/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     pcs_sequence.c
  * @brief    pcs sequence module
  * @company  SOFARSOLAR
  * @author   WWX
  * @note
  * @version  V02
  * @date     2023/05/31
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "array.h"
#include "csu_data.h"
#include "cup_sofar_can.h"
#include "device.h"
#include "pcs.h"
#include "pcs_sequence.h"
#include "sdk.h"
#include "sdk_core.h"
#include "state_machine.h"
#include "pcsc_diag.h"
#include "pcsc_opt_log.h"
#include "can1_bus.h"
#include "product.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
//#define DEBUG_SM_PCS

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/
// States(Modes) array list of pcs sequence state machine
const sm_state_t pcs_sm_state_array[] =
{
	// Name               ID   Entry            Action            Exit
	{"Initial",           0, &st00_entry_pcs, &st00_action_pcs, &st00_exit_pcs},
	{"Build Up list",     1, &st01_entry_pcs, &st01_action_pcs, &st01_exit_pcs},
	{"Get Information",   2, &st02_entry_pcs, &st02_action_pcs, &st02_exit_pcs},
	{"Build Up Grouping", 3, &st03_entry_pcs, &st03_action_pcs, &st03_exit_pcs},
	{"normal",            4, &st04_entry_pcs, &st04_action_pcs, &st04_exit_pcs},
	{"refresh",           5, &st05_entry_pcs, &st05_action_pcs, &st05_exit_pcs},
};

// Transitions array list of pcs sequence state machine
const sm_trans_t pcs_sm_trans_array[] =
{
	// CurrentState            NextState               Transition
	{&pcs_sm_state_array[0], &pcs_sm_state_array[1], &check_tr00_pcs},
	{&pcs_sm_state_array[1], &pcs_sm_state_array[2], &check_tr01_pcs},
	{&pcs_sm_state_array[2], &pcs_sm_state_array[3], &check_tr02_pcs},
	{&pcs_sm_state_array[3], &pcs_sm_state_array[4], &check_tr03_pcs},
	{&pcs_sm_state_array[4], &pcs_sm_state_array[5], &check_tr04_pcs},
	{&pcs_sm_state_array[5], &pcs_sm_state_array[4], &check_tr05_pcs},
};

// get constant information request command
const uint32_t pcs_const_req_array[] =
{
	PCSM_DEVICE_INFO_1,
};

// get variable information request command
const uint32_t pcs_var_req_array[] =
{
	PCSM_REMOTE_SIGNALING_1,
	PCSM_REMOTE_METERING_1,
    PCSM_REMOTE_METERING_BMS,
	PCSM_REMOTE_METERING_2,
	PCSM_REMOTE_METERING_3,
	PCSM_PARAMETER_1,
	PCSM_PARAMETER_2,
	PCSM_PARAMETER_3,
};

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
// pcs sequence state machine
state_machine_t pcs_state_machine =
{
	&pcs_sm_state_array[0],    // Current state(mode)
	&pcs_sm_state_array[0],
	PCS_SM_STATE_ARRAY_SIZES,
	&pcs_sm_trans_array[0],
	PCS_SM_TRANS_ARRAY_SIZES
};

bool_t pcs_init_ok;
bool_t pcs_build_up_list_ok;
bool_t pcs_get_const_info_ok;
bool_t pcs_grouping_set_ok;
bool_t pcs_refresh_ok;
bool_t pcs_regrouping;
bool_t pcs_model_init_ok;
bool_t pcs_model_refresh_ok;
bool_t power_magic_init_ok;
bool_t trigger_pm_init;

// pcs
uint16_t pcs_timer_count;
list_node_t *node_pcs = NULL;
list_node_t *node_pcs_for_const = NULL;
list_node_t *node_pcs_for_var = NULL;
device_cmd_t const_cmd_pcs =
{
	DEVICE_PCS,
	CSU_CAN5,
	0,
	&pcs_const_req_array[0],
	(sizeof(pcs_const_req_array) >> 2)
};

device_cmd_t var_cmd_pcs =
{
	DEVICE_PCS,
	CSU_CAN5,
	0,
	&pcs_var_req_array[0],
	(sizeof(pcs_var_req_array) >> 2)
};

bool_t trigger_pcs_sm;

#ifdef DEBUG_SM_PCS
bool_t debug_result_pcs = FALSE;
#endif

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/******************************************************************************
 * pcs_sm_init().
 * Initialize pcs sequence module [Called by the main initial stage]
 *
 * @param none(I)
 * @return none
 *****************************************************************************/
void pcs_sm_init(void)
{
	trigger_pcs_sm = TRUE;
	state_machine_init(&pcs_state_machine);
}

/******************************************************************************
 * fast_task_pcs_sm().
 * Manage pcs sequence state machine, check transition conditions and
 * execute current state(mode). [Called by task scheduler]
 *
 * @param none(I)
 * @return none
 *****************************************************************************/
void fast_task_pcs_sm(void)
{
	state_machine_exe_st(&pcs_state_machine);
	state_machine_chk_tr(&pcs_state_machine);
}

/******************************************************************************
 * st00_entry_pcs().
 * pcs initial [Called by fast_task_pcs]
 *
 * @param none(I)
 * @return none
 *****************************************************************************/
void st00_entry_pcs(void)
{
//#ifdef Debug
//  eStatusInputcan[0] = E_STATUS_ENTRY;
//#endif
	clear_struct_data((uint8_t*)&pcs_sn_analysis_success[0], sizeof(pcs_sn_analysis_success));
	trigger_pm_init = FALSE;
	// pcs sm status change
	pcs_init_ok = TRUE;
}

/******************************************************************************
 * ADD_ONE_LINE_SHORT_DESCRIPTION_HERE.
 * ADD_MULTILINE_DESCRIPTION_HERE [Called by the OS ? How, When ?]
 *
 * @param none(I)
 * @return none
 *****************************************************************************/
void st00_action_pcs(void)
{
//#ifdef Debug
//  eStatusInputCAN[0] = E_STATUS_ACTION;
//#endif
	device_init();
	pcs_init_ok = TRUE;
}

/******************************************************************************
 * ADD_ONE_LINE_SHORT_DESCRIPTION_HERE.
 * ADD_MULTILINE_DESCRIPTION_HERE [Called by the OS ? How, When ?]
 *
 * @param none(I)
 * @return none
 *****************************************************************************/
void st00_exit_pcs(void)
{
//#ifdef Debug
//  eStatusInputCAN[0] = E_STATUS_EXIT;
//#endif

	pcs_init_ok = FALSE;
}

/******************************************************************************
 * st01_entry_pcs().
 * pcs heart data initial [Called by fast_task_pcs_sm]
 *
 * @param eMeasure (I) measure to set
 * @param fValue   (I) measure value
 * @return This is the resutling value
 *****************************************************************************/
void st01_entry_pcs(void)
{
//#ifdef Debug
//  eStatusInputCAN[1] = E_STATUS_ENTRY;
//#endif

	pcs_timer_count = PCS_COUNT_INIT;
}

/******************************************************************************
 * st01_action_pcs().
 * pcs build up list [Called by fast_task_pcs_sm]
 *
 * @param eMeasure (I) measure to set
 * @param fValue   (I) measure value
 * @return This is the resutling value
 *****************************************************************************/
void st01_action_pcs(void)
{
//#ifdef Debug
//  eStatusInputCAN[1] = E_STATUS_ACTION;
//#endif
	bool_t ret = FALSE;
	pcs_timer_count++;

	ret = check_device_refresh(&device_pcs);
	if(ret)
	{
//		sdk_log_i("st01_action\r\n");
//		sdk_log_i("st01_action %s total network = %d\r\n", __FILE__, array.array_data.variable.pcsm_online);
		device_list_refresh(&device_pcs, REFRESH_ALL);

		// pcs count refresh
		device_cnt_refresh(&device_pcs);

		// At least one pcs builded to change pcs sm status
		if(list_pcs.head != NULL)
		{
			pcs_build_up_list_ok = TRUE;
		}

		pcs_timer_count = PCS_COUNT_INIT;
	}
}

/******************************************************************************
 * ADD_ONE_LINE_SHORT_DESCRIPTION_HERE.
 * ADD_MULTILINE_DESCRIPTION_HERE [Called by the OS ? How, When ?]
 *
 * @param eMeasure (I) measure to set
 * @param fValue   (I) measure value
 * @return This is the resutling value
 *****************************************************************************/
void st01_exit_pcs(void)
{
//#ifdef Debug
//  eStatusInputCAN[1] = E_STATUS_EXIT;
//#endif
	trigger_model_read = TRUE;
	pcs_build_up_list_ok = FALSE;
}

/******************************************************************************
 * st02_entry_pcs().
 * pcs_get data initial [Called by fast_task_pcs_sm]
 *
 * @param none(I)
 * @return none
 *****************************************************************************/
void st02_entry_pcs(void)
{
//#ifdef Debug
//  eStatusInputcan[0] = E_STATUS_ENTRY;
//#endif
	node_pcs = link_list_get_head(&list_pcs);
	node_pcs_for_const = node_pcs;
	trigger_pcs_const = TRUE;
}

/******************************************************************************
 * st02_action_pcs().
 * get pcs const information [Called by fast_task_pcs_sm]
 *
 * @param none(I)
 * @return none
 *****************************************************************************/
void st02_action_pcs(void)
{
//#ifdef Debug
//  eStatusInputCAN[0] = E_STATUS_ACTION;
//#endif
//	sdk_log_i("st02_action\r\n");
//	sdk_log_i("st02_action %s total network = %d\r\n", __FILE__, array.array_data.variable.pcsm_online);
	//if(send_cmd_to_device(node_pcs, &const_cmd_pcs) == REQ_FINISH)
//	if(trigger_pcs_const == FALSE)
//	{
//		csu.variable.can1_dev_const.bit.pcs = TRUE;   //???
	pcs_get_const_info_ok = TRUE;
//	}
}

/******************************************************************************
 * ADD_ONE_LINE_SHORT_DESCRIPTION_HERE.
 * ADD_MULTILINE_DESCRIPTION_HERE [Called by the OS ? How, When ?]
 *
 * @param none(I)
 * @return none
 *****************************************************************************/
void st02_exit_pcs(void)
{
//#ifdef Debug
//  eStatusInputCAN[0] = E_STATUS_EXIT;
//#endif

	pcs_get_const_info_ok = FALSE;
}

/******************************************************************************
 * ADD_ONE_LINE_SHORT_DESCRIPTION_HERE.
 * ADD_MULTILINE_DESCRIPTION_HERE [Called by the OS ? How, When ?]
 *
 * @param none(I)
 * @return none
 *****************************************************************************/
void st03_entry_pcs(void)
{
//#ifdef Debug
//  eStatusInputcan[0] = E_STATUS_ENTRY;
//#endif

	node_pcs = link_list_get_head(&list_pcs);
}

/******************************************************************************
 * ADD_ONE_LINE_SHORT_DESCRIPTION_HERE.
 * ADD_MULTILINE_DESCRIPTION_HERE [Called by the OS ? How, When ?]
 *
 * @param none(I)
 * @return none
 *****************************************************************************/
void st03_action_pcs(void)
{
//#ifdef Debug
//  eStatusInputCAN[0] = E_STATUS_ACTION;
//#endif

	//set_pcs_group(node_pcs, *csu1_id, *csu2_id);   ???
//	sdk_log_i("st03_action\r\n");
//	sdk_log_i("st03_action %s total network = %d\r\n", __FILE__, array.array_data.variable.pcsm_online);
	pcs_grouping_set_ok = TRUE;
}

/******************************************************************************
 * ADD_ONE_LINE_SHORT_DESCRIPTION_HERE.
 * ADD_MULTILINE_DESCRIPTION_HERE [Called by the OS ? How, When ?]
 *
 * @param none(I)
 * @return none
 *****************************************************************************/
void st03_exit_pcs(void)
{
//#ifdef Debug
//  eStatusInputCAN[0] = E_STATUS_EXIT;
//#endif

	pcs_grouping_set_ok = FALSE;
    pcs_regrouping = FALSE;
}

/******************************************************************************
 * st04_entry_pcs().
 * pcs_get data and pcs heart data initial [Called by fast_task_pcs_sm]
 *
 * @param none(I)
 * @return none
 *****************************************************************************/
void st04_entry_pcs(void)
{
//#ifdef Debug
//  eStatusInputcan[0] = E_STATUS_ENTRY;
//#endif
	uint8_t node_num;

	node_num = link_list_get_size(&list_pcs);
	opt_log_record("node num is %d", node_num);
	pcs_timer_count = PCS_COUNT_INIT;

	node_pcs_for_var = link_list_get_head(&list_pcs);
	trigger_model_read = TRUE;
}

/******************************************************************************
 * st04_action_pcs().
 * get pcs variable information and refresh list [Called by fast_task_pcs_sm]
 *
 * @param none(I)
 * @return none
 *****************************************************************************/
void st04_action_pcs(void)
{
//#ifdef Debug
//  eStatusInputCAN[0] = E_STATUS_ACTION;
//#endif
//	sdk_log_i("st04_action\r\n");
//	sdk_log_i("st04_action %s total network = %d\r\n", __FILE__, array.array_data.variable.pcsm_online);
	//node_pcs_for_var = node_pcs;
	// pcs count refresh
	device_cnt_refresh(&device_pcs);
	// link list refresh
	pcs_timer_count++;

	// 3 second check once refresh
	pcs_refresh_ok = check_device_refresh(&device_pcs);
	if((((!power_magic_init_ok) && (pcs_model_init_ok)) || (pcs_model_refresh_ok)) && (!fault_model_read))
	{
		trigger_pm_init = !power_magic_init_ok;
		trigger_model_read = FALSE;
		trigger_model_read_fault_diag = FALSE;
		pcs_model_refresh_ok = FALSE;
	}
}

/******************************************************************************
 * ADD_ONE_LINE_SHORT_DESCRIPTION_HERE.
 * ADD_MULTILINE_DESCRIPTION_HERE [Called by the OS ? How, When ?]
 *
 * @param none(I)
 * @return none
 *****************************************************************************/
void st04_exit_pcs(void)
{
//#ifdef Debug
//  eStatusInputCAN[0] = E_STATUS_EXIT;
//#endif

	pcs_refresh_ok = FALSE;
}

/******************************************************************************
 * st05_entry_pcs().
 * pcs_get data initial and pcs list add node [Called by fast_task_pcs_sm]
 *
 * @param none(I)
 * @return none
 *****************************************************************************/
void st05_entry_pcs(void)
{
//#ifdef Debug
//  eStatusInputcan[0] = E_STATUS_ENTRY;
//#endif
	if(list_pcs.tail != NULL)
	{
		// save current tail before add node
		node_pcs = link_list_get_tail(&list_pcs);
		// add node
		device_list_refresh(&device_pcs, REFRESH_ADD);
		// get add node
		node_pcs = node_pcs->next;
	}
	// list is empty
	else
	{
		// add node
		device_list_refresh(&device_pcs, REFRESH_ADD);
		// get add node
		node_pcs = link_list_get_head(&list_pcs);
	}
	node_pcs_for_const = node_pcs;
	trigger_pcs_const = TRUE;
}

/******************************************************************************
 * st05_action_pcs().
 * get pcs const information [Called by fast_task_pcs_sm]
 *
 * @param none(I)
 * @return none
 *****************************************************************************/
void st05_action_pcs(void)
{
//#ifdef Debug
//  eStatusInputCAN[0] = E_STATUS_ACTION;
//#endif
//	sdk_log_i("st05_action\r\n");
//	sdk_log_i("st05_action %s total network = %d\r\n", __FILE__, array.array_data.variable.pcsm_online);
//	if(node_pcs != NULL)
//	{
//		// const finish
//		//if(send_cmd_to_device(node_pcs, &const_cmd_pcs) == REQ_FINISH)
//		if(trigger_pcs_const == FALSE)
//		{
//			//set_pcs_group(node_pcs, *csu1_id, *csu2_id);    //???
//			pcs_grouping_set_ok = TRUE;
//		}
//	}
//	else
//	{
	pcs_grouping_set_ok = TRUE;
//	}
}

/******************************************************************************
 * st05_exit_pcs().
 * pcs list delete node [Called by fast_task_pcs_sm]
 *
 * @param none(I)
 * @return none
 *****************************************************************************/
void st05_exit_pcs(void)
{
//#ifdef Debug
//  eStatusInputCAN[0] = E_STATUS_EXIT;
//#endif
	// delete node before exit current status
	device_list_refresh(&device_pcs, REFRESH_DEL);

	// auto send const information to can2
	//can2_ack_const = TRUE;   //???

	pcs_grouping_set_ok = FALSE;
}

/******************************************************************************
 * check_tr00_pcs().
 * check pcs_init_ok status [Called by fast_task_pcs_sm]
 *
 * @param eMeasure (I) measure to set
 * @param fValue   (I) measure value
 * @return This is the resutling value
 *****************************************************************************/
bool_t check_tr00_pcs(void)
{
	bool_t result = FALSE;

	if(pcs_init_ok == TRUE)
	{
		result = TRUE;
	}
	else
	{
		result = FALSE;
	}

#ifdef DEBUG_SM_PCS
	result = debug_result_pcs;
	if (debug_result_pcs == TRUE) debug_result_pcs = FALSE;
#endif

	return result;
}

/******************************************************************************
 * check_tr01_pcs().
 * check pcs_build_up_list_ok status [Called by fast_task_pcs_sm]
 *
 * @param eMeasure (I) measure to set
 * @param fValue   (I) measure value
 * @return This is the resutling value
 *****************************************************************************/
bool_t check_tr01_pcs(void)
{
	bool_t result = FALSE;

	if(pcs_build_up_list_ok == TRUE)
	{
		result = TRUE;
	}
	else
	{
		result = FALSE;
	}

#ifdef DEBUG_SM_PCS
	result = debug_result_pcs;
	if (debug_result_pcs == TRUE) debug_result_pcs = FALSE;
#endif

	return result;
}

/******************************************************************************
 * check_tr02_pcs().
 * check pcs_get_const_info_ok status [Called by fast_task_pcs_sm]
 *
 * @param eMeasure (I) measure to set
 * @param fValue   (I) measure value
 * @return This is the resutling value
 *****************************************************************************/
bool_t check_tr02_pcs(void)
{
	bool_t result = FALSE;
	if(pcs_get_const_info_ok == TRUE)
	{
		result = TRUE;
	}
	else
	{
		result = FALSE;
	}

	return result;
}

/******************************************************************************
 * check_tr03_pcs().
 * check pcs_grouping_set_ok status [Called by fast_task_pcs_sm]
 *
 * @param eMeasure (I) measure to set
 * @param fValue   (I) measure value
 * @return This is the resutling value
 *****************************************************************************/
bool_t check_tr03_pcs(void)
{
	bool_t result = FALSE;

	if(pcs_grouping_set_ok == TRUE)
	{
		result = TRUE;
	}
	else
	{
		result = FALSE;
	}

#ifdef DEBUG_SM_PCS
	result = debug_result_pcs;
	if (debug_result_pcs == TRUE) debug_result_pcs = FALSE;
#endif

	return result;
}

/******************************************************************************
 * check_tr04_pcs().
 * check pcs_refresh_ok status [Called by fast_task_pcs_sm]
 *
 * @param eMeasure (I) measure to set
 * @param fValue   (I) measure value
 * @return This is the resutling value
 *****************************************************************************/
bool_t check_tr04_pcs(void)
{
	bool_t result = FALSE;

	if(pcs_refresh_ok == TRUE)
	{
		result = TRUE;
	}
	else
	{
		result = FALSE;
	}

#ifdef DEBUG_SM_PCS
	result = debug_result_pcs;
	if (debug_result_pcs == TRUE) debug_result_pcs = FALSE;
#endif

	return result;
}

/******************************************************************************
 * check_tr05_pcs().
 * check pcs_reset_group_ok status [Called by fast_task_pcs_sm]
 *
 * @param eMeasure (I) measure to set
 * @param fValue   (I) measure value
 * @return This is the resutling value
 *****************************************************************************/
/*bool_t check_tr05_pcs(void)
{
	bool_t result = FALSE;

	if(pcs_regrouping == TRUE)
	{
		result = TRUE;
		sdk_log_d("tr05 true!\r\n");
	}
	else
	{
		result = FALSE;
	}

#ifdef DEBUG_SM_PCS
	result = debug_result_pcs;
	if (debug_result_pcs == TRUE) debug_result_pcs = FALSE;
#endif

	return result;
}
*/

/******************************************************************************
 * check_tr06_pcs().
 * check pcs_grouping_set_ok status [Called by fast_task_pcs_sm]
 *
 * @param eMeasure (I) measure to set
 * @param fValue   (I) measure value
 * @return This is the resutling value
 *****************************************************************************/
bool_t check_tr05_pcs(void)
{
	bool_t result = FALSE;

	if(pcs_grouping_set_ok == TRUE)
	{
		result = TRUE;
	}
	else
	{
		result = FALSE;
	}

#ifdef DEBUG_SM_PCS
	result = debug_result_pcs;
	if (debug_result_pcs == TRUE) debug_result_pcs = FALSE;
#endif

	return result;
}

/******************************************************************************
* End of module
******************************************************************************/
