/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     pcs.c
  * @brief    pcs module
  * @company  SOFARSOLAR
  * @author   WWX
  * @note
  * @version  V02
  * @date     2023/05/17
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "array.h"
#include "can1_bus.h"
#include "common.h"
#include "cup_sofar_can.h"
#include "fifo_can.h"
#include "link_list.h"
#include "pcs.h"
#include "pcs_sequence.h"
#include "pcsc_diag.h"
#include "pcsc_opt_log.h"
//#include "rs485_hmi.h"
#include "sdk.h"
#include "sdk_core.h"
#include "product.h"
#include "power_manage.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
// Unit: 0.01kW, 215kW(rating) * 1.1
// #define SINGLE_PCSM_MAX_POWER                                             23700
// #define SINGLE_PCSM_MIN_POWER                                            -23700

// reactive power can't more than 215kVar
// Unit: 0.01kVar
#define SINGLE_PCSM_MAX_REPOWER                                           21500
#define SINGLE_PCSM_MIN_REPOWER                                          -21500

#define SINGLE_PCSM_MAX_DERATE                                            30000
#define SINGLE_PCSM_MIN_DERATE                                           -30000

#define GROUP_ONE_MAX_ID                                                      4
#define PCSM_GROUP_ONE                                                        1
#define PCSM_GROUP_TWO                                                        2

// 3min = 3 * 60 * 10
#define AFE_DELAY_REF                                                      1800

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
//__attribute__((section ("._DATA"))) pcs_t pcsc[PCS_COUNTER];
bool_t trigger_pcs_const;
bool_t trigger_pcs_var;
bool_t trigger_cmd_to_pcs;
bool_t shutdown_fault = FALSE;
bool_t afe_set_ok;
bool_t trigger_afe_delay;
bool_t g_trigger_sn_analysis;
bool_t g_model_read_fail = FALSE;

uint16_t pcs_last_updating_cnt = 0;
pcsm_group_t pcsm_group[GROUP_NUMS] = {0};
pcsm_chg_dch_limit_t pcsm_chg_dch_limit[PCSM_NUMS];
debug_info_t debug_info_data;

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/
/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/******************************************************************************
 * pcs_init().
 * Initialize pcs module. [Called by sw_init()]
 *
 * @param  none (I)
 * @param  none (O)
 * @return none
 *****************************************************************************/
void pcs_init(void)
{
	uint16_t data;

	trigger_pcs_const = FALSE;
	trigger_pcs_var = FALSE;
	shutdown_fault = FALSE;

    // Initialize power_control_source mode from eeprom
    setting_get(SYS_PARM, EE_SYS_PARM_CTRL_PARM, &data, SYS_PARM_CTRL_PARM_LEN);
    array.pcsc.pcsc_ctrl.power_control_source = data;
	g_trigger_sn_analysis = FALSE;
	g_model_read_fail = FALSE;
	g_trigger_close_ems = FALSE;
	clear_struct_data((uint8_t*)&pcsm_chg_dch_limit[0], sizeof(pcsm_chg_dch_limit));
	clear_struct_data((uint8_t*)&debug_info_data, sizeof(debug_info_data));
}


/******************************************************************************
 * fast_task_pcs_const().
 * Send PCS const REQ. [Called by task.]
 *
 * @param  none
 * @return none
 *****************************************************************************/
void fast_task_pcs_const(void)
{
	bool_t cmd_valid = TRUE;

	pcsm_cmd_t can_cmd_temp;

	// NULL pointer protection
	if(node_pcs_for_const == NULL)
	{
		trigger_pcs_const = FALSE;
		return;
	}

	switch(const_cmd_pcs.data[const_cmd_pcs.index])
	{
		case PCSM_DEVICE_INFO_1:
			can_cmd_temp.offset.all = PCS_SN;
			can_cmd_temp.fun_code = PCS_CMD_GET_DEVICE_INFO;
			can_cmd_temp.len = PCS_SN_LEN;
			break;
		default:
			cmd_valid = FALSE;
			break;
	}

	if(cmd_valid)
	{
		can_cmd_temp.dst_addr = node_pcs_for_const->id;
		fifo_can_push(&fifo_can1_cmd, &can_cmd_temp);

		// TODO optimization and log CAN sending err
	}
	// Request the next piece of data
	const_cmd_pcs.index++;
	if(const_cmd_pcs.index >= const_cmd_pcs.cnt)
	{
		const_cmd_pcs.index = 0;
		node_pcs_for_const = node_pcs_for_const->next;
		if(node_pcs_for_const == NULL)
		{
			// all nodes and all commands done, stop task
			trigger_pcs_const = FALSE;
		}
	}
}

/******************************************************************************
 * can1_cmd_pcsm().
 * csu point-to-point or brocast cmd to pcsm. [Called by app.]
 *
 * @param  id   (I) 1~8: pcsm id, 0: brocast id
 * @param  cmd  (I) cmd code
 * @return none (O)
 *****************************************************************************/
void can1_cmd_pcsm(pcsm_cmd_t *pcsm_cmd)
{
	bool_t cmd_valid = FALSE;
	uint8_t can_data[8];
	uint8_t cmu_num = 0;
	uint8_t index, len;
	can_id_t can_id;
	uint32_t can_port = CAN1_PORT;
	half_word_t temp;
	uint8_t can_id_type, can_id_prio;

//	node = link_list_find_node(&list_pcs, id);
	cmu_num = array.array_data.variable.cmu_online;
    temp.all = 0;
    clear_struct_data(&can_data[0], sizeof(can_data));

	// brocasting or specific cmd protection
	if((cmu_num == 0) && (pcsm_cmd->dst_addr == 0) && (pcsm_cmd->fun_code != AUTO_HEART_BEAT))
	{
		return;
	}

	index = pcsm_cmd->dst_addr - 1;
	if(pcsm_cmd->fun_code == PCS_CMD_GET_DEVICE_INFO || \
			pcsm_cmd->fun_code == PCS_CMD_GET_REMOTE_SIGNALING || \
			pcsm_cmd->fun_code == PCS_CMD_GET_REMOTE_METERING || \
			pcsm_cmd->fun_code == PCS_CMD_GET_PARAMETER)
	{
		can_id_type = 2;
		can_id_prio = 6;
		cmd_valid = TRUE;
		len = 3;
	}
	else if(pcsm_cmd->fun_code == PCS_CMD_SET_PARAMETER)
	{
		can_id_type = 1;
		can_id_prio = 6;
		len = (2 * pcsm_cmd->len);
		switch (pcsm_cmd->offset.all)
		{
			case ACTIVE_POWER_REF:
				if(pcsm_cmd->dst_addr == PCSM_BCAST_ID)
				{
					cmu_num = array.array_data.variable.cmu_running;
					// pcsc power ref(0.1kW) --> pcsm power ref(0.01kW)
					temp.all = ((int32_t)array.pcsc.pcsc_ctrl.active_power_ref * 10) / cmu_num;
					check_uint8_validity(cmu_num, 1, PCSM_NUMS, &cmd_valid);
				}
				else
				{
					if(array.cmu[index].sys_status == CMU_SYS_RUNNING)
					{
						temp.all = array.pcsc.pcsc_data.pcsm_data[index].set[WRITE_INDEX].active_power_ref;
						cmd_valid = TRUE;
					}
				}
				constrain_int16_t_data((int16_t*)&temp.all, \
							-PARAMETER_ACCURACY_MAGNIFICATION_6 * array.csu.csu_data.csu_const.base_rated_power * ACTIVE_POWER_OVERLOAD_MULTIPLE, \
							PARAMETER_ACCURACY_MAGNIFICATION_6 * array.csu.csu_data.csu_const.base_rated_power * ACTIVE_POWER_OVERLOAD_MULTIPLE);
				if(0 == temp.all)
				{
					opt_log_record("use can set power to pcsm id :%d, value:%d", \
					pcsm_cmd->dst_addr, (int16_t)temp.all);
					sdk_log_a("use can set power to pcsm id :%d, value:%d\r\n", \
					pcsm_cmd->dst_addr, (int16_t)temp.all);
				}
				break;
			case REACTIVE_POWER_REF:
				if(pcsm_cmd->dst_addr == PCSM_BCAST_ID)
				{
					cmu_num = array.array_data.variable.cmu_running;
					// pcsc power ref(0.1kVar) --> pcsm power ref(0.01kVar)
					temp.all = ((int32_t)array.pcsc.pcsc_ctrl.reactive_power_ref * 10) / cmu_num;
					check_uint8_validity(cmu_num, 1, PCSM_NUMS, &cmd_valid);
				}
				else
				{
					if(array.cmu[index].sys_status == CMU_SYS_RUNNING)
					{
						temp.all = array.pcsc.pcsc_data.pcsm_data[index].set[WRITE_INDEX].reactive_power_ref;
						cmd_valid = TRUE;
					}
				}
				constrain_int16_t_data((int16_t *)&temp.all, SINGLE_PCSM_MIN_REPOWER,
																	SINGLE_PCSM_MAX_REPOWER);
				break;
			case DRMN_SET:
				temp.all = array.pcsc.pcsc_ctrl.drmn_status;
				check_uint8_validity(temp.all, 0, MASK_BITS(4), &cmd_valid);
				break;
			default:
				break;
		}
	}
	else if(pcsm_cmd->fun_code == AUTO_HEART_BEAT)
	{
		can_id_type = 1;
		can_id_prio = 6;
		len = 1;
		cmd_valid = TRUE;
		temp.bytes.low = array.csu.csu_data.csu_heart.heart_packet.grid_state_word_byte0.all;
	}
	if(cmd_valid)
	{
		can_data[0] = pcsm_cmd->offset.bytes.low;
		can_data[1] = pcsm_cmd->offset.bytes.high;
		can_data[2] = pcsm_cmd->len;
		can_data[3] = temp.bytes.low;
		can_data[4] = temp.bytes.high;

		can_id.src_addr = CSU_MCU2;
		can_id.src_type = DEVICE_CSU;
		can_id.dst_addr = pcsm_cmd->dst_addr;
		can_id.dst_type = DEVICE_PCS;
		can_id.fun_code = pcsm_cmd->fun_code;
		can_id.type = can_id_type;
		can_id.prio = can_id_prio;

		cup_sofar_can_send(can_port, &can_id, can_data, len);
	}

}

/******************************************************************************
 * clear_pcsm_info().
 * clear pcsm infos when can5 comm loses. [Called by app.]
 *
 * @param  none (I)
 * @return none (O)
 *****************************************************************************/
void clear_pcsm_info(void)
{
	uint16_t index;
	pcsm_data_t *pcsm_data;

	for(index = 0; index < PCSM_NUMS; index++)
	{
		if(fault_pcsm_can1[index])
		{
			pcsm_data = &(array.pcsc.pcsc_data.pcsm_data[index]);
			clear_struct_data((uint8_t *)pcsm_data, sizeof(pcsm_data_t));
		}
	}
}

/******************************************************************************
 * fast_task_clear_info().
 * clear info. [Called by app.]
 *
 * @param  none (I)
 * @return none (O)
 *****************************************************************************/
void fast_task_clear_info(void)
{
	clear_pcsm_info();
}

/******************************************************************************
 * fast_task_clear_info().
 * clear info. [Called by app.]
 *
 * @param  none (I)
 * @return none (O)
 *****************************************************************************/
/*
void slow_task_cmd_push(void)
{
	 pcsm_cmd_t can_cmd_temp;
	 bool_t flag;
	 uint16_t id;
	 uint16_t cmd_offset;

	 flag = fifo_can_pop(&fifo_can5_cmd, &can_cmd_temp);
	 if(flag)
	 {
	 	id = can_cmd_temp.dst_addr;
	 	cmd_offset = can_cmd_temp.offset.all;
	 	can5_cmd_pcsm(id, cmd_offset);
	 }
}
*/


/******************************************************************************
 * pcs_sn_analysis().
 * pcs sn analysis. [Called by app]
 *
 * @param  pcs_sn (I)
 * @param  none (O)
 * @return none
 *****************************************************************************/
int8_t pcs_sn_analysis(uint8_t* pcs_sn)
{
	uint8_t cmp_result[2];
	bool_t ret = FALSE;
	int8_t machine_index = -1;
	uint8_t i;

	for (i = 0; (i < PM_MODEL_NUM) && (FALSE == ret); i++)
	{
		cmp_result[0] = memcmp(&pcs_machine_type[i].model_code[0], &pcs_sn[3], 3);
		cmp_result[1] = memcmp(&pcs_machine_type[i].power_level_code[0], &pcs_sn[6], 4);
		if((0 == cmp_result[0]) && (0 == cmp_result[1]))
		{
			ret = TRUE;
			machine_index = i;
		}
	}
	return machine_index;
}

/******************************************************************************
 * slow_task_sn_analysis().
 * sn analysis. [Called by app]
 *
 * @param  none (I)
 * @param  none (O)
 * @return none
 *****************************************************************************/
void slow_task_sn_analysis(void)
{
	uint8_t i;
	int8_t machine_index = -1;

	for (i = 0; (i < array.pcsc.pcsc_ctrl.pcsm_nums_set) && (i < PCSM_NUMS); i++)
	{
		machine_index = pcs_sn_analysis((uint8_t*)&array.pcsc.pcsc_data.pcsm_data[i].constant.sn1);
		if(machine_index != -1)
		{
			array.pcsc.pcsc_data.pcsm_data[i].constant.rated_power = pcs_machine_type[machine_index].rated_power;
			pcs_sn_analysis_success[i] = TRUE;
			array.csu.csu_data.csu_const.base_rated_power = pcs_machine_type[machine_index].rated_power;
		}
		else
		{
			array.pcsc.pcsc_data.pcsm_data[i].constant.rated_power = 0;
			pcs_sn_analysis_success[i] = FALSE;
		}
	}
}


/******************************************************************************
 * modbus_init().
 * Initialize modbus module. [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void modbus_init(rs485_settting_parm_t rs485_settting_parm)
{
	int32_t result;

	result = sdk_modbus_rtu_init(rs485_settting_parm.port, rs485_settting_parm.slave_addr, rs485_settting_parm.baud);

	if(result != SF_OK)
	{
		sdk_log_d("modbus %d init failed!\r\n", rs485_settting_parm.port);
		return;
	}

	result = sdk_modbus_connect(rs485_settting_parm.port);
	if(result != SF_OK)
	{
		sdk_log_d("modbus %d connect failed!\r\n", rs485_settting_parm.port);
		return;
	}

	result = sdk_modbus_response_timeout_set(rs485_settting_parm.port, rs485_settting_parm.timeout);
	if(result != SF_OK)
	{
		sdk_log_d("modbus %d response set timeout failed!\r\n", rs485_settting_parm.port);
		return;
	}

	result = sdk_modbus_indication_timeout_set(rs485_settting_parm.port, rs485_settting_parm.timeout);
	if(result != SF_OK)
	{
		sdk_log_d("modbus %d indication set timeout failed!\r\n", rs485_settting_parm.port);
		return;
	}
}
/******************************************************************************
* End of module
******************************************************************************/

