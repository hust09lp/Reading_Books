/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     rs485_device_manage.c
  * @brief    rs485 device manage module
  * @company  SOFARSOLAR
  * @author   ZZJ
  * @note
  * @version  V01
  * @date     2023/11/30
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "ems.h"
#include "array.h"
#include "pcsc_diag.h"
#include "rs485_device_manage.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
bool_t trigger_rs485_manage;
rs485_device_enable_u g_rs485_device_enable;

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/
/******************************************************************************
 * rs485_device_init().
 * rs485 device init. [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_device_init(void)
{
	trigger_metering_meter = FALSE;
	trigger_backflow_meter = FALSE;
	trigger_microcomputer = FALSE;
	trigger_dehumidifier = FALSE;
	trigger_measure_control = FALSE;
	trigger_rs485_manage = FALSE;

	trigger_meter2 = FALSE;
	g_rs485_device_enable.all = 0;
    clear_struct_data((uint8_t*)&g_trigger_pv_meter[0],sizeof(g_trigger_pv_meter));
    clear_struct_data((uint8_t*)&trigger_meter3[0],sizeof(trigger_meter3));
}

/******************************************************************************
 * rs485_device_deinit().
 * rs485 device init. [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_device_deinit(uint16_t last_scenario)
{
	trigger_metering_meter = FALSE;
	trigger_backflow_meter = FALSE;
	trigger_microcomputer = FALSE;
	trigger_dehumidifier = FALSE;
	trigger_measure_control = FALSE;
	trigger_rs485_manage = FALSE;

	trigger_meter2 = FALSE;
    clear_struct_data((uint8_t*)&g_trigger_pv_meter[0],sizeof(g_trigger_pv_meter));
    clear_struct_data((uint8_t*)&trigger_meter3[0],sizeof(trigger_meter3));
	sdk_modbus_close(0);
	sdk_modbus_free(0);

	if(ONE_STORAGE_TANK_XIAOJU_1_2 == last_scenario)
	{
		sdk_modbus_close(RS485_METER_2);
		sdk_modbus_free(RS485_METER_2);
		sdk_modbus_close(RS485_METER_3);
		sdk_modbus_free(RS485_METER_3);
	}
	else
	{
		sdk_modbus_close(1);
		sdk_modbus_free(1);
		sdk_modbus_close(2);
		sdk_modbus_free(2);
	}
	sdk_modbus_close(RS485_BACKFLOW_METER);
	sdk_modbus_free(RS485_BACKFLOW_METER);
}
/******************************************************************************
 * rs485_device_port_init().
 * rs485 device port init. [Called by.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_device_port_init(void)
{
	if(product_info.model_num == POWER_MAGIC_690V)
	{
		rs485_backflow_meter_init();
		rs485_measure_control_init();
		rs485_microcomputer_init();
	}
	else
	{
		rs485_metering_meter_init();
		rs485_backflow_meter_init();
		if(ONE_STORAGE_TANK_XIAOJU_1_2 == array.pcsc.pcsc_ctrl.scenario_setting)
		{
			rs485_meter2_init();
			rs485_meter3_init();
		}
		else
		{
			rs485_pv_meter_init();
			rs485_dehumidification_init();
		}
	}
}

/******************************************************************************
 * rs485_task_device_manage().
 * rs485 device manage. [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_task_device_manage(void)
{
	uint8_t i;
	if(g_rs485_device_enable.all != array.pcsc.pcsc_ctrl.rs485_enable.all)
	{
		if(product_info.model_num == POWER_MAGIC_400V)
		{
			array.pcsc.pcsc_ctrl.rs485_enable.bit.measure_control = FALSE;
			array.pcsc.pcsc_ctrl.rs485_enable.bit.micro_computer = FALSE;
			if(ONE_STORAGE_TANK_XIAOJU_1_2 == array.pcsc.pcsc_ctrl.scenario_setting)
			{
				array.pcsc.pcsc_ctrl.rs485_enable.bit.dehumidifier = FALSE;
			}
			trigger_backflow_meter = array.pcsc.pcsc_ctrl.rs485_enable.bit.backflow_meter;
			if(FALSE == trigger_backflow_meter)
			{
				fault_backflow_meter = FALSE;
				fault_backflow_meter_cnt = 0;
				clear_struct_data((uint8_t*)&ems.ammeter, sizeof(ems.ammeter));
				clear_struct_data((uint8_t*)&pcc_meter_data, sizeof(pcc_meter_data));
			}
			if(ONE_STORAGE_TANK == array.pcsc.pcsc_ctrl.scenario_setting)
			{
				array.pcsc.pcsc_ctrl.rs485_enable.bit.metering_meter = TRUE;
			}
			trigger_metering_meter = array.pcsc.pcsc_ctrl.rs485_enable.bit.metering_meter;
			if(FALSE == trigger_metering_meter)
			{
				meter1_disconnect_flag = 0;
				fault_metering_meter = FALSE;
				fault_metering_meter_cnt = 0;
				trigger_fut_rs485 = TRUE;
				clear_struct_data((uint8_t*)&metering_meter, sizeof(metering_meter));
			}
			else
			{
				trigger_fut_rs485 = FALSE;
			}
			trigger_dehumidifier = array.pcsc.pcsc_ctrl.rs485_enable.bit.dehumidifier;
			if(FALSE == trigger_dehumidifier)
			{
				fault_dehumidifier_cnt = 0;
				fault_dehumidifier = FALSE;
			}
			g_trigger_pv_meter_sw = array.pcsc.pcsc_ctrl.rs485_enable.bit.pv_meter;
			if(FALSE == g_trigger_pv_meter_sw)
			{
				g_pv_meter_num_record = 0;
				clear_struct_data((uint8_t*)fault_pv_meter_cnt, sizeof(fault_pv_meter_cnt));
				clear_struct_data((uint8_t*)fault_pv_meter, sizeof(fault_pv_meter));
				clear_struct_data((uint8_t*)g_trigger_pv_meter, sizeof(g_trigger_pv_meter));
				clear_struct_data((uint8_t*)&meter2_other_data[0], sizeof(meter2_other_data));
			}
		}
		else if(product_info.model_num == POWER_MAGIC_690V)
		{
			array.pcsc.pcsc_ctrl.rs485_enable.bit.metering_meter = FALSE;
			array.pcsc.pcsc_ctrl.rs485_enable.bit.dehumidifier = FALSE;
			if(ONE_STORAGE_TANK_XIAOJU_1_2 == array.pcsc.pcsc_ctrl.scenario_setting)
			{
				array.pcsc.pcsc_ctrl.rs485_enable.bit.micro_computer = FALSE;
				array.pcsc.pcsc_ctrl.rs485_enable.bit.measure_control = FALSE;
			}
			trigger_backflow_meter = array.pcsc.pcsc_ctrl.rs485_enable.bit.backflow_meter;
			if(FALSE == trigger_backflow_meter)
			{
				fault_backflow_meter_cnt = 0;
				fault_backflow_meter = FALSE;
				clear_struct_data((uint8_t*)&ems.ammeter, sizeof(ems.ammeter));
			}
			trigger_microcomputer = array.pcsc.pcsc_ctrl.rs485_enable.bit.micro_computer;
			if(FALSE == trigger_microcomputer)
			{
				fault_microcomputer_cnt = 0;
				fault_microcomputer = FALSE;
				clear_struct_data((uint8_t*)&microcomputer, sizeof(microcomputer));
			}
			trigger_measure_control = array.pcsc.pcsc_ctrl.rs485_enable.bit.measure_control;
			if(FALSE == trigger_measure_control)
			{
				fault_measure_cnt = 0;
				fault_measure_control = FALSE;
				clear_struct_data((uint8_t*)&measure_control, sizeof(measure_control));
			}
		}
		else
		{
			array.pcsc.pcsc_ctrl.rs485_enable.all = 0;
		}
		g_rs485_device_enable.all = array.pcsc.pcsc_ctrl.rs485_enable.all;
		setting_set(SYS_PARM, EE_SYS_PARM_RS485_ENABLE, &array.pcsc.pcsc_ctrl.rs485_enable.all, HALF_WORD_LEN);
	}

	if(ONE_STORAGE_TANK_XIAOJU_1_2 == array.pcsc.pcsc_ctrl.scenario_setting)
	{
		array.pcsc.pcsc_ctrl.rs485_enable.bit.pv_meter = 0;
		trigger_meter2 = TRUE;
		if(0 == xiao_ju.ammeter3_num)
		{
			if(trigger_meter3[0])
			{
				clear_struct_data((uint8_t*)&trigger_meter3, sizeof(trigger_meter3));
				clear_struct_data((uint8_t*)&fault_meter3, sizeof(fault_meter3));
				clear_struct_data((uint8_t*)&fault_meter3_cnt, sizeof(fault_meter3_cnt));
				clear_struct_data((uint8_t*)&meter3_power_old[0], sizeof(meter3_power_old));
				xiaoju_ammeter.ammeter_3 = 0;
			}
		}
		else
		{
			for(i = 0; i < xiao_ju.ammeter3_num; i++)
			{
				trigger_meter3[i] = TRUE;
			}
		}
		if(metering_meter1_num != xiao_ju.ammeter1_num)
		{
			metering_meter1_num = xiao_ju.ammeter1_num;
			meter1_disconnect_flag = 0;
			clear_struct_data((uint8_t *)&metering_meter, sizeof(metering_meter));
		}
		if(!array.pcsc.pcsc_ctrl.rs485_enable.bit.metering_meter)
		{
			array.pcsc.pcsc_ctrl.rs485_enable.bit.metering_meter = TRUE;
		}
	}
	else
	{
		metering_meter1_num = 1;
	}
}

/******************************************************************************
* End of module
******************************************************************************/
