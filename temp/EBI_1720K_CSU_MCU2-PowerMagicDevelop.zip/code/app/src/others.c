/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     others.c
  * @brief    others
  * @company  SOFARSOLAR
  * @author   WN
  * @note
  * @version  V01
  * @date     2023/08/14
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "array.h"
#include "diag_manage.h"
#include "others.h"
#include "pcs.h"
#include "pcs_sequence.h"
#include "pcsc_diag.h"
#include "can1_bus.h"
#include "power_manage.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
static uint16_t  trigger_const_time_record;

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/******************************************************************************
 * others_init().
 * Initialize others module. [Called by app.]
 *
 * @param	none (I)
 * @return	none
 *****************************************************************************/
void others_init(void)
{
	trigger_const_time_record = 0;
}

/******************************************************************************
 * timing_request_pcs_const().
 * The timer 40s request constant. [Called by slow_task_others.]
 *
 * @param	none (I)
 * @return	none
 *****************************************************************************/
static void timing_request_pcs_const(void)
{
	uint8_t i;

	if(trigger_const_time_record == 400)
	{
		trigger_pcs_const = TRUE;
		trigger_const_time_record++;
	}
	else if(trigger_const_time_record < 400)
	{
		trigger_const_time_record++;
	}
	else
	{
		for(i = 0; (i < PCSM_NUMS) && (trigger_pcs_const == FALSE); i++)
		{

			// If this module is disconnected
			if(heart_pcs[i].online == FALSE)
			{
				// reset the constant receive flag bit corresponding to this module to zero
				pcs_sn_analysis_success[i] = FALSE;
			}
			// If the module is online
			else
			{
				// If the corresponding constant of the module is not received
				if(pcs_sn_analysis_success[i] == FALSE)
				{
					// request the constant again
					node_pcs_for_const = node_pcs;
					trigger_pcs_const = TRUE;
				}
			}

		}
	}
}

/******************************************************************************
 * slow_task_others().
 * slow_task_others. [Called by app.]
 *
 * @param	none (I)
 * @return	none
 *****************************************************************************/
void slow_task_others(void)
{
    delay_diag_task();
    timing_request_pcs_const();
	delay_heart_check();
	delay_planning_scheduling();
}

/******************************************************************************
* End of module
******************************************************************************/
