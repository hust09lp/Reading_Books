/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     ems.c
  * @brief    local ems module
  * @company  SOFARSOLAR
  * @author   ZZJ
  * @note
  * @version  V02
  * @date     2023/07/20
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "array.h"
#include "device.h"
#include "ems.h"
#include "pcs.h"
#include "sdk.h"
#include "fifo_can.h"
#include "common.h"
#include "math.h"
#include "can1_bus.h"
#include "setting.h"
#include "pcsc_diag.h"
#include "power_manage.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define TRANSFORMER_CAPACITY_USABLE_RATIO                                (0.95f)
#define SOC_MAINT_RETURN_DIFFERENCE                                          (2)
#define PCC_POWER_POINT()                                      (ems.pcc_power_set)
#define PURCHASE_DEADZONE                                                (-1.0f)
#define SALE_DEADZONE                                                     (1.0f)
#define AUTOMATIC_DEADZONE                                                (1.0f)
#define PURCHASE_ACTION_POINT() \
							(PCC_POWER_POINT() - (int16_t)ems.allow_purchase_power)

#define PURCHASE_ACTION_STOP_POINT_1() \
(PCC_POWER_POINT() - ((int16_t)ems.allow_purchase_power * AUTOMATIC_ADJUST_DIFF_1))

#define PURCHASE_ACTION_STOP_POINT_2() \
(PCC_POWER_POINT() - ((int16_t)ems.allow_purchase_power * AUTOMATIC_ADJUST_DIFF_2))

#define SALE_ACTION_POINT() \
								(PCC_POWER_POINT() + (int16_t)ems.allow_sale_power)

#define SALE_ACTION_STOP_POINT_1() \
	(PCC_POWER_POINT() + ((int16_t)ems.allow_sale_power * AUTOMATIC_ADJUST_DIFF_1))

#define SALE_ACTION_STOP_POINT_2() \
	(PCC_POWER_POINT() + ((int16_t)ems.allow_sale_power * AUTOMATIC_ADJUST_DIFF_2))
/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
ems_t ems;
int16_t fault_anti_backflow_cnt;
int16_t fault_anti_backflow_ref;
bool_t trigger_local_ems;
bool_t trigger_xiao_ju;
int16_t flat_power;
#if DEBUG_MODE
uint8_t my_soc = 50;
uint8_t tm_period_test = VALLEY_TM;
#endif
xiaoju_t xiao_ju;
xiaoju_ammeter_t xiaoju_ammeter;
int8_t meter_cur_dir[2];
bool_t g_trigger_close_ems;

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/
void flat_tm_chg(uint8_t current_time_period);

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/******************************************************************************
 * inter_dch_power_set()
 *  [Called by .]
 *
 * @param time_period (I)
 * @param rtc_r (I)
 * @return TRUE(is subset), FALSE(not is subset)
 *****************************************************************************/
void inter_dch_power_set(int16_t min, int16_t max)
{
	ems.inter_max_dch_power = max;
	ems.inter_min_dch_power = min;
}
/******************************************************************************
 * inter_chg_power_set()
 *  [Called by .]
 *
 * @param time_period (I)
 * @param rtc_r (I)
 * @return TRUE(is subset), FALSE(not is subset)
 *****************************************************************************/
void inter_chg_power_set(int16_t min, int16_t max)
{
	ems.inter_max_chg_power = max;
	ems.inter_min_chg_power = min;
}
/****************************************************************************
 * @name  ems_init().
 * @brief Initial EMS module. [Called by init]
 *
 * @param none   (I)
 * @param none   (O)
 * @return none
 ****************************************************************************/
void ems_init(uint8_t product_model)
{
	uint16_t offset, i;
	uint8_t ems_buff[EE_EMS_SECTOR_END];
	half_word_t tmp;
	int8_t symbol;
	bool_t cross_broader_flag = FALSE;
	int16_t *p_data_int16 = NULL;

    clear_struct_data(&ems_buff[0], sizeof(ems_buff));
	if(product_model == POWER_MAGIC_690V)
	{
		g_ems_set_table = &ems_set_table_690V[0];
	}
	else
	{
		g_ems_set_table = &ems_set_table_400V[0];
	}
	setting_get(LOCAL_EMS, EE_EMS_SECTOR_START, ems_buff, EE_EMS_SECTOR_END);
	// TODO 初始化ems数据
	ems.demand_side.enable          = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_DEMAND_ENABLE], g_ems_set_table, EE_EMS_DEMAND_ENABLE, &cross_broader_flag);
	ems.demand_side.demand_quantity = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_DEMAND_QUANTITY], g_ems_set_table, EE_EMS_DEMAND_QUANTITY, &cross_broader_flag);
	ems.demand_side.dead_band       = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_DEMAND_DEADBAND], g_ems_set_table, EE_EMS_DEMAND_DEADBAND, &cross_broader_flag);
	ems.anti_backflow.enable        = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_ANTI_ENABLE], g_ems_set_table, EE_EMS_ANTI_ENABLE, &cross_broader_flag);
	ems.allow_sale_power            = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_ALLOW_SALE_POWER], g_ems_set_table, EE_EMS_ALLOW_SALE_POWER, &cross_broader_flag);
	ems.c2d.enable                  = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_C2D_ENABLE], g_ems_set_table, EE_EMS_C2D_ENABLE, &cross_broader_flag);
	ems.allow_purchase_power        = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_ALLOW_PURCHASE_POWER], g_ems_set_table, EE_EMS_ALLOW_PURCHASE_POWER, &cross_broader_flag);
	ems.cpfv.enable                 = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_CPFV_ENABLE], g_ems_set_table, EE_EMS_CPFV_ENABLE, &cross_broader_flag);
	for(i = 0;i < EMS_TIME_PERIOD_NUM;i++)
	{
		offset = EE_EMS_TIME_PERIOD + i * EMS_TIME_PERIOD_LEN;
		ems.tm_period[i].attribute  = setting_data_constrain_uint16((uint16_t*)&ems_buff[offset], g_ems_set_table, EE_EMS_TIME_PERIOD, &cross_broader_flag);

		offset += 2;

		tmp.all = ems_buff[offset++];
		ems.tm_period[i].start_hour   = setting_data_constrain_uint16(&tmp.all, g_ems_set_table, EE_EMS_TIME_PERIOD_HOUR, &cross_broader_flag);

		tmp.all = ems_buff[offset++];
		ems.tm_period[i].start_min  = setting_data_constrain_uint16(&tmp.all, g_ems_set_table, EE_EMS_TIME_PERIOD_MIN, &cross_broader_flag);

		tmp.all = ems_buff[offset++];
		ems.tm_period[i].end_hour     = setting_data_constrain_uint16(&tmp.all, g_ems_set_table, EE_EMS_TIME_PERIOD_HOUR, &cross_broader_flag);

		tmp.all = ems_buff[offset++];
		ems.tm_period[i].end_min    = setting_data_constrain_uint16(&tmp.all, g_ems_set_table, EE_EMS_TIME_PERIOD_MIN, &cross_broader_flag);
	}
	ems.soc_max                      = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_CHG_SOC_MAX], g_ems_set_table, EE_EMS_CHG_SOC_MAX, &cross_broader_flag);
	ems.p_chg_step                   = BASE_POWER_ADJUST_STEP;
	ems.cpfv.k1                      = CHG_DCH_CONVERSION_EFFEICECNCY;
	ems.p_chgmax_theory              = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_THEORY_MAX_CHG_POWER], g_ems_set_table, EE_EMS_THEORY_MAX_CHG_POWER, &cross_broader_flag);
	ems.soc_min                      = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_DISCHG_SOC_MIN], g_ems_set_table, EE_EMS_DISCHG_SOC_MIN, &cross_broader_flag);
	ems.p_dischg_step                = BASE_POWER_ADJUST_STEP;
	ems.cpfv.k2                      = CHG_DCH_CONVERSION_EFFEICECNCY;
	ems.p_dischgmax_theory           = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_THEORY_MAX_DISCHG_POWER], g_ems_set_table, EE_EMS_THEORY_MAX_DISCHG_POWER, &cross_broader_flag);
	ems.soc_maint.enable             = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_SOC_MAINT_ENABLE], g_ems_set_table, EE_EMS_SOC_MAINT_ENABLE, &cross_broader_flag);
	ems.soc_maint.power_maint        = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_SOC_MAINT_POWER], g_ems_set_table, EE_EMS_SOC_MAINT_POWER, &cross_broader_flag);
	ems.force_control.enable         = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_FORCE_CONTROL_ENABLE], g_ems_set_table, EE_EMS_FORCE_CONTROL_ENABLE, &cross_broader_flag);
	ems.power_factor                 = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_POWER_FACTOR], g_ems_set_table, EE_EMS_POWER_FACTOR, &cross_broader_flag);
	ems.q_power_step                 = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_FORCE_CONTROL_ENABLE], g_ems_set_table, EE_EMS_FORCE_CONTROL_ENABLE, &cross_broader_flag);
	ems.rated_capacity               = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_RATED_CAPACITY], g_ems_set_table, EE_EMS_RATED_CAPACITY, &cross_broader_flag);
	ems.cpfv.early_closure_peak      = 0;
	ems.cpfv.early_closure_top       = 0;
	ems.cpfv.early_closure_valley    = 0;
	ems.pcs_advance_startup_time     = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_ADVANCE_STARTUP_TIME], g_ems_set_table, EE_EMS_ADVANCE_STARTUP_TIME, &cross_broader_flag);
	ems.pcs_standby_wait_time        = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_STANDBY_WAIT_TIME], g_ems_set_table, EE_EMS_STANDBY_WAIT_TIME, &cross_broader_flag);
	ems.pcs_stop_wait_time           = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_STOP_WAIT_TIME], g_ems_set_table, EE_EMS_STOP_WAIT_TIME, &cross_broader_flag);
	ems.automatic.enable             = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_AUTOMATIC_ENABLE], g_ems_set_table, EE_EMS_AUTOMATIC_ENABLE, &cross_broader_flag);
	ems.meter_current_direction.all  = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_METER_CUR_DIR], g_ems_set_table, EE_EMS_METER_CUR_DIR, &cross_broader_flag);
	// ems.backflow_meter_switch        = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_BACKFLOW_METER_SWITCH], g_ems_set_table, EE_EMS_BACKFLOW_METER_SWITCH, &cross_broader_flag);
	for(i = 0; i < EMS_TIME_PERIOD_NUM; i++)
	{
		offset = EE_EMS_TIME_PERIOD_POWER + i * HALF_WORD_LEN;
		p_data_int16 = (int16_t*)&ems_buff[offset];
		if((INT16_MAX == *p_data_int16) || (-1 == *p_data_int16))
		{
			ems.tm_period[i].enable_power_set = FALSE;
			ems.tm_period[i].power_ref = INT16_MAX;
		}
		else
		{
			ems.tm_period[i].enable_power_set = TRUE;
			symbol = symbol_judgment_int16(*p_data_int16);
			tmp.all = abs_int2uint(*p_data_int16);
			ems.tm_period[i].power_ref  = symbol * setting_data_constrain_uint16((uint16_t*)&tmp.all, g_ems_set_table, EE_EMS_TIME_PERIOD_POWER, &cross_broader_flag);
			ems.tm_period[i].attribute = get_attr_from_power(ems.tm_period[i].power_ref);
		}
	}
	ems.holiday_tm_enable  = setting_data_constrain_uint16((uint16_t*)&ems_buff[EE_EMS_HOLIDAY_ENABLE], g_ems_set_table, EE_EMS_HOLIDAY_ENABLE, &cross_broader_flag);
	for(i = 0;i < EMS_TIME_PERIOD_NUM;i++)
	{
		offset = EE_EMS_HOLIDAY_TIME_PERIOD + i * EMS_HOLIDAY_TIME_PERIOD_LEN;
		ems.holiday_tm_period[i].attribute  = setting_data_constrain_uint16((uint16_t*)&ems_buff[offset], g_ems_set_table, EE_EMS_HOLIDAY_TIME_PERIOD, &cross_broader_flag);
		offset += HALF_WORD_LEN;
		p_data_int16 = (int16_t*)&ems_buff[offset];
		if((INT16_MAX == *p_data_int16) || (-1 == *p_data_int16))
		{
			ems.holiday_tm_period[i].enable_power_set = FALSE;
			ems.holiday_tm_period[i].power_ref = INT16_MAX;
		}
		else
		{
			ems.holiday_tm_period[i].enable_power_set = TRUE;
			symbol = symbol_judgment_int16(*p_data_int16);
			tmp.all = abs_int2uint(*p_data_int16);
			ems.holiday_tm_period[i].power_ref  = symbol * setting_data_constrain_uint16((uint16_t*)&tmp.all, g_ems_set_table, EE_EMS_HOLIDAY_TIME_PERIOD_POWER, &cross_broader_flag);
			ems.holiday_tm_period[i].attribute = get_attr_from_power(ems.holiday_tm_period[i].power_ref);
		}
		offset += HALF_WORD_LEN;
		tmp.all = ems_buff[offset++];
		ems.holiday_tm_period[i].start_hour   = setting_data_constrain_uint16(&tmp.all, g_ems_set_table, EE_EMS_HOLIDAY_TIME_PERIOD_HOUR, &cross_broader_flag);

		tmp.all = ems_buff[offset++];
		ems.holiday_tm_period[i].start_min  = setting_data_constrain_uint16(&tmp.all, g_ems_set_table, EE_EMS_HOLIDAY_TIME_PERIOD_MIN, &cross_broader_flag);

		tmp.all = ems_buff[offset++];
		ems.holiday_tm_period[i].end_hour     = setting_data_constrain_uint16(&tmp.all, g_ems_set_table, EE_EMS_HOLIDAY_TIME_PERIOD_HOUR, &cross_broader_flag);

		tmp.all = ems_buff[offset++];
		ems.holiday_tm_period[i].end_min    = setting_data_constrain_uint16(&tmp.all, g_ems_set_table, EE_EMS_HOLIDAY_TIME_PERIOD_MIN, &cross_broader_flag);
	}
	memcpy(&ems.holiday_date[0], &ems_buff[EE_EMS_HOLIDAY_DATE], HALF_WORD_LEN * EMS_HOLIDAY_DATE_NUM);

	p_data_int16 = (int16_t*)&ems_buff[EE_EMS_PCC_POWER_SET];
	// 从eeprom首次读取时，此值为-1，需要进行初始化
	if(-1 == *p_data_int16)
	{
		ems.pcc_power_set = setting_data_restore_uint16(g_ems_set_table, EE_EMS_PCC_POWER_SET, EMS_PARM_MAX_NUM);;
	}
	else
	{
		symbol = symbol_judgment_int16(*p_data_int16);
		tmp.all = abs_int2uint(*p_data_int16);
		ems.pcc_power_set  = symbol * setting_data_constrain_uint16((uint16_t*)&tmp.all, g_ems_set_table, EE_EMS_PCC_POWER_SET, &cross_broader_flag);
	}
	meter_cur_dir[POSITIVE_DIR] = 1;
	meter_cur_dir[NEGATIVE_DIR] = -1;

	ems.cpfv.soc_change_dead = 0;
	ems.soc_actual_chg = 0xFF;
	ems.soc_actual_dch = 0xFF;
	ems.finish_chg = FALSE;

	ems.anti_backflow.mark = FALSE;
	ems.anti_backflow.power_var = 0;
	// ems.dch_exit_power = ems.p_dischgmax_theory;
	// ems.chg_exit_power = 0;

	inter_dch_power_set(0, ems.p_dischgmax_theory);
	inter_chg_power_set(0, ems.p_chgmax_theory);

	ems.c2d.mark = FALSE;
	ems.c2d.power_var = 0;

	ems.soc_maint.mark = FALSE;
	ems.soc_maint.power_var = 0;
	ems.soc_maint.upper_limit = ems.soc_max;
	ems.soc_maint.lower_limit = ems.soc_min;
	ems.soc_maint.beyond_the_limit = FALSE;
	ems.soc_maint.below_the_limit = FALSE;
	ems.soc_maint.finish_maint = FALSE;
	ems.soc_min_cmu = SOC_INVALID_VALUE;
	ems.soc_max_cmu = SOC_INVALID_VALUE;
	ems.force_control.mark = FALSE;

	ems.cpfv.last_status = INVALID;
	ems.cpfv.detect_count_set = 1; //由时基计算，时基 * value = 1分钟
	flat_power = 0;
	fault_anti_backflow_cnt = 0;
	fault_anti_backflow_ref = 4;
}

/****************************************************************************
 * @name  xiaoju_init().
 * @brief Initial xiaoju module. [Called by init]
 *
 * @param none   (I)
 * @param none   (O)
 * @return none
 ****************************************************************************/
void xiaoju_init(void)
{
	bool_t cross_broader_flag = FALSE;
	uint8_t xiaoju_buff[XIAOJU_SECTOR_END];

	clear_struct_data((uint8_t*)&xiao_ju, sizeof(xiao_ju));
	clear_struct_data((uint8_t*)&xiaoju_buff, sizeof(xiaoju_buff));
	setting_get(XIAOJU_PARM, XIAOJU_SECTOR_START, xiaoju_buff, XIAOJU_SECTOR_END);

	xiao_ju.transformer_capacity = \
						setting_data_constrain_uint32((uint32_t*)&xiaoju_buff[XIAOJU_TRANSFORMER_CAPACITY], \
														&xiaoju_setting_parm[0], \
														XIAOJU_TRANSFORMER_CAPACITY, \
														&cross_broader_flag);
	xiao_ju.ammeter3_num = \
						setting_data_constrain_uint32((uint32_t*)&xiaoju_buff[XIAOJU_METER3_NUM], \
													&xiaoju_setting_parm[0], \
														XIAOJU_METER3_NUM, \
														&cross_broader_flag);
	xiao_ju.ammeter1_num = \
						setting_data_constrain_uint32((uint32_t*)&xiaoju_buff[XIAOJU_METER1_NUM], \
													&xiaoju_setting_parm[0], \
														XIAOJU_METER1_NUM, \
														&cross_broader_flag);
	xiao_ju.ctrl_source = \
						setting_data_constrain_uint32((uint32_t*)&xiaoju_buff[XIAOJU_CTRL_SOURCE], \
													&xiaoju_setting_parm[0], \
														XIAOJU_CTRL_SOURCE, \
														&cross_broader_flag);
	// xiao_ju.ammeter2_model_switch = \
	// 					setting_data_constrain_uint32((uint32_t*)&xiaoju_buff[XIAOJU_METER2_MODEL_SWITCH], \
	// 												&xiaoju_setting_parm[0], \
	// 													XIAOJU_METER2_MODEL_SWITCH, \
	// 													&cross_broader_flag);
	// xiao_ju.ammeter3_model_switch = \
	// 					setting_data_constrain_uint32((uint32_t*)&xiaoju_buff[XIAOJU_METER3_MODEL_SWITCH], \
	// 												&xiaoju_setting_parm[0], \
	// 													XIAOJU_METER3_MODEL_SWITCH, \
	// 													&cross_broader_flag);

	clear_struct_data((uint8_t*)&xiaoju_ammeter, sizeof(xiaoju_ammeter));
}

/******************************************************************************
 * get_time_period_attr()
 * Cut peaks and fill valleys check. [Called by slow_task_power_magic.]
 *
 * @param none (I)
 * @return TRUE(success), FALSE(failure)
 *****************************************************************************/
uint8_t get_time_period_attr(tm_period_t* now_period)
{
	if(ems.cpfv.enable || ems.automatic.enable)
	{
		if((now_period->enable_power_set) && (ems.cpfv.enable))
		{
			return get_attr_from_power(now_period->power_ref);
		}
		else if(AUTOMATIC_TM == now_period->attribute)
		{
			if(ems.automatic.enable)
			{
				return AUTOMATIC_TM;
			}
			else
			{
				return FLAT_TM;
			}
		}
		else if(ems.cpfv.enable)
		{
			if (FALSE == now_period->enable_power_set)
			{
				return now_period->attribute;
			}
			else
			{
				if(0 == now_period->power_ref)
				{
					return FLAT_TM;
				}
				else if(now_period->power_ref > 0)
				{
					return PEAK_TM;
				}
				else //  if(now_period->power_ref < 0)
				{
					return VALLEY_TM;
				}
			}
		}
		else
		{
			return FLAT_TM;
		}
	}
	else
	{
		return FLAT_TM;
	}
}
/******************************************************************************
 * time_interval_judgment_1()
 * Whether rtc_r is rtc_r subset of time_period [Called by .]
 *
 * @param time_period (I)
 * @param rtc_r (I)
 * @return TRUE(is subset), FALSE(not is subset)
 *****************************************************************************/
bool_t time_interval_judgment_1(tm_period_t *time_period, sdk_rtc_t *rtc_r)
{
	bool_t result = FALSE;

	if((time_period->start_hour < rtc_r->tm_hour) && (time_period->end_hour > rtc_r->tm_hour))
	{
		result = TRUE;
	}
	else if((time_period->start_hour == rtc_r->tm_hour) && \
			(time_period->start_min <= rtc_r->tm_min) && \
			(time_period->end_hour > rtc_r->tm_hour))
	{
		result = TRUE;
	}
	else if((time_period->start_hour < rtc_r->tm_hour) && \
			(time_period->end_hour == rtc_r->tm_hour) && \
			(time_period->end_min >= rtc_r->tm_min))
	{
		result = TRUE;
	}
	else if((time_period->start_hour == rtc_r->tm_hour) && \
			(time_period->end_hour == rtc_r->tm_hour) && \
			(time_period->start_min <= rtc_r->tm_min) && \
			(time_period->end_min >= rtc_r->tm_min))
	{
		result = TRUE;
	}
	else
	{
		result = FALSE;
	}

	return result;
}

/******************************************************************************
 * time_interval_judgment_2()
 * Whether time_period2 is subset of time_period1 [Called by .]
 *
 * @param time_period1 (I)
 * @param time_period2 (I)
 * @return TRUE(is subset), FALSE(not is subset)
 *****************************************************************************/
bool_t time_interval_judgment_2(tm_period_t *time_period1, tm_period_t *time_period2)
{
	bool_t result = FALSE;

	if(((time_period1->start_hour >= time_period2->start_hour) &&
	(time_period1->start_min >= time_period2->start_min)) &&
	((time_period1->end_hour <= time_period2->end_hour) &&
	(time_period1->end_min <= time_period2->end_min)))
	{
		result = TRUE;
	}

	return result;
}
/******************************************************************************
 * 检查今天是否为节假日()
 *  [Called by .]
 *
 * @param time_period1 (I)
 * @param time_period2 (I)
 * @return TRUE(is subset), FALSE(not is subset)
 *****************************************************************************/
bool_t check_today_date(void)
{
	half_word_t today;
	uint8_t i;

	if((BIT_GET(ems.holiday_tm_enable, EMS_SATURDAY_ENABLE)) && (SATURDAY == array.csu.rtc.tm_weekday))
	{
		return TRUE;
	}
	else if((BIT_GET(ems.holiday_tm_enable, EMS_SUNDAY_ENABLE)) && (SUNDAY == array.csu.rtc.tm_weekday))
	{
		return TRUE;
	}
	else if((BIT_GET(ems.holiday_tm_enable, EMS_FESTIVAL_ENABLE)))
	{
		today.bytes.high = array.csu.rtc.tm_mon;
		today.bytes.low = array.csu.rtc.tm_day;
		for (i = 0; i < EMS_HOLIDAY_DATE_NUM; i++)
		{
			if (today.all == ems.holiday_date[i])
			{
				return TRUE;
			}
		}
	}
	else
	{
		return FALSE;
	}
	return FALSE;
}
/******************************************************************************
 * get_tm_period()
 * determine the time interval module. [Called by .]
 *
 * @param none (I)
 * @return  PEAK_TM, TOP_TM, VALLEY_TM, FLAT_TM
 *****************************************************************************/
tm_period_t get_tm_period(void)
{
	int32_t ret;
	int32_t result = FALSE;
	uint8_t i;
	sdk_rtc_t rtc_r;
	tm_period_t *p_period = ems.tm_period;
	tm_period_t now_period = {FLAT_TM, 0, 0, 0, 0, 0, 0};

	ret = sdk_rtc_get(RTC_BIN_FORMAT, &rtc_r);

	if(ret == SF_OK)
	{
		if(check_today_date())
		{
			p_period = ems.holiday_tm_period;
		}
		for(i = 0;(i < TIME_PERIOD_NUM_MAX) && (result == FALSE);i++)
		{
			result = time_interval_judgment_1(&p_period[i], &rtc_r);
			if(result != FALSE)
			{
				now_period = p_period[i];
			}
		}
	}
	else
	{
		sdk_log_i("ems get rtc err, ret = %d!\r\n",ret);
	}

	return now_period;
}

/******************************************************************************
 * get_top_within_period()
 * determine the time interval module. [Called by .]
 *
 * @param none (I)
 * @return  PEAK_TM, TOP_TM, VALLEY_TM, FLAT_TM
 *****************************************************************************/
void get_top_within_period(tm_period_t* now_period, tm_period_t* result, uint8_t *len)
{
	tm_period_t *p_tm;
	uint8_t i;
	bool_t ret;

	*len= 0;
	p_tm = ems.tm_period;
	for(i = 0; i < TIME_PERIOD_NUM_MAX; i++)
	{
		if(p_tm[i].attribute == TOP_TM)
		{
			ret = time_interval_judgment_2(&p_tm[i], now_period);
			if(ret)
			{
				result[(*len)++] = p_tm[i];
			}
		}
	}
}

/******************************************************************************
 * transfer_time_format()
 * Conversion time format. [Called by .]
 *
 * @param none (I)
 * @return
 *****************************************************************************/
void transfer_time_format(tm_period_t* tm_period_tmp, sdk_rtc_t* rtc_tmp)
{
	rtc_tmp[0].tm_hour = tm_period_tmp->start_hour;
	rtc_tmp[0].tm_min = tm_period_tmp->start_min;
	rtc_tmp[1].tm_hour = tm_period_tmp->end_hour;
	rtc_tmp[1].tm_min = tm_period_tmp->end_min;
}

/******************************************************************************
 * get_approach_period()
 * Gets the most recent rechargeable period. [Called by .]
 *
 * @param none (I)
 * @return
 *****************************************************************************/
void get_approach_period(tm_period_t* now_period, tm_period_t* result)
{
	tm_period_t *p_tm;
	uint8_t i;
	uint8_t index = 0;
	sdk_rtc_t rtc_now[2], rtc_temp[2];
	uint16_t time_gap, time_gap_min = 0xffff;

	p_tm = ems.tm_period;
	transfer_time_format(now_period, rtc_now);
	for(i = 0; i < TIME_PERIOD_NUM_MAX; i++)
	{
		if((p_tm[i].attribute == FLAT_TM) || (p_tm[i].attribute == VALLEY_TM))
		{
			transfer_time_format(&p_tm[i], rtc_temp);
			time_gap = time_difference_in_minutes(&rtc_now[1], &rtc_temp[0]);
			if(time_gap < time_gap_min)
			{
				time_gap_min = time_gap;
				index = i;
			}
		}
	}
	*result = p_tm[index];
}

/******************************************************************************
 * get_remain_top_soc()
 * Number of remaining top hours. [Called by app.]
 *
 * @param none (I)
 * @return  Number of remaining top hours
 *****************************************************************************/
uint8_t get_remain_top_soc(void)
{
	uint16_t time_gap;
	float32_t top_capacity = 0;
	uint8_t i, remain_top_soc, top_num;
	tm_period_t tm_period, remain_period, approach_period, period_temp[TIME_PERIOD_NUM_MAX];
	sdk_rtc_t time_temp[2];

	tm_period = get_tm_period();
	if(tm_period.attribute == PEAK_TM)
	{
		get_approach_period(&tm_period, &approach_period);
		remain_period.start_min = tm_period.start_min;
		remain_period.start_hour = tm_period.start_hour;
		remain_period.end_min = approach_period.start_min;
		remain_period.end_hour = approach_period.start_hour;
		get_top_within_period(&remain_period, period_temp, &top_num);
		for(i = 0; i < top_num; i++)
		{
			transfer_time_format(&period_temp[i], time_temp);
			time_gap = time_difference_in_minutes(&time_temp[0], &time_temp[1]);
			top_capacity += time_gap * absolute(ems.p_dischgmax_theory) / 60;
		}
		remain_top_soc = (ems.cpfv.k2 * top_capacity / ems.rated_capacity) * 100;
	}
	else
	{
		remain_top_soc = 0;
	}

	return remain_top_soc;
}

/******************************************************************************
 * get_top_soc()
 * Number of top soc. [Called by app.]
 *
 * @param none (I)
 * @return  Number of top soc
 *****************************************************************************/
uint8_t get_top_soc(void)
{
	uint16_t time_gap;
	float32_t top_capacity = 0;
	uint8_t i, top_soc;
	sdk_rtc_t time_temp[2];

	for(i = 0; i < TIME_PERIOD_NUM_MAX; i++)
	{
		if(ems.tm_period[i].attribute == TOP_TM)
		{
			transfer_time_format(&ems.tm_period[i], time_temp);
			time_gap = time_difference_in_minutes(&time_temp[0], &time_temp[1]);
			top_capacity += time_gap * absolute(ems.p_dischgmax_theory) * 0.00166667f;
		}
	}
	top_soc = (ems.cpfv.k2 * top_capacity / ems.rated_capacity);

	return top_soc;
}

/******************************************************************************
 * demand_side_check()
 * demand side check. [Called by fast_task_local_ems().]
 *
 * @param none (I)
 * @return SF_OK(success), SF_ERR_NDEF(failure)
 *****************************************************************************/
bool_t demand_side_check(void)
{
	bool_t ret;
	demand_side_t *demand_side;

	demand_side = &ems.demand_side;

	// TODO & 有效需求侧指令
	if(demand_side->enable == TRUE)
	{
		ret = TRUE;
	}
	else
	{
		ret = FALSE;
		demand_side->mark = FALSE;
		demand_side->power_var = 0;
	}
	debug_info_data.check_flag[DEBUG_USE_DEMAND_SIDE] = ret;

	return ret;
}

/******************************************************************************
 * demand_side_calc()
 * demand side calc. [Called by fast_task_local_ems().]
 *
 * @param none (I)
 * @return none.
 *****************************************************************************/
void demand_side_calc(void)
{
	int16_t tmp;
	int16_t p_target_demand;

#if SOLAR
	// IF 白天时间段 & 光伏处于限功率状态
		// 将逆变器运行模式调至最大功率跟踪模式
	// ELIF
		// 调节储能
#else
	p_target_demand = ems.demand_side.demand_quantity - ems.ammeter.power_down - \
														ems.last_target_power;
	tmp = ems.demand_side.dead_band;
	if((p_target_demand < tmp) && (p_target_demand > -tmp))
	{
		ems.demand_side.power_var = 0;
		// 关闭需求侧有效指令
	}
	else
	{
		if(p_target_demand > ems.demand_side.step)
		{
			ems.demand_side.power_var = ems.demand_side.step;
		}
		else
		{
			ems.demand_side.power_var = p_target_demand;
		}
	}
#endif
}

/******************************************************************************
 * anti_backflow_check()
 * anti reflux check. [Called by slow_task_power_magic.]
 *
 * @param none (I)
 * @return SF_OK(success), SF_ERR_NDEF(failure)
 *****************************************************************************/
bool_t anti_backflow_check(void)
{
	bool_t ret;
	anti_backflow_t *anti_backflow;
	bool_t anti_backflow_flag = FALSE;

	anti_backflow = &ems.anti_backflow;
	// anti_backflow fault diagnosis and anti_backflow actions must be consistent
	trigger_anti_backflow_diag = anti_backflow->mark;
	// Enable when the power is greater than the dead limit
	// Disable when the power is less than half of the dead limit
	if(((anti_backflow->mark == FALSE) && (ems.ammeter.power_up > ems.allow_sale_power)) || \
		((anti_backflow->mark == TRUE) && (ems.ammeter.power_up > (ems.allow_sale_power * 0.5))))
	{
		anti_backflow_flag = TRUE;
	}
	else
	{
		// When turning off anti_backflow, record the current power
		if(anti_backflow->mark == TRUE)
		{
			// charge
			if(ems.last_target_power < 0)
			{
				// 退出防逆流时，当前处于充电状态
				// ems.dch_exit_power = 0;
				// ems.chg_exit_power = absolute(array.pcsc.pcsc_ctrl.active_power_ref);
				// 限制最大放电功率
				ems.inter_max_dch_power = 0;
				// 记录最小充电功率用作限制
				ems.inter_min_chg_power = absolute(array.pcsc.pcsc_ctrl.active_power_ref);
			}
			else
			{
				// 退出防逆流时，当前处于放电状态
				// ems.dch_exit_power = absolute(array.pcsc.pcsc_ctrl.active_power_ref);
				// ems.chg_exit_power = 0;
				// 记录最大充电功率用作限制
				ems.inter_max_dch_power = absolute(array.pcsc.pcsc_ctrl.active_power_ref);
				// 不限制最小充电功率
				ems.inter_min_chg_power = 0;
			}
		}
		anti_backflow_flag = FALSE;
	}

	// anti_backflow off or now buy power greater than the threshold, do not limit the discharge power
	if(anti_backflow->enable == FALSE)
	{
		// 关闭防逆流功能时
		fault_anti_backflow = FALSE;
		// 不限制最大放电功率
		ems.inter_max_dch_power = ems.p_dischgmax_theory;
		// 不限制最小充电功率
		ems.inter_min_chg_power = 0;
		// ems.dch_exit_power = ems.p_dischgmax_theory;
		// ems.chg_exit_power = 0;
	}
	else if(ems.ammeter.power_down > 10)
	{
		// 不限制最大放电功率
		ems.inter_max_dch_power = ems.p_dischgmax_theory;
		// 不限制最小充电功率
		ems.inter_min_chg_power = 0;
	}

	if((anti_backflow->enable) && (anti_backflow_flag))
	{
		ret = TRUE;
	}
	else
	{
		ret = FALSE;
		anti_backflow->mark = FALSE;
		anti_backflow->power_var = 0;
		fault_anti_backflow_cnt = 0;
	}
	debug_info_data.check_flag[DEBUG_USE_ANTI_BACKFLOW] = ret;

	return ret;
}

/******************************************************************************
 * anti_backflow_calc()
 * anti reflux calculate. [Called by slow_task_power_magic.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void anti_backflow_calc(void)
{
	anti_backflow_t *anti_backflow;
	int32_t tmp;

	anti_backflow = &ems.anti_backflow;
	int16_t step = ems.p_dischg_step;

	anti_backflow->mark = TRUE;

	// Power value to be adjusted
	tmp = ems.ammeter.power_up - ems.allow_sale_power;
	// When the power is greater than the dead zone, the power gradually changes to the dead zone value
	if(ems.ammeter.power_up > ems.allow_sale_power)
	{
		// 减小功率
		anti_backflow->power_var = -min(tmp, step);
	}
	// If the on-grid power is less than the dead zone
	// adjust the step to gradually change the power to half of the dead zone value
	else
	{
		step = ems.allow_sale_power / 3;
		tmp = (int32_t)absolute(ems.ammeter.power_up);
		anti_backflow->power_var = -min_three_argu(step, \
													ems.p_dischg_step, \
													tmp);
	}
	// offset 0.1KW
	anti_backflow->power_var -= 1;
	// if charge and charge power greater than rate power

	if((ems.last_target_power < 0) && (abs_int2uint(ems.last_target_power) > array.csu.csu_data.csu_const.rat_power_p_total))
	{
		if(fault_anti_backflow_cnt <= fault_anti_backflow_ref)
		{
			fault_anti_backflow_cnt++;
		}
	}
}
/******************************************************************************
 * automatic_check()
 * Spontaneous self use mode check. [Called by slow_task_power_magic.]
 *
 * @param none (I)
 * @return SF_OK(success), SF_ERR_NDEF(failure)
 *****************************************************************************/
bool_t automatic_check(void)
{
	bool_t ret = FALSE;
	bool_t automatic_flag = TRUE;
	static uint8_t automatic_act_flag = FALSE;
	float32_t power_offset;

	power_offset = ems.ammeter.power - PCC_POWER_POINT();

	ems.now_period = get_tm_period();
	// 打开防逆流电表后
	if(TRUE == trigger_backflow_meter)
	{
		// 如果没有故障
		if(FALSE == fault_backflow_meter)
		{
			// 当前处于自动模式时段，判断当前是否需要或能否调节功率
			if(AUTOMATIC_TM == get_time_period_attr(&ems.now_period))
			{
				automatic_act_flag = TRUE;
				// 当前处于SOC维护时段，判断当前是否需要或能否调节功率
				if(ems.soc_maint.mark)
				{
					// 如果当前买点功率大于允许买电功率
					if(ems.ammeter.power < PURCHASE_ACTION_POINT())
					{
						// 电池充电功率大于等于SOC维护功率，需要调节功率
						if(ems.last_target_power < -ems.soc_maint.power_maint)
						{
							automatic_flag = TRUE;
						}
						// 电池充电功率小于SOC维护功率，不需要调节功率
						else
						{
							automatic_flag = FALSE;
						}
					}
					// 如果有上网功率，结束SOC维护，转为自动模式进行充电(这个时候不管允许上网功率是多少，只要有，就充电)
					else if(ems.ammeter.power > PCC_POWER_POINT())
					{
						automatic_flag = TRUE;
					} 
				}
				// 如果储能现在放电，并且买电功率小于允许值，清除储能功率
				else if((array.pcsc.pcsc_ctrl.active_power_ref > 0) && (ems.ammeter.power > PURCHASE_ACTION_STOP_POINT_1()))
				{
					automatic_flag = TRUE;
				}
				// 判断是否满足退出自动模式的条件
				// 1：关口表功率小于死区
				else if((absolute(power_offset) <= AUTOMATIC_DEADZONE) || \
					// 2: 关口表功率小于允许买电功率
					((ems.ammeter.power < PCC_POWER_POINT()) && (ems.ammeter.power > PURCHASE_ACTION_POINT()) && (symbol_judgment_int16(ems.last_target_power) != symbol_judgment_int16(power_offset))) || \
					// 3: 关口表功率小于允许卖电功率
					((ems.ammeter.power > PCC_POWER_POINT()) && (ems.ammeter.power < SALE_ACTION_POINT())) || \
					// 4：有买电功率，需要放电，但是可放电的cmu数量为0，并且现在系统设定功率等于0（需清除功率）
					((power_offset < PURCHASE_DEADZONE) && (0 == g_redischargeable_num) && (ems.last_target_power == 0)) || \
					// 5：有上网功率，需要充电，但是可充电的cmu数量为0，并且现在系统设定功率等于0（需清除功率）
					((power_offset > SALE_DEADZONE) && (0 == g_rechargeable_num) && (ems.last_target_power == 0)))
				{
					automatic_flag = FALSE;
				}
				else
				{
					automatic_flag = TRUE;
				}
			}
			else
			{
				// 如果上一时刻自动模式动作，但现在功率是0，并且当前不是自动模式的时间，则退出自动模式
				// 此条件适用于自动模式结束后，清除功率值
				if(ems.automatic.mark || automatic_act_flag)
				{
					if(0 == ems.last_target_power)
					{
						automatic_act_flag = FALSE;
						automatic_flag = FALSE;
					}
				}
				else
				{
					automatic_flag = FALSE;
				}
//				if((0 == ems.last_target_power) && (ems.automatic.mark))
//				{
//					automatic_flag = FALSE;
//				}
			}
		}
		//如果防逆流电表故障，且当前总功率为0，则不进入自动模式
		else if(array.pcsc.pcsc_ctrl.active_power_ref == 0)
		{
			automatic_flag = FALSE;
		}
		// 如果防逆流电表故障，但现在不是自动模式时间段，则退出
		else if(AUTOMATIC_TM != get_time_period_attr(&ems.now_period))
		{
			automatic_flag = FALSE;
		}
		else{}
	}
	// 如果没有开启防逆流电表，不进入自动模式
	else
	{
		automatic_flag = FALSE;
	}
	// 满足进入条件并且使能
	if(automatic_flag && ems.automatic.enable)
	{
		ret = TRUE;
	}
	else
	{
		ret = FALSE;
		ems.automatic.mark = FALSE;
		ems.automatic.power_var = 0;
	}
	debug_info_data.check_flag[DEBUG_USE_AUTOMATIC] = ret;
	return ret;
}

/******************************************************************************
 * automatic_calc()
 * Spontaneous self use mode calc. [Called by slow_task_power_magic.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void automatic_calc(void)
{
	automatic_t *automatic_ptr;
	uint16_t tmp;

	automatic_ptr = &ems.automatic;

	automatic_ptr->mark = TRUE;
	// 防逆流电表故障或当前不是自动模式时，清除功率
	// 如果储能现在放电，并且买电功率小于允许值，清除储能功率
	if((fault_backflow_meter) || \
		(get_time_period_attr(&ems.now_period) != AUTOMATIC_TM) || \
		((array.pcsc.pcsc_ctrl.active_power_ref > 0) && (ems.ammeter.power > PURCHASE_ACTION_STOP_POINT_1())))
	{
		// 现在处于充电
		if(ems.last_target_power < 0)
		{
			automatic_ptr->power_var = min(-ems.last_target_power, ems.p_chg_step);
		}
		else
		{
			automatic_ptr->power_var = -min(ems.last_target_power, ems.p_dischg_step);
		}
	}
	// 自动模式正常工作
	else
	{
		// 有上网功率
		if(ems.ammeter.power > PCC_POWER_POINT())
		{
			// 计算需要减小功率，并增加一些的偏移，例如允许上网功率为1KW，当前上网功率为2KW，则目标调节为0.9KW
			if(ems.ammeter.power > SALE_ACTION_POINT())
			{
				tmp = ems.ammeter.power - SALE_ACTION_STOP_POINT_2();
			}
			else
			{
				tmp = ems.ammeter.power - PCC_POWER_POINT();
			}
			automatic_ptr->power_var = -min(tmp, ems.p_chg_step);
		}
		// 有买电功率
		else
		{
			// 计算需要增加功率，并增加一些的偏移，例如允许买电功率为1KW，当前买电功率为2KW，则目标调节为买电功率0.9KW
			// 允许买电功率为20KW，当前买电功率为30KW，则目标调节为买电功率16KW
			if(ems.ammeter.power < PURCHASE_ACTION_POINT())
			{
				tmp = PURCHASE_ACTION_STOP_POINT_2() - ems.ammeter.power;
			}
			else
			{
				tmp = PCC_POWER_POINT() - ems.ammeter.power;
			}
			automatic_ptr->power_var = min(tmp, ems.p_dischg_step);
		}
	}
}
/******************************************************************************
 * c2d_check()
 * capacity to demand check. [Called by slow_task_power_magic.]
 *
 * @param none (I)
 * @return TRUE(success), FALSE(failure)
 *****************************************************************************/
bool_t c2d_check(void)
{
	bool_t ret;
	static uint8_t count = 0;
	float32_t scale;

	if(ems.c2d.mark)
	{
		scale = 0.8;
	}
	else
	{
		scale = 0.9;
	}
	if(ems.ammeter.power_down > (scale * PURCHASE_ACTION_POINT()))
	{
		if(count <= 4)
		{
			count++;
		}
	}
	else
	{
		count = 0;
	}
	if(FALSE == ems.c2d.enable)
	{
		ret = FALSE;
		ems.c2d.mark = FALSE;
		ems.c2d.power_var = 0;
		ems.inter_min_dch_power = 0;
	}
	else
	{
		if(count >= 4)
		{
			ret = TRUE;
		}
		else
		{
			ret = FALSE;
			ems.c2d.mark = FALSE;
			ems.c2d.power_var = 0;
		}
	}
	if(ems.ammeter.power_down < ( 0.75 * PURCHASE_ACTION_POINT()))
	{
		ems.inter_min_dch_power = 0;
	}
	debug_info_data.check_flag[DEBUG_USE_C2D] = ret;

	return ret;
}

/******************************************************************************
 * c2d_calc()
 * capacity to demand calc. [Called by slow_task_power_magic.]
 *
 * @param none (I)
 * @return none.
 *****************************************************************************/
void c2d_calc(void)
{
	int16_t tmp;
	c2d_t *c2d;

	c2d = &ems.c2d;

	if(c2d->mark == FALSE)
	{
		tmp = PURCHASE_ACTION_POINT() * 0.9f;
		// 买电功率大于0.9倍需量时，放电补充
		if(ems.ammeter.power_down < tmp)
		{
			c2d->mark = FALSE;
			c2d->power_var = 0;
		}
		else
		{
			c2d->mark = TRUE;
#if SOFAR
			// IF 白天时间段 & 光伏处于限功率状态
				// 调节逆变器运行状态为最大功率跟踪模式
				// c2d->power_var = 0;
			// ELSE
				c2d->power_var = -ems.step;
#else
			c2d->power_var = ems.p_dischg_step;
#endif
		}
	}
	else
	{
		tmp = ems.allow_purchase_power * 0.8f;
		if(ems.ammeter.power_down > (tmp))
		{
			c2d->power_var = ems.p_dischg_step;
		}
		// 需要停止
		else
		{
			c2d->mark = FALSE;
			c2d->power_var = 0;
		}
	}
}

/******************************************************************************
 * cpfv_check()
 * Cut peaks and fill valleys check. [Called by slow_task_power_magic.]
 *
 * @param none (I)
 * @return TRUE(success), FALSE(failure)
 *****************************************************************************/
bool_t cpfv_check(void)
{
	bool_t ret = FALSE;
	bool_t soc_check = FALSE;
	uint8_t attr;

	if(ems.cpfv.enable == TRUE)
	{
		ems.now_period = get_tm_period();
		attr = get_time_period_attr(&ems.now_period);
		if((attr == PEAK_TM) || (attr == TOP_TM))
		{
			check_uint8_validity(ems.soc_actual_dch, 0, 100, &soc_check);
		}
		else if(attr == VALLEY_TM)
		{
			check_uint8_validity(ems.soc_actual_chg, 0, 100, &soc_check);
		}
		else{}
		// If the battery soc is within legal limits
		if((attr != FLAT_TM) && soc_check)
		{
			ret = TRUE;
		}
		else if(attr == FLAT_TM)
		{
			flat_tm_chg(FLAT_TM);
		}
	}
	else
	{
		ret = FALSE;
		ems.cpfv.power_var = 0;
		ems.cpfv.mark = FALSE;
	}
	debug_info_data.check_flag[DEBUG_USE_CPFV] = attr;
	return ret;
}

/******************************************************************************
 * valley_tm_chg()
 * Valley period charging strategy. [Called by cpfv_calc().]
 *
 * @param current_time_period (I) current time period
 * @return none.
 *****************************************************************************/
void valley_tm_chg(uint8_t current_time_period)
{
	uint8_t soc_actual = 0;
	int16_t p_ess_real = ems.last_target_power;
	int16_t tmp;
	cpfv_t *cpfv;
	sdk_rtc_t time_now, time_temp[2];
	uint16_t time_gap;
	int8_t symbol;

	soc_actual = ems.soc_actual_chg;

	cpfv = &ems.cpfv;
	sdk_rtc_get(RTC_BIN_FORMAT, &time_now);

	transfer_time_format(&ems.now_period, time_temp);
	time_gap = time_difference_in_minutes(&time_now, &time_temp[1]);
	// Enter the valley for the first time
	if(cpfv->last_status != current_time_period)
	{
		ems.finish_chg = FALSE;
		// Record the SOC that started charging
		// Charge only when the actual SOC is less than the maximum SOC
		cpfv->soc_chg_start = soc_actual;
		tmp = ems.soc_max - cpfv->soc_chg_start;
		if((tmp > 0) && (time_gap > cpfv->early_closure_valley))
		{
			if(ems.now_period.enable_power_set)
			{
				cpfv->p_chgmax_real = min(ems.p_chgmax_theory, abs_int2uint(ems.now_period.power_ref));
			}
			else
			{
				// Calculate the recommended maximum charging power
				// The actual charging power is the recommended maximum charging power and the theoretical maximum charging power
				cpfv->p_chgmax_sug = cpfv->k1 * tmp * (ems.rated_capacity) / time_gap * PARAMETER_ACCURACY_MAGNIFICATION_2 * 60;
				cpfv->p_chgmax_real = min(cpfv->p_chgmax_sug, ems.p_chgmax_theory);
			}
			// What time period is the record in
			cpfv->mark = TRUE;
			cpfv->last_status = current_time_period;
		}
		else
		{
			// If the actual SOC is greater than the maximum SOC, no action is taken
			cpfv->mark = FALSE;
		}
	}
	else
	{
		// action
		if(cpfv->mark == TRUE)
		{
			if(ems.soc_max > soc_actual)
			{
				// Determine how long it's over
				if(time_gap <= cpfv->early_closure_valley)
				{
					ems.finish_chg = TRUE;
				}
			}
			else
			{
				ems.finish_chg = TRUE;
			}
		}
	}

	if(ems.finish_chg)
	{
		symbol = symbol_judgment_int16(p_ess_real);
		cpfv->power_var = -1 * symbol * min(ems.p_chg_step, abs_int2uint(p_ess_real));
		if (p_ess_real == 0)
		{
			cpfv->mark = FALSE;
			cpfv->power_var = 0;
			cpfv->last_status = INVALID;
			ems.finish_chg = FALSE;
		}
	}
	else
	{
		tmp = cpfv->p_chgmax_real;
		constrain_int16_t_data(&tmp, ems.inter_min_chg_power, ems.inter_max_chg_power);
		tmp = -tmp - p_ess_real;
		if(tmp > 0)
		{
			cpfv->power_var = min(ems.p_chg_step, tmp);
		}
		else
		{
			cpfv->power_var = -min(ems.p_chg_step, -tmp);
		}
	}
}

/******************************************************************************
 * recover_flat_power()
 * recover flat power module. [Called by fast_task_local_ems().]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void recover_flat_power(int16_t power_flat)
{
	int16_t step;
	int16_t power_gap;

	ems.cpfv.mark = TRUE;

	if (ems.last_target_power > power_flat)
	{
		step = 250;
		power_gap = ems.last_target_power - power_flat;
		ems.cpfv.power_var = -min(step, power_gap);
	}
	else if(ems.last_target_power < power_flat)
	{
		step = 250;
		power_gap = absolute(power_flat - ems.last_target_power);
		ems.cpfv.power_var = min(step, power_gap);
	}
	else if(ems.last_target_power == power_flat)
	{
		ems.cpfv.last_status = FLAT_TM;
	}
}

/******************************************************************************
 * flat_tm_chg()
 * flat period charging strategy. [Called by cpfv_calc().]
 *
 * @param current_time_period (I) current time period
 * @return none.
 *****************************************************************************/
void flat_tm_chg(uint8_t current_time_period)
{
	cpfv_t *cpfv;

	cpfv = &ems.cpfv;
	cpfv->mark = FALSE;
	cpfv->power_var = 0;
	// Switching from another time slot to a normal time slot
	if(cpfv->last_status != FLAT_TM)
	{
		recover_flat_power(flat_power);
	}
	else
	{
		flat_power = 0;
	}
}

/******************************************************************************
 * peak_tm_dischg()
 * peak period discharging strategy. [Called by cpfv_calc().]
 *
 * @param current_time_period (I) current time period
 * @return none.
 *****************************************************************************/
void peak_tm_dischg(uint8_t current_time_period)
{
	uint8_t soc_actual = 0;
	int16_t p_ess_real = ems.last_target_power;
	cpfv_t *cpfv;
	int16_t tmp;
	sdk_rtc_t time_now, time_temp[2];
	uint16_t time_gap;
	int16_t time_dead_band;
	int8_t symbol;

	soc_actual = ems.soc_actual_dch;
#if DEBUG_MODE
	my_soc--;
	soc_actual = my_soc;
#endif

	cpfv = &ems.cpfv;
	sdk_rtc_get(RTC_BIN_FORMAT, &time_now);

	transfer_time_format(&ems.now_period, time_temp);
	time_gap = time_difference_in_minutes(&time_now, &time_temp[1]);
	if(current_time_period == PEAK_TM)
	{
		// Calculate the soc required during peak hours
		cpfv->remain_top_soc = get_top_soc();
		time_dead_band = cpfv->early_closure_peak;
	}
	else
	{
		cpfv->remain_top_soc = 0;
		time_dead_band = cpfv->early_closure_top;
	}
	// Enter peak (peak) period for the first time
	// Record the SOC that starts discharging
	if(cpfv->last_status != current_time_period)
	{
		ems.finish_dischg = FALSE;
		cpfv->soc_dischg_start = soc_actual;
		// Reserve SOC needed during peak hours
		tmp = cpfv->soc_dischg_start - (ems.soc_min + cpfv->remain_top_soc);
		// Discharge only when the actual SOC is greater than the maximum SOC
		if((tmp > 0) && (ems.inter_max_dch_power != 0) && (time_gap > time_dead_band))
		{
			if(ems.now_period.enable_power_set)
			{
				cpfv->p_dischgmax_real = min(ems.p_dischgmax_theory, abs_int2uint(ems.now_period.power_ref));
			}
			else
			{
				// The SOC value of the discharge is also required
				// The actual discharge power is the minimum of the recommended maximum discharge power and the theoretical maximum discharge power
				cpfv->p_dischgmax_sug = cpfv->k1 * tmp * (ems.rated_capacity) / time_gap * PARAMETER_ACCURACY_MAGNIFICATION_2 * 60;
				cpfv->p_dischgmax_real = min(cpfv->p_dischgmax_sug, ems.p_dischgmax_theory);
			}
			// What time period is the record in
			cpfv->mark = TRUE;
			cpfv->last_status = current_time_period;
		}
		// If the actual SOC is less than the minimum SOC, no action is taken
		else
		{
			ems.finish_dischg = TRUE;
		}
	}
	else
	{
		// action
		if(cpfv->mark == TRUE)
		{
			if(ems.soc_min < soc_actual)
			{
				// Determine how long it's over
				if(time_gap <= time_dead_band)
				{
					ems.finish_dischg = TRUE;
				}
			}
			else
			{
				ems.finish_dischg = TRUE;
			}
		}
	}

	if(ems.finish_dischg)
	{
		symbol = symbol_judgment_int16(p_ess_real);
		cpfv->power_var = -1 * symbol * min(ems.p_dischg_step, abs_int2uint(p_ess_real));
		if (p_ess_real == 0)
		{
			cpfv->mark = FALSE;
			cpfv->power_var = 0;
			cpfv->last_status = INVALID;
			ems.finish_dischg = FALSE;
		}
	}
	else
	{
		// The limiting power is less than the counter-current exit power
		tmp = cpfv->p_dischgmax_real;
		constrain_int16_t_data(&tmp, ems.inter_min_dch_power, ems.inter_max_dch_power);
		tmp -= p_ess_real;
		if(tmp > 0)
		{
			cpfv->power_var = min(ems.p_dischg_step, tmp);
		}
		else
		{
			cpfv->power_var = -min(ems.p_dischg_step, -tmp);
		}
	}
}

/******************************************************************************
 * cpfv_calc()
 * Cut peaks and fill valleys calc. [Called by fast_task_local_ems().]
 *
 * @param none (I)
 * @return none.
 *****************************************************************************/
void cpfv_calc(void)
{
	switch (get_time_period_attr(&ems.now_period))
	{
		case VALLEY_TM:
			valley_tm_chg(VALLEY_TM);
			break;
		case PEAK_TM:
			peak_tm_dischg(PEAK_TM);
			break;
		case TOP_TM:
			peak_tm_dischg(TOP_TM);
			break;
		default:
			break;
	}
}

/******************************************************************************
 * soc_maint_check()
 * Soc maintenance check. [Called by slow_task_power_magic.]
 *
 * @param none (I)
 * @return SF_OK(success), SF_ERR_NDEF(failure)
 *****************************************************************************/
bool_t soc_maint_check(void)
{
	bool_t ret = FALSE;
	soc_maint_t *soc_maint;
	uint8_t attr;

	ems.now_period = get_tm_period();
	if(ems.automatic.enable || ems.cpfv.enable)
	{
		attr = get_time_period_attr(&ems.now_period);
	}
	else
	{
		attr = FLAT_TM;
	}

	soc_maint = &ems.soc_maint;
	if (soc_maint->enable == TRUE)
	{
		if(attr != AUTOMATIC_TM)
		{
			if(attr == FLAT_TM)
			{
				// High soc maintenance
				if((ems.soc_max_cmu > soc_maint->upper_limit) && (0 != g_redischargeable_num))
				{
					soc_maint->beyond_the_limit = TRUE;
					soc_maint->below_the_limit = FALSE;
					ret = TRUE;
				}
				// Low soc maintenance
				else if((ems.soc_min_cmu < soc_maint->lower_limit) && (0 != g_rechargeable_num))
				{
					soc_maint->beyond_the_limit = FALSE;
					soc_maint->below_the_limit = TRUE;
					ret = TRUE;
				}
				// Prepare to shut down when soc maintenance is not required
				else if(soc_maint->mark)
				{
					soc_maint->finish_maint = TRUE;
					ret = TRUE;
				}
			}
		}
		else
		{
			// Low soc maintenance
			if((soc_maint->lower_limit >= SOC_MAINT_RETURN_DIFFERENCE) && (0 != g_rechargeable_num))
			{
				// 当前没有功率的时候才会进行SOC维护
				if(ems.soc_min_cmu <= (soc_maint->lower_limit - SOC_MAINT_RETURN_DIFFERENCE) && (ems.last_target_power == 0))
				{
					soc_maint->beyond_the_limit = FALSE;
					soc_maint->below_the_limit = TRUE;
					ret = TRUE;
				}
				// Prepare to shut down when soc maintenance is not required
				else if((soc_maint->mark) && (ems.soc_min_cmu >= soc_maint->lower_limit))
				{
					soc_maint->finish_maint = TRUE;
					ret = TRUE;
				}
				else
				{
					ret = soc_maint->mark;
				}
			}
		}
	}

	if(ret == FALSE)
	{
		soc_maint->mark = FALSE;
		soc_maint->power_var = 0;
	}
	else
	{
		soc_maint->mark = TRUE;
	}
	debug_info_data.check_flag[DEBUG_USE_SOC_MAINT] = ret;

	return ret;
}

/******************************************************************************
 * soc_maintenance()
 * Soc maintenancec. [Called by fast_task_local_ems().]
 *
 * @param none (I)
 * @return none.
 *****************************************************************************/
void soc_maintenance(void)
{
	soc_maint_t *soc_maint;
	int16_t power_gap;
	int8_t  power_symbol;
	int16_t power_maint = 0;

	soc_maint = &ems.soc_maint;

	// Determine the direction of power change
	if(soc_maint->beyond_the_limit)
	{
		power_symbol = -1;
		soc_maint->power_step = ems.p_dischg_step;
	}
	else
	{
		power_symbol = 1;
		soc_maint->power_step = ems.p_chg_step;
	}

	if (soc_maint->finish_maint)
	{
		// Prepare to end maintenance
		power_gap = abs(ems.last_target_power);
		if (ems.last_target_power == 0)
		{
			soc_maint->beyond_the_limit = FALSE;
			soc_maint->below_the_limit = FALSE;
			soc_maint->finish_maint = FALSE;
			soc_maint->mark = FALSE;
		}
	}
	else
	{
		// SOC过高
		if(soc_maint->beyond_the_limit)
		{
			// 维护功率取最大放电功率与最小放电功率的区间值，并将符号设置为放电符号
			power_maint = soc_maint->power_maint;
			constrain_int16_t_data(&power_maint, ems.inter_min_dch_power, ems.inter_max_dch_power);
		}
		// SOC过低
		else
		{
			// 维护功率取最小充电功率与设定维护功率的最小值，并将符号设置为充电符号
			power_maint = soc_maint->power_maint;
			constrain_int16_t_data(&power_maint, ems.inter_min_chg_power, ems.inter_max_chg_power);
			power_maint = -power_maint;
		}
		// 目标功率和当前功率之间的差值
		power_gap = power_maint - ems.last_target_power;
		// 当前值大于目标值，需要减小
		if(power_gap < 0)
		{
			power_symbol = -1;
		}
		// 当前值小于目标值，需要增大
		else
		{
			power_symbol = 1;
		}
	}

	power_gap = (int16_t)abs(power_gap);
	soc_maint->power_var = power_symbol * min(power_gap, soc_maint->power_step);

}

/******************************************************************************
 * force_control_check()
 * force control check. [Called by fast_task_local_ems.]
 *
 * @param none (I)
 * @return SF_OK(success), SF_ERR_NDEF(failure)
 *****************************************************************************/
bool_t force_control_check(void)
{
	bool_t ret = FALSE;
	force_control_t *force_control;
	int8_t power_factor;
	int16_t power;

	force_control = &ems.force_control;
	power = absolute(ems.last_target_power);
	if ((force_control->enable == TRUE) && (power > 100))
	{
		power_factor = absolute(ems.ammeter.power_factor);
		if((power_factor < FORCE_CONTROL_THRESHOLD) && (force_control->mark == FALSE))
		{
			ret = TRUE;
		}
		else if((power_factor > force_control->power_factor_threshold) && \
				(force_control->mark == TRUE))
		{
			ret = FALSE;
		}
	}

	if(ret == FALSE)
	{
		force_control->mark = FALSE;
		force_control->power_var = 0;
	}
	else if(ret == TRUE)
	{
		force_control->mark = TRUE;
	}
	return ret;
}

/******************************************************************************
 * force_control()
 * force control. [Called by fast_task_local_ems().]
 *
 * @param none (I)
 * @return none.
 *****************************************************************************/
void force_control(void)
{
	force_control_t *force_control;
	float32_t power_q_target;
	int16_t power_p = ems.last_target_power;
	int16_t power_q = ems.ammeter.power_q;
	int16_t power_factor = ems.ammeter.power_factor;
	float32_t power_gap;
	int8_t power_symbol;

	force_control = &ems.force_control;
	power_q_target = sqrt(((power_p / power_factor) * (power_p / power_factor)) - \
							(power_p * power_p)) - \
					sqrt(((power_p / force_control->power_factor_threshold) *
							(power_p / force_control->power_factor_threshold)) - \
							(power_p * power_p));
	power_gap = sqrt((array.csu.csu_data.csu_const.rat_power_p_total *
				array.csu.csu_data.csu_const.rat_power_p_total) -
				(power_p * power_p)) - power_q;
	if (power_factor > 0)
	{
		power_symbol = -1;
	}
	else
	{
		power_symbol = 1;
	}

	force_control->power_var = power_symbol * min_three_argu(ems.q_power_step, power_gap, power_q_target);
}

/******************************************************************************
 * power_p_check()
 * Power Check module. [Called by fast_task_local_ems().]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
bool_t power_p_check(int16_t *power_target)
{
	bool_t ret = FALSE;
	uint8_t id;
	uint8_t check_flag = FALSE;

	if((FALSE == ems.anti_backflow.mark) && \
		(FALSE == ems.automatic.mark)    && \
		(FALSE == ems.soc_maint.mark)    && \
		(FALSE == ems.c2d.mark)          && \
		(FALSE == ems.cpfv.mark))
	{
		return ret;
	}
	constrain_int16_t_data(power_target,\
						-ems.p_chgmax_theory, \
						ems.p_dischgmax_theory);
	for (id = 0; (id < CMU_NUMS) && (FALSE == check_flag); id++)
	{
		if(((*power_target < 0) && (chg_status_check(id))) || \
			((*power_target > 0) && (dch_status_check(id))))
		{
			check_flag = TRUE;
		}
	}

	if(FALSE == check_flag)
	{
		*power_target = 0;
		ret = TRUE;
	}
	else if(*power_target != array.pcsc.pcsc_ctrl.active_power_ref)
	{
		ret = TRUE;
	}
	else
	{}
	return ret;
}

/******************************************************************************
 * power_q_check()
 * Power Check module. [Called by fast_task_local_ems().]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
bool_t power_q_check(int16_t *power_target)
{
	return FALSE;
}

/******************************************************************************
 * fast_task_power_magic()
 * Power Magic module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void fast_task_local_ems(void)
{
	int16_t target_power_p = 0;
	int16_t target_power_q = 0;
	pcsm_cmd_t can_cmd_temp;
	bool_t valid_p, valid_q;

	can_cmd_temp.fun_code = PCS_CMD_SET_PARAMETER;
	can_cmd_temp.len = 1;
	// Positive values correspond to charging and negative values to discharge
	ems.last_target_power = array.pcsc.pcsc_ctrl.active_power_ref;
	ems.last_target_power_q = array.pcsc.pcsc_ctrl.reactive_power_ref;

	// TODO:
	if(demand_side_check() == TRUE)
	{
		demand_side_calc();
	}
	else if(anti_backflow_check() == TRUE)
	{
		anti_backflow_calc();
		// If the clipping is causing countercurrent, turn off the clipping
		if(ems.cpfv.mark == TRUE)
		{
			ems.cpfv.mark = FALSE;
			ems.cpfv.last_status = FLAT_TM;
		}
	}
	else if(automatic_check() == TRUE)
	{
		automatic_calc();
		ems.cpfv.last_status = INVALID;
		if(ems.soc_maint.mark == TRUE)
		{
			ems.soc_maint.mark = FALSE;
		}
	}
	else if(c2d_check() == TRUE)
	{
		c2d_calc();
	}
	else if(cpfv_check() == TRUE)
	{
		cpfv_calc();
		if(ems.soc_maint.mark == TRUE)
		{
			ems.soc_maint.mark = FALSE;
		}
	}
	else if(soc_maint_check() == TRUE)
	{
		soc_maintenance();
	}
	if(force_control_check() == TRUE)
	{
		force_control();
	}

	target_power_p = ems.last_target_power + \
				   (ems.anti_backflow.mark * ems.anti_backflow.power_var) + \
				   (ems.automatic.mark * ems.automatic.power_var) + \
				   (ems.soc_maint.mark * ems.soc_maint.power_var) + \
				   (ems.c2d.mark * ems.c2d.power_var) + \
				   (ems.cpfv.mark * ems.cpfv.power_var);
	sdk_log_a("anti_backflow: %d , %d\r\n", ems.anti_backflow.mark, ems.anti_backflow.power_var);
	sdk_log_a("automatic: %d , %d\r\n", ems.automatic.mark, ems.automatic.power_var);
	sdk_log_a("soc_maint: %d , %d\r\n", ems.soc_maint.mark, ems.soc_maint.power_var);
	sdk_log_a("c2d: %d , %d\r\n", ems.c2d.mark, ems.c2d.power_var);
	sdk_log_a("cpfv: %d , %d\r\n", ems.cpfv.mark, ems.cpfv.power_var);
	if((ems.automatic.mark) && (FALSE == fault_backflow_meter))
	{
		if((symbol_judgment_int16(target_power_p) != symbol_judgment_int16(ems.last_target_power)) && \
			(abs_int2uint(target_power_p) <= ems.automatic.dead_band)                               && \
			(abs_int2uint(ems.last_target_power) <= ems.automatic.dead_band))
		{
			target_power_p = ems.last_target_power;
		}
	}
	target_power_q = ems.last_target_power_q + \
				   (ems.force_control.mark * ems.force_control.power_var);
	valid_p = power_p_check(&target_power_p);
	valid_q = power_q_check(&target_power_q);
	if (valid_p)
	{
		array.pcsc.pcsc_ctrl.active_power_ref = target_power_p;
		g_active_power_send = TRUE;
	}
	if (valid_q)
	{
		can_cmd_temp.dst_addr = PCSM_BCAST_ID;
		can_cmd_temp.offset.all = REACTIVE_POWER_REF;
		fifo_can_push(&fifo_can1_cmd, &can_cmd_temp);
	}
}
/******************************************************************************
 * xiao_ju_ctrl()
 * xiao ju ctrl. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void xiao_ju_ctrl(void)
{
	tm_period_t p_period;

	if(xiao_ju.ctrl_source == XIAOJU_LOCAL)
	{
		ems.cpfv.enable = TRUE;
		p_period = get_tm_period();
		if((p_period.attribute == PEAK_TM) || (p_period.attribute == TOP_TM))
		{
			xiao_ju.system_ctrl = XIAOJU_DISCHARGE;
			xiao_ju.max_allow_dch_power = 1000;
			xiao_ju.max_allow_chg_power = 1000;
		}
		else if(p_period.attribute == VALLEY_TM)
		{
			xiao_ju.system_ctrl = XIAOJU_CHARGE;
			xiao_ju.max_allow_dch_power = 1000;
			xiao_ju.max_allow_chg_power = 1000;
		}
		else
		{
			xiao_ju.system_ctrl = XIAOJU_NO_ACTION;
			xiao_ju.max_allow_dch_power = 0;
			xiao_ju.max_allow_chg_power = 0;
		}
	}
	else
	{
		ems.cpfv.enable = FALSE;
	}
}
/******************************************************************************
 * fast_task_xiao_ju()
 * xiao ju module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void fast_task_xiao_ju(void)
{
	uint16_t max_output_power;
	int16_t target_power_p = 0;
	int16_t power_var = 0;
	int16_t last_target_power;
	int16_t power_step;
	int16_t power_temp;
	uint8_t i;
	bool_t fault_meter3_tmp = FALSE;
	uint32_t transformer_capacity_tmp = xiao_ju.transformer_capacity * TRANSFORMER_CAPACITY_USABLE_RATIO;

	// ammeter power value :
	// Positive is Buying electricity, Negative are selling electricity
	// 30kW
	power_step = 300;
	last_target_power = array.pcsc.pcsc_ctrl.active_power_ref;
	xiao_ju_ctrl();
	if(xiao_ju.system_ctrl == XIAOJU_CHARGE)
	{
		max_output_power = min(array.csu.csu_data.csu_const.rat_power_p_total, \
											xiao_ju.max_allow_chg_power);
		// meter 2 power down
		if(xiaoju_ammeter.ammeter_2 < 0.0f)
		{
			power_temp = abs_int2uint(xiaoju_ammeter.ammeter_2);
			// Has been overloaded.
			if(power_temp >= transformer_capacity_tmp)
			{
				power_var = min((power_temp - transformer_capacity_tmp), power_step);
			}
			// The available box capacity is larger than 2KW.
			else if((transformer_capacity_tmp - power_temp) > 20)
			{
				power_var = -min((transformer_capacity_tmp - power_temp), power_step);
			}
			else
			{
				power_var = 0;
			}
		}
		// meter 2 power up
		else
		{
			// Increase charging power
			power_var = -min((max_output_power + last_target_power), power_step);
		}

		target_power_p = last_target_power + power_var;
		constrain_int16_t_data(&target_power_p, -max_output_power, 0);
		if(fault_meter2)
		{
			target_power_p = 0;
		}
		array.pcsc.pcsc_ctrl.active_power_ref = target_power_p;
		if(target_power_p != last_target_power)
		{
			g_active_power_send = TRUE;
		}
	}
	else if(xiao_ju.system_ctrl == XIAOJU_DISCHARGE)
	{
		max_output_power = min(array.csu.csu_data.csu_const.rat_power_p_total, \
											xiao_ju.max_allow_dch_power);
		xiaoju_ammeter.virtul_ammeter_4 = xiaoju_ammeter.ammeter_2 + xiaoju_ammeter.ammeter_3;
		// power up
		if(xiaoju_ammeter.virtul_ammeter_4 > 0.0f)
		{
			power_var = -min(xiaoju_ammeter.virtul_ammeter_4, power_step);
		}
		// power down 2kW
		else if(xiaoju_ammeter.virtul_ammeter_4 < -20.0f)
		{
			if(last_target_power >= max_output_power)
			{
				power_var = 0;
			}
			else
			{
				power_var = min(-xiaoju_ammeter.virtul_ammeter_4, power_step);
			}
		}
		else
		{
			power_var = 0;
		}

		target_power_p = last_target_power + power_var;
		constrain_int16_t_data(&target_power_p, 0, max_output_power);
		for(i = 0;(i < xiao_ju.ammeter3_num) && (FALSE == fault_meter3_tmp); i++)
		{
			fault_meter3_tmp = fault_meter3[i];
		}
		if(fault_meter2 || fault_meter3_tmp)
		{
			target_power_p = 0;
		}
		array.pcsc.pcsc_ctrl.active_power_ref = target_power_p;
		if(target_power_p != last_target_power)
		{
			g_active_power_send = TRUE;
		}
	}
	else
	{
		power_var = 0;
		if(array.pcsc.pcsc_ctrl.active_power_ref != 0)
		{
			array.pcsc.pcsc_ctrl.active_power_ref = 0;
			g_active_power_send = TRUE;
		}
	}
}

/******************************************************************************
 * slow_task_ems_close()
 * close ems func. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void slow_task_ems_close(void)
{
	uint16_t tmp;

	if(TRUE == ems.cpfv.enable)
	{
		clear_struct_data((uint8_t*)planning_scheduling_delay_on_cnt, sizeof(planning_scheduling_delay_on_cnt));
		ems.cpfv.enable = FALSE;
		ems.cpfv.last_status = INVALID;
		tmp = ems.cpfv.enable;
		setting_set(LOCAL_EMS, EE_EMS_CPFV_ENABLE, &tmp, 2);
	}
	if(TRUE == ems.anti_backflow.enable)
	{
		ems.anti_backflow.enable = FALSE;
		tmp = ems.anti_backflow.enable;
		setting_set(LOCAL_EMS, EE_EMS_ANTI_ENABLE, &tmp, 2);
	}
	if(TRUE == ems.automatic.enable)
	{
		ems.automatic.enable = FALSE;
		tmp = ems.automatic.enable;
		setting_set(LOCAL_EMS, EE_EMS_AUTOMATIC_ENABLE, &tmp, 2);
	}
	if(TRUE == ems.demand_side.enable)
	{
		ems.demand_side.enable = FALSE;
		tmp = ems.demand_side.enable;
		setting_set(LOCAL_EMS, EE_EMS_DEMAND_ENABLE, &tmp, 2);
	}
	if(TRUE == ems.force_control.enable)
	{
		ems.force_control.enable = FALSE;
		tmp = ems.force_control.enable;
		setting_set(LOCAL_EMS, EE_EMS_FORCE_CONTROL_ENABLE, &tmp, 2);
	}
	if(TRUE == ems.soc_maint.enable)
	{
		ems.soc_maint.enable = FALSE;
		tmp = ems.soc_maint.enable;
		setting_set(LOCAL_EMS, EE_EMS_SOC_MAINT_ENABLE, &tmp, 2);
	}
}

/******************************************************************************
 * get_attr_from_power()
 * close ems func. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
uint8_t get_attr_from_power(int16_t power)
{
	if(power > 0)
	{
		return PEAK_TM;
	}
	else
	{
		return VALLEY_TM;
	}
}
/******************************************************************************
* End of module
******************************************************************************/
