/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     product.c
  * @brief    Define version, SN, etc. POWER_MAGIC product information
  * @company  SOFARSOLAR
  * @author   HH
  * @note
  * @version  V01
  * @date     2023/02/19
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "measure.h"
#include "product.h"
#include "setting.h"
#include "sdk.h"
#include "sdk_core.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define  BOOT_VER                            (*(volatile uint32_t *)0x08000298)
#define  BOOT_VERSION_LEN_MAX												 12

#define  HW_VERSION_V1                                                     0.15f
#define  HW_VERSION_V2                                                     0.45f
#define  HW_VERSION_V3                                                     0.65f
#define  HW_VERSION_V4                                                     1.05f
#define  HW_VERSION_V5                                                     1.35f
#define  HW_VERSION_V6                                                    1.575f
#define  HW_VERSION_V7                                                    1.875f
#define  HW_VERSION_V8                                                     2.15f
#define  HW_VERSION_V9                                                     2.35f
#define  HW_VERSION_V10                                                    2.55f

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
version_t   csu_mcu2_boot_v;
version_t   csu_mcu2_core_v;
version_t   csu_mcu2_app_v;
uint8_t     csu_mcu2_hw_v;
half_word_t csu_mcu2_can1_v;
half_word_t csu_mcu2_can5_v;
half_word_t csu_mcu2_mods_v;
uint8_t     sz_csu_sn[SN_SIZE] = "SH0026125KC23C060001";
uint8_t     system_sn[SN_SIZE] = "SH2011215EC23C060001";
sn_t        csu_sn;

product_info_t product_info;
pcs_machine_type_t pcs_machine_type[PM_MODEL_NUM];

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/
uint8_t get_hw_version(void);

void get_mcu2_app_version(version_t *target, char* source);
void output_brand_name(product_info_t *product);
void output_fac_name(product_info_t *product);
void output_model_name(product_info_t *product);
void output_rating(product_info_t *product);
void output_fac_date(product_info_t *product);
void output_use_date(product_info_t *product);
void output_hw_version(void);
void output_sw_version(void);

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/******************************************************************************
 * product_init().
 * Initialize product module. [Called by the sw_init()]
 *
 * @param  none (I)
 * @param  none (O)
 * @return none
 *****************************************************************************/
void product_init(void)
{
	csu_mcu2_boot_v = get_boot_version();
    csu_mcu2_core_v.bytes.rvd    = 'V';
	csu_mcu2_core_v.bytes.high   = SDK_MAJOR_VERSION;
	csu_mcu2_core_v.bytes.middle = SDK_MINOR_VERSION;
	csu_mcu2_core_v.bytes.low    = SDK_STAGE_VERSION;
	get_mcu2_app_version(&csu_mcu2_app_v, SOFTWARE_VERSION);
	csu_mcu2_hw_v = get_hw_version();
	csu_mcu2_can1_v.bytes.high   = 1;
	csu_mcu2_can1_v.bytes.low    = 16;
	csu_mcu2_can5_v.bytes.high   = 1;
	csu_mcu2_can5_v.bytes.low    = 16;
	csu_mcu2_mods_v.bytes.high   = 0;
	csu_mcu2_mods_v.bytes.low    = 1;

	setting_get(FUT_SET, EE_CSU_SN, &sz_csu_sn[0], 20);
	csu_sn.brand    = sz_csu_sn[0];
	csu_sn.factory  = sz_csu_sn[1];
	csu_sn.pdt_line = sz_csu_sn[2] - '0';
	csu_sn.mcode[0] = sz_csu_sn[3];
	csu_sn.mcode[1] = sz_csu_sn[4];
	csu_sn.mcode[2] = sz_csu_sn[5];
	csu_sn.mcode[3] = sz_csu_sn[6];
	csu_sn.mcode[4] = sz_csu_sn[7];
	csu_sn.mcode[5] = sz_csu_sn[8];
	csu_sn.mcode[6] = NULL;
	csu_sn.local    = sz_csu_sn[10];
	csu_sn.year     = (sz_csu_sn[11] - '0') * 10;
	csu_sn.year    += (sz_csu_sn[12] - '0');
	if(sz_csu_sn[13] >= 'A')
	{
		csu_sn.month = sz_csu_sn[13] - 'A' + 10;
	}
	else
	{
		csu_sn.month = sz_csu_sn[13] - '0';
	}
	csu_sn.day  = (sz_csu_sn[14] - '0') * 10;
	csu_sn.day += (sz_csu_sn[15] - '0');
	csu_sn.no   = (sz_csu_sn[16] - '0') * 1000;
	csu_sn.no  += (sz_csu_sn[17] - '0') * 100;
	csu_sn.no  += (sz_csu_sn[18] - '0') * 10;
	csu_sn.no  += (sz_csu_sn[19] - '0');

	memory_copy(&pcs_machine_type[0].model_code[0], PM_400V_MODEL_CODE, sizeof(pcs_machine_type[0].model_code));
	memory_copy(&pcs_machine_type[0].power_level_code[0], PM_400V_POWER_LEVEL_CODE, sizeof(pcs_machine_type[0].power_level_code));
	pcs_machine_type[0].rated_volt = POWER_MAGIC_400V;
	pcs_machine_type[0].rated_power = POWER_MAGIC_400V_POWER_RATED;

	memory_copy(&pcs_machine_type[1].model_code[0], PM_690V_MODEL_CODE, sizeof(pcs_machine_type[0].model_code));
	memory_copy(&pcs_machine_type[1].power_level_code[0], PM_690V_POWER_LEVEL_CODE, sizeof(pcs_machine_type[0].power_level_code));
	pcs_machine_type[1].rated_volt = POWER_MAGIC_690V;
	pcs_machine_type[1].rated_power = POWER_MAGIC_690V_POWER_RATED;
}

/******************************************************************************
 * get_boot_version().
 * Get boot version [Called by app]
 *
 * @param  none (I)
 * @param  none (O)
 * @return boot version
 *****************************************************************************/
version_t get_boot_version(void)
{
	int8_t sz_boot_v[BOOT_VERSION_LEN_MAX];
	version_t boot_v;

    clear_struct_data((uint8_t *)&sz_boot_v[0], sizeof(sz_boot_v));
	sdk_version_get(BOOT_VERSION_TYPE, &sz_boot_v[0], BOOT_VERSION_LEN_MAX);
	boot_v.bytes.rvd    = 'V';
	boot_v.bytes.high   = sz_boot_v[1] - '0';
	boot_v.bytes.middle = sz_boot_v[3] - '0';
	boot_v.bytes.low    = sz_boot_v[5] - '0';

	return boot_v;
}

/******************************************************************************
 * get_sw_version().
 * Get MCU2 APP version [Called by app]
 *
 * @param  none (I)
 * @param  none (O)
 * @return HW version
 *****************************************************************************/
void get_mcu2_app_version(version_t *target, char* source)
{
	int32_t version_high, version_middle, version_low;
	int32_t result;

	result = sscanf(source, "V%d.%d.%d", &version_high, &version_middle, &version_low);
	if(result == 3)
	{
		target->bytes.rvd    = 'V';
		target->bytes.high   = version_high;
		target->bytes.middle = version_middle;
		target->bytes.low    = version_low;
	}
	else
	{
		target->bytes.rvd    = 'V';
		target->bytes.high   = 0;
		target->bytes.middle = 0;
		target->bytes.low    = 0;
	}
}
/******************************************************************************
 * get_hw_version().
 * Get board HW version from ADC [Called by app]
 *
 * @param  none (I)
 * @param  none (O)
 * @return HW version
 *****************************************************************************/
uint8_t get_hw_version(void)
{
	uint8_t hw_v = 0;

	int32_t tmp = 0;
	float32_t hw_voltage = 0;

	sdk_adc_read(AD_CH_HW_VER, &tmp);
	hw_voltage = tmp * 0.0007326f;

	if((hw_voltage < (HW_VERSION_V1 + 0.1f)) &&
	   (hw_voltage > (HW_VERSION_V1 - 0.1f)))
	{
		hw_v = 0;
	}
	else if((hw_voltage < (HW_VERSION_V2 + 0.1f) &&
			(hw_voltage > (HW_VERSION_V2 - 0.1f))))
	{
		hw_v = 1;
	}
	else if((hw_voltage < (HW_VERSION_V3 + 0.1f) &&
			(hw_voltage > (HW_VERSION_V3 - 0.1f))))
	{
		hw_v = 2;
	}
	else if((hw_voltage < (HW_VERSION_V4 + 0.1f) &&
			(hw_voltage > (HW_VERSION_V4 - 0.1f))))
	{
		hw_v = 3;
	}
	else if((hw_voltage < (HW_VERSION_V5 + 0.1f) &&
			(hw_voltage > (HW_VERSION_V5 - 0.1f))))
	{
		hw_v = 4;
	}
	else if((hw_voltage < (HW_VERSION_V6 + 0.1f) &&
			(hw_voltage > (HW_VERSION_V6 - 0.1f))))
	{
		hw_v = 5;
	}
	else if((hw_voltage < (HW_VERSION_V7 + 0.1f) &&
			(hw_voltage > (HW_VERSION_V7 - 0.1f))))
	{
		hw_v = 6;
	}
	else if((hw_voltage < (HW_VERSION_V8 + 0.1f) &&
			(hw_voltage > (HW_VERSION_V8 - 0.1f))))
	{
		hw_v = 7;
	}
	else if((hw_voltage < (HW_VERSION_V9 + 0.1f) &&
			(hw_voltage > (HW_VERSION_V9 - 0.1f))))
	{
		hw_v = 8;
	}
	else if((hw_voltage < (HW_VERSION_V10 + 0.1f) &&
			(hw_voltage > (HW_VERSION_V10 - 0.1f))))
	{
		hw_v = 9;
	}

	return hw_v;
}

/******************************************************************************
 * output_product_info().
 * Output product information [Called by the app()]
 *
 * @param  none (I)
 * @param  none (O)
 * @return none
 *****************************************************************************/
void output_product_info(void)
{
	sdk_log_i("/****** CSU MCU2 information ******/\r\n");

	output_brand_name(&product_info);
	output_fac_name(&product_info);
	output_model_name(&product_info);
	output_rating(&product_info);
	output_fac_date(&product_info);
	output_use_date(&product_info);

	output_hw_version();

	output_sw_version();

	sdk_log_i("\r\n");
}

/******************************************************************************
 * output_brand_name().
 * Output brand name [Called by the app()]
 *
 * @param *product  (I) pointer to product info
 * @param  none     (O)
 * @return none
 *****************************************************************************/
void output_brand_name(product_info_t *product)
{

	if(product)
	{
		sdk_log_i("Brand name:         ");
		sdk_log_i("%s\r\n", (uint8_t *)product->brand_name);
	}
}

/******************************************************************************
 * output_fac_name().
 * Output factory name [Called by the app()]
 *
 * @param *product  (I) pointer to product info
 * @param  none     (O)
 * @return none
 *****************************************************************************/
void output_fac_name(product_info_t *product)
{
	if(product)
	{
		sdk_log_i("Factory Name:       ");
		sdk_log_i("%s\r\n", (uint8_t *)product->fac_name);
	}
}

/******************************************************************************
 * output_model_name().
 * Output model name [Called by the app()]
 *
 * @param *product  (I) pointer to product info
 * @param  none     (O)
 * @return none
 *****************************************************************************/
void output_model_name(product_info_t *product)
{
	if(product)
	{
		sdk_log_i("Model Name:         ");
		sdk_log_i("%s\r\n", (uint8_t *)product->model_name);
	}
}

/******************************************************************************
 * output_rating().
 * Output Nominal Power Rating [Called by the app()]
 *
 * @param *product  (I) pointer to product info
 * @param  none     (O)
 * @return none
 *****************************************************************************/
void output_rating(product_info_t *product)
{
	if(product)
	{
		sdk_log_i("Power Rating:       ");
		sdk_log_i("%dkW\r\n", product->rating);
	}
}

/******************************************************************************
 * output_fac_date().
 * Output factory date [Called by the app()]
 *
 * @param *product  (I) pointer to product info
 * @param  none     (O)
 * @return none
 *****************************************************************************/
void output_fac_date(product_info_t *product)
{
	uint16_t year;
	uint8_t mon;
	uint8_t day;

	if(product)
	{
		year = product->fac_date[1].bytes.low + 2000;
		// 1119 -> 11 mon 19 day
		mon  = product->fac_date[0].bytes.high;
		day  = product->fac_date[0].bytes.low;
		sdk_log_i("Factory date:       ");
		sdk_log_i("%02d-%02d-%02d\r\n", year, mon, day);
	}
}

/******************************************************************************
 * output_use_date().
 * Output use date [Called by the app()]
 *
 * @param *product  (I) pointer to product info
 * @param  none     (O)
 * @return none
 *****************************************************************************/
void output_use_date(product_info_t *product)
{
	uint16_t year;
	uint8_t mon;
	uint8_t day;

	if(product)
	{
		year = product->use_date[1].bytes.low + 2000;
		// 1119 -> 11 mon 19 day
		mon  = product->use_date[0].bytes.high;
		day  = product->use_date[0].bytes.low;
		sdk_log_i("Use date:           ");
		sdk_log_i("%02d-%02d-%02d\r\n", year, mon, day);
	}
}

#if 0
/******************************************************************************
 * output_brand_name().
 * Output brand name [Called by the app()]
 *
 * @param *sn  (I) pointer to sn
 * @param none (O)
 * @return none
 *****************************************************************************/
void output_brand_name(sn_t *sn)
{
	if(sn)
	{
		sdk_log_i("Brand:              ");
		switch(sn->brand)
		{
			case 'S':
			sdk_log_i("SOFAR\r\n");
			break;
			default:
			sdk_log_i("na\r\n");
			break;
		}
	}
}

/******************************************************************************
 * output_factory().
 * Output factory [Called by the app()]
 *
 * @param *sn  (I) pointer to sn
 * @param none (O)
 * @return none
 *****************************************************************************/
void output_factory(sn_t *sn)
{
	if(sn)
	{
		sdk_log_i("Factory:            ");
		switch(sn->factory)
		{
			case 'D':
			sdk_log_i("Dongguan\r\n");
			break;
			case 'H':
			sdk_log_i("Huizhou\r\n");
			break;
			case 'Q':
			sdk_log_i("Qiaoan\r\n");
			break;
			case 'R':
			sdk_log_i("Repaired\r\n");
			break;
			default:
			sdk_log_i("na\r\n");
			break;
		}
	}
}

/******************************************************************************
 * output_pdt_line().
 * Output product line [Called by the app()]
 *
 * @param *sn  (I) pointer to sn
 * @param none (O)
 * @return none
 *****************************************************************************/
void output_pdt_line(sn_t *sn)
{
	if(sn)
	{
		sdk_log_i("Product line:       ");
		switch(sn->pdt_line)
		{
			case PL_SPECIAL:
			sdk_log_i("Special defined\r\n");
			break;
			case PL_INVERTER:
			sdk_log_i("Inverter(PV&PCS)\r\n");
			break;
			case PL_LI_BATTERY:
			sdk_log_i("Li-battery\r\n");
			break;
			case PL_IDC_POWER:
			sdk_log_i("IDC power supply\r\n");
			break;
			default:
			sdk_log_i("na\r\n");
			break;
		}
	}
}

/******************************************************************************
 * output_mcode().
 * Output PCBA material code [Called by the app()]
 *
 * @param *sn  (I) pointer to sn
 * @param none (O)
 * @return none
 *****************************************************************************/
void output_mcode(sn_t *sn)
{
	if(sn)
	{
		sdk_log_i("PCBA:               %s\r\n", sn->mcode);
	}
}

/******************************************************************************
 * output_sales_area().
 * Output sales area [Called by the app()]
 *
 * @param *sn  (I) pointer to sn
 * @param none (O)
 * @return none
 *****************************************************************************/
void output_sales_area(sn_t *sn)
{
	if(sn)
	{
		sdk_log_i("Sales area:         ");
		switch(sn->local)
		{
			case 'C':
			sdk_log_i("China mainland\r\n");
			break;
			case 'E':
			sdk_log_i("Europe, India, South America\r\n");
			break;
			case 'J':
			sdk_log_i("Japan\r\n");
			break;
			case 'U':
			sdk_log_i("North America\r\n");
			break;
			case 'A':
			sdk_log_i("Australia\r\n");
			break;
			case '0':
			sdk_log_i("Others\r\n");
			break;
			default:
			sdk_log_i("na\r\n");
			break;
		}
	}
}

/******************************************************************************
 * output_factory_date().
 * Output factory date [Called by the app()]
 *
 * @param *sn  (I) pointer to sn
 * @param none (O)
 * @return none
 *****************************************************************************/
void output_factory_date(sn_t *sn)
{
	if(sn)
	{
		sdk_log_i("Factory date:       20%02d-%02d-%02d\r\n", sn->year, sn->month, sn->day);
	}
}

/******************************************************************************
 * output_serial_number().
 * Output serial number [Called by the app()]
 *
 * @param *sn  (I) pointer to sn
 * @param none (O)
 * @return none
 *****************************************************************************/
void output_serial_number(sn_t *sn)
{
	if(sn)
	{
		sdk_log_i("Factory serial no.: %04d\r\n", sn->no);
	}
}

#endif

/******************************************************************************
 * output_hw_version().
 * Output HW version [Called by the app()]
 *
 * @param  none (I)
 * @param  none (O)
 * @return none
 *****************************************************************************/
void output_hw_version(void)
{
	sdk_log_i("HW version:         V%02d\r\n", csu_mcu2_hw_v);
}

/******************************************************************************
 * output_sw_version().
 * Output software version [Called by the app()]
 *
 * @param none (I)
 * @param none (O)
 * @return none
 *****************************************************************************/
void output_sw_version(void)
{
	sdk_log_i("Boot version:       V%02d.%02d.%02d\r\n", csu_mcu2_boot_v.bytes.high,
															csu_mcu2_boot_v.bytes.middle,
															csu_mcu2_boot_v.bytes.low);
	sdk_log_i("Core version:       V%02d.%02d.%02d\r\n", csu_mcu2_core_v.bytes.high,
															csu_mcu2_core_v.bytes.middle,
															csu_mcu2_core_v.bytes.low);
	sdk_log_i("App version:        V%02d.%02d.%02d\r\n", csu_mcu2_app_v.bytes.high,
															csu_mcu2_app_v.bytes.middle,
															csu_mcu2_app_v.bytes.low);
}

/******************************************************************************
* End of module
******************************************************************************/
