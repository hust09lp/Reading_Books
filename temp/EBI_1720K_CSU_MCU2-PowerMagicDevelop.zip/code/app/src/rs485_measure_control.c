/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     rs485_measure_control.c
  * @brief    Measure control module
  * @company  SOFARSOLAR
  * @author   ZZJ
  * @note
  * @version  V01
  * @date     2023/09/16
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "array.h"
#include "rs485_measure_control.h"
#include "sdk.h"
#include "sdk_core.h"
#include "pcsc_diag.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
// TODOReturn difference
#define RS485_MEASURE_CONTROL                                               (1)
#define RS485_MEASURE_CONTROL_SLAVE_ADDR_1                                  (1)
#define RS485_MEASURE_CONTROL_SLAVE_ADDR_2                                  (2)
#define RS485_MEASURE_CONTROL_SLAVE_ADDR_3                                  (3)
/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/
measure_control_t measure_control[3];
uint8_t measure_control_buff[MAX_MEASURE_CONTROL_FRAME_LEN];
/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
int16_t fault_measure_cnt;
int16_t fault_measure_ref;
bool_t trigger_measure_control;
rs485_settting_parm_t rs485_measure_control_parm;

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/
/******************************************************************************
 * rs485_measure_control_init().
 * Initialize measure_control debug module. [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_measure_control_init(void)
{
	rs485_measure_control_parm.port = RS485_MEASURE_CONTROL;
	rs485_measure_control_parm.slave_addr = RS485_MEASURE_CONTROL_SLAVE_ADDR_1;
	rs485_measure_control_parm.baud = MODBUS_BAUD_9600;
	rs485_measure_control_parm.timeout = 300;
	modbus_init(rs485_measure_control_parm);

	fault_measure_cnt = 0;
	fault_measure_ref = 4;
	trigger_measure_control = array.pcsc.pcsc_ctrl.rs485_enable.bit.measure_control;
}

/******************************************************************************
 * rs485_task_measure_control()
 * measure_control module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_task_measure_control(void)
{
	int16_t ret;
	uint8_t data[6];
	uint8_t len = 0;
	uint8_t buff_index;
	half_word_t register_address, register_len;
	static uint8_t index = 0;
	uint8_t slave_addr;

	switch (index)
	{
		case 0:
			slave_addr = RS485_MEASURE_CONTROL_SLAVE_ADDR_1;
			buff_index = index;
			index++;
			break;
		case 1:
			slave_addr = RS485_MEASURE_CONTROL_SLAVE_ADDR_2;
			buff_index = index;
			index++;
			break;
		case 2:
			slave_addr = RS485_MEASURE_CONTROL_SLAVE_ADDR_3;
			buff_index = index;
			index = 0;
			break;
		default:
			slave_addr = RS485_MEASURE_CONTROL_SLAVE_ADDR_3;
			buff_index = index;
			index = 0;
			break;
	}
	register_len.all = 8;
	register_address.all = 0x000A;
	data[len++] = slave_addr;
	data[len++] = MODBUS_READ_HOLDING_REGISTERS;
	data[len++] = register_address.bytes.high;
	data[len++] = register_address.bytes.low;
	data[len++] = register_len.bytes.high;
	data[len++] = register_len.bytes.low;

	ret = sdk_modbus_write(RS485_MEASURE_CONTROL, &data[0], len);
	ret = sdk_modbus_receive_confirmation(RS485_MEASURE_CONTROL, &measure_control_buff[0]);
	if(ret > 0)
	{
		fault_measure_cnt = 0;
		memcpy((uint8_t *)&measure_control[buff_index], &measure_control_buff[3], sizeof(measure_control_t));
	}
	else
	{
		sdk_modbus_flush(RS485_MEASURE_CONTROL);
		if(fault_measure_cnt <= fault_measure_ref)
		{
			fault_measure_cnt++;
		}
		clear_struct_data((uint8_t *)&measure_control, sizeof(measure_control_t));
	}
}

/******************************************************************************
* End of module
******************************************************************************/
