/******************************************************************************
 *
 * FILE IDENTIFICATION
 * -------------------
 *
 * File Name   : rtc.c
 * Description : rtc function
 *
 * $RCSfile    : $
 * $Author     : ZHH
 * $Date       : 2023-07-04$
 * $Revision   : V01$
 *
 ******************************************************************************
 * Copyright (c) SOFAR SH 2023
 * All right reserved.
 *****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "array.h"
#include "rtc.h"
#include "setting.h"
#include "cup_sofar_can.h"
#include "measure.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
uint8_t data_ee[EE_TOTAL_RUNTIME_LEN];
uint32_t total_runtime = 0;
int32_t runtime_index = 0;

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/
/******************************************************************************
 * rtc_init().
 * rtc variable initial. [Called by init.]
 *
 * @param none (I)
 * @return none.
 *****************************************************************************/
void rtc_init(void)
{
    sdk_rtc_get(RTC_BIN_FORMAT, &array.csu.rtc);
    clear_struct_data(&data_ee[0], EE_TOTAL_RUNTIME_LEN);
	total_runtime = 0;
	runtime_index = 0;
}

/******************************************************************************
 * total_minutes().
 * The number of minutes now. [Called by time_difference_in_minutes.]
 *
 * @param time (I) now time
 * @return The number of minutes now.
 *****************************************************************************/
uint16_t total_minutes(const sdk_rtc_t* time)
{
    return (time->tm_hour * 60) + time->tm_min;
}

/******************************************************************************
 * total_sec().
 * The number of second now. [Called by time_difference_in_sec.]
 *
 * @param time (I) now time
 * @return The number of sec now.
 *****************************************************************************/
uint32_t total_sec(const sdk_rtc_t* time)
{
	uint32_t sec;

	sec = (time->tm_hour * 3600) + (time->tm_min * 60) + (time->tm_sec);

	return sec;
}

/******************************************************************************
 * time_difference_in_minutes().
 * The number of minutes between two time points. [Called by.]
 *
 * @param time (I) last time
 * @param time (I) now time
 * @return The number of minutes between two time points.
 *****************************************************************************/
uint16_t time_difference_in_minutes(const sdk_rtc_t* time1, const sdk_rtc_t* time2)
{
	uint16_t total_minutes1 = total_minutes(time1);
	uint16_t total_minutes2 = total_minutes(time2);
	uint16_t diff_minutes;

	if (total_minutes2 < total_minutes1)
	{
		// Adding 24 hours in minutes to the second time(24 * 60)
		diff_minutes = total_minutes2 + 1440 - total_minutes1;
	}
	else
	{
		diff_minutes = total_minutes2 - total_minutes1;
	}

	return diff_minutes;
}

/******************************************************************************
 * time_difference_in_minutes().
 * The number of minutes between two time points. [Called by.]
 *
 * @param time (I) last time
 * @param time (I) now time
 * @return The number of sec between two time points.
 *****************************************************************************/
uint32_t time_difference_in_sec(const sdk_rtc_t* time1, const sdk_rtc_t* time2)
{
	uint32_t total_sec1 = total_sec(time1);
	uint32_t total_sec2 = total_sec(time2);
	uint32_t diff_sec;

	if(total_sec2 < total_sec1)
	{
		// Adding 24 hours in sec to the second time(24 * 3600s)
		diff_sec = total_sec2 + 86400 - total_sec1;
	}
	else
	{
		diff_sec = total_sec2 - total_sec1;
	}

	return diff_sec;
}

/******************************************************************************
 * fast_task_rtc().
 * get rtc. [Called by task.]
 *
 * @param none (I)
 * @return none.
 *****************************************************************************/
void fast_task_rtc(void)
{
	sdk_rtc_get(RTC_BIN_FORMAT, &array.csu.rtc);
}

/******************************************************************************
 * total_time_init().
 * total runtime init. [Called by task.]
 *
 * @param none (I)
 * @return none.
 *****************************************************************************/
void total_time_init(void)
{
	uint16_t i;
	int16_t ret = -1;
	uint8_t *p_data = (uint8_t*)&data_ee[0];
	runtime_t *p_runtime;
	runtime_t runtime_temp;
	uint16_t crc;

	runtime_index = -1;
	setting_get(SYS_PARM, EE_TOTAL_RUNTIME, data_ee, EE_TOTAL_RUNTIME_LEN);

	for(i = 0; (i < RUNTIME_NUM) && (ret == -1); p_data += RUNTIME_WORD_LEN, i++)
	{
		p_runtime = (runtime_t*)p_data;
		crc = crc16((uint8_t*)&(p_runtime->value), WORD_LEN);

		if((p_runtime->value != 0xFFFFFFFF) && (crc == p_runtime->crc))
		{
			runtime_index = i;
		}
	}

	// if first or final data, clear and reset
	if (runtime_index == -1)
	{
		total_runtime = 0;
		array.pcsc.pcsc_data.var.total_runtime = total_runtime;
		fill_struct_data(data_ee, 0xFF, EE_TOTAL_RUNTIME_LEN);
		runtime_temp.value = total_runtime;
		runtime_temp.crc = crc16((uint8_t*)&(runtime_temp.value), WORD_LEN);
		memcpy(&data_ee[0], &runtime_temp, RUNTIME_WORD_LEN);
		setting_set(SYS_PARM, EE_TOTAL_RUNTIME, data_ee, EE_TOTAL_RUNTIME_LEN);
		runtime_index = 1;
	}
	else
	{
		memcpy(&array.pcsc.pcsc_data.var.total_runtime, &data_ee[runtime_index * RUNTIME_WORD_LEN], WORD_LEN);
		total_runtime = array.pcsc.pcsc_data.var.total_runtime;
		runtime_index++;
	}
}

/******************************************************************************
 * slow_task_total_runtime().
 * record total runtime. [Called by task.]
 *
 * @param none (I)
 * @return none.
 *****************************************************************************/
void slow_task_total_runtime(void)
{
	static uint8_t entry_count = 0;
	uint8_t record_flag = FALSE;
	runtime_t runtime_temp;
	uint32_t addr;

	total_runtime++;
	entry_count++;
	if(entry_count == 6)
	{
		record_flag = TRUE;
		entry_count = 0;
	}
	if (record_flag)
	{
		runtime_temp.value = total_runtime / 6;
		runtime_temp.crc = crc16((uint8_t*)&runtime_temp.value, WORD_LEN);
		array.pcsc.pcsc_data.var.total_runtime = runtime_temp.value;
		if(runtime_index == RUNTIME_NUM)
		{
			fill_struct_data(data_ee, 0xFF, EE_TOTAL_RUNTIME_LEN);
			memcpy(&data_ee[0], &runtime_temp, RUNTIME_WORD_LEN);
			setting_set_without_log(SYS_PARM, EE_TOTAL_RUNTIME, data_ee, EE_TOTAL_RUNTIME_LEN);
			runtime_index = 0;
		}
		else
		{
			addr = EE_TOTAL_RUNTIME + runtime_index * RUNTIME_WORD_LEN;
			setting_set_without_log(SYS_PARM, addr, &runtime_temp, RUNTIME_WORD_LEN);
			runtime_index++;
		}
	}
}

/******************************************************************************
* End of module
******************************************************************************/
