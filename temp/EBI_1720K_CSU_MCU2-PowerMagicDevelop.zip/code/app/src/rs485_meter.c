/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     rs485_meter.c
  * @brief    Meter module
  * @company  SOFARSOLAR
  * @author   ZZJ
  * @note
  * @version  V01
  * @date     2023/06/20
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "rs485_meter.h"
#include "sdk.h"
#include "sdk_core.h"
#include "ems.h"
#include "array.h"
#include "pcsc_diag.h"
#include "pcsc_opt_log.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
int16_t fault_backflow_meter_cnt;
int16_t fault_backflow_meter_ref;
int16_t fault_metering_meter_cnt;
int16_t fault_metering_meter_ref;
int16_t fault_meter2_cnt;
int16_t fault_meter2_ref;
int16_t fault_meter3_cnt[METERING_METER3_MAX_NUM];
int16_t fault_meter3_ref;
int16_t fault_pv_meter_cnt[PV_METER_MAX_NUM];
int16_t fault_pv_meter_ref;
bool_t trigger_metering_meter;
bool_t trigger_backflow_meter;
bool_t trigger_meter2;
bool_t trigger_meter3[METERING_METER3_MAX_NUM];
bool_t g_trigger_pv_meter[PV_METER_MAX_NUM];
bool_t g_trigger_pv_meter_sw;
metering_meter_t pcc_meter_data;
metering_meter_t metering_meter[CMU_NUMS];
metering_meter_t meter2_other_data[PV_METER_MAX_NUM];
metering_meter_t meter3_other_data[METERING_METER3_MAX_NUM];

uint16_t meter_buff[RS485_METER_BUFF_LEN];
float32_t meter3_power_old[METERING_METER3_MAX_NUM];
uint16_t meter1_disconnect_flag;
uint8_t metering_meter1_num;

uint32_t backflow_conn_count;
uint32_t backflow_disconn_count;
uint32_t meter1_disconn_count;
uint32_t meter1_conn_count;
uint32_t meter2_disconn_count;
uint32_t meter2_conn_count;
uint32_t meter3_disconn_count;
uint32_t meter3_conn_count;
uint32_t pv_meter_disconn_count;
uint32_t pv_meter_conn_count;

rs485_settting_parm_t rs485_abm_parm;
rs485_settting_parm_t rs485_mm1_parm;
rs485_settting_parm_t rs485_mm2_parm;
rs485_settting_parm_t rs485_mm3_parm;
rs485_settting_parm_t rs485_pv_m_parm;

pv_meter_t pv_meter_parm;

uint8_t g_pv_meter_num_record;

meter_point_table_t adl400_point_table[ADL400_DATA_SEGMENT_NUM] =
{
	{0x800, 6}, // R/S/T三相电压
	{0x81C, 8}, // R/S/T三相无功功率 + 总功率
	{0x80C, 6}, // R/S/T三相电流
	{0x82C, 10}, // R/S/T三相功率因数 + 总功率因数 + 电网频率
	{0x824, 8}, // R/S/T三相视在功率 + 总视在功率
	{0x84C, 10}, // 正向有功,总/尖峰/峰/平/谷电能
	{0x86A, 20}, // 正向无功总/尖峰/峰/平/谷电能 + 反向无功总/尖峰/峰/平/谷电能
	{0x856, 10}, // 反向有功总/尖峰/峰/平/谷电能
};
meter_point_table_t dtsu666_point_table[DTSU666_DATA_SEGMENT_NUM] =
{
	{0x2000, 6}, // R/S/T三相电压
	{0x2044, 2}, // 电网频率
	{0x200C, 6}, // R/S/T三相电流
	{0x201A, 8}, // R/S/T三相无功功率 + 总功率
	{0x101E, 2}, // 正向有功总电能
	{0x202A, 8}, // R/S/T三相功率因数 + 总功率因数
	{0x1028, 2}, // 反向有功总电能
};

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

// ************************************************************backflow meter function start*********************************************************
// abm : Anti backflow meter
bool_t adl400_anti_backflow_meter(void);
bool_t adl400_abm_param_init(void);
bool_t adl400_abm_power_p(void);
bool_t adl400_abm_power_q(void);
bool_t adl400_abm_power_factor(void);

bool_t dtsu666_anti_backflow_meter(void);
bool_t dtsu666_abm_param_init(void);
bool_t dtsu666_abm_power_p(void);
bool_t dtsu666_abm_power_q(void);
bool_t dtsu666_abm_power_factor(void);

// Read data using
bool_t (*backflow_meter_fun_ptr[METER_MODEL_NUM])(void) =
{
	adl400_anti_backflow_meter,
	dtsu666_anti_backflow_meter,
};
// Initialize meter parameters
bool_t (*backflow_meter_param_init_fun_ptr[METER_MODEL_NUM])(void) =
{
	adl400_abm_param_init,
	dtsu666_abm_param_init,
};
// adl400 Polling points
bool_t (*adl400_abm_read_ptr[BACKFLOW_METER_POINTS_NUM])(void) =
{
	adl400_abm_power_p,
//	adl400_abm_power_q,
//	adl400_abm_power_factor,
};
// dtsu666 Polling points
bool_t (*dtsu666_abm_read_ptr[BACKFLOW_METER_POINTS_NUM])(void) =
{
	dtsu666_abm_power_p,
	// dtsu666_abm_power_q,
	// dtsu666_abm_power_factor,
};
// ************************************************************backflow meter function end*********************************************************

// ************************************************************metering meter2 function start*********************************************************
// mm : metering meter
bool_t adl400_mm2_param_init(void);
bool_t adl400_mm2_power_p(void);

bool_t dtsu666_mm2_param_init(void);
bool_t dtsu666_mm2_power_p(void);

bool_t (*metering_meter2_fun_ptr[METER_MODEL_NUM])(void) =
{
	adl400_mm2_power_p,
	dtsu666_mm2_power_p,
};
bool_t (*metering_meter2_param_init_fun_ptr[METER_MODEL_NUM])(void) =
{
	adl400_mm2_param_init,
	dtsu666_mm2_param_init,
};

// ************************************************************metering meter2 function end*********************************************************

// ************************************************************metering meter3 function start*********************************************************
// mm : metering meter
bool_t adl400_mm3_param_init(uint8_t index);
bool_t adl400_mm3_power_p(uint8_t index, float32_t *power_tmp);

bool_t dtsu666_mm3_param_init(uint8_t index);
bool_t dtsu666_mm3_power_p(uint8_t index, float32_t *power_tmp);

bool_t (*metering_meter3_fun_ptr[METER_MODEL_NUM])(uint8_t index, float32_t *power_tmp) =
{
	adl400_mm3_power_p,
	dtsu666_mm3_power_p,
};
bool_t (*metering_meter3_param_init_fun_ptr[METER_MODEL_NUM])(uint8_t index) =
{
	adl400_mm3_param_init,
	dtsu666_mm3_param_init,
};
// ************************************************************metering meter3 function end*********************************************************
// ************************************************************pv function start*********************************************************
bool_t adl400_pv_m_param_init(uint8_t index);
bool_t adl400_pv_m_power_p(uint8_t index);

bool_t dtsu666_pv_m_param_init(uint8_t index);
bool_t dtsu666_pv_m_power_p(uint8_t index);
bool_t (*pv_meter_param_init_fun_ptr[METER_MODEL_NUM])(uint8_t index) =
{
	adl400_pv_m_param_init,
	dtsu666_pv_m_param_init,
};

bool_t (*pv_meter_fun_ptr[METER_MODEL_NUM])(uint8_t index) =
{
	adl400_pv_m_power_p,
	dtsu666_pv_m_power_p,
};
// ************************************************************pv function end*********************************************************

uint8_t read_adl400_meter_data(rs485_settting_parm_t rs485_parm, uint8_t index, metering_meter_t* buff);
uint8_t read_dtsu666_meter_data(rs485_settting_parm_t rs485_parm, uint8_t index, metering_meter_t* buff);

uint8_t (*read_meter_data[METER_MODEL_NUM])(rs485_settting_parm_t rs485_parm, uint8_t index, metering_meter_t* buff) =
{
	read_adl400_meter_data,
	read_dtsu666_meter_data,
};
// ************************************************************metering meter3 function end*********************************************************
/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/
/******************************************************************************
 * meter_model_sw()
 * meter param init. [Called by task.]
 *
 * @param none (I)
 * @return TRUE : success / FALSE : fail
 *****************************************************************************/
bool_t meter_model_sw(uint8_t slave_addr, uint8_t port_index, uint16_t *meter_model)
{
	uint8_t data[6] = {slave_addr, 0x03, 0x00, 0x00, 0x00, 0x02};
	uint16_t points_array[METER_MODEL_NUM] = {ADL400_UNIQUE_POINT, DTSU666_UNIQUE_POINT};
	int32_t ret = -1;
	bool_t ret_flag = FALSE;
	half_word_t tmp;
	uint8_t i;
	uint8_t *buff = (uint8_t*)meter_buff;

	sdk_modbus_slave_set(port_index, slave_addr);
	for (i = 0; (i < METER_MODEL_NUM) && (FALSE == ret_flag); i++)
	{
		tmp.all = points_array[i];
		data[2] = tmp.bytes.high;
		data[3] = tmp.bytes.low;
		clear_struct_data((uint8_t*)&buff[0], sizeof(buff));
		sdk_modbus_flush(port_index);
		sdk_modbus_write(port_index, &data[0], 6);
		ret = sdk_modbus_receive_confirmation(port_index, &buff[0]);
		if((9 == ret) && (MODBUS_READ_HOLDING_REGISTERS == buff[1]))
		{
			*meter_model = i;
			ret_flag = TRUE;
		}
		// sdk_log_printf("send:%X, %X, %X, %X, %X, %X\n", data[0], data[1], data[2], data[3], data[4], data[5]);
		sdk_log_a("%d, %d, %d, %d, %d, %d, %d, %d\n", i, ret, buff[0], buff[1], buff[2], buff[3], buff[4], buff[5]);
		sdk_delay_ms(20);
	}
	return ret_flag;
}
/******************************************************************************
 * read_adl400_meter_data().
 * Initialize metering meter debug module. [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
uint8_t read_adl400_meter_data(rs485_settting_parm_t rs485_parm, uint8_t index, metering_meter_t* buff)
{
	int32_t ret = -1;
	uint8_t flag = 0;
	word_t tmp32;
	uint16_t len;
	uint16_t addr;

	sdk_modbus_slave_set(rs485_parm.port, rs485_parm.slave_addr);
	if(index >= ADL400_DATA_SEGMENT_NUM)
	{
		BIT_SET(flag, 2);
		return flag;
	}
	len = adl400_point_table[index].len;
	addr = adl400_point_table[index].addr;
	ret = sdk_modbus_registers_read(rs485_parm.port, addr, len, meter_buff);
	switch (index)
	{
		case 0:
			if(ret == len)
			{
				BIT_SET(flag, 0);
				buff->volt_r = uint32_to_float(meter_buff[0], meter_buff[1]);
				buff->volt_s = uint32_to_float(meter_buff[2], meter_buff[3]);
				buff->volt_t = uint32_to_float(meter_buff[4], meter_buff[5]);
			}
			break;
		case 1:
			if(ret == len)
			{
				BIT_SET(flag, 0);
				buff->reactive_power_r = rs485_parm.symbol * uint32_to_float(meter_buff[0], meter_buff[1]);
				buff->reactive_power_s = rs485_parm.symbol * uint32_to_float(meter_buff[2], meter_buff[3]);
				buff->reactive_power_t = rs485_parm.symbol * uint32_to_float(meter_buff[4], meter_buff[5]);
				buff->reactive_power   = rs485_parm.symbol * uint32_to_float(meter_buff[6], meter_buff[7]);
			}
			break;
		case 2:
			if(ret == len)
			{
				BIT_SET(flag, 0);
				buff->current_r = uint32_to_float(meter_buff[0], meter_buff[1]);
				buff->current_s = uint32_to_float(meter_buff[2], meter_buff[3]);
				buff->current_t = uint32_to_float(meter_buff[4], meter_buff[5]);
			}
			break;
		case 3:
			if(ret == len)
			{
				BIT_SET(flag, 0);
				buff->power_factor_r = rs485_parm.symbol * uint32_to_float(meter_buff[0], meter_buff[1]);
				buff->power_factor_s = rs485_parm.symbol * uint32_to_float(meter_buff[2], meter_buff[3]);
				buff->power_factor_t = rs485_parm.symbol * uint32_to_float(meter_buff[4], meter_buff[5]);
				buff->power_factor   = rs485_parm.symbol * uint32_to_float(meter_buff[6], meter_buff[7]);
				buff->frequency      = uint32_to_float(meter_buff[8], meter_buff[9]);
			}
			break;
		case 4:
			if(ret == len)
			{
				BIT_SET(flag, 0);
				buff->apparent_power_r = uint32_to_float(meter_buff[0], meter_buff[1]);
				buff->apparent_power_s = uint32_to_float(meter_buff[2], meter_buff[3]);
				buff->apparent_power_t = uint32_to_float(meter_buff[4], meter_buff[5]);
				buff->apparent_power   = uint32_to_float(meter_buff[6], meter_buff[7]);
			}
			break;
		case 5:
			if(ret == len)
			{
				BIT_SET(flag, 0);
				tmp32.half_word[1].all = meter_buff[0];
				tmp32.half_word[0].all = meter_buff[1];
				buff->forward_total_active_energy = tmp32.all;
				tmp32.half_word[1].all = meter_buff[2];
				tmp32.half_word[0].all = meter_buff[3];
				buff->forward_top_active_energy = tmp32.all;
				tmp32.half_word[1].all = meter_buff[4];
				tmp32.half_word[0].all = meter_buff[5];
				buff->forward_peak_active_energy = tmp32.all;
				tmp32.half_word[1].all = meter_buff[6];
				tmp32.half_word[0].all = meter_buff[7];
				buff->forward_flat_active_energy = tmp32.all;
				tmp32.half_word[1].all = meter_buff[8];
				tmp32.half_word[0].all = meter_buff[9];
				buff->forward_valley_active_energy = tmp32.all;
			}
			break;
		case 6:
			if(ret == len)
			{
				BIT_SET(flag, 0);
				tmp32.half_word[1].all = meter_buff[0];
				tmp32.half_word[0].all = meter_buff[1];
				buff->forward_total_reactive_energy = tmp32.all;
				tmp32.half_word[1].all = meter_buff[2];
				tmp32.half_word[0].all = meter_buff[3];
				buff->forward_top_reactive_energy = tmp32.all;
				tmp32.half_word[1].all = meter_buff[4];
				tmp32.half_word[0].all = meter_buff[5];
				buff->forward_peak_reactive_energy = tmp32.all;
				tmp32.half_word[1].all = meter_buff[6];
				tmp32.half_word[0].all = meter_buff[7];
				buff->forward_flat_reactive_energy = tmp32.all;
				tmp32.half_word[1].all = meter_buff[8];
				tmp32.half_word[0].all = meter_buff[9];
				buff->forward_valley_reactive_energy = tmp32.all;
				tmp32.half_word[1].all = meter_buff[10];
				tmp32.half_word[0].all = meter_buff[11];
				buff->backward_total_reactive_energy = tmp32.all;
				tmp32.half_word[1].all = meter_buff[12];
				tmp32.half_word[0].all = meter_buff[13];
				buff->backward_top_reactive_energy = tmp32.all;
				tmp32.half_word[1].all = meter_buff[14];
				tmp32.half_word[0].all = meter_buff[15];
				buff->backward_peak_reactive_energy = tmp32.all;
				tmp32.half_word[1].all = meter_buff[16];
				tmp32.half_word[0].all = meter_buff[17];
				buff->backward_flat_reactive_energy = tmp32.all;
				tmp32.half_word[1].all = meter_buff[18];
				tmp32.half_word[0].all = meter_buff[19];
				buff->backward_valley_reactive_energy = tmp32.all;
			}
			break;
		case 7:
			if(ret == len)
			{
				BIT_SET(flag, 1);
				tmp32.half_word[1].all = meter_buff[0];
				tmp32.half_word[0].all = meter_buff[1];
				buff->backward_total_active_energy = tmp32.all;
				tmp32.half_word[1].all = meter_buff[2];
				tmp32.half_word[0].all = meter_buff[3];
				buff->backward_top_active_energy = tmp32.all;
				tmp32.half_word[1].all = meter_buff[4];
				tmp32.half_word[0].all = meter_buff[5];
				buff->backward_peak_active_energy = tmp32.all;
				tmp32.half_word[1].all = meter_buff[6];
				tmp32.half_word[0].all = meter_buff[7];
				buff->backward_flat_active_energy = tmp32.all;
				tmp32.half_word[1].all = meter_buff[8];
				tmp32.half_word[0].all = meter_buff[9];
				buff->backward_valley_active_energy = tmp32.all;
			}
			break;
		default:
			BIT_SET(flag, 2);
			break;
	}
	return flag;
}

/******************************************************************************
 * read_dtsu666_meter_data().
 * Initialize metering meter debug module. [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
uint8_t read_dtsu666_meter_data(rs485_settting_parm_t rs485_parm, uint8_t index, metering_meter_t* buff)
{
	int32_t ret = -1;
	uint8_t flag = 0;
	uint16_t len;
	uint16_t addr;

	sdk_modbus_slave_set(rs485_parm.port, rs485_parm.slave_addr);
	if(index >= DTSU666_DATA_SEGMENT_NUM)
	{
		BIT_SET(flag, 2);
		return flag;
	}
	len = dtsu666_point_table[index].len;
	addr = dtsu666_point_table[index].addr;
	ret = sdk_modbus_registers_read(rs485_parm.port, addr, len, meter_buff);
	switch (index)
	{
		case 0:
			if(ret == len)
			{
				BIT_SET(flag, 0);
				buff->volt_r = uint32_to_float(meter_buff[0], meter_buff[1]) * rs485_parm.vol_ratio * PARAMETER_ACCURACY_MAGNIFICATION_4;
				buff->volt_s = uint32_to_float(meter_buff[2], meter_buff[3]) * rs485_parm.vol_ratio * PARAMETER_ACCURACY_MAGNIFICATION_4;
				buff->volt_t = uint32_to_float(meter_buff[4], meter_buff[5]) * rs485_parm.vol_ratio * PARAMETER_ACCURACY_MAGNIFICATION_4;
			}
			break;
		case 1:
			if(ret == len)
			{
				BIT_SET(flag, 0);
				buff->frequency      = uint32_to_float(meter_buff[0], meter_buff[1]) * PARAMETER_ACCURACY_MAGNIFICATION_3;
			}
			break;
		case 2:
			if(ret == len)
			{
				BIT_SET(flag, 0);
				buff->current_r = uint32_to_float(meter_buff[0], meter_buff[1]) * rs485_parm.cur_ratio * PARAMETER_ACCURACY_MAGNIFICATION_2;
				buff->current_s = uint32_to_float(meter_buff[2], meter_buff[3]) * rs485_parm.cur_ratio * PARAMETER_ACCURACY_MAGNIFICATION_2;
				buff->current_t = uint32_to_float(meter_buff[4], meter_buff[5]) * rs485_parm.cur_ratio * PARAMETER_ACCURACY_MAGNIFICATION_2;
			}
			break;
		case 3:
			if(ret == len)
			{
				BIT_SET(flag, 0);
				buff->reactive_power   = rs485_parm.symbol * (uint32_to_float(meter_buff[0], meter_buff[1]) * rs485_parm.vol_ratio * rs485_parm.cur_ratio * PARAMETER_ACCURACY_MAGNIFICATION_1);
				buff->reactive_power_r = rs485_parm.symbol * (uint32_to_float(meter_buff[2], meter_buff[3]) * rs485_parm.vol_ratio * rs485_parm.cur_ratio * PARAMETER_ACCURACY_MAGNIFICATION_1);
				buff->reactive_power_s = rs485_parm.symbol * (uint32_to_float(meter_buff[4], meter_buff[5]) * rs485_parm.vol_ratio * rs485_parm.cur_ratio * PARAMETER_ACCURACY_MAGNIFICATION_1);
				buff->reactive_power_t = rs485_parm.symbol * (uint32_to_float(meter_buff[6], meter_buff[7]) * rs485_parm.vol_ratio * rs485_parm.cur_ratio * PARAMETER_ACCURACY_MAGNIFICATION_1);
			}
			break;
		case 4:
			if(ret == len)
			{
				BIT_SET(flag, 0);
				buff->forward_total_active_energy      = (uint32_t)(uint32_to_float(meter_buff[0], meter_buff[1]) * rs485_parm.vol_ratio * rs485_parm.cur_ratio * PARAMETER_ACCURACY_MAGNIFICATION_6);
			}
			break;
		case 5:
			if(ret == len)
			{
				BIT_SET(flag, 0);
				buff->power_factor   = rs485_parm.symbol * (uint32_to_float(meter_buff[0], meter_buff[1]) * PARAMETER_ACCURACY_MAGNIFICATION_2);
				buff->power_factor_r = rs485_parm.symbol * (uint32_to_float(meter_buff[2], meter_buff[3]) * PARAMETER_ACCURACY_MAGNIFICATION_2);
				buff->power_factor_s = rs485_parm.symbol * (uint32_to_float(meter_buff[4], meter_buff[5]) * PARAMETER_ACCURACY_MAGNIFICATION_2);
				buff->power_factor_t = rs485_parm.symbol * (uint32_to_float(meter_buff[6], meter_buff[7]) * PARAMETER_ACCURACY_MAGNIFICATION_2);
			}
			break;
		case 6:
			if(ret == len)
			{
				BIT_SET(flag, 1);
				buff->backward_total_active_energy      = (uint32_t)(uint32_to_float(meter_buff[0], meter_buff[1]) * rs485_parm.vol_ratio * rs485_parm.cur_ratio * PARAMETER_ACCURACY_MAGNIFICATION_6);
			}
			break;
		default:
			BIT_SET(flag, 2);
			break;
	}
	return flag;
}
/******************************************************************************
 * rs485_backflow_meter_modbus_init().
 * Initialize meter modbus module. [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_backflow_meter_modbus_init(void)
{
	rs485_abm_parm.port = RS485_BACKFLOW_METER;
	rs485_abm_parm.slave_addr = RS485_BACKFLOW_METER_SLAVE_ADDR;
	rs485_abm_parm.baud = MODBUS_BAUD_9600;
	rs485_abm_parm.timeout = 300;
	rs485_abm_parm.parm_init_flag = FALSE;
	modbus_init(rs485_abm_parm);
}
/******************************************************************************
 * rs485_backflow_meter_init().
 * Initialize meter debug module. [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_backflow_meter_init(void)
{
//	g_backflow_meter_switch = ems.backflow_meter_switch;
	rs485_backflow_meter_modbus_init();
	fault_backflow_meter_cnt = 0;
	fault_backflow_meter_ref = 50;
	backflow_conn_count = 0;
	backflow_disconn_count = 0;
//	trigger_backflow_meter = array.pcsc.pcsc_ctrl.rs485_enable.bit.backflow_meter;
	ems.ammeter.power_up     = 0;
	ems.ammeter.power_down   = 0;
	ems.ammeter.power_factor = 0;
	clear_struct_data((uint8_t*)&pcc_meter_data, sizeof(pcc_meter_data));
}

/******************************************************************************
 * rs485_metering_meter_init().
 * Initialize metering meter debug module. [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_metering_meter_init(void)
{
	rs485_mm1_parm.port = RS485_METERING_METER;
	rs485_mm1_parm.slave_addr = RS485_METERING_METER_SLAVE_ADDR;
	rs485_mm1_parm.baud = MODBUS_BAUD_9600;
	rs485_mm1_parm.timeout = 300;
	modbus_init(rs485_mm1_parm);

	fault_metering_meter_cnt = 0;
	fault_metering_meter_ref = 40;
	meter1_disconn_count = 0;
	meter1_conn_count = 0;
//	trigger_metering_meter = array.pcsc.pcsc_ctrl.rs485_enable.bit.metering_meter;
	metering_meter1_num = 1;
	meter1_disconnect_flag = 0;
	clear_struct_data((uint8_t *)&metering_meter, sizeof(metering_meter));
}

/******************************************************************************
 * rs485_meter2_modbus_init().
 * Initialize metering meter debug module. [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_meter2_modbus_init(void)
{
	rs485_mm2_parm.port = RS485_METER_2;
	rs485_mm2_parm.slave_addr = RS485_METER_2_SLAVE_ADDR;
	rs485_mm2_parm.baud = MODBUS_BAUD_9600;
	rs485_mm2_parm.timeout = 300;
	modbus_init(rs485_mm2_parm);
}

/******************************************************************************
 * rs485_meter3_modbus_init().
 * Initialize metering meter debug module. [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_meter3_modbus_init(void)
{
	rs485_mm3_parm.port = RS485_METER_3;
	rs485_mm3_parm.slave_addr = RS485_METER_3_SLAVE_ADDR;
	rs485_mm3_parm.baud = MODBUS_BAUD_9600;
	rs485_mm3_parm.timeout = 300;
	modbus_init(rs485_mm3_parm);
}
/******************************************************************************
 * rs485_meter2_init().
 * Initialize meter2 module. [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_meter2_init(void)
{
//	g_metering_meter2_switch = xiao_ju.ammeter2_model_switch;
	rs485_meter2_modbus_init();

	fault_meter2_cnt = 0;
	fault_meter2_ref = 50;
	meter2_conn_count = 0;
	meter2_disconn_count = 0;
}
/******************************************************************************
 * rs485_meter3_init().
 * Initialize meter3 module. [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_meter3_init(void)
{
//	g_metering_meter3_switch = xiao_ju.ammeter3_model_switch;
	rs485_meter3_modbus_init();


	clear_struct_data((uint8_t*)&fault_meter3_cnt, sizeof(fault_meter3_cnt));
	if(0 == xiao_ju.ammeter3_num)
	{
		fault_meter3_ref = METERING_METER3_FAULT_THRESHOLD;
	}
	else
	{
		fault_meter3_ref = METERING_METER3_FAULT_THRESHOLD / xiao_ju.ammeter3_num;
	}
	meter3_conn_count = 0;
	meter3_disconn_count = 0;
	clear_struct_data((uint8_t*)&meter3_power_old[0], sizeof(meter3_power_old));
}

/******************************************************************************
 * rs485_pv_meter_modbus_init().
 * Initialize metering meter debug module. [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_pv_meter_modbus_init(void)
{
	rs485_pv_m_parm.port = RS485_PV_METER;
	rs485_pv_m_parm.slave_addr = RS485_PV_METER_SLAVE_ADDR;
	rs485_pv_m_parm.baud = MODBUS_BAUD_9600;
	rs485_pv_m_parm.timeout = 300;
	modbus_init(rs485_pv_m_parm);
}
/******************************************************************************
 * rs485_meter2_init().
 * Initialize meter2 module. [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_pv_meter_init(void)
{
//	g_pv_meter_switch = pv_meter_parm.pv_meter_model;
	// 先不做DLT645
	rs485_pv_meter_modbus_init();

    clear_struct_data((uint8_t*)&fault_pv_meter[0],sizeof(fault_pv_meter));
	if(0 == pv_meter_parm.pv_meter_num)
	{
		fault_pv_meter_ref = PV_METER_FAULT_THRESHOLD;
	}
	else
	{
		fault_pv_meter_ref = PV_METER_FAULT_THRESHOLD / g_pv_meter_num_record;
	}
	g_trigger_pv_meter_sw = FALSE;
	g_pv_meter_num_record = 0;
	pv_meter_conn_count = 0;
	pv_meter_disconn_count = 0;
}
/******************************************************************************
 * adl400_abm_param_init()
 * meter param init. [Called by task.]
 *
 * @param none (I)
 * @return TRUE : success / FALSE : fail
 *****************************************************************************/
bool_t adl400_abm_param_init(void)
{
	return TRUE;
}

/******************************************************************************
 * adl400_abm_power_p()
 * read activate power. [Called by task.]
 *
 * @param none (I)
 * @return TRUE : success / FALSE : fail
 *****************************************************************************/
bool_t adl400_abm_power_p(void)
{
	int32_t ret = -1;
	bool_t ret_flag = FALSE;

	ret = sdk_modbus_registers_read(RS485_BACKFLOW_METER, 0x814, 4 * HALF_WORD_LEN, meter_buff);
	if(ret > 0)
	{
		ret_flag = TRUE;
		pcc_meter_data.active_power_r = meter_cur_dir[ems.meter_current_direction.bits.meter4_cur_dir] * uint32_to_float(meter_buff[0], meter_buff[1]);
		pcc_meter_data.active_power_s = meter_cur_dir[ems.meter_current_direction.bits.meter4_cur_dir] * uint32_to_float(meter_buff[2], meter_buff[3]);
		pcc_meter_data.active_power_t = meter_cur_dir[ems.meter_current_direction.bits.meter4_cur_dir] * uint32_to_float(meter_buff[4], meter_buff[5]);
		pcc_meter_data.active_power   = meter_cur_dir[ems.meter_current_direction.bits.meter4_cur_dir] * uint32_to_float(meter_buff[6], meter_buff[7]);
		ems.ammeter.power = pcc_meter_data.active_power * PARAMETER_ACCURACY_MAGNIFICATION_6;
		if(ems.ammeter.power > 0)
		{
			ems.ammeter.power_up   =  ems.ammeter.power;
			ems.ammeter.power_down =  0;
		}
		else
		{
			ems.ammeter.power_up   =  0;
			ems.ammeter.power_down =  -ems.ammeter.power;
		}
	}

	return ret_flag;
}

/******************************************************************************
 * adl400_abm_power_q()
 * read reactivate power. [Called by task.]
 *
 * @param none (I)
 * @return TRUE : success / FALSE : fail
 *****************************************************************************/
bool_t adl400_abm_power_q(void)
{
	int32_t ret = -1;
	bool_t ret_flag = FALSE;

	ret = sdk_modbus_registers_read(RS485_BACKFLOW_METER, 0x822, HALF_WORD_LEN, meter_buff);
	if(ret > 0)
	{
		ems.ammeter.power_q = meter_cur_dir[ems.meter_current_direction.bits.meter4_cur_dir] * \
								uint32_to_float(meter_buff[0], meter_buff[1]) * PARAMETER_ACCURACY_MAGNIFICATION_6;
		ret_flag = TRUE;
	}
	return ret_flag;
}

/******************************************************************************
 * adl400_abm_power_factor()
 * read power factor. [Called by task.]
 *
 * @param none (I)
 * @return TRUE : success / FALSE : fail
 *****************************************************************************/
bool_t adl400_abm_power_factor(void)
{
	int32_t ret = -1;
	bool_t ret_flag = FALSE;

	ret = sdk_modbus_registers_read(RS485_BACKFLOW_METER, 0x832, HALF_WORD_LEN, meter_buff);
	if(ret > 0)
	{
		ems.ammeter.power_factor = meter_cur_dir[ems.meter_current_direction.bits.meter4_cur_dir] * \
									uint32_to_float(meter_buff[0], meter_buff[1]) * PARAMETER_ACCURACY_MAGNIFICATION_7;
		ret_flag = TRUE;
	}
	return ret_flag;
}
/******************************************************************************
 * adl400_anti_backflow_meter()
 * meter module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
bool_t adl400_anti_backflow_meter(void)
{
	bool_t continue_read_flag = TRUE;
	uint8_t index = 0;

	for (index = 0; ((index < BACKFLOW_METER_POINTS_NUM) && (TRUE == continue_read_flag)); index++)
	{
		continue_read_flag = adl400_abm_read_ptr[index]();
		// wait 2.5 character
		sdk_delay_ms(10);
	}
	return continue_read_flag;
}

/******************************************************************************
 * dtsu666_abm_param_init()
 * meter param init. [Called by task.]
 *
 * @param none (I)
 * @return TRUE : success / FALSE : fail
 *****************************************************************************/
bool_t dtsu666_abm_param_init(void)
{
	int32_t ret = -1;
	bool_t ret_flag = FALSE;

	ret = sdk_modbus_registers_read(RS485_BACKFLOW_METER, 0x6, 2, meter_buff);
	if(ret > 0)
	{
		backflow_conn_count++;
		ret_flag = TRUE;
		fault_backflow_meter_cnt = 0;
		ems.backflow_current_ratio = meter_buff[0];
		ems.backflow_voltage_ratio = meter_buff[1] * 0.1;
	}
	else
	{
		backflow_disconn_count++;
		sdk_modbus_flush(RS485_BACKFLOW_METER);
		if(fault_backflow_meter_cnt <= fault_backflow_meter_ref)
		{
			fault_backflow_meter_cnt++;
		}
		else
		{
			ems.ammeter.power = 0;
			ems.ammeter.power_up   =  0;
			ems.ammeter.power_down =  0;
			ems.ammeter.power_factor = 0;
		}
		ret_flag = FALSE;
	}
	return ret_flag;
}

/******************************************************************************
 * dtsu666_abm_power_p()
 * read activate power. [Called by task.]
 *
 * @param none (I)
 * @return TRUE : success / FALSE : fail
 *****************************************************************************/
bool_t dtsu666_abm_power_p(void)
{
	int32_t ret = -1;
	bool_t return_flag = FALSE;
	ret = sdk_modbus_registers_read(RS485_BACKFLOW_METER, 0x2012, 4 * HALF_WORD_LEN, meter_buff);
	if(ret > 0)
	{
		pcc_meter_data.active_power   = meter_cur_dir[ems.meter_current_direction.bits.meter4_cur_dir] * (uint32_to_float(meter_buff[0], meter_buff[1]) * ems.backflow_voltage_ratio * ems.backflow_current_ratio * PARAMETER_ACCURACY_MAGNIFICATION_1);
		pcc_meter_data.active_power_r = meter_cur_dir[ems.meter_current_direction.bits.meter4_cur_dir] * (uint32_to_float(meter_buff[2], meter_buff[3]) * ems.backflow_voltage_ratio * ems.backflow_current_ratio * PARAMETER_ACCURACY_MAGNIFICATION_1);
		pcc_meter_data.active_power_s = meter_cur_dir[ems.meter_current_direction.bits.meter4_cur_dir] * (uint32_to_float(meter_buff[4], meter_buff[5]) * ems.backflow_voltage_ratio * ems.backflow_current_ratio * PARAMETER_ACCURACY_MAGNIFICATION_1);
		pcc_meter_data.active_power_t = meter_cur_dir[ems.meter_current_direction.bits.meter4_cur_dir] * (uint32_to_float(meter_buff[6], meter_buff[7]) * ems.backflow_voltage_ratio * ems.backflow_current_ratio * PARAMETER_ACCURACY_MAGNIFICATION_1);
		ems.ammeter.power = pcc_meter_data.active_power * PARAMETER_ACCURACY_MAGNIFICATION_6;
		if(ems.ammeter.power > 0)
		{
			ems.ammeter.power_up   =  ems.ammeter.power;
			ems.ammeter.power_down =  0;
		}
		else
		{
			ems.ammeter.power_up   =  0;
			ems.ammeter.power_down =  -ems.ammeter.power;
		}
		return_flag = TRUE;
	}
	return return_flag;
}

/******************************************************************************
 * dtsu666_abm_power_q()
 * read reactivate power. [Called by task.]
 *
 * @param none (I)
 * @return TRUE : success / FALSE : fail
 *****************************************************************************/
bool_t dtsu666_abm_power_q(void)
{
	int32_t ret = -1;
	bool_t return_flag = FALSE;

	ret = sdk_modbus_registers_read(RS485_BACKFLOW_METER, 0x201A, HALF_WORD_LEN, meter_buff);
	if(ret > 0)
	{
		ems.ammeter.power_q = meter_cur_dir[ems.meter_current_direction.bits.meter4_cur_dir] * \
								uint32_to_float(meter_buff[0], meter_buff[1]) * \
								ems.backflow_voltage_ratio * \
								ems.backflow_current_ratio * \
								PARAMETER_ACCURACY_MAGNIFICATION_2;
		return_flag = TRUE;
	}

	return return_flag;
}

/******************************************************************************
 * dtsu666_abm_power_factor()
 * read power factor. [Called by task.]
 *
 * @param none (I)
 * @return TRUE : success / FALSE : fail
 *****************************************************************************/
bool_t dtsu666_abm_power_factor(void)
{
	int32_t ret = -1;
	bool_t return_flag = FALSE;

	ret = sdk_modbus_registers_read(RS485_BACKFLOW_METER, 0x202A, HALF_WORD_LEN, meter_buff);
	if(ret > 0)
	{
		ems.ammeter.power_factor = meter_cur_dir[ems.meter_current_direction.bits.meter4_cur_dir] * \
									uint32_to_float(meter_buff[0], meter_buff[1]) * \
									PARAMETER_ACCURACY_MAGNIFICATION_4;
		return_flag = TRUE;
	}

	return return_flag;
}

/******************************************************************************
 * dtsu666_anti_backflow_meter()
 * meter module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
bool_t dtsu666_anti_backflow_meter(void)
{
	bool_t continue_read_flag = TRUE;
	uint8_t index = 0;

	for (index = 0; ((index < BACKFLOW_METER_POINTS_NUM) && (TRUE == continue_read_flag)); index++)
	{
		continue_read_flag = dtsu666_abm_read_ptr[index]();
		// wait 2.5 character
		sdk_delay_ms(10);
	}
	return continue_read_flag;
}

/******************************************************************************
 * backflow_disconn_check()
 * meter module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void backflow_disconn_check(uint8_t flag)
{
	if(TRUE == flag)
	{
		backflow_conn_count++;
		fault_backflow_meter_cnt = 0;
	}
	else
	{

		backflow_disconn_count++;
		sdk_modbus_flush(RS485_BACKFLOW_METER);
		if(fault_backflow_meter_cnt <= fault_backflow_meter_ref)
		{
			fault_backflow_meter_cnt++;
		}
		else
		{
			rs485_abm_parm.parm_init_flag = FALSE;
			clear_struct_data((uint8_t*)&ems.ammeter, sizeof(ems.ammeter));
		}
	}
}
/******************************************************************************
 * rs485_task_backflow_meter()
 * meter module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_task_backflow_meter(void)
{
	bool_t ret = FALSE;
	if(TRUE == rs485_abm_parm.parm_init_flag)
	{
		// polling data
		ret = backflow_meter_fun_ptr[ems.backflow_meter_switch]();
		backflow_disconn_check(ret);
	}
	else
	{
		// Obtain the set values of the electricity meter
		// such as the slave address, voltage and current ratio
		ret = meter_model_sw(RS485_BACKFLOW_METER_SLAVE_ADDR, RS485_BACKFLOW_METER, &ems.backflow_meter_switch);
		backflow_disconn_check(ret);
		if(TRUE == ret)
		{
			rs485_abm_parm.parm_init_flag = backflow_meter_param_init_fun_ptr[ems.backflow_meter_switch]();
		}
	}
}

/******************************************************************************
 * meter2_disconn_check()
 * meter module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void meter2_disconn_check(uint8_t flag)
{
	if (TRUE == flag)
	{
		meter2_conn_count++;
		fault_meter2_cnt = 0;
	}
	else
	{
		meter2_disconn_count++;
		sdk_modbus_flush(RS485_METER_2);
		if(fault_meter2_cnt <= fault_meter2_ref)
		{
			fault_meter2_cnt++;
		}
		else
		{
			clear_struct_data((uint8_t *)&meter2_other_data[0], sizeof(meter2_other_data));
			rs485_mm2_parm.parm_init_flag = FALSE;
			xiaoju_ammeter.ammeter_2 = 0;
		}
	}
}
/******************************************************************************
 * rs485_task_meter2()
 * meter module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_task_meter2(void)
{
	bool_t ret = FALSE;
	uint16_t meter_model = 0;
	if(ONE_STORAGE_TANK_XIAOJU_1_2 == array.pcsc.pcsc_ctrl.scenario_setting)
	{
		if(TRUE == rs485_mm2_parm.parm_init_flag)
		{
			// polling data
			ret = metering_meter2_fun_ptr[xiao_ju.ammeter2_model_switch]();
			meter2_disconn_check(ret);
		}
		else
		{
			// Obtain the set values of the electricity meter
			// such as the slave address, voltage and current ratio
			ret = meter_model_sw(RS485_METER_2_SLAVE_ADDR, RS485_METER_2, &meter_model);
			xiao_ju.ammeter2_model_switch = meter_model;
			meter2_disconn_check(ret);
			if(TRUE == ret)
			{
				rs485_mm2_parm.parm_init_flag = metering_meter2_param_init_fun_ptr[xiao_ju.ammeter2_model_switch]();
			}
		}
	}
}

/******************************************************************************
 * adl400_mm2_param_init()
 * meter param init. [Called by task.]
 *
 * @param none (I)
 * @return TRUE : success / FALSE : fail
 *****************************************************************************/
bool_t adl400_mm2_param_init(void)
{
	return TRUE;
}
/******************************************************************************
 * adl400_mm2_power_p()
 * meter module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
bool adl400_mm2_power_p(void)
{
	int32_t ret = -1;
	bool_t ret_flag = FALSE;

	ret = sdk_modbus_registers_read(RS485_METER_2, 0x81A, HALF_WORD_LEN, \
																meter_buff);
	if(ret > 0)
	{
		ret_flag = TRUE;
		xiaoju_ammeter.ammeter_2 = meter_cur_dir[ems.meter_current_direction.bits.meter2_cur_dir] * \
									uint32_to_float(meter_buff[0], meter_buff[1]) * PARAMETER_ACCURACY_MAGNIFICATION_6;
	}
	return ret_flag;
}


/******************************************************************************
 * dtsu666_mm2_param_init()
 * meter param init. [Called by task.]
 *
 * @param none (I)
 * @return TRUE : success / FALSE : fail
 *****************************************************************************/
bool_t dtsu666_mm2_param_init(void)
{
	int32_t ret = -1;
	bool_t ret_flag = FALSE;

	ret = sdk_modbus_registers_read(RS485_METER_2, 0x6, 2, meter_buff);
	if(ret > 0)
	{
		meter2_conn_count++;
		fault_meter2_cnt = 0;
		ret_flag = TRUE;
		xiao_ju.ammeter2_current_ratio = meter_buff[0];
		xiao_ju.ammeter2_voltage_ratio = meter_buff[1] * 0.1;
	}
	else
	{
		meter2_disconn_count++;
		sdk_modbus_flush(RS485_METER_2);
		if(fault_meter2_cnt <= fault_meter2_ref)
		{
			fault_meter2_cnt++;
		}
		else
		{
			xiaoju_ammeter.ammeter_2 = 0;
		}
	}
	return ret_flag;
}


/******************************************************************************
 * dtsu666_mm2_power_p()
 * meter module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
bool dtsu666_mm2_power_p(void)
{
	int32_t ret = -1;
	bool_t return_flag = FALSE;

	ret = sdk_modbus_registers_read(RS485_METER_2, 0x2012, HALF_WORD_LEN, meter_buff);
	if(ret > 0)
	{
		return_flag = TRUE;
		xiaoju_ammeter.ammeter_2 = meter_cur_dir[ems.meter_current_direction.bits.meter2_cur_dir] * \
									uint32_to_float(meter_buff[0], meter_buff[1]) * \
									xiao_ju.ammeter2_voltage_ratio * \
									xiao_ju.ammeter2_current_ratio * \
									PARAMETER_ACCURACY_MAGNIFICATION_2;
	}

	return return_flag;
}

/******************************************************************************
 * meter3_disconn_check()
 * meter module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void meter3_disconn_check(float32_t power, uint8_t index, uint8_t flag)
{
	float32_t power_sum = 0;
	uint8_t i;

	if(TRUE == flag)
	{
		meter3_conn_count++;
		fault_meter3_cnt[index] = 0;
		meter3_power_old[index] = power;
		for(i = 0; i < xiao_ju.ammeter3_num; i++)
		{
			power_sum += meter3_power_old[i];
		}
		xiaoju_ammeter.ammeter_3 = power_sum;
	}
	else
	{
		meter3_disconn_count++;
		sdk_modbus_flush(RS485_METER_3);
		if(fault_meter3_cnt[index] <= fault_meter3_ref)
		{
			fault_meter3_cnt[index]++;
		}
		else
		{
			xiaoju_ammeter.ammeter_3 = 0;
			BIT_CLR(rs485_mm3_parm.parm_init_flag, index);
			clear_struct_data((uint8_t*)&meter3_power_old[index], sizeof(meter3_power_old[index]));
			clear_struct_data((uint8_t*)&meter3_other_data[index], sizeof(meter3_other_data[index]));
		}
	}
}
/******************************************************************************
 * rs485_task_meter3()
 * meter module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_task_meter3(void)
{
	static uint8_t ammeter3_num = 0;
	static uint8_t index = 0;
	bool_t ret = FALSE;
	float32_t power = 0;
	uint16_t meter_model = 0;

	if(ammeter3_num != xiao_ju.ammeter3_num)
	{
		ammeter3_num = xiao_ju.ammeter3_num;
		xiaoju_ammeter.ammeter_3 = 0;
		rs485_mm3_parm.parm_init_flag = 0;
		clear_struct_data((uint8_t*)&meter3_power_old[0], sizeof(meter3_power_old));
		clear_struct_data((uint8_t*)&fault_meter3_cnt, sizeof(fault_meter3_cnt));
		clear_struct_data((uint8_t*)meter3_other_data, sizeof(meter3_other_data));
		if(0 == xiao_ju.ammeter3_num)
		{
			fault_meter3_ref = METERING_METER3_FAULT_THRESHOLD;
		}
		else
		{
			fault_meter3_ref = METERING_METER3_FAULT_THRESHOLD / xiao_ju.ammeter3_num;
		}
		index = 0;
	}
	if(BIT_GET(rs485_mm3_parm.parm_init_flag, index))
	{
		// polling data
		ret = metering_meter3_fun_ptr[xiao_ju.ammeter3_model_switch](index, &power);
		meter3_disconn_check(power, index, ret);
	}
	else
	{
		// Obtain the set values of the electricity meter
		// such as the slave address, voltage and current ratio
		ret = meter_model_sw(index + 1, RS485_METER_3, &meter_model);
		xiao_ju.ammeter3_model_switch = meter_model;
		meter3_disconn_check(power, index, ret);
		if(TRUE == ret)
		{
			metering_meter3_param_init_fun_ptr[xiao_ju.ammeter3_model_switch](index);
		}
	}
	index++;
	if(index >= ammeter3_num)
	{
		index = 0;
	}
}

/******************************************************************************
 * adl400_mm3_param_init()
 * meter param init. [Called by task.]
 *
 * @param none (I)
 * @return TRUE : success / FALSE : fail
 *****************************************************************************/
bool_t adl400_mm3_param_init(uint8_t index)
{
	BIT_SET(rs485_mm3_parm.parm_init_flag, index);
	return TRUE;
}
/******************************************************************************
 * adl400_mm2_power_p()
 * meter module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
bool adl400_mm3_power_p(uint8_t index, float32_t *power_tmp)
{
	int32_t ret = -1;
	uint8_t data[6] = {0x01, 0x03, 0x08, 0x1A, 0x00, 0x02};
	uint8_t *p_data = NULL;
	bool_t ret_flag = FALSE;

	p_data = (uint8_t*)&meter_buff[0];

	data[0] = index + 1;
	sdk_modbus_slave_set(RS485_METER_3, data[0]);
	sdk_modbus_write(RS485_METER_3, &data[0], 6);
	ret = sdk_modbus_receive_confirmation(RS485_METER_3, &p_data[0]);
	if((ret > 0) && (data[0] == p_data[0]))
	{
		ret_flag = TRUE;
		*power_tmp = meter_cur_dir[ems.meter_current_direction.bits.meter3_cur_dir] * \
									uint32_to_float_2(&p_data[3]) * PARAMETER_ACCURACY_MAGNIFICATION_6;
	}

	return ret_flag;
}

/******************************************************************************
 * dtsu666_mm3_param_init()
 * meter param init. [Called by task.]
 *
 * @param none (I)
 * @return TRUE : success / FALSE : fail
 *****************************************************************************/
bool_t dtsu666_mm3_param_init(uint8_t index)
{
	int32_t ret = -1;
	bool_t ret_flag = FALSE;

	sdk_modbus_slave_set(RS485_METER_3, index + 1);
	ret = sdk_modbus_registers_read(RS485_METER_3, 0x6, 2, meter_buff);
	if(ret > 0)
	{
		meter3_conn_count++;
		fault_meter3_cnt[index] = 0;
		ret_flag = TRUE;
		xiao_ju.ammeter3_current_ratio[index] = meter_buff[0];
		xiao_ju.ammeter3_voltage_ratio[index] = meter_buff[1] * 0.1;
		BIT_SET(rs485_mm3_parm.parm_init_flag, index);
	}
	else
	{
		meter3_disconn_count++;
		sdk_modbus_flush(RS485_METER_3);
		if(fault_meter3_cnt[index] <= fault_meter3_ref)
		{
			fault_meter3_cnt[index]++;
		}
		else
		{
			BIT_CLR(rs485_mm3_parm.parm_init_flag, index);
			clear_struct_data((uint8_t*)&meter3_other_data[index], sizeof(meter3_other_data[index]));
			xiaoju_ammeter.ammeter_3 = 0;
		}
	}
	return ret_flag;
}


/******************************************************************************
 * dtsu666_mm2_power_p()
 * meter module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
bool dtsu666_mm3_power_p(uint8_t index, float32_t *power_tmp)
{
	int32_t ret = -1;
	uint8_t data[6] = {0x01, 0x03, 0x20, 0x12, 0x00, 0x02};
	uint8_t *p_data = NULL;
	bool_t ret_flag = FALSE;

	p_data = (uint8_t*)&meter_buff[0];
	data[0] = index + 1;
	sdk_modbus_slave_set(RS485_METER_3, data[0]);
	sdk_modbus_write(RS485_METER_3, &data[0], 6);
	ret = sdk_modbus_receive_confirmation(RS485_METER_3, &p_data[0]);
	if((ret > 0) && (data[0] == p_data[0]))
	{
		ret_flag = TRUE;
		*power_tmp = meter_cur_dir[ems.meter_current_direction.bits.meter3_cur_dir] * \
									uint32_to_float_2(&p_data[3]) * \
									xiao_ju.ammeter3_voltage_ratio[index] * \
									xiao_ju.ammeter3_current_ratio[index] * \
									PARAMETER_ACCURACY_MAGNIFICATION_2;
	}
	return ret_flag;
}

/******************************************************************************
 * rs485_task_mm_power()
 * meter module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_task_mm_power(void)
{
	int32_t conn_flag = FALSE;
	static uint8_t meter_index = 0;

	// rs485_mm1_parm.symbol = meter_cur_dir[ems.meter_current_direction.bits.meter1_cur_dir];
	sdk_modbus_slave_set(RS485_METERING_METER, meter_index + 1);
	conn_flag = sdk_modbus_registers_read(RS485_METERING_METER, 0x814, 4 * HALF_WORD_LEN, \
																meter_buff);
	if(conn_flag > 0)
	{
		meter1_conn_count++;
		BIT_CLR(meter1_disconnect_flag, meter_index);
		if(0 == meter1_disconnect_flag)
		{
			fault_metering_meter_cnt = 0;
		}
		metering_meter[meter_index].active_power_r = meter_cur_dir[ems.meter_current_direction.bits.meter1_cur_dir] * uint32_to_float(meter_buff[0], meter_buff[1]);
		metering_meter[meter_index].active_power_s = meter_cur_dir[ems.meter_current_direction.bits.meter1_cur_dir] * uint32_to_float(meter_buff[2], meter_buff[3]);
		metering_meter[meter_index].active_power_t = meter_cur_dir[ems.meter_current_direction.bits.meter1_cur_dir] * uint32_to_float(meter_buff[4], meter_buff[5]);
		metering_meter[meter_index].active_power   = meter_cur_dir[ems.meter_current_direction.bits.meter1_cur_dir] * uint32_to_float(meter_buff[6], meter_buff[7]);
	}
	else
	{
		meter1_disconn_count++;
		sdk_modbus_flush(RS485_METERING_METER);
		BIT_SET(meter1_disconnect_flag, meter_index);
		if(fault_metering_meter_cnt <= fault_metering_meter_ref)
		{
			fault_metering_meter_cnt++;
		}
		else
		{
			clear_struct_data((uint8_t *)&metering_meter, sizeof(metering_meter));
		}
	}
	meter_index++;
	if(meter_index >= metering_meter1_num)
	{
		meter_index = 0;
	}
}
/******************************************************************************
 * rs485_task_metering_meter()
 * meter module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_task_metering_meter(void)
{
	uint8_t conn_flag = FALSE;
	static uint8_t index = 0;
	uint8_t meter_index = 0;

	meter_index = rs485_mm1_parm.slave_addr - 1;
	rs485_mm1_parm.symbol = meter_cur_dir[ems.meter_current_direction.bits.meter1_cur_dir];
	conn_flag = read_adl400_meter_data(rs485_mm1_parm, index, &metering_meter[meter_index]);

	if(0 == conn_flag)
	{
		meter1_disconn_count++;
		sdk_modbus_flush(RS485_METERING_METER);
		BIT_SET(meter1_disconnect_flag, meter_index);
		if(fault_metering_meter_cnt <= fault_metering_meter_ref)
		{
			fault_metering_meter_cnt++;
		}
		else
		{
			clear_struct_data((uint8_t *)&metering_meter, sizeof(metering_meter));
		}
	}
	else
	{
		meter1_conn_count++;
		BIT_CLR(meter1_disconnect_flag, meter_index);
		if(0 == meter1_disconnect_flag)
		{
			fault_metering_meter_cnt = 0;
		}
		if(TRUE == BIT_GET(conn_flag, 1))
		{
			rs485_mm1_parm.slave_addr++;
			index = 0;
		}
		else
		{
			index++;
		}
	}

	if(rs485_mm1_parm.slave_addr > metering_meter1_num)
	{
		rs485_mm1_parm.slave_addr = 1;
	}
}

/******************************************************************************
 * clear_metering_data()
 * clear metering data. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void clear_metering_data(void)
{
	uint8_t data[9] = {RS485_METERING_METER_SLAVE_ADDR, 0xAA, 0x00, 0x01, 0x00, 0x01, 0x02, 0x00, 0x00};

	if(product_info.model_num == POWER_MAGIC_400V)
	{
		trigger_metering_meter = FALSE;
		sdk_modbus_write(RS485_METERING_METER, &data[0], sizeof(data));
		sdk_modbus_receive_confirmation(RS485_METERING_METER, (uint8_t*)&data[0]);
		trigger_metering_meter = array.pcsc.pcsc_ctrl.rs485_enable.bit.metering_meter;
	}
}

/******************************************************************************
 * clear_backflow_data()
 * clear backflow meter data. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void clear_backflow_data(void)
{
	uint8_t data[9] = {RS485_BACKFLOW_METER_SLAVE_ADDR, 0xAA, 0x00, 0x01, 0x00, 0x01, 0x02, 0x00, 0x00};

	trigger_backflow_meter = FALSE;
	sdk_modbus_write(RS485_BACKFLOW_METER, &data[0], sizeof(data));
	sdk_modbus_receive_confirmation(RS485_BACKFLOW_METER, (uint8_t*)&data[0]);
	trigger_backflow_meter = array.pcsc.pcsc_ctrl.rs485_enable.bit.backflow_meter;
}
/******************************************************************************
 * rs485_task_meter2_other()
 * meter module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_task_meter2_other(void)
{
	uint8_t conn_flag = FALSE;
	static uint8_t index = 0;
	bool_t clac_apparent_power = FALSE;
	if(rs485_mm2_parm.parm_init_flag)
	{
		rs485_mm2_parm.symbol = meter_cur_dir[ems.meter_current_direction.bits.meter2_cur_dir];
		rs485_mm2_parm.cur_ratio = xiao_ju.ammeter2_current_ratio;
		rs485_mm2_parm.vol_ratio = xiao_ju.ammeter2_voltage_ratio;

		conn_flag = read_meter_data[xiao_ju.ammeter2_model_switch](rs485_mm2_parm, index, &meter2_other_data[0]);

		if(0 == conn_flag)
		{
			meter2_disconn_count++;
			sdk_modbus_flush(rs485_mm2_parm.port);
			if(fault_meter2_cnt <= fault_meter2_ref)
			{
				fault_meter2_cnt++;
			}
			else
			{
				clear_struct_data((uint8_t *)&meter2_other_data[0], sizeof(meter2_other_data));
			}
		}
		else
		{
			meter2_conn_count++;
			fault_meter2_cnt = 0;
			if(TRUE == BIT_GET(conn_flag, 1))
			{
				clac_apparent_power = TRUE;
				index = 0;
			}
			else
			{
				index++;
			}
		}
	}

	if(clac_apparent_power && (DTSU666 == xiao_ju.ammeter2_model_switch))
	{
		meter2_other_data[0].apparent_power   = calc_vector_modulus(meter2_other_data[0].active_power, meter2_other_data[0].reactive_power);
		meter2_other_data[0].apparent_power_r = calc_vector_modulus(meter2_other_data[0].active_power_r, meter2_other_data[0].reactive_power_r);
		meter2_other_data[0].apparent_power_s = calc_vector_modulus(meter2_other_data[0].active_power_s, meter2_other_data[0].reactive_power_s);
		meter2_other_data[0].apparent_power_t = calc_vector_modulus(meter2_other_data[0].active_power_t, meter2_other_data[0].reactive_power_t);
	}
}

/******************************************************************************
 * pv_meter_disconn_check()
 * meter module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void pv_meter_disconn_check(uint8_t flag, uint8_t meter_index, uint8_t *point_index)
{
	bool_t clac_apparent_power = FALSE;
	if(0 == flag)
	{
		pv_meter_disconn_count++;
		sdk_modbus_flush(rs485_pv_m_parm.port);
		if(fault_pv_meter_cnt[meter_index] <= fault_pv_meter_ref)
		{
			fault_pv_meter_cnt[meter_index]++;
		}
		else
		{
			BIT_CLR(rs485_pv_m_parm.parm_init_flag, meter_index);
			clear_struct_data((uint8_t *)&meter2_other_data[meter_index], sizeof(meter2_other_data[meter_index]));
			rs485_pv_m_parm.slave_addr++;
			*point_index = 0;
		}
	}
	else if((BIT_GET(flag, 0)) || (BIT_GET(flag, 1)))
	{
		pv_meter_conn_count++;
		fault_pv_meter_cnt[meter_index] = 0;
	}
	else{}
	if((BIT_GET(flag, 1)) || (BIT_GET(flag, 2)))
	{
		clac_apparent_power = TRUE;
		rs485_pv_m_parm.slave_addr++;
		*point_index = 0;
	}
	if(clac_apparent_power && (DTSU666 == pv_meter_parm.pv_meter_model))
	{
		meter2_other_data[meter_index].apparent_power   = calc_vector_modulus(meter2_other_data[meter_index].active_power, meter2_other_data[meter_index].reactive_power);
		meter2_other_data[meter_index].apparent_power_r = calc_vector_modulus(meter2_other_data[meter_index].active_power_r, meter2_other_data[meter_index].reactive_power_r);
		meter2_other_data[meter_index].apparent_power_s = calc_vector_modulus(meter2_other_data[meter_index].active_power_s, meter2_other_data[meter_index].reactive_power_s);
		meter2_other_data[meter_index].apparent_power_t = calc_vector_modulus(meter2_other_data[meter_index].active_power_t, meter2_other_data[meter_index].reactive_power_t);
	}
}

/******************************************************************************
 * adl400_pv_m_power_p()
 * meter module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
bool adl400_pv_m_power_p(uint8_t index)
{
	int32_t ret = -1;
	bool_t ret_flag = FALSE;

	sdk_modbus_slave_set(RS485_PV_METER, index + 1);
	ret = sdk_modbus_registers_read(RS485_PV_METER, 0x814, 4 * HALF_WORD_LEN, \
																meter_buff);
	if(ret > 0)
	{
		ret_flag = TRUE;
		meter2_other_data[index].active_power_r = meter_cur_dir[ems.meter_current_direction.bits.meter2_cur_dir] * uint32_to_float(meter_buff[0], meter_buff[1]);
		meter2_other_data[index].active_power_s = meter_cur_dir[ems.meter_current_direction.bits.meter2_cur_dir] * uint32_to_float(meter_buff[2], meter_buff[3]);
		meter2_other_data[index].active_power_t = meter_cur_dir[ems.meter_current_direction.bits.meter2_cur_dir] * uint32_to_float(meter_buff[4], meter_buff[5]);
		meter2_other_data[index].active_power   = meter_cur_dir[ems.meter_current_direction.bits.meter2_cur_dir] * uint32_to_float(meter_buff[6], meter_buff[7]);
	}
	return ret_flag;
}
/******************************************************************************
 * dtsu666_pv_m_power_p()
 * meter module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
bool dtsu666_pv_m_power_p(uint8_t index)
{
	int32_t ret = -1;
	bool_t return_flag = FALSE;

	sdk_modbus_slave_set(RS485_PV_METER, index + 1);
	ret = sdk_modbus_registers_read(RS485_PV_METER, 0x2012, 4 * HALF_WORD_LEN, meter_buff);
	if(ret > 0)
	{
		return_flag = TRUE;
		meter2_other_data[index].active_power   = meter_cur_dir[ems.meter_current_direction.bits.meter2_cur_dir] * \
													(uint32_to_float(meter_buff[0], meter_buff[1]) * \
													pv_meter_parm.pv_meter_vol_ratio[index] * \
													pv_meter_parm.pv_meter_cur_ratio[index] * \
													PARAMETER_ACCURACY_MAGNIFICATION_1);
		meter2_other_data[index].active_power_r = meter_cur_dir[ems.meter_current_direction.bits.meter2_cur_dir] * \
													(uint32_to_float(meter_buff[2], meter_buff[3]) * \
													pv_meter_parm.pv_meter_vol_ratio[index] * \
													pv_meter_parm.pv_meter_cur_ratio[index] * \
													PARAMETER_ACCURACY_MAGNIFICATION_1);
		meter2_other_data[index].active_power_s = meter_cur_dir[ems.meter_current_direction.bits.meter2_cur_dir] * \
													(uint32_to_float(meter_buff[4], meter_buff[5]) * \
													pv_meter_parm.pv_meter_vol_ratio[index] * \
													pv_meter_parm.pv_meter_cur_ratio[index] * \
													PARAMETER_ACCURACY_MAGNIFICATION_1);
		meter2_other_data[index].active_power_t = meter_cur_dir[ems.meter_current_direction.bits.meter2_cur_dir] * \
													(uint32_to_float(meter_buff[6], meter_buff[7]) * \
													pv_meter_parm.pv_meter_vol_ratio[index] * \
													pv_meter_parm.pv_meter_cur_ratio[index] * \
													PARAMETER_ACCURACY_MAGNIFICATION_1);
	}

	return return_flag;
}
/******************************************************************************
 * rs485_task_pv_power()
 * meter module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_task_pv_power(void)
{
	static uint8_t index = 0;
	bool_t conn_flag = FALSE;
	uint8_t point_index = 0;

	if(BIT_GET(rs485_pv_m_parm.parm_init_flag, index))
	{
		// polling data
		conn_flag = pv_meter_fun_ptr[pv_meter_parm.pv_meter_model](index);
		pv_meter_disconn_check(conn_flag, index, &point_index);
	}
	index++;
	if(index >= pv_meter_parm.pv_meter_num)
	{
		index = 0;
	}
}
/******************************************************************************
 * rs485_task_pv_meter()
 * meter module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_task_pv_meter(void)
{
	uint8_t conn_flag = FALSE;
	static uint8_t index = 0;
	uint8_t meter_index = 0;
	uint8_t i;

	if(g_pv_meter_num_record != pv_meter_parm.pv_meter_num)
	{
		clear_struct_data((uint8_t*)&meter2_other_data[0], sizeof(meter2_other_data));
		clear_struct_data((uint8_t *)&fault_pv_meter_cnt, sizeof(fault_pv_meter_cnt));
		clear_struct_data((uint8_t *)&fault_pv_meter, sizeof(fault_pv_meter));
		clear_struct_data((uint8_t *)&g_trigger_pv_meter, sizeof(g_trigger_pv_meter));
		g_pv_meter_num_record = pv_meter_parm.pv_meter_num;
		for(i = 0; i < g_pv_meter_num_record; i++)
		{
			g_trigger_pv_meter[i] = TRUE;
		}
		if(0 == pv_meter_parm.pv_meter_num)
		{
			fault_pv_meter_ref = PV_METER_FAULT_THRESHOLD;
		}
		else
		{
			fault_pv_meter_ref = PV_METER_FAULT_THRESHOLD / g_pv_meter_num_record;
		}
		rs485_pv_m_parm.parm_init_flag = 0;
		meter_index = 0;
		index = 0;
	}

	if(pv_meter_parm.pv_meter_num == 0)
	{
		return;
	}
	meter_index = rs485_pv_m_parm.slave_addr - 1;
	if(BIT_GET(rs485_pv_m_parm.parm_init_flag, meter_index))
	{
		rs485_pv_m_parm.symbol = meter_cur_dir[ems.meter_current_direction.bits.meter2_cur_dir];
		rs485_pv_m_parm.vol_ratio = pv_meter_parm.pv_meter_vol_ratio[meter_index];
		rs485_pv_m_parm.cur_ratio = pv_meter_parm.pv_meter_cur_ratio[meter_index];
		conn_flag = read_meter_data[pv_meter_parm.pv_meter_model](rs485_pv_m_parm, index++, &meter2_other_data[meter_index]);
		pv_meter_disconn_check(conn_flag, meter_index, &index);
	}
	else
	{
		conn_flag = meter_model_sw(meter_index + 1, RS485_PV_METER, &pv_meter_parm.pv_meter_model);
		pv_meter_disconn_check(conn_flag, meter_index, &index);
		if(FALSE != conn_flag)
		{
			pv_meter_param_init_fun_ptr[pv_meter_parm.pv_meter_model](meter_index);
		}
	}

	if(rs485_pv_m_parm.slave_addr > pv_meter_parm.pv_meter_num)
	{
		rs485_pv_m_parm.slave_addr = 1;
	}

}
/******************************************************************************
 * rs485_task_meter3_other()
 * meter module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_task_meter3_other(void)
{
	uint8_t conn_flag = FALSE;
	static uint8_t index = 0;
	uint8_t meter_index = 0;
	bool_t clac_apparent_power = FALSE;

	meter_index = rs485_mm3_parm.slave_addr - 1;
	if(BIT_GET(rs485_mm3_parm.parm_init_flag, meter_index))
	{
		rs485_mm3_parm.symbol = meter_cur_dir[ems.meter_current_direction.bits.meter3_cur_dir];
		rs485_mm3_parm.cur_ratio = xiao_ju.ammeter3_current_ratio[meter_index];
		rs485_mm3_parm.vol_ratio = xiao_ju.ammeter3_voltage_ratio[meter_index];
		conn_flag = read_meter_data[xiao_ju.ammeter3_model_switch](rs485_mm3_parm, index, &meter3_other_data[meter_index]);
		if(0 == conn_flag)
		{
			meter3_disconn_count++;
			sdk_modbus_flush(RS485_METER_3);
			if(fault_meter3_cnt[meter_index] <= fault_meter3_ref)
			{
				fault_meter3_cnt[meter_index]++;
			}
			else
			{
				BIT_CLR(rs485_mm3_parm.parm_init_flag, meter_index);
				clear_struct_data((uint8_t *)&meter3_other_data[meter_index], sizeof(meter3_other_data[meter_index]));
			}
		}
		else if(BIT_GET(conn_flag, 0) || BIT_GET(conn_flag, 1))
		{
			clac_apparent_power = TRUE;
			meter3_conn_count++;
			fault_meter3_cnt[meter_index] = 0;
		}
		else{}
		index++;
		if(BIT_GET(conn_flag, 1) || BIT_GET(conn_flag, 2))
		{
			rs485_mm3_parm.slave_addr++;
			index = 0;
		}

		if(clac_apparent_power && (DTSU666 == xiao_ju.ammeter3_model_switch))
		{
			meter3_other_data[meter_index].apparent_power   = calc_vector_modulus(meter3_other_data[meter_index].active_power, meter3_other_data[meter_index].reactive_power);
			meter3_other_data[meter_index].apparent_power_r = calc_vector_modulus(meter3_other_data[meter_index].active_power_r, meter3_other_data[meter_index].reactive_power_r);
			meter3_other_data[meter_index].apparent_power_s = calc_vector_modulus(meter3_other_data[meter_index].active_power_s, meter3_other_data[meter_index].reactive_power_s);
			meter3_other_data[meter_index].apparent_power_t = calc_vector_modulus(meter3_other_data[meter_index].active_power_t, meter3_other_data[meter_index].reactive_power_t);
		}
	}
	else
	{
		rs485_mm3_parm.slave_addr++;
		index = 0;
	}

	if(rs485_mm3_parm.slave_addr > xiao_ju.ammeter3_num)
	{
		rs485_mm3_parm.slave_addr = 1;
	}

}

/******************************************************************************
 * adl400_pv_m_param_init()
 * meter param init. [Called by task.]
 *
 * @param none (I)
 * @return TRUE : success / FALSE : fail
 *****************************************************************************/
bool_t adl400_pv_m_param_init(uint8_t index)
{
	BIT_SET(rs485_pv_m_parm.parm_init_flag, index);
	return TRUE;
}
/******************************************************************************
 * dtsu666_pv_m_param_init()
 * meter param init. [Called by task.]
 *
 * @param none (I)
 * @return TRUE : success / FALSE : fail
 *****************************************************************************/
bool_t dtsu666_pv_m_param_init(uint8_t index)
{
	int32_t ret = -1;
	bool_t ret_flag = FALSE;

	sdk_modbus_slave_set(RS485_PV_METER, index + 1);
	ret = sdk_modbus_registers_read(RS485_PV_METER, 0x6, 2, meter_buff);
	if(ret > 0)
	{
		pv_meter_conn_count++;
		fault_pv_meter_cnt[index] = 0;
		ret_flag = TRUE;
		pv_meter_parm.pv_meter_cur_ratio[index] = meter_buff[0];
		pv_meter_parm.pv_meter_vol_ratio[index] = meter_buff[1] * 0.1;
		BIT_SET(rs485_pv_m_parm.parm_init_flag, index);
	}
	else
	{
		pv_meter_disconn_count++;
		sdk_modbus_flush(RS485_PV_METER);
		if(fault_pv_meter_cnt[index] <= fault_pv_meter_ref)
		{
			fault_pv_meter_cnt[index]++;
		}
		else
		{
			BIT_CLR(rs485_pv_m_parm.parm_init_flag, index);
			clear_struct_data((uint8_t*)&meter2_other_data[index], sizeof(meter2_other_data[index]));
		}
	}
	return ret_flag;
}


/******************************************************************************
 * rs485_task_pcc_meter_data()
 * meter module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_task_pcc_meter_data(void)
{
	uint8_t conn_flag = FALSE;
	static uint8_t index = 0;
	bool_t clac_apparent_power = FALSE;
	if(rs485_abm_parm.parm_init_flag)
	{
		rs485_abm_parm.symbol = meter_cur_dir[ems.meter_current_direction.bits.meter4_cur_dir];
		rs485_abm_parm.cur_ratio = ems.backflow_current_ratio;
		rs485_abm_parm.vol_ratio = ems.backflow_voltage_ratio;

		conn_flag = read_meter_data[ems.backflow_meter_switch](rs485_abm_parm, index, &pcc_meter_data);

		if(0 == conn_flag)
		{
			backflow_disconn_count++;
			sdk_modbus_flush(rs485_abm_parm.port);
			if(fault_backflow_meter_cnt <= fault_backflow_meter_ref)
			{
				fault_backflow_meter_cnt++;
			}
			else
			{
				clear_struct_data((uint8_t *)&pcc_meter_data, sizeof(pcc_meter_data));
			}
		}
		else
		{
			backflow_conn_count++;
			fault_backflow_meter_cnt = 0;
			if(TRUE == BIT_GET(conn_flag, 1))
			{
				clac_apparent_power = TRUE;
				index = 0;
			}
			else
			{
				index++;
			}
		}
	}

	if(clac_apparent_power && (DTSU666 == ems.backflow_meter_switch))
	{
		pcc_meter_data.apparent_power   = calc_vector_modulus(pcc_meter_data.active_power, pcc_meter_data.reactive_power);
		pcc_meter_data.apparent_power_r = calc_vector_modulus(pcc_meter_data.active_power_r, pcc_meter_data.reactive_power_r);
		pcc_meter_data.apparent_power_s = calc_vector_modulus(pcc_meter_data.active_power_s, pcc_meter_data.reactive_power_s);
		pcc_meter_data.apparent_power_t = calc_vector_modulus(pcc_meter_data.active_power_t, pcc_meter_data.reactive_power_t);
	}
}
/******************************************************************************
* End of module
******************************************************************************/
