/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     safe_parm.c
  * @brief
  * @company  SOFARSOLAR
  * @author   GZQ
  * @note
  * @version  V01
  * @date     2023/03/09
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "cup_sofar_can.h"
#include "device.h"
#include "pcs.h"
#include "safe_parm.h"
#include "sdk.h"
#include "sdk_core.h"
#include "setting.h"
#include "fifo_can.h"
#include "array.h"
#ifdef EBI_1725K
#include "can5_bus.h"
#endif

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
// bytes
#define ONE_SAFE_PARM_LEN                                                   128

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
#ifdef EBI_1725K
uint8_t safe_parm_send_cnt = 1;
safe_para_checksum_t checksum_temp;
uint8_t send_data[ONE_SAFE_PARM_LEN];
static uint8_t g_sp_cnt;
bool_t  trigger_sp_send = FALSE;  // trigger safe parameter transmit
bool_t g_trigger_safe_para = FALSE;
bool_t g_safe_para_arm_chksum = FALSE;
#endif

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/
/******************************************************************************
 * safe_parm_init().
 * . [Called by app.]
 * @return none
 *****************************************************************************/
void safe_parm_init(void)
{
#ifdef EBI_1725K
	clear_struct_data((uint8_t *)&send_data[0], sizeof(send_data));
	safe_parm_send_cnt = 1;
    g_sp_cnt = 0;
	trigger_sp_send = FALSE;
    g_trigger_safe_para = FALSE;
    g_safe_para_arm_chksum = FALSE;
    int32_t res = 0;

    res = sdk_para_read(SAFE_PARM, EE_SAFE_PARM_CHKSUM, \
								(void *)&checksum_temp, SAFE_PARM_CHKSUM_LEN);
	if (res <= 0)
	{
		// sdk_log_i("The checksum of ARM safety regulation parameters: reading failed.\r\n");
	}
	else
	{
		if(0xFFFF != checksum_temp.startup_para_checksum)
		{
			g_safe_para_arm_chksum = TRUE;
		}
	}
#endif
}

/******************************************************************************
 * safe_para_checksum().
 * . [Called by slow_task_send_safe_p.]
 * @return checksum
 *****************************************************************************/
#ifdef EBI_1725K
static uint16_t safe_para_checksum(uint8_t len , uint8_t *send_data)
{
    uint16_t check_sum = 0;
    uint16_t i;
    
    // NULL pointer protection
	if(send_data != NULL)
    {
        for(i = 0; i < len; i++)
        {
            check_sum += send_data[i];
        } 
    }   
    return check_sum;
}

/******************************************************************************
 * safe_para_checksum_check().
 * . [Called by slow_task_send_safe_p.]
 *
 * @param  checksum    (I) current clac checksum
 * @return result      (O) if checksum is the same,return TRUE
 *****************************************************************************/
static bool_t safe_para_checksum_check(safe_para_checksum_t checksum_check)
{
    bool_t result = TRUE;   
    uint8_t index;

    for(index = 0; index < PCSM_NUMS; index++)
    {
        if((checksum_check.startup_para_checksum != \
            array.pcsc.pcsc_data.pcsm_data[index].var.startup_para_checksum) ||
            (checksum_check.voltage_para_checksum != \
            array.pcsc.pcsc_data.pcsm_data[index].var.voltage_para_checksum) ||
            (checksum_check.freq_para_checksum != \
            array.pcsc.pcsc_data.pcsm_data[index].var.freq_para_checksum)    ||
            (checksum_check.dci_para_checksum != \
            array.pcsc.pcsc_data.pcsm_data[index].var.dci_para_checksum)     ||
            (checksum_check.remote_active_para_checksum != \
            array.pcsc.pcsc_data.pcsm_data[index].var.remote_active_para_checksum) ||
            (checksum_check.freq_active_para_checksum != \
            array.pcsc.pcsc_data.pcsm_data[index].var.freq_active_para_checksum)   ||
            (checksum_check.reactive_para_checksum != \
            array.pcsc.pcsc_data.pcsm_data[index].var.reactive_para_checksum)      ||
            (checksum_check.volt_cross_para_checksum != \
            array.pcsc.pcsc_data.pcsm_data[index].var.volt_cross_para_checksum)    ||
            (checksum_check.iso_anti_island_para_checksum != \
            array.pcsc.pcsc_data.pcsm_data[index].var.iso_anti_island_para_checksum)) 
        {
            result = FALSE;
        }
    }
    
    return result;   
}

/******************************************************************************
 * safe_parm_send_2_pcs().
 * . [Called by app.]
 *
 * @param  offset    (I) safe parm offset
 * @return none
 *****************************************************************************/
void safe_parm_send_2_pcs(uint16_t offset)
{
	int32_t res;
	can_id_t frame;
    uint8_t temp[ONE_SAFE_PARM_LEN];
    uint8_t i;

    clear_struct_data(&temp[0], ONE_SAFE_PARM_LEN);
	res = setting_get(SAFE_PARM, offset, &temp[0], ONE_SAFE_PARM_LEN);

	if(res > 0)
	{
        for(i = 0; i < ONE_SAFE_PARM_LEN; i += 2)
        {
            send_data[i + 1] = temp[i];
            send_data[i]     = temp[i + 1];
        }
		frame.src_addr = CSU_MCU2;
		frame.src_type = DEVICE_CSU;
		frame.dst_addr = 0;
		frame.dst_type = DEVICE_PCS;
		frame.fun_code = PCS_CMD_SET_SAFE_PARAMETER;
		frame.type = 1;
		frame.prio = 6;

		frame.addr = offset - EE_SAFE_PARM_GRP1;

		cup_sofar_can_send(CAN5_PORT, &frame, &send_data[0], ONE_SAFE_PARM_LEN);
		pause_fifo_can5_pop = TRUE;
	}
}

/******************************************************************************
 * slow_task_send_safe_p().
 * safe parameter transmit to pcsm. [Called by app.]
 *
 * @return none
 *****************************************************************************/
void slow_task_send_safe_p(void)
{
    bool_t flag;
    pcsm_cmd_t checksum_cmd;

	switch (safe_parm_send_cnt)
	{
		case 1:
			safe_parm_send_2_pcs(EE_SAFE_PARM_GRP1);
            checksum_temp.startup_para_checksum = safe_para_checksum(ONE_SAFE_PARM_LEN, &send_data[0]);
			safe_parm_send_cnt = 2;
			break;
		case 2:
			safe_parm_send_2_pcs(EE_SAFE_PARM_GRP2);
            checksum_temp.voltage_para_checksum = safe_para_checksum(ONE_SAFE_PARM_LEN, &send_data[0]);
			safe_parm_send_cnt = 3;
			break;
		case 3:
			safe_parm_send_2_pcs(EE_SAFE_PARM_GRP3);
            checksum_temp.freq_para_checksum = safe_para_checksum(ONE_SAFE_PARM_LEN, &send_data[0]);
			safe_parm_send_cnt = 4;
			break;
		case 4:
			safe_parm_send_2_pcs(EE_SAFE_PARM_GRP4);
            checksum_temp.dci_para_checksum = safe_para_checksum(ONE_SAFE_PARM_LEN, &send_data[0]);
			safe_parm_send_cnt = 5;
			break;
		case 5:
			safe_parm_send_2_pcs(EE_SAFE_PARM_GRP5);
            checksum_temp.remote_active_para_checksum = safe_para_checksum(ONE_SAFE_PARM_LEN, &send_data[0]);
			safe_parm_send_cnt = 6;
			break;
		case 6:
			safe_parm_send_2_pcs(EE_SAFE_PARM_GRP6);
            checksum_temp.freq_active_para_checksum = safe_para_checksum(ONE_SAFE_PARM_LEN, &send_data[0]);
			safe_parm_send_cnt = 7;
			break;
		case 7:
			safe_parm_send_2_pcs(EE_SAFE_PARM_GRP7);
            checksum_temp.reactive_para_checksum = safe_para_checksum(ONE_SAFE_PARM_LEN, &send_data[0]);
			safe_parm_send_cnt = 8;
			break;
		case 8:
			safe_parm_send_2_pcs(EE_SAFE_PARM_GRP8);
            checksum_temp.volt_cross_para_checksum = safe_para_checksum(ONE_SAFE_PARM_LEN, &send_data[0]);
			safe_parm_send_cnt = 9;
			break;
		case 9:
			safe_parm_send_2_pcs(EE_SAFE_PARM_GRP9);
            checksum_temp.iso_anti_island_para_checksum = safe_para_checksum(ONE_SAFE_PARM_LEN, &send_data[0]);
//			trigger_sp_send = FALSE;
			safe_parm_send_cnt  = 10;
			break;
        case 10:
            g_sp_cnt++;
            break;
		default:
			safe_parm_send_cnt  = 1;
			break;
	}

    if(g_sp_cnt == 1)
    {
        sdk_para_write(SAFE_PARM, EE_SAFE_PARM_CHKSUM, \
								(void *)&checksum_temp, SAFE_PARM_CHKSUM_LEN);
        g_safe_para_arm_chksum = TRUE;
    }
    if(g_sp_cnt == 5)
    {
        checksum_cmd.dst_addr = 0;
        checksum_cmd.fun_code = PCS_CMD_GET_REMOTE_METERING;
        checksum_cmd.len = PCSM_REMOTE_METERING_LENGTH_4;
        checksum_cmd.offset.all = PCSM_POINT_TABLE_OFFSET_4;
        fifo_can_push(&fifo_can5_cmd, &checksum_cmd);
    }
    else if(g_sp_cnt == 10)
    {
        flag = safe_para_checksum_check(checksum_temp);
        if(flag)
        {
            safe_parm_send_cnt = 1;
            trigger_sp_send = FALSE;
        }
        else
        {
            safe_parm_send_cnt = 1;
            trigger_sp_send = TRUE;
        }
        g_sp_cnt = 0;
    }
	// TODO 上述功能，若不按1~9的顺序时将会失效
}

/******************************************************************************
 * slow_task_safe_para_chk().
 * judgment of safety regulations checksum. [Called by app.]
 *
 * @return none
 *****************************************************************************/
void slow_task_safe_para_chk(void)
 {
	int8_t ret = -1;

	ret = safe_para_checksum_check(checksum_temp);
	if(ret < 0)
	{
		trigger_sp_send = TRUE;
	}
 }

/******************************************************************************
 * slow_task_chk_set().
 * open the judgment of safety regulations checksum. [Called by app.]
 *
 * @return none
 *****************************************************************************/
void slow_task_chk_set(void)
 {
	if (PCSM_NUMS == array.array_data.variable.pcsm_online)
	{
		if (g_safe_para_arm_chksum)
		{
			g_trigger_safe_para = TRUE;
		}
		else
		{
		}
	}
	else
	{
	}
 }
#endif

/******************************************************************************
* End of module
******************************************************************************/
