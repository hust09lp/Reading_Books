/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     link_list.c
  * @brief    link list module
  * @company  SOFARSOLAR
  * @author   XYF
  * @note
  * @version  V01
  * @date     2023/03/07
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "link_list.h"
#include "device.h"
#include "sdk.h"
#include "sdk_core.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/******************************************************************************
 * list_node_init().
 * Initialize list node. [Called by App]
 *
 * @param node (I) pointer to a list node structure
 * @param fValue   (I) measure value
 * @return This is the resutling value
 *****************************************************************************/
void list_node_init(list_node_t *node)
{
	// --- pointer null protection ------
	if(node)
	{
		node->id = 0;
		node->data = NULL;
		node->next = NULL;
		node->prev = NULL;
	}
}

/******************************************************************************
 * link_list_init().
 * Initialize link list. [Called by App]
 *
 * @param node (I) pointer to a list node structure
 * @param fValue   (I) measure value
 * @return This is the resutling value
 *****************************************************************************/
void link_list_init(link_list_t *list)
{
	// --- pointer null protection ------
	if(list)
	{
		list->active_size = 0;
		list->head = NULL;
		list->tail = NULL;
	}
}

/******************************************************************************
 * link_list_add().
 * Add a new node to the tail of a link list. [Called by link_list_insert_node()]
 *
 * @param list (I) pointer to a link list structure
 * @param node (I) pointer to a list node structure
 * @return none
 *****************************************************************************/
void link_list_add(link_list_t *list, list_node_t *node)
{
	list_node_t *temp_node = NULL;

	// --- pointer null protection ------
	if(list && node)
	{
		// case: the link list is empty
		if(list->active_size == 0)
		{
			list->head = node;
			list->tail = node;
			list->active_size = 1;
		}
		// case: this is not the first item in the link list
		else
		{
			temp_node = node;
			list->tail->next = temp_node;
			temp_node->prev = list->tail;
			temp_node->next = NULL;

			list->tail = temp_node;
			list->active_size++;
		}
	}
}

/******************************************************************************
 * link_list_insert_node().
 * Insert a new node to the tail of a link list. [Called by app]
 *
 * @param list (I) pointer to a link list structure
 * @param id   (I) the new node's ID
 * @param data (I) pointer to the new node's data area
 * @return 0(no error), < 0(link list error code)
 *****************************************************************************/
LINK_LIST_ERR_E link_list_insert_node(link_list_t *list, uint8_t id, void *data, uint8_t type)
{
	list_node_t *temp_node = NULL;

	// --- pointer null protection ------
	if((list == NULL) || (data == NULL))
	{
		return LLE_NO_DATA;
	}

	//temp_node = malloc(sizeof(list_node_t));
	// ???
	temp_node = &list_sum_device[(id - 1) + (type - 1) * 8];

	// --- case memory allocation failed -----
	if((list == NULL) || (data == NULL))
	{
		return LLE_OUT_OF_MEM;
	}

	temp_node->id   = id;
	temp_node->data = data;
	temp_node->next = NULL;
	temp_node->prev = NULL;

	link_list_add(list, temp_node);

	return LLE_NO_ERR;
}

/******************************************************************************
 * link_list_del_node().
 * Delete a node in a link list. [Called by app]
 *
 * @param list (I) pointer to a link list structure
 * @param node (I) pointer to a list node structure
 * @return 0(no error), < 0(link list error code)
 *****************************************************************************/
LINK_LIST_ERR_E link_list_del_node(link_list_t *list, list_node_t *node)
{
	list_node_t *temp_node = NULL;

	// --- pointer null protection ------
	if((list == NULL) || (node == NULL))
	{
		return LLE_NO_DATA;
	}

	temp_node = link_list_find_node(list, node->id);

	// --- pointer null protection ------
	if(temp_node == NULL)
	{
		return LLE_NO_DATA;
	}

	if((temp_node != list->head) && (temp_node != list->tail))
	{
		temp_node->prev->next = temp_node->next;
		temp_node->next->prev = temp_node->prev;
	}
	else if((temp_node == list->head) && (temp_node == list->tail))
	{
		list->head = NULL;
		list->tail = NULL;
	}
	else if(temp_node == list->head)
	{
		list->head = temp_node->next;
		list->head->prev = NULL;
	}
	else if (temp_node == list->tail)
	{
		list->tail = temp_node->prev;
		list->tail->next = NULL;
	}

	if(temp_node != NULL)
	{
//		free(temp_node);
		temp_node = NULL;
	}

	if(list->active_size)
	{
		list->active_size--;
	}

	return LLE_NO_ERR;
}

/******************************************************************************
 * link_list_find_node().
 * Find the first one to match with ID in a link list, according to its id.
 * [Called by app]
 *
 * @param list (I) pointer to a link list structure
 * @param id   (I) the node's id
 * @return 0(NULL), > 0(pointer to the list node structure)
 *****************************************************************************/
list_node_t *link_list_find_node(link_list_t *list, uint8_t id)
{
	list_node_t *temp_node = NULL;
	uint8_t i;
	uint8_t size;
	bool_t  found;

	// --- pointer null protection ------ //
	if(list == NULL)
	{
		return NULL;
	}

	size = list->active_size;
	temp_node = list->head;

	for(i = 0, found = FALSE; (!found) && (i < size) && (temp_node); i++)
	{
		if(temp_node->id == id)
		{
			found = TRUE;
		}
		else
		{
			temp_node = temp_node->next;
		}
	}

	return temp_node;
}

/******************************************************************************
 * link_list_get_size().
 * Get the size of a link list. [Called by app]
 *
 * @param list (I) pointer to a link list structure
 * @return the actual size of the link list
 *****************************************************************************/
uint8_t link_list_get_size(link_list_t *list)
{
	uint8_t result = 0;

	// --- pointer null protection ------
	if(list)
	{
		result = list->active_size;
	}

	return result;
}

/******************************************************************************
 * link_list_get_head().
 * Get the head pointer of a link list. [Called by app]
 *
 * @param list (I) pointer to a link list structure
 * @return the head pointer of the link list
 *****************************************************************************/
list_node_t *link_list_get_head(link_list_t *list)
{
	list_node_t *temp_node = NULL;

	// --- pointer null protection ------
	if(list)
	{
		temp_node = list->head;
	}

	return temp_node;
}

/******************************************************************************
 * link_list_get_tail().
 * Get the tail pointer of a link list. [Called by app]
 *
 * @param list (I) pointer to a link list structure
 * @return the tail pointer of the link list
 *****************************************************************************/
list_node_t *link_list_get_tail(link_list_t *list)
{
	list_node_t *temp_node = NULL;

	// --- pointer null protection ------
	if(list)
	{
		temp_node = list->tail;
	}

	return temp_node;
}

/******************************************************************************
* End of module
******************************************************************************/
