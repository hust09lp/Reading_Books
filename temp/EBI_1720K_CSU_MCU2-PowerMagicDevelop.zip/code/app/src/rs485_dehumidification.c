/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     rs485_dehumidification.c
  * @brief    Dehumidification module
  * @company  SOFARSOLAR
  * @author   ZZJ
  * @note
  * @version  V01
  * @date     2023/09/16
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "array.h"
#include "rs485_dehumidification.h"
#include "sdk.h"
#include "sdk_core.h"
#include "pcsc_diag.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
// TODOReturn difference

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
int16_t fault_dehumidifier_cnt;
int16_t fault_dehumidifier_ref;
bool_t trigger_dehumidifier;
uint16_t dehumidifier_buff[DEHUMIDIFICATION_DATA_LEN];
dehumidifier_data_t dehumidifier_data;
dehumidifier_set_t dehumidifier_set;
rs485_settting_parm_t rs485_dehumidification_parm;
bool_t dehunidification_set_param_flag = FALSE;

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/
/******************************************************************************
 * rs485_dehumidification_init().
 * Initialize dehumidification debug module. [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_dehumidification_init(void)
{
	rs485_dehumidification_parm.port = RS485_DEHUMIDIFICATION;
	rs485_dehumidification_parm.slave_addr = RS485_DEHUMIDIFICATION_SLAVE_ADDR;
	rs485_dehumidification_parm.baud = MODBUS_BAUD_9600;
	rs485_dehumidification_parm.timeout = 300;
	modbus_init(rs485_dehumidification_parm);

	fault_dehumidifier_cnt = 0;
	fault_dehumidifier_ref = 10;
	dehunidification_set_param_flag = FALSE;
	trigger_dehumidifier = array.pcsc.pcsc_ctrl.rs485_enable.bit.dehumidifier;
	clear_struct_data((uint8_t*)&dehumidifier_buff[0], sizeof(dehumidifier_buff));
	clear_struct_data((uint8_t*)&dehumidifier_data, sizeof(dehumidifier_data));
}

/******************************************************************************
 * rs485_task_dehumidification()
 * dehumidification module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_task_dehumidification(void)
{
	int16_t ret;

	if(FALSE == dehunidification_set_param_flag)
	{
		ret = sdk_modbus_registers_read(RS485_DEHUMIDIFICATION, 0x01, DEHUMIDIFICATION_DATA_LEN, &dehumidifier_buff[0]);
		if(ret == DEHUMIDIFICATION_DATA_LEN)
		{
			fault_dehumidifier_cnt = 0;
			if(dehumidifier_buff[DEHUMIDIFICATION_AUTO_MODE_ADDR - 1] != DEHUMIDIFICATION_AUTO_MODE_VALUE)
			{
				sdk_modbus_register_write(RS485_DEHUMIDIFICATION, DEHUMIDIFICATION_AUTO_MODE_ADDR, DEHUMIDIFICATION_AUTO_MODE_VALUE);
			}
			else if(dehumidifier_buff[DEHUMIDIFICATION_RN_ADDR - 1] != dehumidifier_set.humidity_set)
			{
				sdk_modbus_register_write(RS485_DEHUMIDIFICATION, DEHUMIDIFICATION_RN_ADDR, dehumidifier_set.humidity_set);
			}
			else if(dehumidifier_buff[DEHUMIDIFICATION_RETURN_DIFFERENCE_ADDR - 1] != dehumidifier_set.humidity_diff_set)
			{
				sdk_modbus_register_write(RS485_DEHUMIDIFICATION, DEHUMIDIFICATION_RETURN_DIFFERENCE_ADDR, dehumidifier_set.humidity_diff_set);
			}
			else
			{
				dehunidification_set_param_flag = TRUE;
			}
		}
	}
	else
	{
		ret = sdk_modbus_registers_read(RS485_DEHUMIDIFICATION, 0x0C, 2, &dehumidifier_buff[0]);
		if(ret == 2)
		{
			fault_dehumidifier_cnt = 0;
			dehumidifier_data.temperature = dehumidifier_buff[0] * PARAMETER_ACCURACY_MAGNIFICATION_4;
			dehumidifier_data.humidity = dehumidifier_buff[1] * PARAMETER_ACCURACY_MAGNIFICATION_4;
		}
	}

	if (ret < 0)
	{
		sdk_modbus_flush(RS485_DEHUMIDIFICATION);
		if(fault_dehumidifier_cnt <= fault_dehumidifier_ref)
		{
			fault_dehumidifier_cnt++;
		}
		else
		{
			clear_struct_data((uint8_t*)&dehumidifier_data, sizeof(dehumidifier_data));
		}
	}

}

/******************************************************************************
* End of module
******************************************************************************/
