/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     measure.c
  * @brief    Measure module
  * @company  SOFARSOLAR
  * @author   ZHH
  * @note
  * @version  V04
  * @date     2023/06/01
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------
#include <math.h>

// Include project file ------------------------------------------------------
#include "app_dido.h"
#include "array.h"
#include "calibration.h"
#include "csu_data.h"
#include "measure.h"
#include "sdk.h"
#include "sdk_core.h"
#include "setting.h"
#include "tpll.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define MUX_DC_SEL_A_L()                            sdk_dido_write(DO8_SELA, 1)
#define MUX_DC_SEL_A_H()                            sdk_dido_write(DO8_SELA, 0)
#define MUX_DC_SEL_B_L()                            sdk_dido_write(DO9_SELB, 1)
#define MUX_DC_SEL_B_H()                            sdk_dido_write(DO9_SELB, 0)

#define CHG_DISCHG_HYSTERESIS                                              0.5f

#define BASETIME_10MS                                                       (10)

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/
typedef struct
{
	int16_t   t;   // temperature
	float32_t r;   // resistor/digital
}ntc_t;

// Time stamp for energy_meter recording
typedef struct  {
    uint8_t  tm_day;     // 1-31
    uint8_t  tm_mon;     // 1-12
    uint8_t  tm_year;    // 0-99
}record_time_t;

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/
const ntc_t board_ntc_table[] =
{// Temp  digital
	{-40, 3933.0},
	{-39, 3922.0},
	{-38, 3911.0},
	{-37, 3900.0},
	{-36, 3886.0},
	{-35, 3874.0},
	{-34, 3859.0},
	{-33, 3846.0},
	{-32, 3830.0},
	{-31, 3814.0},
	{-30, 3797.0},
	{-29, 3780.0},
	{-28, 3761.0},
	{-27, 3742.0},
	{-26, 3721.0},
	{-25, 3701.0},
	{-24, 3679.0},
	{-23, 3657.0},
	{-22, 3633.0},
	{-21, 3609.0},
	{-20, 3583.0},
	{-19, 3557.0},
	{-18, 3529.0},
	{-17, 3501.0},
	{-16, 3472.0},
	{-15, 3441.0},
	{-14, 3411.0},
	{-13, 3378.0},
	{-12, 3346.0},
	{-11, 3312.0},
	{-10, 3277.0},
	{-9 , 3241.0},
	{-8 , 3204.0},
	{-7 , 3167.0},
	{-6 , 3128.0},
	{-5 , 3088.0},
	{-4 , 3049.0},
	{-3 , 3008.0},
	{-2 , 2966.0},
	{-1 , 2924.0},
	{0  , 2881.0},
	{1  , 2837.0},
	{2  , 2793.0},
	{3  , 2748.0},
	{4  , 2703.0},
	{5  , 2657.0},
	{6  , 2612.0},
	{7  , 2565.0},
	{8  , 2518.0},
	{9  , 2472.0},
	{10 , 2425.0},
	{11 , 2378.0},
	{12 , 2331.0},
	{13 , 2283.0},
	{14 , 2236.0},
	{15 , 2189.0},
	{16 , 2142.0},
	{17 , 2095.0},
	{18 , 2048.0},
	{19 , 2002.0},
	{20 , 1956.0},
	{21 , 1911.0},
	{22 , 1865.0},
	{23 , 1821.0},
	{24 , 1777.0},
	{25 , 1733.0},
	{26 , 1690.0},
	{27 , 1647.0},
	{28 , 1605.0},
	{29 , 1564.0},
	{30 , 1523.0},
	{31 , 1483.0},
	{32 , 1444.0},
	{33 , 1405.0},
	{34 , 1367.0},
	{35 , 1330.0},
	{36 , 1293.0},
	{37 , 1258.0},
	{38 , 1223.0},
	{39 , 1189.0},
	{40 , 1155.0},
	{41 , 1122.0},
	{42 , 1091.0},
	{43 , 1059.0},
	{44 , 1029.0},
	{45 , 999.0},
	{46 , 970.0},
	{47 , 942.0},
	{48 , 915.0},
	{49 , 888.0},
	{50 , 862.0},
	{51 , 837.0},
	{52 , 812.0},
	{53 , 788.0},
	{54 , 765.0},
	{55 , 742.0},
	{56 , 721.0},
	{57 , 699.0},
	{58 , 679.0},
	{59 , 658.0},
	{60 , 639.0},
	{61 , 620.0},
	{62 , 602.0},
	{63 , 584.0},
	{64 , 567.0},
	{65 , 550.0},
	{66 , 534.0},
	{67 , 518.0},
	{68 , 502.0},
	{69 , 488.0},
	{70 , 473.0},
	{71 , 459.0},
	{72 , 446.0},
	{73 , 433.0},
	{74 , 420.0},
	{75 , 408.0},
	{76 , 396.0},
	{77 , 385.0},
	{78 , 374.0},
	{79 , 363.0},
	{80 , 352.0},
	{81 , 342.0},
	{82 , 333.0},
	{83 , 323.0},
	{84 , 314.0},
	{85 , 305.0},
	{86 , 296.0},
	{87 , 288.0},
	{88 , 280.0},
	{89 , 272.0},
	{90 , 264.0},
	{91 , 257.0},
	{92 , 250.0},
	{93 , 243.0},
	{94 , 236.0},
	{95 , 230.0},
	{96 , 223.0},
	{97 , 217.0},
	{98 , 211.0},
	{99 , 206.0},
	{100, 200.0},
	{101, 195.0},
	{102, 190.0},
	{103, 184.0},
	{104, 180.0},
	{105, 175.0},
	{106, 170.0},
	{107, 166.0},
	{108, 161.0},
	{109, 157.0},
	{110, 153.0},
	{111, 149.0},
	{112, 145.0},
	{113, 142.0},
	{114, 138.0},
	{115, 135.0},
	{116, 131.0},
	{117, 128.0},
	{118, 125.0},
	{119, 122.0},
	{120, 118.0},
	{121, 116.0},
	{122, 113.0},
	{123, 110.0},
	{124, 107.0},
	{125, 105.0},
};

const ntc_t ntc_table[] =
{// Temp  resistance
	{-40, 335.4965},
	{-39, 315.5639},
	{-38, 296.9004},
	{-37, 279.4193},
	{-36, 263.0408},
	{-35, 247.6902},
	{-34, 233.2988},
	{-33, 219.8024},
	{-32, 207.1416},
	{-31, 195.2612},
	{-30, 184.1096},
	{-29, 173.8484},
	{-28, 164.1916},
	{-27, 155.1014},
	{-26, 146.5428},
	{-25, 138.4828},
	{-24, 130.8907},
	{-23, 123.7378},
	{-22, 116.9973},
	{-21, 110.6441},
	{-20, 104.6545},
	{-19, 98.9342},
	{-18, 93.5465},
	{-17, 88.4709},
	{-16, 83.6883},
	{-15, 79.1806},
	{-14, 74.931},
	{-13, 70.9236},
	{-12, 67.1441},
	{-11, 63.5785},
	{-10, 60.214},
	{-9, 57.0482},
	{-8, 54.0587},
	{-7, 51.2349},
	{-6, 48.567},
	{-5, 46.0461},
	{-4, 43.6635},
	{-3, 41.4112},
	{-2, 39.2817},
	{-1, 37.2679},
	{0, 35.3632},
	{1, 33.4678},
	{2, 31.6871},
	{3, 30.0135},
	{4, 28.4396},
	{5, 26.9589},
	{6, 25.5656},
	{7, 24.2536},
	{8, 23.0179},
	{9, 21.8535},
	{10, 20.7559},
	{11, 19.7207},
	{12, 18.744},
	{13, 17.8223},
	{14, 16.9522},
	{15, 16.1302},
	{16, 15.3535},
	{17, 14.6194},
	{18, 13.9253},
	{19, 13.2685},
	{20, 12.6472},
	{21, 12.059},
	{22, 11.5018},
	{23, 10.9742},
	{24, 10.4741},
	{25, 10},
	{26, 9.5504},
	{27, 9.1251},
	{28, 8.7215},
	{29, 8.3382},
	{30, 7.9741},
	{31, 7.628},
	{32, 7.2992},
	{33, 6.9865},
	{34, 6.6892},
	{35, 6.4062},
	{36, 6.137},
	{37, 5.8807},
	{38, 5.6367},
	{39, 5.4042},
	{40, 5.1827},
	{41, 4.9717},
	{42, 4.7704},
	{43, 4.5786},
	{44, 4.3956},
	{45, 4.2209},
	{46, 4.0542},
	{47, 3.8953},
	{48, 3.7433},
	{49, 3.5981},
	{50, 3.4595},
	{51, 3.3254},
	{52, 3.1973},
	{53, 3.0746},
	{54, 2.9573},
	{55, 2.845},
	{56, 2.7375},
	{57, 2.6346},
	{58, 2.5361},
	{59, 2.4417},
	{60, 2.3513},
	{61, 2.2647},
	{62, 2.1816},
	{63, 2.1021},
	{64, 2.0258},
	{65, 1.9526},
	{66, 1.8824},
	{67, 1.8151},
	{68, 1.7504},
	{69, 1.6884},
	{70, 1.6289},
	{71, 1.5717},
	{72, 1.5168},
	{73, 1.4641},
	{74, 1.4134},
	{75, 1.3648},
	{76, 1.3181},
	{77, 1.273},
	{78, 1.2299},
	{79, 1.1882},
	{80, 1.1483},
	{81, 1.1098},
	{82, 1.0728},
	{83, 1.0373},
	{84, 1.003},
	{85, 0.97},
	{86, 0.9388},
	{87, 0.9088},
	{88, 0.8798},
	{89, 0.852},
	{90, 0.8251},
	{91, 0.7993},
	{92, 0.7744},
	{93, 0.7503},
	{94, 0.7272},
	{95, 0.7049},
	{96, 0.6832},
	{97, 0.6625},
	{98, 0.6425},
	{99, 0.6231},
	{100, 0.6044},
	{101, 0.5864},
	{102, 0.569},
	{103, 0.5521},
	{104, 0.5359},
	{105, 0.5202},
	{106, 0.5051},
	{107, 0.4903},
	{108, 0.476},
	{109, 0.4621},
	{110, 0.4488},
	{111, 0.4359},
	{112, 0.4234},
	{113, 0.4113},
	{114, 0.3997},
	{115, 0.3884},
	{116, 0.3774},
	{117, 0.3669},
	{118, 0.3566},
	{119, 0.3468},
	{120, 0.3371},
	{121, 0.3278},
	{122, 0.3189},
	{123, 0.3102},
	{124, 0.3017},
	{125, 0.2935},
};

const uint16_t board_ntc_table_size = sizeof(board_ntc_table) / sizeof(ntc_t);
const uint16_t ntc_table_size = sizeof(ntc_table) / sizeof(ntc_t);

const uint32_t record_cycle_ms = 6 * 60 * 1000;

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
ac_sample_t g_ac_sample;
dc_sample_t g_dc_sample;
ac_sum_t    g_ac_signal[AC_CH_SIZES];
dc_sum_t    g_dc_signal[DC_CH_SIZES];
uint8_t data_ener[EE_TOTAL_ENER_LEN] = {0};
uint8_t rtc_ener[ENERGY_TIME_DATA_LEN_TOTAL] = {0};
int32_t energy_index = 0;

energy_t energy;

static float32_t v_grd_rs_last = 0;
static float32_t v_grd_st_last = 0;
static float32_t v_grd_tr_last = 0;
static float32_t v_out_rs_last = 0;
static float32_t v_out_st_last = 0;
static float32_t v_out_tr_last = 0;
static float32_t i_out_r_last = 0;
static float32_t i_out_s_last = 0;
static float32_t i_out_t_last = 0;
static float32_t v_ac_r_last = 0;
static float32_t v_ac_s_last = 0;
static float32_t v_ac_t_last = 0;

static int8_t   sys_state_hstrs_cnt = 0;

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/
float32_t measure_temp_cali(cali_dc_type_e type);

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/******************************************************************************
 * measure_init().
 * Initialize measure module. [Called by sw_init()]
 *
 * @param  none (I)
 * @param  none (O)
 * @return none
 *****************************************************************************/
void measure_init(void)
{
	clear_struct_data((uint8_t *)&g_ac_sample, sizeof(g_ac_sample));
	clear_struct_data((uint8_t *)&g_dc_sample, sizeof(g_dc_sample));
	clear_struct_data((uint8_t *)&g_ac_signal[0], sizeof(g_ac_signal));
	clear_struct_data((uint8_t *)&g_dc_signal[0], sizeof(g_dc_signal));
    clear_struct_data(&data_ener[0], sizeof(data_ener));

	v_grd_rs_last = 0;
	v_grd_st_last = 0;
	v_grd_tr_last = 0;
	v_out_rs_last = 0;
	v_out_st_last = 0;
	v_out_tr_last = 0;
	i_out_r_last = 0;
	i_out_s_last = 0;
	i_out_t_last = 0;
}

/******************************************************************************
 * ac_sum().
 * Calculate the square sums of AC samples.[Called by crtl_task_ac_sample()]
 *
 * @param data (I) current value
 * @param ptr  (O) AC sample square sums
 * @return none
 *****************************************************************************/
void ac_sum(ac_sum_t *ptr, int16_t data)
{
	float32_t new_sqr;
	uint32_t tmp;

	// NULL pointer protection
	if(!ptr)
	{
		return;
	}

	// v_physical = (v_analog - 1.5) / 0.001
	// v_analog = (v_digital / 4095) * 3.0
	// v_physical = v_digital * 3000 / 4095 - 1500
	// TODO calibrate gain
	tmp = data - ptr->offset;
	// tmp = data;
	ptr->physical = (float32_t)tmp * 0.7326f - 1500.0f;

	new_sqr = ptr->physical * ptr->physical;
	ptr->sum += new_sqr;

	ptr->index++;
	ptr->adc_win_sum += data;
	// pll theta crossing 0
	if(g_tpll.theta < ptr->last_theta)
	{
		ptr->win_size = ptr->index;
		ptr->win_sum = ptr->sum;
		ptr->offset = ptr->adc_win_sum / ptr->win_size - 2048;
		ptr->adc_win_sum = 0;
		ptr->sum = 0;
		ptr->index = 0;
	}
	ptr->last_theta = g_tpll.theta;
}

/******************************************************************************
 * dc_sum().
 * Calculate the sums of DC samples.[Called by crtl_task_dc_sample()]
 *
 * @param data (I) current value
 * @param ptr  (O) DC sample sums
 * @return none
 *****************************************************************************/
void dc_sum(dc_sum_t *ptr, int16_t data)
{
	// NULL pointer protection
	if(!ptr)
	{
		return;
	}

	ptr->index++;
	if(ptr->index >= DC_AVG_WIN_SIZES)
	{
		ptr->index = 0;
	}
	ptr->sum += (data - ptr->buff[ptr->index]);
	ptr->buff[ptr->index] = data;
//	ptr->avg = (ptr->sum + (DC_AVG_WIN_SIZES >> 1)) / DC_AVG_WIN_SIZES;
}

/******************************************************************************
 * calc_ac_rms().
 * Calculate AC RMS measure. [Called by app]
 *
 * @param  none  (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
static void calc_ac_rms(void)
{
	static uint8_t index = 0;
	ac_sum_t *tmp;

	tmp = &g_ac_signal[index];

	if(tmp->win_size != 0)
	{
		tmp->rms = sqrt((tmp->win_sum + (tmp->win_size >> 1)) / tmp->win_size);
		g_ac_signal[index].rms = tmp->rms;
//		tmp->offset = tmp->avg_sum_end / tmp->win_size - 2048;
		tmp->win_sum = 0;
		tmp->win_size = 0;
	}

	index++;
	if(index >= AC_CH_SIZES)
	{
		index = 0;
	}
}

/******************************************************************************
 * calc_dc_avg().
 * Calculate DC AVG measure. [Called by app]
 *
 * @param  none  (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
static void calc_dc_avg(void)
{
	static uint8_t index = 0;
	uint32_t  tmp_sum;
	float32_t tmp_avg;

	tmp_sum = g_dc_signal[index].sum;

	tmp_avg = (tmp_sum + (DC_AVG_WIN_SIZES >> 1)) / DC_AVG_WIN_SIZES;
	g_dc_signal[index].adc_avg  = tmp_avg;

	// temperature
	g_dc_signal[index].avg = tmp_avg;

	index++;
	if(index >= DC_CH_SIZES)
	{
		index = 0;
	}
}

/******************************************************************************
 * calculate_ntc_temp().
 * According to ADC data measure, to calculate the NTC temperature. [Called by app()]
 *
 * @param data (I) Resistance(unit kohm)/ADC of the ntc
 * @param ntc_table (I) temperature table
 * @param table_size (I) temperature table size
 * @param none (O)
 * @return temperature(oC, float32_t)
 *****************************************************************************/
float32_t calculate_ntc_temp(float32_t data, const ntc_t *ntc_table, \
														   uint16_t table_size)
{
	uint16_t  low;
	uint16_t  high;
	uint16_t  mid;
	bool_t    found;
	float32_t t;

	// NULL pointer protection
	if(ntc_table == NULL)
	{
		return FALSE;
	}

	low = 0;
	high = table_size - 1;

	if((data >= ntc_table[low].r) || (data < 0))
	{
		t = ntc_table[low].t;
	}
	else if(data <= ntc_table[high].r)
	{
		t = ntc_table[high].t;
	}
	else
	{
		found = FALSE;
		while((low < high) && (!found))
		{
			mid = (low + high) >> 1;
			if(data < ntc_table[mid].r)
			{
				low = mid + 1;
			}
			else if(data > ntc_table[mid].r)
			{
				high = mid - 1;
			}
			else
			{
				found = TRUE;
			}
		}

		if(!found)
		{
			if(data <= ntc_table[low].r)
			{
				t = (data - ntc_table[low].r) / (ntc_table[low + 1].r - ntc_table[low].r);
				t = ntc_table[low].t + t;
			}
			else
			{
				t = (ntc_table[low].r - data) / (ntc_table[low].r - ntc_table[low - 1].r);
				t = ntc_table[low].t - t;
			}
		}
		else
		{
			t = ntc_table[mid].t;
		}
	}

	return t;
}

/******************************************************************************
 * measure_temp().
 * measure temperature.[Called by app]
 *
 * @param none (I)
 * @param none (O)
 * @return none
 *****************************************************************************/
void measure_temp(void)
{
	float32_t tmp_var;
	float32_t tmp_r;
	pcsc_var_t *p_data = &array.pcsc.pcsc_data.var;

	tmp_var = calculate_ntc_temp((float32_t)g_dc_sample.t_board, \
									&board_ntc_table[0], board_ntc_table_size);
	p_data->t_board = (int16_t)(tmp_var * PARAMETER_ACCURACY_MAGNIFICATION_6 + 0.5f);

	if((csu_data.csu_heart.working_mode == FCT_MODE) || (product_info.model_num == POWER_MAGIC_400V))
	{
		tmp_r = measure_temp_cali(CALI_AC_FUSE_TEMP);
		tmp_var = calculate_ntc_temp(tmp_r, &ntc_table[0], ntc_table_size);
		p_data->t_ac_fuse = (int16_t)(tmp_var * PARAMETER_ACCURACY_MAGNIFICATION_6 + 0.5f);
	}
	else
	{
		// TODO: from MCU1
		p_data->t_ac_fuse = 0;
	}
	if(csu_data.csu_heart.working_mode == FCT_MODE)
	{
		tmp_r = measure_temp_cali(CALI_RESERVE_1);
		tmp_var = calculate_ntc_temp(tmp_r, &ntc_table[0], ntc_table_size);
		p_data->t_reserve_1 = (int16_t)(tmp_var * PARAMETER_ACCURACY_MAGNIFICATION_6 + 0.5f);

		tmp_r = measure_temp_cali(CALI_RESERVE_2);
		tmp_var = calculate_ntc_temp(tmp_r, &ntc_table[0], ntc_table_size);
		p_data->t_reserve_2 = (int16_t)(tmp_var * PARAMETER_ACCURACY_MAGNIFICATION_6 + 0.5f);
	}
}

/******************************************************************************
 * measure_temp_cali().
 * DC and ADC data calibrate.[Called by app]
 *
 * @param type    (I) dc
 * @param none    (O)
 * @return none
 *****************************************************************************/
float32_t measure_temp_cali(cali_dc_type_e type)
{
	float32_t data;
	float32_t temp_r = TEMP_NTC_OUT_LIMIT;

	switch(type)
	{
		case CALI_AC_FUSE_TEMP:
			data = (1 / (float32_t)g_dc_signal[T_AC_FUS].adc_avg) - calibrate.dc[type].offset;
			break;
		case CALI_RESERVE_1:
			data = (1 / (float32_t)g_dc_signal[RESERVE_1].adc_avg) - calibrate.dc[type].offset;
			break;
		case CALI_RESERVE_2:
			data = (1 / (float32_t)g_dc_signal[RESERVE_2].adc_avg) - calibrate.dc[type].offset;
			break;
		default:
			data = 0.0f;
			break;
	}

	if(data)
	{
		// x1 = a / data
		temp_r = calibrate.dc[type].gain / data;
	}
	else
	{
		temp_r = ntc_table[0].r;
	}

	return temp_r;
}

/******************************************************************************
 * ac_grid_cal().
 * AC general data calculate.[Called by task()]
 *
 * @param none (I)
 * @param none (O)
 * @return none
 *****************************************************************************/
static void ac_grid_cal(void)
{
	float32_t v_grd_rs_new = 0;
	float32_t v_grd_st_new = 0;
	float32_t v_grd_tr_new = 0;
	float32_t v_out_rs_new = 0;
	float32_t v_out_st_new = 0;
	float32_t v_out_tr_new = 0;
	float32_t i_out_r_new = 0;
	float32_t i_out_s_new = 0;
	float32_t i_out_t_new = 0;
	float32_t v_ac_r_new = 0;
	float32_t v_ac_s_new = 0;
	float32_t v_ac_t_new = 0;
	float32_t freq_new;
	pcsc_var_t *p_data = &array.pcsc.pcsc_data.var;


	// AC 3 phase voltage calculate, unit 0.1V
	v_grd_rs_new = PARAMETER_ACCURACY_MAGNIFICATION_6 * g_ac_signal[VGRD_RS].rms * calibrate.ac[CALI_VGRID_RS].gain;
	v_grd_st_new = PARAMETER_ACCURACY_MAGNIFICATION_6 * g_ac_signal[VGRD_ST].rms * calibrate.ac[CALI_VGRID_ST].gain;
	v_grd_tr_new = PARAMETER_ACCURACY_MAGNIFICATION_6 * g_ac_signal[VGRD_TR].rms * calibrate.ac[CALI_VGRID_TR].gain;
	v_out_rs_new = PARAMETER_ACCURACY_MAGNIFICATION_6 * g_ac_signal[VPCS_RS].rms * calibrate.ac[CALI_VPCS_RS].gain;
	v_out_st_new = PARAMETER_ACCURACY_MAGNIFICATION_6 * g_ac_signal[VPCS_ST].rms * calibrate.ac[CALI_VPCS_ST].gain;
	v_out_tr_new = PARAMETER_ACCURACY_MAGNIFICATION_6 * g_ac_signal[VPCS_TR].rms * calibrate.ac[CALI_VPCS_TR].gain;
	v_ac_r_new = PARAMETER_ACCURACY_MAGNIFICATION_6 * g_ac_signal[VGRD_R].rms * calibrate.ac[VGRD_RS].gain;
	v_ac_s_new = PARAMETER_ACCURACY_MAGNIFICATION_6 * g_ac_signal[VGRD_S].rms * calibrate.ac[VGRD_ST].gain;
	v_ac_t_new = PARAMETER_ACCURACY_MAGNIFICATION_6 * g_ac_signal[VGRD_T].rms * calibrate.ac[VGRD_TR].gain;
	v_ac_r_last = v_ac_r_last * 0.9f + v_ac_r_new * 0.1f;
	v_ac_s_last = v_ac_s_last * 0.9f + v_ac_s_new * 0.1f;
	v_ac_t_last = v_ac_t_last * 0.9f + v_ac_t_new * 0.1f;
	p_data->v_ac_r = v_ac_r_last;
	p_data->v_ac_s = v_ac_s_last;
	p_data->v_ac_t = v_ac_t_last;

	v_grd_rs_last = v_grd_rs_last * 0.9f + v_grd_rs_new * 0.1f;
	v_grd_st_last = v_grd_st_last * 0.9f + v_grd_st_new * 0.1f;
	v_grd_tr_last = v_grd_tr_last * 0.9f + v_grd_tr_new * 0.1f;
	v_out_rs_last = v_out_rs_last * 0.9f + v_out_rs_new * 0.1f;
	v_out_st_last = v_out_st_last * 0.9f + v_out_st_new * 0.1f;
	v_out_tr_last = v_out_tr_last * 0.9f + v_out_tr_new * 0.1f;

	p_data->v_grd_rs = v_grd_rs_last;
	p_data->v_grd_st = v_grd_st_last;
	p_data->v_grd_tr = v_grd_tr_last;
	p_data->v_out_rs = v_out_rs_last;
	p_data->v_out_st = v_out_st_last;
	p_data->v_out_tr = v_out_tr_last;

	i_out_r_new = g_ac_signal[IGRD_R].rms * calibrate.ac[CALI_CURRENT_R].gain;
	i_out_s_new = g_ac_signal[IGRD_S].rms * calibrate.ac[CALI_CURRENT_S].gain;
	i_out_t_new = g_ac_signal[IGRD_T].rms * calibrate.ac[CALI_CURRENT_T].gain;
	i_out_r_last = i_out_r_last * 0.9f + i_out_r_new * 0.1f;
	i_out_s_last = i_out_s_last * 0.9f + i_out_s_new * 0.1f;
	i_out_t_last = i_out_t_last * 0.9f + i_out_t_new * 0.1f;

	p_data->i_out_r = i_out_r_last;
	p_data->i_out_s = i_out_s_last;
	p_data->i_out_t = i_out_t_last;

//		array.pcsc.pcsc_data.var.grid_freq = freq_tpll * 100.0f;
	// Frequency calculate, use filter, unit 0.01Hz
	freq_new = freq_tpll * PARAMETER_ACCURACY_MAGNIFICATION_7;

//	freq_last = freq_last * 0.9f + freq_new * 0.1f;
	p_data->grid_freq = freq_new;
}

/******************************************************************************
 * update_pcs_sys_state().
 * Update PCS system state.[Called by task()]
 *
 * @param none (I)
 * @param none (O)
 * @return none
 *****************************************************************************/
static void update_pcs_sys_state(void)
{
	uint8_t fault = FALSE;

	if((shutdown_fault == TRUE) &&
	   ((array.pcsc.pcsc_data.fault.fault1.all != 0) ||
		(array.pcsc.pcsc_data.fault.fault2.all != 0) ||
		(array.pcsc.pcsc_data.fault.fault3.all != 0) ||
		(array.pcsc.pcsc_data.fault.fault4.all != 0) ||
		(array.pcsc.pcsc_data.fault.fault5.all != 0)))
	{
		fault = TRUE;
	}
	if(fault == TRUE)
	{
		if(array.pcsc.pcsc_data.state.state1.bit.grid_tied_off == TRUE)
		{
			array.pcsc.pcsc_data.state.sys_state = SYS_STATE_FAULT;
		}
	}
	else
	{
		if (array.pcsc.pcsc_data.state.state1.bit.grid_tied_off == TRUE)
		{
			array.pcsc.pcsc_data.state.sys_state = SYS_STATE_SHUT_DOWN;
		}
		else
		{
			if((array.pcsc.pcsc_ctrl.active_power_ref > 0) && \
				(array.array_data.variable.cmu_running))
			{
				if(sys_state_hstrs_cnt > 3)
				{
					array.pcsc.pcsc_data.state.sys_state = SYS_STATE_DISCHARGE;
				}
				else
				{
					sys_state_hstrs_cnt++;
				}
			}
			else if((array.pcsc.pcsc_ctrl.active_power_ref < 0) && \
					(array.array_data.variable.cmu_running))
			{
				if(sys_state_hstrs_cnt < -3)
				{
					array.pcsc.pcsc_data.state.sys_state = SYS_STATE_CHARGE;
				}
				else
				{
					sys_state_hstrs_cnt--;
				}
			}
			else
			{
				if(sys_state_hstrs_cnt == 0)
				{
					if(array.array_data.variable.cmu_running > 0)
					{
						array.pcsc.pcsc_data.state.sys_state = SYS_STATE_RUNNING;
					}
					else
					{
						array.pcsc.pcsc_data.state.sys_state = SYS_STATE_STANDBY;
					}
				}
				else if(sys_state_hstrs_cnt > 0)
				{
					sys_state_hstrs_cnt--;
				}
				else
				{
					sys_state_hstrs_cnt++;
				}
			}
		}
	}
	if ((!array.pcsc.pcsc_data.state.state1.bit.grid_tied_on) && (!array.pcsc.pcsc_data.state.state1.bit.grid_tied_off))
	{
		array.pcsc.pcsc_data.state.grid_tied_state = SYS_STATE_GRID_TIED_ON;
	}
	else if(array.pcsc.pcsc_data.state.state1.bit.grid_tied_on && array.pcsc.pcsc_data.state.state1.bit.grid_tied_off)
	{
		array.pcsc.pcsc_data.state.grid_tied_state = SYS_STATE_GRID_TIED_OFF;
	}
}

/******************************************************************************
 * crtl_task_ac_sample().
 * Get AC samples.[Called by task()]
 *
 * @param none (I)
 * @param none (O)
 * @return none
 *****************************************************************************/
void crtl_task_ac_sample(void)
{
	int32_t temp;

	sdk_adc_read(AD_CH_VPCS_RN, &temp);
	g_ac_sample.vpcs_rn = (int16_t)temp;

	sdk_adc_read(AD_CH_VPCS_RS, &temp);
	g_ac_sample.vpcs_rs = (int16_t)temp;

	sdk_adc_read(AD_CH_VPCS_RT, &temp);
	g_ac_sample.vpcs_rt = (int16_t)temp;

	sdk_adc_read(AD_CH_VGRD_RN, &temp);
	g_ac_sample.vgrd_rn = (int16_t)temp;

	sdk_adc_read(AD_CH_VGRD_RS, &temp);
	g_ac_sample.vgrd_rs = (int16_t)temp;

	sdk_adc_read(AD_CH_VGRD_RT, &temp);
	g_ac_sample.vgrd_rt = (int16_t)temp;

	sdk_adc_read(AD_CH_IGRD_S, &temp);
	g_ac_sample.igrd_s = (int16_t)temp;
	ac_sum(&g_ac_signal[IGRD_S], g_ac_sample.igrd_s);

	sdk_adc_read(AD_CH_IGRD_T, &temp);
	g_ac_sample.igrd_t = (int16_t)temp;
	ac_sum(&g_ac_signal[IGRD_T], g_ac_sample.igrd_t);
	g_ac_sample.vpcs_r  = g_ac_sample.vpcs_rn;
	g_ac_sample.vpcs_s  = (g_ac_sample.vpcs_rs - g_ac_sample.vpcs_rn) + 2048;
	g_ac_sample.vpcs_t  = (g_ac_sample.vpcs_rt - g_ac_sample.vpcs_rn) + 2048;
	g_ac_sample.vpcs_st = (g_ac_sample.vpcs_rs - g_ac_sample.vpcs_rt) + 2048;
	g_ac_sample.vpcs_tr = 2048 - (g_ac_sample.vpcs_rt - 2048);

	g_ac_sample.vgrd_r  = g_ac_sample.vgrd_rn;
	g_ac_sample.vgrd_s  = (g_ac_sample.vgrd_rs - g_ac_sample.vgrd_rn) + 2048;
	g_ac_sample.vgrd_t  = (g_ac_sample.vgrd_rt - g_ac_sample.vgrd_rn) + 2048;
	g_ac_sample.vgrd_st = (g_ac_sample.vgrd_rs - g_ac_sample.vgrd_rt) + 2048;
	g_ac_sample.vgrd_tr = 2048 - (g_ac_sample.vgrd_rt - 2048);

	ac_sum(&g_ac_signal[VPCS_R], g_ac_sample.vpcs_r);
	ac_sum(&g_ac_signal[VPCS_S], g_ac_sample.vpcs_s);
	ac_sum(&g_ac_signal[VPCS_T], g_ac_sample.vpcs_t);
	ac_sum(&g_ac_signal[VGRD_R], g_ac_sample.vgrd_r);
	ac_sum(&g_ac_signal[VGRD_S], g_ac_sample.vgrd_s);
	ac_sum(&g_ac_signal[VGRD_T], g_ac_sample.vgrd_t);

	ac_sum(&g_ac_signal[VPCS_RS], g_ac_sample.vpcs_rs);
	ac_sum(&g_ac_signal[VPCS_ST], g_ac_sample.vpcs_st);
	ac_sum(&g_ac_signal[VPCS_TR], g_ac_sample.vpcs_tr);
	ac_sum(&g_ac_signal[VGRD_RS], g_ac_sample.vgrd_rs);
	ac_sum(&g_ac_signal[VGRD_ST], g_ac_sample.vgrd_st);
	ac_sum(&g_ac_signal[VGRD_TR], g_ac_sample.vgrd_tr);
}

/******************************************************************************
 * crtl_task_dc_sample().
 * Get DC samples.[Called by task()]
 *
 * @param none (I)
 * @param none (O)
 * @return none
 *****************************************************************************/
void crtl_task_dc_sample(void)
{
	static uint8_t index = 0;
	int32_t temp;

	switch(index)
	{
		case 0:
			sdk_adc_read(AD_CH_T_BOARD, &temp);
			g_dc_sample.t_board = (int16_t)temp;
			dc_sum(&g_dc_signal[T_BOARD], g_dc_sample.t_board);
			index = 0;
			break;
		default:
			index = 0;
			break;
	}
}

/******************************************************************************
 * crtl_task_mux_sample().
 * Get DC samples with control ADC MUX channels.[Called by task()]
 *
 * @param none (I)
 * @param none (O)
 * @return none
 *****************************************************************************/
void crtl_task_mux_sample(void)
{
	static uint8_t index = 0;
	int32_t temp;

	switch(index)
	{
		case 0:
			if((csu_data.csu_heart.working_mode == FCT_MODE) || (product_info.model_num == POWER_MAGIC_400V))
			{
				sdk_adc_read(AD_CH_T_AC_FUS, &temp);
				g_dc_sample.t_ac_fus = (int16_t)temp;
				dc_sum(&g_dc_signal[T_AC_FUS], g_dc_sample.t_ac_fus);
			}
			if(csu_data.csu_heart.working_mode == FCT_MODE)
			{
				index = 1;
				MUX_DC_SEL_A_H();
				MUX_DC_SEL_B_L();
			}
			else
			{
				index = 3;
				MUX_DC_SEL_A_H();
				MUX_DC_SEL_B_H();
			}
			break;
		case 1:
			sdk_adc_read(AD_CH_MUX_RESERVE1, &temp);
			g_dc_sample.reserve_1 = (int16_t)temp;
			dc_sum(&g_dc_signal[RESERVE_1], g_dc_sample.reserve_1);
			index = 2;
			MUX_DC_SEL_A_L();
			MUX_DC_SEL_B_H();
			break;
		case 2:
			sdk_adc_read(AD_CH_MUX_RESERVE2, &temp);
			g_dc_sample.reserve_2 = (int16_t)temp;
			dc_sum(&g_dc_signal[RESERVE_2], g_dc_sample.reserve_2);
			index = 3;
			MUX_DC_SEL_A_H();
			MUX_DC_SEL_B_H();
			break;
		case 3:
			sdk_adc_read(AD_CH_IGRD_R, &temp);
			g_ac_sample.igrd_r = (int16_t)temp;
			ac_sum(&g_ac_signal[IGRD_R], g_ac_sample.igrd_r);
			index = 0;
			MUX_DC_SEL_A_L();
			MUX_DC_SEL_B_L();
			break;
		default:
			index = 0;
			MUX_DC_SEL_A_L();
			MUX_DC_SEL_B_L();
			break;
	}
}

/******************************************************************************
 * fast_task_measure().
 * Measure voltage, etc. [Called by task]
 *
 * @param  none  (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void fast_task_measure(void)
{
	static uint8_t index = 0;

	switch(index)
	{
		case 0:
			calc_ac_rms();
			index = 1;
			break;
		case 1:
			calc_dc_avg();
			index = 0;
			break;
		default:
			index = 0;
			break;
	}
}

/******************************************************************************
 * fast_task_calc().
 * Calculate system data and state. [Called by task]
 *
 * @param  none  (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void fast_task_calc(void)
{
	static uint8_t index = 0;

	switch(index)
	{
		case 0:
			ac_grid_cal();
			index = 2;
			break;
		case 2:
			update_pcs_sys_state();
			index = 0;
			break;
		default:
			index = 0;
			break;
	}
}

/******************************************************************************
 * slow_task_measure().
 * Measure temperature, etc. [Called by task]
 *
 * @param  none  (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void slow_task_measure(void)
{
	measure_temp();
}

/******************************************************************************
* End of module
******************************************************************************/
