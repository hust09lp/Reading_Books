/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     dlt645.h
  * @brief    DLT645 module
  * @company  SOFARSOLAR
  * @author   ZZJ
  * @note
  * @version  V01
  * @date     2024/05/14
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------
#include <math.h>
// Include project file ------------------------------------------------------
#include "dlt645.h"

#include "sdk.h"
#include "sdk_core.h"
#include "sdk_uart.h"
/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
typedef enum
{
    BYTE_RESET = 0,   //重置
    BYTE_LOW_ADDRESS, //低位
    BYTE_HIGH_ADDRESS //高位
} byte_part;
/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
uint8_t dlt645_send_buf[DLT645_2007_RD_CMD_LEN];
uint8_t dlt645_read_buf[DLT645_RESP_LEN];
uint8_t universal_addr[DLT645_ADDR_LEN] = {0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA};

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/
/******************************************************************************
 * dlt645_crc()
 * dlt645 crc module. [Called by task.]
 *
 * @param msg (I) msg
 * @param len (I) msg len
 * @return crc value
 *****************************************************************************/
int8_t dlt645_crc(uint8_t *msg, int len)
{
    uint8_t crc = 0;

    while (len--)
    {
        crc += *msg++;
    }
    return crc;
}

/******************************************************************************
 * dlt645_common_check()
 * dlt645 common check module. [Called by task.]
 *
 * @param msg (I) msg
 * @param len (I) msg len
 * @param addr (I) dlt645 addr
 * @return 0(success) -1(failure)
 *****************************************************************************/
int8_t dlt645_common_check(uint8_t *msg, int len, uint8_t *addr)
{
    uint8_t crc = 0;
    //数据包长度校验
    if (len < 7)
    {
        return -1;
    }
    //数据帧标志校验
    if (msg[DLT645_RECV_START_POS] != DLT645_START_CODE ||
        msg[DLT645_RECV_START_POS + DLT645_ADDR_LEN + 1] != DLT645_START_CODE ||
        msg[len - 1] != DLT645_STOP_CODE)
    {
        sdk_log_a("check code error!\n");
        return -1;
    }
    //CRC校验
    crc = dlt645_crc(msg, len - 2);
    if (crc != msg[len - 2])
    {
        sdk_log_a("check crc error!\n");
        return -1;
    }
    //控制码主从校验
    if ((msg[DLT645_RECV_CONTROL_POS] & C_TD_MASK) == (C_TD_MASTER << C_TD_POS))
    {
        sdk_log_a("check control direction error!\n");
        return -1;
    }
    //控制码应答校验
    if ((msg[DLT645_RECV_CONTROL_POS] & C_ACK_MASK) == (C_ACK_ERR << C_ACK_POS))
    {
        sdk_log_a("check ACK error!\n");
        return -1;
    }
    //从站地址校验
    if (memcmp(msg + DLT645_RECV_ADDR_POS, addr, 6) != 0)
    {
        // 万能地址无需校验
        for(int i = 0; i < 6; i++)
        {
            if(addr[i] != DLT645_GADDR_CODE)
            {
                return -1;
            }
        }
    }

    return 0;
}

/******************************************************************************
 * dec_to_bcd()
 * dec to bcd module. [Called by task.]
 *
 * @param val (I) val
 * @return val(bcd)
 *****************************************************************************/
//uint32_t dec_to_bcd(uint32_t val)
//{
//    uint32_t data = 0;
//    uint32_t multiplier = 1;
//    uint8_t i = 0;
//    uint8_t byte = 0;

//    for (i = 0; i < 8; i++)
//    {
//        byte = (val / multiplier) % 10;
//        data += byte << (i * 4);
//        multiplier *= 10;
//        if (val < multiplier)
//            break;
//    }

//    return data;
//}

/******************************************************************************
 * dec_to_bcd()
 * dec to bcd module. [Called by task.]
 *
 * @param str (I) str
 * @param bcd_store_address (I) bcd_store_address
 * @param bcd_len (I) bcd_len
 * @return 0(success) -1(failure)
 *****************************************************************************/
//int8_t str_to_bcd(char *str, uint8_t *bcd_store_address, uint16_t bcd_len)
//{
//    //字符串偏移
//    int32_t str_pos = bcd_len * 2 - strlen(str);
//    //字符串比BCD码长度长
//    if (str_pos < 0)
//    {
//        return -1;
//    }
//    memset(bcd_store_address, 0, bcd_len);

//    for (int i = 0; i < strlen(str); i++)
//    {
//        if (str[i] >= '0' && str[i] <= '9')
//        {
//            bcd_store_address[(i + str_pos) / 2] |= (str[i] - '0') << (4 * ((i + 1 + (strlen(str) % 2)) % 2));
//        }
//        else
//        {
//            //当前字符不为数字，返回错误
//            return -1;
//        }
//    }
//    return 0;
//}

/******************************************************************************
 * data_package_translate_to_int()
 * data package translate to int module. [Called by task.]
 *
 * @param read_data (I) read_data
 * @param len (I) read_data len
 * @return val
 *****************************************************************************/
int32_t data_package_translate_to_int(uint8_t *read_data, uint16_t len)
{
    //权值
    uint8_t number_weight = 0;
    //当前数组下标索引
    uint8_t current_index = 0;
    //当前解析字节位
    uint8_t current_byte_part = BYTE_RESET;
    //当前整数值
    int32_t i_value = 0;

    while (len--)
    {
        current_byte_part = BYTE_LOW_ADDRESS;
        do
        {
            switch (current_byte_part)
            {
            //当前处理字节低位
            case BYTE_LOW_ADDRESS:
                i_value += ((read_data[current_index] - 0x33) & 0x0f) * pow(10, number_weight);
                number_weight++;
                current_byte_part = BYTE_HIGH_ADDRESS;
                break;
            //当前处理字节高位
            case BYTE_HIGH_ADDRESS:
                i_value += ((read_data[current_index] - 0x33) >> 4) * pow(10, number_weight);
                number_weight++;
                current_byte_part = BYTE_RESET;
                break;
            }
        } while (current_byte_part != BYTE_RESET);
        current_index++;
    }
    return i_value;
}

/******************************************************************************
 * dlt645_set_addr()
 * set dlt645 addr module. [Called by task.]
 *
 * @param ctx (I) ctx
 * @param addr (I) addr
 * @return
 *****************************************************************************/
void dlt645_set_addr(dlt645_t *ctx, uint8_t *addr)
{
    uint8_t addr_temp[6];
    uint8_t i = 0;
    memset(addr_temp, 0, 6);

    //转换字节序
    for (i = 0; i < 6; i++)
    {
        addr_temp[5 - i] = addr[i];
    }
    memcpy(ctx->addr, addr_temp, DLT645_ADDR_LEN);
}

/******************************************************************************
 * dlt645_set_port_index()
 * set dlt645 port index module. [Called by task.]
 *
 * @param ctx (I) ctx
 * @param addr (I) index
 * @return
 *****************************************************************************/
int8_t dlt645_set_port_index(dlt645_t *ctx, int8_t index)
{
    ctx->port_index = index;
    return 0;
}

/******************************************************************************
 * dlt645_set_debug()
 * set dlt645 debug module. [Called by task.]
 *
 * @param ctx (I) ctx
 * @param flag (I) flag
 * @return
 *****************************************************************************/
int8_t dlt645_set_debug(dlt645_t *ctx, int8_t flag)
{
    ctx->debug = flag;
    return 0;
}

/******************************************************************************
 * dlt645_set_premble_code_len()
 * set dlt645 premble code module. [Called by task.]
 *
 * @param ctx (I) ctx
 * @param len (I) len
 * @return
 *****************************************************************************/
int8_t dlt645_set_premble_code_len(dlt645_t *ctx, int8_t len)
{
    ctx->premble_code_len = len;
    return 0;
}

/******************************************************************************
 * dlt645_set_timeout()
 * set dlt645 timeout module. [Called by task.]
 *
 * @param ctx (I) ctx
 * @param timeout (I) timeout
 * @return
 *****************************************************************************/
int8_t dlt645_set_timeout(dlt645_t *ctx, uint32_t timeout)
{
    ctx->timeout = timeout;
    return 0;
}

/******************************************************************************
 * dlt645_addr_parse()
 * dlt645 addr parse module. [Called by task.]
 *
 * @param ctx (I) ctx
 * @param read_data (I) addr
 * @return
 *****************************************************************************/
int8_t dlt645_addr_parse(dlt645_t *ctx, uint8_t *read_data)
{
	uint8_t i = 0;

	for(i = 0; i < 6; i++)
	{
		ctx->addr[i] = read_data[i] - 0x33;
	}
    return 0;
}

/******************************************************************************
 * dlt645_data_parse_by_format_to_float()
 * dlt645_data parse by format to float module. [Called by task.]
 *
 * @param read_data (I) read_data
 * @param read_len (I) read_len
 * @param data_format (I) data_format
 * @param store_address (I) store_address
 * @return 0:success, -1:fail
 *****************************************************************************/
int8_t dlt645_data_parse_by_format_to_float(uint8_t *read_data, uint16_t read_len, const char *data_format, uint8_t *store_address)
{
    //权值
    int32_t num_weight = 0;
    int32_t ival = data_package_translate_to_int(read_data, read_len);
    uint32_t i = 0;
    float32_t fval = 0;

    for (i = 0; i < strlen(data_format); i++)
    {
        if (*(data_format + i) == '.')
        {
            num_weight = strlen(data_format) - i - 1;
            if (num_weight < 0)
            {
                return -1;
            }
            break;
        }
    }
    fval = ival / pow(10, num_weight);
    memcpy(store_address, &fval, 4);
    return 0;
}


/******************************************************************************
 * dlt645_2007_recv_check()
 * dlt645 2007 recv check module. [Called by task.]
 *
 * @param msg (I) msg
 * @param len (I) msg len
 * @param addr (I) addr
 * @param code (I) code
 * @return 0:success, -1:fail
 *****************************************************************************/
int8_t dlt645_2007_recv_check(uint8_t *msg, int len, uint8_t *addr, uint32_t code)
{
    uint8_t *code_buf = (uint8_t *)&code;

    if (dlt645_common_check(msg, len, addr) < 0)
    {
        return -1;
    }
    if (msg[DLT645_RECV_CONTROL_POS] == 0x94)
        return 0;

	if(code != 0xFFFFFFFF)
	{
		for (uint8_t i = 0; i < 4; i++)
		{
			code_buf[i] += 0x33;
		}

		if (*((uint32_t *)(msg + DLT645_RECV_DATA_POS)) != code)
			return -1;
	}

    return 0;
}


/******************************************************************************
 * dlt645_2007_parsing_data()
 * dlt645 2007 parsing data module. [Called by task.]
 *
 * @param code (I) code
 * @param read_data (I) read_data
 * @param len (I) read_data len
 * @param real_val (I) real_val
 * @return
 *****************************************************************************/
int8_t dlt645_2007_parsing_data(uint32_t code, uint8_t *read_data, uint16_t len, uint8_t *real_val)
{
    switch (code)
    {
        case DIC_0:
        case DIC_100:
        case DIC_200:
        case DIC_300:
        case DIC_400:
        case DIC_10000:
        case DIC_10100:
        case DIC_10200:
        case DIC_10300:
        case DIC_10400:
        case DIC_20000:
        case DIC_20100:
        case DIC_20200:
        case DIC_20300:
        case DIC_20400:
        case DIC_30000:
        case DIC_40000:
        case DIC_50000:
        case DIC_60000:
        case DIC_70000:
        case DIC_80000:
        case DIC_90000:
        {
            dlt645_data_parse_by_format_to_float(read_data,4,"XXXXXX.XX",real_val);
            break;
        }
        case DIC_2010100:
        case DIC_2010200:
        case DIC_2010300:
        case DIC_20C0100:
        case DIC_20C0200:
        case DIC_20C0300:
        {
            dlt645_data_parse_by_format_to_float(read_data,2,"XXX.X",real_val);
            break;
        }
        case DIC_2020100:
        case DIC_2020200:
        case DIC_2020300:
        {
            dlt645_data_parse_by_format_to_float(read_data,3,"XXX.XXX",real_val);
            break;
        }
        case DIC_2030000:
        case DIC_2030100:
        case DIC_2030200:
        case DIC_2030300:
        case DIC_2040000:
        case DIC_2040100:
        case DIC_2040200:
        case DIC_2040300:
        case DIC_2050000:
        case DIC_2050100:
        case DIC_2050200:
        case DIC_2050300:
        {
            dlt645_data_parse_by_format_to_float(read_data,3,"XX.XXXX",real_val);
            break;
        }
        case DIC_2060000:
        case DIC_2060100:
        case DIC_2060200:
        case DIC_2060300:
        {
            dlt645_data_parse_by_format_to_float(read_data,2,"X.XXX",real_val);
            break;
        }
        case DIC_2800002:
        {
            dlt645_data_parse_by_format_to_float(read_data,2,"XX.XX",real_val);
            break;
        }
        case DIC_4000403:
        case DIC_5060001:
        case DIC_7000001:
        case DIC_7000002:
            for (uint16_t i = 0; i < len; i++)
            {
                real_val[i] = read_data[i] - 0x33;
            }
            break;
        default:
            for (uint16_t i = 0; i < len; i++)
            {
                real_val[i] = ((read_data[i] - 0x33) & 0x0f) + ((read_data[i] - 0x33) >> 4) * 10;
            }
            break;
    }
    return len;
}

/******************************************************************************
 * dlt645_receive_msg()
 * dlt645 receive msg module. [Called by task.]
 *
 * @param ctx (I) ctx
 * @param msg (I) msg
 * @param len (I) msg len
 * @param code (I) code
 * @return  0:success, -1:fail
 *****************************************************************************/
int8_t dlt645_receive_msg(dlt645_t *ctx, uint8_t *msg, uint16_t len, uint32_t code)
{
    uint8_t i = 0;
    int32_t msg_len = ctx->read(ctx, msg, len);

    while((msg[i] != DLT645_START_CODE) && (msg_len != 0))
    {
        msg_len--;
        i++;
    }

	dlt645_set_premble_code_len(ctx, i);
    return dlt645_2007_recv_check(&msg[i], msg_len, ctx->addr, code);
}

/******************************************************************************
 * dlt645_send_msg()
 * dlt645 send msg module. [Called by task.]
 *
 * @param ctx (I) ctx
 * @param msg (I) msg
 * @param len (I) msg len
 * @return  0:success, -1:fail
 *****************************************************************************/
int8_t dlt645_send_msg(dlt645_t *ctx, uint8_t *msg, int32_t len)
{
    msg[DLT645_SEND_START_POS] = DLT645_START_CODE;
    msg[DLT645_SEND_START_POS + DLT645_ADDR_LEN + 1] = DLT645_START_CODE;
    msg[len - 1] = DLT645_STOP_CODE;
    msg[len - 2] = dlt645_crc(msg + DLT645_PREMBLE_LEN, len - DLT645_PREMBLE_LEN - 2);

    return ctx->write(ctx, msg, len);
}

/******************************************************************************
 * dlt645_2007_read_addr()
 * dlt645 2007 read addr module. [Called by task.]
 *
 * @param ctx (I) ctx
 * @return  0:success, -1:fail
 *****************************************************************************/
int8_t dlt645_2007_read_addr(dlt645_t *ctx)
{
    memset(dlt645_send_buf, DLT645_PREMBLE_CODE, DLT645_PREMBLE_LEN);
    memcpy(dlt645_send_buf + DLT645_SEND_ADDR_POS, ctx->addr, DLT645_ADDR_LEN);

    dlt645_send_buf[DLT645_SEND_CONTROL_POS] = C_2007_CODE_RDA;
    dlt645_send_buf[DLT645_SEND_LEN_POS] = 0;

    if (dlt645_send_msg(ctx, dlt645_send_buf, DLT645_2007_ADDR_CMD_LEN) < 0)
    {
        sdk_log_a("send data error!\n");
        return -1;
    }

    if (dlt645_receive_msg(ctx, dlt645_read_buf, DLT645_RESP_LEN, 0xFFFFFFFF) < 0)
    {
        sdk_log_a("receive msg error!\n");
        return -1;
    }

    return dlt645_addr_parse(ctx, &dlt645_read_buf[ctx->premble_code_len + DLT645_RECV_DATA_POS]);
}

/******************************************************************************
 * dlt645_2007_read_data()
 * dlt645 2007 read data module. [Called by task.]
 *
 * @param ctx (I) ctx
 * @param code (I) code
 * @param read_data (O) read data
 * @return  0:success, -1:fail
 *****************************************************************************/
int8_t dlt645_2007_read_data(dlt645_t *ctx,
                          uint32_t code,
                          uint8_t *read_data)
{
    uint8_t send_code[4] = {0};

    memset(dlt645_send_buf, DLT645_PREMBLE_CODE, DLT645_PREMBLE_LEN);
    memcpy(dlt645_send_buf + DLT645_SEND_ADDR_POS, ctx->addr, DLT645_ADDR_LEN);

    dlt645_send_buf[DLT645_SEND_CONTROL_POS] = C_2007_CODE_RD;
    dlt645_send_buf[DLT645_SEND_LEN_POS] = 4;

    send_code[0] = (code & 0xff) + 0x33;
    send_code[1] = ((code >> 8) & 0xff) + 0x33;
    send_code[2] = ((code >> 16) & 0xff) + 0x33;
    send_code[3] = ((code >> 24) & 0xff) + 0x33;

    memcpy(dlt645_send_buf + DLT645_SEND_DATA_POS, send_code, 4);

    if (dlt645_send_msg(ctx, dlt645_send_buf, DLT645_2007_RD_CMD_LEN) < 0)
    {
        sdk_log_a("send data error!\n");
        return -1;
    }

    if (dlt645_receive_msg(ctx, dlt645_read_buf, DLT645_RESP_LEN, code) < 0)
    {
        sdk_log_a("receive msg error!\n");
        return -1;
    }

    return dlt645_2007_parsing_data(code, \
									dlt645_read_buf + ctx->premble_code_len + DLT645_RECV_DATA_POS + 4, \
									dlt645_read_buf[ctx->premble_code_len + DLT645_RECV_LEN_POS] - 4, \
									read_data);
}

/******************************************************************************
 * dlt645_write_data()
 * dlt645 write data module. [Called by task.]
 *
 * @param ctx (I) ctx
 * @param addr (I) addr
 * @param code (I) code
 * @param write_data (I) write data
 * @param write_len (I) write len
 * @return  0:success, -1:fail
 *****************************************************************************/
int8_t dlt645_write_data(dlt645_t *ctx,
                      uint32_t addr,
                      uint32_t code,
                      uint8_t *write_data,
                      uint8_t write_len)
{
    uint8_t send_code[4] = {0};
    uint8_t i = 0;

    memset(dlt645_read_buf, 0, sizeof(dlt645_read_buf));
    memset(dlt645_send_buf, 0, sizeof(dlt645_send_buf));

    memcpy(dlt645_send_buf + 1, ctx->addr, DLT645_ADDR_LEN);

    dlt645_send_buf[DLT645_SEND_CONTROL_POS] = C_2007_CODE_WR;
    dlt645_send_buf[DLT645_SEND_LEN_POS] = 12 + write_len;

    send_code[0] = (code & 0xff) + 0x33;
    send_code[1] = ((code >> 8) & 0xff) + 0x33;
    send_code[2] = ((code >> 16) & 0xff) + 0x33;
    send_code[3] = ((code >> 24) & 0xff) + 0x33;

    for (i = 0; i < write_len; i++)
    {
        write_data[i] += 0x33;
    }

    memcpy(dlt645_send_buf + DLT645_SEND_DATA_POS, send_code, 4);
    memcpy(dlt645_send_buf + DLT645_SEND_DATA_POS + 12, write_data, write_len);
    if (dlt645_send_msg(ctx, dlt645_send_buf, 24 + write_len) < 0)
    {
        sdk_log_a("send data error!\n");
        return -1;
    }

    if (dlt645_receive_msg(ctx, dlt645_read_buf, DLT645_RESP_LEN, code) < 0)
    {
        sdk_log_a("receive msg error!\n");
        return -1;
    }
    return 0;
}
/******************************************************************************
 * dlt645_write_port()
 * dlt645 write data module. [Called by task.]
 *
 * @param ctx (I) ctx
 * @param buf (I) send buf
 * @param len (I) send len
 * @return  0:success, -1:fail
 *****************************************************************************/
int32_t dlt645_write_port(struct dlt645 *ctx, uint8_t *buf, uint16_t len)
{
	int32_t ret = 0;

	ret = sdk_uart_write(ctx->port_index, buf, len);
    return ret;
}

/******************************************************************************
 * dlt645_recv_port()
 * dlt645 recv data module. [Called by task.]
 *
 * @param ctx (I) ctx
 * @param buf (I) read buf
 * @param len (I) read len
 * @return  0:success, -1:fail
 *****************************************************************************/
int32_t dlt645_recv_port(struct dlt645 *ctx, uint8_t *buf, uint16_t len)
{
    return sdk_uart_read(ctx->port_index, buf, len, ctx->timeout);
}

/******************************************************************************
 * dlt645_port_init()
 * dlt645 port init module. [Called by task.]
 *
 * @param ctx (I) ctx
 * @param port_index (I) port index
 * @param premble_len (I) preble len
 * @param timeout (I) timeout
 * @return  0:success, -1:fail
 *****************************************************************************/
void dlt645_port_init(uint8_t port_index)
{
	int32_t ret;
	sdk_uart_conf_t p_uart_conf;

	p_uart_conf.baud_rate = SDK_UART_BAUD_RATE_9600;
	p_uart_conf.data_bits = SDK_UART_DATA_BITS_8;
	p_uart_conf.flow_ctrl = SDK_UART_HWFLOW_OFF;
	p_uart_conf.parity    = SDK_UART_PARITY_EVEN;
	p_uart_conf.stop_bit  = SDK_UART_STOP_BITS_1;

	ret = sdk_uart_open(port_index);
	if(ret != SF_OK)
	{
		sdk_log_i("open uart %d failure!", port_index);
	}
	else
	{
		sdk_uart_setup(port_index, &p_uart_conf);
		if(ret != SF_OK)
		{
			sdk_log_i("setup uart %d failure!", port_index);
		}
	}
}

/******************************************************************************
 * dlt645_param_init()
 * dlt645 param init module. [Called by task.]
 *
 * @param ctx (I) ctx
 * @param port_index (I) port index
 * @param premble_len (I) preble len
 * @param timeout (I) timeout
 * @return  0:success, -1:fail
 *****************************************************************************/
void dlt645_param_init(dlt645_t *ctx, uint8_t port_index, uint8_t premble_len, uint8_t *addr, uint16_t timeout)
{
    ctx->write = dlt645_write_port;
    ctx->read = dlt645_recv_port;
    if(addr != NULL)
    {
        dlt645_set_addr(ctx, addr);
    }
    dlt645_set_timeout(ctx, timeout);
    dlt645_set_debug(ctx, 0);
    dlt645_set_port_index(ctx, port_index);
	dlt645_set_premble_code_len(ctx, premble_len);
}
/******************************************************************************
 * dlt645_init()
 * dlt645 init module. [Called by task.]
 *
 * @param ctx (I) ctx
 * @param port_index (I) port index
 * @param premble_len (I) preble len
 * @param timeout (I) timeout
 * @return  0:success, -1:fail
 *****************************************************************************/
void dlt645_init(dlt645_t *ctx, uint8_t port_index, uint8_t premble_len, uint8_t *addr, uint16_t timeout)
{
    dlt645_port_init(port_index);
    dlt645_param_init(ctx, port_index, premble_len, addr, timeout);
}

/******************************************************************************
* End of module
******************************************************************************/
