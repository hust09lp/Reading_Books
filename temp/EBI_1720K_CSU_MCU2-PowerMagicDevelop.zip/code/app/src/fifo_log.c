/******************************************************************************
 *
 * FILE IDENTIFICATION
 * -------------------
 *
 * File Name   : fifo_log.c
 * Description : FIFO LOG functional module
 *
 * $RCSfile    : $
 * $Author     : $
 * $Date       : $
 * $Revision   : $
 *
 ******************************************************************************
 * Copyright (c) SOFAR SH 2021
 * All right reserved.
 *****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "array.h"
#include "fifo_log.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define FIFO_LOG_SIZE                                                      0x40
/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
log_t g_log_write;
log_t g_log_buff[FIFO_LOG_SIZE];
sdk_os_mutex_attr_t g_log_mutex;

fifo_log_t g_fifo_log;

uint8_t opt_log_info[ONE_DIAG_LOG_SIZE * 2];
uint8_t diag_log_info[ONE_DIAG_LOG_SIZE * 2];
uint8_t debug_log_info[ONE_DIAG_LOG_SIZE * 2];
uint8_t app_log[ONE_DIAG_LOG_SIZE * 2];

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/******************************************************************************
 * fifo_log_init().
 * Initialize log FIFO module. [Called by the sw_init()]
 *
 * @param none (I)
 * @param none (O)
 * @return none
 *****************************************************************************/
void fifo_log_init(void)
{
	clear_struct_data((uint8_t *)&g_log_write, sizeof(log_t));
    clear_struct_data((uint8_t *)&g_log_buff[0], sizeof(g_log_buff));
    clear_struct_data((uint8_t *)&g_log_mutex, sizeof(sdk_os_mutex_attr_t));
    clear_struct_data((uint8_t *)&g_fifo_log, sizeof(fifo_log_t));
    clear_struct_data(&opt_log_info[0], sizeof(opt_log_info));
    clear_struct_data(&diag_log_info[0], sizeof(diag_log_info));
    clear_struct_data(&debug_log_info[0], sizeof(debug_log_info));
    clear_struct_data(&app_log[0], sizeof(app_log));
    g_fifo_log.empty = TRUE;
    g_fifo_log.buff = &g_log_buff[0];
    g_fifo_log.size = FIFO_LOG_SIZE;

}

/******************************************************************************
 * fifo_log_push().
 * Push a log to a log FIFO. [Called by the task()]
 *
 * @param *log (I) a log to be pushed
 * @param *fifo_log  (O) a log FIFO to be pushed
 * @return TRUE(success), FALSE(failure)
 *****************************************************************************/
bool_t fifo_log_push(fifo_log_t *fifo_log, log_t *log)
{
	bool_t result = FALSE;
	int32_t ret = 0;

	// NULL pointer protection
	if((!fifo_log) |
	(!log))
	{
		// Release sharing resources
		ret = sdk_os_mutex_release(fifo_log->busy);
		if(ret != SDK_OS_OK)
		{
			sdk_log_d("sdk_os_mutex_release fail:%d", ret);
		}
		return result;
	}
	// FIFO full protection
	if(fifo_log->full)
	{
		fifo_log->lost_cnt++;
		// Release sharing resources
		ret = sdk_os_mutex_release(fifo_log->busy);
		if(ret != SDK_OS_OK)
		{
			sdk_log_d("sdk_os_mutex_release fail:%d", ret);
		}
		return result;
	}
	fifo_log->buff[fifo_log->head++] = *log;
	if(fifo_log->head >= fifo_log->size)
	{
		fifo_log->head = 0;
	}

	fifo_log->empty = FALSE;
	fifo_log->len++;
	if(fifo_log->len >= fifo_log->max_len)
	{
		fifo_log->max_len = fifo_log->len;
	}
	if(fifo_log->len >= fifo_log->size)
	{
		fifo_log->full = TRUE;
	}

	// Release sharing resources
	ret = sdk_os_mutex_release(fifo_log->busy);
	if(ret != SDK_OS_OK)
	{
		sdk_log_d("sdk_os_mutex_release fail:%d", ret);
	}

	result = TRUE;
	return result;
}

/******************************************************************************
 * fifo_log_pop().
 * Pop a log from a log FIFO. [Called by the task()]
 *
 * @param *log (I) a log to be popped
 * @param *fifo_log  (O) a log FIFO to be popped
 * @return TRUE(success), FALSE(failure)
 *****************************************************************************/
bool_t fifo_log_pop(fifo_log_t *fifo_log, log_t *log)
{
	bool_t result = FALSE;
	int32_t ret = 0;

	// NULL pointer protection
	if((!fifo_log) |
	(!log))
	{
		// Release sharing resources
		ret = sdk_os_mutex_release(fifo_log->busy);
		if(ret != SDK_OS_OK)
		{
			sdk_log_d("sdk_os_mutex_release fail:%d", ret);
		}
		return result;
	}
	// FIFO empty protection
	if(fifo_log->empty)
	{
		// Release sharing resources
		ret = sdk_os_mutex_release(fifo_log->busy);
		if(ret != SDK_OS_OK)
		{
			sdk_log_d("sdk_os_mutex_release fail:%d", ret);
		}
		return result;
	}
	*log = fifo_log->buff[fifo_log->tail++];
	if(fifo_log->tail >= fifo_log->size)
	{
		fifo_log->tail = 0;
	}

	fifo_log->full = FALSE;
	fifo_log->len--;
	if(fifo_log->len == 0)
	{
		fifo_log->empty = TRUE;
	}

	// Release sharing resources
	ret = sdk_os_mutex_release(fifo_log->busy);
	if(ret != SDK_OS_OK)
	{
		sdk_log_d("sdk_os_mutex_release fail:%d", ret);
	}
	result = TRUE;

	return result;
}

/******************************************************************************
 * app_log_write().
 * app write log including diagnostic log and operation log. [Called by check/reset log write fuction.]
 *
 * @param  log  (I) write log
 * @return type (O) log type : 0: diagnostic log, 1: operation log
 *****************************************************************************/
void app_log_write(uint8_t *log, uint16_t type)
{
	sdk_rtc_t temp_rtc;
	log_t log_temp = {0};
	uint8_t len = 0;

    clear_struct_data((uint8_t *)&log_temp, sizeof(log_t));

	log_temp.code = type;
	switch (log_temp.code)
	{
		case DIAG_LOG:
			len = ONE_DIAG_LOG_SIZE;
			break;
		case OPAT_LOG:
			len = ONE_OPAT_LOG_SIZE;
			break;
		case DEBUG_LOG:
			len = ONE_DEBUG_LOG_SIZE;
			break;
		default:
			break;
	}
	clear_struct_data(&app_log[0], len * 2);

	temp_rtc = array.csu.rtc;
	snprintf((char *)app_log, sizeof(app_log),"\r\n%04d/%02d/%02d %02d:%02d:%02d: %s", \
					temp_rtc.tm_year + 2000, temp_rtc.tm_mon, temp_rtc.tm_day,\
					temp_rtc.tm_hour, temp_rtc.tm_min, temp_rtc.tm_sec, log);
	if(app_log[len] != 0)
	{
		memory_copy(log_temp.info, &app_log[len], len);
		fifo_log_push(&g_fifo_log, &log_temp);
	}
	memory_copy(log_temp.info, &app_log, len);
	fifo_log_push(&g_fifo_log, &log_temp);
}

/******************************************************************************
 * bkgd_task_log_write().
 * log write task module. [Called by background task group.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void bkgd_task_log_write(void)
{
    uint8_t ret;
    bool_t result = TRUE;
	uint16_t len = 0;

    if(!g_log_write.rewrite)
    {
        g_log_write.enable = fifo_log_pop(&g_fifo_log, &g_log_write);
    }

    if(g_log_write.enable)
    {
		if(g_log_write.code >= LOG_TYPE_NUM)
		{
			sdk_log_a("g_log_write.code error");
			result = TRUE;
		}
		else
		{
			switch (g_log_write.code)
			{
				case DIAG_LOG:
					len = ONE_DIAG_LOG_SIZE;
					break;
				case OPAT_LOG:
					len = ONE_OPAT_LOG_SIZE;
					break;
				case DEBUG_LOG:
					len = ONE_DEBUG_LOG_SIZE;
					break;
				default:
					break;
			}
			ret = sdk_record_write(g_log_write.code, WRITE_NEW_LOG, g_log_write.info, len);
			if(ret != SF_OK)
			{
				sdk_log_d("log  %d write error!\r\n", g_log_write.code);
				result = FALSE;
			}
			else
			{
				ret = sdk_record_sync(g_log_write.code);
				if(ret != SF_OK)
				{
					sdk_log_d("log  %d write error!\r\n", g_log_write.code);
					result = FALSE;
				}
			}
		}
		if (!result)
		{
			g_log_write.rewrite = TRUE;
		}
		else
		{
			g_log_write.rewrite = FALSE;
		}
	}
}

/******************************************************************************
* End of module
******************************************************************************/
