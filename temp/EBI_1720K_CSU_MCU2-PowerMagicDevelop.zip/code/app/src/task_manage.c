/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     task_manage.c
  * @brief    App tasks management module
  * @company  SOFARSOLAR
  * @author   HH
  * @note
  * @version  V01
  * @date     2023/02/22
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "app_dido.h"
#include "array.h"
#include "cup_sofar_can.h"
#include "diag_manage.h"
#include "fifo_can.h"
#include "fifo_log.h"
//#include "fut.h"
#include "iec104.h"
#include "iec61850.h"
#include "iso_detect.h"
#include "measure.h"
#include "others.h"
#include "pcs.h"
#include "pcsc_diag.h"
#include "pcsc_diag_log.h"
#include "pcsc_opt_log.h"
#include "pcs_sequence.h"
#include "power_manage.h"
//#include "rs485_hmi.h"
#include "rtc.h"
#include "safe_parm.h"
#include "sdk.h"
#include "sdk_core.h"
#include "task_manage.h"
#include "tpll.h"
#include "sci_mcu1.h"
#include "can1_bus.h"
#include "fut_rs485.h"
#include "ems.h"
#include "rs485_device_manage.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
// Task execution mask
#define MASK_NONE                                          (uint32_t)0xFFFFFFFF
#define MASK_ALL                                           (uint32_t)0x00000000

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
task_t task_array[] =
{
	// Mask-Bits   Type       Run()                         Event                   Phase   Period
	// CRITICAL GROUP(100us)
	{MASK_NONE, TY_PERIOD, &crtl_task_heartbeat,                     NULL,                    4,      5000  },
	{MASK_NONE, TY_PERIOD, &crtl_task_ac_sample,                     NULL,                    1,      1     },
	{MASK_NONE, TY_PERIOD, &crtl_task_dc_sample,                     NULL,                    2,      2     },
	{MASK_NONE, TY_PERIOD, &crtl_task_mux_sample,                    NULL,                    3,      200   },
	{MASK_NONE, TY_PERIOD, &crtl_task_tpll,                          NULL,                    1,      1     },
	// FAST GROUP(10ms)
	{MASK_NONE, TY_PERIOD, &fast_task_heartbeat,                     NULL,                    1,      100   },
	{MASK_NONE, TY_EV_TRG, &fast_task_diagnostic,                &trigger_diag_task,          1,      1     },
	{MASK_NONE, TY_EV_TRG, &fast_task_pcs_sm,                    &trigger_pcs_sm,             1,      100   },
	{MASK_NONE, TY_PERIOD, &fast_task_measure,                       NULL,                    1,      1     },
	{MASK_NONE, TY_EV_TRG, &fast_task_pcs_const,                 &trigger_pcs_const,          5,      100   },
	{MASK_NONE, TY_PERIOD, &fast_task_fault_update,                  NULL,                    6,      10    },
	{MASK_NONE, TY_EV_TRG, &fast_task_clear_info,                &clear_loss_info,            8,      10    },
	{MASK_NONE, TY_PERIOD, &fast_task_calc,                          NULL,                    9,      10    },
	{MASK_NONE, TY_PERIOD, &fast_task_rtc,                           NULL,                    1,      50    },
	{MASK_NONE, TY_EV_TRG, &fast_task_local_ems,                 &trigger_local_ems,          1,      1000  },
	{MASK_NONE, TY_EV_TRG, &fast_task_xiao_ju,                   &trigger_xiao_ju,            1,      70    },
	{MASK_NONE, TY_PERIOD, &fast_task_can1_send,                     NULL,                    1,      1     },
	// SLOW GROUP(100ms)
	{MASK_NONE, TY_PERIOD, &slow_task_heartbeat,                     NULL,                    1,      10    },
	{MASK_NONE, TY_PERIOD, &slow_task_measure,                       NULL,                    1,      1     },
	{MASK_NONE, TY_EV_TRG, &slow_task_di,                        &trigger_di,                 1,      1     },
	{MASK_NONE, TY_EV_TRG, &slow_task_do,                        &trigger_do,                 1,      1     },
	{MASK_NONE, TY_PERIOD, &slow_task_total_runtime,                 NULL,                    1,      600   },
	{MASK_NONE, TY_PERIOD, &slow_task_others,                        NULL,                    1,      1     },
	{MASK_NONE, TY_PERIOD, &slow_task_set_pcsm_nums,                 NULL,                    2,      10    },
    {MASK_NONE, TY_PERIOD, &slow_task_set_scenario,                  NULL,                    1,      1     },
    {MASK_NONE, TY_PERIOD, &slow_task_cmu_check,                     NULL,                    1,      10    },
	{MASK_NONE, TY_PERIOD, &slow_task_cmu_soc_compute,               NULL,                    1,      10    },
	{MASK_NONE, TY_PERIOD, &slow_task_bat_status_get,                NULL,                    1,      10    },
	{MASK_NONE, TY_PERIOD, &slow_task_power_allocate_switch,         NULL,                    1,      10    },
	{MASK_NONE, TY_PERIOD, &slow_task_ems_soc_compute,               NULL,                    1,      10    },
	{MASK_NONE, TY_PERIOD, &slow_task_calc_power_limit,              NULL,                    1,      10    },
	{MASK_NONE, TY_EV_TRG, &slow_task_planning_scheduling,       &trigger_plan_scheduler,     1,      600   },
	{MASK_NONE, TY_EV_TRG, &slow_task_model_read,                &trigger_model_read,         1,      1     },
	{MASK_NONE, TY_EV_ONE, &slow_task_power_magic_init,          &trigger_pm_init,            1,      1     },
	{MASK_NONE, TY_EV_TRG, &slow_task_bat_capacity_test,         &trigger_bat_capacity_test,  1,      1     },
	{MASK_NONE, TY_EV_ONE, &slow_task_sn_analysis,               &g_trigger_sn_analysis,      1,      1     },
	{MASK_NONE, TY_EV_TRG, &slow_task_heart_check,               &trigger_heart_check,        1,      1     },
	{MASK_NONE, TY_EV_TRG, &slow_task_power_resend,              &trigger_power_resend,       1,      100   },
	{MASK_NONE, TY_EV_TRG, &slow_task_drmn_resend,               &trigger_power_resend,       2,      100   },
	{MASK_NONE, TY_EV_ONE, &slow_task_ems_close,               	 &g_trigger_close_ems,        1,      1     },
	{MASK_NONE, TY_PERIOD, &slow_task_debug_record,                  NULL,                    1,      18000 },
	{MASK_NONE, TY_EV_TRG, &slow_task_pcs_rating,                &trigger_pcsc_ratings,       2,      10    },
	// RS485 GROUP(100ms)
	{MASK_NONE, TY_EV_TRG, &rs485_task_fut,                      &trigger_fut_rs485,          1,      1     }, // RS485-1
	{MASK_NONE, TY_EV_TRG, &rs485_task_device_manage,            &trigger_rs485_manage,       1,      1     },
	{MASK_NONE, TY_EV_TRG, &rs485_task_backflow_meter,           &trigger_backflow_meter,     1,      1     }, // RS485-2
	{MASK_NONE, TY_EV_TRG, &rs485_task_pv_power,                 &g_trigger_pv_meter_sw,      1,      1     }, // RS485-5
	{MASK_NONE, TY_EV_TRG, &rs485_task_mm_power,                 &trigger_metering_meter,     1,      1     }, // RS485-1
	{MASK_NONE, TY_EV_TRG, &rs485_task_meter2,                   &trigger_meter2,             1,      1     }, // RS485-5
	{MASK_NONE, TY_EV_TRG, &rs485_task_meter3,                   &trigger_meter3[0],          1,      1     }, // RS485-7
	{MASK_NONE, TY_EV_TRG, &rs485_task_measure_control,          &trigger_measure_control,    1,      1     },
	{MASK_NONE, TY_EV_TRG, &rs485_task_microcomputer,            &trigger_microcomputer,      1,      1     },
	{MASK_NONE, TY_EV_TRG, &rs485_task_dehumidification,         &trigger_dehumidifier,       1,      1     }, // RS485-7
	{MASK_NONE, TY_EV_TRG, &rs485_task_meter2_other,             &trigger_meter2,             1,      1     }, // RS485-5
	{MASK_NONE, TY_EV_TRG, &rs485_task_meter3_other,             &trigger_meter3[0],          1,      1     }, // RS485-7
	{MASK_NONE, TY_EV_TRG, &rs485_task_pv_meter,                 &g_trigger_pv_meter_sw,      2,      3     }, // RS485-5
	{MASK_NONE, TY_EV_TRG, &rs485_task_pcc_meter_data,           &trigger_backflow_meter,     3,      3     }, // RS485-2
	{MASK_NONE, TY_EV_TRG, &rs485_task_metering_meter,           &trigger_metering_meter,     1,      3     }, // RS485-1
	// BACKGROUND GROUP
	{MASK_NONE, TY_PERIOD, &bkgd_task_idle,                           NULL,                   0,      0     },
	{MASK_NONE, TY_PERIOD, &bkgd_task_log_write,                      NULL,                   0,      0     },
	{MASK_NONE, TY_EV_TRG, &bkgd_task_restore_factory,           &trigger_restore_factory,    0,      0     },
};

task_group_t crtl_group;
task_group_t fast_group;
task_group_t slow_group;
task_group_t rs485_group;
task_group_t bkgd_group;

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/******************************************************************************
 * task_manage_init().
 * Initialize task management module. [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void task_manage_init(void)
{
	crtl_group.size = CRTL_GROUP_END - CRTL_GROUP_START;
	crtl_group.task = &task_array[CRTL_GROUP_START];

	fast_group.size = FAST_GROUP_END - FAST_GROUP_START;
	fast_group.task = &task_array[FAST_GROUP_START];

	slow_group.size = SLOW_GROUP_END - SLOW_GROUP_START;
	slow_group.task = &task_array[SLOW_GROUP_START];

	rs485_group.size = RS485_GROUP_END - RS485_GROUP_START;
	rs485_group.task = &task_array[RS485_GROUP_START];

	bkgd_group.size = BKGD_GROUP_END - BKGD_GROUP_START;
	bkgd_group.task = &task_array[BKGD_GROUP_START];
}

/******************************************************************************
 * crtl_task_heartbeat().
 * Critical task hearbeat, indicating the health of critical task group.
 * [Called by task scheduler.]
 *
 * @param none (I)
 * @return none.
 *****************************************************************************/
void crtl_task_heartbeat(void)
{
}

/******************************************************************************
 * fast_task_heartbeat().
 * Fast task hearbeat, indicating the health of fast task group.
 * [Called by task scheduler.]
 *
 * @param none (I)
 * @return none.
 *****************************************************************************/
void fast_task_heartbeat(void)
{
	//sdk_log_d("FG001 fast_task_heartbeat\r\n");
}

/******************************************************************************
 * slow_task_heartbeat().
 * Slow task hearbeat, indicating the health of slow task group.
 * [Called by task scheduler.]
 *
 * @param none (I)
 * @return none.
 *****************************************************************************/
void slow_task_heartbeat(void)
{
	static uint8_t led_toggle = 0;
	pcsm_cmd_t can_cmd_temp;

	can_cmd_temp.dst_addr = PCSM_BCAST_ID;
	can_cmd_temp.fun_code = AUTO_HEART_BEAT;
	can_cmd_temp.len = 0;
	can_cmd_temp.offset.all = 0;
	if(SLAVE == array.csu.csu_data.csu_heart.csu_role)
	{
		task_array[FAST_TASK_LOCAL_EMS].period = FAST_EMS_PERIOD;
		task_array[FAST_TASK_XIAO_JU].period = FAST_EMS_PERIOD;
	}
	else
	{
		task_array[FAST_TASK_LOCAL_EMS].period = SLOW_EMS_PERIOD;
		task_array[FAST_TASK_XIAO_JU].period = SLOW_EMS_PERIOD;
	}
	if((power_magic_init_ok) && (csu_data.csu_heart.working_mode == NORMAL_MODE))
	{
		fifo_can_push(&fifo_can1_cmd, &can_cmd_temp);
	}

	if(led_toggle == 0)
	{
		sdk_led_on(0);
	}
	else
	{
		sdk_led_off(0);
	}

	led_toggle = !led_toggle;
}

/******************************************************************************
 * slow_task_power_magic_init().
 * Initialize variables by different model(690V/400V). [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void slow_task_power_magic_init(void)
{
	if(!trigger_bat_capacity_test)
	{
		trigger_rack_manage = TRUE;
	}
	trigger_di = TRUE;
	trigger_do = TRUE;
	if(pre_product_model != product_info.model_num)
	{
		ems_init(product_info.model_num);
		pre_product_model = product_info.model_num;
	}
	if(ONE_STORAGE_TANK_XIAOJU_1_2 == array.pcsc.pcsc_ctrl.scenario_setting)
	{
		trigger_xiao_ju = TRUE;
		trigger_local_ems = FALSE;
	}
	else
	{
		trigger_xiao_ju = FALSE;
		trigger_local_ems = TRUE;
	}
	pcsc_other_diag_init();
	if(array.pcsc.pcsc_ctrl.scenario_setting != ONLY_COMBINER_CABINET)
	{
		trigger_fut_rs485 = FALSE;
	}
	rs485_device_port_init();
	g_rs485_device_enable.all = 0;
	trigger_rs485_manage = TRUE;
	trigger_pcsc_ratings = TRUE;
	// Initial completed
	power_magic_init_ok = TRUE;
}

/******************************************************************************
 * bkgd_task_idle().
 * Idle task module, do nothing. [Called by background task group.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void bkgd_task_idle(void)
{
}

/******************************************************************************
 * slow_task_debug_record().
 * write log. [Called by.]
 *
 * @param none  (I)
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void slow_task_debug_record(void)
{
	uint8_t i;

	for (i = 0; i < CMU_NUMS; i++)
	{
		if(array.cmu[i].sys_status != CMU_SYS_UNKOWN)
		{
			debug_log_record("CMU%d status: %d/%d,chg soc/soh:%d/%d,dch soc/soh:%d/%d",\
							i + 1, \
							array.cmu[i].sys_status, \
							array.cmu[i].bat_status, \
							array.cmu[i].soc_chg, \
							array.cmu[i].soh_chg, \
							array.cmu[i].soc_dch, \
							array.cmu[i].soh_dch);
			if(MASTER == array.csu.csu_data.csu_heart.csu_role)
			{
				debug_log_record("CMU%d dcMaxChg/Dch:%d/%d,acMaxChg/Dch:%d/%d",\
								i + 1, \
								array.pcsc.pcsc_ctrl.bat_status_info.chg_lmt_power[i], \
								array.pcsc.pcsc_ctrl.bat_status_info.dch_lmt_power[i], \
								pcsm_chg_dch_limit[i].chg_limit, \
								pcsm_chg_dch_limit[i].dch_limit);
			}
			else
			{
				debug_log_record("CMU%d dcMaxChg/Dch:%d/%d,acMaxChg/Dch:%d/%d",\
								i + 1, \
								array.pcsc.pcsc_ctrl.bat_status_info.chg_lmt_power[i], \
								array.pcsc.pcsc_ctrl.bat_status_info.dch_lmt_power[i], \
								array.pcsc.pcsc_data.pcsm_data[i].state.derate_sout_intport, \
								array.pcsc.pcsc_data.pcsm_data[i].state.derate_sout_outport);
			}
			debug_log_record("CMU%d chg_ctrl:0x%X,dch_ctrl:0x%X",\
							i + 1, \
							array.pcsc.pcsc_ctrl.bat_status_info.chg_ctrl.all, \
							array.pcsc.pcsc_ctrl.bat_status_info.dch_ctrl.all);
		}
		else
		{
			debug_log_record("CMU%d status: %d/%d",\
							i + 1, \
							array.cmu[i].sys_status, \
							array.cmu[i].bat_status);
		}
	}
	debug_log_record("pmInitFlag:%d,mode:%d/%d,role:%d,Power:%d(%d/%d/%d/%d/%d/%d),AntiBackflow:%.1f", \
					power_magic_init_ok, \
					trigger_rack_manage, \
					trigger_bat_capacity_test, \
					array.csu.csu_data.csu_heart.csu_role, \
					array.pcsc.pcsc_ctrl.active_power_ref, \
					array.pcsc.pcsc_data.pcsm_data[0].set[WRITE_INDEX].active_power_ref, \
					array.pcsc.pcsc_data.pcsm_data[1].set[WRITE_INDEX].active_power_ref, \
					array.pcsc.pcsc_data.pcsm_data[2].set[WRITE_INDEX].active_power_ref, \
					array.pcsc.pcsc_data.pcsm_data[3].set[WRITE_INDEX].active_power_ref, \
					array.pcsc.pcsc_data.pcsm_data[4].set[WRITE_INDEX].active_power_ref, \
					array.pcsc.pcsc_data.pcsm_data[5].set[WRITE_INDEX].active_power_ref, \
					ems.ammeter.power);
	debug_log_record("cmu num:%d/%d,rated_capacity:%d, baseRatedPower:%d", \
						array.array_data.variable.cmu_online, \
						array.array_data.variable.cmu_running, \
						ems.rated_capacity, \
						array.csu.csu_data.csu_const.base_rated_power);
	debug_log_record("485 disconn/conn 1:%d/%d,2:%d/%d,3:%d/%d,pv:%d/%d,backflow:%d/%d", \
						meter1_disconn_count, \
						meter1_conn_count, \
						meter2_disconn_count, \
						meter2_conn_count, \
						meter3_disconn_count, \
						meter3_conn_count, \
						pv_meter_disconn_count, \
						pv_meter_conn_count, \
						backflow_disconn_count, \
						backflow_conn_count);
	debug_log_record("EmsMark:%d/%d/%d/%d/%d/%d,EmsFlag:%d/%d/%d/%d/%d/%d,ChgLim:%d/%d,DchLim:%d/%d,soc min/max:%d/%d", \
						ems.demand_side.mark, \
						ems.anti_backflow.mark, \
						ems.automatic.mark, \
						ems.c2d.mark, \
						ems.cpfv.mark, \
						ems.soc_maint.mark, \
						debug_info_data.check_flag[DEBUG_USE_DEMAND_SIDE], \
						debug_info_data.check_flag[DEBUG_USE_ANTI_BACKFLOW], \
						debug_info_data.check_flag[DEBUG_USE_AUTOMATIC], \
						debug_info_data.check_flag[DEBUG_USE_C2D], \
						debug_info_data.check_flag[DEBUG_USE_CPFV], \
						debug_info_data.check_flag[DEBUG_USE_SOC_MAINT], \
						ems.inter_min_chg_power, \
						ems.inter_max_chg_power, \
						ems.inter_min_dch_power, \
						ems.inter_max_dch_power, \
						ems.soc_min_cmu, \
						ems.soc_max_cmu);
	debug_log_record("meter model:%d/%d/%d/%d,VolRatio:%d/%d/%d/%d/%d/%d/%d/%d/%d/%d,CurRatio:%d/%d/%d/%d/%d/%d/%d/%d/%d/%d", \
										ems.backflow_meter_switch, \
										pv_meter_parm.pv_meter_model, \
										xiao_ju.ammeter2_model_switch, \
										xiao_ju.ammeter3_model_switch, \
										ems.backflow_voltage_ratio, \
										pv_meter_parm.pv_meter_vol_ratio[0], \
										pv_meter_parm.pv_meter_vol_ratio[1], \
										pv_meter_parm.pv_meter_vol_ratio[2], \
										xiao_ju.ammeter2_voltage_ratio, \
										xiao_ju.ammeter3_voltage_ratio[0], \
										xiao_ju.ammeter3_voltage_ratio[1], \
										xiao_ju.ammeter3_voltage_ratio[2], \
										xiao_ju.ammeter3_voltage_ratio[3], \
										xiao_ju.ammeter3_voltage_ratio[4], \
										ems.backflow_current_ratio, \
										pv_meter_parm.pv_meter_cur_ratio[0], \
										pv_meter_parm.pv_meter_cur_ratio[1], \
										pv_meter_parm.pv_meter_cur_ratio[2], \
										xiao_ju.ammeter2_current_ratio, \
										xiao_ju.ammeter3_current_ratio[0], \
										xiao_ju.ammeter3_current_ratio[1], \
										xiao_ju.ammeter3_current_ratio[2], \
										xiao_ju.ammeter3_current_ratio[3], \
										xiao_ju.ammeter3_current_ratio[4]);
	debug_log_record("drmn:%X", array.pcsc.pcsc_ctrl.drmn_status);
	if(ONE_STORAGE_TANK_XIAOJU_1_2 == array.pcsc.pcsc_ctrl.scenario_setting)
	{
		debug_log_record("xiaojuAmmeter:2:%.1f,3:%.1f(%.1f/%.1f/%.1f/%.1f/%.1f)",\
						xiaoju_ammeter.ammeter_2, \
						xiaoju_ammeter.ammeter_3, \
						meter3_power_old[0], \
						meter3_power_old[1], \
						meter3_power_old[2], \
						meter3_power_old[3], \
						meter3_power_old[4]);
	}
}
/******************************************************************************
* End of module
******************************************************************************/
