/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     modbus_tcp.c
  * @brief    modbus_tcp
  * @company  SOFARSOLAR
  * @author   WWX
  * @note
  * @version  V01
  * @date     2023/07/15
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "sdk.h"
#include "sdk_core.h"
#include "sdk_modbus.h"
#include "modbus_tcp.h"
#include "fifo_can.h"
#include "pcs.h"
#include "array.h"
#include "calibration.h"
#include "pcsc_opt_log.h"
#include "power_manage.h"
#include "can1_bus.h"
/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
static uint8_t modbus_tcp_rx_buf[MOD_FRAME_MAX_NUM];
uint16_t *modbus_reg[MOD_PARA_NUM] = {0};

DATA_RW_E modbus_reg_hold_buf_rw;

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/
/******************************************************************************
 * modbus_tcp_init().
 * Initialize upgrade module. [Called by app.]
 *
 * @param	none (I)
 * @return	none (O)
 *****************************************************************************/
void modbus_tcp_init(void)
{
	modbus_regs_hold_init();
	clear_struct_data((uint8_t *)&modbus_tcp_rx_buf[0], sizeof(modbus_tcp_rx_buf));
}

/******************************************************************************
 * void regs_hold_init(void).
 * Initialized holding registers. [Called by modbus init funtion.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void modbus_regs_hold_init(void)
{
	uint8_t addr = 0;
	modbus_reg[addr++] = (uint16_t *)&array.csu.csu_data.csu_const.system_rated_power;
	modbus_reg[addr++] = (uint16_t *)&array.pcsc.pcsc_data.var.power_p;
	modbus_reg[addr++] = (uint16_t *)&array.pcsc.pcsc_data.var.power_q;
	modbus_reg[addr++] = (uint16_t *)&array.pcsc.pcsc_ctrl.pcsc_on_off;
	modbus_reg[addr++] = (uint16_t *)&array.pcsc.pcsc_data.state.sys_state;
	modbus_reg[addr++] = (uint16_t *)&array.pcsc.pcsc_data.var.max_chargable_power;
	modbus_reg[addr++] = (uint16_t *)&array.pcsc.pcsc_data.var.max_dischargable_power;
	modbus_reg[addr++] = (uint16_t *)&array.pcsc.pcsc_data.var.increasable_reactive_power;
	modbus_reg[addr++] = (uint16_t *)&array.pcsc.pcsc_data.var.decreasable_reactive_power;
	modbus_reg[addr++] = (uint16_t *)&array.pcsc.pcsc_data.var.soc_operation_val;
	modbus_reg[addr++] = (uint16_t *)&array.pcsc.pcsc_data.var.power_p;
	modbus_reg[addr++] = (uint16_t *)&array.pcsc.pcsc_data.var.power_q;
}

/******************************************************************************
 * thread_modbus_tcp_parse().
 * parse CAN module. [Called by the thread()]
 *
 * @param none (I)
 * @param none (O)
 * @return none
 *****************************************************************************/
void thread_modbus_tcp_parse(void *argument)
{
	bool_t rec_flag;
	int32_t ret;
	int32_t socket;
	sdk_modbus_tcp_init(MODBUS_TCP, 1, "0.0.0.0", 502);
	socket = sdk_modbus_tcp_listen(MODBUS_TCP, 2);
	sdk_modbus_indication_timeout_set(MODBUS_TCP,10000);

	while(1)
	{
		ret = sdk_modbus_tcp_accept(MODBUS_TCP, &socket);

		sdk_log_i("sdk_modbus_tcp_accept = %d\r\n",ret);

		if (ret != -1)
		{
			rec_flag = TRUE;
			while(rec_flag)
			{
				ret = sdk_modbus_receive(MODBUS_TCP, modbus_tcp_rx_buf);
				if (ret > 0)
				{
					sdk_modbus_reply(MODBUS_TCP, modbus_tcp_rx_buf, ret, modbus_tcp_parse);
				}
				else if (ret == -1)
				{
					sdk_modbus_close(MODBUS_TCP);
					rec_flag = FALSE;;
				}
			}
		}
	}
	//sdk_modbus_free(MODBUS_TCP);
}


/******************************************************************************
 * modbus_tcp_parse()
 * modbus frame parse. [Called by slow fut task.]
 *
 * @param func      (I) function code
 * @param p_req     (I) modbus request frame
 * @param p_rsp     (I) modbus response frame
 * @param rsp_size  (I) modbus response frame size
 * @return -1 : error, >0 : lenght of sending data
 *****************************************************************************/
int32_t modbus_tcp_parse(uint32_t index, uint32_t func, const uint8_t *p_req,
												uint8_t *p_rsp, int32_t rsp_size)
{
	int32_t result = -1;
	uint16_t reg_addr;
	uint16_t reg_num;
	const uint8_t *p_data = NULL;
	half_word_t temp;

	if((p_req == NULL) || (p_rsp == NULL))
	{
		return result;
	}

	temp.bytes.high = p_req[0];
	temp.bytes.low  = p_req[1];
	reg_addr = temp.all;
	temp.bytes.high = p_req[2];
	temp.bytes.low  = p_req[3];
	reg_num  = temp.all;

	switch(func)
	{
		case MODBUS_READ_HOLDING_REGISTERS:
			result  = modbus_tcp_read_hold_reg(reg_addr, reg_num, p_rsp);
			break;
		case MODBUS_WRITE_SINGLE_REGISTER:
			reg_num = 1;
			p_data  = p_req + 2;
			result  = modbus_tcp_write_hold_reg(reg_addr, reg_num, p_data);
			// addr
			p_rsp[0] = p_req[0];
			p_rsp[1] = p_req[1];
			// num
			p_rsp[2] = p_req[2];
			p_rsp[3] = p_req[3];
			break;
		case MODBUS_WRITE_MULTIPLE_REGISTERS:
			p_data = p_req + 5;
			result = modbus_tcp_write_hold_reg(reg_addr, reg_num, p_data);
			// addr
			p_rsp[0] = p_req[0];
			p_rsp[1] = p_req[1];
			// num
			p_rsp[2] = p_req[2];
			p_rsp[3] = p_req[3];
			break;
		default:
			break;
	}

	return result;
}

/******************************************************************************
 * modbus_tcp_read_hold_reg()
 * slave read holding regs by modbus tcp. [Called by modbus parse function.]
 *
 * @param reg_addr  (I) register start address
 * @param reg_num   (I) register numbers
 * @param p_rsp     (I) modbus response frame
 * @return -1 : error, >0 : length of sending data
 *****************************************************************************/
int32_t modbus_tcp_read_hold_reg(uint16_t reg_addr, uint16_t reg_num, uint8_t *p_rsp)
{
	int32_t result = -1;

	if((reg_addr >= REG_ADDRESS_START) && (reg_addr <= REG_ADDRESS_END))
	{
		result = modbus_read_hold_reg(reg_addr, reg_num, p_rsp);
	}
	return result;
}

/******************************************************************************
 * modbus_read_hold_reg()
 * slave read holding regs by modbus tcp. [Called by modbus parse function.]
 *
 * @param reg_addr  (I) register start address
 * @param reg_num   (I) register numbers
 * @param p_rsp     (I) modbus response frame
 * @return -1 : error, >0 : length of sending data
 *****************************************************************************/
int32_t modbus_read_hold_reg(uint16_t reg_addr, uint16_t reg_num, uint8_t *p_rsp)
{
	uint16_t i;
	uint16_t addr_start;
	uint16_t pointer = 1;
	int32_t result = -1;
	half_word_t temp;
	uint16_t reg_id = 0;

	*p_rsp = reg_num * 2;
	addr_start = reg_addr - REG_ADDRESS_START;
	switch (addr_start)
	{
	case SYSTEM_RATED_POWER_ADDR:
		reg_id = SYSTEM_RATED_POWER;
		break;
	case ACTIVE_POWER_ADDR:
		reg_id = ACTIVE_POWER;
		break;
	case REACTIVE_POWER_ADDR:
		reg_id = REACTIVE_POWER;
		break;
	case RUNNING_STATE_ADDR:
		reg_id = RUNNING_STATE;
		break;
	case MAX_CHARGEABLE_P0WER_ADDR:
		reg_id = MAX_CHARGEABLE_P0WER;
		break;
	case MAX_DISCHARGEABLE_P0WER_ADDR:
		reg_id = MAX_DISCHARGEABLE_P0WER;
		break;
	case INCREASED_REACTIVE_POWER_ADDR:
		reg_id = INCREASED_REACTIVE_POWER;
		break;
	case REDUCED_REACTIVE_POWER_ADDR:
		reg_id = REDUCED_REACTIVE_POWER;
		break;
	case SOC_RUNNING_VAL_ADDR:
		reg_id = SOC_RUNNING_VAL;
		break;
	case REAL_TIME_ACTIVEPOWER_ADDR:
		reg_id = REAL_TIME_ACTIVEPOWER;
		break;
	case REAL_TIME_REACTIVE_POWER_ADDR:
		reg_id = REAL_TIME_REACTIVE_POWER;
		break;
	default:
		break;
	}

	if(modbus_reg_hold_buf_rw == DATA_FREE)
	{
		modbus_reg_hold_buf_rw = DATA_READING;
		for(i = 0; i < reg_num; i++)
		{
			temp.all = *modbus_reg[reg_id + i];
			*(p_rsp + pointer++) = temp.bytes.high;
			*(p_rsp + pointer++) = temp.bytes.low;
		}
		modbus_reg_hold_buf_rw = DATA_FREE;
		result = pointer;
	}

	return result;
}

/******************************************************************************
 * modbus_tcp_write_hold_reg()
 * slave read holding regs by modbus tcp. [Called by modbus parse function.]
 *
 * @param reg_addr  (I) register start address
 * @param reg_num   (I) register numbers
 * @param p_rsp     (I) modbus response frame
 * @return -1 : error, >0 : length of sending data
 *****************************************************************************/
int32_t modbus_tcp_write_hold_reg(uint16_t reg_addr, uint16_t reg_num, const uint8_t *p_data)
{
	uint8_t i;
	uint16_t reg_value;
	int32_t result = -1;
	int32_t ret    = 4;
	half_word_t temp;

	if(modbus_reg_hold_buf_rw == DATA_FREE)
	{
		modbus_reg_hold_buf_rw = DATA_WRITING;
		for(i = 0; i < reg_num; i++)
		{
			temp.bytes.high = *p_data;
			temp.bytes.low  = *(p_data + 1);
			reg_value = temp.all;
			result = modbus_write_hold_reg(reg_addr, reg_value, p_data);
			reg_addr++;
			p_data = p_data + 2;
			if(result == -1)
			{
				ret = -1;
			}
		}
		modbus_reg_hold_buf_rw = DATA_FREE;
	}
	else
	{
		ret = 0;
	}

	return ret;
}


/******************************************************************************
 * modbus_write_hold_reg()
 * slave write holding regs by modbus tcp. [Called by modbus parse function.]
 *
 * @param reg_addr  (I) register start address
 * @param reg_num   (I) register numbers
 * @param p_rsp     (I) modbus response frame
 * @return -1 : error, >0 : length of sending data
 *****************************************************************************/
int32_t modbus_write_hold_reg(uint16_t reg_addr, uint16_t reg_value, const uint8_t *p_data)
{
	uint16_t func;
	int32_t  result = 2;

	func = reg_addr - REG_ADDRESS_START;

	switch(func)
	{
		case ACTIVE_POWER_ADDR:
			*modbus_reg[ACTIVE_POWER] = reg_value;
			if(0 == reg_value)
			{
				opt_log_record("modbus tcp, value:%d -> %d", \
							array.pcsc.pcsc_ctrl.active_power_ref, reg_value);
				sdk_log_a("set power from modbus tcp, value:%d -> %d\r\n", \
							array.pcsc.pcsc_ctrl.active_power_ref, reg_value);
			}
			if(array.pcsc.pcsc_ctrl.power_control_source == CONTROL_NETWORK_MODE)
			{
				array.pcsc.pcsc_ctrl.active_power_ref = reg_value;
				g_active_power_send = TRUE;
			}
			break;
		case REACTIVE_POWER_ADDR:
			*modbus_reg[REACTIVE_POWER] = reg_value;
			if(array.pcsc.pcsc_ctrl.power_control_source == CONTROL_NETWORK_MODE)
			{
				array.pcsc.pcsc_ctrl.reactive_power_ref = reg_value;
				g_reactive_power_send = TRUE;
			}
			break;
		default:
			result = -1;
			sdk_log_d("modbus tcp set para wrong!\r\n");
			break;
	}
	return result;
}

/******************************************************************************
* End of module
******************************************************************************/
