/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     diag_manage.c
  * @brief    Diagnostic manage application module
  * @company  SOFARSOLAR
  * @author   HH
  * @note
  * @version  V01
  * @date     2023/02/22
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "array.h"
#include "app_dido.h"
#include "csu_data.h"
#include "device.h"
#include "diag_manage.h"
#include "ems.h"
#include "pcs.h"
#include "pcsc_diag.h"
#include "pcsc_diag_log.h"
#include "sdk.h"
#include "sdk_core.h"
#include "sci_mcu1.h"
#include "rs485_device_manage.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
uint8_t standard_scenario_400v[] =
{
	// This parameter is applicable to fault diagnosis only when the mask is trigger_diag[]
	FAST_DIAG_CSU_BOARD_OTW,
	FAST_DIAG_AC_TANK_OTW,
	FAST_DIAG_CSU_BOARD_OTP,
	FAST_DIAG_AC_TANK_OTP,
	FAST_DIAG_CSU_BOARD_UTW,
	FAST_DIAG_AC_TANK_UTW,
	FAST_DIAG_CSU_BOARD_NTC,
	FAST_DIAG_AC_TANK_NTC,
	FAST_DIAG_WATER_LEAK,
	FAST_DIAG_DOOR_UNLOCK,
	FAST_DIAG_AC_SPD,
	FAST_DIAG_PCSC_FAN1,
	FAST_DIAG_PCSC_FAN2,
	FAST_DIAG_CMU_FAULT,
	FAST_DIAG_REMOTE_EPO,
	FAST_DIAG_STS_SW_POS,
	FAST_DIAG_BYPASS_FAULT,
	FAST_DIAG_SPD1,
	FAST_DIAG_SPD2,
	FAST_DIAG_QF1_SW,
	UINT8_MAX,
};

uint16_t standard_scenario_400v_di[SYS_STATE_WORD_NUM] =
{
	UINT16_MAX, // state 1 mask, keep all DI status
	UINT16_MAX, // state 2 mask, keep all DI status
};

uint8_t only_combiner_cabinet_400v[] =
{
	// This parameter is applicable to fault diagnosis only when the mask is trigger_diag[]
	FAST_DIAG_CSU_BOARD_OTW,
	FAST_DIAG_AC_TANK_OTW,
	FAST_DIAG_CSU_BOARD_OTP,
	FAST_DIAG_AC_TANK_OTP,
	FAST_DIAG_CSU_BOARD_UTW,
	FAST_DIAG_AC_TANK_UTW,
	FAST_DIAG_CSU_BOARD_NTC,
	FAST_DIAG_AC_TANK_NTC,
	FAST_DIAG_WATER_LEAK,
	FAST_DIAG_DOOR_UNLOCK,
	FAST_DIAG_AC_SPD,
	FAST_DIAG_PCSC_FAN1,
	FAST_DIAG_PCSC_FAN2,
	UINT8_MAX,
};

uint16_t only_combiner_cabinet_400v_di[SYS_STATE_WORD_NUM] =
{
	(BIT_MASK(DI_MASK_RUNNING_STATE)| \
		BIT_MASK(DI_MASK_WATER_IN)| \
		BIT_MASK(DI_MASK_DOOR)| \
		BIT_MASK(DI_MASK_AC_SPD)| \
		BIT_MASK(DI_MASK_FAN1_STATUS)| \
		BIT_MASK(DI_MASK_FAN2_STATUS)), // state 1 mask
	(BIT_MASK(DI_MASK_QA0)| \
		BIT_MASK(DI_MASK_QA1)| \
		BIT_MASK(DI_MASK_QA2)| \
		BIT_MASK(DI_MASK_QA3)| \
		BIT_MASK(DI_MASK_QA4)| \
		BIT_MASK(DI_MASK_QA5)| \
		BIT_MASK(DI_MASK_QA6)| \
		BIT_MASK(DO_MASK_FAN)), // state 2 mask
};

uint8_t combiner_storage_400v[] =
{
	// This parameter is applicable to fault diagnosis only when the mask is trigger_diag[]
	FAST_DIAG_CSU_BOARD_OTW,
	FAST_DIAG_AC_TANK_OTW,
	FAST_DIAG_CSU_BOARD_OTP,
	FAST_DIAG_AC_TANK_OTP,
	FAST_DIAG_CSU_BOARD_UTW,
	FAST_DIAG_AC_TANK_UTW,
	FAST_DIAG_CSU_BOARD_NTC,
	FAST_DIAG_AC_TANK_NTC,
	FAST_DIAG_WATER_LEAK,
	FAST_DIAG_DOOR_UNLOCK,
	FAST_DIAG_AC_SPD,
	FAST_DIAG_PCSC_FAN1,
	FAST_DIAG_PCSC_FAN2,
	FAST_DIAG_CMU_FAULT,
	UINT8_MAX,
};

uint16_t combiner_storage_400v_di[SYS_STATE_WORD_NUM] =
{
	(BIT_MASK(DI_MASK_RUNNING_STATE)| \
		BIT_MASK(DI_MASK_WATER_IN)| \
		BIT_MASK(DI_MASK_DOOR)| \
		BIT_MASK(DI_MASK_AC_SPD)| \
		BIT_MASK(DI_MASK_FAN1_STATUS)| \
		BIT_MASK(DI_MASK_FAN2_STATUS)| \
		BIT_MASK(DI_MASK_CMU_FAULT)), // state 1 mask
	(BIT_MASK(DI_MASK_QA0)| \
		BIT_MASK(DI_MASK_QA1)| \
		BIT_MASK(DI_MASK_QA2)| \
		BIT_MASK(DI_MASK_QA3)| \
		BIT_MASK(DI_MASK_QA4)| \
		BIT_MASK(DI_MASK_QA5)| \
		BIT_MASK(DI_MASK_QA6)| \
		BIT_MASK(DO_MASK_FAN)), // state 2 mask
};

uint8_t standard_scenario_690v[] =
{
	// This parameter is applicable to fault diagnosis only when the mask is trigger_diag[]
	FAST_DIAG_CSU_BOARD_OTW,
	FAST_DIAG_AC_TANK_OTW,
	FAST_DIAG_CSU_BOARD_OTP,
	FAST_DIAG_AC_TANK_OTP,
	FAST_DIAG_CSU_BOARD_UTW,
	FAST_DIAG_AC_TANK_UTW,
	FAST_DIAG_CSU_BOARD_NTC,
	FAST_DIAG_GRID_TIED_POS,
	FAST_DIAG_ISO_DEV_FAULT,
	FAST_DIAG_ISO_FAULT,
	FAST_DIAG_CMU_FAULT,
	FAST_DIAG_REMOTE_EPO,
	UINT8_MAX,
};

uint16_t standard_scenario_690v_di[SYS_STATE_WORD_NUM] =
{
	UINT16_MAX, // state 1 mask, keep all DI status
	UINT16_MAX, // state 2 mask, keep all DI status
};

// Only the energy storage cabinet needs to be opened
uint8_t one_storage_tank_400v[] =
{
	// This parameter is applicable to fault diagnosis only when the mask is trigger_diag[]
	FAST_DIAG_CSU_BOARD_OTW,
	FAST_DIAG_CSU_BOARD_OTP,
	FAST_DIAG_CSU_BOARD_UTW,
	FAST_DIAG_CSU_BOARD_NTC,
	FAST_DIAG_CMU_FAULT,
	UINT8_MAX,
};

uint16_t one_storage_tank_400v_di[SYS_STATE_WORD_NUM] =
{
	(BIT_MASK(DI_MASK_RUNNING_STATE)| \
		BIT_MASK(DI_MASK_CMU_FAULT)), // state 1 mask
	// 0x8001, // state 1 mask, keep bit-15 status(CMU STATUS)/ bit0
	0x0000, // state 2 mask, ignore all DI status
};

// Only the energy storage cabinet needs to be opened
uint8_t one_storage_tank_690v[] =
{
	// This parameter is applicable to fault diagnosis only when the mask is trigger_diag[]
	FAST_DIAG_CSU_BOARD_OTP,
	FAST_DIAG_CSU_BOARD_OTW,
	FAST_DIAG_CSU_BOARD_UTW,
	FAST_DIAG_CSU_BOARD_NTC,
	UINT8_MAX,
};

uint16_t one_storage_tank_690v_di[SYS_STATE_WORD_NUM] =
{
	0x0000, // state 1 mask, ignore all DI status
	0x0000, // state 2 mask, ignore all DI status
};

diag_t diag_array[] =
{
// FAST GROUP(10ms)
//    fault                         type        mask                                         value                                    threshold                     hyst  pha   prd   hpn  hpn_to  rst  rst_to  chk                        rst                        log_chk                         log_rst
	{&fault_csu_board_otw,          DT_UPP,     &trigger_diag[FAST_DIAG_CSU_BOARD_OTW],      &array.pcsc.pcsc_data.var.t_board,       &set_otw,                     100,  1,    100,  0,   2,      0,   10,     NULL,                      NULL,                      &log_check_csu_board_otw,       &log_reset_csu_board_otw        },
	{&fault_ac_tank_otw,            DT_UPP,     &trigger_diag[FAST_DIAG_AC_TANK_OTW],        &array.pcsc.pcsc_data.var.t_ac_fuse,     &set_otw,                     100,  2,    100,  0,   2,      0,   10,     NULL,                      NULL,                      &log_check_ac_tank_otw,         &log_reset_ac_tank_otw          },
	{&fault_csu_board_otp,          DT_UPP,     &trigger_diag[FAST_DIAG_CSU_BOARD_OTP],      &array.pcsc.pcsc_data.var.t_board,       &set_otp,                     100,  3,    100,  0,   2,      0,   10,     NULL,                      NULL,                      &log_check_csu_board_otp,       &log_reset_csu_board_otp        },
	{&fault_ac_tank_otp,            DT_UPP,     &trigger_diag[FAST_DIAG_AC_TANK_OTP],        &array.pcsc.pcsc_data.var.t_ac_fuse,     &set_otp,                     100,  4,    100,  0,   2,      0,   10,     NULL,                      NULL,                      &log_check_ac_tank_otw,         &log_reset_ac_tank_otw          },
	{&fault_csu_board_utw,          DT_DWN,     &trigger_diag[FAST_DIAG_CSU_BOARD_UTW],      &array.pcsc.pcsc_data.var.t_board,       &set_utw,                     100,  5,    100,  0,   2,      0,   10,     NULL,                      NULL,                      &log_check_csu_board_utw,       &log_reset_csu_board_utw        },
	{&fault_ac_tank_utw,            DT_DWN,     &trigger_diag[FAST_DIAG_AC_TANK_UTW],        &array.pcsc.pcsc_data.var.t_ac_fuse,     &set_utw,                     100,  6,    100,  0,   2,      0,   10,     NULL,                      NULL,                      &log_check_ac_tank_otw,         &log_reset_ac_tank_otw          },
	{&fault_csu_board_ntc,          DT_OTH,     &trigger_diag[FAST_DIAG_CSU_BOARD_NTC],      NULL,                                    NULL,                         0,    7,    100,  0,   2,      0,   10,     &csu_board_ntc_check,      &csu_board_ntc_reset,      &log_check_csu_board_ntc,       &log_reset_csu_board_ntc        },
	{&fault_ac_tank_ntc,            DT_OTH,     &trigger_diag[FAST_DIAG_AC_TANK_NTC],        NULL,                                    NULL,                         0,    8,    100,  0,   2,      0,   10,     &ac_tank_ntc_check,        &ac_tank_ntc_reset,        &log_check_ac_tank_otw,         &log_reset_ac_tank_otw          },
	{&fault_water_leak,             DT_OTH,     &trigger_diag[FAST_DIAG_WATER_LEAK],         NULL,                                    NULL,                         0,    9,    100,  0,   2,      0,   10,     &water_leak_check,         &water_leak_reset,         &log_check_water_leak,          &log_reset_water_leak           },
	{&fault_door_unlock,            DT_OTH,     &trigger_diag[FAST_DIAG_DOOR_UNLOCK],        NULL,                                    NULL,                         0,    10,   100,  0,   2,      0,   10,     &door_unlock_check,        &door_unlock_reset,        &log_check_door_unlock,         &log_reset_door_unlock          },
	{&fault_ac_spd_fail,            DT_OTH,     &trigger_diag[FAST_DIAG_AC_SPD],             NULL,                                    NULL,                         0,    11,   100,  0,   2,      0,   10,     &ac_spd_check,             &ac_spd_reset,             &log_check_ac_spd,              &log_reset_ac_spd               },
	{&fault_grid_tied_pos,          DT_OTH,     &trigger_diag[FAST_DIAG_GRID_TIED_POS],      NULL,                                    NULL,                         0,    12,   100,  0,   2,      0,   10,     &grid_tied_pos_check,      &grid_tied_pos_reset,      &log_check_grid_tied_pos,       &log_reset_grid_tied_pos        },
	{&fault_pcsc_fan1,              DT_OTH,     &trigger_diag[FAST_DIAG_PCSC_FAN1],          NULL,                                    NULL,                         0,    14,   100,  0,   2,      0,   10,     &pcsc_fan1_check,          NULL,                      &log_check_pcsc_fan1,           &log_reset_pcsc_fan1            },
	{&fault_pcsc_fan2,              DT_OTH,     &trigger_diag[FAST_DIAG_PCSC_FAN2],          NULL,                                    NULL,                         0,    15,   100,  0,   2,      0,   10,     &pcsc_fan2_check,          NULL,                      &log_check_pcsc_fan2,           &log_reset_pcsc_fan2            },
	{&fault_iso_dev_fault,          DT_OTH,     &trigger_diag[FAST_DIAG_ISO_DEV_FAULT],      NULL,                                    NULL,                         0,    16,   100,  0,   2,      0,   10,     &iso_dev_fail_check,       &iso_dev_fail_reset,       &log_check_iso_dev_fail,        &log_reset_iso_dev_fail         },
	{&fault_iso_fault,              DT_OTH,     &trigger_diag[FAST_DIAG_ISO_FAULT],          NULL,                                    NULL,                         0,    17,   100,  0,   10,     0,   10,     &iso_fault_check,          &iso_fault_reset,          &log_check_iso_fault,           &log_reset_iso_fault            },
	{&fault_cmu_fault,              DT_OTH,     &trigger_diag[FAST_DIAG_CMU_FAULT],          NULL,                                    NULL,                         0,    18,   100,  0,   10,     0,   10,     &cmu_fault_check,          &cmu_fault_reset,          &log_check_cmu_fault,           &log_reset_cmu_fault            },
	{&fault_remote_epo,             DT_OTH,     &trigger_diag[FAST_DIAG_REMOTE_EPO],         NULL,                                    NULL,                         0,    19,   100,  0,   2,      0,   10,     &remote_epo_check,         &remote_epo_reset,         &log_check_remote_epo,          &log_reset_remote_epo           },
//    fault                         type        mask                                         value                                    threshold                     hyst  pha   prd   hpn  hpn_to  rst  rst_to  chk                        rst                        log_chk                         log_rst
	{&fault_pcsm_ac_breaker[0],     DT_OTH,     &trigger_fuse_diag[0],                       NULL,                                    NULL,                         0,    20,   100,  0,   10,     0,   10,     &pcsm1_ac_breaker_check,   &pcsm1_ac_breaker_reset,   &log_check_pcsm1_ac_breaker,    &log_reset_pcsm1_ac_breaker     },
	{&fault_pcsm_ac_breaker[1],     DT_OTH,     &trigger_fuse_diag[1],                       NULL,                                    NULL,                         0,    21,   100,  0,   10,     0,   10,     &pcsm2_ac_breaker_check,   &pcsm2_ac_breaker_reset,   &log_check_pcsm2_ac_breaker,    &log_reset_pcsm2_ac_breaker     },
	{&fault_pcsm_ac_breaker[2],     DT_OTH,     &trigger_fuse_diag[2],                       NULL,                                    NULL,                         0,    22,   100,  0,   10,     0,   10,     &pcsm3_ac_breaker_check,   &pcsm3_ac_breaker_reset,   &log_check_pcsm3_ac_breaker,    &log_reset_pcsm3_ac_breaker     },
	{&fault_pcsm_ac_breaker[3],     DT_OTH,     &trigger_fuse_diag[3],                       NULL,                                    NULL,                         0,    23,   100,  0,   10,     0,   10,     &pcsm4_ac_breaker_check,   &pcsm4_ac_breaker_reset,   &log_check_pcsm4_ac_breaker,    &log_reset_pcsm4_ac_breaker     },
	{&fault_pcsm_ac_breaker[4],     DT_OTH,     &trigger_fuse_diag[4],                       NULL,                                    NULL,                         0,    24,   100,  0,   10,     0,   10,     &pcsm5_ac_breaker_check,   &pcsm5_ac_breaker_reset,   &log_check_pcsm5_ac_breaker,    &log_reset_pcsm5_ac_breaker     },
	{&fault_pcsm_ac_breaker[5],     DT_OTH,     &trigger_fuse_diag[5],                       NULL,                                    NULL,                         0,    25,   100,  0,   10,     0,   10,     &pcsm6_ac_breaker_check,   &pcsm6_ac_breaker_reset,   &log_check_pcsm6_ac_breaker,    &log_reset_pcsm6_ac_breaker     },
//    fault                         type        mask                                         value                                    threshold                     hyst  pha   prd   hpn  hpn_to  rst  rst_to  chk                        rst                        log_chk                         log_rst
	{&fault_pcsm_can1[0],           DT_OTH,     &trigger_comm_diag[0],                       NULL,                                    NULL,                         1,    26,   100,  0,   1,      0,    1,     &pcsm1_can1_check,         &pcsm1_can1_reset,         &log_check_pcsm1_can1,          &log_reset_pcsm1_can1           },
	{&fault_pcsm_can1[1],           DT_OTH,     &trigger_comm_diag[1],                       NULL,                                    NULL,                         1,    27,   100,  0,   1,      0,    1,     &pcsm2_can1_check,         &pcsm2_can1_reset,         &log_check_pcsm2_can1,          &log_reset_pcsm2_can1           },
	{&fault_pcsm_can1[2],           DT_OTH,     &trigger_comm_diag[2],                       NULL,                                    NULL,                         1,    28,   100,  0,   1,      0,    1,     &pcsm3_can1_check,         &pcsm3_can1_reset,         &log_check_pcsm3_can1,          &log_reset_pcsm3_can1           },
	{&fault_pcsm_can1[3],           DT_OTH,     &trigger_comm_diag[3],                       NULL,                                    NULL,                         1,    29,   100,  0,   1,      0,    1,     &pcsm4_can1_check,         &pcsm4_can1_reset,         &log_check_pcsm4_can1,          &log_reset_pcsm4_can1           },
	{&fault_pcsm_can1[4],           DT_OTH,     &trigger_comm_diag[4],                       NULL,                                    NULL,                         1,    30,   100,  0,   1,      0,    1,     &pcsm5_can1_check,         &pcsm5_can1_reset,         &log_check_pcsm5_can1,          &log_reset_pcsm5_can1           },
	{&fault_pcsm_can1[5],           DT_OTH,     &trigger_comm_diag[5],                       NULL,                                    NULL,                         1,    31,   100,  0,   1,      0,    1,     &pcsm6_can1_check,         &pcsm6_can1_reset,         &log_check_pcsm6_can1,          &log_reset_pcsm6_can1           },
	{&fault_metering_meter,         DT_UPP,     &trigger_metering_meter,                     &fault_metering_meter_cnt,               &fault_metering_meter_ref,    1,    32,   100,  0,   10,     0,    0,     NULL,                      NULL,                      &log_check_metering_meter,      &log_reset_metering_meter       },
	{&fault_backflow_meter,         DT_UPP,     &trigger_backflow_meter,                     &fault_backflow_meter_cnt,               &fault_backflow_meter_ref,    1,    33,   100,  0,   10,     0,    0,     NULL,                      NULL,                      &log_check_backflow_meter,      &log_reset_backflow_meter       },
	{&fault_microcomputer,          DT_UPP,     &trigger_microcomputer,                      &fault_microcomputer_cnt,                &fault_microcomputer_ref,     1,    34,   100,  0,   10,     0,    0,     NULL,                      NULL,                      &log_check_microcomputer,       &log_reset_microcomputer        },
	{&fault_dehumidifier,           DT_UPP,     &trigger_dehumidifier,                       &fault_dehumidifier_cnt,                 &fault_dehumidifier_ref,      1,    35,   100,  0,   10,     0,    0,     NULL,                      NULL,                      &log_check_dehumidifier,        &log_reset_dehumidifier         },
	{&fault_measure_control,        DT_UPP,     &trigger_measure_control,                    &fault_measure_cnt,                      &fault_measure_ref,           1,    36,   100,  0,   10,     0,    0,     NULL,                      NULL,                      &log_check_measure_control,     &log_reset_measure_control      },
	{&fault_model_read,             DT_OTH,     &trigger_model_read_fault_diag,              NULL,                                    NULL,                         0,    37,   100,  0,   60,     0,   10,     &model_read_check,         &model_read_reset,         &log_check_model_read,          &log_reset_model_read           },
	{&fault_anti_backflow,          DT_UPP,     &trigger_anti_backflow_diag,                 &fault_anti_backflow_cnt,                &fault_anti_backflow_ref,     1,    38,   100,  0,   2,      0,   10,     NULL,                      NULL,                      &log_check_anti_backflow,       &log_reset_anti_backflow        },
//   fault                          type        mask                                         value                                    threshold                     hyst  pha   prd   hpn  hpn_to  rst  rst_to  chk                        rst                        log_chk                         log_rst
	{&fault_sts_sw_pos,             DT_OTH,     &trigger_diag[FAST_DIAG_STS_SW_POS],         NULL,                                    NULL,                         0,    39,   100,  0,   2,      0,   10,     &sts_sw_pos_check,         &sts_sw_pos_reset,         &log_check_sts_sw_pos,          &log_reset_sts_sw_pos           },
	{&fault_bypass_fault,           DT_OTH,     &trigger_diag[FAST_DIAG_BYPASS_FAULT],       NULL,                                    NULL,                         0,    40,   100,  0,   2,      0,   10,     &bypass_fault_check,       &bypass_fault_reset,       &log_check_bypass_fault,        &log_reset_bypass_fault         },
	{&fault_spd1_fail,              DT_OTH,     &trigger_diag[FAST_DIAG_SPD1],               NULL,                                    NULL,                         0,    41,   100,  0,   2,      0,   10,     &spd1_status_check,        &spd1_status_reset,        &log_check_spd1_status,         &log_reset_spd1_status          },
	{&fault_spd2_fail,              DT_OTH,     &trigger_diag[FAST_DIAG_SPD2],               NULL,                                    NULL,                         0,    42,   100,  0,   2,      0,   10,     &spd2_status_check,        &spd2_status_reset,        &log_check_spd2_status,         &log_reset_spd2_status          },
	{&fault_qf1_fail,               DT_OTH,     &trigger_diag[FAST_DIAG_QF1_SW],             NULL,                                    NULL,                         0,    43,   100,  0,   2,      0,   10,     &qf1_status_check,         &qf1_status_reset,         &log_check_qf1_status,          &log_reset_qf1_status           },
	{&fault_meter2,                 DT_UPP,     &trigger_meter2,                             &fault_meter2_cnt,                       &fault_meter2_ref,            1,    44,   100,  0,   10,     0,    0,     NULL,                      NULL,                      &log_check_meter2,              &log_reset_meter2               },
	{&fault_meter3[0],              DT_UPP,     &trigger_meter3[0],                          &fault_meter3_cnt[0],                    &fault_meter3_ref,            1,    45,   100,  0,   10,     0,    0,     NULL,                      NULL,                      &log_check_meter3_1,            &log_reset_meter3_1             },
	{&fault_meter3[1],              DT_UPP,     &trigger_meter3[1],                          &fault_meter3_cnt[1],                    &fault_meter3_ref,            1,    46,   100,  0,   10,     0,    0,     NULL,                      NULL,                      &log_check_meter3_2,            &log_reset_meter3_2             },
	{&fault_meter3[2],              DT_UPP,     &trigger_meter3[2],                          &fault_meter3_cnt[2],                    &fault_meter3_ref,            1,    47,   100,  0,   10,     0,    0,     NULL,                      NULL,                      &log_check_meter3_3,            &log_reset_meter3_3             },
	{&fault_meter3[3],              DT_UPP,     &trigger_meter3[3],                          &fault_meter3_cnt[3],                    &fault_meter3_ref,            1,    48,   100,  0,   10,     0,    0,     NULL,                      NULL,                      &log_check_meter3_4,            &log_reset_meter3_4             },
	{&fault_meter3[4],              DT_UPP,     &trigger_meter3[4],                          &fault_meter3_cnt[4],                    &fault_meter3_ref,            1,    49,   100,  0,   10,     0,    0,     NULL,                      NULL,                      &log_check_meter3_5,            &log_reset_meter3_5             },
	{&fault_pv_meter[0],            DT_UPP,     &g_trigger_pv_meter[0],                      &fault_pv_meter_cnt[0],                  &fault_pv_meter_ref,          1,    50,   100,  0,   10,     0,    0,     NULL,                      NULL,                      &log_check_pv_meter_1,          &log_reset_pv_meter_1           },
	{&fault_pv_meter[1],            DT_UPP,     &g_trigger_pv_meter[1],                      &fault_pv_meter_cnt[1],                  &fault_pv_meter_ref,          1,    51,   100,  0,   10,     0,    0,     NULL,                      NULL,                      &log_check_pv_meter_2,          &log_reset_pv_meter_2           },
	{&fault_pv_meter[2],            DT_UPP,     &g_trigger_pv_meter[2],                      &fault_pv_meter_cnt[2],                  &fault_pv_meter_ref,          1,    52,   100,  0,   10,     0,    0,     NULL,                      NULL,                      &log_check_pv_meter_3,          &log_reset_pv_meter_3           },
// SLOW GROUP(100ms)
//   fault           type     mask    value   threshold      hyst  chk   rst  log_chk log_rst pha prd hpn hpn_to rst rst_to
//	{&fault_amb_otp, DT_UPE,  NULL,   &t_amb, &set_amb_otp,   20, NULL,  NULL, NULL,   NULL,   1, 100, 0,  2,    0,  5,  },

};

static uint16_t  trigger_diag_time_record;
bool_t trigger_diag_task = FALSE;
diag_group_t fast_diag_group;
diag_group_t slow_diag_group;

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/******************************************************************************
 * diag_manage_init().
 * Initialize diagnostic module. [Called by sw_init()]
 *
 * @param none (I)
 * @param none (O)
 * @return none
 *****************************************************************************/
void diag_manage_init(void)
{
    trigger_diag_time_record = 0;
	trigger_diag_task = FALSE;

	fast_diag_group.size = FAST_DIAG_GROUP_END - FAST_DIAG_GROUP_START;
	fast_diag_group.diag = &diag_array[FAST_DIAG_GROUP_START];

//	slow_diag_group.size = SLOW_DIAG_GROUP_END - SLOW_DIAG_GROUP_START;
//	slow_diag_group.diag = &diag_array[SLOW_DIAG_GROUP_START];
}

/******************************************************************************
 * delay_diag_task().
 * delay 10s, enable diag tasks. [Called by slow_task_others.]
 *
 * @param	none (I)
 * @return	none
 *****************************************************************************/
void delay_diag_task(void)
{
	if(trigger_diag_time_record >= 400)
	{
		trigger_diag_task = TRUE;
	}
	else
	{
		trigger_diag_time_record++;
	}
}
/******************************************************************************
 * fast_task_diagnostic().
 * Execute fast diagnostic group. [Called by fast_task()]
 *
 * @param none (I)
 * @param none (O)
 * @return none
 *****************************************************************************/
void fast_task_diagnostic(void)
{
	//sdk_log_d("FG002 fast_task_diagnostic\r\n");
	diagnostic(&fast_diag_group);
}

/******************************************************************************
 * fast_task_fault_update().
 * Update diagnostic results to global fault words. [Called by app()]
 *
 * @param none (I)
 * @param none (O)
 * @return none
 *****************************************************************************/
void fast_task_fault_update(void)
{
	if(fault_reset_flag)
	{
		// Wait a period of time for the web interface synchronization failure
		trigger_diag_time_record = 0;
		trigger_diag_task = FALSE;

		clear_fault();
		fault_reset_flag = FALSE;
		array.pcsc.pcsc_ctrl.cmd.bit.fault_reset = 0;
	}
	pcsc_fault_update();
}

/******************************************************************************
 * diag_enable().
 * Start a diagnostic task. [Called by app()]
 *
 * @param diag_handle (I) DIAG_ID(0~SLOW_DIAG_GROUP_END)
 * @param none        (O)
 * @return none
 *****************************************************************************/
void diag_enable(DIAG_ID diag_handle)
{
	// out of array protection
	if(diag_handle >= DIAG_ARRAY_SIZE)
	{
		return;
	}
	*(diag_array[diag_handle].mask) = 1;
}

/******************************************************************************
 * diag_disable().
 * Stop a diagnostic task. [Called by slow_task()]
 *
 * @param diag_handle (I) DIAG_ID(0~SLOW_DIAG_GROUP_END)
 * @param none        (O)
 * @return none
 *****************************************************************************/
void diag_disable(DIAG_ID diag_handle)
{
	// out of array protection
	if(diag_handle >= DIAG_ARRAY_SIZE)
	{
		return;
	}
	*(diag_array[diag_handle].mask) = 0;
}

/******************************************************************************
 * clear_fault().
 * Clear manually fault. [Called by app]
 *
 * @param none        (I)
 * @param none        (O)
 * @return none
 *****************************************************************************/
void clear_fault(void)
{
    uint8_t i = 0;

    for(i = 0; i < DIAG_ARRAY_SIZE; i++)
    {
        *(diag_array[i].fault) = 0;
    }
}

/******************************************************************************
* End of module
******************************************************************************/
