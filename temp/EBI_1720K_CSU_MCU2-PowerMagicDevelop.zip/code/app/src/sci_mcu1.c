/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     sci_mcu1.c
  * @brief
  * @company  SOFARSOLAR
  * @author   GZQ
  * @note
  * @version  V01
  * @date     2023/04/14
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
#include <stddef.h>

#include "array.h"
#include "crc.h"
#include "iec61850.h"
#include "pcs.h"
#include "pcsc_diag_log.h"
#include "product.h"
#include "pcs_sequence.h"
#include "fifo_can.h"
#include "fifo_log.h"
#include "safe_parm.h"
#include "sci_mcu1.h"
#include "sdk.h"
#include "sdk_core.h"
#include "sdk_uart.h"
#include "setting.h"
#include "upgrade.h"
#include "iec104.h"
#include "pcsc_opt_log.h"
#include "power_manage.h"
#include "app_dido.h"
#include "pcsc_opt_log.h"
#include "ems.h"
#include "setting.h"
#include "rs485_device_manage.h"
#include "task_manage.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define SCI_START_WORD_H                                                   0x55
#define SCI_START_WORD_L                                                   0xAA
#define SCI_MIN_LEN                                                           9
#define SCI_BUF_SIZE                                                        256

// sci function code
#define SFC_HANDSHAKED_H                                                   0x10
#define SFC_HANDSHAKED_L                                                   0x00

#define SFC_SET_H                                                          0x20
#define SFC_SET_SYS_TIME                                                   0x00
#define SFC_SET_POWER_REF                                                  0x01
#define SFC_SET_ENET_PARM                                                  0x02
#define SFC_SET_EMS_CONST                                                  0x03
#define SFC_SET_BAT_PARM                                                   0x04
#define SFC_SET_UART_PARM                                                  0x05
#define SFC_SET_FACTORY_PARM                                               0x07
#define SFC_SET_MCU2_NOTE                                                  0x08
#define SFC_SET_SYS_SN                                                     0x09
#define SFC_SET_HOLIDAY_DATA                                               0x0A
#define SFC_SET_DRMN                                                       0x0B
#define SFC_SET_PCSM_PARM                                                  0x10
#define SFC_SET_M_S_CONST                                                  0x11
#define SFC_SET_M_S_VAR                                                    0x12
#define SFC_SET_PV_PARM                                                    0x13
#define SFC_SET_EMS_VAR                                                    0x14
#define SFC_SET_REMOTE_CONTROL                                             0x15
#define SFC_SET_REMOTE_ADJUST                                              0x16
#define SFC_SET_SAFE_BASIC                                                 0x20
#define SFC_SET_SAFE_GRP1                                                  0x21
#define SFC_SET_SAFE_GRP2                                                  0x22
#define SFC_SET_SAFE_GRP3                                                  0x23
#define SFC_SET_SAFE_GRP4                                                  0x24
#define SFC_SET_SAFE_GRP5                                                  0x25
#define SFC_SET_SAFE_GRP6                                                  0x26
#define SFC_SET_SAFE_GRP7                                                  0x27
#define SFC_SET_SAFE_GRP8                                                  0x28
#define SFC_SET_SAFE_GRP9                                                  0x29
#define SFC_SET_XIAO_JU_CONST                                              0x30
#define SFC_SET_XIAO_JU_VAR                                                0x31

#define SFC_GET_H                                                          0x30
#define SFC_GET_SYS_TIME                                                   0x00
#define SFC_GET_POWER_REF                                                  0x01
#define SFC_GET_ENET_DATA                                                  0x02
#define SFC_GET_EMS_CONST                                                  0x03
#define SFC_GET_BAT_PARM                                                   0x04
#define SFC_GET_UART_PARM                                                  0x05
#define SFC_GET_METERING                                                   0x06
#define SFC_GET_FACTORY_PARM                                               0x07
#define SFC_GET_MCU2_NOTE                                                  0x08
#define SFC_GET_SYS_SN                                                     0x09
#define SFC_GET_HOLIDAY_DATA                                               0x0A
#define SFC_GET_DRMN                                                       0x0B
#define SFC_GET_PCSM_DATA                                                  0x10
#define SFC_GET_M_S_DATA                                                   0x11
#define SFC_GET_PV_METER                                                   0x12
#define SFC_GET_PV_PARM                                                    0x13
#define SFC_GET_EMS_VAR                                                    0x14
#define SFC_GET_REMOTE_CONTROL                                             0x15
#define SFC_GET_REMOTE_MEASURE                                             0x16
#define SFC_GET_REMOTE_SIGNAL                                              0x17
#define SFC_GET_INTER_DATA                                                 0x18
#define SFC_GET_SAFE_BASIC                                                 0x20
#define SFC_GET_SAFE_GRP1                                                  0x21
#define SFC_GET_SAFE_GRP2                                                  0x22
#define SFC_GET_SAFE_GRP3                                                  0x23
#define SFC_GET_SAFE_GRP4                                                  0x24
#define SFC_GET_SAFE_GRP5                                                  0x25
#define SFC_GET_SAFE_GRP6                                                  0x26
#define SFC_GET_SAFE_GRP7                                                  0x27
#define SFC_GET_SAFE_GRP8                                                  0x28
#define SFC_GET_SAFE_GRP9                                                  0x29
#define SFC_GET_XIAO_JU_CONST                                              0x30
#define SFC_GET_XIAO_JU_VAR                                                0x31

#define SFC_UPGRADE_H                                                      0x90
#define SFC_UPGRADE_QUERY                                                  0x10
#define SFC_UPGRADE_DATA                                                   0x20
#define SFC_UPGRADE_END                                                    0x21
#define SFC_UPGRADE_START                                                  0x22
#define SFC_PAUSE_MCU2_PCS_REQ                                             0x30
#define SFC_UPGRADE_FILE_SIZE                                             0x400

#define SFC_FILE_TRANSFER_H                                                0xA0
#define SFC_FILE_WRITE_START                                               0x00
#define SFC_FILE_WRITE_DATA                                                0x01
#define SFC_FILE_WRITE_END                                                 0x02
#define SFC_FILE_READ_START                                                0x10
#define SFC_FILE_READ_DATA                                                 0x11

#define INDEX_SCI_DATA_BUFF                                                  (4)
#define INDEX_SCI_DATA_LEN                                                   (3)

#define FAULT_LOG_FILE_NAME                                         "fault_log"
#define OPT_LOG_FILE_NAME                                             "opt_log"
#define DEBUG_LOG_FILE_NAME                                         "debug_log"

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
uint8_t g_sci_send_buf[SCI_BUF_SIZE];
uint8_t sci_read_buf[SCI_BUF_SIZE];
sci_slave_t *sci_slave = NULL;
half_word_t last_package_num;
fs_t *file = NULL;
bool_t fault_reset_flag = FALSE;
uint8_t log_type;
uint8_t file_succ_flag[2] = {0};
bool_t sci_printf_flag;

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/******************************************************************************
 * sci_mcu1_init().
 * sci init. [Called by app.]
 *
 * @param  none
 * @return none
 *****************************************************************************/
void sci_mcu1_init(void)
{
	int32_t ret;
	sdk_uart_conf_t p_uart_conf;

	clear_struct_data(&g_sci_send_buf[0], sizeof(g_sci_send_buf));
	clear_struct_data(&sci_read_buf[0], sizeof(sci_read_buf));
	sci_slave = (sci_slave_t *)g_sci_send_buf;

	last_package_num.all = 0;
	file = NULL;
	fault_reset_flag = FALSE;
	log_type = 0;

	p_uart_conf.baud_rate = SDK_UART_BAUD_RATE_115200;
	p_uart_conf.data_bits = SDK_UART_DATA_BITS_8;
	p_uart_conf.flow_ctrl = SDK_UART_HWFLOW_OFF;
	p_uart_conf.parity    = SDK_UART_PARITY_NONE;
	p_uart_conf.stop_bit  = SDK_UART_STOP_BITS_1;

	ret = sdk_uart_open(SCI_PORT);
	if(ret != SF_OK)
	{
		sdk_log_i("open SCI_PORT uart failure!");
	}
	else
	{
		sdk_uart_setup(SCI_PORT, &p_uart_conf);
		if(ret != SF_OK)
		{
			sdk_log_i("setup SCI_PORT uart failure!");
		}
	}
	sci_printf_flag = FALSE;
	clear_struct_data((uint8_t*)&file_succ_flag[0], sizeof(file_succ_flag));
}

/******************************************************************************
 * checksum_calc().
 * Computational checksum. [Called by app.]
 *
 * @param  in_buf    (I) data buffer
 * @param  len		 (I)
 * @param  out_buf   (O) checksum
 * @return none
 *****************************************************************************/
static void checksum_calc(uint8_t *in_buf, uint32_t len, uint8_t *out_buf)
{
	uint32_t i = 0;
	uint16_t sum = 0;

	for (i = 0; i < len; i++)
	{
		sum += *(in_buf + i);
	}

	out_buf[1] = (sum >> 8) & 0xFF;
	out_buf[0] = sum & 0xFF;
}

/******************************************************************************
 * checksum_check().
 * check checksum. [Called by app.]
 *
 * @param  buf      (I) data buffer
 * @param  len		(I)
 * @param  checksum (I) checksum
 * @return 1: consistent, 0: inconsistency
 *****************************************************************************/
static uint8_t checksum_check(uint8_t *buf, uint32_t len, uint8_t *checksum)
{
	uint32_t i = 0;
	uint16_t sum = 0;

	for (i = 0; i < len; i++)
	{
		sum += *(buf + i);
	}

	if((sum & 0xFF) == checksum[0] && ((sum >> 8) & 0xff) == checksum[1])
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

/******************************************************************************
 * sci_send().
 * send sci data. [Called by app.]
 *
 * @param  buf	(I)
 * @param  len  (I)
 * @return none
 *****************************************************************************/
static void sci_send(uint8_t *buf, uint32_t len)
{
	int32_t ret;

	ret = sdk_uart_write(SCI_PORT, buf, len);
	if(ret < 0)
	{
		sdk_log_i("send SCI_PORT's data failure!");
	}
}

/******************************************************************************
 * sci_printf().
 * send sci data. [Called by app.]
 *
 * @param  buf	(I)
 * @param  len  (I)
 * @return none
 *****************************************************************************/
static void sci_printf(sci_master_t *sci_master, uint8_t *buf, uint32_t len)
{
	uint32_t i;

	if((sci_printf_flag) && (buf != NULL) && (len != 0))
	{
		sdk_log_printf("func_code %2X%2X", sci_master->main_command, sci_master->sub_command);
		for(i = 0;i< len; i++)
		{
			if((i % 10) == 0)
			{
				sdk_log_printf("\r\nindex :%d value : ",i);
			}
			sdk_log_printf("%x  ", buf[i]);
		}
		sdk_log_printf("\r\n");
	}
}
/******************************************************************************
 * sci_ack().
 * send sci ack data. [Called by app.]
 *
 * @param  sci_master	(I) master_sci_struct
 * @param  ptr	(I) data pointer to be sent
 * @param  len  (I) data bytes to be sent
 * @return none
 *****************************************************************************/
static void sci_ack(sci_master_t *sci_master, uint8_t *ptr, uint32_t len)
{
	uint32_t i = 0;
	// start mark
	sci_slave->start_word_h = sci_master->start_word_h;
	sci_slave->start_word_l = sci_master->start_word_l;
	// slave addr
	sci_slave->slave_addr = sci_master->slave_addr;
	sci_slave->len = 0;
	// function code
	sci_slave->main_command = sci_master->main_command;
	sci_slave->len++;
	sci_slave->sub_command = sci_master->sub_command;
	sci_slave->len++;

	for(i = 0; i < len; i++)
	{
		sci_slave->data[i] = ptr[i];
	}

	sci_slave->len += len;
	checksum_calc(&sci_slave->slave_addr, sci_slave->len + 2, \
										&sci_slave->data[sci_slave->len - 2]);

	sci_send(g_sci_send_buf, sci_slave->len + 6);
}

/******************************************************************************
 * sci_handshaked().
 * handshaked. [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return  none
 *****************************************************************************/
static void sci_handshaked(sci_master_t *sci_master)
{
	uint8_t i = 0;
	uint8_t s_data_len = 0;
	half_word_t tmp;
	uint8_t *data = sci_master->data;

	// check master message
	if((data[0] == 0x00) && (data[1] == 0x11) && (data[2] == 0x22) \
						&& (data[3] == 0x33) && (data[4] == 0x44))
	{
		sci_slave->data[s_data_len++] = 0x00;
		sci_slave->data[s_data_len++] = csu_mcu2_hw_v;

		sci_slave->data[s_data_len++] = csu_mcu2_app_v.bytes.low;
		sci_slave->data[s_data_len++] = csu_mcu2_app_v.bytes.middle;
		sci_slave->data[s_data_len++] = csu_mcu2_app_v.bytes.high;
		sci_slave->data[s_data_len++] = csu_mcu2_app_v.bytes.rvd;

		// protocol version
		sci_slave->data[s_data_len++] = csu_mcu2_can1_v.bytes.high;
		sci_slave->data[s_data_len++] = csu_mcu2_can1_v.bytes.low;

		sci_slave->data[s_data_len++] = csu_mcu2_boot_v.bytes.low;
		sci_slave->data[s_data_len++] = csu_mcu2_boot_v.bytes.middle;
		sci_slave->data[s_data_len++] = csu_mcu2_boot_v.bytes.high;
		sci_slave->data[s_data_len++] = csu_mcu2_boot_v.bytes.rvd;

		sci_slave->data[s_data_len++] = csu_mcu2_core_v.bytes.low;
		sci_slave->data[s_data_len++] = csu_mcu2_core_v.bytes.middle;
		sci_slave->data[s_data_len++] = csu_mcu2_core_v.bytes.high;
		sci_slave->data[s_data_len++] = csu_mcu2_core_v.bytes.rvd;

		for(i = 0; i < 21; i++)
		{
			sci_slave->data[s_data_len++] = sz_csu_sn[i];
		}
		sci_slave->data[s_data_len++] = 0x00;

		// PCS system rating power
		tmp.all = array.csu.csu_data.csu_const.system_rated_power;
		sci_slave->data[s_data_len++] = tmp.bytes.high;
		sci_slave->data[s_data_len++] = tmp.bytes.low;

		tmp.all = array.csu.csu_data.csu_const.max_power_s_total;
		sci_slave->data[s_data_len++] = tmp.bytes.high;
		sci_slave->data[s_data_len++] = tmp.bytes.low;

		tmp.all = array.csu.csu_data.csu_const.max_power_p_total;
		sci_slave->data[s_data_len++] = tmp.bytes.high;
		sci_slave->data[s_data_len++] = tmp.bytes.low;

		tmp.all = array.csu.csu_data.csu_const.max_power_q_total;
		sci_slave->data[s_data_len++] = tmp.bytes.high;
		sci_slave->data[s_data_len++] = tmp.bytes.low;

		for(i = 0; i < 21; i++)
		{
			sci_slave->data[s_data_len++] = system_sn[i];
		}
		sci_slave->data[s_data_len++] = 0x00;

		sci_ack(sci_master, &sci_slave->data[0], s_data_len);
		sci_printf(sci_master, &sci_slave->data[0], s_data_len);
		trigger_planning_scheduling_start = TRUE;
	}
}

/******************************************************************************
 * sci_set_sys_time().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return  none
 *****************************************************************************/
static void sci_set_sys_time(sci_master_t *sci_master)
{
	int32_t ret;
	uint8_t *data;
	sdk_rtc_t rtc_w;
	uint16_t tmp;
	uint8_t s_data_len = 0;

	data = sci_master->data;
	tmp  = BIG_2_SMALL(data[0], data[1]);
	if(tmp < 60)
	{
		rtc_w.tm_sec = tmp;
	}
	else
	{
		rtc_w.tm_sec = 0;
	}
	tmp  = BIG_2_SMALL(data[2], data[3]);
	if(tmp < 60)
	{
		rtc_w.tm_min = tmp;
	}
	else
	{
		rtc_w.tm_min = 0;
	}
	tmp  = BIG_2_SMALL(data[4], data[5]);
	if(tmp < 24)
	{
		rtc_w.tm_hour = tmp;
	}
	else
	{
		rtc_w.tm_hour = 0;
	}
	tmp  = BIG_2_SMALL(data[6], data[7]);
	if(tmp <= 7)
	{
		rtc_w.tm_weekday = tmp;
	}
	else
	{
		rtc_w.tm_weekday = 1;
	}
	tmp  = BIG_2_SMALL(data[8], data[9]);
	if((tmp >= 1) && (tmp <= 31))
	{
		rtc_w.tm_day = tmp;
	}
	else
	{
		rtc_w.tm_day = 1;
	}
	tmp  = BIG_2_SMALL(data[10], data[11]);
	if((tmp >= 1) && (tmp <= 12))
	{
		rtc_w.tm_mon = tmp;
	}
	else
	{
		rtc_w.tm_mon = 1;
	}
	tmp  = BIG_2_SMALL(data[12], data[13]);
	if(tmp <= 99)
	{
		rtc_w.tm_year = tmp;
	}
	else
	{
		rtc_w.tm_year = 0;
	}
	ret = sdk_rtc_set(RTC_BIN_FORMAT, &rtc_w);
	if(ret == SF_OK)
	{
		sci_slave->data[s_data_len++] = 0x01;
	}
	else
	{
		sci_slave->data[s_data_len++] = 0x00;
	 }

	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &data[0], 14);
}
/******************************************************************************
 * sci_set_power_ref().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return  none
 *****************************************************************************/
static void sci_set_power_ref(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	uint8_t index = 0;
	uint8_t *data;
	half_word_t tmp;

	data = sci_master->data;
	// reserved data[0] data[1]

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if((int16_t)tmp.all != array.pcsc.pcsc_ctrl.active_power_ref)
	{
		sdk_log_a("receive active power from sci, value %d -> %d\r\n", \
								array.pcsc.pcsc_ctrl.active_power_ref, \
													(int16_t)tmp.all);
		if(0 == tmp.all)
		{
			opt_log_record("receive active power from sci, value %d -> %d", \
									array.pcsc.pcsc_ctrl.active_power_ref,  \
														(int16_t)tmp.all);
			sdk_log_a("receive active power from sci, value %d -> %d\r\n", \
									array.pcsc.pcsc_ctrl.active_power_ref, \
														(int16_t)tmp.all);
		}
		array.pcsc.pcsc_ctrl.active_power_ref = tmp.all;
		g_active_power_send = TRUE;
		// if power reference change, means that manual control, need to disable local ems
		g_trigger_close_ems = TRUE;
		constrain_int16_t_data(&array.pcsc.pcsc_ctrl.active_power_ref,\
								-(int16_t)array.csu.csu_data.csu_const.rat_power_p_total * ACTIVE_POWER_OVERLOAD_MULTIPLE, \
								(int16_t)array.csu.csu_data.csu_const.rat_power_p_total * ACTIVE_POWER_OVERLOAD_MULTIPLE);
		//fifo_can_push(&fifo_can1_cmd, &can_cmd_temp);
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if((int16_t)tmp.all != array.pcsc.pcsc_ctrl.reactive_power_ref)
	{
		opt_log_record("receive reactive power from sci, value %d -> %d\r\n", \
								array.pcsc.pcsc_ctrl.reactive_power_ref, \
													(int16_t)tmp.all);
		// TODO 直接下发CAN
		//can_cmd_temp.offset.all = REACTIVE_POWER_REF;
		array.pcsc.pcsc_ctrl.reactive_power_ref = (int16_t)tmp.all;
		g_reactive_power_send = TRUE;
	}

	sci_slave->data[s_data_len++] = 0x01;
	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &data[0], index);
}

/******************************************************************************
 * sci_set_pcsc_parm().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return  none
 *****************************************************************************/
static void sci_set_enet_parm(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	uint8_t *data;
	uint8_t i;
	uint8_t tmp = 0x01;
	uint8_t set_n[16] = {0};
	int32_t ret;
	bool_t cross_broader_flag = FALSE;

	data = sci_master->data;

	for(i = 0; i < ENET_PARM_MAX_NUM; i++)
	{
		data[i] = setting_data_constrain_uint8(&data[i], &enet_set_table[0], i,\
															&cross_broader_flag);
	}
	clear_struct_data(&set_n[0], 16);
	sprintf((char *)&set_n[0], "%d.%d.%d.%d", data[0], data[1], data[2], data[3]);
	ret = sdk_net_ip_set(ETH0, &set_n[0]);
	if(ret != SF_OK)
	{
		tmp = 0x00;
		sdk_log_i("sci set ip fail!");
	}

	clear_struct_data(&set_n[0], 16);
	sprintf((char *)&set_n[0], "%d.%d.%d.%d", data[4], data[5], data[6], data[7]);
	sdk_net_subnetmask_set(ETH0, &set_n[0]);
	if(ret != SF_OK)
	{
		tmp = 0x00;
		sdk_log_i("sci set subnetmask fail!");
	}

	clear_struct_data(&set_n[0], 16);
	sprintf((char *)&set_n[0], "%d.%d.%d.%d", \
											data[8], data[9], data[10], data[11]);
	sdk_net_gateway_set(ETH0, &set_n[0]);
	if(ret != SF_OK)
	{
		tmp = 0x00;
		sdk_log_i("sci set gateway fail!");
	}

	clear_struct_data(&set_n[0], 16);
	sprintf((char *)&set_n[0], "%d.%d.%d.%d", \
											data[12], data[13], data[14], data[15]);
	sdk_net_dns_set(ETH0, &set_n[0]);
	if(ret != SF_OK)
	{
		tmp = 0x00;
		sdk_log_i("sci set dns fail!");
	}

	ret = setting_set(SYS_PARM, EE_SYS_PARM_ENET_PARM, sci_master->data, \
															sci_master->len);
	if(ret != SF_OK)
	{
		tmp = 0x00;
		sdk_log_i("sci save enet parm fail!");
	}

	memory_copy((uint8_t *)&array.csu.csu_data.set.enet_set, data, \
															sci_master->len);

	sci_slave->data[s_data_len++] = tmp;
	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &data[0], 16);
}

/******************************************************************************
 * sci_set_ems_parm().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return  none
 *****************************************************************************/
static void sci_set_ems_parm(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	uint8_t index = 0;
	uint8_t *data;
	uint8_t i;
	uint16_t offset;
	bool_t check;
	half_word_t tmp;
	word_t tmp32;
	bool_t cross_broader_flag = FALSE;
	int8_t symbol;

	data = sci_master->data;

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.demand_side.enable != tmp.all)
	{
		ems.demand_side.enable = \
				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
								EE_EMS_DEMAND_ENABLE, &cross_broader_flag);
		setting_set(LOCAL_EMS, EE_EMS_DEMAND_ENABLE, &tmp, 2);
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.demand_side.dead_band != tmp.all)
	{
		ems.demand_side.dead_band = \
				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
								EE_EMS_DEMAND_DEADBAND, &cross_broader_flag);
		setting_set(LOCAL_EMS, EE_EMS_DEMAND_DEADBAND, &tmp, 2);
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.demand_side.demand_quantity != tmp.all)
	{
		ems.demand_side.demand_quantity = \
				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
								EE_EMS_DEMAND_QUANTITY, &cross_broader_flag);
		setting_set(LOCAL_EMS, EE_EMS_DEMAND_QUANTITY, &tmp, 2);
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.anti_backflow.enable != tmp.all)
	{
		ems.anti_backflow.enable = \
				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
									EE_EMS_ANTI_ENABLE, &cross_broader_flag);
		setting_set(LOCAL_EMS, EE_EMS_ANTI_ENABLE, &tmp, 2);
		if(TRUE == ems.anti_backflow.enable)
		{
			array.pcsc.pcsc_ctrl.rs485_enable.bit.backflow_meter = TRUE;
		}
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.allow_sale_power != tmp.all)
	{
		ems.allow_sale_power = \
				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
								EE_EMS_ALLOW_SALE_POWER, &cross_broader_flag);
		setting_set(LOCAL_EMS, EE_EMS_ALLOW_SALE_POWER, &tmp, 2);
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.c2d.enable != tmp.all)
	{
		ems.c2d.enable = \
				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
								EE_EMS_C2D_ENABLE, &cross_broader_flag);
		setting_set(LOCAL_EMS, EE_EMS_C2D_ENABLE, &tmp, 2);
		if(TRUE == ems.c2d.enable)
		{
			array.pcsc.pcsc_ctrl.rs485_enable.bit.backflow_meter = TRUE;
		}
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.allow_purchase_power != tmp.all)
	{
		ems.allow_purchase_power = \
				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
								EE_EMS_ALLOW_PURCHASE_POWER, &cross_broader_flag);
		setting_set(LOCAL_EMS, EE_EMS_ALLOW_PURCHASE_POWER, &tmp, 2);
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.cpfv.enable != tmp.all)
	{
		clear_struct_data((uint8_t*)planning_scheduling_delay_on_cnt, sizeof(planning_scheduling_delay_on_cnt));
		ems.cpfv.enable = \
				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
								EE_EMS_CPFV_ENABLE, &cross_broader_flag);
		setting_set(LOCAL_EMS, EE_EMS_CPFV_ENABLE, &tmp, 2);
		if(0 == ems.cpfv.enable)
		{
			clear_struct_data((uint8_t*)planning_scheduling_delay_on_cnt, sizeof(planning_scheduling_delay_on_cnt));
			array.pcsc.pcsc_ctrl.active_power_ref = 0;
			ems.cpfv.last_status = INVALID;
		}
	}
	for (i = 0; i < TIME_PERIOD_NUM_MAX; i++)
	{
		offset = EE_EMS_TIME_PERIOD + i * EMS_TIME_PERIOD_LEN;
		tmp.bytes.high = data[index++];
		tmp.bytes.low  = data[index++];
		if(ems.tm_period[i].attribute != tmp.all)
		{
			clear_struct_data((uint8_t*)planning_scheduling_delay_on_cnt, sizeof(planning_scheduling_delay_on_cnt));
			ems.cpfv.last_status = INVALID;
			ems.tm_period[i].attribute = \
					setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
									EE_EMS_TIME_PERIOD, &cross_broader_flag);
			setting_set(LOCAL_EMS, offset, &tmp, 2);
		}
		offset += 2;
		memory_copy((uint8_t *)&tmp32.all, &data[index], 4);
		index += 4;
		check = FALSE;
		check |= memcmp(&ems.tm_period[i].start_hour, (uint8_t *)&tmp32.byte[0], 1);
		check |= memcmp(&ems.tm_period[i].start_min, (uint8_t *)&tmp32.byte[1], 1);
		check |= memcmp(&ems.tm_period[i].end_hour, (uint8_t *)&tmp32.byte[2], 1);
		check |= memcmp(&ems.tm_period[i].end_min, (uint8_t *)&tmp32.byte[3], 1);
		if(check != FALSE)
		{
			clear_struct_data((uint8_t*)planning_scheduling_delay_on_cnt, sizeof(planning_scheduling_delay_on_cnt));
			ems.cpfv.last_status = INVALID;

			tmp.all = tmp32.byte[0];
			ems.tm_period[i].start_hour = \
					setting_data_constrain_uint16(&tmp.all, &g_ems_set_table[0], \
									EE_EMS_TIME_PERIOD_HOUR, &cross_broader_flag);

			tmp.all = tmp32.byte[1];
			ems.tm_period[i].start_min = \
					setting_data_constrain_uint16(&tmp.all, &g_ems_set_table[0], \
									EE_EMS_TIME_PERIOD_MIN, &cross_broader_flag);

			tmp.all = tmp32.byte[2];
			ems.tm_period[i].end_hour = \
					setting_data_constrain_uint16(&tmp.all, &g_ems_set_table[0], \
									EE_EMS_TIME_PERIOD_HOUR, &cross_broader_flag);

			tmp.all = tmp32.byte[3];
			ems.tm_period[i].end_min = \
					setting_data_constrain_uint16(&tmp.all, &g_ems_set_table[0], \
									EE_EMS_TIME_PERIOD_MIN, &cross_broader_flag);

			setting_set(LOCAL_EMS, offset, &tmp32, 4);
		}
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	// if (ems.soc_max != tmp.all)
	// {
	// 	ems.soc_max = \
	// 			setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
	// 							EE_EMS_CHG_SOC_MAX, &cross_broader_flag);
	// 	ems.soc_maint.upper_limit = ems.soc_max;
	// 	setting_set(LOCAL_EMS, EE_EMS_CHG_SOC_MAX, &tmp, 2);
	// }

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if(ems.pcc_power_set != (int16_t)tmp.all)
	{
		symbol = symbol_judgment_int16((int16_t)tmp.all);
		tmp.all = abs_int2uint((int16_t)tmp.all);
		ems.pcc_power_set = \
				symbol * setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
								EE_EMS_PCC_POWER_SET, &cross_broader_flag);
		setting_set(LOCAL_EMS, EE_EMS_PCC_POWER_SET, &ems.pcc_power_set, HALF_WORD_LEN);
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
//	if (ems.cpfv.k1 != tmp.all)
//	{
//		ems.cpfv.k1 = \
//				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
//										EE_EMS_K1, &cross_broader_flag);
//		ems.cpfv.k1 = tmp.all;
//		setting_set(LOCAL_EMS, EE_EMS_K1, &tmp, 2);
//	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.p_chgmax_theory != tmp.all)
	{
		ems.cpfv.last_status = INVALID;
		constrain_uint16_t_data(&tmp.all, 0, array.csu.csu_data.csu_const.rat_power_p_total * ACTIVE_POWER_OVERLOAD_MULTIPLE);
		ems.p_chgmax_theory = tmp.all;
		ems.inter_max_chg_power = ems.p_chgmax_theory;
		setting_set(LOCAL_EMS, EE_EMS_THEORY_MAX_CHG_POWER, &tmp, 2);
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	// if (ems.soc_min != tmp.all)
	// {
	// 	ems.soc_min = \
	// 			setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
	// 							EE_EMS_DISCHG_SOC_MIN, &cross_broader_flag);
	// 	ems.soc_maint.lower_limit = ems.soc_min;
	// 	setting_set(LOCAL_EMS, EE_EMS_DISCHG_SOC_MIN, &tmp, 2);
	// }

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
//	if (ems.p_dischg_step != tmp.all)
//	{
//		ems.p_dischg_step = \
//				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
//							EE_EMS_DISCHG_POWER_STEP, &cross_broader_flag);
//		setting_set(LOCAL_EMS, EE_EMS_DISCHG_POWER_STEP, &tmp, 2);
//	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
//	if (ems.cpfv.k2 != tmp.all)
//	{
//		ems.cpfv.k2 = \
//				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
//											EE_EMS_K2, &cross_broader_flag);
//		setting_set(LOCAL_EMS, EE_EMS_K2, &tmp, 2);
//	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.p_dischgmax_theory != tmp.all)
	{
		ems.cpfv.last_status = INVALID;
		constrain_uint16_t_data(&tmp.all, 0, array.csu.csu_data.csu_const.rat_power_p_total * ACTIVE_POWER_OVERLOAD_MULTIPLE);
		ems.p_dischgmax_theory = tmp.all;
		ems.inter_max_dch_power = ems.p_dischgmax_theory;
		setting_set(LOCAL_EMS, EE_EMS_THEORY_MAX_DISCHG_POWER, &tmp, 2);
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.soc_maint.enable != tmp.all)
	{
		ems.soc_maint.enable = \
				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
							EE_EMS_SOC_MAINT_ENABLE, &cross_broader_flag);
		setting_set(LOCAL_EMS, EE_EMS_SOC_MAINT_ENABLE, &tmp, 2);
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.soc_maint.power_maint != tmp.all)
	{
		constrain_uint16_t_data(&tmp.all, 0, array.csu.csu_data.csu_const.rat_power_p_total * ACTIVE_POWER_OVERLOAD_MULTIPLE);
		ems.soc_maint.power_maint = \
				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
							EE_EMS_SOC_MAINT_POWER, &cross_broader_flag);
		setting_set(LOCAL_EMS, EE_EMS_SOC_MAINT_POWER, &tmp, 2);
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.force_control.enable != tmp.all)
	{
		ems.force_control.enable = \
				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
						EE_EMS_FORCE_CONTROL_ENABLE, &cross_broader_flag);
		setting_set(LOCAL_EMS, EE_EMS_FORCE_CONTROL_ENABLE, &tmp, 2);
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.q_power_step != tmp.all)
	{
		ems.q_power_step = \
				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
								EE_EMS_POWER_Q_STEP, &cross_broader_flag);
		setting_set(LOCAL_EMS, EE_EMS_POWER_Q_STEP, &tmp, 2);
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.power_factor != tmp.all)
	{
		ems.power_factor = \
				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
								EE_EMS_POWER_FACTOR, &cross_broader_flag);
		setting_set(LOCAL_EMS, EE_EMS_POWER_FACTOR, &tmp, 2);
	}


	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.rated_capacity != tmp.all)
	{
		ems.cpfv.last_status = INVALID;
		ems.rated_capacity = \
				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
								EE_EMS_RATED_CAPACITY, &cross_broader_flag);
		setting_set(LOCAL_EMS, EE_EMS_RATED_CAPACITY, &tmp, 2);
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.cpfv.early_closure_peak != tmp.all)
	{
		// ems.cpfv.early_closure_peak = \
		// 		setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
		// 					EE_EMS_EARLY_CLOSURE_PEAK, &cross_broader_flag);
		// setting_set(LOCAL_EMS, EE_EMS_EARLY_CLOSURE_PEAK, &tmp, 2);
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.cpfv.early_closure_top != tmp.all)
	{
		// ems.cpfv.early_closure_top = \
		// 		setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
		// 					EE_EMS_EARLY_CLOSURE_TOP, &cross_broader_flag);
		// setting_set(LOCAL_EMS, EE_EMS_EARLY_CLOSURE_TOP, &tmp, 2);
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.cpfv.early_closure_valley != tmp.all)
	{
		// ems.cpfv.early_closure_valley = \
		// 		setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
		// 				EE_EMS_EARLY_CLOSURE_VALLEY, &cross_broader_flag);
		// setting_set(LOCAL_EMS, EE_EMS_EARLY_CLOSURE_VALLEY, &tmp, 2);
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.pcs_standby_wait_time != tmp.all)
	{
		ems.pcs_standby_wait_time = \
				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
							EE_EMS_STANDBY_WAIT_TIME, &cross_broader_flag);
		setting_set(LOCAL_EMS, EE_EMS_STANDBY_WAIT_TIME, &tmp, 2);
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.pcs_stop_wait_time != tmp.all)
	{
		ems.pcs_stop_wait_time = \
				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
								EE_EMS_STOP_WAIT_TIME, &cross_broader_flag);
		setting_set(LOCAL_EMS, EE_EMS_STOP_WAIT_TIME, &tmp, 2);
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.pcs_advance_startup_time != tmp.all)
	{
		ems.pcs_advance_startup_time = \
				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
						EE_EMS_ADVANCE_STARTUP_TIME, &cross_broader_flag);
		setting_set(LOCAL_EMS, EE_EMS_ADVANCE_STARTUP_TIME, &tmp, 2);
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.automatic.enable != tmp.all)
	{
		clear_struct_data((uint8_t*)planning_scheduling_delay_on_cnt, sizeof(planning_scheduling_delay_on_cnt));
		ems.automatic.enable = \
				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
						EE_EMS_AUTOMATIC_ENABLE, &cross_broader_flag);
		setting_set(LOCAL_EMS, EE_EMS_AUTOMATIC_ENABLE, &tmp, 2);
		if(FALSE == ems.automatic.enable)
		{
			array.pcsc.pcsc_ctrl.active_power_ref = 0;
		}
		else
		{
			array.pcsc.pcsc_ctrl.rs485_enable.bit.backflow_meter = TRUE;
		}
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.meter_current_direction.all != tmp.all)
	{
		symbol = ems.meter_current_direction.bits.meter2_cur_dir;
		ems.meter_current_direction.all = \
				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
						EE_EMS_METER_CUR_DIR, &cross_broader_flag);
		setting_set(LOCAL_EMS, EE_EMS_METER_CUR_DIR, &tmp, 2);
		if(ONE_STORAGE_TANK_XIAOJU_1_2 != array.pcsc.pcsc_ctrl.scenario_setting)
		{
			ems.meter_current_direction.bits.meter2_cur_dir = symbol;
		}
	}
	for (i = 0; i < TIME_PERIOD_NUM_MAX; i++)
	{
		offset = EE_EMS_TIME_PERIOD_POWER + i * HALF_WORD_LEN;
		tmp.bytes.high = data[index++];
		tmp.bytes.low  = data[index++];
//		if(AUTOMATIC_TM == ems.tm_period[i].attribute)
//		{
//			tmp.all = INT16_MAX;
//		}
		if(ems.tm_period[i].power_ref != (int16_t)tmp.all)
		{
			clear_struct_data((uint8_t*)planning_scheduling_delay_on_cnt, sizeof(planning_scheduling_delay_on_cnt));
			ems.cpfv.last_status = INVALID;
			if((INT16_MAX == tmp.all) || (UINT16_MAX == tmp.all))
			{
				ems.tm_period[i].enable_power_set = FALSE;
				ems.tm_period[i].power_ref = INT16_MAX;
			}
			else
			{
				ems.tm_period[i].enable_power_set = TRUE;
				symbol = symbol_judgment_int16((int16_t)tmp.all);
				tmp.all = abs_int2uint((int16_t)tmp.all);
				ems.tm_period[i].power_ref = \
						symbol * setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
										EE_EMS_TIME_PERIOD_POWER, &cross_broader_flag);
				ems.tm_period[i].attribute = get_attr_from_power(ems.tm_period[i].power_ref);
			}
			setting_set(LOCAL_EMS, offset, &ems.tm_period[i].power_ref, HALF_WORD_LEN);
		}
	}
	sci_slave->data[s_data_len++] = 0x01;
	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &data[0], index);
}

/******************************************************************************
 * sci_set_factory_parm().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return  none
 *****************************************************************************/
static void sci_set_factory_parm(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	uint8_t index = 0;
	uint8_t *data;
	half_word_t tmp;

	data = sci_master->data;

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if(tmp.all != factory_parm.all)
	{
		factory_parm.all = tmp.all;
		if(factory_parm.bits.capacity_test)
		{
			trigger_rack_manage = FALSE;
			trigger_bat_capacity_test = TRUE;
		}
		else
		{
			if(power_magic_init_ok)
			{
				trigger_rack_manage = TRUE;
			}
			trigger_bat_capacity_test = FALSE;
		}
		if(factory_parm.bits.restore_data)
		{
			trigger_restore_factory = TRUE;
		}
	}

	sci_slave->data[s_data_len++] = 0x01;
	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &data[0], index);
}

/******************************************************************************
 * sci_set_mcu2_note().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return  none
 *****************************************************************************/
static void sci_set_mcu2_note(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	uint8_t index = 0;
	uint8_t *data;
	uint8_t i;

	data = sci_master->data;

	for(i = 0; i < CMU_NUMS; i++)
	{
		array.cmu[i].action = data[index++];
	}

	sci_slave->data[s_data_len++] = 0x01;
	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &data[0], index);
}

/******************************************************************************
 * sci_set_xiao_ju_const().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return  none
 *****************************************************************************/
static void sci_set_xiao_ju_const(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	uint8_t index = 0;
	uint8_t *data;
	word_t tmp32;
	bool_t cross_broader_flag = FALSE;
	data = sci_master->data;

	tmp32.byte[3]  = data[index++];
	tmp32.byte[2]  = data[index++];
	tmp32.byte[1]  = data[index++];
	tmp32.byte[0]  = data[index++];
	if(tmp32.all != xiao_ju.ctrl_source)
	{
		clear_struct_data((uint8_t*)planning_scheduling_delay_on_cnt, sizeof(planning_scheduling_delay_on_cnt));
		xiao_ju.ctrl_source = \
			setting_data_constrain_uint32(&tmp32.all, &xiaoju_setting_parm[0], \
										XIAOJU_CTRL_SOURCE, &cross_broader_flag);
		setting_set(XIAOJU_PARM, XIAOJU_CTRL_SOURCE, &tmp32.all, WORD_LEN);
	}

	tmp32.byte[3]  = data[index++];
	tmp32.byte[2]  = data[index++];
	tmp32.byte[1]  = data[index++];
	tmp32.byte[0]  = data[index++];
	if(tmp32.all != xiao_ju.transformer_capacity)
	{
		xiao_ju.transformer_capacity = \
			setting_data_constrain_uint32(&tmp32.all, &xiaoju_setting_parm[0], \
							XIAOJU_TRANSFORMER_CAPACITY, &cross_broader_flag);
		setting_set(XIAOJU_PARM, XIAOJU_TRANSFORMER_CAPACITY, &tmp32.all, WORD_LEN);
	}

	tmp32.byte[3]  = data[index++];
	tmp32.byte[2]  = data[index++];
	tmp32.byte[1]  = data[index++];
	tmp32.byte[0]  = data[index++];
	if(tmp32.all != xiao_ju.ammeter1_num)
	{
		xiao_ju.ammeter1_num = \
			setting_data_constrain_uint32(&tmp32.all, &xiaoju_setting_parm[0], \
										XIAOJU_METER1_NUM, &cross_broader_flag);
		setting_set(XIAOJU_PARM, XIAOJU_METER1_NUM, &tmp32.all, WORD_LEN);
	}

	tmp32.byte[3]  = data[index++];
	tmp32.byte[2]  = data[index++];
	tmp32.byte[1]  = data[index++];
	tmp32.byte[0]  = data[index++];
	if(tmp32.all != xiao_ju.ammeter3_num)
	{
		xiao_ju.ammeter3_num = \
			setting_data_constrain_uint32(&tmp32.all, &xiaoju_setting_parm[0], \
										XIAOJU_METER3_NUM, &cross_broader_flag);
		setting_set(XIAOJU_PARM, XIAOJU_METER3_NUM, &tmp32.all, WORD_LEN);
	}

	sci_slave->data[s_data_len++] = 0x01;
	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &data[0], index);
}

/******************************************************************************
 * sci_set_xiao_ju().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return  none
 *****************************************************************************/
static void sci_set_xiao_ju_var(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	uint8_t index = 0;
	uint8_t *data;
	word_t tmp32;

	data = sci_master->data;

	tmp32.byte[3]  = data[index++];
	tmp32.byte[2]  = data[index++];
	tmp32.byte[1]  = data[index++];
	tmp32.byte[0]  = data[index++];
	if(tmp32.all != xiao_ju.system_ctrl)
	{
		xiao_ju.system_ctrl = tmp32.all;
	}

	tmp32.byte[3]  = data[index++];
	tmp32.byte[2]  = data[index++];
	tmp32.byte[1]  = data[index++];
	tmp32.byte[0]  = data[index++];
	if(tmp32.all != xiao_ju.max_allow_chg_power)
	{
		xiao_ju.max_allow_chg_power = tmp32.all;
	}

	tmp32.byte[3]  = data[index++];
	tmp32.byte[2]  = data[index++];
	tmp32.byte[1]  = data[index++];
	tmp32.byte[0]  = data[index++];
	if(tmp32.all != xiao_ju.max_allow_dch_power)
	{
		xiao_ju.max_allow_dch_power = tmp32.all;
	}

	sci_slave->data[s_data_len++] = 0x01;
	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &data[0], index);
}

/******************************************************************************
 * sci_set_sys_sn().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return  none
 *****************************************************************************/
static void sci_set_sys_sn(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	uint8_t index = 0;
	uint8_t *data;
	uint8_t i;

	data = sci_master->data;

	if(factory_parm.bits.system_test)
	{
		for(i = 0; i < 21; i++)
		{
			system_sn[i] = data[index++];
		}
		index++;
		setting_set(FUT_SET, EE_SYSTEM_SN, &system_sn[0], 20);
	}
	else
	{
		index += 22;
	}

	if(factory_parm.bits.csu_sn_enable)
	{
		factory_parm.bits.csu_sn_enable = FALSE;
		for(i = 0; i < 21; i++)
		{
			sz_csu_sn[i] = data[index++];
		}
		index++;
		setting_set(FUT_SET, EE_CSU_SN, &sz_csu_sn[0], 20);
	}
	else
	{
		index += 22;
	}

	sci_slave->data[s_data_len++] = 0x01;
	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &data[0], index);
}

/******************************************************************************
 * sci_set_holiday_data().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return  none
 *****************************************************************************/
static void sci_set_holiday_data(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	uint8_t index = 0;
	uint8_t *data;
	uint8_t i;
	uint16_t offset;
	bool_t check;
	half_word_t tmp;
	word_t tmp32;
	bool_t cross_broader_flag = FALSE;
	int8_t symbol;

	data = sci_master->data;

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (ems.holiday_tm_enable != tmp.all)
	{
		clear_struct_data((uint8_t*)planning_scheduling_delay_on_cnt, sizeof(planning_scheduling_delay_on_cnt));
		ems.holiday_tm_enable = \
				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
						EE_EMS_HOLIDAY_ENABLE, &cross_broader_flag);
		setting_set(LOCAL_EMS, EE_EMS_HOLIDAY_ENABLE, &tmp, 2);
	}
	for (i = 0; i < TIME_PERIOD_NUM_MAX; i++)
	{
		offset = EE_EMS_HOLIDAY_TIME_PERIOD + i * EMS_HOLIDAY_TIME_PERIOD_LEN;
		tmp.bytes.high = data[index++];
		tmp.bytes.low  = data[index++];
		if(ems.holiday_tm_period[i].attribute != tmp.all)
		{
			clear_struct_data((uint8_t*)planning_scheduling_delay_on_cnt, sizeof(planning_scheduling_delay_on_cnt));
			ems.cpfv.last_status = INVALID;
			ems.holiday_tm_period[i].attribute = \
					setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
									EE_EMS_HOLIDAY_TIME_PERIOD, &cross_broader_flag);
			setting_set(LOCAL_EMS, offset, &tmp, 2);
		}
		offset += HALF_WORD_LEN;
		tmp.bytes.high = data[index++];
		tmp.bytes.low  = data[index++];
		if(ems.holiday_tm_period[i].power_ref != (int16_t)tmp.all)
		{
			clear_struct_data((uint8_t*)planning_scheduling_delay_on_cnt, sizeof(planning_scheduling_delay_on_cnt));
			ems.cpfv.last_status = INVALID;
			if((INT16_MAX == tmp.all) || (UINT16_MAX == tmp.all))
			{
				ems.holiday_tm_period[i].enable_power_set = FALSE;
				ems.holiday_tm_period[i].power_ref = INT16_MAX;
			}
			else
			{
				ems.holiday_tm_period[i].enable_power_set = TRUE;
				symbol = symbol_judgment_int16((int16_t)tmp.all);
				tmp.all = abs_int2uint((int16_t)tmp.all);
				ems.holiday_tm_period[i].power_ref = \
						symbol * setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
										EE_EMS_HOLIDAY_TIME_PERIOD_POWER, &cross_broader_flag);
				ems.holiday_tm_period[i].attribute = get_attr_from_power(ems.holiday_tm_period[i].power_ref);
			}
			setting_set(LOCAL_EMS, offset, &ems.holiday_tm_period[i].power_ref, HALF_WORD_LEN);
		}
		offset += HALF_WORD_LEN;
		memory_copy((uint8_t *)&tmp32.all, &data[index], 4);
		index += WORD_LEN;
		check = FALSE;
		check |= memcmp(&ems.holiday_tm_period[i].start_hour, (uint8_t *)&tmp32.byte[0], 1);
		check |= memcmp(&ems.holiday_tm_period[i].start_min, (uint8_t *)&tmp32.byte[1], 1);
		check |= memcmp(&ems.holiday_tm_period[i].end_hour, (uint8_t *)&tmp32.byte[2], 1);
		check |= memcmp(&ems.holiday_tm_period[i].end_min, (uint8_t *)&tmp32.byte[3], 1);
		if(check != FALSE)
		{
			clear_struct_data((uint8_t*)planning_scheduling_delay_on_cnt, sizeof(planning_scheduling_delay_on_cnt));
			ems.cpfv.last_status = INVALID;

			tmp.all = tmp32.byte[0];
			ems.holiday_tm_period[i].start_hour = \
					setting_data_constrain_uint16(&tmp.all, &g_ems_set_table[0], \
									EE_EMS_HOLIDAY_TIME_PERIOD_HOUR, &cross_broader_flag);

			tmp.all = tmp32.byte[1];
			ems.holiday_tm_period[i].start_min = \
					setting_data_constrain_uint16(&tmp.all, &g_ems_set_table[0], \
									EE_EMS_HOLIDAY_TIME_PERIOD_MIN, &cross_broader_flag);

			tmp.all = tmp32.byte[2];
			ems.holiday_tm_period[i].end_hour = \
					setting_data_constrain_uint16(&tmp.all, &g_ems_set_table[0], \
									EE_EMS_HOLIDAY_TIME_PERIOD_HOUR, &cross_broader_flag);

			tmp.all = tmp32.byte[3];
			ems.holiday_tm_period[i].end_min = \
					setting_data_constrain_uint16(&tmp.all, &g_ems_set_table[0], \
									EE_EMS_HOLIDAY_TIME_PERIOD_MIN, &cross_broader_flag);

			setting_set(LOCAL_EMS, offset, &tmp32, 4);
		}
	}
	big2small_uint16(&data[index], HALF_WORD_LEN * EMS_HOLIDAY_DATE_NUM);
	if(memcmp(&data[index], &ems.holiday_date[0], HALF_WORD_LEN * EMS_HOLIDAY_DATE_NUM) != 0)
	{
		clear_struct_data((uint8_t*)planning_scheduling_delay_on_cnt, sizeof(planning_scheduling_delay_on_cnt));
		memcpy(&ems.holiday_date[0], &data[index], HALF_WORD_LEN * EMS_HOLIDAY_DATE_NUM);
		setting_set(LOCAL_EMS, EE_EMS_HOLIDAY_DATE, &ems.holiday_date[0], HALF_WORD_LEN * EMS_HOLIDAY_DATE_NUM);
	}
	index += HALF_WORD_LEN * EMS_HOLIDAY_DATE_NUM;
	sci_slave->data[s_data_len++] = 0x01;
	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &data[0], index);
}

/******************************************************************************
 * sci_set_holiday_data().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return  none
 *****************************************************************************/
static void sci_set_drmn(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	uint8_t index = 0;
	uint8_t *data;
	half_word_t tmp;
	pcsm_cmd_t can_cmd_temp;

	can_cmd_temp.fun_code = PCS_CMD_SET_PARAMETER;
	can_cmd_temp.len = 1;
	can_cmd_temp.dst_addr = 0;
	data = sci_master->data;

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if (array.pcsc.pcsc_ctrl.drmn_status != tmp.all)
	{
		array.pcsc.pcsc_ctrl.drmn_status = tmp.all;
		can_cmd_temp.offset.all = DRMN_SET;
		fifo_can_push(&fifo_can1_cmd, &can_cmd_temp);
	}

	sci_slave->data[s_data_len++] = 0x01;
	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &data[0], index);
}
/******************************************************************************
 * sci_set_bat_parm().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return  none
 *****************************************************************************/
static void sci_set_bat_parm(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	uint8_t *data;
	uint8_t i;
	uint8_t index = 0;
	half_word_t tmp;

	data = sci_master->data;

	for(i = 0; i < BAT_RACK_MAX_NUMS_TOTAL; i++)
	{
		tmp.bytes.high = data[index++];
		tmp.bytes.low  = data[index++];
		array.pcsc.pcsc_data.var.bat_soc[i] = tmp.all;
	}

	for(i = 0; i < BAT_RACK_MAX_NUMS_TOTAL; i++)
	{
		tmp.bytes.high = data[index++];
		tmp.bytes.low  = data[index++];
		array.pcsc.pcsc_data.var.bat_soh[i] = tmp.all;
	}

	for(i = 0; i < CMU_NUMS; i++)
	{
		tmp.bytes.high = data[index++];
		tmp.bytes.low  = data[index++];
		array.pcsc.pcsc_ctrl.bat_status_info.chg_lmt_power[i] = tmp.all;

		tmp.bytes.high = data[index++];
		tmp.bytes.low  = data[index++];
		array.pcsc.pcsc_ctrl.bat_status_info.dch_lmt_power[i] = tmp.all;
	}

	for(i = 0; i < CMU_NUMS; i++)
	{
		tmp.bytes.high = data[index++];
		tmp.bytes.low  = data[index++];
		array.pcsc.pcsc_ctrl.bat_status_info.soc_max[i] = tmp.all;

		tmp.bytes.high = data[index++];
		tmp.bytes.low  = data[index++];
		array.pcsc.pcsc_ctrl.bat_status_info.soc_min[i] = tmp.all;
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	array.pcsc.pcsc_ctrl.bat_status_info.chg_ctrl.all = tmp.all;

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	array.pcsc.pcsc_ctrl.bat_status_info.dch_ctrl.all = tmp.all;

	for(i = 0; i < CMU_NUMS; i++)
	{
		array.cmu[i].sys_status = data[index++];
	}

	sci_slave->data[s_data_len++] = 0x01;
	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &data[0], index);
}

/******************************************************************************
 * sci_set_uart_parm().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return  none
 *****************************************************************************/
static void sci_set_uart_parm(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	uint8_t *data;
	int8_t i;
	uint8_t index = 0;
	word_t temp32;
	uint32_t ret = 0;
	uint32_t addr = 0;
	uint8_t uart_index;
	bool_t cross_broader_flag = FALSE;

	data = sci_master->data;

	temp32.all = 0;
	temp32.half_word[0].bytes.high = data[index++];
	temp32.half_word[0].bytes.low  = data[index++];
	if(temp32.half_word[0].all <= 7)
	{
		i = (int8_t)uart_id_to_index[temp32.half_word[0].bytes.low];
	}
	else
	{
		i = -1;
	}

	if(i != -1)
	{
		switch (i)
		{
		case 0:
			uart_index = EE_UART_INDEX_1;
			break;
		case 1:
			uart_index = EE_UART_INDEX_2;
			break;
		case 2:
			uart_index = EE_UART_INDEX_5;
			break;
		case 3:
			uart_index = EE_UART_INDEX_7;
			break;
		default:
			break;
		}
		array.pcsc.pcsc_ctrl.uart_conf[i].uart_index = \
				(uint8_t)setting_data_constrain_uint32(&temp32.all, \
				&uart_set_table[0], uart_index, &cross_broader_flag);

		temp32.half_word[0].bytes.high = data[index++];
		temp32.half_word[0].bytes.low  = data[index++];
		array.pcsc.pcsc_ctrl.uart_conf[i].slave_addr = \
				(uint8_t)setting_data_constrain_uint32(&temp32.all, \
				&uart_set_table[0], EE_UART_SLAVE_ADDR, &cross_broader_flag);

		temp32.byte[3]  = data[index++];
		temp32.byte[2]  = data[index++];
		temp32.byte[1]  = data[index++];
		temp32.byte[0]  = data[index++];
		array.pcsc.pcsc_ctrl.uart_conf[i].baud_rate = \
				setting_data_constrain_uint32(&temp32.all, \
				&uart_set_table[0], EE_UART_BAUD_RATE, &cross_broader_flag);

		temp32.half_word[0].bytes.high = data[index++];
		temp32.half_word[0].bytes.low  = data[index++];
		array.pcsc.pcsc_ctrl.uart_conf[i].data_bits = \
				(uint8_t)setting_data_constrain_uint32(&temp32.all, \
				&uart_set_table[0], EE_UART_DATA_BITS, &cross_broader_flag);

		temp32.half_word[0].bytes.high = data[index++];
		temp32.half_word[0].bytes.low  = data[index++];
		array.pcsc.pcsc_ctrl.uart_conf[i].stop_bits = \
				(uint8_t)setting_data_constrain_uint32(&temp32.all, \
				&uart_set_table[0], EE_UART_STOP_BITS, &cross_broader_flag);

		temp32.half_word[0].bytes.high = data[index++];
		temp32.half_word[0].bytes.low  = data[index++];
		array.pcsc.pcsc_ctrl.uart_conf[i].parity = \
				(uint8_t)setting_data_constrain_uint32(&temp32.all, \
				&uart_set_table[0], EE_UART_PARITY, &cross_broader_flag);

		sci_slave->data[s_data_len++] = 0x01;
		sci_ack(sci_master, &sci_slave->data[0], s_data_len);
		addr = EE_SYS_PARM_UART_PARM + i * SYS_PARM_UART_PARM_LEN;
		ret = setting_set(SYS_PARM, addr, &array.pcsc.pcsc_ctrl.uart_conf[i], SYS_PARM_UART_PARM_LEN);
		if (ret != SF_OK)
		{
			sdk_log_i("sci save uart parm fail!");
		}
	}
	else
	{
		sci_slave->data[s_data_len++] = 0x00;
		sci_ack(sci_master, &sci_slave->data[0], s_data_len);
		sdk_log_i("SCI set uart err!");
	}
	sci_printf(sci_master, &data[0], index);
}

/******************************************************************************
 * sci_set_pcsm_parm().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return  none
 *****************************************************************************/
static void sci_set_pcsm_parm(sci_master_t *sci_master)
{
	uint8_t i;
	uint8_t *data = NULL;
	uint16_t index = 0;
	pcsm_ctrl_t cmd;
	pcsm_cmd_t can_cmd_temp;

	uint8_t s_data_len = 0;

	can_cmd_temp.fun_code = PCS_CMD_SET_PARAMETER;
	can_cmd_temp.len = 1;
	data = &sci_master->data[0];
	index = BIG_2_SMALL(data[0], data[1]);

	cmd.p = BIG_2_SMALL(data[4], data[5]);
	cmd.q = BIG_2_SMALL(data[6], data[7]);

	for(i = 0; i < PCSM_NUMS; i++)
	{
		if((index >> i) & 0x01)
		{
			can_cmd_temp.dst_addr = i + 1;
			if(array.pcsc.pcsc_data.pcsm_data[i].set[WRITE_INDEX].active_power_ref != \
																		cmd.p)
			{
				if(0 == cmd.p)
				{
						opt_log_record("receive active power from sci single, value %d -> %d", \
												array.pcsc.pcsc_ctrl.active_power_ref,   \
												(int16_t)cmd.p);
						sdk_log_a("receive active power from sci single, value %d -> %d\r\n", \
												array.pcsc.pcsc_ctrl.active_power_ref,   \
												(int16_t)cmd.p);
				}
				can_cmd_temp.offset.all = ACTIVE_POWER_REF;
				array.pcsc.pcsc_data.pcsm_data[i].set[WRITE_INDEX].active_power_ref = \
																			cmd.p;
				fifo_can_push(&fifo_can1_cmd, &can_cmd_temp);
			}
			if(array.pcsc.pcsc_data.pcsm_data[i].set[WRITE_INDEX].reactive_power_ref != \
																			cmd.q)
			{
				can_cmd_temp.offset.all = REACTIVE_POWER_REF;
				array.pcsc.pcsc_data.pcsm_data[i].set[WRITE_INDEX].reactive_power_ref = \
																			cmd.q;
				fifo_can_push(&fifo_can1_cmd, &can_cmd_temp);
			}
		}
	}

	sci_slave->data[s_data_len++] = 0x01;
	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &data[0], index);
}


/******************************************************************************
 * sci_set_master_slave_const().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return  none
 *****************************************************************************/
static void sci_set_master_slave_const(sci_master_t *sci_master)
{
	uint8_t *data = NULL;
	uint16_t index = 0;
	uint8_t s_data_len = 0;
	half_word_t tmp;
	bool_t cross_broader_flag = FALSE;

	data = &sci_master->data[0];
	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];

	if(tmp.all != array.csu.csu_data.csu_heart.csu_role)
	{
		array.csu.csu_data.csu_heart.csu_role = \
				setting_data_constrain_uint16(&tmp.all, mcu2_inter_conf, \
								EE_SYS_PARM_CSU_ROLE, &cross_broader_flag);
		setting_set(SYS_PARM, EE_SYS_PARM_CSU_ROLE, &tmp, 2);
//		if(SLAVE == array.csu.csu_data.csu_heart.csu_role)
//		{
//			fill_struct_data((uint8_t*)&array.pcsc.pcsc_ctrl.cmu_forbid_action_flag.all, 0xFF, sizeof(array.pcsc.pcsc_ctrl.cmu_forbid_action_flag.all));
//		}
	}

	sci_slave->data[s_data_len++] = 0x01;
	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &data[0], index);
}
/******************************************************************************
 * sci_set_pcsm_parm().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return  none
 *****************************************************************************/
static void sci_set_master_slave_var(sci_master_t *sci_master)
{
	uint8_t i;
	uint8_t *data = NULL;
	uint16_t index = 0;
	half_word_t tmp;
	uint8_t s_data_len = 0;

	data = &sci_master->data[0];
	for (i = 0; i < PCSM_NUMS; i++)
	{
		tmp.bytes.high = data[index++];
		tmp.bytes.low  = data[index++];
		pcsm_chg_dch_limit[i].dch_limit = tmp.all;

		tmp.bytes.high = data[index++];
		tmp.bytes.low  = data[index++];
		pcsm_chg_dch_limit[i].chg_limit = tmp.all;
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if(MASTER == array.csu.csu_data.csu_heart.csu_role)
	{
		array.pcsc.pcsc_ctrl.cmu_forbid_action_flag.all = tmp.all;
	}

	sci_slave->data[s_data_len++] = 0x01;
	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &data[0], index);
}

/******************************************************************************
 * sci_set_pv_parm().
 * . [Called by app.]
 *
 * @param  sci_master (I) master_sci_struct
 * @param  offset     (I) ???
 * @return  none
 *****************************************************************************/
static void sci_set_pv_parm(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	uint8_t index = 0;
	uint8_t *data;
	half_word_t tmp;
	bool_t cross_broader_flag = FALSE;

	data = sci_master->data;

//	tmp.bytes.high = data[index++];
//	tmp.bytes.low  = data[index++];
//	if(tmp.all != pv_meter_parm.pv_meter_model)
//	{
//		pv_meter_parm.pv_meter_model = \
//		setting_data_constrain_uint16(&tmp.all, mcu2_inter_conf, \
//						EE_SYS_PARM_PV_METER_MODEL, &cross_broader_flag);
//		setting_set(SYS_PARM, EE_SYS_PARM_PV_METER_MODEL, &tmp, 2);
//	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if(tmp.all != pv_meter_parm.pv_meter_num)
	{
		pv_meter_parm.pv_meter_num = \
		setting_data_constrain_uint16(&tmp.all, mcu2_inter_conf, \
						EE_SYS_PARM_PV_METER_NUM, &cross_broader_flag);
		setting_set(SYS_PARM, EE_SYS_PARM_PV_METER_NUM, &tmp, 2);
		if(0 == pv_meter_parm.pv_meter_num)
		{
			array.pcsc.pcsc_ctrl.rs485_enable.bit.pv_meter = FALSE;
		}
		else
		{
			array.pcsc.pcsc_ctrl.rs485_enable.bit.pv_meter = TRUE;
		}
	}
	tmp.all = data[index++];
	if(tmp.all != ems.meter_current_direction.bits.meter2_cur_dir)
	{
		ems.meter_current_direction.bits.meter2_cur_dir = tmp.all;
		setting_set(LOCAL_EMS, EE_EMS_METER_CUR_DIR, &ems.meter_current_direction.all, 2);
	}


	sci_slave->data[s_data_len++] = 0x01;
	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
}

/******************************************************************************
 * sci_set_sys_var_parm().
 * . [Called by app.]
 *
 * @param  sci_master (I) master_sci_struct
 * @param  offset     (I) ???
 * @return  none
 *****************************************************************************/
static void sci_set_sys_var_parm(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	uint8_t index = 0;
	uint8_t *data;
	half_word_t tmp;
	bool_t cross_broader_flag = FALSE;

	data = sci_master->data;

	tmp.all = data[index++];
	if (((uint16_t)ems.soc_min) != tmp.all)
	{
		ems.soc_min = \
				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
								EE_EMS_DISCHG_SOC_MIN, &cross_broader_flag);
		ems.soc_maint.lower_limit = ems.soc_min;
		setting_set(LOCAL_EMS, EE_EMS_DISCHG_SOC_MIN, &tmp, 2);
	}

	tmp.all = data[index++];
	if (((uint16_t)ems.soc_max) != tmp.all)
	{
		ems.soc_max = \
				setting_data_constrain_uint16(&tmp.all, g_ems_set_table, \
								EE_EMS_CHG_SOC_MAX, &cross_broader_flag);
		ems.soc_maint.upper_limit = ems.soc_max;
		setting_set(LOCAL_EMS, EE_EMS_CHG_SOC_MAX, &tmp, 2);
	}

	sci_slave->data[s_data_len++] = 0x01;
	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
}

/******************************************************************************
 * sci_set_remote_control().
 * . [Called by app.]
 *
 * @param  sci_master (I) master_sci_struct
 * @param  offset     (I) ???
 * @return  none
 *****************************************************************************/
static void sci_set_remote_control(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	uint8_t index = 0;
	uint8_t *data;
	half_word_t tmp;

	data = sci_master->data;

	// remote command
	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];

	if(tmp.all != array.pcsc.pcsc_ctrl.cmd.all)
	{
		if(!tmp.bits.b0)
		{
			task_array[SLOW_TASK_PLANNING_SCHEDULING].phase = 0;
		}
		if(tmp.bits.b1 != array.pcsc.pcsc_ctrl.cmd.bit.fault_reset)
		{
			opt_log_record("fault reset %d->%d", array.pcsc.pcsc_ctrl.cmd.bit.fault_reset, tmp.bits.b1);
			fault_reset_flag = TRUE;
		}
		if(tmp.bits.b2 != array.pcsc.pcsc_ctrl.cmd.bit.restore_factory_default)
		{
			opt_log_record("restore factory %d->%d", array.pcsc.pcsc_ctrl.cmd.bit.restore_factory_default, tmp.bits.b2);
			trigger_restore_factory = TRUE;
		}
		if (tmp.bits.b3 != array.pcsc.pcsc_ctrl.cmd.bit.to_connect_grid)
		{
			opt_log_record("to_connect_grid %d->%d", array.pcsc.pcsc_ctrl.cmd.bit.to_connect_grid, tmp.bits.b3);
			array.pcsc.pcsc_ctrl.do_ctrl.bit.grid_tied_sw_qf1_on = tmp.bits.b3;
		}
		if (tmp.bits.b4 != array.pcsc.pcsc_ctrl.cmd.bit.to_disconnect_grid)
		{
			opt_log_record("to_disconnect_grid %d->%d", array.pcsc.pcsc_ctrl.cmd.bit.to_disconnect_grid, tmp.bits.b4);
			array.pcsc.pcsc_ctrl.do_ctrl.bit.grid_tied_sw_qf1_off = tmp.bits.b4;
		}
		if (tmp.bits.b5 != array.pcsc.pcsc_ctrl.cmd.bit.fan_ctrl)
		{
			opt_log_record("fan_ctrl %d->%d", array.pcsc.pcsc_ctrl.cmd.bit.fan_ctrl, tmp.bits.b5);
			array.pcsc.pcsc_ctrl.cmd.bit.fan_ctrl = tmp.bits.b5;
		}
		array.pcsc.pcsc_ctrl.cmd.all = tmp.all;
	}

	sci_slave->data[s_data_len++] = 0x01;
	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
}
/******************************************************************************
 * sci_set_remote_adjust().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return  none
 *****************************************************************************/
static void sci_set_remote_adjust(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	uint8_t index = 0;
	uint8_t *data;
	half_word_t tmp;
	bool_t ret = FALSE;
	bool_t cross_broader_flag = FALSE;

	data = sci_master->data;

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if(tmp.all != array.pcsc.pcsc_ctrl.pcsm_nums_set)
	{
		check_uint16_validity(tmp.all, 1, PCSM_NUMS, &ret);
		if(ret == TRUE)
		{
			opt_log_record("pcsm_nums_set %d->%d", array.pcsc.pcsc_ctrl.pcsm_nums_set, tmp.all);
			array.pcsc.pcsc_ctrl.pcsm_nums_set = tmp.all;
		}
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if(tmp.all != array.pcsc.pcsc_ctrl.rs485_enable.all)
	{
		check_uint16_validity(tmp.all, 0, RS485_ENABLE_LIM, &ret);
		if(TRUE == ret)
		{
			opt_log_record("rs485_enable %d->%d", array.pcsc.pcsc_ctrl.rs485_enable.all, tmp.all);
			array.pcsc.pcsc_ctrl.rs485_enable.all = tmp.all;
		}
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if(tmp.all != array.pcsc.pcsc_ctrl.scenario_setting)
	{
		check_uint16_validity(tmp.all, ONE_STORAGE_TANK, SCENARIO_END, &ret);
		if(ret == TRUE)
		{
			opt_log_record("scenario_setting %d->%d", array.pcsc.pcsc_ctrl.scenario_setting, tmp.all);
			array.pcsc.pcsc_ctrl.scenario_setting = tmp.all;
			trigger_rs485_manage = FALSE;
		}
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if(tmp.all != dehumidifier_set.humidity_set)
	{
		opt_log_record("humidity_set %d->%d", dehumidifier_set.humidity_set, tmp.all);
		dehunidification_set_param_flag = FALSE;
		dehumidifier_set.humidity_set = \
				setting_data_constrain_uint16(&tmp.all, \
				&mcu2_inter_conf[0], EE_SYS_PARM_DEHUMIDIFIER_SET, &cross_broader_flag);
		setting_set(SYS_PARM, EE_SYS_PARM_DEHUMIDIFIER_SET, &tmp, 2);
	}

	tmp.bytes.high = data[index++];
	tmp.bytes.low  = data[index++];
	if(tmp.all != dehumidifier_set.humidity_diff_set)
	{
		opt_log_record("humidity_diff_set %d->%d", dehumidifier_set.humidity_diff_set, tmp.all);
		dehunidification_set_param_flag = FALSE;
		dehumidifier_set.humidity_diff_set = \
				setting_data_constrain_uint16(&tmp.all, \
				&mcu2_inter_conf[0], EE_SYS_PARM_DEHUMIDIFIER_DIFF_SET, &cross_broader_flag);
		setting_set(SYS_PARM, EE_SYS_PARM_DEHUMIDIFIER_DIFF_SET, &tmp, 2);
	}

	sci_slave->data[s_data_len++] = 0x01;
	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &data[0], index);
}
/******************************************************************************
 * sci_set().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return  none
 *****************************************************************************/
static void sci_set(sci_master_t *sci_master)
{
	uint8_t index = sci_master->sub_command;

	switch(index)
	{
		case SFC_SET_SYS_TIME:
			sci_set_sys_time(sci_master);
			break;
		case SFC_SET_POWER_REF:
			sci_set_power_ref(sci_master);
			break;
		case SFC_SET_ENET_PARM:
			sci_set_enet_parm(sci_master);
			break;
		case SFC_SET_EMS_CONST:
			sci_set_ems_parm(sci_master);
			break;
		case SFC_SET_XIAO_JU_CONST:
			sci_set_xiao_ju_const(sci_master);
			break;
		case SFC_SET_XIAO_JU_VAR:
			sci_set_xiao_ju_var(sci_master);
			break;
		case SFC_SET_BAT_PARM:
			sci_set_bat_parm(sci_master);
			break;
		case SFC_SET_UART_PARM:
			sci_set_uart_parm(sci_master);
			break;
		case SFC_SET_FACTORY_PARM:
			sci_set_factory_parm(sci_master);
			break;
		case SFC_SET_MCU2_NOTE:
			sci_set_mcu2_note(sci_master);
			break;
		case SFC_SET_SYS_SN:
			sci_set_sys_sn(sci_master);
			break;
		case SFC_SET_HOLIDAY_DATA:
			sci_set_holiday_data(sci_master);
			break;
		case SFC_SET_DRMN:
			sci_set_drmn(sci_master);
			break;
		case SFC_SET_PCSM_PARM:
			sci_set_pcsm_parm(sci_master);
			break;
		case SFC_SET_M_S_CONST:
			sci_set_master_slave_const(sci_master);
			break;
		case SFC_SET_M_S_VAR:
			sci_set_master_slave_var(sci_master);
			break;
		case SFC_SET_PV_PARM:
			sci_set_pv_parm(sci_master);
			break;
		case SFC_SET_EMS_VAR:
			sci_set_sys_var_parm(sci_master);
			break;
		case SFC_SET_REMOTE_CONTROL:
			sci_set_remote_control(sci_master);
			break;
		case SFC_SET_REMOTE_ADJUST:
			sci_set_remote_adjust(sci_master);
			break;
		default:
			break;
	}

	// TDOO: when safety parameters recieve done, trigger send them to PCSM
}

/******************************************************************************
 * ().
 * hand shaked. [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_get_sys_time(sci_master_t *sci_master)
{
	int32_t ret;
	half_word_t tmp;
	sdk_rtc_t rtc_r;
	uint8_t s_data_len = 0;

	ret = sdk_rtc_get(RTC_BIN_FORMAT, &rtc_r);
	if(ret == SF_OK)
	{
		tmp.all = rtc_r.tm_sec;
		sci_slave->data[s_data_len++] = tmp.bytes.high;
		sci_slave->data[s_data_len++] = tmp.bytes.low;
		tmp.all = rtc_r.tm_min;
		sci_slave->data[s_data_len++] = tmp.bytes.high;
		sci_slave->data[s_data_len++] = tmp.bytes.low;
		tmp.all = rtc_r.tm_hour;
		sci_slave->data[s_data_len++] = tmp.bytes.high;
		sci_slave->data[s_data_len++] = tmp.bytes.low;
		tmp.all = rtc_r.tm_weekday;
		sci_slave->data[s_data_len++] = tmp.bytes.high;
		sci_slave->data[s_data_len++] = tmp.bytes.low;
		tmp.all = rtc_r.tm_day;
		sci_slave->data[s_data_len++] = tmp.bytes.high;
		sci_slave->data[s_data_len++] = tmp.bytes.low;
		tmp.all = rtc_r.tm_mon;
		sci_slave->data[s_data_len++] = tmp.bytes.high;
		sci_slave->data[s_data_len++] = tmp.bytes.low;
		tmp.all = rtc_r.tm_year;
		sci_slave->data[s_data_len++] = tmp.bytes.high;
		sci_slave->data[s_data_len++] = tmp.bytes.low;
	}
	else
	{
		sci_slave->data[s_data_len++] = 0;
		sdk_log_i("SCI get rtc err!\r\n");
	}

	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &sci_slave->data[0], s_data_len);
}
/******************************************************************************
 * sci_get_power_ref().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_get_power_ref(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	half_word_t tmp;

	tmp.all = array.pcsc.pcsc_ctrl.active_power_ref;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_ctrl.reactive_power_ref;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &sci_slave->data[0], s_data_len);
}

/******************************************************************************
 * sci_get_enet_parm().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_get_enet_parm(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	enet_parm_t *tmp;

	tmp = &array.csu.csu_data.set.enet_set;

	sci_slave->data[s_data_len++] = tmp->ip[0];
	sci_slave->data[s_data_len++] = tmp->ip[1];
	sci_slave->data[s_data_len++] = tmp->ip[2];
	sci_slave->data[s_data_len++] = tmp->ip[3];
	sci_slave->data[s_data_len++] = tmp->subnetmask[0];
	sci_slave->data[s_data_len++] = tmp->subnetmask[1];
	sci_slave->data[s_data_len++] = tmp->subnetmask[2];
	sci_slave->data[s_data_len++] = tmp->subnetmask[3];
	sci_slave->data[s_data_len++] = tmp->gateway[0];
	sci_slave->data[s_data_len++] = tmp->gateway[1];
	sci_slave->data[s_data_len++] = tmp->gateway[2];
	sci_slave->data[s_data_len++] = tmp->gateway[3];
	sci_slave->data[s_data_len++] = tmp->dns[0];
	sci_slave->data[s_data_len++] = tmp->dns[1];
	sci_slave->data[s_data_len++] = tmp->dns[2];
	sci_slave->data[s_data_len++] = tmp->dns[3];

	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &sci_slave->data[0], s_data_len);
}

/******************************************************************************
 * sci_get_uart_parm().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_get_uart_parm(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	uint8_t *data;
	half_word_t temp_data16;
	word_t temp_data32;
	int8_t i;

	data = sci_master->data;
	temp_data16.bytes.high = data[0];
	temp_data16.bytes.low  = data[1];
	if(temp_data16.all <= 7)
	{
		i = (int8_t)uart_id_to_index[(uint8_t)temp_data16.all];
	}
	else
	{
		i = -1;
	}

	if (i != -1)
	{
		temp_data16.all = array.pcsc.pcsc_ctrl.uart_conf[i].uart_index;
		sci_slave->data[s_data_len++] = temp_data16.bytes.high;
		sci_slave->data[s_data_len++] = temp_data16.bytes.low;

		temp_data16.all = array.pcsc.pcsc_ctrl.uart_conf[i].slave_addr;
		sci_slave->data[s_data_len++] = temp_data16.bytes.high;
		sci_slave->data[s_data_len++] = temp_data16.bytes.low;

		temp_data32.all = array.pcsc.pcsc_ctrl.uart_conf[i].baud_rate;
		sci_slave->data[s_data_len++] = temp_data32.byte[3];
		sci_slave->data[s_data_len++] = temp_data32.byte[2];
		sci_slave->data[s_data_len++] = temp_data32.byte[1];
		sci_slave->data[s_data_len++] = temp_data32.byte[0];

		temp_data16.all = array.pcsc.pcsc_ctrl.uart_conf[i].data_bits;
		sci_slave->data[s_data_len++] = temp_data16.bytes.high;
		sci_slave->data[s_data_len++] = temp_data16.bytes.low;

		temp_data16.all = array.pcsc.pcsc_ctrl.uart_conf[i].stop_bits;
		sci_slave->data[s_data_len++] = temp_data16.bytes.high;
		sci_slave->data[s_data_len++] = temp_data16.bytes.low;

		temp_data16.all = array.pcsc.pcsc_ctrl.uart_conf[i].parity;
		sci_slave->data[s_data_len++] = temp_data16.bytes.high;
		sci_slave->data[s_data_len++] = temp_data16.bytes.low;
		sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	}
	else
	{
		sci_slave->data[s_data_len++] = 0;
		sci_ack(sci_master, &sci_slave->data[0], s_data_len);
		sdk_log_i("SCI get uart err!\r\n");
	}

	sci_printf(sci_master, &sci_slave->data[0], s_data_len);
}


/******************************************************************************
 * sci_get_metering().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_get_metering(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	half_word_t tmp16;
	word_t tmp32;
	bool_t param_normal_flag = FALSE;
	meter_index_t meter_index;
	metering_meter_t *p_data = NULL;

	meter_index.all = sci_master->data[0];
	if(SFC_GET_METERING == sci_master->sub_command)
	{
		if(METERING_METER_1 == meter_index.bit.meter_id)
		{
			if(meter_index.bit.meter_num < metering_meter1_num)
			{
				p_data = &metering_meter[meter_index.bit.meter_num];
				param_normal_flag = TRUE;
			}
		}
		else if(METERING_METER_2 == meter_index.bit.meter_id)
		{
			if(0 == meter_index.bit.meter_num)
			{
				p_data = &meter2_other_data[0];
				param_normal_flag = TRUE;
			}
		}
		else if(METERING_METER_3 == meter_index.bit.meter_id)
		{
			if(meter_index.bit.meter_num < xiao_ju.ammeter3_num)
			{
				p_data = &meter3_other_data[meter_index.bit.meter_num];
				param_normal_flag = TRUE;
			}
		}
		else if(PCC_METER == meter_index.bit.meter_id)
		{
			if(0 == meter_index.bit.meter_num)
			{
				p_data = &pcc_meter_data;
				param_normal_flag = TRUE;
			}
		}
		else
		{
			param_normal_flag = FALSE;
		}
	}
	else
	{
		if(meter_index.all < pv_meter_parm.pv_meter_num)
		{
			p_data = &meter2_other_data[meter_index.all];
			param_normal_flag = TRUE;
		}
	}
	if(param_normal_flag)
	{
		sci_slave->data[s_data_len++] = meter_index.all;

		tmp32.all = (int32_t)(p_data->active_power_r * PARAMETER_ACCURACY_MAGNIFICATION_8);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (int32_t)(p_data->active_power_s * PARAMETER_ACCURACY_MAGNIFICATION_8);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (int32_t)(p_data->active_power_t * PARAMETER_ACCURACY_MAGNIFICATION_8);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (int32_t)(p_data->active_power * PARAMETER_ACCURACY_MAGNIFICATION_8);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (int32_t)(p_data->reactive_power_r * PARAMETER_ACCURACY_MAGNIFICATION_8);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (int32_t)(p_data->reactive_power_s * PARAMETER_ACCURACY_MAGNIFICATION_8);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (int32_t)(p_data->reactive_power_t * PARAMETER_ACCURACY_MAGNIFICATION_8);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (int32_t)(p_data->reactive_power * PARAMETER_ACCURACY_MAGNIFICATION_8);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (int32_t)(p_data->apparent_power_r * PARAMETER_ACCURACY_MAGNIFICATION_8);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (int32_t)(p_data->apparent_power_s * PARAMETER_ACCURACY_MAGNIFICATION_8);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (int32_t)(p_data->apparent_power_t * PARAMETER_ACCURACY_MAGNIFICATION_8);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (int32_t)(p_data->apparent_power * PARAMETER_ACCURACY_MAGNIFICATION_8);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp16.all = (int16_t)(p_data->power_factor_r * PARAMETER_ACCURACY_MAGNIFICATION_8);
		sci_slave->data[s_data_len++] = tmp16.bytes.high;
		sci_slave->data[s_data_len++] = tmp16.bytes.low;

		tmp16.all = (int16_t)(p_data->power_factor_s * PARAMETER_ACCURACY_MAGNIFICATION_8);
		sci_slave->data[s_data_len++] = tmp16.bytes.high;
		sci_slave->data[s_data_len++] = tmp16.bytes.low;

		tmp16.all = (int16_t)(p_data->power_factor_t * PARAMETER_ACCURACY_MAGNIFICATION_8);
		sci_slave->data[s_data_len++] = tmp16.bytes.high;
		sci_slave->data[s_data_len++] = tmp16.bytes.low;

		tmp16.all = (int16_t)(p_data->power_factor * PARAMETER_ACCURACY_MAGNIFICATION_8);
		sci_slave->data[s_data_len++] = tmp16.bytes.high;
		sci_slave->data[s_data_len++] = tmp16.bytes.low;

		tmp32.all = (uint32_t)(p_data->forward_total_active_energy * PARAMETER_ACCURACY_MAGNIFICATION_6);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (uint32_t)(p_data->forward_top_active_energy * PARAMETER_ACCURACY_MAGNIFICATION_6);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (uint32_t)(p_data->forward_peak_active_energy * PARAMETER_ACCURACY_MAGNIFICATION_6);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (uint32_t)(p_data->forward_flat_active_energy * PARAMETER_ACCURACY_MAGNIFICATION_6);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (uint32_t)(p_data->forward_valley_active_energy * PARAMETER_ACCURACY_MAGNIFICATION_6);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (uint32_t)(p_data->backward_total_active_energy * PARAMETER_ACCURACY_MAGNIFICATION_6);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (uint32_t)(p_data->backward_top_active_energy * PARAMETER_ACCURACY_MAGNIFICATION_6);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (uint32_t)(p_data->backward_peak_active_energy * PARAMETER_ACCURACY_MAGNIFICATION_6);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (uint32_t)(p_data->backward_flat_active_energy * PARAMETER_ACCURACY_MAGNIFICATION_6);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (uint32_t)(p_data->backward_valley_active_energy * PARAMETER_ACCURACY_MAGNIFICATION_6);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (uint32_t)(p_data->forward_total_reactive_energy * PARAMETER_ACCURACY_MAGNIFICATION_6);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (uint32_t)(p_data->forward_top_reactive_energy * PARAMETER_ACCURACY_MAGNIFICATION_6);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (uint32_t)(p_data->forward_peak_reactive_energy * PARAMETER_ACCURACY_MAGNIFICATION_6);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (uint32_t)(p_data->forward_flat_reactive_energy * PARAMETER_ACCURACY_MAGNIFICATION_6);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (uint32_t)(p_data->forward_valley_reactive_energy * PARAMETER_ACCURACY_MAGNIFICATION_6);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (uint32_t)(p_data->backward_total_reactive_energy * PARAMETER_ACCURACY_MAGNIFICATION_6);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (uint32_t)(p_data->backward_top_reactive_energy * PARAMETER_ACCURACY_MAGNIFICATION_6);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (uint32_t)(p_data->backward_peak_reactive_energy * PARAMETER_ACCURACY_MAGNIFICATION_6);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (uint32_t)(p_data->backward_flat_reactive_energy * PARAMETER_ACCURACY_MAGNIFICATION_6);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = (uint32_t)(p_data->backward_valley_reactive_energy * PARAMETER_ACCURACY_MAGNIFICATION_6);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = p_data->volt_r * PARAMETER_ACCURACY_MAGNIFICATION_6;
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = p_data->volt_s * PARAMETER_ACCURACY_MAGNIFICATION_6;
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = p_data->volt_t * PARAMETER_ACCURACY_MAGNIFICATION_6;
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = abs_int2uint(p_data->current_r * PARAMETER_ACCURACY_MAGNIFICATION_7);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = abs_int2uint(p_data->current_s * PARAMETER_ACCURACY_MAGNIFICATION_7);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = abs_int2uint(p_data->current_t * PARAMETER_ACCURACY_MAGNIFICATION_7);
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];

		tmp32.all = p_data->frequency * PARAMETER_ACCURACY_MAGNIFICATION_7;
		sci_slave->data[s_data_len++] = tmp32.byte[3];
		sci_slave->data[s_data_len++] = tmp32.byte[2];
		sci_slave->data[s_data_len++] = tmp32.byte[1];
		sci_slave->data[s_data_len++] = tmp32.byte[0];
	}
	else
	{
		sci_slave->data[s_data_len++] = 0xFF;
	}

	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &sci_slave->data[0], s_data_len);
}

/******************************************************************************
 * sci_get_holiday_data().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_get_holiday_data(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	ems_t *data;
	half_word_t tmp;
	uint8_t i;

	data = &ems;

	tmp.all = data->holiday_tm_enable;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	for (i = 0; i < TIME_PERIOD_NUM_MAX; i++)
	{
		tmp.all = data->holiday_tm_period[i].attribute;
		sci_slave->data[s_data_len++] = tmp.bytes.high;
		sci_slave->data[s_data_len++] = tmp.bytes.low;
		tmp.all = data->holiday_tm_period[i].power_ref;
		sci_slave->data[s_data_len++] = tmp.bytes.high;
		sci_slave->data[s_data_len++] = tmp.bytes.low;

		sci_slave->data[s_data_len++] = data->holiday_tm_period[i].start_hour;
		sci_slave->data[s_data_len++] = data->holiday_tm_period[i].start_min;
		sci_slave->data[s_data_len++] = data->holiday_tm_period[i].end_hour;
		sci_slave->data[s_data_len++] = data->holiday_tm_period[i].end_min;
	}
	memcpy(&sci_slave->data[s_data_len], data->holiday_date, sizeof(data->holiday_date));
	big2small_uint16(&sci_slave->data[s_data_len], HALF_WORD_LEN * EMS_HOLIDAY_DATE_NUM);
	s_data_len += sizeof(data->holiday_date);
	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &sci_slave->data[0], s_data_len);
}
/******************************************************************************
 * sci_get_drmn().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_get_drmn(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	half_word_t tmp;

	tmp.all = array.pcsc.pcsc_ctrl.drmn_status;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &sci_slave->data[0], s_data_len);
}
/******************************************************************************
 * sci_get_factory_parm().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_get_factory_parm(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	half_word_t tmp16;

	tmp16.all = factory_parm.all;
	sci_slave->data[s_data_len++] = tmp16.bytes.high;
	sci_slave->data[s_data_len++] = tmp16.bytes.low;

	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &sci_slave->data[0], s_data_len);
}

/******************************************************************************
 * sci_get_mcu2_note().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_get_mcu2_note(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	uint8_t i;

	for(i = 0; i < CMU_NUMS; i++)
	{
		sci_slave->data[s_data_len++] = array.cmu[i].action;
	}
	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &sci_slave->data[0], s_data_len);
}

/******************************************************************************
 * sci_get_xiao_ju_const().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_get_xiao_ju_const(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	word_t tmp;

	tmp.all = xiao_ju.ctrl_source;
	sci_slave->data[s_data_len++] = tmp.byte[3];
	sci_slave->data[s_data_len++] = tmp.byte[2];
	sci_slave->data[s_data_len++] = tmp.byte[1];
	sci_slave->data[s_data_len++] = tmp.byte[0];

	tmp.all = xiao_ju.transformer_capacity;
	sci_slave->data[s_data_len++] = tmp.byte[3];
	sci_slave->data[s_data_len++] = tmp.byte[2];
	sci_slave->data[s_data_len++] = tmp.byte[1];
	sci_slave->data[s_data_len++] = tmp.byte[0];

	tmp.all = xiao_ju.ammeter1_num;
	sci_slave->data[s_data_len++] = tmp.byte[3];
	sci_slave->data[s_data_len++] = tmp.byte[2];
	sci_slave->data[s_data_len++] = tmp.byte[1];
	sci_slave->data[s_data_len++] = tmp.byte[0];

	tmp.all = xiao_ju.ammeter3_num;
	sci_slave->data[s_data_len++] = tmp.byte[3];
	sci_slave->data[s_data_len++] = tmp.byte[2];
	sci_slave->data[s_data_len++] = tmp.byte[1];
	sci_slave->data[s_data_len++] = tmp.byte[0];

	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &sci_slave->data[0], s_data_len);
}

/******************************************************************************
 * sci_get_xiao_ju_var().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_get_xiao_ju_var(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	word_t tmp;

	tmp.all = xiao_ju.system_ctrl;
	sci_slave->data[s_data_len++] = tmp.byte[3];
	sci_slave->data[s_data_len++] = tmp.byte[2];
	sci_slave->data[s_data_len++] = tmp.byte[1];
	sci_slave->data[s_data_len++] = tmp.byte[0];

	tmp.all = xiao_ju.max_allow_chg_power;
	sci_slave->data[s_data_len++] = tmp.byte[3];
	sci_slave->data[s_data_len++] = tmp.byte[2];
	sci_slave->data[s_data_len++] = tmp.byte[1];
	sci_slave->data[s_data_len++] = tmp.byte[0];

	tmp.all = xiao_ju.max_allow_dch_power;
	sci_slave->data[s_data_len++] = tmp.byte[3];
	sci_slave->data[s_data_len++] = tmp.byte[2];
	sci_slave->data[s_data_len++] = tmp.byte[1];
	sci_slave->data[s_data_len++] = tmp.byte[0];

	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &sci_slave->data[0], s_data_len);
}


/******************************************************************************
 * sci_get_sys_sn().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_get_sys_sn(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	uint8_t i = 0;

	for(i = 0; i < 21; i++)
	{
		sci_slave->data[s_data_len++] = system_sn[i];
	}
	sci_slave->data[s_data_len++] = 0x00;

	for(i = 0; i < 21; i++)
	{
		sci_slave->data[s_data_len++] = sz_csu_sn[i];
	}
	sci_slave->data[s_data_len++] = 0x00;

	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &sci_slave->data[0], s_data_len);
}

/******************************************************************************
 * sci_get_master_slave_data().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_get_master_slave_data(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	uint8_t i = 0;
	half_word_t tmp;

	tmp.all = array.csu.csu_data.csu_heart.csu_role;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	for (i = 0; i < CMU_NUMS; i++)
	{
		tmp.all = array.pcsc.pcsc_data.pcsm_data[i].set[WRITE_INDEX].active_power_ref;
		sci_slave->data[s_data_len++] = tmp.bytes.high;
		sci_slave->data[s_data_len++] = tmp.bytes.low;
	}

	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &sci_slave->data[0], s_data_len);
}

/******************************************************************************
 * sci_get_pv_param().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_get_pv_param(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	half_word_t tmp;

	tmp.all = pv_meter_parm.pv_meter_num;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	sci_slave->data[s_data_len++] = ems.meter_current_direction.bits.meter2_cur_dir;

	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
}


/******************************************************************************
 * sci_get_sys_var_parm().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_get_sys_var_parm(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	half_word_t tmp;

	tmp.all = ems.soc_min;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = ems.soc_min;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
}

/******************************************************************************
 * sci_get_remote_control().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_get_remote_control(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	half_word_t tmp;

	tmp.all = array.pcsc.pcsc_ctrl.cmd.all;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &sci_slave->data[0], s_data_len);
}

/******************************************************************************
 * sci_get_remote_measure().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_get_remote_measure(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	half_word_t tmp;
	word_t tmp32;
	float32_t tmp32_f;
	uint8_t i;

	tmp.all = array.pcsc.pcsc_ctrl.pcsm_nums_set;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_ctrl.rs485_enable.all;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_ctrl.scenario_setting;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.state.sys_state;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.state.grid_tied_state;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.var.v_grd_rs;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.var.v_grd_st;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.var.v_grd_tr;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.var.v_out_rs;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.var.v_out_st;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.var.v_out_tr;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.var.i_out_r;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.var.i_out_s;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.var.i_out_t;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.var.grid_freq;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.var.t_board;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.var.t_ac_fuse;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp32.all = array.pcsc.pcsc_data.var.power_p;
	sci_slave->data[s_data_len++] = tmp32.byte[3];
	sci_slave->data[s_data_len++] = tmp32.byte[2];
	sci_slave->data[s_data_len++] = tmp32.byte[1];
	sci_slave->data[s_data_len++] = tmp32.byte[0];

	tmp32.all = array.pcsc.pcsc_data.var.power_q;
	sci_slave->data[s_data_len++] = tmp32.byte[3];
	sci_slave->data[s_data_len++] = tmp32.byte[2];
	sci_slave->data[s_data_len++] = tmp32.byte[1];
	sci_slave->data[s_data_len++] = tmp32.byte[0];

	tmp32.all = array.pcsc.pcsc_data.var.power_s;
	sci_slave->data[s_data_len++] = tmp32.byte[3];
	sci_slave->data[s_data_len++] = tmp32.byte[2];
	sci_slave->data[s_data_len++] = tmp32.byte[1];
	sci_slave->data[s_data_len++] = tmp32.byte[0];

	tmp32.all = array.pcsc.pcsc_data.var.today_chg_energy;
	sci_slave->data[s_data_len++] = tmp32.byte[3];
	sci_slave->data[s_data_len++] = tmp32.byte[2];
	sci_slave->data[s_data_len++] = tmp32.byte[1];
	sci_slave->data[s_data_len++] = tmp32.byte[0];

	tmp32.all = array.pcsc.pcsc_data.var.today_dch_energy;
	sci_slave->data[s_data_len++] = tmp32.byte[3];
	sci_slave->data[s_data_len++] = tmp32.byte[2];
	sci_slave->data[s_data_len++] = tmp32.byte[1];
	sci_slave->data[s_data_len++] = tmp32.byte[0];

	tmp32.all = array.pcsc.pcsc_data.var.total_chg_energy;
	sci_slave->data[s_data_len++] = tmp32.byte[3];
	sci_slave->data[s_data_len++] = tmp32.byte[2];
	sci_slave->data[s_data_len++] = tmp32.byte[1];
	sci_slave->data[s_data_len++] = tmp32.byte[0];

	tmp32.all = array.pcsc.pcsc_data.var.total_dch_energy;
	sci_slave->data[s_data_len++] = tmp32.byte[3];
	sci_slave->data[s_data_len++] = tmp32.byte[2];
	sci_slave->data[s_data_len++] = tmp32.byte[1];
	sci_slave->data[s_data_len++] = tmp32.byte[0];

	tmp32.all = array.pcsc.pcsc_data.var.total_runtime;
	sci_slave->data[s_data_len++] = tmp32.byte[3];
	sci_slave->data[s_data_len++] = tmp32.byte[2];
	sci_slave->data[s_data_len++] = tmp32.byte[1];
	sci_slave->data[s_data_len++] = tmp32.byte[0];

	tmp.all = array.pcsc.pcsc_data.var.v_ac_r;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.var.v_ac_s;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.var.v_ac_t;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.var.active_power_r;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.var.active_power_s;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.var.active_power_t;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.var.reactive_power_r;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.var.reactive_power_s;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.var.reactive_power_t;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.var.apparent_power_r;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.var.apparent_power_s;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.var.apparent_power_t;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	if(ONE_STORAGE_TANK_XIAOJU_1_2 != array.pcsc.pcsc_ctrl.scenario_setting)
	{
		tmp32_f = ems.ammeter.power;
	}
	else
	{
		tmp32_f = xiaoju_ammeter.ammeter_2 + xiaoju_ammeter.ammeter_3;
	}
	memory_copy(&tmp32, &tmp32_f, WORD_LEN);
	sci_slave->data[s_data_len++] = tmp32.byte[3];
	sci_slave->data[s_data_len++] = tmp32.byte[2];
	sci_slave->data[s_data_len++] = tmp32.byte[1];
	sci_slave->data[s_data_len++] = tmp32.byte[0];

	tmp.all = dehumidifier_data.temperature;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = dehumidifier_data.humidity;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = product_info.model_num;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = dehumidifier_set.humidity_set;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = dehumidifier_set.humidity_diff_set;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp32_f = 0.0f;
	for (i = 0; i < pv_meter_parm.pv_meter_num; i++)
	{
		tmp32_f += (meter2_other_data[i].active_power * PARAMETER_ACCURACY_MAGNIFICATION_6);
	}
	memory_copy(&tmp32, &tmp32_f, WORD_LEN);
	sci_slave->data[s_data_len++] = tmp32.byte[3];
	sci_slave->data[s_data_len++] = tmp32.byte[2];
	sci_slave->data[s_data_len++] = tmp32.byte[1];
	sci_slave->data[s_data_len++] = tmp32.byte[0];
	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &sci_slave->data[0], s_data_len);
}

/******************************************************************************
 * sci_get_remote_signal().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_get_remote_signal(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	half_word_t tmp;

	tmp.all = array.pcsc.pcsc_data.state.state1.all;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.state.state2.all;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	// reserved
	tmp.all = 0;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	// reserved
	tmp.all = 0;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.fault.fault1.all;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.fault.fault2.all;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.fault.fault3.all;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.fault.fault4.all;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_data.fault.fault5.all;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	// reserved
	tmp.all = 0;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	// reserved
	tmp.all = 0;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	// reserved
	tmp.all = 0;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &sci_slave->data[0], s_data_len);
}
/******************************************************************************
 * sci_get_inter_data().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_get_inter_data(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	half_word_t tmp16;
	uint8_t i;

	SCI_ONPACK_WORD(sci_slave->data, s_data_len, meter1_conn_count);
	SCI_ONPACK_WORD(sci_slave->data, s_data_len, meter1_disconn_count);
	SCI_ONPACK_WORD(sci_slave->data, s_data_len, meter2_conn_count);
	SCI_ONPACK_WORD(sci_slave->data, s_data_len, meter2_disconn_count);
	SCI_ONPACK_WORD(sci_slave->data, s_data_len, meter3_conn_count);
	SCI_ONPACK_WORD(sci_slave->data, s_data_len, meter3_disconn_count);
	SCI_ONPACK_WORD(sci_slave->data, s_data_len, backflow_conn_count);
	SCI_ONPACK_WORD(sci_slave->data, s_data_len, backflow_disconn_count);
	SCI_ONPACK_WORD(sci_slave->data, s_data_len, pv_meter_conn_count);
	SCI_ONPACK_WORD(sci_slave->data, s_data_len, pv_meter_disconn_count);

	tmp16.all = array.pcsc.pcsc_ctrl.bat_status_info.chg_ctrl.all;
	sci_slave->data[s_data_len++] = tmp16.bytes.high;
	sci_slave->data[s_data_len++] = tmp16.bytes.low;

	tmp16.all = array.pcsc.pcsc_ctrl.bat_status_info.dch_ctrl.all;
	sci_slave->data[s_data_len++] = tmp16.bytes.high;
	sci_slave->data[s_data_len++] = tmp16.bytes.low;

	tmp16.all = array.pcsc.pcsc_data.pcsm_data[i].state.derate_sout_outport;
	sci_slave->data[s_data_len++] = tmp16.bytes.high;
	sci_slave->data[s_data_len++] = tmp16.bytes.low;
	for (i = 0; i < CMU_NUMS; i++)
	{
		sci_slave->data[s_data_len++] = array.cmu[i].sys_status;
		sci_slave->data[s_data_len++] = array.cmu[i].bat_status;
		sci_slave->data[s_data_len++] = array.cmu[i].soc_chg;
		sci_slave->data[s_data_len++] = array.cmu[i].soh_chg;
		sci_slave->data[s_data_len++] = array.cmu[i].soc_dch;
		sci_slave->data[s_data_len++] = array.cmu[i].soh_dch;

		tmp16.all = array.pcsc.pcsc_data.pcsm_data[i].state.derate_sout_intport;
		sci_slave->data[s_data_len++] = tmp16.bytes.high;
		sci_slave->data[s_data_len++] = tmp16.bytes.low;

		tmp16.all = array.pcsc.pcsc_data.pcsm_data[i].state.derate_sout_outport;
		sci_slave->data[s_data_len++] = tmp16.bytes.high;
		sci_slave->data[s_data_len++] = tmp16.bytes.low;

		tmp16.all = pcsm_chg_dch_limit[i].chg_limit;
		sci_slave->data[s_data_len++] = tmp16.bytes.high;
		sci_slave->data[s_data_len++] = tmp16.bytes.low;

		tmp16.all = pcsm_chg_dch_limit[i].dch_limit;
		sci_slave->data[s_data_len++] = tmp16.bytes.high;
		sci_slave->data[s_data_len++] = tmp16.bytes.low;

		tmp16.all = array.pcsc.pcsc_ctrl.bat_status_info.chg_lmt_power[i];
		sci_slave->data[s_data_len++] = tmp16.bytes.high;
		sci_slave->data[s_data_len++] = tmp16.bytes.low;

		tmp16.all = array.pcsc.pcsc_ctrl.bat_status_info.dch_lmt_power[i];
		sci_slave->data[s_data_len++] = tmp16.bytes.high;
		sci_slave->data[s_data_len++] = tmp16.bytes.low;

		tmp16.all = array.pcsc.pcsc_data.pcsm_data[i].set[WRITE_INDEX].active_power_ref;
		sci_slave->data[s_data_len++] = tmp16.bytes.high;
		sci_slave->data[s_data_len++] = tmp16.bytes.low;
	}
	sci_slave->data[s_data_len++] = power_magic_init_ok;
	sci_slave->data[s_data_len++] = trigger_rack_manage;
	sci_slave->data[s_data_len++] = trigger_bat_capacity_test;
	sci_slave->data[s_data_len++] = array.csu.csu_data.csu_heart.csu_role;
	sci_slave->data[s_data_len++] = ems.demand_side.mark;
	sci_slave->data[s_data_len++] = ems.anti_backflow.mark;
	sci_slave->data[s_data_len++] = ems.automatic.mark;
	sci_slave->data[s_data_len++] = ems.c2d.mark;
	sci_slave->data[s_data_len++] = ems.cpfv.mark;
	sci_slave->data[s_data_len++] = ems.soc_maint.mark;
	sci_slave->data[s_data_len++] = ems.soc_max_cmu;
	sci_slave->data[s_data_len++] = ems.soc_min_cmu;

	tmp16.all = ems.inter_max_chg_power;
	sci_slave->data[s_data_len++] = tmp16.bytes.high;
	sci_slave->data[s_data_len++] = tmp16.bytes.low;

	tmp16.all = ems.inter_min_chg_power;
	sci_slave->data[s_data_len++] = tmp16.bytes.high;
	sci_slave->data[s_data_len++] = tmp16.bytes.low;

	tmp16.all = ems.inter_max_dch_power;
	sci_slave->data[s_data_len++] = tmp16.bytes.high;
	sci_slave->data[s_data_len++] = tmp16.bytes.low;

	tmp16.all = ems.inter_min_dch_power;
	sci_slave->data[s_data_len++] = tmp16.bytes.high;
	sci_slave->data[s_data_len++] = tmp16.bytes.low;

	sci_slave->data[s_data_len++] = array.array_data.variable.cmu_online;
	sci_slave->data[s_data_len++] = array.array_data.variable.cmu_running;

	tmp16.all = ems.rated_capacity;
	sci_slave->data[s_data_len++] = tmp16.bytes.high;
	sci_slave->data[s_data_len++] = tmp16.bytes.low;

	tmp16.all = array.csu.csu_data.csu_const.base_rated_power;
	sci_slave->data[s_data_len++] = tmp16.bytes.high;
	sci_slave->data[s_data_len++] = tmp16.bytes.low;

	SCI_ONPACK_FLOAT(sci_slave->data, s_data_len, ems.ammeter.power);
	SCI_ONPACK_FLOAT(sci_slave->data, s_data_len, ems.ammeter.power_q);
	SCI_ONPACK_FLOAT(sci_slave->data, s_data_len, ems.ammeter.power_factor);
	SCI_ONPACK_FLOAT(sci_slave->data, s_data_len, metering_meter[0].active_power);
	SCI_ONPACK_FLOAT(sci_slave->data, s_data_len, meter2_other_data[0].active_power);
	for (i = 0; i < METERING_METER3_MAX_NUM; i++)
	{
		SCI_ONPACK_FLOAT(sci_slave->data, s_data_len, meter3_other_data[i].active_power);
	}
	for (i = 0; i < PV_METER_MAX_NUM; i++)
	{
		SCI_ONPACK_FLOAT(sci_slave->data, s_data_len, meter2_other_data[i].active_power);
	}

	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &sci_slave->data[0], s_data_len);
}
/******************************************************************************
 * sci_get_bat_parm().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_get_bat_parm(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	half_word_t tmp;
	uint8_t i;

	for(i = 0; i < BAT_RACK_MAX_NUMS_TOTAL; i++)
	{
		tmp.all = array.pcsc.pcsc_data.var.bat_soc[i];
		sci_slave->data[s_data_len++] = tmp.bytes.high;
		sci_slave->data[s_data_len++] = tmp.bytes.low;
	}

	for(i = 0; i < BAT_RACK_MAX_NUMS_TOTAL; i++)
	{
		tmp.all = array.pcsc.pcsc_data.var.bat_soh[i];
		sci_slave->data[s_data_len++] = tmp.bytes.high;
		sci_slave->data[s_data_len++] = tmp.bytes.low;
	}
	for(i = 0; i < CMU_NUMS; i++)
	{
		tmp.all = array.pcsc.pcsc_ctrl.bat_status_info.chg_lmt_power[i];
		sci_slave->data[s_data_len++] = tmp.bytes.high;
		sci_slave->data[s_data_len++] = tmp.bytes.low;

		tmp.all = array.pcsc.pcsc_ctrl.bat_status_info.dch_lmt_power[i];
		sci_slave->data[s_data_len++] = tmp.bytes.high;
		sci_slave->data[s_data_len++] = tmp.bytes.low;
	}

	for(i = 0; i < CMU_NUMS; i++)
	{
		tmp.all = array.pcsc.pcsc_ctrl.bat_status_info.soc_max[i];
		sci_slave->data[s_data_len++] = tmp.bytes.high;
		sci_slave->data[s_data_len++] = tmp.bytes.low;

		tmp.all = array.pcsc.pcsc_ctrl.bat_status_info.soc_min[i];
		sci_slave->data[s_data_len++] = tmp.bytes.high;
		sci_slave->data[s_data_len++] = tmp.bytes.low;
	}

	tmp.all = array.pcsc.pcsc_ctrl.bat_status_info.chg_ctrl.all;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = array.pcsc.pcsc_ctrl.bat_status_info.dch_ctrl.all;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	for(i = 0; i < CMU_NUMS; i++)
	{
		sci_slave->data[s_data_len++] = array.cmu[i].sys_status;
	}
	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &sci_slave->data[0], s_data_len);
}

/******************************************************************************
 * sci_get_ems_data().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_get_ems_parm(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;
	ems_t *data;
	half_word_t tmp;
	uint8_t i;

	data = &ems;

	tmp.all = data->demand_side.enable;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->demand_side.dead_band;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->demand_side.demand_quantity;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->anti_backflow.enable;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->allow_sale_power;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->c2d.enable;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->allow_purchase_power;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->cpfv.enable;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	for (i = 0; i < TIME_PERIOD_NUM_MAX; i++)
	{
		tmp.all = data->tm_period[i].attribute;
		sci_slave->data[s_data_len++] = tmp.bytes.high;
		sci_slave->data[s_data_len++] = tmp.bytes.low;

		sci_slave->data[s_data_len++] = data->tm_period[i].start_hour;
		sci_slave->data[s_data_len++] = data->tm_period[i].start_min;
		sci_slave->data[s_data_len++] = data->tm_period[i].end_hour;
		sci_slave->data[s_data_len++] = data->tm_period[i].end_min;
	}

	tmp.all = data->soc_max;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->pcc_power_set;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->cpfv.k1;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->p_chgmax_theory;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->soc_min;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->p_dischg_step;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->cpfv.k2;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->p_dischgmax_theory;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->soc_maint.enable;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->soc_maint.power_maint;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->force_control.enable;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->q_power_step;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->power_factor;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->rated_capacity;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->cpfv.early_closure_peak;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->cpfv.early_closure_top;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->cpfv.early_closure_valley;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->pcs_standby_wait_time;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->pcs_stop_wait_time;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->pcs_advance_startup_time;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->automatic.enable;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	tmp.all = data->meter_current_direction.all;
	sci_slave->data[s_data_len++] = tmp.bytes.high;
	sci_slave->data[s_data_len++] = tmp.bytes.low;

	for (i = 0; i < TIME_PERIOD_NUM_MAX; i++)
	{
		tmp.all = data->tm_period[i].power_ref;
		sci_slave->data[s_data_len++] = tmp.bytes.high;
		sci_slave->data[s_data_len++] = tmp.bytes.low;
	}

	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
	sci_printf(sci_master, &sci_slave->data[0], s_data_len);
}

/******************************************************************************
 * sci_get_pcsm_data().
 * . [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_get_pcsm_data(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;

	// TODO 暂时不做， MCU1 能直接读取
	sci_slave->data[s_data_len++] = 0x01;

	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
}

/******************************************************************************
 * data_swap().
 * hand shaked. [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void data_swap(sci_master_t *sci_master)
{
	uint8_t index = sci_master->sub_command;

	switch(index)
	{
		case SFC_GET_SYS_TIME:
			sci_get_sys_time(sci_master);
			break;
		case SFC_GET_POWER_REF:
			sci_get_power_ref(sci_master);
			break;
		case SFC_GET_ENET_DATA:
			sci_get_enet_parm(sci_master);
			break;
		case SFC_GET_PCSM_DATA:
			sci_get_pcsm_data(sci_master);
			break;
		case SFC_GET_BAT_PARM:
			sci_get_bat_parm(sci_master);
			break;
		case SFC_GET_EMS_CONST:
			sci_get_ems_parm(sci_master);
			break;
		case SFC_GET_UART_PARM:
			sci_get_uart_parm(sci_master);
			break;
		case SFC_GET_METERING:
			sci_get_metering(sci_master);
			break;
		case SFC_GET_HOLIDAY_DATA:
			sci_get_holiday_data(sci_master);
			break;
		case SFC_GET_DRMN:
			sci_get_drmn(sci_master);
			break;
		case SFC_GET_XIAO_JU_CONST:
			sci_get_xiao_ju_const(sci_master);
			break;
		case SFC_GET_XIAO_JU_VAR:
			sci_get_xiao_ju_var(sci_master);
			break;
		case SFC_GET_FACTORY_PARM:
			sci_get_factory_parm(sci_master);
			break;
		case SFC_GET_MCU2_NOTE:
			sci_get_mcu2_note(sci_master);
			break;
		case SFC_GET_SYS_SN:
			sci_get_sys_sn(sci_master);
			break;
		case SFC_GET_M_S_DATA:
			sci_get_master_slave_data(sci_master);
			break;
		case SFC_GET_PV_METER:
			sci_get_metering(sci_master);
			break;
		case SFC_GET_PV_PARM:
			sci_get_pv_param(sci_master);
			break;
		case SFC_GET_EMS_VAR     :
			sci_get_sys_var_parm(sci_master);
			break;
		case SFC_GET_REMOTE_CONTROL:
			sci_get_remote_control(sci_master);
			break;
		case SFC_GET_REMOTE_MEASURE:
			sci_get_remote_measure(sci_master);
			break;
		case SFC_GET_REMOTE_SIGNAL:
			sci_get_remote_signal(sci_master);
			break;
		case SFC_GET_INTER_DATA:
			sci_get_inter_data(sci_master);
			break;
		// TODO 获取安规参数？
		default:
			break;
	}
}

/******************************************************************************
 * sci_upgrade_query_chip().
 * query chip. [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_upgrade_query_chip(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;

	sdk_fs_close(file);
	sdk_fs_remove((const int8_t*)TMP_FILE_NAME);
	last_package_num.all = 0;

	file_system_init();
	file = sdk_fs_open((const int8_t*)TMP_FILE_NAME, \
										FA_WRITE | FA_READ | FA_OPEN_ALWAYS);
	if(file == NULL)
	{
		sdk_fs_format((const int8_t*)"1:");
		sdk_log_i("open tmp.bin failure, in sci_upgrade_query_chip");
		sci_slave->data[s_data_len++] = 0x00;
	}
	else
	{
		sci_slave->data[s_data_len++] = CHIP_TYPE;
	}

	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
}

/******************************************************************************
 * sci_upgrade_rev_data().
 * sci_slave->data. [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_upgrade_rev_data(sci_master_t *sci_master)
{
	int32_t ret;
	int32_t tmp;
	uint16_t package_num = 0;
	uint16_t w_data_len = 0;
	uint8_t *data = NULL;
	uint8_t s_data_len = 0;

	data = sci_master->data;
	package_num = BIG_2_SMALL(data[0], data[1]);
	w_data_len = sci_master->len - 5;

	if((last_package_num.all + 1) == package_num)
	{
		ret = sdk_fs_write(file, data + 2, w_data_len);
		if(ret == w_data_len)
		{
			last_package_num.all = package_num;
			sdk_log_i("pack:%d\r\n",package_num);
		}
		else
		{
			// if write failed, then restore to start point
			tmp = sdk_fs_get_size(file);
			tmp -= ret;
			sdk_fs_lseek(file, tmp);
		}
	}

	sci_slave->data[s_data_len++] = last_package_num.bytes.high;
	sci_slave->data[s_data_len++] = last_package_num.bytes.low;

	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
}

/******************************************************************************
 * sci_upgrade_file_crc().
 * Calculated check value. [Called by app.]
 *
 * @param file_type	(I) bin file type
 * @return none
 *****************************************************************************/
int32_t sci_upgrade_file_crc(uint8_t *file_type)
{
	int32_t result;
	uint32_t i = 0;
	uint16_t read_len = 0;
	uint32_t crc = 0xFFFFFFFF;
	uint32_t tmp = 0;
	word_t crc_effective;
	word_t file_size;

	file = sdk_fs_open((const int8_t*)TMP_FILE_NAME, FS_READ);

	if(file != NULL)
	{
		file_size.all = sdk_fs_get_size(file);
		if((file_size.all > 1024) && (file_size.all < SFC_UPGRADE_FILE_SIZE * 1024))
		{
			sdk_fs_lseek(file, file_size.all - 1024);
			sdk_fs_read(file, g_upgrade_buf, 1024);

			*file_type = *(g_upgrade_buf + 128);
			// file_size.all = g_update_buf[1] | (g_update_buf[2] << 8) | \
			//             (g_update_buf[3] << 16) | (g_update_buf[4] << 24);
			file_size.byte[0] = g_upgrade_buf[1];
			file_size.byte[1] = g_upgrade_buf[2];
			file_size.byte[2] = g_upgrade_buf[3];
			file_size.byte[3] = g_upgrade_buf[4];
			// crc_effective = g_update_buf[5] | (g_update_buf[6] << 8) | \
			//             (g_update_buf[7] << 16) | (g_update_buf[8] << 24);
			crc_effective.byte[0] = g_upgrade_buf[5];
			crc_effective.byte[1] = g_upgrade_buf[6];
			crc_effective.byte[2] = g_upgrade_buf[7];
			crc_effective.byte[3] = g_upgrade_buf[8];

			sdk_fs_lseek(file, 0);
			tmp = file_size.all / UPGRADE_BUF_SIZE;
			for(i = 0; i < tmp; i++)
			{
				read_len = sdk_fs_read(file, g_upgrade_buf, UPGRADE_BUF_SIZE);
				crc = CRC32(&g_upgrade_buf[0], read_len, crc);
			}

			sdk_fs_read(file, g_upgrade_buf, UPGRADE_BUF_SIZE);
			crc = CRC32(&g_upgrade_buf[0], file_size.all % UPGRADE_BUF_SIZE, crc);

			if(crc == crc_effective.all)
			{
				result = SF_OK;
			}
			else
			{
				result = SF_ERR_NDEF;
			}
		}
		else
		{
			result = SF_ERR_NDEF;
		}
	}
	else
	{
		result = SF_ERR_PARA;
	}

	sdk_fs_close(file);

	return result;
}

/******************************************************************************
 * sci_upgrade_file_check().
 * upgrade. [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_upgrade_file_check(sci_master_t *sci_master)
{
	int32_t ret;
	uint8_t file_type = 0;
	uint8_t s_data_len = 0;

	ret = sdk_fs_close(file);
	last_package_num.all = 0;

	if(ret == SF_OK)
	{
		ret = sci_upgrade_file_crc(&file_type);
	}

	if(ret == SF_OK)
	{
		// app.bin
		if(file_type == 0)
		{
			sdk_fs_remove((const int8_t*)APP_FILE_NAME);
			sdk_fs_rename((const int8_t*)TMP_FILE_NAME, \
												(const int8_t*)APP_FILE_NAME);
			//sdk_start_upgrade((uint8_t*)APP_FILE_NAME, 1);
			file_succ_flag[0] = TRUE;
		}
		// core.bin
		else
		{
			sdk_fs_remove((const int8_t*)CORE_FILE_NAME);
			sdk_fs_rename((const int8_t*)TMP_FILE_NAME, \
												(const int8_t*)CORE_FILE_NAME);
			//sdk_start_upgrade((uint8_t*)CORE_FILE_NAME, 1);
			file_succ_flag[1] = TRUE;
		}
		sci_slave->data[s_data_len++] = 0x01;
	}
	else
	{
		sci_slave->data[s_data_len++] = 0x00;
		sdk_log_i("upgrade .bin crc failure");
	}

	sci_ack(sci_master, sci_slave->data, s_data_len);
}

/******************************************************************************
 * sci_upgrade_start_up().
 * upgrade. [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_upgrade_start_up(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;

	sci_slave->data[s_data_len++] = 0x01;
	sci_ack(sci_master, sci_slave->data, s_data_len);
	if(file_succ_flag[0] == TRUE)
	{
		sdk_start_upgrade((uint8_t*)APP_FILE_NAME, FIRMWARE_NEED_UPGRADE);
	}

	if((file_succ_flag[1] == TRUE) && (file_succ_flag[0] == TRUE))
	{
		sdk_start_upgrade((uint8_t*)CORE_FILE_NAME, FIRMWARE_NEED_UPGRADE);
	}

	sdk_sys_reset();
}

/******************************************************************************
 * sci_pause_mcu2_pcs_req().
 * Pause MCU2 to PCS CAN message request. [Called by app.]
 *
 * @param  sci_master (I) master_sci_struct
 * @return none
 *****************************************************************************/
static void sci_pause_mcu2_pcs_req(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;

	trigger_pcs_sm    = !sci_master->data[0];
	trigger_pcs_var   = !sci_master->data[0];
	trigger_pcs_const = !sci_master->data[0];

	sci_slave->data[s_data_len++] = 0x01;
	sci_ack(sci_master, sci_slave->data, s_data_len);
}

/******************************************************************************
 * sci_upgrade().
 * upgrade. [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_upgrade(sci_master_t *sci_master)
{
	uint8_t index = sci_master->sub_command;

	switch(index)
	{
		case SFC_UPGRADE_QUERY:
			sci_upgrade_query_chip(sci_master);
			break;
		case SFC_UPGRADE_DATA:
			sci_upgrade_rev_data(sci_master);
			break;
		case SFC_UPGRADE_END:
			sci_upgrade_file_check(sci_master);
			break;
		case SFC_UPGRADE_START:
			sci_upgrade_start_up(sci_master);
			break;
		case SFC_PAUSE_MCU2_PCS_REQ:
			sci_pause_mcu2_pcs_req(sci_master);
		default:
			break;
	}
}

/******************************************************************************
 * sci_file_write_start().
 * Request file write. [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_file_write_start(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;

	last_package_num.all = 0;
	sdk_fs_remove((const int8_t*)IEC61850_FILE_NAME);
	file = sdk_fs_open((const int8_t*)IEC61850_FILE_NAME, \
										FA_WRITE | FA_READ | FA_OPEN_ALWAYS);

	if(file == NULL)
	{
		sdk_log_i("open IEC61850_FILE_NAME.bin failure, in sci");
		sci_slave->data[s_data_len++] = 0x00;
	}
	else
	{
		sci_slave->data[s_data_len++] = 0x01;
	}

	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
}

/******************************************************************************
 * sci_file_write_data().
 * Write file data. [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_file_write_data(sci_master_t *sci_master)
{
	int32_t ret;
	int32_t tmp;
	uint16_t package_num = 0;
	uint16_t w_data_len = 0;
	uint8_t *data = NULL;
	uint8_t s_data_len = 0;

	data = sci_master->data;
	package_num = BIG_2_SMALL(data[0], data[1]);
	w_data_len = sci_master->len - 5;

	if((last_package_num.all + 1) == package_num)
	{
		ret = sdk_fs_write(file, data + 2, w_data_len);
		if(ret == w_data_len)
		{
			last_package_num.all = package_num;
			sdk_log_i("pack:%d\r\n",package_num);
		}
		else
		{
			// if write failed, then restore to start point
			tmp = sdk_fs_get_size(file);
			tmp -= ret;
			sdk_fs_lseek(file, tmp);
		}
	}

	sci_slave->data[s_data_len++] = last_package_num.bytes.high;
	sci_slave->data[s_data_len++] = last_package_num.bytes.low;

	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
}

/******************************************************************************
 * sci_file_write_end().
 * File write done. [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_file_write_end(sci_master_t *sci_master)
{
	uint8_t s_data_len = 0;

	sdk_fs_close(file);

//	trigger_iec61850_cid = TRUE;
	sci_slave->data[s_data_len++] = 0x01;
	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
}

/******************************************************************************
 * sci_file_read_start().
 * Request file read. [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_file_read_start(sci_master_t *sci_master)
{
	int8_t s_log_num[2] = {0, 0};
	uint8_t s_data_len = 0;
	uint16_t temp_num = 0;
	uint16_t total_pack_num = 0;
	uint8_t file_name_len;

	file_name_len = sci_master->data[0];
	if(0 == strncmp((char*)&sci_master->data[1], FAULT_LOG_FILE_NAME, file_name_len))
	{
		log_type = DIAG_LOG;
	}
	else if(0 == strncmp((char*)&sci_master->data[1], OPT_LOG_FILE_NAME, file_name_len))
	{
		log_type = OPAT_LOG;
	}
	else if(0 == strncmp((char*)&sci_master->data[1], DEBUG_LOG_FILE_NAME, file_name_len))
	{
		log_type = DEBUG_LOG;
	}
	else
	{}

	if((log_type == DIAG_LOG) || (log_type == OPAT_LOG) || (log_type == DEBUG_LOG))
	{
		temp_num = sdk_record_get_index(log_type);
		total_pack_num = temp_num / 3;
		if(temp_num % 3 == 0)
		{
			s_log_num[0] = total_pack_num >> 8;
			s_log_num[1] = total_pack_num & 0xff;
		}
		else
		{
			total_pack_num++;
			s_log_num[0] = total_pack_num >> 8;
			s_log_num[1] = total_pack_num & 0xff;
		}

		sci_slave->data[s_data_len++] = s_log_num[0];
		sci_slave->data[s_data_len++] = s_log_num[1];
	}
	else
	{
		sdk_log_i("get diag file failed");
		sci_slave->data[s_data_len++] = 0x00;
	}

	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
}

/******************************************************************************
 * sci_file_read_data().
 * Read file data. [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_file_read_data(sci_master_t *sci_master)
{
	int32_t ret;
	int32_t s_log_num = 0;
	uint8_t s_data_len = 0;
	uint16_t package_num = 0;
	uint8_t *data = NULL;
	uint32_t i = 0;
	uint32_t log_len = 0;

	data = sci_master->data;

	package_num = BIG_2_SMALL(data[0], data[1]) - 1;
	s_log_num = sdk_record_get_index(log_type);

	if((package_num * 3) >= s_log_num)
	{
		sdk_log_i("log num receive error!\r\n");
	}
	else
	{
		if(log_type == DIAG_LOG)
		{
			log_len = ONE_DIAG_LOG_SIZE;
		}
		else if(log_type == OPAT_LOG)
		{
			log_len = ONE_OPAT_LOG_SIZE;
		}
		else if(log_type == DEBUG_LOG)
		{
			log_len = ONE_DEBUG_LOG_SIZE;
		}
		else
		{
		}
		sci_slave->data[s_data_len++] = data[0];
		sci_slave->data[s_data_len++] = data[1];
		for(i = 0; i < 3; i++)
		{
			ret = sdk_record_read(log_type , package_num * 3 + i, &sci_slave->data[s_data_len + i * log_len], log_len);
			if(ret > 0)
			{
				sdk_log_i("log read success!\r\n");
			}
		}
		s_data_len += 3 * log_len;
	}

	sci_ack(sci_master, &sci_slave->data[0], s_data_len);
}

/******************************************************************************
 * sci_file_transfer().
 * File transfer management. [Called by app.]
 *
 * @param	sci_master	(I) master_sci_struct
 * @return	none
 *****************************************************************************/
static void sci_file_transfer(sci_master_t *sci_master)
{
	uint8_t index = sci_master->sub_command;

	switch(index)
	{
		case SFC_FILE_WRITE_START:
			sci_file_write_start(sci_master);
			break;
		case SFC_FILE_WRITE_DATA:
			sci_file_write_data(sci_master);
			break;
		case SFC_FILE_WRITE_END:
			sci_file_write_end(sci_master);
			break;
		case SFC_FILE_READ_START:
			sci_file_read_start(sci_master);
			break;
		case SFC_FILE_READ_DATA:
			sci_file_read_data(sci_master);
			break;
		default:
			break;
	}
}

/******************************************************************************
 * sci_receive_analysis().
 * analysis data. [Called by app.]
 *
 * @param	buf	(I) data buffer
 * @param	len	(I) len
 * @return	none
 *****************************************************************************/
static void sci_receive_analysis(uint8_t *buf, uint32_t len)
{
	bool_t end_mark = FALSE;
	uint8_t *buf_tmp = NULL;
	int32_t len_remain = 0, len_tmp = 0;
	sci_master_t *sci_master = NULL;

	if(buf == NULL)
	{
		return;
	}

	buf_tmp = buf;
	len_remain = len;

	while(end_mark != TRUE)
	{
		sci_master = (sci_master_t *)buf_tmp;

		if((sci_master->start_word_h == SCI_START_WORD_H) &&
		   (sci_master->start_word_l == SCI_START_WORD_L))
		{
			len_tmp = sci_master->len + 6;

			if(checksum_check(&sci_master->slave_addr, sci_master->len + 2, \
												buf_tmp + sci_master->len + 4))
			{
				if(SCI_SLAVE_ADDR == sci_master->slave_addr)
				{
					if((sci_master->main_command == SFC_HANDSHAKED_H) &&
					   (sci_master->sub_command  == SFC_HANDSHAKED_L))
					{
						sci_handshaked(sci_master);
					}
					else if(sci_master->main_command == SFC_SET_H)
					{
						sci_set(sci_master);
					}
					else if(sci_master->main_command == SFC_GET_H)
					{
						data_swap(sci_master);
					}
					else if(sci_master->main_command == SFC_UPGRADE_H)
					{
						sci_upgrade(sci_master);
					}
					else if(sci_master->main_command == SFC_FILE_TRANSFER_H)
					{
						sci_file_transfer(sci_master);
					}
					else
					{
						// sdk_log_i("sci invalid command");
					}
				}
				else
				{
					// sdk_log_i("sci invalid address");
				}
			}
			else
			{
				// sdk_log_i("sci's data crc err");
				end_mark = TRUE;
			}
		}
		else
		{
			// 当前两个字节不是0x55 0xaa,移向下一个
			len_tmp = 1;
		}

		buf_tmp += len_tmp;
		len_remain -= len_tmp;

		if((len_remain < SCI_MIN_LEN) || (buf_tmp < (buf + len)))
		{
			end_mark = TRUE;
		}
	}
}
/******************************************************************************
 * sci_receive_start.
 * sci receive start. [Called by app.]
 *
 * @param	none
 * @param	none
 *****************************************************************************/
/*
uint16_t sci_receive_start(uint8_t port, uint8_t *buff, uint32_t timeout_ms)
{
	uint16_t len;

	len = sdk_uart_read(port, buff, 1, timeout_ms);
	if(len > 0)
	{
		if(buff[0] == SCI_START_WORD_H)
		{
			len = sdk_uart_read(port, buff + 1, 1, timeout_ms);
			if(len > 0)
			{
				if(buff[1] == SCI_START_WORD_L)
				{
					len = sdk_uart_read(port, buff + 2, 2, timeout_ms);
				}
				else
				{
					len = 0;
				}
			}
		}
		else
		{
			len = 0;
		}
	}
	return len;
}
*/
/******************************************************************************
 * sci_receive.
 * sci receive. [Called by app.]
 *
 * @param	none
 * @param	none
 *****************************************************************************/
/*
uint8_t sci_receive(uint8_t port, uint8_t *buff, uint32_t len, uint32_t timeout_ms)
{
	uint8_t length;
	uint8_t need_recevice_len;

	length = sci_receive_start(port, buff, timeout_ms);
	if(length > 0)
	{
		need_recevice_len = buff[INDEX_SCI_DATA_LEN] + CRC16_LEN + INDEX_SCI_DATA_BUFF;
		if(need_recevice_len <= len)
		{
			length = sdk_uart_read(port, buff + INDEX_SCI_DATA_BUFF, buff[INDEX_SCI_DATA_LEN] + CRC16_LEN, timeout_ms);
			if(length > 0)
			{
				length += INDEX_SCI_DATA_BUFF;
			}
		}
		else
		{
			length = 0;
		}
	}
	return length;
}
*/
/******************************************************************************
 * thread_sci_mcu1(*argument).
 * sci receive and ack. [Called by app.]
 *
 * @param	none
 * @param	none
 *****************************************************************************/
void thread_sci_mcu1(void *argument)
{
	uint8_t len = 0;

	while(1)
	{
		len = sdk_uart_read(SCI_PORT, sci_read_buf, SCI_BUF_SIZE, 100);
		if(len > 0)
		{
			sci_receive_analysis(sci_read_buf, len);
		}
		// sdk_delay_ms(3);
	}
}

/******************************************************************************
* End of module
******************************************************************************/
