/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     pcsc_diag.c
  * @brief    pcs cabinet diagnostic module
  * @company  SOFARSOLAR
  * @author   ZHH
  * @note
  * @version  V02
  * @date     2023/05/19
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "app_dido.h"
#include "array.h"
#include "csu_data.h"
#include "diag_manage.h"
#include "measure.h"
#include "pcs.h"
#include "pcsc_diag.h"
#include "device.h"
#include "can1_bus.h"
#include "pcs_sequence.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
bool_t fault_csu_board_otw;
bool_t fault_ac_tank_otw;
bool_t fault_csu_board_otp;
bool_t fault_ac_tank_otp;
bool_t fault_csu_board_utw;
bool_t fault_ac_tank_utw;
bool_t fault_csu_board_ntc;
bool_t fault_ac_tank_ntc;

bool_t fault_water_leak;
bool_t fault_door_unlock;
bool_t fault_ac_spd_fail;
bool_t fault_grid_tied_pos;
bool_t fault_pcsc_fan1;
bool_t fault_pcsc_fan2;
bool_t fault_iso_dev_fault;
bool_t fault_iso_fault;
bool_t fault_cmu_fault;
bool_t fault_remote_epo;

bool_t fault_pcsm_ac_breaker[PCSM_NUMS];

bool_t fault_pcsm_can1[PCSM_NUMS];

bool_t fault_metering_meter;
bool_t fault_backflow_meter;
bool_t fault_microcomputer;
bool_t fault_dehumidifier;
bool_t fault_measure_control;
bool_t fault_model_read;
bool_t fault_anti_backflow;

bool_t fault_sts_sw_pos;
bool_t fault_bypass_fault;
bool_t fault_spd1_fail;
bool_t fault_spd2_fail;
bool_t fault_qf1_fail;
bool_t fault_meter2;
bool_t fault_meter3[METERING_METER3_MAX_NUM];
bool_t fault_pv_meter[PV_METER_MAX_NUM];

bool_t fault_grid_rs_ovw;
bool_t fault_grid_st_ovw;
bool_t fault_grid_tr_ovw;
bool_t fault_grid_rs_uvw;
bool_t fault_grid_st_uvw;
bool_t fault_grid_tr_uvw;
bool_t fault_grid_r_ocw;
bool_t fault_grid_s_ocw;
bool_t fault_grid_t_ocw;
bool_t fault_grid_ofw;
bool_t fault_grid_ufw;
bool_t fault_pcs_rs_ovw;
bool_t fault_pcs_st_ovw;
bool_t fault_pcs_tr_ovw;
bool_t fault_pcs_rs_uvw;
bool_t fault_pcs_st_uvw;

bool_t fault_pcs_tr_uvw;
bool_t fault_dc1_ovw;
bool_t fault_dc2_ovw;
bool_t fault_dc1_uvw;
bool_t fault_dc2_uvw;

bool_t trigger_diag[DIAG_NUM_MAX];
bool_t trigger_comm_diag[PCSM_NUMS];
bool_t trigger_fuse_diag[PCSM_NUMS];
bool_t trigger_model_read;
bool_t trigger_model_read_fault_diag;
bool_t trigger_anti_backflow_diag;

bool_t clear_loss_info;

int16_t set_otw = 700;
int16_t set_otp = 750;
int16_t set_utw = -350;

int16_t heart_ref;
uint16_t pre_fault5;
int8_t model_read_count;

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/
static bool_t ac_breaker_fault_check(float32_t v_grid, int16_t v_pcsm);
static bool_t ac_breaker_fault_reset(float32_t v_grid, int16_t v_pcsm);

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/
/******************************************************************************
 * pcsc_diag_init().
 * init diagnosis of all modules. [Called by slow task group.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void pcsc_diag_init(void)
{
	uint8_t index;

	clear_struct_data((uint8_t*)&trigger_comm_diag[0], sizeof(trigger_comm_diag));
	clear_struct_data((uint8_t*)&trigger_diag[0], sizeof(trigger_diag));

	heart_ref = 1;
	pre_fault5 = array.pcsc.pcsc_data.fault.fault5.all;

	for(index = 0; index < PCSM_NUMS; index++)
	{
		trigger_fuse_diag[index] = FALSE;
	}

	for(index = 0; (index < array.pcsc.pcsc_ctrl.pcsm_nums_set) && (index < PCSM_NUMS); index++)
	{
		trigger_comm_diag[index] = TRUE;
	}
	trigger_model_read = FALSE;
	model_read_count = 0;
	pcs_model_init_ok = FALSE;
	pcs_model_refresh_ok = FALSE;
	power_magic_init_ok = FALSE;
	trigger_anti_backflow_diag = FALSE;

	clear_fault();
}

/******************************************************************************
 * diag_switch_onoff().
 * diag switch on/off. [Called by slow task group.]
 *
 * @param fault_array (I) fault list
 * @param value (I) on or off
 * @return none
 *****************************************************************************/
void diag_switch_onoff(uint8_t *fault_array, bool_t value)
{
	uint8_t i;
	uint8_t index = 0;

	for(i = 0; (i < DIAG_ARRAY_SIZE) && (index != 0xFF); i++)
	{
		index = fault_array[i];
		if(index != 0xFF)
		{
			trigger_diag[index] = value;
		}
	}
}

/******************************************************************************
 * pcsc_other_diag_init().
 * init diagnosis of all modules. [Called by slow task group.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void pcsc_other_diag_init(void)
{
	uint8_t *fault_array;

	if(product_info.model_num == POWER_MAGIC_690V)
	{
		if((ONE_STORAGE_TANK == array.pcsc.pcsc_ctrl.scenario_setting) || \
			(ONE_STORAGE_TANK_XIAOJU_1_2 == array.pcsc.pcsc_ctrl.scenario_setting))
		{
			fault_array = &one_storage_tank_690v[0];
			di_mask[SYS_STATE_WORD_1] = &one_storage_tank_690v_di[SYS_STATE_WORD_1];
			di_mask[SYS_STATE_WORD_2] = &one_storage_tank_690v_di[SYS_STATE_WORD_2];
		}
		else
		{
			fault_array = &standard_scenario_690v[0];
			di_mask[SYS_STATE_WORD_1] = &standard_scenario_690v_di[SYS_STATE_WORD_1];
			di_mask[SYS_STATE_WORD_2] = &standard_scenario_690v_di[SYS_STATE_WORD_2];
		}
	}
	else
	{
		if((ONE_STORAGE_TANK == array.pcsc.pcsc_ctrl.scenario_setting) || \
			(ONE_STORAGE_TANK_XIAOJU_1_2 == array.pcsc.pcsc_ctrl.scenario_setting))
		{
			fault_array = &one_storage_tank_400v[0];
			di_mask[SYS_STATE_WORD_1] = &one_storage_tank_400v_di[SYS_STATE_WORD_1];
			di_mask[SYS_STATE_WORD_2] = &one_storage_tank_400v_di[SYS_STATE_WORD_2];
		}
		else if(ONLY_COMBINER_CABINET == array.pcsc.pcsc_ctrl.scenario_setting)
		{
			fault_array = &only_combiner_cabinet_400v[0];
			di_mask[SYS_STATE_WORD_1] = &only_combiner_cabinet_400v_di[SYS_STATE_WORD_1];
			di_mask[SYS_STATE_WORD_2] = &only_combiner_cabinet_400v_di[SYS_STATE_WORD_2];
		}
//		else if(COMBINER_STORAGE == array.pcsc.pcsc_ctrl.scenario_setting)
//		{
//			fault_array = &combiner_storage_400v[0];
//			di_mask[SYS_STATE_WORD_1] = &combiner_storage_400v_di[SYS_STATE_WORD_1];
//			di_mask[SYS_STATE_WORD_2] = &combiner_storage_400v_di[SYS_STATE_WORD_2];
//		}
		else
		{
			fault_array = &standard_scenario_400v[0];
			di_mask[SYS_STATE_WORD_1] = &standard_scenario_400v_di[SYS_STATE_WORD_1];
			di_mask[SYS_STATE_WORD_2] = &standard_scenario_400v_di[SYS_STATE_WORD_2];
		}
	}
	// enable DI fault diagnostic
	diag_switch_onoff(fault_array, TRUE);
}

/******************************************************************************
 * ntc_fail_check().
 * check ntc whether failed. [Called by diag task group.]
 *
 * @param  ntc_temp (I) ntc temp
 * @return result   (O) if ntc failed, output true, otherwise false
 *****************************************************************************/
bool_t ntc_fail_check(int16_t ntc_temp)
{
	bool_t result = FALSE;

	if(ntc_temp > NTC_TEMP_MAX_LIMIT)
	{
		result = TRUE;
	}
	else if(ntc_temp < NTC_TEMP_MIN_LIMIT)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * ntc_fail_reset().
 * check ntc whether failed. [Called by diag task group.]
 *
 * @param  ntc_temp (I) ntc temp
 * @return result   (O) if ntc restore, output true, otherwise false
 *****************************************************************************/
bool_t ntc_fail_reset(int16_t ntc_temp)
{
	bool_t result = FALSE;

	if((ntc_temp > (NTC_TEMP_MIN_LIMIT + 50))
		&& (ntc_temp < (NTC_TEMP_MAX_LIMIT - 50)))
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * csu_board_ntc_check().
 * check csu board ntc whether failed. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if csu board ntc failed, output true, otherwise false
 *****************************************************************************/
bool_t csu_board_ntc_check(void)
{
	bool_t result = FALSE;

	result = ntc_fail_check(array.pcsc.pcsc_data.var.t_board);

	return result;
}

/******************************************************************************
 * csu_board_ntc_reset().
 * check csu board ntc whether restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if csu board ntc restored, output true, otherwise false
 *****************************************************************************/
bool_t csu_board_ntc_reset(void)
{
	bool_t result = FALSE;

	result = ntc_fail_reset(array.pcsc.pcsc_data.var.t_board);

	return result;
}

/******************************************************************************
 * ac_tank_ntc_check().
 * check ac tank ntc whether failed. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if ac tank ntc failed, output true, otherwise false
 *****************************************************************************/
bool_t ac_tank_ntc_check(void)
{
	bool_t result = FALSE;

	result = ntc_fail_check(array.pcsc.pcsc_data.var.t_ac_fuse);

	return result;
}

/******************************************************************************
 * ac_tank_ntc_reset().
 * check csu board ntc whether restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if ac tank ntc restored, output true, otherwise false
 *****************************************************************************/
bool_t ac_tank_ntc_reset(void)
{
	bool_t result = FALSE;

	result = ntc_fail_reset(array.pcsc.pcsc_data.var.t_ac_fuse);

	return result;
}

/******************************************************************************
 * water_leak_check().
 * check water leakage. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if water leaked, output true, otherwise false
 *****************************************************************************/
bool_t water_leak_check(void)
{
	bool_t result = FALSE;

	if(array.pcsc.pcsc_data.state.state1.bit.water_leak)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * water_leak_reset().
 * check water leakage whether restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if water leak restored, output true, otherwise false
 *****************************************************************************/
bool_t water_leak_reset(void)
{
	bool_t result = FALSE;

	if(!array.pcsc.pcsc_data.state.state1.bit.water_leak)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * door_unlock_check().
 * check door unlock. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if door unlocked, output true, otherwise false
 *****************************************************************************/
bool_t door_unlock_check(void)
{
	bool_t result = FALSE;

	if(array.pcsc.pcsc_data.state.state1.bit.door_unlock)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * door_unlock_reset().
 * check door unlock whether restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if door unlock restored, output true, otherwise false
 *****************************************************************************/
bool_t door_unlock_reset(void)
{
	bool_t result = FALSE;

	if(!array.pcsc.pcsc_data.state.state1.bit.door_unlock)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * ac_spd_check().
 * check ac spd. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if ac spd opened, output true, otherwise false
 *****************************************************************************/
bool_t ac_spd_check(void)
{
	bool_t result = FALSE;

	if(array.pcsc.pcsc_data.state.state1.bit.ac_spd_fail)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * dc2_spd_reset().
 * check dc2 spd whether restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if dc2 spd restored, output true, otherwise false
 *****************************************************************************/
bool_t ac_spd_reset(void)
{
	bool_t result = FALSE;

	if(!array.pcsc.pcsc_data.state.state1.bit.ac_spd_fail)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * grid_tied_pos_check().
 * check grid-tied switch on failed. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if grid-tied switch on failed, output true, otherwise false
 *****************************************************************************/
bool_t grid_tied_pos_check(void)
{
	bool_t result = FALSE;

	// ac on cmd, but ac breaker in off position
	// ac off cmd, but ac breaker in on position
	if(grid_tied_sw_on_cmd && \
	((!array.pcsc.pcsc_data.state.state1.bit.grid_tied_on) || \
	(array.pcsc.pcsc_data.state.state1.bit.grid_tied_off)))
	{
		result = TRUE;
	}
	else if(grid_tied_sw_off_cmd && \
	((array.pcsc.pcsc_data.state.state1.bit.grid_tied_on) || \
	(!array.pcsc.pcsc_data.state.state1.bit.grid_tied_off)))
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * grid_tied_pos_reset().
 * check grid-tied on whether restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if grid-tied on restored, output true, otherwise false
 *****************************************************************************/
bool_t grid_tied_pos_reset(void)
{
	bool_t result = FALSE;

	// ac on cmd, ac breaker in on position
	// ac off cmd, ac breaker in off position
	if(grid_tied_sw_on_cmd && \
	((array.pcsc.pcsc_data.state.state1.bit.grid_tied_on) && \
	(!array.pcsc.pcsc_data.state.state1.bit.grid_tied_off)))
	{
		result = TRUE;
	}
	else if(grid_tied_sw_off_cmd && \
	((!array.pcsc.pcsc_data.state.state1.bit.grid_tied_on) && \
	(array.pcsc.pcsc_data.state.state1.bit.grid_tied_off)))
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * pcsc_fan1_check().
 * check pcsc fan1. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if pcsc fan fails, output true, otherwise false
 *****************************************************************************/
bool_t pcsc_fan1_check(void)
{
	bool_t result = FALSE;
	if(array.pcsc.pcsc_ctrl.cmd.bit.fan_ctrl && array.pcsc.pcsc_data.state.state1.bit.fan1_status)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * pcsc_fan1_reset().
 * check pcsc fan1 restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if pcsc fan restored, output true, otherwise false
 *****************************************************************************/
bool_t pcsc_fan1_reset(void)
{
	bool_t result = FALSE;

	if(!array.pcsc.pcsc_data.state.state1.bit.fan1_status)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * pcsc_fan2_check().
 * check pcsc fan2. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if pcsc fan fails, output true, otherwise false
 *****************************************************************************/
bool_t pcsc_fan2_check(void)
{
	bool_t result = FALSE;
	if(array.pcsc.pcsc_ctrl.cmd.bit.fan_ctrl && array.pcsc.pcsc_data.state.state1.bit.fan2_status)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * pcsc_fan2_reset().
 * check pcsc fan2 restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if pcsc fan restored, output true, otherwise false
 *****************************************************************************/
bool_t pcsc_fan2_reset(void)
{
	bool_t result = FALSE;

	if(!array.pcsc.pcsc_data.state.state1.bit.fan2_status)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * iso_dev_fail_check().
 * check iso dev fail. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if iso warned, output true, otherwise false
 *****************************************************************************/
bool_t iso_dev_fail_check(void)
{
	bool_t result = FALSE;

	if(array.pcsc.pcsc_data.state.state1.bit.iso_dev_fail)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * iso_dev_fail_reset().
 * check iso dev fail restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if iso warn restored, output true, otherwise false
 *****************************************************************************/
bool_t iso_dev_fail_reset(void)
{
	bool_t result = FALSE;

	if(!array.pcsc.pcsc_data.state.state1.bit.iso_dev_fail)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * cmu_fault_check().
 * check cmu_fault. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if cmu fault, output true, otherwise false
 *****************************************************************************/
bool_t cmu_fault_check(void)
{
	bool_t result = FALSE;

	if(array.pcsc.pcsc_data.state.state1.bit.cmu_fault)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * cmu_fault_reset().
 * check cmu_fault restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if cmu fault restored, output true, otherwise false
 *****************************************************************************/
bool_t cmu_fault_reset(void)
{
	bool_t result = FALSE;

	if(!array.pcsc.pcsc_data.state.state1.bit.cmu_fault)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * remote_epo_check().
 * check remote epo. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if remote epo warned, output true, otherwise false
 *****************************************************************************/
bool_t remote_epo_check(void)
{
	bool_t result = FALSE;

	if(array.pcsc.pcsc_data.state.state2.bit.remote_epo)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * remote_epo_reset().
 * check remote epo restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if remote epo warn restored, output true, otherwise false
 *****************************************************************************/
bool_t remote_epo_reset(void)
{
	bool_t result = FALSE;

	if(!array.pcsc.pcsc_data.state.state2.bit.remote_epo)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * iso_fault_check().
 * check iso fault. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if iso failed, output true, otherwise false
 *****************************************************************************/
bool_t iso_fault_check(void)
{
	bool_t result = FALSE;

	if(array.pcsc.pcsc_data.state.state1.bit.iso_fault)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * iso_fault_reset().
 * check iso fault restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if iso failed, output true, otherwise false
 *****************************************************************************/
bool_t iso_fault_reset(void)
{
	bool_t result = FALSE;

	if(!array.pcsc.pcsc_data.state.state1.bit.iso_fault)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * ac_breaker_fault_check().
 * Check AC breaker fault. [Called by diag task group.]
 *
 * @param  v_grid        (I) Grid side voltage of the fuse (unit V)
 * @param  v_pcsm        (I) PCSM side voltage of the fuse (unit 0.1V)
 * @return result        (O) if fuse open, output true, otherwise false
 *****************************************************************************/
static bool_t ac_breaker_fault_check(float32_t v_grid, int16_t v_pcsm)
{
	bool_t result = FALSE;
	int16_t grid_volt;
	int16_t fuse_volt;

	grid_volt = v_grid * PARAMETER_ACCURACY_MAGNIFICATION_6;

	if(grid_volt > v_pcsm)
	{
		fuse_volt = grid_volt - v_pcsm;
	}
	else
	{
		fuse_volt = v_pcsm - grid_volt;
	}

	if (fuse_volt >= AC_BREAKER_FAULT_VALUE)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * ac_breaker_fault_reset().
 * AC breaker fault restored. [Called by diag task group.]
 *
 * @param  v_grid        (I) Grid side voltage of the fuse (unit V)
 * @param  v_pcsm        (I) PCSM side voltage of the fuse (unit 0.1V)
 * @return result        (O) if fuse close, output true, otherwise false
 *****************************************************************************/
static bool_t ac_breaker_fault_reset(float32_t v_grid, int16_t v_pcsm)
{
	bool_t result = FALSE;
	int16_t grid_volt;
	int16_t fuse_volt;

	grid_volt = v_grid * PARAMETER_ACCURACY_MAGNIFICATION_6;

	if(grid_volt > v_pcsm)
	{
		fuse_volt = grid_volt - v_pcsm;
	}
	else
	{
		fuse_volt = v_pcsm - grid_volt;
	}

	if (fuse_volt <= AC_BREAKER_FAULT_VALUE)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * pcsm1_ac_breaker_check().
 * Check pcsm1 AC fuse phase R. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if fuse open, output true, otherwise false
 *****************************************************************************/
bool_t pcsm1_ac_breaker_check(void)
{
	bool_t result = FALSE;
	result = (ac_breaker_fault_check(g_ac_signal[VGRD_R].rms, array.pcsc.pcsc_data.pcsm_data[0].var.grid_volt_r))    ||
				(ac_breaker_fault_check(g_ac_signal[VGRD_S].rms, array.pcsc.pcsc_data.pcsm_data[0].var.grid_volt_s)) ||
				(ac_breaker_fault_check(g_ac_signal[VGRD_T].rms, array.pcsc.pcsc_data.pcsm_data[0].var.grid_volt_t));
	return result;
}

/******************************************************************************
 * pcsm1_ac_breaker_reset().
 * Check pcsm1 AC fuse phase R. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if fuse close, output true, otherwise false
 *****************************************************************************/
bool_t pcsm1_ac_breaker_reset(void)
{
	bool_t result = FALSE;
	result = (ac_breaker_fault_reset(g_ac_signal[VGRD_R].rms, array.pcsc.pcsc_data.pcsm_data[0].var.grid_volt_r))    ||
				(ac_breaker_fault_reset(g_ac_signal[VGRD_S].rms, array.pcsc.pcsc_data.pcsm_data[0].var.grid_volt_s)) ||
				(ac_breaker_fault_reset(g_ac_signal[VGRD_T].rms, array.pcsc.pcsc_data.pcsm_data[0].var.grid_volt_t));
	return result;
}


/******************************************************************************
 * pcsm2_ac_breaker_check().
 * Check pcsm2 AC fuse phase R. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if fuse open, output true, otherwise false
 *****************************************************************************/
bool_t pcsm2_ac_breaker_check(void)
{
	bool_t result = FALSE;
	result = (ac_breaker_fault_check(g_ac_signal[VGRD_R].rms, array.pcsc.pcsc_data.pcsm_data[1].var.grid_volt_r))    ||
				(ac_breaker_fault_check(g_ac_signal[VGRD_S].rms, array.pcsc.pcsc_data.pcsm_data[1].var.grid_volt_s)) ||
				(ac_breaker_fault_check(g_ac_signal[VGRD_T].rms, array.pcsc.pcsc_data.pcsm_data[1].var.grid_volt_t));
	return result;
}

/******************************************************************************
 * pcsm2_ac_breaker_reset().
 * Check pcsm2 AC fuse phase R. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if fuse close, output true, otherwise false
 *****************************************************************************/
bool_t pcsm2_ac_breaker_reset(void)
{
	bool_t result = FALSE;
	result = (ac_breaker_fault_reset(g_ac_signal[VGRD_R].rms, array.pcsc.pcsc_data.pcsm_data[1].var.grid_volt_r))    ||
				(ac_breaker_fault_reset(g_ac_signal[VGRD_S].rms, array.pcsc.pcsc_data.pcsm_data[1].var.grid_volt_s)) ||
				(ac_breaker_fault_reset(g_ac_signal[VGRD_T].rms, array.pcsc.pcsc_data.pcsm_data[1].var.grid_volt_t));
	return result;
}


/******************************************************************************
 * pcsm3_ac_breaker_check().
 * Check pcsm3 AC fuse phase R. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if fuse open, output true, otherwise false
 *****************************************************************************/
bool_t pcsm3_ac_breaker_check(void)
{
	bool_t result = FALSE;
	result = (ac_breaker_fault_check(g_ac_signal[VGRD_R].rms, array.pcsc.pcsc_data.pcsm_data[2].var.grid_volt_r))    ||
				(ac_breaker_fault_check(g_ac_signal[VGRD_S].rms, array.pcsc.pcsc_data.pcsm_data[2].var.grid_volt_s)) ||
				(ac_breaker_fault_check(g_ac_signal[VGRD_T].rms, array.pcsc.pcsc_data.pcsm_data[2].var.grid_volt_t));
	return result;
}

/******************************************************************************
 * pcsm3_ac_breaker_reset().
 * Check pcsm3 AC fuse phase R. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if fuse close, output true, otherwise false
 *****************************************************************************/
bool_t pcsm3_ac_breaker_reset(void)
{
	bool_t result = FALSE;
	result = (ac_breaker_fault_reset(g_ac_signal[VGRD_R].rms, array.pcsc.pcsc_data.pcsm_data[2].var.grid_volt_r))    ||
				(ac_breaker_fault_reset(g_ac_signal[VGRD_S].rms, array.pcsc.pcsc_data.pcsm_data[2].var.grid_volt_s)) ||
				(ac_breaker_fault_reset(g_ac_signal[VGRD_T].rms, array.pcsc.pcsc_data.pcsm_data[2].var.grid_volt_t));
	return result;
}

/******************************************************************************
 * pcsm4_ac_breaker_check().
 * Check pcsm4 AC fuse phase R. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if fuse open, output true, otherwise false
 *****************************************************************************/
bool_t pcsm4_ac_breaker_check(void)
{
	bool_t result = FALSE;
	result = (ac_breaker_fault_check(g_ac_signal[VGRD_R].rms, array.pcsc.pcsc_data.pcsm_data[3].var.grid_volt_r))    ||
				(ac_breaker_fault_check(g_ac_signal[VGRD_S].rms, array.pcsc.pcsc_data.pcsm_data[3].var.grid_volt_s)) ||
				(ac_breaker_fault_check(g_ac_signal[VGRD_T].rms, array.pcsc.pcsc_data.pcsm_data[3].var.grid_volt_t));
	return result;
}

/******************************************************************************
 * pcsm4_ac_breaker_reset().
 * Check pcsm4 AC fuse phase R. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if fuse close, output true, otherwise false
 *****************************************************************************/
bool_t pcsm4_ac_breaker_reset(void)
{
	bool_t result = FALSE;
	result = (ac_breaker_fault_reset(g_ac_signal[VGRD_R].rms, array.pcsc.pcsc_data.pcsm_data[3].var.grid_volt_r))    ||
				(ac_breaker_fault_reset(g_ac_signal[VGRD_S].rms, array.pcsc.pcsc_data.pcsm_data[3].var.grid_volt_s)) ||
				(ac_breaker_fault_reset(g_ac_signal[VGRD_T].rms, array.pcsc.pcsc_data.pcsm_data[3].var.grid_volt_t));
	return result;
}

/******************************************************************************
 * pcsm5_ac_breaker_check().
 * Check pcsm5 AC fuse phase R. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if fuse open, output true, otherwise false
 *****************************************************************************/
bool_t pcsm5_ac_breaker_check(void)
{
	bool_t result = FALSE;
	result = (ac_breaker_fault_check(g_ac_signal[VGRD_R].rms, array.pcsc.pcsc_data.pcsm_data[4].var.grid_volt_r))    ||
				(ac_breaker_fault_check(g_ac_signal[VGRD_S].rms, array.pcsc.pcsc_data.pcsm_data[4].var.grid_volt_s)) ||
				(ac_breaker_fault_check(g_ac_signal[VGRD_T].rms, array.pcsc.pcsc_data.pcsm_data[4].var.grid_volt_t));
	return result;
}

/******************************************************************************
 * pcsm5_ac_breaker_reset().
 * Check pcsm5 AC fuse phase R. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if fuse close, output true, otherwise false
 *****************************************************************************/
bool_t pcsm5_ac_breaker_reset(void)
{
	bool_t result = FALSE;
	result = (ac_breaker_fault_reset(g_ac_signal[VGRD_R].rms, array.pcsc.pcsc_data.pcsm_data[4].var.grid_volt_r))    ||
				(ac_breaker_fault_reset(g_ac_signal[VGRD_S].rms, array.pcsc.pcsc_data.pcsm_data[4].var.grid_volt_s)) ||
				(ac_breaker_fault_reset(g_ac_signal[VGRD_T].rms, array.pcsc.pcsc_data.pcsm_data[4].var.grid_volt_t));
	return result;
}

/******************************************************************************
 * pcsm6_ac_breaker_check().
 * Check pcsm6 AC fuse phase R. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if fuse open, output true, otherwise false
 *****************************************************************************/
bool_t pcsm6_ac_breaker_check(void)
{
	bool_t result = FALSE;
	result = (ac_breaker_fault_check(g_ac_signal[VGRD_R].rms, array.pcsc.pcsc_data.pcsm_data[5].var.grid_volt_r))    ||
				(ac_breaker_fault_check(g_ac_signal[VGRD_S].rms, array.pcsc.pcsc_data.pcsm_data[5].var.grid_volt_s)) ||
				(ac_breaker_fault_check(g_ac_signal[VGRD_T].rms, array.pcsc.pcsc_data.pcsm_data[5].var.grid_volt_t));
	return result;
}

/******************************************************************************
 * pcsm6_ac_breaker_reset().
 * Check pcsm6 AC fuse phase R. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if fuse close, output true, otherwise false
 *****************************************************************************/
bool_t pcsm6_ac_breaker_reset(void)
{
	bool_t result = FALSE;
	result = (ac_breaker_fault_reset(g_ac_signal[VGRD_R].rms, array.pcsc.pcsc_data.pcsm_data[5].var.grid_volt_r))    ||
				(ac_breaker_fault_reset(g_ac_signal[VGRD_S].rms, array.pcsc.pcsc_data.pcsm_data[5].var.grid_volt_s)) ||
				(ac_breaker_fault_reset(g_ac_signal[VGRD_T].rms, array.pcsc.pcsc_data.pcsm_data[5].var.grid_volt_t));
	return result;
}

/******************************************************************************
 * pcsm1_can1_check().
 * Check pcsm1 can1 connect. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if can1 disconnect, output true, otherwise false
 *****************************************************************************/
bool_t pcsm1_can1_check(void)
{
	bool_t result = FALSE;

	if(heart_pcs[0].online == FALSE)
	{
		result = TRUE;
	}
	return result;
}

/******************************************************************************
 * pcsm1_can1_reset().
 * Reset pcsm1 can1 connect. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if can1 connect, output true, otherwise false
 *****************************************************************************/
bool_t pcsm1_can1_reset(void)
{
	bool_t result = FALSE;

	if(heart_pcs[0].online == TRUE)
	{
		result = TRUE;
	}
	return result;
}

/******************************************************************************
 * pcsm2_can1_check().
 * Check pcsm2 can1 connect. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if can1 disconnect, output true, otherwise false
 *****************************************************************************/
bool_t pcsm2_can1_check(void)
{
	bool_t result = FALSE;

	if(heart_pcs[1].online == FALSE)
	{
		result = TRUE;
	}
	return result;
}

/******************************************************************************
 * pcsm2_can1_reset().
 * Reset pcsm2 can1 connect. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if can1 connect, output true, otherwise false
 *****************************************************************************/
bool_t pcsm2_can1_reset(void)
{
	bool_t result = FALSE;

	if(heart_pcs[1].online == TRUE)
	{
		result = TRUE;
	}
	return result;
}

/******************************************************************************
 * pcsm3_can1_check().
 * Check pcsm3 can1 connect. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if can1 disconnect, output true, otherwise false
 *****************************************************************************/
bool_t pcsm3_can1_check(void)
{
	bool_t result = FALSE;

	if(heart_pcs[2].online == FALSE)
	{
		result = TRUE;
	}
	return result;
}

/******************************************************************************
 * pcsm3_can1_reset().
 * Reset pcsm3 can1 connect. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if can1 connect, output true, otherwise false
 *****************************************************************************/
bool_t pcsm3_can1_reset(void)
{
	bool_t result = FALSE;

	if(heart_pcs[2].online == TRUE)
	{
		result = TRUE;
	}
	return result;
}

/******************************************************************************
 * pcsm4_can1_check().
 * Check pcsm4 can1 connect. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if can1 disconnect, output true, otherwise false
 *****************************************************************************/
bool_t pcsm4_can1_check(void)
{
	bool_t result = FALSE;

	if(heart_pcs[3].online == FALSE)
	{
		result = TRUE;
	}
	return result;
}

/******************************************************************************
 * pcsm4_can1_reset().
 * Reset pcsm4 can1 connect. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if can1 connect, output true, otherwise false
 *****************************************************************************/
bool_t pcsm4_can1_reset(void)
{
	bool_t result = FALSE;

	if(heart_pcs[3].online == TRUE)
	{
		result = TRUE;
	}
	return result;
}

/******************************************************************************
 * pcsm5_can1_check().
 * Check pcsm5 can1 connect. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if can1 disconnect, output true, otherwise false
 *****************************************************************************/
bool_t pcsm5_can1_check(void)
{
	bool_t result = FALSE;

	if(heart_pcs[4].online == FALSE)
	{
		result = TRUE;
	}
	return result;
}

/******************************************************************************
 * pcsm5_can1_reset().
 * Reset pcsm5 can1 connect. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if can1 connect, output true, otherwise false
 *****************************************************************************/
bool_t pcsm5_can1_reset(void)
{
	bool_t result = FALSE;

	if(heart_pcs[4].online == TRUE)
	{
		result = TRUE;
	}
	return result;
}

/******************************************************************************
 * pcsm6_can1_check().
 * Check pcsm6 can1 connect. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if can1 disconnect, output true, otherwise false
 *****************************************************************************/
bool_t pcsm6_can1_check(void)
{
	bool_t result = FALSE;

	if(heart_pcs[5].online == FALSE)
	{
		result = TRUE;
	}
	return result;
}

/******************************************************************************
 * pcsm6_can1_reset().
 * Reset pcsm6 can1 connect. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if can1 connect, output true, otherwise false
 *****************************************************************************/
bool_t pcsm6_can1_reset(void)
{
	bool_t result = FALSE;

	if(heart_pcs[5].online == TRUE)
	{
		result = TRUE;
	}
	return result;
}

/******************************************************************************
 * model_read_check().
 * ???. [Called by app().]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
bool_t model_read_check(void)
{
	return g_model_read_fail;
}

/******************************************************************************
 * model_read_reset().
 * ???. [Called by app().]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
bool_t model_read_reset(void)
{
	return !g_model_read_fail;
}

/******************************************************************************
 * sts_sw_pos_check().
 * check sts switch on failed. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if sts switch on failed, output true, otherwise false
 *****************************************************************************/
bool_t sts_sw_pos_check(void)
{
	bool_t result = FALSE;

	// ac on cmd, but ac breaker in off position
	// ac off cmd, but ac breaker in on position
	if(sts_sw_on_cmd && \
	((!array.pcsc.pcsc_data.state.state1.bit.sts_sw_on) || \
	(array.pcsc.pcsc_data.state.state1.bit.sts_sw_off)))
	{
		result = TRUE;
	}
	else if(sts_sw_off_cmd && \
	((array.pcsc.pcsc_data.state.state1.bit.sts_sw_on) || \
	(!array.pcsc.pcsc_data.state.state1.bit.sts_sw_off)))
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * sts_sw_pos_reset().
 * check sts switch on whether restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if sts switch on restored, output true, otherwise false
 *****************************************************************************/
bool_t sts_sw_pos_reset(void)
{
	bool_t result = FALSE;

	// ac on cmd, ac breaker in on position
	// ac off cmd, ac breaker in off position
	if(sts_sw_on_cmd && \
	((array.pcsc.pcsc_data.state.state1.bit.sts_sw_on) && \
	(!array.pcsc.pcsc_data.state.state1.bit.sts_sw_off)))
	{
		result = TRUE;
	}
	else if(sts_sw_off_cmd && \
	((!array.pcsc.pcsc_data.state.state1.bit.sts_sw_on) && \
	(array.pcsc.pcsc_data.state.state1.bit.sts_sw_off)))
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * bypass_fault_check().
 * check bypass switch failed. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if bypass switch failed, output true, otherwise false
 *****************************************************************************/
bool_t bypass_fault_check(void)
{
	bool_t result = FALSE;

	if(array.pcsc.pcsc_data.state.state2.bit.qf2_status == \
							array.pcsc.pcsc_data.state.state1.bit.qf3_status)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * bypass_fault_reset().
 * check bypass switch whether restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if bypass switch restored, output true, otherwise false
 *****************************************************************************/
bool_t bypass_fault_reset(void)
{
	bool_t result = FALSE;

	if(array.pcsc.pcsc_data.state.state2.bit.qf2_status != \
							array.pcsc.pcsc_data.state.state1.bit.qf3_status)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * spd1_status_check().
 * check spd1 status. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if spd1 failed, output true, otherwise false
 *****************************************************************************/
bool_t spd1_status_check(void)
{
	bool_t result = FALSE;

	if(array.pcsc.pcsc_data.state.state1.bit.spd1_fail)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * spd1_status_reset().
 * check spd1 status whether restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if spd1 restored, output true, otherwise false
 *****************************************************************************/
bool_t spd1_status_reset(void)
{
	bool_t result = FALSE;

	if(!array.pcsc.pcsc_data.state.state1.bit.spd1_fail)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * spd2_status_check().
 * check spd2 status. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if spd2 failed, output true, otherwise false
 *****************************************************************************/
bool_t spd2_status_check(void)
{
	bool_t result = FALSE;

	if(array.pcsc.pcsc_data.state.state1.bit.spd2_fail)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * spd2_status_reset().
 * check spd2 status whether restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if spd2 restored, output true, otherwise false
 *****************************************************************************/
bool_t spd2_status_reset(void)
{
	bool_t result = FALSE;

	if(!array.pcsc.pcsc_data.state.state1.bit.spd2_fail)
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * qf1_status_check().
 * check qf1 status. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if qf1 failed, output true, otherwise false
 *****************************************************************************/
bool_t qf1_status_check(void)
{
	bool_t result = FALSE;

	if((array.pcsc.pcsc_ctrl.do_ctrl.bit.grid_tied_sw_qf1_on && (!array.pcsc.pcsc_data.state.state2.bit.qf1_status)) || \
		(array.pcsc.pcsc_ctrl.do_ctrl.bit.grid_tied_sw_qf1_off && array.pcsc.pcsc_data.state.state2.bit.qf1_status))
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * qf1_status_reset().
 * check qf1 status whether restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O) if qf1 restored, output true, otherwise false
 *****************************************************************************/
bool_t qf1_status_reset(void)
{
	bool_t result = FALSE;

	if((array.pcsc.pcsc_ctrl.do_ctrl.bit.grid_tied_sw_qf1_on && array.pcsc.pcsc_data.state.state2.bit.qf1_status) || \
		(array.pcsc.pcsc_ctrl.do_ctrl.bit.grid_tied_sw_qf1_off && (!array.pcsc.pcsc_data.state.state2.bit.qf1_status)))
	{
		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * pcsc_fault_update().
 * pcsc faults update. [Called by task group.]
 *
 * @param  none (I)
 * @return none (O)
 *****************************************************************************/
void pcsc_fault_update(void)
{
	pcsc_fault1_t *fault1;
	pcsc_fault2_t *fault2;
	pcsc_fault3_t *fault3;
	pcsc_fault4_t *fault4;

	fault1 = &(array.pcsc.pcsc_data.fault.fault1);
	fault1->bit.csu_board_otw       = fault_csu_board_otw;
	fault1->bit.ac_tank_otw         = fault_ac_tank_otw;
	fault1->bit.csu_board_otp       = fault_csu_board_otp;
	fault1->bit.ac_tank_otp         = fault_ac_tank_otp;
	fault1->bit.csu_board_utw       = fault_csu_board_utw;
	fault1->bit.ac_tank_utw         = fault_ac_tank_utw;
	fault1->bit.csu_board_ntc       = fault_csu_board_ntc;
	fault1->bit.ac_tank_ntc         = fault_ac_tank_ntc;
	fault1->bit.water_leak          = fault_water_leak;
	fault1->bit.door_unlock         = fault_door_unlock;
	fault1->bit.ac_spd_fail         = fault_ac_spd_fail;
	fault1->bit.grid_tied_pos_fault = fault_grid_tied_pos;
	fault1->bit.fan1_fail           = fault_pcsc_fan1;
	fault1->bit.fan2_fail           = fault_pcsc_fan2;
	fault1->bit.iso_dev_fault       = fault_iso_dev_fault;
	fault1->bit.iso_fault           = fault_iso_fault;

	fault2 = &array.pcsc.pcsc_data.fault.fault2;
	fault2->bit.cmu_fault           = fault_cmu_fault;
	fault2->bit.remote_epo          = fault_remote_epo;
	fault2->bit.pcsm1_ac_breaker    = fault_pcsm_ac_breaker[0];
	fault2->bit.pcsm2_ac_breaker    = fault_pcsm_ac_breaker[1];
	fault2->bit.pcsm3_ac_breaker    = fault_pcsm_ac_breaker[2];
	fault2->bit.pcsm4_ac_breaker    = fault_pcsm_ac_breaker[3];
	fault2->bit.pcsm5_ac_breaker    = fault_pcsm_ac_breaker[4];
	fault2->bit.pcsm6_ac_breaker    = fault_pcsm_ac_breaker[5];
	fault2->bit.pcsm1_can1          = fault_pcsm_can1[0];
	fault2->bit.pcsm2_can1          = fault_pcsm_can1[1];
	fault2->bit.pcsm3_can1          = fault_pcsm_can1[2];
	fault2->bit.pcsm4_can1          = fault_pcsm_can1[3];
	fault2->bit.pcsm5_can1          = fault_pcsm_can1[4];
	fault2->bit.pcsm6_can1          = fault_pcsm_can1[5];
	fault2->bit.metering_meter      = fault_metering_meter;
	fault2->bit.backflow_meter      = fault_backflow_meter;

	fault3 = &array.pcsc.pcsc_data.fault.fault3;
	fault3->bit.microcomputer       = fault_microcomputer;
	fault3->bit.dehumidifier        = fault_dehumidifier;
	fault3->bit.measure_control     = fault_measure_control;
	fault3->bit.pcsm_model_err      = fault_model_read;
	fault3->bit.anti_backflow_err   = fault_anti_backflow;
	fault3->bit.sts_sw_pos_fault    = fault_sts_sw_pos;
	fault3->bit.bypass_fault        = fault_bypass_fault;
	fault3->bit.spd1_fail           = fault_spd1_fail;
	fault3->bit.spd2_fail           = fault_spd2_fail;
	fault3->bit.qf1_fail            = fault_qf1_fail;
	fault3->bit.metering_meter_2    = fault_meter2;
	fault3->bit.metering_meter_3_1    = fault_meter3[0];
	fault3->bit.metering_meter_3_2    = fault_meter3[1];
	fault3->bit.metering_meter_3_3    = fault_meter3[2];
	fault3->bit.metering_meter_3_4    = fault_meter3[3];
	fault3->bit.metering_meter_3_5    = fault_meter3[4];

	fault4 = &array.pcsc.pcsc_data.fault.fault4;
	fault4->bit.pv_meter_1            = fault_pv_meter[0];
	fault4->bit.pv_meter_2            = fault_pv_meter[1];
	fault4->bit.pv_meter_3            = fault_pv_meter[2];

	// shutdown_fault used in pcs_onoff state machine to turn off system
	if(fault_csu_board_otp        ||
	   fault_ac_tank_otp          ||
	   fault_water_leak           ||
	   fault_door_unlock          ||
	   fault_grid_tied_pos        ||
	   fault_iso_fault            ||
	   fault_remote_epo)
	{
		shutdown_fault = TRUE;
	}
	else
	{
		shutdown_fault = FALSE;
	}
	// epo fault also used in pcs_onoff state machine to turn off system
	if(fault_remote_epo)
	{
		array.pcsc.pcsc_ctrl.pcsc_on_off = 0;
        array.pcsc.pcsc_ctrl.pcs_run = FALSE;
        array.pcsc.pcsc_ctrl.cmd.all = 0;
	}
}

/******************************************************************************
 * slow_task_model_read().
 * model_read. [Called by task.]
 *
 * @param  none (I)
 * @return none (O)
 *****************************************************************************/
void slow_task_model_read(void)
{
	bool_t comm_status = TRUE;
	uint8_t i;
	list_node_t *node_pcs_tmp = NULL;

	// open model read fault
	trigger_model_read_fault_diag = TRUE;

	if(array.array_data.variable.pcsm_online == 0)
	{
		g_model_read_fail = FALSE;
		return;
	}
	for(i = 0; (i < PCSM_NUMS) && (comm_status == TRUE); i++)
	{
		if((heart_pcs[i].online == TRUE) && (pcs_sn_analysis_success[i] != TRUE))
		{
			comm_status = FALSE;
		}
	}

	if(comm_status)
	{
		node_pcs_tmp = link_list_get_head(&list_pcs);
		model_read_count = 0;
		while(node_pcs_tmp)
		{
			if (array.pcsc.pcsc_data.pcsm_data[node_pcs_tmp->id - 1].constant.rated_power == POWER_MAGIC_690V_POWER_RATED)
			{
				model_read_count++;
			}
			else if (array.pcsc.pcsc_data.pcsm_data[node_pcs_tmp->id - 1].constant.rated_power == POWER_MAGIC_400V_POWER_RATED)
			{
				model_read_count--;
			}
			node_pcs_tmp = node_pcs_tmp->next;
		}

		if(model_read_count == array.array_data.variable.pcsm_online)
		{
			product_info.model_num = POWER_MAGIC_690V;
			g_model_read_fail = FALSE;
			// Before model initializes,
			// determine whether the model init is completed
			if(power_magic_init_ok == FALSE)
			{
				pcs_model_init_ok = TRUE;
			}
			else
			{
				pcs_model_refresh_ok = TRUE;
			}
		}
		else if(model_read_count == -array.array_data.variable.pcsm_online)
		{
			product_info.model_num = POWER_MAGIC_400V;
			g_model_read_fail = FALSE;
			if(power_magic_init_ok == FALSE)
			{
				pcs_model_init_ok = TRUE;
			}
			else
			{
				pcs_model_refresh_ok = TRUE;
			}
		}
		else
		{
			clear_struct_data((uint8_t *)&pcs_sn_analysis_success[0], sizeof(pcs_sn_analysis_success));
			g_model_read_fail = TRUE;
			if(power_magic_init_ok == FALSE)
			{
				pcs_model_init_ok = FALSE;
			}
			else
			{
				pcs_model_refresh_ok = FALSE;
			}
		}
	}
	else
	{
		g_model_read_fail = TRUE;
	}
}

/******************************************************************************
* End of module
******************************************************************************/
