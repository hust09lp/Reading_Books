/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     power_manage.c
  * @brief    Power dispatching management module
  * @company  SOFARSOLAR
  * @author   HH
  * @note
  * @version  V01
  * @date     2023/03/08
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "power_manage.h"
#include "sdk.h"
#include "sdk_core.h"
#include "array.h"
#include "fifo_can.h"
#include "task_manage.h"
#include "pcsc_opt_log.h"
#include "cup_sofar_can.h"
#include "device.h"
#include "can1_bus.h"
#include "ems.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
// 100ms
#define SOC_COMPUTE_BASETIME                                              (100)
// 10 minute
#define SOC_COMPUTE_DETECT_PERIOD                              (1000 * 60 * 10)
// 1 minute
#define ONE_MINUTE_COUNT_100MS                                        (60 * 10)

#define CAN_WAIT_MUTEX_TIME                                                 (1)
#define PLANNING_SCHEDULING_PERIOD                                  (60 * 1000) // ms
#define PLANNING_SCHEDULING_DELAY_ON_TIME                      (20 * 60 * 1000) // ms, 20 minute
#define PLANNING_SCHEDULING_DELAY_ON_TIME_CONUT                (PLANNING_SCHEDULING_DELAY_ON_TIME / PLANNING_SCHEDULING_PERIOD) // ms, 30 minute

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
bool_t trigger_rack_manage   = FALSE;
bool_t trigger_pcsc_ratings  = FALSE;
bool_t trigger_bat_capacity_test;
uint8_t last_cmu_action[CMU_NUMS];
uint16_t soc_compute_detect_count_ref;
uint16_t cmu_loss_delay;
bool_t g_active_power_send;
bool_t g_reactive_power_send;
bool_t trigger_power_resend;
uint8_t g_chg_p_distribution_mode;
uint8_t g_rechargeable_num;
uint8_t g_dch_p_distribution_mode;
uint8_t g_redischargeable_num;

uint16_t g_chg_avilable_cmu = 0;
uint16_t g_dch_avilable_cmu = 0;
int16_t power_allocation_buff[CMU_NUMS];
uint16_t planning_scheduling_delay_on_cnt[CMU_NUMS];
bool_t trigger_plan_scheduler;
bool_t trigger_planning_scheduling_start = 0;

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/
/******************************************************************************
 * power_manage_init().
 * Initialize power dispatching management module. [Called by sw_init()]
 *
 * @param  none (I)
 * @param  none (O)
 * @return none
 *****************************************************************************/
void power_manage_init(void)
{
	uint8_t i;

	trigger_local_ems = FALSE;
	trigger_xiao_ju = FALSE;
	trigger_bat_capacity_test = FALSE;

	trigger_pcsc_ratings  = FALSE;
	trigger_rack_manage   = FALSE;
	// SOC is not configured, AVERAGE_DISTRIBUTION is used by default
	array.pcsc.pcsc_ctrl.power_distribution_mode = AVERAGE_DISTRIBUTION;
	cmu_loss_delay = ONE_MINUTE_COUNT_100MS;

	for(i = 0; i < CMU_NUMS; i++)
	{
		array.cmu[i].sys_status = CMU_SYS_UNKOWN;
		array.cmu[i].bat_status = CMU_BAT_UNKNOWN;
		array.cmu[i].soc = &array.pcsc.pcsc_data.var.bat_soc[i * BAT_RACK_MAX_NUMS_PER_CMU];
		array.cmu[i].soh = &array.pcsc.pcsc_data.var.bat_soh[i * BAT_RACK_MAX_NUMS_PER_CMU];
		// Initialized to the maximum, with no limit on power
		array.cmu[i].limit_power_chg = INT16_MAX;
		array.cmu[i].limit_power_dch = INT16_MAX;
		array.cmu[i].soc_chg = SOC_INVALID_VALUE;
		array.cmu[i].soh_chg = SOC_INVALID_VALUE;
		array.cmu[i].soc_dch = SOC_INVALID_VALUE;
		array.cmu[i].soh_dch = SOC_INVALID_VALUE;
	}
	fill_struct_data((uint8_t *)&array.pcsc.pcsc_data.var.bat_soc[0], 0xFF, sizeof(array.pcsc.pcsc_data.var.bat_soc));
	soc_compute_detect_count_ref = SOC_COMPUTE_BASETIME / SOC_COMPUTE_BASETIME / task_array[SLOW_TASK_CMU_SOC_COMPUTE].period;
	clear_struct_data((uint8_t*)last_cmu_action, sizeof(last_cmu_action));
	clear_struct_data((uint8_t*)power_allocation_buff, sizeof(power_allocation_buff));
	clear_struct_data((uint8_t*)planning_scheduling_delay_on_cnt, sizeof(planning_scheduling_delay_on_cnt));

	g_active_power_send = FALSE;
	g_reactive_power_send = FALSE;
	trigger_power_resend = TRUE;
	trigger_plan_scheduler = FALSE;
	trigger_planning_scheduling_start = FALSE;
}

/******************************************************************************
 * can_frame_direct_send().
 * Combine can frame and send can frame directly. [Called by rack_level_manage]
 *
 * @param  can_cmd  (I) the can cmd
 * @param  can_port (I) can send port
 * @param  value    (I) active power
 * @param  none     (O)
 * @return none
 *****************************************************************************/
static void can_frame_direct_send(pcsm_cmd_t can_cmd, uint32_t can_port, half_word_t value)
{
	can_id_t can_id;
	uint8_t can_data[8];
	int16_t base_rated_power = array.csu.csu_data.csu_const.base_rated_power;

	can_id.src_addr = CSU_MCU2;
	can_id.src_type = DEVICE_CSU;
	can_id.dst_type = DEVICE_PCS;
	can_id.fun_code = can_cmd.fun_code;
	can_id.dst_addr = can_cmd.dst_addr;
	can_id.type = 1;
	can_id.prio = 6;
	constrain_int16_t_data((int16_t*)&value.all, \
							-PARAMETER_ACCURACY_MAGNIFICATION_6 * base_rated_power * ACTIVE_POWER_OVERLOAD_MULTIPLE, \
							PARAMETER_ACCURACY_MAGNIFICATION_6 * base_rated_power * ACTIVE_POWER_OVERLOAD_MULTIPLE);
	can_data[0] = can_cmd.offset.bytes.low;
	can_data[1] = can_cmd.offset.bytes.high;
	can_data[2] = can_cmd.len;
	can_data[3] = value.bytes.low;
	can_data[4] = value.bytes.high;
	can_data[5] = 0;
	can_data[6] = 0;
	can_data[7] = 0;

	while(sdk_os_mutex_acquire(can1_busy, CAN_WAIT_MUTEX_TIME));

	cup_sofar_can_send(can_port, &can_id, can_data, can_cmd.len);
	sdk_os_mutex_release(can1_busy);

}

/******************************************************************************
 * ext_power_manage().
 * External power dispatching management. [Called by app]
 *
 * @param  none  (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void ext_power_manage(void)
{
}

/******************************************************************************
 * cab_power_manage().
 * Cabinet power dispatching management. [Called by app]
 *
 * @param  none  (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void cab_power_manage(void)
{
}

/******************************************************************************
 * pm_power_manage().
 * Power module's power dispatching management. [Called by app]
 *
 * @param  none  (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void pm_power_manage(void)
{
}

/******************************************************************************
 * avg_power_algorithm().
 * Average power dispatching algorithm. [Called by app]
 *
 * @param  none  (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void avg_power_algorithm(void)
{
	pcsm_cmd_t can_cmd_temp;
	uint32_t can_port;
	half_word_t value;
	uint8_t cmu_num = 0;

	cmu_num = array.array_data.variable.cmu_running;
	if(0 == cmu_num)
	{
		return;
	}
	can_cmd_temp.len = 1;
	can_cmd_temp.fun_code = PCS_CMD_SET_PARAMETER;
	can_cmd_temp.dst_addr = PCSM_BCAST_ID;
	can_cmd_temp.offset.all = ACTIVE_POWER_REF;
	//fifo_can_push(&fifo_can1_cmd, &can_cmd_temp);
	// pcsc power ref(0.1kW) --> pcsm power ref(0.01kW)
	value.all = ((int32_t)array.pcsc.pcsc_ctrl.active_power_ref * 10) / cmu_num;
	can_port = CAN1_PORT;

	can_frame_direct_send(can_cmd_temp, can_port, value);
}
/******************************************************************************
 * clear_power_setting().
 * Average power dispatching algorithm. [Called by app]
 *
 * @param  none  (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void clear_power_setting(void)
{
	pcsm_cmd_t can_cmd_temp;
	uint32_t can_port;
	half_word_t value;
	uint8_t i = 0;

	for (i = 0; i < CMU_NUMS; i++)
	{
		array.pcsc.pcsc_data.pcsm_data[i].set[WRITE_INDEX].active_power_ref = 0;
	}

	can_cmd_temp.len = 1;
	can_cmd_temp.fun_code = PCS_CMD_SET_PARAMETER;
	can_cmd_temp.offset.all = ACTIVE_POWER_REF;
	value.all = 0;
	can_port = CAN1_PORT;

	if(MASTER == array.csu.csu_data.csu_heart.csu_role)
	{
		can_cmd_temp.dst_addr = 1;
		can_frame_direct_send(can_cmd_temp, can_port, value);
	}
	else
	{
		for (i = 0; i < CMU_NUMS; i++)
		{
			can_cmd_temp.dst_addr = i + 1;
			can_frame_direct_send(can_cmd_temp, can_port, value);
		}
	}
}

/******************************************************************************
 * power_load_shedding().
 * Rack level management. [Called by app]
 *
 * @param  none  (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
bool_t power_load_shedding(uint8_t action, uint8_t distribution_mode, uint16_t avilable_cmu)
{
	int32_t remain_power = 0;
	uint8_t i = 0;
	bool_t distribution_complete = FALSE;
	uint16_t cmu_count = 0;
	int32_t      soc_sum = 0;
	int16_t    soc_act_temp[CMU_NUMS];

	for (i = 0; i < CMU_NUMS; i++)
	{
		// dch
		if((action == SYS_STATE_DISCHARGE) && (TRUE == BIT_GET(g_dch_avilable_cmu, i)))
		{
			if(power_allocation_buff[i] >= array.cmu[i].limit_power_dch)
			{
				soc_act_temp[i] = 0;
				remain_power += power_allocation_buff[i] - array.cmu[i].limit_power_dch;
				power_allocation_buff[i] = array.cmu[i].limit_power_dch;
				BIT_CLR(avilable_cmu, i);
			}
			else
			{
				soc_act_temp[i] = array.cmu[i].soc_dch * array.cmu[i].soh_dch;
				soc_sum += soc_act_temp[i];
				cmu_count++;
			}
		}
		else if(((action == SYS_STATE_CHARGE) && (TRUE == BIT_GET(g_chg_avilable_cmu, i))))
		{
			if(power_allocation_buff[i] <= array.cmu[i].limit_power_chg)
			{
				soc_act_temp[i] = 0;
				remain_power += power_allocation_buff[i] - array.cmu[i].limit_power_chg;
				power_allocation_buff[i] = array.cmu[i].limit_power_chg;
				BIT_CLR(avilable_cmu, i);
			}
			else
			{
				soc_act_temp[i] = (100 - array.cmu[i].soc_chg) * array.cmu[i].soh_chg;
				soc_sum += soc_act_temp[i];
				cmu_count++;
			}
		}
		else{}
	}
	if((remain_power != 0) && (cmu_count != 0))
	{
		for (i = 0; i < CMU_NUMS; i++)
		{
			if(TRUE == BIT_GET(avilable_cmu, i))
			{
				if(distribution_mode == RACK_MANAGE)
				{
					power_allocation_buff[i] += remain_power * soc_act_temp[i] / soc_sum;
				}
				else
				{
					power_allocation_buff[i] += remain_power / cmu_count;
				}
			}
		}
		return distribution_complete;
	}
	else
	{
		distribution_complete = TRUE;
		return distribution_complete;
	}
}
/******************************************************************************
 * rack_level_manage_master().
 * Rack level management. [Called by app]
 *
 * @param  none  (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void rack_level_manage_master(void)
{
	uint8_t      i;
	uint32_t     can_port;
	half_word_t  value;
	pcsm_cmd_t   can_cmd_temp;
	int16_t      p_total;
	pcsm_data_t  *pcsm = NULL;
	int32_t      soc_sum = 0;
	int16_t    soc_act_temp[CMU_NUMS];
	uint8_t distribution_mode = AVERAGE_DISTRIBUTION;
	uint8_t cmu_avilable_num = 0;
	uint16_t avilable_cmu = 0;
	uint8_t sys_action;
	uint8_t power_alloc_cnt = 0;
	bool_t power_clear = FALSE;

	clear_struct_data((uint8_t *)&soc_act_temp[0], sizeof(soc_act_temp));
	can_cmd_temp.fun_code = PCS_CMD_SET_PARAMETER;
	can_cmd_temp.len = 1;
	can_cmd_temp.offset.all = ACTIVE_POWER_REF;
	p_total = array.pcsc.pcsc_ctrl.active_power_ref;
	pcsm = array.pcsc.pcsc_data.pcsm_data;
	can_port = CAN1_PORT;

	constrain_int16_t_data(&p_total, -1 * ems.p_chgmax_theory, ems.p_dischgmax_theory);
	if((p_total < 0) && (g_rechargeable_num != 0))
	{
		sys_action = SYS_STATE_CHARGE;
		distribution_mode = g_chg_p_distribution_mode;
		cmu_avilable_num = g_rechargeable_num;
		for(i = 0; i < CMU_NUMS; i++)
		{
			if(TRUE == BIT_GET(g_chg_avilable_cmu, i))
			{
				soc_act_temp[i] = (100 - array.cmu[i].soc_chg) * array.cmu[i].soh_chg;
				soc_sum += soc_act_temp[i];
			}
			else
			{
				soc_act_temp[i] = 0;
			}
		}
		if (soc_sum == 0)
		{
			power_clear = TRUE;
		}
	}
	else if((p_total > 0) && (g_redischargeable_num != 0))
	{
		sys_action = SYS_STATE_DISCHARGE;
		distribution_mode = g_dch_p_distribution_mode;
		cmu_avilable_num = g_redischargeable_num;
		for(i = 0; i < CMU_NUMS; i++)
		{
			if(TRUE == BIT_GET(g_dch_avilable_cmu, i))
			{
				soc_act_temp[i] = array.cmu[i].soc_dch * array.cmu[i].soh_dch;
				soc_sum += soc_act_temp[i];
			}
			else
			{
				soc_act_temp[i] = 0;
			}
		}
		if (soc_sum == 0)
		{
			power_clear = TRUE;
		}
	}
	else
	{
		power_clear = TRUE;
	}

	if(TRUE == power_clear)
	{
		clear_power_setting();
		return;
	}

	for(i = 0; i < CMU_NUMS; i++)
	{
		if(((sys_action == SYS_STATE_CHARGE) && (TRUE == BIT_GET(g_chg_avilable_cmu, i))) || \
			((sys_action == SYS_STATE_DISCHARGE) && (TRUE == BIT_GET(g_dch_avilable_cmu, i))))
		{
			if(distribution_mode == RACK_MANAGE)
			{
				power_allocation_buff[i] = (soc_act_temp[i] * p_total) / soc_sum;
			}
			else
			{
				power_allocation_buff[i] = p_total / cmu_avilable_num;
			}
			BIT_SET(avilable_cmu, i);
		}
		else
		{
			power_allocation_buff[i] = 0;
		}
	}

	array.pcsc.pcsc_ctrl.power_distribution_mode = distribution_mode;

	while(!power_load_shedding(sys_action, distribution_mode, avilable_cmu))
	{
		power_alloc_cnt++;
		if(power_alloc_cnt > CMU_NUMS)
		{
			break;
		}
	}
	for(i = 0; i < CMU_NUMS; i++)
	{
		pcsm[i].set[WRITE_INDEX].active_power_ref = (int16_t)power_allocation_buff[i] * 10;
	}
	if(array.csu.csu_data.csu_heart.csu_role == MASTER)
	{
		if(TRUE == BIT_GET(avilable_cmu, 0))
		{
			can_cmd_temp.dst_addr = 1;
			value.all = (uint16_t)pcsm[0].set[WRITE_INDEX].active_power_ref;
			can_frame_direct_send(can_cmd_temp, can_port, value);
		}
	}
	else
	{
		for(i = 0; i < CMU_NUMS; i++)
		{
			if(TRUE == BIT_GET(avilable_cmu, i))
			{
				can_cmd_temp.dst_addr = i + 1;
				value.all = (uint16_t)pcsm[i].set[WRITE_INDEX].active_power_ref;
				can_frame_direct_send(can_cmd_temp, can_port, value);
			}
		}
	}
}

/******************************************************************************
 * slow_task_pcs_ratings().
 * Calculate the rating of all PCS modules, and grouping. [Called by app]
 *
 * @param  none  (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void slow_task_pcs_rating(void)
{
	static uint8_t pre_cmu_online_num = 0;
	static uint8_t pre_rechargeable_num = 0;
	static uint8_t pre_redischargeable_num = 0;

	csu_const_t *p_const = &array.csu.csu_data.csu_const;

	if(pre_cmu_online_num != array.array_data.variable.cmu_online)
	{
		p_const->rat_power_p_total = array.csu.csu_data.csu_const.base_rated_power * (array.array_data.variable.cmu_online > 0 ? array.array_data.variable.cmu_online : 1);
		pre_cmu_online_num = array.array_data.variable.cmu_online;
		ems.automatic.dead_band = p_const->rat_power_p_total * 0.005;
	}

	if((pre_rechargeable_num != g_rechargeable_num) || (pre_redischargeable_num != g_redischargeable_num))
	{
		ems.p_chg_step = BASE_POWER_ADJUST_STEP * (g_rechargeable_num > 0 ? g_rechargeable_num : 1);
		ems.p_dischg_step = BASE_POWER_ADJUST_STEP *(g_redischargeable_num > 0 ? g_redischargeable_num : 1);
		pre_rechargeable_num = g_rechargeable_num;
		pre_redischargeable_num = g_redischargeable_num;
	}
}

/******************************************************************************
 * rack_manage().
 * rack level management.[Called by task]
 *
 * @param  none  (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void rack_manage(void)
{
	static uint8_t pre_cmu_num = 0;
	static int16_t per_active_power = 0;

	if ((g_active_power_send) || \
		(pre_cmu_num != array.array_data.variable.cmu_running))
	{
		if(((0 == array.pcsc.pcsc_ctrl.active_power_ref) && \
			(per_active_power != array.pcsc.pcsc_ctrl.active_power_ref)) || \
			(array.array_data.variable.cmu_running != pre_cmu_num))
		{
			opt_log_record("rack manage, power : %d, pcsm num : %d ->%d", \
			array.pcsc.pcsc_ctrl.active_power_ref, \
								pre_cmu_num, array.array_data.variable.cmu_running);
			sdk_log_a("rack manage, power : %d, pcsm num : %d ->%d\n", \
			array.pcsc.pcsc_ctrl.active_power_ref, \
								pre_cmu_num, array.array_data.variable.cmu_running);
		}
		g_active_power_send = FALSE;
		rack_level_manage_master();
		pre_cmu_num = array.array_data.variable.cmu_running;
		per_active_power = array.pcsc.pcsc_ctrl.active_power_ref;
	}
}

/******************************************************************************
 * slow_task_cmu_soc_compute().
 * Battery balanced power distribution task. [Called by app]
 *
 * @param  none  (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void slow_task_cmu_soc_compute(void)
{
	uint8_t i, j;
	bool_t tmp = FALSE;
	uint16_t soc_min_index, soc_max_index;
	for(i = 0; i < CMU_NUMS; i++)
	{
		if(array.cmu[i].sys_status != CMU_SYS_UNKOWN)
		{
			// 默认第一个soc一定是0~100之间的
			soc_min_index = 0;
			soc_max_index = 0;
			// Let's say the first soc is the most valuable, compared to the other SOCs
			for(j = 1; j < BAT_RACK_MAX_NUMS_PER_CMU; j++)
			{
				// All it takes is one soc to work
				check_uint16_validity(array.cmu[i].soc[j], 0, 100, &tmp);
				if(tmp)
				{
					if(array.cmu[i].soc[soc_max_index] < array.cmu[i].soc[j])
					{
						soc_max_index = j;
					}
					// If it is not the maximum value, determine whether it is the minimum value
					else if(array.cmu[i].soc[soc_min_index] > array.cmu[i].soc[j])
					{
						soc_min_index = j;
					}
				}
			}
			// Add up the soc per cmu
			array.cmu[i].soc_chg = soc_limit(i, array.cmu[i].soc[soc_max_index]);
			array.cmu[i].soh_chg = array.cmu[i].soh[soc_max_index];
			array.cmu[i].soc_dch = soc_limit(i, array.cmu[i].soc[soc_min_index]);
			array.cmu[i].soh_dch = array.cmu[i].soh[soc_min_index];
		}
	}
}

/******************************************************************************
 * slow_task_ems_soc_compute().
 * Battery balanced power distribution task. [Called by app]
 *
 * @param  none  (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void slow_task_ems_soc_compute(void)
{
	uint8_t i;
	uint16_t soc_actual_chg = 0, soh_actual_chg = 0, soc_actual_dch = 0, soh_actual_dch = 0;
	uint16_t soc_max_cmu_tmp = 0, soc_min_cmu_tmp = 100;
	// 至少有一个cmu可以充电
	if(0 != g_rechargeable_num)
	{
		// 计算需要充电的SOC有多少，并找出soc最高的cmu的soc值
		for (i = 0; i < CMU_NUMS; i++)
		{
			if(BIT_GET(g_chg_avilable_cmu, i))
			{
				soc_actual_chg += array.cmu[i].soc_chg;
				soh_actual_chg += array.cmu[i].soh_chg;
				// 如果cmu可以充电，需要关注是否有soc过低
				soc_min_cmu_tmp = min(soc_min_cmu_tmp, array.cmu[i].soc_dch);
			}
		}
		// 计算平均可充的soc
		ems.soc_actual_chg = soc_actual_chg / g_rechargeable_num;
		ems.soh_actual_chg = soh_actual_chg / g_rechargeable_num;
		ems.soc_min_cmu = soc_min_cmu_tmp;
	}
	else
	{
		ems.soc_actual_chg = SOC_INVALID_VALUE;
		ems.soh_actual_chg = SOC_INVALID_VALUE;
		ems.soc_min_cmu = SOC_INVALID_VALUE;
	}
	if(0 != g_redischargeable_num)
	{
		// 计算需要放电的SOC有多少，并找出soc最低的cmu的soc值
		for (i = 0; i < CMU_NUMS; i++)
		{
			if(BIT_GET(g_dch_avilable_cmu, i))
			{
				soc_actual_dch += array.cmu[i].soc_dch;
				soh_actual_dch += array.cmu[i].soh_dch;
				// 如果cmu可以放电，需要关注是否有soc过高
				soc_max_cmu_tmp = max(soc_max_cmu_tmp, array.cmu[i].soc_chg);
			}
		}
		// 计算平均可放的soc
		ems.soc_actual_dch = soc_actual_dch / g_redischargeable_num;
		ems.soh_actual_dch = soh_actual_dch / g_redischargeable_num;
		ems.soc_max_cmu = soc_max_cmu_tmp;
	}
	else
	{
		ems.soc_actual_dch = SOC_INVALID_VALUE;
		ems.soh_actual_dch = SOC_INVALID_VALUE;
		ems.soc_max_cmu = SOC_INVALID_VALUE;
	}
}
/******************************************************************************
 * slow_task_power_allocate_switch().
 * Battery balanced power distribution task. [Called by app]
 *
 * @param  none  (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void slow_task_power_allocate_switch(void)
{
    uint16_t maxdischargediff = 0;
    uint16_t mindischargediff = 10000;
    uint16_t maxchargediff = 0;
    uint16_t minchargediff = 10000;
	uint16_t i = 0;
	uint16_t var_tmp;
	uint8_t rechargeable_num = 0;
	uint8_t redischargeable_num = 0;

    for (i = 0; i < CMU_NUMS; i++) {
		if(TRUE == chg_status_check(i))
		{
			rechargeable_num++;
			BIT_SET(g_chg_avilable_cmu, i);
			var_tmp = (100 - array.cmu[i].soc_chg) * array.cmu[i].soh_chg;
			if (var_tmp > maxchargediff) {
				maxchargediff = var_tmp;
			}
			if (var_tmp < minchargediff) {
				minchargediff = var_tmp;
			}
		}
		else
		{
			BIT_CLR(g_chg_avilable_cmu, i);
		}

		if(TRUE == dch_status_check(i))
		{
			redischargeable_num++;
			BIT_SET(g_dch_avilable_cmu, i);
			var_tmp = array.cmu[i].soc_dch *array.cmu[i].soh_dch;
			if (var_tmp > maxdischargediff) {
				maxdischargediff = var_tmp;
			}
			if (var_tmp < mindischargediff) {
				mindischargediff = var_tmp;
			}
		}
		else
		{
			BIT_CLR(g_dch_avilable_cmu, i);
		}
    }
	g_rechargeable_num = rechargeable_num;
	g_redischargeable_num = redischargeable_num;

	if((maxdischargediff - mindischargediff) < 300)
	{
		g_dch_p_distribution_mode = AVERAGE_DISTRIBUTION;
	}
	else
	{
		g_dch_p_distribution_mode = RACK_MANAGE;
	}
	if((maxchargediff - minchargediff) < 300)
	{
		g_chg_p_distribution_mode = AVERAGE_DISTRIBUTION;
	}
	else
	{
		g_chg_p_distribution_mode = RACK_MANAGE;
	}
}
/******************************************************************************
 * reactive_power_send().
 * Deliver reactive power. [Called by thread_power_control()]
 *
 * @param *argument (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
static void reactive_power_send(void)
{
	uint32_t can_port;
	pcsm_cmd_t can_cmd_temp;
	half_word_t value;
	uint8_t cmu_num;

	cmu_num = array.array_data.variable.cmu_running;
	if(0 == cmu_num)
	{
		return;
	}

	can_cmd_temp.len = 1;
	can_cmd_temp.fun_code = PCS_CMD_SET_PARAMETER;
	can_cmd_temp.dst_addr = PCSM_BCAST_ID;
	can_cmd_temp.offset.all = REACTIVE_POWER_REF;

	// pcsc reactive power ref(0.1kW) --> pcsm  reactive power ref(0.01kW)
	value.all = ((int32_t)array.pcsc.pcsc_ctrl.reactive_power_ref * 10) / cmu_num;

	can_port = CAN1_PORT;

	can_frame_direct_send(can_cmd_temp, can_port, value);
}

/******************************************************************************
 * thread_power_control().
 * Power control tasks group management. [Called by OS()]
 *
 * @param *argument (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void thread_power_control(void *argument)
{
	while(1)
	{
		if ((trigger_rack_manage) && (!trigger_bat_capacity_test))
		{
			rack_manage();
		}

		if(g_reactive_power_send)
		{
			g_reactive_power_send = FALSE;
			reactive_power_send();
		}
		sdk_delay_ms(3);
	}
}

/******************************************************************************
 * slow_task_bat_capacity_test().
 * Battery capacity test. [Called by task()]
 *
 * @param *argument (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void slow_task_bat_capacity_test(void)
{
	pcsm_cmd_t   can_cmd_temp;

	if (g_active_power_send && \
		!trigger_rack_manage)
	{
		can_cmd_temp.dst_addr = PCSM_BCAST_ID;
		can_cmd_temp.offset.all = ACTIVE_POWER_REF;
		can_cmd_temp.fun_code = PCS_CMD_SET_PARAMETER;
		can_cmd_temp.len = 1;
		fifo_can_push(&fifo_can1_cmd, &can_cmd_temp);
		g_active_power_send = FALSE;
	}
}
/******************************************************************************
 * slow_task_cmu_check().
 * // TODO:. [Called by app]
 *
 * @param  none  (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void slow_task_cmu_check(void)
{
	uint8_t i;
	cmu_t *p_cmu_data = &array.cmu[0];
	uint8_t cmu_online_cnt = 0;
	uint8_t cmu_running_cnt = 0;

	for (i = 0; i < CMU_NUMS; i++)
	{
		// 上线
		if(p_cmu_data[i].sys_status != CMU_SYS_UNKOWN)
		{
			if(p_cmu_data[i].bat_status == CMU_BAT_UNKNOWN)
			{
				p_cmu_data[i].bat_status = CMU_BAT_NORMAL;
				opt_log_record("CMU%d go online", i + 1);
			}
			cmu_online_cnt++;
			if(p_cmu_data[i].sys_status == CMU_SYS_RUNNING)
			{
				cmu_running_cnt++;
			}
		}
		// 下线
		else if((p_cmu_data[i].sys_status == CMU_SYS_UNKOWN) && (p_cmu_data[i].bat_status != CMU_BAT_UNKNOWN))
		{
			p_cmu_data[i].bat_status = CMU_BAT_UNKNOWN;
			p_cmu_data[i].soc_chg = SOC_INVALID_VALUE;
			p_cmu_data[i].soc_dch = SOC_INVALID_VALUE;
			p_cmu_data[i].soh_chg = SOC_INVALID_VALUE;
			p_cmu_data[i].soh_dch = SOC_INVALID_VALUE;
			opt_log_record("CMU%d disconnect", i + 1);
		}
		else{}
	}
	array.array_data.variable.cmu_online = cmu_online_cnt;
	array.array_data.variable.cmu_running = cmu_running_cnt;
}

/******************************************************************************
 * slow_task_bat_ctrl().
 * // TODO:. [Called by app]
 *
 * @param  none  (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void slow_task_bat_status_get(void)
{
	uint8_t i;
	bat_status_t *p_bat_status;

	p_bat_status = &array.pcsc.pcsc_ctrl.bat_status_info;
	for (i = 0; i < CMU_NUMS; i++)
	{
		// if online
		if(array.cmu[i].bat_status != CMU_BAT_UNKNOWN)
		{
			if((BIT_GET(p_bat_status->chg_ctrl.all, i)) && \
				(BIT_GET(p_bat_status->dch_ctrl.all, i)))
			{
				if(array.cmu[i].bat_status != CMU_BAT_FORBID_CHG_DCH)
				{
					opt_log_record("cmu %d status is %d to %d", i, array.cmu[i].bat_status, CMU_BAT_FORBID_CHG_DCH);
					array.cmu[i].bat_status = CMU_BAT_FORBID_CHG_DCH;
				}
			}
			else if(BIT_GET(p_bat_status->chg_ctrl.all, i))
			{
				if(array.cmu[i].bat_status != CMU_BAT_FORBID_CHG)
				{
					opt_log_record("cmu %d status is %d to %d", i, array.cmu[i].bat_status, CMU_BAT_FORBID_CHG);
					array.cmu[i].bat_status = CMU_BAT_FORBID_CHG;
				}
			}
			else if(BIT_GET(p_bat_status->dch_ctrl.all, i))
			{
				if(array.cmu[i].bat_status != CMU_BAT_FORBID_DCH)
				{
					opt_log_record("cmu %d status is %d to %d", i, array.cmu[i].bat_status, CMU_BAT_FORBID_DCH);
					array.cmu[i].bat_status = CMU_BAT_FORBID_DCH;
				}
			}
			else
			{
				if(array.cmu[i].bat_status != CMU_BAT_NORMAL)
				{
					opt_log_record("cmu %d status is %d to %d", i, array.cmu[i].bat_status, CMU_BAT_NORMAL);
					array.cmu[i].bat_status = CMU_BAT_NORMAL;
				}
			}
		}
	}
}

/******************************************************************************
 * notice_mcu1().
 * planning scheduling pcsm. [Called by app]
 *
 * @param  check_time  (I) time range
 * @param  mode  (I) shutdown or urgent shutdown
 * @param  action  (I) on(TRUE) or off(FALSE)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void notice_mcu1(uint8_t *action)
{
	uint8_t i;
	bool_t send_cmd_flag;
	uint8_t running_status = 0;

	for(i = 0; i < CMU_NUMS; i++)
	{
		running_status = array.cmu[i].sys_status;
		send_cmd_flag = FALSE;
		if(CMU_ACTION_NONE != action[i])
		{
			if((CMU_ACTION_ON == action[i]) && \
				((last_cmu_action[i] != action[i]) || (running_status != CMU_SYS_RUNNING)) && \
				(0 == planning_scheduling_delay_on_cnt[i]))
			{
				send_cmd_flag = TRUE;
			}
			else if((CMU_ACTION_STANBY == action[i]) && \
					(((last_cmu_action[i] != CMU_ACTION_STANBY) && (last_cmu_action[i] != CMU_ACTION_STOP)) || (running_status == CMU_SYS_RUNNING)))
			{
				planning_scheduling_delay_on_cnt[i] = PLANNING_SCHEDULING_DELAY_ON_TIME_CONUT;
				send_cmd_flag = TRUE;
			}
			else if((CMU_ACTION_STOP == action[i]) && \
					(((last_cmu_action[i] != CMU_ACTION_STANBY) && (last_cmu_action[i] != CMU_ACTION_STOP)) || (running_status == CMU_SYS_RUNNING)))
			{
				planning_scheduling_delay_on_cnt[i] = PLANNING_SCHEDULING_DELAY_ON_TIME_CONUT;
				send_cmd_flag = TRUE;
			}
			else{}
			if(send_cmd_flag)
			{
				array.cmu[i].action = action[i];
				last_cmu_action[i] = action[i];
				opt_log_record("cmu %d, cmd: %d", i + 1, action[i]);
			}
		}
	}
}

/******************************************************************************
 * get_time_interval().
 * get_time_interval. [Called by app]
 *
 * @param  probibit  (I) CMU_BAT_FORBID_CHG_DCH or CMU_BAT_FORBID_CHG or
 *                       CMU_BAT_FORBID_DCH or CMU_BAT_NORMAL
 * @return 0： Currently in power scheduling instruction，
 *     other： Distance from the next power scheduling interval
 *****************************************************************************/
uint16_t get_time_interval(uint8_t probibit)
{
	uint16_t ret = UINT16_MAX;
	uint16_t time_gap = UINT16_MAX;
	uint8_t i;
	sdk_rtc_t next_time[2];
	uint16_t time_point[3];
	sdk_rtc_t now_time;
	uint8_t tm_attr;
	tm_period_t *p_period = &ems.tm_period[0];

	if(CMU_BAT_FORBID_CHG_DCH == probibit)
	{
		ret = UINT16_MAX;
	}
	else
	{
		now_time = array.csu.rtc;
		if(check_today_date())
		{
			p_period = &ems.holiday_tm_period[0];
		}
		for(i = 0; i < TIME_PERIOD_NUM_MAX; i++)
		{
			transfer_time_format(&p_period[i], &next_time[0]);
			tm_attr = get_time_period_attr(&p_period[i]);

			// If the current time period is discharge scheduling
			if (((CMU_BAT_FORBID_CHG == probibit) && ((tm_attr == PEAK_TM) || (tm_attr == TOP_TM)  || (tm_attr == AUTOMATIC_TM))) || \
				((CMU_BAT_FORBID_DCH == probibit) && ((tm_attr == VALLEY_TM) || (tm_attr == AUTOMATIC_TM))) || \
				((CMU_BAT_NORMAL == probibit) && (tm_attr > FLAT_TM)))
			{
				time_point[0]= total_minutes(&next_time[0]);
				time_point[1]= total_minutes(&next_time[1]);
				time_point[2]= total_minutes(&now_time);
				if((time_point[2] >= time_point[0]) &&
					(time_point[2] <= time_point[1]))
				{
					time_gap = 0;
				}
				else
				{
					transfer_time_format(&p_period[i], &next_time[0]);
					time_gap = time_difference_in_minutes(&now_time, &next_time[0]);
				}
				ret = min(ret, time_gap);
			}
		}
	}

	return ret;
}

/******************************************************************************
 * delay_planning_scheduling().
 * delay 10s, enable heart check. [Called by slow_task_others.]
 *
 * @param	none (I)
 * @return	none
 *****************************************************************************/
void delay_planning_scheduling(void)
{
	static uint16_t delay_planning_scheduling_cnt = 0;

	if (trigger_planning_scheduling_start)
	{
		trigger_plan_scheduler = FALSE;
		trigger_planning_scheduling_start = FALSE;
		delay_planning_scheduling_cnt = 0;
		clear_struct_data((uint8_t*)planning_scheduling_delay_on_cnt, sizeof(planning_scheduling_delay_on_cnt));
	}

	if((FALSE == trigger_plan_scheduler) && (delay_planning_scheduling_cnt <= 600))
	{
		delay_planning_scheduling_cnt++;
	}
	else
	{
		trigger_plan_scheduler = TRUE;
	}
}
/******************************************************************************
 * slow_task_planning_scheduling().
 * planning scheduling pcsm. [Called by app]
 *
 * @param  check_time  (I) time range
 * @param  mode  (I) shutdown or urgent shutdown
 * @param  action  (I) on or off
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void slow_task_planning_scheduling(void)
{
	uint16_t standby_time;
	uint16_t stop_time;
	uint16_t startup_time;
	uint16_t time_gap;
	uint8_t id, i;
	uint8_t action[CMU_NUMS];

	if((ONE_STORAGE_TANK_XIAOJU_1_2 == array.pcsc.pcsc_ctrl.scenario_setting) && \
		(XIAOJU_REMOTE == xiao_ju.ctrl_source))
	{
		return;
	}
	clear_struct_data((uint8_t*)&action, CMU_NUMS);

	for (i = 0; i < CMU_NUMS; i++)
	{
		if(planning_scheduling_delay_on_cnt[i] != 0)
		{
			planning_scheduling_delay_on_cnt[i]--;
		}
	}
	if(ems.cpfv.enable || ems.automatic.enable)
	{
		stop_time = ems.pcs_stop_wait_time * 6;
		standby_time = ems.pcs_standby_wait_time * 6;
		startup_time = ems.pcs_advance_startup_time;

		for (id = 0; id < CMU_NUMS; id++)
		{
			if(((array.cmu[id].sys_status == CMU_SYS_STOP) || (array.cmu[id].sys_status == CMU_SYS_RUNNING) || (array.cmu[id].sys_status == CMU_SYS_SLEEP)) && \
				(array.pcsc.pcsc_data.pcsm_data[id].set[WRITE_INDEX].active_power_ref == 0))
			{
				time_gap = get_time_interval(array.cmu[id].bat_status);
				// A stop time has been set and the time interval is greater than the stop time
				if((0 != stop_time) && (time_gap >= stop_time))
				{
					action[id] = CMU_ACTION_STOP;
				}
				// A waiting time has been set and the time interval is greater than the waiting time
				else if((0 != standby_time) && (time_gap >= standby_time))
				{
					action[id] = CMU_ACTION_STANBY;
				}
				else if(time_gap <= startup_time)
				{
					action[id] = CMU_ACTION_ON;
				}
				else
				{
					action[id] = CMU_ACTION_NONE;
				}
			}
		}
		notice_mcu1(&action[0]);
	}
}

/******************************************************************************
 * slow_task_power_resend().
 * active and reactive power resend. [Called by OS()]
 *
 * @param *argument (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void slow_task_power_resend(void)
{
	g_active_power_send = TRUE;
	g_reactive_power_send = TRUE;
}

/******************************************************************************
 * slow_task_drmn_resend().
 * active and reactive power resend. [Called by OS()]
 *
 * @param *argument (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void slow_task_drmn_resend(void)
{
	pcsm_cmd_t can_cmd_temp;

	can_cmd_temp.fun_code = PCS_CMD_SET_PARAMETER;
	can_cmd_temp.len = 1;
	can_cmd_temp.dst_addr = PCSM_BCAST_ID;
	can_cmd_temp.offset.all = DRMN_SET;
	fifo_can_push(&fifo_can1_cmd, &can_cmd_temp);
}
/******************************************************************************
 * chg_status_check().
 * chg_status_check. [Called by OS()]
 *
 * @param *argument (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
bool_t chg_status_check(uint8_t cmu_index)
{
	bool_t ret = FALSE;
	uint8_t bat_status = array.cmu[cmu_index].bat_status;
	uint8_t sys_status = array.cmu[cmu_index].sys_status;

	if((CMU_SYS_RUNNING == sys_status) && ((bat_status == CMU_BAT_NORMAL) || (bat_status == CMU_BAT_FORBID_DCH)))
	{
		ret = TRUE;
	}

	return ret;
}

/******************************************************************************
 * dch_status_check().
 * dch_status_check. [Called by OS()]
 *
 * @param *argument (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
bool_t dch_status_check(uint8_t cmu_index)
{
	bool_t ret = FALSE;
	uint8_t bat_status = array.cmu[cmu_index].bat_status;
	uint8_t sys_status = array.cmu[cmu_index].sys_status;

	if((CMU_SYS_RUNNING == sys_status) && ((bat_status == CMU_BAT_NORMAL) || (bat_status == CMU_BAT_FORBID_CHG)))
	{
		ret = TRUE;
	}

	return ret;
}

/******************************************************************************
 * slow_task_calc_power_limit().
 * dch_status_check. [Called by OS()]
 *
 * @param *argument (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void slow_task_calc_power_limit(void)
{
	uint8_t i;

	for (i = 0; i < CMU_NUMS; i++)
	{
		if(array.cmu[i].bat_status != CMU_BAT_UNKNOWN)
		{
			if(MASTER == array.csu.csu_data.csu_heart.csu_role)
			{
				array.cmu[i].limit_power_chg = max(array.pcsc.pcsc_ctrl.bat_status_info.chg_lmt_power[i], pcsm_chg_dch_limit[i].chg_limit) / 10;
				array.cmu[i].limit_power_dch = min(array.pcsc.pcsc_ctrl.bat_status_info.dch_lmt_power[i], pcsm_chg_dch_limit[i].dch_limit) / 10;
			}
			else
			{
				array.cmu[i].limit_power_chg = max(array.pcsc.pcsc_ctrl.bat_status_info.chg_lmt_power[i], (array.pcsc.pcsc_data.pcsm_data[i].state.derate_sout_intport)) / 10;
				array.cmu[i].limit_power_dch = min(array.pcsc.pcsc_ctrl.bat_status_info.dch_lmt_power[i], (array.pcsc.pcsc_data.pcsm_data[i].state.derate_sout_outport)) / 10;
			}
		}
	}
}

/******************************************************************************
 * soc_limit().
 * soc_limit. [Called by OS()]
 *
 * @param *argument (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
uint8_t soc_limit(uint8_t cmu_index, uint8_t soc)
{
	uint8_t soc_act = soc;

	if((100 == soc_act) && (chg_status_check(cmu_index)))
	{
		soc_act = 99;
	}
	if((0 == soc_act) && (dch_status_check(cmu_index)))
	{
		soc_act = 1;
	}
	return soc_act;
}
/******************************************************************************
* End of module
******************************************************************************/
