/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     pcsc_diag_log.c
  * @brief    pcsc diagnostic log module
  * @company  SOFARSOLAR
  * @author   WWX
  * @note
  * @version  V01
  * @date     2023/05/10
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "array.h"
#include "ems.h"
#include "fifo_log.h"
#include "measure.h"
#include "pcsc_diag_log.h"
#include "pcsc_opt_log.h"
#include "pcsc_diag.h"
#include "rs485_device_manage.h"
#include "sdk_core.h"
#include "sdk.h"
#include <stdarg.h>

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
//enum
//{
//	DIAG_LOG = 0,     // type diagnose
//	OPAT_LOG,         // type excution
//}APP_LOG_E;

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/
static void log_check_ac_breaker(const char *num_degree_str, uint8_t pcsm_id, \
										float32_t v_grid[3], int16_t v_pcsm[3]);
static void log_reset_ac_breaker(const char *num_degree_str, uint8_t pcsm_id, \
										float32_t v_grid[3], int16_t v_pcsm[3]);

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/
/******************************************************************************
 * pcsc_diag_log_init().
 * Initialize pcsc diagnostic of log modules. [Called by sw init function.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void pcsc_diag_log_init(void)
{
	int32_t ret;

	ret = sdk_record_init(DIAG_LOG, ONE_DIAG_LOG_SIZE, MAX_DIAG_LOG_NUMS);
	if(ret != SF_OK)
	{
		sdk_log_d("diagnostic log init error!\r\n");
	}
	else
	{
		sdk_log_d("diagnostic log init ok!\r\n");
	}
}

/******************************************************************************
 * record_fault_log().
 * write log of csu board otw. [Called by diag task group.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void fault_log_record(const char *p_format, ...)
{
	va_list aptr;

	va_start(aptr, p_format);
	clear_struct_data(diag_log_info, ONE_DIAG_LOG_SIZE * 2);
	vsprintf((char*)diag_log_info, p_format, aptr);
	va_end(aptr);
	app_log_write(diag_log_info, DIAG_LOG);
}

/******************************************************************************
 * log_check_csu_board_otw().
 * write log of csu board otw. [Called by diag task group.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void log_check_csu_board_otw(void)
{
	fault_log_record("1, minor: csu board otw, value:%d, set:%d",\
					array.pcsc.pcsc_data.var.t_board, set_otw);
}

/******************************************************************************
 * log_reset_csu_board_otw().
 * write log check_csu_board_otw. [Called by diag task group.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void log_reset_csu_board_otw(void)
{
	fault_log_record("1, minor: csu board otw restored, value:%d, set:%d",
			array.pcsc.pcsc_data.var.t_board, set_otw);
}

/******************************************************************************
 * log_check_ac_tank_otw().
 * write log check ac tank otw. [Called by diag task group.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void log_check_ac_tank_otw(void)
{
	fault_log_record("2, minor: ac tank otw, value:%d, set:%d",
			array.pcsc.pcsc_data.var.t_ac_fuse, set_otw);
}

/******************************************************************************
 * log_reset_ac_tank_otw().
 * write log reset ac tank otw. [Called by diag task group.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void log_reset_ac_tank_otw(void)
{
	fault_log_record("2, minor: ac tank otw restored, value:%d, set:%d",
			array.pcsc.pcsc_data.var.t_ac_fuse, set_otw);
}
/******************************************************************************
 * log_check_csu_board_otp().
 * write log of csu board otp. [Called by diag task group.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void log_check_csu_board_otp(void)
{
	fault_log_record("3, major: csu board otp, value:%d, set:%d",
			array.pcsc.pcsc_data.var.t_board, set_otp);
}

/******************************************************************************
 * log_reset_csu_board_otp().
 * write log check_csu_board_otp. [Called by diag task group.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void log_reset_csu_board_otp(void)
{
	fault_log_record("3, major: csu board otp restored, value:%d, set:%d",
			array.pcsc.pcsc_data.var.t_board, set_otp);
}

/******************************************************************************
 * log_check_ac_tank_otp().
 * write log check ac tank otp. [Called by diag task group.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void log_check_ac_tank_otp(void)
{
	fault_log_record("4, major: ac tank otp, value:%d, set:%d",
			array.pcsc.pcsc_data.var.t_ac_fuse, set_otp);
}

/******************************************************************************
 * log_reset_ac_breaker_otp().
 * write log reset ac tank otp. [Called by diag task group.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void log_reset_ac_tank_otp(void)
{
	fault_log_record("4, major: ac tank otp restored, value:%d, set:%d",
			array.pcsc.pcsc_data.var.t_ac_fuse, set_otp);
}

/******************************************************************************
 * log_check_csu_board_utw().
 * write log of csu board utw. [Called by diag task group.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void log_check_csu_board_utw(void)
{
	fault_log_record("5, minor: csu board utw, value:%d, set:%d",
			array.pcsc.pcsc_data.var.t_board, set_utw);
}

/******************************************************************************
 * log_reset_csu_board_utw().
 * write log check_csu_board_utw. [Called by diag task group.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void log_reset_csu_board_utw(void)
{
	fault_log_record("5, minor: csu board utw restored, value:%d, set:%d",
			array.pcsc.pcsc_data.var.t_board, set_utw);
}

/******************************************************************************
 * log_check_ac_tank_utw().
 * write log check ac tank utw. [Called by diag task group.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void log_check_ac_tank_utw(void)
{
	fault_log_record("6, minor: ac tank utw, value:%d, set:%d",
			array.pcsc.pcsc_data.var.t_ac_fuse, set_utw);
}

/******************************************************************************
 * log_reset_ac_tank_utw().
 * write log reset ac tank utw. [Called by diag task group.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void log_reset_ac_tank_utw(void)
{
	fault_log_record("6, minor: ac tank utw restored, value:%d, set:%d",
			array.pcsc.pcsc_data.var.t_ac_fuse, set_utw);
}

/******************************************************************************
 * log_check_csu_board_ntc().
 * write log of csu board ntc fail. [Called by diag task group.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void log_check_csu_board_ntc(void)
{
	fault_log_record("7, minor: csu board ntc failed, value:%d, max limt:%d, min limt:%d",
			array.pcsc.pcsc_data.var.t_board, NTC_TEMP_MAX_LIMIT, NTC_TEMP_MIN_LIMIT);
}

/******************************************************************************
 * log_reset_csu_board_ntc().
 * write log of csu board ntc restore. [Called by diag task group.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void log_reset_csu_board_ntc(void)
{
	fault_log_record("7, minor: csu board ntc restored, value:%d, max limt:%d, min limt:%d",
			array.pcsc.pcsc_data.var.t_board, NTC_TEMP_MAX_LIMIT, NTC_TEMP_MIN_LIMIT);
}

/******************************************************************************
 * log_check_ac_tank_ntc().
 * write log check ac tank ntc fail. [Called by diag task group.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void log_check_ac_tank_ntc(void)
{
	fault_log_record("8, minor: ac tank ntc fail, value:%d, max limt:%d, min limt:%d",
			array.pcsc.pcsc_data.var.t_ac_fuse, NTC_TEMP_MAX_LIMIT, NTC_TEMP_MIN_LIMIT);
}

/******************************************************************************
 * log_reset_ac_tank_ntc().
 * write log of ac tank ntc restore. [Called by diag task group.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void log_reset_ac_tank_ntc(void)
{
	fault_log_record("8, minor: ac tank ntc restored, value:%d, max limt:%d, min limt:%d",
			array.pcsc.pcsc_data.var.t_ac_fuse, NTC_TEMP_MAX_LIMIT, NTC_TEMP_MIN_LIMIT);
}

/******************************************************************************
 * log_check_water_leak().
 * log of water leakage. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_water_leak(void)
{
	fault_log_record("9, major: water leaked");
}

/******************************************************************************
 * log_reset_water_leak().
 * log of water leak restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_water_leak(void)
{
	fault_log_record("9, major: water leak restored");
}

/******************************************************************************
 * log_check_door_unlock().
 * log of door unlock. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_door_unlock(void)
{
	fault_log_record("10, major: door unlock");
}

/******************************************************************************
 * log_reset_door_unlock().
 * log of door unlock. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_door_unlock(void)
{
	fault_log_record("10, major: door unlock restored");
}


/******************************************************************************
 * log_check_ac_spd().
 * log of ac spd open. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_ac_spd(void)
{
	fault_log_record("11, minor: ac spd opened");
}

/******************************************************************************
 * log_reset_dc2_spd().
 * log of ac spd open restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_ac_spd(void)
{
	fault_log_record("11, minor: ac spd open restored");
}

/******************************************************************************
 * log_check_grid_tied_pos().
 * log of grid-tied switch on failed. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_grid_tied_pos(void)
{
	fault_log_record("12, minor: grid-tied on failed");
}

/******************************************************************************
 * log_reset_grid_tied_pos().
 * log of grid-tied switch on restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_grid_tied_pos(void)
{
	fault_log_record("12, minor: grid-tied on restored");
}


/******************************************************************************
 * log_check_pcsc_fan1().
 * log of pcsc fan1 error. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_pcsc_fan1(void)
{
	fault_log_record("13, minor: fan1 errored %d, %d", array.pcsc.pcsc_ctrl.cmd.bit.fan_ctrl, array.pcsc.pcsc_data.state.state1.bit.fan1_status);
}

/******************************************************************************
 * log_reset_pcsc_fan1().
 * log of pcsc fan1 error restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_pcsc_fan1(void)
{
	fault_log_record("13, minor: fan1 error restored");
}

/******************************************************************************
 * log_check_pcsc_fan2().
 * log of pcsc fan2 error. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_pcsc_fan2(void)
{
	fault_log_record("14, minor: fan2 errored %d, %d", array.pcsc.pcsc_ctrl.cmd.bit.fan_ctrl, array.pcsc.pcsc_data.state.state1.bit.fan2_status);
}

/******************************************************************************
 * log_reset_pcsc_fan2().
 * log of pcsc fan2 error restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_pcsc_fan2(void)
{
	fault_log_record("14, minor: fan2 error restored");
}

/******************************************************************************
 * log_check_iso_dev_fail().
 * log of dev fail. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_iso_dev_fail(void)
{
	fault_log_record("15, minor: iso dev fail");
}

/******************************************************************************
 * log_reset_iso_dev_fail().
 * log of dev fail restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_iso_dev_fail(void)
{
	fault_log_record("15, minor: iso dev fail restored");
}

/******************************************************************************
 * log_check_iso_fault().
 * log of iso fault. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_iso_fault(void)
{
	fault_log_record("16, major: iso fault");
}

/******************************************************************************
 * log_check_iso_fault().
 * log of iso fault restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_iso_fault(void)
{
	fault_log_record("16, major: iso fault restored");
}

/******************************************************************************
 * log_check_cmu_fault().
 * log of cmu fault. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_cmu_fault(void)
{
	fault_log_record("17, major: CMU fault");
}

/******************************************************************************
 * log_check_cmu_fault().
 * log of cmu fault restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_cmu_fault(void)
{
	fault_log_record("17, major: CMU fault restored");
}

/******************************************************************************
 * log_check_remote_epo().
 * log of remote epo fault. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_remote_epo(void)
{
	fault_log_record("18, major: remote epo fault");
}

/******************************************************************************
 * log_check_remote_epo().
 * log of remote epo fault restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_remote_epo(void)
{
	fault_log_record("18, major: remote epo fault restored");
}

/******************************************************************************
 * log_check_ac_breaker().
 * log write when ac breaker check fault. [Called by diag task group.]
 *
 * @param  pcsm_id  	 (I) PCSM id, 1~PCSM_NUMS
 * @param  v_grid        (I) Grid side voltage of the breaker (unit V)
 * @param  v_pcsm        (I) PCSM side voltage of the breaker (unit 0.1V)
 * @param  phase_str     (I) AC phase string,"S","T"
 * @return none			 (O) none
 *****************************************************************************/
static void log_check_ac_breaker(const char *num_degree_str, uint8_t pcsm_id, float32_t *v_grid, int16_t *v_pcsm)
{
	fault_log_record("%s: PCSM%d breaker broken, grid side(R、S、T): %5.1fV/%5.1fV/%5.1fV, pcsm side(R、S、T): %5.1fV/%5.1fV/%5.1fV",\
		num_degree_str, pcsm_id, v_grid[0], v_grid[1], v_grid[2],
		((float32_t)v_pcsm[0])*PARAMETER_ACCURACY_MAGNIFICATION_4, \
		((float32_t)v_pcsm[1])*PARAMETER_ACCURACY_MAGNIFICATION_4, \
		((float32_t)v_pcsm[2])*PARAMETER_ACCURACY_MAGNIFICATION_4);
}

/******************************************************************************
 * log_reset_ac_breaker().
 * log write when ac breaker restored. [Called by diag task group.]
 *
 * @param  pcsm_id  	 (I) PCSM id, 1~PCSM_NUMS
 * @param  v_grid        (I) Grid side voltage of the fuse (unit V)
 * @param  v_pcsm        (I) PCSM side voltage of the fuse (unit 0.1V)
 * @param  phase_str     (I) AC phase string,"S","T"
 * @return none			 (O) none
 *****************************************************************************/
static void log_reset_ac_breaker(const char *num_degree_str, uint8_t pcsm_id, float32_t v_grid[3], int16_t v_pcsm[3])
{
	fault_log_record("%s: PCSM%d breaker restored, grid side(R、S、T): %5.1fV/%5.1fV/%5.1fV, pcsm side(R、S、T): %5.1fV/%5.1fV/%5.1fV",\
		num_degree_str, pcsm_id, v_grid[0], v_grid[1], v_grid[2],
		((float32_t)v_pcsm[0])*PARAMETER_ACCURACY_MAGNIFICATION_4, \
		((float32_t)v_pcsm[1])*PARAMETER_ACCURACY_MAGNIFICATION_4, \
		((float32_t)v_pcsm[2])*PARAMETER_ACCURACY_MAGNIFICATION_4);
}

/******************************************************************************
 * log_check_pcsm1_ac_breaker().
 * log of pcsm1 ac fuse phase r fault. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_pcsm1_ac_breaker(void)
{
	float32_t v_grid[3] = {g_ac_signal[VPCS_R].rms, g_ac_signal[VPCS_S].rms, g_ac_signal[VPCS_T].rms};
	int16_t v_pcsm[3] = {array.pcsc.pcsc_data.pcsm_data[0].var.grid_volt_r, \
						array.pcsc.pcsc_data.pcsm_data[0].var.grid_volt_s, \
						array.pcsc.pcsc_data.pcsm_data[0].var.grid_volt_t};

	log_check_ac_breaker("19, minor", 1, v_grid, v_pcsm);
}

/******************************************************************************
 * log_reset_pcsm1_ac_breaker().
 * log of pcsm1 ac fuse phase r fault restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_pcsm1_ac_breaker(void)
{
	float32_t v_grid[3] = {g_ac_signal[VPCS_R].rms, g_ac_signal[VPCS_S].rms, g_ac_signal[VPCS_T].rms};
	int16_t v_pcsm[3] = {array.pcsc.pcsc_data.pcsm_data[0].var.grid_volt_r, \
						array.pcsc.pcsc_data.pcsm_data[0].var.grid_volt_s, \
						array.pcsc.pcsc_data.pcsm_data[0].var.grid_volt_t};
	log_reset_ac_breaker("19, minor", 1, v_grid, v_pcsm);
}

/******************************************************************************
 * log_check_pcsm2_ac_breaker().
 * log of pcsm2 ac fuse phase r fault. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_pcsm2_ac_breaker(void)
{
	float32_t v_grid[3] = {g_ac_signal[VPCS_R].rms, g_ac_signal[VPCS_S].rms, g_ac_signal[VPCS_T].rms};
	int16_t v_pcsm[3] = {array.pcsc.pcsc_data.pcsm_data[1].var.grid_volt_r, \
						array.pcsc.pcsc_data.pcsm_data[1].var.grid_volt_s, \
						array.pcsc.pcsc_data.pcsm_data[1].var.grid_volt_t};
	log_check_ac_breaker("20, minor", 2, v_grid, v_pcsm);
}

/******************************************************************************
 * log_reset_pcsm2_ac_breaker().
 * log of pcsm2 ac fuse phase r fault restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_pcsm2_ac_breaker(void)
{
	float32_t v_grid[3] = {g_ac_signal[VPCS_R].rms, g_ac_signal[VPCS_S].rms, g_ac_signal[VPCS_T].rms};
	int16_t v_pcsm[3] = {array.pcsc.pcsc_data.pcsm_data[1].var.grid_volt_r, \
						array.pcsc.pcsc_data.pcsm_data[1].var.grid_volt_s, \
						array.pcsc.pcsc_data.pcsm_data[1].var.grid_volt_t};
	log_reset_ac_breaker("20, minor", 2, v_grid, v_pcsm);
}

/******************************************************************************
 * log_check_pcsm3_ac_breaker().
 * log of pcsm3 ac fuse phase R fault. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_pcsm3_ac_breaker(void)
{
	float32_t v_grid[3] = {g_ac_signal[VPCS_R].rms, g_ac_signal[VPCS_S].rms, g_ac_signal[VPCS_T].rms};
	int16_t v_pcsm[3] = {array.pcsc.pcsc_data.pcsm_data[2].var.grid_volt_r, \
						array.pcsc.pcsc_data.pcsm_data[2].var.grid_volt_s, \
						array.pcsc.pcsc_data.pcsm_data[2].var.grid_volt_t};
	log_check_ac_breaker("21, minor", 3, v_grid, v_pcsm);
}

/******************************************************************************
 * log_reset_pcsm3_ac_breaker().
 * log of pcsm3 ac fuse phase R fault restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_pcsm3_ac_breaker(void)
{
	float32_t v_grid[3] = {g_ac_signal[VPCS_R].rms, g_ac_signal[VPCS_S].rms, g_ac_signal[VPCS_T].rms};
	int16_t v_pcsm[3] = {array.pcsc.pcsc_data.pcsm_data[2].var.grid_volt_r, \
						array.pcsc.pcsc_data.pcsm_data[2].var.grid_volt_s, \
						array.pcsc.pcsc_data.pcsm_data[2].var.grid_volt_t};
	log_reset_ac_breaker("21, minor", 3, v_grid, v_pcsm);
}


/******************************************************************************
 * log_check_pcsm4_ac_breaker().
 * log of pcsm4 ac fuse phase r fault. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_pcsm4_ac_breaker(void)
{
	float32_t v_grid[3] = {g_ac_signal[VPCS_R].rms, g_ac_signal[VPCS_S].rms, g_ac_signal[VPCS_T].rms};
	int16_t v_pcsm[3] = {array.pcsc.pcsc_data.pcsm_data[3].var.grid_volt_r, \
						array.pcsc.pcsc_data.pcsm_data[3].var.grid_volt_s, \
						array.pcsc.pcsc_data.pcsm_data[3].var.grid_volt_t};
	log_check_ac_breaker("22, minor", 4, v_grid, v_pcsm);
}

/******************************************************************************
 * log_reset_pcsm4_ac_breaker().
 * log of pcsm4 ac fuse phase r fault restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_pcsm4_ac_breaker(void)
{
	float32_t v_grid[3] = {g_ac_signal[VPCS_R].rms, g_ac_signal[VPCS_S].rms, g_ac_signal[VPCS_T].rms};
	int16_t v_pcsm[3] = {array.pcsc.pcsc_data.pcsm_data[3].var.grid_volt_r, \
						array.pcsc.pcsc_data.pcsm_data[3].var.grid_volt_s, \
						array.pcsc.pcsc_data.pcsm_data[3].var.grid_volt_t};
	log_reset_ac_breaker("22, minor", 4, v_grid, v_pcsm);
}


/******************************************************************************
 * log_check_pcsm5_ac_breaker().
 * log of pcsm5 ac fuse phase R fault. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_pcsm5_ac_breaker(void)
{
	float32_t v_grid[3] = {g_ac_signal[VPCS_R].rms, g_ac_signal[VPCS_S].rms, g_ac_signal[VPCS_T].rms};
	int16_t v_pcsm[3] = {array.pcsc.pcsc_data.pcsm_data[4].var.grid_volt_r, \
						array.pcsc.pcsc_data.pcsm_data[4].var.grid_volt_s, \
						array.pcsc.pcsc_data.pcsm_data[4].var.grid_volt_t};
	log_check_ac_breaker("23, minor", 5, v_grid, v_pcsm);
}

/******************************************************************************
 * log_reset_pcsm5_ac_breaker().
 * log of pcsm5 ac fuse phase r fault restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_pcsm5_ac_breaker(void)
{
	float32_t v_grid[3] = {g_ac_signal[VPCS_R].rms, g_ac_signal[VPCS_S].rms, g_ac_signal[VPCS_T].rms};
	int16_t v_pcsm[3] = {array.pcsc.pcsc_data.pcsm_data[4].var.grid_volt_r, \
						array.pcsc.pcsc_data.pcsm_data[4].var.grid_volt_s, \
						array.pcsc.pcsc_data.pcsm_data[4].var.grid_volt_t};
	log_reset_ac_breaker("23, minor", 5, v_grid, v_pcsm);
}

/******************************************************************************
 * log_check_pcsm6_ac_breaker().
 * log of pcsm6 ac fuse phase r fault. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_pcsm6_ac_breaker(void)
{
	float32_t v_grid[3] = {g_ac_signal[VPCS_R].rms, g_ac_signal[VPCS_S].rms, g_ac_signal[VPCS_T].rms};
	int16_t v_pcsm[3] = {array.pcsc.pcsc_data.pcsm_data[5].var.grid_volt_r, \
						array.pcsc.pcsc_data.pcsm_data[5].var.grid_volt_s, \
						array.pcsc.pcsc_data.pcsm_data[5].var.grid_volt_t};
	log_check_ac_breaker("24, minor", 6, v_grid, v_pcsm);
}

/******************************************************************************
 * log_reset_pcsm6_ac_breaker().
 * log of pcsm6 ac fuse phase r fault restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_pcsm6_ac_breaker(void)
{
	float32_t v_grid[3] = {g_ac_signal[VPCS_R].rms, g_ac_signal[VPCS_S].rms, g_ac_signal[VPCS_T].rms};
	int16_t v_pcsm[3] = {array.pcsc.pcsc_data.pcsm_data[5].var.grid_volt_r, \
						array.pcsc.pcsc_data.pcsm_data[5].var.grid_volt_s, \
						array.pcsc.pcsc_data.pcsm_data[5].var.grid_volt_t};
	log_reset_ac_breaker("24, minor", 6, v_grid, v_pcsm);
}

/******************************************************************************
 * log_check_pcsm1_can1().
 * log of pcsm1 can1 comm. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_pcsm1_can1(void)
{
	fault_log_record("25, major: PCSM1 can1 comm loss");
}

/******************************************************************************
 * log_check_pcsm2_can1().
 * log of pcsm2 can1 comm. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_pcsm2_can1(void)
{
	fault_log_record("26, major: PCSM2 can1 comm loss");
}

/******************************************************************************
 * log_check_pcsm3_can1().
 * log of pcsm3 can1 comm. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_pcsm3_can1(void)
{
	fault_log_record("27, major: PCSM3 can1 comm loss");
}

/******************************************************************************
 * log_check_pcsm4_can1().
 * log of pcsm4 can1 comm. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_pcsm4_can1(void)
{
	fault_log_record("28, major: PCSM4 can1 comm loss");
}

/******************************************************************************
 * log_check_pcsm5_can1().
 * log of pcsm5 can1 comm. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_pcsm5_can1(void)
{
	fault_log_record("29, major: PCSM5 can1 comm loss");
}

/******************************************************************************
 * log_check_pcsm6_can1().
 * log of pcsm6 can1 comm. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_pcsm6_can1(void)
{
	fault_log_record("30, major: PCSM6 can1 comm loss");
}

/******************************************************************************
 * log_reset_pcsm1_can1().
 * log of pcsm1 can1 comm. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_pcsm1_can1(void)
{
	fault_log_record("25, major: PCSM1 can1 comm restores");
}

/******************************************************************************
 * log_reset_pcsm2_can1().
 * log of pcsm2 can1 comm. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_pcsm2_can1(void)
{
	fault_log_record("26, major: PCSM2 can1 comm restores");
}

/******************************************************************************
 * log_reset_pcsm3_can1().
 * log of pcsm3 can1 comm. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_pcsm3_can1(void)
{
	fault_log_record("27, major: PCSM3 can1 comm restores");
}

/******************************************************************************
 * log_reset_pcsm4_can1().
 * log of pcsm4 can1 comm. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_pcsm4_can1(void)
{
	fault_log_record("28, major: PCSM4 can1 comm restores");
}

/******************************************************************************
 * log_reset_pcsm5_can1().
 * log of pcsm5 can1 comm. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_pcsm5_can1(void)
{
	fault_log_record("29, major: PCSM5 can1 comm restores");
}

/******************************************************************************
 * log_reset_pcsm6_can1().
 * log of pcsm6 can1 comm. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_pcsm6_can1(void)
{
	fault_log_record("30, major: PCSM6 can1 comm restores");
}

/******************************************************************************
 * log_check_metering_meter().
 * log of metering meter error. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_metering_meter(void)
{
	fault_log_record("31, minor: metering meter error. value:%d, set:%d",
							fault_metering_meter_cnt, fault_metering_meter_ref);
}

/******************************************************************************
 * log_reset_metering_meter().
 * log of metering meter restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_metering_meter(void)
{
	fault_log_record("31, minor: metering meter restored. value:%d, set:%d",
							fault_metering_meter_cnt, fault_metering_meter_ref);
}

/******************************************************************************
 * log_check_backflow_meter().
 * log of backflow meter error. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_backflow_meter(void)
{
	fault_log_record("32, minor: backflow meter error. value:%d, set:%d",
							fault_backflow_meter_cnt, fault_backflow_meter_ref);
}
/******************************************************************************
 * log_reset_backflow_meter().
 * log of backflow meter restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_backflow_meter(void)
{
	fault_log_record("32, minor: backflow meter restored. value:%d, set:%d",
							fault_backflow_meter_cnt, fault_backflow_meter_ref);
}

/******************************************************************************
 * log_check_microcomputer().
 * log of microcomputer error. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_microcomputer(void)
{
	fault_log_record("33, minor: microcomputer error. value:%d, set:%d",
							fault_microcomputer_cnt, fault_microcomputer_ref);
}

/******************************************************************************
 * log_reset_microcomputer().
 * log of microcomputer restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_microcomputer(void)
{
	fault_log_record("33, minor: microcomputer restored. value:%d, set:%d",
							fault_microcomputer_cnt, fault_microcomputer_ref);
}

/******************************************************************************
 * log_check_dehumidifier().
 * log of dehumidifier error. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_dehumidifier(void)
{
	fault_log_record("34, minor: dehumidifier error. value:%d, set:%d",
								fault_dehumidifier_cnt, fault_dehumidifier_ref);
}

/******************************************************************************
 * log_reset_dehumidifier().
 * log of dehumidifier restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_dehumidifier(void)
{
	fault_log_record("34, minor: dehumidifier restored. value:%d, set:%d",
								fault_dehumidifier_cnt, fault_dehumidifier_ref);
}

/******************************************************************************
 * log_check_measure_control().
 * log of measure control error. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_measure_control(void)
{
	fault_log_record("35, minor: measure control error. value:%d, set:%d",
										fault_measure_cnt, fault_measure_ref);
}

/******************************************************************************
 * log_reset_measure_control().
 * log of measure control restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_measure_control(void)
{
	fault_log_record("35, minor: measure control restored. value:%d, set:%d",
										fault_measure_cnt, fault_measure_ref);
}

/******************************************************************************
 * log_check_model_read().
 * log of model read error. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_model_read(void)
{
	uint8_t sn[PCSM_NUMS][8];
	uint8_t i;

	for (i = 0; i < PCSM_NUMS; i++)
	{
		memcpy(&sn[i][0], &array.pcsc.pcsc_data.pcsm_data[i].constant.sn2, 8);
	}
	
	fault_log_record("36, minor: pcsm model read error %s,%s,%s,%s,%s,%s", sn[0], sn[1], sn[2], sn[3], sn[4], sn[5]);
}

/******************************************************************************
 * log_reset_model_read().
 * log of model read restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_model_read(void)
{
	uint8_t sn[PCSM_NUMS][8];
	uint8_t i;

	for (i = 0; i < PCSM_NUMS; i++)
	{
		memcpy(&sn[i][0], &array.pcsc.pcsc_data.pcsm_data[i].constant.sn2, 8);
	}
	fault_log_record("36, minor: pcsm model read restored %s,%s,%s,%s,%s,%s", sn[0], sn[1], sn[2], sn[3], sn[4], sn[5]);
}

/******************************************************************************
 * log_check_anti_backflow().
 * log of model read error. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_anti_backflow(void)
{
	fault_log_record("37, minor: anti-backflow error. value:%d, set:%d",
							fault_anti_backflow_cnt, fault_anti_backflow_ref);
}

/******************************************************************************
 * log_reset_anti_backflow().
 * log of model read restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_anti_backflow(void)
{
	fault_log_record("37, minor: anti-backflow restored. value:%d, set:%d",
							fault_anti_backflow_cnt, fault_anti_backflow_ref);
}

/******************************************************************************
 * log_check_sts_sw_pos().
 * log of sts switch failed. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_sts_sw_pos(void)
{
	fault_log_record("38, minor: sts switch on error");
}

/******************************************************************************
 * log_reset_sts_sw_pos().
 * log of sts switch restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_sts_sw_pos(void)
{
	fault_log_record("38, minor: sts switch on restored");
}


/******************************************************************************
 * log_check_bypass_fault().
 * log of bypass switch error. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_bypass_fault(void)
{
	fault_log_record( "39, minor: bypass status error, qf2 = %d, qf3 = %d", \
			array.pcsc.pcsc_data.state.state2.bit.qf2_status, \
			array.pcsc.pcsc_data.state.state1.bit.qf3_status);
}

/******************************************************************************
 * log_reset_bypass_fault().
 * log of bypass switch restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_bypass_fault(void)
{
	fault_log_record("39, minor: bypass status restored, qf2 = %d, qf3 = %d", \
			array.pcsc.pcsc_data.state.state2.bit.qf2_status, \
			array.pcsc.pcsc_data.state.state1.bit.qf3_status);
}

/******************************************************************************
 * log_check_spd1_status().
 * log of spd1 status error. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_spd1_status(void)
{
	fault_log_record("40, minor: spd1 status error");
}

/******************************************************************************
 * log_reset_spd1_status().
 * log of spd1 status restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_spd1_status(void)
{
	fault_log_record( "40, minor: spd1 status restored");
}

/******************************************************************************
 * log_check_spd2_status().
 * log of spd2 status error. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_spd2_status(void)
{
	fault_log_record("41, minor: spd2 status error");
}

/******************************************************************************
 * log_reset_spd2_status().
 * log of spd2 status restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_spd2_status(void)
{
	fault_log_record("41, minor: spd2 status restored");
}

/******************************************************************************
 * log_check_qf1_status().
 * log of qf1 status error. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_qf1_status(void)
{
	fault_log_record("42, minor: qf1 status error, cmd = %d, sta = %d", \
			array.pcsc.pcsc_ctrl.do_ctrl.bit.grid_tied_sw_qf1_on, \
			array.pcsc.pcsc_data.state.state2.bit.qf1_status);
}

/******************************************************************************
 * log_reset_qf1_status().
 * log of qf1 status restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_qf1_status(void)
{
	fault_log_record("42, minor: qf1 status restored, cmd = %d, sta = %d", \
			array.pcsc.pcsc_ctrl.do_ctrl.bit.grid_tied_sw_qf1_on, \
			array.pcsc.pcsc_data.state.state2.bit.qf1_status);
}

/******************************************************************************
 * log_check_meter2().
 * log of metering meter error. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_meter2(void)
{
	fault_log_record("43, minor: metering meter2 error. value:%d, set:%d",
											fault_meter2_cnt, fault_meter2_ref);
}

/******************************************************************************
 * log_reset_meter2().
 * log of metering meter restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_meter2(void)
{
	fault_log_record("43, minor: metering meter2 restored. value:%d, set:%d",
											fault_meter2_cnt, fault_meter2_ref);
}

/******************************************************************************
 * log_check_meter3().
 * log of metering meter error. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_meter3_1(void)
{
	fault_log_record("44, minor: metering meter3 1 error. value:%d, set:%d",
											fault_meter3_cnt[0], fault_meter3_ref);
}

/******************************************************************************
 * log_reset_meter3().
 * log of metering meter restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_meter3_1(void)
{
	fault_log_record("44, minor: metering meter3 1 restored. value:%d, set:%d",
												fault_meter3_cnt[0], fault_meter3_ref);
}

/******************************************************************************
 * log_check_meter3().
 * log of metering meter error. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_meter3_2(void)
{
	fault_log_record("45, minor: metering meter3 2 error. value:%d, set:%d",
											fault_meter3_cnt[1], fault_meter3_ref);
}

/******************************************************************************
 * log_reset_meter3().
 * log of metering meter restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_meter3_2(void)
{
	fault_log_record("45, minor: metering meter3 2 restored. value:%d, set:%d",
												fault_meter3_cnt[1], fault_meter3_ref);
}
/******************************************************************************
 * log_check_meter3().
 * log of metering meter error. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_meter3_3(void)
{
	fault_log_record("46, minor: metering meter3 3 error. value:%d, set:%d",
											fault_meter3_cnt[2], fault_meter3_ref);
}

/******************************************************************************
 * log_reset_meter3().
 * log of metering meter restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_meter3_3(void)
{
	fault_log_record("46, minor: metering meter3 3 restored. value:%d, set:%d",
												fault_meter3_cnt[2], fault_meter3_ref);
}
/******************************************************************************
 * log_check_meter3().
 * log of metering meter error. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_meter3_4(void)
{
	fault_log_record("47, minor: metering meter3 4 error. value:%d, set:%d",
											fault_meter3_cnt[3], fault_meter3_ref);
}

/******************************************************************************
 * log_reset_meter3().
 * log of metering meter restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_meter3_4(void)
{
	fault_log_record("47, minor: metering meter3 4 restored. value:%d, set:%d",
												fault_meter3_cnt[3], fault_meter3_ref);
}
/******************************************************************************
 * log_check_meter3().
 * log of metering meter error. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_meter3_5(void)
{
	fault_log_record("48, minor: metering meter3 5 error. value:%d, set:%d",
											fault_meter3_cnt[4], fault_meter3_ref);
}

/******************************************************************************
 * log_reset_meter3().
 * log of metering meter restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_meter3_5(void)
{
	fault_log_record("48, minor: metering meter3 5 restored. value:%d, set:%d",
												fault_meter3_cnt[4], fault_meter3_ref);
}

/******************************************************************************
 * log_check_pv_meter().
 * log of metering meter error. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_pv_meter_1(void)
{
	fault_log_record("49, minor: pv meter 1 error. value:%d, set:%d",
											fault_pv_meter_cnt[0], fault_pv_meter_ref);
}

/******************************************************************************
 * log_reset_pv_meter().
 * log of metering meter restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_pv_meter_1(void)
{
	fault_log_record("49, minor: pv meter 1 restored. value:%d, set:%d",
												fault_pv_meter_cnt[0], fault_pv_meter_ref);
}

/******************************************************************************
 * log_check_pv_meter().
 * log of metering meter error. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_pv_meter_2(void)
{
	fault_log_record("50, minor: pv meter 2 error. value:%d, set:%d",
											fault_pv_meter_cnt[1], fault_pv_meter_ref);
}

/******************************************************************************
 * log_reset_pv_meter().
 * log of metering meter restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_pv_meter_2(void)
{
	fault_log_record("50, minor: pv meter 2 restored. value:%d, set:%d",
												fault_pv_meter_cnt[1], fault_pv_meter_ref);
}

/******************************************************************************
 * log_check_pv_meter().
 * log of metering meter error. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_check_pv_meter_3(void)
{
	fault_log_record("51, minor: pv meter 3 error. value:%d, set:%d",
											fault_pv_meter_cnt[2], fault_pv_meter_ref);
}

/******************************************************************************
 * log_reset_pv_meter().
 * log of metering meter restored. [Called by diag task group.]
 *
 * @param  none   (I)
 * @return result (O)
 *****************************************************************************/
void log_reset_pv_meter_3(void)
{
	fault_log_record("51, minor: pv meter 3 restored. value:%d, set:%d",
												fault_pv_meter_cnt[2], fault_pv_meter_ref);
}
/******************************************************************************
* End of module
******************************************************************************/
