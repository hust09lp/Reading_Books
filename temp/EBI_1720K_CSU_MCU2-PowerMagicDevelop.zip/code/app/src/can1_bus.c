/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     can1 bus.c
  * @brief    can1 bus module
  * @company  SOFARSOLAR
  * @author   WWX
  * @note
  * @version  V02
  * @date     2023/03/07
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "can1_bus.h"
#include "cup_sofar_can.h"
#include "pcs.h"
#include "device.h"
#include "array.h"
#include "pcsc_opt_log.h"
#include "power_manage.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
sdk_os_mutex_attr_t  can1_mutex;
sdk_os_mutex_id_t    can1_busy;
static uint8_t recv_data[CAN_SOFAR_SEND_MAXNUMS] = {'\0'};
bool_t pcs_sn_analysis_success[PCSM_NUMS];

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/
/******************************************************************************
 * can1_bus_init().
 * Initialized can1 bus. [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void can1_bus_init(void)
{
	uint8_t ret;
	sdk_can_cfg_t can_config;

	can1_mutex.name = (const int8_t *)"can1_mutex";
	can1_busy = sdk_os_mutex_new(&can1_mutex);
	ret = sdk_os_mutex_release(can1_busy);
	if(ret != SDK_OS_OK)
	{
		sdk_log_d("sdk_os_mutex_release fail:%d", ret);
	}

	can_config.baud = SDK_CAN_BAUD_500K;
	can_config.mode = SDK_CAN_MODE_NORMAL;

	ret = sdk_can_open(CAN1_PORT);
	if(ret != 0)
	{
		sdk_log_d("CAN1 open failed!\r\n");
		return ;
	}
	ret = sdk_can_setup(CAN1_PORT, &can_config);
	if(ret != 0)
	{
		sdk_log_d("CAN1 setup failed!\r\n");
		return ;
	}
	ret = cup_sofar_can_init();
	if(ret != 0)
	{
		sdk_log_d("cup_sofar_can_init failed\r\n");
		return ;
	}
}

/******************************************************************************
 * can1_pcs_data_parse().
 * parse PCS CAN1 data frame. [Called by the can1_parse()]
 *
 * @param can_id (I)  the can frame id
 * @param p_data (I)  the can frame data
 * @param len    (I)  the can frame data bytes length
 * @param none   (O)
 * @return none
 *****************************************************************************/
static void can1_pcs_data_parse(can_id_t *can_id, uint8_t *p_data, int32_t *len)
{
	bool_t parse_flag = FALSE;
	uint8_t fun_code;
	uint8_t device_id;
	uint8_t *p_dst_data = NULL;
	device_heart_t *pcs_heart;
	bool_t valid;
	uint16_t offset;

	if((can_id == NULL) ||
		(p_data == NULL) ||
		(len    == NULL))
	{
		return;
	}

	fun_code  = can_id->fun_code;
	device_id = can_id->src_addr - 1;
	check_uint8_validity(device_id, 0, PCSM_NUMS - 1, &valid);

	if (valid == TRUE)
	{
		switch(fun_code)
		{
			case AUTO_HEART_BEAT:
				pcs_heart = &heart_pcs[device_id];
				offset = 0;
				pcs_heart->got = TRUE;
				pcs_heart->id = can_id->src_addr;
				if(heart_pcs[device_id].online)
				{
					p_dst_data = (uint8_t *)&array.pcsc.pcsc_data.pcsm_data[device_id].state;
					parse_flag = TRUE;
				}
				heart_check_cnt[device_id]++;
				break;
			case PCS_CMD_GET_DEVICE_INFO:
				if(can_id->addr < PCSM_DEVICE_INFO_LENGTH_1)
				{
					p_dst_data = (uint8_t *)&array.pcsc.pcsc_data.pcsm_data[device_id].constant.sn1;
					offset = 2 * (can_id->addr - PCSM_POINT_TABLE_OFFSET_1);
					*len = min(*len, (2 * PCSM_DEVICE_INFO_LENGTH_1) - offset);
					if(can_id->addr == PCS_SN)
					{
						g_trigger_sn_analysis = TRUE;
					}
					parse_flag = TRUE;
				}
				else if((can_id->addr >= PCSM_POINT_TABLE_OFFSET_2) && \
						(can_id->addr < PCSM_POINT_TABLE_OFFSET_2 + PCSM_DEVICE_INFO_LENGTH_2))
				{
					p_dst_data = (uint8_t *)&array.pcsc.pcsc_data.pcsm_data[device_id].constant.slv_fw_version1;
					offset = 2 * (can_id->addr - PCSM_POINT_TABLE_OFFSET_2);
					*len = min(*len, (2 * PCSM_DEVICE_INFO_LENGTH_2) - offset);
					parse_flag = TRUE;
				}
				break;
			case PCS_CMD_GET_PARAMETER:
				if(can_id->addr < PCSM_PARAMETER_LENGTH_1)
				{
					p_dst_data = (uint8_t *)&array.pcsc.pcsc_data.pcsm_data[device_id].set[READ_INDEX];
					offset = 2 * (can_id->addr - PCSM_POINT_TABLE_OFFSET_1);
					*len = min(*len, (2 * PCSM_PARAMETER_LENGTH_1) - offset);
					parse_flag = TRUE;
				}
				break;
			default:
				parse_flag = FALSE;
				break;
		}

		if((parse_flag) && (p_dst_data != NULL))
		{
			memcpy(&p_dst_data[offset], p_data, *len);
		}
		else
		{
			// TODO log parse fail
		}
	}
	else
	{
		// TODO log device id invalid
		sdk_log_d("device id invalid");
	}
}

/******************************************************************************
 * can1_parse().
 * parse CAN module. [Called by the fast_task_can1_parse()]
 *
 * @param can_id (I)  the can frame id
 * @param p_data (I)  the can frame data
 * @param len    (I)  the can frame data bytes length
 * @return none
 *****************************************************************************/
static void can1_parse(can_id_t *can_id, uint8_t *p_data, int32_t *len)
{
	switch(can_id->type)
	{
		case DATA_FRAME:
			can1_pcs_data_parse(can_id, p_data, len);
			break;
		default:
			break;
	}
}

/******************************************************************************
 * thread_can1_parse().
 * parse CAN module. [Called by the thread()]
 *
 * @param none (I)
 * @param none (O)
 * @return none
 *****************************************************************************/
void thread_can1_parse(void *argument)
{
	int32_t len;
	can_id_t can_id;
	uint8_t ret;

	while(1)
	{
		ret = cup_sofar_can_rev(CAN1_PORT, 10, &can_id, &recv_data[0], &len);
		if(ret == CAN_DATA_COMPLETE)
		{
			//cup_sofar_can_send(CAN5_PORT, &can_id, recv_data, &len);
			can1_parse(&can_id, &recv_data[0], &len);
		}
	}
}

/******************************************************************************
* End of module
******************************************************************************/
