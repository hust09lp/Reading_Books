/******************************************************************************
 * FILE IDENTIFICATION
 ******************************************************************************/
/**
 * @file     calibration.h
 * @brief    Calibration functional module header file
 * @company  SOFARSOLAR
 * @author   WWX
 * @note
 * @version  V01
 * @date     2023/05/19
 */
/*****************************************************************************/

#ifndef CALIBRATION_H
#define CALIBRATION_H

/******************************************************************************
 * INCLUDE FILE
 ******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "common.h"
#include "measure.h"

/******************************************************************************
 * DEFINE DESCRIPTION
 ******************************************************************************/
// fuse : a & b are calculated by circuit digram
// r1 = 15K, r2 = 150K, NTC x is parallel to r2
// 1/Y = gain/X + offset (Y: ADC value，X: resistance value)
// gain   = 15 / (1.1 * 4095) = 0.00333
// offset = 1 / 4095 = 0.0002442
#define TEMP_GAIN                                            (float32_t)0.00333
#define TEMP_OFFSET                                        (float32_t)0.0002442

// VBUS1 & VBUS2
// y : vout, x: vin
// y = a*x + b
// a = 0.00164, b = 0.32
// Y = X/gain + offset (Y: ADC value, X: vin)
// gain = 1/((4095/3)*0.00164) = 0.446708
// offset = (4095/3)*0.32 = 436.8
#define AC_VOLT_GAIN                                      (float32_t)0.46461557
#define AC_CURRENT_GAIN                                       (float32_t)0.125f
#define AC_POWER_GAIN                                            (float32_t)1.0
// VGRID & VPCS RN,RS,RT
// Y = X / gain (Y: simple value, X: vin true)
// gain = 1.0


/******************************************************************************
 * ENUM DESCRIPTION
 ******************************************************************************/
typedef enum
{
	CALI_AC_FUSE_TEMP = 0,
	CALI_RESERVE_1,
	CALI_RESERVE_2,
	CALI_VBUS1,
	CALI_VBUS2,
	CALI_DC_LEN
} cali_dc_type_e;

typedef enum
{
	CALI_VGRID_RS = 0,
	CALI_VGRID_ST,
	CALI_VGRID_TR,
	CALI_VPCS_RS,
	CALI_VPCS_ST,
	CALI_VPCS_TR,
	CALI_CURRENT_R,
	CALI_CURRENT_S,
	CALI_CURRENT_T,
	CALI_POWER_P,
	CALI_POWER_Q,
	CALI_POWER_S,
	CALI_AC_LEN
} cali_ac_type_e;

/******************************************************************************
 * STRUCTURE DESCRIPTION
 ******************************************************************************/
typedef struct
{
	uint32_t ac_fuse_temp : 1;
	uint32_t dc1_fuse_temp : 1;
	uint32_t dc2_fuse_temp : 1;
	uint32_t vbus1 : 1;
	uint32_t vbus2 : 1;
	uint32_t vgrid_rs : 1;
	uint32_t vgrid_st : 1;
	uint32_t vgrid_tr : 1;
	uint32_t vpcs_rs : 1;
	uint32_t vpcs_st : 1;
	uint32_t vpcs_tr : 1;
	uint32_t current_r : 1;
	uint32_t current_s : 1;
	uint32_t current_t : 1;
	uint32_t power_p : 1;
	uint32_t power_q : 1;
	uint32_t power_s : 1;
	uint32_t rsvd : 15;
} cali_sts_bits_t;

typedef union
{
	cali_sts_bits_t bit;
	uint16_t half_word[2];
	uint32_t all;
} cali_status_t;

typedef struct
{
	float32_t gain;
	float32_t offset;
	float32_t x1; // meter minimum value
	float32_t x2; // meter maximum value
	uint16_t y1;  // sample digital value of x1(0~65535)
	uint16_t y2;  // sample digital value of x2(0~65535)
} cali_dc_t;

typedef struct
{
	float32_t gain;
	float32_t x; // meter minimum value
	float32_t y; // sample value
} cali_ac_t;

typedef struct
{
	cali_status_t status;      // calibration status word
	cali_dc_t dc[CALI_DC_LEN];
	cali_ac_t ac[CALI_AC_LEN];
} calibration_t;

typedef struct
{
	uint16_t addr;	   // EEPROM internal address
	float32_t min;	   // minimun value
	float32_t max;	   // maximun value
	float32_t def; // default value
} set_value_float32_t;

/******************************************************************************
 * EXTERN CONSTANT DESCRIPTION
 ******************************************************************************/
extern const set_value_float32_t t_gain_table[];
extern const set_value_float32_t t_offset_table[];
extern const set_value_float32_t v_gain_table[];
extern const set_value_float32_t v_offset_table[];
extern const set_value_float32_t vbus_gain_table[];
extern const set_value_float32_t vbus_offset_table[];

/******************************************************************************
 * EXTERN VARIABLE DESCRIPTION
 ******************************************************************************/
extern calibration_t calibrate;

/******************************************************************************
 * EXTERN FUNCTION PROTOTYPE
 ******************************************************************************/
void calibration_init(void);
bool_t calibrate_dc(cali_dc_type_e type);
bool_t calibrate_ac(cali_ac_type_e type);

#endif
/******************************************************************************
 * End of module
 ******************************************************************************/
