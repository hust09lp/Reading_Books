/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     app_dido.h
  * @brief    App DI&DO management module header file
  * @company  SOFARSOLAR
  * @author   HH
  * @note
  * @version  V01
  * @date     2023/03/09
  */
/*****************************************************************************/

#ifndef __APP_DIDO_H__
#define __APP_DIDO_H__

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "common.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define		SDK_PWM_0                                                       (0)

#define		DO1_RSVD                                                        (0)
#define		DO2_STS_SW_ON                                                   (1)
#define		DO3_GRID_TIED_SW_QF1_ON                                         (2)
#define		DO4_GRID_TIED_SW_QF1_OFF                                        (3)
#define		DO6_STS_SW_OFF                                                  (4)
#define		DO8_SELA                                                        (5)
#define		DO9_SELB                                                        (6)

#define		DI1_WATER_IN                                                    (0)
#define		DI2_DOOR                                                        (1)
#define     DI3_STS_SW_ON                                                   (2)
#define     DI4_STS_SW_OFF                                                  (3)
#define     DI5_QF3_STATUS                                                  (4)
#define     DI6_SPD1_STATUS                                                 (5)
#define		DI7_AC_SPD                                                      (6)
#define     DI8_SPD2_STATUS                                                 (7)
#define		DI9_GRID_TIED_SW_ON_QF1                                         (8)
#define		DI10_GRID_TIED_SW_OFF_QF2                                       (9)
#define		DI11_FAN1_STATUS                                               (10)
#define		DI12_FAN2_STATUS                                               (11)
#define		DI13_ISO_DEVICE_FAULT                                          (12)
#define		DI14_ISO_FAULT                                                 (13)
#define		DI15_CMU_FAULT                                                 (14)
#define		DI16_REMOTE_EPO                                                (15)

#define		DI_QA0                                                          (2)
#define		DI_QA1                                                          (3)
#define		DI_QA2                                                          (4)
#define		DI_QA3                                                          (5)
#define		DI_QA4                                                          (7)
#define		DI_QA5                                                          (8)
#define		DI_QA6                                                          (9)

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
enum
{
    FAN_OFF = 0,  
    FAN_ON = 1,
};
typedef enum
{
	DI_MASK_RUNNING_STATE,
	DI_MASK_WATER_IN,
	DI_MASK_DOOR,
	DI_MASK_STS_SW_ON,
	DI_MASK_STS_SW_OFF,
	DI_MASK_QF3_STATUS,
	DI_MASK_SPD1_STATUS,
	DI_MASK_AC_SPD,
	DI_MASK_SPD2_STATUS,
	DI_MASK_GRID_TIED_SW_ON_QF1,
	DI_MASK_GRID_TIED_SW_OFF_QF2,
	DI_MASK_FAN1_STATUS,
	DI_MASK_FAN2_STATUS,
	DI_MASK_ISO_DEVICE_FAULT,
	DI_MASK_ISO_FAULT,
	DI_MASK_CMU_FAULT,
}DI_MASK_1_E;
typedef enum
{
	DI_MASK_REMOTE_EPO,
	DI_MASK_QF1,
	DI_MASK_QF2,
	DI_MASK_QA0,
	DI_MASK_QA1,
	DI_MASK_QA2,
	DI_MASK_QA3,
	DI_MASK_QA4,
	DI_MASK_QA5,
	DI_MASK_QA6,
	DO_MASK_FAN,
}DI_MASK_2_E;
/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/
typedef struct 
{
	uint16_t dido_1  : 1;
	uint16_t dido_2  : 1;
	uint16_t dido_3  : 1;
	uint16_t dido_4  : 1;
	uint16_t dido_5  : 1;
	uint16_t dido_6  : 1;
	uint16_t dido_7  : 1;
	uint16_t dido_8  : 1;
	uint16_t dido_9  : 1;
	uint16_t dido_10 : 1;
	uint16_t dido_11 : 1;
	uint16_t dido_12 : 1;
	uint16_t dido_13 : 1;
	uint16_t dido_14 : 1;
	uint16_t dido_15 : 1;
	uint16_t dido_16 : 1;
}temp_state_bits_t;

typedef union 
{
	uint16_t all;
	temp_state_bits_t bit;
}temp_state_t;

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/
extern bool_t grid_tied_sw_on_cmd;
extern bool_t grid_tied_sw_off_cmd;
extern bool_t sts_sw_on_cmd;
extern bool_t sts_sw_off_cmd;
extern uint16_t *di_mask[2];
extern bool_t trigger_di;
extern bool_t trigger_do;

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void app_dido_init(void);
void pwm_init(void);

void slow_task_di(void);
void slow_task_do(void);

#endif
/******************************************************************************
* End of module
******************************************************************************/
