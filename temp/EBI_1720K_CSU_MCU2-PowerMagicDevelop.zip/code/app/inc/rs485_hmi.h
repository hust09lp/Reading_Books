/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     rs485_hmi.h
  * @brief    HMI debug module header file
  * @company  SOFARSOLAR
  * @author   WWX
  * @note
  * @version  V01
  * @date     2023/03/09
  */
/*****************************************************************************/

#ifndef __RS485_HMI_H__
#define __RS485_HMI_H__

 /******************************************************************************
 * INCLUDE FILE
 ******************************************************************************/
 // Include system file -------------------------------------------------------

 // Include project file ------------------------------------------------------
#include "common.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define HMI_PCSM_BCAST_ID                                                  0xFF
#define HMI_PCSM_GROUP1_ID                                                 0xFE
#define HMI_PCSM_GROUP2_ID                                                 0xFD

#define TEST_START_REGS_ADDR                                                  0
#define TEST_END_REGS_ADDR                                                 1300 

#define PCSM_SET_START_REGS_ADDR                                            400
#define PCSM_SET_END_REGS_ADDR                                              560
#define PCSM_FAULT_STATE_START_REGS_ADDR                                    560
#define PCSM_FAULT_STATE_END_REGS_ADDR                                      880
#define PCSC_SET_PCMD_ADDR                                                  888
#define PCSC_SET_ONOFF_ADDR                                                 889
#define PCSC_SET_PWM_ADDR                                                   890
#define PCSC_SET_OPT_MODE_ADDR                                              891
#define PCSC_SET_BUS_VOLT_REF_ADDR                                          892
#define PCSC_SET_RESET_CMD_ADDR                                             893
#define PCSC_STATE_START_REGS_ADDR                                          900
#define PCSC_STATE_END_REGS_ADDR                                            920
#define PCSM_GROUP_SET_ADDR                                                 930
#define CSU_HMI_COMM_LED_REG_ADDR                                           949
#define PCS_SYS_RT_DATA_ADDR                                               1000
#define PCS_SYS_ENERGY_CLEAR_ADDR                                          1050

// Real time AD/true value
#define CALIB_STATE_ADDR                                                   1051
#define RT_ADC_T_BOARD_ADDR                                                1052
#define RT_ADC_T_AC_FUS_ADDR                                               1053
#define RT_ADC_T_DC_FUS1_ADDR                                              1054
#define RT_ADC_T_DC_FUS2_ADDR                                              1055
#define RT_ADC_V_DC1_ADDR                                                  1056
#define RT_ADC_V_DC2_ADDR                                                  1057

#define RT_ADC_V_PCS_RS_ADDR                                               1058
#define RT_ADC_V_PCS_ST_ADDR                                               1060
#define RT_ADC_V_PCS_TR_ADDR                                               1062
#define RT_ADC_V_GRD_RS_ADDR                                               1064
#define RT_ADC_V_GRD_ST_ADDR                                               1066
#define RT_ADC_V_GRD_TR_ADDR                                               1068
#define RT_ADC_I_OUT_R_ADDR                                                1070
#define RT_ADC_I_OUT_S_ADDR                                                1072
#define RT_ADC_I_OUT_T_ADDR                                                1074
#define RT_ADC_POWER_P_ADDR                                                1076
#define RT_ADC_POWER_Q_ADDR                                                1078
#define RT_ADC_POWER_S_ADDR                                                1080

// Gain And Offset
#define DC_GAIN_OFFSET_LEN                                                    4
#define GNFT_T_AC_FUSE_ADDR                                                1082
#define GNFT_T_DC_FUS1_ADDR      (GNFT_T_AC_FUSE_ADDR + DC_GAIN_OFFSET_LEN * 1)
#define GNFT_T_DC_FUS2_ADDR      (GNFT_T_AC_FUSE_ADDR + DC_GAIN_OFFSET_LEN * 2)
#define GNFT_V_DC1_ADDR          (GNFT_T_AC_FUSE_ADDR + DC_GAIN_OFFSET_LEN * 3)
#define GNFT_V_DC2_ADDR          (GNFT_T_AC_FUSE_ADDR + DC_GAIN_OFFSET_LEN * 4)

#define AC_GAIN_LEN                                                           2
#define GNFT_V_PCS_RS_ADDR              (GNFT_V_DC2_ADDR + DC_GAIN_OFFSET_LEN) // 1102
#define GNFT_V_PCS_ST_ADDR              (GNFT_V_PCS_RS_ADDR + AC_GAIN_LEN * 1)
#define GNFT_V_PCS_TR_ADDR              (GNFT_V_PCS_RS_ADDR + AC_GAIN_LEN * 2)
#define GNFT_V_GRD_RS_ADDR              (GNFT_V_PCS_RS_ADDR + AC_GAIN_LEN * 3)
#define GNFT_V_GRD_ST_ADDR              (GNFT_V_PCS_RS_ADDR + AC_GAIN_LEN * 4)
#define GNFT_V_GRD_TR_ADDR              (GNFT_V_PCS_RS_ADDR + AC_GAIN_LEN * 5)
#define GNFT_I_OUT_RS_ADDR              (GNFT_V_PCS_RS_ADDR + AC_GAIN_LEN * 6)
#define GNFT_I_OUT_ST_ADDR              (GNFT_V_PCS_RS_ADDR + AC_GAIN_LEN * 7)
#define GNFT_I_OUT_TR_ADDR              (GNFT_V_PCS_RS_ADDR + AC_GAIN_LEN * 8)
#define GNFT_POWER_RS_ADDR              (GNFT_V_PCS_RS_ADDR + AC_GAIN_LEN * 9)
#define GNFT_POWER_ST_ADDR              (GNFT_V_PCS_RS_ADDR + AC_GAIN_LEN * 10)
#define GNFT_POWER_TR_ADDR              (GNFT_V_PCS_RS_ADDR + AC_GAIN_LEN * 11)

// Input calibrate data
#define CALIB_DC_DATA_LEN                                                     6
#define CALIB_T_AC_FUSE_ADDR                                               1126
#define CALIB_T_DC_FUS1_ADDR     (CALIB_T_AC_FUSE_ADDR + CALIB_DC_DATA_LEN * 1)
#define CALIB_T_DC_FUS2_ADDR     (CALIB_T_AC_FUSE_ADDR + CALIB_DC_DATA_LEN * 2)
#define CALIB_V_DC1_ADDR         (CALIB_T_AC_FUSE_ADDR + CALIB_DC_DATA_LEN * 3)
#define CALIB_V_DC2_ADDR         (CALIB_T_AC_FUSE_ADDR + CALIB_DC_DATA_LEN * 4)

#define CALIB_AC_DATA_LEN                                                     4
#define CALIB_V_PCS_RS_ADDR      (CALIB_V_DC2_ADDR + CALIB_DC_DATA_LEN) // 1156
#define CALIB_V_PCS_ST_ADDR      (CALIB_V_PCS_RS_ADDR + CALIB_AC_DATA_LEN * 1)
#define CALIB_V_PCS_TR_ADDR      (CALIB_V_PCS_RS_ADDR + CALIB_AC_DATA_LEN * 2)
#define CALIB_V_GRD_RS_ADDR      (CALIB_V_PCS_RS_ADDR + CALIB_AC_DATA_LEN * 3)
#define CALIB_V_GRD_ST_ADDR      (CALIB_V_PCS_RS_ADDR + CALIB_AC_DATA_LEN * 4)
#define CALIB_V_GRD_TR_ADDR      (CALIB_V_PCS_RS_ADDR + CALIB_AC_DATA_LEN * 5)
#define CALIB_I_OUT_R_ADDR       (CALIB_V_PCS_RS_ADDR + CALIB_AC_DATA_LEN * 6)
#define CALIB_I_OUT_S_ADDR       (CALIB_V_PCS_RS_ADDR + CALIB_AC_DATA_LEN * 7)
#define CALIB_I_OUT_T_ADDR       (CALIB_V_PCS_RS_ADDR + CALIB_AC_DATA_LEN * 8)
#define CALIB_POWER_P_ADDR       (CALIB_V_PCS_RS_ADDR + CALIB_AC_DATA_LEN * 9)
#define CALIB_POWER_Q_ADDR       (CALIB_V_PCS_RS_ADDR + CALIB_AC_DATA_LEN * 10)
#define CALIB_POWER_S_ADDR       (CALIB_V_PCS_RS_ADDR + CALIB_AC_DATA_LEN * 11) //1200

#define PCSM_SET_REG_NUM                                                    160
#define PCSM_SET_CMD_NUM                                                     20
#define PCSM_GROUP_CMD_NUM                                                    5

#define MOD_CMD_MAX_NUM                                                     100
#define MOD_FRAME_MAX_NUM                                                   256

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
enum
{
	// PCSM SET
	HMI_PCSM_RUN = 0,          // pcsm on/off
	HMI_PCSM_ACTIVE_POW,       // pcsm active power
	HMI_PCSM_REACTIVE_POW,     // pcsm reactive power
	HMI_PCSM_OPT_MODE,         // pcsm operation mode
	HMI_PCSM_BUS_VOLT_REF,     // pcsm bus voltage reference
	HMI_OPENLOOP_ENABLE,       // pcsm openloop enable
	HMI_OPENLOOP_VOLT_SET,     // pcsm openloop bus volt set
	HMI_RESET_CMD,             // pcsm software reset
};

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/
typedef struct
{
	word_t   temp_data;
	uint8_t  temp_rx_cnt;
}mod_temp_t;

typedef struct
{
	uint16_t id;
	uint16_t cmd;
}mods_cmd_t;

typedef struct
{
	uint16_t   head;
	bool_t     empty;
	uint16_t   tail;
	bool_t     full;
	uint16_t   len;
	bool_t     busy;
	mods_cmd_t *buff;
	uint16_t   size;
	uint16_t   max_len;         // Maximum numbers of reg frame in a FIFO
	uint16_t   lost_cnt;        // Numbers of lost data(push when FIFO is full)
}fifo_mods_cmd_t;

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/
extern mod_temp_t mod_temp;
extern fifo_mods_cmd_t fifo_mods_cmd;
extern uint16_t hmi_heartbeat;

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void rs485_hmi_init(void);
bool_t fifo_mods_push(fifo_mods_cmd_t *fifo_mods_cmd, mods_cmd_t *mods_cmd);
bool_t fifo_mods_pop(fifo_mods_cmd_t *fifo_mods_cmd, mods_cmd_t *mods_cmd);

void slow_task_rs485_hmi(void);

#endif
/******************************************************************************
* End of module
******************************************************************************/
