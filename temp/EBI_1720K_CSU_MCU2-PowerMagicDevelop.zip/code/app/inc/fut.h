/******************************************************************************
 *
 * FILE IDENTIFICATION
 * -------------------
 *
 * File Name   : fut.h
 * Description : fut functional module header file
 *
 * $RCSfile    : $
 * $Author     : $
 * $Date       : $
 * $Revision   : $
 *
 ******************************************************************************
 * Copyright (c) SOFAR SH 2021
 * All right reserved.
 *****************************************************************************/

#ifndef FUT_H
#define FUT_H

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "sdk.h"
#include "sdk_core.h"
#include "fut.h"
#include "common.h"
#include "csu_data.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define CMD_TEST_CAN1                     0x200
#define ACK_TEST_CAN1                     0x201
#define CMD_TEST_CAN5                     0x202
#define ACK_TEST_CAN5                     0x203
#define NTC_SAMPLE_NUM                    4
#define OTHER_SAMPLE_NUM                  2

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
typedef enum
{
	LOW = 0,
	HIGH
}DO_E;

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/
typedef struct
{
	uint16_t do1   : 1;
	uint16_t do2   : 1;
	uint16_t do3   : 1;
	uint16_t do4   : 1;
	uint16_t do5   : 1;
	uint16_t do6   : 1;
	uint16_t do7   : 1;
	uint16_t do8   : 1;
	uint16_t rsvd  : 8;
}fut_do_tst_bits_t;

typedef union
{
	uint16_t all;
	fut_do_tst_bits_t bits;
}fut_do_tst_t;

typedef struct
{
	fut_do_tst_t do_tst;
}fut_tst_cmd_t;

typedef struct
{    
	uint8_t input_4_cnt;
	uint8_t input_2_cnt;
	//uint16_t run_mod;
	uint16_t led_state;
	uint16_t dry_contact;
	uint16_t test_result;
	uint32_t test_addr;
	uint16_t sample_array[2];
	float32_t meter_array[2];
	float32_t series_array[2];
}calib_tst_var_t;

// factory unitary test data block
typedef struct
{
	half_word_t     flag;              // factory test flag(T1/T2/...)
	fut_tst_cmd_t   cmd;               // factory test cmd(do...)
	calib_tst_var_t calib_var;
}fut_t;

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/
extern fut_t fut;
extern bool_t fut_flag;

extern float32_t fut_float_array[36];
extern uint16_t fut_integer_array[8];

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void fut_init(void);

void fut_telemet_upload(void);

void slow_task_fut(void);

#endif
/******************************************************************************
* End of module
******************************************************************************/
