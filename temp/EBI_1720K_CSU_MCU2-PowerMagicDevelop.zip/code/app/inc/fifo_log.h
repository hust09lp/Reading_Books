/******************************************************************************
 *
 * FILE IDENTIFICATION
 * -------------------
 *
 * File Name   : fifo_log.h
 * Description : FIFO LOG functional module
 *
 * $RCSfile    : $
 * $Author     : $
 * $Date       : $
 * $Revision   : $
 *
 ******************************************************************************
 * Copyright (c) SOFAR SH 2021
 * All right reserved.
 *****************************************************************************/

#ifndef FIFO_LOG_H
#define FIFO_LOG_H

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------
#include "common.h"
#include "sdk_core.h"
// Include project file ------------------------------------------------------

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define LOG_LENGTH                                                          (79)

// #define DIAG_LOG                                                              0
#define ONE_DIAG_LOG_SIZE                                                    79
#define MAX_DIAG_LOG_NUMS                                                 10000

// #define OPAT_LOG                                                              1
#define ONE_OPAT_LOG_SIZE                                                    79
#define MAX_OPAT_LOG_NUMS                                                 10000

#define ONE_DEBUG_LOG_SIZE                                                   79
#define MAX_DEBUG_LOG_NUMS                                                10000

#define WRITE_NEW_LOG                                                         0

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
typedef struct
{
	uint16_t code;          // log code
	// uint8_t location[64];   // log print current file and line
	uint8_t info[LOG_LENGTH];      // log information(set parameter, vaviale ...)
	bool_t  rewrite;         // 0: write success, 1: write fail
	bool_t  enable;
}log_t;
/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/
// -------------------------------------------------------
// FIFO log control block
// -------------------------------------------------------
//       tail     head
//       |        |
// Push->XXXXXXXXXOOOOO->Pop
//       |<-len->|    |
//       |<---size--->|
typedef struct
{
	uint16_t   head;
	bool_t     empty;
	uint16_t   tail;
	bool_t     full;
	uint16_t   len;
	sdk_os_mutex_id_t     busy;
	log_t      *buff;
	uint16_t   size;
	uint16_t   max_len;         // Maximum numbers of log frame in a FIFO
	uint16_t   lost_cnt;        // Numbers of lost data(push when FIFO is full)
}fifo_log_t;

enum
{
	DIAG_LOG = 0,
	OPAT_LOG,
	DEBUG_LOG,
	LOG_TYPE_NUM,
};

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/
extern fifo_log_t g_fifo_log;
extern log_t g_log_write;
extern sdk_os_mutex_attr_t g_log_mutex;
extern uint8_t opt_log_info[ONE_OPAT_LOG_SIZE * 2];
extern uint8_t diag_log_info[ONE_DIAG_LOG_SIZE * 2];
extern uint8_t debug_log_info[ONE_DEBUG_LOG_SIZE * 2];

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void fifo_log_init(void);

bool_t fifo_log_push(fifo_log_t *fifo_log, log_t *log);
bool_t fifo_log_pop(fifo_log_t *fifo_log, log_t *log);
void app_log_write(uint8_t *log, uint16_t type);
void bkgd_task_log_write(void);

#endif
/******************************************************************************
* End of module
******************************************************************************/
