/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     diag_manage.h
  * @brief    Diagnostic manage application module header file
  * @company  SOFARSOLAR
  * @author   HH
  * @note
  * @version  V01
  * @date     2023/02/22
  */
/*****************************************************************************/

#ifndef __DIAG_MANAGE_H__
#define __DIAG_MANAGE_H__

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "diagnostic.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
typedef enum
{
	// ------ FAST GROUP ------
	FAST_DIAG_GROUP_START = 0,
	FAST_DIAG_CSU_BOARD_OTW = FAST_DIAG_GROUP_START,
	FAST_DIAG_AC_TANK_OTW,
	FAST_DIAG_CSU_BOARD_OTP,
	FAST_DIAG_AC_TANK_OTP,
	FAST_DIAG_CSU_BOARD_UTW,
	FAST_DIAG_AC_TANK_UTW,
	FAST_DIAG_CSU_BOARD_NTC,
	FAST_DIAG_AC_TANK_NTC,
	FAST_DIAG_WATER_LEAK,
	FAST_DIAG_DOOR_UNLOCK,
	FAST_DIAG_AC_SPD,
	FAST_DIAG_GRID_TIED_POS,
	FAST_DIAG_PCSC_FAN1,
	FAST_DIAG_PCSC_FAN2,
	FAST_DIAG_ISO_DEV_FAULT,
	FAST_DIAG_ISO_FAULT,
	FAST_DIAG_CMU_FAULT,
	FAST_DIAG_REMOTE_EPO,
	FAST_DIAG_PCSM1_AC_BREAKER,
	FAST_DIAG_PCSM2_AC_BREAKER,
	FAST_DIAG_PCSM3_AC_BREAKER,
	FAST_DIAG_PCSM4_AC_BREAKER,
	FAST_DIAG_PCSM5_AC_BREAKER,
	FAST_DIAG_PCSM6_AC_BREAKER,
	FAST_DIAG_PCSM1_CAN5,
	FAST_DIAG_PCSM2_CAN5,
	FAST_DIAG_PCSM3_CAN5,
	FAST_DIAG_PCSM4_CAN5,
	FAST_DIAG_PCSM5_CAN5,
	FAST_DIAG_PCSM6_CAN5,
	FAST_DIAG_METERING_METER,
	FAST_DIAG_BACKFLOW_METER,
	FAST_DIAG_MICROCOMPUTER,
	FAST_DIAG_DEHUMIDIFIER,
	FAST_DIAG_MEASURE_CONTROL,
	FAST_DIAG_MODEL_READ,
	FAST_DIAG_ANTI_BACKFLOW,
	FAST_DIAG_STS_SW_POS,
	FAST_DIAG_BYPASS_FAULT,
	FAST_DIAG_SPD1,
	FAST_DIAG_SPD2,
	FAST_DIAG_QF1_SW,
	FAST_DIAG_METER2,
	FAST_DIAG_METER3_1,
	FAST_DIAG_METER3_2,
	FAST_DIAG_METER3_3,
	FAST_DIAG_METER3_4,
	FAST_DIAG_METER3_5,
	FAST_DIAG_PV_METER_1,
	FAST_DIAG_PV_METER_2,
	FAST_DIAG_PV_METER_3,
	FAST_DIAG_GROUP_END,
	// ------ SLOW GROUP ------
//	SLOW_DIAG_GROUP_START = FAST_DIAG_GROUP_END,
//	SLOW_DIAG_AMB_OTP = SLOW_DIAG_GROUP_START,
//	SLOW_DIAG_GROUP_END,
	DIAG_ARRAY_SIZE = FAST_DIAG_GROUP_END //SLOW_DIAG_GROUP_END
}DIAG_ID;

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/
extern diag_t diag_array[];
extern uint16_t fault_warn[];
extern uint8_t standard_scenario_400v[];
extern uint8_t standard_scenario_690v[];
extern uint8_t one_storage_tank_400v[];
extern uint8_t only_combiner_cabinet_400v[];
extern uint8_t combiner_storage_400v[];
extern uint8_t one_storage_tank_690v[];
extern uint16_t standard_scenario_400v_di[2];
extern uint16_t standard_scenario_690v_di[2];
extern uint16_t one_storage_tank_400v_di[2];
extern uint16_t only_combiner_cabinet_400v_di[2];
extern uint16_t combiner_storage_400v_di[2];
extern uint16_t one_storage_tank_690v_di[2];
extern diag_group_t fast_diag_group;
//extern diag_group_t slow_diag_group;
extern bool_t trigger_diag_task;

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void diag_manage_init(void);

void delay_diag_task(void);
void fast_task_diagnostic(void);
//void slow_task_diagnostic(void);
void fast_task_fault_update(void);
void fast_task_trigger_update(void);
void diag_enable(DIAG_ID diag_handle);
void diag_disable(DIAG_ID diag_handle);
void clear_fault(void);

#endif
/******************************************************************************
* End of module
******************************************************************************/
