/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     sci_mcu1.h
  * @brief
  * @company  SOFARSOLAR
  * @author
  * @note
  * @version  V01
  * @date     2023/04/14
  */
/*****************************************************************************/
#ifndef __SCI_MCU1_H__
#define __SCI_MCU1_H__

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
#include "stdint.h"
#include "common.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define SCI_SOFT_VERTION                                                   0x01
#define SCI_HARD_VERTION                                                   0x01
#define SCI_PROTOCOL_VERTION                                               0x01
#define SCI_SLAVE_ADDR                                                     0x01
#define SCI_PORT                                                              0

#define SCI_ONPACK_WORD(buff, len, data) \
{ \
	uint32_t temp = data; \
	(buff)[len++] = (temp & 0xFF000000) >> 24; \
	(buff)[len++] = (temp & 0x00FF0000) >> 16; \
	(buff)[len++] = (temp & 0x0000FF00) >> 8; \
	(buff)[len++] = temp & 0xFF; \
}
#define SCI_ONPACK_FLOAT(buff, len, data) \
{ \
	uint32_t temp = *((uint32_t*)&(data)); \
	(buff)[len++] = (temp & 0xFF000000) >> 24; \
	(buff)[len++] = (temp & 0x00FF0000) >> 16; \
	(buff)[len++] = (temp & 0x0000FF00) >> 8; \
	(buff)[len++] = temp & 0xFF; \
}
/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/
#pragma pack(1)
typedef struct
{
	uint8_t start_word_h;
	uint8_t start_word_l;
	uint8_t slave_addr;
	uint8_t len;
	uint8_t reserved;
	uint8_t main_command;
	uint8_t sub_command;
	uint8_t data[256];
} sci_master_t;

typedef struct
{
	uint8_t start_word_h;
	uint8_t start_word_l;
	uint8_t slave_addr;
	uint8_t len;
	uint8_t main_command;
	uint8_t sub_command;
	uint8_t data[256];
} sci_slave_t;
#pragma pack()

extern bool_t sci_printf_flag;
/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void sci_mcu1_init(void);

void thread_sci_mcu1(void *argument);

extern bool_t fault_reset_flag;

#endif
/******************************************************************************
* End of module
******************************************************************************/
