/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     rs485_dehumidification.h
  * @brief    DEHUMIDIFICATION module
  * @company  SOFARSOLAR
  * @author   ZZJ
  * @note
  * @version  V01
  * @date     2023/09/16
  */
/*****************************************************************************/

#ifndef __RS485_DEHUMIDIFICATION_H__
#define __RS485_DEHUMIDIFICATION_H__

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "common.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define RS485_DEHUMIDIFICATION                                              (2)
#define RS485_DEHUMIDIFICATION_SLAVE_ADDR                                   (1)

#define DEHUMIDIFICATION_AUTO_MODE_ADDR                                  (0x0A)
#define DEHUMIDIFICATION_AUTO_MODE_VALUE                                    (0)
#define DEHUMIDIFICATION_RN_ADDR                                         (0x04)
#define DEHUMIDIFICATION_RN_DEFAULT_VALUE                                  (75)
#define DEHUMIDIFICATION_RETURN_DIFFERENCE_ADDR                          (0x05)
#define DEHUMIDIFICATION_RETURN_DIFF_DEFAULT__VALUE                        (15)
#define DEHUMIDIFICATION_DATA_LEN                                          (14)
/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/


/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/
typedef struct
{
  uint16_t humidity;
  uint16_t temperature;
}dehumidifier_data_t;
typedef struct
{
  uint16_t humidity_set;
  uint16_t humidity_diff_set;
}dehumidifier_set_t;

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/
extern int16_t fault_dehumidifier_cnt;
extern int16_t fault_dehumidifier_ref;
extern bool_t trigger_dehumidifier;
extern dehumidifier_data_t dehumidifier_data;
extern dehumidifier_set_t dehumidifier_set;
extern bool_t dehunidification_set_param_flag;

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void rs485_dehumidification_init(void);

void rs485_task_dehumidification(void);

#endif
/******************************************************************************
* End of module
******************************************************************************/
