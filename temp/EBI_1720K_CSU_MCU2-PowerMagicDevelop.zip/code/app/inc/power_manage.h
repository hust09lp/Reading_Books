/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     power_manage.h
  * @brief    Power dispatching management module header file
  * @company  SOFARSOLAR
  * @author   HH
  * @note     
  * @version  V01
  * @date     2023/03/08
  */
/*****************************************************************************/

#ifndef __POWER_MANAGE_H__
#define __POWER_MANAGE_H__

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "sdk.h"
#include "sdk_core.h"
#include "common.h"
#include "pcs.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define SOC_INVALID_VALUE                                                (0xFF)

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/
extern bool_t trigger_power_balance;
extern bool_t trigger_rack_manage;
extern bool_t trigger_bat_capacity_test;
extern bool_t g_active_power_send;
extern bool_t g_reactive_power_send;
extern bool_t trigger_power_resend;
extern bool_t trigger_pcsc_ratings;
extern uint8_t g_redischargeable_num;
extern uint8_t g_rechargeable_num;

extern uint8_t g_chg_p_distribution_mode;
extern uint8_t g_dch_p_distribution_mode;

extern uint16_t planning_scheduling_delay_on_cnt[CMU_NUMS];

extern bool_t trigger_planning_scheduling_start;
extern bool_t trigger_plan_scheduler;
/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void power_manage_init(void);

void thread_power_control(void *argument);
void slow_task_pcs_rating(void);
bool_t chg_status_check(uint8_t cmu_index);
bool_t dch_status_check(uint8_t cmu_index);
void slow_task_cmu_soc_compute(void);
void slow_task_power_resend(void);
void slow_task_drmn_resend(void);
void slow_task_power_allocate_switch(void);
void slow_task_bat_capacity_test(void);
void slow_task_bat_status_get(void);
void slow_task_planning_scheduling(void);
void slow_task_calc_power_limit(void);
void slow_task_cmu_check(void);
void slow_task_ems_soc_compute(void);
uint8_t soc_limit(uint8_t cmu_index, uint8_t soc);
void delay_planning_scheduling(void);
#endif
/******************************************************************************
* End of module
******************************************************************************/
