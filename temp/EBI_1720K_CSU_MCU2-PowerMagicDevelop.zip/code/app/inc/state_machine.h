/******************************************************************************
 *
 * FILE IDENTIFICATION
 * -------------------
 *
 * File Name   : state_machine.h
 * Description : state machine engine header file
 *
 * $RCSfile    : $
 * $Author     : HH $
 * $Date       : 2023/02/21 $
 * $Revision   : V04 $
 *
 ******************************************************************************
 * Copyright (c) SOFAR SH 2021
 * All right reserved.
 *****************************************************************************/

#ifndef STATE_MACHINE_H
#define STATE_MACHINE_H

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "common.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
// state machine state(mode) name length size(Bytes)
#define SM_ST_NAME_LEN                                             (uint16_t)24

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

typedef struct
{
	const int8_t str_name[SM_ST_NAME_LEN];
	uint32_t     id;
	void        (*entry)(void);
	void        (*action)(void);
	void        (*exit)(void);
}sm_state_t;

typedef struct
{
	const sm_state_t  *curr_state;
	const sm_state_t  *next_state;
	bool_t           (*check)(void);
} sm_trans_t;

// for example:
// curr_mode = &ST00
// mode_array = [ST00, ST01, ST02, ST03]
// mode_array_size = 4
// trans_array = [TR01, TR02, TR03]
// trans_array_size = 3
typedef struct
{
	const sm_state_t  *curr_mode;
	const sm_state_t  *mode_array;
	uint32_t           mode_array_size;
	const sm_trans_t  *trans_array;
	uint32_t           trans_array_size;
} state_machine_t;

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void state_machine_init(state_machine_t *state_machine);
void state_machine_chk_tr(state_machine_t *state_machine);
void state_machine_exe_st(state_machine_t *state_machine);
void state_machine_change_state(state_machine_t *state_machine, uint16_t curr_state);


#endif
/******************************************************************************
* End of module
******************************************************************************/
