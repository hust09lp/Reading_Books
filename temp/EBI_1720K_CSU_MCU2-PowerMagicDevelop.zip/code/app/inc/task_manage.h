/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     task_manage.h
  * @brief    App tasks management module header file
  * @company  SOFARSOLAR
  * @author   HH
  * @note
  * @version  V01
  * @date     2023/02/22
  */
/*****************************************************************************/

#ifndef __TASK_MANAGE_H__
#define __TASK_MANAGE_H__

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "task_scheduler.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define DEBUG_LED                                                           (0)

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
typedef enum
{
	// ------ CRITICAL GROUP ------
	CRTL_GROUP_START = 0,
	CRTL_TASK_HEARTBEAT = CRTL_GROUP_START,
	CRTL_TASK_AC_SAMPLE,
	CRTL_TASK_DC_SAMPLE,
	CRTL_TASK_MUX_SAMPLE,
	CRTL_TASK_TPLL,
	CRTL_GROUP_END,
	// ------ FAST GROUP ------
	FAST_GROUP_START = CRTL_GROUP_END,
	FAST_TASK_HEARTBEAT = FAST_GROUP_START,
	FAST_TASK_DIAGNOSTIC,
	FAST_TASK_PCS_SM,
	FAST_TASK_MEASURE,
	FAST_TASK_PCS_CONST,
	FAST_TASK_FAULT_UPDATE,
	FAST_TASK_CLEAR_INFO,
	FAST_TASK_CALC,
	FAST_TASK_RTC,
	FAST_TASK_LOCAL_EMS,
	FAST_TASK_XIAO_JU,
	FAST_TASK_CAN1_SEND,
	FAST_GROUP_END,
	// ------ SLOW GROUP ------
	SLOW_GROUP_START = FAST_GROUP_END,
	SLOW_TASK_HEARTBEAT = SLOW_GROUP_START,
	SLOW_TASK_MEASURE,
	SLOW_TASK_DI,
	SLOW_TASK_DO,
	SLOW_TASK_TOTAL_RUNTIME,
	SLOW_TASK_OTHERS,
	SLOW_TASK_SET_PCSM_NUMS,
	SLOW_TASK_SCENARIO_MODIFY,
	SLOW_TASK_CMU_CHECK,
	SLOW_TASK_CMU_SOC_COMPUTE,
	SLOW_TASK_BAT_CTRL,
	SLOW_TASK_POWER_ALLOCATE_SWITCH,
	SLOW_TASK_EMS_SOC_COMPUTE,
	SLOW_TASK_CALC_POWER_LIMIT,
	SLOW_TASK_PLANNING_SCHEDULING,
	SLOW_TASK_MODEL_READ,
	SLOW_TASK_POWER_MAGIC_INIT,
	SLOW_TASK_BAT_CAPACITY_TEST,
	SLOW_TASK_SN_ANALYSIS,
	SLOW_TASK_HEART_CHECK,
	SLOW_TASK_POWER_RESEND,
	SLOW_TASK_DRMN_RESEND,
	SLOW_TASK_EMS_CLOSE,
	SLOW_TASK_DEBUG_RECORD,
	SLOW_TASK_PCS_RATING,
	SLOW_GROUP_END,
	// ------ RS485 GROUP ------
	RS485_GROUP_START = SLOW_GROUP_END,
	RS485_TASK_FUT = RS485_GROUP_START,
	RS485_TASK_DEVICE_MANAGE,
	RS485_TASK_BACKFLOW_METER,
	RS485_TASK_PV_POWER,
	RS485_TASK_MM_POWER,
	RS485_TASK_METER2,
	RS485_TASK_METER3,
	RS485_TASK_MEASURE_CONTROL,
	RS485_TASK_MICROCOMPUTER,
	RS485_TASK_DEHUMIDIFICATION,
	RS485_TASK_METER2_OTHER,
	RS485_TASK_METER3_OTHER,
	RS485_TASK_PV_METER,
	RS485_TASK_PCC_METER_DATA,
	RS485_TASK_RS485_METERING,
	RS485_GROUP_END,
	// ------ BACKGROUND GROUP ------
	BKGD_GROUP_START = RS485_GROUP_END,
	BKGD_TASK_IDLE = BKGD_GROUP_START,
	BKGD_TASK_LOG_WRITE,
	BKGD_TASK_RESTORE_FACTORY,
	BKGD_GROUP_END
}TASK_ID;

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/
extern task_t task_array[];

extern task_group_t crtl_group;
extern task_group_t fast_group;
extern task_group_t slow_group;
extern task_group_t rs485_group;
extern task_group_t bkgd_group;

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void task_manage_init(void);

void crtl_task_heartbeat(void);
void fast_task_heartbeat(void);
void slow_task_heartbeat(void);
void slow_task_power_magic_init(void);
void bkgd_task_idle(void);
void slow_task_debug_record(void);
#endif
/******************************************************************************
* End of module
******************************************************************************/
