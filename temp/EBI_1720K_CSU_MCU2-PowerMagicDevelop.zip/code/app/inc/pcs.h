/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     pcs.h
  * @brief    pcs module header file
  * @company  SOFARSOLAR
  * @author   WWX
  * @note
  * @version  V03
  * @date     2023/06/20
  */
/*****************************************************************************/

#ifndef __PCS_H__
#define __PCS_H__

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
#include "common.h"
#include "sdk.h"
#include "fifo_can.h"
#include "setting.h"
/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define		PCSM_NUMS                                                       (6)
#define     GROUP_NUMS                                                      (2)
#define		GROUP_ONE_ID                                                    (0)
#define		GROUP_TWO_ID                                                    (1)

// can frame function code
#define		PCS_CMD_GET_DEVICE_INFO                                         (0)
#define		PCS_CMD_GET_REMOTE_SIGNALING                                    (1)
#define		PCS_CMD_GET_REMOTE_METERING                                     (2)
#define		PCS_CMD_GET_PARAMETER                                          (10)
#define		PCS_CMD_SET_PARAMETER                                          (20)
#define		PCS_CMD_GET_PARAMETER_FAST                                     (11)
#define		PCS_CMD_SET_PARAMETER_FAST                                     (21)
#define     PCS_CMD_GET_SAFE_PARAMETER                                     (32)
#define     PCS_CMD_SET_SAFE_PARAMETER                                     (33)
#define		PCS_CMD_SET_GROUP_PARAMETER                                    (57)

// cmd get vars in differernt blocks
#define		PCSM_DEVICE_INFO_1                                              (0)
#define		PCSM_DEVICE_INFO_2                                              (1)
#define		PCSM_REMOTE_SIGNALING_1                                         (2)
#define		PCSM_REMOTE_METERING_1                                          (3)
#define		PCSM_REMOTE_METERING_BMS                                        (4)
#define		PCSM_REMOTE_METERING_2                                          (5)
#define		PCSM_REMOTE_METERING_3                                          (6)
#define		PCSM_PARAMETER_1                                                (7)
#define		PCSM_PARAMETER_2                                                (8)
#define		PCSM_PARAMETER_3                                                (9)

#define     PCSM_POINT_TABLE_OFFSET_1                                       (0)
#define     PCSM_POINT_TABLE_OFFSET_BMS									 (1000)
#define     PCSM_POINT_TABLE_OFFSET_2                                   (10000)
#define     PCSM_POINT_TABLE_OFFSET_3                                   (20000)
#define     PCSM_POINT_TABLE_OFFSET_4                                   (30000)

// can frame data length
#define		PCSM_DEVICE_INFO_LENGTH_1                                      (20)
#define		PCSM_DEVICE_INFO_LENGTH_2                                      (23)
#define		PCSM_REMOTE_SIGNALING_LENGTH_1                                 (20)
#define		PCSM_REMOTE_METERING_LENGTH_1                                  (36)
#define		PCSM_REMOTE_METERING_LENGTH_BMS                                (16)
#define		PCSM_REMOTE_METERING_LENGTH_2                                  (38)
#define		PCSM_REMOTE_METERING_LENGTH_3                                   (3)
#define		PCSM_REMOTE_METERING_LENGTH_4                                   (9)
#define		PCSM_PARAMETER_LENGTH_1                                        (25)
#define		PCSM_PARAMETER_LENGTH_2                                        (31)
#define		PCSM_PARAMETER_LENGTH_3                                         (5)
#define     AUTO_HEART_BEAT                                              (0x7f)
#define     PCS_SN_LEN                                                     (10)

#define		CMU_NUMS                                                (PCSM_NUMS)
#define		BAT_RACK_MAX_NUMS_TOTAL                                        (36)
#define     BAT_RACK_MAX_NUMS_PER_CMU                                       (6)

#define ACTIVE_POWER_OVERLOAD_MULTIPLE                                 (1.112f)
#define READ_INDEX                                                          (0)
#define WRITE_INDEX                                                         (1)

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
typedef enum
{
	PCS_SN = 0,
	PCS_CONST_RATED_POWER = 14,
	PCS_CONST_PRODUCT_MODEL = 10009,
}PCS_DEVICE_INFO_OFFSET_E;

typedef enum
{
	PCS_RUN = 0,
	ACTIVE_POWER_REF,
	REACTIVE_POWER_REF,
	PCS_OPERATION_MODE,
	DERATE_SOUT_OUTPORT_REF,
	DERATE_SOUT_INTPORT_REF,
	SYSTEM_TIME_SECOND,
	SYSTEM_TIME_MINUTE,
	SYSTEM_TIME_HOUR,
	SYSTEM_TIME_DAY,
	SYSTEM_TIME_MONTH,
	SYSTEM_TIME_YEAR,
	POWER_FACTOR_REF,
	PCS_REACTIVE_POWER_MODE,
	PCS_CEI016_MODE,
	ANTI_ISLAND_ENABLE,
	GRID_OFF_PHASE_VOLT_REF,
	GRID_OFF_FREQ_REF,
	POWER_REF_SOFT_START_GRADIDENT,
	POWER_ON_SOFT_START_GRADIDENT,
	AUTO_START_ENABLE,
	BUS_VOLT_REF = 10000,
	SN1_SET,
	SN2_SET,
	SN3_SET,
	SN4_SET,
	SN5_SET,
	SN6_SET,
	SN7_SET,
	SN8_SET,
	SN9_SET,
	SN10_SET,
	AD_GAIN_BUS_P_CALI,
	AD_GAIN_BUS_N_CALI,
	AD_GAIN_IOUT_R_CALI,
	AD_GAIN_IOUT_S_CALI,
	AD_GAIN_IOUT_T_CALI,
	GROUP_NUM_SET,
	AD_GAIN_VOUT_RS_CALI = 10017,
	AD_GAIN_VOUT_TR_CALI,
	ISO_DET_ENABLE = 10019,
	CONST_CURRENT_REF,
	ENERGY_DATA_CLEAR_ENABLE,
	DEVICE_NUM_SET = 10022,
	AGED_ENABLE,
	FAN_TEST_ENABLE,
	DRMN_SET = 10038,
	// ENERGY_CALCULATE_ENABLE,
	OPENLOOP_ENABLE = 20000,
	OPENLOOP_VOLT_SET,
	RESET_CMD,
}PCS_CMD_OFFSET_E;

typedef enum
{
	REACTIVE_DISTURBANCE_REF = 0,
}PCS_FAST_CMD_OFFSET_E;

typedef enum
{
	GROUP_PCS_RUN = 0,
	GROUP_ACTIVE_POWER_REF,
	GROUP_REACTIVE_POWER_REF,
	GROUP_PCS_OPERATION_MODE = 10000,
	GROUP_BUS_VOLT_REF,
	GROUP_CONST_CURRENT_REF,
}PCS_GROUP_CMD_E;

typedef enum
{
	CONFIG = 0,
	WAIT,
	CHECK,
	NORMAL,
	SHUTDOWN,
	UPGRADE
}PCSM_FSM_STATE_E;

typedef enum
{
	GRID_CONNECT = 0x0000,
	GRID_DISCONNECT = 0x0001,
	CONST_CURRENT = 0x0010,
	CONST_VOLTAGE = 0x0020,
	AFE_ENABLE = 0x0100,
}PCSM_OPERATION_MODE_E;

typedef enum
{
	AVERAGE_DISTRIBUTION = 0,
	RACK_MANAGE,
}POWER_DISTRIBUTION_MODE_E;

typedef enum
{
    DEFAULT_MODE = 0,
    FIXED_FACTOR_MODE = 1,
    FIXED_REACTIVE_MODE = 2,
    QP_MODE = 3,
    QU_I_MODE = 4,
    QU_II_MODE = 5,
    CEI016_MODE = 6,
}PCS_REACTIVE_POWER_MODE_E;

typedef enum
{
    ZERO_REACTIVE_MODE = 0,
    INDUCTIVE_REACTIVE_MODE = 1,
    CAPACTIVE_REACTIVE_MODE = 2,
}PCS_CEI016_MODE_E;

// system working state
enum
{
	SYS_STATE_SHUT_DOWN = 0,
	SYS_STATE_STANDBY,
	SYS_STATE_FAULT,
	SYS_STATE_CHARGE,
	SYS_STATE_DISCHARGE,
	SYS_STATE_RUNNING,
};

typedef enum
{
    MONITORING_NETWORK_MODE = 0,
    CONTROL_NETWORK_MODE = 1,
}POWER_CONTROL_SOURCE_E;

// grid connect state
enum
{
	SYS_STATE_GRID_TIED_OFF = 0,
	SYS_STATE_GRID_TIED_ON,
	SYS_STATE_GRID_TIED_FAULT,
};
enum
{
	SYS_STATE_WORD_1 = 0,
	SYS_STATE_WORD_2,
	SYS_STATE_WORD_NUM,
};


/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

typedef struct
{
	// func code = 2, telemetering vars(R)
	// 0 ~
	int16_t  grid_volt_rs;
	int16_t  grid_volt_st;
	int16_t  grid_volt_tr;
	int16_t  grid_freq;
	int16_t  ac_current_r;
	int16_t  ac_current_s;
	int16_t  ac_current_t;
	int16_t  bus_volt_pn;
	int16_t  bat_volt;
	uint16_t iso_resistence;
	int16_t  active_power;
	int16_t  reactive_power;
	int16_t  apparent_power;
	int16_t  amb_temp;
	int16_t  power_pf;
	uint16_t running_hours_l;
	uint16_t running_hours_h;
	int16_t  active_power_r;
	int16_t  active_power_s;
	int16_t  active_power_t;
	int16_t  reactive_power_r;
	int16_t  reactive_power_s;
	int16_t  reactive_power_t;
	int16_t  apparent_power_r;
	int16_t  apparent_power_s;
	int16_t  apparent_power_t;
    uint16_t system_time_second;
    uint16_t system_time_minute;
    uint16_t system_time_hour;
    uint16_t system_time_day;
    uint16_t system_time_month;
    uint16_t system_time_year;
    int16_t en_grid_current_r;
    int16_t en_grid_current_s;
    int16_t en_grid_current_t;
    uint16_t invq_manage_mode;
    // 1000 ~
    uint16_t battery_total_volt;
    int16_t  battery_total_curr;
    uint16_t battery_chg_state;
    uint16_t battery_health_state;
    uint16_t battery_chg_limit_curr;
    uint16_t battery_dischg_limit_curr;
    uint16_t battery_chg_limit_volt;
    uint16_t battery_dischg_limit_volt;
    uint16_t battery_chg_avail_energy;
    uint16_t battery_dischg_avail_energy;
    uint16_t bms_state;
    uint16_t battery_state_power;
    uint16_t battery_single_volt_max;
    uint16_t battery_single_volt_min;
    int16_t battery_single_temp_max;
    int16_t battery_single_temp_min;
	// 10000 ~
	int16_t grid_volt_r;
	int16_t grid_volt_s;
	int16_t grid_volt_t;
	int16_t n_to_pe_volt;
	int16_t dci_r;
	int16_t dci_s;
	int16_t dci_t;
	int16_t gfci;
	int16_t bus_volt_p;
	int16_t bus_volt_n;
	int16_t igbt_temp_ra;
	int16_t igbt_temp_sa;
	int16_t igbt_temp_ta;
	int16_t igbt_temp_rb;
	int16_t igbt_temp_sb;
	int16_t igbt_temp_tb;
	int16_t slv_grid_volt_r;
	int16_t slv_grid_volt_s;
	int16_t slv_grid_volt_t;
	uint16_t fan_speed_inner1;
	uint16_t fan_speed_inner2;
	uint16_t fan_speed_outer1;
	uint16_t fan_speed_outer2;
	uint16_t fan_speed_outer3;
	uint16_t fan_speed_outer4;
	uint16_t energy_generated_l;
	uint16_t energy_generated_h;
	uint16_t energy_charge_l;
	uint16_t energy_charge_h;
    int16_t cr_curr_r;
    int16_t cr_curr_s;
    int16_t cr_curr_t;
    int16_t pcs_volt_r;
    int16_t pcs_volt_s;
    int16_t pcs_volt_t;
    int16_t pcs_volt_rs;
    int16_t pcs_volt_st;
    int16_t pcs_volt_tr;
	// 20000 ~
	int16_t  bat_current;
	uint16_t iso_det_state;
	int16_t  iso_volt_to_pe;
    // 30000 ~
    uint16_t startup_para_checksum;
    uint16_t voltage_para_checksum;
    uint16_t freq_para_checksum;
    uint16_t dci_para_checksum;
    uint16_t remote_active_para_checksum;
    uint16_t freq_active_para_checksum;
    uint16_t reactive_para_checksum;
    uint16_t volt_cross_para_checksum;
    uint16_t iso_anti_island_para_checksum;
}pcsm_var_t;

typedef struct
{
	//pcsm_state1_t state1;
	uint16_t pcsm_operate_mode;
	uint8_t  fault_state;
	uint8_t  fsm_state;
	int16_t  derate_sout_outport; // 0.01KW
	int16_t  derate_sout_intport; // 0.01KW
}pcsm_state_t;

typedef struct
{
	int16_t  chg_limit; // 0.01KW
	int16_t  dch_limit; // 0.01KW
}pcsm_chg_dch_limit_t;

typedef struct
{
	// func code = 1, teleindication vars(R)
	// 0~9;
	uint16_t fault1;
	uint16_t fault2;
	uint16_t fault3;
	uint16_t fault4;
	uint16_t fault5;
	uint16_t fault6;
	uint16_t fault7;
	uint16_t fault8;
	uint16_t fault9;
	uint16_t fault10;
	uint16_t fault11;
	uint16_t warn1;
	uint16_t warn2;
	uint16_t warn3;
	uint16_t warn4;
	uint16_t warn5;
	uint16_t warn6;
	uint16_t warn7;
	uint16_t fault12;
	uint16_t fault13;
}pcsm_fault_t;

typedef struct
{
	// func code = 10, set[0](R)
	// func code = 20, set[1](W)
	// 0 ~
	uint16_t pcs_run;
	int16_t  active_power_ref;
	int16_t  reactive_power_ref;
	uint16_t pcs_operation_mode;
	int16_t  derate_sout_outport_ref;
	int16_t  derate_sout_intport_ref;
	uint16_t set_system_time_second;
	uint16_t set_system_time_minute;
	uint16_t set_system_time_hour;
	uint16_t set_system_time_day;
	uint16_t set_system_time_month;
	uint16_t set_system_time_year;
	int16_t  power_factor_ref;
	uint16_t pcs_reactive_power_mode;
	uint16_t pcs_cei016_mode;
	uint16_t anti_island_enable;
	uint16_t grid_off_phase_volt_ref;
	uint16_t grid_off_freq_ref;
	uint16_t power_ref_soft_start_gradident;
	uint16_t power_on_soft_start_gradident;
	uint16_t auto_start_enable;
    uint16_t battery_chg_dischg_forbidden;
    int16_t  power_limit_soc_t;
    uint16_t low_power_mode;
    uint16_t low_power_mode_wait_time;
    int16_t dischg_power_limit_soc_t;
    //1000 ~
    uint16_t bms_state;
    uint16_t bms_soc;
    uint16_t bms_soh;
    uint16_t bms_chg_limit_curr;
    uint16_t bms_dischg_limit_curr;
    uint16_t bms_chg_limit_power;
    uint16_t bms_dischg_limit_power;
    uint16_t bms_chg_avail_energy;
    uint16_t bms_dischg_avail_energy;
    uint16_t bms_total_volt;
    uint16_t bms_total_curr;
    uint16_t bms_chg_dischg_power;
	// 10000 ~
	uint16_t bus_volt_ref;
	uint16_t sn1_set;
	uint16_t sn2_set;
	uint16_t sn3_set;
	uint16_t sn4_set;
	uint16_t sn5_set;
	uint16_t sn6_set;
	uint16_t sn7_set;
	uint16_t sn8_set;
	uint16_t sn9_set;
	uint16_t sn10_set;
	uint16_t ad_gain_bus_p_cali;
	uint16_t ad_gain_bus_n_cali;
	uint16_t ad_gain_iout_r_cali;
	uint16_t ad_gain_iout_s_cali;
	uint16_t ad_gain_iout_t_cali;
	uint16_t group_num_set;
	uint16_t ad_gain_vout_rs_cali;
	uint16_t ad_gain_vout_tr_cali;
	uint16_t iso_det_enable;
	uint16_t const_current_ref;
	uint16_t energy_data_clear_enable;
	uint16_t device_num_set;
	uint16_t aged_enable;
	uint16_t fan_Test_Enable;
    uint16_t energy_Calculate_Enable;
    uint16_t ad_gain_vbat_cali;
    uint16_t factory_test_flag;
    uint16_t can_ext_freq_power_mode_set;
    uint16_t power_coeff_cali;
    uint16_t overload_110_enable;
	// 20000 ~
	uint16_t openloop_enable;
	uint16_t openloop_volt_set;
	uint16_t reset_cmd;
    uint16_t product_model_set;
    uint16_t dpwm_enable;
	// fast cmd
	int16_t reactive_disturbance_ref;
}pcsm_set_t;

typedef struct
{
	// func code = 0, constant(R)
	//sn_t     sn;
	//ver_t    boot_v;
	//ver_t    app_v;
	//uint16_t hw_v;
	//uint16_t ptl_can_v;

	// 0~16
	uint16_t sn1;
	uint16_t sn2;
	uint16_t sn3;
	uint16_t sn4;
	uint16_t sn5;
	uint16_t sn6;
	uint16_t sn7;
	uint16_t sn8;
	uint16_t sn9;
	uint16_t sn10;
	uint16_t fw_version1;
	uint16_t fw_version2;
	uint16_t fw_version3;
	uint16_t fw_version4;
	uint16_t rated_power;
	uint16_t group_num;
	uint16_t device_num;
	uint16_t max_power_s;
	uint16_t max_power_p;
	uint16_t max_power_q;
	// 10000 ~
	uint16_t slv_fw_version1;
	uint16_t slv_fw_version2;
	uint16_t slv_fw_version3;
	uint16_t slv_fw_version4;
	uint16_t control_board_version;
	uint16_t power_board_version;
	uint16_t output_board_version;
	uint16_t can_version1;
	uint16_t can_version2;
    uint16_t product_model;
    uint16_t boot_version_1;
    uint16_t boot_version_2;
    uint16_t boot_version_3;
    uint16_t boot_version_4;
    uint16_t factory_test_flag;
    uint16_t slv_boot_version_1;
    uint16_t slv_boot_version_2;
    uint16_t slv_boot_version_3;
    uint16_t slv_boot_version_4;
    uint16_t cpld_version_1;
    uint16_t cpld_version_2;
    uint16_t cpld_version_3;
    uint16_t cpld_version_4;
}pcsm_const_t;

typedef struct
{
	// func code = 57, group set(W)
	// 0~2
	uint16_t pcs_run;
	int16_t  active_power_ref;
	int16_t  reactive_power_ref;

	// 10000~10002
	uint16_t pcs_operation_mode;
	uint16_t bus_volt_ref;
	uint16_t const_current_ref;
	// TODO:
	uint8_t  soc_max_index;
	uint8_t  soc_min_index;
}pcsm_group_t;

typedef struct
{
	pcsm_var_t   var;
	pcsm_state_t state;
	pcsm_fault_t fault;
	pcsm_set_t   set[2];           // set[0]: read, set[1]: write
	pcsm_const_t constant;
}pcsm_data_t;

typedef struct
{
	uint16_t running       : 1;     // 0: off,    1: on
	uint16_t water_leak    : 1;     // 0: false,  1: true
	uint16_t door_unlock   : 1;     // 0: false,  1: true
	uint16_t sts_sw_on     : 1;     // 0: off,    1: on
	uint16_t sts_sw_off    : 1;     // 0: off,    1: on
	uint16_t qf3_status    : 1;     // 0: off,    1: on
	uint16_t spd1_fail     : 1;     // 0: false,  1: true
	uint16_t ac_spd_fail   : 1;     // 0: false,  1: true
	uint16_t spd2_fail     : 1;     // 0: false,  1: true
	uint16_t grid_tied_on  : 1;     // 0: off,    1: on
	uint16_t grid_tied_off : 1;     // 0: off,    1: on
	uint16_t fan1_status   : 1;     // 0: false,    1: true
	uint16_t fan2_status   : 1;     // 0: false,    1: true
	uint16_t iso_dev_fail  : 1;     // 0: false,  1: true
	uint16_t iso_fault     : 1;     // 0: false,  1: true
	uint16_t cmu_fault     : 1;     // 0: false,  1: true
}pcsc_state1_bits_t;

typedef union
{
	uint16_t all;
	pcsc_state1_bits_t bit;
}pcsc_state1_t;

typedef struct
{
	uint16_t remote_epo    : 1;     // 0: false,  1: true
	uint16_t qf1_status    : 1;     // 0: off,    1: on
	uint16_t qf2_status    : 1;     // 0: off,    1: on
	uint16_t qa0_status    : 1;     // 0: off,    1: on
	uint16_t qa1_status    : 1;     // 0: off,    1: on
	uint16_t qa2_status    : 1;     // 0: off,    1: on
	uint16_t qa3_status    : 1;     // 0: off,    1: on
	uint16_t qa4_status    : 1;     // 0: off,    1: on
	uint16_t qa5_status    : 1;     // 0: off,    1: on
	uint16_t qa6_status    : 1;     // 0: off,    1: on
	uint16_t fan_status    : 1;     // 0: off,    1: on
	uint16_t rsvd          : 5;
}pcsc_state2_bits_t;

typedef union
{
	uint16_t all;
	pcsc_state2_bits_t bit;
}pcsc_state2_t;

typedef struct
{
	uint16_t rsvd_1                : 1;     // reserved
	uint16_t sts_switch_on         : 1;     // 0: off, 1: on
	uint16_t grid_tied_sw_qf1_on   : 1;     // 0: off, 1: on
	uint16_t grid_tied_sw_qf1_off  : 1;     // 0: off, 1: on
	uint16_t do5_rsvd1             : 1;     // reserved
	uint16_t sts_switch_off        : 1;     // 0: off, 1: on
	uint16_t sel_a          : 1;     // sample ch sel a   0: off, 1: on
	uint16_t sel_b          : 1;     // sample ch sel b   0: off, 1: on
	uint16_t rsvd           : 8;
}pcsc_do_ctrl_bits_t;

typedef union
{
	uint16_t all;
	pcsc_do_ctrl_bits_t bit;
}pcsc_do_ctrl_t;

typedef struct
{
	uint16_t run       : 1; // PCS total run state 0: standby, 1: run
	uint16_t charge    : 1; // PCS total charge state 0: NA, 1: charge
	uint16_t discharge : 1; // PCS total discharge state 0: NA, 1: discharge
	uint16_t warn      : 1; // PCS total warning state 0: false, 1: true
	uint16_t fault     : 1; // PCS total fault state 0: false, 1: true
	uint16_t rsvd      : 11;// reserved
}pcsc_sys_state_bits_t;

typedef union
{
	uint16_t all;
	pcsc_sys_state_bits_t bit;
}pcsc_sys_state_t;

typedef struct
{
	uint16_t v_grd_rs;
	uint16_t v_grd_st;
	uint16_t v_grd_tr;
	uint16_t v_out_rs;
	uint16_t v_out_st;
	uint16_t v_out_tr;
	uint16_t i_out_r;
	uint16_t i_out_s;
	uint16_t i_out_t;
	uint16_t grid_freq;
	int16_t  t_board;
	int16_t  t_ac_fuse;
	int16_t  t_reserve_1;
	int16_t  t_reserve_2;
	int32_t  power_p;
	int32_t  power_q;
	int32_t  power_s;
	uint32_t today_chg_energy;
	uint32_t today_dch_energy;
	uint32_t total_chg_energy;
	uint32_t total_dch_energy;
	uint16_t bat_soc[BAT_RACK_MAX_NUMS_TOTAL];
	uint16_t bat_soh[BAT_RACK_MAX_NUMS_TOTAL];
	uint32_t total_runtime;
	uint16_t v_ac_r;
	uint16_t v_ac_s;
	uint16_t v_ac_t;
	int16_t  active_power_r;
	int16_t  active_power_s;
	int16_t  active_power_t;
	int16_t  reactive_power_r;
	int16_t  reactive_power_s;
	int16_t  reactive_power_t;
	int16_t  apparent_power_r;
	int16_t  apparent_power_s;
	int16_t  apparent_power_t;
    uint16_t max_chargable_power;
    uint16_t max_dischargable_power;
    int16_t  increasable_reactive_power;
    int16_t  decreasable_reactive_power;
    uint16_t soc_operation_val;
}pcsc_var_t;

typedef struct
{
	pcsc_state1_t state1;
	pcsc_state2_t state2;
	uint16_t sys_state;
	uint16_t grid_tied_state;
}pcsc_state_t;

typedef struct
{
	uint16_t csu_board_otw        : 1;
	uint16_t ac_tank_otw          : 1;
	uint16_t csu_board_otp        : 1;
	uint16_t ac_tank_otp          : 1;
	uint16_t csu_board_utw        : 1;
	uint16_t ac_tank_utw          : 1;
	uint16_t csu_board_ntc        : 1;
	uint16_t ac_tank_ntc          : 1;
	uint16_t water_leak           : 1;
	uint16_t door_unlock          : 1;
	uint16_t ac_spd_fail          : 1;
	uint16_t grid_tied_pos_fault  : 1;
	uint16_t fan1_fail            : 1;
	uint16_t fan2_fail            : 1;
	uint16_t iso_dev_fault        : 1;
	uint16_t iso_fault            : 1;
}pcsc_fault1_bits_t;

typedef struct
{
	uint16_t cmu_fault        : 1;
	uint16_t remote_epo       : 1;
	uint16_t pcsm1_ac_breaker : 1;
	uint16_t pcsm2_ac_breaker : 1;
	uint16_t pcsm3_ac_breaker : 1;
	uint16_t pcsm4_ac_breaker : 1;
	uint16_t pcsm5_ac_breaker : 1;
	uint16_t pcsm6_ac_breaker : 1;
	uint16_t pcsm1_can1       : 1;
	uint16_t pcsm2_can1       : 1;
	uint16_t pcsm3_can1       : 1;
	uint16_t pcsm4_can1       : 1;
	uint16_t pcsm5_can1       : 1;
	uint16_t pcsm6_can1       : 1;
	uint16_t metering_meter   : 1;
	uint16_t backflow_meter   : 1;
}pcsc_fault2_bits_t;

typedef struct
{
	uint16_t microcomputer       : 1;
	uint16_t dehumidifier        : 1;
	uint16_t measure_control     : 1;
	uint16_t pcsm_model_err      : 1;
	uint16_t anti_backflow_err   : 1;
	uint16_t sts_sw_pos_fault    : 1;
	uint16_t bypass_fault        : 1;
	uint16_t spd1_fail           : 1;
	uint16_t spd2_fail           : 1;
	uint16_t qf1_fail            : 1;
	uint16_t metering_meter_2    : 1;
	uint16_t metering_meter_3_1  : 1;
	uint16_t metering_meter_3_2  : 1;
	uint16_t metering_meter_3_3  : 1;
	uint16_t metering_meter_3_4  : 1;
	uint16_t metering_meter_3_5  : 1;
}pcsc_fault3_bits_t;

typedef struct
{
	uint16_t pv_meter_1	     : 1;
	uint16_t pv_meter_2	     : 1;
	uint16_t pv_meter_3	     : 1;
	uint16_t rsvd	         : 13;
}pcsc_fault4_bits_t;

typedef struct
{
	uint16_t pcs_tr_uvw	  : 1;
	uint16_t dc1_ovw	  : 1;
	uint16_t dc2_ovw	  : 1;
	uint16_t dc1_uvw	  : 1;
	uint16_t dc2_uvw	  : 1;
	uint16_t rsvd		  : 11;
}pcsc_fault5_bits_t;

typedef struct
{
	uint16_t rsvd            :16;
}pcsc_fault6_bits_t;

typedef struct
{
	uint16_t rsvd            :16;
}pcsc_fault7_bits_t;

typedef union
{
	uint16_t all;
	pcsc_fault1_bits_t bit;
}pcsc_fault1_t;

typedef union
{
	uint16_t all;
	pcsc_fault2_bits_t bit;
}pcsc_fault2_t;

typedef union
{
	uint16_t all;
	pcsc_fault3_bits_t bit;
}pcsc_fault3_t;

typedef union
{
	uint16_t all;
	pcsc_fault4_bits_t bit;
}pcsc_fault4_t;

typedef union
{
	uint16_t all;
	pcsc_fault5_bits_t bit;
}pcsc_fault5_t;

typedef union
{
	uint16_t all;
	pcsc_fault6_bits_t bit;
}pcsc_fault6_t;

typedef union
{
	uint16_t all;
	pcsc_fault7_bits_t bit;
}pcsc_fault7_t;

typedef struct
{
	pcsc_fault1_t fault1;
	pcsc_fault2_t fault2;
	pcsc_fault3_t fault3;
	pcsc_fault4_t fault4;
	pcsc_fault5_t fault5;
	pcsc_fault6_t fault6;
	pcsc_fault7_t fault7;
}pcsc_fault_t;

/* typedef struct
{
	// TODO
}pcsc_set_t;

typedef struct
{
	sn_t     sn;
	ver_t    boot_v;
	ver_t    core_v;
	ver_t    app_v;
	uint16_t hw_v;
	uint16_t ptl_can_v;
	uint16_t ptl_104_v;
}pcsc_const_t;*/

typedef struct
{
	pcsc_var_t   var;
	pcsc_state_t state;
	pcsc_fault_t fault;
	//pcsc_set_t   set;
	//pcsc_const_t constant;
	pcsm_data_t    pcsm_data[PCSM_NUMS];
}pcsc_data_t;

typedef struct
{
	//pcsm_cmd_t cmd;           // command words
	int32_t    p_cmd;           // power reference
	uint16_t on_off;            // PCS on/off
    int16_t  p;                 // active power ref
	int16_t  q;                 // reactive power ref
	uint16_t run_mode;          //
	uint16_t v_bus;             // dc bus ref
	uint16_t open_loop_enable;  //
	uint16_t open_loop_v;       // open loop ref(v)
	uint16_t sw_reset;          // software reset
	uint16_t gfd_enable;        //
	uint16_t cc_cmd;            // cc source ref(i)
}pcsm_ctrl_t;

typedef struct
{
	uint16_t pcs_onoff                    : 1;   // 0: disable,  1: enable
	uint16_t fault_reset                  : 1;
	uint16_t restore_factory_default      : 1;
	uint16_t to_connect_grid              : 1;
	uint16_t to_disconnect_grid           : 1;
	uint16_t fan_ctrl                     : 1;
	uint16_t rsvd                         : 10;
}pcsc_cmd_bits_t;

typedef union
{
	uint16_t all;
	pcsc_cmd_bits_t bit;
}pcsc_cmd_t;

typedef struct
{
	uint16_t forbid_chg_cmu1 : 1;     // 0: false,  1: true
	uint16_t forbid_chg_cmu2 : 1;     // 0: false,  1: true
	uint16_t forbid_chg_cmu3 : 1;     // 0: false,  1: true
	uint16_t forbid_chg_cmu4 : 1;     // 0: false,  1: true
	uint16_t forbid_chg_cmu5 : 1;     // 0: false,  1: true
	uint16_t forbid_chg_cmu6 : 1;     // 0: false,  1: true
	uint16_t rsvd            : 10;
}chg_ctrl_bits_t;

typedef struct
{
	uint16_t forbid_dch_cmu1 : 1;     // 0: false,  1: true
	uint16_t forbid_dch_cmu2 : 1;     // 0: false,  1: true
	uint16_t forbid_dch_cmu3 : 1;     // 0: false,  1: true
	uint16_t forbid_dch_cmu4 : 1;     // 0: false,  1: true
	uint16_t forbid_dch_cmu5 : 1;     // 0: false,  1: true
	uint16_t forbid_dch_cmu6 : 1;     // 0: false,  1: true
	uint16_t rsvd            : 10;
}dch_ctrl_bits_t;

typedef union
{
	uint16_t all;
	chg_ctrl_bits_t bit;
}chg_ctrl_t;

typedef union
{
	uint16_t all;
	dch_ctrl_bits_t bit;
}dch_ctrl_t;


typedef struct
{
	int16_t chg_lmt_power[CMU_NUMS]; // 0.01KW
	int16_t dch_lmt_power[CMU_NUMS]; // 0.01KW
	uint8_t  soc_max[CMU_NUMS];
	uint8_t  soc_min[CMU_NUMS];
	chg_ctrl_t chg_ctrl;
	dch_ctrl_t dch_ctrl;
}bat_status_t;

typedef struct
{
	uint32_t baud_rate;
	uint8_t  uart_index;
	uint8_t  slave_addr;
	uint8_t  data_bits;
	uint8_t  stop_bits;
	uint8_t  parity;
}uart_conf_t;

typedef struct
{
    uint16_t energy_record : 1;
    uint16_t resv          : 15;
}mcu2_notification_bit_t;

typedef union
{
    mcu2_notification_bit_t bit;
    uint16_t all;
}mcu2_notification_t;

typedef struct
{
	uint16_t backflow_meter  : 1;
	uint16_t metering_meter  : 1;
	uint16_t micro_computer  : 1;
	uint16_t measure_control : 1;
	uint16_t dehumidifier    : 1;
	uint16_t pv_meter        : 1;
	uint16_t resv            : 10;
}rs485_device_enable_t;

typedef union
{
	rs485_device_enable_t bit;
	uint16_t all;
}rs485_device_enable_u;

typedef struct
{// 作为主机时使用，代表对应CMU是否处于运行状态，1为运行
	uint16_t cmu1_forbid_action  : 1; // 0:forbid 1:allow
	uint16_t cmu2_forbid_action  : 1; // 0:forbid 1:allow
	uint16_t cmu3_forbid_action  : 1; // 0:forbid 1:allow
	uint16_t cmu4_forbid_action  : 1; // 0:forbid 1:allow
	uint16_t cmu5_forbid_action  : 1; // 0:forbid 1:allow
	uint16_t cmu6_forbid_action  : 1; // 0:forbid 1:allow
	uint16_t resv                : 10;
}cmu_forbid_action_bits_t;

typedef union
{
	cmu_forbid_action_bits_t bit;
	uint16_t all;
}cmu_forbid_action_t;
typedef struct
{
	// brocasting cmd to all pcsms
	uint16_t pcs_run;
	// TODO: modify to int32
	int16_t  active_power_ref;
	int16_t  reactive_power_ref;
	uint16_t pcs_operation_mode;
	int16_t  derate_sout_outport_ref;
	int16_t  derate_sout_intport_ref;
	uint16_t system_time_second;
	uint16_t system_time_minute;
	uint16_t system_time_hour;
	uint16_t system_time_day;
	uint16_t system_time_month;
	uint16_t system_time_year;
	int16_t  power_factor_ref;
	uint16_t pcs_reactive_power_mode;
	uint16_t pcs_cei016_mode;
	uint16_t anti_island_enable;
	uint16_t grid_off_phase_volt_ref;
	uint16_t grid_off_freq_ref;
	uint16_t power_ref_soft_start_gradident;
	uint16_t power_on_soft_start_gradident;
	uint16_t auto_start_enable;
    uint16_t power_control_source;   // 0: monitor_network, 1: control_network

	uint16_t bus_volt_ref;
	uint16_t sn1_set;
	uint16_t sn2_set;
	uint16_t sn3_set;
	uint16_t sn4_set;
	uint16_t sn5_set;
	uint16_t sn6_set;
	uint16_t sn7_set;
	uint16_t sn8_set;
	uint16_t sn9_set;
	uint16_t sn10_set;
	uint16_t ad_gain_bus_p_cali;
	uint16_t ad_gain_bus_n_cali;
	uint16_t ad_gain_iout_r_cali;
	uint16_t ad_gain_iout_s_cali;
	uint16_t ad_gain_iout_t_cali;
	uint16_t group_num_set;
	uint16_t ad_gain_vout_rs_cali;
	uint16_t ad_gain_vout_tr_cali;
	uint16_t iso_det_enable;
	uint16_t const_current_ref;
	uint16_t energy_data_clear_enable;
	uint16_t device_num_set;
	uint16_t aged_enable;
	uint16_t fan_test_enable;
	// uint16_t energy_calculate_enable;
    uint16_t ad_gain_vbat_cali;
    uint16_t pcsm_t1_finish_flag;
    uint16_t pcsm_aging_finish_flag;
    uint16_t pcsm_t2_finish_flag;
	uint16_t openloop_enable;
	uint16_t openloop_volt_set;
	uint16_t reset_cmd;

	int16_t        reactive_disturbance_ref;
	uint16_t       pcsc_on_off;
	uint16_t       pwm_enable;
	pcsc_cmd_t     cmd;
	pcsc_do_ctrl_t do_ctrl;
//	pcsm_ctrl_t    pcsm_ctrl[PCSM_NUMS];
	bat_status_t   bat_status_info;
	uart_conf_t    uart_conf[UART_NUMS];
	uint16_t       power_distribution_mode;
	uint16_t       machine_model;
    uint16_t       prevent_anti_island_enable;
	uint16_t       pcsc_emergency_shutdown;
	uint16_t       power_soft_start_rate;
    mcu2_notification_t notification;
	uint16_t       pcsm_nums_set;
	rs485_device_enable_u rs485_enable;
	uint16_t       scenario_setting;
	cmu_forbid_action_t cmu_forbid_action_flag;
	uint16_t drmn_status;
}pcsc_ctrl_t;

typedef struct
{
	pcsc_data_t pcsc_data;
	pcsc_ctrl_t pcsc_ctrl;
}pcsc_t;

typedef enum
{
	CMU_ACTION_NONE = 0,
	CMU_ACTION_ON,
	CMU_ACTION_STANBY,
	CMU_ACTION_STOP
}cmu_action_u;

typedef enum
{
	CMU_SYS_STOP = 0,
	CMU_SYS_STANDBY,
	CMU_SYS_RUNNING,
	CMU_SYS_FAULT,
	CMU_SYS_UPGRADE,
	CMU_SYS_SLEEP,
	CMU_SYS_UNKOWN = 0xFF,
}cmu_sys_status_u;

typedef enum
{
	CMU_BAT_UNKNOWN = 0, // CMU不在线
	CMU_BAT_NORMAL,          // CMU在线,可充可放
	CMU_BAT_FORBID_CHG,     // CMU在线,不可充,可放
	CMU_BAT_FORBID_DCH,      // CMU在线,可充,不可放
	CMU_BAT_FORBID_CHG_DCH, // CMU在线,不可充,不可放
}cmu_bat_status_u;
typedef struct
{
	uint8_t  sys_status;
	uint8_t  bat_status;           // status of CMU
	uint8_t  bat_rack_cnt;     // numbers of battery rack per CMU
	uint8_t  soc_chg;
	uint8_t  soh_chg;
	uint8_t  soc_dch;
	uint8_t  soh_dch;
	uint16_t *soc;
	uint16_t *soh;
	int16_t limit_power_chg; // 0.1KW
	int16_t limit_power_dch; // 0.1KW
	uint8_t action;
}cmu_t;

typedef struct
{
	uint8_t port;
	uint8_t slave_addr;
	uint16_t timeout;
	uint32_t baud;
	uint16_t *p_buff;
	float32_t vol_ratio;
	float32_t cur_ratio;
	float32_t symbol;
	uint8_t slave_num;
	uint8_t model;
	uint8_t parm_init_flag;
}rs485_settting_parm_t;

typedef enum
{
	DEBUG_USE_DEMAND_SIDE = 0,
	DEBUG_USE_ANTI_BACKFLOW,
	DEBUG_USE_AUTOMATIC,
	DEBUG_USE_C2D,
	DEBUG_USE_CPFV,
	DEBUG_USE_SOC_MAINT,
	DEBUG_USE_END,
}debug_info_u;

typedef struct
{
	uint8_t check_flag[DEBUG_USE_END];
}debug_info_t;


/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/
extern bool_t trigger_pcs_const;
extern bool_t trigger_pcs_var;
extern bool_t shutdown_fault;

extern bool_t g_trigger_sn_analysis;
extern bool_t g_model_read_fail;
extern uint16_t pcs_last_updating_cnt;
extern pcsm_group_t pcsm_group[GROUP_NUMS];

extern bool_t afe_set_ok;
extern bool_t trigger_afe_delay;
extern pcsm_chg_dch_limit_t pcsm_chg_dch_limit[PCSM_NUMS];
extern debug_info_t debug_info_data;

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void pcs_init(void);

void can1_cmd_pcsm(pcsm_cmd_t *pcsm_cmd);
void fast_task_pcs_const(void);
void fast_task_clear_info(void);
void slow_task_sn_analysis(void);
void modbus_init(rs485_settting_parm_t rs485_settting_parm);

#endif
/******************************************************************************
* End of module
******************************************************************************/
