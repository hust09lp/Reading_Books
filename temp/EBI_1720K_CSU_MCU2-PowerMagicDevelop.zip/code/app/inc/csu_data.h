/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     csu_data.h
  * @brief    csu data module header file
  * @company  SOFARSOLAR
  * @author   XYF
  * @note     
  * @version  V02
  * @date     2023/03/07
  */
/*****************************************************************************/

#ifndef __CSU_DATA_H__
#define __CSU_DATA_H__

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "common.h"
#include "product.h"
#include "sdk.h"
#include "sdk_core.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
// working mode
enum
{
	NORMAL_MODE = 0,
	FCT_MODE
};

enum
{
	SLAVE = 0,
	MASTER
};

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/
typedef struct
{
	uint8_t req_offline_grid : 1;
	uint8_t sts_off          : 1;
	uint8_t req_sync_grid    : 1;
	uint8_t sts_on           : 1;
	uint8_t resv             : 4;
}grid_state_bits_t;

typedef union
{
	grid_state_bits_t bits;
	uint8_t all;
}grid_state_byte_t;

typedef struct
{
	grid_state_byte_t grid_state_word_byte0;
	uint8_t resv[7];
}csu_heart_packet_t;

typedef struct
{
	uint16_t csu_role;          // 0:slave, 1:master
	uint16_t working_mode;      // 0:normal, 1:factory
	csu_heart_packet_t heart_packet;
}csu_heart_t; 

typedef struct
{
	uint8_t     sn[22];
	version_t   boot_v;
	version_t   app_v;
	half_word_t hw_v;
//	half_word_t addr;
	half_word_t id;
	half_word_t can1_prtl_v;
	half_word_t can5_prtl_v;
	half_word_t csu_mods_v;
	uint16_t    base_rated_power;
	uint16_t 	system_rated_power;
	uint16_t    rat_power_p_total;
	uint16_t    max_power_p_total;
	uint16_t    max_power_q_total;
	uint16_t    max_power_s_total;
}csu_const_t;

typedef struct
{
	int16_t    board_temp;
}var_t;

typedef struct
{
	uint8_t ip[4];
	uint8_t subnetmask[4];
	uint8_t gateway[4];
	uint8_t dns[4];
}enet_parm_t;

typedef struct
{
	enet_parm_t enet_set;
}set_t;

typedef struct
{
	DATA_RW_E   rw;
	csu_heart_t csu_heart;
	var_t       var;
	csu_const_t csu_const;

//	state_t state;
//	fault_t fault;
	set_t   set;
//	calibration_t calibration;

	// PCSM_t PCSM[PCSM_COUNT];
}csu_data_t;

typedef struct
{
	uint16_t ctl;
}csu_ctl_t;

typedef struct
{
	csu_data_t csu_data;
	csu_ctl_t csu_ctl;
	sdk_rtc_t rtc;
}csu_t;

typedef struct
{
	uint16_t capacity_test : 1;
	uint16_t system_test   : 1;
	uint16_t restore_data  : 1;
	uint16_t csu_sn_enable : 1;
	uint16_t reserved      : 12;
}factory_parm_bits_t;

typedef union
{
	factory_parm_bits_t bits;
	uint16_t all;
}factory_parm_t;

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/
extern csu_data_t csu_data;
extern factory_parm_t factory_parm;

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void csu_data_init(void);

#endif
/******************************************************************************
* End of module
******************************************************************************/
