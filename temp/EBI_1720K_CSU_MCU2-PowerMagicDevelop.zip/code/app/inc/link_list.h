/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     link_list.h
  * @brief    link list module header file
  * @company  SOFARSOLAR
  * @author   XYF
  * @note     
  * @version  V01
  * @date     2023/03/07
  */
/*****************************************************************************/

#ifndef LINK_LIST_H
#define LINK_LIST_H

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------
//#include <stdlib.h>???

// Include project file ------------------------------------------------------
#include "common.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
typedef enum
{
	LLE_NO_ERR     =  0,
	LLE_NO_DATA    = -1,
	LLE_OUT_OF_MEM = -2
}LINK_LIST_ERR_E;

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/
struct list_node
{
	uint8_t           id;            // identifier
	void              *data;         // pointer to node data area
	struct list_node  *next;         // pointer to next list node
	struct list_node  *prev;         // pointer to previous list node
};
typedef struct list_node list_node_t;

typedef struct
{
	uint8_t          active_size;    // actual sizes of active nodes in the list
	list_node_t      *head;          // pointer to the list's head
	list_node_t      *tail;          // pointer to the list's tail
}link_list_t;

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void list_node_init(list_node_t *node);
void link_list_init(link_list_t *list);

LINK_LIST_ERR_E link_list_insert_node(link_list_t *list, uint8_t id, void *data, uint8_t type);
LINK_LIST_ERR_E link_list_del_node(link_list_t *list, list_node_t *node);

list_node_t *link_list_find_node(link_list_t *list, uint8_t id);
uint8_t link_list_get_size(link_list_t *list);
list_node_t *link_list_get_head(link_list_t *list);
list_node_t *link_list_get_tail(link_list_t *list);

#endif
/******************************************************************************
* End of module
******************************************************************************/
