/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     main.h
  * @brief    App main entry module header file
  * @company  SOFARSOLAR
  * @author   HH
  * @note     
  * @version  V01
  * @date     2023/02/19
  */
/*****************************************************************************/

#ifndef __MAIN_H__
#define __MAIN_H__

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------
#include <stdint.h>
#include <string.h>

// Include project file ------------------------------------------------------

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
// Flash space allocation:
#ifdef SOC_LPC54605
#define BOOT_START_FLASH_ADDR                                      (0x00000000)
// 32kB
#define FLASH_SECTOR_SIZE                                              (0x8000)
#endif

#ifdef SOC_LPC54606
#define BOOT_START_FLASH_ADDR                                      (0x00000000)
// 32kB
#define FLASH_SECTOR_SIZE                                              (0x8000)
#endif

#ifdef SOC_IMXRT1024
#define BOOT_START_FLASH_ADDR                                      (0x60000000)
// 4kB
#define FLASH_SECTOR_SIZE                                              (0x1000)
#endif

// 64kB
#define BOOT_FLASH_SIZE                                               (0x20000)
#define CORE_START_FLASH_ADDR         (BOOT_START_FLASH_ADDR + BOOT_FLASH_SIZE)
//#define FCT_PARA_START_FLASH_ADDR     (BOOT_START_FLASH_ADDR + BOOT_FLASH_SIZE)
// 64kB
//#define FCT_PARA_FLASH_SIZE                                           (0x10000)
//#define CORE_START_FLASH_ADDR (FCT_PARA_START_FLASH_ADDR + FCT_PARA_FLASH_SIZE)
// 256kB
#define CORE_FLASH_SIZE                                              (0x100000)
#define APP_START_FLASH_ADDR          (CORE_START_FLASH_ADDR + CORE_FLASH_SIZE)

#define CORE_SDK_API_START_FLASH_ADDR          (CORE_START_FLASH_ADDR + 0x8000)

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
int main(void);

#endif
/******************************************************************************
* End of module
******************************************************************************/

