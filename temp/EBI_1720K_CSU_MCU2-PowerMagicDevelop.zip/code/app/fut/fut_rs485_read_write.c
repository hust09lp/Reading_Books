/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     fut_rs485_read_write.c
  * @brief    Factory tests modbus read and write
  * @company  SOFARSOLAR
  * @author   ZT
  * @note
  * @version  V01
  * @date     2023/08/31
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------
#include <stdio.h>

// Include project file ------------------------------------------------------
#include "array.h"
#include "app_dido.h"
#include "common.h"
#include "calibration.h"
#include "csu_data.h"
#include "fut_rs485.h"
#include "fut_rs485_read_write.h"
#include "fut_function.h"
#include "product.h"
#include "pcs.h"
#include "setting.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
uint16_t *reg_hod[REG_HOD_NUMBER];
DATA_RW_E reg_hold_rw_status;
fut_param_t fut_param;

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/*****************************************************************************/
/**
 * @name  fut_reg_init.
 * @brief Factory test register initialization.[Called by rs485_task_fut]
 *
 * @param none   (I)
 * @param none   (O)
 * @return none
 */
/*****************************************************************************/
void fut_reg_init(void)
{
	uint8_t i;
	uint16_t addr;
	uint16_t *p_dst = NULL;

    clear_struct_data((uint8_t *)&fut_param, sizeof(fut_param_t));

	addr = REG_HOD_OFFSET1;

	p_dst = (uint16_t* )(&csu_mcu2_app_v);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t* )(&csu_mcu2_boot_v);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t* )(&csu_mcu2_core_v);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;

    reg_hod[addr++] = (uint16_t *)(&csu_mcu2_hw_v);
    reg_hod[addr++] = (uint16_t *)(&csu_data.csu_heart.working_mode);
	reg_hod[addr++] = (uint16_t *)(&array.pcsc.pcsc_data.var.t_board);
	reg_hod[addr++] = (uint16_t *)(&array.pcsc.pcsc_data.var.t_ac_fuse);
	reg_hod[addr++] = (uint16_t *)(&array.pcsc.pcsc_data.var.v_grd_rs);
	reg_hod[addr++] = (uint16_t *)(&array.pcsc.pcsc_data.var.v_grd_st);
	reg_hod[addr++] = (uint16_t *)(&array.pcsc.pcsc_data.var.v_grd_tr);
	reg_hod[addr++] = (uint16_t *)(&array.pcsc.pcsc_data.var.v_out_rs);
	reg_hod[addr++] = (uint16_t *)(&array.pcsc.pcsc_data.var.v_out_st);
	reg_hod[addr++] = (uint16_t *)(&array.pcsc.pcsc_data.var.v_out_tr);
	reg_hod[addr++] = (uint16_t *)(&array.pcsc.pcsc_data.var.i_out_r);
	reg_hod[addr++] = (uint16_t *)(&array.pcsc.pcsc_data.var.i_out_s);
	reg_hod[addr++] = (uint16_t *)(&array.pcsc.pcsc_data.var.i_out_t);
	reg_hod[addr++] = (uint16_t *)(&calibrate.status.half_word[0]);
	reg_hod[addr++] = (uint16_t *)(&g_dc_signal[T_AC_FUS].adc_avg);
	//spare
	p_dst = (uint16_t *)(&calibrate.ac[CALI_VGRID_RS].y);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_VGRID_ST].y);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_VGRID_TR].y);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_VPCS_RS].y);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_VPCS_ST].y);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_VPCS_TR].y);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_CURRENT_R].y);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_CURRENT_S].y);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_CURRENT_T].y);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;

	p_dst = (uint16_t *)(&calibrate.dc[CALI_AC_FUSE_TEMP].gain);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.dc[CALI_AC_FUSE_TEMP].offset);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_VGRID_RS].gain);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_VGRID_ST].gain);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_VGRID_TR].gain);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_VPCS_RS].gain);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_VPCS_ST].gain);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_VPCS_TR].gain);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_CURRENT_R].gain);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_CURRENT_S].gain);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_CURRENT_T].gain);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	reg_hod[addr++] = (uint16_t *)(&fut_param.factory_mode_setting);
	reg_hod[addr++] = (uint16_t *)(&fut_param.test_led_control_word);
	reg_hod[addr++] = (uint16_t *)(&array.pcsc.pcsc_ctrl.do_ctrl.all);
	reg_hod[addr++] = (uint16_t *)(&fut_param.test_di_result_status_word);
	reg_hod[addr++] = (uint16_t *)(&array.pcsc.pcsc_ctrl.pwm_enable);
	reg_hod[addr++] = (uint16_t *)(&fut_param.test_com_control_word);

	p_dst = (uint16_t *)(&calibrate.dc[CALI_AC_FUSE_TEMP].x1);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.dc[CALI_AC_FUSE_TEMP].x2);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	reg_hod[addr++] = (uint16_t *)(&calibrate.dc[CALI_AC_FUSE_TEMP].y1);
	reg_hod[addr++] = (uint16_t *)(&calibrate.dc[CALI_AC_FUSE_TEMP].y2);
	p_dst = (uint16_t *)(&calibrate.ac[CALI_VPCS_RS].x);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_VPCS_RS].y);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_VPCS_ST].x);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_VPCS_ST].y);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_VPCS_TR].x);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_VPCS_TR].y);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;

	p_dst = (uint16_t *)(&calibrate.ac[CALI_VGRID_RS].x);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_VGRID_RS].y);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_VGRID_ST].x);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_VGRID_ST].y);
	reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_VGRID_TR].x);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_VGRID_TR].y);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_CURRENT_R].x);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_CURRENT_R].y);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_CURRENT_S].x);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_CURRENT_S].y);
	reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_CURRENT_T].x);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	p_dst = (uint16_t *)(&calibrate.ac[CALI_CURRENT_T].y);
    reg_hod[addr++] = p_dst + 1;
    reg_hod[addr++] = p_dst;
	reg_hod[addr++] = (uint16_t *)(&fut_param.factory_test_result_status_word);

	p_dst = (uint16_t *)(&sz_csu_sn);
	for(i = 0; i < SN_WORD_LEN; i++)
	{
		reg_hod[addr++] = p_dst + i;
	}

	reg_hod[addr++] = (uint16_t *)(&fut_param.com_test_result_status_word);

	reg_hod[addr++] = (uint16_t *)(&array.pcsc.pcsc_data.var.t_reserve_1);
	reg_hod[addr++] = (uint16_t *)(&array.pcsc.pcsc_data.var.t_reserve_2);
	reg_hod[addr++] = (uint16_t *)(&g_dc_signal[RESERVE_1].adc_avg);
	reg_hod[addr++] = (uint16_t *)(&g_dc_signal[RESERVE_2].adc_avg);

	p_dst = (uint16_t *)(&dc_volt[0]);
	for(i = 0; i < AD_SAMPLE_POINT_NUM; i++)
	{
		reg_hod[addr++] = p_dst + i;
	}
}

/*****************************************************************************/
/**
 * @name  fut_param_parase.
 * @brief Parse the parameters written by the factory test.[Called by fut_reg_write]
 *
 * @param offset    (I)
 * @param reg_num   (O)
 * @return 1：valid, -1：unvalid
 */
/*****************************************************************************/
int32_t fut_param_parase(uint16_t offset, uint16_t reg_num)
{
	int32_t  result = 1;
	uint16_t reg_value;

	if (offset == FACTORY_MODE_SETTING)
	{
		reg_value = *reg_hod[offset];
		switch (reg_value)
		{
			case DISABLE:
				csu_data.csu_heart.working_mode = NORMAL_MODE;
				fut_exit_init();
				break;
			case ENABLE:
				csu_data.csu_heart.working_mode = FCT_MODE;
				fut_enter_init();
				break;
			default:
				break;
		}
	}

	reg_value = csu_data.csu_heart.working_mode;
	if (reg_value == FCT_MODE)
	{
		switch (offset)
		{
			case TEST_LED_CONTROL_WORD:
				//Leds do not require control
				reg_value = *reg_hod[TEST_LED_CONTROL_WORD];
				if (reg_value == ENABLE)
				{
				}
				else if (reg_value == DISABLE)
				{
				}
				else
				{
					result = -1;
				}
				break;
			case TEST_DO_CONTROL_WORD:
				reg_value = *reg_hod[TEST_DO_CONTROL_WORD];
				do_on_off(reg_value);
				break;
			case TEST_PWM_SYNC_CONTROL_WORD:
				// pwm does not require control
				reg_value = *reg_hod[TEST_PWM_SYNC_CONTROL_WORD];
				if (reg_value == ENABLE)
				{
				}
				else if (reg_value == DISABLE)
				{
				}
				else
				{
					result = -1;
				}
				break;
			case CALIB_V_PCS_RS:
				calibrate_ac(CALI_VPCS_RS);
				break;
			case CALIB_V_PCS_ST:
				calibrate_ac(CALI_VPCS_ST);
				break;
			case CALIB_V_PCS_TR:
				calibrate_ac(CALI_VPCS_TR);
				break;
			case CALIB_V_GRD_RS:
				calibrate_ac(CALI_VGRID_RS);
				break;
			case CALIB_V_GRD_ST:
				calibrate_ac(CALI_VGRID_ST);
				break;
			case CALIB_V_GRD_TR:
				calibrate_ac(CALI_VGRID_TR);
				break;
			case CALIB_I_R:
				calibrate_ac(CALI_CURRENT_R);
				break;
			case CALIB_I_S:
				calibrate_ac(CALI_CURRENT_S);
				break;
			case CALIB_I_T:
				calibrate_ac(CALI_CURRENT_T);
				break;
			case SN_SERIAL_NUMBER:
				setting_set(FUT_SET, EE_CSU_SN, &sz_csu_sn[0], 20);
				break;
			default:
				result = -1;
				sdk_log_d("modbus set pcsm wrong!\r\n");
				break;
		}
	}
	return result;
}

/*****************************************************************************/
/**
 * @name  fut_reg_read.
 * @brief modbus 03 Function code read register.[Called by fut_modbus_parse]
 *
 * @param reg_addr   (I)
 * @param reg_num    (O)
 * @param p_rsp      (O)
 * @return >0: return data length, 0: register busy, <0: write address error
 */
/*****************************************************************************/
int32_t fut_reg_read(uint16_t reg_addr, uint16_t reg_num, uint8_t *p_rsp)
{
	uint8_t i;
	uint16_t offset;
	uint16_t addr_end;
	uint16_t pointer;
	int32_t result;
	half_word_t temp;

	if((reg_addr >= REG_START_ADDR) && (reg_addr <= REG_END_ADDR))
	{
		pointer = 1;
		*p_rsp = reg_num * 2;
		offset = reg_addr - REG_START_ADDR;
		addr_end = offset + reg_num;
		if(reg_hold_rw_status == DATA_FREE)
		{
			reg_hold_rw_status = DATA_READING;

			for(i = offset; i < addr_end; i++)
			{
				if((i >= SN_START_OFFSET) && (i <= SN_END_OFFSET))
				{
					setting_get(FUT_SET, EE_CSU_SN, &sz_csu_sn[0], 20);
					temp.all = *reg_hod[i];
					*(p_rsp + pointer++) = temp.bytes.low;
					*(p_rsp + pointer++) = temp.bytes.high;
				}
				else
				{
					temp.all = *reg_hod[i];
					*(p_rsp + pointer++) = temp.bytes.high;
					*(p_rsp + pointer++) = temp.bytes.low;
				}
			}
			reg_hold_rw_status = DATA_FREE;
			result = pointer;
		}
		else
		{
			result = 0;
		}
	}
	else
	{
		result = -1;
	}

	return result;
}

/*****************************************************************************/
/**
 * @name  fut_reg_write
 * @brief modbus writes to multiple registers.[Called by fut_modbus_parse]
 *
 * @param reg_addr   (I)
 * @param reg_num    (O)
 * @param p_rsp      (O)
 * @return >0: return data length, 0: register busy, <0: write address error
 */
/*****************************************************************************/
int32_t fut_reg_write(uint16_t reg_addr, uint16_t reg_num, const uint8_t *p_data)
{
	uint8_t i;
	uint16_t offset;
	uint16_t addr_end;
	int32_t result;
	half_word_t temp;

	if ((reg_addr >= REG_WRITE_START_ADDR) && (reg_addr <= REG_END_ADDR))
	{
		offset = reg_addr - REG_START_ADDR;
		addr_end = offset + reg_num;
		if(reg_hold_rw_status == DATA_FREE)
		{
			reg_hold_rw_status = DATA_WRITING;
			for(i = offset; i < addr_end; i++)
			{
				if ((i >= SN_START_OFFSET) && (i <= SN_END_OFFSET))
				{
					temp.bytes.low = *p_data;
					temp.bytes.high  = *(p_data + 1);
					*reg_hod[i] = temp.all;
				}
				else
				{
					temp.bytes.high = *p_data;
					temp.bytes.low  = *(p_data + 1);
					*reg_hod[i] = temp.all;
				}
				p_data += 2;
				fut_param_parase(i, reg_num);
			}
			reg_hold_rw_status = DATA_FREE;
			result = 4;
		}
		else
		{
			result = 0;
		}
	}
	else
	{
		result = -1;
	}

	return result;
}

/******************************************************************************
* End of module
******************************************************************************/
