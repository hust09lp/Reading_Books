/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     fut_rs485.c
  * @brief    Factory test modbus communication
  * @company  SOFARSOLAR
  * @author   ZT
  * @note
  * @version  V01
  * @date     2023/08/31
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "common.h"
#include "csu_data.h"
#include "cup_sofar_can.h"
#include "fut_function.h"
#include "fut_rs485.h"
#include "fut_rs485_read_write.h"
#include "rs485_hmi.h"
#include "sdk.h"
#include "sdk_core.h"
#include "sofar_errors.h"
#include "task_manage.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
uint8_t query_buf[MOD_FRAME_MAX_NUM];
bool_t trigger_fut_rs485;

//uint8_t trigger_clac_dc;
int16_t dc_volt[AD_SAMPLE_POINT_NUM];
/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/*****************************************************************************/
/**
 * @name  rs485_fut_init.
 * @brief Factory test initialization. [Called by app]
 *
 * @param none   (I)
 * @param none   (O)
 * @return none
 */
/*****************************************************************************/
void rs485_fut_init(void)
{
    clear_struct_data((uint8_t *)&query_buf[0], sizeof(query_buf));
	fut_rs485_init(RS485_1, 1, MODBUS_BAUD_9600);
	fut_reg_init();
	trigger_fut_rs485 = TRUE;
}

/*****************************************************************************/
/**
 * @name  fut_enter_init.
 * @brief Enter factory initialization. [Called by fut_param_parase]
 *
 * @param none   (I)
 * @param none   (O)
 * @return none
 */
/*****************************************************************************/
void fut_enter_init(void)
{
	fut_can5_init();
	fut_rs485_init(RS485_2, 2, MODBUS_BAUD_9600);
	fut_rs485_init(RS485_5, 5, MODBUS_BAUD_9600);
	fut_rs485_init(RS485_7, 7, MODBUS_BAUD_9600);
}

/*****************************************************************************/
/**
 * @name  fut_exit_init.
 * @brief Exit factory initialization. [Called by fut_param_parase]
 *
 * @param none   (I)
 * @param none   (O)
 * @return none
 */
/*****************************************************************************/
void fut_exit_init(void)
{
	sdk_can_close(CAN5_PORT);
	sdk_modbus_free(RS485_2);
	sdk_modbus_free(RS485_5);
	sdk_modbus_free(RS485_7);
}

/*****************************************************************************/
/**
 * @name  fut_rs485_init
 * @brief Factory test modbus initialization. [Called by fut_param_parase]
 *
 * @param port_num          (I) //Software virtual ID
 * @param slave_address     (I)
 * @param baud              (I)
 * @return none
 */
/*****************************************************************************/
void fut_rs485_init(uint32_t port_num, uint32_t slave_address, uint32_t baud)
{
    int32_t result;

	result = sdk_modbus_rtu_init(port_num, slave_address, baud);
	if(result != SF_OK)
	{
		sdk_log_d("RS485 modbus init failed!\r\n");
		return;
	}

	result = sdk_modbus_connect(port_num);
	if(result != SF_OK)
	{
		sdk_log_d("RS485 modbus connect failed!\r\n");
		return;
	}

	result = sdk_modbus_response_timeout_set(port_num, 10);
	if(result != SF_OK)
	{
		sdk_log_d("RS485 response set timeout failed!\r\n");
		return;
	}

	result = sdk_modbus_indication_timeout_set(port_num, 10);
	if(result != SF_OK)
	{
		sdk_log_d("RS485 modbus indication set timeout failed!\r\n");
		return;
	}
}

/*****************************************************************************/
/**
 * @name  fut_can5_init
 * @brief Factory test modbus initialization. [Called by fut_param_parase]
 *
 * @param NONE
 * @return none
 */
/*****************************************************************************/
void fut_can5_init(void)
{
	uint8_t ret;
	sdk_can_cfg_t can_config;

	can_config.baud = SDK_CAN_BAUD_500K;
    can_config.mode = SDK_CAN_MODE_NORMAL;

	ret = sdk_can_open(CAN5_PORT);
	if(ret != SF_OK)
	{
		sdk_log_d("CAN5 open failed!\r\n");
		return ;
	}
	ret = sdk_can_setup(CAN5_PORT, &can_config);
	if(ret != SF_OK)
	{
		sdk_log_d("CAN5 setup failed!\r\n");
		return ;
	}
	ret = cup_sofar_can_init();
	if(ret != SF_OK)
	{
		sdk_log_d("cup_sofar_can_init failed\r\n");
		return ;
	}
}

/*****************************************************************************/
/**
 * @name  fut_modbus_parse
 * @brief modbus communication frame parsing. [Called by rs485_task_fut]
 *
 * @param port_num     (I) //Software virtual ID
 * @param func         (I)
 * @param p_req        (I)
 * @param p_req        (O)
 * @param sp_size      (O)
 * @return >0: return data length, 0: register busy, <0: write address error
 */
/*****************************************************************************/
int32_t fut_modbus_parse(uint32_t port_num, uint32_t func, const uint8_t *p_req,\
											uint8_t *p_rsp, int32_t rsp_size)
{
    int32_t result = -1;
	uint16_t reg_addr;
	uint16_t reg_num;
	const uint8_t *p_data = NULL;
	half_word_t temp;

	if((p_req == NULL) || (p_rsp == NULL))
	{
		return result;
	}

	temp.bytes.high = p_req[0];
	temp.bytes.low  = p_req[1];
	reg_addr = temp.all;
	temp.bytes.high = p_req[2];
	temp.bytes.low  = p_req[3];
	reg_num  = temp.all;

	switch(func)
	{
		case MODBUS_READ_HOLDING_REGISTERS:
			result  = fut_reg_read(reg_addr, reg_num, p_rsp);
			break;
		case MODBUS_WRITE_SINGLE_REGISTER:
			reg_num = 1;
			p_data  = p_req + 2;
			result  = fut_reg_write(reg_addr, reg_num, p_data);
			// addr
			p_rsp[0] = p_req[0];
			p_rsp[1] = p_req[1];
			// num
			p_rsp[2] = p_req[2];
			p_rsp[3] = p_req[3];
			break;
		case MODBUS_WRITE_MULTIPLE_REGISTERS:
			p_data = p_req + 5;
			result = fut_reg_write(reg_addr, reg_num, p_data);
			// addr
			p_rsp[0] = p_req[0];
			p_rsp[1] = p_req[1];
			// num
			p_rsp[2] = p_req[2];
			p_rsp[3] = p_req[3];
			break;
		default:
			break;
	}

	return result;
}

/*****************************************************************************/
/**
 * @name  rs485_task_fut
 * @brief modbus communication task. [Called by app]
 *
 * @param none     (I)
 * @param none     (I)
 * @return none
 */
/*****************************************************************************/
void rs485_task_fut(void)
{
    int32_t data_num1;
	int32_t data_num2;
	int32_t data_num5;
	int32_t data_num7;
	half_word_t test_ctrl;

	data_num1 = sdk_modbus_receive(RS485_1, query_buf);
	if(data_num1 > 0)
	{
		sdk_modbus_reply(RS485_1, query_buf, data_num1, fut_modbus_parse);
	}
	else if(data_num1 < 0)
	{
		sdk_log_d("modbus receive failed!\r\n");
	}

	if(csu_data.csu_heart.working_mode == FCT_MODE)
	{
		data_num2 = sdk_modbus_receive(RS485_2, query_buf);
		data_num5 = sdk_modbus_receive(RS485_5, query_buf);
		data_num7 = sdk_modbus_receive(RS485_7, query_buf);
		if(data_num2 > 0)
		{
			sdk_modbus_reply(RS485_2, query_buf, data_num2, fut_modbus_parse);
		}
		else if(data_num2 < 0)
		{
			sdk_log_d("modbus receive failed!\r\n");
		}

		if(data_num5 > 0)
		{
			sdk_modbus_reply(RS485_5, query_buf, data_num5, fut_modbus_parse);
		}
		else if(data_num5 < 0)
		{
			sdk_log_d("modbus receive failed!\r\n");
		}

		if(data_num7 > 0)
		{
			sdk_modbus_reply(RS485_7, query_buf, data_num7, fut_modbus_parse);
		}
		else if(data_num7 < 0)
		{
			sdk_log_d("modbus receive failed!\r\n");
		}
		di_test_result();
		test_ctrl.all = *reg_hod[TEST_COM_CONTROL_WORD];
		if (test_ctrl.bits.b0 == ENABLE)
		{
			rs485_can_test();
		}
		dc_volt_calc();
	}
}

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/******************************************************************************
* End of module
******************************************************************************/

