/**
 * @file         sdk_fds.h
 * @brief        多路复用IO模型接口
 * @author       chenzq
 * @version      V0.0.1
 * @date         2023/02/16
 * @copyright    Copyright (c) 2023 by SofarSolar, All Rights Reserved.
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author    <th>Description
 * <tr><td>2023/02/16  <td>0.0.1    <td>chenzq     <td>创建初始版本
 * </table>
 *
 **********************************************************************************
 * @par 示例:
 * @code
 * 暂无
 * @endcode
 */

#ifndef __SDK_FDS_H__
#define __SDK_FDS_H__

#include <string.h>
#include "data_types.h"

#ifndef  SDK_FD_SETSIZE
#define  SDK_FD_SETSIZE  16
#endif

typedef   long    sdk_fd_mask;

#ifndef   SDK_TYPES_FD_SET
#define   SDK_NBBY    8      
#define   SDK_NFDBITS (sizeof (sdk_fd_mask) * SDK_NBBY)   

#define   SDK_HOWMANY(x,y)    (((x)+((y)-1))/(y))

typedef struct {
    long fds_bits[SDK_HOWMANY(SDK_FD_SETSIZE, SDK_NFDBITS)];
} fd_set_t;

#define SDK_FD_SET(n, p)    ((p)->fds_bits[(n)/SDK_NFDBITS] |= (1L << ((n) % SDK_NFDBITS)))   // 将一个文件描述符加入文件描述符集中
#define SDK_FD_CLR(n, p)    ((p)->fds_bits[(n)/SDK_NFDBITS] &= ~(1L << ((n) % SDK_NFDBITS)))  // 将一个文件描述符从文件描述符集清除
#define SDK_FD_ISSET(n, p)  ((p)->fds_bits[(n)/SDK_NFDBITS] & (1L << ((n) % SDK_NFDBITS)))    // 测试该集中的一个文件描述符有无发生变化
#define SDK_FD_ZERO(p)      memset((void*)(p), 0, sizeof(*(p)))                               // 清除一个文件描述符集
#endif 

typedef struct 
{
  uint32_t  tv_sec;     // 单位：秒 
  uint32_t  tv_usec;    // 单位：毫秒 
}time_val_t;

typedef struct 
{
  int32_t   fd;
  int16_t   events;
  int16_t   revents;
}pollfd_t;

/**
 * @brief    监听文件描述符状态改变
 * @param    [in] nfds        需要检查的号码最高的文件描述符加1
 * @param    [in] p_read_fds  监视的读文件描述符集合
 * @param    [in] p_write_fds 监视的写文件描述符集合
 * @param    [in] p_error_fds 监视的异常处理文件描述符集合
 * @param    [in] p_timeout   指向超时结构体指针
 * @return    执行结果
 * @retval    >=0  成功 准备好的文件描述符
 * @retval    <0 失败
 */
int32_t sdk_fds_select(int32_t nfds, fd_set_t *p_read_fds, fd_set_t *p_write_fds, fd_set_t *p_error_fds, time_val_t *p_timeout);

/**
 * @brief    
 * @param    [in] p_fds     监视的文件描述符结构体指针
 * @param    [in] nfds      文件描述符的总数量
 * @param    [in] timeout   阻塞事件，单位ms
 * @return   int32_t 大于0，表示有描述符的状态发生变化；0 超时； 小于0 有错误发生
 * @retval   大于0，表示有描述符的状态发生变化；
 * @retval   0 超时；
 * @retval   小于0 有错误发生
 */
int32_t sdk_fds_poll(pollfd_t *p_fds, uint32_t nfds, int32_t timeout);//


#endif /* __SDK_FDS_H__ */
