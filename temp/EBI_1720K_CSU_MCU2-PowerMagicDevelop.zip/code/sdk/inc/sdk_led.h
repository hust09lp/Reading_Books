/**
 * @file         sdk_led.h
 * @brief        led功能定义
 * @details     主要包含了关于led功能的相关函数
 * @author       renwj
 * @note         无
 * @version      V1.0.1 初始版本
 * @date         2022/12/30
 * @copyright   Copyright(c) 2022 by SofarSolar, All Rights Reserved. 
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author    <th>Description
 * <tr><td>2022/12/30  <td>1.0.1    <td>renwj     <td>创建初始版本
 * <tr><td>2023/3/7    <td>1.0.2    <td>renwj     <td>入参id统一修改为led_id
 * </table>
 *
 **********************************************************************************
 * @par 示例:
 * @code
 * 暂无
 * @endcode
 */

#ifndef __SDK_LED_H__
#define __SDK_LED_H__

#include "data_types.h"

#define LED_ID_MAX           6      ///< LED器编号最大值

/**
 * @brief    led闪烁
 * @param    [in] led_id        led虚拟编号
 * @param    [in] period        led闪烁周期
 * -# 最小周期为任务周期或扫描周期（建议10ms）,需是任务及扫描周期的倍数
 * @param    [in] duty        led闪烁占空比
 * -# 0-100,表示0%-100%
 * @param    [in] times        led闪烁次数
 * -# -1 持续闪烁
 * -# >=0 闪烁次数
 * @return    执行结果
 * @retval    0  成功
 * @retval    < 0 为异常，详情见sofar_errors.h
 * @warning 使用此函数时要注意 参数之间的关系需要：period*duty > 此函数被调用周期*100。否则不会闪烁。
 */
int32_t sdk_led_flash(uint32_t led_id, uint32_t period, uint32_t duty, int32_t times);
 
/**
 * @brief    LED灯亮
 * @param    [in] led_id    led虚拟编号
 * @return    执行结果
 * @retval    0  成功
 * @retval    < 0 为异常，详情见sofar_errors.h
 */
int32_t sdk_led_on(uint32_t led_id);

/**
 * @brief    LED灯灭
 * @param    [in] led_id    led虚拟编号
 * @return    执行结果
 * @retval    0  成功
 * @retval    < 0 为异常，详情见sofar_errors.h
 */
int32_t sdk_led_off(uint32_t led_id);

/**
 * @brief   配置 led_id 参数
 * @param   led_id 虚拟id
 * @param   cmd     led_id 操作命令
 * @param   p_arg   led_id 操作命令的参数
 * @return  执行结果
 * @retval  SF_OK   成功
 * @retval  < 0 为异常，详情见sofar_errors.h
 */
int32_t sdk_led_ioctl(uint32_t led_id, uint32_t cmd, void *p_arg);


#endif /*__SDK_LED_H__*/
