#ifndef __SDKTIMER_H__
#define __SDKTIMER_H__

#include "data_types.h"

typedef enum
{
    SDK_TIMER_0,
    SDK_TIMER_1,
    SDK_TIMER_2,
    SDK_TIMER_3,
}timer_id_e;


typedef enum
{
    TIMER_TYPE_HARD,
    TIMER_TYPE_SOFT,
}timer_type_e;


typedef void(*call_back_f)(void *args);


/**
 * @brief 初始化定时器
 * @param [in] id    定时器id
 * @param [in] type  定时器类型，硬件定时器和软件定时器
 * @return  执行结果
 * @retval  SF_OK   执行成功
 * @retval  < 0      执行失败
 */
int32_t sdk_timer_init(uint32_t id, timer_type_e type);

/**
 * @brief 设置硬件定时器回调函数
 * @param [in] id    定时器id
 * @param [in] type  定时器类型，硬件定时器和软件定时器
 * @param [in] us    定时器周期
 * @param [in] call_back 回调函数
 * @return  执行结果
 * @retval  SF_OK   执行成功
 * @retval  < 0      执行失败
 */
int32_t sdk_timer_set(uint32_t id, timer_type_e type, uint32_t us, call_back_f call_back);

/**
 * @brief 定时器启动
 * @param id        定时器id
 * @param type      定时器类型
 * @return  执行结果
 * @retval  SF_OK   执行成功
 * @retval  < 0      执行失败
 */
int32_t sdk_timer_start(uint32_t id, timer_type_e type);

/**
 * @brief 定时器停止
 * @param id        定时器id
 * @param type      定时器类型
 * @return  执行结果
 * @retval  SF_OK   执行成功
 * @retval  < 0      执行失败
 */
int32_t sdk_timer_stop(uint32_t id, timer_type_e type);



#endif

