import os
import shutil
import struct
import sys

boot_path = '../../tools/BIN/CSU_MCU2_BOOT_0x60000000.bin'
core_path = '../../tools/BIN/CSU_MCU2_CORE_0x60020000.bin'
app_path = '../../output/PowerMagic_CSU_MCU2.bin'
bin_output_path = '../../output/PowerMagic_CSU_MCU2_0x60000000.bin'
hex_output_path = '../../output/PowerMagic_CSU_MCU2_0x60000000.hex'
signal_file_path = r'..\..\tools\sofar_pack_upgrade_file_power_magic.bat'
def combine_bin(bin1_path, bin2_path, bin3_path, output_path):
    offset1 = 0x00000000
    offset2 = 0x00020000
    offset3 = 0x00120000
    try:
        bin_1 = open(bin1_path, 'rb')
        bin_2 = open(bin2_path, 'rb')
        bin_3 = open(bin3_path, 'rb')
    except IOError as e:
        print(f"文件打开失败: {e}")
        sys.exit(1)  # 退出程序，状态码1表示失败
    shutil.copyfile(bin1_path,output_path)
    bin_merge = open(output_path, 'ab')
    bin1_size = os.path.getsize(bin1_path)
    bin2_size = os.path.getsize(bin2_path)
    bin3_size = os.path.getsize(bin3_path)
    print(bin1_size,bin2_size,bin3_size)
    bin_result_size = os.path.getsize(output_path)
    print(bin_result_size)

    final_size = 1024*1152*1 + bin3_size
    print(final_size)
    
    offset = bin_result_size

    value_default = struct.pack('B', 0xff)
    
    while offset < final_size:
        if offset == offset2:
            data = bin_2.read()
            bin_merge.write(data)
            offset = bin_merge.tell()
        elif offset == offset3:
            data = bin_3.read()
            bin_merge.write(data)
            offset = bin_merge.tell()
        else:
            bin_merge.write(value_default)
            offset = bin_merge.tell()
    bin_1.close()
    bin_2.close()
    bin_3.close()
    bin_merge.close()
def to_hex_string(byte):
    return '{:02X}'.format(byte)

def calculate_checksum(record):
    total = sum(record)
    return ((~total + 1) & 0xFF)
def bin_to_hex(bin_file, hex_file, start_address=0x60000000):
    with open(bin_file, 'rb') as bin_f:
        bin_data = bin_f.read()
    
    hex_records = []
    address = start_address
    current_segment = (address >> 16) & 0xFFFF  # 初始化当前段地址

    # 添加第一行扩展线性地址记录
    record = [0x02, 0x00, 0x00, 0x04, (current_segment >> 8) & 0xFF, current_segment & 0xFF]
    checksum = calculate_checksum(record)
    record.append(checksum)
    hex_record = ':' + ''.join(to_hex_string(byte) for byte in record)
    hex_records.append(hex_record)

    for i in range(0, len(bin_data), 32):
        # 当前段地址
        segment = (address >> 16) & 0xFFFF
        if segment != current_segment:
            # 如果段地址变化，添加扩展线性地址记录
            current_segment = segment
            record = [0x02, 0x00, 0x00, 0x04, (segment >> 8) & 0xFF, segment & 0xFF]
            checksum = calculate_checksum(record)
            record.append(checksum)
            hex_record = ':' + ''.join(to_hex_string(byte) for byte in record)
            hex_records.append(hex_record)

        chunk = bin_data[i:i+32]
        length = len(chunk)
        record = [length, (address >> 8) & 0xFF, address & 0xFF, 0x00] + list(chunk)
        checksum = calculate_checksum(record)
        record.append(checksum)
        hex_record = ':' + ''.join(to_hex_string(byte) for byte in record)
        hex_records.append(hex_record)
        address += length

    hex_records.append(':00000001FF')  # End of file record

    with open(hex_file, 'w') as hex_f:
        hex_f.write('\n'.join(hex_records) + '\n')
        print("convert_bin_to_hex ok")

def run_bat_script(bat_file_path):
    # 调用 .bat 文件
    result = os.system(signal_file_path)
    # result = subprocess.run([bat_file_path], check=True, capture_output=True, text=True)
    print("BAT脚本执行完成。")
    print("输出：", result)


if __name__ == "__main__": 
    run_bat_script(signal_file_path)
    combine_bin(boot_path, core_path, app_path, bin_output_path)
    bin_to_hex(bin_output_path, hex_output_path)
