#include "main.h"

#include "sdk.h"
#include "sdk_core.h"


#define VERSION_LENGTH_MAX          12

//#define HEART_LED                   LED_ID_1


void app_task_1(void *argument)
{
    sdk_log_d("app_task_1 start\r\n");
    
    while(1)
    {
        sdk_os_delay(sdk_os_tick_from_millisecond(10));
    }
}

uint32_t g_app_thread_1_stack[1024/4];
sdk_os_thread_attr_tab_t g_app_thread1_attr = {
    .thread_attr = {
                        "app_task_1",
                        0,
                        NULL,
                        0,
                        10,
                        (void *)g_app_thread_1_stack,
                        sizeof(g_app_thread_1_stack),
                        OS_APP_PRIORITY_1,
                        0,
                    },
    .func = app_task_1,
    .thread_id = NULL,
};

extern int Region$$Table$$Base;
/**
* @brief        app全局变量初始化
* @param        void
* @return       void
*/
void app_global_load(void)
{
    int global_buf[8];

    memcpy(global_buf, (void *)&Region$$Table$$Base, sizeof(global_buf));
    memcpy((void *)global_buf[1], (void *)global_buf[0], global_buf[2]);
    memset((void *)global_buf[5], 0, global_buf[6]);
}

int main(void)
{
    int32_t ret;
    int8_t sdk_ver[VERSION_LENGTH_MAX] = {0};

    app_global_load();
    
    ret = core_sdk_api_init(CORE_SDK_API_FLASH_ADDR);
    if (ret != SDK_OK)
    {
        return -1;  // 获取SDK的API接口失败
    }
    
    ret = sdk_version_get(SDK_VERSION_TYPE, sdk_ver, VERSION_LENGTH_MAX);
    if (strcmp((char *)sdk_ver, SDK_VERSION_INFO) != 0)
    {
        return -2;  // SDK版本不一致，禁止启动App程序
    }
    
    sdk_log_i("***********************************\r\n");
    sdk_log_i("APP Project Start Running....\r\n");
    sdk_log_i("SDK Version:%s....\r\n", sdk_ver);
    sdk_log_i("***********************************\r\n");

//    sdk_led_flash(HEART_LED, 1000, 50, LED_FLASH_CONTINUE);
    
    ret = sdk_os_thread_new(1, &g_app_thread1_attr);
    if (ret != 0)
    {
        sdk_log_e("app_task_1 Create fail\r\n");
    }
    
    while(1)
    {
        sdk_os_delay(sdk_os_tick_from_millisecond(100));
    }
}

typedef int (*app_start_func)(void);
const app_start_func app_main __attribute__((at(APP_START_FLASH_ADDR))) = {main};
