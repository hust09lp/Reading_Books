/** 
 * @file          sdk_ipc.h
 * @brief         进程间通讯接口函数说明
 * @author        qinmingsheng
 * @version       V0.0.1     初始版本
 * @date          2022/12/20 11:12:30
 * @lastAuthor    Please set LastEditors
 * @copyright     Copyright (c) 2022 by SofarSolar, All Rights Reserved. 
 */
#ifndef __SDK_IPC_H__
#define __SDK_IPC_H__

#include <stdint.h>

#define MAX_NAME_LEN    16    //最后一个字节为空，name实际长度为15个字节。
#define MAX_EVENT_NUM   32    //每个进程的事件总数。
#define MAX_PROCESS_NUM 16    //业务层进程最大值
#define MAX_DATA_LEN    1024

/** 
 * @brief        注册事件服务到进程通信服务中
 * @param        [in] p_name ，所有注册的事件名称（长度越小越好，建议不要超过8个字节）
 * @return       [int32_t]执行结果
 * @retval		   >0 成功,值表示返回的ID标识符
 * @retval		   <0 失败，值对应错误代码
 * @note         使用服务前必须调用此函数进行注册
 */
int32_t sdk_msg_regist(int8_t *p_name);

/** 
 * @brief        服务连接函数，连接其它进程或线程已经注册成功的事件。
 * @param        [in] p_name ，注册时的事件名称
 * @return       [int32_t] 执行结果
 * @retval       >0 成功，值表示返回的obj_id,通过此ID可以进行数据的收发。
 * @retval       <0 失败，值对应错误代码。-1：此事件未注册或未成功注册
 * @note         只有本进程或其它进程成功调用sdk_msg_regist(int8_t *p_name)后，此函数才有可能正确返回
 */
int32_t sdk_msg_connect(int8_t *p_name);

/** 
 * @brief        数据发送函数，数据发送到指定的obj_id
 * @param        [in] obj_id 函数sdk_msg_connect(int8_t *p_name)成功返回值，
 * @param        [in] p_msg_t 可以是任何类型结构体。
 * @param        [in] msg_size 入参p_msg_t的大小，单位字节。
 * @return       [int32_t] 执行结果
 * @retval       >0成功，实际发送数据长度
 * @retval       <0失败，-1：obj_id无效或不存在
 * @note         向指定的obj_id发送数据
 */
int32_t sdk_msg_send(int32_t obj_id, const void *p_msg_t, const uint32_t msg_size); //p_msg_t可以是任何类型结构体。

/** 
 * @brief        接收其它进程或线程序发送到obj_id的数据
 * @param        [in] obj_id 传入参数，指定的数据来源，函数sdk_msg_connect(int8_t *p_name)成功返回值
 * @param        [out] p_msg_t 传出参数，数据存放在p_msg_t指向的地址中。
 * @param        [out] msg_size 传出参数，数据长度
 * @param        [in] wait_time 传入参数，需要等待时间，单位：ms，0表示一直等待
 * @return       [int32_t] 执行结果
 * @retval       >0 成功
 * @retval       <0 失败，值对应的是错误代码
 * @note         接收指定的obj_id数据，
 */
int32_t sdk_msg_receive(int32_t obj_id, void *p_msg_t, uint32_t *msg_size, const int32_t wait_time); 

#endif