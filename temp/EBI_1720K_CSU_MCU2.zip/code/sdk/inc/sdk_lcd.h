#ifndef __SDK_LCD_H__
#define __SDK_LCD_H__

#include <stdint.h>


/**
* @brief		LCD加载驱动
* @return		执行结果
* @retval		SDK_OK 成功
* @retval		<0 失败原因 
*/
int32_t sdk_lcd_init(void);


/**
* @brief		LCD删除驱动
* @return		执行结果
* @retval		SDK_OK 成功
* @retval		<0 失败原因 
*/
int32_t sdk_lcd_deinit(void);


/**
* @brief		打开LCD功能 
* @param		[in] lcd_id 虚拟LCD设备  
* @return		执行结果
* @retval		SDK_OK 成功
* @retval		<0 失败原因
* @pre			执行sdk_lcd_init后执行才有效。
*/
int32_t sdk_lcd_open(int32_t lcd_id);


/**
* @brief		关闭LCD功能 
* @param		[in] lcd_id 虚拟LCD设备  
* @return		执行结果
* @retval		SDK_OK 成功
* @retval		<0 失败原因  
* @pre			执行sdk_lcd_init后执行才有效。
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t sdk_lcd_close(int32_t lcd_id);


/**
* @brief		LCD从休眠中唤醒，恢复状态
* @param		[in]  lcd_id 虚拟LCD设备     
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		<0 失败原因   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t sdk_lcd_resume(uint32_t lcd_id);

 
/**
* @brief		LCD功能进入休眠模式
* @param		[in]  lcd_id 虚拟LCD设备     
* @return		执行结果
* @retval		SDK_OK 成功  
* @retval		<0 失败原因
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式，功能不影响
*/
int32_t sdk_lcd_suspend(uint32_t lcd_id);


/**
* @brief		清空显示
* @param		[in] lcd_id 虚拟LCD设备  
* @return		执行结果
* @retval		SDK_OK 成功
* @retval		<0 失败原因  
* @warning		本接口调用后，数据只刷新到RAM中，还没更新到LCD设备 
*/
int32_t sdk_lcd_clear(int32_t lcd_id);


/**
* @brief		更新LCD，把数据显示刷新到设备中
* @param		[in] lcd_id 虚拟LCD设备  
* @return		执行结果
* @retval		SDK_OK 成功
* @retval		<0 失败原因  
*/
int32_t sdk_lcd_reflash(int32_t lcd_id);


/**
* @brief		更新字符串
* @param		[in] lcd_id 虚拟LCD设备  
* @param		[in] line 显示行  
* @param		[in] col 显示列  
* @param		[in] str 显示字符串，'\0'结尾
* @return		执行结果
* @retval		SDK_OK 成功
* @retval		<0 失败原因  
* @warning		本接口调用后，数据只刷新到RAM中，还没更新到LCD设备 
*/
int32_t sdk_lcd_display_string(int32_t lcd_id, uint32_t line, uint32_t col, const char *str);


/**
* @brief		更新字符串
* @param		[in] lcd_id 虚拟LCD设备  
* @param		[in] line 显示行  
* @param		[in] align_type 对其方式
* -# LCD_ALIGN_LEFT = 左对齐
* -# LCD_ALIGN_CENTER = 居中对齐
* -# LCD_ALIGN_RIGHT = 右对齐
* @param		[in] str 显示字符串，'\0'结尾
* @return		执行结果
* @retval		SDK_OK 成功
* @retval		<0 失败原因  
* @warning		本接口调用后，数据只刷新到RAM中，还没更新到LCD设备 
*/
int32_t sdk_lcd_display_string_align(int32_t lcd_id, uint32_t line, uint8_t align_type, const char *str);


/**
* @brief		清空指定长度的行
* @param		[in] lcd_id 虚拟LCD设备  
* @param		[in] line 显示行  
* @param		[in] col 起始显示列  
* @param		[in] width 清空的宽度
* @return		执行结果
* @retval		SDK_OK 成功
* @retval		<0 失败原因  
* @warning		本接口调用后，数据只刷新到RAM中，还没更新到LCD设备 
*/
int32_t sdk_lcd_clear_line(int32_t lcd_id, uint32_t line, uint32_t col, uint8_t width);


/**
* @brief		翻转指定长度的行
* @param		[in] lcd_id 虚拟LCD设备  
* @param		[in] line 显示行  
* @param		[in] col 起始显示列  
* @param		[in] width 翻转的宽度
* @return		执行结果
* @retval		SDK_OK 成功
* @retval		<0 失败原因  
* @warning		本接口调用后，数据只刷新到RAM中，还没更新到LCD设备 
*/
int32_t sdk_lcd_reverse_line(int32_t lcd_id, uint32_t line, uint32_t col, uint32_t width);


/**
* @brief		翻转指定长度的行
* @param		[in] lcd_id 虚拟LCD设备  
* @param		[in] x 起始行坐标  
* @param		[in] y 起始列坐标 
* @param		[in] w 图片宽度
* @param		[in] h 图片高度
* @param		[in] date 显示数据
* @return		执行结果
* @retval		SDK_OK 成功
* @retval		<0 失败原因  
* @warning		本接口调用后，数据只刷新到RAM中，还没更新到LCD设备 
*/
int32_t sdk_lcd_display_bmp(int32_t lcd_id, uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint8_t *data);



/**
* @brief		扩展功能 
* @param		[in] lcd_id 虚拟LCD设备 
* @param		[in] cmd 控制命令  
* -# LCD_CTRL_BACKLIGHT = 控制背光灯
* -# LCD_GET_ATTR = 获取屏幕属性
* @param		[in] arg 控制参数   
* @return		执行结果
* @retval		SDK_OK 成功    
* @retval		<0 失败原因  
* @par 示例:
* @code
	uint32_t lcd_backlight_state = LCD_CMD_BL_ON;
	sdk_lcd_ioctl(LCD_NO, LCD_CTRL_BACKLIGHT, &lcd_backlight_state);
	
	lcd_attr_t lcd_attr;
	memset(&lcd_attr, 0, sizeof(lcd_attr_t));
	sdk_lcd_ioctl(LCD_NO, LCD_GET_ATTR, &lcd_attr);
* @endcode
*/
int32_t sdk_lcd_ioctl(int32_t lcd_id, uint8_t cmd, void* arg);


#endif
