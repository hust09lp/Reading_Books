#ifndef __SDK_PM_H__
#define __SDK_PM_H__

#include <stdint.h>


enum {
    WAKEUP_SOURCE_KEY1   = (1 << 0), ///< 开机
    WAKEUP_SOURCE_CHARGE = (1 << 1), ///< 充电
    WAKEUP_SOURCE_PCS    = (1 << 2), ///< PCS通讯(外CAN)
    WAKEUP_SOURCE_ID_IN  = (1 << 3), ///< 拼机
};


/**
 * @brief  使能休眠功能
 * @param  [in]  enter_sleep_time 多少毫秒后休眠功能生效
 * @param  [in]  level 休眠等级
 * @return 无
 */
void sdk_pm_enable(uint32_t enter_sleep_time, uint8_t level);

/**
 * @brief  获取休眠锁id
 * @retval 1~31 休眠锁id
 */
uint8_t sdk_pm_lock_id_get(void);

/**
 * @brief  锁住休眠功能
 * @param[in]  lock_id 休眠锁id，取值范围（0~31）
 * @retval 无
 */
void sdk_pm_lock(uint8_t lock_id);

/**
 * @brief  解锁休眠功能
 * @param  [in]  lock_id 休眠锁id，取值范围（0~31）
 * @retval 无
 */
void sdk_pm_unlock(uint8_t lock_id);

/**
 * @brief  设置换醒源
 * @param  [in]  mask 换醒源掩码。取值如下
 * -# WAKEUP_SOURCE_KEY1    按键开机换醒
 * -# WAKEUP_SOURCE_CHARGE  充电换醒
 * -# WAKEUP_SOURCE_PCS     PCS换醒
 * -# WAKEUP_SOURCE_ID_IN   拼机换醒
 * @retval 无
 */
void sdk_pm_wakeup_source_set(uint32_t mask);

/**
 * @brief  获取换醒源
 * @retval WAKEUP_SOURCE_KEY1    按键开机换醒
 * @retval WAKEUP_SOURCE_CHARGE  充电换醒
 * @retval WAKEUP_SOURCE_PCS PCS PCS换醒
 * @retval WAKEUP_SOURCE_ID_IN   拼机换醒
 * @pre 先使能sdk_sleep_enable()才有效
 */
uint32_t sdk_pm_wakeup_source_get(void);


#endif
