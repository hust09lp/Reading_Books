/** 
 * @file          drm.h
 * @brief         与DRM有关的状态获取
 * @author        qinmingsheng
 * @version       V0.0.1     初始版本
 * @date          2022/12/21 11:12:30
 * @lastAuthor    qinmingsheng
 * @copyright     Copyright (c) 2022 by SofarSolar, All Rights Reserved. 
 */
#ifndef __SDK_DRM_H__
#define __SDK_DRM_H__

#include <stdint.h>


typedef enum
{
    // DRM_0_VALUE = 0x00U,
    DRM_1_VALUE = 0x01U,
    DRM_2_VALUE = 0x02U,
    DRM_3_VALUE = 0x04U,
    DRM_4_VALUE = 0x08U,
    DRM_5_VALUE = 0x10U,
    DRM_6_VALUE = 0x20U,
    DRM_7_VALUE = 0x40U,
    DRM_8_VALUE = 0x80U,
    DRM_NULL_VALUE = 0x7F,
}sdk_drmn_value_e;

/** 
 * @brief        DRM0状态获取
 * @return       [int32_t] 返回执行结果
 * @note         
 * @retval       0、1代表DRM0对应的状态，小于0对应的错误代码。
 * @date         2022/12/20 08:39:17
 * @lastEditors  APOI
 */
int32_t sdk_drms0_get(void);

/** 
 * @brief        获取drm1-drm8的状态值（目前最大值数量是8个）
 * @param        [uint32_t] *p_drmn:转出参数，存放DRMN的有效值，不同的bit值组合对应的是功率输出值 bit0-bit7,对应DRM1-DRM8。
 * @return       [int32_t] SDK_OK 成功
 * @return       [int32_t] < 0 失败原因
 * @retval       bit0 --bit8,对应编号为DRM1-DRM8的AFCI值（p_drmn）是否有效
 * @date         2022/12/20 08:39:30
 * @lastEditors  APOI
 */
int32_t sdk_drmn_get(uint32_t *p_drmn);


#endif

