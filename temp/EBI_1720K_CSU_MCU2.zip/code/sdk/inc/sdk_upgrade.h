#ifndef __SDK_UPGRADE_H__
#define __SDK_UPGRADE_H__

#include "stdint.h"


/******************** sdk_upgrade Api ***********************/

/**
* @brief		开始升级
* @param		[in] flag 升级标志
* -# ARM_FLAG - 0x01  
* -# DSPM_FLAG - 0x02
* -# DSPS_FLAG - 0x03  
* -# FUSE_FLAG - 0x04  
* -# BMS_FLAG - 0x05 
* -# PCU_FLAG - 0x06
* -# BDU_FLAG - 0x07
* -# WIFI_FLAG - 0x08
* -# BLE_FLAG - 0x09
* -# AFCI_FLAG - 0x0A
* -# DCDC_FLAG - 0x0B 
* -# MPPT_FLAG - 0x0C
* @return		执行结果
* @retval		SDK_OK 成功
* @retval		<0 失败原因
*/
int32_t sdk_start_upgrade(uint8_t flag);

/**
* @brief		升级进度获取
* @param		[in] type 升级设备类型
* @return		执行结果
* @retval		0 - 100 升级进度条
* @retval		<0 失败原因  
* @pre			执行sdk_start_upgrade后执行才有效。
*/
int32_t sdk_upgrade_progress_get(uint8_t type);

/**
* @brief		升级状态获取
* @param		[in] type 升级设备类型
* @return		执行结果
* @retval		0 升级成功
* @retval		<0 升级失败 
*/
int32_t sdk_upgrade_status_get(uint8_t type);



#endif
