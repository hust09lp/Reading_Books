/** 
 * @file          sdk_afci.h
 * @brief         AFCI状相关功能
 * @author        qinmingsheng
 * @version       V0.0.1     初始版本
 * @date          2022/12/20 11:12:30
 * @lastAuthor    qinmingsheng
 * @copyright     Copyright (c) 2022 by SofarSolar, All Rights Reserved. 
 */
 
#ifndef __SDK_AFCI_H__
#define __SDK_AFCI_H__

#include <stdint.h>

/** 
 * @brief        AFCI状态获取，
 * @param        [out] p_afcis 传出参数存放AFCI的有效值，每个bit对应一个AFCI设备，bit0-bit31对应的编号是0-31. 0：无效，1：有效
 * @param        [out] *p_num 传出参数，表示AFCI数量，
 * @return       [unt32_t] bit0 --bit31,对应编号为0-31的AFCI值（p_afcis）是否有效。 0：无效，1：有效
 * @note         
 * @retval       bit0 --bit31,对应编号为0-31的AFCI值（p_afcis）是否有效
 */
uint32_t sdk_all_afci_status_get(uint32_t *p_afcis, uint32_t *p_num);

#endif
