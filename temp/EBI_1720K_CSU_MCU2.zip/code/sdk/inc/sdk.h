#ifndef __SDK_H__
#define __SDK_H__


#include "sdk_afci.h"
#include "sdk_buzzer.h"
#include "sdk_can.h"
#include "sdk_uart.h"
#include "sdk_dido.h"
#include "sdk_drm.h"
#include "sdk_errors.h"
#include "sdk_fan.h"
//#include "sdk_fs.h"
#include "sdk_iec104.h"
#include "sdk_iec61850.h"
#include "sdk_key.h"
#include "sdk_lcd.h"
#include "sdk_led.h"
#include "sdk_log.h"
#include "sdk_osif.h"
#include "sdk_modbus.h"
#include "sdk_para.h"
#include "sdk_plc.h"
#include "sdk_pm.h"
#include "sdk_public.h"
#include "sdk_record.h"
//#include "sdk_sofar_sci.h"
#include "sdk_upgrade.h"
#include "sdk_version.h"
#include "sdk_timer.h"


/**
* 主版本号
*/
#define SDK_MAJOR_VERSION        0        ///< 当API的兼容性变化时，需递增(0 - 99)
/**
* 次版本号
*/
#define SDK_MINOR_VERSION        0        ///< 当增加功能时(不影响API 的兼容性)，需递增(0 - 255)
/**
* 阶段版本号
*/
#define SDK_STAGE_VERSION        5        ///< 当做Bug修复时(不影响API 的兼容性)，需递增(0 - 255)
/**
* SDK版本字符串(规则为: V主版本.次版本.阶段版本)
*/
#define SDK_VERSION_INFO         "V0.0.5"


typedef int32_t  (*core_sdk_version_get_f)(version_type_e type, int8_t *p_version, uint16_t len);

typedef void     (*core_sdk_delay_us_f)(uint32_t us);
typedef void     (*core_sdk_delay_ms_f)(uint32_t ms);

typedef int32_t  (*core_sdk_os_delay_f)(uint32_t ticks);
typedef uint32_t (*core_sdk_os_tick_from_millisecond_f)(uint32_t ms);
typedef int32_t  (*core_sdk_os_thread_new_f)(uint8_t thread_num, sdk_os_thread_attr_tab_t *p_attr);

typedef int32_t  (*core_sdk_log_init_f)(void);
typedef void     (*core_sdk_log_set_level_f)(uint8_t log_level);
typedef uint8_t  (*core_sdk_log_get_level_f)(void);
typedef int      (*core_sdk_log_printf_f)(const char *p_format, ...);
typedef int32_t  (*core_sdk_log_hexdump_f)(const char *p_name, uint8_t width, uint8_t *p_buf, uint16_t size);
typedef void     (*core_sdk_log_finish_f)(void);

typedef int32_t  (*core_sdk_wdt_enable_f)(uint8_t state);
typedef void     (*core_sdk_wdt_feed_f)(void);
typedef void     (*core_sdk_sys_reset_f)(void);

typedef uint32_t (*core_sdk_tick_get_f)(void);
typedef bool     (*core_sdk_is_tick_over_f)(uint32_t start_tick, uint32_t interval);
typedef int32_t  (*core_sdk_rtc_set_f)(uint32_t rtc_format, sdk_rtc_t *p_time);
typedef int32_t  (*core_sdk_rtc_get_f)(uint32_t rtc_format, sdk_rtc_t *p_time);
typedef bool     (*core_sdk_is_time_over_f)(sdk_rtc_t *p_start_time, uint32_t interval);

typedef int32_t  (*core_sdk_buzzer_tick_f)(uint32_t buzzer_id, uint32_t period, uint32_t duty, int32_t times);
typedef int32_t  (*core_sdk_buzzer_on_f)(uint32_t buzzer_id);
typedef int32_t  (*core_sdk_buzzer_off_f)(uint32_t buzzer_id);

typedef int32_t  (*core_sdk_led_flash_f)(uint32_t led_id, uint32_t period, uint32_t duty, uint32_t times);
typedef int32_t  (*core_sdk_led_on_f)(uint32_t led_id);
typedef int32_t  (*core_sdk_led_off_f)(uint32_t led_id);

typedef uint32_t (*core_sdk_key_get_f)(void);

typedef int32_t  (*core_sdk_dido_write_f)(do_index_e do_index, uint8_t value);
typedef int32_t  (*core_sdk_dido_read_f)(di_index_e di_index);
typedef int32_t  (*core_sdk_dido_set_irq_f)(di_index_e di_index, dido_irq_e mode, dido_irq_callback p_fcallback);
typedef int32_t  (*core_sdk_dido_free_irq_f)(di_index_e di_index);

typedef int32_t  (*core_sdk_drms0_get_f)(void);
typedef int32_t  (*core_sdk_drmn_get_f)(uint32_t *p_drmn);

typedef int32_t  (*core_sdk_fan_setup_f)(uint32_t fan_id, uint32_t fan_type, uint32_t pwm_period, uint8_t pwm_duty);
typedef int32_t  (*core_sdk_fan_pwm_set_f)(uint32_t fan_id, uint8_t duty);
typedef int32_t  (*core_sdk_fan_status_get_f)(uint32_t fan_id);

typedef int32_t  (*core_sdk_can_open_f)(uint32_t port);
typedef int32_t  (*core_sdk_can_close_f)(uint32_t port);
typedef int32_t  (*core_sdk_can_setup_f)(uint32_t port, can_cfg_t * p_cfg);
typedef int32_t  (*core_sdk_can_write_f)(uint32_t port, can_frame_t *p_can_frame, uint32_t len);
typedef int32_t  (*core_sdk_can_read_f)(uint32_t port, can_frame_t *p_can_frame, uint32_t len, int32_t timeout_ms);
typedef int32_t  (*core_sdk_can_set_irq_f)(uint32_t port, sdk_can_irq_callback tx_cb, sdk_can_irq_callback rx_cb);
typedef int32_t  (*core_sdk_can_free_irq_f)(uint32_t port);

typedef int32_t  (*core_sdk_uart_open_f)(uint32_t port);
typedef int32_t  (*core_sdk_uart_close_f)(uint32_t port);
typedef int32_t  (*core_sdk_uart_setup_f)(uint32_t port, sdk_uart_conf_t *p_uart_conf);
typedef int32_t  (*core_sdk_uart_write_f)(uint32_t port, uint8_t *p_buf, uint32_t len);
typedef int32_t  (*core_sdk_uart_read_f)(uint32_t port, uint8_t *p_buf, uint32_t len, int32_t timeout_ms);


typedef int32_t (*core_sdk_timer_init_f)(uint32_t id, timer_type_e type);
typedef int32_t (*core_sdk_timer_set_f)(uint32_t id, timer_type_e type, uint32_t us,call_back_f call_back);
typedef int32_t (*core_sdk_timer_start_f)(uint32_t id,timer_type_e type );
typedef int32_t (*core_sdk_timer_stop_f)(uint32_t id,timer_type_e type );
    
    
// ...待添加

typedef struct 
{
    core_sdk_version_get_f core_sdk_version_get;

    core_sdk_delay_us_f core_sdk_delay_us;
    core_sdk_delay_ms_f core_sdk_delay_ms;
    
    core_sdk_os_delay_f core_sdk_os_delay;
    core_sdk_os_tick_from_millisecond_f core_sdk_os_tick_from_millisecond;
    core_sdk_os_thread_new_f core_sdk_os_thread_new;
    
    core_sdk_log_init_f core_sdk_log_init;
    core_sdk_log_set_level_f core_sdk_log_set_level;
    core_sdk_log_get_level_f core_sdk_log_get_level;
    core_sdk_log_printf_f core_sdk_log_printf;
    core_sdk_log_hexdump_f core_sdk_log_hexdump;
    core_sdk_log_finish_f core_sdk_log_finish;

    core_sdk_wdt_enable_f core_sdk_wdt_enable;
    core_sdk_wdt_feed_f core_sdk_wdt_feed;
    core_sdk_sys_reset_f core_sdk_sys_reset;

    core_sdk_tick_get_f core_sdk_tick_get;
    core_sdk_is_tick_over_f core_sdk_is_tick_over;
    core_sdk_rtc_set_f core_sdk_rtc_set;
    core_sdk_rtc_get_f core_sdk_rtc_get;
    core_sdk_is_time_over_f core_sdk_is_time_over;

    core_sdk_buzzer_tick_f core_sdk_buzzer_tick;
    core_sdk_buzzer_on_f core_sdk_buzzer_on;
    core_sdk_buzzer_off_f core_sdk_buzzer_off;

    core_sdk_led_flash_f core_sdk_led_flash;
    core_sdk_led_on_f core_sdk_led_on;
    core_sdk_led_off_f core_sdk_led_off;

    core_sdk_key_get_f core_sdk_key_get;

    core_sdk_dido_write_f core_sdk_dido_write;
    core_sdk_dido_read_f core_sdk_dido_read;
    core_sdk_dido_set_irq_f core_sdk_dido_set_irq;
    core_sdk_dido_free_irq_f core_sdk_dido_free_irq;

    core_sdk_drms0_get_f core_sdk_drms0_get;
    core_sdk_drmn_get_f core_sdk_drmn_get;

    core_sdk_fan_setup_f core_sdk_fan_setup;
    core_sdk_fan_pwm_set_f core_sdk_fan_pwm_set;
    core_sdk_fan_status_get_f core_sdk_fan_status_get;
    
    core_sdk_can_open_f core_sdk_can_open;
    core_sdk_can_close_f core_sdk_can_close;
    core_sdk_can_setup_f core_sdk_can_setup;
    core_sdk_can_write_f core_sdk_can_write;
    core_sdk_can_read_f core_sdk_can_read;
    core_sdk_can_set_irq_f core_sdk_can_set_irq;
    core_sdk_can_free_irq_f core_sdk_can_free_irq;
    
    core_sdk_uart_open_f core_sdk_uart_open;
    core_sdk_uart_close_f core_sdk_uart_close;
    core_sdk_uart_setup_f core_sdk_uart_setup;
    core_sdk_uart_write_f core_sdk_uart_write;
    core_sdk_uart_read_f core_sdk_uart_read;
	
	core_sdk_timer_init_f core_sdk_timer_init;
	core_sdk_timer_set_f  core_sdk_timer_set;
	core_sdk_timer_start_f core_sdk_timer_start;
	core_sdk_timer_stop_f core_sdk_timer_stop;

    // ...待添加

}core_sdk_interface_t;


#endif

