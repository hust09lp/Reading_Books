#ifndef __SDK_UART_H__
#define __SDK_UART_H__

#include "stdint.h"

#define  B0               0
#define  B50              50
#define  B75              75
#define  B110             110
#define  B134             134
#define  B150             150
#define  B200             200
#define  B300             300
#define  B600             600
#define  B1200            1200
#define  B1800            1800
#define  B2400            2400
#define  B4800            4800
#define  B9600            9600
#define  B19200           19200
#define  B38400           38400
#define  B57600           57600
#define  B115200          115200
#define  B230400          230400
#define  B460800          460800
#define  B500000          500000
#define  B576000          576000
#define  B921600          921600
#define  B1000000         1000000
#define  B1152000         1152000

/* 数据位 */
#define SDK_UART_5B       0000000
#define SDK_UART_6B       0000020
#define SDK_UART_7B       0000040
#define SDK_UART_8B       0000060

/* 校验位 */
#define SDK_UART_PARNON   0000000
#define SDK_UART_PARENB   0000400
#define SDK_UART_PARODD   0001000

/* 停止位 */
#define SDK_UART_STOP1B   0000000
#define SDK_UART_STOP2B   0000100

#define SDK_UART_HWFLOW_ON      1            ///< 硬件流控开
#define SDK_UART_HWFLOW_OFF     0            ///< 硬件流控关

#ifdef SOC_LPC54606
/* 虚拟串口号 */
typedef enum
{
    SDK_UART1    = 0,  // DSP
    SDK_UART2    = 1,  // AFCI
    SDK_UART_MAX,
} sdk_uart_port_e;
#endif

#ifdef SOC_IMXRT1024
/* 虚拟串口号 */
typedef enum
{
    SDK_UART1 = 0,  // 硬件UART1
    SDK_UART2,      // 硬件UART2
    SDK_UART3,      // 硬件UART3
    SDK_UART4,      // 硬件UART4
    SDK_UART5,      // 硬件UART5
    SDK_UART6,      // 硬件UART6
//    SDK_UART7,        // 已作为调试串口使用
    SDK_UART8,      // 硬件UART8
    SDK_UART_MAX,
} sdk_uart_port_e;
#endif

/**
 * @struct 串口属性
 * @brief  配置串口各种属性
 */
typedef struct
{
    uint32_t baud_rate;      ///< 波特率
    uint32_t data_bits;      ///< 数据位
    uint32_t stop_bit;       ///< 停止位
    uint32_t parity;         ///< 校验位
    uint32_t flow_ctrl;      ///< 流控制
} sdk_uart_conf_t;

/**
 * @brief    打开串口
 * @param    [in] port 虚拟串口号
 * @return   SDK_OK 成功
 * @return   SDK_EPERR 失败
 */
int32_t sdk_uart_open(uint32_t port);

/**
 * @brief    关闭串口
 * @param    [in] port 虚拟串口号
 * @return   SDK_OK 成功；SDK_EPERR 失败
 */
int32_t sdk_uart_close(uint32_t port);

/**
 * @brief    配置串口属性
 * @param    [in] port        虚拟串口号
 * @param    [in] p_uart_conf 串口属性缓存地址
 * @return   SDK_OK 成功；SDK_EPERR 失败
 */
int32_t sdk_uart_setup(uint32_t port, sdk_uart_conf_t *p_uart_conf);

/**
 * @brief    串口通讯发送接口函数
 * @param    [in] port   虚拟串口号
 * @param    [in] p_buf  发送缓存指针
 * @param    [in] len    发送字节数
 * @return   SDK_OK 成功；SDK_EPERR 失败
 */
int32_t sdk_uart_write(uint32_t port, uint8_t *p_buf, uint32_t len);

/**
 * @brief    串口通讯接收接口函数
 * @param    [in] port   虚拟串口号
 * @param    [out] p_buf 接收缓存指针
 * @param    [in] len    要接收字节数
 * @param    [in] timeout_ms 等待时长：-1 无限等待；0：不等待；其他：等待具体ms值 
 * @return   >= 0为读取到的字节数；< 0 为异常：SDK_EPERR-> 参数错误；
 */
int32_t sdk_uart_read(uint32_t port, uint8_t *p_buf, uint32_t len, int32_t timeout_ms);

#endif /* __SDK_UART_H__ */

