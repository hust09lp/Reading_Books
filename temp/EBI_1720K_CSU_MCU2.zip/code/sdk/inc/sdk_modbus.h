/**
 * @file     sdk_modbus.h
 * @brief    modbus协议SDK接口
 * @author   hewenjun
 * @note     无
 * @version  V1.0
 * @date     2022/12/27
 */
#ifndef __SDK_MODBUS_H__
#define __SDK_MODBUS_H__

#include "stdint.h"


/**
 * @brief   初始化RTU
 * @param   [in] index modbus下标，0~5
 * @param   [in] slave 从机地址
 * @param   [in] baud 波特率
 * @return  返回执行结果：0正常；-1异常
 */
int32_t sdk_modbus_rtu_init(uint32_t index, uint32_t slave, uint32_t baud);

/**
 * @brief   初始化TCP
 * @param   [in] index modbus下标，0~5
 * @param   [in] slave 从机地址
 * @param   [in] ip IP地址
 * @param   [in] port 端口
 * @return  返回执行结果：0正常；-1异常
 */
int32_t sdk_modbus_tcp_init(uint32_t index, uint32_t slave, const char *ip, int32_t port);

/**
 * @brief   设置从机地址
 * @param   [in] index modbus下标，0~5
 * @param   [in] slave 从机地址
 * @return  返回执行结果：0正常；-1异常
 */
int32_t sdk_modbus_slave_set(uint32_t index, uint32_t slave);

/**
 * @brief   设置波特率
 * @param   [in] index modbus下标，0~5
 * @param   [in] baud 波特率
 * @return  返回执行结果：0正常；-1异常
 */
int32_t sdk_modbus_baud_set(uint32_t index, uint32_t baud);

/**
 * @brief   设置响应超时时间
 * @param   [in] index modbus下标，0~5
 * @param   [in] timeout_ms 毫秒,范围值0~10000
 * @return  返回执行结果：0正常；-1异常
 */
int32_t sdk_modbus_response_timeout_set(uint32_t index, uint32_t timeout_ms);

/**
 * @brief   modbus连接
 * @param   [in] index modbus下标，0~5
 * @return  返回执行结果：0正常；-1异常
 */
int32_t sdk_modbus_connect(uint32_t index);

/**
 * @brief   modbus关闭
 * @param   [in] index modbus下标，0~5
 * @return  返回执行结果：0正常；-1：index异常
 */
int32_t sdk_modbus_close(uint32_t index);

/**
 * @brief   modbus释放
 * @param   [in] index modbus下标，0~5
 * @return  返回执行结果：0正常；-1：index异常
 */
int32_t sdk_modbus_free(uint32_t index);

/**
 * @brief   modbus回调函数格式
 * @param   [in] function 功能码
 * @param   [in] p_req 接收报文的指针
 * @param   [out] p_rsq 响应报文的指针
 * @param   [in] rsq_size 响应报文buff的大小
 * @return  返回执行结果
 */
typedef int32_t (*modbus_function_cb)(int32_t function, const uint8_t *p_req, uint8_t *p_rsq, int32_t rsq_size);

/**
 * @brief   modbus注册回调函数
 * @param   [in] fun_call_back 回调函数
 * @return  返回执行结果
 */
int32_t sdk_modbus_handle(modbus_function_cb fun_call_back);

/**
 * @brief   读取保持寄存器值
 * @param   [in] index modbus下标，0~5
 * @param   [in] addr 起始寄存器地址
 * @param   [in] nb 寄存器数量
 * @param   [out] dest 读取的数据的指针
 * @return  返回执行结果：-1异常
 */
int32_t sdk_modbus_registers_read(uint32_t index, int32_t addr, int32_t nb, uint16_t *dest);

/**
 * @brief   写单个保持寄存器
 * @param   [in] index modbus下标，0~5
 * @param   [in] addr 寄存器地址
 * @param   [in] value 写入值
 * @return  返回执行结果：-1异常
 */
int32_t sdk_modbus_register_write(uint32_t index, int32_t addr, const uint16_t value);

/**
 * @brief   写多个保持寄存器
 * @param   [in] index modbus下标，0~5
 * @param   [in] addr 寄存器起始地址
 * @param   [in] nb 寄存器数量
 * @param   [in] data 写入值的指针
 * @return  返回执行结果：-1异常
 */
int32_t sdk_modbus_registers_write(uint32_t index, int32_t addr, int32_t nb, const uint16_t *data);

#endif
