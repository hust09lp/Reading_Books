/**
 * @file     	sdk_key.h
 * @brief    	按键模块sdk接口
 * @author   	renwenjie
 * @note     	无
 * @version  	V1.0.1
 * @date     	2022/12/30
 * @copyright   Copyright(c) 2022 by SofarSolar, All Rights Reserved. 
 */

#ifndef __SDK_KEY_H__
#define __SDK_KEY_H__

#include <stdint.h>


/**
* @brief    按键的键值
*/
typedef enum 
{
    KEY_NO_PRESS = 0,           ///< 无按键按下
    KEY1_SHORT_PRESS,           ///< 按键1短按
    KEY1_LONG_PRESS,            ///< 按键1长按
    KEY2_SHORT_PRESS,           ///< 按键2短按
    KEY2_LONG_PRESS,            ///< 按键2长按
    KEY3_SHORT_PRESS,           ///< 按键3短按
    KEY3_LONG_PRESS,            ///< 按键3长按
    KEY4_SHORT_PRESS,           ///< 按键4短按
    KEY4_LONG_PRESS,            ///< 按键4长按
    KEY1_2_PRESS,               ///< 组合按键,按键1和按键2同时按下(长按)
} key_val_e;


/**
* @brief            获取按键的信息
* @return           执行结果
* @retval           按键值获取
* @warning          无
*/
uint32_t sdk_key_get(void);


#endif

