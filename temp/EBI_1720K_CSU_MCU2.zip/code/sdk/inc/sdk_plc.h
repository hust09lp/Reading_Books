/**
* @file		sdk_plc.h
* @brief    PLC模块接口
* @copyright Shouhang
* @author   yangwenjuan
* @note     2022.11.25 新拟制
* @version  V1.0   
* @date     2022/11/25
*/

#ifndef __SDK_PLC_H__
#define __SDK_PLC_H__

#include <stdint.h>


#define PLC_READ_DATA_LEN		30

typedef enum {
	PLC_SCI_OK					=  0,	/** No error, everything OK. */
	PLC_SCI_SEND_ERROR			= -1,	/** Send err.          		 */
	PLC_SCI_RECEIVE_ERROR		= -2,	/** Receive err.          	 */
	PLC_SCI_UNPACK_ERROR		= -3,	/** Receive unpack err.      */    
} plc_sci_err_e;

typedef struct{
	uint16_t mac[3];
	uint16_t txpower;
}plc_parameter_t;

typedef struct{
	uint16_t plc_type;		//PLC类型
	uint16_t soft_ver[15];	//PLC软件版本号
	uint16_t sta_net_state;	//sta入网状态 1-表示已入网，2-表示未入网
	uint16_t cco_mac[3];	//sta入网后的CCO mac地址
	uint16_t com_property;	//串口通信参数
	uint16_t plc_mac[3];	//PLC的mac地址
	uint16_t freq_band;		//频段信息
	uint16_t txpower;		//发射功率	
}plc_data_t;


/**
* @brief    plc模块初始化——参数初始化（根据规则生成sta的mac地址，读取arm存储的发射功率）
* @param    [out] p_plc_para plc参数缓存指针，具体参数见 plc_parameter_t
* @return   void
*/
void sdk_plc_init(plc_parameter_t *p_plc_para);

/**
* @brief    配置plc(sta)模块mac地址  
* @param	[in] port 虚拟串口端口号 
* @param    [in] p_mac  mac地址缓存指针
* @param    [in] len    mac地址长度（按16位数的长度，默认传3）
* @return	执行结果
* @retval	>0 设置成功
* @retval	<0 设置失败及失败原因，具体见plc_sci_err_e
*/
uint16_t sdk_plc_set_mac(uint16_t port, uint16_t *p_mac, uint16_t len);

/**
* @brief    配置plc(sta)模块发射功率  
* @param	[in] port   虚拟串口端口号 
* @param    [in] txpower 发射功率
* @return	执行结果
* @retval	>0 设置成功
* @retval	<0 设置失败及失败原因，具体见plc_sci_err_e	
*/
uint16_t sdk_plc_set_txpower(uint16_t port, uint16_t txpower);

/**
* @brief    查询获取PLC的信息  
* @param	[in] port 虚拟串口端口号 
* @param    [out] p_plc_data 查询到的PLC数据缓存指针,具体见p_plc_data
* @return	执行结果
* @retval	>0 查询成功
* @retval	<0 查询失败及失败原因，具体见plc_sci_err_e
*/
uint16_t sdk_plc_get_info(uint16_t port, plc_data_t *p_plc_data);

#endif /* __SDK_PLC_H__ */

