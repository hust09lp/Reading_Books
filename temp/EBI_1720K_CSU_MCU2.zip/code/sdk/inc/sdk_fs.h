
#ifndef __SDK_FS_H__
#define __SDK_FS_H__

#include "lfs2.h"
#include "lfs2_util.h"
#include "ff.h"
#include "sdk_errors.h"

#ifdef	__cplusplus
extern "C"
{
#endif


/**
* @struct fs_t
* @brief 文件系统控制变量
*/
typedef struct
{
	uint32_t type;
	lfs_file_t file;
	FIL fatfs_fh;
}fs_t;


enum{
	FS_READ = (1 << 0),				///<	Specifies read access to the file. Data can be read from the file.
	FS_WRITE = (1 << 1),			///<	Specifies write access to the file. Data can be written to the file. Combine with FA_READ for read-write access.
	FS_OPEN_EXISTING = (1 << 2),	///<	Opens a file. The function fails if the file is not existing. (Default)
	FS_CREATE_NEW = (1 << 3),		///<	Creates a new file. The function fails with FR_EXIST if the file is existing.
	FS_CREATE_ALWAYS = (1 << 4),	///<	Creates a new file. If the file is existing, it will be truncated and overwritten.
	FS_OPEN_ALWAYS = (1 << 5),		///<	Opens the file if it is existing. If not, a new file will be created.
	FS_OPEN_APPEND = (1 << 6),		///<	Same as FS_OPEN_ALWAYS except the read/write pointer is set end of the file.
};



#ifndef SDK_API_INTERFACE_ENABLE	///< SDK接口对外声明是否打开

int32_t sdk_fs_init(void);

/**
 * @brief  打开文件
 * @param  [in] path 文件路径(字符长度不能超过20)
 *         盘符"0:"为little
 *         盘符"1:"为FatFs
 * @param  [in] mode 打开文件模式
 * @return 文件控制变量，动态生成，关闭后释放
 * @retval NULL 打开失败
 * @retval 非空 打开成功
 */
fs_t *sdk_fs_open(const char *path, uint16_t mode);
/**
 * @brief		关闭文件
 * @param		[in] p_fs 文件控制变量
 * @return		关闭状态
 * @retval		0 关闭成功
 * @retval		<0 关闭失败原因
 */
int32_t sdk_fs_close(fs_t *p_fs);

/**
 * @brief		读文件数据
 * @param		[in] p_fs 文件控制变量
 * @param		[out] buff 数据缓冲区
 * @param		[in] len 需要读取长度
 * @return		读取长度
 * @retval		<=0 读取失败，以及失败原因
 * @retval		>0 实际读取长度
 */
int32_t sdk_fs_read(fs_t *p_fs, void *buff, uint32_t len);

/**
 * @brief		写文件文件
 * @param		[in] p_fs 文件控制变量
 * @param		[in] buff 数据缓冲区
 * @param		[in] len 需要写入长度
 * @return		写入长度
 * @retval		<=0 写入失败，以及失败原因
 * @retval		>0 实际写入长度
 */
int32_t sdk_fs_write(fs_t *p_fs, void *buff, uint32_t len);

/**
 * @brief		文件当前指针跳转
 * @param		[in] p_fs 文件控制变量
 * @param		[in] offset 从文件头部起始的偏移地址
 * @return		跳转结果
 * @retval		0 跳转成功
 * @retval		<0 跳转失败
 */
int32_t sdk_fs_lseek(fs_t *p_fs, uint32_t offset);

/**
 * @brief		获取文件长度
 * @param		[in] p_fs 文件控制变量
 * @return		文件长度
 * @retval		0 失败
 * @retval		>0 文件实际长度
 */
int32_t sdk_fs_get_size(fs_t *p_fs);


int32_t sdk_fs_file_sync(fs_t *p_fs);

/**
 * @brief        删除文件
 * @param        [in] path 文件路径
 * @return        删除状态
 * @retval        0 删除成功
 * @retval        <0 删除失败原因
 */
int32_t sdk_fs_remove(const char *path);

/**
 * @brief        重命名文件
 * @param        [in] oldpath 旧文件路径
 * @param        [in] newpath 新文件路径
 * @return        状态
 * @retval        0 成功
 * @retval        <0 失败原因
 */
int32_t sdk_fs_rename(const char *oldpath, const char *newpath);

/**
 * @brief        将文件的大小截断为指定的大小
 * @param		[in] p_fs 文件控制变量
 * @param		[in] size 文件大小
 * @return        状态
 * @retval        0 成功
 * @retval        <0 失败原因
 */
int32_t sdk_fs_truncate(fs_t *p_fs, uint32_t size);

#ifdef	__cplusplus
}
#endif

#endif
#endif
