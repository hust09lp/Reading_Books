#ifndef __SDK_CORE_H__
#define __SDK_CORE_H__

#include "sdk.h"


extern core_sdk_interface_t *gp_core_sdk_api;


#define sdk_version_get                 (gp_core_sdk_api->core_sdk_version_get)

#define sdk_delay_us                    (gp_core_sdk_api->core_sdk_delay_us)
#define sdk_delay_ms                    (gp_core_sdk_api->core_sdk_delay_ms)

#define sdk_os_delay                    (gp_core_sdk_api->core_sdk_os_delay)
#define sdk_os_tick_from_millisecond    (gp_core_sdk_api->core_sdk_os_tick_from_millisecond)
#define sdk_os_thread_new               (gp_core_sdk_api->core_sdk_os_thread_new)

#define sdk_log_init                    (gp_core_sdk_api->core_sdk_log_init)
#define sdk_log_set_level               (gp_core_sdk_api->core_sdk_log_set_level)
#define sdk_log_get_level               (gp_core_sdk_api->core_sdk_log_get_level)
#define sdk_log_printf                  (gp_core_sdk_api->core_sdk_log_printf)
#define sdk_log_hexdump                 (gp_core_sdk_api->core_sdk_log_hexdump)
#define sdk_log_finish                  (gp_core_sdk_api->core_sdk_log_finish)

#define sdk_wdt_enable                  (gp_core_sdk_api->core_sdk_wdt_enable)
#define sdk_wdt_feed                    (gp_core_sdk_api->core_sdk_wdt_feed)
#define sdk_sys_reset                   (gp_core_sdk_api->core_sdk_sys_reset)

#define sdk_tick_get                    (gp_core_sdk_api->core_sdk_tick_get)
#define sdk_is_tick_over                (gp_core_sdk_api->core_sdk_is_tick_over)
#define sdk_rtc_set                     (gp_core_sdk_api->core_sdk_rtc_set)
#define sdk_rtc_get                     (gp_core_sdk_api->core_sdk_rtc_get)
#define sdk_is_time_over                (gp_core_sdk_api->core_sdk_is_time_over)

#define sdk_buzzer_tick                 (gp_core_sdk_api->core_sdk_buzzer_tick)
#define sdk_buzzer_on                   (gp_core_sdk_api->core_sdk_buzzer_on)
#define sdk_buzzer_off                  (gp_core_sdk_api->core_sdk_buzzer_off)

#define sdk_led_flash                   (gp_core_sdk_api->core_sdk_led_flash)
#define sdk_led_on                      (gp_core_sdk_api->core_sdk_led_on)
#define sdk_led_off                     (gp_core_sdk_api->core_sdk_led_off)

#define sdk_key_get                     (gp_core_sdk_api->core_sdk_key_get)

#define sdk_dido_write                  (gp_core_sdk_api->core_sdk_dido_write)
#define sdk_dido_read                   (gp_core_sdk_api->core_sdk_dido_read)
#define sdk_dido_set_irq                (gp_core_sdk_api->core_sdk_dido_set_irq)
#define sdk_dido_free_irq               (gp_core_sdk_api->core_sdk_dido_free_irq)

#define sdk_drms0_get                   (gp_core_sdk_api->core_sdk_drms0_get)
#define sdk_drmn_get                    (gp_core_sdk_api->core_sdk_drmn_get)

#define sdk_fan_setup                   (gp_core_sdk_api->core_sdk_fan_setup)
#define sdk_fan_pwm_set                 (gp_core_sdk_api->core_sdk_fan_pwm_set)
#define sdk_fan_status_get              (gp_core_sdk_api->core_sdk_fan_status_get)

#define sdk_can_open                    (gp_core_sdk_api->core_sdk_can_open)
#define sdk_can_close                   (gp_core_sdk_api->core_sdk_can_close)
#define sdk_can_setup                   (gp_core_sdk_api->core_sdk_can_setup)
#define sdk_can_write                   (gp_core_sdk_api->core_sdk_can_write)
#define sdk_can_read                    (gp_core_sdk_api->core_sdk_can_read)
#define sdk_can_set_irq                 (gp_core_sdk_api->core_sdk_can_set_irq)
#define sdk_can_free_irq                (gp_core_sdk_api->core_sdk_can_free_irq)

#define sdk_uart_open                   (gp_core_sdk_api->core_sdk_uart_open)
#define sdk_uart_close                  (gp_core_sdk_api->core_sdk_uart_close)
#define sdk_uart_setup                  (gp_core_sdk_api->core_sdk_uart_setup)
#define sdk_uart_write                  (gp_core_sdk_api->core_sdk_uart_write)
#define sdk_uart_read                   (gp_core_sdk_api->core_sdk_uart_read)

#define sdk_timer_init					(gp_core_sdk_api->core_sdk_timer_init)	
#define sdk_timer_set					(gp_core_sdk_api->core_sdk_timer_set)
#define sdk_timer_start					(gp_core_sdk_api->core_sdk_timer_start)
#define sdk_timer_stop					(gp_core_sdk_api->core_sdk_timer_stop)

/** 
 * SDK接口初始化
 */
int32_t core_sdk_api_init(uint32_t sdk_api_addr);

#endif

