#ifndef __SDK_ERRORS_H__
#define __SDK_ERRORS_H__


#define SDK_OK              0           ///< No errors 
#define SDK_EIO             (-1)        ///< I/O error 
#define SDK_EPERR           (-2)        ///< Argument error
#define SDK_EINVAL          (-3)        ///< Invalid argument 
#define SDK_ENXIO           (-4)        ///< No such device
#define SDK_FNOSUPP         (-5)        ///< Function not support
#define SDK_TMOUTERR        (-6)        ///< Timeout error
#define SDK_CFGERR          (-7)        ///< Set config error
#define SDK_DEVNEN          (-8)        ///< Device not enable
#define SDK_SETERR          (-9)        ///< Setting error
#define SDK_DRM0ERR         (-10)       ///< DRM0 error
#define SDK_DRMNERR         (-11)       ///< DRMN error
#define SDK_OSCERR          (-12)       ///< Thread create error


#define SDK_ERR             (-99)       ///< no define 


#endif

