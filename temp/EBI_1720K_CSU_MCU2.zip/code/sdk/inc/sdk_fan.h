/** 
 * @file          sdk_fan.h
 * @brief         风扇功能接口定义
 * @author        Chace
 * @version       V0.0.1     初始版本
 * @date          2023/02/08 15:42:30
 * @lastAuthor    Chace
 * @copyright     Copyright (c) 2022 by SofarSolar, All Rights Reserved. 
 */
#ifndef __SDK_FAN_H__
#define __SDK_FAN_H__

#include <stdint.h>


typedef enum
{
    FAN_ID_1 = 0,
    FAN_ID_2,
    FAN_ID_3,
    FAN_ID_4,
    FAN_ID_MAX,
}fan_id_e;

typedef enum
{
    FAN_YL_TYPE = 0,    ///< 永利风扇
    FAN_NMB_TYPE,       ///< NMB风扇
    FAN_TYPE_MAX,
}fan_type_e;

// /**
// * @struct 风扇属性
// * @brief 配置风扇各种属性
// */
// typedef struct
// {
//     uint16_t type;         ///< 风扇类型
//     uint32_t pwm_hz;       ///< 风扇PWM采样率
//     uint8_t pwm_duty;      ///< 风扇PWM占空比 0 - 100
//     uint8_t enable;        ///< 风扇使能
// }fan_conf_t;


/******************** sdk_fan Api ***********************/

/**
* @brief        风扇参数配置
* @param        [in] fan_id 风扇序号
* @param        [in] fan_type 风扇类型
* @param        [in] pwm_period 风扇PWM控制的采样周期(HZ)
* @param        [in] pwm_duty 风扇PWM控制的占空比(0 - 100%)
* @return        执行结果
* @retval        SDK_OK 成功
* @retval        <0 失败原因
*/
int32_t sdk_fan_setup(uint32_t fan_id, uint32_t fan_type, uint32_t pwm_period, uint8_t pwm_duty);

/**
* @brief        设置风扇PWM占空比
* @param        [in] fan_id 风扇序号
* @param        [in] duty 风扇PWM占空比 0 - 100
* @return        执行结果
* @retval        SDK_OK 成功
* @retval        <0 失败原因  
* @pre            执行sdk_fan_setup后执行才有效。
*/
int32_t sdk_fan_pwm_set(uint32_t fan_id, uint8_t duty);

/**
* @brief        风扇状态获取
* @param        [in] fan_id 风扇序号
* @return        执行结果
* @retval        0 状态低电平
* @retval        1 状态高电平
* @retval        <0 失败原因 
*/
int32_t sdk_fan_status_get(uint32_t fan_id);



#endif
