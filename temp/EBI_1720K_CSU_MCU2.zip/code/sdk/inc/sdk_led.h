/**
 * @file     	sdk_led.h
 * @brief    	led模块sdk接口
 * @author   	renwenjie
 * @note     	无
 * @version  	V1.0.1
 * @date     	2022/12/30
 * @copyright   Copyright(c) 2022 by SofarSolar, All Rights Reserved. 
 */

#ifndef __SDK_LED_H__
#define __SDK_LED_H__

#include <stdint.h>

#define LED_FLASH_CONTINUE                    0xFFFFFFFF


typedef enum
{
    LED_ID_1 = 0,
    LED_ID_2,
    LED_ID_3,
    LED_ID_4,
    LED_ID_5,
    LED_ID_6,
    LED_ID_7,
    LED_ID_8,
    LED_ID_9,
    LED_ID_10,
    LED_ID_MAX,
}led_id_type_e;

/**
* @brief    led闪烁
* @param    [in] led_id        led编号
* @param    [in] period        led闪烁周期(ms)
* -# 最小周期为任务周期或扫描周期（建议10ms）,需是任务及扫描周期的倍数
* @param    [in] duty        led闪烁占空比
* -# 0-100,表示0%-100%
* @param    [in] times        led闪烁次数
* -# 0xFFFFFFFF 持续闪烁
* -# >=0 闪烁次数
* @return    执行结果
* @retval    SDK_OK  成功
* @retval    < 0  失败
*/
int32_t sdk_led_flash(uint32_t led_id, uint32_t period, uint32_t duty, uint32_t times);
 
/**
* @brief    LED灯亮
* @param    [in] led_id LED编号
* @return    执行结果
* @retval    SDK_OK  成功
* @retval    < 0  失败
*/
int32_t sdk_led_on(uint32_t led_id);

/**
* @brief    LED灯灭
* @param    [in] led_id LED编号
* @return    执行结果
* @retval    SDK_OK  成功
* @retval    < 0  失败
*/
int32_t sdk_led_off(uint32_t led_id);



#endif
