/** 
 * @file          sdk_osif.h
 * @brief         os系统sdk接口
 * @author        renwenjie
 * @version       V1.0.1   
 * @date          2023/1/11
 * @copyright     Copyright (c) 2022 by SofarSolar, All Rights Reserved. 
 */
 
#ifndef __SDK_OSIF_H__
#define __SDK_OSIF_H__

#include <stdint.h>
#include <stddef.h>

/**
 * @enum os_app_priority_e 
 * @brief Priority values.
 * @warning 供应用层app调用，core禁止调用
 */
typedef enum {
    OS_APP_PRIORITY_1                    = (10-7),                ///< Priority:highest 
    OS_APP_PRIORITY_2                    = (10-6),                 ///< Priority:1 
    OS_APP_PRIORITY_3                    = (10-5),                 ///< Priority:2 
    OS_APP_PRIORITY_4                    = (10-4),                 ///< Priority:3
    OS_APP_PRIORITY_5                    = (10-3),                 ///< Priority:4
    OS_APP_PRIORITY_6                    = (10-2),                 ///< Priority:5
    OS_APP_PRIORITY_7                    = (10-1),                 ///< Priority:lowest
} sdk_os_priority_e;

/**
 * @struct os_thread_attr_t
 * @brief Attributes structure for thread.
 */
typedef struct {
    const char                            *name;            ///< name of the thread
    uint32_t                            attr_bits;        ///< attribute bits
    void                                *cb_mem;        ///< memory for control block
    uint32_t                            cb_size;        ///< size of provided memory for control block
    uint32_t                            tick;
    void                                *stack_mem;        ///< memory for stack
    uint32_t                            stack_size;        ///< size of stack
    sdk_os_priority_e                    priority;        ///< initial thread priority (default: OS_PRIORITY_NORMAL)
#ifdef __TZ_MODULEID_T__
    TZ_module_id_t                        tz_module;        ///< TrustZone module identifier
#endif
    uint32_t                            reserved;        ///< reserved (must be 0)
} sdk_os_thread_attr_t;


/**
 * @enum os_status_e
 * @brief Status code values returned by RTOS functions.
 */
typedef enum {
    SDK_OS_OK                            =  0,            ///< Operation completed successfully.
    SDK_OS_ERROR                        = -1,            ///< Unspecified RTOS error: run-time error but no other error message fits.
    SDK_OS_ERROR_TIMEOUT                = -2,            ///< Operation not completed within the timeout period.
    SDK_OS_ERROR_RESOURCE                = -3,            ///< Resource not available.
    SDK_OS_ERROR_PARAMETER                = -4,            ///< Parameter error.
    SDK_OS_ERROR_NO_MEMORY                = -5,            ///< System is out of memory: it was impossible to allocate or reserve memory for the operation.
    SDK_OS_ERROR_ISR                    = -6,            ///< Not allowed in ISR context: the function cannot be called from interrupt service routines.
    SDK_OS_STATUS_RESERVED                = 0x7FFFFFFF    ///< Prevents enum down-size compiler optimization.
} sdk_os_status_e;

/// \details Thread ID identifies the thread.
typedef void *sdk_os_thread_id_t;


/** Entry point of a thread. */
typedef void (*sdk_os_thread_func_t)(void *argument);


typedef struct
{
    sdk_os_thread_attr_t thread_attr;
    sdk_os_thread_func_t func;
    sdk_os_thread_id_t   thread_id;
}sdk_os_thread_attr_tab_t;

/**
 * @brief        Status code values returned by RTOS functions.
 * @param        [in] ticks 延时多少ticks
 * @return        执行结果 返回状态
 */
int32_t sdk_os_delay(uint32_t ticks);

/**
 * @brief        毫秒转成tick数.
 * @param        [in] ms
 * @return        执行结果 tick
 */
uint32_t sdk_os_tick_from_millisecond(uint32_t ms);

/**
 * @brief        注册线程
 * @param        [in] thread_num  线程数量
 * @param        [in] *p_attr 线程属性结构指针
 * @return        执行结果
 * @retval        -1 创建失败 
 * @retval        0  创建成功  
 */
int32_t sdk_os_thread_new(uint8_t thread_num, sdk_os_thread_attr_tab_t *p_attr);

#endif
