/*
 * Copyright 2018-2020 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */
#ifndef __ONCHIP_FLASH_H__
#define __ONCHIP_FLASH_H__

#include <stdint.h>
#include "fsl_romapi.h"


//!< API 功能接口
void onchip_flash_init(void);
void onchip_flash_deinit(void);
uint32_t onchip_flash_sectorsize_get(void);
status_t onchip_flash_page_write(uint32_t addr, const uint8_t *buf, uint32_t len);
status_t onchip_flash_erase(uint32_t addr);
status_t onchip_flash_read(uint32_t addr, const uint8_t *buf, uint32_t len);
status_t FLEXSPI_NorFlash_GetVendorID(uint32_t instance, uint32_t *vendorID);
uint32_t FLASH_Test(uint32_t startAddr, uint32_t len);
uint32_t FLASH_GetProgramCmd(void);

#endif

