#include "update.h"
#include "uart.h"
#include "ff.h"
#include "crc32.h"
#include "stdio.h"
#include "hal_flash.h"
#include "fsl_cache.h"
#include "fsl_wdog.h"
#include "fsl_gpio.h"



#if !defined(MAX)
#define MAX(a, b) (((a) > (b)) ? (a) : (b))
#endif


#define CORE_START_ADDR             (0x60020000UL)
#define CORE_SIZE                   (0x100000UL)        // 1024k
#define APP_START_ADDR              (0x60120000UL)
#define APP_SIZE                    (0x20000UL)         // 128k
#define CHECK_INFO_ADDR             (0x60140000UL)      // 签名信息
#define CHECK_INFO_SIZE             (0x1000UL)          // 4k
#define UPGRADE_FLG_ADDR            (0x60141000UL)      // 升级标志位
#define UPGRADE_FLG_SIZE            (0x1000UL)          // 4k
#define OTHER_INFO_ADDR             (0x60142000UL)      // 其他信息


#define CHIP_ROLE                   0x34    // CSU芯片角色
//#define CHIP_ROLE                   0x3C    // CMU芯片角色
#define UPDATE_BUF_SIZE             4096    // 必须大等于4096
#define APP_FILE_NAME               "1:app.bin"
#define CORE_FILE_NAME              "1:core.bin"
#define TMP_FILE_NAME               "1:tmp.bin"
#define RETRY_CNT                   5


static FIL   g_fp;
BYTE g_work[FF_MAX_SS] = {0};
FATFS g_fs;
static uint8_t g_reset_flg = 0;
static uint8_t g_upgrade_flg = 0;
static uint8_t g_mount_flg = 0;
static uint8_t g_update_buf[UPDATE_BUF_SIZE];

typedef int32_t (*fn_t)(uint8_t *p_in, uint32_t in_len, uint8_t *p_out, uint32_t *p_out_len);

typedef struct
{
    uint8_t command_h;
    uint8_t command_l;
    fn_t data_in_out;
} update_sci_t;


static void delay_10ms(uint32_t n)
{
    while (n--)
    {
        volatile uint32_t i = 714290;

        while (i--)
        {
            __NOP();
        }
    }
}

static void delay_100ms(uint32_t n)
{
    while (n--)
    {
        volatile uint32_t i = 7142900;

        while (i--)
        {
            __NOP();
        }
    }
}

int32_t update_other_info_write(uint32_t offset, uint8_t dat)
{
    if (offset < 4096)
    {
		update_feet_dog();
        hal_flash_read(HAL_FLASH_ID_INT, OTHER_INFO_ADDR, 4096, g_update_buf);
        g_update_buf[offset] = dat;
        hal_flash_erase(HAL_FLASH_ID_INT, OTHER_INFO_ADDR, 1);   // 擦除内部flash
        DCACHE_InvalidateByRange(OTHER_INFO_ADDR, 4096);
        hal_flash_write(HAL_FLASH_ID_INT, OTHER_INFO_ADDR, 4096, g_update_buf);
        return 0;
    }
    else
    {
        return -1;
    }
}

static int32_t update_other_info_read(uint32_t offset, uint8_t *p_buf, uint32_t len)
{
    if (p_buf)
    {
        hal_flash_read(HAL_FLASH_ID_INT, OTHER_INFO_ADDR + offset, len, p_buf);
        return 0;
    }
    else
    {
        return -1;
    }
}


static int32_t update_upgrade_flg_read(uint32_t offset, uint8_t *p_flg, uint32_t len)
{
    if (p_flg)
    {
        hal_flash_read(HAL_FLASH_ID_INT, UPGRADE_FLG_ADDR + offset, len, p_flg);
        return 0;
    }
    else
    {
        return -1;
    }
}


int32_t update_upgrade_flg_write(uint32_t offset, uint8_t flg)
{
    if (offset < 4096)
    {
		update_feet_dog();
        hal_flash_read(HAL_FLASH_ID_INT, UPGRADE_FLG_ADDR, 4096, g_update_buf);
        g_update_buf[offset] = flg;
        hal_flash_erase(HAL_FLASH_ID_INT, UPGRADE_FLG_ADDR, 4096);   // 擦除内部flash
        DCACHE_InvalidateByRange(UPGRADE_FLG_ADDR, 4096);
        hal_flash_write(HAL_FLASH_ID_INT, UPGRADE_FLG_ADDR, 4096, g_update_buf);
        return 0;
    }
    else
    {
        return -1;
    }
}

/**
 * @brief                           检查升级文件完整性
 * @param p_file_name               待检查的升级文件名
 * @param [out] p_firmware_size     固件大小
 * @param [out] p_firmware_crc      固件crc
 * @return                          执行结果
 * @retval  0                       执行成功
 * @retval -1                       执行失败
 */
int32_t update_updatefile_check(char *p_file_name, uint32_t *p_firmware_size, uint32_t  *p_firmware_crc, uint8_t *p_firmware_type)
{
    FRESULT res;
    uint8_t file_type = 0;
    uint32_t br = 0;
    uint32_t file_crc = 0;
    uint32_t file_size = 0;
    uint32_t crc = 0;
    uint32_t i = 0;
    uint32_t cnt = 0;

    if (p_file_name == NULL || p_firmware_size == NULL || p_firmware_crc == NULL ||  p_firmware_type == NULL)
    {
        return -1;
    }

    res = f_close(&g_fp);
    res = f_open(&g_fp, p_file_name, FA_READ);

    if (res == FR_OK)
    {
        file_size = f_size(&g_fp);  // 获取文件大小
        res = f_lseek(&g_fp, file_size - 1024);   // 偏移到最后1k签名信息
        res = f_read(&g_fp, g_update_buf, 1024, &br);

        if (res == FR_OK)   // 读取最后1k数据成功
        {
            uint8_t *p = g_update_buf + 1;
            file_size = p[0] | p[1] << 8 | p[2] << 16 | p[3] << 24;     // 获取文件长度
            p += 4;
            file_crc = p[0] | p[1] << 8 | p[2] << 16 | p[3] << 24;      // 获取文件自带的crc32
            p = g_update_buf + 128;                                     // 获取文件类型
            file_type = *p;
            cnt = 0;

            if (file_size > MAX(CORE_SIZE, APP_SIZE))
            {
                res = f_close(&g_fp);
                return -1;
            }

            res = f_lseek(&g_fp, 0);
            // 计算crc
            crc = 0xFFFFFFFF;

            for (i = 0; i < file_size / UPDATE_BUF_SIZE; i++)
            {
				update_feet_dog();
                res = f_read(&g_fp, g_update_buf, UPDATE_BUF_SIZE, &br);
                crc = sdk_check_crc32(crc, g_update_buf, UPDATE_BUF_SIZE);
            }

            i = file_size % UPDATE_BUF_SIZE;
            res = f_read(&g_fp, g_update_buf, i, &br);
            crc = sdk_check_crc32(crc, g_update_buf, i);
            res = f_close(&g_fp);

            // 比对crc结果
            if (crc == file_crc)
            {
                *p_firmware_crc = file_crc;
                *p_firmware_size = file_size;
                *p_firmware_type = file_type;
                return 0;
            }
            else    // crc 校验错误
            {
                return -1;
            }
        }
        else    // 读取1k签名信息失败
        {
            return -1;
        }
    }
    else    // 文件打开失败
    {
        return -1;
    }
}

/**
 * @brief               sci 芯片角色
 * @param p_in_buf      收到的数据指针
 * @param in_len        收到的数据长度
 * @param p_out_buf     发送的数据指针
 * @param p_out_len     发送的数据长度
 * @return              解析结果
 * @retval      0       解析成功
 * @retval     -1       解析失败
 */

static int32_t update_sci_chip_role(uint8_t *p_in_buf, uint32_t in_len, uint8_t *p_out_buf, uint32_t *p_out_len)
{
    FRESULT res;

    if (in_len == 0)
    {
        res = f_close(&g_fp);
        // 打开文件
        res = f_open(&g_fp, TMP_FILE_NAME, FA_WRITE | FA_READ | FA_OPEN_ALWAYS);

        if (res != FR_OK)
        {
        }

        *p_out_buf = CHIP_ROLE;
        *p_out_len = 1;
        return 0;
    }
    else
    {
        return -1;
    }
}

/**
 * @brief               下发文件数据解析
 * @param p_in_buf      收到的数据指针
 * @param in_len        收到的数据长度
 * @param p_out_buf     发送的数据指针
 * @param p_out_len     发送的数据长度
 * @return              解析结果
 * @retval      0       解析成功
 * @retval     -1       解析失败
 */
static int32_t update_sci_file_data(uint8_t *p_in_buf, uint32_t in_len, uint8_t *p_out_buf, uint32_t *p_out_len)
{
    static uint16_t pack_num = 0;
    FRESULT res;
    uint32_t bw = 0;
    uint32_t len = 0;

    if (in_len > 2)
    {
        uint8_t *p = p_in_buf;
        uint16_t tmp = p[0] << 8 | p[1];
        len = in_len - 2;

        if (tmp == 1)   // 第一包
        {
            pack_num = 1;
        }

        if (tmp == pack_num)    // 包序号相等
        {
            res = f_write(&g_fp, p + 2, len, &bw);

            if (len != bw || res != FR_OK)  // 写失败
            {
                printf("write fail len = %d, bw = %d\r\n",len,bw);
            }

            pack_num++;
        }
        else    // 包序号不等
        {
        }

        p_out_buf[0] = p_in_buf[0];
        p_out_buf[1] = p_in_buf[1];
        *p_out_len = 2;
        return 0;
    }
    else    // 长度错误
    {
        return -1;
    }
}

/**
 * @brief               sci 文件传输完成解析
 * @param p_in_buf      收到的数据指针
 * @param in_len        收到的数据长度
 * @param p_out_buf     发送的数据指针
 * @param p_out_len     发送的数据长度
 * @return              解析结果
 * @retval      0       解析成功
 * @retval     -1       解析失败
 */
static int32_t update_sci_file_finish(uint8_t *p_in_buf,
                                      uint32_t in_len,
                                      uint8_t *p_out_buf,
                                      uint32_t *p_out_len)
{
    int32_t ret = 0;
    uint8_t upgrade_flg = 0;
    uint32_t file_size = 0;
    uint32_t file_crc = 0;
    uint32_t i = 0;
    uint32_t crc = 0xFFFFFFFF;
    uint8_t file_type = 0;
    uint32_t br = 0;
    FRESULT res;

    if (in_len == 0)
    {
        *p_out_len = 1;
        p_out_buf[0] = 1;
        res = f_close(&g_fp);
        ret = update_updatefile_check(TMP_FILE_NAME, &file_size, &file_crc, &file_type);

        // 校验成功
        if (ret == 0)
        {
            if (file_type == 0)     // app
            {
                res = f_unlink(APP_FILE_NAME);
                printf("f_unlink = %d\r\n",res);
                res = f_rename(TMP_FILE_NAME, APP_FILE_NAME);
                printf("f_rename = %d\r\n",res);
            }
            else                    // core
            {
                res = f_unlink(CORE_FILE_NAME);
                res = f_rename(TMP_FILE_NAME, CORE_FILE_NAME);
            }

            update_upgrade_flg_write(file_type, 1);
        }
        else
        {
            return -1;
        }

        return 0;
    }
    else
    {
        return -1;
    }
}

/**
 * @brief               开始升级解析
 * @param p_in_buf      收到的数据指针
 * @param in_len        收到的数据长度
 * @param p_out_buf     发送的数据指针
 * @param p_out_len     发送的数据长度
 * @return              解析结果
 * @retval      0       解析成功
 * @retval     -1       解析失败
 */
static int32_t update_sci_start_upgrade(uint8_t *p_in, uint32_t in_len, uint8_t *p_out, uint32_t *p_out_len)
{
    if (in_len == 0)
    {
        p_out[0] = 0x01;
        *p_out_len = 1;
        g_reset_flg = 1;
        return 0;
    }
    else
    {
        return -1;
    }
}

static const update_sci_t g_update_sci[] =
{
    [0] = {.command_h = 0x90, .command_l = 0x10, .data_in_out = update_sci_chip_role},
    [1] = {.command_h = 0x90, .command_l = 0x20, .data_in_out = update_sci_file_data},
    [2] = {.command_h = 0x90, .command_l = 0x21, .data_in_out = update_sci_file_finish},
    [3] = {.command_h = 0x90, .command_l = 0x22, .data_in_out = update_sci_start_upgrade},
};

/**
 * @brief               sci 通讯数据交换
 * @param cmd_h         命令高字节
 * @param cmd_l         命令低字节
 * @param p_in_buf      收到的数据指针
 * @param in_len        收到的数据长度
 * @param p_out_buf     发送的数据指针
 * @param p_out_len     发送的数据长度
 * @return              执行结果
 * @retval      0       执行成功
 * @retval     -1       执行失败
 */
int32_t update_sci_data_swap(uint8_t cmd_h,
                             uint8_t cmd_l,
                             uint8_t *p_in_buf,
                             uint32_t in_len,
                             uint8_t *p_out_buf,
                             uint32_t *p_out_len)
{
    for (int i = 0 ; i < sizeof(g_update_sci) / sizeof(g_update_sci[0]); i++)
    {
        if (cmd_h == g_update_sci[i].command_h && cmd_l == g_update_sci[i].command_l)
        {
            return g_update_sci[i].data_in_out(p_in_buf, in_len, p_out_buf, p_out_len);
        }
    }

    return -1;
}

/**
 * @brief           sci通讯数据发送
 * @param p_buf     数据指针
 * @param len       数据长度
 */
void update_sci_data_send(uint8_t *p_buf, uint32_t len)
{
    uart_send(LPUART2, p_buf, len);
}

/**
 * @brief           sci通讯数据接收
 * @param p_dat     数据指针
 * @return          执行结果
 * @retval     0    执行成功
 */
int32_t update_sci_data_receive(uint8_t *p_dat)
{
    return uart_receive(LPUART2, p_dat);
}

/**
 * @brief 复位
 *
 */
void update_proc(void)
{
    if (g_reset_flg)
    {
        g_reset_flg = 0;
        NVIC_SystemReset();
    }
}

/**
 * @brief               校验信息读取
 * @param offset        偏移地址
 * @param p_buf         数据指针
 * @param len           数据长度
 * @return              执行结果
 * @retval         0    读取成功
 * @retval       非0    读取失败
 */
static int32_t update_check_info_read(uint32_t offset, uint8_t *p_buf, uint32_t len)
{
    return hal_flash_read(HAL_FLASH_ID_INT, CHECK_INFO_ADDR + offset, len, p_buf);
}


static int32_t update_check_info_write(char *p_file_name)
{
    FRESULT res;
    uint32_t br = 0;
    uint32_t file_size = 0;

    if (p_file_name ==  NULL)
    {
        return -1;
    }

    // 打开文件
    res = f_open(&g_fp, p_file_name, FA_READ);

    if (res == FR_OK)
    {
        //        DCACHE_InvalidateByRange(CHECK_INFO_ADDR, 4096);
        // 读取内部4k签名数据
        hal_flash_read(HAL_FLASH_ID_INT, CHECK_INFO_ADDR, 4096, g_update_buf);
        //
        file_size = f_size(&g_fp);  // 获取文件大小
        res = f_lseek(&g_fp, file_size - 1024);   // 偏移到最后1k签名信息

        // 更新签名数据
        if (strcmp(p_file_name, APP_FILE_NAME) == 0) // app放到0-1k
        {
            res = f_read(&g_fp, g_update_buf, 1024, &br);
        }
        else if (strcmp(p_file_name, CORE_FILE_NAME) == 0)  // core放到2-3k
        {
            res = f_read(&g_fp, g_update_buf + 2048, 1024, &br);
        }
        else
        {
            res = f_close(&g_fp);
            return -1;
        }

        // 写入
        if (res == FR_OK)   // 读取最后1k数据成功
        {
			update_feet_dog();
            hal_flash_erase(HAL_FLASH_ID_INT, CHECK_INFO_ADDR, 4096);   // 擦除内部flash
            DCACHE_InvalidateByRange(CHECK_INFO_ADDR, 4096);
            hal_flash_write(HAL_FLASH_ID_INT, CHECK_INFO_ADDR, 4096, g_update_buf);
            res = f_close(&g_fp);
            return 0;
        }
        else
        {
            res = f_close(&g_fp);
            return -1;
        }
    }
    else
    {
        return -1;
    }
}



/**
 * @brief               从外部flash数据复制到内部flash
 * @param p_file_name   文件名
 * @param target_addr   内部地址
 * @param size          数据大小
 * @return              执行结果
 * @retval      0       成功
 * @retval      -1      失败
 */
static int32_t update_firmware_cp(char *p_file_name, uint32_t target_addr, uint32_t size)
{
    FRESULT res;
    uint32_t i = 0;
    uint32_t br = 0;

    if (p_file_name == NULL || size > MAX(CORE_SIZE, APP_SIZE))
    {
        return -1;
    }

    res = f_open(&g_fp, p_file_name, FA_READ);

    if (res == FR_OK)
    {

        hal_flash_erase(HAL_FLASH_ID_INT, target_addr, size);   // 擦除内部flash
        DCACHE_InvalidateByRange(target_addr, size);

        for (i = 0; i < size / UPDATE_BUF_SIZE; i++)
        {
			update_feet_dog();
            f_read(&g_fp, g_update_buf, UPDATE_BUF_SIZE, &br);
            hal_flash_write(HAL_FLASH_ID_INT, target_addr + i * UPDATE_BUF_SIZE, UPDATE_BUF_SIZE, g_update_buf);
        }

        f_read(&g_fp, g_update_buf, size % UPDATE_BUF_SIZE, &br);
        hal_flash_write(HAL_FLASH_ID_INT, target_addr + i * UPDATE_BUF_SIZE, size % UPDATE_BUF_SIZE, g_update_buf);
        f_close(&g_fp);
        return 0;
    }

    return -1;
}

/**
 * @brief                   固件校验
 * @param firmware_addr     待校验的固件地址
 * @param size              固件大小
 * @param check_value       比较值
 * @return                  校验结果
 * @retval  0               校验成功
 * @retval  -1              校验失败
 */
static int32_t update_firmware_check(uint32_t firmware_addr, uint32_t size, uint32_t check_value)
{
    uint32_t i = 0;
    uint32_t crc = 0xFFFFFFFF;

    if (firmware_addr != CORE_START_ADDR && firmware_addr != APP_START_ADDR)
    {
        return -1;
    }

    for (i = 0; i < size / UPDATE_BUF_SIZE; i++)
    {
		update_feet_dog();
        hal_flash_read(HAL_FLASH_ID_INT, firmware_addr + UPDATE_BUF_SIZE * i, UPDATE_BUF_SIZE, g_update_buf);
        crc = sdk_check_crc32(crc, g_update_buf, UPDATE_BUF_SIZE);
    }

    hal_flash_read(HAL_FLASH_ID_INT, firmware_addr + UPDATE_BUF_SIZE * i, size % UPDATE_BUF_SIZE, g_update_buf);
    crc = sdk_check_crc32(crc, g_update_buf, size % UPDATE_BUF_SIZE);

    if (crc == check_value)
    {
        return 0;
    }
    else
    {
        return -1;
    }
}

/**
 * @brief                   固件搬运及更新校验信息
 * @param p_file_name       升级文件名
 * @param firmware_addr     固件地址
 * @return                  执行结果
 * @retval      0           执行成功
 * @retval     -1           执行失败
 */
static int32_t update_firmware_update(char *p_file_name, uint32_t firmware_addr)
{
    int ret = 0;
    int cnt = 0;
    uint32_t firmware_size = 0;
    uint32_t firmware_crc = 0;
    uint8_t firmware_type = 0;  // 文件类型，用来区分是app还是core

    if (p_file_name == NULL)
    {
        return -1;
    }

    // 检查文件系统里面的固件完整性
    ret = update_updatefile_check(p_file_name, &firmware_size, &firmware_crc, &firmware_type);

    if (ret == 0)
    {
        // 从文件系统复制固件数据到内部flash
        ret = update_firmware_cp(p_file_name, firmware_addr, firmware_size);

        if (0 == ret)
        {
            // 校验内部flash数据是否复制成功，
            ret = update_firmware_check(firmware_addr, firmware_size, firmware_crc);

            if (ret == 0)
            {
                update_upgrade_flg_write(firmware_type, 2);
                update_check_info_write(p_file_name);
                return 0;
            }
            else
            {
                return -1;
            }
        }
        else
        {
            return -1;
        }
    }
    else
    {
        return -1;
    }
}

static void update_fs_mount(void)
{
    FRESULT res;
    uint8_t tmp = 0;
    int cnt = 0;

    do
    {
        res = f_mount(&g_fs, "1:", 1);
        cnt++;

        if (res != FR_OK)
        {
            delay_100ms(cnt);
        }
    } while (res != FR_OK && cnt < RETRY_CNT);

    if (res != FR_OK)
    {
        update_other_info_read(1, &tmp, 1);

        if (tmp == 0xFF)
        {
            tmp = 0;
        }

        if (tmp > 3)
        {
            res = f_mkfs("1:", 0, g_work, sizeof(g_work));

            if (res == FR_OK)
            {
                res = f_mount(&g_fs, "1:", 1);

                if (res == FR_OK)
                {
                    g_mount_flg = 1;
                    update_other_info_write(1, 0);
                }
            }
        }
        else
        {
            tmp++;
            update_other_info_write(1, tmp);
            NVIC_SystemReset();
        }
    }
    else
    {
        update_other_info_read(1, &tmp, 1);

        if (tmp > 0 && tmp != 0xFF)
        {
            update_other_info_write(1, 0);
        }

        g_mount_flg = 1;
    }
}

int32_t update_upgrade(void)
{
    int32_t cnt = 0;
    int32_t ret = 0;
    uint8_t upgrade_flg[2];
    uint8_t tmp = 0;
    // 读取升级标志位
    ret = update_upgrade_flg_read(0, upgrade_flg, 2);

    if (upgrade_flg[0] == 1 || upgrade_flg[1] == 1)
    {
        update_fs_mount();

        if (upgrade_flg[0] == 1)    // 升级app
        {
            cnt = 0;

            do
            {
                ret = update_firmware_update(APP_FILE_NAME, APP_START_ADDR);
                cnt++;

                if (ret != 0)
                {
                    delay_10ms(cnt);
                }
            } while (ret != 0 && cnt < RETRY_CNT);
        }

        if (upgrade_flg[1] == 1)    // 升级core
        {
            cnt = 0;

            do
            {
                ret = update_firmware_update(CORE_FILE_NAME, CORE_START_ADDR);
                cnt++;

                if (ret != 0)
                {
                    delay_10ms(cnt);
                }
            } while (ret != 0 && cnt < RETRY_CNT);
        }

        if (ret == 0)
        {
            update_other_info_write(0, 0);
        }
    }

    if (upgrade_flg[0] == 2 || upgrade_flg[1] == 2)
    {
        update_other_info_read(0, &tmp, 1);

        if (tmp == 0xFF)
        {
            tmp = 0;
        }

        if (tmp > 5)
        {
            g_upgrade_flg = 1;  // 不跳转，准备升级

            if (g_mount_flg == 0)
            {
                update_fs_mount();
            }
        }
        else
        {
            tmp++;
            update_other_info_write(0, tmp);
        }
    }

    return 0;
}


static int32_t update_jump2image(void)
{
    typedef void(*app_entry_f)(void);
    uint32_t *vector_table = (uint32_t *)CORE_START_ADDR;
    static uint32_t sp = 0;
    static uint32_t pc = 0;
    static app_entry_f application = 0;
    //
    sp = vector_table[0];
    pc = vector_table[1];
    application = (app_entry_f)pc;

    if (pc >= CORE_START_ADDR && pc <= (CORE_START_ADDR + CORE_SIZE))
    {
        __set_MSP(sp);
        // SCB->VTOR = CORE_START_ADDR; 放到core中去映射向量表
        application();
        __NOP();
    }
    else
    {
        return -1;
    }

    return 0;
}




/**
 * @brief 跳转
 * @return 执行结果
 * @retval -1 跳转失败
 */
int32_t update_jump(void)
{
    int32_t ret = 0;

    if (g_upgrade_flg == 0)
    {
        ret = update_jump2image();

        if (ret == -1)
        {
            if (g_mount_flg == 0)
            {
                update_fs_mount();
            }
        }
    }
    else
    {
        if (g_mount_flg == 0)
        {
            update_fs_mount();
        }
    }

    return 0;
}

/**
 * @brief 喂狗
 */
void update_feet_dog(void)
{
#ifdef EBI_215K_R
	GPIO_PortToggle((GPIO_Type *)GPIO2_BASE,1<<14U);
#endif
    WDOG_Refresh(WDOG1);
}