#ifndef __UPDATE_H__
#define __UPDATE_H__

#include "data_types.h"


int32_t update_upgrade(void);
int32_t update_jump(void);
void    update_proc(void);

int32_t update_sci_data_receive(uint8_t *p_dat);
void    update_sci_data_send(uint8_t *p_buf, uint32_t len);
int32_t update_sci_data_swap(uint8_t cmd_h,
                             uint8_t cmd_l,
                             uint8_t *p_in_buf,
                             uint32_t in_len,
                             uint8_t *p_out_buf,
                             uint32_t *p_out_len);
void update_feet_dog(void);


#endif
