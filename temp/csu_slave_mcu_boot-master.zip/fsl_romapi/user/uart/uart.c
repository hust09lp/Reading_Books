#include "uart.h"
#include "stdio.h"

int fputc(int ch, FILE *f)
{
    uart_send(LPUART7, (uint8_t*)&ch, 1);
    return ch;
}

void uart_init(void)
{
    lpuart_config_t config;
    LPUART_GetDefaultConfig(&config);
    config.baudRate_Bps = 115200;
    config.enableTx     = true;
    config.enableRx     = true;
    LPUART_Init(LPUART1, &config, CLOCK_GetClockRootFreq(kCLOCK_UartClkRoot));
    LPUART_Init(LPUART2, &config, CLOCK_GetClockRootFreq(kCLOCK_UartClkRoot));
    LPUART_Init(LPUART7, &config, CLOCK_GetClockRootFreq(kCLOCK_UartClkRoot));
}

int uart_send(LPUART_Type *base, uint8_t *p_buf, uint32_t len)
{
    return LPUART_WriteBlocking(base, p_buf, len);
}


int uart_receive(LPUART_Type *base, uint8_t *ch)
{
    if (base->STAT & LPUART_STAT_RDRF_MASK)
    {
        *ch = (uint8_t)(base->DATA);
        return 0;
    }

    if (base->STAT & LPUART_STAT_OR_MASK)
    {
        base->STAT |= LPUART_STAT_OR_MASK;
    }

    return 1;
}



