#include "hal_flash.h"
#include "fsl_wdog.h"
#include "fsl_gpio.h"

#include "sfud.h"
#include "onchip_flash.h"
#include "update.h"

//#define HAL_FLASH_TEST

#ifdef HAL_FLASH_TEST


#define SFUD_DEMO_TEST_BUFFER_SIZE                     1024
static uint8_t sfud_demo_test_buf[SFUD_DEMO_TEST_BUFFER_SIZE];

void sfud_demo(uint32_t addr, size_t size, uint8_t *data)
{
    sfud_err result = SFUD_SUCCESS;
    sfud_flash *flash = sfud_get_device(SFUD_W25QXX_DEVICE_INDEX);
    size_t i;

    /* prepare write data */
    for (i = 0; i < size; i++)
    {
        data[i] = i & 0xFF;
    }

    /* erase test */
    result = sfud_erase(flash, addr, size);

    if (result == SFUD_SUCCESS)
    {
        printf("Erase the %s flash data finish. Start from 0x%08X, size is %u.\r\n", flash->name, addr, size);
    }
    else
    {
        printf("Erase the %s flash data failed.\r\n", flash->name);
        return;
    }

    /* write test */
    result = sfud_write(flash, addr, size, data);

    if (result == SFUD_SUCCESS)
    {
        printf("Write the %s flash data finish. Start from 0x%08X, size is %zu.\r\n", flash->name, addr, size);
    }
    else
    {
        printf("Write the %s flash data failed.\r\n", flash->name);
        return;
    }

    for (i = 0; i < size; i++)
    {
        data[i] = 0;
    }

    /* read test */
    result = sfud_read(flash, addr, size, data);

    if (result == SFUD_SUCCESS)
    {
        printf("Read the %s flash data success. Start from 0x%08X, size is %zu. The data is:\r\n", flash->name, addr, size);
        printf("Offset (h) 00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F\r\n");

        for (i = 0; i < size; i++)
        {
            if (i % 16 == 0)
            {
                printf("[%08X] ", addr + i);
            }

            printf("%02X ", data[i]);

            if (((i + 1) % 16 == 0) || i == size - 1)
            {
                printf("\r\n");
            }
        }

        printf("\r\n");
    }
    else
    {
        printf("Read the %s flash data failed.\r\n", flash->name);
    }

    /* data check */
    for (i = 0; i < size; i++)
    {
        if (data[i] != (i & 0xFF))
        {
            printf("Read and check write data has an error. Write the %s flash data failed.\r\n", flash->name);
            break;
        }
    }

    if (i == size)
    {
        printf("The %s flash test is success.\r\n", flash->name);
    }
}

#endif

static const sfud_flash *gp_flash = NULL;


/**
 * @brief FLASH初始化
 * @return 执行状态
 * @retval HAL_OK       初始化成功
 * @retval HAL_ENXIO    初始化失败
 */
int32_t hal_flash_init(void)
{
    int32_t ret = HAL_OK;

    if (SFUD_SUCCESS == sfud_init())
    {
        gp_flash = sfud_get_device_table();
#ifdef HAL_FLASH_TEST
        sfud_demo(1024, sizeof(sfud_demo_test_buf), sfud_demo_test_buf);
#endif
        ret = HAL_OK;
    }
    else
    {
        ret = HAL_ENXIO;
    }

    
    return ret;
}

/**
 * @brief FLASH反初始化
 * @return 执行状态
 * @retval HAL_OK   反初始化成功
 */
int32_t hal_flash_deinit(void)
{
    int32_t ret = HAL_OK;
    return ret;
}

/**
 * @brief FLASH信息获取
 *
 * @param dev_no    FLASH设备号
 * @param info      信息指针
 * @return          执行结果
 * @retval HAL_OK   执行成功
 * @retval HAL_NINIT 没有初始化
 */
int32_t hal_flash_info_get(uint32_t dev_no, hal_flash_info_t *info)
{
    int32_t ret = HAL_OK;

    switch (dev_no)
    {
        case HAL_FLASH_ID_EXT:
        {
            if (gp_flash)
            {
                info->total_size = gp_flash->chip.capacity;
                info->sector_size = gp_flash->chip.erase_gran;
                ret = HAL_OK;
            }
            else
            {
                ret = HAL_NINIT;
            }

            break;
        }

        case HAL_FLASH_ID_INT:
        {
            break;
        }

        default:
        {
            ret = HAL_EPERR;
            break;
        }
    }

    return ret;
}

/**
 * @brief 获取SN码
 * @param dev_no    FLASH设备号
 * @param id        指针
 * @param len       长度
 * @return 执行结果
 * @retval HAL_OK   执行成功
 */
int32_t hal_flash_sn_get(uint32_t dev_no, uint8_t *id, uint32_t len)
{
    int32_t ret = HAL_OK;
    return ret;
}


/**
 * @brief FLASH写数据
 * @param dev_no    FLASH设备号
 * @param offset    起始地址
 * @param len       长度
 * @param buf       数据指针
 * @return          执行结果
 * @retval  HAL_OK  执行成功
 * @retval  HAL_ENXIO 执行失败
 * @retval HAL_NINIT  没有初始化
 */
int32_t hal_flash_write(uint32_t dev_no, uint32_t offset, uint32_t len, uint8_t *buf)
{
    int32_t ret = HAL_OK;

    switch (dev_no)
    {
        case HAL_FLASH_ID_EXT:
        {
            if (gp_flash)
            {
                ret = (SFUD_SUCCESS == sfud_erase_write(gp_flash, offset, len, buf)) ? (HAL_OK) : (HAL_ENXIO);
            }
            else
            {
                ret = HAL_NINIT;
            }

            break;
        }

        case HAL_FLASH_ID_INT:
        {
            uint32_t i = 0;
            ret = 0;

            for (i = 0; i < len / 256; i++)
            {
                ret += onchip_flash_page_write(offset + i * 256, buf + i * 256, 256);
            }

            ret += onchip_flash_page_write(offset + i * 256, buf + i * 256, len % 256);

            if (ret == 0)
            {
                ret = HAL_OK;
            }
            else
            {
                ret = HAL_ENXIO;
            }

            break;
        }

        default:
        {
            ret = HAL_EPERR;
            break;
        }
    }

    return ret;
}


/**
 * @brief FLASH读数据
 * @param dev_no        FLASH设备号
 * @param offset        起始地址
 * @param len           长度
 * @param buf           数据指针
 * @return              执行结果
 * @retval HAL_OK       执行成功
 * @retval HAL_ENXIO    执行失败
 * @retval HAL_NINIT    没有初始化
 */
int32_t hal_flash_read(uint32_t dev_no, uint32_t offset, uint32_t len, uint8_t *buf)
{
    int32_t ret = HAL_OK;

    switch (dev_no)
    {
        case HAL_FLASH_ID_EXT:
        {
            if (gp_flash)
            {
                ret = (SFUD_SUCCESS == sfud_read(gp_flash, offset, len, buf)) ? (HAL_OK) : (HAL_ENXIO);
            }
            else
            {
                ret = HAL_NINIT;
            }

            break;
        }

        case HAL_FLASH_ID_INT:
        {
            ret = (0 == onchip_flash_read(offset, buf, len)) ? (HAL_OK) : (HAL_ENXIO);
            break;
        }

        default:
        {
            ret = HAL_EPERR;
            break;
        }
    }

    return ret;
}


/**
 * @brief FLASH擦除
 * @param dev_no        FLASH设备号
 * @param offset        起始地址
 * @param len           长度
 * @return              执行结果
 * @retval HAL_OK       执行成功
 * @retval HAL_ENXIO    执行失败
 * @retval HAL_NINIT    没有初始化
 */
int32_t hal_flash_erase(uint32_t dev_no, uint32_t offset, uint32_t len)
{
    int32_t ret = HAL_OK;

    switch (dev_no)
    {
        case HAL_FLASH_ID_EXT:
        {
            if (gp_flash)
            {
                ret = (SFUD_SUCCESS == sfud_erase(gp_flash, offset, len)) ? (HAL_OK) : (HAL_ENXIO);
            }
            else
            {
                ret = HAL_NINIT;
            }

            break;
        }

        case HAL_FLASH_ID_INT:
        {
            // 获取扇区大小
            uint32_t sector_size = onchip_flash_sectorsize_get();
            len += sector_size - 1;
            ret = 0;

            for (int i = 0; i < len / sector_size; i++)
            {
				update_feet_dog();
                ret += onchip_flash_erase(offset);
                offset += sector_size;
            }

            if (ret == 0)
            {
                ret = HAL_OK;
            }
            else
            {
                ret = HAL_ENXIO;
            }

            break;
        }

        default:
        {
            ret = HAL_EPERR;
            break;
        }
    }

    return ret;
}


/**
 * @brief FLASH控制
 * @param dev_no    FLASH设备号
 * @param cmd       命令
 * @param args      参数
 * @return          执行结果
 * @retval HAL_OK   执行成功
 */
int32_t hal_flash_ioctl(int32_t dev_no, uint8_t cmd, void *args)
{
    int32_t ret = HAL_OK;

    switch (dev_no)
    {
        case HAL_FLASH_ID_INT:
        {
            break;
        }

        case HAL_FLASH_ID_EXT:
        {
            break;
        }

        default:
        {
            ret = HAL_EPERR;
            break;
        }
    }

    return ret;
}
