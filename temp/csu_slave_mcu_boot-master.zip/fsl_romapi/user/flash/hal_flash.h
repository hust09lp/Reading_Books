#ifndef __HAL_FLASH_H__
#define __HAL_FLASH_H__

#include "hal_errors.h"
#include "data_types.h"

/**
  * @struct hal_pwm_config_t
  * @brief flash信息
  */
typedef struct
{
    uint32_t     total_size;         ///< Total flash size
    uint32_t     page_size;          ///< Write (page) size
    uint32_t     sector_size;        ///< Erase (sector) size
}hal_flash_info_t;

/**
  * @struct 
  * @brief FLASH类型
  */
enum
{
    HAL_FLASH_ID_INT,   ///< 内部flash
    HAL_FLASH_ID_EXT,   ///< 外部flash
    HAL_FLASH_ID_MAX,   ///< flash总数
};



#define W25Q128_SECTOR_SIZE 4096
#define W25Q128_MAP0_ADDR 0
#define W25Q128_MAP0_SECTOR_NUM 1536 // 总大小: 4k * 1536 = 6M byte
#define W25Q128_MAP1_ADDR (W25Q128_SECTOR_SIZE * 3584)
#define W25Q128_MAP1_SECTOR_NUM 512 // 总大小: 4k * 512 = 2M byte



int32_t hal_flash_init(void);
int32_t hal_flash_deinit(void);
int32_t hal_flash_info_get(uint32_t dev_no, hal_flash_info_t *info);
int32_t hal_flash_sn_get(uint32_t dev_no, uint8_t *id, uint32_t len);
int32_t hal_flash_write(uint32_t dev_no, uint32_t offset, uint32_t len, uint8_t *buf);
int32_t hal_flash_read(uint32_t dev_no, uint32_t offset, uint32_t len, uint8_t *buf);
int32_t hal_flash_erase(uint32_t dev_no, uint32_t offset, uint32_t len);
int32_t hal_flash_ioctl(int32_t dev_no, uint8_t cmd, void* args);



#endif
