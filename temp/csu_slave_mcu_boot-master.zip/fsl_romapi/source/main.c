/*
 * Copyright 2020 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "fsl_romapi.h"
#include "fsl_wdog.h"

#include "board.h"

#include "pin_mux.h"
#include "clock_config.h"
#include "board.h"

#include "uart.h"
#include "sci.h"
#include "update.h"
#include "stdio.h"
#include "onchip_flash.h"

int main(void)
{
    uint8_t ch;

    sci_t sci;
    wdog_config_t config;
    BOARD_ConfigMPU();
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    onchip_flash_init();
    uart_init();
    //
    WDOG_GetDefaultConfig(&config);
    config.workMode.enableDebug   = true;
    config.timeoutValue = 0xBU; /* Timeout value is (0xB + 1)/2 = 6 sec. */
    WDOG_Init(WDOG1, &config);
    // 升级检查
	update_feet_dog();
    update_upgrade();
    // 跳转
	update_feet_dog();
    update_jump();

    // SCI通讯初始化
    sci.data_send = update_sci_data_send;
    sci.data_swap = update_sci_data_swap;
    sci.slave_addr = 0x01;

    while (1)
    {
		update_feet_dog();

        if (update_sci_data_receive(&ch) == 0)
        {
            sci_receive(&sci, ch);
        }

        update_proc();
    }

    return 0;
}

