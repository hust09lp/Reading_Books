/** 
 * @file          even_record_task.c
 * @brief         历史事件记录接口函数功能实现
 * @author        duyumeng
 * @version       V0.0.1     初始版本
 * @date          2022/08/25
 * @copyright     Copyright (c) 2023 by SofarSolar, All Rights Reserved. 
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author    	  <th>Description 
 * <tr><td>2022/08/25  <td>0.0.1    <td>duyumeng  	  <td>创建初始版本  
 * <tr><td>2023/03/15  <td>0.0.2    <td>liangguyao    <td>根据需求，作以下修改:
 *                                                        1.删除DCDC模块故障；
 *                                                        2.主设备由逆变器故障变更为CMU的故障/告警；
 *                                                        3.增加电池簇模块的故障/告警。
 * </table>
 **********************************************************************************
 */

#include <sys/stat.h>
#include "event_record_task.h"
#include "process_battery_read.h"
#include "sdk_shm.h"
#include "sdk_public.h"
#include "sofar_log.h"
#include "sofar_errors.h"

#include <string.h>
#include <stdbool.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include "sqlite3.h"
#include <sys/stat.h>

uint8_t g_cmu_fault_pre[CMU_SYSTEM_FAULT_LEN_BYTE] = {0};
uint8_t g_container_fault_pre[CONTAINER_SYSTEM_FAULT_LEN_BYTE] = {0};
uint8_t g_container_warn_pre[CONTAINER_SYSTEM_WARN_LEN_BYTE] = {0};
uint8_t g_battery_cluster_fault_pre[BCU_DEVICE_NUM][BATTERY_CLUSTER_FAULT_LEN_BYTE] = {0};
uint8_t g_battery_cluster_warn_pre[BCU_DEVICE_NUM][BATTERY_CLUSTER_WARN_LEN_BYTE] = {0};
pcs_telematic_info_t g_pcs_module[PCS_CABINET_POWER_MODULE_NUM] = {0};

#define FAULT_DB_PATH "/user/data/event/Faults.db"
#define SDK_OK  0
#define PATH_HISTORY_EVENT_RECOND_FOLDER	"/user/data/event/"

int32_t sqlite_db_create_table(void);


/**
 * @brief  检查故障记录数据库文件是否存在和有效
 * @param  [in] none
 * @param  [out] none
 * @return 0-数据库文件正常   -1-数据库文件异常
 */
static int32_t history_event_file_check(void)
{
	int32_t ret = -1;
	struct stat file_stat;
	
    ret = sdk_fs_access((const int8_t *)FAULT_DB_PATH, F_OK);
    if (ret == -1)  // 文件不存在，创建该文件
    {
		log_i((const int8_t*)"\nFaults.db is not exist\n");
		sqlite_db_create_table();
		return (0);
    }
	else     // 文件存在，检查文件大小是否为0
	{
		ret = stat(FAULT_DB_PATH,&file_stat);
        if(ret != SF_OK)
        {
            sqlite_db_create_table();
		    return (0);
        }
        else
        {
            if(file_stat.st_size == 0)
            {
                sdk_fs_remove((const int8_t *)FAULT_DB_PATH);
                sqlite_db_create_table();
            }
        }
	}
	return (0);
}

static int32_t history_event_start_write(uint16_t event_id)
{
	sqlite3 *db;
	sdk_rtc_t rtc_time;
    int32_t ret;
	char *errMsg = NULL;
	char sql[128] = {0};

	history_event_file_check();
	ret = sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
	if (ret != SDK_OK)
    {
		log_i((int8_t *)"\n [%s:%d] sdk_rtc_get fail \n", __func__, __LINE__);
		return (-1);
    }

	snprintf(sql, 128, "INSERT INTO Faults (FAULTID, STARTTIME, ENDTIME) VALUES (%d, '%04d-%02d-%02d %02d:%02d:%02d', '1970-00-00 00:00:00');" \
	,event_id, 2000 + rtc_time.tm_year,rtc_time.tm_mon, rtc_time.tm_day, rtc_time.tm_hour, rtc_time.tm_min, rtc_time.tm_sec);

	
    ret = sqlite3_open("/user/data/event/Faults.db", &db);
    if( ret ) {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return(-1);
    }

	ret = sqlite3_exec(db, sql, 0, 0, &errMsg);
	
	if (ret != SQLITE_OK) {
		fprintf(stderr, "SQL error: %s\n", errMsg);
		sqlite3_free(errMsg);
		return (-1);
	} else {
	   fprintf(stdout, "Records created successfully\n");
	}
    sqlite3_file_control(db, "/user/data/event/Faults.db", SQLITE_FCNTL_SYNC, NULL);
	sqlite3_close(db);
	return(0);
}

static int32_t history_event_end_write(uint16_t event_id)
{
	sqlite3 *db;
	sqlite3_stmt *stmt;
	sdk_rtc_t rtc_time;
    int32_t ret;
	char *errMsg = NULL;
	char sql_update[128] = {0};
	char new_end_time[32] = {0};

	history_event_file_check();
	// 查询最近一条故障ID为1的记录
	snprintf(sql_update, 128, "SELECT ID FROM Faults WHERE FAULTID = %d ORDER BY ID DESC LIMIT 1;",event_id);
	
    ret = sqlite3_open("/user/data/event/Faults.db", &db);
    if( ret ) {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return(-1);
    }
	
	ret = sqlite3_prepare_v2(db, sql_update, -1, &stmt, 0);
	
	if (ret != SQLITE_OK) {
		fprintf(stderr, "Failed to fetch data: %s\n", sqlite3_errmsg(db));
		sqlite3_close(db);
		return (-1);
	}
	int latest_id;
	// 如果有结果
	if (sqlite3_step(stmt) == SQLITE_ROW) {
		latest_id = sqlite3_column_int(stmt, 0);
	} else {
		fprintf(stderr, "No record found with the provided FAULTID.\n");
		sqlite3_close(db);
		return (-1);
	}
	
	sqlite3_finalize(stmt);

	ret = sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
	if (ret != SDK_OK)
    {
		log_i((int8_t *)"\n [%s:%d] sdk_rtc_get fail \n", __func__, __LINE__);
		sqlite3_close(db);
		return (-1);
    }	
	// 更新这条记录的结束时间
	sprintf(new_end_time, "'%04d-%02d-%02d %02d:%02d:%02d'", 2000 + rtc_time.tm_year,rtc_time.tm_mon, rtc_time.tm_day, rtc_time.tm_hour, rtc_time.tm_min, rtc_time.tm_sec);
	sprintf(sql_update, "UPDATE Faults SET ENDTIME = %s WHERE ID = %d;", new_end_time, latest_id);
	
	ret = sqlite3_exec(db, sql_update, 0, 0, &errMsg);
	
	if (ret != SQLITE_OK) {
		fprintf(stderr, "SQL error: %s\n", errMsg);
		sqlite3_free(errMsg);
		sqlite3_close(db);
		return (-1);
	} else {
		fprintf(stdout, "Record updated successfully\n");
	}
    sqlite3_file_control(db, "/user/data/event/Faults.db", SQLITE_FCNTL_SYNC, NULL);
	sqlite3_close(db);
	return (0);
}


/**
 * @brief  	CMU系统故障历史事件管理
 * @param  	[in] void
 * @return 	void
 */
static void cmu_fault_history_event_manage(void)
{
	uint8_t *p_fault = NULL;
	uint16_t id;
	uint8_t i, j;
	int32_t ret;
	telematic_data_t *p_telematic_data;

	/* CMU系统故障 */
	p_telematic_data = sdk_shm_telematic_data_get();
	p_fault = p_telematic_data->CMU_system_fault_info;

	ret = memcmp(p_fault, g_cmu_fault_pre, CMU_SYSTEM_FAULT_LEN_BYTE);
	if (ret != 0)
	{
		for(i = 0; i < CMU_SYSTEM_FAULT_LEN_BYTE; i ++)
		{
			for(j = 0; j < 8; j++)
			{
				if((((p_fault[i] >> j) & 0x01) != ((g_cmu_fault_pre[i] >> j) & 0x01)))
				{
					// 存储事件
					id = (i * 8) + j + CMU_FAULT_START;
					if ((g_cmu_fault_pre[i] >> j) & 0x01)
					{
						ret = history_event_end_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d end ret %d\n", __func__, __LINE__, id,ret);
					}
					else
					{
						ret = history_event_start_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d start\n", __func__, __LINE__, id);
							
					}
				}
			}
		}
		memcpy(g_cmu_fault_pre, p_fault, CMU_SYSTEM_FAULT_LEN_BYTE);
	}
}

/**
 * @brief  	集装箱系统故障历史事件管理
 * @param  	[in] void
 * @return 	void
 */
static void container_fault_history_event_manage(void)
{
	uint8_t *p_fault = NULL;
	uint16_t id;
	uint8_t i, j;
	int32_t ret;
	telematic_data_t *p_telematic_data;

	/* 集装箱系统故障 */
	p_telematic_data = sdk_shm_telematic_data_get();
	p_fault = p_telematic_data->container_system_fault_info;
	ret = memcmp(p_fault, g_container_fault_pre, CONTAINER_SYSTEM_FAULT_LEN_BYTE);
	if (ret != 0)
	{
		for(i = 0; i < CONTAINER_SYSTEM_FAULT_LEN_BYTE; i ++)
		{
			for(j = 0; j < 8; j++)
			{
				if((((p_fault[i] >> j) & 0x01) != ((g_container_fault_pre[i] >> j) & 0x01)))
				{
					// 存储事件
					id = (i * 8) + j + CONTAINER_FAULT_START;
					if ((g_container_fault_pre[i] >> j) & 0x01)
					{
						ret = history_event_end_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d end ret %d\n", __func__, __LINE__, id,ret);
					}
					else
					{
						ret = history_event_start_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d start\n", __func__, __LINE__, id);	
					}
				}
			}
		}
		memcpy(g_container_fault_pre, p_fault, CONTAINER_SYSTEM_FAULT_LEN_BYTE);
	}
}

/**
 * @brief  	集装箱系统告警历史事件管理
 * @param  	[in] void
 * @return 	void
 */
static void container_warn_history_event_manage(void)
{
	uint8_t *p_warn = NULL;
	uint16_t id;
	uint8_t i, j;
	int32_t ret;
	telematic_data_t *p_telematic_data;

	/* 集装箱系统告警 */
	p_telematic_data = sdk_shm_telematic_data_get();
	p_warn = p_telematic_data->container_system_warn_info;
	ret = memcmp(p_warn, g_container_warn_pre, CONTAINER_SYSTEM_WARN_LEN_BYTE);
	if (ret != 0)
	{
		for(i = 0; i < CONTAINER_SYSTEM_WARN_LEN_BYTE; i ++)
		{
			for(j = 0; j < 8; j++)
			{
				if((((p_warn[i] >> j) & 0x01) != ((g_container_warn_pre[i] >> j) & 0x01)))
				{
					// 存储事件
					id = (i * 8) + j + CONTAINER_WARN_START;
					if(((id >= 0x81) && (id <= 0xAE)) || (id == 0x38))//消防一级告警
					{
						if ((g_container_warn_pre[i] >> j) & 0x01)
						{
							ret = history_event_end_write(id);
							EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d end ret %d\n", __func__, __LINE__, id,ret);
						}
						else
						{
							ret = history_event_start_write(id);
							EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d start\n", __func__, __LINE__, id);
								
						}
					}
					
				}
			}
		}
		memcpy(g_container_warn_pre, p_warn, CONTAINER_SYSTEM_WARN_LEN_BYTE);
	}
}

/**
 * @brief  	主设备历史事件管理
 * @param  	[in] void
 * @return 	void
 */
static void master_device_history_event_manage(void)
{
	static uint16_t remove_event_cmd_bak = 0;
	int32_t ret;
	other_parameter_data_t *p_parameter_data;
	int8_t path_name[HISTORY_EVENT_PATH_NAME_MAX];

	p_parameter_data = sdk_shm_other_parameter_data_get();
	if (remove_event_cmd_bak != ((p_parameter_data->privilege_ctrl_word >> 2) & 0x1))
	{
		remove_event_cmd_bak = (p_parameter_data->privilege_ctrl_word >> 2) & 0x1;

		if(remove_event_cmd_bak)	//收到新的清除事件记录的命令
		{
			snprintf((char *)path_name, sizeof(path_name), PATH_HISTORY_EVENT_RECOND_FOLDER "event");
			ret = sdk_fs_remove((const int8_t *)path_name);
			if (ret < 0)
			{
				EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] sdk_fs_remove fail, ret = %d \n", __func__, __LINE__, ret);
			}
			EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_manage---->remove '/user/data/event/event' \n", __func__, __LINE__);
			return ;
		}
	}

	/* CMU系统故障 */
	cmu_fault_history_event_manage();

	/* 集装箱系统故障 */
	container_fault_history_event_manage();

	/* 集装箱系统告警 */
	 container_warn_history_event_manage();
}

/**
 * @brief  	电池簇历史事件管理
 * @param  	[in] void
 * @return 	void
 */
static void battery_cluster_history_event_manage(void)
{
	static uint16_t remove_event_bms_cmd_bak = 0;
	battery_cluster_data_t *p_battery_cluster;
	battery_cluster_data_t *p_battery_cluster_offset;
	other_parameter_data_t *p_parameter_data;
	uint8_t *p_fault = NULL;
	uint8_t *p_warn = NULL;
	uint8_t i, j;
	int8_t path_name[HISTORY_EVENT_PATH_NAME_MAX];
	int32_t ret;
	int32_t num;
	uint16_t id;
	uint16_t start_event;
	uint16_t end_event;

	p_parameter_data = sdk_shm_other_parameter_data_get();
	if (remove_event_bms_cmd_bak != ((p_parameter_data->privilege_ctrl_word >> 2) & 0x1))
	{
		remove_event_bms_cmd_bak = (p_parameter_data->privilege_ctrl_word >> 2) & 0x1;

		if(remove_event_bms_cmd_bak)	//收到新的清除事件记录的命令
		{
			for (i = 1; i < (BCU_DEVICE_NUM + 1); i++)
			{
				snprintf((char *)path_name, sizeof(path_name), PATH_HISTORY_EVENT_RECOND_FOLDER "event_bms%02d", i);
				ret = sdk_fs_remove((const int8_t *)path_name);
				if (ret < 0)
				{
					EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] sdk_fs_remove fail, ret = %d \n", __func__, __LINE__, ret);
				}
				EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_manage---->remove '/user/data/event/event_bms%02d' \n", __func__, __LINE__, i);
			}
			return ;
		}
	}

	p_battery_cluster = battery_cluster_data_get();
	for (num = 0; num < BCU_DEVICE_NUM; num++)	// BCU_DEVICE_NUM个电池簇都需要遍历
	{
		p_battery_cluster_offset = p_battery_cluster + num;

		/* 电池簇故障 */
		p_fault = p_battery_cluster_offset->battery_cluster_fault_info;
		ret = memcmp(p_fault, g_battery_cluster_fault_pre[num], BATTERY_CLUSTER_FAULT_LEN_BYTE);
		if (ret != 0)
		{
			for (i = 0; i < BATTERY_CLUSTER_FAULT_LEN_BYTE; i++)
			{
				for (j = 0; j < 8; j++)
				{
					if ((((p_fault[i] >> j) & 0x01) != ((g_battery_cluster_fault_pre[num][i] >> j) & 0x01)))
					{
						// 存储事件
						id = (i * 8) + j + BATTERY_CLUSTER_1_FAULT_START + (num * BATTERY_CLUSTER_INTERVAL);
						if ((g_battery_cluster_fault_pre[num][i] >> j) & 0x01)
						{
							ret = history_event_end_write(id);
							EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d end ret %d\n", __func__, __LINE__, id,ret);
						}
						else
						{
							ret = history_event_start_write(id);
							EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d start\n", __func__, __LINE__, id);
						}
					}
				}
			}
			memcpy(g_battery_cluster_fault_pre[num], p_fault, BATTERY_CLUSTER_FAULT_LEN_BYTE);
		}

		/* 电池簇告警 */
		p_warn = p_battery_cluster_offset->battery_cluster_warn_info;
		ret = memcmp(p_warn, g_battery_cluster_warn_pre[num], BATTERY_CLUSTER_WARN_LEN_BYTE);
		if (ret != 0)
		{
			for (i = 0; i < BATTERY_CLUSTER_WARN_LEN_BYTE; i++)
			{
				for (j = 0; j < 8; j++)
				{
					if ((((p_warn[i] >> j) & 0x01) != ((g_battery_cluster_warn_pre[num][i] >> j) & 0x01)))
					{
						// 存储事件
						id = (i * 8) + j + BATTERY_CLUSTER_1_WARN_START + (num * BATTERY_CLUSTER_INTERVAL);
						start_event = BATTERY_CLUSTER_1_WARN3_START + (num * BATTERY_CLUSTER_INTERVAL);
						end_event = BATTERY_CLUSTER_1_WARN3_END + (num * BATTERY_CLUSTER_INTERVAL);
						if (id >=  start_event && id <= end_event)
						{
							if ((g_battery_cluster_warn_pre[num][i] >> j) & 0x01)
							{
								ret = history_event_end_write(id);
								EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d end ret %d\n", __func__, __LINE__, id,ret);
							}
							else
							{
								ret = history_event_start_write(id);
								EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d start\n", __func__, __LINE__, id);
							}
						}
					}
				}
			}
			memcpy(g_battery_cluster_warn_pre[num], p_warn, BATTERY_CLUSTER_WARN_LEN_BYTE);
		}
	}
}


/**
 * @brief  	PCS历史事件管理
 * @param  	[in] void
 * @return 	void
 */
static void pcs_history_event_manage(void)
{
	static uint16_t remove_event_cmd_bak = 0;
	other_parameter_data_t *p_parameter_data;
	uint8_t i = 0;
	int8_t path_name[HISTORY_EVENT_PATH_NAME_MAX];
	int32_t ret;
	int32_t num;
	uint16_t id;
	telematic_data_t *p_telematic_data;
	pcs_telematic_info_t *p_pcs_module = NULL;
	pcs_telematic_info_t  pcs_module = {0};
	p_telematic_data = sdk_shm_telematic_data_get();

	p_parameter_data = sdk_shm_other_parameter_data_get();
	if (remove_event_cmd_bak != ((p_parameter_data->privilege_ctrl_word >> 2) & 0x1))
	{
		remove_event_cmd_bak = (p_parameter_data->privilege_ctrl_word >> 2) & 0x1;

		if(remove_event_cmd_bak)	//收到新的清除事件记录的命令
		{
			snprintf((char *)path_name, sizeof(path_name), PATH_HISTORY_EVENT_RECOND_FOLDER "event");
			ret = sdk_fs_remove((const int8_t *)path_name);
			if (ret < 0)
			{
				EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] sdk_fs_remove fail, ret = %d \n", __func__, __LINE__, ret);
			}
			EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_manage---->remove '/user/data/event/event' \n", __func__, __LINE__);
			return ;
		}
	}

	/* PCS模块故障 */
	for (num = 0; num < PCS_CABINET_POWER_MODULE_NUM; ++num)
	{
		//test
		//memset(&p_telematic_data->pcs_module[0],65535,sizeof(telematic_info_t));
		
		p_pcs_module = &p_telematic_data->pcs_module[num];
		
		memcpy(&pcs_module,p_pcs_module,sizeof(pcs_telematic_info_t));
		
		ret = memcmp(&pcs_module.grid_fault , &g_pcs_module[num].grid_fault, 2);
		if (0 != ret)
		{
			for(i = 0; i < 16; i ++)
			{
				if((((pcs_module.grid_fault.val >> i) & 0x0001) ) != ((g_pcs_module[num].grid_fault.val >> i) & 0x0001))
				{
				//存储事件
					id = GRID_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT + (num * PCSMODULE_CLUSTER_FAULT_LEN);
					if ((g_pcs_module[num].grid_fault.val >> i) & 0x0001)
					{
						ret = history_event_end_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d end ret %d\n", __func__, __LINE__, id,ret);
					}
					else
					{
						ret = history_event_start_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d start\n", __func__, __LINE__, id);
					}
				}
			}
				
			memcpy(&g_pcs_module[num] ,&pcs_module, 2);

		}

		ret = memcmp(&pcs_module.sampling_fault , &g_pcs_module[num].sampling_fault, 2);

		if (0 != ret)
		{
			for(i = 0; i < 16; i ++)
			{
				
				if(((pcs_module.sampling_fault.val >> i) & 0x0001) != ((g_pcs_module[num].sampling_fault.val >> i) & 0x0001))
				{
					//存储事件
					id = SAMPLING_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT + (num * PCSMODULE_CLUSTER_FAULT_LEN);
					if ((g_pcs_module[num].sampling_fault.val >> i) & 0x0001)
					{
						ret = history_event_end_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d end ret %d\n", __func__, __LINE__, id,ret);
					}
					else
					{
						ret = history_event_start_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d start\n", __func__, __LINE__, id);
					}
				}			
			}
		}

		ret = memcmp(&pcs_module.self_test_fault , &g_pcs_module[num].self_test_fault, 2);
		if (0 != ret)
		{
			for(i = 0; i < 16; i ++)
			{
				if((((pcs_module.self_test_fault.val >> i) & 0x0001)) != ((g_pcs_module[num].self_test_fault.val >> i) & 0x0001))
				{
					//存储事件
					id = SELF_TEST_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT + (num * PCSMODULE_CLUSTER_FAULT_LEN);
					if ((g_pcs_module[num].self_test_fault.val >> i) & 0x0001)
					{
						ret = history_event_end_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d end ret %d\n", __func__, __LINE__, id,ret);
					}
					else
					{
						ret = history_event_start_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d start\n", __func__, __LINE__, id);
					}
				}			
			}
		}

		ret = memcmp(&pcs_module.temperature_fault , &g_pcs_module[num].temperature_fault, 2);
		if (0 != ret)
		{
			for(i = 0; i < 16; i ++)
			{
		
				if((((pcs_module.temperature_fault.val >> i) & 0x0001)) != ((g_pcs_module[num].temperature_fault.val >> i) & 0x0001))
				{
						//存储事件
					id = TEMP_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT + (num * PCSMODULE_CLUSTER_FAULT_LEN);
					if ((g_pcs_module[num].temperature_fault.val >> i) & 0x0001)
					{
						ret = history_event_end_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d end ret %d\n", __func__, __LINE__, id,ret);
					}
					else
					{
						ret = history_event_start_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d start\n", __func__, __LINE__, id);
					}
				}			
			}
		}


		ret = memcmp(&pcs_module.voltage_fault , &g_pcs_module[num].voltage_fault, 2);
		if (0 != ret)
		{
			for(i = 0; i < 16; i ++)
			{
				if((((pcs_module.voltage_fault.val >> i) & 0x0001)) != ((g_pcs_module[num].voltage_fault.val >> i) & 0x0001))
				{
					
					//存储事件
					id = VOLT_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT + (num * PCSMODULE_CLUSTER_FAULT_LEN);
					if ((g_pcs_module[num].voltage_fault.val >> i) & 0x0001)
					{
						ret = history_event_end_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d end ret %d\n", __func__, __LINE__, id,ret);
					}
					else
					{
						ret = history_event_start_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d start\n", __func__, __LINE__, id);
					}						
				}			
			}
		}		

		ret = memcmp(&pcs_module.current_fault , &g_pcs_module[num].current_fault, 2);
		if (0 != ret)
		{
			for(i = 0; i < 16; i ++)
			{
				if((((pcs_module.current_fault.val >> i) & 0x0001)) != ((g_pcs_module[num].current_fault.val >> i) & 0x0001))
				{
					//存储事件
					id = CURRENT_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT + (num * PCSMODULE_CLUSTER_FAULT_LEN);
					if ((g_pcs_module[num].current_fault.val >> i) & 0x0001)
					{
						ret = history_event_end_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d end ret %d\n", __func__, __LINE__, id,ret);
					}
					else
					{
						ret = history_event_start_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d start\n", __func__, __LINE__, id);
					}						
				}			
			}
		}	

		ret = memcmp(&pcs_module.hardware_signal_fault , &g_pcs_module[num].hardware_signal_fault, 2);
		if (0 != ret)
		{
			for(i = 0; i < 16; i ++)
			{
				if((((pcs_module.hardware_signal_fault.val >> i) & 0x0001) ) != ((g_pcs_module[num].hardware_signal_fault.val >> i) & 0x0001))
				{
					//存储事件
					id = HWSIGNAL_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT + (num * PCSMODULE_CLUSTER_FAULT_LEN);
					if ((g_pcs_module[num].hardware_signal_fault.val >> i) & 0x0001)
					{
						ret = history_event_end_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d end ret %d\n", __func__, __LINE__, id,ret);
					}
					else
					{
						ret = history_event_start_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d start\n", __func__, __LINE__, id);
					}						
				}		
			}
		}	
	
		ret = memcmp(&pcs_module.control_fault , &g_pcs_module[num].control_fault, 2);
		if (0 != ret)
		{
			for(i = 0; i < 16; i ++)
			{
				if((((pcs_module.control_fault.val >> i) & 0x0001) ) != ((g_pcs_module[num].control_fault.val >> i) & 0x0001))
				{
					//存储事件
					id = CONTROL_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT + (num * PCSMODULE_CLUSTER_FAULT_LEN);
					if ((g_pcs_module[num].control_fault.val >> i) & 0x0001)
					{
						ret = history_event_end_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d end ret %d\n", __func__, __LINE__, id,ret);
					}
					else
					{
						ret = history_event_start_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d start\n", __func__, __LINE__, id);
					}		
				}			
			}
		}	

		ret = memcmp(&pcs_module.communication_fault, &g_pcs_module[num].communication_fault, 2);
		if (0 != ret)
		{
			for(i = 0; i < 16; i ++)
			{
				if((((pcs_module.communication_fault.val >> i) & 0x0001)) != ((g_pcs_module[num].communication_fault.val >> i) & 0x0001))
				{
					//存储事件
					id = COMM_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT + (num * PCSMODULE_CLUSTER_FAULT_LEN);
					if ((g_pcs_module[num].communication_fault.val >> i) & 0x0001)
					{
						ret = history_event_end_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d end ret %d\n", __func__, __LINE__, id,ret);
					}
					else
					{
						ret = history_event_start_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d start\n", __func__, __LINE__, id);
					}				
				}			
			}
		}

		ret = memcmp(&pcs_module.supplement_fault , &g_pcs_module[num].supplement_fault, 2);
		if (0 != ret)
		{
			for(i = 0; i < 16; i ++)
			{
				if((((pcs_module.supplement_fault.val >> i) & 0x0001)) != ((g_pcs_module[num].supplement_fault.val >> i) & 0x0001))
				{
					//存储事件
					id = SUPPLEEMENT_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT + (num * PCSMODULE_CLUSTER_FAULT_LEN);
					if ((g_pcs_module[num].supplement_fault.val >> i) & 0x0001)
					{
						ret = history_event_end_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d end ret %d\n", __func__, __LINE__, id,ret);
					}
					else
					{
						ret = history_event_start_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d start\n", __func__, __LINE__, id);
					}		
				}			
			}
		}	


		ret = memcmp(&pcs_module.external_device_fault , &g_pcs_module[num].external_device_fault, 2);
		if (0 != ret)
		{
			for(i = 0; i < 16; i ++)
			{
				if((((pcs_module.external_device_fault.val >> i) & 0x0001)) != ((g_pcs_module[num].external_device_fault.val >> i) & 0x0001))
				{
					//存储事件
					id = DEVICE_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT + (num * PCSMODULE_CLUSTER_FAULT_LEN);
					if ((g_pcs_module[num].external_device_fault.val >> i) & 0x0001)
					{
						ret = history_event_end_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d end ret %d\n", __func__, __LINE__, id,ret);
					}
					else
					{
						ret = history_event_start_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d start\n", __func__, __LINE__, id);
					}	
				}			
			}
		}	


		ret = memcmp(&pcs_module.warn_info , &g_pcs_module[num].warn_info, 2);
		if (0 != ret)
		{
			for(i = 0; i < 16; i ++)
			{
				if((((pcs_module.warn_info.val >> i) & 0x0001)) != ((g_pcs_module[num].warn_info.val >> i) & 0x0001))
				{
					//存储事件
					id = WARN_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT + (num * PCSMODULE_CLUSTER_FAULT_LEN);
					if ((g_pcs_module[num].warn_info.val >> i) & 0x0001)
					{
						ret = history_event_end_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d end ret %d\n", __func__, __LINE__, id,ret);
					}
					else
					{
						ret = history_event_start_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d start\n", __func__, __LINE__, id);
					}	
				}			
			}
		}	

		ret = memcmp(&pcs_module.state6 , &g_pcs_module[num].state6, 2);
		if (0 != ret)
		{
			for(i = 0; i < 16; i ++)
			{
				if((((pcs_module.state6.val >> i) & 0x0001)) != ((g_pcs_module[num].state6.val >> i) & 0x0001))
				{
					//存储事件
					id = STATE6_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT + (num * PCSMODULE_CLUSTER_FAULT_LEN);
					if ((g_pcs_module[num].state6.val >> i) & 0x0001)
					{
						ret = history_event_end_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d end ret %d\n", __func__, __LINE__, id,ret);
					}
					else
					{
						ret = history_event_start_write(id);
						EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d start\n", __func__, __LINE__, id);
					}				
				}			
			}
		}	

		memcpy(&g_pcs_module[num].sampling_fault ,&pcs_module.sampling_fault,sizeof(pcs_telematic_info_t) - 2 );
		
	}
}

/**
 * @brief  	历史事件存储，当事件id状态0->1时产生一个故障记录
 * @param  	[in] void
 * @return 	void
 */
static void history_event_manage(void)
{
	master_device_history_event_manage();
	battery_cluster_history_event_manage();
	pcs_history_event_manage();
}


/* Create the table if it doesn't exist */
int32_t sqlite_db_create_table(void) 
{
    char *err_msg = 0;
	int rc = 0;
    sqlite3 *db;
	char *sql_Faults = "CREATE TABLE IF NOT EXISTS Faults("  \
            "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
            "FAULTID         INT    NOT NULL," \
            "STARTTIME       TEXT   NOT NULL," \
            "ENDTIME         TEXT   NOT NULL);";

	char *sql_info = "CREATE TABLE IF NOT EXISTS FaultInfo("  \
            "FAULTID         INT    NOT NULL," \
            "FaultName       TEXT   NOT NULL," \
            "Reason      	 TEXT," \
            "Suggestion      TEXT," \
            "FaultGrade      TEXT);";
	
	char *sql_trigger = "CREATE TRIGGER limit_rows AFTER INSERT ON Faults "
						"BEGIN "
							"DELETE FROM Faults WHERE ID IN ("
								"SELECT ID FROM Faults "
								"ORDER BY ID ASC "
								"LIMIT (SELECT CASE WHEN (SELECT COUNT(*) FROM Faults) > 5000 THEN 1 ELSE 0 END)"
							"); "
						"END;";
	
    rc = sqlite3_open(FAULT_DB_PATH, &db);
    if( rc ) {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return(0);
    }

    rc = sqlite3_exec(db, sql_Faults, 0, 0, &err_msg);
    if (rc != SQLITE_OK) {
        fprintf(stderr, "Failed to create table: %s\n", err_msg);
        sqlite3_free(err_msg);
    }

    rc = sqlite3_exec(db, sql_info, 0, 0, &err_msg);
    if (rc != SQLITE_OK) {
        fprintf(stderr, "Failed to create table: %s\n", err_msg);
        sqlite3_free(err_msg);
    }

	rc = sqlite3_exec(db, sql_trigger, 0, 0, &err_msg);
	if (rc != SQLITE_OK) {
		fprintf(stderr, "SQL error: %s\n", err_msg);
		sqlite3_free(err_msg);
	} else {
		fprintf(stdout, "Trigger created successfully\n");
	}
	
	sqlite3_close(db);
	return(1);
}

/**
 * @brief  	恢复所有未结束的故障列表
 * @param  	[in] void
 * @return 	void
 */
void history_event_list_reset(void)
{
    sqlite3 *db = NULL;
    char *err_msg = NULL;
    int rc = 0;
	sdk_rtc_t rtc_time = {0};
    char current_date[32] = {0};
    char sql[256] = {0};
    int32_t ret = 0;
		
	ret = sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
	if (ret != SDK_OK)
    {
		return;
    }	
    sprintf(current_date, "%04d-%02d-%02d %02d:%02d:%02d", 2000 + rtc_time.tm_year,rtc_time.tm_mon, rtc_time.tm_day, rtc_time.tm_hour, rtc_time.tm_min, rtc_time.tm_sec);
    sprintf(sql, "UPDATE Faults SET ENDTIME = REPLACE(ENDTIME, '1970-00-00 00:00:00', '%s') WHERE ENDTIME LIKE '%%1970-00-00 00:00:00%%';", current_date);

    rc = sqlite3_open(FAULT_DB_PATH, &db);
    if (rc != SQLITE_OK) 
    {
        fprintf(stderr, "Cannot open database: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return;
    }
 
    rc = sqlite3_exec(db, sql, NULL, NULL, &err_msg);
    if (rc != SQLITE_OK) 
    {
        fprintf(stderr, "SQL error: %s\n", err_msg);
        sqlite3_free(err_msg);
        sqlite3_close(db);
        return;
    }
 
    sqlite3_close(db);
}


/** 
 * @brief   历史事件线程（用于记录故障及告警事件的信息存储）
 * @param
 * @return 	void
 */
void *thread_history_event(void *arg)
{
	int32_t ret = 0;
	
	ret = sdk_fs_access((const int8_t *)PATH_HISTORY_EVENT_RECOND_FOLDER, F_OK);
    if (ret == -1)  // 文件夹不存在，创建该文件夹
    {
        EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] /user/data/event/ Folder does not exist!!! \n", __func__, __LINE__);
        ret = sdk_fs_mkdir((const char *)PATH_HISTORY_EVENT_RECOND_FOLDER, 755);
        if (ret < 0)
        {
            log_i((int8_t *)"\n [%s:%d] sdk_fs_mkdir fail, ret = %d \n", __func__, __LINE__, ret);
        }
    }	
    //判断文件是否存在,如果文件不存在就进行创建
	ret = sdk_fs_access((const int8_t *)FAULT_DB_PATH, F_OK);
    if (ret == -1)  // 文件不存在，创建该文件
    {
		sqlite_db_create_table();
    }

    //此处遍历所有的故障信息，如果存在未结束故障则手动恢复
    history_event_list_reset();
		
    while (1)
    {
        history_event_manage();
        sleep(1); // sdk_delay_ms(1000);	// 1s
    }
    
    pthread_exit(NULL);
}

