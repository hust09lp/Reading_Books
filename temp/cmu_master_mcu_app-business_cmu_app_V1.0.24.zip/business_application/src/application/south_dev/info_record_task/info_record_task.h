#ifndef __INFO_RECORD_TASK_H__
#define __INFO_RECORD_TASK_H__

#include "data_types.h"
#include "data_shm.h"



/** 
 * @brief   信息记录任务启动
 * @param
 * @return
 */
void info_record_task_start(void);

#endif  /* __INFO_RECORD_TASK_H__ */
