#include "info_record_task.h"
#include "param_record_task.h"
#include "operating_record_task.h"
#include "operating_pcs_record_task.h"
#include "energy_record_task.h"
#include "power_record_task.h"
#include "event_record_task.h"
#include "sdk_public.h"
#include "sofar_log.h"
#include <pthread.h>
#include <unistd.h>


/** 
 * @brief   信息记录线程 信息存储
 * @param
 * @return
 */
void *thread_info_record(void *arg)
{
    while (1)
    {
        app_param_comparison();

        sleep(1);	// 1s
    }
    
    pthread_exit(NULL);
}

/** 
 * @brief   信息记录任务启动（用于信息存储，包括运行数据、故障录波数据、设备参数等）
 * @param
 * @return
 */
void info_record_task_start(void)
{
    int16_t ret = 0;
    pthread_attr_t info_record_attr;
    pthread_t info_record;

    // 初始化线程属性
    ret = pthread_attr_init(&info_record_attr);
    if (ret)
    {
        log_e((int8_t *)"\n [%s:%d] pthread_attr_init error!!! \n", __func__, __LINE__);
        return; // 线程属性初始化出错退出
    }
    
    // 设置线程属性为分离状态
    ret = pthread_attr_setdetachstate(&info_record_attr, PTHREAD_CREATE_DETACHED);
    if (ret)
    {
        log_e((int8_t *)"\n [%s:%d] pthread_attr_setdetachstate info_record_attr error!!! \n", __func__, __LINE__);
        return; // 线程分离属性设置出错退出
    }

    ret = pthread_create(&info_record, &info_record_attr, &thread_info_record, NULL);
    if (ret)
    {
        log_e((int8_t *)"\n [%s:%d] pthread_create info_record error!!! \n", __func__, __LINE__);
        return; // 线程创建出错退出
    }
	
    // 历史电量线程
    pthread_t history_energy;
    ret = pthread_create(&history_energy, &info_record_attr, &thread_history_energy, NULL);
    if (ret)
    {
        log_e((int8_t *)"\n [%s:%d] pthread_create history_energy error!!! \n", __func__, __LINE__);
        return; // 线程创建出错退出
    }

    // 历史功率线程
    pthread_t history_power;
    ret = pthread_create(&history_power, &info_record_attr, &thread_history_power, NULL);
    if (ret)
    {
        log_e((int8_t *)"\n [%s:%d] pthread_create history_power error!!! \n", __func__, __LINE__);
        return; // 线程创建出错退出
    }

    // 历史事件线程
    pthread_t history_event;
    ret = pthread_create(&history_event, &info_record_attr, &thread_history_event, NULL);
    if (ret)
    {
        log_e((int8_t *)"\n [%s:%d] pthread_create history_event error!!! \n", __func__, __LINE__);
        return; // 线程创建出错退出
    }

    // 运行记录线程
    pthread_t operating_record;
    ret = pthread_create(&operating_record, &info_record_attr, &thread_operating_record, NULL);
    if (ret)
    {
        log_e((int8_t *)"\n [%s:%d] pthread_create operating_record error!!! \n", __func__, __LINE__);
        return; // 线程创建出错退出
    }

    // 运行PCS记录线程
    pthread_t pcs_operating_record;
    ret = pthread_create(&pcs_operating_record, &info_record_attr, &thread_operating_pcs_record, NULL);
    if (ret)
    {
        log_e((int8_t *)"\n [%s:%d] pthread_create pcs_operating_record error!!! \n", __func__, __LINE__);
        return; // 线程创建出错退出
    }

    // 销毁线程属性结构,它在重新初始化之前不能重新使用
    pthread_attr_destroy(&info_record_attr);
}
