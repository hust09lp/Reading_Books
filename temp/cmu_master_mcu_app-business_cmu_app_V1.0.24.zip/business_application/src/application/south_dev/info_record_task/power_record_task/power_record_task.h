#ifndef __POWER_RECORD_TASK_H__
#define __POWER_RECORD_TASK_H__

#include "data_types.h"

#define HISTORY_YEAR_START           (2023)

#define DISPLAY_ACCURACY             (5)        // 显示精度 10min一次

// 时间变化类型
#define POWER_YEAR_CHANGE				    5
#define POWER_MONTH_CHANGE					4
#define POWER_DAY_CHANGE					3
#define POWER_HOUR_CHANGE					2
#define POWER_SOME_MINS_CHANGE              1
#define POWER_NO_CHANGE						0

// 打印开关
#if (0)
#define POWER_DEBUG_LOG(...) log_i((const int8_t*)__VA_ARGS__);
#else
#define POWER_DEBUG_LOG(...) {do {} while(0);}
#endif

// 功率时间类型
typedef enum{
    POWER_TIMETYPE_MINS = 1,    // n分钟
	POWER_TIMETYPE_HOUR,	    // 历史小时功率
	POWER_TIMETYPE_DAY,		    // 日
	POWER_TIMETYPE_MONTH,		// 月
	POWER_TIMETYPE_YEAR,		// 年
}power_timetype_e;

typedef enum
{
    POWER_CHARGE_DIS = 1,
    POWER_DATATYPE_MAX,
}power_datatype_e;

#pragma pack(push)
#pragma pack(1)
typedef struct
{
    int16_t year;	// 年份，如2023
    int16_t month;	// 月份，1~12
    int16_t date;	// 日期，1~31
	int16_t hour;	// 小时，0~23
    int16_t minute;
	int16_t second;
    // int16_t weekday; // 1~7
}power_time_t;
#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)
typedef struct
{
    double charge_dis_power;       // PCS充放电功率
}power_data_t;
#pragma pack(pop)

typedef struct
{
    power_time_t now_time;              // 当前时间
    power_time_t last_time;             // 上一次保存时间
    power_data_t real_power;            // 实时功率
}power_record_task_t;


/**
 * @brief  历史功率读取函数
 * @param  [in] p_time 要读取的时间
 * @param  [out] p_buf 读取数据所存放的buf首地址
 * @param  [in] buf_size 传入buf大小
 * @param  [in] time_type 读取的时间类型（1~4）,见power_timetype_e
 * @param  [in] energy_type 读取的功率类型(1)，见power_datatype_e
 * @return 读取结果 >=0：实际读取到的数据个数  -1：失败/异常
 */
int32_t history_power_read(power_time_t *p_time, int16_t *p_buf, uint16_t buf_size, uint8_t time_type, uint8_t energy_type);


/**
 * @brief  功率记录线程（用于充放电功率存储）
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
void *thread_history_power(void *arg);

#endif
