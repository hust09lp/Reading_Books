#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <time.h>
#include <pthread.h>
#include <sys/stat.h>
#include "sqlite3.h"
#include "power_record_task.h"
#include "data_shm.h"
#include "sofar_log.h"
#include "sdk_fs.h"
#include "sdk_public.h"
#include "sofar_errors.h"
#include "sdk_shm.h"

#define PATH_POWER_GENERAL_DIR	 "/user/data/power/"			// 功率存储总目录

#define MINS_NUM_PER_HOUR               (60)                    // 一小时60分钟
#define HOURS_NUM_PER_DAY				(24)					// 一天24小时

power_record_task_t g_power_record_task;

static void power_record_init(void);


/**
 * @brief  创建数据库
 * @param  [in] 
 * @param  [in]
 * @param  [out]
 * @return 
 *
* Create the table if it doesn't exist */
static void create_energy_table(void)
{
    sqlite3 *db;
    char *sql = "CREATE TABLE IF NOT EXISTS power_data (date TEXT PRIMARY KEY, power REAL);";
    char *err_msg = 0;
    int rc = 0;
    char db_name[512] = {0};
    sdk_rtc_t now;

    sdk_rtc_get(RTC_BIN_FORMAT, &now);

    sprintf(db_name, "%s%s-%d%s",PATH_POWER_GENERAL_DIR, "power", now.tm_year, ".db");
    
    rc = sqlite3_open(db_name, &db);
    if( rc ) {
        POWER_DEBUG_LOG((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
        return;
    }
 
    rc = sqlite3_exec(db, sql, 0, 0, &err_msg);
    if (rc != SQLITE_OK) {
        POWER_DEBUG_LOG((int8_t *)"Failed to create table: %s\n", err_msg);
        sqlite3_free(err_msg);
    }
 
    sqlite3_close(db);
}

/**
 * @brief  检查功率曲线数据库文件是否存在和有效
 * @param  [in] none
 * @param  [out] none
 * @return 0-数据库文件正常   -1-数据库文件异常
 */
static int32_t power_db_file_check(char* file_nane)
{
	int32_t ret = -1;
	struct stat file_stat;
	
	
    ret = sdk_fs_access((const int8_t *)file_nane, F_OK);
    if (ret == -1)  // 文件不存在，创建该文件
    {
		create_energy_table();
		return (0);
    }
	else     // 文件存在，检查文件大小是否为0
	{
        ret = stat((const char *)file_nane,&file_stat);
        if(ret != SF_OK)
        {
            create_energy_table();
		    return (0);
        }
        else
        {
            if(file_stat.st_size == 0)
            {
                sdk_fs_remove((const int8_t *)file_nane);
                create_energy_table();
            }
        }
		// p_fs = sdk_fs_open((const int8_t *)file_nane,FS_READ);
		// if ( p_fs != NULL)
		// {
		// 	ret = sdk_fs_get_size(p_fs);
		// 	sdk_fs_close(p_fs);
		// 	if (ret == 0)
		// 	{
		// 		sdk_fs_remove((const int8_t *)file_nane);
		// 		create_energy_table();
		// 	}
		// }
		// else 
		// {
		// 	return (-1);
		// }
	}
	return (0);
}

/**
 * @brief  更新数据库充放电量
 * @param  [in] date 日期(2023-07-11 10:00:00)
 * @param  [in] charge 充电量
 * @param  [in] discharge 放电量
 * @return 0失败 1成功
 */
static int32_t sqlite_db_update_data(uint8_t *date, double power)
{
    sqlite3 *db;
    int32_t rc;
    int32_t ret;
    int32_t retry_count=0;
    char db_name[512] = {0};
    sdk_rtc_t now;

    ret = sdk_rtc_get(RTC_BIN_FORMAT, &now);
    sprintf(db_name, "%s%s-%d%s",PATH_POWER_GENERAL_DIR, "power", now.tm_year, ".db");
 

    printf("[%s %d date %s %lf]\n", __func__, __LINE__,date,power);
    power_db_file_check(db_name);
    rc = sqlite3_open(db_name, &db);
    if( rc ) {
       POWER_DEBUG_LOG((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
       return(0);
    } else {
        char *sql = "INSERT OR REPLACE INTO power_data (date, power) VALUES (?, ?);";
        sqlite3_stmt *stmt;
        sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
        sqlite3_bind_text(stmt, 1, (const char*)date, -1, SQLITE_STATIC);
        sqlite3_bind_double(stmt, 2, power);
 
        //printf( "sqlite3_step ret%d \n",sqlite3_step(stmt));
        while ((SQLITE_DONE != (ret = sqlite3_step(stmt))) && (retry_count < 5))
        {
            retry_count++;
            printf( "sqlite3_step err ret = %d \n",ret);
            usleep(1000);
        }
        
        sqlite3_finalize(stmt);
    }
    sqlite3_file_control(db, db_name, SQLITE_FCNTL_SYNC, NULL);
    sqlite3_close(db);    

    return(1);
}



/**
 * @brief  历史功率存储函数
 * @param  [in] p_task 功率存储任务结构体指针
 * @param  [in] time_type 存储的时间类型（1~4）
 * @param  [out] none
 * @return 存储结果 0：成功  -1：失败/异常
 */
int32_t history_power_record(power_record_task_t *p_task, uint8_t time_type)
{
    power_time_t *p_time = NULL;
    uint8_t date[32] = {0};

    if (NULL == p_task)
    {
        return -1;
    }

    p_time = &p_task->now_time;

    if (NULL == p_time)
    {
        return -1;
    }

    if (time_type == POWER_YEAR_CHANGE)
    {
        power_record_init();                 // 已更新last_time
        return -1;
    }

    // 目录不存在，重新初始化
	if ((sdk_fs_access((const int8_t *)PATH_POWER_GENERAL_DIR, FS_F_OK)) == -1)
	{
        power_record_init();                // 已更新last_time

        return -1;
    }

    // 只按分钟变化存储
 
    snprintf((char*)date, sizeof(date),"%04d-%02d-%02d %02d:%02d:00",p_time->year,\
                    p_time->month, p_time->date, p_time->hour, p_time->minute);
    sqlite_db_update_data(date, g_power_record_task.real_power.charge_dis_power);
    

    return 0;
}

/**
 * @brief  获取实时功率数据
 * @param  [in] none
 * @param  [out] none
 * @return 获取结果 0：成功  -1：失败
 */
int32_t get_realtime_power(void)
{
    power_record_task_t *p_task = NULL;
    power_module_telemetry_info_t *module_info = NULL;

    p_task = &g_power_record_task;
    telemetry_data_t *pcs_telemetry_data = sdk_shm_pcs_telemetry_data_get();
    module_info = &pcs_telemetry_data->power_module_telemetry_info[0];

    p_task->real_power.charge_dis_power = module_info->active_power / 100.0;
    POWER_DEBUG_LOG((int8_t *)"\n[get_realtime_power] p_task->real_power.charge_dis_power = %d\n", p_task->real_power.charge_dis_power);

    return 0;
}

/**
 * @brief  获取当前时间
 * @param  [in] none
 * @param  [out] none
 * @return 返回当前时间结构体变量
 */
power_time_t get_date_time(void)
{
    int32_t ret = 0;
    sdk_rtc_t now;
    power_time_t current = {0, 0, 0, 0, 0, 0};

    POWER_DEBUG_LOG((int8_t *)"[get_date_time] sdk_rtc_get before!\n");
    ret = sdk_rtc_get(RTC_BIN_FORMAT, &now);
    POWER_DEBUG_LOG((int8_t *)"[get_date_time] sdk_rtc_get over!\n");

    if (ret != 0)
    {
        return current;
    }

    current.year = (uint16_t)now.tm_year + 2000;
    current.month = (uint16_t)now.tm_mon;
    current.date = (uint16_t)now.tm_day;
    current.hour = (uint16_t)now.tm_hour;
    current.minute = (uint16_t)now.tm_min;
    current.second = (uint16_t)now.tm_sec;
    // current.weekday = (uint16_t)now.tm_weekday;
    POWER_DEBUG_LOG((int8_t *)"\n[get_date_time] Time_get is: %04d.%02d.%02d %02d:%02d:%02d\r\n\n", current.year, \
                                current.month, current.date, current.hour, current.minute, current.second);

    return current;
}

/**
 * @brief  将sdk_rtc_t结构体时间转换成时间戳（秒）
 * @param  [in] p_time sdk_rtc_t结构体时间
 * @param  [out] p_timestamp 时间戳（秒）
 * @return 执行结果  0：成功 -1：失败
 */
static int32_t date_time_to_timestamp(power_time_t *p_time, time_t *p_timestamp)
{
    struct tm data;

    if ((p_time == NULL) || (p_timestamp == NULL))
    {
        POWER_DEBUG_LOG("\n[date_time_to_timestamp] [%s:%d] null pointer! \n", __func__, __LINE__);
        return -1;
    }

    memset(&data, 0, sizeof(data));

    data.tm_year = (int32_t)(p_time->year - 1900);
    data.tm_mon  = (int32_t)(p_time->month - 1);
    data.tm_mday = (int32_t)(p_time->date);
    data.tm_hour = (int32_t)(p_time->hour);
    data.tm_min  = (int32_t)(p_time->minute);
    data.tm_sec  = (int32_t)(p_time->second);

    *p_timestamp = mktime(&data) - 8 * 60 *60;

    return 0;
}

/**
 * @brief  时间变化判断函数
 * @param  [in] updatetime 更新时的时间
 * @param  [in] lastsavetime 上一次保存的时间
 * @param  [out] none
 * @return 时间变化类型
 */
static uint8_t get_time_change(power_time_t updatetime, power_time_t lastsavetime)
{
    int32_t ret = 0;
    time_t now_stamp = 0;
    time_t last_stamp = 0;

    ret = date_time_to_timestamp(&updatetime, &now_stamp);
    if (ret != 0)
    {
        return POWER_NO_CHANGE;
    }

    ret = date_time_to_timestamp(&lastsavetime, &last_stamp);
    if (ret != 0)
    {
        return POWER_NO_CHANGE;
    }

    POWER_DEBUG_LOG((int8_t *)"[get_time_change] now_stamp  = %d\n", now_stamp);
    POWER_DEBUG_LOG((int8_t *)"[get_time_change] last_stamp = %d\n", last_stamp);
    POWER_DEBUG_LOG((int8_t *)"[get_time_change] now_stamp - last_stamp = %ds \n", now_stamp - last_stamp);

	if (updatetime.year < HISTORY_YEAR_START)	// 年限不合理，不进行功率记录
	{
		return POWER_NO_CHANGE;
	}
 
	if (lastsavetime.year != updatetime.year)
	{
		return POWER_YEAR_CHANGE;
	}
	if (lastsavetime.month != updatetime.month)
	{
		return POWER_MONTH_CHANGE;
	}
	if (lastsavetime.date != updatetime.date)
	{
		return POWER_DAY_CHANGE;
	}
	if (lastsavetime.hour != updatetime.hour)
	{
		return POWER_HOUR_CHANGE;
	}
    if (lastsavetime.minute != updatetime.minute)
    {
        POWER_DEBUG_LOG((int8_t *)"[get_time_change] realized some mins change!\n");
        return POWER_SOME_MINS_CHANGE;
    }

	return POWER_NO_CHANGE;
}


/**
 * @brief  功率记录初始化
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void power_record_init(void)
{
    int32_t ret = 0;

    // 文件夹不存在，先创建文件夹
	if ((sdk_fs_access((const int8_t *)PATH_POWER_GENERAL_DIR, FS_F_OK)) == -1)
	{
		ret = sdk_fs_mkdir(PATH_POWER_GENERAL_DIR, FS_S_IRWXU|FS_S_IRWXG|FS_S_IRWXO);
        if (ret == -1)
        {
            POWER_DEBUG_LOG((int8_t *)"\n[power_record_init] mkdir failed!\n");
            return;
        }
        else
        {
            POWER_DEBUG_LOG((int8_t *)"\n[power_record_init] '/user/data/power/' direct not exist but has created! \r\n");
        }	
	}

    //初始化数据库
    create_energy_table();   

    //初始化全局变量
    memset(&g_power_record_task, 0, sizeof(power_record_task_t));

    // 每次上电，记录当前时间为上一次对比时间
    POWER_DEBUG_LOG((int8_t *)"[power_record_init] ready to record last time\n");
    g_power_record_task.last_time = get_date_time();
    POWER_DEBUG_LOG((int8_t *)"[power_record_init] last_time init %04d.%02d.%02d %02dh \n", g_power_record_task.last_time.year, \
								g_power_record_task.last_time.month, g_power_record_task.last_time.date, g_power_record_task.last_time.hour);

    return;
}

/**
 * @brief  充放电功率记录管理任务
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void power_record_task(void)
{
    uint8_t change = 0;
    int32_t ret = 0;
    // time_t time_stamp;
    power_record_task_t *p_task = NULL;

    p_task = &g_power_record_task;

    if (NULL == p_task)
    {
        return;
    }

    // 获取实时功率
    ret = get_realtime_power();
    if (ret != 0)
    {
        return;
    }

    // 获取当前时间
    p_task->now_time = get_date_time();

    // 获取变化类型
    change = get_time_change(p_task->now_time, p_task->last_time);
    POWER_DEBUG_LOG((int8_t *)"[power_record_task] change = %d\n",change);
    if((p_task->now_time.minute % 5 == 0) && (p_task->now_time.minute != p_task->last_time.minute))
//    if ( (p_task->now_time.minute % 5) == 0 )
    {
        // 均按分钟变化存
        ret = history_power_record(p_task, change);
        if (ret == 0)
        {
            p_task->last_time = p_task->now_time;
        }
    }
    
    return;
}

/**
 * @brief  功率记录线程（用于充放电功率存储）
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
void *thread_history_power(void *arg)
{

	power_record_init();
    POWER_DEBUG_LOG((int8_t *)"[power_record_init] init over!\n");

    while (1)
    {
        power_record_task();
		
		// usleep(10);			// 调试
        sleep(1); 
    }
    
    pthread_exit(NULL);
}

