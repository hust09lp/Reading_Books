/*****************************************************************************
* File Name          : operating_data_handle.h            
* Description        : 运行数据处理（更新、保存）内外部通讯接口
* Original Author    : liangguyao
* date               : 2023.02.15
******************************************************************************/

#ifndef __OPERATING_DATA_HANDLE_H__ 
#define __OPERATING_DATA_HANDLE_H__ 


#include "data_shm.h"
#include "sdk_public.h"
#include "sdk_fs.h"

#define PATH_OPERATING_RECORD_FOLDER	"/media/mmcblk0p1/" // "/user/data/opt_record/"		//运行数据存储的文件夹
#define PATH_FILE_MAX_LEN   (60)        //文件路径的最大长度

#define OPERATING_DATA_READ_MAX_COUNT    480    /* 一个文件（一天）读取的最大次数（最大理论值，3min保存一次的运行数据） 24*60/3 = 480 */

#define OPERATING_RECORD_MIN_INTERVAL  3   // 3min
#define OPERATING_RECORD_MAX_INTERVAL  60  // 60min


#pragma pack(push)
#pragma pack(1)
/**
 * @struct telematic_operating_data_t
 * @brief 遥信运行数据结构体定义。
 */
typedef struct
{
    uint8_t CMU_system_fault_info[CMU_SYSTEM_FAULT_LEN_BYTE];                           // CMU系统（故障信息）0x01~0x30
    uint8_t container_system_status_info[CONTAINER_SYSTEM_STATUS_LEN_BYTE];             // 集装箱系统（状态信息） 0x31~0x88   预留 0x89~0xA0
    uint8_t container_system_warn_info[CONTAINER_SYSTEM_WARN_LEN_BYTE];                 // 集装箱系统（告警信息） 0xA1~0xD8   预留 0xD9~0x100
    uint8_t container_system_fault_info[CONTAINER_SYSTEM_FAULT_LEN_BYTE];               // 集装箱系统（故障信息） 0x101~0x138 预留 0x139~0x150

    battery_cluster_telematic_info_t battery_cluster_telematic_info[BCU_DEVICE_NUM];    // 集装箱内电池簇的遥信数据
}telematic_operating_data_t;

/**
 * @struct cmu_telemetry_operating_info_t
 * @brief cmu遥测运行数据结构体定义。
 */
typedef struct{
    uint16_t mcu1_hardware_ver;
    uint16_t mcu1_software_ver;
    uint16_t mcu2_software_ver;
    uint16_t sci_protocol_ver;
    uint16_t cmu_sys_state;     // 0:停机状态 1:待机状态 2:运行状态 3:故障状态 4:升级状态
}cmu_telemetry_operating_info_t;

/**
 * @struct battery_cluster_telemetry_operating_info_t
 * @brief 集装箱内电池簇遥测运行数据结构体定义。
 */
typedef struct{

    uint16_t software_version;                           // 软件版本 高位大版本，低位小版本
    uint16_t BCU_comm_status;                            // BCU通信状态 0-未连接 1-通信正常 2-通信中断
    int16_t  cluster_voltage;                            // 簇端电压  精度：0.1V 偏移量：0
    int16_t  cluster_current;                            // 簇端电流  精度：0.1A 偏移量：-1600
    uint16_t cluster_SOC;                                // 簇端SOC  精度：1%   偏移量：0
    uint16_t positive_insulation_resistance;             // 正绝缘阻抗  精度：1KΩ 偏移量：0
    uint16_t negative_insulation_resistance;             // 负绝缘阻抗  精度：1KΩ 偏移量：0
    int16_t  high_pressure_box_temperature[4];           // 高压箱温度T1-T4  精度：1℃ 偏移量：-40
    uint16_t PACK_number_in_cluster;                     // 簇内PACK数量
    uint16_t battery_number_in_PACK;                     // PACK内电芯数量
    uint16_t total_battery_number;                       // 总电芯数量（一簇）
    uint16_t temperature_number_in_PACK;                 // PACK内温度个数
    uint16_t total_temperature_number;                   // 总温度数量（一簇）
    int16_t highest_monomer_voltage_cluster[3];          // 单簇最高单体电压前三Umax1-3  精度：0.001V 偏移量：0
    int16_t lowest_monomer_voltage_cluster[3];           // 单簇最低单体电压前三Umin1-3  精度：0.001V 偏移量：0
    uint16_t battery_node_highest_voltage;               // 单簇最高单体电压的电池节号
    uint16_t battery_node_lowest_voltage;                // 单簇最低单体电压的电池节号
    int16_t average_voltage_monomer;                     // 单体电压平均值Umean  精度：0.001V 偏移量：0
    int16_t highest_monomer_temperature_cluster[3];      // 单簇最高单体温度前三Tmax1-3  精度：1℃ 偏移量：-40
    int16_t lowest_monomer_temperature_cluster[3];       // 单簇最低单体温度前三Tmin1-3  精度：1℃ 偏移量：-40
    uint16_t battery_node_highest_temperature;           // 单簇最高单体温度的电池节号
    uint16_t battery_node_lowest_temperature;            // 单簇最低单体温度的电池节号
    int16_t average_temperature_monomer;                 // 单体温度平均值Tmean  精度：1℃ 偏移量：-40
    uint16_t highest_monomer_SOC_cluster[3];             // 单簇最高单体SOC前三SOCmax1-3  精度：1% 偏移量：0 范围：0-100
    uint16_t lowest_monomer_SOC_cluster[3];              // 单簇最低单体SOC前三SOCmin1-3  精度：1% 偏移量：0 范围：0-100
    uint16_t battery_node_highest_SOC;                   // 单簇最高单体SOC的电池节号
    uint16_t battery_node_lowest_SOC;                    // 单簇最低单体SOC的电池节号
    uint16_t average_SOC_monomer;                        // 单体SOC平均值SOCmean  精度：1% 偏移量：0 范围：0-100
    uint16_t highest_monomer_SOH_cluster[3];             // 单簇最高单体SOH前三SOHmax1-3  精度：1% 偏移量：0 范围：0-100
    uint16_t lowest_monomer_SOH_cluster[3];              // 单簇最低单体SOH前三SOHmin1-3  精度：1% 偏移量：0 范围：0-100
    uint16_t battery_node_highest_SOH;                   // 单簇最高单体SOH的电池节号
    uint16_t battery_node_lowest_SOH;                    // 单簇最低单体SOH的电池节号
    uint16_t average_SOH_monomer;                        // 单体SOH平均值SOHmean  精度：1% 偏移量：0 范围：0-100

    monomer_info_t monomer_info[PACK_NUMBER];            // PACK1-8的详细单体数据

    int16_t pole_temperater_PACK[PACK_NUMBER][POLE_TEMP_NUM_IN_PACK];   // PACK1-8的极柱温度T1-T2  精度：1℃ 偏移量：-40
}battery_cluster_telemetry_operating_info_t;


//临时维护，新的版本共享内存修改了遥测数据会导致历史数据出现异常，这里本地维护历史数据的相关数据结构
typedef struct{

    // 集装箱
    uint16_t soc;                                       // 集装箱soc
    uint16_t soh;                                       // 集装箱soh
    uint16_t charge_limits_power;                       // 充电限制功率
    uint16_t discharge_limits_power;                    // 放电限制功率
    uint16_t charge_limits_capacity;                    // 充电限制容量
    uint16_t discharge_limits_capacity;                 // 放电限制容量
    int16_t  total_voltage;                             // 总电压
    int16_t  total_current;                             // 总电流
    int16_t  charge_discharge_power;                    // 充放电功率  KW
    uint16_t battery_cluster_number;                    // 电池簇数量
    uint16_t battery_type;                              // 电池类型 1-磷酸铁锂电池(L), 2—钛酸锂电池(N), 3—锰酸锂电池(T), 4-三元锂电池(S)
    // 除湿器
    uint16_t bat1_humidity;          					// 电池仓1 湿度
	uint16_t bat2_humidity;          					// 电池仓2 湿度
	uint16_t bat3_humidity;          					// 电池仓3 湿度
	uint16_t bat4_humidity;          					// 电池仓4 湿度
	uint16_t bat5_humidity;          					// 电池仓5 湿度
	uint16_t bat6_humidity;          					// 电池仓6 湿度
	int16_t	 bat1_temper;            					// 电池仓1 温度
	int16_t	 bat2_temper;            					// 电池仓2 温度
	int16_t	 bat3_temper;            					// 电池仓3 温度
	int16_t	 bat4_temper;            					// 电池仓4 温度
	int16_t	 bat5_temper;            					// 电池仓5 温度
	int16_t	 bat6_temper;            					// 电池仓6 温度
    // 液冷
	uint16_t lc_type;                               	// 液冷机组 型号 0：美的  1：空调国际  2：视源
    int16_t  lc_outdoor_temper;      					// 液冷机组 室外环境温度
	int16_t	 lc_inlet_temp;								// 液冷机组 进水温度
	int16_t	 lc_outlet_temp;							// 液冷机组 出水温度
	uint16_t lc_inlet_pressure;							// 液冷机组 进水压力
	uint16_t lc_outlet_pressure;						// 液冷机组 出水压力
	uint16_t lc_control_mode;        					// 液冷机组 运行模式
	uint16_t lc_sofar_mode;          					// 液冷机组 首航逻辑运行状态
	uint16_t pump_flow_rate;        					// 液冷机组 水泵流速
	uint16_t target_temp;          						// 液冷机组 目标温度
    uint16_t ff_cylinder_press;                         // 消防气瓶气压，单位：1KPa
	uint16_t reserver[4];
    // 消防复合型传感器
    int16_t  mix_sensor1_temp;       					// 电池仓1#复合型传感器温度
    uint16_t mix_sensor1_co_ppm;     					// 电池仓1#复合型传感器CO浓度
    uint16_t mix_sensor1_pm25_ppm;   					// 电池仓1#复合型传感器pm2.5浓度
    int16_t  mix_sensor2_temp;       					// 电池仓2#复合型传感器温度
    uint16_t mix_sensor2_co_ppm;     					// 电池仓2#复合型传感器CO浓度
    uint16_t mix_sensor2_pm25_ppm;   					// 电池仓2#复合型传感器pm2.5浓度
    int16_t  mix_sensor3_temp;       					// 电池仓3#复合型传感器温度
    uint16_t mix_sensor3_co_ppm;     					// 电池仓3#复合型传感器CO浓度
    uint16_t mix_sensor3_pm25_ppm;   					// 电池仓3#复合型传感器pm2.5浓度
    int16_t  mix_sensor4_temp;       					// 电池仓4#复合型传感器温度
    uint16_t mix_sensor4_co_ppm;     					// 电池仓4#复合型传感器CO浓度
    uint16_t mix_sensor4_pm25_ppm;   					// 电池仓4#复合型传感器pm2.5浓度
    int16_t  mix_sensor5_temp;       					// 电池仓5#复合型传感器温度
    uint16_t mix_sensor5_co_ppm;     					// 电池仓5#复合型传感器CO浓度
    uint16_t mix_sensor5_pm25_ppm;   					// 电池仓5#复合型传感器pm2.5浓度
    int16_t  mix_sensor6_temp;       					// 电池仓6#复合型传感器温度
    uint16_t mix_sensor6_co_ppm;     					// 电池仓6#复合型传感器CO浓度
    uint16_t mix_sensor6_pm25_ppm;   					// 电池仓6#复合型传感器pm2.5浓度
	// 消防
    uint16_t fire_fan_start_1co;						// 风机联动时复合型传感器1的CO 浓度值
	uint16_t fire_fan_start_2co;						// 风机联动时复合型传感器2的CO 浓度值
	uint16_t fire_fan_start_3co;						// 风机联动时复合型传感器3的CO 浓度值
	uint16_t fire_fan_start_4co;						// 风机联动时复合型传感器4的CO 浓度值
	uint16_t fire_fan_start_5co;						// 风机联动时复合型传感器5的CO 浓度值
	uint16_t fire_fan_start_6co;						// 风机联动时复合型传感器6的CO 浓度值

    // 集装箱电表
    float32_t voltage_phase_A;                          // A相电压
    float32_t voltage_phase_B;                          // B相电压
    float32_t voltage_phase_C;                          // C相电压
    float32_t active_power_combined;                    // 联合有功功率
    float32_t active_power_phase_A;                     // A相有功功率
    float32_t active_power_phase_B;                     // B相有功功率
    float32_t active_power_phase_C;                     // C相有功功率
    float32_t reactive_power_combined;                  // 联合无功功率
    float32_t reactive_power_phase_A;                   // A相无功功率
    float32_t reactive_power_phase_B;                   // B相无功功率
    float32_t reactive_power_phase_C;                   // C相无功功率
    float32_t frequency;                                // 频率
    float32_t forward_active_energy_total;              // (电流)总正向有功电量
    float32_t forward_active_energy_phase_A;            // (电流)A相正向电量
    float32_t forward_active_energy_phase_B;            // (电流)B相正向电量
    float32_t forward_active_energy_phase_C;            // (电流)C相正向电量
}history_container_system_telemetry_info_t;


/**
 * @struct telemetry_operating_data_t
 * @brief 遥测运行数据结构体定义。
 */
typedef struct
{
    cmu_telemetry_operating_info_t cmu_telemetry_operating_info;                        // cmu遥测数据
    history_container_system_telemetry_info_t container_system_telemetry_operating_info;        // 集装箱系统遥测运行数据
    battery_cluster_telemetry_operating_info_t battery_cluster_telemetry_operating_info[BCU_DEVICE_NUM];    // 集装箱内电池簇遥测数据
    DCDC_telemetry_info_t DCDC_telemetry_info;                         // 集装箱内DCDC遥测数据
}telemetry_operating_data_t;

/**
 * @struct operating_data_t
 * @brief 运行数据结构体定义。
 */
typedef struct
{
    sdk_rtc_t operating_time;    // 运行时间（年、月、日、时、分、秒）
    telematic_operating_data_t telematic_operating_data;    // 遥信运行数据
    telemetry_operating_data_t telemetry_operating_data;    // 遥测运行数据
    uint32_t crc;           // CRC校验
}operating_data_t;
#pragma pack(pop)


/**
 * @brief   运行数据初始化
 * @param   无
 * @return  无
 */
void operating_data_init(void);

/**
 * @brief   运行数据更新
 * @param   [in] p_rtc_time RTC时间结构体指针
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t operating_data_update(sdk_rtc_t *p_rtc_time);

/**
 * @brief   运行数据保存（写入文件）
 * @param   [in] p_fs 已打开的文件指针 
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t operating_data_save(fs_t *p_fs);


#endif  /* __OPERATING_DATA_HANDLE_H__ */