/*****************************************************************************
* File Name          : operating_pcs_data_handle.h            
* Description        : 运行数据处理（更新、保存）内外部通讯接口
* Original Author    :
* date               : 2023.04.26
******************************************************************************/

#ifndef __OPERATING_PCS_DATA_HANDLE_H__ 
#define __OPERATING_PCS_DATA_HANDLE_H__ 


#include "data_shm.h"
#include "sdk_public.h"
#include "sdk_fs.h"

#define PATH_OPERATING_PCS_RECORD_FOLDER	"/media/mmcblk0p1/pcs_opt_record/" //运行数据存储的文件夹
//#define PATH_OPERATING_RECORD_FOLDER	"/user/data/opt_record/" // "/user/data/opt_record/"		//运行数据存储的文件夹
#define PATH_FILE_MAX_LEN   (60)        //文件路径的最大长度

#define OPERATING_PCS_DATA_READ_MAX_COUNT    480    /* 一个文件（一天）读取的最大次数（最大理论值，3min保存一次的运行数据） 24*60/3 = 480 */

#pragma pack(push)
#pragma pack(1)


/**
 * @struct telematic_operating_data_t
 * @brief 遥信运行数据结构体定义。
 */

typedef struct
{
	// uint8_t csu_system_fault_info[CSU_SYSTEM_FAULT_LEN_BYTE];							// CSU系统（故障信息）0xD00~0xD2F
    // uint8_t pcs_system_cabinet_status_info[PCS_CABINET_SYSTEM_STATUS_LEN_BYTE];             // PCS系统柜（状态信息）
    // uint8_t pcs_system_cabinet_fault_info[PCS_CABINET_SYSTEM_FAULT_LEN_BYTE];                 // PCS系统柜（故障信息）
    pcs_telematic_info_t pcs_module[PCS_CABINET_POWER_MODULE_NUM];							// PCS系统柜功率模块
}telematic_operating_pcs_data_t;

/**
 * @struct cmu_telemetry_operating_info_t
 * @brief cmu遥测运行数据结构体定义。
 */
typedef struct{
    uint16_t mcu1_hardware_ver;
    uint16_t mcu1_software_ver;
    uint16_t mcu2_software_ver;
    uint16_t sci_protocol_ver;
    uint16_t cmu_sys_state;     // 0:停机状态 1:待机状态 2:运行状态 3:故障状态 4:升级状态
}cmu_telemetry_operating_pcs_info_t;


//历史数据结构不用共享内存数据结构，改为本地维护，防止修改共享内存影响到历史数据读取
typedef struct{
	//0x14301
	int16_t grid_volt_rs;				//遥测信息：电网相电压RS  0.1V
	int16_t grid_volt_st;				//遥测信息：电网相电压ST  0.1V
	int16_t grid_volt_tr;				//遥测信息：电网相电压TR  0.1V
	int16_t grid_freq;					//遥测信息：电网频率	  0.01 Hz
	int16_t ac_current_r;				//遥测信息：交流侧电流R相 0.1A
	int16_t ac_current_s;				//遥测信息：交流侧电流S相 0.1A
	int16_t ac_current_t;				//遥测信息：交流侧电流T相 0.1A
	int16_t bus_volt_pn;				//遥测信息：母线电压  0.1V
	int16_t bat_volt;					//遥测信息：电池电压  0.1V
	uint16_t iso_resistence;			//遥测信息：绝缘阻抗检测阻抗值 1kOhm
	int16_t active_power;				//有功功率，放电为正，充电为负                 0.01kW
	int16_t reactive_power;				//无功功率，逆变器端超前为正，滞后为负  0.01kVar
	int16_t apparent_power;				//视在功率 0.01kVA
	int16_t amb_temp;					//环境温度0.1℃
	int16_t power_factor;    			//功率因数
	uint16_t Running_Hours_L;			//PCS模块累计运行时间(低16位)
	uint16_t Running_Hours_H;			//PCS模块累计运行时间(高16位)
	int16_t Active_Power_R;				//R相有功功率
	int16_t Active_Power_S;				//S相有功功率
	int16_t Active_Power_T; 			//T相有功功率
	int16_t Reactive_Power_R;			//R相无功功率
	int16_t Reactive_Power_S;			//S相无功功率
	int16_t Reactive_Power_T; 			//T相无功功率
	int16_t Apparent_Power_R;			//R相视在功率
	int16_t Apparent_Power_S;			//S相视在功率
	int16_t Apparent_Power_T;			//T相视在功率
	uint16_t System_Time_Second;		//系统时间-秒
	uint16_t System_Time_Minute;		//系统时间-分
	uint16_t System_Time_Hour;			//系统时间-时
	uint16_t System_Time_Day;			//系统时间-天
	uint16_t System_Time_Month;			//系统时间-月
	uint16_t System_Time_Year;			//系统时间-年
	int16_t En_Grid_Current_R;         //入网侧电流R相
	int16_t	En_Grid_Current_S;			//入网侧电流S相
	int16_t	En_Grid_Current_T;			//入网侧电流T相
	// int16_t QvarInsRef;					//无功功率瞬时给定，发容性无功为正，感性为负
	// uint16_t rev1[23];                  //预留
	//0x14333
	int16_t grid_volt_r;				//遥测信息：电网相电压R  0.1V
	int16_t grid_volt_s;				//遥测信息：电网相电压S  0.1V
	int16_t grid_volt_t;				//遥测信息：电网相电压T  0.1V
	int16_t n_to_pe_volt;				//遥测信息：相对地电压  0.1V
	int16_t dci_r;						//遥测信息：R相电流直流偏置  1mA
	int16_t dci_s;						//遥测信息：S相电流直流偏置  1mA
	int16_t dci_t;						//遥测信息：T相电流直流偏置  1mA
	int16_t gfci;						//遥测信息：漏电流  0.1mA
	int16_t bus_volt_p;					//遥测信息：正半母线电压  0.1V
	int16_t bus_volt_n;					//遥测信息：正半母线电压  0.1V
	int16_t igbt_temp_ra;				//模块Ra温度 0.1℃
	int16_t igbt_temp_sa;				//模块Sa温度 0.1℃
	int16_t igbt_temp_ta;				//模块Ta温度 0.1℃
	int16_t igbt_temp_rb;				//模块Rb温度 0.1℃
	int16_t igbt_temp_sb;				//模块Sb温度 0.1℃
	int16_t igbt_temp_tb;				//模块Tb温度 0.1℃
	int16_t slv_grid_volt_r;			//副DSP采样R相电网电压 0.1V
	int16_t slv_grid_volt_s;			//副DSP采样S相电网电压 0.1V
	int16_t slv_grid_volt_t;			//副DSP采样T相电网电压 0.1V
	uint16_t Fan_Speed_Inner1;			//内部风扇1转速
	uint16_t Fan_Speed_Inner2;			//内部风扇2转速
	uint16_t Fan_Speed_Outer1;			//外部风扇1转速
	uint16_t Fan_Speed_Outer2;			//外部风扇2转速
	uint16_t Fan_Speed_Outer3;			//外部风扇3转速
	uint16_t Fan_Speed_Outer4;			//外部风扇4转速
	uint16_t energy_discharge_l;         //模块累计放电量低16位(与高16位组合，按I32解析)
    uint16_t energy_discharge_h;        	//模块累计放电量高16位(与低16位组合，按I32解析)
    uint16_t energy_charge_l;            //模块累计充电量低16位(与高16位组合，按I32解析)
    uint16_t energy_charge_h;        	//模块累计充电量高16位(与低16位组合，按I32解析)
	uint16_t rev1[9];                  //预留
	int16_t bat_current;				//遥测信息：电池电流  0.1A
	uint16_t iso_det_state;				//绝缘阻抗检测结果       	1
	int16_t iso_volt_to_pe;				//Iso对地电压			0.1V
	uint16_t rev2[9];                  //预留
}history_power_module_telemetry_info_t;


/**
 * @struct telemetry_operating_data_t
 * @brief 遥测运行数据结构体定义。
 */
typedef struct
{
    // pcs_cabinet_telemetry_info_t pcs_cabinet_telemetry_info;                  		// PCS系统柜遥测数据
    // pcs_version_telemetry_info_t pcs_version_telemetry_info;                                    // PCS柜版本信息
    pcs_module_version_telemetry_info_t pcs_module_version_telemetry_info[PCS_CABINET_POWER_MODULE_NUM];    // PCS模块版本信息                                // PCS模块版本信息
    history_power_module_telemetry_info_t power_module_telemetry_info[PCS_CABINET_POWER_MODULE_NUM];    // 功率模块遥测数据
}telemetry_operating_pcs_data_t;

/**
 * @brief 历史功率定值数据结构体定义。
 */

typedef struct
{
    int16_t active_power;                           // 有功功率
    int16_t reactive_power;                         // 无功功率          

}history_constant_parameter_t;
/**
 * @struct operating_pcs_data_t
 * @brief 运行数据结构体定义。
 */
typedef struct
{
    sdk_rtc_t operating_time;    // 运行时间（年、月、日、时、分、秒）
    telematic_operating_pcs_data_t telematic_operating_data;    // 遥信运行数据
    telemetry_operating_pcs_data_t telemetry_operating_data;    // 遥测运行数据
    history_constant_parameter_t history_constant_parameter;
    uint32_t crc;           // CRC校验
}operating_pcs_data_t;

#pragma pack(pop)


/**
 * @brief   运行数据初始化
 * @param   无
 * @return  无
 */
void operating_pcs_data_init(void);

/**
 * @brief   运行数据更新
 * @param   [in] p_rtc_time RTC时间结构体指针
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t operating_pcs_data_update(sdk_rtc_t *p_rtc_time);

/**
 * @brief   运行数据保存（写入文件）
 * @param   [in] p_fs 已打开的文件指针 
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t operating_pcs_data_save(fs_t *p_fs);


#endif  /* __OPERATING_DATA_HANDLE_H__ */
