/*****************************************************************************
* File Name          : operating_record_export.h            
* Description        : 运行数据记录文件U盘导出接口
* Original Author    : liangguyao
* date               : 2023.02.15
******************************************************************************/

#ifndef __OPERATING_RECORD_EXPORT_H__ 
#define __OPERATING_RECORD_EXPORT_H__ 

#include "data_types.h"


/* 函数运行结果 */
#define EXPORT_RET_TURE				    (0)		//函数正确执行完,需要回复的数据已正确回复
#define EXPORT_RET_SRC_FILE_ERR		    (-1)	//源文件不存在
#define EXPORT_RET_SRC_FILE_OPEN_ERR	(-2)	//源文件sdk_fs_open出错
#define EXPORT_RET_SRC_FILE_SEEK_ERR	(-3)	//源文件sdk_fs_lseek位置偏移出错
#define EXPORT_RET_DES_FILE_OPEN_ERR	(-4)	//目标文件sdk_fs_open出错
#define EXPORT_RET_DATA_ERR			    (-5)	//导出数据异常

/**
 * @struct operating_date_t
 * @brief 运行日期结构体定义。
 */
typedef struct{
    uint8_t  tm_day;     // <  日 	1-31    与SDK的sdk_rtc_t定义tm_day保持一致
    uint8_t  tm_mon;     // <  月 	1-12    与SDK的sdk_rtc_t定义tm_mon保持一致
    uint16_t tm_year;    // <  年           
}operating_date_t;

/**
 * @brief   运行数据记录文件U盘导出
 * @param   [in] p_date 要导出的日期结构体指针
 * @return  结果
 * @retval  0 导出成功
 * @retval  其他 导出失败
 */
int32_t operating_record_export(operating_date_t *p_date);

#endif  /* __OPERATING_RECORD_EXPORT_H__ */