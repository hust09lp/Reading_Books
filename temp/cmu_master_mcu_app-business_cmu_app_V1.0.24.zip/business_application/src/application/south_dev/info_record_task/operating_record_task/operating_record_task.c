/*****************************************************************************
* File Name        : operating_record_task.c            
* Description      : 运行数据记录任务
* Original Author  : liangguyao
* date             : 2023.02.15
******************************************************************************/

#include "operating_record_task.h"
#include "operating_data_handle.h"
#include "sofar_log.h"
#include "sdk_store.h"
#include "sdk_shm.h"
#include "sofar_errors.h"

#include <pthread.h>
//#include <time.h>    /* time_t, struct tm, time, localtime */
//#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
//#include <sys/time.h>


#define OPERATING_RECORD_INVALID_YEAR    37  // 同步sdk_public里的rtc时间入参合法性/有效性检查的年份
#define OPERATING_RECORD_YEAR_INTERVAL   2   // 年间隔

#define BASE_YEAR   2000    // 基准年份


static sdk_rtc_t g_operating_time_record = {0, 0, 0, 0, 0, 0, 0};  // 保存上次记录的时间点
static uint16_t g_minute_interval = 5;  // 3min~60min可设置，默认5min


/**
 * @brief   获取运行数据存储的分钟间隔
 * @param   无
 * @return  [uint16_t] 返回分钟间隔
 */
uint16_t operating_time_minute_interval_get(void)
{
    return g_minute_interval;
}

/**
 * @brief   设置运行数据存储的分钟间隔
 * @param   [in] value 要设置的分钟间隔
 * @note    取值范围：3min ~ 60min
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t operating_time_minute_interval_set(uint16_t value)
{
    int32_t ret = 0;
    if (value < OPERATING_RECORD_MIN_INTERVAL || value > OPERATING_RECORD_MAX_INTERVAL)
    {
        ret = -1;
    }
    else
    {
        g_minute_interval = value;
    }

    return ret;
}

/**
 * @brief   运行数据存储的分钟间隔初始化
 * @param   无
 * @return  无
 */
static void operating_time_minute_interval_init(void)
{
    uint16_t minute_interval;
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    minute_interval = p_para_data->storage_freq_operation_data;
    if ((minute_interval >= OPERATING_RECORD_MIN_INTERVAL) && (minute_interval <= OPERATING_RECORD_MAX_INTERVAL))
    {
        operating_time_minute_interval_set(minute_interval);
    }
}

/**
 * @brief   运行数据存储的分钟间隔监控
 * @param   无
 * @return  [uint16_t] 分钟间隔
 */
static uint16_t operating_time_minute_interval_monitor(void)
{
    uint16_t old_interval;
    uint16_t new_interval;
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数
    
    old_interval = operating_time_minute_interval_get();
    new_interval = p_para_data->storage_freq_operation_data;
    if (old_interval != new_interval)
    {
        if ((new_interval >= OPERATING_RECORD_MIN_INTERVAL) && (new_interval <= OPERATING_RECORD_MAX_INTERVAL))
        {
            operating_time_minute_interval_set(new_interval);
            old_interval = new_interval;
        }
    }

    return old_interval;
}

/**
 * @brief   获取保存上次记录时间点的全局变量的指针
 * @param   无
 * @return  (static修饰的)全局变量的地址作为返回值
 */
static sdk_rtc_t *operating_time_record_get(void)
{
    return (&g_operating_time_record);
}

/**
 * @brief   运行数据时间记录
 * @param   [in] p_rtc_time 当前的RTC时间结构体指针
 * @note    g_operating_time_record 记录保存运行的时间
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
static int32_t operating_time_record_set(sdk_rtc_t *p_rtc_time)
{
    int32_t ret = 0;
    sdk_rtc_t *p_record = operating_time_record_get();

    if (p_record == NULL || p_rtc_time == NULL)
    {
        ret = -1;
    }
    else
    {
        p_record->tm_year = p_rtc_time->tm_year;
        p_record->tm_mon = p_rtc_time->tm_mon;
        p_record->tm_day = p_rtc_time->tm_day;
        p_record->tm_hour = p_rtc_time->tm_hour;
        p_record->tm_min = p_rtc_time->tm_min;
        p_record->tm_sec = p_rtc_time->tm_sec;
        p_record->tm_weekday = p_rtc_time->tm_weekday;
    }

    return ret;
}

/**
 * @brief   运行数据记录初始化
 * @param   无
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t operating_record_init(void)
{
    sdk_rtc_t rtc_time;
    int32_t ret;

    operating_data_init();
    operating_time_minute_interval_init();

    ret = sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
    if (ret != SF_OK)
    {
        log_e((int8_t *)"\n [%s:%d] sdk_rtc_get fail \n", __func__, __LINE__);
        return ret;
    }

    operating_time_record_set(&rtc_time);

    return ret;
}

/**
 * @brief          检查SD卡是否挂载
 * @return         true：挂载 false：没有挂载
 */
static bool sd_mount_status(void)
{
    char cmd[256] = {0};
    char tmp_buff[32] = {0};
    FILE *fp = NULL;

    snprintf(cmd, 256, "df | grep \"dev/mmcblk0p1\" | awk '{print $1}'");
    fp = popen(cmd,"r");
    if(fp == NULL)
    {
        return false;
    }
    fread(tmp_buff, 1, sizeof(tmp_buff), fp);
    if(!strncmp(tmp_buff, "/dev/mmcblk0p1", strlen("/dev/mmcblk0p1")))
    {
        pclose(fp);
        return true;
    }
    pclose(fp);
    return false;
}


/**
 * @brief   运行数据处理
 * @param   [in] p_rtc_time RTC时间结构体指针
 * @return  [int32_t] 执行结果
 * @retval  SF_OK: 成功
 * @retval  SF_ERR_NO_OBJECT: 对象不存在
 * @retval  SF_ERR_OPEN: 打开失败
 * @retval  SF_ERR_CLOSE: 关闭失败
 * @retval  SF_ERR_NDEF: 未定义的错误
 */
static int32_t operating_record_handle(sdk_rtc_t *p_rtc_time)
{
    char file_name[PATH_FILE_MAX_LEN];
    fs_t *p_fs = NULL;
    int32_t ret = 0;
    sdk_rtc_t *p_record;
    bool sd_sta = false;

    /* 运行数据更新 */
    operating_data_update(p_rtc_time);


    /* 检测SD卡是否存在 */
    sd_sta = sd_mount_status();
    if(sd_sta == false)
    {
       log_i((int8_t *)"\n battery TF_CARD does not exist!!! \n"); 
       return SF_ERR_NO_OBJECT; 
    }
#if 0
    ret = sdk_store_is_exist(TF_CARD);
    if (ret < SF_OK)
    {
        log_i((int8_t *)"\n battery TF_CARD does not exist!!! \n");
        return SF_ERR_NO_OBJECT;
    }
#endif
    /* 判断/media/文件夹是否存在 */
    ret = sdk_fs_access((const int8_t *)(PATH_OPERATING_RECORD_FOLDER), F_OK);
    if (ret != SF_OK)
    {
        log_i((int8_t *)"\n [%s:%d] /media/ Folder does not exist. \n", __func__, __LINE__);
        return SF_ERR_NO_OBJECT;
    }
    
    /* 需检测年文件夹是否存在 */
    snprintf(file_name, sizeof(file_name), PATH_OPERATING_RECORD_FOLDER "%04d/", p_rtc_time->tm_year + BASE_YEAR);
    ret = sdk_fs_access((const int8_t *)(file_name), FS_F_OK);
    if (ret != SF_OK)	//文件夹不存在,先创建文件夹
    {
        log_i((int8_t *)"\n [%s:%d] %04d Folder does not exist! \n", __func__, __LINE__, p_rtc_time->tm_year + BASE_YEAR);
        ret = sdk_fs_mkdir(file_name, 755);
        if (ret < 0)
        {
            log_i((int8_t *)"\n [%s:%d] sdk_fs_mkdir fail. %s \n", __func__, __LINE__, file_name);
            return SF_ERR_NDEF;
        }
        else
        {
            log_i((int8_t *)"\n [%s:%d] sdk_fs_mkdir succeed. ret = %d\n", __func__, __LINE__, ret);
        }
    }

    /* 运行数据写入文件保存 */
    p_record = operating_time_record_get();
    if (p_record == NULL)
    {
        return SF_ERR_NDEF;
    }
    snprintf(file_name, sizeof(file_name), PATH_OPERATING_RECORD_FOLDER "%04d/%04d%02d%02d", \
            p_record->tm_year + BASE_YEAR, p_record->tm_year + BASE_YEAR, \
            p_record->tm_mon, p_record->tm_day);
    p_fs = sdk_fs_open((const int8_t *)file_name, FS_OPEN_APPEND);
    if (p_fs == NULL)
    {
        log_i((int8_t *)"\n [%s:%d] sdk_fs_open operating record file fail. \n", __func__, __LINE__);
        return SF_ERR_OPEN;
    }
    operating_data_save(p_fs);
    fsync(fileno(&p_fs->file));
    ret = sdk_fs_close(p_fs);

    if (ret < 0)
    {
        log_i((int8_t *)"\n [%s:%d] sdk_fs_close fail! ret = %d \n", __func__, __LINE__, ret);
        return SF_ERR_CLOSE;
    }

    return SF_OK;
}

/**
 * @brief  	将sdk_rtc_t结构体时间转换成时间戳（秒）
 * @param  	[in] p_time         sdk_rtc_t结构体时间
 * @param  	[out] p_timestamp   时间戳（秒）
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
static int32_t date_time_to_timestamp(sdk_rtc_t *p_time, time_t *p_timestamp)
{
    struct tm data;

    if ((p_time == NULL) || (p_timestamp == NULL))
    {
        log_i((int8_t *)"\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    memset(&data, 0, sizeof(data));
    data.tm_year = (int32_t)(p_time->tm_year) + 100;
    data.tm_mon  = (int32_t)(p_time->tm_mon - 1);
    data.tm_mday = (int32_t)(p_time->tm_day);
    data.tm_hour = (int32_t)(p_time->tm_hour);
    data.tm_min  = (int32_t)(p_time->tm_min);
    data.tm_sec  = (int32_t)(p_time->tm_sec);
    *p_timestamp = mktime(&data) - 8 * 60 * 60;

    return SF_OK;
}

/**
 * @brief  	将时间戳（秒）转换成sdk_rtc_t结构体时间
 * @param  	[in] p_timestamp    时间戳（秒）
 * @param  	[out] p_time        sdk_rtc_t结构体时间
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
static int32_t timestamp_to_date_time(time_t *p_timestamp, sdk_rtc_t *p_time)
{
    struct tm *p_data;

    if ((p_timestamp == NULL) || (p_time == NULL))
    {
        log_i((int8_t *)"\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    p_data = localtime(p_timestamp);
    p_time->tm_year = (uint8_t)(p_data->tm_year - 100);
    p_time->tm_mon  = (uint8_t)(p_data->tm_mon + 1);
    p_time->tm_day  = (uint8_t)(p_data->tm_mday);
    p_time->tm_hour = (uint8_t)(p_data->tm_hour);
    p_time->tm_min  = (uint8_t)(p_data->tm_min);
    p_time->tm_sec  = (uint8_t)(p_data->tm_sec);

    return SF_OK;
}

/**
 * @brief  	以sdk_rtc_t结构体时间为终点，将不满足运行数据存储天数的过期文件清除
 * @param  	[in] p_time         sdk_rtc_t结构体时间
 * @return 	无
 */
static void operating_record_clear_expired_files(sdk_rtc_t *p_time)
{
    char file_name[PATH_FILE_MAX_LEN];
    uint16_t days;
    uint16_t year;
    uint16_t file_num;
    int32_t  ret;
    uint16_t i;
    time_t timestamp;
    time_t temp_timestamp;
    sdk_rtc_t temp_rtc_time;
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    if (p_time == NULL)
    {
        return;
    }

    if (p_time->tm_year > OPERATING_RECORD_INVALID_YEAR)
    {
        log_e((int8_t *)"\n [%s:%d] error, year = %d \n", __func__, __LINE__, p_time->tm_year);
        return;
    }

    days = p_para_data->storage_duration_operation_data;
    if ((days >= OPERATING_RECORD_DAYS_MIN) && (days <= OPERATING_RECORD_DAYS_MAX))
    {
        if (p_time->tm_year > OPERATING_RECORD_YEAR_INTERVAL)
        {
            year = p_time->tm_year - OPERATING_RECORD_YEAR_INTERVAL + BASE_YEAR;

            /* 检测前年的文件夹是否存在 */
            snprintf(file_name, sizeof(file_name), PATH_OPERATING_RECORD_FOLDER "%04d/", year);
            ret = sdk_fs_access((const int8_t *)(file_name), FS_F_OK);
            if (ret == SF_OK)
            {
                /* 删除前年的文件夹 */
                // SDK缺少删除文件夹的函数接口，后续再补充
            }
        }

        /* 计算要删除的文件数量 */
        file_num = OPERATING_RECORD_DAYS_MAX - days;

        /* 获取当前时间戳 */
        ret = date_time_to_timestamp(p_time, &timestamp);
        if (ret < SF_OK)
        {
            log_e((int8_t *)"\n [%s:%d] error, ret = %d \n", __func__, __LINE__, ret);
            return;
        }

        for (i = 0; i < file_num; i++)
        {
            temp_timestamp = timestamp - ((days + i) * 24 * 60 * 60);
            ret = timestamp_to_date_time(&temp_timestamp, &temp_rtc_time);
            if (ret == SF_OK)
            {
                /* 判断对应的日期文件是否存在 */
                snprintf(file_name, sizeof(file_name), PATH_OPERATING_RECORD_FOLDER "%04d/%04d%02d%02d", \
                    temp_rtc_time.tm_year + BASE_YEAR, temp_rtc_time.tm_year + BASE_YEAR, \
                    temp_rtc_time.tm_mon, temp_rtc_time.tm_day);
                ret = sdk_fs_access((const int8_t *)file_name, FS_F_OK);
                if (ret == SF_OK)
                {
                    /* 删除该日期文件 */
                    ret = sdk_fs_remove((const int8_t *)file_name);
                    if (ret < SF_OK)
                    {
                        log_i((int8_t *)"\n [%s:%d] error, ret = %d \n", __func__, __LINE__, ret);
                    }
                }
            }
        }
    }
}

/**
 * @brief   运行数据记录管理任务
 * @param   无
 * @return  无
 * @note    存储天数（≥30，≤360）和频率（3min~60min）可设置
 */
void operating_record_task(void)
{
    sdk_rtc_t rtc_time;
    int32_t ret;
    time_t curr_timestamp = 0;
    time_t record_timestamp = 0;
    uint16_t minute_interval;
    sdk_rtc_t *p_record = operating_time_record_get();


    if (p_record == NULL)
    {
        return;
    }

    ret = sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
    if (ret == SF_OK)
    {
        if (rtc_time.tm_year > OPERATING_RECORD_INVALID_YEAR)
        {
            log_e((int8_t *)"\n [%s:%d] error, year = %d \n", __func__, __LINE__, rtc_time.tm_year);
            return;
        }
        else if (p_record->tm_year > OPERATING_RECORD_INVALID_YEAR)
        {
            /* 从未同步的时间变化为同步后的时间时，设置一次运行时间 */
            operating_time_record_set(&rtc_time);
        }
        else
        {
            /* 获取当前时间戳 */
            ret = date_time_to_timestamp(&rtc_time, &curr_timestamp);
            if (ret == SF_OK)
            {
                /* 获取保存上次记录时间点对应的时间戳 */
                ret = date_time_to_timestamp(p_record, &record_timestamp);
                if (ret == SF_OK)
                {
                    /* 如果当前的时间小于上次记录的时间时（时间被用户往回设置），重新设置记录的运行时间 */
                    if (curr_timestamp < record_timestamp)
                    {
                        operating_time_record_set(&rtc_time);
                    }
                }
            }
        }

        minute_interval = operating_time_minute_interval_monitor();
        if((rtc_time.tm_min % minute_interval == 0) && (rtc_time.tm_min != p_record->tm_min))
        {
            operating_time_record_set(&rtc_time);
            ret = operating_record_handle(&rtc_time);

            /* 清除过期文件 */
            operating_record_clear_expired_files(&rtc_time);
        }
    }
    else
    {
        log_e((int8_t *)"\n [%s:%d] sdk_rtc_get fail. \n", __func__, __LINE__);
    }
}

/** 
 * @brief   运行记录线程
 * @param
 * @return 	void
 */
void *thread_operating_record(void *arg)
{
    operating_record_init();

    while (1)
    {
        operating_record_task();

        sleep(1); // sdk_delay_ms(1000);	// 1s
    }
    
    pthread_exit(NULL);
}

