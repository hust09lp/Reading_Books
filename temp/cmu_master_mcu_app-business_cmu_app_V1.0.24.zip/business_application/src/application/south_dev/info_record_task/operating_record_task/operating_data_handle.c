/*****************************************************************************
* File Name        : operating_data_handle.c            
* Description      : 运行数据处理（更新、保存）
* Original Author  : liangguyao
* date             : 2023.02.15
******************************************************************************/

#include "operating_data_handle.h"
#include "process_battery_read.h"
#include "crc.h"
#include "sdk_shm.h"
#include "sofar_log.h"

#include <string.h>


static operating_data_t g_operating_data;  // 运行数据

/**
 * @brief   获取运行数据全局变量的指针
 * @param   无
 * @return  （static修饰的）全局变量的地址作为返回值
 */
static operating_data_t *operating_data_get(void)
{
    return (&g_operating_data);
}

/**
 * @brief   运行数据初始化
 * @param   无
 * @return  无
 */
void operating_data_init(void)
{
    memset(&g_operating_data, 0, sizeof(g_operating_data));
}

/**
 * @brief   运行时间更新
 * @param   [in] p_rtc_time RTC时间结构体指针
 * @param   [out] p_operating_data 运行数据结构体指针
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
static int32_t operating_time_update(sdk_rtc_t *p_rtc_time, operating_data_t *p_operating_data)
{
    int32_t ret = 0;

    if (p_operating_data == NULL || p_rtc_time == NULL)
    {
        ret = -1;
    }
    else
    {
        p_operating_data->operating_time.tm_year = p_rtc_time->tm_year;
        p_operating_data->operating_time.tm_mon = p_rtc_time->tm_mon;
        p_operating_data->operating_time.tm_day = p_rtc_time->tm_day;
        p_operating_data->operating_time.tm_hour = p_rtc_time->tm_hour;
        p_operating_data->operating_time.tm_min = p_rtc_time->tm_min;
        p_operating_data->operating_time.tm_sec = p_rtc_time->tm_sec;
        p_operating_data->operating_time.tm_weekday = p_rtc_time->tm_weekday;
    }

    return ret;
}

/**
 * @brief   遥信运行数据更新
 * @param   [out] p_operating_data 运行数据结构体指针
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
static int32_t telematic_operating_data_update(operating_data_t *p_operating_data)
{
    int num;
    battery_cluster_data_t *p_battery_cluster;
    battery_cluster_data_t *p_battery_cluster_offset;
    telematic_data_t *p_telematic_data;

    if (p_operating_data == NULL)
    {
        return -1;
    }

    p_telematic_data = sdk_shm_telematic_data_get();

    /* CMU系统（故障信息）0x01~0x30  CMU_system_fault_info[CMU_SYSTEM_FAULT_LEN_BYTE] */
    memcpy(p_operating_data->telematic_operating_data.CMU_system_fault_info, \
           p_telematic_data->CMU_system_fault_info, CMU_SYSTEM_FAULT_LEN_BYTE);

    /* 集装箱系统（状态信息） 0x31~0x88   预留 0x89~0xA0  container_system_status_info[CONTAINER_SYSTEM_STATUS_LEN_BYTE] */
    memcpy(p_operating_data->telematic_operating_data.container_system_status_info, \
           p_telematic_data->container_system_status_info, CONTAINER_SYSTEM_STATUS_LEN_BYTE);

    /* 集装箱系统（告警信息） 0xA1~0xD8   预留 0xD9~0x100  container_system_warn_info[CONTAINER_SYSTEM_WARN_LEN_BYTE]*/
    memcpy(p_operating_data->telematic_operating_data.container_system_warn_info, \
           p_telematic_data->container_system_warn_info, CONTAINER_SYSTEM_WARN_LEN_BYTE);

    /* 集装箱系统（故障信息） 0x101~0x138 预留 0x139~0x150  container_system_fault_info[CONTAINER_SYSTEM_FAULT_LEN_BYTE]*/
    memcpy(p_operating_data->telematic_operating_data.container_system_fault_info, \
           p_telematic_data->container_system_fault_info, CONTAINER_SYSTEM_FAULT_LEN_BYTE);

    p_battery_cluster = battery_cluster_data_get();
    for (num = 0; num < BCU_DEVICE_NUM; num++)
    {
        p_battery_cluster_offset = p_battery_cluster + num;

        /* 集装箱内电池簇（告警信息） 0x71~0xB8   预留 0xB9~0x100  battery_cluster_warn_info[BATTERY_CLUSTER_WARN_LEN_BYTE] */
        memcpy(p_operating_data->telematic_operating_data.battery_cluster_telematic_info[num].battery_cluster_warn_info, \
        p_battery_cluster_offset->battery_cluster_warn_info, BATTERY_CLUSTER_WARN_LEN_BYTE);

        /* 集装箱内电池簇（故障信息） 0x101~0x119 预留 0x11A~0x200  battery_cluster_fault_info[BATTERY_CLUSTER_FAULT_LEN_BYTE] */
        memcpy(p_operating_data->telematic_operating_data.battery_cluster_telematic_info[num].battery_cluster_fault_info, \
        p_battery_cluster_offset->battery_cluster_fault_info, BATTERY_CLUSTER_FAULT_LEN_BYTE);

        /* 集装箱内电池簇（状态信息） 0x201~0x210 预留 0x211~0x260  battery_cluster_status_info[BATTERY_CLUSTER_STATUS_LEN_BYTE] */
        memcpy(p_operating_data->telematic_operating_data.battery_cluster_telematic_info[num].battery_cluster_status_info, \
        p_battery_cluster_offset->battery_cluster_status_info, BATTERY_CLUSTER_STATUS_LEN_BYTE);
    }

    return 0;
}

/**
 * @brief   遥测运行数据更新
 * @param   [out] p_operating_data 运行数据结构体指针
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
static int32_t telemetry_operating_data_update(operating_data_t *p_operating_data)
{
    int num;
    battery_cluster_data_t *p_battery_cluster;
    battery_cluster_data_t *p_battery_cluster_offset;
    telemetry_data_t *p_telemetry_data;

    if (p_operating_data == NULL)
    {
        return -1;
    }

    p_telemetry_data = sdk_shm_telemetry_data_get();

    /* cmu遥测运行数据更新 */
    p_operating_data->telemetry_operating_data.cmu_telemetry_operating_info.mcu1_hardware_ver = p_telemetry_data->cmu_telemetry_info.mcu1_hardware_ver;
    p_operating_data->telemetry_operating_data.cmu_telemetry_operating_info.mcu1_software_ver = p_telemetry_data->cmu_telemetry_info.mcu1_software_ver;
    p_operating_data->telemetry_operating_data.cmu_telemetry_operating_info.mcu2_software_ver = p_telemetry_data->cmu_telemetry_info.mcu2_software_ver;
    p_operating_data->telemetry_operating_data.cmu_telemetry_operating_info.sci_protocol_ver  = p_telemetry_data->cmu_telemetry_info.sci_protocol_ver;
    p_operating_data->telemetry_operating_data.cmu_telemetry_operating_info.cmu_sys_state     = p_telemetry_data->cmu_telemetry_info.cmu_sys_state;

    /* 集装箱系统遥测运行数据更新 */
    memcpy(&(p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info), \
        &(p_telemetry_data->container_system_telemetry_info), sizeof(container_system_telemetry_info_t));

    /* 集装箱内电池簇遥测数据更新 */
    p_battery_cluster = battery_cluster_data_get();
    for (num = 0; num < BCU_DEVICE_NUM; num++)
    {
        p_battery_cluster_offset = p_battery_cluster + num;
        memcpy(&(p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num]), \
            &(p_battery_cluster_offset->software_version), sizeof(battery_cluster_telemetry_operating_info_t));
    }

    /* 集装箱内DCDC遥测数据更新 */
    memcpy(&(p_operating_data->telemetry_operating_data.DCDC_telemetry_info), \
        &(p_telemetry_data->DCDC_telemetry_info), sizeof(DCDC_telemetry_info_t));

    return 0;
}

/**
 * @brief   运行数据更新
 * @param   [in] p_rtc_time RTC时间结构体指针
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t operating_data_update(sdk_rtc_t *p_rtc_time)
{
    operating_data_t *p_operating_data = operating_data_get();

    if (p_operating_data == NULL)
    {
        return -1;
    }

    /* 运行时间更新 */
    operating_time_update(p_rtc_time, p_operating_data);

    /* 遥信运行数据更新 */
    telematic_operating_data_update(p_operating_data);

    /* 遥测运行数据更新 */
    telemetry_operating_data_update(p_operating_data);

    /* CRC校验更新 */
    p_operating_data->crc = crc32((const unsigned char *)p_operating_data, (sizeof(operating_data_t) - 4));

    return 0;
}

/**
 * @brief   运行数据保存（写入文件）
 * @param   [in] p_fs 已打开的文件指针 
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t operating_data_save(fs_t *p_fs)
{
    operating_data_t *p_operating_data = operating_data_get();

    if (p_operating_data == NULL)
    {
        return -1;
    }

    sdk_fs_write(p_fs, p_operating_data, sizeof(operating_data_t));
    return 0;
}

