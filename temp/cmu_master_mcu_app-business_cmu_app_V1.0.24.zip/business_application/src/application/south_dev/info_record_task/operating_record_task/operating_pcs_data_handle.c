/*****************************************************************************
* File Name        : operating_data_handle.c            
* Description      : 运行数据处理（更新、保存）
* Original Author  : yun
* date             : 2023.04.26
******************************************************************************/

#include "operating_pcs_data_handle.h"
#include "crc.h"
#include "sdk_shm.h"
#include "sdk_log.h"

#include <string.h>


static operating_pcs_data_t g_operating_data;  // 运行数据

/**
 * @brief   获取运行数据全局变量的指针
 * @param   无
 * @return  （static修饰的）全局变量的地址作为返回值
 */
static operating_pcs_data_t *operating_pcs_data_get(void)
{
    return (&g_operating_data);
}

/**
 * @brief   运行数据初始化
 * @param   无
 * @return  无
 */
void operating_pcs_data_init(void)
{
    memset(&g_operating_data, 0, sizeof(g_operating_data));
}

/**
 * @brief   运行时间更新
 * @param   [in] p_rtc_time RTC时间结构体指针
 * @param   [out] p_operating_data 运行数据结构体指针
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
static int32_t operating_time_update(sdk_rtc_t *p_rtc_time, operating_pcs_data_t *p_operating_data)
{
    int32_t ret = 0;

    if (p_operating_data == NULL || p_rtc_time == NULL)
    {
        ret = -1;
    }
    else
    {
        p_operating_data->operating_time.tm_year = p_rtc_time->tm_year;
        p_operating_data->operating_time.tm_mon = p_rtc_time->tm_mon;
        p_operating_data->operating_time.tm_day = p_rtc_time->tm_day;
        p_operating_data->operating_time.tm_hour = p_rtc_time->tm_hour;
        p_operating_data->operating_time.tm_min = p_rtc_time->tm_min;
        p_operating_data->operating_time.tm_sec = p_rtc_time->tm_sec;
        p_operating_data->operating_time.tm_weekday = p_rtc_time->tm_weekday;
    }

    return ret;
}

/**
 * @brief   遥信运行数据更新
 * @param   [out] p_operating_data 运行数据结构体指针
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
static int32_t telematic_operating_pcs_data_update(operating_pcs_data_t *p_operating_data)
{
    int num;
    telematic_data_t *p_telematic_data;

    if (p_operating_data == NULL)
    {
        return -1;
    }

    p_telematic_data = sdk_shm_telematic_data_get();

	for (num = 0; num < PCS_CABINET_POWER_MODULE_NUM; num++)
	{
 
        /* pcs （告警信息） */
        memcpy(&(p_operating_data->telematic_operating_data.pcs_module[num]), \
        &(p_telematic_data->pcs_module[num]), sizeof(pcs_telematic_info_t));	
	}

    return 0;
}

/**
 * @brief   遥测运行数据更新
 * @param   [out] p_operating_data 运行数据结构体指针
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
static int32_t telemetry_operating_pcs_data_update(operating_pcs_data_t *p_operating_data)
{
    int num;
	telemetry_data_t *p_telemetry_data;
	
    if (p_operating_data == NULL)
    {
        return -1;
    }

    p_telemetry_data = sdk_shm_pcs_telemetry_data_get();
	

	// memcpy(&(p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info ), \
	// &(p_telemetry_data->pcs_cabinet_telemetry_info), sizeof(pcs_cabinet_telemetry_info_t));


	// memcpy(&(p_operating_data->telemetry_operating_data.pcs_version_telemetry_info ), \
	// &(p_telemetry_data->pcs_version_telemetry_info), sizeof( pcs_version_telemetry_info_t));	

	for (num = 0; num < PCS_CABINET_POWER_MODULE_NUM; num++)
	{
 
        /* pcs模块 （版本信息）  */
        memcpy(&(p_operating_data->telemetry_operating_data.pcs_module_version_telemetry_info[num]), \
        &(p_telemetry_data->pcs_module_version_telemetry_info[num]), sizeof(pcs_module_version_telemetry_info_t));	
	}

	for (num = 0; num < PCS_CABINET_POWER_MODULE_NUM; num++)
	{
 
        /* pcs模块 （信息）*/
        memcpy(&(p_operating_data->telemetry_operating_data.power_module_telemetry_info[num]), \
        &(p_telemetry_data->power_module_telemetry_info[num]), sizeof(history_power_module_telemetry_info_t));	
	}		

    return 0;
}

static int32_t history_constant_paramete_pcs_data_update(operating_pcs_data_t *p_operating_data)
{
    telemetry_data_t *pcs_telemetry_data = sdk_shm_pcs_telemetry_data_get();
	
    if (pcs_telemetry_data == NULL)
    {
    	p_operating_data->history_constant_parameter.active_power = 0;
		p_operating_data->history_constant_parameter.reactive_power = 0;
        return -1;
    }
	
	p_operating_data->history_constant_parameter.active_power =	pcs_telemetry_data->power_module_telemetry_info[0].active_power;
    p_operating_data->history_constant_parameter.reactive_power = pcs_telemetry_data->power_module_telemetry_info[0].reactive_power;
    return 1;
}


/**
 * @brief   运行数据更新
 * @param   [in] p_rtc_time RTC时间结构体指针
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t operating_pcs_data_update(sdk_rtc_t *p_rtc_time)
{
    operating_pcs_data_t *p_operating_data = operating_pcs_data_get();

    if (p_operating_data == NULL)
    {
        return -1;
    }

    /* 运行时间更新 */
    operating_time_update(p_rtc_time, p_operating_data);

    /* 遥信运行数据更新 */
    telematic_operating_pcs_data_update(p_operating_data);

    /* 遥测运行数据更新 */
    telemetry_operating_pcs_data_update(p_operating_data);

	/* 系统功率给定更新*/
	history_constant_paramete_pcs_data_update(p_operating_data);

    /* CRC校验更新 */
    p_operating_data->crc = crc32((const unsigned char *)p_operating_data, (sizeof(operating_pcs_data_t) - 4));
	
//	log_i((int8_t *)"\n [%s:%d] crc = %d \n", __func__, __LINE__, p_operating_data->crc);
    return 0;
}

/**
 * @brief   运行数据保存（写入文件）
 * @param   [in] p_fs 已打开的文件指针 
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t operating_pcs_data_save(fs_t *p_fs)
{
    operating_pcs_data_t *p_operating_data = operating_pcs_data_get();

    if (p_operating_data == NULL)
    {
        return -1;
    }

    sdk_fs_write(p_fs, p_operating_data, sizeof(operating_pcs_data_t));
	
  //  log_i((int8_t *)"\n [%s:%d] write, operating_data_t = %d --------------------------------\n", __func__, __LINE__, sizeof(operating_pcs_data_t));
	return 0;
}

