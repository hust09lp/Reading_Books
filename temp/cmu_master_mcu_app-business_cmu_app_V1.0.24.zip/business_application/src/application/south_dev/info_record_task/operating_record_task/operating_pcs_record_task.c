/*****************************************************************************
* File Name        : operating_record_task.c            
* Description      : 运行数据记录任务
* Original Author  : liangguyao
* date             : 2023.02.15
******************************************************************************/

#include "operating_pcs_record_task.h"
#include "operating_pcs_data_handle.h"
#include "operating_record_task.h"
#include "sofar_log.h"
#include "sdk_store.h"
#include "sofar_errors.h"
#include "sdk_shm.h"

#include <pthread.h>
//#include <time.h>    /* time_t, struct tm, time, localtime */
#include <unistd.h>
//#include <stdio.h>
#include <string.h>
//#include <sys/time.h>


#define OPERATING_RECORD_INVALID_YEAR    37  // 同步sdk_public里的rtc时间入参合法性/有效性检查的年份

static sdk_rtc_t g_operating_time_record = {0, 0, 0, 0, 0, 0, 0};  // 保存上次记录的时间点
static uint8_t g_minute_interval = 5;  // 3min~60min可设置，默认5min


/**
 * @brief   获取运行数据存储的分钟间隔
 * @param   无
 * @return  [uint8_t] 返回分钟间隔
 */
uint8_t operating_pcs_time_minute_interval_get(void)
{
    return g_minute_interval;
}

/**
 * @brief   设置运行数据存储的分钟间隔
 * @param   [in] value 要设置的分钟间隔
 * @note    取值范围：3min ~ 60min
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t operating_pcs_time_minute_interval_set(uint8_t value)
{
    int32_t ret = 0;
    if (value < OPERATING_PCS_RECORD_MIN_INTERVAL || value > OPERATING_PCS_RECORD_MAX_INTERVAL)
    {
        ret = -1;
    }
    else
    {
        g_minute_interval = value;
    }

    return ret;
}

/**
 * @brief   获取保存上次记录时间点的全局变量的指针
 * @param   无
 * @return  (static修饰的)全局变量的地址作为返回值
 */
static sdk_rtc_t *operating_time_record_get(void)
{
    return (&g_operating_time_record);
}

/**
 * @brief   运行数据时间记录
 * @param   [in] p_rtc_time 当前的RTC时间结构体指针
 * @note    g_operating_time_record 记录保存运行的时间
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
static int32_t operating_time_record_set(sdk_rtc_t *p_rtc_time)
{
    int32_t ret = 0;
    sdk_rtc_t *p_record = operating_time_record_get();

    if (p_record == NULL || p_rtc_time == NULL)
    {
        ret = -1;
    }
    else
    {
        p_record->tm_year = p_rtc_time->tm_year;
        p_record->tm_mon = p_rtc_time->tm_mon;
        p_record->tm_day = p_rtc_time->tm_day;
        p_record->tm_hour = p_rtc_time->tm_hour;
        p_record->tm_min = p_rtc_time->tm_min;
        p_record->tm_sec = p_rtc_time->tm_sec;
        p_record->tm_weekday = p_rtc_time->tm_weekday;
    }

    return ret;
}


/**
 * @brief   删除过期文件
 * @param   path 路径
 * @param   date 过期日期
 * @return  
 */
static int32_t del_operating_file(const char *path, const char *date_str){

    DIR *d;
    struct dirent *dir;
	char file_path[PATH_FILE_MAX_LEN]={0};

	if ((NULL == path) || (NULL == date_str))
	{
		return 0;
	}
	
    d = opendir(path);
    if (d) 
	{
        while ((dir = readdir(d)) != NULL) 
		{
            if (!strcmp(dir->d_name, ".") || !strcmp(dir->d_name, "..")) 
			{
                // skip self and parent
                continue;
            }
			
			if (strcmp(dir->d_name, date_str) < 0) 
			{
				snprintf(file_path, sizeof(file_path), "%s/%s", path, dir->d_name);
				sdk_fs_remove((const int8_t *)file_path);
				log_i((int8_t *)"\n [%s:%d] remove %s \n", __func__, __LINE__, file_path);
			}			
      
        }
        closedir(d);
    }
	return 1;

}

/**
 * @brief  	将时间戳（秒）转换成sdk_rtc_t结构体时间
 * @param  	[in] p_timestamp    时间戳（秒）
 * @param  	[out] p_time        sdk_rtc_t结构体时间
 * @return 	无
 */
static void timestamp_to_date_time(const time_t *p_timestamp, sdk_rtc_t *p_time)
{
    struct tm *p_data;

    p_data = localtime(p_timestamp);
    p_time->tm_year = (uint8_t)(p_data->tm_year - 100);
    p_time->tm_mon  = (uint8_t)(p_data->tm_mon + 1);
    p_time->tm_day  = (uint8_t)(p_data->tm_mday);
    p_time->tm_hour = (uint8_t)(p_data->tm_hour);
    p_time->tm_min  = (uint8_t)(p_data->tm_min);
    p_time->tm_sec  = (uint8_t)(p_data->tm_sec);
}

/**
 * @brief  	将sdk_rtc_t结构体时间转换成时间戳（秒）
 * @param  	[in] p_time         sdk_rtc_t结构体时间
 * @param  	[out] p_timestamp   时间戳（秒）
 * @return 	无
 */
static void date_time_to_timestamp(sdk_rtc_t *p_time, time_t *p_timestamp)
{
    struct tm data;

    memset(&data, 0, sizeof(data));
    data.tm_year = (int32_t)(p_time->tm_year) + 100;
    data.tm_mon  = (int32_t)(p_time->tm_mon - 1);
    data.tm_mday = (int32_t)(p_time->tm_day);
    data.tm_hour = (int32_t)(p_time->tm_hour);
    data.tm_min  = (int32_t)(p_time->tm_min);
    data.tm_sec  = (int32_t)(p_time->tm_sec);
    *p_timestamp = mktime(&data) - 8 * 60 * 60;
}

static void file_management(const char *path,sdk_rtc_t *p_rtc_time)
{
	char file_name[PATH_FILE_MAX_LEN]={0};
	char date_str[12]={0};
	int interval = 0;
	time_t acl_ts;
	sdk_rtc_t expire_date;
    DIR *d;
    struct dirent *dir;
	constant_parameter_data_t *constant_parameter = sdk_shm_constant_parameter_data_get();
	
	if ((constant_parameter->storage_duration_operation_data >= 180) && (constant_parameter->storage_duration_operation_data <= 366))
	{
		interval = constant_parameter->storage_duration_operation_data;
	}
	else
	{
		interval = 180;
	}
	
	date_time_to_timestamp(p_rtc_time, &acl_ts);
	acl_ts = acl_ts-(interval * 24 * 60 * 60);
	timestamp_to_date_time(&acl_ts, &expire_date);	
	snprintf(date_str, sizeof(date_str),  "%04d%02d%02d", expire_date.tm_year + 2000, expire_date.tm_mon, expire_date.tm_day);
	printf("date_str %s\n",date_str);
	
    d = opendir(path);
    if (d) {
        while ((dir = readdir(d)) != NULL) {
            if (!strcmp(dir->d_name, ".") || !strcmp(dir->d_name, "..")) {
                // skip self and parent
                continue;
            }
			
			if(dir->d_type == 4)
			{
				//printf("++++%s\n", dir->d_name);
				snprintf(file_name, sizeof(file_name), PATH_OPERATING_PCS_RECORD_FOLDER "/%s", dir->d_name);
				del_operating_file(file_name, date_str);
				
				//find_file(file_name, files, &file_count);
			}
		}
        closedir(d);
    }


}


/**
 * @brief   运行数据记录初始化
 * @param   无
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t operating_pcs_record_init(void)
{
    sdk_rtc_t rtc_time;
    int32_t ret;
	int32_t value;
	constant_parameter_data_t *constant_parameter = sdk_shm_constant_parameter_data_get();

	value = constant_parameter->storage_freq_operation_data;
	
	if (value > 2 && (value < 61))
	{
		operating_time_minute_interval_set(value);
	}

    operating_pcs_data_init();
    ret = sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
 
    if (ret != SF_OK)
    {
        log_e((int8_t *)"\n [%s:%d] sdk_rtc_get fail \n", __func__, __LINE__);
        return ret;
    }

    operating_time_record_set(&rtc_time);

    return ret;
}

/**
 * @brief          检查SD卡是否挂载
 * @return         true：挂载 false：没有挂载
 */
static bool sd_mount_status(void)
{
    char cmd[256] = {0};
    char tmp_buff[32] = {0};
    FILE *fp = NULL;

    snprintf(cmd, 256, "df | grep \"dev/mmcblk0p1\" | awk '{print $1}'");
    fp = popen(cmd,"r");
    if(fp == NULL)
    {
        return false;
    }
    fread(tmp_buff, 1, sizeof(tmp_buff), fp);
    if(!strncmp(tmp_buff, "/dev/mmcblk0p1", strlen("/dev/mmcblk0p1")))
    {
        pclose(fp);
        return true;
    }
    pclose(fp);
    return false;
}

/**
 * @brief   运行数据处理
 * @param   [in] p_rtc_time RTC时间结构体指针
 * @return  [int32_t] 执行结果
 * @retval  SF_OK: 成功
 * @retval  SF_ERR_NO_OBJECT: 对象不存在
 * @retval  SF_ERR_OPEN: 打开失败
 * @retval  SF_ERR_CLOSE: 关闭失败
 * @retval  SF_ERR_NDEF: 未定义的错误
 */
static int32_t operating_record_handle(sdk_rtc_t *p_rtc_time)
{
    char file_name[PATH_FILE_MAX_LEN];
    fs_t *p_fs = NULL;
    int32_t ret = 0;
    sdk_rtc_t *p_record;
    bool sd_sta = false;

    /* 运行数据更新 */
    operating_pcs_data_update(p_rtc_time);

    /* 检测SD卡是否存在 */
    sd_sta = sd_mount_status();
    if(sd_sta == false)
    {
       log_i((int8_t *)"\n pcs TF_CARD does not exist!!! \n"); 
       return SF_ERR_NO_OBJECT; 
    }

    /* 判断/media/文件夹是否存在 */
    ret = sdk_fs_access((const int8_t *)(PATH_OPERATING_PCS_RECORD_FOLDER), FS_F_OK);
    if (ret != SF_OK)
    {
        log_i((int8_t *)"\n [%s:%d] %s Folder does not exist. \n", __func__, __LINE__,PATH_OPERATING_PCS_RECORD_FOLDER);
     //   return SF_ERR_NO_OBJECT;
        ret = sdk_fs_mkdir((const char *)PATH_OPERATING_PCS_RECORD_FOLDER, 755);
        if (ret < 0)
        {
            log_i((int8_t *)"\n [%s:%d] sdk_fs_mkdir fail, ret = %d \n", __func__, __LINE__, ret);
        }

    }

    /* 需检测年文件夹是否存在 */
    snprintf(file_name, sizeof(file_name), PATH_OPERATING_PCS_RECORD_FOLDER "%04d/", p_rtc_time->tm_year + 2000);
    ret = sdk_fs_access((const int8_t *)(file_name), FS_F_OK);
    if (ret != SF_OK)	//文件夹不存在,先创建文件夹
    {
        log_i((int8_t *)"\n [%s:%d] %04d Folder does not exist! \n", __func__, __LINE__, p_rtc_time->tm_year + 2000);
        ret = sdk_fs_mkdir(file_name, 755);
        if (ret < 0)
        {
            log_i((int8_t *)"\n [%s:%d] sdk_fs_mkdir fail. %s \n", __func__, __LINE__, file_name);
            return SF_ERR_NDEF;
        }
        else
        {
            log_i((int8_t *)"\n [%s:%d] sdk_fs_mkdir succeed. ret = %d\n", __func__, __LINE__, ret);
        }
    }

    /* 运行数据写入文件保存 */
    p_record = operating_time_record_get();
    if (p_record == NULL)
    {
        return SF_ERR_NDEF;
    }
    snprintf(file_name, sizeof(file_name), PATH_OPERATING_PCS_RECORD_FOLDER "%04d/%04d%02d%02d", \
            p_record->tm_year + 2000, p_record->tm_year + 2000, \
            p_record->tm_mon, p_record->tm_day);
	
    ret = sdk_fs_access((const int8_t *)(file_name), FS_F_OK);
    if (ret != SF_OK)	//文件不存在
    {
    	 file_management(PATH_OPERATING_PCS_RECORD_FOLDER, p_record);
    }	
	
    p_fs = sdk_fs_open((const int8_t *)file_name, FS_OPEN_APPEND);
    if (p_fs == NULL)
    {
        log_i((int8_t *)"\n [%s:%d] sdk_fs_open operating record file fail. \n", __func__, __LINE__);
        return SF_ERR_OPEN;
    }
    operating_pcs_data_save(p_fs);
    fsync(fileno(&p_fs->file));
    ret = sdk_fs_close(p_fs);
    if (ret < 0)
    {
        log_i((int8_t *)"\n [%s:%d] sdk_fs_close fail! ret = %d \n", __func__, __LINE__, ret);
        return SF_ERR_CLOSE;
    }

    return SF_OK;
}

/**
 * @brief   运行数据记录管理任务
 * @param   无
 * @return  无
 * @note    存储天数（≥30，≤360）和频率（3min~60min）可设置
 */
void operating_pcs_record_task(void)
{
    sdk_rtc_t rtc_time;
    int32_t ret;
	constant_parameter_data_t *constant_parameter = sdk_shm_constant_parameter_data_get();
    uint8_t minute_interval =  constant_parameter->storage_freq_operation_data;
    sdk_rtc_t *p_record = operating_time_record_get();

    if (p_record == NULL)
    {
    	
        return;
    }
	
    ret = sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
    if (ret == SF_OK)
    {
        if (rtc_time.tm_year > OPERATING_RECORD_INVALID_YEAR)
        {
            log_i((int8_t *)"\n [%s:%d] error, year = %d \n", __func__, __LINE__, rtc_time.tm_year);
            return;
        }
        else if (p_record->tm_year > OPERATING_RECORD_INVALID_YEAR)
        {
            /* 从未同步的时间变化为同步后的时间时，设置一次运行时间 */
            operating_time_record_set(&rtc_time);
        }

		if (minute_interval < 2)
		{
			minute_interval = 5;
		}
        if((rtc_time.tm_min % minute_interval == 0) && (rtc_time.tm_min != p_record->tm_min))
        {
            operating_time_record_set(&rtc_time);
            ret = operating_record_handle(&rtc_time);
            if (ret < SF_OK)
            {
                log_i((int8_t *)"\n [%s:%d] operating_record_handle, ret = %d. \n", __func__, __LINE__, ret);
            }
        }
    }
    else
    {
        log_i((int8_t *)"\n [%s:%d] sdk_rtc_get fail. \n", __func__, __LINE__);
    }
}

/** 
 * @brief   运行记录线程
 * @param
 * @return 	void
 */
void *thread_operating_pcs_record(void *arg)
{
    operating_pcs_record_init();
	
    while (1)
    {

        operating_pcs_record_task();

        sleep(1); // sdk_delay_ms(1000);	// 1s
    }
    
    pthread_exit(NULL);
}

