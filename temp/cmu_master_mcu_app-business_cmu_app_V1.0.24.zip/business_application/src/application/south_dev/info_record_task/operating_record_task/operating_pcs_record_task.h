/*****************************************************************************
* File Name          : operating_pcs_record_task.h            
* Description        : PCS运行数据记录任务内外部通讯接口
* Original Author    : 
* date               : 2023.02.15
******************************************************************************/

#ifndef __OPERATING_PCS_RECORD_TASK_H__ 
#define __OPERATING_PCS_RECORD_TASK_H__ 

#include "data_types.h"


#define OPERATING_PCS_RECORD_MIN_INTERVAL  3   // 3min
#define OPERATING_PCS_RECORD_MAX_INTERVAL  60  // 60min


/**
 * @brief   获取运行数据存储的分钟间隔
 * @param   无
 * @return  [uint8_t] 返回分钟间隔
 */
uint8_t operating_pcs_time_minute_interval_get(void);

/**
 * @brief   设置运行数据存储的分钟间隔
 * @param   [in] value 要设置的分钟间隔
 * @note    取值范围：3min ~ 60min
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t operating_pcs_time_minute_interval_set(uint8_t value);

/** 
 * @brief   运行记录线程
 * @param
 * @return 	void
 */
void *thread_operating_pcs_record(void *arg);


#endif  /* __OPERATING_RECORD_TASK_H__ */