/*****************************************************************************
* File Name          : battery_fault_record_export.h            
* Description        : 电池故障录波文件U盘导出接口
* Original Author    : liangguyao
* date               : 2023.02.24
******************************************************************************/

#ifndef __BATTERY_FAULT_RECORD_EXPORT_H__ 
#define __BATTERY_FAULT_RECORD_EXPORT_H__ 

#include "data_types.h"



#define DATA_LENGTH_MAX       600       /* 一个id包含的最大点数(单位: U16) */


/**
 * @brief     电池故障录波文件U盘导出
 * @note      电池故障录波正在存储过程中，不允许读取故障录波
 * @param     [in] p_path_des 目标文件路径
 * @return    [int32_t] 执行结果
 * @retval    0: 成功
 * @retval    -1: 失败
 */
int32_t battery_fault_record_data_export(void *p_path_des);


#endif  /* __BATTERY_FAULT_RECORD_EXPORT_H__ */