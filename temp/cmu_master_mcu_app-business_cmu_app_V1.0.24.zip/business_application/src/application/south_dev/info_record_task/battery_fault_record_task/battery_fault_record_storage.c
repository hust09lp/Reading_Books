/*****************************************************************************
* File Name        : battery_fault_record_storage.c            
* Description      : 电池故障录波任务存储
* Original Author  : liangguyao
* date             : 2023.02.24
******************************************************************************/


#include "battery_fault_record_storage.h"
#include "sofar_log.h"

#include <string.h>
#include <errno.h>
#include <stdbool.h>


#define PATH_FILE_MAX_LEN    (60)    //文件路径的最大长度


battery_fault_record_info_t    g_battery_fault_record_info;    //电池故障录波信息（包含配置和索引的信息）


/**
 * @brief   获取电池故障录波信息全局变量的指针
 * @param   无
 * @return  （static修饰的）全局变量的地址作为返回值
 */
battery_fault_record_info_t *battery_fault_record_info_get(void)
{
    return (&g_battery_fault_record_info);
}


/**
 * @brief   文件名检查
 * @param   [in] p_file 文件名，不包含文件所在的路经
 * @return  [int32_t] 执行结果
 * @retval  0: 正确的文件名（年月日时分秒，例如“20230306120001”）
 * @retval  -1: 错误的文件名
 */
static int32_t file_name_check(const int8_t *p_file)
{
    uint32_t len;
    int8_t *p_file_name;
    int8_t temp;
    int i;
    int32_t ret;

    if (p_file == NULL)
    {
        log_i((int8_t *)"\n [%s:%d] null pointer!\n", __func__, __LINE__);
        return (-1);
    }

    len = strlen((const char *)p_file);
    if (len != INDEX_NAME_LENGTH)
    {
        log_i((int8_t *)"\n [%s:%d] error len \n", __func__, __LINE__);
        return (-1);
    }

    p_file_name = (int8_t *)p_file;
    for (i = 0; i < INDEX_NAME_LENGTH; i++)
    {
        temp = *(p_file_name + i);
        if ( temp < '0' || temp > '9')
        {
            break;
        }
    }
    if (i == INDEX_NAME_LENGTH)
    {
        ret = 0;
    }
    else
    {
        ret = -1;
    }

    return ret;
}

/**
 * @brief   电池故障录波存储文件增加处理
 * @param   [in] p_file 文件名，不包含文件所在的路经
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
static int32_t battery_fault_record_add_file_process(const int8_t* p_file)
{
    int32_t ret;
    battery_fault_record_info_t *p_data = battery_fault_record_info_get();
    uint8_t next_point;
    int8_t file_path[PATH_FILE_MAX_LEN];  //要删除的文件名，包含文件所在的路经

    if (p_data == NULL)
    {
        log_i((int8_t *)"\n [%s:%d] null pointer!\n", __func__, __LINE__);
        return (-1);
    }

    /* 判断文件名格式是否正确 */
    ret = file_name_check(p_file);
    if (ret < 0)
    {
        log_i((int8_t *)"\n [%s:%d] file name error!\n", __func__, __LINE__);
        return (-1);
    }

    next_point = p_data->battery_fault_record_config.next_point;
    if(next_point >= p_data->battery_fault_record_config.max_num)
    {
        next_point = 0;
    }

    if (p_data->battery_fault_record_config.saved_num >= p_data->battery_fault_record_config.max_num)
    {
        /* 存储条数已达设置的最大值，删除存储最早的那个电池录波记录文件 */
        snprintf((char *)file_path, sizeof(file_path), PATH_BATTERY_FAULT_RECORD_FOLDER "%s", \
                &(p_data->battery_fault_record_index[next_point].name[0]));
        ret = sdk_fs_remove((const int8_t *)file_path);
        if (ret < 0)
        {
            log_i((int8_t *)"\n [%s:%d] remove file error, path: %s \n", __func__, __LINE__, file_path);
        }
    }

    /* 存储新创建的那条电池录波记录索引 */
    snprintf((char *)(&(p_data->battery_fault_record_index[next_point].name[0])), NAME_BUFF_MAX_LENGTH, "%s", p_file);

    /* 更新索引指向 */
    p_data->p_current_index = &(p_data->battery_fault_record_index[next_point]);

    next_point++;
    if(next_point >= p_data->battery_fault_record_config.max_num)
    {
        next_point = 0;
    }
    p_data->battery_fault_record_config.next_point = next_point;

    battery_fault_record_info_write(p_data);

    return (0);
}

/**
 * @brief   打开电池故障录波存储文件
 * @param   [in] p_file 文件名，不包含文件所在的路经
 * @param   [in] mode 在文件中的偏移地址
 * @return  [fs_t] 执行结果
 * @retval  >0: 成功，返回指向该流的文件指针
 * @retval  NULL: 失败
 */
fs_t *battery_fault_record_open(const int8_t* p_file, uint16_t mode)
{
    fs_t *p_fs = NULL;
    int32_t ret;
    bool new_file = true;
    int8_t file_path[PATH_FILE_MAX_LEN];  //要打开的文件名，包含文件所在的路经

    if (p_file == NULL)
    {
        log_i((int8_t *)"\n [%s:%d] null pointer!\n", __func__, __LINE__);
        return (p_fs);
    }

    /* 判断文件名格式是否正确 */
    ret = file_name_check(p_file);
    if (ret < 0)
    {
        log_i((int8_t *)"\n [%s:%d] file name error!\n", __func__, __LINE__);
        return (p_fs);
    }

    snprintf((char *)file_path, sizeof(file_path), PATH_BATTERY_FAULT_RECORD_FOLDER "%s", p_file);

    /* 判断文件是否已存在 */
    ret = sdk_fs_access(file_path, FS_F_OK);
    if (ret == 0 || mode == FS_READ)
    {
        new_file = false;
    }

    p_fs = sdk_fs_open(file_path, mode);
    if (p_fs == NULL)
    {
        log_i((int8_t *)"\n [%s:%d] null pointer!\n", __func__, __LINE__);
        return (p_fs);
    }

    if (new_file)
    {
        battery_fault_record_add_file_process(p_file);
    }

    return (p_fs);
}

/**
 * @brief   关闭电池故障录波存储文件
 * @param   [in] p_fs 文件句柄
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t battery_fault_record_close(fs_t* p_fs)
{
    int32_t ret;

    if (p_fs == NULL)
    {
        log_i((int8_t *)"\n [%s:%d] null pointer!\n", __func__, __LINE__);
        return (-1);
    }

    ret = sdk_fs_close(p_fs);
    if (ret < 0)
    {
        log_i((int8_t *)"\n [%s:%d] close fail \n", __func__, __LINE__);
        return (-1);
    }

    return (0);
}

/**
 * @brief   读取电池故障录波数据
 * @param   [in] p_fs 文件句柄
 * @param   [in] offset 在文件中的偏移地址
 * @param   [in] length 要读取的数据长度
 * @param   [out] p_buff 读取的录波数据
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t battery_fault_record_read(fs_t* p_fs, uint32_t offset, uint32_t length, void* p_buff)
{
    int32_t ret;

    if((p_fs == NULL) || (p_buff == NULL))
    {
        log_i((int8_t *)"\n [%s:%d] null pointer!\n", __func__, __LINE__);
        return (-1);
    }

    ret = sdk_fs_lseek(p_fs, offset);
    if (ret < 0)
    {
        log_i((int8_t *)"\n [%s:%d] lseek error!\n", __func__, __LINE__);
        return (-1);
    }

    ret = sdk_fs_read(p_fs, p_buff, length);
    if (ret != length)
    {
        log_i((int8_t *)"\n [%s:%d] read error!\n", __func__, __LINE__);
        return (-1);
    }

    return (0);
}

/**
 * @brief   存储电池故障录波数据
 * @param   [in] p_fs 文件句柄
 * @param   [in] offset 写入位置在文件中的偏移地址
 * @param   [in] length 写入长度
 * @param   [in] p_buff 写入的录波数据
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t battery_fault_record_write(fs_t* p_fs, uint32_t offset, uint32_t length, void* p_buff)
{
    int32_t ret;

    if((p_fs == NULL) || (p_buff == NULL))
    {
        log_i((int8_t *)"\n [%s:%d] null pointer!\n", __func__, __LINE__);
        return (-1);
    }

    ret = sdk_fs_lseek(p_fs, offset);
    if (ret < 0)
    {
        log_i((int8_t *)"\n [%s:%d] lseek error!\n", __func__, __LINE__);
        return (-1);
    }

    ret = sdk_fs_write(p_fs, p_buff, length);
    if (ret != length)
    {
        log_i((int8_t *)"\n [%s:%d] write error!\n", __func__, __LINE__);
        return (-1);
    }

    return (0);
}

/**
 * @brief   写电池故障录波的存储信息，应用层需要自己更新信息
 * @note    写电池故障录波的存储信息，如果电池故障录波信息增加，则相应更新索引信息和存储信息
 *          注意saved_num <= BATTERY_FAULT_RECORD_MAX_NUM
 * @param   [in] p_battery_fault_record_info 更新后要写入的文件信息
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t battery_fault_record_info_write(battery_fault_record_info_t* p_battery_fault_record_info)
{
    fs_t *p_fs = NULL;

    if(p_battery_fault_record_info == NULL)
    {
        log_i((int8_t *)"[%s:%s:%d] %s\n", __FILE__, __func__, __LINE__, strerror(errno));
        return (-1);
    }

    if (BATTERY_FAULT_RECORD_FILE_VALID != p_battery_fault_record_info->battery_fault_record_config.flag)
    {
        log_i((int8_t *)"\n [%s:%d] flag error!\n", __func__, __LINE__);
        return (-1);
    }

    /* 打开电池故障录波信息文件（包含配置和索引信息的文件） */
    p_fs = sdk_fs_open((const int8_t *)PATH_BATTERY_FAULT_RECORD_INFO, FS_WRITE);
    if(p_fs == NULL)
    {
        log_i((int8_t *)"[%s:%s:%d] %s\n", __FILE__,__func__, __LINE__, strerror(errno));
        return (-1);
    }

    /* 写电池故障录波信息结构体 */
    battery_fault_record_write(p_fs, 0, sizeof(battery_fault_record_info_t), p_battery_fault_record_info);

    /* 关闭电池故障录波信息文件（包含配置和索引信息的文件） */
    sdk_fs_close(p_fs);

    return (0);
}
