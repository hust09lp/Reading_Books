/*****************************************************************************
* File Name          : battery_fault_record_export.c            
* Description        : 电池故障录波数据U盘导出
* Original Author    : liangguyao
* date               : 2023.02.24
******************************************************************************/


#include "battery_fault_record_export.h"
#include "battery_fault_record_storage.h"
#include "sofar_log.h"
#include <errno.h>
#include <string.h>


/**
 * @brief     电池故障录波文件U盘导出
 * @note      电池故障录波正在存储过程中，不允许读取故障录波
 * @param     [in] p_path_des 目标文件路径
 * @return    [int32_t] 执行结果
 * @retval    0: 成功
 * @retval    -1: 失败
 */
int32_t battery_fault_record_data_export(void *p_path_des)
{
    fs_t *p_fs_src = NULL;
    fs_t *p_fs_des = NULL;
    FILE *p_fp_des = NULL;
    int32_t ret;
    uint8_t read_point = 0;
    uint8_t file_num = 0;
    battery_fault_record_info_t *p_info = battery_fault_record_info_get();
    battery_fault_record_config_t *p_config_data;
    uint16_t i;
    
    if (p_path_des == NULL || p_info == NULL)
    {
        log_i((int8_t *)"[%s:%s:%d] %s\n", __FILE__, __func__, __LINE__, strerror(errno));
        return (-1);
    }

    if ((p_info->battery_fault_record_config.saved_num == 0) || (p_info->battery_fault_record_config.max_num == 0))
    {
        log_i((int8_t *)"[%s:%s:%d] saved_num = %d, max_num = %d \n", __FILE__, __func__, __LINE__, \
                p_info->battery_fault_record_config.saved_num, p_info->battery_fault_record_config.max_num);
        return (-1);
    }

    /* 打开目标文件 */
    p_fs_des = sdk_fs_open((const int8_t *)p_path_des, FS_CREATE_ALWAYS);
    if (p_fs_des == NULL)
    {
        log_i((int8_t *)"[%s:%s:%d] %s\n", __FILE__, __func__, __LINE__, strerror(errno));
        return (-1);
    }
    p_fp_des = &(p_fs_des->file);

    /* 输入首行标题栏 */
    fprintf(p_fp_des, "%s,%s,%s,", "number", "index name", "id"); 
    for(i = 0; i < DATA_LENGTH_MAX; i++)
    {
      fprintf(p_fp_des, "date_%d,", i);
    }
    fprintf(p_fp_des, "%s\n", "end");

    p_config_data = &(p_info->battery_fault_record_config);
    /* 录波数据已存满，下一次存储区域处于起始存储区时，最新那条索引处于索引区末尾 */
    if (((p_config_data->saved_num) == (p_config_data->max_num)) && (p_config_data->next_point) == 0)
    {
        read_point = p_config_data->max_num - 1;
    }
    else if ((p_config_data->next_point) > 0)
    {
        /* 起始读取区域 = 当前已存的最新那条索引的位置(即 下一次存储故障录波存放区-1) */
        read_point = (p_config_data->next_point) - 1;
    }

    /* 输入数据 */
    for (file_num = 0; file_num < (p_info->battery_fault_record_config.saved_num); file_num++)
    {
        p_fs_src = battery_fault_record_open((const int8_t *)(&(p_info->battery_fault_record_index[read_point].name[0])), FS_READ);
        if (p_fs_src == NULL)
        {
            log_i((int8_t *)"[%s:%s:%d] %s\n", __FILE__, __func__, __LINE__, strerror(errno));
            fprintf(p_fp_des, "open %s error\n", p_info->battery_fault_record_index[read_point].name);
        }
        else
        {
            /* 根据具体的格式处理文件数据 待定 */

            ret = battery_fault_record_close(p_fs_src);
            if (ret < 0)
            {
                log_i((int8_t *)"[%s:%s:%d] %s\n", __FILE__, __func__, __LINE__, strerror(errno));
            }
            fprintf(p_fp_des, "%s\n", "end");
        }

        if (read_point > 0)
        {
            read_point--;
        }
        else  // 循环读取 0-->max-->0（0-->9-->0）
        {
            read_point = p_config_data->max_num - 1;
        }
    }

    sdk_fs_close(p_fs_des);

    return 0;
}

