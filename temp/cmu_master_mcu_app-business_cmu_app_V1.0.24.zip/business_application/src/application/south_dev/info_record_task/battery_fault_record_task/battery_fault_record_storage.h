/*****************************************************************************
* File Name          : battery_fault_record_storage.h            
* Description        : 电池故障录波数据存储外部接口
* Original Author    : liangguyao
* date               : 2023.02.24
******************************************************************************/

#ifndef __BATTERY_FAULT_RECORD_STORAGE_H__ 
#define __BATTERY_FAULT_RECORD_STORAGE_H__ 

#include "data_types.h"
#include "sdk_fs.h"


#define PATH_BATTERY_FAULT_RECORD_FOLDER    "/user/data/battery_record/"        // 存储电池故障录波文件的文件夹
#define PATH_BATTERY_FAULT_RECORD_INFO      "/user/data/battery_record/info"    // 电池故障录波信息文件（包含配置和索引信息的文件）


#define BATTERY_FAULT_RECORD_MAX_NUM        10      // 存储最大故障录波条数
#define INDEX_NAME_LENGTH                   14      // 索引名称的长度  单位:字节
#define NAME_BUFF_MAX_LENGTH                15      // 字符串格式的索引名称(产生故障录波的时刻)最大长度 + 1个字节的结束符  单位:字节

#define STORAGE_SPACE_MAX                   12000   // 每条故障录波数据的最大存储空间 待确定

#define BATTERY_FAULT_RECORD_FILE_VALID     0x55AA  // 故障录波文件有效 


#pragma pack(push)
#pragma pack(1)

/* 电池故障录波配置信息 */
typedef struct
{
    uint16_t flag;                    // 录波配置文件有效标志位
    uint8_t  max_num;                 // 故障录波最大存储数目
    uint8_t  saved_num;               // 目前已存储的条数
    uint8_t  next_point;              // 下一次存储故障录波存放在哪个区
}battery_fault_record_config_t;

/* 电池故障录波索引信息 */
typedef struct
{
    uint8_t  name[NAME_BUFF_MAX_LENGTH];
}battery_fault_record_index_t;

typedef struct
{
    battery_fault_record_config_t battery_fault_record_config;                                 //配置信息
    battery_fault_record_index_t  battery_fault_record_index[BATTERY_FAULT_RECORD_MAX_NUM];    //索引信息
    battery_fault_record_index_t  *p_current_index;                                            //当前操作索引指向位置
}battery_fault_record_info_t;

#pragma pack(pop)


/**
 * @brief   获取电池故障录波信息全局变量的指针
 * @param   无
 * @return  （static修饰的）全局变量的地址作为返回值
 */
battery_fault_record_info_t *battery_fault_record_info_get(void);

/**
 * @brief   打开电池故障录波存储文件
 * @param   [in] p_file 文件名，不包含文件所在的路经
 * @param   [in] mode 在文件中的偏移地址
 * @return  [fs_t] 执行结果
 * @retval  >0: 成功，返回指向该流的文件指针
 * @retval  NULL: 失败
 */
fs_t *battery_fault_record_open(const int8_t* p_file, uint16_t mode);

/**
 * @brief   关闭电池故障录波存储文件
 * @param   [in] p_fs 文件句柄
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t battery_fault_record_close(fs_t* p_fs);

/**
 * @brief   读取电池故障录波数据
 * @param   [in] p_fs 文件句柄
 * @param   [in] offset 在文件中的偏移地址
 * @param   [in] length 要读取的数据长度
 * @param   [out] p_buff 读取的录波数据
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t battery_fault_record_read(fs_t* p_fs, uint32_t offset, uint32_t length, void* p_buff);

/**
 * @brief   存储故障录波数据
 * @param   [in] p_fs 文件句柄
 * @param   [in] offset 写入位置在文件中的偏移地址
 * @param   [in] length 写入长度
 * @param   [in] p_buff 写入的录波数据
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t battery_fault_record_write(fs_t* p_fs, uint32_t offset, uint32_t length, void* p_buff);

/**
 * @brief   写电池故障录波的存储信息，应用层需要自己更新信息
 * @note    写电池故障录波的存储信息，如果电池故障录波信息增加，则相应更新索引信息和存储信息
 *          注意saved_num <= BATTERY_FAULT_RECORD_MAX_NUM
 * @param   [in] p_battery_fault_record_info 更新后要写入的文件信息
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t battery_fault_record_info_write(battery_fault_record_info_t* p_battery_fault_record_info);
#endif  /* __BATTERY_FAULT_RECORD_STORAGE_H__ */