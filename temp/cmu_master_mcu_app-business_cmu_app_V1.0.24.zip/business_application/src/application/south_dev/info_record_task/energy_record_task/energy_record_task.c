#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include <sys/stat.h>
#include "sdk_shm.h"
#include "data_shm.h"
#include "sdk_fs.h"
#include "sdk_public.h"
#include "sqlite3.h"
#include "sofar_log.h"
#include "energy_record_task.h"
#include "process_battery_read.h"
#include "sofar_errors.h"

//相关宏定义
#define PATH_ENERGY_GENERAL_DIR	 "/user/data/energy/"			// 电量存储总目录
static energy_record_task_t g_energy_record_task;      // 历史电量任务
#define ENERGY_DB "/user/data/energy/energy.db"

/**
 * @brief  创建数据库
 * @param  [in] 
 * @param  [in]
 * @param  [out]
 * @return 
 *
 */
static void create_energy_table(void)
 {
    sqlite3 *db;
    char *sql = "CREATE TABLE IF NOT EXISTS charge_data (date TEXT PRIMARY KEY, charge REAL, discharge REAL);";
    char *err_msg = 0;
    int rc = 0;
    
    rc = sqlite3_open(ENERGY_DB, &db);
    if( rc ) {
        ENERGY_DEBUG_LOG((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
        return;
    }
 
    rc = sqlite3_exec(db, sql, 0, 0, &err_msg);
    if (rc != SQLITE_OK) {
        ENERGY_DEBUG_LOG((int8_t *)"Failed to create table: %s\n", err_msg);
        sqlite3_free(err_msg);
    }
 
    sqlite3_close(db);
}

/**
 * @brief  设置上次数据记录时间
 * @param  [in] now 当前时间
 * @return 
 *
 */
static void set_last_savetime(sdk_rtc_t *now) 
{
	energy_time_t *p_time = NULL;
	
	p_time = &g_energy_record_task.last_save_time;
	
	if(NULL == p_time)
	{
		return;
	}
	
	p_time->year = now->tm_year + 2000;
	p_time->month = now->tm_mon;
	p_time->date = now->tm_day;
	p_time->hour = now->tm_hour;
	p_time->minute = now->tm_min;
	p_time->second = now->tm_sec;
}


/**
 * @brief  等待PCS连接通信正常
 * @param  [in] now 当前时间
 * @return false:通信异常；true:通信正常
 *
 */
static bool wait_pcs_connect(void)
{
    heartbeat_data_t *heartbeat_data = sdk_shm_heartbeat_data_get();
	if (heartbeat_data->comm_state[0] != 1)                            //PCS通信异常，直接返回
	{
		return false;
	}	

    return true;
}

/**
 * @brief  计算当前充放电量
 * @param  [out] *p_charge 当前充电量
 * @param  [out] *p_discharge 当前放电量
 * @return 
 *
 */
static void calculate_pcs_total_charge_discharge(uint32_t *p_charge, uint32_t *p_discharge)
{
	*p_charge = 0;
    *p_discharge = 0;
    power_module_telemetry_info_t *module_info = NULL;

    telemetry_data_t *pcs_telemetry_data = sdk_shm_pcs_telemetry_data_get();

    while (wait_pcs_connect() == false)
    {
        sleep(1);
    }

    while((*p_charge == 0) && (*p_discharge == 0)) //还没从CAN总线获取到数据
    {
        module_info = &pcs_telemetry_data->power_module_telemetry_info[0];
        *p_charge = (module_info->energy_charge_h << 16) | module_info->energy_charge_l;
        *p_discharge = (module_info->energy_discharge_h << 16) | module_info->energy_discharge_l;
        sleep(1);
    }

    // printf("[%s %d %d %d]\n", __func__, __LINE__,*p_charge, *p_discharge);
}


/**
 * @brief  系统rtc时间获取
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void get_energy_time(void)
{
    sdk_rtc_t now;
    energy_time_t *p_time = NULL;
 
    p_time = &g_energy_record_task.now_time;
    sdk_rtc_get(RTC_BIN_FORMAT, &now);
 
    if(NULL == p_time)
    {
        return;
    }
 
    p_time->year = now.tm_year + 2000;
    p_time->month = now.tm_mon;
    p_time->date = now.tm_day;
    p_time->hour = now.tm_hour;
    p_time->minute = now.tm_min;
    p_time->second = now.tm_sec;
}

/**
 * @brief  时间变化判断函数
 * @param  [in] updatetime 更新时的时间
 * @param  [in] lastsavetime 上一次保存的时间
 * @param  [out] none
 * @return 时间变化类型
 */
static uint8_t get_energy_timechange(energy_time_t updatetime, energy_time_t lastsavetime)
{
    if(updatetime.year < HISTORY_YEAR_START)    //年限不合理，不进行历史电量记录
    {
        return 0;
    }
 
    if (lastsavetime.year != updatetime.year)
    {
        return YEAR_CHANGE;
    }
    if (lastsavetime.month != updatetime.month)
    {
        return MONTH_CHANGE;
    }
    if (lastsavetime.date != updatetime.date)
    {
        return DAY_CHANGE;
    }
    if (lastsavetime.hour != updatetime.hour)
    {
        return HOUR_CHANGE;
    }
    return 0;
}

/**
 * @brief  检查充放电量数据库文件是否存在和有效
 * @param  [in] none
 * @param  [out] none
 * @return 0-数据库文件正常   -1-数据库文件异常
 */
static int32_t energy_db_file_check(void)
{
	int32_t ret = -1;
    struct stat file_stat;
	
    ret = sdk_fs_access((const int8_t *)ENERGY_DB, F_OK);
    if (ret == -1)  // 文件不存在，创建该文件
    {
		log_i((const int8_t*)"\nenergy.db is not exist\n");
		create_energy_table();
		return (0);
    }
	else     // 文件存在，检查文件大小是否为0
	{
        ret = stat(ENERGY_DB,&file_stat);
        if(ret != SF_OK)
        {
            create_energy_table();
		    return (0);
        }
        else
        {
            if(file_stat.st_size == 0)
            {
                sdk_fs_remove((const int8_t *)ENERGY_DB);
                create_energy_table();
            }
        }
	}
	return (0);
}

/**
 * @brief  更新数据库充放电量
 * @param  [in] date 日期(2023-07-11 10:00:00)
 * @param  [in] charge 充电量
 * @param  [in] discharge 放电量
 * @return 0失败 1成功
 */
static int32_t sqlite_db_update_data(uint8_t *date, uint32_t charge, uint32_t discharge)
{
    sqlite3 *db;
    int32_t rc;
    int32_t ret;
    int32_t retry_count=0;
 
    printf("[%s %d date %s %d %d]\n", __func__, __LINE__,date,charge, discharge);
    energy_db_file_check();
    rc = sqlite3_open(ENERGY_DB, &db);
    if( rc ) {
       ENERGY_DEBUG_LOG((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
       return(0);
    } else {
        char *sql = "INSERT OR REPLACE INTO charge_data (date, charge, discharge) VALUES (?, ?, ?);";
        sqlite3_stmt *stmt;
        sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
        sqlite3_bind_text(stmt, 1, (char *)date, -1, SQLITE_STATIC);
        sqlite3_bind_int(stmt, 2, charge);
        sqlite3_bind_int(stmt, 3, discharge);
 
        //printf( "sqlite3_step ret%d \n",sqlite3_step(stmt));
        while ((SQLITE_DONE != (ret = sqlite3_step(stmt))) && (retry_count < 5))
        {
            retry_count++;
            printf( "sqlite3_step err ret = %d \n",ret);
            usleep(1000);
        }
        sqlite3_file_control(db, ENERGY_DB, SQLITE_FCNTL_SYNC, NULL);
        sqlite3_finalize(stmt);
    }
    sqlite3_close(db);    

    return(1);
}

/**
 * @brief  更新上一次生产时间
 * @param  [in] updatetime 
 * @param  [out] lastproductiontime
 * @return none
 */
static void energy_update_lastsavetime(energy_time_t *p_last_time, energy_time_t update_time)
{
    if (NULL == p_last_time)
    {
        return;
    }
 
    memcpy(p_last_time, &update_time, sizeof(energy_time_t));
 
    return;
}

/**
 * @brief  电量统计线程
 * @param  [in] 
 * @param  [out] 
 * @return 
 */
static void energy_record_task(void)
{
    uint8_t change = 0;
    uint32_t charge = 0;
    uint32_t discharge = 0;
    uint8_t date[32] = {0};
    energy_record_task_t *p_task = NULL;
    energy_time_t *p_time = NULL;
    
    p_task = &g_energy_record_task;
    // 1、获取各电量实时值
   calculate_pcs_total_charge_discharge(&p_task->battery_energy_now.energy_container_charge, 
				&p_task->battery_energy_now.energy_container_dischar);


	if((p_task->battery_energy_now.energy_container_charge < p_task->battery_energy_last.energy_container_charge) ||
			(p_task->battery_energy_now.energy_container_dischar < p_task->battery_energy_last.energy_container_dischar))
	{
		return ; //异常,本次不更新
	}
	//获取这段时间的充放电量(当前总的减去之前记录的总计)
	charge = p_task->battery_energy_now.energy_container_charge - p_task->battery_energy_last.energy_container_charge;
    discharge = p_task->battery_energy_now.energy_container_dischar - p_task->battery_energy_last.energy_container_dischar;

    // 2、获取当前时间
    get_energy_time();
 
    change = get_energy_timechange(p_task->now_time, p_task->last_save_time);
    if(NO_CHANGE == change)
    {
        //五分钟更新一次当前小时电量记录
        if ((p_task->now_time.minute - p_task->last_save_time.minute) > 4)
        {	
            p_time = &g_energy_record_task.now_time;
 
            snprintf((char*)date, sizeof(date),"%04d-%02d-%02d %02d:00:00",p_time->year,\
                        p_time->month, p_time->date, p_time->hour);
         
			sqlite_db_update_data(date, charge, discharge);
            p_task->last_save_time.minute = p_task->now_time.minute;
        }
    } 
    
    if(change)
    {
        p_time = &g_energy_record_task.now_time;
 
        if (HOUR_CHANGE == change)
        { 
            //避免外部同步系统时间时出现00:00:00导致出现时间存储异常
            //如果出现则把当前的能量数据保存至本地零点
            if(!p_time->hour)
            {
                snprintf((char *)date, sizeof(date),"%04d-%02d-%02d %02d:00:00",p_time->year,\
                    p_time->month, p_time->date, p_time->hour);   
            }
            else
            {
                snprintf((char *)date, sizeof(date),"%04d-%02d-%02d %02d:00:00",p_time->year,\
                    p_time->month, p_time->date, p_time->hour - 1);   
            } 

			//时切换 将当前电量写入前一小时
			sqlite_db_update_data(date, charge, discharge);
			//更新到上一小时当天累计电量
			p_task->battery_energy_last.energy_container_charge = p_task->battery_energy_now.energy_container_charge;
			p_task->battery_energy_last.energy_container_dischar = p_task->battery_energy_now.energy_container_dischar;
    
        }else
        {
            //日、月、年切换 将当前记录写入前一小时记录
            //第二天时MCU传过来的当天充放电会清零，使用最近一次保存的电量记录到前面一小时
            snprintf((char *)date, sizeof(date),"%04d-%02d-%02d 23:00:00",p_task->last_save_time.year,
                                                                          p_task->last_save_time.month,
                                                                          p_task->last_save_time.date);
			sqlite_db_update_data(date,charge, discharge);
			p_task->battery_energy_last.energy_container_charge = p_task->battery_energy_now.energy_container_charge;
			p_task->battery_energy_last.energy_container_dischar = p_task->battery_energy_now.energy_container_dischar;
        }
        //更新数据
        energy_update_lastsavetime(&p_task->last_save_time, p_task->now_time);    // 更新时间指针
        //time
    }    
}


/**
 * @brief  获取当前小时的数据库数据，如果有则作为基质，否则读取电池实时数据作为基值
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
int32_t select_charge_discharge(uint8_t *date, uint32_t *charge, uint32_t *discharge)
{
	sqlite3 *db;
	sqlite3_stmt *stmt;
	int32_t rc;
	int32_t i=0;
	char sql[256] = {0};

	rc = sqlite3_open("/user/data/energy/energy.db", &db);
	if( rc ) {
	   printf("Can't open database: %s\n", sqlite3_errmsg(db));
	   return(0);
	} 
    else 
    {
		snprintf((char*)sql, sizeof(sql), "SELECT strftime('%%Y', date), charge, discharge FROM charge_data  WHERE date = '%s';",date);
		ENERGY_DEBUG_LOG((int8_t *)"sql:%s\n",sql);
		sqlite3_prepare_v2(db, sql, -1, &stmt, 0);

		while (sqlite3_step(stmt) == SQLITE_ROW) 
		{
			*charge = sqlite3_column_int(stmt, 1);
			*discharge = sqlite3_column_int(stmt, 2);
			i++;
		}
	}
	
	ENERGY_DEBUG_LOG((int8_t *)"Found %d pieces of data\n",i);
    sqlite3_finalize(stmt);
	sqlite3_close(db);	
    return(1);
}


/**
 * @brief  发电量记录管理任务初始化
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void energy_record_init(void)
{
    sdk_rtc_t now;
    uint8_t date[32]= {0};
    uint32_t last_record_charge = 0;
    uint32_t last_record_discharge = 0;

    sdk_rtc_get(RTC_BIN_FORMAT, &now);
    
    // 文件夹不存在，先创建文件夹
    if ((sdk_fs_access((const int8_t *)PATH_ENERGY_GENERAL_DIR, FS_F_OK)) == -1)
    {
        sdk_fs_mkdir(PATH_ENERGY_GENERAL_DIR, FS_S_IRWXU|FS_S_IRWXG|FS_S_IRWXO);
        ENERGY_DEBUG_LOG((int8_t *)"\n[energy_record_init] '/user/data/energy/' direct not exist but has created! \r\n");
    }
 
    //初始化数据库
    create_energy_table();
 
    //初始化全局变量
    memset(&g_energy_record_task,0,sizeof(energy_record_task_t));
    //首先读取当前小时的数据，如果有直接作为电量基值，否则会出现数据丢失
	if (now.tm_hour)
	{
		snprintf((char*)date, sizeof(date), "%04d-%02d-%02d %02d:00:00",now.tm_year + 2000,now.tm_mon,now.tm_day,now.tm_hour);
		select_charge_discharge(date,&last_record_charge,&last_record_discharge);
	}
	//记录当前启动之后从CAN获取的电量，作为电量基值,该值为增量值，比较可靠
	calculate_pcs_total_charge_discharge(&g_energy_record_task.battery_energy_last.energy_container_charge,
		 &g_energy_record_task.battery_energy_last.energy_container_dischar);

    g_energy_record_task.battery_energy_last.energy_container_charge -= last_record_charge;
    g_energy_record_task.battery_energy_last.energy_container_dischar -= last_record_discharge;



    //记录时间作为基准时间
    set_last_savetime(&now);
}
 
/*
 * @brief  历史电量线程（用于历史电量数据存储）
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
void *thread_history_energy(void *arg)
{
	energy_record_init();
    while (1)
    {
		energy_record_task();	
		sleep(1); // sdk_delay_ms(1000);	// 1s
    }
    
    pthread_exit(NULL);
}
