/** 
 * @file          param_record_task.h
 * @brief         参数信息存储外部接口
 * @author        xiaojuying
 * @note
 * @version       V0.0.1     初版
 * @date          2023/3/3
 */

#ifndef __PARAM_RECORD_TASK_H__
#define __PARAM_RECORD_TASK_H__

#include "data_types.h"
#include "data_shm.h"

#define PRESET_SOFTWARE_VERSION_TPYE         ('0')           // 默认版本类型标识

// MCU1应用层软件版本号
#define MCU1_SOFTWARE_VERSION_TPYE           ('V')           // 版本类型，暂固定为 V
#define MCU1_SOFTWARE_MAJOR_VERSION          (1)             // 主版本号
#define MCU1_SOFTWARE_MINOR_VERSION          (1)           // 次版本号
#define MCU1_SOFTWARE_STAGE_VERSION          (20)             // 阶段版本号

/* 热管理版本 */
#define HOT_MANAGE_MAJOR_VERSION             (3)             // 热管理主版本号
#define HOT_MANAGE_SUB_VERSION               (0)             // 热管理子版本号

// CAN协议版本
#define CAN_PROTOCOL_VERSION                 (1)             // can协议版本号

// 每个电池簇里的PACK数量
#define PACK_NUM_PER_BATTERY_CLUSTER        (5)             // 每个电池簇里的PACK数量


#define FILE_VALID                  0x01            // 文件有效标志


#define FILE_SIZE_DEVICE_PARAM      1024            // 设备配置参数文件大小
#define FILE_SIZE_APP_PARAM         (1024 * 2)      // 应用设置参数文件大小
#define FILE_SIZE_FACTORY_PARAM     1024            // 工厂设置参数文件大小
#define FILE_SIZE_CAP_TEST_PARAM    (1024 * 2)      // 容测参数文件大小


#pragma pack(push)
#pragma pack(1)
/**************** 设备配置参数-其他参数 需与共享内存中对应参数排列一致 ****************/
typedef  struct {

    uint16_t address_rs485_4;                       // RS485-4地址
    uint32_t baud_rate_rs485_4;                     // RS485-4波特率
    uint16_t stop_bit_rs485_4;                      // RS485-4停止位
    uint16_t check_bit_rs485_4;                     // RS485-4校验位

    uint16_t address_rs485_6;                       // RS485-6地址
    uint32_t baud_rate_rs485_6;                     // RS485-6波特率
    uint16_t stop_bit_rs485_6;                      // RS485-6停止位
    uint16_t check_bit_rs485_6;                     // RS485-6校验位

    uint8_t addr_IP_ETH_1[NET_ADDR_LEN_MAX];        // ETH-1 IP地址
    uint16_t num_port_ETH_1;                        // ETH-1 端口号
    uint8_t addr_IP_server_ETH_1[NET_ADDR_LEN_MAX]; // ETH-1 服务器IP地址
    uint16_t numr_port_server_ETH_1;                // ETH-1 服务器端口号
    uint8_t addr_IP_ETH_3[NET_ADDR_LEN_MAX];        // ETH-3 IP地址
    uint16_t num_port_ETH_3;                        // ETH-3 端口号
    uint8_t addr_IP_server_ETH_3[NET_ADDR_LEN_MAX]; // ETH-3 服务器IP地址
    uint16_t numr_port_server_ETH_3;                // ETH-3 服务器端口号

    uint16_t remote_on_off_ctrl;                    // 远程开关机 0-关机 1-开机
    uint16_t LC_on_off_ctrl;                        // 液冷系统开关机 手动模式下才生效 0-关机 1-开机

}device_paramater_other_t;

/**************** 设备配置参数-CMU系统参数 定值/参数数据 需与共享内存中对应参数排列一致 ****************/
typedef  struct {

    uint16_t storage_duration_operation_data;       // 运行数据存储天数 30~360天
    uint16_t storage_freq_operation_data;           // 运行数据存储频率 3min~60min
    uint16_t number_fault_record;                   // 故障录波条数 0~10条
    uint16_t battery_cluster_id;                    // 电池簇编号
    uint16_t cmu_mode;                              // cmu模式设置 0 运行模式，1 运维模式
    uint16_t bat_cabinet_num;                   	// 电池仓个数
    uint16_t energy_cabinet_FF_addr;                // 储能柜消防气瓶地址
	uint16_t energy_cabinet_num;					// 消防共享储能柜数量
    int16_t soc_charge_limit;                       // SOC充电上限
    int16_t soc_discharge_limit;                    // SOC放电下限
    uint16_t eol_threshold;                       	//SOH报警阈值
    uint16_t bat_cluster_pack_num;                    // 电池簇PACK个数
    uint16_t display_language;                       //WEB/上位机/触摸屏等，显示的语言  0 中文 1 英文
    uint8_t device_sn[24];
    uint16_t iec104_pcs_upload_time;                 //104 PCS上报时间
    uint16_t iec104_bcu_upload_time;                 //104 BCU上报时间
    uint16_t safety_rdr_country;					// 安规国家
	uint16_t ver_safety_rdr_para;					// 安规参数版本号 
    uint16_t idle_to_sleep_tm;                      // 空载转待机时间，单位：小时
    uint16_t sleep_to_pow_off_tm;                   // 空载触发停机时间，单位小时
    uint16_t sleep_to_pow_off_enable;               // 待机转停机使能
    uint16_t idle_to_sleep_enable;                  // 空载转待机使能
    uint16_t external_epo_input_type;                  // 外部EPO输入类型 0：常开  1：常闭
    // uint8_t external_protocol_enable;                // 设置外置协议 bit0：IEC104  bit1：MODBUS TCP
    uint8_t iec104_upload_enable;                   // IEC104上报使能

}device_paramater_sys_t;


/**************** 设备配置参数 ****************/
typedef  struct {

    uint16_t validity_flag;                             // 文件有效性标志
    device_paramater_other_t dev_param_other_data;      // 需通过非104协议传输的其他设置参数 
    device_paramater_sys_t device_paramater_sys_data;   // 系统设置参数

}device_paramater_t;

/**************** 容测 临时参数 ****************/
typedef  struct 
{
    uint16_t validity_flag;                             // 文件有效性标志
    uint16_t bat_cap_test_mode;                         // 电池容测模式   0：正常模式  1：容测模式
    battery_parameter_data_t usr_battery_param;         // 用户电池参数
} bat_cap_test_paramater_t;
#pragma pack(pop)


#pragma pack(push)
#pragma pack(1)
/**************** 集装箱系统 定值/参数数据 需与共享内存中对应参数排列一致 ****************/
typedef struct{

    uint16_t cluster_curr_diff_warn_threshold_1;         // 簇间电流差异过大1级报警阈值
    uint16_t cluster_curr_diff_warn_threshold_2;         // 簇间电流差异过大2级报警阈值
    uint16_t cluster_curr_diff_warn_threshold_3;         // 簇间电流差异过大3级报警阈值
    uint16_t cluster_curr_diff_warn_hysteresis_err;      // 簇间电流差异过大报警回差值

    dynamic_ring_parameter_data_t dynamic_ring;          // 动环系统定值/参数

}container_system_parameter_data_t;

typedef struct{
    dynamic_ring_parameter_data2_t dynamic_ring;          // 动环系统定值/参数
}container_system_parameter_data2_t;

/**************** 应用设置参数 ****************/
typedef  struct {

    uint16_t validity_flag;                             // 文件有效性标志

    /**************** 集装箱系统 定值/参数数据 ****************/
    container_system_parameter_data_t container_sys_param_data;

    /**************** 集装箱内电池簇 定值/参数数据 ****************/
    battery_parameter_data_t battery_parameter_data[BCU_DEVICE_NUM];

    /**************** 集装箱系统 定值/参数数据 ****************/
    container_system_parameter_data2_t container_sys_param_data2;
    
}application_paramater_t;
#pragma pack(pop)


#pragma pack(push)
#pragma pack(1)
/**************** 工厂设置参数 ****************/
typedef  struct {

    uint16_t validity_flag;         // 文件有效性标志

    // 工厂模式-状态控制字；
    uint16_t state_ctr;             // Bit0-Bit7：工厂模式使能位 单板测试使能位 T1完成标志 老化完成标志 T2完成标志 包装测试完成标志 电池老化模式使能 电池激活

    // 工厂模式-特权控制字；每位写入0无效，写入1有效。
    uint16_t privilege_ctrl_word;   // Bit0：清除校准系数 Bit1：清除运行数据 Bit2：清除故障录波

}factory_paramater_t;
#pragma pack(pop)



/**
* @brief    设置全局变量电池设置参数读取状态的值
* @param	[in] value  设置的值
* @return   
* @note     
*/
void battery_set_param_read_status_set(uint8_t value);

/**
* @brief    设备参数文件初始化
* @param        
* @return       
* @retval
*/
void param_record_file_init(void);

/**
 * @brief   对共享内存的数据初始化
 * @param
 * @return  
 * @note    对应配置参数，优先从文件读取，若文件读取失败，则赋默认值
 */
void shm_data_init(void);

/**
 * @brief   子设备的应用设置参数确认
 * @param
 * @return  
 * @note    将从文件读取的设置参数与从子设备获取的应用参数进行对比，
 *          若不一致，报 文件中应用设置参数与实际不一致 的提示
 */
void app_param_comparison(void);

/**
 * @brief   电池簇定值/参数（阈值）恢复出厂设置
 * @param   无
 * @return  [int32_t] 执行结果
 * @retval  =0  成功
 * @retval  <0  失败
 * @note
 */
int32_t battery_parameter_data_reset(void);

/**
 * @brief   读取 电池容测临时参数
 * @param   
 * @retval  0       成功
 * @retval  其他    失败
*/
int32_t bat_cap_test_data_restore( bat_cap_test_paramater_t *p_bat_cap_test_param  );

/**
 * @brief   电池容测临时参数清除
 * @param   
 * @retval  0       成功
 * @retval  其他    失败
*/
int32_t bat_cap_test_data_clear( void );

/**
 * @brief   电池容测临时参数保存
 * @param   
 * @retval  0       成功
 * @retval  其他    失败
*/
int32_t bat_cap_test_data_save( void );

/**
 * @brief   设备配置参数存储
 * @param   
 * @retval  0       成功
 * @retval  其他    失败
*/
int32_t dev_param_save(void);

/**
 * @brief   应用设置参数存储
 * @param   
 * @retval  0       成功
 * @retval  其他    失败
*/
int32_t app_param_save(void);

/**
 * @brief   工厂参数存储
 * @param   
 * @retval  0       成功
 * @retval  其他    失败
*/
int32_t factory_param_save(void);

/**
 * @brief   集装箱阈值参数存储
 * @param   
 * @retval  0       成功
 * @retval  其他    失败
*/
int32_t container_system_param_save(void);

/**
 * @brief   电池阈值参数存储
 * @param   
 * @retval  0       成功
 * @retval  其他    失败
*/
int32_t battery_param_save(void);

/**
 * @brief   设备配置参数读取
 * @param   
 * @retval  0       成功
 * @retval  其他    失败
 * @note    从文件中读取设备参数，若文件读取成功，将读取内容更新至共享内存
 *          若读取失败则不更新
 */
int32_t dev_param_read(void);

/**
 * @brief   电池阈值参数读取
 * @param   
 * @retval  0       成功
 * @retval  其他    失败
 * @note    从文件中读取设置参数，若文件读取成功，将读取内容更新至共享内存
 *          若读取失败则不更新
 */
int32_t battery_param_read(void);

/**
 * @brief   检查热管理逻辑版本，版本不一致则复位热管理默认参数
 * @param
 * @return  
 * @note    
 */
void check_hot_manage_version( void );

#endif  /* __PARAM_RECORD_TASK_H__ */
