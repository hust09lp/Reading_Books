/** 
 * @file          param_record_task.c
 * @brief         参数信息存储
 * @author        xiaojuying
 * @note
 * @version       V0.0.1     初版
 * @date          2023/3/3
 */

#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include "param_record_task.h"
#include "process_battery_read.h"
#include "sdk_shm.h"
#include "sdk_para.h"
#include "sofar_log.h"
#include "sdk_fs.h"
#include "sofar_errors.h"
#include "sdk_safety.h"
#include "safety_lib_task.h"
#include "mem_utils.h"
#include "json_utils.h"

/**
 * @brief   initialization of battery parameters
 * @note    绝缘阻抗1级/2级/3级报警阈值、回差值
 *          簇端电压1级/2级/3级过压报警阈值、回差值（单个PACK的值，实际使用时，要乘以PACK的数量PACK_NUM_PER_BATTERY_CLUSTER）
 *          簇端电压1级/2级/3级欠压报警阈值、回差值（单个PACK的值，实际使用时，要乘以PACK的数量PACK_NUM_PER_BATTERY_CLUSTER）
 *          PACK电压1级/2级/3级过压报警阈值、回差值
 *          PACK电压1级/2级/3级欠压报警阈值、回差值
 *          充电电流1级/2级/3级过流报警阈值、回差值
 *          放电电流1级/2级/3级过流报警阈值、回差值
 *          充电单体温度1级/2级/3级过温报警阈值、回差值、充电单体温度1级/2级/3级欠温报警阈值、回差值
 *          放电单体温度1级/2级/3级过温报警阈值、回差值、放电单体温度1级/2级/3级欠温报警阈值、回差值
 *          单体温差过大1级/2级/3级过温报警阈值、回差值
 *          单体电压1级/2级/3级过压报警阈值、回差值
 *          单体电压1级/2级/3级欠压报警阈值、回差值
 *          单体压差过大1级报警阈值、回差值
 *          SOC过大1级/2级/3级报警阈值、回差值
 *          SOC过低1级/2级/3级报警阈值、回差值
 *          SOC差异过大1级/2级/3级报警阈值、回差值
 *          模块温差过大1级/2级/3级报警阈值、回差值
*/
static battery_parameter_data_t g_battery_paramater_init = {
                                .ISO_warn_threshold_1 = 1000,
                                .ISO_warn_threshold_2 = 500,
                                .ISO_warn_threshold_3 = 100,
                                .ISO_warn_hysteresis_err = 10,
                                .cluster_OVP_warn_threshold_1 = 1680,
                                .cluster_OVP_warn_threshold_2 = 1704,
                                .cluster_OVP_warn_threshold_3 = 1752,
                                .cluster_OVP_warn_hysteresis_err = 100,
                                .cluster_UVP_warn_threshold_1 = 1344,
                                .cluster_UVP_warn_threshold_2 = 1296,
                                .cluster_UVP_warn_threshold_3 = 1200,
                                .cluster_UVP_warn_hysteresis_err = 100,
                                .PACK_OVP_warn_threshold_1 = 1680,
                                .PACK_OVP_warn_threshold_2 = 1704,
                                .PACK_OVP_warn_threshold_3 = 1752,
                                .PACK_OVP_warn_hysteresis_err = 50,
                                .PACK_UVP_warn_threshold_1 = 1344,
                                .PACK_UVP_warn_threshold_2 = 1296,
                                .PACK_UVP_warn_threshold_3 = 1200,
                                .PACK_UVP_warn_hysteresis_err = 50,
                                .charge_OCP_warn_threshold_1 = 2150,
                                .charge_OCP_warn_threshold_2 = 2300,
                                .charge_OCP_warn_threshold_3 = 2500,
                                .charge_OCP_warn_hysteresis_err = 100,
                                .discharge_OCP_warn_threshold_1 = 2150,
                                .discharge_OCP_warn_threshold_2 = 2300,
                                .discharge_OCP_warn_threshold_3 = 2500,
                                .discharge_OCP_warn_hysteresis_err = 100,
                                .charge_monomer_OTP_warn_threshold_1 = 90,
                                .charge_monomer_OTP_warn_threshold_2 = 95,
                                .charge_monomer_OTP_warn_threshold_3 = 100,
                                .charge_monomer_OTP_warn_hysteresis_err = 5,
                                .charge_monomer_UTP_warn_threshold_1 = 40,
                                .charge_monomer_UTP_warn_threshold_2 = 30,
                                .charge_monomer_UTP_warn_threshold_3 = 20,
                                .charge_monomer_UTP_warn_hysteresis_err = 5,
                                .discharge_monomer_OTP_warn_threshold_1 = 90,
                                .discharge_monomer_OTP_warn_threshold_2 = 95,
                                .discharge_monomer_OTP_warn_threshold_3 = 100,
                                .discharge_monomer_OTP_warn_hysteresis_err = 5,
                                .discharge_monomer_UTP_warn_threshold_1 = 40,
                                .discharge_monomer_UTP_warn_threshold_2 = 30,
                                .discharge_monomer_UTP_warn_threshold_3 = 20,
                                .discharge_monomer_UTP_warn_hysteresis_err = 5,
                                .monomer_temp_diff_warn_threshold_1 = 15,
                                .monomer_temp_diff_warn_threshold_2 = 20,
                                .monomer_temp_diff_warn_threshold_3 = 30,
                                .monomer_temp_diff_warn_hysteresis_err = 5,
                                .monomer_OVP_warn_threshold_1 = 3500,
                                .monomer_OVP_warn_threshold_2 = 3550,
                                .monomer_OVP_warn_threshold_3 = 3650,
                                .monomer_OVP_warn_hysteresis_err = 100,
                                .monomer_UVP_warn_threshold_1 = 2800,
                                .monomer_UVP_warn_threshold_2 = 2700,
                                .monomer_UVP_warn_threshold_3 = 2500,
                                .monomer_UVP_warn_hysteresis_err = 200,
                                .monomer_vol_diff_warn_threshold_1 = 400,
                                .monomer_vol_diff_warn_threshold_2 = 600,
                                .monomer_vol_diff_warn_threshold_3 = 1000,
                                .monomer_vol_diff_warn_hysteresis_err = 50,
                                .SOC_high_warn_threshold_1 = 100,
                                .SOC_high_warn_threshold_2 = 100,
                                .SOC_high_warn_threshold_3 = 100,
                                .SOC_high_warn_hysteresis_err = 2,
                                .SOC_low_warn_threshold_1 = 15,
                                .SOC_low_warn_threshold_2 = 10,
                                .SOC_low_warn_threshold_3 = 5,
                                .SOC_low_warn_hysteresis_err = 2,
                                .SOC_diff_warn_threshold_1 = 100,
                                .SOC_diff_warn_threshold_2 = 100,
                                .SOC_diff_warn_threshold_3 = 100,
                                .SOC_diff_warn_hysteresis_err = 2,
                                .PACK_temp_diff_warn_threshold_1 = 75,
                                .PACK_temp_diff_warn_threshold_2 = 125,
                                .PACK_temp_diff_warn_threshold_3 = 140,
                                .PACK_temp_diff_warn_hysteresis_err = 5,
};

/**
 * @brief   initialization of CMU1 system parameters
 * @note    簇间电流差异过大1级/2级/3级报警阈值、回差值 // fix me!!! 值待确定
 *          动环系统定值/参数{
 *          液冷机组型号、手自模式、模式设置、控制方式、水泵转速设定、
 *          制冷温度设定、制冷回差、制热温度设定、制热回差、制冷出水低温告警设定、
 *          制热出水高温告警设定、出水压力过高设定点、回水压力过低设定点、
 *          电芯设定目标温度、电芯设定最大温度、水泵延迟关闭时间、预冷/预热启动等待时间、液冷预冷启动最大温度、
 *          液冷预冷启动平均温度、液冷预冷回差、液冷预冷温度、液冷预冷流量、液冷预热启动最小温度、
 *          液冷预热启动平均温度、液冷预热回差、液冷预热温度、液冷预热流量、制冷开机挡位区间点1、
 *          制冷开机挡位区间点2、制冷开机挡位区间点3、制冷开机挡位区间点4、制冷开机挡位区间点5、制冷开机区间对应初始供液温度1、
 *          制冷开机区间对应初始供液温度2、制冷开机区间对应初始供液温度3、制冷开机区间对应初始供液温度4、制冷开机区间对应初始供液温度5、制冷开机区间对应初始供液温度6、
 *          制冷开机区间回差、制冷开机初始供液流量、制冷开机初始运行时间、达温停机 Tds 正负回差、进入达温停机 持续时间
 *          退出达温停机 持续时间、制冷模式供液温度控制方式、制冷模式固定供液温度、制冷模式自适应供液温度设定最小值、制冷模式自适应供液温度设定最大值、
 *          制冷模式自适应供液温度Tmean修正区间点1 ~ 制冷模式自适应供液温度Tmean修正区间点5、
 *          制冷模式自适应供液温度Tmean修正区间对应温度修正值1 ~ 制冷模式自适应供液温度Tmean修正区间对应温度修正值5、
 *          制冷模式自适应供液温度Tmean修正区间对应温度修正值6、制冷模式自适应供液温度Tmean修正区间回差、制冷模式自适应供液温度Tmean修正时间间隔、制冷模式自适应供液温度Tmax修正区间点1、制冷模式自适应供液温度Tmax修正区间点2、
 *          制冷模式自适应供液温度Tmax修正区间点3、制冷模式自适应供液温度Tmax修正区间对应温度修正值1 ~ 制冷模式自适应供液温度Tmax修正区间对应温度修正值4、
 *          制冷模式自适应供液温度Tmax修正区间回差、制冷模式自适应供液温度Tmax修正时间间隔、制冷模式供液流量控制方式、制冷模式固定供液流量值、制冷模式自适应供液流量策略Tdm/Tds 回差、
 *          制冷模式自适应供液流量修正 温差峰值区间点1 ~ 制冷模式自适应供液流量修正 温差峰值区间点3、制冷模式自适应供液流量修正区间对应流量修正值1、制冷模式自适应供液流量修正区间对应流量修正值2、
 *          制冷模式自适应供液流量修正区间对应流量修正值3、制冷模式自适应供液流量修正区间对应流量修正值4、制冷模式自适应供液流量修正 温差峰值区间回差、制冷模式自适应供液流量修正时间间隔、系统待机电流、
 *          消防气瓶压力表1低压阈值、消防气瓶压力表1高压阈值、消防一级报警PACK温度、消防一级报警复合传感器温度、
 *          消防一级报警复合传感器CO浓度【工商业中无效】、消防一级报警复合传感器PM2.5浓度、消防二级报警PACK最高温度【pack】、消防二级报警复合传感器CO浓度【pack】、
 *          消防二级报警复合传感器温度【舱级】、消防二级报警复合传感器CO浓度【舱级】、消防风机联动复合传感器CO浓度、消防风机联动复合传感器PM2.5浓度【工商业中无效】、
 *          消防控制字、关闭风机联动CO浓度、消防二级报警PACK温度次高温度【pack】、湿度设定、湿度回差
 *          }
*/
static container_system_parameter_data_t g_container_sys_param_init = {
                                .cluster_curr_diff_warn_threshold_1 = 2500,
                                .cluster_curr_diff_warn_threshold_2 = 2500,
                                .cluster_curr_diff_warn_threshold_3 = 2500,
                                .cluster_curr_diff_warn_hysteresis_err = 100,
                                .dynamic_ring.lc_type = 0,
                                .dynamic_ring.lc_auto_mode = 1,
                                .dynamic_ring.lc_mode = 0,
                                .dynamic_ring.lc_ctrl_mode = 0,
                                .dynamic_ring.lc_pump_rate = 100,
                                .dynamic_ring.lc_cooling_point = 180,
                                .dynamic_ring.lc_cooling_drop = 20,
                                .dynamic_ring.lc_heating_point = 150,
                                .dynamic_ring.lc_heating_drop = 20,
                                .dynamic_ring.lc_cool_outlet_low_tmp = 100,
                                .dynamic_ring.lc_heat_outlet_hig_tmp = 380,
                                .dynamic_ring.lc_outlet_pressure_high = 280,
                                .dynamic_ring.lc_inlet_pressure_low = 50,
                                .dynamic_ring.bat_Dts = 320,
                                .dynamic_ring.bat_Dtm = 380,
                                .dynamic_ring.pump_close_delay = 600,
                                .dynamic_ring.pre_check_tm_sec = 20,
                                .dynamic_ring.bat_Tmax_max = 410,
                                .dynamic_ring.bat_Tmean_max = 350,
                                .dynamic_ring.exit_pre_cool_ret_tmp = 20,
                                .dynamic_ring.lc_pre_cool_tmp = 190,
                                .dynamic_ring.lc_pre_cool_flow = 100,
                                .dynamic_ring.bat_Tmin_min = 120,
                                .dynamic_ring.bat_Tmean_min = 150,
                                .dynamic_ring.exit_pre_heat_ret_tmp = 30,
                                .dynamic_ring.lc_pre_heat_tmp = 250,
                                .dynamic_ring.lc_pre_heat_flow = 100,
                                .dynamic_ring.start_Tmean_Tds_val[0] = 0,
                                .dynamic_ring.start_Tmean_Tds_val[1] = 10,
                                .dynamic_ring.start_Tmean_Tds_val[2] = 20,
                                .dynamic_ring.start_Tmean_Tds_val[3] = 30,
                                .dynamic_ring.start_Tmean_Tds_val[4] = 40,
                                .dynamic_ring.lc_tmp[0] = 0,
                                .dynamic_ring.lc_tmp[1] = 260,
                                .dynamic_ring.lc_tmp[2] = 250,
                                .dynamic_ring.lc_tmp[3] = 240,
                                .dynamic_ring.lc_tmp[4] = 230,
                                .dynamic_ring.lc_tmp[5] = 220,
                                .dynamic_ring.ret_tmp = 0,
                                .dynamic_ring.lc_flow = 100,
                                .dynamic_ring.tm_sec = 300,
                                .dynamic_ring.Tds_ret_tmp = 20,
                                .dynamic_ring.enter_valid_tm = 300,
                                .dynamic_ring.exit_valid_tm = 0,
                                .dynamic_ring.cool_lc_tmp_ctrl_mode = 1,
                                .dynamic_ring.cool_fix_lc_tmp = 190,
                                .dynamic_ring.min_lc_tmp = 190,
                                .dynamic_ring.max_lc_tmp = 250,
                                .dynamic_ring.Tmean_Tds_val[0] = -10,
                                .dynamic_ring.Tmean_Tds_val[1] = 0,
                                .dynamic_ring.Tmean_Tds_val[2] = 10,
                                .dynamic_ring.Tmean_Tds_val[3] = 20,
                                .dynamic_ring.Tmean_Tds_val[4] = 30,
                                .dynamic_ring.Tmean_Tds_adj[0] = 15,
                                .dynamic_ring.Tmean_Tds_adj[1] = 10,
                                .dynamic_ring.Tmean_Tds_adj[2] = 5,
                                .dynamic_ring.Tmean_Tds_adj[3] = 0,
                                .dynamic_ring.Tmean_Tds_adj[4] = -5,
                                .dynamic_ring.Tmean_Tds_adj[5] = -10,
                                .dynamic_ring.Tmean_Tds_ret = 10,
                                .dynamic_ring.Tmean_Tds_adj_interval_tm = 120,
                                .dynamic_ring.Tmax_Tdm_val[0] = 0,
                                .dynamic_ring.Tmax_Tdm_val[1] = 10,
                                .dynamic_ring.Tmax_Tdm_val[2] = 20,
                                .dynamic_ring.Tmax_Tdm_adj[0] = 0,
                                .dynamic_ring.Tmax_Tdm_adj[1] = -10,
                                .dynamic_ring.Tmax_Tdm_adj[2] = -15,
                                .dynamic_ring.Tmax_Tdm_adj[3] = -20,
                                .dynamic_ring.Tmax_Tdm_ret = 5,
                                .dynamic_ring.Tmax_Tdm_adj_interval_tm = 60,
                                .dynamic_ring.cool_lc_flow_ctrl_mode = 0,
                                .dynamic_ring.cool_fix_lc_flow = 100,
                                .dynamic_ring.Tdm_Tds_ret = 10,
                                .dynamic_ring.Tmax_Tmin_val[0] = 20,
                                .dynamic_ring.Tmax_Tmin_val[1] = 30,
                                .dynamic_ring.Tmax_Tmin_val[2] = 40,
                                .dynamic_ring.Tmax_Tmin_adj[0] = -10,
                                .dynamic_ring.Tmax_Tmin_adj[1] = 0,
                                .dynamic_ring.Tmax_Tmin_adj[2] = 10,
                                .dynamic_ring.Tmax_Tmin_adj[3] = 20,
                                .dynamic_ring.Tmax_Tmin_ret = 5,
                                .dynamic_ring.Tmax_Tmin_adj_interval_tm = 60,
                                .dynamic_ring.sys_standby_current = 10,
                                .dynamic_ring.gauge1_low_pressure_threshold = 1800,
                                .dynamic_ring.gauge1_high_pressure_threshold = 3500,
                                .dynamic_ring.level_1_alarm_pack_temperature = 65,
                                .dynamic_ring.level_1_alarm_composite_sensor_temp = 100,
                                .dynamic_ring.ff_alarm_level1_sensor_co = 100,
                                .dynamic_ring.level_1_alarm_composite_sensor_PM25 = 2000,
                                .dynamic_ring.level_2_alarm_pack_temperature = 65,
                                .dynamic_ring.level_2_alarm_composite_sensor_CO = 100,
                                .dynamic_ring.ff_alarm_level2_compart_temp = 100,
                                .dynamic_ring.ff_alarm_level2_compart_co = 100,
                                .dynamic_ring.fire_fan_linkage_composite_sensor_CO = 100,
                                .dynamic_ring.fire_fan_linkage_composite_sensor_PM25 = 2000,
                                .dynamic_ring.fire_control_words = 0,
                                .dynamic_ring.fire_close_fan_linkage_composite_sensor_CO = 50,
                                .dynamic_ring.level_2_alarm_pack_temperature2 = 48,
                                .dynamic_ring.dst_humidity = 75,
                                .dynamic_ring.ret_humidity = 15,
                                .dynamic_ring.ff_backup_enable = 1,
};

/**
 * @brief   initialization of CMU1 system parameters
 * @note    保温模式使能位
 *          保温模式 加热启动温度
 *          保温模式 加热退出温度
 *          保温模式 制冷启动温度
 *          保温模式 制冷退出温度
*/
static container_system_parameter_data2_t g_container_sys_param_init2 = {
                                .dynamic_ring.keep_temper_enable = 0,
                                .dynamic_ring.keep_temper_heating_startup_temper = 150,
                                .dynamic_ring.keep_temper_heating_exit_temper = 200,
                                .dynamic_ring.keep_temper_cooling_startup_temper = 350,
                                .dynamic_ring.keep_temper_cooling_exit_temper = 320,
                                .dynamic_ring.pre_cooling_forbid_charge_discharge_temper = 380,
                                .dynamic_ring.pre_heating_forbid_charge_discharge_temper = 100,
};

/**
 * @brief   initialization of device configuration parameters
 * @note    文件有效性标志
 *          RS485-4地址、波特率、停止位、校验位、RS485-6地址、波特率、停止位、校验位
 *          ETH-1 IP地址、端口号
 *          ETH-1 服务器IP地址、端口号
 *          ETH-3 IP地址、端口号
 *          ETH-3 服务器IP地址、端口号
 *          远程开关机 0-关机 1-开机
 *          液冷系统开关机 手动模式下才生效 0-关机 1-开机
 *          运行数据存储天数 30~360天
 *          运行数据存储频率 3min~60min
 *          故障录波条数 0~10条
 *          电池簇编号
 *          cmu模式设置 0 运行模式，1 运维模式
*/
static const device_paramater_t g_dev_param_init = {
                            .validity_flag = 1,
                            .dev_param_other_data.address_rs485_4 = 1,
                            .dev_param_other_data.baud_rate_rs485_4 = 115200,
                            .dev_param_other_data.stop_bit_rs485_4 = 1,
                            .dev_param_other_data.check_bit_rs485_4 = 0,
                            .dev_param_other_data.address_rs485_6 = 1,
                            .dev_param_other_data.baud_rate_rs485_6 = 115200,
                            .dev_param_other_data.stop_bit_rs485_6 = 1,
                            .dev_param_other_data.check_bit_rs485_4 = 0,
                            .dev_param_other_data.addr_IP_ETH_1 = "192.168.1.100",
                            .dev_param_other_data.num_port_ETH_1 = 2404,
                            .dev_param_other_data.addr_IP_server_ETH_1 = "192.168.1.1",
                            .dev_param_other_data.numr_port_server_ETH_1 = 2404,
                            .dev_param_other_data.addr_IP_ETH_3 = "192.168.1.100",
                            .dev_param_other_data.num_port_ETH_3 = 2404,
                            .dev_param_other_data.addr_IP_server_ETH_3 = "192.168.1.100",
                            .dev_param_other_data.numr_port_server_ETH_3 = 2404,
                            .dev_param_other_data.remote_on_off_ctrl = 0,
                            .dev_param_other_data.LC_on_off_ctrl = 1,
                            .device_paramater_sys_data.storage_duration_operation_data = 180,
                            .device_paramater_sys_data.storage_freq_operation_data = 5,
                            .device_paramater_sys_data.number_fault_record = 10,
                            .device_paramater_sys_data.battery_cluster_id = 0,
                            .device_paramater_sys_data.cmu_mode = 0,
                            .device_paramater_sys_data.bat_cabinet_num = 1,
                            .device_paramater_sys_data.energy_cabinet_FF_addr = 1,
                            .device_paramater_sys_data.energy_cabinet_num = 1,
                            .device_paramater_sys_data.soc_charge_limit = 100,
                            .device_paramater_sys_data.soc_discharge_limit = 0,
                            .device_paramater_sys_data.eol_threshold = 70,
                            .device_paramater_sys_data.bat_cluster_pack_num = 5,
                            .device_paramater_sys_data.display_language = 0,
                            .device_paramater_sys_data.device_sn = "00000000000000000000",
                            .device_paramater_sys_data.iec104_pcs_upload_time = 90,
                            .device_paramater_sys_data.iec104_bcu_upload_time = 90,
                            .device_paramater_sys_data.safety_rdr_country = 65535,
                            .device_paramater_sys_data.ver_safety_rdr_para = 65535,
                            
                            .device_paramater_sys_data.idle_to_sleep_tm = 8,
                            .device_paramater_sys_data.sleep_to_pow_off_tm = 24,
                            .device_paramater_sys_data.sleep_to_pow_off_enable = 0,
                            .device_paramater_sys_data.idle_to_sleep_enable = 0,

                            .device_paramater_sys_data.external_epo_input_type = 0,
                            .device_paramater_sys_data.iec104_upload_enable = 1,
};

static application_paramater_t g_app_param_init = {0};
/**
 * @brief   initialization of factory parameters
 * @note    文件有效性标志
 *          工厂模式-状态控制字
 *          工厂模式-特权控制字
*/
static factory_paramater_t g_factory_param_init = {1, 0, 0};


static uint8_t g_battery_set_param_read_status = DISABLE; // 电池设置参数读取状态。0 未读取完成，1 读取完成
static device_paramater_t g_dev_param;
static application_paramater_t g_app_param;
static factory_paramater_t g_factory_param;
static bat_cap_test_paramater_t g_bat_cap_test_param;

static int32_t bat_cap_test_param_file_init(void);



/**
 * @brief    设置全局变量电池设置参数读取状态的值
 * @param	[in] value  设置的值
 * @return   
 * @note     
 */
void battery_set_param_read_status_set(uint8_t value)
{
	g_battery_set_param_read_status = value;
}

/**
 * @brief        设备配置参数文件初始化
 * @param        
 * @return       
 * @retval       0      初始化成功
 * @retval       其他   异常
 */
static int32_t dev_param_file_init(void)
{
    int32_t ret = 0;
    int32_t result = 0;
    uint32_t len = 0;
    device_paramater_t param_temp;
    struct stat file_stat;
    uint8_t device_sn_temp[24];
    uint16_t pack_num_temp = 0;


    ret = sdk_para_init(FILE_TYPE_DEVICE_PARAM, FILE_SIZE_DEVICE_PARAM);
    if (0 == ret)
    {
        len = sizeof(device_paramater_t);
        // 先给参数全部赋默认值
        memcpy(&param_temp.dev_param_other_data,&g_dev_param_init.dev_param_other_data,len -2);

        // 获取已保存的参数文件的大小
        result = stat(DEVICE_PARAM_PATH,&file_stat);
        if(result != SF_OK)
        {
            goto __write_default;
        }

        // 参数文件大小小于结构体大小，只读实际文件大小的数据填充结构体前面的部分
        if(file_stat.st_size < len)
        {
            len = file_stat.st_size;
        }
    
        ret = sdk_para_read(FILE_TYPE_DEVICE_PARAM, 0, (uint8_t*)&param_temp, len);
        if(ret != len)  
        {
            log_i((int8_t *)"\n device param has changed, rewrite default!!! \n"); // 测试用
            goto __write_default;
        }
        else
        {
            if(param_temp.validity_flag == FILE_VALID) 
            {
                len = sizeof(device_paramater_t);
                result = sdk_para_write(FILE_TYPE_DEVICE_PARAM, 0, (uint8_t *)(&param_temp), len);
                if (result == len)
                {
                    ret = sdk_para_sync(FILE_TYPE_DEVICE_PARAM);
                    log_i((int8_t *)"\n [ok] device param file init success \n"); // 测试用
                    goto __exit;
                }
                else
                {
                    ret = -1;
                }
            }
        }
    }
    else if (ret < 0)
    {
        log_e((int8_t *)"\n [error] sdk_para_init->device param fail!!! \n");
        goto __exit;
    }

__write_default:
    // 给设备配置参数写默认值
    len = sizeof(device_paramater_t);
    memset(device_sn_temp,0,sizeof(device_sn_temp));
    memcpy(device_sn_temp,&param_temp.device_paramater_sys_data.device_sn,sizeof(device_sn_temp));
    pack_num_temp = param_temp.device_paramater_sys_data.bat_cluster_pack_num;
    memcpy(&param_temp.validity_flag,&g_dev_param_init.validity_flag,len);
    memcpy(&param_temp.device_paramater_sys_data.device_sn,device_sn_temp,sizeof(param_temp.device_paramater_sys_data.device_sn));
    param_temp.device_paramater_sys_data.bat_cluster_pack_num = pack_num_temp;
    result = sdk_para_write(FILE_TYPE_DEVICE_PARAM, 0, (uint8_t *)(&param_temp), len);
    if (result == len)
    {
        ret = sdk_para_sync(FILE_TYPE_DEVICE_PARAM);
        log_i((int8_t *)"\n [ok] device param file init success \n"); // 测试用
    }
    else
    {
        ret = -1;
    }
    
__exit:
    return ret;
}

/**
 * @brief        应用设置参数初始化
 * @param        
 * @return       
 * @retval       0   初始化成功
 * @retval       <0  异常
 */
static int32_t app_param_file_init(void)
{
    int32_t ret = 0;
    int32_t result = 0;
    uint32_t len = 0;
    application_paramater_t app_para_temp;
    struct stat file_stat;

    memset(&app_para_temp,0,sizeof(application_paramater_t));

    ret = sdk_para_init(FILE_TYPE_APP_PARAM, FILE_SIZE_APP_PARAM);

    if (0 == ret)
    {
        len = sizeof(application_paramater_t);
        // 先给参数全部赋默认值
        memcpy(&app_para_temp.container_sys_param_data,&g_app_param_init.container_sys_param_data,len -2);

        // 获取已保存的参数文件的大小
        result = stat(APP_PARAM_PATH,&file_stat);
        if(result != SF_OK)
        {
            goto __write_default;
        }

        // 参数文件大小小于结构体大小，只读实际文件大小的数据填充结构体前面的部分
        if(file_stat.st_size < len)
        {
            len = file_stat.st_size;
        }

        ret = sdk_para_read(FILE_TYPE_APP_PARAM, 0, (uint8_t *)&app_para_temp, len);
        if(ret != len)  
        {
            log_i((int8_t *)"\n application param has changed, rewrite default  %d %d!!! \n",ret,sizeof(application_paramater_t)); // 测试用
            goto __write_default;
        }
        else
        {
            if(app_para_temp.validity_flag == FILE_VALID) 
            {
                len = sizeof(application_paramater_t);
                result = sdk_para_write(FILE_TYPE_APP_PARAM, 0, (uint8_t *)(&app_para_temp), len);
                if (result == len)
                {
                    ret = sdk_para_sync(FILE_TYPE_APP_PARAM);
                    log_i((int8_t *)"\n [ok] device param file init success \n"); // 测试用
                    goto __exit;
                }
                else
                {
                    ret = -1;
                }
            }
        }
    }
    else if (ret < 0)
    {
        log_e((int8_t *)"\n [error] sdk_para_init->application param fail! \n");
        goto __exit;
    }
__write_default:
    // 给应用设置参数写默认值
    len = sizeof(application_paramater_t);
    result = sdk_para_write(FILE_TYPE_APP_PARAM, 0, (uint8_t *)(&g_app_param_init), len);
    if (result == len)
    {
        ret = sdk_para_sync(FILE_TYPE_APP_PARAM);
    }
    else
    {
        ret = -1;
    }

__exit:
    return ret;
}

/**
 * @brief        工厂参数文件初始化
 * @param        
 * @return       
 * @retval       0   初始化成功
 * @retval       <0  异常
 */
static int32_t factory_param_file_init(void)
{
    int32_t ret = 0;
    int32_t result = 0;
    uint32_t len = 0;
    factory_paramater_t factory_para_temp;
    struct stat file_stat;

    memset(&factory_para_temp,0,sizeof(factory_paramater_t));

    ret = sdk_para_init(FILE_TYPE_FACTORY_PARAM, FILE_SIZE_FACTORY_PARAM);

    if (0 == ret)
    {

        len = sizeof(factory_paramater_t);
        // 先给参数全部赋默认值
        memcpy(&factory_para_temp.state_ctr,&g_factory_param_init.state_ctr,len-2);
        // 获取已保存的参数文件的大小
        result = stat(FACTORY_PARAM_PATH,&file_stat);
        if(result != SF_OK)
        {
            goto __write_default;
        }
        // 参数文件大小小于结构体大小，只读实际文件大小的数据填充结构体前面的部分
        if(file_stat.st_size < len)
        {
            len = file_stat.st_size;
        }

        ret = sdk_para_read(FILE_TYPE_FACTORY_PARAM, 0, (uint8_t *)&factory_para_temp, len);
        if(ret != len)  
        {
            log_i((int8_t *)"\n factory param has changed, rewrite default  %d %d!!! \n",ret,sizeof(factory_paramater_t)); // 测试用
            goto __write_default;
        }
        else
        {
            if(factory_para_temp.validity_flag == FILE_VALID) 
            {
                len = sizeof(factory_paramater_t);
                result = sdk_para_write(FILE_TYPE_FACTORY_PARAM, 0, (uint8_t *)(&factory_para_temp), len);
                if (result == len)
                {
                    ret = sdk_para_sync(FILE_TYPE_FACTORY_PARAM);
                    log_i((int8_t *)"\n [ok] device param file init success \n"); // 测试用
                    goto __exit;
                }
                else
                {
                    ret = -1;
                }
            }
        }
    }
    else if (ret < 0)
    {
        log_e((int8_t *)"\n [error] sdk_para_init factory param fail! \n");
        goto __exit;
    }
__write_default:
    // 给工厂参数写默认值
    len = sizeof(factory_paramater_t);
    result = sdk_para_write(FILE_TYPE_FACTORY_PARAM, 0, (uint8_t *)(&g_factory_param_init), len);
    if (result == len)
    {
        ret = sdk_para_sync(FILE_TYPE_FACTORY_PARAM);
        log_i((int8_t *)"\n [ok] factory param file init success!!!\n"); // 测试用
    }
    else
    {
        ret = -1;
    }

__exit:
    return ret;
}

/**
 * @brief   设备参数文件初始化
 * @param        
 * @return       
 * @retval
 */
void param_record_file_init(void)
{
    uint16_t i = 0;
    int32_t ret[4] = {0};
 //   uint16_t bat_cluster_pack_num;
   // constant_parameter_data_t *p_data = sdk_shm_constant_parameter_data_get();     // 定值/参数

    /*para000初始化*/
    ret[0] = dev_param_file_init();
    if (ret[0] < 0)
    {
        log_e((int8_t *)"\n [error] dev param file init fail!!!\n");
    }

    /*para001初始化*/
   // p_data = sdk_shm_constant_parameter_data_get();
    g_app_param_init.validity_flag = FILE_VALID;
    memcpy((&g_app_param_init.container_sys_param_data), &g_container_sys_param_init, sizeof(container_system_parameter_data_t));
    memcpy((&g_app_param_init.container_sys_param_data2), &g_container_sys_param_init2, sizeof(container_system_parameter_data2_t));

  //  bat_cluster_pack_num = p_data->bat_cluster_pack_num;
    for (i = 0; i < BCU_DEVICE_NUM; i++)
    {
        memcpy((&g_app_param_init.battery_parameter_data[i]), &g_battery_paramater_init, sizeof(battery_parameter_data_t));
    }

    ret[1] = app_param_file_init();
    if (ret[1] < 0)
    {
        log_e((int8_t *)"\n [error] app param file init fail!!!\n");
    }

    /*para002初始化*/
    ret[2] = factory_param_file_init();
    if (ret[2] < 0)
    {
        log_e((int8_t *)"\n [error] factory param file init fail!!!\n");
    }

    /*para004初始化*/
    ret[3] = bat_cap_test_param_file_init();
    if (ret[3] < 0)
    {
        log_e((int8_t *)"\n [error] bat cap test param file init fail!!!\n");
    }
}



/**
 * @brief   检查热管理逻辑版本，版本不一致则复位热管理默认参数
 * @param
 * @return  
 * @note    
 */
void check_hot_manage_version( void )
{
    #define SYS_INFO_FILE_PATH       "/user/data/para/sys_info.json"

    char wr_sys_info_js_str[ 1024 ] = {0};
    char sys_info_js_str[ 1024 ] = {0};
    int32_t ret;

    fs_t *p_fs = sdk_fs_open((const int8_t *)SYS_INFO_FILE_PATH, FS_READ | FS_WRITE | FS_OPEN_ALWAYS );

    if (p_fs == NULL)
    {
        log_e((int8_t *)"[%s:%d] open file fail \n", __func__, __LINE__);
        return;
    }
    
    if ( 0 > sdk_fs_read( p_fs, sys_info_js_str, sizeof( sys_info_js_str ) ))
    {
        log_e((int8_t *)"[%s:%d] open %s file fail \n", __func__, __LINE__, SYS_INFO_FILE_PATH);
        sdk_fs_close( p_fs );
        return;
    }
    sdk_fs_close( p_fs );

    char local_ver_str[20] = {0};
    sprintf( local_ver_str, "%d.%d", HOT_MANAGE_MAJOR_VERSION, HOT_MANAGE_SUB_VERSION );
    if ( SF_TRUE == json_utils_str_key_val_str_cmp( sys_info_js_str, "/hotManageVer", local_ver_str ))
    {
        /* 版本一致，不做处理 */
        return;
    }

    /* 版本不一致，复位热管理默认参数，并保存 */
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

   
    memcpy( &p_para_data->dynamic_ring.bat_Dts,  
            &g_container_sys_param_init.dynamic_ring.bat_Dts,
            ((void*)&p_para_data->dynamic_ring.sys_standby_current - (void*)&p_para_data->dynamic_ring.bat_Dts) + sizeof( uint16_t ) );
    memcpy( &p_para_data->dynamic_ring2.keep_temper_enable,  
            &g_container_sys_param_init2.dynamic_ring.keep_temper_enable,
            ((void*)&p_para_data->dynamic_ring2.pre_heating_forbid_charge_discharge_temper - (void*)&p_para_data->dynamic_ring2.keep_temper_enable) + sizeof(uint16_t) );
    
    app_param_save();
    app_param_save();

    if ( 0 == strlen( sys_info_js_str ))
    {
        sys_info_js_str[0] = '{';
        sys_info_js_str[1] = '}'; 
    }
    
    /* 保存版本信息 */
    js_val_t ver_val = { .type = JS_VAL_TYPE_STR, .p_str_val = local_ver_str };
    if ( SF_OK != json_utils_str_add_leaf_val( wr_sys_info_js_str, sys_info_js_str, "/hotManageVer", &ver_val ))
    {
        log_e((int8_t *)"[%s:%d] add ver leaf val fail \n", __func__, __LINE__);
        return;
    }

    p_fs = sdk_fs_open((const int8_t *)SYS_INFO_FILE_PATH, FS_CREATE_ALWAYS | FS_WRITE);
    if (p_fs == NULL)
    {
        log_e((int8_t *)"[%s:%d] open file fail \n", __func__, __LINE__);
        return;
    }
    
    ret = sdk_fs_write( p_fs, wr_sys_info_js_str, strlen( wr_sys_info_js_str ) );
    if (ret != strlen( wr_sys_info_js_str ) )
    {
        log_e((int8_t *)"[%s:%d] write wr_sys_info_js_str fail \n", __func__, __LINE__);
    }
    sdk_fs_close( p_fs );

    return;
}


/**
 * @brief   对共享内存的数据初始化
 * @param
 * @return  
 * @note    对应配置参数，优先从文件读取，若文件读取失败，则赋默认值
 */
void shm_data_init(void)
{
    uint8_t i = 0;
    uint8_t j = 0;
    uint8_t k = 0;
    int32_t ret[4] = {0};
    uint32_t len[4] = {0};
    uint16_t bat_cluster_pack_num;
    
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();              // 遥信
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();              // 遥测
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数
    other_parameter_data_t *p_other_data = sdk_shm_other_parameter_data_get();      // 其他参数
    internal_shared_data_t *p_internal_data = internal_shared_data_get();           // 内部共用参数
    internal_version_info_t *p_version_info = internal_version_info_get();          // 内部版本信息
    firmware_update_t *p_update_info = sdk_shm_firmware_update_info_get();          // 升级相关信息
    web_control_info_t *p_web_info = shm_web_control_info_get();                    // web 控制操作数据
    battery_cluster_telemetry_info_t *p_battery_telemetry = NULL; // 电池遥测数据
    system_fault_recorder_data_t *p_fault_record_0 = sdk_shm_fault_record_data_get(0);
    system_fault_recorder_data_t *p_fault_record_1 = sdk_shm_fault_record_data_get(1);
    
    if ((NULL == p_telematic_data) || (NULL == p_telemetry_data) || (NULL == p_para_data) || (NULL == p_other_data) \
        || (NULL == p_internal_data) || (NULL == p_version_info) || (NULL == p_web_info) || (p_fault_record_0 == NULL)\
        || (p_fault_record_1 == NULL))
    {
        log_e((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    // 初始化 共享内存中 遥信信息
    memset(p_telematic_data, 0, sizeof(telematic_data_t));
	
    // 初始化 共享内存中 遥测信息
    memset(p_telemetry_data, 0, sizeof(telemetry_data_t));
    
    // 电流、温度值存在偏移量，初始化是需赋对应值使其初始时外部显示为0
    for (i = 0; i < BCU_DEVICE_NUM; i++)
    {
        p_battery_telemetry = sdk_shm_battery_cluster_telemetry_info_get(i);
        if (NULL == p_battery_telemetry)
        {
            log_e((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
            return;
        }

        p_battery_telemetry->cluster_current = 16000;

        for (j = 0; j < 4; j++)
        {
            p_battery_telemetry->high_pressure_box_temperature[j] = 40;

            if (j < 3)
            {
                p_battery_telemetry->highest_monomer_temperature_cluster[j] = 40;
                p_battery_telemetry->lowest_monomer_temperature_cluster[j] = 40;
            } 
        }

        p_battery_telemetry->average_temperature_monomer = 40;

        for (j = 0; j < PACK_NUMBER; j++)
        {
            for (k = 0; k < MONOMER_NUMBER_IN_PACK; k++)
            {
                p_battery_telemetry->monomer_info[j].monomer_temperature[k] = 40;

                if (k < POLE_TEMP_NUM_IN_PACK)
                {
                    p_battery_telemetry->pole_temperater_PACK[j][k] = 40;
                }
            }
        }
    }
    
    // 初始化 共享内存中 内部共用参数
    memset(p_internal_data, 0, sizeof(internal_shared_data_t));
    
    // 初始化 共享内存中 升级相关数据
    memset(p_update_info, 0, sizeof(firmware_update_t));

    // 初始化 共享内存中 web 控制操作数据
    memset(p_web_info, 0, sizeof(web_control_info_t));

    // 初始化 共享内存软件版本号
    memset(p_version_info, 0, sizeof(internal_version_info_t));
    p_version_info->mcu2_app_soft_version[0] = PRESET_SOFTWARE_VERSION_TPYE;
    p_version_info->mcu1_core_soft_version[0] = PRESET_SOFTWARE_VERSION_TPYE;
    p_version_info->mcu2_core_soft_version[0] = PRESET_SOFTWARE_VERSION_TPYE;
    p_version_info->mcu1_app_soft_version[0] = MCU1_SOFTWARE_VERSION_TPYE;
    p_version_info->mcu1_app_soft_version[1] = MCU1_SOFTWARE_MAJOR_VERSION;
    p_version_info->mcu1_app_soft_version[2] = MCU1_SOFTWARE_MINOR_VERSION;
    p_version_info->mcu1_app_soft_version[3] = MCU1_SOFTWARE_STAGE_VERSION;
    p_version_info->can_protocol_version = CAN_PROTOCOL_VERSION;

    // 初始化 共享内存中 故障录波数据
    memset(p_fault_record_0,0,sizeof(system_fault_recorder_data_t));
    memset(p_fault_record_1,0,sizeof(system_fault_recorder_data_t));

    // 定值参数和其他参数
    len[0] = sizeof(device_paramater_t);
    ret[0] = sdk_para_read(FILE_TYPE_DEVICE_PARAM, 0, (uint8_t *)(&g_dev_param), len[0]);

    len[1] = sizeof(application_paramater_t);
    ret[1] = sdk_para_read(FILE_TYPE_APP_PARAM, 0, (uint8_t *)(&g_app_param), len[1]);

    len[2] = sizeof(factory_paramater_t);
    ret[2] = sdk_para_read(FILE_TYPE_FACTORY_PARAM, 0, (uint8_t *)(&g_factory_param), len[2]);
    
    len[3] = sizeof(bat_cap_test_paramater_t);
    ret[3] = sdk_para_read(FILE_TYPE_CAP_TEST_PARAM, 0, (uint8_t *)(&g_bat_cap_test_param), len[3]);

    if (ret[0] == len[0])
    {
        memcpy(&(p_other_data->address_rs485_4), &(g_dev_param.dev_param_other_data.address_rs485_4), \
                sizeof(device_paramater_other_t));
        memcpy(&(p_para_data->storage_duration_operation_data),  \
                (&(g_dev_param.device_paramater_sys_data.storage_duration_operation_data)), \
                (sizeof(device_paramater_sys_t) - 2));
        p_para_data->bat_cluster_pack_num = g_dev_param.device_paramater_sys_data.bat_cluster_pack_num;  //电池簇内PACK个数
        p_para_data->soc_charge_limit = g_dev_param.device_paramater_sys_data.soc_charge_limit;  //充电上限
        p_para_data->soc_discharge_limit = g_dev_param.device_paramater_sys_data.soc_discharge_limit;  //放电下限
        p_para_data->eol_threshold = g_dev_param.device_paramater_sys_data.eol_threshold;
        p_para_data->cmu_mode = g_dev_param.device_paramater_sys_data.cmu_mode;
        p_para_data->bat_cabinet_num = g_dev_param.device_paramater_sys_data.bat_cabinet_num;
        p_para_data->energy_cabinet_FF_addr = g_dev_param.device_paramater_sys_data.energy_cabinet_FF_addr;
        p_para_data->energy_cabinet_num = g_dev_param.device_paramater_sys_data.energy_cabinet_num;
        p_para_data->iec104_bcu_upload_time = g_dev_param.device_paramater_sys_data.iec104_bcu_upload_time;
        p_para_data->iec104_pcs_upload_time = g_dev_param.device_paramater_sys_data.iec104_pcs_upload_time;
        p_para_data->safety_rdr_country = g_dev_param.device_paramater_sys_data.safety_rdr_country;
        p_para_data->ver_safety_rdr_para = g_dev_param.device_paramater_sys_data.ver_safety_rdr_para;
        p_para_data->idle_to_sleep_tm = g_dev_param.device_paramater_sys_data.idle_to_sleep_tm;
        p_para_data->sleep_to_pow_off_tm = g_dev_param.device_paramater_sys_data.sleep_to_pow_off_tm;
        p_para_data->sleep_to_pow_off_enable = g_dev_param.device_paramater_sys_data.sleep_to_pow_off_enable;
        p_para_data->idle_to_sleep_enable = g_dev_param.device_paramater_sys_data.idle_to_sleep_enable;
        p_para_data->external_epo_input_type = g_dev_param.device_paramater_sys_data.external_epo_input_type;
        sdk_shm_get()->other_parameter_data.iec104_upload_enable = g_dev_param.device_paramater_sys_data.iec104_upload_enable;
        
        memcpy(p_para_data->device_sn, g_dev_param.device_paramater_sys_data.device_sn, sizeof(g_dev_param.device_paramater_sys_data.device_sn)); //设备SN号
        memcpy(p_version_info->dev_sn, g_dev_param.device_paramater_sys_data.device_sn, sizeof(g_dev_param.device_paramater_sys_data.device_sn)); //设备SN号
    } 
    else    // 设备配置参数读取失败
    {
        memcpy(&(p_other_data->address_rs485_4), &(g_dev_param_init.dev_param_other_data.address_rs485_4), \
                sizeof(device_paramater_other_t));
        memcpy(&(p_para_data->storage_duration_operation_data), \
                (&(g_dev_param_init.device_paramater_sys_data.storage_duration_operation_data)), \
                (sizeof(device_paramater_sys_t) - 2));
        p_para_data->bat_cluster_pack_num = g_dev_param_init.device_paramater_sys_data.bat_cluster_pack_num;  //电池簇内PACK个数
        p_para_data->soc_charge_limit = g_dev_param_init.device_paramater_sys_data.soc_charge_limit;  //充电上限
        p_para_data->soc_discharge_limit = g_dev_param_init.device_paramater_sys_data.soc_discharge_limit;  //放电下限
        p_para_data->eol_threshold = g_dev_param_init.device_paramater_sys_data.eol_threshold;
        p_para_data->cmu_mode = g_dev_param_init.device_paramater_sys_data.cmu_mode;
        p_para_data->bat_cabinet_num = g_dev_param_init.device_paramater_sys_data.bat_cabinet_num;
        p_para_data->energy_cabinet_FF_addr = g_dev_param_init.device_paramater_sys_data.energy_cabinet_FF_addr;
        p_para_data->energy_cabinet_num = g_dev_param_init.device_paramater_sys_data.energy_cabinet_num;
        p_para_data->iec104_bcu_upload_time = g_dev_param_init.device_paramater_sys_data.iec104_bcu_upload_time;
        p_para_data->iec104_pcs_upload_time = g_dev_param_init.device_paramater_sys_data.iec104_pcs_upload_time;
        p_para_data->safety_rdr_country = g_dev_param_init.device_paramater_sys_data.safety_rdr_country;
        p_para_data->ver_safety_rdr_para = g_dev_param_init.device_paramater_sys_data.ver_safety_rdr_para;
        p_para_data->idle_to_sleep_tm = g_dev_param_init.device_paramater_sys_data.idle_to_sleep_tm;
        p_para_data->sleep_to_pow_off_tm = g_dev_param_init.device_paramater_sys_data.sleep_to_pow_off_tm;
        p_para_data->sleep_to_pow_off_enable = g_dev_param_init.device_paramater_sys_data.sleep_to_pow_off_enable;
        p_para_data->idle_to_sleep_enable    = g_dev_param_init.device_paramater_sys_data.idle_to_sleep_enable;
        p_para_data->external_epo_input_type    = g_dev_param_init.device_paramater_sys_data.external_epo_input_type;
        sdk_shm_get()->other_parameter_data.iec104_upload_enable = g_dev_param_init.device_paramater_sys_data.iec104_upload_enable;
        
        memcpy(p_para_data->device_sn, g_dev_param_init.device_paramater_sys_data.device_sn, sizeof(g_dev_param_init.device_paramater_sys_data.device_sn)); //设备SN号
        memcpy(p_version_info->dev_sn, g_dev_param_init.device_paramater_sys_data.device_sn, sizeof(g_dev_param_init.device_paramater_sys_data.device_sn)); //设备SN号
        log_e((int8_t *)"\n [error] device_paramater read fail \n"); // 测试用
    }

    if (ret[1] == len[1])
    {
        memcpy(&(p_para_data->cluster_curr_diff_warn_threshold_1), \
               &(g_app_param.container_sys_param_data.cluster_curr_diff_warn_threshold_1), \
               sizeof(container_system_parameter_data_t));

        memcpy(&(p_para_data->dynamic_ring2), \
               &(g_app_param.container_sys_param_data2.dynamic_ring), \
               sizeof(dynamic_ring_parameter_data2_t));

        bat_cluster_pack_num = p_para_data->bat_cluster_pack_num;
        for (i = 0; i < BCU_DEVICE_NUM; i++)
        {
            g_app_param.battery_parameter_data[i].cluster_OVP_warn_threshold_1 = (g_app_param.battery_parameter_data[i].PACK_OVP_warn_threshold_1) * bat_cluster_pack_num;
            g_app_param.battery_parameter_data[i].cluster_OVP_warn_threshold_2 = (g_app_param.battery_parameter_data[i].PACK_OVP_warn_threshold_2) * bat_cluster_pack_num;
            g_app_param.battery_parameter_data[i].cluster_OVP_warn_threshold_3 = (g_app_param.battery_parameter_data[i].PACK_OVP_warn_threshold_3) * bat_cluster_pack_num;
            g_app_param.battery_parameter_data[i].cluster_UVP_warn_threshold_1 = (g_app_param.battery_parameter_data[i].PACK_UVP_warn_threshold_1) * bat_cluster_pack_num;
            g_app_param.battery_parameter_data[i].cluster_UVP_warn_threshold_2 = (g_app_param.battery_parameter_data[i].PACK_UVP_warn_threshold_2) * bat_cluster_pack_num;
            g_app_param.battery_parameter_data[i].cluster_UVP_warn_threshold_3 = (g_app_param.battery_parameter_data[i].PACK_UVP_warn_threshold_3) * bat_cluster_pack_num;
        }
        memcpy(&(p_para_data->battery_parameter_data[0]), &(g_app_param.battery_parameter_data[0]), \
                (sizeof(battery_parameter_data_t) * BCU_DEVICE_NUM));
    } 
    else    // 应用设置参数读取失败
    {
        // 初始化 共享内存中 集装箱系统的定值/参数信息
        memcpy(&(p_para_data->cluster_curr_diff_warn_threshold_1), \
               &(g_container_sys_param_init.cluster_curr_diff_warn_threshold_1), \
               sizeof(container_system_parameter_data_t));
        memcpy(&(p_para_data->dynamic_ring2), \
               &(g_container_sys_param_init2), \
               sizeof(container_system_parameter_data2_t));
        bat_cluster_pack_num = p_para_data->bat_cluster_pack_num;
        // 初始化 共享内存中 集装箱内电池簇的定值/参数信息
        for (i = 0; i < BCU_DEVICE_NUM; i++)
        {
            memcpy(&(p_para_data->battery_parameter_data[i].ISO_warn_threshold_1), &g_battery_paramater_init, \
                sizeof(battery_parameter_data_t));
            p_para_data->battery_parameter_data[i].cluster_OVP_warn_threshold_1 = (g_battery_paramater_init.PACK_OVP_warn_threshold_1) * bat_cluster_pack_num;
            p_para_data->battery_parameter_data[i].cluster_OVP_warn_threshold_2 = (g_battery_paramater_init.PACK_OVP_warn_threshold_2) * bat_cluster_pack_num;
            p_para_data->battery_parameter_data[i].cluster_OVP_warn_threshold_3 = (g_battery_paramater_init.PACK_OVP_warn_threshold_3) * bat_cluster_pack_num;
            p_para_data->battery_parameter_data[i].cluster_UVP_warn_threshold_1 = (g_battery_paramater_init.PACK_UVP_warn_threshold_1) * bat_cluster_pack_num;
            p_para_data->battery_parameter_data[i].cluster_UVP_warn_threshold_2 = (g_battery_paramater_init.PACK_UVP_warn_threshold_2) * bat_cluster_pack_num;
            p_para_data->battery_parameter_data[i].cluster_UVP_warn_threshold_3 = (g_battery_paramater_init.PACK_UVP_warn_threshold_3) * bat_cluster_pack_num;
        }
        
        log_e((int8_t *)"\n [error] app_paramater read fail \n"); // 测试用
    }
    
    if (ret[2] == len[2])
    {
        memcpy(&(p_other_data->state_ctr), &(g_factory_param.state_ctr), (sizeof(factory_paramater_t) - 2));
    } 
    else    // 工厂参数读取失败
    {
        memcpy(&(p_other_data->state_ctr), &(g_factory_param_init.state_ctr), (sizeof(factory_paramater_t) - 2));
        log_i((int8_t *)"\n [error] factory_paramater read fail \n"); // 测试用
    }
	p_para_data->battery_cap_test_flag = 0;
	if (ret[3] == len[3])
    {
        if (   ( g_bat_cap_test_param.validity_flag == true )
            && ( g_bat_cap_test_param.bat_cap_test_mode == 1) )
        {
            p_para_data->battery_cap_test_flag |= ( 1<<0 );
        }
        else
        {
            p_para_data->battery_cap_test_flag &= ~(1<<0);
        }
    }
}

/**
 * @brief   子设备的应用设置参数确认
 * @param
 * @return  
 * @note    将从文件读取的设置参数与从子设备获取的应用参数进行对比，
 *          若不一致，报 文件中应用设置参数与实际不一致 的提示
 */
void app_param_comparison(void)
{
    uint8_t i = 0;
    int16_t result = 0;
    int32_t ret = 0;
    uint32_t len = 0;
    uint8_t bat_cluster_pack_num = 0;
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();   // 遥信数据
    battery_parameter_data_t *p_battery_param = NULL;
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    // 将从电池簇读取到的电池设置参数，与文件中存储的电池设置参数对比，若不一致报"存储数据与实际运行数据不一致"提示
    if (ENABLE == g_battery_set_param_read_status)
    {
        battery_set_param_read_status_set(DISABLE);

        len = (sizeof(battery_parameter_data_t) * BCU_DEVICE_NUM);
        memset(&(g_app_param.battery_parameter_data[0]), 0, len);
        ret = sdk_para_read(FILE_TYPE_APP_PARAM, (2 + sizeof(container_system_parameter_data_t)), \
                            (uint8_t *)(&(g_app_param.battery_parameter_data[0])), len);
        if (ret == len)
        {
            bat_cluster_pack_num = p_para_data->bat_cluster_pack_num;
            for (i = 0; i < BCU_DEVICE_NUM; i++)
            {
                g_app_param.battery_parameter_data[i].cluster_OVP_warn_threshold_1 = (g_app_param.battery_parameter_data[i].PACK_OVP_warn_threshold_1) * bat_cluster_pack_num;
                g_app_param.battery_parameter_data[i].cluster_OVP_warn_threshold_2 = (g_app_param.battery_parameter_data[i].PACK_OVP_warn_threshold_2) * bat_cluster_pack_num;
                g_app_param.battery_parameter_data[i].cluster_OVP_warn_threshold_3 = (g_app_param.battery_parameter_data[i].PACK_OVP_warn_threshold_3) * bat_cluster_pack_num;
                g_app_param.battery_parameter_data[i].cluster_UVP_warn_threshold_1 = (g_app_param.battery_parameter_data[i].PACK_UVP_warn_threshold_1) * bat_cluster_pack_num;
                g_app_param.battery_parameter_data[i].cluster_UVP_warn_threshold_2 = (g_app_param.battery_parameter_data[i].PACK_UVP_warn_threshold_2) * bat_cluster_pack_num;
                g_app_param.battery_parameter_data[i].cluster_UVP_warn_threshold_3 = (g_app_param.battery_parameter_data[i].PACK_UVP_warn_threshold_3) * bat_cluster_pack_num;
                p_battery_param = sdk_shm_battery_parameter_data_get(i);

                if (NULL == p_battery_param)
                {
                    break;
                }
                
                result = memcmp(&(g_app_param.battery_parameter_data[i]), p_battery_param, \
                                sizeof(battery_parameter_data_t));
                if (result)
                {
                    // 文件设备参数与实际不一致故障 置位 CMU_system_fault_info[0]-bit7
                    p_telematic_data->CMU_system_fault_info[0] |= (1 << 7);
                    log_e((int8_t *)"\n [error] The stored data is inconsistent with the actual operation data!!! \n"); // 测试用
                    break;
                }
                else
                {
                    p_telematic_data->CMU_system_fault_info[0] &= ~(1 << 7);
                }
            }
        }
        else
        {
            log_e((int8_t *)"\n [error] Function[%s] read dev param file fail!!! \n",  __func__);
        }
    }
}


/**
 * @brief   电池簇定值/参数（阈值）恢复出厂设置
 * @param   无
 * @return  [int32_t] 执行结果
 * @retval  =0  成功
 * @retval  <0  失败
 * @note
 */
int32_t battery_parameter_data_reset(void)
{
    uint8_t i;
    uint8_t bat_cluster_pack_num = 0;
    battery_parameter_data_t reset_data;
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    if (NULL == p_para_data)
    {
        log_e((int8_t *)"\n [%s:%d] null pointer!\n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    bat_cluster_pack_num = p_para_data->bat_cluster_pack_num;

    memcpy(&reset_data, &g_battery_paramater_init, sizeof(battery_parameter_data_t));
    reset_data.cluster_OVP_warn_threshold_1 = (g_battery_paramater_init.PACK_OVP_warn_threshold_1) * bat_cluster_pack_num;
    reset_data.cluster_OVP_warn_threshold_2 = (g_battery_paramater_init.PACK_OVP_warn_threshold_2) * bat_cluster_pack_num;
    reset_data.cluster_OVP_warn_threshold_3 = (g_battery_paramater_init.PACK_OVP_warn_threshold_3) * bat_cluster_pack_num;
    reset_data.cluster_UVP_warn_threshold_1 = (g_battery_paramater_init.PACK_UVP_warn_threshold_1) * bat_cluster_pack_num;
    reset_data.cluster_UVP_warn_threshold_2 = (g_battery_paramater_init.PACK_UVP_warn_threshold_2) * bat_cluster_pack_num;
    reset_data.cluster_UVP_warn_threshold_3 = (g_battery_paramater_init.PACK_UVP_warn_threshold_3) * bat_cluster_pack_num;

    for (i = 0; i < BCU_DEVICE_NUM; i++)
    {
        memcpy(&(p_para_data->battery_parameter_data[i]), &reset_data, sizeof(battery_parameter_data_t));
    }

    return SF_OK;
}

static int32_t bat_cap_test_param_file_init(void)
{
    bat_cap_test_paramater_t bat_cap_test_paramater;
    int32_t read_len = 0;
    int32_t ret = 0;
    int32_t ret1 = 0, ret2 = 0;

    log_i((const int8_t*)"%s\r\n", __FUNCTION__);
    ret = sdk_para_init( FILE_TYPE_CAP_TEST_PARAM, FILE_SIZE_CAP_TEST_PARAM );
    if ( ret != 0 )
    {
        log_e( (const int8_t*)"sdk_para_init FILE_TYPE_CAP_TEST_PARAM error!!!\r\n" );
        return -1;
    }

    /* 设置默认数值 */
    memset( &bat_cap_test_paramater, 0, sizeof(bat_cap_test_paramater));

    read_len = sdk_para_read( FILE_TYPE_CAP_TEST_PARAM, 0, (uint8_t *)&bat_cap_test_paramater, sizeof( bat_cap_test_paramater_t )  );
    if ( read_len == 0 )
    {
        /* 未进入容测模式，无需处理 */
        return 0;
    }

    if ( bat_cap_test_paramater.validity_flag != FILE_VALID )
    {
        /* 文件数据不正确 */
        log_e( (const int8_t *)"[ERROR] bat_cap_test_paramater.validity_flag != FILE_VALID" );
        goto __write_default;
    }
    memcpy( &g_bat_cap_test_param , &bat_cap_test_paramater, sizeof( bat_cap_test_paramater_t ));

    return ret;

__write_default:
    /* 默认数据 */
    log_i((const int8_t*)"%s __write_default\r\n", __FUNCTION__);
    memset( &bat_cap_test_paramater, 0, sizeof(bat_cap_test_paramater_t) );
    bat_cap_test_paramater.validity_flag = FILE_VALID;
    memcpy( &g_bat_cap_test_param , &bat_cap_test_paramater, sizeof( bat_cap_test_paramater_t ));
    ret1 = sdk_para_write( FILE_TYPE_CAP_TEST_PARAM, 0, (uint8_t *)&bat_cap_test_paramater, sizeof(bat_cap_test_paramater_t) );
    ret2 = sdk_para_write( FILE_TYPE_CAP_TEST_PARAM, 0, (uint8_t *)&bat_cap_test_paramater, sizeof(bat_cap_test_paramater_t) );
    if ( (ret1 < 0) || (ret2 < 0) )
    {
        return -2;
    }
    sdk_para_sync( FILE_TYPE_CAP_TEST_PARAM );

    return 0;
}

/**
 * @brief   读取 电池容测临时参数
 * @param   
 * @retval  0       成功
 * @retval  其他    失败
*/
int32_t bat_cap_test_data_restore( bat_cap_test_paramater_t *p_bat_cap_test_param  )
{
    bat_cap_test_paramater_t tmp_bat_cap_test_param;
    int32_t read_len = 0;

    log_i((const int8_t*)"%s", __FUNCTION__);

    /* 设置默认数值 */
    memset( &tmp_bat_cap_test_param, 0, sizeof(bat_cap_test_paramater_t));

    read_len = sdk_para_read( FILE_TYPE_CAP_TEST_PARAM, 0, (uint8_t *)&tmp_bat_cap_test_param, sizeof( bat_cap_test_paramater_t )  );
    if ( read_len != sizeof( bat_cap_test_paramater_t ) )
    {
        log_e( (int8_t *)"read cap test param error!!!\r\n" );
        return -1;
    }
   
    if ( tmp_bat_cap_test_param.validity_flag != FILE_VALID )
    {
        log_e( (int8_t *)"cap test param valid flag error!!!\r\n" );
        return -2;
    }
    memcpy( p_bat_cap_test_param, &tmp_bat_cap_test_param, sizeof( bat_cap_test_paramater_t ) ) ;

    return 0;
}

/**
 * @brief   电池容测临时参数清除
 * @param   
 * @retval  0       成功
 * @retval  其他    失败
*/
int32_t bat_cap_test_data_clear( void )
{
    bat_cap_test_paramater_t  bat_cap_test_param = { .validity_flag = FILE_VALID, .bat_cap_test_mode = 0 };

    log_i((const int8_t*)"%s\r\n", __FUNCTION__);
    int32_t ret1 = sdk_para_write( FILE_TYPE_CAP_TEST_PARAM, 0, (uint8_t *)&bat_cap_test_param, sizeof(bat_cap_test_paramater_t));
    int32_t ret2 = sdk_para_write( FILE_TYPE_CAP_TEST_PARAM, 0, (uint8_t *)&bat_cap_test_param, sizeof(bat_cap_test_paramater_t));
    if ( (ret1 < 0) || (ret2 < 0) )
    {
        log_e( (int8_t *)"clear battery cap test param error, ret1:%d, ret2:%d!!!\r\n", ret1, ret2 );
        return -1;
    }
    sdk_para_sync( FILE_TYPE_CAP_TEST_PARAM );
    return 0;
}

/**
 * @brief   电池容测临时参数保存
 * @param   
 * @retval  0       成功
 * @retval  其他    失败
*/
int32_t bat_cap_test_data_save( void )
{
    bat_cap_test_paramater_t  bat_cap_test_param = { .validity_flag = FILE_VALID, .bat_cap_test_mode = 1 };
    constant_parameter_data_t *p_constant_param  = sdk_shm_constant_parameter_data_get(); // 定值/参数
    int32_t ret1, ret2;
    application_paramater_t app_param_temp;

    memset(&app_param_temp, 0, sizeof(application_paramater_t));
    sdk_para_read(FILE_TYPE_APP_PARAM, 0, (uint8_t *)(&app_param_temp), sizeof(application_paramater_t));
    app_param_temp.battery_parameter_data[0].cluster_OVP_warn_threshold_1 = (app_param_temp.battery_parameter_data[0].PACK_OVP_warn_threshold_1) * p_constant_param->bat_cluster_pack_num;
    app_param_temp.battery_parameter_data[0].cluster_OVP_warn_threshold_2 = (app_param_temp.battery_parameter_data[0].PACK_OVP_warn_threshold_2) * p_constant_param->bat_cluster_pack_num;
    app_param_temp.battery_parameter_data[0].cluster_OVP_warn_threshold_3 = (app_param_temp.battery_parameter_data[0].PACK_OVP_warn_threshold_3) * p_constant_param->bat_cluster_pack_num;
    app_param_temp.battery_parameter_data[0].cluster_UVP_warn_threshold_1 = (app_param_temp.battery_parameter_data[0].PACK_UVP_warn_threshold_1) * p_constant_param->bat_cluster_pack_num;
    app_param_temp.battery_parameter_data[0].cluster_UVP_warn_threshold_2 = (app_param_temp.battery_parameter_data[0].PACK_UVP_warn_threshold_2) * p_constant_param->bat_cluster_pack_num;
    app_param_temp.battery_parameter_data[0].cluster_UVP_warn_threshold_3 = (app_param_temp.battery_parameter_data[0].PACK_UVP_warn_threshold_3) * p_constant_param->bat_cluster_pack_num;

    memcpy( &bat_cap_test_param.usr_battery_param, &app_param_temp.battery_parameter_data[0], sizeof(battery_parameter_data_t));
    mem_utils_print_hex_dat( __FUNCTION__ , (uint8_t*)&bat_cap_test_param, sizeof(bat_cap_test_param), 10, true );
    ret1 = sdk_para_write( FILE_TYPE_CAP_TEST_PARAM, 0, (uint8_t *)&bat_cap_test_param, sizeof(bat_cap_test_paramater_t));
    ret2 = sdk_para_write( FILE_TYPE_CAP_TEST_PARAM, 0, (uint8_t *)&bat_cap_test_param, sizeof(bat_cap_test_paramater_t));
    if ( (ret1 < 0) || (ret2 < 0) )
    {
        log_e( (const int8_t *)"save battery cap test param error, ret1:%d, ret2:%d!!!\r\n", ret1, ret2 );
        return -1;
    }
    sdk_para_sync( FILE_TYPE_CAP_TEST_PARAM );

    return 0;
}

/**
 * @brief   设备配置参数存储
 * @param   
 * @retval  0       成功
 * @retval  其他    失败
*/
int32_t dev_param_save(void)
{
    int32_t ret = 0;
    int32_t result = 0;
    int32_t len = 0;
    device_paramater_t *p_data = &g_dev_param;
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数
    other_parameter_data_t *p_other_data = sdk_shm_other_parameter_data_get();      // 其他参数
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();
    internal_version_info_t *p_version_info = internal_version_info_get();          // 内部版本信息

    if ((NULL == p_data) || (NULL == p_para_data) || (NULL == p_other_data))
    {
        ret = -1;
        goto __exit;
    }

    p_data->validity_flag = FILE_VALID;
    memcpy(&(p_data->dev_param_other_data.address_rs485_4), &(p_other_data->address_rs485_4), \
           sizeof(device_paramater_other_t));

    memcpy(&(p_data->device_paramater_sys_data.storage_duration_operation_data), \
           &(p_para_data->storage_duration_operation_data), \
           (sizeof(device_paramater_sys_t) - 2));
    p_data->device_paramater_sys_data.bat_cluster_pack_num = p_para_data->bat_cluster_pack_num;
    p_data->device_paramater_sys_data.soc_charge_limit = p_para_data->soc_charge_limit;
    p_data->device_paramater_sys_data.soc_discharge_limit = p_para_data->soc_discharge_limit;
    p_data->device_paramater_sys_data.eol_threshold = p_para_data->eol_threshold;
    p_data->device_paramater_sys_data.cmu_mode = p_para_data->cmu_mode;
    p_data->device_paramater_sys_data.bat_cabinet_num = p_para_data->bat_cabinet_num;
    p_data->device_paramater_sys_data.energy_cabinet_FF_addr = p_para_data->energy_cabinet_FF_addr;
    p_data->device_paramater_sys_data.energy_cabinet_num = p_para_data->energy_cabinet_num;
    p_data->device_paramater_sys_data.iec104_pcs_upload_time = p_para_data->iec104_pcs_upload_time;
    p_data->device_paramater_sys_data.iec104_bcu_upload_time = p_para_data->iec104_bcu_upload_time;
    p_data->device_paramater_sys_data.safety_rdr_country = p_para_data->safety_rdr_country;
    p_data->device_paramater_sys_data.ver_safety_rdr_para = p_para_data->ver_safety_rdr_para;
    p_data->device_paramater_sys_data.idle_to_sleep_tm = p_para_data->idle_to_sleep_tm;
    p_data->device_paramater_sys_data.sleep_to_pow_off_tm = p_para_data->sleep_to_pow_off_tm;
    p_data->device_paramater_sys_data.sleep_to_pow_off_enable = p_para_data->sleep_to_pow_off_enable;
    p_data->device_paramater_sys_data.idle_to_sleep_enable = p_para_data->idle_to_sleep_enable;
    p_data->device_paramater_sys_data.external_epo_input_type = p_para_data->external_epo_input_type;
    p_data->device_paramater_sys_data.iec104_upload_enable = sdk_shm_other_parameter_data_get()->iec104_upload_enable;

    memcpy(p_data->device_paramater_sys_data.device_sn, p_para_data->device_sn, sizeof(p_para_data->device_sn));
    memcpy(p_version_info->dev_sn, p_para_data->device_sn, sizeof(p_para_data->device_sn));
    
    len = sizeof(device_paramater_t);
    result = sdk_para_write(FILE_TYPE_DEVICE_PARAM, 0, (uint8_t *)p_data, len);

    if (result == len)
    {
        log_i((int8_t *)"\n dev param sync \n");
        ret = sdk_para_sync(FILE_TYPE_DEVICE_PARAM);
    }
    else
    {
        ret = -1;
    }

__exit:
    return ret;
}


/**
 * @brief   应用设置参数存储
 * @param   
 * @retval  0       成功
 * @retval  其他    失败
*/
int32_t app_param_save(void)
{
    // uint8_t battery_id = 0;
    int32_t ret = 0;
    int32_t result = 0;
    int32_t len = 0;
    uint8_t i = 0;
    uint8_t bat_cluster_pack_num = 0;
    application_paramater_t *p_data = &g_app_param;
    application_paramater_t temp_data;
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数
    if ((NULL == p_data) || (NULL == p_para_data))
    {
        ret = -1;
        goto __exit;
    }
    bat_cluster_pack_num = p_para_data->bat_cluster_pack_num;

    // battery_id = p_para_data->battery_cluster_id;    // 电池簇编号

    p_data->validity_flag = FILE_VALID;
    memcpy(&(p_data->container_sys_param_data.cluster_curr_diff_warn_threshold_1), \
           &(p_para_data->cluster_curr_diff_warn_threshold_1), \
           sizeof(container_system_parameter_data_t));
    memcpy(&(p_data->container_sys_param_data2.dynamic_ring), \
        &(p_para_data->dynamic_ring2), \
        sizeof(dynamic_ring_parameter_data2_t));
    memcpy(&(p_data->battery_parameter_data[0]), &(p_para_data->battery_parameter_data[0]), \
            (sizeof(battery_parameter_data_t) * BCU_DEVICE_NUM));

    memcpy(&temp_data, p_data, sizeof(application_paramater_t));
  
    for (i = 0; i < BCU_DEVICE_NUM; i++)
    {
        temp_data.battery_parameter_data[i].cluster_OVP_warn_threshold_1 = (temp_data.battery_parameter_data[i].cluster_OVP_warn_threshold_1) / bat_cluster_pack_num;
        temp_data.battery_parameter_data[i].cluster_OVP_warn_threshold_2 = (temp_data.battery_parameter_data[i].cluster_OVP_warn_threshold_2) / bat_cluster_pack_num;
        temp_data.battery_parameter_data[i].cluster_OVP_warn_threshold_3 = (temp_data.battery_parameter_data[i].cluster_OVP_warn_threshold_3) / bat_cluster_pack_num;
        temp_data.battery_parameter_data[i].cluster_UVP_warn_threshold_1 = (temp_data.battery_parameter_data[i].cluster_UVP_warn_threshold_1) / bat_cluster_pack_num;
        temp_data.battery_parameter_data[i].cluster_UVP_warn_threshold_2 = (temp_data.battery_parameter_data[i].cluster_UVP_warn_threshold_2) / bat_cluster_pack_num;
        temp_data.battery_parameter_data[i].cluster_UVP_warn_threshold_3 = (temp_data.battery_parameter_data[i].cluster_UVP_warn_threshold_3) / bat_cluster_pack_num;
    }

    len = sizeof(application_paramater_t);
    // result = sdk_para_write(FILE_TYPE_APP_PARAM, 0, (uint8_t *)p_data, len);
    result = sdk_para_write(FILE_TYPE_APP_PARAM, 0, (uint8_t *)(&temp_data), len);

    if (result == len)
    {
        log_i((int8_t *)"\n app param sync \n");
        ret = sdk_para_sync(FILE_TYPE_APP_PARAM);
    }
    else
    {
        ret = -1;
    }

__exit:
    return ret;
}

/**
 * @brief   工厂参数存储
 * @param   
 * @retval  0       成功
 * @retval  其他    失败
*/
int32_t factory_param_save(void)
{
    int32_t ret = 0;
    int32_t result = 0;
    int32_t len = 0;
    factory_paramater_t *p_data = &g_factory_param;
    other_parameter_data_t *p_other_data = sdk_shm_other_parameter_data_get();      // 其他参数

    if ((NULL == p_data) || (NULL == p_other_data))
    {
        ret = -1;
        goto __exit;
    }
    

    p_data->validity_flag = FILE_VALID;
    memcpy(&(p_data->state_ctr), &(p_other_data->state_ctr), (sizeof(factory_paramater_t) - 2));
    
    len = sizeof(factory_paramater_t);
    result = sdk_para_write(FILE_TYPE_FACTORY_PARAM, 0, (uint8_t *)p_data, len);

    if (result == len)
    {
        log_i((int8_t *)"\n factory param sync\n");
        ret = sdk_para_sync(FILE_TYPE_FACTORY_PARAM);
    }
    else
    {
        ret = -1;
    }

__exit:
    return ret;
}

/**
 * @brief   集装箱阈值参数存储
 * @param   
 * @retval  0       成功
 * @retval  其他    失败
*/
int32_t container_system_param_save(void)
{
    // uint8_t battery_id = 0;
    int32_t ret = 0;
    int32_t result = 0;
    int32_t len = 0;
    application_paramater_t *p_data = &g_app_param;
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    if ((NULL == p_data) || (NULL == p_para_data))
    {
        ret = -1;
        goto __exit;
    }

    p_data->validity_flag = FILE_VALID;
    memcpy(&(p_data->container_sys_param_data.cluster_curr_diff_warn_threshold_1), \
           &(p_para_data->cluster_curr_diff_warn_threshold_1), \
           sizeof(container_system_parameter_data_t));
    
    len = sizeof(container_system_parameter_data_t) + 2;
    result = sdk_para_write(FILE_TYPE_APP_PARAM, 0, (uint8_t *)p_data, len);

    if (result == len)
    {
        log_i((int8_t *)"\n container system parameter sync!! \n");
        ret = sdk_para_sync(FILE_TYPE_APP_PARAM);
    }
    else
    {
        ret = -1;
    }

__exit:
    return ret;
}

/**
 * @brief   电池阈值参数存储
 * @param   
 * @retval  0       成功
 * @retval  其他    失败
*/
int32_t battery_param_save(void)
{
    // uint8_t battery_id = 0;
    int32_t ret = 0;
    int32_t result = 0;
    int32_t len = 0;
    uint8_t i = 0;
    uint8_t bat_cluster_pack_num = 0;
    application_paramater_t *p_data = &g_app_param;
    application_paramater_t temp_data;
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    if ((NULL == p_data) || (NULL == p_para_data))
    {
        ret = -1;
        goto __exit;
    }

    bat_cluster_pack_num = p_para_data->bat_cluster_pack_num;

    len = sizeof(battery_parameter_data_t) * BCU_DEVICE_NUM;
    memcpy(&(p_data->battery_parameter_data[0]), &(p_para_data->battery_parameter_data[0]), len);

    memcpy(&temp_data, p_data, sizeof(application_paramater_t));
    for (i = 0; i < BCU_DEVICE_NUM; i++)
    {
        temp_data.battery_parameter_data[i].cluster_OVP_warn_threshold_1 = (temp_data.battery_parameter_data[i].cluster_OVP_warn_threshold_1) / bat_cluster_pack_num;
        temp_data.battery_parameter_data[i].cluster_OVP_warn_threshold_2 = (temp_data.battery_parameter_data[i].cluster_OVP_warn_threshold_2) / bat_cluster_pack_num;
        temp_data.battery_parameter_data[i].cluster_OVP_warn_threshold_3 = (temp_data.battery_parameter_data[i].cluster_OVP_warn_threshold_3) / bat_cluster_pack_num;
        temp_data.battery_parameter_data[i].cluster_UVP_warn_threshold_1 = (temp_data.battery_parameter_data[i].cluster_UVP_warn_threshold_1) / bat_cluster_pack_num;
        temp_data.battery_parameter_data[i].cluster_UVP_warn_threshold_2 = (temp_data.battery_parameter_data[i].cluster_UVP_warn_threshold_2) / bat_cluster_pack_num;
        temp_data.battery_parameter_data[i].cluster_UVP_warn_threshold_3 = (temp_data.battery_parameter_data[i].cluster_UVP_warn_threshold_3) / bat_cluster_pack_num;
    }

    result = sdk_para_write(FILE_TYPE_APP_PARAM, (sizeof(container_system_parameter_data_t) + 2), \
                            (uint8_t *)(&(temp_data.battery_parameter_data[0])), len);

    if (result == len)
    {
        log_i((int8_t *)"\n battery threshold sync!!! \n");
        ret = sdk_para_sync(FILE_TYPE_APP_PARAM);
    }
    else
    {
        ret = -1;
    }

__exit:
    return ret;
}

/**
 * @brief   设备配置参数读取
 * @param   
 * @retval  0       成功
 * @retval  其他    失败
 * @note    从文件中读取设备参数，若文件读取成功，将读取内容更新至共享内存
 *          若读取失败则不更新
 */
int32_t dev_param_read(void)
{
    int32_t ret = 0;
    int32_t result = 0;
    uint32_t len = 0;

    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数
    other_parameter_data_t *p_other_data = sdk_shm_other_parameter_data_get();      // 其他参数

    if ((NULL == p_para_data) || (NULL == p_other_data))
    {
        ret = -1;
        goto __exit;
    }

    // 读取应用设置参数文件
    len = sizeof(device_paramater_t);
    result = sdk_para_read(FILE_TYPE_DEVICE_PARAM, 0, (uint8_t *)(&g_dev_param), len);

    if (result == len)
    {
        ret = 0;
        memcpy(&(p_para_data->storage_duration_operation_data),  \
                (&(g_dev_param.device_paramater_sys_data.storage_duration_operation_data)), \
                (sizeof(device_paramater_sys_t) - 2));
        p_para_data->cmu_mode = g_dev_param.device_paramater_sys_data.cmu_mode;

        memcpy(&(p_other_data->address_rs485_4), &(g_dev_param.dev_param_other_data.address_rs485_4), \
                sizeof(device_paramater_other_t));
    } 
    else    // 设备配置参数读取失败
    {
        ret = -1;
        log_e((int8_t *)"\n [%s:%s:%d] device_paramater read fail \n", __FILE__,__func__, __LINE__); // 测试用
    }

__exit:
    return ret;
}

/**
 * @brief   电池阈值参数读取
 * @param   
 * @retval  0       成功
 * @retval  其他    失败
 * @note    从文件中读取设置参数，若文件读取成功，将读取内容更新至共享内存
 *          若读取失败则不更新
 */
int32_t battery_param_read(void)
{
    int32_t ret = 0;
    int32_t result = 0;
    uint32_t len = 0;
    uint8_t i = 0;
    uint8_t bat_cluster_pack_num = 0;

    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    if (NULL == p_para_data)
    {
        ret = -1;
        goto __exit;
    }

    bat_cluster_pack_num = p_para_data->bat_cluster_pack_num;

    // 读取应用设置参数文件 中 电池簇的阈值信息
    len = sizeof(battery_parameter_data_t) * BCU_DEVICE_NUM;
    result = sdk_para_read(FILE_TYPE_APP_PARAM, (sizeof(container_system_parameter_data_t) + 2), \
                           (uint8_t *)(&g_app_param.battery_parameter_data[0]), len);

    if (result == len)  // 读取成功，更新数据到共享内存
    {
        for (i = 0; i < BCU_DEVICE_NUM; i++)
        {
            g_app_param.battery_parameter_data[i].cluster_OVP_warn_threshold_1 = (g_app_param.battery_parameter_data[i].cluster_OVP_warn_threshold_1) * bat_cluster_pack_num;
            g_app_param.battery_parameter_data[i].cluster_OVP_warn_threshold_2 = (g_app_param.battery_parameter_data[i].cluster_OVP_warn_threshold_2) * bat_cluster_pack_num;
            g_app_param.battery_parameter_data[i].cluster_OVP_warn_threshold_3 = (g_app_param.battery_parameter_data[i].cluster_OVP_warn_threshold_3) * bat_cluster_pack_num;
            g_app_param.battery_parameter_data[i].cluster_UVP_warn_threshold_1 = (g_app_param.battery_parameter_data[i].cluster_UVP_warn_threshold_1) * bat_cluster_pack_num;
            g_app_param.battery_parameter_data[i].cluster_UVP_warn_threshold_2 = (g_app_param.battery_parameter_data[i].cluster_UVP_warn_threshold_2) * bat_cluster_pack_num;
            g_app_param.battery_parameter_data[i].cluster_UVP_warn_threshold_3 = (g_app_param.battery_parameter_data[i].cluster_UVP_warn_threshold_3) * bat_cluster_pack_num;
        }
        ret = 0;

        memcpy(&(p_para_data->battery_parameter_data[0]), &(g_app_param.battery_parameter_data[0]), \
                (sizeof(battery_parameter_data_t) * BCU_DEVICE_NUM));
    } 
    else    // 参数读取失败
    {
        ret = -1;
        log_e((int8_t *)"\n [%s:%s:%d] app_paramater read fail \n", __FILE__,__func__, __LINE__); // 测试用
    }

__exit:
    return ret;
}
