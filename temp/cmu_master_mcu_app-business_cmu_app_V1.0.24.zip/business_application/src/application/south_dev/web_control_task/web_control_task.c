/** 
 * @file          web_control_task.c
 * @brief         响应 web 控制操作的任务线程
 * @author        xiaojuying
 * @note
 * @version       V0.0.1     初版
 * @date          2023/5/6
 */
#include "low_power_task.h"
#include "mem_utils.h"
#include "web_control_task.h"
#include "param_record_task.h"
#include "process_battery_read.h"
#include "battery_fun_interface.h"
#include "pcs_fun_interface.h"
#include "sci_task.h"
#include "iec104_slave.h"
#include "sdk_shm.h"
#include "sdk_public.h"
#include "sdk_para.h"
#include "sdk_net_public.h"
#include <sofar_errors.h>
#include <pthread.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

#include "sofar_type.h"

#define BAT_PARA_UPDATE_WAIT_COUNT      (6)     // 6s


typedef struct
{
    int16_t monomer_OVP_warn_threshold_2;               // 单体电压2级过压报警阈值  精度：0.001V 偏移量：0
    int16_t monomer_UVP_warn_threshold_2;               // 单体电压2级欠压报警阈值  精度：0.001V 偏移量：0
    int16_t monomer_UVP_warn_threshold_3;               // 单体电压3级欠压报警阈值  精度：0.001V 偏移量：0
    int16_t PACK_OVP_warn_threshold_2;                  // PACK电压2级过压报警阈值  精度：0.1V 偏移量：0
    int16_t PACK_UVP_warn_threshold_2;                  // PACK电压2级欠压报警阈值  精度：0.1V 偏移量：0
    int16_t PACK_UVP_warn_threshold_3;                  // PACK电压3级欠压报警阈值  精度：0.1V 偏移量：0
}ft_cap_test_bat_para_data_t;

static battery_parameter_data_t g_battery_param_data[BCU_DEVICE_NUM];
static void battery_param_set_handle(void);

static int32_t sdk_system_cmd(int8_t * cmd)
{
    FILE *fp = NULL;

    if((fp=popen((const char*)cmd, "r")) == NULL)
    {
        return -1;
    }
    pclose(fp);

    return 0;
}


static void modify_net_conf(uint8_t device,const uint8_t is_dhcp, uint8_t *p_ip, uint8_t *p_netmask, uint8_t *p_gw, uint8_t *p_dns1, uint8_t *p_dns2)
{
   if(is_dhcp == 1)
   {
		if (ETH1 == device)
		{
			 system("udhcpc -b -i eth1");
        	 return;		   
		}
        system("udhcpc -b -i eth0");
        return;
   }
   if(sdk_net_ip_set(device, p_ip) < 0)
   {
        log_i((int8_t *)"set ip failed");
        return;
   }

   if(sdk_net_subnetmask_set(device, p_netmask) < 0)
   {
        log_i((int8_t *)"set subnet mask failed");
        return;
   }

   if(sdk_net_gateway_set(device, p_gw) < 0)
   {
        log_i((int8_t *)"set gateway failed");
        return;
   }

   if(sdk_net_dns_set(device, p_dns1)< 0)
   {
        log_i((int8_t *)"set dns1 failed");
        return;
   }
   //我们目前暂不支持DNS2的配置,后续看情况如何将DNS用起来
}


/**
 * @brief   电池簇定值/参数（阈值）复位更新
 * @param   无
 * @return  [int32_t] 执行结果
 * @retval  =0  成功
 * @retval  <0  失败
 * @note
 */
static int32_t battery_parameter_data_reset_update(void)
{
    int32_t ret1;

    web_control_info_t *p_web_data = shm_web_control_info_get();

    if (NULL == p_web_data)
    {
        log_e((int8_t *)"\n [%s:%d] null pointer!\n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    ret1 = battery_parameter_data_reset();
    if (SF_OK == ret1)
    {
        p_web_data->battery_threshold_update_flag = ENABLE; // 电池阈值更新
    }

    return ret1;
}


/** 
 * @brief   恢复出厂设置
 * @param
 * @return
 * @note
 */
static int32_t reset(void)
{
    int32_t result;
    int32_t ret = 0;
    uint16_t data = 0;
	constant_parameter_data_t * p_param = sdk_shm_constant_parameter_data_get();
	constant_parameter_data_t temp = {0};


	memcpy(&temp,p_param,sizeof(constant_parameter_data_t));
	

    ret = sdk_para_init(FILE_TYPE_DEVICE_PARAM, FILE_SIZE_DEVICE_PARAM);
	if(ret == 0)
    {
        result = sdk_para_write(FILE_TYPE_DEVICE_PARAM, 0, (uint8_t *)&data, 2);
        
	    if (result == 2)
	    {
	        ret = sdk_para_sync(FILE_TYPE_DEVICE_PARAM);
	        printf("\n [ok] device param file sdk_para_sync \n"); // 测试用
	    }
	    else
	    {
	        ret = -1;
			printf("\n [fail] device param file sdk_para_write \n"); 
	    }
	    usleep(1000 * 100);
	        
	    result = sdk_para_write(FILE_TYPE_DEVICE_PARAM, 0, (uint8_t *)&data, 2);
	        
	    if (result == 2)
	    {
	        printf("\n set com config flag \n");
	        ret = sdk_para_sync(FILE_TYPE_DEVICE_PARAM);
	        printf("\n [ok] device param file sdk_para_sync \n");
	    }
	    else
	    {
	        ret = -1;
			printf("\n [fail] device param file sdk_para_write \n"); 
	    }
    }
    

	ret = sdk_para_init(FILE_TYPE_APP_PARAM, FILE_SIZE_APP_PARAM);

	if(0 == ret)
	{
		
		result = sdk_para_write(FILE_TYPE_APP_PARAM, 0, (uint8_t *)&data, 2);
				
		if (result == 2)
		{
			ret = sdk_para_sync(FILE_TYPE_APP_PARAM);
			printf("\n [ok] app param file sdk_para_sync \n"); // 测试用
		}
		else
		{
			ret = -1;
			printf("\n [fail] app param file sdk_para_write \n"); 
		}
		usleep(1000 * 100);
			
		result = sdk_para_write(FILE_TYPE_APP_PARAM, 0, (uint8_t *)&data, 2);
			
		if (result == 2)
		{
			printf("\n set com config flag \n");
			ret = sdk_para_sync(FILE_TYPE_APP_PARAM);
			printf("\n [ok] app param file sdk_para_sync \n");
		}
		else
		{
			ret = -1;
			printf("\n [fail] app param file sdk_para_write \n"); 
		}
	}

	modify_net_conf(ETH0,0,(uint8_t*)"192.168.1.100",(uint8_t*)"255.255.255.0",(uint8_t*)"192.168.1.1",(uint8_t*)"114.114.114.114",(uint8_t*)"202.96.128.86");
	modify_net_conf(ETH1,0,(uint8_t*)"192.168.2.100",(uint8_t*)"255.255.255.0",(uint8_t*)"192.168.2.1",(uint8_t*)"114.114.114.114",(uint8_t*)"202.96.128.86");

	sdk_system_cmd((int8_t*)"sync");
    sleep(1);
    sdk_system_cmd((int8_t*)"reboot -f");
	return ret;
}

static void update_epo_type_to_shm(void)
{
    constant_parameter_data_t *p_para_data = NULL;
    internal_shared_data_t *p_internal_data = NULL;
    uint8_t temp_buf[4];
    uint8_t tm_year = 0;
    uint8_t tm_month = 0;
    
    p_para_data = sdk_shm_constant_parameter_data_get();    // 定值/参数
    p_internal_data =  internal_shared_data_get();
    if(p_para_data == NULL || p_internal_data == NULL)
    {
        return;
    }
    memset(temp_buf,0,sizeof(temp_buf));
    temp_buf[0] = p_para_data->device_sn[11];
    temp_buf[1] = p_para_data->device_sn[12];
    tm_year = atoi((const char*)temp_buf);

    memset(temp_buf,0,sizeof(temp_buf));
    temp_buf[0] = p_para_data->device_sn[13];
    if(temp_buf[0] >= '1' && temp_buf[0] <= '9')
    {
        tm_month = atoi((const char*)temp_buf);
    }
    else if(temp_buf[0] >= 'A' && temp_buf[0] <= 'C')
    {
        tm_month = temp_buf[0] - 55;
    }
    else 
    {
        tm_month = 1;
    }

    if(tm_year == 24)
    {
        if(tm_month >= 12)
        {
            p_internal_data->epo_trigger_type = EPO_TRIGGER_LOW;
        }
        else
        {
            p_internal_data->epo_trigger_type = EPO_TRIGGER_HIGH;
        }
    }
    else if(tm_year > 24)
    {
        p_internal_data->epo_trigger_type = EPO_TRIGGER_LOW;
    }
    else 
    {
       p_internal_data->epo_trigger_type = EPO_TRIGGER_HIGH; 
    }
    return;
}


/** 
 * @brief   响应 web 对电池遥控量的操作
 * @param
 * @return
 * @note    检测共享内存对应标志位，若电池对应的遥控操作标志位被置位，则给电池下发对应控制指令
 */
static void battery_remote_control_handle(void)
{
    uint8_t i = 0;
    uint8_t j = 0;
    uint8_t temp = 0;
    other_parameter_data_t *p_other_data = sdk_shm_other_parameter_data_get(); // 共享内存-其他参数
    web_control_info_t *p_web_data = shm_web_control_info_get();
    uint8_t bat_cluster_pack_num = 0;
    uint8_t cluster_index;
    battery_parameter_data_t *p_para = NULL;
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    if (NULL == p_web_data)
    {
        return;
    }

    for (i = 0; i < 16; i++)
    {
        temp = ((p_web_data->CMU_system_control_off) >> i) & 0x01;
        if (ENABLE == temp)
        { 
            switch (i)
            {
                case 0: // 远程关机
                {
                    printf("\n web remote off 远程关机 \n");
                    p_other_data->remote_on_off_ctrl = REMOTE_POWER_OFF;
                    low_power_task_set_usr_power_sta( SF_FALSE );
                    break;
                }

                case 1: // 液冷系统关机
                {
                    printf("\n web liquid cooling off\n");
                    p_other_data->LC_on_off_ctrl = REMOTE_POWER_OFF;
                    set_constant_data(FUNCID_SET_POWER_ONOFF_LC);
                    break;
                }

                case 2: // pcs关机
                {
                    // printf("\n web pcs poweroff \n");
                    pcs_power_control(PCS_POWER_OFF);
                    break;
                }

                case 3: // 关闭排气扇
                {
                    // printf("\n web exhaust fan poweroff \n");
                    p_other_data->EF_on_off_ctrl = REMOTE_FAN_POWER_OFF;
                    set_constant_data(FUNCID_SET_FAN_STATUS);
                    break;
                }

                default:
                    break;
            }

            if ((0 == i) || (1 == i))
            {
                // 调用固化参数接口
                dev_param_save();
                dev_param_save();
            }
            
            p_web_data->CMU_system_control_off &= ~(1 << i);
        }
        
        temp = ((p_web_data->CMU_system_control_on) >> i) & 0x01;
        if (ENABLE == temp)
        {
            switch (i)
            {
                case 0: // 远程开机
                {
                    printf("\n web remote on 远程开机 \n");
                    p_other_data->remote_on_off_ctrl = REMOTE_POWER_ON;
                    low_power_task_set_usr_power_sta( SF_TRUE );
                    break;
                }

                case 1: // 液冷系统开机
                {
                    printf("\nweb liquid cooling on\n");
                    p_other_data->LC_on_off_ctrl = REMOTE_POWER_ON;
                    set_constant_data(FUNCID_SET_POWER_ONOFF_LC);
                    break;
                }

                case 2: // pcs开机
                {
                    // printf("\n web pcs poweron \n");
                    pcs_power_control(PCS_POWER_ON);
                    break;
                }

                case 3: // 打开排气扇
                {
                    // printf("\n web exhaust fan poweron \n");
                    p_other_data->EF_on_off_ctrl = REMOTE_FAN_POWER_ON;
                    set_constant_data(FUNCID_SET_FAN_STATUS);
                    break;
                }

                default:
                    break;
            }
            
            if ((0 == i) || (1 == i))
            {
                // 调用固化参数接口
                dev_param_save();
                dev_param_save();
            }

            p_web_data->CMU_system_control_on &= ~(1 << i);
        }
    }

    for (i = 0; i < BCU_DEVICE_NUM; i++)
    {
        temp = ((p_web_data->battery_power_off) >> i) & 0x01; // 第i电池簇下电
        if (ENABLE == temp)
        {

            // printf("\n web第%d电池簇下电 \n", i);
            battery_power_control(POWER_OFF, (i + 1));
            p_web_data->battery_power_off &= ~(1 << i);
        }

        temp = ((p_web_data->battery_power_on) >> i) & 0x01; // 第i电池簇上电
        if (ENABLE == temp)
        {
            // printf("\n web第%d电池簇上电 \n", i);
            battery_power_control(POWER_ON, (i + 1));
            p_web_data->battery_power_on &= ~(1 << i);
        }

        for (j = 0; j < 8; j++)
        {
            // 控制第i电池簇的第j个DO口输出有效
            temp = ((p_web_data->battery_DO_control_on[i]) >> j) & 0x01;
            if (ENABLE == temp)
            {
                set_DO_output(i, j, DI_DO_HIGH);
                p_web_data->battery_DO_control_on[i] &= ~(1 << j);
            }
            
            // 控制第i电池簇的第j个DO口输出无效
            temp = ((p_web_data->battery_DO_control_off[i]) >> j) & 0x01;
            if (ENABLE == temp)
            {
                set_DO_output(i, j, DI_DO_LOW);
                p_web_data->battery_DO_control_off[i] &= ~(1 << j);
            }
        }
    }
    
    temp = p_web_data->battery_power_off_all;   // 所有簇下电
    if (ENABLE == temp)
    {
        // 产生操作日志 id依据104点表
        battery_power_control(POWER_OFF, 0);
        p_web_data->battery_power_off_all = DISABLE;
    }

    temp = p_web_data->liquid_cooling_param_update_flag;   // 设置液冷参数
    if (ENABLE == temp)
    {
        printf("\n web liquid cooling param set \n");
        set_constant_data(FUNCID_SET_PARA_SYSTEM_LC);
        p_web_data->liquid_cooling_param_update_flag = DISABLE;
        container_system_param_save();
        container_system_param_save();
    }

    temp = p_web_data->cmu_mode_update_flag;   // 设置CMU模式
    if (ENABLE == temp)
    {
        printf("\n web cmu mode set \n");
        set_constant_data(FUNCID_SET_PARA_CONTAINER);
        p_web_data->cmu_mode_update_flag = DISABLE;
        // 调用固化参数接口
        dev_param_save();
        dev_param_save();
    }

    temp = p_web_data->sys_reset;   // 恢复出厂设置
    if (ENABLE == temp)
    {
        printf("\n web cmu sys reset \n");
        battery_parameter_data_reset_update();
        battery_param_set_handle();
        reset();
        p_web_data->sys_reset = DISABLE;
    }

    temp = p_web_data->clear_history_data_flag;   // 清除历史数据
    if (ENABLE == temp)  // 数据清除
    {
        log_i((const int8_t*)"[%s:%d] web clear data \n",__func__, __LINE__);
        p_web_data->clear_history_data_flag = 0;
		sleep(1);
        system("rm -rf /media/mmcblk0p1/*;rm -rf /user/data/event/*;rm -rf /user/data/opt_log/*;rm -rf /user/data/power/*;rm -rf /user/data/energy/*;");
		sdk_system_cmd((int8_t*)"sync");
        sleep(1);
	    sdk_system_cmd((int8_t*)"reboot -f");
        
    }

    temp = p_web_data->bat_cabinet_num_update_flag;   // 设置电池仓个数
    if (ENABLE == temp)
    {
        set_constant_data(FUNCID_SET_PARA_BATT_CAB_NUM);
        p_web_data->bat_cabinet_num_update_flag = DISABLE;
        // 调用固化参数接口
        dev_param_save();
        dev_param_save();
    }

    temp = p_web_data->enenrgy_cabinet_attr_update_flag;   // 设置储能柜属性
    if (ENABLE == temp)
    {
        set_constant_data(FUNCID_SET_ENEGY_CAB_ATTR);
        p_web_data->enenrgy_cabinet_attr_update_flag = DISABLE;
        dev_param_save();
        dev_param_save();
    }

    temp = p_web_data->charge_discharge_soc_limit_set_flag;   // 设置SOC充放电上下限
    if (ENABLE == temp)
    {
        p_web_data->charge_discharge_soc_limit_set_flag = DISABLE;
        dev_param_save();
        dev_param_save();
    }

    temp = p_web_data->pack_num_set_flag;   // 设置PACK个数,此时簇端过压/欠压阈值要跟随pack个数自动变化
    if (ENABLE == temp)
    {
        p_web_data->pack_num_set_flag = DISABLE;
        bat_cluster_pack_num = p_para_data->bat_cluster_pack_num;
        for (cluster_index = 0; cluster_index < BCU_DEVICE_NUM; cluster_index++)
        {
            p_para = sdk_shm_battery_parameter_data_get(cluster_index);
            p_para->cluster_OVP_warn_threshold_1 = p_para->PACK_OVP_warn_threshold_1 * bat_cluster_pack_num;
            p_para->cluster_OVP_warn_threshold_2 = p_para->PACK_OVP_warn_threshold_2 * bat_cluster_pack_num;
            p_para->cluster_OVP_warn_threshold_3 = p_para->PACK_OVP_warn_threshold_3 * bat_cluster_pack_num;
            p_para->cluster_UVP_warn_threshold_1 = p_para->PACK_UVP_warn_threshold_1 * bat_cluster_pack_num;
            p_para->cluster_UVP_warn_threshold_2 = p_para->PACK_UVP_warn_threshold_2 * bat_cluster_pack_num;
            p_para->cluster_UVP_warn_threshold_3 = p_para->PACK_UVP_warn_threshold_3 * bat_cluster_pack_num;
        }
        p_web_data->battery_threshold_update_flag = ENABLE;
        dev_param_save();
        dev_param_save();
    }

    temp = p_web_data->dev_sn_set_flag;  //设置SN号
    if (ENABLE == temp)
    {
        p_web_data->dev_sn_set_flag = DISABLE;
        dev_param_save();
        dev_param_save();
        update_epo_type_to_shm();
    }

    temp = p_web_data->eol_threshold_set_flag;
    if (ENABLE == temp)
    {
        p_web_data->eol_threshold_set_flag = DISABLE;
        dev_param_save();
        dev_param_save();
    }

    temp =  p_web_data->external_epo_type_set_flag;		// 外部EPO输入类型设置	
    if (ENABLE == temp)
    {
        p_web_data->external_epo_type_set_flag = 0;
        dev_param_save();
        dev_param_save();
    }	

    temp = p_web_data->run_storage_param_update_flag;   // 设置运行数据保存参数
    if (ENABLE == temp)
    {
        p_web_data->run_storage_param_update_flag = 0;
        dev_param_save();
        dev_param_save();
    }

    temp =  p_web_data->external_protocol_set_flag;		// 外部EMS协议设置
    if (ENABLE == temp)
    {
        p_web_data->external_protocol_set_flag = 0;
        dev_param_save();
        dev_param_save();
    }	
}

static void low_power_setting_set_handle(void)
{ 
    if ( BIT_GET( shm_web_control_info_get()->low_power_setting_flag, 0) )
    {
        constant_parameter_data_t *p_constant_param = sdk_shm_constant_parameter_data_get();
        
        low_power_set_idle_to_sleep_enable( p_constant_param->idle_to_sleep_enable );
        low_power_set_sleep_to_power_off_enable( p_constant_param->sleep_to_pow_off_enable );
        low_power_set_idle_to_sleep_mode_time( p_constant_param->idle_to_sleep_tm );
        low_power_set_sleep_to_power_off_time( p_constant_param->sleep_to_pow_off_tm );

        BIT_CLR( shm_web_control_info_get()->low_power_setting_flag, 0);
    }
}

/** 
 * @brief   保温模式参数设置响应接口
 * @param
 * @return
 */
static void keep_warm_param_set_handle(void)
{ 
    web_control_info_t *web_control_info = NULL;

    web_control_info = shm_web_control_info_get();
    if(web_control_info == NULL)
    {
        return;
    }

    if ( web_control_info->keep_warm_param_set_flag == 1 )
    {
        web_control_info->keep_warm_param_set_flag = 0;
        set_constant_data(FUNCID_SET_PARA_LOGIC_LC);
        app_param_save();
        app_param_save();
    }
}

/** 
 * @brief   pcs功率软启时间梯度设置响应接口
 * @param
 * @return
 */
static void pcs_powerup_time_set_handle(void)
{ 
    web_control_info_t *web_control_info = NULL;

    web_control_info = shm_web_control_info_get();
    if(web_control_info == NULL)
    {
        return;
    }
    
    if ( web_control_info->pcs_powerup_gradident_set_flag == 1 )
    {
        web_control_info->pcs_powerup_gradident_set_flag = 0;
        pcs_powerup_gradident_set_control(web_control_info->pcs_powerup_gradident_setvalue);
    }
}

/** 
 * @brief   pcs工厂模式设置响应接口
 * @param
 * @return
 */
static void pcs_factory_mode_set_handle(void)
{ 
    web_control_info_t *web_control_info = NULL;

    web_control_info = shm_web_control_info_get();
    if(web_control_info == NULL)
    {
        return;
    }
    
    if ( web_control_info->pcs_factory_mode_set_flag & BIT(0) )
    {
        web_control_info->pcs_factory_mode_set_flag &= ~BIT(0);
        pcs_factory_mode_set_control(web_control_info->pcs_factory_mode_set_value);
        // 设置工厂模式后置位最高位，CAN通信线程根据标志位立即回读工厂模式
        web_control_info->pcs_factory_mode_set_flag |= BIT(7);     
    }
}

static void battery_param_set_cap_test_handle(void)
{
    constant_parameter_data_t *p_constant_param      = sdk_shm_constant_parameter_data_get();
    web_control_info_t        *p_web_ctrl            = shm_web_control_info_get();

    if ( (p_web_ctrl->battery_cap_test_set_flag & BIT(0)) == 0 )
    {
        return;
    }
    p_web_ctrl->battery_cap_test_set_flag &= ~BIT(0);

    if ( p_constant_param->battery_cap_test_flag & BIT(0) )
    {
        /* 进入容测模式 */
        const ft_cap_test_bat_para_data_t g_enter_ft_cap_test_para = {
                                                .monomer_OVP_warn_threshold_2 = 3600,
                                                .monomer_UVP_warn_threshold_2 = 2500,
                                                .monomer_UVP_warn_threshold_3 = 2400,
                                                .PACK_OVP_warn_threshold_2 = 1728,
                                                .PACK_UVP_warn_threshold_2 = 1200,
                                                .PACK_UVP_warn_threshold_3 = 1152};

        if ( 0 != bat_cap_test_data_save())
        {
            return;
        }

        /* 使用容测参数 */
        for (size_t i = 0; i < BCU_DEVICE_NUM; i++)
        {
            p_constant_param->battery_parameter_data[i].monomer_OVP_warn_threshold_2 = g_enter_ft_cap_test_para.monomer_OVP_warn_threshold_2;
            p_constant_param->battery_parameter_data[i].monomer_UVP_warn_threshold_2 = g_enter_ft_cap_test_para.monomer_UVP_warn_threshold_2;
            p_constant_param->battery_parameter_data[i].monomer_UVP_warn_threshold_3 = g_enter_ft_cap_test_para.monomer_UVP_warn_threshold_3;
            p_constant_param->battery_parameter_data[i].PACK_OVP_warn_threshold_2    = g_enter_ft_cap_test_para.PACK_OVP_warn_threshold_2;
            p_constant_param->battery_parameter_data[i].PACK_UVP_warn_threshold_2    = g_enter_ft_cap_test_para.PACK_UVP_warn_threshold_2;
            p_constant_param->battery_parameter_data[i].PACK_UVP_warn_threshold_3    = g_enter_ft_cap_test_para.PACK_UVP_warn_threshold_3;
        }
        p_web_ctrl->battery_threshold_update_flag = 1;

    }else{
        /* 进入正常模式， 从文件恢复 */
        bat_cap_test_paramater_t bat_cap_test_paramater;

        if ( 0 != bat_cap_test_data_restore( &bat_cap_test_paramater ))
        {
            return;
        } 

        if ( ( bat_cap_test_paramater.validity_flag == FILE_VALID )
            && ( bat_cap_test_paramater.bat_cap_test_mode == 1 ) )
        {
            mem_utils_print_hex_dat( __FUNCTION__ , (uint8_t*)&bat_cap_test_paramater, sizeof(bat_cap_test_paramater), 10, true );
            bat_cap_test_data_clear();

            /* 恢复 进入容测之前的数据 */
            for (size_t i = 0; i < BCU_DEVICE_NUM; i++)
            {
                p_constant_param->battery_parameter_data[i] = bat_cap_test_paramater.usr_battery_param;
            }
            p_web_ctrl->battery_threshold_update_flag = 1;
        }
    }
}

/** 
 * @brief   响应 web 对电池阈值参数设置的操作
 * @param
 * @return
 * @note    检测共享内存中 电池阈值更新标志位，若置位，则给电池下发阈值设置指令，若阈值设置成功，
 *          将更改后的阈值存入文件，若阈值设置失败，读取参数文件，将共享内存中阈值信息恢复为修改前的数据
 *          （注意需要参数类型字节数保持一致[U16/I16]）
 */
static void battery_param_set_handle(void)
{
    uint8_t i = 0;
    uint8_t j = 0;
    uint8_t k = 0;
    int16_t ret = 0;
    uint16_t offset = 0;
    uint16_t battery_base_id = 0;
    int32_t result = 0;
    uint32_t bat_flag = 0;
    uint32_t len = 0;
    uint16_t *p_shm_data = NULL;
    uint16_t *p_file_data = NULL;
    web_control_info_t *p_web_data = shm_web_control_info_get();
    
    if (NULL == p_web_data)
    {
        log_i((int8_t *)"\n [%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    if (ENABLE != p_web_data->battery_threshold_update_flag)
    {
        return;
    }
    // 读取应用设置参数文件 中 电池簇的阈值信息
    len = sizeof(battery_parameter_data_t) * BCU_DEVICE_NUM;
    result = sdk_para_read(FILE_TYPE_APP_PARAM, (sizeof(container_system_parameter_data_t) + 2), \
                           (uint8_t *)(&g_battery_param_data[0]), len);
    if (result != len)  // 读取失败
    {
        log_i((int8_t *)"\n [%s:%d] app param read error! \n", __func__, __LINE__);
        return;
    }

    for (i = 0; i < BATTERY_PARAM_GROUP_NUM; i++)    // 19-目前有19组阈值
    {
        for (j = 0; j < PARAMETER_NUM_IN_GROUP; j++) // 4-电池阈值4个参数为一组
        {
            offset = (i * PARAMETER_NUM_IN_GROUP) + j;
            
            for (k = 0; k < BCU_DEVICE_NUM; k++)
            {
                p_file_data = (uint16_t *)(&g_battery_param_data[k]);
                p_shm_data = (uint16_t *)(sdk_shm_battery_parameter_data_get(k));

                if ((NULL == p_file_data) || (NULL == p_shm_data))
                {
                    log_i((int8_t *)"\n [%s:%d] Null pointer \n", __func__, __LINE__);
                    return;
                }

                ret = memcmp((p_file_data + offset), (p_shm_data + offset), sizeof(uint16_t));
                if (!ret)
                {
                    continue;
                }
                if ((8 == i) || (10 == i))
                {
                    // 充电单体温度(上、下限)阈值/放电单体温度(上、下限)阈值在同一个设置指令内下发
                    bat_flag |= (1 << (i - 1));
                }
                else if ((16 == i) || (17 == i))
                {
                    // SOC(上限、下限、差值)阈值在同一个接口下发
                    bat_flag |= (1 << 15);
                }
                else
                {
                    bat_flag |= (1 << i);
                }

                break;  // 只要找到一簇有改变，就不需要继续寻后面的簇
            }
        }
    }
   
    for (i = 0; i < BATTERY_PARAM_GROUP_NUM; i++)    // 19-目前有19组阈值
    {
        if (((bat_flag >> i) & 0x01))
        {
            for (j = 0; j < BCU_DEVICE_NUM; j++) // 循环给所有簇下发设置指令
            {
                p_file_data = (uint16_t *)(&g_battery_param_data[j]);
                p_shm_data = (uint16_t *)(sdk_shm_battery_parameter_data_get(j));

                if ((NULL == p_file_data) || (NULL == p_shm_data))
                {
                    log_i((int8_t *)"\n [%s:%d] Null pointer \n", __func__, __LINE__);
                    return;
                }

                switch (i)
                {
                    case 0:
                    {
                        ret = battery_config_table_set(j, ISO_WARN_VALUE);
                        break;
                    }

                    case 1:
                    {
                        ret = battery_config_table_set(j, CLUSTER_OVP_WARN_VALUE);
                        break;
                    }

                    case 2:
                    {
                        ret = battery_config_table_set(j, CLUSTER_UVP_WARN_VALUE);
                        break;
                    }

                    case 3:
                    {
                        
                        ret = battery_config_table_set(j, PACK_OVP_WARN_VALUE);
                        break;
                    }

                    case 4:
                    {
                        
                        ret = battery_config_table_set(j, PACK_UVP_WARN_VALUE);
                        break;
                    }

                    case 5:
                    {
                        ret = battery_config_table_set(j, CHARGE_OCP_WARN_VALUE);
                        break;
                    }

                    case 6:
                    {
                        ret = battery_config_table_set(j, DISCHARGE_OCP_WARN_VALUE);
                        break;
                    }

                    case 7:
                    {
                        ret = battery_config_table_set(j, CHARGE_MONOMER_TEMP_WARN_VALUE);
                        break;
                    }

                    case 9:
                    {
                        ret = battery_config_table_set(j, DISCHARGE_MONOMER_TEMP_WARN_VALUE);
                        break;
                    }

                    case 11:
                    {
                        ret = battery_config_table_set(j, MONOMER_TEMP_DIFF_WARN_VALUE);
                        break;
                    }

                    case 12:
                    {
                        ret = battery_config_table_set(j, MONOMER_OVP_WARN_VALUE);
                        break;
                    }

                    case 13:
                    {
                        ret = battery_config_table_set(j, MONOMER_UVP_WARN_VALUE);
                        break;
                    }

                    case 14:
                    {
                        ret = battery_config_table_set(j, MONOMER_VOL_DIFF_WARN_VALUE);
                        break;
                    }

                    case 15:
                    {
                        ret = battery_config_table_set(j, SOC_WARN_VALUE);
                        break;
                    }

                    case 18:
                    {
                        ret = battery_config_table_set(j, MODULE_TEMP_WARN_VALUE);
                        break;
                    }

                    default:
                        break;
                }

                if ((7 == i) || (9 == i))   // bit7和bit9均对应下发了两组参数
                {
                    len = 2 * PARAMETER_NUM_IN_GROUP * sizeof(uint16_t);
                }
                else if (15 == i)   // bit15-对应下发了三组参数
                {
                    len = 3 * PARAMETER_NUM_IN_GROUP * sizeof(uint16_t);
                }
                else
                {
                    len = PARAMETER_NUM_IN_GROUP * sizeof(uint16_t);
                }

                if (SF_OK != ret)
                {
                    // 设置指令下发失败，将共享内存参数恢复原值
                    memcpy((p_shm_data + (i * PARAMETER_NUM_IN_GROUP)), (p_file_data + (i * PARAMETER_NUM_IN_GROUP)), len);
                }
            }
        }
    }              
    // 存储修改后的值
    battery_param_save();
    battery_param_save();

    p_web_data->battery_threshold_update_flag = DISABLE;
}

/** 
 * @brief   响应 web 的控制操作
 * @param
 * @return
 */
void *thread_web_control(void *arg)
{
    usleep(1000 * 180);	// 通讯板上电后 延时180ms再开始发送指令，否则前面几帧指令容易丢失

    while (1)
    {
        battery_remote_control_handle();
        battery_param_set_handle();
        battery_param_set_cap_test_handle();
        low_power_setting_set_handle();
        keep_warm_param_set_handle();
        pcs_powerup_time_set_handle();
        pcs_factory_mode_set_handle();
        usleep(1000 * 500);	// 500ms
    }
    
    pthread_exit(NULL);
}

/** 
 * @brief   web 控制操作响应任务启动（用于实现web的控制指令、参数设置指令下发、参数更新等）
 * @param
 * @return
 */
void web_control_task_start(void)
{
    int16_t ret = 0;
    pthread_attr_t web_control_attr;
    pthread_t web_control;

    // 初始化线程属性
    ret = pthread_attr_init(&web_control_attr);
    if (ret)
    {
        log_e((int8_t *)"\n [%s:%d] pthread_attr_init error!!! \n", __func__, __LINE__);
        return; // 线程属性初始化出错退出
    }
    
    // 设置线程属性为分离状态
    ret = pthread_attr_setdetachstate(&web_control_attr, PTHREAD_CREATE_DETACHED);
    if (ret)
    {
        log_e((int8_t *)"\n [%s:%d] pthread_attr_setdetachstate web_control_attr error!!! \n", __func__, __LINE__);
        return; // 线程分离属性设置出错退出
    }

    ret = pthread_create(&web_control, &web_control_attr, &thread_web_control, NULL);
    if (ret)
    {
        log_e((int8_t *)"\n [%s:%d] pthread_create web_control error!!! \n", __func__, __LINE__);
        return; // 线程创建出错退出
    }

    // 销毁线程属性结构,它在重新初始化之前不能重新使用
    pthread_attr_destroy(&web_control_attr);
}
