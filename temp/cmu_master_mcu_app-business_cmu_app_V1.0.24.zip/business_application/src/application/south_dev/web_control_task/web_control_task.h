/** 
 * @file          web_control_task.h
 * @brief         响应 web 控制操作的任务线程的外部接口
 * @author        xiaojuying
 * @note
 * @version       V0.0.1     初版
 * @date          2023/5/6
 */


#ifndef __WEB_CONTROL_TASK_H__
#define __WEB_CONTROL_TASK_H__

#include "data_types.h"

#define PARAMETER_NUM_IN_GROUP              (4)         // 一组阈值的参数个数
#define BATTERY_PARAM_GROUP_NUM             (19)        // 电池阈值参数的组别数量

#define YK_DO_START_ADDR                    0x601C      // 电池簇DO控制的起始地址
#define YK_BAT_OFF_ALL_ADDR                 0x601B      // 所有簇下电

/** 
 * @brief   web 控制操作响应任务启动（用于实现web的控制指令、参数设置指令下发、参数更新等）
 * @param
 * @return
 */
void web_control_task_start(void);

#endif  /* __WEB_CONTROL_TASK_H__ */
