#ifndef _DATA_MAP_PROC_H_
#define _DATA_MAP_PROC_H_

#include "sofar_type.h"

sf_ret_t data_map_proc_init( void );

sf_ret_t data_map_modbus_write_register( uint16_t reg_addr, uint16_t reg_cnt, uint16_t *p_wr_vals );
sf_ret_t data_map_modbus_read_register( uint16_t reg_addr, uint16_t reg_cnt, uint16_t *p_rd_vals );

sf_ret_t data_map_iec104_write_register( uint16_t reg_addr, uint16_t reg_cnt, uint16_t *p_wr_vals );
sf_ret_t data_map_iec104_read_register( uint16_t reg_addr, uint16_t reg_cnt, uint16_t *p_rd_vals );

#endif
