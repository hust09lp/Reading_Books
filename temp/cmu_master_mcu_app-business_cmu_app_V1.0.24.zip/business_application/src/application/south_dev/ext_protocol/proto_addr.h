#ifndef _PROTO_ADDR_H_
#define _PROTO_ADDR_H_

/*------------------------------------------ 定值参数 / 遥调 -----------------------------------------*/
#define IEC_MB_ADJ_GRID_CODE_START_ADDR                0x8101  // 安规参数 开始地址
#define IEC_MB_ADJ_GRID_CODE_END_ADDR                  0x8400  // 安规参数 结束地址
#define IEC_MB_ADJ_GRID_CODE_VAILD_LEN                 (64*9)  // 安规参数 有效长度

#define IEC_MB_ADJ_PARA_SYS_START_ADDR                  0x8701  // 系统参数 开始地址
#define IEC_MB_ADJ_PARA_SYS_END_ADDR                    0x8740  // 系统参数 结束地址
#define IEC_MB_ADJ_PARA_SYS_VAILD_LEN                   44      // 系统参数 有效长度

#define IEC_MB_ADJ_PARA_DYNAMIC_ENV_START_ADDR          0x8741  // 电池参数+动环系统参数
#define IEC_MB_ADJ_PARA_DYNAMIC_ENV_END_ADDR            0x8800  // 电池参数+动环系统参数
#define IEC_MB_ADJ_PARA_DYNAMIC_ENV_VAILD_LEN           112     // 电池参数+动环系统参数 有效长度

#define IEC_MB_ADJ_BAT_THRESHOLD_START_ADDR             0x8801  // 电池参数阈值参数 开始地址
#define IEC_MB_ADJ_BAT_THRESHOLD_END_ADDR               0x8900  // 电池参数阈值参数 结束地址
#define IEC_MB_ADJ_BAT_THRESHOLD_VAILD_LEN              76      // 电池参数阈值参数 有效长度

#define IEC_MB_ADJ_PCS_PARA_START_ADDR                  0x8901  // PCS模块参数设置 开始地址
#define IEC_MB_ADJ_PCS_PARA_END_ADDR                    0x8940  // PCS模块参数设置 结束地址
#define IEC_MB_ADJ_PCS_PARA_VAILD_LEN                   8       // PCS模块参数设置 有效长度

/*------------------------------------------ 遥测 -----------------------------------------*/
/*----------------- 储能柜 -----------------*/
#define IEC_MB_TELEMETRY_ES_CAB_BASE_INFO_START_ADDR     0x4301  // 储能柜基本信息 开始地址
#define IEC_MB_TELEMETRY_ES_CAB_BASE_INFO_END_ADDR       0x431D  // 储能柜基本信息 结束地址
#define IEC_MB_TELEMETRY_ES_CAB_BASE_INFO_VAILD_LEN      28      // 储能柜基本信息 有效长度

#define IEC_MB_TELEMETRY_ES_CAB_DATA_START_ADDR          0x431E  // 储能柜数据 开始地址
#define IEC_MB_TELEMETRY_ES_CAB_DATA_END_ADDR            0x4400  // 储能柜数据 结束地址
#define IEC_MB_TELEMETRY_ES_CAB_DATA_VAILD_LEN           76  // 储能柜数据 有效长度

/*----------------- 电池簇 -----------------*/
#define IEC_MB_TELEMETRY_BAT_CLU1_DATA_START_ADDR        0x4401  // 电池簇1数据 开始地址
#define IEC_MB_TELEMETRY_BAT_CLU1_DATA_END_ADDR          0x4E00  // 电池簇1数据 结束地址


#define IEC_MB_TELEMETRY_BAT_CLU2_DATA_START_ADDR        0xA401  // 电池簇2数据 开始地址
#define IEC_MB_TELEMETRY_BAT_CLU2_DATA_END_ADDR          0xAE00  // 电池簇2数据 结束地址
#define IEC_MB_TELEMETRY_BAT_CLU_DATA_VAILD_LEN          2372    // 电池簇数据 有效长度

/* 计算 电池簇2~6数据 起始地址和结束地址, bat_id = 2~6 */
#define IEC_MB_TELEMETRY_BAT_CLU_DATA_ADDR_INV                (0x1000)   // 电池簇数据地址间隔
#define IEC_MB_TELEMETRY_BAT_CLU2_6_DATA_START_ADDR(bat_id)   (IEC_MB_TELEMETRY_BAT_CLU2_DATA_START_ADDR + ((bat_id - 2) * 0x1000))    // 电池簇2~6数据 开始地址
#define IEC_MB_TELEMETRY_BAT_CLU2_6_DATA_END_ADDR(bat_id)     (IEC_MB_TELEMETRY_BAT_CLU2_DATA_END_ADDR + ((bat_id - 2) * 0x1000))      // 电池簇2~6数据 结束地址


/*----------------- PCS -----------------*/
#define IEC_MB_TELEMETRY_PCS_DATA_START_ADDR             0xEE01  // PCS数据 开始地址
#define IEC_MB_TELEMETRY_PCS_DATA_END_ADDR               0xEEB0  // PCS数据 结束地址
#define IEC_MB_TELEMETRY_PCS_DATA_VAILD_LEN              122     // PCS数据 有效长度

#define IEC_MB_TELEMETRY_PCS_BASE_INFO_START_ADDR        0xEEB1  // PCS基本信息 开始地址
#define IEC_MB_TELEMETRY_PCS_BASE_INFO_END_ADDR          0xEF00  // PCS基本信息 结束地址
#define IEC_MB_TELEMETRY_PCS_BASE_INFO_VAILD_LEN         61      // PCS基本信息 有效长度

#define IEC_MB_TELEMETRY_HEATBEAT_ADDR                   0xFFFF

/*------------------------------------------ 遥信 -----------------------------------------*/ 
/*----------------- 储能柜 -----------------*/
#define IEC_TELEMATIC_ES_CAB_SYS_FAULT_INFO_START_ADDR   0x0101  // 储能柜系统故障信息 开始地址
#define IEC_TELEMATIC_ES_CAB_SYS_FAULT_INFO_END_ADDR     0x0130  // 储能柜系统故障信息 结束地址
#define IEC_TELEMATIC_ES_CAB_SYS_FAULT_INFO_VAILD_LEN    19      // 储能柜系统故障信息 有效长度

#define IEC_TELEMATIC_ES_CAB_STA_INFO_START_ADDR         0x0131  // 储能柜状态信息 开始地址
#define IEC_TELEMATIC_ES_CAB_STA_INFO_END_ADDR           0x01A0  // 储能柜状态信息 结束地址
#define IEC_TELEMATIC_ES_CAB_STA_INFO_VAILD_LEN          110     // 储能柜状态信息 有效长度

#define IEC_TELEMATIC_ES_CAB_WARN_INFO_START_ADDR        0x01A1  // 储能柜告警信息 开始地址
#define IEC_TELEMATIC_ES_CAB_WARN_INFO_END_ADDR          0x0230  // 储能柜告警信息 结束地址
#define IEC_TELEMATIC_ES_CAB_WARN_INFO_VAILD_LEN         140     // 储能柜告警信息 有效长度

#define IEC_TELEMATIC_ES_CAB_FAULT_INFO_START_ADDR       0x0231  // 储能柜故障信息 开始地址
#define IEC_TELEMATIC_ES_CAB_FAULT_INFO_END_ADDR         0x02C0  // 储能柜故障信息 结束地址
#define IEC_TELEMATIC_ES_CAB_FAULT_INFO_VAILD_LEN        129     // 储能柜故障信息 有效长度

/*----------------- 电池簇 -----------------*/
#define IEC_TELEMATIC_BAT_CLU1_STA_INFO_START_ADDR       0x02C1  // 电池簇1状态信息 开始地址
#define IEC_TELEMATIC_BAT_CLU1_STA_INFO_END_ADDR         0x02E0  // 电池簇1状态信息 结束地址
#define IEC_TELEMATIC_BAT_CLU_STA_INFO_VAILD_LEN         16      // 电池簇状态信息 有效长度

#define IEC_TELEMATIC_BAT_CLU1_WARN_INFO_START_ADDR      0x02E1  // 电池簇1告警信息 开始地址
#define IEC_TELEMATIC_BAT_CLU1_WARN_INFO_END_ADDR        0x0370  // 电池簇1告警信息 结束地址
#define IEC_TELEMATIC_BAT_CLU_WARN_INFO_VAILD_LEN        74      // 电池簇1告警信息 有效长度

#define IEC_TELEMATIC_BAT_CLU1_FAULT_INFO_START_ADDR     0x0371  // 电池簇1故障信息 开始地址
#define IEC_TELEMATIC_BAT_CLU1_FAULT_INFO_END_ADDR       0x03C0  // 电池簇1故障信息 结束地址
#define IEC_TELEMATIC_BAT_CLU_FAULT_INFO_VAILD_LEN       40      // 电池簇1故障信息 有效长度

/* bat_idx = 1~6 */
#define IEC_TELEMATIC_BAT_CLU1_6_STA_INFO_START_ADDR(bat_idx)       (IEC_TELEMATIC_BAT_CLU1_STA_INFO_START_ADDR + (((bat_idx) - 1) * 0x100))      // 电池簇1-6状态信息 开始地址
#define IEC_TELEMATIC_BAT_CLU1_6_STA_INFO_END_ADDR(bat_idx)         (IEC_TELEMATIC_BAT_CLU1_STA_INFO_END_ADDR   + (((bat_idx) - 1) * 0x100))      // 电池簇1-6状态信息 结束地址

#define IEC_TELEMATIC_BAT_CLU1_6_WARN_INFO_START_ADDR(bat_idx)      (IEC_TELEMATIC_BAT_CLU1_WARN_INFO_START_ADDR + (((bat_idx) - 1) * 0x100))     // 电池簇1-6告警信息 开始地址
#define IEC_TELEMATIC_BAT_CLU1_6_WARN_INFO_END_ADDR(bat_idx)        (IEC_TELEMATIC_BAT_CLU1_WARN_INFO_END_ADDR   + (((bat_idx) - 1) * 0x100))     // 电池簇1-6告警信息 结束地址

#define IEC_TELEMATIC_BAT_CLU1_6_FAULT_INFO_START_ADDR(bat_idx)     (IEC_TELEMATIC_BAT_CLU1_FAULT_INFO_START_ADDR + (((bat_idx) - 1) * 0x100))    // 电池簇1-6故障信息 开始地址
#define IEC_TELEMATIC_BAT_CLU1_6_FAULT_INFO_END_ADDR(bat_idx)       (IEC_TELEMATIC_BAT_CLU1_FAULT_INFO_END_ADDR   + (((bat_idx) - 1) * 0x100))    // 电池簇1-6故障信息 结束地址

/*----------------- PCS -----------------*/
#define IEC_TELEMATIC_PCS_FAULT_INFO_START_ADDR          0x08C1  // PCS故障信息 开始地址
#define IEC_TELEMATIC_PCS_FAULT_INFO_END_ADDR            0x09C0  // PCS故障信息 结束地址
#define IEC_TELEMATIC_PCS_FAULT_INFO_VAILD_LEN           240     // PCS故障信息 有效长度

/*------------------------------------------ 遥控 -----------------------------------------*/ 
#define IEC_MB_TELCTRL_ES_CAB_START_ADDR           0x6011    // 储能柜遥控 开始地址
#define IEC_MB_TELCTRL_ES_CAB_END_ADDR             0x6020    // 储能柜遥控 结束地址
#define IEC_MB_TELCTRL_ES_CAB_VAILD_LEN            5         // 储能柜遥控 有效长度

#define IEC_MB_TELCTRL_BAT_CLU_START_ADDR           0x6021   // 电池簇系统遥控开始地址
#define IEC_MB_TELCTRL_BAT_CLU_END_ADDR             0x6070   // 电池簇系统遥控结束地址
#define IEC_MB_TELCTRL_BAT_CLU_VALID_LEN            59       // 电池簇系统遥控有效长度

#define IEC_MB_TELCTRL_PCS_START_ADDR               0x6071   // PCS模块参数 遥控开始地址
#define IEC_MB_TELCTRL_PCS_END_ADDR                 0x6080   // PCS模块参数 遥控结束地址
#define IEC_MB_TELCTRL_PCS_VALID_LEN                4        // PCS模块参数 遥控有效长度

typedef struct 
{
    uint16_t start_addr;  // 起始地址
    uint16_t end_addr;    // 结束地址
} cmu_iec_mb_addr_t;

#define CMU_IEC_MB_ADDR_LIST { \
                                {IEC_TELEMATIC_ES_CAB_SYS_FAULT_INFO_START_ADDR  , IEC_TELEMATIC_PCS_FAULT_INFO_END_ADDR        },     \
                                {IEC_MB_ADJ_GRID_CODE_START_ADDR                 , IEC_MB_ADJ_GRID_CODE_END_ADDR                },     \
                                {IEC_MB_ADJ_PARA_SYS_START_ADDR                  , IEC_MB_ADJ_PCS_PARA_END_ADDR                 },     \
                                {IEC_MB_TELCTRL_ES_CAB_START_ADDR                , IEC_MB_TELCTRL_PCS_END_ADDR                  },     \
                                {IEC_MB_TELEMETRY_ES_CAB_BASE_INFO_START_ADDR    , IEC_MB_TELEMETRY_BAT_CLU1_DATA_END_ADDR      },     \
                                {IEC_MB_TELEMETRY_BAT_CLU2_6_DATA_START_ADDR(2)  , IEC_MB_TELEMETRY_BAT_CLU2_6_DATA_END_ADDR(6) },     \
                                {IEC_MB_TELEMETRY_PCS_DATA_START_ADDR            , IEC_MB_TELEMETRY_PCS_BASE_INFO_END_ADDR      },     \
                            }

#endif
