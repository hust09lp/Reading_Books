#include "data_map_proc.h"
#include "proto_addr.h"
#include "function_handle.h"
#include "process_battery_read.h"
#include "battery_fun_interface.h"
#include "low_power_task.h"
#include "param_record_task.h"
#include "sci_task.h"

#include "mem_utils.h"
#include "sdk_shm.h"

#include <pthread.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>

#if (0)
#define DATA_MAP_PROC_DEBUG(...) do { printf("[Debug]"); printf(__VA_ARGS__); } while(0)
#else
#define DATA_MAP_PROC_DEBUG(...) do {} while(0)
#endif

#define DATA_MAP_PROC_ERROR(...) do { printf("[Error]"); printf(__VA_ARGS__); } while(0)

static sf_ret_t data_map_get_telematic_es_cab_sys_fault( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value );
static sf_ret_t data_map_get_telematic_es_cab_sta_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value );
static sf_ret_t data_map_get_telematic_es_cab_warn_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value );
static sf_ret_t data_map_get_telematic_es_cab_fault_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value );
static sf_ret_t data_map_get_telematic_pcs_fault_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value );
static sf_ret_t data_map_get_telematic_bat_cluster_sta_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value );
static sf_ret_t data_map_get_telematic_bat_cluster_warn_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value );
static sf_ret_t data_map_get_telematic_bat_cluster_fault_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value );
static sf_ret_t data_map_get_telematic_bat_cluster_fault_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value );

static sf_ret_t data_map_get_telemetry_hearbeat_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value );
static sf_ret_t data_map_get_telemetry_es_cab_base_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value );
static sf_ret_t data_map_get_telemetry_es_cab_data_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value );
static sf_ret_t data_map_get_telemetry_es_bat_cluster1_data_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value );
static sf_ret_t data_map_get_telemetry_es_bat_cluster2_6_data_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value );
static sf_ret_t data_map_get_telemetry_pcs_data_data_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value );
static sf_ret_t data_map_get_telemetry_pcs_base_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value );

static sf_ret_t data_map_get_tel_adjust_grid_code_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value );
static sf_ret_t data_map_set_tel_adjust_grid_code_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value, uint16_t val_len );
static sf_ret_t data_map_get_tel_adjust_sys_para( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value );
static sf_ret_t data_map_set_tel_adjust_sys_para( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value, uint16_t val_len );
static sf_ret_t data_map_get_tel_adjust_para_dynamic_env( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value );
static sf_ret_t data_map_set_tel_adjust_para_dynamic_env( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value, uint16_t val_len );
static sf_ret_t data_map_get_tel_adjust_bat_threshold( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value );
static sf_ret_t data_map_set_tel_adjust_bat_threshold( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value, uint16_t val_len );
static sf_ret_t data_map_get_tel_adjust_pcs_para( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value );
static sf_ret_t data_map_set_tel_adjust_pcs_para( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value, uint16_t val_len );

static sf_ret_t data_map_set_tel_ctrl_es_cab( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value, uint16_t val_len );

static void *data_map_task_thread( void *arg );

typedef sf_ret_t (*data_map_get_cb)( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value );
typedef sf_ret_t (*data_map_set_cb)( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value, uint16_t val_len );

typedef struct data_map
{
    struct 
    {
        uint16_t base_addr;              /* 基地址 */
        uint16_t valid_addr_len;         /* 有效地址长度 */
        data_map_get_cb dp_get_cb;     /* 获取数据点位回调函数 */
        data_map_set_cb dp_set_cb;     /* 设置数据点位回调函数 */
    } element;
    
    /**
     * 例如：  element.base_addr = 0x3000
     * 
     *         elem_array.is_array = true
     *         elem_array.element_max_num = 6
     *         elem_array.element_addr_inv = 0x1000
     * 则表示:
     *       element[0].base_addr = 0x3000
     *       element[1].base_addr = (0x3000 + (0x1000 * 1) ) = 0x4000
     *       element[2].base_addr = (0x3000 + (0x1000 * 2) ) = 0x5000
     *       ...
     *       element[n].base_addr = (0x3000 + (0x1000 * n) ) = 0x5000
     * 内部结构一致，只是地址不同
     */
    struct {
        bool     is_array;          // 是否为数组，默认为 fasle
        uint16_t element_max_num;   // 元素最大个数
        uint16_t element_addr_inv;  // 元素之间的地址间隔
    } elem_array;
} data_map_t;

data_map_t s_telematic_dps[] = 
{
    { 
        .element = {
            IEC_TELEMATIC_ES_CAB_SYS_FAULT_INFO_START_ADDR,
            IEC_TELEMATIC_ES_CAB_SYS_FAULT_INFO_VAILD_LEN, 
            data_map_get_telematic_es_cab_sys_fault,
            NULL,
        }
    },
    { 
        .element = {
            IEC_TELEMATIC_ES_CAB_STA_INFO_START_ADDR,
            IEC_TELEMATIC_ES_CAB_STA_INFO_VAILD_LEN, 
            data_map_get_telematic_es_cab_sta_info,
            NULL,
        }
    },
    { 
        .element = {
            IEC_TELEMATIC_ES_CAB_WARN_INFO_START_ADDR,
            IEC_TELEMATIC_ES_CAB_WARN_INFO_VAILD_LEN, 
            data_map_get_telematic_es_cab_warn_info,
            NULL,
        }
    },
    { 
        .element = {
            IEC_TELEMATIC_ES_CAB_FAULT_INFO_START_ADDR,
            IEC_TELEMATIC_ES_CAB_FAULT_INFO_VAILD_LEN, 
            data_map_get_telematic_es_cab_fault_info,
            NULL,
        }
    },
    { 
        .element = {
            IEC_TELEMATIC_PCS_FAULT_INFO_START_ADDR,
            IEC_TELEMATIC_PCS_FAULT_INFO_VAILD_LEN, 
            data_map_get_telematic_pcs_fault_info,
            NULL,
        }
    },
    { 
        .element = {
            IEC_TELEMATIC_BAT_CLU1_6_STA_INFO_START_ADDR(1),
            IEC_TELEMATIC_BAT_CLU_STA_INFO_VAILD_LEN, 
            data_map_get_telematic_bat_cluster_sta_info,
            NULL,
        },
        .elem_array = { .is_array = true, .element_max_num = 6, .element_addr_inv = 0x100 }
    },
    { 
        .element = {
            IEC_TELEMATIC_BAT_CLU1_6_WARN_INFO_START_ADDR(1),
            IEC_TELEMATIC_BAT_CLU_WARN_INFO_VAILD_LEN, 
            data_map_get_telematic_bat_cluster_warn_info,
            NULL,
        },
        .elem_array = { .is_array = true, .element_max_num = 6, .element_addr_inv = 0x100 }
    },
    { 
        .element = {
            IEC_TELEMATIC_BAT_CLU1_6_FAULT_INFO_START_ADDR(1),
            IEC_TELEMATIC_BAT_CLU_FAULT_INFO_VAILD_LEN, 
            data_map_get_telematic_bat_cluster_fault_info,
            NULL,
        },
        .elem_array = { .is_array = true, .element_max_num = 6, .element_addr_inv = 0x100 }
    },
};
data_map_t s_tmp_mb_telematic_dps[ sizeof(s_telematic_dps) ];

data_map_t s_telemetry_dps[] = 
{
    { 
        .element = {
            IEC_MB_TELEMETRY_ES_CAB_BASE_INFO_START_ADDR,
            IEC_MB_TELEMETRY_ES_CAB_BASE_INFO_VAILD_LEN,
            data_map_get_telemetry_es_cab_base_info,
            NULL,
        }
    },
    { 
        .element = {
            IEC_MB_TELEMETRY_ES_CAB_DATA_START_ADDR,
            IEC_MB_TELEMETRY_ES_CAB_DATA_VAILD_LEN,
            data_map_get_telemetry_es_cab_data_info,
            NULL,
        },
    },
    { 
        .element = {
            IEC_MB_TELEMETRY_BAT_CLU1_DATA_START_ADDR,
            IEC_MB_TELEMETRY_BAT_CLU_DATA_VAILD_LEN,
            data_map_get_telemetry_es_bat_cluster1_data_info,
            NULL,
        },
    },
    { 
        .element = {
            IEC_MB_TELEMETRY_BAT_CLU2_6_DATA_START_ADDR(2),
            IEC_MB_TELEMETRY_BAT_CLU_DATA_VAILD_LEN,
            data_map_get_telemetry_es_bat_cluster2_6_data_info,
            NULL,
        },
        .elem_array = { .is_array = true, .element_max_num = 5, .element_addr_inv = IEC_MB_TELEMETRY_BAT_CLU_DATA_ADDR_INV }
    },
    { 
        .element = {
            IEC_MB_TELEMETRY_PCS_DATA_START_ADDR,
            IEC_MB_TELEMETRY_PCS_DATA_VAILD_LEN,
            data_map_get_telemetry_pcs_data_data_info,
            NULL,
        },
    },
    { 
        .element = {
            IEC_MB_TELEMETRY_PCS_BASE_INFO_START_ADDR,
            IEC_MB_TELEMETRY_PCS_BASE_INFO_VAILD_LEN,   
            data_map_get_telemetry_pcs_base_info,
            NULL,
        },
    },
    { 
        .element = {
            IEC_MB_TELEMETRY_HEATBEAT_ADDR,
            1,
            data_map_get_telemetry_hearbeat_info,
            NULL,
        },
    }
};

data_map_t s_tel_adjust_dps[] = 
{
    {   
        .element = {
            IEC_MB_ADJ_GRID_CODE_START_ADDR, 
            IEC_MB_ADJ_GRID_CODE_VAILD_LEN, 
            data_map_get_tel_adjust_grid_code_info,
            data_map_set_tel_adjust_grid_code_info
        }
    },
    {
        .element = {
            IEC_MB_ADJ_PARA_SYS_START_ADDR,
            IEC_MB_ADJ_PARA_SYS_VAILD_LEN,
            data_map_get_tel_adjust_sys_para,
            data_map_set_tel_adjust_sys_para
        }
    },
    {
        .element = {
            IEC_MB_ADJ_PARA_DYNAMIC_ENV_START_ADDR,
            IEC_MB_ADJ_PARA_DYNAMIC_ENV_VAILD_LEN,
            data_map_get_tel_adjust_para_dynamic_env,
            data_map_set_tel_adjust_para_dynamic_env
        }
    },
    {
        .element = {
            IEC_MB_ADJ_BAT_THRESHOLD_START_ADDR,
            IEC_MB_ADJ_BAT_THRESHOLD_VAILD_LEN,
            data_map_get_tel_adjust_bat_threshold,
            data_map_set_tel_adjust_bat_threshold
        }
    }, 
    {
        .element = {
            IEC_MB_ADJ_PCS_PARA_START_ADDR,
            IEC_MB_ADJ_PCS_PARA_VAILD_LEN,
            data_map_get_tel_adjust_pcs_para,
            data_map_set_tel_adjust_pcs_para
        }
    }
};

data_map_t s_tel_ctrl_dps[] = 
{
    { 
        .element = {
            IEC_MB_TELCTRL_ES_CAB_START_ADDR,
            IEC_MB_TELCTRL_ES_CAB_VAILD_LEN,
            NULL,
            data_map_set_tel_ctrl_es_cab
        }
    },
};

typedef enum 
{
    IN_STA_NONE,        // 
    IN_STA_HALF,        // 
    IN_STA_FULL,        // 
} in_sta_e;

typedef struct 
{
    in_sta_e sta;
    uint16_t ele_array_idx;
} in_sta_t;

typedef enum
{
    REG_TYPE_TELEMATIC,
    REG_TYPE_TELEMETRY,
    REG_TYPE_TEL_ADJUST,
    REG_TYPE_TEL_CTRL,
    REG_TYPE_NO_EXSITE,
} reg_type_e;

typedef struct 
{
    reg_type_e   type;
    uint16_t     array_idx;
    data_map_t   *p_dps;
} reg_addr_info_t;

typedef struct 
{
    enum {
        ASYNC_STA_NONE = 0,
        ASYNC_STA_UPDATING,
        ASYNC_STA_READY,
    } async_sta;

    bool dev_param_save_flag;
    bool app_param_save_flag;
    bool set_lc_hot_manage_setting;
    bool set_fire_fighting_setting;
    bool set_dehumi_setting;
    bool set_lc_setting;
    uint32_t bat_flag;
} async_event_t;

struct 
{
    async_event_t    async_event;  
    telematic_data_t *p_telematic_data;
    telemetry_data_t *p_telemetry_data;
} s_dm_proc_info;

sf_ret_t data_map_proc_init( void )
{
    memset( &s_dm_proc_info, 0, sizeof(s_dm_proc_info) );
    memcpy( &s_tmp_mb_telematic_dps, &s_telematic_dps, sizeof(s_telematic_dps) );
    for (size_t i = 0; i < ARRAY_SIZE( s_telematic_dps ); i++)
    {
        s_tmp_mb_telematic_dps[i].element.valid_addr_len  = (s_telematic_dps[i].element.valid_addr_len / 16) ;
        s_tmp_mb_telematic_dps[i].element.valid_addr_len += (s_telematic_dps[i].element.valid_addr_len % 16) ? 1 : 0 ;
    }

    s_dm_proc_info.p_telematic_data = &sdk_shm_get()->telematic_data;
    s_dm_proc_info.p_telemetry_data = &sdk_shm_get()->telemetry_data;

	pthread_t tcp_modbus;
	pthread_attr_t attr;

	pthread_attr_init( &attr );
	pthread_attr_setdetachstate( &attr, PTHREAD_CREATE_DETACHED);

	if ( pthread_create( &tcp_modbus, &attr, data_map_task_thread, NULL) != 0 )
	{
		printf ( "data_map_task_thread create falied\r\n");
	}
	pthread_attr_destroy(&attr);

    return SF_OK;
}

static void data_map_async_event_handle( void )
{
    if ( true == s_dm_proc_info.async_event.dev_param_save_flag)
    {
        s_dm_proc_info.async_event.dev_param_save_flag = false;
        dev_param_save();
        dev_param_save();
    }

    if ( true == s_dm_proc_info.async_event.app_param_save_flag)
    {
        s_dm_proc_info.async_event.app_param_save_flag = false;
        app_param_save();
        app_param_save();
    }

    if ( true == s_dm_proc_info.async_event.set_lc_setting)
    {
        s_dm_proc_info.async_event.set_lc_setting = false;
        set_constant_data( FUNCID_SET_PARA_SYSTEM_LC );
    }

    if ( true == s_dm_proc_info.async_event.set_lc_hot_manage_setting)
    {
        s_dm_proc_info.async_event.set_lc_hot_manage_setting = false;
        set_constant_data( FUNCID_SET_PARA_LOGIC_LC );
    }

    if ( true == s_dm_proc_info.async_event.set_fire_fighting_setting)
    {
        s_dm_proc_info.async_event.set_fire_fighting_setting = false;
        set_constant_data(FUNCID_SET_PARA_FIRE);
    }

    if ( true == s_dm_proc_info.async_event.set_dehumi_setting)
    {
        s_dm_proc_info.async_event.set_dehumi_setting = false;
        set_constant_data( FUNCID_SET_PARA_DRY );
    }
}

static void *data_map_task_thread( void *arg )
{
    while (1)
    {
        data_map_async_event_handle();
        usleep( 100 * 1000 );
    }
    pthread_exit( NULL );
}

static in_sta_t _reg_addr_in_data_map ( uint16_t reg_addr, uint16_t reg_cnt, data_map_t *p_dat_map )
{
    uint16_t start_addr;
    uint32_t valid_end_addr;
    in_sta_t ret = { .sta = IN_STA_NONE, .ele_array_idx = 0 };

    if ( p_dat_map->elem_array.is_array == SF_FALSE )
    {
        start_addr     = p_dat_map->element.base_addr;
        valid_end_addr = start_addr + p_dat_map->element.valid_addr_len;

        if ( reg_addr >= start_addr && reg_addr <= valid_end_addr )
        {
            if ( (reg_addr + reg_cnt) > valid_end_addr )
            {
                ret.sta = IN_STA_HALF;
                return ret;
            }
            ret.sta = IN_STA_FULL;
            return ret;
        }
    }
    else
    {
        for (size_t i = 0; i < p_dat_map->elem_array.element_max_num; i++)
        {
            start_addr     = p_dat_map->element.base_addr + (i * p_dat_map->elem_array.element_addr_inv);
            valid_end_addr = start_addr + p_dat_map->element.valid_addr_len;
            
            if ( reg_addr >= start_addr && reg_addr <= valid_end_addr )
            {
                ret.ele_array_idx = i;
                if ( (reg_addr + reg_cnt) > valid_end_addr )
                {
                    ret.sta = IN_STA_HALF;
                    return ret;
                }
                ret.sta = IN_STA_FULL;
                return ret;
            }
        }
    }
    return ret;
}

/**
 * @brief   寄存器地址在表结构中的定位
 * @param reg_addr : 寄存器地址
 * @param reg_cnt  : 寄存器数量
 * @note
 * @return 
 */
reg_addr_info_t data_map_modbus_addr_get_info ( uint16_t reg_addr, uint16_t reg_cnt )
{
    uint16_t start_addr, valid_end_addr;
    reg_addr_info_t ret = { .type = REG_TYPE_NO_EXSITE, .p_dps = NULL, .array_idx = 0 };
    in_sta_t in_sta = { .sta = IN_STA_NONE, .ele_array_idx = 0 };

    for ( size_t i = 0; i < ARRAY_SIZE( s_tmp_mb_telematic_dps ) ; i++ )
    {
        in_sta = _reg_addr_in_data_map( reg_addr, reg_cnt, &s_tmp_mb_telematic_dps[i] );
        if ( in_sta.sta == IN_STA_FULL )
        {
            ret.array_idx = in_sta.ele_array_idx;
            ret.type  = REG_TYPE_TELEMATIC;
            ret.p_dps = &s_tmp_mb_telematic_dps[i];
            return ret;
        }else if ( in_sta.sta == IN_STA_HALF )
        {
            return ret;
        }
    }

    for ( size_t i = 0; i < ARRAY_SIZE( s_telemetry_dps ) ; i++ )
    {
        in_sta = _reg_addr_in_data_map( reg_addr, reg_cnt, &s_telemetry_dps[i] );
        if ( in_sta.sta == IN_STA_FULL )
        {
            ret.array_idx = in_sta.ele_array_idx;
            ret.type  = REG_TYPE_TELEMETRY;
            ret.p_dps = &s_telemetry_dps[i];
            return ret;
        }else if ( in_sta.sta == IN_STA_HALF )
        {
            return ret;
        }
    }

    for ( size_t i = 0; i < ARRAY_SIZE( s_tel_adjust_dps ) ; i++ )
    {
        in_sta = _reg_addr_in_data_map( reg_addr, reg_cnt, &s_tel_adjust_dps[i] );
        if ( in_sta.sta == IN_STA_FULL )
        {
            ret.array_idx = in_sta.ele_array_idx;
            ret.type  = REG_TYPE_TEL_ADJUST;
            ret.p_dps = &s_tel_adjust_dps[i];
            return ret;
        }else if ( in_sta.sta == IN_STA_HALF )
        {
            return ret;
        }
    }
    
    for ( size_t i = 0; i < ARRAY_SIZE( s_tel_ctrl_dps ) ; i++ )
    {
        in_sta = _reg_addr_in_data_map( reg_addr, reg_cnt, &s_tel_ctrl_dps[i] );
        if ( in_sta.sta == IN_STA_FULL )
        {
            ret.array_idx = in_sta.ele_array_idx;
            ret.type  = REG_TYPE_TEL_CTRL;
            ret.p_dps = &s_tel_ctrl_dps[i];
            return ret;
        }else if ( in_sta.sta == IN_STA_HALF )
        {
            return ret;
        }
    }

    return ret;
}


sf_ret_t data_map_modbus_read_register( uint16_t reg_addr, uint16_t reg_cnt, uint16_t *p_rd_vals )
{
    reg_addr_info_t reg_addr_info = data_map_modbus_addr_get_info( reg_addr, reg_cnt );
    
    DATA_MAP_PROC_DEBUG("data_map_modbus_read_register, %04X, %d, reg_addr_info.type:%s\r\n", reg_addr, reg_cnt, 
                                            (reg_addr_info.type == REG_TYPE_TELEMATIC  ) ? "REG_TYPE_TELEMATIC"  : 
                                            (reg_addr_info.type == REG_TYPE_TELEMETRY  ) ? "REG_TYPE_TELEMETRY"  : 
                                            (reg_addr_info.type == REG_TYPE_TEL_ADJUST ) ? "REG_TYPE_TEL_ADJUST" :
                                            (reg_addr_info.type == REG_TYPE_TEL_CTRL   ) ? "REG_TYPE_TEL_CTRL"   : "REG_TYPE_NO_EXSITE" );
    if (   reg_addr_info.type  == REG_TYPE_NO_EXSITE
        || reg_addr_info.p_dps == NULL   )
    {
        return SF_ERR_NO_OBJECT;
    }

    data_map_get_cb dp_get_cb = reg_addr_info.p_dps->element.dp_get_cb;
    uint16_t base_addr  = reg_addr_info.p_dps->element.base_addr + ( reg_addr_info.array_idx * reg_addr_info.p_dps->elem_array.element_addr_inv );
    
    if ( dp_get_cb == NULL )
    {
        return SF_ERR_FNOSUPP;
    }
    if ( reg_addr_info.type == REG_TYPE_TELEMATIC )
    {
        for ( size_t i = 0; i < ( reg_cnt * 16 ); i++ )
        {
            uint16_t val = 0;

            dp_get_cb( reg_addr_info.array_idx, (reg_addr - base_addr) * 16 + i , &val );
            if ( val == 0 )
            {
                p_rd_vals[i / 16] &= ~BIT( i%16 );
            }else{
                p_rd_vals[i / 16] |= BIT( i%16 );
            }
        }
    }else{
        for ( size_t i = 0; i < reg_cnt ; i++ )
        {
            dp_get_cb( reg_addr_info.array_idx, (reg_addr + i) - base_addr , &p_rd_vals[i] );
        }
    }
    return SF_OK;
}

sf_ret_t data_map_modbus_write_register( uint16_t reg_addr, uint16_t reg_cnt, uint16_t *p_wr_vals )
{
    reg_addr_info_t reg_addr_info = data_map_modbus_addr_get_info( reg_addr, reg_cnt );
    if (   reg_addr_info.type == REG_TYPE_NO_EXSITE
        || reg_addr_info.p_dps == NULL )
    {
        return SF_ERR_NO_OBJECT;
    }

    data_map_set_cb dp_set_cb = reg_addr_info.p_dps->element.dp_set_cb;
    uint16_t base_addr  = reg_addr_info.p_dps->element.base_addr + ( reg_addr_info.array_idx * reg_addr_info.p_dps->elem_array.element_addr_inv );

    if ( dp_set_cb == NULL )
    {
        return SF_ERR_FNOSUPP;
    }

    dp_set_cb( reg_addr_info.array_idx, reg_addr - base_addr, p_wr_vals, reg_cnt );
    
    return SF_OK;
}

static sf_ret_t data_map_get_telematic_es_cab_sys_fault( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value )
{
    *p_value = mem_utils_get_bit_val( s_dm_proc_info.p_telematic_data->CMU_system_fault_info, addr_offset );
    return SF_OK;
}

static sf_ret_t data_map_get_telematic_es_cab_sta_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value )
{
    *p_value = mem_utils_get_bit_val( s_dm_proc_info.p_telematic_data->container_system_status_info, addr_offset );
    return SF_OK;
}

static sf_ret_t data_map_get_telematic_es_cab_warn_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value )
{
    *p_value = mem_utils_get_bit_val( s_dm_proc_info.p_telematic_data->container_system_warn_info, addr_offset );
    return SF_OK;
}

static sf_ret_t data_map_get_telematic_es_cab_fault_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value )
{
    *p_value = mem_utils_get_bit_val( s_dm_proc_info.p_telematic_data->container_system_fault_info, addr_offset );
    return SF_OK;
}

static sf_ret_t data_map_get_telematic_pcs_fault_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value )
{
    *p_value = mem_utils_get_bit_val( (uint8_t*)&s_dm_proc_info.p_telematic_data->pcs_module[0], addr_offset );
    return SF_OK;
}

static sf_ret_t data_map_get_telematic_bat_cluster_sta_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value )
{
    *p_value = mem_utils_get_bit_val( s_dm_proc_info.p_telematic_data->battery_cluster_telematic_info[array_idx].battery_cluster_status_info, addr_offset );
    return SF_OK;
}

static sf_ret_t data_map_get_telematic_bat_cluster_warn_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value )
{
    *p_value = mem_utils_get_bit_val( s_dm_proc_info.p_telematic_data->battery_cluster_telematic_info[array_idx].battery_cluster_warn_info, addr_offset );
    return SF_OK;
}

static sf_ret_t data_map_get_telematic_bat_cluster_fault_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value )
{
    *p_value = mem_utils_get_bit_val( s_dm_proc_info.p_telematic_data->battery_cluster_telematic_info[array_idx].battery_cluster_fault_info, addr_offset );
    return SF_OK;
}


static sf_ret_t data_map_get_telemetry_hearbeat_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value )
{
    *p_value = 0xAABB;
    return SF_OK;
}

static sf_ret_t data_map_get_telemetry_es_cab_base_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value )
{
    internal_version_info_t *p_ver = internal_version_info_get();
    uint16_t seq_id = addr_offset + 1;

    if  ( seq_id == 1 )               
    {
        /* CMU储能柜硬件版本号 */
        *p_value = (p_ver->mcu1_hardware_version[1] << 8) | p_ver->mcu1_hardware_version[0];

    }else if  ( seq_id == 2 )               
    {
        /* MCU1软件版本号低16位 */
        *p_value = (p_ver->mcu1_app_soft_version[1] << 8) | p_ver->mcu1_app_soft_version[0];

    }else if  ( seq_id == 3 )               
    {
        /* MCU1软件版本号高16位 */
        *p_value = (p_ver->mcu1_app_soft_version[3] << 8) | p_ver->mcu1_app_soft_version[2];

    }else if  ( seq_id == 4 )               
    {
        /* MCU1BOOT版本号低16位 */
        *p_value = 0x156;

    }else if  ( seq_id == 5 )               
    {
        /* MCU1BOOT版本号高16位 */
        *p_value = 257;

    }else if  ( seq_id == 6 )               
    {
        /* MCU1CORE版本号低16位 */
        *p_value = (p_ver->mcu1_core_soft_version[1] << 8) | p_ver->mcu1_core_soft_version[0];

    }else if  ( seq_id == 7 )               
    {
        /* MCU1CORE版本号高16位 */
        *p_value = (p_ver->mcu1_core_soft_version[3] << 8) | p_ver->mcu1_core_soft_version[2];

    }else if  ( seq_id == 8 )               
    {
        /* MCU2软件版本号低16位 */
        *p_value = (p_ver->mcu2_app_soft_version[1] << 8) | p_ver->mcu2_app_soft_version[0];

    }else if  ( seq_id == 9 )               
    {
        /* MCU2软件版本号高16位 */
        *p_value = (p_ver->mcu2_app_soft_version[3] << 8) | p_ver->mcu2_app_soft_version[2];

    }else if  ( seq_id == 10 )              
    {
        /* MCU2BOOT版本号低16位 */
        *p_value = 0;

    }else if  ( seq_id == 11 )              
    {
        /* MCU2BOOT版本号高16位 */
        *p_value = 0;

    }else if  ( seq_id == 12 )              
    {
        /* MCU2CORE版本号低16位 */
        *p_value = (p_ver->mcu2_core_soft_version[1] << 8) | p_ver->mcu2_core_soft_version[0];

    }else if  ( seq_id == 13 )              
    {
        /* MCU2CORE版本号高16位 */
        *p_value = (p_ver->mcu2_core_soft_version[3] << 8) | p_ver->mcu2_core_soft_version[2];

    }else if  ( seq_id == 14 )              
    {
        /* 通信协议版本号 */
        *p_value = SCI_VERTION1;

    }else if  ( seq_id == 15 )              
    {
        /* 系统状态 */
        *p_value = sdk_shm_telemetry_data_get()->cmu_telemetry_info.cmu_sys_state;

    }else if  ( seq_id == 16 )              
    {
        /* 消防控制器软件版本号 */
        *p_value = (p_ver->ff_software_version[1] << 8) | p_ver->ff_software_version[0];
        
    }else if  ( (seq_id >= 17) && (seq_id <= 28) )
    {
        /* 储能柜SN, sn需要做大小端转化 */
        uint16_t *p_u16 = (uint16_t *)p_ver->dev_sn;
        *p_value = htons( p_u16[seq_id - 17] );
    }else {
        *p_value = 0;
    }

    return SF_OK;
}

static sf_ret_t data_map_get_telemetry_es_cab_data_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value )
{
    uint16_t *p_u16 = (uint16_t*)&s_dm_proc_info.p_telemetry_data->container_system_telemetry_info;
    *p_value = p_u16[addr_offset];
    return SF_OK;
}

static sf_ret_t data_map_get_telemetry_es_bat_cluster1_data_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value )
{
    uint16_t *p_u16 = (uint16_t*)&s_dm_proc_info.p_telemetry_data->battery_cluster_telemetry_info[0];
    *p_value = p_u16[addr_offset];
    return SF_OK;
}

static sf_ret_t data_map_get_telemetry_es_bat_cluster2_6_data_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value )
{    
    uint16_t *p_u16 = (uint16_t*)&s_dm_proc_info.p_telemetry_data->battery_cluster_telemetry_info[ 1 + array_idx];
    *p_value = p_u16[addr_offset];
    return SF_OK;
}

static sf_ret_t data_map_get_telemetry_pcs_data_data_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value )
{
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();
    uint16_t seq_id = addr_offset + 1;
    uint16_t *p_u16 = NULL;

    if ( seq_id >= 1 && seq_id <= 26 )      /* PCS功率模块数据,从电网线电压RS~T相视在功率 */
    {
        p_u16 = (uint16_t *)(&(p_telemetry_data->power_module_telemetry_info[0].grid_volt_rs));
        *p_value = p_u16[seq_id - 1];
    }
    else if ( seq_id >= 51 && seq_id <= 79 )  /* PCS功率模块数据,从电网相电压R~模块累计充电量高16位 */
    {
        p_u16 = (uint16_t *)(&(p_telemetry_data->power_module_telemetry_info[0].grid_volt_r));
        *p_value = p_u16[seq_id - 51];
    }
    else if ( seq_id >= 101 && seq_id <= 103 )  /* PCS功率模块数据,电池电流~Iso对地电压 */
    {
        p_u16 = (uint16_t *)(&(p_telemetry_data->power_module_telemetry_info[0].bat_current));
        *p_value = p_u16[seq_id - 101];
    }
    else if ( seq_id >= 114 && seq_id <= 122 )  /* PCS功率模块数据, 启动参数校验和 ~ ISO孤岛参数校验和 */
    {
        p_u16 = (uint16_t *)(&(p_telemetry_data->power_module_telemetry_info[0].startup_para_checksum));
        *p_value = p_u16[seq_id - 101];
    }else{
        *p_value = 0;
    }
    return SF_OK;
}

static sf_ret_t data_map_get_telemetry_pcs_base_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value )
{
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();
    uint16_t seq_id = addr_offset + 1;

    if ( seq_id >= 1 && seq_id <= 10 )     /* SN序列号 */
    {
        uint16_t *p_u16 = (uint16_t *)p_telemetry_data->pcs_module_version_telemetry_info[0].sn;
        *p_value = htons( p_u16[ seq_id - 1] );
    }
    else if ( seq_id >= 11 && seq_id <= 20 )     /* 主DSP软件版本号 ~ PCS模块最大无功功率 */
    {
        uint16_t *p_u16 = (uint16_t *)&p_telemetry_data->pcs_module_version_telemetry_info[0].fw_version[0];
        *p_value = p_u16[ seq_id - 11 ];
    }
    else if ( seq_id >= 51 && seq_id <= 59 )     /* 从DSP软件版本号 ~ PCS模块CAN协议版本号大版本 */
    {
        uint16_t *p_u16 = (uint16_t *)&p_telemetry_data->pcs_module_version_telemetry_info[0].slv_fw_version[0];
        *p_value = p_u16[ seq_id - 51 ];
    }else{
        *p_value = 0;
    }

    return SF_OK;
}

static sf_ret_t data_map_get_tel_adjust_grid_code_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value )
{
    uint16_t *p_u16 = (uint16_t*)&sdk_shm_constant_parameter_data_get()->safety_param.group_list[0][0];
    *p_value = p_u16[addr_offset];
    return SF_OK;
}

static sf_ret_t data_map_set_tel_adjust_grid_code_info( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value, uint16_t val_len )
{
    for (size_t i = 0; i < val_len; i++)
    {
        iec104_safety_pre_set( IEC_MB_ADJ_GRID_CODE_START_ADDR + addr_offset + i, p_value[i] );
    }
    iec104_safety_start_sync();

    return SF_OK;
}

static sf_ret_t data_map_get_tel_adjust_sys_para( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value )
{
    uint16_t seq_id = addr_offset + 1;
    uint16_t *p_u16 = NULL;

    if ( seq_id >= 7 && seq_id <= 18 )               
    {
        /* sn需要做大小端转化 */
        p_u16 = (uint16_t *)sdk_shm_constant_parameter_data_get()->device_sn;
        *p_value = htons( p_u16[seq_id - 7] );
    }
    else
    {
        p_u16 = (uint16_t *)&sdk_shm_constant_parameter_data_get()->storage_duration_operation_data;
        *p_value = p_u16[addr_offset];
    }

    return SF_OK;
}

static sf_ret_t data_map_set_tel_adjust_sys_para( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value, uint16_t val_len )
{
    internal_shared_data_t *p_inter_param  = &sdk_shm_get()->internal_shared_data;
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get();
    web_control_info_t         *p_web_ctrl = shm_web_control_info_get();
    bool dev_param_save_flag = false;
    uint8_t setsn_flag = 0;

    for (size_t i = 0; i < val_len; i++ )
    {
        uint16_t seq_id = addr_offset + i + 1;
            
        dev_param_save_flag = true;
        if ( seq_id == 5 )
        {
            /* 安规地区标准 */  
            p_inter_param->import_safety_country_region = p_value[i];
            p_inter_param->safety_switch_flag = 1;   
        }
        else if ( seq_id == 6 )
        {
            /* 安规版本号 */     
            p_inter_param->import_safety_ver = p_value[i];
            p_inter_param->safety_switch_flag = 1;  
        }
        else if ( seq_id >= 7 && seq_id <= 18 )
        {
            uint16_t *p_data = (uint16_t*)p_para_data->device_sn; 
            p_data[ seq_id - 7 ] = htons(p_value[i]);
            setsn_flag = 1;
        }
        else if ( seq_id == 19 )
        {
            /* 空载转休眠时长设置 */    
            low_power_set_idle_to_sleep_mode_time( p_value[i] ); 
        }
        else if ( seq_id == 20 )
        {
            /* 休眠转停机时长设置 */     
            low_power_set_sleep_to_power_off_time( p_value[i] );
        }
        else if ( seq_id == 21 )
        {
            /* 休眠转停机使能 */     
            low_power_set_sleep_to_power_off_enable( p_value[i] );
        }
        else if ( seq_id == 22 )
        {
            /* 空载转休眠使能 */     
            low_power_set_idle_to_sleep_enable( p_value[i] );
        }
        else if ( seq_id == 23 )
        {
            /* 容测模式使能 */     
            p_para_data->battery_cap_test_flag = p_value[i];
            p_web_ctrl->battery_cap_test_set_flag = true;
        }
        else if ( seq_id == 43 )
        {
            /* 电池簇pack数量 */  
            p_para_data->bat_cluster_pack_num = p_value[i];
            p_web_ctrl->pack_num_set_flag = ENABLE;   
        }
        else if ( seq_id == 44 )
        {
            /* 外部EPO输入类型 */ 
            p_para_data->external_epo_input_type = p_value[i];
            p_web_ctrl->external_epo_type_set_flag = ENABLE;    
        }else {
            // case 1 :          /* 运行数据存储天数 */     
            // case 2 :          /* 运行数据存储频率 */     
            // case 3 :          /* 故障录波条数 */     
            // case 4 :          /* 电池簇编号 */  
            // case 7 :          /* 储能柜SN */         
            // case 24:         /* 预留 */         
            // case 32:         /* CMU模式设置 */     
            // case 33:         /* 有功功率 */     
            // case 34:         /* 无功功率 */     
            // case 35:         /* SOC充电上限 */     
            // case 36:         /* SOC放电下限 */     
            // case 37:         /* 电池柜个数 */     
            // case 38:         /* 储能柜监控板动环地址 */     
            // case 39:         /* 消防共享储能柜个数 */     
            // case 40:         /* EOL告警阈值 */     
            // case 41:         /* 数据IEC104上传间隔 */     
            // case 42:         /* 电池簇数据IEC104上传间隔 */     
            // default:
            /* 其他设置赋值即可起作用 */
            uint16_t *p_u16 = &p_para_data->storage_duration_operation_data;
            p_u16[ seq_id - 1 ] = p_value[i];
        }
    }
    s_dm_proc_info.async_event.dev_param_save_flag |= dev_param_save_flag;

    if(setsn_flag == 1)
    {
        p_web_ctrl->dev_sn_set_flag = ENABLE;
        setsn_flag = 0;
    }

    return SF_OK;
}

static sf_ret_t data_map_get_tel_adjust_para_dynamic_env( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value )
{
    uint16_t *p_u16 = (uint16_t *)&sdk_shm_constant_parameter_data_get()->cluster_curr_diff_warn_threshold_1;
    *p_value = p_u16[ addr_offset ];
    return SF_OK;
}

static sf_ret_t data_map_set_tel_adjust_para_dynamic_env( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value, uint16_t val_len )
{    
    // printf("data_map_set_tel_adjust_para_dynamic_env, array_idx:%d, addr_offset:%d, val_len:%d \r\n", array_idx, addr_offset, val_len );
    // mem_utils_print_u16_dat( "p_value:", p_value, val_len, 10, true );
    // return SF_OK;

    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get();
    bool app_param_save_flag = false;
    bool set_lc_hot_manage_setting = false;
    bool set_fire_fighting_setting = false;
    bool set_dehumi_setting = false;
    bool set_lc_setting = false;

    for (size_t i = 0; i < val_len; i++ )
    {
        uint16_t seq_id = addr_offset + i + 1;

        /* 点位与内存顺序排列 */
        uint16_t *p_u16 = (uint16_t*)&p_para_data->cluster_curr_diff_warn_threshold_1;
        p_u16[ addr_offset + i ] = p_value[i];

        app_param_save_flag = true;

        if (( seq_id >= 1 ) && ( seq_id <= 4 ))
        {
            /* 簇间电流差异报警阈值设置 */
        } 
        else if (( seq_id >= 5 ) && ( seq_id <= 17 ))
        {
            /* 储能柜-液冷系统 */
            set_lc_setting = true;
        }
        else if (( seq_id >= 18 ) && ( seq_id <= 87 ))
        {
            /* 热管理逻辑 */
            set_lc_hot_manage_setting = true;
        }
        else if (( seq_id >= 88 ) && ( seq_id <= 102 ))
        {
            /* 储能柜-消防 */
            set_fire_fighting_setting = true;
        } 
        else if (( seq_id >= 103 ) && ( seq_id <= 104 ))
        {
            /* 储能柜-除湿逻辑 */
            set_dehumi_setting = true;
        }
        else if ( seq_id == 105 )
        {
            /* MCU2消防备份功能使能 */
            set_fire_fighting_setting = true;
        }
        else if (( seq_id >= 106 ) && ( seq_id <= 112 ))
        {
            /* 热管理-保温模式 */
            set_lc_hot_manage_setting = true;
        }
    }

    s_dm_proc_info.async_event.app_param_save_flag       |= app_param_save_flag;
    s_dm_proc_info.async_event.set_lc_hot_manage_setting |= set_lc_hot_manage_setting;
    s_dm_proc_info.async_event.set_fire_fighting_setting |= set_fire_fighting_setting;
    s_dm_proc_info.async_event.set_dehumi_setting        |= set_dehumi_setting;
    s_dm_proc_info.async_event.set_lc_setting            |= set_lc_setting;

    return SF_OK;
}

static sf_ret_t data_map_get_tel_adjust_bat_threshold( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value )
{
    uint16_t *p_u16 = (uint16_t *)&sdk_shm_constant_parameter_data_get()->battery_parameter_data[0].ISO_warn_threshold_1;
    *p_value = p_u16[ addr_offset ];
    return SF_OK;
}

static sf_ret_t data_map_set_tel_adjust_bat_threshold( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value, uint16_t val_len )
{
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get();
    int16_t bat_set_ret = 0;
    uint32_t bat_flag = 0;
    
    for (size_t i = 0; i < val_len; i++ )
    {
        uint16_t seq_id = addr_offset + i + 1;
        
        for (size_t j = 0; j < ARRAY_SIZE( p_para_data->battery_parameter_data ); j++)
        {
            uint16_t *p_u16 = &(p_para_data->battery_parameter_data[0].ISO_warn_threshold_1);
            p_u16[ addr_offset + i ] = p_value[i];
        }
        
        /* 每4个参数为1组can设置 */
        uint16_t group_idx = addr_offset / 4;
        bat_flag |= BIT( group_idx );
    }

    for (size_t i = 0; i < 19; i++ )
    {
        if ( (bat_flag & BIT(i)) == 0 )
        {
            /* 没有设置，继续检索 */
            continue;
        }

        for (size_t j = 0; j < ARRAY_SIZE( p_para_data->battery_parameter_data ); j++)
        {
            switch (i)
            {
                case 0:
                    bat_set_ret |= battery_config_table_set(j, ISO_WARN_VALUE);
                    break;
                case 1:
                    bat_set_ret |= battery_config_table_set(j, CLUSTER_OVP_WARN_VALUE);
                    break;
                case 2:
                    bat_set_ret |= battery_config_table_set(j, CLUSTER_UVP_WARN_VALUE);
                    break;
                case 3:
                    bat_set_ret |= battery_config_table_set(j, PACK_OVP_WARN_VALUE);
                    break;
                case 4:
                    bat_set_ret |= battery_config_table_set(j, PACK_UVP_WARN_VALUE);
                    break;
                case 5:
                    bat_set_ret |= battery_config_table_set(j, CHARGE_OCP_WARN_VALUE);
                    break;
                case 6:
                    bat_set_ret |= battery_config_table_set(j, DISCHARGE_OCP_WARN_VALUE);
                    break;
                case 7:
                    bat_set_ret |= battery_config_table_set(j, CHARGE_MONOMER_TEMP_WARN_VALUE);
                    break;
                case 8:
                    bat_set_ret |= battery_config_table_set(j, CHARGE_MONOMER_TEMP_WARN_VALUE);
                    break;
                case 9:
                    bat_set_ret |= battery_config_table_set(j, DISCHARGE_MONOMER_TEMP_WARN_VALUE);
                    break;
                case 10:
                    bat_set_ret |= battery_config_table_set(j, DISCHARGE_MONOMER_TEMP_WARN_VALUE);
                    break;
                case 11:
                    bat_set_ret |= battery_config_table_set(j, MONOMER_TEMP_DIFF_WARN_VALUE);
                    break;
                case 12:
                    bat_set_ret |= battery_config_table_set(j, MONOMER_OVP_WARN_VALUE);
                    break;
                case 13:
                    bat_set_ret |= battery_config_table_set(j, MONOMER_UVP_WARN_VALUE);
                    break;
                case 14:
                    bat_set_ret |= battery_config_table_set(j, MONOMER_VOL_DIFF_WARN_VALUE);
                    break;
                case 15:
                    bat_set_ret |= battery_config_table_set(j, SOC_WARN_VALUE);
                    break;
                case 16:
                    bat_set_ret |= battery_config_table_set(j, SOC_WARN_VALUE);
                    break;
                case 17:
                    bat_set_ret |= battery_config_table_set(j, SOC_WARN_VALUE);
                    break;
                case 18:
                    bat_set_ret |= battery_config_table_set(j, MODULE_TEMP_WARN_VALUE);
                    break;
                default:
                    break;
            }
        }
    }
    if ( bat_set_ret == 0)
    {
        // 成功， 调用固化参数接口
        battery_param_save();
        battery_param_save();
    }
    else
    {
        // 失败，调用参数读取接口，更新共享内存数据
        battery_param_read();
        battery_param_read();         
    }

    return SF_OK;
}

static sf_ret_t data_map_get_tel_adjust_pcs_para( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value )
{
    uint16_t* p_u16 = (uint16_t *)(&(sdk_shm_constant_parameter_data_get()->iec_pcs_parameter_data[0].active_power_ref));
    *p_value = p_u16[ addr_offset ];
    return SF_OK;
}

static sf_ret_t data_map_set_tel_adjust_pcs_para( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value, uint16_t val_len )
{
    web_control_info_t *p_web_ctrl = shm_web_control_info_get();

    for (size_t i = 0; i < val_len; i++ )
    {
        uint16_t seq_id = addr_offset + i + 1;
        switch (seq_id)
        {
            case 7:
                p_web_ctrl->pcs_powerup_gradident_set_flag = 1;
                p_web_ctrl->pcs_powerup_gradident_setvalue = p_value[i];
                break;
            case 8:
                p_web_ctrl->pcs_factory_mode_set_flag |= 0x01;
                p_web_ctrl->pcs_factory_mode_set_value = p_value[i];
                break;
            default:
                break;
        }
    }
    return SF_OK;
}

static sf_ret_t data_map_set_tel_ctrl_es_cab( uint16_t array_idx, uint16_t addr_offset, uint16_t *p_value, uint16_t val_len )
{
    internal_shared_data_t *p_internal_data = internal_shared_data_get();
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();
    web_control_info_t *web_ctrl_info = shm_web_control_info_get();

    for (size_t i = 0; i < val_len; i++ )
    {
        uint16_t seq_id = addr_offset + i + 1;
        switch (seq_id)
        {
            case 1:   /* 远程开关机 */
                if ( p_value[i] ) 
                {
                    web_ctrl_info->CMU_system_control_on |= (1 << 0);
                } else {
                    web_ctrl_info->CMU_system_control_off |= (1 << 0);
                }
                web_ctrl_info->energy_saving_power_halt_flag = DISABLE;
                break;

            case 3:   /* 故障复归 */
                memset( p_telematic_data->container_system_fault_info, 0 , sizeof(p_telematic_data->container_system_fault_info) );
                p_internal_data->fault_reset = ENABLE;
                break;

            case 5:   /* 清除历史数据 */
                web_ctrl_info->clear_history_data_flag |= (1 << 0);
                break;

            case 2:   /* 液冷系统开关 */
            case 4:   /* 开启排气扇 */
            default:
                break;
        }
    }
    
    return SF_OK;
}

