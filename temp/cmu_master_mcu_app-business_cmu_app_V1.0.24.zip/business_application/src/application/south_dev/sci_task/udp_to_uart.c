#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>

#include "sdk_uart.h"
#include "sci_task.h"

#define UDP_PORT    7777
#define BUFF_LEN    1024

int udp_fd = 0;

static void _udp_recv_dat_vertify( uint8_t *p_recv_dat, uint32_t recv_len );
static void _udp_raw_printf( uint8_t *p_raw_dat, uint32_t raw_len );

static void *_udp_to_uart_thread( void )
{
    uint8_t recv_buf[BUFF_LEN] ;

    printf("%s start recv udp port:%d\r\n", __FUNCTION__, UDP_PORT);

    while (1)
    {
        struct sockaddr_in clientAddr;
        socklen_t size = sizeof(clientAddr);

        int len = recvfrom( udp_fd, recv_buf, sizeof(recv_buf), 0, (struct sockaddr *) &clientAddr, &size);
        if( len > 0 )
        {
            // printf( "udp recv len:%d data:", len );
            // _udp_raw_printf( recv_buf, len );
            _udp_recv_dat_vertify( recv_buf, len );
            printf( "tran to uart data:" );
            _udp_raw_printf( recv_buf, len );

            sdk_uart_write(SDK_UART2, recv_buf, len);
        }
        usleep(20000);
    }
    return NULL;
}

static int _udp_to_uart_thread_init( void )
{
	pthread_t thread_id;
    int ret;
 
	ret = pthread_create(&thread_id, NULL, (void *)_udp_to_uart_thread,NULL);
	if(ret)
	{
		printf("Create pthread error!\r\n");
		return -1;
	}
    printf("%s success\r\n", __FUNCTION__);
    return 0;
}

static int _udp_to_uart_socket_init( void )
{
    struct sockaddr_in ser_addr;
    int ret;

    udp_fd = socket(AF_INET, SOCK_DGRAM, 0); //AF_INET:IPV4;SOCK_DGRAM:UDP
    if(udp_fd < 0)
    {
        printf("create socket fail!\r\n");
        return -1;
    }

    memset(&ser_addr, 0, sizeof(ser_addr));
    ser_addr.sin_family = AF_INET;
    ser_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    ser_addr.sin_port = htons(UDP_PORT); 

    ret = bind(udp_fd, (struct sockaddr*)&ser_addr, sizeof(ser_addr));
    if(ret < 0)
    {
        printf("socket bind fail!\r\n");
        return -1;
    }

    printf( "_udp_to_uart_socket_init success\r\n" );

    return 0;
}

void udp_to_uart_init( void )
{
    _udp_to_uart_socket_init();
    _udp_to_uart_thread_init();
}

static void _udp_raw_printf( uint8_t *p_raw_dat, uint32_t raw_len )
{
    for (size_t i = 0; i < raw_len; i++)
        printf( "%02X ", p_raw_dat[i] );
    
    printf( "\r\n" );
}

static void _udp_recv_dat_vertify( uint8_t *p_recv_dat, uint32_t recv_len )
{
    if( (p_recv_dat[0] != 0x55) || (p_recv_dat[1] != 0xAA) )
    {
        printf("recv data header error!!!\r\n");
        return;
    }

    uint8_t dat_len = p_recv_dat[3];

    if( (dat_len + 6) != recv_len )
    {
        printf("frame len , recv len not match!!!\r\n");
        return;
    }

    uint16_t sum_val = 0;

    for (size_t i = 2; i < recv_len - 2; i++)
        sum_val += p_recv_dat[i];
    
    p_recv_dat[ recv_len - 2 ] = (sum_val >> 0) & 0xff;
    p_recv_dat[ recv_len - 1 ] = (sum_val >> 8) & 0xff;

    return;
}
