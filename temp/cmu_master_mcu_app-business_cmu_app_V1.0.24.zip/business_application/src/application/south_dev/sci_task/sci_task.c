/*****************************************************************************
* File Name			: sci_task.c			
* Description		: 	
* Original Author	: 
* date				: 
******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>

#include "mem_utils.h"
#include "update_task.h"
#include "sdk_shm.h"
#include "data_shm.h"
#include "sci_task.h"
#include "process_battery_read.h"
#include "cu_sofar_sci.h"
#include "sdk_uart.h"
#include "sofar_log.h"
#include "sdk_public.h"
#include "udp_to_uart.h"
#include "sofar_type.h"

#define SCI_TIMEOUT_MS		    	   (800)			// general串口读取超时时间800ms
// #define THRESHOLD_TIMEOUT_MS		   (3000)			// 串口读取阈值设置结果超时时间 3s
#define FLAG_REALTEMP0		    	  (0x0000)			// 实时数据跟随下发标志值，高字节为电池类数据长度，低字节为是否下发此类数据
// #define FLAG_REALTEMP1		   		  (0xC803)			// 实时数据跟随下发标志值，高字节为电池类数据长度，低字节为是否下发此类数据
#define FLAG_REALTEMP1(num, flag)           ((((num)*(20)) << (8)) | (flag))  // 实时数据跟随下发标志值，高字节为电池类数据长度，低字节为是否下发此类数据
#define LC_ON_OFF_DATA_NUM				(1)				// 遥控-液冷开关机 数据个数
#define THRESHOLD_CONTAINER_DATA_NUM	(1)				// 集装箱系统定值参数 数据个数
#define THRESHOLD_LC_SYS_DATA_NUM		(13)			// 液冷系统定值参数 数据个数
#define THRESHOLD_LC_LOGIC_DATA_NUM		(75)			// 液冷逻辑定值参数 数据个数
#define THRESHOLD_FIRE_DATA_NUM			(18)			// 消防定值参数 数据个数  15
#define THRESHOLD_DRY_DATA_NUM			(2)				// 除湿定值参数 数据个数
#define THRESHOLD_BATT_CAB_DATA_NUM		(1)				// 电池柜个数定值参数 数据个数
#define SET_FAN_ONOFF_STATUS_DATA_NUM	(1)				// 设置排气扇状态 数据个数
#define ENERGY_CABINET_ATTR_DATA_NUM	(2)				// 设置储能柜属性 数据个数

#define MAX_TIMER                       3
enum{
    SYS_TIME_UPDATE_TIMER = 0,      // 同步系统时间
	SYS_TIME_RESERVE1 = 1,			// 备用1  后面扩展可以使用
	SYS_TIME_RESERVE2 = 2,			// 备用2  后面扩展使用
};

#define SCI_SYS_TIME_UPDATE         (60 * 60 * 24 * 2) // 更新系统时间 24小时更新一次
static sdk_rtc_t g_operating_time[MAX_TIMER];           // 保存上次记录的时间点 目前只用到了一个，根据需要进行扩展使用

typedef struct 
{
	uint16_t ix;		// 记录单簇电池温度max1的簇号（0~10）
	uint16_t jx;		// 记录单簇电池温度max1的包号（0~7）
	uint16_t kx;		// 记录单簇电池温度max1的节号（每包的序号0~47）
	uint16_t iy;		// 记录单簇电池温度max2的簇号（0~10）
	uint16_t jy;		// 记录单簇电池温度max2的包号（0~7）
	uint16_t ky;		// 记录单簇电池温度max2的节号（每包的序号0~47）
}flag_t;

static flag_t flag;										
static sci_task_t g_sci_task;							// sci任务结构体缓存
static sci_localbuf_t g_sci_localbuf;					// sci数据结构体缓存
static uint8_t sci_cmd_map[STAGE_MAX];                  // sci指令map，记录相关指令是否已下发

pthread_mutex_t sofar_sci_mutex;						// 通信互斥锁


/**
 * @brief  获取sci通信收发互斥锁
 * @param  [in] none
 * @param  [out] none
 * @return sci通信收发互斥锁指针
 */
pthread_mutex_t *sci_mutex_get(void)
{
	return &sofar_sci_mutex;
}

/**
 * @brief  sci任务状态设置
 * @param  [in] stage 待设置的状态 具体见sci_stage_e
 * @param  [out] none
 * @return none
 */
static void task_stage_set(uint16_t stage)
{
	g_sci_task.stage = stage;
	return;
}

/**
 * @brief  sci任务升级标志位置1
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
void update_flag_set(void)
{
    g_sci_task.bupdate = 1;
    return;
}

/**
 * @brief  sci任务升级标志位清0
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
void update_flag_clear(void)
{
    g_sci_task.bupdate = 0;
    return;
}

/**
 * @brief  判断sci任务升级标志位是否为1
 * @param  [in] none
 * @param  [out] none
 * @return true：正在升级  false：未在升级
 */
static bool is_update_flag(void)
{
	firmware_update_t *p_update = NULL;

	p_update = get_shm_update_stru();

	if(p_update->state == UPDATING || p_update->state == UPDATE)
	{
		return true;
	}
	else 
	{
		return false;
	}
}

/**
 * @brief  交互标志位置1
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void course_flag_set(void)
{
	g_sci_task.course_flag = 1;
	return;
}

/**
 * @brief  交互标志位清除
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void course_flag_clear(void)
{
	g_sci_task.course_flag = 0;
	return;
}

/**
 * @brief  判断交互标志位是否为1
 * @param  [in] none
 * @param  [out] none
 * @return true：正在交互  false：未在交互
 */
static bool is_course_flag(void)
{
	bool ret = false;

	if(1 == g_sci_task.course_flag)
	{
		ret = true;
	}
	else
	{
		ret = false;
	}

	return ret;
}

/**
 * @brief  系统rtc时间获取
 * @param  [in] none
 * @param  [out] none
 * @return 当前时间结构体
 */
sci_time_t get_sci_time(void)
{
    int32_t ret = 0;
    sdk_rtc_t now;
	sci_time_t current = {0, 0, 0, 0, 0, 0};

    ret = sdk_rtc_get(RTC_BIN_FORMAT, &now);
	if (ret != 0)
	{
		return current;
	}

    current.year = now.tm_year + 2000;
    current.month = now.tm_mon;
    current.date = now.tm_day;
    current.hour = now.tm_hour;
    current.minute = now.tm_min;
    current.second = now.tm_sec;

    SCI_DEBUG_LOG((int8_t *)"[get_sci_time] %04d.%02d.%02d %02d:%02d:%02d\r\n", current.year, \
            		current.month, current.date, current.hour, current.minute, current.second);

    return current;  
}


/**
 * @brief   获取保存上次记录时间点的全局变量的指针
 * @param   index:编号
 * @return  (static修饰的)全局变量的地址作为返回值
 */
static sdk_rtc_t *operating_time_get(uint8_t index)
{
    return (&g_operating_time[index]);
}

/**
 * @brief   运行数据时间记录
 * @param   [in] p_rtc_time 当前的RTC时间结构体指针
 * @note    g_operating_time_record 记录保存运行的时间
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
static int32_t operating_time_set(sdk_rtc_t *p_rtc_time, uint8_t index)
{
    int32_t ret = 0;
    sdk_rtc_t *p_record = operating_time_get(index);

    if (p_record == NULL || p_rtc_time == NULL)
    {
        ret = -1;
    }
    else
    {
        p_record->tm_year = p_rtc_time->tm_year;
        p_record->tm_mon = p_rtc_time->tm_mon;
        p_record->tm_day = p_rtc_time->tm_day;
        p_record->tm_hour = p_rtc_time->tm_hour;
        p_record->tm_min = p_rtc_time->tm_min;
        p_record->tm_sec = p_rtc_time->tm_sec;
        p_record->tm_weekday = p_rtc_time->tm_weekday;
    }

    SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] operating_time_record_set, ret = %d \n", __func__, __LINE__, ret);

    return ret;
}

/**
 * @brief  结构体初始化打包
 * @param  [out] p_sofar sci结构体缓存，具体见cu_sofar_sci_t
 * @param  [in] funcid 功能码
 * @param  [in] p_data 数据段缓存指针
 * @param  [in] data_len 数据段的长度
 * @return none
 */
static void regular_data_pack(cu_sofar_sci_t *p_sofar, uint16_t func_id, uint8_t *p_data, int32_t data_len)
{
	if(p_sofar == NULL || p_data == NULL || data_len > SCI_BUF_SIZE)
	{
		return;
	}

	p_sofar->version = SCI_VERTION1;
	p_sofar->dev_addr = DEV_ADDR_CONTAINER;
	p_sofar->function_id = func_id;
	p_sofar->data_len = data_len;
	p_sofar->p_data = p_data;

	return;
}

/**
 * @brief  参数、数据列表初始化
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void sci_data_init(void)
{
	telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get(); 
	
	// task stru init
	memset(&g_sci_task, 0, sizeof(g_sci_task));
	SCI_DEBUG_LOG((int8_t *)"task-struct clear over\n");
	
    g_sci_task.stage = STAGE_SHAKE_HAND;
	g_sci_task.devaddr = DEV_ADDR_CONTAINER; 
	if(p_telemetry_data != NULL)
	{
		g_sci_task.bcu_actual_num = p_telemetry_data->container_system_telemetry_info.battery_cluster_number;		// 实际电池簇数量获取
	}
	SCI_DEBUG_LOG((int8_t *)"task-struct init over\n");

	// 电池最大温度位置清除
	memset(&flag, 0, sizeof(flag));

	// 数据本地缓存清0
	memset(&g_sci_localbuf, 0, sizeof(sci_localbuf_t));

	g_sci_localbuf.realtimetemp.flag = FLAG_REALTEMP1((BCU_DEVICE_NUM - 2), 0x01);
	g_sci_localbuf.batt_cab_num = 1;


	// memset(&g_sci_localbuf.cmu_mode, 0, sizeof(g_sci_localbuf.cmu_mode));
	// memset(&g_sci_localbuf.realtimedata, 0, sizeof(g_sci_localbuf.realtimedata));
	// memset(&g_sci_localbuf.thresholdinfo, 0, sizeof(g_sci_localbuf.thresholdinfo));
	// memset(g_sci_localbuf.realtimetemp.max_temp, 0, sizeof(g_sci_localbuf.realtimetemp.max_temp));
	// memset(g_sci_localbuf.realtimetemp.max_pack, 0, sizeof(g_sci_localbuf.realtimetemp.max_pack));

	return;
}

/**
 * @brief  sci通讯任务初始化
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void sci_task_init(void)
{
	int32_t retry_cnt = UART_INIT_RETRYCNT;
	sdk_uart_conf_t arrt = {UART_BAUD_RATE_115200, UART_DATA_BITS_8, UART_STOP_BITS_1, UART_PARITY_NONE, UART_HWFLOW_OFF};

	while(retry_cnt--)
	{
		// 打开串口
		if(sdk_uart_open(SDK_UART2) != 0) 
		{
			SCI_DEBUG_LOG((int8_t *)"sdk_uart_open faild\n");
			continue;
		}
		SCI_DEBUG_LOG((int8_t *)"sdk_uart_open over\n");

		// 配置串口
		SCI_DEBUG_LOG((int8_t *)"uart setup start!\n");	
		if(sdk_uart_setup(SDK_UART2, &arrt) == 0)
		{
			SCI_DEBUG_LOG((int8_t *)"sdk_setup over\n");
			break;
		}
		SCI_DEBUG_LOG((int8_t *)("sdk_uart_setup faild\n"));
	}

	// 参数数据列表初始化
	sci_data_init();

	return;
}

/**
 * @brief  通讯异常计数
 * @param  [in] devid  设备地址
 * @param  [in] berror 1 异常；0 正常
 * @param  [in] btimeout 1 接收超时异常；0 正常接收未超时
 * @param  [out] none
 * @return none
 */
static void sci_error_handle(int32_t devid, int32_t berror, int32_t btimeout)
{
	uint32_t step_cnt = 1;
	common_data_t *shm = NULL;

	shm = sdk_shm_get();

	if(devid != DEV_ADDR_CONTAINER)
	{
		return;
	}
	if(btimeout == 1)
	{
		step_cnt = 2;
	}
	//连续通讯异常包统计
	if(berror)
	{
		g_sci_task.commerr_cnt += step_cnt;
		if(g_sci_task.commerr_cnt >= COMMBREAKCNT_MAX)
		{
			g_sci_task.commerr_cnt = COMMBREAKCNT_MAX;
			g_sci_task.commbreak_flag = 1;
			// g_sci_task.commbreak_flag |= 1 << (devid - 1) ;
			// 置共享内存里对应故障位--SCI通信故障
			shm->telematic_data.CMU_system_fault_info[0] |= (1 << 4);
			SCI_DEBUG_LOG((int8_t *)("[sci_error_handle] sci commbreak!\n"));
		}
	}
	else
	{
		g_sci_task.commerr_cnt = 0;
		g_sci_task.commbreak_flag = 0; 
		// 清共享内存里对应故障位
		shm->telematic_data.CMU_system_fault_info[0] &= ~(1 << 4);
	}
	return;
}


/**
 * @brief  版本号（设备信息）更新至共享内存
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void sci_update_deviceinfo_to_shm(void)
{
	sci_handack_t *p_hand = NULL;
	common_data_t *shm = NULL;

	shm = sdk_shm_get();
	p_hand = &g_sci_localbuf.handack;

	if(NULL == shm || NULL == p_hand)
	{
		SCI_DEBUG_LOG((int8_t *)"[sci_update_deviceinfo_to_shm] p is null will return!\n");
		return;
	}

	// 更新mcu2app层软件版本号
	memcpy(shm->internal_version_info.mcu2_app_soft_version, \
			p_hand->mcu2_app_soft_version, SOFTVER_SIZE);
	SCI_DEBUG_LOG((int8_t *)"[sci_update_deviceinfo_to_shm] mcu2app soft_ver update ok!\n");

	// 更新mcu2core层软件版本号
	memcpy(shm->internal_version_info.mcu2_core_soft_version, \
			p_hand->mcu2_core_soft_version, SOFTVER_SIZE);
	SCI_DEBUG_LOG((int8_t *)"[sci_update_deviceinfo_to_shm] mcu2core soft_ver update ok!\n");

	// 判断mcu2sci协议版本号与mcu1是否一致
	if(SCI_VERTION1 != p_hand->mcu2_sci_version)
	{
		// 共享内存协议版本不一致置位

	}

	// 更新sci协议版本号
	shm->internal_version_info.sci_protocol_version = SCI_VERTION1;
	SCI_DEBUG_LOG((int8_t *)"[sci_update_deviceinfo_to_shm] sci protocol_ver update ok!\n");

	return;
}

/**
 * @brief  sci实时数据更新至共享内存
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void sci_update_realtimedata_to_shm(void)
{
    uint8_t i = 0;
	common_data_t *shm = NULL;
    sci_realtimedata_t *p_realtimedata = NULL;           
    telematic_data_t *p_telematic = NULL;
    container_system_telemetry_info_t *p_telemetry = NULL;
    quad_bytes_u *p_meter = NULL;

	shm = sdk_shm_get();
    p_realtimedata = &g_sci_localbuf.realtimedata;      					// 实时数据缓存

	if(shm == NULL || p_realtimedata == NULL)
	{
		return;
	}

    p_telematic = &shm->telematic_data;       								// 共享内存遥信数据
    p_telemetry = &shm->telemetry_data.container_system_telemetry_info;     // 共享内存遥测数据

	// 遥信数据
	/* 状态信息 */
	/* 储能柜系统DI信号 <MCU2> */
	p_telematic->container_system_status_info[1] = (uint8_t)((p_realtimedata->dev_di_sta_info >> 0) & 0xFF);
	p_telematic->container_system_status_info[2] = (uint8_t)((p_realtimedata->dev_di_sta_info >> 8) & 0xFF);

	/* 储能柜系统DO信号 <MCU2> */
	p_telematic->container_system_status_info[3] = (uint8_t)((p_realtimedata->dev_do_sta_info >> 0) & 0xFF);
	p_telematic->container_system_status_info[4] = (uint8_t)((p_realtimedata->dev_do_sta_info >> 8) & 0xFF);

	/* 消防DI信号 <MCU2> */
	p_telematic->container_system_status_info[5] = (uint8_t)((p_realtimedata->ff_di_sta_info >> 0) & 0xFF);
	p_telematic->container_system_status_info[6] = (uint8_t)((p_realtimedata->ff_di_sta_info >> 8) & 0xFF);

	/* 消防DI信号 <MCU2> */
	p_telematic->container_system_status_info[7] = (uint8_t)((p_realtimedata->ff_do_sta_info >> 0) & 0xFF);

	/* 液冷-状态信息 <MCU2> */
	p_telematic->container_system_status_info[8] = (uint8_t)((p_realtimedata->lc_sta_info >> 0) & 0xFF);
	p_telematic->container_system_status_info[9] = (uint8_t)((p_realtimedata->lc_sta_info >> 8) & 0xFF);
	p_telematic->container_system_status_info[10] = (uint8_t)((p_realtimedata->lc_sta_info >> 16) & 0xFF);
	p_telematic->container_system_status_info[11] = (uint8_t)((p_realtimedata->lc_sta_info >> 24) & 0xFF);

	/* 除湿器 <MCU2> */
	p_telematic->container_system_status_info[12] = (uint8_t)((p_realtimedata->dry_sta_info >> 0) & 0xFF);

	/* 风机联动原因 <MCU2> */
	p_telematic->container_system_status_info[13] = (uint8_t)((p_realtimedata->fan_reas_info >> 0) & 0xFF);

	/* 告警信息 */
	/* 储能柜系统 */
    BIT_COPY_A_BIT( p_telematic->container_system_warn_info[1], 0,  p_realtimedata->dev_warn_info, 0 );
    BIT_COPY_A_BIT( p_telematic->container_system_warn_info[1], 1,  p_realtimedata->dev_warn_info, 1 );
    BIT_COPY_A_BIT( p_telematic->container_system_warn_info[1], 2,  p_realtimedata->dev_warn_info, 3 );
    BIT_COPY_A_BIT( p_telematic->container_system_warn_info[1], 3,  p_realtimedata->dev_warn_info, 4 );
    BIT_COPY_A_BIT( p_telematic->container_system_warn_info[1], 4,  p_realtimedata->dev_warn_info, 5 );
    BIT_COPY_A_BIT( p_telematic->container_system_warn_info[1], 5,  p_realtimedata->dev_warn_info, 6 );
    BIT_COPY_A_BIT( p_telematic->container_system_warn_info[1], 6,  p_realtimedata->dev_warn_info, 7 );
    BIT_COPY_A_BIT( p_telematic->container_system_warn_info[1], 7,  p_realtimedata->dev_warn_info, 8 );

	/* 告警信息 */
	/* 电池仓IO采集板 */
	p_telematic->container_system_warn_info[1] &= (0x03);			// 清高6位
    p_telematic->container_system_warn_info[1] |= (uint8_t)(((p_realtimedata->dev_warn_info >> 0) & 0xF8));
	p_telematic->container_system_warn_info[1] |= (uint8_t)(((p_realtimedata->dev_warn_info >> 8) & 0x01));

	/* 液冷 */
    p_telematic->container_system_warn_info[2] = (uint8_t)((p_realtimedata->lc_warn_info1 >> 0) & 0xFF);
    p_telematic->container_system_warn_info[3] = (uint8_t)((p_realtimedata->lc_warn_info1 >> 8) & 0xFF);
	p_telematic->container_system_warn_info[4] = (uint8_t)((p_realtimedata->lc_warn_info2 >> 0) & 0xFF);
    p_telematic->container_system_warn_info[5] = (uint8_t)((p_realtimedata->lc_warn_info2 >> 8) & 0xFF);
	p_telematic->container_system_warn_info[6] = (uint8_t)((p_realtimedata->lc_warn_info3 >> 0) & 0xFF);
    p_telematic->container_system_warn_info[7] = (uint8_t)((p_realtimedata->lc_warn_info3 >> 8) & 0xFF);
	p_telematic->container_system_warn_info[8] = (uint8_t)((p_realtimedata->lc_warn_info4 >> 0) & 0xFF);
    p_telematic->container_system_warn_info[9] = (uint8_t)((p_realtimedata->lc_warn_info4 >> 8) & 0xFF);

	/* 消防一级告警 */
	p_telematic->container_system_warn_info[10] = (uint8_t)((p_realtimedata->ff_warn1_info1 >> 0) & 0xFF);
	p_telematic->container_system_warn_info[11] = (uint8_t)((p_realtimedata->ff_warn1_info1 >> 8) & 0xFF);
	p_telematic->container_system_warn_info[12] = (uint8_t)((p_realtimedata->ff_warn1_info2 >> 0) & 0xFF);
	p_telematic->container_system_warn_info[13] = (uint8_t)((p_realtimedata->ff_warn1_info2 >> 8) & 0xFF);
	p_telematic->container_system_warn_info[14] = (uint8_t)((p_realtimedata->ff_warn1_info3 >> 0) & 0xFF);
	p_telematic->container_system_warn_info[15] = (uint8_t)((p_realtimedata->ff_warn1_info3 >> 8) & 0xFF);

	/*消防控制器通信失联*/
//	p_telematic->container_system_warn_info[0] &= (0x7F); //清该位
	if(p_realtimedata->ff_warn1_info3 & 0x2000)
	{
		p_telematic->container_system_warn_info[0] |= 0x80;
	}
	else
	{
		p_telematic->container_system_warn_info[0] &= ~0x80;
	}
	//p_telematic->container_system_warn_info[0] |= (uint8_t)((p_realtimedata->ff_warn1_info3 >> 8) & 0x20);

	/*1/2/3/4/5/6#消防IO采集板通讯失联告警*/
	if(p_realtimedata->ff_warn1_info3 & 0x4000)
	{
		p_telematic->container_system_warn_info[15] |= 0x20;
	}
	else
	{
		p_telematic->container_system_warn_info[15] &= ~0x20;
	}
	//p_telematic->container_system_warn_info[15] &= (0xDF); //清该位
	//p_telematic->container_system_warn_info[15] |= (uint8_t)((p_realtimedata->ff_warn1_info3 >> 8) & 0x20);

	/* 除湿器告警告警 */
	p_telematic->container_system_warn_info[16] = (uint8_t)((p_realtimedata->dry_warn_info >> 0) & 0xFF);
	p_telematic->container_system_warn_info[17] = (uint8_t)((p_realtimedata->dry_warn_info >> 8) & 0xFF);

	/* 故障信息 */
	/* 储能柜系统 <MCU2> */
	p_telematic->container_system_fault_info[1] = (uint8_t)((p_realtimedata->dev_fault_info >> 0) & 0xFF);
	p_telematic->container_system_fault_info[2] = (uint8_t)((p_realtimedata->dev_fault_info >> 8) & 0xFF);
	/* 液冷-故障信息 <导致液冷停机> <MCU2> */
	p_telematic->container_system_fault_info[3] = (uint8_t)((p_realtimedata->lc_fault_info1 >> 0) & 0xFF);
	p_telematic->container_system_fault_info[4] = (uint8_t)((p_realtimedata->lc_fault_info1 >> 8) & 0xFF);
	p_telematic->container_system_fault_info[5] = (uint8_t)((p_realtimedata->lc_fault_info2 >> 0) & 0xFF);
	p_telematic->container_system_fault_info[6] = (uint8_t)((p_realtimedata->lc_fault_info2 >> 8) & 0xFF);
	p_telematic->container_system_fault_info[7] = (uint8_t)((p_realtimedata->lc_fault_info3 >> 0) & 0xFF);
	p_telematic->container_system_fault_info[8] = (uint8_t)((p_realtimedata->lc_fault_info3 >> 8) & 0xFF);
	p_telematic->container_system_fault_info[9] = (uint8_t)((p_realtimedata->lc_fault_info4 >> 0) & 0xFF);
	p_telematic->container_system_fault_info[10] = (uint8_t)((p_realtimedata->lc_fault_info4 >> 8) & 0xFF);

	/* 消防二级告警 <MCU2> */
	p_telematic->container_system_fault_info[11] = (uint8_t)((p_realtimedata->ff_warn2_info1 >> 0) & 0xFF);
	p_telematic->container_system_fault_info[12] = (uint8_t)((p_realtimedata->ff_warn2_info1 >> 8) & 0xFF);
	p_telematic->container_system_fault_info[13] = (uint8_t)((p_realtimedata->ff_warn2_info2 >> 0) & 0xFF);
	p_telematic->container_system_fault_info[14] = (uint8_t)((p_realtimedata->ff_warn2_info2 >> 8) & 0xFF);
	p_telematic->container_system_fault_info[15] = (uint8_t)((p_realtimedata->ff_warn2_info3 >> 0) & 0xFF);

	// 遥测数据
	shm->internal_shared_data.battery_chargedis_disable_mcu2 = (uint8_t)((p_realtimedata->stop_chargedis_flag >> 0) & 0xFF);
	/* 除湿器 */
	p_telemetry->bat1_humidity = p_realtimedata->bat1_humidity;
	p_telemetry->bat2_humidity = p_realtimedata->bat2_humidity;
	p_telemetry->bat3_humidity = p_realtimedata->bat3_humidity;
	p_telemetry->bat4_humidity = p_realtimedata->bat4_humidity;
	p_telemetry->bat5_humidity = p_realtimedata->bat5_humidity;
	p_telemetry->bat6_humidity = p_realtimedata->bat6_humidity;
	p_telemetry->bat1_temper = p_realtimedata->bat1_temper;
	p_telemetry->bat2_temper = p_realtimedata->bat2_temper;
	p_telemetry->bat3_temper = p_realtimedata->bat3_temper;
	p_telemetry->bat4_temper = p_realtimedata->bat4_temper;
	p_telemetry->bat5_temper = p_realtimedata->bat5_temper;
	p_telemetry->bat6_temper = p_realtimedata->bat6_temper;
	/* 液冷 */
	p_telemetry->lc_type = (uint16_t)(p_realtimedata->lc_type);
	p_telemetry->lc_outdoor_temper = p_realtimedata->lc_outdoor_temper;
	p_telemetry->lc_inlet_temp = p_realtimedata->lc_inlet_temp;
	p_telemetry->lc_outlet_temp = p_realtimedata->lc_outlet_temp;
	p_telemetry->lc_inlet_pressure = p_realtimedata->lc_inlet_pressure;
	p_telemetry->lc_outlet_pressure = p_realtimedata->lc_outlet_pressure;
	p_telemetry->lc_control_mode = p_realtimedata->lc_mode & 0x0F;
	p_telemetry->lc_sofar_mode = p_realtimedata->lc_mode >> 4;
	p_telemetry->pump_flow_rate = p_realtimedata->pump_flow_rate;
	p_telemetry->target_temp = p_realtimedata->target_temp;
	SCI_DEBUG_LOG((int8_t *)"lc_control_mode:%d  lc_sofar_mode:%d  pump_flow_rate:%d  target_temp:%d\n", \
	p_telemetry->lc_control_mode,\
	p_telemetry->lc_sofar_mode,\
	p_telemetry->pump_flow_rate,\
	p_telemetry->target_temp);
	/* 消防复合型传感器 */
	p_telemetry->mix_sensor1_temp = p_realtimedata->mix_sensor1_temp;
	p_telemetry->mix_sensor1_co_ppm = p_realtimedata->mix_sensor1_co_ppm;
	p_telemetry->mix_sensor1_pm25_ppm = p_realtimedata->mix_sensor1_pm25_ppm;
	p_telemetry->mix_sensor2_temp = p_realtimedata->mix_sensor2_temp;
	p_telemetry->mix_sensor2_co_ppm = p_realtimedata->mix_sensor2_co_ppm;
	p_telemetry->mix_sensor2_pm25_ppm = p_realtimedata->mix_sensor2_pm25_ppm;
	p_telemetry->mix_sensor3_temp = p_realtimedata->mix_sensor3_temp;
	p_telemetry->mix_sensor3_co_ppm = p_realtimedata->mix_sensor3_co_ppm;
	p_telemetry->mix_sensor3_pm25_ppm = p_realtimedata->mix_sensor3_pm25_ppm;
	p_telemetry->mix_sensor4_temp = p_realtimedata->mix_sensor4_temp;
	p_telemetry->mix_sensor4_co_ppm = p_realtimedata->mix_sensor4_co_ppm;
	p_telemetry->mix_sensor4_pm25_ppm = p_realtimedata->mix_sensor4_pm25_ppm;
	p_telemetry->mix_sensor5_temp = p_realtimedata->mix_sensor5_temp;
	p_telemetry->mix_sensor5_co_ppm = p_realtimedata->mix_sensor5_co_ppm;
	p_telemetry->mix_sensor5_pm25_ppm = p_realtimedata->mix_sensor5_pm25_ppm;
	p_telemetry->mix_sensor6_temp = p_realtimedata->mix_sensor6_temp;
	p_telemetry->mix_sensor6_co_ppm = p_realtimedata->mix_sensor6_co_ppm;
	p_telemetry->mix_sensor6_pm25_ppm = p_realtimedata->mix_sensor6_pm25_ppm;
	/* 消防 */
	p_telemetry->fire_fan_start_1co = p_realtimedata->fire_fan_start_1co;
	p_telemetry->fire_fan_start_2co = p_realtimedata->fire_fan_start_2co;
	p_telemetry->fire_fan_start_3co = p_realtimedata->fire_fan_start_3co;
	p_telemetry->fire_fan_start_4co = p_realtimedata->fire_fan_start_4co;
	p_telemetry->fire_fan_start_5co = p_realtimedata->fire_fan_start_5co;
	p_telemetry->fire_fan_start_6co = p_realtimedata->fire_fan_start_6co;
    
	p_telemetry->lc_com_loss_rate = p_realtimedata->lc_com_loss_rate;
	p_telemetry->ff_com_loss_rate = p_realtimedata->ff_com_loss_rate;
    for (size_t i = 0; i < ARRAY_SIZE( p_telemetry->dh_com_loss_rate ); i++)
    {
	    p_telemetry->dh_com_loss_rate[i] = p_realtimedata->dh_com_loss_rate[i];
    }
    for (size_t i = 0; i < ARRAY_SIZE( p_telemetry->io_ext_com_loss_rate ); i++)
    {
	    p_telemetry->io_ext_com_loss_rate[i] = p_realtimedata->io_ext_com_loss_rate[i];
    }
    p_telemetry->ff_cylinder_press = p_realtimedata->ff_cylinder_press;

    shm = sdk_shm_get();
    
	memcpy(shm->internal_version_info.ff_software_version, \
			p_realtimedata->ff_software_version, FF_SOFTVER_SIZE);
	SCI_DEBUG_LOG((int8_t *)"fire fighting soft_ver %d.%d update ok!\n", shm->internal_version_info.ff_software_version[0], shm->internal_version_info.ff_software_version[1]);

	return;
}	



/**
 * @brief  握手信息赋值至参数缓存
 * @param  [in] p_para_buf 发送数据缓存指针
 * @param  [out] none
 * @return >0:打包字节数  -1:失败
 */
static int32_t sci_onpack_handshake(uint8_t *p_para_buf)
{
	int32_t len = 0;
	if(p_para_buf == NULL)
	{
		return -1;
	}

	p_para_buf[len++] = (uint8_t)(0x00);
	p_para_buf[len++] = (uint8_t)(0x11);
	p_para_buf[len++] = (uint8_t)(0x22);
	p_para_buf[len++] = (uint8_t)(0x33);
	p_para_buf[len++] = (uint8_t)(0x44);
	return len;
}

/**
 * @brief  实时温度赋值至参数缓存
 * @param  [in] p_para_buf 发送数据缓存指针
 * @param  [out] none
 * @return >0:数据字节数  -1:失败
 */
static int32_t sci_onpack_realtimetemp(uint8_t *p_para_buf)
{
	uint16_t i = 0,j = 0,k = 0;
	uint16_t temp_pack = 0;
	int16_t temp_value = 0;
	int32_t len = 0;
	common_data_t *shm = NULL;
	sci_realtimetemp_t *p_real = NULL;
	battery_cluster_data_t *p_batdata = NULL;
	telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get(); 
	// battery_cluster_telemetry_info_t *p_batdata = NULL;
	
	shm = sdk_shm_get();
	p_batdata = battery_cluster_data_get();
	p_real = &g_sci_localbuf.realtimetemp;
	// p_batdata = sdk_shm_battery_cluster_telemetry_info_get(0);

	if(NULL == shm || NULL == p_batdata || NULL == p_real || NULL == p_para_buf || p_telemetry_data == NULL)
	{
		return -1;
	}

	// SCI_DEBUG_LOG((int8_t *)"[sci_onpack_realtimetemp] Before filter!\n");
	// for(i=0; i<g_sci_task.bcu_actual_num; i++)				
	// {
	// 	for(j=0; j<3; j++)				
	// 	{
	// 		SCI_DEBUG_LOG((int8_t *)"[sci_onpack_realtimetemp] g_sci_localbuf.realtimetemp.max_temp[%d][%d] = %d\n", i, j, g_sci_localbuf.realtimetemp.max_temp[i][j]);
	// 	}
	// }

	p_real->cmu_status = 0;
	p_real->BCU_comm_status = 0;
	memset(g_sci_localbuf.realtimetemp.max_temp, 0, sizeof(g_sci_localbuf.realtimetemp.max_temp));
	memset(g_sci_localbuf.realtimetemp.max_pack, 0, sizeof(g_sci_localbuf.realtimetemp.max_pack));

	// BCU状态获取
	for (i = 0; i < BCU_DEVICE_NUM; i++)
	{
		if (shm->telemetry_data.battery_cluster_telemetry_info[i].BCU_comm_status == 1)
		{
			p_real->BCU_comm_status |= (1<<i); 
		}
		else
		{
			p_real->BCU_comm_status &= (~(1<<i));
		}
	}
	
	// 1、获取cmu运行状态
	// p_real->cmu_status = shm->telemetry_data.cmu_telemetry_info.cmu_sys_state;
	p_real->cmu_status = (shm->telemetry_data.cmu_telemetry_info.cmu_sys_state << 8) | (0x0001);
	SCI_DEBUG_LOG((int8_t *)"cmu_status = %d\n", p_real->cmu_status);
	
	// 2、记录每簇电池最大温度值及对应pack号
	for(i=0; i<BCU_DEVICE_NUM; i++)				
	{
		for(j=0; j<PACK_NUMBER; j++)				
		{
			for(k=0; k<MONOMER_NUMBER_IN_PACK; k++)	
			{
				// printf("p_batdata[%x].monomer_data[%x].monomer_temperature[%x] = %x\n", i, j, k, p_batdata[i].monomer_data[j].monomer_temperature[k]);
				if(p_batdata[i].monomer_data[j].monomer_temperature[k] > p_real->max_temp[i][0])
				{
					temp_value = p_real->max_temp[i][0];
					temp_pack = p_real->max_pack[i][0];
					p_real->max_temp[i][0] = p_batdata[i].monomer_data[j].monomer_temperature[k];
					p_real->max_pack[i][0] = j;
					p_real->max_temp[i][2] = p_real->max_temp[i][1];
					p_real->max_pack[i][2] = p_real->max_pack[i][1];
					p_real->max_temp[i][1] = temp_value;
					p_real->max_pack[i][1] = temp_pack;
					flag.iy = flag.ix;
					flag.jy = flag.jx;
					flag.ky = flag.kx;
					flag.ix = i;
					flag.jx = j;
					flag.kx = k;
				}
				else if((p_batdata[i].monomer_data[j].monomer_temperature[k] > p_real->max_temp[i][1]) && \
				((i != flag.ix) || (j != flag.jx) || (k != flag.kx)))
				{
					p_real->max_temp[i][2] = p_real->max_temp[i][1];
					p_real->max_pack[i][2] = p_real->max_pack[i][1];
					p_real->max_temp[i][1] = p_batdata[i].monomer_data[j].monomer_temperature[k];
					p_real->max_pack[i][1] = j;
					flag.iy = i;
					flag.jy = j;
					flag.ky = k;
					
				}
				else if((p_batdata[i].monomer_data[j].monomer_temperature[k] > p_real->max_temp[i][2]) && \
				((i != flag.ix) || (j != flag.jx) || (k != flag.kx)) && \
				((i != flag.iy) || (j != flag.jy) || (k != flag.ky)))
				{
					p_real->max_temp[i][2] = p_batdata[i].monomer_data[j].monomer_temperature[k];
					p_real->max_pack[i][2] = j;	
				}
				else
				{
				}
				// SCI_DEBUG_LOG((int8_t *)"p_batdata[%d].monomer_data[%d].monomer_temperature[%d] = %d\n",i,j,k,p_batdata[i].monomer_data[j].monomer_temperature[k]);
			}
				// SCI_DEBUG_LOG((int8_t *)"\n");
		}

		memset(&flag, 0, sizeof(flag_t));	
		flag.ix = i + 1;					// 记录下一簇位置
		flag.iy = i + 1;					// 记录下一簇位置
		//SCI_DEBUG_LOG((int8_t *)"flag xyz clear over!\n");

		// 每簇单体温度最低值、平均值、簇端电压、簇端电流
		p_real->min_temp[i] = p_batdata[i].lowest_monomer_temperature_cluster[0];
		p_real->avr_temp[i] = p_batdata[i].average_temperature_monomer;
		p_real->cluster_voltage[i] = p_batdata[i].cluster_voltage;
		p_real->cluster_current[i] = p_batdata[i].cluster_current;

		// 标记温度是否全部更新
		if (p_real->max_temp[i][0] == 0)
		{
			p_real->cmu_status &= 0xFF00;
		}
	}

	memset(&flag, 0, sizeof(flag));


	// 3、将数据存入发送缓存
	if (FLAG_REALTEMP0 == p_real->flag)
	{
		g_sci_task.bcu_actual_num = p_telemetry_data->container_system_telemetry_info.battery_cluster_number;		// 实际电池簇数量获取
		// if (g_sci_task.bcu_actual_num > (BCU_DEVICE_NUM - 2))
		{
			p_para_buf[len++] = (uint8_t)((FLAG_REALTEMP1(2, 0x02) >> 8) & 0xff);	// 跟随标志高字节
			p_para_buf[len++] = (uint8_t)(FLAG_REALTEMP1(2, 0x02) & 0xff);	// 跟随标志低字节
			SCI_DEBUG_LOG((int8_t *)"p_real->flag = %x\n",p_real->flag);
			for (i = (BCU_DEVICE_NUM - 2); i < BCU_DEVICE_NUM; i++)
			{
				for(j=0; j<3; j++)
				{
					p_para_buf[len++] = (uint8_t)((p_real->max_temp[i][j] >> 8) & 0xff);
					p_para_buf[len++] = (uint8_t)((p_real->max_temp[i][j] >> 0) & 0xff);
					p_para_buf[len++] = (uint8_t)((p_real->max_pack[i][j] >> 8) & 0xff);
					p_para_buf[len++] = (uint8_t)((p_real->max_pack[i][j] >> 0) & 0xff);
				}
				p_para_buf[len++] = (uint8_t)((p_real->min_temp[i] >> 8) & 0xff);
				p_para_buf[len++] = (uint8_t)((p_real->min_temp[i] >> 0) & 0xff);
				p_para_buf[len++] = (uint8_t)((p_real->avr_temp[i] >> 8) & 0xff);
				p_para_buf[len++] = (uint8_t)((p_real->avr_temp[i] >> 0) & 0xff);
				p_para_buf[len++] = (uint8_t)((p_real->cluster_voltage[i] >> 8) & 0xff);
				p_para_buf[len++] = (uint8_t)((p_real->cluster_voltage[i] >> 0) & 0xff);
				p_para_buf[len++] = (uint8_t)((p_real->cluster_current[i] >> 8) & 0xff);
				p_para_buf[len++] = (uint8_t)((p_real->cluster_current[i] >> 0) & 0xff);
			}
		}
		return len;
	}
	p_para_buf[len++] = (uint8_t)((p_real->flag >> 8) & 0xff);	// 跟随标志高字节
	p_para_buf[len++] = (uint8_t)((p_real->flag >> 0) & 0xff);	// 跟随标志低字节
	SCI_DEBUG_LOG((int8_t *)"p_real->flag = %x\n",p_real->flag);
	p_para_buf[len++] = (uint8_t)((p_real->BCU_comm_status >> 8) & 0xff);
	p_para_buf[len++] = (uint8_t)((p_real->BCU_comm_status >> 0) & 0xff);
	p_para_buf[len++] = (uint8_t)((p_real->cmu_status >> 8) & 0xff);
	p_para_buf[len++] = (uint8_t)((p_real->cmu_status >> 0) & 0xff);
	p_para_buf[len++] = (uint8_t)((p_real->dehumidification_on_flag >> 8) & 0xff);
	p_para_buf[len++] = (uint8_t)((p_real->dehumidification_on_flag >> 0) & 0xff);

	// k = 0;
	for(i=0; i<BCU_DEVICE_NUM; i++)
	{
		for(j=0; j<3; j++)
		{
			// p_max_temp[i][j] = k+10;
			// k += 1;
			p_para_buf[len++] = (uint8_t)((p_real->max_temp[i][j] >> 8) & 0xff);
			p_para_buf[len++] = (uint8_t)((p_real->max_temp[i][j] >> 0) & 0xff);
			p_para_buf[len++] = (uint8_t)((p_real->max_pack[i][j] >> 8) & 0xff);
			p_para_buf[len++] = (uint8_t)((p_real->max_pack[i][j] >> 0) & 0xff);
			// p_para_buf[len++] = (uint8_t)((k >> 8) & 0xff);
			// p_para_buf[len++] = (uint8_t)((k >> 0) & 0xff);
			// k++;
			// p_para_buf[len++] = (uint8_t)((k >> 8) & 0xff);
			// p_para_buf[len++] = (uint8_t)((k >> 0) & 0xff);
			// k++;
		}
		p_para_buf[len++] = (uint8_t)((p_real->min_temp[i] >> 8) & 0xff);
		p_para_buf[len++] = (uint8_t)((p_real->min_temp[i] >> 0) & 0xff);
		p_para_buf[len++] = (uint8_t)((p_real->avr_temp[i] >> 8) & 0xff);
		p_para_buf[len++] = (uint8_t)((p_real->avr_temp[i] >> 0) & 0xff);
		p_para_buf[len++] = (uint8_t)((p_real->cluster_voltage[i] >> 8) & 0xff);
		p_para_buf[len++] = (uint8_t)((p_real->cluster_voltage[i] >> 0) & 0xff);
		p_para_buf[len++] = (uint8_t)((p_real->cluster_current[i] >> 8) & 0xff);
		p_para_buf[len++] = (uint8_t)((p_real->cluster_current[i] >> 0) & 0xff);
		// test
		// p_para_buf[len++] = (uint8_t)((k >> 8) & 0xff);
		// p_para_buf[len++] = (uint8_t)((k >> 0) & 0xff);
		// k++;
		// p_para_buf[len++] = (uint8_t)((k >> 8) & 0xff);
		// p_para_buf[len++] = (uint8_t)((k >> 0) & 0xff);
		// k++;
		// p_para_buf[len++] = (uint8_t)((k >> 8) & 0xff);
		// p_para_buf[len++] = (uint8_t)((k >> 0) & 0xff);
		// k++;
		// p_para_buf[len++] = (uint8_t)((k >> 8) & 0xff);
		// p_para_buf[len++] = (uint8_t)((k >> 0) & 0xff);
		// k++;
		// printf("max_temp[%d][%d] = %x      ",i,j,p_real->max_temp[i][j]);
		// printf("max_pack[%d][%d] = %x\n",i,j,p_real->max_pack[i][j]);
	}
	p_para_buf[len++] = (uint8_t)((p_real->preheat_on_flag >> 8) & 0xff);
	p_para_buf[len++] = (uint8_t)((p_real->preheat_on_flag >> 0) & 0xff);
	// printf("\n\n");

	return len;
}

/**
 * @brief  u16数据赋值至u8参数缓存
 * @param  [in] p_buf 数据发送缓存指针
 * @param  [in] p_data 待打包的u16数据块首地址
 * @param  [in] data_num 待打包的u16数据个数
 * @param  [out] none
 * @return >0:打包字节数  -1:失败
 */
static int32_t sci_onpack_txdata(uint8_t *p_buf, const uint16_t *p_data, int32_t data_num)
{
	int32_t i = 0;
	int32_t len = 0;
	
	if(NULL == p_buf || NULL == p_data)
	{
		return -1;
	}

	if(data_num > (SCI_BUF_SIZE / sizeof(uint16_t)))
	{
		SCI_DEBUG_LOG((int8_t *)"[sci_onpack_txdata] data_num is out of range!\n");
		return -1;
	}

	for(i=0; i<data_num; i++)
	{
		// 发送u16数据，高位在前，低位在后
		p_buf[len++] = (uint8_t)((p_data[i] >> 8) & 0xff);
		p_buf[len++] = (uint8_t)((p_data[i] >> 0) & 0xff);
	}
	
	return len;
}


/**
 * @brief  接收数据解析
 * @param  [in] p_buf 接收数据缓存
 * @param  [in] data_len 数据段长度
 * @param  [in] p_data 数据解析缓存首地址
 * @param  [out] none
 * @return >0:解析成功u16数据个数  -1:失败
 */
static int32_t sci_onparse_rxdata(uint8_t *p_buf, uint8_t data_len, uint16_t *p_data)
{
	uint8_t i = 0;
	int32_t num = 0;

	if(NULL == p_buf || NULL == p_data)
	{
		return -1;
	}

	for(i=0; i<data_len-1; i+=2)
	{
		// 接收组装为u16数据，高位在前，低位在后
		p_data[num++] = (uint16_t)((p_buf[i] << 8) | p_buf[i+1]);
	}

	return num;
}

/**
 * @brief  握手应答数据解析
 * @param  [in] p_data 指向应答包的数据段起始位置
 * @param  [in] buf_len	有效数据段长度 
 * @param  [out] none
 * @return 0：成功  -1：失败
 */
static int32_t sci_onparse_handshake(uint8_t *p_data, uint8_t buf_len)	
{
	sci_handack_t *p_hand = NULL;
	
	p_hand = &g_sci_localbuf.handack;

	if(NULL == p_data || NULL == p_hand)
	{
		return -1;;
	}

	if(buf_len != sizeof(sci_handack_t))
	{
		SCI_DEBUG_LOG((int8_t *)"[sci_onparse_handshake] ack data_len is not equal to local_stru!\n");
		return -1;
	}

	memcpy((uint8_t *)p_hand, p_data, sizeof(sci_handack_t));
	SCI_DEBUG_LOG((int8_t *)"[sci_onparse_handshake] local oparse ok!\n");

	return 0;
}

/**
 * @brief  实时接收数据解析
 * @param  [in] pbuf 应答包数据段缓存指针
 * @param  [in] data_len 应答包数据段长度
 * @param  [out] none
 * @return -1：解析异常  0：mcu2实时数据未上传成功解析  1：mcu2实时数据已上传且成功解析
 */
static int32_t sci_onparse_realtimedata(uint8_t *p_buf, uint8_t data_len)
{
	sci_realtimedata_t *p_data = NULL;

	p_data = &g_sci_localbuf.realtimedata;
	if(p_data == NULL || p_buf == NULL || data_len <2)
	{
		return -1;
	}


	// 跟随数据标志位
	p_data->flag = (uint16_t)((p_buf[0] << 8) | p_buf[1]);
	SCI_DEBUG_LOG((int8_t *)"[sci_onparse_realtimedata] realtime.flag = %x\n", p_data->flag);

	if((p_data->flag & 0x01) == 0)
	{
		return 0;
	}


	// 有实时数据时，数据大小需一致
	if(data_len != sizeof(sci_realtimedata_t))
	{
		SCI_DEBUG_LOG((int8_t *)"[sci_onparse_realtimedata] get data_len not equals to sci_t_size  data_len:%d, sci_realtimedata_t len:%d\n", data_len ,sizeof(sci_realtimedata_t));
		return -1;
	}

	p_data->mcu2_reset_flag = p_buf[2];
	p_data->lc_type = p_buf[3];
	sci_onparse_rxdata(p_buf+4, data_len-4, (uint16_t *)(p_data)+2);

	return 1;			
}

/**
 * @brief  发送指令
 * @param  [in] dev_addr 从机地址
 * @param  [in] function_id 功能码                               
 * @param  [in] data_len 数据段长度
 * @param  [in] p_data 数据段首地址
 * @param  [out] none
 * @return 0：成功  -1：失败
 */
int32_t sci_send_command(uint8_t dev_addr,uint16_t function_id, int32_t data_len, uint8_t *p_data)
{
    uint8_t txbuf[SCI_BUF_SIZE] = {0};
    int32_t send_len = 0;
	int32_t ret = -1;
    cu_sofar_sci_t sci_pack_tx;

	regular_data_pack(&sci_pack_tx, function_id, p_data, data_len);
    memset(txbuf, 0, SCI_BUF_SIZE);

    // 打包
    send_len = cu_sofar_sci_pack(&sci_pack_tx, txbuf, SCI_BUF_SIZE);
	if(send_len == -1)
	{
		SCI_DEBUG_LOG((int8_t *)"[cu_sofar_sci_pack] pack err ret = %d!\n", send_len);
		return -1;
	}
    SCI_DEBUG_LOG((int8_t *)"[sci_send_command] send_len = %d\n", send_len);

    // 发送
    ret = sdk_uart_write(SDK_UART2, txbuf, send_len);
    
    if(ret < 0)
    {
        SCI_DEBUG_LOG((int8_t *)"[sci_send_command] sci cmd send fail!\n");
		sci_error_handle(g_sci_task.devaddr, 1, 0);						// 异常未超时
		return -1;
    }
    else
    {
        SCI_DEBUG_LOG((int8_t *)"[sci_send_command] sci send_frame: ");
        print_frame(txbuf, send_len);
        SCI_DEBUG_LOG((int8_t *)"\n");
    }

    return 0;
}

/**
 * @brief  读取应答数据
 * @param  [in] time_out_ms	串口读取超时时间 
 * @param  [out] ack_data_buffer 应答数据段首地址
 * @param  [in] buf_len 接收缓存大小
 * @param  [in] function_id 功能码 
 * @return 读取结果 >=0：数据段长度  -1：失败
 */
int32_t sci_read_ackdata(int32_t time_out_ms, uint8_t *ack_data_buffer, uint8_t buf_len, uint16_t function_id)
{
    uint8_t rxbuf[SCI_BUF_SIZE] = {0};
    int32_t ret = -1;
    int32_t valid_data_len = 0;
    int32_t recv_len = 0;
    cu_sofar_sci_t sci_pack_rx;

	if(NULL == ack_data_buffer)
	{
		return -1;
	}
    
    // cu_stru_pack(&sci_pack_rx, SCI_VERTION1, function_id, dev_addr, SCI_BUF_SIZE, &rxbuf[INDEX_DATA_SLAVE]);
	regular_data_pack(&sci_pack_rx, function_id, &rxbuf[INDEX_DATA_SLAVE], SCI_BUF_SIZE);
    
    // 接收
    memset(rxbuf, 0, SCI_BUF_SIZE);
    ret = sdk_uart_read(SDK_UART2, rxbuf, SCI_BUF_SIZE, time_out_ms);
    SCI_DEBUG_LOG((int8_t *)"[sci_read_ackdata] recv_len = %d\n", ret);

    if(ret < 0)
    {
        SCI_DEBUG_LOG((int8_t *)"[sci_read_ackdata] uart read fail!\n");
		sci_error_handle(g_sci_task.devaddr, 1, 1);						// 异常且超时
        return -1;
    }

    recv_len = (ret > SCI_BUF_SIZE)?SCI_BUF_SIZE:ret;
    SCI_DEBUG_LOG((int8_t *)"[sci_read_ackdata] sci recv_frame: ");
    print_frame(rxbuf, recv_len);

    // 框架解包
    ret = cu_sofar_sci_unpack(DEV_ADDR_CONTAINER, function_id, &sci_pack_rx, rxbuf, recv_len);
    if(ret != 0)
    {
        SCI_DEBUG_LOG((int8_t *)"[sci_read_ackdata] unpack fail and ret = %d!\n",ret);
		sci_error_handle(g_sci_task.devaddr, 1, 0);						// 异常未超时
        return -1;
    }

    valid_data_len = rxbuf[3]-2;
    // 限幅
    valid_data_len = (int32_t)((valid_data_len>buf_len)?buf_len:valid_data_len);

    memcpy(ack_data_buffer, &rxbuf[INDEX_DATA_SLAVE], valid_data_len);
    SCI_DEBUG_LOG((int8_t *)"[sci_read_ackdata] sci recv ok\n");
    
    return valid_data_len;
}

/**
 * @brief  上电握手过程--交互
 * @param  [in] none
 * @param  [out] none
 * @return 0:成功  -1:失败
 */
static int32_t sci_handshake_course(void)
{
	uint8_t i = 0;
	int32_t ret1 = -1;
	int32_t ret2 = -1;
	int32_t ret3 = -1;
	int32_t data_len = 0;			// 发送数据长度
	int32_t valid_data_len = 0;		// 接收有效数据长度

	course_flag_set();				// 交互开始

	// 1、发送
	memset(&g_sci_task.txbuf, 0, SCI_BUF_SIZE);
	data_len = sci_onpack_handshake(&g_sci_task.txbuf[INDEX_DATA_HOST]);
	SCI_DEBUG_LOG((int8_t *)"[sci_handshake_course] data_len = %d\n",data_len);
	if(data_len == -1)
	{
		course_flag_clear();
		return -1;
	}

	for(i=0; i<CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		// 发送握手数据
		ret1 = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_HANDSHAKED, data_len, &g_sci_task.txbuf[INDEX_DATA_HOST]);

        // 获取应答结果
		if(ret1 == 0)
		{
			ret2 = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_HANDSHAKED);
		} 
		pthread_mutex_unlock(&sofar_sci_mutex);

		if(ret2 > 0)
		{	
			valid_data_len = ret2;
			SCI_DEBUG_LOG((int8_t *)"[sci_handshake_course] ack ok and valid_data_len = %d\n", valid_data_len);
			break;
		}

		usleep(1000 * 100);

	}
	// 数据处理
	if (valid_data_len > 0)		
	{		
		// 解析握手信息
		ret3 = sci_onparse_handshake(&g_sci_task.rxbuf[INDEX_DATA_SLAVE], valid_data_len);	

		// 版本信息上传至共享内存
		if(ret3 == 0)
		{
			sci_update_deviceinfo_to_shm();

			// 清异常通讯计数
			sci_error_handle(g_sci_task.devaddr, 0, 0);
		}
		else
		{
			sci_error_handle(g_sci_task.devaddr, 1, 0);
		}

	}
	course_flag_clear();				// 交互结束

	return ret3;		
}

void sci_localbuf_fresh( void )
{
	common_data_t *p_shm = sdk_shm_get();
    sci_localbuf_t *p_localbuf = &g_sci_localbuf;
    dynamic_ring_parameter_data_t *p_dynamic_ring   = &p_shm->constant_parameter_data.dynamic_ring ;
    dynamic_ring_parameter_data2_t *p_dynamic_ring2 = &p_shm->constant_parameter_data.dynamic_ring2;
    
	// 将共享内存数据更新至缓存
    sci_lc_param_setting_t *p_sci_lc_param_setting  = &g_sci_localbuf.thresholdinfo.lc_param_setting;
    /* 共享内存与SCI相对应部分直接拷贝 */
	memcpy( p_sci_lc_param_setting, &p_dynamic_ring->lc_type, sizeof(sci_lc_param_setting_t));

    sci_lc_logic_setting_t *p_sci_lc_logic_setting = &g_sci_localbuf.thresholdinfo.lc_logic_setting;
    /* 共享内存与SCI相对应部分直接拷贝 */
	memcpy( p_sci_lc_logic_setting, &p_dynamic_ring->bat_Dts, sizeof(sci_lc_logic_setting_t));
    /* 非对应的数值重新赋值 */
    p_sci_lc_logic_setting->keep_temper_enable                 = p_dynamic_ring2->keep_temper_enable;
    p_sci_lc_logic_setting->keep_temper_heating_startup_temper = p_dynamic_ring2->keep_temper_heating_startup_temper;
    p_sci_lc_logic_setting->keep_temper_heating_exit_temper    = p_dynamic_ring2->keep_temper_heating_exit_temper;
    p_sci_lc_logic_setting->keep_temper_cooling_startup_temper = p_dynamic_ring2->keep_temper_cooling_startup_temper;
    p_sci_lc_logic_setting->keep_temper_cooling_exit_temper    = p_dynamic_ring2->keep_temper_cooling_exit_temper;
    p_sci_lc_logic_setting->pre_heating_forbid_charge_discharge_temper = p_dynamic_ring2->pre_heating_forbid_charge_discharge_temper;
    p_sci_lc_logic_setting->pre_cooling_forbid_charge_discharge_temper = p_dynamic_ring2->pre_cooling_forbid_charge_discharge_temper;

    sci_ff_setting_t *p_sci_ff_setting = &g_sci_localbuf.thresholdinfo.ff_setting;
    /* 共享内存与SCI相对应部分直接拷贝 */
	memcpy( p_sci_ff_setting, &p_dynamic_ring->gauge1_low_pressure_threshold, sizeof(sci_ff_setting_t));
    /* 非对应的数值重新赋值 */
    p_sci_ff_setting->reserve[0] = 0;
    p_sci_ff_setting->reserve[1] = 0;

    sci_dh_setting_t *p_sci_dh_setting =  &g_sci_localbuf.thresholdinfo.dh_setting;
    /* 共享内存与SCI相对应部分直接拷贝 */
	memcpy( p_sci_dh_setting, &p_dynamic_ring->dst_humidity, sizeof(sci_dh_setting_t));

	p_localbuf->cmu_mode = p_shm->constant_parameter_data.cmu_mode;
	p_localbuf->telecommand.LC_on_off_ctrl = p_shm->other_parameter_data.LC_on_off_ctrl;
	p_localbuf->batt_cab_num = p_shm->constant_parameter_data.bat_cabinet_num;
	p_localbuf->ff_addr = p_shm->constant_parameter_data.energy_cabinet_FF_addr;
	p_localbuf->energy_cab_num = p_shm->constant_parameter_data.energy_cabinet_num;
}

/**
 * @brief  下发动作阈值过程--交互
 * @param  [in] funcid 下发阈值对应功能码
 * @param  [in] p_data 待发送数据首地址
 * @param  [in] data_num 待发送数据个数
 * @param  [out] none
 * @return 0:成功  -1:失败
 */
static int32_t sci_threshold_course(uint16_t function_id, uint16_t *p_data, uint32_t data_num)
{
	uint8_t i = 0;
	int32_t data_len = 0;		// 发送数据长度
	int32_t ret1 = -1;
	int32_t ret2 = -1;
	int32_t ret3 = -1;
	common_data_t *shm = NULL;
	sci_localbuf_t *p_localbuf = NULL;

	shm = sdk_shm_get();
	p_localbuf = &g_sci_localbuf;
	
	if(NULL == shm || NULL == p_localbuf || NULL == p_data)
	{
		return -1;
	}

	course_flag_set();			// 交互开始

	// 将共享内存数据更新至缓存
	sci_localbuf_fresh();

	SCI_DEBUG_LOG((int8_t *)"level_2_alarm_pack_temperature2 = %x\n", p_localbuf->thresholdinfo.level_2_alarm_pack_temperature2);

	// 1、发送
	memset(&g_sci_task.txbuf, 0, SCI_BUF_SIZE);

    if ( function_id == FUNCID_SET_PARA_FIRE )
    {
        uint16_t temp_dat[ 100 ];

        memset( temp_dat, 0, sizeof( temp_dat ));
        memcpy( temp_dat, p_data, data_num * sizeof( uint16_t ) );
        if ( shm->constant_parameter_data.energy_cabinet_FF_addr != 1 )
        {
            /* 消防共享为从机时候，气瓶低压阈值设置为0，因为消防共享从机储能柜不带消防瓶 */
            temp_dat[0] = 0;
        }
	    data_len = sci_onpack_txdata(&g_sci_task.txbuf[INDEX_DATA_HOST], temp_dat, data_num);
    }else{
	    data_len = sci_onpack_txdata(&g_sci_task.txbuf[INDEX_DATA_HOST], p_data, data_num);
    }

	if(data_len == -1)
	{
		course_flag_clear();
		return -1;
	}
		
	for(i=0; i<CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		// 发送握手数据
		ret1 = sci_send_command(DEV_ADDR_CONTAINER, function_id, data_len, &g_sci_task.txbuf[INDEX_DATA_HOST]);

		// 等待mcu2下发结束
		sleep(3);
        // 获取应答结果
		if(ret1 == 0)
		{
			ret2 = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, function_id);
		} 
		pthread_mutex_unlock(&sofar_sci_mutex);

		if(ret2 > 0)
		{
			break;
		}

		usleep(1000 * 100);
	}

	if(ret2 > 0)
	{
		// 无数据处理
		if(1 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
		{
			SCI_DEBUG_LOG((int8_t *)("[sci_threshold_course] 2-Threshold Set ok!!!\n"));
			ret3 = 0;
		}
		else if(0 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
		{
			SCI_DEBUG_LOG((int8_t *)("[sci_threshold_course] 2-Threshold Set fail!\n"));	
			ret3 = -1;
		}
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);

	}
	course_flag_clear();			// 交互结束

	return ret3;
}

/**
 * @brief  获取实时数据过程--交互
 * @param  [in] none
 * @param  [out] none
 * @return 0:成功  负数:失败
 */
static int32_t sci_realtimedata_course(void)
{
	uint8_t i = 0;
	int32_t ret1 = -1;
	int32_t ret2 = -1;
	int32_t ret3 = -1;
	int32_t rtn = -1;
	int32_t valid_data_len = 0;
	int32_t data_len = 0;		// 发送数据长度

	course_flag_set();			// 交互开始

	// 打包数据
	memset(&g_sci_task.txbuf, 0, SCI_BUF_SIZE);
	data_len = sci_onpack_realtimetemp(&g_sci_task.txbuf[INDEX_DATA_HOST]);
	if(data_len == -1)
	{
		course_flag_clear();
		return -1;
	}

	for(i=0; i<CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		// 发送握手数据
		ret1 = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_GET_REALTIME_DATA, data_len, &g_sci_task.txbuf[INDEX_DATA_HOST]);

        // 获取应答结果
		if(ret1 == 0)
		{
			ret2 = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_GET_REALTIME_DATA);
		} 
		pthread_mutex_unlock(&sofar_sci_mutex);

		if(ret2 > 0)
		{
			valid_data_len = ret2;

			// 定时除湿命令已下发完成，清标志位
			if ((g_sci_localbuf.realtimetemp.dehumidification_on_flag == 1) && \
				(g_sci_localbuf.realtimetemp.flag == FLAG_REALTEMP1((BCU_DEVICE_NUM - 2), 0x01)))
			{
				g_sci_localbuf.realtimetemp.dehumidification_on_flag = 0;
				g_sci_task.regular_dehum_finish = 1;
			}

			// 定时预冷预热命令已下发完成，清标志位
			if ((g_sci_localbuf.realtimetemp.preheat_on_flag == 1) && \
				(g_sci_localbuf.realtimetemp.flag == FLAG_REALTEMP1((BCU_DEVICE_NUM - 2), 0x01)))
			{
				g_sci_localbuf.realtimetemp.preheat_on_flag = 0;
				g_sci_task.regular_preheat_finish = 1;
			}

			break;
		}

		usleep(1000 * 100);
	}
	// 数据处理
	if(valid_data_len > 0)
	{
		// 实时数据解析
		ret3 = sci_onparse_realtimedata(&g_sci_task.rxbuf[INDEX_DATA_SLAVE], valid_data_len);
		if(ret3 != -1)
		{
			if(ret3 == 1)
			{
				// 实时数据更新至共享内存
				sci_update_realtimedata_to_shm();
			}
			
			// 清共享内存计数
			sci_error_handle(g_sci_task.devaddr, 0, 0);

			rtn = 0;
		}
		else
		{
			sci_error_handle(g_sci_task.devaddr, 1, 0);				// 解析异常
			rtn = -1;
		}

	}

	course_flag_clear();		// 交互结束
	return rtn;
}

/**
 * @brief  SCI通讯指令切换
 * @param  [in] current_stage  当n前执行指令
 * @param  [out] none
 * @return 下一个要执行的指令
 */
static void sci_stage_change(sci_stage_e current_stage)
{
	uint8_t i;

	for(i=current_stage; i<STAGE_GET_REALTIMEDATA; i++)
	{
		if(sci_cmd_map[i] != 0)
		{
			task_stage_set(i);
			return;
		}
	}
	task_stage_set(STAGE_GET_REALTIMEDATA);
	return;
}

/**
* @brief		同步时间
* @return		void
*/
static void sync_time(void)
{
	uint8_t *time_buf = NULL;
	uint8_t len = 0;
	int32_t ret = 0;
	int32_t i = 0;

    if(is_update_flag() == true)
    {
        return;
    }
	course_flag_set();			// 交互开始
	
	sdk_rtc_t rtc_time;
	sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
	SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] system time:%02i:%02i:%02i (%02i)%02i/%02i/%04i\n",__func__, __LINE__, rtc_time.tm_hour,
                         rtc_time.tm_min,
                         rtc_time.tm_sec,
                         rtc_time.tm_weekday,
                         rtc_time.tm_day,
                         rtc_time.tm_mon,
                         rtc_time.tm_year + 2000);
	
	time_buf = &g_sci_task.txbuf[INDEX_DATA_HOST];
	
	time_buf[len++] = (rtc_time.tm_sec >> 8) & 0xff;
	time_buf[len++] = (rtc_time.tm_sec >> 0) & 0xff;
	time_buf[len++] = (rtc_time.tm_min >> 8) & 0xff;
	time_buf[len++] = (rtc_time.tm_min >> 0) & 0xff;
	time_buf[len++] = (rtc_time.tm_hour >> 8) & 0xff;
	time_buf[len++] = (rtc_time.tm_hour >> 0) & 0xff;
	
	time_buf[len++] = (rtc_time.tm_weekday >> 8) & 0xff;
	time_buf[len++] = (rtc_time.tm_weekday >> 0) & 0xff;

	time_buf[len++] = (rtc_time.tm_day >> 8) & 0xff;
	time_buf[len++] = (rtc_time.tm_day >> 0) & 0xff;
	time_buf[len++] = (rtc_time.tm_mon >> 8) & 0xff;
	time_buf[len++] = (rtc_time.tm_mon >> 0) & 0xff;
	time_buf[len++] = (rtc_time.tm_year >> 8) & 0xff;
	time_buf[len++] = (rtc_time.tm_year >> 0) & 0xff;
	
	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		// 发送握手数据
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_SYNC_TIME, len, &g_sci_task.txbuf[INDEX_DATA_HOST]);
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_SYNC_TIME);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			if(1 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
			{
				SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__, ret);
				break;
			}
			
		}
		usleep(1000 * 100);
	}
	if(ret > 0)
	{
		// 无数据处理
		if(1 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
		{
			g_sci_task.systime_sync_flag = 1;
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] sync_time Set ok!!!\n"),__func__, __LINE__);
		}
		else if(0 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
		{
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] sync_time Set fail!\n"),__func__, __LINE__);	
		}
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束
	return;
}

/**
* @brief		周期更新系统时间
* @return		void
*/
void period_sync_time()

{
	static uint32_t sync_time_cnt = 0;
	web_control_info_t *p_web_data = shm_web_control_info_get();

	// 上电握手完成后第一次同步时间
	if ((g_sci_task.stage > STAGE_SHAKE_HAND) && (g_sci_task.systime_sync_flag == 0 || p_web_data->sync_systime_flag == 1))
	{
		p_web_data->sync_systime_flag = 0;
		sync_time();
	}

	// 每隔24小时左右同步一次时间
	if (sync_time_cnt < SCI_SYS_TIME_UPDATE)
	{
		sync_time_cnt++;
		return;
	}
	else 
	{
		sync_time_cnt = 0;
	}

	sync_time();
	return;
}

/**
 * @brief  SCI通讯任务管理
 * @param  [in] arg
 * @param  [out] none
 * @return 0:正常  负数:异常
 */
static int32_t sci_task_manage(void)
{
	int32_t ret = -1;
	sci_localbuf_t *p_localbuf = NULL;

	p_localbuf = &g_sci_localbuf;

	if(NULL == p_localbuf)
	{
		return ret;
	}

    if(is_update_flag() == true)
    {
        return ret;
    }
    SCI_DEBUG_LOG((int8_t *)"[sci_task_manage] Not in the upgrade, prepare the sci!\n");

	// 直接判断阶段
	switch(g_sci_task.stage)
	{
		case STAGE_SHAKE_HAND:
		{	
			SCI_DEBUG_LOG((int8_t *)("[sci_task_manage] this is 1 stage!\n"));
		
			// g_sci_task.current_funcID = FUNCID_HANDSHAKED;

			ret = sci_handshake_course();

			if(0 == ret)
			{
				memset(sci_cmd_map,0x01,sizeof(sci_cmd_map));
				task_stage_set(STAGE_SEND_PARA_LC);
			}
			break;
		}
		case STAGE_SEND_PARA_LC:
		{
			SCI_DEBUG_LOG((int8_t *)"[sci_task_manage] this is 2-3 stage!\n");

			// g_sci_task.current_funcID = FUNCID_SET_PARA_SYSTEM_LC;

			ret = sci_threshold_course(FUNCID_SET_PARA_SYSTEM_LC, \
										(uint16_t *)(&(p_localbuf->thresholdinfo.lc_param_setting)), sizeof( sci_lc_param_setting_t ) / 2);
			if(ret == 0)
			{
				sci_cmd_map[STAGE_SEND_PARA_LC] = 0;
			}
			sci_stage_change(STAGE_SEND_TELECOMMAND);
			break;
		}
		case STAGE_SEND_TELECOMMAND:
		{
			SCI_DEBUG_LOG((int8_t *)"[sci_task_manage] this is 2-1 stage!\n");
			SCI_DEBUG_LOG((int8_t *)"[sci_task_manage] 2-1stage: p_localbuf->telecommand.LC_on_off_ctrl = %x\n\n\n",p_localbuf->telecommand.LC_on_off_ctrl);
			
			// g_sci_task.current_funcID = FUNCID_SET_POWER_ONOFF_LC;

			ret = sci_threshold_course(FUNCID_SET_POWER_ONOFF_LC, \
										(uint16_t *)(&(p_localbuf->telecommand.LC_on_off_ctrl)), LC_ON_OFF_DATA_NUM);
			if(ret == 0)
			{
				sci_cmd_map[STAGE_SEND_TELECOMMAND] = 0;
			}
			sci_stage_change(STAGE_SEND_PARA_CONTAINER);
			break;
		}
		case STAGE_SEND_PARA_CONTAINER:
		{
			SCI_DEBUG_LOG((int8_t *)"[sci_task_manage] this is 2-2 stage!\n");

			// g_sci_task.current_funcID = FUNCID_SET_PARA_CONTAINER;

			ret = sci_threshold_course(FUNCID_SET_PARA_CONTAINER, \
										(uint16_t *)(&(p_localbuf->cmu_mode)), THRESHOLD_CONTAINER_DATA_NUM);
			if(ret == 0)
			{
				sci_cmd_map[STAGE_SEND_PARA_CONTAINER] = 0;
			}
			sci_stage_change(STAGE_SEND_PARA_LOGIC_LC);
			break;
		}
		case STAGE_SEND_PARA_LOGIC_LC:
		{
			SCI_DEBUG_LOG((int8_t *)"[sci_task_manage] this is 2-4 stage!\n");
            
			ret = sci_threshold_course(FUNCID_SET_PARA_LOGIC_LC, \
									   (uint16_t *)(&(p_localbuf->thresholdinfo.lc_logic_setting)), sizeof( sci_lc_logic_setting_t )/2);
			if(ret == 0)
			{
				sci_cmd_map[STAGE_SEND_PARA_LOGIC_LC] = 0;
			}
			sci_stage_change(STAGE_SEND_PARA_BATT_CAB_NUM);
			break;
		}
		case STAGE_SEND_PARA_BATT_CAB_NUM:
		{
			SCI_DEBUG_LOG((int8_t *)"[sci_task_manage] this is 2-5 stage!\n");

			// g_sci_task.current_funcID = STAGE_SEND_PARA_BATT_CAB_NUM;
			
			ret = sci_threshold_course(FUNCID_SET_PARA_BATT_CAB_NUM, \
										(uint16_t *)(&(p_localbuf->batt_cab_num)), THRESHOLD_BATT_CAB_DATA_NUM);
			if(ret == 0)
			{
				sci_cmd_map[STAGE_SEND_PARA_BATT_CAB_NUM] = 0;
			}
			sci_stage_change(STAGE_SEND_PARA_FIRE);
			break;
		}
		case STAGE_SEND_PARA_FIRE:
		{
			SCI_DEBUG_LOG((int8_t *)"[sci_task_manage] this is 2-6 stage!\n");

			// g_sci_task.current_funcID = FUNCID_SET_PARA_FIRE;
			
			ret = sci_threshold_course(FUNCID_SET_PARA_FIRE, \
										(uint16_t *)(&(p_localbuf->thresholdinfo.ff_setting)), sizeof( sci_ff_setting_t )/2);
			if(ret == 0)
			{
				sci_cmd_map[STAGE_SEND_PARA_FIRE] = 0;
			}
			sci_stage_change(STAGE_SEND_PARA_DRY);
			break;
		}
		case STAGE_SEND_PARA_DRY:
		{
			SCI_DEBUG_LOG((int8_t *)"[sci_task_manage] this is 2-7 stage!\n");

			// g_sci_task.current_funcID = STAGE_SEND_PARA_DRY;
			
			ret = sci_threshold_course(FUNCID_SET_PARA_DRY, \
										(uint16_t *)(&(p_localbuf->thresholdinfo.dh_setting)), sizeof( sci_dh_setting_t )/2);
			if(ret == 0)
			{
				sci_cmd_map[STAGE_SEND_PARA_DRY] = 0;
			}
			sci_stage_change(STAGE_SEND_ENEGY_CAB_ATTR);
			break;
		}
		case STAGE_SEND_ENEGY_CAB_ATTR:
		{
			SCI_DEBUG_LOG((int8_t *)"[sci_task_manage] this is 2-8 stage!\n");

			// g_sci_task.current_funcID = STAGE_SEND_ENEGY_CAB_ATTR;
			
			ret = sci_threshold_course(FUNCID_SET_ENEGY_CAB_ATTR, \
										(uint16_t *)(&(p_localbuf->ff_addr)), ENERGY_CABINET_ATTR_DATA_NUM);
			if(ret == 0)
			{
				sci_cmd_map[STAGE_SEND_ENEGY_CAB_ATTR] = 0;
			}
			sci_stage_change(STAGE_GET_REALTIMEDATA);
			break;
		}
		case STAGE_GET_REALTIMEDATA:
		{
		
			SCI_DEBUG_LOG((int8_t *)("[sci_task_manage] this is 3 stage!\n"));

			// g_sci_task.current_funcID = FUNCID_GET_REALTIME_DATA;

			ret = sci_realtimedata_course();

			// 实时数据间隔下发
			SCI_DEBUG_LOG((int8_t *)"[sci_task_manage] g_sci_localbuf.realtimetemp.flag = %x\n",g_sci_localbuf.realtimetemp.flag);
			if(g_sci_localbuf.realtimetemp.flag == FLAG_REALTEMP0)
			{
				SCI_DEBUG_LOG((int8_t *)"[sci_task_manage] g_sci_localbuf.realtimetemp.flag come here to judge0-1!\n");
				g_sci_localbuf.realtimetemp.flag = FLAG_REALTEMP1((BCU_DEVICE_NUM - 2), 0x01);
			}
			else
			{
				SCI_DEBUG_LOG((int8_t *)"[sci_task_manage] g_sci_localbuf.realtimetemp.flag come here to judge1-0!\n");
				g_sci_localbuf.realtimetemp.flag = FLAG_REALTEMP0;
				sci_stage_change(STAGE_SEND_PARA_LC);
			}
			
			if (g_sci_localbuf.realtimedata.mcu2_reset_flag == 0)
			{
				SCI_DEBUG_LOG((int8_t *)("[sci_task_manage] mcu2_reset_flag = 0 !\n"));
				g_sci_task.para_init_finish = 0;
				task_stage_set(STAGE_SHAKE_HAND);
			}
			break;
		}
		default:
		{
			break;
		}
		
	}
	period_sync_time();
	return ret;
}


/**
 * @brief  下发定值参数
 * @param  [in]  function_id 下发数据功能码，具体见data_shm.h
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
int32_t set_constant_data(uint16_t function_id)
{
	int32_t ret = 0;
	int32_t cnt = 10000;
	common_data_t *shm = NULL;
	sci_localbuf_t *p_localbuf = NULL;

	shm = sdk_shm_get();
	p_localbuf = &g_sci_localbuf;

	if(NULL == p_localbuf || NULL == shm)
	{
		return -1;
	}

    if(is_update_flag() == true)
    {
        return -1;
    }

	while(cnt--)
	{
		if(false == is_course_flag())
		{
			task_stage_set(STAGE_OTHER);
			break;
		}
		usleep(1000*1);
	}

	p_localbuf->telecommand.LC_on_off_ctrl = shm->other_parameter_data.LC_on_off_ctrl;
	p_localbuf->telecommand.EF_on_off_ctrl = shm->other_parameter_data.EF_on_off_ctrl;
			
	switch (function_id)
	{
		case FUNCID_SET_POWER_ONOFF_LC:
		{	
			// task_stage_set(STAGE_OTHER);
			SCI_DEBUG_LOG((int8_t *)"\n FUNCID_SET_POWER_ONOFF_LC \n");
			ret = sci_threshold_course(function_id, (uint16_t *)(&(p_localbuf->telecommand.LC_on_off_ctrl)), LC_ON_OFF_DATA_NUM);
			break;
		}
		case FUNCID_SET_PARA_CONTAINER:
		{
			// task_stage_set(STAGE_OTHER);
			ret = sci_threshold_course(function_id, (uint16_t *)(&(p_localbuf->cmu_mode)), THRESHOLD_CONTAINER_DATA_NUM);
			break;
		}
		case FUNCID_SET_PARA_SYSTEM_LC:
		{
			// task_stage_set(STAGE_OTHER);
			ret = sci_threshold_course(function_id, (uint16_t *)(&(p_localbuf->thresholdinfo.lc_param_setting)), sizeof(sci_lc_param_setting_t) / 2);
			break;
		}
		case FUNCID_SET_PARA_LOGIC_LC:
		{
			// task_stage_set(STAGE_OTHER);
            /* 分段获取设置 */            
			ret = sci_threshold_course(FUNCID_SET_PARA_LOGIC_LC, \
									   (uint16_t *)(&(p_localbuf->thresholdinfo.lc_logic_setting)), sizeof( sci_lc_logic_setting_t )/2);
			break;
		}
		case FUNCID_SET_PARA_FIRE:
		{
			// task_stage_set(STAGE_OTHER);
			ret = sci_threshold_course(function_id, (uint16_t *)(&(p_localbuf->thresholdinfo.ff_setting)), sizeof(sci_ff_setting_t)/2);
			break;
		}
		case FUNCID_SET_PARA_DRY:
		{
			// task_stage_set(STAGE_OTHER);
			ret = sci_threshold_course(function_id, (uint16_t *)(&(p_localbuf->thresholdinfo.dh_setting)), sizeof( sci_dh_setting_t )/2);
			break;
		}
		case FUNCID_SET_PARA_BATT_CAB_NUM:
		{
			// task_stage_set(STAGE_OTHER);
			ret = sci_threshold_course(function_id, (uint16_t *)(&(p_localbuf->batt_cab_num)), THRESHOLD_BATT_CAB_DATA_NUM);
			break;
		}
		case FUNCID_SET_FAN_STATUS:
		{
			// task_stage_set(STAGE_OTHER);
			SCI_DEBUG_LOG((int8_t *)"\n FUNCID_SET_FAN_STATUS \n");
			// fix me!!! web增加排气扇的控制后，再修改fan_status的值
			ret = sci_threshold_course(function_id, (uint16_t *)(&(p_localbuf->telecommand.EF_on_off_ctrl)), SET_FAN_ONOFF_STATUS_DATA_NUM);
			break;
		}
		case FUNCID_SET_ENEGY_CAB_ATTR:
		{
			// task_stage_set(STAGE_OTHER);
			ret = sci_threshold_course(function_id, (uint16_t *)(&(p_localbuf->ff_addr)), ENERGY_CABINET_ATTR_DATA_NUM);
			break;
		}
		default:
		{
			ret = -1;
			break;
		}
	}

	// 下发完毕切换至实时数据阶段
	task_stage_set(STAGE_GET_REALTIMEDATA);

	return ret;
}

/**
 * @brief  定时下发除湿命令处理
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
void sci_daily_duhum_handle(void)
{
	sci_time_t current_time;
	sci_task_t *p_task = NULL;
	sci_localbuf_t *p_local = NULL;
	
	p_task = &g_sci_task;
	p_local = &g_sci_localbuf;

	if(NULL == p_task || NULL == p_local)
	{
		return;
	}

	current_time = get_sci_time();

	if((current_time.hour == DEHUM_ON_HOUR_SET) && (current_time.minute == DEHUM_ON_MINUTE_SET) \
		&& (p_task->regular_dehum_finish == 0))
	{
		p_local->realtimetemp.dehumidification_on_flag = 1;			// 定时开启除湿
		p_task->last_time_dehum = current_time;						// 粗略记录上一次除湿时间
		SCI_DEBUG_LOG((int8_t *)"[sci_daily_duhum_handle] last_time_dehum: %02d:%02d\n", current_time.hour, current_time.minute);
	}

	if((current_time.hour > DEHUM_ON_HOUR_SET) || (current_time.date != p_task->last_time_dehum.date) || \
		(current_time.month != p_task->last_time_dehum.month) || (current_time.year != p_task->last_time_dehum.year))
	{
		p_task->regular_dehum_finish = 0;							// 每日重置
	}

	return;
}

/**
 * @brief  定时下发液冷預熱命令处理
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
void sci_daily_preheat_handle(void)
{
	sci_time_t current_time;
	sci_task_t *p_task = NULL;
	sci_localbuf_t *p_local = NULL;
	
	p_task = &g_sci_task;
	p_local = &g_sci_localbuf;

	if(NULL == p_task || NULL == p_local)
	{
		return;
	}

	current_time = get_sci_time();

	if((current_time.hour == PREHEAT_ON_HOUR_SET) && (current_time.minute == PREHEAT_ON_MINUTE_SET) \
		&& (p_task->regular_preheat_finish == 0))
	{
		p_local->realtimetemp.preheat_on_flag = 1;			// 定时开启除湿
		p_task->last_time_preheat = current_time;						// 粗略记录上一次除湿时间
		SCI_DEBUG_LOG((int8_t *)"[sci_daily_preheat_handle] last_time_preheat: %02d:%02d\n", current_time.hour, current_time.minute);
	}

	if((current_time.hour > PREHEAT_ON_HOUR_SET) || (current_time.date != p_task->last_time_preheat.date) || \
		(current_time.month != p_task->last_time_preheat.month) || (current_time.year != p_task->last_time_preheat.year))
	{
		p_task->regular_preheat_finish = 0;							// 每日重置
	}

	return;
}


/**
 * @brief  SCI通讯线程
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
void *thread_scicomm(void *arg)
{
	uint8_t i = 0;
	sdk_rtc_t rtc_time;

	sleep(1);							// 集装箱的sci线程,上电延时1s启动
	
	sci_task_init();
	udp_to_uart_init();
	for(i = 0; i < MAX_TIMER; i++)
    {
        operating_time_set(&rtc_time, i);
    }
	
	while(1)
	{
		sci_daily_duhum_handle();
		sci_daily_preheat_handle();

		sci_task_manage();

		usleep(500*1000);				// 500ms
	}

	pthread_exit(NULL);

}

/**
 * @brief  启动SCI通讯线程
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
void sci_task_start(void)
{
	int32_t ret = 0;
	pthread_attr_t sci_attr;
	pthread_t container_sci;
	pthread_t update_mcu2;

	// 初始化线程属性
    ret = pthread_attr_init(&sci_attr);
    if (ret)
    {
        SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] pthread_attr_init error!!! \n", __func__, __LINE__);
        return; // 线程属性初始化出错退出
    }
    
    // 设置线程属性为分离状态
    ret = pthread_attr_setdetachstate(&sci_attr, PTHREAD_CREATE_DETACHED);
    if (ret)
    {
        SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] pthread_attr_setdetachstate info_record_attr error!!! \n", __func__, __LINE__);
        return; // 线程分离属性设置出错退出
    }

	
	ret = pthread_create(&container_sci, &sci_attr, &thread_scicomm, NULL);
	if (ret)
    {
        SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] pthread_create container_sci error!!! \n", __func__, __LINE__);
        return; // 线程创建出错退出
    }

	
	ret = pthread_create(&update_mcu2, &sci_attr, &thread_update, NULL);
	if (ret)
    {
        SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] pthread_create update_mcu2 error!!! \n", __func__, __LINE__);
        return; // 线程创建出错退出
    }

	// 销毁线程属性结构,它在重新初始化之前不能重新使用
    pthread_attr_destroy(&sci_attr);

	return;
}

/**
 * @brief  打印收发帧
 * @param  [in] p_buf 需要打印的缓存首地址
 * @param  [in] len 需要打印的缓存长度
 * @param  [out] none
 * @return 0:正常	-1:异常
 */
int32_t print_frame(const uint8_t *p_buf, int32_t len)	
{
	int32_t i = 0;

	if(NULL == p_buf || len > SCI_BUF_SIZE || len < 0)
	{
		return -1;
	}

	for(i=0; i<len; i++)
	{
		SCI_DEBUG_HEX_LOG((int8_t *)"0x%02x ",p_buf[i]);
	}
	SCI_DEBUG_HEX_LOG((int8_t *)"\n");

	return 0;
}






