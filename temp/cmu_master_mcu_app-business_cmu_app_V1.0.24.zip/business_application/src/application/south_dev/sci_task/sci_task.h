/*****************************************************************************
* File Name			: sci_task.h			
* Description		: 	
* Original Author	: 
* date				: 
******************************************************************************/
#ifndef __SCI_TASK_H__
#define __SCI_TASK_H__

#include <pthread.h>
#include "data_types.h"
#include "data_shm.h"

// 从机地址
#define DEV_ADDR_CONTAINER              (0x01)          // 集装箱设备地址

// SCI串口端号
#define SDK_UART2			            (1)				// 串口端号

// 版本信息
#define SOFTVER_SIZE                    (4)             // 软件版本大小
#define HARDVER_SIZE                    (2)             // 硬件版本大小


// 协议版本号
#define SCI_PROTOCOL_SYMBOL             'V'
#define SCI_VERTION1                    (0x01)          // SCI协议版本号数值

// 消防版本信息
#define FF_SOFTVER_SIZE                 (2)             // 软件版本大小

// 命令码
#define FUNCID_HANDSHAKED               (0x1000)        /* 上电握手 */
#define FUNCID_GET_REALTIME_DATA        (0x2000)        /* 获取实时数据 */
// #define FUNCID_SEND_THRESHOLD_INFO   (0x3000)        /* 下发动作阈值 */

// 通讯监控
#define UART_INIT_RETRYCNT              (3)             // 串口初始化失败重试次数
#define CMD_RETRYCNT_MAX                (3)             // 命令重发次数max
#define COMMBREAKCNT_MAX                (60)            // 通讯异常报中断的累计次数
#define SENDERR_CNT_MAX                 (50)            // 100ms * 50 = 5s，持续异常5s发送失败

// 收发缓存
#define SCI_BUF_SIZE		            (256)           // 收发缓存区大小
#define DATA_SIZE_MAX                   (245)           // 收发缓存区数据段max
#define INDEX_DATA_HOST                 (7)             // 主机数据索引
#define INDEX_DATA_SLAVE                (6)             // 从机数据索引

// 定时除湿
#define DEHUM_ON_HOUR_SET               (8)             // 开启除湿时间——小时（0~23）
#define DEHUM_ON_MINUTE_SET             (0)             // 开启除湿时间——分钟（0~59）

// 定时预热、预冷
#define PREHEAT_ON_HOUR_SET               (8)             // 开启预冷预热时间——小时（0~23）
#define PREHEAT_ON_MINUTE_SET             (0)             // 开启预冷预热时间——分钟（0~59）

#if (0)
#define SCI_DEBUG_HEX_LOG(...) log_i((const int8_t*)__VA_ARGS__);
#else
#define SCI_DEBUG_HEX_LOG(...) {do {} while(0);}
#endif

#if (0)
#define SCI_DEBUG_LOG(...) log_i((const int8_t*)__VA_ARGS__);
#else
#define SCI_DEBUG_LOG(...) {do {} while(0);}
#endif

/**************************************************************************
*   All Structures and Common Constants
**************************************************************************/
#pragma pack(push)
#pragma pack(1)
typedef union
{
    float32_t data;
    struct
    {
        uint16_t low;
        uint16_t high;
    }apart;
    
}quad_bytes_u;
#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)
/* 版本信息-接收 */
typedef struct{

    uint8_t mcu2_app_soft_version[SOFTVER_SIZE];        // mcu2 app层软件版本号 1ASCII码 + 3数值
    uint8_t mcu2_core_soft_version[SOFTVER_SIZE];       // mcu2 core层软件版本号 1ASCII码 + 3数值
    uint8_t mcu2_hardware_version[HARDVER_SIZE];        // mcu2 硬件版本号 2数值
    uint8_t mcu2_sci_version;                           // mcu2 sci协议版本号 1数值
}sci_handack_t;
#pragma pack(pop)


#pragma pack(push)
#pragma pack(1)
/* 实时数据-接收 */
typedef struct{

    uint16_t flag;                                      // 跟随数据标志位
    uint8_t  mcu2_reset_flag;                           // mcu2初始化标记
    uint8_t  lc_type;                                   // 液冷机型：0-美的，1-空调国际，2-视源，0xFF-未知
    // 遥信----状态、告警、故障
    uint16_t dev_di_sta_info;                           // 配电柜DI-状态信息
    uint16_t dev_do_sta_info;                           // 配电柜DO-状态信息
    uint32_t ff_di_sta_info;                            // 消防DI-状态信息
    uint32_t ff_do_sta_info;                            // 消防DO-状态信息
    uint32_t lc_sta_info;                               // 液冷-状态信息
    uint16_t dry_sta_info;                              // 除湿器-状态信息
    uint16_t fan_reas_info;                             // 消防风机联动原因

    uint16_t dev_warn_info;                             // 配电仓 告警信息
    uint16_t lc_warn_info1;                             // 液冷告警信息1
    uint16_t lc_warn_info2;                             // 液冷告警信息2
    uint16_t lc_warn_info3;                             // 液冷告警信息3
    uint16_t lc_warn_info4;                             // 液冷告警信息4
    uint16_t ff_warn1_info1;                            // 消防一级告警信息1
    uint16_t ff_warn1_info2;                            // 消防一级告警信息2
    uint16_t ff_warn1_info3;                            // 消防一级告警信息3
    uint16_t ff_warn1_info4;                            // 消防一级告警信息4
    uint16_t dry_warn_info;                             // 除湿器告警信息

    uint16_t dev_fault_info;                            // 配电柜故障信息
    uint16_t lc_fault_info1;                            // 液冷故障信息1
    uint16_t lc_fault_info2;                            // 液冷故障信息2
    uint16_t lc_fault_info3;                            // 液冷故障信息3
    uint16_t lc_fault_info4;                            // 液冷故障信息4
    uint16_t ff_warn2_info1;                            // 消防二级告警信息1
    uint16_t ff_warn2_info2;                            // 消防二级告警信息2
    uint16_t ff_warn2_info3;                            // 消防二级告警信息3
    uint16_t ff_warn2_info4;                            // 消防二级告警信息4

    // 遥测---CMU
    uint16_t stop_chargedis_flag;                       // 禁止充放标志位
    uint16_t bat1_humidity;                             // 电池仓1 湿度
    uint16_t bat2_humidity;                             // 电池仓2 湿度
    uint16_t bat3_humidity;                             // 电池仓3 湿度
    uint16_t bat4_humidity;                             // 电池仓4 湿度
    uint16_t bat5_humidity;                             // 电池仓5 湿度
    uint16_t bat6_humidity;                             // 电池仓6 湿度

    int16_t  bat1_temper;                               // 电池仓1 温度
    int16_t  bat2_temper;                               // 电池仓2 温度
    int16_t  bat3_temper;                               // 电池仓3 温度
    int16_t  bat4_temper;                               // 电池仓4 温度
    int16_t  bat5_temper;                               // 电池仓5 温度
    int16_t  bat6_temper;                               // 电池仓6 温度

    // 遥测---液冷
    int16_t  lc_outdoor_temper;                         // 液冷机组 室外环境温度
    int16_t  lc_inlet_temp;                             // 液冷机组 进水温度
    int16_t  lc_outlet_temp;                            // 液冷机组 出水温度
    uint16_t lc_inlet_pressure;                         // 液冷机组 进水压力
    uint16_t lc_outlet_pressure;                        // 液冷机组 出水压力
    uint8_t lc_mode;                                    // 液冷机组 bit0-3:运行状态；bit4-7:首航逻辑运行状态
    uint8_t pump_flow_rate;                             // 液冷机组 水泵流速
    uint16_t target_temp;                               // 液冷机组 目标温度

    // 遥测---复合型传感器
    int16_t  mix_sensor1_temp;                          // 电池仓1#复合型传感器温度
    uint16_t mix_sensor1_co_ppm;                        // 电池仓1#复合型传感器CO浓度
    uint16_t mix_sensor1_pm25_ppm;                      // 电池仓1#复合型传感器pm2.5浓度
    int16_t  mix_sensor2_temp;                          // 电池仓2#复合型传感器温度
    uint16_t mix_sensor2_co_ppm;                        // 电池仓2#复合型传感器CO浓度
    uint16_t mix_sensor2_pm25_ppm;                      // 电池仓2#复合型传感器pm2.5浓度
    int16_t  mix_sensor3_temp;                          // 电池仓3#复合型传感器温度
    uint16_t mix_sensor3_co_ppm;                        // 电池仓3#复合型传感器CO浓度
    uint16_t mix_sensor3_pm25_ppm;                      // 电池仓3#复合型传感器pm2.5浓度
    int16_t  mix_sensor4_temp;                          // 电池仓4#复合型传感器温度
    uint16_t mix_sensor4_co_ppm;                        // 电池仓4#复合型传感器CO浓度
    uint16_t mix_sensor4_pm25_ppm;                      // 电池仓4#复合型传感器pm2.5浓度
    int16_t  mix_sensor5_temp;                          // 电池仓5#复合型传感器温度
    uint16_t mix_sensor5_co_ppm;                        // 电池仓5#复合型传感器CO浓度
    uint16_t mix_sensor5_pm25_ppm;                      // 电池仓5#复合型传感器pm2.5浓度
    int16_t  mix_sensor6_temp;                          // 电池仓6#复合型传感器温度
    uint16_t mix_sensor6_co_ppm;                        // 电池仓6#复合型传感器CO浓度
    uint16_t mix_sensor6_pm25_ppm;                      // 电池仓6#复合型传感器pm2.5浓度

    // 遥测---消防
    uint16_t fire_fan_start_1co;                        // 风机联动时复合型传感器1的CO 浓度值
    uint16_t fire_fan_start_2co;                        // 风机联动时复合型传感器2的CO 浓度值
    uint16_t fire_fan_start_3co;                        // 风机联动时复合型传感器3的CO 浓度值
    uint16_t fire_fan_start_4co;                        // 风机联动时复合型传感器4的CO 浓度值
    uint16_t fire_fan_start_5co;                        // 风机联动时复合型传感器5的CO 浓度值
    uint16_t fire_fan_start_6co;                        // 风机联动时复合型传感器6的CO 浓度值

    // 遥测---电表
    // quad_bytes_u voltage_a;                             // A相电压（电表数据均为临时值，更至共享内存时需调整字节序）    0.1
    // quad_bytes_u voltage_b;                             // B相电压  0.1
    // quad_bytes_u voltage_c;                             // C相电压  0.1
    // quad_bytes_u combined_active_power;                 // 组合有功功率 0.1
    // quad_bytes_u active_power_a;                        // A相有功功率  0.1
    // quad_bytes_u active_power_b;                        // B相有功功率  0.1
    // quad_bytes_u active_power_c;                        // C相有功功率  0.1
    // quad_bytes_u combined_reactive_power;               // 组合无功功率 0.1
    // quad_bytes_u reactive_power_a;                      // A相无功功率  0.1
    // quad_bytes_u reactive_power_b;                      // B相无功功率  0.1
    // quad_bytes_u reactive_power_c;                      // C相无功功率  0.1
    // quad_bytes_u freq;                                  // 频率 0.01
    // quad_bytes_u imp_ep;                                // 总正向有功能量   0.1
    // quad_bytes_u imp_ep_a;                              // A相正向有功能量  0.1
    // quad_bytes_u imp_ep_b;                              // B相正向有功能量  0.1
    // quad_bytes_u imp_ep_c;                              // C相正向有功能量  0.1

    uint16_t ff_cylinder_press;                         // 消防气瓶气压，单位：1KPa
    uint16_t reserve[31];                               // 液冷丢包率，单位： 0.01%
    uint8_t  ff_software_version[2];                    // 消防软件版本号 数值

    uint16_t lc_com_loss_rate;                          // 液冷丢包率，单位： 0.01%
    uint16_t ff_com_loss_rate;                          // 消防丢包率，单位： 0.01%
    uint16_t dh_com_loss_rate[6];                       // 除湿器丢包率，单位： 0.01%
    uint16_t io_ext_com_loss_rate[6];                   // IO拓展板丢包率，单位： 0.01%
}sci_realtimedata_t;
#pragma pack(pop)


#pragma pack(push)
#pragma pack(1)
/* 实时数据-下发 */
typedef struct{

    uint16_t flag;                                      // 跟随数据标志位
    uint16_t BCU_comm_status;                           // BCU通讯状态,bit 0:不在线;1:在线 bit0~bit11：BCU1~12通讯状态
    uint16_t cmu_status;                                // cmu系统状态
    uint16_t dehumidification_on_flag;                  // 除湿开启标志 1：开启 0：不作控制
    uint16_t max_pack[BCU_DEVICE_NUM][3];               // 每簇最高单体温度前三对应pack号                              
    int16_t max_temp[BCU_DEVICE_NUM][3];                // 每簇最高单体温度值Tmax1-3
    int16_t min_temp[BCU_DEVICE_NUM];                   // 每簇最低单体温度值Tmin1
    int16_t avr_temp[BCU_DEVICE_NUM];                   // 每簇单体温度平均值Tavr
    int16_t cluster_voltage[BCU_DEVICE_NUM];            // 簇端电压
    int16_t cluster_current[BCU_DEVICE_NUM];            // 簇端电流
    uint16_t preheat_on_flag;                           // 预热预冷开启标志 1：开启 0：不作控制

}sci_realtimetemp_t;
#pragma pack(pop)


#pragma pack(push)
#pragma pack(1)
/* 遥控数据下发 */
typedef struct{

    uint16_t LC_on_off_ctrl;                            // 液冷系统开关机 0-关机 1-开机
    uint16_t EF_on_off_ctrl;                            // 打开/关闭排气扇 0-关机 1-开机

}sci_telecommand_t;
#pragma pack(pop)


#pragma pack(push)
#pragma pack(1)
typedef struct 
{
    // 液冷系统
    uint16_t lc_type;                       			// 液冷机组型号  0:美的 1:空调国际 2:视源
    uint16_t lc_auto_mode;                    			// 手自模式 0:手动  1：自动
    uint16_t lc_mode;                         			// 模式设置 0：待机 1：制热 2：制冷 3：自循环
    uint16_t lc_ctrl_mode;                    			// 控制方式 0：出水 1：回水
    uint16_t lc_pump_rate;                    			// 水泵转速设定 单位：1%
    int16_t  lc_cooling_point;                			// 制冷温度设定 单位：0.1℃
    int16_t  lc_cooling_drop;                 			// 制冷回差 单位：0.1℃
    int16_t  lc_heating_point;                			// 制热温度设定 单位：0.1℃
    int16_t  lc_heating_drop;                           // 制热回差 单位：0.1℃
    uint16_t lc_cool_outlet_low_tmp;          			// 制冷出水低温告警设定 单位：0.1℃
    uint16_t lc_heat_outlet_hig_tmp;          			// 制热出水高温告警设定 单位：0.1℃
    uint16_t lc_outlet_pressure_high;                   // 出水压力过高设定点 单位：bar
    uint16_t lc_inlet_pressure_low;           			// 回水压力过低设定点 单位：bar
} sci_lc_param_setting_t;

typedef struct
{
    // 热管理参数
	int16_t  bat_Dts;									// 电芯设定目标温度，单位：0.1℃   
	int16_t  bat_Dtm;                         			// 电芯设定最大温度，单位：0.1℃   
	uint16_t pump_close_delay;                			// 水泵延迟关闭时间，单位：1s               
	uint16_t pre_check_tm_sec;                			// 预冷/预热启动等待时间，单位：1s  
	int16_t  bat_Tmax_max;                  			// 液冷预冷启动最大温度，单位：0.1℃
	int16_t  bat_Tmean_max;                 			// 液冷预冷启动平均温度，单位：0.1℃
	int16_t  exit_pre_cool_ret_tmp;                  	// 液冷预冷回差，单位：0.1℃
	int16_t  lc_pre_cool_tmp;                        	// 液冷预冷温度，单位：0.1℃
	int16_t  lc_pre_cool_flow;                       	// 液冷预冷流量，单位：1%
	int16_t  bat_Tmin_min;                  			// 液冷预热启动最小温度，单位：0.1℃
	int16_t  bat_Tmean_min;                 			// 液冷预热启动平均温度，单位：0.1℃
	int16_t  exit_pre_heat_ret_tmp;                  	// 液冷预热回差，单位：0.1℃
	int16_t  lc_pre_heat_tmp;                        	// 液冷预热温度，单位：0.1℃
	int16_t  lc_pre_heat_flow;                        	// 液冷预热流量，单位：1%
	int16_t  start_Tmean_Tds_val[5];            		// 制冷开机挡位区间点【5】，单位：0.1℃
	int16_t  lc_tmp[6];                   				// 制冷开机区间对应初始供液温度【6】，单位：0.1℃
	int16_t  ret_tmp;                       			// 制冷开机区间回差，单位：0.1℃
	int16_t  lc_flow;                       			// 制冷开机初始供液流量，单位：1%
	uint16_t tm_sec;                        			// 制冷开机初始运行时间，单位：1s
	int16_t  Tds_ret_tmp;                				// 达温停机 Tds 正负回差，单位：0.1℃
	uint16_t enter_valid_tm;             				// 进入达温停机 持续时间，单位：1s
	uint16_t exit_valid_tm;              				// 退出达温停机 持续时间，单位：1s
	uint16_t cool_lc_tmp_ctrl_mode;           			// 制冷模式供液温度控制方式   
	int16_t  cool_fix_lc_tmp;                 			// 制冷模式固定供液温度，单位：0.1℃   
	int16_t  min_lc_tmp;                   				// 制冷模式自适应供液温度设定最小值，单位：0.1℃
	int16_t  max_lc_tmp;                   				// 制冷模式自适应供液温度设定最大值，单位：0.1℃
	int16_t  Tmean_Tds_val[5];             				// 制冷模式自适应供液温度Tmean修正区间点【5】，单位：0.1℃
	int16_t  Tmean_Tds_adj[6];             				// 制冷模式自适应供液温度Tmean修正区间对应温度修正值【6】，单位：0.1℃
	int16_t  Tmean_Tds_ret;                				// 制冷模式自适应供液温度Tmean修正区间回差，单位：0.1℃
	uint16_t Tmean_Tds_adj_interval_tm;    				// 制冷模式自适应供液温度Tmean修正时间间隔，单位：1s
	int16_t  Tmax_Tdm_val[3];              				// 制冷模式自适应供液温度Tmax修正区间点【3】，单位：0.1℃
	int16_t  Tmax_Tdm_adj[4];              				// 制冷模式自适应供液温度Tmax修正区间对应温度修正值【4】，单位：0.1℃
	int16_t  Tmax_Tdm_ret;                 				// 制冷模式自适应供液温度Tmax修正区间回差，单位：0.1℃
	uint16_t Tmax_Tdm_adj_interval_tm;    				// 制冷模式自适应供液温度Tmax修正时间间隔，单位：1s
	uint16_t cool_lc_flow_ctrl_mode;          			// 制冷模式供液流量控制方式
	int16_t  cool_fix_lc_flow;                  		// 制冷模式固定供液流量值， 单位：%
	int16_t  Tdm_Tds_ret;                  				// 制冷模式自适应供液流量策略Tdm/Tds 回差， 根据 Tmean/ Tdm / Tds 决定 水泵控制行为 【流量调节/只加不减/100】，单位：0.1℃
	int16_t  Tmax_Tmin_val[3];             				// 制冷模式自适应供液流量修正 温差峰值区间点【3】 ，单位：0.1℃
	int16_t  Tmax_Tmin_adj[4];             				// 制冷模式自适应供液流量修正区间对应流量修正值【4】，单位：%
	int16_t  Tmax_Tmin_ret;                				// 制冷模式自适应供液流量修正 温差峰值区间回差，单位：0.1℃
	uint16_t Tmax_Tmin_adj_interval_tm;    				// 制冷模式自适应供液流量修正时间间隔，单位：1s
	int16_t  sys_standby_current;                		// 系统待机电流，单位：0.1A
    uint16_t keep_temper_enable;                        // 保温模式使能位
    uint16_t keep_temper_heating_startup_temper;        // 保温模式 加热启动温度
    uint16_t keep_temper_heating_exit_temper;           // 保温模式 加热退出温度
    uint16_t keep_temper_cooling_startup_temper;        // 保温模式 制冷启动温度
    uint16_t keep_temper_cooling_exit_temper;           // 保温模式 制冷退出温度
    uint16_t pre_cooling_forbid_charge_discharge_temper;// 预冷 禁充禁放温度
    uint16_t pre_heating_forbid_charge_discharge_temper;// 预热 禁充禁放温度
} sci_lc_logic_setting_t;

typedef struct 
{
    // 消防
    uint16_t gauge1_low_pressure_threshold;               // 消防气瓶压力表1低压阈值
    uint16_t gauge1_high_pressure_threshold;              // 消防气瓶压力表1高压阈值
    uint16_t level_1_alarm_pack_temperature;              // 消防一级报警PACK温度
    uint16_t level_1_alarm_composite_sensor_temp;         // 消防一级报警复合传感器温度
    uint16_t ff_alarm_level1_sensor_co;                   // 消防一级报警复合传感器CO浓度【工商业中无效】
    uint16_t level_1_alarm_composite_sensor_PM25;         // 消防一级报警复合传感器PM2.5浓度
    uint16_t level_2_alarm_pack_temperature;              // 消防二级报警PACK最高温度【pack】
    uint16_t level_2_alarm_composite_sensor_CO;           // 消防二级报警复合传感器CO浓度【pack】
    uint16_t ff_alarm_level2_compart_temp;                // 消防二级报警复合传感器温度【舱级】
    uint16_t ff_alarm_level2_compart_co;                  // 消防二级报警复合传感器CO浓度【舱级】
    uint16_t fire_fan_linkage_composite_sensor_CO;        // 消防风机联动复合传感器CO浓度
    uint16_t fire_fan_linkage_composite_sensor_PM25;      // 消防风机联动复合传感器PM2.5浓度【工商业中无效】
    uint16_t fire_control_words;                          // 消防控制字
    uint16_t fire_close_fan_linkage_composite_sensor_CO;  // 关闭风机联动CO浓度
    uint16_t level_2_alarm_pack_temperature2;             // 消防二级报警PACK温度次高温度【pack】        
    uint16_t reserve[2];
    uint16_t ff_backup_enable;							// 消防备份功能使能 0-关闭 1-使能
} sci_ff_setting_t;

typedef struct 
{
	// 除湿
	uint16_t dst_humidity;								// 湿度设定，单位：RH%
	uint16_t ret_humidity;								// 湿度回差，单位：RH%
} sci_dh_setting_t;

/* 定值/参数-下发 */
typedef struct{
    sci_lc_param_setting_t lc_param_setting;                // 液冷系统
    sci_lc_logic_setting_t lc_logic_setting;                // 热管理参数
    sci_ff_setting_t ff_setting;                            // 消防设置
    sci_dh_setting_t dh_setting;                            // 除湿设置
}sci_thresholdinfo_t;
#pragma pack(pop)


#pragma pack(push)
#pragma pack(1)
/* 通讯数据 */
typedef struct 
{

    uint16_t cmu_mode;              // cmu模式设置 0-运行 1-运维
    sci_handack_t handack;
    sci_telecommand_t telecommand;
    sci_thresholdinfo_t thresholdinfo;
    sci_realtimedata_t realtimedata;
    sci_realtimetemp_t realtimetemp;
    uint16_t batt_cab_num;          // 电池柜个数
    uint16_t ff_addr;               // 动环消防瓶地址
    uint16_t energy_cab_num;        // 储能柜个数
}sci_localbuf_t;
#pragma pack(pop)

// 时间结构体
#pragma pack(push)
#pragma pack(1)
typedef struct
{
    int16_t year;	// 年份，如2023
    int16_t month;	// 月份，1~12
    int16_t date;	// 日期，1~31
	int16_t hour;	// 小时，0~23
    int16_t minute;
	int16_t second;
}sci_time_t;
#pragma pack(pop)

/* 通讯阶段 */
typedef enum{

    STAGE_SHAKE_HAND = 0,           // 上电握手 
    STAGE_SEND_PARA_LC,             // 下发定值参数-液冷系统
    STAGE_SEND_TELECOMMAND,         // 下发遥控信息
    STAGE_SEND_PARA_CONTAINER,      // 下发定值参数-集装箱系统
    STAGE_SEND_PARA_LOGIC_LC,       // 下发定值参数-液冷逻辑
    STAGE_SEND_PARA_BATT_CAB_NUM,   // 下发定值参数-电池柜个数
    STAGE_SEND_PARA_FIRE,           // 下发定值参数-消防
    STAGE_SEND_PARA_DRY,            // 下发定值参数-除湿
    STAGE_SEND_ENEGY_CAB_ATTR,      // 下发定值参数-储能柜属性
    STAGE_GET_REALTIMEDATA,         // 获取实时数据
    STAGE_OTHER,                    // 其他阶段
    STAGE_MAX,                      // 最大范围

}sci_stage_e;

/* 通讯任务 */
typedef struct{

    uint16_t bcu_actual_num;        // 实际电池簇数量
    int32_t bupdate;			    // 0：非升级状态，1:处于升级状态
    // int32_t call_falg;           // 下发阈值函数调用标志
    int32_t regular_dehum_finish;   // 每日定时除湿完成标志
    int32_t para_init_finish;       // 定值参数首次下发完成标志
    int32_t course_flag;            // 交互进行标志
	int32_t devaddr;			    // 用于记录当前发送包的设备地址
	int32_t commbreak_flag;		    // 通讯中断标志 0：正常，1:通讯中断
	int32_t commerr_cnt;	        // 记录通讯异常包连续次数
	// int32_t senderr_cnt;	        // 记录发送失败次数
	// int32_t retry_cnt;		    // 单条命令重复次数
	// int32_t current_funcID;      // 用来标记当前正在执行的功能码，暂未用到
    uint8_t txbuf[SCI_BUF_SIZE];    // 发送包缓存
    uint8_t rxbuf[SCI_BUF_SIZE];    // 接收包缓存
	sci_stage_e stage;		        // 通讯任务阶段
    sci_time_t last_time_dehum;     // 上一次除湿时间
    int32_t regular_preheat_finish;   // 每日定时预冷预热完成标志
    sci_time_t last_time_preheat;     // 上一次预冷预热启动时间
    int32_t systime_sync_flag;      // 上电后系统时间同步标记

}sci_task_t;


/**************************************************************************
*   Function declaration
**************************************************************************/

/**
 * @brief  sci任务升级标志位置1
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
void update_flag_set(void);

/**
 * @brief  sci任务升级标志位清0
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
void update_flag_clear(void);

/**
 * @brief  下发定值参数
 * @param  [in]  function_id 下发数据功能码，具体见data_shm.h
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
int32_t set_constant_data(uint16_t function_id);

/**
 * @brief  获取sci通信收发互斥锁
 * @param  [out] none
 * @param  [in] none
 * @return sci通信收发互斥锁指针
 */
pthread_mutex_t *sci_mutex_get(void);

/**
 * @brief  启动SCI通讯线程
 * @param  none
 * @return none
 */ 
void sci_task_start(void);

/**
 * @brief  打印收发帧
 * @param  [in] buf 需要打印的缓存首地址
 * @param  [in] len 需要打印的缓存长度
 * @param  [out] none
 * @return 0:正常	-1:异常
 */
int32_t print_frame(const uint8_t *buf, int32_t len);


#endif

