#ifndef __UPDATE_TASK_H__
#define	__UPDATE_TASK_H__

#include "data_types.h"
#include "data_shm.h"


#define FUNCID_UPGRADE_GET_CHIPROLE  		(0x9010)                    // 获取芯片角色功能码
#define	FUNCID_TRANSFER_FILEDATA  			(0x9020)                    // 传输升级数据功能码
#define	FUNCID_TRANSFER_FILEDATA_STOP 		(0x9021)                    // 升级数据终止传输功能码
#define FUNCID_UPDATE_START_NOW             (0x9022)                    // 开始升级功能码

#define T_PATH_SIZE				            (100)                       // 路径长度
#define FIRM_DATA_RETRY_CNT                 (8)                         // 升级数据重发次数
#define FIRM_DATA_SIZE_PER_PACK             (238)                       // 每包升级数据大小

#define SIGNATURE_LEN_1K                    (1024)                      // 签名信息长度
#define SIGNATURE_VERSION                   (0x02)                      // 签名信息版本

#define FILE_TYPE_CODE_APP                  (0x00)                      // 文件类型编码-APP
#define FILE_TYPE_CODE_CORE                 (0x01)                      // 文件类型编码-CORE
#define CHIP_ROLE_CODE_MCU2                 (0x3C)                      // MCU2芯片角色编码
#define CHIP_MODEL_CODE_MCU2                ("R0")                      // MCU2芯片代号


#if (0)
#define T_DEBUG_LOG(...) log_i((const int8_t*)__VA_ARGS__);
#else
#define T_DEBUG_LOG(...) {do {} while(0);}
#endif

typedef enum{

    STAGE_FIRM_SEND_FIRM1 = 0,           // core固件下发阶段(含校验) 
    STAGE_FIRM_SEND_FIRM2,               // app固件下发阶段（含校验）
    STAGE_UPDATE_CMD_SEND,               // 升级命令下发阶段
    STAGE_DEFAULT_NONE_UPDATE,           // 不升级返回升级失败阶段

}update_stage_e;

// V02软件固件签名信息，见《软件固件签名规则》
#pragma pack(push)
#pragma pack(1)
typedef struct
{
    uint8_t         protocol_version;   // 协议版本号
    uint32_t        file_len;           // 有效文件长度 小端模式
    uint32_t        file_crc;           // 有效字节crc32
    int8_t          chip_type[30];      // 芯片型号
    int8_t          soft_version[20];   // 软件版本
    int8_t          hard_version[20];   // 硬件版本
    int8_t          project_name[30];   // 工程名称
    int8_t          creation_date[12];  // 生成日期
    uint32_t        code_start_addr;    // 程序起始地址
    uint8_t         chip_role;          // 芯片角色编码
    int8_t          chip_code[2];       // 芯片代号,如M1
    uint8_t         file_type;          // 文件类型编码
    uint8_t         reserved[127];      // 预留
}firmware_signature_t;
#pragma pack(pop)

// 升级标志共用体
#pragma pack(push)
#pragma pack(1)
typedef union
{
    struct{
        uint32_t firm1:1;
        uint32_t firm2:1;
        uint32_t rsv1:30;
    }bit;

    uint32_t total; 
}update_flag_u;
#pragma pack(pop)

// 固件专属信息结构体
#pragma pack(push)
#pragma pack(1)
typedef struct
{
    int8_t path[T_PATH_SIZE];
    int32_t index;
    firmware_signature_t signature_info;
}firmware_info_t;
#pragma pack(pop)

// 固件升级任务结构体
#pragma pack(push)
#pragma pack(1)
typedef struct
{
    // uint8_t update_fail_warn;     // Bit0:mcu1-app升级失败 Bit1:mcu1-core升级失败 Bit2:mcu2-app升级失败 Bit3:mcu2-core升级失败 Bit4-7:预留
    update_flag_u update_flag;
    update_stage_e stage;
    firmware_info_t mcu2_firm1;
    firmware_info_t mcu2_firm2;
}firmware_update_task_t;
#pragma pack(pop)


/**
 * @brief  MCU2升级线程
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
void *thread_update(void *arg);

/**
 * @brief  获取共享内存升级结构体地址
 * @param  [in] none                           
 * @param  [out] none
 * @return 升级结构体地址
 */
firmware_update_t *get_shm_update_stru(void);

/**
 * @brief  设置共享内存升级标志
 * @param  [in] index 待设置的升级标志的对象标号
 * @param  [in] value 升级标志设置值 0：升级成功/无需升级 1：正在升级 2：升级失败
 * @param  [out] none
 * @return 0：设置成功  -1：设置失败
 */
int32_t shm_update_stru_flag_set(int32_t index, uint8_t value);

#endif