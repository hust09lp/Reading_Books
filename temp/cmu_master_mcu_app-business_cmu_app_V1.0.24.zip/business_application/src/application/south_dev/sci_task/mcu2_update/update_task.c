#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>

#include "update_task.h"
#include "sci_task.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk_uart.h"
#include "sdk_fs.h"
#include "sofar_log.h"
#include "sdk_public.h"
#include "cu_sofar_sci.h"


#define FIRMWARE_NAME_KEY_MCU2          "CMU-MCU2"
#define UPDATE_FINISH               (0)                                 // 升级结束
#define UPDATE_START                (1)                                 // 开始升级
#define UPDATE_FAIL                 (2)                                 // 升级失败
#define WARN_SET                    (1)                                 // 告警设置
#define WARN_CLEAR                  (0)                                 // 告警清除

#define T_NOTDETECT_INDEX		    (-1)                                // 未检测到的默认序号
#define T_UPDATE_READUART_TIMEOUT   (500)                               // 升级时读串口超时时间

#define UPDATE_DATA_ERROR           (-255)
static firmware_update_task_t g_update_task;

static const uint32_t crc32_table[] = {
    0x00000000, 0x77073096, 0xee0e612c, 0x990951ba, 0x076dc419, 0x706af48f,
    0xe963a535, 0x9e6495a3, 0x0edb8832, 0x79dcb8a4, 0xe0d5e91e, 0x97d2d988,
    0x09b64c2b, 0x7eb17cbd, 0xe7b82d07, 0x90bf1d91, 0x1db71064, 0x6ab020f2,
    0xf3b97148, 0x84be41de, 0x1adad47d, 0x6ddde4eb, 0xf4d4b551, 0x83d385c7,
    0x136c9856, 0x646ba8c0, 0xfd62f97a, 0x8a65c9ec, 0x14015c4f, 0x63066cd9,
    0xfa0f3d63, 0x8d080df5, 0x3b6e20c8, 0x4c69105e, 0xd56041e4, 0xa2677172,
    0x3c03e4d1, 0x4b04d447, 0xd20d85fd, 0xa50ab56b, 0x35b5a8fa, 0x42b2986c,
    0xdbbbc9d6, 0xacbcf940, 0x32d86ce3, 0x45df5c75, 0xdcd60dcf, 0xabd13d59,
    0x26d930ac, 0x51de003a, 0xc8d75180, 0xbfd06116, 0x21b4f4b5, 0x56b3c423,
    0xcfba9599, 0xb8bda50f, 0x2802b89e, 0x5f058808, 0xc60cd9b2, 0xb10be924,
    0x2f6f7c87, 0x58684c11, 0xc1611dab, 0xb6662d3d, 0x76dc4190, 0x01db7106,
    0x98d220bc, 0xefd5102a, 0x71b18589, 0x06b6b51f, 0x9fbfe4a5, 0xe8b8d433,
    0x7807c9a2, 0x0f00f934, 0x9609a88e, 0xe10e9818, 0x7f6a0dbb, 0x086d3d2d,
    0x91646c97, 0xe6635c01, 0x6b6b51f4, 0x1c6c6162, 0x856530d8, 0xf262004e,
    0x6c0695ed, 0x1b01a57b, 0x8208f4c1, 0xf50fc457, 0x65b0d9c6, 0x12b7e950,
    0x8bbeb8ea, 0xfcb9887c, 0x62dd1ddf, 0x15da2d49, 0x8cd37cf3, 0xfbd44c65,
    0x4db26158, 0x3ab551ce, 0xa3bc0074, 0xd4bb30e2, 0x4adfa541, 0x3dd895d7,
    0xa4d1c46d, 0xd3d6f4fb, 0x4369e96a, 0x346ed9fc, 0xad678846, 0xda60b8d0,
    0x44042d73, 0x33031de5, 0xaa0a4c5f, 0xdd0d7cc9, 0x5005713c, 0x270241aa,
    0xbe0b1010, 0xc90c2086, 0x5768b525, 0x206f85b3, 0xb966d409, 0xce61e49f,
    0x5edef90e, 0x29d9c998, 0xb0d09822, 0xc7d7a8b4, 0x59b33d17, 0x2eb40d81,
    0xb7bd5c3b, 0xc0ba6cad, 0xedb88320, 0x9abfb3b6, 0x03b6e20c, 0x74b1d29a,
    0xead54739, 0x9dd277af, 0x04db2615, 0x73dc1683, 0xe3630b12, 0x94643b84,
    0x0d6d6a3e, 0x7a6a5aa8, 0xe40ecf0b, 0x9309ff9d, 0x0a00ae27, 0x7d079eb1,
    0xf00f9344, 0x8708a3d2, 0x1e01f268, 0x6906c2fe, 0xf762575d, 0x806567cb,
    0x196c3671, 0x6e6b06e7, 0xfed41b76, 0x89d32be0, 0x10da7a5a, 0x67dd4acc,
    0xf9b9df6f, 0x8ebeeff9, 0x17b7be43, 0x60b08ed5, 0xd6d6a3e8, 0xa1d1937e,
    0x38d8c2c4, 0x4fdff252, 0xd1bb67f1, 0xa6bc5767, 0x3fb506dd, 0x48b2364b,
    0xd80d2bda, 0xaf0a1b4c, 0x36034af6, 0x41047a60, 0xdf60efc3, 0xa867df55,
    0x316e8eef, 0x4669be79, 0xcb61b38c, 0xbc66831a, 0x256fd2a0, 0x5268e236,
    0xcc0c7795, 0xbb0b4703, 0x220216b9, 0x5505262f, 0xc5ba3bbe, 0xb2bd0b28,
    0x2bb45a92, 0x5cb36a04, 0xc2d7ffa7, 0xb5d0cf31, 0x2cd99e8b, 0x5bdeae1d,
    0x9b64c2b0, 0xec63f226, 0x756aa39c, 0x026d930a, 0x9c0906a9, 0xeb0e363f,
    0x72076785, 0x05005713, 0x95bf4a82, 0xe2b87a14, 0x7bb12bae, 0x0cb61b38,
    0x92d28e9b, 0xe5d5be0d, 0x7cdcefb7, 0x0bdbdf21, 0x86d3d2d4, 0xf1d4e242,
    0x68ddb3f8, 0x1fda836e, 0x81be16cd, 0xf6b9265b, 0x6fb077e1, 0x18b74777,
    0x88085ae6, 0xff0f6a70, 0x66063bca, 0x11010b5c, 0x8f659eff, 0xf862ae69,
    0x616bffd3, 0x166ccf45, 0xa00ae278, 0xd70dd2ee, 0x4e048354, 0x3903b3c2,
    0xa7672661, 0xd06016f7, 0x4969474d, 0x3e6e77db, 0xaed16a4a, 0xd9d65adc,
    0x40df0b66, 0x37d83bf0, 0xa9bcae53, 0xdebb9ec5, 0x47b2cf7f, 0x30b5ffe9,
    0xbdbdf21c, 0xcabac28a, 0x53b39330, 0x24b4a3a6, 0xbad03605, 0xcdd70693,
    0x54de5729, 0x23d967bf, 0xb3667a2e, 0xc4614ab8, 0x5d681b02, 0x2a6f2b94,
    0xb40bbe37, 0xc30c8ea1, 0x5a05df1b, 0x2d02ef8d
};


/**
 * @brief  标准整包crc32校验值计算
 * @param  [in] buf 待校验内容buf
 * @param  [in] len 待校验数据长度
 * @return 校验值
 */
uint32_t firmware_crc32_standard_calculate(uint8_t *buf, uint64_t len) 
{
    uint8_t *p=NULL;
    uint32_t crc = 0xFFFFFFFF;
    
    for (p=buf; len>0; ++p, --len) 
    {
        crc = (uint32_t)(crc32_table[(crc ^ *p ) & 0xFF] ^ (crc >> 8));
    }

    return ~crc;
}

/**
 * @brief  固件crc32校验值计算
 * @param  [in] buf 待校验内容buf
 * @param  [in] len 待校验数据长度
 * @return 校验值
 */
uint32_t firmware_crc32_calculate(uint8_t *buf, uint64_t len)
{
    uint8_t *p = NULL;
    uint32_t crc = 0xFFFFFFFF;

    p = buf;
    if(p == NULL)
    {
        return 0;
    }
    T_DEBUG_LOG((int8_t *)"crc32 p is ok\n");
    for (p=buf; len>0; ++p, --len) 
    {
        crc = (uint32_t)(crc32_table[(crc ^ *p ) & 0xFF] ^ (crc >> 8));
    }

    return crc;
}

/**
 * @brief  获取共享内存升级结构体地址
 * @param  [in] none                           
 * @param  [out] none
 * @return 升级结构体地址
 */
firmware_update_t *get_shm_update_stru(void)
{
	common_data_t *shm = NULL;
	shm = sdk_shm_get();
    if(NULL == shm)
    {
        return NULL;
    }

	return &(shm->update);	
}

/**
 * @brief  设置共享内存升级标志
 * @param  [in] index 待设置的升级标志的对象标号
 * @param  [in] value 升级标志设置值 0：升级成功/无需升级 1：正在升级 2：升级失败
 * @param  [out] none
 * @return 0：设置成功  -1：设置失败
 */
int32_t shm_update_stru_flag_set(int32_t index, uint8_t value)
{
    firmware_update_t *p_update = NULL;

    p_update = get_shm_update_stru();
    if(NULL == p_update || index < 0 || index > UPDATE_OBJECT_NUM)
    {
        return -1;
    }

    p_update->update_flag[index] = value;
    return 0;
}

/**
 * @brief  共享内存升级对象清零
 * @param  [in] index 升级对象待清零的对象标号
 * @param  [out] none
 * @return 0：清零成功  -1：清零失败
 */
int32_t shm_update_stru_object_clear(int32_t index)
{
    firmware_update_t *p_update = NULL;

    p_update = get_shm_update_stru();
    if(NULL == p_update || index < 0 || index > UPDATE_OBJECT_NUM)
    {
        return -1;
    }

    memset(&p_update->module_object[index][0], 0, sizeof(int8_t)*8);
    return 0;
}

/**
 * @brief  获取mcu2升级任务结构体地址
 * @param  [in] none                           
 * @param  [out] none
 * @return 升级任务结构体地址
 */
firmware_update_task_t *get_update_task_stru(void)
{
    return &g_update_task;
}

/**
 * @brief  core固件索引获取
 * @param  [in] none
 * @param  [out] none
 * @return 返回core固件索引 -1:获取失败
 */
int32_t get_firmware_core_index(void)
{
	// T_DEBUG_LOG((int8_t *)"cmu_index = %d\n",g_update_task.cmu2_firmware_index);
    firmware_update_task_t *p_task = NULL;

    p_task = get_update_task_stru();
    if(NULL == p_task)
    {
        return -1;
    }

    if(p_task->mcu2_firm1.signature_info.file_type == FILE_TYPE_CODE_CORE)
    {
        return p_task->mcu2_firm1.index;
    }
    else if(p_task->mcu2_firm2.signature_info.file_type == FILE_TYPE_CODE_CORE)
    {
        return p_task->mcu2_firm2.index;
    }
    else
    {
        return -1;
    }
}

/**
 * @brief  app固件索引获取
 * @param  [in] none
 * @param  [out] none
 * @return 返回app固件索引 -1:获取失败
 */
int32_t get_firmware_app_index(void)
{
	// T_DEBUG_LOG((int8_t *)"cmu_index = %d\n",g_update_task.cmu2_firmware_index);
	firmware_update_task_t *p_task = NULL;

    p_task = get_update_task_stru();
    if(NULL == p_task)
    {
        return -1;
    }

    if(p_task->mcu2_firm1.signature_info.file_type == FILE_TYPE_CODE_APP)
    {
        return p_task->mcu2_firm1.index;
    }
    else if(p_task->mcu2_firm2.signature_info.file_type == FILE_TYPE_CODE_APP)
    {
        return p_task->mcu2_firm2.index;
    }
    else
    {
        return -1;
    }
}

/**
 * @brief  获取文件内容
 * @param  [in] p_path 文件路径含文件名
 * @param  [out] p_size 实际读到的数据大小
 * @return p_ar：文件内容指针，用完记得释放 NULL：获取失败
 */
uint8_t *get_file_content(const int8_t *p_path, int32_t *p_size)
{
	// fs_t *p_fd = NULL;
    FILE *p_fd = NULL;
    uint8_t *p_ar = NULL;
	int32_t size = 0;
    // struct stat statbuff;

    if(NULL == p_path || NULL == p_size)
    {
        return NULL;
    }

    T_DEBUG_LOG((int8_t *)"[get file content] p_path = %s\n", p_path);
	// if(sdk_fs_access((const int8_t *)p_path, FS_F_OK) < 0)
    if(access((const char *)p_path, FS_F_OK) != 0)
	{
		T_DEBUG_LOG((int8_t *)"\nfilename:%s noexist!\n\n", p_path);
		return NULL;
	}

	// 打开文件
	// p_fd = sdk_fs_open((const int8_t *)p_path, "rb");
    p_fd = fopen((const char *)p_path, "rb");
    // perror((const int8_t *)"file open failed\n");

    if(NULL == p_fd)
    {
        T_DEBUG_LOG((int8_t *)"filename:%s noexist!\n", p_path);
        T_DEBUG_LOG((int8_t *)"Error:Open filename:%s file fail!\n", p_path);
        return NULL;
    }

	// 求得文件的大小
	// size = sdk_fs_get_size(p_fd);
    fseek(p_fd, 0, SEEK_END);
    size = ftell(p_fd);
    T_DEBUG_LOG((int8_t *)"ftell_size = %ld\n",size);

	// 申请一块能装下整个文件的空间
    p_ar = (uint8_t *)malloc((size+1)*sizeof(uint8_t));
    // p_ar = (uint8_t*)malloc((10000)*sizeof(uint8_t));
    
	if(NULL == p_ar)
    {
        fclose(p_fd);
        return NULL;
    }

	memset(p_ar, 0, (size+1)*sizeof(uint8_t));

    if(fseek(p_fd, 0, SEEK_SET) != 0)
    {
        // sdk_fs_close(p_fd);
        fclose(p_fd);
        free(p_ar);
        p_ar = NULL;

        return NULL;
    }

	//读文件
	// *p_size = sdk_fs_read(p_fd, p_ar, size);
    *p_size = fread(p_ar, 1, size, p_fd);
	
    // sdk_fs_close(p_fd);
    fclose(p_fd);

    if(*p_size <= 0)
    {
        free(p_ar);
        p_ar = NULL;
        return NULL;
    }

    T_DEBUG_LOG((int8_t *)"[get file content] read_size = %ld\n", (*p_size));
    T_DEBUG_LOG((int8_t *)"[get file content] success!\n");
    return p_ar;
}

/**
 * @brief  获取升级文件的签名信息
 * @param  [in] p_path 文件路径
 * @param  [out] p_file_sign 文件签名信息
 * @return 0:成功 -1：失败
 */
int32_t get_firmware_signature(int8_t *p_path, firmware_signature_t *p_file_sign)
{
	int8_t data[SIGNATURE_LEN_1K] = {0};
    int32_t file_size = 0;
    int32_t sign_offset = 0;
    // fs_t *p_fd = NULL;
    FILE *p_fd = NULL;
    int32_t seek_ret;

    if(NULL == p_path || NULL == p_file_sign)
    {
        return -1;
    }

    //检查文件是否存在，不存在则退出
    // if (0 != sdk_fs_access(p_path, FS_F_OK))
    if(access((const char *)p_path, FS_F_OK) < 0)
	{
		T_DEBUG_LOG((int8_t *)"filename:%s noexist!\n", p_path);
		return -1;
	}


    // p_fd = sdk_fs_open((const int8_t *)p_path, FS_READ);
    p_fd = fopen((const char *)p_path, "rb");
    if(NULL == p_fd)
    {
        return -1;
    }

    // file_size = sdk_fs_get_size(p_fd);
    seek_ret = fseek(p_fd, 0, SEEK_END);
    T_DEBUG_LOG((int8_t *)"seek_ret = %d\n",seek_ret);
    file_size = ftell(p_fd);
    T_DEBUG_LOG((int8_t *)"[get signature info]file_size = %ld\n", file_size);
    sign_offset = file_size - SIGNATURE_LEN_1K;
    T_DEBUG_LOG((int8_t *)"[get signature info]sign_offset = %ld\n", sign_offset);

    // if(sdk_fs_lseek(p_fd, sign_offset) != 0)
    if(fseek(p_fd, sign_offset, SEEK_SET) != 0)
    {
        // sdk_fs_close(p_fd);
        fclose(p_fd);
        return -1;
    }
    
    // if(sdk_fs_read(p_fd, data, SIGNATURE_LEN_1K) < 0)
    if(fread(data, 1, SIGNATURE_LEN_1K, p_fd) == 0)         // 读取失败
    {
        // sdk_fs_close(p_fd);
        fclose(p_fd);
        return -1;
    }
    
    // sdk_fs_close(p_fd);
    fclose(p_fd);
    
    memcpy(p_file_sign, data, sizeof(firmware_signature_t));
    T_DEBUG_LOG((int8_t *)"[get signature] success!\n");

    return 0;
}

/**
 * @brief  MCU2升级任务初始化
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
void update_task_init(void)
{
    memset(&g_update_task, 0, sizeof(firmware_update_task_t));
    
    return;
}

/**
 * @brief  检测mcu2是否需要升级（object对应位置有内容代表要升级）
 * @param  [in] none
 * @param  [out] none
 * @return mcu2升级标志
 */
static int32_t firmware_update_flag_check(void)
{
    int8_t i = 0;
    firmware_update_t *p_update = NULL;
    firmware_update_task_t *p_task = NULL;

    p_task = get_update_task_stru();
    p_update = get_shm_update_stru();
    
    if(NULL == p_task || NULL == p_update)
    {
        return -1; 
    }

    p_task->mcu2_firm1.index = T_NOTDETECT_INDEX;
    p_task->mcu2_firm2.index = T_NOTDETECT_INDEX;
    for(i=0; i<UPDATE_OBJECT_NUM; i++)
    {
        if(!strncmp((const char *)&p_update->module_object[i], FIRMWARE_NAME_KEY_MCU2, strlen(FIRMWARE_NAME_KEY_MCU2)))
        {
            if(p_task->mcu2_firm1.index == T_NOTDETECT_INDEX)
            {
                p_task->mcu2_firm1.index = i;
                p_task->update_flag.bit.firm1 = 1;
                // 正在升级标志置1
                shm_update_stru_flag_set(i, UPDATE_START);
                T_DEBUG_LOG((int8_t *)"find firm1 need to update!\n");
                snprintf((char *)p_task->mcu2_firm1.path, sizeof(p_task->mcu2_firm1.path), \
                        "%s%s",(const int8_t *)&p_update->root_path[0], (const int8_t *)&p_update->module_name[i]);
                T_DEBUG_LOG((int8_t *)"p_task->mcu2_firm1.path = %s\n",p_task->mcu2_firm1.path);
                // 清 
                // memset(&p_update->module_object[i][0], 0, sizeof(int8_t)*8);
            }
            else if(p_task->mcu2_firm2.index == T_NOTDETECT_INDEX)
            {
                p_task->mcu2_firm2.index = i;
                p_task->update_flag.bit.firm2 = 1;
                // 正在升级标志置1
                shm_update_stru_flag_set(i, UPDATE_START);
                T_DEBUG_LOG((int8_t *)"find firm2 need to update!\n");
                snprintf((char *)p_task->mcu2_firm2.path, sizeof(p_task->mcu2_firm2.path), \
                        "%s%s",(const int8_t *)&p_update->root_path[0], (const int8_t *)&p_update->module_name[i]);
                T_DEBUG_LOG((int8_t *)"p_task->mcu2_firm2.path = %s\n",p_task->mcu2_firm2.path);
                // 清 
                // memset(&p_update->module_object[i][0], 0, sizeof(int8_t)*8);
            }
        }
    }

    // 升级需暂停sci正常通信任务
    if(p_task->update_flag.total)
    {
        update_flag_set();
    }
    else
    {
        update_flag_clear();
    }


    T_DEBUG_LOG((int8_t *)"p_task->update_flag.bit.firm1 = %d\n",p_task->update_flag.bit.firm1);
    T_DEBUG_LOG((int8_t *)"p_task->update_flag.bit.firm2 = %d\n",p_task->update_flag.bit.firm2);
    T_DEBUG_LOG((int8_t *)"p_task->update_flag.total = %d\n",p_task->update_flag.total);
    T_DEBUG_LOG((int8_t *)"check over!\n");

    return p_task->update_flag.total;
}

/**
 * @brief  固件签名校验
 * @param  [in] p_object 固件信息结构体指针，见firmware_info_t
 * @param  [in] p_file_content 固件内容指针
 * @param  [in] read_size 固件内容大小
 * @return 校验结果 0：成功  -1：失败
 */
int32_t firmware_verification(firmware_info_t *p_object, uint8_t *p_file_content, int32_t read_size)
{
    int32_t ret = -1;
    uint32_t crc32 = 0;
    int32_t effective_len = 0;

    if(NULL == p_object || NULL == p_file_content)
    {
        return -1;
    }

    // 获取签名信息
    ret = get_firmware_signature(p_object->path, &p_object->signature_info);
    if(ret != 0)
    {
        return -1;
    }

    // 校验签名版本
    if(p_object->signature_info.protocol_version != SIGNATURE_VERSION)
    {
        T_DEBUG_LOG((int8_t *)"signature_version = %d\n", p_object->signature_info.protocol_version);
        T_DEBUG_LOG((int8_t *)"signature version is not right!\n\n");
        return -1;
    }
    T_DEBUG_LOG((int8_t *)"[signature verify]-version success!\n");

    // 校验crc
    effective_len = p_object->signature_info.file_len;
    T_DEBUG_LOG((int8_t *)"\neffective_len = %d\n", effective_len);
    crc32 = firmware_crc32_calculate(p_file_content, effective_len);
    // crc32 = firmware_crc32_standard_calculate(p_file_content, effective_len);
    
    if(p_object->signature_info.file_crc != crc32)
    {
        T_DEBUG_LOG((int8_t *)"crc32 = %x, file_sign_crc32 = %x\n", crc32, p_object->signature_info.file_crc);
        T_DEBUG_LOG((int8_t *)"signature crc32 is not right!\n\n");
        return -1;
    }
    T_DEBUG_LOG((int8_t *)"[signature verify]-crc32 success!\n");

    // 校验文件长度
    if(p_object->signature_info.file_len != effective_len)
    {
        T_DEBUG_LOG((int8_t *)"effective_len = %d, file_sign_size = %d\n", effective_len, p_object->signature_info.file_len);
        T_DEBUG_LOG((int8_t *)"signature file_len is not right!\n\n");
        return -1;
    }
    T_DEBUG_LOG((int8_t *)"[signature verify]-file length success!\n");

    // 验证芯片角色、芯片代号
    if(p_object->signature_info.chip_role != CHIP_ROLE_CODE_MCU2 || \
        0 != strncmp((const char *)p_object->signature_info.chip_code, CHIP_MODEL_CODE_MCU2, strlen(CHIP_MODEL_CODE_MCU2)))
    {
        T_DEBUG_LOG((int8_t *)"signature_chip_role = %x, signature_chip_code = %s\n", \
                p_object->signature_info.chip_role, p_object->signature_info.chip_code);
        T_DEBUG_LOG((int8_t *)"signature chip is not rigth!\n\n");
        return -1;
    }
    T_DEBUG_LOG((int8_t *)"[signature verify]-chip role and model code success!\n");

    return 0;
}

/**
 * @brief  打包结构体赋值
 * @param  [out] p_sofar 打包结构体
 * @param  [in] function_id 功能码
 * @param  [in] data_len 数据段长度
 * @param  [in] p_data 数据段首地址
 * @return none
 */
void cu_stru_pack(cu_sofar_sci_t *p_sofar, uint16_t function_id, uint16_t data_len, uint8_t *p_data)
{
    if(NULL == p_sofar || NULL == p_data || data_len > SCI_BUF_SIZE)
    {
        return;
    }

    p_sofar->version = SCI_VERTION1;
    p_sofar->dev_addr = DEV_ADDR_CONTAINER;
    p_sofar->function_id = function_id;
    p_sofar->data_len = data_len;
    p_sofar->p_data = p_data;
    
    return;
}

/**
 * @brief  发送指令
 * @param  [in] dev_addr 从机地址
 * @param  [in] function_id 功能码                               
 * @param  [in] data_len 数据段长度
 * @param  [in] p_data 数据段首地址
 * @param  [out] none
 * @return none
 */
void firmware_update_send_command(uint16_t function_id, uint16_t data_len, uint8_t *p_data)
{ 
    uint8_t txbuf[SCI_BUF_SIZE] = {0};
    int16_t send_len = 0;
    int32_t ret = -1;
    cu_sofar_sci_t sci_pack_tx;

    if(NULL == p_data)
    {
        return;
    }
    
    data_len = (data_len > SCI_BUF_SIZE) ? SCI_BUF_SIZE : data_len;

    cu_stru_pack(&sci_pack_tx, function_id, data_len, p_data);
    memset(txbuf, 0, SCI_BUF_SIZE);

    // 打包
    send_len = cu_sofar_sci_pack(&sci_pack_tx, txbuf, SCI_BUF_SIZE);
    T_DEBUG_LOG((int8_t *)"send_len = %d\n", send_len);
    //T_DEBUG_LOG((int8_t *)"sci_pack_tx.function_id = %x\n",sci_pack_tx.function_id);

    // 发送
    ret = sdk_uart_write(SDK_UART2, txbuf, send_len);
    
    if(ret < 0)
    {
        T_DEBUG_LOG((int8_t *)"update chiprole cmd send fail!\n");
    }
    else
    {
        T_DEBUG_LOG((int8_t *)"update send_frame: ");
        print_frame(txbuf, send_len);
        T_DEBUG_LOG((int8_t *)"\n");
    }

    return;
}

/**
 * @brief  读取应答数据
 * @param  [in] time_out_ms 读串口超时时间
 * @param  [in] buf_len 接收缓存大小
 * @param  [in] function_id 功能码                              
 * @param  [out] ack_data_buffer 应答数据段首地址
 * @return 读取结果 >=0：数据段长度  -1：失败
 */
int32_t firmware_update_read_ackdata(int32_t time_out_ms, uint8_t *ack_data_buffer, uint8_t buf_len, uint16_t function_id)
{
    uint8_t rxbuf[SCI_BUF_SIZE] = {0};
    int32_t ret = -1;
    int32_t valid_data_len = 0;
    int32_t recv_len = 0;
    cu_sofar_sci_t sci_pack_rx;

    if(NULL == ack_data_buffer)
    {
        return -1;
    }
    
    cu_stru_pack(&sci_pack_rx, function_id, SCI_BUF_SIZE, &rxbuf[INDEX_DATA_SLAVE]);
    
    // 接收
    memset(rxbuf, 0, SCI_BUF_SIZE);
    ret = sdk_uart_read(SDK_UART2, rxbuf, SCI_BUF_SIZE, time_out_ms);
    T_DEBUG_LOG((int8_t *)"recv_len = %d\n", ret);

    if(ret < 0)
    {
        T_DEBUG_LOG((int8_t *)"update read fail!\n");
        return -1;
    }

    recv_len = (ret > SCI_BUF_SIZE)?SCI_BUF_SIZE:ret;
    T_DEBUG_LOG((int8_t *)"update recv_frame: ");
    print_frame(rxbuf, recv_len);

    // 框架解包
    ret = cu_sofar_sci_unpack(DEV_ADDR_CONTAINER, function_id, &sci_pack_rx, rxbuf, recv_len);
    if(ret != 0)
    {
        T_DEBUG_LOG((int8_t *)"unpack fail and ret = %d!\n",ret);
        return -1;
    }

    valid_data_len = rxbuf[3]-2;
    // 限幅
    valid_data_len = (int32_t)((valid_data_len>buf_len)?buf_len:valid_data_len);

    memcpy(ack_data_buffer, &rxbuf[INDEX_DATA_SLAVE], valid_data_len);
    T_DEBUG_LOG((int8_t *)"update recv ok\n");
    
    return valid_data_len;
}

/**
 * @brief  从机响应下发升级包数据验证
 * @param  [in] tx_pack_num 下发升级包包号
 * @param  [in] rx_pack_num  响应升级包包号
 * @param  [out] none
 * @return 验证结果 0：成功  -1：失败
 */
int32_t firmware_update_response_check(uint16_t tx_pack_num, uint16_t rx_pack_num)
{
    T_DEBUG_LOG((int8_t *)"[response check] tx_pack_num = %d, rx_pack_num = %d\n", \
                            tx_pack_num, rx_pack_num);

    if(tx_pack_num != rx_pack_num)
    {
        T_DEBUG_LOG((int8_t *)"[response check] pack_num not constent! and will return -1\n");
        return -1;
    }

    return 0;
}

/**
 * @brief  获取mcu2应答芯片角色
 * @param  [in] retry_times 失败重试次数                               
 * @param  [out] p_role 芯片角色
 * @return 获取结果 0：成功  -1：失败
 */
int32_t firmware_update_chiprole_get(uint8_t *p_role, uint8_t retry_times)
{
    uint8_t data_buf[DATA_SIZE_MAX] = {0};
    uint16_t data_len = 0;
    int32_t ret = -1;
    pthread_mutex_t *p_mutex = NULL;

    p_mutex = sci_mutex_get();

    while(retry_times)
    {
        // 发送指令
        pthread_mutex_lock(p_mutex);
        firmware_update_send_command(FUNCID_UPGRADE_GET_CHIPROLE, data_len, data_buf);

        // 延时500ms
        usleep(500000);

        // 获取应答结果
        ret = firmware_update_read_ackdata(T_UPDATE_READUART_TIMEOUT, p_role, sizeof(uint8_t), FUNCID_UPGRADE_GET_CHIPROLE);
        pthread_mutex_unlock(p_mutex);

        if(ret > 0)
        {
            return 0;
        }

        // 接收失败重试
        retry_times--;
        usleep(20000);
    }

    return -1;
}

/**
 * @brief  下发升级包数据
 * @param  [in] p_txdata 发送数据段内容指针
 * @param  [in] txdata_len 发送数据段长度
 * @param  [out] p_rxdata 接收数据段指针                               
 * @param  [in] rxdata_size 接收数据段缓存大小
 * @param  [in] retry_times 重试次数
 * @return 下发结果 0：成功  -1：失败
 */
int32_t firmware_update_send_firm_data(uint8_t *p_txdata, uint16_t txdata_len, uint8_t *p_rxdata, uint16_t rxdata_size, uint8_t retry_times)
{
    uint16_t tx_pack_num = 0;                       // 发送升级包包号
    uint16_t rx_pack_num = 0;                       // 响应升级包包号
    int32_t ret = 0;
    pthread_mutex_t *p_mutex = NULL;

    p_mutex = sci_mutex_get();

    while (retry_times)
    {
        // 发送升级数据
        T_DEBUG_LOG((int8_t *)"\n\nnow start send firmware pack!!!!!!!!\n");
        pthread_mutex_lock(p_mutex);
        firmware_update_send_command(FUNCID_TRANSFER_FILEDATA, txdata_len, p_txdata);

        // 延时20ms
        usleep(20000);

        // 获取应答结果
        ret = firmware_update_read_ackdata(T_UPDATE_READUART_TIMEOUT, p_rxdata, rxdata_size, FUNCID_TRANSFER_FILEDATA);
        pthread_mutex_unlock(p_mutex);

        // 框架解包成功且响应2Bytes数据
        if(ret >= 2)
        {
            tx_pack_num = (uint16_t)((p_txdata[0] << 8) | (p_txdata[1] << 0));
            rx_pack_num = (uint16_t)((p_rxdata[0] << 8) | (p_rxdata[1] << 0));
            if(0 == firmware_update_response_check(tx_pack_num, rx_pack_num))
            {
                // 解包成功，可进行下一包
                T_DEBUG_LOG((int8_t *)"unpack success! can into next pack!\n");
                return 0;
            }  
        }
        // 接收失败重试
        retry_times--;
        usleep(20000);
    }

    return -1;
}

/**
 * @brief  下发文件终止传输命令（已经传完）
 * @param  [in] retry_times 重试次数
 * @param  [out] none
 * @return 下发结果 0：成功  -1：失败
 */
int32_t firmware_update_deliver_ok_command(uint8_t retry_times)
{
    uint8_t txdata_buf[DATA_SIZE_MAX] = {0};
    uint8_t rxdata_buf[DATA_SIZE_MAX] = {0};
    uint16_t txdata_len = 0;
    int32_t ret = 0;
    pthread_mutex_t *p_mutex = NULL;

    p_mutex = sci_mutex_get();

    while(retry_times)
    {
        // 发送指令
        pthread_mutex_lock(p_mutex);
        firmware_update_send_command(FUNCID_TRANSFER_FILEDATA_STOP, txdata_len, txdata_buf);

        // 延时3s等待写flash
        sleep(3);

        // 获取应答结果
        ret = firmware_update_read_ackdata(T_UPDATE_READUART_TIMEOUT, rxdata_buf, sizeof(rxdata_buf), FUNCID_TRANSFER_FILEDATA_STOP);
        pthread_mutex_unlock(p_mutex);

        if(ret > 0)
        {
            if(rxdata_buf[0] == 1)
            {
                T_DEBUG_LOG((int8_t *)"deliver ok\n");
                return 0;
            } 
        }

        // 接收失败重试
        retry_times--;
        usleep(20000);
    }

    T_DEBUG_LOG((int8_t *)"deliver fail\n");
    return -1;

}

/**
 * @brief  下发开始升级命令
 * @param  [in] retry_times 重试次数
 * @param  [out] none
 * @return 下发结果 0：成功  -1：失败
 */
int32_t firmware_update_start_update_command(uint8_t retry_times)
{
    uint8_t txdata_buf[DATA_SIZE_MAX] = {0};
    uint8_t rxdata_buf[DATA_SIZE_MAX] = {0};
    uint16_t txdata_len = 0;
    int32_t ret = 0;
    pthread_mutex_t *p_mutex = NULL;

    p_mutex = sci_mutex_get();

    while(retry_times)
    {
        // 发送指令
        pthread_mutex_lock(p_mutex);
        firmware_update_send_command(FUNCID_UPDATE_START_NOW, txdata_len, txdata_buf);

        // 延时5ms
        usleep(5000);

        // 获取应答结果
        ret = firmware_update_read_ackdata(T_UPDATE_READUART_TIMEOUT, rxdata_buf, sizeof(rxdata_buf), FUNCID_UPDATE_START_NOW);
        pthread_mutex_unlock(p_mutex);

        if(ret > 0)
        {
            if(rxdata_buf[0] == 1)
            {
                return 0;
            } 
        }

        // 接收失败重试
        retry_times--;
        usleep(20000);
    }

    T_DEBUG_LOG((int8_t *)"cmd--start update ack/read fail!\n");
    return -1;

}

/**
 * @brief  升级失败告警更新至共享内存
 * @param  [in] chip_role 芯片角色
 * @param  [in] file_type 文件类型
 * @param  [in] is_warn 是否告警 1：是  0：否
 * @param  [out] none 
 * @return 更新结果 0：成功  -1：失败
 */
int32_t firmware_update_fail_warn_to_shm(uint8_t chip_role, uint8_t file_type, uint8_t is_warn)
{
    common_data_t *shm = NULL;

    shm = sdk_shm_get();
    if(NULL == shm)
    {
        return -1;
    }

    if(chip_role == CHIP_ROLE_CODE_MCU2)
    {
        if(file_type == FILE_TYPE_CODE_APP)
        {
            if(is_warn)
            {
                shm->telematic_data.CMU_system_fault_info[1] |= (uint8_t)(1 << 2);
            }
            else
            {
                shm->telematic_data.CMU_system_fault_info[1] &= (uint8_t)(~(1 << 2));
            }
            
        }
        else if(file_type == FILE_TYPE_CODE_CORE)
        {
            if(is_warn)
            {
                shm->telematic_data.CMU_system_fault_info[1] |= (uint8_t)(1 << 3);
            }
            else
            {
                shm->telematic_data.CMU_system_fault_info[1] &= (uint8_t)(~(1 << 3));
            }   
        }
    }

    return 0;
}

/**
 * @brief  更新升级进度至共享内存
 * @param  [in] dev_addr 从机地址
 * @param  [in] temp_pace 升级进度
 * @param  [in] p_object 传入对应固件指针
 * @param  [out] none 
 * @return 更新结果 0：成功  -1：失败
 */
int32_t firmware_update_progress_to_shm(uint8_t dev_addr, uint32_t temp_pace, firmware_info_t *p_object)
{
	int32_t object_index = 0;
	firmware_update_t *p_update = get_shm_update_stru();

    if(NULL == p_object)
    {
        return -1;
    }

    object_index = p_object->index;
    T_DEBUG_LOG((int8_t *)"[process update to shm] index get ok!\n");

	if(dev_addr == DEV_ADDR_CONTAINER)
	{
		p_update->module_percent[object_index] = temp_pace;
	}
	else
	{
		T_DEBUG_LOG((int8_t *)"firmware_update_update_shm_progress dev_addr error, dev_addr:%d\n", dev_addr);
        return -1;
	}
    T_DEBUG_LOG((int8_t *)"[process update to shm] tem_pace update ok temp_pace = %d!\n", temp_pace);
	
    return 0;
}

/**
 * @brief  固件数据打包下发管理
 * @param  [in] p_file_content 升级文件内容指针
 * @param  [in] read_size 升级文件大小
 * @param  [in] p_object 传入对应固件指针
 * @param  [out] none 
 * @return 从机接收结果 0：成功  -1：失败
 */
int32_t firmware_update_data_pack_manage(uint8_t *p_file_content, int32_t read_size, firmware_info_t *p_object)
{
    // uint8_t dev_addr = DEV_ADDR_CONTAINER;
    uint8_t delivery_finished = 0;                  // 0-未结束 1-最后一包 2-已发完
    uint8_t tx_databuf[DATA_SIZE_MAX] = {0};        // 有效数据发送缓存
    uint8_t rx_databuf[DATA_SIZE_MAX] = {0};        // 有效数据接收缓存
    int32_t ret = 0;
    int32_t data_remain = 0;                        // 剩余字节数
    int32_t offset = 0;                             // 起始偏移
    uint32_t pack_bytes = 0;                        // 打包字节数
    uint32_t total_packnum = 0;                     // 总包数
    uint32_t pack_index = 0;                        // 当前包包序号
    uint32_t ok_packnum = 0;                        // 已成功发送包数
    uint32_t temp_pace = 0;                         // 下发进度

    if(NULL == p_file_content || NULL == p_object)
    {
        return -1;
    }

    data_remain = read_size;
    total_packnum = data_remain/FIRM_DATA_SIZE_PER_PACK + 1;        
    pack_index = 1;

    while(1)
    {
        temp_pace = (100 * pack_index) / total_packnum;
        if(temp_pace > 99)
        {
            temp_pace = 100;
        }
        printf("\n\n\n>>>2、Transfer upgrade data: temp_pace:%d, ok_packnum:%d, total_packnum:%d, pack_index:%d \n", \
                            temp_pace, ok_packnum, total_packnum, pack_index);
        firmware_update_progress_to_shm(DEV_ADDR_CONTAINER, temp_pace, p_object);
        // 文件终止
        if(1 == delivery_finished)
        {
            delivery_finished = 2;
            pack_bytes = 0;

            // 下发文件终止命令
            ret = firmware_update_deliver_ok_command(FIRM_DATA_RETRY_CNT);
            if(0 == ret)
            {
                return 0;
            }
            else
            {
                return -1;
            }

        }
        else
        {
            if(data_remain < FIRM_DATA_SIZE_PER_PACK)
            {
                pack_bytes = data_remain;
                delivery_finished = 1;          // 最后一组数据
                if(0 == pack_bytes)
                {
                    continue;
                }
            }
            else
            {
                pack_bytes = FIRM_DATA_SIZE_PER_PACK;
            }

            memset(tx_databuf, 0, sizeof(tx_databuf));
            // 发送数据打包
            tx_databuf[0] = (uint8_t)((pack_index >> 8) & 0xFF);
            tx_databuf[1] = (uint8_t)((pack_index >> 0) & 0xFF);
            memcpy(&tx_databuf[2], &p_file_content[offset], pack_bytes);

            ret = firmware_update_send_firm_data(tx_databuf, pack_bytes+2, rx_databuf, sizeof(rx_databuf), FIRM_DATA_RETRY_CNT);
            if(0 == ret)
            {
                offset += pack_bytes;
                data_remain -= pack_bytes;
                if(pack_index < total_packnum)
                {
                    pack_index++;
                    ok_packnum++;
                }
            }
            else
            {
                T_DEBUG_LOG((int8_t *)"Transfer is abnormal, upgrade is aborted and exited!\n");
                return -1;      // 升级失败
            }
        }

        usleep(10000);
    }

}

/**
 * @brief  升级动作
 * @param  [in] p_object 传入对应固件指针
 * @param  [out] none 
 * @return 升级结果 0：成功  -1：失败
 */
int32_t firmware_update_action(firmware_info_t *p_object)
{
    uint8_t chip_role = 0;
    uint8_t *p_file_content = NULL;
    int32_t ret = 0;
    int32_t read_size = 0;
    

    if(NULL == p_object)
    {
        goto err_prog;
    }

    // 1、获取固件内容
    p_file_content = get_file_content(p_object->path, &read_size);
    if(NULL == p_file_content)
    {
        ret = -1;
        goto err_prog;
    }

    // 2、校验升级包
    ret = firmware_verification(p_object, p_file_content, read_size);
    if(ret != 0)
    {
        goto err_prog;
    }

    // 3、获取芯片角色--升级前交互
    ret = firmware_update_chiprole_get(&chip_role, CMD_RETRYCNT_MAX);
    if(ret != 0)
    {
        goto err_prog;
    }

    usleep(20000);

    // 4、下发升级数据
    ret = firmware_update_data_pack_manage(p_file_content, read_size, p_object);
    if(ret != 0)
    {
        ret = UPDATE_DATA_ERROR;
        goto err_prog;
    }

    if(p_file_content != NULL)
	{
	    free(p_file_content);
	    p_file_content = NULL;
	}
    // 升级成功，置标志位  下发完9022才置，此处不置
    // shm_update_stru_flag_set(p_object->index, UPDATE_FINISH);

    return 0;

err_prog:
    if(p_file_content != NULL)
	{
	    free(p_file_content);
	    p_file_content = NULL;
	}
    // 升级失败，置标志位且告警  下发完9022才置，此处不置
    // shm_update_stru_flag_set(p_object->index, UPDATE_FAIL);
    firmware_update_fail_warn_to_shm(p_object->signature_info.chip_role, p_object->signature_info.file_type, WARN_SET);  
    return ret;
}

/**
 * @brief  开始升级mcu2
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
int32_t firmware_update_start(void)
{
    int32_t ret1 = -1;
    int32_t ret2 = -1;
    int32_t ret3 = -1;
    firmware_update_task_t *p_task = NULL;

    p_task = get_update_task_stru();
    
    if(NULL == p_task)
    {
        return -1; 
    }
    while(1)
    {
        switch(p_task->stage)
        {
            case STAGE_FIRM_SEND_FIRM1:
            {
                T_DEBUG_LOG((int8_t *)"\n\n******》》this is 1 stage!\n");
                if(p_task->update_flag.bit.firm1)
                {
                    ret1 = firmware_update_action(&p_task->mcu2_firm1);
                    // 清共享内存升级对象
                    shm_update_stru_object_clear(p_task->mcu2_firm1.index); 
                    if(ret1 == UPDATE_DATA_ERROR)  
                    {
                        shm_update_stru_object_clear(p_task->mcu2_firm2.index); 
                        shm_update_stru_flag_set(p_task->mcu2_firm1.index, UPDATE_FAIL);
                        return -1;
                    }
                }
                p_task->stage = STAGE_FIRM_SEND_FIRM2;
                break;
            }
            case STAGE_FIRM_SEND_FIRM2:
            {
                T_DEBUG_LOG((int8_t *)"\n\n******》》this is 2 stage!\n");
                if(p_task->update_flag.bit.firm2)
                {
                    ret2 = firmware_update_action(&p_task->mcu2_firm2);
                    // 清共享内存升级对象
                    shm_update_stru_object_clear(p_task->mcu2_firm2.index);
                    if(ret2 == UPDATE_DATA_ERROR)  
                    {
                        shm_update_stru_object_clear(p_task->mcu2_firm1.index); 
                        shm_update_stru_flag_set(p_task->mcu2_firm2.index, UPDATE_FAIL);
                        return -1;
                    }
                }
                // 只要有一个固件成功下发就发送升级命令
                if(0 == ret1 || 0 == ret2)
                {
                    p_task->stage = STAGE_UPDATE_CMD_SEND;
                }
                else
                {
                    p_task->stage = STAGE_DEFAULT_NONE_UPDATE;
                }
                break;
            }
            case STAGE_UPDATE_CMD_SEND:
            {
                T_DEBUG_LOG((int8_t *)"\n\n******》》this is 3 stage!\n");
                ret3 = firmware_update_start_update_command(CMD_RETRYCNT_MAX);
                
                p_task->stage = STAGE_DEFAULT_NONE_UPDATE;
                break;
            }
            case STAGE_DEFAULT_NONE_UPDATE:
            {
                T_DEBUG_LOG((int8_t *)"\n\n******》》this is 4 stage!\n");
                // 升级成功，置标志位
                if(ret1 == 0)
                {
                    shm_update_stru_flag_set(p_task->mcu2_firm1.index, UPDATE_FINISH);
                }
                else if(p_task->update_flag.bit.firm1)
                {
                    shm_update_stru_flag_set(p_task->mcu2_firm1.index, UPDATE_FAIL);
                }
                if(ret2 == 0)
                {
                    shm_update_stru_flag_set(p_task->mcu2_firm2.index, UPDATE_FINISH);
                }
                else if(p_task->update_flag.bit.firm2)
                {
                    shm_update_stru_flag_set(p_task->mcu2_firm2.index, UPDATE_FAIL);
                } 
                
                if(0 == ret3)
                {
                    return 0;
                }

                return -1;
            }
        }

        sleep(1);
    }
    
}

/**
 * @brief  升级处理
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void firmware_update_handle(void)
{
    int32_t ret = 0;
    firmware_update_task_t *p_task = NULL;
    firmware_update_t *p_update = NULL;

    p_task = get_update_task_stru();
    p_update = get_shm_update_stru();


    if(NULL == p_task || NULL == p_update)
    {
        return;
    }

    // 清上一次告警(按需清除)
    if((p_task->update_flag.bit.firm1 == 1) && (p_task->mcu2_firm1.index != T_NOTDETECT_INDEX))
    {
        firmware_update_fail_warn_to_shm(p_update->chip_role[p_task->mcu2_firm1.index], p_update->file_type[p_task->mcu2_firm1.index], WARN_CLEAR);
    }
    if((p_task->update_flag.bit.firm2 == 1) && (p_task->mcu2_firm2.index != T_NOTDETECT_INDEX))
    {
        firmware_update_fail_warn_to_shm(p_update->chip_role[p_task->mcu2_firm2.index], p_update->file_type[p_task->mcu2_firm2.index], WARN_CLEAR);
    }
    // firmware_update_fail_warn_to_shm(CHIP_ROLE_CODE_MCU2, FILE_TYPE_CODE_APP, WARN_CLEAR);
    // firmware_update_fail_warn_to_shm(CHIP_ROLE_CODE_MCU2, FILE_TYPE_CODE_CORE, WARN_CLEAR);

    // 开始升级mcu2
    ret = firmware_update_start();

    if(0 == ret)
    {
        T_DEBUG_LOG((int8_t *)"This upgrade was a complete success!\n");
    }
    else
    {
        T_DEBUG_LOG((int8_t *)"This upgrade final result is fail!\n");
    }

    // 清任务缓存
    memset(p_task, 0, sizeof(firmware_update_task_t));
    sleep(1);
    // 清SCI升级标志
    update_flag_clear();

    return;
}

/**
 * @brief  MCU2升级线程
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
void *thread_update(void *arg)
{
    sleep(2);             // 待sci先启动

    update_task_init();
    // test_shm_init();
    T_DEBUG_LOG((int8_t *)"we come into update-task!\n");

	while(1)
	{

		if(firmware_update_flag_check())
		{
            T_DEBUG_LOG((int8_t *)"Detected need update, enter to update handle!\n");
			firmware_update_handle();
		}

		sleep(1);
	}

	pthread_exit(NULL);
}

#if 0    // 在SCI任务开启时一起创建
/**
 * @brief  启动MCU2升级通讯线程
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
void update_task_start(void)
{
	pthread_t update_mcu2;
	pthread_create(&update_mcu2, NULL, &thread_update, NULL);
}
#endif

// 测试代码
void test_shm_init(void)
{
    T_DEBUG_LOG((int8_t *)"this is test_shm init\n");
	common_data_t *shm = NULL;

	shm = sdk_shm_get();

    if(NULL == shm)
    {
        return;
    }

    memset(&shm->update, 0, sizeof(firmware_update_t));

    strncpy((char*)shm->update.module_object[0], "CMU-MCU2", 8);       
    strncpy((char*)shm->update.module_object[1], "CMU-MCU2", 8);       
    strncpy((char*)shm->update.module_name[0], "mcu2_app.bin", 12);    
    strncpy((char*)shm->update.module_name[1], "mcu2_core.bin", 13);   
    strncpy((char*)shm->update.root_path, "/tmp/upload/", 12);

	return;
}
