/**-------------------------------------------------------------
 *                      本机低功耗管理模块 
 *-------------------------------------------------------------*/  
#ifndef _LOW_POWER_TASK_H_
#define _LOW_POWER_TASK_H_

#include "sofar_type.h"


/**
 * @brief  低功耗管理初始化，根据用户功率功率进行状态维护
 * @param  [in] 无
 * @return SF_Ok：成功  非SF_Ok：失败
 * @note   
 */
sf_ret_t low_power_manage_init( void );

/**
 * @brief  设置空载切休眠的时间
 * @param  [in] idle_tm_hour：空载切休眠的时间，单位：1小时
 * @return SF_Ok：成功  非SF_Ok：失败
 * @note   
 */
sf_ret_t low_power_set_idle_to_sleep_mode_time( uint16_t idle_tm_hour );

/**
 * @brief  设置休眠转关机的时间
 * @param  [in] idle_tm_hour：休眠转关机的时间，单位：1小时
 * @return SF_Ok：成功  非SF_Ok：失败
 * @note   
 */
sf_ret_t low_power_set_sleep_to_power_off_time( uint16_t idle_tm_hour );

/**
 * @brief  设置休眠转关机使能功能
 * @param  [in] enable：使能标志
 * @return SF_Ok：成功  非SF_Ok：失败
 * @note   
 */
sf_ret_t low_power_set_sleep_to_power_off_enable( uint16_t enable );

/**
 * @brief  设置空载转休眠使能功能
 * @param  [in] enable：使能标志
 * @return SF_Ok：成功  非SF_Ok：失败
 * @note   
 */
sf_ret_t low_power_set_idle_to_sleep_enable( uint16_t enable );

/**
 * @brief  同步用户设置 开关机状态
 * @param  [in] usr_power_sta_on： 用户开关机状态
 * @return SF_Ok：成功  非SF_Ok：失败
 * @note   
 */
sf_ret_t low_power_task_set_usr_power_sta( bool usr_power_sta_on );


#endif
