#include "sdk_shm.h"
#include "sdk_log.h"
#include "sofar_type.h"
#include "pcs_fun_interface.h"
#include "user_timer.h"
#include "param_record_task.h"
#include "op_log.h"
#include "sdk_shm.h"
#include "cmu_sys_state.h"
#include "low_power_task.h"

#include <pthread.h>
#include <string.h>
#include <unistd.h>

#define LOW_POWER_TASK_RELEASE               1

#if (LOW_POWER_TASK_RELEASE == 1)
#define HOUR_TO_MS( hours )                 ( (hours) * 3600 * 1000 )
#else           
#define HOUR_TO_MS( hours )                 ( (hours) * 30 * 1000 )
#endif

#define DAY_TO_HOUR( days )                 ( (days ) * 24 )

#define TRIG_STANDBY_TM_HOUR_DEF            8
#define TRIG_STANDBY_TM_HOUR_MIN            4
#define TRIG_STANDBY_TM_HOUR_MAX            12

#define TRIG_POW_OFF_TM_DAY_DEF             1
#define TRIG_POW_OFF_TM_DAY_MIN             1
#define TRIG_POW_OFF_TM_DAY_MAX             7

#if (1)
// #define LOW_POWER_LOG_D(...) do{ /* log_d( "[%s]", __FILE__);  */printf(__VA_ARGS__); } while(0)
#define LOW_POWER_LOG_D(...) do{ printf( "[%s]", __FILE__);  printf((const char*)__VA_ARGS__);  printf("\r\n"); } while(0)
#else
#define LOW_POWER_LOG_D(...) {do {} while(0);}
#endif

typedef enum {
    LOW_POW_STA_NORMAL ,                     // 正常状态
    LOW_POW_STA_SLEEP,                      // 空载休眠状态
    LOW_POW_STA_POWER_OFF,                  // 空载关机状态
} low_pow_sta_e;

static int16_t         g_user_setting_power = 0;             // 正放负充，单位 0.1KW
static user_timer_hd   trig_sleep_timer   = NULL;            // 空载触发休眠定时器   
static user_timer_hd   trig_pow_off_timer = NULL;            // 空载触发关机定时器               
static user_timer_hd   csu_monitor_timer  = NULL;            // csu数据监控定时器

static void _low_power_all_timers_refresh( void );

static void _low_power_all_timers_refresh( void )
{
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); 

    uint16_t idle_to_power_tm_hours = 0;

    if ( p_para_data->idle_to_sleep_enable )
    {
        idle_to_power_tm_hours = p_para_data->idle_to_sleep_tm;
        user_timer_set_timeout( trig_sleep_timer  , HOUR_TO_MS( p_para_data->idle_to_sleep_tm ), SF_FALSE );
    }

    if ( p_para_data->sleep_to_pow_off_enable )
    {
        idle_to_power_tm_hours += p_para_data->sleep_to_pow_off_tm;
        user_timer_set_timeout( trig_pow_off_timer, HOUR_TO_MS( idle_to_power_tm_hours ), SF_FALSE );
    }
    
    user_timer_refresh( trig_sleep_timer );
    user_timer_refresh( trig_pow_off_timer );
}

/**
 * @brief  设置空载切休眠的时间
 * @param  [in] idle_tm_hour：空载切休眠的时间，单位：1小时
 * @return SF_Ok：成功  非SF_Ok：失败
 * @note   
 */
sf_ret_t low_power_set_idle_to_sleep_mode_time( uint16_t idle_tm_hour )
{
    LOW_POWER_LOG_D("%s ,timer: %d hours\r\n", __FUNCTION__, idle_tm_hour);

    #if (LOW_POWER_TASK_RELEASE == 1)
    if (   ( idle_tm_hour < TRIG_STANDBY_TM_HOUR_MIN )
        || ( idle_tm_hour > TRIG_STANDBY_TM_HOUR_MAX ) )
    {
        return SF_ERR_PARA;
    }
    #endif

    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); 
    p_para_data->idle_to_sleep_tm = idle_tm_hour;
    _low_power_all_timers_refresh();
    dev_param_save();
    dev_param_save();


    return SF_OK;
}

sf_ret_t low_power_set_disable( uint16_t disable )
{
    if (disable == SF_TRUE )
    {
        if (cmu_sys_state_get() == CMU_SYS_STATE_SLEEP)
        {
            LOW_POWER_LOG_D( "recover\r\n" );
            
            /* 切为待机状态，按待机之后得流程走 */
            cmu_sys_state_set( CMU_SYS_STATE_STANDBY );
            BIT_SET( shm_web_control_info_get()->CMU_system_control_on, 0 );

        }

    }
    
    _low_power_all_timers_refresh();
    return SF_OK;
}
/**
 * @brief  设置空载转休眠使能功能
 * @param  [in] enable：使能标志
 * @return SF_Ok：成功  非SF_Ok：失败
 * @note   
 */
sf_ret_t low_power_set_idle_to_sleep_enable( uint16_t enable )
{
    LOW_POWER_LOG_D("set idle to sleep enable:%d", enable);

    /* 刷新停机时间，防止立刻进入休眠状态 */
    sdk_shm_constant_parameter_data_get()->idle_to_sleep_enable = enable ; // 定值/参数
    _low_power_all_timers_refresh();
    dev_param_save();
    dev_param_save();
    

    if (    (cmu_sys_state_get() == CMU_SYS_STATE_SLEEP)
            && (enable == SF_FALSE ))
    {
        LOW_POWER_LOG_D( "recover\r\n" );
        
        /* 切为待机状态，按待机之后得流程走 */
        cmu_sys_state_set( CMU_SYS_STATE_STANDBY );
        BIT_SET( shm_web_control_info_get()->CMU_system_control_on, 0 );
    }

    return SF_OK;
}

/**
 * @brief  设置休眠转关机使能功能
 * @param  [in] enable：使能标志
 * @return SF_Ok：成功  非SF_Ok：失败
 * @note   
 */
sf_ret_t low_power_set_sleep_to_power_off_enable( uint16_t enable )
{
    LOW_POWER_LOG_D("set sleep to power off enable:%d", enable);

    sdk_shm_constant_parameter_data_get()->sleep_to_pow_off_enable = enable ; // 定值/参数
    _low_power_all_timers_refresh();
    dev_param_save();
    dev_param_save();

    return SF_OK;
}

/**
 * @brief  设置空载切关机的时间
 * @param  [in] idle_tm_hour：空载切关机的时间，单位：1小时
 * @return SF_Ok：成功  非SF_Ok：失败
 * @note   
 */
sf_ret_t low_power_set_sleep_to_power_off_time( uint16_t idle_tm_hour )
{
    LOW_POWER_LOG_D("%s ,timer: %d hours\r\n", __FUNCTION__, idle_tm_hour);

    #if (LOW_POWER_TASK_RELEASE == 1)
    if (   ( idle_tm_hour < DAY_TO_HOUR( TRIG_POW_OFF_TM_DAY_MIN ))
        || ( idle_tm_hour > DAY_TO_HOUR( TRIG_POW_OFF_TM_DAY_MAX )) )
    {
        return SF_ERR_PARA;
    }
    #endif

    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数
    p_para_data->sleep_to_pow_off_tm = idle_tm_hour;
    _low_power_all_timers_refresh();
    dev_param_save();
    dev_param_save();

    return SF_OK;
}

/**
 * @brief  定时监控 功率
 * @param  [in] arg ：用户参数
 * @return 无
 * @note   
 */
static void _csu_data_monitor_callback( void *arg )
{
    static int16_t last_usr_setting_power = 0;

    g_user_setting_power =  internal_shared_data_get()->csu_dat_info.pcs.active_power;
    if ( last_usr_setting_power != g_user_setting_power )
    {
        last_usr_setting_power = g_user_setting_power;
        LOW_POWER_LOG_D("g_user_setting_power:%d\r\n", g_user_setting_power);
    }
}

/**
 * @brief  低功耗管理模块数据初始化
 * @param  [in] 无
 * @return SF_OK：成功  非SF_OK：失败
 * @note   
 */
sf_ret_t low_power_manage_data_init( void )
{
    trig_pow_off_timer = user_timer_create( NULL, NULL );
    trig_sleep_timer = user_timer_create( NULL, NULL );
    csu_monitor_timer  = user_timer_create( _csu_data_monitor_callback, NULL );

    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    if (   ( p_para_data->sleep_to_pow_off_enable != 0 )
        && ( p_para_data->sleep_to_pow_off_enable != 1 ) )
    {
        LOW_POWER_LOG_D( "%s sleep_to_pow_off_enable error, set defualt enable!!!\r\n", __FUNCTION__ );
        low_power_set_sleep_to_power_off_enable(0);
    }
    if (   ( p_para_data->idle_to_sleep_enable != 0 )
        && ( p_para_data->idle_to_sleep_enable != 1 ) )
    {
        LOW_POWER_LOG_D( "%s idle_to_sleep_enable error, set defualt enable!!!\r\n", __FUNCTION__ );
        low_power_set_idle_to_sleep_enable(0);
    }

    #if (LOW_POWER_TASK_RELEASE == 1)
    if (   ( p_para_data->idle_to_sleep_tm < TRIG_STANDBY_TM_HOUR_MIN )
        || ( p_para_data->idle_to_sleep_tm > TRIG_STANDBY_TM_HOUR_MAX ) )
    {
        LOW_POWER_LOG_D( "%s idle_to_sleep_tm error, set defualt time!!!\r\n", __FUNCTION__ );
        low_power_set_idle_to_sleep_mode_time( TRIG_STANDBY_TM_HOUR_DEF );
    }

    if (   ( p_para_data->sleep_to_pow_off_tm < DAY_TO_HOUR( TRIG_POW_OFF_TM_DAY_MIN ))
        || ( p_para_data->sleep_to_pow_off_tm > DAY_TO_HOUR( TRIG_POW_OFF_TM_DAY_MAX )) )
    {
        LOW_POWER_LOG_D( "%s sleep_to_pow_off_tm error, set defualt time!!!\r\n", __FUNCTION__ );
        low_power_set_sleep_to_power_off_time( DAY_TO_HOUR( TRIG_POW_OFF_TM_DAY_DEF ) );
    }
    #endif

    LOW_POWER_LOG_D( "[%s] enable:%d idle to sleep time:%d hours\r\n", __FUNCTION__ ,
                                                                        p_para_data->idle_to_sleep_enable,
                                                                        p_para_data->idle_to_sleep_tm );
    LOW_POWER_LOG_D( "[%s] enable:%d sleep to pow off time:%d hours\r\n", __FUNCTION__ ,
                                                                          p_para_data->sleep_to_pow_off_enable,
                                                                          p_para_data->sleep_to_pow_off_tm );

    _low_power_all_timers_refresh();
    user_timer_set_timeout( csu_monitor_timer, 10 * 1000, SF_TRUE );
    
    return SF_OK;
}

/**
 * @brief  低功耗状态管理任务
 * @param  [in] cmu_sys_sta      ： 系统状态
 * @param  [in] forbid_charge    ： 禁充标志
 * @param  [in] forbid_discharge ： 禁放标志
 * @param  [in] usr_power        ： 用户设置功率
 * @return 
 * @note   
 */
static void low_power_sta_manage_task_loop( uint8_t cmu_sys_sta, bool forbid_charge, bool forbid_discharge , int16_t usr_power )
{
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();
    internal_shared_data_t *p_internal_data = NULL;
    static uint16_t last_sleep_disable = 0xFF;

    p_internal_data = internal_shared_data_get();
    if(p_telemetry_data == NULL || p_internal_data == NULL)
    {
        return;
    }

    if( last_sleep_disable != p_internal_data->csu_dat_info.sleep_mode_disable )
    {
        low_power_set_disable(p_internal_data->csu_dat_info.sleep_mode_disable);
        last_sleep_disable = p_internal_data->csu_dat_info.sleep_mode_disable;
    }
    if( p_internal_data->csu_dat_info.sleep_mode_disable == SF_TRUE)
    {
        return;
    }

    if ( !( ( p_telemetry_data->cmu_telemetry_info.cmu_sys_state == 2 )      /* 运行状态 欲转 休眠状态 */
           || ( p_telemetry_data->cmu_telemetry_info.cmu_sys_state == 5 )      /* 休眠状态 欲转 停机状态 */  /* 休眠状态 欲转 重开机 */ 
        ))
    {
        /* 既不是运行，也不是休眠 */
        user_timer_refresh( trig_sleep_timer );
        user_timer_refresh( trig_pow_off_timer );
        return;
    }

    bool power_invalid =    ( usr_power == 0)                                      /* 空载 */
                         || ( usr_power < 0 && forbid_charge    == SF_TRUE )       /* 无法充电 */
                         || ( usr_power > 0 && forbid_discharge == SF_TRUE );      /* 无法放电 */

    if ( power_invalid == SF_FALSE )
    {
        /* 功率有效 */
        user_timer_refresh( trig_sleep_timer );
        user_timer_refresh( trig_pow_off_timer );
    }

    bool trig_standby = user_timer_is_timeout( trig_sleep_timer );
    bool trig_pow_off = user_timer_is_timeout( trig_pow_off_timer );

    low_pow_sta_e cur_power_sta      = LOW_POW_STA_NORMAL;

    if ( trig_standby && (sdk_shm_constant_parameter_data_get()->idle_to_sleep_enable == 1) )
    {
        cur_power_sta = LOW_POW_STA_SLEEP;
    }
        
    if ( trig_pow_off && (sdk_shm_constant_parameter_data_get()->sleep_to_pow_off_enable == 1))
    {
        cur_power_sta = LOW_POW_STA_POWER_OFF;
    }
        
    if ( !( ( (p_telemetry_data->cmu_telemetry_info.cmu_sys_state == 2 )   /* 运行状态 欲转 休眠状态 */  /* 运行状态 欲转 停机状态 */
                 && ( cur_power_sta == LOW_POW_STA_SLEEP || cur_power_sta == LOW_POW_STA_POWER_OFF ) )      
            || ( (p_telemetry_data->cmu_telemetry_info.cmu_sys_state == 5)    /* 休眠状态 欲转 停机状态 */
                 && ( cur_power_sta == LOW_POW_STA_POWER_OFF ))
            || ( (p_telemetry_data->cmu_telemetry_info.cmu_sys_state == 5)    /* 休眠状态 欲转 重开机，必须功率有效 */ 
                 && ( cur_power_sta == LOW_POW_STA_NORMAL ) && ( power_invalid == SF_FALSE ) )
        ))
    {
        /* 其他情况 不符合状态切换条件，直接返回 */
        return;
    }
    
    LOW_POWER_LOG_D("%s cur_power_sta:%d\r\n", __FUNCTION__, cur_power_sta);

    operation_log_t op_log; 

	init_user_basic_info( &op_log);
	strcpy((char*)op_log.user_name,"SystemSetup");
	strcpy((char*)op_log.user_role,"Null");
	strcpy((char*)op_log.op_status,"success");

    switch ( cur_power_sta )
    {
        case LOW_POW_STA_SLEEP:
            LOW_POWER_LOG_D( "TO LOW_POW_STA_SLEEP\r\n" );
            cmu_sys_state_set( CMU_SYS_STATE_SLEEP );
            pcs_power_control( PCS_POWER_EPO );
            sleep(2);
            pcs_power_control( PCS_POWER_OFF );
 		    strcpy((char*)op_log.op_type,"空载转休眠");
	        add_one_op_log(&op_log);
            break;

        case LOW_POW_STA_POWER_OFF:
            LOW_POWER_LOG_D( "TO LOW_POW_STA_POWER_OFF\r\n" );
            BIT_SET( shm_web_control_info_get()->CMU_system_control_off, 0 );
 		    strcpy((char*)op_log.op_type,"休眠转停机");
	        add_one_op_log(&op_log);
            break;

        case LOW_POW_STA_NORMAL:
            LOW_POWER_LOG_D( "TO LOW_POW_STA_POWER_ON\r\n" );
            if (( cmu_sys_state_get() == CMU_SYS_STATE_SLEEP) )
            {
                LOW_POWER_LOG_D( "PCS POWER ON\r\n" );

                /* 切为待机状态，按待机之后得流程走 */
                cmu_sys_state_set( CMU_SYS_STATE_STANDBY );
                BIT_SET( shm_web_control_info_get()->CMU_system_control_on, 0 );
                strcpy((char*)op_log.op_type,"休眠转开机");
                add_one_op_log(&op_log);
            }
            break;
        default:
            break;
    }
}


void *low_power_manage_task_loop(void *arg)
{
    while (1)
    {
        telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();
        telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();
        
        bool forbid_charge    = ((p_telematic_data->container_system_status_info[0]) & BIT(0))? SF_TRUE: SF_FALSE;      // 禁止充电
        bool forbid_discharge = ((p_telematic_data->container_system_status_info[0]) & BIT(1))? SF_TRUE: SF_FALSE;      // 禁止放电

        // LOW_POWER_LOG_D( "cmu_sys_sta:%d, forbid_charge:%d, forbid_discharge:%d ,usr_power:%d, usr_pow_on:%d, g_low_pow_sta:%d\r\n", 
        //                 p_telemetry_data->cmu_telemetry_info.cmu_sys_state, forbid_charge, forbid_discharge , g_user_setting_power, g_user_powr_on, g_low_pow_sta );
        low_power_sta_manage_task_loop( p_telemetry_data->cmu_telemetry_info.cmu_sys_state, forbid_charge, forbid_discharge, g_user_setting_power );

        sleep(5);
    }
}

/**
 * @brief  同步用户设置 开关机状态
 * @param  [in] usr_power_sta_on： 用户开关机状态
 * @return SF_Ok：成功  非SF_Ok：失败
 * @note   
 */
sf_ret_t low_power_task_set_usr_power_sta( bool usr_power_sta_on )
{
    LOW_POWER_LOG_D("%s, usr_power_sta_on:%d\r\n", __FUNCTION__, usr_power_sta_on);

    if (    (cmu_sys_state_get() == CMU_SYS_STATE_SLEEP)
            && (usr_power_sta_on == SF_TRUE ))
    {
        LOW_POWER_LOG_D( "USR PCS POWER ON\r\n" );
        
        /* 切为待机状态，按待机之后得流程走 */
        cmu_sys_state_set( CMU_SYS_STATE_STANDBY );
        BIT_SET( shm_web_control_info_get()->CMU_system_control_on, 0 );
    }
    
    user_timer_refresh( trig_sleep_timer );
    user_timer_refresh( trig_pow_off_timer );

    return SF_OK;
}

/**
 * @brief  低功耗管理初始化，根据用户功率功率进行状态维护
 * @param  [in] 无
 * @return SF_Ok：成功  非SF_Ok：失败
 * @note   
 */
sf_ret_t low_power_manage_init( void )
{
    LOW_POWER_LOG_D("%s", __FUNCTION__);

    int32_t ret = 0;
	pthread_attr_t inte_attr;
	pthread_t integration_task;

    low_power_manage_data_init();

    // 初始化线程属性
    ret = pthread_attr_init(&inte_attr);
    if (ret)
    {
        LOW_POWER_LOG_D((int8_t *)"\n [%s:%d] pthread_attr_init error!!! \n", __func__, __LINE__);
        return SF_ERR_NDEF; // 线程属性初始化出错退出
    }
    
    // 设置线程属性为分离状态
    ret = pthread_attr_setdetachstate(&inte_attr, PTHREAD_CREATE_DETACHED);
    if (ret)
    {
        LOW_POWER_LOG_D((int8_t *)"\n [%s:%d] pthread_attr_setdetachstate info_record_attr error!!! \n", __func__, __LINE__);
        return SF_ERR_NDEF; // 线程分离属性设置出错退出
    }
    // 创建综合任务线程
    ret = pthread_create(&integration_task, &inte_attr, &low_power_manage_task_loop, NULL);
    if (ret)
    {
        LOW_POWER_LOG_D((int8_t *)"\n [%s:%d] pthread_create integration_task error!!! \n", __func__, __LINE__);
        return SF_ERR_NDEF; // 线程创建出错退出
    }  

    // 销毁线程属性结构,它在重新初始化之前不能重新使用
    pthread_attr_destroy(&inte_attr);

    return SF_OK;
}