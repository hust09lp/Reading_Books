#include "cmu_sys_state.h"
#include "battery_fun_interface.h"
#include "process_battery_read.h"
#include "info_record_task.h"
#include "param_record_task.h"
#include "iec104_slave.h"
#include "data_shm.h"
#include "sofar_log.h"
#include "sdk_public.h"
#include "sdk_shm.h"
#include "sci_task.h"
#include "kh_pcs_task.h"
#include "web_control_task.h"
#include "integration_task.h"
#include "pcs_task.h"
#include "low_power_task.h"
#include "emergent_stop.h"
#include "fault_record_task.h"
#include "modbus_task.h"

#include <stdio.h>
#include <unistd.h>

void innercan_task_start(void);
void safety_task_start(void);

int32_t main(int32_t argc, char **argv)
{
    log_init((const int8_t *) PATH_CONF);
    log_set_level(LOG_LVL_DEBUG);

    // 映射共享内存
    sdk_shm_init();

    // 文件初始化和共享内存初始化放在哪个进程？ fix me!!!
    param_record_file_init();
    shm_data_init();

    // 检查热管理版本
    check_hot_manage_version();

    // 电池线程
    battery_read_task_start();
    battery_write_task_start();

    // PCS的CAN通讯线程
    innercan_task_start();

    // sci线程
    sci_task_start();

    // pcs线程
    pcs_task_start();

    // cmu系统状态管理线程
    sys_state_process_start();

    // iec104线程
    iec104_slave_task_start();

    // 信息存储线程
    info_record_task_start();

    // 响应web控制操作
    web_control_task_start();

    // 综合管理线程
    integration_task_start();

    // 安规管理线程
    safety_task_start();

    // 低功耗管理
    low_power_manage_init();

    // 紧急停止任务管理
    emergent_stop_task_init();

    // 故障录波线程
    fault_record_process_start();

    // modbus线程启动
    modbus_start();
    
    while(1)
    {
        sleep(5);
    }

	log_finish();

    return 0;
}


