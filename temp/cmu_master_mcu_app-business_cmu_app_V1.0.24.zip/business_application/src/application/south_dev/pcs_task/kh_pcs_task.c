#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk_modbus.h"
#include "kh_pcs_task.h"
#include "pcs_task.h"

static kh_pcs_data_t g_kh_pcs_data = {0};

/**
 * @brief   u16的数据copy到u8的buff中
 * @param   [in] p_des 目标地
 * @param   [in] p_src 源地
 * @param   [in] len 长度
 * @retu
 */
static void buf_cpy16to8(uint8_t *p_des, const uint16_t *p_src, uint16_t len)
{
	while (len--)
	{
		*p_des = *(p_src) >> 8;
		p_des++;
        *p_des = *(p_src) & 0xff;
		p_src++;
        p_des++;
	}
}

/**
 * @brief   u8的数据copy到u16的buff中
 * @param   [in] p_des 目标地
 * @param   [in] p_src 源地
 * @param   [in] len 长度
 * @return 
 */
static void buf_cpy8to8(uint8_t *p_des, const uint8_t *p_src, uint16_t len)
{
	while (len--)
	{
		*p_des = *p_src;
		p_src++;
        p_des++;
	}
}

/**
 * @brief   cmu状态转化为pcs需要的bms状态
 * @param   
 * @return  bms状态
 */
uint8_t bms_state_change(void)
{
    uint8_t tmp = 0;
    uint8_t bms_state = 0;
    uint8_t warn[BATTERY_CLUSTER_WARN_LEN_BYTE] = {0};
    telemetry_data_t *p_yc_data = sdk_shm_telemetry_data_get(); // 遥测数据
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();   // 遥信数据

    switch (p_yc_data->cmu_telemetry_info.cmu_sys_state)
    {
        // cmu系统运行状态  0-停机 1-待机 2-运行 3-故障 4-升级
        case 0: 
            bms_state = BMS_STATE_START;
            break;
        case 1:
            bms_state = BMS_STATE_STANDBY;  // 禁充禁放 
            break;
        case 2:
            bms_state = BMS_STATE_RUN;
            break;
        case 3:
            bms_state = BMS_STATE_FAULT;  // PCS 关机保护
            break;
        case 4:
            bms_state = BMS_STATE_STANDBY;  // 禁充禁放 
            break;

        default:
            break;
    }

    // 检查正常运行时是否有告警信息
    if (bms_state == BMS_STATE_RUN)
    {
        if (memcmp(p_telematic_data->container_system_warn_info, warn, CONTAINER_SYSTEM_WARN_LEN_BYTE) != 0)
        {
            bms_state = BMS_STATE_WARN;
        }
        
        for (tmp = 0; tmp < BCU_DEVICE_NUM; tmp++)
        {
            if (memcmp(p_telematic_data->battery_cluster_telematic_info[tmp].battery_cluster_warn_info, warn, CONTAINER_SYSTEM_WARN_LEN_BYTE) != 0)
            {
                bms_state = BMS_STATE_WARN;
                break;
            }
        }
    }

    // 检查正常运行或告警时是否有禁充禁放指令
    if ((bms_state == BMS_STATE_RUN) || (bms_state == BMS_STATE_WARN))
    {
        if((p_telematic_data->container_system_status_info[3]&0x05) != 0)
        {
            bms_state = BMS_STATE_NO_CHARGE;
        }
        if((p_telematic_data->container_system_status_info[3]&0x0A) != 0)
        {
            bms_state = BMS_STATE_NO_DISCHARGE;
        }
    }

    return (bms_state);
}

#if 0
/**
 * @brief   soc数值获取
 * @param  
 * @note    获取十簇中soc的平均值
 * @return  soc最小值
 */
static uint16_t bms_soc_get(void)
{
    uint8_t i = 0, j = 0;
    uint16_t soc = 0;
    telemetry_data_t *p_yc_data = sdk_shm_telemetry_data_get();     // 遥测数据

#if 1 
    // 获取10簇中soc的平均值之和
    for (i = 0; i < BCU_DEVICE_NUM; i++)
    {
        soc += p_yc_data->battery_cluster_telemetry_info[i].average_SOC_monomer;
    }
    // 四舍五入，获取十簇平均值
    soc = (soc + 500)/BCU_DEVICE_NUM; 

    return (soc);

#endif

#if 0 
    // 获取最小值
    soc = p_yc_data->battery_cluster_telemetry_info[0].lowest_monomer_SOC_cluster[0];
    // 获取10簇中soc的最小值
    for (i = 0; i < BCU_DEVICE_NUM; i++)
    {
        for (j = 0; j < 3; j++)
        {
            if (soc > p_yc_data->battery_cluster_telemetry_info[i].lowest_monomer_SOC_cluster[j])
            {
                soc = p_yc_data->battery_cluster_telemetry_info[i].lowest_monomer_SOC_cluster[j];
            }
        }
    }
    return (soc);

#endif
}

/**
 * @brief   soh数值获取
 * @param  
 * @note    获取十簇soh的平均值
 * @return  soh平均值
 */
static uint16_t bms_soh_get(void)
{
    uint8_t i = 0;
    uint16_t soh = 0;
    telemetry_data_t *p_yc_data = sdk_shm_telemetry_data_get();     // 遥测数据

    // 获取10簇中soh的平均值之和
    for (i = 0; i < BCU_DEVICE_NUM; i++)
    {
        soh += p_yc_data->battery_cluster_telemetry_info[i].average_SOH_monomer;
    }
    // 四舍五入，获取十簇平均值
    soh = (soh + 500)/BCU_DEVICE_NUM;   

    return (soh);
}
#endif

/**
 * @brief   科华PCS需要的数据从共享内存中同步
 * @param   [in] p_data pcs数据
 * @return  
 */
static void kh_data_get(kh_pcs_data_t *p_data)
{   
    uint16_t bms_state = 0;
    uint16_t bms_heart = 0;
    telemetry_data_t *p_yc_data = sdk_shm_telemetry_data_get();     // 遥测数据

    bms_state = bms_state_change();
    bms_heart = p_data->bms_state>>12;

    bms_heart ++;
    if (bms_heart > 15)
    {
        bms_heart = 0;
    }

    p_data->bms_state = 0;
    p_data->bms_state |= ((bms_state&0xffff)<<4);
    p_data->bms_state |= ((bms_heart&0xffff)<<12);

    p_data->voltage = p_yc_data->container_system_telemetry_info.total_voltage;     // 精度0.1
    p_data->current = p_yc_data->container_system_telemetry_info.total_current + 400; // 精度0.1 偏移2000
    p_data->soc = p_yc_data->container_system_telemetry_info.soc;  // 获取十簇最小值  精度0.1
    p_data->soh = p_yc_data->container_system_telemetry_info.soh;  // 获取十簇平均值  精度0.1
    p_data->charge_limits_current = 1600*10;  // 充电限制电流——0.5C，1600A  精度0.1
    p_data->discharge_limits_current = 1600*10;  // 充电限制电流——0.5C，1600A  精度0.1
    p_data->charge_limits_voltage = 1400*10;  // 充电限制电压——3.6×8×48=1382V，取1400V 精度0.1
    p_data->discharge_limits_voltage = 1000*10;  // 放电限制电压——2.8×8×48=1075V，取1000V 精度0.1
    p_data->charge_available_electricity = (3440 * p_data->soh * (1000 - p_data->soc));  // 充电可用电量——3440×SOH×（100-SOC） 精度0.1
    p_data->discharge_available_electricity = (3440 * p_data->soh * p_data->soc);  // 放电可用电量——3440×SOH×SOC  精度0.1

}

/**
 * @brief   科华0x03功能码响应
 * @param   [in] p_req 接收报文的指针,功能码之后的数据
 * @param   [out] p_rsq 响应报文的指针，功能码之后的数据
 * @return  返回执行结果，>0 实际返回的数据长度，< 0 返回异常
 */
int32_t kh_pcs_data_read(const uint8_t *p_req, uint8_t *p_rsq)
{
    uint16_t start_add = 0;
    uint16_t register_num = 0;
    uint16_t offset = 0;
    uint8_t rsq_len = 0;
    kh_pcs_data_t *p_pcs_data = &g_kh_pcs_data;
    uint16_t *p_data = &p_pcs_data->bms_state;

    start_add = (p_req[0]<<8)|p_req[1];
    register_num = (p_req[2]<<8)|p_req[3];

    KH_PCS_DEBUG_PRINT("\n start_add = %x register_num = %x\n", start_add, register_num);

    // 起始地址错误
    if (start_add < KH_START_ADDR)
    {
        p_rsq[0] = MODBUS_READ_HOLDING_REGISTERS + 0x80;
        p_rsq[1] = KH_MODBUS_ILLEGAL_DATA_ADDRESS;
        rsq_len = 2;
        return (rsq_len);
    }

    // 请求的数据长度错误
    if ((start_add + register_num)  > (KH_START_ADDR + (sizeof(kh_pcs_data_t)>>1)))
    {
        p_rsq[0] = MODBUS_READ_HOLDING_REGISTERS + 0x80;
        p_rsq[1] = KH_MODBUS_ILLEGAL_DATA_LEN;
        rsq_len = 2;
        return (rsq_len);
    }

    offset = start_add - KH_START_ADDR;

    // 科华PCS需要的数据同步
    kh_data_get(p_pcs_data);      

    // modbus数据填充
    p_rsq[0] = MODBUS_READ_HOLDING_REGISTERS;
    p_rsq[1] = register_num<<1;
    buf_cpy16to8(&p_rsq[2], p_data + offset, register_num);
    rsq_len = (register_num<<1) + 2;

    return (rsq_len);
}

/**
 * @brief   科华0x06功能码响应
 * @param   [in] p_req 接收报文的指针,功能码之后的数据
 * @param   [out] p_rsq 响应报文的指针，功能码之后的数据
 * @return  返回执行结果，>0 实际返回的数据长度，< 0 返回异常
 */
int32_t kh_pcs_data_write(const uint8_t *p_req, uint8_t *p_rsq)
{
    uint16_t start_add = 0;
    uint16_t value = 0;
    uint16_t offset = 0;
    uint8_t rsq_len = 0;
    uint16_t *p_data = &g_kh_pcs_data.bms_state;

    start_add = (p_req[0]<<8)|p_req[1];
    value = (p_req[2]<<8)|p_req[3];

    // 起始地址错误
    if ((start_add < (KH_START_ADDR + 6)) || (start_add > (KH_START_ADDR + (sizeof(kh_pcs_data_t)>>1))))
    {
        p_rsq[0] = MODBUS_WRITE_SINGLE_REGISTER + 0x80;
        p_rsq[1] = KH_MODBUS_ILLEGAL_DATA_ADDRESS;
        rsq_len = 2;
        return (rsq_len);
    }   

    // 写数据
    offset = start_add - KH_START_ADDR;
    *(p_data + offset) = value;

    // modbus数据填充
    p_rsq[0] = MODBUS_WRITE_SINGLE_REGISTER;
    buf_cpy8to8(&p_rsq[1], p_req, 4);
    rsq_len = 5;

    return (rsq_len);
}


/**
 * @brief   modbus数据处理
 * @param   [in] index modbus下标，0~9
 * @param   [in] req   接收数据
 * @param   [in] req_length   接收数据
 * @return  返回执行结果：>0 发送数据长度；-1：异常
 */
int32_t modbus_analysis(uint32_t index, const uint8_t *req, uint8_t req_length)
{
    uint8_t rsq[MODBUS_MAX_MESSAGE_LENGTH] = {0};
    uint8_t slave_addr = 0;
    uint8_t function = 0;
    uint8_t send_len = 0;
    int32_t rc = 0;

    if (req == NULL)
    {
        KH_PCS_DEBUG_PRINT("\n 空指针 \n");
        return (-1);
    }

    slave_addr= req[0];
    function = req[1];

    // 检查从机地址是否是本机从机地址
    if ((slave_addr != 1) && (slave_addr != MODBUS_BROADCAST_ADDR))
    {
        KH_PCS_DEBUG_PRINT("\n slave_addr err \n");
        return (-1);
    }
    rsq[0] = req[0];
    send_len ++;

    switch (function)
    {
        // 读数据处理
        case MODBUS_READ_HOLDING_REGISTERS:
            KH_PCS_DEBUG_PRINT("\n kh_pcs_data_read \n");
            rc = kh_pcs_data_read(&req[2], &rsq[1]);
            break;

        // 写数据处理
        case MODBUS_WRITE_SINGLE_REGISTER:
            KH_PCS_DEBUG_PRINT("\n kh_pcs_data_write \n");
            rc = kh_pcs_data_write(&req[2], &rsq[1]);
            break;
        
        default:
            break;
    }

    if (rc > 1)
    {
        send_len += rc;
    }
    else
    {
        rsq[1] = function + 0x80;
        send_len ++;
        rsq[2] = KH_MODBUS_ILLEGAL_FUNCTION;
        send_len ++;
    }

    return ((slave_addr == MODBUS_BROADCAST_ADDR) ? 0 : sdk_modbus_write(index, rsq, send_len));
}

