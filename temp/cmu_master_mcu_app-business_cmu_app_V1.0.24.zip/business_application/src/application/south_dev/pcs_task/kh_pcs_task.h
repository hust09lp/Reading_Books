#ifndef __KH_PCS_TASK_H__
#define __KH_PCS_TASK_H__

#include "data_types.h"
#include "sofar_log.h"

#define KH_START_ADDR       0x0100      // 科华PCS的modbus起始地址

typedef enum{
	KH_MODBUS_ILLEGAL_FUNCTION 	    = 1,	    // 不支持的功能码
	KH_MODBUS_ILLEGAL_DATA_ADDRESS  = 2,	    // 起始地址错误
    KH_MODBUS_ILLEGAL_DATA_LEN 	    = 3,	    // 请求的数据长度错误
    KH_MODBUS_ILLEGAL_DATA_CTRL 	= 4,	    // 数据读写失败
}kh_err_e;

typedef enum{
	BMS_STATE_START 	    = 0,	    // 初始状态
	BMS_STATE_RUN    	    = 1,	    // 正常状态
    BMS_STATE_NO_CHARGE 	= 2,	    // 禁充  描述：禁止给电池充电，允许放电；
    BMS_STATE_NO_DISCHARGE 	= 3,	    // 禁放  描述：禁止给电池放电，允许充电；
    BMS_STATE_WARN 	        = 4,	    // 告警  PCS 行为：PCS 显示告警，不作其它处理。
    BMS_STATE_FAULT 	    = 5,	    // 故障  PCS 行为： PCS 关机保护。
    BMS_STATE_STANDBY 	    = 6,	    // 待机  描述：禁止给电池充放电；
}bms_sys_state_e;


#pragma pack(push)
#pragma pack(1)

// 读寄存器地址 0x0100 ~ 0x0x010B
typedef struct{
    uint16_t bms_state;     // BMS状态字
                            // bit4~6：BMS系统状态 00:初始状态，01：正常状态，02：禁充，03：禁放，04：告警，05：故障，06：待机，07：保留
                            // bit12~15 0~15：生命信号值
    uint16_t resv1;
    uint16_t voltage;       // 电压 0.1
    int16_t  current;       // 电流 0.1 2000 真实值为current*0.1-2000
    uint16_t soc;           // %   0.1
    uint16_t soh;           // %   0.1
    uint16_t charge_limits_current;         // 充电限制电流 0.1
    uint16_t discharge_limits_current;      // 放电限制电流 0.1
    uint16_t charge_limits_voltage;         // 充电限制电压 0.1
    uint16_t discharge_limits_voltage;      // 放电限制电压 0.1
    uint16_t charge_available_electricity;      // 充电可用电量 0.1
    uint16_t discharge_available_electricity;   // 放电可用电量 0.1
}kh_pcs_data_t;

#pragma pack(pop)

/**
 * @brief   modbus数据处理
 * @param   [in] index modbus下标，0~9
 * @param   [in] req   接收数据
 * @param   [in] req_length   接收数据
 * @return  返回执行结果：>0 发送数据长度；-1：异常
 */
int32_t modbus_analysis(uint32_t index, const uint8_t *req, uint8_t req_length);

#endif














