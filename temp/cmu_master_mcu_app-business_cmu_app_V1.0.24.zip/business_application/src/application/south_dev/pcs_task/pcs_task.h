#ifndef __PCS_TASK_H__
#define __PCS_TASK_H__

#include "data_types.h"
#include "sofar_log.h"

#define KH_PCS_UART_NUM     (3)     // 使用串口4，序号为3

#if (0)
#define KH_PCS_DEBUG_PRINT(...) log_i((int8_t *)__VA_ARGS__);
#else
#define KH_PCS_DEBUG_PRINT(...) {do {} while(0);}
#endif

void pcs_task_start(void);

#endif



