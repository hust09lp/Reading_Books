#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>
#include <sys/time.h>
#include <unistd.h>
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk_public.h"
#include "kh_pcs_task.h"
#include "pcs_task.h"
#include "sdk_modbus.h"

/**
 * @brief 科华PCS任务
 * @param
 * @note 做从机
 * @return
 */
void *thread_kh_pcs_slave(void *arg)
{
    int16_t rc = 0;
	uint8_t query[MODBUS_MAX_MESSAGE_LENGTH] = {0};

    uint16_t addr = sdk_shm_other_parameter_data_get()->address_rs485_4;

    if( sdk_modbus_rtu_init(KH_PCS_UART_NUM, addr, MODBUS_BAUD_9600) != 0)
    {
        KH_PCS_DEBUG_PRINT("sdk_modbus_rtu_init init error ret \n");
        return NULL;
    }
    sdk_modbus_debug_set(KH_PCS_UART_NUM, 1);
    sdk_modbus_connect(KH_PCS_UART_NUM);
    sdk_modbus_indication_timeout_set(KH_PCS_UART_NUM, 0);

    while (1)
    {
        rc = sdk_modbus_receive(KH_PCS_UART_NUM, query);
		if((rc != -1) && (rc != 0))
		{
            modbus_analysis(KH_PCS_UART_NUM, query, rc);
		}
        sleep(1);	
    }
}

/**
 * @brief   科华PCS任务
 * @param
 * @note 做主机。测试主机功能，实际没有这个功能需求
 * @return
 */
void *thread_kh_pcs_master(void *arg)
{
	int16_t rc = 0;
	uint8_t query[255] = {1, 2, 3, 4, 5};

    if( sdk_modbus_rtu_init( 3, 1, 9600 ) != 0)
    {
        KH_PCS_DEBUG_PRINT("sdk_modbus_rtu_init init error ret \n");
        return NULL;
    }
    sdk_modbus_debug_set( 3, 1 );
    sdk_modbus_connect( 3 );
    // sdk_modbus_write(0, query, 5);

    while (1)
    {
        rc = sdk_modbus_receive_confirmation(3, query);
        KH_PCS_DEBUG_PRINT("rc = %x \n", rc);
		if((rc != -1) && (rc != 0))
		{
            for (uint8_t i = 0; i < rc; i++)
            {
                KH_PCS_DEBUG_PRINT(" %x ", query[i]);
            }		
		}
        sleep(1);	
    }
    return NULL;
}

/**
 * @brief   科华PCS任务启动
 * @param
 * @note  创建任务
 * @return
 */
void pcs_task_start(void)
{
    // 创建任务 测试线程
    // pthread_t kh_pcs_master;
    // pthread_create(&kh_pcs_master, NULL, &thread_kh_pcs_master, NULL);

    pthread_t kh_pcs_slave;
    int32_t ret = 0;
    pthread_attr_t attr;

    // 初始化线程属性
    ret = pthread_attr_init(&attr);
    if (ret != 0)
    {
        KH_PCS_DEBUG_PRINT("\n pthread_attr_init: ");
    }
	//设置线程属性为分离状态
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);

    // 创建任务 
    pthread_create(&kh_pcs_slave, &attr, &thread_kh_pcs_slave, NULL);
    if (ret != 0)
    {
        KH_PCS_DEBUG_PRINT("\n pthread_create: ");
    }

    // 回收线程,设置为分离属性可以不调用
	ret = pthread_detach(kh_pcs_slave);
	if (ret != 0)
    {
		KH_PCS_DEBUG_PRINT("pthread_detach: %s\n", strerror(ret));
	}

    // 销毁线程属性
    pthread_attr_destroy(&attr);

}
