#ifndef __FAULT_RECORD_TASK_H__
#define __FAULT_RECORD_TASK_H__

#include "data_types.h"
#include "data_shm.h"


/**
 * @brief   故障录波管理线程
 * @param   
 * @note    
 * @return  
 */
void fault_record_process_start(void);


#endif  /* __INFO_RECORD_TASK_H__ */