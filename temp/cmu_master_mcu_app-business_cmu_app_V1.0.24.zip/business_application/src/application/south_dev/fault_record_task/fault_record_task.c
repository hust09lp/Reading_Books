/** 
 * @file          fault_record_task.c
 * @brief         故障录波功能实现模块
 * @author        dongzuhuang
 * @version       V0.0.1     初始版本
 * @date          2024/10/11
 * @copyright     Copyright (c) 2023 by SofarSolar, All Rights Reserved.
 */

#include <string.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
#include <time.h>

#include "fault_record_task.h"
#include "sofar_log.h"
#include "sdk_shm.h"
#include "data_shm.h"
#include "sdk_fs.h"
#include "sofar_errors.h"
#include "sdk_public.h"
#include "process_battery_read.h"
#include "sofar_errors.h"

#define PATH_FAULT_RECORD_FOLDER	"/media/mmcblk0p1/fault_record/" //运行数据存储的文件夹

#define FAULT_RECORD_IDLE       (0)     // 故障记录空闲
#define FAULT_RECORD_HEAD       (1)     // 故障记录前半段
#define FAULT_RECORD_TAIL       (2)     // 故障记录后半段
#define FAULT_RECORD_FINISH     (3)     // z故障记录结束  需要保存完整的故障录波数据到SD卡
#define MAX_RECORD_NUM          (50)    // 最大保存故障录波条数
#define PARALLEL_RECORD_NUM     (2)     // 并行保存的最大故障录波条数


// 故障编号
#define CMU_FAULT_START                (0x01)       // CMU系统故障编号起点
#define CMU_FAULT_END                  (0x30)       // CMU系统故障编号终点
#define CONTAINER_FAULT_START          (0xC1)      // 集装箱故障编号起点
#define CONTAINER_FAULT_END            (0x150)      // 集装箱故障编号终点
#define BATTERY_CLUSTER_1_FAULT_START  (0x201)      // 电池簇1故障编号起点
#define BATTERY_CLUSTER_1_FAULT_END    (0x250)      // 电池簇1故障编号终点
#define BATTERY_CLUSTER_2_FAULT_START  (0x301)      // 电池簇2故障编号起点
#define BATTERY_CLUSTER_2_FAULT_END    (0x350)      // 电池簇2故障编号终点
#define BATTERY_CLUSTER_3_FAULT_START  (0x401)      // 电池簇3故障编号起点
#define BATTERY_CLUSTER_3_FAULT_END    (0x450)      // 电池簇3故障编号终点
#define BATTERY_CLUSTER_4_FAULT_START  (0x501)      // 电池簇4故障编号起点
#define BATTERY_CLUSTER_4_FAULT_END    (0x550)      // 电池簇4故障编号终点
#define BATTERY_CLUSTER_5_FAULT_START  (0x601)      // 电池簇5故障编号起点
#define BATTERY_CLUSTER_5_FAULT_END    (0x650)      // 电池簇5故障编号终点
#define BATTERY_CLUSTER_6_FAULT_START  (0x701)      // 电池簇6故障编号起点
#define BATTERY_CLUSTER_6_FAULT_END    (0x750)      // 电池簇6故障编号终点

// 告警编号
#define CONTAINER_WARN_START           (0x31)       // 集装箱告警编号起点
#define CONTAINER_WARN_END             (0xC0)       // 集装箱告警编号终点
#define BATTERY_CLUSTER_1_WARN_START   (0x171)      // 电池簇1告警编号起点
#define BATTERY_CLUSTER_1_WARN_END     (0x200)      // 电池簇1告警编号终点
#define BATTERY_CLUSTER_2_WARN_START   (0x271)      // 电池簇2告警编号起点
#define BATTERY_CLUSTER_2_WARN_END     (0x300)      // 电池簇2告警编号终点
#define BATTERY_CLUSTER_3_WARN_START   (0x371)      // 电池簇3告警编号起点
#define BATTERY_CLUSTER_3_WARN_END     (0x400)      // 电池簇3告警编号终点
#define BATTERY_CLUSTER_4_WARN_START   (0x471)      // 电池簇4告警编号起点
#define BATTERY_CLUSTER_4_WARN_END     (0x500)      // 电池簇4告警编号终点
#define BATTERY_CLUSTER_5_WARN_START   (0x571)      // 电池簇5告警编号起点
#define BATTERY_CLUSTER_5_WARN_END     (0x600)      // 电池簇5告警编号终点
#define BATTERY_CLUSTER_6_WARN_START   (0x671)      // 电池簇6告警编号起点
#define BATTERY_CLUSTER_6_WARN_END     (0x700)      // 电池簇6告警编号终点

#define BATTERY_CLUSTER_INTERVAL       (0x100)      // 电池簇间隔
#define BATTERY_CLUSTER_1_WARN3_START  (0x1A1)     // 电池簇1 3级告警编号起点
#define BATTERY_CLUSTER_1_WARN3_END    (0x1B8)     // 电池簇1 3级告警编号终点
#define BATTERY_CLUSTER_WARN3_NUM    (BATTERY_CLUSTER_1_WARN3_END - BATTERY_CLUSTER_1_WARN3_START)



#define FILE_PATH_MAX_LEN               (64)
#define RECORDER_WRITE_INTERVAL         (10)        // 故障发生后故障录波数据写入SD卡的时间间隔 单位：秒


uint8_t cmu_fault_pre[CMU_SYSTEM_FAULT_LEN_BYTE] = {0};
uint8_t container_fault_pre[CONTAINER_SYSTEM_FAULT_LEN_BYTE] = {0};
uint8_t battery_cluster_fault_pre[BCU_DEVICE_NUM][BATTERY_CLUSTER_FAULT_LEN_BYTE] = {0};
uint8_t battery_cluster_warn_pre[BCU_DEVICE_NUM][BATTERY_CLUSTER_WARN_LEN_BYTE] = {0};


typedef struct {
    char name[128];
    time_t modTime;
} FileInfo;


/**
 * @brief          检查SD卡是否挂载
 * @return         true：挂载 false：没有挂载
 */
static bool sd_mount_status(void)
{
    char cmd[256] = {0};
    char tmp_buff[32] = {0};
    FILE *fp = NULL;

    snprintf(cmd, 256, "df | grep \"dev/mmcblk0p1\" | awk '{print $1}'");
    fp = popen(cmd,"r");
    if(fp == NULL)
    {
        return false;
    }
    fread(tmp_buff, 1, sizeof(tmp_buff), fp);
    if(!strncmp(tmp_buff, "/dev/mmcblk0p1", strlen("/dev/mmcblk0p1")))
    {
        pclose(fp);
        return true;
    }
    pclose(fp);
    return false;
}

/**
 * @brief  对比文件修改时间
 * @param  [in] 
 * @param  [out] 
 * @return 
 */
int32_t compareModTime(const void *a, const void *b)
{
    FileInfo *fileInfoA = (FileInfo *)a;
    FileInfo *fileInfoB = (FileInfo *)b;
    return difftime(fileInfoB->modTime, fileInfoA->modTime);
}

/**
 * @brief  新增条故障录波数据
 * @param  [in] p_record 故障录波数据结构体
 * @param  [out] 故障记录新增结果
 * @return 
 */
static int32_t  add_one_record_item(cabinet_fault_recorder_data_t *p_record)
{
    telemetry_data_t *p_telemetry_data = NULL;
    telematic_data_t *p_telematic_data = NULL;
    uint16_t i = 0;
    sdk_rtc_t rtc_time;
    uint16_t highest_temperature_node = 0;
    uint16_t pack_index = 0;
    uint16_t cell_index = 0;
    uint16_t cell_1th_index = 0;
    uint16_t cell_2nd_index = 0;
    
    p_telemetry_data = sdk_shm_telemetry_data_get();
    p_telematic_data = sdk_shm_telematic_data_get();

    if(p_telemetry_data == NULL || p_telematic_data == NULL)
    {
        return SF_ERR_PARA;
    }
    // 时间戳记录
    sdk_rtc_get(RTC_BIN_FORMAT,&rtc_time);
    p_record->record_time[0] = rtc_time.tm_year;
    p_record->record_time[1] = rtc_time.tm_mon;
    p_record->record_time[2] = rtc_time.tm_day;
    p_record->record_time[3] = rtc_time.tm_hour;
    p_record->record_time[4] = rtc_time.tm_min;
    p_record->record_time[5] = rtc_time.tm_sec;
    // pcs 数据
    p_record->grid_volt_rs = p_telemetry_data->power_module_telemetry_info->grid_volt_rs;
    p_record->grid_volt_st = p_telemetry_data->power_module_telemetry_info->grid_volt_st;
    p_record->grid_volt_tr = p_telemetry_data->power_module_telemetry_info->grid_volt_tr;
    p_record->ac_current_r = p_telemetry_data->power_module_telemetry_info->ac_current_r;
    p_record->ac_current_s = p_telemetry_data->power_module_telemetry_info->ac_current_s;
    p_record->ac_current_t = p_telemetry_data->power_module_telemetry_info->ac_current_t;
    p_record->bus_volt_pn = p_telemetry_data->power_module_telemetry_info->bus_volt_pn;
    // log_i("\n==========pcs data: %d %d %d %d %d %d %d========\n",p_record->grid_volt_rs,p_record->grid_volt_st,p_record->grid_volt_tr\
    // ,p_record->ac_current_r,p_record->ac_current_s,p_record->ac_current_t,p_record->bus_volt_pn);

    // 液冷数据
    p_record->lc_inlet_temp = p_telemetry_data->container_system_telemetry_info.lc_inlet_temp;
    p_record->lc_outlet_temp = p_telemetry_data->container_system_telemetry_info.lc_outlet_temp;
    p_record->lc_inlet_pressure = p_telemetry_data->container_system_telemetry_info.lc_inlet_pressure;
    p_record->lc_outlet_pressure = p_telemetry_data->container_system_telemetry_info.lc_outlet_pressure;
    // log_i("\n=====lc data: %d %d %d %d=====\n",p_record->lc_inlet_temp,p_record->lc_outlet_temp,p_record->lc_inlet_pressure,p_record->lc_outlet_pressure);

    // 消防数据
    p_record->cabinet_data[0].mix_sensor1_co_ppm = p_telemetry_data->container_system_telemetry_info.mix_sensor1_co_ppm;
    p_record->cabinet_data[0].bat1_temper = p_telemetry_data->container_system_telemetry_info.bat1_temper;
    p_record->cabinet_data[0].bat1_humidity = p_telemetry_data->container_system_telemetry_info.bat1_humidity;
    p_record->cabinet_data[0].ff_cylinder_press = p_telemetry_data->container_system_telemetry_info.ff_cylinder_press;
    // log_i("\n======ff data: %d %d %d %d=====\n",p_record->cabinet_data[0].mix_sensor1_co_ppm\
    // ,p_record->cabinet_data[0].bat1_temper,p_record->cabinet_data[0].bat1_humidity,p_record->cabinet_data[0].ff_cylinder_press);

    p_record->cabinet_data[1].mix_sensor1_co_ppm = p_telemetry_data->container_system_telemetry_info.mix_sensor2_co_ppm;
    p_record->cabinet_data[1].bat1_temper = p_telemetry_data->container_system_telemetry_info.bat2_temper;
    p_record->cabinet_data[1].bat1_humidity = p_telemetry_data->container_system_telemetry_info.bat2_humidity;
    p_record->cabinet_data[1].ff_cylinder_press = p_telemetry_data->container_system_telemetry_info.ff_cylinder_press;

    p_record->cabinet_data[2].mix_sensor1_co_ppm = p_telemetry_data->container_system_telemetry_info.mix_sensor3_co_ppm;
    p_record->cabinet_data[2].bat1_temper = p_telemetry_data->container_system_telemetry_info.bat3_temper;
    p_record->cabinet_data[2].bat1_humidity = p_telemetry_data->container_system_telemetry_info.bat3_humidity;
    p_record->cabinet_data[2].ff_cylinder_press = p_telemetry_data->container_system_telemetry_info.ff_cylinder_press;

    p_record->cabinet_data[3].mix_sensor1_co_ppm = p_telemetry_data->container_system_telemetry_info.mix_sensor4_co_ppm;
    p_record->cabinet_data[3].bat1_temper = p_telemetry_data->container_system_telemetry_info.bat4_temper;
    p_record->cabinet_data[3].bat1_humidity = p_telemetry_data->container_system_telemetry_info.bat4_humidity;
    p_record->cabinet_data[3].ff_cylinder_press = p_telemetry_data->container_system_telemetry_info.ff_cylinder_press;

    // 电池数据
    for(i = 0; i < MAX_CABINET_NUM; i++)
    {
        p_record->cabinet_data[i].highest_monomer_voltage_cluster = p_telemetry_data->battery_cluster_telemetry_info[i].highest_monomer_voltage_cluster[0];
        p_record->cabinet_data[i].lowest_monomer_voltage_cluster = p_telemetry_data->battery_cluster_telemetry_info[i].lowest_monomer_voltage_cluster[0];
        p_record->cabinet_data[i].average_voltage_monomer = p_telemetry_data->battery_cluster_telemetry_info[i].average_voltage_monomer;
        p_record->cabinet_data[i].highest_monomer_temperature_cluster = p_telemetry_data->battery_cluster_telemetry_info[i].highest_monomer_temperature_cluster[0];
        p_record->cabinet_data[i].lowest_monomer_temperature_cluster = p_telemetry_data->battery_cluster_telemetry_info[i].lowest_monomer_temperature_cluster[0];
        p_record->cabinet_data[i].average_temperature_monomer = p_telemetry_data->battery_cluster_telemetry_info[i].average_temperature_monomer;
        p_record->cabinet_data[i].cluster_voltage = p_telemetry_data->battery_cluster_telemetry_info[i].cluster_voltage;
        p_record->cabinet_data[i].cluster_current = p_telemetry_data->battery_cluster_telemetry_info[i].cluster_current;
        p_record->cabinet_data[i].cluster_SOC = p_telemetry_data->battery_cluster_telemetry_info[i].cluster_SOC;
        p_record->cabinet_data[i].positive_relay_status = p_telematic_data->battery_cluster_telematic_info[i].battery_cluster_status_info[1]&0x01;
        p_record->cabinet_data[i].negative_relay_status = (p_telematic_data->battery_cluster_telematic_info[i].battery_cluster_status_info[1]&0x04)?1:0;
        highest_temperature_node = p_telemetry_data->battery_cluster_telemetry_info[i].battery_node_highest_temperature;
        pack_index = highest_temperature_node / 48;
        cell_index = highest_temperature_node % 48;
        if(cell_index == 0)
        {
            if(highest_temperature_node > 0)
            {
                cell_1th_index = 46;
                cell_2nd_index = 45;
            }
            else
            {
                cell_1th_index = 1;
                cell_2nd_index = 2; 
            }
        }
        else if(cell_index == 1)
        {
            cell_1th_index = cell_index;
            cell_2nd_index = cell_index+1; 
        }
        else 
        {
            cell_1th_index = cell_index -2;
            cell_2nd_index = cell_index;  
        }
        if(cell_1th_index > 47) cell_1th_index = 47;
        if(cell_2nd_index > 47) cell_1th_index = 47;
        // log_i("\n=====pack_index:%d %d %d %d====\n",highest_temperature_node,pack_index,cell_1th_index,cell_2nd_index);
        p_record->cabinet_data[i].Adjacent_highest_monomer_temperature1 = p_telemetry_data->battery_cluster_telemetry_info[i].monomer_info[pack_index].monomer_temperature[cell_1th_index];
        p_record->cabinet_data[i].Adjacent_highest_monomer_temperature2 = p_telemetry_data->battery_cluster_telemetry_info[i].monomer_info[pack_index].monomer_temperature[cell_2nd_index];
      
        // log_i("\n======bat data: %d %d %d %d %d %d %d %d %d %d %d %d %d\n",p_record->cabinet_data[i].highest_monomer_voltage_cluster\
        // ,p_record->cabinet_data[i].lowest_monomer_voltage_cluster,p_record->cabinet_data[i].average_voltage_monomer,\
        //  p_record->cabinet_data[i].highest_monomer_temperature_cluster,p_record->cabinet_data[i].lowest_monomer_temperature_cluster\
        //  ,p_record->cabinet_data[i].average_temperature_monomer,p_record->cabinet_data[i].cluster_voltage\
        //  ,p_record->cabinet_data[i].cluster_current,p_record->cabinet_data[i].cluster_SOC\
        //  ,p_record->cabinet_data[i].positive_relay_status,p_record->cabinet_data[i].negative_relay_status\
        //  ,p_record->cabinet_data[i].Adjacent_highest_monomer_temperature1,p_record->cabinet_data[i].Adjacent_highest_monomer_temperature2);
    }
    return SF_OK;
    
}

/**
 * @brief  CMU故障触发检测
 * @param  [in] 
 * @param  [out] 
 * @return 
 */
static void cmu_fault_trigger_detect(void)
{
    uint8_t i, j;
    int32_t ret;
    uint16_t id;
    uint8_t *p_fault = NULL;
    telematic_data_t *p_telematic_data;
    system_fault_recorder_data_t *p_fault_recorder_0 = NULL;
    system_fault_recorder_data_t *p_fault_recorder_1 = NULL;
  
	/* CMU系统故障 */
	p_telematic_data = sdk_shm_telematic_data_get();
    p_fault_recorder_0 = sdk_shm_fault_record_data_get(0);
    p_fault_recorder_1 = sdk_shm_fault_record_data_get(1);

	p_fault = p_telematic_data->CMU_system_fault_info;

    ret = memcmp(p_fault, cmu_fault_pre, CMU_SYSTEM_FAULT_LEN_BYTE);
    if(ret != 0)
    {
        for(i = 0; i < CMU_SYSTEM_FAULT_LEN_BYTE; i ++)
        {
            for(j = 0; j < 8; j++)
            {
                if((((p_fault[i] >> j) & 0x01) != ((cmu_fault_pre[i] >> j) & 0x01)))
                {
                    if(((i == 0) && (j == 4 )) || ((i == 1) && (j == 4)) || (i == 2))
                    {
                        if (!((cmu_fault_pre[i] >> j) & 0x01))
                        {
                            if(p_fault_recorder_0->cabinet_fault_recorder_info.record_status == FAULT_RECORD_HEAD)
                            {
                                id = (i * 8) + j + CMU_FAULT_START;
                                p_fault_recorder_0->cabinet_fault_recorder_info.fault_record_reason = id;
                                p_fault_recorder_0->cabinet_fault_recorder_info.record_status = FAULT_RECORD_TAIL;
                                p_fault_recorder_0->cabinet_fault_recorder_info.tail_current_index = 0;
                                p_fault_recorder_0->cabinet_fault_recorder_info.tail_record_len = 0;
                                sdk_rtc_get(RTC_BIN_FORMAT,&p_fault_recorder_0->cabinet_fault_recorder_info.record_tim);
                            }
                            else if(p_fault_recorder_1->cabinet_fault_recorder_info.record_status == FAULT_RECORD_HEAD)
                            {
                                id = (i * 8) + j + CMU_FAULT_START;
                                p_fault_recorder_1->cabinet_fault_recorder_info.fault_record_reason = id;
                                p_fault_recorder_1->cabinet_fault_recorder_info.record_status = FAULT_RECORD_TAIL;
                                p_fault_recorder_1->cabinet_fault_recorder_info.tail_current_index = 0;
                                p_fault_recorder_1->cabinet_fault_recorder_info.tail_record_len = 0;
                                sdk_rtc_get(RTC_BIN_FORMAT,&p_fault_recorder_1->cabinet_fault_recorder_info.record_tim);
                            }
                        }
                    }
                    
                }
            }
        }
        memcpy(cmu_fault_pre, p_fault, CMU_SYSTEM_FAULT_LEN_BYTE);
    }

    return;
}

/**
 * @brief  集装箱故障触发检测
 * @param  [in] 
 * @param  [out] 
 * @return 
 */
static void container_fault_trigger_detect(void)
{
    uint8_t i, j;
    int32_t ret;
    uint16_t id;
    uint8_t *p_fault = NULL;
    telematic_data_t *p_telematic_data = NULL;
    system_fault_recorder_data_t *p_fault_recorder_0 = NULL;
    system_fault_recorder_data_t *p_fault_recorder_1 = NULL;

	/* 集装箱系统故障 */
    p_fault_recorder_0 = sdk_shm_fault_record_data_get(0);
    p_fault_recorder_1 = sdk_shm_fault_record_data_get(1);

    p_telematic_data = sdk_shm_telematic_data_get();
    p_fault = p_telematic_data->container_system_fault_info;
   

    ret = memcmp(p_fault, container_fault_pre, CONTAINER_SYSTEM_FAULT_LEN_BYTE);
    if(ret != 0)
    {
        for(i = 0; i < CONTAINER_SYSTEM_FAULT_LEN_BYTE; i ++)
        {
            for(j = 0; j < 8; j++)
            {
                if((((p_fault[i] >> j) & 0x01) != ((container_fault_pre[i] >> j) & 0x01)))
                {
                    if (!((container_fault_pre[i] >> j) & 0x01))
                    {
                        if(p_fault_recorder_0->cabinet_fault_recorder_info.record_status == FAULT_RECORD_HEAD)
                        {
                            id = (i * 8) + j + CONTAINER_FAULT_START;
                            p_fault_recorder_0->cabinet_fault_recorder_info.fault_record_reason = id;
                            p_fault_recorder_0->cabinet_fault_recorder_info.record_status = FAULT_RECORD_TAIL;
                            p_fault_recorder_0->cabinet_fault_recorder_info.tail_current_index = 0;
                            p_fault_recorder_0->cabinet_fault_recorder_info.tail_record_len = 0;
                            sdk_rtc_get(RTC_BIN_FORMAT,&p_fault_recorder_0->cabinet_fault_recorder_info.record_tim);
                        }
                        else if(p_fault_recorder_1->cabinet_fault_recorder_info.record_status == FAULT_RECORD_HEAD)
                        {
                            id = (i * 8) + j + CONTAINER_FAULT_START;
                            p_fault_recorder_1->cabinet_fault_recorder_info.fault_record_reason = id;
                            p_fault_recorder_1->cabinet_fault_recorder_info.record_status = FAULT_RECORD_TAIL;
                            p_fault_recorder_1->cabinet_fault_recorder_info.tail_current_index = 0;
                            p_fault_recorder_1->cabinet_fault_recorder_info.tail_record_len = 0;
                            sdk_rtc_get(RTC_BIN_FORMAT,&p_fault_recorder_1->cabinet_fault_recorder_info.record_tim);
                        }
                    }
                }
            }
        }
        memcpy(container_fault_pre, p_fault, CONTAINER_SYSTEM_FAULT_LEN_BYTE);
    }
  
    return;
}

/**
 * @brief  电池故障触发检测
 * @param  [in] 
 * @param  [out] 
 * @return 
 */
static void battery_fault_trigger_detect(void)
{
    uint8_t i, j;
    int32_t ret;
    uint16_t id;
    int32_t num;
    uint8_t *p_fault = NULL;
    uint8_t *p_warn = NULL;
    telematic_data_t *p_telematic_data = NULL;
    system_fault_recorder_data_t *p_fault_recorder_0 = NULL;
    system_fault_recorder_data_t *p_fault_recorder_1 = NULL;
    battery_cluster_data_t *p_battery_cluster = NULL;
	battery_cluster_data_t *p_battery_cluster_offset = NULL;
    uint16_t start_id = 0;
	uint16_t end_id = 0;

	/* 集装箱系统故障 */
    p_fault_recorder_0 = sdk_shm_fault_record_data_get(0);
    p_fault_recorder_1 = sdk_shm_fault_record_data_get(1);

    p_telematic_data = sdk_shm_telematic_data_get();
    p_battery_cluster = battery_cluster_data_get();
   
    for(num = 0; num < BCU_DEVICE_NUM; num++)
    {
        p_battery_cluster_offset = p_battery_cluster + num;
        
        // 电池簇故障
        p_fault = p_battery_cluster_offset->battery_cluster_fault_info;
        ret = memcmp(p_fault, battery_cluster_fault_pre[num], BATTERY_CLUSTER_FAULT_LEN_BYTE);

        if(ret != 0)
        {
            for(i = 0; i < BATTERY_CLUSTER_FAULT_LEN_BYTE; i ++)
            {
                for(j = 0; j < 8; j++)
                {
                    if((((p_fault[i] >> j) & 0x01) != ((battery_cluster_fault_pre[num][i] >> j) & 0x01)))
                    {
                        if (!((battery_cluster_fault_pre[num][i] >> j) & 0x01))
                        {
                            if(p_fault_recorder_0->cabinet_fault_recorder_info.record_status == FAULT_RECORD_HEAD)
                            {
                                id = (i * 8) + j + BATTERY_CLUSTER_1_FAULT_START + (num * BATTERY_CLUSTER_INTERVAL);
                                p_fault_recorder_0->cabinet_fault_recorder_info.fault_record_reason = id;
                                p_fault_recorder_0->cabinet_fault_recorder_info.record_status = FAULT_RECORD_TAIL;
                                p_fault_recorder_0->cabinet_fault_recorder_info.tail_current_index = 0;
                                p_fault_recorder_0->cabinet_fault_recorder_info.tail_record_len = 0;
                                sdk_rtc_get(RTC_BIN_FORMAT,&p_fault_recorder_0->cabinet_fault_recorder_info.record_tim);
                            }
                            else if(p_fault_recorder_1->cabinet_fault_recorder_info.record_status == FAULT_RECORD_HEAD)
                            {
                                id = (i * 8) + j + BATTERY_CLUSTER_1_FAULT_START + (num * BATTERY_CLUSTER_INTERVAL);
                                p_fault_recorder_1->cabinet_fault_recorder_info.fault_record_reason = id;
                                p_fault_recorder_1->cabinet_fault_recorder_info.record_status = FAULT_RECORD_TAIL;
                                p_fault_recorder_1->cabinet_fault_recorder_info.tail_current_index = 0;
                                p_fault_recorder_1->cabinet_fault_recorder_info.tail_record_len = 0;
                                sdk_rtc_get(RTC_BIN_FORMAT,&p_fault_recorder_1->cabinet_fault_recorder_info.record_tim);
                            }
                        }
                    }
                }
            }
            memcpy(battery_cluster_fault_pre[num], p_fault, BATTERY_CLUSTER_FAULT_LEN_BYTE);
        }

        // 电池簇3级告警
        p_warn = p_battery_cluster_offset->battery_cluster_warn_info;
		ret = memcmp(p_warn, battery_cluster_warn_pre[num], BATTERY_CLUSTER_WARN_LEN_BYTE);
        if(ret != 0)
        {
            for(i = 0; i < BATTERY_CLUSTER_WARN_LEN_BYTE; i ++)
            {
                for(j = 0; j < 8; j++)
                {
                    if((((p_warn[i] >> j) & 0x01) != ((battery_cluster_warn_pre[num][i] >> j) & 0x01)))
                    {
                        id = (i * 8) + j + BATTERY_CLUSTER_1_WARN_START + (num * BATTERY_CLUSTER_INTERVAL);
                        start_id = BATTERY_CLUSTER_1_WARN3_START + (num * BATTERY_CLUSTER_INTERVAL);
                        end_id = BATTERY_CLUSTER_1_WARN3_END + (num * BATTERY_CLUSTER_INTERVAL);
                        if(id >=  start_id && id <= end_id)
                        {
                            if (!((battery_cluster_warn_pre[num][i] >> j) & 0x01))
                            {
                                if(p_fault_recorder_0->cabinet_fault_recorder_info.record_status == FAULT_RECORD_HEAD)
                                {
                                    p_fault_recorder_0->cabinet_fault_recorder_info.fault_record_reason = id;
                                    p_fault_recorder_0->cabinet_fault_recorder_info.record_status = FAULT_RECORD_TAIL;
                                    p_fault_recorder_0->cabinet_fault_recorder_info.tail_current_index = 0;
                                    p_fault_recorder_0->cabinet_fault_recorder_info.tail_record_len = 0;
                                    sdk_rtc_get(RTC_BIN_FORMAT,&p_fault_recorder_0->cabinet_fault_recorder_info.record_tim);
                                }
                                else if(p_fault_recorder_1->cabinet_fault_recorder_info.record_status == FAULT_RECORD_HEAD)
                                {
                                    id = (i * 8) + j + BATTERY_CLUSTER_1_WARN_START + (num * BATTERY_CLUSTER_INTERVAL);
                                    p_fault_recorder_1->cabinet_fault_recorder_info.fault_record_reason = id;
                                    p_fault_recorder_1->cabinet_fault_recorder_info.record_status = FAULT_RECORD_TAIL;
                                    p_fault_recorder_1->cabinet_fault_recorder_info.tail_current_index = 0;
                                    p_fault_recorder_1->cabinet_fault_recorder_info.tail_record_len = 0;
                                    sdk_rtc_get(RTC_BIN_FORMAT,&p_fault_recorder_1->cabinet_fault_recorder_info.record_tim);
                                }
                            }
                        }
                    }
                }
            }
            memcpy(battery_cluster_warn_pre[num], p_warn, BATTERY_CLUSTER_WARN_LEN_BYTE);
        }
    }
    return;
}

/**
 * @brief  故障录波状态管理
 * @param  [in] 
 * @param  [out] 
 * @return 
 */
static void fault_record_stage_manage(void)
{
   
    cmu_fault_trigger_detect();
    container_fault_trigger_detect();
    battery_fault_trigger_detect();
    return;
}

/**
 * @brief  故障录波文件管理，文件最多存50个，超过50个删除旧的文件
 * @param  [in]  
 * @param  [out] 
 * @return 
 */
static void fault_record_file_management(void)
{
    DIR *dir;
    fs_t *p_fs = NULL;
    struct dirent *entry;
    uint16_t file_num = 0;
    struct stat statbuf;
    uint8_t file_path[128];
    int32_t ret = -1;
    FileInfo *files;
    bool sd_sta = false;
    uint16_t i;

    /* 检测SD卡是否存在 */
    sd_sta = sd_mount_status();

    if(sd_sta == false)
    {
       log_i((int8_t *)"\n pcs TF_CARD does not exist!!! \n"); 
       return; 
    }
    // 尝试打开目录
    dir = opendir(PATH_FAULT_RECORD_FOLDER);
    if(dir == NULL)
    {
        log_e((int8_t *)"\n [%s:%d] open fault record dir fail \n", __func__, __LINE__);
        return;
    }

    // 遍历文件夹下的所有文件，统计文件个数
    while((entry = readdir(dir)) != NULL)
    {
        snprintf((char*)file_path,sizeof(file_path),"%s%s",PATH_FAULT_RECORD_FOLDER,entry->d_name);
        ret = stat((char*)file_path, &statbuf);
        //  log_i("\n---------------d_type:%d %s    %s-----------------------\n",entry->d_type ,entry->d_name,file_path);
        //  log_i("\n============ret:%d %d %d %d %d\n",ret,statbuf.st_size,statbuf.st_ctime,statbuf.st_atime,statbuf.st_mtime);
        if(entry->d_type == 8 && entry->d_name[0] != '.')
        {
            file_num++;
        }
    }
  //  log_i("\n*************file num:%d**********\n",file_num);
    // 判断已保存的故障录波文件数量是否超过最大文件数量 小于最大文件数量不需要删除操作
    if(file_num < MAX_RECORD_NUM)
    {
        closedir(dir);
        return;
    }

    // 文件数量超出规定的最大数量，执行删除旧文件操作
    files = malloc(file_num * sizeof(FileInfo));
    if(files == NULL)
    {
        closedir(dir);
        return;
    }
   
    // 重置目录流
    rewinddir(dir);
    i = 0;
    while((entry = readdir(dir)) != NULL)
    {
        if(entry->d_type == 8 && entry->d_name[0] != '.' && i < file_num)
        {
            memset(file_path,0,sizeof(file_path));
            snprintf((char*)file_path,sizeof(file_path),"%s%s",PATH_FAULT_RECORD_FOLDER,entry->d_name);
            stat((char*)file_path, &statbuf);
            strncpy(files[i].name,entry->d_name,sizeof(files[i].name));
            files[i].modTime = statbuf.st_mtime;
          //  log_i("\n------------file %d name:%s %d--------------\n",i,files[i].name,ctime(&files[i].modTime));
            i++;
        }
    }
    qsort(files,file_num,sizeof(FileInfo),compareModTime);
    // for(i = 0; i < file_num; i++)
    // {
    //     log_i("\n*********%s Modified: %s**************\n", files[i].name, ctime(&files[i].modTime));
    // }
    for(i = MAX_RECORD_NUM -1; i < file_num; i++)
    {
        snprintf((char*)file_path,sizeof(file_path),"%s%s",PATH_FAULT_RECORD_FOLDER,files[i].name);
        sdk_fs_remove((const int8_t *)file_path);
    }
    closedir(dir);
    free(files);
    return;
}

/**
 * @brief  故障录波数据写入SD中
 * @param  [in]  type 写入类型 0-故障发生前半段数据  1-g故障发生后半段数据
 * @param  [in]  index 要写入的a故障嗯录波索引
 * @return  写入结果
 */
static int32_t fault_record_write_handle(uint8_t type,uint8_t index,uint16_t write_len)
{
    system_fault_recorder_data_t *p_fault_recorder = NULL;
    char file_name[FILE_PATH_MAX_LEN];
    fs_t *p_fs = NULL;
    int32_t ret = 0;
    bool sd_sta = false;
    int32_t result = -1;
    uint16_t i = 0;
    uint16_t current_index = 0;
    uint16_t data_len = 0;
    static uint16_t start_write_index = 0;

    /* 检测SD卡是否存在 */
    sd_sta = sd_mount_status();

    if(sd_sta == false)
    {
       log_i((int8_t *)"\n pcs TF_CARD does not exist!!! \n"); 
       return SF_ERR_NO_OBJECT; 
    }
    p_fault_recorder = sdk_shm_fault_record_data_get(index);
    snprintf(file_name, sizeof(file_name), PATH_FAULT_RECORD_FOLDER "20%02d%02d%02d%02d%02d%02d-%d", p_fault_recorder->cabinet_fault_recorder_info.record_tim.tm_year\
    ,p_fault_recorder->cabinet_fault_recorder_info.record_tim.tm_mon,p_fault_recorder->cabinet_fault_recorder_info.record_tim.tm_day\
    ,p_fault_recorder->cabinet_fault_recorder_info.record_tim.tm_hour,p_fault_recorder->cabinet_fault_recorder_info.record_tim.tm_min\
    ,p_fault_recorder->cabinet_fault_recorder_info.record_tim.tm_sec,p_fault_recorder->cabinet_fault_recorder_info.fault_record_reason);
    /* 判断/media/文件夹是否存在 */
    ret = sdk_fs_access((const int8_t *)(PATH_FAULT_RECORD_FOLDER), FS_F_OK);
    if (ret != SF_OK)
    {
        ret = sdk_fs_mkdir((const char *)PATH_FAULT_RECORD_FOLDER, 755);
        if (ret < 0)
        {
            log_e((int8_t *)"\n [%s:%d] sdk_fs_mkdir fail, ret = %d \n", __func__, __LINE__, ret);
        }
    }
    
    p_fs = sdk_fs_open((const int8_t *)file_name,FS_OPEN_APPEND|FS_READ);
    if(p_fs == NULL)
    {
        log_e((const int8_t*)"\n=========creat fault reord failed===========\n");
        return -1;
    }
    if(type == 0)
    {
        data_len = p_fault_recorder->cabinet_fault_recorder_info.head_record_len;
        if(data_len <= MAX_FAULT_RECORDER_ITEM)
        {
            current_index = 0;
        }
        else
        {
            current_index = p_fault_recorder->cabinet_fault_recorder_info.head_current_index;
            data_len = MAX_FAULT_RECORDER_ITEM;
        }
        for(i = 0;i < data_len; i++)
        {
            sdk_fs_write(p_fs, &p_fault_recorder->fault_recorder_data_head[(current_index+i)%MAX_FAULT_RECORDER_ITEM], sizeof(cabinet_fault_recorder_data_t));
        }
        sdk_fs_close(p_fs);
        
    }
    else if(type == 1)
    {
        data_len = write_len;
        current_index = p_fault_recorder->cabinet_fault_recorder_info.tail_current_index-RECORDER_WRITE_INTERVAL;
        for(i = 0;i < data_len; i++)
        {
            sdk_fs_write(p_fs, &p_fault_recorder->fault_recorder_data_tail[(current_index+i)%MAX_FAULT_RECORDER_ITEM], sizeof(cabinet_fault_recorder_data_t));
        }
        sdk_fs_close(p_fs);
    }
    return SF_OK;
}

/**
 * @brief  储能柜故障录波数据记录
 * @param  [in] 
 * @param  [out] 
 * @return 
 */
static void local_fault_record_task(void)
{
    uint16_t status = 0;
    system_fault_recorder_data_t *p_fault_recorder = NULL;
    uint16_t current_index = 0;
    int32_t ret = -1;
    uint8_t i = 0;
    
    for(i = 0; i < PARALLEL_RECORD_NUM; i++)
    {
        p_fault_recorder = sdk_shm_fault_record_data_get(i);
        status = p_fault_recorder->cabinet_fault_recorder_info.record_status;
        fault_record_stage_manage();
        switch(status)
        {
            case FAULT_RECORD_IDLE:
                p_fault_recorder->cabinet_fault_recorder_info.head_current_index = 0;
                p_fault_recorder->cabinet_fault_recorder_info.head_record_len = 0;
                p_fault_recorder->cabinet_fault_recorder_info.record_status = FAULT_RECORD_HEAD;
                break;

            case FAULT_RECORD_HEAD:
                if(p_fault_recorder->cabinet_fault_recorder_info.head_current_index >= MAX_FAULT_RECORDER_ITEM)
                {
                    p_fault_recorder->cabinet_fault_recorder_info.head_current_index = 0; 
                }
                current_index = p_fault_recorder->cabinet_fault_recorder_info.head_current_index;
                ret = add_one_record_item(&p_fault_recorder->fault_recorder_data_head[current_index]);
             //   log_i("\n=======add_one_head_record_item:%d %d ======\n",p_fault_recorder->cabinet_fault_recorder_info.head_current_index\
                ,p_fault_recorder->cabinet_fault_recorder_info.head_record_len);
                if(ret == SF_OK)
                {
                    p_fault_recorder->cabinet_fault_recorder_info.head_current_index++;
                    if(p_fault_recorder->cabinet_fault_recorder_info.head_record_len <= MAX_FAULT_RECORDER_ITEM)
                    {
                        p_fault_recorder->cabinet_fault_recorder_info.head_record_len++;
                    }
                }
                break;

            case FAULT_RECORD_TAIL:
                if(p_fault_recorder->cabinet_fault_recorder_info.tail_current_index == 0)
                {
                    fault_record_file_management();
                    fault_record_write_handle(0,i,p_fault_recorder->cabinet_fault_recorder_info.head_record_len);
                }
                if(p_fault_recorder->cabinet_fault_recorder_info.tail_current_index >= MAX_FAULT_RECORDER_ITEM)
                {
                    p_fault_recorder->cabinet_fault_recorder_info.record_status = FAULT_RECORD_FINISH;
                    break;
                }
                current_index = p_fault_recorder->cabinet_fault_recorder_info.tail_current_index;
                ret = add_one_record_item(&p_fault_recorder->fault_recorder_data_tail[current_index]);
                if(ret == SF_OK)
                {
                    p_fault_recorder->cabinet_fault_recorder_info.tail_current_index++;
                    p_fault_recorder->cabinet_fault_recorder_info.tail_record_len++;
                }
                if(p_fault_recorder->cabinet_fault_recorder_info.tail_current_index%RECORDER_WRITE_INTERVAL == 0)
                {
                    fault_record_write_handle(1,i,RECORDER_WRITE_INTERVAL);
                }
            break;

            case FAULT_RECORD_FINISH:
             //   fault_record_write_handle(1,i,p_fault_recorder->cabinet_fault_recorder_info.tail_record_len%RECORDER_WRITE_INTERVAL);
                memset(p_fault_recorder,0,sizeof(system_fault_recorder_data_t));

            break;

            default:
            break;


        }
    }
    
}

/**
 * @brief     故障录波处理线程
 * @param     
 * @return    null
 * @author    sofar team
 * @note      null
 * @see       null
 * @date      2023/4/18
 */
void *thread_fault_record_process(void *arg)
{
    system_fault_recorder_data_t *p_fault_recorder = NULL;

    // 初始化故障录波结构体
    p_fault_recorder = sdk_shm_fault_record_data_get(0);
    memset(p_fault_recorder,0,sizeof(system_fault_recorder_data_t));
    p_fault_recorder = sdk_shm_fault_record_data_get(1);
    memset(p_fault_recorder,0,sizeof(system_fault_recorder_data_t));
    while(1)
    {
        local_fault_record_task();
        sleep(1);
    }
    pthread_exit(NULL);
}

/**
 * @brief   故障录波管理线程
 * @param   
 * @note    
 * @return  
 */
void fault_record_process_start(void)
{
    int16_t ret = 0;
    pthread_attr_t sys_attr;
    pthread_t fault_record_process;

    // 初始化线程属性
    ret = pthread_attr_init(&sys_attr);
    if (ret)
    {
        log_e((int8_t *)"\n [%s:%d] pthread_attr_init error!!! \n", __func__, __LINE__);
        return; // 线程属性初始化出错退出
    }
    
    // 设置线程属性为分离状态
    ret = pthread_attr_setdetachstate(&sys_attr, PTHREAD_CREATE_DETACHED);
    if (ret)
    {
        log_e((int8_t *)"\n [%s:%d] pthread_attr_setdetachstate sys_attr error!!! \n", __func__, __LINE__);
        return; // 线程分离属性设置出错退出
    }

    // 创建线程
    ret = pthread_create(&fault_record_process, &sys_attr, &thread_fault_record_process, NULL);
    if (ret)
    {
        log_e((int8_t *)"\n [%s:%d] pthread_create fault_monitor_process error!!! \n", __func__, __LINE__);
        return; // 线程创建出错退出
    }

}