/** 
 * @file          warn_monitor.h
 * @brief         告警监控外部接口函数说明
 * @author        liangguyao
 * @version       V0.0.1     初始版本
 * @date          2023/09/23
 * @copyright     Copyright (c) 2023 by SofarSolar, All Rights Reserved.
 */


#ifndef __WARN_MONITOR_H__
#define __WARN_MONITOR_H__

#include "data_types.h"
#include "pcs_fun_interface.h"

#if (0)
#define WARN_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else
#define WARN_DEBUG_PRINT(...) {do {} while(0);}
#endif

#define OBJ_LEVEL1_WARN_NO          (0)     // 无一级告警
#define OBJ_LEVEL1_WARN_YES         (1)     // 存在一级告警
#define OBJ_LEVEL2_FIRE_WARN_NO     (0)     // 无消防二级告警
#define OBJ_LEVEL2_FIRE_WARN_YES    (1)     // 存在消防二级告警
#define OBJ_LEVEL2_WARN_NO          (0)     // 无二级告警
#define OBJ_LEVEL2_WARN_YES         (1)     // 存在二级告警


/**
 * @brief   获取一级告警标志的置位情况
 * @param   null
 * @return 	[int32_t] 执行结果
 * @retval  OBJ_LEVEL1_WARN_NO      无一级告警
 * @retval  OBJ_LEVEL1_WARN_YES     存在一级告警
 * @retval  <0                      失败，返回错误码
 */
uint32_t level1_warn_flag_get(void);

/**
 * @brief   获取一级告警指示灯标志的置位情况
 * @param   null
 * @return 	[int32_t] 执行结果
 * @retval  OBJ_LEVEL1_WARN_NO      无须显示一级告警指示灯
 * @retval  OBJ_LEVEL1_WARN_YES     须要显示一级告警指示灯
 * @retval  <0                      失败，返回错误码
 */
uint32_t level1_warn_indicator_light_get(void);

/**
 * @brief   获取消防二级告警信号的置位情况
 * @param   null
 * @return 	[int32_t] 执行结果
 * @retval  OBJ_LEVEL2_FIRE_WARN_NO     无消防二级告警
 * @retval  OBJ_LEVEL2_FIRE_WARN_YES    存在消防二级告警
 * @retval  <0                          失败，返回错误码
 */
uint32_t level2_fire_warn_flag_get(void);

/**
 * @brief   获取二级告警标志的置位情况
 * @param   null
 * @return 	[int32_t] 执行结果
 * @retval  OBJ_LEVEL2_WARN_NO      无二级告警
 * @retval  OBJ_LEVEL2_WARN_YES     存在二级告警
 * @retval  <0                      失败，返回错误码
 */
uint32_t level2_warn_flag_get(void);

/**
 * @brief   获取二级告警指示灯标志的置位情况
 * @param   null
 * @return 	[int32_t] 执行结果
 * @retval  OBJ_LEVEL2_WARN_NO      无须显示二级告警指示灯
 * @retval  OBJ_LEVEL2_WARN_YES     须要显示二级告警指示灯
 * @retval  <0                      失败，返回错误码
 */
uint32_t level2_warn_indicator_light_get(void);

/**
 * @brief   获取二级告警下对应的pcs禁充禁放状态
 * @param   null
 * @return 	[int32_t] 执行结果
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败，返回错误码
 */
int32_t level2_warn_pcs_chg_dischg_get(pcs_chg_dischg_forbid_control_cmd_type_e *p_type);


#endif  /* __WARN_MONITOR_H__ */