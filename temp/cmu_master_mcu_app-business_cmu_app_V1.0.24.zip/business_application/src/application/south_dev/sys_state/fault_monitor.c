/**
 * @file          fault_monitor.c
 * @brief         cmu 三级故障管理
 * @company       sofarsolar
 * @author        sofar team
 * @note          base data_shm.h
 * @version       V1.0
 * @date          2023/4/18
*/
#include "param_record_task.h"
#include "fault_monitor.h"
#include "process_battery_read.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk_public.h"
#include "sofar_log.h"
#include "sdk_dido.h"
#include "data_types.h"
#include "pcs_fun_interface.h"
#include <pthread.h>
#include <string.h>
#include <stdlib.h>
#include "emergent_stop.h"


static uint8_t g_three_level_fault_flag = OBJ_FAULT_NO;             // 发生需要下电的三级故障的标志位 0-无故障 1-有故障
static sdk_rtc_t g_lc_fault_check_time = {0, 0, 1, 1, 1, 1, 1};     // 用于记录动环系统不稳定的RTC时间
static uint8_t g_power_off_fail_flag = DISABLE;                     // 正常下电失败
static sdk_rtc_t g_lc_fault_clear_time = {0, 0, 1, 1, 1, 1, 1};     // 用于清除动环系统不稳定的RTC时间


/** 
 * @brief   故障监测线程相关参数初始化
 * @param
 * @return
 */
void fault_monitor_param_init(void)
{
    int32_t ret = 0;

    g_three_level_fault_flag = OBJ_FAULT_NO;
    ret = sdk_rtc_get(RTC_BIN_FORMAT, &g_lc_fault_check_time);
    if (ret)
    {
        log_i((int8_t *)"\n [%s:%d] sdk_rtc_get fail \n", __func__, __LINE__);
    }
    ret = sdk_rtc_get(RTC_BIN_FORMAT, &g_lc_fault_clear_time);
    if (ret)
    {
        log_i((int8_t *)"\n [%s:%d] sdk_rtc_get fail \n", __func__, __LINE__);
    }

    // 因为底层接口sdk_is_time_over(sdk_rtc_t *p_start_time, uint32_t interval) 
    // 当p_start_time为1970年时，无法正确判断是否超时，所以检测到时间不合法时，赋一个合法的初始值
    if ((g_lc_fault_check_time.tm_year) > 37)
    {
        g_lc_fault_check_time.tm_year = 23;
    }
    if ((g_lc_fault_clear_time.tm_year) > 37)
    {
        g_lc_fault_clear_time.tm_year = 23;
    }
}

/**
 * @brief     三级故障标志设置
 * @param     [in] flag_state: OBJ_FAULT_NO(0)-无故障 OBJ_FAULT_YES(1)-有故障
 * @return    null
 * @author    sofar team
 * @note      null
 * @see       null
 * @date      2023/4/18
*/
static void three_level_fault_flag_set(uint8_t flag_state)
{
    if(flag_state > OBJ_FAULT_YES)
    {
        return;
    }

   // log_i((int8_t *)"\n ************ set g_three_level_fault_flag = %d ************\n", flag_state);
    
    g_three_level_fault_flag = flag_state;
}

/**
 * @brief     获取三级故障标志的置位情况
 * @param     null
 * @return    OBJ_FAULT_NO-无三级故障 OBJ_FAULT_YES-有三级故障
 * @author    sofar team
 * @note      null
 * @see       null
 * @date      2023/2/15
 */
uint8_t three_level_fault_flag_get(void)
{
    return g_three_level_fault_flag;
}

/**
 * @brief     获取电池簇的正常下电失败故障的置位情况
 * @param     null
 * @return    DISABLE-无电池簇存在正常下电失败故障  
 *            ENABLE-至少有一簇电池存在正常下电失败故障
 * @author    sofar team
 * @note      null
 * @see       null
 * @date      2023/5/23
 */
uint8_t power_off_fail_flag_get(void)
{
    return g_power_off_fail_flag;
}

/**
 * @brief  通过SN获取交流接触器反馈线是否连接
 * @param  [in] 无
 * @return 0-交流开关反馈线未接   1-交流开关反馈线接了
 * @note   
 */
static uint16_t get_ac_switch_type_by_sn(void)
{
    constant_parameter_data_t *p_para_data = NULL;
    internal_shared_data_t *p_internal_data = NULL;
    uint8_t temp_buf[4];
    uint8_t tm_year = 0;
    uint16_t switch_type = 0;
    
    p_para_data = sdk_shm_constant_parameter_data_get();    // 定值/参数
    p_internal_data =  internal_shared_data_get();
    if(p_para_data == NULL || p_internal_data == NULL)
    {
        return 0xffff;
    }
    memset(temp_buf,0,sizeof(temp_buf));
    temp_buf[0] = p_para_data->device_sn[11];
    temp_buf[1] = p_para_data->device_sn[12];
    tm_year = atoi((const char *)temp_buf);

    if(tm_year > 24)
    {
        switch_type = 1;
    }
    else 
    {
       switch_type = 0; 
    }
    return switch_type;
}

/**
 * @brief     读取CMU-MCU1的各DI信号，根据输入对相应故障位置位
 * @param     
 * @return    
 * @author    sofar team
 * @note      null
 * @see       null
 * @date      2023/3/29
*/
static void cmu_sys_state_di_value_get(void)
{
    int32_t ret = -1;
    uint16_t i = 0;
    uint16_t switch_type = 0;
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();   // 遥信数据
    other_parameter_data_t *p_other_data = sdk_shm_other_parameter_data_get(); // 共享内存-其他参数

    if ((NULL == p_telematic_data) || (NULL == p_other_data))
    {
        log_i((int8_t *)"\n [%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    for (i = 0; i < 8; i++)
    {
        if(i == 0 || i == 3 || i == 7)
        {
            ret = sdk_dido_read(i);
        }
        
        // 交流开关反馈根据SN号识别，旧机器没接交流反馈线，默认状态为闭合，新机器根据实际DI状态显示，0-断开  1-闭合
        if(i == 3)
        {
            switch_type = get_ac_switch_type_by_sn();
            // 交流开关反馈线没接，默认为闭合状态
            if(switch_type == 0)
            {
                ret = DI_DO_HIGH;
            }
        }
        if (DI_DO_HIGH == ret)
        {
            // MCU1的DI输入状态 置位 container_system_status_info[0] 
            // bit0-禁止放电 bit1-禁止充电 bit2-防雷信号 bit3-交流开关反馈 bit4-紧急停机 bit5-外部告警信号 bit6-CSU告警信号输入 bit7-预留
            // DI0-防雷信号（辅电）
            // DI1-预留
            // DI2-预留
            // DI3-交流开关反馈
            // DI4-预留
            // DI5-EPO信号
            // DI6-外部告警信号输入
            // DI7-CSU告警信号输入
            
            switch (i)
            {
                case 0: // DI0-防雷信号（辅电）
                    // 防雷信号 置位 container_system_status_info[0]-bit2
                    p_telematic_data->container_system_status_info[0] |= (1 << 2);
                    // 防雷故障 置位 container_system_fault_info[0]-bit2
                    p_telematic_data->container_system_fault_info[0] |= (1 << 2);
                    break;
                case 3: // DI3-交流开关反馈
                    // 交流开关反馈 置位 container_system_status_info[0]-bit3
                    p_telematic_data->container_system_status_info[0] |= (1 << 3);
                    break;
                case 7: // DI7-CSU告警信号输入
                    // CSU告警 置位 container_system_status_info[0]-bit6
                    p_telematic_data->container_system_status_info[0] |= (1 << 6);
                    break;
                default:
                    break;
            }
        }
        else
        {
            // 状态位需要根据dido的值进行更新
            switch (i)
            {
                case 0: // DI0-防雷信号（辅电）
                    // 防雷信号 清零 container_system_status_info[0]-bit2
                    p_telematic_data->container_system_status_info[0] &= ~(1 << 2);
                    // 防雷故障 解除 container_system_fault_info[0]-bit2
                    p_telematic_data->container_system_fault_info[0] &= ~(1 << 2);
                    break;
                case 3: // DI3-交流开关反馈
                    // 交流开关反馈 清零 container_system_status_info[0]-bit3
                    p_telematic_data->container_system_status_info[0] &= ~(1 << 3);
                    break;
                case 7: // DI7-CSU告警信号输入
                    // CSU告警 解除 container_system_status_info[0]-bit6
                    p_telematic_data->container_system_status_info[0] &= ~(1 << 6);
                    break;
                default:
                    break;
            }
        }
    }
}

/**
 * @brief     get container and cmu fault
 * @param     null
 * @return    have fault or not,
 * @return    OBJ_FAULT_NO or OBJ_FAULT_YES
 * @author    sofar team
 * @note      null
 * @see       null
 * @date      2023/2/15
*/
static uint8_t container_and_cmu_fault_get(void)
{
    static uint8_t count[SYS_LC_FAULT_NUM] = {0}; // 记录故障出现次数
    static uint8_t fault_bak[SYS_LC_FAULT_LEN_BYTE] = {0}; // 记录上一次集装箱系统和液冷机组的故障状态
    uint8_t fault = 0;
    uint8_t ret = OBJ_FAULT_NO;
    uint8_t temp = 0;
    uint8_t data_bak = 0;
    uint8_t index = 0;
    uint16_t i = 0;
    uint16_t j = 0;
    int32_t result = 0;
    uint8_t lc_fault_flag = 0;
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get(); // get telematic data
    internal_shared_data_t *p_internal_data = internal_shared_data_get();


    if ((NULL == p_telematic_data) || (NULL == p_internal_data))
    {
        log_i((int8_t *)"\n [%s:%d] Null pointer \n", __func__, __LINE__);
        
        ret = OBJ_FAULT_YES;
        goto __exit;
    }

    if (p_internal_data->fault_reset)   // 执行了故障复归指令
    {
        memset(count, 0, sizeof(count));
        p_internal_data->fault_reset = DISABLE;
        p_telematic_data->CMU_system_fault_info[2] &= ~(1 << 0);
        pcs_reset_control(1);         // 给PCS发送复位指令
    }

    if(p_telematic_data->CMU_system_fault_info[0] & (1<<4))  //CMU內部SCI通信故障，系统需要停机
    {
        ret = OBJ_FAULT_YES;
        log_i((int8_t *)"\n [%s:%d] CMU SCI COM fault \n", __func__, __LINE__);
        goto __exit;
    }
    
    if(p_telematic_data->CMU_system_fault_info[0] & (1<<3))  //PCS开机失败，系统需要停机
    {
        ret = OBJ_FAULT_YES;
      //  log_i((int8_t *)"\n [%s:%d] PCS POWER ON fault \n", __func__, __LINE__);
        goto __exit;
    }

    if(p_telematic_data->CMU_system_fault_info[1] & (1<<4))  //CMU和CSU通信故障，系统需要停机
    {
        ret = OBJ_FAULT_YES;
        log_i((int8_t *)"\n [%s:%d] CMU disconnect from CSU\n", __func__, __LINE__);
        goto __exit;
    }


    if(p_telematic_data->CMU_system_fault_info[2] & (1<<1))  //CMU与PCS的CAN通信故障，PCS通信失联,系统需要停机
    {
        ret = OBJ_FAULT_YES;
        log_i((int8_t *)"\n [%s:%d] PCS CAN fault \n", __func__, __LINE__);
        goto __exit;
    }

    // CSU系统故障
    temp = p_telematic_data->CMU_system_fault_info[2] & (1 << 2);
    if(temp > 0)
    {
        ret = OBJ_FAULT_YES;
        log_i((int8_t *)"\n [%s:%d] CSU fault \n", __func__, __LINE__);
        goto __exit;
    }

    // container fault
    // p_telematic_data->container_system_fault_info[0] &= 0xF7; // 屏蔽消防故障 临时
    // p_telematic_data->container_system_fault_info[0] &= 0xEF; // 屏蔽温湿度传感器 临时
    // p_telematic_data->container_system_fault_info[2] &= 0xFE; // 屏蔽液冷总故障 临时

    result = sdk_is_time_over(&g_lc_fault_check_time, 3600); // 一小时超时

    if (1 == result)
    {
        result = sdk_rtc_get(RTC_BIN_FORMAT, &g_lc_fault_check_time);   // 更新当前时间
        if (result)
        {
            log_i((int8_t *)"\n [%s:%d] sdk_rtc_get fail \n", __func__, __LINE__);
        }

        for (i = 0; i < SYS_LC_FAULT_NUM; i++)
        {
            count[i] = 0;
        }
    }

    // 集装箱系统和液冷机组的故障，在1h内发生3次需人为恢复才能消除故障
    for (i = 0; i < SYS_LC_FAULT_LEN_BYTE; i++)
    {
        fault = p_telematic_data->container_system_fault_info[i + SYS_LC_FAULT_START];

        for (j = 0; j < 8; j++)
        {
            index = i * 8 + j;
            temp = (fault >> j) & 0x01;
            data_bak = (fault_bak[i] >> j) & 0x01;
            if (ENABLE == temp)
            {
                lc_fault_flag = ENABLE;
            }
            if ((DISABLE == data_bak) && (ENABLE == temp)) // 记录该位 0->1 的次数
            {
                count[index]++;
            }

            if (count[index] >= 8)  // 1h内该故障已出现3次，判断时认为该故障一直存在需要手动复位
            {
                count[index] = 8;
                fault |= (1 << j);

                // 动环系统不稳定 故障置位 --做提示用，提醒维护人员动环系统出现故障频繁变动情况，需要查看故障记录
                if (p_telematic_data->CMU_system_fault_info[2] & (1 << 0))
                {
                    result = sdk_rtc_get(RTC_BIN_FORMAT, &g_lc_fault_clear_time);   // 更新当前时间
                    if (result)
                    {
                        log_i((int8_t *)"\n [%s:%d] sdk_rtc_get fail \n", __func__, __LINE__);
                    }
                }
                p_telematic_data->CMU_system_fault_info[2] |= (1 << 0);
            }
        }

        fault_bak[i] = p_telematic_data->container_system_fault_info[i+SYS_LC_FAULT_START];
        
        if (fault)
        {
           // log_e((int8_t *)"\n container_system_fault_info[%d] = 0x%x, fault = 0x%x \n", i, p_telematic_data->container_system_fault_info[i], fault);
            ret = OBJ_FAULT_YES;
        }
    }

    if(p_telematic_data->CMU_system_fault_info[2] & (1 << 0))
    {
        result = sdk_is_time_over(&g_lc_fault_clear_time, 7200); // 2小时超时
        if (1 == result && lc_fault_flag == 0)
        {
            p_telematic_data->CMU_system_fault_info[2] &= ~(1 << 0);  // 触发动环不稳定2小时后如果没有故障，解除动环不稳定故障
        }
        ret = OBJ_FAULT_YES;
    }

    for (i = 0; i < SYS_LC_FAULT_START; i++)
    {
        if (p_telematic_data->container_system_fault_info[i])
        {
          //  log_e((int8_t *)"\n container_system_fault_info[%d] = 0x%x \n", i, p_telematic_data->container_system_fault_info[i]);
            ret = OBJ_FAULT_YES;
        }
    }

    for (i = SYS_LC_FAULT_LEN_BYTE + SYS_LC_FAULT_START; i < CONTAINER_SYSTEM_FAULT_LEN_BYTE; i++)
    {
        if (p_telematic_data->container_system_fault_info[i])
        {
     //       log_e((int8_t *)"\n container_system_fault_info[%d] = 0x%x \n", i, p_telematic_data->container_system_fault_info[i]);
            ret = OBJ_FAULT_YES;
        }
    }
    

__exit:
    return ret;
}

/**
 * @brief     get bat fault
 * @param     null
 * @return    have fault or not,
 * @return    OBJ_FAULT_NO or OBJ_FAULT_YES
 * @author    sofar team
 * @note      null
 * @see       null
 * @date      2023/2/15
*/
static uint8_t bat_fault_get(void)
{
    uint8_t  flag = 0;
    uint8_t  temp = 0;
    uint8_t  ret = OBJ_FAULT_NO;
    uint32_t i = 0;
    uint32_t j = 0;
    uint32_t k = 0;
    battery_cluster_telematic_info_t *p_bat_telematic = NULL;
    static battery_cluster_telematic_info_t last_bat_telematic = {0};
    uint8_t bat_fault_trigger_poweroff = 0;
    other_parameter_data_t *p_other_data = sdk_shm_other_parameter_data_get(); // 共享内存-其他参数
    static uint8_t bat_fault_trigger_poweroff_bak = 0;

    for (i = 0; i < BCU_DEVICE_NUM; i++)
    {
        p_bat_telematic = sdk_shm_battery_cluster_telematic_info_get(i);

        if (NULL == p_bat_telematic)
        {
            ret = OBJ_FAULT_YES;
            goto __exit;
        }
        
        // 正常下电失败 fault[3].bit6
        temp = (p_bat_telematic->battery_cluster_fault_info[3] >> 6) & 0x01;
        if (temp)
        {
            flag = ENABLE;
        }

        // 电池簇3级告警报故障
        for (j = 6; j < 9; j++)
        {
            if (7 == j)
            {
                // SOC过高、过低3级故障不影响电池上下电操作
                temp = (p_bat_telematic->battery_cluster_warn_info[j]) & 0xF3;

                // 放电过流3级告警 单体压差3级告警触发后，故障恢复后不恢复运行
                if(p_bat_telematic->battery_cluster_warn_info[j] & 0x41)
                {
                    bat_fault_trigger_poweroff =1;
                }
                
            }
            else
            {
                temp = p_bat_telematic->battery_cluster_warn_info[j];
            }
            
            // 充电过流3级告警触发后，故障恢复后不恢复运行
            if(6 == j)
            {
                if(p_bat_telematic->battery_cluster_warn_info[j] & 0x20)
                {
                    bat_fault_trigger_poweroff =1;
                }
            }
            // 单体温差3级告警触发后，故障恢复后不恢复运行
            if(8 == j)
            {
                if(p_bat_telematic->battery_cluster_warn_info[j] & 0x08)
                {
                    bat_fault_trigger_poweroff =1;
                }
            }

            if (temp)
            {
                if ( p_bat_telematic->battery_cluster_warn_info[j] != last_bat_telematic.battery_cluster_warn_info[j] )
                {
                    log_e((int8_t *)"\n cluster id = %d, battery_cluster_warn_info[%d] = 0x%x \n", i, j, p_bat_telematic->battery_cluster_warn_info[j]);
                    last_bat_telematic.battery_cluster_warn_info[j] = p_bat_telematic->battery_cluster_warn_info[j];
                }
                ret = OBJ_FAULT_YES;
            }
        }
        // 放电过流3级告警 单体压差3级告警 充电过流3级告警 单体温差3级告警  故障恢复后不自动上电
        if((bat_fault_trigger_poweroff == 1) && (bat_fault_trigger_poweroff_bak == 0))
        {
            p_other_data->remote_on_off_ctrl = REMOTE_POWER_OFF;
            dev_param_save();
            dev_param_save();
        }
        bat_fault_trigger_poweroff_bak = bat_fault_trigger_poweroff;
        // bat fault
        for(k = 0; k < BATTERY_CLUSTER_FAULT_LEN_BYTE; k++)
        {
            if(p_bat_telematic->battery_cluster_fault_info[k])
            {
                if (p_bat_telematic->battery_cluster_fault_info[k] != last_bat_telematic.battery_cluster_fault_info[k] )
                {
                    last_bat_telematic.battery_cluster_fault_info[k] = p_bat_telematic->battery_cluster_fault_info[k];
                    log_e((int8_t *)"\n cluster id = %d, battery_cluster_fault_info[%d] = 0x%x \n", i, k, p_bat_telematic->battery_cluster_fault_info[k]);
                }
                ret = OBJ_FAULT_YES;
            }
        }
    }

    // 判断是否有电池簇发生了正常下电失败
    if (flag)
    {
        g_power_off_fail_flag = ENABLE;
    }
    else
    {
        g_power_off_fail_flag = DISABLE;
    }

__exit:
    return ret;
}

/**
 * @brief   检测系统是否发生三级故障
 * @param     
 * @return  
 * @author  sofar team
 * @note    包含三个步骤：1. 对电池簇上电前部分需要cmu-mcu1系统置位的故障位，进行检测置位
 *                          (CMU-MCU1的DI输入、电池簇主控版本号一致判断)
 *                       2. 扫描集装箱故障、电池簇3级告警和电池故障信息，判断是否存在三级故障
 *                       3. 若存在三级故障，输出故障IO（对外、对BCU）
 * @date    2023/4/6
*/
void cmu_sys_state_fault_detection(void)
{
    uint8_t version_check = OBJ_VERSION_NORMAL;
    uint8_t  container_fault = 0;
    uint8_t  bat_fault = 0;
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();   // 共享内存-遥信数据

    // 1. DI输入检测
    cmu_sys_state_di_value_get(); // 检测CMU-MCU1的DI信号，对相应故障位置位

    // 2. 电池簇版本号一致检测
    version_check = battery_master_software_version_check();
    if (OBJ_VERSION_UN_NORMAL == version_check)
    {
        // 电池簇主控版本不一致告警 置位 container_system_warn_info[0].bit7
        p_telematic_data->container_system_warn_info[0] |= (1 << 0);
        log_i((int8_t *)"\n battery_master_software_version_check fail *************** \n"); // 测试用
    }
    else
    {
        p_telematic_data->container_system_warn_info[0] &= ~(1 << 0);
    }

    container_fault = container_and_cmu_fault_get();
    bat_fault       = bat_fault_get();

    if ((OBJ_FAULT_YES == container_fault) || (OBJ_FAULT_YES == bat_fault))
    {
        if (OBJ_FAULT_YES == container_fault)
        {
           // log_i((int8_t *)"\n container_fault !!! \n");
        }
        if (OBJ_FAULT_YES == bat_fault)
        {
           // log_i((int8_t *)"\n bat_fault !!! \n");
        }
        three_level_fault_flag_set(OBJ_FAULT_YES);

        // 输出故障IO(对PCS模块故障IO)
        // sdk_dido_write(INDEX_DO_OUT1, DI_DO_HIGH);
        _emergent_stop_pcs_fault_pin_set( SF_TRUE );
    }
    else
    {
        three_level_fault_flag_set(OBJ_FAULT_NO);

        // 清零故障IO(对PCS模块故障IO)
        // sdk_dido_write(INDEX_DO_OUT1, DI_DO_LOW);
        _emergent_stop_pcs_fault_pin_set( SF_FALSE );
    }
}


