/** 
 * @file          warn_monitor.c
 * @brief         告警监控外部接口函数实现
 * @author        liangguyao
 * @version       V0.0.1     初始版本
 * @date          2023/09/23
 * @copyright     Copyright (c) 2023 by SofarSolar, All Rights Reserved.
 */


#include "warn_monitor.h"
#include "process_battery_read.h"
#include "data_shm.h"
#include "sofar_errors.h"
#include "sofar_log.h"
#include "sdk_shm.h"


// #define 

#if (0)
#define WARN_MONITOR_LOG_D(...)   do{ log_d( (const int8_t*)__VA_ARGS__); } while(0)
#define WARN_MONITOR_LOG_I(...)   do{ log_i( (const int8_t*)__VA_ARGS__); } while(0)
#else
#define WARN_MONITOR_LOG_D(...)   do{} while(0)
#define WARN_MONITOR_LOG_I(...)   do{} while(0)
#endif

#define BATTERY_CLUSTER_LEVEL_1_WARN_LEN    (3)     // 电池簇数据1级告警字节长度


/**
 * @brief   获取一级告警标志的置位情况
 * @param   null
 * @return 	[int32_t] 执行结果
 * @retval  OBJ_LEVEL1_WARN_NO      无一级告警
 * @retval  OBJ_LEVEL1_WARN_YES     存在一级告警
 * @retval  <0                      失败，返回错误码
 */
uint32_t level1_warn_flag_get(void)
{
    uint8_t temp = 0;
    uint8_t i;
    uint8_t cluster_index;
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();              // 遥信
    battery_cluster_telematic_info_t *p_cluster_telematic = NULL;

    if (NULL == p_telematic_data)
    {
        log_e((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return SF_ERR_NDEF;
    }

    /* CMU储能柜系统 */
    /* 告警信息（地址范围0x1A1~0x230） */
    for (i = 0; i < CONTAINER_SYSTEM_WARN_LEN_BYTE; i++)
    {
        if (p_telematic_data->container_system_warn_info[i] > 0)
        {
            WARN_MONITOR_LOG_I((int8_t *)"\n [%s:%d] p_telematic_data->container_system_warn_info[%d] = 0x%x \n", __func__, __LINE__, i, p_telematic_data->container_system_warn_info[i]);
            return OBJ_LEVEL1_WARN_YES;
        }
    }

    /* CMU-1电池柜 电池簇1数据 */
    /* 告警信息 （地址范围0x2E1~0x370） 供电电压欠压报警1级 ~ PACK欠压报警1级（前3字节） */
    for (cluster_index = 0; cluster_index < BCU_DEVICE_NUM; cluster_index++)
    {
        p_cluster_telematic = sdk_shm_battery_cluster_telematic_info_get(cluster_index);
        if (NULL == p_cluster_telematic)
        {
            log_e((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
            return SF_ERR_NDEF;
        }

        for (i = 0; i < BATTERY_CLUSTER_LEVEL_1_WARN_LEN; i++)
        {
            if (p_cluster_telematic->battery_cluster_warn_info[i] > 0)
            {
                WARN_MONITOR_LOG_I((int8_t *)"\n [%s:%d] p_cluster_telematic->battery_cluster_warn_info[%d] = 0x%x \n", __func__, __LINE__, i, p_cluster_telematic->battery_cluster_warn_info[i]);
                return OBJ_LEVEL1_WARN_YES;
            }
        }

        // SOC过低报警2级、SOC过高报警2级
        temp = p_cluster_telematic->battery_cluster_warn_info[4] & 0x0C;
        if (temp > 0)
        {
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[4] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[4]);
            return OBJ_LEVEL1_WARN_YES;
        }

        // SOC过低报警3级、SOC过高报警3级
        temp = p_cluster_telematic->battery_cluster_warn_info[7] & 0x0C;
        if (temp > 0)
        {
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[7] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[7]);
            return OBJ_LEVEL1_WARN_YES;
        }
    }

    return OBJ_LEVEL1_WARN_NO;
}

/**
 * @brief   获取一级告警指示灯标志的置位情况
 * @param   null
 * @return 	[int32_t] 执行结果
 * @retval  OBJ_LEVEL1_WARN_NO      无须显示一级告警指示灯
 * @retval  OBJ_LEVEL1_WARN_YES     须要显示一级告警指示灯
 * @retval  <0                      失败，返回错误码
 */
uint32_t level1_warn_indicator_light_get(void)
{
    uint8_t temp = 0;
    uint8_t i;
    uint8_t cluster_index;
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();              // 遥信
    battery_cluster_telematic_info_t *p_cluster_telematic = NULL;

    if (NULL == p_telematic_data)
    {
        log_e((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return SF_ERR_NDEF;
    }

    /* CMU储能柜系统 */
    /* 告警信息（地址范围0x1A1~0x230） */
    for (i = 0; i < CONTAINER_SYSTEM_WARN_LEN_BYTE; i++)
    {
        if (p_telematic_data->container_system_warn_info[i] > 0)
        {
        //    WARN_MONITOR_LOG_I((int8_t *)"\n [%s:%d] p_telematic_data->container_system_warn_info[%d] = 0x%x \n", __func__, __LINE__, i, p_telematic_data->container_system_warn_info[i]);
            return OBJ_LEVEL1_WARN_YES;
        }
    }

    /* CMU-1电池柜 电池簇1数据 */
    /* 告警信息 （地址范围0x2E1~0x370） 供电电压欠压报警1级 ~ PACK欠压报警1级（前3字节） */
    for (cluster_index = 0; cluster_index < BCU_DEVICE_NUM; cluster_index++)
    {
        p_cluster_telematic = sdk_shm_battery_cluster_telematic_info_get(cluster_index);
        if (NULL == p_cluster_telematic)
        {
            log_e((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
            return SF_ERR_NDEF;
        }

        // 供电电压欠压报警1级 ~ 馈电电流过流报警1级 （簇端电压欠压报警1级、簇端电压过压报警1级 不判断）
        temp = p_cluster_telematic->battery_cluster_warn_info[0] & 0xE7;
        if (temp > 0)
        {
            WARN_MONITOR_LOG_I((int8_t *)"\n [%s:%d] p_cluster_telematic->battery_cluster_warn_info[0] = 0x%x \n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[0]);
            return OBJ_LEVEL1_WARN_YES;
        }

        // 放电过流报警1级 ~ 充电单体过温报警1级 （SOC过低报警1级、SOC过高报警1级、单体电压过压报警1级、单体电压欠压报警1级、单体压差报警1级 不判断）
        temp = p_cluster_telematic->battery_cluster_warn_info[1] & 0x83;
        if (temp > 0)
        {
            WARN_MONITOR_LOG_I((int8_t *)"\n [%s:%d] p_cluster_telematic->battery_cluster_warn_info[1] = 0x%x \n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[1]);
            return OBJ_LEVEL1_WARN_YES;
        }

        // 充电单体欠温报警1级 ~ PACK欠压报警1级 （PACK过压报警1级、PACK欠压报警1级 不判断）
        temp = p_cluster_telematic->battery_cluster_warn_info[2] & 0x3F;
        if (temp > 0)
        {
            WARN_MONITOR_LOG_I((int8_t *)"\n [%s:%d] p_cluster_telematic->battery_cluster_warn_info[2] = 0x%x \n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[2]);
            return OBJ_LEVEL1_WARN_YES;
        }
    }

    return OBJ_LEVEL1_WARN_NO;
}

/**
 * @brief   获取消防二级告警信号的置位情况
 * @param   null
 * @return 	[int32_t] 执行结果
 * @retval  OBJ_LEVEL2_FIRE_WARN_NO     无消防二级告警
 * @retval  OBJ_LEVEL2_FIRE_WARN_YES    存在消防二级告警
 * @retval  <0                          失败，返回错误码
 */
uint32_t level2_fire_warn_flag_get(void)
{
    uint32_t ret = OBJ_LEVEL2_FIRE_WARN_NO;
    uint8_t temp = 0;
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();              // 遥信

    if (NULL == p_telematic_data)
    {
        log_e((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return SF_ERR_NDEF;
    }

    // 消防二级告警信号
    temp = p_telematic_data->container_system_status_info[2] & 0x04;
    if (temp > 0)
    {
        ret = OBJ_LEVEL2_FIRE_WARN_YES;
    }
    else
    {
        ret = OBJ_LEVEL2_FIRE_WARN_NO;
    }

    return ret;
}

/**
 * @brief   获取二级告警标志的置位情况
 * @param   null
 * @return 	[int32_t] 执行结果
 * @retval  OBJ_LEVEL2_WARN_NO      无二级告警
 * @retval  OBJ_LEVEL2_WARN_YES     存在二级告警
 * @retval  <0                      失败，返回错误码
 */
uint32_t level2_warn_flag_get(void)
{
    int32_t ret = OBJ_LEVEL2_WARN_NO;
    uint8_t cluster_index;
    uint8_t temp;
    battery_cluster_telematic_info_t *p_cluster_telematic = NULL;
    battery_cluster_data_t *p_battery_cluster = NULL;
    battery_cluster_data_t *p_battery_cluster_offset = NULL;

    p_battery_cluster = battery_cluster_data_get();
    for (cluster_index = 0; cluster_index < BCU_DEVICE_NUM; cluster_index++)
    {
        p_battery_cluster_offset = p_battery_cluster + cluster_index;
        {
            if (p_battery_cluster_offset->charge_disable > 0)
            {
                WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] charge_disable = 0x%x, cluster_index = %d \n", __func__, __LINE__, p_battery_cluster_offset->charge_disable, cluster_index);
                return OBJ_LEVEL2_WARN_YES;
            }
            if (p_battery_cluster_offset->discharge_disable > 0)
            {
                WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] discharge_disable = 0x%x, cluster_index = %d \n", __func__, __LINE__, p_battery_cluster_offset->discharge_disable, cluster_index);
                return OBJ_LEVEL2_WARN_YES;
            }
        }

        p_cluster_telematic = sdk_shm_battery_cluster_telematic_info_get(cluster_index);
        if (NULL == p_cluster_telematic)
        {
            log_e((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
            return SF_ERR_NDEF;
        }

        // 供电电压欠压报警2级 ~ 馈电电流过流报警2级
        if (p_cluster_telematic->battery_cluster_warn_info[3] > 0)
        {
            ret = OBJ_LEVEL2_WARN_YES;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[3] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[3]);
            break;
        }

        // 放电过流报警2级 ~ 充电单体过温报警2级 （SOC过低报警2级、SOC过高报警2级 不判断）
        temp = p_cluster_telematic->battery_cluster_warn_info[4] & 0xF3;
        if (temp > 0)
        {
            ret = OBJ_LEVEL2_WARN_YES;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[4] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[4]);
            break;
        }

        // 充电单体欠温报警2级 ~ PACK欠压报警2级
        if (p_cluster_telematic->battery_cluster_warn_info[5] > 0)
        {
            ret = OBJ_LEVEL2_WARN_YES;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[5] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[5]);
            break;
        }

        // CMU与BCU通讯故障(2级)
        temp = p_cluster_telematic->battery_cluster_warn_info[9] & 0x01;
        if (temp > 0)
        {
            ret = OBJ_LEVEL2_WARN_YES;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[9] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[9]);
            break;
        }
    }

    WARN_DEBUG_PRINT((int8_t *)"[%s:%d] ret = %d\n", __func__, __LINE__, ret);
    return ret;
}

/**
 * @brief   获取二级告警指示灯标志的置位情况
 * @param   null
 * @return 	[int32_t] 执行结果
 * @retval  OBJ_LEVEL2_WARN_NO      无须显示二级告警指示灯
 * @retval  OBJ_LEVEL2_WARN_YES     须要显示二级告警指示灯
 * @retval  <0                      失败，返回错误码
 */
uint32_t level2_warn_indicator_light_get(void)
{
    int32_t ret = OBJ_LEVEL2_WARN_NO;
    uint8_t cluster_index;
    uint8_t temp;
    battery_cluster_telematic_info_t *p_cluster_telematic = NULL;

    for (cluster_index = 0; cluster_index < BCU_DEVICE_NUM; cluster_index++)
    {
        p_cluster_telematic = sdk_shm_battery_cluster_telematic_info_get(cluster_index);
        if (NULL == p_cluster_telematic)
        {
            log_e((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
            return SF_ERR_NDEF;
        }

        // 供电电压欠压报警2级 ~ 馈电电流过流报警2级
        if (p_cluster_telematic->battery_cluster_warn_info[3] > 0)
        {
            ret = OBJ_LEVEL2_WARN_YES;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[3] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[3]);
            break;
        }

        // 放电过流报警2级 ~ 充电单体过温报警2级 （SOC过低报警2级、SOC过高报警2级、单体电压过压报警2级（2级）、单体电压欠压报警2级（2级） 不判断）
        temp = p_cluster_telematic->battery_cluster_warn_info[4] & 0xC3;
        if (temp > 0)
        {
            ret = OBJ_LEVEL2_WARN_YES;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[4] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[4]);
            break;
        }

        // 充电单体欠温报警2级 ~ PACK欠压报警2级
        if (p_cluster_telematic->battery_cluster_warn_info[5] > 0)
        {
            ret = OBJ_LEVEL2_WARN_YES;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[5] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[5]);
            break;
        }

        // CMU与BCU通讯故障(2级)
        temp = p_cluster_telematic->battery_cluster_warn_info[9] & 0x01;
        if (temp > 0)
        {
            ret = OBJ_LEVEL2_WARN_YES;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[9] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[9]);
            break;
        }
    }

    WARN_DEBUG_PRINT((int8_t *)"[%s:%d] ret = %d\n", __func__, __LINE__, ret);
    return ret;
}

/**
 * @brief   获取二级告警下对应的pcs禁充禁放状态
 * @param   null
 * @return 	[int32_t] 执行结果
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败，返回错误码
 */
int32_t level2_warn_pcs_chg_dischg_get(pcs_chg_dischg_forbid_control_cmd_type_e *p_type)
{
    int32_t ret = SF_OK;
    pcs_chg_dischg_forbid_control_cmd_type_e type = PCS_CHG_DISCHG_FORBID_OFF;
    uint8_t cluster_index;
    uint8_t temp;
    battery_cluster_telematic_info_t *p_cluster_telematic = NULL;
    battery_cluster_data_t *p_battery_cluster = NULL;
    battery_cluster_data_t *p_battery_cluster_offset = NULL;
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();   // 共享内存-遥信数据

    if(p_telematic_data->container_system_status_info[0] & 0x01)  //禁止充电
    {
        type |= PCS_CHG_FORBID_ON;
    }
    if(p_telematic_data->container_system_status_info[0] & 0x02)  //禁止放电
    {
        type |= PCS_DISCHG_FORBID_ON;
    }

    p_battery_cluster = battery_cluster_data_get();
    for (cluster_index = 0; cluster_index < BCU_DEVICE_NUM; cluster_index++)
    {
        p_battery_cluster_offset = p_battery_cluster + cluster_index;
        {
            if (p_battery_cluster_offset->charge_disable > 0)
            {
                WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] charge_disable = 0x%x, cluster_index = %d \n", __func__, __LINE__, p_battery_cluster_offset->charge_disable, cluster_index);
                type |= PCS_CHG_FORBID_ON;
            }
            if (p_battery_cluster_offset->discharge_disable > 0)
            {
                WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] discharge_disable = 0x%x, cluster_index = %d \n", __func__, __LINE__, p_battery_cluster_offset->discharge_disable, cluster_index);
                type |= PCS_DISCHG_FORBID_ON;
            }
        }

        p_cluster_telematic = sdk_shm_battery_cluster_telematic_info_get(cluster_index);
        if (NULL == p_cluster_telematic)
        {
            log_e((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
            return SF_ERR_NDEF;
        }

        // 供电电压欠压报警2级、供电电压过压报警2级 不判断，不处理

        // PACK温度过温报警2级
        temp = p_cluster_telematic->battery_cluster_warn_info[3] & 0x04;
        if (temp > 0)
        {
            type |= PCS_CHG_DISCHG_FORBID_ON;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[3] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[3]);
            break;
        }

        // 簇端电压欠压报警2级
        temp = p_cluster_telematic->battery_cluster_warn_info[3] & 0x08;
        if (temp > 0)
        {
            type |= PCS_DISCHG_FORBID_ON;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[3] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[3]);
        }

        // 簇端电压过压报警2级
        temp = p_cluster_telematic->battery_cluster_warn_info[3] & 0x10;
        if (temp > 0)
        {
            type |= PCS_CHG_FORBID_ON;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[3] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[3]);
        }

        // 充电过流报警2级
        temp = p_cluster_telematic->battery_cluster_warn_info[3] & 0x20;
        if (temp > 0)
        {
            type |= PCS_CHG_FORBID_ON;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[3] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[3]);
        }

        // 动力端子过温报警2级
        temp = p_cluster_telematic->battery_cluster_warn_info[3] & 0x40;
        if (temp > 0)
        {
            type |= PCS_CHG_DISCHG_FORBID_ON;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[3] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[3]);
            break;
        }

        // 馈电电流过流报警2级 不判断，不处理

        // 放电过流报警2级
        temp = p_cluster_telematic->battery_cluster_warn_info[4] & 0x01;
        if (temp > 0)
        {
            type |= PCS_DISCHG_FORBID_ON;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[4] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[4]);
        }

        // 绝缘过低报警2级
        temp = p_cluster_telematic->battery_cluster_warn_info[4] & 0x02;
        if (temp > 0)
        {
            type |= PCS_CHG_DISCHG_FORBID_ON;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[4] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[4]);
            break;
        }

        // SOC过低报警2级、SOC过高报警2级 不判断，不处理

        // 单体电压过压报警2级
        temp = p_cluster_telematic->battery_cluster_warn_info[4] & 0x10;
        if (temp > 0)
        {
            type |= PCS_CHG_FORBID_ON;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[4] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[4]);
        }

        // 单体电压欠压报警2级
        temp = p_cluster_telematic->battery_cluster_warn_info[4] & 0x20;
        if (temp > 0)
        {
            type |= PCS_DISCHG_FORBID_ON;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[4] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[4]);
        }

        // 单体压差报警2级
        temp = p_cluster_telematic->battery_cluster_warn_info[4] & 0x40;
        if (temp > 0)
        {
            type |= PCS_CHG_DISCHG_FORBID_ON;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[4] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[4]);
            break;
        }

        // 充电单体过温报警2级
        temp = p_cluster_telematic->battery_cluster_warn_info[4] & 0x80;
        if (temp > 0)
        {
            type |= PCS_CHG_FORBID_ON;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[4] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[4]);
        }

        // 充电单体欠温报警2级
        temp = p_cluster_telematic->battery_cluster_warn_info[5] & 0x01;
        if (temp > 0)
        {
            type |= PCS_CHG_FORBID_ON;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[5] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[5]);
        }

        // 放电单体过温报警2级
        temp = p_cluster_telematic->battery_cluster_warn_info[5] & 0x02;
        if (temp > 0)
        {
            type |= PCS_DISCHG_FORBID_ON;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[5] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[5]);
        }

        // 放电单体欠温报警2级
        temp = p_cluster_telematic->battery_cluster_warn_info[5] & 0x04;
        if (temp > 0)
        {
            type |= PCS_DISCHG_FORBID_ON;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[5] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[5]);
        }

        // 单体温差报警2级
        temp = p_cluster_telematic->battery_cluster_warn_info[5] & 0x08;
        if (temp > 0)
        {
            type |= PCS_CHG_DISCHG_FORBID_ON;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[5] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[5]);
            break;
        }

        // SOC差异过大报警2级 不判断，不处理

        // 温升过快报警2级
        temp = p_cluster_telematic->battery_cluster_warn_info[5] & 0x20;
        if (temp > 0)
        {
            type |= PCS_CHG_DISCHG_FORBID_ON;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[5] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[5]);
            break;
        }

        // PACK过压报警2级
        temp = p_cluster_telematic->battery_cluster_warn_info[5] & 0x40;
        if (temp > 0)
        {
            type |= PCS_CHG_FORBID_ON;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[5] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[5]);
        }

        // PACK欠压报警2级
        temp = p_cluster_telematic->battery_cluster_warn_info[5] & 0x80;
        if (temp > 0)
        {
            type |= PCS_DISCHG_FORBID_ON;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[5] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[5]);
        }

        // CMU与BCU通讯故障(2级)
        temp = p_cluster_telematic->battery_cluster_warn_info[9] & 0x01;
        if (temp > 0)
        {
            type |= PCS_CHG_DISCHG_FORBID_ON;
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] battery_cluster_warn_info[9] = %d\n", __func__, __LINE__, p_cluster_telematic->battery_cluster_warn_info[9]);
            break;
        }

        // 已满足禁止充电、禁止放电的条件
        if (type == PCS_CHG_DISCHG_FORBID_ON)
        {
            WARN_MONITOR_LOG_I((int8_t *)"[%s:%d] PCS_CHG_DISCHG_FORBID_ON\n", __func__, __LINE__);
            break;
        }
    }
    WARN_DEBUG_PRINT((int8_t *)"[%s:%d] type = %d\n", __func__, __LINE__, type);
    *p_type = type;

    return ret;
}

