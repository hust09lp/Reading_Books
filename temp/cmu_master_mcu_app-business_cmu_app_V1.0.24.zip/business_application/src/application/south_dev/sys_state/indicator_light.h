/** 
 * @file          indicator_light.h
 * @brief         指示灯外部接口函数说明
 * @author        liangguyao
 * @version       V0.0.1     初始版本
 * @date          2023/09/25
 * @copyright     Copyright (c) 2023 by SofarSolar, All Rights Reserved.
 */


#ifndef __INDICATOR_LIGHT_H__
#define __INDICATOR_LIGHT_H__

#include "data_types.h"

#if (0)
#define INDICATOR_LIGHT_DEBUG_PRINT(...) log_i((const int8_t*)__VA_ARGS__);
#else
#define INDICATOR_LIGHT_DEBUG_PRINT(...) {do {} while(0);}
#endif


/**
 * @brief     指示灯控制处理线程
 * @param     
 * @return    null
 * @note      null
 * @see       null
 */
void *thread_indicator_light_process(void *arg);


#endif  /* __INDICATOR_LIGHT_H__ */