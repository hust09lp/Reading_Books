#ifndef __FAULT_MONITOR_H__
#define __FAULT_MONITOR_H__


#include "data_types.h"


#define OBJ_FAULT_NO                    (0)     // 无故障
#define OBJ_FAULT_YES                   (1)     // 存在故障

#define INDEX_DO_OUT1                   (0)     // 对PCS模块故障IO

#define  SYS_LC_FAULT_START             (3)
#define  SYS_LC_FAULT_LEN_BYTE          (8)     // 集装箱系统和液冷机组的故障信息所占字节数
#define  SYS_LC_FAULT_NUM               (SYS_LC_FAULT_LEN_BYTE * 8)     // 集装箱系统和液冷机组的故障位数量



/** 
 * @brief   故障监测线程相关参数初始化
 * @param
 * @return
 */
void fault_monitor_param_init(void);

/**
 * @brief     获取三级故障标志的置位情况
 * @param     null
 * @return    OBJ_FAULT_NO-无三级故障 OBJ_FAULT_YES-有三级故障
 * @author    sofar team
 * @note      null
 * @see       null
 * @date      2023/2/15
 */
uint8_t three_level_fault_flag_get(void);

/**
 * @brief     获取电池簇的正常下电失败故障的置位情况
 * @param     null
 * @return    DISABLE-无电池簇存在正常下电失败故障  
 *            ENABLE-至少有一簇电池存在正常下电失败故障
 * @author    sofar team
 * @note      null
 * @see       null
 * @date      2023/5/23
 */
uint8_t power_off_fail_flag_get(void);

/**
 * @brief   检测系统是否发生三级故障
 * @param     
 * @return  
 * @author  sofar team
 * @note    包含三个步骤：1. 对电池簇上电前部分需要cmu-mcu1系统置位的故障位，进行检测置位
 *                          (CMU-MCU1的DI输入、电池簇主控版本号一致判断)
 *                       2. 扫描集装箱故障、电池簇3级告警和电池故障信息，判断是否存在三级故障
 *                       3. 若存在三级故障，输出故障IO（对外、对BCU）
 * @date    2023/4/6
*/
void cmu_sys_state_fault_detection(void);



#endif /* __FAULT_MONITOR_H__ */

