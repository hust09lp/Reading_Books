
#ifndef __SYS_STATE_H__
#define __SYS_STATE_H__


#include "data_types.h"

#if (0)
#define CMU_SYS_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else 
#define CMU_SYS_DEBUG_PRINT(...) {do {} while(0);}
#endif

#define OBJ_BATTERY_STATUS_NO           (0)     // 电池主正、主负继电器至少一个未闭合
#define OBJ_BATTERY_STATUS_YES          (1)     // 电池主正、主负继电器皆为闭合状态

#define OBJ_PARA_NORMAL                 (0)
#define OBJ_PARA_UN_NORMAL              (1)

#define OBJ_UPGRADE_NO                  (0)
#define OBJ_UPGRADE_BUSY                (1)

#define WAIT_PCS_RUNNING_TIME_ADD       (120)    // PCS启动等待时间o需压根据安规开机参数时间+2分钟

#define PCS_STATE_CONFIG                (0)     // 瞬态
#define PCS_STATE_STANDBY               (1)     // 稳态 
#define PCS_STATE_STARTUP               (2)     // 瞬态  启动
#define PCS_STATE_RUNNING               (3)     // 稳态
#define PCS_STATE_SHUTDOWN              (4)     // 稳态
#define PCS_STATE_UPGRADE               (5)     // 稳态

#define CLUSTER_NUM_IN_HEAP             (5)         // 正常一堆中电池簇的数量

// Function return value
#define REMOTE_CTRL                     (1)         // 远程控制介入
#define OPERATION_FAILED                (-2)        // 操作失败

// BCU的下电逻辑中，收到正常下电指令的同时需要簇电流小于10A才能正常下电，
// 若收到正常下电指令时簇电流不小于10A，则会进入正常下电失败状态
#define POWER_OFF_CURRENT_UPPER         (16100)     // 正常下电的电流边界值 16100 * 0.1 - 1600 = 10A
#define POWER_OFF_CURRENT_LOWER         (15900)     // 正常下电的电流边界值 15900 * 0.1 - 1600 = -10A

#define CURRENT_DECREASE_WAIT_TIME      (10)         // 簇电流下降的最大等待时间 单位（S）
#define POWER_OFF_FAIL_WAIT_TIME        (5)         // 正常下电失败触发 到 发送故障下电的等待时间


// define cmu system working state
typedef enum
{
    CMU_SYS_STATE_STOP = 0,     // 停机状态:内部开关全开路(主继电器,辅电继电器)
    CMU_SYS_STATE_STANDBY,      // 待机状态:主继电器闭合,上高压结束,PCS/DCDC未启动充放电
    CMU_SYS_STATE_RUNNING,      // 运行状态:主继电器闭合,PCS/DCDC在充放电
    CMU_SYS_STATE_FAULT,        // 故障状态:内部开关全跳开,输出故障IO
    CMU_SYS_STATE_UPGRADE,      // 升级状态:系统升级中
    CMU_SYS_STATE_SLEEP,        // 睡眠状态:主继电器闭合,上高压结束,PCS/DCDC未启动充放电
    CMU_SYS_STATE_MAX,
}cmu_sys_state_e;

// define cmu system battery heap index
typedef enum
{
    BATTERY_HEAP_1 = 0,     // 操作对象-堆1（电池簇1~5）
    BATTERY_HEAP_2 = 1,     // 操作对象-堆2（电池簇6~10）
    BATTERY_HEAP_MAX,
}cmu_battery_heap_e;

// define power off command type
typedef enum
{
    POWER_OFF_TYPE_REMOTE = 0,      // 远程关机
    POWER_OFF_TYPE_FAULT,           // 故障下电
    POWER_OFF_TYPE_OFF_FAILURE,     // 正常下电失败
    POWER_OFF_TYPE_MAX,
}power_off_type_e;

/**
 * @brief     get cmu system working state
 * @param     null
 * @return    system state, data in cmu_sys_state_e
 * @author    sofar team
 * @note      null
 * @see       null
 * @date      2023/2/15
 */
cmu_sys_state_e cmu_sys_state_get(void);

/**
 * @brief     set cmu system working state
 * @param     null
 * @return    system state, data in cmu_sys_state_e
 * @author    sofar team
 * @note      null
 * @see       null
 * @date      2023/2/15
 */
void cmu_sys_state_set(cmu_sys_state_e sys_state);

/**
 * @brief   cmu系统状态管理线程
 * @param   
 * @note    
 * @return  
 */
void sys_state_process_start(void);


#endif /* __SYS_STATE_H__ */
