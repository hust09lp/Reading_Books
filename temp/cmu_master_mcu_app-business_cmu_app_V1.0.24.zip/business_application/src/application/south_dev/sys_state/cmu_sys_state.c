/**
 * @file          cmu_sys_state.c
 * @brief         cmu mcu1 system state manage
 * @company       sofarsolar
 * @author        sofar team
 * @note          base data_shm.h
 * @version       V1.0
 * @date          2023/2/15
*/

#include "cmu_sys_state.h"
#include "battery_fun_interface.h"
#include "process_battery_read.h"
#include "fault_monitor.h"
#include "warn_monitor.h"
#include "indicator_light.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk_public.h"
#include "sofar_log.h"
#include "sofar_errors.h"
#include "data_types.h"
#include "low_power_task.h"

#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>

static cmu_sys_state_e  g_s_sys_state = CMU_SYS_STATE_STOP;         // MCU1的系统状态
static sdk_rtc_t g_power_off_fail_time = {0, 0, 1, 1, 1, 1, 1};     // 记录正常下电失败触发时间
static sdk_rtc_t g_power_off_fault_time = {0, 0, 1, 1, 1, 1, 1};    // 记录故障下电触发时间
static sdk_rtc_t g_power_off_remote_time = {0, 0, 1, 1, 1, 1, 1};   // 记录远程关机触发时间
static sdk_rtc_t g_csu_comm_monitor_time;                           // 保存上次记录的时间点

/**
 * @brief     set system working state
 * @param     [in]sys_state, from cmu_sys_state_e
 * @return    null
 * @author    sofar team
 * @note      null
 * @see       null
 * @date      2023/2/15
*/
void cmu_sys_state_set(cmu_sys_state_e sys_state)
{
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();

    if((sys_state >= CMU_SYS_STATE_MAX) || (NULL == p_telemetry_data))
    {
        CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] param error \n", __func__, __LINE__);
        return;
    }

    CMU_SYS_DEBUG_PRINT((int8_t *)"\n ************ set g_s_sys_state = %x ************\n", sys_state);
    
    g_s_sys_state = sys_state;
    p_telemetry_data->cmu_telemetry_info.cmu_sys_state = g_s_sys_state;
}

/**
 * @brief     get cmu system working state
 * @param     null
 * @return    system state, data in cmu_sys_state_e
 * @author    sofar team
 * @note      null
 * @see       null
 * @date      2023/2/15
 */
cmu_sys_state_e cmu_sys_state_get(void)
{
    return g_s_sys_state;
}

/**
 * @brief     升序排序：不改变原数组值的情况下，对数组值从小到大排序
 * @param     [in] src_data  需要排序的数组
 * @param     [in] len       数组长度(限制最大为256)
 * @param     [out] dst_index 排序后，从小到大的值 依次对应 的数组下标
 * @return    
 * @author    sofar team
 * @note      例：需要排序的数组{2, 3, -1, 4, -5, 3, 2}，长度7，
 *                dst_index为{4, 2, 0, 6, 1, 5, 3}
 * @see       null
 * @date      2023/3/20
*/
static void ascending_sort(const int16_t *src_data, uint8_t len, uint8_t *dst_index)
{
    uint8_t min = 0;
    uint8_t rank = 0;
    uint8_t i = 0;
    uint8_t j = 0;
    uint8_t k = 0;
    int16_t buff[2][256] = {0};

    if ((NULL == src_data) || (NULL == dst_index))
    {
        CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }
    
    for (i = 0; i < len; i++)
    {
        buff[0][i] = src_data[i];
        buff[1][i] = 0;
    }

    // 排序
    for(i = 0; i < len; i++)
    {
        for(j = 0; j < len; j++)
        {
            if (buff[1][j] == 0)
            {
                min = j;
                break;
            }
        }

        for(k = 0; k < len; k++)    // 每一轮最小值
        {
            if((buff[0][k] < buff[0][min]) && (buff[1][k] == 0))
            {
                min = k;
            }
        }

        buff[1][min] = ++rank;
        dst_index[rank - 1] = min;
    }

    // 测试代码
    // CMU_SYS_DEBUG_PRINT((int8_t *)"\n dst_index data:");
    // for(i = 0; i < len; i++)
    // {
    //     CMU_SYS_DEBUG_PRINT((int8_t *)"%3d", dst_index[i]);
    // }
    // CMU_SYS_DEBUG_PRINT((int8_t *)"\n");
}

/**
 * @brief   获取从第i个电池簇开始的N个电池簇的簇端电压
 * @param   [in]  start_id       起始电池簇的id 0~N
 * @param   [in]  number         需获取的数量
 * @param   [out] p_data_buff    电池簇的簇端电压值
 * @return  获取结果
 * @retval  0     成功
 * @retval  <0    失败
 * @author  sofar team
 * @note    (start_id + number)小于等于电池簇实际数量
 * @date    2023/3/21
*/
static int16_t battery_cluster_voltage_get(uint8_t start_id, uint8_t number, uint16_t *p_data_buff)
{
    uint8_t i = 0;
    uint8_t offset = 0;
    battery_cluster_telemetry_info_t *p_data = NULL;

    if ((NULL == p_data_buff) || ((start_id + number) > BCU_DEVICE_NUM))
    {
        CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] param error \n", __func__, __LINE__);
        return -1;
    }

    for (i = start_id; i < number; i++)
    {
        p_data = sdk_shm_battery_cluster_telemetry_info_get(i);

        if (NULL == p_data)
        {
            CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
            return -1;
        }

        p_data_buff[offset++] = p_data->cluster_voltage;
    }

    return 0;
}

/**
 * @brief   获取电池簇主正、主负继电器状态反馈
 * @param   [in] dev_id    电池簇id(0~N)
 * @return  电池簇 i 的主正、主负继电器状态
 * @retval  OBJ_BATTERY_STATUS_YES(1) 正、负继电器皆处于闭合状态
 * @retval  OBJ_BATTERY_STATUS_NO(0) 正、负继电器至少有一个未闭合
 * @author  sofar team
 * @note    null
 * @date    2023/3/21
*/
static uint8_t battery_status_get(uint8_t dev_id)
{
    uint8_t  status_p = 0;
    uint8_t  status_n = 0;
    battery_cluster_telematic_info_t *p_data = sdk_shm_battery_cluster_telematic_info_get(dev_id);

    if (NULL == p_data)
    {
        CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return OBJ_BATTERY_STATUS_NO;
    }
    
    // 具体bit位置见104点表
    status_p = (p_data->battery_cluster_status_info[0]) & 0x01;           // 正继电器状态
    status_n = ((p_data->battery_cluster_status_info[0]) >> 2) & 0x01;    // 副继电器状态

    // CMU_SYS_DEBUG_PRINT((int8_t *)"\n status_p = %d , status_n = %d \n", status_p, status_n); // 测试用

    if ((ENABLE != status_p) || (ENABLE != status_n))
    {
        return OBJ_BATTERY_STATUS_NO;
    }
    else
    {
        return OBJ_BATTERY_STATUS_YES;
    }
}

/**
 * @brief     判断簇端电流是否达到可正常下电的边界值--10A
 * @param     null
 * @return    cluster current is normal or not,
 * @return    OBJ_PARA_NORMAL or OBJ_PARA_UN_NORMAL
 * @author    sofar team
 * @note      null
 * @see       null
 * @date      2023/5/22
*/
static uint8_t cmu_sys_state_judge_bat_current(void)
{
    uint8_t i = 0;
    uint8_t cycle_number = 0;
    uint8_t index = 0;
    battery_cluster_telemetry_info_t *p_battery_telemetry = NULL; // 电池遥测数据
    battery_comm_info_t *p_bat_comm_data = battery_comm_info_get();

    cycle_number = p_bat_comm_data->connect_num;
    if ((cycle_number > BCU_DEVICE_NUM) || (cycle_number == 0))
    {
        CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] connect_num error \n", __func__, __LINE__);
        return OBJ_PARA_UN_NORMAL;
    }

    // if any bat cluster current overflow 10A, then un-normal
    for(i = 0; i < cycle_number; i++)
    {
        index = p_bat_comm_data->battery_id_connect[i];
        if (index >= BCU_DEVICE_NUM)
        {
            CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] battery_id_connect error \n", __func__, __LINE__);
            return OBJ_PARA_UN_NORMAL;
        }

        p_battery_telemetry = sdk_shm_battery_cluster_telemetry_info_get(index);

        if (NULL == p_battery_telemetry)
        {
            CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
            return OBJ_PARA_UN_NORMAL;
        }

        if(((p_battery_telemetry->cluster_current) >= POWER_OFF_CURRENT_UPPER) \
            || ((p_battery_telemetry->cluster_current) <= POWER_OFF_CURRENT_LOWER))
        {
            CMU_SYS_DEBUG_PRINT((int8_t *)"\n cluster_current = %d cluster id = %x \n", p_battery_telemetry->cluster_current, i);
            return OBJ_PARA_UN_NORMAL;
        }
    }
    
    return OBJ_PARA_NORMAL;
}

/**
 * @brief     记录触发下电动作的时间
 * @param     null
 * @return    null
 * @author    sofar team
 * @note      目前有三种情况会触发下电动作：
 *            1. 正常下电故障发生后5S，需要通过故障下电指令使电池簇下高压
 *            2. 收到远程关机指令，需先检测簇电流是否均小于10A，小于则发送正常下电指令，
 *               如距离收到指令已间隔8S簇电流还未小于10A，发送故障下电。
 *            3. 出现三级故障，触发故障下电，下电流程与远程关机一致（先检电流，若不符合最多等待8S）。
 * @see       null
 * @date      2023/5/23
*/
static void power_off_trigger_time_get(void)
{
    uint8_t temp = 0;
    int32_t ret = -1;
    static uint8_t power_off_fail_bak = DISABLE;    // 记录上一次正常下电失败标志的置位情况
    static uint8_t fault_bak = OBJ_FAULT_NO;        // 记录上一次三级故障标志的置位情况
    static uint16_t remote_bak = REMOTE_POWER_ON;   // 记录上一次远程开关机的情况
    other_parameter_data_t *p_other_data = sdk_shm_other_parameter_data_get(); // 共享内存-其他参数

    if (NULL == p_other_data)
    {
        CMU_SYS_DEBUG_PRINT((int8_t *)"\n [%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    // 出现正常下电失败 从未置位->置位 的状态转变
    temp = power_off_fail_flag_get();
    if ((DISABLE == power_off_fail_bak) && (ENABLE == temp))
    {
        // printf("\n --- power_off_fail get RTC time ----\n"); // 测试代码
        ret = sdk_rtc_get(RTC_BIN_FORMAT, &g_power_off_fail_time);
        if (ret)
        {
            CMU_SYS_DEBUG_PRINT((int8_t *)"\n [%s:%d] power off fail, sdk_rtc_get fail \n", __func__, __LINE__);
        }
    }
    power_off_fail_bak = power_off_fail_flag_get();

    // 出现 从远程开机->远程关机的状态转变
    if ((REMOTE_POWER_ON == remote_bak) && (REMOTE_POWER_OFF == (p_other_data->remote_on_off_ctrl)))
    {
        // printf("\n --- remote off get RTC time ----\n"); // 测试代码
        ret = sdk_rtc_get(RTC_BIN_FORMAT, &g_power_off_remote_time);
        if (ret)
        {
            CMU_SYS_DEBUG_PRINT((int8_t *)"\n [%s:%d] remote off, sdk_rtc_get fail \n", __func__, __LINE__);
        }
    }
    remote_bak = p_other_data->remote_on_off_ctrl;

    // 出现 无故障->有故障的状态转变
    temp = three_level_fault_flag_get();
    if ((OBJ_FAULT_NO == fault_bak) && (OBJ_FAULT_YES == temp))
    {
        // printf("\n --- fault power off get RTC time ----\n"); // 测试代码
        ret = sdk_rtc_get(RTC_BIN_FORMAT, &g_power_off_fault_time);
        if (ret)
        {
            CMU_SYS_DEBUG_PRINT((int8_t *)"\n [%s:%d] fault power off, sdk_rtc_get fail \n", __func__, __LINE__);
        }
    }
    fault_bak = three_level_fault_flag_get();
}

/**
 * @brief   控制电池所有簇下电
 * @param   [in] trigger_time 指令触发时间 
 * @param   [in] command_type 指令类型      POWER_OFF_TYPE_REMOTE-远程关机
 *               (具体见power_off_type_e)   POWER_OFF_TYPE_FAULT-故障下电
 *                                         POWER_OFF_TYPE_OFF_FAILURE-正常下电失败
 * @return  
 * @retval  SF_OK(0)   成功
 * @retval  <0         失败
 * @author  sofar team
 * @note    远程关机或故障下电流程：
 *          1. 检测电池簇是否已上高压   2. 若有电池簇已上高压，检测所有簇的簇电流是否均小于10A
 *          3. 若所有簇的簇电流均小于10A，发送正常下电指令
 *          4. 若距离收到下电标志已等待了10S，且簇电流仍未小于10A，发送所有簇故障下电指令
 *          正常下电失败时下电流程：
 *          1. 检测电池簇是否已上高压   2. 若有电池簇已上高压，等待5S后，下发故障下电指令
 * @date    2023/5/24
*/
static int16_t battery_power_off_all(sdk_rtc_t trigger_time, power_off_type_e command_type)
{
    bool flag = false;
    uint8_t i = 0;
    uint8_t result = 0;
    int16_t ret = 0;
    int32_t time_over = 0;
    uint32_t time_out = 0;       // 超时时间

    for (i = 0; i < BCU_DEVICE_NUM; i++)
    {
        result = battery_status_get(i);
        if (OBJ_BATTERY_STATUS_YES == result)
        {
            flag = true;
            break;
        }
    }

    if ((POWER_OFF_TYPE_REMOTE == command_type) || (POWER_OFF_TYPE_FAULT == command_type))
    {
        time_out = CURRENT_DECREASE_WAIT_TIME;
    }
    else if (POWER_OFF_TYPE_OFF_FAILURE == command_type)
    {
        time_out = POWER_OFF_FAIL_WAIT_TIME;
    }
    else
    {
        ret = -1;
        goto __exit;
    }

    if (true == flag)
    {
        // printf("\n need send power off command! \n"); // 测试
        time_over = sdk_is_time_over(&trigger_time, time_out); // 超时判断

        if ((POWER_OFF_TYPE_REMOTE == command_type) || (POWER_OFF_TYPE_FAULT == command_type))
        {
            // printf("\n POWER_OFF_TYPE_REMOTE/POWER_OFF_TYPE_FAULT \n"); // 测试
            result = cmu_sys_state_judge_bat_current();
            if (OBJ_PARA_NORMAL == result)
            {
                ret = battery_power_control(POWER_OFF, 0);  // 所有簇正常下电
                CMU_SYS_DEBUG_PRINT((int8_t *)"\n [power off] because remote or fault!!! \n");
                goto __exit;
            }

            if ((OBJ_PARA_UN_NORMAL == result) && (1 == time_over))
            {
                // 所有簇故障下电--为避免需要频繁重启电池，调试阶段先下发正常下电指令
#if 0
                ret = battery_power_control(FAULT_POWER_OFF_ALL, 0);
#else
                ret = battery_power_control(POWER_OFF, 0);
#endif
                CMU_SYS_DEBUG_PRINT((int8_t *)"\n [fault power off] because remote or fault!!! \n");
            }
        }
        else if (POWER_OFF_TYPE_OFF_FAILURE == command_type)
        {
            // printf("\n POWER_OFF_TYPE_OFF_FAILURE \n"); // 测试
            if (1 == time_over)
            {
                // 所有簇故障下电--为避免需要频繁重启电池，调试阶段先下发正常下电指令
#if 0
                ret = battery_power_control(FAULT_POWER_OFF_ALL, 0);
#else
                ret = battery_power_control(POWER_OFF, 0);
#endif
                CMU_SYS_DEBUG_PRINT((int8_t *)"\n [fault power off] because power off fail!!! \n");
            }
        }
        else
        {
            ret = -1;
        }
    }

__exit:
    return ret;
}

/**
 * @brief     judge battery's resistance
 * @param     null
 * @return    resistance is normal or not,
 * @return    OBJ_PARA_NORMAL or OBJ_PARA_UN_NORMAL
 * @author    sofar team
 * @note      null
 * @see       null
 * @date      2023/2/15
*/
static uint8_t cmu_sys_state_judge_bat_resis(void)
{
    uint8_t i = 0;
    uint8_t cycle_number = 0;
    uint8_t connect_num = 0;
    uint8_t index = 0;
    battery_cluster_telemetry_info_t *p_battery_telemetry = NULL; // 电池遥测数据
    battery_parameter_data_t *p_battery_param = NULL; // 电池定值参数数据
    battery_comm_info_t *p_bat_comm_data = battery_comm_info_get();

    if (NULL == p_bat_comm_data)
    {
        CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return OBJ_PARA_UN_NORMAL;
    }

    connect_num = p_bat_comm_data->connect_num;
    if ((connect_num > BCU_DEVICE_NUM) || (connect_num == 0))
    {
        CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] connect_num error \n", __func__, __LINE__);
        return OBJ_PARA_UN_NORMAL;
    }

    if(CMU_SYS_STATE_STOP == g_s_sys_state)
    {
        cycle_number = connect_num;

        // if any bat resistance overflow resis_th, then un-normal
        for(i = 0; i < cycle_number; i++)
        {
            index = p_bat_comm_data->battery_id_connect[i];
            if (index >= BCU_DEVICE_NUM)
            {
                CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] battery_id_connect error \n", __func__, __LINE__);
                return OBJ_PARA_UN_NORMAL;
            }
            
            p_battery_telemetry = sdk_shm_battery_cluster_telemetry_info_get(index);
            p_battery_param = sdk_shm_battery_parameter_data_get(index);
            

            if ((NULL == p_battery_telemetry) || (NULL == p_battery_param) || (NULL == p_bat_comm_data))
            {
                CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
                return OBJ_PARA_UN_NORMAL;
            }
            
            // 3级
            if((p_battery_telemetry->positive_insulation_resistance) < (p_battery_param->ISO_warn_threshold_2))
            {
                CMU_SYS_DEBUG_PRINT((int8_t *)"\n p_battery_telemetry->positive_insulation_resistance = %d p_battery_param->ISO_warn_threshold_3 = %d \n", p_battery_telemetry->positive_insulation_resistance, p_battery_param->ISO_warn_threshold_3);
                CMU_SYS_DEBUG_PRINT((int8_t *)"\n p_battery_telemetry->negative_insulation_resistance = %d p_battery_param->ISO_warn_threshold_3 = %d \n", p_battery_telemetry->negative_insulation_resistance, p_battery_param->ISO_warn_threshold_3);

                CMU_SYS_DEBUG_PRINT((int8_t *)"\n positive insulation resistance abnormal!  cluster id = %x\n", i);

                return OBJ_PARA_UN_NORMAL;
            }
            
            // 负绝缘阻抗
            if((p_battery_telemetry->negative_insulation_resistance) < (p_battery_param->ISO_warn_threshold_2))
            {
                CMU_SYS_DEBUG_PRINT((int8_t *)"\n p_battery_telemetry->positive_insulation_resistance = %d p_battery_param->ISO_warn_threshold_3 = %d \n", p_battery_telemetry->positive_insulation_resistance, p_battery_param->ISO_warn_threshold_3);
                CMU_SYS_DEBUG_PRINT((int8_t *)"\n p_battery_telemetry->negative_insulation_resistance = %d p_battery_param->ISO_warn_threshold_3 = %d \n", p_battery_telemetry->negative_insulation_resistance, p_battery_param->ISO_warn_threshold_3);
        
                CMU_SYS_DEBUG_PRINT((int8_t *)"\n negative insulation resistance abnormal!  cluster id = %x\n", i);

                return OBJ_PARA_UN_NORMAL;
            }
        }
    }
    else if (CMU_SYS_STATE_STANDBY == g_s_sys_state)
    {
        if (connect_num > 2)
        {
            cycle_number = 2;
        }
        else
        {
            cycle_number = connect_num;
        }
        
        // if any bat resistance overflow resis_th, then un-normal
        for(i = 0; i < cycle_number; i++)
        {
            // 上高压后，每堆只由其中一个BCU做绝缘阻抗检测 暂定检 已连接的第一簇和最后一簇
            index = p_bat_comm_data->battery_id_connect[i * (connect_num - 1)];
            if (index >= BCU_DEVICE_NUM)
            {
                CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] battery_id_connect error \n", __func__, __LINE__);
                return OBJ_PARA_UN_NORMAL;
            }

            p_battery_telemetry = sdk_shm_battery_cluster_telemetry_info_get(index);
            p_battery_param = sdk_shm_battery_parameter_data_get(index);

            if ((NULL == p_battery_telemetry) || (NULL == p_battery_param))
            {
                CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
                return OBJ_PARA_UN_NORMAL;
            }

            // 3级
            if(p_battery_telemetry->positive_insulation_resistance < p_battery_param->ISO_warn_threshold_2)
            {
                CMU_SYS_DEBUG_PRINT((int8_t *)"\n p_battery_telemetry->positive_insulation_resistance = %d p_battery_param->ISO_warn_threshold_3 = %d \n", p_battery_telemetry->positive_insulation_resistance, p_battery_param->ISO_warn_threshold_3);
                CMU_SYS_DEBUG_PRINT((int8_t *)"\n p_battery_telemetry->negative_insulation_resistance = %d p_battery_param->ISO_warn_threshold_3 = %d \n", p_battery_telemetry->negative_insulation_resistance, p_battery_param->ISO_warn_threshold_3);

                CMU_SYS_DEBUG_PRINT((int8_t *)"\n positive insulation resistance abnormal!  cluster id = %x\n", (i * 5));

                return OBJ_PARA_UN_NORMAL;
            }
                
            // 负绝缘阻抗
            if(p_battery_telemetry->negative_insulation_resistance < p_battery_param->ISO_warn_threshold_2)
            {
                CMU_SYS_DEBUG_PRINT((int8_t *)"\n p_battery_telemetry->positive_insulation_resistance = %d p_battery_param->ISO_warn_threshold_3 = %d \n", p_battery_telemetry->positive_insulation_resistance, p_battery_param->ISO_warn_threshold_3);
                CMU_SYS_DEBUG_PRINT((int8_t *)"\n p_battery_telemetry->negative_insulation_resistance = %d p_battery_param->ISO_warn_threshold_3 = %d \n", p_battery_telemetry->negative_insulation_resistance, p_battery_param->ISO_warn_threshold_3);
            
                CMU_SYS_DEBUG_PRINT((int8_t *)"\n negative insulation resistance abnormal!  cluster id = %x\n", (i * 5));

                return OBJ_PARA_UN_NORMAL;
            }
        }
    }
    else
    {
        return OBJ_PARA_UN_NORMAL;
    }
    
    return (OBJ_PARA_NORMAL);
}


/**
 * @brief     judge battery's high voltage
 * @param     null
 * @return    high voltage is normal or not,
 * @return    OBJ_PARA_NORMAL or OBJ_PARA_UN_NORMAL
 * @author    sofar team
 * @note      null
 * @see       null
 * @date      2023/2/15
*/
static uint8_t cmu_sys_state_judge_bat_high_volt(void)
{
    uint8_t i = 0;
    uint8_t cycle_number = 0;
    uint8_t index = 0;
    battery_cluster_telemetry_info_t *p_battery_telemetry = NULL; // 电池遥测数据
    battery_parameter_data_t *p_battery_param = NULL; // 电池定值参数数据
    battery_comm_info_t *p_bat_comm_data = battery_comm_info_get();

    if (NULL == p_bat_comm_data)
    {
        CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return OBJ_PARA_UN_NORMAL;
    }

    cycle_number = p_bat_comm_data->connect_num;
    if ((cycle_number > BCU_DEVICE_NUM) || (cycle_number == 0))
    {
        CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] connect_num error \n", __func__, __LINE__);
        return OBJ_PARA_UN_NORMAL;
    }

    // if any bat high voltage overflow volt_th, then un-normal
    for(i = 0; i < cycle_number; i++)
    {
        index = p_bat_comm_data->battery_id_connect[i];
        if (index >= BCU_DEVICE_NUM)
        {
            CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] battery_id_connect error \n", __func__, __LINE__);
            return OBJ_PARA_UN_NORMAL;
        }
            
        p_battery_telemetry = sdk_shm_battery_cluster_telemetry_info_get(index);
        p_battery_param = sdk_shm_battery_parameter_data_get(index);

        if ((NULL == p_battery_telemetry) || (NULL == p_battery_param))
        {
            CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
            return OBJ_PARA_UN_NORMAL;
        }

        if(p_battery_telemetry->cluster_voltage > \
           p_battery_param->cluster_OVP_warn_threshold_3)
        {
            CMU_SYS_DEBUG_PRINT((int8_t *)"\n cluster_voltage = %d cluster_OVP_warn_threshold_3 = %d\n", p_battery_telemetry->cluster_voltage, p_battery_param->cluster_OVP_warn_threshold_3);
            CMU_SYS_DEBUG_PRINT((int8_t *)"\n cluster OVP!  cluster id = %x \n", i);
            return OBJ_PARA_UN_NORMAL;
        }
        
        if(p_battery_telemetry->cluster_voltage < \
           p_battery_param->cluster_UVP_warn_threshold_3)
        {
            CMU_SYS_DEBUG_PRINT((int8_t *)"\n cluster_voltage = %d cluster_UVP_warn_threshold_3 = %d \n", p_battery_telemetry->cluster_voltage, p_battery_param->cluster_UVP_warn_threshold_3);
            CMU_SYS_DEBUG_PRINT((int8_t *)"\n cluster UVP!  cluster id = %x \n", i);
            return OBJ_PARA_UN_NORMAL;
        }
    }
    
    return OBJ_PARA_NORMAL;
}


/**
 * @brief     get pcs working state
 * @param     bull
 * @return    pcs state,
 * @return    PCS状态机主状态: 0=config  1=wait  2=check  3=normal  4=shutdown 5=upgrade
 * @author    sofar team
 * @note      null
 * @see       null
 * @date      2023/2/15
*/
static uint8_t cmu_sys_state_get_pcs_state(void)
{
    uint8_t ret;
    heartbeat_data_t *p_heartbeat_data = sdk_shm_heartbeat_data_get();

    ret = p_heartbeat_data->fsm_state[0];
    CMU_SYS_DEBUG_PRINT((int8_t *)"\n pcs fsm_state = %x \n", ret);
    
    return ret;
}


/**
 * @brief     get system is upgrading or not
 * @param     null
 * @return    OBJ_UPGRADE_NO or OBJ_UPGRADE_BUSY
 * @author    sofar team
 * @note      null
 * @see       null
 * @date      2023/2/15
*/
static uint8_t cmu_sys_state_get_upgrade(void)
{
    //have no addr
    firmware_update_t *p_update = sdk_shm_firmware_update_info_get();
    if (NULL == p_update)
    {
        return OBJ_UPGRADE_NO;
    }

    if (UPDATING == p_update->state)
    {
        return OBJ_UPGRADE_BUSY;
    }
    
    return OBJ_UPGRADE_NO;
}

/**
 * @brief     禁充、禁放状态检测
 * @param     
 * @return    
 * @author    sofar team
 * @note      禁充、禁放状态有三个数据来源：1. MCU2反馈 2. 电池簇反馈 3.当SOC过高或者过低时(超过了设置的值)
 *            两个来源中任何一个出现禁充/禁放状态，均需对共享内存中
 *            集装箱状态信息-禁止充/放电状态位进行置位
 * @date      2024/3/5
 */
static void get_charge_discharge_status(uint8_t *p_forbid_charge, uint8_t *p_forbid_discharge)
{
    uint16_t current_soc = 0;  //当前系统的SOC值
    int16_t total_current;   //电流
 
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();              // 遥测

    total_current = p_telemetry_data->container_system_telemetry_info.total_current;
    /*当前电池系统的SOC值(平均),精度0.1*/
    current_soc = p_telemetry_data->container_system_telemetry_info.soc;
    if(current_soc >= p_para_data->soc_charge_limit * 10)
    {
        // 容测模式下 SOC上限设置为100时不限制禁充
        if(p_para_data->battery_cap_test_flag & 0x01)
        {
            if(p_para_data->soc_charge_limit < 100)
            {
               *p_forbid_charge = 1; 
            }
        }
        // 非容测模式下SOC上限设置为100时禁充
        else
        {
            *p_forbid_charge = 1; 
        }
    }
    else if(current_soc <= (p_para_data->soc_charge_limit * 10 - 20))
    {
        *p_forbid_charge = 0;
    }

    if(current_soc <= p_para_data->soc_discharge_limit * 10)
    {
        // 容测模式下 SOC下限设置为0时不限制禁放
        if(p_para_data->battery_cap_test_flag & 0x01)
        {
            if ( p_para_data->soc_discharge_limit > 0 )
            {
                *p_forbid_discharge = 1;   
            }
        }
        // 非容测模式下SOC下限设置为0时禁放
        else
        {
            *p_forbid_discharge = 1;
        }    
    }
    else if(current_soc >= (p_para_data->soc_discharge_limit * 10 + 20))
    {
        if(total_current <= -2)
        {
            *p_forbid_discharge = 0;
        }
    }
}

/**
 * @brief     禁充、禁放状态检测
 * @param     
 * @return    
 * @author    sofar team
 * @note      禁充、禁放状态有三个数据来源：1. MCU2反馈 2. 电池簇反馈 3.当SOC过高或者过低时(超过了设置的值)
 *            两个来源中任何一个出现禁充/禁放状态，均需对共享内存中
 *            集装箱状态信息-禁止充/放电状态位进行置位
 * @date      2023/4/3
 */
static void charge_discharge_state_set(void)
{
    uint8_t charge_flag = 0;
    uint8_t discharge_flag = 0;
    static uint8_t charge_forbidden_by_soc = 0;
    static uint8_t discharge_forbidden_by_soc = 0;
    internal_shared_data_t *p_data = internal_shared_data_get(); // 内部共用参数
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();   // 遥信数据

    if ((NULL == p_data) || (NULL == p_telematic_data))
    {
        CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return; 
    }

    // 1. MCU2禁充禁放反馈
    if (ENABLE == p_data->battery_chargedis_disable_mcu2)
    {
        charge_flag = ENABLE;
        discharge_flag = ENABLE;
    }

    // 2. 电池簇禁充禁放反馈 只在运行和待机状态下同步BMS的禁充禁放标志位，因为在关机状态下BMS的禁充禁放标志一直为1
    if(g_s_sys_state == CMU_SYS_STATE_RUNNING || g_s_sys_state == CMU_SYS_STATE_STANDBY || g_s_sys_state == CMU_SYS_STATE_SLEEP )
    {
        if (ENABLE == (p_data->battery_charge_disable))
        {
            charge_flag = ENABLE;
        }

        if (ENABLE == (p_data->battery_discharge_disable))
        {
            discharge_flag = ENABLE;
        }
    }
    
    

    //3. 当前SOC的值不支持充放电,需要禁止充/放电
    get_charge_discharge_status(&charge_forbidden_by_soc, &discharge_forbidden_by_soc);
    if(ENABLE == charge_forbidden_by_soc)
    {
        charge_flag = ENABLE;
    }

    if(ENABLE == discharge_forbidden_by_soc)
    {
        discharge_flag = ENABLE;
    }

    // 禁充、禁放状态位置位
    if (ENABLE == charge_flag)
    {
        // 禁止充电 置位 container_system_status_info[0].bit0
        p_telematic_data->container_system_status_info[0] |= (1 << 0);
    }
    else
    {
        p_telematic_data->container_system_status_info[0] &= ~(1 << 0);
    }

    if (ENABLE == discharge_flag)
    {
        // 禁止放电 置位 container_system_status_info[0].bit1
        p_telematic_data->container_system_status_info[0] |= (1 << 1);
    }
    else
    {
        p_telematic_data->container_system_status_info[0] &= ~(1 << 1);
    }
}




/**
 * @brief     电池簇上电处理
 * @param     [in] start_id         起始电池簇的id 0~N
 * @param     [in] operation_num    需要上电的电池簇数量
 * @return    SF_OK(0)          上电成功
 * @return    REMOTE_CTRL(1)    远程指令介入
 *            <0                失败(SF_ERR_PARA[-1]-非法入参 OPERATION_FAILED[-2]-操作失败 SF_ERR_SEEK[-6]-空指针)
 * @author    sofar team
 * @note      电池簇上电需要分两组进行，前5簇为一组，后5簇为一组
 *            上电步骤分三步：
 *                          1-获取电池簇的簇端电压并进行升序排序
 *                          2-从电压最小的电池簇开始下发上电指令
 *                          3-检测主正、主负继电器状态反馈，皆闭合表示上电成功，可以下发下一簇的上电指令
 * @see       null
 * @date      2023/3/21
 */
static int16_t battery_power_on_handle(uint8_t start_addr, uint8_t operation_num)
{
    uint8_t i = 0;
    uint8_t j = 0;
    uint8_t status_get_count = 60; // 状态反馈查询最大次数
    uint8_t fault = OBJ_FAULT_NO;
    int16_t result = 0;
    int16_t ret = SF_OK;
    uint16_t cluster_voltage_buff[BCU_DEVICE_NUM] = {0};
    uint8_t  battery_power_on_sequence[BCU_DEVICE_NUM] = {0};
    other_parameter_data_t *p_other_data = sdk_shm_other_parameter_data_get(); // 共享内存-其他参数
    battery_cluster_telemetry_info_t *p_battery_telemetry = NULL; // 电池遥测数据
 
    if (((start_addr + operation_num) > BCU_DEVICE_NUM) || (NULL == p_other_data))
    {
        ret = SF_ERR_PARA;
        CMU_SYS_DEBUG_PRINT((int8_t *)"\n [%s:%d] param error \n", __func__, __LINE__);
        goto __exit;
    }

    // 1-获取电池簇的簇端电压并进行升序排序
    result = battery_cluster_voltage_get(start_addr, operation_num, cluster_voltage_buff);

    if (result < 0)
    {
        CMU_SYS_DEBUG_PRINT((int8_t *)"\n battery cluster voltage get fail! \n");
        ret = OPERATION_FAILED;
        goto __exit;
    }
                    
    ascending_sort((int16_t *)cluster_voltage_buff, operation_num, battery_power_on_sequence);

    // 2-从电压最小的电池簇开始下发上电指令
    for (i = 0; i < operation_num; i++)
    {
        fault = three_level_fault_flag_get();

        // 若有远程关机指令下发，或出现3级故障，立即退出
        if ((REMOTE_POWER_OFF == (p_other_data->remote_on_off_ctrl)) || (OBJ_FAULT_YES == fault))
        {
            ret = REMOTE_CTRL;
            goto __exit;
        }

        CMU_SYS_DEBUG_PRINT((int8_t *)"\n [power on] battery power on, cluster id = %x \n", (start_addr + battery_power_on_sequence[i])); // 测试用

        p_battery_telemetry = sdk_shm_battery_cluster_telemetry_info_get(start_addr + battery_power_on_sequence[i]);
        if (NULL == p_battery_telemetry)
        {
            ret = OPERATION_FAILED;
            goto __exit;
        }
        
        // 该簇未连接，不需要上电
        if (BCU_NOT_CONNECT == (p_battery_telemetry->BCU_comm_status))
        {
            continue;
        }
        
        result = battery_power_control(POWER_ON, (start_addr + 1 + battery_power_on_sequence[i]));  // 控制电池上电
        battery_monomer_data_query((start_addr + battery_power_on_sequence[i]), BATTERY_DI_DO_INFO);

        if (SF_OK == result)
        {
            // 3-检测主正、主负继电器状态反馈，皆闭合表示上电成功，可以下发下一簇的上电指令，否则终止上电操作
            for (j = 0; j < status_get_count; j++)
            {
                CMU_SYS_DEBUG_PRINT((int8_t *)"\n j = %d \n", j);
                sleep(2);

                fault = three_level_fault_flag_get();

                // 若有远程关机指令下发，或出现3级故障，立即退出
                if ((REMOTE_POWER_OFF == (p_other_data->remote_on_off_ctrl)) || (OBJ_FAULT_YES == fault))
                {
                    ret = REMOTE_CTRL;
                    goto __exit;
                }

                result = battery_status_get(start_addr + battery_power_on_sequence[i]);

                if (OBJ_BATTERY_STATUS_YES == result)
                {
                    ret = SF_OK;
                    break;
                }
                else
                {
                    battery_monomer_data_query((start_addr + battery_power_on_sequence[i]), BATTERY_DI_DO_INFO);
                    ret = OPERATION_FAILED;
                }
            }

            if (OPERATION_FAILED == ret)
            {
                goto __exit;
            }
        }
        else
        {
            ret = OPERATION_FAILED;
            goto __exit;
        }
    }

__exit:
    return ret;
}

/**
 * @brief     停机状态的逻辑处理
 * @param     
 * @return    null
 * @author    sofar team
 * @note      电池上高压的条件：1. 绝缘阻抗检测正常 2. 电压检测正常 3. 无3级故障 4. 远程开机 5. 无电池簇禁止充放标志-mcu2上传
 * @see       null
 * @date      2023/4/3
*/
static void stop_state_logical_handle(void)
{
    static uint8_t power_on_fault_count = 0;
    uint8_t fault = OBJ_FAULT_NO;
    uint8_t bat_resis_flag = OBJ_PARA_NORMAL;
    uint8_t bat_volt_flag = OBJ_PARA_NORMAL;
    uint8_t heap_num = 0;
    uint8_t start_addr = 0;
    uint8_t operation_num = 0;
    uint8_t i = 0;
    uint8_t temp = 0;
    int16_t result = SF_OK;
    uint8_t dev_id;
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();   // 共享内存-遥信数据
    other_parameter_data_t *p_other_data = sdk_shm_other_parameter_data_get(); // 共享内存-其他参数
    internal_shared_data_t *p_internal_data = internal_shared_data_get();   // 共享内存-内部共用参数
    battery_cluster_data_t *p_battery_cluster = battery_cluster_data_get();

    if ((NULL == p_telematic_data) || (NULL == p_other_data))
    {
        CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        goto __exit;
    }

    // 1. bat resistance
    bat_resis_flag = cmu_sys_state_judge_bat_resis();

    // 2. bat high voltage
    bat_volt_flag = cmu_sys_state_judge_bat_high_volt();
    
    // 3. fault detection: container cmu and bat fault
    fault = three_level_fault_flag_get();

    if ((OBJ_PARA_UN_NORMAL == bat_resis_flag) || (OBJ_PARA_UN_NORMAL == bat_volt_flag) \
        || (OBJ_FAULT_YES == fault) || (REMOTE_POWER_OFF == p_other_data->remote_on_off_ctrl) \
        || (ENABLE == p_internal_data->battery_chargedis_disable_mcu2))
    {
        CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] The power on conditions are not met! \n", __func__, __LINE__);
        CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] Error: bat_resis_flag = %d \n", __func__, __LINE__, bat_resis_flag);
        CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] Error: bat_volt_flag = %d \n", __func__, __LINE__, bat_volt_flag);
        CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] Error: fault = %d \n", __func__, __LINE__, fault);
        CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] Error: remote_on_off_ctrl = %d \n", __func__, __LINE__, p_other_data->remote_on_off_ctrl);
        CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] Error: battery_chargedis_disable_mcu2 = %d \n", __func__, __LINE__, p_internal_data->battery_chargedis_disable_mcu2);
        goto __exit;
    }

    heap_num = BCU_DEVICE_NUM / CLUSTER_NUM_IN_HEAP;
    if (0 != (BCU_DEVICE_NUM % CLUSTER_NUM_IN_HEAP))
    {
        heap_num++;
    }
    
    // 轮询所有簇，在上电处理函数中判断该簇是否已连接，仅给已连接的簇下发上电指令
    for (i = 0; i < heap_num; i++)
    {
        start_addr = i * CLUSTER_NUM_IN_HEAP;
        
        temp = BCU_DEVICE_NUM - start_addr;
        if (temp >= CLUSTER_NUM_IN_HEAP)
        {
            operation_num = CLUSTER_NUM_IN_HEAP;
        }
        else
        {
            operation_num = temp;
        }

        if ((OBJ_FAULT_YES == fault) || (REMOTE_POWER_OFF == p_other_data->remote_on_off_ctrl))
        {
            goto __exit;
        }

        // 电池上高压的时间较长，为及时响应远程开关机的指令，在上电流程中加入对远程开关机标志的判断
        result = battery_power_on_handle(start_addr, operation_num);

        if (SF_OK == result)
        {
            continue;
        }
        else if ((result < 0) && (OBJ_FAULT_NO == fault) && (REMOTE_POWER_ON == p_other_data->remote_on_off_ctrl))
        {
            // 上电过程中若远程关机指令介入或出现严重故障会影响上电时对电池主正、主负继电器状态的判断，
            // 只有在无严重故障且远程开机状态时出现上电失败才认为是存在未知故障导致上电不成功
            power_on_fault_count++;
            CMU_SYS_DEBUG_PRINT((int8_t *)"\n [error] BATTERY_HEAP_%d battery power on fail! \n", i);  // 测试用

            if (power_on_fault_count >= 3)
            {
                power_on_fault_count = 3;

                // 电池簇上电失败故障 置位 container_system_fault_info[0].bit1
                p_telematic_data->container_system_fault_info[0] |= (1 << 1);
            }

            goto __exit;
        }
        else
        {
            goto __exit;
        }
    }

    // sys to be standby
    power_on_fault_count = 0;
    for (dev_id = 0; dev_id < BCU_DEVICE_NUM; dev_id++)
    {
        if (BCU_NOT_CONNECT != p_battery_cluster->BCU_comm_status)
        {
            battery_auxpower_relay_control(dev_id, true);
        }
    }
    cmu_sys_state_set(CMU_SYS_STATE_STANDBY);

__exit:
    return;
}

/**
 * @brief   获取保存上次记录时间点的全局变量的指针
 * @param   
 * @return  (static修饰的)全局变量的地址作为返回值
 */
static sdk_rtc_t *csu_comm_monitor_time_get(void)
{
    return &g_csu_comm_monitor_time;
}

/**
 * @brief   CSU通讯状态时间记录
 * @param   [in] p_rtc_time 当前的RTC时间结构体指针
 * @note    g_operating_time_record 记录保存运行的时间
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
static int32_t csu_comm_monitor_time_set(sdk_rtc_t *p_rtc_time)
{
    int32_t ret = 0;
    sdk_rtc_t *p_record = csu_comm_monitor_time_get();

    if (p_record == NULL || p_rtc_time == NULL)
    {
        ret = -1;
    }
    else
    {
        p_record->tm_year = p_rtc_time->tm_year;
        p_record->tm_mon = p_rtc_time->tm_mon;
        p_record->tm_day = p_rtc_time->tm_day;
        p_record->tm_hour = p_rtc_time->tm_hour;
        p_record->tm_min = p_rtc_time->tm_min;
        p_record->tm_sec = p_rtc_time->tm_sec;
        p_record->tm_weekday = p_rtc_time->tm_weekday;
    }
    return ret;
}


/**
 * @brief     csu通讯状态监控
 * @param     
 * @return    null
*/
static void csu_comm_status_monitor(void)
{
    static uint8_t timer_init_flag = 0;
    static uint16_t csu_comm_hb_miss_cnt = 0;
    sdk_rtc_t rtc_time;
    internal_shared_data_t *p_shared_data =  internal_shared_data_get();
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get(); 

    if(!timer_init_flag)
    {
        sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
        csu_comm_monitor_time_set(&rtc_time);
        timer_init_flag = 1;
    }

    sdk_rtc_t *p_record = csu_comm_monitor_time_get();
    if(sdk_is_time_over(p_record, 10) == 1)
    {
        if(!p_shared_data->csu_hb_recv_flag)
        {
            csu_comm_hb_miss_cnt++;
        }
        else
        {
            csu_comm_hb_miss_cnt = 0;
            p_shared_data->csu_hb_recv_flag = 0;
            p_telematic_data->CMU_system_fault_info[1] &= ~ (1<<4);
        }
        sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
        csu_comm_monitor_time_set(&rtc_time);
    }
    if(csu_comm_hb_miss_cnt >= 3)
    {
        p_telematic_data->CMU_system_fault_info[1] |= (1<<4);
    }
}


/**
 * @brief     cmu system working state manage process
 * @param     [process_time_s]: process time, second
 * @return    null
 * @author    sofar team
 * @note      null
 * @see       null
 * @date      2023/2/15
 */
void *thread_sys_state_process(void *arg)
{
    int32_t ret;
    uint8_t status_flag = OBJ_BATTERY_STATUS_NO;
    bool    id_error_flag = false;
    uint8_t pcs_state;
    uint8_t dev_id;
    uint8_t temp = 0;
    uint8_t i = 0;
    uint8_t fault_flag_level_3 = OBJ_FAULT_NO; // 记录是否有三级故障发生 0-无三级故障 1-有三级故障
    int32_t level2_warn_flag = OBJ_LEVEL2_WARN_NO;
    pcs_chg_dischg_forbid_control_cmd_type_e pcs_chg_dischg_forbid_cmd = PCS_CHG_DISCHG_FORBID_OFF;
    pcs_chg_dischg_forbid_control_cmd_type_e pcs_chg_dischg_forbid_state = PCS_CHG_DISCHG_FORBID_OFF;
    pcs_chg_dischg_forbid_control_cmd_type_e temp_type = PCS_CHG_DISCHG_FORBID_OFF;
    uint32_t process_time_ms = 500;
    uint32_t pcs_running_cont = 0;
    uint32_t pcs_poweron_faile_count = 0;
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();   // 共享内存-遥信数据
    other_parameter_data_t *p_other_data = sdk_shm_other_parameter_data_get(); // 共享内存-其他参数
    battery_comm_info_t *p_bat_comm_data = battery_comm_info_get();
    battery_cluster_data_t *p_battery_cluster = battery_cluster_data_get();
    constant_parameter_data_t *p_constant_parameter = sdk_shm_constant_parameter_data_get();    // 共享内存-定值/参数
    web_control_info_t *p_web_data = shm_web_control_info_get();    // web 控制操作数据
    internal_shared_data_t *p_internal_data = internal_shared_data_get(); // 内部共用参数
    uint32_t pcs_power_timeout = 0;

    if ((NULL == p_other_data) || (NULL == p_telematic_data) || (NULL == p_bat_comm_data) || (NULL== p_internal_data))
    {
        CMU_SYS_DEBUG_PRINT((int8_t *)"\n [%s:%d] Null pointer \n", __func__, __LINE__);
        pthread_exit(NULL);
    }
    
    sleep(30);

    CMU_SYS_DEBUG_PRINT((int8_t *)"\n ******* thread_sys_state_process ****** \n");
    
    while(1)
    {
        // sleep how long?
        usleep(1000 * 500);
        
        temp = cmu_sys_state_get_upgrade();

        if(OBJ_UPGRADE_BUSY == temp)
        {
            // sys to be upgrade
            cmu_sys_state_set(CMU_SYS_STATE_UPGRADE);
            
            // sleep how long?
            // sleep(1);
            continue; // if in upgrade, don't check others
        }
      
        csu_comm_status_monitor();
       
        if(p_telematic_data->container_system_fault_info[0] & (1 << 3))
        {
            // PCS开机失败故障触发后延迟10分钟再清除开机失败故障，grumor没有远程关机，继续走上电流程
            if(pcs_poweron_faile_count++ >= 400)
            {
                pcs_poweron_faile_count = 0;
                p_telematic_data->container_system_fault_info[0] &= ~(1 << 3);
            }
        }

        // 禁充禁放状态设置
        charge_discharge_state_set();

        // 验证 远程开关机状态，只有处于远程开机时系统状态管理逻辑才生效
        if (REMOTE_POWER_OFF == (p_other_data->remote_on_off_ctrl))
        {
            pcs_running_cont = 0;
            CMU_SYS_DEBUG_PRINT((int8_t *)"\n remote off 1 \n");
            continue;
        }

        

        // stop to standby
        if((CMU_SYS_STATE_STOP == g_s_sys_state) && (REMOTE_POWER_ON == (p_other_data->remote_on_off_ctrl)))
        {
            stop_state_logical_handle();
        }

        // standby to running
        if((CMU_SYS_STATE_STANDBY == g_s_sys_state) && (REMOTE_POWER_ON == (p_other_data->remote_on_off_ctrl)))
        {
            if (((p_bat_comm_data->connect_num) > BCU_DEVICE_NUM) || (0 == (p_bat_comm_data->connect_num)))
            {
                CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] connect_num error \n", __func__, __LINE__);
                cmu_sys_state_set(CMU_SYS_STATE_STOP);
                continue;
            }

            id_error_flag = false;
            for (i = 0; i < (p_bat_comm_data->connect_num); i++)
            {
                temp = p_bat_comm_data->battery_id_connect[i];
                if (temp >= BCU_DEVICE_NUM)
                {
                    CMU_SYS_DEBUG_PRINT((int8_t *)"[%s:%d] battery_id_connect error \n", __func__, __LINE__);
                    id_error_flag = true;
                    break;
                }

                status_flag = battery_status_get(temp);
                if (OBJ_BATTERY_STATUS_NO == status_flag)
                {
                    break;
                }
            }
            if (id_error_flag)
            {
                continue;
            }

            if (OBJ_BATTERY_STATUS_NO == status_flag)
            {
                cmu_sys_state_set(CMU_SYS_STATE_STOP);
                continue;
            }

            // pcs state
            pcs_state = cmu_sys_state_get_pcs_state();

            // bat resistance
            temp = cmu_sys_state_judge_bat_resis();
            if (OBJ_PARA_NORMAL == temp)
            {
                if (PCS_STATE_RUNNING == pcs_state)
                {
                    // sys to be running
                    cmu_sys_state_set(CMU_SYS_STATE_RUNNING);
                    pcs_running_cont = 0;
                    p_web_data->energy_saving_power_halt_flag = DISABLE;
                    p_internal_data->pcs_fault_restore_flag_query = 0;
                }
                else 
                {
                    // 开机过程置位查询重连标志，CAN线程根据这个标志去查询PCS故障恢复标志位
                    p_internal_data->pcs_fault_restore_flag_query = 1;
                    if(p_internal_data->pcs_fault_restore_flag == 1)
                    {
                        pcs_running_cont = 0;
                    }
                    /* 非低功耗模式下需要 做PCS状态检测 / 状态纠正 /  */
                    pcs_power_timeout = (p_constant_parameter->safety_param.group1[0] > p_constant_parameter->safety_param.group1[2])?\
                    p_constant_parameter->safety_param.group1[0]:p_constant_parameter->safety_param.group1[2];
                    pcs_power_timeout += WAIT_PCS_RUNNING_TIME_ADD;
                    if (pcs_running_cont > ((pcs_power_timeout * 1000) / process_time_ms))
                    {
                        // sys to be stop
                        p_telematic_data->container_system_fault_info[0] |= (1 << 3);
                        pcs_running_cont = 0;
                    //   cmu_sys_state_set(CMU_SYS_STATE_STOP);
                    }
                    else
                    {
                        // 电池簇的绝缘检测处于开启状态，关闭电池簇的绝缘检测，待电池簇的绝缘检测处于关闭状态后，再给PCS开机
                        if (p_battery_cluster->battery_insulation_detection_status != BATT_INSULATION_DETECTION_CTRL_CLOSE)
                        {
                            for (dev_id = 0; dev_id < BCU_DEVICE_NUM; dev_id++)
                            {
                                if (BCU_NOT_CONNECT != p_battery_cluster->BCU_comm_status)
                                {
                                    battery_insulation_detection_control(dev_id, false);
                                }
                            }
                            sleep(1);
                        }
                        else
                        {
                            log_i((int8_t *)"\n pcs power on\n");
                            pcs_power_control(PCS_POWER_ON);
                            pcs_running_cont++;
                        }
                    }
                }                
            }
            else
            {
                // PCS模块已处于运行状态
                if (PCS_STATE_RUNNING == pcs_state)
                {
                    // sys to be running
                    cmu_sys_state_set(CMU_SYS_STATE_RUNNING);
                    pcs_running_cont = 0;
                    p_web_data->energy_saving_power_halt_flag = DISABLE;
                }
            }
        }

        if(CMU_SYS_STATE_FAULT == g_s_sys_state) // fault reset
        {
            fault_flag_level_3 = three_level_fault_flag_get();

            // sys to be stop
            if (OBJ_FAULT_NO == fault_flag_level_3)
            {
                CMU_SYS_DEBUG_PRINT((int8_t *)"\n ******* Fault has been recovered! ********* \n");
                cmu_sys_state_set(CMU_SYS_STATE_STOP);
            }
            else
            {
                sleep(1);
            }
        }

        // running : 1、当存在二级故障时：给PCS发关机指令；2、当二级故障消除时：给PCS发开机指令
        if (CMU_SYS_STATE_RUNNING == g_s_sys_state)
        {
            fault_flag_level_3 = three_level_fault_flag_get();
            if (OBJ_FAULT_NO == fault_flag_level_3) // 无故障
            {
                level2_warn_flag = level2_warn_flag_get();
                ret = level2_warn_pcs_chg_dischg_get(&temp_type);
                if (ret == SF_OK)
                {
                    pcs_chg_dischg_forbid_cmd = temp_type;
                }
                pcs_state = cmu_sys_state_get_pcs_state();
                pcs_chg_dischg_forbid_state = (pcs_chg_dischg_forbid_control_cmd_type_e)(p_constant_parameter->pcs_parameter_data[0].battery_chg_dischg_forbidden);
                if (OBJ_LEVEL2_WARN_YES == level2_warn_flag) // 存在二级告警
                {
                    if (pcs_chg_dischg_forbid_cmd != PCS_CHG_DISCHG_FORBID_OFF)
                    {
                        if (pcs_chg_dischg_forbid_cmd != pcs_chg_dischg_forbid_state)
                        {
                            log_i((int8_t *)"\n level2 warn, pcs_chg_dischg_forbid: cmd = %d\n", pcs_chg_dischg_forbid_cmd);
                            pcs_chg_dischg_forbid_control(pcs_chg_dischg_forbid_cmd);
                        }
                    }
                }
                else
                {
                    // PCS开机
                    if ((PCS_STATE_RUNNING != pcs_state) && (PCS_STATE_STARTUP != pcs_state))
                    {
                        /* 非低功耗模式下需要状态纠正 */
                        log_i((int8_t *)"\n running state, no fault, no level2 warn: pcs power on\n");
                        pcs_power_control(PCS_POWER_ON);
                    }
                    else if (PCS_STATE_RUNNING == pcs_state)
                    {
                        if (pcs_chg_dischg_forbid_cmd != pcs_chg_dischg_forbid_state)
                        {
                            log_i((int8_t *)"\n no level2 warn, pcs_chg_dischg_forbid: cmd = %d\n", pcs_chg_dischg_forbid_cmd);
                            pcs_chg_dischg_forbid_control(pcs_chg_dischg_forbid_cmd);
                        }
                    }
                }
            }
        }
    }

    pthread_exit(NULL);
}

/**
 * @brief     监测是否发生需要电池下电动作的故障，及时响应远程开关机
 * @param     
 * @return    null
 * @author    sofar team
 * @note      null
 * @see       null
 * @date      2023/4/18
 */
void *thread_fault_monitor_process(void *arg)
{
    int16_t ret = -1;
    uint8_t temp = DISABLE;
    uint8_t fault = OBJ_FAULT_NO;
    uint8_t pcs_state;
    cmu_sys_state_e cmu_sys_state;
    other_parameter_data_t *p_other_data = sdk_shm_other_parameter_data_get(); // 共享内存-其他参数
    web_control_info_t *p_web_data = shm_web_control_info_get();    // web 控制操作数据
    static uint8_t pcs_epo_trigger = 0;
    int32_t cmd_ret = -1;
    constant_parameter_data_t *p_constant_data = NULL;
    uint8_t dev_id;
    battery_cluster_data_t *p_battery_cluster = battery_cluster_data_get();

    p_constant_data = sdk_shm_constant_parameter_data_get();
    if (NULL == p_other_data || NULL == p_constant_data)
    {
        CMU_SYS_DEBUG_PRINT((int8_t *)"\n [%s:%d] Null pointer \n", __func__, __LINE__);
        pthread_exit(NULL);
    }
    
    fault_monitor_param_init();

    while(1)
    {
        usleep(1000 * 300); // sleep how long?
        // 给PCS下发紧急关机指令后，要下发一遍关机指令，不然PCS会报EPO故障，导致CMU无法再次上电
        if (ENABLE == pcs_epo_trigger)
        {
            cmd_ret = pcs_power_control(PCS_POWER_OFF);
            if ( SF_OK == cmd_ret)
            {
                pcs_epo_trigger = DISABLE;
            }
        }
        // 检测 MCU1、MCU2、电池是否发生三级故障，对三级故障标志位进行置位
        cmu_sys_state_fault_detection();
        
        // 捕捉下电动作的触发时间，用于后续执行下电流程
        power_off_trigger_time_get();
        cmu_sys_state = cmu_sys_state_get();

        temp = power_off_fail_flag_get();
        if (ENABLE == temp)
        {
            if(cmu_sys_state != CMU_SYS_STATE_UPGRADE)
            {
                cmu_sys_state_set(CMU_SYS_STATE_FAULT);
            }
            ret = battery_power_off_all(g_power_off_fail_time, POWER_OFF_TYPE_OFF_FAILURE);
            if (ret < 0)
            {
                CMU_SYS_DEBUG_PRINT((int8_t *)"\n [%s:%d] operation failed \n", __func__, __LINE__);
            }
            
            CMU_SYS_DEBUG_PRINT((int8_t *)"\n power off fail \n");
            continue;
        }

        // pcs state
        pcs_state = cmu_sys_state_get_pcs_state();

        // cmu system state
        cmu_sys_state = cmu_sys_state_get();
        
        // 响应远程关机
        fault = three_level_fault_flag_get();
        if (REMOTE_POWER_OFF == (p_other_data->remote_on_off_ctrl) || cmu_sys_state == CMU_SYS_STATE_UPGRADE)
        {
            if (CMU_SYS_STATE_STOP == cmu_sys_state)
            {
                if (OBJ_FAULT_YES == fault)
                {
                    // sys to be fault
                    if(cmu_sys_state != CMU_SYS_STATE_UPGRADE)
                    {
                        cmu_sys_state_set(CMU_SYS_STATE_FAULT);
                    }
                }
            }
            else
            {
                if (OBJ_FAULT_NO == fault)
                {
                    // sys to be stop
                    if(cmu_sys_state != CMU_SYS_STATE_UPGRADE)
                    {
                        cmu_sys_state_set(CMU_SYS_STATE_STOP);
                        for (dev_id = 0; dev_id < BCU_DEVICE_NUM; dev_id++)
                        {
                            if (BCU_NOT_CONNECT != p_battery_cluster->BCU_comm_status)
                            {
                                battery_auxpower_relay_control(dev_id, false);
                            }
                        }
                    }
                }
                else
                {
                    if(cmu_sys_state != CMU_SYS_STATE_UPGRADE)
                    {
                        cmu_sys_state_set(CMU_SYS_STATE_FAULT);
                    }
                }
            }

            // PCS关机
            if ((PCS_STATE_RUNNING == pcs_state) || (PCS_STATE_STARTUP == pcs_state) || (p_constant_data->pcs_parameter_data[0].pcs_run == PCS_POWER_ON))
            {
                if (ENABLE == p_web_data->energy_saving_power_halt_flag)
                {
                    log_i((int8_t *)"\n energy_saving_power_halt, pcs power EPO \n");
                    pcs_power_control(PCS_POWER_EPO);
                    pcs_epo_trigger = ENABLE;
                }
                else
                {
                    log_i((int8_t *)"\n remote off pcs power off \n");
                    pcs_power_control(PCS_POWER_OFF);
                }
            }

            // 电池簇关机
            ret = battery_power_off_all(g_power_off_remote_time, POWER_OFF_TYPE_REMOTE);
            if (ret < 0)
            {
                CMU_SYS_DEBUG_PRINT((int8_t *)"\n [%s:%d] operation failed \n", __func__, __LINE__);
            }

            CMU_SYS_DEBUG_PRINT((int8_t *)"\n remote off 2 \n");
        }
        else
        {
            // 若存在三级故障，将电池下电、系统状态置为故障状态
            if (OBJ_FAULT_YES == fault)
            {
                // sys to be fault
                if(cmu_sys_state != CMU_SYS_STATE_UPGRADE)
                {
                    cmu_sys_state_set(CMU_SYS_STATE_FAULT);
                }
                // PCS关机
                if ((PCS_STATE_RUNNING == pcs_state) || (PCS_STATE_STARTUP == pcs_state) || (p_constant_data->pcs_parameter_data[0].pcs_run == PCS_POWER_ON))
                {
                    log_i((int8_t *)"\n Error: fault pcs power off\n");
                    pcs_power_control(PCS_POWER_EPO);
                    pcs_epo_trigger = ENABLE;
                }

                ret = battery_power_off_all(g_power_off_fault_time, POWER_OFF_TYPE_FAULT);
                if (ret < 0)
                {
                    CMU_SYS_DEBUG_PRINT((int8_t *)"\n [%s:%d] operation failed \n", __func__, __LINE__);
                }

                CMU_SYS_DEBUG_PRINT((int8_t *)"\n battery power off because fault!!! \n");
            }
        }
    }

    pthread_exit(NULL);
}

/**
 * @brief   cmu系统状态管理线程
 * @param   
 * @note    
 * @return  
 */
void sys_state_process_start(void)
{
    int16_t ret = 0;
    pthread_attr_t sys_attr;
    pthread_t fault_monitor_process;
    pthread_t sys_state_process;
    pthread_t indicator_light_process;

    // 初始化线程属性
    ret = pthread_attr_init(&sys_attr);
    if (ret)
    {
        CMU_SYS_DEBUG_PRINT((int8_t *)"\n [%s:%d] pthread_attr_init error!!! \n", __func__, __LINE__);
        return; // 线程属性初始化出错退出
    }
    
    // 设置线程属性为分离状态
    ret = pthread_attr_setdetachstate(&sys_attr, PTHREAD_CREATE_DETACHED);
    if (ret)
    {
        CMU_SYS_DEBUG_PRINT((int8_t *)"\n [%s:%d] pthread_attr_setdetachstate sys_attr error!!! \n", __func__, __LINE__);
        return; // 线程分离属性设置出错退出
    }

    // 创建线程
    ret = pthread_create(&fault_monitor_process, &sys_attr, &thread_fault_monitor_process, NULL);
    if (ret)
    {
        CMU_SYS_DEBUG_PRINT((int8_t *)"\n [%s:%d] pthread_create fault_monitor_process error!!! \n", __func__, __LINE__);
        return; // 线程创建出错退出
    }

    ret = pthread_create(&sys_state_process, &sys_attr, &thread_sys_state_process, NULL);
    if (ret)
    {
        CMU_SYS_DEBUG_PRINT((int8_t *)"\n [%s:%d] pthread_create sys_state_process error!!! \n", __func__, __LINE__);
        return; // 线程创建出错退出
    }

    ret = pthread_create(&indicator_light_process, &sys_attr, &thread_indicator_light_process, NULL);
    if (ret)
    {
        CMU_SYS_DEBUG_PRINT((int8_t *)"\n [%s:%d] pthread_create sys_state_process error!!! \n", __func__, __LINE__);
        return; // 线程创建出错退出
    }

    // 销毁线程属性结构,它在重新初始化之前不能重新使用
    pthread_attr_destroy(&sys_attr);
}

