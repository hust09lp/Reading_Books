/** 
 * @file          indicator_light.c
 * @brief         指示灯外部接口函数实现
 * @author        liangguyao
 * @version       V0.0.1     初始版本
 * @date          2023/09/25
 * @copyright     Copyright (c) 2023 by SofarSolar, All Rights Reserved.
 */


#include "indicator_light.h"
#include "cmu_sys_state.h"
#include "warn_monitor.h"
#include "data_shm.h"
#include "sofar_errors.h"
#include "sofar_log.h"
#include "sdk_dido.h"
#include <unistd.h>
#include <pthread.h>


#define INDEX_DO_OUT2                   (1)     // 面板绿灯IO
#define INDEX_DO_OUT3                   (2)     // 面板红灯IO
#define INDEX_DO_OUT4                   (3)     // 面板黄灯IO

#define INDICATOR_LIGHT_CYCLE_1S        (2)     // 指示灯一个周期内（1S），亮或者灭所需的时间 ÷ 250ms
#define INDICATOR_LIGHT_CYCLE_2S        (4)     // 指示灯一个周期内（2S），亮或者灭所需的时间 ÷ 250ms

// define indicator light working state
typedef enum
{
    //                                          指示灯                  状态
    INDICATOR_LIGHT_STATE_GREEN_HALF_HZ = 0,    // 绿色闪烁（0.5Hz）    关机
    INDICATOR_LIGHT_STATE_GREEN,                // 绿色常亮             运行（直/交流继电器已全部闭合）
    INDICATOR_LIGHT_STATE_GREEN_1HZ,            // 绿色闪烁（1Hz）      待机检测
    INDICATOR_LIGHT_STATE_GREEN_2HZ,            // 绿色闪烁（2Hz）      升级
    INDICATOR_LIGHT_STATE_YELLOW,               // 黄色常亮             一级告警
    INDICATOR_LIGHT_STATE_YELLOW_2HZ,           // 黄色闪烁（2Hz）      二级告警
    INDICATOR_LIGHT_STATE_RED,                  // 红色常亮             跳机故障
    INDICATOR_LIGHT_STATE_RED_2HZ,              // 红色闪烁（2Hz）      消防故障
    INDICATOR_LIGHT_STATE_MAX,
}indicator_light_state_e;


/**
 * @brief   获取指示灯应指示的状态
 * @param	null
 * @return 	[indicator_light_state_e]   详见indicator_light_state_e枚举的定义
 */
static indicator_light_state_e indicator_light_state_get(void)
{
    uint32_t ret1;
    uint32_t ret2;
    uint32_t fire_ret;
    indicator_light_state_e indicator_light_state;
    cmu_sys_state_e cmu_sys_state = cmu_sys_state_get();

    switch (cmu_sys_state)
    {
        case CMU_SYS_STATE_STOP:
            indicator_light_state = INDICATOR_LIGHT_STATE_GREEN_HALF_HZ;
            break;

        case CMU_SYS_STATE_STANDBY:
            indicator_light_state = INDICATOR_LIGHT_STATE_GREEN_1HZ;
            break;

        case CMU_SYS_STATE_RUNNING:
            ret1 = level1_warn_indicator_light_get();
            ret2 = level2_warn_indicator_light_get();
            if (OBJ_LEVEL2_WARN_YES == ret2)
            {
                indicator_light_state = INDICATOR_LIGHT_STATE_YELLOW_2HZ;
            }
            else if (OBJ_LEVEL1_WARN_YES == ret1)
            {
                indicator_light_state = INDICATOR_LIGHT_STATE_YELLOW;
            }
            else
            {
                indicator_light_state = INDICATOR_LIGHT_STATE_GREEN;
            }
            break;

        case CMU_SYS_STATE_FAULT:
            fire_ret = level2_fire_warn_flag_get();
            if (OBJ_LEVEL2_FIRE_WARN_YES == fire_ret)
            {
                indicator_light_state = INDICATOR_LIGHT_STATE_RED_2HZ;
            }
            else
            {
                indicator_light_state = INDICATOR_LIGHT_STATE_RED;
            }
            break;

        case CMU_SYS_STATE_UPGRADE:
            indicator_light_state = INDICATOR_LIGHT_STATE_GREEN_2HZ;
            break;

        default:
            indicator_light_state = INDICATOR_LIGHT_STATE_GREEN_HALF_HZ;
            break;
    }

    return indicator_light_state;
}

/**
 * @brief   设置指示灯全灭状态
 * @param	null
 * @return 	[int32_t]   执行结果
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败，返回错误码
 */
static int32_t indicator_light_all_off(void)
{
    int32_t ret;

    ret = sdk_dido_write(INDEX_DO_OUT2, DI_DO_LOW);
    if (ret < SF_OK)
    {
        INDICATOR_LIGHT_DEBUG_PRINT((int8_t *)"\n [%s:%d] write INDEX_DO_OUT2 error: ret = %d \n", __func__, __LINE__, ret);
    }
    ret = sdk_dido_write(INDEX_DO_OUT3, DI_DO_LOW);
    if (ret < SF_OK)
    {
        INDICATOR_LIGHT_DEBUG_PRINT((int8_t *)"\n [%s:%d] write INDEX_DO_OUT3 error: ret = %d \n", __func__, __LINE__, ret);
    }
    ret = sdk_dido_write(INDEX_DO_OUT4, DI_DO_LOW);
    if (ret < SF_OK)
    {
        INDICATOR_LIGHT_DEBUG_PRINT((int8_t *)"\n [%s:%d] write INDEX_DO_OUT4 error: ret = %d \n", __func__, __LINE__, ret);
    }

    return ret;
}

/**
 * @brief   设置绿色指示灯亮灭状态
 * @param	[in] value  设置的值
 * @return 	[int32_t]   执行结果
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败，返回错误码
 */
static int32_t indicator_light_green(bool value)
{
    int32_t ret;

    if (value)
    {
        ret = sdk_dido_write(INDEX_DO_OUT2, DI_DO_HIGH);
    }
    else
    {
        ret = sdk_dido_write(INDEX_DO_OUT2, DI_DO_LOW);
    }
    if (ret < SF_OK)
    {
        INDICATOR_LIGHT_DEBUG_PRINT((int8_t *)"\n [%s:%d] write INDEX_DO_OUT2 error: ret = %d \n", __func__, __LINE__, ret);
    }
    ret = sdk_dido_write(INDEX_DO_OUT3, DI_DO_LOW);
    if (ret < SF_OK)
    {
        INDICATOR_LIGHT_DEBUG_PRINT((int8_t *)"\n [%s:%d] write INDEX_DO_OUT3 error: ret = %d \n", __func__, __LINE__, ret);
    }
    ret = sdk_dido_write(INDEX_DO_OUT4, DI_DO_LOW);
    if (ret < SF_OK)
    {
        INDICATOR_LIGHT_DEBUG_PRINT((int8_t *)"\n [%s:%d] write INDEX_DO_OUT4 error: ret = %d \n", __func__, __LINE__, ret);
    }

    return ret;
}

/**
 * @brief   设置红色指示灯亮灭状态
 * @param	[in] value  设置的值
 * @return 	[int32_t]   执行结果
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败，返回错误码
 */
static int32_t indicator_light_red(bool value)
{
    int32_t ret;
    if (value)
    {
        ret = sdk_dido_write(INDEX_DO_OUT3, DI_DO_HIGH);
    }
    else
    {
        ret = sdk_dido_write(INDEX_DO_OUT3, DI_DO_LOW);
    }
    if (ret < SF_OK)
    {
        INDICATOR_LIGHT_DEBUG_PRINT((int8_t *)"\n [%s:%d] write INDEX_DO_OUT2 error: ret = %d \n", __func__, __LINE__, ret);
    }
    ret = sdk_dido_write(INDEX_DO_OUT2, DI_DO_LOW);
    if (ret < SF_OK)
    {
        INDICATOR_LIGHT_DEBUG_PRINT((int8_t *)"\n [%s:%d] write INDEX_DO_OUT3 error: ret = %d \n", __func__, __LINE__, ret);
    }
    ret = sdk_dido_write(INDEX_DO_OUT4, DI_DO_LOW);
    if (ret < SF_OK)
    {
        INDICATOR_LIGHT_DEBUG_PRINT((int8_t *)"\n [%s:%d] write INDEX_DO_OUT4 error: ret = %d \n", __func__, __LINE__, ret);
    }

    return ret;
}

/**
 * @brief   设置黄色指示灯亮灭状态
 * @param	[in] value  设置的值
 * @return 	[int32_t]   执行结果
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败，返回错误码
 */
static int32_t indicator_light_yellow(bool value)
{
    int32_t ret;

    if (value)
    {
        ret = sdk_dido_write(INDEX_DO_OUT4, DI_DO_HIGH);
    }
    else
    {
        ret = sdk_dido_write(INDEX_DO_OUT4, DI_DO_LOW);
    }
    if (ret < SF_OK)
    {
        INDICATOR_LIGHT_DEBUG_PRINT((int8_t *)"\n [%s:%d] write INDEX_DO_OUT2 error: ret = %d \n", __func__, __LINE__, ret);
    }
    ret = sdk_dido_write(INDEX_DO_OUT2, DI_DO_LOW);
    if (ret < SF_OK)
    {
        INDICATOR_LIGHT_DEBUG_PRINT((int8_t *)"\n [%s:%d] write INDEX_DO_OUT3 error: ret = %d \n", __func__, __LINE__, ret);
    }
    ret = sdk_dido_write(INDEX_DO_OUT3, DI_DO_LOW);
    if (ret < SF_OK)
    {
        INDICATOR_LIGHT_DEBUG_PRINT((int8_t *)"\n [%s:%d] write INDEX_DO_OUT4 error: ret = %d \n", __func__, __LINE__, ret);
    }

    return ret;
}


/**
 * @brief     指示灯控制处理线程
 * @param     
 * @return    null
 * @note      null
 * @see       null
 */
void *thread_indicator_light_process(void *arg)
{
    bool on_off = false;
    uint8_t count = 0;
    indicator_light_state_e indicator_light_state = INDICATOR_LIGHT_STATE_MAX;
    indicator_light_state_e indicator_light_state_bak = INDICATOR_LIGHT_STATE_MAX;

    sleep(32);  // 等待thread_sys_state_process线程起来后再控制指示灯

    INDICATOR_LIGHT_DEBUG_PRINT((int8_t *)"\n ******* thread_indicator_light_process ****** \n");

    while(1)
    {
        usleep(1000 * 250);

        indicator_light_state = indicator_light_state_get();
        if (indicator_light_state != indicator_light_state_bak)
        {
            indicator_light_state_bak = indicator_light_state;
            on_off = true;
            count = 0;
        }

        switch (indicator_light_state)
        {
            case INDICATOR_LIGHT_STATE_GREEN_HALF_HZ:
                indicator_light_green(on_off);
                count++;
                if (count >= INDICATOR_LIGHT_CYCLE_2S)
                {
                    on_off = !on_off;
                    count = 0;
                }
                break;
            
            case INDICATOR_LIGHT_STATE_GREEN:
                indicator_light_green(true);
                break;

            case INDICATOR_LIGHT_STATE_GREEN_1HZ:
                indicator_light_green(on_off);
                count++;
                if (count >= INDICATOR_LIGHT_CYCLE_1S)
                {
                    on_off = !on_off;
                    count = 0;
                }
                break;
            
            case INDICATOR_LIGHT_STATE_GREEN_2HZ:
                indicator_light_green(on_off);
                on_off = !on_off;
                break;

            case INDICATOR_LIGHT_STATE_YELLOW:
                indicator_light_yellow(true);
                break;

            case INDICATOR_LIGHT_STATE_YELLOW_2HZ:
                indicator_light_yellow(on_off);
                on_off = !on_off;
                break;

            case INDICATOR_LIGHT_STATE_RED:
                indicator_light_red(true);
                break;

            case INDICATOR_LIGHT_STATE_RED_2HZ:
                indicator_light_red(on_off);
                on_off = !on_off;
                break;

            default:
                indicator_light_all_off();
                INDICATOR_LIGHT_DEBUG_PRINT((int8_t *)"\n [%s:%d] state error: indicator_light_state = %d \n", __func__, __LINE__, indicator_light_state);
                break;
        }
    }

    pthread_exit(NULL);
}