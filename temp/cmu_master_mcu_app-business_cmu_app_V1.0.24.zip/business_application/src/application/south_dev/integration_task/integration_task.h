#ifndef __INTEGRATION_TASK_H__
#define __INTEGRATION_TASK_H__

#include "data_types.h"


#if (0)
#define INTE_DEBUG_LOG(...) log_i((const int8_t*)__VA_ARGS__);
#else
#define INTE_DEBUG_LOG(...) {do {} while(0);}
#endif


#if 0
typedef enum{
    VERSION_HIGH_VALUE1 = 0x30,
    VERSION_HIGH_VALUE2,
    VERSION_HIGH_VALUE3,
    VERSION_HIGH_VALUE4,
    VERSION_HIGH_VALUE5,
    VERSION_HIGH_VALUE6,
    VERSION_HIGH_VALUE7,
    VERSION_HIGH_VALUE8,

}mcu1_adconvert_range_e;
#endif

#pragma pack(push)
#pragma pack(1)
typedef struct{

    int8_t mcu1_hardware_version[4];       // ASCII码 如V1.0
    int8_t mcu1_core_soft_version[6];      // ASCII码 如V1.0.0

}integrated_version_t;
#pragma pack(pop)


/**
 * @brief  启动综合任务线程
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
void integration_task_start(void);


#endif
