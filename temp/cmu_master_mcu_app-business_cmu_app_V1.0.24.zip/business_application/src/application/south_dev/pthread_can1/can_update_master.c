#include "can_update.h"
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <sys/prctl.h>
#include "data_types.h"
#include <errno.h>
#include <stdlib.h>

#include "sdk_log.h"
#include "sdk_shm.h"
#include <unistd.h>
#include "update_task.h"
#include "data_shm.h"
#include "sofar_errors.h"
#include "pcs_fun_interface.h"
#include "cmu_sys_state.h"
#include "param_record_task.h"
#include "range_check.h"
#include "can_safety.h"

#define MIN(a, b) ((a) < (b) ? (a) : (b))
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define CLAMP(x, min, max) ((x) < (min) ? (min) : ((x) > (max) ? (max) : (x)))

#define MONOMER_TEMP_LOWEST_DIFF_TOO_BIG (10)  //最低单体温度和平均单体温度相差太大

typedef struct {
    int16_t temperature;  // 温度阈值（单位：0.1℃）
    float power_factor;   // 功率系数
} TemperaturePowerProfile;

// SOC < 70% 的配置
static const TemperaturePowerProfile profile_soc_low[] = {
    {0, 0.0},{5, 0.2}, {10, 0.4}, {15, 0.6}, {20, 1.0},
    {45, 1.0}, {50, 0.75}, {55, 0.5}, {60, 0.0}
};

// SOC >= 70% 的配置
static const TemperaturePowerProfile profile_soc_high[] = {
    {0, 0.0},{5, 0.1}, {10, 0.2}, {15, 0.4}, {20, 0.6}, {25, 1.0},
    {45, 0.5}, {50, 0.25}, {55, 0.2}, {60, 0.0}
};

// 放电温度和对应的功率系数配置
static const TemperaturePowerProfile discharge_profile[] = {
    {-10, 0.0}, {0, 0.5}, {10, 0.5},{15, 1.0}, {45, 1.0}, {50, 0.5},{55, 0.5}, {60, 0.0}
};

static update_session_t g_session_master;
ack_status_t g_ack_status = {0}; 
query_status_t g_query_status = {0};
extern pcs_comm_info_t  g_pcs_comm_info;
uint32_t g_crc32;
static uint8_t update_dsp_type = 0;//0代表主DSP，1代表副DSP
fault_record_info_t g_fault_record_info = {0};

#define FILEPATH_UPDATEBIN_DCDC 	"/opt/update/pcs.bin"

#define LITTLE_TO_BIG_UINT16(d)   ((d>>8)|(d<<8))

#define PCS_POWER_LIMIT_SOC_COUNT_MAX	(10)
#define PCS_DISCHARGE_TEMP_SECTION		(6)
#define PCS_CHARGE_TEMP_SECTION_1		(9)
#define PCS_CHARGE_TEMP_SECTION_2		(10)
#define PCS_RET_DIFF_VAL_TEMPERATURE	(2)  //温度回差值
#define PCS_RET_DIFF_VAL_SOC			(50)  //SOC回差值
#define PCS_CHARGE_SOC_LESS_70			(700)	// 精度/单位：0.1/%
#define PCS_CHARGE_SOC_LESS_100			(1000)	// 精度/单位：0.1/%
#define POWER_KW_CONVERT_10W_COEFFICIENT	(100)	// 精度/单位：0.01KW

#define DEV_INFO1_INTERVAL  101
#define DEV_INFO2_INTERVAL  252
#define DEV_PARA1_INTERVAL  253
#define DEV_PARA2_INTERVAL  254

#define BCU_NOT_CONNECT 0    // 未连接
#define BCU_COMM_NORMAL 1    // 通信正常
#define BCU_COMM_BREAK  2    // 通信中断

#define MAX_DISCHG_POWER 30000     	// 放电功率最大限制 精度0.01kw
#define MIN_DISCHG_POWER 0         	// 放电功率最小限制 精度0.01kw

#define MAX_CHG_POWER 0     		// 充电功率最大限制 精度0.01kw
#define MIN_CHG_POWER -30000        // 充电功率最小限制 精度0.01kw

#define PCS_MAX_POWER 30000			// PCS最大功率限制 精度0.01kw
typedef enum
{
	RANGE_HANDLE_TYPE_SOC,
	RANGE_HANDLE_TYPE_TEMP1,
	RANGE_HANDLE_TYPE_TEMP2,
	RANGE_HANDLE_TYPE_END
}RANGE_HANDLE_TYPE_E;

//升级任务的几个阶段
#define STAGE_CANUPDATE_IDLE	1
#define STAGE_CANUPDATE_START	1
#define STAGE_CANUPDATE_DOING	1
#define STAGE_CANUPDATE_DONE	1

uint32_t Dbg_StartDCDCCanUpdate = 0;	//目前通过手动启动
uint32_t gCanUpdateStage = STAGE_CANUPDATE_IDLE;

#define PCS_SIGNATURE_VERSION                   (0x03)                      // 签名信息版本
#define CHIP_ROLE_CODE_PCS                 (0x22)                      // PCS-M芯片角色编码
#define CHIP_ROLE_CODE_PCS_S                (0x23)                      // PCS-S芯片角色编码
#define CHIP_MODEL_CODE_PCS               ("T7")                      // PCS-M芯片代号
#define CHIP_MODEL_CODE_PCS_S               ("T1")                      // PCS-S芯片代号
#define CHIP_MODEL_NUM_PCS                 (0x5437)                      // PCS-M芯片编码
#define CHIP_MODEL_NUM_PCS_S                (0x5431) 

#define PCS_BROADCAST_UPGRADE               1                      // PCS广播升级
#define PCS_UNICAST_UPGRADE                 2                      // PCS单播升级
#define PCS_DATA_QUERY_TIME_INTERVAL_MS    5	// 500 // 100

void data_print(uint8_t *p_data, int32_t len)
{
    CAN_DEBUG_PRINT_DATA("\n data start \n");
    for (uint8_t i = 0; i < len; i++)
    {
        CAN_DEBUG_PRINT_DATA(" %x ", p_data[i]);
    }
	CAN_DEBUG_PRINT_DATA("\n");
    CAN_DEBUG_PRINT_DATA("data end \n");
}

static pcs_firmware_update_task_t g_pcs_update_task;

int32_t pcs_firmware_verification(pcs_firmware_info_t *p_object);

/**
 * @brief  获取mcu2升级任务结构体地址
 * @param  [in] none                           
 * @param  [out] none
 * @return 升级任务结构体地址
 */
pcs_firmware_update_task_t *get_pcs_update_task_stru(void)
{
    return &g_pcs_update_task;
}

static int32_t sdk_system_cmd(int8_t * cmd)
{
	FILE *fp = NULL;

	if((fp=popen((const char*)cmd, "r")) == NULL)
	{
		printf("[%s:%s:%d] %s, cmd:%s\n", __FILE__,__func__, __LINE__, strerror(errno), cmd);
		return -1;
	}
	pclose(fp);

	return 0;
}

/******************************************************************************
**  description    : 延时ms函数
**  parameter      : 
**  		       : 
**  return         : 
******************************************************************************/
void can_update_delay_ms(uint32_t ms)
{
    struct timeval tv;

    tv.tv_sec = 0;        		 	 /*SECOND*/
    tv.tv_usec = (time_t)ms * 1000;  /*MICROSECOND*/

    select(0, NULL, NULL, NULL, &tv);
}

/**************************************
* 功  能: 按字节获取文本文件的长度
* 输  入: file_name 文件路径或名称
* 输  出: 无
* 返  回：文件长度
 * ***********************************/
uint32_t get_file_length(const void *file_name)
{
    uint32_t length = 0;

	struct stat statbuff;
	if(stat((const char *)file_name, &statbuff) < 0){
		return length;
	}else{
		length = statbuff.st_size;
	}
    return length;
}

/****************************************************************************
* 功  能: 按字节获取文本文件的数据内容
* 输  入: file_name路径或名称，start_add偏移地址 data_length数据长度
* 输  出: file_data 数据内容
* 返  回：0为正常，-1为异常
****************************************************************************/
int32_t get_file_data(const void *file_name, uint32_t start_add, uint32_t data_length, uint8_t *file_data)
{
    FILE *fp = NULL;

    fp = fopen((const char*)file_name, "r");
    if(fp == NULL)
    {
        CAN_DEBUG_PRINT("\n [%s:%d] File Open Failed !\n",__func__, __LINE__);
        return -1;
    }
    fseek(fp, start_add, SEEK_CUR);
    fread(file_data, 1, data_length, fp);
    fclose(fp);

    return 0;
}

/****************************************************************************
* 功  能: 按字节写文本文件数据
* 输  入: file_name路径或名称，start_add偏移地址 data_length数据长度
* 输  出: file_data 数据内容
* 返  回：0为正常，-1为异常
****************************************************************************/
int16_t set_file_data(const void *file_name, uint32_t start_add, uint32_t data_length, const void *file_data)
{
    FILE *fp = NULL;

	if((fp=fopen((const char*)file_name,"ab+")) == NULL)
	{
        CAN_DEBUG_PRINT("\n [%s:%d] File Open Failed !\n",__func__, __LINE__);
		return -1;
	}
	fclose(fp);

    fp = fopen((const char*)file_name, "rb+");
    if(fp == NULL)
    {
        CAN_DEBUG_PRINT("\n [%s:%d] File Open Failed !\n",__func__, __LINE__);
        return -1;
    }
    fseek(fp, start_add, SEEK_CUR);
    fwrite(file_data, 1, data_length, fp);
    fclose(fp);
    
    return 0;
}

static uint16_t can_update_get_package_index(uint8_t group_index,  uint32_t *p_bit_mask)
{
	uint16_t package_index = 0;
	uint32_t mask = 0;
	uint8_t i = 0;
	
	mask = *p_bit_mask;
	for(i=0; i<24; i++)
	{
		package_index++;
		if((mask&0x01))
		{
			// 清除已经提取的位
			*p_bit_mask = *p_bit_mask&(~((uint32_t)(1<<(package_index-1))));
			package_index = package_index+(uint16_t)group_index*24;
			return(package_index);
		}
		mask >>=1;
	}
	return(0);
}


static bool can_update_wait_respose(uint32_t timeout_ms)
{
	uint32_t time_cnt = 0;
	bool ret = true;
	
	while(1)
	{
		can_update_delay_ms(1);
		time_cnt++;
		if(time_cnt >= timeout_ms)
		{
			ret = false;
			break;
		}
		else if(g_session_master.status ==CAN_UPDATE_STATUS_REC_ACK)
		{
			ret = true;
			break;
		}
	}	
	g_session_master.status = CAN_UPDATE_STATUS_IDLE;
	return(ret);
}

int32_t checkArray(uint8_t *buff, int32_t size) {
    for (int32_t i = 0; i < size; i++) {
        if (buff[i] != 0xFF) {
            return 0;  // 如果有任何一个字节不为 0xFF，则返回 0
        }
    }
    return -1;  // 如果所有字节都为 0xFF，则返回 -1
}

/**************************************
* 功  能: 请求文件等待接口
* 输  入: timeout_ms 等待时间
* 输  出: 无
* 返  回：
 * ***********************************/
static bool can_file_wait_respose(uint32_t timeout_ms)
{
	uint32_t time_cnt = 0;
	bool ret = true;

	while(1)
	{
		can_update_delay_ms(1);
		time_cnt++;
		if(time_cnt >= timeout_ms)
		{
			ret = false;
			break;
		}
		else if(g_fault_record_info.status == CAN_UPDATE_STATUS_REC_ACK)
		{
			ret = true;
			break;
		}
	}
	g_fault_record_info.status = CAN_UPDATE_STATUS_IDLE;
	return(ret);
}


/**
 * @brief   发起方下发开始传输帧（请求帧）
 * @param   [in] timeout_ms  等待应答帧的时长
 * @param   [in] repeat_cnt  重复发送次数
 * @note    向所有PCS模块广播
 * @return  false，失败，无应答帧返回；true，成功，有应答帧返回
 */
static bool can_update_send_fw_start(uint32_t timeout_ms, uint8_t repeat_cnt)
{
	bool ret = true;
	uint16_t i = 0;
	uint8_t buff[8] = {0};
	int32_t flag = 0;
	uint16_t valid_data_cnt = 0;

	 for( i = 0;i < g_session_master.package_cnt;i++)
	{
		get_file_data(g_pcs_update_task.pcs_firm.path,(uint32_t)i*g_session_master.package_size,g_session_master.package_size,  g_session_master.data_buf);
		flag = checkArray(g_session_master.data_buf,g_session_master.package_size);
		if((0 == flag) || (i >= (g_session_master.package_cnt - 5)))//保留最后签名的5包
		{
			valid_data_cnt++;
		}
	}

	buff[0] = valid_data_cnt & 0xff;
    buff[1] = (valid_data_cnt >> 8) & 0xff;
	buff[2] = g_session_master.package_size & 0xff;
	buff[3] = (g_session_master.package_size >> 8) & 0xff;
	if(0 == update_dsp_type)
	{
		buff[4] = CHIP_ROLE_CODE_PCS;
		buff[5] = CHIP_MODEL_NUM_PCS & 0xff;
		buff[6] = (CHIP_MODEL_NUM_PCS >> 8) & 0xff;
	}
	else
	{
		buff[4] = CHIP_ROLE_CODE_PCS_S;
		buff[5] = CHIP_MODEL_NUM_PCS_S & 0xff;
		buff[6] = (CHIP_MODEL_NUM_PCS_S >> 8) & 0xff;
	}
	buff[7] = 0x00;
	g_session_master.can_msg.fun_code = PCS_UPDATE_START;
	g_session_master.can_msg.type = 2;
	
	for(i=0; i<repeat_cnt; i++)
	{
		CAN_DEBUG_PRINT("\n [%s:%d] can_update_send_fw_start start!\n",__func__, __LINE__);
		cup_sofar_can_send(CAN_PORT_PCS,&g_session_master.can_msg,buff,8);
		g_session_master.status = CAN_UPDATE_STATUS_WAIT_ACK;
		ret = can_update_wait_respose(timeout_ms);
		if(true == ret)
		{
			CAN_DEBUG_PRINT("\n [%s:%d] can_update_send_fw_start success!\n",__func__, __LINE__);
			break;
		}
		can_update_delay_ms(5);
	}
	return(ret);
}

static bool can_update_send_rev_result_query(uint32_t timeout_ms)
{
	bool ret = true;
	uint32_t len = 0;
	uint8_t *temp_buff = NULL;
	temp_buff = (uint8_t *)malloc(UPDATE_FW_MAX_SIZE*sizeof(uint8_t));
	if(NULL == temp_buff)
	{
		CAN_DEBUG_PRINT("\n [%s:%d] can_update_send_rev_result_query malloc failed\n",__func__, __LINE__);
	}
	uint8_t buff[8] = {0};
	uint16_t crc_check = 0;
	
	len = get_file_length(g_pcs_update_task.pcs_firm.path);
	get_file_data(g_pcs_update_task.pcs_firm.path,0,len,  temp_buff);

    extern uint16_t crc16(uint8_t *p_data, int32_t len);
	crc_check = crc16(temp_buff, len);
	CAN_DEBUG_PRINT("\n [%s:%d] crc_check=%x\n",__func__, __LINE__,crc_check);

	buff[0] = 0xAA;
	buff[2] = crc_check & 0xff;
	buff[1] = (crc_check >> 8) & 0xff;
	
	g_session_master.can_msg.fun_code = PCS_UPDATE_REC_RESULT_QUERY;
	g_session_master.can_msg.type = 2;
	g_session_master.recv_flag = 1;//开始接收帧
	memset(&g_session_master.p_query_rec_res_all,0,sizeof(update_query_rec_res_all_t));
	for(int32_t i = 0;i<3;i++)
	{
		cup_sofar_can_send(CAN_PORT_PCS,&g_session_master.can_msg,buff,8);
		g_session_master.status = CAN_UPDATE_STATUS_WAIT_ACK;
		ret = can_update_wait_respose(timeout_ms);
		if(ret == true)
		{
			CAN_DEBUG_PRINT("\n [%s:%d] send_rev_result_query success\n",__func__, __LINE__);
			break;
		}
		can_update_delay_ms(5);
	}
	
	free(temp_buff);
	return(ret);
}

static bool can_update_send_query_update_result(uint32_t timeout_ms)
{
	bool ret = true;

	uint8_t buff[8] = {0};
	buff[0] = 1;

	g_session_master.can_msg.fun_code = PCS_UPDATE_RESULT_QUERY;
	g_session_master.can_msg.type = 2;
	
	cup_sofar_can_send(1,&g_session_master.can_msg,buff,8);
	g_session_master.status = CAN_UPDATE_STATUS_WAIT_ACK;
	ret = can_update_wait_respose(timeout_ms);
	return(ret);
}

static bool can_update_master_send_data_package(void)
{
	bool ret = true;
	uint32_t i = 0;
	int32_t flag = 0;
	
	get_file_data(g_pcs_update_task.pcs_firm.path,(uint32_t)g_session_master.package_cur_index*g_session_master.package_size,g_session_master.package_size,  g_session_master.data_buf);

	flag = checkArray(g_session_master.data_buf,g_session_master.package_size);
	if((-1 == flag) && (g_session_master.package_cur_index < g_session_master.package_cnt - 5))//最后5包签名信息就留下
	{
		CAN_DEBUG_PRINT("\n [%s:%d] invalid data index[%d], discard!\n",__func__, __LINE__,g_session_master.package_cur_index);
		return(ret);
	}
	g_session_master.can_msg.addr = g_session_master.package_cur_index;
	g_session_master.can_msg.fun_code = PCS_UPDATE_DATA;
	g_session_master.can_msg.type = 1;
	for(int32_t i = 0;i < 3;i++)
	{
		ret = cup_sofar_can_send(CAN_PORT_PCS,&g_session_master.can_msg,g_session_master.data_buf,g_session_master.package_size);
		if(0 == ret)//发送成功，如果是副DSP，就下发升级数据块接收结果查询帧，最多只发10次，就一定发下一包
		{
			CAN_DEBUG_PRINT("\n [%s:%d] pack[%d] send success\n",__func__, __LINE__,g_session_master.package_cur_index);
			if(1 == update_dsp_type)//副DSP升级
			{
				usleep(100 * 1000);
			}
			ret = true;
			break;
		}
	}
	
	if(ret != true)
	{
		log_i((const int8_t*)"can_update_master_send_data_package---→can_update_send_fw_data: FAIL, packageIndex:%d, i:%d\r\n", g_session_master.package_cur_index,  i);	//log_e
	}
	
	return(ret);
}

/**
 * @brief   解析收到的应答帧（主要在升级过程中）
 * @param   [in] rframe  接收数据的CAN ID信息
 * @param   [in] p_data  接收的数据
 * @param   [in] len  接收数据的长度
 * @note   
 * @return  false，失败；true，成功
 */

bool can_update_master_decode(can_msg_t *rframe,uint8_t* p_data,int32_t len)
{
	bool ret = false;
	uint8_t res = 0;
	int32_t index = rframe->src_addr - 1;
	CAN_DEBUG_PRINT("\n [%s:%d] ack_frame_analysis\n",__func__, __LINE__);
	switch(rframe->fun_code)
	{
		case PCS_UPDATE_START:
			if(g_session_master.status == CAN_UPDATE_STATUS_WAIT_ACK)
			{
				uint16_t dev_package_size = 0;
				res = p_data[0];
				dev_package_size = (p_data[3]<<8) | p_data[2];
				log_i((const int8_t*)"\ncan_update_master_decode ——→ UPDATE_START ===client package size:0x%x=== \r\n", dev_package_size);
				if(0 == res)
				{
					if(dev_package_size < g_session_master.package_size)
					{
						uint32_t fw_size = 0;
						fw_size = get_file_length(g_pcs_update_task.pcs_firm.path);
						g_session_master.package_size = dev_package_size;
						g_session_master.package_cnt =  (fw_size%g_session_master.package_size)>0 ? fw_size/g_session_master.package_size+1:fw_size/g_session_master.package_size ;
						
						log_i((const int8_t*)"\ncan_update_master_decode--update information:\r\n");	//log_i
						log_i((const int8_t*)"fw_size:%dByte", fw_size);
						log_i((const int8_t*)"package_size:%dBytes", g_session_master.package_size);
						log_i((const int8_t*)"package_cnt:%d",g_session_master.package_cnt);
						log_i((const int8_t*)"package_cur_index:%d",g_session_master.package_cur_index);
						log_i((const int8_t*)"dev_cnt:%d", g_session_master.device_cnt);
					}
					else
					{
						g_session_master.status = CAN_UPDATE_STATUS_REC_ACK;
					}
				}
				
			}
			break;
		// case UPDATE_DATA_START:
		// 	if(g_session_master.status == CAN_UPDATE_STATUS_WAIT_ACK
		// 		&& ((g_session_master.can_msg.dst_addr == rframe->src_addr) || (g_session_master.can_msg.dst_addr == 0)))
		// 	{
		// 		log_i((const int8_t*)"can_update_master_decode ——→ UPDATE_DATA_START\r\n");
		// 		g_session_master.status = CAN_UPDATE_STATUS_REC_ACK;
		// 	}
		// 	break;
		case PCS_UPDATE_REC_RESULT_QUERY:
			if(/*g_session_master.status == CAN_UPDATE_STATUS_WAIT_ACK*/(g_session_master.recv_flag == 1)
				&& ((g_session_master.can_msg.dst_addr == rframe->src_addr) || (g_session_master.can_msg.dst_addr == 0)))
			{
				for(int32_t i = 0;i < 288;i++)
				{
					if(0 == g_session_master.p_query_rec_res_all.p_query_rec_res_2[i].flag)
					{
						g_session_master.p_query_rec_res_all.num++;
						g_session_master.p_query_rec_res_all.p_query_rec_res_2[i].src_addr = rframe->src_addr;
						g_session_master.p_query_rec_res_all.p_query_rec_res_2[i].flag = 1;
						g_session_master.p_query_rec_res_all.p_query_rec_res_2[i].ret_code = p_data[0];
						g_session_master.p_query_rec_res_all.p_query_rec_res_2[i].group_index = p_data[1];
						g_session_master.p_query_rec_res_all.p_query_rec_res_2[i].bit_mask = (uint32_t)((p_data[4]<<16) | (p_data[3]<<8) | (p_data[2]));
						break;
					}
				}
				g_session_master.status = CAN_UPDATE_STATUS_REC_ACK;
				
				ret = true;
				log_i((const int8_t*)"can_update_master_decode ——→ UPDATE_REC_RESULT_QUERY\r\n");
			}
			break;
		case PCS_UPDATE_RESULT_QUERY:
			if(g_session_master.status == CAN_UPDATE_STATUS_WAIT_ACK
				 && ((g_session_master.can_msg.dst_addr == rframe->src_addr) || (g_session_master.can_msg.dst_addr == 0)))
			{
				g_session_master.p_query_update_res.ret_code = p_data[0];
				g_session_master.p_query_update_res.storage_firmware = p_data[1];
				g_session_master.status = CAN_UPDATE_STATUS_REC_ACK;
				ret = true;
				log_i((const int8_t*)"can_update_master_decode ——→ UPDATE_RESULT_QUERY\r\n");
			}
			break;
		case PCS_UPDATE_DATA_REC_RESULT_QUERY:
			if(((g_session_master.status == CAN_UPDATE_STATUS_WAIT_ACK) || (g_session_master.status == CAN_UPDATE_STATUS_REC_ACK))
				 && ((g_session_master.can_msg.dst_addr == rframe->src_addr) || (g_session_master.can_msg.dst_addr == 0)))
			{
				if((1 <= rframe->src_addr) && (rframe->src_addr <= 8))
				{
					uint8_t tmp_index = rframe->src_addr - 1;
					g_session_master.p_query_pack_rec_res.ret_code[tmp_index] = p_data[0];
					g_session_master.p_query_pack_rec_res.res[tmp_index] = p_data[1];
					g_session_master.p_query_pack_rec_res.pack_index[tmp_index] = p_data[2] | (p_data[3] << 8);
				}
				
				g_session_master.status = CAN_UPDATE_STATUS_REC_ACK;
				ret = true;
			}
			break;
		case PCS_FUN_CODE_WRITE_PARAM:
			if(1 == g_pcs_comm_info.pcs_wait_ack_flag[index])
			{
				g_pcs_comm_info.pcs_wait_ack_flag[index] = 2;
				g_pcs_comm_info.pcs_ack_code[index] = p_data[3];
			}
			break;
		case FUN_FILE_DATA_READ:
			if((g_fault_record_info.status == CAN_UPDATE_STATUS_WAIT_ACK) && (p_data[1] == 0))//结果描述符：0表示执行成功，非0异常
			{
				g_fault_record_info.file_id = p_data[0];
				g_fault_record_info.file_len = (p_data[3]<<8) | p_data[2];
				g_fault_record_info.status = CAN_UPDATE_STATUS_REC_ACK;
				printf("file_id[%02x],file_len[%02x]\n",g_fault_record_info.file_id,g_fault_record_info.file_len);
			}
			break;
		default:
			break;
	}

	
	return(ret);
}

/**
 * @brief   发起方下发总接收结果查询帧（请求帧）
 * @param   [in] check_cnt  查询次数
 * @note    单独向每个模块发送查询帧
 * @return  设备掩码，对应bit位置0表示该设备数据接收成功
 */
uint32_t can_update_get_rec_result(uint32_t check_cnt)
{
	uint32_t i = 0;
	uint32_t j = 0;
	uint32_t pcs_index = 0;
	uint32_t device_mask = 0;
	uint8_t dst_addr_temp = 0;
	
	dst_addr_temp = g_session_master.can_msg.dst_addr;
	common_data_t * shm_data = sdk_shm_get();
	firmware_update_t *p_update = NULL;
	p_update = get_shm_update_stru();
	
	if(NULL == shm_data)
	{
		return 0xff;
	}
	
	if(0 == p_update->upgrade_pcs_index)
	{
		device_mask = ((uint32_t)(1<<g_session_master.device_cnt))-1;
	}
	else
	{
		device_mask = (uint32_t)(1<<(p_update->upgrade_pcs_index-1));
	}
	for(j=0; j<check_cnt; j++)
	{
		// DCDC. BMS地址是从1开始
		for(i=0; i<g_session_master.device_cnt; i++)
		{
			if(0 == p_update->upgrade_pcs_index)
			{
				pcs_index = i;
			}
			else
			{
				pcs_index = p_update->upgrade_pcs_index-1;
			}
	
			if(shm_data->internal_shared_data.pcs_heartbeat_info.comm_state[pcs_index] == 0)//通讯异常的，直接跳过
			{
				CAN_DEBUG_PRINT("\n [%s:%d] *********************PCS UPDATE! DEV[%d] offline!SKIP****************\n",__func__, __LINE__,pcs_index);
				device_mask &=(~(uint32_t)(1<<pcs_index));
				g_session_master.device_mask |= ((uint32_t)(1<<pcs_index));
			}
			g_session_master.can_msg.dst_addr = pcs_index+1;
			if( (device_mask&(1<<pcs_index))==0 )
			{
				continue;
			}
	
			CAN_DEBUG_PRINT("*********************UPDATE_TEST****************\n");
			if(can_update_send_rev_result_query(500) == true)
			{
				can_update_delay_ms(2000);//等待1s，让回复帧接收完毕
				g_session_master.recv_flag = 0;
				printf("p_query_rec_res_all.num=%d\n",g_session_master.p_query_rec_res_all.num);
				for(int32_t m = 0;m < g_session_master.p_query_rec_res_all.num;m++)
				{
					if(g_session_master.p_query_rec_res_all.p_query_rec_res_2[m].flag == 1)
					{
						//PACKAGE_INTERVAL_TIME_MS
						g_session_master.p_query_rec_res.group_index = g_session_master.p_query_rec_res_all.p_query_rec_res_2[m].group_index;
						g_session_master.p_query_rec_res.bit_mask = g_session_master.p_query_rec_res_all.p_query_rec_res_2[m].bit_mask;
						g_session_master.p_query_rec_res.ret_code = g_session_master.p_query_rec_res_all.p_query_rec_res_2[m].ret_code;
						{
							uint16_t index = 0;
							if(g_session_master.p_query_rec_res.group_index==0 && g_session_master.p_query_rec_res.bit_mask==0
								&& g_session_master.p_query_rec_res.ret_code == CAN_UPDATE_RECODE_OK)
							{
								device_mask &=(~(uint32_t)(1<<pcs_index));
								break;
							}

							if(g_session_master.p_query_rec_res.group_index==0 && g_session_master.p_query_rec_res.bit_mask==0
								&& g_session_master.p_query_rec_res.ret_code == CAN_UPDATE_RECODE_FILE_CRC_ERROR)
							{
								printf("file crc error,no index!\n");
								break;
							}
			send_next_package:					
							index = can_update_get_package_index(g_session_master.p_query_rec_res.group_index, &(g_session_master.p_query_rec_res.bit_mask));
							// 以下测试调试代码
							if(index == 0)
							{
								CAN_DEBUG_PRINT("\n [%s:%d] group_index[%d] retransmission completed!\n",__func__, __LINE__,g_session_master.p_query_rec_res.group_index);
								continue;
							}
							log_i((const int8_t*)"p_query_rec_res->group_index:%d, bit_mask:%x", g_session_master.p_query_rec_res.group_index, g_session_master.p_query_rec_res.bit_mask);
							log_i((const int8_t*)"package index:%d", index);	//log_i
							
							// 以上测试调试代码
							if(index <= g_session_master.package_cnt)
							{
								g_session_master.package_cur_index = index-1;
								g_session_master.can_msg.dst_addr = dst_addr_temp;
								CAN_DEBUG_PRINT("\nretransmission [%d]\n",g_session_master.package_cur_index);
								can_update_master_send_data_package();
								// 发送下一个失败包
								goto send_next_package;
							}
							else
							{
								CAN_DEBUG_PRINT("Wrong index number\n");
								continue;
							}
						}
					}
				}
			}
			else
			{
				g_session_master.recv_flag = 0;
				CAN_DEBUG_PRINT("can_update_send_rev_result_query:No response!\n");
			}
			
			can_update_delay_ms(PACKAGE_DATA_INTERVAL_TIME_MS);
		}
		if(device_mask==0)
		{
			
			return(device_mask);
		}
		can_update_delay_ms(PACKAGE_INTERVAL_TIME_MS);
	}
	
	return(device_mask);
}

uint32_t can_update_get_rec_result_slave(uint32_t check_cnt)
{
	uint32_t i = 0;
	uint32_t j = 0;
	uint32_t pcs_index = 0;
	uint32_t device_mask = 0;

	common_data_t * shm_data = sdk_shm_get();
	firmware_update_t *p_update = NULL;
	p_update = get_shm_update_stru();
	
	if(NULL == shm_data)
	{
		return 0xff;
	}
	
	if(0 == p_update->upgrade_pcs_index)
	{
		device_mask = ((uint32_t)(1<<g_session_master.device_cnt))-1;
	}
	else
	{
		device_mask = (uint32_t)(1<<(p_update->upgrade_pcs_index-1));
	}
	for(j=0; j<check_cnt; j++)
	{	
		for(i=0; i<PCS_CABINET_POWER_MODULE_NUM; i++)
		{
			if(shm_data->internal_shared_data.pcs_heartbeat_info.comm_state[i] == 0)//通讯异常的，直接跳过
			{
				CAN_DEBUG_PRINT("\n [%s:%d] *********************PCS UPDATE! DEV[%d] offline!SKIP****************\n",__func__, __LINE__,i);
				device_mask &=(~(uint32_t)(1<<i));
				g_session_master.device_mask |= ((uint32_t)(1<<i));
			}
		}
		
	
		CAN_DEBUG_PRINT("*********************UPDATE_TEST****************\n");
		if(can_update_send_rev_result_query(500) == true)//3
		{
			can_update_delay_ms(1000);//等待1s，让回复帧接收完毕
			g_session_master.recv_flag = 0;
			printf("p_query_rec_res_all.num=%d\n",g_session_master.p_query_rec_res_all.num);
			for(int32_t m = 0;m < g_session_master.p_query_rec_res_all.num;m++)
			{
				if(g_session_master.p_query_rec_res_all.p_query_rec_res_2[m].flag == 1)
				{
					//PACKAGE_INTERVAL_TIME_MS
					g_session_master.p_query_rec_res.src_addr =  g_session_master.p_query_rec_res_all.p_query_rec_res_2[m].src_addr;
					g_session_master.p_query_rec_res.group_index = g_session_master.p_query_rec_res_all.p_query_rec_res_2[m].group_index;
					g_session_master.p_query_rec_res.bit_mask = g_session_master.p_query_rec_res_all.p_query_rec_res_2[m].bit_mask;
					g_session_master.p_query_rec_res.ret_code = g_session_master.p_query_rec_res_all.p_query_rec_res_2[m].ret_code;
					{
						uint16_t index = 0;
						if(g_session_master.p_query_rec_res.group_index==0 && g_session_master.p_query_rec_res.bit_mask==0
							&& g_session_master.p_query_rec_res.ret_code == CAN_UPDATE_RECODE_OK)
						{
							pcs_index = g_session_master.p_query_rec_res.src_addr - 1;
							device_mask &=(~(uint32_t)(1<<pcs_index));
							continue;
						}

						if(g_session_master.p_query_rec_res.group_index==0 && g_session_master.p_query_rec_res.bit_mask==0
							&& g_session_master.p_query_rec_res.ret_code == CAN_UPDATE_RECODE_FILE_CRC_ERROR)
						{
							printf("file crc error,no index!\n");
							continue;
						}
		send_next_package:					
						index = can_update_get_package_index(g_session_master.p_query_rec_res.group_index, &(g_session_master.p_query_rec_res.bit_mask));
						// 以下测试调试代码
						if(index == 0)
						{
							CAN_DEBUG_PRINT("\n [%s:%d] group_index[%d] retransmission completed!\n",__func__, __LINE__,g_session_master.p_query_rec_res.group_index);
							continue;
						}
						log_i((const int8_t*)"p_query_rec_res->group_index:%d, bit_mask:%x", g_session_master.p_query_rec_res.group_index, g_session_master.p_query_rec_res.bit_mask);
						log_i((const int8_t*)"package index:%d", index);	//log_i
						
						// 以上测试调试代码
						if(index <= g_session_master.package_cnt)
						{
							g_session_master.package_cur_index = index-1;
							//g_session_master.can_msg.dst_addr = dst_addr_temp;
							CAN_DEBUG_PRINT("\nretransmission [%d]\n",g_session_master.package_cur_index);
							can_update_master_send_data_package();
							// 发送下一个失败包
							goto send_next_package;
						}
						else
						{
							CAN_DEBUG_PRINT("Wrong index number\n");
							continue;
						}
					}
				}
			}
		}
		else
		{
			g_session_master.recv_flag = 0;
			CAN_DEBUG_PRINT("can_update_send_rev_result_query:No response!\n");
		}
			
		can_update_delay_ms(PACKAGE_DATA_INTERVAL_TIME_MS);
		
		if(device_mask==0)
		{
			
			return(device_mask);
		}
		can_update_delay_ms(PACKAGE_INTERVAL_TIME_MS);
	}
	
	return(device_mask);
}

uint32_t can_update_get_update_result(uint32_t check_cnt)
{
	uint32_t i = 0;
	uint32_t j = 0;
	uint32_t device_mask = 0;
	
	device_mask = ((uint32_t)(1<<g_session_master.device_cnt))-1;
	for(j=0; j<check_cnt; j++)
	{
		// DCDC. BMS地址是从1开始
		for(i=0; i<g_session_master.device_cnt; i++)
		{
			if( (device_mask&(1<<i))==0 )
			{
				continue;
			}
			if(can_update_send_query_update_result(PACKAGE_INTERVAL_TIME_MS) == true)
			{
				if(g_session_master.p_query_update_res.ret_code == CAN_UPDATE_RECODE_OK)
				{
					device_mask &=(~(uint32_t)(1<<i));
				}
			}
			can_update_delay_ms(PACKAGE_DATA_INTERVAL_TIME_MS);
		}
		if(device_mask==0)
		{
			return(device_mask);
		}
		can_update_delay_ms(PACKAGE_QUERY_INTERVAL_TIME_MS);
	}
	return(device_mask);
}

bool can_update_master_update_stepup(dev_type_e dev_type, uint8_t tar_addr, uint8_t dev_cnt)
{
	uint32_t fw_size = 0;
	g_session_master.status = CAN_UPDATE_STATUS_IDLE;
	g_session_master.device_cnt = dev_cnt;
	g_session_master.dev_update_result = 0xffffffff;
	g_session_master.can_msg.dst_addr = tar_addr;
	g_session_master.can_msg.dst_type = dev_type;
	g_session_master.can_msg.prio = 7;
	g_session_master.can_msg.src_addr = 1;
	g_session_master.can_msg.src_type = 2;
	g_session_master.can_msg.fun_code = PCS_UPDATE_START; 
	g_session_master.package_size = PACKAGE_SIZE_DEFAULT;
	g_session_master.device_mask = 0;
	fw_size = get_file_length(g_pcs_update_task.pcs_firm.path);
	
	g_session_master.package_cur_index = 0;
	g_session_master.package_cnt = (fw_size%g_session_master.package_size)>0 ? fw_size/g_session_master.package_size+1:fw_size/g_session_master.package_size ;
	
	log_i((const int8_t*)"\ncan_update_master_update_stepup---update information:\r\n");	//log_i
	log_i((const int8_t*)"dst_type:%d ", dev_type);
	log_i((const int8_t*)"dst_addr:%d ", tar_addr);
	log_i((const int8_t*)"fw_size:%dByte ", fw_size);
	log_i((const int8_t*)"package_size:%dBytes ", g_session_master.package_size);
	log_i((const int8_t*)"package_cnt:%d ",g_session_master.package_cnt);
	log_i((const int8_t*)"package_cur_index:%d ",g_session_master.package_cur_index);
	log_i((const int8_t*)"dev_cnt:%d ", g_session_master.device_cnt);
	CAN_DEBUG_PRINT("\n");
	
	return(true);
}

uint32_t can_update_master_send_fw(void)
{
	uint32_t dev_mask = 0;
	uint32_t i = 0;
	bool ret = true;
	uint8_t progress = 0;
	firmware_update_t *p_update = get_shm_update_stru();
	pcs_firmware_update_task_t *p_task = NULL;
	int32_t verify_flag = -1;

	p_task = get_pcs_update_task_stru();
	p_update->module_percent[p_task->pcs_firm.index] = progress;
	
	if(0 == p_update->upgrade_pcs_index)
	{
		dev_mask = ((uint32_t)(1<<g_session_master.device_cnt))-1;
	}
	else
	{
		dev_mask = (uint32_t)(1<<(p_update->upgrade_pcs_index-1));
	}
	verify_flag = pcs_firmware_verification(&g_pcs_update_task.pcs_firm);

	if(verify_flag != 0)
	{
		shm_update_stru_flag_set(p_task->pcs_firm.index, 2);
		p_update->module_result[p_task->pcs_firm.index] = dev_mask;
		return(dev_mask);
	}
	
	ret = can_update_send_fw_start(PACKAGE_QUERY_INTERVAL_TIME_MS, CAN_SEND_CMD_REPEAT_CNT);

	if(ret == false)
	{
		shm_update_stru_flag_set(p_task->pcs_firm.index, 2);
		p_update->module_result[p_task->pcs_firm.index] = dev_mask;
		return(dev_mask);
	}

	can_update_delay_ms(PACKAGE_QUERY_INTERVAL_TIME_MS);
	for(i=0; i<g_session_master.package_cnt; i++)
	{
		ret = can_update_master_send_data_package();
		if(ret != true)
		{
			log_i((const int8_t*)"\ncan_update_master_send_fw→can_update_master_send_data_package:fail, current package:%d\r\n", g_session_master.package_cur_index);	//log_e
		}
		g_session_master.package_cur_index++;
		progress = g_session_master.package_cur_index*100/(g_session_master.package_cnt+1);// 计算百分比, 等待接收完成，再强制进度为100%
		p_update->module_percent[p_task->pcs_firm.index] = progress;
		can_update_delay_ms(5);
	}

	if(update_dsp_type == 1)
	{
		dev_mask = can_update_get_rec_result_slave(CAN_SEND_REQ_MAX_CNT); 		// 查询次数，代测试纠正 CAN_SEND_REQ_MAX_CNT
	}
	else
	{
		dev_mask = can_update_get_rec_result(CAN_SEND_REQ_MAX_CNT); 		// 查询次数，代测试纠正 CAN_SEND_REQ_MAX_CNT
	}
	
	dev_mask |= g_session_master.device_mask;//记录了掉线的，掉线的也算在失败里

	if(p_update->upgrade_pcs_index != 0)//单播，只关注自身的失败
	{
		dev_mask &= 1 << (p_update->upgrade_pcs_index - 1);
	}
	
	g_session_master.dev_update_result = dev_mask;
	
	g_session_master.dev_update_result = dev_mask;
	
	if(g_session_master.dev_update_result != 0)
	{
		shm_update_stru_flag_set(p_task->pcs_firm.index, 2);
	}
	else
	{
		p_update->module_percent[p_task->pcs_firm.index] = 100;
		shm_update_stru_flag_set(p_task->pcs_firm.index, 0);
	}
	p_update->module_result[p_task->pcs_firm.index] = g_session_master.dev_update_result;
	memset(p_update->module_object[p_task->pcs_firm.index], 0, sizeof(p_update->module_object[0]));
	return(g_session_master.dev_update_result);
}

int32_t can_wait_query_respose(uint8_t dev_id,uint32_t timeout_ms)
{
	uint32_t time_cnt = 0;
	int32_t i = 0;
	while(1)
	{
		usleep(1000);
		time_cnt++;
		if(time_cnt >= timeout_ms)
		{
			break;
		}
		if(0 == dev_id)
		{
			for( i = 0;i < PCS_CABINET_POWER_MODULE_NUM;i++)
			{
				if((g_pcs_comm_info.pcs_connect_flag[i] == 1) && (2 != g_pcs_comm_info.pcs_wait_flag[i]))
				{
					break;
				}
				
			}
			if(PCS_CABINET_POWER_MODULE_NUM == i)
			{
				return 0;
			}
		}
		else if(dev_id <= PCS_CABINET_POWER_MODULE_NUM)
		{
			if(g_pcs_comm_info.pcs_connect_flag[dev_id-1] != 1)
			{
				break;
			}
			else if(2 == g_pcs_comm_info.pcs_wait_flag[dev_id-1])
			{
				CAN_DEBUG_PRINT("can_wait_query_respose success\n");
				return 0;
			}
			
		}
	}	
	if(0 == dev_id)
	{
		for(i = 0;i < PCS_CABINET_POWER_MODULE_NUM;i++)
		{
			if((g_pcs_comm_info.pcs_connect_flag[i] == 1) && (2 != g_pcs_comm_info.pcs_wait_flag[i]))
			{
				g_pcs_comm_info.pcs_comm_err_cnt[i]++;
			}
		}
	}
	else if(dev_id <= PCS_CABINET_POWER_MODULE_NUM)
	{
		CAN_DEBUG_PRINT("can_wait_query_respose failed\n");
		g_pcs_comm_info.pcs_comm_err_cnt[dev_id-1]++;
	}
	
	return(-1);
}

int32_t can_wait_ack_respose(uint8_t dev_id,uint32_t timeout_ms)
{
	uint32_t time_cnt = 0;
	int32_t i = 0;
	while(1)
	{
		usleep(1000);
		time_cnt++;
		if(time_cnt >= timeout_ms)
		{
			break;
		}
		if(0 == dev_id)
		{
			for( i = 0;i < PCS_CABINET_POWER_MODULE_NUM;i++)
			{
				if((g_pcs_comm_info.pcs_connect_flag[i] == 1) && 
					((2 != g_pcs_comm_info.pcs_wait_ack_flag[i]) || (0 != g_pcs_comm_info.pcs_ack_code[dev_id])))
				{
					break;
				}
				
			}
			if(PCS_CABINET_POWER_MODULE_NUM == i)
			{
				return 0;
			}
		}
		else if((dev_id <= PCS_CABINET_POWER_MODULE_NUM) && ((g_pcs_comm_info.pcs_connect_flag[dev_id-1] == 1) && (2 == g_pcs_comm_info.pcs_wait_ack_flag[dev_id-1]) && (0 == g_pcs_comm_info.pcs_ack_code[dev_id-1])))
		{
			return 0;
		}
	}
	
	if(0 == dev_id)
	{
		for(i = 0;i < PCS_CABINET_POWER_MODULE_NUM;i++)
		{
			if((g_pcs_comm_info.pcs_connect_flag[i] == 1) && 
				((2 != g_pcs_comm_info.pcs_wait_ack_flag[i]) || (0 != g_pcs_comm_info.pcs_ack_code[dev_id])))
			{
				g_pcs_comm_info.pcs_comm_err_cnt[i]++;
			}
		}
	}
	else
	{
		g_pcs_comm_info.pcs_comm_err_cnt[dev_id-1]++;
	}
	
	return(-1);
}




int32_t pcs_tele_data_query(uint8_t fun_code, uint8_t dev_id, uint16_t addr, uint8_t len)
{
	if(0 == dev_id)
	{
		memset(&g_pcs_comm_info.pcs_wait_flag[0],1,sizeof(g_pcs_comm_info.pcs_wait_flag));
	}
	else if(dev_id <= PCS_CABINET_POWER_MODULE_NUM)
	{
		g_pcs_comm_info.pcs_wait_flag[dev_id-1] = 1;
	}
	
	int32_t ret = 0;
	uint8_t buff[8] = {0};
	int32_t i = 0;
	can_msg_t can_msg = {0};
	can_msg.src_addr = 1;
	can_msg.src_type = DEV_CSU_MCU;
	can_msg.dst_addr = dev_id;
	can_msg.dst_type = DEV_PCS;
	can_msg.prio = PRIO_DATA;
	can_msg.addr = addr;//点表起始位置
	can_msg.fun_code = fun_code;
	can_msg.type = TYPE_REQ;
	
	buff[0] = can_msg.addr & 0xff;
	buff[1] = (can_msg.addr >> 8) & 0xff;
	buff[2] = len;//数据个数
	
	CAN_DEBUG_PRINT("pcs_tele_data_query:funcode[%d]\n",fun_code);
	data_print(buff, 8);   //打印数据
	for(i = 0; i < 3; i++)
	{
		ret = cup_sofar_can_send(CAN_PORT_PCS,&can_msg,buff,8);
		if(0 == ret)
		{
			break;
		}
		else
		{
			sdk_delay_ms(10);
		}
	}
	if(3 == i)
	{
		CAN_DEBUG_PRINT("cup_sofar_can_send failed 3 times\n");
		return -1;
	}
	
	ret = can_wait_query_respose(dev_id, 1000);	// 2000
	memset(&g_pcs_comm_info.pcs_wait_flag[0],0,sizeof(g_pcs_comm_info.pcs_wait_flag));
	return ret;
}

int32_t pcs_param_write(uint8_t dev_id, uint16_t addr, uint16_t *buff,int32_t len)
{
	if(0 == dev_id)
	{
		memset(&g_pcs_comm_info.pcs_wait_ack_flag[0],1,sizeof(g_pcs_comm_info.pcs_wait_ack_flag));
	}
	else if(dev_id <= PCS_CABINET_POWER_MODULE_NUM)
	{
		g_pcs_comm_info.pcs_wait_ack_flag[dev_id-1] = 1;
	}

	int32_t ret = 0;
	int32_t i = 0;
	int32_t m = 0;
	int32_t j = 0;
	uint8_t *tem_buff= NULL;
	tem_buff = (uint8_t*)malloc(2*len*sizeof(uint8_t));
	
	can_msg_t can_msg = {0};
	can_msg.src_addr = 1;
	can_msg.src_type = DEV_CSU_MCU;
	can_msg.dst_addr = dev_id;
	can_msg.dst_type = DEV_PCS;
	can_msg.prio = PRIO_DATA;
	can_msg.addr = addr;//点表起始位置
	can_msg.fun_code = PCS_FUN_CODE_WRITE_PARAM;
	can_msg.type = TYPE_DATA;
	
	for(j = 0;j < len; j++)
	{
		tem_buff[m] = buff[j] & 0xff;
		tem_buff[m+1] = (buff[j] >> 8) & 0xff;
		m = m + 2;
	}
	
	CAN_DEBUG_PRINT("pcs_param_write:send data\n");
	
	data_print(tem_buff, 2*len);   //打印数据
	
	for (i = 0; i < 3; i++)
	{
		ret = cup_sofar_can_send(CAN_PORT_PCS,&can_msg,tem_buff,2*len);
		if(0 == ret)
		{
			break;
		}
	}

	if(3 == i)
	{
		CAN_DEBUG_PRINT("cup_sofar_can_send failed 3 times\n");
		return -1;
	}
	
	ret = can_wait_ack_respose(dev_id,2000);
	memset(&g_pcs_comm_info.pcs_wait_ack_flag[0],0,sizeof(g_pcs_comm_info.pcs_wait_ack_flag));
	memset(&g_pcs_comm_info.pcs_ack_code[0],0,sizeof(g_pcs_comm_info.pcs_ack_code));
	free(tem_buff);
	return ret;
}

/**
 * @brief  检测pcs模块是否需要升级（object对应位置有内容代表要升级）
 * @param  [in] none
 * @param  [out] none
 * @return mcu2升级标志
 */
int32_t firmware_update_flag(void)
{
	int32_t i = 0;
	pcs_firmware_update_task_t *p_task = NULL;
	firmware_update_t *p_update = NULL;
	p_task = get_pcs_update_task_stru();
	memset(p_task,0,sizeof(pcs_firmware_update_task_t));
	p_update = get_shm_update_stru();
	
	if(NULL == p_task || NULL == p_update)
	{
		return -1; 
	}
	
	for(i=0; i<UPDATE_OBJECT_NUM; i++)
	{
		if(!strncmp((const char *)&p_update->module_object[i], FIRMWARE_NAME_CAN, strlen(FIRMWARE_NAME_CAN)) ||
			!strncmp((const char *)&p_update->module_object[i], FIRMWARE_NAME_PCS_S, strlen(FIRMWARE_NAME_PCS_S)))
		{
			p_task->pcs_firm.index = i;
			shm_update_stru_flag_set(p_task->pcs_firm.index, 1);
			snprintf((char *)p_task->pcs_firm.path, sizeof(p_task->pcs_firm.path), \
						"/tmp/upload/%s", (const int8_t *)&p_update->module_name[i]);
			CAN_DEBUG_PRINT((int8_t *)"PCS_firm path= %s\n", p_task->pcs_firm.path);
			if(0 == p_update->upgrade_pcs_index)
			{
				p_task->update_flag = PCS_BROADCAST_UPGRADE;
			}
			else
			{
				p_task->update_flag = PCS_UNICAST_UPGRADE;
			}
			
			break;
		}
	}
	
	return p_task->update_flag;
}

/**
 * @brief  固件签名校验
 * @param  [in] p_object 固件信息结构体指针，见firmware_info_t
 * @param  [in] p_file_content 固件内容指针
 * @param  [in] read_size 固件内容大小
 * @return 校验结果 0：成功  -1：失败
 */
int32_t pcs_firmware_verification(pcs_firmware_info_t *p_object)
{
    int32_t ret = 0;

    extern int32_t get_firmware_signature(int8_t *p_path, firmware_signature_t *p_file_sign);
    // 获取签名信息
    ret = get_firmware_signature(p_object->path, (firmware_signature_t *)&p_object->signature_info);
	
    if(ret != 0)
    {
        return -1;
    }

    // 校验签名版本
    if(p_object->signature_info.protocol_version != PCS_SIGNATURE_VERSION)
    {
        CAN_DEBUG_PRINT((int8_t *)"signature_version = %d\n", p_object->signature_info.protocol_version);
        CAN_DEBUG_PRINT((int8_t *)"signature version is not right!\n\n");
        return -1;
    }
    CAN_DEBUG_PRINT((int8_t *)"[signature verify]-version success!\n");

    // 验证芯片角色、芯片代号
   if((p_object->signature_info.chip_role == CHIP_ROLE_CODE_PCS || p_object->signature_info.chip_role == 0x30) && 0 == strncmp((const char *)p_object->signature_info.chip_code, CHIP_MODEL_CODE_PCS, strlen(CHIP_MODEL_CODE_PCS)))	
	{
		CAN_DEBUG_PRINT((int8_t *)"[signature verify]-chip role and model code success! main DSP!\n");
		update_dsp_type = 0;
		return 0;
	}
	else if((p_object->signature_info.chip_role == CHIP_ROLE_CODE_PCS_S || p_object->signature_info.chip_role == 0x31) && 0 == strncmp((const char *)p_object->signature_info.chip_code, CHIP_MODEL_CODE_PCS_S, strlen(CHIP_MODEL_CODE_PCS_S)))
	{
		CAN_DEBUG_PRINT((int8_t *)"[signature verify]-chip role and model code success! slave DSP!\n");
		update_dsp_type = 1;
		return 0;
	}
	else
	{
        CAN_DEBUG_PRINT((int8_t *)"signature_chip_role = %x, signature_chip_code = %s\n", \
                p_object->signature_info.chip_role, p_object->signature_info.chip_code);
        CAN_DEBUG_PRINT((int8_t *)"signature chip is not right!\n\n");
        return -1;
    }
}

/** 
 * @brief   获取所有电池簇的单体最高温度
 * @param   无
 * @return 	无
 */
static int16_t get_battery_max_monomer_temp(void)
{
	uint8_t i;
	int16_t current_temp = 0;
	int16_t max_temp = 0;
	uint8_t max_temp_valid = 0;
	battery_cluster_telemetry_info_t *p_bat_telemetry = NULL;

	for(i = 0; i < BCU_DEVICE_NUM; i++)
	{
		p_bat_telemetry = sdk_shm_battery_cluster_telemetry_info_get(i); // 电池簇遥测
		if(p_bat_telemetry == NULL)
		{
			continue;
		}
		if(p_bat_telemetry->BCU_comm_status == BCU_COMM_NORMAL)
		{
			current_temp = p_bat_telemetry->highest_monomer_temperature_cluster[0] - 40;
			if(max_temp_valid == 0)
			{
				max_temp_valid = 1;
				max_temp = current_temp;
			}
			else
			{
				if(max_temp < current_temp)
				{
					max_temp = current_temp;
				}
			}
		}

	}
	return max_temp;
}

/** 
 * @brief   获取所有电池簇的单体最低温度
 * @param   无
 * @return 	无
 */
static int16_t get_battery_min_monomer_temp(void)
{
	uint8_t i;
	int16_t current_temp = 0;
	int16_t min_temp = 0;
	uint8_t min_temp_valid = 0;
	battery_cluster_telemetry_info_t *p_bat_telemetry = NULL;

	for(i = 0; i < BCU_DEVICE_NUM; i++)
	{
		p_bat_telemetry = sdk_shm_battery_cluster_telemetry_info_get(i); // 电池簇遥测
		if(p_bat_telemetry == NULL)
		{
			continue;
		}
		if(p_bat_telemetry->BCU_comm_status == BCU_COMM_NORMAL)
		{
			current_temp = p_bat_telemetry->lowest_monomer_temperature_cluster[0] - 40;
			if(min_temp_valid == 0)
			{
				min_temp_valid = 1;
				min_temp = current_temp;
			}
			else
			{
				if(min_temp > current_temp)
				{
					min_temp = current_temp;
				}
			}
		}

	}
	return min_temp;
}

/**
 * @brief 线性插值计算当前温度对应的功率因子
 * @param temperature 当前温度（单位：0.1℃）
 * @param profile 温度-功率因子曲线数组
 * @param size 温度-功率因子曲线数组的大小
 * @return 当前温度对应的功率因子，如果温度超出范围，返回边界值或默认值
 */
static float linear_interpolate(int16_t temperature, 
                                const TemperaturePowerProfile* profile, 
                                size_t size) {
    // 边界检查：如果温度小于等于最小温度，返回最小温度对应的功率因子
    if (temperature <= profile[0].temperature) {
        return profile[0].power_factor;
    }
    // 边界检查：如果温度大于等于最大温度，返回最大温度对应的功率因子
    if (temperature >= profile[size - 1].temperature) {
        return profile[size - 1].power_factor;
    }

    // 查找当前温度所在的区间
    for (size_t i = 1; i < size; i++) {
        if (temperature < profile[i].temperature) {
            // 线性插值公式：
            // P = P1 + (T - T1) / (T2 - T1) * (P2 - P1)
            int16_t T1 = profile[i - 1].temperature; // 区间下限温度
            int16_t T2 = profile[i].temperature;     // 区间上限温度
            float P1 = profile[i - 1].power_factor;  // 区间下限功率因子
            float P2 = profile[i].power_factor;      // 区间上限功率因子

            // 计算并返回插值结果
            return P1 + (float)(temperature - T1) / (T2 - T1) * (P2 - P1);
        }
    }

    // 默认返回值，通常不会执行到这里
    return 0.0;
}


/**
 * @brief 根据温度、SOC 和额定功率计算充电功率限制
 * @param rated_power 额定功率（单位：0.01KW）
 * @param temperature 当前温度（单位：0.1℃）
 * @param soc 电池的荷电状态（单位：0.1%）
 * @return 充电功率限制值（单位：0.01KW，负值表示充电功率）
 */
static int16_t get_power_charge_limit_temp_soc(int16_t rated_power, 
                                              int16_t temperature, 
                                              uint16_t soc) {
    const TemperaturePowerProfile* profile;  // 温度-功率因子曲线指针
    size_t profile_size;                     // 温度-功率因子曲线数组大小

    // 根据 SOC 值选择不同的温度-功率因子曲线
    if (soc < PCS_CHARGE_SOC_LESS_70) {
        profile = profile_soc_low;  // 使用低 SOC 对应的曲线
        profile_size = sizeof(profile_soc_low) / sizeof(profile_soc_low[0]);
    } else {
        profile = profile_soc_high; // 使用高 SOC 对应的曲线
        profile_size = sizeof(profile_soc_high) / sizeof(profile_soc_high[0]);
    }

    // 通过线性插值计算当前温度对应的功率因子
    float factor = linear_interpolate(temperature, profile, profile_size);

    // 计算功率值：功率值 = 额定功率 * 功率因子 * 转换系数
    uint16_t power_value = (uint16_t)(POWER_KW_CONVERT_10W_COEFFICIENT * rated_power * factor);

    // 限幅处理：确保功率值不超过最大值 30000（即 300KW）
    if (power_value > PCS_MAX_POWER) {
        power_value = PCS_MAX_POWER;
    }

    // 充电功率转换为负数值，表示充电功率
    return (int16_t)(-power_value);
}

/**
 * @brief 根据温度和额定功率计算放电功率限制
 * @param rated_power 额定功率（单位：0.01KW）
 * @param temperature 当前温度（单位：0.1℃）
 * @return 放电功率限制值（单位：0.01KW）
 */
static int16_t get_power_discharge_limit_temp(int16_t rated_power, 
                                             int16_t temperature) {
    // 获取放电功率配置数据
    const TemperaturePowerProfile* profile = discharge_profile;
    // 计算配置数据的长度
    size_t profile_size = sizeof(discharge_profile) / sizeof(discharge_profile[0]);

    // 使用线性插值计算功率系数
    float factor = linear_interpolate(temperature, profile, profile_size);

    // 根据功率系数和额定功率计算功率值
    uint16_t power_value = (uint16_t)(POWER_KW_CONVERT_10W_COEFFICIENT * rated_power * factor);

    // 限幅处理：确保功率值不超过最大值（30000，即300KW）
    if (power_value > PCS_MAX_POWER) {
        power_value = PCS_MAX_POWER;
    }

    // 返回最终的功率限制值
    return (int16_t)power_value;
}

/** 
 * @brief   根据温度与SOC限制PCS充放电功率
 * @param   无
 * @return 	无
 */
static void pcs_power_limit_soc_proc(const uint8_t cluster_index)
{
	static uint8_t count = 0;
	int16_t rated_power = 0;
	int16_t power_value = 0;	// 精度/单位：0.01KW
	int16_t power_value_lowest = 0;	// 精度/单位：0.01KW
	int16_t power_value_highest = 0;	// 精度/单位：0.01KW
	int32_t total_power_limit = 0;
	float64_t pn = 0;
	uint16_t soc;
	uint16_t stanby_power = 0;
	int16_t monomer_lowest_temp; //一簇中单体的最低温度
	int16_t monomer_highest_temp; //一簇中单体的最低温度
	uint16_t pack_num = 0;
	uint16_t cluster_num = 0;
	static uint8_t chg_limit_init = 0;
	static uint8_t dischg_limit_init = 0;
	static int16_t last_chg_power_value = 0; 
	static int16_t last_dischg_power_value = 0; 
	int32_t ret = -1;
	telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();   // 共享内存-遥测数据
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

	if(NULL == p_telemetry_data || p_para_data == NULL)
    {
        return;
    }

	// 获取电池包数量，并限制在 4 到 8 之间
    pack_num = CLAMP(p_para_data->bat_cluster_pack_num, 4, 8);

	// 获取电池簇数量
	cluster_num = p_telemetry_data->container_system_telemetry_info.battery_cluster_number;

	// 计数器递增
    count++;

	// 如果未达到计数上限，直接返回
    if (count <= PCS_POWER_LIMIT_SOC_COUNT_MAX) {
        return;
    }

	// 计算额定功率 Pn = 3.2 * 48 * pack_num * 280 / 1000（转换为 KW）
	pn = (3.2 * 48 * pack_num * 280) / 1000;	
	rated_power = (int16_t)pn;
	soc 		= p_telemetry_data->container_system_telemetry_info.soc;

	// 获取 SOC 和单体温度	
	monomer_lowest_temp = get_battery_min_monomer_temp();           // 获取最低单体温度
	monomer_highest_temp = get_battery_max_monomer_temp();			// 获取最高单体温度

	// 计算放电功率限制
	power_value_lowest = get_power_discharge_limit_temp(rated_power, monomer_lowest_temp);   // 根据最低温度计算限制功率
	power_value_highest = get_power_discharge_limit_temp(rated_power, monomer_highest_temp); // 根据最高温度计算限制功率
	total_power_limit = cluster_num * MIN(power_value_lowest, power_value_highest);
	power_value = CLAMP(total_power_limit, MIN_DISCHG_POWER, MAX_DISCHG_POWER);
	p_telemetry_data->container_system_telemetry_info.discharge_limits_power = CLAMP(power_value,0,12500)/10;
	// 没有设置过放电限制功率或放电限制功率发生变化才下发给PCS
	if(dischg_limit_init == 0 || last_dischg_power_value != power_value)
	{
		ret = pcs_dischgpower_limit_soc_control(power_value);
		if(ret == 0)
		{
			dischg_limit_init = 1;
			last_dischg_power_value = power_value;
		}
		else
		{
			dischg_limit_init = 0;
		}
		
	}
	

	// 计算充电功率限制
	power_value_lowest = get_power_charge_limit_temp_soc(rated_power, monomer_lowest_temp, soc);
	power_value_highest = get_power_charge_limit_temp_soc(rated_power, monomer_highest_temp, soc);
	total_power_limit = cluster_num * MAX(power_value_lowest, power_value_highest);
	power_value = CLAMP(total_power_limit,MIN_CHG_POWER,MAX_CHG_POWER);
	p_telemetry_data->container_system_telemetry_info.charge_limits_power = CLAMP(power_value,-12500,0)/10;

	// 没有设置过充电限制功率或充电限制功率发生变化才下发给PCS
	if(chg_limit_init == 0 || last_chg_power_value != power_value)
	{
		ret = pcs_chgpower_limit_soc_control(power_value);
		if(ret == 0)
		{
			chg_limit_init = 1;
			last_chg_power_value = power_value;
		}
		else
		{
			chg_limit_init = 0;
		}
	}

	count = 0;
}

/**
 * @brief   发起方下发读文件指令（故障录波）（请求帧）
 * @param   [in] timeout_ms  等待应答帧的时长
 * @param   [in] repeat_cnt  重复发送次数
 * @param   [in] dev_id  PCS模块索引，从1开始
 * @param   [in] file_id  文件编号，从1开始
 * @note    
 * @return  false，失败，无应答帧返回；true，成功，有应答帧返回
 */
static bool read_fault_recorder_start(uint32_t timeout_ms, uint8_t repeat_cnt, uint8_t dev_id,uint8_t file_id)
{
	bool ret = true;
	uint8_t i = 0;
	can_msg_t can_msg = {0};

	can_msg.dst_addr = dev_id;
	can_msg.dst_type = DEV_PCS;
	can_msg.prio = 6;
	can_msg.src_addr = 1;
	can_msg.src_type = DEV_CSU_MCU;
	can_msg.fun_code = FUN_FILE_DATA_READ;
	can_msg.type = TYPE_REQ;

	uint8_t buff[8] = {0};
	buff[0] = file_id + 200;//文件编号201对应第1个故障
	buff[1] = 1;//由发起方选择读取该文件内容

	CAN_DEBUG_PRINT("\n [%s:%d] fault_recorder_start\n",__func__, __LINE__);
	for(i=0; i<repeat_cnt; i++)
	{
		g_fault_record_info.status = CAN_UPDATE_STATUS_WAIT_ACK;
		cup_sofar_can_send(CAN_PORT_PCS,&can_msg,buff,2);
		ret = can_file_wait_respose(timeout_ms);
		if(true == ret)
		{
			CAN_DEBUG_PRINT("\n [%s:%d] read_fault_recorder_start success!file_id[%d],dev_id[%d]\n",__func__, __LINE__,file_id,dev_id);
			break;
		}
		can_update_delay_ms(5);
	}
	return(ret);
}

/**
 * @brief  请求故障录波文件
 * @param  [in] timeout_ms 超时等待时间
 * @param  [in] repeat_cnt 重发次数
 * @param   [in] dev_id  PCS模块索引，从1开始
 * @param  [in] file_id 故障录波文件编号
 * @param  [in] offset 文件偏移地址
 * @return 
 */
static bool read_fault_recorder(uint32_t timeout_ms, uint8_t repeat_cnt, uint8_t dev_id,uint8_t file_id,uint16_t offset)
{
	bool ret = true;
	uint8_t i = 0;
	can_msg_t can_msg = {0};
	uint16_t len = 1;//PCS模块以固定的长度在发帧，此处先固定为1

	can_msg.dst_addr = dev_id;
	can_msg.dst_type = DEV_PCS;
	can_msg.prio = 6;
	can_msg.src_addr = 1;
	can_msg.src_type = DEV_CSU_MCU;
	can_msg.fun_code = FUN_FILE_DATA_READ;
	can_msg.type = TYPE_REQ;

	uint8_t buff[8] = {0};
	buff[0] = file_id;//文件编号201对应第1个故障
	buff[1] = offset & 0xff;//当前文件偏移地址低位
	buff[2] = (offset >> 8) & 0xff;//当前文件偏移地址高位
	buff[3] = len & 0xff;
	buff[4] = (len >> 8) & 0xff;

	CAN_DEBUG_PRINT("\n [%s:%d] read_fault_recorder file_id[%x],offset[%d]\n",__func__, __LINE__,file_id,offset);
	for(i=0; i< repeat_cnt; i++)
	{
		g_fault_record_info.status = CAN_UPDATE_STATUS_WAIT_ACK;
		cup_sofar_can_send(CAN_PORT_PCS,&can_msg,buff,5);
		ret = can_file_wait_respose(timeout_ms);
		if(true == ret)
		{
			CAN_DEBUG_PRINT("\n [%s:%d] read_fault_recorder success!file_id[%d],offset[%d]\n",__func__, __LINE__,file_id,offset);
			break;
		}
		can_update_delay_ms(5);
	}
	return(ret);
}

/**
 * @brief  从PCS获取故障录波文件
 * @param  [in] dev_id  PCS模块ID
 * @param  [in] file_id  故障录波文件ID
 * @return 
 */
int32_t can_get_fault_recorder(uint8_t dev_id,uint8_t file_id)
{

	uint16_t i = 0;
	bool ret = true;
	uint8_t progress = 0;
	uint16_t tmp_progress = 0;
	tmp_progress = g_fault_record_info.progress;
	internal_shared_data_t *p_internal_data = internal_shared_data_get();			// 内部共用参数

	if((file_id == 0) || (p_internal_data == NULL))
	{
		p_internal_data->pcs_fault_recorder_info.progress = -1;
		return -1;
	}
	//update_pcs_flag(1);
	CAN_DEBUG_PRINT("\n [%s:%d] dev_id[%d],file_id[%d] step 1\n",__func__, __LINE__,dev_id,file_id);
	//sleep(11);//实测10s，MCU2的查询帧才会停止
	CAN_DEBUG_PRINT("\n [%s:%d] dev_id[%d],file_id[%d] step 2\n",__func__, __LINE__,dev_id,file_id);
	ret = read_fault_recorder_start(1000,3,dev_id,file_id);
	if(ret == false)
	{
		CAN_DEBUG_PRINT("\n [%s:%d] start fault recorder failed!\n",__func__, __LINE__);
		//update_pcs_flag(0);
		p_internal_data->pcs_fault_recorder_info.progress = -1;
		return -1;
	}
	CAN_DEBUG_PRINT("\n [%s:%d] step 3\n",__func__, __LINE__);
	can_update_delay_ms(100);

	for(i=0; i<= 50; i++)
	{
		ret = read_fault_recorder(2000,3,dev_id,g_fault_record_info.file_id,i);
		if(ret != true)
		{
			CAN_DEBUG_PRINT("\n read_fault_recorder:fail, current file_id:%d\r\n", i);	//log_e
			//update_pcs_flag(0);
			p_internal_data->pcs_fault_recorder_info.progress = -1;
			return -1;
		}
		progress = i*100/50;
		g_fault_record_info.progress = tmp_progress + progress;

		if(p_internal_data->pcs_fault_recorder_info.file_id != 0)
		{
			if(progress > 0)
			{
				p_internal_data->pcs_fault_recorder_info.progress = progress;
			}
			else
			{
				p_internal_data->pcs_fault_recorder_info.progress = progress - 1;
			}
			
		}
		else
		{
			if(g_fault_record_info.progress/10 > 0)
			{
				p_internal_data->pcs_fault_recorder_info.progress = (g_fault_record_info.progress/10) - 1;
			}
			else 
			{
				p_internal_data->pcs_fault_recorder_info.progress = g_fault_record_info.progress/10;
			}

		}
		CAN_DEBUG_PRINT("\n read_fault_recorder:success, current file_id:%d\r\n", i);
		can_update_delay_ms(5);
	}
	//sleep(3);
	//update_pcs_flag(0);
	CAN_DEBUG_PRINT("\n [%s:%d] step 4\n",__func__, __LINE__);
	return 0;
}

void *thread_can_send(void *args)
{
    prctl(PR_SET_NAME, "can_send");
    int32_t ret = SF_OK;
	uint16_t i = 0;
    uint8_t update_flag = 0;
    uint32_t dev_mask = 0;
	uint8_t soc_range_id;
    firmware_update_t *p_update = NULL;
    pcs_firmware_update_task_t *p_task = NULL;
    p_update = get_shm_update_stru();
    p_task = get_pcs_update_task_stru();
	common_data_t *psc_common_data = sdk_shm_get();
	internal_shared_data_t *p_internal_data = internal_shared_data_get();
	web_control_info_t *web_control_info = shm_web_control_info_get();

	static uint16_t dev_info1_count = 0;
	static uint16_t dev_info2_count = 0;
	static uint16_t dev_param1_count = 0;
	static uint16_t dev_param2_count = 0;

	
	/* V1.0.13版本启用温度和SOC回差和排异*/
	// range_handle_t soc_range_handle;
	// range_handle_t temp1_range_handle;
	// range_handle_t temp2_range_handle;

	// soc_range_handle = get_range_handle_by_type(RANGE_HANDLE_TYPE_SOC);
	// temp1_range_handle = get_range_handle_by_type(RANGE_HANDLE_TYPE_TEMP1);
	// temp2_range_handle = get_range_handle_by_type(RANGE_HANDLE_TYPE_TEMP2);

	// if(!soc_range_handle || !temp1_range_handle || !temp2_range_handle)
	// {
	// 	printf("create range handle failed.\n");
	// 	return NULL;
	// }
	// /*设置初始ID空间为5，即1pn,防止在出发次数未达到valid count之前,id一直为0xff,导致限制功率为-0.01*/
	// range_set_range_id(temp1_range_handle, 5);
	// range_set_range_id(temp2_range_handle, 5);
    while(1)
    {        
		if(p_internal_data->pcs_fault_recorder_info.fault_recorder_export_flag == 1)
		{
			//文件读取前进度清0
			g_fault_record_info.progress = 0;	
			p_internal_data->pcs_fault_recorder_info.progress = 0;
			p_internal_data->pcs_fault_recorder_info.fault_recorder_export_flag = 0;
			// 导出单个故障数据文件
			if((p_internal_data->pcs_fault_recorder_info.file_id >= 1) && (p_internal_data->pcs_fault_recorder_info.file_id <= 10))
			{
				sdk_system_cmd((int8_t*)"rm -rf /user/data/pcs_fault_record/*");
				ret = can_get_fault_recorder(0,p_internal_data->pcs_fault_recorder_info.file_id);
				sleep(1);
				if(ret == 0)
				{
					sdk_system_cmd((int8_t*)"cd /user/data/pcs_fault_record/ ; tar -zcvf fault_recorder.tar.gz *.fw");
					p_internal_data->pcs_fault_recorder_info.progress = 100;
				}
				
			}
			// 导出所有故障数据文件
			else if(p_internal_data->pcs_fault_recorder_info.file_id == 0)
			{
				sdk_system_cmd((int8_t*)"rm -rf /user/data/pcs_fault_record/*");
				for(i = 1;i <= 10;i++)
				{
					ret = can_get_fault_recorder(0,i);
					if(ret != 0)
					{
						break;
					}
				}
				sleep(1);
				if(ret == 0)
				{
					sdk_system_cmd((int8_t*)"cd /user/data/pcs_fault_record/ ; tar -zcvf fault_recorder.tar.gz *.fw");
					p_internal_data->pcs_fault_recorder_info.progress = 100;
				}
			}
		}
        update_flag = firmware_update_flag();
        if(PCS_BROADCAST_UPGRADE == update_flag)//广播升级
        {
            printf("Broadcast upgrade\n");
            can_update_master_update_stepup(DEV_PCS, 0, 8);
            dev_mask = can_update_master_send_fw();
            printf(("\n [%s:%d]  dev_mask=%d!\n"),__func__, __LINE__,dev_mask);
            sleep(5);
        }
        else if(PCS_UNICAST_UPGRADE == update_flag)//单播升级
        {
			pcs_power_control(PCS_POWER_OFF);      // 升级前给PCS下发关机指令
            printf("Unicast upgrade index[%d]\n",p_update->upgrade_pcs_index);
            sleep(2);
            can_update_master_update_stepup(DEV_PCS, p_update->upgrade_pcs_index, 1);
            dev_mask = can_update_master_send_fw();
            printf(("\n [%s:%d]  dev_mask=%d!\n"),__func__, __LINE__,dev_mask);
            memset(p_update->module_object[p_task->pcs_firm.index], 0, sizeof(p_update->module_object[p_task->pcs_firm.index]));
            sleep(15);  //等待PCS重启
        }

		can_process_import_safety();	// 响应web导入的安规参数，执行转发

		// 关键信息每轮查询，次要信息n间隔查询
        // 读取设备信息 0 ~ 19
		if(dev_info1_count++ >= DEV_INFO1_INTERVAL)
		{
			ret = pcs_tele_data_query(PCS_FUN_CODE_DEV_INFO, 0, 0, 20);
			if (ret != SF_OK)
			{
				CAN_DEBUG_PRINT((int8_t *)"[%s:%d] ret = %d \n", __func__, __LINE__, ret);
			}
			sdk_delay_ms(PCS_DATA_QUERY_TIME_INTERVAL_MS);
			dev_info1_count = 0;
		}
        
 
        // 读取设备信息 10000 ~ 10022, 采集23个设备相关信息
		if(dev_info2_count++ >= DEV_INFO2_INTERVAL)
		{
			ret = pcs_tele_data_query(PCS_FUN_CODE_DEV_INFO, 0, 10000, 23); // pcs_tele_data_query(PCS_FUN_CODE_DEV_INFO, 0, 10000, 14);
			if (ret != SF_OK)
			{
				CAN_DEBUG_PRINT((int8_t *)"[%s:%d] ret = %d \n", __func__, __LINE__, ret);
			}
			sdk_delay_ms(PCS_DATA_QUERY_TIME_INTERVAL_MS);
			dev_info2_count = 0;
		}
        
 
        // 读取遥信信息 0 ~ 19 故障和告警信息
        ret = pcs_tele_data_query(PCS_FUN_CODE_YX_INFO, 0, 0, 20);
        if (ret != SF_OK)
        {
            CAN_DEBUG_PRINT((int8_t *)"[%s:%d] ret = %d \n", __func__, __LINE__, ret);
        }
        sdk_delay_ms(PCS_DATA_QUERY_TIME_INTERVAL_MS);

		// 读取遥信信息 10000 ~ 10001 电网故障重连状态
		if(p_internal_data->pcs_fault_restore_flag_query == 1)
		{
			ret = pcs_tele_data_query(PCS_FUN_CODE_YX_INFO, 0, 10000, 1);
			if (ret != SF_OK)
			{
				CAN_DEBUG_PRINT((int8_t *)"[%s:%d] ret = %d \n", __func__, __LINE__, ret);
			}
			sdk_delay_ms(PCS_DATA_QUERY_TIME_INTERVAL_MS);
		}
        
 
        // 读取遥测信息 0 ~ 35,包含系统实时时间年月日时分秒以及入网侧RST电流
        ret = pcs_tele_data_query(PCS_FUN_CODE_YC_INFO, 0, 0, 35);
        if (ret != SF_OK)
        {
            CAN_DEBUG_PRINT((int8_t *)"[%s:%d] ret = %d \n", __func__, __LINE__, ret);
        }
        sdk_delay_ms(PCS_DATA_QUERY_TIME_INTERVAL_MS);
 
        // 读取遥测信息 10000 ~ 10037
        ret = pcs_tele_data_query(PCS_FUN_CODE_YC_INFO, 0, 10000, 38);
        if (ret != SF_OK)
        {
            CAN_DEBUG_PRINT((int8_t *)"[%s:%d] ret = %d \n", __func__, __LINE__, ret);
        }
        sdk_delay_ms(PCS_DATA_QUERY_TIME_INTERVAL_MS);
 
        // 读取遥测信息 20000 ~ 20002
        ret = pcs_tele_data_query(PCS_FUN_CODE_YC_INFO, 0, 20000, 3);
        if (ret != SF_OK)
        {
            CAN_DEBUG_PRINT((int8_t *)"[%s:%d] ret = %d \n", __func__, __LINE__, ret);
        }
        sdk_delay_ms(PCS_DATA_QUERY_TIME_INTERVAL_MS);
 
        // 读取定值参数 0 ~ 29
        ret = pcs_tele_data_query(PCS_FUN_CODE_READ_PARAM, 0, 0, 30);
        if (ret != SF_OK)
        {
            CAN_DEBUG_PRINT((int8_t *)"[%s:%d] ret = %d \n", __func__, __LINE__, ret);
        }
        sdk_delay_ms(PCS_DATA_QUERY_TIME_INTERVAL_MS);
 
        // 读取定值参数 10000 ~ 10030
		if(dev_param1_count++ >= DEV_PARA1_INTERVAL || (web_control_info->pcs_factory_mode_set_flag & BIT(7)) )
		{
			if(web_control_info->pcs_factory_mode_set_flag & BIT(7))
			{
				web_control_info->pcs_factory_mode_set_flag &= ~BIT(7);
			}
			ret = pcs_tele_data_query(PCS_FUN_CODE_READ_PARAM, 0, 10000, 32);
			if (ret != SF_OK)
			{
				CAN_DEBUG_PRINT((int8_t *)"[%s:%d] ret = %d \n", __func__, __LINE__, ret);
			}
			sdk_delay_ms(PCS_DATA_QUERY_TIME_INTERVAL_MS);
			dev_param1_count = 0;
		}
        
		// 读取定值参数 20000 ~ 20004
		if(dev_param2_count++ >= DEV_PARA2_INTERVAL)
		{
			ret = pcs_tele_data_query(PCS_FUN_CODE_READ_PARAM, 0, 20000, 5);
			if (ret != SF_OK)
			{
				CAN_DEBUG_PRINT((int8_t *)"[%s:%d] ret = %d \n", __func__, __LINE__, ret);
			}
			sdk_delay_ms(PCS_DATA_QUERY_TIME_INTERVAL_MS);
			dev_param2_count = 0;
		}
        
        // 读取定值参数 2304 ~ 2306
        ret = pcs_tele_data_query(PCS_FUN_CODE_READ_SAFETY_PARAM, 0, 2304, 3);
        if (ret != SF_OK)
        {
            CAN_DEBUG_PRINT((int8_t *)"[%s:%d] ret = %d \n", __func__, __LINE__, ret);
        }
		sdk_delay_ms(PCS_DATA_QUERY_TIME_INTERVAL_MS);

		// PCS低功耗模式未使能，下发指令使能低功耗模式
		if (psc_common_data->constant_parameter_data.pcs_parameter_data[0].low_power_mode_enable == PCS_LOWPOWER_DISABLE)
		{
			ret = pcs_lowpower_control(PCS_LOWPOWER_ENABLE);

		}

		// 根据温度与SOC计算PCS的充放电功率
		pcs_power_limit_soc_proc(0);
    }
}


