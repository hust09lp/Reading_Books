/** 
 * @file          pcs_fun_interface.c
 * @brief         PCS模块通信功能外部接口函数实现
 * @author        liangguyao
 * @version       V0.0.1     初始版本
 * @date          2023/09/14
 * @copyright     Copyright (c) 2023 by SofarSolar, All Rights Reserved.
 */


#include "pcs_fun_interface.h"
#include "can_update.h"
#include "sofar_errors.h"
#include "sofar_log.h"
#include "data_shm.h"

#include <stdlib.h>
#include <string.h>

#define PCS_RUN_OFFSET                  (0)     // PCS开关机指令在点表功能码对应的偏移地址
#define PCS_TIME_SEC_OFFSET             (6)     // PCS系统时间 - 秒在点表功能码对应的偏移地址
#define PCS_TIME_MIN_OFFSET             (7)     // PCS系统时间 - 分在点表功能码对应的偏移地址
#define PCS_TIME_HOUR_OFFSET            (8)     // PCS系统时间 - 时在点表功能码对应的偏移地址
#define PCS_TIME_DAY_OFFSET             (9)     // PCS系统时间 - 日在点表功能码对应的偏移地址
#define PCS_TIME_MON_OFFSET             (10)    // PCS系统时间 - 月在点表功能码对应的偏移地址
#define PCS_TIME_YEAR_OFFSET            (11)    // PCS系统时间 - 年在点表功能码对应的偏移地址
#define PCS_CHG_DISCHG_FORBID_OFFSET    (21)    // PCS禁止充电禁止放电指令在点表功能码对应的偏移地址
#define PCS_CHGPOWER_LIMIT_SOC_OFFSET   (22)    // 根据温度与SOC限制PCS充电功率指令在点表功能码对应的偏移地址
#define PCS_LOWPOWER_ENABLE_OFFSET      (23)    // PCS低功耗使能指令在点表功能码对应的偏移地址
#define PCS_DISCHGPOWER_LIMIT_SOC_OFFSET   (25)    // 根据温度与SOC限制PCS放电功率指令在点表功能码对应的偏移地址
#define PCS_POWERUP_TIME_GRADIDENT_OFFSET  (18)     // PCS功率软启时间梯度在点表中对应的便宜地址
#define PCS_RESET_OFFSET                (20002)    // 复位偏移地址
#define PCS_FACTORY_MODE_OFFSET         (10031)    // 工厂模式偏移地址

#define PCS_CHGPOWER_LIMIT_MAX          (-30000) // 根据温度与SOC限制的PCS充电功率最大值（-300KW）
#define PCS_DISCHGPOWER_LIMIT_MAX       (30000)  // 根据温度与SOC限制的PCS放电功率最大值（300KW）

#define PCS_POWERUP_GRADIDENT_MAX       (60000)     // 功率软启时间梯度最大值 
#define PCS_POWERUP_GRADIDENT_MIN       (1)         // 功率软启时间梯度最小值 

#define PCS_ONOFF_CMD_SIZE          (2)
#define PCS_CHG_DISCHG_CMD_SIZE     (2)
#define PCS_POWER_LIMIT_CMD_SIZE    (2)
#define PCS_TIME_SET_SIZE           (2)
#define PCS_LOWPOWER_CMD_SIZE       (2)
#define PCS_RESET_CMD_SIZE          (2)
#define PCS_POWERUP_GRADIDENT_CMD_SIZE       (2)    
#define PCS_FACTORY_MODE_CMD_SIZE   (2)       

#include "mem_utils.h"
/**
 * @brief   CAN数据打包发送给PCS模块
 * @param   [in] can_msg  CAN ID信息
 * @param   [in] p_data  需要发送的数据
 * @param   [in] len  需要发送的数据长度
 * @note    调用此函数之前需要APP层自己调用打开CAN的SDK接口
 * @return 	[int32_t] 执行结果
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败，返回错误码
 */
static int32_t pcs_can_send(can_msg_t *p_can_msg, uint8_t *p_data, int32_t len)
{
    int32_t ret;
    uint8_t i;

    for (i = 0; i < 3; i++)
    {
        ret = cup_sofar_can_send(CAN_PORT_PCS, p_can_msg, p_data, len);
        if(ret == SF_OK)
        {
            break;
        }
    }

    /* 通过CAN下发数据给PCS失败处理 */
    if (ret != SF_OK)
    {
        PCS_FUN_DEBUG((int8_t *)"\n [%s:%d] send pcs_can_send error, ret = %d\n", __func__, __LINE__,  ret);
        return ret;
    }else{
        // mem_utils_print_hex_dat( "pcs_can_send ", p_data, len, 10, true );
    }

    return SF_OK;
}

/** 
 * @brief   控制PCS开关机指令
 * @param   [in] command_type   命令类型 0：关机 1：开机 2：紧急关机，其他：无效 pcs_control_command_type_e
 * @return 	[int32_t] 执行结果
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败，返回错误码
 */
int32_t pcs_power_control(pcs_power_control_cmd_type_e command_type)
{
    int32_t ret;
    uint8_t data_buf[PCS_ONOFF_CMD_SIZE];
    
    can_msg_t can_msg = {0};

    can_msg.src_addr = 1;
    can_msg.src_type = DEV_CSU_MCU;
    can_msg.dst_addr = 1;
    can_msg.dst_type = DEV_PCS;
    can_msg.prio = PRIO_DATA;
    can_msg.fun_code = PCS_FUN_CODE_WRITE_PARAM; // 功能码
    can_msg.type = TYPE_DATA;   // 数据帧
    can_msg.addr = PCS_RUN_OFFSET;   // 点表起始位置

    /* 清空缓存 */
    memset(data_buf, 0, sizeof(data_buf));

    /* 命令类型数据填充 */
    data_buf[0] = command_type;

    /* 通过CAN下发开关机指令给PCS */
    ret = pcs_can_send(&can_msg, data_buf, PCS_ONOFF_CMD_SIZE);
    if(ret == SF_OK)
    {
        log_i((const int8_t*)"\n [%s:%d] pcs_power_control, command_type = %d \n", __func__, __LINE__, command_type);
    }
    else   /* 通过CAN下发开关机指令给PCS失败处理 */
    {
        log_i((int8_t *)"\n [%s:%d] send pcs_power_control error, command_type = %d, ret = %d\n",__func__, __LINE__, command_type, ret);
    }

    return SF_OK;
}

/** 
 * @brief   控制PCS禁止充电、禁止放电指令
 * @param   [in] command_type   命令类型
 *          PCS_CHG_DISCHG_FORBID_OFF   ：“禁止充电”、“禁止放电”都关闭
 *          PCS_CHG_FORBID_ON           ：仅打开“禁止充电”
 *          PCS_DISCHG_FORBID_ON        ：仅打开“禁止放电”
 *          PCS_CHG_DISCHG_FORBID_ON    ：“禁止充电”、“禁止放电”都打开
 *          其他：无效 pcs_chg_dischg_forbid_control_cmd_type_e
 * @return 	[int32_t] 执行结果
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败，返回错误码
 */
int32_t pcs_chg_dischg_forbid_control(pcs_chg_dischg_forbid_control_cmd_type_e command_type)
{
    int32_t ret;
    uint8_t data_buf[PCS_CHG_DISCHG_CMD_SIZE];
    
    can_msg_t can_msg = {0};

    can_msg.src_addr = 1;
    can_msg.src_type = DEV_CSU_MCU;
    can_msg.dst_addr = 1;
    can_msg.dst_type = DEV_PCS;
    can_msg.prio = PRIO_DATA;
    can_msg.fun_code = PCS_FUN_CODE_WRITE_PARAM; // 功能码
    can_msg.type = TYPE_DATA;   // 数据帧
    can_msg.addr = PCS_CHG_DISCHG_FORBID_OFFSET;   // 点表起始位置

    /* 清空缓存 */
    memset(data_buf, 0, sizeof(data_buf));

    /* 命令类型数据填充 */
    data_buf[0] = command_type;

    /* 通过CAN下发开关机指令给PCS */
    ret = pcs_can_send(&can_msg, data_buf, PCS_CHG_DISCHG_CMD_SIZE);
    if(ret == SF_OK)
    {
     //   log_i("\n [%s:%d] pcs_chg_dischg_forbid_control, command_type = %d \n", __func__, __LINE__, command_type);
    }
    else   /* 通过CAN下发开关机指令给PCS失败处理 */
    {
        log_i((int8_t *)"\n [%s:%d] send pcs_chg_dischg_forbid_control error, command_type = %d, ret = %d\n",__func__, __LINE__, command_type, ret);
    }

    return SF_OK;
}

/** 
 * @brief   根据温度与SOC限制PCS充放电功率指令
 * @param   [in] power_value    限制的功率值（单位0.01KW，实际功率值放大100倍，取值范围：-30000 ~ 30000之间，即-300KW ~ 300KW，放电为正，充电为负）
 * @return 	[int32_t] 执行结果
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败，返回错误码
 */
int32_t pcs_chgpower_limit_soc_control(int16_t power_value)
{
    int32_t ret;
    uint8_t data_buf[PCS_POWER_LIMIT_CMD_SIZE];
    
    can_msg_t can_msg = {0};

    can_msg.src_addr = 1;
    can_msg.src_type = DEV_CSU_MCU;
    can_msg.dst_addr = 1;
    can_msg.dst_type = DEV_PCS;
    can_msg.prio = PRIO_DATA;
    can_msg.fun_code = PCS_FUN_CODE_WRITE_PARAM; // 功能码
    can_msg.type = TYPE_DATA;   // 数据帧
    can_msg.addr = PCS_CHGPOWER_LIMIT_SOC_OFFSET;   // 点表起始位置

    /* 入参的功率值合法性判断 */
    if ((power_value < PCS_CHGPOWER_LIMIT_MAX) || (power_value > PCS_POWER_LIMIT_MIN))
    {
        log_i((int8_t *)"\n [%s:%d] error, power_value = %d \n", __func__, __LINE__, power_value);
        return SF_ERR_PARA;
    }

    /* 清空缓存 */
    memset(data_buf, 0, sizeof(data_buf));

    /* 命令类型数据填充 */
    data_buf[0] = power_value & 0xFF;
    data_buf[1] = (power_value >> 8) & 0xFF;

    /* 通过CAN下发开关机指令给PCS */
    ret = pcs_can_send(&can_msg, data_buf, PCS_POWER_LIMIT_CMD_SIZE);
    if(ret == SF_OK)
    {
       //  log_i("\n [%s:%d] pcs_power_limit_soc_control111, power_value = %d \n", __func__, __LINE__, power_value);
    }
    else   /* 通过CAN下发开关机指令给PCS失败处理 */
    {
        log_i((int8_t *)"\n [%s:%d] send pcs_power_limit_soc_control error, power_value = %d, ret = %d\n",__func__, __LINE__, power_value, ret);
    }

    return SF_OK;
}

/** 
 * @brief   根据温度与SOC限制PCS放电功率指令
 * @param   [in] power_value    限制的功率值（单位0.01KW，实际功率值放大100倍，取值范围：0 ~ 30000之间，即0KW ~ 300KW）
 * @return 	[int32_t] 执行结果
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败，返回错误码
 */
int32_t pcs_dischgpower_limit_soc_control(int16_t power_value)
{
    int32_t ret;
    uint8_t data_buf[PCS_POWER_LIMIT_CMD_SIZE];
    
    can_msg_t can_msg = {0};

    can_msg.src_addr = 1;
    can_msg.src_type = DEV_CSU_MCU;
    can_msg.dst_addr = 1;
    can_msg.dst_type = DEV_PCS;
    can_msg.prio = PRIO_DATA;
    can_msg.fun_code = PCS_FUN_CODE_WRITE_PARAM; // 功能码
    can_msg.type = TYPE_DATA;   // 数据帧
    can_msg.addr = PCS_DISCHGPOWER_LIMIT_SOC_OFFSET;   // 点表起始位置

    /* 入参的功率值合法性判断 */
    if ((power_value > PCS_DISCHGPOWER_LIMIT_MAX) || (power_value < PCS_POWER_LIMIT_MIN))
    {
        log_i((int8_t *)"\n [%s:%d] error, dischg_power_value = %d \n", __func__, __LINE__, power_value);
        return SF_ERR_PARA;
    }

    /* 清空缓存 */
    memset(data_buf, 0, sizeof(data_buf));

    /* 命令类型数据填充 */
    data_buf[0] = power_value & 0xFF;
    data_buf[1] = (power_value >> 8) & 0xFF;

    /* 通过CAN下发开关机指令给PCS */
    ret = pcs_can_send(&can_msg, data_buf, PCS_POWER_LIMIT_CMD_SIZE);
    if(ret == SF_OK)
    {
    //    log_i("\n [%s:%d] pcs_dischg_power_limit_soc_control111, power_value = %d \n", __func__, __LINE__, power_value);
    }
    else   /* 通过CAN下发开关机指令给PCS失败处理 */
    {
        log_i((int8_t *)"\n [%s:%d] send pcs_dischg_power_limit_soc_control error, power_value = %d, ret = %d\n",__func__, __LINE__, power_value, ret);
    }

    return SF_OK;
}

/** 
 * @brief   PCS模块时间设置
 * @param   [in] p_time rtc时间结构体,详见sdk_rtc_t定义
 * @return 	[int32_t] 执行结果
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败，返回错误码
 */
int32_t pcs_time_set(sdk_rtc_t *p_time)
{
    int32_t ret;
    uint8_t data_buf[PCS_TIME_SET_SIZE];
    can_msg_t can_msg = {0};

    if (p_time == NULL)
    {
       PCS_FUN_DEBUG("\n [%s:%d] null pointer !\n", __func__, __LINE__); 
       return -1;
    }

    can_msg.src_addr = 1;
    can_msg.src_type = DEV_CSU_MCU;
    can_msg.dst_addr = 1;
    can_msg.dst_type = DEV_PCS;
    can_msg.prio = PRIO_DATA;
    can_msg.fun_code = PCS_FUN_CODE_WRITE_PARAM; // 功能码
    can_msg.type = TYPE_DATA;   // 数据帧

    /* 清空缓存 */
    memset(data_buf, 0, sizeof(data_buf));

    /* 秒 */
    can_msg.addr = PCS_TIME_SEC_OFFSET;     // PCS系统时间 - 秒在点表功能码对应的偏移地址
    data_buf[0] = p_time->tm_sec;
    ret = pcs_can_send(&can_msg, data_buf, PCS_TIME_SET_SIZE);
    if (ret < SF_OK)
    {
       PCS_FUN_DEBUG((int8_t *)"\n [%s:%d] send pcs_time_set sec error, ret = %d\n",__func__, __LINE__, ret);
       return ret;
    }

    /* 分 */
    can_msg.addr = PCS_TIME_MIN_OFFSET;     // PCS系统时间 - 分在点表功能码对应的偏移地址
    data_buf[0] = p_time->tm_min;
    ret = pcs_can_send(&can_msg, data_buf, PCS_TIME_SET_SIZE);
    if (ret < SF_OK)
    {
       PCS_FUN_DEBUG((int8_t *)"\n [%s:%d] send pcs_time_set min error, ret = %d\n",__func__, __LINE__, ret);
       return ret;
    }

    /* 时 */
    can_msg.addr = PCS_TIME_HOUR_OFFSET;    // PCS系统时间 - 时在点表功能码对应的偏移地址
    data_buf[0] = p_time->tm_hour;
    ret = pcs_can_send(&can_msg, data_buf, PCS_TIME_SET_SIZE);
    if (ret < SF_OK)
    {
       PCS_FUN_DEBUG((int8_t *)"\n [%s:%d] send pcs_time_set hour error, ret = %d\n",__func__, __LINE__, ret);
       return ret;
    }

    /* 日 */
    can_msg.addr = PCS_TIME_DAY_OFFSET;     // PCS系统时间 - 日在点表功能码对应的偏移地址
    data_buf[0] = p_time->tm_day;
    ret = pcs_can_send(&can_msg, data_buf, PCS_TIME_SET_SIZE);
    if (ret < SF_OK)
    {
       PCS_FUN_DEBUG((int8_t *)"\n [%s:%d] send pcs_time_set day error, ret = %d\n",__func__, __LINE__, ret);
       return ret;
    }

    /* 月 */
    can_msg.addr = PCS_TIME_MON_OFFSET;     // PCS系统时间 - 月在点表功能码对应的偏移地址
    data_buf[0] = p_time->tm_mon;
    ret = pcs_can_send(&can_msg, data_buf, PCS_TIME_SET_SIZE);
    if (ret < SF_OK)
    {
       PCS_FUN_DEBUG((int8_t *)"\n [%s:%d] send pcs_time_set mon error, ret = %d\n",__func__, __LINE__, ret);
       return ret;
    }

    /* 年 */
    can_msg.addr = PCS_TIME_YEAR_OFFSET;    // PCS系统时间 - 年在点表功能码对应的偏移地址
    data_buf[0] = p_time->tm_year;
    ret = pcs_can_send(&can_msg, data_buf, PCS_TIME_SET_SIZE);
    if (ret < SF_OK)
    {
       PCS_FUN_DEBUG((int8_t *)"\n [%s:%d] send pcs_time_set mon error, ret = %d\n",__func__, __LINE__, ret);
    }
    return ret;
}

/** 
 * @brief   PCS低功耗模式设置   使能低功耗模式后i待机5分钟会封波
 * @param   [in] command_type   命令类型 0：禁止 1：使能 其他：无效 
 * @return 	[int32_t] 执行结果
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败，返回错误码
 */
int32_t pcs_lowpower_control(pcs_lowpower_control_cmd_type_e command_type)
{
    int32_t ret;
    uint8_t data_buf[PCS_LOWPOWER_CMD_SIZE];
    
    can_msg_t can_msg = {0};

    can_msg.src_addr = 1;
    can_msg.src_type = DEV_CSU_MCU;
    can_msg.dst_addr = 1;
    can_msg.dst_type = DEV_PCS;
    can_msg.prio = PRIO_DATA;
    can_msg.fun_code = PCS_FUN_CODE_WRITE_PARAM; // 功能码
    can_msg.type = TYPE_DATA;   // 数据帧
    can_msg.addr = PCS_LOWPOWER_ENABLE_OFFSET;   // 点表起始位置

    /* 清空缓存 */
    memset(data_buf, 0, sizeof(data_buf));

    /* 命令类型数据填充 */
    data_buf[0] = command_type;

    /* 通过CAN下发开关机指令给PCS */
    ret = pcs_can_send(&can_msg, data_buf, PCS_LOWPOWER_CMD_SIZE);
    if(ret == SF_OK)
    {
        log_i((const int8_t*)"\n [%s:%d] pcs_lowpower_control, command_type = %d \n", __func__, __LINE__, command_type);
    }
    else   /* 通过CAN下发开关机指令给PCS失败处理 */
    {
        log_i((int8_t *)"\n [%s:%d] send pcs_lowpower_control error, command_type = %d, ret = %d\n",__func__, __LINE__, command_type, ret);
    }

    return SF_OK;
}

/** 
 * @brief   PCS软复位指令
 * @param   [in] cmd 1:软件复位
 * @return 	[int32_t] 执行结果
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败，返回错误码
 */
int32_t pcs_reset_control(int16_t command)
{
    int32_t ret;
    uint8_t data_buf[PCS_RESET_CMD_SIZE];
    
    can_msg_t can_msg = {0};

    can_msg.src_addr = 1;
    can_msg.src_type = DEV_CSU_MCU;
    can_msg.dst_addr = 1;
    can_msg.dst_type = DEV_PCS;
    can_msg.prio = PRIO_DATA;
    can_msg.fun_code = PCS_FUN_CODE_WRITE_PARAM; // 功能码
    can_msg.type = TYPE_DATA;   // 数据帧
    can_msg.addr = PCS_RESET_OFFSET;   // 点表起始位置

    /* 清空缓存 */
    memset(data_buf, 0, sizeof(data_buf));

    /* 命令类型数据填充 */
    data_buf[0] = command & 0xFF;
    data_buf[1] = (command >> 8) & 0xFF;

    /* 通过CAN下发开关机指令给PCS */
    ret = pcs_can_send(&can_msg, data_buf, PCS_POWER_LIMIT_CMD_SIZE);
    if(ret == SF_OK)
    {
        log_i((const int8_t*)"\n [%s:%d] pcs_reset_control \n", __func__, __LINE__);
    }
    else   /* 通过CAN下发开关机指令给PCS失败处理 */
    {
        log_i((int8_t *)"\n [%s:%d] pcs_reset_control error\n",__func__, __LINE__);
    }

    return SF_OK;
}

/** 
 * @brief   设置功率软启时间梯度
 * @param   [in] power_value    限制的功率值（单位0.01KW，实际功率值放大100倍，取值范围：0 ~ 30000之间，即0KW ~ 300KW）
 * @return 	[int32_t] 执行结果
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败，返回错误码
 */
int32_t pcs_powerup_gradident_set_control(uint16_t gradident)
{
    int32_t ret;
    uint8_t data_buf[PCS_POWER_LIMIT_CMD_SIZE];
    
    can_msg_t can_msg = {0};

    can_msg.src_addr = 1;
    can_msg.src_type = DEV_CSU_MCU;
    can_msg.dst_addr = 1;
    can_msg.dst_type = DEV_PCS;
    can_msg.prio = PRIO_DATA;
    can_msg.fun_code = PCS_FUN_CODE_WRITE_PARAM; // 功能码
    can_msg.type = TYPE_DATA;   // 数据帧
    can_msg.addr = PCS_POWERUP_TIME_GRADIDENT_OFFSET;  // 点表起始位置

    /* 入参的功率值合法性判断 */
    if ((gradident > PCS_POWERUP_GRADIDENT_MAX) || (gradident < PCS_POWERUP_GRADIDENT_MIN))
    {
        log_i((int8_t *)"\n [%s:%d] error, dischg_power_value = %d \n", __func__, __LINE__, gradident);
        return SF_ERR_PARA;
    }

    /* 清空缓存 */
    memset(data_buf, 0, sizeof(data_buf));

    /* 命令类型数据填充 */
    data_buf[0] = gradident & 0xFF;
    data_buf[1] = (gradident >> 8) & 0xFF;

    /* 通过CAN下发开关机指令给PCS */
    ret = pcs_can_send(&can_msg, data_buf, PCS_POWERUP_GRADIDENT_CMD_SIZE);
    if(ret == SF_OK)
    {
    //    log_i("\n [%s:%d] pcs_dischg_power_limit_soc_control111, power_value = %d \n", __func__, __LINE__, power_value);
    }
    else   /* 通过CAN下发开关机指令给PCS失败处理 */
    {
        log_i((int8_t *)"\n [%s:%d] send pcs_powerup_gradident_set_control error, power_value = %d, ret = %d\n",__func__, __LINE__, gradident, ret);
    }

    return SF_OK;
}

/** 
 * @brief   设置PCS进入/退出工厂模式
 * @param   [in] mode     1:进入工厂模式  0:退出工厂模式
 * @return 	[int32_t] 执行结果
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败，返回错误码
 */
int32_t pcs_factory_mode_set_control(uint16_t mode)
{
    int32_t ret;
    uint8_t data_buf[PCS_FACTORY_MODE_CMD_SIZE];
    uint16_t pcs_addr = 1;
    can_msg_t can_msg = {0};
   
    /* 入参的功率值合法性判断 */
    if ((mode != 0) && (mode != 1))
    {
        log_i((int8_t *)"\n [%s:%d] error, mode = %d \n", __func__, __LINE__, mode);
        return SF_ERR_PARA;
    }

    can_msg.src_addr = 1;
    can_msg.src_type = DEV_CSU_MCU;
    can_msg.dst_addr = 1;   // 地址为bit0~bit4有效
    can_msg.dst_type = DEV_PCS;
    can_msg.prio = PRIO_DATA;
    can_msg.fun_code = PCS_FUN_CODE_WRITE_PARAM; // 功能码
    can_msg.type = TYPE_DATA;   // 数据帧
    can_msg.addr = PCS_FACTORY_MODE_OFFSET;  // 点表起始位置

    

    /* 清空缓存 */
    memset(data_buf, 0, sizeof(data_buf));

    /* 命令类型数据填充 */
    data_buf[0] = mode & 0xFF;
    data_buf[1] = (mode >> 8) & 0xFF;

    /* 通过CAN下发开关机指令给PCS */
    ret = pcs_can_send(&can_msg, data_buf, PCS_POWERUP_GRADIDENT_CMD_SIZE);
    if(ret == SF_OK)
    {
    //    log_i("\n [%s:%d] pcs_dischg_power_limit_soc_control111, power_value = %d \n", __func__, __LINE__, power_value);
    }
    else   /* 通过CAN下发开关机指令给PCS失败处理 */
    {
        log_i((int8_t *)"\n [%s:%d] send pcs_factory_mode_set_control error, power_value = %d, ret = %d\n",__func__, __LINE__, mode, ret);
    }

    return SF_OK;
}