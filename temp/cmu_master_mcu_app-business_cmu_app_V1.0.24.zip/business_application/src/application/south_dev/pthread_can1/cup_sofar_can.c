#include "cup_sofar_can.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
//#include "data_types.h"
#include "sdk_can.h"
//#include "lal_can.h"
#include "pthread.h"
#define SOFAR_CAN_TRS_BUF_NUMS	  16		// 接收缓冲区个数
#define SOFAR_CAN_VER_LEN	      16	// 版本号 V1.0

//canbus通讯结果
#define SOFAR_CAN_RET_EMPTY       0       // 无发送数据
#define SOFAR_CAN_RET_WAIT        1       // 等待发送,任务调用发送时填入

static int8_t g_debug_flag = 0;

extern pthread_mutex_t gp_can1_mutex;




typedef struct{
    can_frame_id_u can_frame_id;      //通讯帧ID
    uint8_t comm_state;         //通讯状态
    uint8_t rev_data[CAN_SOFAR_SEND_MAXNUMS];   //接收数据缓冲区
    uint8_t rev_num;            //接收数据的帧数
    uint8_t rev_len;            //接收数据的长度
    uint16_t addr;              //地址
}can_rev_comm_t;

static can_rev_comm_t g_can_rev_comm[SOFAR_CAN_TRS_BUF_NUMS] = {0};

const uint8_t CRC16_high[] = {

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,

       0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,

       0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40

};

const uint8_t CRC16_low[] = {

       0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06, 0x07, 0xC7,

       0x05, 0xC5, 0xC4, 0x04, 0xCC, 0x0C, 0x0D, 0xCD, 0x0F, 0xCF, 0xCE, 0x0E,

       0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09, 0x08, 0xC8, 0xD8, 0x18, 0x19, 0xD9,

       0x1B, 0xDB, 0xDA, 0x1A, 0x1E, 0xDE, 0xDF, 0x1F, 0xDD, 0x1D, 0x1C, 0xDC,

       0x14, 0xD4, 0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3,

       0x11, 0xD1, 0xD0, 0x10, 0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3, 0xF2, 0x32,

       0x36, 0xF6, 0xF7, 0x37, 0xF5, 0x35, 0x34, 0xF4, 0x3C, 0xFC, 0xFD, 0x3D,

       0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A, 0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38,

       0x28, 0xE8, 0xE9, 0x29, 0xEB, 0x2B, 0x2A, 0xEA, 0xEE, 0x2E, 0x2F, 0xEF,

       0x2D, 0xED, 0xEC, 0x2C, 0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26,

       0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 0xA0, 0x60, 0x61, 0xA1,

       0x63, 0xA3, 0xA2, 0x62, 0x66, 0xA6, 0xA7, 0x67, 0xA5, 0x65, 0x64, 0xA4,

       0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F, 0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB,

       0x69, 0xA9, 0xA8, 0x68, 0x78, 0xB8, 0xB9, 0x79, 0xBB, 0x7B, 0x7A, 0xBA,

       0xBE, 0x7E, 0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 0xB4, 0x74, 0x75, 0xB5,

       0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71, 0x70, 0xB0,

       0x50, 0x90, 0x91, 0x51, 0x93, 0x53, 0x52, 0x92, 0x96, 0x56, 0x57, 0x97,

       0x55, 0x95, 0x94, 0x54, 0x9C, 0x5C, 0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E,

       0x5A, 0x9A, 0x9B, 0x5B, 0x99, 0x59, 0x58, 0x98, 0x88, 0x48, 0x49, 0x89,

       0x4B, 0x8B, 0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,

       0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42, 0x43, 0x83,

       0x41, 0x81, 0x80, 0x40
};

/**
 * @brief   打印数据
 * @param   [in] p_data  需要打印的数据
 * @param   [in] len  需要打印的数据长度
 * @note    
 * @return  返回执行结果 空
 */
 #if 1
static void data_print(uint8_t *p_data, int32_t len)
{
    if (g_debug_flag == 1)
    {
        CAN_DEBUG_PRINT_DATA("data start \n");
        for (uint8_t i = 0; i < len; i++)
        {
            CAN_DEBUG_PRINT_DATA(" %x ", p_data[i]);
        }
		CAN_DEBUG_PRINT_DATA("\n");
        CAN_DEBUG_PRINT_DATA("data end \n");
    }
}
#endif


/**
 * @brief   crc16的计算值
 * @param   [in] p_data  需要发送的数据
 * @param   [in] len  需要发送的数据长度
 * @note    
 * @return  返回执行结果 0:正常；<0:异常
 */
uint16_t crc16(uint8_t *p_data, int32_t len)
{
    uint8_t crc_high = 0xff;
    uint8_t crc_low = 0xff;
    int32_t num = 0;
    uint8_t index = 0;
    uint16_t crc16 = 0;

    for (num = 0; num < len; num++)
    {
        index = crc_high^p_data[num];
        crc_high = crc_low^CRC16_high[index];
        crc_low = CRC16_low[index];
    }

    crc16 = (crc_high<<8)|crc_low;

    return(crc16);
}

uint16_t crc16_calc(uint8_t * p_data, uint16_t data_len)
{
    uint8_t ch_crc_hi = 0xFF; // 高CRC字节初始化
    uint8_t ch_crc_lo = 0xFF; // 低CRC字节初始化
    uint16_t w_index; // CRC循环中的索引

    while (data_len--) {
    // 计算CRC
    w_index = ch_crc_lo ^ *p_data++ ;
    ch_crc_lo = ch_crc_hi ^ CRC16_high[w_index];
    ch_crc_hi = CRC16_low[w_index] ;
    }

    return ((ch_crc_hi << 8) | ch_crc_lo) ;
}


/**
 * @brief   计算一包数据可以分成几帧数据
 * @param   [in] pack_len 需要分包数据的长度
 * @param   [in] frame_len 一帧数据的长度
 * @note    
 * @return  返回执行结果 0:正常，可以分帧数量；<0:异常
 */
static uint8_t get_frame_num(uint16_t pack_len, uint16_t frame_len)
{
    uint8_t frame_num = 0;

    frame_num = pack_len / frame_len;
    if((pack_len % frame_len) != 0)
    {
        frame_num++;
    }

    return(frame_num);
}

/**
 * @brief   发送CAN数据 长帧
 * @param   [in] index  CAN 口编号
 * @param   [in] can_msg  CAN ID信息
 * @param   [in] txframe  CAN 通讯信息
 * @param   [in] p_data  需要发送的数据
 * @param   [in] len  需要发送的数据长度
 * @note    调用此函数之前需要APP层自己调用打开CAN的SDK接口
 * @return  返回执行结果 0:正常；<0:异常
 */
static int32_t long_data_send(uint32_t index, can_msg_t *can_msg, sdk_can_frame_t *txframe, uint8_t *p_data, int32_t len)
{
    int32_t rc = 0;
    uint8_t offset = 0;
    uint8_t first_sent;  //第一包已经发出去的数据字节数
    uint8_t frame_num = 0;
    uint16_t crc_check = 0;
    uint16_t num = 0;
    uint8_t *buff = NULL;
    buff = (uint8_t*)malloc(len*sizeof(uint8_t) + 2);
    memset(buff,0,len+2);
    memcpy(buff,p_data,len);
    if ((can_msg == NULL) || (p_data == NULL) || (len < 0) || (txframe == NULL))
    {
        free(buff);
        return(CAN_RET_GINSENG);
    }
    
    //CRC计算
    //crc_check = crc16(p_data, len);
    crc_check = crc16_calc(p_data, len);
    //p_data[len] = crc_check & 0xff;//Q:此处直接给p_data赋值，是否会存在溢出风险
    //p_data[len + 1] = (crc_check >> 8) & 0xff;
    buff[len] = crc_check & 0xff;
    buff[len+1] = (crc_check >> 8) & 0xff;
    //CAN_DEBUG_PRINT("crc_check=0x%02x,0x%02x!",buff[2*len],buff[2*len+1]);
    
    //if ((can_msg->fun_code == FUN_FILE_DATA_READ) || (can_msg->fun_code == FUN_UPDATE_DATA_TRS) 
        //|| (can_msg->fun_code == FUN_FILE_DATA_WRITE))      // 文件数据帧
    if(can_msg->fun_code == PCS_UPDATE_DATA)
    {
        offset = 4;
        first_sent = 3;
        txframe->data[0] = 0;
        txframe->data[1] = (can_msg->addr)&0xff;
        txframe->data[2] = ((can_msg->addr)>>8)&0xff;
        txframe->data[3] = len&0xff;
        txframe->data[4] = (len>>8)&0xff;
        memcpy(&(txframe->data[5]), p_data, 3);        
    }
    else    //点表数据帧
    {
        #if 0
        for(int i = 0,j = 0; i < len; i++)
        {
            
            buff[j] = p_data[i];
            buff[j+1] = 0;
            j=j+2;
        }
        #endif
        offset = 3;
        first_sent = 4;
        txframe->data[0] = 0;
        txframe->data[1] = (can_msg->addr)&0xff;
        txframe->data[2] = ((can_msg->addr)>>8)&0xff;
        txframe->data[3] = len>>1;
        //txframe->data[3] = len;
        //memcpy(&(txframe->data[4]), p_data, 4); //Q:文档中点表数据帧，每个数据占用两个字节，此处直接拷贝？     
        memcpy(&(txframe->data[4]), buff, 4);            
    }

    data_print(txframe->data, 8);   //打印数据
	// pthread_mutex_lock(&gp_can1_mutex);
    sdk_can_write(index, txframe, 1);    // 加锁
	// pthread_mutex_unlock(&gp_can1_mutex);
    // 计算有几帧数据,总的数据长度减去随着第一帧发出去的first_sent个数据加上末尾的两个crc16
    frame_num = get_frame_num((len - first_sent + 2), 7);

    //后续帧数据
    for (num = 1; num <= frame_num; num++)
    {
        if (num == frame_num) //最后一帧
        {
            txframe->data[0] = 0xff;
        }
        else
        {
            txframe->data[0] = num;
        }
        //memcpy(&(txframe->data[1]), &(p_data[(7 - offset) + 7 * (num - 1)]), 7);
        //memcpy(&(txframe->data[1]), &(buff[(7 - offset) + 7 * (num - 1)]), 7);
        //m = (7 - offset) + 7 * (num - 1);
        //memcpy(&(txframe->data[1]), buff + m, 7);
        memcpy(&(txframe->data[1]), &(buff[(7 - offset) + 7 * (num - 1)]), 7);
        data_print(txframe->data, 8);   //打印数据
		// pthread_mutex_lock(&gp_can1_mutex);
        sdk_can_write(index, txframe,1);    // 加锁
        // pthread_mutex_unlock(&gp_can1_mutex);
	//	usleep(4000);  //每隔4MS发一帧
        usleep(500);  //每隔4MS发一帧
    }
    free(buff);
    return(rc);
}

/**
 * @brief   接收数据缓存区获取
 * @param   [in] txframe  CAN 通讯信息
 * @return  返回执行结果 0:正常；<0:异常
 */
static int8_t buff_index_get(sdk_can_frame_t *txframe)
{
    int8_t rc = 0;
    uint8_t index = 0;
    uint8_t num = 0;

    if (txframe == NULL)
    {
        return(-1);
    }   

    for (num = 0; num < SOFAR_CAN_TRS_BUF_NUMS; num++)
    {
        if (g_can_rev_comm[num].comm_state != SOFAR_CAN_RET_EMPTY)
        {
            if ((g_can_rev_comm[num].can_frame_id.id_val & 0x1fffffff) == (txframe->id & 0x1fffffff))
            {
                index = num;
                break;
            }
        }
    } 

    if (index >= SOFAR_CAN_TRS_BUF_NUMS)
    {
        rc = -1;
    }   
    else
    {
        rc = index;
    }

    return(rc);
}


/**
 * @brief   接收数据组包
 * @param   [in] can_msg  CAN ID信息
 * @param   [in] txframe  CAN 通讯信息
 * @param   [in] p_data  需要发送的数据
 * @param   [in] len  需要发送的数据长度
 * @note    调用此函数之前需要APP层自己调用打开CAN的SDK接口
 * @return  返回执行结果 0:正常；<0:异常
 */
static int32_t long_data_pack(can_msg_t *can_msg, sdk_can_frame_t *txframe, uint8_t *p_data, int32_t *len)
{
    int32_t rc = 0;
    uint8_t offset = 0;
    // uint8_t frame_num = 0;
    uint16_t crc_check = 0;
    uint16_t read_check = 0;
    uint16_t num = 0;
    uint8_t index = 0;

    //if ((can_msg == NULL) || (p_data == NULL) || (len < 0) || (can_msg == NULL))//Q:明显错误
    if ((can_msg == NULL) || (p_data == NULL) || (len == NULL) || (txframe == NULL))
    {
        return(CAN_RET_GINSENG);
    }
    
    // 判断长帧的帧类型
    if ((can_msg->fun_code == FUN_FILE_DATA_READ) || (can_msg->fun_code == FUN_UPDATE_DATA_TRS) 
        || (can_msg->fun_code == FUN_FILE_DATA_WRITE))      // 文件数据帧
    {
        offset = 4;       
    }
    else    //点表数据帧
    {
        offset = 3;               
    }

    if (txframe->data[0] == 0)  // 检测是否是第一帧数据
    {
        // 将第一帧数据放在空缓冲区
        for (num = 0; num < SOFAR_CAN_TRS_BUF_NUMS; num++)
        {
        	/*如果同一ID情况下，又出现第一帧，直接替换。防止出现最后一帧丢失情况下，占用了缓冲区,永远不释放*/
        	if (g_can_rev_comm[num].comm_state != SOFAR_CAN_RET_EMPTY)
	        {
	            if ((g_can_rev_comm[num].can_frame_id.id_val & 0x1fffffff) == (txframe->id & 0x1fffffff))
	            {
	                index = num;
	                memset(&(g_can_rev_comm[index]), 0, sizeof(can_rev_comm_t));
					break;
	            }
	        }
			else
            {
                index = num;
                break;
            }
        }
		#if 0//走不到这里面来
        if (index >= SOFAR_CAN_TRS_BUF_NUMS)
        {
            index = 0;
            memset(&(g_can_rev_comm[index]), 0, sizeof(can_rev_comm_t));
        }
		#endif
        // 装载第一帧数据
        g_can_rev_comm[index].can_frame_id.id_val = txframe->id; // 记录CAN ID信息
        // memcpy(&(g_can_rev_comm[index].can_frame_id.id_val), &(txframe->id), 4);
        g_can_rev_comm[index].addr = txframe->data[1] | (txframe->data[2] << 8); // 记录偏移地址

        if (offset == 4)  // 文件数据
        {
            g_can_rev_comm[index].rev_len = txframe->data[3] | (txframe->data[4] << 8); // 记录数据长度
            memcpy(&(g_can_rev_comm[index].rev_data[0]), &(txframe->data[5]), 3);     // 记录数据
        }
        else    // 点表数据
        {
            //g_can_rev_comm[index].rev_len = txframe->data[2] << 1; // 记录数据长度
            g_can_rev_comm[index].rev_len = txframe->data[3] << 1; // 记录数据长度
            memcpy(&(g_can_rev_comm[index].rev_data[0]), &(txframe->data[4]), 4);     // 记录数据
        }

        g_can_rev_comm[index].comm_state = SOFAR_CAN_RET_WAIT;
        (g_can_rev_comm[index].rev_num)++;//Q:此处是不是要记录一下
        CAN_DEBUG_PRINT("\n [%s:%d] first frame:len=%d!\n",__func__, __LINE__,g_can_rev_comm[index].rev_len);
    }
    else if (txframe->data[0] == 0xff)  // 检测是否是最后一帧数据
    {
        rc = buff_index_get(txframe); // 获取缓存区存储位置

        if (rc < 0)
        {
            return(CAN_RET_RECERR);
        }
        else
        {
            index = rc;
        }

        num = (g_can_rev_comm[index].rev_num)++;
        memcpy(&(g_can_rev_comm[index].rev_data[(7 - offset) + 7 * (num - 1)]),  &(txframe->data[1]), 7);
		#if 0
        CAN_DEBUG_PRINT("g_can_rev_comm test_data:\n");
        for(int i = 0;i < g_can_rev_comm[index].rev_len+2;i++)
        {
            CAN_DEBUG_PRINT("%02x ",g_can_rev_comm[index].rev_data[i]);
        }
        CAN_DEBUG_PRINT("\n");
		#endif
        //memset(g_can_rev_comm,0,sizeof(g_can_rev_comm));
        //CRC计算
        //crc_check = crc16(&(g_can_rev_comm[index].rev_data[0]), g_can_rev_comm[index].rev_len);//crc16_calc
		crc_check = crc16_calc(&(g_can_rev_comm[index].rev_data[0]), g_can_rev_comm[index].rev_len);//crc16_calc
        read_check = g_can_rev_comm[index].rev_data[g_can_rev_comm[index].rev_len] | (g_can_rev_comm[index].rev_data[g_can_rev_comm[index].rev_len + 1] << 8);
        //read_check = (g_can_rev_comm[index].rev_data[g_can_rev_comm[index].rev_len] << 8) | (g_can_rev_comm[index].rev_data[g_can_rev_comm[index].rev_len + 1]);
        //CAN_DEBUG_PRINT("read_check_1=%02x,read_check_2=%02x",g_can_rev_comm[index].rev_data[g_can_rev_comm[index].rev_len],g_can_rev_comm[index].rev_data[g_can_rev_comm[index].rev_len + 1]);
        
        if (crc_check == read_check)
        {
        	
            can_msg->addr = g_can_rev_comm[index].addr;
            *len = g_can_rev_comm[index].rev_len;
            memcpy(p_data, &(g_can_rev_comm[index].rev_data[0]), *len);
            rc = CAN_RET_TURE;
			
        }
        else
        {
        	CAN_DEBUG_PRINT("\n [%s:%d] crc_check:%x,read_check=%x\n",__func__, __LINE__,crc_check,read_check);
            rc = CAN_RET_CRC_ERR;
        }
        g_can_rev_comm[index].comm_state = SOFAR_CAN_RET_EMPTY;//Q:此处原本用了num做索引，不对
        memset(&(g_can_rev_comm[index]), 0, sizeof(can_rev_comm_t));//Q:从逻辑上说，数组的当前索引变量的状态已经被置empty了，这个变量是不是要清空。而且不清空，当遇到相同ID但是值不同的情况时，数据可能会被修改
		#if 0
		CAN_DEBUG_PRINT("\n [%s:%d] last frame:len=%d\n",__func__, __LINE__,*len);
        for(int i = 0;i < *len;i++)
        {
            CAN_DEBUG_PRINT_DATA("%x ",p_data[i]);
        }
        CAN_DEBUG_PRINT_DATA("\n");
		#endif
        //memset(g_can_rev_comm,0,sizeof(g_can_rev_comm));
    }
    else    // 中间帧数据
    {
        rc = buff_index_get(txframe); // 获取缓存区存储位置

        if (rc < 0)
        {
            rc = CAN_RET_RECERR;
        }
        else
        {
            index = rc;
            num = (g_can_rev_comm[index].rev_num)++;
            memcpy(&(g_can_rev_comm[index].rev_data[(7- offset) + 7 * (num - 1)]),  &(txframe->data[1]), 7);

            rc = CAN_RET_TURE;
        }      
    }
  
    return(rc);
}

/**
 * @brief   发送CAN数据接收
 * @param   [in] index  CAN 口编号
 * @param   [in] timeout_ms  读取超时时间设置
 * @param   [out] can_id_msg  接收数据的CAN ID信息
 * @param   [out] p_data  接收的数据
 * @param   [out] len  接收数据的长度
 * @note    调用此函数之前需要APP层自己调用打开CAN的SDK接口，收到完整数据包之后将数据返回
 * 			返回的数据根据不同的功能码有以下不同的情况（只有数据包时的数据帧p_data才仅是真正的数据）
 * 			p_data:数据帧时对应的是解析组包之后的数据；请求和应答帧时是应答和请求的帧数据内容
 * @return  返回执行结果 0:正常；<0:异常
 */
int32_t cup_sofar_can_rev(uint32_t index, int32_t timeout_ms, can_msg_t *can_msg, uint8_t *p_data, int32_t *len)
{
    can_frame_id_u can_frame_id;
	sdk_can_frame_t txframe;
    int32_t rc = 0;

    if ((can_msg == NULL) || (p_data == NULL) || (len == NULL))
    {
        return(CAN_RET_GINSENG);
    }
	//pthread_mutex_lock(&gp_can1_mutex);
	
    rc = sdk_can_read(index, &txframe, 1, timeout_ms); //加锁
	//pthread_mutex_unlock(&gp_can1_mutex);
    if (rc > 0)     // 接收到CAN的数据
    {
    	//CAN_DEBUG_PRINT("cup_sofar_can_rev: recv data\n");
        //data_print(txframe.data, 8);   //打印数据

        can_frame_id.id_val = txframe.id; 

        can_msg->src_addr = can_frame_id.bit.src_addr;
        can_msg->src_type = can_frame_id.bit.src_type;
        can_msg->dst_addr = can_frame_id.bit.dst_addr;
        can_msg->dst_type = can_frame_id.bit.dst_type;
        can_msg->fun_code = can_frame_id.bit.fun_code;
        can_msg->flag = can_frame_id.bit.flag;//Q:不添加这个连续标志的话，当帧结构为长帧时，没法立马返回数据，该如何进行处理
        can_msg->type = can_frame_id.bit.type;
        can_msg->prio = can_frame_id.bit.prio; 

		CAN_DEBUG_PRINT("CAN_RECV: id[%x],index[%x],fun_code[%d],recv data from src_type[%d],src_addr[%d],dst_type[%d],dst_addr[%d],flag[%d],type[%d],prio[%d]!\n",
			(can_frame_id.id_val & 0x1fffffff),txframe.data[0],can_msg->fun_code,can_msg->src_type,can_msg->src_addr,can_msg->dst_type,can_msg->dst_addr,can_msg->flag,can_msg->type,can_msg->prio);
        //data_print(txframe.data, 8);   //打印数据
        #if 1
        for (uint8_t i = 0; i < 8; i++)
        {
            CAN_DEBUG_PRINT_DATA("%x ", txframe.data[i]);
        }
		CAN_DEBUG_PRINT_DATA("\n");
		#endif

        if (can_msg->type == 1)     // 数据帧内容
        {
            if (can_frame_id.bit.flag == 1)    //长帧数据
            {
                rc = long_data_pack(can_msg, &txframe, p_data, len);
            }
            else    //短帧数据
            {
                if ((can_msg->fun_code == FUN_FILE_DATA_READ) || (can_msg->fun_code == FUN_UPDATE_DATA_TRS) 
                    || (can_msg->fun_code == FUN_FILE_DATA_WRITE))      // 文件数据帧
                {
                    can_msg->addr = txframe.data[0] | (txframe.data[1] << 8);
                    *len = txframe.data[2] | (txframe.data[3] << 8);
                    memcpy(p_data, &(txframe.data[4]), 4);
                }
			    else if(can_msg->fun_code == PCS_FUN_HEARTBEAT_INFO)//心跳帧特殊处理
			    {
			    	memcpy(p_data, &(txframe.data[0]), 8); 
					can_msg->addr = 0;
					*len = 8;
			    }
                else    //点表数据帧
                {
                    can_msg->addr = txframe.data[0] | (txframe.data[1] << 8);
                    *len = txframe.data[2]<<1;
                    memcpy(p_data, &(txframe.data[3]), 5);                
                }
                rc = CAN_RET_TURE;
            }
        }
        else    // 非数据帧内容
        {
            memcpy(p_data, &(txframe.data[0]), 8);
			*len = 8;
            rc = CAN_RET_TURE;
        }
    }
    else        //没有读取到数据
    {
        rc = CAN_RET_TIMEOUT;
    }

    return(rc);    
}


/**
 * @brief   发送CAN数据打包发送
 * @param   [in] index  CAN 口编号
 * @param   [in] can_msg  CAN ID信息
 * @param   [in] p_data  需要发送的数据
 * @param   [in] len  需要发送的数据长度
 * @note    调用此函数之前需要APP层自己调用打开CAN的SDK接口,
 * @return  返回执行结果 0:正常；<0:异常
 */
int32_t cup_sofar_can_send(uint32_t index, can_msg_t *can_msg, uint8_t *p_data, int32_t len)
{
	can_frame_id_u can_frame_id;
	sdk_can_frame_t txframe = {0};
     
    if ((can_msg == NULL) || (p_data == NULL) || (len < 0))
    {
        return (CAN_RET_GINSENG);
    }

    if (len > CAN_SOFAR_DATA_MAXNUMS)
    {
        return (CAN_RET_GINSENG);
    }

    // printf("cup_sofar_can_send(in)\n");
    // pthread_mutex_lock(&gp_can1_mutex);
    can_frame_id.bit.src_addr = can_msg->src_addr;
    can_frame_id.bit.src_type = can_msg->src_type;
    can_frame_id.bit.dst_addr = can_msg->dst_addr;
    can_frame_id.bit.dst_type = can_msg->dst_type;
    can_frame_id.bit.fun_code = can_msg->fun_code;
    can_frame_id.bit.type = can_msg->type;
    can_frame_id.bit.prio = can_msg->prio;   
    can_frame_id.bit.format = 1;    //拓展帧
    // txframe.ide = 1;    //拓展帧
    txframe.len = 8;
    if (can_msg->type == 1)     // 数据帧内容
    {
        if (len >= 5)    //长帧数据
        {
            //CAN_DEBUG_PRINT("long_data_send");
            can_frame_id.bit.flag = 1;      //  连续性帧
            //txframe.can_id = (can_frame_id.id_val & 0x1fffffff); 
            txframe.id = (can_frame_id.id_val & 0x9fffffff);
            long_data_send(index, can_msg, &txframe, p_data, len);
        }
        else    //短帧帧数据
        {
            can_frame_id.bit.flag = 0;      //  非连续性帧
            //txframe.can_id = (can_frame_id.id_val & 0x1fffffff);//Q:此处为何又把拓展帧的bit清0了？
            txframe.id = (can_frame_id.id_val & 0x9fffffff);
            if ((can_msg->fun_code == FUN_FILE_DATA_READ) || (can_msg->fun_code == FUN_UPDATE_DATA_TRS) 
                || (can_msg->fun_code == FUN_FILE_DATA_WRITE))      // 文件数据帧
            {
                txframe.data[0] = (can_msg->addr)&0xff;
                txframe.data[1] = ((can_msg->addr)>>8)&0xff;
                txframe.data[2] = len&0xff;
                txframe.data[3] = (len>>8)&0xff;
                memcpy(&(txframe.data[4]), p_data, len);

            }
            else    //点表数据帧
            {
                txframe.data[0] = (can_msg->addr)&0xff;
                txframe.data[1] = ((can_msg->addr)>>8)&0xff;
                txframe.data[2] = len>>1;
                //memcpy(&(txframe.data[3]), p_data, 5);//Q:此处拷贝，当p_data的空间不足时，拷贝会溢出。例如：如果p_data是一个长度为4的数组，拷贝将导致发送帧最后的数据可能错误（拷贝了p_data外的未知数据）
                memcpy(&(txframe.data[3]), p_data, len);         
            }
            //CAN_DEBUG_PRINT("txframe.can_id=0x%x.",txframe.can_id);
            txframe.len = 8;
            //txframe.data[0] = 'Y';
            data_print(txframe.data, 8);   //打印数据
            // pthread_mutex_lock(&gp_can1_mutex);
            sdk_can_write(index, &txframe, 1);    //加锁
            // pthread_mutex_unlock(&gp_can1_mutex);
        }
    }
    else    // 非数据帧内容
    {
        can_frame_id.bit.flag = 0;      //  非连续性帧
        //txframe.can_id = (can_frame_id.id_val & 0x1fffffff);
        txframe.id = (can_frame_id.id_val & 0x9fffffff); 
        memcpy(&(txframe.data[0]), p_data, len);
		data_print(txframe.data, 8);   //打印数据
		// pthread_mutex_lock(&gp_can1_mutex);
        sdk_can_write(index, &txframe,1);    // 加锁
        // pthread_mutex_unlock(&gp_can1_mutex);
    }

    // pthread_mutex_unlock(&gp_can1_mutex);
    // printf("cup_sofar_can_send(out)\n");
    return (0);
}

/**
 * @brief   CAN 通讯协议初始化（接收状态初始化）
 * @note    在创建CAN通讯任务，初始化时需要调用此函数，防止接收数据时的状态、缓冲区未初始化
 * @return  返回执行结果 0:正常；<0:异常
 */
int32_t cup_sofar_can_init(void)
{
    uint8_t index = 0;

    for (index = 0; index < SOFAR_CAN_TRS_BUF_NUMS; index++)
    {
        memset(&(g_can_rev_comm[index]), 0, sizeof(can_rev_comm_t));
    }

    return (0);
}

/** 
 * @brief        打印信息设置函数
 * @param        [in] flag 打印信息设置函数，0不打印，1打印
 * @return       [int32_t] 执行结果
 * @retval       =0  设置成功 
 * @retval       < 0 失败原因
 */
int32_t cup_sofar_can_debug_set(int8_t flag)
{
    g_debug_flag = flag;

    return (0);
}

