/** 
 * @file          can_safety.c
 * @brief         通过CAN下发安规的接口函数功能实现
 * @author        liangguyao
 * @version       V0.0.1     初始版本
 * @date          2023/09/07
 * @copyright     Copyright (c) 2023 by SofarSolar, All Rights Reserved.
 */


#include "param_record_task.h"
#include "can_safety.h"
#include "can_update.h"
#include "sofar_errors.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk_fs.h"
#include "sofar_log.h"
#include <string.h>
#include "safety_lib_task.h"
#include "sdk_public.h"
#include "param_record_task.h"

//安规文件存取每帧大小
#define SAFETY_FRAME_SIZE               128 // 安规文件读写写入帧的长度

#define SAFETY_PARAM_GROUP_NUM          9   // 安规文件读写写入帧的长度
#define SAFETY_PARAM_GROUP_OFFSET       256 // 安规参数组在点表的偏移地址

#define WRITE_SAFETY_PARAM_FUN_CODE     33  // 写安规参数的功能码

#define WRITE_SAFETY_COUNTRY_CMD_SIZE       (4)   // 写安规国家和地区、版本号功能码
#define PCS_SAFETY_COUNTRY_CODE_OFFSET      (2304)   // 

uint16_t safety_country_region = 0;
uint16_t safety_ver = 0;

extern int32_t pcs_tele_data_query(uint8_t fun_code, uint8_t dev_id, uint16_t addr, uint8_t len);

/**
 * @brief  	计算安规参数的和校验
 * @param  	[in] void
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
static uint16_t safe_para_checksum(uint8_t len, uint8_t *send_data)
{
	uint16_t check_sum = 0;
	uint16_t i;

	// NULL pointer protection
	if(send_data != NULL)
	{
		for(i = 0; i < len; i++)
		{
			check_sum += send_data[i];
		}
	}
	else
	{
	}

	return check_sum;
}

/** 
 * @brief   设置安规版本、国家、区域
 * @param   无
 * @return 	[int32_t] 执行结果
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败，返回错误码
 */
int32_t can_safety_country_set(void)
{
    int32_t ret;
    uint8_t data_buf[WRITE_SAFETY_COUNTRY_CMD_SIZE];
    // internal_shared_data_t *p_internal_data = internal_shared_data_get(); 
    common_data_t *p_common_data = sdk_shm_get();

    can_msg_t can_msg = {0};

    can_msg.src_addr = 1;
    can_msg.src_type = DEV_CSU_MCU;
    can_msg.dst_addr = 1;
    can_msg.dst_type = DEV_PCS;
    can_msg.prio = PRIO_DATA;
    can_msg.fun_code = WRITE_SAFETY_PARAM_FUN_CODE; // 功能码
    can_msg.type = TYPE_DATA;   // 数据帧
    can_msg.addr = PCS_SAFETY_COUNTRY_CODE_OFFSET;   // 点表起始位置

    /* 清空缓存 */
    memset(data_buf, 0, sizeof(data_buf));
    // 安规国家和区域
    //  data_buf[0] = (p_internal_data->safety_country_region >> 8) & 0xFF;
    //  data_buf[1] = p_internal_data->safety_country_region & 0xFF;
    //  // 安规版本
    //  data_buf[2] = p_internal_data->safety_ver & 0xFF;
    //  data_buf[3] = (p_internal_data->safety_ver >> 8) & 0xFF;
     data_buf[0] = (p_common_data->constant_parameter_data.safety_rdr_country >> 8) & 0xFF;
     data_buf[1] = p_common_data->constant_parameter_data.safety_rdr_country & 0xFF;
     // 安规版本
     data_buf[2] = p_common_data->constant_parameter_data.ver_safety_rdr_para & 0xFF;
     data_buf[3] = (p_common_data->constant_parameter_data.ver_safety_rdr_para >> 8) & 0xFF;


    /* 通过CAN下发开关机指令给PCS */
 //   ret = pcs_can_send(&can_msg, data_buf, WRITE_SAFETY_COUNTRY_CMD_SIZE);
    ret = cup_sofar_can_send(CAN_PORT_PCS, &can_msg, data_buf, SAFETY_FRAME_SIZE);
    if(ret == SF_OK)
    {
        log_i((int8_t*)"\n [%s:%d] can_safety_country_set, success  \n", __func__, __LINE__);
    }
    else   /* 通过CAN下发开关机指令给PCS失败处理 */
    {
        log_i((int8_t *)"\n [%s:%d] can_safety_country_set, error\n",__func__, __LINE__);
    }

    return SF_OK;
}

/**
 * @brief  	通过CAN下发安规数据给PCS
 * @param  	[in] void
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t can_safety_send(void)
{
    int32_t ret = -1;
    uint32_t start_add;
    uint8_t data_buf[SAFETY_FRAME_SIZE];
    uint8_t i, j;
    uint8_t temp;
    uint16_t k;
    can_msg_t can_msg = {0};
    uint16_t calc_checksum = 0;
    uint16_t* p_checksum = NULL;
    common_data_t *psc_common_data = sdk_shm_get();

    if(NULL == psc_common_data)
    {
       ret = -1;
       return ret; 
    }

    /* 检测安规文件是否存在 */
    ret = sdk_fs_access((const int8_t *)(PATH_SAFETY_FILE), FS_F_OK);
    if (ret != SF_OK)
    {
        CAN_SAFETY_DEBUG((int8_t *)"\n [%s:%d] Safety file does not exist, ret = %d\n", __func__, __LINE__, ret);
        return ret;
    }

    can_msg.src_addr = 1;
    can_msg.src_type = DEV_CSU_MCU;
    can_msg.dst_addr = 1;
    can_msg.dst_type = DEV_PCS;
    can_msg.prio = PRIO_DATA;
    can_msg.fun_code = WRITE_SAFETY_PARAM_FUN_CODE; // 功能码
    can_msg.type = TYPE_DATA;   // 数据帧
    p_checksum = &(psc_common_data->telemetry_data.power_module_telemetry_info[0].startup_para_checksum);

    for (i = 0; i < SAFETY_PARAM_GROUP_NUM; i++)
    {
        /* 清空缓存 */
        memset(data_buf, 0, sizeof(data_buf));

        /* 计算对应参数组在安规文件里的起始读取位置 */
        start_add = i * SAFETY_FRAME_SIZE;

        /* 读取安规文件里对应参数组的数据 */
        extern int32_t get_file_data(const void *file_name, uint32_t start_add, uint32_t data_length, uint8_t *file_data);
        ret = get_file_data((const void *)PATH_SAFETY_FILE, start_add, SAFETY_FRAME_SIZE, data_buf);
        if (ret != SF_OK)
        {
            CAN_SAFETY_DEBUG((int8_t *)"\n [%s:%d] read safety file data error, i = %d, ret = %d\n", __func__, __LINE__, i, ret);
            return ret;
        }

        /* 计算对应参数组在点表里的偏移地址 */
        can_msg.addr = i * SAFETY_PARAM_GROUP_OFFSET;   // 点表起始位置

        /* 反转大小端序，即反转data_buf里的数据 */
        for (k = 0; k < SAFETY_FRAME_SIZE; k += 2)
        {
            temp = data_buf[k];
            data_buf[k] = data_buf[k + 1];
            data_buf[k + 1] = temp;
        }

        /* 通过CAN下发安规的对应参数组数据给PCS 失败重发3次*/
        for (j = 0; j < 5; j++)
        {
            calc_checksum = safe_para_checksum(SAFETY_FRAME_SIZE,data_buf);
            ret = cup_sofar_can_send(CAN_PORT_PCS, &can_msg, data_buf, SAFETY_FRAME_SIZE);
            if(ret == SF_OK)
            {
                sdk_delay_ms(1);
                CAN_SAFETY_DEBUG("\n [%s:%d] pack[%d] send success\n", __func__, __LINE__, i);
                ret = pcs_tele_data_query(PCS_FUN_CODE_YC_INFO, 0, 30000, 9);
                if(ret == SF_OK)
                {
                    sdk_delay_ms(5);
                    if(calc_checksum == *p_checksum)
                    {
                        log_i((const int8_t*)"\nsend safety param group%d success\n",i);
                        break;
                    }
                    else
                    {
                        log_i((const int8_t*)"\nparam group%d checksum error\n",i);
                    }
                }
                else
                {
                    log_i((const int8_t*)"\nget safety  group%d checksum faile\n",i);    
                }
                
            }
            else
            {
                log_i((const int8_t*)"\nsend safety param group%d faile\n",i);
            }
            
        }
        p_checksum++;
        /* 通过CAN下发安规的对应参数组数据给PCS失败处理 */
        if (ret != SF_OK)
        {
            CAN_SAFETY_DEBUG((int8_t *)"\n [%s:%d] send safety data error, i = %d, ret = %d\n", __func__, __LINE__, i, ret);
            return ret;
        }
    }
    can_safety_country_set();
    return SF_OK;
}

/**
 * @brief  	响应web导入的安规参数，执行转发
 * @param  	[in] void
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t can_process_import_safety(void)
{
    int32_t ret = SF_OK;
    internal_shared_data_t *p_internal_data = NULL;
    telematic_data_t *p_telematic_data = NULL;
    constant_parameter_data_t *p_constant_parameter = NULL;

    p_constant_parameter = sdk_shm_constant_parameter_data_get();
    p_telematic_data = sdk_shm_telematic_data_get();
    p_internal_data = internal_shared_data_get();

	if(NULL == p_internal_data || p_telematic_data == NULL || p_constant_parameter == NULL)
	{
        log_i((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
		return SF_ERR_PARA;
	}

    if ((p_internal_data->safety_update_flag >> 0) & 0x1)   	//更新安规国家和版本号
    {
        log_i((int8_t *)"can_process_import_safety!\n");
        p_internal_data->import_result_flag = 0;
        p_internal_data->safety_update_flag &= ~(1 << 0);
        ret = can_safety_send();
        ret = safety_param_init();
        // 本地安规参数读取失败
        if(ret == SF_ERR_PARA)
        {
            p_telematic_data->container_system_warn_info[0] |= 1<<2;
            memset(&p_constant_parameter->safety_param,0,sizeof(p_constant_parameter->safety_param));
            // 安规文件不存在，开机超时时间默认10分钟
            p_constant_parameter->safety_param.group1[0] = 600;
            p_constant_parameter->safety_param.group1[2] = 600;
        }
        dev_param_save();
        dev_param_save();
        if (ret == SF_OK)
        {
            p_internal_data->import_result_flag = 2;
            log_i((int8_t *)"can_process_import_safety succeed!\n");
        }
        else
        {
            log_i((int8_t *)"can_process_import_safety fail!\n");
        }
    } else if (p_internal_data->safety_update_flag != 0 )
    {
        can_safety_sync();
    }

    return ret;
}


#include "safety_def.h" 
#include "mem_utils.h"
 
#if (1)
#define CAN_SAFETY_LOG_D(...)      do{ log_d((const int8_t*)__VA_ARGS__); }while(0)
#else
#define CAN_SAFETY_LOG_D(...)      do{}while(0)
#endif

#define CAN_SAFETY_LOG_E(...)      do{ log_e((const int8_t*)__VA_ARGS__); }while(0)

// void safety_test( void )
// {
//     volatile safety_par_u tmp_safety_par;
//     volatile safety_par_u safety_par;

//     fs_t *p_fs = sdk_fs_open( PATH_SAFETY_FILE, FS_READ );
//     if ( p_fs == NULL )
//     {
//         printf( "ope %s error!!!/r/n", PATH_SAFETY_FILE );
//         return;
//     }

//     memset( &tmp_safety_par, 0, sizeof( safety_par_u ));
//     int32_t rd_len = sdk_fs_read( p_fs, &tmp_safety_par, sizeof(safety_par_u) );
//     if ( rd_len != sizeof( safety_par_u ) )
//     {
//         printf( "read %s error!!!/r/n", PATH_SAFETY_FILE );
//         return;
//     }

//     mem_utils_u16_array_littleEndian_to_bigEndian( (uint16_t*)&tmp_safety_par, sizeof(safety_par_u)/2, (uint16_t*)&safety_par );

//     while (1)
//     {
//         printf( "safety_par.detail.iso_island_par.value_array[63]:%d\r\n", safety_par.detail.iso_island_par.value_array[63] );
//         safety_par.detail.iso_island_par.value_array[63] = 0;
//         sleep(1);
//     }
    
//     return;
// }

sf_ret_t can_safety_par_sync_to_file( void )
{
    constant_parameter_data_t *p_constant_parameter = sdk_shm_constant_parameter_data_get();
    uint16_t store_safety_dat[ sizeof( safety_par_u )/2 ] = {0};

    fs_t *p_safety_fs = sdk_fs_open( (const int8_t*)SAFETY_PATH, FS_WRITE | FS_OPEN_ALWAYS );
    if ( p_safety_fs == NULL )
    {
        CAN_SAFETY_LOG_E("[%s] open %s error!!!", __FUNCTION__, SAFETY_PATH );
        return SF_ERR_OPEN;
    }

    mem_utils_u16_array_littleEndian_to_bigEndian( (uint16_t*)&p_constant_parameter->safety_param, sizeof( safety_par_t )/2, store_safety_dat );
    
    int32_t wr_len = sdk_fs_write( p_safety_fs, store_safety_dat, sizeof( store_safety_dat ) );
    if ( wr_len != sizeof( store_safety_dat ) )
    {
        CAN_SAFETY_LOG_E("[%s] write %s error!!!", __FUNCTION__, SAFETY_PATH );
        sdk_fs_close( p_safety_fs );
        return SF_ERR_WR;
    }
    sdk_fs_close( p_safety_fs );

    return SF_OK;
}

/**
 * @brief  	通过CAN下发安规数据给PCS
 * @param  	[in] void
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t can_safety_send_group_par_data( safety_group_par_e gp_par_type )
{
    uint8_t safety_gp_par_can_dat[ SAFETY_GROUP_PAR_CNT * sizeof(uint16_t) ];
    uint16_t* p_checksum_list = NULL;
    can_msg_t can_msg = {0};

    can_msg.src_addr = 1;
    can_msg.src_type = DEV_CSU_MCU;
    can_msg.dst_addr = 1;
    can_msg.dst_type = DEV_PCS;
    can_msg.prio = PRIO_DATA;
    can_msg.fun_code = WRITE_SAFETY_PARAM_FUN_CODE; // 功能码
    can_msg.type = TYPE_DATA;                       // 数据帧
    can_msg.addr = gp_par_type * 256;

    p_checksum_list = &(sdk_shm_get()->telemetry_data.power_module_telemetry_info[0].startup_para_checksum);
    memcpy( safety_gp_par_can_dat, sdk_shm_constant_parameter_data_get()->safety_param.group_list[ gp_par_type ], sizeof( safety_gp_par_can_dat ) );
    uint16_t cal_checksum = mem_utils_cal_checksum( safety_gp_par_can_dat, sizeof( safety_gp_par_can_dat ) );
    
    for (size_t rety = 0; rety < 3; rety++)
    {
        /* 发送数据 */
        int32_t ret = cup_sofar_can_send( CAN_PORT_PCS, &can_msg,  safety_gp_par_can_dat, sizeof( safety_gp_par_can_dat ));
        if ( ret < 0 )
        {
            CAN_SAFETY_LOG_E( "[%s] send can cmd data error!!!", __FUNCTION__ );
            /* 失败 */
            continue;
        }

        sdk_delay_ms(1);
        /* 查询校验和 */
        ret = pcs_tele_data_query(PCS_FUN_CODE_YC_INFO, 0, 30000, 9);
        if ( ret < 0 )
        {
            CAN_SAFETY_LOG_E( "[%s] query checksum data error!!!", __FUNCTION__ );
            continue;
        }
        
        sdk_delay_ms(5);
        /* 对比校验和 */
        if ( p_checksum_list[ gp_par_type ] != cal_checksum )
        {
            CAN_SAFETY_LOG_E( "[%s] checksum != cal checksum!!!", __FUNCTION__ );
            continue;
        }

        return SF_OK;
    }
    
    CAN_SAFETY_LOG_E( "[%s] write group dat error!!!", __FUNCTION__ );
    return SF_ERR_WR;
}

sf_ret_t can_safety_sync( void )
{
    bool file_sync = SF_FALSE;
    sf_ret_t ret = SF_OK;

    printf( "[%s] safety_update_flag: 0x%04X\r\n", __FUNCTION__, internal_shared_data_get()->safety_update_flag );

    for (size_t i = 0; i < SAFETY_GP_NUM; i++)
    {
        if ( BIT_GET( internal_shared_data_get()->safety_update_flag, i + 1 ))
        {
            BIT_CLR( internal_shared_data_get()->safety_update_flag, i + 1 );
            if ( 0 > can_safety_send_group_par_data( (safety_group_par_e)i ))
            {
                ret = SF_ERR_WR;
            }
            file_sync = SF_TRUE;
        }
    }
    
    if ( file_sync == SF_TRUE )
    {
        if ( SF_OK != can_safety_par_sync_to_file())
        {
            ret = SF_ERR_WR;
        }
    }

    return ret;
}