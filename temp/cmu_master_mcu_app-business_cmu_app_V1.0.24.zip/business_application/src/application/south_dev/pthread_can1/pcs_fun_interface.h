/** 
 * @file          pcs_fun_interface.h
 * @brief         PCS模块通信功能外部接口函数说明
 * @author        liangguyao
 * @version       V0.0.1     初始版本
 * @date          2023/09/14
 * @copyright     Copyright (c) 2023 by SofarSolar, All Rights Reserved.
 */


#ifndef __PCS_FUN_INTERFACE_H__
#define __PCS_FUN_INTERFACE_H__

#include "data_types.h"
#include "sdk_public.h"


#if (0)
#define PCS_FUN_DEBUG(...) log_i((const int8_t*)__VA_ARGS__);
#else
#define PCS_FUN_DEBUG(...) {do {} while(0);}
#endif


#define PCS_POWER_LIMIT_MIN             (0)		


// Type of PCS power control command
typedef enum{
    PCS_POWER_OFF                   = 0,    // 关机
    PCS_POWER_ON                    = 1,    // 开机
    PCS_POWER_EPO                   = 2,    // 紧急关机
}pcs_power_control_cmd_type_e;

// Type of PCS charge discharge forbid control command
// bit0：禁止充电
// bit1：禁止放电
// 0 = FALSE
// 1 = TRUE
typedef enum{
    PCS_CHG_DISCHG_FORBID_OFF       = 0,    // “禁止充电”、“禁止放电”都关闭
    PCS_CHG_FORBID_ON               = 1,    // 仅打开“禁止充电”
    PCS_DISCHG_FORBID_ON            = 2,    // 仅打开“禁止放电”
    PCS_CHG_DISCHG_FORBID_ON        = 3,    // “禁止充电”、“禁止放电”都打开
}pcs_chg_dischg_forbid_control_cmd_type_e;

typedef enum{
    PCS_LOWPOWER_DISABLE                   = 0,    // 禁止
    PCS_LOWPOWER_ENABLE                    = 1,    // 使能
}pcs_lowpower_control_cmd_type_e;

/** 
 * @brief   控制PCS开关机指令
 * @param   [in] command_type   命令类型 0：关机 1：开机 2：紧急关机，其他：无效 pcs_control_command_type_e
 * @return 	[int32_t] 执行结果
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败，返回错误码
 */
int32_t pcs_power_control(pcs_power_control_cmd_type_e command_type);

/** 
 * @brief   控制PCS禁止充电、禁止放电指令
 * @param   [in] command_type   命令类型
 *          PCS_CHG_DISCHG_FORBID_OFF   ：“禁止充电”、“禁止放电”都关闭
 *          PCS_CHG_FORBID_ON           ：仅打开“禁止充电”
 *          PCS_DISCHG_FORBID_ON        ：仅打开“禁止放电”
 *          PCS_CHG_DISCHG_FORBID_ON    ：“禁止充电”、“禁止放电”都打开
 *          其他：无效 pcs_chg_dischg_forbid_control_cmd_type_e
 * @return 	[int32_t] 执行结果
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败，返回错误码
 */
int32_t pcs_chg_dischg_forbid_control(pcs_chg_dischg_forbid_control_cmd_type_e command_type);

/** 
 * @brief   根据温度与SOC限制PCS充放电功率指令
 * @param   [in] power_value    限制的功率值（单位0.01KW，实际功率值放大100倍，取值范围：-30000 ~ 30000之间，即-300KW ~ 300KW，放电为正，充电为负）
 * @return 	[int32_t] 执行结果
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败，返回错误码
 */
int32_t pcs_power_limit_soc_control(int16_t power_value);

/** 
 * @brief   PCS模块时间设置
 * @param   [in] p_time rtc时间结构体,详见sdk_rtc_t定义
 * @return 	[int32_t] 执行结果
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败，返回错误码
 */
int32_t pcs_time_set(sdk_rtc_t *p_time);

/** 
 * @brief   PCS低功耗模式设置   使能低功耗模式后i待机5分钟会封波
 * @param   [in] command_type   命令类型 0：禁止 1：使能 其他：无效 
 * @return 	[int32_t] 执行结果
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败，返回错误码
 */
int32_t pcs_lowpower_control(pcs_lowpower_control_cmd_type_e command_type);

/** 
 * @brief   PCS软复位指令
 * @param   [in] cmd 1:软件复位
 * @return 	[int32_t] 执行结果
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败，返回错误码
 */
int32_t pcs_reset_control(int16_t command);


int32_t pcs_dischgpower_limit_soc_control(int16_t power_value);
int32_t pcs_chgpower_limit_soc_control(int16_t power_value);
int32_t pcs_powerup_gradident_set_control(uint16_t gradident);
int32_t pcs_factory_mode_set_control(uint16_t mode);

#endif  /* __PCS_FUN_INTERFACE_H__ */