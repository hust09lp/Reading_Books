#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

#include <unistd.h>
#include <sys/time.h>
#include <string.h>
#include <sys/prctl.h>
#include "sdk_can.h"
#include "cup_sofar_can.h"
#include "can_update.h"
#include "sdk_shm.h"
#include "sdk_public.h"
#include "sdk_fs.h"
#include "sdk_log.h"

extern common_data_t *shm;
pthread_mutex_t gp_can1_mutex;
static pcs_data_point_info_t g_pcs_data_info[PCS_CABINET_POWER_MODULE_NUM];
extern query_status_t g_query_status;
pcs_comm_info_t  g_pcs_comm_info;
extern fault_record_info_t g_fault_record_info;

#define DBG_CANPRF		0

#define CAN_GROUP_ADDR_1  0
#define CAN_GROUP_ADDR_2  10000
#define CAN_GROUP_ADDR_3  20000
#define CAN_GROUP_ADDR_4  30000
#define CAN_ADDR_DEV_GROUP1_END  19
#define CAN_ADDR_DEV_GROUP2_END  10022
#define CAN_ADDR_YX_GROUP1_END  19
#define CAN_ADDR_YX_GROUP2_END  10000
#define CAN_ADDR_YC_GROUP1_END  34
#define CAN_ADDR_YC_GROUP2_END  10037
#define CAN_ADDR_YC_GROUP3_END  20012
#define CAN_ADDR_YC_GROUP4_END  30008
#define CAN_ADDR_PARAM_GROUP1_END  29
#define CAN_ADDR_PARAM_GROUP2_END  10031
#define CAN_ADDR_PARAM_GROUP3_END  20004
#define CAN_ADDR_MULTICAST_GROUP1_END  7
#define CAN_ADDR_MULTICAST_GROUP2_END  10002
#define CAN_ADDR_SAFETY_INFO  2304
#define CAN_ADDR_SAFETY_INFO_END  2306

#define PCS_FAULT_RECORD_INFO 12 	// PCS故障录波信息长度


void print_point_table_data(uint16_t *p_data, int32_t len)
{
    CAN_DEBUG_PRINT("point_table_data start\n");
    for (uint8_t i = 0; i < len; i++)
    {
        CAN_DEBUG_PRINT_DATA(" %x ", p_data[i]);
    }
    CAN_DEBUG_PRINT_DATA("\n point_table_data end \n");
}

void copy_pcs_yx_data_to_shared_memory(uint8_t index,uint16_t addr, int32_t len)
{
	common_data_t *psc_common_data = sdk_shm_get();

	if(NULL != psc_common_data)
	{
		memcpy((uint16_t*)(&psc_common_data->telematic_data.can_pcs_module[index].grid_fault.val) + addr,&g_pcs_data_info[index].pcs_yx_info[addr],len);
	}
	return;
}

void copy_pcs_yx_data_to_iec(uint8_t index)
{
	telematic_data_t * yx_data = sdk_shm_telematic_data_get();
	
	if(NULL != yx_data)
	{
		memcpy(&(yx_data->pcs_module[index]),&(yx_data->can_pcs_module[index]),22);
		yx_data->pcs_module[index].warn_info = yx_data->can_pcs_module[index].warn_info;
		yx_data->pcs_module[index].state6 = yx_data->can_pcs_module[index].state6;
		yx_data->pcs_module[index].fault12 = yx_data->can_pcs_module[index].fault12;
		yx_data->pcs_module[index].fault13 = yx_data->can_pcs_module[index].fault13;
	}
}

void copy_pcs_yc_data_to_iec(uint8_t index,uint16_t addr, int32_t len)
{
	static uint16_t energy_charge_h = 0;
    static uint16_t energy_charge_l = 0;
    static uint16_t energy_discharge_h = 0;
    static uint16_t energy_discharge_l = 0;

	common_data_t *psc_common_data = sdk_shm_get();
	energy_charge_h = psc_common_data->telemetry_data.power_module_telemetry_info[index].energy_charge_h;
    energy_charge_l = psc_common_data->telemetry_data.power_module_telemetry_info[index].energy_charge_l;
    energy_discharge_h = psc_common_data->telemetry_data.power_module_telemetry_info[index].energy_discharge_h;
    energy_discharge_l = psc_common_data->telemetry_data.power_module_telemetry_info[index].energy_discharge_l;


	if((addr + len/2) > sizeof(power_module_telemetry_info_t)/2)
	{
		CAN_DEBUG_PRINT("\n [%s:%d] too more data:addr[%d],len[%d]!\n",__func__, __LINE__,addr,len);
		return;
	}
	if(NULL != psc_common_data)
	{
		memcpy((uint16_t*)(&psc_common_data->telemetry_data.power_module_telemetry_info[index].grid_volt_rs) + addr,&g_pcs_data_info[index].pcs_yc_info[addr],len);
	}
	if(addr == (CAN_ADDR_YC_GROUP1_END - CAN_GROUP_ADDR_1 + 1))
	{
		if((psc_common_data->telemetry_data.power_module_telemetry_info[index].energy_charge_h == 0) && (psc_common_data->telemetry_data.power_module_telemetry_info[index].energy_charge_l == 0))
		{
			psc_common_data->telemetry_data.power_module_telemetry_info[index].energy_charge_h = energy_charge_h;
			psc_common_data->telemetry_data.power_module_telemetry_info[index].energy_charge_l = energy_charge_l;
		}
		if((psc_common_data->telemetry_data.power_module_telemetry_info[index].energy_discharge_h == 0) && (psc_common_data->telemetry_data.power_module_telemetry_info[index].energy_discharge_l == 0))
		{
			psc_common_data->telemetry_data.power_module_telemetry_info[index].energy_discharge_h = energy_discharge_h;
			psc_common_data->telemetry_data.power_module_telemetry_info[index].energy_discharge_l = energy_discharge_l;
		}
	}
	return;
}

void copy_pcs_dev_info_to_iec(uint8_t index,uint16_t addr, int32_t len)
{
	common_data_t *psc_common_data = sdk_shm_get();
	if((addr + len/2) > sizeof(pcs_module_version_telemetry_info_t)/2)
	{
		CAN_DEBUG_PRINT("\n [%s:%d] too more data:addr[%d],len[%d]!\n",__func__, __LINE__,addr,len);
		return;
	}
	if(NULL != psc_common_data)
	{
		memcpy((uint16_t*)(&psc_common_data->telemetry_data.pcs_module_version_telemetry_info[index].sn[0]) + addr,&g_pcs_data_info[index].pcs_dev_info[addr],len);
	}
	return;
}


void copy_pcs_param_data_to_shared_memory(uint8_t index,uint16_t addr, int32_t len)
{
	common_data_t *psc_common_data = sdk_shm_get();

	
	if((addr + len/2) > sizeof(pcs_parameter_data_t)/2)
	{
		CAN_DEBUG_PRINT("\n [%s:%d] too more data:addr[%d],len[%d]!\n",__func__, __LINE__,addr,len);
		return;
	}
	if(NULL != psc_common_data)
	{
		memcpy((uint16_t*)(&psc_common_data->constant_parameter_data.pcs_parameter_data[index]) + addr,&g_pcs_data_info[index].pcs_read_param_info[addr],len);
	}
	return;
}

void copy_pcs_param_to_iec_param(uint8_t index)
{
	constant_parameter_data_t * param_data = sdk_shm_constant_parameter_data_get();
	
	if(NULL != param_data)
	{ 

		param_data->iec_pcs_parameter_data[index].active_power_ref = param_data->pcs_parameter_data[index].active_power_ref;
		param_data->iec_pcs_parameter_data[index].reactive_power_ref = param_data->pcs_parameter_data[index].reactive_power_ref;
		param_data->iec_pcs_parameter_data[index].pcs_operation_mode = param_data->pcs_parameter_data[index].pcs_operation_mode;
		param_data->iec_pcs_parameter_data[index].bus_volt_ref = param_data->pcs_parameter_data[index].bus_volt_ref;
		param_data->iec_pcs_parameter_data[index].openloop_volt_set = param_data->pcs_parameter_data[index].openloop_volt_set;
		param_data->iec_pcs_parameter_data[index].const_current_ref = param_data->pcs_parameter_data[index].const_current_ref;
		param_data->iec_pcs_parameter_data[index].power_ref_soft_start_gradident = param_data->pcs_parameter_data[index].power_ref_soft_start_gradident;	
		param_data->iec_pcs_parameter_data[index].factory_mode = param_data->pcs_parameter_data[index].factory_mode;	
	}
}

void copy_pcs_heartbeat_data_to_shared_memory(uint8_t index)
{
	common_data_t *psc_common_data = sdk_shm_get();
	
	if(NULL != psc_common_data)
	{
		psc_common_data->internal_shared_data.pcs_heartbeat_info.fsm_state[index] = g_pcs_data_info[index].pcs_heartbeat_info[3];
		psc_common_data->internal_shared_data.pcs_heartbeat_info.fault_state[index] = g_pcs_data_info[index].pcs_heartbeat_info[2];
		psc_common_data->internal_shared_data.pcs_heartbeat_info.pcs_dischg_limit_power[index] = g_pcs_data_info[index].pcs_heartbeat_info[4] | (g_pcs_data_info[index].pcs_heartbeat_info[5] << 8);
		psc_common_data->internal_shared_data.pcs_heartbeat_info.pcs_chg_limit_power[index] = g_pcs_data_info[index].pcs_heartbeat_info[6] | (g_pcs_data_info[index].pcs_heartbeat_info[7] << 8);
	}
	return;
}

/** 
 * @brief   同步PCS的故障到整个系统,方便通知系统故障
 * @param   [in] index   PCS的序号,第几个PCS
 * @return 	void
 */
static void sync_pcs_fault_to_system(const uint8_t index)
{
	time_t now;
	uint16_t *p_data;
	uint8_t i,j;
	telematic_data_t * yx_data = sdk_shm_telematic_data_get();

	/*定位到故障字段起始位置*/
	p_data = (uint16_t *)(&(yx_data->pcs_module[index].grid_fault.val)); 
	time(&now);  //获取当前的时间戳
	for(i = 0; i < 11; i++)  //前面11个故障fault 1~11
	{
		for(j = 0; j < 16; j++) 
		{
			if(i != 10 && j != 4)
			{
				if((((*(p_data + i) >> j) & 0x01) == 1) &&
					(((g_pcs_fault_last[i] >> j) & 0x01) == 1))   //该位被置位了，对应PCS有故障
				{
					if((now - g_fault_time[i*16+j]) >= (3*60))  //故障超过了三分钟了
					{
						yx_data->container_system_fault_info[16] |= 0x01; //认为储能柜有故障
						g_fault_time[i*16+j] = now;
						return;                //任意一个故障就要置位第16个bit，然后直接返回
					}
				}
				else if((((*(p_data + i) >> j) & 0x01) == 0) &&
					(((g_pcs_fault_last[i] >> j) & 0x01) == 1)) //故障消失了
				{
					yx_data->container_system_fault_info[16] &= 0xFE; 
				}
				else
				{
					g_fault_time[i*16+j] = now;
				}
			}
		}
		g_pcs_fault_last[i] = *(p_data + i);
	}
	
	for(i = 0; i < 2;i++)  //后面2个故障fault 12~13
	{
		p_data = (uint16_t *)(&(yx_data->pcs_module[index].fault12.val)); //故障位置
		for(j = 0; j < 16; j++) 
		{
			if((((*(p_data + i) >> j) & 0x01) == 1) &&
				(((g_pcs_fault_last[i+11] >> j) & 0x01) == 1))   //该位被置位了，对应PCS有故障
			{
				printf("fault [%d],", i+12);
				if((now - g_fault_time[(i+11)*16+j]) > (3*60))  //故障超过了三分钟了
				{
					yx_data->container_system_fault_info[16] |= 0x01; //认为储能柜有故障
					g_fault_time[i*16+j] = now;
					return;
				}
			}
			else if((((*(p_data + i) >> j) & 0x01) == 0) &&
				(((g_pcs_fault_last[i+11] >> j) & 0x01) == 1)) //故障消失了
			{
				yx_data->container_system_fault_info[16] &= 0xFE; 
			}
			else
			{
				g_fault_time[(i+11)*16+j] = now;
			}
		}
		g_fault_time[(i+11)*16+j] = now;
		g_pcs_fault_last[i+11] = *(p_data + i);
	}

}


/**
 * @brief   解析收到的请求帧
 * @param   [in] rframe  接收数据的CAN ID信息
 * @param   [in] p_data  接收的数据
 * @param   [in] len  接收数据的长度
 * @note
 * @return
 */

void req_frame_analysis(can_msg_t *rframe,uint8_t* p_data,int32_t len)
{

}

/****************************************************************************
* 功  能: 存储故障录波数据
* 描  述:
* 输  入: length：写入长度;        offset：写入位置在文件中的偏移地址；
* 输  出: p_buff：写入的录波数据;   p_fp  ：文件句柄
* 返  回：-1失败，0成功
****************************************************************************/

int8_t fault_recorder_write(uint16_t length, uint32_t offset, void* p_buff, uint8_t id)
{
	CAN_DEBUG_PRINT("\n [%s:%d] fault_recorder_write file_id[%d],offset[%d]\n",__func__, __LINE__,id,offset);
	if(p_buff == NULL)
	{
		CAN_DEBUG_PRINT(1, ("\n fault recorder write point NULL \n"));
		return (-1);
	}

	int32_t rc = 0;
	uint32_t file_offset = 0;
	//FILE * fp = NULL;
	int8_t file_name[64] = {0};

	// 检测升级文件夹路径是否存在
	rc = sdk_fs_access((const int8_t *)PATH_FAULT_RECORD, FS_S_IRWXO);
	if (rc < 0)
	{
		CAN_DEBUG_PRINT("\n =====pcsfault record dir is not existing====== \n");
		if(sdk_fs_mkdir(PATH_FAULT_RECORD, 755) < 0)
		{
			CAN_DEBUG_PRINT("\n =====pcs fault record dir creat fail======= \n");
			return (2);
		}
		CAN_DEBUG_PRINT("\n ==========pcd fault record dir creat success====== \n");
	}

	snprintf((char*)file_name, 64,"%sfault_recorder%d.fw",PATH_FAULT_RECORD,id-200);

	if(g_fault_record_info.fault_fp == NULL)
	{
		if((g_fault_record_info.fault_fp = fopen((const char*)file_name,"w+")) == NULL)
		{
			CAN_DEBUG_PRINT(1, ("\n open fault recorder file fail w+ \n"));
			return (-1);
		}
	}

	if(offset != 0)
	{
		file_offset = PCS_FAULT_RECORD_INFO + 192*(offset - 1);//16
	}
	else
	{
		file_offset = 0;
	}
	fseek(g_fault_record_info.fault_fp, file_offset, SEEK_SET); // 一般用于二进制文件，在文本文件中由于要进行转换，计算的位置有时会出错

	if(fwrite(p_buff, length, 1, g_fault_record_info.fault_fp) != 1)
	{
		CAN_DEBUG_PRINT(1, ("\n write fault recorder file fail \n"));
		fclose(g_fault_record_info.fault_fp);
		return (-1);
	}

	if(offset == 50)
	{
		fclose(g_fault_record_info.fault_fp);
		g_fault_record_info.fault_fp = NULL;
	}


	return (0);
}


void fault_record_data_handle(can_msg_t *rframe,uint8_t* p_data,int32_t len)
{
	if((NULL == rframe) || (NULL == p_data))
	{
		return;
	}

	fault_recorder_write(len, rframe->addr, p_data,g_fault_record_info.file_id);
}

/**
 * @brief   解析收到的数据帧
 * @param   [in] rframe  接收数据的CAN ID信息
 * @param   [in] p_data  接收的数据
 * @param   [in] len  接收数据的长度
 * @note   
 * @return  
 */
void data_frame_analysis(can_msg_t *rframe,uint8_t* p_data,int32_t len)
{
	
	if((NULL == rframe) || (NULL == p_data))
	{
		return;
	}
	
	common_data_t *psc_common_data = sdk_shm_get();
	
	if(NULL == psc_common_data)
	{
		return;
	}
	
	int32_t i = 0;
	int32_t j = 0;
	uint16_t addr = rframe->addr;
	uint16_t start_addr = 0;
	uint8_t index = rframe->src_addr-1;
	uint16_t offset = 0;
	uint32_t order_num = 0;
	
	switch(rframe->fun_code)
	{
		case PCS_FUN_CODE_DEV_INFO:
			if((CAN_GROUP_ADDR_1 <= addr) && (addr <= CAN_ADDR_DEV_GROUP1_END))
			{
				start_addr = addr;
				order_num = CAN_ADDR_DEV_GROUP1_END - CAN_GROUP_ADDR_1 + 1;
				for (i = start_addr,j = 0;j < len;j = j + 2,i++)
				{
					if((i < order_num) && (i < CAN_DATA_NUM))
					{
						
						g_pcs_data_info[index].pcs_dev_info[i] = p_data[j] | (p_data[j+1] << 8); 
					}
				}
			}
			else if((CAN_GROUP_ADDR_2 <= addr) && (addr <= CAN_ADDR_DEV_GROUP2_END))
			{
				offset = addr - CAN_GROUP_ADDR_2;
				start_addr = CAN_ADDR_DEV_GROUP1_END - CAN_GROUP_ADDR_1 + 1 + offset;
				order_num = CAN_ADDR_DEV_GROUP1_END - CAN_GROUP_ADDR_1 + 1 + CAN_ADDR_DEV_GROUP2_END - CAN_GROUP_ADDR_2 + 1;
				for (i = start_addr,j = 0;j < len;j = j + 2,i++)
				{
					
					if((i < order_num) && (i < CAN_DATA_NUM))
					{
						
						g_pcs_data_info[index].pcs_dev_info[i] = p_data[j] | (p_data[j+1] << 8); 
						
					}
				}
			}
			CAN_DEBUG_PRINT("pcs_dev_info from PCS[%d]:\n",index);
			print_point_table_data( g_pcs_data_info[index].pcs_dev_info,CAN_DATA_NUM);          
			copy_pcs_dev_info_to_iec(index,start_addr,len);
			break;
		case PCS_FUN_CODE_YX_INFO:
			if((CAN_GROUP_ADDR_1 <= addr) &&(addr <= CAN_ADDR_YX_GROUP1_END))
			{
				for (i = addr,j = 0;j < len;j = j + 2,i++)
				{
					if(i < 20)   //遥信目前有20个数据,0~19
					{
						g_pcs_data_info[index].pcs_yx_info[i] = p_data[j] | (p_data[j+1] << 8);
					}
				}
				// 屏蔽PCS上报的EPO故障
			//	g_pcs_data_info[index].pcs_yx_info[10] &= ~(1<<4);
				CAN_DEBUG_PRINT("pcs_yx_info from PCS[%d]:\n",index);
				print_point_table_data( g_pcs_data_info[index].pcs_yx_info,CAN_DATA_NUM);           
				copy_pcs_yx_data_to_shared_memory(index,addr,len);
				copy_pcs_yx_data_to_iec(index);
				/*同步PCS故障到整个系统，在PCS出现连续故障五分钟之后,PCS和系统都能够停机*/
				sync_pcs_fault_to_system(index); 
			}
			else if(CAN_GROUP_ADDR_2 == addr)
			{
				psc_common_data->internal_shared_data.pcs_fault_restore_flag = p_data[0] | (p_data[1] << 8);
			}
			
			break;
		case PCS_FUN_CODE_YC_INFO:
			if((CAN_GROUP_ADDR_1 <= addr) && (addr <= CAN_ADDR_YC_GROUP1_END))
			{
				start_addr = addr;
				order_num = CAN_ADDR_YC_GROUP1_END - CAN_GROUP_ADDR_1 + 1;
				for (i = start_addr,j = 0;j < len;j = j + 2,i++)
				{
					if((i < order_num) && (i < CAN_DATA_NUM*2))
					{
						
						g_pcs_data_info[index].pcs_yc_info[i] = p_data[j] | (p_data[j+1] << 8);
					}
				}
			}
			else if((CAN_GROUP_ADDR_2 <= addr) && (addr <= CAN_ADDR_YC_GROUP2_END))
			{
				offset = addr - CAN_GROUP_ADDR_2;
				start_addr = CAN_ADDR_YC_GROUP1_END - CAN_GROUP_ADDR_1 + 1 + offset;
				order_num = CAN_ADDR_YC_GROUP1_END - CAN_GROUP_ADDR_1 + 1 + CAN_ADDR_YC_GROUP2_END - CAN_GROUP_ADDR_2 + 1;
				for (i = start_addr,j = 0;j < len;j = j + 2,i++)
				{
					
					if((i < order_num) && (i < CAN_DATA_NUM*2))
					{
						
						g_pcs_data_info[index].pcs_yc_info[i] = p_data[j] | (p_data[j+1] << 8);
						//memcpy(((uint16_t*)&psc_common_data->telemetry_data.pcs_module_version_telemetry_info[index] + i),&g_pcs_data_info[index].pcs_dev_info[i],2);
					}
				}
			}
			else if((CAN_GROUP_ADDR_3 <= addr) && (addr <= CAN_ADDR_YC_GROUP3_END))
			{
				offset = addr - CAN_GROUP_ADDR_3;
				start_addr = CAN_ADDR_YC_GROUP1_END - CAN_GROUP_ADDR_1 + CAN_ADDR_YC_GROUP2_END - CAN_GROUP_ADDR_2 + 2 + offset;
				order_num = CAN_ADDR_YC_GROUP1_END - CAN_GROUP_ADDR_1 + 1 + CAN_ADDR_YC_GROUP2_END - CAN_GROUP_ADDR_2 + 1 + CAN_ADDR_YC_GROUP3_END - CAN_GROUP_ADDR_3 + 1;
				for (i = start_addr,j = 0;j < len;j = j + 2,i++)
				{
					
					if((i < order_num) && (i < CAN_DATA_NUM*2))
					{
						
						g_pcs_data_info[index].pcs_yc_info[i] = p_data[j] | (p_data[j+1] << 8);
					}
				}
			}
			else if((CAN_GROUP_ADDR_4 <= addr) && (addr <= CAN_ADDR_YC_GROUP4_END))
			{
				offset = addr - CAN_GROUP_ADDR_4;
				start_addr = CAN_ADDR_YC_GROUP1_END - CAN_GROUP_ADDR_1 + CAN_ADDR_YC_GROUP2_END - CAN_GROUP_ADDR_2 + CAN_ADDR_YC_GROUP3_END - CAN_GROUP_ADDR_3 + 3 + offset;
				order_num = CAN_ADDR_YC_GROUP1_END - CAN_GROUP_ADDR_1 + CAN_ADDR_YC_GROUP2_END - CAN_GROUP_ADDR_2 + CAN_ADDR_YC_GROUP3_END - CAN_GROUP_ADDR_3 + CAN_ADDR_YC_GROUP4_END - CAN_GROUP_ADDR_4 + 4;
				for (i = start_addr,j = 0;j < len;j = j + 2,i++)
				{
					
					if((i < order_num) && (i < CAN_DATA_NUM*2))
					{
						
						g_pcs_data_info[index].pcs_yc_info[i] = p_data[j] | (p_data[j+1] << 8);
					}
				}
			}

			
			CAN_DEBUG_PRINT("pcs_yc_info from PCS[%d]:\n",index);
			print_point_table_data( g_pcs_data_info[index].pcs_yc_info,CAN_DATA_NUM*2);             
			copy_pcs_yc_data_to_iec(index,start_addr,len);
			break;
		case PCS_FUN_CODE_READ_PARAM:
			if((CAN_GROUP_ADDR_1 <= addr) && (addr <= CAN_ADDR_PARAM_GROUP1_END))
			{
				start_addr = addr;
				order_num = CAN_ADDR_PARAM_GROUP1_END - CAN_GROUP_ADDR_1 + 1;
				for (i = start_addr,j = 0;j < len;j = j + 2,i++)
				{
					if((i < order_num) && (i < CAN_DATA_NUM))
					{
						
						g_pcs_data_info[index].pcs_read_param_info[i] = p_data[j] | (p_data[j+1] << 8);
					}
				}
			}
			else if((CAN_GROUP_ADDR_2 <= addr) && (addr <= CAN_ADDR_PARAM_GROUP2_END))
			{
				offset = addr - CAN_GROUP_ADDR_2;
				start_addr = CAN_ADDR_PARAM_GROUP1_END - CAN_GROUP_ADDR_1 + 1 + offset;
				order_num = CAN_ADDR_PARAM_GROUP1_END - CAN_GROUP_ADDR_1 + 1 + CAN_ADDR_PARAM_GROUP2_END - CAN_GROUP_ADDR_2 + 1;
				for (i = start_addr,j = 0;j < len;j = j + 2,i++)
				{
					
					if((i < order_num) && (i < CAN_DATA_NUM))
					{
						
						g_pcs_data_info[index].pcs_read_param_info[i] = p_data[j] | (p_data[j+1] << 8);
					}
				}
			}
			else if((CAN_GROUP_ADDR_3 <= addr) && (addr <= CAN_ADDR_PARAM_GROUP3_END))
			{
				offset = addr - CAN_GROUP_ADDR_3;
				start_addr = CAN_ADDR_PARAM_GROUP1_END - CAN_GROUP_ADDR_1 + 1 + CAN_ADDR_PARAM_GROUP2_END - CAN_GROUP_ADDR_2 + 1 + offset;
				order_num = CAN_ADDR_PARAM_GROUP1_END - CAN_GROUP_ADDR_1 + 1 + CAN_ADDR_PARAM_GROUP2_END - CAN_GROUP_ADDR_2 + 1 + CAN_ADDR_PARAM_GROUP3_END - CAN_GROUP_ADDR_3 + 1;
				for (i = start_addr,j = 0;j < len;j = j + 2,i++)
				{
					
					if((i < order_num) && (i < CAN_DATA_NUM))
					{
						
						g_pcs_data_info[index].pcs_read_param_info[i] = p_data[j] | (p_data[j+1] << 8);
					}
				}
			}
			
			CAN_DEBUG_PRINT("pcs_read_param_info from PCS[%d]:\n",index);
			print_point_table_data( g_pcs_data_info[index].pcs_read_param_info,CAN_DATA_NUM);  
			copy_pcs_param_data_to_shared_memory(index,start_addr,len);
			copy_pcs_param_to_iec_param(index);
			break;
		case PCS_FUN_CODE_WRITE_PARAM:
			if((CAN_GROUP_ADDR_1 <= addr) && (addr <= CAN_ADDR_PARAM_GROUP1_END))
			{
				start_addr = addr;
				order_num = CAN_ADDR_PARAM_GROUP1_END - CAN_GROUP_ADDR_1 + 1;
				for (i = start_addr,j = 0;j < len;j = j + 2,i++)
				{
					if((i < order_num) && (i < CAN_DATA_NUM))
					{
						
						g_pcs_data_info[index].pcs_write_param_info[i] = p_data[j] | (p_data[j+1] << 8);
						//memcpy(((uint16_t*)&psc_common_data->telemetry_data.pcs_module_version_telemetry_info[index] + i),&g_pcs_data_info[index].pcs_dev_info[i],2);
					}
				}
			}
			else if((CAN_GROUP_ADDR_2 <= addr) && (addr <= CAN_ADDR_PARAM_GROUP2_END))
			{
				offset = addr - CAN_GROUP_ADDR_2;
				start_addr = CAN_ADDR_PARAM_GROUP1_END - CAN_GROUP_ADDR_1 + 1 + offset;
				order_num = CAN_ADDR_PARAM_GROUP1_END - CAN_GROUP_ADDR_1 + 1 + CAN_ADDR_PARAM_GROUP2_END - CAN_GROUP_ADDR_2 + 1;
				for (i = start_addr,j = 0;j < len;j = j + 2,i++)
				{
					
					if((i < order_num) && (i < CAN_DATA_NUM))
					{
						
						g_pcs_data_info[index].pcs_write_param_info[i] = p_data[j] | (p_data[j+1] << 8);
						//memcpy(((uint16_t*)&psc_common_data->telemetry_data.pcs_module_version_telemetry_info[index] + i),&g_pcs_data_info[index].pcs_dev_info[i],2);
					}
				}
			}
			else if((CAN_GROUP_ADDR_3 <= addr) && (addr <= CAN_ADDR_PARAM_GROUP3_END))
			{
				offset = addr - CAN_GROUP_ADDR_3;
				start_addr = CAN_ADDR_PARAM_GROUP1_END - CAN_GROUP_ADDR_1 + 1 + CAN_ADDR_PARAM_GROUP2_END - CAN_GROUP_ADDR_2 + 1 + offset;
				order_num = CAN_ADDR_PARAM_GROUP1_END - CAN_GROUP_ADDR_1 + 1 + CAN_ADDR_PARAM_GROUP2_END - CAN_GROUP_ADDR_2 + 1 + CAN_ADDR_PARAM_GROUP3_END - CAN_GROUP_ADDR_3 + 1;
				for (i = start_addr,j = 0;j < len;j = j + 2,i++)
				{
					
					if((i < order_num) && (i < CAN_DATA_NUM))
					{
						
						g_pcs_data_info[index].pcs_write_param_info[i] = p_data[j] | (p_data[j+1] << 8);
						//memcpy(((uint16_t*)&psc_common_data->telemetry_data.pcs_module_version_telemetry_info[index] + i),&g_pcs_data_info[index].pcs_dev_info[i],2);
					}
				}
			}
			
			CAN_DEBUG_PRINT("pcs_write_param_info from PCS[%d]:\n",index);
			print_point_table_data( g_pcs_data_info[index].pcs_write_param_info,CAN_DATA_NUM);   
			//copy_pcs_param_data_to_shared_memory(index,addr,len/2);
			break;
		case PCS_FUN_CODE_WRITE_MULTICAST:
			if((CAN_GROUP_ADDR_1 <= addr) && (addr <= CAN_ADDR_MULTICAST_GROUP1_END))
			{
				start_addr = addr;
				order_num = CAN_ADDR_MULTICAST_GROUP1_END - CAN_GROUP_ADDR_1 + 1;
				for (i = start_addr,j = 0;j < len;j = j + 2,i++)
				{
					if((i < order_num) && (i < CAN_DATA_NUM))
					{
						
						g_pcs_data_info[index].pcs_write_multicast_info[i] = p_data[j] | (p_data[j+1] << 8);
						//memcpy(((uint16_t*)&psc_common_data->telemetry_data.pcs_module_version_telemetry_info[index] + i),&g_pcs_data_info[index].pcs_dev_info[i],2);
					}
				}
			}
			else if((CAN_GROUP_ADDR_2 <= addr) && (addr <= CAN_ADDR_MULTICAST_GROUP2_END))
			{
				offset = addr - CAN_GROUP_ADDR_2;
				start_addr = CAN_ADDR_MULTICAST_GROUP1_END - CAN_GROUP_ADDR_1 + 1 + offset;
				order_num = CAN_ADDR_MULTICAST_GROUP1_END - CAN_GROUP_ADDR_1 + 1 + CAN_ADDR_MULTICAST_GROUP2_END - CAN_GROUP_ADDR_2 + 1;
				for (i = start_addr,j = 0;j < len;j = j + 2,i++)
				{
					
					if((i < order_num) && (i < CAN_DATA_NUM))
					{
						
						g_pcs_data_info[index].pcs_write_multicast_info[i] = p_data[j] | (p_data[j+1] << 8);
						//memcpy(((uint16_t*)&psc_common_data->telemetry_data.pcs_module_version_telemetry_info[index] + i),&g_pcs_data_info[index].pcs_dev_info[i],2);
					}
				}
			}
			
			CAN_DEBUG_PRINT("pcs_write_multicast_info from PCS[%d]:\n",index);
			print_point_table_data( g_pcs_data_info[index].pcs_write_multicast_info,CAN_DATA_NUM);      
			//copy_pcs_param_data_to_shared_memory(index,addr,len/2);
			break;
		case PCS_FUN_CODE_READ_SAFETY_PARAM:
			if((CAN_ADDR_SAFETY_INFO <= addr) && (addr <= CAN_ADDR_SAFETY_INFO_END))
			{
				start_addr = addr - CAN_ADDR_SAFETY_INFO;
				order_num = CAN_ADDR_SAFETY_INFO_END - CAN_ADDR_SAFETY_INFO + 1;
				for (i = start_addr,j = 0;j < len;j = j + 2,i++)
				{
					if((i < order_num) && (i < CAN_DATA_NUM))
					{
						
						g_pcs_data_info[index].pcs_read_param_info[i] = p_data[j] | (p_data[j+1] << 8);
					}
				}
				psc_common_data->internal_shared_data.pcs_safety_country_region = (g_pcs_data_info[index].pcs_read_param_info[0]>>8) | (g_pcs_data_info[index].pcs_read_param_info[0]<<8);
				psc_common_data->internal_shared_data.pcs_safety_ver = g_pcs_data_info[index].pcs_read_param_info[1];
			}
			break;
		case PCS_FUN_HEARTBEAT_INFO:
			for (i = addr,j = 0;j < len;i++,j++)
			{
				if(i < 8)
				{
					
					//g_pcs_data_info[index].pcs_heartbeat_info[i] = p_data[j] | (p_data[j+1] << 8);
					g_pcs_data_info[index].pcs_heartbeat_info[i] = p_data[j];
				}
			}
			CAN_DEBUG_PRINT("pcs_heartbeat_info from PCS[%d]:\n",index);
			// printf("Receive: pcs_heartbeat_info from PCS[%d] \n", index);
            extern void data_print(uint8_t *p_data, int32_t len);
			data_print( g_pcs_data_info[index].pcs_heartbeat_info,8);   
			copy_pcs_heartbeat_data_to_shared_memory(index);
			break;
		case FUN_FILE_DATA_READ:
			if(g_fault_record_info.status == CAN_UPDATE_STATUS_WAIT_ACK)
			{
				CAN_DEBUG_PRINT("\n [%s:%d] FUN_FILE_DATA_READ\n",__func__, __LINE__);
				fault_record_data_handle(rframe,p_data,len);
				g_fault_record_info.status = CAN_UPDATE_STATUS_REC_ACK;
			}

			break;
		default:
			return;
	}
	
	if((PCS_FUN_HEARTBEAT_INFO != rframe->fun_code) && (1 == g_pcs_comm_info.pcs_wait_flag[index]))
	{
		g_pcs_comm_info.pcs_wait_flag[index] = 2;
	}
	return;
}

void pcs_data_info_analysis_test(can_msg_t *rframe,uint8_t* p_data,int32_t len)
{
	if((NULL == rframe) || (NULL == p_data))
	{
		return;
	}
	
	if((rframe->src_addr > PCS_CABINET_POWER_MODULE_NUM) || (0 == rframe->src_addr))
	{
		CAN_DEBUG_PRINT("\n [%s:%d] rframe->src_addr [%d] error!\n",__func__, __LINE__,rframe->src_addr);
		return;
	}
	
	g_pcs_comm_info.pcs_connect_flag[rframe->src_addr-1] = 1;
	g_pcs_comm_info.pcs_heartbeat_err_cnt[rframe->src_addr-1] = 0;
    g_pcs_comm_info.pcs_comm_break[rframe->src_addr-1] = 0;
	
	if (rframe->type == TYPE_DATA)
	{
		data_frame_analysis(rframe,p_data,len);
	}
	if (rframe->type == TYPE_ACK)
	{
		can_update_master_decode(rframe,p_data,len);
	}
}

/** 
 * @brief   PCS通信接收线程相关参数初始化
 * @param
 * @return
 */
static void pcs_comm_read_param_init(void)
{
    memset(&g_pcs_comm_info, 0, sizeof(pcs_comm_info_t));
	
}

/**
 * @brief   CAN通讯心跳数据管理
 * @param   
 * @note    收到心跳数据，错误次数会置0。1min都未收到心跳数据（错误次数30），认为离线
 * @return  
 */

static void heartbeat_comm_error_handle(void)
{
    uint16_t i = 0;
	static time_t last_record;
	uint8_t can_break_flag = 0;
	common_data_t * shm_data = sdk_shm_get();
	if(NULL == shm_data)
	{
		return;
	}
     
	if(last_record == 0)
	{
		last_record = time(NULL);  //第一次记录时间
	}
    
	/*失联时间由100秒修改为35秒判断*/
    if (abs(time(NULL) - last_record) >= 5)  //每隔五秒检查一次
    {
		last_record = time(NULL);
        for (i = 0; i < PCS_CABINET_POWER_MODULE_NUM; i++)
        {
            //if (1 == g_pcs_comm_info.pcs_connect_flag[i])  // 曾经连接过
            {
                g_pcs_comm_info.pcs_heartbeat_err_cnt[i]++;
            }

            if (g_pcs_comm_info.pcs_heartbeat_err_cnt[i] >= 7)   //PCS端的CAN检测到100秒无数据那边就会故障
            {
                g_pcs_comm_info.pcs_heartbeat_err_cnt[i] = 7;
                CAN_DEBUG_PRINT((int8_t *)"\n [%s:%d] CAN PCS[%d] Break! \n",__func__, __LINE__, i);   // 测试用
            }
        }
    }

    for (i = 0; i < PCS_CABINET_POWER_MODULE_NUM; i++)
    {
        if (g_pcs_comm_info.pcs_heartbeat_err_cnt[i] >= 7)
        {
        	can_break_flag = 1;
            shm_data->internal_shared_data.pcs_heartbeat_info.comm_state[i] = 0;
        }
		else
		{
			shm_data->internal_shared_data.pcs_heartbeat_info.comm_state[i] = 1;
		}
    }
	if (1 == can_break_flag) // 存在一个PCS模块失联就置位
    {
        // CSU系统中 PCS通讯失联 置位 CMU_system_fault_info[2]-bit1
        shm_data->telematic_data.CMU_system_fault_info[2] |= (1 << 1);
    }
    else
    {
        shm_data->telematic_data.CMU_system_fault_info[2] &= ~(1 << 1);
    }

}

uint8_t recv_flag = 0;//标记是否接收到过CAN数据帧

uint8_t can_error_handle()
{
	uint8_t i = 0;
	static uint32_t can_break_cnt = 0;
	sdk_can_cfg_t can_cfg;
	can_cfg.baud = SDK_CAN_BAUD_500K;
    can_cfg.mode = SDK_CAN_MODE_NORMAL;
	common_data_t * shm_data = sdk_shm_get();
	for (i = 0; i < PCS_CABINET_POWER_MODULE_NUM; i++)
	{
		if (1 == shm_data->internal_shared_data.pcs_heartbeat_info.comm_state[i])//只要有一个模块通讯正常，就不需要重启CAN口
		{
			can_break_cnt = 0;
			return 0;
		}
	}
	if(1 == recv_flag)
	{
		can_break_cnt++;
		if(can_break_cnt >= 50)
		{
			can_break_cnt = 0;
			sdk_can_close(CAN_PORT_PCS);
			sleep(1);
		    sdk_can_open(CAN_PORT_PCS);
		    if (sdk_can_setup(CAN_PORT_PCS, &can_cfg) < 0)
		    {
		        CAN_DEBUG_PRINT((int8_t *)"\n [%s:%d] open CAN fail! \n",__func__, __LINE__);
		    }
			
			printf("reboot can!!!!!!!!!!\n");
			recv_flag = 0;//重启CAN口之后需重新看是否接收到过CAN帧
		}
	}
	
	return 1;
}

/** 
 * @brief   管理CAN数据发送与接收
 * @param
 * @return
 */

void *thread_can1(void *arg)
{
	prctl(PR_SET_NAME, "can_read");
	int32_t ret = 0;
	int32_t timeout_ms = 0;
	//uint8_t p_data[CAN_SOFAR_SEND_MAXNUMS] = {0}; 
	uint8_t *p_data = NULL;
	int32_t len = 0;
	can_msg_t can_msg = {0};
	sdk_can_cfg_t can_cfg;
	pthread_t can_update_task_id;
	pthread_attr_t attr;

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);
	
    can_cfg.baud = SDK_CAN_BAUD_500K;
    can_cfg.mode = SDK_CAN_MODE_NORMAL;

    if(sdk_can_open(CAN_PORT_PCS) < 0)
	{
        CAN_DEBUG_PRINT("\n [%s:%d] open CAN1 fail!\n",__func__, __LINE__);
		pthread_exit(NULL);
	}
	
    if (sdk_can_setup(CAN_PORT_PCS, &can_cfg) < 0)
    {
        log_e((const int8_t*)"open CAN_battery fail! \n");
        pthread_exit(NULL);
    }
	
	CAN_DEBUG_PRINT("\n [%s:%d] open can\n",__func__, __LINE__);
	
	cup_sofar_can_init();
	cup_sofar_can_debug_set(1);
	pcs_comm_read_param_init();

	pthread_mutex_init(&gp_can1_mutex, NULL);

	if(pthread_create(&can_update_task_id,&attr,thread_can_send,NULL) != 0)
	{
		log_e((const int8_t*)"create can send thread fail!\n");
	}
	CAN_DEBUG_PRINT("\n [%s:%d] create can send thread success\n",__func__, __LINE__);

	pthread_attr_destroy(&attr);
	
	timeout_ms = 2000;
	p_data = (uint8_t*)malloc(CAN_SOFAR_SEND_MAXNUMS*sizeof(uint8_t));

	while(1)
	{
		len = 0;
		memset(p_data,0,CAN_SOFAR_SEND_MAXNUMS*sizeof(uint8_t));
		memset(&can_msg,0,sizeof(can_msg_t));
		ret = cup_sofar_can_rev(CAN_PORT_PCS,timeout_ms,&can_msg,p_data,&len);
		if(0 == ret)
		{
			recv_flag = 1;
		}
		
		heartbeat_comm_error_handle();
		
		if((0 == len) && (CONSECUTIVE_FRAME_FLAG == can_msg.flag))
		{
			CAN_DEBUG_PRINT("Long frame, waiting for the packet to complete\n");
			continue;
		}
		
		if((can_msg.dst_type != DEV_CSU_MCU) && (can_msg.dst_type != DEV_BROADCAST))
		{
			CAN_DEBUG_PRINT("\n [%s:%d] dst_type error[%d]\n",__func__, __LINE__,can_msg.dst_type);
			//continue;
		}

		if((DEV_PCS == can_msg.src_type) && ((can_msg.dst_type == DEV_CSU_MCU) || (can_msg.dst_type == DEV_BROADCAST)))
		{
			pcs_data_info_analysis_test(&can_msg,p_data,len);
		}

		can_error_handle();
	}
	free(p_data);
	pthread_exit(NULL);
}


void innercan_task_start(void)
{
	pthread_t can_task_id;
	pthread_attr_t attr;

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);

	if(pthread_create(&can_task_id,&attr,thread_can1,NULL) != 0)
	{
		perror("pthread_create thread_can_test");
	}
	pthread_attr_destroy(&attr);
	return;

}

