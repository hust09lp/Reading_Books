/** 
 * @file          can_safety.h
 * @brief         通过CAN下发安规的接口函数说明
 * @author        liangguyao
 * @version       V0.0.1     初始版本
 * @date          2023/09/07
 * @copyright     Copyright (c) 2023 by SofarSolar, All Rights Reserved.
 */


#ifndef __CAN_SAFETY_H__
#define __CAN_SAFETY_H__

#include "data_types.h"
#include "sofar_type.h"

#if (1)
#define CAN_SAFETY_DEBUG(...) log_i((const int8_t *)__VA_ARGS__);
#else
#define CAN_SAFETY_DEBUG(...) {do {} while(0);}
#endif


#define PATH_SAFETY_FILE				"/user/data/cfg/safety"


/**
 * @brief  	通过CAN下发安规数据给PCS
 * @param  	[in] void
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t can_safety_send(void);

/**
 * @brief  	响应web导入的安规参数，执行转发
 * @param  	[in] void
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t can_process_import_safety(void);


sf_ret_t can_safety_sync( void );

#endif  /* __CAN_SAFETY_H__ */