#ifndef _CAN_UPDATE_H_
#define _CAN_UPDATE_H_
#include <stdbool.h>
#include "cup_sofar_can.h"
#include <time.h>



// 固件相关的参数默认值
#define PACKAGE_SIZE_DEFAULT								(256)//(1024)
#define PACKAGE_CNT_MAX											(512)
#define UPDATE_FW_MAX_SIZE									(PACKAGE_CNT_MAX*1024)
#define PACKAGE_MASK_SIZE										(PACKAGE_CNT_MAX/8)
// 相应的时间间隔定义
#define PACKAGE_DATA_INTERVAL_TIME_MS			(1)
#define PACKAGE_INTERVAL_TIME_MS				(50)
#define PACKAGE_QUERY_INTERVAL_TIME_MS			1000//(500)
// 重发次数
#define CAN_SEND_CMD_REPEAT_CNT							(10)
// 查询最大次数
#define CAN_SEND_REQ_MAX_CNT								(10)
// 帧类型
#define CAN_FRAME_REQ_TYPE									(0)
#define CAN_FRAME_ACK_TYPE									(1)
// 操作状态
#define CAN_UPDATE_STATUS_IDLE							(0)
#define CAN_UPDATE_STATUS_WAIT_ACK					(1)
#define CAN_UPDATE_STATUS_REC_ACK						(2)

// 查询状态
#define CAN_QUERY_STATUS_IDLE							(0)
#define CAN_QUERY_STATUS_WAIT_ACK					(1)
#define CAN_QUERY_STATUS_REC_ACK						(2)

// 应答状态值
#define CAN_UPDATE_RECODE_OK								(0)
#define CAN_UPDATE_RECODE_PACKAGE_CRC_ERROR					(1)
#define CAN_UPDATE_RECODE_FILE_CRC_ERROR					(2)

#define PCS_CABINET_POWER_MODULE_NUM              1	// 8       // PCS系统柜内功率模块数量 
#define CAN_PORT_PCS                              1

#define FIRMWARE_NAME_CAN         				"PCS-M" 
#define FIRMWARE_NAME_PCS_S         			"PCS-S" 

#define CAN_DATA_NUM         		120 

#define PATH_FAULT_RECORD               "/user/data/pcs_fault_record/"            // 逆变器故障录波数据

//PCS点表信息储存
typedef struct{
	uint16_t pcs_dev_info[CAN_DATA_NUM];			//功能码：0 ；设备信息 ；R
	uint16_t pcs_yx_info[CAN_DATA_NUM];			//功能码：1 ；遥信信息 ；R
	uint16_t pcs_yc_info[CAN_DATA_NUM];			//功能码：2 ；遥测信息 ；R
	uint16_t pcs_read_param_info[CAN_DATA_NUM];	//功能码：10；定值/参数；R
	uint16_t pcs_write_param_info[CAN_DATA_NUM];	//功能码：20；定值/参数；W
	uint16_t pcs_write_multicast_info[CAN_DATA_NUM];	//功能码：57；写组播定值/参数；W
	uint8_t pcs_heartbeat_info[CAN_DATA_NUM];	//功能码：0x7f；定值/参数；R 1s周期性发送
}pcs_data_point_info_t;

uint16_t g_pcs_fault_last[CAN_DATA_NUM];
time_t g_fault_time[16*13];   //记录上次出现故障的时间戳,每一个故障位占一个时间戳,一共有13个需要PCS停机的故障(包含预留)

typedef struct{
	uint8_t		status;
	int8_t		ret_code;
	uint8_t		len;
	uint16_t addr;	
	can_frame_id_u			frame_id;
}ack_status_t;


typedef enum{
	UPDATE_START							= 0X7FB,
	UPDATE_DATA_START 				= 0X7FC,
	UPDATE_DATA								= 0X7FD,
	UPDATE_REC_RESULT_QUERY 	= 0X7FE,
	UPDATE_RESULT_QUERY 			= 0X7FF,
}update_fun_code_t;

typedef struct{
    uint8_t  pcs_connect_flag[PCS_CABINET_POWER_MODULE_NUM];       // 记录电池簇是否连接成功过 0: 未连接  1: 已连接
    uint8_t  pcs_comm_break[PCS_CABINET_POWER_MODULE_NUM];         // 0：正常，1: 通讯中断
    uint8_t  pcs_heartbeat_break[PCS_CABINET_POWER_MODULE_NUM];         // 0：正常，1: 通讯中断(心跳)
    uint16_t pcs_comm_err_cnt[PCS_CABINET_POWER_MODULE_NUM];       // 记录电池簇通讯中断次数
    uint16_t pcs_heartbeat_err_cnt[PCS_CABINET_POWER_MODULE_NUM];       // 记录心跳通讯中断次数
    uint8_t  pcs_wait_flag[PCS_CABINET_POWER_MODULE_NUM];			//数据是否返回，1：等待数据返回；2：数据返回 
    uint16_t pcs_respond_flag[PCS_CABINET_POWER_MODULE_NUM];       // 记录电池是否应答下发的设置指令 高八位为功能码 低八位：0-成功 1-失败
    uint8_t  error_code[PCS_CABINET_POWER_MODULE_NUM];                 // 记录电池应答的错误码
    uint8_t  pcs_wait_ack_flag[PCS_CABINET_POWER_MODULE_NUM];			//应答帧是否返回，1：等待数据返回；2：数据返回
    uint8_t  pcs_ack_code[PCS_CABINET_POWER_MODULE_NUM];			//应答帧的结果码
}pcs_comm_info_t;



typedef enum{
	FW_ROLE_ARM = 0,
	FW_ROLE_MDSP,
	FW_ROLE_SDSP,
	FW_ROLE_BMS,
}update_fw_role_t;
//
typedef struct{
	uint8_t		frame_type;
	uint8_t		fw_role; 
	uint16_t	chip_type;
	uint16_t	fw_block_cnt;
	uint16_t	block_size;
}update_start_t;

typedef struct{
	uint8_t		frame_type;
	uint8_t		reserve; 
	uint16_t	data_block_index;
	uint16_t	data_block_size;
	uint16_t	data_block_crc;
}update_data_start_t;

typedef struct{
	uint8_t		frame_type;
	uint8_t		fw_role; 
	uint16_t	chip_type;
	uint16_t	reserve;
	uint16_t	reserve1;
}update_query_result_t;

typedef struct{
	uint8_t src_addr;
	uint8_t		frame_type;
	uint8_t		ret_code;
	uint16_t	chip_type;
	uint8_t		group_index;
	uint32_t	bit_mask;
}update_query_rec_res_t;

typedef struct{
	uint8_t     src_addr;
	uint8_t		flag;
	uint8_t		ret_code;
	uint8_t		group_index;
	uint32_t	bit_mask;
}update_query_rec_res_2_t;

typedef struct{
	int32_t     num;
	update_query_rec_res_2_t        p_query_rec_res_2[288];
}update_query_rec_res_all_t;

typedef struct{
	//uint8_t		frame_type;
	uint8_t		ret_code;
	uint8_t		storage_firmware;
}update_query_update_res_t;

typedef struct{
	uint8_t			ret_code[8];
	uint8_t			res[8];
	int32_t		pack_index[8];
}update_query_pack_rec_res_t;

typedef struct{
	uint16_t	package_cnt;
	uint16_t	package_cur_index;	
	uint16_t	package_size;
	uint8_t		data_buf[PACKAGE_SIZE_DEFAULT*2];
	uint8_t		status;
	uint8_t		recv_flag;//是否还继续接收帧
	uint8_t		device_cnt;
	uint32_t	dev_update_result;
	update_query_rec_res_t			p_query_rec_res;
	update_query_rec_res_all_t      p_query_rec_res_all;
	update_query_update_res_t		p_query_update_res;
	update_query_pack_rec_res_t		p_query_pack_rec_res;
	can_msg_t 				can_msg;
	uint32_t device_mask;				//记录因为某种原因（掉线）未升级的设备
}update_session_t;

typedef struct{
	uint8_t		status;
	uint16_t len;
	can_msg_t 	can_msg;
}query_status_t;

/*升级包校验*/
#define T_PATH_SIZE				            (100)                       // 路径长度

// V02软件固件签名信息，见《软件固件签名规则》
#pragma pack(push)
#pragma pack(1)
typedef struct
{
    uint8_t         protocol_version;   // 协议版本号
    uint32_t        file_len;           // 有效文件长度 小端模式
    uint32_t        file_crc;           // 有效字节crc32
    int8_t          chip_type[30];      // 芯片型号
    int8_t          soft_version[20];   // 软件版本
    int8_t          hard_version[20];   // 硬件版本
    int8_t          project_name[30];   // 工程名称
    int8_t          creation_date[12];  // 生成日期
    uint32_t        code_start_addr;    // 程序起始地址
    uint8_t         chip_role;          // 芯片角色编码
    int8_t          chip_code[2];       // 芯片代号,如M1
    uint8_t         file_type;          // 文件类型编码
    uint8_t         reserved[127];      // 预留
}pcs_firmware_signature_t;
#pragma pack(pop)


// 固件专属信息结构体
#pragma pack(push)
#pragma pack(1)
typedef struct
{
    int8_t path[T_PATH_SIZE];
    int32_t index;
    pcs_firmware_signature_t signature_info;
}pcs_firmware_info_t;
#pragma pack(pop)

// 固件升级任务结构体
#pragma pack(push)
#pragma pack(1)
typedef struct{
    uint8_t update_flag;
    pcs_firmware_info_t pcs_firm;
}pcs_firmware_update_task_t;
#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)
// 故障录波向dsp取数据信息记录
typedef struct
{
	uint8_t	status;
	uint8_t file_id;                      // 文件编码
	uint16_t file_len;					  //文件大小
	FILE * fault_fp;						//文件句柄
	uint8_t end_flag;						//最后一包文件标志
	uint16_t progress;					  //接收进度
}fault_record_info_t;
#pragma pack(pop)


void data_print_data(uint16_t *p_data, int32_t len);

void *thread_can_send(void *args);

bool can_update_master_decode(can_msg_t *rframe,uint8_t* p_data,int32_t len);
bool can_update_master_update_stepup(dev_type_e dev_type, uint8_t tar_addr, uint8_t dev_cnt);
uint32_t can_update_master_send_fw(void);
#endif

