#ifndef __IEC104_SLAVE_H__
#define __IEC104_SLAVE_H__

#include "data_types.h"
#include "sofar_log.h"

#if (0)
#define IEC104_DEBUG_PRINT(...) printf(__VA_ARGS__);
#else
#define IEC104_DEBUG_PRINT(...) {do {} while(0);}
#endif

#define YX_SYS_START_ADDR       0x101
#define YX_BAT_START_ADDR       0x2C1
#define YX_PCS_MODULE_START_ADDR       0x8C1
#define YX_PCS_MODULE_END_ADDR  0x9C0

#define YX_SYS_LEN              (CMU_SYSTEM_FAULT_LEN_BYTE+CONTAINER_SYSTEM_STATUS_LEN_BYTE+CONTAINER_SYSTEM_WARN_LEN_BYTE+CONTAINER_SYSTEM_FAULT_LEN_BYTE)
#define YX_BAT_LEN              (BATTERY_CLUSTER_WARN_LEN_BYTE+BATTERY_CLUSTER_FAULT_LEN_BYTE+BATTERY_CLUSTER_STATUS_LEN_BYTE)


#define YC_CMU_START_ADDR       0x4301
#define YC_SYS_START_ADDR       0x431E
#define YC_BAT_START_ADDR       0x4401
#define YC_PCS_MODULE_INFO_START_ADDR       0xEE01
#define YC_PCS_MODULE_VERSION_START_ADDR    0xEEB1


#define YC_SYS_AMMETER_OFFSET   0x3F    // 系统信息到电表信息的个数

#define YC_SYS_AMMETER_ADDR     0x405D  // 电表信息的地址
#define YC_SYS_AMMETER_LEN      16      // 电表信息个数

#define YC_BAT_OFFSET_ADDR      0xA001  // 第二簇开始的偏移地址

#define SAFETY_PARAM_START_ADDR 0x8101  // 安规参数开始地址
#define SAFETY_PARAM_END_ADDR   0x8400  // 安规参数结束地址

#define PARA_SYS_START_ADDR     0x8701  // 系统参数
#define PARA_POWER_START_ADDR   0x8745  // 动环系统参数
#define PARA_BAT_START_ADDR     0x8801  // 电池参数
#define PARA_PCS_START_ADDR     0x8901  // 电池参数

#define PARA_SYS_LEN            0x44
#define PARA_POWER_LEN          0x42
#define PARA_BAT_LEN            0x4C

#define YK_SWITCH_ADDR          0x6001
#define YK_SWITCH_YL_ADDR       0x6002  // 系统参数
#define YK_FAULT_RESET_ADDR     0x6003  // 故障信号复归
#define YK_START_ADDR           0x6011
#define YK_NUM_MAX              (91)

typedef struct
{
    int addr;
    uint16_t value;
} para_value_t;

typedef struct
{
    para_value_t para_value[0x7f];
    uint8_t num;
} para_value_record_t;

void iec104_slave_task_start(void);

/**
 * @brief   获取记录的预置参数信息地址
 * @param   
 * @return  预置参数结构体首地址
 */
para_value_record_t *para_value_record_get(void);


#endif



