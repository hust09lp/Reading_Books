#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/time.h>
#include <arpa/inet.h>
#include "cs104_slave.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk_net_public.h"
#include "iec104_slave.h"
#include "cs101_information_objects.h"
#include "lib60870_internal.h"
#include "battery_fun_interface.h"
#include "process_battery_read.h"
#include "param_record_task.h"
#include "sdk_public.h"
#include "sci_task.h"
#include "function_handle.h"
#include "mem_utils.h"
#include "low_power_task.h"

static CS104_Slave g_slave = NULL;
static CS101_AppLayerParameters g_alParams = NULL;

// 遥信数据，用于判别遥信变位数据
static telematic_data_t g_telematic_data = {0};    
// 连接记录 
static uint8_t g_connect_flag = 0;    
// 是否有其他响应在处理              
static uint8_t g_other_respone = 0;  
// 执行和结束升级标志（升级文件传输结束后将其置1）        
static uint8_t g_update_start = 0; 
// 预置参数记录               
static para_value_record_t g_para_value_record = {0};
IMasterConnection g_mastercon;

/**
 * @brief   获取记录的预置参数信息地址
 * @param   
 * @return  预置参数结构体首地址
 */
para_value_record_t *para_value_record_get(void)
{
    return (&g_para_value_record);
}

void printCP56Time2a(CP56Time2a time)
{
    IEC104_DEBUG_PRINT("%02i:%02i:%02i %02i/%02i/%04i", CP56Time2a_getHour(time),
                       CP56Time2a_getMinute(time),
                       CP56Time2a_getSecond(time),
                       CP56Time2a_getDayOfMonth(time),
                       CP56Time2a_getMonth(time),
                       CP56Time2a_getYear(time) + 2000);
}

/* Callback handler to log sent or received messages (optional) */
static void rawMessageHandler(void *parameter, IMasterConnection conneciton, uint8_t *msg, int msgSize, bool sent)
{
    if (sent)
    {
        IEC104_DEBUG_PRINT("SEND: ");
    }
    else
    {
        IEC104_DEBUG_PRINT("RCVD: ");
    }

    int i;
    for (i = 0; i < msgSize; i++)
    {
        IEC104_DEBUG_PRINT("%02x ", msg[i]);
    }

    IEC104_DEBUG_PRINT("\n");
}

static bool clockSyncHandler(void *parameter, IMasterConnection connection, CS101_ASDU asdu, CP56Time2a newTime)
{
    IEC104_DEBUG_PRINT("Process time sync command with time ");
    printCP56Time2a(newTime);
    IEC104_DEBUG_PRINT("\n");
    uint64_t newSystemTimeInMs = CP56Time2a_toMsTimestamp(newTime);
    web_control_info_t *p_web_data = shm_web_control_info_get();

    /* Set time for ACT_CON message */
    // CP56Time2a_setFromMsTimestamp(newTime, Hal_getTimeInMs());
 //   CP56Time2a_setFromMsTimestamp(newTime, newSystemTimeInMs);

    /* update system time here */
    system_time_update(newTime);
    p_web_data->sync_systime_flag = 1;
    return true;
}

static bool telemetry_general_data_upload(const CS101_CauseOfTransmission cot, const uint8_t battery_index)
{
    uint8_t i;
    int16_t *p_data;
    CS101_ASDU newAsdu = NULL;
    InformationObject io = NULL;
    uint32_t ioa;  //IOA
    telemetry_data_t *p_telemetry_data = NULL;
    uint8_t data_num;
   
    p_telemetry_data = sdk_shm_telemetry_data_get();
    internal_version_info_t *p_ver = internal_version_info_get();

    newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
    if(newAsdu == NULL)
    {
        printf("CS101_ASDU_create failed\n");
        return false;
    }
    /*1.CMU-1系统 (地址范围0x4301~0x431D)*/
    //CMU储能柜硬件版本号
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4301, (p_ver->mcu1_hardware_version[1] << 8) | p_ver->mcu1_hardware_version[0], IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    //MCU1软件版本号低16位
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4302, (p_ver->mcu1_app_soft_version[1] << 8) | p_ver->mcu1_app_soft_version[0], IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    //MCU1软件版本号高16位
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4303, (p_ver->mcu1_app_soft_version[3] << 8) | p_ver->mcu1_app_soft_version[2], IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    //MCU1BOOT版本号低16位
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4304, 0x156, IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    //MCU1BOOT版本号高16位
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4305, 257, IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    //MCU1CORE版本号低16位
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4306, (p_ver->mcu1_core_soft_version[1] << 8) | p_ver->mcu1_core_soft_version[0], IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    //MCU1CORE版本号高16位
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4307, (p_ver->mcu1_core_soft_version[3] << 8) | p_ver->mcu1_core_soft_version[2], IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    //MCU2软件版本号低16位
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4308, (p_ver->mcu2_app_soft_version[1] << 8) | p_ver->mcu2_app_soft_version[0], IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    //MCU2软件版本号高16位
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4309, (p_ver->mcu2_app_soft_version[3] << 8) | p_ver->mcu2_app_soft_version[2], IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    //MCU2BOOT版本号低16位
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x430A, 0, IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    //MCU2BOOT版本号共16位
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x430B, 0, IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    //MCU2CORE版本号低16位
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x430C, (p_ver->mcu2_core_soft_version[1] << 8) | p_ver->mcu2_core_soft_version[0], IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    //MCU2CORE版本号高16位
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x430D, (p_ver->mcu2_core_soft_version[3] << 8) | p_ver->mcu2_core_soft_version[2], IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    //通信协议版本号
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x430E, SCI_VERTION1, IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    //系统状态
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x430F, p_telemetry_data->cmu_telemetry_info.cmu_sys_state, IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);

    // 消防控制器软件版本号
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4310, (p_ver->ff_software_version[1] << 8) | p_ver->ff_software_version[0], IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);

    //SN
    p_data = (int16_t *)(&p_ver->dev_sn);
    for (i = 0; i < 12; i++)
    {
        ioa = 0x4311 + i;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, htons(*(p_data + i)), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
    }


    //预留部分
    ioa = 0x431D;
    io = (InformationObject) MeasuredValueShort_create(NULL, ioa, 0, IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    
    CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
    CS101_ASDU_destroy(newAsdu);
    usleep(50);

    /*CMU-1储能柜系统 (地址范围0x431E~0x4400)*/
    newAsdu = NULL;
    data_num = 0;
    p_data = (int16_t *)(&p_telemetry_data->container_system_telemetry_info.soc);
    for(i = 0; i < 76; i++)
    {   
        if(newAsdu == NULL)
        {
            newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
            if(newAsdu == NULL)
            {
                printf("CS101_ASDU_create failed\n");
                return false;
            }
        }
    
        ioa = 0x431E + i;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
        data_num += 1;
        if(data_num == 30)  //30*8 = 240,留下15个字节作为头部
        {
            CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
            CS101_ASDU_destroy(newAsdu);
            usleep(50);
            data_num = 0;
            newAsdu = NULL;
        }
    }
    if(newAsdu != NULL)  //残留部分
    {
        CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
        CS101_ASDU_destroy(newAsdu);
        usleep(50);
    }

    /*电池柜概要数据（地址范围0x4401~0x4434）*/
    newAsdu = NULL;
    data_num = 0;
    p_data = (int16_t *)(&p_telemetry_data->battery_cluster_telemetry_info[battery_index].software_version);
    for(i = 0; i < 52; i++)
    {   
        if(newAsdu == NULL)
        {
            newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
            if(newAsdu == NULL)
            {
                printf("CS101_ASDU_create failed\n");
                return false;
            }
        }
    
        ioa = 0x4401 + i + 0x6000 * battery_index;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
        data_num += 1;
        if(data_num == 30)  //30*8 = 240,留下15个字节作为头部
        {
            CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
            CS101_ASDU_destroy(newAsdu);
            usleep(50);
            data_num = 0;
            newAsdu = NULL;
        }
    }
    if(newAsdu != NULL)  //残留部分
    {
        CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
        CS101_ASDU_destroy(newAsdu);
        usleep(50);
    }
    return true;
}

static bool telemetry_constant_param_upload(const CS101_CauseOfTransmission cot, const uint8_t battery_index)
{
    uint8_t i;
    int16_t *p_data;
    CS101_ASDU newAsdu = NULL;
    InformationObject io = NULL;
    uint32_t ioa;  //IOA
    constant_parameter_data_t *p_constant_parameter = NULL;
    uint8_t data_num;

    p_constant_parameter = sdk_shm_constant_parameter_data_get();
    /*CMU-1 系统 (地址范围0x8701~0x8742)*/
    data_num = 0;
    p_data = (int16_t *)(&p_constant_parameter->storage_duration_operation_data);
    for(i = 0; i < 44; i++)  
    {
        if(newAsdu == NULL)
        {
            newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
            if(newAsdu == NULL)
            {
                printf("CS101_ASDU_create failed\n");
                return false;
            }
        }

        ioa = 0x8701 + i;
        if((ioa >= 0x8707) && (ioa <= 0x8712))
        {
            io = (InformationObject) MeasuredValueShort_create(NULL, ioa, htons(*(p_data + i)), IEC60870_QUALITY_GOOD);
        }
        else
        {
            io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        }
        
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
        data_num += 1;
        if(data_num == 30)  //30*8 = 240,留下15个字节作为头部
        {
            CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
            CS101_ASDU_destroy(newAsdu);
            usleep(50);
            data_num = 0;
            newAsdu = NULL;
        }
    }
    if(newAsdu != NULL)  //残留部分
    {
        CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
        CS101_ASDU_destroy(newAsdu);
        usleep(50);
    }

    /*CMU-1储能柜 系统 （地址范围0x8741~0x8800）*/
    data_num = 0;
    newAsdu = NULL;
    p_data = (int16_t *)(&p_constant_parameter->cluster_curr_diff_warn_threshold_1);
    for(i = 0; i < 112; i++)
    {
        if(newAsdu == NULL)
        {
            newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
            if(newAsdu == NULL)
            {
                printf("CS101_ASDU_create failed\n");
                return false;
            }
        }
    
        ioa = 0x8741 + i;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
        data_num += 1;
        if(data_num == 30)  //30*8 = 240,留下15个字节作为头部
        {
            CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
            CS101_ASDU_destroy(newAsdu);
            usleep(50);
            data_num = 0;
            newAsdu = NULL;
        }
    }
    if(newAsdu != NULL)  //残留部分
    {
        CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
        CS101_ASDU_destroy(newAsdu);
        usleep(50);
    }

    /*CMU-1电池柜 内电池簇 （地址范围0x8801-0x8900）*/
    data_num = 0;
    newAsdu = NULL;
    p_data = (int16_t *)(&p_constant_parameter->battery_parameter_data[battery_index].ISO_warn_threshold_1);
    for(i = 0; i < 76; i++)
    {
        if(newAsdu == NULL)
        {
            newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
            if(newAsdu == NULL)
            {
                printf("CS101_ASDU_create failed\n");
                return false;
            }
        }
    
        ioa = 0x8801 + i;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
        data_num += 1;
        if(data_num == 30)  //30*8 = 240,留下15个字节作为头部
        {
            CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
            CS101_ASDU_destroy(newAsdu);
            usleep(50);
            data_num = 0;
            newAsdu = NULL;
        }
    }
    if(newAsdu != NULL)  //残留部分
    {
        CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
        CS101_ASDU_destroy(newAsdu);
        usleep(50);
    }

    /*CMU-1 PCS模块参数 （地址范围0x8901-0x8940）*/
    newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
    if(newAsdu == NULL)
    {
        printf("CS101_ASDU_create failed\n");
        return false;
    }
    p_data = (int16_t *)(&p_constant_parameter->iec_pcs_parameter_data[0].active_power_ref);
    for(i = 0; i < 8; i++)
    {
        ioa = 0x8901 + i;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
    }
    CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
    CS101_ASDU_destroy(newAsdu);

    return true;
}

static bool telemetry_safety_param_upload(const CS101_CauseOfTransmission cot)
{
    uint8_t i;
    int16_t *p_data;
    CS101_ASDU newAsdu = NULL;
    InformationObject io = NULL;
    uint32_t ioa;  //IOA
    constant_parameter_data_t *p_constant_parameter = NULL;
    uint8_t data_num;

    p_constant_parameter = sdk_shm_constant_parameter_data_get();

    /* 安规参数 */
    data_num = 0;
    p_data = (int16_t *)(&p_constant_parameter->safety_param);
    for (size_t i = 0; i < sizeof(p_constant_parameter->safety_param)/2 ; i++)
    {
        if(newAsdu == NULL)
        {
            newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
            if(newAsdu == NULL)
            {
                printf("CS101_ASDU_create failed\n");
                return false;
            }
        }

        ioa = SAFETY_PARAM_START_ADDR + i;
        if((ioa >= SAFETY_PARAM_START_ADDR) && (ioa <= SAFETY_PARAM_END_ADDR))
        {
            io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        }
        
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
        data_num += 1;
        if(data_num == 30)  //30*8 = 240,留下15个字节作为头部
        {
            CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
            CS101_ASDU_destroy(newAsdu);
            usleep(50);
            data_num = 0;
            newAsdu = NULL;
        }
    }
    if(newAsdu != NULL)  //残留部分
    {
        CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
        CS101_ASDU_destroy(newAsdu);
        usleep(50);
    }

    return true;
}

static bool telemetry_detail_data_upload(const CS101_CauseOfTransmission cot, const uint8_t battery_index, const uint8_t pack_index)
{
    uint8_t i;
    int16_t *p_data;
    CS101_ASDU newAsdu = NULL;
    InformationObject io = NULL;
    uint32_t ioa;  //IOA
    telemetry_data_t *p_telemetry_data = NULL;
    uint8_t data_num;

    p_telemetry_data = sdk_shm_telemetry_data_get();
    /*PACK单体电压Uc1-Uc48*/
    data_num = 0;
    p_data = (int16_t *)(&p_telemetry_data->battery_cluster_telemetry_info[battery_index].monomer_info[pack_index].monomer_voltage[0]);
    for(i = 0; i < MONOMER_NUMBER_IN_PACK; i++)
    {
        if(newAsdu == NULL)
        {
            newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
            if(newAsdu == NULL)
            {
                printf("CS101_ASDU_create failed\n");
                return false;
            }
        }
    
        ioa = 0x4435 + i + (pack_index * 0x120) + (0x6000 * battery_index);
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
        data_num += 1;
        if(data_num == 30)  //30*8 = 240,留下15个字节作为头部
        {
            CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
            CS101_ASDU_destroy(newAsdu);
            usleep(50);
            data_num = 0;
            newAsdu = NULL;
        }
    }
    if(newAsdu != NULL)  //残留部分
    {
        CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
        CS101_ASDU_destroy(newAsdu);
        usleep(50);
    }

    /*PACK单体温度Tc1-Tc48*/
    data_num = 0;
    newAsdu = NULL;
    p_data = (int16_t *)(&p_telemetry_data->battery_cluster_telemetry_info[battery_index].monomer_info[pack_index].monomer_temperature[0]);
    for(i = 0; i < MONOMER_NUMBER_IN_PACK; i++)
    {
        if(newAsdu == NULL)
        {
            newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
            if(newAsdu == NULL)
            {
                printf("CS101_ASDU_create failed\n");
                return false;
            }
        }
    
        ioa = 0x4465 + i + (pack_index * 0x120) + (0x6000 * battery_index);
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
        data_num += 1;
        if(data_num == 30)  //30*8 = 240,留下15个字节作为头部
        {
            CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
            CS101_ASDU_destroy(newAsdu);
            usleep(50);
            data_num = 0;
            newAsdu = NULL;
        }
    }
    if(newAsdu != NULL)  //残留部分
    {
        CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
        CS101_ASDU_destroy(newAsdu);
    }

    /*PACK单体SOC*/
    data_num = 0;
    newAsdu = NULL;
    p_data = (int16_t *)(&p_telemetry_data->battery_cluster_telemetry_info[battery_index].monomer_info[pack_index].monomer_SOC[0]);
    for(i = 0; i < MONOMER_NUMBER_IN_PACK; i++)
    {
        if(newAsdu == NULL)
        {
            newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
            if(newAsdu == NULL)
            {
                printf("CS101_ASDU_create failed\n");
                return false;
            }
        }
    
        ioa = 0x4495 + i + (pack_index * 0x120) + (0x6000 * battery_index);
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
        data_num += 1;
        if(data_num == 30)  //30*8 = 240,留下15个字节作为头部
        {
            CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
            CS101_ASDU_destroy(newAsdu);
            usleep(50);
            data_num = 0;
            newAsdu = NULL;
        }
    }
    if(newAsdu != NULL)  //残留部分
    {
        CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
        CS101_ASDU_destroy(newAsdu);
        usleep(50);
    }

    /*PACK单体SOH*/
    data_num = 0;
    newAsdu = NULL;
    p_data = (int16_t *)(&p_telemetry_data->battery_cluster_telemetry_info[battery_index].monomer_info[pack_index].monomer_SOH[0]);
    for(i = 0; i < MONOMER_NUMBER_IN_PACK; i++)
    {
        if(newAsdu == NULL)
        {
            newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
            if(newAsdu == NULL)
            {
                printf("CS101_ASDU_create failed\n");
                return false;
            }
        }
    
        ioa = 0x44C5 + i + (pack_index * 0x120) + (0x6000 * battery_index);
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
        data_num += 1;
        if(data_num == 30)  //30*8 = 240,留下15个字节作为头部
        {
            CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
            CS101_ASDU_destroy(newAsdu);
            usleep(50);
            data_num = 0;
            newAsdu = NULL;
        }
    }
    if(newAsdu != NULL)  //残留部分
    {
        CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
        CS101_ASDU_destroy(newAsdu);
        usleep(50);
    }

    /*PACK单体SOE（高特未提供）*/
    data_num = 0;
    newAsdu = NULL;
    p_data = (int16_t *)(&p_telemetry_data->battery_cluster_telemetry_info[battery_index].monomer_info[pack_index].monomer_SOE[0]);
    for(i = 0; i < MONOMER_NUMBER_IN_PACK; i++)
    {
        if(newAsdu == NULL)
        {
            newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
            if(newAsdu == NULL)
            {
                printf("CS101_ASDU_create failed\n");
                return false;
            }
        }
    
        ioa = 0x44F5 + i + (pack_index * 0x120) + (0x6000 * battery_index);
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
        data_num += 1;
        if(data_num == 30)  //30*8 = 240,留下15个字节作为头部
        {
            CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
            CS101_ASDU_destroy(newAsdu);
            usleep(50);
            data_num = 0;
            newAsdu = NULL;
        }
    }
    if(newAsdu != NULL)  //残留部分
    {
        CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
        CS101_ASDU_destroy(newAsdu);
        usleep(50);
    }

    /*PACK1单体SOP（高特未提供）*/
    data_num = 0;
    newAsdu = NULL;
    p_data = (int16_t *)(&p_telemetry_data->battery_cluster_telemetry_info[battery_index].monomer_info[pack_index].monomer_SOP[0]);
    for(i = 0; i < MONOMER_NUMBER_IN_PACK; i++)
    {
        if(newAsdu == NULL)
        {
            newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
            if(newAsdu == NULL)
            {
                printf("CS101_ASDU_create failed\n");
                return false;
            }
        }
    
        ioa = 0x4525 + i + (pack_index * 0x120) + (0x6000 * battery_index);
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
        data_num += 1;
        if(data_num == 30)  //30*8 = 240,留下15个字节作为头部
        {
            CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
            CS101_ASDU_destroy(newAsdu);
            usleep(50);
            data_num = 0;
            newAsdu = NULL;
        }
    }
    if(newAsdu != NULL)  //残留部分
    {
        CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
        CS101_ASDU_destroy(newAsdu);
        usleep(50);
    }
    
    /*极柱温度*/
    newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
    if(newAsdu == NULL)
    {
        printf("CS101_ASDU_create failed\n");
        return false;
    }
    ioa = 0x4D35 + (pack_index * 2)  + (0x6000 * battery_index);
    io = (InformationObject) MeasuredValueShort_create(NULL, ioa, p_telemetry_data->battery_cluster_telemetry_info[battery_index].pole_temperater_PACK[pack_index][0], IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    ioa = 0x4D36 + (pack_index * 2)  + (0x6000 * battery_index);;
    io = (InformationObject) MeasuredValueShort_create(NULL, ioa, p_telemetry_data->battery_cluster_telemetry_info[battery_index].pole_temperater_PACK[pack_index][1], IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
    CS101_ASDU_destroy(newAsdu);

    return true;
}

static bool telemetry_pcs_data_upload(const CS101_CauseOfTransmission cot)
{
    uint8_t i;
    int16_t *p_data;
    CS101_ASDU newAsdu = NULL;
    InformationObject io = NULL;
    uint32_t ioa;  //IOA
    telemetry_data_t *p_telemetry_data = NULL;

    p_telemetry_data = sdk_shm_telemetry_data_get();
    /*PCS功率模块(地址范围0xEE01~0xEEB0)*/
    newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
    if(newAsdu == NULL)
    {
        printf("CS101_ASDU_create failed\n");
        return false;
    }
    p_data = (int16_t *)(&p_telemetry_data->power_module_telemetry_info[0].grid_volt_rs);
    for(i = 0; i < 27; i++)
    {
        ioa = 0xEE01 + i;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
    }
    CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
    CS101_ASDU_destroy(newAsdu);
    usleep(50);
    
    /*预留*/
    newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
    if(newAsdu == NULL)
    {
        printf("CS101_ASDU_create failed\n");
        return false;
    }
    for(i = 0; i < 23; i++)
    {
        ioa = 0xEE1C + i;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, 0, IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
    }
    CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
    CS101_ASDU_destroy(newAsdu);
    usleep(50);
    
    /*电网相电压*/
    p_data = (int16_t *)(&p_telemetry_data->power_module_telemetry_info[0].grid_volt_r);
    newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
    if(newAsdu == NULL)
    {
        printf("CS101_ASDU_create failed\n");
        return false;
    }
    for(i = 0; i < 29; i++)
    {
        ioa = 0xEE33 + i;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
    }
    CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
    CS101_ASDU_destroy(newAsdu);
    usleep(50);

    /*预留*/
    newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
    if(newAsdu == NULL)
    {
        printf("CS101_ASDU_create failed\n");
        return false;
    }
    for(i = 0; i < 21; i++)
    {
        ioa = 0xEE50 + i;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, 0, IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
    }
    CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
    CS101_ASDU_destroy(newAsdu);
    usleep(50);

    /*电池电流*/
    newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
    if(newAsdu == NULL)
    {
        printf("CS101_ASDU_create failed\n");
        return false;
    }
    p_data = (int16_t *)(&p_telemetry_data->power_module_telemetry_info[0].bat_current);
    for(i = 0; i < 3; i++)
    {
        ioa = 0xEE65 + i;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
    }
    CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
    CS101_ASDU_destroy(newAsdu);
    usleep(50);

    /*PCS功率模块设备信息(地址范围0xEEB1~0xEF00)*/
    p_data = (int16_t *)(&p_telemetry_data->pcs_module_version_telemetry_info[0].sn[0]);
    newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
    if(newAsdu == NULL)
    {
        printf("CS101_ASDU_create failed\n");
        return false;
    }
    for(i = 0; i < 10; i++)
    {
        ioa = 0xEEB1 + i;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, htons(*(p_data + i)), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
    }

    for(i = 10; i < 20; i++)
    {
        ioa = 0xEEB1 + i;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
    }

    CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
    CS101_ASDU_destroy(newAsdu);
    usleep(50);

    /*预留*/
    newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
    if(newAsdu == NULL)
    {
        printf("CS101_ASDU_create failed\n");
        return false;
    }
    for(i = 0; i < 30; i++)
    {
        ioa = 0xEEC5 + i;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, 0, IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
    }
    CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
    CS101_ASDU_destroy(newAsdu);
    usleep(50);

    /*从DSP软件版本号*/
    p_data = (int16_t *)(&p_telemetry_data->pcs_module_version_telemetry_info[0].slv_fw_version[0]);
    newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
    if(newAsdu == NULL)
    {
        printf("CS101_ASDU_create failed\n");
        return false;
    }
    for(i = 0; i < 9; i++)
    {
        ioa = 0xEEE3 + i;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
    }
    CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
    CS101_ASDU_destroy(newAsdu);
    usleep(50);

    return true;
}

static bool telematic_data_upload(const CS101_CauseOfTransmission cot, uint8_t total_flag)
{
    InformationObject io = NULL;
    CS101_ASDU newAsdu = NULL;
    telematic_data_t *p_telematic_data = NULL;
    uint8_t *p_data8 = NULL;
    uint16_t i = 0;
    uint8_t j = 0;
    uint32_t data_num;
    uint8_t value = 0;
    int32_t addr = 0;
    uint8_t bat_num = 0;
    uint8_t pcs_num = 0;
    constant_parameter_data_t *p_constant_param = NULL;

    p_constant_param = sdk_shm_constant_parameter_data_get();
 //   CS101_AppLayerParameters alParams = IMasterConnection_getApplicationLayerParameters(g_mastercon);
    //上传CMU+集装箱状态信息+集装箱告警信息+集装箱故障信息
    p_telematic_data = sdk_shm_telematic_data_get();
    //对比遥信是否发生变化
    if((memcmp(&g_telematic_data, p_telematic_data, sizeof(telematic_data_t)) == 0) && (total_flag == 0))
    {
        return false;
    }
    data_num = 0;
    p_data8 = (uint8_t *)(&p_telematic_data->CMU_system_fault_info[0]);
    for (i = 0; i < YX_SYS_LEN; i++)
    {
        for (j = 0; j < 8; j++)
        {
            if(newAsdu == NULL)
            {
                newAsdu = CS101_ASDU_create(g_alParams, false, cot,
                                                    0, 1, false, false);
                if(newAsdu == NULL)
                {
                    printf("CS101_ASDU_create failed\n");
                    return false;
                
                }
            }
            addr = (i * 8) + j + YX_SYS_START_ADDR;
            value = (*(p_data8 + i) >> j) & 0x01;
           // value = (*(p_data8 + i) >> j) & 0x01;
            io = (InformationObject)SinglePointInformation_create(NULL, addr, value, IEC60870_QUALITY_GOOD);
            CS101_ASDU_addInformationObject(newAsdu, io);
            InformationObject_destroy(io);
            data_num += 1;
            if(data_num == 56)  //三个IOA+一个值，一个遥信占据四个字节
            {
                if(g_mastercon != NULL)
                {
                    IMasterConnection_sendASDU(g_mastercon, newAsdu);
                }
                CS101_ASDU_destroy(newAsdu);
                data_num = 0;
                newAsdu = NULL;
                usleep(50);
            }
        }
    }
    if(newAsdu != NULL)
    {
        if(g_mastercon != NULL)
        {
            IMasterConnection_sendASDU(g_mastercon, newAsdu);
        }
        CS101_ASDU_destroy(newAsdu);
        usleep(50);
    }

    //上传电池簇遥信信息
    data_num = 0;
    newAsdu = NULL;
    for (bat_num = 0; bat_num < p_constant_param->bat_cabinet_num; bat_num++)  //国能日新只有一簇电池
    {
        p_data8 = (uint8_t *)(&p_telematic_data->battery_cluster_telematic_info[bat_num].battery_cluster_status_info[0]);
        for (i = 0; i < YX_BAT_LEN; i++)
        {
            for (j = 0; j < 8; j++)
            {
                if(newAsdu == NULL)
                {
                    newAsdu = CS101_ASDU_create(g_alParams, false, cot,
                                                        0, 1, false, false);
                    if(newAsdu == NULL)
                    {
                        printf("CS101_ASDU_create failed\n");
                        return false;
                    }
                }
                addr = (i * 8) + j + (YX_BAT_START_ADDR + (0x100 * bat_num));
                if(addr == (773 + (0x100 * bat_num)) || addr == (774 +  (0x100 * bat_num)))   //单体过压2级和单体欠压2级不上报
                {
                    value = 0;
                }
                else
                {
                    value = (*(p_data8 + i) >> j) & 0x01;
                }
              //  value = (*(p_data8 + i) >> j) & 0x01;
                io = (InformationObject)SinglePointInformation_create(NULL, addr, value, IEC60870_QUALITY_GOOD);
                CS101_ASDU_addInformationObject(newAsdu, io);
                InformationObject_destroy(io);
                data_num += 1;
                if(data_num == 56)  //三个IOA+一个值，一个遥信占据四个字节
                {
                    if(g_mastercon != NULL)
                    {
                        IMasterConnection_sendASDU(g_mastercon, newAsdu);
                    }
                    CS101_ASDU_destroy(newAsdu);
                    newAsdu = NULL;
                    data_num = 0;
                    usleep(50);
                }
            }
        }
    }
    if(newAsdu != NULL)
    {
        if(g_mastercon != NULL)
        {
            IMasterConnection_sendASDU(g_mastercon, newAsdu);
        }
        CS101_ASDU_destroy(newAsdu);
        usleep(50);
    }

    // 加载遥信数据 PCS功率模块
    data_num = 0;
    newAsdu = NULL;
    for (pcs_num = 0; pcs_num < 1; pcs_num++)
    {
        p_data8 = (uint8_t *)(&p_telematic_data->pcs_module[pcs_num].grid_fault.val);
        for(i = 0; i < 240; i++)
        {
            for (j = 0; j < 8; j++)
            {
                if(newAsdu == NULL)
                {
                    newAsdu = CS101_ASDU_create(g_alParams, false, cot,
                                                        0, 1, false, false);
                    if(newAsdu == NULL)
                    {
                        printf("CS101_ASDU_create failed\n");
                        return false;
                    }
                }
                addr = (i * 8) + j + (YX_PCS_MODULE_START_ADDR + (0x100 * pcs_num));
                value = (*(p_data8 + i) >> j) & 0x01;
                io = (InformationObject)SinglePointInformation_create(NULL, addr, value, IEC60870_QUALITY_GOOD);
                CS101_ASDU_addInformationObject(newAsdu, io);
                InformationObject_destroy(io);
                data_num += 1;
                if(data_num == 56)  //三个IOA+一个值，一个遥信占据四个字节
                {
                    if(g_mastercon != NULL)
                    {
                         IMasterConnection_sendASDU(g_mastercon, newAsdu);
                    }
                    CS101_ASDU_destroy(newAsdu);
                    newAsdu = NULL;
                    data_num = 0;
                    usleep(50);
                }
            }
        }
    }
    if(newAsdu != NULL)
    {
        if(g_mastercon != NULL)
        {
            IMasterConnection_sendASDU(g_mastercon, newAsdu);
        }
        CS101_ASDU_destroy(newAsdu);
        newAsdu = NULL;
    }
    memcpy(&g_telematic_data, p_telematic_data, sizeof(telematic_data_t));
    return true;
}
/**
 * @brief   总召唤数据响应
 * @param   [in] parameter
 * @param   [in] connection
 * @param   [in] asdu
 * @return
 */
static bool interrogationHandler(void *parameter, IMasterConnection connection, CS101_ASDU asdu, uint8_t qoi)
{
    uint16_t i = 0;
    uint16_t j = 0;

    g_mastercon = connection;
    g_connect_flag = 0;
    constant_parameter_data_t *p_constant_param = NULL;
    telematic_data_t *p_telematic_data = NULL;

    p_telematic_data = sdk_shm_telematic_data_get();
    p_constant_param = sdk_shm_constant_parameter_data_get();
    telematic_data_upload(CS101_COT_INTERROGATED_BY_STATION, 1);
    for(i = 0; i < p_constant_param->bat_cabinet_num; i++)
    {
        telemetry_general_data_upload(CS101_COT_INTERROGATED_BY_STATION, i); //电池簇0的概要数据
        telemetry_constant_param_upload(CS101_COT_INTERROGATED_BY_STATION, i);
        for(j = 0; j < p_constant_param->bat_cluster_pack_num; j++) //pack的详细数据
        {
            telemetry_detail_data_upload(CS101_COT_INTERROGATED_BY_STATION, i, j);
        }
    }
    telemetry_pcs_data_upload(CS101_COT_INTERROGATED_BY_STATION);  //PCS数据
    telemetry_safety_param_upload( CS101_COT_PERIODIC );
	
    memcpy(&g_telematic_data, p_telematic_data, sizeof(telematic_data_t));  //先更新一次数据到全局变量，存储的是改变之前的遥信量
    g_connect_flag = 1;
    IMasterConnection_sendACT_TERM(connection, asdu); // 结束确认帧
    return true;
}

/**
 * @brief   文件传输处理
 * @param   [in] parameter
 * @param   [in] connection
 * @param   [in] asdu
 * @return
 */
static bool file_processing(void *parameter, IMasterConnection connection, CS101_ASDU asdu)
{
    uint8_t ctrl_id = 0;
    uint8_t len = 0;
    int8_t name[65] = {0};
    CS101_ASDU newAsdu = NULL;
    InformationObject io = NULL;

    file_directory_con_t file_directory_con = {0};
    file_activate_con_t file_activate_con = {0};
    file_data_trs_t file_data_trs = {0};
    file_data_trs_con_t file_data_trs_con = {0};

    file_directory_con_t *p_file_directory_con = &file_directory_con;
    file_activate_con_t *p_file_activate_con = &file_activate_con;
    file_data_trs_t *p_file_data_trs = &file_data_trs;
    file_data_trs_con_t *p_file_data_trs_con = &file_data_trs_con;

    CS101_AppLayerParameters alParams = CS104_Slave_getAppLayerParameters((CS104_Slave)connection);

    io = CS101_ASDU_getElement(asdu, 0);
    if (io)
    {
        if (FileIdentify_getDataType((FileIdentify )io) == 2)
        {
            IEC104_DEBUG_PRINT(" FileIdentify_getDataType == 2 ");
        }
        else
        {
            IEC104_DEBUG_PRINT("\n FileIdentify_getDataType != 2 \n");
            // 异常不处理
            CS101_ASDU_setCOT(asdu, CS101_COT_UNKNOWN_COT);
            IMasterConnection_sendASDU(connection, asdu);

            return true;
        }

        ctrl_id = FileIdentify_getCtrlID((FileIdentify )io);
        IEC104_DEBUG_PRINT(" ctrl_id == %x ", ctrl_id);

        // 获取数据ID之后，根据操作标识符解析数据，并做相应的逻辑响应
        switch (ctrl_id)
        {
            case FILE_READ_DIRECTORY:
                // 获取要读取的目录信息
                FileIdentify_getID((FileIdentify )io, FILE_READ_DIRECTORY);
                len = FileIdentify_getLen((FileIdentify )io, FILE_READ_DIRECTORY);
                FileIdentify_getName((FileIdentify )io, FILE_READ_DIRECTORY, name);
                CP56Time2a start_time = FileIdentify_start_time((FileIdentify )io);
                CP56Time2a stop_time = FileIdentify_stop_time((FileIdentify )io);

                // 获取读取范围 
                if (FileIdentify_getSign((FileIdentify )io, FILE_READ_DIRECTORY) == 0) 
                {
                    // 目录下所有文件
                    file_identify_get(name, len, 0, start_time, stop_time, p_file_directory_con);
                }
                else 
                {
                    // 目录下满足搜索时间段的文件
                    file_identify_get(name, len, 1, start_time, stop_time, p_file_directory_con);
                }

                InformationObject_destroy(io);

                newAsdu = CS101_ASDU_create(alParams, false, CS101_COT_ACTIVATION_CON,
                                            0, 1, false, false);
                io = (InformationObject)FileIdentify_create(NULL, 0, FILE_READ_DIRECTORY_CON, p_file_directory_con);
                CS101_ASDU_addInformationObject(newAsdu, io);

                InformationObject_destroy(io);
                IMasterConnection_sendASDU(connection, newAsdu);
                CS101_ASDU_destroy(newAsdu);
                break;

            case FILE_READ_ACTIVATE:
                // 获取要读取的文件名称
                len = FileIdentify_getLen((FileIdentify )io, FILE_READ_ACTIVATE);
                FileIdentify_getName((FileIdentify )io, FILE_READ_DIRECTORY, name);

                // 获取文件大小及获取结果
                file_activate_con_get((FileIdentify )io, p_file_activate_con);

                InformationObject_destroy(io);

                // 发送读文件激活确认信息
                newAsdu = CS101_ASDU_create(alParams, false, CS101_COT_ACTIVATION_CON,
                                            0, 1, false, false);
                io = (InformationObject)FileIdentify_create(NULL, 0, FILE_READ_ACTIVATE_CON, p_file_activate_con);
                CS101_ASDU_addInformationObject(newAsdu, io);

                InformationObject_destroy(io);
                IMasterConnection_sendASDU(connection, newAsdu);
                CS101_ASDU_destroy(newAsdu);

                // 发送文件具体数据
                newAsdu = CS101_ASDU_create(alParams, false, CS101_COT_REQUEST,
                                            0, 1, false, false);
                io = (InformationObject)FileIdentify_create(NULL, 0, FILE_READ_DATA, p_file_data_trs);
                CS101_ASDU_addInformationObject(newAsdu, io);

                InformationObject_destroy(io);
                IMasterConnection_sendASDU(connection, newAsdu);
                CS101_ASDU_destroy(newAsdu);
                break;

            case FILE_WRITE_ACTIVATE:
                IEC104_DEBUG_PRINT("\n FILE_WRITE_ACTIVATE \n");

                // 返回是否可写的结果
                file_activate_con_get((FileIdentify )io, p_file_activate_con);
                InformationObject_destroy(io);

                // 发送写数据激活确认
                newAsdu = CS101_ASDU_create(alParams, false, CS101_COT_ACTIVATION_CON,
                                            0, 1, false, false);
                io = (InformationObject)FileIdentify_create(NULL, 0, FILE_WEITE_ACTIVATE_CON, p_file_activate_con);
                CS101_ASDU_addInformationObject(newAsdu, io);

                InformationObject_destroy(io);
                IMasterConnection_sendASDU(connection, newAsdu);
                CS101_ASDU_destroy(newAsdu);
                break;

            case FILE_WRITE_DATA:
                printf("\n FILE_WRITE_DATA \n");
                // 将获取的数据写入文件
                file_data_trs_set((FileIdentify )io, p_file_data_trs_con);
                InformationObject_destroy(io);

                // 发送写数据传输确认
                newAsdu = CS101_ASDU_create(alParams, false, CS101_COT_ACTIVATION_CON,
                                            0, 1, false, false);
                io = (InformationObject)FileIdentify_create(NULL, 0, FILE_WRITE_DATA_CON, p_file_data_trs_con);
           
                CS101_ASDU_addInformationObject(newAsdu, io);

                InformationObject_destroy(io);
                printf("\n IMasterConnection_sendASDU \n");
                IMasterConnection_sendASDU(connection, newAsdu);
                printf("\n CS101_ASDU_destroy \n");
                CS101_ASDU_destroy(newAsdu);
                break;

            default:
                InformationObject_destroy(io);
                CS101_ASDU_setCOT(asdu, CS101_COT_UNKNOWN_COT);
                IMasterConnection_sendASDU(connection, asdu);
                break;
        }
    }
    else
    {
        IEC104_DEBUG_PRINT("ERROR: message has no valid information object\n");
    }
    return true;
}

/**
 * @brief   升级处理
 * @param   [in] parameter
 * @param   [in] connection
 * @param   [in] asdu
 * @return
 */
static bool update_processing(void *parameter, IMasterConnection connection, CS101_ASDU asdu)
{
    // CS101_ASDU newAsdu = NULL;
    InformationObject io = NULL;
    
    CS104_Slave_getAppLayerParameters((CS104_Slave)connection);

    if (CS101_ASDU_getCOT(asdu) == CS101_COT_ACTIVATION)
    {
        io = CS101_ASDU_getElement(asdu, 0);

        if (io)
        {
            if (UpdateInform_isSelect((UpdateInform)asdu) == true) // 升级启动命令
            {
                IEC104_DEBUG_PRINT("\n******启动升级******\n");

                // 设置升级
                update_state_set(UPDATE);
                g_update_start = 1;

                // 升级启动确认
                CS101_ASDU_setCOT(asdu, CS101_COT_ACTIVATION_CON);
                IMasterConnection_sendASDU(connection, asdu);
                InformationObject_destroy(io);
            }
            else // 升级执行
            {
                IEC104_DEBUG_PRINT("\n******执行升级/升级结束******\n");
                
                // 设置正在下载
                if (g_update_start == 1)
                {
                    update_state_set(DOWNLOAD);
                }

                // 升级执行/结束确认
                CS101_ASDU_setCOT(asdu, CS101_COT_ACTIVATION_CON);
                IMasterConnection_sendASDU(connection, asdu);
                InformationObject_destroy(io);
            }
        }
        else
        {
            IEC104_DEBUG_PRINT("ERROR: message has no valid information object\n");
            return true;
        }
    }
    else if (CS101_ASDU_getCOT(asdu) == CS101_COT_DEACTIVATION)
    {
        io = CS101_ASDU_getElement(asdu, 0);

        if (io) // 升级撤销
        {
            // 升级终止
            update_state_set(NONE);
            g_update_start = 0;

            // 升级撤销确认
            CS101_ASDU_setCOT(asdu, CS101_COT_DEACTIVATION_CON);
            IMasterConnection_sendASDU(connection, asdu);
            InformationObject_destroy(io);
        }

        else
        {
            IEC104_DEBUG_PRINT("ERROR: message has no valid information object\n");
            return true;
        }
    }
    return true;
}

/**
 * @brief   遥控指令处理
 * @param   [in] parameter
 * @param   [in] connection
 * @param   [in] asdu
 * @return
 */
static bool remote_control_processing(void *parameter, IMasterConnection connection, CS101_ASDU asdu)
{
    SingleCommand sc = NULL;
    int ioa = 0;
    InformationObject io;
    web_control_info_t *ctrl_info;
    telematic_data_t *p_telematic_data = NULL;
    p_telematic_data = sdk_shm_telematic_data_get();
    internal_shared_data_t *p_internal_data = NULL;

    ctrl_info = shm_web_control_info_get();
    p_internal_data  = internal_shared_data_get();

    io = CS101_ASDU_getElement(asdu, 0);
    sc = (SingleCommand)io;
	ioa = InformationObject_getObjectAddress(io);
    if(ioa == 0x6011)  //远程开关机
    {
        if (SingleCommand_isSelect(sc) == true) // 遥控选择
        {
            IEC104_DEBUG_PRINT("\n******1******\n");  
            CS101_ASDU_setCOT(asdu, CS101_COT_ACTIVATION_CON);
            IMasterConnection_sendASDU(connection, asdu);
        }
        else
        {
            if (SingleCommand_getState(sc))  //开机
            {
                ctrl_info->CMU_system_control_on |= (1 << 0);
            }
            else   //关机
            {
                ctrl_info->CMU_system_control_off |= (1 << 0);
            }
            ctrl_info->energy_saving_power_halt_flag = DISABLE;
            CS101_ASDU_setCOT(asdu, CS101_COT_ACTIVATION_CON);
           // CS101_ASDU_setCOT(asdu, CS101_COT_ACTIVATION_TERMINATION);
            IMasterConnection_sendASDU(connection, asdu);
        }
        InformationObject_destroy(io); 
        return true;
    }
    if(ioa == 0x6013)  //故障复位
    {
        if (SingleCommand_isSelect(sc) == true) // 遥控选择
        {
            IEC104_DEBUG_PRINT("\n******1******\n");   
            CS101_ASDU_setCOT(asdu, CS101_COT_ACTIVATION_CON);
            IMasterConnection_sendASDU(connection, asdu);
        }
        else
        {
            if (SingleCommand_getState(sc))  //故障复位
            {
                memset(p_telematic_data->container_system_fault_info, 0 , 18);
                p_internal_data->fault_reset = ENABLE;  // 通知其他进程/线程执行故障复归
            }
            CS101_ASDU_setCOT(asdu, CS101_COT_ACTIVATION_CON);
         //   CS101_ASDU_setCOT(asdu, CS101_COT_ACTIVATION_TERMINATION);
            IMasterConnection_sendASDU(connection, asdu);
        }
        InformationObject_destroy(io); 
        return true;
    }
    if(ioa == 0x6015)  // 清除历史数据
    {
        if (SingleCommand_isSelect(sc) == true) // 遥控选择
        {
            IEC104_DEBUG_PRINT("\n******6015******\n");  
            CS101_ASDU_setCOT(asdu, CS101_COT_ACTIVATION_CON);
            IMasterConnection_sendASDU(connection, asdu);
        }
        else
        {
            if (SingleCommand_getState(sc))  
            {
                ctrl_info->clear_history_data_flag |= (1 << 0);
            }
            CS101_ASDU_setCOT(asdu, CS101_COT_ACTIVATION_CON);
           // CS101_ASDU_setCOT(asdu, CS101_COT_ACTIVATION_TERMINATION);
            IMasterConnection_sendASDU(connection, asdu);
        }
        InformationObject_destroy(io); 
        return true;
    }
    return false;
}

//添加定值区与参数特征标识
static void param_add_sn_flag(CS101_StaticASDU self,uint16_t sn,uint8_t flag)
{
	IEC104_DEBUG_PRINT("sn=%d,flag=%d\n",sn,flag);
	/*定值区*/
	self->encodedData[self->asduHeaderLength++] = (uint8_t) (sn & 0xff);
	self->encodedData[self->asduHeaderLength++] = (uint8_t) ((sn>>8) & 0xff);
	/*参数特征*/
	self->encodedData[self->asduHeaderLength++] = flag;
	
    self->payload = self->encodedData + self->asduHeaderLength;
    IEC104_DEBUG_PRINT("asduHeaderLength=%d\n",self->asduHeaderLength);
}
/**
 * @brief   读参数处理
 * @param   [in] parameter
 * @param   [in] connection
 * @param   [in] asdu
 * @return
 */
static bool para_read_processing(void *parameter, IMasterConnection connection, CS101_ASDU asdu)
{
    CS101_ASDU newAsdu = NULL;
    InformationObject io = NULL;
    uint8_t i; // 循环使用临时变量
    uint16_t *p_data = NULL;
    uint8_t num = 0;
    int32_t ioa = 0;
    uint8_t *payload;
    uint8_t io_in_asdu;

    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get();
    CS101_AppLayerParameters alParams = IMasterConnection_getApplicationLayerParameters(connection);

    p_data = &(p_para_data->storage_duration_operation_data);
    num = CS101_ASDU_getNumberOfElements(asdu);

    payload = CS101_ASDU_getPayload(asdu);
    io_in_asdu = 0;

    for (i = 0; i < num; i++)
    {
        ioa = payload[2+i*3] + payload[2+i*3+1] * 0x100 + payload[2+i*3+2] * 0x10000;
        
        if((ioa >= SAFETY_PARAM_START_ADDR) && (ioa <= SAFETY_PARAM_END_ADDR))
        {
            p_data = (uint16_t *)(&(p_para_data->safety_param)) + (ioa - SAFETY_PARAM_START_ADDR);
            io = (InformationObject)ParaValue_create(NULL, ioa, *p_data);
        }
        else if((ioa >= PARA_SYS_START_ADDR) && (ioa <= 0x8722))//0x87aa
        {
            p_data = (uint16_t *)(&(p_para_data->storage_duration_operation_data)) + (ioa - PARA_SYS_START_ADDR);
            if((ioa >= 0x8707) && (ioa <= 0x8712))
            {
                io = (InformationObject)ParaValue_create(NULL, ioa, htons(*p_data));
            }
            else
            {
                io = (InformationObject)ParaValue_create(NULL, ioa, *p_data);
            }
        }
		else if(ioa == 0x8723)//下面几个参数，点表中的顺序地址与结构体中的顺序不一样
		{
			p_data = (uint16_t *)(&(p_para_data->soc_charge_limit));
            io = (InformationObject)ParaValue_create(NULL, ioa, *p_data);
		}
		else if(ioa == 0x8724)
		{
			p_data = (uint16_t *)(&(p_para_data->soc_discharge_limit));
            io = (InformationObject)ParaValue_create(NULL, ioa, *p_data);
		}
		else if(ioa == 0x8725)
		{
			p_data = (uint16_t *)(&(p_para_data->bat_cabinet_num));
            io = (InformationObject)ParaValue_create(NULL, ioa, *p_data);
		}
		else if(ioa == 0x8726)
		{
			p_data = (uint16_t *)(&(p_para_data->energy_cabinet_FF_addr));
            io = (InformationObject)ParaValue_create(NULL, ioa, *p_data);
		}
		else if(ioa == 0x8727)
		{
			p_data = (uint16_t *)(&(p_para_data->energy_cabinet_num));
            io = (InformationObject)ParaValue_create(NULL, ioa, *p_data);
		}
		else if(ioa == 0x8728)
		{
			p_data = (uint16_t *)(&(p_para_data->eol_threshold));
            io = (InformationObject)ParaValue_create(NULL, ioa, *p_data);
		}
        else if(ioa == 0x8729)
		{
			p_data = (uint16_t *)(&(p_para_data->iec104_pcs_upload_time));
            io = (InformationObject)ParaValue_create(NULL, ioa, *p_data);
		}
        else if(ioa == 0x872A)
		{
			p_data = (uint16_t *)(&(p_para_data->iec104_bcu_upload_time));
            io = (InformationObject)ParaValue_create(NULL, ioa, *p_data);
		}
        else if(ioa == 0x872B)
		{
			p_data = (uint16_t *)(&(p_para_data->bat_cluster_pack_num));
            io = (InformationObject)ParaValue_create(NULL, ioa, *p_data);
		}
        else if(ioa == 0x872C)
		{
			p_data = (uint16_t *)(&(p_para_data->external_epo_input_type));
            io = (InformationObject)ParaValue_create(NULL, ioa, *p_data);
		}
		else if((ioa >= 0x8741) && (ioa <= 0x8800))
        {
            p_data = (uint16_t *)(&(p_para_data->cluster_curr_diff_warn_threshold_1)) + (ioa - 0x8741);
            io = (InformationObject)ParaValue_create(NULL, ioa, *p_data);
        }
        else if((ioa >= 0x8801) && (ioa <= 0x8900))
        {
            p_data = (uint16_t *)(&(p_para_data->battery_parameter_data[0].ISO_warn_threshold_1)) + (ioa - 0x8801);
            io = (InformationObject)ParaValue_create(NULL, ioa, *p_data);
        }
        else if((ioa >= 0x8901) && (ioa <= 0x8940))
        {
            p_data = (uint16_t *)(&(p_para_data->iec_pcs_parameter_data[0].active_power_ref)) + (ioa - 0x8901);
            io = (InformationObject)ParaValue_create(NULL, ioa, *p_data);
        }
        else
        {
            printf("IOA error\n");
            return false;
        }
        if(io == NULL)
        {
            printf("null pointer io\n");
        }
        if(newAsdu == NULL)
        {
            newAsdu = CS101_ASDU_create(alParams, false, CS101_COT_ACTIVATION_CON,
                                        0, 1, false, false);
            if(newAsdu == NULL)
            {
                printf("create new asdu failed\n");
                return false;
            }
            param_add_sn_flag((CS101_StaticASDU)newAsdu,1,0);
        }
    
        CS101_ASDU_addInformationObject(newAsdu, io);
        InformationObject_destroy(io);
        
        io_in_asdu++;
        if(io_in_asdu >= 25)
        {
            IMasterConnection_sendASDU(connection, newAsdu);
            CS101_ASDU_destroy(newAsdu);
            io_in_asdu = 0;
            newAsdu = NULL;
        }
    }

    if (newAsdu != NULL)
    {
        IMasterConnection_sendASDU(connection, newAsdu);
        CS101_ASDU_destroy(newAsdu);
        newAsdu = NULL;
    }
    return true;
}

/**
 * @brief   写参数处理
 * @param   [in] parameter
 * @param   [in] connection
 * @param   [in] asdu
 * @return
 */
static bool para_write_processing(void *parameter, IMasterConnection connection, CS101_ASDU asdu)
{
    CS101_ASDU newAsdu = NULL;
    InformationObject io = NULL;
    // ParaValue iom = NULL;
    uint8_t i = 0; // 循环使用临时变量
    // uint8_t k = 0, j = 0; // 循环使用临时变量
    // uint8_t destroy_flag = 0;
    // uint16_t *p_data = NULL;
    uint16_t value = 0;
    int addrs = 0;
    uint8_t index = 0;
    uint8_t num = 0;
    // uint8_t state = 0;
    // uint32_t bat_flag = 0;
    // uint8_t offset = 0;
    bool flag = 0;

    para_value_record_t *p_para_value_record = &g_para_value_record;
    // constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get();
    CS101_AppLayerParameters alParams = IMasterConnection_getApplicationLayerParameters(connection);
    // CS101_AppLayerParameters alParams = IMasterConnection_getApplicationLayerParameters(connection);

    if (CS101_ASDU_getCOT(asdu) == CS101_COT_ACTIVATION)
    {
        num = CS101_ASDU_getNumberOfElements(asdu);
        flag = CS101_ASDU_isSequence(asdu);
        IEC104_DEBUG_PRINT("num = %x\n", num);
        if ((num == 0) && (flag == 0))
        {
            IEC104_DEBUG_PRINT("\n********para save*********\n");
            para_change_synch();
            CS101_ASDU_setCOT(asdu, CS101_COT_ACTIVATION_CON);
            IMasterConnection_sendASDU(connection, asdu);
        }
        else
        {
            IEC104_DEBUG_PRINT("\n********para pre*********\n");
            memset(p_para_value_record, 0, sizeof(para_value_record_t));
            // 预置写参数
            for (i = 0; i < num; i++)
            {
                InformationObject io = CS101_ASDU_getElement(asdu, i);
                IEC104_DEBUG_PRINT("\n CS101_ASDU_getElement num = %x\n", i);
                if (io)
                {
                    addrs = InformationObject_getObjectAddress(io);
                    if ((addrs >= PARA_SYS_START_ADDR) && (addrs < (PARA_SYS_START_ADDR + 0x1000)))
                    {
                        value = ParaValue_getValue((ParaValue)io);
                        index = p_para_value_record->num;
                        p_para_value_record->para_value[index].addr = addrs;
                        p_para_value_record->para_value[index].value = value;
                        p_para_value_record->num++;
                    }
                    else if ((addrs >= SAFETY_PARAM_START_ADDR) && (addrs <= (SAFETY_PARAM_END_ADDR)))
                    {
                        value = ParaValue_getValue((ParaValue)io);
                        index = p_para_value_record->num;
                        p_para_value_record->para_value[index].addr = addrs;
                        p_para_value_record->para_value[index].value = value;
                        p_para_value_record->num++;
                    }

#if 0
                    // 为方便调试增加代码 临时
                    else if (addrs == 0x8000)
                    {
                        value = ParaValue_getValue((ParaValue)io);
                        newAsdu = CS101_ASDU_create(alParams, false, CS101_COT_ACTIVATION_CON,
                                                    0, 1, false, false);
                        CS101_ASDU_setSequence(newAsdu, 0);
                        io = (InformationObject)ParaValueSet_create(NULL, 0, 0);
                        CS101_ASDU_addInformationObject(newAsdu, io);
                        CS101_ASDU_setCOT(newAsdu, CS101_COT_ACTIVATION_CON);
                        IMasterConnection_sendASDU(connection, newAsdu);
                        InformationObject_destroy(io);

                        yc_data_update_test(value, g_slave, g_alParams);
                        g_other_respone = 0;
                        return true;
                    }
#endif
                    else
                    {
                        newAsdu = CS101_ASDU_create(alParams, false, CS101_COT_ACTIVATION_CON,
                                                    0, 1, false, false);
                        CS101_ASDU_setSequence(newAsdu, 0);
                        io = (InformationObject)ParaValueSet_create(NULL, 0, 0);
                        CS101_ASDU_addInformationObject(newAsdu, io);
                        CS101_ASDU_setCOT(newAsdu, CS101_COT_UNKNOWN_IOA);
                        IMasterConnection_sendASDU(connection, newAsdu);
                        InformationObject_destroy(io);
                    }
                }
                else
                {
                    g_other_respone = 0;
                    IEC104_DEBUG_PRINT("ERROR: message has no valid information object i = %x\n", i);
                    return true;
                }
            }

            newAsdu = CS101_ASDU_create(alParams, false, CS101_COT_ACTIVATION_CON,
                                        0, 1, false, false);
            CS101_ASDU_setSequence(newAsdu, 0);
            io = (InformationObject)ParaValueSet_create(NULL, 0, 0);
            CS101_ASDU_addInformationObject(newAsdu, io);
            CS101_ASDU_setCOT(newAsdu, CS101_COT_ACTIVATION_CON);
            IMasterConnection_sendASDU(connection, newAsdu);
            InformationObject_destroy(io);
        }
    }
    else if (CS101_ASDU_getCOT(asdu) == CS101_COT_DEACTIVATION)
    {
        // 参数撤销
        IEC104_DEBUG_PRINT("\n********参数撤销*********\n");
        memset(p_para_value_record, 0, sizeof(para_value_record_t));
        CS101_ASDU_setCOT(asdu, CS101_COT_DEACTIVATION_CON);
        IMasterConnection_sendASDU(connection, asdu);
    }
    else
    {
        IEC104_DEBUG_PRINT("\n********未识别*********\n");
        CS101_ASDU_setCOT(asdu, CS101_COT_UNKNOWN_COT);
        IMasterConnection_sendASDU(connection, asdu);
    }
    g_other_respone = 0;
    return true;
}

#if 1
/**
 * @brief  遥测数据客户端主动获取片理函数
 * @param   
 * @note    
 * @return  1-成功，0-失败原因
 */
static bool telemetry_read_processing(void *parameter, IMasterConnection connection, CS101_ASDU asdu)
{
    uint8_t num;
    uint8_t i;
    int32_t ioa = 0;
    uint8_t *payload;
    int16_t *p_data;
    CS101_ASDU newAsdu = NULL;
    InformationObject io = NULL;
    telemetry_data_t *p_telemetry_data = NULL;
    internal_version_info_t *p_ver = internal_version_info_get();

    CS101_AppLayerParameters alParams = IMasterConnection_getApplicationLayerParameters(connection);
    num = CS101_ASDU_getNumberOfElements(asdu);  //读取有多少个数据
    payload = CS101_ASDU_getPayload(asdu);
   
    p_telemetry_data = sdk_shm_telemetry_data_get();

    for(i=0; i<num; i++)
    {
        if(newAsdu == NULL)
        {
            newAsdu = CS101_ASDU_create(alParams, false, CS101_COT_ACTIVATION_CON,
                                                0, 1, false, false);
            if(newAsdu == NULL)
            {
                printf("CS101_ASDU_create failed\n");
                return false;
            }
        }
        ioa = payload[2+i*3] + (payload[2+i*3+1] << 8) + (payload[2+i*3+2] << 16);
        //printf("read measure data,ios=%x\n", ioa);

        if((ioa >= YC_CMU_START_ADDR) && (ioa < (YC_CMU_START_ADDR + 16)))  //储能柜 (地址范围0x4301~0x4310)
        {
            uint16_t ver_data;

            if(ioa == YC_CMU_START_ADDR)
            {
                ver_data = (p_ver->mcu1_hardware_version[1] << 8) | p_ver->mcu1_hardware_version[0];
            }
            else if(ioa == YC_CMU_START_ADDR+1)
            {//  MCU1 Software Version (Low 16 Bits)
                ver_data = (p_ver->mcu1_app_soft_version[1] << 8) | p_ver->mcu1_app_soft_version[0];
            }
            else if(ioa == YC_CMU_START_ADDR+2)
            {// MCU1 Software Version (hight 16 Bits)
                ver_data = (p_ver->mcu1_app_soft_version[3] << 8) | p_ver->mcu1_app_soft_version[2];
            }
            else if(ioa == YC_CMU_START_ADDR+3)
            { // MCU1 boot Version (Low 16 Bits)
                ver_data = 0x156;
            }
            else if(ioa == YC_CMU_START_ADDR+4)
            { // MCU1 boot Version (High 16 Bits)
                ver_data = 257;
            }
            else if(ioa == YC_CMU_START_ADDR+5)
            { //  MCU1 Core Version (Low 16 Bits)
                ver_data = (p_ver->mcu1_core_soft_version[1] << 8) | p_ver->mcu1_core_soft_version[0];
            }
            else if(ioa == YC_CMU_START_ADDR+6)
            { //  MCU1 Core Version (high 16 Bits)
                ver_data = (p_ver->mcu1_core_soft_version[3] << 8) | p_ver->mcu1_core_soft_version[2];
            }
            else if(ioa == YC_CMU_START_ADDR+7)
            { //  MCU2 Software Version (Low 16 Bits)
                ver_data = (p_ver->mcu2_app_soft_version[1] << 8) | p_ver->mcu2_app_soft_version[0];
            }
            else if(ioa == YC_CMU_START_ADDR+8)
            { //  MCU2 Software Version (high 16 Bits)
                ver_data = (p_ver->mcu2_app_soft_version[3] << 8) | p_ver->mcu2_app_soft_version[2];
            }
            else if(ioa == YC_CMU_START_ADDR+9)
            { //   MCU2 boot Version (Low 16 Bits)
                ver_data = 0;
            }
            else if(ioa == YC_CMU_START_ADDR+10)
            { //   MCU2 boot Version (high 16 Bits)
                ver_data = 0;
            }
            else if(ioa == YC_CMU_START_ADDR+11)
            { //   MCU2 Core Version (Low 16 Bits)
                ver_data = (p_ver->mcu2_core_soft_version[1] << 8) | p_ver->mcu2_core_soft_version[0];
            }
            else if(ioa == YC_CMU_START_ADDR+12)
            { //   MCU2 Core Version (high 16 Bits)
                ver_data = (p_ver->mcu2_core_soft_version[3] << 8) | p_ver->mcu2_core_soft_version[2];
            }
            else if(ioa == YC_CMU_START_ADDR+13)
            { //   通信协议版本号
                ver_data = SCI_VERTION1;
            }
            else if(ioa == YC_CMU_START_ADDR+14)
            { //   系统状态
                ver_data = p_telemetry_data->cmu_telemetry_info.cmu_sys_state;
            }
            else if(ioa == YC_CMU_START_ADDR+15)
            { //   消防控制器软件版本号
                ver_data = (p_ver->ff_software_version[1] << 8) | p_ver->ff_software_version[0];
            }
            else
            { //预留部分
                ver_data = 0;
            }
            p_data = (int16_t*)&ver_data;
            io = (InformationObject)MeasuredValueShort_create(NULL, ioa, *p_data, IEC60870_QUALITY_GOOD);
            CS101_ASDU_addInformationObject(newAsdu, io);
            InformationObject_destroy(io);
        }

        if((ioa >= YC_CMU_START_ADDR + 16 ) && (ioa < YC_SYS_START_ADDR - 1))  //储能柜 (地址范围0x4311~0x431D)
        {
            p_data = (int16_t *)(p_ver->dev_sn) + (ioa - YC_CMU_START_ADDR - 16);

            io = (InformationObject) MeasuredValueShort_create(NULL, ioa, htons(*(p_data)), IEC60870_QUALITY_GOOD);
            CS101_ASDU_addInformationObject(newAsdu, io);
            InformationObject_destroy(io);
        }

        if((ioa >= YC_SYS_START_ADDR) && (ioa < (YC_SYS_START_ADDR + 0x4C)))  //CMU+集装箱信息16位部分
        {
            p_data = (int16_t *)(&p_telemetry_data->container_system_telemetry_info.soc) + (ioa - YC_SYS_START_ADDR);

            io = (InformationObject)MeasuredValueShort_create(NULL, ioa, *p_data, IEC60870_QUALITY_GOOD);
            CS101_ASDU_addInformationObject(newAsdu, io);
            InformationObject_destroy(io);
        }

        #if 1
        if((ioa >= 0x4401) && (ioa <= 0x4E00))  //第1簇电池信息
        {
            p_data = (int16_t *)(&(p_telemetry_data->battery_cluster_telemetry_info[0].software_version)) + (ioa - 0x4401);
            io = (InformationObject)MeasuredValueShort_create(NULL, ioa, *p_data, IEC60870_QUALITY_GOOD);
            CS101_ASDU_addInformationObject(newAsdu, io);
            InformationObject_destroy(io);
        }
        #endif
        if((ioa >= 0xA401) && (ioa <= 0xAE00))  //第2簇电池信息
        {
            p_data = (int16_t *)(&(p_telemetry_data->battery_cluster_telemetry_info[1].software_version)) + (ioa - 0xA401);
            io = (InformationObject)MeasuredValueShort_create(NULL, ioa, *p_data, IEC60870_QUALITY_GOOD);
            CS101_ASDU_addInformationObject(newAsdu, io);
            InformationObject_destroy(io);
        }
        if((ioa >= 0xB401) && (ioa <= 0xBE00))  //第3簇电池信息
        {
            p_data = (int16_t *)(&(p_telemetry_data->battery_cluster_telemetry_info[2].software_version)) + (ioa - 0xB401);
            io = (InformationObject)MeasuredValueShort_create(NULL, ioa, *p_data, IEC60870_QUALITY_GOOD);
            CS101_ASDU_addInformationObject(newAsdu, io);
            InformationObject_destroy(io);
        }
        if((ioa >= 0xC401) && (ioa <= 0xCE00))  //第4簇电池信息
        {
            p_data = (int16_t *)(&(p_telemetry_data->battery_cluster_telemetry_info[3].software_version)) + (ioa - 0xC401);
            io = (InformationObject)MeasuredValueShort_create(NULL, ioa, *p_data, IEC60870_QUALITY_GOOD);
            CS101_ASDU_addInformationObject(newAsdu, io);
            InformationObject_destroy(io);
        }
        if((ioa >= 0xD401) && (ioa <= 0xDE00))  //第5簇电池信息(预留)
        {
            p_data = (int16_t *)(&(p_telemetry_data->battery_cluster_telemetry_info[4].software_version)) + (ioa - 0xD401);
            io = (InformationObject)MeasuredValueShort_create(NULL, ioa, *p_data, IEC60870_QUALITY_GOOD);
            CS101_ASDU_addInformationObject(newAsdu, io);
            InformationObject_destroy(io);
        }
        if((ioa >= 0xE401) && (ioa <= 0xEE00))  //第6簇电池信息(预留)
        {
            p_data = (int16_t *)(&(p_telemetry_data->battery_cluster_telemetry_info[5].software_version)) + (ioa - 0xE401);
            io = (InformationObject)MeasuredValueShort_create(NULL, ioa, *p_data, IEC60870_QUALITY_GOOD);
            CS101_ASDU_addInformationObject(newAsdu, io);
            InformationObject_destroy(io);
        }
        // if(ioa >= 0xD401 && ioa <= 0xDE00)  //第6簇电池信息(预留)
        // {
        //     p_data = (int16_t *)(&(p_telemetry_data->battery_cluster_telemetry_info[6].software_version)) + (ioa - 0xD401);
        //     io = (InformationObject)MeasuredValueShort_create(NULL, ioa, *p_data, IEC60870_QUALITY_GOOD);
        //     CS101_ASDU_addInformationObject(newAsdu, io);
        //     InformationObject_destroy(io);
        // }
        if((ioa >= 0xEE01) && (ioa <= (0xEE01 + 0x1A)))  //PCS功率模块数据,从电网线电压RS~T相视在功率
        {
            p_data = (int16_t *)(&(p_telemetry_data->power_module_telemetry_info[0].grid_volt_rs)) + (ioa - 0xEE01);
            io = (InformationObject)MeasuredValueShort_create(NULL, ioa, *p_data, IEC60870_QUALITY_GOOD);
            CS101_ASDU_addInformationObject(newAsdu, io);
            InformationObject_destroy(io);
        }
        if((ioa >= (0xEE01 + 0x32)) && (ioa <= (0xEE01 + 0x4F)))  //PCS功率模块数据,从电网相电压R~模块累计充电量高16位
        {
            p_data = (int16_t *)(&(p_telemetry_data->power_module_telemetry_info[0].grid_volt_r)) + (ioa - (0xEE01 + 0x32));
            io = (InformationObject)MeasuredValueShort_create(NULL, ioa, *p_data, IEC60870_QUALITY_GOOD);
            CS101_ASDU_addInformationObject(newAsdu, io);
            InformationObject_destroy(io);
        }
        if((ioa >= (0xEE01 + 0x64)) && (ioa <= (0xEE01 + 0x66)))  //PCS功率模块数据,直流侧电流-->
        {
            p_data = (int16_t *)(&(p_telemetry_data->power_module_telemetry_info[0].bat_current)) + (ioa - (0xEE01 + 0x64));
            io = (InformationObject)MeasuredValueShort_create(NULL, ioa, *p_data, IEC60870_QUALITY_GOOD);
            CS101_ASDU_addInformationObject(newAsdu, io);
            InformationObject_destroy(io);
        }
        if((ioa >= 0xEEB1) && (ioa <= 0xEEBA))  //PCS功率模块版本信息,截至到遗留字段之前
        {
            //这里对SN进行大小端转换
            uint16_t pcs_sn[10] = {0};
            for(uint8_t j = 0; j < 10; j++)
            {
                pcs_sn[j] = htons(p_telemetry_data->pcs_module_version_telemetry_info[0].sn[j]);
            }
            p_data = (int16_t *)(&pcs_sn[0]) + (ioa - 0xEEB1);
            io = (InformationObject)MeasuredValueShort_create(NULL, ioa, *p_data, IEC60870_QUALITY_GOOD);
            CS101_ASDU_addInformationObject(newAsdu, io);
            InformationObject_destroy(io);
        }
        if((ioa >= 0xEEBB) && (ioa <= 0xEEC4))  //PCS功率模块版本信息,截至到遗留字段之前
        {
            p_data = (int16_t *)(&(p_telemetry_data->pcs_module_version_telemetry_info[0].fw_version[0])) + (ioa - 0xEEBB);
            io = (InformationObject)MeasuredValueShort_create(NULL, ioa, *p_data, IEC60870_QUALITY_GOOD);
            CS101_ASDU_addInformationObject(newAsdu, io);
            InformationObject_destroy(io);
        }

        if((ioa >= 0xEEE3) && (ioa <= 0xEEEB))  //PCS功率模块版本信息,遗留字段之后
        {
            p_data = (int16_t *)(&(p_telemetry_data->pcs_module_version_telemetry_info[0].slv_fw_version[0])) + (ioa - 0xEEE3);
            io = (InformationObject)MeasuredValueShort_create(NULL, ioa, *p_data, IEC60870_QUALITY_GOOD);
            CS101_ASDU_addInformationObject(newAsdu, io);
            InformationObject_destroy(io);
        }
        /*使用遥测数据传递遥信*/
        if((ioa >= 0x1) && (ioa <= 0x200))
        {
            //上传CMU+集装箱状态信息+集装箱告警信息+集装箱故障信息
            telematic_data_t *p_telematic_data;
            uint16_t state_data;
            uint8_t *p_data8;
            
            p_telematic_data = sdk_shm_telematic_data_get();

            p_data8 = (uint8_t *)(&p_telematic_data->CMU_system_fault_info[0]) + (ioa - 0x1)*2;
			
            state_data = ((uint16_t)(p_data8[1]) << 8) + p_data8[0];

            io = (InformationObject)MeasuredValueShort_create(NULL, ioa, state_data, IEC60870_QUALITY_GOOD);
            CS101_ASDU_addInformationObject(newAsdu, io);
            InformationObject_destroy(io);
        }

        if(((i % 25) == 0) && (i != 0))
        {
            IMasterConnection_sendASDU(connection, newAsdu);
            CS101_ASDU_destroy(newAsdu);
            newAsdu = NULL;
        }
        ///
    }
    if(newAsdu != NULL)
    { 
        IMasterConnection_sendASDU(connection, newAsdu);
        CS101_ASDU_destroy(newAsdu);
    }
    
    return true;
}

static bool telematic_read_processing(void *parameter, IMasterConnection connection, CS101_ASDU asdu)
{
    uint8_t num;
    uint8_t i;
    int32_t ioa = 0;
    uint8_t *payload;
    uint8_t value;
    int32_t ioa_offset1, ioa_offset2;
    uint8_t *p_data = NULL;
    telematic_data_t *p_telematic_data = NULL;

    CS101_ASDU newAsdu = NULL;
    InformationObject io = NULL;

    CS101_AppLayerParameters alParams = IMasterConnection_getApplicationLayerParameters(connection);
    num = CS101_ASDU_getNumberOfElements(asdu);  //读取有多少个数据
    payload = CS101_ASDU_getPayload(asdu);
   
    p_telematic_data = sdk_shm_pcs_telematic_data_get();
    p_data = (uint8_t *)(&p_telematic_data->CMU_system_fault_info[0]);

    for(i=0; i<num; i++)
    {
        if(newAsdu == NULL)
        {
            newAsdu = CS101_ASDU_create(alParams, false, CS101_COT_ACTIVATION_CON,
                                                0, 1, false, false);
            if(newAsdu == NULL)
            {
                printf("CS101_ASDU_create failed\n");
                return false;
            }
        }
        ioa = payload[2+i*3] + (payload[2+i*3+1] << 8) + (payload[2+i*3+2] << 16);

        ioa_offset1 = ioa/8;
        ioa_offset2 = ioa%8;
        if(ioa >= YX_SYS_START_ADDR && ioa <= YX_PCS_MODULE_END_ADDR)
        {
            value = (*(p_data + ioa_offset1) >> ioa_offset2) & 0x01;
            io = (InformationObject)SinglePointInformation_create(NULL, ioa, value, IEC60870_QUALITY_GOOD);
            
            CS101_ASDU_addInformationObject(newAsdu, io);
            InformationObject_destroy(io);
        }
        else
        {
            io = (InformationObject)SinglePointInformation_create(NULL, ioa, 0, IEC60870_QUALITY_GOOD);
            
            CS101_ASDU_addInformationObject(newAsdu, io);
            InformationObject_destroy(io);
        }

        if(((i % 25) == 0) && (i != 0))
        {
            IMasterConnection_sendASDU(connection, newAsdu);
            CS101_ASDU_destroy(newAsdu);
            newAsdu = NULL;
        }
    }

    if(newAsdu != NULL)
    { 
        IMasterConnection_sendASDU(connection, newAsdu);
        CS101_ASDU_destroy(newAsdu);
    }
    
    return true;
}
#endif

static bool asduHandler(void *parameter, IMasterConnection connection, CS101_ASDU asdu)
{
    IEC104_DEBUG_PRINT("RECVD ASDU type: %s(%i) elements: %i\n",
                       TypeID_toString(CS101_ASDU_getTypeID(asdu)),
                       CS101_ASDU_getTypeID(asdu),
                       CS101_ASDU_getNumberOfElements(asdu));

    if (CS101_ASDU_getTypeID(asdu) == P_SC_RD_1)    // 读取参数
    {
        IEC104_DEBUG_PRINT("\n measured scaled values  P_SC_RD_1: \n");

        para_read_processing(parameter, connection, asdu);
    }
    else if (CS101_ASDU_getTypeID(asdu) == P_SC_WT_1)   // 写参数
    {
        IEC104_DEBUG_PRINT("  single point information (P_SC_WT_1):\n");
        para_write_processing(parameter, connection, asdu);
    }
    #if 1
    else if (CS101_ASDU_getTypeID(asdu) == M_ME_NC_1) //13---上位机主动读取遥测数据
    {
        IEC104_DEBUG_PRINT("read telemetry datas(M_ME_NC_1):\n");
        telemetry_read_processing(parameter, connection, asdu);  //读取遥测信息
    }
    else if (CS101_ASDU_getTypeID(asdu) == M_SP_NA_1)   // 单点遥信
    {
        IEC104_DEBUG_PRINT("read telematic datas(M_SP_NA_1):\n");
        telematic_read_processing(parameter, connection, asdu);  //读取遥信信息
    }
    #endif
    else if (CS101_ASDU_getTypeID(asdu) == C_SC_NA_1)   // 遥控数据
    {
        IEC104_DEBUG_PRINT("received single command\n");

        remote_control_processing(parameter, connection, asdu);
    }
    else if (CS101_ASDU_getTypeID(asdu) == F_FR_NA_2)   // 文件传输
    {
        IEC104_DEBUG_PRINT("   event of protection equipment (F_FR_NA_2):\n");
        file_processing(parameter, connection, asdu);
    }
    else if (CS101_ASDU_getTypeID(asdu) == F_FU_NA_1)   // 升级
    {
        IEC104_DEBUG_PRINT("received single command\n");

        // 升级处理
        update_processing(parameter, connection, asdu);
    }
    else
    {
        // 异常功能码
        CS101_ASDU_setCOT(asdu, CS101_COT_UNKNOWN_COT);
        IMasterConnection_sendASDU(connection, asdu);
    }

    return true;
}

static bool
connectionRequestHandler(void *parameter, const char *ipAddress)
{
    IEC104_DEBUG_PRINT("New connection request from %s\n", ipAddress);

#if 0
    if (strcmp(ipAddress, "127.0.0.1") == 0) {
        IEC104_DEBUG_PRINT("Accept connection\n");
        return true;
    }
    else {
        IEC104_DEBUG_PRINT("Deny connection\n");
        return false;
    }
#else
    return true;
#endif
}

static void
connectionEventHandler(void *parameter, IMasterConnection con, CS104_PeerConnectionEvent event)
{
    IEC104_DEBUG_PRINT("\n connectionEventHandler \n");
    if (event == CS104_CON_EVENT_CONNECTION_OPENED)
    {
        IEC104_DEBUG_PRINT("Connection opened (%p)\n", con);
       // g_connect_flag = 0;
    }
    else if (event == CS104_CON_EVENT_CONNECTION_CLOSED)
    {
        IEC104_DEBUG_PRINT("Connection closed (%p)\n", con);
      //  g_connect_flag = 0;
    }
    else if (event == CS104_CON_EVENT_ACTIVATED)
    {
        IEC104_DEBUG_PRINT("Connection activated (%p)\n", con);
    }
    else if (event == CS104_CON_EVENT_DEACTIVATED)
    {
        IEC104_DEBUG_PRINT("Connection deactivated (%p)\n", con);
       // g_connect_flag = 0;
    }
    
}

/**
 * @brief   iec104 从机功能（ETH）任务
 * @param
 * @note
 * @return
 */
void *thread_iec104_slave(void *arg)
{
    static uint8_t tick_cnt = 0;
    /* create a new slave/server instance with default connection parameters and
     * default message queue size */
    CS104_Slave slave = CS104_Slave_create(500, 200);

    CS104_Slave_setLocalAddress(slave, "0.0.0.0"); //Jhon 2023.8.16设置监听ip地址为0.0.0.0表示监听在本地所有网络接口上
    CS104_Slave_setLocalPort(slave, 2404);

    /* Set mode to a single redundancy group
     * NOTE: library has to be compiled with CONFIG_CS104_SUPPORT_SERVER_MODE_SINGLE_REDUNDANCY_GROUP enabled (=1)
     */
    CS104_Slave_setServerMode(slave, CS104_MODE_SINGLE_REDUNDANCY_GROUP);

    /* get the connection parameters - we need them to create correct ASDUs -
     * you can also modify the parameters here when default parameters are not to be used */
    CS101_AppLayerParameters alParams = CS104_Slave_getAppLayerParameters(slave);
    g_alParams = alParams;
    g_slave = slave;

    Lib60870_enableDebugOutput(0);

    IEC104_DEBUG_PRINT("\n CS101_AppLayerParameters:\n");
    IEC104_DEBUG_PRINT(" sizeOfTypeId:%i  sizeOfVSQ:%i  sizeOfCOT:%i  originatorAddress:%i\n", alParams->sizeOfTypeId, alParams->sizeOfVSQ, alParams->sizeOfCOT, alParams->originatorAddress);
    IEC104_DEBUG_PRINT(" sizeOfCA:%i  sizeOfIOA:%i  maxSizeOfASDU:%i\n", alParams->sizeOfCA, alParams->sizeOfIOA, alParams->maxSizeOfASDU);

    /* when you have to tweak the APCI parameters (t0-t3, k, w) you can access them here */
    CS104_APCIParameters apciParams = CS104_Slave_getConnectionParameters(slave);

    IEC104_DEBUG_PRINT("\n APCI parameters:\n");
    IEC104_DEBUG_PRINT(" t0:%i  t1:%i  t2:%i  t3:%i\n", apciParams->t0, apciParams->t1, apciParams->t2, apciParams->t3);
    IEC104_DEBUG_PRINT(" k:%i  w:%i\n", apciParams->k, apciParams->w);

    /* set the callback handler for the clock synchronization command */
    CS104_Slave_setClockSyncHandler(slave, clockSyncHandler, NULL);

    /* set the callback handler for the interrogation command */
    CS104_Slave_setInterrogationHandler(slave, interrogationHandler, NULL);

    // /* set handler for other message types */
    CS104_Slave_setASDUHandler(slave, asduHandler, NULL);

    /* set handler to handle connection requests (optional) */
    CS104_Slave_setConnectionRequestHandler(slave, connectionRequestHandler, NULL);

    /* set handler to track connection events (optional) */
    CS104_Slave_setConnectionEventHandler(slave, connectionEventHandler, NULL);

    /* uncomment to log messages */
    CS104_Slave_setRawMessageHandler(slave, rawMessageHandler, NULL);

    CS104_Slave_start(slave);

    IEC104_DEBUG_PRINT("\n self->isStarting3 = %x\n", CS104_Slave_isRunning(slave));

    if (CS104_Slave_isRunning(slave) == false)
    {
        IEC104_DEBUG_PRINT("Starting server failed!\n");
        goto exit_program;
    }

    while (1)
    {
        // 如果已经开启总召唤，则开始主动上报
        if ( sdk_shm_other_parameter_data_get()->iec104_upload_enable == 1 )
        {
            telematic_data_upload(CS101_COT_PERIODIC, 0);
            if(tick_cnt >= 30)
            {
                telematic_data_upload(CS101_COT_PERIODIC, 1);
                tick_cnt = 0;
            }
            tick_cnt++;
        }
        sleep(1);
    }

    CS104_Slave_stop(slave);

exit_program:
    CS104_Slave_destroy(slave);
    pthread_exit(NULL);
}

static void *telemetry_general_pcs_upload(void *arg) 
{
    uint8_t i;
    uint8_t delay_time = 0;
    constant_parameter_data_t *p_constant_param = NULL;
    p_constant_param = sdk_shm_constant_parameter_data_get();

    while(1)
    {
        delay_time = (p_constant_param->iec104_pcs_upload_time > 1 ? p_constant_param->iec104_pcs_upload_time : 1);
        if ( sdk_shm_other_parameter_data_get()->iec104_upload_enable == 1 )
        {
            for(i = 0; i < p_constant_param->bat_cabinet_num; i++)
            {
                telemetry_general_data_upload(CS101_COT_PERIODIC, i);
            }
            telemetry_constant_param_upload(CS101_COT_PERIODIC, 0);
            telemetry_pcs_data_upload(CS101_COT_PERIODIC);
        }
        sleep(delay_time);
    } 
    return NULL;
}

static void *telemetry_detail_upload(void *arg) 
{
    uint8_t i;
    uint8_t j;
    uint8_t delay_time = 0;
    constant_parameter_data_t *p_constant_param = NULL;

    p_constant_param = sdk_shm_constant_parameter_data_get();

    while(1)
    {
        delay_time = (p_constant_param->iec104_pcs_upload_time > 3 ? p_constant_param->iec104_bcu_upload_time : 3);
        if ( sdk_shm_other_parameter_data_get()->iec104_upload_enable == 1 )
        {
            for(i = 0; i < p_constant_param->bat_cabinet_num; i++)
            {
                for(j = 0; j < p_constant_param->bat_cluster_pack_num; j++)
                {
                    telemetry_detail_data_upload(CS101_COT_PERIODIC, i, j);
                    usleep(300 * 1000);
                }
            } 
        }
        sleep(delay_time);
    }
    return NULL;
}


/**
 * @brief   iec104 从机功能（ETH）任务启动
 * @param
 * @note  创建任务，处理总召唤和遥信数据
 * @return
 */
void iec104_slave_task_start(void)
{
    pthread_t iec104_slave;
    pthread_t telemetry_general_pcs_tid;
    pthread_t telemetry_detail_tid;
    int32_t ret = 0;
    pthread_attr_t attr;

    // 初始化线程属性
    ret = pthread_attr_init(&attr);
    if (ret != 0)
    {
        log_i((int8_t *)"\n pthread_attr_init: ");
    }
	//设置线程属性为分离状态
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);

    // 创建线程
    pthread_create(&iec104_slave, &attr, &thread_iec104_slave, NULL);
    //此处加延时，等g_alParams完成初始化
    sleep(3);
    pthread_create(&telemetry_general_pcs_tid, &attr, &telemetry_general_pcs_upload, NULL);
    pthread_create(&telemetry_detail_tid, &attr, &telemetry_detail_upload, NULL);
    if (ret != 0)
    {
        log_i((int8_t *)"\n pthread_create: ");
    }

    // 销毁线程属性
    pthread_attr_destroy(&attr);    
}
