#ifndef __FUNCTION_HANDLE_H__
#define __FUNCTION_HANDLE_H__

#include "data_types.h"
#include "cs104_slave.h"
#include "data_shm.h"
#include "sdk_public.h"
#include "iec104_slave.h"

/**
 * @brief   参数变更同步
 * @param   
 * @note   参数发生变化，将参数同步更新到共享内存
 * @return
 */
int32_t para_change_synch();

/**
 * @brief   参数变更同步
 * @param   [in] newTime
 * @note   参数发生变化，将参数同步更新到共享内存
 * @return
 */
int32_t system_time_update(CP56Time2a newTime);

/**
 * @brief   故障信号复归
 * @param   
 * @note   遥控指令“故障复归”激活时调用该函数
 * @return
 */
void fault_reset(void);

/**
 * @brief  升级状态设置
 * @param  [in] state // 0-无; 1-下载; 2-升级; 3-升级中; 4-触发U盘; 5-升级失败
 * @note   NONE=0, DOWNLOAD=1, UPDATE=2, UPDATING=3, UDISK=4, FAIL=5
 * @return
 */
void update_state_set(inform_e state);

/**
 * @brief   newTime转换成RTCtime
 * @param   [in] newTime
 * @param   [in] RTCtine
 * @note   
 * @return
 */
void new2rtc_time_change(CP56Time2a newTime, sdk_rtc_t *p_rtc_time);

/**
 * @brief  获取文件目录
 * @param  [in] p_name 文件目录名称
 * @param  [in] len 文件目录名称长度
 * @param  [in] sign 文件读取范围 0读取所有；1读取搜索时间范围内
 * @param  [in] start_time 查询起始时间
 * @param  [in] stop_time 查询结束时间
 * @param  [out] p_file_directory_con 文件目录
 * @note   
 * @return
 */
int32_t file_identify_get(int8_t *p_name, uint8_t len, uint8_t sign, CP56Time2a start_time, CP56Time2a stop_time, file_directory_con_t *p_file_directory_con);

/**
 * @brief  读文件激活确认
 * @param  [in] asdu 文件名称
 * @param  [out] p_file_activate_con 文件激活确认
 * @note   
 * @return 0 成功，1 未知错误，2 文件名不支持
 */
int32_t file_activate_con_get(FileIdentify asdu, file_activate_con_t *p_file_activate_con);

/**
 * @brief  设置文件具体内容
 * @param  [in] asdu 文件名称
 * @param  [out] p_file_data_trs_con 文件传输确认
 * @note   
 * @return
 */
int32_t file_data_trs_set(FileIdentify asdu, file_data_trs_con_t *p_file_data_trs_con);

/**
 * @brief  iec104预设安规参数
 * @param  [in] iec104_addr ： 104参数地址
 * @param  [in] val         ： 内容
 * @note   
 * @return
 */
void iec104_safety_pre_set( uint16_t iec104_addr, uint16_t val );

/**
 * @brief  iec104安规参数同步
 * @param  [in] 无
 * @note   
 * @return
 */
void iec104_safety_start_sync( void );

#endif