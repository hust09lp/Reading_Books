/** 
 * @file          battery_fun_interface.h
 * @brief         电池通信功能外部接口
 * @author        xiaojuying
 * @note
 * @version       V0.0.1     初版
 * @date          2023/2/8
 */

#ifndef __BATTERY_FUN_INTERFACE_H__
#define __BATTERY_FUN_INTERFACE_H__


#include "data_types.h"
#include "data_shm.h"

#define OBJ_BATTERY_MASTER_VERSION          (0x01)      // 电池版本号查询对象-主控
#define OBJ_BATTERY_SLAVE_VERSION           (0x02)      // 电池版本号查询对象-从控


// Type of control command
typedef enum{
    POWER_ON                = 1,  // 上电
    POWER_OFF               = 2,  // 下电
    FAULT_POWER_OFF_ALL     = 3,  // 所有簇故障下电
    CONTROL_COMMAND_TYPE_MAX,
}control_command_type_e;

// device priority
typedef enum{
    PRIO_HIGHEST        = 0,
    PRIO_SECOND_HIGH    = 1,
    PRIO_THIRD_HIGH     = 2,
    PRIO_FOURTH_HIGH    = 3,
    PRIO_FOURTH_LOW     = 4,
    PRIO_THIRD_LOW      = 5,
    PRIO_SECOND_LOW     = 6,
    PRIO_LOWEST         = 7,
}can_fun_prio_e;

// 电池单体数据的信息类型
typedef enum{
    BATTERY_MONOMER_VOL = 0x01,     // 电池单体电压
    BATTERY_MONOMER_TEMP = 0x02,    // 电池单体温度/极柱温度
    BATTERY_MONOMER_SOC,            // 电池单体 SOC
    BATTERY_MONOMER_SOH,            // 电池单体 SOH
    CLUSTER_BATTERY_DATA,           // 主控采集信息（组端电压、组端电流、绝缘电阻、模块温度）
    SYSTEM_SUMMARY_DATA,            // 系统概要信息（电池单体电压、温度、SOC、SOH的最大值（前三）、最小值（前三）、平均值、极差值）
    BATTERY_NUMBER_MODULE,          // 模块电池节数
    BATTERY_ALARM_INFO,             // 组端报警信息
    BATTERY_DI_DO_INFO,             // DI/DO 状态信息
    TEMPERATURE_NUMBER_MODULE,      // 模块温度个数信息
}battery_data_type_e;


/** 
 * @brief   控制电池主控上下电指令(0x80)
 * @param   [in] command_type   命令类型 1：上电 2：下电 3：所有簇故障下电，其他：无效 见control_command_type_e
 * @param   [in] object         操作对象 0: 所有簇执行 1~20 对应簇执行
 * @return
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败
 */
int16_t battery_power_control(control_command_type_e command_type, uint8_t object);

/** 
 * @brief   控制电池主控绝缘检测功能指令(0x81)
 * @param   [in] dev_id     上位机下发的设备序号(0~N) N为电池簇数量-1
 * @param   [in] on_off     true：开启绝缘检测  false：关闭绝缘检测
 * @return
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败
 */
int32_t battery_insulation_detection_control(uint8_t dev_id, bool on_off);

/** 
 * @brief   配置表数据查询指令 下发函数接口(0x1F)
 * @param   [in] dev_id         上位机下发的设备序号(0~N) N为电池簇数量-1
 * @param   [in] config_type    需要查询的配置数据的类型->对应配置表命令码
 * @return
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败
 * @note     配置表查询，只在接收到上位机的配置查询指令的时候需要下发，由104的通信进程调用
 */
int16_t battery_config_table_query(uint8_t dev_id, uint8_t config_type);

/** 
 * @brief   配置表类设置指令 下发函数接口
 * @param   [in] dev_id         上位机下发的设备序号(0~N) N为电池簇数量-1
 * @param   [in] function_id    功能码
 * @return  
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败
 * @note     配置表设置，只在接收到上位机的配置设置指令的时候需要下发，由104的通信线程调用
 *           特别注意：电池主控的参数保存在内部 Flash 中，因此参数设置命令需要间隔 300 ms
 */
int16_t battery_config_table_set(uint8_t dev_id, uint8_t function_id);

/** 
 * @brief   版本信息查询指令 下发函数接口(0x40)
 * @param   [in] dev_id 上位机下发的设备序号(0~N) N为电池簇数量-1
 * @param   [in] object 查询对象 0x01-主控  0x02-从控
 * @return
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败
 * @note     版本信息查询，只在接收到查询版本号的指令的时候需要下发，由104的通信进程调用
 */
int16_t battery_version_info_query(uint8_t dev_id, uint8_t object);

/**
 * @brief    电池CAN通信电池单体数据获取
 * @param    [in] dev_id    设备序号(0~N) N为电池簇数量-1
 * @param    [in] data_type 信息类型 详见 battery_data_type_e
 * @return   
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败
 * @note     电池信息类 的数据，需要定时获取并更新到共享内存，以供存储。
 *           （获取频率还需商榷！！！）
 */
int16_t battery_monomer_data_query(uint8_t dev_id, uint8_t data_type);

/** 
 * @brief   控制模块DO输出
 * @param   [in] dev_id     上位机下发的设备序号(0~N) N为电池簇数量-1
 * @param   [in] port       端口号0~7，对应DO1~DO8
 * @param   [in] cmd        需要下发的具体命令 0-输出无效  1-输出有效
 * @return
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败
 * @note     只在接收到上位机控制DO输出指令的时候需要下发，由104的通信进程调用
 */
int16_t set_DO_output(uint8_t dev_id, uint8_t port, uint8_t cmd);

/** 
 * @brief   查询电池运行数据指令发送（CAN通讯）任务启动
 * @param
 * @return
 */
void battery_write_task_start(void);

/** 
 * @brief   控制辅电继电器
 * @param   [in] dev_id 电池簇ID
 * @param   [in] on_off 0-断开  1-吸合
 * @return
 */
int32_t battery_auxpower_relay_control(uint8_t dev_id, bool on_off);

#endif  /* __BATTERY_FUN_INTERFACE_H__ */
