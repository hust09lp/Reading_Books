/** 
 * @file          process_battery_read.c
 * @brief         电池数据读取线程功能实现
 * @author        xiaojuying
 * @note
 * @version       V0.0.1     初版
 * @date          2023/2/8
 */

#include "process_battery_read.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "sofar_log.h"
#include "sdk_public.h"
#include "sdk_can.h"
#include "sofar_errors.h"
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <sys/time.h>
#include "cmu_sys_state.h"


static battery_cluster_data_t g_battery_cluster_data[BCU_DEVICE_NUM];
static battery_comm_info_t  g_battery_comm_info;
static battery_software_version_t g_battery_software_version[BCU_DEVICE_NUM];
// static const uint8_t g_project_number[12] = "20222099"; // 项目编号，用于确认电池的软件版本是本项目的
static sdk_rtc_t g_rtc_time;    // 用于记录系统RTC时间

/** 
 * @brief   电池通信接收线程相关参数初始化
 * @param
 * @return
 */
static void battery_comm_read_param_init(void)
{
    uint8_t i = 0;
    uint8_t j = 0;
    uint8_t k = 0;
    int32_t ret = 0;
    uint16_t bat_cabinet_num;                   	// 电池仓个数

    memset(&g_battery_cluster_data, 0, (sizeof(battery_cluster_data_t) * BCU_DEVICE_NUM));
    memset(&g_battery_comm_info, 0, sizeof(battery_comm_info_t));
    memset(&g_battery_software_version, 0, sizeof(battery_software_version_t));
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    //解决BUG：如果没有连接好电池簇的CAN就开始上电,会导致无法检测出通信失联。
    //在初始化我们假设用户设置的"电池簇个数"个BCU都是处于连接状态
    bat_cabinet_num = p_para_data->bat_cabinet_num;
    for(i = 0; i < bat_cabinet_num; i++)
    {
       // g_battery_cluster_data[i].BCU_comm_status = BATTERY_CONNECT;
       g_battery_comm_info.battery_connect_flag[i] = BATTERY_CONNECT;
    }

    // 电流、温度值存在偏移量，初始化是需赋对应值使其初始时外部显示为0
    for (i = 0; i < BCU_DEVICE_NUM; i++)
    {
        g_battery_cluster_data[i].cluster_current = 16000;

        for (j = 0; j < 4; j++)
        {
            g_battery_cluster_data[i].high_pressure_box_temperature[j] = 40;

            if (j < 3)
            {
                g_battery_cluster_data[i].highest_monomer_temperature_cluster[j] = 40;
                g_battery_cluster_data[i].lowest_monomer_temperature_cluster[j] = 40;
            } 
        }

        g_battery_cluster_data[i].average_temperature_monomer = 40;

        for (j = 0; j < PACK_NUMBER; j++)
        {
            for (k = 0; k < MONOMER_NUMBER_IN_PACK; k++)
            {
                g_battery_cluster_data[i].monomer_data[j].monomer_temperature[k] = 40;

                if (k < POLE_TEMP_NUM_IN_PACK)
                {
                    g_battery_cluster_data[i].pole_temperater_PACK[j][k] = 40;
                }
            }
        }
    }

    ret = sdk_rtc_get(RTC_BIN_FORMAT, &g_rtc_time);
    if (ret)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"\n [%s:%d] sdk_rtc_get fail \n", __func__, __LINE__);
    }

    // 因为底层接口sdk_is_time_over(sdk_rtc_t *p_start_time, uint32_t interval) 
    // 当p_start_time为1970年时，无法正确判断是否超时，所以检测到时间不合法时，赋一个合法的初始值
    if ((g_rtc_time.tm_year) > 37)
    {
        g_rtc_time.tm_year = 23;
    }
}

/**
 * @brief   根据电池簇禁充、禁放的反馈 对 共享内存电池禁充、禁放标志位进行置位
 * @param   
 * @return  
 * @note
 */
static void battery_charge_discharge_disable_set(void)
{
    uint8_t charge_disable = 0;
    uint8_t discharge_disable = 0;
    uint8_t i = 0;
    internal_shared_data_t *p_internal_data = internal_shared_data_get();

    if (NULL == p_internal_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    for (i = 0; i < BCU_DEVICE_NUM; i++)
    {
        if (g_battery_cluster_data[i].charge_disable)
        {
            charge_disable += 1;
        }

        if (g_battery_cluster_data[i].discharge_disable)
        {
            discharge_disable += 1;
        }
    }
    
    p_internal_data->battery_charge_disable = (charge_disable > 0) ? 1 : 0;
    p_internal_data->battery_discharge_disable = (discharge_disable > 0) ? 1 : 0;
}

/**
 * @brief    将电池的主控/从控软件版本号解析成字符串形式
 * @param    [in]   p_src   从电池获取到的原始版本号数据
 * @param    [out]  p_dst   字符串形式的版本号数据
 * @return   字符串的长度
 * @note     例：C-3-4.0.2.0-GB2.8
 */
static uint16_t software_version_to_string(uint8_t *p_src, uint8_t *p_dst)
{
    uint16_t offset_src = 0;
    uint16_t offset_dst = 0;

    if ((NULL == p_dst) || (NULL == p_src))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return (0);
    }

    p_dst[offset_dst++] = p_src[offset_src++]; // 主控版本号1(ASCII)

    offset_dst += snprintf((char *) (&(p_dst[offset_dst])), 9, "%c%d%c%d", '-', p_src[offset_src], \
                            '-', p_src[offset_src + 1]); // 主控版本号2-3(数值)

    // 主控版本号4 5 6(数值)
    offset_src += 2;
    offset_dst += snprintf((char *) (&(p_dst[offset_dst])), 13, "%c%d%c%d%c%d", \
                            '.', p_src[offset_src], '.', p_src[offset_src + 1], \
                            '.', p_src[offset_src + 2]);


    offset_src += 3;
    p_dst[offset_dst++] = '-';
    p_dst[offset_dst++] = p_src[offset_src++]; // 主控版本号7(ASCII)
    p_dst[offset_dst++] = p_src[offset_src++]; // 主控版本号8(ASCII)

    offset_dst += snprintf((char *) (&(p_dst[offset_dst])), 8, "%d%c%d", p_src[offset_src], \
                            '.', p_src[offset_src + 1]); // 主控版本号9.10(数值)

    return offset_dst;
}

/**
 * @brief    更新电池的软件版本号到共享内存
 * @param    
 * @return
 * @note     返回电池的完整软件版本号 字符串格式（主控软件版本号-从控软件版本号-项目软件版本号）
 *           例：C-3-4.0.2.0-GB2.8-C-3-4.0.2.0-GB2.8-20220225-01.03-00
 */
static void battery_software_version_update(uint8_t dev_id)
{
    uint16_t offset_src = 0;
    uint16_t offset_dst = 0;
    uint8_t *p_version_src = NULL;
    uint8_t project_num[12] = {0};
    // int16_t ret = 0;
    uint8_t *p_battery_ver = NULL;
    internal_shared_data_t *p_internal_data = internal_shared_data_get();

    p_battery_ver = p_internal_data->battery_software_version_string;

    if ((NULL == p_battery_ver) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    snprintf((char *) project_num, sizeof(project_num), "%04d%02d%02d", \
                            (2000 + g_battery_software_version[dev_id].project_software_version[0]), \
                            g_battery_software_version[dev_id].project_software_version[1], \
                            g_battery_software_version[dev_id].project_software_version[2]);

    // ret = memcmp(project_num, g_project_number, sizeof(project_num));
    // BATTERY_DEBUG_PRINT((int8_t *)"\n project_num = %s \n", project_num); // 测试用

    // if (ret)
    // {
    //     BATTERY_DEBUG_PRINT((int8_t *)"[error] battery software version: project number is incorrect\n");
    //     // memset(p_battery_ver, 0, LENGTH_BATTERY_VERSION_STRING_MAX);
    //     return;
    // }
    
    // 主控软件版本号
    p_version_src = &(g_battery_software_version[dev_id].master_software_version[0]);
    offset_dst += software_version_to_string(p_version_src, &(p_battery_ver[offset_dst]));

    p_battery_ver[offset_dst++] = '-';

    // 从控软件版本号
    p_version_src = &(g_battery_software_version[dev_id].slave_software_version[0]);
    offset_dst += software_version_to_string(p_version_src, &(p_battery_ver[offset_dst]));

    p_battery_ver[offset_dst++] = '-'; 

    // 项目软件版本号
    p_version_src = &(g_battery_software_version[dev_id].project_software_version[0]);

    // 项目软件版本号-年(偏移量2000)、项目编号千位和百位、项目编号十位和个位 （数值）
    offset_dst += snprintf((char *) (&(p_battery_ver[offset_dst])), 12, "%s", project_num);
    
    // 项目大版本.小版本-测试版本（数值）
    offset_src += 3;
    offset_dst += snprintf((char *) (&(p_battery_ver[offset_dst])), 10, "%c%02d%c%02d%c%02d", \
                            '-', p_version_src[offset_src], '.', p_version_src[offset_src + 1], \
                            '-', p_version_src[offset_src + 2]);

    BATTERY_DEBUG_PRINT((int8_t *)"\n battery software version = %s \n", p_battery_ver); // 测试用
}

/**
 * @brief   电池数量报文解包
 * @param   [in] dev_id     电池簇地址索引(0~N) N代表电池簇的最大数量-1
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0x01的应答帧进行数据解析
 */
static void battery_number_total_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t offset = 0;
    battery_cluster_data_t *p_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_data = &g_battery_cluster_data[dev_id];

    if (NULL == p_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    p_data->total_battery_number = (uint16_t)((p_rxframe->data[offset] << 8) \
                                              | p_rxframe->data[offset + 1]);
    offset += 2;
    p_data->total_temperature_number = (uint16_t)((p_rxframe->data[offset] << 8) \
                                                  | p_rxframe->data[offset + 1]);

    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->total_battery_number = %d \n", p_data->total_battery_number);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->total_temperature_number = %d \n", p_data->total_temperature_number);
}

/**
 * @brief   组端总电压上限报警值解包
 * @param   [in] dev_id     电池簇地址索引
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0x04的应答帧进行数据解析
 */
static void cluster_OVP_warn_value_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t offset = 0;
    battery_parameter_data_t *p_battery_para_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_battery_para_data = sdk_shm_battery_parameter_data_get(dev_id);

    if (NULL == p_battery_para_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    // 簇端电压过压阈值 更新至共享内存
    p_battery_para_data->cluster_OVP_warn_threshold_1 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                   | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->cluster_OVP_warn_threshold_2 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                   | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->cluster_OVP_warn_threshold_3 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                   | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->cluster_OVP_warn_hysteresis_err = (int16_t) (p_rxframe->data[offset]);

    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->cluster_OVP_warn_threshold_1 = %d \n", p_battery_para_data->cluster_OVP_warn_threshold_1);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->cluster_OVP_warn_threshold_2 = %d \n", p_battery_para_data->cluster_OVP_warn_threshold_2);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->cluster_OVP_warn_threshold_3 = %d \n", p_battery_para_data->cluster_OVP_warn_threshold_3);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->cluster_OVP_warn_hysteresis_err = %d \n", p_battery_para_data->cluster_OVP_warn_hysteresis_err);
}

/**
 * @brief   组端总电压下限报警值解包
 * @param   [in] dev_id     电池簇地址索引
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0x05的应答帧进行数据解析
 */
static void cluster_UVP_warn_value_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t offset = 0;
    battery_parameter_data_t *p_battery_para_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_battery_para_data = sdk_shm_battery_parameter_data_get(dev_id);

    if (NULL == p_battery_para_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    // 簇端电压欠压阈值 更新至共享内存
    p_battery_para_data->cluster_UVP_warn_threshold_1 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                   | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->cluster_UVP_warn_threshold_2 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                   | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->cluster_UVP_warn_threshold_3 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                   | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->cluster_UVP_warn_hysteresis_err = (int16_t)(p_rxframe->data[offset]);

    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->cluster_UVP_warn_threshold_1 = %d \n", p_battery_para_data->cluster_UVP_warn_threshold_1);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->cluster_UVP_warn_threshold_2 = %d \n", p_battery_para_data->cluster_UVP_warn_threshold_2);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->cluster_UVP_warn_threshold_3 = %d \n", p_battery_para_data->cluster_UVP_warn_threshold_3);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->cluster_UVP_warn_hysteresis_err = %d \n", p_battery_para_data->cluster_UVP_warn_hysteresis_err);
}

/**
 * @brief   充电电流报警值解包
 * @param   [in] dev_id     电池簇地址索引
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0x06的应答帧进行数据解析
 */
static void charge_OCP_warn_value_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t offset = 0;
    uint8_t charge_type = 0;
    battery_parameter_data_t *p_battery_para_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_battery_para_data = sdk_shm_battery_parameter_data_get(dev_id);

    if (NULL == p_battery_para_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    charge_type = p_rxframe->data[offset++]; // 充电类型 1: 快充  2: 慢充/极柱过温  3: 馈电
    // BATTERY_DEBUG_PRINT((int8_t *)"\n charge_type = %d \n", charge_type); // 测试用

    if (1 == charge_type)
    {
        // 快充充电电流过流阈值 更新至共享内存
        p_battery_para_data->charge_OCP_warn_threshold_1 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                     | p_rxframe->data[offset + 1]);
        offset += 2;
        p_battery_para_data->charge_OCP_warn_threshold_2 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                     | p_rxframe->data[offset + 1]);
        offset += 2;
        p_battery_para_data->charge_OCP_warn_threshold_3 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                     | p_rxframe->data[offset + 1]);
        offset += 2;
        p_battery_para_data->charge_OCP_warn_hysteresis_err = (int16_t)(p_rxframe->data[offset]);

        // 测试用
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->charge_OCP_warn_threshold_1 = %d \n", p_battery_para_data->charge_OCP_warn_threshold_1);
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->charge_OCP_warn_threshold_2 = %d \n", p_battery_para_data->charge_OCP_warn_threshold_2);
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->charge_OCP_warn_threshold_3 = %d \n", p_battery_para_data->charge_OCP_warn_threshold_3);
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->charge_OCP_warn_hysteresis_err = %d \n", p_battery_para_data->charge_OCP_warn_hysteresis_err);
    }
}

/**
 * @brief   放电电流报警值解包
 * @param   [in] dev_id     电池簇地址索引
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0x07的应答帧进行数据解析
 */
static void discharge_OCP_warn_value_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t offset = 0;
    battery_parameter_data_t *p_battery_para_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_battery_para_data = sdk_shm_battery_parameter_data_get(dev_id);

    if (NULL == p_battery_para_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    // 放电电流过流阈值 更新至共享内存
    p_battery_para_data->discharge_OCP_warn_threshold_1 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                    | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->discharge_OCP_warn_threshold_2 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                    | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->discharge_OCP_warn_threshold_3 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                    | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->discharge_OCP_warn_hysteresis_err = (int16_t)(p_rxframe->data[offset]);

    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->discharge_OCP_warn_threshold_1 = %d \n", p_battery_para_data->discharge_OCP_warn_threshold_1);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->discharge_OCP_warn_threshold_2 = %d \n", p_battery_para_data->discharge_OCP_warn_threshold_2);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->discharge_OCP_warn_threshold_3 = %d \n", p_battery_para_data->discharge_OCP_warn_threshold_3);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->discharge_OCP_warn_hysteresis_err = %d \n", p_battery_para_data->discharge_OCP_warn_hysteresis_err);
}

/**
 * @brief   充电单体电池温度报警值解包
 * @param   [in] dev_id     电池簇地址索引
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0x08的应答帧进行数据解析
 */
static void charge_monomer_temp_warn_value_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t offset = 0;
    battery_parameter_data_t *p_battery_para_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_battery_para_data = sdk_shm_battery_parameter_data_get(dev_id);

    if (NULL == p_battery_para_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    // 充电单体电池温度阈值 更新至共享内存
    p_battery_para_data->charge_monomer_OTP_warn_threshold_1 = p_rxframe->data[offset++];
    p_battery_para_data->charge_monomer_OTP_warn_threshold_2 = p_rxframe->data[offset++];
    p_battery_para_data->charge_monomer_OTP_warn_threshold_3 = p_rxframe->data[offset++];
    p_battery_para_data->charge_monomer_OTP_warn_hysteresis_err = p_rxframe->data[offset++];
    p_battery_para_data->charge_monomer_UTP_warn_threshold_1 = p_rxframe->data[offset++];
    p_battery_para_data->charge_monomer_UTP_warn_threshold_2 = p_rxframe->data[offset++];
    p_battery_para_data->charge_monomer_UTP_warn_threshold_3 = p_rxframe->data[offset++];
    p_battery_para_data->charge_monomer_UTP_warn_hysteresis_err = p_rxframe->data[offset];

    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->charge_monomer_OTP_warn_threshold_1 = %d \n", p_battery_para_data->charge_monomer_OTP_warn_threshold_1);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->charge_monomer_OTP_warn_threshold_2 = %d \n", p_battery_para_data->charge_monomer_OTP_warn_threshold_2);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->charge_monomer_OTP_warn_threshold_3 = %d \n", p_battery_para_data->charge_monomer_OTP_warn_threshold_3);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->charge_monomer_OTP_warn_hysteresis_err = %d \n", p_battery_para_data->charge_monomer_OTP_warn_hysteresis_err);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->charge_monomer_UTP_warn_threshold_1 = %d \n", p_battery_para_data->charge_monomer_UTP_warn_threshold_1);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->charge_monomer_UTP_warn_threshold_2 = %d \n", p_battery_para_data->charge_monomer_UTP_warn_threshold_2);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->charge_monomer_UTP_warn_threshold_3 = %d \n", p_battery_para_data->charge_monomer_UTP_warn_threshold_3);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->charge_monomer_UTP_warn_hysteresis_err = %d \n", p_battery_para_data->charge_monomer_UTP_warn_hysteresis_err);
}

/**
 * @brief   单体电池温差报警值解包
 * @param   [in] dev_id     电池簇地址索引
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0x09的应答帧进行数据解析
 */
static void monomer_temp_diff_warn_value_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t offset = 0;
    battery_parameter_data_t *p_battery_para_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_battery_para_data = sdk_shm_battery_parameter_data_get(dev_id);

    if (NULL == p_battery_para_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    // 单体电池温差阈值 更新至共享内存
    p_battery_para_data->monomer_temp_diff_warn_threshold_1 = p_rxframe->data[offset++];
    p_battery_para_data->monomer_temp_diff_warn_threshold_2 = p_rxframe->data[offset++];
    p_battery_para_data->monomer_temp_diff_warn_threshold_3 = p_rxframe->data[offset++];
    p_battery_para_data->monomer_temp_diff_warn_hysteresis_err = p_rxframe->data[offset];

    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->monomer_temp_diff_warn_threshold_1 = %d \n", p_battery_para_data->monomer_temp_diff_warn_threshold_1);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->monomer_temp_diff_warn_threshold_2 = %d \n", p_battery_para_data->monomer_temp_diff_warn_threshold_2);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->monomer_temp_diff_warn_threshold_3 = %d \n", p_battery_para_data->monomer_temp_diff_warn_threshold_3);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->monomer_temp_diff_warn_hysteresis_err = %d \n", p_battery_para_data->monomer_temp_diff_warn_hysteresis_err);
}

/**
 * @brief   SOC 报警值解包
 * @param   [in] dev_id     电池簇地址索引
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0x0A的应答帧进行数据解析
 */
static void SOC_warn_value_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t offset = 0;
    uint8_t threshold_type = 0;
    battery_parameter_data_t *p_battery_para_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_battery_para_data = sdk_shm_battery_parameter_data_get(dev_id);

    if (NULL == p_battery_para_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    // SOC（上限 下限 差异）阈值 更新至共享内存
    threshold_type = p_rxframe->data[offset++];
    switch (threshold_type)
    {
        case 1:         // 下限值
        {
            p_battery_para_data->SOC_low_warn_threshold_1 = p_rxframe->data[offset++];
            p_battery_para_data->SOC_low_warn_threshold_2 = p_rxframe->data[offset++];
            p_battery_para_data->SOC_low_warn_threshold_3 = p_rxframe->data[offset++];
            p_battery_para_data->SOC_low_warn_hysteresis_err = p_rxframe->data[offset];

            // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->SOC_low_warn_threshold_1 = %d \n", p_battery_para_data->SOC_low_warn_threshold_1);
            // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->SOC_low_warn_threshold_2 = %d \n", p_battery_para_data->SOC_low_warn_threshold_2);
            // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->SOC_low_warn_threshold_3 = %d \n", p_battery_para_data->SOC_low_warn_threshold_3);
            // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->SOC_low_warn_hysteresis_err = %d \n", p_battery_para_data->SOC_low_warn_hysteresis_err);
            break;
        }

        case 2:         // 上限值
        {
            p_battery_para_data->SOC_high_warn_threshold_1 = p_rxframe->data[offset++];
            p_battery_para_data->SOC_high_warn_threshold_2 = p_rxframe->data[offset++];
            p_battery_para_data->SOC_high_warn_threshold_3 = p_rxframe->data[offset++];
            p_battery_para_data->SOC_high_warn_hysteresis_err = p_rxframe->data[offset];

            // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->SOC_high_warn_threshold_1 = %d \n", p_battery_para_data->SOC_high_warn_threshold_1);
            // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->SOC_high_warn_threshold_2 = %d \n", p_battery_para_data->SOC_high_warn_threshold_2);
            // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->SOC_high_warn_threshold_3 = %d \n", p_battery_para_data->SOC_high_warn_threshold_3);
            // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->SOC_high_warn_hysteresis_err = %d \n", p_battery_para_data->SOC_high_warn_hysteresis_err);
            break;
        }

        case 3:         // 差异值
        {
            p_battery_para_data->SOC_diff_warn_threshold_1 = p_rxframe->data[offset++];
            p_battery_para_data->SOC_diff_warn_threshold_2 = p_rxframe->data[offset++];
            p_battery_para_data->SOC_diff_warn_threshold_3 = p_rxframe->data[offset++];
            p_battery_para_data->SOC_diff_warn_hysteresis_err = p_rxframe->data[offset];

            // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->SOC_diff_warn_threshold_1 = %d \n", p_battery_para_data->SOC_diff_warn_threshold_1);
            // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->SOC_diff_warn_threshold_2 = %d \n", p_battery_para_data->SOC_diff_warn_threshold_2);
            // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->SOC_diff_warn_threshold_3 = %d \n", p_battery_para_data->SOC_diff_warn_threshold_3);
            // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->SOC_diff_warn_hysteresis_err = %d \n", p_battery_para_data->SOC_diff_warn_hysteresis_err);
            break;
        }

        default:
            break;
    }

}

/**
 * @brief   绝缘电阻报警值解包
 * @param   [in] dev_id     电池簇地址索引
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0x0B的应答帧进行数据解析
 */
static void ISO_warn_value_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t offset = 0;
    battery_parameter_data_t *p_battery_para_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_battery_para_data = sdk_shm_battery_parameter_data_get(dev_id);

    if (NULL == p_battery_para_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    // 绝缘阻抗阈值 更新至共享内存
    p_battery_para_data->ISO_warn_threshold_1 = (uint16_t)((p_rxframe->data[offset] << 8) \
                                                            | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->ISO_warn_threshold_2 = (uint16_t)((p_rxframe->data[offset] << 8) \
                                                            | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->ISO_warn_threshold_3 = (uint16_t)((p_rxframe->data[offset] << 8) \
                                                            | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->ISO_warn_hysteresis_err = p_rxframe->data[offset];
    
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->ISO_warn_threshold_1 = %d \n", p_battery_para_data->ISO_warn_threshold_1);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->ISO_warn_threshold_2 = %d \n", p_battery_para_data->ISO_warn_threshold_2);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->ISO_warn_threshold_3 = %d \n", p_battery_para_data->ISO_warn_threshold_3);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->ISO_warn_hysteresis_err = %d \n", p_battery_para_data->ISO_warn_hysteresis_err);
}

/**
 * @brief   电池单体电压上限报警值解包
 * @param   [in] dev_id     电池簇地址索引
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0x0C的应答帧进行数据解析
 */
static void monomer_OVP_warn_value_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t offset = 0;
    battery_parameter_data_t *p_battery_para_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_battery_para_data = sdk_shm_battery_parameter_data_get(dev_id);

    if (NULL == p_battery_para_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    // 单体电压上限阈值 更新至共享内存
    p_battery_para_data->monomer_OVP_warn_threshold_1 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                   | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->monomer_OVP_warn_threshold_2 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                   | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->monomer_OVP_warn_threshold_3 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                   | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->monomer_OVP_warn_hysteresis_err = p_rxframe->data[offset];

    // BATTERY_DEBUG_PRINT((int8_t *)"\n [config] p_battery_para_data->monomer_OVP_warn_threshold_1 = %d \n", p_battery_para_data->monomer_OVP_warn_threshold_1);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n [config] p_battery_para_data->monomer_OVP_warn_threshold_2 = %d \n", p_battery_para_data->monomer_OVP_warn_threshold_2);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n [config] p_battery_para_data->monomer_OVP_warn_threshold_3 = %d \n", p_battery_para_data->monomer_OVP_warn_threshold_3);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n [config] p_battery_para_data->monomer_OVP_warn_hysteresis_err = %d \n", p_battery_para_data->monomer_OVP_warn_hysteresis_err);
}

/**
 * @brief   电池单体电压下限报警值解包
 * @param   [in] dev_id     电池簇地址索引
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0x0D的应答帧进行数据解析
 */
static void monomer_UVP_warn_value_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t offset = 0;
    battery_parameter_data_t *p_battery_para_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_battery_para_data = sdk_shm_battery_parameter_data_get(dev_id);

    if (NULL == p_battery_para_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    // 单体电压下限阈值 更新至共享内存
    p_battery_para_data->monomer_UVP_warn_threshold_1 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                   | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->monomer_UVP_warn_threshold_2 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                   | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->monomer_UVP_warn_threshold_3 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                   | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->monomer_UVP_warn_hysteresis_err = p_rxframe->data[offset];

    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->monomer_UVP_warn_threshold_1 = %d \n", p_battery_para_data->monomer_UVP_warn_threshold_1);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->monomer_UVP_warn_threshold_2 = %d \n", p_battery_para_data->monomer_UVP_warn_threshold_2);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->monomer_UVP_warn_threshold_3 = %d \n", p_battery_para_data->monomer_UVP_warn_threshold_3);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->monomer_UVP_warn_hysteresis_err = %d \n", p_battery_para_data->monomer_UVP_warn_hysteresis_err);
}

/**
 * @brief   电池单体电压压差报警值解包
 * @param   [in] dev_id     电池簇地址索引
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0x0E的应答帧进行数据解析
 */
static void monomer_vol_diff_warn_value_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t offset = 0;
    battery_parameter_data_t *p_battery_para_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_battery_para_data = sdk_shm_battery_parameter_data_get(dev_id);

    if (NULL == p_battery_para_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    // 单体电压压差阈值 更新至共享内存
    p_battery_para_data->monomer_vol_diff_warn_threshold_1 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                        | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->monomer_vol_diff_warn_threshold_2 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                        | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->monomer_vol_diff_warn_threshold_3 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                        | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->monomer_vol_diff_warn_hysteresis_err = p_rxframe->data[offset];

    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->monomer_vol_diff_warn_threshold_1 = %d \n", p_battery_para_data->monomer_vol_diff_warn_threshold_1);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->monomer_vol_diff_warn_threshold_2 = %d \n", p_battery_para_data->monomer_vol_diff_warn_threshold_2);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->monomer_vol_diff_warn_threshold_3 = %d \n", p_battery_para_data->monomer_vol_diff_warn_threshold_3);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->monomer_vol_diff_warn_hysteresis_err = %d \n", p_battery_para_data->monomer_vol_diff_warn_hysteresis_err);
}

/**
 * @brief   模块温度上限报警值解包
 * @param   [in] dev_id     电池簇地址索引
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0x0F的应答帧进行数据解析
 */
static void module_temp_warn_value_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t offset = 0;
    battery_parameter_data_t *p_battery_para_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_battery_para_data = sdk_shm_battery_parameter_data_get(dev_id);

    if (NULL == p_battery_para_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    // 模块温度上限阈值 更新至共享内存
    p_battery_para_data->PACK_temp_diff_warn_threshold_1 = p_rxframe->data[offset++];
    p_battery_para_data->PACK_temp_diff_warn_threshold_2 = p_rxframe->data[offset++];
    p_battery_para_data->PACK_temp_diff_warn_threshold_3 = p_rxframe->data[offset++];
    p_battery_para_data->PACK_temp_diff_warn_hysteresis_err = p_rxframe->data[offset];

    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->PACK_temp_diff_warn_threshold_1 = %d \n", p_battery_para_data->PACK_temp_diff_warn_threshold_1);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->PACK_temp_diff_warn_threshold_2 = %d \n", p_battery_para_data->PACK_temp_diff_warn_threshold_2);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->PACK_temp_diff_warn_threshold_3 = %d \n", p_battery_para_data->PACK_temp_diff_warn_threshold_3);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->PACK_temp_diff_warn_hysteresis_err = %d \n", p_battery_para_data->PACK_temp_diff_warn_hysteresis_err);
}

/**
 * @brief   电池主参数解包
 * @param   [in] dev_id     电池簇地址索引
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0x16的应答帧进行数据解析
 */
static void battery_type_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t offset = 0;
    battery_cluster_data_t *p_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_data = &g_battery_cluster_data[dev_id];

    if (NULL == p_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    p_data->battery_type = p_rxframe->data[offset++];

    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->battery_type = %d \n", p_data->battery_type);
}

/**
 * @brief   放电单体电池温度报警值解包
 * @param   [in] dev_id     电池簇地址索引
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0x1C的应答帧进行数据解析
 */
static void discharge_monomer_temp_warn_value_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t offset = 0;
    battery_parameter_data_t *p_battery_para_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_battery_para_data = sdk_shm_battery_parameter_data_get(dev_id);

    if (NULL == p_battery_para_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    // 放电单体电池温度阈值 更新至共享内存
    p_battery_para_data->discharge_monomer_OTP_warn_threshold_1 = p_rxframe->data[offset++];
    p_battery_para_data->discharge_monomer_OTP_warn_threshold_2 = p_rxframe->data[offset++];
    p_battery_para_data->discharge_monomer_OTP_warn_threshold_3 = p_rxframe->data[offset++];
    p_battery_para_data->discharge_monomer_OTP_warn_hysteresis_err = p_rxframe->data[offset++];

    p_battery_para_data->discharge_monomer_UTP_warn_threshold_1 = p_rxframe->data[offset++];
    p_battery_para_data->discharge_monomer_UTP_warn_threshold_2 = p_rxframe->data[offset++];
    p_battery_para_data->discharge_monomer_UTP_warn_threshold_3 = p_rxframe->data[offset++];
    p_battery_para_data->discharge_monomer_UTP_warn_hysteresis_err = p_rxframe->data[offset];

    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->discharge_monomer_OTP_warn_threshold_1 = %d \n", p_battery_para_data->discharge_monomer_OTP_warn_threshold_1);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->discharge_monomer_OTP_warn_threshold_2 = %d \n", p_battery_para_data->discharge_monomer_OTP_warn_threshold_2);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->discharge_monomer_OTP_warn_threshold_3 = %d \n", p_battery_para_data->discharge_monomer_OTP_warn_threshold_3);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->discharge_monomer_OTP_warn_hysteresis_err = %d \n", p_battery_para_data->discharge_monomer_OTP_warn_hysteresis_err);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->discharge_monomer_UTP_warn_threshold_1 = %d \n", p_battery_para_data->discharge_monomer_UTP_warn_threshold_1);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->discharge_monomer_UTP_warn_threshold_2 = %d \n", p_battery_para_data->discharge_monomer_UTP_warn_threshold_2);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->discharge_monomer_UTP_warn_threshold_3 = %d \n", p_battery_para_data->discharge_monomer_UTP_warn_threshold_3);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->discharge_monomer_UTP_warn_hysteresis_err = %d \n", p_battery_para_data->discharge_monomer_UTP_warn_hysteresis_err);
}

/**
 * @brief   电池模组(PACK)电压上限报警值解包
 * @param   [in] dev_id     电池簇地址索引
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0x2B的应答帧进行数据解析
 */
static void PACK_OVP_warn_value_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t offset = 0;
    battery_parameter_data_t *p_battery_para_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_battery_para_data = sdk_shm_battery_parameter_data_get(dev_id);

    if (NULL == p_battery_para_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    // PACK电压上限阈值 更新至共享内存
    p_battery_para_data->PACK_OVP_warn_threshold_1 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->PACK_OVP_warn_threshold_2 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->PACK_OVP_warn_threshold_3 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->PACK_OVP_warn_hysteresis_err = p_rxframe->data[offset];

    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->PACK_OVP_warn_threshold_1 = %d \n", p_battery_para_data->PACK_OVP_warn_threshold_1);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->PACK_OVP_warn_threshold_2 = %d \n", p_battery_para_data->PACK_OVP_warn_threshold_2);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->PACK_OVP_warn_threshold_3 = %d \n", p_battery_para_data->PACK_OVP_warn_threshold_3);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->PACK_OVP_warn_hysteresis_err = %d \n", p_battery_para_data->PACK_OVP_warn_hysteresis_err);
}

/**
 * @brief   电池模组(PACK)电压下限报警值解包
 * @param   [in] dev_id     电池簇地址索引
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0x2C的应答帧进行数据解析
 */
static void PACK_UVP_warn_value_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t offset = 0;
    battery_parameter_data_t *p_battery_para_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_battery_para_data = sdk_shm_battery_parameter_data_get(dev_id);

    if (NULL == p_battery_para_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    // PACK电压下限阈值 更新至共享内存
    p_battery_para_data->PACK_UVP_warn_threshold_1 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->PACK_UVP_warn_threshold_2 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->PACK_UVP_warn_threshold_3 = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                | p_rxframe->data[offset + 1]);
    offset += 2;
    p_battery_para_data->PACK_UVP_warn_hysteresis_err = p_rxframe->data[offset];

    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->PACK_UVP_warn_threshold_1 = %d \n", p_battery_para_data->PACK_UVP_warn_threshold_1);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->PACK_UVP_warn_threshold_2 = %d \n", p_battery_para_data->PACK_UVP_warn_threshold_2);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->PACK_UVP_warn_threshold_3 = %d \n", p_battery_para_data->PACK_UVP_warn_threshold_3);
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_battery_para_data->PACK_UVP_warn_hysteresis_err = %d \n", p_battery_para_data->PACK_UVP_warn_hysteresis_err);
}

/**
 * @brief   电池单体电压解包
 * @param   [in] dev_id         电池簇地址索引
 * @param   [in] p_rxframe      基本CAN帧结构
 * @return  
 * @note    对命令码为0x31的应答帧进行数据解析
 */
static void monomer_voltage_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t i = 0;
    uint8_t offset = 0;
    uint8_t frame_num = 0;
    uint8_t pack_num = 0;
    uint16_t monomer_num = 0; // 记录现在是第几个单体
    uint16_t PACK_id = 0;
    uint16_t monomer_id = 0;
    battery_cluster_data_t *p_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_data = &g_battery_cluster_data[dev_id];

    if (NULL == p_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }
    
    frame_num = p_rxframe->data[offset++];
    pack_num = p_rxframe->data[offset++];

    // BATTERY_DEBUG_PRINT((int8_t *)"\n frame_num = %d pack_num = %d \n", frame_num, pack_num); // 测试用

    if ((frame_num < 1) || (frame_num > 20) || (pack_num < 1))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal frame_num/pack_num\n", __func__, __LINE__);
        return;
    }
    
    // 计算公式：电池那边组包方式，假设一簇共有N个单体，单体电压数据按60个为一包，则一簇共N/60包
    // 而can发送数据时，一帧只能发送 3 个单体电压数据，则一包需分为 60/3，即20帧。monomer_num从0开始计数
    monomer_num = 3 * (frame_num - 1) + (pack_num - 1) * 60;

    // 目前系统实际有8个PACK，每个PACK有48个单体，单体电压个数与单体个数一致
    for (i = 0; i < 3; i++)
    {
        // ((monomer_num + i) / PACK内电池数量) 确定PACK编号，((monomer_num + i) % PACK内电池数量) 确定 每个PACK内单体编号
        if (p_data->battery_number_in_PACK)
        {
            PACK_id = ((monomer_num + i) / (p_data->battery_number_in_PACK));
            monomer_id = ((monomer_num + i) % (p_data->battery_number_in_PACK));

            if ((PACK_id >= PACK_NUMBER) || (monomer_id >= MONOMER_NUMBER_IN_PACK))
            {
                break;
            }
        }
        else
        {
            break;
        }

        p_data->monomer_data[PACK_id].monomer_voltage[monomer_id] = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                              | p_rxframe->data[offset + 1]);
        offset += 2;
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->monomer_data[%d].monomer_voltage[%d] = %d \n", PACK_id, monomer_id, p_data->monomer_data[PACK_id].monomer_voltage[monomer_id]); // 测试用
    }
}

/**
 * @brief   电池单体温度数据解包
 * @param   [in] dev_id         电池簇地址索引
 * @param   [in] p_rxframe      基本CAN帧结构
 * @return  
 * @note    对命令码为0x32的应答帧进行数据解析
 */
static void monomer_temperature_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t i = 0;
    uint8_t module_number = 0;
    uint8_t temp2 = 0;
    uint8_t offset = 0;
    uint8_t frame_num = 0;
    uint8_t pack_num = 0;
    uint16_t monomer_num = 0; // 记录现在是第几个单体
    uint16_t PACK_id = 0;
    uint16_t temperature_id = 0;
    uint16_t monomer_id = 0;
    battery_cluster_data_t *p_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_data = &g_battery_cluster_data[dev_id];

    if (NULL == p_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }
    
    frame_num = p_rxframe->data[offset++];
    pack_num = p_rxframe->data[offset++];

    // BATTERY_DEBUG_PRINT((int8_t *)"\n frame_num = %d pack_num = %d \n", frame_num, pack_num); // 测试用

    if ((frame_num < 1) || (frame_num > 20) || (pack_num < 1))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal frame_num/pack_num\n", __func__, __LINE__);
        return;
    }
    
    // 计算公式：电池那边组包方式，假设一簇共有N个单体，单体温度数据按120个为一包，则一簇共N/120包
    // 而can发送数据时，一帧只能发送 6 个单体温度数据，则一包需分为 120/6，即20帧。monomer_num从0开始计数
    monomer_num = 6 * (frame_num - 1) + (pack_num - 1) * 120;

    // 目前系统实际有8个PACK，每个PACK有48个单体，28个温度采样点，存在两个电芯共用一个温度的情况
    // 目前每个PACK温度采样点为28个，分为4个模组，即每12个电芯对应7个温度采样点，
    // 其中每个模组第一个和最后一个电芯单独一个温度采样点，其余两两一组，两个电芯共用一个温度
    // T1->1  T2->2/3  T3->4/5  T4->6/7  T5->8/9  T6->10/11  T7->12 ----模组1
    // T8->13  T14->24,  T15->25  T21->36,  T22->37  T28->48
    for (i = 0; i < 6; i++)
    {
        // ((monomer_num + i) / PACK内温度个数) 确定PACK编号，((monomer_num + i) % PACK内温度个数) 确定 每个PACK内温度采集点的编号
        if (p_data->temperature_number_in_PACK)
        {
            PACK_id = ((monomer_num + i) / (p_data->temperature_number_in_PACK));
            temperature_id = ((monomer_num + i) % (p_data->temperature_number_in_PACK));

            if ((PACK_id >= PACK_NUMBER) || (temperature_id >= MONOMER_NUMBER_IN_PACK))
            {
                break;
            }
        }
        else
        {
            break;
        }

        BATTERY_DEBUG_PRINT((int8_t *)"p_data->temperature_number_in_PACK = %d\n",p_data->temperature_number_in_PACK); // 测试用
        module_number = temperature_id / 7; // -- 计算在哪个模组 0-3
        temp2 = temperature_id % 7; // -- 计算在模组内排第几个 0-6
        if (0 == temp2)
        {
            monomer_id = module_number * 12;
        }
        else
        {
            monomer_id = temp2 + (temp2 - 1) + (module_number * 12);
        }
        
        if ((0 == temp2) || (6 == temp2))
        {
            if (0xFF == (p_rxframe->data[offset]))
            {
                p_data->monomer_data[PACK_id].monomer_temperature[monomer_id] = 0;
            }
            else
            {
                p_data->monomer_data[PACK_id].monomer_temperature[monomer_id] = (p_rxframe->data[offset]);
            }

            BATTERY_DEBUG_PRINT((int8_t *)"p_data->monomer_data[%d].monomer_temperature[%d] = %d \n", PACK_id, monomer_id, p_data->monomer_data[PACK_id].monomer_temperature[monomer_id]); // 测试用
        }
        else
        {
            if (0xFF == (p_rxframe->data[offset]))
            {
                p_data->monomer_data[PACK_id].monomer_temperature[monomer_id] = 0;
                p_data->monomer_data[PACK_id].monomer_temperature[monomer_id + 1] = 0;
            }
            else
            {
                p_data->monomer_data[PACK_id].monomer_temperature[monomer_id] = (p_rxframe->data[offset]);
                p_data->monomer_data[PACK_id].monomer_temperature[monomer_id + 1] = (p_rxframe->data[offset]);
            }

            BATTERY_DEBUG_PRINT((int8_t *)"p_data->monomer_data[%d].monomer_temperature[%d] = %d \n", PACK_id, monomer_id, p_data->monomer_data[PACK_id].monomer_temperature[monomer_id]); // 测试用
            BATTERY_DEBUG_PRINT((int8_t *)"p_data->monomer_data[%d].monomer_temperature[%d] = %d \n", PACK_id, (monomer_id + 1), p_data->monomer_data[PACK_id].monomer_temperature[monomer_id + 1]); // 测试用
        }
        
        offset++;
    }
}

/**
 * @brief   电池单体SOC、电池充、放电能量解包
 * @param   [in] dev_id         电池簇地址索引
 * @param   [in] p_rxframe      基本CAN帧结构
 * @return  
 * @note    对命令码为0x33的应答帧进行数据解析
 */
static void monomer_SOC_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t i = 0;
    uint8_t offset = 0;
    uint8_t frame_num = 0;
    uint8_t pack_num = 0;
    uint16_t monomer_num = 0; // 记录现在是第几个单体
    uint8_t PACK_id = 0;
    uint8_t monomer_id = 0;
    uint8_t cluster_id = 0;
    uint8_t energy_type = 0;
    uint8_t temp = 0;
    battery_cluster_data_t *p_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_data = &g_battery_cluster_data[dev_id];

    if (NULL == p_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }
    
    frame_num = p_rxframe->data[offset++];
    pack_num = p_rxframe->data[offset++];

    // BATTERY_DEBUG_PRINT((int8_t *)"\n frame_num = %d pack_num = %d \n", frame_num, pack_num); // 测试用

    if ((frame_num < 1) || ((frame_num > 20) && (pack_num != 5)) || (pack_num < 1))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal frame_num/pack_num\n", __func__, __LINE__);
        return;
    }
    
    // 计算公式：电池那边组包方式，假设一簇共有N个单体，单体SOC数据按120个为一包，则一簇共N/120包
    // 而can发送数据时，一帧只能发送 6 个单体SOC数据，则一包需分为 120/6，即20帧。从0开始计数
    monomer_num = 6 * (frame_num - 1) + (pack_num - 1) * 120;

    // 目前系统实际有8个PACK，每个PACK有48个单体，单体SOC的个数与单体个数一致
    if (pack_num <= 4)
    {
        for (i = 0; i < 6; i++)
        {
            // ((monomer_num + i) / PACK内电池数量) 确定PACK编号，((monomer_num + i) % PACK内电池数量) 确定 每个PACK内单体编号
            if (p_data->battery_number_in_PACK)
            {
                PACK_id = ((monomer_num + i) / (p_data->battery_number_in_PACK));
                monomer_id = ((monomer_num + i) % (p_data->battery_number_in_PACK));

                if ((PACK_id >= PACK_NUMBER) || (monomer_id >= MONOMER_NUMBER_IN_PACK))
                {
                    break;
                }
            }
            else
            {
                break;
            }

            p_data->monomer_data[PACK_id].monomer_SOC[monomer_id] = p_rxframe->data[offset++];
            // BATTERY_DEBUG_PRINT((int8_t *)"p_data->monomer_data[%d].monomer_SOC[%d] = %d \n", PACK_id, monomer_id, p_data->monomer_data[PACK_id].monomer_SOC[monomer_id]); // 测试用
        }
    }
    else if (5 == pack_num) // pack_num为5时，传输的是充、放电能量的数据
    {
        // 充、放电能量解析
        temp = frame_num / 6;
        if ((temp >= 1) && (temp <= BCU_DEVICE_NUM))
        {
            cluster_id = temp - 1;
            energy_type = frame_num % 6;

            if (cluster_id >= BCU_DEVICE_NUM)
            {
                return;
            }

            if(0 == energy_type)  //单次放电容量
            {
                if(temp >= 2)
                {
                    cluster_id = temp - 2;
                    g_battery_cluster_data[cluster_id].sigle_time_discharge_capacity = (uint16_t)((p_rxframe->data[offset] << 8) \
                                                                                       | p_rxframe->data[offset + 1]);                                 
                    offset += 2;
                }
            }

            if(1 == energy_type)  //累计充电容量
            {
                // 簇累计充电能量 精度：0.1AHMB
                g_battery_cluster_data[cluster_id].total_charge_capacity = (uint32_t) ((p_rxframe->data[offset] << 24) \
                                                                                       | (p_rxframe->data[offset + 1] << 16) \
                                                                                       | (p_rxframe->data[offset + 2] << 8) \
                                                                                       | (p_rxframe->data[offset + 3]));
            }

            if(2 == energy_type)  //累计放电容量
            {
                // 簇累计充电能量 精度：0.1AHMB
                g_battery_cluster_data[cluster_id].total_discharge_capacity = (uint32_t) ((p_rxframe->data[offset] << 24) \
                                                                                       | (p_rxframe->data[offset + 1] << 16) \
                                                                                       | (p_rxframe->data[offset + 2] << 8) \
                                                                                       | (p_rxframe->data[offset + 3]));
            }

            if (3 == energy_type) // 充电量
            {
                // 簇累计充电能量 精度：0.01KWH
                g_battery_cluster_data[cluster_id].total_charging_energy = (uint32_t) ((p_rxframe->data[offset] << 24) \
                                                                                       | (p_rxframe->data[offset + 1] << 16) \
                                                                                       | (p_rxframe->data[offset + 2] << 8) \
                                                                                       | (p_rxframe->data[offset + 3]));
                offset += 4;

                // 簇单日累计充电能量 精度：0.1KWH
                g_battery_cluster_data[cluster_id].daily_charging_energy = (uint16_t)((p_rxframe->data[offset] << 8) \
                                                                                      | p_rxframe->data[offset + 1]);

                // BATTERY_DEBUG_PRINT((int8_t *)"g_battery_cluster_data[%d].total_charging_energy = %d \n", cluster_id, g_battery_cluster_data[cluster_id].total_charging_energy); // 测试用
                // BATTERY_DEBUG_PRINT((int8_t *)"p_data->daily_charging_energy = %d \n", p_data->daily_charging_energy); // 测试用
            }
            
            if (4 == energy_type) // 放电量
            {
                // 簇累计放电能量 精度：0.01KWH
                g_battery_cluster_data[cluster_id].total_discharge_energy = (uint32_t) ((p_rxframe->data[offset] << 24) \
                                                                                        | (p_rxframe->data[offset + 1] << 16) \
                                                                                        | (p_rxframe->data[offset + 2] << 8) \
                                                                                        | (p_rxframe->data[offset + 3]));
                offset += 4;

                // 簇单日累计放电能量 精度：0.1KWH
                g_battery_cluster_data[cluster_id].daily_discharge_energy = (uint16_t)((p_rxframe->data[offset] << 8) \
                                                                                       | p_rxframe->data[offset + 1]);
                // BATTERY_DEBUG_PRINT((int8_t *)"g_battery_cluster_data[%d].total_discharge_energy = %d \n", cluster_id, g_battery_cluster_data[cluster_id].total_discharge_energy); // 测试用
                // BATTERY_DEBUG_PRINT((int8_t *)"p_data->daily_discharge_energy = %d \n", p_data->daily_discharge_energy); // 测试用
            }
              
            if(5 == energy_type)  //单次充电容量
            {
                g_battery_cluster_data[cluster_id].sigle_time_charge_capacity = (uint16_t)((p_rxframe->data[offset] << 8) \
                                                                                       | p_rxframe->data[offset + 1]);          
                offset += 2;
            }

        }
    }
}

/**
 * @brief   电池单体SOH数据解包
 * @param   [in] dev_id         电池簇地址索引
 * @param   [in] p_rxframe      基本CAN帧结构
 * @return  
 * @note    对命令码为0x34的应答帧进行数据解析
 */
static void monomer_SOH_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t i = 0;
    uint8_t offset = 0;
    uint8_t frame_num = 0;
    uint8_t pack_num = 0;
    uint16_t monomer_num = 0; // 记录现在是第几个单体
    uint16_t PACK_id = 0;
    uint16_t monomer_id = 0;
    battery_cluster_data_t *p_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_data = &g_battery_cluster_data[dev_id];

    if (NULL == p_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }
    
    frame_num = p_rxframe->data[offset++];
    pack_num = p_rxframe->data[offset++];

    // BATTERY_DEBUG_PRINT((int8_t *)"\n frame_num = %d pack_num = %d \n", frame_num, pack_num); // 测试用

    if ((frame_num < 1) || (frame_num > 20) || (pack_num < 1))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal frame_num/pack_num\n", __func__, __LINE__);
        return;
    }

    // 计算公式：电池那边组包方式，假设一簇共有N个单体，单体SOH数据按120个为一包，则一簇共N/120包
    // 而can发送数据时，一帧只能发送 6 个单体SOH数据，则一包需分为 120/6，即20帧。从0开始计数
    monomer_num = 6 * (frame_num - 1) + (pack_num - 1) * 120;

    // 目前系统实际有8个PACK，每个PACK有48个单体，单体SOH的个数与单体个数一致
    for (i = 0; i < 6; i++)
    {
        // ((monomer_num + i) / PACK内电池数量) 确定PACK编号，((monomer_num + i) % PACK内电池数量) 确定 每个PACK内单体编号
        if (p_data->battery_number_in_PACK)
        {
            PACK_id = ((monomer_num + i) / (p_data->battery_number_in_PACK));
            monomer_id = ((monomer_num + i) % (p_data->battery_number_in_PACK));

            if ((PACK_id >= PACK_NUMBER) || (monomer_id >= MONOMER_NUMBER_IN_PACK))
            {
                break;
            }
        }
        else
        {
            break;
        }

        p_data->monomer_data[PACK_id].monomer_SOH[monomer_id] = p_rxframe->data[offset++];
        // BATTERY_DEBUG_PRINT((int8_t *)"p_data->monomer_data[%d].monomer_SOH[%d] = %d \n", PACK_id, monomer_id, p_data->monomer_data[PACK_id].monomer_SOH[monomer_id]); // 测试用
    }
}

/**
 * @brief   主控采集信息应答数据解包
 * @param   [in] dev_id     电池簇地址索引
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0x35的应答帧进行数据解析
 */
static void cluster_summary_data_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t offset = 0;
    uint8_t pack_num = 0;
    battery_cluster_data_t *p_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_data = &g_battery_cluster_data[dev_id];

    if (NULL == p_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    pack_num = p_rxframe->data[offset++];

    if (1 == pack_num)
    {
        offset++;
        p_data->cluster_voltage = (int16_t)((p_rxframe->data[offset] << 8) \
                                             | p_rxframe->data[offset + 1]);  // 组端电压
        offset += 2;
        p_data->cluster_current = (int16_t)((p_rxframe->data[offset] << 8) \
                                             | p_rxframe->data[offset + 1]);   // 组端电流
        offset += 2;

        // 绝缘电阻 R+
        p_data->positive_insulation_resistance = (uint16_t)((p_rxframe->data[offset] << 8) \
                                                             | p_rxframe->data[offset + 1]);
        // 测试用
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->cluster_voltage = %d \n", (int16_t)p_data->cluster_voltage);
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->cluster_current = %d \n", (int16_t)p_data->cluster_current); 
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->positive_insulation_resistance = %d \n", p_data->positive_insulation_resistance); 
    }
    else if (2 == pack_num)
    {
        // 绝缘电阻 R-
        p_data->negative_insulation_resistance = (uint16_t)((p_rxframe->data[offset] << 8) \
                                                             | p_rxframe->data[offset + 1]);
        offset += 2;
        p_data->cluster_SOC = p_rxframe->data[offset];    // 组端 SOC

        // 测试用
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->negative_insulation_resistance = %d \n", p_data->negative_insulation_resistance);
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->cluster_SOC = %d \n", p_data->cluster_SOC);  
    }
    else if (4 == pack_num)
    {
        offset += 2;
        p_data->high_pressure_box_temperature[0] = p_rxframe->data[offset++]; // 高压箱温度 T1
        p_data->high_pressure_box_temperature[1] = p_rxframe->data[offset++]; // 高压箱温度 T2
        p_data->high_pressure_box_temperature[2] = p_rxframe->data[offset++]; // 高压箱温度 T3
        p_data->high_pressure_box_temperature[3] = p_rxframe->data[offset];   // 高压箱温度 T4
        
        // 测试用
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->high_pressure_box_temperature[0] = %d \n", (int16_t)p_data->high_pressure_box_temperature[0]);
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->high_pressure_box_temperature[1] = %d \n", (int16_t)p_data->high_pressure_box_temperature[1]); 
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->high_pressure_box_temperature[2] = %d \n", (int16_t)p_data->high_pressure_box_temperature[2]);
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->high_pressure_box_temperature[3] = %d \n", (int16_t)p_data->high_pressure_box_temperature[3]);
    }
    else
    {
        return;
    }
}

/**
 * @brief   系统概要信息数据解包
 * @param   [in] dev_id     电池簇地址索引
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0x36的应答帧进行数据解析
 */
static void system_monomer_summary_data_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t offset = 0;
    uint8_t pack_num = 0;
    uint16_t i = 0;
    battery_cluster_data_t *p_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_data = &g_battery_cluster_data[dev_id];

    if (NULL == p_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    // 每包对应数据含义详见 高特 J1939《高特EVBCM与后台软件通信协议》
    pack_num = p_rxframe->data[offset++];

    if (1 == pack_num)
    {
        offset++;
        for (i = 0; i < 3; i++)
        {
            // 单簇最高单体电压前三Umax1-3
            p_data->highest_monomer_voltage_cluster[i] = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                        | p_rxframe->data[offset + 1]);
            offset += 2;
            // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->highest_monomer_voltage_cluster[%d] = %d \n", i, (int16_t)p_data->highest_monomer_voltage_cluster[i]); // 测试用
        }
    }
    else if (2 == pack_num)
    {
        offset++;
        for (i = 0; i < 3; i++)
        {
            // 单簇最低单体电压前三Umin1-3
            p_data->lowest_monomer_voltage_cluster[i] = (int16_t)((p_rxframe->data[offset] << 8) \
                                                                       | p_rxframe->data[offset + 1]);
            offset += 2;
            // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->lowest_monomer_voltage_cluster[%d] = %d \n", i, (int16_t)p_data->lowest_monomer_voltage_cluster[i]); // 测试用
        }
    }
    else if (3 == pack_num)
    {
        offset++;

        // 单体电压平均值Umean
        p_data->average_voltage_monomer = (int16_t)((p_rxframe->data[offset] << 8) \
                                                         | p_rxframe->data[offset + 1]);
        offset += 4;

        // 单簇最高单体温度前一、前二Tmax1、Tmax2
        p_data->highest_monomer_temperature_cluster[0] = p_rxframe->data[offset++];
        p_data->highest_monomer_temperature_cluster[1] = p_rxframe->data[offset];

        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->average_voltage_monomer = %d \n", p_data->average_voltage_monomer); // 测试用
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->highest_monomer_temperature_cluster[0] = %d \n", (int16_t)p_data->highest_monomer_temperature_cluster[0]); // 测试用
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->highest_monomer_temperature_cluster[1] = %d \n", (int16_t)p_data->highest_monomer_temperature_cluster[1]); // 测试用
    }
    else if (4 == pack_num)
    {
        // 单簇最高单体温度前三Tmax3
        p_data->highest_monomer_temperature_cluster[2] = p_rxframe->data[offset++];

        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->highest_monomer_temperature_cluster[2] = %d \n", (int16_t)p_data->highest_monomer_temperature_cluster[2]); // 测试用

        // 单簇最低单体温度前三Tmin1-3
        for (i = 0; i < 3; i++)
        {
            p_data->lowest_monomer_temperature_cluster[i] = p_rxframe->data[offset++];
            // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->lowest_monomer_temperature_cluster[%d] = %d \n", i, (int16_t)p_data->lowest_monomer_temperature_cluster[i]); // 测试用
        }

        // 单体温度平均值Tmean
        p_data->average_temperature_monomer = p_rxframe->data[offset++];
        offset++;

        // 单簇最高单体SOC前一 SOCmax1
        p_data->highest_monomer_SOC_cluster[0] = p_rxframe->data[offset];
            
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->average_temperature_monomer = %d \n", (int16_t)p_data->average_temperature_monomer); // 测试用
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->highest_monomer_SOC_cluster[0] = %d \n", p_data->highest_monomer_SOC_cluster[0]); // 测试用
    }
    else if (5 == pack_num)
    {
        // 单簇最高单体SOC前二、前三 SOCmax2、SOCmax3
        p_data->highest_monomer_SOC_cluster[1] = p_rxframe->data[offset++];
        p_data->highest_monomer_SOC_cluster[2] = p_rxframe->data[offset++];

        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->highest_monomer_SOC_cluster[1] = %d \n", p_data->highest_monomer_SOC_cluster[1]); // 测试用
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->highest_monomer_SOC_cluster[2] = %d \n", p_data->highest_monomer_SOC_cluster[2]); // 测试用

        // 单簇最低单体SOC前三SOCmin1-3
        for (i = 0; i < 3; i++)
        {
            p_data->lowest_monomer_SOC_cluster[i] = p_rxframe->data[offset++];
            // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->lowest_monomer_SOC_cluster[%d] = %d \n", i, p_data->lowest_monomer_SOC_cluster[i]); // 测试用
        }
                
        // 单体SOC平均值SOCmean
        p_data->average_SOC_monomer = p_rxframe->data[offset];
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->average_SOC_monomer = %d \n", p_data->average_SOC_monomer); // 测试用
    }
    else if (6 == pack_num)
    {
        for (i = 0; i < 3; i++)
        {
            // 单簇最高单体SOH前三SOHmax1-3
            p_data->highest_monomer_SOH_cluster[i] = p_rxframe->data[offset + i];

            // 单簇最低单体SOH前三SOHmin1-3
            p_data->lowest_monomer_SOH_cluster[i] = p_rxframe->data[offset + 3 + i];

            // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->highest_monomer_SOH_cluster[%d] = %d \n", i, p_data->highest_monomer_SOH_cluster[i]); // 测试用
            // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->lowest_monomer_SOH_cluster[%d] = %d \n", i, p_data->lowest_monomer_SOH_cluster[i]); // 测试用
        }

        offset += 6;

        // 单体SOH平均值SOHmean
        p_data->average_SOH_monomer = p_rxframe->data[offset];
    }
    else if (40 == pack_num)
    {
        offset++;

        // 单簇最高单体电压的电池节号
        p_data->battery_node_highest_voltage = (uint16_t)((p_rxframe->data[offset] << 8) \
                                                          | p_rxframe->data[offset + 1]);
        offset += 2;

        // 单簇最低单体电压的电池节号
        p_data->battery_node_lowest_voltage = (uint16_t)((p_rxframe->data[offset] << 8) \
                                                         | p_rxframe->data[offset + 1]);
        offset += 2;

        // 单簇最高单体温度的电池节号
        p_data->battery_node_highest_temperature = (uint16_t)((p_rxframe->data[offset] << 8) \
                                                              | p_rxframe->data[offset + 1]);
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->battery_node_highest_voltage = %d \n", p_data->battery_node_highest_voltage); // 测试用
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->battery_node_lowest_voltage = %d \n", p_data->battery_node_lowest_voltage); // 测试用
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->battery_node_highest_temperature = %d \n", p_data->battery_node_highest_temperature); // 测试用
    }
    else if (41 == pack_num)
    {
        offset++;

        // 单簇最低单体温度的电池节号
        p_data->battery_node_lowest_temperature = (uint16_t)((p_rxframe->data[offset] << 8) \
                                                             | p_rxframe->data[offset + 1]);
        offset += 2;

        // 单簇最高单体SOC的电池节号
        p_data->battery_node_highest_SOC = (uint16_t)((p_rxframe->data[offset] << 8) \
                                                      | p_rxframe->data[offset + 1]);
        offset += 2;

        // 单簇最低单体SOC的电池节号
        p_data->battery_node_lowest_SOC = (uint16_t)((p_rxframe->data[offset] << 8) \
                                                     | p_rxframe->data[offset + 1]);
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->battery_node_lowest_temperature = %d \n", p_data->battery_node_lowest_temperature); // 测试用
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->battery_node_highest_SOC = %d \n", p_data->battery_node_highest_SOC); // 测试用
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->battery_node_lowest_SOC = %d \n", p_data->battery_node_lowest_SOC); // 测试用
    }
    else if (42 == pack_num)
    {
        offset++;

        // 单簇最高单体SOH的电池节号
        p_data->battery_node_highest_SOH = (uint16_t)((p_rxframe->data[offset] << 8) \
                                                      | p_rxframe->data[offset + 1]);
        offset += 2;

        // 单簇最低单体SOH的电池节号
        p_data->battery_node_lowest_SOH = (uint16_t)((p_rxframe->data[offset] << 8) \
                                                     | p_rxframe->data[offset + 1]);
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->battery_node_highest_SOH = %d \n", p_data->battery_node_highest_SOH); // 测试用
        // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->battery_node_lowest_SOH = %d \n", p_data->battery_node_lowest_SOH); // 测试用
    }
}

/**
 * @brief   模块电池节数 解包
 * @param   [in] dev_id     电池簇地址索引
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0x37的应答帧进行数据解析
 */
static void battery_num_module_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t offset = 0;
    uint8_t pack_num = 0;
    battery_cluster_data_t *p_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_data = &g_battery_cluster_data[dev_id];

    if (NULL == p_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }
    
    pack_num = p_rxframe->data[offset++];

    switch (pack_num)
    {
        case 0:
        {
            // 模块总数、总电池节数赋值
            p_data->PACK_number_in_cluster = p_rxframe->data[offset++];
            p_data->total_battery_number = (uint16_t)((p_rxframe->data[offset] << 8) \
                                                      | (p_rxframe->data[offset + 1]));
            // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->PACK_number_in_cluster = %d \n", p_data->PACK_number_in_cluster);
            // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->total_battery_number = %d \n", p_data->total_battery_number);
            break;
        }

        case 1:
        {
            // 模块内电池数量赋值
            p_data->battery_number_in_PACK = p_rxframe->data[offset];
            // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->battery_number_in_PACK = %d \n", p_data->battery_number_in_PACK);

            break;
        }
    
        default:
            break;
    }
}

/**
 * @brief   电池报警/故障信息 解包
 * @param   [in] dev_id     电池簇地址索引
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0x38的应答帧进行数据解析
 */
static void battery_warn_fault_info_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t len = 0;
    uint8_t offset = 0;
    uint8_t alarm_level = 0;
    battery_cluster_data_t *p_data = NULL;
    cmu_sys_state_e cmu_sys_state;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_data = &g_battery_cluster_data[dev_id];

    if (NULL == p_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }
    cmu_sys_state = cmu_sys_state_get();
    // 0-无报警 1-严重报警 2-一般报警 3-轻微报警 4-设备硬件故障
    alarm_level = p_rxframe->data[offset++];

    switch (alarm_level) // 详细故障位位置描述见 104点表 和 高特 J1939《高特EVBCM与后台软件通信协议》
    {
        case 0:
        {
            // 无报警
            len = BATTERY_WARN_1_LEN + BATTERY_WARN_2_LEN + BATTERY_WARN_3_LEN;
            memset(&(p_data->battery_cluster_warn_info[0]), 0, len); // 高特0x38命令码会上报9个字节的告警信息
            // memset(&(p_data->battery_cluster_fault_info[0]), 0, BATTERY_FAULT_LEN); // 高特0x38命令码会上报4个字节的硬件故障信息
            break;
        }

        case 1:
        {
            // 严重报警（3 级）
            memcpy(&(p_data->battery_cluster_warn_info[6]), &(p_rxframe->data[offset]), BATTERY_WARN_3_LEN);
            p_data->battery_cluster_warn_info[7] = (p_data->battery_cluster_warn_info[7]) & 0xF3;
            BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->battery_cluster_warn_info[6] = 0x%x \n", p_data->battery_cluster_warn_info[6]); // 测试用
            BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->battery_cluster_warn_info[7] = 0x%x \n", p_data->battery_cluster_warn_info[7]); // 测试用
            BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->battery_cluster_warn_info[8] = 0x%x \n", p_data->battery_cluster_warn_info[8]); // 测试用
            break;
        }

        case 2:
        {
            // 一般报警（2 级）
            memcpy(&(p_data->battery_cluster_warn_info[3]), &(p_rxframe->data[offset]), BATTERY_WARN_2_LEN);
            p_data->battery_cluster_warn_info[4] = (p_data->battery_cluster_warn_info[4]) & 0xF3;
            /*如果处在运行中,就要屏蔽绝缘检测二级告警*/
            if(cmu_sys_state == CMU_SYS_STATE_RUNNING)
            {
                p_data->battery_cluster_warn_info[4] = (p_data->battery_cluster_warn_info[4]) & 0xFD;
            }
            BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->battery_cluster_warn_info[3] = 0x%x \n", p_data->battery_cluster_warn_info[3]); // 测试用
            BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->battery_cluster_warn_info[4] = 0x%x \n", p_data->battery_cluster_warn_info[4]); // 测试用
            BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->battery_cluster_warn_info[5] = 0x%x \n", p_data->battery_cluster_warn_info[5]); // 测试用
            break;
        }

        case 3:
        {
            // 轻微报警（1 级）
            memcpy(&(p_data->battery_cluster_warn_info[0]), &(p_rxframe->data[offset]), BATTERY_WARN_1_LEN);
            p_data->battery_cluster_warn_info[1] = (p_data->battery_cluster_warn_info[1]) & 0xF3;
            /*如果关闭了绝缘检测,就要屏蔽绝缘检测一级告警*/
            if(cmu_sys_state == CMU_SYS_STATE_RUNNING)
            {
                p_data->battery_cluster_warn_info[1] = (p_data->battery_cluster_warn_info[1]) & 0xFD;
            }
            BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->battery_cluster_warn_info[0] = 0x%x \n", p_data->battery_cluster_warn_info[0]); // 测试用
            BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->battery_cluster_warn_info[1] = 0x%x \n", p_data->battery_cluster_warn_info[1]); // 测试用
            BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->battery_cluster_warn_info[2] = 0x%x \n", p_data->battery_cluster_warn_info[2]); // 测试用
            break;
        }

        case 4:
        {
            // 设备硬件故障
            memcpy(&(p_data->battery_cluster_fault_info[0]), &(p_rxframe->data[offset]), BATTERY_FAULT_LEN);
            BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->battery_cluster_fault_info[0] = 0x%x \n", p_data->battery_cluster_fault_info[0]); // 测试用
            BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->battery_cluster_fault_info[1] = 0x%x \n", p_data->battery_cluster_fault_info[1]); // 测试用
            BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->battery_cluster_fault_info[2] = 0x%x \n", p_data->battery_cluster_fault_info[2]); // 测试用
            BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->battery_cluster_fault_info[3] = 0x%x \n", p_data->battery_cluster_fault_info[3]); // 测试用
            break;
        }
    
        default:
            break;
    }
}

/**
 * @brief   DI/DO 信息应答消息 解包
 * @param   [in] dev_id     电池簇地址索引
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0x39的应答帧进行数据解析
 */
static void DI_DO_info_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t offset = 0;
    uint8_t pack_num = 0;
    uint8_t temp = 0;
    battery_cluster_data_t *p_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_data = &g_battery_cluster_data[dev_id];

    if (NULL == p_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }
    
    pack_num = p_rxframe->data[offset++];

    switch (pack_num)
    {
        case 0:
        {
            // DI1~DI8状态 对应 battery_cluster_status_info[0]的bit0~bit7
            p_data->battery_cluster_status_info[0] = p_rxframe->data[offset];
            break;
        }

        case 1:  // DO 状态 DI/DO严重故障
        {
            // DO1~DO8状态 对应 battery_cluster_status_info[1]的bit0~bit7
            p_data->battery_cluster_status_info[1] = p_rxframe->data[offset++];

            // 禁充、禁放反馈置位 data[2]的bit0-禁充 bit1-禁放
            p_data->charge_disable = (p_rxframe->data[offset]) & 0x01;
            p_data->discharge_disable = ((p_rxframe->data[offset]) >> 1) & 0x01;

            // 严重故障状态 data[2]的bit2
            temp = (p_rxframe->data[offset] >> 2) & 0x01;
            if (ENABLE == temp)
            {
                p_data->battery_cluster_fault_info[4] |= (1 << 0); // battery_cluster_fault_info[4]的bit0
            }
            else
            {
                p_data->battery_cluster_fault_info[4] &= ~(1 << 0); // battery_cluster_fault_info[4]的bit0
            }

            break;
        }

        default:
            break;
    }
}

/**
 * @brief   模块温度个数 解包
 * @param   [in] dev_id     电池簇地址索引
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0x3A的应答帧进行数据解析
 */
static void temperature_num_module_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t offset = 0;
    uint8_t pack_num = 0;
    battery_cluster_data_t *p_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_data = &g_battery_cluster_data[dev_id];

    if (NULL == p_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }
    
    pack_num = p_rxframe->data[offset++];

    switch (pack_num)
    {
        case 0:
        {
            // 模块总数、温度总数赋值
            p_data->PACK_number_in_cluster = p_rxframe->data[offset++];
            p_data->total_temperature_number = (uint16_t)((p_rxframe->data[offset] << 8) \
                                                          | (p_rxframe->data[offset + 1]));
            // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->PACK_number_in_cluster = %d \n", p_data->PACK_number_in_cluster);
            // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->total_temperature_number = %d \n", p_data->total_temperature_number);
            break;
        }

        case 1:
        {
            // 模块内温度数量赋值
            p_data->temperature_number_in_PACK = p_rxframe->data[offset];
            // BATTERY_DEBUG_PRINT((int8_t *)"\n p_data->temperature_number_in_PACK = %d \n", p_data->temperature_number_in_PACK);

            break;
        }
    
        default:
            break;
    }
}

/**
 * @brief   电池极柱温度数据 解包
 * @param   [in] dev_id     电池簇地址索引
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0xB2的应答帧进行数据解析
 */
static void pole_temperature_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t i = 0;
    uint8_t offset = 0;
    uint8_t slave_module_id = 0;    // 从控模块号 1~N (N是PACK数量)
    uint8_t pole_temperater_number = 0;
    battery_cluster_data_t *p_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    p_data = &g_battery_cluster_data[dev_id];
    
    if (NULL == p_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }
    
    slave_module_id = p_rxframe->data[offset++];
    pole_temperater_number = p_rxframe->data[offset++];

    if ((slave_module_id < 1) || (slave_module_id > PACK_NUMBER) || (pole_temperater_number < 1) \
        || (pole_temperater_number > POLE_TEMP_NUM_IN_PACK))
    {
        return;
    }

    for (i = 0; i < pole_temperater_number; i++)
    {
        // 每个PACK的极柱温度赋值
        p_data->pole_temperater_PACK[slave_module_id - 1][i] = p_rxframe->data[offset++];
        BATTERY_DEBUG_PRINT((int8_t *)"\n cluster_id= %d, PACK = %d, pole_temperater[%d] = %d \n", dev_id, (slave_module_id - 1), i, p_data->pole_temperater_PACK[slave_module_id - 1][i]); // 测试用
    }
}

/**
 * @brief   电池主控绝缘检测状态数据 解包
 * @param   [in] dev_id     电池簇地址索引
 * @param   [in] p_rxframe  基本CAN帧结构
 * @return  
 * @note    对命令码为0x81的主动上传的数据帧进行数据解析
 */
static void battery_insulation_detection_unpack(uint8_t dev_id, sdk_can_frame_t *p_rxframe)
{
    battery_cluster_data_t *p_data = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

 //  log_i((int8_t *)"Receive: battery_insulation_detection : %d \n", p_rxframe->data[0]);
    p_data = &g_battery_cluster_data[dev_id];
    
    if (NULL == p_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    p_data->battery_insulation_detection_status = p_rxframe->data[0];
}

/**
 * @brief   配置表数据解析
 * @param   [in] dev_id         电池簇地址索引
 * @param   [in] function_id    功能码
 * @param   [in] p_rxframe      基本CAN帧结构
 * @return  
 * @note    对命令码为配置表类的应答帧进行数据解析
 */
static void config_table_response_data_analysis(uint8_t dev_id, uint8_t function_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t offset = 0;
    
    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    if (CONFIG_TABLE_SET_ACK == function_id)
    {
        g_battery_comm_info.battery_respond_flag[dev_id] = (uint16_t)((p_rxframe->data[offset] << 8) \
                                                                      | p_rxframe->data[offset + 1]);
        offset += 2;
        g_battery_comm_info.error_code[dev_id] = p_rxframe->data[offset];
    }
    else if (BATTERY_NUM_TOTAL == (function_id))
    {
        battery_number_total_unpack(dev_id, p_rxframe);
    }
    else if (CLUSTER_OVP_WARN_VALUE == (function_id))
    {
        cluster_OVP_warn_value_unpack(dev_id, p_rxframe);
    }
    else if (CLUSTER_UVP_WARN_VALUE == (function_id))
    {
        cluster_UVP_warn_value_unpack(dev_id, p_rxframe);
    }
    else if (CHARGE_OCP_WARN_VALUE == (function_id))
    {
        charge_OCP_warn_value_unpack(dev_id, p_rxframe);
    }
    else if (DISCHARGE_OCP_WARN_VALUE == (function_id))
    {
        discharge_OCP_warn_value_unpack(dev_id, p_rxframe);
    }
    else if (CHARGE_MONOMER_TEMP_WARN_VALUE == (function_id))
    {
        charge_monomer_temp_warn_value_unpack(dev_id, p_rxframe);
    }
    else if (MONOMER_TEMP_DIFF_WARN_VALUE == (function_id))
    {
        monomer_temp_diff_warn_value_unpack(dev_id, p_rxframe);
    }
    else if (SOC_WARN_VALUE == (function_id))
    {
        SOC_warn_value_unpack(dev_id, p_rxframe);
    }
    else if (ISO_WARN_VALUE == (function_id))
    {
        ISO_warn_value_unpack(dev_id, p_rxframe);
    }
    else if (MONOMER_OVP_WARN_VALUE == (function_id))
    {
        monomer_OVP_warn_value_unpack(dev_id, p_rxframe);
    }
    else if (MONOMER_UVP_WARN_VALUE == (function_id))
    {
        monomer_UVP_warn_value_unpack(dev_id, p_rxframe);
    }
    else if (MONOMER_VOL_DIFF_WARN_VALUE == (function_id))
    {
        monomer_vol_diff_warn_value_unpack(dev_id, p_rxframe);
    }
    else if (MODULE_TEMP_WARN_VALUE == (function_id))
    {
        module_temp_warn_value_unpack(dev_id, p_rxframe);
    }
    else if (BATTERY_TYPE == (function_id))
    {
        battery_type_unpack(dev_id, p_rxframe);
    }
    else if (DISCHARGE_MONOMER_TEMP_WARN_VALUE == (function_id))
    {
        discharge_monomer_temp_warn_value_unpack(dev_id, p_rxframe);
    }
    else if (PACK_OVP_WARN_VALUE == (function_id))
    {
        PACK_OVP_warn_value_unpack(dev_id, p_rxframe);
    }
    else if (PACK_UVP_WARN_VALUE == (function_id))
    {
        PACK_UVP_warn_value_unpack(dev_id, p_rxframe);
    }
    else
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] undefined function_id = %d\n", __func__, __LINE__, function_id);
        return;
    }
}

/**
 * @brief   电池类信息数据解析
 * @param   [in] dev_id         电池簇地址索引
 * @param   [in] function_id    功能码
 * @param   [in] p_rxframe      基本CAN帧结构
 * @return  
 * @note    对命令码为电池类的应答帧进行数据解析
 */
static void battery_monomer_data_analysis(uint8_t dev_id, uint8_t function_id, sdk_can_frame_t *p_rxframe)
{
    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    if (MONOMER_VOLTAGE == function_id)
    {
        monomer_voltage_unpack(dev_id, p_rxframe);
    }
    else if (MONOMER_TEMPERATURE == function_id)
    {
        monomer_temperature_unpack(dev_id, p_rxframe);
    }
    else if (MONOMER_SOC == function_id)
    {
        monomer_SOC_unpack(dev_id, p_rxframe);
    }
    else if (MONOMER_SOH == function_id)
    {
        monomer_SOH_unpack(dev_id, p_rxframe);
    }
    else if (CLUSTER_BATTERY_INFO == (function_id))
    {
        cluster_summary_data_unpack(dev_id, p_rxframe);
    }
    else if (SYSTEM_SUMMARY_INFO == (function_id))
    {
        system_monomer_summary_data_unpack(dev_id, p_rxframe);
    }
    else if (BATTERY_NUM_MODULE == (function_id))
    {
        battery_num_module_unpack(dev_id, p_rxframe);
    }
    else if (BATTERY_WARN_FAULT_INFO == (function_id))
    {
        battery_warn_fault_info_unpack(dev_id, p_rxframe);
    }
    else if (DI_DO_INFO == (function_id))
    {
        DI_DO_info_unpack(dev_id, p_rxframe);
    }
    else if (TEMPERATURE_NUM_MODULE == (function_id))
    {
        temperature_num_module_unpack(dev_id, p_rxframe);
    }
    else
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] undefined function_id = %d\n", __func__, __LINE__, function_id);
        return;
    }
}

/**
 * @brief   版本号信息解析
 * @param   [in] dev_id         电池簇地址索引
 * @param   [in] function_id    功能码
 * @param   [in] p_rxframe      基本CAN帧结构
 * @return  
 * @note    对查询版本号0x41指令的应答帧进行数据解析
 */
static void version_info_analysis(uint8_t dev_id, uint8_t function_id, sdk_can_frame_t *p_rxframe)
{
    uint8_t offset = 0;
    uint8_t len = 0;
    uint8_t pack_num = 0;
    // uint8_t module_num = 0;
    uint8_t *p_version_index = NULL;

    if ((NULL == p_rxframe) || (dev_id >= BCU_DEVICE_NUM))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    if (VERSION_INFO_ACK == function_id)
    {
        pack_num = p_rxframe->data[offset++];

        if (1 == pack_num)
        {
            offset++;

            // 主控版本号前6个字节
            p_version_index = &(g_battery_software_version[dev_id].master_software_version[0]);
            len = 6;
        }
        else if (2 == pack_num)
        {
            offset++;

            // 主控版本号后4个字节
            p_version_index = &(g_battery_software_version[dev_id].master_software_version[6]);
            len = 4;
        }
        else if (3 == pack_num)
        {
            offset++; // module_num = p_rxframe->data[offset++];

            // 从控版本号前6个字节
            p_version_index = &(g_battery_software_version[dev_id].slave_software_version[0]);
            len = 6;
        }
        else if (4 == pack_num)
        {
            offset++; // module_num = p_rxframe->data[offset++];
            
            // 赋值从控版本号后4个字节
            p_version_index = &(g_battery_software_version[dev_id].slave_software_version[6]);
            len = 4;
        }
        else if (5 == pack_num)
        {
            // 项目软件版本号
            g_battery_cluster_data[dev_id].software_version = (uint16_t) ((p_rxframe->data[offset + 3] << 8) \
                                                                          | (p_rxframe->data[offset + 4]));
            
            p_version_index = &(g_battery_software_version[dev_id].project_software_version[0]);
            len = LENGTH_VERSION_P;
        }
        else
        {
            return;
        }

        if (NULL == p_version_index)
        {
            return;
        }
        
        memcpy(p_version_index, &(p_rxframe->data[offset]), len);
        g_battery_software_version[dev_id].receive_completion_flag |= (1 << (pack_num -1)); // 用于记录完整软件版本号是否获取完成

        // 电池软件版本号已获取完整，更新电池完整的软件版本号(字符串形式)
        if (0x1F == (g_battery_software_version[dev_id].receive_completion_flag))
        {
            battery_software_version_update(dev_id);
        }

        // 测试用
        uint8_t i = 0;
        BATTERY_DEBUG_PRINT((int8_t *)"\n cluster id = %d master_software_version = ", dev_id);
        for (i = 0; i < 10; i++)
        {
            BATTERY_DEBUG_PRINT((int8_t *)" %x ", (g_battery_software_version[dev_id].master_software_version[i]));
        }
        BATTERY_DEBUG_PRINT((int8_t *)"\n");

        // BATTERY_DEBUG_PRINT((int8_t *)"\n slave_software_version = ");
        // for (i = 0; i < 10; i++)
        // {
        //     BATTERY_DEBUG_PRINT((int8_t *)" %x ", (g_battery_software_version[dev_id].slave_software_version[i]));
        // }
        // BATTERY_DEBUG_PRINT((int8_t *)"\n");
        // BATTERY_DEBUG_PRINT((int8_t *)"\n project_software_version = ");
        // for (i = 0; i < 6; i++)
        // {
        //     BATTERY_DEBUG_PRINT((int8_t *)" %x ", (g_battery_software_version[dev_id].project_software_version[i]));
        // }
        // BATTERY_DEBUG_PRINT((int8_t *)"\n");
    }
}

/**
 * @brief   电池数据更新
 * @param   [in] dev_id   电池簇地址索引
 * @return  
 * @note    对输入的设备序号dev_id参数对应的电池设备数据进行更新
 */
static void battery_data_update(uint8_t dev_id)
{
    uint8_t  i = 0;
    uint8_t  index = 0;
    uint16_t len = 0;
    uint16_t SOC_sum = 0;
    uint16_t SOH_sum = 0;
    int16_t voltage_sum = 0;
    int16_t current_sum = 0;
    int16_t current = 0;
    int16_t voltage = 0;
    int32_t power = 0;

    telemetry_data_t *p_telemetry_all = sdk_shm_telemetry_data_get();
    internal_shared_data_t *p_internal_data = internal_shared_data_get();  // 内部共用参数
    internal_version_info_t *p_version_info = internal_version_info_get();  // 内部版本信息
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    if ((dev_id >= BCU_DEVICE_NUM) || (NULL == p_telemetry_all) || (NULL == p_internal_data) || (NULL == p_version_info))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    battery_cluster_data_t *p_data = &g_battery_cluster_data[dev_id];
    battery_cluster_telematic_info_t *p_telematic_data = sdk_shm_battery_cluster_telematic_info_get(dev_id); // 电池簇遥信
    battery_cluster_telemetry_info_t *p_telemetry_data = sdk_shm_battery_cluster_telemetry_info_get(dev_id); // 电池簇遥测
    battery_parameter_data_t *p_battery_para_data = sdk_shm_battery_parameter_data_get(dev_id);              // 电池簇定值参数

    if ((NULL == p_data) || (NULL == p_telematic_data) || (NULL == p_telemetry_data) || (NULL == p_battery_para_data))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    // 更新集装箱内电池簇的遥信信息 到 共享内存
    memcpy((p_telematic_data->battery_cluster_warn_info), (p_data->battery_cluster_warn_info), \
            BATTERY_CLUSTER_WARN_LEN_BYTE);

    memcpy((p_telematic_data->battery_cluster_fault_info), (p_data->battery_cluster_fault_info), \
            BATTERY_CLUSTER_FAULT_LEN_BYTE);
    
    memcpy((p_telematic_data->battery_cluster_status_info), (p_data->battery_cluster_status_info), \
            BATTERY_CLUSTER_STATUS_LEN_BYTE);

    // 更新集装箱内电池簇的遥测信息 到 共享内存
    len = sizeof(battery_cluster_telemetry_info_t) - sizeof(p_telemetry_data->reserve);
    memcpy(&(p_telemetry_data->software_version), &(p_data->software_version), len);

     /*SOH告警*/
    if(p_data->average_SOH_monomer < p_para_data->eol_threshold)
    {
        p_telematic_data->battery_cluster_warn_info[9] |= (1<<1);
    }
    else
    {
        p_telematic_data->battery_cluster_warn_info[9] &= ~(1<<1);
    }

    // 更新电池类型
    p_telemetry_all->container_system_telemetry_info.battery_type = p_data->battery_type;
    
    // 更新电池软件、硬件版本号
    p_version_info->bat_software_version[0] = g_battery_software_version[0].project_software_version[3];
    p_version_info->bat_software_version[1] = g_battery_software_version[0].project_software_version[4];
    p_version_info->bat_hardware_version[0] = BAT_HARDWARE_MAJOR_VERSION;
    p_version_info->bat_hardware_version[1] = BAT_HARDWARE_MINOR_VERSION;
    
    // 更新总压、总电流、充放电功率
    len = g_battery_comm_info.connect_num;
    if ((len > BCU_DEVICE_NUM) || (len == 0))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] connect_num error \n", __func__, __LINE__);
        return;
    }
    
    for (i = 0; i < len; i++)
    {
        index = g_battery_comm_info.battery_id_connect[i];
        if (index >= BCU_DEVICE_NUM)
        {
            BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] battery_id_connect error \n", __func__, __LINE__);
            return;
        }
        current = -(((g_battery_cluster_data[index].cluster_current) - 16000) / 10);
        voltage = (g_battery_cluster_data[index].cluster_voltage) / 10;

        // current = (g_battery_cluster_data[index].cluster_current) - 16000;
        // voltage = g_battery_cluster_data[index].cluster_voltage;

        current_sum += current;
        voltage_sum += voltage;

        power += (current * voltage) ; // 单位 w
        SOC_sum += (g_battery_cluster_data[index].cluster_SOC) * 10; 
        SOH_sum += (g_battery_cluster_data[index].average_SOH_monomer) * 10;
    }

    p_telemetry_all->container_system_telemetry_info.total_voltage = (voltage_sum / (g_battery_comm_info.connect_num)); // V
    p_telemetry_all->container_system_telemetry_info.total_current = current_sum;       // A
    p_telemetry_all->container_system_telemetry_info.charge_discharge_power = power / 1000;    // kw
    p_telemetry_all->container_system_telemetry_info.soc = (SOC_sum / (g_battery_comm_info.connect_num)); // 分辨率 0.1%
    p_telemetry_all->container_system_telemetry_info.soh = (SOH_sum / (g_battery_comm_info.connect_num)); // 分辨率 0.1%

    // printf("\n total_voltage = %d \n", p_telemetry_all->container_system_telemetry_info.total_voltage);
    // printf("\n total_current = %d \n", p_telemetry_all->container_system_telemetry_info.total_current);
    // printf("\n charge_discharge_power = %d \n", p_telemetry_all->container_system_telemetry_info.charge_discharge_power);
    // printf("\n SOC = %d \n", p_telemetry_all->container_system_telemetry_info.soc);
    // printf("\n SOH = %d \n", p_telemetry_all->container_system_telemetry_info.soh);

    // 更新电池充、放电量
    p_internal_data->cluster_daily_charging_energy[dev_id] = p_data->daily_charging_energy;
    p_internal_data->cluster_daily_discharge_energy[dev_id] = p_data->daily_discharge_energy;
    p_internal_data->cluster_total_charging_energy[dev_id] = p_data->total_charging_energy;
    p_internal_data->cluster_total_discharge_energy[dev_id] = p_data->total_discharge_energy;

    // 测试代码
    // for (i = 0; i < BCU_DEVICE_NUM; i++)
    // {
    //     BATTERY_DEBUG_PRINT((int8_t *) "\n cluster id = %d, cluster_daily_charging_energy = %d \n", i, p_internal_data->cluster_daily_charging_energy[i]);
    //     BATTERY_DEBUG_PRINT((int8_t *) "\n cluster id = %d, cluster_daily_discharge_energy = %d \n", i, p_internal_data->cluster_daily_discharge_energy[i]);
    //     BATTERY_DEBUG_PRINT((int8_t *) "\n cluster id = %d, cluster_total_charging_energy = %d \n", i, p_internal_data->cluster_total_charging_energy[i]);
    //     BATTERY_DEBUG_PRINT((int8_t *) "\n cluster id = %d, cluster_total_discharge_energy = %d \n", i, p_internal_data->cluster_total_discharge_energy[i]);
    // }
}

/**
 * @brief    CAN通信数据解析
 * @param    [in] p_rxframe 基本CAN帧结构
 * @return   无
 * @note     对从CAN通信中读取到的一帧数据（CAN数据帧），根据标识符ID中包含的命令码进行解析
 */
static void battery_data_info_analysis(sdk_can_frame_t *p_rxframe)
{
    can_frame_id_u can_frame_id = {0};
    uint8_t dev_id = 0;
    uint8_t function_id = 0;

    if (NULL == p_rxframe)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }
    
    can_frame_id.id_val = p_rxframe->id;
	
    dev_id = can_frame_id.bit.src_addr - ADDR_CAN_BATTERY;
    function_id = can_frame_id.bit.fun_code;

    if(((can_frame_id.bit.dst_addr != ADDR_CAN_CMU1) && (can_frame_id.bit.dst_addr != ADDR_CAN_BROADCAST)) \
        || (dev_id > (BCU_DEVICE_NUM - 1)))
    {
        return;
    }

    BATTERY_DEBUG_PRINT((int8_t *)"\n addr = %x, function_id = %x \n", can_frame_id.bit.src_addr, function_id);

    if (function_id <= 0x2F)                                    // 配置表类
    {
        config_table_response_data_analysis(dev_id, function_id, p_rxframe);
    }
    else if ((function_id >= 0x30) && (function_id <= 0x3D))    // 电池信息数据类
    {
        battery_monomer_data_analysis(dev_id, function_id, p_rxframe);
    }
    else if (POLE_TEMPERATURE == function_id)                   // 极柱温度
    {
        pole_temperature_unpack(dev_id, p_rxframe);
    }
    else if ((function_id >= 0x40) && (function_id <= 0x47))    // 版本控制类
    {
        version_info_analysis(dev_id, function_id, p_rxframe);
    }
    else if (BATTERY_INSULATION_DETECTION_CTRL == function_id)  // 电池主控绝缘检测状态
    {
        battery_insulation_detection_unpack(dev_id, p_rxframe);
    }
    else
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] undefined function_id = %d\n", __func__, __LINE__, function_id);
        return;
    }

    // 更新数据到共享内存
    battery_data_update(dev_id);

    // 清除通信中断标志，清零通信中断计数
    g_battery_comm_info.battery_connect_flag[dev_id] = BATTERY_CONNECT;  // 标记此电池簇已连接成功
    g_battery_comm_info.battery_comm_err_cnt[dev_id] = 0;
    g_battery_comm_info.battery_comm_break[dev_id] = 0;
}

/** 
 * @brief   电池通信状态更新
 * @param
 * @return
 * @note    判断通信中断逻辑：1S超时计数，所有簇的超时次数每1S增加一次，每当收到电池簇的数据，在can帧解析函数中，
 *          将对应簇的超时次数清零，一旦超时次数超过设置的最大值15，说明已经有15S没收到该簇的信息，认为该簇已失联
 */
static void battery_comm_status_update(void)
{
    uint8_t bcu_break_flag = 0;
    uint8_t bat_number = 0;
    uint8_t count = 0;
    uint16_t i = 0;
    int32_t ret = 0;
    // static sdk_rtc_t now = {0, 0, 1, 1, 1, 1, 1};
    // sdk_rtc_t temp = {0, 0, 1, 1, 1, 1, 1}; // 测试用
    sdk_rtc_t *p_start_time = NULL;
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();   // 共享内存-遥信数据
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();   // 共享内存-遥测
    battery_cluster_telemetry_info_t *p_bat_telemetry = NULL;

    // sdk_rtc_get(RTC_BIN_FORMAT, &temp); // 测试用
    // printf("\n temp = %d-%d-%d %d:%d:%d %d \n", temp.tm_year, temp.tm_mon, temp.tm_day, temp.tm_hour, temp.tm_min, temp.tm_sec, temp.tm_weekday); // 测试用
    p_start_time = &g_rtc_time;
    if ((NULL == p_start_time) || (NULL == p_telematic_data) ||(NULL == p_telemetry_data))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"\n [%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }
    
    ret = sdk_is_time_over(p_start_time, 1); // 1s计数一次
    // BATTERY_DEBUG_PRINT((int8_t *)"\n sdk_is_time_over ret = %d \n", ret);   // 测试用
    // BATTERY_DEBUG_PRINT((int8_t *)"\n now = %d-%d-%d %d:%d:%d %d \n", now.tm_year, now.tm_mon, now.tm_day, now.tm_hour, now.tm_min, now.tm_sec, now.tm_weekday); // 测试用
    
    if (1 == ret) // 已到1s
    {
        ret = sdk_rtc_get(RTC_BIN_FORMAT, &g_rtc_time);
        if (ret)
        {
            BATTERY_DEBUG_PRINT((int8_t *)"\n [%s:%d] sdk_rtc_get fail \n", __func__, __LINE__);
            return;
        }

        // BATTERY_DEBUG_PRINT((int8_t *)"\n now = %d-%d-%d %d:%d:%d %d \n", now.tm_year, now.tm_mon, now.tm_day, now.tm_hour, now.tm_min, now.tm_sec, now.tm_weekday); // 测试用
        // printf((int8_t *)"\n CAN 1s time over \n");   // 测试用
        for (i = 0; i < BCU_DEVICE_NUM; i++)
        {
            if (BATTERY_CONNECT == g_battery_comm_info.battery_connect_flag[i])  // 该簇电池曾经连接过
            {
                g_battery_comm_info.battery_comm_err_cnt[i]++;
            }

            // MCU1给BCU的查询包 平均约37ms一帧，查询完一簇至少860ms，查询10簇至少8.6S, 暂定CAN通讯中断时间至少大于15S. 1S * 15 = 15S
            if (g_battery_comm_info.battery_comm_err_cnt[i] >= COMM_ERROR_CNT_MAX)
            {
                g_battery_comm_info.battery_comm_err_cnt[i] = COMM_ERROR_CNT_MAX;
                g_battery_comm_info.battery_comm_break[i] = BATTERY_COMM_BREAK;    // 通信中断置位

                // CMU与第i簇BCU通讯故障(2级) 置位 battery_cluster_warn_info[9]-bit0
                g_battery_cluster_data[i].charge_disable = 1;
                g_battery_cluster_data[i].discharge_disable = 1;
                p_telematic_data->battery_cluster_telematic_info[i].battery_cluster_warn_info[9] |= (1 << 0);
                BATTERY_DEBUG_PRINT((int8_t *)"\n CAN BCU[%d] Break! \n", i);   // 测试用
            }
            else
            {
                // g_battery_cluster_data[i].charge_disable = 0;
                // g_battery_cluster_data[i].discharge_disable = 0;
                p_telematic_data->battery_cluster_telematic_info[i].battery_cluster_warn_info[9] &= ~(1 << 0);
            }
        }
    }

    // 更新BCU通信状态到共享内存，计算当前在线的BCU数量
    for (i = 0; i < BCU_DEVICE_NUM; i++)
    {
        if (BATTERY_COMM_BREAK == g_battery_comm_info.battery_comm_break[i])
        {
            bcu_break_flag = 1;
            g_battery_cluster_data[i].BCU_comm_status = BCU_COMM_BREAK;
            g_battery_comm_info.battery_id_connect[count] = i;
            count++;
        }
        else if (BATTERY_CONNECT != g_battery_comm_info.battery_connect_flag[i])
        {
            g_battery_cluster_data[i].BCU_comm_status = BCU_NOT_CONNECT;
        }
        else
        {
            g_battery_cluster_data[i].BCU_comm_status = BCU_COMM_NORMAL;
            g_battery_comm_info.battery_id_connect[count] = i;
            count++;
            bat_number++; // 当前在线
        }

        p_bat_telemetry = sdk_shm_battery_cluster_telemetry_info_get(i); // 电池簇遥测
        if (NULL == p_bat_telemetry)
        {
            BATTERY_DEBUG_PRINT((int8_t *)"\n [%s:%d] Null pointer \n", __func__, __LINE__);
            continue;
        }

        p_bat_telemetry->BCU_comm_status = g_battery_cluster_data[i].BCU_comm_status;
    }

    // 更新在线的电池簇数量、已连接的电池数量
    p_telemetry_data->container_system_telemetry_info.battery_cluster_number = bat_number;
    g_battery_comm_info.connect_num = count;

    if (bcu_break_flag) // 存在一簇失联就置位
    {
        // CMU系统中 BCU通信故障 置位 CMU_system_fault_info[0]-bit5
        p_telematic_data->CMU_system_fault_info[0] |= (1 << 5);
    }
    else
    {
        p_telematic_data->CMU_system_fault_info[0] &= ~(1 << 5);
    }
}

/** 
 * @brief   电池数据读取处理线程
 * @param
 * @return
 */
void *thread_can_battery_read(void *arg)
{
    uint8_t flag = 0;
    int32_t ret = 0;
    static uint16_t can_break_cnt = 0;
    sdk_can_frame_t rxframe;
    sdk_can_cfg_t can_cfg;

    can_cfg.baud = SDK_CAN_BAUD_250K;
    can_cfg.mode = SDK_CAN_MODE_NORMAL;

    sdk_can_open(CAN_PORT_BATTERY);
    if (sdk_can_setup(CAN_PORT_BATTERY, &can_cfg) < 0)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"\n open CAN_battery fail! \n");
        pthread_exit(NULL);
    }
    
    battery_comm_read_param_init();

    while (1)
    {
        memset(&rxframe, 0, sizeof(sdk_can_frame_t));
        ret = sdk_can_read(CAN_PORT_BATTERY, &rxframe, 1, BATTERY_COMM_TIMEOUT_MS);
        if (ret > 0)
        {
            battery_data_info_analysis(&rxframe);

            flag = 1;
            can_break_cnt = 0;
        }
        else
        {
            if (flag == 1)
            {
                can_break_cnt++;
                if (can_break_cnt >= 50)
                {
                    BATTERY_DEBUG_PRINT((int8_t *)"\n CAN reboot \n");
                    can_break_cnt = 50;

                    sdk_can_close(CAN_PORT_BATTERY);
                    sdk_can_open(CAN_PORT_BATTERY);
                    if (sdk_can_setup(CAN_PORT_BATTERY, &can_cfg) < 0)
                    {
                        BATTERY_DEBUG_PRINT((int8_t *)"\n open CAN_battery fail! \n");
                    }
                }
            }
        }

        battery_comm_status_update(); // BCU通信状态更新
        battery_charge_discharge_disable_set(); // 电池禁充、禁放标志置位

        usleep(1000 * 5);    // 5ms fix me!!!
    }
    
    pthread_exit(NULL);
}

/** 
 * @brief   电池数据读取（CAN通讯）任务启动
 * @param
 * @return
 */
void battery_read_task_start(void)
{
    int16_t ret = 0;
    pthread_attr_t battery_read_attr;
    pthread_t can_battery_read;

    // 初始化线程属性
    ret = pthread_attr_init(&battery_read_attr);
    if (ret)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"\n [%s:%d] pthread_attr_init error!!! \n", __func__, __LINE__);
        return; // 线程属性初始化出错退出
    }
    
    // 设置线程属性为分离状态
    ret = pthread_attr_setdetachstate(&battery_read_attr, PTHREAD_CREATE_DETACHED);
    if (ret)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"\n [%s:%d] pthread_attr_setdetachstate battery_read_attr error!!! \n", __func__, __LINE__);
        return; // 线程分离属性设置出错退出
    }

    // 创建线程
    ret = pthread_create(&can_battery_read, &battery_read_attr, &thread_can_battery_read, NULL);
    if (ret)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"\n [%s:%d] pthread_create can_battery_read error!!! \n", __func__, __LINE__);
        return; // 线程创建出错退出
    }

    // 销毁线程属性结构,它在重新初始化之前不能重新使用
    pthread_attr_destroy(&battery_read_attr);
}

/**
 * @brief    所有簇电池主控软件版本号确认
 * @param    
 * @return   主控版本号确认结果
 * @retval   OBJ_VERSION_NORMAL(0)      所有电池簇的主控版本号一致
 * @retval   OBJ_VERSION_UN_NORMAL(1)   至少有一簇的主控版本号不一致
 * @note     
 */
uint8_t battery_master_software_version_check(void)
{
    uint8_t i = 0;
    uint8_t flag = DISABLE;
    uint8_t index = 0;
    uint16_t temp = 0;
    uint8_t *p_master_ver = NULL;
    int16_t result = -1;
    uint8_t ret = OBJ_VERSION_NORMAL;

    if ((0 == g_battery_comm_info.connect_num) || (g_battery_comm_info.connect_num > BCU_DEVICE_NUM))
    {
        goto __exit;
    }
    
    for (i = 0; i < (g_battery_comm_info.connect_num); i++)
    {
        index = g_battery_comm_info.battery_id_connect[i];
        if (index >= BCU_DEVICE_NUM)
        {
            goto __exit;
        }
        
        // 查询是否所有电池簇的主控版本号均已获取完整 bit0/bit1均已置位
        temp = (g_battery_software_version[index].receive_completion_flag) & 0x03;
        if (0x03 != temp)
        {
            flag = ENABLE;
            break;
        }
    }
     
    if (ENABLE == flag) // 还有簇的版本号还未获取完整
    {
        goto __exit;
    }

    // 所有已连接的簇 主控版本号均已获取成功，验证版本号是否一致
    for (i = 0; i < (g_battery_comm_info.connect_num); i++)
    {
        index = g_battery_comm_info.battery_id_connect[i];
        if (index >= BCU_DEVICE_NUM)
        {
            goto __exit;
        }

        p_master_ver = &(g_battery_software_version[index].master_software_version[0]);
        if (NULL == p_master_ver)
        {
            BATTERY_DEBUG_PRINT((int8_t *)"\n [%s:%d] Null pointer \n", __func__, __LINE__);
            goto __exit;
        }
        
        temp = g_battery_comm_info.battery_id_connect[0];
        result = memcmp(&(g_battery_software_version[temp].master_software_version[0]), \
                        p_master_ver, LENGTH_VERSION_M_S);

        if (result)
        {
            BATTERY_DEBUG_PRINT((int8_t *)"\n master_software_version is inconsistent! cluster id = %x \n", i); // 测试用
            ret = OBJ_VERSION_UN_NORMAL;
            goto __exit;
        }
        else
        {
            ret = OBJ_VERSION_NORMAL;
        }
    }

__exit:
    return ret;
}


/** 
 * @brief   获取集装箱内电池簇数据缓存结构体的首地址
 * @param   
 * @return  &g_battery_cluster_data[0]
 * @note    g_battery_cluster_data[BCU_DEVICE_NUM] 数组的下标 0~9，
 *          分别对应电池簇地址 0xE1~0xEA
 */
battery_cluster_data_t *battery_cluster_data_get(void)
{
    return (&g_battery_cluster_data[0]);
}

/** 
 * @brief   获取电池通信参数结构体的地址
 * @param
 * @return
 */
battery_comm_info_t *battery_comm_info_get(void)
{
    return (&g_battery_comm_info);
}

