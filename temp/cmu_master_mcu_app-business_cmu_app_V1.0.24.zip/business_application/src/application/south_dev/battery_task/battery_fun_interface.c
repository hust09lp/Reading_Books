/** 
 * @file          battery_fun_interface.c
 * @brief         电池通信功能外部接口实现
 * @author        xiaojuying
 * @note
 * @version       V0.0.1     初版
 * @date          2023/2/9
 */


#include "battery_fun_interface.h"
#include "process_battery_read.h"
#include "param_record_task.h"
#include "cmu_sys_state.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "sofar_log.h"
#include "sdk_public.h"
#include "sdk_can.h"
#include "sofar_errors.h"
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <stdio.h>


static pthread_mutex_t g_can_battery_mutex;


/**
 * @brief    CAN发送指令CAN ID 和 dlc打包
 * @param    [in] p_txframe     基本CAN帧结构
 * @param    [in] dst_addr      目的地址
 * @param    [in] function_id   命令码
 * @param    [in] priority      优先级 0~7
 * @return   
 * @note
 */
static void battery_can_send_frame_pack(sdk_can_frame_t *p_txframe, uint8_t dst_addr, \
                                        uint8_t function_id, can_fun_prio_e priority)
{
    can_frame_id_u can_frame_id = {0};
    if ((NULL == p_txframe) || (priority > 7))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }
    
    can_frame_id.bit.src_addr = ADDR_CAN_CMU1; 
    can_frame_id.bit.dst_addr = dst_addr;
    can_frame_id.bit.fun_code = function_id;
    can_frame_id.bit.prio = priority;
    can_frame_id.bit.flag = 1;

    p_txframe->id = can_frame_id.id_val;
    p_txframe->len = 8;
    // BATTERY_DEBUG_PRINT((int8_t *)"\n p_txframe->id = %02x \n", p_txframe->id); // 测试用
}

/** 
 * @brief   控制电池主控上下电指令(0x80)
 * @param   [in] command_type 命令类型 1：上电 2：下电 3：所有簇故障下电，其他：无效
 * @param   [in] object  操作对象 0: 所有簇执行 1~20 对应簇执行
 * @return
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败
 * @note    CMU系统状态处于故障状态时，不允许发送电池簇上电指令
 */
int16_t battery_power_control(control_command_type_e command_type, uint8_t object)
{
    uint8_t rc = 0;
    int16_t ret = -1;
    int32_t result = -1;
    sdk_can_frame_t txframe;
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();

    if ((NULL == p_telemetry_data) || (command_type >= CONTROL_COMMAND_TYPE_MAX))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return SF_ERR_PARA;
    }
    
    memset((txframe.data), 0x00, sizeof(txframe.data));
    txframe.data[0] = command_type;
    txframe.data[1] = object;

    // CMU系统状态处于故障状态时，不允许发送电池簇上电指令
    if ((CMU_SYS_STATE_FAULT == (p_telemetry_data->cmu_telemetry_info.cmu_sys_state)) \
        && (POWER_ON == command_type))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"\n CMU system is in a faulty state, the battery cluster is not allowed to power on! \n");
        ret = SF_ERR_FNOSUPP;
    }
    log_i((int8_t *)"\n battery_power_control: command_type = %d \n", command_type);
    
    // CAN ID: 0x0880FFF4
    battery_can_send_frame_pack(&txframe, ADDR_CAN_BROADCAST, BATTERY_POWER_CONTROL, PRIO_THIRD_HIGH);

    while (rc < 3)
    {
        pthread_mutex_lock(&g_can_battery_mutex);
        result = sdk_can_write(CAN_PORT_BATTERY, &txframe, 1);
        pthread_mutex_unlock(&g_can_battery_mutex);

        usleep(1000 * 10);

        if (result > 0)
        {
            ret = SF_OK;
            break;
        }
        else
        {
            ret = result;
        }

        BATTERY_DEBUG_PRINT((int8_t *)"\n battery power control can write error!!! \n"); // 测试用
        rc++;
    }

    return ret;
}

/** 
 * @brief   控制电池主控绝缘检测功能指令(0x81)
 * @param   [in] dev_id     上位机下发的设备序号(0~N) N为电池簇数量-1
 * @param   [in] on_off     true：开启绝缘检测  false：关闭绝缘检测
 * @return
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败
 */
int32_t battery_insulation_detection_control(uint8_t dev_id, bool on_off)
{
    uint8_t dst_addr = dev_id + ADDR_CAN_BATTERY; // 电池簇地址
    uint8_t rc = 0;
    int16_t ret = -1;
    int32_t result = -1;
    sdk_can_frame_t txframe;

    if (dev_id > (BCU_DEVICE_NUM - 1))
    {
        log_i((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    memset((txframe.data), 0x00, sizeof(txframe.data));
    if (on_off)
    {
        txframe.data[0] = 1;    // 1：开启绝缘检测
    }
    else
    {
        txframe.data[0] = 2;    // 2：关闭绝缘检测
    }

    log_i((int8_t *)"\n battery_insulation_detection_control: on_off = %d \n", on_off);
    
    // CAN ID: 0x0880FFF4
    battery_can_send_frame_pack(&txframe, dst_addr, BATTERY_INSULATION_DETECTION_CTRL, PRIO_THIRD_HIGH);

    while (rc < 3)
    {
        pthread_mutex_lock(&g_can_battery_mutex);
        result = sdk_can_write(CAN_PORT_BATTERY, &txframe, 1);
        pthread_mutex_unlock(&g_can_battery_mutex);

        usleep(1000 * 10);

        if (result > 0)
        {
            ret = SF_OK;
            break;
        }
        else
        {
            ret = result;
        }

        BATTERY_DEBUG_PRINT((int8_t *)"\n battery power control can write error!!! \n"); // 测试用
        rc++;
    }

    return ret;
}

/** 
 * @brief   控制BCU辅电继电器开关指令(0x81)
 * @param   [in] dev_id     上位机下发的设备序号(0~N) N为电池簇数量-1
 * @param   [in] on_off     1：闭合辅电继电器  2：断开辅电继电器
 * @return
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败
 */
int32_t battery_auxpower_relay_control(uint8_t dev_id, bool on_off)
{
    uint8_t dst_addr = dev_id + ADDR_CAN_BATTERY; // 电池簇地址
    uint8_t rc = 0;
    int16_t ret = -1;
    int32_t result = -1;
    sdk_can_frame_t txframe;

    if (dev_id > (BCU_DEVICE_NUM - 1))
    {
        log_i((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    memset((txframe.data), 0x00, sizeof(txframe.data));
    if (on_off)
    {
        txframe.data[1] = 1;    // 1：闭合辅助继电器
    }
    else
    {
        txframe.data[1] = 2;    // 2：断开辅助继电器
    }
    
    // CAN ID: 0x0880FFF4
    battery_can_send_frame_pack(&txframe, dst_addr, BATTERY_AUXPOWER_RELAY_CTRL, PRIO_THIRD_HIGH);

    while (rc < 3)
    {
        pthread_mutex_lock(&g_can_battery_mutex);
        result = sdk_can_write(CAN_PORT_BATTERY, &txframe, 1);
        pthread_mutex_unlock(&g_can_battery_mutex);

        usleep(1000 * 10);

        if (result > 0)
        {
            ret = SF_OK;
            break;
        }
        else
        {
            ret = result;
        }

        BATTERY_DEBUG_PRINT((int8_t *)"\n battery auxpower relay control can write error!!! \n"); // 测试用
        rc++;
    }

    return ret;
}

/** 
 * @brief   配置表--组端总电压上限报警值设置指令打包
 * @param   [in] p_txframe    基本CAN帧结构
 * @param   [in] dst_addr     目的地址
 * @return
 */
static void cluster_OVP_warn_value_pack(sdk_can_frame_t *p_txframe, uint8_t dst_addr)
{
    uint8_t offset = 0;
    uint8_t dev_id = dst_addr - ADDR_CAN_BATTERY;
    battery_parameter_data_t *p_para_data = sdk_shm_battery_parameter_data_get(dev_id); // 集装箱内电池簇的定值/参数
    
    if ((NULL == p_txframe) || (NULL == p_para_data) || (dev_id > (BCU_DEVICE_NUM - 1)))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }
    
    memset((p_txframe->data), 0xFF, sizeof(p_txframe->data));
    p_txframe->data[offset++] = (uint8_t)((p_para_data->cluster_OVP_warn_threshold_1) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->cluster_OVP_warn_threshold_1);
    p_txframe->data[offset++] = (uint8_t)((p_para_data->cluster_OVP_warn_threshold_2) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->cluster_OVP_warn_threshold_2);
    p_txframe->data[offset++] = (uint8_t)((p_para_data->cluster_OVP_warn_threshold_3) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->cluster_OVP_warn_threshold_3);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->cluster_OVP_warn_hysteresis_err);

    battery_can_send_frame_pack(p_txframe, dst_addr, CLUSTER_OVP_WARN_VALUE, PRIO_SECOND_LOW);
}

/** 
 * @brief   配置表--组端总电压下限报警值设置指令打包
 * @param   [in] p_txframe    基本CAN帧结构
 * @param   [in] dst_addr     目的地址
 * @return
 */
static void cluster_UVP_warn_value_pack(sdk_can_frame_t *p_txframe, uint8_t dst_addr)
{
    uint8_t offset = 0;
    uint8_t dev_id = dst_addr - ADDR_CAN_BATTERY;
    battery_parameter_data_t *p_para_data = sdk_shm_battery_parameter_data_get(dev_id); // 集装箱内电池簇的定值/参数
    
    if ((NULL == p_txframe) || (NULL == p_para_data) || (dev_id > (BCU_DEVICE_NUM - 1)))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }    

    memset((p_txframe->data), 0xFF, sizeof(p_txframe->data));
    p_txframe->data[offset++] = (uint8_t)((p_para_data->cluster_UVP_warn_threshold_1) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->cluster_UVP_warn_threshold_1);
    p_txframe->data[offset++] = (uint8_t)((p_para_data->cluster_UVP_warn_threshold_2) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->cluster_UVP_warn_threshold_2);
    p_txframe->data[offset++] = (uint8_t)((p_para_data->cluster_UVP_warn_threshold_3) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->cluster_UVP_warn_threshold_3);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->cluster_UVP_warn_hysteresis_err);

    battery_can_send_frame_pack(p_txframe, dst_addr, CLUSTER_UVP_WARN_VALUE, PRIO_SECOND_LOW);
}

/** 
 * @brief   配置表--充电电流报警值设置指令打包
 * @param   [in] p_txframe    基本CAN帧结构
 * @param   [in] dst_addr     目的地址
 * @param   [in] charge_type  充电类型 1：快充  2：慢充/极柱过温  3：馈电  // fix me!!!
 * @return
 */
static void charge_OCP_warn_value_pack(sdk_can_frame_t *p_txframe, uint8_t dst_addr, uint8_t charge_type)
{
    uint8_t offset = 0;
    uint8_t dev_id = dst_addr - ADDR_CAN_BATTERY;
    battery_parameter_data_t *p_para_data = sdk_shm_battery_parameter_data_get(dev_id); // 集装箱内电池簇的定值/参数
    
    if ((NULL == p_txframe) || (NULL == p_para_data) || (dev_id > (BCU_DEVICE_NUM - 1)))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    memset((p_txframe->data), 0xFF, sizeof(p_txframe->data));
    p_txframe->data[offset++] = charge_type;

    if (1 == charge_type)
    {
        p_txframe->data[offset++] = (uint8_t)((p_para_data->charge_OCP_warn_threshold_1) >> 8);
        p_txframe->data[offset++] = (uint8_t)(p_para_data->charge_OCP_warn_threshold_1);
        p_txframe->data[offset++] = (uint8_t)((p_para_data->charge_OCP_warn_threshold_2) >> 8);
        p_txframe->data[offset++] = (uint8_t)(p_para_data->charge_OCP_warn_threshold_2);
        p_txframe->data[offset++] = (uint8_t)((p_para_data->charge_OCP_warn_threshold_3) >> 8);
        p_txframe->data[offset++] = (uint8_t)(p_para_data->charge_OCP_warn_threshold_3);
        p_txframe->data[offset++] = (uint8_t)(p_para_data->charge_OCP_warn_hysteresis_err);
    }

    battery_can_send_frame_pack(p_txframe, dst_addr, CHARGE_OCP_WARN_VALUE, PRIO_SECOND_LOW);
}

/** 
 * @brief   配置表--放电电流报警值设置指令打包
 * @param   [in] p_txframe    基本CAN帧结构
 * @param   [in] dst_addr     目的地址
 * @return
 */
static void discharge_OCP_warn_value_pack(sdk_can_frame_t *p_txframe, uint8_t dst_addr)
{
    uint8_t offset = 0;
    uint8_t dev_id = dst_addr - ADDR_CAN_BATTERY;
    battery_parameter_data_t *p_para_data = sdk_shm_battery_parameter_data_get(dev_id); // 集装箱内电池簇的定值/参数
    
    if ((NULL == p_txframe) || (NULL == p_para_data) || (dev_id > (BCU_DEVICE_NUM - 1)))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    memset((p_txframe->data), 0xFF, sizeof(p_txframe->data));
    p_txframe->data[offset++] = (uint8_t)((p_para_data->discharge_OCP_warn_threshold_1) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->discharge_OCP_warn_threshold_1);
    p_txframe->data[offset++] = (uint8_t)((p_para_data->discharge_OCP_warn_threshold_2) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->discharge_OCP_warn_threshold_2);
    p_txframe->data[offset++] = (uint8_t)((p_para_data->discharge_OCP_warn_threshold_3) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->discharge_OCP_warn_threshold_3);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->discharge_OCP_warn_hysteresis_err);

    battery_can_send_frame_pack(p_txframe, dst_addr, DISCHARGE_OCP_WARN_VALUE, PRIO_SECOND_LOW);
}

/** 
 * @brief   配置表--充电单体电池温度报警值设置指令打包
 * @param   [in] p_txframe    基本CAN帧结构
 * @param   [in] dst_addr     目的地址
 * @return
 */
static void charge_monomer_temp_warn_value_pack(sdk_can_frame_t *p_txframe, uint8_t dst_addr)
{
    uint8_t offset = 0;
    uint8_t dev_id = dst_addr - ADDR_CAN_BATTERY;
    battery_parameter_data_t *p_para_data = sdk_shm_battery_parameter_data_get(dev_id); // 集装箱内电池簇的定值/参数
    
    if ((NULL == p_txframe) || (NULL == p_para_data) || (dev_id > (BCU_DEVICE_NUM - 1)))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    memset((p_txframe->data), 0xFF, sizeof(p_txframe->data));
    p_txframe->data[offset++] = (uint8_t)(p_para_data->charge_monomer_OTP_warn_threshold_1);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->charge_monomer_OTP_warn_threshold_2);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->charge_monomer_OTP_warn_threshold_3);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->charge_monomer_OTP_warn_hysteresis_err);

    p_txframe->data[offset++] = (uint8_t)(p_para_data->charge_monomer_UTP_warn_threshold_1);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->charge_monomer_UTP_warn_threshold_2);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->charge_monomer_UTP_warn_threshold_3);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->charge_monomer_UTP_warn_hysteresis_err);
    
    battery_can_send_frame_pack(p_txframe, dst_addr, CHARGE_MONOMER_TEMP_WARN_VALUE, PRIO_SECOND_LOW);
}

/** 
 * @brief   配置表--单体电池温差报警值设置指令打包
 * @param   [in] p_txframe    基本CAN帧结构
 * @param   [in] dst_addr     目的地址
 * @return
 */
static void monomer_temp_diff_warn_value_pack(sdk_can_frame_t *p_txframe, uint8_t dst_addr)
{
    uint8_t offset = 0;
    uint8_t dev_id = dst_addr - ADDR_CAN_BATTERY;
    battery_parameter_data_t *p_para_data = sdk_shm_battery_parameter_data_get(dev_id); // 集装箱内电池簇的定值/参数
    
    if ((NULL == p_txframe) || (NULL == p_para_data) || (dev_id > (BCU_DEVICE_NUM - 1)))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    memset((p_txframe->data), 0xFF, sizeof(p_txframe->data));
    p_txframe->data[offset++] = (uint8_t)(p_para_data->monomer_temp_diff_warn_threshold_1);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->monomer_temp_diff_warn_threshold_2);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->monomer_temp_diff_warn_threshold_3);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->monomer_temp_diff_warn_hysteresis_err);
    
    battery_can_send_frame_pack(p_txframe, dst_addr, MONOMER_TEMP_DIFF_WARN_VALUE, PRIO_SECOND_LOW);
}

/** 
 * @brief   配置表--SOC 报警值设置指令打包
 * @param   [in] p_txframe      基本CAN帧结构
 * @param   [in] dev_id         电池簇编号
 * @param   [in] warn_type      告警类型 1：下限值 2：上限值 3：差异值
 * @return
 */
static void SOC_warn_value_pack(sdk_can_frame_t *p_txframe, uint8_t warn_type, uint8_t dev_id)
{
    uint8_t offset = 0;
    battery_parameter_data_t *p_para_data = sdk_shm_battery_parameter_data_get(dev_id); // 集装箱内电池簇的定值/参数

    if ((NULL == p_txframe) || (NULL == p_para_data) || (dev_id > (BCU_DEVICE_NUM - 1)))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    memset((p_txframe->data), 0xFF, sizeof(p_txframe->data));
    p_txframe->data[offset++] = (uint8_t) warn_type;

    if (1 == warn_type)
    {
        p_txframe->data[offset++] = (uint8_t)(p_para_data->SOC_low_warn_threshold_1);
        p_txframe->data[offset++] = (uint8_t)(p_para_data->SOC_low_warn_threshold_2);
        p_txframe->data[offset++] = (uint8_t)(p_para_data->SOC_low_warn_threshold_3);
        p_txframe->data[offset++] = (uint8_t)(p_para_data->SOC_low_warn_hysteresis_err);
    }
    else if (2 == warn_type)
    {
        p_txframe->data[offset++] = (uint8_t)(p_para_data->SOC_high_warn_threshold_1);
        p_txframe->data[offset++] = (uint8_t)(p_para_data->SOC_high_warn_threshold_2);
        p_txframe->data[offset++] = (uint8_t)(p_para_data->SOC_high_warn_threshold_3);
        p_txframe->data[offset++] = (uint8_t)(p_para_data->SOC_high_warn_hysteresis_err);
    }
    else if (3 == warn_type)
    {
        p_txframe->data[offset++] = (uint8_t)(p_para_data->SOC_diff_warn_threshold_1);
        p_txframe->data[offset++] = (uint8_t)(p_para_data->SOC_diff_warn_threshold_2);
        p_txframe->data[offset++] = (uint8_t)(p_para_data->SOC_diff_warn_threshold_3);
        p_txframe->data[offset++] = (uint8_t)(p_para_data->SOC_diff_warn_hysteresis_err);
    }
    else
    {
        return;
    }
}

/** 
 * @brief   配置表--SOC 报警值设置
 * @param   [in] p_txframe    基本CAN帧结构
 * @param   [in] dst_addr     目的地址
 * @return
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败
 */
static int16_t SOC_warn_value_set(sdk_can_frame_t *p_txframe, uint8_t dst_addr)
{
    uint8_t warn_type = 1;  // 告警类型 1：下限值 2：上限值 3：差异值
    uint8_t rc = 0;
    uint8_t i = 0;
    uint8_t dev_id = dst_addr - ADDR_CAN_BATTERY;
    int16_t ret = -1;
    int32_t result = -1;

    if ((NULL == p_txframe) || (dev_id > (BCU_DEVICE_NUM - 1)))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    for (i = 0; i < 3; i++)
    {
        rc = 0;
        warn_type = i + 1; // 告警类型 1：下限值 2：上限值 3：差异值
        SOC_warn_value_pack(p_txframe, warn_type, dev_id);
        battery_can_send_frame_pack(p_txframe, dst_addr, SOC_WARN_VALUE, PRIO_SECOND_LOW);

        while (rc < 3)
        {
            pthread_mutex_lock(&g_can_battery_mutex);
            result = sdk_can_write(CAN_PORT_BATTERY, p_txframe, 1);
            pthread_mutex_unlock(&g_can_battery_mutex);

            usleep(1000 * 300);

            if (result > 0)
            {
                ret = SF_OK;
                break;
            }
            else
            {
                ret = result;
            }

            BATTERY_DEBUG_PRINT((int8_t *)"\n SOC warn value set can write error!!! \n"); // 测试用
            rc++;
        }
    }
    
    return ret;
}

/** 
 * @brief   配置表--绝缘电阻报警值设置指令打包
 * @param   [in] p_txframe    基本CAN帧结构
 * @param   [in] dst_addr     目的地址
 * @return
 */
static void ISO_warn_value_pack(sdk_can_frame_t *p_txframe, uint8_t dst_addr)
{
    uint8_t offset = 0;
    uint8_t dev_id = dst_addr - ADDR_CAN_BATTERY;
    battery_parameter_data_t *p_para_data = sdk_shm_battery_parameter_data_get(dev_id); // 集装箱内电池簇的定值/参数
    
    if ((NULL == p_txframe) || (NULL == p_para_data) || (dev_id > (BCU_DEVICE_NUM - 1)))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    memset((p_txframe->data), 0xFF, sizeof(p_txframe->data));
    p_txframe->data[offset++] = (uint8_t)((p_para_data->ISO_warn_threshold_1) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->ISO_warn_threshold_1);
    p_txframe->data[offset++] = (uint8_t)((p_para_data->ISO_warn_threshold_2) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->ISO_warn_threshold_2);
    p_txframe->data[offset++] = (uint8_t)((p_para_data->ISO_warn_threshold_3) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->ISO_warn_threshold_3);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->ISO_warn_hysteresis_err);

    battery_can_send_frame_pack(p_txframe, dst_addr, ISO_WARN_VALUE, PRIO_SECOND_LOW);
}

/** 
 * @brief   配置表--电池单体电压上限报警值设置指令打包
 * @param   [in] p_txframe    基本CAN帧结构
 * @param   [in] dst_addr     目的地址
 * @return
 */
static void monomer_OVP_warn_value_pack(sdk_can_frame_t *p_txframe, uint8_t dst_addr)
{
    uint8_t offset = 0;
    uint8_t dev_id = dst_addr - ADDR_CAN_BATTERY;
    battery_parameter_data_t *p_para_data = sdk_shm_battery_parameter_data_get(dev_id); // 集装箱内电池簇的定值/参数
    
    if ((NULL == p_txframe) || (NULL == p_para_data) || (dev_id > (BCU_DEVICE_NUM - 1)))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    memset((p_txframe->data), 0xFF, sizeof(p_txframe->data));
    p_txframe->data[offset++] = (uint8_t)((p_para_data->monomer_OVP_warn_threshold_1) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->monomer_OVP_warn_threshold_1);
    p_txframe->data[offset++] = (uint8_t)((p_para_data->monomer_OVP_warn_threshold_2) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->monomer_OVP_warn_threshold_2);
    p_txframe->data[offset++] = (uint8_t)((p_para_data->monomer_OVP_warn_threshold_3) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->monomer_OVP_warn_threshold_3);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->monomer_OVP_warn_hysteresis_err);

    battery_can_send_frame_pack(p_txframe, dst_addr, MONOMER_OVP_WARN_VALUE, PRIO_SECOND_LOW);
}

/** 
 * @brief   配置表--电池单体电压上限报警值设置指令打包
 * @param   [in] p_txframe    基本CAN帧结构
 * @param   [in] dst_addr     目的地址
 * @return
 */
static void monomer_UVP_warn_value_pack(sdk_can_frame_t *p_txframe, uint8_t dst_addr)
{
    uint8_t offset = 0;
    uint8_t dev_id = dst_addr - ADDR_CAN_BATTERY;
    battery_parameter_data_t *p_para_data = sdk_shm_battery_parameter_data_get(dev_id); // 集装箱内电池簇的定值/参数
    
    if ((NULL == p_txframe) || (NULL == p_para_data) || (dev_id > (BCU_DEVICE_NUM - 1)))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    memset((p_txframe->data), 0xFF, sizeof(p_txframe->data));
    p_txframe->data[offset++] = (uint8_t)((p_para_data->monomer_UVP_warn_threshold_1) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->monomer_UVP_warn_threshold_1);
    p_txframe->data[offset++] = (uint8_t)((p_para_data->monomer_UVP_warn_threshold_2) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->monomer_UVP_warn_threshold_2);
    p_txframe->data[offset++] = (uint8_t)((p_para_data->monomer_UVP_warn_threshold_3) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->monomer_UVP_warn_threshold_3);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->monomer_UVP_warn_hysteresis_err);

    battery_can_send_frame_pack(p_txframe, dst_addr, MONOMER_UVP_WARN_VALUE, PRIO_SECOND_LOW);
}

/** 
 * @brief   配置表--电池单体电压压差报警值设置指令打包
 * @param   [in] p_txframe    基本CAN帧结构
 * @param   [in] dst_addr     目的地址
 * @return
 */
static void monomer_vol_diff_warn_value_pack(sdk_can_frame_t *p_txframe, uint8_t dst_addr)
{
    uint8_t offset = 0;
    uint8_t dev_id = dst_addr - ADDR_CAN_BATTERY;
    battery_parameter_data_t *p_para_data = sdk_shm_battery_parameter_data_get(dev_id); // 集装箱内电池簇的定值/参数
    
    if ((NULL == p_txframe) || (NULL == p_para_data) || (dev_id > (BCU_DEVICE_NUM - 1)))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    memset((p_txframe->data), 0xFF, sizeof(p_txframe->data));
    p_txframe->data[offset++] = (uint8_t)((p_para_data->monomer_vol_diff_warn_threshold_1) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->monomer_vol_diff_warn_threshold_1);
    p_txframe->data[offset++] = (uint8_t)((p_para_data->monomer_vol_diff_warn_threshold_2) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->monomer_vol_diff_warn_threshold_2);
    p_txframe->data[offset++] = (uint8_t)((p_para_data->monomer_vol_diff_warn_threshold_3) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->monomer_vol_diff_warn_threshold_3);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->monomer_vol_diff_warn_hysteresis_err);

    battery_can_send_frame_pack(p_txframe, dst_addr, MONOMER_VOL_DIFF_WARN_VALUE, PRIO_SECOND_LOW);
}

/** 
 * @brief   配置表--模块温度上限设置指令打包
 * @param   [in] p_txframe    基本CAN帧结构
 * @param   [in] dst_addr     目的地址
 * @return
 */
static void module_temp_warn_value_pack(sdk_can_frame_t *p_txframe, uint8_t dst_addr)
{
    uint8_t offset = 0;
    uint8_t dev_id = dst_addr - ADDR_CAN_BATTERY;
    battery_parameter_data_t *p_para_data = sdk_shm_battery_parameter_data_get(dev_id); // 集装箱内电池簇的定值/参数
    
    if ((NULL == p_txframe) || (NULL == p_para_data) || (dev_id > (BCU_DEVICE_NUM - 1)))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    memset((p_txframe->data), 0xFF, sizeof(p_txframe->data));
    p_txframe->data[offset++] = (uint8_t)(p_para_data->PACK_temp_diff_warn_threshold_1);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->PACK_temp_diff_warn_threshold_2);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->PACK_temp_diff_warn_threshold_3);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->PACK_temp_diff_warn_hysteresis_err);
    
    battery_can_send_frame_pack(p_txframe, dst_addr, MODULE_TEMP_WARN_VALUE, PRIO_SECOND_LOW);
}

/** 
 * @brief   配置表--放电单体电池温度报警值设置指令打包
 * @param   [in] p_txframe    基本CAN帧结构
 * @param   [in] dst_addr     目的地址
 * @return
 */
static void discharge_monomer_temp_warn_value_pack(sdk_can_frame_t *p_txframe, uint8_t dst_addr)
{
    uint8_t offset = 0;
    uint8_t dev_id = dst_addr - ADDR_CAN_BATTERY;
    battery_parameter_data_t *p_para_data = sdk_shm_battery_parameter_data_get(dev_id); // 集装箱内电池簇的定值/参数
    
    if ((NULL == p_txframe) || (NULL == p_para_data) || (dev_id > (BCU_DEVICE_NUM - 1)))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }

    memset((p_txframe->data), 0xFF, sizeof(p_txframe->data));
    p_txframe->data[offset++] = (uint8_t)(p_para_data->discharge_monomer_OTP_warn_threshold_1);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->discharge_monomer_OTP_warn_threshold_2);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->discharge_monomer_OTP_warn_threshold_3);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->discharge_monomer_OTP_warn_hysteresis_err);

    p_txframe->data[offset++] = (uint8_t)(p_para_data->discharge_monomer_UTP_warn_threshold_1);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->discharge_monomer_UTP_warn_threshold_2);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->discharge_monomer_UTP_warn_threshold_3);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->discharge_monomer_UTP_warn_hysteresis_err);
    
    battery_can_send_frame_pack(p_txframe, dst_addr, DISCHARGE_MONOMER_TEMP_WARN_VALUE, PRIO_SECOND_LOW);
}

/** 
 * @brief   配置表--电池模组电压上限报警值设置指令打包
 * @param   [in] p_txframe    基本CAN帧结构
 * @param   [in] dst_addr     目的地址
 * @return
 */
static void PACK_OVP_warn_value_pack(sdk_can_frame_t *p_txframe, uint8_t dst_addr)
{
    uint8_t offset = 0;
    uint8_t dev_id = dst_addr - ADDR_CAN_BATTERY;
    battery_parameter_data_t *p_para_data = sdk_shm_battery_parameter_data_get(dev_id); // 集装箱内电池簇的定值/参数
    
    if ((NULL == p_txframe) || (NULL == p_para_data) || (dev_id > (BCU_DEVICE_NUM - 1)))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }
    
    memset((p_txframe->data), 0xFF, sizeof(p_txframe->data));
    p_txframe->data[offset++] = (uint8_t)((p_para_data->PACK_OVP_warn_threshold_1) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->PACK_OVP_warn_threshold_1);
    p_txframe->data[offset++] = (uint8_t)((p_para_data->PACK_OVP_warn_threshold_2) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->PACK_OVP_warn_threshold_2);
    p_txframe->data[offset++] = (uint8_t)((p_para_data->PACK_OVP_warn_threshold_3) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->PACK_OVP_warn_threshold_3);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->PACK_OVP_warn_hysteresis_err);

    battery_can_send_frame_pack(p_txframe, dst_addr, PACK_OVP_WARN_VALUE, PRIO_SECOND_LOW);
}

/** 
 * @brief   配置表--电池模组电压下限报警值设置指令打包
 * @param   [in] p_txframe    基本CAN帧结构
 * @param   [in] dst_addr     目的地址
 * @return
 */
static void PACK_UVP_warn_value_pack(sdk_can_frame_t *p_txframe, uint8_t dst_addr)
{
    uint8_t offset = 0;
    uint8_t dev_id = dst_addr - ADDR_CAN_BATTERY;
    battery_parameter_data_t *p_para_data = sdk_shm_battery_parameter_data_get(dev_id); // 集装箱内电池簇的定值/参数
    
    if ((NULL == p_txframe) || (NULL == p_para_data) || (dev_id > (BCU_DEVICE_NUM - 1)))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return;
    }    

    memset((p_txframe->data), 0xFF, sizeof(p_txframe->data));
    p_txframe->data[offset++] = (uint8_t)((p_para_data->PACK_UVP_warn_threshold_1) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->PACK_UVP_warn_threshold_1);
    p_txframe->data[offset++] = (uint8_t)((p_para_data->PACK_UVP_warn_threshold_2) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->PACK_UVP_warn_threshold_2);
    p_txframe->data[offset++] = (uint8_t)((p_para_data->PACK_UVP_warn_threshold_3) >> 8);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->PACK_UVP_warn_threshold_3);
    p_txframe->data[offset++] = (uint8_t)(p_para_data->PACK_UVP_warn_hysteresis_err);

    battery_can_send_frame_pack(p_txframe, dst_addr, PACK_UVP_WARN_VALUE, PRIO_SECOND_LOW);
}

/** 
 * @brief   配置表数据查询指令 下发函数接口
 * @param   [in] dev_id         上位机下发的设备序号(0~N) N为电池簇数量-1
 * @param   [in] config_type    需要查询的配置数据的类型->对应配置表命令码
 * @return
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败
 * @note     配置表查询，只在接收到上位机的配置查询指令的时候需要下发，
 *           由104的通信线程调用
 */
int16_t battery_config_table_query(uint8_t dev_id, uint8_t config_type)
{
    uint8_t dst_addr = dev_id + ADDR_CAN_BATTERY; // 电池簇地址
    uint8_t offset = 0;
    uint8_t rc = 0;
    // uint8_t j = 0;
    int16_t ret = -1;
    int32_t result = -1;
    sdk_can_frame_t txframe;
    // constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 共享内存定值/参数

    if (dev_id > (BCU_DEVICE_NUM - 1))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return SF_ERR_PARA;
    }
    
    memset((txframe.data), 0xFF, sizeof(txframe.data));

    txframe.data[offset++] = config_type;

    if (HARDWARE_INFO_MODULE == txframe.data[0]) 
    {
        txframe.data[offset] = 1; // 模块地址
    }
    else if (CHARGE_OCP_WARN_VALUE == txframe.data[0])
    {
        txframe.data[offset] = 1; // 充电类型 1: 快充  2: 极柱过温  3: 馈电 fix me!!!
    }

    battery_can_send_frame_pack(&txframe, dst_addr, CONFIG_TABLE_QUERY, PRIO_SECOND_LOW);

    // for (j = 0; j < 8; j++)
    // {
    //     BATTERY_DEBUG_PRINT((int8_t *)"\n txframe.data[%d] = %02x \n", j, txframe.data[j]); // 测试用
    // }

    while (rc < 3)
    {
        pthread_mutex_lock(&g_can_battery_mutex);
        result = sdk_can_write(CAN_PORT_BATTERY, &txframe, 1);
        pthread_mutex_unlock(&g_can_battery_mutex);

        usleep(1000 * 10);

        if (result > 0)
        {
            ret = SF_OK;
            break;
        }
        else
        {
            ret = result;
        }

        BATTERY_DEBUG_PRINT((int8_t *)"\n config table data query can write error!!! \n"); // 测试用
        rc++;
    }

    return ret;
}

/** 
 * @brief   配置表类设置指令 下发函数接口
 * @param   [in] dev_id         上位机下发的设备序号(0~N) N为电池簇数量-1
 * @param   [in] function_id    功能码
 * @return  
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败
 * @note     配置表设置，只在接收到上位机的配置设置指令的时候需要下发，由104的通信线程调用
 *           特别注意：电池主控的参数保存在内部 Flash 中，因此参数设置命令需要间隔 300 ms
 */
int16_t battery_config_table_set(uint8_t dev_id, uint8_t function_id)
{
    uint8_t dst_addr = dev_id + ADDR_CAN_BATTERY; // 电池簇地址
    uint8_t rc = 0;
    int16_t ret = -1;
    int32_t result = -1;
    sdk_can_frame_t txframe;

    if (dev_id > (BCU_DEVICE_NUM - 1))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    // 备注：电池主控的参数保存在内部 Flash 中，因此参数设置命令需要间隔 300 ms
    if (CLUSTER_OVP_WARN_VALUE == function_id)
    {
        cluster_OVP_warn_value_pack(&txframe, dst_addr);
    }
    else if (CLUSTER_UVP_WARN_VALUE == (function_id))
    {
        cluster_UVP_warn_value_pack(&txframe, dst_addr);
    }
    else if (CHARGE_OCP_WARN_VALUE == (function_id))
    {
        // 暂时项目需求只需要设置快充的阈值
        charge_OCP_warn_value_pack(&txframe, dst_addr, 1);
    }
    else if (DISCHARGE_OCP_WARN_VALUE == (function_id))
    {
        discharge_OCP_warn_value_pack(&txframe, dst_addr);
    }
    else if (CHARGE_MONOMER_TEMP_WARN_VALUE == (function_id))
    {
        charge_monomer_temp_warn_value_pack(&txframe, dst_addr);
    }
    else if (MONOMER_TEMP_DIFF_WARN_VALUE == (function_id))
    {
        monomer_temp_diff_warn_value_pack(&txframe, dst_addr);
    }
    else if (SOC_WARN_VALUE == (function_id))
    {
        ret = SOC_warn_value_set(&txframe, dst_addr); // 函数内已包含打包和发送
        return ret;
    }
    else if (ISO_WARN_VALUE == (function_id))
    {
        ISO_warn_value_pack(&txframe, dst_addr);
    }
    else if (MONOMER_OVP_WARN_VALUE == (function_id))
    {
        monomer_OVP_warn_value_pack(&txframe, dst_addr);
    }
    else if (MONOMER_UVP_WARN_VALUE == (function_id))
    {
        monomer_UVP_warn_value_pack(&txframe, dst_addr);
    }
    else if (MONOMER_VOL_DIFF_WARN_VALUE == (function_id))
    {
        monomer_vol_diff_warn_value_pack(&txframe, dst_addr);
    }
    else if (MODULE_TEMP_WARN_VALUE == (function_id))
    {
        module_temp_warn_value_pack(&txframe, dst_addr);
    }
    else if (DISCHARGE_MONOMER_TEMP_WARN_VALUE == (function_id))
    {
        discharge_monomer_temp_warn_value_pack(&txframe, dst_addr);
    }
    else if (PACK_OVP_WARN_VALUE == (function_id))
    {
        PACK_OVP_warn_value_pack(&txframe, dst_addr);
    }
    else if (PACK_UVP_WARN_VALUE == (function_id))
    {
        PACK_UVP_warn_value_pack(&txframe, dst_addr);
    }
    else
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] undefined function_id = %d\n", __func__, __LINE__, function_id);
        return (-1);
    }

    while (rc < 3)
    {
        pthread_mutex_lock(&g_can_battery_mutex);
        result = sdk_can_write(CAN_PORT_BATTERY, &txframe, 1);
        pthread_mutex_unlock(&g_can_battery_mutex);

        usleep(1000 * 300);

        if (result > 0)
        {
            ret = SF_OK;
            break;
        }
        else
        {
            ret = result;
        }

        BATTERY_DEBUG_PRINT((int8_t *)"\n config table data set can write error!!! \n"); // 测试用
        rc++;
    }

    return ret;
}

/** 
 * @brief   版本信息查询指令 下发函数接口
 * @param   [in] dev_id     上位机下发的设备序号(0~N) N为电池簇数量-1
 * @param   [in] object     查询对象 0x01-主控  0x02-从控
 * @return
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败
 * @note     版本信息查询，只在接收到查询版本号的指令的时候需要下发，由其他进/线程调用
 */
int16_t battery_version_info_query(uint8_t dev_id, uint8_t object)
{
    uint8_t offset = 0;
    uint8_t rc = 0;
    uint8_t i = 0;
    uint16_t pack_num = 0;
    int16_t ret = -1;
    int32_t result = -1;
    sdk_can_frame_t txframe;
    uint8_t dst_addr = dev_id + ADDR_CAN_BATTERY; // 电池簇地址
    battery_cluster_telemetry_info_t *p_telemetry_data = sdk_shm_battery_cluster_telemetry_info_get(dev_id); // 电池簇 遥测

    if ((dev_id > (BCU_DEVICE_NUM - 1)) || (NULL == p_telemetry_data) \
        || ((OBJ_BATTERY_MASTER_VERSION != object) && (OBJ_BATTERY_SLAVE_VERSION != object)))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return SF_ERR_PARA;
    }
    
    memset((txframe.data), 0xFF, sizeof(txframe.data));
    txframe.data[offset++] = object;

    if (OBJ_BATTERY_MASTER_VERSION == object)
    {
        pack_num = 1;
    }
    else if (OBJ_BATTERY_SLAVE_VERSION == object)
    {
        // pack_num = p_telemetry_data->PACK_number_in_cluster;
        pack_num = 1; // 目前一簇内的所有pack的从控版本号一致，故暂时一簇里只查询其中一个从控版本号
    }

    for (i = 0; i < pack_num; i++)
    {
        rc = 0;

        // 当txframe.data[0]为0x02时，txframe.data[1] 为模块地址 1~N (N为一簇内PACK数量)
        if (OBJ_BATTERY_SLAVE_VERSION == object)
        {
            txframe.data[offset] = 1 + i;
        }
        
        battery_can_send_frame_pack(&txframe, dst_addr, VERSION_QUERY, PRIO_SECOND_LOW);

        while (rc < 3)
        {
            pthread_mutex_lock(&g_can_battery_mutex);
            result = sdk_can_write(CAN_PORT_BATTERY, &txframe, 1);
            pthread_mutex_unlock(&g_can_battery_mutex);

            usleep(1000 * 10);
            if (result > 0)
            {
                ret = SF_OK;
                break;
            }
            else
            {
                ret = result;
            }

            BATTERY_DEBUG_PRINT((int8_t *)"\n battery version info query can write error!!! \n"); // 测试用
            rc++;
        }        
    }
    
    return ret;
}

/** 
 * @brief   控制模块DO输出
 * @param   [in] dev_id     上位机下发的设备序号(0~N) N为电池簇数量-1
 * @param   [in] port       端口号0~7，对应DO1~DO8
 * @param   [in] cmd        需要下发的具体命令 0-输出无效  1-输出有效
 * @return
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败
 * @note     只在接收到上位机控制DO输出指令的时候需要下发，由104的通信进程调用
 */
int16_t set_DO_output(uint8_t dev_id, uint8_t port, uint8_t cmd)
{
    uint8_t rc = 0;
    uint8_t offset = 0;
    uint8_t dst_addr = dev_id + ADDR_CAN_BATTERY;  // 电池簇地址
    int16_t ret = -1;
    int32_t result = -1;
    sdk_can_frame_t txframe;

    if ((dev_id > (BCU_DEVICE_NUM - 1)) || (port > 7) || (cmd > 1))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    memset((txframe.data), 0xFF, sizeof(txframe.data));
    txframe.data[offset++] = (cmd << port);
    txframe.data[offset++] = 0;
    txframe.data[offset++] = 0;
    battery_can_send_frame_pack(&txframe, dst_addr, SET_DO_OUTPUT_COMMAND, PRIO_SECOND_LOW);

    while (rc < 3)
    {
        pthread_mutex_lock(&g_can_battery_mutex);
        result = sdk_can_write(CAN_PORT_BATTERY, &txframe, 1);
        pthread_mutex_unlock(&g_can_battery_mutex);

        usleep(1000 * 10);
        if (result > 0)
        {
            ret = SF_OK;
            break;
        }
        else
        {
            ret = result;
        }

        BATTERY_DEBUG_PRINT((int8_t *)"\n set DO output can write error!!! \n"); // 测试用
        rc++;
    }

    return ret;
}

/**
 * @brief    电池CAN通信电池单体数据获取
 * @param    [in] dev_id    设备序号(0~N) N为电池簇数量-1
 * @param    [in] data_type 信息类型 详见 battery_data_type_e
 * @return   
 * @retval   SF_OK(0)   成功
 * @retval   <0         失败
 * @note     电池信息类 的数据，需要定时获取并更新到共享内存，以供存储。
 *           （获取频率还需商榷！！！）
 */
int16_t battery_monomer_data_query(uint8_t dev_id, uint8_t data_type)
{
    uint8_t rc = 0;
    uint16_t i = 0;
    uint16_t wait_time = (1000 * 20);
    // uint8_t j = 0;
    int16_t ret = -1;
    int32_t result = -1;
    sdk_can_frame_t txframe;
    uint16_t pack_number = 0;
    uint8_t dst_addr = dev_id + ADDR_CAN_BATTERY;
    battery_cluster_telemetry_info_t *p_battery_data = NULL;

    if (dev_id > (BCU_DEVICE_NUM - 1))
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] illegal parameter!\n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    p_battery_data = sdk_shm_battery_cluster_telemetry_info_get(dev_id);
    if (NULL == p_battery_data)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return SF_ERR_SEEK;
    }

    if (BATTERY_MONOMER_VOL == (data_type))
    {
        pack_number = (p_battery_data->total_battery_number) / 60;
        if (((p_battery_data->total_battery_number) % 60) != 0)
        {
            pack_number++;
        }
    }
    else if (BATTERY_MONOMER_TEMP == (data_type))
    {
        pack_number = (p_battery_data->total_temperature_number) / 120;
        if (((p_battery_data->total_temperature_number) % 120) != 0)
        {
            pack_number++;
        }
    }
    else if ((BATTERY_MONOMER_SOC == (data_type)) || (BATTERY_MONOMER_SOH == (data_type)))
    {
        pack_number = (p_battery_data->total_battery_number) / 120;
        if (((p_battery_data->total_battery_number) % 120) != 0)
        {
            pack_number++;
        }
    }
    else
    {
        pack_number = 1;
    }

    if (((data_type >= BATTERY_MONOMER_VOL) && (data_type <= SYSTEM_SUMMARY_DATA)) \
        || (BATTERY_DI_DO_INFO == data_type))
    {
        wait_time = (1000 * 40); // 详细单体数据量比较大，多等待一段时间
    }
    else
    {
        wait_time = (1000 * 20);
    }

    for (i = 0; i < pack_number; i++)
    {
        rc = 0;
        
        memset((txframe.data), 0xFF, sizeof(txframe.data));
        txframe.data[0] = data_type;

        if ((data_type >= BATTERY_MONOMER_VOL) && (data_type <= BATTERY_MONOMER_SOH))
        {
            txframe.data[1] = (i + 1);
        }
        
        battery_can_send_frame_pack(&txframe, dst_addr, BATTERY_MONOMER_INFO_QUERY, PRIO_SECOND_LOW);
        // for (j = 0; j < 8; j++)
        // {
        //     BATTERY_DEBUG_PRINT((int8_t *)"\n txframe.data[%d] = %02x \n", j, txframe.data[j]); // 测试用
        // }

        while (rc < 3)
        {
            pthread_mutex_lock(&g_can_battery_mutex);
            result = sdk_can_write(CAN_PORT_BATTERY, &txframe, 1);
            pthread_mutex_unlock(&g_can_battery_mutex);

            usleep(wait_time);
            if (result > 0)
            {
                ret = SF_OK;
                break;
            }
            else
            {
                ret = result;
            }
            
            BATTERY_DEBUG_PRINT((int8_t *)"\n battery monomer data query can write error!!! \n"); // 测试用
            rc++;
        }
    }

    return ret;
}

/** 
 * @brief   查询电池运行数据指令发送处理线程
 * @param
 * @return
 */
void *thread_can_battery_send(void *arg)
{
    uint8_t i = 0;
    uint8_t j = 0;
    uint8_t k = 0;
    int16_t ret = 0;
    static uint16_t flag = 0;
    battery_cluster_telemetry_info_t *p_bat_telemetry = NULL;
    battery_cluster_telemetry_info_t *p_temp_telemetry = NULL;

    // 互斥锁初始化
    ret = pthread_mutex_init(&g_can_battery_mutex, NULL);
    if (ret)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] init error!!! \n", __func__, __LINE__);
        pthread_exit(NULL);
    }
    
    usleep(1000 * 200); // 通讯板上电后 延时200ms再开始发送指令，否则前面几帧指令容易丢失

    while (1)
    {
        // 作为心跳帧，检测哪些BCU在线
        for (i = 0; i < BCU_DEVICE_NUM; i++)
        {
            battery_monomer_data_query(i, BATTERY_ALARM_INFO);
        }

        if (flag < 3)
        {
            // 优先满足系统控制线程开启电池前的检测需求，先获取 绝缘阻抗阈值、簇端电压、绝缘阻抗值、故障信息
            for (i = 0; i < BCU_DEVICE_NUM; i++)
            {
                battery_config_table_query(i, CLUSTER_OVP_WARN_VALUE);
                battery_config_table_query(i, CLUSTER_UVP_WARN_VALUE);
                battery_config_table_query(i, ISO_WARN_VALUE);
                battery_monomer_data_query(i, CLUSTER_BATTERY_DATA);
                // battery_monomer_data_query(i, BATTERY_ALARM_INFO);
            }

            flag++;
        }
        else if (flag < 6)
        {
            // 上电获取 电池软件版本号、电池的配置表信息、模块电池数量、模块温度个数 用于外部显示
            for (i = 0; i < BCU_DEVICE_NUM; i++)
            {
                battery_version_info_query(i, OBJ_BATTERY_MASTER_VERSION);
                battery_version_info_query(i, OBJ_BATTERY_SLAVE_VERSION);
                    
                for (j = CHARGE_OCP_WARN_VALUE; j <= MODULE_TEMP_WARN_VALUE; j++)
                {
                    battery_config_table_query(i, j);
                }
                battery_config_table_query(i, BATTERY_TYPE);
                battery_config_table_query(i, DISCHARGE_MONOMER_TEMP_WARN_VALUE);
                battery_config_table_query(i, PACK_OVP_WARN_VALUE);
                battery_config_table_query(i, PACK_UVP_WARN_VALUE);

                // 获取模块电池数量
                battery_monomer_data_query(i, BATTERY_NUMBER_MODULE);

                // 获取模块温度个数
                battery_monomer_data_query(i, TEMPERATURE_NUMBER_MODULE);
            }

            if (5 == flag)
            {
                battery_set_param_read_status_set(ENABLE); // 更新 电池设置参数读取状态 为读取完成
            }

            flag++;
        }
        else
        {
            // 循环获取每簇电池的实时运行数据
            for (i = 0; i < BCU_DEVICE_NUM; i++)
            {
                p_bat_telemetry = sdk_shm_battery_cluster_telemetry_info_get(i); // 电池簇遥测
                if (NULL == p_bat_telemetry)
                {
                    BATTERY_DEBUG_PRINT((int8_t *)"\n [%s:%d] Null pointer \n", __func__, __LINE__);
                    continue;
                }

                // 只获取已连接的电池簇数据
                if (BCU_NOT_CONNECT == (p_bat_telemetry->BCU_comm_status))
                {
                    continue;
                }
                
                for (j = BATTERY_MONOMER_VOL; j <= TEMPERATURE_NUMBER_MODULE; j++)
                {
                    /* 1、在查询当前电池簇的前五项电池单体数据（“电池单体电压”、“电池单体温度/极柱温度”、“电池单体SOC”、“电池单体SOH”、“主控采集信息”）前，
                       分别先插入查询电池簇1~5的“DI/DO状态信息”
                       2、第九项查询当前电池簇的电池单体数据（“DI/DO状态信息”）修改为查询最后一个电池簇（电池簇6）的，“DI/DO状态信息”
                    */
                    if ((j < BCU_DEVICE_NUM) || (j == BATTERY_DI_DO_INFO))
                    {
                        if (j < BCU_DEVICE_NUM)
                        {
                            k = j - 1;
                        }
                        else
                        {
                            k = BCU_DEVICE_NUM - 1;
                        }
                        p_temp_telemetry = sdk_shm_battery_cluster_telemetry_info_get(k); // 电池簇遥测
                        if (NULL != p_temp_telemetry)
                        {
                            if (BCU_NOT_CONNECT != (p_temp_telemetry->BCU_comm_status))
                            {
                                // log_i((int8_t *)"send BATTERY_DI_DO_INFO, k = %d \n", k);
                                battery_monomer_data_query(k, BATTERY_DI_DO_INFO);
                            }
                        }
                        if (j == BATTERY_DI_DO_INFO)
                        {
                            continue;
                        }
                    }

                    battery_monomer_data_query(i, j);
                }
            }
        }

        usleep(1000 * 20);
    }

    pthread_exit(NULL);
}


/** 
 * @brief   电池参数设置失败的处理
 * @param
 * @return
 * @note    检测电池返回帧的对应标志位，若检测到设置失败置位，则重新下发对应的阈值参数
 */
static void battery_param_set_fail_handle(void)
{
    uint8_t i = 0;
    uint8_t function_id = 0;
    uint8_t respond_flag = 0;
    battery_comm_info_t *p_battery_comm_info = battery_comm_info_get();

    if(NULL == p_battery_comm_info)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    for (i = 0; i < BCU_DEVICE_NUM; i++)
    {
        respond_flag = (uint8_t) (p_battery_comm_info->battery_respond_flag[i]);

        if (ENABLE == respond_flag)   // BMS反馈参数设置失败，重新下发设置指令
        {
            function_id = (uint8_t) ((p_battery_comm_info->battery_respond_flag[i]) >> 8);

            if (((function_id >= CLUSTER_OVP_WARN_VALUE) && (function_id <= MODULE_TEMP_WARN_VALUE)) \
                || (DISCHARGE_MONOMER_TEMP_WARN_VALUE == function_id) || (PACK_OVP_WARN_VALUE == function_id) \
                || (PACK_UVP_WARN_VALUE == function_id))
            {
                battery_config_table_set(i, function_id);
            }

            p_battery_comm_info->battery_respond_flag[i] = 0;
        }
    }
}

/** 
 * @brief   电池参数设置失败的处理线程
 * @param
 * @return
 */
void *thread_battery_param_set_detection(void *arg)
{
    usleep(1000 * 200); // 通讯板上电后 延时200ms再开始发送指令，否则前面几帧指令容易丢失

    while (1)
    {
        battery_param_set_fail_handle();
        sleep(2);   // 2S 查询一次
    }

    pthread_exit(NULL);
}

/** 
 * @brief   查询电池运行数据指令发送（CAN通讯）任务启动
 * @param
 * @return
 */
void battery_write_task_start(void)
{
    int16_t ret = 0;
    pthread_attr_t battery_write_attr;
    pthread_t can_battery_write;
    pthread_t battery_param_set;
    
    // 初始化线程属性
    ret = pthread_attr_init(&battery_write_attr);
    if (ret)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"\n [%s:%d] pthread_attr_init error!!! \n", __func__, __LINE__);
        return; // 线程属性初始化出错退出
    }
    
    // 设置线程属性为分离状态
    ret = pthread_attr_setdetachstate(&battery_write_attr, PTHREAD_CREATE_DETACHED);
    if (ret)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"\n [%s:%d] pthread_attr_setdetachstate battery_write_attr error!!! \n", __func__, __LINE__);
        return; // 线程分离属性设置出错退出
    }
    
    // 创建线程
    ret = pthread_create(&can_battery_write, &battery_write_attr, &thread_can_battery_send, NULL);
    if (ret)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"\n [%s:%d] pthread_create can_battery_write error!!! \n", __func__, __LINE__);
        return; // 线程创建出错退出
    }
    
    ret = pthread_create(&battery_param_set, &battery_write_attr, &thread_battery_param_set_detection, NULL);
    if (ret)
    {
        BATTERY_DEBUG_PRINT((int8_t *)"\n [%s:%d] pthread_create battery_param_set error!!! \n", __func__, __LINE__);
        return; // 线程创建出错退出
    }

    // 销毁线程属性结构,它在重新初始化之前不能重新使用
    pthread_attr_destroy(&battery_write_attr);
}


