/** 
 * @file          process_battery_read.h
 * @brief         电池数据读取线程外部接口
 * @author        xiaojuying
 * @note
 * @version       V0.0.1     初版
 * @date          2023/2/8
 */

#ifndef __PROCESS_BATTERY_READ_H__
#define __PROCESS_BATTERY_READ_H__

#include "data_types.h"
#include "data_shm.h"

#if (0)
#define BATTERY_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else 
#define BATTERY_DEBUG_PRINT(...) {do {} while(0);}
#endif


// 通讯地址
#define ADDR_CAN_BATTERY                0xE8            // 电池簇地址 0xE8~0xF1
#define ADDR_CAN_CMU1                   0xF4            // CMU MCU1的地址
#define ADDR_CAN_BROADCAST              0xFF            // 广播地址


// 虚拟CAN端口号 0: CAN1  1: CAN2
#define CAN_PORT_BATTERY                0               // 电池簇通信所用虚拟CAN端口号
#define BATTERY_COMM_TIMEOUT_MS         200             // 电池簇CAN通信超时时间 单位：ms

#define COMM_ERROR_CNT_MAX              15              // CAN通讯中断计数最大值
#define BATTERY_CONNECT                 1               // 电池簇已连接
#define BATTERY_COMM_BREAK              1               // 电池簇通信中断


// 高特电池命令码
// 配置表
#define HARDWARE_INFO_MASTER                (0x00)          // 主控硬件信息
#define BATTERY_NUM_TOTAL                   (0x01)          // 总电池节数
#define HARDWARE_INFO_MODULE                (0x02)          // 模块硬件信息
#define SENSOR_MESSAGE                      (0x03)          // 传感器报文
#define CLUSTER_OVP_WARN_VALUE              (0x04)          // 组端总电压上限报警值
#define CLUSTER_UVP_WARN_VALUE              (0x05)          // 组端总电压下限报警值
#define CHARGE_OCP_WARN_VALUE               (0x06)          // 充电电流报警值
#define DISCHARGE_OCP_WARN_VALUE            (0x07)          // 放电电流报警值
#define CHARGE_MONOMER_TEMP_WARN_VALUE      (0x08)          // 充电单体电池温度报警值(上限、下限)
#define MONOMER_TEMP_DIFF_WARN_VALUE        (0x09)          // 单体电池温差报警值
#define SOC_WARN_VALUE                      (0x0A)          // SOC 报警值
#define ISO_WARN_VALUE                      (0x0B)          // 绝缘电阻报警值 
#define MONOMER_OVP_WARN_VALUE              (0x0C)          // 电池单体电压上限报警值
#define MONOMER_UVP_WARN_VALUE              (0x0D)          // 电池单体电压下限报警值
#define MONOMER_VOL_DIFF_WARN_VALUE         (0x0E)          // 电池单体电压压差报警值
#define MODULE_TEMP_WARN_VALUE              (0x0F)          // 模块温度上限(模块温差上限)
#define BATTERY_TYPE                        (0x16)          // 电池主参数
#define DISCHARGE_MONOMER_TEMP_WARN_VALUE   (0x1C)          // 放电单体电池温度报警值(上限、下限)
#define CONFIG_TABLE_SET_ACK                (0x1E)          // 设置配置表操作的应答（成功/失败） 
#define CONFIG_TABLE_QUERY                  (0x1F)          // 配置表查询
#define PACK_OVP_WARN_VALUE                 (0x2B)          // 电池模组电压上限报警值
#define PACK_UVP_WARN_VALUE                 (0x2C)          // 电池模组电压下限报警值

// 电池数据
#define BATTERY_MONOMER_INFO_QUERY          (0x30)          // 请求电池采集消息
#define MONOMER_VOLTAGE                     (0x31)          // 电池单体电压
#define MONOMER_TEMPERATURE                 (0x32)          // 电池单体温度
#define MONOMER_SOC                         (0x33)          // 电池单体 SOC
#define MONOMER_SOH                         (0x34)          // 电池单体 SOH
#define CLUSTER_BATTERY_INFO                (0x35)          // 主控采集信息
#define SYSTEM_SUMMARY_INFO                 (0x36)          // 系统概要信息
#define BATTERY_NUM_MODULE                  (0x37)          // 模块电池节数
#define BATTERY_WARN_FAULT_INFO             (0x38)          // 电池报警/故障信息
#define DI_DO_INFO                          (0x39)          // DI/DO 信息
#define TEMPERATURE_NUM_MODULE              (0x3A)          // 模块温度个数信息
#define POLE_TEMPERATURE                    (0xB2)          // 电池极柱温度

// 版本号
#define VERSION_QUERY                       (0x40)          // 请求查询版本号
#define VERSION_INFO_ACK                    (0x41)          // 返回版本号消息

// 测试类
#define FORCE_EQUALIZE_COMMAND              (0x52)          // 发送强制均衡命令
#define SET_DO_OUTPUT_COMMAND               (0x57)          // 发送设置 EVBCM 模块 DO 输出命令
#define EQUALIZATION_CONTACTOR_CONTROL      (0x80)          // 请求控制均衡和接触器
#define OPERATION_DATA_QUERY                (0x70)          // 发送读取运行数据命令码
#define RESPOND_OPERATION_DATA              (0x71)          // 返回运行数据
#define BATTERY_INSULATION_DETECTION_CTRL   (0x81)          // 控制电池主控绝缘检测功能开启或关闭（电池簇主控高压上电之后听从EMS指令控制）
#define BATTERY_AUXPOWER_RELAY_CTRL         (0x81)          // 控制辅电继电器开关

// 控制指令
#define BATTERY_POWER_CONTROL               (0x80)          // 控制电池主控上下电


#define OBJ_VERSION_NORMAL                  (0)             // 版本号正常
#define OBJ_VERSION_UN_NORMAL               (1)             // 版本号异常
#define LENGTH_VERSION_M_S                  (10)            // 主/从控软件版本号长度
#define LENGTH_VERSION_P                    (6)             // 项目软件版本号长度

#define BAT_HARDWARE_MAJOR_VERSION          (0)             // 电池硬件大版本
#define BAT_HARDWARE_MINOR_VERSION          (1)             // 电池硬件小版本

#define BATTERY_WARN_1_LEN                  (3)             // 电池0x38命令码上报的1级告警位的字节数
#define BATTERY_WARN_2_LEN                  (3)             // 电池0x38命令码上报的2级告警位的字节数
#define BATTERY_WARN_3_LEN                  (3)             // 电池0x38命令码上报的3级告警位的字节数
#define BATTERY_FAULT_LEN                   (4)             // 电池0x38命令码上报的设备硬件故障位的字节数

#define BATT_INSULATION_DETECTION_CTRL_OPEN     (1)         // 绝缘检测开启
#define BATT_INSULATION_DETECTION_CTRL_CLOSE    (2)         // 绝缘检测关闭



// can frame id
typedef union{
    uint32_t id_val;
    struct{
        uint32_t src_addr:  8;  // source address
        uint32_t dst_addr:  8;  // destination address
        uint32_t fun_code:  8;  // < CAN Frame function code
        uint32_t data_page: 1;  // < CAN Frame Data Page
        uint32_t rsvd:      1;  // < Reserved.
        uint32_t prio:      3;  // < CAN Frame fun_code priority
        uint32_t reserved:  2;  // < Reserved. 
        uint32_t flag:      1;  // 0-standard frame  1-extended frame
    }bit;
}can_frame_id_u;


// BCU communication status
typedef enum{

    BCU_NOT_CONNECT = 0,    // 未连接
    BCU_COMM_NORMAL = 1,    // 通信正常
    BCU_COMM_BREAK  = 2,    // 通信中断

}battery_comm_status_e;



#pragma pack(push)
#pragma pack(1)
/**************** 集装箱内电池簇共用数据 （注意：遥信、遥测数据顺序需要与共享内存中保持一致） ****************/
typedef struct{

    // BCU--→CMU MCU1
    uint8_t  battery_cluster_status_info[BATTERY_CLUSTER_STATUS_LEN_BYTE];   // 集装箱内电池簇（状态信息）
    uint8_t  battery_cluster_warn_info[BATTERY_CLUSTER_WARN_LEN_BYTE];       // 集装箱内电池簇（告警信息）
    uint8_t  battery_cluster_fault_info[BATTERY_CLUSTER_FAULT_LEN_BYTE];     // 集装箱内电池簇（故障信息）

    uint16_t software_version;                           // 软件版本 高位大版本，低位小版本
    uint16_t BCU_comm_status;                            // BCU通信状态 0-未连接 1-通信正常 2-通信中断
    int16_t  cluster_voltage;                            // 簇端电压  精度：0.1V 偏移量：0
    int16_t  cluster_current;                            // 簇端电流  精度：0.1A 偏移量：-1600
    uint16_t cluster_SOC;                                // 簇端SOC  精度：1%   偏移量：0
    uint16_t positive_insulation_resistance;             // 正绝缘阻抗  精度：1KΩ 偏移量：0
    uint16_t negative_insulation_resistance;             // 负绝缘阻抗  精度：1KΩ 偏移量：0
    int16_t  high_pressure_box_temperature[4];           // 高压箱温度T1-T4  精度：1℃ 偏移量：-40
    uint16_t PACK_number_in_cluster;                     // 簇内PACK数量
    uint16_t battery_number_in_PACK;                     // PACK内电芯数量
    uint16_t total_battery_number;                       // 总电芯数量（一簇）
    uint16_t temperature_number_in_PACK;                 // PACK内温度个数
    uint16_t total_temperature_number;                   // 总温度数量（一簇）
    int16_t highest_monomer_voltage_cluster[3];          // 单簇最高单体电压前三Umax1-3  精度：0.001V 偏移量：0
    int16_t lowest_monomer_voltage_cluster[3];           // 单簇最低单体电压前三Umin1-3  精度：0.001V 偏移量：0
    uint16_t battery_node_highest_voltage;               // 单簇最高单体电压的电池节号
    uint16_t battery_node_lowest_voltage;                // 单簇最低单体电压的电池节号
    int16_t average_voltage_monomer;                     // 单体电压平均值Umean  精度：0.001V 偏移量：0
    int16_t highest_monomer_temperature_cluster[3];      // 单簇最高单体温度前三Tmax1-3  精度：1℃ 偏移量：-40
    int16_t lowest_monomer_temperature_cluster[3];       // 单簇最低单体温度前三Tmin1-3  精度：1℃ 偏移量：-40
    uint16_t battery_node_highest_temperature;           // 单簇最高单体温度的电池节号
    uint16_t battery_node_lowest_temperature;            // 单簇最低单体温度的电池节号
    int16_t average_temperature_monomer;                 // 单体温度平均值Tmean  精度：1℃ 偏移量：-40
    uint16_t highest_monomer_SOC_cluster[3];             // 单簇最高单体SOC前三SOCmax1-3  精度：1% 偏移量：0 范围：0-100
    uint16_t lowest_monomer_SOC_cluster[3];              // 单簇最低单体SOC前三SOCmin1-3  精度：1% 偏移量：0 范围：0-100
    uint16_t battery_node_highest_SOC;                   // 单簇最高单体SOC的电池节号
    uint16_t battery_node_lowest_SOC;                    // 单簇最低单体SOC的电池节号
    uint16_t average_SOC_monomer;                        // 单体SOC平均值SOCmean  精度：1% 偏移量：0 范围：0-100
    uint16_t highest_monomer_SOH_cluster[3];             // 单簇最高单体SOH前三SOHmax1-3  精度：1% 偏移量：0 范围：0-100
    uint16_t lowest_monomer_SOH_cluster[3];              // 单簇最低单体SOH前三SOHmin1-3  精度：1% 偏移量：0 范围：0-100
    uint16_t battery_node_highest_SOH;                   // 单簇最高单体SOH的电池节号
    uint16_t battery_node_lowest_SOH;                    // 单簇最低单体SOH的电池节号
    uint16_t average_SOH_monomer;                        // 单体SOH平均值SOHmean  精度：1% 偏移量：0 范围：0-100

    monomer_info_t monomer_data[PACK_NUMBER];            // PACK1-8的详细单体数据
    
    int16_t pole_temperater_PACK[PACK_NUMBER][POLE_TEMP_NUM_IN_PACK];   // PACK1-8的极柱温度T1-T2  精度：1℃ 偏移量：-40

    uint16_t sigle_time_charge_capacity;    //单次充电容量
    uint16_t sigle_time_discharge_capacity;  //单次放电容量
    uint32_t total_charge_capacity;   //累计充电容量
    uint32_t total_discharge_capacity;  //累计放电容量

    uint8_t charge_disable;                              // 记录电池簇禁止充电标志是否置位
    uint8_t discharge_disable;                           // 记录电池簇禁止放电标志是否置位

    uint8_t battery_type;   // 记录电池类型 1-磷酸铁锂电池(L), 2—钛酸锂电池(N), 3—锰酸锂电池(T), 4-三元锂电池(S)

    uint32_t total_charging_energy;     // 簇累计充电能量 精度：0.01KWH
    uint32_t total_discharge_energy;    // 簇累计放电能量 精度：0.01KWH
    uint16_t daily_charging_energy;     // 簇单日累计充电能量 精度：0.1KWH
    uint16_t daily_discharge_energy;    // 簇单日累计放电能量 精度：0.1KWH

    uint8_t  battery_insulation_detection_status;
}battery_cluster_data_t;
#pragma pack(pop)

/**************** 电池通信相关参数 ****************/
typedef struct{
    uint8_t  battery_connect_flag[BCU_DEVICE_NUM];       // 记录电池簇是否连接成功过 0: 未连接  1: 已连接
    uint8_t  battery_comm_break[BCU_DEVICE_NUM];         // 0：正常，1: 通讯中断
    uint16_t battery_comm_err_cnt[BCU_DEVICE_NUM];       // 记录电池簇通讯中断次数
    
    uint16_t battery_respond_flag[BCU_DEVICE_NUM];       // 记录电池是否应答下发的设置指令 高八位为功能码 低八位：0-成功 1-失败
    uint8_t  error_code[BCU_DEVICE_NUM];                 // 记录电池应答的错误码

    uint8_t battery_id_connect[BCU_DEVICE_NUM];          // 记录当前已连接的电池簇id
    uint8_t connect_num;                                 // 记录当前已连接的电池簇数量

}battery_comm_info_t;

/**************** 电池的软件版本号 ****************/
typedef struct{

    // 主控软件版本号1~10，其中1 7 8 为ASCII码，其余为数值 例：C-3-4.0.2.0-GB2.8 (横杠和点为显示添加，无数据上传)
    uint8_t master_software_version[LENGTH_VERSION_M_S];

    // 从控软件版本号1~10，其中1 7 8 为ASCII码，其余为数值 例：C-3-4.0.2.0-GB2.8 (横杠和点为显示添加，无数据上传)
    uint8_t slave_software_version[LENGTH_VERSION_M_S];

    // 字节0-年(偏移量2000), 1-项目编号千位和百位, 2-项目编号十位和个位, 3-项目大版本, 4-项目小版本, 5-项目测试版本
    // 项目软件版本号(均为数值，横杠和点为显示添加，无数据上传) 例：20220225-01.03-00 对应数组内数据 0x16 0x02 0x19 0x01 0x03 0x00
    uint8_t project_software_version[LENGTH_VERSION_P];

    // 记录软件版本号接收完成标志；bit0-第一帧(主控软件版本号1~6) bit1-第二帧(主控软件版本号7~10)
    // bit2-第三帧(从控软件版本号1~6) bit3-第四帧(从控软件版本号7~10) bit4-第五帧(项目软件版本号)
    uint16_t receive_completion_flag;
}battery_software_version_t;



/** 
 * @brief   电池数据读取（CAN通讯）任务启动
 * @param
 * @return
 */
void battery_read_task_start(void);


/**
 * @brief    所有簇电池主控软件版本号确认
 * @param    
 * @return   主控版本号确认结果
 * @retval   OBJ_VERSION_NORMAL(0)      所有电池簇的主控版本号一致
 * @retval   OBJ_VERSION_UN_NORMAL(1)   至少有一簇的主控版本号不一致
 * @note     
 */
uint8_t battery_master_software_version_check(void);

/** 
 * @brief   获取集装箱内电池簇数据缓存结构体的首地址
 * @param   
 * @return  &g_battery_cluster_data[0]
 * @note    g_battery_cluster_data[BCU_DEVICE_NUM] 数组的下标 0~9，
 *          分别对应电池簇地址 0xE1~0xEA
 */
battery_cluster_data_t *battery_cluster_data_get(void);

/** 
 * @brief   获取电池通信参数结构体地址
 * @param
 * @return
 */
battery_comm_info_t *battery_comm_info_get(void);


#endif  /* __PROCESS_BATTERY_READ_H__ */
