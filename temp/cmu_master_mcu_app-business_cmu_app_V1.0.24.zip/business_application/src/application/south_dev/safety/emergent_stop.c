#include "safety_lib_task.h"
#include "emergent_stop.h"
#include "bool_filter.h"
#include "sdk_log.h"
#include "sdk_fs.h"
#include "sdk_dido.h"
#include "pcs_fun_interface.h"
#include "data_shm.h"
#include "user_timer.h"
#include "sdk_shm.h"
#include "mem_utils.h"
#include "param_record_task.h"

#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>

#define DRM0_HANDLE_DEBUG     0

#if (1)
    #define DRM0_HANDLE_LOG_D(...)          do{ log_i( (const int8_t*)__VA_ARGS__ ); } while (0);
#else
    #define DRM0_HANDLE_LOG_D(...)          do{} while (0);
#endif

#define DRM0_HANDLE_LOG_E(...)              do{ log_e( (const int8_t*)__VA_ARGS__ ); } while (0);

#define EMERGENT_EVENT_EXSIT( p_telmatic_fault_info )  (  ( p_telmatic_fault_info[0] & BIT(0) ) \
                                                        || ( p_telmatic_fault_info[0] & BIT(4) ) \
                                                        || ( p_telmatic_fault_info[0] & BIT(5) ) )
        
/*-------------------------------- 紧急停机 IO相关系统文件 -----------------------------*/
#define DRM0_DI5_FILE_PATH             "/sys/class/gpio/gpio66/value"
#define EPO_DI6_FILE_PATH              "/sys/class/gpio/gpio67/value"
#define EXT_WARN_DI7_FILE_PATH         "/sys/class/gpio/gpio68/value"

#define PCS_FAULT_PIN_DO1_FILE_PATH    "/sys/class/gpio/gpio69/value"

/*-------------------------------------------------------------------------------------*/

/* 紧急停机GPIO类型 */
typedef enum {
    EM_STOP_PIN_EPO,
    EM_STOP_PIN_EXT_WARN,
    EM_STOP_PIN_DRM0,
    EM_STOP_PIN_MAX,
    EM_STOP_PIN_NUM = EM_STOP_PIN_MAX,
} em_stop_pin_e;

typedef struct 
{
    bool_filter_hd  pin_filter[EM_STOP_PIN_NUM];
} em_stop_info_t;

#if DRM0_HANDLE_DEBUG
static em_stop_info_t s_em_stop_info = { .pin_filter = {NULL, NULL, NULL} };
#else
static em_stop_info_t s_em_stop_info = { .pin_filter = {NULL, NULL, NULL} };
#endif

static void _emergent_stop_monitor_task( void );
static sf_ret_t _drm_handle_get_drm_enable_flag( bool *p_drm0_en_flag, bool *p_drm1_8_en_flag );
static sf_ret_t _drm_handle_enable_refresh( void );
static void _drm_handle_enable_monitor( void );


/**
 * @brief  设置 CMU对PCS故障IO 电平
 * @param  [in] lv ： 输出电平
 * @return 无
 * @note   
 */
static void _pcs_fault_pin_set( bool lv )
{
    static int pcs_fauLt_pin_fd = 0;

    // DRM0_HANDLE_LOG_D("%s lv:%d\r\n", __FUNCTION__, lv);
    if ( pcs_fauLt_pin_fd <= 0 )
    {
        pcs_fauLt_pin_fd = open( PCS_FAULT_PIN_DO1_FILE_PATH, O_WRONLY );
        if ( pcs_fauLt_pin_fd < 0 )
        {
            DRM0_HANDLE_LOG_D("open %s error!!!\r\n", PCS_FAULT_PIN_DO1_FILE_PATH);
        }
    }

    lseek( pcs_fauLt_pin_fd, 0, SEEK_SET);
    write( pcs_fauLt_pin_fd, lv ? "1" : "0", 1);

    return;    
}

/**
 * @brief  获取 紧急停机IO 电平
 * @param  [in] pin ： 紧急停机IO类型
 * @return true：高电平  false：低电平
 * @note   
 */
static bool _emergent_stop_pin_get( em_stop_pin_e pin )
{
    int em_stop_pin_fd;
    char lv_val[2] = { 0, 0 };
    
    if ( pin == EM_STOP_PIN_EPO )
    {
        em_stop_pin_fd = open( EPO_DI6_FILE_PATH, O_RDONLY );
    }
    else if ( pin == EM_STOP_PIN_EXT_WARN )
    {
        em_stop_pin_fd = open( EXT_WARN_DI7_FILE_PATH, O_RDONLY );
    }
    else if ( pin == EM_STOP_PIN_DRM0 )
    {
        em_stop_pin_fd = open( DRM0_DI5_FILE_PATH, O_RDONLY );
    } 
    else
    {
        return false;
    }
        
    if ( em_stop_pin_fd < 0 )
    {
        DRM0_HANDLE_LOG_D("open %d error!!!\r\n",pin);
        return false;
    }

    lseek( em_stop_pin_fd, 0, SEEK_SET);
    read( em_stop_pin_fd, lv_val, sizeof( lv_val ) );
    close(em_stop_pin_fd  );

    return (lv_val[0] == '1') ? SF_TRUE : SF_FALSE;
}

/**
 * @brief  紧急停机监控【线程方式】
 * @param  [in] p_user_arg ： 线程参数
 * @return 无
 * @note   
 */
static void *_emergent_stop_monitor_thread( void *p_user_arg )
{
    DRM0_HANDLE_LOG_D("%s\r\n", __FUNCTION__);
    while(1)
    {
        // _drm_handle_enable_monitor();
        _emergent_stop_monitor_task();
        usleep(2000);
    }
    return NULL;
}

// /**
//  * @brief  紧急停机监控【定时器方式】
//  * @param  [in] p_user_arg ： 用户参数
//  * @return 无
//  * @note   
//  */
// static void _emergent_stop_monitor_timer_out( void *p_user_arg )
// {
//     // _drm_handle_enable_monitor();
//     _emergent_stop_monitor_task();
// }


/**
 * @brief  通过SN获取EPO是常开还是常闭类型
 * @param  [in] 无
 * @return 无
 * @note   
 */
static void get_epo_type_by_sn(void)
{
    constant_parameter_data_t *p_para_data = NULL;
    internal_shared_data_t *p_internal_data = NULL;
    uint8_t temp_buf[4];
    uint8_t tm_year = 0;
    uint8_t tm_month = 0;
    
    p_para_data = sdk_shm_constant_parameter_data_get();    // 定值/参数
    p_internal_data =  internal_shared_data_get();
    if(p_para_data == NULL || p_internal_data == NULL)
    {
        return;
    }
    memset(temp_buf,0,sizeof(temp_buf));
    temp_buf[0] = p_para_data->device_sn[11];
    temp_buf[1] = p_para_data->device_sn[12];
    tm_year = atoi((const char*)temp_buf);

    memset(temp_buf,0,sizeof(temp_buf));
    temp_buf[0] = p_para_data->device_sn[13];
    if(temp_buf[0] >= '1' && temp_buf[0] <= '9')
    {
        tm_month = atoi((const char*)temp_buf);
    }
    else if(temp_buf[0] >= 'A' && temp_buf[0] <= 'C')
    {
        tm_month = temp_buf[0] - 55;
    }
    else 
    {
        tm_month = 1;
    }

    if(tm_year == 24)
    {
        if(tm_month >= 12)
        {
            p_internal_data->epo_trigger_type = EPO_TRIGGER_LOW;
        }
        else
        {
            p_internal_data->epo_trigger_type = EPO_TRIGGER_HIGH;
        }
    }
    else if(tm_year > 24)
    {
        p_internal_data->epo_trigger_type = EPO_TRIGGER_LOW;
    }
    else 
    {
       p_internal_data->epo_trigger_type = EPO_TRIGGER_HIGH; 
    }
    return;
}

/**
 * @brief  紧急停机 任务监控初始化
 * @param  [in] 无
 * @return SF_OK：成功  非SF_OK：失败
 * @note   
 */
sf_ret_t emergent_stop_task_init( void )
{
    DRM0_HANDLE_LOG_D("%s\r\n", __FUNCTION__);

    /* 创建 GPIO滤波器 */
    filter_setting_t pin_filter_setting = { .tm_ms = 20, .cnt = 7 };

    get_epo_type_by_sn();
    for (size_t i = 0; i < ARRAY_SIZE( s_em_stop_info.pin_filter ); i++)
    {
        s_em_stop_info.pin_filter[i] = bool_filter_create( FILTER_TYPE_TM_AND_CNT, &pin_filter_setting, &pin_filter_setting );
        if ( s_em_stop_info.pin_filter[i] == NULL )
        {
            DRM0_HANDLE_LOG_E("%s s_em_stop_info.pin_filter[%d] == NULL \r\n", __FUNCTION__, i);
            return SF_ERR_NO_OBJECT;
        }
    //    bool_filter_set_val( s_em_stop_info.pin_filter[i], BOOL_VAL_FALSE );
    }

    /* 刷新 drm0 启动标志位 */
    // _drm_handle_enable_refresh();


    // /* 创建 采样定时器 */
    // user_timer_hd em_pin_sample_timer = user_timer_create( _emergent_stop_monitor_timer_out, NULL );
    // if ( em_pin_sample_timer == NULL )
    // {
    //     DRM0_HANDLE_LOG_E("%s em_pin_sample_timer == NULL\r\n", __FUNCTION__);
    //     return SF_ERR_NDEF;
    // }
    // user_timer_set_timeout( em_pin_sample_timer, 2, SF_TRUE );



    pthread_attr_t inte_attr;
    pthread_t drm0_handle_task;
    int32_t ret = 0;

    // 初始化线程属性
    ret = pthread_attr_init(&inte_attr);
    if (ret)
    {
        DRM0_HANDLE_LOG_E((int8_t *)"\n [%s:%d] pthread_attr_init error!!! \n", __func__, __LINE__);
        return SF_ERR_NDEF; // 线程属性初始化出错退出
    }
    
    // 设置线程属性为分离状态
    ret = pthread_attr_setdetachstate(&inte_attr, PTHREAD_CREATE_DETACHED);
    if (ret)
    {
        DRM0_HANDLE_LOG_E((int8_t *)"\n [%s:%d] pthread_attr_setdetachstate info_record_attr error!!! \n", __func__, __LINE__);
        return SF_ERR_NDEF; // 线程分离属性设置出错退出
    }
    // 创建综合任务线程
    ret = pthread_create(&drm0_handle_task, &inte_attr, &_emergent_stop_monitor_thread, NULL);
    if (ret)
    {
        DRM0_HANDLE_LOG_E((int8_t *)"\n [%s:%d] pthread_create integration_task error!!! \n", __func__, __LINE__);
        return SF_ERR_NDEF; // 线程创建出错退出
    }  

    // 销毁线程属性结构,它在重新初始化之前不能重新使用
    pthread_attr_destroy(&inte_attr);

    return SF_OK;
}

/**
 * @brief  对 所有涉及紧急停机IO 进行处理
 * @param  [in] pin           ：紧急停机IO类型
 * @param  [in] pin_filter_lv ：紧急停机IO滤波之后的电平
 * @return 无
 * @note   
 */
static void _emergent_stop_pin_handle( em_stop_pin_e pin, bool_val_e pin_filter_lv )
{
    constant_parameter_data_t *p_constant_parameter_data = sdk_shm_constant_parameter_data_get();
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();
    static bool epo_trig_pow_off = SF_FALSE;
    internal_shared_data_t *p_internal_data =  NULL;
    static uint16_t epo_type_change_count = 0;
    static uint16_t last_epo_type = 0xFF;
    static uint16_t ext_epo_type_change_count = 0;
    static uint16_t last_ext_epo_type = 0xFF;

    p_internal_data = internal_shared_data_get();
    if(p_internal_data == NULL || p_constant_parameter_data == NULL || p_telematic_data == NULL)
    {
        return;
    }
    
    // 柜子内部的EPO类型判断
    if(last_epo_type != p_internal_data->epo_trigger_type)
    {
        if(last_epo_type != 0xFF)
        {
            if(epo_type_change_count ++ >= 3000)
            {
                last_epo_type = p_internal_data->epo_trigger_type;
                epo_type_change_count = 0;
            }
            
        }
        else
        {
            last_epo_type = p_internal_data->epo_trigger_type; 
        }   
    }

    // 柜子外部的EPO类型判断
    if(last_ext_epo_type != p_constant_parameter_data->external_epo_input_type)
    {
        if(last_ext_epo_type != 0xFF)
        {
            if(ext_epo_type_change_count ++ >= 3000)
            {
                last_ext_epo_type = p_constant_parameter_data->external_epo_input_type;
                ext_epo_type_change_count = 0;
            }
            
        }
        else
        {
            last_ext_epo_type = p_constant_parameter_data->external_epo_input_type; 
        }   
    }

    if( pin == EM_STOP_PIN_EPO)
    {
        if(last_epo_type == EPO_TRIGGER_LOW)
        {
            if(pin_filter_lv == BOOL_VAL_TRUE)
            {
                pin_filter_lv = BOOL_VAL_FALSE;
            }
            else
            {
                pin_filter_lv = BOOL_VAL_TRUE;
            }
        }
    }
    else if(pin == EM_STOP_PIN_EXT_WARN)
    {
        if(last_ext_epo_type == EPO_TRIGGER_HIGH)
        {
            if(pin_filter_lv == BOOL_VAL_TRUE)
            {
                pin_filter_lv = BOOL_VAL_FALSE;
            }
            else
            {
                pin_filter_lv = BOOL_VAL_TRUE;
            }
        }
    }

    /* 整理遥信标志位 */ 
    if ( pin == EM_STOP_PIN_EPO ) 
    {
        mem_utils_set_bit_val( p_telematic_data->container_system_status_info , 4, ( pin_filter_lv == BOOL_VAL_TRUE )? 1: 0 );
        mem_utils_set_bit_val( p_telematic_data->container_system_fault_info  , 0, ( pin_filter_lv == BOOL_VAL_TRUE )? 1: 0 );
    }
    else if ( pin == EM_STOP_PIN_EXT_WARN ) 
    {
        mem_utils_set_bit_val( p_telematic_data->container_system_status_info , 5, ( pin_filter_lv == BOOL_VAL_TRUE )? 1: 0 );
        mem_utils_set_bit_val( p_telematic_data->container_system_fault_info  , 4, ( pin_filter_lv == BOOL_VAL_TRUE )? 1: 0 );
    }
    else if ( pin == EM_STOP_PIN_DRM0 ) 
    {
        mem_utils_set_bit_val( p_telematic_data->container_system_status_info , 7, ( pin_filter_lv == BOOL_VAL_TRUE )? 1: 0 );
        if ( BIT_GET( p_constant_parameter_data->safety_param.group5[0], 5 ) == 1 )
        {
            mem_utils_set_bit_val( p_telematic_data->container_system_fault_info , 5, ( pin_filter_lv == BOOL_VAL_TRUE )? 1: 0 );
        }else{
            mem_utils_set_bit_val( p_telematic_data->container_system_fault_info , 5, 0 );
        }
    }

    if ( pin_filter_lv == BOOL_VAL_TRUE )
    {
        if ( (pin == EM_STOP_PIN_DRM0) && ( BIT_GET( p_constant_parameter_data->safety_param.group5[0], 5) == 0 ) ) 
        {
            /* DRM0 没开启则不处理 */
            return;
        }

        /* 触发紧急停机 */
        if(epo_trig_pow_off == SF_FALSE)
        {
            epo_trig_pow_off = SF_TRUE;
            pcs_power_control( PCS_POWER_EPO );
            _emergent_stop_pcs_fault_pin_set( SF_TRUE );
        }
        
    }
    else if ( pin_filter_lv == BOOL_VAL_FALSE )
    {
        if ( !EMERGENT_EVENT_EXSIT( p_telematic_data->container_system_fault_info ) )
        {
            if ( epo_trig_pow_off == SF_TRUE )
            {
                /* 紧急关机的故障消除之后，系统切换为关机状态 */
                epo_trig_pow_off = SF_FALSE;
                sdk_shm_other_parameter_data_get()->remote_on_off_ctrl = REMOTE_POWER_OFF;
                dev_param_save();
                dev_param_save();
            }
        }
    }
}

/**
 * @brief  设置 CMU对PCS故障停机IO 
 * @param  [in] enable ： 是否对PCS输出故障
 * @return 无
 * @note   
 */
void _emergent_stop_pcs_fault_pin_set( bool enable )
{
    static pthread_mutex_t pcs_fault_pin_mutex;						// 通信互斥锁
    static bool mutex_init = SF_FALSE;

    if ( mutex_init != SF_TRUE )
    {
        pthread_mutex_init( &pcs_fault_pin_mutex, NULL );
        mutex_init = SF_TRUE;
    }

    pthread_mutex_lock( &pcs_fault_pin_mutex );
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();
    // DRM0_HANDLE_LOG_D( "enable:%d, container_system_fault_info:%02X", enable ,p_telematic_data->container_system_fault_info[0] );

    if ( SF_TRUE == enable )
    {
        _pcs_fault_pin_set( SF_TRUE );
    }else
    {
        if ( SF_FALSE == EMERGENT_EVENT_EXSIT( p_telematic_data->container_system_fault_info ))
        {
            /* 必须解除所有紧急停机事件才能 取消PCS故障IO */
            _pcs_fault_pin_set( SF_FALSE );
        }
    }
    pthread_mutex_unlock( &pcs_fault_pin_mutex );
}


/**
 * @brief  对 紧急停机事件 进行监控
 * @param  [in] 无
 * @return 无
 * @note   
 */
static void _emergent_stop_monitor_task( void )
{
    static uint8_t last_raw_lv[ EM_STOP_PIN_NUM ] = { USR_U8_VAL_INVALID, USR_U8_VAL_INVALID, USR_U8_VAL_INVALID };
    static bool_val_e last_filter_lv[ EM_STOP_PIN_NUM ]  = { BOOL_VAL_INVALID, BOOL_VAL_INVALID, BOOL_VAL_INVALID };
    static uint8_t raw_lv[ EM_STOP_PIN_NUM ];
    bool_val_e filter_lv[ EM_STOP_PIN_NUM ];
    uint8_t raw_level;
    
    for (size_t i = 0; i < ARRAY_SIZE( raw_lv ); i++)
    {
        raw_level = _emergent_stop_pin_get( (em_stop_pin_e)i );
        raw_lv[i] = raw_level;
        if ( last_raw_lv[i] != raw_lv[i] )
        {
            
            DRM0_HANDLE_LOG_D( "%s lv:%d\r\n",  (i == EM_STOP_PIN_EPO      ) ? "EPO":
                                                (i == EM_STOP_PIN_EXT_WARN ) ? "EXT WARN":
                                                (i == EM_STOP_PIN_DRM0     ) ? "DRM0": "UNKNOW PIN" 
                                                , raw_lv[i] );
            last_raw_lv[i] = raw_lv[i];
        }

        filter_lv[i] = bool_filter_input( s_em_stop_info.pin_filter[i], (raw_lv[i] == 1) ? BOOL_VAL_TRUE: BOOL_VAL_FALSE );
        if ( last_filter_lv[i] != filter_lv[i] )
        {
            DRM0_HANDLE_LOG_D( "%s filter lv:%d\r\n", (i == EM_STOP_PIN_EPO      ) ? "EPO":
                                                      (i == EM_STOP_PIN_EXT_WARN ) ? "EXT WARN":
                                                      (i == EM_STOP_PIN_DRM0     ) ? "DRM0": "UNKNOW PIN" 
                                                      , filter_lv[i] );
            last_filter_lv[i] = filter_lv[i];
        }
        if(filter_lv[i] != BOOL_VAL_INVALID)
        {
            _emergent_stop_pin_handle( ( em_stop_pin_e )i, filter_lv[i] );
        }
        
    }
}
