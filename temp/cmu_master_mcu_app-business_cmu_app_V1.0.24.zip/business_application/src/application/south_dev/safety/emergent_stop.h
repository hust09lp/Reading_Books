#ifndef _EMERGENT_STOP_H_
#define _EMERGENT_STOP_H_

#include "sofar_type.h"

/**
 * @brief  紧急停机 任务监控初始化
 * @param  [in] 无
 * @return SF_OK：成功  非SF_OK：失败
 * @note   
 */
sf_ret_t emergent_stop_task_init( void );

/**
 * @brief  设置 CMU对PCS故障停机IO 
 * @param  [in] enable ： 是否对PCS输出故障
 * @return 无
 * @note   
 */
void _emergent_stop_pcs_fault_pin_set( bool enable );

#endif
