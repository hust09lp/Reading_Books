/************************************************************************************
 *Description: sdk_safety
 *Created on: 2022-11-02
 *Author: quliuliu
 ************************************************************************************/

/* 安规文件处理 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

#include "sdk_safety.h"
#include"sdk_shm.h"

// 安规包头信息FLASH读取的缓存
safety_regula_package_header_t  g_safety_regula_package_header = {0};
//安规包索引信息 flash读取的缓存
safety_regula_package_index_t  g_safety_regula_package_index_array[MENU_PAGE_NUM] = {0};
//在选取安规标准时 对应索引信息的flash物理序号
static uint8_t g_safety_regula_package_index_region_pos[MENU_PAGE_NUM] = {0};

//sum=0x2368;
//CS:164,101  A4, 65

static uint16_t sum=0xFFFF;
uint8_t list[10240]={0};

// 安规文件加密算法
static uint32_t N = 233 * 283;
static uint32_t E = 17;
static uint32_t D = 7697;

static uint32_t Lock(uint32_t a, uint32_t b, uint32_t mo)
{
	uint32_t ans = 1;
	a %= mo;
	while (b > 0)
	{
		if ((b & 1) == 1) ans = ans * a % mo;
		b >>= 1;
		a = a * a % mo;
	}
	return ans;
}

static uint16_t Decode(uint16_t key)
{
	return (uint16_t)Lock(key, D, N);
}

static uint16_t Encode(uint16_t key)
{
	return (uint16_t)Lock(key, E, N);
}

static uint16_t CrcTable[] = {
	0X0000, 0XC0C1, 0XC181, 0X0140, 0XC301, 0X03C0, 0X0280, 0XC241,
	0XC601, 0X06C0, 0X0780, 0XC741, 0X0500, 0XC5C1, 0XC481, 0X0440,
	0XCC01, 0X0CC0, 0X0D80, 0XCD41, 0X0F00, 0XCFC1, 0XCE81, 0X0E40,
	0X0A00, 0XCAC1, 0XCB81, 0X0B40, 0XC901, 0X09C0, 0X0880, 0XC841,
	0XD801, 0X18C0, 0X1980, 0XD941, 0X1B00, 0XDBC1, 0XDA81, 0X1A40,
	0X1E00, 0XDEC1, 0XDF81, 0X1F40, 0XDD01, 0X1DC0, 0X1C80, 0XDC41,
	0X1400, 0XD4C1, 0XD581, 0X1540, 0XD701, 0X17C0, 0X1680, 0XD641,
	0XD201, 0X12C0, 0X1380, 0XD341, 0X1100, 0XD1C1, 0XD081, 0X1040,
	0XF001, 0X30C0, 0X3180, 0XF141, 0X3300, 0XF3C1, 0XF281, 0X3240,
	0X3600, 0XF6C1, 0XF781, 0X3740, 0XF501, 0X35C0, 0X3480, 0XF441,
	0X3C00, 0XFCC1, 0XFD81, 0X3D40, 0XFF01, 0X3FC0, 0X3E80, 0XFE41,
	0XFA01, 0X3AC0, 0X3B80, 0XFB41, 0X3900, 0XF9C1, 0XF881, 0X3840,
	0X2800, 0XE8C1, 0XE981, 0X2940, 0XEB01, 0X2BC0, 0X2A80, 0XEA41,
	0XEE01, 0X2EC0, 0X2F80, 0XEF41, 0X2D00, 0XEDC1, 0XEC81, 0X2C40,
	0XE401, 0X24C0, 0X2580, 0XE541, 0X2700, 0XE7C1, 0XE681, 0X2640,
	0X2200, 0XE2C1, 0XE381, 0X2340, 0XE101, 0X21C0, 0X2080, 0XE041,
	0XA001, 0X60C0, 0X6180, 0XA141, 0X6300, 0XA3C1, 0XA281, 0X6240,
	0X6600, 0XA6C1, 0XA781, 0X6740, 0XA501, 0X65C0, 0X6480, 0XA441,
	0X6C00, 0XACC1, 0XAD81, 0X6D40, 0XAF01, 0X6FC0, 0X6E80, 0XAE41,
	0XAA01, 0X6AC0, 0X6B80, 0XAB41, 0X6900, 0XA9C1, 0XA881, 0X6840,
	0X7800, 0XB8C1, 0XB981, 0X7940, 0XBB01, 0X7BC0, 0X7A80, 0XBA41,
	0XBE01, 0X7EC0, 0X7F80, 0XBF41, 0X7D00, 0XBDC1, 0XBC81, 0X7C40,
	0XB401, 0X74C0, 0X7580, 0XB541, 0X7700, 0XB7C1, 0XB681, 0X7640,
	0X7200, 0XB2C1, 0XB381, 0X7340, 0XB101, 0X71C0, 0X7080, 0XB041,
	0X5000, 0X90C1, 0X9181, 0X5140, 0X9301, 0X53C0, 0X5280, 0X9241,
	0X9601, 0X56C0, 0X5780, 0X9741, 0X5500, 0X95C1, 0X9481, 0X5440,
	0X9C01, 0X5CC0, 0X5D80, 0X9D41, 0X5F00, 0X9FC1, 0X9E81, 0X5E40,
	0X5A00, 0X9AC1, 0X9B81, 0X5B40, 0X9901, 0X59C0, 0X5880, 0X9841,
	0X8801, 0X48C0, 0X4980, 0X8941, 0X4B00, 0X8BC1, 0X8A81, 0X4A40,
	0X4E00, 0X8EC1, 0X8F81, 0X4F40, 0X8D01, 0X4DC0, 0X4C80, 0X8C41,
	0X4400, 0X84C1, 0X8581, 0X4540, 0X8701, 0X47C0, 0X4680, 0X8641,
	0X8201, 0X42C0, 0X4380, 0X8341, 0X4100, 0X81C1, 0X8081, 0X4040 
};

static uint16_t checksum(uint8_t *buf, int len)
{
	int i;
	for(i=0;i<len;i++)
	{
		sum = (uint16_t)((sum >> 8) ^ CrcTable[(sum ^ (*buf++)) & 0xFF]);
	}

	return sum;
}





void extract(const int8_t *request,uint8_t *str)
{
	int i, j, n=0;
	const int8_t *p1=request;
	uint8_t buf[32]={0};

	for(i=0; i<strlen((char *)p1); i++)
	{
		if(*(p1+i)==':' || *(p1+i)==',')
		{
			memset(buf, 0, sizeof(buf));
			for(j=0; j<strlen((char *)p1)-i; j++)
			{
				if(*(p1+i+1+j)==',' || *(p1+i+1+j)=='\0')
				{
					break;
				}
				*(buf+j)=*(p1+i+1+j);
			}
			
			*(str+(n*2+0)) = (uint8_t)(atoi((char *)buf)>>8);
			*(str+(n*2+1)) = (uint8_t)(atoi((char *)buf)&0xFF);
			n++;
		}
	}
}

int32_t sdk_safety_txt_to_bin(const int8_t *p_txt_file, int8_t *p_bin_file, safety_attr_t *safety_attr, uint32_t lib_index)
{
	sum=0xFFFF;
    int line_num = 0; // 读取行数
	int8_t buf[LINE_MAX]={0};
	uint8_t str[SAFETY_FRAME_SIZE]={0};
	uint8_t country[8]={0};
	uint8_t region[8]={0};
	uint8_t version[8]={0};

	uint8_t head[10]={0};
    int cs1 = 0,cs2 = 0;
    uint16_t crc_read = 0;              //读出来的CRC参数
    uint16_t crc_result = 0;            //CRC计算结果
    uint8_t crc_succeed_flag = 0;       //0:仅校验，1：crc校验通过
    uint8_t safety_country_num = 0;     //安规国家对应数值
    uint8_t safety_region_num = 0;      //安规地区对应数值
    uint16_t safety_version_num = 0;    //安规版本对应数值
    
    //检查安规文件是否存在
    if(0 != access((const char *)p_txt_file, F_OK))
    {
		return -1;
    }

	FILE *fp_txt = NULL;
	if ((fp_txt = fopen((char *)p_txt_file, "r")) == NULL)
	{
		printf("[%s:%s:%d] %s\n", __FILE__,__func__, __LINE__, strerror(errno));
		return -1;
	}

    FILE *fp_bin = NULL;
crc_succeed:    //遍历两边，第一遍进行校验，第二遍进行赋值
    if (1 == crc_succeed_flag)
    {
        if((fp_bin = fopen((char *)p_bin_file, "w+")) == NULL)
        {
            printf("[%s:%s:%d] %s\n", __FILE__,__func__, __LINE__, strerror(errno));
            fclose(fp_txt);
            return -1;
        }
    }
    //偏移，若为安规库文件则进行偏移，txt文件index设置为0
    if (0 != fseek((FILE*)fp_txt, lib_index, SEEK_SET))
    {
        fclose(fp_txt);
        if (1 == crc_succeed_flag)
        {
            fclose(fp_bin);
        }
        return -2;
    }
	while (fgets((char *)buf, LINE_MAX, fp_txt)) 
	{
		line_num++;
		// 对每行数据(buf)进行处理
		if (1 == line_num)//对安规国家/地区/版本提取
		{
			sscanf((char *)buf, "COUNTRY&Region&Ver:%[^,],%[^,],%[^,],", country, region, version);

            //校验成功
            if (1 == crc_succeed_flag)
            {
                safety_country_num = atoi((char *)country);
                safety_region_num = atoi((char *)region);
                safety_version_num = ((atoi((char *)version)) & 0xFF00) | (atoi((char *)version) & 0xFF);
                
                safety_attr->region = (safety_country_num << 8) | safety_region_num;
                safety_attr->version = safety_version_num;
            }

			head[0]=(uint8_t)(atoi((char *)country));
			head[1]=(uint8_t)(atoi((char *)region));
			head[2]=(uint8_t)(atoi((char *)version)>>8);
			head[3]=(uint8_t)(atoi((char *)version)&0xff);

            if (0 == crc_succeed_flag)
            {
                checksum(head, 4);
            }
		}
		else if (line_num > 1 && line_num < 11)
		{
			memset(str, 0, sizeof(str));
			extract(buf,str);
			
            if (0 == crc_succeed_flag)
            {
                checksum(str, SAFETY_FRAME_SIZE);
            }
            //校验成功
            else if (1 == crc_succeed_flag)
            {
                if (fwrite(str, SAFETY_FRAME_SIZE, 1, fp_bin) != 1)
                {
                    printf("[%s:%s:%d] %s\r\n",  __FILE__,__func__, __LINE__, strerror(errno));
                    fclose(fp_txt);
                    fclose(fp_bin);
                    return -1;
                }
            }
        }
		else if (11 == line_num)
		{
			//第11行，获取校验
            sscanf((char *)buf, "CS:%d,%d", &cs1, &cs2);
			//数据获取完，安规校验检查
            if (0 == crc_succeed_flag)
            {
                crc_result = Encode(sum);
                crc_read = ((cs2 << 8) & 0xff00) | (cs1 & 0x00ff);
                if (crc_read != crc_result)
                {
                    printf("[%s:%s:%d] checksum error\r\n",  __FILE__,__func__, __LINE__);
                    printf("Encode checksum = %x\n", crc_result);
                    printf("crc_read = %x\n", crc_read);
                    fclose(fp_txt);
                    return -3;
                }
                crc_succeed_flag = 1;
                line_num = 0;
                goto crc_succeed;
            }
            else
            {
                break;
            }
		}
		memset(buf, 0, sizeof(buf));
	}
	

    fclose(fp_txt);
    fclose(fp_bin);

	return 0;
}

int32_t sdk_safety_bin_to_txt(const int8_t *p_bin_file, int8_t *p_txt_file, safety_attr_t safety_attr)
{
	sum=0xFFFF;
	int32_t i=0;
	int32_t n=0;
	int line_num = 0; // 写入行数
    char str[LINE_MAX]={0};
	uint8_t buf[SAFETY_FRAME_SIZE]={0};
	uint8_t head[10]={0};
    uint16_t unsigned_safety_num = 0;   //无符号的安规参数

    //检查安规文件是否存在
    if(0 != access((const char *)p_bin_file, F_OK))
    {
		return -1;
    }
    FILE *fp_bin = NULL;
	if((fp_bin=fopen((char *)p_bin_file, "r")) == NULL)
	{
		printf("[%s:%s:%d] %s\n", __FILE__,__func__, __LINE__, strerror(errno));
		return -1;
	}

    FILE *fp_txt = NULL;
	if((fp_txt=fopen((char *)p_txt_file, "w+")) == NULL)
	{
		printf("[%s:%s:%d] %s\n", __FILE__,__func__, __LINE__, strerror(errno));
        fclose(fp_bin);
		return -1;
	}

	snprintf(str, sizeof(str), "COUNTRY&Region&Ver:%d,%d,%d,\n", safety_attr.region>>8, safety_attr.region&0xff, safety_attr.version);
	if(fputs(str, fp_txt) != 1)
    {
        printf("[%s:%s:%d] %s\r\n",  __FILE__,__func__, __LINE__, strerror(errno));
        fclose(fp_txt);
    	fclose(fp_bin);
        return -1;
    }

	head[0]=(uint8_t)(safety_attr.region>>8);
	head[1]=(uint8_t)(safety_attr.region&0xFF);
	head[2]=(uint8_t)(safety_attr.version>>8);
	head[3]=(uint8_t)(safety_attr.version&0xFF);

	checksum(head, 4);

	while(fread(buf, SAFETY_FRAME_SIZE, 1, fp_bin))
	{
		n=0;
		line_num++;
		memset(str, 0, sizeof(str));
		n += snprintf((char *) (str + n), sizeof(str), "%d:",line_num);
		for(i=0; i<SAFETY_FRAME_SIZE; i+=2)
		{
            unsigned_safety_num = (buf[i] << 8) | buf[i+1];
            if (5 == line_num)
            {
                //第五行的参数有负数
                if (65535 == unsigned_safety_num)
                {
                    n += snprintf((char *) (str + n), sizeof(str), "%d,",unsigned_safety_num);
                }
                else
                {
                    n += snprintf((char *) (str + n), sizeof(str), "%d,",(int16_t)unsigned_safety_num);
                }
            }
            else
            {
                n += snprintf((char *) (str + n), sizeof(str), "%d,",unsigned_safety_num);
            }
		}
		n += snprintf((char *) (str + n), sizeof(str), "\n");

		if(fputs(str, fp_txt) != 1)
		{
			printf("[%s:%s:%d] %s\r\n",  __FILE__,__func__, __LINE__, strerror(errno));
			fclose(fp_txt);
    		fclose(fp_bin);
			return -1;
		}

		checksum(buf, SAFETY_FRAME_SIZE);
		memset(buf, 0, sizeof(buf));
	}

	Encode(sum);
	
	snprintf((char *) str, sizeof(str), "CS:%d,%d", (Encode(sum) & 0xff), ((Encode(sum)>>8) & 0xff));
	if(fputs(str, fp_txt) != 1)
	{
		printf("[%s:%s:%d] %s\r\n",  __FILE__,__func__, __LINE__, strerror(errno));
		fclose(fp_txt);
    	fclose(fp_bin);
		return -1;
	}
	
	fclose(fp_txt);
    fclose(fp_bin);

	return 0;
}


int32_t sdk_safety_file_import()
{
	return 0;
}

int32_t sdk_safety_file_export()
{
	return 0;
}

//////////////////////////////////////////////////
//以下为安规库文件的处理

/**
 * @brief: 从安规包读取头部信息
 * @param {int8_t} *safety_package_file 安规库文件路径
 * @param {safety_regula_package_header_t} *header_info 头文件信息
 * @return {0：正常，1：输入参数有误，-1：打开文件错误，-2：读取文件错误} 
 * @note: 
 * @see: ret = safety_regula_package_header_read((int8_t *)SAFETY_PATH,&safety_header);
 * @date: 2023年1月5日
 */
static int32_t safety_regula_package_header_read(const int8_t *p_safety_package_file, safety_regula_package_header_t *p_header_info)
{
    FILE *fp_package = NULL;

    int32_t ret = 0;

    if (p_header_info == NULL)
    {
        ret = 1;
        goto __exit;
    }
    //检查安规文件是否存在
    if(0 != access((const char *)p_safety_package_file, F_OK))
    {
        ret = 1;
        goto __exit;
    }

    memset(p_header_info, 0, SAFETY_REGULA_PACKAGE_HEADER_SIZE);

    fp_package = fopen((const char*)p_safety_package_file, "r");
	if (fp_package == NULL)
	{
		ret = -1;
        goto __exit;
	}
    //获取头部信息
    fread(p_header_info, SAFETY_REGULA_PACKAGE_HEADER_SIZE, 1, (FILE*)fp_package); 

__exit:
    //未打开文件时的报错返回大于0
    if (0 >= ret)
    {
        fclose(fp_package);
    }
    return ret;
}

/**
 * @brief: 检查安规包头部信息
 * @param {safety_regula_package_header_t *} pheader 安规库文件头部信息
 * @return {1：输入参数有误，2：魔术字错误，3：长度错误}
 * @note: 
 * @see: 
 * @date: 2023年1月5日
 */
static int32_t safety_regula_package_header_check(safety_regula_package_header_t * p_header)
{
    int32_t ret = 0;

    if (p_header == NULL)
    {
        ret = 1;
        goto __exit;
    }
    //检查魔术字
    if (!( SAFETY_REGULA_PACKAGE_HEADER_CHECK_MAGIC(p_header->magic) ) )
    {
        ret = 2;
        goto __exit;
    }
    //判断长度
    if ((1024 * 1024) < (p_header->len) )
    {
        ret = 3;
    }

__exit:
    return ret;
}

/**
 * @brief: 从安规包读取索引信息
 * @param {int8_t} *p_safety_package_file 安规库文件路径
 * @param {safety_regula_package_index_t} *p_index 安规索引信息的存储
 * @param {uint16_t} pos 安规标准的偏移
 * @param {uint16_t} num 读取数量
 * @return {错误信息}
 * @note: 
 * @see: 
 * @date: 2023年1月6日
 */
static int32_t safety_regula_package_index_read(const int8_t *p_safety_package_file, safety_regula_package_index_t *p_index, uint16_t pos, uint16_t num)
{
    FILE *fp_package = NULL;

    int32_t ret = 0;
    uint32_t read_addr = 0;
    uint32_t file_len = 0;

    if(p_index == NULL)
    {
        ret = 1;
        goto __exit;
    }
    //检查读取的大小
    if( 0 == num)
    {
        //长度超出
        ret = 2;
        goto __exit;
    }

    //检查安规文件是否存在
    if(0 != access((const char *)p_safety_package_file, F_OK))
    {
        ret = 1;
        goto __exit;
    }
    read_addr = SAFETY_REGULA_PACKAGE_HEADER_SIZE; //跳过头部信息
    read_addr = read_addr + (SAFETY_REGULA_PACKAGE_INDEX_SIZE * pos); //加上偏移

    memset(p_index, 0, SAFETY_REGULA_PACKAGE_INDEX_SIZE * num);
    
    fp_package = fopen((const char*)p_safety_package_file, "r");
	if (fp_package == NULL)
	{
		ret = -1;
        goto __exit;
	}
    //偏移
    fseek(fp_package, 0, SEEK_END);
    file_len = ftell(fp_package);  //获取文件大小
    
    //检查读取的起始地址
    if (file_len < read_addr)
    {
        //长度超出
        ret = -2;
        goto __exit;
    }
    //检查读取的结束地址地址
    if (file_len < (read_addr + (SAFETY_REGULA_PACKAGE_INDEX_SIZE * num)))
    {
        //长度超出
        ret = -2;
        goto __exit;
    }

    ret = fseek((FILE*)fp_package, read_addr, SEEK_SET);
    if (0 != ret)
    {
        ret = -3;
        goto __exit;
    }
    //获取信息
    fread(p_index, SAFETY_REGULA_PACKAGE_INDEX_SIZE, num, (FILE*)fp_package);

__exit:
    //未打开文件时的报错返回大于0
    if (0 >= ret)
    {
        fclose(fp_package);
    }
    return ret;
}

/**
 * @brief:从安规包查找读取索引信息(读取国家信息)
 * @param {int8_t} *p_safety_package_file 安规库文件路径
 * @param {uint16_t} index_pos
 * @param {safety_regula_package_header_t *} p_header 安规库头部信息
 * @param {safety_regula_package_index_t *} p_index_buffer 安规索引信息
 * @param {uint8_t*} p_index_pos 缓存数据物理索引序号
 * @param {uint16_t} buffer_num 读取的缓存数量
 * @return {读出来的安规国家数量}
 * @note: 
 * @see: 
 * @date: 2023年1月6日
 */
static int32_t safety_regula_package_index_find_country_by_index(const int8_t *p_safety_package_file, uint16_t index_pos, safety_regula_package_header_t * p_header,
                                                        safety_regula_package_index_t * p_index_buffer, uint8_t* p_index_pos, uint16_t buffer_num )
{
    int32_t ret = 0;
    uint16_t read_pos = 0;
    uint16_t read_num = 0;
    uint16_t index = 0;
    uint8_t next_country_pos = 0;   //下一个国家的索引位置

    if (p_header == NULL)
    {
        ret = 0;
        goto __exit;
    }
    index = 0;
    read_pos = 0;
    while (read_num < buffer_num)
    {
        safety_regula_package_index_read(p_safety_package_file, &(p_index_buffer[index]), index_pos + read_pos, 1);
        
        //保存当前国家的索引位置
        p_index_pos[index] = index_pos + read_pos;
        
        //计算下一个国家的索引位置
        next_country_pos =  (p_index_buffer[index].region_num - p_index_buffer[index].region_index) + 1;
            
        //偏移到下一个
        read_pos += next_country_pos;
        
        index++;
        read_num++;
        
        if (p_header->region_num <= (index_pos + read_pos) )
        {
            break;
        }
    }
    ret = read_num;
    
__exit:
    return ret;
}

/**
 * @brief: 从安规包查找读取索引信息(指定国家的安规标准)
 * @param {int8_t} *p_safety_package_file 安规库文件路径
 * @param {uint16_t} index_pos 
 * @param {safety_regula_package_header_t *} p_header 安规库头部信息
 * @param {safety_regula_package_index_t *} p_index_buffer 安规索引信息
 * @param {uint8_t*} p_index_pos 缓存数据物理索引序号
 * @param {uint16_t} buffer_num 读取的缓存数量
 * @return {读出来的标准数量}
 * @note: 
 * @see: 
 * @date: 2023年1月6日
 */
static int32_t safety_regula_package_index_find_region_by_index(const int8_t *p_safety_package_file, uint16_t index_pos, safety_regula_package_header_t * p_header, 
                                                        safety_regula_package_index_t * p_index_buffer, uint8_t* p_index_pos, uint16_t buffer_num )
{
    int32_t ret = 0;
    uint16_t read_pos = 0;
    uint16_t read_num = 0;

    if (p_header == NULL)
    {
        ret = 0;
        goto __exit;
    }
    
    read_pos = 0;
    while (read_num < buffer_num)
    {
        safety_regula_package_index_read(p_safety_package_file, &(p_index_buffer[read_num]), index_pos + read_pos, 1);
        
        //保存当前标准的索引位置
        p_index_pos[read_num] = index_pos + read_pos;
        
        if ( p_index_buffer[read_num].region_index >= p_index_buffer[read_num].region_num )
        {
            //已经读取完了
            read_pos++;
            read_num++;
            break;
        }
        
        //偏移到下一个
        read_pos++;
        read_num++;
        
        if (p_header->region_num < (index_pos + read_pos) )
        {
            break;
        }
    }
    ret = read_num;
    
__exit:
    return ret;
}

/**
 * @brief: 从安规包查找读取索引信息 根据国家和标准
 * @param {int8_t} *p_safety_package_file
 * @param {safety_attr_t} *safety_attr 安规国家、标准和版本号
 * @param {safety_regula_package_header_t} *p_header 安规库头部信息
 * @param {safety_regula_package_index_t} *p_index_buffer 安规索引信息
 * @param {uint8_t} *p_index_pos 缓存数据物理索引序号
 * @param {uint16_t} buffer_num 读取的缓存数量
 * @return {小于0为错误信息，大于0为偏移}
 * @note: 
 * @see: 
 * @date: 2023年1月6日
 */
static int32_t safety_regula_package_index_find_by_country_region(const int8_t *p_safety_package_file, safety_attr_t *safety_attr, safety_regula_package_header_t *p_header,
                                                     safety_regula_package_index_t *p_index_buffer, uint8_t *p_index_pos, uint16_t buffer_num )
{
    int32_t ret = -1;   //返回信息
    int32_t index = 0;
    int32_t num = 0;
    uint16_t next_pos = 0;  //下一个国家/标准编号
    uint16_t read_pos = 0;  //当前国家/标准编号
    uint16_t read_num = 0;
    
    int16_t find_region_index = -1;
    int16_t find_region_num = -1;
    
    int16_t find_setp = 0;

    uint16_t country_id_temp = 0;   //安规国家id
    uint16_t region_id_temp = 0;    //安规标准id


    if (p_header == NULL)
    {
        ret = -2;   //输入参数错误
        goto __exit;
    }
    if (safety_attr == NULL)
    {
        ret = -2;   //输入参数错误
        goto __exit;
    }
    //获取要查找的安规国家与地区
    country_id_temp = safety_attr->region >> 8;
    region_id_temp = safety_attr->region & 0x00FF;
    
    //批量查找国家
    read_pos = 0;
    while (read_pos < p_header->region_num)
    {
        //一次读取多个不同国家的信息
        num = safety_regula_package_index_find_country_by_index(p_safety_package_file, 0 + read_pos, p_header, p_index_buffer, p_index_pos, buffer_num);
        if (num > 0)
        {
            //比较这些国家是否是需要找的国家
            for (index = 0; index < num; index++)
            {
                if (p_index_buffer[index].country_id == country_id_temp)
                {
                    //找到了
                    find_region_index = p_index_pos[index] + 1 - p_index_buffer[index].region_index;
                    find_region_num = p_index_buffer[index].region_num;
                    find_setp = 1;
                    break;
                }
                else
                {
                    //更新下一个位置
                    next_pos = p_index_pos[index] + p_index_buffer[index].region_num - p_index_buffer[index].region_index +  1; 
                }
            }
            if (find_setp == 1)
            {
                //已经找到，需要继续跳出while
                break;
            }
            //没有找到继续下一次循环
            read_pos = next_pos;
        }
        else
        {
            //没有找到
            ret = -4;
            break;
        }
    }
    
    //查找标准
    if ((find_region_index >= 0) && (find_region_num > 0))
    {
        read_pos = 0;
        read_num = 0;
        while (read_pos < find_region_num)
        {
            //批量读取国家标准
            read_num = buffer_num;
            if (read_num > (find_region_num - read_pos))
            {
                read_num = (find_region_num - read_pos);
            }
            num = safety_regula_package_index_find_region_by_index(p_safety_package_file, find_region_index + read_pos, p_header, p_index_buffer, p_index_pos, read_num);
            if (num > 0)
            {
                //比较这些标准ID是否是需要找的标准ID
                for (index = 0; index < num; index++)
                {
                    if ((p_index_buffer[index].country_id == country_id_temp) &&
                        (p_index_buffer[index].region_id == region_id_temp))
                    {
                        //获取到当前的索引位置
                        ret = p_index_pos[index];
                        find_setp = 2;
                        break;
                    }
                }
            }
            if (find_setp == 2)
            {
                //已经找到，需要继续跳出while
                break;
            }
            //计算偏移地址
            read_pos += read_num;
        }
    }

__exit:
    return ret;
}

/**
 * @brief: 根据偏移，将安规库的指定安规标准提取成单独的bin文件
 * @param {int8_t} *p_safety_package_file 安规库文件路径
 * @param {int8_t} *p_bin_file 要生成的bin文件路径
 * @param {safety_attr_t} *safety_attr 安规标准代码
 * @param {safety_regula_package_index_t} *p_index 指定安规的安规索引信息
 * @return {1：输入参数错误，2：文件长度错误}
 * @note: 由于安规库里的单个安规包是用ASCII存储，与txt相同，故直接调用此函数sdk_safety_txt_to_bin()
 * @see: 
 * @date: 2023年1月7日
 */
static int8_t safety_lib_extract_bin(const int8_t *p_safety_package_file, int8_t *p_bin_file, safety_attr_t *safety_attr, safety_regula_package_index_t *p_index)
{
    int8_t ret = 0;
    uint32_t read_len = 0;
    uint32_t lib_offset = 0;

    //输入参数检验
    if (p_index == NULL || p_bin_file == NULL || safety_attr == NULL)
    {
        ret = 1;
        goto FILEERR;
    }
    read_len = p_index->file_size;
    if (read_len > SD_READ_BUFF_LEN)
    {
        ret = 2;
        goto FILEERR;
    }
    //获取偏移
    lib_offset = p_index->file_offset_addr;
    ret = sdk_safety_txt_to_bin(p_safety_package_file, p_bin_file, safety_attr, lib_offset);

FILEERR:
    return ret;
}

/**
 * @brief: 获取安规库的头部信息并检验
 * @param {int8_t} *p_safety_package_file 安规库文件路径
 * @param {safety_regula_package_header_t} *p_header_info 头文件信息
 * @return {0：正常，-1：头部信息不合法}
 * @note: 
 * @see: 
 * @date: 2023年1月9日
 */
int32_t sdk_safety_lib_header_get(const int8_t *p_safety_package_file, safety_regula_package_header_t *p_header_info)
{
    int32_t ret = 0;

    //从flash读取头信息
    ret = safety_regula_package_header_read(p_safety_package_file, p_header_info);
    if (0 != ret)
    {
        ret = -1;
        return ret;
    }

    //判断头部信息是否正确合法
    if (0 != safety_regula_package_header_check(p_header_info))
    {
        ret = -2;
    }

    return ret;
}

/**
 * @brief: 根据安国国家ID和标准索引获取安规标准相关信息
 * @param {int8_t} *p_safety_package_file 安规库路径
 * @param {safety_attr_t} *safety_attr 安规标准相关信息
 * @return {0：正常，-1：无该安规文件}
 * @note: 通过安规库里的信息获得
 * @see: 
 * @date: 
 */
int32_t sdk_safety_regula_find_by_lib(const int8_t *p_safety_package_file, safety_attr_t *safety_attr)
{
    int32_t ret = 0;
    int32_t index = 0;

    //根据安国国家ID和标准索引 查找安规文件
    index = safety_regula_package_index_find_by_country_region(p_safety_package_file, safety_attr, 
            &g_safety_regula_package_header, g_safety_regula_package_index_array, g_safety_regula_package_index_region_pos, MENU_PAGE_NUM);
    if (0 > index)
    {
        ret = -1;
    }
    else
    {
        //根据查到的索引位置 读取索引信息
        ret = safety_regula_package_index_read(p_safety_package_file, g_safety_regula_package_index_array, index, 1);
        if (0 != ret)
        {
            ret = -2;
        }
    }

   return ret;
}

/**
 * @brief: 选择安规标准，输出安规bin文件
 * @param {int8_t} *p_safety_package_file 安规库文件路径
 * @param {int8_t} *p_bin_file 要生成的bin文件路径
 * @param {safety_attr_t} *safety_attr  安规标准代码
 * @return {-1：头部信息不对，-2：安规库中没有该安规标准/索引信息读取错误，-3：生成单独的bin文件错误}
 * @note: 
 * @see: 
 * @date: 2023年1月7日
 */
int32_t sdk_safety_lib_select(const int8_t *p_safety_package_file, int8_t *p_bin_file, safety_attr_t *safety_attr)
{
    int32_t ret = 0;
    constant_parameter_data_t *p_constant_parameter = sdk_shm_constant_parameter_data_get();
    
    ret = sdk_safety_lib_header_get(p_safety_package_file, &g_safety_regula_package_header);
    if (0 != ret)
    {
        ret = -1;
        goto __exit;
    }
    //根据安国国家ID和标准索引 查找安规文件
    ret = sdk_safety_regula_find_by_lib(p_safety_package_file, safety_attr);
    if(0 != ret)
    {
        ret = -2;
        goto __exit;
    }
    //根据偏移读取安规文件并转换为单独的bin文件
    ret = safety_lib_extract_bin(p_safety_package_file, p_bin_file, safety_attr, &(g_safety_regula_package_index_array[0]));
    if (0 != ret)
    {
        ret = -3;
        goto __exit;
    }
    else
    {
        p_constant_parameter->safety_rdr_country = safety_attr->region;
        p_constant_parameter->ver_safety_rdr_para = safety_attr->version;
    }

__exit:
    return ret;
}

//////////////////////////////////////////////


/****************************************************************************
* 函数名   : struct_to_array()
* 功  能   : 结构体转字符串数组
* 输  入   : src
* 输  出   : buf
*/
// void struct_to_array(struct flash_data *src, unsigned char* buf)
// {  
// 	int32_t num;   
// 	unsigned char *temp = (unsigned char *)src ; 
// 	for(num=0; num<FLASH_DATA_SIZE; num++)     
// 		*(buf+num)= temp[num];  
// }

/****************************************************************************
* 函数名   : array_to_struct()
* 功  能   : 字符串数组转结构体
* 输  入   : buf
* 输  出   : src
*/
// void array_to_struct(unsigned char * buf, struct flash_data * src)
// {  
//     int32_t num;
//     unsigned char* temp = (unsigned char *)src;      
//     for(num=0; num<FLASH_DATA_SIZE; num++)
//         *(temp++) = buf[num];
// }

/***********************************************************************
 * 函数功能：int整型数据转十六进制数据赋值给字符，注意unsigned char防止溢出
 * 参数说明：buf为已转为16进制字符的出口参数，data为需要转换的整型入口参数， byteNum为整型转16进制字符占几个字节数
*/
// void IntToHex(unsigned char *buf, int32_t data, int32_t byteNum) 
// {
// 	int32_t i;
	
// 	for(i=0; i<byteNum; i++)
// 	{
// 		if(i < (byteNum-1)) 
// 		{
// 			buf[i] = data >> (8*(byteNum-i-1)); 
// 		}
// 		else
// 		{
// 			buf[i] = data % 256;
// 		}
// 	}
// }
