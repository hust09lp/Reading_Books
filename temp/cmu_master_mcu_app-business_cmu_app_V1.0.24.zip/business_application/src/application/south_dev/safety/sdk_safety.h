/************************************************************************************
 *Description: sdk_safety
 *Created on: 2022-11-02
 *Author: quliuliu
 ************************************************************************************/

#ifndef __SDK_SAFETY_H__
#define __SDK_SAFETY_H__

// #include "../../include/data_types.h"
#include "data_types.h"

#define DEBUG_SAFETY_LIB    (0)    //安规库操作的调试开关

#define  MENU_PAGE_NUM      8
// 每行最大长度
#define LINE_MAX 1024
//安规文件存取每帧大小
#define SAFETY_FRAME_SIZE 128

/**********************解析安规文件******************************/
#define SD_READ_BUFF_LEN    4096

//安规属性信息
typedef struct sdk_safety 
{
    uint16_t region;    //国家+地区=2字节
    uint16_t version;   //版本号=2字节
}safety_attr_t;

#pragma pack(1) //字节对齐
//安规库提取出的属性信息
typedef struct
{
    uint8_t         magic[4];
    uint32_t        len;                //文件长度 小端模式
    uint32_t        crc;                //crr校验
    uint32_t        version;            //版本号
    uint16_t        country_code_min;   //安规国家ID最小值
    uint16_t        country_code_max;   //安规国家ID最大值
    uint8_t         region_num;         //安规标准总数
    uint8_t         country_num;        //安规国家总数
}safety_regula_package_header_t;
#pragma pack()
#define SAFETY_REGULA_PACKAGE_HEADER_SIZE   sizeof(safety_regula_package_header_t)

#pragma pack(1) //字节对齐
//安规索引信息
typedef struct
{
    uint8_t         country_id;         //安规国家ID
    uint8_t         region_num;         //本国安规标准总数
    uint8_t         region_id;          //当前安规标准ID
    uint8_t         region_index;       //当前序号
    uint32_t        file_offset_addr;   //文件偏移地址
    uint16_t        file_size;          //文件大小
    uint8_t         country_name[16];
    uint8_t         region_name[16];
    uint16_t        version;
    uint16_t        version_ext;
}safety_regula_package_index_t;
#pragma pack()
#define SAFETY_REGULA_PACKAGE_INDEX_SIZE   sizeof(safety_regula_package_index_t)


// 安规包头信息FLASH读取的缓存
extern safety_regula_package_header_t  g_safety_regula_package_header;
//安规包索引信息 flash读取的缓存
extern safety_regula_package_index_t  g_safety_regula_package_index_array[MENU_PAGE_NUM];

#define SAFETY_REGULA_PACKAGE_HEADER_CHECK_MAGIC(magic)    \
    ((magic[0] == 'S') && (magic[1] == 'A') && (magic[2] == 'F') && (magic[3] == 'E') )


int32_t sdk_safety_txt_to_bin(const int8_t *p_txt_file, int8_t *p_bin_file, safety_attr_t *safety_attr, uint32_t index);

int32_t sdk_safety_bin_to_txt(const int8_t *p_bin_file, int8_t *p_txt_file, safety_attr_t safety_attr);

//获取安规库的头部信息并检验
int32_t sdk_safety_lib_header_get(const int8_t *p_safety_package_file, safety_regula_package_header_t *p_header_info);
//根据安国国家ID和标准索引获取安规标准相关信息
int32_t sdk_safety_regula_find_by_lib(const int8_t *p_safety_package_file, safety_attr_t *safety_attr);
//选择安规标准，输出安规bin文件
int32_t sdk_safety_lib_select(const int8_t *p_safety_package_file,int8_t *p_bin_file, safety_attr_t *safety_attr);

#endif /* __SDK_SAFETY_H__ */