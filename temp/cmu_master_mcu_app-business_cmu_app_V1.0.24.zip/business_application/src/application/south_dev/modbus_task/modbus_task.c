#include "data_map_proc.h"

#include "modbus_common.h"
#include "modbus-private.h"
#include "modbus.h"
#include "mem_utils.h"

#include <sys/epoll.h>
#include <pthread.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/socket.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>

#define MODBUS_DEBUG_ENABLE         0
#define MODBUS_TCP_RAW_DAT_PRINT    0

#if (1)
#define MODBUS_TASK_DEBUG(format, ...) do{ printf("[DEBUG]"); printf(format, ##__VA_ARGS__);} while(0)
#else
#define MODBUS_TASK_DEBUG(...) {do {} while(0);}
#endif

#define MODBUS_TASK_ERROR(format, ...) do{ printf("[ERROR]"); printf(format, ##__VA_ARGS__);} while(0)

#define EPOLL_WAIT_TM_OUT_MS        (1 * 1000)
#define MODBUS_TCP_CON_NUM          10
#define MAX_EVENTS                  (MODBUS_TCP_CON_NUM + 1)

#define  MODBUS_TCP_FRAME_HEAD_LEN_BYTE      7     // TCP帧头所占字节数
#define  MODBUS_RTU_FRAME_DATA_LEN_BYTE      1     // RTU帧头所占字节数


static int32_t modbus_analysis(modbus_t *ctx, const uint8_t *req, int32_t req_length);
static int32_t enable_keepalive(modbus_t *ctx);
static int32_t modbus_reply_info(modbus_t *ctx, modbus_frame_t *modbus_frame);
static int send_msg(modbus_t *ctx, uint8_t *msg, int msg_length);

void *thread_tcp_modbus(void *arg)
{
	modbus_t *ctx;
    int32_t server_socket, client_socket;
    int32_t epfd;
    struct epoll_event ev, events[MAX_EVENTS];
	modbus_mapping_t *tcp_mb_mapping = NULL;
    int32_t nfds, i;
	uint8_t query[MODBUS_TCP_MAX_ADU_LENGTH];
	int32_t rc = 0;

    MODBUS_TASK_DEBUG( " modbus tcp thread start \r\n");
    ctx = modbus_new_tcp("0.0.0.0", 1502);
	modbus_set_debug(ctx, MODBUS_DEBUG_ENABLE);
	if(ctx == NULL)
	{
		MODBUS_TASK_DEBUG(("modbus open tcp faild"));
		modbus_free(ctx);	
		pthread_exit(NULL);
	}

    server_socket = modbus_tcp_listen(ctx, 10);
    if (server_socket == -1) {
		MODBUS_TASK_DEBUG("\n\n modbus_tcp_listen fail \n\n");
		modbus_free(ctx);	
		pthread_exit(NULL);
    }

    epfd = epoll_create(10);
    if (epfd == -1) {
        MODBUS_TASK_DEBUG("Failed to create epoll instance\n");
        close(server_socket);
        modbus_free(ctx);
        pthread_exit(NULL);
    }

    ev.events = EPOLLIN;
    ev.data.fd = server_socket;
    if (epoll_ctl(epfd, EPOLL_CTL_ADD, server_socket, &ev) == -1) {
        MODBUS_TASK_DEBUG("Failed to add server socket to epoll\n");
        close(server_socket);
        modbus_free(ctx);
        pthread_exit(NULL);
    }

    for (;;) 
    {
        nfds = epoll_wait(epfd, events, MAX_EVENTS, EPOLL_WAIT_TM_OUT_MS);
        if (nfds == -1) {
            perror("epoll_wait failed\n");
            break;
        }

        for (i = 0; i < nfds; i++) 
		{
            if (events[i].data.fd == server_socket)
			{
                /* 本地服务端 socket 事件 */
                client_socket = modbus_tcp_accept(ctx, &server_socket);
                if (client_socket == -1) {
                    MODBUS_TASK_DEBUG("Accept failure\n");
                    continue;
                }
                MODBUS_TASK_DEBUG( "new client_socket: %d\r\n", client_socket );

                ev.events = EPOLLIN | EPOLLET;
                ev.data.fd = client_socket;
                if (epoll_ctl(epfd, EPOLL_CTL_ADD, client_socket, &ev) == -1) 
				{
                    MODBUS_TASK_DEBUG("Failed to add client socket to epoll\n");
                    close(client_socket);
                }
				else
				{
					MODBUS_TASK_DEBUG("add client socket fd %d to epoll\n",ev.data.fd);
					rc = enable_keepalive(ctx);
					if (rc == -1)
					{
						MODBUS_TASK_DEBUG("\n\n enable_keepalive fail \n\n");
					}
				}
            }
			else 
			{
                /* 客户端 socket 事件 */
				// MODBUS_TASK_DEBUG("receiv fd %d \n",events[i].data.fd);
				modbus_set_socket(ctx, events[i].data.fd);
                
                int rc = modbus_receive(ctx, query);
                if (rc > 0) {
                    
                    modbus_analysis(ctx, query, rc );
                    modbus_flush(ctx); // 清空缓存, 保证下一次正常数据可以通信
                }
				else 
				{
                	// MODBUS_TASK_DEBUG("del client socket %d to epoll\n",events[i].data.fd);
					// // if (get_Master_fd() == events[i].data.fd)
					// // {
					// // 	set_Master_fd(0);
					// // }
                    // epoll_ctl(epfd, EPOLL_CTL_DEL, events[i].data.fd, NULL);
                    // close(events[i].data.fd);
                }
            }
        }
    }

    close(server_socket);
    modbus_free(ctx);
    return NULL;
}

void modbus_start(void)
{
	pthread_t tcp_modbus;
	pthread_attr_t attr;

    data_map_proc_init();
    
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);

	if(pthread_create(&tcp_modbus,&attr,thread_tcp_modbus,NULL) != 0)
	{
		perror("pthread_create modbus_start");
	}
	
	pthread_attr_destroy(&attr);

	return;
}

#define CMU_MODBUS_LOCAL_SLAVE_ID           1

/**
 * @brief  modbus协议分析总入口函数，根据读表功能码再调用相关处理函数，
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
static int32_t modbus_analysis( modbus_t *ctx, const uint8_t *req, int32_t req_length )
{
    modbus_frame_t modbus_frame;

    modbus_frame.offset = ctx->backend->header_length;
    modbus_frame.address = ((req[modbus_frame.offset + 1]<<8)&0xff00)|((req[modbus_frame.offset + 2]<<0)&0x00ff);
    modbus_frame.reg_num = ((req[modbus_frame.offset + 3]<<8)&0xff00)|((req[modbus_frame.offset + 4]<<0)&0x00ff);
    modbus_frame.slave = *(req + modbus_frame.offset - 1);
	modbus_frame.function = *(req + modbus_frame.offset);
    modbus_frame.req = req;
    modbus_frame.req_length = req_length;

#if ( MODBUS_TCP_RAW_DAT_PRINT == 1 )
    printf("[%s:%d] start_add[%d], register_num[%d],func[%x]\n",__func__, __LINE__, modbus_frame.address,modbus_frame.reg_num,modbus_frame.function);
    mem_utils_print_hex_dat( "\r\nmodbus recv: ", req, req_length, 10, true );
#endif

    if(MODBUS_FC_WRITE_SINGLE_REGISTER == modbus_frame.function)
	{
		modbus_frame.reg_num = 1;
	} 
    if((modbus_frame.offset == MODBUS_TCP_FRAME_HEAD_LEN_BYTE) && ((modbus_frame.req[2] != 0) || (modbus_frame.req[3] != 0))) // 协议必须为00，表示modbus协议
    {
        MODBUS_TASK_ERROR( "modbus offset, head flag error.\n");
        modbus_reply_exception(ctx, modbus_frame.req, MODBUS_EXCEPTION_ILLEGAL_DATA_VALUE);
        return -1;
    }
    
    if (modbus_frame.slave != CMU_MODBUS_LOCAL_SLAVE_ID )
    {
        MODBUS_TASK_DEBUG("dev addr is error.\n");
        modbus_reply_exception(ctx, modbus_frame.req, MODBUS_EXCEPTION_SLAVE_OR_SERVER_FAILURE);
        return -1;
    }
	

    switch (modbus_frame.function)
    {
        case MODBUS_FC_READ_HOLDING_REGISTERS:
        case MODBUS_FC_WRITE_SINGLE_REGISTER:
        case MODBUS_FC_WRITE_MULTIPLE_REGISTERS:
            modbus_reply_info(ctx, &modbus_frame);
            break;

        default:
            modbus_reply_exception(ctx, req, MODBUS_EXCEPTION_ILLEGAL_FUNCTION);
            break;
    }

    return 0;
}




static int32_t enable_keepalive(modbus_t *ctx) {
    int32_t sock = modbus_get_socket(ctx);
    if (sock == -1) {
        return -1;
    }

    int32_t optval = 1;
    // Enable keep-alive
    if (setsockopt(sock, SOL_SOCKET, SO_KEEPALIVE, &optval, sizeof(optval)) < 0) {
        perror("setsockopt");
        return -1;
    }

    // Optional: Set keep-alive parameters
    // For example, set the start time and interval for probes
    int32_t keepidle = 30;   // Start keep-alive after 60 seconds
    int32_t keepinterval = 5; // Send a probe every 5 seconds
    int32_t keep_count = 5;
    if (setsockopt(sock, IPPROTO_TCP, TCP_KEEPIDLE, &keepidle, sizeof(keepidle)) < 0) {
        perror("setsockopt");
        return -1;
    }
    if (setsockopt(sock, IPPROTO_TCP, TCP_KEEPINTVL, &keepinterval, sizeof(keepinterval)) < 0) {
        perror("setsockopt");
        return -1;
    }
	if (setsockopt(sock, SOL_TCP, TCP_KEEPCNT, (void *)&keep_count, sizeof(keep_count))) {
		perror("Error setsockopt(TCP_KEEPCNT) failed");
		return -1;
	}			

    return 0;
}


/**
 * @brief  CSU数据读取总入口,函数里面对地址进行区分（依据协议点表大类分），再调用相关处理函数，
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
static int32_t modbus_reply_info(modbus_t *ctx, modbus_frame_t *modbus_frame)
{
    uint8_t reply [ MODBUS_MAX_MESSAGE_LENGTH ] = {0};
    uint8_t reply_len = 0;
    uint16_t reg_val[1024] = {0};
    sft_t sft;
    sf_ret_t ret = SF_ERR_NO_OBJECT;

    sft.slave    = modbus_frame->slave;
    sft.function = modbus_frame->function;
    sft.t_id     = ctx->backend->prepare_response_tid(modbus_frame->req, (int *)&(modbus_frame->req_length));

    if (modbus_frame->reg_num < 1 || MODBUS_MAX_READ_REGISTERS < modbus_frame->reg_num) 
    {
        /* 非法数据地址 */
        MODBUS_TASK_ERROR("modbus_reply_info reg_num error\n");
        return modbus_reply_exception(ctx, modbus_frame->req, MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS);
    }

    if (   modbus_frame->function == MODBUS_FC_READ_HOLDING_REGISTERS
        || modbus_frame->function == MODBUS_FC_READ_INPUT_REGISTERS )
    {
        ret = data_map_modbus_read_register( modbus_frame->address, modbus_frame->reg_num, reg_val );
    }
    else if (  modbus_frame->function == MODBUS_FC_WRITE_SINGLE_REGISTER 
            || modbus_frame->function == MODBUS_FC_WRITE_MULTIPLE_REGISTERS )
    {
        uint16_t *p_mb_fr_reg_val = ( modbus_frame->function == MODBUS_FC_WRITE_SINGLE_REGISTER )    ? (uint16_t *)&modbus_frame->req[ modbus_frame->offset + 3 ]:
                                    ( modbus_frame->function == MODBUS_FC_WRITE_MULTIPLE_REGISTERS ) ? (uint16_t *)&modbus_frame->req[ modbus_frame->offset + 6 ]: NULL ;
         
        for (size_t i = 0; i < modbus_frame->reg_num; i++)
        {
            reg_val[i] = htons( *p_mb_fr_reg_val++ );
        }
        ret = data_map_modbus_write_register( modbus_frame->address, modbus_frame->reg_num, reg_val );
        // ret = SF_OK;
    }
    
    if ( ret != SF_OK )
    {
        MODBUS_TASK_ERROR("modbus_reply_info error ret: %d\n", ret);
        return modbus_reply_exception(ctx, modbus_frame->req,
            (ret == SF_ERR_NO_OBJECT)? MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS :          /* 非法数据地址 */
            (ret == SF_ERR_FNOSUPP  )? MODBUS_EXCEPTION_ILLEGAL_FUNCTION :              /* 非法功能 */
                                       MODBUS_EXCEPTION_SLAVE_OR_SERVER_FAILURE );      /* 从站设备处理失败 */
    }

    /* 成功返回 */
	if (   modbus_frame->function == MODBUS_FC_WRITE_SINGLE_REGISTER 
	    || modbus_frame->function == MODBUS_FC_WRITE_MULTIPLE_REGISTERS )
	{
		reply_len = ctx->backend->build_response_basis( &sft, reply );
        /* 4 to copy the address (2) and the no. of registers */
        memcpy( reply + reply_len, modbus_frame->req + reply_len, 4);
        reply_len += 4;
	}
    else if( modbus_frame->function == MODBUS_FC_READ_HOLDING_REGISTERS
          || modbus_frame->function == MODBUS_FC_READ_INPUT_REGISTERS)
    {
        reply_len = ctx->backend->build_response_basis( &sft, reply);
        reply[ reply_len++ ] = modbus_frame->reg_num << 1;

        for ( size_t i = 0; i < modbus_frame->reg_num; i++) 
        {
            reply[ reply_len++ ] = reg_val[i] >> 8;
            reply[ reply_len++ ] = reg_val[i] & 0xFF;
        }
    }

    return (ctx->backend->backend_type == _MODBUS_BACKEND_TYPE_RTU &&
            modbus_frame->slave == MODBUS_BROADCAST_ADDRESS) ? 0 : send_msg(ctx, reply, reply_len); 
}

/**
 * @brief   modbus应答时间等待
 * @param   
 * @note    
 * @return  
 */
void _sleep_response_timeout(modbus_t *ctx)
{
    /* Response timeout is always positive */
#ifdef _WIN32
    /* usleep doesn't exist on Windows */
    Sleep((ctx->response_timeout.tv_sec * 1000) + (ctx->response_timeout.tv_usec / 1000));
#else
    /* usleep source code */
    struct timespec request, remaining;
    request.tv_sec = ctx->response_timeout.tv_sec;
    request.tv_nsec = ((long int) ctx->response_timeout.tv_usec) * 1000;
    while (nanosleep(&request, &remaining) == -1 && errno == EINTR) {
        request = remaining;
    }
#endif
}

/**
 * @brief   modbus发送数据
 * @param   
 * @note    
 * @return  
 */
static int send_msg(modbus_t *ctx, uint8_t *msg, int msg_length)
{
    int rc;
    int i;

    msg_length = ctx->backend->send_msg_pre(msg, msg_length);
    #if ( MODBUS_TCP_RAW_DAT_PRINT == 1 )
        mem_utils_print_hex_dat( "modbus send: ", msg, msg_length, 10, true );
    #endif
    
    /* In recovery mode, the write command will be issued until to be
       successful! Disabled by default. */
    do {
        rc = ctx->backend->send(ctx, msg, msg_length);
        if (rc == -1) {
            _error_print(ctx, NULL);
            if (ctx->error_recovery & MODBUS_ERROR_RECOVERY_LINK) {
#ifdef _WIN32
                const int wsa_err = WSAGetLastError();
                if (wsa_err == WSAENETRESET || wsa_err == WSAENOTCONN ||
                    wsa_err == WSAENOTSOCK || wsa_err == WSAESHUTDOWN ||
                    wsa_err == WSAEHOSTUNREACH || wsa_err == WSAECONNABORTED ||
                    wsa_err == WSAECONNRESET || wsa_err == WSAETIMEDOUT) {
                    modbus_close(ctx);
                    _sleep_response_timeout(ctx);
                    modbus_connect(ctx);
                } else {
                    _sleep_response_timeout(ctx);
                    modbus_flush(ctx);
                }
#else
                int saved_errno = errno;

                if ((errno == EBADF || errno == ECONNRESET || errno == EPIPE)) {
                    modbus_close(ctx);
                    _sleep_response_timeout(ctx);
                    modbus_connect(ctx);
                } else {
                    _sleep_response_timeout(ctx);
                    modbus_flush(ctx);
                }
                errno = saved_errno;
#endif
            }
        }
    } while ((ctx->error_recovery & MODBUS_ERROR_RECOVERY_LINK) && rc == -1);

    if (rc > 0 && rc != msg_length) {
        errno = EMBBADDATA;
        return -1;
    }

    return rc;
}
