#ifndef __MODBUS_COMMON_H__
#define __MODBUS_COMMON_H__

#include "sofar_type.h"

/* Modbus function codes 自定义功能码*/
#define MODBUS_FC_READ_DEVICE_IDENTIFIER    0x2B
#define MODBUS_FC_WRITE_FILE                0x41
#define MODBUS_FC_READ_FILE                 0x42
#define MODBUS_FC_READ_ENERGY               0x43
#define MODBUS_FC_HEART_BEAT                0x49
#define MODBUS_FC_DOWNLOAD_UPDATE_FILE      0x50
#define MODBUS_FC_START_UPDATE              0x51
#define MODBUS_FC_SPECIAL_RADIO_SET         0x52
#define MODBUS_FC_READ_ENTIRE_FILE          0x53

/* Modbus function codes 固件升级自定义子功能码*/
#define MODBUS_FC_SUB_START_UPDATE          0x01        //启动升级
#define MODBUS_FC_READ_UPDATE_STA_OLD       0x02        //读升级进度旧方案
#define MODBUS_FC_READ_UPDATE_FILE_STA      0x03        //读升级文件传输状态
#define MODBUS_FC_SET_UPDATE_TIME           0x04        //设置升级启动时间
#define MODBUS_FC_READ_UPDATE_TIME          0x05        //读升级启动时间
#define MODBUS_FC_READ_UPDATE_STA_NEW       0x06        //读升级进度新方案

/* Modbus function codes 自定义子功能码*/
#define MODBUS_FC_FILE_TYPE                 0x01        //设置文件类型
#define MODBUS_FC_OPERATE                   0x02        //执行操作，执行读或写
#define MODBUS_FC_END                       0x03        //传输结束

/* Read Device ID 码 */
#define MODBUS_FC_BASIC_DEVICE_ID           0x01        // basic device identification
#define MODBUS_FC_REGULAR_DEVICE_ID         0x02        //regular device identification
#define MODBUS_FC_EXTENDED_DEVICE_ID        0x03        //extended device identification
#define MODBUS_FC_SPECIFIC_DEVICE_ID        0x04        //specific identification objec

/* Modbus function codes 设备类型功能码 对象ID*/
#define MODBUS_FC_COMPANY_IDENTIFICATION    0x00        //供应商名称
#define MODBUS_FC_PRODUCT_CODE              0x01        //产品代码
#define MODBUS_FC_REVISED_VERSION           0x02        //主要修订版本
#define MODBUS_FC_COMPANY_WEB_SITE          0x03        //供应商网址
#define MODBUS_FC_PRODUCT_NAME              0x04        //产品名称
#define MODBUS_FC_TYPE_NAME                 0x05        //型号名称
#define MODBUS_FC_APP_NAME                  0x06        //应用程序名称

#define MODBUS_MAX_MESSAGE_LENGTH           260         //最大数据

#define PROTOCOL_EFFECTIVE_VERSION          2       //协议生效版本 0:3代MODBUS  1:4代MODBUS  2:4代2.0 MODBUS 

// 通用 Modbus 地址
#define USER_DEVICE_SYSTEM_ADDR_START               1001    // 设备系统参数起始地址
#define USER_DEVICE_SYSTEM_ADDR_END                 2000    // 设备系统参数结束地址
#define USER_PROTOCOL_COMPATIBLE_ADDR_START         20000   // 协议兼容信息开始地址
#define USER_PROTOCOL_COMPATIBLE_ADDR_END           20400   // 协议兼容信息结束地址

typedef struct {
    uint8_t slave;
    uint8_t function;
    uint8_t offset;
    uint16_t address;
    uint16_t reg_num;
    const uint8_t *req;
    int32_t req_length;
}modbus_frame_t;

/**************** 设备系统参数 ****************/
typedef struct{
	uint16_t tm_year;								//系统时钟：年							
	uint16_t tm_mon;								//系统时钟：月
	uint16_t tm_day;								//系统时钟：日
	uint16_t tm_hour;								//系统时钟：时
	uint16_t tm_min;								//系统时钟：分
	uint16_t tm_sec;								//系统时钟：秒
}device_system_param_t;

/**************** 协议兼容信息设置 ****************/
typedef struct{
    uint16_t protocol_effective_version;            // 协议生效版本
}user_protocol_compatible_info_t;
#endif

