#ifndef __MODBUS_TASK_H__
#define __MODBUS_TASK_H__

void modbus_start(void);

#endif
