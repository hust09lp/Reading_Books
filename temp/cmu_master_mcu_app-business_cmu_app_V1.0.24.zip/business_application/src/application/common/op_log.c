#include "sdk/sdk_fs.h"
#include "sdk/sdk_public.h"
#include "sdk/sdk_log.h"
#include "sqlite3.h"
#include "op_log.h"
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>

#define OPERATION_DB_PATH                   "/user/data/event/Operation.db"

static int32_t op_log_file_check(void);

/**
 * @brief   初始化操作日志结构体
 * @param   [in] 操作日志结构体指针
 * @param   [out] 操作日志结构体指针
 * @return  无
 */
void init_user_basic_info(operation_log_t *oplog)
{
	memset(oplog,0,sizeof(operation_log_t));
	strncpy((char *)oplog->phone_num,"未知",strlen("未知"));
	oplog->dev_sn[0] = 0; //序列号
	strncpy((char *)oplog->user_role,"未知",strlen("未知"));
	oplog->op_param1 = 0;
	oplog->op_param2 = 0;
	strncpy((char *)oplog->op_status,"failed",strlen("failed"));
}

/**
 * @brief   添加一条操作日志,该函数为公共函数,不同模块记录操作日志时调用该函数即可
 * @return  无
 */
void add_one_op_log(operation_log_t *p_oplog)
{
	sqlite3 *db = NULL;
    int32_t ret;
	char *errMsg = NULL;
	sdk_rtc_t rtc_time;
    uint8_t date_time[32] = {0};
		
	ret = sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
	if (ret != 0)
    {
		log_e((int8_t *)"\n [%s:%d] sdk_rtc_get fail \n", __func__, __LINE__);
		return;
    }
	snprintf((char*)date_time, 32, "%04d-%02d-%02d %02d:%02d:%02d", 2000 + rtc_time.tm_year,rtc_time.tm_mon, rtc_time.tm_day, rtc_time.tm_hour, rtc_time.tm_min, rtc_time.tm_sec);

    // 检查数据库文件是否存在，数据库文件大小是否为0,文件异常后删除并重新创建表单
    op_log_file_check();

    ret = sqlite3_open(OPERATION_DB_PATH, &db);
    if(ret) 
    {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return;
    }
    else
    {
        char *sql = "INSERT INTO Operation (USERNAME, PHONENUM, USERROLE, OPTYPE, DEVSN, PARAM1, PARAM2, OPSTATUS, TIME) VALUES \
            (?, ?, ?, ?, ?, ?, ?, ?, ?);";
        sqlite3_stmt *stmt;
        sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
        sqlite3_bind_text(stmt, 1, (const char*)p_oplog->user_name, -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt, 2, (const char*)p_oplog->phone_num, -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt, 3, (const char*)p_oplog->user_role, -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt, 4, (const char*)p_oplog->op_type, -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt, 5, (const char*)p_oplog->dev_sn, -1, SQLITE_STATIC);
        sqlite3_bind_double(stmt, 6, p_oplog->op_param1);
        sqlite3_bind_double(stmt, 7, p_oplog->op_param2);    
        sqlite3_bind_text(stmt, 8, (const char*)p_oplog->op_status, -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt, 9, (const char*)date_time, -1, SQLITE_STATIC);    

        ret = sqlite3_step(stmt);
    	if (ret != SQLITE_DONE) 
        {
            fprintf(stderr, "SQL error: %s\n", errMsg);
            sqlite3_free(errMsg);
        } 
        sqlite3_file_control(db, OPERATION_DB_PATH, SQLITE_FCNTL_SYNC, NULL);
        sqlite3_finalize(stmt);
    }
	sqlite3_close(db);
}

/**
 * @brief  检查操作日志数据库文件是否存在和有效
 * @param  [in] none
 * @param  [out] none
 * @return 0-数据库文件正常   -1-数据库文件异常
 */
static int32_t op_log_file_check(void)
{
	int32_t ret = -1;
	struct stat file_stat;
	
    ret = sdk_fs_access((const int8_t *)OPERATION_DB_PATH, F_OK);
    if (ret == -1)  // 文件不存在，创建该文件
    {
		log_e((const int8_t*)"\n Operation.db is not exist\n");
		op_log_sqlite_db_create_table();
		return (0);
    }
	else     // 文件存在，检查文件大小是否为0
	{
        ret = stat(OPERATION_DB_PATH,&file_stat);
        if(ret != SF_OK)
        {
            op_log_sqlite_db_create_table();
		    return (0);
        }
        else
        {
            if(file_stat.st_size == 0)
            {
                sdk_fs_remove((const int8_t *)OPERATION_DB_PATH);
                op_log_sqlite_db_create_table();
            }
        }
	
	}
	return (0);
}

/**
 * @brief  创建操作日志数据库文件
 * @param  
 * @param  
 * @return
 */
int32_t op_log_sqlite_db_create_table(void) 
{
    char *err_msg = NULL;
	int rc = 0;
    sqlite3 *db = NULL;

	char *sql_Faults = "CREATE TABLE IF NOT EXISTS Operation("  \
            "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
            "USERNAME       TEXT   NOT NULL," \
            "PHONENUM       TEXT   NOT NULL," \
            "USERROLE       TEXT   NOT NULL," \
            "OPTYPE         TEXT   NOT NULL," \
            "DEVSN          TEXT   NOT NULL," \
            "PARAM1         INT    NOT NULL," \
            "PARAM2         INT    NOT NULL," \
            "OPSTATUS       TEXT   NOT NULL," \
            "TIME           TEXT   NOT NULL);";

	char *sql_trigger = "CREATE TRIGGER limit_rows AFTER INSERT ON Operation "
						"BEGIN "
							"DELETE FROM Operation WHERE ID IN ("
								"SELECT ID FROM Operation "
								"ORDER BY ID ASC "
								"LIMIT (SELECT CASE WHEN (SELECT COUNT(*) FROM Operation) > 5000 THEN 1 ELSE 0 END)"
							"); "
						"END;";
	
    rc = sqlite3_open(OPERATION_DB_PATH, &db);
    if( rc ) 
    {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return(0);
    }

    rc = sqlite3_exec(db, sql_Faults, 0, 0, &err_msg);
    if (rc != SQLITE_OK) 
    {
        fprintf(stderr, "Failed to create table: %s\n", err_msg);
        sqlite3_free(err_msg);
    }

	rc = sqlite3_exec(db, sql_trigger, 0, 0, &err_msg);
	if (rc != SQLITE_OK) 
    {
		fprintf(stderr, "SQL error: %s\n", err_msg);
		sqlite3_free(err_msg);
	} else {
		fprintf(stdout, "Trigger created successfully\n");
	}
	
	sqlite3_close(db);
	return(1);
}
