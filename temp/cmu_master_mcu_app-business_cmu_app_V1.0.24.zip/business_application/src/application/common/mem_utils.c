#include "mem_utils.h"

void memcpy_bits( uint8_t *p_dst_dat, uint16_t dst_bit_offset, uint8_t *p_src_dat, uint16_t src_bit_offset, uint16_t cp_bit_len )
{
    uint16_t tmp_cp_bit_len = cp_bit_len;
    uint16_t dst_idx = 0, dst_bit_pos = 0;
    uint16_t src_idx = 0, src_bit_pos = 0;

    for ( ; tmp_cp_bit_len > 0; tmp_cp_bit_len--)
    {
        dst_idx     = dst_bit_offset >> 3;           //< /8
        dst_bit_pos = dst_bit_offset & 0x0007;       //< %8
        
        src_idx     = src_bit_offset >> 3;           //< /8
        src_bit_pos = src_bit_offset & 0x0007;       //< %8

        BIT_COPY_A_BIT( p_dst_dat[ dst_idx ], dst_bit_pos, p_src_dat[ src_idx ], src_bit_pos );

        dst_bit_offset++;
        src_bit_offset++;
    }
}

uint8_t mem_utils_get_bit_val( uint8_t *p_dat, uint16_t bit_offset )
{
    uint16_t idx = 0, bit_pos = 0;
    
    idx     = bit_offset >> 3;           //< /8
    bit_pos = bit_offset & 0x0007;       //< %8

    return (p_dat[ idx ] & BIT( bit_pos )) ? 1 : 0;
}

void mem_utils_set_bit_val( uint8_t *p_dat, uint16_t bit_offset, uint8_t bit_val )
{
    uint16_t idx = 0, bit_pos = 0;
    
    idx     = bit_offset >> 3;           //< /8
    bit_pos = bit_offset & 0x0007;       //< %8

    if ( bit_val == 0 )
    {
        p_dat[idx] &= ~BIT( bit_pos );
    }else if ( bit_val == 1 )
    {
        p_dat[idx] |= BIT( bit_pos );
    }
    
    return;
}

void mem_utils_print_hex_dat( const char *head_str, uint8_t *dat, uint16_t dat_len, uint8_t col_num, bool col_num_print  )
{
    if( head_str )
    {
        printf("%s ", head_str);
    }

    printf( "dat len:%d , data:", dat_len );
    for (size_t i = 0; i < dat_len; i++)
    {
        if( (i % col_num) == 0 )
        {
            printf( "\r\n" );
            if( col_num_print )
            {
                printf("%04d: ", i / col_num);
            }
        }
        printf( "%02X ", dat[i] );
    }
    printf( "\r\n");
}


void mem_utils_print_u16_dat( const char *head_str, uint16_t *dat, uint16_t dat_len, uint8_t col_num, bool col_num_print  )
{
    if( head_str )
    {
        printf("%s ", head_str);
    }

    printf( "dat len:%d , data:", dat_len );
    for (size_t i = 0; i < dat_len; i++)
    {
        if( (i % col_num) == 0 )
        {
            printf( "\r\n" );
            if( col_num_print )
            {
                printf("%04d: ", i / col_num);
            }
        }
        printf( "%04X ", dat[i] );
    }
    printf( "\r\n");
}

void mem_utils_u16_array_littleEndian_to_bigEndian( uint16_t *p_input_array, uint16_t input_cnt, uint16_t *p_output_array )
{
    for (size_t i = 0; i < input_cnt; i++)
    {
        *p_output_array = (*p_input_array << 8) | (*p_input_array >> 8) ;
        p_input_array++;
        p_output_array++;
    }
}

uint16_t mem_utils_cal_checksum( uint8_t *p_input_dat, uint16_t input_dat_len )
{
    uint16_t sum = 0;

    for (size_t i = 0; i < input_dat_len; i++)
    {
        sum += p_input_dat[i];
    }
    return sum;
}
