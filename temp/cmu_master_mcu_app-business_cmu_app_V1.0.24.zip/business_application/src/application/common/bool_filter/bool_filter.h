#ifndef __BOOL_FILTER_H__
#define __BOOL_FILTER_H__

#include "sofar_type.h"

// typedef uint16_t                filter_cnt_t;
// #define FILTER_CNT_INVALID      0xFFFF

// typedef uint32_t                filter_tm_ms_t;
// #define FILTER_TM_MS_INVALID    0xFFFFFFFF

/**
  * @struct 滤波器类型
  * @brief  
  */
typedef enum {
    FILTER_TYPE_TM,                 //< 以时间为准
    FILTER_TYPE_CNT,                //< 以次数为准
    FILTER_TYPE_TM_AND_CNT,         //< 以次数和时间为准 [与关系]
    FILTER_TYPE_MAX,                //< 最大值
} filter_type_e;

/* bool 滤波器 句柄 */
typedef void* bool_filter_hd;

typedef struct {
    usr_uint32_t  tm_ms; 
    usr_uint16_t  cnt;
} filter_setting_t;

/**
 * @brief  bool 滤波器 初始化
 * @param  [in] 无
 * @return 0：成功   1：失败
 * @note   
 */
sf_ret_t bool_filter_init( void );

/**
 * @brief  创建 bool 滤波器
 * @param  [in] type        : bool 滤波器 类型
 * @param  [in] valid_tm_ms : 数值 有效时间 
 * @param  [in] valid_cnt   : 数值 有效次数 
 * @return bool 滤波器句柄
 * @retval NULL：失败  非NULL: 成功
 * @note   
 */
bool_filter_hd bool_filter_create( filter_type_e type, filter_setting_t *p_true_setting, filter_setting_t *p_false_setting  );

/**
 * @brief  bool 滤波器 输入数据
 * @param  [in] hd     : bool 滤波器 句柄
 * @param  [in] value  : 输入数值
 * @return  0：成功   -1：失败
 * @note   
 */
bool_val_e bool_filter_input( bool_filter_hd hd, bool_val_e value );

/**
 * @brief  获取 bool 滤波器滤波之后的数值
 * @param  [in] hd  : bool 滤波器 句柄，不可为 NULL
 * @return  滤波之后的数值 （false/true）
 */
bool_val_e bool_filter_get_val( bool_filter_hd hd );

/**
 * @brief  设置 bool 滤波器 数值 【一般为初始化或是外部干涉使用】
 * @param  [in] hd  : bool 滤波器 句柄
 * @param  [in] val : 设置数值
 * @return  0：成功   -1：失败
 */
sf_ret_t bool_filter_set_val( bool_filter_hd hd, bool_val_e val );

void bool_filter_info_print( bool_filter_hd hd );

#endif
