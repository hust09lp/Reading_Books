#include "bool_filter.h"
#include "user_timer.h"

#include "sdk_log.h"
#include <string.h>
#include <stdlib.h>

/* 滤波器最大个数 */
#define MAX_BOOL_FILTER_CNT         50

typedef struct {
    uint16_t        cnt;                //< 有效 次数 
    uint32_t        tm_ms;              //< 有效时间，单位：1ms
} valid_setting_t;

/* bool 滤波器信息 */
typedef struct 
{
    struct {
        filter_type_e   type;                   //< 滤波器类型
        valid_setting_t true_valid;             //< true 有效设置 
        valid_setting_t false_valid;            //< false 有效设置
    } attr;                                     //< 属性
    struct {
        bool_val_e      value;                  //< 当前数值
        bool_val_e      new_val;                //< 新输入数值
        uint16_t        new_val_cnt;            //< 新输入数值 次数
        user_timer_hd   new_val_tm_hd;          //< 新输入数值 定时器 
    } run;                                      //< 运行数据
} bool_filter_info_t;

#if(1)
    #define BOOL_FILTER_LOG_D(...)      do{ printf(__VA_ARGS__); printf("\r\n"); }while (0);
#else
    #define BOOL_FILTER_LOG_D(...)      do{ }while (1);
#endif

#define BOOL_FILTER_LOG_E(...)      do{ printf("[ERROR]"); printf(__VA_ARGS__); printf("\r\n"); }while (0);

// static bool_filter_info_t s_bool_filter_infos[ MAX_BOOL_FILTER_CNT ] = { {0} };

static void _bool_filter_val_refresh( bool_filter_info_t *p_bool_filter_info );

/**
 * @brief  bool 滤波器 初始化
 * @param  [in] 无
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
sf_ret_t bool_filter_init( void )
{
    // memset( s_bool_filter_infos, 0, sizeof( s_bool_filter_infos ) );

    // for (size_t i = 0; i < MAX_BOOL_FILTER_CNT; i++)
    // {
    //     s_bool_filter_infos[ i ].run.value = BOOL_VAL_INVALID;
    // }

    return SF_OK;
}

/**
 * @brief  创建 bool 滤波器
 * @param  [in] type        : bool 滤波器 类型
 * @param  [in] valid_tm_ms : 数值 有效时间 
 * @param  [in] valid_cnt   : 数值 有效次数 
 * @return bool 滤波器句柄
 * @retval NULL：失败  非NULL: 成功
 * @note   
 */
bool_filter_hd bool_filter_create( filter_type_e type, filter_setting_t *p_true_setting, filter_setting_t *p_false_setting  )
{
    bool_filter_hd new_filter_hd = NULL;
    uint8_t i;
    
    /* 判断参数合法性 */
    if (    ( type >= FILTER_TYPE_MAX )
        || (( type == FILTER_TYPE_CNT ) && ( (p_true_setting->cnt == USR_U16_VAL_INVALID) || (p_false_setting->cnt == USR_U16_VAL_INVALID)))
        || (( type == FILTER_TYPE_TM  ) && ( (p_true_setting->tm_ms == USR_U32_VAL_INVALID) || (p_false_setting->tm_ms == USR_U32_VAL_INVALID)))
        || (( type == FILTER_TYPE_TM_AND_CNT ) && 
                ((p_true_setting->cnt == USR_U16_VAL_INVALID) || ( p_true_setting->tm_ms == USR_U32_VAL_INVALID) 
                || (p_false_setting->cnt == USR_U16_VAL_INVALID) || ( p_false_setting->tm_ms == USR_U32_VAL_INVALID) )))
    {
        BOOL_FILTER_LOG_E("%s param error!!!", __FUNCTION__);
        return NULL;
    }

    bool_filter_info_t *p_new_bool_filter = malloc( sizeof( bool_filter_info_t ) );

    if( p_new_bool_filter == NULL )
    {
        BOOL_FILTER_LOG_E( "p_new_bool_filter == NULL" );
        return NULL;
    }

    memset( p_new_bool_filter, 0, sizeof( bool_filter_info_t ) );
    p_new_bool_filter->attr.type              = type;
    p_new_bool_filter->attr.true_valid.cnt    = p_true_setting->cnt;
    p_new_bool_filter->attr.true_valid.tm_ms  = p_true_setting->tm_ms;
    p_new_bool_filter->attr.false_valid.cnt   = p_false_setting->cnt;
    p_new_bool_filter->attr.false_valid.tm_ms = p_false_setting->tm_ms;

    p_new_bool_filter->run.value         = BOOL_VAL_INVALID ;
    p_new_bool_filter->run.new_val       = BOOL_VAL_INVALID ;
    if ( (type == FILTER_TYPE_TM) || (type == FILTER_TYPE_TM_AND_CNT) )
    {
        p_new_bool_filter->run.new_val_tm_hd = user_timer_create( NULL, NULL ) ;
        if ( p_new_bool_filter->run.new_val_tm_hd == NULL )
        {
            BOOL_FILTER_LOG_E( "p_new_bool_filter->run.new_val_tm_hd == NULL" );
            free( p_new_bool_filter );
            return NULL;
        }
    }
    
    return p_new_bool_filter;
}


void bool_filter_info_print( bool_filter_hd hd )
{
    bool_filter_info_t *p_bool_filter_info = (bool_filter_info_t *)hd;

    BOOL_FILTER_LOG_D( "bool type:%d", p_bool_filter_info->attr.type );
    BOOL_FILTER_LOG_D( "true_valid.cnt:%d, tm_ms:%d", p_bool_filter_info->attr.true_valid.cnt, p_bool_filter_info->attr.true_valid.tm_ms );
    BOOL_FILTER_LOG_D( "false_valid.cnt:%d, tm_ms:%d", p_bool_filter_info->attr.false_valid.cnt, p_bool_filter_info->attr.false_valid.tm_ms );

    BOOL_FILTER_LOG_D( "val:%d, new val:%d, new val cnt:%d", p_bool_filter_info->run.value,
                                                                 p_bool_filter_info->run.new_val, 
                                                                 p_bool_filter_info->run.new_val_cnt);
    BOOL_FILTER_LOG_D( "new val timeout:%d", user_timer_is_timeout( p_bool_filter_info->run.new_val_tm_hd ));
}


/**
 * @brief  bool 滤波器 输入数据
 * @param  [in] hd     : bool 滤波器 句柄
 * @param  [in] value  : 输入数值 
 * @return  0：成功   -1：失败
 * @note   
 */
bool_val_e bool_filter_input( bool_filter_hd hd, bool_val_e value )
{
    bool_filter_info_t *p_bool_filter_info = (bool_filter_info_t *)hd;

    if ( hd == NULL || value > BOOL_VAL_TRUE )
    {
        BOOL_FILTER_LOG_E("%s input param error!!!", __FUNCTION__);
        return BOOL_VAL_INVALID;
    }

    if ( p_bool_filter_info->run.new_val != value )
    {
        /* 记录数据翻转时候状态 */
        p_bool_filter_info->run.new_val      = value;
        p_bool_filter_info->run.new_val_cnt  = 1;
        user_timer_set_timeout( p_bool_filter_info->run.new_val_tm_hd, 
                                (value == BOOL_VAL_TRUE)? p_bool_filter_info->attr.true_valid.tm_ms : p_bool_filter_info->attr.false_valid.tm_ms,
                                SF_FALSE );
    } else {
        p_bool_filter_info->run.new_val_cnt++;
    }

    _bool_filter_val_refresh( p_bool_filter_info );

    return p_bool_filter_info->run.value;
}

static void _bool_filter_val_refresh( bool_filter_info_t *p_bool_filter_info )
{
    /* 查看是否满足更新条件 */
    valid_setting_t *p_valid_setting;

    if ( ( p_bool_filter_info->run.new_val == BOOL_VAL_INVALID )
      || ( p_bool_filter_info->run.new_val == p_bool_filter_info->run.value ))
        return;

    if( p_bool_filter_info->run.new_val )
        p_valid_setting = &p_bool_filter_info->attr.true_valid;
    else 
        p_valid_setting = &p_bool_filter_info->attr.false_valid;

    if ( p_bool_filter_info->attr.type == FILTER_TYPE_CNT )
    {
        /* 次数滤波 判断 */
        if ( p_bool_filter_info->run.new_val_cnt >= p_valid_setting->cnt ) 
        {
            p_bool_filter_info->run.value = p_bool_filter_info->run.new_val;
        }

    } else if ( p_bool_filter_info->attr.type == FILTER_TYPE_TM )
    {
        /* 时间滤波 判断 */
        if ( user_timer_is_timeout( p_bool_filter_info->run.new_val_tm_hd ))
        {
            p_bool_filter_info->run.value = p_bool_filter_info->run.new_val;
        }

    } else if ( p_bool_filter_info->attr.type == FILTER_TYPE_TM_AND_CNT )
    {
        /* 时间和次数滤波 通知判断 */
        if (    user_timer_is_timeout( p_bool_filter_info->run.new_val_tm_hd )
            &&  p_bool_filter_info->run.new_val_cnt >= p_valid_setting->cnt )
        {
            p_bool_filter_info->run.value = p_bool_filter_info->run.new_val;
        }
    }
}

/**
 * @brief  获取 bool 滤波器滤波之后的数值
 * @param  [in] hd  : bool 滤波器 句柄，不可为 NULL
 * @return  滤波之后的数值 （false/true）
 */
bool_val_e bool_filter_get_val( bool_filter_hd hd )
{
    bool_filter_info_t *p_bool_filter_info = (bool_filter_info_t *)hd;

    if ( hd == NULL )
    {
        BOOL_FILTER_LOG_E("%s hd == NULL", __FUNCTION__);
        return BOOL_VAL_INVALID;
    }

    _bool_filter_val_refresh( p_bool_filter_info );

    return p_bool_filter_info->run.value;
}

/**
 * @brief  设置 bool 滤波器 数值 【一般为初始化或是外部干涉使用】
 * @param  [in] hd  : bool 滤波器 句柄
 * @param  [in] val : 设置数值
 * @return  0：成功   -1：失败
 */
sf_ret_t bool_filter_set_val( bool_filter_hd hd, bool_val_e val )
{
    bool_filter_info_t *p_bool_filter_info = (bool_filter_info_t *)hd;

    if ( hd == NULL )
    {
        BOOL_FILTER_LOG_E("%s hd == NULL", __FUNCTION__);
        return -1;
    }

    p_bool_filter_info->run.value         = val;
    p_bool_filter_info->run.new_val       = val;
    p_bool_filter_info->run.new_val_cnt   = 0;
    user_timer_refresh( p_bool_filter_info->run.new_val_tm_hd );

    return SF_OK;
}


/*--------------------------------------------------以下为测试代码--------------------------------------------------------*/
// #include "sdk_dido.h"

// #include <pthread.h>
// #include <unistd.h>

// static bool_val_e     usr_input_val   = BOOL_VAL_INVALID;
// static bool_filter_hd pin_bool_filter = NULL;

// static void _bool_filter_usr_input_init( void );

// void bool_filter_test( void )
// {
//     filter_setting_t true_filter_setting  = { .cnt = 3,  .tm_ms = 10000 } ;
//     filter_setting_t false_filter_setting = { .cnt = 1, .tm_ms = 5000 } ;
    
//     static bool_val_e filter_test_lv = BOOL_VAL_FALSE;
//     bool_val_e test_lv = BOOL_VAL_FALSE;
//     int32_t di_test_lv = 0;

//     printf("%s\r\n", __FUNCTION__);

//     pin_bool_filter = bool_filter_create( FILTER_TYPE_TM_AND_CNT, &true_filter_setting , &false_filter_setting );
//     bool_filter_set_val( pin_bool_filter, BOOL_VAL_FALSE );
    
//     _bool_filter_usr_input_init();

//     while( 1 )
//     {
//         // di_test_lv = sdk_dido_read( 4 );
//         // printf("di_test_lv:%d\r\n", di_test_lv );
//         // bool_filter_input( pin_bool_filter, di_test_lv );

//         printf("usr_input_val:%d\r\n", usr_input_val );
//         bool_filter_input( pin_bool_filter, usr_input_val );

//         if ( test_lv != bool_filter_get_val( pin_bool_filter ) )
//         {
//             test_lv = bool_filter_get_val( pin_bool_filter );
//             printf("----\r\n" );
//             printf("test_lv change:%d\r\n", test_lv );
//             printf("----\r\n" );
//         }
//         usleep( 500* 1000 );
//     }
// }

// static void *_bool_filter_usr_input_task( void *arg )
// {
//     int32_t usr_input_cmd = 0;

//     printf("%s", __FUNCTION__);
//     while (1)
//     {
//         printf( "please input usr cmd:" );
//         scanf( "%d", &usr_input_cmd );
//         printf( "usr_input_cmd:%d\r\n", usr_input_cmd );

//         switch ( usr_input_cmd )
//         {
//             case 0:
//                 usr_input_val = BOOL_VAL_FALSE;
//                 break;
//             case 1:
//                 usr_input_val = BOOL_VAL_TRUE;
//                 break;
//             case 2:
//                 usr_input_val = BOOL_VAL_INVALID;
//                 break;
//             case 3:
//                 bool_filter_info_print(pin_bool_filter);
//                 break;
//             default:
//                 break;
//         }
//         usleep( 100* 1000 );
//     }
// }

// static void _bool_filter_usr_input_init( void )
// {
//     pthread_t usr_input_thr_id;
//     int ret;

//     ret = pthread_create(&usr_input_thr_id, NULL, &_bool_filter_usr_input_task, NULL);
//     if ( ret )
//     {
//         BOOL_FILTER_LOG_E( "create usr input thread error!!!" );
//         return; 
//     }  
// }
