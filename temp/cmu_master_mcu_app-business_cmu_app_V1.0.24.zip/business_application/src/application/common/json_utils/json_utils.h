#ifndef _JSON_TOOL_H_
#define _JSON_TOOL_H_

#include "cJSON.h"
#include "sofar_type.h"

#include <float.h>

#define JSON_SPRINTF_END                            NULL

#define JS_VAL_INVALID_STR                          "js-null"
#define JS_VAL_INVALID_INT                          INT32_MIN
#define JS_VAL_INVALID_DBL                          DBL_MIN
#define JS_VAL_INVALID_BOOL                         false

#define JS_BOOL_VAL_STR(bool_val)                   (((bool_val) == true)? "true" : "false" )

#define JS_VAL_DEF_INIT(p_js_val, str_val_buf)      {                                                        \
                                                        (p_js_val)->int_val    = JS_VAL_INVALID_INT;             \
                                                        (p_js_val)->double_val = JS_VAL_INVALID_DBL;             \
                                                        (p_js_val)->bool_val   = JS_VAL_INVALID_BOOL;            \
                                                        if ( (str_val_buf) != NULL )                         \
                                                        {                                                    \
                                                            (p_js_val)->p_str_val = (str_val_buf);           \
                                                            strcpy( (p_js_val)->p_str_val, JS_VAL_INVALID_STR ); \
                                                        }                                                    \
                                                    }while(0);


typedef struct 
{
    enum {
        JS_VAL_TYPE_NUM,
        JS_VAL_TYPE_STR,
        JS_VAL_TYPE_BOOL,
    } type;
    struct 
    {
        int    int_val;   
        double double_val;   
        char*  p_str_val;   
        bool   bool_val;
    };
} js_val_t;

typedef struct 
{
    int    int_val;   
    double double_val;   
} js_num_t;

/**
 * @brief  类似 sprintf ，只是更适用于 json 格式化
 * @param  [in] buf ： 用户buff
 * @param  [in] fmt ： 格式化字符串
 * @return 格式化之后的长度
 * @note   
 * len = json_utils_sprintf( js_str_buff,    "{", 
 *                                                "\"name\": \"%s\" ,"             , "zhangSan",
 *                                                "\"info\": [{"
 *                                                    "\"male\": %s ,"             , JS_BOOL_VAL_STR( true ),
 *                                                    "\"age\": %d ,"              , 18,
 *                                                    "\"array\": [%d,%d,%d,%d]"  , num, num+1 ,num+2, num+3 
 *                                                "}]"
 *                                            "}", 
 *                                           JSON_SPRINTF_END );
 */
int json_utils_sprintf( char *buf, const char *fmt, ...);

/**
 * @brief  在 json_utils_sprintf 基础上添加了buff大小
 * @param  [in] buf  ： 用户buff
 * @param  [in] size ： buff大小
 * @param  [in] fmt  ： 格式化字符串
 * @return > 0: 格式化之后的长度  <0 : 失败
 * @note   
 */
int json_utils_snprintf(char *buf, size_t size, const char *fmt, ...);

/**
 * @brief  获取 p_js_obj 的 key_path 对应的子节点对象
 * @param  [in] p_js_obj ： json 对象
 * @param  [in] key_path ： key路径
 * @return 返回子节点对象，不存在则返回NULL
 * @note   
 */
cJSON* json_utils_get_item( const cJSON *p_js_obj, const char *key_path );

/**
 * @brief  获取 p_js_str 的 key_path 对应的子节点数值
 * @param  [in] p_js_str   ： json 字符串
 * @param  [in] key_path   ： key路径
 * @param  [out] p_get_val ： 对应的key-val的 value数值
 * @return SF_OK：成功  非SF_OK：失败
 * @note   
 */
sf_ret_t json_utils_str_get_leaf_val( const char *p_js_str, const char *key_path, js_val_t *p_get_val );

/**
 * @brief  往 p_src_js_str json字符串中加入新数值，并通过 p_dst_js_str 输出
 * @param  [out] p_dst_js_str  ： 输出json字符串
 * @param  [in] p_src_js_str   ： 输入json字符串
 * @param  [in] add_key_path   ： 新加入的key路径
 * @param  [in] p_add_val      ： 新加入的key-val的 value数值
 * @return SF_OK：成功  非SF_OK：失败
 * @note   
 */
sf_ret_t json_utils_str_add_leaf_val( char *p_dst_js_str, const char *p_src_js_str, const char *add_key_path, js_val_t *p_add_val );

/**
 * @brief  往 p_js_obj 对象获取 key路径下的数值
 * @param  [in] p_js_obj   ： 操作json对象
 * @param  [in] key_path   ： 新加入的key路径
 * @param  [in] p_get_val  ： 新加入的key-val的 value数值
 * @return SF_OK：成功  非SF_OK：失败
 * @note   
 */
sf_ret_t json_utils_obj_get_leaf_val( const cJSON *p_js_obj, const char *key_path, js_val_t *p_get_val );

/**
 * @brief  往 p_js_obj 对象中加入新数值
 * @param  [in] p_js_obj   ： 操作json对象
 * @param  [in] key_path   ： 新加入的key路径
 * @param  [in] p_add_val  ： 新加入的key-val的 value数值
 * @return SF_OK：成功  非SF_OK：失败
 * @note   
 */
sf_ret_t json_utils_obj_add_leaf_val( cJSON *p_js_obj, const char *key_path, js_val_t *p_add_val );

/**
 * @brief  判断 p_js_str 的 key_path 对应的子节点数值是否与 usr_str 相等
 * @param  [in] p_js_str   ： json 字符串
 * @param  [in] key_path   ： key路径
 * @param  [in] usr_str    ： 用户输入的字符串
 * @return true：相等  false：不相等
 * @note   
 */
bool json_utils_str_key_val_str_cmp( const char *p_js_str, const char *key_path, char *usr_str );

#endif
