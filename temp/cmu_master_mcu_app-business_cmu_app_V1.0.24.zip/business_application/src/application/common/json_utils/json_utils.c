#include "json_utils.h"

#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <float.h>

#if(1) 
    #define JS_UTILS_LOG_D(...)  do{ printf(__VA_ARGS__); }while(0)
    #define JS_UTILS_LOG_E(...)  do{ printf(__VA_ARGS__); }while(0)
#else
    #define JS_UTILS_LOG_D(...)  
    #define JS_UTILS_LOG_E(...)  
#endif

#define ELE_KEY_MAX_LEN         100

typedef enum {
    KEY_RET_NONE,
    KEY_RET_PARAM_ERR,                      // 参数错误
    KEY_RET_NEXT_KEY,                       // 存在下一个key
    KEY_RET_END,                            // 解析结束
} key_ret_e;                                // key_path 解析返回值

typedef struct {
    uint8_t element_flag  : 1;              // 是否是元素
    uint8_t array_idx_flag: 1;              // 是否是数组
} key_attr_t;

typedef struct 
{
    key_attr_t   key_attr;                         /* 属性 */
    char         ele_key[ ELE_KEY_MAX_LEN ];       /* 名称 */
    usr_uint16_t array_idx;                        /* 数组下标 */
} key_info_t;

static sf_ret_t _js_utils_js_obj_to_js_val( const cJSON *p_js_obj, js_val_t *p_js_val );
static key_ret_e _json_key_path_get_next_key( const char *p_key_path, const char **pp_next_key_path, key_info_t *p_key_info );
static const cJSON* _js_utils_get_sub_item( const cJSON *p_js_obj, key_info_t *p_sub_key_info );
static cJSON* _js_utils_create_obj_item( cJSON *p_js_obj, key_info_t *p_sub_key_info );
static sf_ret_t _js_utils_update_item_val( cJSON *p_js_obj, js_val_t *p_update_val );
static cJSON* _js_utils_create_leaf_item( cJSON *p_js_obj, key_info_t *p_sub_key_info, js_val_t *p_add_val );

/**
 * @brief  获取 p_js_obj 的 key_path 对应的子节点对象
 * @param  [in] p_js_obj ： json 对象
 * @param  [in] key_path ： key路径
 * @return 返回子节点对象，不存在则返回NULL
 * @note   
 */
cJSON* json_utils_get_item( const cJSON *p_js_obj, const char *key_path )
{
    const char  *p_curr_key_path = key_path;
    const cJSON *p_curr_js = p_js_obj;
    key_ret_e ret = KEY_RET_NONE;
    key_info_t key_info;

    while ( ret != KEY_RET_END )
    {
        const char *p_next_key_path = NULL;

        ret = _json_key_path_get_next_key( p_curr_key_path, &p_next_key_path, &key_info );
        if ( ret == KEY_RET_PARAM_ERR )
        {
            JS_UTILS_LOG_E("KEY_RET_PARAM_ERR, %s\r\n", p_curr_key_path );
            break;
        } 
        else if ( ret == KEY_RET_NEXT_KEY )
        {
            p_curr_js = _js_utils_get_sub_item( p_curr_js, &key_info );
            if ( p_curr_js == NULL )
            {
                break;
            }
            p_curr_key_path = p_next_key_path;
        } 
        else if ( ret == KEY_RET_END )
        {
            p_curr_js = _js_utils_get_sub_item( p_curr_js, &key_info );
            if ( p_curr_js == NULL )
            {
                break;
            }
            return (cJSON *)p_curr_js;
        }else{
            break;
        }
    }
    return NULL;
}
 
/**
 * @brief  在 p_js_obj 的 key_path 路径下创建对应的子节点对象，并赋值
 * @param  [in] p_js_obj   ： json 对象
 * @param  [in] key_path   ： key路径
 * @param  [out] p_add_val ： 对应的key-val的 value数值
 * @retval 非NULL : 新创建成功，并赋值的json对象  NULL : 创建失败
 **/
cJSON* json_utils_create_item( cJSON *p_js_obj, const char *key_path, js_val_t *p_add_val )
{
    const char  *p_curr_key_path = key_path;
    cJSON *p_curr_js = p_js_obj;
    key_ret_e ret = KEY_RET_NONE;
    key_info_t key_info;

    for ( ; ; )
    {
        const char *p_next_key_path = NULL;

        ret = _json_key_path_get_next_key( p_curr_key_path, &p_next_key_path, &key_info );
        // printf( "element_flag:%d, array_idx_flag:%d, key_info.ele_key: %s, array_idx:%d\r\n", key_info.key_attr.element_flag, key_info.key_attr.array_idx_flag, 
        //                                                                                       key_info.ele_key, key_info.array_idx );
        // printf( "ret:%d\r\n", ret);
        if ( ret == KEY_RET_PARAM_ERR )
        {
            JS_UTILS_LOG_E("KEY_RET_PARAM_ERR, %s\r\n", p_curr_key_path );
            return NULL;
        } 
        else if ( ret == KEY_RET_NEXT_KEY )
        {
            /* 中间节点 */
            p_curr_js = (cJSON*)_js_utils_get_sub_item( p_curr_js, &key_info );
            if ( p_curr_js == NULL )
            {
                /* 中间节点不存在, 创建节点 */
                p_curr_js = _js_utils_create_obj_item( p_curr_js, &key_info );
                if ( p_curr_js == NULL )
                {
                    /* 创建失败，直接返回 */
                    return NULL;
                }
            }
            p_curr_key_path = p_next_key_path;
        } 
        else if ( ret == KEY_RET_END )
        {
            /* 最终节点 */
            cJSON *p_leaf_js = (cJSON*)_js_utils_get_sub_item( p_curr_js, &key_info );
            if ( p_leaf_js != NULL )
            {
                /* 尾节点存在, 更新节点 */
                _js_utils_update_item_val( p_leaf_js, p_add_val );
                return (cJSON*)p_leaf_js;
            }

            /* 尾节点不存在, 创建节点 */
            p_leaf_js = _js_utils_create_leaf_item(  p_curr_js, &key_info, p_add_val );
            if ( p_leaf_js == NULL )
            {
                JS_UTILS_LOG_E( "js leaf item create error!!!\r\n" );
                return NULL;
            }
            return (cJSON *)p_curr_js;
        }else{
            break;
        }
    }
    return NULL;
}

/**
 * @brief  获取 p_js_str 的 key_path 对应的子节点数值
 * @param  [in] p_js_str   ： json 字符串
 * @param  [in] key_path   ： key路径
 * @param  [out] p_get_val ： 对应的key-val的 value数值
 * @return SF_OK：成功  非SF_OK：失败
 * @note   
 */
sf_ret_t json_utils_str_get_leaf_val( const char *p_js_str, const char *key_path, js_val_t *p_get_val )
{
    cJSON *p_js_obj = cJSON_Parse( p_js_str );
    if ( p_js_obj == NULL )
    {
        JS_UTILS_LOG_E( "js str parse error!!!\r\n" );
        return SF_ERR_PARA;
    }

    if (SF_OK != json_utils_obj_get_leaf_val( (const cJSON*)p_js_obj, key_path, p_get_val ))
    {
        cJSON_Delete( p_js_obj );
        return SF_ERR_PARA;
    }

    cJSON_Delete( p_js_obj );
    return SF_OK;
}

/**
 * @brief  往 p_src_js_str json字符串中加入新数值，并通过 p_dst_js_str 输出
 * @param  [out] p_dst_js_str  ： 输出json字符串
 * @param  [in] p_src_js_str   ： 输入json字符串
 * @param  [in] add_key_path   ： 新加入的key路径
 * @param  [in] p_add_val      ： 新加入的key-val的 value数值
 * @return SF_OK：成功  非SF_OK：失败
 * @note   
 */
sf_ret_t json_utils_str_add_leaf_val( char *p_dst_js_str, const char *p_src_js_str, const char *add_key_path, js_val_t *p_add_val )
{
    sf_ret_t ret = SF_ERR_NDEF;
    char *p_ret_str = NULL;

    cJSON *p_js_obj = cJSON_Parse( p_src_js_str );
    if ( p_js_obj == NULL )
    {
        JS_UTILS_LOG_E( "js str parse error!!!\r\n" );
        return SF_ERR_PARA;
    }

    ret = json_utils_obj_add_leaf_val( p_js_obj, add_key_path, p_add_val );
    if ( ret == SF_OK )
    {
        p_ret_str = cJSON_PrintUnformatted( p_js_obj );
        if (  p_ret_str == NULL )
        {
            JS_UTILS_LOG_E( "js str print error!!!\r\n" );
            ret = SF_ERR_PARA;
        }
    }

    if ( p_ret_str )
    {
        strcpy( p_dst_js_str, p_ret_str );
        free( p_ret_str );
    }
    cJSON_Delete( p_js_obj );
    return ret;
}

/**
 * @brief  判断 p_js_str 的 key_path 对应的子节点数值是否与 usr_str 相等
 * @param  [in] p_js_str   ： json 字符串
 * @param  [in] key_path   ： key路径
 * @param  [in] usr_str    ： 用户输入的字符串
 * @return true：相等  false：不相等
 * @note   
 */
bool json_utils_str_key_val_str_cmp( const char *p_js_str, const char *key_path, char *usr_str )
{
    cJSON *p_root_js = cJSON_Parse( p_js_str );
    if ( p_root_js == NULL )
    {
        return false;
    }

    cJSON *p_cmp_js = json_utils_get_item( p_root_js, key_path );
    if( p_cmp_js == NULL )
    {
        cJSON_Delete( p_root_js );
        return SF_FALSE;
    }

    if ( (p_cmp_js->type != cJSON_String) )
    {
        cJSON_Delete( p_root_js );
        return SF_FALSE;
    }

    if ( 0 == strcmp( p_cmp_js->valuestring, usr_str ) )
    {
        cJSON_Delete( p_root_js );
        return SF_TRUE;
    }else{
        cJSON_Delete( p_root_js );
        return SF_FALSE;
    }
}

/**
 * @brief  往 p_js_obj 对象中加入新数值
 * @param  [in] p_js_obj   ： 操作json对象
 * @param  [in] key_path   ： 新加入的key路径
 * @param  [in] p_add_val  ： 新加入的key-val的 value数值
 * @return SF_OK：成功  非SF_OK：失败
 * @note   
 */
sf_ret_t json_utils_obj_add_leaf_val( cJSON *p_js_obj, const char *key_path, js_val_t *p_add_val )
{
    if ( NULL != json_utils_create_item( p_js_obj, key_path, p_add_val ) )
    {
        return SF_OK;
    }else{
        return SF_ERR_PARA;
    }
}

/**
 * @brief  往 p_js_obj 对象获取 key路径下的数值
 * @param  [in] p_js_obj   ： 操作json对象
 * @param  [in] key_path   ： 新加入的key路径
 * @param  [in] p_get_val  ： 新加入的key-val的 value数值
 * @return SF_OK：成功  非SF_OK：失败
 * @note   
 */
sf_ret_t json_utils_obj_get_leaf_val( const cJSON *p_js_obj, const char *key_path, js_val_t *p_get_val )
{
    const cJSON *p_leaf_js = json_utils_get_item( p_js_obj, key_path );

    if ( p_leaf_js == NULL )
    {
        return SF_ERR_NO_OBJECT;
    }
    if ( SF_OK != _js_utils_js_obj_to_js_val( p_leaf_js, p_get_val ))
    {
        return SF_ERR_PARA;
    }
    return SF_OK;
}

/**
 * @brief  将 p_js_obj 对象转换为 js_val_t数值
 * @param  [in] p_js_obj   ： 操作json对象
 * @param  [out] p_get_val ： 对应的key-val的 value数值
 * @return SF_OK：成功  非SF_OK：失败
 * @note   
 */
static sf_ret_t _js_utils_js_obj_to_js_val( const cJSON *p_js_obj, js_val_t *p_js_val )
{
    if (   p_js_obj->type & cJSON_False
        || p_js_obj->type & cJSON_True   )
    {
        p_js_val->type     = JS_VAL_TYPE_BOOL;
        p_js_val->bool_val = (p_js_obj->type & cJSON_True)? true: false;
        return SF_OK;
    } 
    else if ( p_js_obj->type & cJSON_Number  )
    {
        p_js_val->type        = JS_VAL_TYPE_NUM;
        p_js_val->int_val     = p_js_obj->valueint;
        p_js_val->double_val  = p_js_obj->valuedouble;
        return SF_OK;
    }
    else if ( p_js_obj->type & cJSON_String  )
    {
        if ( p_js_val->p_str_val == NULL )
        {
            JS_UTILS_LOG_E( "p_js_val->p_str_val == NULL\r\n" );
            return SF_ERR_PARA;
        }
        p_js_val->type = JS_VAL_TYPE_STR;
        strcpy( p_js_val->p_str_val, p_js_obj->valuestring );
        return SF_OK;
    }
    
    return SF_ERR_PARA;
}

/**
 * @brief 在当前p_js_obj下创建子项
 * @param [in] p_js_obj       ： 当前 json 对象
 * @param [in] p_sub_key_info ： 要创建的子项信息
 * @retval 非NULL : 新创建成功，并赋值的json对象  NULL : 创建失败
 * @note   
 */
static cJSON* _js_utils_create_obj_item( cJSON *p_js_obj, key_info_t *p_sub_key_info )
{
    cJSON *p_ret_js = NULL;

    if ( p_js_obj == NULL || p_sub_key_info == NULL )
    {
        JS_UTILS_LOG_E("p_js_obj == NULL || p_sub_key_info == NULL\r\n");
        return NULL;
    }

    if (    p_sub_key_info->key_attr.element_flag   == 1 
        &&  p_sub_key_info->key_attr.array_idx_flag == 0 )
    {
        /* 普通节点， eg: /element */
        p_ret_js = cJSON_AddObjectToObject( p_js_obj, p_sub_key_info->ele_key );
    }
    else if ( p_sub_key_info->key_attr.element_flag  == 1 
        &&   p_sub_key_info->key_attr.array_idx_flag == 1 )
    {
        /* 数组节点， eg: /element[*] */
        JS_UTILS_LOG_E("unsupport ele:1 array:1 !!!\r\n");
    }
    else if ( p_sub_key_info->key_attr.element_flag  == 0 
        &&   p_sub_key_info->key_attr.array_idx_flag == 1 )
    {
        /* 数组索引， eg: /[*] */
        JS_UTILS_LOG_E("unsupport ele:0 array:1 !!!\r\n");
    } 
    else
    {
        /* 格式不正确，无法创建 */
        JS_UTILS_LOG_E("format error!!!\r\n");
    }

    if ( p_ret_js == NULL )
    {
        JS_UTILS_LOG_E("create obj item fail!!!\r\n");
    }

    return p_ret_js;
}

/**
 * @brief 在当前p_js_obj下创建叶子项，并直接赋值
 * @param [in] p_js_obj       ： 当前 json 对象
 * @param [in] p_sub_key_info ： 要创建的子项信息
 * @param [in] p_add_val      ： 要创建的子项数值
 * @retval 非NULL : 新创建成功，并赋值的json对象  NULL : 创建失败
 * @note   
 */
static cJSON* _js_utils_create_leaf_item( cJSON *p_js_obj, key_info_t *p_sub_key_info, js_val_t *p_add_val )
{
    cJSON *p_ret_js = NULL;

    if ( p_js_obj == NULL || p_sub_key_info == NULL || p_add_val == NULL )
    {
        JS_UTILS_LOG_E("p_js_obj == NULL || p_sub_key_info == NULL || p_add_val == NULL\r\n");
        return NULL;
    }

    if (    p_sub_key_info->key_attr.element_flag   == 1 
        &&  p_sub_key_info->key_attr.array_idx_flag == 0 )
    {
        /* 普通节点， eg: /element */
        switch ( p_add_val->type )
        {
            case JS_VAL_TYPE_NUM:
                p_ret_js = cJSON_AddNumberToObject( p_js_obj, p_sub_key_info->ele_key, p_add_val->int_val );
                break;

            case JS_VAL_TYPE_STR:
                p_ret_js = cJSON_AddStringToObject( p_js_obj, p_sub_key_info->ele_key, p_add_val->p_str_val );
                break;

            case JS_VAL_TYPE_BOOL:
                p_ret_js = cJSON_AddBoolToObject( p_js_obj, p_sub_key_info->ele_key, p_add_val->bool_val );
                break;
        
            default:
                JS_UTILS_LOG_E("p_add_val->type error!!!\r\n");
        }
    }
    else if ( p_sub_key_info->key_attr.element_flag  == 1 
        &&   p_sub_key_info->key_attr.array_idx_flag == 1 )
    {
        /* 数组节点， eg: /element[*] */
        JS_UTILS_LOG_E("unsupport ele:1 array:1 !!!\r\n");
    }
    else if ( p_sub_key_info->key_attr.element_flag  == 0 
        &&   p_sub_key_info->key_attr.array_idx_flag == 1 )
    {
        /* 数组索引， eg: /[*] */
        JS_UTILS_LOG_E("unsupport ele:0 array:1 !!!\r\n");
    } 
    else
    {
        /* 格式不正确，无法创建 */
        JS_UTILS_LOG_E("format error!!!\r\n");
    }

    if ( p_ret_js == NULL )
    {
        JS_UTILS_LOG_E("create leaf item fail!!!\r\n");
    }

    return p_ret_js;
}

/**
 *  @brief 更新json对象中的值
 *  @param [in] p_js_obj       ： 当前 json 对象
 *  @param [in] p_update_val   ： 要更新的数值
 *  @retval SF_OK：成功   非SF_OK：失败
 */
static sf_ret_t _js_utils_update_item_val( cJSON *p_js_obj, js_val_t *p_update_val )
{
    if ( p_js_obj == NULL || p_update_val == NULL )
    {
        JS_UTILS_LOG_E("p_js_obj == NULL || p_update_val == NULL\r\n");
        return SF_ERR_PARA;
    }

    if (   p_update_val->type == JS_VAL_TYPE_NUM
        && p_js_obj->type == cJSON_Number )
    {
        cJSON_SetNumberValue( p_js_obj, p_update_val->int_val );
    }
    else if ( p_update_val->type == JS_VAL_TYPE_STR
           && p_js_obj->type == cJSON_String )
    {
        cJSON_SetValuestring( p_js_obj, p_update_val->p_str_val );
    }
    else if (  p_update_val->type == JS_VAL_TYPE_BOOL
            && (p_js_obj->type == cJSON_False || p_js_obj->type == cJSON_True) )
    {
        cJSON_SetBoolValue( p_js_obj, p_update_val->bool_val );
    }
    else
    {
        JS_UTILS_LOG_E("p_update_val->type error!!!\r\n");
        return SF_ERR_PARA;
    }

    return SF_OK;
}

/**
 *  @brief 获取 p_js_obj下是否存在 p_sub_key_info 子项
 *  @param [in] p_js_obj       ： 当前 json 对象
 *  @param [in] p_sub_key_info ： 要获取的子项信息
 *  @return 非NULL : 子项对象   NULL : 获取失败
 */
static const cJSON* _js_utils_get_sub_item( const cJSON *p_js_obj, key_info_t *p_sub_key_info )
{
    const cJSON *p_parent_js = NULL;
    const cJSON *p_sub_js    = NULL;
    
    if ( p_js_obj == NULL || p_sub_key_info == NULL )
    {
        JS_UTILS_LOG_E("p_js_obj == NULL || p_sub_key_info == NULL\r\n");
        return NULL;
    }

    if ( p_sub_key_info->key_attr.element_flag == 1 )
    {
        p_parent_js = p_js_obj;
        p_sub_js = cJSON_GetObjectItem( p_parent_js, p_sub_key_info->ele_key );
        if ( p_sub_js == NULL )
        {
            JS_UTILS_LOG_E("get ele_key:%s fail!!!\r\n", p_sub_key_info->ele_key );
            return NULL;
        }
    }

    if ( p_sub_key_info->key_attr.array_idx_flag == 1 )
    {
        p_parent_js = ( p_sub_js != NULL )? p_sub_js: p_js_obj;
        p_sub_js = cJSON_GetArrayItem( p_parent_js, (int)p_sub_key_info->array_idx );
        if ( p_sub_js == NULL )
        {
            JS_UTILS_LOG_E("get ele_key %s[%d] fail!!!\r\n", p_sub_key_info->ele_key ,p_sub_key_info->array_idx );
            return NULL;
        }
    }

    return p_sub_js;
}


// inline
sf_ret_t _extract_array_idx_from_key_path( const char *p_key_path, const char **pp_next_key_path, uint16_t *p_array_idx )
{
    char num_str[20]    = {0};
    uint8_t num_str_idx = 0;

    /* 数组 '[' 开头 */
    if ( p_key_path[0] != '[' )
    {
        return SF_ERR_PARA;
    }

    /* 提取数字 */
    const char *p_str = &p_key_path[1];
    while ( (*p_str >= '0') && (*p_str <= '9') )
    {
        num_str[ num_str_idx++ ] = *p_str++;
    }

    /* 数组 ']' 结尾 */
    if( *p_str++ != ']' )
    {
        return SF_ERR_PARA;
    }

    *p_array_idx = (uint16_t)atoi( num_str );
    *pp_next_key_path = (char *)p_str;

    return SF_OK;
}


/**
 *  @brief 解析 p_key_path 并获取第一个key字符串
 *  @param [in] p_key_path        ： key路径
 *  @param [out] pp_next_key_path ： 下一个key路径
 *  @param [out] p_key_info       ： 获取的key信息
 *  @retval KEY_RET_PARAM_ERR : 参数错误
 *          KEY_RET_NEXT_KEY  ：存在下一个key
 *          KEY_RET_END       ：不存在下一个key，解析结束
 * */
static key_ret_e _json_key_path_get_next_key( const char *p_key_path, const char **pp_next_key_path, key_info_t *p_key_info )
{
    key_ret_e  ret = KEY_RET_NONE;
    uint16_t array_idx = 0;
    const char *p_dat_str = NULL;

    if ( p_key_path == NULL )
    {
        return KEY_RET_PARAM_ERR;
    }
    memset( p_key_info, 0, sizeof(key_info_t) );
    if ( p_key_path[0] == '/' )
    {
        /* 获取元素 */
        char *p_dst_str = p_key_info->ele_key;
        p_dat_str = &p_key_path[1];

        /* 提取key字符串 */
        p_key_info->key_attr.element_flag = 1;
        memset( p_key_info->ele_key, 0, sizeof(p_key_info->ele_key));
        while( (*p_dat_str != '[') && (*p_dat_str != '/') && (*p_dat_str != '\0')  )
        {
            *p_dst_str++ = *p_dat_str++;
        }
        *pp_next_key_path = p_dat_str;

        /* 提取数组索引 */
        if ( *p_dat_str == '[' )
        {
            /* 该元素为数组 */
            if ( SF_OK != _extract_array_idx_from_key_path( p_dat_str , pp_next_key_path, &array_idx ))
            {
                return KEY_RET_PARAM_ERR;
            }
            p_key_info->key_attr.array_idx_flag = 1;
            p_key_info->array_idx = array_idx;
            p_dat_str = *pp_next_key_path;
        }
    }else if ( p_key_path[0] == '[' )
    {
        /* 本元素为数组索引 */
        p_dat_str = &p_key_path[0];
        if ( SF_OK != _extract_array_idx_from_key_path( p_dat_str , pp_next_key_path, &array_idx ) )
        {
            return KEY_RET_PARAM_ERR;
        }

        p_key_info->key_attr.array_idx_flag = 1;
        p_key_info->array_idx = array_idx;
        p_dat_str = *pp_next_key_path;
    }
    
    /* 结束 */
    if ( p_dat_str == NULL )
    {
        /* 错误参数 */            
        return KEY_RET_PARAM_ERR;
    }

    return ( *p_dat_str == '/'  ) ? KEY_RET_NEXT_KEY  :     /* 下一个元素 */
           ( *p_dat_str == '\0' ) ? KEY_RET_END       :     /* 解析结束 */
                                    KEY_RET_PARAM_ERR ;     /* 错误参数 */  
}

// void json_utils_test( void )
// {
//     char js_str_buff[200] = {0};
//     int num = 100;
//     char js_val_buf[100];
//     int len;

//     while (1)
//     {
//         len = json_utils_sprintf( js_str_buff,    "{", 
//                                                 "\"name\": \"%s\" ,"             , "chenhuanjian",
//                                                 "\"info\": [{"
//                                                     "\"address\": \"%s\" ,"      , "ShenZhen",
//                                                     "\"male\": %s ,"             , JS_BOOL_VAL_STR( true ),
//                                                     "\"age\": %d ,"              , 18,
//                                                     "\"array\": [%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d]"  , num, num+1 ,num+2, num+3 ,num+4, num+5 ,num+6, 
//                                                                                                           num+7 ,num+8, num+9 ,num+10, num+11,
//                                                 "}]"
//                                             "}", 
//                                     JSON_SPRINTF_END );
//         printf("js_str_buff:%s, len = %d, strlen = %d \r\n", js_str_buff, len, (int)strlen( js_str_buff ));

//         js_val_t js_val = {.p_str_val = js_val_buf};
//         sf_ret_t ret;

//         printf( "json_strl test\r\n" );

//         // ret = json_utils_str_get_leaf_val( js_str_buff, "/info[0]/array[11]", &js_val );
//         // printf( "/info[0]/array[1] - js_val.int_val:%d, js_val.int_val:%lf, ret:%d\r\n", js_val.int_val, js_val.double_val, ret );

//         // ret = json_utils_str_get_leaf_val( js_str_buff, "/info[0]/male", &js_val );
//         // printf( "/info[0]/male - js_val.bool_val:%d, ret:%d\r\n", js_val.bool_val, ret );

//         // ret = json_utils_str_get_leaf_val( js_str_buff, "/info[0]/age", &js_val );
//         // printf( "/info[0]/age - js_val.int_val:%d, js_val.int_val:%lf, ret:%d\r\n", js_val.int_val, js_val.double_val, ret );

//         // ret = json_utils_str_get_leaf_val( js_str_buff, "/name", &js_val );
//         // printf( "/name - js_val.p_str_val:%s, ret:%d\r\n", js_val.p_str_val, ret );

//         // ret = json_utils_str_get_leaf_val( js_str_buff, "/info[0]/address", &js_val );
//         // printf( "/info/address - js_val.p_str_val:%s, ret:%d\r\n", js_val.p_str_val, ret );

//         // ret = json_utils_str_get_leaf_val( js_str_buff, "/info[0]", &js_val );
//         // printf( "/info - js_val.p_str_val:%s, ret:%d\r\n", js_val.p_str_val, ret );

//         printf( "json_obj test\r\n" );
//         cJSON *p_root_js = cJSON_Parse( js_str_buff );

//         ret = json_utils_obj_get_leaf_val( p_root_js, "/info[0]/array[11]", &js_val );
//         printf( "/info[0]/array[1] - js_val.int_val:%d, js_val.int_val:%lf, ret:%d\r\n", js_val.int_val, js_val.double_val, ret );

//         ret = json_utils_obj_get_leaf_val( p_root_js, "/info[0]/male", &js_val );
//         printf( "/info[0]/male - js_val.bool_val:%d, ret:%d\r\n", js_val.bool_val, ret );

//         ret = json_utils_obj_get_leaf_val( p_root_js, "/info[0]/age", &js_val );
//         printf( "/info[0]/age - js_val.int_val:%d, js_val.int_val:%lf, ret:%d\r\n", js_val.int_val, js_val.double_val, ret );

//         ret = json_utils_obj_get_leaf_val( p_root_js, "/name", &js_val );
//         printf( "/name - js_val.p_str_val:%s, ret:%d\r\n", js_val.p_str_val, ret );

//         ret = json_utils_obj_get_leaf_val( p_root_js, "/info[0]/address", &js_val );
//         printf( "/info/address - js_val.p_str_val:%s, ret:%d\r\n", js_val.p_str_val, ret );

//         cJSON *p_item_js = json_utils_get_item( p_root_js, "/info[0]");
//         printf( "/info[0] - js_val.p_str_val:%s, ret:%d\r\n", js_val.p_str_val, ret );

//         sleep(1);
//     }
// }

