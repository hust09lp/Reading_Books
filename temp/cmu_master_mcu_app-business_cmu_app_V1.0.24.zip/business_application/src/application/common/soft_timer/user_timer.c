#include "user_timer.h"

#include "sdk_log.h"

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>
#include <string.h>


typedef struct 
{
    timer_t         timer_id;              // 系统定时器id
    uint32_t        timeout_ms;            // 定时时间，单位：1ms
    bool            cycle;                 // 是否循环，true：循环  false：单次
    user_timeout_cb p_usr_timeout_cb;      // 超时回调函数
    void            *p_usr_arg;            // 回调函数参数
} user_timer_node_t;

#if (1)
    #define USER_TIMER_LOG_D(...) do { log_i((const int8_t*)__VA_ARGS__);} while(0) 
#else
    #define USER_TIMER_LOG_D(...) {do {} while(0);}
#endif

#define USER_TIMER_LOG_E(...) do{ log_e((const int8_t*)__VA_ARGS__); }while(0)

static void _user_timeout_handle( union sigval sv )
{
    if ( sv.sival_ptr == NULL )
        return;
    
    user_timer_node_t *p_usr_tm = (user_timer_node_t *)sv.sival_ptr;

    if ( p_usr_tm->p_usr_timeout_cb == NULL )
        return;

    p_usr_tm->p_usr_timeout_cb( p_usr_tm->p_usr_arg );
}

/**
 * @brief  创建用户定时器
 * @param  [in] timeout_cb ： 超时回调函数，可为NULL
 * @param  [in] p_cb_arg   ： 回调函数参数
 * @return 返回定时器句柄，NULL为创建失败
 * @note   
 */
user_timer_hd user_timer_create( user_timeout_cb timeout_cb, void *p_cb_arg )
{
    struct sigevent sev;

    user_timer_node_t *p_usr_tm = malloc( sizeof( user_timer_node_t ) );

    if ( p_usr_tm == NULL )
    {
        USER_TIMER_LOG_E( "create user_timer_node_t error" );
        return NULL;
    }

    if ( timeout_cb == NULL )
    {
        sev.sigev_notify = SIGEV_NONE;
        sev.sigev_value.sival_ptr = NULL;
        sev.sigev_notify_function = NULL;
    }else{

        sev.sigev_notify = SIGEV_THREAD;
        sev.sigev_value.sival_ptr = (void *)p_usr_tm;
        sev.sigev_notify_function = _user_timeout_handle;
        
        p_usr_tm->p_usr_timeout_cb = timeout_cb;
        p_usr_tm->p_usr_arg        = p_cb_arg;
    }
    sev.sigev_notify_attributes = NULL;


    if (timer_create(CLOCK_REALTIME, &sev, &p_usr_tm->timer_id) == -1) 
    {
        USER_TIMER_LOG_E( "create system timer error" );
        free( p_usr_tm );
        return NULL;
    }

    return (user_timer_hd)p_usr_tm;    
}

/**
 * @brief  删除用户定时器
 * @param  [in] user_timer ： 定时器句柄
 * @return 
 * @note   
 */
void user_timer_delete( user_timer_hd usr_timer )
{
    user_timer_node_t *p_usr_tm = ( user_timer_node_t *)usr_timer;

    timer_delete( p_usr_tm->timer_id );
    free( p_usr_tm );

    return;
}

/**
 * @brief  定时器重新刷新
 * @param  [in] user_timer ： 定时器句柄
 * @return sf_ok：成功  非sf_ok：失败
 * @note   
 */
sf_ret_t user_timer_refresh( user_timer_hd usr_timer )
{
    user_timer_node_t *p_usr_tm = ( user_timer_node_t *)usr_timer;

    return user_timer_set_timeout( usr_timer, p_usr_tm->timeout_ms, p_usr_tm->cycle );
}

/**
 * @brief  设置定时器超时时间
 * @param  [in] user_timer ： 定时器句柄
 * @param  [in] timeout_ms ： 超时时间，单位1ms
 * @param  [in] cycle      ： 启用循环模式 
 * @return sf_ok：成功  非sf_ok：失败
 * @note   
 */
sf_ret_t user_timer_set_timeout( user_timer_hd usr_timer, uint32_t timeout_ms, bool cycle )
{
    user_timer_node_t *p_usr_tm = ( user_timer_node_t *)usr_timer;
    struct itimerspec its;
    int32_t second;
    int32_t millisecond;

    p_usr_tm->timeout_ms = timeout_ms; 
    p_usr_tm->cycle      = cycle; 

    second       = p_usr_tm->timeout_ms / 1000;
    millisecond  = p_usr_tm->timeout_ms % 1000;

    its.it_value.tv_sec     = second; 
    its.it_value.tv_nsec    = millisecond * 1000000;
    its.it_interval.tv_sec  = 0;
    its.it_interval.tv_nsec = 0;

    if ( cycle == true )
    {
        // its.it_interval.tv_sec  = 5;
        // its.it_interval.tv_nsec = 0;
        its.it_interval.tv_sec  = second; 
        its.it_interval.tv_nsec = millisecond * 1000000;
    }

    // 启动定时器
    if (timer_settime( p_usr_tm->timer_id, 0, &its, NULL) == -1) 
    {
        USER_TIMER_LOG_E( "user timer setting error!!!" );
        return SF_ERR_PARA;
    }

    return SF_OK;
}

/**
 * @brief  设置定时器超时时间 - 详细
 * @param  [in] user_timer       ： 定时器句柄
 * @param  [in] first_timeout_ms ： 第一次超时时间，单位1ms
 * @param  [in] cycle_timeout_ms ： 循环超时时间，单位1ms
 * @return sf_ok：成功  非sf_ok：失败
 * @note   
 */
sf_ret_t user_timer_detail_set_timeout( user_timer_hd usr_timer, uint32_t first_timeout_ms, uint32_t cycle_timeout_ms )
{
    user_timer_node_t *p_usr_tm = ( user_timer_node_t *)usr_timer;
    struct itimerspec its;
    int32_t second;
    int32_t millisecond;

    p_usr_tm->timeout_ms = cycle_timeout_ms; 
    p_usr_tm->cycle      = ( cycle_timeout_ms != 0 ); 

    second       = first_timeout_ms / 1000;
    millisecond  = first_timeout_ms % 1000;

    its.it_value.tv_sec     = second; 
    its.it_value.tv_nsec    = millisecond * 1000000;

    second       = cycle_timeout_ms / 1000;
    millisecond  = cycle_timeout_ms % 1000;
    its.it_interval.tv_sec  = second; 
    its.it_interval.tv_nsec = millisecond * 1000000;

    // 启动定时器
    if (timer_settime( p_usr_tm->timer_id, 0, &its, NULL) == -1) 
    {
        USER_TIMER_LOG_E( "user timer setting error!!!" );
        return SF_ERR_PARA;
    }

    return SF_OK;
}

/**
 * @brief  判断当前定时器是否超时
 * @param  [in] user_timer ： 定时器句柄
 * @return true：超时   false：未超时  
 * @note   
 */
bool user_timer_is_timeout( user_timer_hd usr_timer )
{
    user_timer_node_t *p_usr_tm = ( user_timer_node_t *)usr_timer;
    struct itimerspec curr_value;
    
    timer_gettime( p_usr_tm->timer_id, &curr_value );
    
    if ( (0 == curr_value.it_value.tv_sec)
         && 0 == curr_value.it_value.tv_nsec )
    {
        return true;
    }else{
        return false;
    }
}


// void user_timer_test_callback( void *p_user_arg )
// {
//     USER_TIMER_LOG_D( "user_timer_test_callback ,arg:0x%p", p_user_arg );
//     // printf( "user_timer_test_callback ,arg:0x%p", p_user_arg );
// }

// int user_timer_test( void ) 
// {
//     user_timer_hd test_timer = NULL;
//     USER_TIMER_LOG_D( "user_timer_test start" );

//     test_timer = user_timer_create( user_timer_test_callback, (void *)0xAAAA );
//     // user_timer_set_timeout( test_timer, 5999, true );
//     // user_timer_set_timeout( test_timer, 5999, true );
//     user_timer_detail_set_timeout( test_timer, 10*1000, 30*1000 );

//     while (1) 
//     {
//         // user_timer_is_timeout( test_timer );

//         // int val = timer_getoverrun( timerid );
//         // printf( "val:%d\r\n", val );
//         sleep(1);
//     }
//     return 0;
// }


