#ifndef __OP_LOG_H__
#define __OP_LOG_H__

#include "sofar_type.h"
#include "time.h"

struct st_oplog_info
{
	uint8_t user_name[32]; //用户名
	uint8_t phone_num[32]; //手机号
	uint8_t user_role[16]; //用户角色
	uint8_t op_type[64];//该部分使用中文直接传到前端
	uint8_t dev_sn[16]; //设备SN
	double op_param1;   //操作参数1
	double op_param2; 	//操作参数2
	uint8_t op_status[16]; //操作状态,成功还是失败
	uint8_t time_stamp[16]; //操作时间,格式为时间戳
    time_t op_time;         
	struct st_oplog_info *next;  //暂时不使用链表的形式
};
typedef struct st_oplog_info operation_log_t;

void init_user_basic_info(operation_log_t *oplog);

/**
 * @brief   添加一条操作日志,该函数为公共函数,不同模块记录操作日志时调用该函数即可
 * @return  无
 */
void add_one_op_log(operation_log_t *p_oplog);

int32_t op_log_sqlite_db_create_table(void);

#endif