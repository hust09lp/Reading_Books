#ifndef __SOFAR_SERVICE_H__
#define __SOFAR_SERVICE_H__

#include "sdk_log.h"

#define TCP_SERVER_ADDR "192.168.2.200" 
#define TCP_PORT        2000

#if (1)
#define TCP_DEBUG_PRINT(...) log_i((const int8_t*)__VA_ARGS__);
#else
#define TCP_DEBUG_PRINT(...) {do {} while(0);}
#endif

#define RT_SUCCESS      1
#define RT_FAIL         0


#define TCP_MAX_BUFF_LEN    256

#define DISCONNECT      0
#define CONNECT         1

#define PCS_SN_LEN  10
#define SN_MAX_LEN  32
typedef struct{
    char cmu_sn[SN_MAX_LEN];
    char pcs_sn[SN_MAX_LEN];
    char bcu_sn[BCU_DEVICE_NUM][SN_MAX_LEN];
    char bat_stack_sn[SN_MAX_LEN];
    char fc_sn[SN_MAX_LEN];
    char lc_sn[SN_MAX_LEN];
}sign_in_data_t;                    //cmu注册数据

typedef struct{
    uint8_t tcp_connect_status;
    int socket_fd;
    sign_in_data_t sign_data; 
}tcp_dev_info_t;


#define BIT_CPL(value, bit) ((value) ^= (1 << (bit)))           //取反指定位
#define BIT_SET(value, bit) ((value) |= (1 << (bit)))           //置位指定位
#define BIT_CLR(value, bit) ((value) &=~(1 << (bit)))           //清零指定位
#define BIT_GET(value, bit) (((value) &  (1 << (bit))) >> (bit))  //读取指定位

/**
 * @brief   数据发送并等待接收
 * @param   [in] socket_fd:socket句柄
 * @param   [in] p_txdata:待数据内容
 * @param   [in] txdata_len:数据长度
 * @param   [out] p_rxdata:待数据内容
 * @param   [out] p_rxdata_len:数据长度
 * @note
 * @return
 */
void tcp_send(int socket_fd, char *p_txdata, int txdata_len, char *p_rxdata, int *p_rxdata_len);

/**
 * @brief   获取设备信息
 * @note
 * @return
 */
tcp_dev_info_t *tcp_dev_info_get(void);


#endif