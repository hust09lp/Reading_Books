#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include "sdk_public.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "errors.h"
#include "sofar_log.h"
#include "cJSON.h"
#include "sqlite3.h"
#include "sofar_service.h"

#define ENERGY_DB     "/user/data/energy/energy.db"
#define ENERGY_PATH   "/user/data/energy/"

#define HEART_BEAT_TIME_CNT         60
#define PCS_DATA_TIME_CNT           30
#define BCU_DATA_TIME_CNT           35
#define BAT_STACK_DATA_TIME_CNT     40
#define FC_DATA_TIME_CNT            60
#define LC_DATA_TIME_CNT            60

/**
 * @brief   排序
 * @note
 * @return
 */
void data_sort(uint8_t *p_data, int32_t data_len) 
{
    int i, j, temp;

    for (i = 0; i < data_len - 1; i++)
    {
        for (j = 0; j < data_len - 1 - i; j++)
        {
            if (p_data[j] > p_data[j + 1]) 
            {
                temp = p_data[j];
                p_data[j] = p_data[j + 1];
                p_data[j + 1] = temp;
            }
        }
    }
}


/**
 * @brief   心跳
 * @note
 * @return
 */
void tcp_heart_beat(void)
{
    static uint8_t tick_cnt = 0;
    cJSON *p_root = NULL;
    char *p = NULL;
    char recv_buff[TCP_MAX_BUFF_LEN] = {0};
    int recv_len = 0;
    tcp_dev_info_t *p_dev_info = NULL;

    p_dev_info = tcp_dev_info_get();
    if(tick_cnt++ < HEART_BEAT_TIME_CNT)
    {
        return;
    }

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "devtype", "cmu");
    cJSON_AddStringToObject(p_root, "cmdtype", "heartbeat");
    cJSON_AddNumberToObject(p_root, "cmuIndex", 1);
    p = cJSON_PrintUnformatted(p_root);
    tcp_send(p_dev_info->socket_fd, p, strlen(p), recv_buff, &recv_len);
    usleep(500 * 1000);
    tick_cnt = 0;
    cJSON_Delete(p_root);
    free(p);
}


/**
 * @brief   获取当天充放电量
 * @param   [out] p_charge:充电量
 * @param   [out] p_charge:放电量
 * @note
 * @return
 */
int32_t select_sqlite_db_day(uint32_t *p_charge, uint32_t *p_discharge)
{
    sqlite3 *db;
    int rc = 0;
    int32_t hour = 0;
    sqlite3_stmt *stmt = NULL;
    char date[32] = {0};
    char sql[256] = {0};
    sdk_rtc_t rtc_time;

    sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);   
    rc = sqlite3_open(ENERGY_DB, &db);
    if(rc) 
    {
       TCP_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
       return(0);
    } 
    else 
    {
        snprintf(date, 32,"%04d-%02d-%02d", rtc_time.tm_year + 2000, rtc_time.tm_mon, rtc_time.tm_day);
        snprintf(sql, sizeof(sql), "SELECT strftime('%%H', date), charge, discharge FROM charge_data WHERE date LIKE '%s%%';",date);
        sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
        while (sqlite3_step(stmt) == SQLITE_ROW) 
        {
            hour = atoi((const char*)sqlite3_column_text(stmt, 0));
            if (hour > 23)
            {
                break;
            }
            *p_charge += sqlite3_column_double(stmt, 1);
            *p_discharge += sqlite3_column_double(stmt, 2);
        }
    }
    sqlite3_finalize(stmt);
    sqlite3_close(db);    
    return 1; 
}


/**
 * @brief   获取当月充放电量
 * @param   [out] p_charge:充电量
 * @param   [out] p_charge:放电量
 * @note
 * @return
 */
int32_t select_sqlite_db_mon(uint32_t *p_charge, uint32_t *p_discharge)
{
    sqlite3 *db = NULL;
    sqlite3_stmt *stmt = NULL;
    int rc;
    char date[32] = {0};
    char sql[256] = {0};
    sdk_rtc_t rtc_time;

    sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);   
    rc = sqlite3_open(ENERGY_DB, &db);
    if( rc ) 
    {
       return(0);
    } 
    else 
    {
        snprintf(date, 32,"%04d-%02d", rtc_time.tm_year + 2000, rtc_time.tm_mon);
        snprintf(sql, sizeof(sql), "SELECT strftime('%%d', date), SUM(charge), SUM(discharge) FROM charge_data WHERE strftime('%%Y-%%m', date) = '%s' GROUP BY strftime('%%Y-%%m-%%d', date);", date);
        sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
        while (sqlite3_step(stmt) == SQLITE_ROW) 
        {
            *p_charge += sqlite3_column_double(stmt, 1);
            *p_discharge += sqlite3_column_double(stmt, 2);
        }
    }
    sqlite3_finalize(stmt);
    sqlite3_close(db);  
    return 1;   
}


/**
 * @brief   获取当年充放电量
 * @param   [out] p_charge:充电量
 * @param   [out] p_charge:放电量
 * @note
 * @return
 */
int32_t select_sqlite_db_year(uint32_t *p_charge, uint32_t *p_discharge)
{
    sqlite3 *db = NULL;
    sqlite3_stmt *stmt = NULL;
    int rc;
    char date[32] = {0};
    char sql[256] = {0};
    sdk_rtc_t rtc_time;

    sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);  
    rc = sqlite3_open(ENERGY_DB, &db);
    if( rc )
    {
       return(0);
    } 
    else 
    {
        snprintf(date, 32,"%04d", rtc_time.tm_year + 2000);
        snprintf(sql, sizeof(sql), "SELECT strftime('%%m', date), SUM(charge), SUM(discharge) FROM charge_data WHERE strftime('%%Y', date) = '%s' GROUP BY strftime('%%Y-%%m', date);", date);
        sqlite3_prepare_v2(db, sql, -1, &stmt, 0);   
        while (sqlite3_step(stmt) == SQLITE_ROW) 
        {
            *p_charge += sqlite3_column_double(stmt, 1);
            *p_discharge += sqlite3_column_double(stmt, 2);
        }
    }
    sqlite3_finalize(stmt);
    sqlite3_close(db);     
    return 1;
}



/**
 * @brief   获取PCS模块温度最小值
 * @note
 * @return
 */
int16_t get_pcs_module_temp_min(void)
{
    int16_t min_value = 0;
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();          //遥测数据

    min_value = p_telemetry_data->power_module_telemetry_info[0].igbt_temp_ra;
    if (p_telemetry_data->power_module_telemetry_info[0].igbt_temp_sa < min_value) min_value = p_telemetry_data->power_module_telemetry_info[0].igbt_temp_sa;
    if (p_telemetry_data->power_module_telemetry_info[0].igbt_temp_ta < min_value) min_value = p_telemetry_data->power_module_telemetry_info[0].igbt_temp_ta;
    if (p_telemetry_data->power_module_telemetry_info[0].igbt_temp_rb < min_value) min_value = p_telemetry_data->power_module_telemetry_info[0].igbt_temp_rb;
    if (p_telemetry_data->power_module_telemetry_info[0].igbt_temp_sb < min_value) min_value = p_telemetry_data->power_module_telemetry_info[0].igbt_temp_sb;
    if (p_telemetry_data->power_module_telemetry_info[0].igbt_temp_tb < min_value) min_value = p_telemetry_data->power_module_telemetry_info[0].igbt_temp_tb;

    return min_value;
}


/**
 * @brief   PCS监控项数据上报
 * @note
 * @return
 */
void tcp_pcs_monitor_data_upload(void)
{
    static uint8_t tick_cnt = PCS_DATA_TIME_CNT;
    cJSON *p_root = NULL;
    cJSON *p_data = NULL;
    char *p = NULL;
    char recv_buff[TCP_MAX_BUFF_LEN] = {0};
    int recv_len = 0;
    sdk_rtc_t rtc_time = {0};
    char date[32] = {0};
    uint32_t day_charge = 0, day_discharge = 0;
    uint32_t mon_charge = 0, mon_discharge = 0;
    uint32_t year_charge = 0, year_discharge = 0;
    uint32_t charge_energy = 0;
    uint32_t discharge_energy = 0;
    tcp_dev_info_t *p_dev_info = NULL;
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();          //遥测数据
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);   
    snprintf(date, 32,"%04d%02d%02d", rtc_time.tm_year + 2000, rtc_time.tm_mon, rtc_time.tm_day);

    p_dev_info = tcp_dev_info_get();
    if(tick_cnt++ < PCS_DATA_TIME_CNT)
    {
        return;
    }

    p_data = cJSON_CreateObject();
    if(p_data == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(p_data, "activepower", p_telemetry_data->power_module_telemetry_info[0].active_power);
    cJSON_AddNumberToObject(p_data, "reactivePower", p_telemetry_data->power_module_telemetry_info[0].reactive_power);
    cJSON_AddNumberToObject(p_data, "apparentPower", p_telemetry_data->power_module_telemetry_info[0].apparent_power);
    cJSON_AddNumberToObject(p_data, "powerFactor", p_telemetry_data->power_module_telemetry_info[0].power_factor);
    cJSON_AddNumberToObject(p_data, "R_vol", p_telemetry_data->power_module_telemetry_info[0].grid_volt_r);
    cJSON_AddNumberToObject(p_data, "S_vol", p_telemetry_data->power_module_telemetry_info[0].grid_volt_s);
    cJSON_AddNumberToObject(p_data, "T_vol", p_telemetry_data->power_module_telemetry_info[0].grid_volt_t);
    cJSON_AddNumberToObject(p_data, "R_cur", p_telemetry_data->power_module_telemetry_info[0].ac_current_r);
    cJSON_AddNumberToObject(p_data, "S_cur", p_telemetry_data->power_module_telemetry_info[0].ac_current_s);
    cJSON_AddNumberToObject(p_data, "T_cur", p_telemetry_data->power_module_telemetry_info[0].ac_current_t);
    cJSON_AddNumberToObject(p_data, "gridFreq", p_telemetry_data->power_module_telemetry_info[0].grid_freq);
    cJSON_AddNumberToObject(p_data, "busVoltPN", p_telemetry_data->power_module_telemetry_info[0].bus_volt_pn);
    cJSON_AddNumberToObject(p_data, "posHalfBusVoltPN", p_telemetry_data->power_module_telemetry_info[0].bus_volt_p);
    cJSON_AddNumberToObject(p_data, "negHalfBusVoltPN", p_telemetry_data->power_module_telemetry_info[0].bus_volt_n);
    cJSON_AddNumberToObject(p_data, "batCurrent", p_telemetry_data->power_module_telemetry_info[0].bat_current);
    int32_t bat_power = p_telemetry_data->power_module_telemetry_info[0].bat_current * p_telemetry_data->power_module_telemetry_info[0].bat_volt;
    cJSON_AddNumberToObject(p_data, "batPower", bat_power / 1000);
    uint32_t charge = (p_telemetry_data->power_module_telemetry_info[0].energy_charge_h << 16) | p_telemetry_data->power_module_telemetry_info[0].energy_charge_l;
    uint32_t discharge = (p_telemetry_data->power_module_telemetry_info[0].energy_discharge_h << 16) | p_telemetry_data->power_module_telemetry_info[0].energy_discharge_l;
    cJSON_AddNumberToObject(p_data, "energyCharge", charge);
    cJSON_AddNumberToObject(p_data, "energyDischarge", discharge);
    cJSON_AddNumberToObject(p_data, "date", atoi(date));
    //读取数据库当日充放电量
    select_sqlite_db_day(&day_charge, &day_discharge);
    cJSON_AddNumberToObject(p_data, "dayEnergyCharge", day_charge);
    cJSON_AddNumberToObject(p_data, "dayEnergyDischarge", day_discharge);
    //读取数据库当月充放电量
    select_sqlite_db_mon(&mon_charge, &mon_discharge);
    cJSON_AddNumberToObject(p_data, "monEnergyCharge", mon_charge);
    cJSON_AddNumberToObject(p_data, "monEnergyDischarge", mon_discharge);
    //读取数据库当年充放电量
    select_sqlite_db_year(&year_charge, &year_discharge);
    cJSON_AddNumberToObject(p_data, "yearEnergyCharge", year_charge);
    cJSON_AddNumberToObject(p_data, "yearEnergyDischarge", year_discharge);
    //6个模块取最小值
    cJSON_AddNumberToObject(p_data, "tempModule", get_pcs_module_temp_min());
    cJSON_AddNumberToObject(p_data, "tempAm", p_telemetry_data->power_module_telemetry_info[0].amb_temp);
    //当前可充放电量，单簇累计
    //簇可充放电量，计算公式：额定容量*soh*soc(1-soc),pack容量：43kWh
    for(uint8_t i = 0; i < p_para_data->bat_cabinet_num; i++)
    {
        charge_energy += (43 * (p_para_data->bat_cluster_pack_num) * (p_telemetry_data->battery_cluster_telemetry_info[i].average_SOH_monomer) * (100 - p_telemetry_data->battery_cluster_telemetry_info[i].cluster_SOC));
    }
    for(uint8_t i = 0; i < p_para_data->bat_cabinet_num; i++)
    {
        discharge_energy += (43 * (p_para_data->bat_cluster_pack_num) * (p_telemetry_data->battery_cluster_telemetry_info[i].average_SOH_monomer) * (p_telemetry_data->battery_cluster_telemetry_info[i].cluster_SOC));
    }
    cJSON_AddNumberToObject(p_data, "char", charge_energy / 100);
    cJSON_AddNumberToObject(p_data, "dischar", discharge_energy / 100);

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_data);
        return;
    }

    cJSON_AddStringToObject(p_root, "devtype", "pcs");
    cJSON_AddStringToObject(p_root, "cmdtype", "monitor");
    cJSON_AddNumberToObject(p_root, "cmuIndex", 1);
    cJSON_AddItemToObject(p_root, "data", p_data);

    p = cJSON_PrintUnformatted(p_root);
    tcp_send(p_dev_info->socket_fd, p, strlen(p), recv_buff, &recv_len);
    usleep(500 * 1000);
    tick_cnt = 0;
    cJSON_Delete(p_root);
    free(p);
}


/**
 * @brief   BCU监控项数据上报
 * @note
 * @return
 */
void tcp_bcu_monitor_data_upload(void)
{
    static uint8_t tick_cnt = BCU_DATA_TIME_CNT;
    static uint8_t bcu_cnt = 0;
    static uint8_t pack_cnt = 0;
    cJSON *p_root = NULL;
    cJSON *p_data = NULL;
    cJSON *p_pack = NULL;
    char *p = NULL;
    char recv_buff[TCP_MAX_BUFF_LEN] = {0};
    int recv_len = 0;
    tcp_dev_info_t *p_dev_info = NULL;
    char pack_str[16] = {0};
    uint32_t charge_energy = 0;
    uint32_t discharge_energy = 0;
    int32_t monomer_data[MONOMER_NUMBER_IN_PACK] = {0};
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();          //遥测数据
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数
    internal_shared_data_t *p_shared_data = internal_shared_data_get();

    p_dev_info = tcp_dev_info_get();
    if(tick_cnt++ < BCU_DATA_TIME_CNT)
    {
        return;
    }

    p_data = cJSON_CreateObject();
    if(p_data == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(p_data, "volt", p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].cluster_voltage);
    cJSON_AddNumberToObject(p_data, "current", -(p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].cluster_current - 16000));
    int32_t power = p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].cluster_voltage * (p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].cluster_current - 16000);
    cJSON_AddNumberToObject(p_data, "power", -power / 1000);
    cJSON_AddNumberToObject(p_data, "soc", p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].cluster_SOC);
    cJSON_AddNumberToObject(p_data, "soh", p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].average_SOH_monomer);
    cJSON_AddNumberToObject(p_data, "monomerVmax", p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].highest_monomer_voltage_cluster[0]);
    cJSON_AddNumberToObject(p_data, "monomerVmean", p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].average_voltage_monomer);
    cJSON_AddNumberToObject(p_data, "monomerVmin", p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].lowest_monomer_voltage_cluster[0]);
    cJSON_AddNumberToObject(p_data, "monomerTmax", p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].highest_monomer_temperature_cluster[0] - 40);
    cJSON_AddNumberToObject(p_data, "monomerTmean", p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].average_temperature_monomer - 40);
    cJSON_AddNumberToObject(p_data, "monomerTmin", p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].lowest_monomer_temperature_cluster[0] - 40);
    //簇可充放电量，计算公式：额定容量*soh*soc(1-soc),pack容量：43kWh
    charge_energy = 43 * (p_para_data->bat_cluster_pack_num) * (p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].average_SOH_monomer) * (100 - p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].cluster_SOC);
    cJSON_AddNumberToObject(p_data, "charEnergy", charge_energy / 100);
    discharge_energy = 43 * (p_para_data->bat_cluster_pack_num) * (p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].average_SOH_monomer) * (p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].cluster_SOC);
    cJSON_AddNumberToObject(p_data, "discharEnergy", discharge_energy / 100);
    cJSON_AddNumberToObject(p_data, "totalEnergyCharge", p_shared_data->cluster_total_charging_energy[bcu_cnt]);
    cJSON_AddNumberToObject(p_data, "totalEnergyDischarge", p_shared_data->cluster_total_discharge_energy[bcu_cnt]);
    cJSON_AddNumberToObject(p_data, "posInsulation", p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].positive_insulation_resistance);
    cJSON_AddNumberToObject(p_data, "NegInsulation", p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].negative_insulation_resistance);
    cJSON_AddNumberToObject(p_data, "HBtemp1", p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].high_pressure_box_temperature[0] - 40);
    cJSON_AddNumberToObject(p_data, "HBtemp2", p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].high_pressure_box_temperature[1] - 40);
    cJSON_AddNumberToObject(p_data, "HBtemp3", p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].high_pressure_box_temperature[2] - 40);
    cJSON_AddNumberToObject(p_data, "HBtemp4", p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].high_pressure_box_temperature[3] - 40);       
    
    p_pack = cJSON_CreateObject();
    if(p_pack == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_data);
        return;
    }
    memset(pack_str, 0, 8);
    sprintf(pack_str, "pack%dvolt", pack_cnt + 1);
    for(uint8_t i = 0; i < MONOMER_NUMBER_IN_PACK; i++)
    {
        monomer_data[i] = p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].monomer_info[pack_cnt].monomer_voltage[i];
    }
    cJSON_AddItemToObject(p_pack, pack_str, cJSON_CreateIntArray(monomer_data, MONOMER_NUMBER_IN_PACK));
    memset(pack_str, 0, 8);
    sprintf(pack_str, "pack%dtemp", pack_cnt + 1);
    for(uint8_t i = 0; i < MONOMER_NUMBER_IN_PACK; i++)
    {
        monomer_data[i] = p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].monomer_info[pack_cnt].monomer_temperature[i] - 40;
    }
    cJSON_AddItemToObject(p_pack, pack_str, cJSON_CreateIntArray(monomer_data, MONOMER_NUMBER_IN_PACK));
    memset(pack_str, 0, 8);
    sprintf(pack_str, "pack%dsoc", pack_cnt + 1);
    for(uint8_t i = 0; i < MONOMER_NUMBER_IN_PACK; i++)
    {
        monomer_data[i] = p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].monomer_info[pack_cnt].monomer_SOC[i];
    }
    cJSON_AddItemToObject(p_pack, pack_str, cJSON_CreateIntArray(monomer_data, MONOMER_NUMBER_IN_PACK));
    memset(pack_str, 0, 8);
    sprintf(pack_str, "pack%dsoh", pack_cnt + 1);
    for(uint8_t i = 0; i < MONOMER_NUMBER_IN_PACK; i++)
    {
        monomer_data[i] = p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].monomer_info[pack_cnt].monomer_SOH[i];
    }
    cJSON_AddItemToObject(p_pack, pack_str, cJSON_CreateIntArray(monomer_data, MONOMER_NUMBER_IN_PACK));
    memset(pack_str, 0, 8);
    sprintf(pack_str, "pack%dTtemp1", pack_cnt + 1);
    cJSON_AddNumberToObject(p_pack, pack_str, p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].pole_temperater_PACK[pack_cnt][0] - 40);
    memset(pack_str, 0, 8);
    sprintf(pack_str, "pack%dTtemp2", pack_cnt + 1);
    cJSON_AddNumberToObject(p_pack, pack_str, p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].pole_temperater_PACK[pack_cnt][1] - 40);
    memset(pack_str, 0, 8);
    sprintf(pack_str, "pack%d", pack_cnt + 1);
    cJSON_AddItemToObject(p_data, pack_str, p_pack);
 
    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_data);
        cJSON_Delete(p_pack);
        return;
    }

    cJSON_AddStringToObject(p_root, "devtype", "bms");
    cJSON_AddStringToObject(p_root, "cmdtype", "monitor");
    cJSON_AddNumberToObject(p_root, "cmuIndex", 1);
    cJSON_AddNumberToObject(p_root, "clusterIndex", bcu_cnt + 1);
    cJSON_AddItemToObject(p_root, "data", p_data);

    p = cJSON_PrintUnformatted(p_root);
    tcp_send(p_dev_info->socket_fd, p, strlen(p), recv_buff, &recv_len);
    usleep(500 * 1000);
    cJSON_Delete(p_root);
    free(p);
    pack_cnt++;
    if(pack_cnt >= p_para_data->bat_cluster_pack_num)
    {
        bcu_cnt++;
        pack_cnt = 0;
        if(bcu_cnt >= p_para_data->bat_cabinet_num)
        {
            bcu_cnt = 0;
            tick_cnt = 0;
        }
    }
}


/**
 * @brief   电池堆监控项数据上报
 * @note
 * @return
 */
void tcp_bat_stack_monitor_data_upload(void)
{
    static uint8_t tick_cnt = BAT_STACK_DATA_TIME_CNT;
    cJSON *p_root = NULL;
    cJSON *p_data = NULL;
    char *p = NULL;
    char recv_buff[TCP_MAX_BUFF_LEN] = {0};
    int recv_len = 0;
    tcp_dev_info_t *p_dev_info = NULL;
    int16_t curr = 0;
    uint32_t total_charge = 0;
    uint32_t total_discharge = 0;
    uint32_t charge_energy = 0;
    uint32_t discharge_energy = 0;
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();          //遥测数据
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数
    internal_shared_data_t *p_shared_data = internal_shared_data_get();

    p_dev_info = tcp_dev_info_get();
    if(tick_cnt++ < BAT_STACK_DATA_TIME_CNT)
    {
        return;
    }

    p_data = cJSON_CreateObject();
    if(p_data == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    //SOC取最大值、SOH取最小值
    uint8_t *p_soc_array = NULL;
    uint8_t *p_soh_array = NULL;
    p_soc_array = malloc(p_para_data->bat_cabinet_num);
    p_soh_array = malloc(p_para_data->bat_cabinet_num);
    if((p_soc_array == NULL) || (p_soh_array == NULL))
    {
        return;
    }
    for(uint8_t i = 0; i < p_para_data->bat_cabinet_num; i++)
    {
        p_soc_array[i] = p_telemetry_data->battery_cluster_telemetry_info[i].cluster_SOC;
        p_soh_array[i] = p_telemetry_data->battery_cluster_telemetry_info[i].average_SOH_monomer;

    }
    data_sort(p_soc_array, p_para_data->bat_cabinet_num);
    data_sort(p_soh_array, p_para_data->bat_cabinet_num);
    cJSON_AddNumberToObject(p_data, "soc", p_soc_array[p_para_data->bat_cabinet_num - 1]);
    cJSON_AddNumberToObject(p_data, "soh", p_soh_array[0]);
    if(p_soc_array)
    {
        free(p_soc_array);
    }
    if(p_soh_array)
    {
        free(p_soh_array);
    }
    //电池堆温度，对电池簇单体平均温度取平均
    int16_t temp = 0;
    for(uint8_t i = 0; i < p_para_data->bat_cabinet_num; i++)
    {
        temp += (p_telemetry_data->battery_cluster_telemetry_info[i].average_temperature_monomer - 40);
    }
    cJSON_AddNumberToObject(p_data, "temM", (temp / p_para_data->bat_cabinet_num) * 10);

    //当前可充放电量，单簇累计
    //簇可充放电量，计算公式：额定容量*soh*soc(1-soc),pack容量：43kWh
    for(uint8_t i = 0; i < p_para_data->bat_cabinet_num; i++)
    {
        charge_energy += (43 * (p_para_data->bat_cluster_pack_num) * (p_telemetry_data->battery_cluster_telemetry_info[i].average_SOH_monomer) * (100 - p_telemetry_data->battery_cluster_telemetry_info[i].cluster_SOC));
    }
    for(uint8_t i = 0; i < p_para_data->bat_cabinet_num; i++)
    {
        discharge_energy += (43 * (p_para_data->bat_cluster_pack_num) * (p_telemetry_data->battery_cluster_telemetry_info[i].average_SOH_monomer) * (p_telemetry_data->battery_cluster_telemetry_info[i].cluster_SOC));
    }
    cJSON_AddNumberToObject(p_data, "char", charge_energy / 100);
    cJSON_AddNumberToObject(p_data, "dischar", discharge_energy / 100);
    //当前累计充电时长,暂不处理
    cJSON_AddNumberToObject(p_data, "totalCharTm", 0);
    //总电压=电池簇电压
    cJSON_AddNumberToObject(p_data, "Volt", p_telemetry_data->battery_cluster_telemetry_info[0].cluster_voltage);
    //总电流=电池簇累计
    for(uint8_t i = 0; i < p_para_data->bat_cabinet_num; i++)
    {
        curr += (p_telemetry_data->battery_cluster_telemetry_info[i].cluster_current - 16000);
    }
    cJSON_AddNumberToObject(p_data, "Curr", -curr);
    //总功率
    int32_t power = (p_telemetry_data->battery_cluster_telemetry_info[0].cluster_voltage) * (-(curr));
    cJSON_AddNumberToObject(p_data, "Power", power / 1000);
    //累计充放电量
    for(uint8_t i = 0; i < p_para_data->bat_cabinet_num; i++)
    {
        total_charge += p_shared_data->cluster_total_charging_energy[i];
        total_discharge += p_shared_data->cluster_total_discharge_energy[i];
    }
    cJSON_AddNumberToObject(p_data, "totalChar", total_charge);
    cJSON_AddNumberToObject(p_data, "totalDischar", total_discharge);
    //绝缘电阻，第一簇最小值
    uint16_t insulation_resistance = ((p_telemetry_data->battery_cluster_telemetry_info[0].positive_insulation_resistance > p_telemetry_data->battery_cluster_telemetry_info[0].negative_insulation_resistance)
                                    ? p_telemetry_data->battery_cluster_telemetry_info[0].negative_insulation_resistance : p_telemetry_data->battery_cluster_telemetry_info[0].positive_insulation_resistance);
    cJSON_AddNumberToObject(p_data, "insulation", insulation_resistance);

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_data);
        return;
    }

    cJSON_AddStringToObject(p_root, "devtype", "batstack");
    cJSON_AddStringToObject(p_root, "cmdtype", "monitor");
    cJSON_AddNumberToObject(p_root, "cmuIndex", 1);
    cJSON_AddItemToObject(p_root, "data", p_data);

    p = cJSON_PrintUnformatted(p_root);
    tcp_send(p_dev_info->socket_fd, p, strlen(p), recv_buff, &recv_len);
    usleep(500 * 1000);
    tick_cnt = 0;
    cJSON_Delete(p_root);
    free(p);
}


/**
 * @brief   消防监控项数据上报
 * @note
 * @return
 */
static void tcp_fc_monitor_data_upload(void)
{
    static uint8_t tick_cnt = FC_DATA_TIME_CNT;
    cJSON *p_root = NULL;
    cJSON *p_data = NULL;
    char *p = NULL;
    char recv_buff[TCP_MAX_BUFF_LEN] = {0};
    int recv_len = 0;
    tcp_dev_info_t *p_dev_info = NULL;
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();          //遥测数据

    p_dev_info = tcp_dev_info_get();
    if(tick_cnt++ < FC_DATA_TIME_CNT)
    {
        return;
    }

    p_data = cJSON_CreateObject();
    if(p_data == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }
    //取第一个电池柜
    cJSON_AddNumberToObject(p_data, "temp", p_telemetry_data->container_system_telemetry_info.mix_sensor1_temp);
    cJSON_AddNumberToObject(p_data, "co", p_telemetry_data->container_system_telemetry_info.mix_sensor1_co_ppm);
    cJSON_AddNumberToObject(p_data, "pm25", p_telemetry_data->container_system_telemetry_info.mix_sensor1_pm25_ppm);

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_data);
        return;
    }

    cJSON_AddStringToObject(p_root, "devtype", "fc");
    cJSON_AddStringToObject(p_root, "cmdtype", "monitor");
    cJSON_AddNumberToObject(p_root, "cmuIndex", 1);
    cJSON_AddItemToObject(p_root, "data", p_data);

    p = cJSON_PrintUnformatted(p_root);
    tcp_send(p_dev_info->socket_fd, p, strlen(p), recv_buff, &recv_len);
    usleep(500 * 1000);
    tick_cnt = 0;
    cJSON_Delete(p_root);
    free(p);
}


/**
 * @brief   液冷监控项数据上报
 * @note
 * @return
 */
static void tcp_lc_monitor_data_upload(void)
{
    static uint8_t tick_cnt = FC_DATA_TIME_CNT;
    cJSON *p_root = NULL;
    cJSON *p_data = NULL;
    char *p = NULL;
    char recv_buff[TCP_MAX_BUFF_LEN] = {0};
    int recv_len = 0;
    tcp_dev_info_t *p_dev_info = NULL;
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();          //遥测数据


    p_dev_info = tcp_dev_info_get();
    if(tick_cnt++ < FC_DATA_TIME_CNT)
    {
        return;
    }

    p_data = cJSON_CreateObject();
    if(p_data == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(p_data, "wpOutput", p_telemetry_data->container_system_telemetry_info.pump_flow_rate);
    //风机输出
    cJSON_AddNumberToObject(p_data, "fanOutput", 0);
    cJSON_AddNumberToObject(p_data, "effluentTemp", p_telemetry_data->container_system_telemetry_info.lc_outlet_temp);
    cJSON_AddNumberToObject(p_data, "ascentTemp", p_telemetry_data->container_system_telemetry_info.lc_inlet_temp);
    cJSON_AddNumberToObject(p_data, "effluentPressure", p_telemetry_data->container_system_telemetry_info.lc_outlet_pressure);
    cJSON_AddNumberToObject(p_data, "ascentPressure", p_telemetry_data->container_system_telemetry_info.lc_inlet_pressure);
    cJSON_AddNumberToObject(p_data, "temp", p_telemetry_data->container_system_telemetry_info.lc_outdoor_temper);

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_data);
        return;
    }

    cJSON_AddStringToObject(p_root, "devtype", "lc");
    cJSON_AddStringToObject(p_root, "cmdtype", "monitor");
    cJSON_AddNumberToObject(p_root, "cmuIndex", 1);
    cJSON_AddItemToObject(p_root, "data", p_data);

    p = cJSON_PrintUnformatted(p_root);
    tcp_send(p_dev_info->socket_fd, p, strlen(p), recv_buff, &recv_len);
    usleep(500 * 1000);
    tick_cnt = 0;
    cJSON_Delete(p_root);
    free(p);
}


/**
 * @brief   监控项数据定时上报服务初始化
 * @param   [in] arg
 * @note
 * @return
 */
void *tcp_regular_time_data_upload_service(void *arg)
{
    tcp_dev_info_t *p_dev_info = NULL;

    p_dev_info = tcp_dev_info_get();
	while(1)
	{
        if(p_dev_info->tcp_connect_status == CONNECT)
        {
            tcp_heart_beat();
            tcp_pcs_monitor_data_upload();
            tcp_bat_stack_monitor_data_upload();
            tcp_bcu_monitor_data_upload();
            tcp_fc_monitor_data_upload();
            tcp_lc_monitor_data_upload();
        }
        sleep(1);
	}
}



/**
 * @brief   监控项定时上报模块初始化
 * @param
 * @note
 * @return
 */
void tcp_regular_time_monitor_module_init(void)
{
	pthread_t regular_time_monitor;
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	if(pthread_create(&regular_time_monitor, &attr, tcp_regular_time_data_upload_service, NULL) != 0)
	{
		perror("pthread_create tcp server service");
	}
	pthread_attr_destroy(&attr);
}