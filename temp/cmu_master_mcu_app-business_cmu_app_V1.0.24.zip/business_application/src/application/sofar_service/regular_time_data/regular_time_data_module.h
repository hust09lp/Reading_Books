#ifndef __REGULAR_TIME_DATA_MODULE_H__
#define __REGULAR_TIME_DATA_MODULE_H__

#include "sdk_log.h"

/**
 * @brief   监控项定时上报模块初始化
 * @param
 * @note
 * @return
 */
void tcp_regular_time_monitor_module_init(void);

#endif