#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include "data_shm.h"
#include "sdk_shm.h"
#include "errors.h"
#include "sofar_log.h"
#include "cJSON.h"
#include "sofar_service.h"
#include "regular_time_data_module.h"
#include "real_time_data_module.h"
#include "sofar_ota.h"

//线程锁
static pthread_mutex_t g_tcp_mutex;
//tcp设备信息
static tcp_dev_info_t g_tcp_dev_info = {0};


/**
 * @brief   注册数据初始化
 * @note
 * @return
 */
static void dev_sign_data_init(void)
{
    uint8_t i = 0;
    uint8_t len = 0;
	constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();

    strcpy(g_tcp_dev_info.sign_data.cmu_sn, (char *)p_para_data->device_sn);
    for(i = 0; i < p_para_data->bat_cabinet_num; i++)
    {
        sprintf(g_tcp_dev_info.sign_data.bcu_sn[i], "%s_01_%02d", g_tcp_dev_info.sign_data.cmu_sn, i + 1);
    }
    sprintf(g_tcp_dev_info.sign_data.bat_stack_sn, "%s_02_01", g_tcp_dev_info.sign_data.cmu_sn);
    sprintf(g_tcp_dev_info.sign_data.fc_sn, "%s_03_01", g_tcp_dev_info.sign_data.cmu_sn);
    sprintf(g_tcp_dev_info.sign_data.lc_sn, "%s_04_01", g_tcp_dev_info.sign_data.cmu_sn);

    for (i = 0; i < PCS_SN_LEN; ++i)
    {
        len += sprintf(g_tcp_dev_info.sign_data.pcs_sn + len,"%c",(p_telemetry_data->pcs_module_version_telemetry_info[0].sn[i] & 0x00FF));
        len += sprintf(g_tcp_dev_info.sign_data.pcs_sn + len,"%c",((p_telemetry_data->pcs_module_version_telemetry_info[0].sn[i] >> 8)  & 0x00ff));
    }
    g_tcp_dev_info.sign_data.pcs_sn[len]=0;

    TCP_DEBUG_PRINT((int8_t *)"cmu sn:%s", g_tcp_dev_info.sign_data.cmu_sn);
    TCP_DEBUG_PRINT((int8_t *)"pcs sn:%s", g_tcp_dev_info.sign_data.pcs_sn);
    for(i = 0; i < p_para_data->bat_cabinet_num; i++)
    {
        TCP_DEBUG_PRINT((int8_t *)"bcu[%d] sn:%s", i + 1, g_tcp_dev_info.sign_data.bcu_sn[i]);
    }
    TCP_DEBUG_PRINT((int8_t *)"bat stack sn:%s", g_tcp_dev_info.sign_data.bat_stack_sn);
    TCP_DEBUG_PRINT((int8_t *)"fc sn:%s", g_tcp_dev_info.sign_data.fc_sn);
    TCP_DEBUG_PRINT((int8_t *)"lc sn:%s", g_tcp_dev_info.sign_data.lc_sn);

}


/**
 * @brief   获取设备信息
 * @note
 * @return
 */
tcp_dev_info_t *tcp_dev_info_get(void)
{
    return &g_tcp_dev_info;
}


/**
 * @brief    设置系统时间
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void custom_set_time(char *p_data)
{
    cJSON *p_request = NULL;
    char *p_ymd = NULL;  //年月日
    char *p_hms = NULL;  //时分秒
    char cmd[128] = {0};

	p_request = cJSON_Parse(p_data);
    if(p_request == NULL)
	{
		TCP_DEBUG_PRINT((int8_t *)"parse request failed.");
		return;
	}

    p_ymd = cJSON_GetObjectItem(p_request,"YMD")->valuestring;
    p_hms = cJSON_GetObjectItem(p_request,"HMS")->valuestring;

    sprintf(cmd,"date -s \"%s %s\"",p_ymd,p_hms);
    system(cmd);
    system("hwclock -w");
    cJSON_Delete(p_request);
}


/**
 * @brief   设备注册
 * @param   [in] socket_fd:网络连接信息
 * @note
 * @return
 */
static void dev_sign_in(int socket_fd)
{
    cJSON *p_root = NULL;
    cJSON *p_bcu_array = NULL;
    char *p = NULL;
    char recv_buff[TCP_MAX_BUFF_LEN] = {0};
    int recv_len = 0;
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get();

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    if(p_para_data->bat_cabinet_num > 0)
    {
        p_bcu_array = cJSON_CreateArray();
        if(p_bcu_array == NULL)
        {
            TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
            cJSON_Delete(p_root);
            return;
        }
    }

    cJSON_AddStringToObject(p_root, "devtype", "cmu");
    cJSON_AddStringToObject(p_root, "cmdtype", "signIn");
    cJSON_AddNumberToObject(p_root, "cmuIndex", 1);
    cJSON_AddStringToObject(p_root, "cmuSn", g_tcp_dev_info.sign_data.cmu_sn);
    cJSON_AddStringToObject(p_root, "pcsSn", g_tcp_dev_info.sign_data.pcs_sn);
    cJSON_AddNumberToObject(p_root, "bcuNum", p_para_data->bat_cabinet_num);
    for(uint8_t i = 0; i < p_para_data->bat_cabinet_num; i++)
    {
        cJSON_AddItemToArray(p_bcu_array, cJSON_CreateString(g_tcp_dev_info.sign_data.bcu_sn[i]));
    }
    cJSON_AddItemToObject(p_root, "bcuSn", p_bcu_array);
    cJSON_AddStringToObject(p_root, "batStackSn", g_tcp_dev_info.sign_data.bat_stack_sn);
    cJSON_AddStringToObject(p_root, "fcSn", g_tcp_dev_info.sign_data.fc_sn);
    cJSON_AddStringToObject(p_root, "lcSn", g_tcp_dev_info.sign_data.lc_sn);

    p = cJSON_PrintUnformatted(p_root);
    tcp_send(socket_fd, p, strlen(p), recv_buff, &recv_len);
    if(recv_len > 0)
    {
        custom_set_time(recv_buff);
    }
    cJSON_Delete(p_root);
    free(p);
}


int is_socket_connected(int sockfd) {
    int err;
    socklen_t len;
    int bIsConnected;
 
    len = sizeof(bIsConnected);
 
    err = getsockopt(sockfd, SOL_SOCKET, SO_ERROR, &bIsConnected, &len);
 
    if (err < 0) {
        perror("getsockopt");
        return -1; // Error
    }
 
    return bIsConnected == 0 ? 1 : 0; // 1 = connected, 0 = not connected
}


/**
 * @brief   数据发送并等待接收
 * @param   [in] socket_fd:socket句柄
 * @param   [in] p_txdata:待数据内容
 * @param   [in] txdata_len:数据长度
 * @param   [out] p_rxdata:待数据内容
 * @param   [out] p_rxdata_len:数据长度
 * @note
 * @return
 */
void tcp_send(int socket_fd, char *p_txdata, int txdata_len, char *p_rxdata, int *p_rxdata_len)
{
    int ret = 0;
    int recv_len = 0;
    tcp_dev_info_t *p_dev_info = NULL;

    p_dev_info = tcp_dev_info_get();
    if(!is_socket_connected(socket_fd))
    {
        p_dev_info->tcp_connect_status = DISCONNECT;
        return;
    }
    pthread_mutex_lock(&g_tcp_mutex);
    ret = send(socket_fd, p_txdata, txdata_len, 0);
    if(ret <= 0)
    {
        TCP_DEBUG_PRINT((int8_t *)"tcp send error");
        pthread_mutex_unlock(&g_tcp_mutex);
        return;
    }
    recv_len = recv(socket_fd, p_rxdata, TCP_MAX_BUFF_LEN, 0);
    if(recv_len <= 0)
    {
        TCP_DEBUG_PRINT((int8_t *)"tcp recv error");
        pthread_mutex_unlock(&g_tcp_mutex);
        p_dev_info->tcp_connect_status = DISCONNECT;
        return;
    }
    TCP_DEBUG_PRINT((int8_t *)"tcp recv[%d]:%s", recv_len, p_rxdata);
    *p_rxdata_len = recv_len;
    pthread_mutex_unlock(&g_tcp_mutex);
}


/**
 * @brief   新建socket
 * @note
 * @return socket句柄
 */
static int tcp_socket_creat(void)
{
    return socket(AF_INET, SOCK_STREAM, 0);
}

/**
 * @brief   关闭socket
 * @note
 * @return
 */
static int tcp_socket_close(int socket_fd)
{
    return close(g_tcp_dev_info.socket_fd);
}

/**
 * @brief   连接服务器
 * @param   [in] socket_fd：socket句柄
 * @note
 * @return socket句柄
 */
static int tcp_socket_connect(int socket_fd)
{
    struct sockaddr_in serv_addr;
    struct timeval tv;

    tv.tv_sec = 1;
    tv.tv_usec = 0;
    memset(&serv_addr,0,sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;                
    serv_addr.sin_port = htons(TCP_PORT); 

    if(inet_pton(AF_INET, TCP_SERVER_ADDR, &serv_addr.sin_addr) <= 0)
    {
        TCP_DEBUG_PRINT((int8_t *)"inet_pton error\n");
        return RT_FAIL;
    }
    setsockopt(socket_fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    setsockopt(socket_fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    if(connect(socket_fd,(struct sockaddr*)&serv_addr,sizeof(serv_addr)) < 0)
    {
        TCP_DEBUG_PRINT((int8_t *)"socket connect error\n");
        return RT_FAIL;
    }
    g_tcp_dev_info.tcp_connect_status = CONNECT;
    dev_sign_in(socket_fd);

    return RT_SUCCESS;
}


/**
 * @brief   TCP连接服务进程
 * @param   [in] arg
 * @note
 * @return
 */
int main(int argc, char *argv[])
{
	common_data_t *p_common_data = NULL;

	log_init((int8_t *)PATH_CONF);
	log_set_level(LOG_LVL_DEBUG);
	
    //初始化线程锁
    pthread_mutex_init(&g_tcp_mutex, NULL);
    // 映射共享内存
    p_common_data = sdk_shm_init();
    while (p_common_data == NULL)
	{
		sleep(2);
		p_common_data = sdk_shm_init();
	}
    //即时检测数据上报模块初始化
    tcp_real_time_monitor_module_init();
    //定时监控数据上报模块初始化
    tcp_regular_time_monitor_module_init();
    //升级模块初始化
    sofar_ota_module_init();
    //等待其他进程初始化，不然可能SN还没有读取到共享内存
    sleep(15);
    dev_sign_data_init();
    g_tcp_dev_info.socket_fd = tcp_socket_creat();

    while(!tcp_socket_connect(g_tcp_dev_info.socket_fd))
    {
        sleep(3);
    }

	while(1)
    {
        if(g_tcp_dev_info.tcp_connect_status == DISCONNECT)
        {
            tcp_socket_close(g_tcp_dev_info.socket_fd);
            g_tcp_dev_info.socket_fd = tcp_socket_creat();
            tcp_socket_connect(g_tcp_dev_info.socket_fd);
            sleep(2);
        }
        usleep(500 * 1000);
    }
	return 0;
}