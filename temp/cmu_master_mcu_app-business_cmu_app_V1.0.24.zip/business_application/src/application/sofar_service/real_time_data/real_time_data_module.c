#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include "data_shm.h"
#include "sdk_shm.h"
#include "errors.h"
#include "sofar_log.h"
#include "cJSON.h"
#include "sofar_service.h"
#include "real_time_data_module.h"


static pcs_property_data_t g_pcs_property = {0};                                //PCS本地属性数据
static bms_property_data_t g_bcu_property[BCU_DEVICE_NUM] = {0};                //电池簇本地属性数据
static cmu_property_data_t g_cmu_property = {0};                                //CMU本地属性数据
static bat_stack_property_data_t g_bat_stack_property = {0};                    //电池堆本地属性数据
static fc_property_data_t g_fc_property = {0};                                  //消防本地属性数据
static lc_property_data_t g_lc_property = {0};                                  //液冷本地属性数据

static pcs_telematic_info_t g_pcs_module[PCS_CABINET_POWER_MODULE_NUM] = {0};   //PCS遥信本地属性数据
uint8_t g_battery_cluster_warn_info[BATTERY_CLUSTER_WARN_LEN_BYTE];             // CMU-1电池柜内电池簇（告警信息）
uint8_t g_battery_cluster_fault_info[BATTERY_CLUSTER_FAULT_LEN_BYTE];           // CMU-1电池柜内电池簇（故障信息）
uint8_t g_battery_cluster_warn_info[BATTERY_CLUSTER_WARN_LEN_BYTE];             // CMU-1电池柜内电池簇（告警信息）
uint8_t g_battery_cluster_fault_info[BATTERY_CLUSTER_FAULT_LEN_BYTE];           // CMU-1电池柜内电池簇（故障信息）
uint8_t g_container_system_warn_info[CONTAINER_SYSTEM_WARN_LEN_BYTE];           // CMU-1储能柜系统（告警信息）
uint8_t g_container_system_fault_info[CONTAINER_SYSTEM_FAULT_LEN_BYTE];         // CMU-1储能柜系统（故障信息）

typedef struct{
    uint16_t dev_fault_id;
    uint16_t sofar_fault_id;
}fault_id_t;
//PCS故障ID映射
const fault_id_t g_pcs_fault_id_table[PCS_MAX_EVENT_ITEM] = {
    {2049, 0x1000},{2050, 0x1001},{2051, 0x1002},{2052, 0x1003},
    {2053, 0x1010},{2054, 0x1020},{2055, 0x1021},{2056, 0x1022},
    {2059, 0x1023},{2065, 0x1024},{2066, 0x1025},{2068, 0x1026},
    {2070, 0x1027},{2078, 0x1030},{2085, 0x1040},{2086, 0x1050},
    {2089, 0x1060},{2090, 0x1070},{2094, 0x1080},{2104, 0x1090},
    {2105, 0x1091},{2107, 0x1092},{2108, 0x1093},{2109, 0x1094},
    {2110, 0x1095},{2111, 0x1096},{2112, 0x1097},{2113, 0x10A0},
    {2115, 0x10A1},{2118, 0x10A2},{2120, 0x10A3},{2121, 0x10B0},
    {2130, 0x10B1},{2131, 0x10B2},{2133, 0x10B3},{2136, 0x10B4},
    {2140, 0x10B5},{2146, 0x10B6},{2148, 0x10B7},{2151, 0x10B8},
    {2155, 0x10C0},{2193, 0x10C1},{2194, 0x10C2},{2195, 0x10C3},
    {2196, 0x10C4},{2197, 0x10C5},{2198, 0x10D0},{2199, 0x10D1},
    {2200, 0x10E0},{2201, 0x10E1},{2202, 0x10E2},{2203, 0x10E3},
    {2204, 0x10E4},{2217, 0x10F0},{2218, 0x10F1},{2257, 0x1110},
    {2273, 0x1120},{2274, 0x1121},{2225, 0x1130},{2227, 0x1131},
    {2228, 0x1132}
};

//BCU故障ID映射
const fault_id_t g_bcu_fault_id_table[BMS_MAX_EVENT_ITEM] = {
    {3, 0x2000}, {4, 0x2010}, {5, 0x2011}, {6, 0x2020},
    {7, 0x2030}, {9, 0x2040}, {10, 0x2050},{13, 0x2060},
    {14, 0x2061},{15, 0x2062},{16, 0x2070},{17, 0x2071},
    {18, 0x2072},{19, 0x2073},{20, 0x2080},{23, 0x2090},
    {24, 0x2091},{25, 0x20D0},{26, 0x20A0},{27, 0x20B0},
    {35, 0x20C0},{36, 0x20E0},{37, 0x20E1},{38, 0x20F0},
    {39, 0x2100},{46, 0x2110},{47, 0x2111},{49, 0x2120},
    {50, 0x2130}
};

//消防故障ID映射
const fault_id_t g_fc_fault_id_table[FC_MAX_EVENT_ITEM] = {
    {50, 0x4000}, {1, 0x4010}, {51, 0x4011}, {2, 0x4012},
    {52, 0x4013}, {3, 0x4014}, {53, 0x4015}, {4, 0x4016},
    {54, 0x4017}, {7, 0x4020}, {8, 0x4021},  {9, 0x4022},
    {10, 0x4023}, {13, 0x4030},{14, 0x4031}, {15, 0x4032},
    {16, 0x4033}, {19, 0x4040},{20, 0x4041}, {21, 0x4042},
    {22, 0x4043}, {25, 0x4050},{26, 0x4051}, {27, 0x4052},
    {28, 0x4053}, {57, 0x4060},{58, 0x4061}, {59, 0x4062},
    {60, 0x4063}, {63, 0x4070},{64, 0x4071}, {65, 0x4072},
    {66, 0x4073}, {69, 0x4080},{70, 0x4081}, {71, 0x4082},
    {72, 0x4083}, {75, 0x4090},{76, 0x4091}, {77, 0x4092},
    {78, 0x4093}, {81, 0x40A0},{31, 0x40B0}, {32, 0x40B1},
    {33, 0x40B2}, {34, 0x40B3},{37, 0x40C0}, {38, 0x40D0},
    {0, 0x40E0},  {45, 0x40F0}
};

//液冷故障ID映射
const fault_id_t g_lc_fault_id_table[LC_MAX_EVENT_ITEM] = {
    {0, 0x5000},  {1, 0x5010},  {10, 0x5020}, {11, 0x5030},
    {12, 0x5031}, {13, 0x5040}, {14, 0x5050}, {15, 0x5060},
    {16, 0x5061}, {17, 0x5062}, {18, 0x5063}, {19, 0x5070},
    {20, 0x5080}, {21, 0x5081}, {23, 0x5090}, {24, 0x50A0},
    {25, 0x50B0}, {26, 0x50B1}, {27, 0x50C0}, {28, 0x50D0},
    {29, 0x50D1}, {30, 0x50E0}, {31, 0x50E1}, {32, 0x50F0},
    {33, 0x50F1}, {34, 0x5100}, {35, 0x5101}, {36, 0x5102},
    {37, 0x5103}, {38, 0x5104}, {39, 0x5105}, {40, 0x5106},
    {41, 0x5107}, {42, 0x5110}, {43, 0x5111}, {44, 0x5112},
    {45, 0x5120}, {46, 0x5130}, {47, 0x5131}, {48, 0x5140},
    {49, 0x5150}, {50, 0x5160}, {61, 0x5170}, {62, 0x5171},
    {63, 0x5172}, {64, 0x5173}, {65, 0x5174}, {66, 0x5180},
    {67, 0x5190}, {68, 0x51A0}, {69, 0x51B0}, {70, 0x51C0},
    {71, 0x51C1}, {72, 0x51C2}, {73, 0x51C3}, {74, 0x51D0},
    {75, 0x51D1}, {76, 0x51E1}, {77, 0x51E2}, {78, 0x51E3},
};


/**
 * @brief   获取PCS通讯状态
 * @note
 * @return
 */
static uint8_t pcsm_state(int32_t pcs)
{
	heartbeat_data_t *heartbeat_data = sdk_shm_heartbeat_data_get();

	if ((pcs < 0) || (pcs > 7) || (NULL == heartbeat_data))
	{
		return 0;
	}

	if (0 == heartbeat_data->comm_state[pcs])
	{
		return 0;
	}

	if (1 == heartbeat_data->fault_state[pcs])
	{
		return 0;
	}	

    return 1;

}


/**
 * @brief   通过SN获取PCS型号信息
 * @note
 * @return
 */
static void pcs_model_get(char *p_sn, char *p_model)
{
    uint8_t len = 0;

    sprintf(p_model, "%s", "EBI ");
    len += strlen(p_model) + 1;
    memcpy(p_model + len - 1, &p_sn[6], 4);
    len += 4;
    if((p_sn[5] == 0x39) || (p_sn[5] == 0x36))
    {
        sprintf(p_model + len - 1, "-%s", "R");
    }
}


/**
 * @brief   PCS属性数据上报
 * @note
 * @return
 */
static void tcp_pcs_property_data_upload(void)
{
    uint8_t upload_flag = 0;
    cJSON *p_root = NULL;
    cJSON *p_data = NULL;
    char *p = NULL;
    tcp_dev_info_t *p_dev_info = NULL;
    uint8_t pcs_comm_status = 0;
    char pcs_model[32] = {0};
    char mdsp_version[VERSION_MAX_LEN] = {0};      //主DSP版本号
    char ldsp_version[VERSION_MAX_LEN] = {0};      //副DSP版本号
    uint8_t len = 0;
    uint8_t all_data_upload_flag = 0;
    static uint16_t upload_tick_cnt = 0;
    char recv_buff[TCP_MAX_BUFF_LEN] = {0};
    int recv_len = 0;
    pcs_module_version_telemetry_info_t *module_version_info = NULL;	
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();          //遥测数据
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数
    internal_shared_data_t *p_internal_shared_data = internal_shared_data_get();

    p_dev_info = tcp_dev_info_get();
    //上报计时，对精确度要求不高
    if(upload_tick_cnt < PROPERTY_UPLOAD_TIME_INTERVAL)
    {
        upload_tick_cnt++;
    }
    else
    {
        all_data_upload_flag = 1;
        upload_tick_cnt = 0;
    }  
    module_version_info = &p_telemetry_data->pcs_module_version_telemetry_info[0];

    snprintf(mdsp_version, sizeof(mdsp_version), "%c%d.%d.%d", module_version_info->fw_version[0],
                                                               module_version_info->fw_version[1],
                                                               module_version_info->fw_version[2],
                                                               module_version_info->fw_version[3]);


    snprintf(ldsp_version, sizeof(ldsp_version), "%c%d.%d.%d", module_version_info->slv_fw_version[0],
                                                               module_version_info->slv_fw_version[1],
                                                               module_version_info->slv_fw_version[2],
                                                               module_version_info->slv_fw_version[3]);
    
    //对比SN号	
	if(strcmp(g_pcs_property.pcs_sn, p_dev_info->sign_data.pcs_sn))
    {
        strcpy(g_pcs_property.pcs_sn, p_dev_info->sign_data.pcs_sn);
        upload_flag = 1;
    }	
    //对比PCS型号
    pcs_model_get(g_pcs_property.pcs_sn, pcs_model);
    if(strcmp(g_pcs_property.pcs_model, pcs_model))
    {
        strcpy(g_pcs_property.pcs_model, pcs_model);
        upload_flag = 1;
    }	
    //对比主DSP版本号
    if(strcmp(g_pcs_property.mdsp_version, mdsp_version))
    {
        strcpy(g_pcs_property.mdsp_version, mdsp_version);
        upload_flag = 1;
    }
    //对比副DSP版本号
    if(strcmp(g_pcs_property.ldsp_version, ldsp_version))
    {
        strcpy(g_pcs_property.ldsp_version, ldsp_version);
        upload_flag = 1;
    }	
    //对比设备类型
    if(g_pcs_property.dev_type != module_version_info->product_model)
    {
        g_pcs_property.dev_type = module_version_info->product_model;
        upload_flag = 1;
    }
    //对比额定功率
    if(g_pcs_property.rated_power != module_version_info->power)
    {
        g_pcs_property.rated_power = module_version_info->power;
        upload_flag = 1;
    }	
    //对比通讯状态
    pcs_comm_status = pcsm_state(0);
    if(g_pcs_property.comm_status != pcs_comm_status)
    {
        g_pcs_property.comm_status = pcs_comm_status;
        upload_flag = 1;
    }
    //对比系统状态
    if(g_pcs_property.sys_status != p_internal_shared_data->pcs_heartbeat_info.fsm_state[0])
    {
        g_pcs_property.sys_status = p_internal_shared_data->pcs_heartbeat_info.fsm_state[0];
        upload_flag = 1;
    }
    //对比额定电网电压
    if(g_pcs_property.rated_voltage != p_para_data->safety_param.group2[1])
    {
        g_pcs_property.rated_voltage = p_para_data->safety_param.group2[1];
        upload_flag = 1;
    }

    if(upload_flag || all_data_upload_flag)
    {
        p_data = cJSON_CreateObject();
        if(p_data == NULL)
        {
            TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
            return;
        }

        cJSON_AddStringToObject(p_data, "sn", g_pcs_property.pcs_sn);
        cJSON_AddStringToObject(p_data, "model", g_pcs_property.pcs_model);
        cJSON_AddStringToObject(p_data, "mDSPversion", g_pcs_property.mdsp_version);
        cJSON_AddStringToObject(p_data, "lDSPversion", g_pcs_property.ldsp_version);
        cJSON_AddNumberToObject(p_data, "devType", g_pcs_property.dev_type);
        cJSON_AddNumberToObject(p_data, "ratedPower", g_pcs_property.rated_power / 10);
        cJSON_AddNumberToObject(p_data, "commStatus", g_pcs_property.comm_status);
        cJSON_AddNumberToObject(p_data, "sysStatus", g_pcs_property.sys_status);
        cJSON_AddNumberToObject(p_data, "ratedVolt", g_pcs_property.rated_voltage);
       
        p_root = cJSON_CreateObject();
        if(p_root == NULL)
        {
            TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
            cJSON_Delete(p_data);
            return;
        }

        cJSON_AddStringToObject(p_root, "devtype", "pcs");
        cJSON_AddStringToObject(p_root, "cmdtype", "property");
        cJSON_AddNumberToObject(p_root, "cmuIndex", 1);
        cJSON_AddItemToObject(p_root, "data", p_data);

        p = cJSON_PrintUnformatted(p_root);
        tcp_send(p_dev_info->socket_fd, p, strlen(p), recv_buff, &recv_len);
        usleep(200 * 1000);
        cJSON_Delete(p_root);
        free(p);
    }
}


/**
 * @brief   BCU属性数据上报
 * @note
 * @return
 */
static void tcp_bcu_property_data_upload(void)
{
    uint8_t upload_flag = 0;
    static uint8_t bcu_cnt = 0;
    cJSON *p_root = NULL;
    cJSON *p_data = NULL;
    char *p = NULL;
    char recv_buff[TCP_MAX_BUFF_LEN] = {0};
    int recv_len = 0;
    uint8_t all_data_upload_flag = 0;
    static uint16_t upload_tick_cnt = 0;
    tcp_dev_info_t *p_dev_info = NULL;
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();          //遥测数据
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    p_dev_info = tcp_dev_info_get();
    //上报计时，对精确度要求不高
    if(upload_tick_cnt < PROPERTY_UPLOAD_TIME_INTERVAL)
    {
        upload_tick_cnt++;
    }
    else
    {
        all_data_upload_flag = 1;
        upload_tick_cnt = 0;
    }  
    //对比SN号	
	if(strcmp(g_bcu_property[bcu_cnt].bms_sn, p_dev_info->sign_data.bcu_sn[bcu_cnt]))
    {

        strcpy(g_bcu_property[bcu_cnt].bms_sn, p_dev_info->sign_data.bcu_sn[bcu_cnt]);
        upload_flag = 1;
    }	
    //对比电芯数量
    if(g_bcu_property[bcu_cnt].cell_num != p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].battery_number_in_PACK)
    {
        g_bcu_property[bcu_cnt].cell_num = p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].battery_number_in_PACK;
    }
    //对比通讯状态
    if(g_bcu_property[bcu_cnt].comm_status != p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].BCU_comm_status)
    {
        g_bcu_property[bcu_cnt].comm_status = p_telemetry_data->battery_cluster_telemetry_info[bcu_cnt].BCU_comm_status;
        upload_flag = 1;
    }
    //对比工作状态
    if(g_bcu_property[bcu_cnt].work_status != 1)
    {
        g_bcu_property[bcu_cnt].work_status = 1;
        upload_flag = 1;
    }
    //对比禁充禁放状态
    uint8_t char_prohibit = (p_telematic_data->container_system_status_info[0]) & 0x01;           // 禁充状态
    uint8_t dischar_prohibit = (p_telematic_data->container_system_status_info[0] >> 1) & 0x01;   // 禁放状态
    if(g_bcu_property[bcu_cnt].char_prohibit != char_prohibit)
    {
        g_bcu_property[bcu_cnt].char_prohibit = char_prohibit;
        upload_flag = 1;
    }
    if(g_bcu_property[bcu_cnt].dischar_prohibit != dischar_prohibit)
    {
        g_bcu_property[bcu_cnt].dischar_prohibit = dischar_prohibit;
        upload_flag = 1;
    }
    //继电器状态
    uint8_t status_p = (p_telematic_data->battery_cluster_telematic_info[bcu_cnt].battery_cluster_status_info[0]) & 0x01;           // 正继电器状态
    uint8_t status_n = ((p_telematic_data->battery_cluster_telematic_info[bcu_cnt].battery_cluster_status_info[0]) >> 2) & 0x01;    // 副继电器状态
    if(g_bcu_property[bcu_cnt].main_pos_relay != status_p)
    {
        g_bcu_property[bcu_cnt].main_pos_relay = status_p;
        upload_flag = 1;
    }
    if(g_bcu_property[bcu_cnt].main_nega_relay != status_n)
    {
        g_bcu_property[bcu_cnt].main_nega_relay = status_n;
        upload_flag = 1;
    }

    if(upload_flag || all_data_upload_flag)
    {
        p_data = cJSON_CreateObject();
        if(p_data == NULL)
        {
            TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
            return;
        }

        cJSON_AddStringToObject(p_data, "sn", g_bcu_property[bcu_cnt].bms_sn);
        cJSON_AddNumberToObject(p_data, "cellNum", g_bcu_property[bcu_cnt].cell_num);
        cJSON_AddNumberToObject(p_data, "commStatus", g_bcu_property[bcu_cnt].comm_status);
        cJSON_AddNumberToObject(p_data, "workStatus", g_bcu_property[bcu_cnt].work_status);
        cJSON_AddNumberToObject(p_data, "charProhibit", g_bcu_property[bcu_cnt].char_prohibit);
        cJSON_AddNumberToObject(p_data, "discharProhibit", g_bcu_property[bcu_cnt].dischar_prohibit);
        cJSON_AddNumberToObject(p_data, "mainPosRelay", g_bcu_property[bcu_cnt].main_pos_relay);
        cJSON_AddNumberToObject(p_data, "mainNegaRelay", g_bcu_property[bcu_cnt].main_nega_relay);
       
        p_root = cJSON_CreateObject();
        if(p_root == NULL)
        {
            TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
            cJSON_Delete(p_data);
            return;
        }

        cJSON_AddStringToObject(p_root, "devtype", "bms");
        cJSON_AddStringToObject(p_root, "cmdtype", "property");
        cJSON_AddNumberToObject(p_root, "cmuIndex", 1); 
        cJSON_AddNumberToObject(p_root, "clusterIndex", bcu_cnt + 1);
        cJSON_AddItemToObject(p_root, "data", p_data);

        p = cJSON_PrintUnformatted(p_root);
        tcp_send(p_dev_info->socket_fd, p, strlen(p), recv_buff, &recv_len);
        usleep(200 * 1000);
        cJSON_Delete(p_root);
        free(p);
    }
    bcu_cnt++;
    if(bcu_cnt >= p_para_data->bat_cabinet_num)
    {
        bcu_cnt = 0;
    }    
}


/**
 * @brief   CMU属性数据上报
 * @note
 * @return
 */
static void tcp_cmu_property_data_upload(void)
{
    uint8_t upload_flag = 0;
    cJSON *p_root = NULL;
    cJSON *p_data = NULL;
    char *p = NULL;
    tcp_dev_info_t *p_dev_info = NULL;
    char version[VERSION_MAX_LEN] = {0};    
    char recv_buff[TCP_MAX_BUFF_LEN] = {0};
    int recv_len = 0;	
    uint8_t all_data_upload_flag = 0;
    static uint16_t upload_tick_cnt = 0;
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();          //遥测数据
    internal_version_info_t *p_internal_version = internal_version_info_get();
    internal_shared_data_t *p_shared_data = internal_shared_data_get();

    p_dev_info = tcp_dev_info_get();
    //上报计时，对精确度要求不高
    if(upload_tick_cnt < PROPERTY_UPLOAD_TIME_INTERVAL)
    {
        upload_tick_cnt++;
    }
    else
    {
        all_data_upload_flag = 1;
        upload_tick_cnt = 0;
    }  
    //对比SN号	
	if(strcmp(g_cmu_property.cmu_sn, p_dev_info->sign_data.cmu_sn))
    {
        strcpy(g_cmu_property.cmu_sn, p_dev_info->sign_data.cmu_sn);
        upload_flag = 1;
    }	
    //对比版本号
    snprintf(version, sizeof(version), "%c%d.%d.%d", p_internal_version->mcu1_app_soft_version[0],
                                                     p_internal_version->mcu1_app_soft_version[1],
                                                     p_internal_version->mcu1_app_soft_version[2],
                                                     p_internal_version->mcu1_app_soft_version[3]);
    if(strcmp(g_cmu_property.version, version))
    {
        strcpy(g_cmu_property.version, version);
        upload_flag = 1;
    }
    //对比安规版本
    if(g_cmu_property.safe_version != p_shared_data->pcs_safety_ver)
    {
        g_cmu_property.safe_version = p_shared_data->pcs_safety_ver;
        upload_flag = 1;
    }
    //对比运行状态
    if(g_cmu_property.run_status != p_telemetry_data->cmu_telemetry_info.cmu_sys_state)
    {
        g_cmu_property.run_status = p_telemetry_data->cmu_telemetry_info.cmu_sys_state;
        upload_flag = 1;
    }

    if(upload_flag || all_data_upload_flag)
    {
        p_data = cJSON_CreateObject();
        if(p_data == NULL)
        {
            TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
            return;
        }

        cJSON_AddStringToObject(p_data, "sn", g_cmu_property.cmu_sn);
        cJSON_AddStringToObject(p_data, "version", g_cmu_property.version);
        memset(version, 0, sizeof(version));
        sprintf(version, "%d", g_cmu_property.safe_version);
        cJSON_AddStringToObject(p_data,"safetyVersion", version);
        cJSON_AddNumberToObject(p_data, "runStatus", g_cmu_property.run_status);
       
        p_root = cJSON_CreateObject();
        if(p_root == NULL)
        {
            TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
            cJSON_Delete(p_data);
            return;
        }

        cJSON_AddStringToObject(p_root, "devtype", "cmu");
        cJSON_AddStringToObject(p_root, "cmdtype", "property");
        cJSON_AddNumberToObject(p_root, "cmuIndex", 1);
        cJSON_AddItemToObject(p_root, "data", p_data);

        p = cJSON_PrintUnformatted(p_root);
        tcp_send(p_dev_info->socket_fd, p, strlen(p), recv_buff, &recv_len);
        usleep(200 * 1000);
        cJSON_Delete(p_root);
        free(p);
    }
}


/**
 * @brief   电池堆属性数据上报
 * @note
 * @return
 */
static void tcp_bat_stack_property_data_upload(void)
{
    uint8_t upload_flag = 0;
    cJSON *p_root = NULL;
    cJSON *p_data = NULL;
    char *p = NULL;
    tcp_dev_info_t *p_dev_info = NULL;
    char recv_buff[TCP_MAX_BUFF_LEN] = {0};
    int recv_len = 0;	
    uint8_t all_data_upload_flag = 0;
    static uint16_t upload_tick_cnt = 0;
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();          //遥测数据
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    p_dev_info = tcp_dev_info_get();
    //上报计时，对精确度要求不高
    if(upload_tick_cnt < PROPERTY_UPLOAD_TIME_INTERVAL)
    {
        upload_tick_cnt++;
    }
    else
    {
        all_data_upload_flag = 1;
        upload_tick_cnt = 0;
    }   
    //对比SN号	
	if(strcmp(g_bat_stack_property.bat_stack_sn, p_dev_info->sign_data.bat_stack_sn))
    {
        strcpy(g_bat_stack_property.bat_stack_sn, p_dev_info->sign_data.bat_stack_sn);
        upload_flag = 1;
    }	
    //对比通讯状态，全部失联即失联
    uint8_t bat_stack_comm = 0;
    for(uint8_t i = 0; i < p_para_data->bat_cabinet_num; i++)
    {
        if(p_telemetry_data->battery_cluster_telemetry_info[i].BCU_comm_status)
        {
            bat_stack_comm = 1;
            break;
        }
    }
    if(g_bat_stack_property.comm_status != bat_stack_comm)
    {
        g_bat_stack_property.comm_status = bat_stack_comm;
        upload_flag = 1;
    }
    //对比工作状态
    if(g_bat_stack_property.work_status != 0)
    {
        g_bat_stack_property.work_status = 0;
        upload_flag = 1;
    }
    //对比禁充禁放状态
    uint8_t char_prohibit = (p_telematic_data->container_system_status_info[0]) & 0x01;           // 禁充状态
    uint8_t dischar_prohibit = (p_telematic_data->container_system_status_info[0] >> 1) & 0x01;   // 禁放状态
    if(g_bat_stack_property.char_prohibit != char_prohibit)
    {
        g_bat_stack_property.char_prohibit = char_prohibit;
        upload_flag = 1;
    }
    if(g_bat_stack_property.dischar_prohibit != dischar_prohibit)
    {
        g_bat_stack_property.dischar_prohibit = dischar_prohibit;
        upload_flag = 1;
    }
    //对比电池簇数量
    if(g_bat_stack_property.bcu_num != p_para_data->bat_cabinet_num)
    {
        g_bat_stack_property.bcu_num = p_para_data->bat_cabinet_num;
        upload_flag = 1;
    }
    //对比电池簇内PACK数量
    if(g_bat_stack_property.pack_num != p_para_data->bat_cluster_pack_num)
    {
        g_bat_stack_property.pack_num = p_para_data->bat_cluster_pack_num;
        upload_flag = 1;
    }
    //对比PACK内电芯数量
    if(g_bat_stack_property.cell_num != p_telemetry_data->battery_cluster_telemetry_info[0].battery_number_in_PACK)
    {
        g_bat_stack_property.cell_num = p_telemetry_data->battery_cluster_telemetry_info[0].battery_number_in_PACK;
        upload_flag = 1;
    }

    if(upload_flag || all_data_upload_flag)
    {
        p_data = cJSON_CreateObject();
        if(p_data == NULL)
        {
            TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
            return;
        }

        cJSON_AddStringToObject(p_data, "sn", g_bat_stack_property.bat_stack_sn);
        cJSON_AddNumberToObject(p_data, "commStatus", g_bat_stack_property.comm_status);
        cJSON_AddNumberToObject(p_data, "workStatus", g_bat_stack_property.work_status);
        cJSON_AddNumberToObject(p_data, "charProhibit", g_bat_stack_property.char_prohibit);
        cJSON_AddNumberToObject(p_data, "discharProhibit", g_bat_stack_property.dischar_prohibit);
        cJSON_AddNumberToObject(p_data, "bcuNum", g_bat_stack_property.bcu_num);
        cJSON_AddNumberToObject(p_data, "pcakNum", g_bat_stack_property.pack_num);
        cJSON_AddNumberToObject(p_data, "cellNum", g_bat_stack_property.cell_num);
       
        p_root = cJSON_CreateObject();
        if(p_root == NULL)
        {
            TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
            cJSON_Delete(p_data);
            return;
        }

        cJSON_AddStringToObject(p_root, "devtype", "batstack");
        cJSON_AddStringToObject(p_root, "cmdtype", "property");
        cJSON_AddNumberToObject(p_root, "cmuIndex", 1);
        cJSON_AddItemToObject(p_root, "data", p_data);

        p = cJSON_PrintUnformatted(p_root);
        tcp_send(p_dev_info->socket_fd, p, strlen(p), recv_buff, &recv_len);
        usleep(200 * 1000);
        cJSON_Delete(p_root);
        free(p);
    }
}


/**
 * @brief   消防属性数据上报
 * @note
 * @return
 */
static void tcp_fc_property_data_upload(void)
{
    uint8_t upload_flag = 0;
    cJSON *p_root = NULL;
    cJSON *p_data = NULL;
    char *p = NULL;
    tcp_dev_info_t *p_dev_info = NULL;
    uint8_t fc_comm_status = 0;
    uint8_t fc_run_status = 0;
    uint8_t fc_sd_status = 0;
    uint8_t fc_td_status = 0;
    char recv_buff[TCP_MAX_BUFF_LEN] = {0};
    int recv_len = 0;
    uint8_t all_data_upload_flag = 0;
    static uint16_t upload_tick_cnt = 0;
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();

    p_dev_info = tcp_dev_info_get();
    //上报计时，对精确度要求不高
    if(upload_tick_cnt < PROPERTY_UPLOAD_TIME_INTERVAL)
    {
        upload_tick_cnt++;
    }
    else
    {
        all_data_upload_flag = 1;
        upload_tick_cnt = 0;
    }  
    //对比SN号	
	if(strcmp(g_fc_property.fc_sn, p_dev_info->sign_data.fc_sn))
    {
        strcpy(g_fc_property.fc_sn, p_dev_info->sign_data.fc_sn);
        upload_flag = 1;
    }	
    //对比设备类型，当前只有景安
    if(g_fc_property.dev_type != 0)
    {
        g_fc_property.dev_type = 0;
        upload_flag = 1;
    }
    //通讯状态
    fc_comm_status = BIT_GET(p_telematic_data->container_system_warn_info[0], 7);
    if(g_fc_property.comm_status != (!fc_comm_status))
    {
        g_fc_property.comm_status = !fc_comm_status;
        upload_flag = 1;
    }	
    //运行状态
    fc_run_status = BIT_GET(p_telematic_data->container_system_status_info[3], 1);
    if(g_fc_property.work_status != (!fc_run_status))
    {
        g_fc_property.work_status = !fc_run_status;
        upload_flag = 1;
    }	
    //烟感状态，获取所有的电池柜烟感状态
    fc_sd_status = ((BIT_GET(p_telematic_data->container_system_status_info[5], 0)) |
                    (BIT_GET(p_telematic_data->container_system_status_info[5], 2)) |
                    (BIT_GET(p_telematic_data->container_system_status_info[5], 4)) |
                    (BIT_GET(p_telematic_data->container_system_status_info[5], 6)));
    // if(g_fc_property.sd_status != (!fc_sd_status))
    if(g_fc_property.sd_status != fc_sd_status)
    {
        g_fc_property.sd_status = fc_sd_status;
        upload_flag = 1;
    }	
    //温感状态，获取所有的电池柜烟感状态
    fc_td_status = ((BIT_GET(p_telematic_data->container_system_status_info[5], 1)) |
                    (BIT_GET(p_telematic_data->container_system_status_info[5], 3)) |
                    (BIT_GET(p_telematic_data->container_system_status_info[5], 5)) |
                    (BIT_GET(p_telematic_data->container_system_status_info[5], 7)));
    // if(g_fc_property.td_status != (!fc_td_status))
    if(g_fc_property.td_status != fc_td_status)
    {
        g_fc_property.td_status = fc_td_status;
        upload_flag = 1;
    }

    if(upload_flag || all_data_upload_flag)
    {
        p_data = cJSON_CreateObject();
        if(p_data == NULL)
        {
            TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
            return;
        }

        cJSON_AddStringToObject(p_data, "sn", g_fc_property.fc_sn);
        cJSON_AddNumberToObject(p_data, "devType", g_fc_property.dev_type);
        cJSON_AddNumberToObject(p_data, "commStatus", g_fc_property.comm_status);
        cJSON_AddNumberToObject(p_data, "workStatus", g_fc_property.work_status);
        cJSON_AddNumberToObject(p_data, "sdStatus", g_fc_property.sd_status);
        cJSON_AddNumberToObject(p_data, "tdStatus", g_fc_property.td_status);
       
        p_root = cJSON_CreateObject();
        if(p_root == NULL)
        {
            TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
            cJSON_Delete(p_data);
            return;
        }

        cJSON_AddStringToObject(p_root, "devtype", "fc");
        cJSON_AddStringToObject(p_root, "cmdtype", "property");
        cJSON_AddNumberToObject(p_root, "cmuIndex", 1);
        cJSON_AddItemToObject(p_root, "data", p_data);

        p = cJSON_PrintUnformatted(p_root);
        tcp_send(p_dev_info->socket_fd, p, strlen(p), recv_buff, &recv_len);
        usleep(200 * 1000);
        cJSON_Delete(p_root);
        free(p);
    }
}


/**
 * @brief   液冷属性数据上报
 * @note
 * @return
 */
static void tcp_lc_property_data_upload(void)
{
    uint8_t upload_flag = 0;
    cJSON *p_root = NULL;
    cJSON *p_data = NULL;
    char *p = NULL;
    tcp_dev_info_t *p_dev_info = NULL;
    uint8_t lc_comm_status = 0;
    uint8_t lc_run_status = 0;
    uint8_t lc_warn_status = 0;
    uint8_t lc_wp_status = 0;
    uint8_t lc_cp_status = 0;
    uint8_t lc_eh_status = 0;
    char recv_buff[TCP_MAX_BUFF_LEN] = {0};
    int recv_len = 0;	
    uint8_t all_data_upload_flag = 0;
    static uint16_t upload_tick_cnt = 0;
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();

    p_dev_info = tcp_dev_info_get();
    //上报计时，对精确度要求不高
    if(upload_tick_cnt < PROPERTY_UPLOAD_TIME_INTERVAL)
    {
        upload_tick_cnt++;
    }
    else
    {
        all_data_upload_flag = 1;
        upload_tick_cnt = 0;
    }  
    //对比SN号	
	if(strcmp(g_lc_property.lc_sn, p_dev_info->sign_data.lc_sn))
    {
        strcpy(g_lc_property.lc_sn, p_dev_info->sign_data.lc_sn);
        upload_flag = 1;
    }	
    //对比设备类型
    if(g_lc_property.dev_type != p_telemetry_data->container_system_telemetry_info.lc_type)
    {
        g_lc_property.dev_type = p_telemetry_data->container_system_telemetry_info.lc_type;
        upload_flag = 1;
    }
    //通讯状态
    lc_comm_status = BIT_GET(p_telematic_data->container_system_fault_info[3], 1);
    if(g_lc_property.comm_status != (!lc_comm_status))
    {
        g_lc_property.comm_status = !lc_comm_status;
        upload_flag = 1;
    }	
    //运行状态
    lc_run_status = BIT_GET(p_telematic_data->container_system_status_info[8], 0);
    if(g_lc_property.work_status != (!lc_run_status))
    {
        g_lc_property.work_status = (!lc_run_status);
        upload_flag = 1;
    }	
    //运行模式
    if(g_lc_property.work_mode != p_telemetry_data->container_system_telemetry_info.lc_control_mode)
    {
        g_lc_property.work_mode = p_telemetry_data->container_system_telemetry_info.lc_control_mode;
        upload_flag = 1;
    }	
    //告警状态
    lc_warn_status = BIT_GET(p_telematic_data->container_system_warn_info[2], 0);
    if(g_lc_property.warn_status != lc_warn_status)
    {
        g_lc_property.warn_status = lc_warn_status;
        upload_flag = 1;
    }	
    //水泵状态,压缩机制冷、制热运行、自循环，只要有一个是开启的，水泵即为开启状态
    lc_wp_status = ((BIT_GET(p_telematic_data->container_system_status_info[9], 3)) |
                    (BIT_GET(p_telematic_data->container_system_status_info[9], 4)) |
                    (BIT_GET(p_telematic_data->container_system_status_info[9], 5)) |
                    (BIT_GET(p_telematic_data->container_system_status_info[9], 6)));
    if(g_lc_property.wp_status != lc_wp_status)
    {
        g_lc_property.wp_status = lc_wp_status;
        upload_flag = 1;
    }	
    //压缩机状态
    lc_cp_status = BIT_GET(p_telematic_data->container_system_status_info[9], 3);
    if(g_lc_property.cp_status != lc_cp_status)
    {
        g_lc_property.cp_status = lc_cp_status;
        upload_flag = 1;
    }	
    //电加热状态
    lc_eh_status = BIT_GET(p_telematic_data->container_system_status_info[9], 5);
    if(g_lc_property.eh_status != lc_eh_status)
    {
        g_lc_property.eh_status = lc_eh_status;
        upload_flag = 1;
    }
    //风机状态
    if(g_lc_property.fan_status != 0)
    {
        g_lc_property.fan_status = 0;
        upload_flag = 1;
    }	

    if(upload_flag || all_data_upload_flag)
    {
        p_data = cJSON_CreateObject();
        if(p_data == NULL)
        {
            TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
            return;
        }

        cJSON_AddStringToObject(p_data, "sn", g_lc_property.lc_sn);
        cJSON_AddNumberToObject(p_data, "devType", g_lc_property.dev_type);
        cJSON_AddNumberToObject(p_data, "commStatus", g_lc_property.comm_status);
        cJSON_AddNumberToObject(p_data, "workStatus", g_lc_property.work_status);
        cJSON_AddNumberToObject(p_data, "runMode", g_lc_property.work_mode);
        cJSON_AddNumberToObject(p_data, "warnStatus", g_lc_property.warn_status);
        cJSON_AddNumberToObject(p_data, "wpStatus", g_lc_property.wp_status);
        cJSON_AddNumberToObject(p_data, "cpStatus", g_lc_property.cp_status);
        cJSON_AddNumberToObject(p_data, "ehStatus", g_lc_property.eh_status);
        cJSON_AddNumberToObject(p_data, "fanStatus", g_lc_property.fan_status);
   
        p_root = cJSON_CreateObject();
        if(p_root == NULL)
        {
            TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
            cJSON_Delete(p_data);
            return;
        }

        cJSON_AddStringToObject(p_root, "devtype", "lc");
        cJSON_AddStringToObject(p_root, "cmdtype", "property");
        cJSON_AddNumberToObject(p_root, "cmuIndex", 1);
        cJSON_AddItemToObject(p_root, "data", p_data);

        p = cJSON_PrintUnformatted(p_root);
        tcp_send(p_dev_info->socket_fd, p, strlen(p), recv_buff, &recv_len);
        usleep(200 * 1000);
        cJSON_Delete(p_root);
        free(p);
    }
}



/**
 * @brief   PCS故障数据上报
 * @param   [in] fault_id:故障ID
 * @param   [in] fault_status:故障状态
 * @note
 * @return
 */
static void pcs_fault_data_upload(uint16_t fault_id, uint8_t fault_status)
{
    uint8_t i = 0;
    cJSON *p_root = NULL;
    cJSON *p_data = NULL;
    char *p = NULL;
    tcp_dev_info_t *p_dev_info = NULL;  
    char recv_buff[TCP_MAX_BUFF_LEN] = {0};
    int recv_len = 0;	
    uint16_t sofar_fault_id = 0;

    p_dev_info = tcp_dev_info_get();

    //获取首航云故障ID
    for(i = 0; i < PCS_MAX_EVENT_ITEM; i++)
    {
        if(fault_id == g_pcs_fault_id_table[i].dev_fault_id)
        {
            sofar_fault_id = g_pcs_fault_id_table[i].sofar_fault_id;
            break;
        }
    }
    if(i == PCS_MAX_EVENT_ITEM)
    {
        TCP_DEBUG_PRINT((int8_t *)"fault id not exit");
        return;
    }

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_data);
        return;
    }

    cJSON_AddStringToObject(p_root, "devtype", "pcs");
    cJSON_AddStringToObject(p_root, "cmdtype", "event");
    cJSON_AddNumberToObject(p_root, "cmuIndex", 1);
    cJSON_AddNumberToObject(p_root, "ID", sofar_fault_id);
    cJSON_AddNumberToObject(p_root, "code", !fault_status);
    cJSON_AddNumberToObject(p_root, "level", 3);                //PCS均为3级故障
    cJSON_AddNumberToObject(p_root, "time", time(NULL));

    p = cJSON_PrintUnformatted(p_root);
    tcp_send(p_dev_info->socket_fd, p, strlen(p), recv_buff, &recv_len);
    usleep(100 * 1000);
    cJSON_Delete(p_root);
    free(p);
    
}


/**
 * @brief   PCS事件数据上报
 * @note
 * @return
 */
static void tcp_pcs_event_data_upload(void)
{
    int ret = 0;
    uint16_t id = 0;
    uint8_t i = 0;
    pcs_telematic_info_t *p_pcs_module = NULL;
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();

    p_pcs_module = &p_telematic_data->pcs_module[0];
    ret = memcmp(&p_pcs_module->grid_fault , &g_pcs_module[0].grid_fault, 2);
    if (0 != ret)
    {
        for(i = 0; i < 16; i ++)
        {
            if((((p_pcs_module->grid_fault.val >> i) & 0x0001) ) != ((g_pcs_module[0].grid_fault.val >> i) & 0x0001))
            {
                id = GRID_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT;
                if ((g_pcs_module[0].grid_fault.val >> i) & 0x0001)
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] end", id);
                    pcs_fault_data_upload(id, 0);
                    BIT_CLR(g_pcs_module[0].grid_fault.val, i);
                }
                else
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] start", id);
                    pcs_fault_data_upload(id, 1);
                    BIT_SET(g_pcs_module[0].grid_fault.val, i);
                }
            }
        }
    }

    ret = memcmp(&p_pcs_module->sampling_fault , &g_pcs_module[0].sampling_fault, 2);
    if (0 != ret)
    {
        for(i = 0; i < 16; i ++)
        {
            if(((p_pcs_module->sampling_fault.val >> i) & 0x0001) != ((g_pcs_module[0].sampling_fault.val >> i) & 0x0001))
            {
                //存储事件
                id = SAMPLING_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT;
                if ((g_pcs_module[0].sampling_fault.val >> i) & 0x0001)
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] end", id);
                    pcs_fault_data_upload(id, 0);
                    BIT_CLR(g_pcs_module[0].sampling_fault.val, i);
                }
                else
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] start", id);
                    pcs_fault_data_upload(id, 1);
                    BIT_SET(g_pcs_module[0].sampling_fault.val, i);
                }
            }			
        }
    }

    ret = memcmp(&p_pcs_module->self_test_fault , &g_pcs_module[0].self_test_fault, 2);
    if (0 != ret)
    {
        for(i = 0; i < 16; i ++)
        {
            if((((p_pcs_module->self_test_fault.val >> i) & 0x0001)) != ((g_pcs_module[0].self_test_fault.val >> i) & 0x0001))
            {
                //存储事件
                id = SELF_TEST_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT;
                if ((g_pcs_module[0].self_test_fault.val >> i) & 0x0001)
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] end", id);
                    pcs_fault_data_upload(id, 0);
                    BIT_CLR(g_pcs_module[0].self_test_fault.val, i);
                }
                else
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] start", id);
                    pcs_fault_data_upload(id, 1);
                    BIT_SET(g_pcs_module[0].self_test_fault.val, i);
                }
            }			
        }
    }

    ret = memcmp(&p_pcs_module->temperature_fault , &g_pcs_module[0].temperature_fault, 2);
    if (0 != ret)
    {
        for(i = 0; i < 16; i ++)
        {
            if((((p_pcs_module->temperature_fault.val >> i) & 0x0001)) != ((g_pcs_module[0].temperature_fault.val >> i) & 0x0001))
            {
                    //存储事件
                id = TEMP_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT;
                if ((g_pcs_module[0].temperature_fault.val >> i) & 0x0001)
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] end", id);
                    pcs_fault_data_upload(id, 0);
                    BIT_CLR(g_pcs_module[0].temperature_fault.val, i);
                }
                else
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] start", id);
                    pcs_fault_data_upload(id, 1);
                    BIT_SET(g_pcs_module[0].temperature_fault.val, i);
                }
            }			
        }
    }


    ret = memcmp(&p_pcs_module->voltage_fault , &g_pcs_module[0].voltage_fault, 2);
    if (0 != ret)
    {
        for(i = 0; i < 16; i ++)
        {
            if((((p_pcs_module->voltage_fault.val >> i) & 0x0001)) != ((g_pcs_module[0].voltage_fault.val >> i) & 0x0001))
            {
                id = VOLT_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT;
                if ((g_pcs_module[0].voltage_fault.val >> i) & 0x0001)
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] end", id);
                    pcs_fault_data_upload(id, 0);
                    BIT_CLR(g_pcs_module[0].voltage_fault.val, i);
                }
                else
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] start", id);
                    pcs_fault_data_upload(id, 1);
                    BIT_SET(g_pcs_module[0].voltage_fault.val, i);
                }						
            }			
        }
    }		

    ret = memcmp(&p_pcs_module->current_fault , &g_pcs_module[0].current_fault, 2);
    if (0 != ret)
    {
        for(i = 0; i < 16; i ++)
        {
            if((((p_pcs_module->current_fault.val >> i) & 0x0001)) != ((g_pcs_module[0].current_fault.val >> i) & 0x0001))
            {
                id = CURRENT_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT;
                if ((g_pcs_module[0].current_fault.val >> i) & 0x0001)
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] end", id);
                    pcs_fault_data_upload(id, 0);
                    BIT_CLR(g_pcs_module[0].current_fault.val, i);
                }
                else
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] start", id);
                    pcs_fault_data_upload(id, 1);
                    BIT_SET(g_pcs_module[0].current_fault.val, i);
                }						
            }			
        }
    }	

    ret = memcmp(&p_pcs_module->hardware_signal_fault , &g_pcs_module[0].hardware_signal_fault, 2);
    if (0 != ret)
    {
        for(i = 0; i < 16; i ++)
        {
            if((((p_pcs_module->hardware_signal_fault.val >> i) & 0x0001) ) != ((g_pcs_module[0].hardware_signal_fault.val >> i) & 0x0001))
            {
                id = HWSIGNAL_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT;
                if ((g_pcs_module[0].hardware_signal_fault.val >> i) & 0x0001)
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] end", id);
                    pcs_fault_data_upload(id, 0);
                    BIT_CLR(g_pcs_module[0].hardware_signal_fault.val, i);
                }
                else
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] start", id);
                    pcs_fault_data_upload(id, 1);
                    BIT_SET(g_pcs_module[0].hardware_signal_fault.val, i);
                }						
            }		
        }
    }	

    ret = memcmp(&p_pcs_module->control_fault , &g_pcs_module[0].control_fault, 2);
    if (0 != ret)
    {
        for(i = 0; i < 16; i ++)
        {
            if((((p_pcs_module->control_fault.val >> i) & 0x0001) ) != ((g_pcs_module[0].control_fault.val >> i) & 0x0001))
            {
                id = CONTROL_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT;
                if ((g_pcs_module[0].control_fault.val >> i) & 0x0001)
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] end", id);
                    pcs_fault_data_upload(id, 0);
                    BIT_CLR(g_pcs_module[0].control_fault.val, i);
                }
                else
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] start", id);
                    pcs_fault_data_upload(id, 1);
                    BIT_SET(g_pcs_module[0].control_fault.val, i);
                }		
            }			
        }
    }	

    ret = memcmp(&p_pcs_module->communication_fault, &g_pcs_module[0].communication_fault, 2);
    if (0 != ret)
    {
        for(i = 0; i < 16; i ++)
        {
            if((((p_pcs_module->communication_fault.val >> i) & 0x0001)) != ((g_pcs_module[0].communication_fault.val >> i) & 0x0001))
            {
                id = COMM_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT;
                if ((g_pcs_module[0].communication_fault.val >> i) & 0x0001)
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] end", id);
                    pcs_fault_data_upload(id, 0);
                    BIT_CLR(g_pcs_module[0].communication_fault.val, i);
                }
                else
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] start", id);
                    pcs_fault_data_upload(id, 1);
                    BIT_SET(g_pcs_module[0].communication_fault.val, i);
                }				
            }			
        }
    }

    ret = memcmp(&p_pcs_module->supplement_fault , &g_pcs_module[0].supplement_fault, 2);
    if (0 != ret)
    {
        for(i = 0; i < 16; i ++)
        {
            if((((p_pcs_module->supplement_fault.val >> i) & 0x0001)) != ((g_pcs_module[0].supplement_fault.val >> i) & 0x0001))
            {
                id = SUPPLEEMENT_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT;
                if ((g_pcs_module[0].supplement_fault.val >> i) & 0x0001)
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] end", id);
                    pcs_fault_data_upload(id, 0);
                    BIT_CLR(g_pcs_module[0].supplement_fault.val, i);
                }
                else
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] start", id);
                    pcs_fault_data_upload(id, 1);
                    BIT_SET(g_pcs_module[0].supplement_fault.val, i);
                }		
            }			
        }
    }	


    ret = memcmp(&p_pcs_module->external_device_fault , &g_pcs_module[0].external_device_fault, 2);
    if (0 != ret)
    {
        for(i = 0; i < 16; i ++)
        {
            if((((p_pcs_module->external_device_fault.val >> i) & 0x0001)) != ((g_pcs_module[0].external_device_fault.val >> i) & 0x0001))
            {
                id = DEVICE_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT;
                if ((g_pcs_module[0].external_device_fault.val >> i) & 0x0001)
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] end", id);
                    pcs_fault_data_upload(id, 0);
                    BIT_CLR(g_pcs_module[0].external_device_fault.val, i);
                }
                else
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] start", id);
                    pcs_fault_data_upload(id, 1);
                    BIT_SET(g_pcs_module[0].external_device_fault.val, i);
                }	
            }			
        }
    }	


    ret = memcmp(&p_pcs_module->warn_info , &g_pcs_module[0].warn_info, 2);
    if (0 != ret)
    {
        for(i = 0; i < 16; i ++)
        {
            if((((p_pcs_module->warn_info.val >> i) & 0x0001)) != ((g_pcs_module[0].warn_info.val >> i) & 0x0001))
            {
                id = WARN_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT;
                if ((g_pcs_module[0].warn_info.val >> i) & 0x0001)
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] end", id);
                    pcs_fault_data_upload(id, 0);
                    BIT_CLR(g_pcs_module[0].warn_info.val, i);
                }
                else
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] start", id);
                    pcs_fault_data_upload(id, 1);
                    BIT_SET(g_pcs_module[0].warn_info.val, i);
                }	
            }			
        }
    }	

    ret = memcmp(&p_pcs_module->state6 , &g_pcs_module[0].state6, 2);
    if (0 != ret)
    {
        for(i = 0; i < 16; i ++)
        {
            if((((p_pcs_module->state6.val >> i) & 0x0001)) != ((g_pcs_module[0].state6.val >> i) & 0x0001))
            {
                //存储事件
                id = STATE6_FAULT_START_POINT + i + PCSMODULE_CLUSTER_FAULT_START_POINT;
                if ((g_pcs_module[0].state6.val >> i) & 0x0001)
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] end", id);
                    pcs_fault_data_upload(id, 0);
                    BIT_CLR(g_pcs_module[0].state6.val, i);
                }
                else
                {
                    TCP_DEBUG_PRINT((int8_t *)"fault[%d] start", id);
                    pcs_fault_data_upload(id, 1);
                    BIT_SET(g_pcs_module[0].state6.val, i);
                }				
            }			
        }
    }	
}



/**
 * @brief   BCU故障数据上报
 * @param   [in] fault_id:故障ID
 * @param   [in] fault_status:故障状态
 * @param   [in] fault_level:故障等级
 * @param   [in] cluster_index:电池簇序号
 * @note
 * @return
 */
static void bcu_fault_data_upload(uint16_t fault_id, uint8_t fault_status, uint8_t fault_level, uint8_t cluster_index)
{
    uint8_t i = 0;
    cJSON *p_root = NULL;
    cJSON *p_data = NULL;
    char *p = NULL;
    tcp_dev_info_t *p_dev_info = NULL;  
    char recv_buff[TCP_MAX_BUFF_LEN] = {0};
    int recv_len = 0;	
    uint16_t sofar_fault_id = 0;

    p_dev_info = tcp_dev_info_get();

    //获取首航云故障ID
    for(i = 0; i < BMS_MAX_EVENT_ITEM; i++)
    {
        if(fault_id == g_bcu_fault_id_table[i].dev_fault_id)
        {
            sofar_fault_id = g_bcu_fault_id_table[i].sofar_fault_id;
            break;
        }
    }
    if(i == BMS_MAX_EVENT_ITEM)
    {
        TCP_DEBUG_PRINT((int8_t *)"fault id not exit");
        return;
    }

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_data);
        return;
    }

    cJSON_AddStringToObject(p_root, "devtype", "bms");
    cJSON_AddStringToObject(p_root, "cmdtype", "event");
    cJSON_AddNumberToObject(p_root, "cmuIndex", 1);
    cJSON_AddNumberToObject(p_root, "clusterIndex", cluster_index);
    cJSON_AddNumberToObject(p_root, "ID", sofar_fault_id);
    cJSON_AddNumberToObject(p_root, "code", !fault_status);
    cJSON_AddNumberToObject(p_root, "level", fault_level); 
    cJSON_AddNumberToObject(p_root, "time", time(NULL));

    p = cJSON_PrintUnformatted(p_root);
    tcp_send(p_dev_info->socket_fd, p, strlen(p), recv_buff, &recv_len);
    usleep(100 * 1000);
    cJSON_Delete(p_root);
    free(p);
    
}


/**
 * @brief   BCU事件数据上报
 * @note
 * @return
 */
static void tcp_bcu_event_data_upload(void)
{
    int ret = 0;
    uint16_t id = 0;
    uint8_t i = 0;
    uint8_t j = 0;
    uint8_t *p_bcu_warn = NULL;
    uint8_t *p_bcu_fault = NULL;
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get();

    for(uint8_t bat_cnt = 0; bat_cnt < p_para_data->bat_cabinet_num; bat_cnt++)
    {
        p_bcu_warn = &p_telematic_data->battery_cluster_telematic_info[bat_cnt].battery_cluster_warn_info[0];
        p_bcu_fault = &p_telematic_data->battery_cluster_telematic_info[bat_cnt].battery_cluster_fault_info[0];

        ret = memcmp(p_bcu_warn, &g_battery_cluster_warn_info, BATTERY_CLUSTER_WARN_LEN_BYTE);
        if (0 != ret)
        {
            //一级告警
            for (i = BCU_WARN1_BYTE_START; i < BCU_WARN1_BYTE_END; i++)
			{
                for(j = 0; j < 8; j++)
                {
                    if(((p_bcu_warn[i] >> j) & 0x01) != ((g_battery_cluster_warn_info[i] >> j) & 0x01))
                    {
                        id = BCU_WARN_START_POINT + (i - BCU_WARN1_BYTE_START) * 8 + j;
                        if ((g_battery_cluster_warn_info[i] >> j) & 0x01)
                        {
                            TCP_DEBUG_PRINT((int8_t *)"bcu fault[%d] end", id);
                            bcu_fault_data_upload(id, 0, 1, bat_cnt + 1);
                            BIT_CLR(g_battery_cluster_warn_info[i], j);
                        }
                        else
                        {
                            TCP_DEBUG_PRINT((int8_t *)"bcu fault[%d] start", id);
                            bcu_fault_data_upload(id, 1, 1, bat_cnt + 1);
                            BIT_SET(g_battery_cluster_warn_info[i], j);
                        }
                    }
                }
            }
            //二级告警
            for (i = BCU_WARN2_BYTE_START; i < BCU_WARN2_BYTE_END; i++)
			{
                for(j = 0; j < 8; j++)
                {
                    if(((p_bcu_warn[i] >> j) & 0x01) != ((g_battery_cluster_warn_info[i] >> j) & 0x01))
                    {
                        id = BCU_WARN_START_POINT + (i - BCU_WARN2_BYTE_START) * 8 + j;
                        if ((g_battery_cluster_warn_info[i] >> j) & 0x01)
                        {
                            TCP_DEBUG_PRINT((int8_t *)"bcu fault[%d] end", id);
                            bcu_fault_data_upload(id, 0, 2, bat_cnt + 1);
                            BIT_CLR(g_battery_cluster_warn_info[i], j);
                        }
                        else
                        {
                            TCP_DEBUG_PRINT((int8_t *)"bcu fault[%d] start", id);
                            bcu_fault_data_upload(id, 1, 2, bat_cnt + 1);
                            BIT_SET(g_battery_cluster_warn_info[i], j);
                        }
                    }
                }
            }
            //三级告警
            for (i = BCU_WARN3_BYTE_START; i < BCU_WARN3_BYTE_END; i++)
			{
                for(j = 0; j < 8; j++)
                {
                    if(((p_bcu_warn[i] >> j) & 0x01) != ((g_battery_cluster_warn_info[i] >> j) & 0x01))
                    {
                        id = BCU_WARN_START_POINT + (i - BCU_WARN3_BYTE_START) * 8 + j;
                        if ((g_battery_cluster_warn_info[i] >> j) & 0x01)
                        {
                            TCP_DEBUG_PRINT((int8_t *)"bcu fault[%d] end", id);
                            bcu_fault_data_upload(id, 0, 3, bat_cnt + 1);
                            BIT_CLR(g_battery_cluster_warn_info[i], j);
                        }
                        else
                        {
                            TCP_DEBUG_PRINT((int8_t *)"bcu fault[%d] start", id);
                            bcu_fault_data_upload(id, 1, 3, bat_cnt + 1);
                            BIT_SET(g_battery_cluster_warn_info[i], j);
                        }
                    }
                }
            }
			//其他类告警
            for(j = 0; j < 8; j++)
            {
                if(((p_bcu_warn[BCU_OTHER_WARN_BYTE] >> j) & 0x01) != ((g_battery_cluster_warn_info[BCU_OTHER_WARN_BYTE] >> j) & 0x01))
                {
                    //前三级告警占3个字节
                    id = BCU_WARN_START_POINT + 24 + j;
                    if ((g_battery_cluster_warn_info[BCU_OTHER_WARN_BYTE] >> j) & 0x01)
                    {
                        TCP_DEBUG_PRINT((int8_t *)"bcu fault[%d] end", id);
                        bcu_fault_data_upload(id, 0, 2, bat_cnt + 1);
                        BIT_CLR(g_battery_cluster_warn_info[BCU_OTHER_WARN_BYTE], j);
                    }
                    else
                    {
                        TCP_DEBUG_PRINT((int8_t *)"bcu fault[%d] start", id);
                        bcu_fault_data_upload(id, 1, 2, bat_cnt + 1);
                        BIT_SET(g_battery_cluster_warn_info[BCU_OTHER_WARN_BYTE], j);
                    }
                }
            }
        }

        //故障
        ret = memcmp(p_bcu_fault, &g_battery_cluster_fault_info, BATTERY_CLUSTER_FAULT_LEN_BYTE);
        if (0 != ret)
        {
            for (i = 0; i < BATTERY_CLUSTER_FAULT_LEN_BYTE; i++)
            {
                for(j = 0; j < 8; j++)
                {
                    if(((p_bcu_fault[i] >> j) & 0x01) != ((g_battery_cluster_fault_info[i] >> j) & 0x01))
                    {
                        id = BCU_FAULT_START_POINT + i * 8 + j;
                        if ((g_battery_cluster_fault_info[i] >> j) & 0x01)
                        {
                            TCP_DEBUG_PRINT((int8_t *)"bcu fault[%d] end", id);
                            bcu_fault_data_upload(id, 0, 3, bat_cnt + 1);
                            BIT_CLR(g_battery_cluster_fault_info[i], j);
                        }
                        else
                        {
                            TCP_DEBUG_PRINT((int8_t *)"bcu fault[%d] start", id);
                            bcu_fault_data_upload(id, 1, 3, bat_cnt + 1);
                            BIT_SET(g_battery_cluster_fault_info[i], j);
                        }
                    }
                }
            }
        }
    }
}


/**
 * @brief   消防故障数据上报
 * @param   [in] fault_id:故障ID
 * @param   [in] fault_status:故障状态
 * @param   [in] fault_level:故障等级
 * @note
 * @return
 */
static void fc_fault_data_upload(uint16_t fault_id, uint8_t fault_status, uint8_t fault_level)
{
    uint8_t i = 0;
    cJSON *p_root = NULL;
    cJSON *p_data = NULL;
    char *p = NULL;
    tcp_dev_info_t *p_dev_info = NULL;  
    char recv_buff[TCP_MAX_BUFF_LEN] = {0};
    int recv_len = 0;	
    uint16_t sofar_fault_id = 0;

    p_dev_info = tcp_dev_info_get();

    //获取首航云故障ID
    for(i = 0; i < FC_MAX_EVENT_ITEM; i++)
    {
        if(fault_id == g_fc_fault_id_table[i].dev_fault_id)
        {
            sofar_fault_id = g_fc_fault_id_table[i].sofar_fault_id;
            break;
        }
    }
    if(i == FC_MAX_EVENT_ITEM)
    {
        TCP_DEBUG_PRINT((int8_t *)"fault id not exit");
        return;
    }

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_data);
        return;
    }

    cJSON_AddStringToObject(p_root, "devtype", "fc");
    cJSON_AddStringToObject(p_root, "cmdtype", "event");
    cJSON_AddNumberToObject(p_root, "cmuIndex", 1);
    cJSON_AddNumberToObject(p_root, "ID", sofar_fault_id);
    cJSON_AddNumberToObject(p_root, "code", !fault_status);
    cJSON_AddNumberToObject(p_root, "level", fault_level); 
    cJSON_AddNumberToObject(p_root, "time", time(NULL));

    p = cJSON_PrintUnformatted(p_root);
    tcp_send(p_dev_info->socket_fd, p, strlen(p), recv_buff, &recv_len);
    usleep(100 * 1000);
    cJSON_Delete(p_root);
    free(p);
    
}


/**
 * @brief   消防事件数据上报
 * @note
 * @return
 */
static void tcp_fc_event_data_upload(void)
{
    int ret = 0;
    uint16_t id = 0;
    uint8_t i = 0;
    uint8_t j = 0;
    uint8_t *p_fc_warn = NULL;
    uint8_t *p_fc_fault = NULL;
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();

    p_fc_warn = &p_telematic_data->container_system_warn_info[0];
    p_fc_fault = &p_telematic_data->container_system_fault_info[0];

    ret = memcmp(p_fc_warn, &g_container_system_warn_info, CONTAINER_SYSTEM_WARN_LEN_BYTE);
    if (0 != ret)
    {
        //一级告警
        for (i = FC_WARN1_BYTE_START; i < FC_WARN1_BYTE_END; i++)
        {
            for(j = 0; j < 8; j++)
            {
                if(((p_fc_warn[i] >> j) & 0x01) != ((g_container_system_warn_info[i] >> j) & 0x01))
                {
                    id = (i - FC_WARN1_BYTE_START) * 8 + j;
                    if ((g_container_system_warn_info[i] >> j) & 0x01)
                    {
                        TCP_DEBUG_PRINT((int8_t *)"fc fault[%d] end", id);
                        fc_fault_data_upload(id, 0, 1);
                        BIT_CLR(g_container_system_warn_info[i], j);
                    }
                    else
                    {
                        TCP_DEBUG_PRINT((int8_t *)"fc fault[%d] start", id);
                        fc_fault_data_upload(id, 1, 1);
                        BIT_SET(g_container_system_warn_info[i], j);
                    }
                }
            }
        }
    }

    //故障
    ret = memcmp(p_fc_fault, &g_container_system_fault_info, CONTAINER_SYSTEM_FAULT_LEN_BYTE);
    if (0 != ret)
    {
        for (i = FC_FAULT_BYTE_START; i < CONTAINER_SYSTEM_FAULT_LEN_BYTE; i++)
        {
            for(j = 0; j < 8; j++)
            {
                if(((p_fc_fault[i] >> j) & 0x01) != ((g_container_system_fault_info[i] >> j) & 0x01))
                {
                    id = 50 + (i - FC_FAULT_BYTE_START) * 8 + j;
                    if ((g_container_system_fault_info[i] >> j) & 0x01)
                    {
                        TCP_DEBUG_PRINT((int8_t *)"fc fault[%d] end", id);
                        fc_fault_data_upload(id, 0, 3);
                        BIT_CLR(g_container_system_fault_info[i], j);
                    }
                    else
                    {
                        TCP_DEBUG_PRINT((int8_t *)"fc fault[%d] start", id);
                        fc_fault_data_upload(id, 1, 3);
                        BIT_SET(g_container_system_fault_info[i], j);
                    }
                }
            }
        }
    }
    //其他类
    //消防控制器失联
    if((BIT_GET(p_fc_warn[0], 7)) != (BIT_GET(g_container_system_warn_info[0], 7)))
    {
        id = 0;
        if ((g_container_system_warn_info[0] >> 7) & 0x01)
        {
            TCP_DEBUG_PRINT((int8_t *)"fc fault[%d] end", id);
            fc_fault_data_upload(id, 0, 1);
            BIT_CLR(g_container_system_warn_info[0], 7);
        }
        else
        {
            TCP_DEBUG_PRINT((int8_t *)"fc fault[%d] start", id);
            fc_fault_data_upload(id, 1, 1);
            BIT_SET(g_container_system_warn_info[0], 7);
        }
    }
}


/**
 * @brief   液冷故障数据上报
 * @param   [in] fault_id:故障ID
 * @param   [in] fault_status:故障状态
 * @param   [in] fault_level:故障等级
 * @note
 * @return
 */
static void lc_fault_data_upload(uint16_t fault_id, uint8_t fault_status, uint8_t fault_level)
{
    uint8_t i = 0;
    cJSON *p_root = NULL;
    cJSON *p_data = NULL;
    char *p = NULL;
    tcp_dev_info_t *p_dev_info = NULL;  
    char recv_buff[TCP_MAX_BUFF_LEN] = {0};
    int recv_len = 0;	
    uint16_t sofar_fault_id = 0;

    p_dev_info = tcp_dev_info_get();

    //获取首航云故障ID
    for(i = 0; i < LC_MAX_EVENT_ITEM; i++)
    {
        if(fault_id == g_lc_fault_id_table[i].dev_fault_id)
        {
            sofar_fault_id = g_lc_fault_id_table[i].sofar_fault_id;
            break;
        }
    }
    if(i == LC_MAX_EVENT_ITEM)
    {
        TCP_DEBUG_PRINT((int8_t *)"fault id not exit");
        return;
    }

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_data);
        return;
    }

    cJSON_AddStringToObject(p_root, "devtype", "lc");
    cJSON_AddStringToObject(p_root, "cmdtype", "event");
    cJSON_AddNumberToObject(p_root, "cmuIndex", 1);
    cJSON_AddNumberToObject(p_root, "ID", sofar_fault_id);
    cJSON_AddNumberToObject(p_root, "code", !fault_status);
    cJSON_AddNumberToObject(p_root, "level", fault_level); 
    cJSON_AddNumberToObject(p_root, "time", time(NULL));

    p = cJSON_PrintUnformatted(p_root);
    tcp_send(p_dev_info->socket_fd, p, strlen(p), recv_buff, &recv_len);
    usleep(100 * 1000);
    cJSON_Delete(p_root);
    free(p);
    
}



/**
 * @brief   液冷事件数据上报
 * @note
 * @return
 */
static void tcp_lc_event_data_upload(void)
{
    int ret = 0;
    uint16_t id = 0;
    uint8_t i = 0;
    uint8_t j = 0;
    uint8_t *p_lc_warn = NULL;
    uint8_t *p_lc_fault = NULL;
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();

    p_lc_warn = &p_telematic_data->container_system_warn_info[0];
    p_lc_fault = &p_telematic_data->container_system_fault_info[0];

    ret = memcmp(p_lc_warn, &g_container_system_warn_info, CONTAINER_SYSTEM_WARN_LEN_BYTE);
    if (0 != ret)
    {
        //一级告警
        for (i = LC_WARN1_BYTE_START; i < LC_WARN1_BYTE_END; i++)
        {
            for(j = 0; j < 8; j++)
            {
                if(((p_lc_warn[i] >> j) & 0x01) != ((g_container_system_warn_info[i] >> j) & 0x01))
                {
                    id = 50 + (i - LC_WARN1_BYTE_START) * 8 + j;
                    if ((g_container_system_warn_info[i] >> j) & 0x01)
                    {
                        TCP_DEBUG_PRINT((int8_t *)"lc fault[%d] end", id);
                        lc_fault_data_upload(id, 0, 1);
                        BIT_CLR(g_container_system_warn_info[i], j);
                    }
                    else
                    {
                        TCP_DEBUG_PRINT((int8_t *)"lc fault[%d] start", id);
                        lc_fault_data_upload(id, 1, 1);
                        BIT_SET(g_container_system_warn_info[i], j);
                    }
                }
            }
        }
    }
    ret = memcmp(p_lc_fault, &g_container_system_fault_info, CONTAINER_SYSTEM_FAULT_LEN_BYTE);
    if (0 != ret)
    {
        //三级故障
        for (i = LC_FAULT_BYTE_START; i < LC_FAULT_BYTE_END; i++)
        {
            for(j = 0; j < 8; j++)
            {
                if(((p_lc_fault[i] >> j) & 0x01) != ((g_container_system_fault_info[i] >> j) & 0x01))
                {
                    id = (i - LC_FAULT_BYTE_START) * 8 + j;
                    if ((g_container_system_fault_info[i] >> j) & 0x01)
                    {
                        TCP_DEBUG_PRINT((int8_t *)"lc fault[%d] end", id);
                        lc_fault_data_upload(id, 0, 3);
                        BIT_CLR(g_container_system_fault_info[i], j);
                    }
                    else
                    {
                        TCP_DEBUG_PRINT((int8_t *)"lc fault[%d] start", id);
                        lc_fault_data_upload(id, 1, 3);
                        BIT_SET(g_container_system_fault_info[i], j);
                    }
                }
            }
        }
    }
}


/**
 * @brief   属性&事件即时上报服务初始化
 * @param   [in] arg
 * @note
 * @return
 */
void *tcp_real_time_data_upload_service(void *arg)
{
    tcp_dev_info_t *p_dev_info = NULL;

    p_dev_info = tcp_dev_info_get();
	while(1)
	{
        if(p_dev_info->tcp_connect_status == CONNECT)
        {
            //属性
            tcp_cmu_property_data_upload();
            tcp_pcs_property_data_upload();
            tcp_bat_stack_property_data_upload();
            tcp_bcu_property_data_upload();
            tcp_fc_property_data_upload();
            tcp_lc_property_data_upload();
            //事件
            tcp_pcs_event_data_upload();
            tcp_bcu_event_data_upload();
            tcp_fc_event_data_upload();
            tcp_lc_event_data_upload();
        }
        sleep(1);
	}
}



/**
 * @brief   属性&事件即时上报模块初始化
 * @param
 * @note
 * @return
 */
void tcp_real_time_monitor_module_init(void)
{
	pthread_t realtime_time_monitor;
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	if(pthread_create(&realtime_time_monitor, &attr, tcp_real_time_data_upload_service, NULL) != 0)
	{
		perror("pthread_create tcp server service");
	}
	pthread_attr_destroy(&attr);
}