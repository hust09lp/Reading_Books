#ifndef __REAL_TIME_DATA_MODULE_H__
#define __REAL_TIME_DATA_MODULE_H__

#include "sdk_log.h"

#define PROPERTY_UPLOAD_TIME_INTERVAL  (2 * 60)       //2分钟上报一次属性数据

#define SN_MAX_LEN              32
#define VERSION_MAX_LEN         32

#define PCS_MAX_EVENT_ITEM      61
#define PCSMODULE_CLUSTER_FAULT_START_POINT	0x801
#define PCSMODULE_CLUSTER_FAULT_END_POINT	0x8F0
#define GRID_FAULT_START_POINT	        0
#define SAMPLING_FAULT_START_POINT	    16
#define SELF_TEST_FAULT_START_POINT	    32
#define TEMP_FAULT_START_POINT	        48
#define VOLT_FAULT_START_POINT	        64
#define CURRENT_FAULT_START_POINT	    80
#define HWSIGNAL_FAULT_START_POINT	    96
#define CONTROL_FAULT_START_POINT	    112
#define COMM_FAULT_START_POINT	        128
#define SUPPLEEMENT_FAULT_START_POINT	144  
#define DEVICE_FAULT_START_POINT	    160
#define WARN_FAULT_START_POINT	        176
#define STATE6_FAULT_START_POINT        192

#define BMS_MAX_EVENT_ITEM      29
//一级起始
#define BCU_WARN1_BYTE_START    0
#define BCU_WARN1_BYTE_END      2
//二级起始
#define BCU_WARN2_BYTE_START    3
#define BCU_WARN2_BYTE_END      5
//三级起始
#define BCU_WARN3_BYTE_START    6
#define BCU_WARN3_BYTE_END      8
//其他类起始
#define BCU_OTHER_WARN_BYTE     9

#define BCU_WARN_START_POINT	1
#define BCU_FAULT_START_POINT	27

#define FC_MAX_EVENT_ITEM      50
//消防告警点位
#define FC_WARN1_BYTE_START    10
#define FC_WARN1_BYTE_END      15
//消防故障点位
#define FC_FAULT_BYTE_START    11
#define FC_FAULT_BYTE_END      14

#define LC_MAX_EVENT_ITEM      60
//液冷告警点位
#define LC_WARN1_BYTE_START    2
#define LC_WARN1_BYTE_END      9
//液冷故障点位
#define LC_FAULT_BYTE_START    3
#define LC_FAULT_BYTE_END      10

#define PCS_DEV_TYPE            1
#define PCS_RATED_POWER         125
typedef struct{
    char pcs_sn[SN_MAX_LEN];                    //pcs序列号
    char pcs_model[SN_MAX_LEN];                 //pcs型号
    char mdsp_version[VERSION_MAX_LEN];         //主DSP版本号
    char ldsp_version[VERSION_MAX_LEN];         //副DSP版本号
    uint16_t dev_type;                          //设备类型
    uint16_t rated_power;                       //额定功率
    uint8_t comm_status;                        //通讯状态
    uint8_t sys_status;                         //系统状态
    uint16_t rated_voltage;                     //额定电网电压
}pcs_property_data_t;                           //pcs属性数据


typedef struct{
    char bms_sn[SN_MAX_LEN];                    //bms序列号
    uint16_t cell_num;                          //电芯数量
    uint8_t comm_status;                        //通讯状态
    uint8_t work_status;                        //工作状态
    uint8_t char_prohibit;                      //禁充状态
    uint8_t dischar_prohibit;                   //禁充状态
    uint8_t main_pos_relay;                     //主正继电器状态
    uint8_t main_nega_relay;                    //主负继电器状态
}bms_property_data_t;                           //电池簇属性数据

typedef struct{
    char bat_stack_sn[SN_MAX_LEN];              //电池堆序列号
    uint8_t comm_status;                        //通讯状态
    uint8_t work_status;                        //工作状态
    uint8_t char_prohibit;                      //禁充状态
    uint8_t dischar_prohibit;                   //禁充状态
    uint8_t bcu_num;                            //电池堆内电池簇数量
    uint8_t pack_num;                           //电池簇内PACK数量
    uint8_t cell_num;                           //PACK内电芯数量
}bat_stack_property_data_t;                     //电池堆属性数据

typedef struct{
    char fc_sn[SN_MAX_LEN];                     //消防序列号
    uint8_t dev_type;                           //设备类型
    uint8_t comm_status;                        //通讯状态
    uint8_t work_status;                        //消防状态
    uint8_t sd_status;                          //烟感状态
    uint8_t td_status;                          //温感状态
}fc_property_data_t;                            //消防属性数据


typedef struct{
    char lc_sn[SN_MAX_LEN];                     //液冷序列号
    uint8_t dev_type;                           //设备类型
    uint8_t comm_status;                        //通讯状态
    uint8_t work_status;                        //运行状态
    uint8_t work_mode;                          //运行模式
    uint8_t warn_status;                        //告警状态
    uint8_t wp_status;                          //水泵状态
    uint8_t cp_status;                          //压缩机状态
    uint8_t eh_status;                          //电加热状态
    uint8_t fan_status;                         //风机状态
}lc_property_data_t;                            //液冷属性数据


typedef struct{
    char cmu_sn[SN_MAX_LEN];
    char version[VERSION_MAX_LEN];
    uint16_t safe_version;
    uint8_t comm_status;
    uint8_t run_status;
}cmu_property_data_t;                    //cmu属性数据

/**
 * @brief   属性&事件即时上报模块初始化
 * @param
 * @note
 * @return
 */
void tcp_real_time_monitor_module_init(void);

#endif