#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include "data_shm.h"
#include "sdk_shm.h"
#include "errors.h"
#include "sofar_log.h"
#include "cJSON.h"
#include "sofar_service.h"
#include "sofar_ota.h"


#define MCU1_UPDATE         (0)
#define MCU1_APP_UPDATE     (1)
#define MCU1_CORE_UPDATE    (2)
#define MCU2_UPDATE         (3)
#define MCU2_APP_UPDATE     (4)
#define MCU2_CORE_UPDATE    (5)
#define PCS_UPDATE          (6)
#define DSPM_UPDATE         (7)
#define DSPS_UPDATE         (8)

#define MCU1_APP_INDEX      (0)
#define MCU1_CORE_INDEX     (1)
#define MCU2_APP_INDEX      (2)
#define MCU2_CORE_INDEX     (3)
#define DSPM_INDEX          (4)
#define DSPS_INDEX          (5)

typedef enum
{
    ALMIGHTY_NUM = 0x00,    // 不查询编码
    PCS_M_NUM = 0x22,
    PCS_S_NUM = 0x23,
    CSU_MCU1_NUM = 0x33,
    CSU_MCU2_NUM = 0x34,
    CMU_MCU1_NUM = 0x3b,
    CMU_MCU2_NUM = 0x3c,
} obj_num_e;

typedef enum
{
    FILE_APP_NUM = 0x00,
    FILE_CORE_NUM = 0x01,
    FILE_KERNEL_NUM,
    FILE_ROOTFS_NUM,
    FILE_SAFETY_NUM,
    FILE_PACK_NUM = 0x80,
} file_type_num_e;

/**
 * @brief   升级数据上报
 * @note
 * @return
 */
static void tcp_ota_percent_upload(void)
{
    cJSON *p_root = NULL;
    cJSON *p_data = NULL;
    char *p = NULL;
    tcp_dev_info_t *p_dev_info = NULL;  
    char recv_buff[TCP_MAX_BUFF_LEN] = {0};
    int recv_len = 0;	
    uint8_t upload_flag[8];
    
    firmware_update_t *p_update = sdk_shm_firmware_update_info_get();

    //检测是否存在升级
    if(p_update->state != UPDATING)
    {
        return;
    }
    p_dev_info = tcp_dev_info_get();
    p_data = cJSON_CreateObject();
    if(p_data == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }
    memset(upload_flag,0,sizeof(upload_flag));
    TCP_DEBUG_PRINT((int8_t *)"*******************************************");
    for (uint8_t i = 0; i < UPDATE_OBJECT_NUM; i++)
    {
        //MCU1-APP
        if((p_update->chip_role[i] == CMU_MCU1_NUM) && (p_update->file_type[i] == FILE_APP_NUM))
        {
            TCP_DEBUG_PRINT((int8_t *)"cmu-mcu1 app module_percent[%d] %d", i, p_update->module_percent[i]);
            cJSON_AddNumberToObject(p_data, "mcu1_app", p_update->module_percent[i]);
            upload_flag[MCU1_APP_INDEX] = 1;
        }
        //MCU1-CORE
        if((p_update->chip_role[i] == CMU_MCU1_NUM) && (p_update->file_type[i] == FILE_CORE_NUM))
        {
            TCP_DEBUG_PRINT((int8_t *)"cmu-mcu1 core module_percent[%d] %d", i, p_update->module_percent[i]);
            cJSON_AddNumberToObject(p_data, "mcu1_core", p_update->module_percent[i]);
            upload_flag[MCU1_CORE_INDEX] = 1;
        }
        //MCU2-APP
        if((p_update->chip_role[i] == CMU_MCU2_NUM) && (p_update->file_type[i] == FILE_APP_NUM))
        {
            TCP_DEBUG_PRINT((int8_t *)"cmu-mcu2 app module_percent[%d] %d", i, p_update->module_percent[i]);
            cJSON_AddNumberToObject(p_data, "mcu2_app", p_update->module_percent[i]);
            upload_flag[MCU2_APP_INDEX] = 1;
        }
        //MCU2-CORE
        if((p_update->chip_role[i] == CMU_MCU2_NUM) && (p_update->file_type[i] == FILE_CORE_NUM))
        {
            TCP_DEBUG_PRINT((int8_t *)"cmu-mcu2 core module_percent[%d] %d", i, p_update->module_percent[i]);
            cJSON_AddNumberToObject(p_data, "mcu2_core", p_update->module_percent[i]);
            upload_flag[MCU2_CORE_INDEX] = 1;
        }
        //PCS_M
        if (p_update->chip_role[i] == PCS_M_NUM)
        {
            TCP_DEBUG_PRINT((int8_t *)"pcs master module_percent[%d] %d", i, p_update->module_percent[i]);
            cJSON_AddNumberToObject(p_data, "pcs_m", p_update->module_percent[i]);
            upload_flag[DSPM_INDEX] = 1;
        }
        //PCS_S
        if (p_update->chip_role[i] == PCS_S_NUM)
        {
            TCP_DEBUG_PRINT((int8_t *)"pcs slave module_percent[%d] %d", i, p_update->module_percent[i]);
            cJSON_AddNumberToObject(p_data, "pcs_s", p_update->module_percent[i]);
            upload_flag[DSPS_INDEX] = 1;
        }
    }	
    if((BIT_GET(p_update->module_update_flag,MCU1_UPDATE) == 1) && (upload_flag[MCU1_APP_INDEX] == 0))
    {
        cJSON_AddNumberToObject(p_data, "mcu1_app", -1);
    }
    if((BIT_GET(p_update->module_update_flag,MCU1_UPDATE) == 1) && (upload_flag[MCU1_CORE_INDEX] == 0))
    {
        cJSON_AddNumberToObject(p_data, "mcu1_core", -1);
    }
    if((BIT_GET(p_update->module_update_flag,MCU2_UPDATE) == 1) && (upload_flag[MCU2_APP_INDEX] == 0))
    {
        cJSON_AddNumberToObject(p_data, "mcu2_app", -1);
    }
    if((BIT_GET(p_update->module_update_flag,MCU2_UPDATE) == 1) && (upload_flag[MCU2_CORE_INDEX] == 0))
    {
        cJSON_AddNumberToObject(p_data, "mcu2_core", -1);
    }
    if((BIT_GET(p_update->module_update_flag,DSPM_UPDATE) == 1) && (upload_flag[DSPM_INDEX] == 0))
    {
        cJSON_AddNumberToObject(p_data, "pcs_m", -1);
    }
    if((BIT_GET(p_update->module_update_flag,DSPS_UPDATE) == 1) && (upload_flag[DSPS_INDEX] == 0))
    {
        cJSON_AddNumberToObject(p_data, "pcs_s", -1);
    }
    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_data);
        return;
    }

    cJSON_AddStringToObject(p_root, "devtype", "cmu");
    cJSON_AddStringToObject(p_root, "cmdtype", "ota");
    cJSON_AddNumberToObject(p_root, "cmuIndex", 1);
    cJSON_AddItemToObject(p_root, "data", p_data);
    p = cJSON_PrintUnformatted(p_root);
    tcp_send(p_dev_info->socket_fd, p, strlen(p), recv_buff, &recv_len);
    // usleep(200 * 1000);
    cJSON_Delete(p_root);
    free(p);
}



/**
 * @brief   升级进度上报服务初始化
 * @param   [in] arg
 * @note
 * @return
 */
void *tcp_ota_progress_service(void *arg)
{
    tcp_dev_info_t *p_dev_info = NULL;

    p_dev_info = tcp_dev_info_get();
	while(1)
	{
        if(p_dev_info->tcp_connect_status == CONNECT)
        {
            tcp_ota_percent_upload();
        }
        usleep(1000 * 2000);
	}
}


/**
 * @brief   首航云升级模块初始化
 * @param
 * @note
 * @return
 */
void sofar_ota_module_init(void)
{
	pthread_t realtime_time_monitor;
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	if(pthread_create(&realtime_time_monitor, &attr, tcp_ota_progress_service, NULL) != 0)
	{
		perror("pthread_create tcp server service");
	}
	pthread_attr_destroy(&attr);
}