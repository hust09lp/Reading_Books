#ifndef __SOFAR_OTA_H__
#define __SOFAR_OTA_H__
  

/**
 * @brief   首航云升级模块初始化
 * @param
 * @note
 * @return
 */
void sofar_ota_module_init(void);

#endif