#ifndef __PERIPHERAL_DEV_TEST__
#define __PERIPHERAL_DEV_TEST__
#include<stdint.h>

#define RS485_DEV_1 2
#define RS485_DEV_2 3
#define CAN1_PORT 0
#define CAN2_PORT 1

#define print_log(format,argc...){ \
	printf("%s[%s:%d]=>",__FILE__,__func__,__LINE__); \
	printf(format,##argc); \
	printf("\n"); \
}
typedef union{
    uint32_t id_val;
    struct{
        uint32_t src_addr:  8;  // source address
        uint32_t dst_addr:  8;  // destination address
        uint32_t fun_code:  8;  // < CAN Frame function code
        uint32_t data_page: 1;  // < CAN Frame Data Page
        uint32_t rsvd:      1;  // < Reserved.
        uint32_t prio:      3;  // < CAN Frame fun_code priority
        uint32_t reserved:  2;  // < Reserved. 
        uint32_t flag:      1;  // 0-standard frame  1-extended frame
    }bit;
}can_frame_id_u;

uint8_t test_rs485(const uint8_t index);
uint8_t test_can(const uint8_t index);
uint8_t test_tfcard();
void test_do_set_value(const uint8_t gpio_num, uint8_t io_lv );
void test_do_value(const uint8_t gpio_num);
uint8_t test_di_value(const uint8_t gpio_num);
uint8_t test_net2();
uint8_t test_usb(void);
#endif