#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<sys/ioctl.h>
#include<net/if.h>
#include<string.h>
#include<fcntl.h>
#include<linux/can.h>
#include<linux/can/error.h>
#include<linux/can/raw.h>
#include<linux/rtc.h>
#include"peripheral_dev_test.h"
#include"sdk_uart.h"
#include"sdk_can.h"

#define USB_SDA1 "/media/sda1"
#define USB_SDB1 "/media/sdb1"
#define USB_SDC1 "/media/sdc1"
#define USB_SDD1 "/media/sdd1"

#define BUFF_LEN 128
sdk_uart_conf_t g_arrt = {UART_BAUD_RATE_9600, UART_DATA_BITS_8, UART_STOP_BITS_1, UART_PARITY_NONE, UART_HWFLOW_OFF};

uint8_t test_rs485(const uint8_t index)
{
    uint8_t *p1 = "TEST--UART--111";
    uint8_t *p2 = "TEST--UART--222";
    uint8_t buff[BUFF_LEN];
    uint8_t rs4851_ok, rs4852_ok;

    if(rs4851_ok && (index == 1))
    {
        return 1;
    }
    if(rs4852_ok && (index == 2))
    {
        return 1;
    }

    rs4851_ok = rs4852_ok = 0;
    sdk_uart_open(RS485_DEV_1); //打开第一路RS485对应的UART
    sdk_uart_setup(RS485_DEV_1, &g_arrt); //115200N8
    sdk_uart_open(RS485_DEV_2); //打开第二路RS485对应的UART
    sdk_uart_setup(RS485_DEV_2, &g_arrt); //115200N8
    
    memset(buff, 0, BUFF_LEN);
    sdk_uart_write(RS485_DEV_1, p1, strlen(p1));
    usleep(200 * 1000);
    sdk_uart_read(RS485_DEV_2, buff, BUFF_LEN, 1500);

    if(memcmp(buff, p1, strlen(p1)) != 0)
    {
        print_log("rs4851 test failed.");
        sdk_uart_close(RS485_DEV_1);
        sdk_uart_close(RS485_DEV_2);
        rs4851_ok = rs4852_ok = 0; 
        return 0;
    }

    memset(buff, 0, BUFF_LEN);
    sdk_uart_write(RS485_DEV_2, p2, strlen(p2));
    usleep(200 * 1000);
    sdk_uart_read(RS485_DEV_1, buff, BUFF_LEN, 1500);

    if(memcmp(buff, p2, strlen(p2)) != 0)
    {
        print_log("rs4852 test failed.");
        sdk_uart_close(RS485_DEV_1);
        sdk_uart_close(RS485_DEV_2);
        rs4851_ok = 0;
        rs4852_ok = 0; 
        return 0;
    }
    sdk_uart_close(RS485_DEV_1);
    sdk_uart_close(RS485_DEV_2);
    rs4851_ok = 1;
    rs4852_ok = 1; 
    return 1;
}

uint8_t test_can(const uint8_t index)
{
    uint8_t buff1[BUFF_LEN] = {'T', 'E', 'S', 'T', 'C', 'A', 'N', '1'};
    uint8_t buff2[BUFF_LEN] = {'T', 'E', 'S', 'T', 'C', 'A', 'N', '2'};
    sdk_can_frame_t frame_recv;
    sdk_can_frame_t frame_sned;
    can_frame_id_u can_frame_id;
    sdk_can_cfg_t conf;
    uint8_t i;
    uint8_t can1_ok, can2_ok;

    can_frame_id.bit.src_addr = 0xF4;
    can_frame_id.bit.dst_addr = 0xE8;
    can_frame_id.bit.fun_code = 0x30;
    can_frame_id.bit.prio = 6;
    can_frame_id.bit.flag = 1;

    frame_sned.id = can_frame_id.id_val;
    frame_sned.len = 8;
    conf.mode = 0;
    conf.baud = 250000;  //250K

    can1_ok = can2_ok = 0;
    sdk_can_open(CAN1_PORT);
    sdk_can_setup(CAN1_PORT, &conf);
    sdk_can_open(CAN2_PORT);
    sdk_can_setup(CAN2_PORT, &conf);

    for(i=0; i<8; i++)
    {
        frame_sned.data[i] = buff1[i];
    }
   
    sdk_can_write(CAN1_PORT, &frame_sned, 1);
    usleep(200 * 1000);
    sdk_can_read(CAN2_PORT ,&frame_recv, 1, 1500);
    for(i=0; i<8; i++)
    {
        printf("%c\t", frame_recv.data[i]);
    }
    printf("\n");
    for(i=0; i<8; i++)
    {
        if(frame_recv.data[i] != buff1[i])
        {
            print_log("can data %d error", i);
            sdk_can_close(CAN1_PORT);
            sdk_can_close(CAN2_PORT);
            can1_ok = can2_ok = 0; 
            return 0;
        }
    }


    for(i=0; i<8; i++)
    {
        frame_sned.data[i] = buff2[i];
    }
 
    sdk_can_write(CAN2_PORT, &frame_sned, 1);
    usleep(200 * 1000);
    sdk_can_read(CAN1_PORT ,&frame_recv, 1, 1500);
    for(i=0; i<8; i++)
    {
        printf("%c\t", frame_recv.data[i]);
    }
    printf("\n");

    for(i=0; i<8; i++)
    {
        if(frame_recv.data[i] != buff2[i])
        {
            print_log("can data %d error", i);
            sdk_can_close(CAN1_PORT);
            sdk_can_close(CAN2_PORT);
            can1_ok = 0;
            can2_ok = 0; 
            return 0;
        }
    }

    sdk_can_close(CAN1_PORT);
    sdk_can_close(CAN2_PORT);
    can1_ok = 1;
    can2_ok = 1; 
    return 1;
}

uint8_t test_tfcard()
{
	uint8_t line[128];
	FILE *fp;
	uint8_t mounted = 0;

    if(access("/dev/mmcblk0",F_OK) != 0 ||
		access("/dev/mmcblk0p1",F_OK) != 0)  //设备不存在
	{
	    print_log("no sd card found");
        return 0;
    }

    fp = popen("df", "r");  //查看挂载情况
	if(fp == NULL)
	{
		print_log("call popen failed");
        return 0;
	}
	while (fgets(line, sizeof(line), fp))
	{
		if(strstr(line, "/media/mmcblk0p1"))
		{
			mounted = 1;
			break;
		}
	}
    pclose(fp);
	if(mounted == 0)
	{
		print_log("sd not mounted");
        return 0;
	}

    system("touch /media/mmcblk0p1/test");  //测试读写情况
	if(access("/media/mmcblk0p1/test",F_OK) != 0)
	{
		print_log("sd can not rw");
		return 0;
	}
	system("rm -f /media/dev/mmcblk0p1/test");
	return 1;
}

void test_do_set_value(const uint8_t gpio_num, uint8_t io_lv )
{
    uint8_t gpio_path[BUFF_LEN] = {0};
    uint8_t cmd[BUFF_LEN] = {0};

    if ( io_lv >= 2 )
    {
        return;
    }

    snprintf(gpio_path, BUFF_LEN, "/sys/class/gpio/gpio%d", gpio_num);
    if(access(gpio_path, F_OK) != 0)  //该GPIO还没有导出
    {
        snprintf(cmd, BUFF_LEN, "echo %d > /sys/class/gpio/export", gpio_num);
        system(cmd);
    }
    if(access(gpio_path, F_OK) != 0)
    {
        print_log("gpio %d export failed", gpio_num);
        return ;
    }
    snprintf(cmd, BUFF_LEN, "echo out > /sys/class/gpio/gpio%d/direction", gpio_num);
    system(cmd);
    snprintf(cmd, BUFF_LEN, "echo %d > /sys/class/gpio/gpio%d/value", io_lv, gpio_num );
    system(cmd);
}

void test_do_value(const uint8_t gpio_num)
{
    uint8_t gpio_path[BUFF_LEN] = {0};
    uint8_t cmd[BUFF_LEN] = {0};

    snprintf(gpio_path, BUFF_LEN, "/sys/class/gpio/gpio%d", gpio_num);
    if(access(gpio_path, F_OK) != 0)  //该GPIO还没有导出
    {
        snprintf(cmd, BUFF_LEN, "echo %d > /sys/class/gpio/export", gpio_num);
        system(cmd);
    }
    if(access(gpio_path, F_OK) != 0)
    {
        print_log("gpio %d export failed", gpio_num);
        return ;
    }
    snprintf(cmd, BUFF_LEN, "echo out > /sys/class/gpio/gpio%d/direction", gpio_num);
    system(cmd);
    snprintf(cmd, BUFF_LEN, "echo 1 > /sys/class/gpio/gpio%d/value", gpio_num);
    system(cmd);
}

uint8_t test_di_value(const uint8_t gpio_num)
{
    int32_t fd;
    uint8_t gpio_path[BUFF_LEN] = {0};
    uint8_t cmd[BUFF_LEN] = {0};
    uint8_t value[4] = {0};
    uint8_t gpio_value_path[BUFF_LEN] = {0};

    snprintf(gpio_path, BUFF_LEN, "/sys/class/gpio/gpio%d", gpio_num);
    if(access(gpio_path, F_OK) != 0)  //该GPIO还没有导出
    {
        snprintf(cmd, BUFF_LEN, "echo %d > /sys/class/gpio/export", gpio_num);
        system(cmd);
    }
    if(access(gpio_path, F_OK) != 0)
    {
        print_log("gpio %d export failed", gpio_num);
        return 0;
    }
    snprintf(cmd, BUFF_LEN, "echo in > /sys/class/gpio/gpio%d/direction", gpio_num);
    system(cmd);
    
    snprintf(gpio_value_path, BUFF_LEN, "/sys/class/gpio/gpio%d/value", gpio_num);

    fd = open(gpio_value_path, O_RDWR);
	if(fd < 0)
	{
		print_log("open %s failed", gpio_value_path);
		return 0;
	}
	read(fd, value, 4);  
	close(fd);
	return atoi(value);
}

uint8_t test_net2()
{
    char *strCmd = "ping 192.168.2.120 -w 1";
    char buf[256] = {0};
    FILE *pf = NULL;

    if ((pf = popen(strCmd, "r")) == NULL)
    {
        print_log("popen %s failed", strCmd);
        return 0;
    }

    while (fgets(buf, sizeof(buf), pf))
    {
        printf("+++++++++++++++ %s\n", buf);
        if (strstr(buf, "64 bytes from") != NULL)
        {
            pclose(pf);
            return 1;
        }
    }
    pclose(pf);
    return 0;
}

static bool is_usb_inserted(uint8_t *dir)  //当USB存储设备插入之后,会自动挂载在/media下面
{
    if((access(USB_SDA1,F_OK) != 0) &&
        (access(USB_SDB1,F_OK) != 0) &&
        (access(USB_SDC1,F_OK) != 0) &&
        (access(USB_SDD1,F_OK) != 0)
    )
	{
        return false;
    }

    if(access(USB_SDA1,F_OK) == 0) //   /media/sda1
    {
       strcpy(dir,USB_SDA1);
    }
    else if(access(USB_SDB1,F_OK) == 0)  // /media/sdb1
    {
        strcpy(dir,USB_SDB1);
    }
    else if(access(USB_SDC1,F_OK) == 0)  // /media/sdc1
    {
        strcpy(dir,USB_SDC1);
    }
    else if(access(USB_SDD1,F_OK) == 0)  // /media/sdd1
    {
        strcpy(dir,USB_SDD1);
    }
    return true;
}

uint8_t test_usb(void)
{
	uint8_t file_path[BUFF_LEN] = {0};
	FILE *fp;
	uint8_t mounted = 0;
    int8_t dir[32];
    uint8_t cmd[BUFF_LEN] = {0};

    // 当USB存储设备插入之后,会自动挂载在/media下面
    if(is_usb_inserted(dir) == false)
    {
        print_log("no usb found");
		return 0;
    }

    snprintf(file_path, BUFF_LEN, "%s/test", dir);
    snprintf(cmd, BUFF_LEN, "touch %s/test", dir);
    system(cmd);  // 测试读写情况
	if(access(file_path, F_OK) != 0)
	{
		print_log("usb not rw");
		return 0;
	}

    memset(cmd, 0, BUFF_LEN);
    snprintf(cmd, BUFF_LEN, "rm -f %s/test", dir);
	system(cmd);
	return 1;
}