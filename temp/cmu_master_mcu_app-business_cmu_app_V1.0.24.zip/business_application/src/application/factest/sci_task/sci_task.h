/*****************************************************************************
* File Name			: sci_task.h			
* Description		: 	
* Original Author	: 
* date				: 
******************************************************************************/
#ifndef __SCI_TASK_H__
#define __SCI_TASK_H__

#include <pthread.h>
#include "data_types.h"
#include "sdk_log.h"
#include "sofar_type.h"

// 从机地址
#define DEV_ADDR_CONTAINER              (0x01)          // 集装箱设备地址

// SCI串口端号
#define SDK_UART2			            (1)				// 串口端号

// 版本信息
#define SOFTVER_SIZE                    (4)             // 软件版本大小
#define HARDVER_SIZE                    (2)             // 硬件版本大小

// 消防版本信息
#define FF_SOFTVER_SIZE                 (2)             // 软件版本大小

// 协议版本号
#define SCI_PROTOCOL_SYMBOL             'V'
#define SCI_VERTION1                    (0x01)          // SCI协议版本号数值

// 命令码
#define FUNCID_HANDSHAKED               (0x1000)        /* 上电握手 */
#define FUNCID_GET_REALTIME_DATA        (0x2000)        /* 获取实时数据 */
// #define FUNCID_SEND_THRESHOLD_INFO   (0x3000)        /* 下发动作阈值 */

// 通讯监控
#define UART_INIT_RETRYCNT              (3)             // 串口初始化失败重试次数
#define CMD_RETRYCNT_MAX                (3)             // 命令重发次数max
#define COMMBREAKCNT_MAX                (60)           // 通讯异常报中断的累计次数
#define SENDERR_CNT_MAX                 (50)            // 100ms * 50 = 5s，持续异常5s发送失败

// 收发缓存
#define SCI_BUF_SIZE		            (255)           // 收发缓存区大小
#define DATA_SIZE_MAX                   (245)           // 收发缓存区数据段max
#define INDEX_DATA_HOST                 (7)             // 主机数据索引
#define INDEX_DATA_SLAVE                (6)             // 从机数据索引

// 定时除湿
#define DEHUM_ON_HOUR_SET               (8)             // 开启除湿时间——小时（0~23）
#define DEHUM_ON_MINUTE_SET             (0)             // 开启除湿时间——分钟（0~59）

#define FUNCID_FACTEST_ENTER        0x4010  // 进入CMU产测模式
#define FUNCID_FACTEST_START        0x4020  // 开始CMU单项产测
#define FUNCID_FACTEST_VERSION      0x4021  // 读取MCU2版本号和消防瓶组气压
#define FUNCID_FACTEST_GET_DAT      0x4021  // 读取数据
#define FUNCID_FACTEST_SET_DAT      0x4022  // 写入数据
#define FUNCID_FACTEST_LEAVE        0x4030  // 退出CMU产测模式
uint8_t g_muc2_version[4];
uint8_t pressure[4];
#if (1)
#define SCI_DEBUG_LOG(...) log_i(__VA_ARGS__);
#else
#define SCI_DEBUG_LOG(...) {do {} while(0);}
#endif

/**************************************************************************
*   All Structures and Common Constants
**************************************************************************/
#pragma pack(push)
#pragma pack(1)
typedef union
{
    float32_t data;
    struct
    {
        uint16_t low;
        uint16_t high;
    }apart;
    
}quad_bytes_u;
#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)
/* 版本信息-接收 */
typedef struct{

    uint8_t mcu2_app_soft_version[SOFTVER_SIZE];        // mcu2 app层软件版本号 1ASCII码 + 3数值
    uint8_t mcu2_core_soft_version[SOFTVER_SIZE];       // mcu2 core层软件版本号 1ASCII码 + 3数值
    uint8_t mcu2_hardware_version[HARDVER_SIZE];        // mcu2 硬件版本号 2数值
    uint8_t mcu2_sci_version;                           // mcu2 sci协议版本号 1数值
    uint8_t ff_software_version[FF_SOFTVER_SIZE];       // 消防软件版本号 数值
}sci_handack_t;
#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)
/* 通讯数据 */
typedef struct 
{
    uint16_t factory_enter;
    uint16_t factory_rs485;
    uint16_t factory_can;
    uint16_t factory_di;
    uint16_t factory_do;
    uint16_t factory_leave;
}sci_localbuf_t;
#pragma pack(pop)


// 时间结构体
#pragma pack(push)
#pragma pack(1)
typedef struct
{
    int16_t year;	// 年份，如2023
    int16_t month;	// 月份，1~12
    int16_t date;	// 日期，1~31
	int16_t hour;	// 小时，0~23
    int16_t minute;
	int16_t second;
}sci_time_t;
#pragma pack(pop)

/* 通讯阶段 */
typedef enum{

    STAGE_SHAKE_HAND = 0,           // 上电握手 
    STAGE_SEND_PARA_LC,             // 下发定值参数-液冷系统
    STAGE_SEND_TELECOMMAND,         // 下发遥控信息
    STAGE_SEND_PARA_CONTAINER,      // 下发定值参数-集装箱系统
    STAGE_SEND_PARA_LOGIC_LC,       // 下发定值参数-液冷逻辑
    STAGE_SEND_PARA_FIRE,           // 下发定值参数-消防
    STAGE_GET_REALTIMEDATA,         // 获取实时数据
    STAGE_OTHER,                    // 其他阶段
    STAGE_MAX,                      // 最大范围

}sci_stage_e;

/* 通讯任务 */
typedef struct{

    uint16_t bcu_actual_num;        // 实际电池簇数量
    int32_t bupdate;			    // 0：非升级状态，1:处于升级状态
    // int32_t call_falg;           // 下发阈值函数调用标志
    int32_t regular_dehum_finish;   // 每日定时除湿完成标志
    int32_t para_init_finish;       // 定值参数首次下发完成标志
    int32_t course_flag;            // 交互进行标志
	int32_t devaddr;			    // 用于记录当前发送包的设备地址
	int32_t commbreak_flag;		    // 通讯中断标志 0：正常，1:通讯中断
	int32_t commerr_cnt;	        // 记录通讯异常包连续次数
	// int32_t senderr_cnt;	        // 记录发送失败次数
	// int32_t retry_cnt;		    // 单条命令重复次数
	// int32_t current_funcID;      // 用来标记当前正在执行的功能码，暂未用到
    uint8_t txbuf[SCI_BUF_SIZE];    // 发送包缓存
    uint8_t rxbuf[SCI_BUF_SIZE];    // 接收包缓存
	sci_stage_e stage;		        // 通讯任务阶段
    sci_time_t last_time_dehum;     // 上一次除湿时间

}sci_task_t;


typedef union 
{
    struct 
    {
        uint8_t major_ver;
        uint8_t sub_ver;
    }ff_sw_ver;
    
    uint8_t ff_sen_type;
} fact_info_u;

typedef enum {
    FACT_INFO_TYPE_MCU2_VER     = 1,
    FACT_INFO_TYPE_FF_PRESSURE  = 2,
    FACT_INFO_TYPE_FF_SW_VER    = 3,
    FACT_INFO_TYPE_FF_SEN_TYPE  = 4,
} fact_info_type_e;

/**************************************************************************
*   Function declaration
**************************************************************************/

/**
 * @brief  sci任务升级标志位置1
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
void update_flag_set(void);

/**
 * @brief  sci任务升级标志位清0
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
void update_flag_clear(void);

/**
 * @brief  下发定值参数
 * @param  [in]  function_id 下发数据功能码，具体见data_shm.h
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
int32_t set_constant_data(uint16_t function_id, uint16_t index, uint16_t port);

/**
 * @brief  获取sci通信收发互斥锁
 * @param  [out] none
 * @param  [in] none
 * @return sci通信收发互斥锁指针
 */
pthread_mutex_t *sci_mutex_get(void);

/**
 * @brief  启动SCI通讯线程
 * @param  none
 * @return none
 */ 
void sci_task_start(void);

/**
 * @brief  打印收发帧
 * @param  [in] buf 需要打印的缓存首地址
 * @param  [in] len 需要打印的缓存长度
 * @param  [out] none
 * @return 0:正常	-1:异常
 */
int32_t print_frame(const uint8_t *buf, int32_t len);

sf_ret_t sci_factory_get_info( fact_info_type_e info_type, fact_info_u *p_fact_info );
sf_ret_t sci_factory_set_sensor_type( uint8_t sensor_type );

#endif

