/*****************************************************************************
* File Name			: sci_task.c			
* Description		: 	
* Original Author	: 
* date				: 
******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>  
#include "sci_task.h"
#include "sdk_uart.h"
#include "cu_sofar_sci.h"
#include "sofar_type.h"

#define SCI_TIMEOUT_MS		    	   30000//(800)			// general串口读取超时时间800ms
// #define THRESHOLD_TIMEOUT_MS		   (3000)			// 串口读取阈值设置结果超时时间 3s
#define FLAG_REALTEMP0		    	  (0x0000)			// 实时数据跟随下发标志值，高字节为电池类数据长度，低字节为是否下发此类数据
// #define FLAG_REALTEMP1		   		  (0xC803)			// 实时数据跟随下发标志值，高字节为电池类数据长度，低字节为是否下发此类数据
#define FLAG_REALTEMP1(num, flag)           ((((num)*(20)) << (8)) | (flag))  // 实时数据跟随下发标志值，高字节为电池类数据长度，低字节为是否下发此类数据
#define LC_ON_OFF_DATA_NUM				(1)				// 遥控-液冷开关机 数据个数
#define THRESHOLD_CONTAINER_DATA_NUM	(1)				// 集装箱系统定值参数 数据个数
#define THRESHOLD_LC_SYS_DATA_NUM		(16)			// 液冷系统定值参数 数据个数
#define THRESHOLD_LC_LOGIC_DATA_NUM		(27)			// 液冷逻辑定值参数 数据个数
#define THRESHOLD_FIRE_DATA_NUM			(15)			// 消防定值参数 数据个数

typedef struct 
{
	uint16_t ix;		// 记录单簇电池温度max1的簇号（0~10）
	uint16_t jx;		// 记录单簇电池温度max1的包号（0~7）
	uint16_t kx;		// 记录单簇电池温度max1的节号（每包的序号0~47）
	uint16_t iy;		// 记录单簇电池温度max2的簇号（0~10）
	uint16_t jy;		// 记录单簇电池温度max2的包号（0~7）
	uint16_t ky;		// 记录单簇电池温度max2的节号（每包的序号0~47）
}flag_t;

static flag_t flag;										
static sci_task_t g_sci_task;							// sci任务结构体缓存
static sci_localbuf_t g_sci_localbuf;					// sci数据结构体缓存

pthread_mutex_t sofar_sci_mutex;						// 通信互斥锁


static sf_ret_t _sci_requset_data( uint16_t function_id, uint8_t *request_playload_dat, uint16_t request_playload_datlen,
                                   uint8_t *p_resp_playload_dat, uint16_t *p_resp_playload_datlen );
/**
 * @brief  获取sci通信收发互斥锁
 * @param  [in] none
 * @param  [out] none
 * @return sci通信收发互斥锁指针
 */
pthread_mutex_t *sci_mutex_get(void)
{
	return &sofar_sci_mutex;
}

/**
 * @brief  sci任务状态设置
 * @param  [in] stage 待设置的状态 具体见sci_stage_e
 * @param  [out] none
 * @return none
 */
static void task_stage_set(uint16_t stage)
{
	g_sci_task.stage = stage;
	return;
}

/**
 * @brief  sci任务升级标志位置1
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
void update_flag_set(void)
{
    g_sci_task.bupdate = 1;
    return;
}

/**
 * @brief  sci任务升级标志位清0
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
void update_flag_clear(void)
{
    g_sci_task.bupdate = 0;
    return;
}

/**
 * @brief  判断sci任务升级标志位是否为1
 * @param  [in] none
 * @param  [out] none
 * @return true：正在升级  false：未在升级
 */
static bool is_update_flag(void)
{
    bool ret = false;

	if(1 == g_sci_task.bupdate)
	{
		ret = true;
	}
	else
	{
		ret = false;
	}
	return ret;
}

/**
 * @brief  交互标志位置1
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void course_flag_set(void)
{
	g_sci_task.course_flag = 1;
	return;
}

/**
 * @brief  交互标志位清除
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void course_flag_clear(void)
{
	g_sci_task.course_flag = 0;
	return;
}

/**
 * @brief  判断交互标志位是否为1
 * @param  [in] none
 * @param  [out] none
 * @return true：正在交互  false：未在交互
 */
static bool is_course_flag(void)
{
	bool ret = false;

	if(1 == g_sci_task.course_flag)
	{
		ret = true;
	}
	else
	{
		ret = false;
	}

	return ret;
}

/**
 * @brief  结构体初始化打包
 * @param  [out] p_sofar sci结构体缓存，具体见cu_sofar_sci_t
 * @param  [in] funcid 功能码
 * @param  [in] p_data 数据段缓存指针
 * @param  [in] data_len 数据段的长度
 * @return none
 */
static void regular_data_pack(cu_sofar_sci_t *p_sofar, uint16_t func_id, uint8_t *p_data, int32_t data_len)
{
	if(p_sofar == NULL || p_data == NULL || data_len > SCI_BUF_SIZE)
	{
		return;
	}

	p_sofar->version = SCI_VERTION1;
	p_sofar->dev_addr = DEV_ADDR_CONTAINER;
	p_sofar->function_id = func_id;
	p_sofar->data_len = data_len;
	p_sofar->p_data = p_data;

	return;
}

/**
 * @brief  sci通讯任务初始化
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void sci_task_init(void)
{
	int32_t ret = 0;
	int32_t retry_cnt = UART_INIT_RETRYCNT;
	sdk_uart_conf_t arrt = {UART_BAUD_RATE_115200, UART_DATA_BITS_8, UART_STOP_BITS_1, UART_PARITY_NONE, UART_HWFLOW_OFF};

	while(retry_cnt--)
	{
		// 打开串口
		if(sdk_uart_open(SDK_UART2) != 0) 
		{
			SCI_DEBUG_LOG((int8_t *)"sdk_uart_open faild\n");
			continue;
		}
		SCI_DEBUG_LOG((int8_t *)"sdk_uart_open over\n");

		// 配置串口
		SCI_DEBUG_LOG((int8_t *)"uart setup start!\n");	
		if(sdk_uart_setup(SDK_UART2, &arrt) == 0)
		{
			SCI_DEBUG_LOG((int8_t *)"sdk_setup over\n");
			break;
		}
		SCI_DEBUG_LOG((int8_t *)("sdk_uart_setup faild\n"));
	}

	return;
}

/**
 * @brief  通讯异常计数
 * @param  [in] devid  设备地址
 * @param  [in] berror 1 异常；0 正常
 * @param  [in] btimeout 1 接收超时异常；0 正常接收未超时
 * @param  [out] none
 * @return none
 */
static void sci_error_handle(int32_t devid, int32_t berror, int32_t btimeout)
{
	uint32_t step_cnt = 1;

	if(devid != DEV_ADDR_CONTAINER)
	{
		return;
	}
	if(btimeout == 1)
	{
		step_cnt = 2;
	}
	//连续通讯异常包统计
	if(berror)
	{
		g_sci_task.commerr_cnt += step_cnt;
		if(g_sci_task.commerr_cnt >= COMMBREAKCNT_MAX)
		{
			g_sci_task.commerr_cnt = COMMBREAKCNT_MAX;
			g_sci_task.commbreak_flag = 1;
			// g_sci_task.commbreak_flag |= 1 << (devid - 1) ;
			// 置共享内存里对应故障位--SCI通信故障
			SCI_DEBUG_LOG((int8_t *)("[sci_error_handle] sci commbreak!\n"));
		}
	}
	else
	{
		g_sci_task.commerr_cnt = 0;
		g_sci_task.commbreak_flag = 0; 
		// 清共享内存里对应故障位
	}
	return;
}


/**
 * @brief  握手信息赋值至参数缓存
 * @param  [in] p_para_buf 发送数据缓存指针
 * @param  [out] none
 * @return >0:打包字节数  -1:失败
 */
static int32_t sci_onpack_handshake(uint8_t *p_para_buf)
{
	int32_t len = 0;
	if(p_para_buf == NULL)
	{
		return -1;
	}

	p_para_buf[len++] = (uint8_t)(0x00);
	p_para_buf[len++] = (uint8_t)(0x11);
	p_para_buf[len++] = (uint8_t)(0x22);
	p_para_buf[len++] = (uint8_t)(0x33);
	p_para_buf[len++] = (uint8_t)(0x44);
	return len;
}


/**
 * @brief  u16数据赋值至u8参数缓存
 * @param  [in] p_buf 数据发送缓存指针
 * @param  [in] p_data 待打包的u16数据块首地址
 * @param  [in] data_num 待打包的u16数据个数
 * @param  [out] none
 * @return >0:打包字节数  -1:失败
 */
static int32_t sci_onpack_txdata(uint8_t *p_buf, const uint16_t *p_data, int32_t data_num)
{
	int32_t i = 0;
	int32_t len = 0;
	
	if(NULL == p_buf || NULL == p_data)
	{
		return -1;
	}

	if(data_num > (SCI_BUF_SIZE / sizeof(uint16_t)))
	{
		SCI_DEBUG_LOG((int8_t *)"[sci_onpack_txdata] data_num is out of range!\n");
		return -1;
	}

	for(i=0; i<data_num; i++)
	{
		// 发送u16数据，高位在前，低位在后
		p_buf[len++] = (uint8_t)((p_data[i] >> 8) & 0xff);
		p_buf[len++] = (uint8_t)((p_data[i] >> 0) & 0xff);
	}
	
	return len;
}


/**
 * @brief  接收数据解析
 * @param  [in] p_buf 接收数据缓存
 * @param  [in] data_len 数据段长度
 * @param  [in] p_data 数据解析缓存首地址
 * @param  [out] none
 * @return >0:解析成功u16数据个数  -1:失败
 */
static int32_t sci_onparse_rxdata(uint8_t *p_buf, uint8_t data_len, uint16_t *p_data)
{
	uint8_t i = 0;
	int32_t num = 0;

	if(NULL == p_buf || NULL == p_data)
	{
		return -1;
	}

	for(i=0; i<data_len-1; i+=2)
	{
		// 接收组装为u16数据，高位在前，低位在后
		p_data[num++] = (uint16_t)((p_buf[i] << 8) | p_buf[i+1]);
	}

	return num;
}


/**
 * @brief  发送指令
 * @param  [in] dev_addr 从机地址
 * @param  [in] function_id 功能码                               
 * @param  [in] data_len 数据段长度
 * @param  [in] p_data 数据段首地址
 * @param  [out] none
 * @return 0：成功  -1：失败
 */
int32_t sci_send_command(uint8_t dev_addr,uint16_t function_id, int32_t data_len, uint8_t *p_data)
{
    uint8_t txbuf[SCI_BUF_SIZE] = {0};
    int32_t send_len = 0;
	int32_t ret = -1;
    cu_sofar_sci_t sci_pack_tx;

	regular_data_pack(&sci_pack_tx, function_id, p_data, data_len);
    memset(txbuf, 0, SCI_BUF_SIZE);

    // 打包
    send_len = cu_sofar_sci_pack(&sci_pack_tx, txbuf, SCI_BUF_SIZE);
	if(send_len == -1)
	{
		SCI_DEBUG_LOG((int8_t *)"[cu_sofar_sci_pack] pack err ret = %d!\n", send_len);
		return -1;
	}
    SCI_DEBUG_LOG((int8_t *)"[sci_send_command] send_len = %d\n", send_len);

    // 发送
    ret = sdk_uart_write(SDK_UART2, txbuf, send_len);
    
    if(ret < 0)
    {
        SCI_DEBUG_LOG((int8_t *)"[sci_send_command] sci cmd send fail!\n");
		sci_error_handle(g_sci_task.devaddr, 1, 0);						// 异常未超时
		return -1;
    }
    else
    {
        SCI_DEBUG_LOG((int8_t *)"[sci_send_command] sci send_frame: ");
        print_frame(txbuf, send_len);
        SCI_DEBUG_LOG((int8_t *)"\n");
    }

    return 0;
}

/**
 * @brief  读取应答数据
 * @param  [in] time_out_ms	串口读取超时时间 
 * @param  [out] ack_data_buffer 应答数据段首地址
 * @param  [in] buf_len 接收缓存大小
 * @param  [in] function_id 功能码 
 * @return 读取结果 >=0：数据段长度  -1：失败
 */
int32_t sci_read_ackdata(int32_t time_out_ms, uint8_t *ack_data_buffer, uint8_t buf_len, uint16_t function_id)
{
    uint8_t rxbuf[SCI_BUF_SIZE] = {0};
    int32_t ret = -1;
    int32_t valid_data_len = 0;
    int32_t recv_len = 0;
    cu_sofar_sci_t sci_pack_rx;

	if(NULL == ack_data_buffer)
	{
		return -1;
	}
    
    // cu_stru_pack(&sci_pack_rx, SCI_VERTION1, function_id, dev_addr, SCI_BUF_SIZE, &rxbuf[INDEX_DATA_SLAVE]);
	regular_data_pack(&sci_pack_rx, function_id, &rxbuf[INDEX_DATA_SLAVE], SCI_BUF_SIZE);
    
    // 接收
    memset(rxbuf, 0, SCI_BUF_SIZE);
    ret = sdk_uart_read(SDK_UART2, rxbuf, SCI_BUF_SIZE, time_out_ms);
    SCI_DEBUG_LOG((int8_t *)"[sci_read_ackdata] recv_len = %d\n", ret);

    if(ret < 0)
    {
        SCI_DEBUG_LOG((int8_t *)"[sci_read_ackdata] uart read fail!\n");
		sci_error_handle(g_sci_task.devaddr, 1, 1);						// 异常且超时
        return -1;
    }

    recv_len = (ret > SCI_BUF_SIZE)?SCI_BUF_SIZE:ret;
    SCI_DEBUG_LOG((int8_t *)"[sci_read_ackdata] sci recv_frame: ");
    print_frame(rxbuf, recv_len);

    // 框架解包
    ret = cu_sofar_sci_unpack(DEV_ADDR_CONTAINER, function_id, &sci_pack_rx, rxbuf, recv_len);
    if(ret != 0)
    {
        SCI_DEBUG_LOG((int8_t *)"[sci_read_ackdata] unpack fail and ret = %d!\n",ret);
		sci_error_handle(g_sci_task.devaddr, 1, 0);						// 异常未超时
        return -1;
    }

    valid_data_len = rxbuf[3]-2;
    // 限幅
    valid_data_len = (int32_t)((valid_data_len>buf_len)?buf_len:valid_data_len);

    memcpy(ack_data_buffer, &rxbuf[INDEX_DATA_SLAVE], valid_data_len);
    SCI_DEBUG_LOG((int8_t *)"[sci_read_ackdata] sci recv ok\n");
    
    return valid_data_len;
}

/**
 * @brief  上电握手过程--交互
 * @param  [in] none
 * @param  [out] none
 * @return 0:成功  -1:失败
 */
static int32_t sci_handshake_course(void)
{
	uint8_t i = 0;
	int32_t ret1 = -1;
	int32_t ret2 = -1;
	int32_t ret3 = -1;
	int32_t data_len = 0;			// 发送数据长度
	int32_t valid_data_len = 0;		// 接收有效数据长度

	course_flag_set();				// 交互开始

	// 1、发送
	memset(&g_sci_task.txbuf, 0, SCI_BUF_SIZE);
	data_len = sci_onpack_handshake(&g_sci_task.txbuf[INDEX_DATA_HOST]);
	SCI_DEBUG_LOG((int8_t *)"[sci_handshake_course] data_len = %d\n",data_len);
	if(data_len == -1)
	{
		course_flag_clear();
		return -1;
	}

	for(i=0; i<CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		// 发送握手数据
		ret1 = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_HANDSHAKED, data_len, &g_sci_task.txbuf[INDEX_DATA_HOST]);

        // 获取应答结果
		if(ret1 == 0)
		{
			ret2 = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_HANDSHAKED);
		} 
		pthread_mutex_unlock(&sofar_sci_mutex);

		if(ret2 > 0)
		{	
			valid_data_len = ret2;
			SCI_DEBUG_LOG((int8_t *)"[sci_handshake_course] ack ok and valid_data_len = %d\n", valid_data_len);
			break;
		}

		usleep(1000 * 100);
	}

	sci_error_handle(g_sci_task.devaddr, 0, 0);
	course_flag_clear();				// 交互结束

	return ret3;		
}


sf_ret_t sci_factory_get_info( fact_info_type_e info_type, fact_info_u *p_fact_info )
{
    uint8_t  get_cmd[6]    = {0};
    uint8_t  resp_dat[255] = {0};
    uint16_t resp_dat_len = 0;

    get_cmd[1] = info_type;
    if ( SF_OK != _sci_requset_data( FUNCID_FACTEST_GET_DAT, get_cmd, sizeof( get_cmd ), resp_dat, &resp_dat_len ))
    {
        return SF_ERR_RD;
    }

    if (   (resp_dat_len != 6 )
        || (resp_dat[0] != 0) 
        || (resp_dat[1] != info_type))
    {
        return SF_ERR_RD;
    }

    if ( info_type == FACT_INFO_TYPE_FF_SW_VER )
    {
        p_fact_info->ff_sw_ver.major_ver = resp_dat[3];
        p_fact_info->ff_sw_ver.sub_ver   = resp_dat[4];
    }
    else if ( info_type == FACT_INFO_TYPE_FF_SEN_TYPE )
    {
        p_fact_info->ff_sen_type = resp_dat[5];
    }

    return SF_OK;
}

sf_ret_t sci_factory_set_sensor_type( uint8_t sensor_type )
{
    uint8_t set_cmd[6] = {  0x00,0x01,      //< key
                            0,0,0,0         //< val
                         };
    uint8_t  resp_dat[10] = {0};
    uint16_t resp_dat_len = 0;

    set_cmd[5] = sensor_type;
    if ( SF_OK == _sci_requset_data( FUNCID_FACTEST_SET_DAT, set_cmd, sizeof( set_cmd ), resp_dat, &resp_dat_len ))
    {
        if ( resp_dat_len == 3 && resp_dat[2] == 1 )
        {
            return SF_OK;
        }
    }
    return SF_ERR_WR;
}

/**
 * @brief  sci 请求数据
 * @param  [in] function_id             ： 功能ID
 * @param  [in] request_playload_dat    ： 请求数据
 * @param  [in] request_playload_datlen ： 请求数据长度
 * @param  [in] respond_proc_cb         ： 回应处理回调
 * @return SF_OK：成功  非SF_OK：失败
 * @note   
 */
static sf_ret_t _sci_requset_data( uint16_t function_id, uint8_t *request_playload_dat, uint16_t request_playload_datlen,
                                   uint8_t *p_resp_playload_dat, uint16_t *p_resp_playload_datlen )
{
    uint8_t rx_buff[255] = {0};
    uint32_t rd_len = -1;
    sf_ret_t ret = SF_OK;

	course_flag_set();
    
    memset( rx_buff, 0, sizeof(rx_buff) );
    for ( size_t i = 0; i < CMD_RETRYCNT_MAX; i++ )
	{
		pthread_mutex_lock( &sofar_sci_mutex );
		if( 0 == sci_send_command(DEV_ADDR_CONTAINER, function_id, request_playload_datlen, request_playload_dat ))
		{
			rd_len = sci_read_ackdata(SCI_TIMEOUT_MS, rx_buff, sizeof(rx_buff), function_id);
		} 
		pthread_mutex_unlock(&sofar_sci_mutex);
		if( rd_len >= 0 )
		{
            if ( rd_len == 0 )
            {
                log_w( (int8_t*)"sci respond playload is empty!!!" );
            }
			break;
		}
		usleep(1000 * 100);
	}

    if ( rd_len < 0 )
    {
        log_e( (int8_t*)"[%s]sci respond error!!!", __FUNCTION__ );
        ret = SF_ERR_NDEF;
    }

    memcpy( p_resp_playload_dat, rx_buff, rd_len );
    *p_resp_playload_datlen = rd_len;

	course_flag_clear();		// 交互结束

    return ret;
}


/**
 * @brief  下发动作阈值过程--交互
 * @param  [in] funcid 下发阈值对应功能码
 * @param  [in] p_data 待发送数据首地址
 * @param  [in] data_num 待发送数据个数
 * @param  [out] none
 * @return 0:成功  -1:失败
 */
static int32_t sci_threshold_course(uint16_t function_id, uint16_t *p_data, uint32_t data_num)
{
	uint8_t i = 0;
	int32_t data_len = 0;		// 发送数据长度
	int32_t ret1 = -1;
	int32_t ret2 = -1;
	int32_t ret3 = -1;
	int32_t valid_data_len = 0;
	
	if(NULL == p_data)
	{
		return -1;
	}

	course_flag_set();			// 交互开始

	// 1、发送
	memset(&g_sci_task.txbuf, 0, SCI_BUF_SIZE);
	data_len = sci_onpack_txdata(&g_sci_task.txbuf[INDEX_DATA_HOST], p_data, data_num);
	if(data_len == -1)
	{
		course_flag_clear();
		return -1;
	}
	
	for(i=0; i<CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		// 发送握手数据
		ret1 = sci_send_command(DEV_ADDR_CONTAINER, function_id, data_len, &g_sci_task.txbuf[INDEX_DATA_HOST]);

		// 等待mcu2下发结束
		//sleep(3);
        // 获取应答结果
		if(ret1 == 0)
		{
			printf("++++++++  sci_send_command success\n");
			ret2 = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, function_id);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);

		if(ret2 > 0)
		{
			valid_data_len = ret2;
			break;
		}

		usleep(1000 * 100);
	}


	if(ret2 > 0)
	{
		if (ret2 == 5)
		{
			printf("+++++++++++++==  %d  %d  %d  %d  %d\n", g_sci_task.rxbuf[INDEX_DATA_SLAVE], g_sci_task.rxbuf[INDEX_DATA_SLAVE + 1]\
					, g_sci_task.rxbuf[INDEX_DATA_SLAVE + 2], g_sci_task.rxbuf[INDEX_DATA_SLAVE + 3], g_sci_task.rxbuf[INDEX_DATA_SLAVE + 4]);
			if (1 == g_sci_task.rxbuf[INDEX_DATA_SLAVE + 4])
			{
				SCI_DEBUG_LOG((int8_t *)("[sci_threshold_course] 2-Threshold Set ok!!!\n"));
				ret3 = 0;
			}
			else
			{
				SCI_DEBUG_LOG((int8_t *)("[sci_threshold_course] 2-Threshold Set fail!\n"));	
				ret3 = -1;
			}
		}
		else if(ret2 == 6)
		{
			if(g_sci_task.rxbuf[INDEX_DATA_SLAVE] == 0 && 
				g_sci_task.rxbuf[INDEX_DATA_SLAVE+1] == 1)  //版本号
			{
				g_muc2_version[0] = g_sci_task.rxbuf[INDEX_DATA_SLAVE+2];
				g_muc2_version[1] = g_sci_task.rxbuf[INDEX_DATA_SLAVE+3];
				g_muc2_version[2] = g_sci_task.rxbuf[INDEX_DATA_SLAVE+4];
				g_muc2_version[3] = g_sci_task.rxbuf[INDEX_DATA_SLAVE+5];
				ret3 = 0;
			}
			if(g_sci_task.rxbuf[INDEX_DATA_SLAVE] == 0 && 
				g_sci_task.rxbuf[INDEX_DATA_SLAVE+1] == 2)  //消防瓶组气压
			{
				pressure[0] = g_sci_task.rxbuf[INDEX_DATA_SLAVE+2];
				pressure[1] = g_sci_task.rxbuf[INDEX_DATA_SLAVE+3];
				pressure[2] = g_sci_task.rxbuf[INDEX_DATA_SLAVE+4];
				pressure[3] = g_sci_task.rxbuf[INDEX_DATA_SLAVE+5];
				ret3 = 0;
			}
			else
			{
				ret3 = -1;
			}
		}
		else
		{
			// 无数据处理
			if(1 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
			{
				SCI_DEBUG_LOG((int8_t *)("[sci_threshold_course] 2-Threshold Set ok!!!\n"));
				printf("[sci_threshold_course] 2-Threshold Set ok!!!\n");
				ret3 = 0;
			}
			else if(0 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
			{
				SCI_DEBUG_LOG((int8_t *)("[sci_threshold_course] 2-Threshold Set fail!\n"));	
				ret3 = -1;
			}
		}
		
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);

	}
	course_flag_clear();			// 交互结束

	return ret3;
}

/**
 * @brief  SCI通讯任务管理
 * @param  [in] arg
 * @param  [out] none
 * @return 0:正常  负数:异常
 */
static int32_t sci_task_manage(void)
{
	int32_t ret = -1;
	sci_localbuf_t *p_localbuf = NULL;

	p_localbuf = &g_sci_localbuf;

	if(NULL == p_localbuf)
	{
		return ret;
	}

    if(is_update_flag() == true)
    {
        return ret;
    }
    SCI_DEBUG_LOG((int8_t *)"[sci_task_manage] Not in the upgrade, prepare the sci!\n");

	// 直接判断阶段
	switch(g_sci_task.stage)
	{
		case STAGE_SHAKE_HAND:
		{	
			SCI_DEBUG_LOG((int8_t *)("[sci_task_manage] this is 1 stage!\n"));
		
			// g_sci_task.current_funcID = FUNCID_HANDSHAKED;

			ret = sci_handshake_course();

			if(0 == ret)
			{
				task_stage_set(STAGE_SEND_TELECOMMAND);
			}
			break;
		}
		default:
		{
			break;
		}
		
	}
	return ret;
}

/**
 * @brief  下发定值参数
 * @param  [in]  function_id 下发数据功能码，具体见data_shm.h
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
int32_t set_constant_data(uint16_t function_id, uint16_t index, uint16_t port)
{
	int32_t ret = 0;
	int32_t cnt = 10000;

	uint16_t sci_data[2] = {0};

	sci_data[0] = index;
	sci_data[1] = port;

	while(cnt--)
	{
		if(false == is_course_flag())
		{
			task_stage_set(STAGE_OTHER);
			break;
		}
		usleep(1000*1);
	}

	switch (function_id)
	{
		case FUNCID_FACTEST_ENTER:
		{
			SCI_DEBUG_LOG((int8_t *)"\n FUNCID_FACTEST_ENTER \n");
			// task_stage_set(STAGE_OTHER);
		//	sci_data[0] = 1; //表示辅电箱测试
			if(port == 1)
			{
				sci_data[0] = 1;
			}
			else
			{
				sci_data[0] = 0;
			}
			ret = sci_threshold_course(function_id, sci_data, 1);
			break;
		}
		case FUNCID_FACTEST_START:
		{
			printf((int8_t *)"\n FUNCID_FACTEST_START \n");
			// task_stage_set(STAGE_OTHER);
			ret = sci_threshold_course(function_id, sci_data, 2);
			break;
		}
		case FUNCID_FACTEST_LEAVE:
		{
			SCI_DEBUG_LOG((int8_t *)"\n FUNCID_FACTEST_LEAVE \n");
			// task_stage_set(STAGE_OTHER);
			ret = sci_threshold_course(function_id, sci_data, 1);
			break;
		}
		case FUNCID_FACTEST_VERSION:
		{
			SCI_DEBUG_LOG((int8_t *)"\n FUNCID_FACTEST_VERSION \n");
			sci_data[0] = port;
			ret = sci_threshold_course(function_id, sci_data, 1);
			break;
		}
		default:
		{
			ret = -1;
			break;
		}
	}

	// 下发完毕切换至实时数据阶段
	task_stage_set(STAGE_GET_REALTIMEDATA);

	return ret;
}

/**
 * @brief  SCI通讯线程
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
void *thread_scicomm(void *arg)
{
	sleep(1);							// 集装箱的sci线程,上电延时1s启动
	
	sci_task_init();
	while(1)
	{
		sci_task_manage();

		usleep(500*1000);				// 500ms
	}

	pthread_exit(NULL);

}

/**
 * @brief  启动SCI通讯线程
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
void sci_task_start(void)
{
	int32_t ret = 0;
	pthread_attr_t sci_attr;
	pthread_t container_sci;
	pthread_t update_mcu2;

	// 初始化线程属性
    ret = pthread_attr_init(&sci_attr);
    if (ret)
    {
        SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] pthread_attr_init error!!! \n", __func__, __LINE__);
        return; // 线程属性初始化出错退出
    }
    
    // 设置线程属性为分离状态
    ret = pthread_attr_setdetachstate(&sci_attr, PTHREAD_CREATE_DETACHED);
    if (ret)
    {
        SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] pthread_attr_setdetachstate info_record_attr error!!! \n", __func__, __LINE__);
        return; // 线程分离属性设置出错退出
    }

	
	ret = pthread_create(&container_sci, &sci_attr, &thread_scicomm, NULL);
	if (ret)
    {
        SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] pthread_create container_sci error!!! \n", __func__, __LINE__);
        return; // 线程创建出错退出
    }

	// 销毁线程属性结构,它在重新初始化之前不能重新使用
    pthread_attr_destroy(&sci_attr);

	return;
}

/**
 * @brief  打印收发帧
 * @param  [in] p_buf 需要打印的缓存首地址
 * @param  [in] len 需要打印的缓存长度
 * @param  [out] none
 * @return 0:正常	-1:异常
 */
int32_t print_frame(const uint8_t *p_buf, int32_t len)	
{
	int32_t i = 0;

	if(NULL == p_buf || len > SCI_BUF_SIZE || len < 0)
	{
		return -1;
	}

	for(i=0; i<len; i++)
	{
		SCI_DEBUG_LOG((int8_t *)"0x%02x ",p_buf[i]);
	}
	SCI_DEBUG_LOG((int8_t *)"\n");

	return 0;
}






