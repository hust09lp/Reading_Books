#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<sys/ioctl.h>
#include<net/if.h>
#include<pthread.h>
#include"modbus-tcp.h"
#include"modbus-private.h"
#include"peripheral_dev_test.h"
#include"sci_task/sci_task.h"

#define FACTORY_TEST_FLAG "/user/conf/factory_test_flag"
#define LOG_MODBUS_ENABLE 0
#define MODBUS_TCP_PORT 502
#define DIN1_GPIO_NUM 64
#define DIN2_GPIO_NUM 65
#define DIN3_GPIO_NUM 115
#define DIN4_GPIO_NUM 116
#define DIN5_GPIO_NUM 66
#define DIN6_GPIO_NUM 67
#define DIN7_GPIO_NUM 68
#define DIN8_GPIO_NUM 137

#define DO1_GPIO_NUM 69
#define DO2_GPIO_NUM 80
#define DO3_GPIO_NUM 71
#define DO4_GPIO_NUM 72

// MCU1应用层软件版本号
#define MCU1_SOFTWARE_VERSION_TPYE           ('V')           // 版本类型，暂固定为 V
#define MCU1_SOFTWARE_MAJOR_VERSION          (1)             // 主版本号
#define MCU1_SOFTWARE_MINOR_VERSION          (0)             // 次版本号
#define MCU1_SOFTWARE_STAGE_VERSION          (12)             // 阶段版本号

#define MCU1_HARDWARE_MAJOR_VERSION          (0)             // 主版本号
#define MCU1_HARDWARE_MINOR_VERSION          (7)             // 次版本号

/* 辅电箱产测基地址 */
#define AUX_FACTEST_MB_ADDR_BASE        ( 0xF401 )
#define AUX_FACTEST_MB_ADDR( offset )   ( (AUX_FACTEST_MB_ADDR_BASE ) - 1 + (offset) )

#define MCU1_ENERGY_DIRECTORY "/user/data/energy"
#define MCU1_EVENT_DIRECTORY "/user/data/event"
#define MCU1_PARA_DIRECTORY "/user/data/para"
#define MCU1_POWER_DIRECTORY "/user/data/power"
#define MCU1_ADMIN_CONFIG_FILE "/user/www/conf/administrator.json"
#define MCU1_SYSTIME_CONFIG_FILE "/user/www/conf/systime.json"
#define MCU1_RUNTIME_CONFIG_FILE "/user/www/conf/runtimeparams.json"
#define MCU1_OPERATION_LOG "/user/www/conf/operationlog"
#define MCU1_HISTORY_DIRECTORY "/media/mmcblk0p1/"

uint8_t g_reboot_flag;
uint8_t g_rs485[2];
uint8_t g_can[2];
uint8_t g_tfcard;
uint8_t g_usb;
uint8_t g_di[8];
uint8_t g_net2;
uint8_t g_mcu2;

void printhex(uint8_t *data, int32_t length)
{
    uint8_t i;
    for(i = 0; i< length; i++)
    {
        printf("0x%x\t", data[i]);
    }
    printf("\n");
}

//生产测试完成之后，需要删除一些产测过程中产生的文件
static void clear_intermediate_directory_and_files()
{
    uint8_t cmd[128];
    memset(cmd, 0, sizeof(cmd));
    if(access(MCU1_ENERGY_DIRECTORY, F_OK) == 0)
    {
        snprintf(cmd, sizeof(cmd), "rm -rf %s", MCU1_ENERGY_DIRECTORY);
        system(cmd);
    }
    memset(cmd, 0, sizeof(cmd));
    if(access(MCU1_EVENT_DIRECTORY, F_OK) == 0)
    {
        snprintf(cmd, sizeof(cmd), "rm -rf %s", MCU1_EVENT_DIRECTORY);
        system(cmd);
    }
    memset(cmd, 0, sizeof(cmd));
    if(access(MCU1_PARA_DIRECTORY, F_OK) == 0)
    {
        snprintf(cmd, sizeof(cmd), "rm -rf %s", MCU1_PARA_DIRECTORY);
        system(cmd);
    }
    memset(cmd, 0, sizeof(cmd));
    if(access(MCU1_POWER_DIRECTORY, F_OK) == 0)
    {
        snprintf(cmd, sizeof(cmd), "rm -rf %s", MCU1_POWER_DIRECTORY);
        system(cmd);
    }
    memset(cmd, 0, sizeof(cmd));
    if(access(MCU1_ADMIN_CONFIG_FILE, F_OK) == 0)
    {
        snprintf(cmd, sizeof(cmd), "rm -rf %s", MCU1_ADMIN_CONFIG_FILE);
        system(cmd);
    }
    memset(cmd, 0, sizeof(cmd));
    if(access(MCU1_SYSTIME_CONFIG_FILE, F_OK) == 0)
    {
        snprintf(cmd, sizeof(cmd), "rm -rf %s", MCU1_SYSTIME_CONFIG_FILE);
        system(cmd);
    }
    memset(cmd, 0, sizeof(cmd));
    if(access(MCU1_RUNTIME_CONFIG_FILE, F_OK) == 0)
    {
        snprintf(cmd, sizeof(cmd), "rm -rf %s", MCU1_RUNTIME_CONFIG_FILE);
        system(cmd);
    }
    memset(cmd, 0, sizeof(cmd));
    if(access(MCU1_OPERATION_LOG, F_OK) == 0)
    {
        snprintf(cmd, sizeof(cmd), "rm -rf %s", MCU1_OPERATION_LOG);
        system(cmd);
    }
    memset(cmd, 0, sizeof(cmd));
    if(access(MCU1_HISTORY_DIRECTORY, F_OK) == 0)
    {
        snprintf(cmd, sizeof(cmd), "rm -rf %s/*", MCU1_HISTORY_DIRECTORY);
        system(cmd);
    }
}

bool test_di( uint8_t di_num, uint8_t link_do_num )
{
    test_do_set_value( link_do_num, 1 );
    usleep( 100*1000 );
    if ( 1 != test_di_value( di_num ) ) 
    {
        test_do_set_value( di_num, 0 );
        return FALSE;
    }
    
    test_do_set_value( link_do_num, 0 );
    usleep( 100*1000 );
    if ( 0 != test_di_value( di_num ) ) 
    {
        return FALSE;
    }
    return TRUE;
}

static void modbus_analysis(modbus_t *ctx, uint8_t *req, int32_t req_length)
{
    int offset = 0;
	int header_length = 0;
    uint16_t addr = 0;  //起始地址或者寄存器地址
    uint16_t register_num = 0;
	uint8_t func = 0;
	int32_t rc = 0;
    sft_t sft;
    uint8_t msg_len;
    uint8_t msg[16] = {0,0,0,0,0,0,1};
    uint8_t msg_length;
    uint16_t data;
    uint8_t cmd[64] = {0};
    uint8_t i;
    static uint8_t g_factory_mode;

	header_length = modbus_get_header_length(ctx);  //前6个字节加上一个字节的从机地址,值为7
    offset = header_length;

    #if 0
    printhex(req, req_length);
    #endif
    func = req[offset];
    addr = ((uint16_t)(req[offset+1] << 8)) + req[offset+2];
    #if 0
    if(access(FACTORY_TEST_FLAG, F_OK) != 0)  //当前不是工厂测试模式，则不能进行测试
    {
        if(addr != 60000)
        {
            printf("not factory mode!!!\n");
            return;
        }
    }
    #endif
	if(0x06 == func)//写单个寄存器
	{
		print_log("func code = 0x06, addr = %d", addr);
        data = (req[offset+3] << 8) + req[offset+4];
        switch(addr)
        {
            case AUX_FACTEST_MB_ADDR(1):   //进入工厂模式(辅电箱)
                if(data == 2)
                {
                    #if 0
                    if(access(FACTORY_TEST_FLAG, F_OK) == 0) //当前是工厂模式
                    {
                        printf("current is already factory mode!!!\n");
                        break;
                    }
                    #endif
                    system("killall app_start");
                    system("killall communication");
                    system("killall core_ipc_server");
                    system("killall south_dev");
                    system("killall web_server");
                    system("killall update_server");
                    sleep(3);
                    sci_task_start();
                    sleep(1);
                    set_constant_data(FUNCID_FACTEST_ENTER, 0, 1);
                   // snprintf(cmd, 64, "touch %s", FACTORY_TEST_FLAG);
                   // system(cmd);
                  //  sync();
                    g_factory_mode = 1;
                    print_log("enter into factory mode...");
                    req_length = ctx->backend->send_msg_pre((char *)req, req_length);
                    ctx->backend->send(ctx, req, req_length); //原封不动返回
                    return;
                }
                else if(data == 0)  //退出工厂模式
                {
                   /* if(access(FACTORY_TEST_FLAG, F_OK) != 0) //当前不是工厂模式
                    {
                        printf("current is not factory mode!!!\n");
                        break;
                    }*/
                   // set_constant_data(FUNCID_FACTEST_LEAVE, 0, 0);
                  //  snprintf(cmd, 64, "rm -f %s", FACTORY_TEST_FLAG);
                  //  system(cmd);
                  //  clear_intermediate_directory_and_files();
                  //  sync();
                   // g_reboot_flag = 1;
                    print_log("exit factory mode...");
                    g_factory_mode = 0;
                    set_constant_data(FUNCID_FACTEST_LEAVE, 0, 0);
                    req_length = ctx->backend->send_msg_pre((char *)req, req_length);
                    ctx->backend->send(ctx, req, req_length); //原封不动返回
               //     g_reboot_flag = 1;
                    return;
                }
                else if(data == 1) //进入工厂模式(单板)
                {
                    // if(access(FACTORY_TEST_FLAG, F_OK) == 0) //当前是工厂模式
                    // {
                    //     printf("current is already factory mode!!!\n");
                    //     break;
                    // }
                    system("killall app_start");
                    system("killall communication");
                    system("killall core_ipc_server");
                    system("killall south_dev");
                    system("killall web_server");
                    system("killall update_server");
                    sleep(3);
                    sci_task_start();
                    sleep(1);
                    set_constant_data(FUNCID_FACTEST_ENTER, 0, 0);
                    snprintf(cmd, 64, "touch %s", FACTORY_TEST_FLAG);
                    system(cmd);
                    g_factory_mode = 1;
                    g_reboot_flag = 1;
                }
                break;
            case AUX_FACTEST_MB_ADDR(2): 
                g_rs485[0] = test_rs485(1);
                if(data != 0xffff)
                {
                    print_log("data error");
                    return ;
                }
                break;
            case AUX_FACTEST_MB_ADDR(4):
                if(data != 0xffff)
                {
                    print_log("data error");
                    return ;
                }
                g_rs485[1] = test_rs485(2);
                break;
            case AUX_FACTEST_MB_ADDR(6):
                if(data != 0xffff)
                {
                    print_log("data error");
                    return ;
                }
                g_can[0] = test_can(1);
                break;
            case AUX_FACTEST_MB_ADDR(8):
                if(data != 0xffff)
                {
                    print_log("data error");
                    return ;
                }
                g_can[1] = test_can(2);
                break;
            case AUX_FACTEST_MB_ADDR(10):
                if(data != 0xffff)
                {
                    print_log("data error");
                    return ;
                }
                g_tfcard = test_tfcard();
                break;
            case AUX_FACTEST_MB_ADDR(12):
                if(data != 0xffff)
                {
                    print_log("data error");
                    return ;
                }
                g_di[0] = test_di( DIN1_GPIO_NUM, DO1_GPIO_NUM );
                break;
            case AUX_FACTEST_MB_ADDR(14):
                if(data != 0xffff)
                {
                    print_log("data error");
                    return ;
                }
                g_di[1] = test_di( DIN2_GPIO_NUM, DO1_GPIO_NUM );
                break;
            case AUX_FACTEST_MB_ADDR(16):
                if(data != 0xffff)
                {
                    print_log("data error");
                    return ;
                }
                g_di[2] = test_di( DIN3_GPIO_NUM, DO2_GPIO_NUM );
                break;
            case AUX_FACTEST_MB_ADDR(18):
                if(data != 0xffff)
                {
                    print_log("data error");
                    return ;
                }
              //  g_di[3] = test_di_value(DIN4_GPIO_NUM);  //特殊情况
                g_di[3] = test_di( DIN4_GPIO_NUM, DO2_GPIO_NUM );
                break;
            case AUX_FACTEST_MB_ADDR(20):
                if(data != 0xffff)
                {
                    print_log("data error");
                    return ;
                }
                g_di[4] = test_di( DIN5_GPIO_NUM, DO3_GPIO_NUM );
                break;
            case AUX_FACTEST_MB_ADDR(22):
                if(data != 0xffff)
                {
                    print_log("data error");
                    return ;
                }
                g_di[5] = test_di( DIN6_GPIO_NUM, DO3_GPIO_NUM );
                break;
            case AUX_FACTEST_MB_ADDR(24):
                if(data != 0xffff)
                {
                    print_log("data error");
                    return ;
                }
                g_di[6] = test_di( DIN7_GPIO_NUM, DO4_GPIO_NUM );
                break;
            case AUX_FACTEST_MB_ADDR(26):
                if(data != 0xffff)
                {
                    print_log("data error");
                    return ;
                }
                g_di[7] = test_di( DIN8_GPIO_NUM, DO4_GPIO_NUM );
                break;
            case AUX_FACTEST_MB_ADDR(28):
                if(data != 0xffff)
                {
                    print_log("data error");
                    return ;
                }
                g_net2 = test_net2();
                break;
            case AUX_FACTEST_MB_ADDR(30):
                if(data != 0xffff)
                {
                    print_log("data error");
                    return ;
                }
                g_usb = test_usb();
                break;
        }

        g_mcu2 = 0;
        if (addr >= AUX_FACTEST_MB_ADDR(39) && addr <=  AUX_FACTEST_MB_ADDR(46))
        {
            rc = set_constant_data(FUNCID_FACTEST_START, 1, (addr - AUX_FACTEST_MB_ADDR(39))/2 + 1);
            if (rc == 0)
            {
                g_mcu2 = 1;
                print_log("CMU2 RS485 %d test ok", (addr - AUX_FACTEST_MB_ADDR(39))/2 + 1);
            }
        } else if (addr >= AUX_FACTEST_MB_ADDR(47) && addr <= AUX_FACTEST_MB_ADDR(50))
        {
            rc = set_constant_data(FUNCID_FACTEST_START, 2, (addr - AUX_FACTEST_MB_ADDR(47))/2 + 1);
            if (rc == 0)
            {
                g_mcu2 = 1;
                print_log("CMU2 CAN %d test ok", (addr - AUX_FACTEST_MB_ADDR(47))/2 + 1);
            }
        } else if (addr >= AUX_FACTEST_MB_ADDR(51) && addr <= AUX_FACTEST_MB_ADDR(84))
        {
            rc = set_constant_data(FUNCID_FACTEST_START, 3, (addr - AUX_FACTEST_MB_ADDR(51))/2 + 1);
            if (rc == 0)
            {
                g_mcu2 = 1;
                print_log("CMU2 DI %d test ok", (addr - AUX_FACTEST_MB_ADDR(51))/2 + 1);
            }
        } else if (addr >= AUX_FACTEST_MB_ADDR(85) && addr <= AUX_FACTEST_MB_ADDR(100))
        {
            rc = set_constant_data(FUNCID_FACTEST_START, 4, (addr - AUX_FACTEST_MB_ADDR(85))/2 + 1);
            if (rc == 0)
            {
                g_mcu2 = 1;
                print_log("CMU2 DO %d test ok", (addr - AUX_FACTEST_MB_ADDR(85))/2 + 1);
            }
        }else if(addr >= AUX_FACTEST_MB_ADDR(101) && addr <= AUX_FACTEST_MB_ADDR(114))  //消防控制器
        {
            rc = set_constant_data(FUNCID_FACTEST_START, 5, (addr - AUX_FACTEST_MB_ADDR(101))/2 + 1);
            if (rc == 0)
            {
                g_mcu2 = 1;
                print_log("CMU2 fire control %d test ok", (addr - AUX_FACTEST_MB_ADDR(101))/2 + 1);
            }
        }else if(addr == AUX_FACTEST_MB_ADDR(115))
        {
            rc = set_constant_data(FUNCID_FACTEST_START, 5, 7);
            if (rc == 0)
            {
                g_mcu2 = 1;
                print_log("CMU2 fire control 7 test ok");
            }
        }
        else if(addr >= AUX_FACTEST_MB_ADDR(117) && addr <= AUX_FACTEST_MB_ADDR(132))  //IO拓展板DI1~DI8
        {
            rc = set_constant_data(FUNCID_FACTEST_START, 6, (addr - AUX_FACTEST_MB_ADDR(117))/2 + 0x81);
            if (rc == 0)
            {
                g_mcu2 = 1;
                print_log("CMU2 extend board %d test ok", (addr - AUX_FACTEST_MB_ADDR(117))/2 + 0x81);
            }
        }else if(addr >= AUX_FACTEST_MB_ADDR(133) && addr <= AUX_FACTEST_MB_ADDR(148))  //IO拓展板DO1~DO8
        {
            rc = set_constant_data(FUNCID_FACTEST_START, 6, (addr - AUX_FACTEST_MB_ADDR(133))/2 + 0x01);
            if (rc == 0)
            {
                g_mcu2 = 1;
                print_log("CMU2 extend board %d test ok", (addr - AUX_FACTEST_MB_ADDR(133))/2 + 0x01);
            }
        }else if( addr == AUX_FACTEST_MB_ADDR(151) )  // MCU2 FLASH测试
        {
            rc = set_constant_data(FUNCID_FACTEST_START, 7, 1);
            if (rc == 0)
            {
                g_mcu2 = 1;
                print_log("CMU2 flash test ok");
            }
        }else if( addr == AUX_FACTEST_MB_ADDR(153) )  // MCU2 EEPROM测试
        {
            rc = set_constant_data(FUNCID_FACTEST_START, 8, 1);
            if (rc == 0)
            {
                g_mcu2 = 1;
                print_log("CMU2 EEPROM  test ok");
            }
        }
        else if( addr == AUX_FACTEST_MB_ADDR(155) )  // MCU2 看门狗测试
        {
            rc = set_constant_data(FUNCID_FACTEST_START, 9, 0);
            usleep(1000*3);
            rc = set_constant_data(FUNCID_FACTEST_START, 9, 1);
            if (rc == 0)
            {
                usleep(1000000*4);
                rc = set_constant_data(FUNCID_FACTEST_ENTER, 0, 0);
                if(rc == 0)
                {
                    rc = set_constant_data(FUNCID_FACTEST_START, 9, 2);
                    if(rc == 0)
                    {
                        g_mcu2 = 1;
                        print_log("CMU2 WDT test ok");
                    }
                }
                
            }
        }

        switch ( addr )
        {
            case AUX_FACTEST_MB_ADDR(150):
                /* 消防控制器传感器类型 */
                if ( data <= 1 )
                {
                    sci_factory_set_sensor_type( data );
                }
                break;
        }

        req_length = ctx->backend->send_msg_pre((char *)req, req_length);
        ctx->backend->send(ctx, req, req_length); //原封不动返回
	}
    if(0x03 == func) //读取单个寄存器
    {
        fact_info_u fact_info;

        print_log("func code = 0x03, addr = %d", addr);
        register_num = (req[offset+3] << 8) + req[offset+4];
        if(addr == AUX_FACTEST_MB_ADDR(32) || addr == AUX_FACTEST_MB_ADDR(34) || addr == AUX_FACTEST_MB_ADDR(37))
        {
            if(register_num != 2)
            {
                print_log("register_num = %d", register_num);
                req_length = ctx->backend->send_msg_pre((char *)req, req_length);
                ctx->backend->send(ctx, req, req_length); //原封不动返回
                return ;
            }
        }
        else
        {
            if(register_num != 1)
            {
                print_log("register_num = %d", register_num);
                req_length = ctx->backend->send_msg_pre((char *)req, req_length);
                ctx->backend->send(ctx, req, req_length); //原封不动返回
                return ;
            }
        }

        msg[0] = req[0];
        msg[1] = req[1];
        msg[7] = 0x03;
        msg[8] = 2;  //2个字节
        msg_length = 11;
        switch(addr)
        {
            case AUX_FACTEST_MB_ADDR(1):
                msg[9] = 0;
                msg[10] = g_factory_mode;
                break;
            case AUX_FACTEST_MB_ADDR(3):
                msg[9] = 0;
                msg[10] = g_rs485[0];
                break;
            case AUX_FACTEST_MB_ADDR(5):
                msg[9] = 0;
                msg[10] = g_rs485[1];
                break;
            case AUX_FACTEST_MB_ADDR(7):
                msg[9] = 0;
                msg[10] = g_can[0];
                break;
            case AUX_FACTEST_MB_ADDR(9):
                msg[9] = 0;
                msg[10] = g_can[1];
                break;
            case AUX_FACTEST_MB_ADDR(11):
                msg[9] = 0;
                msg[10] = g_tfcard;
                break;
            case AUX_FACTEST_MB_ADDR(13):
                msg[9] = 0;
                msg[10] = g_di[0];
                break;
            case AUX_FACTEST_MB_ADDR(15):
                msg[9] = 0;
                msg[10] = g_di[1];
                break;
            case AUX_FACTEST_MB_ADDR(17):
                msg[9] = 0;
                msg[10] = g_di[2];
                break;
            case AUX_FACTEST_MB_ADDR(19):
                msg[9] = 0;
                msg[10] = g_di[3];
                break;
            case AUX_FACTEST_MB_ADDR(21):
                msg[9] = 0;
                msg[10] = g_di[4];
                break;
            case AUX_FACTEST_MB_ADDR(23):
                msg[9] = 0;
                msg[10] = g_di[5];
                break;
            case AUX_FACTEST_MB_ADDR(25):
                msg[9] = 0;
                msg[10] = g_di[6];
                break;
            case AUX_FACTEST_MB_ADDR(27):
                msg[9] = 0;
                msg[10] = g_di[7];
                break;
            case AUX_FACTEST_MB_ADDR(29):
                msg[9] = 0;
                msg[10] = g_net2;
                break;
            case AUX_FACTEST_MB_ADDR(31):
                msg[9] = 0;
                msg[10] = g_usb;
                break;
            case AUX_FACTEST_MB_ADDR(32):
                msg[8] = 4;  //4个字节
                msg_length = 13;
                msg[9] = MCU1_SOFTWARE_MAJOR_VERSION;
                msg[10] = MCU1_SOFTWARE_VERSION_TPYE;
                msg[11] = MCU1_SOFTWARE_STAGE_VERSION;
                msg[12] = MCU1_SOFTWARE_MINOR_VERSION;
                break;
            case AUX_FACTEST_MB_ADDR(34):
                msg[8] = 4;  //4个字节
                msg_length = 13;
                memset(g_muc2_version, 0, sizeof(g_muc2_version));
                set_constant_data(FUNCID_FACTEST_VERSION, 0 ,1);
                msg[9] = g_muc2_version[1];
                msg[10] = g_muc2_version[0];
                msg[11] = g_muc2_version[3];
                msg[12] = g_muc2_version[2];
                break;
            case AUX_FACTEST_MB_ADDR(36):
                msg[9] = MCU1_HARDWARE_MINOR_VERSION;
                msg[10] = MCU1_HARDWARE_MAJOR_VERSION;
                break;
            case AUX_FACTEST_MB_ADDR(37):
                msg[8] = 4;  //4个字节
                msg_length = 13;
                set_constant_data(FUNCID_FACTEST_VERSION, 0 ,2);
                msg[9] = pressure[2];
                msg[10] = pressure[3];
                msg[11] = pressure[0];
                msg[12] = pressure[1];
                break;
            case AUX_FACTEST_MB_ADDR(149):
                /* 消防控制器软件版本 */
                memset( &fact_info, 0xFF, sizeof( fact_info ) );
                sci_factory_get_info( FACT_INFO_TYPE_FF_SW_VER, &fact_info );
                msg[9]  = fact_info.ff_sw_ver.major_ver;
                msg[10] = fact_info.ff_sw_ver.sub_ver;
                break;
            case AUX_FACTEST_MB_ADDR(150):
                /* 消防控制器传感器类型 */
                memset( &fact_info, 0xFF, sizeof( fact_info ) );
                sci_factory_get_info( FACT_INFO_TYPE_FF_SEN_TYPE, &fact_info );
                msg[0]  = 0;
                msg[10] = fact_info.ff_sen_type;
                break;
        }

        /*  */
        if (addr >= AUX_FACTEST_MB_ADDR(39) && addr <= AUX_FACTEST_MB_ADDR(148))
        {
            msg[9] = 0;
            msg[10] = g_mcu2;
        }
        else if (addr == AUX_FACTEST_MB_ADDR(152) || addr == AUX_FACTEST_MB_ADDR(154) || addr == AUX_FACTEST_MB_ADDR(156))
        {
            msg[9] = 0;
            msg[10] = g_mcu2;
        }

        msg_length = ctx->backend->send_msg_pre(msg, msg_length); 
        ctx->backend->send(ctx, msg, msg_length);
    }
}

#if 0
static void *check_for_reboot(void *arg)
{
	while(1)
	{
		if(g_reboot_flag)
		{
            sleep(10);
            printf("ready to reboot...\n");
			system("reboot -f");
		}
        sleep(1);
	}
}
#endif
int main()
{
    int s = -1;
	int rc = 0;
	uint8_t *query = NULL;
    modbus_t *ctx = NULL;
    pthread_t reboot_tid;	

    // sci线程 
    #if 0
    if(access(FACTORY_TEST_FLAG, F_OK) == 0)
    {
        sci_task_start();
    }
    #endif
   // sci_task_start();

	ctx = modbus_new_tcp("0.0.0.0", MODBUS_TCP_PORT);
    if(ctx == NULL)
	{
		print_log("modbus open tcp faild");
        return 0;
	}
    modbus_set_debug(ctx, LOG_MODBUS_ENABLE);

    s = modbus_tcp_listen(ctx, 1);
	if(s == -1)
	{
		print_log("modbus_tcp_listen fail");
		modbus_free(ctx);	
		return 0;
	}

   // pthread_create(&reboot_tid, NULL, check_for_reboot, NULL);

    modbus_tcp_accept(ctx, &s);

    query = (uint8_t *)malloc(MODBUS_TCP_MAX_ADU_LENGTH);

    while(1)
    {		
        memset(query, 0 , MODBUS_TCP_MAX_ADU_LENGTH);
		rc = modbus_receive(ctx, query);
		if((rc != -1) && (rc != 0))
		{
			modbus_analysis(ctx, query, rc);
		}	
		else
		{
			//此段代码不可删除
			modbus_tcp_accept(ctx, &s);
		}
    }
    return 0;
}
