#ifndef __HISTORY_DRDATA__
#define __HISTORY_DRDATA__

#include "sdk_public.h"
#include "mongoose.h"


#define PATH_DR_HISTORY_FOLDER	"/media/mmcblk0p1/"

//东环系统历史数据
typedef struct
{
    sdk_rtc_t operating_time;                       // 运行时间（年、月、日、时、分、秒）
    uint16_t ff_cylinder_press;                         // 消防气瓶气压，单位：1KPa
    uint16_t mix_sensor1_co_ppm;     					// 电池仓1#复合型传感器CO浓度
    uint16_t mix_sensor2_co_ppm;     					// 电池仓2#复合型传感器CO浓度
    uint16_t mix_sensor3_co_ppm;     					// 电池仓3#复合型传感器CO浓度
    uint16_t mix_sensor4_co_ppm;     					// 电池仓4#复合型传感器CO浓度
    int16_t	 bat1_temper;            					// 电池仓1 温度
	int16_t	 bat2_temper;            					// 电池仓2 温度
	int16_t	 bat3_temper;            					// 电池仓3 温度
	int16_t	 bat4_temper;            					// 电池仓4 温度
    uint16_t bat1_humidity;          					// 电池仓1 湿度
	uint16_t bat2_humidity;          					// 电池仓2 湿度
	uint16_t bat3_humidity;          					// 电池仓3 湿度
	uint16_t bat4_humidity;          					// 电池仓4 湿度
	uint16_t lc_inlet_pressure;							// 液冷机组 进水压力
	uint16_t lc_outlet_pressure;						// 液冷机组 出水压力
	int16_t	 lc_inlet_temp;								// 液冷机组 进水温度
	int16_t	 lc_outlet_temp;							// 液冷机组 出水温度
    int16_t  lc_outdoor_temper;      					// 液冷机组 室外环境温度
    uint16_t pump_flow_rate;        					// 液冷机组 水泵流速
}dr_history_data_page_t;


/**
 * @brief 动环历史数据模块初始化
 * @return void
 */
void history_dr_data_module_init(void);

#endif