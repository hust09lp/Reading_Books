#ifndef __HOME_PAGE_H__
#define __HOME_PAGE_H__
#include"mongoose.h"

#include "op_log.h"

#define DEVICE_SN_LEN			(20)		// SN长度
#define DEVICE_SN_FILE_VALID	(0xAA55)	// SN文件有效标志

typedef struct
{
    uint16_t validity_flag;			// 文件有效性标志
    uint8_t  dev_sn[DEVICE_SN_LEN]; //设备SN
}device_sn_t;

uint8_t g_csu_comm_timeout;
typedef struct 
{
	uint8_t user_name[32]; //过滤用户名
	uint8_t op_type[64];//过滤的操作类型
	uint8_t user_role[16]; //过滤的用户角色
	uint8_t op_status[16]; //过滤的操作状态,成功还是失败
	uint8_t time_stamp[16]; //过滤使用的时间
}oplog_filter_t;
#define REASON_FILE_EMPTY 1
#define REASON_OTHER 2
#define REASON_NO_ITEM 1

#define MAX_OPERATION_ITEMS 5000   
#define MAX_MEMORY_FOR_OPLOGS (200 * 5000)    //最大只需要1M存储量

void get_submatrix_info(struct mg_connection *p_nc,struct http_message *p_msg);
void get_battery_info(struct mg_connection *p_nc,struct http_message *p_msg);
void get_operation_log(struct mg_connection *p_nc,struct http_message *p_msg);
void destory_oplog_list(operation_log_t *p_oplog_list_head);
void get_fault_log(struct mg_connection *p_nc,struct http_message *p_msg);
void export_fault_List(struct mg_connection *p_nc,struct http_message *p_msg);
void get_daily_charge_discharge(struct mg_connection *p_nc,struct http_message *p_msg);
void get_monthly_charge_discharge(struct mg_connection *p_nc,struct http_message *p_msg);
void get_yearly_charge_discharge(struct mg_connection *p_nc,struct http_message *p_msg);
void get_total_charge_discharge(struct mg_connection *p_nc,struct http_message *p_msg);
void get_daily_power(struct mg_connection *p_nc,struct http_message *p_msg);
void get_container_info(struct mg_connection *p_nc,struct http_message *p_msg);
void do_remote_power_on(struct mg_connection *p_nc,struct http_message *p_msg);
void do_remote_power_off(struct mg_connection *p_nc,struct http_message *p_msg);
void do_exhaust_fan_on(struct mg_connection *p_nc,struct http_message *p_msg);
void do_exhaust_fan_off(struct mg_connection *p_nc,struct http_message *p_msg);
void do_fault_reset(struct mg_connection *p_nc,struct http_message *p_msg);
void get_cmu_sysinfo(struct mg_connection *p_nc,struct http_message *p_msg);
void csu_set_sys_fault(struct mg_connection *p_nc,struct http_message *p_msg);
void do_energy_saving_set(struct mg_connection *p_nc,struct http_message *p_msg);
void csu_set_sys_warn(struct mg_connection *p_nc,struct http_message *p_msg);
void homepage_info_module_init(void);

/**
 * @brief    获取CMU认证版本信息
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void cmu_sys_version_info_get(struct mg_connection *p_nc,struct http_message *p_msg);

#endif

