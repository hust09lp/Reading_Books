#ifndef __UPLOAD_H__
#define __UPLOAD_H__
#include"mongoose.h"
typedef struct {
	FILE *fp;
	char file_name[32];
    char file_path[64];
	size_t file_size;
}file_info_t;

// 固件包签名信息长度
#define SIGNING_MSG_LENGTH 2048
// 读取固件每帧数据长度-解包与crc校验时使用，改此宏定义后，函数里部分代码也需要修改，如length>>10、length&0x3FF
#define DATA_LENGTH 1024
#define FIRMWARE_SIGN_LEN 1024

#define VERSION 0x02
#define TYPE_BESS_MCU_CODE 9
#define MODEL_BESS_MCU_MODEL_CODE 17
#define TYPE_POWER_MAGIC 3  //  安规文件模块类型
#define MODE_POWER_MAGIC 3  //  安规文件模块类型

enum new_file_type_num_e
{
    FILE_APP_NUM = 0x00,
    FILE_CORE_NUM,
    FILE_KERNEL_NUM,
    FILE_ROOTFS_NUM,
    FILE_SAFETY_NUM,
    FILE_PACK_NUM = 0x80,
};

#pragma pack(push,1)	//作用：是指把原来对齐方式设置压栈，并设新的对齐方式设置为一个字节对齐
/**
 * @brief  : V01版签名信息
 * @note   : 
 * @see    : 
 * @date   : 2023-03-21
 */
typedef struct firmware_msg	// 各固件信息
{
	int8_t object[8];               //固件类型
	int8_t name[32];                //固件名称
	uint8_t addr[4];                //固件起始偏移地址
	uint8_t length[4];              //固件长度
	int8_t version[20];             //固件版本号
}firmware_msg_t;
typedef struct signing_msg	// 固件包签名信息
{
	int8_t protocol_version;        //协议版本号
	int8_t company[16];             //公司名称
	int8_t type[16];                //产品型号
	int8_t package_name[32];        //固件包名称
	uint8_t release_time[6];        //固件包打包时间日期
	uint8_t module_total;           //固件模块数量
	int8_t module_config[2];        //升级选中固件配置
	int8_t reserved1[64];           //预留
	firmware_msg_t firmware_msg[27];//固件类型、名称、起始偏移地址、长度、版本号
	int8_t reserved2[66];           //预留
	uint8_t package_length[4];      //固件包总长
	uint32_t package_crc32;         //CRC32
}package_signing_msg_t;

/**
 * @brief  : V02版签名信息
 * @note   : 
 * @see    : 
 * @date   : 2023-03-21
 */
typedef struct
{
    uint8_t file_type;          // 文件类型
    uint8_t chip_role;          // 芯片角色
    uint8_t name[56];           // 固件名称
    uint32_t addr;              // 起始偏移地址
    uint32_t length;            // 长度
    uint8_t version[20];        // 版本号
    uint8_t reserved[18];       // 预留
} firmware_msg_V02_t;
typedef struct
{
    uint8_t protocol_version;           // 协议版本号
    uint8_t company[16];                // 公司名称
    uint8_t product_type_code;          // 产品类型编码
    uint16_t product_model_code;        // 产品型号编码
    uint8_t package_name[52];           // 固件包名称
    uint8_t release_time[6];            // 固件包打包日期
    uint8_t module_total;               // 固件模块数量
    uint8_t reserved1[58];              // 预留
    firmware_msg_V02_t firmware_msg[18];// 各固件信息
    uint8_t reserved2[31];              // 预留
    uint32_t package_length;            // 固件包总长
    uint32_t package_crc32;             // CRC32
} package_signing_msg_V02_t;

typedef struct
{
    uint8_t         protocol_version;   //协议版本号
    uint32_t        file_len;           //文件长度 小端模式
    uint32_t        file_crc;           //有效字节crc32
	uint8_t         chip_name[30];		 //芯片名字
    uint8_t         reserved1[40];      //预留
    int8_t          pro_name[30];            //工程名称
    uint8_t         reserved2[12];      //预留
	uint32_t 		start_addr;      //程序起始地址
	uint8_t         chip_role;   //芯片角色
	uint16_t 		chip_code;   //芯片代号
    uint8_t         file_type;          //文件类型
    uint8_t         reserved3[127];     //预留
}file_package_signature_t;
#pragma pack(pop)	//作用：恢复对齐状态
void do_handle_upload(struct mg_connection* p_nc, const int ev, void* data);
void set_upgrade_devices(struct mg_connection *p_nc,struct http_message *p_msg);
void get_upgrade_progress(struct mg_connection *p_nc,struct http_message *p_msg);
void safety_upload(struct mg_connection* nc, const int ev, void* data);
void upgrade_module_init(void);
#endif