#ifndef __ADMINISTRATOR_H__
#define __ADMINISTRATOR_H__
#include"mongoose.h"
typedef enum
{
	LOGIN_OK,
	LOGIN_FAILED,
	LOGIN_MAX
}login_status_e;
/***********************************************
功能:判断登录是否成功
输入:user_name为登录时输入的用户名,pass_word表示登录时输入的密码
输出:无
返回值:LOGIN_OK表示登录成功,LOGIN_FAILED表示登录失败
***********************************************/
login_status_e is_login_success(const uint8_t *p_user_name,const uint8_t *p_pass_word,uint8_t *role);
void do_login(struct mg_connection *p_nc,struct http_message *p_msg);
void get_user_info(struct mg_connection *p_nc,struct http_message *p_msg);
void delete_users(struct mg_connection *p_nc,struct http_message *p_msg);
void add_one_user(struct mg_connection *p_nc,struct http_message *p_msg);
void reset_password(struct mg_connection *p_nc,struct http_message *p_msg);
void edit_user_info(struct mg_connection *p_nc,struct http_message *p_msg);
void web_user_manage_module_init(void);
#endif
