#ifndef _JS_API_COMMON_H_
#define _JS_API_COMMON_H_

#include "sofar_type.h"

/**
 * @brief  json字符串下面 action 字段和用户 usr_match_action_str相匹配
 * @param  [in] req_js_str           ： json请求字符串
 * @param  [in] usr_match_action_str ： 用户匹配 action 数值字符串
 * @return SF_TRUE : action数值与 usr_match_action_str 相匹配
 * @return SF_FALSE : 不匹配
 * @note   
 */
bool js_api_common_js_str_action_val_cmp( const char *js_str, const char *usr_match_action_str );

#endif
