#ifndef __PROTECT_PARAMS_H__
#define __PROTECT_PARAMS_H__

#include"mongoose.h"

void get_protect_params(struct mg_connection *p_nc,struct http_message *p_msg);
void set_protect_params(struct mg_connection *p_nc,struct http_message *p_msg);
void get_runtime_params(struct mg_connection *p_nc,struct http_message *p_msg);
void set_runtime_params(struct mg_connection *p_nc,struct http_message *p_msg);
void get_run_storage_params(struct mg_connection *p_nc,struct http_message *p_msg);
void set_run_storage_params(struct mg_connection *p_nc,struct http_message *p_msg);
void get_eol_threshold(struct mg_connection *p_nc,struct http_message *p_msg);
void set_eol_threshold(struct mg_connection *p_nc,struct http_message *p_msg);
void protect_param_module_init(void);
#endif