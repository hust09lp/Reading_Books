#ifndef __BATTERY_INFO_H__
#define __BATTERY_INFO_H__
#include"mongoose.h"

typedef struct
{
    uint8_t communication_sta[8];                      //通讯状态,正常或者异常
    uint16_t cluster_voltage;                            // 簇端电压
    uint16_t cluster_current;                            // 簇端电流
    uint16_t cluster_SOC;
    uint16_t cluster_SOH;
    uint16_t monomer_vmax;   //单体最高电压
    uint16_t monomer_vmin;   //单体最低电压
    uint16_t monomer_vmean; //单体平均电压
    uint16_t monomer_tmax; //单体最高温度
    uint16_t monomer_tmin; //单体最低温度
    uint16_t monomer_tmean; //单体平均温度
    uint16_t precomb_temp[4]; //高压箱温度
    uint16_t insulation_resistance; //绝缘阻抗
    uint8_t precharge_relay[8]; //预充继电器
    uint8_t main_pos_relay[8];  //主正继电器
    uint8_t main_nega_relay[8]; //主负继电器
}cluster_info_t;

#define MAX_ELEC_CORE 48   //一个pack内部有48个电芯，每个电芯有对应的数据
typedef struct
{
    uint16_t voltage[MAX_ELEC_CORE];
    uint16_t temperature[MAX_ELEC_CORE];
    uint16_t soc[MAX_ELEC_CORE];
    uint16_t soh[MAX_ELEC_CORE];
}pack_info_t;
void get_battery_cluster_info(struct mg_connection *p_nc,struct http_message *p_msg);
void get_battery_pack_info(struct mg_connection *p_nc,struct http_message *p_msg);
void get_battery_cluster_charge_info(struct mg_connection *p_nc,struct http_message *p_msg);
void battery_info_module_init(void);
#endif
