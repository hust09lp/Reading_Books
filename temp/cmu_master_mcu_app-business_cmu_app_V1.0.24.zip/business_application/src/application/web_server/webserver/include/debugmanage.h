#ifndef __DEBUG_MANAGE_H__
#define __DEBUG_MANAGE_H__
#include"mongoose.h"
typedef enum
{
    MAJOR_POS_RELAY_DO1,
    MAJOR_NEGA_RELAY_DO3,
    PRECHARGE_RELAY_DO2,
    AUX_ELEC_RELAY_DO7,   //辅电继电器DO7
    RUNNING_LED_DO5,
    FAULT_LED_DO6,
    MAIN_POS_FEEDBACK_DI1,
    MAIN_NEGA_FEEDBACK_DI3,
    AUX_ELEC_SWITCH_DI2,
    EMERGENCY_STOP_DI4,
    CMUFAULT_SIGNAL_DI5,
    OUTPUT_SWITCH_FEEDBACK_DI6,
    CLUTESR_POWER_COMMAND,
    MAX_DEBUG_MANAGE = 255
}debug_manage_e;

typedef enum
{
    FC_CO_CONCENTRATION,
    FC_CO2_CONCENTRATION,
    FC_PM25_CONCENTRATION,
    FC_TEMPERATURE,
    MAX_FIRECONTROL = 255
}debug_firecontrol_e;

void get_debug_status(struct mg_connection *p_nc,struct http_message *p_msg);
void set_debug_status(struct mg_connection *p_nc,struct http_message *p_msg);
void get_debug_pcs_switch(struct mg_connection *p_nc,struct http_message *p_msg);
void set_debug_pcs_switch(struct mg_connection *p_nc,struct http_message *p_msg);
void get_debug_liquid_cooling(struct mg_connection *p_nc,struct http_message *p_msg);
void set_debug_liquid_cooling(struct mg_connection *p_nc,struct http_message *p_msg);
void get_debug_liquid_cooling_param(struct mg_connection *p_nc,struct http_message *p_msg);
void set_debug_liquid_cooling_param(struct mg_connection *p_nc,struct http_message *p_msg);
void get_debug_cmu_mode(struct mg_connection *p_nc,struct http_message *p_msg);
void set_debug_cmu_mode(struct mg_connection *p_nc,struct http_message *p_msg);
void web_reset(struct mg_connection *p_nc,struct http_message *p_msg);
void set_bat_cabinet_num(struct mg_connection *p_nc,struct http_message *p_msg);
void get_bat_cabinet_num(struct mg_connection *p_nc,struct http_message *p_msg);
void set_energy_cabinet_attr(struct mg_connection *p_nc,struct http_message *p_msg);
void get_energy_cabinet_attr(struct mg_connection *p_nc,struct http_message *p_msg);
void set_bat_cluster_pack_num(struct mg_connection *p_nc,struct http_message *p_msg);
void get_bat_cluster_pack_num(struct mg_connection *p_nc,struct http_message *p_msg);
void set_energy_cabinet_sn(struct mg_connection *p_nc,struct http_message *p_msg);
void get_energy_cabinet_sn(struct mg_connection *p_nc,struct http_message *p_msg);
void set_ft_cap_test_mode(struct mg_connection *p_nc,struct http_message *p_msg);
void web_clear_data(struct mg_connection *p_nc,struct http_message *p_msg);
void get_ft_cap_test_mode(struct mg_connection *p_nc,struct http_message *p_msg);
void debug_param_module_init(void);

#endif