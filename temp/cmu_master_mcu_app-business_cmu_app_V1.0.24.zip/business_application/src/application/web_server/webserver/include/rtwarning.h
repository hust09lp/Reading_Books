#ifndef __RT_WARNING_H__
#define __RT_WARNING_H__

#include"mongoose.h"
#define MAX_PACK 8

void get_real_time_warning(struct mg_connection *p_nc,struct http_message *p_msg);
void warning_info_module_init(void);
#endif