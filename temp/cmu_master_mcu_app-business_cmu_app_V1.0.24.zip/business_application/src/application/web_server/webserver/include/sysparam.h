#ifndef __SYSPARAM_H__
#define __SYSPARAM_H__
#include"mongoose.h"

#define  NET_ADDR_LEN_MAX                       16      // IP地址长度最大值
typedef struct{
    uint16_t address_rs485_4;                       // RS485-4地址
    uint32_t baud_rate_rs485_4;                     // RS485-4波特率
    uint16_t stop_bit_rs485_4;                      // RS485-4停止位
    uint16_t check_bit_rs485_4;                     // RS485-4校验位

    uint16_t address_rs485_6;                       // RS485-6地址
    uint32_t baud_rate_rs485_6;                     // RS485-6波特率
    uint16_t stop_bit_rs485_6;                      // RS485-6停止位
    uint16_t check_bit_rs485_6;                     // RS485-6校验位

    uint8_t addr_IP_ETH_1[NET_ADDR_LEN_MAX];        // ETH-1 IP地址
    uint16_t num_port_ETH_1;                        // ETH-1 端口号
    uint8_t addr_IP_server_ETH_1[NET_ADDR_LEN_MAX]; // ETH-1 服务器IP地址
    uint16_t numr_port_server_ETH_1;                // ETH-1 服务器端口号
    uint8_t addr_IP_ETH_3[NET_ADDR_LEN_MAX];        // ETH-3 IP地址
    uint16_t num_port_ETH_3;                        // ETH-3 端口号
    uint8_t addr_IP_server_ETH_3[NET_ADDR_LEN_MAX]; // ETH-3 服务器IP地址
    uint16_t numr_port_server_ETH_3;                // ETH-3 服务器端口号

    uint16_t remote_on_off_ctrl;                    // 远程开关机 0-关机 1-开机
    uint16_t LC_on_off_ctrl;                        // 液冷系统开关机 手动模式下才生效 0-关机 1-开机  
	uint16_t EF_on_off_ctrl;                        // 排气扇开关机 0-关机 1-开机  

    uint16_t state_ctr;                             // 工厂模式-状态控制字；Bit0-Bit7：工厂模式使能位 单板测试使能位 T1完成标志 老化完成标志 T2完成标志 包装测试完成标志 电池老化模式使能 电池激活
    uint16_t privilege_ctrl_word;                   // 工厂模式-特权控制字；每位写入0无效，写入1有效。Bit0：清除校准系数 Bit1：清除运行数据 Bit2：清除故障录波

}device_paramater_other_t;

void get_system_param(struct mg_connection *p_nc,struct http_message *p_msg);
void set_system_param(struct mg_connection *p_nc,struct http_message *p_msg);
void get_com_params(struct mg_connection *p_nc,struct http_message *p_msg);
void set_com_params(struct mg_connection *p_nc,struct http_message *p_msg);
void web_sys_param_module_init(void);
#endif