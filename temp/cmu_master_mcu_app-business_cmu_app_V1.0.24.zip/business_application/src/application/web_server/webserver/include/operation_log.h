#ifndef __OPERATION_LOG_H__
#define __OPERATION_LOG_H__

#include "homepage.h"

#define OPERATION_LOG_LATEST_5_ITEM     (5)
#define MAX_OPERATION_ITEMS             5000   
#define MAX_MEMORY_FOR_OPLOGS           (200 * 5000)    //最大只需要1M存储量


/**
 * @brief   初始化操作日志结构体
 * @param   [in] 操作日志结构体指针
 * @param   [out] 操作日志结构体指针
 * @return  无
 */
void init_user_basic_info(operation_log_t *oplog);

/**
 * @brief   根据已知信息获取账户中的其他信息
 * @return  无
 */
void get_user_basic_info(operation_log_t *p_oplog);


/**
 * @brief   获取操作日志
 * @param   [in] p_nc 表示http连接指针
 * @param   [in] p_msg 表示http连接的请求体内容
 * @return  无
 */
void get_operation_log(struct mg_connection *p_nc,struct http_message *p_msg);

/**
 * @brief  操作日志配置初始化
 * @param  
 * @param  
 * @return
 */
void operation_log_conf_init(void);

/**
 * @brief  	首页页面获取要显示的最新的5条操作日志数据
 * @param  	[out] p_data        操作日志的数据指针
 * @param  	[out] p_data_num    实际获取到操作日志的条数
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t home_page_operation_log_latest_5_item_get(void *p_data, uint32_t *p_data_num);

/**
 * @brief  获取 记录
 * @param  [in] *p_nc 连接信息 
 * @param  [in] *p_msg  http请求信息
 * @return
 */
void export_operation_List(struct mg_connection *p_nc,struct http_message *p_msg);

/**
 * @brief  根据操作日志获取对应的ID号
 * @param  [in] *operationlog_text 操作日志文本 
 * @return
 */
int32_t get_operationid_by_name(const char *operationlog_text);

/**
 * @brief  添加新操作日志
 * @param  [in] p_op_usr_name : 操作用户名称
 * @param  [in] p_op_str      : 操作内容
 * @param  [in] op_success    : 操作结果
 * @param  [in] op_par1       : 原先操作参数数值
 * @param  [in] op_par2       : 现有操作参数数值
 * @return
 */
void usr_add_one_op_log( const char *p_op_usr_name, const char *p_op_str, bool op_success, double op_par1, double op_par2 );

#endif