/*****************************************************************************
* File Name          : operating_pcs_data_handle.h            
* Description        : 运行数据处理（更新、保存）内外部通讯接口
* Original Author    : yunzhen
* date               : 2023.04.26
******************************************************************************/

#ifndef __POWER_HISTORY_H__ 
#define __POWER_HISTORY_H__ 


#include "data_shm.h"
#include "sdk_public.h"
// 打印开关
#if (1)
#define POWER_DEBUG_LOG(...) printf(__VA_ARGS__);
#else
#define POWER_DEBUG_LOG(...) {do {} while(0);}
#endif

// #define PATH_OPERATING_RECORD_FOLDER	"/media/mmcblk0p1/" //运行数据存储的文件夹
//#define PATH_OPERATING_RECORD_FOLDER    "/user/data/opt_record/"		//运行数据存储的文件夹
#define PATH_HISTORYFILE    "/tmp/history.csv"
#define PATH_FILE_MAX_LEN   (60)        //文件路径的最大长度

#define OPERATING_DATA_READ_MAX_COUNT    480    /* 一个文件（一天）读取的最大次数（最大理论值，3min保存一次的运行数据） 24*60/3 = 480 */

#if 0
#pragma pack(push)
#pragma pack(1)


/**
 * @struct telematic_operating_data_t
 * @brief 遥信运行数据结构体定义。
 */

typedef struct
{
    uint8_t pcs_system_cabinet_status_info[PCS_CABINET_SYSTEM_STATUS_LEN_BYTE];             // PCS系统柜（状态信息）
    uint8_t pcs_system_cabinet_fault_info[PCS_CABINET_SYSTEM_FAULT_LEN_BYTE];                 // PCS系统柜（故障信息）
    telematic_info_t pcs_module[PCS_CABINET_POWER_MODULE_NUM];							// PCS系统柜功率模块
}telematic_operating_pcs_data_t;



/**
 * @struct telemetry_operating_data_t
 * @brief 遥测运行数据结构体定义。
 */
typedef struct
{
    pcs_cabinet_telemetry_info_t pcs_cabinet_telemetry_info;                  		// PCS系统柜遥测数据
    pcs_version_telemetry_info_t pcs_version_telemetry_info;                                    // PCS柜版本信息
    pcs_module_version_telemetry_info_t pcs_module_version_telemetry_info[PCS_CABINET_POWER_MODULE_NUM];    // PCS模块版本信息                                // PCS模块版本信息
    power_module_telemetry_info_t power_module_telemetry_info[PCS_CABINET_POWER_MODULE_NUM];    // 功率模块遥测数据
}telemetry_operating_pcs_data_t;


/**
 * @brief 历史功率定值数据结构体定义。
 */

typedef struct
{
    int16_t active_power;                           // 有功功率
    int16_t reactive_power;                         // 无功功率          

}history_constant_parameter_t;
/**
 * @struct operating_pcs_data_t
 * @brief 运行数据结构体定义。
 */
typedef struct
{
    sdk_rtc_t operating_time;    // 运行时间（年、月、日、时、分、秒）
    telematic_operating_pcs_data_t telematic_operating_data;    // 遥信运行数据
    telemetry_operating_pcs_data_t telemetry_operating_data;    // 遥测运行数据
    history_constant_parameter_t history_constant_parameter;
    uint32_t crc;           // CRC校验
}operating_pcs_data_t;
#pragma pack(pop)
#endif

void get_power_list(struct mg_connection *p_nc,struct http_message *p_msg);

void export_history_List(struct mg_connection *p_nc,struct http_message *p_msg);
void power_history_module_init(void);
#endif  /* __OPERATING_DATA_HANDLE_H__ */