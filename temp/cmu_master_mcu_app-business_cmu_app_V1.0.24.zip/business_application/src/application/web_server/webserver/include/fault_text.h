/** 
 * @file          fault_text.h
 * @brief         故障文本接口函数说明
 * @author        liangguyao
 * @version       V0.0.1     初始版本
 * @date          2023/05/18
 * @copyright     Copyright (c) 2023 by SofarSolar, All Rights Reserved.
 */


#ifndef __FAULT_TEXT_H__
#define __FAULT_TEXT_H__


#include "data_types.h"


#if (0)
#define WEB_FAULT_TEXT_PRINT(...) printf(__VA_ARGS__);
#else
#define WEB_FAULT_TEXT_PRINT(...)
#endif

#define FAULT_NAME_TEXT_LEN         (128)        // 故障名称最大长度
#define FAULT_RESTORE_TEXT_LEN         (512) 

#define COOLED_FAULT_BUFF_LEN (200 * 250)   // 液冷故障字符缓存buff长度

#define MIDEA_COOLED_FAULT_JSON         "/user/conf/midea_cooled_fault.json"
#define AIRCONDITION_COOLED_FAULT_JSON  "/user/conf/aircondition_cooled_fault.json"
#define VISUAL_COOLED_FAULT_JSON        "/user/conf/visual_cooled_fault.json"

typedef enum{
  MIDEA_COOLED_DEV_ID = 0,      // 美的
  AIRCONDITION_COOLED_DEV_ID,   // 空调国际
  VISUAL_COOLED_DEV_ID,         // 视源
  COOLED_DEV_ID_END,
}cooled_dev_id_e;

typedef enum{
  COOLED_FIELD_FAULT_NAME = 1,      // 字段：故障名称
  COOLED_FIELD_FAULT_REASON,          // 字段：故障原因
  COOLED_FIELD_FAULT_RESOLVENT,          // 字段：故障建议
  COOLED_FIELD_FAULT_END,
}cooled_fault_type_e;

typedef enum{
  FAULT_TEXT_LANGUAGE_CHINESE,     //中文显示
  FAULT_TEXT_LANGUAGE_ENGLISH,    //英文显示
  FAULT_TEXT_LANGUAGE_END,
}fault_text_language_e;

/**
 * @brief  	根据索引，获取CMU的故障显示文本
 * @param  	[in] index 	索引
 * @param  	[out] buff 	获取到的CMU故障显示文本
 * @return 	执行结果
 * @retval  =0: 成功
 * @retval  <0: 失败，返回错误代码
 */
int32_t cmu_fault_text_get(const fault_text_language_e lan, uint8_t index, int8_t *buff);
int32_t cmu_reason_fault_text_get(const fault_text_language_e lan, uint8_t index, int8_t *buff);
int32_t cmu_restore_fault_text_get(const fault_text_language_e lan, uint8_t index, int8_t *buff);

/**
 * @brief  	根据索引，获取集装箱的故障显示文本
 * @param  	[in] index 	索引
 * @param  	[out] buff 	获取到的集装箱故障显示文本
 * @return 	执行结果
 * @retval  =0: 成功
 * @retval  <0: 失败，返回错误代码
 */
int32_t container_fault_text_get(const fault_text_language_e lan, uint8_t index, int8_t *buff);
int32_t container_reason_fault_text_get(const fault_text_language_e lan, uint8_t index, int8_t *buff);
int32_t container_restore_fault_text_get(const fault_text_language_e lan, uint8_t index, int8_t *buff);


/**
 * @brief  	根据索引，获取集装箱的故障显示文本
 * @param  	[in] dev_id 设备id
 * @param  	[in] field_index 	字段索引
 * @param  	[in] fault_id 	故障id
 * @param  	[out] buff 	获取到的集装箱故障显示文本
 * @return 	执行结果
 * @retval  =0: 成功
 * @retval  <0: 失败，返回错误代码
 */
int32_t cooled_fault_reason_get(const fault_text_language_e lan, const uint8_t dev_id, const uint8_t field_index, const uint8_t fault_id, uint8_t *buff);


/**
 * @brief  	根据索引，获取电池簇的故障显示文本
 * @param  	[in] index 	索引
 * @param  	[out] buff 	获取到的电池簇故障显示文本
 * @return 	执行结果
 * @retval  =0: 成功
 * @retval  <0: 失败，返回错误代码
 */
int32_t cluster_fault_text_get(const fault_text_language_e lan, uint8_t index, int8_t *buff);
int32_t cluster_reason_fault_text_get(const fault_text_language_e lan, uint8_t index, int8_t *buff);
int32_t cluster_restore_fault_text_get(const fault_text_language_e lan, uint8_t index, int8_t *buff);

/**
 * @brief  	根据索引，获取PCS模块的故障显示文本
 * @param  	[in] index 	索引
 * @param  	[out] buff 	获取到的PCS模块故障显示文本
 * @return 	执行结果
 * @retval  =0: 成功
 * @retval  <0: 失败，返回错误代码
 */
int32_t pcs_fault_text_get(const fault_text_language_e lan, uint8_t index, int8_t *buff);
int32_t pcs_reason_fault_text_get(const fault_text_language_e lan, uint8_t index, int8_t *buff);
int32_t pcs_restore_fault_text_get(const fault_text_language_e lan, uint8_t index, int8_t *buff);

#endif /* __FAULT_TEXT_H__ */
