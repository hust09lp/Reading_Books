/** 
 * @file          web_data_interface.h
 * @brief         WEB数据接口函数说明
 * @author        liangguyao
 * @version       V0.0.1     初始版本
 * @date          2023/04/11
 * @copyright     Copyright (c) 2023 by SofarSolar, All Rights Reserved.
 */


#ifndef __WEB_DATA_INTERFACE__
#define __WEB_DATA_INTERFACE__


#include "data_types.h"
#include "data_shm.h"
#include "sdk_public.h"
#include "event_record_task.h"
#include <stdbool.h>


#if (0)
#define WEB_DEBUG_PRINT(...) printf(__VA_ARGS__);
#else
#define WEB_DEBUG_PRINT(...)
#endif

#define FUALT_LOG_LATEST_5_ITEM (5)


#pragma pack(push)
#pragma pack(1)
typedef struct
{
    // 集装箱
    uint16_t cmu_sys_state;             // 0:停机状态 1:待机状态 2:运行状态 3:故障状态 4:升级状态
    int16_t  total_voltage;             // 总电压
    int16_t  total_current;             // 总电流
    int16_t  charge_discharge_power;    // 充放电功率
    uint16_t average_SOC;               // SOC平均值
    // 温湿度传感器
    int16_t  cabinet_temperature1;      // 箱内温度T1 -> 设备舱温度
    int16_t  cabinet_temperature2;      // 箱内温度T2 -> 电池舱温度
    uint16_t cabinet_humidity1;         // 箱内湿度H1 -> 设备舱湿度
    uint16_t cabinet_humidity2;         // 箱内湿度H2 -> 电池舱湿度
    // 液冷机组
    int16_t  outlet_temperature_LC;     // 液冷机组出水温度
    int16_t  inlet_temperature_LC;      // 液冷机组回水温度
    uint16_t outlet_pressure_LC;        // 液冷机组出水压力
    uint16_t inlet_pressure_LC;         // 液冷机组回水压力

    uint16_t run_mode_LC;               // 液冷运行模式

    uint8_t  battery_door_status;       // 电池舱门磁状态
    uint8_t  battery_flood_status;      // 电池舱水浸状态
    uint8_t  equipment_door_status;     // 设备舱门磁状态
    uint8_t  equipment_flood_status;    // 电池舱水浸状态
    uint8_t  chg_dischg_forbid;         // 禁充禁放标志位 1-禁充 2-禁放 3-禁充禁放
    uint16_t lc_sofar_mode;             // 首航热管理模式 2-预冷 3-预热 5-消防联动

     // 消防
    uint16_t fire_fan_start1_CO;                        // 联动时复合型传感器1的CO浓度值
    uint16_t fire_fan_start2_CO;                        // 联动时复合型传感器2的CO浓度值
    uint16_t fire_fan_start3_CO;                        // 联动时复合型传感器3的CO浓度值
    uint16_t fire_fan_start4_CO;                        // 联动时复合型传感器4的CO浓度值
    uint16_t fire_fan_start1_PM25;                      // 联动时复合型传感器1的PM2.5浓度值
    uint16_t fire_fan_start2_PM25;                      // 联动时复合型传感器2的PM2.5浓度值
    uint16_t fire_fan_start3_PM25;                      // 联动时复合型传感器3的PM2.5浓度值
    uint16_t fire_fan_start4_PM25;                      // 联动时复合型传感器4的PM2.5浓度
    // 消防复合型传感器
    int16_t composite_sensor1_temp;                     // 1#复合型传感器温度
    uint16_t composite_sensor1_CO;                      // 1#复合型传感器CO浓度
    uint16_t composite_sensor1_PM25;                    // 1#复合型传感器PM2.5浓度
    int16_t composite_sensor2_temp;                     // 2#复合型传感器温度
    uint16_t composite_sensor2_CO;                      // 2#复合型传感器CO浓度
    uint16_t composite_sensor2_PM25;                    // 2#复合型传感器PM2.5浓度
    int16_t composite_sensor3_temp;                     // 3#复合型传感器温度
    uint16_t composite_sensor3_CO;                      // 3#复合型传感器CO浓度
    uint16_t composite_sensor3_PM25;                    // 3#复合型传感器PM2.5浓度
    int16_t composite_sensor4_temp;                     // 4#复合型传感器温度
    uint16_t composite_sensor4_CO;                      // 4#复合型传感器CO浓度
    uint16_t composite_sensor4_PM25;                    // 4#复合型传感器PM2.5浓度
    uint16_t composite_resv[4];                         // 预留
    int16_t chg_limit_power;                            // 充电限制功率
    int16_t dischg_limit_power;                         // 放电限制功率
}home_page_container_t;

typedef struct
{
	//0x14301
	int16_t grid_volt_rs;				//遥测信息：电网相电压RS  0.1V
	int16_t grid_volt_st;				//遥测信息：电网相电压ST  0.1V
	int16_t grid_volt_tr;				//遥测信息：电网相电压TR  0.1V
	int16_t grid_freq;					//遥测信息：电网频率	  0.01 Hz
	int16_t ac_current_r;				//遥测信息：交流侧电流R相 0.1A
	int16_t ac_current_s;				//遥测信息：交流侧电流S相 0.1A
	int16_t ac_current_t;				//遥测信息：交流侧电流T相 0.1A
	int16_t bus_volt_pn;				//遥测信息：母线电压  0.1V
	int16_t bat_volt;					//遥测信息：电池电压  0.1V
	uint16_t iso_resistence;			//遥测信息：绝缘阻抗检测阻抗值 1kOhm
	int16_t active_power;				//有功功率，放电为正，充电为负                 0.01kW
	int16_t reactive_power;				//无功功率，逆变器端超前为正，滞后为负  0.01kVar
	int16_t apparent_power;				//视在功率 0.01kVA
	int16_t amb_temp;					//环境温度0.1℃
	int16_t power_factor;    			//功率因数
	uint16_t Running_Hours_L;			//PCS模块累计运行时间(低16位)
	uint16_t Running_Hours_H;			//PCS模块累计运行时间(高16位)
	int16_t Active_Power_R;				//R相有功功率
	int16_t Active_Power_S;				//S相有功功率
	int16_t Active_Power_T; 			//T相有功功率
	int16_t Reactive_Power_R;			//R相无功功率
	int16_t Reactive_Power_S;			//S相无功功率
	int16_t Reactive_Power_T; 			//T相无功功率
	int16_t Apparent_Power_R;			//R相视在功率
	int16_t Apparent_Power_S;			//S相视在功率
	int16_t Apparent_Power_T;			//T相视在功率
	uint16_t System_Time_Second;		//系统时间-秒
	uint16_t System_Time_Minute;		//系统时间-分
	uint16_t System_Time_Hour;			//系统时间-时
	uint16_t System_Time_Day;			//系统时间-天
	uint16_t System_Time_Month;			//系统时间-月
	uint16_t System_Time_Year;			//系统时间-年
	int16_t En_Grid_Current_R;         //入网侧电流R相
	int16_t	En_Grid_Current_S;			//入网侧电流S相
	int16_t	En_Grid_Current_T;			//入网侧电流T相
	// int16_t QvarInsRef;					//无功功率瞬时给定，发容性无功为正，感性为负
	// uint16_t rev1[23];                  //预留
	//0x14333
	int16_t grid_volt_r;				//遥测信息：电网相电压R  0.1V
	int16_t grid_volt_s;				//遥测信息：电网相电压S  0.1V
	int16_t grid_volt_t;				//遥测信息：电网相电压T  0.1V
	int16_t n_to_pe_volt;				//遥测信息：相对地电压  0.1V
	int16_t dci_r;						//遥测信息：R相电流直流偏置  1mA
	int16_t dci_s;						//遥测信息：S相电流直流偏置  1mA
	int16_t dci_t;						//遥测信息：T相电流直流偏置  1mA
	int16_t gfci;						//遥测信息：漏电流  0.1mA
	int16_t bus_volt_p;					//遥测信息：正半母线电压  0.1V
	int16_t bus_volt_n;					//遥测信息：正半母线电压  0.1V
	int16_t igbt_temp_ra;				//模块Ra温度 0.1℃
	int16_t igbt_temp_sa;				//模块Sa温度 0.1℃
	int16_t igbt_temp_ta;				//模块Ta温度 0.1℃
	int16_t igbt_temp_rb;				//模块Rb温度 0.1℃
	int16_t igbt_temp_sb;				//模块Sb温度 0.1℃
	int16_t igbt_temp_tb;				//模块Tb温度 0.1℃
	int16_t slv_grid_volt_r;			//副DSP采样R相电网电压 0.1V
	int16_t slv_grid_volt_s;			//副DSP采样S相电网电压 0.1V
	int16_t slv_grid_volt_t;			//副DSP采样T相电网电压 0.1V
	uint16_t Fan_Speed_Inner1;			//内部风扇1转速
	uint16_t Fan_Speed_Inner2;			//内部风扇2转速
	uint16_t Fan_Speed_Outer1;			//外部风扇1转速
	uint16_t Fan_Speed_Outer2;			//外部风扇2转速
	uint16_t Fan_Speed_Outer3;			//外部风扇3转速
	uint16_t Fan_Speed_Outer4;			//外部风扇4转速
	int16_t energy_discharge_l;         //模块累计放电量低16位(与高16位组合，按I32解析)
    int16_t energy_discharge_h;        	//模块累计放电量高16位(与低16位组合，按I32解析)
    int16_t energy_charge_l;            //模块累计充电量低16位(与高16位组合，按I32解析)
    int16_t energy_charge_h;        	//模块累计充电量高16位(与低16位组合，按I32解析)
	uint16_t rev1[9];                  //预留
	int16_t bat_current;				//遥测信息：电池电流  0.1A
	uint16_t iso_det_state;				//绝缘阻抗检测结果       	1
	int16_t iso_volt_to_pe;				//Iso对地电压			0.1V
	uint16_t rev2[10];                  //预留
	//30000
	uint16_t startup_para_checksum;			// 安规参数中启动参数校验和
	uint16_t voltage_para_checksum;			// 安规参数中电压参数校验和
	uint16_t freq_para_checksum;			// 安规参数中频率参数校验和
	uint16_t dci_para_checksum;				// 安规参数中DCI保护参数校验和
	uint16_t remote_active_para_checksum;	// 安规参数中远程及有功参数校验和
	uint16_t freq_active_para_checksum;		// 安规参数中频率有功参数校验和
	uint16_t reactive_para_checksum;		// 安规参数中无功参数校验和
	uint16_t volt_cross_para_checksum;		// 安规参数中电压穿越参数校验和
	uint16_t iso_anti_island_para_checksum; // 安规参数中ISO孤岛参数校验和
	uint16_t rev3[9];
}home_page_pcs_info_t;   


typedef struct
{
    uint8_t  BCU_comm_status;                   // BCU通信状态 0-未连接 1-通信正常 2-通信中断
    int16_t  cluster_voltage;                   // 簇端电压  精度：0.1V 偏移量：0
    int16_t  cluster_current;                   // 簇端电流  精度：0.1A 偏移量：-1600
    uint16_t cluster_SOC;                       // 簇端SOC  精度：1%   偏移量：0
    uint16_t average_SOH_monomer;               // 单体SOH平均值SOHmean  精度：1% 偏移量：0 范围：0-100
    int16_t  highest_monomer_voltage;           // 单簇最高单体电压Umax  精度：0.001V 偏移量：0
    int16_t  lowest_monomer_voltage;            // 单簇最低单体电压Umin  精度：0.001V 偏移量：0
    int16_t  average_voltage_monomer;           // 单体电压平均值Umean  精度：0.001V 偏移量：0
    int16_t  highest_monomer_temperature;       // 单簇最高单体温度Tmax  精度：1℃ 偏移量：-40
    int16_t  lowest_monomer_temperature;        // 单簇最低单体温度Tmin  精度：1℃ 偏移量：-40
    int16_t  average_temperature_monomer;       // 单体温度平均值Tmean  精度：1℃ 偏移量：-40
    int16_t  high_pressure_box_temperature1;    // 高压箱温度T1-T4  精度：1℃ 偏移量：-40
    int16_t  high_pressure_box_temperature2;    // 高压箱温度T1-T4  精度：1℃ 偏移量：-40
    int16_t  high_pressure_box_temperature3;    // 高压箱温度T1-T4  精度：1℃ 偏移量：-40
    int16_t  high_pressure_box_temperature4;    // 高压箱温度T1-T4  精度：1℃ 偏移量：-40
    uint16_t positive_insulation_resistance;    // 正绝缘阻抗  精度：1KΩ 偏移量：0
    uint16_t negative_insulation_resistance;    // 负绝缘阻抗  精度：1KΩ 偏移量：0
    uint16_t battery_node_highest_voltage;      // 单簇最高单体电压的电池节号
    uint16_t battery_node_lowest_voltage;       // 单簇最低单体电压的电池节号
    uint16_t battery_node_highest_temperature;  // 单簇最高单体温度的电池节号
    uint16_t battery_node_lowest_temperature;   // 单簇最低单体温度的电池节号

    uint8_t  positive_relay_status;             // 主正继电器
    uint8_t  negative_relay_status;             // 主负继电器

    uint32_t cluster_cap_energy;                // 电池簇容量，单位： 0.01KWH
}web_battery_cluster_t;

typedef struct
{
    web_battery_cluster_t battery_cluster_info[BCU_DEVICE_NUM];
}battery_cluster_page_t;

typedef struct
{
    int16_t pole_temperater_PACK[POLE_TEMP_NUM_IN_PACK];    // PACK的极柱温度T1-T2  精度：1℃ 偏移量：-40
    int16_t monomer_voltage[MONOMER_NUMBER_IN_PACK];        // PACK的单体电压Uc1-Uc48  精度：0.001V 偏移量：0
    int16_t monomer_temperature[MONOMER_NUMBER_IN_PACK];    // PACK的单体温度Tc1-Tc48  精度：1℃ 偏移量：-40
    uint16_t monomer_SOC[MONOMER_NUMBER_IN_PACK];           // PACK的单体SOC 1-48  精度：1% 偏移量：0 范围：0-100
    uint16_t monomer_SOH[MONOMER_NUMBER_IN_PACK];           // PACK的单体SOH 1-48  精度：1% 偏移量：0 范围：0-100
}web_monomer_info_t;

typedef struct
{
    uint8_t container_system_warn_info[CONTAINER_SYSTEM_WARN_LEN_BYTE];                 // 集装箱系统（告警信息） 0xA1~0xD8   预留 0xD9~0x100
    uint8_t container_system_fault_info[CONTAINER_SYSTEM_FAULT_LEN_BYTE];               // 集装箱系统（故障信息） 0x101~0x138 预留 0x139~0x150
    uint8_t battery_cluster_warn_info[BCU_DEVICE_NUM][BATTERY_CLUSTER_WARN_LEN_BYTE];   // 集装箱内电池簇（告警信息） 0x171~0x1B8 预留 0x1B9~0x200
    uint8_t battery_cluster_fault_info[BCU_DEVICE_NUM][BATTERY_CLUSTER_FAULT_LEN_BYTE]; // 集装箱内电池簇（故障信息） 0x201~0x228 预留 0x229~0x250
}realtime_warn_page_t;

typedef struct
{
    uint8_t container_system_status_info[CONTAINER_SYSTEM_STATUS_LEN_BYTE];             // 集装箱系统（状态信息） 0x31~0x88   预留 0x89~0xA0
}container_status_info_t;

typedef struct
{
    sdk_rtc_t operating_time;                       // 运行时间（年、月、日、时、分、秒）
    int16_t   cluster_voltage;                      // 簇端电压  精度：0.1V 偏移量：0
    int16_t   cluster_current;                      // 簇端电流  精度：0.1A 偏移量：-1600
    uint16_t  cluster_SOC;                          // 簇端SOC  精度：1%   偏移量：0
    uint16_t  average_SOH_monomer;                  // 单体SOH平均值SOHmean  精度：1% 偏移量：0 范围：0-100
    int16_t   highest_monomer_voltage_cluster;      // 单簇最高单体电压Umax  精度：0.001V 偏移量：0
    int16_t   lowest_monomer_voltage_cluster;       // 单簇最低单体电压Umin  精度：0.001V 偏移量：0
    int16_t   average_voltage_monomer;              // 单体电压平均值Umean  精度：0.001V 偏移量：0
    int16_t   highest_monomer_temperature_cluster;  // 单簇最高单体温度Tmax  精度：1℃ 偏移量：-40
    int16_t   lowest_monomer_temperature_cluster;   // 单簇最低单体温度Tmin  精度：1℃ 偏移量：-40
    int16_t   average_temperature_monomer;          // 单体温度平均值Tmean  精度：1℃ 偏移量：-40
    int16_t   high_pressure_box_temperature1;       // 高压箱温度T1-T4  精度：1℃ 偏移量：-40
    int16_t   high_pressure_box_temperature2;       // 高压箱温度T1-T4  精度：1℃ 偏移量：-40
    int16_t   high_pressure_box_temperature3;       // 高压箱温度T1-T4  精度：1℃ 偏移量：-40
    int16_t   high_pressure_box_temperature4;       // 高压箱温度T1-T4  精度：1℃ 偏移量：-40
    uint16_t  positive_insulation_resistance;       // 正绝缘阻抗  精度：1KΩ 偏移量：0
    uint16_t  negative_insulation_resistance;       // 负绝缘阻抗  精度：1KΩ 偏移量：0
    web_monomer_info_t monomer_info[PACK_NUMBER];   // PACK1-8的详细单体数据
}history_data_page_t;

typedef struct
{
    uint8_t battery_cluster_status_info[BCU_DEVICE_NUM][BATTERY_CLUSTER_STATUS_LEN_BYTE];   // 集装箱内电池簇（状态信息） 0x151~0x160 预留 0x161~0x170
}debug_manage_page_read_t;
#pragma pack(pop)


#pragma pack(push)
#pragma pack(1)
typedef struct
{   
    other_parameter_data_t other_parameter_data_update;
	uint8_t other_parameter_update_flag[5];          		// 更新标志 0-无效  1-有效 数组[0]为RS485-4 数组[1]为RS485-6 数组[2]为ETH-1  数组[3]为ETH-1

    /************ 遥控标志（每bit代表一个遥控量，具体对应见104点表） ************/
    uint16_t CMU_system_control_on;                   // CMU-1系统遥控  bit0-远程开机  bit1-液冷系统开机 bit2-PCS开机 bit3-排气扇开机，0-不使能  1-使能
    uint16_t CMU_system_control_off;                  // CMU-1系统遥控  bit0-远程关机  bit1-液冷系统关机 bit2-PCS关机 bit3-排气扇关机，0-不使能  1-使能

    uint16_t battery_power_on;                        // 电池簇上电 bit0-对应第一簇(0xE8) bit9-对应第十簇(0xF1)，0-不使能  1-使能
    uint16_t battery_power_off;                       // 电池簇下电 bit0-对应第一簇(0xE8) bit9-对应第十簇(0xF1)，0-不使能  1-使能

    uint8_t  battery_power_off_all;                   // 所有簇下电，0-不使能  1-使能

    // bit0-主正接触器控制 bit1-环流接触器控制 bit2-主负接触器控制 bit3-脱扣线束预留 bit4-指示灯(绿灯) bit5-指示灯(红灯) bit6-辅助接触器控制 bit7-预留，0-不使能  1-使能
    uint8_t battery_DO_control_on[BCU_DEVICE_NUM];    // 电池簇DO控制输出有效 [0]-对应第一簇(0xE8)  [9]-对应第十簇(0xF1)
    uint8_t battery_DO_control_off[BCU_DEVICE_NUM];   // 电池簇DO控制输出无效 [0]-对应第一簇(0xE8)  [9]-对应第十簇(0xF1)
    
    /************ 参数下发标志 ************/
    uint8_t battery_threshold_update_flag;            // 电池阈值更新标志 0-无效  1-有效
    uint8_t liquid_cooling_param_update_flag;         // 液冷参数下发 0-无效  1-有效
    uint8_t cmu_mode_update_flag;         			  // CMU模式设置 0-无效  1-有效
    uint8_t sys_reset;								  // 恢复出厂设置
    uint8_t bat_cabinet_num_update_flag;
    uint8_t enenrgy_cabinet_attr_update_flag;
    uint8_t energy_saving_power_halt_flag;
    uint8_t charge_discharge_soc_limit_set_flag;
	uint8_t pack_num_set_flag;
	uint8_t dev_sn_set_flag;
	uint8_t eol_threshold_set_flag;   //更新SOH阈值
    uint8_t clear_history_data_flag;  // 清除历史数据 1-有效

    uint8_t sync_systime_flag;      //  同步系统时间
    uint8_t low_power_setting_flag;                     //  低功耗设置  bit0: web设置低功耗信息
	uint8_t battery_cap_test_set_flag;                  //  bit0: 电池容测 1：设置容测模式
	uint8_t keep_warm_param_set_flag;                   //  1: 设置保温模式参数
	uint16_t pcs_powerup_gradident_setvalue;		  // PCS功率软启时间梯度设置值
	uint8_t pcs_powerup_gradident_set_flag;				// PCS功率软启时间梯度设置标志 1：有效
	uint8_t external_epo_type_set_flag;					// 外置EPO输入类型设置 0：常开  1：常闭
    uint8_t run_storage_param_update_flag;				// 运行数据存储参数更新标志 1：有效
    uint8_t external_protocol_set_flag;                 // 设置外置协议
    uint16_t pcs_factory_mode_set_value;				// PCS工厂模式设置值
	uint8_t pcs_factory_mode_set_flag;					// PCS工厂模式设置标志 1：有效
}debug_manage_page_write_t;

typedef struct
{
    uint8_t bat_software_version[2];                  // 大版本号数值+小版本号数值  原型：01.03
    uint8_t bat_hardware_version[2];                  // 大版本号数值+小版本号数值  原型：V1.0
    uint8_t mcu2_core_soft_version[4];                // 版本标识ASCII码+主版本数值+次版本数值+阶段版本数值  原型：V0.0.0
    uint8_t mcu2_app_soft_version[4];                 // 版本标识ASCII码+主版本数值+次版本数值+阶段版本数值  原型：V0.0.0 
    uint8_t mcu2_hardware_version[2];                 // 大版本号数值+小版本号数值  原型：V1.0
    uint8_t mcu1_core_soft_version[4];                // 版本标识ASCII码+主版本数值+次版本数值+阶段版本数值  原型：V0.0.0
    uint8_t mcu1_app_soft_version[4];                 // 版本标识ASCII码+主版本数值+次版本数值+阶段版本数值  原型：V0.0.0
    uint8_t mcu1_hardware_version[2];                 // 大版本号数值+小版本号数值  原型：V1.0
    uint8_t sci_protocol_version;                     // 协议版本号数值（001~255）  原型：V001
    uint8_t can_protocol_version;                     // 协议版本号数值（001~255）  原型：V001
    uint8_t iec104_protocol_version;                  // 协议版本号数值（001~255）  原型：V001
    uint8_t iec61850_protocol_version;                // 协议版本号数值（001~255）  原型：V001
    uint8_t ff_software_version[2];                   // 大版本号数值+小版本号数值  原型：V1.0
}debug_manage_version_info_t;
#pragma pack(pop)


#pragma pack(push)
#pragma pack(1)
typedef struct
{
	uint8_t battery_type;                                           // 电池类型
    uint8_t charge_status;                                          // 充放电状态
    uint32_t charge_curr_max;                                       // 允许最大充电电流
    uint32_t discharge_curr_max;                                    // 允许最大放电电流
    uint32_t voltage;                                               // 电池簇电压
    uint32_t current;                                               // 电池簇电流
    uint32_t power;                                                 // 电池簇功率
    uint16_t soc;                                                   // SOC
    uint16_t soh;                                                   // SOH
    uint16_t monomer_vmin;                                          // 单体最低电压
    uint16_t monomer_vmin_index;                                    // 单体最低电压序号
    uint16_t monomer_vmax;                                          // 单体最高电压
    uint16_t monomer_vmax_index;                                    // 单体最高电压序号
    uint16_t monomer_tmin;                                          // 单体最低温度
    uint16_t monomer_tmin_index;                                    // 单体最低温度序号
    uint16_t monomer_tmax;                                          // 单体最高温度
    uint16_t monomer_tmax_index;                                    // 单体最高温度序号
    uint32_t total_discharge;                                       // 总放电电量
    uint32_t total_charge;                                          // 总充电电量
    uint32_t day_discharge;                                         // 当天放电电量
    uint32_t day_charge;                                            // 当天充电电量
    uint16_t pack_num;                                              // 电池模组数量
    uint16_t monomer_num;                                           // 每个电池模组单体数量
    uint16_t pack_tpoint_num;                                       // 每个电池模组温度采样点数量
    uint32_t pack_volt[PACK_NUMBER];                                // 电池模组电压集合
    uint32_t pack_curr[PACK_NUMBER];                                // 电池模组电流集合
    uint32_t pack_power[PACK_NUMBER];                               // 电池模组功率集合
    uint32_t monomer_volt[PACK_NUMBER * MONOMER_NUMBER_IN_PACK];    // 单体电压集合
	uint32_t monomer_temp[PACK_NUMBER * MONOMER_NUMBER_IN_PACK];    // 温度集合
}bms_data_t;                                                        // BMS数据

typedef struct
{
    uint8_t pcs_status;                                             // PCS状态
    uint8_t charge_status;                                          // 充放电状态
    uint16_t temp;                                                  // 温度
    uint32_t grid_power;                                            // 电网功率
    uint32_t load_power;                                            // 负载功率
    uint32_t dc_power;                                              // 直流侧功率
    uint32_t ac_power;                                              // 交流侧功率
    uint32_t grid_su_energy;                                        // 馈网电量
    uint32_t get_grid_energy;                                       // 电网取电量
    uint32_t load_use_energy;                                       // 负载用电量
    uint32_t grid_volt_r;                                           // 电网相电压R  
    uint32_t grid_current_r;                                        // 电网相电流R
    uint32_t grid_freq_r;                                           // 电网频率R
    uint32_t grid_volt_s;                                           // 电网相电压S 
    uint32_t grid_current_s;                                        // 电网相电流S
    uint32_t grid_freq_s;                                           // 电网频率S
    uint32_t grid_volt_t;                                           // 电网相电压T
    uint32_t grid_current_t;                                        // 电网相电流T
    uint32_t grid_freq_t;                                           // 电网频率T
    uint32_t day_run_time;                                          // 当天运行时间（单位s）
    uint32_t total_run_time;                                        // 总运行时间（单位s）
}pcs_data_t;
#pragma pack(pop)


/**
 * @brief  	WEB数据初始化（若存放操作日志文件的文件夹不存在时，创建对应的文件夹）
 * @param  	[in] void
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t web_data_init(void);

/**
 * @brief  	首页页面获取要显示的集装箱信息
 * @param  	[out] p_data 集装箱信息的数据指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t home_page_container_get(home_page_container_t *p_data);

/**
 * @brief  	首页页面获取要显示的最新的操作日志数据
 * @param  	[in] num            欲获取操作日志的条数
 * @param  	[out] p_data        获取到的操作日志数据指针
 * @param  	[out] p_data_num    实际获取到操作日志的条数
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t home_page_operation_log_latest_item_get(uint32_t num, void *p_data, uint32_t *p_data_num);

/**
 * @brief  	首页页面获取PCS相关数据
 * @param  	[out] p_data        获取到的PCS数据结构体指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t home_page_pcs_info_get(home_page_pcs_info_t *p_data);

/**
 * @brief  	将event_time_t结构体时间转换成时间戳（秒）
 * @param  	[in] p_time         event_time_t结构体时间
 * @param  	[out] p_timestamp   时间戳（秒）
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t event_time_to_timestamp(const event_time_t *p_time, time_t *p_timestamp);

/**
 * @brief  	首页页面获取要显示的最新的5条故障日志数据
 * @param  	[out] p_data        故障日志的数据指针
 * @param  	[out] p_data_num    实际获取到故障日志的条数
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t home_page_fault_log_latest_5_item_get(void *p_data, uint32_t *p_data_num);

/**
 * @brief  	首页页面获取要显示的最新的故障日志数据
 * @param  	[in] filter_para    筛选条件参数
 * @param  	[out] p_data        故障日志的数据指针
 * @param  	[out] p_data_num    实际获取到故障日志的条数
 * @param  	[out] p_total_num   符合筛选条件的故障日志的条数
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t home_page_fault_log_latest_item_get(event_filter_para_t filter_para, void *p_data, uint32_t *p_data_num, uint32_t *p_total_num);

/**
 * @brief  	电池簇信息页面获取要显示的信息
 * @param  	[out] p_data 电池簇信息的数据指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t cluster_info_page_get(battery_cluster_page_t *p_data);

/**
 * @brief  	电池簇信息详情页面获取要显示的PACK信息
 * @param  	[in] cluster_index  欲获取的电池簇数据索引
 * @param  	[in] pack_index     欲获取的PACK数据索引
 * @param  	[out] p_data        PACK信息的数据指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t cluster_info_page_pack_get(uint8_t cluster_index, uint8_t pack_index, web_monomer_info_t *p_data);

/**
 * @brief  	实时告警页面获取要显示的信息
 * @param  	[out] p_data 告警信息的数据指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t realtime_warn_page_get(realtime_warn_page_t *p_data);

/**
 * @brief  	参数配置页面获取保护参数配置
 * @param  	[out] p_data 参数的数据指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t para_config_page_protect_para_get(battery_parameter_data_t *p_data);

/**
 * @brief  	参数配置页面设置保护参数配置
 * @param  	[out] p_data 参数的数据指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t para_config_page_protect_para_set(battery_parameter_data_t *p_data);

/**
 * @brief  	参数配置页面获取运行数据存储参数
 * @param  	[out] p_days 运行数据存储天数参数的数据指针
 * @param  	[out] p_freq 运行数据存储频率参数的数据指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t para_config_page_storage_para_get(uint16_t *p_days, uint16_t *p_freq);

/**
 * @brief  	参数配置页面设置运行数据存储参数
 * @param  	[in] days 运行数据存储天数参数
 * @param  	[in] freq 运行数据存储频率参数
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t para_config_page_storage_para_set(uint16_t days, uint16_t freq);

/**
 * @brief  	历史数据页面获取历史数据
 * @param  	[in] p_start_time   获取的历史数据的起始时间点
 * @param  	[in] p_end_time     获取的历史数据的结束时间点
 * @param  	[in] cluster_index  欲获取的电池簇数据索引
 * @param  	[out] p_data        历史数据的指针
 * @param  	[out] p_data_num    获取到历史数据的条数
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t history_data_page_get(sdk_rtc_t *p_start_time, sdk_rtc_t *p_end_time, uint8_t cluster_index, void *p_data, uint32_t *p_data_num);

/**
 * @brief  	调试管理页面获取状态信息
 * @param  	[out] p_data 状态信息的指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t debug_manage_page_get(debug_manage_page_read_t *p_data);

/**
 * @brief  	调试管理页面设置遥控数据信息
 * @param  	[in] p_data 遥控数据信息的指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t debug_manage_page_set(debug_manage_page_write_t *p_data);


/**
 * @brief  	调试管理页面显示MCU和BMS版本号信息
 * @param  	[in] p_data 遥测数据信息的指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t debug_manage_version_info_get(debug_manage_version_info_t *p_data);

/**
 * @brief  	设置保护参数页面进行保护参数保存
 * @param  	无
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t protect_params_flag_set(void);

/**
 * @brief  	获取液冷信息和电池簇组的信息
 * @param  	无
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t get_lc_status_and_cluster_group_status(uint8_t *p_lc_sta,uint8_t *p_cluster_group1_sta,uint8_t *p_cluster_group2_sta);

/**
 * @brief  	获取集装箱状态信息
 * @param  	[in] p_data 集装箱状态信息指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t container_status_info_get(container_status_info_t *p_data);

/**
 * @brief  	获取MQTT使用的信息
 * @param  	[in] p_bms_data BMS数据指针
 * @param  	[in] p_pcs_data MQTT信息指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t mqtt_info_get(bms_data_t *p_bms_data, pcs_data_t *p_pcs_data);

/**
 * @brief  	参数配置页面获取充电上限SOC和放电下限SOC
 * @param  	[out] p_soc_charge_limit 充电上限SOC的数据指针
 * @param  	[out] p_soc_discharge_limit 放电下限SOC的数据指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t para_config_page_limit_soc_para_get(uint16_t *p_soc_charge_limit, uint16_t *p_soc_discharge_limit);

/**
 * @brief  	参数配置页面设置充电上限SOC和放电下限SOC
 * @param  	[in] soc_charge_limit 充电上限SOC
 * @param  	[in] soc_discharge_limit 放电下限SOC
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t para_config_page_limit_soc_para_set(int16_t soc_charge_limit, int16_t soc_discharge_limit);


#endif /* __WEB_DATA_INTERFACE__ */
