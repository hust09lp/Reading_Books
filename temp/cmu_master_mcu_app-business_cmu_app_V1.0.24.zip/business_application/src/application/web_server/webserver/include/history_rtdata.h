#ifndef __HISTORY_RTDATA__
#define __HISTORY_RTDATA__

#include"mongoose.h"

#define MAX_HISTORY_ITEMS 1500   //最大历史条数,480*3 = 1440,3分钟1条，每天480条，3天最多1440条，留余量60

void get_cluster_history_info(struct mg_connection *p_nc,struct http_message *p_msg);
void get_pack_history_info(struct mg_connection *p_nc,struct http_message *p_msg);
void history_data_module_init(void);
#endif