#ifndef __SAFETY_H__
#define __SAFETY_H__

#include"mongoose.h"

/**
 * @brief    获取安规
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void get_safety(struct mg_connection *p_nc,struct http_message *p_msg);

/**
 * @brief    设置安规信息
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void set_safety(struct mg_connection *p_nc,struct http_message *p_msg);

/**
 * @brief 安规导入模块初始化
 * @return void
 */
void safety_param_module_init(void);

#endif