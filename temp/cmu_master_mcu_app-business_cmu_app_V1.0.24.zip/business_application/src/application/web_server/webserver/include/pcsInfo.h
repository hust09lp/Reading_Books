#ifndef __RT_PCSINFO_H__
#define __RT_PCSINFO_H__

#include"mongoose.h"
void get_pcsInfo(struct mg_connection *p_nc,struct http_message *p_msg);
void get_pcs_simple(struct mg_connection *p_nc,struct http_message *p_msg);
void get_pcs_detailede(struct mg_connection *p_nc,struct http_message *p_msg);
void pcsinfo_data_module_init(void);

#endif