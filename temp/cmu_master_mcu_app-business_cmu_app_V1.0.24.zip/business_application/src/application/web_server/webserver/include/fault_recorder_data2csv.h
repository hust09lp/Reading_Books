#ifndef __FAULT_RECOEDER_DATA2CSV_H__
#define __FAULT_RECOEDER_DATA2CSV_H__

#include "sdk_public.h"

#define PCS_ITEM_NUM        7
#define LC_ITEM_NUM         4
#define FF_ITEM_NUM         4
#define BAT_ITEM_NUM        13

/**
 * @brief   对字节流录波数据进行解析并存储成csv文件
 * @param p_src_file：需要转换的文件
 * @param p_src_file：需要生成的文件
 * @return 0：成功  -1：失败
 * @note
 */
int32_t fault_recorder_data2csv(char *p_src_file, char *p_dst_file);


#endif