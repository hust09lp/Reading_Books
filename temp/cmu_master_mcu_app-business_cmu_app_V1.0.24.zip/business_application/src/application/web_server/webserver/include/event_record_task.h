/** 
 * @file          even_record_task.h
 * @brief         历史事件记录接口函数说明
 * @author        duyumeng
 * @version       V0.0.1     初始版本
 * @date          2022/08/25
 * @copyright     Copyright (c) 2023 by SofarSolar, All Rights Reserved. 
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author    	  <th>Description 
 * <tr><td>2022/08/25  <td>0.0.1    <td>duyumeng  	  <td>创建初始版本  
 * <tr><td>2023/03/15  <td>0.0.2    <td>liangguyao    <td>根据需求，作以下修改:
 *                                                        1.删除DCDC模块故障；
 *                                                        2.主设备由逆变器故障变更为CMU的故障/告警；
 *                                                        3.增加电池簇模块的故障/告警。
 * </table>
 **********************************************************************************
 */


#ifndef __EVENT_RECORD_TASK_H__
#define __EVENT_RECORD_TASK_H__

#include "data_types.h"
#include "sdk_fs.h"

#include <stdio.h>
#include <stdlib.h>
#include <time.h>


// 打印开关
#if (0)
#define EVENT_RECORD_DEBUG_PRINT(...) printf(__VA_ARGS__);
#else
#define EVENT_RECORD_DEBUG_PRINT(...)
#endif

#define EVENT_RECORD_DEEP_MAX				(5000)	// 每个文件的事件记录的最大深度（条数）

#define HISTORY_EVENT_PATH_NAME_MAX			60
#define PATH_HISTORY_EVENT_RECOND_FOLDER	"/user/data/event/"

// 故障编号
#define CMU_FAULT_START                (0x01)       // CMU系统故障编号起点
#define CMU_FAULT_END                  (0x30)       // CMU系统故障编号终点
#define CONTAINER_FAULT_START          (0xC1)      // 集装箱故障编号起点
#define CONTAINER_FAULT_END            (0x150)      // 集装箱故障编号终点
#define BATTERY_CLUSTER_1_FAULT_START  (0x201)      // 电池簇1故障编号起点
#define BATTERY_CLUSTER_1_FAULT_END    (0x250)      // 电池簇1故障编号终点
#define BATTERY_CLUSTER_2_FAULT_START  (0x301)      // 电池簇2故障编号起点
#define BATTERY_CLUSTER_2_FAULT_END    (0x350)      // 电池簇2故障编号终点
#define BATTERY_CLUSTER_3_FAULT_START  (0x401)      // 电池簇3故障编号起点
#define BATTERY_CLUSTER_3_FAULT_END    (0x450)      // 电池簇3故障编号终点
#define BATTERY_CLUSTER_4_FAULT_START  (0x501)      // 电池簇4故障编号起点
#define BATTERY_CLUSTER_4_FAULT_END    (0x550)      // 电池簇4故障编号终点
#define BATTERY_CLUSTER_5_FAULT_START  (0x601)      // 电池簇5故障编号起点
#define BATTERY_CLUSTER_5_FAULT_END    (0x650)      // 电池簇5故障编号终点
#define BATTERY_CLUSTER_6_FAULT_START  (0x701)      // 电池簇6故障编号起点
#define BATTERY_CLUSTER_6_FAULT_END    (0x750)      // 电池簇6故障编号终点
#define PCS_FAULT_START                (0x801)      // PCS模块故障编号起点
#define PCS_FAULT_END                  (0x8F0)      // PCS模块故障编号终点

#define CONTAINER_COOLED_FAULT_OFFSET   (24)        // 集装箱故障编号 -- 液冷故障偏移地址
#define CONTAINER_COOLED_FAULT_NUM      (64)        // 集装箱液冷故障个数

// PCS分段编号
#define PCSMODULE_CLUSTER_FAULT_START_POINT	0x801
#define PCSMODULE_CLUSTER_FAULT_END_POINT	0x8F0
#define PCSMODULE_CLUSTER_FAULT_LEN			256		// 每个PCS模块故障的编号长度
#define GRID_FAULT_START_POINT	        0
#define SAMPLING_FAULT_START_POINT	    16
#define SELF_TEST_FAULT_START_POINT	    32
#define TEMP_FAULT_START_POINT	        48
#define VOLT_FAULT_START_POINT	        64
#define CURRENT_FAULT_START_POINT	    80
#define HWSIGNAL_FAULT_START_POINT	    96
#define CONTROL_FAULT_START_POINT	    112
#define COMM_FAULT_START_POINT	        128
#define SUPPLEEMENT_FAULT_START_POINT	144  //supplement
#define DEVICE_FAULT_START_POINT	    160          //device
#define WARN_FAULT_START_POINT	        176
#define STATE6_FAULT_START_POINT        192

// 告警编号
#define CONTAINER_WARN_START           (0x31)       // 集装箱告警编号起点
#define CONTAINER_WARN_END             (0xC0)       // 集装箱告警编号终点
#define BATTERY_CLUSTER_1_WARN_START   (0x171)      // 电池簇1告警编号起点
#define BATTERY_CLUSTER_1_WARN_END     (0x200)      // 电池簇1告警编号终点
#define BATTERY_CLUSTER_2_WARN_START   (0x271)      // 电池簇2告警编号起点
#define BATTERY_CLUSTER_2_WARN_END     (0x300)      // 电池簇2告警编号终点
#define BATTERY_CLUSTER_3_WARN_START   (0x371)      // 电池簇3告警编号起点
#define BATTERY_CLUSTER_3_WARN_END     (0x400)      // 电池簇3告警编号终点
#define BATTERY_CLUSTER_4_WARN_START   (0x471)      // 电池簇4告警编号起点
#define BATTERY_CLUSTER_4_WARN_END     (0x500)      // 电池簇4告警编号终点
#define BATTERY_CLUSTER_5_WARN_START   (0x571)      // 电池簇5告警编号起点
#define BATTERY_CLUSTER_5_WARN_END     (0x600)      // 电池簇5告警编号终点
#define BATTERY_CLUSTER_6_WARN_START   (0x671)      // 电池簇6告警编号起点
#define BATTERY_CLUSTER_6_WARN_END     (0x700)      // 电池簇6告警编号终点
// #define BATTERY_CLUSTER_7_WARN_START   (0x1771)      // 电池簇7告警编号起点
// #define BATTERY_CLUSTER_7_WARN_END     (0x800)      // 电池簇7告警编号终点
// #define BATTERY_CLUSTER_8_WARN_START   (0x871)      // 电池簇8告警编号起点
// #define BATTERY_CLUSTER_8_WARN_END     (0x900)      // 电池簇8告警编号终点
// #define BATTERY_CLUSTER_9_WARN_START   (0x971)      // 电池簇9告警编号起点
// #define BATTERY_CLUSTER_9_WARN_END     (0xA00)      // 电池簇9告警编号终点
// #define BATTERY_CLUSTER_10_WARN_START  (0xA71)      // 电池簇10告警编号起点
// #define BATTERY_CLUSTER_10_WARN_END    (0xB00)      // 电池簇10告警编号终点

#define BATTERY_CLUSTER_INTERVAL       (0x100)      // 电池簇间隔

// 历史事件分类
typedef enum
{
    ALL_EVENT   = 0,    // 不进行事件分类，所有的事件
    FAULT_EVENT = 1,    // 仅故障事件
    WARN_EVENT  = 2,    // 仅告警事件
    TBD_EVENT   = 3,    // 仅未定义/不明确的事件
}history_event_classify_e;

// web筛选条件
typedef enum
{
    FILTER_ALL      = 0,    // 所有的故障事件，不进行筛选
    FILTER_ID       = 1,    // 仅筛选指定的故障ID事件
    FILTER_DATE     = 2,    // 仅筛选指定的日期故障事件
    FILTER_ID_DATE  = 3,    // 仅筛选指定故障ID并且指定日期的故障事件
}event_filter_criteria_e;

typedef struct 
{
    uint16_t event_id;
    uint8_t start_time[32];
	uint8_t end_time[32];
}history_event_new_t;

// 筛选条件参数
typedef struct
{
    history_event_classify_e  filter_classify;  // 筛选分类：history_event_classify_e
                                                // ALL_EVENT   = 0（不进行事件分类，所有的事件）
                                                // FAULT_EVENT = 1（仅故障事件）
                                                // WARN_EVENT  = 2（仅告警事件）
                                                // TBD_EVENT   = 3（仅未定义/不明确的事件）
    event_filter_criteria_e  filter_criteria;   // web端筛选条件：event_filter_criteria_e
                                                // FILTER_ALL       = 0（所有的故障事件，不进行筛选）
                                                // FILTER_ID        = 1（仅筛选指定的故障ID事件）
                                                // FILTER_DATE      = 2（仅筛选指定的日期故障事件）
                                                // FILTER_ID_DATE   = 3（仅筛选指定故障ID并且指定日期的故障事件）
    uint16_t event_id;                          // 筛选指定的故障ID，当filter_criteria的值为FILTER_ID或FILTER_ID_DATE时，此故障ID值才有效，否则此故障ID值无效
    uint8_t  year;                              // 筛选指定的故障日期（年），当filter_criteria的值为FILTER_DATE或FILTER_ID_DATE时，此值才有效，否则此值无效
    uint8_t  mon;                               // 筛选指定的故障日期（月），当filter_criteria的值为FILTER_DATE或FILTER_ID_DATE时，此值才有效，否则此值无效
    uint8_t  day;                               // 筛选指定的故障日期（日），当filter_criteria的值为FILTER_DATE或FILTER_ID_DATE时，此值才有效，否则此值无效
    uint8_t  items_perpage;                     // 一页显示多少条
    uint16_t page_index;                        // 显示第几页的索引
}event_filter_para_t;

#pragma pack(push)
#pragma pack(1)
typedef struct
{
    uint8_t year;
    uint8_t mon;
    uint8_t day;
    uint8_t hour;
    uint8_t min;
    uint8_t sec;    
}event_time_t;

typedef struct
{
    uint16_t event_id;
    event_time_t event_time;
}history_event_t;
#pragma pack(pop)

/**
 * @brief  	根据入参的筛选条件参数，从文件中读取对应的最新的历史事件数据
 * @param  	[in] p_fs 			已打开的文件指针
 * @param   [in] para    		筛选条件参数
 * @param  	[out] p_data 		符合筛选条件参数的历史事件的数据指针
 * @param  	[out] p_data_num	实际获取到符合筛选条件参数的历史事件的条数
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t history_event_latest_item_get(fs_t *p_fs, event_filter_para_t para, void *p_data, uint32_t *p_data_num);

#endif

