#ifndef __FAULT_RECORDER_H__
#define __FAULT_RECORDER_H__

#define PATH_FAULT_RECORD_FOLDER	        "/media/mmcblk0p1/fault_record/"    //故障录波存储的文件夹
#define PATH_FAULT_RECORD_CSV_FOLDER	    "/user/data/cmu_fault_record/CMUFaultRecorder/"	

#define MAX_CMU_RECORDER_FILE_NUM   50

typedef struct
{
    char file_name[64];
    char file_time[32];
    int fault_id;
    int file_index;
    time_t mod_time;
}cmu_fault_recorder_info_t;


/**
 * @brief 故障录波模块初始化
 * @return void
 */
void fault_recorder_module_init(void);

#endif