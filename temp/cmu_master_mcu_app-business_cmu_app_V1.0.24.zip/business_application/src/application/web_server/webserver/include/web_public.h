#ifndef __WEB_PUBLIC_H__
#define __WEB_PUBLIC_H__


#include <stdint.h>
#include "sdk_public.h"
#include"mongoose.h"


#define SUCCESS   		0
#define FAIL        1
#define HISTORY_FILE_LEN 8



//uint32_t crc32( const unsigned char *buf, unsigned int size);
//void date_time_to_timestamp(sdk_rtc_t *p_time, time_t *p_timestamp);


#endif

