#ifndef _CSU_DATA_INFO_H_
#define _CSU_DATA_INFO_H_

#include "sofar_type.h"

void csu_data_info_module_init(void);


#endif
