#ifndef __USB_UPGRADE_H__
#define __USB_UPGRADE_H__

#include"mongoose.h"
void do_usb_upgrade(struct mg_connection *p_nc,struct http_message *p_msg);
#endif