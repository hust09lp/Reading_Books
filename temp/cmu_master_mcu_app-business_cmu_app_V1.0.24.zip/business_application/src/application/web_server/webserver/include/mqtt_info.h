#ifndef __MQTT_INFO__
#define __MQTT_INFO__

#include"mongoose.h"

void mqtt_get_bms_pcs_info(struct mg_connection *p_nc,struct http_message *p_msg);
void mqtt_get_event_info(struct mg_connection *p_nc,struct http_message *p_msg);
void mqtt_set_param_info(struct mg_connection *p_nc,struct http_message *p_msg);
void mqtt_info_module_init(void);

#endif