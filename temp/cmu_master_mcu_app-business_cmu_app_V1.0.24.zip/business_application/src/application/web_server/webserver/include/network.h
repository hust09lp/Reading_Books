#ifndef __NETWORK_H__
#define __NETWORK_H__
#include"mongoose.h"
void get_network_sta(struct mg_connection *p_nc,struct http_message *p_msg);
void set_network_dhcp(struct mg_connection *p_nc,struct http_message *p_msg);
void set_network_static(struct mg_connection *p_nc,struct http_message *p_msg);
void web_network_param_module_init(void);
#endif