#ifndef __COMMON_H__
#define __COMMIN_H__
#include"mongoose.h"
#include"homepage.h"

#define WEB_HOME_PATH "/user/www/htdocs"
#define WEB_CONF_PATH "/user/www/conf/"
#define ADMIN_JSON_FILE "/user/www/conf/administrator.json"
#define SYSTIME_JSON_FILE "/user/www/conf/systime.json"
#define SYSPARAM_JSON_FILE "/user/www/conf/sysparam.json"
#define NETWORK_CONF_FILE "/opt/conf/network"
#define NETWORK_CONF_FILE_TMP "/opt/conf/network_tmp"
#define WEB_OPERATION_LOG_PATH "/user/www/conf/operationlog"  //操作日志文件
#define PROTECT_PARAMS_JSON_FILE "/user/www/conf/protectparams.json"  //保护参数临时使用的配置文件，后面修改为接口获取，因为WEB不需要维护这些参数
#define RUNTIME_PARAMS_JSON_FILE "/user/www/conf/runtimeparams.json"
#define DEBUG_STATUS_JSON_FILE "/user/www/conf/debugstatus.json"
#define SYSPARAM_CONF   "/user/conf/system_param.json"   //存放系统运行参数
#define WEB_UPLOAD_DIR "/tmp/upload"


#define print_log(format,argc...){ \
	printf("%s[%s:%d]=>",__FILE__,__func__,__LINE__); \
	printf(format,##argc); \
	printf("\n"); \
}

//void print_log(const int8_t *format,...);
void md5_calcul(const uint8_t *text,const uint8_t len,uint8_t *out);
void http_back(struct mg_connection *p_nc,uint8_t *p_data);
int8_t build_empty_response(uint8_t *response,const uint16_t code,const uint8_t *p_reason);
void hex_to_str(const uint8_t *p_src,uint8_t *p_dst,const uint8_t len);
void strip_request_body(const uint8_t *p_src,const uint8_t len,uint8_t *p_dst);
void init_user_basic_info(operation_log_t *oplog);
void get_user_basic_info(operation_log_t *oplog);
void add_one_op_log(operation_log_t *p_oplog);
void get_user_from_http_request(struct http_message *p_msg,uint8_t *p_username);
void ymd_to_timestamp(const uint16_t year,const uint8_t month,const uint8_t day,time_t *timestamp);
void translate_operation_log(const uint8_t language, const uint8_t *p_log_in, uint8_t *p_log_out, const uint8_t max_len);
#endif
