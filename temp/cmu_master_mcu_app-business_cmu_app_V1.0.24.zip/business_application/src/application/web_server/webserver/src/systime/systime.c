#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"cJSON.h"
#include"systime.h"
#include"common.h"
//#include"data_shm.h"
#include "sdk_shm.h"
#include "web_broker.h"

//时区调整
struct timezone_mapping {
        const int timezone_id;
        const char* timezone_path;
    };
 
//时区对应的时区文件,其中有一些文案错误的，等web改完再改。比如UTC-0500中间没有冒号，阿德莱德写成阿德菜德
static const struct timezone_mapping timezone_mappings[] = {
    {1, "/usr/share/zoneinfo/Etc/GMT+12"},
    {2, "/usr/share/zoneinfo/Etc/GMT+11"},
    {3, "/usr/share/zoneinfo/America/Adak"},
    {4, "/usr/share/zoneinfo/Pacific/Honolulu"},
    {5, "/usr/share/zoneinfo/Pacific/Marquesas"},
    {6, "/usr/share/zoneinfo/America/Anchorage"},
    {7, "/usr/share/zoneinfo/Etc/GMT+9"},
    {8, "/usr/share/zoneinfo/America/Los_Angeles"},
    {9, "/usr/share/zoneinfo/America/Tijuana"},
    {10, "/usr/share/zoneinfo/Etc/GMT+8"},
    {11, "/usr/share/zoneinfo/America/Mazatlan"},
    {12, "/usr/share/zoneinfo/America/Denver"},
    {13, "/usr/share/zoneinfo/America/Phoenix"},
    {14, "/usr/share/zoneinfo/America/Whitehorse"},
    {15, "/usr/share/zoneinfo/Pacific/Easter"},
    {16, "/usr/share/zoneinfo/America/Mexico_City"},
    {17, "/usr/share/zoneinfo/America/Regina"},
    {18, "/usr/share/zoneinfo/America/Chicago"},
    {19, "/usr/share/zoneinfo/America/Guatemala"},
    {20, "/usr/share/zoneinfo/America/Bogota"},
    {21, "/usr/share/zoneinfo/America/New_York"},
    {22, "/usr/share/zoneinfo/America/Havana"},
    {23, "/usr/share/zoneinfo/America/Port-au-Prince"},
    {24, "/usr/share/zoneinfo/America/Cancun"},
    {25, "/usr/share/zoneinfo/America/Grand_Turk"},
    {26, "/usr/share/zoneinfo/America/Indiana/Indianapolis"},
    {27, "/usr/share/zoneinfo/America/Halifax"},
    {28, "/usr/share/zoneinfo/America/Caracas"},
    {29, "/usr/share/zoneinfo/America/Cuiaba"},
    {30, "/usr/share/zoneinfo/America/La_Paz"},
    {31, "/usr/share/zoneinfo/America/Santiago"},
    {32, "/usr/share/zoneinfo/America/Asuncion"},
    {33, "/usr/share/zoneinfo/America/St_Johns"},
    {34, "/usr/share/zoneinfo/America/Argentina/Buenos_Aires"},
    {35, "/usr/share/zoneinfo/America/Sao_Paulo"},
    {36, "/usr/share/zoneinfo/America/Argentina/Buenos_Aires"},
    {37, "/usr/share/zoneinfo/America/Godthab"},
    {38, "/usr/share/zoneinfo/America/Cayenne"},
    {39, "/usr/share/zoneinfo/America/Montevideo"},
    {40, "/usr/share/zoneinfo/America/Punta_Arenas"},
    {41, "/usr/share/zoneinfo/America/El_Salvador"},
    {42, "/usr/share/zoneinfo/America/Miquelon"},
    {43, "/usr/share/zoneinfo/Etc/GMT+2"},
    {44, "/usr/share/zoneinfo/Atlantic/Cape_Verde"},
    {45, "/usr/share/zoneinfo/Atlantic/Azores"},
    {46, "/usr/share/zoneinfo/UTC"},
    {47, "/usr/share/zoneinfo/Europe/London"},
    {48, "/usr/share/zoneinfo/Atlantic/Reykjavik"},
    {49, "/usr/share/zoneinfo/Africa/Sao_Tome"},
    {50, "/usr/share/zoneinfo/Africa/Casablanca"},
    {51, "/usr/share/zoneinfo/Europe/Berlin"},
    {52, "/usr/share/zoneinfo/Europe/Belgrade"},
    {53, "/usr/share/zoneinfo/Europe/Paris"},
    {54, "/usr/share/zoneinfo/Europe/Sarajevo"},
    {55, "/usr/share/zoneinfo/Africa/Lagos"},
    {56, "/usr/share/zoneinfo/Asia/Beirut"},
    {57, "/usr/share/zoneinfo/Asia/Damascus"},
    {58, "/usr/share/zoneinfo/Africa/Tripoli"},
    {59, "/usr/share/zoneinfo/Africa/Harare"},
    {60, "/usr/share/zoneinfo/Europe/Helsinki"},
    {61, "/usr/share/zoneinfo/Europe/Chisinau"},
    {62, "/usr/share/zoneinfo/Europe/Kaliningrad"},
    {63, "/usr/share/zoneinfo/Asia/Gaza"},
    {64, "/usr/share/zoneinfo/Africa/Khartoum"},
    {65, "/usr/share/zoneinfo/Africa/Cairo"},
    {66, "/usr/share/zoneinfo/Africa/Windhoek"},
    {67, "/usr/share/zoneinfo/Europe/Athens"},
    {68, "/usr/share/zoneinfo/Asia/Jerusalem"},
    {69, "/usr/share/zoneinfo/Africa/Juba"},
    {70, "/usr/share/zoneinfo/Asia/Amman"},
    {71, "/usr/share/zoneinfo/Asia/Baghdad"},
    {72, "/usr/share/zoneinfo/Europe/Volgograd"},
    {73, "/usr/share/zoneinfo/Asia/Kuwait"},
    {74, "/usr/share/zoneinfo/Europe/Minsk"},
    {75, "/usr/share/zoneinfo/Europe/Moscow"},
    {76, "/usr/share/zoneinfo/Africa/Nairobi"},
    {77, "/usr/share/zoneinfo/Europe/Istanbul"},
    {78, "/usr/share/zoneinfo/Asia/Tehran"},
    {79, "/usr/share/zoneinfo/Asia/Dubai"},
    {80, "/usr/share/zoneinfo/Europe/Astrakhan"},
    {81, "/usr/share/zoneinfo/Asia/Yerevan"},
    {82, "/usr/share/zoneinfo/Asia/Baku"},
    {83, "/usr/share/zoneinfo/Asia/Tbilisi"},
    {84, "/usr/share/zoneinfo/Indian/Mauritius"},
    {85, "/usr/share/zoneinfo/Europe/Saratov"},
    {86, "/usr/share/zoneinfo/Europe/Samara"},
    {87, "/usr/share/zoneinfo/Asia/Kabul"},
    {88, "/usr/share/zoneinfo/Asia/Ashgabat"},
    {89, "/usr/share/zoneinfo/Asia/Qyzylorda"},
    {90, "/usr/share/zoneinfo/Asia/Yekaterinburg"},
    {91, "/usr/share/zoneinfo/Asia/Karachi"},
    {92, "/usr/share/zoneinfo/Asia/Kolkata"},
    {93, "/usr/share/zoneinfo/Asia/Colombo"},
    {94, "/usr/share/zoneinfo/Asia/Kathmandu"},
    {95, "/usr/share/zoneinfo/Asia/Almaty"},
    {96, "/usr/share/zoneinfo/Asia/Dhaka"},
    {97, "/usr/share/zoneinfo/Asia/Omsk"},
    {98, "/usr/share/zoneinfo/Asia/Yangon"},
    {99, "/usr/share/zoneinfo/Asia/Barnaul"},
    {100, "/usr/share/zoneinfo/Asia/Krasnoyarsk"},
    {101, "/usr/share/zoneinfo/Asia/Krasnoyarsk"},
    {102, "/usr/share/zoneinfo/Asia/Bangkok"},
    {103, "/usr/share/zoneinfo/Asia/Tomsk"},
    {104, "/usr/share/zoneinfo/Asia/Novosibirsk"},
    {105, "/usr/share/zoneinfo/Asia/Shanghai"},
    {106, "/usr/share/zoneinfo/Asia/Kuala_Lumpur"},
    {107, "/usr/share/zoneinfo/Australia/Perth"},
    {108, "/usr/share/zoneinfo/Asia/Taipei"},
    {109, "/usr/share/zoneinfo/Asia/Ulaanbaatar"},
    {110, "/usr/share/zoneinfo/Asia/Irkutsk"},
    {111, "/usr/share/zoneinfo/Australia/Eucla"},
    {112, "/usr/share/zoneinfo/Asia/Chita"},
    {113, "/usr/share/zoneinfo/Asia/Tokyo"},
    {114, "/usr/share/zoneinfo/Asia/Pyongyang"},
    {115, "/usr/share/zoneinfo/Asia/Seoul"},
    {116, "/usr/share/zoneinfo/Asia/Yakutsk"},
    {117, "/usr/share/zoneinfo/Australia/Adelaide"},
    {118, "/usr/share/zoneinfo/Australia/Darwin"},
    {119, "/usr/share/zoneinfo/Australia/Brisbane"},
    {120, "/usr/share/zoneinfo/Asia/Vladivostok"},
    {121, "/usr/share/zoneinfo/Pacific/Port_Moresby"},
    {122, "/usr/share/zoneinfo/Australia/Hobart"},
    {123, "/usr/share/zoneinfo/Australia/Sydney"},
    {124, "/usr/share/zoneinfo/Australia/Lord_Howe"},
    {125, "/usr/share/zoneinfo/Pacific/Bougainville"},
    {126, "/usr/share/zoneinfo/Asia/Magadan"},
    {127, "/usr/share/zoneinfo/Pacific/Norfolk"},
    {128, "/usr/share/zoneinfo/Asia/Sakhalin"},
    {129, "/usr/share/zoneinfo/Asia/Sakhalin"},
    {130, "/usr/share/zoneinfo/Pacific/Noumea"},
    {131, "/usr/share/zoneinfo/Asia/Anadyr"},
    {132, "/usr/share/zoneinfo/Pacific/Auckland"},
    {133, "/usr/share/zoneinfo/Pacific/Fiji"},
    {134, "/usr/share/zoneinfo/Etc/GMT-12"},
    {135, "/usr/share/zoneinfo/Pacific/Chatham"},
    {136, "/usr/share/zoneinfo/Pacific/Tongatapu"},
    {137, "/usr/share/zoneinfo/Pacific/Apia"},
    {138, "/usr/share/zoneinfo/Etc/GMT-13"},
    {139, "/usr/share/zoneinfo/Pacific/Kiritimati"},
};

//根据字符串形式的时区信息，为系统设置对应的时区
void convert_Time_Zone(const int timezone_id)
{
    char command[256] = {0};
    int num_mappings = sizeof(timezone_mappings) / sizeof(timezone_mappings[0]);

    if(timezone_id >= 1 && timezone_id <= num_mappings)
    {
        print_log("time zone is set to %s.\n",timezone_mappings[timezone_id - 1].timezone_path);
        sprintf(command, "ln -sf %s /etc/localtime", timezone_mappings[timezone_id - 1].timezone_path);
        system("mount -o remount,rw /");
        system("rm /etc/localtime");
        system(command);
        system("hwclock -w");
        system("mount -o remount,ro /");
    }
}


static void check_for_old_systime_config()
{
    FILE *fp;
    uint8_t content[256] = {0};
    cJSON *p_conf;
    cJSON *p_timezone;

    /*打开文件并读取内容*/
    fp = fopen(SYSTIME_JSON_FILE,"r");
    if(fp == NULL)
    {
        print_log("open json file %s failed.",SYSTIME_JSON_FILE);  
        return;   
    }
    fread(content, 1, 256, fp);
    fclose(fp);

    /*解析文件内容*/
    p_conf = cJSON_Parse(content);
    if(p_conf == NULL)
    {
        print_log("parse file %s content failed.",SYSTIME_JSON_FILE);
        return;
    }
    /*看文件中是否有timezone字段,如果有,则表示是比较老的版本,自动更新为新的版本*/
    p_timezone = cJSON_GetObjectItem(p_conf, "timeZone");
    if(p_timezone != NULL)
    {
        system("cp /user/www/conf/default/systime.json /user/www/conf/");
    }
    cJSON_Delete(p_conf);
}

void get_system_time_info(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_conf;
    cJSON *p_resp_root;
    cJSON *p_resp_item;
    uint8_t response[128];
    uint8_t *p_action;
    uint8_t *p;
    uint16_t timezone_id;
    uint8_t request_body[1024] = {0};
    uint8_t content[128] = {0};
    FILE *fp;

    memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getSysTimeInfo"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

    check_for_old_systime_config();
    fp = fopen(SYSTIME_JSON_FILE,"r");
    if(fp == NULL)
    {
        print_log("open json file %s failed.",SYSTIME_JSON_FILE);  
        return;   
    }
    fread(content, 1, 128, fp);
    fclose(fp);

    p_conf = cJSON_Parse(content);
    if(p_conf == NULL)
    {
        print_log("parse file %s content failed.",SYSTIME_JSON_FILE);
        return;
    }

    timezone_id = cJSON_GetObjectItem(p_conf,"timezone_id")->valueint;
    cJSON_Delete(p_conf);
    
    p_resp_item = cJSON_CreateObject();
    if(p_resp_item == NULL)
    {
        print_log("create json  obj failed.");
        return;       
    }

    cJSON_AddNumberToObject(p_resp_item,"currentTime",time(NULL));
    cJSON_AddNumberToObject(p_resp_item,"timeZoneID",timezone_id);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json  obj failed.");
        cJSON_Delete(p_resp_item);
        return;       
    }
    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddItemToObject(p_resp_root,"data",p_resp_item);
    cJSON_AddStringToObject(p_resp_root,"msg","getSysTimeInfo successfu.");

    p = cJSON_PrintUnformatted(p_resp_root);
    http_back(p_nc,p);
    free(p);
    cJSON_Delete(p_resp_root);
}

void ntp_sync_time(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_conf;
    uint8_t *p_action;
    uint8_t *p_status;
    uint8_t *p_server;
    uint16_t port;
    uint8_t *p_tz;
    uint8_t *p;
    uint8_t response[128];
    uint8_t request_body[1024] = {0};
    uint8_t content[512] = {0};
    FILE *fp;
    operation_log_t op_log;
	uint8_t cur_user[32] = {0};
    uint8_t timezone_cn[128] = {0};
    uint8_t timezone_en[128] = {0};

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"ntpSyncTime"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

     /*NTP服务器相关参数获取*/
    p_status = cJSON_GetObjectItem(p_request,"ntpStatus")->valuestring;
    p_server = cJSON_GetObjectItem(p_request,"ntpServer")->valuestring; //用户也可能更新了ntp的服务器
    port = cJSON_GetObjectItem(p_request,"ntpPort")->valueint;

     /*记录配置*/
    fp = fopen(SYSTIME_JSON_FILE,"r");
    if(fp == NULL)
    {
        print_log("open json file %s failed.",SYSTIME_JSON_FILE);  
        cJSON_Delete(p_request);
        return;   
    }
    fread(content, 1, 128, fp);
    fclose(fp);

    p_conf = cJSON_Parse(content);
    if(p_conf == NULL)
    {
        print_log("parse config file %s failed.",SYSTIME_JSON_FILE);
        cJSON_Delete(p_request);
        return;
    }
    cJSON_ReplaceItemInObject(p_conf,"ntpstatus",cJSON_CreateString(p_status));
    cJSON_ReplaceItemInObject(p_conf,"ntpserver",cJSON_CreateString(p_server));
    cJSON_ReplaceItemInObject(p_conf,"ntpport",cJSON_CreateNumber(port));

    p = cJSON_PrintUnformatted(p_conf);
    fp = fopen(SYSTIME_JSON_FILE,"w");
    if(fp == NULL)
    {
        print_log("open json file %s failed.",SYSTIME_JSON_FILE);  
        cJSON_Delete(p_request);
        return;   
    }
    fwrite(p, 1, strlen(p), fp);
    fclose(fp);
    cJSON_Delete(p_conf);
    free(p);
    
    /*记录操作日志*/
    init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"NTP同步时间");

    /*如果没有使能NTP但是却点击了同步操作，此时不进行响应*/
    if(strcmp(p_status,"enable"))
    {
        print_log("ntp is not enabled.");
		build_empty_response(response,204,"ntp is not enabled");
        strcpy(op_log.op_status,"failed");
        add_one_op_log(&op_log);
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
    }

    /*进行NTP服务请求,通过NTP连接同步本地系统时间*/
    if(do_ntp_sync_time(p_server,port) != 0)  //这里可能需要细分，是具体返回多少
    {
        print_log("sync time failed.");
        strcpy(op_log.op_status,"failed");
        add_one_op_log(&op_log);
        build_empty_response(response,205,"ntp sync time failed");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
    }
    
    cJSON_Delete(p_request);
    strcpy(op_log.op_status,"success");
    add_one_op_log(&op_log);

    build_empty_response(response,200,"ntp sync time successful");
    http_back(p_nc,response);
}

void custom_set_time(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    uint8_t *p_action;
    uint8_t *p_ymd;  //年月日
    uint8_t *p_hms;  //时分秒
    uint8_t response[128];
    uint8_t request_body[1024] = {0};
    char cmd[128];
    operation_log_t op_log;
	uint8_t cur_user[32] = {0};
    web_control_info_t *p_web_data = shm_web_control_info_get();

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"customSetTime"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    p_ymd = cJSON_GetObjectItem(p_request,"customYMD")->valuestring;
    p_hms = cJSON_GetObjectItem(p_request,"customHMS")->valuestring;

    sprintf(cmd,"date -s \"%s %s\"",p_ymd,p_hms);
    system(cmd);
    system("hwclock -w");
    cJSON_Delete(p_request);
    p_web_data->sync_systime_flag = 1;

    init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"同步系统时间");
    strcpy(op_log.op_status,"success");
	add_one_op_log(&op_log);

    build_empty_response(response,200,"custom set time successful");
    http_back(p_nc,response);
}

void set_timezone_info(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_conf;
    cJSON *p_resp_root;
    uint8_t response[128];
    uint8_t *p_action;
    uint8_t *p;
    uint16_t timezone_id;
    uint8_t request_body[1024] = {0};
    uint8_t content[128] = {0};
    FILE *fp;
    operation_log_t op_log;
	uint8_t cur_user[32] = {0};

    memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"setTimeZone"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    /*获取要设置的时区值(ID)*/
    timezone_id = cJSON_GetObjectItem(p_request,"timeZoneID")->valueint;
    cJSON_Delete(p_request);

    /*时区转换*/
    convert_Time_Zone(timezone_id);

    /*将新的时区设置保存下来*/
    fp = fopen(SYSTIME_JSON_FILE,"r");
    if(fp == NULL)
    {
        print_log("open json file %s failed.",SYSTIME_JSON_FILE);  
        return;   
    }
    fread(content, 1, 128, fp);
    fclose(fp);

    p_conf = cJSON_Parse(content);
    if(p_conf == NULL)
    {
        print_log("parse file %s content failed.",SYSTIME_JSON_FILE);
        return;
    }
    cJSON_ReplaceItemInObject(p_conf,"timezone_id",cJSON_CreateNumber(timezone_id));
    p = cJSON_PrintUnformatted(p_conf);

    fp = fopen(SYSTIME_JSON_FILE,"w");
    if(fp == NULL)
    {
        print_log("open json file %s failed.",SYSTIME_JSON_FILE);  
        cJSON_Delete(p_conf);
        return;   
    }
    fwrite(p, 1, strlen(p), fp);
    fclose(fp);
    cJSON_Delete(p_conf);
    free(p);

    /*记录操作日志*/
    init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"设置时区");
    strcpy(op_log.op_status,"success");
    add_one_op_log(&op_log);

    /*返回结果到前端*/
    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json  obj failed.");
        return;       
    }
    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddStringToObject(p_resp_root,"msg","setTimeZone successfu.");

    p = cJSON_PrintUnformatted(p_resp_root);
    http_back(p_nc,p);
    free(p);
    cJSON_Delete(p_resp_root);
}

/**
 * @brief 系统时间模块初始化
 * @return void
 */
void web_sys_time_module_init(void)
{
    /*获取系统当前的运行时间*/
	if(!web_func_attach("/system/getSysTime", get_system_time_info))
	{
		print_log("[/system/getSysTime] attach failed");
	}
	/*NTP同步时间*/
	if(!web_func_attach("/system/ntpSyncTime", ntp_sync_time))
	{
		print_log("[/system/ntpSyncTime] attach failed");
	}
	/*手动设置时间*/
	if(!web_func_attach("/system/customSetTime", custom_set_time))
	{
		print_log("[/system/customSetTime] attach failed");
	}
	/*设置时区*/
	if(!web_func_attach("/system/setTimeZone", set_timezone_info))
	{
		print_log("[/system/setTimeZone] attach failed");
	}
	
}