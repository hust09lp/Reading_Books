#include "sdk_fs.h"
#include "sdk_shm.h"
#include "sdk_file.h"
#include "history_drdata.h"
#include "web_public.h"
#include "crc.h"
#include "cJSON.h"
#include "common.h"
#include "operating_data_handle.h"
#include "web_broker.h"

#define READ_MAX_COUNT       288
typedef struct	{
	time_t start_time;
	time_t end_time;
	struct tm tm_start_time;
	struct tm tm_end_time;
}time_span_t;


typedef struct	{
	uint8_t start_time[32];
	uint8_t end_time[32];
}operation_records_time_t;


/**
 * @brief	对读取的运行数据帧进行crc校验
 * @param	[in] p_operating_data 运行数据结构体指针
 * @return	结果
 * @retval	0 成功
 * @retval	-1 失败
 */
static int32_t operating_record_data_frame_crc_check(operating_data_t *p_operating_data)
{
	int32_t ret = -1;
	uint32_t crc;

	crc = crc32((const unsigned char *)p_operating_data, (sizeof(operating_data_t) - 4));
	if (p_operating_data->crc == crc)
	{
		ret = 0;
	}

	return ret;
}

static void operating_record_data_json_input(time_span_t time_span, operating_data_t *p_operating_data, cJSON *p_resp_array)
{
	cJSON *p_resp_item;
	int32_t i;
	int32_t apparent_power = 0;
	int32_t active_power = 0;
	int32_t reactive_power = 0; 
	time_t time_ts;
    uint8_t date[32] = {0};
    char str_buff[64] = {0};
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();

	p_resp_item = cJSON_CreateObject();
	if(p_resp_item == NULL)
	{
		print_log((int8_t *)"create json obj failed.");	 
		return;
	}

	sprintf(date, "%04d-%02d-%02d %02d:%02d:%02d", 2000 + p_operating_data->operating_time.tm_year, 
                                                            p_operating_data->operating_time.tm_mon, 
                                                            p_operating_data->operating_time.tm_day, 
                                                            p_operating_data->operating_time.tm_hour, 
                                                            p_operating_data->operating_time.tm_min, 
                                                            p_operating_data->operating_time.tm_sec); 
	cJSON_AddStringToObject(p_resp_item,"time", date);

	cJSON_AddNumberToObject(p_resp_item, "cylinderPressure", p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.ff_cylinder_press); 
	
    if(p_telemetry_data->container_system_telemetry_info.battery_cluster_number == 1)
    {
        memset(str_buff, 0, sizeof(str_buff));
        sprintf(str_buff, "%d", p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.mix_sensor1_co_ppm);
        cJSON_AddStringToObject(p_resp_item, "COConcentration", str_buff); 

        memset(str_buff, 0, sizeof(str_buff));
        sprintf(str_buff, "%0.1f", p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.bat1_temper / 10.0);
        cJSON_AddStringToObject(p_resp_item, "CabinTemperature", str_buff); 

        memset(str_buff, 0, sizeof(str_buff));
        sprintf(str_buff, "%d", p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.bat1_humidity);
        cJSON_AddStringToObject(p_resp_item, "CabinHumidity", str_buff); 
    }
    else if(p_telemetry_data->container_system_telemetry_info.battery_cluster_number == 2)
    {
        memset(str_buff, 0, sizeof(str_buff));
        sprintf(str_buff, "%d/%d", p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.mix_sensor1_co_ppm,
                                        p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.mix_sensor2_co_ppm);
        cJSON_AddStringToObject(p_resp_item, "COConcentration", str_buff); 

        memset(str_buff, 0, sizeof(str_buff));
        sprintf(str_buff, "%0.1f/%0.1f", p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.bat1_temper / 10.0,
                                        p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.bat2_temper / 10.0);
        cJSON_AddStringToObject(p_resp_item, "CabinTemperature", str_buff); 

        memset(str_buff, 0, sizeof(str_buff));
        sprintf(str_buff, "%d/%d", p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.bat1_humidity,
                                        p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.bat2_humidity);
        cJSON_AddStringToObject(p_resp_item, "CabinHumidity", str_buff); 
    }
    else if(p_telemetry_data->container_system_telemetry_info.battery_cluster_number == 3)
    {
        memset(str_buff, 0, sizeof(str_buff));
        sprintf(str_buff, "%d/%d/%d", p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.mix_sensor1_co_ppm,
                                        p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.mix_sensor2_co_ppm,
                                        p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.mix_sensor3_co_ppm);
        cJSON_AddStringToObject(p_resp_item, "COConcentration", str_buff); 

        memset(str_buff, 0, sizeof(str_buff));
        sprintf(str_buff, "%0.1f/%0.1f/%0.1f", p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.bat1_temper / 10.0,
                                        p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.bat2_temper / 10.0,
                                        p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.bat3_temper / 10.0);
        cJSON_AddStringToObject(p_resp_item, "CabinTemperature", str_buff); 

        memset(str_buff, 0, sizeof(str_buff));
        sprintf(str_buff, "%d/%d/%d", p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.bat1_humidity,
                                        p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.bat2_humidity,
                                        p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.bat3_humidity);
        cJSON_AddStringToObject(p_resp_item, "CabinHumidity", str_buff); 
    }
    else if(p_telemetry_data->container_system_telemetry_info.battery_cluster_number == 4)
    {
        memset(str_buff, 0, sizeof(str_buff));
        sprintf(str_buff, "%d/%d/%d/%d", p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.mix_sensor1_co_ppm,
                                        p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.mix_sensor2_co_ppm,
                                        p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.mix_sensor3_co_ppm,
                                        p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.mix_sensor4_co_ppm);
        cJSON_AddStringToObject(p_resp_item, "COConcentration", str_buff); 

        memset(str_buff, 0, sizeof(str_buff));
        sprintf(str_buff, "%0.1f/%0.1f/%0.1f/%0.1f", p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.bat1_temper / 10.0,
                                        p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.bat2_temper / 10.0,
                                        p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.bat3_temper / 10.0,
                                        p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.bat4_temper / 10.0);
        cJSON_AddStringToObject(p_resp_item, "CabinTemperature", str_buff); 

        memset(str_buff, 0, sizeof(str_buff));
        sprintf(str_buff, "%d/%d/%d/%d", p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.bat1_humidity,
                                        p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.bat2_humidity,
                                        p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.bat3_humidity,
                                        p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.bat4_humidity);
        cJSON_AddStringToObject(p_resp_item, "CabinHumidity", str_buff); 
    }
 
	cJSON_AddNumberToObject(p_resp_item, "OutletWaterPressure", p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.lc_outlet_pressure); 
    cJSON_AddNumberToObject(p_resp_item, "InputWaterPressure", p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.lc_inlet_pressure); 
    cJSON_AddNumberToObject(p_resp_item, "OutletWaterTemperature", p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.lc_outlet_temp / 10.0); 
	cJSON_AddNumberToObject(p_resp_item, "InputWaterTemperature", p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.lc_inlet_temp / 10.0); 
    cJSON_AddNumberToObject(p_resp_item, "ambientTemperature", p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.lc_outdoor_temper / 10.0); 
    cJSON_AddNumberToObject(p_resp_item, "PumpOutput", p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info.pump_flow_rate); 

	cJSON_AddItemToArray(p_resp_array,p_resp_item);

	return;
}


/**
  * @brief	动环历史读取函数
  * @param	[in] time_span 要读取的时间段
  * @param	[in] file_name 存储数据记录的文件名。
  * @param	[out] p_resp_array json对象指针 
  * @return 读取结果 
*/
static int32_t history_dr_data_read(time_span_t time_span, uint8_t *file_name, cJSON *p_resp_array)
{
  	uint8_t file_path[128] = {0};
 	uint8_t folder[8] = {0};
    int32_t ret = 0;
    fs_t *p_fs_src = NULL;
	int32_t file_size = 0;
	int32_t once_len = 0;
	int32_t loop_count = 0;	
	int32_t ret_len = 0;
	int32_t crc_check = 0;
	uint32_t offset = 0;
	operating_data_t operating_data = {0};
	
	print_log("[%s:%d]",__func__, __LINE__);
	
	/*组装完整路径*/
	snprintf((char*)folder, 5, "%s", file_name);
	snprintf((char*)file_path, sizeof(file_path), PATH_OPERATING_RECORD_FOLDER "%s/%s", folder, file_name);

	p_fs_src = sdk_fs_open((const int8_t *)file_path, FS_READ);
	if (p_fs_src == NULL)
	{
		print_log((int8_t *)"\n sdk_fs_open  file fail! \n");
		return FAIL;
	}
	
	file_size = sdk_fs_get_size(p_fs_src);
	once_len = sizeof(operating_data_t);
	loop_count = file_size / once_len;
	print_log((int8_t *)"[%s:%d] src_size: %d, loop_count: %d, once_len: %d\n", __func__, __LINE__, file_size, loop_count, once_len);
	if (loop_count < 1)
	{
		print_log((int8_t *)"[%s:%d] no content!\n", __func__, __LINE__);
		sdk_fs_close(p_fs_src);
		return FAIL;
	}
	else if (loop_count > READ_MAX_COUNT)
	{
		print_log((int8_t *)"[%s:%d] overflow!\n", __func__, __LINE__);
		loop_count = READ_MAX_COUNT;
	}
	offset = (loop_count - 1) * once_len;
    while (loop_count)
    {
        memset(&operating_data, 0 , sizeof(operating_data_t));
		
		sdk_fs_lseek(p_fs_src, offset);
        ret_len = sdk_fs_read(p_fs_src, &operating_data, sizeof(operating_data_t));
        if (ret_len != once_len)
        {
            print_log((int8_t *)"[%s:%d] read len error! ret_len = %d\n", __func__, __LINE__, ret_len);
			sdk_fs_close(p_fs_src);
			return FAIL;

        }
		
        crc_check = operating_record_data_frame_crc_check(&operating_data);
        if (crc_check < 0)
        {
            print_log((int8_t *)"[%s:%d] frame crc error!\n", __func__, __LINE__);
            
        }
        else
        {
			// print_log((int8_t *)"[%s:%d] frame crc ok!\n", __func__, __LINE__);
			operating_record_data_json_input(time_span, &operating_data, p_resp_array);
        }

        loop_count--;
		offset -= once_len;
    }	 
	 sdk_fs_close(p_fs_src);
	 return SUCCESS;
	
}


 /**
 * @brief  比较大小排序
 * @param  [in] low low下标
 * @param  [in] high high下标
 * @param  [out] arr 指针数组 
 * @return
 */ 
static int partition(uint8_t *arr[], int32_t low, int32_t high) 
{
	char *pivot = arr[high];
	int i = (low - 1);
	
	for (int j = low; j <= high - 1; j++) 
	{
		if (strcmp(arr[j], pivot) < 0) 
		{
			i++;
			char *temp = arr[i];
			arr[i] = arr[j];
			arr[j] = temp;
		}
	}
	
	char *temp = arr[i + 1];
	arr[i + 1] = arr[high];
	arr[high] = temp;
	return (i + 1);
}
 
/**
 * @brief  文件名按照时间快速排序
 * @param  [in] low low下标
 * @param  [in] high high下标
 * @param  [out] arr  指针数组
 * @return
 */ 
static void quicksort(uint8_t *arr[], int32_t low, int32_t high) 
{
	if (low < high) 
	{
		int pivot = partition(arr, low, high);
		quicksort(arr, low, pivot - 1);
		quicksort(arr, pivot + 1, high);
	}
}


/**
 * @brief  符合条件的文件路径加入数组
 * @param  [in] time_span 要读取的时间段 
 * @param  [in] path  文件路径
 * @param  [out] file_count  文件总数 
 * @return
 */
static void add_files_to_array(time_span_t time_span, const uint8_t *path, uint8_t *files[], int32_t *file_count)
{
	DIR *d;
	struct dirent *dir;
	uint8_t satrt_str[16];
	uint8_t end_str[16];

	snprintf((char*)satrt_str, sizeof(satrt_str),  "%04d%02d%02d", time_span.tm_start_time.tm_year, time_span.tm_start_time.tm_mon,
                                                            time_span.tm_start_time.tm_mday);
	snprintf((char*)end_str, sizeof(end_str),  "%04d%02d%02d", time_span.tm_end_time.tm_year, time_span.tm_end_time.tm_mon,
                                                        time_span.tm_end_time.tm_mday);
                                                        
	print_log((int8_t *)"satrt_str %s end_str %s\n",satrt_str,end_str);
	d = opendir(path);
	if (d) 
	{
		while ((dir = readdir(d)) != NULL) 
		{
			if (!strcmp(dir->d_name, ".") || !strcmp(dir->d_name, "..")) 
			{
				// skip self and parent
				continue;
			}
			/* 历史文件格式为：年+月+日 20230101。不符合此条件的文件跳过*/
		if (strlen(dir->d_name) != HISTORY_FILE_LEN)
		{
			
				continue;
		}
			/*跳过小于开始日期大于结束日期的文件*/
		if ((strncmp(dir->d_name, satrt_str, HISTORY_FILE_LEN) < 0) || ((strncmp(dir->d_name, end_str, HISTORY_FILE_LEN) > 0) ))
		{
			continue;
		}
			files[*file_count] = malloc(strlen(dir->d_name) + 1);
			strcpy(files[*file_count], dir->d_name);
			*file_count = *file_count + 1;
		}
		closedir(d);
	}
}

/**
 * @brief  读取符合时间的记录
 * @param  [in] time_span 要读取的时间段 
 * @param  [in] p_resp_array  json数组
 * @return
 */
static void traverse_folder(time_span_t time_span, cJSON *p_resp_array)
{
	uint8_t file_path[PATH_FILE_MAX_LEN] = {0};
	uint8_t *files[1000]; 
	int32_t file_count = 0;
	sdk_rtc_t expire_date = {0};
	DIR *d = NULL;
	struct dirent *dir = NULL;
	
	/* 历史文件存储为路径为 历史记录文件夹 + 年份 + 日期*/
	d = opendir(PATH_DR_HISTORY_FOLDER);
	if (d) 
	{
		while ((dir = readdir(d)) != NULL) 
		{
			if (!strcmp(dir->d_name, ".") || !strcmp(dir->d_name, "..")) {
					// skip self and parent
					continue;
			}
			/*年份文件夹*/
			if (dir->d_type == 4)
			{
				print_log((int8_t *)"++++%s\n", dir->d_name);

				snprintf((char*)file_path, sizeof(file_path), PATH_DR_HISTORY_FOLDER "/%s", dir->d_name);		 
				add_files_to_array(time_span, file_path, files, &file_count);

			}
		}
		closedir(d);
	}

	quicksort(files, 0, file_count - 1);

	for (int i = 0; i < file_count; i++) 
	{
		print_log((int8_t *)"%s\n", files[file_count - 1 - i]);		 
		history_dr_data_read(time_span, files[file_count - 1 - i], p_resp_array);
		free(files[file_count - 1 - i]);
	}
	 
}


 /**
  * @brief  获取动环系统历史记录
  * @param  [in] *p_nc 连接信息 
  * @param  [in] *p_msg  http请求信息
  * @return
  */
void get_dr_history_info(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_root = NULL;
    cJSON *p_resp_array = NULL;
    cJSON *p_resp_item = NULL;	
    uint8_t response[256] = {0};
    uint8_t *p_action = NULL;
	int32_t i = 0;
    uint8_t *p_start = NULL;
    uint8_t *p_end = NULL;
    uint8_t *p = NULL;
    uint8_t request_body[1024] = {0};
	time_span_t time_span = {0};
	
    memcpy(request_body, p_msg->body.p, p_msg->body.len);
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log((int8_t *)"parse request failed.");
		build_empty_response(response, 202, "parse request failed.");
		http_back(p_nc, response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request, "action")->valuestring;
    print_log((int8_t *)"action is %s.", p_action);
	if(strcmp(p_action, "getDynamicEnvironmentList"))
	{
		print_log((int8_t *)"action is not right.");
		build_empty_response(response, 203, "action is not right");
		http_back(p_nc, response);
		cJSON_Delete(p_request);
		return;
	}
	if ((NULL == cJSON_GetObjectItem(p_request, "start")) || (NULL == cJSON_GetObjectItem(p_request, "end")))
	{
		print_log((int8_t *)"start/end time not right.");
		build_empty_response(response, 203, "start/end time not right");
		http_back(p_nc, response);
		cJSON_Delete(p_request);
		return;
	}

	p_start = cJSON_GetObjectItem(p_request,"start")->valuestring;
	p_end = cJSON_GetObjectItem(p_request,"end")->valuestring;

    sscanf(p_start, "%04d-%02d-%02d %02d:%02d:%02d", &time_span.tm_start_time.tm_year, &time_span.tm_start_time.tm_mon,
                                                     &time_span.tm_start_time.tm_mday, &time_span.tm_start_time.tm_hour, 
                                                     &time_span.tm_start_time.tm_min, &time_span.tm_start_time.tm_sec);
    sscanf(p_end, "%04d-%02d-%02d %02d:%02d:%02d", &time_span.tm_end_time.tm_year, &time_span.tm_end_time.tm_mon,
                                                   &time_span.tm_end_time.tm_mday, &time_span.tm_end_time.tm_hour, 
                                                &time_span.tm_end_time.tm_min, &time_span.tm_end_time.tm_sec);
    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log((int8_t *)"create json obj failed.");
        return ;
    }

	cJSON_AddNumberToObject(p_resp_root, "code", 200);

    p_resp_array = cJSON_CreateArray();
    if(p_resp_array == NULL)
    {
        print_log((int8_t *)"create json array failed.");
        cJSON_Delete(p_resp_root);
        return;
    }

	traverse_folder(time_span, p_resp_array);

	cJSON_AddItemToObject(p_resp_root, "data", p_resp_array);
	
	cJSON_AddStringToObject(p_resp_root, "msg","get successful");
	
	p = cJSON_PrintUnformatted(p_resp_root);

	print_log((int8_t *)" json len %d", strlen(p));

	cJSON_Delete(p_resp_root);


	http_back(p_nc,p); 
	free(p);	
 }


/**
 * @brief 动环历史数据模块初始化
 * @return void
 */
void history_dr_data_module_init(void)
{
	/*获取动环历史信息*/
	if(!web_func_attach("/getHistoryInfo/getDynamicEnvironmentList", get_dr_history_info))
	{
		print_log("[/getHistoryInfo/getDynamicEnvironmentList] attach failed");
	}
}