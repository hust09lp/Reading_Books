#include "js_api_common.h"
#include "sdk_log.h"

#include "cJSON.h"
#include <string.h>

/**
 * @brief  json字符串下面 action 字段和用户 usr_match_action_str相匹配
 * @param  [in] req_js_str           ： json请求字符串
 * @param  [in] usr_match_action_str ： 用户匹配 action 数值字符串
 * @return SF_TRUE : action数值与 usr_match_action_str 相匹配
 * @return SF_FALSE : 不匹配
 * @note   
 */ 
bool js_api_common_js_str_action_val_cmp( const char *js_str, const char *usr_match_action_str )
{
    bool ret = SF_FALSE;
    cJSON *p_root_js = cJSON_Parse( js_str );
    if ( p_root_js == NULL )
    {
        log_e( (const int8_t*)"%s p_root_js == NULL!!!", __FUNCTION__ );
        return SF_FALSE;
    }

    cJSON *p_act_js = cJSON_GetObjectItem( p_root_js, "action" );
    if ( p_act_js == NULL )
    {
        log_e( (const int8_t*)"%s p_act_js == NULL!!!", __FUNCTION__ );
        cJSON_Delete( p_root_js );
        return SF_FALSE;
    }
    ret = (strcmp( p_act_js->valuestring, usr_match_action_str ) == 0 ) ? SF_TRUE : SF_FALSE;
    cJSON_Delete( p_root_js );
    
    return ret;
}

