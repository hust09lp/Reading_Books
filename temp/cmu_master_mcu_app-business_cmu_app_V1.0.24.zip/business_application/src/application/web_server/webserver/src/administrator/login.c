#include<stdio.h>
#include<stdlib.h>
#include"administrator.h"
#include"cJSON.h"
#include"common.h"

#define MAX_BUFF (200 * 250)   //每一条最多占用200字节,最多可以有250条
login_status_e is_login_success(const uint8_t *p_user_name,const uint8_t *p_pass_word,uint8_t *role)
{
	cJSON *p_root_array;
	cJSON *p_array_item;
	FILE *fp;
	login_status_e login_status = LOGIN_FAILED;
	uint8_t content[MAX_BUFF] = {0};
	uint8_t md5[16] = {0};
	uint8_t md5_str[33] = {0};
	uint8_t *p_uname,*p_pwd,*p_stat;
	uint8_t i;
	md5_calcul(p_pass_word,strlen(p_pass_word),md5);
	hex_to_str(md5,md5_str,16);

	fp = fopen(ADMIN_JSON_FILE,"r");
	if(fp == NULL)
	{
		print_log("open file %s failed.",ADMIN_JSON_FILE);
		return LOGIN_FAILED;
	}
	fread(content,1,MAX_BUFF,fp);
	fclose(fp);
	p_root_array = cJSON_Parse(content);
	if(p_root_array == NULL)
	{
		print_log("parse json content failed,content:\n%s",content);
		return LOGIN_FAILED;
	}
	for(i=0;i<cJSON_GetArraySize(p_root_array);i++)
	{
		p_array_item = cJSON_GetArrayItem(p_root_array,i);
		if(p_array_item == NULL)
		{
			print_log("get array item [%d] failed.",i);
			goto END;
		}
	 	p_uname = cJSON_GetObjectItem(p_array_item,"username")->valuestring;
		p_pwd = cJSON_GetObjectItem(p_array_item,"password")->valuestring;
		p_stat = cJSON_GetObjectItem(p_array_item,"status")->valuestring;
		if(!strcmp(p_user_name,p_uname) && !strcmp(md5_str,p_pwd) && !strcmp(p_stat,"activated"))
		{
//			print_log("get username [%s],password is ok and the account is activated",p_uname);
			login_status = LOGIN_OK;
			strcpy(role,cJSON_GetObjectItem(p_array_item,"role")->valuestring);
			goto END;
		}
	}
	END:
	if(p_root_array != NULL)
	{
		cJSON_Delete(p_root_array);
	}
	return login_status;
}

void do_login(struct mg_connection *p_nc,struct http_message *p_msg)
{
	uint8_t response[64] = {0};
	uint8_t request_body[1024] = {0};
	uint8_t *p_action;
	uint8_t *p_username,*p_password;
	uint8_t *p_reason;
	uint8_t status_code;
	cJSON *p_root;
	operation_log_t op_log;
	uint8_t user_role[16] = {0};
	cJSON *p_resp_root;
	uint8_t *p;

	if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}
	p_root = cJSON_Parse(request_body);

	if(p_root == NULL)
	{
		print_log("parse query string failed");
		status_code = 202;
		p_reason = "parse query string failed";
		goto END;
	}

	p_action = cJSON_GetObjectItem(p_root,"action")->valuestring;
	if(strcmp(p_action,"login"))
	{
		print_log("action is not right");
		status_code = 203;
		p_reason = "action is not right";
		goto END;
	}

	p_username = cJSON_GetObjectItem(p_root,"userName")->valuestring;
	p_password = cJSON_GetObjectItem(p_root,"passWord")->valuestring;

	init_user_basic_info(&op_log);
	strcpy(op_log.user_name,p_username);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"用户登录");

	if(is_login_success(p_username,p_password,user_role) == LOGIN_OK)
	{
		status_code = 200;
		p_reason = "login successful";
		strcpy(op_log.op_status,"success");
		add_one_op_log(&op_log);
		goto END;
	}
	else
	{
		print_log("login failed");
		status_code = 201;
		strcpy(op_log.op_status,"failed");
		add_one_op_log(&op_log);
		p_reason = "login failed";
	}

END:
	if(p_root != NULL)
	{
		cJSON_Delete(p_root);
	}
//	build_empty_response(response,status_code,p_reason);

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		print_log("action is not right");
		return;
	}
	cJSON_AddNumberToObject(p_resp_root,"code",status_code);
	cJSON_AddStringToObject(p_resp_root,"userRole",user_role);
	cJSON_AddStringToObject(p_resp_root,"devType","CMU");
	cJSON_AddStringToObject(p_resp_root,"msg",p_reason);

	p = cJSON_PrintUnformatted(p_resp_root);
	strcpy(response,p);

	cJSON_Delete(p_resp_root);
	free(p);
	
	http_back(p_nc,response);
}
