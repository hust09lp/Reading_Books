#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"cJSON.h"
#include"batteryinfo.h"
#include"common.h"
#include"debugmanage.h"
#include"web_data_interface.h"
#include"sdk_shm.h"
#include "web_broker.h"

void get_battery_cluster_info(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_array;
    cJSON *p_resp_item;
    cJSON *p_resp_root;
    uint8_t response[64];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t i;
    uint8_t request_body[1024] = {0};
    battery_cluster_page_t cluster_info;
    debug_manage_page_read_t debug_info;

    container_system_telemetry_info_t *p_yc_data = &(sdk_shm_telemetry_data_get()->container_system_telemetry_info);
    telematic_data_t *p_telematic = sdk_shm_telematic_data_get();
    telemetry_data_t *p_telemetry = sdk_shm_telemetry_data_get();
    constant_parameter_data_t* p_constant_param = sdk_shm_constant_parameter_data_get();

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getBatteryClusterInfo"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

    p_resp_array = cJSON_CreateArray();
    if(p_resp_array == NULL)
    {
        print_log("create json array failed");
        return;
    }

    cluster_info_page_get(&cluster_info);
    debug_manage_page_get(&debug_info);

    for(i=0;i<BCU_DEVICE_NUM;i++)
    {
        p_resp_item = cJSON_CreateObject();
        if(p_resp_item == NULL)
        {
            print_log("create json obj failed");
            cJSON_Delete(p_resp_array);
            return;
        }
        cJSON_AddNumberToObject(p_resp_item,"communicationSta",cluster_info.battery_cluster_info[i].BCU_comm_status);
        cJSON_AddNumberToObject(p_resp_item,"voltage",cluster_info.battery_cluster_info[i].cluster_voltage/10.0);
        cJSON_AddNumberToObject(p_resp_item,"current",-((cluster_info.battery_cluster_info[i].cluster_current - 16000)/10.0));
        cJSON_AddNumberToObject(p_resp_item,"soc",cluster_info.battery_cluster_info[i].cluster_SOC);
        cJSON_AddNumberToObject(p_resp_item,"soh",cluster_info.battery_cluster_info[i].average_SOH_monomer);
        cJSON_AddNumberToObject(p_resp_item,"monomerVmax",cluster_info.battery_cluster_info[i].highest_monomer_voltage);
        cJSON_AddNumberToObject(p_resp_item,"monomerVmaxIndex",cluster_info.battery_cluster_info[i].battery_node_highest_voltage);
        cJSON_AddNumberToObject(p_resp_item,"monomerVmin",cluster_info.battery_cluster_info[i].lowest_monomer_voltage);
        cJSON_AddNumberToObject(p_resp_item,"monomerVminIndex",cluster_info.battery_cluster_info[i].battery_node_lowest_voltage);
        cJSON_AddNumberToObject(p_resp_item,"monomerVmean",cluster_info.battery_cluster_info[i].average_voltage_monomer);
        cJSON_AddNumberToObject(p_resp_item,"monomerTmax",(cluster_info.battery_cluster_info[i].highest_monomer_temperature - 40));
        cJSON_AddNumberToObject(p_resp_item,"monomerTmaxIndex",cluster_info.battery_cluster_info[i].battery_node_highest_temperature);
        cJSON_AddNumberToObject(p_resp_item,"monomerTmin",(cluster_info.battery_cluster_info[i].lowest_monomer_temperature - 40));
        cJSON_AddNumberToObject(p_resp_item,"monomerTminIndex",cluster_info.battery_cluster_info[i].battery_node_lowest_temperature);
        cJSON_AddNumberToObject(p_resp_item,"monomerTmean",(cluster_info.battery_cluster_info[i].average_temperature_monomer - 40));
        cJSON_AddNumberToObject(p_resp_item,"precombT1",(cluster_info.battery_cluster_info[i].high_pressure_box_temperature1 - 40));
        cJSON_AddNumberToObject(p_resp_item,"precombT2",(cluster_info.battery_cluster_info[i].high_pressure_box_temperature2 - 40));
        cJSON_AddNumberToObject(p_resp_item,"precombT3",(cluster_info.battery_cluster_info[i].high_pressure_box_temperature3 - 40));
        cJSON_AddNumberToObject(p_resp_item,"precombT4",(cluster_info.battery_cluster_info[i].high_pressure_box_temperature4 - 40));
        // cJSON_AddNumberToObject(p_resp_item,"posInsulation",cluster_info.battery_cluster_info[i].positive_insulation_resistance);
        //临时显示为负绝缘阻抗
        cJSON_AddNumberToObject(p_resp_item,"posInsulation",cluster_info.battery_cluster_info[i].negative_insulation_resistance);
        cJSON_AddNumberToObject(p_resp_item,"NegInsulation",cluster_info.battery_cluster_info[i].negative_insulation_resistance);
        cJSON_AddStringToObject(p_resp_item,"preChargeRelay",((debug_info.battery_cluster_status_info[i][1] & (1<<1)) == 0) ? "0" : "1");
        cJSON_AddStringToObject(p_resp_item,"mainPosRelay",(cluster_info.battery_cluster_info[i].positive_relay_status == 0) ? "0" : "1");
        cJSON_AddStringToObject(p_resp_item,"mainNegaRelay",(cluster_info.battery_cluster_info[i].negative_relay_status == 0) ? "0" : "1");

        switch(i)
        {
            case 0:
                cJSON_AddNumberToObject(p_resp_item,"temperatrue",p_yc_data->bat1_temper/10.0);
                cJSON_AddNumberToObject(p_resp_item,"humidity",p_yc_data->bat1_humidity);
                cJSON_AddNumberToObject(p_resp_item,"coConcentration",p_yc_data->mix_sensor1_co_ppm);
                cJSON_AddNumberToObject(p_resp_item,"pm25Concentration",p_yc_data->mix_sensor1_pm25_ppm);
                cJSON_AddStringToObject(p_resp_item,"batteryDoorStatus",((p_telematic->container_system_status_info[1] & (1 << 3)) != 0)?"1":"0");
                if(cluster_info.battery_cluster_info[i].BCU_comm_status != 0)
                {
                    cJSON_AddNumberToObject(p_resp_item,"fireCylPress", p_telemetry->container_system_telemetry_info.ff_cylinder_press );
                }
                else
                {
                    cJSON_AddNumberToObject(p_resp_item,"fireCylPress", 0 );
                }
                break;

            case 1:
                cJSON_AddNumberToObject(p_resp_item,"temperatrue",p_yc_data->bat2_temper/10.0);
                cJSON_AddNumberToObject(p_resp_item,"humidity",p_yc_data->bat2_humidity);
                cJSON_AddNumberToObject(p_resp_item,"coConcentration",p_yc_data->mix_sensor2_co_ppm);
                cJSON_AddNumberToObject(p_resp_item,"pm25Concentration",p_yc_data->mix_sensor2_pm25_ppm);
                cJSON_AddStringToObject(p_resp_item,"batteryDoorStatus",((p_telematic->container_system_status_info[1] & (1 << 4)) != 0)?"1":"0");
                if(cluster_info.battery_cluster_info[i].BCU_comm_status != 0)
                {
                    cJSON_AddNumberToObject(p_resp_item,"fireCylPress", p_telemetry->container_system_telemetry_info.ff_cylinder_press );
                }
                else
                {
                    cJSON_AddNumberToObject(p_resp_item,"fireCylPress", 0 );
                }
                break;    

            case 2:
                cJSON_AddNumberToObject(p_resp_item,"temperatrue",p_yc_data->bat3_temper/10.0);
                cJSON_AddNumberToObject(p_resp_item,"humidity",p_yc_data->bat3_humidity);
                cJSON_AddNumberToObject(p_resp_item,"coConcentration",p_yc_data->mix_sensor3_co_ppm);
                cJSON_AddNumberToObject(p_resp_item,"pm25Concentration",p_yc_data->mix_sensor3_pm25_ppm);
                cJSON_AddStringToObject(p_resp_item,"batteryDoorStatus",((p_telematic->container_system_status_info[1] & (1 << 5)) != 0)?"1":"0");
                
                if(cluster_info.battery_cluster_info[i].BCU_comm_status != 0)
                {
                    cJSON_AddNumberToObject(p_resp_item,"fireCylPress", p_telemetry->container_system_telemetry_info.ff_cylinder_press );
                }
                else
                {
                    cJSON_AddNumberToObject(p_resp_item,"fireCylPress", 0 );
                }
                break;   

            case 3:
                cJSON_AddNumberToObject(p_resp_item,"temperatrue",p_yc_data->bat4_temper/10.0);
                cJSON_AddNumberToObject(p_resp_item,"humidity",p_yc_data->bat4_humidity);
                cJSON_AddNumberToObject(p_resp_item,"coConcentration",p_yc_data->mix_sensor4_co_ppm);
                cJSON_AddNumberToObject(p_resp_item,"pm25Concentration",p_yc_data->mix_sensor4_pm25_ppm);
                cJSON_AddStringToObject(p_resp_item,"batteryDoorStatus",((p_telematic->container_system_status_info[1] & (1 << 6)) != 0)?"1":"0");
                if(cluster_info.battery_cluster_info[i].BCU_comm_status != 0)
                {
                    cJSON_AddNumberToObject(p_resp_item,"fireCylPress", p_telemetry->container_system_telemetry_info.ff_cylinder_press );
                }
                else
                {
                    cJSON_AddNumberToObject(p_resp_item,"fireCylPress", 0 );
                }
                break;

            case 4:
                cJSON_AddNumberToObject(p_resp_item,"temperatrue",p_yc_data->bat5_temper/10.0);
                cJSON_AddNumberToObject(p_resp_item,"humidity",p_yc_data->bat5_humidity);
                cJSON_AddNumberToObject(p_resp_item,"coConcentration",p_yc_data->mix_sensor5_co_ppm);
                cJSON_AddNumberToObject(p_resp_item,"pm25Concentration",p_yc_data->mix_sensor5_pm25_ppm);
                cJSON_AddStringToObject(p_resp_item,"batteryDoorStatus",((p_telematic->container_system_status_info[1] & (1 << 7)) != 0)?"1":"0");
                if(cluster_info.battery_cluster_info[i].BCU_comm_status != 0)
                {
                    cJSON_AddNumberToObject(p_resp_item,"fireCylPress", p_telemetry->container_system_telemetry_info.ff_cylinder_press );
                }
                else
                {
                    cJSON_AddNumberToObject(p_resp_item,"fireCylPress", 0 );
                }
                break;

            case 5:
                cJSON_AddNumberToObject(p_resp_item,"temperatrue",p_yc_data->bat6_temper/10.0);
                cJSON_AddNumberToObject(p_resp_item,"humidity",p_yc_data->bat6_humidity);
                cJSON_AddNumberToObject(p_resp_item,"coConcentration",p_yc_data->mix_sensor6_co_ppm);
                cJSON_AddNumberToObject(p_resp_item,"pm25Concentration",p_yc_data->mix_sensor6_pm25_ppm);
                cJSON_AddStringToObject(p_resp_item,"batteryDoorStatus",((p_telematic->container_system_status_info[2] & (1 << 0)) != 0)?"1":"0");
                if(cluster_info.battery_cluster_info[i].BCU_comm_status != 0)
                {
                    cJSON_AddNumberToObject(p_resp_item,"fireCylPress", p_telemetry->container_system_telemetry_info.ff_cylinder_press );
                }
                else
                {
                    cJSON_AddNumberToObject(p_resp_item,"fireCylPress", 0 );
                }
                break;

            default:
                break;
        }

        cJSON_AddItemToArray(p_resp_array,p_resp_item);
    }

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        cJSON_Delete(p_resp_array);
        return;
    }
    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddItemToObject(p_resp_root,"data",p_resp_array);
    cJSON_AddStringToObject(p_resp_root,"msg","get battery cluster info successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_resp_root);

    http_back(p_nc,p);
    free(p);
}

void get_battery_pack_info(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_array;
    cJSON *p_resp_item;
    cJSON *p_resp_root;
    uint8_t response[4096];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t i;
    uint8_t cluster_index;  //第几簇
    uint8_t pack_index;    //第几个pack包
    uint8_t request_body[1024] = {0};
    web_monomer_info_t monomer_info;
    uint32_t total_voltage;
    uint8_t cluster_num;  //一共有几簇
    uint8_t pack_num;    //每簇有几个pack
    constant_parameter_data_t * p_constant_param_data = sdk_shm_constant_parameter_data_get();
    uint8_t data_valid = 0;

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getBatteryDetailInfo"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    cluster_index = cJSON_GetObjectItem(p_request,"clusterIndex")->valueint;
    pack_index = cJSON_GetObjectItem(p_request,"packIndex")->valueint;
    cJSON_Delete(p_request);

    p_resp_array = cJSON_CreateArray();
    if(p_resp_array == NULL)
    {
        print_log("create json array failed");
        return;
    }
    total_voltage = 0;
    memset(&monomer_info, 0, sizeof(web_monomer_info_t));

    /*获取电池簇个数和PACK个数*/
    cluster_num = p_constant_param_data->bat_cabinet_num;  
    pack_num = p_constant_param_data->bat_cluster_pack_num;

    /*如果要获取的储能柜和PACK的索引在合理范围内,就去获取相应的值,否则不做处理,将monomer_info初始化为0即可*/
    if(cluster_index <= cluster_num && pack_index <= pack_num && 
                                cluster_index >= 1 && pack_index >= 1)
    {
        data_valid = 1;
        cluster_index -= 1;
        pack_index -= 1;
        cluster_info_page_pack_get(cluster_index,pack_index,&monomer_info);
    }
    for(i = 0;i < MAX_ELEC_CORE;i++)
    {
        p_resp_item = cJSON_CreateObject();
        if(p_resp_item == NULL)
        {
            print_log("create json obj failed");
            cJSON_Delete(p_resp_array);
            return;
        }
        cJSON_AddNumberToObject(p_resp_item,"voltage",monomer_info.monomer_voltage[i]); 
        if(data_valid)
        {
            total_voltage += monomer_info.monomer_voltage[i]; //电压
            monomer_info.monomer_temperature[i] -= 40;
        }

        cJSON_AddNumberToObject(p_resp_item,"temperature",monomer_info.monomer_temperature[i]);
        cJSON_AddNumberToObject(p_resp_item,"soc",monomer_info.monomer_SOC[i]); 
        cJSON_AddNumberToObject(p_resp_item,"soh",monomer_info.monomer_SOH[i]);

        cJSON_AddItemToArray(p_resp_array,p_resp_item); 
    }

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        cJSON_Delete(p_resp_array);
    }

    cJSON_AddNumberToObject(p_resp_root,"code",200);
    if(data_valid)
    {
        monomer_info.pole_temperater_PACK[0] -= 40;
        monomer_info.pole_temperater_PACK[1] -= 40;
    }
    cJSON_AddNumberToObject(p_resp_root,"packT1", monomer_info.pole_temperater_PACK[0]);
    cJSON_AddNumberToObject(p_resp_root,"packT2", monomer_info.pole_temperater_PACK[1]);
    cJSON_AddNumberToObject(p_resp_root,"packVoltage",total_voltage/1000.0);
    cJSON_AddItemToObject(p_resp_root,"data",p_resp_array);
    cJSON_AddStringToObject(p_resp_root,"msg","get battery detailed info successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);

    cJSON_Delete(p_resp_root);
    free(p);

     http_back(p_nc,response);
}

static void get_upper_lower_charge_discharge_param(double *p_powerlimit, uint8_t *p_upper, uint8_t *p_lower)
{
    FILE *fp;
    uint8_t content[128];
    cJSON *p_conf_root;

    fp = fopen(RUNTIME_PARAMS_JSON_FILE,"r");
    if(fp == NULL)
    {
        print_log("open file %s failed",RUNTIME_PARAMS_JSON_FILE);
        return;
    }
    fread(content,1,sizeof(content),fp);
    fclose(fp);

    p_conf_root = cJSON_Parse(content);
    if(p_conf_root == NULL)
    {
        print_log("parse json file failed");
        return;
    }
    *p_powerlimit = cJSON_GetObjectItem(p_conf_root,"cdpower")->valuedouble;
    *p_upper = cJSON_GetObjectItem(p_conf_root,"socuplimit")->valueint;
    *p_lower = cJSON_GetObjectItem(p_conf_root,"soclowlimit")->valueint;

    cJSON_Delete(p_conf_root);
}
static void get_container_charge_discharge_prohibit(uint8_t *p_charge_prohibit, uint8_t *p_discharge_prohibit)
{
    container_status_info_t status_info;
    container_status_info_get(&status_info);

    *p_charge_prohibit = ((status_info.container_system_status_info[0] & 0x01) == 0) ? 0 : 1;
    *p_discharge_prohibit = ((status_info.container_system_status_info[0] & 0x02) == 0) ? 0 : 1;
}

void get_battery_cluster_charge_info(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_array;
    cJSON *p_resp_item;
    cJSON *p_resp_root;
    uint8_t *p_action;
    uint8_t *p;
    uint8_t i;
    uint8_t response[64];  //
    uint8_t request_body[1024] = {0};
    battery_cluster_page_t battery_cluster;
    uint8_t soc_upper_limit;
    uint8_t soc_lower_limit;
    double powerlimit;
    uint8_t charge_prohibit;
    uint8_t discharge_prohibit;
    uint8_t pack_num = 0;
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();
	common_data_t *psc_common_data = sdk_shm_get();
    
    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getBatteryClusterChargeInfo"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    cJSON_Delete(p_request);

    p_resp_array = cJSON_CreateArray();
    if(p_resp_array == NULL)
    {
        print_log("create json array failed");
        return;
    }

    cluster_info_page_get(&battery_cluster);
    for(i=0; i<6; i++)
    {
        p_resp_item = cJSON_CreateObject();
        if(p_resp_item == NULL)
        {
            print_log("create json obj failed");
            cJSON_Delete(p_resp_array);
            return;
        }

        cJSON_AddNumberToObject(p_resp_item, "soc", battery_cluster.battery_cluster_info[i].cluster_SOC);
        cJSON_AddNumberToObject(p_resp_item, "soh", battery_cluster.battery_cluster_info[i].average_SOH_monomer);
        cJSON_AddNumberToObject(p_resp_item, "communicationSta", battery_cluster.battery_cluster_info[i].BCU_comm_status);
        cJSON_AddNumberToObject(p_resp_item, "clusterCapEng", battery_cluster.battery_cluster_info[i].cluster_cap_energy / 100.0f );
        cJSON_AddItemToArray(p_resp_array, p_resp_item);
    }

    get_upper_lower_charge_discharge_param(&powerlimit, &soc_upper_limit, &soc_lower_limit);
    get_container_charge_discharge_prohibit(&charge_prohibit, &discharge_prohibit);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
         print_log("create json obj failed");
        cJSON_Delete(p_resp_array);
        return;
    }
    cJSON_AddNumberToObject(p_resp_root, "code", 200);
    cJSON_AddItemToObject(p_resp_root ,"data", p_resp_array);
    cJSON_AddNumberToObject(p_resp_root, "chargeLimitPower", p_telemetry_data->container_system_telemetry_info.charge_limits_power*10);
    cJSON_AddNumberToObject(p_resp_root, "dischargeLimitPower", p_telemetry_data->container_system_telemetry_info.discharge_limits_power*10);
    cJSON_AddNumberToObject(p_resp_root, "chargeSocLimit", soc_upper_limit);
    cJSON_AddNumberToObject(p_resp_root, "dischargeSocLowerLimit", soc_lower_limit);
    cJSON_AddNumberToObject(p_resp_root, "chargeProhibit", charge_prohibit);
    cJSON_AddNumberToObject(p_resp_root, "dischargeProhibit", discharge_prohibit);
    
    cJSON_AddNumberToObject(p_resp_root, "totalBatVol",  p_telemetry_data->container_system_telemetry_info.total_voltage );
    cJSON_AddNumberToObject(p_resp_root, "totalBatCurr", p_telemetry_data->container_system_telemetry_info.total_current );

    p_telemetry_data = sdk_shm_telemetry_data_get();
    for(i = 0; i < p_telemetry_data->container_system_telemetry_info.battery_cluster_number; i++)
    {
        pack_num += p_telemetry_data->battery_cluster_telemetry_info[i].PACK_number_in_cluster;
    }
    cJSON_AddNumberToObject(p_resp_root, "packNum", pack_num);
	cJSON_AddNumberToObject(p_resp_root, "pcschglimitpower", psc_common_data->internal_shared_data.pcs_heartbeat_info.pcs_chg_limit_power[0]);
    cJSON_AddNumberToObject(p_resp_root, "pcsdischglimitpower", psc_common_data->internal_shared_data.pcs_heartbeat_info.pcs_dischg_limit_power[0]);
    cJSON_AddStringToObject(p_resp_root,"msg","get battery cluster charge info successful");

    

    p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_resp_root);

    http_back(p_nc,p);
    free(p);
}

/**
 * @brief 电池信息模块初始化
 * @return void
 */
void battery_info_module_init(void)
{
    /*获取电池簇信息*/
	if(!web_func_attach("/batteryInfo/getBatteryClusterInfo", get_battery_cluster_info))
	{
		print_log("[/batteryInfo/getBatteryClusterInfo] attach failed");
	}
	/*获取电池簇详细信息(pack)*/
	if(!web_func_attach("/batteryInfo/getBatteryDetailInfo", get_battery_pack_info))
	{
		print_log("[/batteryInfo/getBatteryDetailInfo] attach failed");
	}
	/*获取电池簇充放电信息*/
	if(!web_func_attach("/batteryInfo/getBatteryClusterChargeInfo", get_battery_cluster_charge_info))
	{
		print_log("[/batteryInfo/getBatteryClusterChargeInfo] attach failed");
	}
}