#define _XOPEN_SOURCE

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"cJSON.h"
#include"homepage.h"
#include"common.h"
#include<time.h>
#include"sdk_fs.h"
#include"data_shm.h"
#include"sdk_shm.h"
#include"power_history.h"
//#include"operating_pcs_data_handle.h"
#include"web_public.h"
#include"crc.h"

#include "sdk_file.h"
#include "history2csv.h"
#include "web_broker.h"

#define READ_MAX_COUNT       288
typedef struct	{
	time_t start_time;
	time_t end_time;
	struct tm tm_start_time;
	struct tm tm_end_time;
}time_span_t;


typedef struct	{
	uint8_t start_time[32];
	uint8_t end_time[32];
}Operation_records_time_t;

/**
 * @brief  	将sdk_rtc_t结构体时间转换成时间戳（秒）
 * @param  	[in] p_time         sdk_rtc_t结构体时间
 * @param  	[out] p_timestamp   时间戳（秒）
 * @return 	无
 */
static void date_time_to_timestamp(sdk_rtc_t *p_time, time_t *p_timestamp)
{
    struct tm date;

    memset(&date, 0, sizeof(date));
    date.tm_year = (int32_t)(p_time->tm_year) + 100;
    date.tm_mon  = (int32_t)(p_time->tm_mon - 1);
    date.tm_mday = (int32_t)(p_time->tm_day);
    date.tm_hour = (int32_t)(p_time->tm_hour);
    date.tm_min  = (int32_t)(p_time->tm_min);
    date.tm_sec  = (int32_t)(p_time->tm_sec);

    *p_timestamp = mktime(&date) - 8 * 60 * 60;
}


/**
 * @brief	对读取的运行数据帧进行crc校验
 * @param	[in] p_operating_data 运行数据结构体指针
 * @return	结果
 * @retval	0 成功
 * @retval	-1 失败
 */
static int32_t operating_record_data_frame_crc_check(operating_pcs_data_t *p_operating_data)
{
	int32_t ret = -1;
	uint32_t crc;

	crc = crc32((const unsigned char *)p_operating_data, (sizeof(operating_pcs_data_t) - 4));
	if (p_operating_data->crc == crc)
	{
		ret = 0;
	}

	return ret;
}

static void operating_record_data_json_input(time_span_t time_span, operating_pcs_data_t *p_operating_data, cJSON *p_resp_array)
{
	cJSON *p_resp_item;
	int32_t i;
	int32_t apparent_power = 0;
	int32_t active_power = 0;
	int32_t reactive_power = 0; 
	time_t time_ts;
    uint8_t date[32] = {0};

	p_resp_item = cJSON_CreateObject();
	if(p_resp_item == NULL)
	{
		POWER_DEBUG_LOG((int8_t *)"create json obj failed.");	 
		return;
	}

	date_time_to_timestamp(&(p_operating_data->operating_time), &time_ts);

	sprintf(date, "%04d-%02d-%02d %02d:%02d:%02d", 2000 + p_operating_data->operating_time.tm_year, 
                                                            p_operating_data->operating_time.tm_mon, 
                                                            p_operating_data->operating_time.tm_day, 
                                                            p_operating_data->operating_time.tm_hour, 
                                                            p_operating_data->operating_time.tm_min, 
                                                            p_operating_data->operating_time.tm_sec); 
	cJSON_AddStringToObject(p_resp_item,"time", date);
	for (i = 0; i < PCS_CABINET_POWER_MODULE_NUM; ++i)
	{
		apparent_power  += p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].apparent_power;
		active_power  += p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].active_power;
		reactive_power  += p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].reactive_power;
	}

	cJSON_AddNumberToObject(p_resp_item,"gridSideLineVolRS",p_operating_data->telemetry_operating_data.power_module_telemetry_info[0].grid_volt_rs/10.0); 
	cJSON_AddNumberToObject(p_resp_item,"gridSideLineVolST",p_operating_data->telemetry_operating_data.power_module_telemetry_info[0].grid_volt_st/10.0); 
	cJSON_AddNumberToObject(p_resp_item,"gridSideLineVolTR",p_operating_data->telemetry_operating_data.power_module_telemetry_info[0].grid_volt_tr/10.0); 

	cJSON_AddNumberToObject(p_resp_item,"acSidePhaseCurrentR",p_operating_data->telemetry_operating_data.power_module_telemetry_info[0].ac_current_r/10.0); 
	cJSON_AddNumberToObject(p_resp_item,"acSidePhaseCurrentS",p_operating_data->telemetry_operating_data.power_module_telemetry_info[0].ac_current_s/10.0); 
	cJSON_AddNumberToObject(p_resp_item,"acSidePhaseCurrentT",p_operating_data->telemetry_operating_data.power_module_telemetry_info[0].ac_current_t/10.0); 

	cJSON_AddNumberToObject(p_resp_item,"active_power",active_power/100.0); 
	cJSON_AddNumberToObject(p_resp_item,"reactive_power",reactive_power/100.0); 
	cJSON_AddNumberToObject(p_resp_item,"apparent_power",apparent_power/100.0); 

	cJSON_AddItemToArray(p_resp_array,p_resp_item);

	return;
}


/**
  * @brief	历史功率读取函数
  * @param	[in] time_span 要读取的时间段
  * @param	[in] file_name 存储数据记录的文件名。
  * @param	[out] p_resp_array json对象指针 
  * @return 读取结果 
*/
static int32_t history_power_read(time_span_t time_span, uint8_t *file_name, cJSON *p_resp_array)
{
  	uint8_t file_path[128] = {0};
 	uint8_t folder[8] = {0};
    int32_t ret = 0;
    fs_t *p_fs_src = NULL;
	int32_t file_size;
	int32_t once_len;
	int32_t loop_count;	
	int32_t ret_len;
	int32_t crc_check;
	uint32_t offset;
	operating_pcs_data_t operating_data;
	
	print_log("[%s:%d]",__func__, __LINE__);
	
	/*组装完整路径*/
	snprintf((char*)folder, 5, "%s", file_name);
	snprintf((char*)file_path, sizeof(file_path), PATH_OPERATING_RECORD_FOLDER "%s/%s", folder, file_name);

	p_fs_src = sdk_fs_open((const int8_t *)file_path, FS_READ);
	if (p_fs_src == NULL)
	{
		print_log((int8_t *)"\n sdk_fs_open  file fail! \n");
		return FAIL;
	}
	
	file_size = sdk_fs_get_size(p_fs_src);
	once_len = sizeof(operating_pcs_data_t);
	loop_count = file_size / once_len;
	POWER_DEBUG_LOG((int8_t *)"[%s:%d] src_size: %d, loop_count: %d, once_len: %d\n", __func__, __LINE__, file_size, loop_count, once_len);
	if (loop_count < 1)
	{
		print_log((int8_t *)"[%s:%d] no content!\n", __func__, __LINE__);
		sdk_fs_close(p_fs_src);
		return FAIL;
	}
	else if (loop_count > READ_MAX_COUNT)
	{
		POWER_DEBUG_LOG((int8_t *)"[%s:%d] overflow!\n", __func__, __LINE__);
		loop_count = READ_MAX_COUNT;
	}
	offset = (loop_count - 1) * once_len;
    while (loop_count)
    {
        memset(&operating_data, 0 , sizeof(operating_pcs_data_t));
		
		sdk_fs_lseek(p_fs_src, offset);
        ret_len = sdk_fs_read(p_fs_src, &operating_data, sizeof(operating_pcs_data_t));
        if (ret_len != once_len)
        {
            POWER_DEBUG_LOG((int8_t *)"[%s:%d] read len error! ret_len = %d\n", __func__, __LINE__, ret_len);
			sdk_fs_close(p_fs_src);
			return FAIL;

        }
		
        crc_check = operating_record_data_frame_crc_check(&operating_data);
        if (crc_check < 0)
        {
            POWER_DEBUG_LOG((int8_t *)"[%s:%d] frame crc error!\n", __func__, __LINE__);
            
        }
        else
        {
			// print_log((int8_t *)"[%s:%d] frame crc ok!\n", __func__, __LINE__);
			operating_record_data_json_input(time_span, &operating_data, p_resp_array);
        }

        loop_count--;
		offset -= once_len;
    }	 
	 sdk_fs_close(p_fs_src);
	 return SUCCESS;
	
}


 /**
 * @brief  比较大小排序
 * @param  [in] low low下标
 * @param  [in] high high下标
 * @param  [out] arr 指针数组 
 * @return
 */ 
static int partition(uint8_t *arr[], int32_t low, int32_t high) 
{
	char *pivot = arr[high];
	int i = (low - 1);
	
	for (int j = low; j <= high - 1; j++) 
	{
		if (strcmp(arr[j], pivot) < 0) 
		{
			i++;
			char *temp = arr[i];
			arr[i] = arr[j];
			arr[j] = temp;
		}
	}
	
	char *temp = arr[i + 1];
	arr[i + 1] = arr[high];
	arr[high] = temp;
	return (i + 1);
}
 
/**
 * @brief  文件名按照时间快速排序
 * @param  [in] low low下标
 * @param  [in] high high下标
 * @param  [out] arr  指针数组
 * @return
 */ 
static void quicksort(uint8_t *arr[], int32_t low, int32_t high) 
{
	if (low < high) 
	{
		int pivot = partition(arr, low, high);
		quicksort(arr, low, pivot - 1);
		quicksort(arr, pivot + 1, high);
	}
}

/**
 * @brief  	将时间戳（秒）转换成sdk_rtc_t结构体时间
 * @param  	[in] p_timestamp    时间戳（秒）
 * @param  	[out] p_time        sdk_rtc_t结构体时间
 * @return 	无
 */
static void timestamp_to_date_time(const time_t *p_timestamp, sdk_rtc_t *p_time)
{
    struct tm *p_data;

    p_data = localtime(p_timestamp);
    p_time->tm_year = (uint8_t)(p_data->tm_year - 100);
    p_time->tm_mon  = (uint8_t)(p_data->tm_mon + 1);
    p_time->tm_day  = (uint8_t)(p_data->tm_mday);
    p_time->tm_hour = (uint8_t)(p_data->tm_hour);
    p_time->tm_min  = (uint8_t)(p_data->tm_min);
    p_time->tm_sec  = (uint8_t)(p_data->tm_sec);
}

/**
 * @brief  符合条件的文件路径加入数组
 * @param  [in] time_span 要读取的时间段 
 * @param  [in] path  文件路径
 * @param  [out] file_count  文件总数 
 * @return
 */
static void add_files_to_array(time_span_t time_span, const uint8_t *path, uint8_t *files[], int32_t *file_count)
{
	DIR *d;
	struct dirent *dir;
	uint8_t satrt_str[16];
	uint8_t end_str[16];

	snprintf((char*)satrt_str, sizeof(satrt_str),  "%04d%02d%02d", time_span.tm_start_time.tm_year, time_span.tm_start_time.tm_mon,
                                                            time_span.tm_start_time.tm_mday);
	snprintf((char*)end_str, sizeof(end_str),  "%04d%02d%02d", time_span.tm_end_time.tm_year, time_span.tm_end_time.tm_mon,
                                                        time_span.tm_end_time.tm_mday);
                                                        
	POWER_DEBUG_LOG((int8_t *)"satrt_str %s end_str %s\n",satrt_str,end_str);
	d = opendir(path);
	if (d) 
	{
		while ((dir = readdir(d)) != NULL) 
		{
			if (!strcmp(dir->d_name, ".") || !strcmp(dir->d_name, "..")) 
			{
				// skip self and parent
				continue;
			}
			/* 历史文件格式为：年+月+日 20230101。不符合此条件的文件跳过*/
		if (strlen(dir->d_name) != HISTORY_FILE_LEN)
		{
			
				continue;
		}
			/*跳过小于开始日期大于结束日期的文件*/
		if ((strncmp(dir->d_name, satrt_str, HISTORY_FILE_LEN) < 0) || ((strncmp(dir->d_name, end_str, HISTORY_FILE_LEN) > 0) ))
		{
			POWER_DEBUG_LOG((int8_t *)"[%s:%d] Not Satisfiable\n", __func__, __LINE__);
			continue;
		}
			files[*file_count] = malloc(strlen(dir->d_name) + 1);
			strcpy(files[*file_count], dir->d_name);
			*file_count = *file_count + 1;
		}
		closedir(d);
	}
}

/**
 * @brief  读取符合时间的记录
 * @param  [in] time_span 要读取的时间段 
 * @param  [in] p_resp_array  json数组
 * @return
 */
static void traverse_folder(time_span_t time_span,cJSON *p_resp_array)
{
	uint8_t file_path[PATH_FILE_MAX_LEN]={0};
	uint8_t *files[1000];  // Assuming there will be at most 1000 files
	int32_t file_count = 0;
	sdk_rtc_t expire_date;
	DIR *d;
	struct dirent *dir;
	
	/* 历史文件存储为路径为 历史记录文件夹 + 年份 + 日期*/
	d = opendir(PATH_OPERATING_RECORD_FOLDER);
	if (d) 
	{
		while ((dir = readdir(d)) != NULL) 
		{
			if (!strcmp(dir->d_name, ".") || !strcmp(dir->d_name, "..")) {
					// skip self and parent
					continue;
			}
			/*年份文件夹*/
			if (dir->d_type == 4)
			{
				print_log((int8_t *)"++++%s\n", dir->d_name);

				snprintf((char*)file_path, sizeof(file_path), PATH_OPERATING_RECORD_FOLDER "/%s", dir->d_name);		 
				add_files_to_array(time_span, file_path, files, &file_count);

			}
		}
		closedir(d);
	}

	quicksort(files, 0, file_count - 1);

	for (int i = 0; i < file_count; i++) 
	{
		POWER_DEBUG_LOG((int8_t *)"%s\n", files[file_count - 1 - i]);		 
		history_power_read(time_span, files[file_count - 1 - i], p_resp_array);
		free(files[file_count - 1 - i]);
	}
	 
}

static void export_history(uint8_t *file_name)
{
	uint8_t file_path[128] = {0};
	uint8_t folder[8] = {0};

	/*组装完整路径*/
	snprintf((char*)folder, 5, "%s", file_name);
	snprintf((char*)file_path, sizeof(file_path), PATH_OPERATING_RECORD_FOLDER "%s/%s", folder, file_name);

	
	extract_data(file_path,PATH_HISTORYFILE);
}


 /**
  * @brief  符合条件的文件路径加入数组
  * @param  [in] time_span 要读取的时间段 
  * @param  [in] path  文件路径
  * @param  [out] file_count  文件总数 
  * @return
  */
static void add_operationfile(Operation_records_time_t  *operation_time, const uint8_t *path, uint8_t *files[], int32_t *file_count)
{
	DIR *d;
	struct dirent *dir;
	sdk_rtc_t rtc_start;
	sdk_rtc_t rtc_end;
	
	POWER_DEBUG_LOG((int8_t *)"x start_str %s end_str %s\n",operation_time->start_time ,operation_time->end_time);
	d = opendir(path);
	if (d) 
	{
		while ((dir = readdir(d)) != NULL) 
		{
			if (!strcmp(dir->d_name, ".") || !strcmp(dir->d_name, "..")) 
			{
				// skip self and parent
				continue;
			}
			/* 历史文件格式为：年+月+日 20230101。不符合此条件的文件跳过*/
		if (strlen(dir->d_name) != HISTORY_FILE_LEN)
		{
			
				continue;
		}
			/*跳过小于开始日期大于结束日期的文件*/
		if ((strncmp(dir->d_name, operation_time->start_time , HISTORY_FILE_LEN) < 0) || ((strncmp(dir->d_name, operation_time->end_time, HISTORY_FILE_LEN) > 0) ))
		{
			POWER_DEBUG_LOG((int8_t *)"[%s:%d] Not Satisfiable\n", __func__, __LINE__);
			continue;
		}
			files[*file_count] = malloc(strlen(dir->d_name) + 1);
			strcpy(files[*file_count], dir->d_name);
			*file_count = *file_count + 1;
		}
		closedir(d);
	}
}

 /**
   * @brief  读取符合时间的记录
   * @param  [in] time_span 要读取的时间段 
   * @param  [in] p_resp_array	json数组
   * @return
   */
static int32_t find_folder(Operation_records_time_t *operation_time)
{
	uint8_t file_path[PATH_FILE_MAX_LEN]={0};
	uint8_t *files[1000];  // Assuming there will be at most 1000 files
	int32_t file_count = 0;
	sdk_rtc_t expire_date;
	DIR *d;
	struct dirent *dir;

	sdk_file_remove(PATH_HISTORYFILE);
	/* 历史文件存储为路径为 历史记录文件夹 + 年份 + 日期*/
	d = opendir(PATH_OPERATING_RECORD_FOLDER);
	if (d) 
	{
		while ((dir = readdir(d)) != NULL) 
		{
			if (!strcmp(dir->d_name, ".") || !strcmp(dir->d_name, "..")) {
				// skip self and parent
				continue;
			}
			/*年份文件夹*/
			if (dir->d_type == 4)
			{
			// POWER_DEBUG_LOG((int8_t *)"++++%s\n", dir->d_name);
				snprintf((char*)file_path, sizeof(file_path), PATH_OPERATING_RECORD_FOLDER "/%s", dir->d_name);		  
				add_operationfile(operation_time, file_path, files, &file_count);
			}
		}
		closedir(d);
	}

	if (file_count < 1)
	{
		  return 0;
	}
	quicksort(files, 0, file_count - 1);
	for (int i = 0; i < file_count; i++) {
		POWER_DEBUG_LOG((int8_t *)"%s\n", files[i]);
		export_history(files[i]);
		free(files[i]);
	}

	return 1;
	  
}



 /**
  * @brief  获取历史记录
  * @param  [in] *p_nc 连接信息 
  * @param  [in] *p_msg  http请求信息
  * @return
  */
void get_power_list(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_root = NULL;
    cJSON *p_resp_array = NULL;
    cJSON *p_resp_item = NULL;	
    uint8_t response[256] = {0};
    uint8_t *p_action = NULL;
	int32_t i = 0;
    uint8_t *p_start = NULL;
    uint8_t *p_end = NULL;
    uint8_t *p = NULL;
    uint8_t request_body[1024] = {0};
	time_span_t time_span = {0};
	
    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		POWER_DEBUG_LOG((int8_t *)"parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getPowerList"))
	{
		POWER_DEBUG_LOG((int8_t *)"action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
	if ((NULL == cJSON_GetObjectItem(p_request,"start")) || (NULL == cJSON_GetObjectItem(p_request,"end")))
	{
		POWER_DEBUG_LOG((int8_t *)"start/end time not right.");
		build_empty_response(response,203,"start/end time not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;

	}

	p_start = cJSON_GetObjectItem(p_request,"start")->valuestring;
	p_end = cJSON_GetObjectItem(p_request,"end")->valuestring;

    sscanf(p_start, "%04d-%02d-%02d %02d:%02d:%02d", &time_span.tm_start_time.tm_year, &time_span.tm_start_time.tm_mon,
                                                     &time_span.tm_start_time.tm_mday, &time_span.tm_start_time.tm_hour, 
                                                     &time_span.tm_start_time.tm_min, &time_span.tm_start_time.tm_sec);
    sscanf(p_end, "%04d-%02d-%02d %02d:%02d:%02d", &time_span.tm_end_time.tm_year, &time_span.tm_end_time.tm_mon,
                                                   &time_span.tm_end_time.tm_mday, &time_span.tm_end_time.tm_hour, 
                                                &time_span.tm_end_time.tm_min, &time_span.tm_end_time.tm_sec);
    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        POWER_DEBUG_LOG((int8_t *)"create json obj failed.");
        return ;
    }

	cJSON_AddNumberToObject(p_resp_root,"code",200);

    p_resp_array = cJSON_CreateArray();
    if(p_resp_array == NULL)
    {
        POWER_DEBUG_LOG((int8_t *)"create json array failed.");
        cJSON_Delete(p_resp_root);
        return;
    }

	traverse_folder(time_span, p_resp_array);

	cJSON_AddItemToObject(p_resp_root,"data",p_resp_array);
	
	cJSON_AddStringToObject(p_resp_root,"msg","get successful");
	
	p = cJSON_PrintUnformatted(p_resp_root);

	POWER_DEBUG_LOG((int8_t *)" json len %d",strlen(p));

	cJSON_Delete(p_resp_root);


	http_back(p_nc,p); 
	free(p);	
 }

/**
 * @brief  获取历史记录
 * @param  [in] *p_nc 连接信息 
 * @param  [in] *p_msg  http请求信息
 * @return
 */
void export_history_List(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request;
	cJSON *p_resp_root;
	uint8_t response[256] = {0};
	uint8_t *p_action;
	int32_t ret = 0;
	uint8_t *p = NULL;
	uint8_t request_body[1024] = {0};
	int32_t year=0,mon=0,day=0;
	Operation_records_time_t  operation_time ={0};

	if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);	 
	}
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		POWER_DEBUG_LOG((int8_t *)"parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	if(NULL == cJSON_GetObjectItem(p_request,"action"))
	{
		 POWER_DEBUG_LOG((int8_t *)"action is NULL");
		 build_empty_response(response,203,"action is NULL");
		 http_back(p_nc,response);
		 cJSON_Delete(p_request);
		 return;
	}
	 
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"exportPowerList"))
	{
		 POWER_DEBUG_LOG((int8_t *)"action is not right.");
		 build_empty_response(response,203,"action is not right");
		 http_back(p_nc,response);
		 cJSON_Delete(p_request);
		 return;
	}
	
	if ((NULL == cJSON_GetObjectItem(p_request,"timestart")) || (NULL == cJSON_GetObjectItem(p_request,"timeend")))
	{
		 POWER_DEBUG_LOG((int8_t *)"start/end time not right.");
		 build_empty_response(response,203,"start/end time not right");
		 http_back(p_nc,response);
		 cJSON_Delete(p_request);
		 return;
	}

	sscanf(cJSON_GetObjectItem(p_request,"timestart")->valuestring,"%d-%d-%d",&year,&mon,&day);
	snprintf((char*)operation_time.start_time, 32, "%04d%02d%02d",year,mon,day);
	
	sscanf(cJSON_GetObjectItem(p_request,"timeend")->valuestring,"%d-%d-%d",&year,&mon,&day);
	snprintf((char*)operation_time.end_time, 32, "%04d%02d%02d",year,mon,day);
	POWER_DEBUG_LOG((int8_t *)"start %s end %s \n",operation_time.start_time,operation_time.end_time);
	cJSON_Delete(p_request);

	//mg_printf(p_nc, "HTTP/1.1 302 Found\r\n"
    //              "Location: /down/xxx\r\n"
    //              "\r\n");
	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		POWER_DEBUG_LOG((int8_t *)"create json obj failed.");
		return ;
	}

	ret = find_folder(&operation_time);
	if (ret)
	{
		cJSON_AddNumberToObject(p_resp_root,"code",200);
		cJSON_AddStringToObject(p_resp_root,"url","download/history.csv");
		cJSON_AddStringToObject(p_resp_root,"msg","successful");
	 	p = cJSON_PrintUnformatted(p_resp_root);
	 	cJSON_Delete(p_resp_root);
	 	http_back(p_nc,p); 
	 	free(p);
		return;
	}else
	{
		POWER_DEBUG_LOG((int8_t *)"Record does not exist");
		build_empty_response(response,203,"Record does not exist");
		http_back(p_nc,response);
		cJSON_Delete(p_resp_root);
		return;
	}
	 
}

/**
 * @brief 功率曲线模块初始化
 * @return void
 */
void power_history_module_init(void)
{
	/*获取功率历史数据*/
	if(!web_func_attach("/getHistoryInfo/getPowerList", get_power_list))
	{
		print_log("[/getHistoryInfo/getPowerList] attach failed");
	}
	/*下载运行记录*/
	if(!web_func_attach("/getHistoryInfo/exportPowerList", export_history_List))
	{
		print_log("[/getHistoryInfo/exportPowerList] attach failed");
	}
}


