#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"cJSON.h"
#include"protectparams.h"
#include"common.h"
#include"homepage.h"
#include"web_data_interface.h"
#include "sdk_shm.h"
#include "web_broker.h"

#define PARAM_STORAGE_DAYS_MIN    (30)
#define PARAM_STORAGE_DAYS_MAX    (360)
#define PARAM_STORAGE_FREQ_MIN    (3)
#define PARAM_STORAGE_FREQ_MAX    (60)


typedef enum
{
    CLUSTER_OVERVOLTAGE,
    CLUSTER_UNDERVOLTAGE,
    PACK_OVERVOLTAGE,
    PACK_UNDERVOLTAGE,
    MONOMER_OVERVOLTAGE,
    MONOMER_UNDERVOLTAGE,
    EXECDIFF_PRESSURE,
    CHARGE_MONOMER_OVERTEMP,
    CHARGE_MONOMER_UNDERTEMP,
    DISCHARGE_MONOMER_OVERTEMP,
    DISCHARGE_MONOMER_UNDERTEMP,
    EXECDIFF_TEMP,
    CHARGE_OVER_CURRENT,
    DISCHARGE_OVER_CURRENT,
    SOC_TOO_LOW,
    SOC_TOO_HIGH,
    INSULATION_TOO_LOW,
    WARNING_MAX = 255
}protect_params_e;

static void transfer_params_format(const battery_parameter_data_t *p_param_info,const protect_params_e type,double *data_array)
{
    switch(type)
	{
		case CLUSTER_OVERVOLTAGE:
            data_array[0] = (p_param_info->cluster_OVP_warn_threshold_1)/10.0;
            data_array[1] = (p_param_info->cluster_OVP_warn_threshold_2)/10.0;
            data_array[2] = (p_param_info->cluster_OVP_warn_threshold_3)/10.0;
            data_array[3] = (p_param_info->cluster_OVP_warn_hysteresis_err)/10.0;
            break;
        case CLUSTER_UNDERVOLTAGE:
			data_array[0] = p_param_info->cluster_UVP_warn_threshold_1/10.0;
            data_array[1] = p_param_info->cluster_UVP_warn_threshold_2/10.0;
            data_array[2] = p_param_info->cluster_UVP_warn_threshold_3/10.0;
            data_array[3] = p_param_info->cluster_UVP_warn_hysteresis_err/10.0;
            break;
        case PACK_OVERVOLTAGE:
			data_array[0] = p_param_info->PACK_OVP_warn_threshold_1/10.0;
            data_array[1] = p_param_info->PACK_OVP_warn_threshold_2/10.0;
            data_array[2] = p_param_info->PACK_OVP_warn_threshold_3/10.0;
            data_array[3] = p_param_info->PACK_OVP_warn_hysteresis_err/10.0;
            break;
        case PACK_UNDERVOLTAGE:
			data_array[0] = p_param_info->PACK_UVP_warn_threshold_1/10.0;
            data_array[1] = p_param_info->PACK_UVP_warn_threshold_2/10.0;
            data_array[2] = p_param_info->PACK_UVP_warn_threshold_3/10.0;
            data_array[3] = p_param_info->PACK_UVP_warn_hysteresis_err/10.0;
            break;
        case MONOMER_OVERVOLTAGE:
			data_array[0] = p_param_info->monomer_OVP_warn_threshold_1;
            data_array[1] = p_param_info->monomer_OVP_warn_threshold_2;
            data_array[2] = p_param_info->monomer_OVP_warn_threshold_3;
            data_array[3] = p_param_info->monomer_OVP_warn_hysteresis_err;
            break;
        case MONOMER_UNDERVOLTAGE:
			data_array[0] = p_param_info->monomer_UVP_warn_threshold_1;
            data_array[1] = p_param_info->monomer_UVP_warn_threshold_2;
            data_array[2] = p_param_info->monomer_UVP_warn_threshold_3;
            data_array[3] = p_param_info->monomer_UVP_warn_hysteresis_err;
            break;
        case EXECDIFF_PRESSURE:
			data_array[0] = p_param_info->monomer_vol_diff_warn_threshold_1;
            data_array[1] = p_param_info->monomer_vol_diff_warn_threshold_2;
            data_array[2] = p_param_info->monomer_vol_diff_warn_threshold_3;
            data_array[3] = p_param_info->monomer_vol_diff_warn_hysteresis_err;
            break;
        case CHARGE_MONOMER_OVERTEMP: //充电过温
			data_array[0] = (p_param_info->charge_monomer_OTP_warn_threshold_1 - 40);
            data_array[1] = (p_param_info->charge_monomer_OTP_warn_threshold_2 - 40);
            data_array[2] = (p_param_info->charge_monomer_OTP_warn_threshold_3 - 40);
            data_array[3] = (p_param_info->charge_monomer_OTP_warn_hysteresis_err);
            break;
        case CHARGE_MONOMER_UNDERTEMP: //充电欠温
			data_array[0] = (p_param_info->charge_monomer_UTP_warn_threshold_1 - 40);
            data_array[1] = (p_param_info->charge_monomer_UTP_warn_threshold_2 - 40);
            data_array[2] = (p_param_info->charge_monomer_UTP_warn_threshold_3 - 40);
            data_array[3] = (p_param_info->charge_monomer_UTP_warn_hysteresis_err);
            break;
        case DISCHARGE_MONOMER_OVERTEMP:
			data_array[0] = (p_param_info->discharge_monomer_OTP_warn_threshold_1 - 40);
            data_array[1] = (p_param_info->discharge_monomer_OTP_warn_threshold_2 - 40);
            data_array[2] = (p_param_info->discharge_monomer_OTP_warn_threshold_3 - 40);
            data_array[3] = (p_param_info->discharge_monomer_OTP_warn_hysteresis_err);
            break;
        case DISCHARGE_MONOMER_UNDERTEMP:
			data_array[0] = (p_param_info->discharge_monomer_UTP_warn_threshold_1 - 40);
            data_array[1] = (p_param_info->discharge_monomer_UTP_warn_threshold_2 - 40);
            data_array[2] = (p_param_info->discharge_monomer_UTP_warn_threshold_3 - 40);
            data_array[3] = p_param_info->discharge_monomer_UTP_warn_hysteresis_err;
            break;
        case EXECDIFF_TEMP:
			data_array[0] = p_param_info->monomer_temp_diff_warn_threshold_1;
            data_array[1] = p_param_info->monomer_temp_diff_warn_threshold_2;
            data_array[2] = p_param_info->monomer_temp_diff_warn_threshold_3;
            data_array[3] = p_param_info->monomer_temp_diff_warn_hysteresis_err;
            break;
        case CHARGE_OVER_CURRENT:
			data_array[0] = p_param_info->charge_OCP_warn_threshold_1/10.0;
            data_array[1] = p_param_info->charge_OCP_warn_threshold_2/10.0;
            data_array[2] = p_param_info->charge_OCP_warn_threshold_3/10.0;
            data_array[3] = p_param_info->charge_OCP_warn_hysteresis_err/10.0;
            break;
        case DISCHARGE_OVER_CURRENT:
			data_array[0] = p_param_info->discharge_OCP_warn_threshold_1/10.0;
            data_array[1] = p_param_info->discharge_OCP_warn_threshold_2/10.0;
            data_array[2] = p_param_info->discharge_OCP_warn_threshold_3/10.0;
            data_array[3] = p_param_info->discharge_OCP_warn_hysteresis_err/10.0;
            break;
        case SOC_TOO_LOW:
			data_array[0] = p_param_info->SOC_low_warn_threshold_1;
            data_array[1] = p_param_info->SOC_low_warn_threshold_2;
            data_array[2] = p_param_info->SOC_low_warn_threshold_3;
            data_array[3] = p_param_info->SOC_low_warn_hysteresis_err;
            break;
        case SOC_TOO_HIGH:
			data_array[0] = p_param_info->SOC_high_warn_threshold_1;
            data_array[1] = p_param_info->SOC_high_warn_threshold_2;
            data_array[2] = p_param_info->SOC_high_warn_threshold_3;
            data_array[3] = p_param_info->SOC_high_warn_hysteresis_err;
            break;
        case INSULATION_TOO_LOW:
			data_array[0] = p_param_info->ISO_warn_threshold_1;
            data_array[1] = p_param_info->ISO_warn_threshold_2;
            data_array[2] = p_param_info->ISO_warn_threshold_3;
            data_array[3] = p_param_info->ISO_warn_hysteresis_err;
            break;
        default:
            break;
    }
}

static void set_protect_params_into_struct(battery_parameter_data_t *p_param_info,const protect_params_e type,const cJSON *p_data_array)
{
    uint8_t i;
    double data_array[4];

    for(i = 0;i < 4;i++)
    {
        data_array[i] = cJSON_GetArrayItem(p_data_array,i)->valuedouble;
    }

    switch(type)
	{
		case CLUSTER_OVERVOLTAGE:
			p_param_info->cluster_OVP_warn_threshold_1 = (data_array[0] * 10);
            p_param_info->cluster_OVP_warn_threshold_2 = (data_array[1] * 10);
            p_param_info->cluster_OVP_warn_threshold_3 = (data_array[2] * 10);
            p_param_info->cluster_OVP_warn_hysteresis_err = (data_array[3] * 10);
            break;
        case CLUSTER_UNDERVOLTAGE:
			p_param_info->cluster_UVP_warn_threshold_1 = (data_array[0] * 10);
            p_param_info->cluster_UVP_warn_threshold_2 = (data_array[1] * 10);
            p_param_info->cluster_UVP_warn_threshold_3 = (data_array[2] * 10);
            p_param_info->cluster_UVP_warn_hysteresis_err = (data_array[3] * 10);
            break;
        case PACK_OVERVOLTAGE:
			p_param_info->PACK_OVP_warn_threshold_1 = (data_array[0] * 10);
            p_param_info->PACK_OVP_warn_threshold_2 = (data_array[1] * 10);
            p_param_info->PACK_OVP_warn_threshold_3 = (data_array[2] * 10);
            p_param_info->PACK_OVP_warn_hysteresis_err = (data_array[3] * 10);
            break;
        case PACK_UNDERVOLTAGE:
			p_param_info->PACK_UVP_warn_threshold_1 = (data_array[0] * 10);
            p_param_info->PACK_UVP_warn_threshold_2 = (data_array[1] * 10);
            p_param_info->PACK_UVP_warn_threshold_3 = (data_array[2] * 10);
            p_param_info->PACK_UVP_warn_hysteresis_err = (data_array[3] * 10);
            break;
        case MONOMER_OVERVOLTAGE:
			p_param_info->monomer_OVP_warn_threshold_1 = data_array[0];
            p_param_info->monomer_OVP_warn_threshold_2 = data_array[1];
            p_param_info->monomer_OVP_warn_threshold_3 = data_array[2];
            p_param_info->monomer_OVP_warn_hysteresis_err = data_array[3];
            break;
        case MONOMER_UNDERVOLTAGE:
			p_param_info->monomer_UVP_warn_threshold_1 = data_array[0];
            p_param_info->monomer_UVP_warn_threshold_2 = data_array[1];
            p_param_info->monomer_UVP_warn_threshold_3 = data_array[2];
            p_param_info->monomer_UVP_warn_hysteresis_err = data_array[3];
            break;
        case EXECDIFF_PRESSURE:
			p_param_info->monomer_vol_diff_warn_threshold_1 = data_array[0];
            p_param_info->monomer_vol_diff_warn_threshold_2 = data_array[1];
            p_param_info->monomer_vol_diff_warn_threshold_3 = data_array[2];
            p_param_info->monomer_vol_diff_warn_hysteresis_err = data_array[3];
            break;
        case CHARGE_MONOMER_OVERTEMP: //充电过温
			p_param_info->charge_monomer_OTP_warn_threshold_1 = (data_array[0] + 40);
            p_param_info->charge_monomer_OTP_warn_threshold_2 = (data_array[1] + 40);
            p_param_info->charge_monomer_OTP_warn_threshold_3 = (data_array[2] + 40);
            p_param_info->charge_monomer_OTP_warn_hysteresis_err = (data_array[3]);
            break;
        case CHARGE_MONOMER_UNDERTEMP: //充电欠温
			p_param_info->charge_monomer_UTP_warn_threshold_1 = (data_array[0] + 40);
            p_param_info->charge_monomer_UTP_warn_threshold_2 = (data_array[1] + 40);
            p_param_info->charge_monomer_UTP_warn_threshold_3 = (data_array[2] + 40);
            p_param_info->charge_monomer_UTP_warn_hysteresis_err = (data_array[3]);
            break;
        case DISCHARGE_MONOMER_OVERTEMP:
			p_param_info->discharge_monomer_OTP_warn_threshold_1 = (data_array[0] + 40);
            p_param_info->discharge_monomer_OTP_warn_threshold_2 = (data_array[1] + 40);
            p_param_info->discharge_monomer_OTP_warn_threshold_3 = (data_array[2] + 40);
            p_param_info->discharge_monomer_OTP_warn_hysteresis_err = (data_array[3]);
            break;
        case DISCHARGE_MONOMER_UNDERTEMP:
			p_param_info->discharge_monomer_UTP_warn_threshold_1 = (data_array[0] + 40);
            p_param_info->discharge_monomer_UTP_warn_threshold_2 = (data_array[1] + 40);
            p_param_info->discharge_monomer_UTP_warn_threshold_3 = (data_array[2] + 40);
            p_param_info->discharge_monomer_UTP_warn_hysteresis_err = (data_array[3]);
            break;
        case EXECDIFF_TEMP:
			p_param_info->monomer_temp_diff_warn_threshold_1 = data_array[0];
            p_param_info->monomer_temp_diff_warn_threshold_2 = data_array[1];
            p_param_info->monomer_temp_diff_warn_threshold_3 = data_array[2];
            p_param_info->monomer_temp_diff_warn_hysteresis_err = data_array[3];
            break;
        case CHARGE_OVER_CURRENT:
			p_param_info->charge_OCP_warn_threshold_1 = (data_array[0] * 10);
            p_param_info->charge_OCP_warn_threshold_2 = (data_array[1] * 10);
            p_param_info->charge_OCP_warn_threshold_3 = (data_array[2] * 10);
            p_param_info->charge_OCP_warn_hysteresis_err = (data_array[3] * 10);
            break;
        case DISCHARGE_OVER_CURRENT:
			p_param_info->discharge_OCP_warn_threshold_1 = (data_array[0] * 10);
            p_param_info->discharge_OCP_warn_threshold_2 = (data_array[1] * 10);
            p_param_info->discharge_OCP_warn_threshold_3 = (data_array[2] * 10);
            p_param_info->discharge_OCP_warn_hysteresis_err = (data_array[3] * 10);
            break;
        case SOC_TOO_LOW:
			p_param_info->SOC_low_warn_threshold_1 = data_array[0];
            p_param_info->SOC_low_warn_threshold_2 = data_array[1];
            p_param_info->SOC_low_warn_threshold_3 = data_array[2];
            p_param_info->SOC_low_warn_hysteresis_err = data_array[3];
            break;
        case SOC_TOO_HIGH:
			p_param_info->SOC_high_warn_threshold_1 = data_array[0];
            p_param_info->SOC_high_warn_threshold_2 = data_array[1];
            p_param_info->SOC_high_warn_threshold_3 = data_array[2];
            p_param_info->SOC_high_warn_hysteresis_err = data_array[3];
            break;
        case INSULATION_TOO_LOW:
			p_param_info->ISO_warn_threshold_1 = data_array[0];
            p_param_info->ISO_warn_threshold_2 = data_array[1];
            p_param_info->ISO_warn_threshold_3 = data_array[2];
            p_param_info->ISO_warn_hysteresis_err = data_array[3];
            break;
        default:
            break;
    }
}

void get_protect_params(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_item;
    cJSON *p_resp_root;
    uint8_t response[1024];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    battery_parameter_data_t param_info;
    double data_array[4];

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getProtectParams"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

    p_resp_item = cJSON_CreateObject();
    if(p_resp_item == NULL)
    {
        print_log("create json obj failed");
        return;
    }
    para_config_page_protect_para_get(&param_info);
    
    transfer_params_format(&param_info,CLUSTER_OVERVOLTAGE,data_array);
    cJSON_AddItemToObject(p_resp_item,"clusterOverVoltage",cJSON_CreateDoubleArray(data_array,4));
    transfer_params_format(&param_info,CLUSTER_UNDERVOLTAGE,data_array);
    cJSON_AddItemToObject(p_resp_item,"clusterUnderVoltage",cJSON_CreateDoubleArray(data_array,4));
    transfer_params_format(&param_info,PACK_OVERVOLTAGE,data_array);
    cJSON_AddItemToObject(p_resp_item,"packOverVoltage",cJSON_CreateDoubleArray(data_array,4));
    transfer_params_format(&param_info,PACK_UNDERVOLTAGE,data_array);
    cJSON_AddItemToObject(p_resp_item,"packUnderVoltage",cJSON_CreateDoubleArray(data_array,4));
    transfer_params_format(&param_info,MONOMER_OVERVOLTAGE,data_array);
    cJSON_AddItemToObject(p_resp_item,"monomerOverVoltage",cJSON_CreateDoubleArray(data_array,4));
    transfer_params_format(&param_info,MONOMER_UNDERVOLTAGE,data_array);
    cJSON_AddItemToObject(p_resp_item,"monomerUnderVoltage",cJSON_CreateDoubleArray(data_array,4));
    transfer_params_format(&param_info,EXECDIFF_PRESSURE,data_array);
    cJSON_AddItemToObject(p_resp_item,"execDiffPressure",cJSON_CreateDoubleArray(data_array,4));
    transfer_params_format(&param_info,CHARGE_MONOMER_OVERTEMP,data_array);
    cJSON_AddItemToObject(p_resp_item,"chargeMonomerOverTemp",cJSON_CreateDoubleArray(data_array,4));
    transfer_params_format(&param_info,CHARGE_MONOMER_UNDERTEMP,data_array);
    cJSON_AddItemToObject(p_resp_item,"chargeMonomerUnderTemp",cJSON_CreateDoubleArray(data_array,4));
    transfer_params_format(&param_info,DISCHARGE_MONOMER_OVERTEMP,data_array);
    cJSON_AddItemToObject(p_resp_item,"disChargeMonomerOverTemp",cJSON_CreateDoubleArray(data_array,4));
    transfer_params_format(&param_info,DISCHARGE_MONOMER_UNDERTEMP,data_array);
    cJSON_AddItemToObject(p_resp_item,"disChargeMonomerUnderTemp",cJSON_CreateDoubleArray(data_array,4));
    transfer_params_format(&param_info,EXECDIFF_TEMP,data_array);
    cJSON_AddItemToObject(p_resp_item,"execDiffTemp",cJSON_CreateDoubleArray(data_array,4));
    transfer_params_format(&param_info,CHARGE_OVER_CURRENT,data_array);
    cJSON_AddItemToObject(p_resp_item,"chargeOverCurrent",cJSON_CreateDoubleArray(data_array,4));
    transfer_params_format(&param_info,DISCHARGE_OVER_CURRENT,data_array);
    cJSON_AddItemToObject(p_resp_item,"disChargeOverCurrent",cJSON_CreateDoubleArray(data_array,4));
    transfer_params_format(&param_info,SOC_TOO_LOW,data_array);
    cJSON_AddItemToObject(p_resp_item,"socTooLow",cJSON_CreateDoubleArray(data_array,4));
    transfer_params_format(&param_info,SOC_TOO_HIGH,data_array);
    cJSON_AddItemToObject(p_resp_item,"socTooHigh",cJSON_CreateDoubleArray(data_array,4));
    transfer_params_format(&param_info,INSULATION_TOO_LOW,data_array);
    cJSON_AddItemToObject(p_resp_item,"insulation",cJSON_CreateDoubleArray(data_array,4));


    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        cJSON_Delete(p_resp_item);
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddItemToObject(p_resp_root,"data",p_resp_item);
    cJSON_AddStringToObject(p_resp_root,"msg","get protect params successful");

    p = cJSON_PrintUnformatted(p_resp_root);

    strcpy(response,p);

    cJSON_Delete(p_resp_root);
    free(p);

    http_back(p_nc,response);
}

void set_protect_params(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_data_array;
    uint8_t response[64];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024 * 2] = {0};
    operation_log_t op_log;
    uint8_t cur_user[32] = {0};
    battery_parameter_data_t param_info;
    battery_parameter_data_t param_info_old;
    double value[2]; //分别存放旧的值和新的值

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"setProtectParams"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
   
    init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);

    para_config_page_protect_para_get(&param_info); //需求比实际较少，需要先获取一下所有数据，只修改需求的数据
    para_config_page_protect_para_get(&param_info_old);  //旧的值

    //簇端过压
    p_data_array = cJSON_GetObjectItem(p_request,"clusterOverVoltage");
    set_protect_params_into_struct(&param_info,CLUSTER_OVERVOLTAGE,p_data_array);
    if(param_info_old.cluster_OVP_warn_threshold_1 != param_info.cluster_OVP_warn_threshold_1) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.cluster_OVP_warn_threshold_1/10.0;
        op_log.op_param2 = param_info.cluster_OVP_warn_threshold_1/10.0;
        strcpy(op_log.op_type,"修改簇端过压一级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.cluster_OVP_warn_threshold_2 != param_info.cluster_OVP_warn_threshold_2) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.cluster_OVP_warn_threshold_2/10.0;
        op_log.op_param2 = param_info.cluster_OVP_warn_threshold_2/10.0;
        strcpy(op_log.op_type,"修改簇端过压二级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.cluster_OVP_warn_threshold_3 != param_info.cluster_OVP_warn_threshold_3) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.cluster_OVP_warn_threshold_3/10.0;
        op_log.op_param2 = param_info.cluster_OVP_warn_threshold_3/10.0;
        strcpy(op_log.op_type,"修改簇端过压三级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.cluster_OVP_warn_hysteresis_err != param_info.cluster_OVP_warn_hysteresis_err) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.cluster_OVP_warn_hysteresis_err/10.0;
        op_log.op_param2 = param_info.cluster_OVP_warn_hysteresis_err/10.0;
        strcpy(op_log.op_type,"修改簇端过压报警回差值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

    //簇端欠压
    p_data_array = cJSON_GetObjectItem(p_request,"clusterUnderVoltage");
    set_protect_params_into_struct(&param_info,CLUSTER_UNDERVOLTAGE,p_data_array);
    if(param_info_old.cluster_UVP_warn_threshold_1 != param_info.cluster_UVP_warn_threshold_1) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.cluster_UVP_warn_threshold_1/10.0;
        op_log.op_param2 = param_info.cluster_UVP_warn_threshold_1/10.0;
        strcpy(op_log.op_type,"修改簇端欠压一级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.cluster_UVP_warn_threshold_2 != param_info.cluster_UVP_warn_threshold_2) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.cluster_UVP_warn_threshold_2/10.0;
        op_log.op_param2 = param_info.cluster_UVP_warn_threshold_2/10.0;
        strcpy(op_log.op_type,"修改簇端欠压二级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.cluster_UVP_warn_threshold_3 != param_info.cluster_UVP_warn_threshold_3) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.cluster_UVP_warn_threshold_3/10.0;
        op_log.op_param2 = param_info.cluster_UVP_warn_threshold_3/10.0;
        strcpy(op_log.op_type,"修改簇端欠压三级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.cluster_UVP_warn_hysteresis_err != param_info.cluster_UVP_warn_hysteresis_err) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.cluster_UVP_warn_hysteresis_err/10.0;
        op_log.op_param2 = param_info.cluster_UVP_warn_hysteresis_err/10.0;
        strcpy(op_log.op_type,"修改簇端欠压报警回差值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

    //PACK过压阈值
    p_data_array = cJSON_GetObjectItem(p_request,"packOverVoltage");
    set_protect_params_into_struct(&param_info,PACK_OVERVOLTAGE,p_data_array);
    if(param_info_old.PACK_OVP_warn_threshold_1 != param_info.PACK_OVP_warn_threshold_1) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.PACK_OVP_warn_threshold_1/10.0;
        op_log.op_param2 = param_info.PACK_OVP_warn_threshold_1/10.0;
        strcpy(op_log.op_type,"修改PACK过压一级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.PACK_OVP_warn_threshold_2 != param_info.PACK_OVP_warn_threshold_2) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.PACK_OVP_warn_threshold_2/10.0;
        op_log.op_param2 = param_info.PACK_OVP_warn_threshold_2/10.0;
        strcpy(op_log.op_type,"修改PACK过压二级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.PACK_OVP_warn_threshold_3 != param_info.PACK_OVP_warn_threshold_3) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.PACK_OVP_warn_threshold_3/10.0;
        op_log.op_param2 = param_info.PACK_OVP_warn_threshold_3/10.0;
        strcpy(op_log.op_type,"修改PACK过压三级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.PACK_OVP_warn_hysteresis_err != param_info.PACK_OVP_warn_hysteresis_err) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.PACK_OVP_warn_hysteresis_err/10.0;
        op_log.op_param2 = param_info.PACK_OVP_warn_hysteresis_err/10.0;
        strcpy(op_log.op_type,"修改PACK过压报警回差值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

    //PACK欠压报警阈值
    p_data_array = cJSON_GetObjectItem(p_request,"packUnderVoltage");
    set_protect_params_into_struct(&param_info,PACK_UNDERVOLTAGE,p_data_array);
    if(param_info_old.PACK_UVP_warn_threshold_1 != param_info.PACK_UVP_warn_threshold_1) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.PACK_UVP_warn_threshold_1/10.0;
        op_log.op_param2 = param_info.PACK_UVP_warn_threshold_1/10.0;
        strcpy(op_log.op_type,"修改PACK欠压一级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.PACK_UVP_warn_threshold_2 != param_info.PACK_UVP_warn_threshold_2) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.PACK_UVP_warn_threshold_2/10.0;
        op_log.op_param2 = param_info.PACK_UVP_warn_threshold_2/10.0;
        strcpy(op_log.op_type,"修改PACK欠压二级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.PACK_UVP_warn_threshold_3 != param_info.PACK_UVP_warn_threshold_3) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.PACK_UVP_warn_threshold_3/10.0;
        op_log.op_param2 = param_info.PACK_UVP_warn_threshold_3/10.0;
        strcpy(op_log.op_type,"修改PACK欠压三级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.PACK_UVP_warn_hysteresis_err != param_info.PACK_UVP_warn_hysteresis_err) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.PACK_UVP_warn_hysteresis_err/10.0;
        op_log.op_param2 = param_info.PACK_UVP_warn_hysteresis_err/10.0;
        strcpy(op_log.op_type,"修改PACK欠压报警回差值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

    //单体过压阈值
    p_data_array = cJSON_GetObjectItem(p_request,"monomerOverVoltage");
    set_protect_params_into_struct(&param_info,MONOMER_OVERVOLTAGE,p_data_array);
    if(param_info_old.monomer_OVP_warn_threshold_1 != param_info.monomer_OVP_warn_threshold_1) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.monomer_OVP_warn_threshold_1;
        op_log.op_param2 = param_info.monomer_OVP_warn_threshold_1;
        strcpy(op_log.op_type,"修改单体过压一级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.monomer_OVP_warn_threshold_2 != param_info.monomer_OVP_warn_threshold_2) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.monomer_OVP_warn_threshold_2;
        op_log.op_param2 = param_info.monomer_OVP_warn_threshold_2;
        strcpy(op_log.op_type,"修改单体过压二级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.monomer_OVP_warn_threshold_3 != param_info.monomer_OVP_warn_threshold_3) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.monomer_OVP_warn_threshold_3;
        op_log.op_param2 = param_info.monomer_OVP_warn_threshold_3;
        strcpy(op_log.op_type,"修改单体过压三级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.monomer_OVP_warn_hysteresis_err != param_info.monomer_OVP_warn_hysteresis_err) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.monomer_OVP_warn_hysteresis_err;
        op_log.op_param2 = param_info.monomer_OVP_warn_hysteresis_err;
        strcpy(op_log.op_type,"修改单体过压报警回差值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

    //单体欠压
    p_data_array = cJSON_GetObjectItem(p_request,"monomerUnderVoltage");
    set_protect_params_into_struct(&param_info,MONOMER_UNDERVOLTAGE,p_data_array);
    if(param_info_old.monomer_UVP_warn_threshold_1 != param_info.monomer_UVP_warn_threshold_1) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.monomer_UVP_warn_threshold_1;
        op_log.op_param2 = param_info.monomer_UVP_warn_threshold_1;
        strcpy(op_log.op_type,"修改单体欠压一级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.monomer_UVP_warn_threshold_2 != param_info.monomer_UVP_warn_threshold_2) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.monomer_UVP_warn_threshold_2;
        op_log.op_param2 = param_info.monomer_UVP_warn_threshold_2;
        strcpy(op_log.op_type,"修改单体欠压二级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.monomer_UVP_warn_threshold_3 != param_info.monomer_UVP_warn_threshold_3) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.monomer_UVP_warn_threshold_3;
        op_log.op_param2 = param_info.monomer_UVP_warn_threshold_3;
        strcpy(op_log.op_type,"修改单体欠压三级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.monomer_UVP_warn_hysteresis_err != param_info.monomer_UVP_warn_hysteresis_err) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.monomer_UVP_warn_hysteresis_err;
        op_log.op_param2 = param_info.monomer_UVP_warn_hysteresis_err;
        strcpy(op_log.op_type,"修改单体欠压报警回差值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

    //单体压差过大
    p_data_array = cJSON_GetObjectItem(p_request,"execDiffPressure");
    set_protect_params_into_struct(&param_info,EXECDIFF_PRESSURE,p_data_array);
    if(param_info_old.monomer_vol_diff_warn_threshold_1 != param_info.monomer_vol_diff_warn_threshold_1) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.monomer_vol_diff_warn_threshold_1;
        op_log.op_param2 = param_info.monomer_vol_diff_warn_threshold_1;
        strcpy(op_log.op_type,"修改单体压差过大一级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.monomer_vol_diff_warn_threshold_2 != param_info.monomer_vol_diff_warn_threshold_2) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.monomer_vol_diff_warn_threshold_2;
        op_log.op_param2 = param_info.monomer_vol_diff_warn_threshold_2;
        strcpy(op_log.op_type,"修改单体压差过大二级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.monomer_vol_diff_warn_threshold_3 != param_info.monomer_vol_diff_warn_threshold_3) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.monomer_vol_diff_warn_threshold_3;
        op_log.op_param2 = param_info.monomer_vol_diff_warn_threshold_3;
        strcpy(op_log.op_type,"修改单体压差过大三级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.monomer_vol_diff_warn_hysteresis_err != param_info.monomer_vol_diff_warn_hysteresis_err) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = param_info_old.monomer_vol_diff_warn_hysteresis_err;
        op_log.op_param2 = param_info.monomer_vol_diff_warn_hysteresis_err;
        strcpy(op_log.op_type,"修改单体压差过大报警回差值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

    //单体充电过温
    p_data_array = cJSON_GetObjectItem(p_request,"chargeMonomerOverTemp"); //充电过温
    set_protect_params_into_struct(&param_info,CHARGE_MONOMER_OVERTEMP,p_data_array);
    if(param_info_old.charge_monomer_OTP_warn_threshold_1 != param_info.charge_monomer_OTP_warn_threshold_1) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.charge_monomer_OTP_warn_threshold_1 - 40);
        op_log.op_param2 = (param_info.charge_monomer_OTP_warn_threshold_1 - 40);
        strcpy(op_log.op_type,"修改单体充电过温一级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.charge_monomer_OTP_warn_threshold_2 != param_info.charge_monomer_OTP_warn_threshold_2) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.charge_monomer_OTP_warn_threshold_2 - 40);
        op_log.op_param2 = (param_info.charge_monomer_OTP_warn_threshold_2 - 40);
        strcpy(op_log.op_type,"修改单体充电过温二级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.charge_monomer_OTP_warn_threshold_3 != param_info.charge_monomer_OTP_warn_threshold_3) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.charge_monomer_OTP_warn_threshold_3 - 40);
        op_log.op_param2 = (param_info.charge_monomer_OTP_warn_threshold_3 - 40);
        strcpy(op_log.op_type,"修改单体充电过温三级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.charge_monomer_OTP_warn_hysteresis_err != param_info.charge_monomer_OTP_warn_hysteresis_err) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.charge_monomer_OTP_warn_hysteresis_err);
        op_log.op_param2 = (param_info.charge_monomer_OTP_warn_hysteresis_err);
        strcpy(op_log.op_type,"修改单体充电过温报警回差值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

    //单体充电欠温
    p_data_array = cJSON_GetObjectItem(p_request,"chargeMonomerUnderTemp"); //充电欠温
    set_protect_params_into_struct(&param_info,CHARGE_MONOMER_UNDERTEMP,p_data_array);
    if(param_info_old.charge_monomer_UTP_warn_threshold_1 != param_info.charge_monomer_UTP_warn_threshold_1) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.charge_monomer_UTP_warn_threshold_1 - 40);
        op_log.op_param2 = (param_info.charge_monomer_UTP_warn_threshold_1 - 40);
        strcpy(op_log.op_type,"修改单体充电欠温一级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.charge_monomer_UTP_warn_threshold_2 != param_info.charge_monomer_UTP_warn_threshold_2) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.charge_monomer_UTP_warn_threshold_2 - 40);
        op_log.op_param2 = (param_info.charge_monomer_UTP_warn_threshold_2 - 40);
        strcpy(op_log.op_type,"修改单体充电欠温二级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.charge_monomer_UTP_warn_threshold_3 != param_info.charge_monomer_UTP_warn_threshold_3) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.charge_monomer_UTP_warn_threshold_3 - 40);
        op_log.op_param2 = (param_info.charge_monomer_UTP_warn_threshold_3 - 40);
        strcpy(op_log.op_type,"修改单体充电欠温三级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.charge_monomer_UTP_warn_hysteresis_err != param_info.charge_monomer_UTP_warn_hysteresis_err) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.charge_monomer_UTP_warn_hysteresis_err);
        op_log.op_param2 = (param_info.charge_monomer_UTP_warn_hysteresis_err);
        strcpy(op_log.op_type,"修改单体充电欠温报警回差值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

    //放电过温
    p_data_array = cJSON_GetObjectItem(p_request,"disChargeMonomerOverTemp"); //放电过温
    set_protect_params_into_struct(&param_info,DISCHARGE_MONOMER_OVERTEMP,p_data_array);
    if(param_info_old.discharge_monomer_OTP_warn_threshold_1 != param_info.discharge_monomer_OTP_warn_threshold_1) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.discharge_monomer_OTP_warn_threshold_1 - 40);
        op_log.op_param2 = (param_info.discharge_monomer_OTP_warn_threshold_1 - 40);
        strcpy(op_log.op_type,"修改单体放电过温一级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.discharge_monomer_OTP_warn_threshold_2 != param_info.discharge_monomer_OTP_warn_threshold_2) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.discharge_monomer_OTP_warn_threshold_2 - 40);
        op_log.op_param2 = (param_info.discharge_monomer_OTP_warn_threshold_2 - 40);
        strcpy(op_log.op_type,"修改单体放电过温二级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.discharge_monomer_OTP_warn_threshold_3 != param_info.discharge_monomer_OTP_warn_threshold_3) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.discharge_monomer_OTP_warn_threshold_3 - 40);
        op_log.op_param2 = (param_info.discharge_monomer_OTP_warn_threshold_3 - 40);
        strcpy(op_log.op_type,"修改单体放电过温三级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.discharge_monomer_OTP_warn_hysteresis_err != param_info.discharge_monomer_OTP_warn_hysteresis_err) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.discharge_monomer_OTP_warn_hysteresis_err);
        op_log.op_param2 = (param_info.discharge_monomer_OTP_warn_hysteresis_err);
        strcpy(op_log.op_type,"修改单体放电过温报警回差值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

    //放电欠温
    p_data_array = cJSON_GetObjectItem(p_request,"disChargeMonomerUnderTemp"); //放电欠温
    set_protect_params_into_struct(&param_info,DISCHARGE_MONOMER_UNDERTEMP,p_data_array);
    if(param_info_old.discharge_monomer_UTP_warn_threshold_1 != param_info.discharge_monomer_UTP_warn_threshold_1) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.discharge_monomer_UTP_warn_threshold_1 - 40);
        op_log.op_param2 = (param_info.discharge_monomer_UTP_warn_threshold_1 - 40);
        strcpy(op_log.op_type,"修改单体放电欠温一级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.discharge_monomer_UTP_warn_threshold_2 != param_info.discharge_monomer_UTP_warn_threshold_2) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.discharge_monomer_UTP_warn_threshold_2 - 40);
        op_log.op_param2 = (param_info.discharge_monomer_UTP_warn_threshold_2 - 40);
        strcpy(op_log.op_type,"修改单体放电过温二级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.discharge_monomer_UTP_warn_threshold_3 != param_info.discharge_monomer_UTP_warn_threshold_3) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.discharge_monomer_UTP_warn_threshold_3 - 40);
        op_log.op_param2 = (param_info.discharge_monomer_UTP_warn_threshold_3 - 40);
        strcpy(op_log.op_type,"修改单体放电过温三级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.discharge_monomer_UTP_warn_hysteresis_err != param_info.discharge_monomer_UTP_warn_hysteresis_err) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.discharge_monomer_UTP_warn_hysteresis_err);
        op_log.op_param2 = (param_info.discharge_monomer_UTP_warn_hysteresis_err);
        strcpy(op_log.op_type,"修改单体放电欠温报警回差值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

    //温差过大
    p_data_array = cJSON_GetObjectItem(p_request,"execDiffTemp"); //温差过大
    set_protect_params_into_struct(&param_info,EXECDIFF_TEMP,p_data_array);
    if(param_info_old.monomer_temp_diff_warn_threshold_1 != param_info.monomer_temp_diff_warn_threshold_1) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.monomer_temp_diff_warn_threshold_1);
        op_log.op_param2 = (param_info.monomer_temp_diff_warn_threshold_1);
        strcpy(op_log.op_type,"修改单体温差过大一级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.monomer_temp_diff_warn_threshold_2 != param_info.monomer_temp_diff_warn_threshold_2) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.monomer_temp_diff_warn_threshold_2);
        op_log.op_param2 = (param_info.monomer_temp_diff_warn_threshold_2);
        strcpy(op_log.op_type,"修改单体温差过大二级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.monomer_temp_diff_warn_threshold_2 != param_info.monomer_temp_diff_warn_threshold_2) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.monomer_temp_diff_warn_threshold_2);
        op_log.op_param2 = (param_info.monomer_temp_diff_warn_threshold_2);
        strcpy(op_log.op_type,"修改单体温差过大三级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.discharge_monomer_UTP_warn_hysteresis_err != param_info.discharge_monomer_UTP_warn_hysteresis_err) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.discharge_monomer_UTP_warn_hysteresis_err);
        op_log.op_param2 = (param_info.discharge_monomer_UTP_warn_hysteresis_err);
        strcpy(op_log.op_type,"修改单体温差过大报警回差值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

    //充电过流
    p_data_array = cJSON_GetObjectItem(p_request,"chargeOverCurrent"); //充电过流
    set_protect_params_into_struct(&param_info,CHARGE_OVER_CURRENT,p_data_array);
    if(param_info_old.charge_OCP_warn_threshold_1 != param_info.charge_OCP_warn_threshold_1) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.charge_OCP_warn_threshold_1/10.0);
        op_log.op_param2 = (param_info.charge_OCP_warn_threshold_1/10.0);
        strcpy(op_log.op_type,"修改充电过流一级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.charge_OCP_warn_threshold_2 != param_info.charge_OCP_warn_threshold_2) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.charge_OCP_warn_threshold_2/10.0);
        op_log.op_param2 = (param_info.charge_OCP_warn_threshold_2/10.0);
        strcpy(op_log.op_type,"修改充电过流二级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.charge_OCP_warn_threshold_3 != param_info.charge_OCP_warn_threshold_3) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.charge_OCP_warn_threshold_3/10.0);
        op_log.op_param2 = (param_info.charge_OCP_warn_threshold_3/10.0);
        strcpy(op_log.op_type,"修改充电过流三级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.charge_OCP_warn_hysteresis_err != param_info.charge_OCP_warn_hysteresis_err) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.charge_OCP_warn_hysteresis_err/10.0);
        op_log.op_param2 = (param_info.charge_OCP_warn_hysteresis_err/10.0);
        strcpy(op_log.op_type,"修改充电过流报警回差值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

    //放电过流
    p_data_array = cJSON_GetObjectItem(p_request,"disChargeOverCurrent"); //放电过流
    set_protect_params_into_struct(&param_info,DISCHARGE_OVER_CURRENT,p_data_array);
    if(param_info_old.discharge_OCP_warn_threshold_1 != param_info.discharge_OCP_warn_threshold_1) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.discharge_OCP_warn_threshold_1/10.0);
        op_log.op_param2 = (param_info.discharge_OCP_warn_threshold_1/10.0);
        strcpy(op_log.op_type,"修改放电过流一级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.discharge_OCP_warn_threshold_2 != param_info.discharge_OCP_warn_threshold_2) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.discharge_OCP_warn_threshold_2/10.0);
        op_log.op_param2 = (param_info.discharge_OCP_warn_threshold_2/10.0);
        strcpy(op_log.op_type,"修改放电过流二级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.discharge_OCP_warn_threshold_3 != param_info.discharge_OCP_warn_threshold_3) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.discharge_OCP_warn_threshold_3/10.0);
        op_log.op_param2 = (param_info.discharge_OCP_warn_threshold_3/10.0);
        strcpy(op_log.op_type,"修改放电过流三级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.discharge_OCP_warn_hysteresis_err != param_info.discharge_OCP_warn_hysteresis_err) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.discharge_OCP_warn_hysteresis_err/10.0);
        op_log.op_param2 = (param_info.discharge_OCP_warn_hysteresis_err/10.0);
        strcpy(op_log.op_type,"修改放电过流报警回差值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

    //SOC过低
    p_data_array = cJSON_GetObjectItem(p_request,"socTooLow"); //SOC过低
    set_protect_params_into_struct(&param_info,SOC_TOO_LOW,p_data_array);
    if(param_info_old.SOC_low_warn_threshold_1 != param_info.SOC_low_warn_threshold_1) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.SOC_low_warn_threshold_1);
        op_log.op_param2 = (param_info.SOC_low_warn_threshold_1);
        strcpy(op_log.op_type,"修改SOC过低一级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.SOC_low_warn_threshold_2 != param_info.SOC_low_warn_threshold_2) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.SOC_low_warn_threshold_2);
        op_log.op_param2 = (param_info.SOC_low_warn_threshold_2);
        strcpy(op_log.op_type,"修改SOC过低二级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.SOC_low_warn_threshold_3 != param_info.SOC_low_warn_threshold_3) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.SOC_low_warn_threshold_3);
        op_log.op_param2 = (param_info.SOC_low_warn_threshold_3);
        strcpy(op_log.op_type,"修改SOC过低三级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.SOC_low_warn_hysteresis_err != param_info.SOC_low_warn_hysteresis_err) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.SOC_low_warn_hysteresis_err);
        op_log.op_param2 = (param_info.SOC_low_warn_hysteresis_err);
        strcpy(op_log.op_type,"修改SOC过低报警回差值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

    //SOC过高
    p_data_array = cJSON_GetObjectItem(p_request,"socTooHigh"); //SOC过高
    set_protect_params_into_struct(&param_info,SOC_TOO_HIGH,p_data_array);
    if(param_info_old.SOC_high_warn_threshold_1 != param_info.SOC_high_warn_threshold_1) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.SOC_high_warn_threshold_1);
        op_log.op_param2 = (param_info.SOC_high_warn_threshold_1);
        strcpy(op_log.op_type,"修改SOC过高一级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.SOC_high_warn_threshold_2 != param_info.SOC_high_warn_threshold_2) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.SOC_high_warn_threshold_2);
        op_log.op_param2 = (param_info.SOC_high_warn_threshold_2);
        strcpy(op_log.op_type,"修改SOC过高二级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.SOC_high_warn_threshold_3 != param_info.SOC_high_warn_threshold_3) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.SOC_high_warn_threshold_3);
        op_log.op_param2 = (param_info.SOC_high_warn_threshold_3);
        strcpy(op_log.op_type,"修改SOC过高三级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.SOC_high_warn_hysteresis_err != param_info.SOC_high_warn_hysteresis_err) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.SOC_high_warn_hysteresis_err);
        op_log.op_param2 = (param_info.SOC_high_warn_hysteresis_err);
        strcpy(op_log.op_type,"修改SOC过高报警回差值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

    //阻抗过低
    p_data_array = cJSON_GetObjectItem(p_request,"insulation"); //阻抗过低
    set_protect_params_into_struct(&param_info,INSULATION_TOO_LOW,p_data_array);
    if(param_info_old.ISO_warn_threshold_1 != param_info.ISO_warn_threshold_1) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.ISO_warn_threshold_1);
        op_log.op_param2 = (param_info.ISO_warn_threshold_1);
        strcpy(op_log.op_type,"修改阻抗过低一级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.ISO_warn_threshold_2 != param_info.ISO_warn_threshold_2) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.ISO_warn_threshold_2);
        op_log.op_param2 = (param_info.ISO_warn_threshold_2);
        strcpy(op_log.op_type,"修改阻抗过低二级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.ISO_warn_threshold_3 != param_info.ISO_warn_threshold_3) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.ISO_warn_threshold_3);
        op_log.op_param2 = (param_info.ISO_warn_threshold_3);
        strcpy(op_log.op_type,"修改阻抗过低三级报警阈值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if(param_info_old.ISO_warn_hysteresis_err != param_info.ISO_warn_hysteresis_err) //如果新的和老的不相等,就是修改了参数
    {
        op_log.op_param1 = (param_info_old.ISO_warn_hysteresis_err);
        op_log.op_param2 = (param_info.ISO_warn_hysteresis_err);
        strcpy(op_log.op_type,"修改阻抗过低报警回差值");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

    para_config_page_protect_para_set(&param_info);
    protect_params_flag_set();
    cJSON_Delete(p_request);

    build_empty_response(response,200,"set protect params successful");
	http_back(p_nc,response);
}

void get_runtime_params(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
    cJSON *p_resp_item;
    uint8_t content[128];
    uint8_t response[132];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    int16_t soc_charge_limit;                       // SOC充电上限
    int16_t soc_discharge_limit;                    //SOC放电下限

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getRunTimeParams"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

    p_resp_item = cJSON_CreateObject();
    if(p_resp_item == NULL)
    {
        print_log("create json obj failed");
        return;
    }

    para_config_page_limit_soc_para_get(&soc_charge_limit, &soc_discharge_limit);
    cJSON_AddNumberToObject(p_resp_item,"chargeDischargePower",0.5);
    cJSON_AddNumberToObject(p_resp_item,"socUpperLimit", soc_charge_limit);
    cJSON_AddNumberToObject(p_resp_item,"socLowerLimit", soc_discharge_limit);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        cJSON_Delete(p_resp_item);
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddItemToObject(p_resp_root,"data",p_resp_item);
    cJSON_AddStringToObject(p_resp_root,"msg","get runtime parameters successful");

    p = cJSON_PrintUnformatted(p_resp_root);

    strcpy(response,p);
    cJSON_Delete(p_resp_root);
    free(p);

    http_back(p_nc,response);
}

void set_runtime_params(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    uint8_t response[64];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    operation_log_t op_log;
    uint8_t cur_user[32] = {0};
    int16_t soc_charge_limit;                       // SOC充电上限
    int16_t soc_discharge_limit;                    //SOC放电下限
    int16_t soc_charge_limit_old;                       
    int16_t soc_discharge_limit_old;;                  
    web_control_info_t *web_control_info;
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();   // 遥信数据
    uint8_t charge_change_flag = 0;
    uint8_t discharge_change_flag = 0;

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"setRunTimeParams"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    soc_charge_limit = cJSON_GetObjectItem(p_request,"socUpperLimit")->valueint;
    soc_discharge_limit = cJSON_GetObjectItem(p_request,"socLowerLimit")->valueint;

    cJSON_Delete(p_request);

    para_config_page_limit_soc_para_get(&soc_charge_limit_old, &soc_discharge_limit_old);

    if (soc_charge_limit != soc_charge_limit_old)
    {
        charge_change_flag = 1;
    }
    if (soc_discharge_limit != soc_discharge_limit_old)
    {
        discharge_change_flag = 1;
    }
    init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);

    /*此时禁止充电*/
    if((p_telematic_data->container_system_status_info[0] & 0x01) && charge_change_flag)
    {
        print_log("forbid charge.");
        op_log.op_param1 = soc_charge_limit_old;
        op_log.op_param2 = soc_charge_limit;
        strcpy(op_log.op_type,"修改充电SOC上限");
        strcpy(op_log.op_status,"failed");
        add_one_op_log(&op_log);
        build_empty_response(response,204, "not allow to modify charge soc limit when charge is forbidden");
        
	//	build_empty_response(response,204, "not allowed modify charge soc limit when charge is forbidden");
		http_back(p_nc,response);
		return;
    }

    if((p_telematic_data->container_system_status_info[0] & 0x02) && discharge_change_flag)
    {
        print_log("forbid discharge.");
        op_log.op_param1 = soc_discharge_limit_old;
        op_log.op_param2 = soc_discharge_limit;
        strcpy(op_log.op_type,"修改放电SOC下限");
        strcpy(op_log.op_status,"failed");
        add_one_op_log(&op_log);
         build_empty_response(response,205, "not allow Tto modify discharge soc limit when charge is forbidden");
        

		http_back(p_nc,response);
		return;
    }
    /*充电上限不合理,或者此时禁止充电*/
    if(soc_charge_limit < 80 || soc_charge_limit > 100)
    {
        print_log("invalid soc charge limit %d, only support value between [80,100]", soc_charge_limit);
        op_log.op_param1 = soc_charge_limit_old;
        op_log.op_param2 = soc_charge_limit;
        strcpy(op_log.op_type,"修改充电SOC上限");
        strcpy(op_log.op_status,"failed");
        add_one_op_log(&op_log);
       build_empty_response(response,206,"invalid soc charge limit, only support value between [80,100]");

		//build_empty_response(response,206,"invalid soc charge limit, only support value between [80,100]");
		http_back(p_nc,response);
		return;
    }
    /*放电下限不合理,或者此时禁止放电*/
    if(soc_discharge_limit > 20 || soc_discharge_limit < 0)
    {
        print_log("invalid soc discharge limit %d, only support value between [80,100]", soc_discharge_limit);
        op_log.op_param1 = soc_discharge_limit_old;
        op_log.op_param2 = soc_discharge_limit;
        strcpy(op_log.op_type,"修改放电SOC下限");
        strcpy(op_log.op_status,"failed");
        add_one_op_log(&op_log);
        build_empty_response(response,207,"invalid soc discharge limit, only support value between [0,20]");
        
		http_back(p_nc,response);
		return;
    }

    /*获取原有数据,看是否发生变化,若发生变化,需要在操作日志进行记录*/
    if (soc_charge_limit != soc_charge_limit_old)
    {
        charge_change_flag = 1;
        op_log.op_param1 = soc_charge_limit_old;
        op_log.op_param2 = soc_charge_limit;
        strcpy(op_log.op_type,"修改充电SOC上限");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    if (soc_discharge_limit != soc_discharge_limit_old)
    {
        discharge_change_flag = 1;
        op_log.op_param1 = soc_discharge_limit_old;
        op_log.op_param2 = soc_discharge_limit;
        strcpy(op_log.op_type,"修改放电SOC下限");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    web_control_info = shm_web_control_info_get();
    if(charge_change_flag || discharge_change_flag)
    {
        para_config_page_limit_soc_para_set(soc_charge_limit, soc_discharge_limit);
        web_control_info->charge_discharge_soc_limit_set_flag = 1;
    }

    build_empty_response(response,200,"set runtime parameters successful");
	http_back(p_nc,response);
}

void get_run_storage_params(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
    cJSON *p_resp_item;
    uint8_t response[132];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    uint16_t storage_days = 0;
    uint16_t storage_freq = 0;

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getRunStorageParams"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

    p_resp_item = cJSON_CreateObject();
    if(p_resp_item == NULL)
    {
        print_log("create json obj failed");
        return;
    }

    para_config_page_storage_para_get(&storage_days, &storage_freq);
    cJSON_AddNumberToObject(p_resp_item, "storageDays", storage_days);
    cJSON_AddNumberToObject(p_resp_item, "storageFrequency", storage_freq);


    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        cJSON_Delete(p_resp_item);
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddItemToObject(p_resp_root,"data",p_resp_item);
    cJSON_AddStringToObject(p_resp_root,"msg","get run storage parameters successful");

    p = cJSON_PrintUnformatted(p_resp_root);

    strcpy(response,p);
    cJSON_Delete(p_resp_root);
    free(p);

    http_back(p_nc,response);
}

void set_run_storage_params(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    uint8_t response[64];
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    operation_log_t op_log;
    uint8_t cur_user[32] = {0};
    uint16_t storage_days;
    uint16_t storage_freq;
    uint16_t storage_days_old;
    uint16_t storage_freq_old;
    bool change_flag = false;

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"setRunStorageParams"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    init_user_basic_info(&op_log);
    get_user_from_http_request(p_msg, cur_user);
    strcpy(op_log.user_name, cur_user);
    get_user_basic_info(&op_log);

    storage_days = cJSON_GetObjectItem(p_request, "storageDays")->valueint;
    storage_freq = cJSON_GetObjectItem(p_request, "storageFrequency")->valueint;
    if ((storage_days >= PARAM_STORAGE_DAYS_MIN) && (storage_days <= PARAM_STORAGE_DAYS_MAX) && \
        (storage_freq >= PARAM_STORAGE_FREQ_MIN) && (storage_freq <= PARAM_STORAGE_FREQ_MAX))
    {
        para_config_page_storage_para_get(&storage_days_old, &storage_freq_old);
        if (storage_days != storage_days_old)
        {
            change_flag = true;
            op_log.op_param1 = storage_days_old;
            op_log.op_param2 = storage_days;
            strcpy(op_log.op_type,"修改运行数据存储天数");
            strcpy(op_log.op_status,"success");
            add_one_op_log(&op_log);
        }
        if (storage_freq != storage_freq_old)
        {
            change_flag = true;
            op_log.op_param1 = storage_freq_old;
            op_log.op_param2 = storage_freq;
            strcpy(op_log.op_type,"修改运行数据存储频率");
            strcpy(op_log.op_status,"success");
            add_one_op_log(&op_log);
        }
        if (change_flag)
        {
            para_config_page_storage_para_set(storage_days, storage_freq);
        }
    }

    cJSON_Delete(p_request);


    build_empty_response(response,200,"set run storage parameters successful");
	http_back(p_nc,response);
}

void get_eol_threshold(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
    cJSON *p_resp_item;
    uint8_t response[64];
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    uint8_t eol_threshold;
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getEOLAlarmThreshold"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    cJSON_Delete(p_request);

    eol_threshold = p_para_data->eol_threshold;
    p_resp_item = cJSON_CreateObject();
    if(p_resp_item == NULL)
    {
        print_log("create json obj failed");
        return;
    }    
    cJSON_AddNumberToObject(p_resp_item, "EOLAlarmThreshold", eol_threshold);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        cJSON_Delete(p_resp_item);
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddItemToObject(p_resp_root,"data",p_resp_item);
    cJSON_AddStringToObject(p_resp_root,"msg","get EOL Alarm Threshold successfu");

    p = cJSON_PrintUnformatted(p_resp_root);

    http_back(p_nc, p);
    cJSON_Delete(p_resp_root);
    free(p);
}

void set_eol_threshold(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    uint8_t response[64];
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    operation_log_t op_log;
    uint8_t cur_user[32] = {0};
    uint8_t eol_threshold;
    uint8_t eol_threshold_old;
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数
    web_control_info_t *web_control_info = shm_web_control_info_get();

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"setEOLAlarmThreshold"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    eol_threshold = cJSON_GetObjectItem(p_request, "EOLAlarmThreshold")->valueint;
    cJSON_Delete(p_request);

    init_user_basic_info(&op_log);
    get_user_from_http_request(p_msg, cur_user);
    strcpy(op_log.user_name, cur_user);
    get_user_basic_info(&op_log);

    eol_threshold_old = p_para_data->eol_threshold;
    if ((eol_threshold >= 0) && (eol_threshold <= 100) &&
        eol_threshold != eol_threshold_old)
    {
        p_para_data->eol_threshold = eol_threshold;
        web_control_info->eol_threshold_set_flag = 1;
       
        op_log.op_param1 = eol_threshold_old;
        op_log.op_param2 = eol_threshold;
        strcpy(op_log.op_type,"设置EOL告警参数");
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    build_empty_response(response,200,"set run storage parameters successful");
	http_back(p_nc,response);
}

/**
 * @brief 保护参数模块初始化
 * @return void
 */
void protect_param_module_init(void)
{
    /*获取保护参数*/
	if(!web_func_attach("/paramsInfo/getProtectParams", get_protect_params))
	{
		print_log("[/paramsInfo/getProtectParams] attach failed");
	}
	/*设置保护参数*/
	if(!web_func_attach("/paramsInfo/setProtectParams", set_protect_params))
	{
		print_log("[/paramsInfo/setProtectParams] attach failed");
	}
	/*获取运行参数*/
	if(!web_func_attach("/paramsInfo/getRunTimeParams", get_runtime_params))
	{
		print_log("[/paramsInfo/getRunTimeParams] attach failed");
	}
	/*设置运行参数*/
	if(!web_func_attach("/paramsInfo/setRunTimeParams", set_runtime_params))
	{
		print_log("[/paramsInfo/setRunTimeParams] attach failed");
	}
	/*获取运行数据存储参数*/
	if(!web_func_attach("/paramsInfo/getRunStorageParams", get_run_storage_params))
	{
		print_log("[/paramsInfo/getRunStorageParams] attach failed");
	}
	/*设置运行数据存储参数*/
	if(!web_func_attach("/paramsInfo/setRunStorageParams", set_run_storage_params))
	{
		print_log("[/paramsInfo/setRunStorageParams] attach failed");
	}
    /*获取EOL告警阈值参数*/
	if(!web_func_attach("/paramsInfo/getEOLAlarmThreshold", get_eol_threshold))
	{
		print_log("[/paramsInfo/getEOLAlarmThreshold] attach failed");
	}
	/*设置EOL告警阈值参数*/
	if(!web_func_attach("/paramsInfo/setEOLAlarmThreshold", set_eol_threshold))
	{
		print_log("[/paramsInfo/setEOLAlarmThreshold] attach failed");
	}
}