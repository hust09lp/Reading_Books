#include "cJSON.h"
#include "common.h"
#include "sdk/sdk_fs.h"
#include "sdk/sdk_file.h"
#include "sdk/sdk_public.h"
#include "sqlite3.h"
#include "operation_log.h"
#include "sdk_shm.h"
#include"data_shm.h"
#include "sofar_errors.h"
#include <sys/stat.h>

#define MAX_BUFF (200 * 250)   //每一条最多占用200字节,最多可以有250条
#define PATH_HISTORY_EVENT_RECOND_FOLDER	"/user/data/event/"
#define OPERATION_DB_PATH                   "/user/data/event/Operation.db"
#define OPERATION_CSV_PATH                  "/tmp/CMUoperation.csv"
#define INVALID_OPERATION_ID     (255)

struct operationlog_mapping {
    int operationlog_id;
    char *operationlog_text;
};


/*
/*
操作日志词条-中文
*/
const struct operationlog_mapping operationlog_mappings[] = 
{
    {1,"用户登录"},
    {2,"远程开机"},
    {3,"远程关机"},
    {4,"节能降耗开机"},
    {5,"节能降耗关机"},
    {6,"节能降耗停机"},
    {7,"开启排气扇"},
    {8,"关闭排气扇"},
    {9,"故障复位"},
    {10,"修改簇端过压一级报警阈值"},
    {11,"修改簇端过压二级报警阈值"},
    {12,"修改簇端过压三级报警阈值"},
    {13,"修改簇端过压报警回差值"},
    {14,"修改簇端欠压一级报警阈值"},
    {15,"修改簇端欠压二级报警阈值"},
    {16,"修改簇端欠压三级报警阈值"},
    {17,"修改簇端欠压报警回差值"},
    {18,"修改PACK过压一级报警阈值"},
    {19,"修改PACK过压二级报警阈值"},
    {20,"修改PACK过压三级报警阈值"},
    {21,"修改PACK过压报警回差值"},
    {22,"修改PACK欠压一级报警阈值"},
    {23,"修改PACK欠压二级报警阈值"},
    {24,"修改PACK欠压三级报警阈值"},
    {25,"修改PACK欠压报警回差值"},
    {26,"修改单体过压一级报警阈值"},
    {27,"修改单体过压二级报警阈值"},
    {28,"修改单体过压三级报警阈值"},
    {29,"修改单体过压报警回差值"},
    {30,"修改单体欠压一级报警阈值"},
    {31,"修改单体欠压二级报警阈值"},
    {32,"修改单体欠压三级报警阈值"},
    {33,"修改单体欠压报警回差值"},
    {34,"修改单体压差过大一级报警阈值"},
    {35,"修改单体压差过大二级报警阈值"},
    {36,"修改单体压差过大三级报警阈值"},
    {37,"修改单体压差过大报警回差值"},
    {38,"修改单体充电过温一级报警阈值"},
    {39,"修改单体充电过温二级报警阈值"},
    {40,"修改单体充电过温三级报警阈值"},
    {41,"修改单体充电过温报警回差值"},
    {42,"修改单体充电欠温一级报警阈值"},
    {43,"修改单体充电欠温二级报警阈值"},
    {44,"修改单体充电欠温三级报警阈值"},
    {45,"修改单体充电欠温报警回差值"},
    {46,"修改单体放电过温一级报警阈值"},
    {47,"修改单体放电过温二级报警阈值"},
    {48,"修改单体放电过温三级报警阈值"},
    {49,"修改单体放电过温报警回差值"},
    {50,"修改单体放电欠温一级报警阈值"},
    {51,"修改单体放电欠温二级报警阈值"},
    {52,"修改单体放电欠温三级报警阈值"},
    {53,"修改单体放电欠温报警回差值"},
    {54,"修改单体温差过大一级报警阈值"},
    {55,"修改单体温差过大二级报警阈值"},
    {56,"修改单体温差过大三级报警阈值"},
    {57,"修改单体温差过大报警回差值"},
    {58,"修改充电过流一级报警阈值"},
    {59,"修改充电过流二级报警阈值"},
    {60,"修改充电过流三级报警阈值"},
    {61,"修改充电过流报警回差值"},
    {62,"修改放电过流一级报警阈值"},
    {63,"修改放电过流二级报警阈值"},
    {64,"修改放电过流三级报警阈值"},
    {65,"修改放电过流报警回差值"},
    {66,"修改SOC过低一级报警阈值"},
    {67,"修改SOC过低二级报警阈值"},
    {68,"修改SOC过低三级报警阈值"},
    {69,"修改SOC过低报警回差值"},
    {70,"修改SOC过高一级报警阈值"},
    {71,"修改SOC过高二级报警阈值"},
    {72,"修改SOC过高三级报警阈值"},
    {73,"修改SOC过高报警回差值"},
    {74,"修改阻抗过低一级报警阈值"},
    {75,"修改阻抗过低二级报警阈值"},
    {76,"修改阻抗过低三级报警阈值"},
    {77,"修改阻抗过低报警回差值"},
    {78,"第1簇主正继电器分"},
    {79,"第2簇主正继电器分"},
    {80,"第3簇主正继电器分"},
    {81,"第4簇主正继电器分"},
    {82,"第1簇主正继电器合"},
    {83,"第2簇主正继电器合"},
    {84,"第3簇主正继电器合"},
    {85,"第4簇主正继电器合"},
    {86,"第1簇主负继电器分"},
    {87,"第2簇主负继电器分"},
    {88,"第3簇主负继电器分"},
    {89,"第4簇主负继电器分"},
    {90,"第1簇主负继电器合"},
    {91,"第2簇主负继电器合"},
    {92,"第3簇主负继电器合"},
    {93,"第4簇主负继电器合"},
    {94,"第1簇预充继电器分"},
    {95,"第2簇预充继电器分"},
    {96,"第3簇预充继电器分"},
    {97,"第4簇预充继电器分"},
    {98,"第1簇预充继电器合"},
    {99,"第2簇预充继电器合"},
    {100,"第3簇预充继电器合"},
    {101,"第4簇预充继电器合"},
    {102,"第1簇辅助继电器分"},
    {103,"第2簇辅助继电器分"},
    {104,"第3簇辅助继电器分"},
    {105,"第4簇辅助继电器分"},
    {106,"第1簇辅助继电器合"},
    {107,"第2簇辅助继电器合"},
    {108,"第3簇辅助继电器合"},
    {109,"第4簇辅助继电器合"},
    {110,"第1簇运行显示灯分"},
    {111,"第2簇运行显示灯分"},
    {112,"第3簇运行显示灯分"},
    {113,"第4簇运行显示灯分"},
    {114,"第1簇运行显示灯合"},
    {115,"第2簇运行显示灯合"},
    {116,"第3簇运行显示灯合"},
    {117,"第4簇运行显示灯合"},
    {118,"第1簇故障显示灯分"},
    {119,"第2簇故障显示灯分"},
    {120,"第3簇故障显示灯分"},
    {121,"第4簇故障显示灯分"},
    {122,"第1簇故障显示灯合"},
    {123,"第2簇故障显示灯合"},
    {124,"第3簇故障显示灯合"},
    {125,"第4簇故障显示灯合"},
    {126,"第1簇电池簇下电"},
    {127,"第2簇电池簇下电"},
    {128,"第3簇电池簇下电"},
    {129,"第4簇电池簇下电"},
    {130,"第1簇电池簇上电"},
    {131,"第2簇电池簇上电"},
    {132,"第3簇电池簇上电"},
    {133,"第4簇电池簇上电"},
    {134,"打开PCS开关"},
    {135,"关闭PCS开关"},
    {136,"打开液冷系统"},
    {137,"关闭液冷系统"},
    {138,"设置液冷参数"},
    {139,"设置CMU运维模式"},
    {140,"设置CMU运行模式"},
    {141,"设置电池仓个数"},
    {142,"设置储能柜属性"},
    {143,"设置电池簇PACK个数"},
    {144,"设置储能柜的SN"},
    {145,"设置工厂容测模式"},
    {146,"设置运行参数"},
    {147,"修改运行数据存储天数"},
    {148,"修改运行数据存储频率"},
    {149,"设置DHCP"},
    {150,"修改静态网络参数"},
    {151,"修改系统参数"},
    {152,"修改通讯参数"},
    {153,"NTP同步时间"},
    {154,"修改充电SOC上限"},
    {155,"修改放电SOC下限"},
    {156,"设置时区"},
    {157,"设置EOL告警参数"},
    {158,"批量删除用户"},
    {159,"删除用户"},
    {160,"添加用户"},
    {161,"重置密码"},
    {162,"批量重置密码"},
    {163,"修改用户信息"},
    {164,"同步系统时间"},
    {165,"设置安规标准"},
    {166,"导入单个安规文件(.txt)"},
    {167,"导入安规库(.bin)"},
    {168,"空载转休眠"},
    {169,"休眠转停机"},
    {170,"休眠转开机"},
    {171,"空载转休眠使能设置"},
    {172,"休眠转停机使能设置"},
    {173,"空载转休眠时间设置"},
    {174,"休眠转停机时间设置"},
    {175,"导入安规库(.sofar)"},
    {176,"设置保温模式使能位"},
    {177,"设置保温加热启动温度"},
    {178,"设置保温加热停止温度"},
    {179,"设置保温制冷启动温度"},
    {180,"设置保温制冷停止温度"},
    {181,"设置PCS功率软启时间梯度"},
    {182,"设置外部EPO类型"},
    {183,"设置功率因数"},
    {184,"设置无功模式"},
    {185,"设置无功使能"},
    {186,"设置外部MODBUS使能"},
    {187,"设置外部IEC104使能"},
};

/**
 * @brief  根据操作日志获取对应的ID号
 * @param  [in] *operationlog_text 操作日志文本 
 * @return
 */
int32_t get_operationid_by_name(const char *operationlog_text)
{
    int operationid;
    uint32_t i;
    int num_mappings = sizeof(operationlog_mappings) / sizeof(operationlog_mappings[0]);

    for(i = 0; i < num_mappings; i++)
    {
        if(!strcmp(operationlog_text, operationlog_mappings[i].operationlog_text))  //匹配成功
        {
            return (i+1);
        }
    }
    return INVALID_OPERATION_ID;
}


/**
 * @brief  根据操作日志ID获取对应的操作名称
 * @param  [in] id 操作日志ID 
 * @return
 */
char *get_operation_name_by_id(int id)
{
    uint32_t i;
    int num_mappings = sizeof(operationlog_mappings) / sizeof(operationlog_mappings[0]);

    for(i = 0; i < num_mappings; i++)
    {
        if(operationlog_mappings[i].operationlog_id == id)  //匹配成功
        {
            return operationlog_mappings[i].operationlog_text;
        }
    }
    return NULL;
}



typedef struct	
{
	uint8_t start_time[32];
	uint8_t end_time[32];
}operation_records_time_t;



/**
 * @brief   根据已知信息获取账户中的其他信息
 * @return  无
 */
void get_user_basic_info(operation_log_t *p_oplog)
{
	FILE *fp;
	cJSON *p_root_array = NULL;
	cJSON *p_item = NULL;
	uint8_t *p_uname = NULL;
	uint8_t *p_buff = NULL;
	uint8_t i;

	fp = fopen(ADMIN_JSON_FILE,"r");
	if(fp == NULL)
	{
		print_log("open admin json file failed.");
		return;
	}
	p_buff = (uint8_t *)malloc(MAX_BUFF);
	if(p_buff == NULL)
	{
		print_log("malloc memory failed.");
		fclose(fp);
		return;
	}

	fread(p_buff,1,MAX_BUFF,fp);
	fclose(fp);
	p_root_array = cJSON_Parse(p_buff);

	if(p_root_array == NULL)
	{
		print_log("parse admin json data failed.");
        free(p_buff);
		return;
	}
    free(p_buff);

	for(i=0;i<cJSON_GetArraySize(p_root_array);i++)
	{
		p_item = cJSON_GetArrayItem(p_root_array,i);
		p_uname = cJSON_GetObjectItem(p_item,"username")->valuestring;
		if(!strcmp(p_oplog->user_name,p_uname))  //找到了
		{
			if(cJSON_GetObjectItem(p_item,"phonenum") != NULL)  //有可能电话字段不存在
			{
				strcpy(p_oplog->phone_num,cJSON_GetObjectItem(p_item,"phonenum")->valuestring);
			}
			strcpy(p_oplog->user_role,cJSON_GetObjectItem(p_item,"role")->valuestring);
			break; //找到了就退出
		}
	}
    sprintf(p_oplog->time_stamp,"%d",time(NULL));
	cJSON_Delete(p_root_array);
}

static time_t string_to_timestamp(const char* str)
{
   struct tm tm_time = {0};
   if(NULL == str)
   {
      return 0;
   }
	
    // 将字符串形式的时间转换为tm结构体
    sscanf(str, "%d-%d-%d %d:%d:%d", &tm_time.tm_year, &tm_time.tm_mon, &tm_time.tm_mday, 
           &tm_time.tm_hour, &tm_time.tm_min, &tm_time.tm_sec);
    // 调整年份和月份
    if(tm_time.tm_year >= 1900)
    {
       tm_time.tm_year -= 1900; // 年份从1900年开始
    }
   if(tm_time.tm_mon >= 1)
   {
      tm_time.tm_mon -= 1; // 月份从0开始
   }
    // 将tm结构体转换为UNIX时间戳
    time_t unix_time = mktime(&tm_time) - 8 * 60 * 60;
    return unix_time;
}

/**
 * @brief   从数据库读取所有操作日志内容
 * @param   [in] p_nc 表示http连接指针
 * @param   [in] p_msg 表示http连接的请求体内容
 * @return  无
 */
static int32_t sqlite_db_select(oplog_filter_t filter_para, void *p_data, uint32_t *p_data_num, uint32_t *p_total_num)
{
	sqlite3_stmt *stmt = NULL;
    char *err_msg = 0;
	int32_t rc = 0;
    sqlite3 *db = NULL;
	int total_num = 0;
	char sql[256] = {0};
    uint8_t sql_len = 0;
    uint8_t filter_flag = 0;
    uint32_t year = 0;
    uint32_t month = 0;
    uint32_t day = 0;

	operation_log_t *p_item = NULL;
	p_item = (operation_log_t *)p_data;

	rc = sdk_fs_access((const int8_t *)OPERATION_DB_PATH, F_OK);
    if (rc == -1)  // 文件夹不存在，创建该文件夹
    {
		return(-1);
	}

    rc = sqlite3_open(OPERATION_DB_PATH , &db);
    if( rc ) 
    {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return(-1);
    }	
	
	// 查询
    // 根据过滤条件拼接字符串
   // snprintf(sql, 256, "SELECT ID, USERNAME, PHONENUM, USERROLE, OPTYPE, DEVSN, PARAM1, PARAM2, OPSTATUS, strftime('%%s', TIME) FROM Operation ");
    snprintf(sql, 256, "SELECT ID, USERNAME, PHONENUM, USERROLE, OPTYPE, DEVSN, PARAM1, PARAM2, OPSTATUS, TIME FROM Operation ");
    sql_len = strlen(sql);
    if(strcmp(filter_para.user_name,"all"))  //如果是all，表示不过滤
    {
        snprintf(sql + sql_len, 256 - sql_len, "WHERE USERNAME LIKE '%s' ", filter_para.user_name);
        sql_len = strlen(sql);
        filter_flag = 1;
    }
    if(strcmp(filter_para.op_type,"all"))  //如果是all，表示不过滤
    {
        if(filter_flag)
        {
            snprintf(sql + sql_len, 256 - sql_len, "AND OPTYPE LIKE '%s' ", filter_para.op_type);
            sql_len = strlen(sql);
        }
        else
        {
            snprintf(sql + sql_len, 256 - sql_len, "WHERE OPTYPE LIKE '%s' ", filter_para.op_type);
            sql_len = strlen(sql);
            filter_flag = 1;
        }
    }
    if(strcmp(filter_para.user_role,"all"))  //如果是all，表示不过滤
    {
        if(filter_flag)
        {
            snprintf(sql + sql_len, 256 - sql_len, "AND USERROLE LIKE '%s' ", filter_para.user_role);
            sql_len = strlen(sql);
        }
        else
        {
            snprintf(sql + sql_len, 256 - sql_len, "WHERE USERROLE LIKE '%s' ", filter_para.user_role);
            sql_len = strlen(sql);
            filter_flag = 1;
        }
    }
    if(strcmp(filter_para.op_status,"all"))  //如果是all，表示不过滤
    {
        if(filter_flag)
        {
            snprintf(sql + sql_len, 256 - sql_len, "AND OPSTATUS LIKE '%s' ", filter_para.op_status);
            sql_len = strlen(sql);
        }
        else
        {
            snprintf(sql + sql_len, 256 - sql_len, "WHERE OPSTATUS LIKE '%s' ", filter_para.op_status);
            sql_len = strlen(sql);
            filter_flag = 1;
        }
    }
    if(strcmp(filter_para.time_stamp,"all"))  //如果是all，表示不过滤
    {
        sscanf(filter_para.time_stamp,"%d-%d-%d", &year, &month, &day);
        if(filter_flag)
        {
            snprintf(sql + sql_len, 256 - sql_len, "AND date(TIME) = date( '%04d-%02d-%02d' ) ", year , month, day);
            sql_len = strlen(sql);
        }
        else
        {
            snprintf(sql + sql_len, 256 - sql_len, "WHERE date(TIME) = date( '%04d-%02d-%02d' ) ", year , month, day);
            sql_len = strlen(sql);
            filter_flag = 1;
        }
    }

	snprintf(sql + sql_len, 256 - sql_len, "ORDER BY TIME DESC");

	rc = sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
	if (rc != SQLITE_OK) 
    {
    	fprintf(stderr, "Failed to fetch data: %s\n", sqlite3_errmsg(db));
    	sqlite3_close(db);
    	return -1;
	}

	while (sqlite3_step(stmt) == SQLITE_ROW)
	{
        strcpy(p_item[total_num].user_name, sqlite3_column_text(stmt, 1));
        strcpy(p_item[total_num].phone_num, sqlite3_column_text(stmt, 2));
        strcpy(p_item[total_num].user_role, sqlite3_column_text(stmt, 3));
        strcpy(p_item[total_num].op_type, sqlite3_column_text(stmt, 4));
        strcpy(p_item[total_num].dev_sn, sqlite3_column_text(stmt, 5));
        p_item[total_num].op_param1 = sqlite3_column_double(stmt, 6);
		p_item[total_num].op_param2 = sqlite3_column_double(stmt,7);
        strcpy(p_item[total_num].op_status, sqlite3_column_text(stmt, 8));
        strcpy(p_item[total_num].time_stamp, sqlite3_column_text(stmt, 9));
		total_num ++;
	}
	*p_total_num = total_num;
	
	sqlite3_finalize(stmt);
	sqlite3_close(db);
	
	return 1;
}


/**
 * @brief   获取操作日志
 * @param   [in] p_nc 表示http连接指针
 * @param   [in] p_msg 表示http连接的请求体内容
 * @return  无
 */
void get_operation_log(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_root = NULL;
    cJSON *p_resp_array = NULL;
    cJSON *p_resp_item = NULL;
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t request_body[1024];
    uint8_t response[64]; 
    uint16_t page_index;  //要第几页数据
    uint8_t items_perpage;  //每页有多少条数据
    oplog_filter_t op_filter;  //数据过滤结构体
    uint8_t *p_filter_item = NULL;
    operation_log_t *p_item = NULL;
    uint32_t data_num = 0;
	uint32_t total_num = 0;
    uint16_t total_pages = 0;
	uint16_t acl_total  = 0; //过滤之后有多少条
    uint32_t i;
    int32_t index;
    double param[2];
    uint8_t time_stamp[16] = {0};
    int32_t ret = 0;
    uint8_t dev_sn[DEVICE_SN_LEN + 1] = {0};
    constant_parameter_data_t *p_constant_data = sdk_shm_constant_parameter_data_get(); // 定值/参数
 
    memset(dev_sn, 0, DEVICE_SN_LEN + 1);
    memcpy(dev_sn, p_constant_data->device_sn, DEVICE_SN_LEN);

    memset(request_body,0,sizeof(request_body));
    memcpy(request_body,p_msg->body.p,p_msg->body.len);	
    //解析请求体
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log((int8_t *)"parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

    //根据前端协议,此处请求的action必须为getOperationLog
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getOperationLog"))
	{
		print_log((int8_t *)"action is not right.");
		build_empty_response(response,203,"action is not right");
        cJSON_Delete(p_request);
		http_back(p_nc,response);
		return;
	}

    //需要那一页数据
    page_index = cJSON_GetObjectItem(p_request,"pageIndex")->valueint;

    //每一页多少数据
    items_perpage = cJSON_GetObjectItem(p_request,"itemsPerPage")->valueint;
    
    memset(&op_filter,0,sizeof(oplog_filter_t));
    //前端根据用户名过滤
    p_filter_item = cJSON_GetObjectItem(p_request,"aclUserName")->valuestring;
    strncpy((char *)op_filter.user_name,p_filter_item,strlen(p_filter_item));

    //前端根据操作类型过滤,操作类型目前需要搜集,或者支持前端输入,不再以下拉框的形式
    int id = atoi(cJSON_GetObjectItem(p_request,"aclAction")->valuestring);
    p_filter_item = get_operation_name_by_id(id);
    if(p_filter_item == NULL)
    {
        strcpy(op_filter.op_type,"all");
    }
    else
    {
        strncpy((char *)op_filter.op_type,p_filter_item,strlen(p_filter_item));
    }

    //前端根据角色过滤
    p_filter_item = cJSON_GetObjectItem(p_request,"aclRole")->valuestring;
    strncpy((char *)op_filter.user_role,p_filter_item,strlen(p_filter_item));

    //前端根据操作结果过滤,成功或者失败
    p_filter_item = cJSON_GetObjectItem(p_request,"aclStatus")->valuestring;
    strncpy((char *)op_filter.op_status,p_filter_item,strlen(p_filter_item));

    //前端根据日期,需要哪一天的数据
    p_filter_item = cJSON_GetObjectItem(p_request,"aclYmd")->valuestring;
    strncpy((char *)op_filter.time_stamp,p_filter_item,strlen(p_filter_item));

    //释放前端请求json指针
    cJSON_Delete(p_request);

    // 数据
	p_item = (operation_log_t *)malloc(MAX_OPERATION_ITEMS * sizeof(operation_log_t));
	if(p_item == NULL)
	{
		print_log((int8_t *)"malloc failed");
		return;
	}

	ret = sqlite_db_select(op_filter, (void *)p_item, &data_num, &total_num);
	if (ret < 0)
	{
		print_log((int8_t *)"operation log get failed, ret = %d", ret);
		free(p_item);
		return;
	}

	acl_total = (uint16_t)total_num;
	if ((total_num % items_perpage) == 0)
	{
		total_pages = (uint16_t)(total_num / items_perpage);
	}
	else
	{
		total_pages = (uint16_t)((total_num / items_perpage) + 1);
	}

    if(total_num == 0)
    {
		data_num = 0;
    }
	else if ((page_index < total_pages) || !(total_num % items_perpage))
	{
		data_num = items_perpage;
	}
    else
    {
		data_num = total_num % items_perpage;
	}

	p_resp_array = cJSON_CreateArray();
	if(p_resp_array == NULL)
	{
		print_log("create json array failed");
        free(p_item);
		return;
	}

    for(i = 0; i < data_num; i++)
    {
        p_resp_item = cJSON_CreateObject();
        if(p_resp_item == NULL)
        {
            print_log("create json obj failed");
            cJSON_Delete(p_resp_array); 
            free(p_item);
            return;
        }
        index =((page_index - 1) * items_perpage) + i;
        cJSON_AddStringToObject(p_resp_item,"userName",p_item[index].user_name);
        if(!strcmp(p_item[index].phone_num, "未知"))
        {
            cJSON_AddStringToObject(p_resp_item, "phoneNum", "-");
        }
        else
        {
            cJSON_AddStringToObject(p_resp_item, "phoneNum", p_item[index].phone_num);
        }
       /*约定0表示运维人员,1表示终端用户*/
        if(!strcmp(p_item[index].user_role, "operator"))
        {
            cJSON_AddNumberToObject(p_resp_item,"userRole", 0);
        }
        else
        {
            cJSON_AddNumberToObject(p_resp_item,"userRole", 1);
        }
        /*对操作类型进行转换*/
        cJSON_AddNumberToObject(p_resp_item,"opType", get_operationid_by_name(p_item[index].op_type));
        /*设备SN号*/
        cJSON_AddStringToObject(p_resp_item,"devSN",dev_sn);
        param[0] = p_item[index].op_param1;
        param[1] = p_item[index].op_param2;
        cJSON_AddItemToObject(p_resp_item,"opParam",cJSON_CreateDoubleArray(param,2));
        cJSON_AddStringToObject(p_resp_item,"status",p_item[index].op_status);
        cJSON_AddStringToObject(p_resp_item,"timestamp",p_item[index].time_stamp);
        cJSON_AddItemToArray(p_resp_array,p_resp_item);
    }
	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		print_log("create json obj failed");
		cJSON_Delete(p_resp_array);
        free(p_item);
        return;
	}

    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddNumberToObject(p_resp_root,"totalPage",total_pages);
    cJSON_AddNumberToObject(p_resp_root,"totalItems",acl_total);
    cJSON_AddItemToObject(p_resp_root,"data",p_resp_array);
    cJSON_AddStringToObject(p_resp_root,"msg","get operation log successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_resp_root);
    //将生成的请求包发送到前端
    http_back(p_nc,p);

    //释放
	free(p);
	free(p_item);
}



/**
 * @brief  操作日志配置初始化
 * @param  
 * @param  
 * @return
 */
void operation_log_conf_init(void)
{
	int32_t ret = 0;
	
    // 文件夹不存在，若不存在则创建该文件夹
	ret = sdk_fs_access((const int8_t *)PATH_HISTORY_EVENT_RECOND_FOLDER, F_OK);
    if (ret == -1)          
    {
        print_log("\n [%s:%d] /user/data/event/ Folder does not exist!!! \n", __func__, __LINE__);
        ret = sdk_fs_mkdir((const char *)PATH_HISTORY_EVENT_RECOND_FOLDER, 755);
        if (ret < 0)
        {
            print_log((int8_t *)"\n [%s:%d] sdk_fs_mkdir fail, ret = %d \n", __func__, __LINE__, ret);
        }
    }	
    //判断文件是否存在,如果文件不存在就进行创建
	ret = sdk_fs_access((const int8_t *)OPERATION_DB_PATH, F_OK);
    if (ret == -1)
    {
		op_log_sqlite_db_create_table();
    }    
}


/**
 * @brief  	首页页面获取要显示的最新的5条操作日志数据
 * @param  	[out] p_data        操作日志的数据指针
 * @param  	[out] p_data_num    实际获取到操作日志的条数
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t home_page_operation_log_latest_5_item_get(void *p_data, uint32_t *p_data_num)
{
	sqlite3_stmt *stmt = NULL;
    char *err_msg = NULL;
	int32_t rc = 0;
    sqlite3 *db = NULL;
	int total_num = 0;
	uint8_t sql[256] = {0};
	
	operation_log_t *p_item = NULL;
	p_item = (operation_log_t *)p_data;

	rc = sdk_fs_access((const int8_t *)OPERATION_DB_PATH, F_OK);
    if (rc == -1)  // 文件夹不存在，创建该文件夹
    {
		return(-1);
	}	
    rc = sqlite3_open(OPERATION_DB_PATH, &db);
    if(rc) 
    {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return(-1);
    }	
	
    snprintf(sql, 256, "SELECT ID, USERNAME, PHONENUM, USERROLE, OPTYPE, DEVSN, PARAM1, PARAM2, OPSTATUS, TIME FROM Operation ORDER BY TIME DESC LIMIT 5;");
    // snprintf(sql, 256, "SELECT * FROM Operation ORDER BY TIME DESC LIMIT 5;");
	rc = sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
	if (rc != SQLITE_OK) 
    {
    	fprintf(stderr, "Failed to fetch data: %s\n", sqlite3_errmsg(db));
    	sqlite3_close(db);
    	return -1;
	}

	while (sqlite3_step(stmt) == SQLITE_ROW)
	{
        strcpy(p_item[total_num].user_name, sqlite3_column_text(stmt, 1));
        strcpy(p_item[total_num].phone_num, sqlite3_column_text(stmt, 2));
        strcpy(p_item[total_num].user_role, sqlite3_column_text(stmt, 3));
        strcpy(p_item[total_num].op_type, sqlite3_column_text(stmt, 4));
        strcpy(p_item[total_num].dev_sn, sqlite3_column_text(stmt, 5));
        p_item[total_num].op_param1 = sqlite3_column_double(stmt, 6);
		p_item[total_num].op_param2 = sqlite3_column_double(stmt,7);
        strcpy(p_item[total_num].op_status, sqlite3_column_text(stmt, 8));
        strcpy(p_item[total_num].time_stamp, sqlite3_column_text(stmt, 9));
		total_num ++;
	}
	*p_data_num = total_num;
	
	sqlite3_finalize(stmt);
	sqlite3_close(db);
	
	return 1;
}


/**
 * @brief  	读取操作日志文件至导出
 * @param  	[in] p_operation_time：过滤时间参数
 * @param  	[out] p_data：日志
 * @param  	[out] p_total_num：数量
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
static int32_t read_operation_log2export(operation_records_time_t *p_operation_time, void *p_data, uint32_t *p_total_num)
{
	sqlite3_stmt *stmt = NULL;
    char *err_msg = NULL;
	int32_t rc = 0;
    sqlite3 *db = NULL;
	uint8_t sql[512] = {0};
    int total_num = 0;
    operation_log_t *p_item = NULL;
    int32_t ret = 0;

    rc = sqlite3_open(OPERATION_DB_PATH, &db);
    if( rc ) 
    {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return 0;
    }	

    snprintf(sql,256,"SELECT USERNAME, PHONENUM, USERROLE, OPTYPE, DEVSN, PARAM1, PARAM2, OPSTATUS, TIME "
            "FROM Operation "
            "WHERE date(TIME) BETWEEN date('%s') AND date('%s') "
            "ORDER BY TIME DESC;", p_operation_time->start_time, p_operation_time->end_time);

	rc = sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
	if (rc != SQLITE_OK) 
    {
		fprintf(stderr, "Failed to fetch data: %s\n", sqlite3_errmsg(db));
		sqlite3_close(db);
		return 0;
	}
    p_item = (operation_log_t *)p_data;
	// 遍历结果集
	while (sqlite3_step(stmt) == SQLITE_ROW) 
    {
        strcpy(p_item[total_num].user_name, sqlite3_column_text(stmt, 0));
        strcpy(p_item[total_num].phone_num, sqlite3_column_text(stmt, 1));
        strcpy(p_item[total_num].user_role, sqlite3_column_text(stmt, 2));
        strcpy(p_item[total_num].op_type, sqlite3_column_text(stmt, 3));
        strcpy(p_item[total_num].dev_sn, sqlite3_column_text(stmt, 4));
        p_item[total_num].op_param1 = sqlite3_column_double(stmt, 5);
		p_item[total_num].op_param2 = sqlite3_column_double(stmt,6);
        strcpy(p_item[total_num].op_status, sqlite3_column_text(stmt, 7));
        strcpy(p_item[total_num].time_stamp, sqlite3_column_text(stmt, 8));
		total_num ++;
	}
    *p_total_num = total_num;

	sqlite3_finalize(stmt);
	sqlite3_close(db);

	return(1);
}



 /**
   * @brief  获取 记录
   * @param  [in] *p_nc 连接信息 
   * @param  [in] *p_msg  http请求信息
   * @return
   */
void export_operation_List(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
    cJSON *p_resp_array = NULL;
    cJSON *p_resp_item = NULL;
	uint8_t *p_action = NULL;
	uint8_t *p = NULL;
    double param[2] = {0};
    uint8_t response[256] = {0};
	uint8_t request_body[1024] = {0};
	int32_t year = 0, mon = 0, day = 0;
    int32_t ret = 0;
	operation_records_time_t operation_time = {0};
    operation_log_t *p_item = NULL;
	uint32_t total_num = 0;
    constant_parameter_data_t *p_constant_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

	memcpy(request_body,p_msg->body.p,p_msg->body.len);	
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		print_log((int8_t *)"parse request failed.");
		build_empty_response(response,203,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	if(NULL == cJSON_GetObjectItem(p_request,"action"))
	{
        print_log((int8_t *)"action is NULL");
        build_empty_response(response,202,"action is NULL");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
	}
	 
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getOperationList"))
	{
        print_log((int8_t *)"action is not right.");
        build_empty_response(response,202,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
	}
	
	if ((NULL == cJSON_GetObjectItem(p_request,"timestart")) || (NULL == cJSON_GetObjectItem(p_request,"timeend")))
	{
		print_log((int8_t *)"start/end time not right.");
        build_empty_response(response,202,"start/end time not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
	}

	sscanf(cJSON_GetObjectItem(p_request,"timestart")->valuestring,"%d-%d-%d",&year,&mon,&day);
	snprintf((char*)operation_time.start_time, 32, "%04d-%02d-%02d",year,mon,day);
	
	sscanf(cJSON_GetObjectItem(p_request,"timeend")->valuestring,"%d-%d-%d",&year,&mon,&day);
	snprintf((char*)operation_time.end_time, 32, "%04d-%02d-%02d",year,mon,day);
	print_log((int8_t *)"start %s end %s \n",operation_time.start_time, operation_time.end_time);
	cJSON_Delete(p_request);

    // 数据
	p_item = (operation_log_t *)malloc(MAX_OPERATION_ITEMS * sizeof(operation_log_t));
	if(p_item == NULL)
	{
		print_log((int8_t *)"malloc failed");
		return;
	}

	ret = read_operation_log2export(&operation_time, p_item, &total_num);
	if (ret)
	{
        p_resp_array = cJSON_CreateArray();
        if(p_resp_array == NULL)
        {
            print_log("create json array failed");
            free(p_item);
            return;
        }
        for(uint32_t i = 0; i < total_num; i++)
        {
            p_resp_item = cJSON_CreateObject();
            if(p_resp_item == NULL)
            {
                print_log("create json obj failed");
                cJSON_Delete(p_resp_array); 
                free(p_item);
                return;
            }
            cJSON_AddStringToObject(p_resp_item,"Name",p_item[i].user_name);
            if(!strcmp(p_item[i].user_role, "operator"))
            {
                cJSON_AddNumberToObject(p_resp_item,"Role", 0);
            }
            else
            {
                cJSON_AddNumberToObject(p_resp_item,"Role", 1);
            }
            cJSON_AddNumberToObject(p_resp_item,"ID", get_operationid_by_name(p_item[i].op_type));
            param[0] = p_item[i].op_param1;
            param[1] = p_item[i].op_param2;
            cJSON_AddItemToObject(p_resp_item,"Param",cJSON_CreateDoubleArray(param,2));
            if(!strcmp(p_item[i].op_status, "success"))
            {
                cJSON_AddNumberToObject(p_resp_item,"status", 1);
            }
            else
            {
                cJSON_AddNumberToObject(p_resp_item,"status", 0);
            }
            cJSON_AddStringToObject(p_resp_item,"tm",p_item[i].time_stamp);
            cJSON_AddItemToArray(p_resp_array,p_resp_item);
        }
	}

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
        print_log("create json obj failed");
        cJSON_Delete(p_resp_array);
        free(p_item);
        return;
	}

    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddStringToObject(p_resp_root,"devSN",(char *)p_constant_data->device_sn);
    cJSON_AddItemToObject(p_resp_root,"data",p_resp_array);
    cJSON_AddStringToObject(p_resp_root,"msg","get operation log successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_resp_root);
    //将生成的请求包发送到前端
    http_back(p_nc,p);

    //释放
	free(p);
	free(p_item);
}

/**
 * @brief  添加新操作日志
 * @param  [in] p_op_usr_name : 操作用户名称
 * @param  [in] p_op_str      : 操作内容
 * @param  [in] op_success    : 操作结果
 * @param  [in] op_par1       : 原先操作参数数值
 * @param  [in] op_par2       : 现有操作参数数值
 * @return
 */
void usr_add_one_op_log( const char *p_op_usr_name, const char *p_op_str, bool op_success, double op_par1, double op_par2 )
{
    operation_log_t op_log;

    init_user_basic_info( &op_log );
    strcpy( op_log.user_name, p_op_usr_name );
    get_user_basic_info( &op_log );
    strcpy( op_log.op_type, p_op_str );
    strcpy( op_log.op_status, op_success? "success": "fail" );
    op_log.op_param1 = op_par1;
    op_log.op_param2 = op_par2;

    add_one_op_log(&op_log);
}