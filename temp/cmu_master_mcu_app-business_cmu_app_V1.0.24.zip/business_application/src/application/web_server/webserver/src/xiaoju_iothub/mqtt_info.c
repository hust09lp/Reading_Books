#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"cJSON.h"
#include"batteryinfo.h"
#include"common.h"
#include"web_data_interface.h"
#include"sdk_shm.h"
#include "sofar_errors.h"
#include "web_broker.h"


#define MQTT_MONOMER_CHG_LIMIT_VOL_MIN      (3500)
#define MQTT_MONOMER_CHG_LIMIT_VOL_MAX      (3600)
#define MQTT_MONOMER_DISCHG_LIMIT_VOL_MIN   (2600)
#define MQTT_MONOMER_DISCHG_LIMIT_VOL_MAX   (2800)
#define MQTT_SOC_CHARGE_LIMIT_MIM           (800)
#define MQTT_SOC_CHARGE_LIMIT_MAX           (1000)
#define MQTT_SOC_DISCHARGE_LIMIT_MIM        (0)
#define MQTT_SOC_DISCHARGE_LIMIT_MAX        (200)


void mqtt_get_bms_pcs_info(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
    uint8_t response[64];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    bms_data_t bms_data = {0};
    pcs_data_t pcs_data = {0};

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getUploadData"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

    mqtt_info_get(&bms_data, &pcs_data);

    //BMS数据
    cJSON *bms_item = cJSON_CreateObject();
    if(bms_item == NULL)
    {
        print_log("create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(bms_item,"batteryType",bms_data.battery_type);
    cJSON_AddNumberToObject(bms_item,"chargeStatus",bms_data.charge_status);
    cJSON_AddNumberToObject(bms_item,"chargeCurrMax",bms_data.charge_curr_max);
    cJSON_AddNumberToObject(bms_item,"dischargeCurrMax",bms_data.discharge_curr_max);
    cJSON_AddNumberToObject(bms_item,"voltage",bms_data.voltage);
    cJSON_AddNumberToObject(bms_item,"current",bms_data.current);
    cJSON_AddNumberToObject(bms_item,"power",bms_data.power);
    cJSON_AddNumberToObject(bms_item,"soc",bms_data.soc);
    cJSON_AddNumberToObject(bms_item,"soh",bms_data.soh);
    cJSON_AddNumberToObject(bms_item,"monomerVmin",bms_data.monomer_vmin);
    cJSON_AddNumberToObject(bms_item,"monomerVminIndex",bms_data.monomer_vmin_index);
    cJSON_AddNumberToObject(bms_item,"monomerVmax",bms_data.monomer_vmax);
    cJSON_AddNumberToObject(bms_item,"monomerVmaxIndex",bms_data.monomer_vmax_index);
    cJSON_AddNumberToObject(bms_item,"monomerTmin",bms_data.monomer_tmin);
    cJSON_AddNumberToObject(bms_item,"monomerTminIndex",bms_data.monomer_tmin_index);
    cJSON_AddNumberToObject(bms_item,"monomerTmax",bms_data.monomer_tmax);
    cJSON_AddNumberToObject(bms_item,"monomerTmaxIndex",bms_data.monomer_tmax_index);
    cJSON_AddNumberToObject(bms_item,"totalDischarge",bms_data.total_discharge);
    cJSON_AddNumberToObject(bms_item,"totalcharge",bms_data.total_charge);
    cJSON_AddNumberToObject(bms_item,"dayDischarge",bms_data.day_discharge);
    cJSON_AddNumberToObject(bms_item,"daycharge",bms_data.day_charge);
    cJSON_AddNumberToObject(bms_item,"packNum",bms_data.pack_num);
    cJSON_AddNumberToObject(bms_item,"monomerNum",bms_data.monomer_num);
    cJSON_AddNumberToObject(bms_item,"packTpointNum",bms_data.pack_tpoint_num);

    cJSON_AddItemToObject(bms_item,"packVolt",cJSON_CreateIntArray(bms_data.pack_volt, bms_data.pack_num));
    cJSON_AddItemToObject(bms_item,"packCurr",cJSON_CreateIntArray(bms_data.pack_curr, bms_data.pack_num));
    cJSON_AddItemToObject(bms_item,"packPower",cJSON_CreateIntArray(bms_data.pack_power , bms_data.pack_num));
    cJSON_AddItemToObject(bms_item,"monomerVolt",cJSON_CreateIntArray(bms_data.monomer_volt, bms_data.pack_num * MONOMER_NUMBER_IN_PACK));
    cJSON_AddItemToObject(bms_item,"monomerTemp",cJSON_CreateIntArray(bms_data.monomer_temp, bms_data.pack_num * MONOMER_NUMBER_IN_PACK));
    
    //PCS数据
    cJSON *pcs_item = cJSON_CreateObject();
    if(pcs_item == NULL)
    {
        print_log("create json obj failed");
        cJSON_Delete(bms_item);
        return;
    }

    cJSON_AddNumberToObject(pcs_item,"PCSStatus",pcs_data.pcs_status);
    cJSON_AddNumberToObject(pcs_item,"chargeStatus",pcs_data.charge_status);
    cJSON_AddNumberToObject(pcs_item,"temp",pcs_data.temp);
    cJSON_AddNumberToObject(pcs_item,"gridPower",pcs_data.grid_power);
    cJSON_AddNumberToObject(pcs_item,"loadPower",pcs_data.load_power);
    cJSON_AddNumberToObject(pcs_item,"dcPower",pcs_data.dc_power);
    cJSON_AddNumberToObject(pcs_item,"acPower",pcs_data.ac_power);
    cJSON_AddNumberToObject(pcs_item,"gridSuEnergy",pcs_data.grid_su_energy);
    cJSON_AddNumberToObject(pcs_item,"getGridEnergy",pcs_data.get_grid_energy);
    cJSON_AddNumberToObject(pcs_item,"loadUseEnergy",pcs_data.load_use_energy);
    cJSON_AddNumberToObject(pcs_item,"gridVoltR",pcs_data.grid_volt_r);
    cJSON_AddNumberToObject(pcs_item,"gridCurrentR",pcs_data.grid_current_r);
    cJSON_AddNumberToObject(pcs_item,"gridFreqR",pcs_data.grid_freq_r);
    cJSON_AddNumberToObject(pcs_item,"gridVoltS",pcs_data.grid_volt_s);
    cJSON_AddNumberToObject(pcs_item,"gridCurrentS",pcs_data.grid_current_s);
    cJSON_AddNumberToObject(pcs_item,"gridFreqS",pcs_data.grid_freq_s);
    cJSON_AddNumberToObject(pcs_item,"gridVoltT",pcs_data.grid_volt_t);
    cJSON_AddNumberToObject(pcs_item,"gridCurrentT",pcs_data.grid_current_t);
    cJSON_AddNumberToObject(pcs_item,"gridFreqT",pcs_data.grid_freq_t);
    cJSON_AddNumberToObject(pcs_item,"dayRunTime",pcs_data.day_run_time);
    cJSON_AddNumberToObject(pcs_item,"totalRunTime",pcs_data.total_run_time);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        cJSON_Delete(bms_item);
        cJSON_Delete(pcs_item);
        return;
    }
    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddItemToObject(p_resp_root,"BMS",bms_item);
    cJSON_AddItemToObject(p_resp_root,"PCS",pcs_item);
    cJSON_AddStringToObject(p_resp_root,"msg","get info successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_resp_root);

    http_back(p_nc,p);
    free(p);
}


void char_bit_set(uint32_t *p_value, uint8_t pos, uint8_t byte, uint8_t byte_pos)
{
    if((byte >> byte_pos) & 0x01)
    {
        *p_value |= (1 << pos);
    }
}

void short_bit_set(uint32_t *p_value, uint8_t pos, uint16_t byte, uint8_t byte_pos)
{
    if((byte >> byte_pos) & 0x0001)
    {
        *p_value |= (1 << pos);
    }
}

/**
 * @brief   获取BMS一级告警
 * @param   
 * @return  故障数据，按照bit位填充
 * @note
 */
static uint32_t bms_warn_level_1_get(void)
{
    uint32_t bms_warn = 0;
    uint8_t *p_warn = NULL;
    uint8_t pos = 0;

    //对照小桔协议对需要的告警点位进行提取
    p_warn = sdk_shm_telematic_data_get()->battery_cluster_telematic_info[0].battery_cluster_warn_info;

    char_bit_set(&bms_warn, pos++, p_warn[0], 1);        //总压过压
    char_bit_set(&bms_warn, pos++, p_warn[0], 0);        //总压欠压
    char_bit_set(&bms_warn, pos++, p_warn[1], 0);        //放电过流
    char_bit_set(&bms_warn, pos++, p_warn[0], 5);        //充电过流
    char_bit_set(&bms_warn, pos++, p_warn[1], 5);        //单体欠压
    char_bit_set(&bms_warn, pos++, p_warn[1], 6);        //压差过大
    char_bit_set(&bms_warn, pos, p_warn[1], 7);          //温度过高
    char_bit_set(&bms_warn, pos++, p_warn[2], 1);
    char_bit_set(&bms_warn, pos, p_warn[2], 0);          //温度过低
    char_bit_set(&bms_warn, pos++, p_warn[2], 2);
    char_bit_set(&bms_warn, pos++, p_warn[2], 3);        //温差过大
    char_bit_set(&bms_warn, pos++, p_warn[1], 2);        //SOC过低
    char_bit_set(&bms_warn, pos++, p_warn[1], 1);        //绝缘过低

    return bms_warn;
}

/**
 * @brief   获取BMS二级告警
 * @param   
 * @return  故障数据，按照bit位填充
 * @note
 */
static uint32_t bms_warn_level_2_get(void)
{
    uint32_t bms_warn = 0;
    uint8_t *p_warn = NULL;
    uint8_t pos = 0;

    //对照小桔协议对需要的告警点位进行提取
    p_warn = sdk_shm_telematic_data_get()->battery_cluster_telematic_info[0].battery_cluster_warn_info;

    char_bit_set(&bms_warn, pos++, p_warn[3], 1);        //总压过压
    char_bit_set(&bms_warn, pos++, p_warn[3], 0);        //总压欠压
    char_bit_set(&bms_warn, pos++, p_warn[4], 0);        //放电过流
    char_bit_set(&bms_warn, pos++, p_warn[3], 5);        //充电过流
    char_bit_set(&bms_warn, pos++, p_warn[4], 5);        //单体欠压
    char_bit_set(&bms_warn, pos++, p_warn[4], 6);        //压差过大
    char_bit_set(&bms_warn, pos, p_warn[4], 7);          //温度过高
    char_bit_set(&bms_warn, pos++, p_warn[5], 1); 
    char_bit_set(&bms_warn, pos, p_warn[5], 0);          //温度过低
    char_bit_set(&bms_warn, pos++, p_warn[5], 2);
    char_bit_set(&bms_warn, pos++, p_warn[5], 3);        //温差过大
    char_bit_set(&bms_warn, pos++, p_warn[4], 2);        //SOC过低
    char_bit_set(&bms_warn, pos++, p_warn[4], 1);        //绝缘过低

    return bms_warn;
}


/**
 * @brief   获取BMS三级告警
 * @param   
 * @return  故障数据，按照bit位填充
 * @note
 */
static uint32_t bms_warn_level_3_get(void)
{
    uint32_t bms_warn = 0;
    uint8_t *p_warn = NULL;
    uint8_t *p_fault = NULL;
    uint8_t pos = 0;
    uint8_t byte = 0;

    //对照小桔协议对需要的告警点位进行提取
    p_warn = sdk_shm_telematic_data_get()->battery_cluster_telematic_info[0].battery_cluster_warn_info;
    p_fault = sdk_shm_telematic_data_get()->battery_cluster_telematic_info[0].battery_cluster_fault_info;

    char_bit_set(&bms_warn, pos++, p_warn[6], 1);        //总压过压
    char_bit_set(&bms_warn, pos++, p_warn[6], 0);        //总压欠压
    char_bit_set(&bms_warn, pos++, p_warn[7], 0);        //放电过流
    char_bit_set(&bms_warn, pos++, p_warn[6], 5);        //充电过流
    char_bit_set(&bms_warn, pos++, p_warn[7], 5);        //单体欠压
    char_bit_set(&bms_warn, pos++, p_warn[7], 6);        //压差过大
    char_bit_set(&bms_warn, pos, p_warn[7], 7);          //温度过高
    char_bit_set(&bms_warn, pos++, p_warn[8], 1); 
    char_bit_set(&bms_warn, pos, p_warn[8], 0);          //温度过低
    char_bit_set(&bms_warn, pos, p_warn[8], 2); 
    char_bit_set(&bms_warn, pos++, p_warn[8], 3);        //温差过大
    char_bit_set(&bms_warn, pos++, p_warn[7], 2);        //SOC过低
    char_bit_set(&bms_warn, pos++, p_warn[7], 1);        //绝缘过低
    char_bit_set(&bms_warn, pos, p_fault[2], 3);         //电流采样故障
    char_bit_set(&bms_warn, pos++, p_fault[2], 4); 
    char_bit_set(&bms_warn, pos++, 0, 0);                //总压采样故障
    char_bit_set(&bms_warn, pos++, p_fault[1], 1);       //单体电压采样故障
    char_bit_set(&bms_warn, pos++, 0, 0);                //继电器粘连故障
    char_bit_set(&bms_warn, pos++, 0, 0);                //继电器断路故障
    char_bit_set(&bms_warn, pos++, p_fault[1], 0);       //内部通信故障

    for(uint8_t i = 0; i < BATTERY_CLUSTER_FAULT_LEN_BYTE; i++)
    {
        for(uint8_t j = 0; j < 8; j++)
        {
            if(((i == 1) && ((j == 0) || (j == 1))) || ((i == 2) && ((j == 3) || (j == 4))))
            {
                continue;
            }
            if((p_fault[i] >> j) & 0x01)
            {
                byte = 0x01;
                break;
            }
        }
    }
    char_bit_set(&bms_warn, pos++, byte, 0);         //其他类储能柜故障

    return bms_warn;
}


/**
 * @brief   获取PCS三级告警
 * @param   
 * @return  故障数据，按照bit位填充
 * @note
 */
static uint32_t pcs_warn_level_3_get(void)
{
    uint32_t pcs_warn = 0;
    uint16_t fault = 0;
    uint8_t pos = 0;
    uint8_t byte = 0;

    //对照小桔协议对需要的告警点位进行提取
    fault = sdk_shm_telematic_data_get()->pcs_module[0].grid_fault.val;

    short_bit_set(&pcs_warn, pos++, fault, 0);          //交流过压
    short_bit_set(&pcs_warn, pos++, fault, 1);          //交流欠压
    short_bit_set(&pcs_warn, pos++, fault, 2);          //交流过频
    short_bit_set(&pcs_warn, pos++, fault, 3);          //交流欠频
    short_bit_set(&pcs_warn, pos++, 0, 0);              //电网电压不平衡

    fault = sdk_shm_telematic_data_get()->pcs_module[0].supplement_fault.val;
    short_bit_set(&pcs_warn, pos++, fault, 0);          //电网反序

    fault = sdk_shm_telematic_data_get()->pcs_module[0].grid_fault.val;
    short_bit_set(&pcs_warn, pos++, fault, 7);          //孤岛
    short_bit_set(&pcs_warn, pos++, 0, 0);              //并离网切换异常

    fault = sdk_shm_telematic_data_get()->pcs_module[0].supplement_fault.val;
    short_bit_set(&pcs_warn, pos++, fault, 1);          //输出接地故障

    fault = sdk_shm_telematic_data_get()->pcs_module[0].temperature_fault.val;
    short_bit_set(&pcs_warn, pos, fault, 7);            //内部过温
    short_bit_set(&pcs_warn, pos, fault, 8); 
    fault = sdk_shm_telematic_data_get()->pcs_module[0].supplement_fault.val;
    short_bit_set(&pcs_warn, pos++, fault, 5); 

    fault = sdk_shm_telematic_data_get()->pcs_module[0].supplement_fault.val;
    short_bit_set(&pcs_warn, pos, fault, 10);            //can通信故障
    fault = sdk_shm_telematic_data_get()->pcs_module[0].fault13.val;
    short_bit_set(&pcs_warn, pos++, fault, 0); 


    fault = sdk_shm_telematic_data_get()->pcs_module[0].external_device_fault.val;
    short_bit_set(&pcs_warn, pos, fault, 8);            //风扇故障
    short_bit_set(&pcs_warn, pos++, fault, 9);

    fault = sdk_shm_telematic_data_get()->pcs_module[0].voltage_fault.val;
    short_bit_set(&pcs_warn, pos, fault, 5);            //母线电压高
    short_bit_set(&pcs_warn, pos, fault, 7);
    short_bit_set(&pcs_warn, pos++, fault, 8);
    short_bit_set(&pcs_warn, pos++, fault, 2);          //母线电压低
    short_bit_set(&pcs_warn, pos++, fault, 0);          //母线电压不平衡
    short_bit_set(&pcs_warn, pos++, 0, 0);              //输出电压异常

    fault = sdk_shm_telematic_data_get()->pcs_module[0].current_fault.val;
    short_bit_set(&pcs_warn, pos++, fault, 7);

    fault = sdk_shm_telematic_data_get()->pcs_module[0].temperature_fault.val;
    short_bit_set(&pcs_warn, pos, fault, 10);            //散热器过温
    short_bit_set(&pcs_warn, pos, fault, 11);
    short_bit_set(&pcs_warn, pos, fault, 12);
    short_bit_set(&pcs_warn, pos, fault, 13);
    short_bit_set(&pcs_warn, pos, fault, 14);
    short_bit_set(&pcs_warn, pos++, fault, 15);

    fault = sdk_shm_telematic_data_get()->pcs_module[0].current_fault.val;
    short_bit_set(&pcs_warn, pos, fault, 2);            //变流器过载
    short_bit_set(&pcs_warn, pos, fault, 4);
    fault = sdk_shm_telematic_data_get()->pcs_module[0].hardware_signal_fault.val;
    short_bit_set(&pcs_warn, pos, fault, 3);
    short_bit_set(&pcs_warn, pos++, fault, 6); 

    fault = sdk_shm_telematic_data_get()->pcs_module[0].self_test_fault.val;
    short_bit_set(&pcs_warn, pos, fault, 5);            //变流器启动失败
    fault = sdk_shm_telematic_data_get()->pcs_module[0].supplement_fault.val;
    short_bit_set(&pcs_warn, pos++, fault, 7);     

    //其他故障归于其他类故障
    fault = sdk_shm_telematic_data_get()->pcs_module[0].grid_fault.val;
    short_bit_set(&pcs_warn, pos, fault, 4); 
    short_bit_set(&pcs_warn, pos, fault, 5);   
    short_bit_set(&pcs_warn, pos, fault, 6);  
    short_bit_set(&pcs_warn, pos, fault, 10); 

    fault = sdk_shm_telematic_data_get()->pcs_module[0].sampling_fault.val;
    short_bit_set(&pcs_warn, pos, fault, 0); 
    short_bit_set(&pcs_warn, pos, fault, 1);   
    short_bit_set(&pcs_warn, pos, fault, 3);  
    short_bit_set(&pcs_warn, pos, fault, 5); 
    short_bit_set(&pcs_warn, pos, fault, 13); 

    fault = sdk_shm_telematic_data_get()->pcs_module[0].self_test_fault.val;
    short_bit_set(&pcs_warn, pos, fault, 4); 
    short_bit_set(&pcs_warn, pos, fault, 8);   
    short_bit_set(&pcs_warn, pos, fault, 9);  
    short_bit_set(&pcs_warn, pos, fault, 13); 

    fault = sdk_shm_telematic_data_get()->pcs_module[0].current_fault.val;
    short_bit_set(&pcs_warn, pos, fault, 1); 
    short_bit_set(&pcs_warn, pos, fault, 11);   

    fault = sdk_shm_telematic_data_get()->pcs_module[0].hardware_signal_fault.val;
    short_bit_set(&pcs_warn, pos, fault, 10); 

    fault = sdk_shm_telematic_data_get()->pcs_module[0].supplement_fault.val;
    short_bit_set(&pcs_warn, pos, fault, 2);
    short_bit_set(&pcs_warn, pos, fault, 3);
    short_bit_set(&pcs_warn, pos, fault, 4);
    short_bit_set(&pcs_warn, pos, fault, 6);
    short_bit_set(&pcs_warn, pos, fault, 8);
    short_bit_set(&pcs_warn, pos, fault, 9);
    short_bit_set(&pcs_warn, pos, fault, 11);

    return pcs_warn;
}


/**
 * @brief   获取动环一级告警
 * @param   
 * @return  故障数据，按照bit位填充
 * @note
 */
static uint32_t dy_warn_level_1_get(void)
{
    uint32_t dy_warn = 0;
    uint8_t *p_warn = NULL;
    uint8_t *p_status = NULL;
    uint8_t pos = 0;

    //对照小桔协议对需要的告警点位进行提取
    p_warn = sdk_shm_telematic_data_get()->container_system_warn_info;

    char_bit_set(&dy_warn, pos++, p_warn[13], 1);        //气体传感器超限
    char_bit_set(&dy_warn, pos++, p_warn[10], 7);        //烟雾传感器超限
    char_bit_set(&dy_warn, pos++, 0, 0);                 //火焰传感器超限    
    char_bit_set(&dy_warn, pos++, p_warn[11], 5);        //温度传感器超限
    
    p_status = sdk_shm_telematic_data_get()->container_system_status_info;
    char_bit_set(&dy_warn, pos++, p_status[3], 2);        //声和_或光警报器启动

    return dy_warn;
}


/**
 * @brief   获取动环三级告警
 * @param   
 * @return  故障数据，按照bit位填充
 * @note
 */
static uint32_t dy_warn_level_3_get(void)
{
    uint32_t dy_warn = 0;
    uint8_t *p_fault = NULL;
    uint8_t pos = 0;
    uint8_t byte = 0;

    //对照小桔协议对需要的告警点位进行提取
    p_fault = sdk_shm_telematic_data_get()->container_system_fault_info;

    char_bit_set(&dy_warn, pos++, p_fault[11], 7);        //气体传感器超限
    char_bit_set(&dy_warn, pos++, p_fault[12], 5);        //烟雾传感器超限
    char_bit_set(&dy_warn, pos++, 0, 0);                 //火焰传感器超限    
    char_bit_set(&dy_warn, pos++, p_fault[11], 1);        //温度传感器超限


    for(uint8_t i = 1; i < CONTAINER_SYSTEM_FAULT_LEN_BYTE; i++)
    {
        for(uint8_t j = 0; j < 8; j++)
        {
            if(((i == 11) && ((j == 1) || (j == 7))) || ((i == 12) && (j == 5)))
            {
                continue;
            }
            if((p_fault[i] >> j) & 0x01)
            {
                byte = 0x01;
                break;
            }
        }
    }
    char_bit_set(&dy_warn, 12, byte, 0);         //其他类故障

    return dy_warn;
}


void mqtt_get_event_info(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
    uint8_t response[64];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    bms_data_t bms_data = {0};
    pcs_data_t pcs_data = {0};
    internal_shared_data_t *p_internal_shared_data = NULL;
    
    telemetry_data_t *p_telemetry = sdk_shm_telemetry_data_get();
    p_internal_shared_data = internal_shared_data_get();

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getUploadEvent"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

    mqtt_info_get(&bms_data, &pcs_data);

    //BMS数据
    cJSON *event_item = cJSON_CreateObject();
    if(event_item == NULL)
    {
        print_log("create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(event_item,"chargeStatus",bms_data.charge_status);
    if((bms_data.soc == 1000) && (p_internal_shared_data->battery_charge_disable == 1))
    {
        cJSON_AddNumberToObject(event_item,"batFull",1);
    }
    else
    {
        cJSON_AddNumberToObject(event_item,"batFull",0);
    }

    //一级告警
    cJSON *warn1_item = cJSON_CreateObject();   
    if(warn1_item == NULL)
    {
        print_log("create json obj failed");
        cJSON_Delete(event_item);
        return;
    }
    cJSON_AddNumberToObject(warn1_item,"BMS",bms_warn_level_1_get());
    cJSON_AddNumberToObject(warn1_item,"PCS",0);
    cJSON_AddNumberToObject(warn1_item,"DY",dy_warn_level_1_get());

    //二级告警
    cJSON *warn2_item = cJSON_CreateObject();   
    if(warn2_item == NULL)
    {
        print_log("create json obj failed");
        cJSON_Delete(event_item);
        cJSON_Delete(warn1_item);
        return;
    }
    cJSON_AddNumberToObject(warn2_item,"BMS",bms_warn_level_2_get());
    cJSON_AddNumberToObject(warn2_item,"PCS",0);
    cJSON_AddNumberToObject(warn2_item,"DY",0);

    //三级告警
    cJSON *warn3_item = cJSON_CreateObject();   
    if(warn3_item == NULL)
    {
        print_log("create json obj failed");
        cJSON_Delete(event_item);
        cJSON_Delete(warn1_item);
        cJSON_Delete(warn2_item);
        return;
    }
    cJSON_AddNumberToObject(warn3_item,"BMS",bms_warn_level_3_get());
    cJSON_AddNumberToObject(warn3_item,"PCS",pcs_warn_level_3_get());
    cJSON_AddNumberToObject(warn3_item,"DY",dy_warn_level_3_get());
    
    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        cJSON_Delete(event_item);
        cJSON_Delete(warn1_item);
        cJSON_Delete(warn2_item);
        cJSON_Delete(warn3_item);
        return;
    }
    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddNumberToObject(p_resp_root,"energyCabinetStatus",p_telemetry->cmu_telemetry_info.cmu_sys_state);
    cJSON_AddItemToObject(p_resp_root,"Event",event_item);
    cJSON_AddItemToObject(p_resp_root,"Warn1",warn1_item);
    cJSON_AddItemToObject(p_resp_root,"Warn2",warn2_item);
    cJSON_AddItemToObject(p_resp_root,"Warn3",warn3_item);
    cJSON_AddStringToObject(p_resp_root,"msg","get info successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_resp_root);

    http_back(p_nc,p);
    free(p);
}


void mqtt_set_param_info(struct mg_connection *p_nc,struct http_message *p_msg)
{
    int32_t ret;
    cJSON *p_request;
    cJSON *p_resp_root;
    uint8_t response[64];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    uint32_t value_int = 0;
    uint32_t monomer_charge_limit_volt = 0;
    uint32_t monomer_discharge_limit_volt = 0;
    int16_t soc_charge_limit = 0;                       // SOC充电上限
    int16_t soc_discharge_limit = 0;                    // SOC放电下限
    int32_t  chg_data_valid = SF_ERR_PARA;
    int32_t  dischg_data_valid = SF_ERR_PARA;
    int32_t  soc_charge_limit_data_valid = SF_ERR_PARA;
    int32_t  soc_discharge_limit_data_valid = SF_ERR_PARA;
    uint8_t soc_limit_changed_flag = 0;
    battery_parameter_data_t param_info;
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数
    web_control_info_t *p_web_data = shm_web_control_info_get();
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();   // 遥信数据

	if(NULL == p_web_data)
	{
		return;
	}

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"paramSet"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
	if ((NULL == cJSON_GetObjectItem(p_request,"monomerChargeLimitVolt")) && \
        (NULL == cJSON_GetObjectItem(p_request,"monomerDischargeLimitVolt")) && \
        (NULL == cJSON_GetObjectItem(p_request,"chargeLimitSoc")) && \
        (NULL == cJSON_GetObjectItem(p_request,"dischargeLimitSoc")))
	{
		print_log("No valid item.");
		build_empty_response(response,203,"No valid item");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    if ((NULL != cJSON_GetObjectItem(p_request,"monomerChargeLimitVolt")))
    {
        value_int = cJSON_GetObjectItem(p_request,"monomerChargeLimitVolt")->valueint;
        if ((value_int >= MQTT_MONOMER_CHG_LIMIT_VOL_MIN) && (value_int <= MQTT_MONOMER_CHG_LIMIT_VOL_MAX))
        {
            monomer_charge_limit_volt = value_int;
            chg_data_valid = SF_OK;
        }
    }
    if ((NULL != cJSON_GetObjectItem(p_request,"monomerDischargeLimitVolt")))
    {
        value_int = cJSON_GetObjectItem(p_request,"monomerDischargeLimitVolt")->valueint;
        if ((value_int >= MQTT_MONOMER_DISCHG_LIMIT_VOL_MIN) && (value_int <= MQTT_MONOMER_DISCHG_LIMIT_VOL_MAX))
        {
            monomer_discharge_limit_volt = value_int;
            dischg_data_valid = SF_OK;
        }
    }
    if ((NULL != cJSON_GetObjectItem(p_request,"chargeLimitSoc")))   //SOC充电上限
    {
        value_int = cJSON_GetObjectItem(p_request,"chargeLimitSoc")->valueint;
        if ((value_int >= MQTT_SOC_CHARGE_LIMIT_MIM) &&
            (value_int <= MQTT_SOC_CHARGE_LIMIT_MAX) &&
            ((p_telematic_data->container_system_status_info[0] & 0x01) == 0)) //值在合理区间,并且此时没有禁充
        {
            soc_charge_limit = value_int / 10;
            soc_charge_limit_data_valid = SF_OK;
        }
    }
    if ((NULL != cJSON_GetObjectItem(p_request,"dischargeLimitSoc")))   //SOC放电下限
    {
        value_int = cJSON_GetObjectItem(p_request,"dischargeLimitSoc")->valueint;
        if ((value_int >= MQTT_SOC_DISCHARGE_LIMIT_MIM) && 
            (value_int <= MQTT_SOC_DISCHARGE_LIMIT_MAX) &&
            ((p_telematic_data->container_system_status_info[0] & 0x02) == 0)) //值在合理区间,并且此时没有禁放
        {
            soc_discharge_limit = value_int / 10;
            soc_discharge_limit_data_valid = SF_OK;
        }
    }
    
    cJSON_Delete(p_request);
    ret = para_config_page_protect_para_get(&param_info); //需求比实际较少，需要先获取一下所有数据，只修改需求的数据
    if (SF_OK != ret)
    {
        print_log("para get error.");
		build_empty_response(response,204,"para get error");
		http_back(p_nc,response);
		return;
    }

    if ((SF_OK == chg_data_valid) || (SF_OK == dischg_data_valid))
    {
        if (SF_OK == chg_data_valid)
        {
            param_info.monomer_OVP_warn_threshold_2 = monomer_charge_limit_volt;
        }
        if (SF_OK == dischg_data_valid)
        {
            param_info.monomer_UVP_warn_threshold_2 = monomer_discharge_limit_volt;
        }
        para_config_page_protect_para_set(&param_info);
        p_web_data->battery_threshold_update_flag = ENABLE;
    }

    if((SF_OK == soc_charge_limit_data_valid) &&
        p_para_data->soc_charge_limit != soc_charge_limit)  //值发生了改变
    {
        soc_limit_changed_flag = 1;
        p_para_data->soc_charge_limit = soc_charge_limit;
    }
    if((SF_OK == soc_discharge_limit_data_valid) &&
        p_para_data->soc_discharge_limit != soc_discharge_limit) //值发生了改变
    {
        soc_limit_changed_flag = 1;
        p_para_data->soc_discharge_limit = soc_discharge_limit;
    }

    if(soc_limit_changed_flag == 1)
    {
        p_web_data->charge_discharge_soc_limit_set_flag = 1;  //如果值发生了变化,需要更新配置文件
    }

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        return;
    }
    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddStringToObject(p_resp_root,"msg","set successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_resp_root);

    http_back(p_nc,p);
    free(p);
}

/**
 * @brief mqtt模块初始化
 * @return void
 */
void mqtt_info_module_init(void)
{
    /*MQTT数据获取，针对小桔云平台*/
	if(!web_func_attach("/mqttUpload/getUploadData", mqtt_get_bms_pcs_info))
	{
		print_log("[/mqttUpload/getUploadData] attach failed");
	}
	/*MQTT事件获取，针对小桔云平台*/
	if(!web_func_attach("/mqttUpload/getUploadEvent", mqtt_get_event_info))
	{
		print_log("[/mqttUpload/getUploadEvent] attach failed");
	}
	/*MQTT设置储能柜参数，针对小桔云平台*/
	if(!web_func_attach("/mqttSetParam/paramSet", mqtt_set_param_info))
	{
		print_log("[/mqttSetParam/paramSet] attach failed");
	}
}