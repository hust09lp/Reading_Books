#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include "sdk_fs.h"
#include "sdk_file.h"
#include "sofar_errors.h"
#include "common.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "fault_recorder_data2csv.h"

// #define FAULTCSV_PATH               "/user/data/fault_recorder.csv"
// #define FAULT_RECORDER_PATH         "/user/data/241017140028-202"

#define FAULT_RECORDER_TIME_LEN     6                   //时间
#define FAULT_RECORDER_ITEM_LEN     296                 //每条数据长度
#define MAX_RECORDER_ITEM_NUM       80                 //参数数量
#define MAX_RECORDER_NUM            600                 //最大记录条数

#define MAX_RECORDER_STR_LEN        (1024 * 8)

const char *p_title_txt[80] = \
{
    //日期
    "日期",
    //PCS
    "电网相电压RS(V)",
    "电网相电压ST(V)",
    "电网相电压TR(V)",
    "交流侧电流R相(A)",
    "交流侧电流S相(A)",
    "交流侧电流T相(A)",
    "母线电压(V)",
    //液冷
    "进水温度(℃)",
    "出水温度(℃)",
    "进水压力(kPa)",
    "出水压力(kPa)",
    //消防电池参数1
    "1#复合型传感器CO浓度(ppm)",
    "1#温度(℃)",
    "1#湿度(%)",
    "1#消防气瓶气压(kPa)",
    "1#单簇最高单体电压(V)",
    "1#单簇最低单体电压(V)",
    "1#单体电压平均值(V)",
    "1#单簇最高单体温度(℃)",
    "1#单簇最低单体温度(℃)",
    "1#单体温度平均值(℃)",
    "1#簇端电压(V)",
    "1#簇端电流(A)",
    "1#1#簇端SOC",
    "1#主正继电器状态",
    "1#主负继电器状态",
    "1#与最高温度电芯相邻的电芯温度(℃)",
    "1#与最高温度电芯相邻的电芯温度(℃)",
    //消防电池参数2
    "2#复合型传感器CO浓度(ppm)",
    "2#温度(℃)",
    "2#湿度(%)",
    "2#消防气瓶气压(kPa)",
    "2#单簇最高单体电压(V)",
    "2#单簇最低单体电压(V)",
    "2#单体电压平均值(V)",
    "2#单簇最高单体温度(℃)",
    "2#单簇最低单体温度(℃)",
    "2#单体温度平均值(℃)",
    "2#簇端电压(V)",
    "2#簇端电流(A)",
    "2#1#簇端SOC",
    "2#主正继电器状态",
    "2#主负继电器状态",
    "2#与最高温度电芯相邻的电芯温度(℃)",
    "2#与最高温度电芯相邻的电芯温度(℃)",
    //消防电池参数3
    "3#复合型传感器CO浓度(ppm)",
    "3#温度(℃)",
    "3#湿度(%)",
    "3#消防气瓶气压(kPa)",
    "3#单簇最高单体电压(V)",
    "3#单簇最低单体电压(V)",
    "3#单体电压平均值(V)",
    "3#单簇最高单体温度(℃)",
    "3#单簇最低单体温度(℃)",
    "3#单体温度平均值(℃)",
    "3#簇端电压(V)",
    "3#簇端电流(A)",
    "3#1#簇端SOC",
    "3#主正继电器状态",
    "3#主负继电器状态",
    "3#与最高温度电芯相邻的电芯温度(℃)",
    "3#与最高温度电芯相邻的电芯温度(℃)",
    //消防电池参数4
    "4#复合型传感器CO浓度(ppm)",
    "4#温度(℃)",
    "4#湿度(%)",
    "4#消防气瓶气压(kPa)",
    "4#单簇最高单体电压(V)",
    "4#单簇最低单体电压(V)",
    "4#单体电压平均值(V)",
    "4#单簇最高单体温度(℃)",
    "4#单簇最低单体温度(℃)",
    "4#单体温度平均值(℃)",
    "4#簇端电压(V)",
    "4#簇端电流(A)",
    "4#1#簇端SOC",
    "4#主正继电器状态",
    "4#主负继电器状态",
    "4#与最高温度电芯相邻的电芯温度(℃)",
    "4#与最高温度电芯相邻的电芯温度(℃)",
};


/**
 * @brief  	从文件中读取录波数据
 * @param  	[in] p_fs 	已打开的文件指针
 * @param   [in] offset 在文件中的偏移地址
 * @param  	[in] len 	欲读取数据长度
 * @param  	[out] p_buff 	指向欲存放读取进来的数据空间
 * @return 	[int32_t] 执行结果
 * @retval  =0 读取成功
 * @retval  <0 读取失败
 */
static int32_t fault_recoeder_date_read(fs_t *p_fs, uint32_t offset, uint32_t len, void *p_buff)
{
	int32_t ret = SF_OK;

	ret = sdk_fs_lseek(p_fs, offset);
    if (ret < 0)
    {
        print_log("lseek error! ret = %d \n", ret);
        return SF_ERR_SEEK;
    }

	ret = sdk_fs_read(p_fs, p_buff, len);
    if (ret != len)
    {
        print_log("read error!\n");
        return SF_ERR_RD;
    }

	return SF_OK;
}


/**
 * @brief  	读取录波数据
 * @param  	[out] p_data    录波数据
 * @param  	[out] p_data_num    数据条数
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功  -1：失败
 */
static int32_t fault_recoder_data_get(cabinet_fault_recorder_data_t *p_data, uint32_t *p_data_num, char *p_file)
{
    int32_t ret;
    fs_t *p_fs = NULL;
    int32_t file_size = 0;
    int32_t item_len = 0;
    int32_t item_loop = 0;
    uint32_t offset = 0;
    uint32_t data_num = 0;
    cabinet_fault_recorder_data_t recorder_data;

    ret = sdk_fs_access((const int8_t *)p_file, FS_F_OK);
    if(ret != SF_OK)
    {
        print_log("file not exit\n");
        return -1;
    }
    
    p_fs = sdk_fs_open((int8_t *)p_file, FS_READ);
    if(p_fs == NULL)
    {
        print_log("file open fail\n");
        return -1;
    }
    print_log("file open ok\n");
    file_size = sdk_fs_get_size(p_fs);
    if (file_size < 0)
    {
        print_log("file_size = %d \n",file_size);
        sdk_fs_close(p_fs);
        return -1;
    }
    print_log("file_size = %d \n",file_size);
    item_len = sizeof(cabinet_fault_recorder_data_t);
    item_loop = file_size / item_len;
    print_log("file_size: %d, item_loop: %d, item_len: %d\n", file_size, item_loop, item_len);
    if (item_loop < 1)
    {
        print_log("no content!\n");
        sdk_fs_close(p_fs);
        return -1;
    }
    // offset = (item_loop - 1) * item_len;

    while (item_loop)
    {
        ret = fault_recoeder_date_read(p_fs, offset, sizeof(cabinet_fault_recorder_data_t), &recorder_data);
        if (ret == SF_OK)
        {
            memcpy((int8_t *)&p_data[data_num], &recorder_data, sizeof(cabinet_fault_recorder_data_t));
            data_num++;

            offset += item_len;
            item_loop--;
        }
    }
    sdk_fs_close(p_fs);   
    *p_data_num = data_num;
    return ret;
}



/**
 * @brief   对字节流录波数据进行解析并存储成csv文件
 * @param p_src_file：需要转换的文件
 * @param p_src_file：需要生成的文件
 * @return 0：成功  -1：失败
 * @note
 */
int32_t fault_recorder_data2csv(char *p_src_file, char *p_dst_file)
{
    int32_t ret = 0;
    fs_t *p_fs_des = NULL;
    cabinet_fault_recorder_data_t *p_data = NULL;
    char p_title[4096] = {0};                           //第一行表格头
    int title_para_num = 0;
    char item_data[MAX_RECORDER_STR_LEN] = {0};         //每条数据内容
    uint32_t recorder_item_num = 0;
    int len = 0;
    int i = 0;
    int j = 0;
    int k = 0;
    int16_t *p_para = NULL;

    constant_parameter_data_t *p_const_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    sdk_file_remove((int8_t *)p_dst_file);
    p_fs_des = sdk_fs_open((int8_t *)p_dst_file, FS_OPEN_APPEND);
    if (p_fs_des == NULL)
    {
        print_log("\n sdk_fs_open des file fail! \n");
        return -1;
    }

    //设置第一行表格，参数名称，需要根据电池簇数量来确定
    //日期：1  PCS：7  液冷：4  消防电池：17 * 电池簇数量
    title_para_num = 12 + 17 * p_const_data->bat_cabinet_num;
    for(i = 0; i < title_para_num; i++)
    {
        len += snprintf(p_title + len, 4096, "%s, ", p_title_txt[i]);
    }
    fprintf((FILE *)p_fs_des, "%s\n", p_title);

    p_data = (cabinet_fault_recorder_data_t *)malloc(MAX_RECORDER_NUM * sizeof(cabinet_fault_recorder_data_t));
    if(p_data == NULL)
    {
        print_log("malloc memory failed\n");
        return -1;
    }
    //开始循环读取录波文件
    ret = fault_recoder_data_get(p_data, &recorder_item_num, p_src_file);
    if(ret < 0)
    {
        print_log("fault recorder data get error");
        sdk_fs_close(p_fs_des);
        free(p_data);
        return -1;
    }
    print_log("----->fault recorder item num:%d\n", recorder_item_num);
    //先读取时间
    for(i = 0; i < recorder_item_num; i++)
    {
        len = 0;
        memset(item_data, 0, sizeof(item_data));
        len += snprintf(item_data + len, MAX_RECORDER_STR_LEN, "%d-%d-%d %d:%d:%d, ", p_data[i].record_time[0], p_data[i].record_time[1], \
                                                                    p_data[i].record_time[2], p_data[i].record_time[3], \
                                                                    p_data[i].record_time[4], p_data[i].record_time[5]);

        
        //PCS数据
        p_para = &p_data[i].grid_volt_rs;
        for(j = 0; j < PCS_ITEM_NUM; j++)
        {
            len += snprintf(item_data + len, MAX_RECORDER_STR_LEN, "%.2f, ", (*(p_para + j)) / 10.0);
        }

        //液冷数据
        //出水温度&进水温度
        len += snprintf(item_data + len, MAX_RECORDER_STR_LEN, "%.2f, ", (p_data[i].lc_inlet_temp) / 10.0);
        len += snprintf(item_data + len, MAX_RECORDER_STR_LEN, "%.2f, ", (p_data[i].lc_outlet_temp) / 10.0);
        //进水压力&出水压力
        len += snprintf(item_data + len, MAX_RECORDER_STR_LEN, "%d, ", p_data[i].lc_inlet_pressure);
        len += snprintf(item_data + len, MAX_RECORDER_STR_LEN, "%d, ", p_data[i].lc_outlet_pressure);

        //消防电池数据，4个柜子循环提取
        for(k = 0; k < p_const_data->bat_cabinet_num; k++)
        {
            //消防数据
            //CO浓度
            len += snprintf(item_data + len, MAX_RECORDER_STR_LEN, "%d, ", p_data[i].cabinet_data[k].mix_sensor1_co_ppm);
            //电池仓温度
            len += snprintf(item_data + len, MAX_RECORDER_STR_LEN, "%.2f, ", (p_data[i].cabinet_data[k].bat1_temper) / 10.0);
            //电池仓湿度
            len += snprintf(item_data + len, MAX_RECORDER_STR_LEN, "%d, ", p_data[i].cabinet_data[k].bat1_humidity);
            //消防气瓶压力
            len += snprintf(item_data + len, MAX_RECORDER_STR_LEN, "%d, ", p_data[i].cabinet_data[k].ff_cylinder_press);

            //电池数据
            //单体电压
            p_para = &p_data[i].cabinet_data[k].highest_monomer_voltage_cluster;
            for(j = 0; j < 3; j++)
            {
                len += snprintf(item_data + len, MAX_RECORDER_STR_LEN, "%.3f, ", (*(p_para + j)) / 1000.0);
            }
            //单体温度
            p_para = &p_data[i].cabinet_data[k].highest_monomer_temperature_cluster;
            for(j = 0; j < 3; j++)
            {
                len += snprintf(item_data + len, MAX_RECORDER_STR_LEN, "%d, ", (*(p_para + j)) - 40);
            } 
            //簇端电压
            len += snprintf(item_data + len, MAX_RECORDER_STR_LEN, "%.2f, ", (p_data[i].cabinet_data[k].cluster_voltage) / 10.0);
            //簇端电流
            len += snprintf(item_data + len, MAX_RECORDER_STR_LEN, "%.2f, ", (16000 - p_data[i].cabinet_data[k].cluster_current) / 10.0);
            //SOC
            len += snprintf(item_data + len, MAX_RECORDER_STR_LEN, "%d, ", p_data[i].cabinet_data[k].cluster_SOC);
            //继电器
            len += snprintf(item_data + len, MAX_RECORDER_STR_LEN, "%d, ", p_data[i].cabinet_data[k].positive_relay_status);
            len += snprintf(item_data + len, MAX_RECORDER_STR_LEN, "%d, ", p_data[i].cabinet_data[k].negative_relay_status);
            //比邻电芯温度
            len += snprintf(item_data + len, MAX_RECORDER_STR_LEN, "%d, ", p_data[i].cabinet_data[k].Adjacent_highest_monomer_temperature1 - 40);
            len += snprintf(item_data + len, MAX_RECORDER_STR_LEN, "%d, ", p_data[i].cabinet_data[k].Adjacent_highest_monomer_temperature2 - 40);
        }

        fprintf((FILE *)p_fs_des, "%s\n", item_data);
    }

    sdk_fs_close(p_fs_des);
    free(p_data);

    return 0;
}