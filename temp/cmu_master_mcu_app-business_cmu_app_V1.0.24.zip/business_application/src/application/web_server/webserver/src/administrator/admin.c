#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "cJSON.h"
#include "common.h"
#include "administrator.h"
#include "web_broker.h"

#define DEFAULT_PASSWORD_MD5 "d000670b645d5fc3dea909b4e21a455c"  //Sofar147369  MD5_HASH
#define MAX_OPERATOR 50   //根据刘博的需求,我们最多支持50个运维人员和200个终端用户
#define MAX_ENDUSER 200
#define MAX_BUFF (200 * 250)   //每一条最多占用200字节,最多可以有250条
 
static void get_current_user_num(uint8_t *p_operator_num,uint8_t *p_enduser_num)
{
	FILE *fp;
	cJSON *p_conf_array;
	uint8_t *p_buff;
	uint8_t i;
	uint8_t *p_role; 
	cJSON *p_conf_item;

	fp = fopen(ADMIN_JSON_FILE,"r");
	if(fp == NULL)
	{
		print_log("open [%s] failed.", ADMIN_JSON_FILE);
		return;
	}

	p_buff = (uint8_t *)malloc(MAX_BUFF);
	if(p_buff == NULL)
	{
		print_log("malloc memory failed.");
		fclose(fp);
		return;
	}

	fread(p_buff,1,MAX_BUFF,fp);
	fclose(fp);

	p_conf_array = cJSON_Parse(p_buff);
	if(p_conf_array == NULL)
	{
		print_log("parse config [%s] failed.",ADMIN_JSON_FILE);
		free(p_buff);
		return;
	}
	free(p_buff);  //此时p_buff里面的json数据已经全部解析到了p_conf_array里面,这个已经没有用了,可以释放了

	*p_operator_num = 0;
	*p_enduser_num = 0;
	for(i=0;i<cJSON_GetArraySize(p_conf_array);i++)
	{
		p_conf_item = cJSON_GetArrayItem(p_conf_array,i);
		p_role = cJSON_GetObjectItem(p_conf_item,"role")->valuestring;
		if(!strcmp(p_role,"operator"))
		{
			*p_operator_num += 1;
		}
		else if(!strcmp(p_role,"enduser"))
		{
			*p_enduser_num += 1;
		}
	}
	cJSON_Delete(p_conf_array);
}

void get_user_info(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request;
	cJSON *p_conf_array;
	cJSON *p_conf_item;
	cJSON *p_resp_data_array;
	cJSON *p_resp_data_item;
	cJSON *p_resp_root;
	uint8_t *p_action;
	uint8_t *p_uname;
	uint8_t *p_role;
	uint8_t *p_creat_time;
	uint8_t *p_stat;
	uint8_t *p_phonenum;
	uint8_t *p;
	FILE *fp;
	uint16_t i;
	uint8_t *p_buff;
	uint8_t response[64];
	uint8_t request_body[1024] = {0};

	if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}	
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		print_log("request body is not json.");
		build_empty_response(response,202,"request body is not json.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getUserInfo"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		cJSON_Delete(p_request);
		http_back(p_nc,response);
		return;
	}
	cJSON_Delete(p_request);

	fp = fopen(ADMIN_JSON_FILE,"r");
	if(fp == NULL)
	{
		print_log("open [%s] failed.", ADMIN_JSON_FILE);
		return;
	}
	p_buff = (uint8_t *)malloc(MAX_BUFF);
	if(p_buff == NULL)
	{
		print_log("malloc memory failed.");
		fclose(fp);
		return;
	}

	fread(p_buff,1,MAX_BUFF,fp);
	fclose(fp);

	p_conf_array = cJSON_Parse(p_buff);
	if(p_conf_array == NULL)
	{
		print_log("parse config [%s] failed.",ADMIN_JSON_FILE);
		free(p_buff);
		return;
	}
	free(p_buff);

	p_resp_data_array = cJSON_CreateArray();
	if(p_resp_data_array == NULL)
	{
		print_log("create data array failed.");
		cJSON_Delete(p_conf_array);
		return;
	}
	
	for(i = 0; i < cJSON_GetArraySize(p_conf_array);i++)
	{
		p_phonenum = NULL;
		p_conf_item = cJSON_GetArrayItem(p_conf_array,i);
		p_uname = cJSON_GetObjectItem(p_conf_item,"username")->valuestring;
		p_role = cJSON_GetObjectItem(p_conf_item,"role")->valuestring;
		p_creat_time = cJSON_GetObjectItem(p_conf_item,"createtime")->valuestring;
		p_stat = cJSON_GetObjectItem(p_conf_item,"status")->valuestring;
		if(cJSON_GetObjectItem(p_conf_item,"phonenum") != NULL)
		{
			p_phonenum = cJSON_GetObjectItem(p_conf_item,"phonenum")->valuestring;
		}
		p_resp_data_item = cJSON_CreateObject();
		if(p_resp_data_item == NULL)
		{
			print_log("create data item failed.");
			cJSON_Delete(p_conf_array);
			cJSON_Delete(p_resp_data_array);
			return;
		}
		cJSON_AddStringToObject(p_resp_data_item,"userName",p_uname);
		cJSON_AddStringToObject(p_resp_data_item,"userRole",p_role);
		cJSON_AddStringToObject(p_resp_data_item,"createTime",p_creat_time);
		cJSON_AddStringToObject(p_resp_data_item,"accountStat",p_stat);
		if(p_phonenum != NULL)
		{
			cJSON_AddStringToObject(p_resp_data_item,"phoneNum",p_phonenum);
		}
		cJSON_AddItemToArray(p_resp_data_array,p_resp_data_item);
	}
	cJSON_Delete(p_conf_array);
	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		print_log("create json obj failed.");
        cJSON_Delete(p_resp_data_array);
		return;
	}
	cJSON_AddItemToObject(p_resp_root,"data",p_resp_data_array);
	cJSON_AddNumberToObject(p_resp_root,"code",200);
	cJSON_AddStringToObject(p_resp_root,"msg","get user info successful.");

	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	
	free(p);
}

void delete_users(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request;	
	cJSON *p_user_info_array;
	cJSON *p_user_info_item;
	cJSON *p_conf_array;
	cJSON *p_conf_item;
	FILE *fp;
	uint8_t response[128] = {0};
	uint8_t *p_buff;
	uint8_t *p_action;
	uint8_t num;
	uint8_t i,j;
	uint8_t user_to_del[32][64];
	uint8_t *p;
	uint8_t request_body[4096] = {0};
	uint8_t cur_user[32] = {0};
	operation_log_t op_log;
	
	if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	for(i=0;i<32;i++)
	{
		memset(user_to_del[i],0,64);
	}

	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"deleteUser"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
	
	num = cJSON_GetObjectItem(p_request,"num")->valueint;
	p_user_info_array = cJSON_GetObjectItem(p_request,"userInfo");
	if(num != cJSON_GetArraySize(p_user_info_array))
	{
		print_log("num is not equal to array size.");
		cJSON_Delete(p_request);
		return;
	}

	for(i=0;i<num;i++)
	{
		p_user_info_item = cJSON_GetArrayItem(p_user_info_array,i);
		strcpy(user_to_del[i],cJSON_GetObjectItem(p_user_info_item,"userName")->valuestring);		
	}
	cJSON_Delete(p_request);

	fp = fopen(ADMIN_JSON_FILE,"r");
	if(fp == NULL)
	{
		print_log("open %s failed.",ADMIN_JSON_FILE);
		return;
	}
	p_buff = (uint8_t *)malloc(MAX_BUFF);
	if(p_buff == NULL)
	{
		print_log("malloc memory failed.");
		fclose(fp);
		return;
	}
	memset(p_buff,0,MAX_BUFF);
	fread(p_buff,1,MAX_BUFF,fp);
	fclose(fp);

	p_conf_array = cJSON_Parse(p_buff);
	if(p_conf_array == NULL)
	{
		print_log("parse conf file failed.");
		free(p_buff);
		return;
	}
	free(p_buff);

	for(i=0;i<num;i++)
	{
		for(j=0;j<cJSON_GetArraySize(p_conf_array);j++)
		{
			p_conf_item = cJSON_GetArrayItem(p_conf_array,j);
			if((!strcmp(user_to_del[i],cJSON_GetObjectItem(p_conf_item,"username")->valuestring) &&
			(strcmp(user_to_del[i],"admin"))))
			{
				cJSON_DeleteItemFromArray(p_conf_array,j);
				break; //此处退出内循环即可。因为用户名字的唯一性，所以没有必要继续循环下去
			}
		}
	}

	p = cJSON_PrintUnformatted(p_conf_array);

	fp = fopen(ADMIN_JSON_FILE,"w");
	if(fp == NULL)
	{
		print_log("open %s failed.",ADMIN_JSON_FILE);
		cJSON_Delete(p_conf_array);
		return;
	}
	fwrite(p,1,strlen(p),fp);
	fclose(fp);

	cJSON_Delete(p_conf_array);
	free(p);

	init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	if(num > 1)
	{
		strcpy(op_log.op_type,"批量删除用户");
	}
	else
	{
		strcpy(op_log.op_type,"删除用户");
	}
	strcpy(op_log.op_status,"success");
	add_one_op_log(&op_log);

	
	build_empty_response(response,200,"delete successful");
	http_back(p_nc,response);
}

void add_one_user(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request;
	cJSON *p_conf_array;
	cJSON *p_conf_item;
	uint8_t *p_action;
	uint8_t *p_uname;
	uint8_t *p_conf_uname;
	uint8_t *p_role;
	uint8_t *p_pwd;
	uint8_t *p_phonenum = NULL;
	uint8_t *p;
	uint8_t i;
	FILE *fp;
	uint8_t response[128];
	uint8_t request_body[1024] = {0};
	uint8_t *p_buff;
	uint8_t md5[16] = {0};
	uint8_t md5_str[33] = {0};
	time_t time_now;
	uint8_t time_stamp[16] = {0};
	operation_log_t op_log;
	uint8_t cur_user[32] = {0};
	uint8_t p_operator_num;
	uint8_t p_enduser_num;

	if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"addUser"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		cJSON_Delete(p_request);
		http_back(p_nc,response);
		return;
	}
	p_uname = cJSON_GetObjectItem(p_request,"userName")->valuestring;
	p_role = cJSON_GetObjectItem(p_request,"userRole")->valuestring;
	p_pwd = cJSON_GetObjectItem(p_request,"loginPwd")->valuestring;
	get_current_user_num(&p_operator_num,&p_enduser_num);

	if(!strcmp(p_role,"operator") && (p_operator_num >= MAX_OPERATOR))
	{
		print_log("operator num is larger than 50");
		build_empty_response(response,205,"operator num is larger than 50");
		cJSON_Delete(p_request);
		http_back(p_nc,response);
		return;
	}

	if(!strcmp(p_role,"enduser") && (p_enduser_num >= MAX_ENDUSER))
	{
		print_log("enduser num is larger than 200");
		build_empty_response(response,206,"enduser num is larger than 200");
		cJSON_Delete(p_request);
		http_back(p_nc,response);
		return;
	}

	if(cJSON_GetObjectItem(p_request,"phoneNum") != NULL)
	{
		p_phonenum = cJSON_GetObjectItem(p_request,"phoneNum")->valuestring;
	}

	fp = fopen(ADMIN_JSON_FILE,"r");
	if(fp == NULL)
	{
		print_log("open [%s] failed.", ADMIN_JSON_FILE);
		return;
	}

	p_buff = (uint8_t *)malloc(MAX_BUFF);
	if(p_buff == NULL)
	{
		print_log("malloc memory failed.");
		fclose(fp);
		return;
	}
	//memset(p_buff,0,MAX_BUFF);
	fread(p_buff,1,MAX_BUFF,fp);
	fclose(fp);

	p_conf_array = cJSON_Parse(p_buff);
	if(p_conf_array == NULL)
	{
		print_log("parse config [%s] failed.",ADMIN_JSON_FILE);
		free(p_buff);
		return;
	}
	free(p_buff);  //此时p_buff里面的json数据已经全部解析到了p_conf_array里面,这个已经没有用了,可以释放了
	
	for(i=0;i<cJSON_GetArraySize(p_conf_array);i++)
	{
		p_conf_item = cJSON_GetArrayItem(p_conf_array,i);
		p_conf_uname = cJSON_GetObjectItem(p_conf_item,"username")->valuestring;
		if(!strcmp(p_conf_uname,p_uname))  //名字具有唯一性，不能重复
		{
			print_log("username already exists.");
			cJSON_Delete(p_request);
			cJSON_Delete(p_conf_array);
			build_empty_response(response,204,"username already exists.");
			http_back(p_nc,response);
			return;
		}
	}
	p_conf_item = cJSON_CreateObject();
	if(p_conf_item == NULL)
	{
		print_log("create obj failed.");
		cJSON_Delete(p_request);
		cJSON_Delete(p_conf_array);
		return;
	}
	md5_calcul(p_pwd,strlen(p_pwd),md5);
	hex_to_str(md5,md5_str,16);
	time_now = time(NULL);
	sprintf(time_stamp,"%d",time_now);
	
	cJSON_AddStringToObject(p_conf_item,"username",p_uname);
	cJSON_AddStringToObject(p_conf_item,"password",md5_str);
	cJSON_AddStringToObject(p_conf_item,"role",p_role);
	cJSON_AddStringToObject(p_conf_item,"createtime",time_stamp);
	cJSON_AddStringToObject(p_conf_item,"status","activated");
	if(p_phonenum != NULL)
	{
		cJSON_AddStringToObject(p_conf_item,"phonenum",p_phonenum);
	}
	cJSON_Delete(p_request);
	cJSON_AddItemToArray(p_conf_array,p_conf_item);
	p = cJSON_PrintUnformatted(p_conf_array);

	fp = fopen(ADMIN_JSON_FILE,"w");
	if(fp == NULL)
	{
		print_log("open %s failed.",ADMIN_JSON_FILE);
		cJSON_Delete(p_conf_array);
		return;
	}
	fwrite(p,1,strlen(p),fp);
	fclose(fp);

	cJSON_Delete(p_conf_array);
	free(p);

	init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"添加用户");
	strcpy(op_log.op_status,"success");
	add_one_op_log(&op_log);

	build_empty_response(response,200,"add user successful");
	http_back(p_nc,response);
}

void reset_password(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request;
	cJSON *p_user_info_array;
	cJSON *p_user_info_item;
	cJSON *p_conf_array;
	cJSON *p_conf_item;
	FILE *fp;
	uint8_t *p;
	uint8_t *p_action;
	uint8_t i,j;
	uint8_t num;
	uint8_t response[128];
	uint8_t request_body[1024] = {0};
	uint8_t user_reset_pwd[32][64];
	uint8_t *p_buff;
	operation_log_t op_log;
	uint8_t cur_user[32] = {0};

	for(i=0;i<32;i++)
	{
		memset(user_reset_pwd[i],0,64); //初始化二维数组
	}

	if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"resetPwd"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
	num = cJSON_GetObjectItem(p_request,"num")->valueint;
	p_user_info_array = cJSON_GetObjectItem(p_request,"userInfo");

	if(num != cJSON_GetArraySize(p_user_info_array))
	{
		print_log("num is not equal to array size.");
		cJSON_Delete(p_request);
		return;
	}
	for(i=0;i<num;i++)
	{
		p_user_info_item = cJSON_GetArrayItem(p_user_info_array,i);
		strcpy(user_reset_pwd[i],cJSON_GetObjectItem(p_user_info_item,"userName")->valuestring);		
	}
	cJSON_Delete(p_request);

	fp = fopen(ADMIN_JSON_FILE,"r");
	if(fp == NULL)
	{
		print_log("open [%s] failed.", ADMIN_JSON_FILE);
		return;
	}

	p_buff = (uint8_t *)malloc(MAX_BUFF);
	if(p_buff == NULL)
	{
		print_log("malloc memory failed.");
		fclose(fp);
		return;
	}
	fread(p_buff,1,MAX_BUFF,fp);
	fclose(fp);

	p_conf_array = cJSON_Parse(p_buff);
	if(p_conf_array == NULL)
	{
		print_log("parse config [%s] failed.",ADMIN_JSON_FILE);
		free(p_buff);
		return;
	}
	free(p_buff);  //此时p_buff里面的json数据已经全部解析到了p_conf_array里面,这个已经没有用了,可以释放了

	for(i=0;i<num;i++)
	{
		for(j=0;j<cJSON_GetArraySize(p_conf_array);j++)
		{
			p_conf_item = cJSON_GetArrayItem(p_conf_array,j);
			if(!strcmp(user_reset_pwd[i],cJSON_GetObjectItem(p_conf_item,"username")->valuestring))
			{
				cJSON_ReplaceItemInObject(p_conf_item,"password",cJSON_CreateString(DEFAULT_PASSWORD_MD5));
				break; //此处退出内循环即可。因为用户名字的唯一性，所以没有必要继续循环下去
			}
		}
	}
	p = cJSON_PrintUnformatted(p_conf_array);

	fp = fopen(ADMIN_JSON_FILE,"w");
	if(fp == NULL)
	{
		print_log("open %s failed.",ADMIN_JSON_FILE);
		cJSON_Delete(p_conf_array);
		return;
	}
	fwrite(p,1,strlen(p),fp);
	fclose(fp);

	cJSON_Delete(p_conf_array);
	free(p);

	init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	if(num > 1)
	{
		strcpy(op_log.op_type,"批量重置密码");
	}
	else
	{
		strcpy(op_log.op_type,"重置密码");
	}
	strcpy(op_log.op_status,"success");
	add_one_op_log(&op_log);

	build_empty_response(response,200,"reset pwd successful");
	http_back(p_nc,response);
}

void edit_user_info(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request;
	cJSON *p_conf_array;
	cJSON *p_conf_item;
	uint8_t *p_action;
	uint8_t *p_uname;
	uint8_t *p_conf_uname;
	uint8_t *p_role;
	uint8_t *p_pwd;
	uint8_t *p_phonenum = NULL;
	uint8_t *p;
	uint8_t i;
	FILE *fp;
	uint8_t response[128];
	uint8_t request_body[1024] = {0};
	uint8_t *p_buff;
	uint8_t md5[16] = {0};
	uint8_t md5_str[33] = {0};
	time_t time_now;
	uint8_t time_stamp[16] = {0};
	operation_log_t op_log;
	uint8_t cur_user[32] = {0};

	if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"modifyUser"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
	p_uname = cJSON_GetObjectItem(p_request,"userName")->valuestring;
	p_role = cJSON_GetObjectItem(p_request,"userRole")->valuestring;
	p_pwd = cJSON_GetObjectItem(p_request,"loginPwd")->valuestring;
	md5_calcul(p_pwd,strlen(p_pwd),md5);
	hex_to_str(md5,md5_str,16);
	if(cJSON_GetObjectItem(p_request,"phoneNum") != NULL)
	{
		p_phonenum = cJSON_GetObjectItem(p_request,"phoneNum")->valuestring;
	}

	fp = fopen(ADMIN_JSON_FILE,"r");
	if(fp == NULL)
	{
		print_log("open [%s] failed.", ADMIN_JSON_FILE);
		return;
	}

	p_buff = (uint8_t *)malloc(MAX_BUFF);
	if(p_buff == NULL)
	{
		print_log("malloc memory failed.");
		fclose(fp);
		return;
	}
	memset(p_buff,0,MAX_BUFF);
	fread(p_buff,1,MAX_BUFF,fp);
	fclose(fp);

	p_conf_array = cJSON_Parse(p_buff);
	if(p_conf_array == NULL)
	{
		print_log("parse config [%s] failed.",ADMIN_JSON_FILE);
		free(p_buff);
		return;
	}
	free(p_buff);  //此时p_buff里面的json数据已经全部解析到了p_conf_array里面,这个已经没有用了,可以释放了

	for(i=0;i<cJSON_GetArraySize(p_conf_array);i++)
	{
		p_conf_item = cJSON_GetArrayItem(p_conf_array,i);
		p_conf_uname = cJSON_GetObjectItem(p_conf_item,"username")->valuestring;
		if(!strcmp(p_conf_uname,p_uname))  //名字具有唯一性，不能重复
		{
			cJSON_ReplaceItemInObject(p_conf_item,"password",cJSON_CreateString(md5_str));
			cJSON_ReplaceItemInObject(p_conf_item,"role",cJSON_CreateString(p_role));
			if(p_phonenum != NULL)
			{
				if(cJSON_GetObjectItem(p_conf_item,"phonenum") != NULL)
				{
					cJSON_ReplaceItemInObject(p_conf_item,"phonenum",cJSON_CreateString(p_phonenum));
				}
				else
				{
					cJSON_AddStringToObject(p_conf_item,"phonenum",p_phonenum);
				}
			}
			else  //删除了电话号码
			{
				if(cJSON_GetObjectItem(p_conf_item,"phonenum") != NULL)
				{
					cJSON_DeleteItemFromObject(p_conf_item,"phonenum");
				}
			}
			break; //要编辑的已经找到，没有必要继续循环
		}
	}

	cJSON_Delete(p_request);
	p = cJSON_PrintUnformatted(p_conf_array);

	fp = fopen(ADMIN_JSON_FILE,"w");
	if(fp == NULL)
	{
		print_log("open %s failed.",ADMIN_JSON_FILE);
		cJSON_Delete(p_conf_array);
		return;
	}
	fwrite(p,1,strlen(p),fp);
	fclose(fp);

	cJSON_Delete(p_conf_array);
	free(p);

	init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"修改用户信息");
	strcpy(op_log.op_status,"success");
	add_one_op_log(&op_log);

	build_empty_response(response,200,"modify  user successful");
	http_back(p_nc,response);
}

/**
 * @brief 用户管理模块初始化
 * @return void
 */
void web_user_manage_module_init(void)
{
	/*用户登录*/
	if(!web_func_attach("/userLogin", do_login)) 
	{
		print_log("[/userLogin] attach failed");
	}
	/*获取用户信息*/
	if(!web_func_attach("/system/getUserInfo", get_user_info))
	{
		print_log("[/system/getUserInfo] attach failed");
	}
	/*删除用户*/
	if(!web_func_attach("/system/deleteUser", delete_users))
	{
		print_log("[/system/deleteUser] attach failed");
	}
	/*添加用户*/
	if(!web_func_attach("/system/addUser", add_one_user))
	{
		print_log("[/system/addUser] attach failed");
	}
	/*重置密码*/
	if(!web_func_attach("/system/resetPwd", reset_password))
	{
		print_log("[/system/resetPwd] attach failed");
	}
	/*编辑用户信息*/
	if(!web_func_attach("/system/modifyUser", edit_user_info))
	{
		print_log("[/system/modifyUser] attach failed");
	}
}













