#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/stat.h>
#include<sys/types.h>
#include"cJSON.h"
#include"upgrade.h"
#include"common.h"
#include"sdk_shm.h"
#include "sdk_safety.h"
#include"safety_lib_task.h"
#include "web_broker.h"
#include"udiskupgrade.h"


// #define BIT_SET(value, bit) (value |= (1 << bit))           //置位指定位
// #define BIT_CLR(value, bit) (value &=~(1 << bit))           //清零指定位
// #define BIT_GET(value, bit) ((value &  (1 << bit)) >> bit)  //读取指定位

#define MCU1_UPDATE         (0)
#define MCU1_APP_UPDATE     (1)
#define MCU1_CORE_UPDATE    (2)
#define MCU2_UPDATE         (3)
#define MCU2_APP_UPDATE     (4)
#define MCU2_CORE_UPDATE    (5)
#define PCS_UPDATE          (6)
#define DSPM_UPDATE         (7)
#define DSPS_UPDATE         (8)

struct FileInfo{
	FILE  *fp;
    char filePath[128];
    char fileName[128];	
};


uint32_t g_crc32;
int8_t g_progress_mcu1 = -1;
int8_t g_progress_mcu2 = -1;
int8_t g_progress_pcs = -1;
int8_t g_progress_pcs_m = -1;
int8_t g_progress_pcs_s = -1;
uint8_t g_upgrade_type_mcu1;
uint8_t g_upgrade_type_mcu2;
uint8_t g_upgrade_type_pcs;
uint8_t g_upgrade_type_pcs_m;
uint8_t g_upgrade_type_pcs_s;
uint8_t g_mcu2_progress_app_last;
uint8_t g_mcu2_progress_core_last;
uint8_t g_pcs_progress_last;
uint8_t g_pcs_progress_m_last;
uint8_t g_pcs_progress_s_last;
int8_t g_file_path[64];
static package_signing_msg_V02_t g_package_V02;
extern pthread_mutex_t g_upgrade_mtx;
extern pthread_mutex_t g_upgrade_mtx_pcs;
uint8_t g_reboot_flag;
uint8_t g_mcu2_done;
uint8_t g_pcs_done;
uint8_t g_pcs_m_done;
uint8_t g_pcs_s_done;
uint8_t g_mcu2_app_exist;
uint8_t g_mcu2_core_exist;
uint8_t safety_cur_user[32] = {0};

//新格式的芯片编码
typedef enum 
{
    ALMIGHTY_NUM = 0x00,    //不查询编码
    //集中式储能
    PCS_M_NUM = 0x22,
    PCS_S_NUM,
    PCS_M_NUM_LEGACY = 0x30,
    PCS_S_NUM_LEGACY = 0x31,
    PCS_C_NUM,
    PCS_MCU1_NUM,
    PCS_MCU2_NUM,
    CMU_MCU1_NUM = 0x3B,
    CMU_MCU2_NUM = 0x3C,
}obj_num_e;

typedef struct
{
    uint8_t file_number;
    uint8_t obj_number;
    uint8_t module_object[8];
} role_coding_new_t;

// 新格式的芯片角色编码与对象简称
static role_coding_new_t g_role_coding_new[UPDATE_OBJECT_NUM] = {
    /*      文件类型编码（新）    芯片角色编码（新）       类型           */
    {FILE_APP_NUM, CMU_MCU1_NUM, "CMU-MCU1"},
    {FILE_APP_NUM, CMU_MCU2_NUM, "CMU-MCU2"},
    {FILE_CORE_NUM, CMU_MCU1_NUM, "CMU-MCU1"},
    {FILE_CORE_NUM, CMU_MCU2_NUM, "CMU-MCU2"},
};

static const uint32_t crc32_table[] = {
    0x00000000, 0x77073096, 0xee0e612c, 0x990951ba, 0x076dc419, 0x706af48f,
    0xe963a535, 0x9e6495a3, 0x0edb8832, 0x79dcb8a4, 0xe0d5e91e, 0x97d2d988,
    0x09b64c2b, 0x7eb17cbd, 0xe7b82d07, 0x90bf1d91, 0x1db71064, 0x6ab020f2,
    0xf3b97148, 0x84be41de, 0x1adad47d, 0x6ddde4eb, 0xf4d4b551, 0x83d385c7,
    0x136c9856, 0x646ba8c0, 0xfd62f97a, 0x8a65c9ec, 0x14015c4f, 0x63066cd9,
    0xfa0f3d63, 0x8d080df5, 0x3b6e20c8, 0x4c69105e, 0xd56041e4, 0xa2677172,
    0x3c03e4d1, 0x4b04d447, 0xd20d85fd, 0xa50ab56b, 0x35b5a8fa, 0x42b2986c,
    0xdbbbc9d6, 0xacbcf940, 0x32d86ce3, 0x45df5c75, 0xdcd60dcf, 0xabd13d59,
    0x26d930ac, 0x51de003a, 0xc8d75180, 0xbfd06116, 0x21b4f4b5, 0x56b3c423,
    0xcfba9599, 0xb8bda50f, 0x2802b89e, 0x5f058808, 0xc60cd9b2, 0xb10be924,
    0x2f6f7c87, 0x58684c11, 0xc1611dab, 0xb6662d3d, 0x76dc4190, 0x01db7106,
    0x98d220bc, 0xefd5102a, 0x71b18589, 0x06b6b51f, 0x9fbfe4a5, 0xe8b8d433,
    0x7807c9a2, 0x0f00f934, 0x9609a88e, 0xe10e9818, 0x7f6a0dbb, 0x086d3d2d,
    0x91646c97, 0xe6635c01, 0x6b6b51f4, 0x1c6c6162, 0x856530d8, 0xf262004e,
    0x6c0695ed, 0x1b01a57b, 0x8208f4c1, 0xf50fc457, 0x65b0d9c6, 0x12b7e950,
    0x8bbeb8ea, 0xfcb9887c, 0x62dd1ddf, 0x15da2d49, 0x8cd37cf3, 0xfbd44c65,
    0x4db26158, 0x3ab551ce, 0xa3bc0074, 0xd4bb30e2, 0x4adfa541, 0x3dd895d7,
    0xa4d1c46d, 0xd3d6f4fb, 0x4369e96a, 0x346ed9fc, 0xad678846, 0xda60b8d0,
    0x44042d73, 0x33031de5, 0xaa0a4c5f, 0xdd0d7cc9, 0x5005713c, 0x270241aa,
    0xbe0b1010, 0xc90c2086, 0x5768b525, 0x206f85b3, 0xb966d409, 0xce61e49f,
    0x5edef90e, 0x29d9c998, 0xb0d09822, 0xc7d7a8b4, 0x59b33d17, 0x2eb40d81,
    0xb7bd5c3b, 0xc0ba6cad, 0xedb88320, 0x9abfb3b6, 0x03b6e20c, 0x74b1d29a,
    0xead54739, 0x9dd277af, 0x04db2615, 0x73dc1683, 0xe3630b12, 0x94643b84,
    0x0d6d6a3e, 0x7a6a5aa8, 0xe40ecf0b, 0x9309ff9d, 0x0a00ae27, 0x7d079eb1,
    0xf00f9344, 0x8708a3d2, 0x1e01f268, 0x6906c2fe, 0xf762575d, 0x806567cb,
    0x196c3671, 0x6e6b06e7, 0xfed41b76, 0x89d32be0, 0x10da7a5a, 0x67dd4acc,
    0xf9b9df6f, 0x8ebeeff9, 0x17b7be43, 0x60b08ed5, 0xd6d6a3e8, 0xa1d1937e,
    0x38d8c2c4, 0x4fdff252, 0xd1bb67f1, 0xa6bc5767, 0x3fb506dd, 0x48b2364b,
    0xd80d2bda, 0xaf0a1b4c, 0x36034af6, 0x41047a60, 0xdf60efc3, 0xa867df55,
    0x316e8eef, 0x4669be79, 0xcb61b38c, 0xbc66831a, 0x256fd2a0, 0x5268e236,
    0xcc0c7795, 0xbb0b4703, 0x220216b9, 0x5505262f, 0xc5ba3bbe, 0xb2bd0b28,
    0x2bb45a92, 0x5cb36a04, 0xc2d7ffa7, 0xb5d0cf31, 0x2cd99e8b, 0x5bdeae1d,
    0x9b64c2b0, 0xec63f226, 0x756aa39c, 0x026d930a, 0x9c0906a9, 0xeb0e363f,
    0x72076785, 0x05005713, 0x95bf4a82, 0xe2b87a14, 0x7bb12bae, 0x0cb61b38,
    0x92d28e9b, 0xe5d5be0d, 0x7cdcefb7, 0x0bdbdf21, 0x86d3d2d4, 0xf1d4e242,
    0x68ddb3f8, 0x1fda836e, 0x81be16cd, 0xf6b9265b, 0x6fb077e1, 0x18b74777,
    0x88085ae6, 0xff0f6a70, 0x66063bca, 0x11010b5c, 0x8f659eff, 0xf862ae69,
    0x616bffd3, 0x166ccf45, 0xa00ae278, 0xd70dd2ee, 0x4e048354, 0x3903b3c2,
    0xa7672661, 0xd06016f7, 0x4969474d, 0x3e6e77db, 0xaed16a4a, 0xd9d65adc,
    0x40df0b66, 0x37d83bf0, 0xa9bcae53, 0xdebb9ec5, 0x47b2cf7f, 0x30b5ffe9,
    0xbdbdf21c, 0xcabac28a, 0x53b39330, 0x24b4a3a6, 0xbad03605, 0xcdd70693,
    0x54de5729, 0x23d967bf, 0xb3667a2e, 0xc4614ab8, 0x5d681b02, 0x2a6f2b94,
    0xb40bbe37, 0xc30c8ea1, 0x5a05df1b, 0x2d02ef8d
};

void update_check_crc32(uint8_t *buf, int len) 
{
    uint8_t *p = NULL;
    
    for ( p = buf; len > 0; ++p, --len ) 
    {
        g_crc32 = (uint32_t)(crc32_table[(g_crc32 ^ *p ) & 0xFF] ^ (g_crc32 >> 8));
    }
}

/**
 * @brief  : 拷贝对象简称
 * @param   [in] file_type 文件类型
 * @param   [in] chip_role 芯片角色
 * @param   [in] *p_object 对象字符
 * @return  0:正常
 */
uint16_t update_obj_cpy(uint8_t file_type, uint8_t chip_role, int8_t *p_object)
{
    uint8_t i = 0;

    // 匹配文件类型编码与芯片角色编码，新旧编码进行匹配，用于兼容旧编码
    for (i = 0; i < UPDATE_OBJECT_NUM; i++)
    {
        // 新格式芯片角色编码 芯片角色编码一致
        if ((file_type == g_role_coding_new[i].file_number) && (chip_role == g_role_coding_new[i].obj_number))
        {
            strncpy((char *)p_object, (char *)g_role_coding_new[i].module_object, 8);
            return 0;
        }
    }
    return -1;
}

// 对固件包进行CRC32校验 以1k为单位进行crc校验
uint32_t firmware_crc32_calculate(const int8_t *path,const uint32_t length,const uint8_t negate)
{
	g_crc32 = 0xFFFFFFFF;
	uint32_t i = 0;
    uint16_t read_len;
	uint8_t data[DATA_LENGTH + 4]={0};
	FILE *fp = NULL;
    uint32_t seg_num;
    uint32_t total_len = 0;

	if((fp = fopen((char *)path,"r")) == NULL)
	{
		print_log("%s\n", strerror(errno));
		return 1;
	}

    seg_num = (length % DATA_LENGTH == 0) ? (length / DATA_LENGTH) : (length / DATA_LENGTH + 1);
	for(i=0; i<seg_num; i++)	// length>>10 <==> length/1024; 注意：打印uint64_t的数值时要用%llu
	{
		memset(data, 0, sizeof(data));	
        if(length - total_len < DATA_LENGTH)  //最后一个包
        {
            read_len = fread(data, 1, (length - total_len), fp);
        }
        else
        {
		    read_len = fread(data, 1, DATA_LENGTH, fp);
        }
        total_len += read_len;
		update_check_crc32(data, read_len);
	}
	
	fclose(fp);
    if(negate == 1)
    {
	    return ~g_crc32;
    }
    else
    {
        return g_crc32;
    }
}

static int8_t check_package(const uint8_t *package_path)
{
    FILE *fp;
    uint32_t filesize = -1;	
	struct stat statbuff;
    int32_t len;
    uint32_t crc32;
    int8_t data[SIGNING_MSG_LENGTH] = {0};

	if(stat((const char *)package_path, &statbuff) < 0){
        print_log("stat %s failed",package_path);
		return -1;
	}else{
		filesize = statbuff.st_size;
	}
    
    fp = fopen((const char*)package_path,"r");
    if(fp == NULL)
    {
        print_log("open %s failed",package_path);
        return -1;
    }

    if(fseek(fp, filesize-SIGNING_MSG_LENGTH, SEEK_SET) != 0)
	{
		print_log("%s\n", strerror(errno));
		fclose(fp);
		return -1;
	}
	if(fread(data, SIGNING_MSG_LENGTH, 1, fp) != 1)
	{
		print_log("%s\n", strerror(errno));
		fclose(fp);
		return -1;
	}
	fclose(fp);
    crc32 = firmware_crc32_calculate(package_path,filesize - 4,1);
   
    memcpy(&g_package_V02,data,SIGNING_MSG_LENGTH);
    if(g_package_V02.protocol_version != VERSION)  //打包工具的版本号
    {
        print_log("version is not right");
        return -1;
    }

    if(crc32 != g_package_V02.package_crc32)  //CRC32是否一致
    {
        print_log("crc32 is not right");
        return -1;
    }
    if(g_package_V02.package_length != filesize-SIGNING_MSG_LENGTH)   //长度
    {
        print_log("package length is not right");
        return -1;
    }

    /*验证项目类型和芯片模型代码是不是当前已经配置的,这些参数需要在打包时候进行填写和勾选*/
    if((g_package_V02.product_type_code != TYPE_BESS_MCU_CODE && g_package_V02.product_type_code != TYPE_POWER_MAGIC)\
    || (g_package_V02.product_model_code != MODEL_BESS_MCU_MODEL_CODE && g_package_V02.product_model_code != MODE_POWER_MAGIC))
    {
        printf("\n====product_type_code:%d product_model_code:%d ======\n",g_package_V02.product_type_code,g_package_V02.product_model_code);
        print_log("product type code or model code is not right");
        return -1;
    }
    return 0;
}

static int8_t check_and_upgrade(const int8_t *path,const uint8_t flag)
{
    if((flag != 1) && (flag != 2))
    {
        print_log("flag is not right");
        return  -1;
    }
    FILE *fp;
    FILE *fp_read = NULL;
    FILE *fp_write = NULL;
    int8_t data[DATA_LENGTH];
    uint32_t length;
    char cmd[128];
    uint32_t seg_num;
    uint32_t i;
    uint32_t written;
    uint16_t left_len;
    uint16_t read_len;
    int8_t sign_data[FIRMWARE_SIGN_LEN];
    file_package_signature_t file_package_signature;
    uint32_t crc32;

    fp = fopen((const char*)path,"r");
    if(fp == NULL)
    {
        print_log("open file %s failed",path);
        return -1;
    }
    if(fseek(fp, -FIRMWARE_SIGN_LEN, SEEK_END) != 0)    //负数前移
    {
        print_log("call fseek failed");
        fclose(fp);
        return -1;
    }
    if(fread(sign_data,1,FIRMWARE_SIGN_LEN,fp) != FIRMWARE_SIGN_LEN)
    {
        print_log("call fread failed");
        fclose(fp);
        return -1;
    }
    fclose(fp);

    memcpy(&file_package_signature,sign_data,sizeof(file_package_signature_t));

    if(file_package_signature.protocol_version != VERSION)
    {
        print_log("version error");
        return -1;
    }

    crc32 = firmware_crc32_calculate(path,file_package_signature.file_len,0);
    if(crc32 != file_package_signature.file_crc)
    {
        print_log("crc error");
        return -1;
    }

    length = file_package_signature.file_len;
    if(flag == 1) //升级APP
    {
        fp_write = fopen(WEB_UPLOAD_DIR"/app.tar.gz","w+"); 
    }
    else if(flag == 2) //升级core
    {
        fp_write = fopen(WEB_UPLOAD_DIR"/opt.tar.gz","w+"); 
    }
    if(fp_write == NULL)
    {
        return -1;
    }
    fp_read = fopen((const char*)path,"r");
    if(fp_read == NULL)
    {
        print_log("open file %s failed",path);
        fclose(fp_write);
        return -1;
    }
    seg_num = (length % DATA_LENGTH == 0) ? (length / DATA_LENGTH) : (length / DATA_LENGTH + 1);
    written = 0;
    for(i=0;i<seg_num-1;i++)
    {
        read_len = fread(data,1,DATA_LENGTH, fp_read);
        if(read_len != DATA_LENGTH)
        {
            print_log("%s\n", strerror(errno));
            fclose(fp_write);
            fclose(fp_read);
            return -1;
        }

        if(fwrite(data,1,DATA_LENGTH,fp_write) != DATA_LENGTH)
        {
            print_log("%s\n", strerror(errno));
            fclose(fp_write);
            fclose(fp_read);
            return -1;
        }
        written += DATA_LENGTH;
    }

    left_len = length - written;
    read_len = fread(data, 1, left_len, fp_read);
    if(read_len != left_len)
    {
        print_log("%s\n", strerror(errno));
        fclose(fp_write);
        fclose(fp_read);
        return -1;
    }
    written += fwrite(data,1,left_len,fp_write);
    if(written != length)
    {
        print_log("write last segement failed\n");
        fclose(fp_write);
        fclose(fp_read);
        return -1;
    }
   
    fclose(fp_write);
    fclose(fp_read);

    remove(path); //删除升级包

    if(flag == 1) //升级app
    {
        sprintf(cmd,"tar zxf %s/app.tar.gz -C /user",WEB_UPLOAD_DIR);
        system(cmd);
        sprintf(cmd,"rm -f %s/app.tar.gz",WEB_UPLOAD_DIR);
        system(cmd);
        print_log("upgrade app successful");
    }
    else if(flag == 2) //升级core
    {
        sprintf(cmd,"tar zxf %s/opt.tar.gz -C /opt",WEB_UPLOAD_DIR);
        system(cmd);
        sprintf(cmd,"rm -f %s/opt.tar.gz",WEB_UPLOAD_DIR);
        system(cmd);
        print_log("upgrade core successful");
    }
    return 0;
}

static void check_and_upgrade_firmaware()
{
    firmware_update_t *p_update;
    uint8_t i;
    int8_t mcu1_path[128] = {0};
    uint8_t app_flag;
    uint8_t core_flag;

    app_flag = core_flag = 0;
    p_update = sdk_shm_firmware_update_info_get();
    for (i = 0; i < UPDATE_OBJECT_NUM; i++)
    {
        if ((p_update->file_type[i] == FILE_APP_NUM) && 
            (p_update->chip_role[i] == CMU_MCU1_NUM) && 
            (g_upgrade_type_mcu1 == 1))
        {
            p_update->update_flag[i] = UPDATE_ING;
            sprintf((char *)mcu1_path, WEB_UPLOAD_DIR"/%s", (char *)p_update->module_name[i]);
            if(check_and_upgrade(mcu1_path,1) != 0)
            {
                pthread_mutex_lock(&g_upgrade_mtx);
                g_progress_mcu1 = -1;
                pthread_mutex_unlock(&g_upgrade_mtx);
            }
            else
            {
                app_flag = 1;
                pthread_mutex_lock(&g_upgrade_mtx);
                g_progress_mcu1 = 45;
                p_update->module_percent[i] = 100;
                pthread_mutex_unlock(&g_upgrade_mtx);
            }
        }
       
        if((p_update->file_type[i] == FILE_CORE_NUM) && 
            (p_update->chip_role[i] == CMU_MCU1_NUM) && 
            (g_upgrade_type_mcu1 == 1))
        {
            p_update->update_flag[i] = UPDATE_ING;
            sprintf((char *)mcu1_path, WEB_UPLOAD_DIR"/%s", (char *)p_update->module_name[i]);
            if(check_and_upgrade(mcu1_path,2) != 0)
            {
                pthread_mutex_lock(&g_upgrade_mtx);
                g_progress_mcu1 = -1;
                pthread_mutex_unlock(&g_upgrade_mtx);
            }
            else
            {
                core_flag = 1;
                pthread_mutex_lock(&g_upgrade_mtx);
                g_progress_mcu1 = 75;
                p_update->module_percent[i] = 100;
                pthread_mutex_unlock(&g_upgrade_mtx);
            }
        }
    }
    if(app_flag && core_flag)
    {
        pthread_mutex_lock(&g_upgrade_mtx);
        g_progress_mcu1 = 100;
        pthread_mutex_unlock(&g_upgrade_mtx);
    }
    else if(g_upgrade_type_mcu1 == 1)  //缺少升级文件
    {
        pthread_mutex_lock(&g_upgrade_mtx);
        g_progress_mcu1 = -1;
        pthread_mutex_unlock(&g_upgrade_mtx);
    }
}

int32_t module_firmware_extraction(const int8_t *package_path)
{
    uint8_t total_module;
    uint8_t module_index;
    uint32_t i;
    uint32_t addr = 0;
	uint32_t length = 0;
    int8_t path[128] = {0};
    int8_t data[DATA_LENGTH];
    uint32_t seg_num;
    uint32_t written;
    int16_t read_len;
    uint16_t left_len;
  
    FILE *fp_read = NULL;
	FILE *fp_write = NULL;
    firmware_update_t *p_update;
    
    total_module = g_package_V02.module_total;

    if((fp_read = fopen((const char*)package_path,"rb")) == NULL)
	{
		print_log("%s\n", strerror(errno));
		return -1;
	}

    for(module_index = 0;module_index < total_module;module_index++)
    {
        addr = g_package_V02.firmware_msg[module_index].addr;
        length = g_package_V02.firmware_msg[module_index].length;
        snprintf((char*)path, sizeof(path)-1, WEB_UPLOAD_DIR"/%s", g_package_V02.firmware_msg[module_index].name);

        if((fp_write = fopen((const char*)path,"w+")) == NULL)
		{
			print_log("%s\n", strerror(errno));
			fclose(fp_read);
			return -1;
		}

        if(fseek(fp_read, addr, SEEK_SET) != 0)
		{
			print_log("%s\n", strerror(errno));
			fclose(fp_read);
            fclose(fp_write);
            return -1;
        }

        seg_num = (length % DATA_LENGTH == 0) ? (length / DATA_LENGTH) : (length / DATA_LENGTH + 1);
        written = 0;
        for(i = 0; i < seg_num - 1; i++)	// length>>10 <==> length/1024; 注意：打印uint64_t的数值时要用%llu
        {
            memset(data, 0, sizeof(data));	
            read_len = fread(data,1,DATA_LENGTH, fp_read);
            if(read_len != DATA_LENGTH)
            {
                print_log("%s\n", strerror(errno));
                fclose(fp_write);
                fclose(fp_read);
                return -1;
            }

            if(fwrite(data,1,DATA_LENGTH,fp_write) != DATA_LENGTH)
            {
                print_log("%s\n", strerror(errno));
                fclose(fp_write);
                fclose(fp_read);
                return -1;
            }
            written += DATA_LENGTH;
        }
        left_len = length - written;
        read_len = fread(data, 1, left_len, fp_read);
        if(read_len != left_len)
        {
            print_log("%s\n", strerror(errno));
            fclose(fp_write);
            fclose(fp_read);
            return -1;
        }
        written += fwrite(data,1,left_len,fp_write);
        if(written != length)
        {
            print_log("write last segement failed\n");
            fclose(fp_write);
            fclose(fp_read);
            return -1;
        }
        fclose(fp_write);
#if 0
        //此处无需校验返回值，因为直接可以从全局的进度条进行传递
        check_and_upgrade_firmaware(path);
       
        pthread_mutex_lock(&g_upgrade_mtx);
        g_progress_mcu1 += 20/total_module;
        g_progress_mcu2 += 20/total_module;
        pthread_mutex_unlock(&g_upgrade_mtx);
    #endif
    }
    fclose(fp_read);

    p_update = sdk_shm_firmware_update_info_get();

    memset(p_update->module_name[0], 0, sizeof(p_update->module_name[0]) * UPDATE_OBJECT_NUM);
    memset(p_update->module_object[0], 0, sizeof(p_update->module_object[0]) * UPDATE_OBJECT_NUM);
    memset(p_update->module_object_bak[0], 0, sizeof(p_update->module_object_bak[0]) * UPDATE_OBJECT_NUM);

    // 解包完成后再对共享内存操作
    for (i = 0; i < total_module; i++)
    {
        strncpy((char *)p_update->module_name[i], (char *)g_package_V02.firmware_msg[i].name, sizeof(p_update->module_name[i]) - 1);
        p_update->file_type[i] = g_package_V02.firmware_msg[i].file_type;
        p_update->chip_role[i] = g_package_V02.firmware_msg[i].chip_role;
        printf("file type[%d]:%d\n", i, p_update->file_type[i]);
        printf("chip role[%d]:%d\n", i, p_update->chip_role[i]);
      //  p_update->update_flag[i] = UPDATE_ING;
        if(g_upgrade_type_mcu2 == 1)
        {
            update_obj_cpy(p_update->file_type[i], p_update->chip_role[i], p_update->module_object[i]);
            update_obj_cpy(p_update->file_type[i], p_update->chip_role[i], p_update->module_object_bak[i]);
        }
        if((p_update->file_type[i] == FILE_APP_NUM) && 
            (p_update->chip_role[i] == CMU_MCU2_NUM))  //存在MCU2的APP
        {
            g_mcu2_app_exist = 1;
            if(g_upgrade_type_mcu2 == 1)
            {
                p_update->update_flag[i] = UPDATE_ING;
            }
        }
        if((p_update->file_type[i] == FILE_CORE_NUM) && 
            (p_update->chip_role[i] == CMU_MCU2_NUM))  //存在MCU2的CORE
        {
            g_mcu2_core_exist = 1;
            if(g_upgrade_type_mcu2 == 1)
            {
                p_update->update_flag[i] = UPDATE_ING;
            }
        }
        if((g_upgrade_type_pcs_m == 1) && 
        (p_update->file_type[i] == FILE_APP_NUM) &&
        (p_update->chip_role[i] == PCS_M_NUM || p_update->chip_role[i] == PCS_M_NUM_LEGACY))
        {
            p_update->upgrade_pcs_index = 1;
            strncpy((char *)p_update->module_object[i], "PCS-M", 5);
            strncpy((char *)p_update->module_object_bak[i], "PCS-M", 5);
            if(g_upgrade_type_pcs_m == 1)
            {
                p_update->update_flag[i] = UPDATE_ING;
            }
        }
        if((g_upgrade_type_pcs_s == 1) && 
        (p_update->file_type[i] == FILE_APP_NUM) &&
        (p_update->chip_role[i] == PCS_S_NUM || p_update->chip_role[i] == PCS_S_NUM_LEGACY))
        {
            p_update->upgrade_pcs_index = 1;
            strncpy((char *)p_update->module_object[i], "PCS-S", 5);
            strncpy((char *)p_update->module_object_bak[i], "PCS-S", 5);
            if(g_upgrade_type_pcs_s == 1)
            {
                p_update->update_flag[i] = UPDATE_ING;
            }
        }
    }
    memcpy(p_update->root_path, "/tmp/upload/", 12);
    return 0;
}

void *do_upgrade(void *arg)
{
    int8_t ret;
    firmware_update_t *p_update;
    uint8_t i;

    p_update = sdk_shm_firmware_update_info_get();
    for (i = 0; i < UPDATE_OBJECT_NUM; i++)
    {
        p_update->module_percent[i] = 0;
        p_update->module_result[i] = 0;
        p_update->update_flag[i] = 0;
    }
    g_mcu2_progress_app_last = 0;
    g_mcu2_progress_core_last = 0;
    g_pcs_progress_last = 0;
    g_pcs_progress_m_last = 0;
    g_pcs_progress_s_last = 0;
    
    memset(&g_package_V02,0,sizeof(package_signing_msg_V02_t));
    //package大包校验
    ret = check_package(g_file_path);
    if(ret != 0)
    {
        pthread_mutex_lock(&g_upgrade_mtx);
        g_progress_mcu1 = -1;
        g_progress_mcu2 = -1;
        g_progress_pcs = -1;
        g_progress_pcs_m = -1;
        g_progress_pcs_s = -1;
        pthread_mutex_unlock(&g_upgrade_mtx);
        pthread_exit(NULL);
    }

    pthread_mutex_lock(&g_upgrade_mtx);
    g_progress_mcu1 = 10;
    g_progress_mcu2 = 2;
    g_progress_pcs = 0;
    g_progress_pcs_m = 0;
    g_progress_pcs_s = 0;
    pthread_mutex_unlock(&g_upgrade_mtx);

    //解析为各个小包
    if(module_firmware_extraction(g_file_path) != 0)
    {
        pthread_mutex_lock(&g_upgrade_mtx);
        g_progress_mcu1 = -1;
        g_progress_mcu2 = -1;
        g_progress_pcs = -1;
        g_progress_pcs_m = -1;
        g_progress_pcs_s = -1;
        pthread_mutex_unlock(&g_upgrade_mtx);
        pthread_exit(NULL);
        //return NULL;
    }

    pthread_mutex_lock(&g_upgrade_mtx);
    g_progress_mcu1 = 25;
 //   g_progress_mcu2 = 50;
    pthread_mutex_unlock(&g_upgrade_mtx);

    //小包校验,升级MCU1(如果有),此处无需判断返回值
    check_and_upgrade_firmaware();
   // pthread_exit(NULL);
}

void *lookup_reboot_sta(void *arg)
{
    while(1)
    {
        if(g_reboot_flag == 1)
        {
            sleep(5);
        //    system("reboot -f");
        }
        sleep(2);
    }
}

void do_handle_upload(struct mg_connection* p_nc, const int ev, void* data)
{
    file_info_t *p_info = NULL;
    uint8_t i;
    firmware_update_t *p_update = NULL;
    p_update = sdk_shm_firmware_update_info_get();

    //当事件ev是 MG_EV_HTTP_PART_BEGIN/MG_EV_HTTP_PART_DATA/MG_EV_HTTP_PART_END 时，data类型是mg_http_multipart_part
    struct mg_http_multipart_part *p_mp = NULL;
    if(ev >= MG_EV_HTTP_PART_BEGIN && ev <= MG_EV_HTTP_PART_END)
    {
        p_mp = (struct mg_http_multipart_part*)data;
    }
    switch(ev)
    {
        case MG_EV_HTTP_PART_BEGIN:
            if(p_info == NULL)
            {
                p_info = calloc(1, sizeof(file_info_t));
                if(p_info == NULL)
                {
                    print_log("calloc for file failed");
                    p_nc->flags |= MG_F_SEND_AND_CLOSE;
                    return;
                }
            }
            if( p_mp->file_name != NULL && strlen(p_mp->file_name) > 0)
            {
                strncpy(p_info->file_name, p_mp->file_name, sizeof(p_info->file_name)-1);
                snprintf(p_info->file_path,sizeof(p_info->file_path)-1, WEB_UPLOAD_DIR"/%s", p_mp->file_name);
                strncpy((char *)p_update->package_name, p_mp->file_name, sizeof(p_update->package_name) - 1);

                p_info->fp = fopen(p_info->file_path, "wb+");
                if(p_info->fp == NULL)
                {
                    print_log("open file %s failed",p_info->file_path);
                    p_nc->flags |= MG_F_SEND_AND_CLOSE;
				    free(p_info);
					return;
                }
                p_info->file_size = 0;
                p_nc->user_data = (void *)p_info;
            }
            break;
        case MG_EV_HTTP_PART_DATA:
            p_info = (file_info_t *)p_nc->user_data;
            if(fwrite(p_mp->data.p, 1, p_mp->data.len, p_info->fp) != p_mp->data.len)
            {
                print_log("write file %s failed",p_info->file_path);
                 mg_printf(p_nc,
                        "HTTP/1.1 200 OK\r\n"
                        "Content-Type: text/plain\r\n"
                        "Connection: close\r\n\r\n"
                        "{\"code\":210,\"msg\":\"upload firmware failed\"}\r\n"
                );
                p_nc->flags |= MG_F_SEND_AND_CLOSE;
                free(p_info);
                return;
            }
            p_info->file_size += p_mp->data.len;
            break;
        case MG_EV_HTTP_PART_END:
            p_info = (file_info_t *)p_nc->user_data;
			p_nc->flags |= MG_F_SEND_AND_CLOSE;
			fclose(p_info->fp);
            #if 1
            if(strstr(p_info->file_path,".sofar") && strstr(p_info->file_path,"ESS3M44"))  //属于集中式储能的升级包
            {
                g_progress_mcu1 = 0;
                g_progress_mcu2 = 0;
                g_progress_pcs = 0;
                g_progress_pcs_m = 0;
                g_progress_pcs_s = 0;
                g_reboot_flag = 0;
                g_mcu2_done = 0;
                g_mcu2_app_exist = 0;
                g_mcu2_core_exist = 0;
                strcpy(g_file_path,p_info->file_path);
                for (i = 0; i < UPDATE_OBJECT_NUM; i++)
                {
                    p_update->module_percent[i] = 0;
                    p_update->module_result[i] = 0;
                    p_update->update_flag[i] = 0;
                }
                g_mcu2_progress_app_last = 0;
                g_mcu2_progress_core_last = 0;
                g_pcs_progress_last = 0;
                g_pcs_progress_m_last = 0;
                g_pcs_progress_s_last = 0;
                p_update->state = UPDATE;
            }
            else
            {
                print_log("file name file %s error",p_info->file_path);
                 mg_printf(p_nc,
                        "HTTP/1.1 200 OK\r\n"
                        "Content-Type: text/plain\r\n"
                        "Connection: close\r\n\r\n"
                        "{\"code\":210,\"msg\":\"文件名称错误\"}\r\n"
                );
                p_nc->flags |= MG_F_SEND_AND_CLOSE;
                free(p_info);
                return;
            }
            #endif
            free(p_info);
            sync(); //将数据同步到nand flash上,或者如果使用了tmp文件系统的话就是/tmp目录。也就是内存
             mg_printf(p_nc,
                    "HTTP/1.1 200 OK\r\n"
                    "Content-Type: text/plain\r\n"
                    "Connection: close\r\n\r\n"
                    "{\"code\":200,\"msg\":\"upload firmware successful\"}\r\n"
            );
            break;
        default:
            break;
    }
}

static int32_t safety_file_recognition(uint8_t *safety_name)
{
	int n1, n2, n3;
    int ret = 0; 
    ret = sscanf((char *) safety_name,"EBI-125kW-%d-%d-%d.txt",&n1,&n2,&n3);
    if(3 == ret)
    {
        return 0;
    }
    else
    {
		return -1;
    }
}

static int32_t sdk_system_cmd(int8_t * cmd)
{
    FILE *fp = NULL;

    if((fp=popen(cmd, "r")) == NULL)
    {
        printf("[%s:%s:%d] %s, cmd:%s\n", __FILE__,__func__, __LINE__, strerror(errno), cmd);
        return -1;
    }
    pclose(fp);

    return 0;
}

int32_t safety_firmware_extraction(const int8_t *package_path)
{
    uint8_t total_module;
    uint8_t module_index;
    uint32_t i;
    uint32_t addr = 0;
	uint32_t length = 0;
    int8_t path[128] = {0};
    int8_t data[DATA_LENGTH];
    uint32_t seg_num;
    uint32_t written;
    int16_t read_len;
    uint16_t left_len;
  
    FILE *fp_read = NULL;
	FILE *fp_write = NULL;
    firmware_update_t *p_update;
    
    total_module = g_package_V02.module_total;
    if((fp_read = fopen((const char*)package_path,"rb")) == NULL)
	{
		print_log("%s\n", strerror(errno));
		return -1;
	}
    if(total_module > 1 || g_package_V02.firmware_msg[0].file_type != FILE_SAFETY_NUM)
    {
        fclose(fp_read);
        return -1;
    }
    module_index = 0;
    addr = g_package_V02.firmware_msg[module_index].addr;
    length = g_package_V02.firmware_msg[module_index].length;
    snprintf((char*)path, sizeof(path)-1, "/tmp/%s", g_package_V02.firmware_msg[module_index].name);  // WEB_UPLOAD_DIR
    if((fp_write = fopen((const char*)path,"w+")) == NULL)
    {
        print_log("%s\n", strerror(errno));
        fclose(fp_read);
        return -1;
    }
    if(fseek(fp_read, addr, SEEK_SET) != 0)
    {
        print_log("%s\n", strerror(errno));
        fclose(fp_read);
        fclose(fp_write);
        return -1;
    }
    seg_num = (length % DATA_LENGTH == 0) ? (length / DATA_LENGTH) : (length / DATA_LENGTH + 1);
    written = 0;
    for(i = 0; i < seg_num - 1; i++)	// length>>10 <==> length/1024; 注意：打印uint64_t的数值时要用%llu
    {
        memset(data, 0, sizeof(data));	
        read_len = fread(data,1,DATA_LENGTH, fp_read);
        if(read_len != DATA_LENGTH)
        {
            print_log("%s\n", strerror(errno));
            fclose(fp_write);
            fclose(fp_read);
            return -1;
        }
        if(fwrite(data,1,DATA_LENGTH,fp_write) != DATA_LENGTH)
        {
            print_log("%s\n", strerror(errno));
            fclose(fp_write);
            fclose(fp_read);
            return -1;
        }
        written += DATA_LENGTH;
    }
    left_len = length - written;
    read_len = fread(data, 1, left_len, fp_read);
    if(read_len != left_len)
    {
        print_log("%s\n", strerror(errno));
        fclose(fp_write);
        fclose(fp_read);
        return -1;
    }
    written += fwrite(data,1,left_len,fp_write);
    if(written != length)
    {
        print_log("write last segement failed\n");
        fclose(fp_write);
        fclose(fp_read);
        return -1;
    }
    fclose(fp_write);
    fclose(fp_read);
    sync();
    return 0;
}

static int32_t safety_file_import(uint8_t *safety_name)
{
	safety_attr_t safety_attr = {0};
	int32_t ret = 1;
	uint8_t safety_path[64] ={0};
	uint8_t cmd[128] = {0};
    int8_t ret1 = -1;
    operation_log_t op_log = {0};
	constant_parameter_data_t *p_constant_parameter = sdk_shm_constant_parameter_data_get();
	internal_shared_data_t *p_internal_shared = internal_shared_data_get();
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();
	
	print_log("safety_name = %s\n",safety_name); 
    snprintf((char*)safety_path , sizeof(safety_path), "%s%s", "/tmp/", safety_name);
    // txt文件
	if(safety_file_recognition(safety_name) == 0)
	{
		snprintf((char*)safety_path , sizeof(safety_path), "%s%s", "/tmp/", safety_name);
		ret = sdk_safety_txt_to_bin(safety_path, "/tmp/safety.bin", &safety_attr, 0);
		print_log("ret = %d\n",ret);
        init_user_basic_info(&op_log);
        strcpy(op_log.user_name, safety_cur_user);
        get_user_basic_info(&op_log);
        strcpy(op_log.op_type,"导入单个安规文件(.txt)");
		if (0 == ret)
		{
            strcpy(op_log.op_status,"success");
	    	snprintf((char*)cmd, sizeof(cmd), "mv /tmp/safety.bin /user/data/cfg/safety");
   		    sdk_system_cmd((int8_t *)cmd);	
            
            p_constant_parameter->safety_rdr_country = safety_attr.region;
            p_constant_parameter->ver_safety_rdr_para = safety_attr.version;
            p_internal_shared->safety_update_flag = 1;
            p_telematic_data->container_system_warn_info[0] &= ~(1<<2);
		}
        else
        {
            strcpy(op_log.op_status,"failed");
        }
		add_one_op_log(&op_log);
        snprintf((char*)cmd, sizeof(cmd), "rm /tmp/%s",safety_name);
   		sdk_system_cmd((int8_t *)cmd);	
	}
    // bin文件
    else if (strstr(safety_name, ".bin"))
	{	
        init_user_basic_info(&op_log);
        strcpy(op_log.user_name, safety_cur_user);
        get_user_basic_info(&op_log);
        strcpy(op_log.op_type,"导入安规库(.bin)");
		ret = safety_lib_import((char *)safety_name);
        if(0 == ret)
        {
            strcpy(op_log.op_status,"success");   
        }
        else
        {
            strcpy(op_log.op_status,"failed");
        }
        add_one_op_log(&op_log);
        snprintf((char*)cmd, sizeof(cmd), "rm /tmp/%s",safety_name);
   		sdk_system_cmd((int8_t *)cmd);	
	}
    // .sofar文件
    else if(strstr(safety_name, ".sofar"))
    {
        init_user_basic_info(&op_log);
        strcpy(op_log.user_name, safety_cur_user);
        get_user_basic_info(&op_log);
        strcpy(op_log.op_type,"导入安规库(.sofar)");

        memset(&g_package_V02,0,sizeof(package_signing_msg_V02_t));
        ret1 = check_package(safety_path);
        if(ret1 != 0)
        {
            strcpy(op_log.op_status,"failed");
            add_one_op_log(&op_log);
            return ret1;
        }
        ret = safety_firmware_extraction(safety_path);
        if(ret == 0)
        {
            ret = safety_lib_import((char *)g_package_V02.firmware_msg[0].name);
            if(ret == 0)
            {
                strcpy(op_log.op_status,"success");   
            }
            else
            {
                strcpy(op_log.op_status,"failed");
            }
        }
        else
        {
            strcpy(op_log.op_status,"failed");
        }
        add_one_op_log(&op_log);
        snprintf((char*)cmd, sizeof(cmd), "rm /tmp/%s /tmp/%s",g_package_V02.firmware_msg[0].name,safety_name);
   		sdk_system_cmd((int8_t *)cmd);	
        
    }

	print_log("safety_attr.region = %d safety_attr.version = %d \n",safety_attr.region, safety_attr.version);
	print_log("ret %d\n",ret);
	return ret;
}

void safety_upload(struct mg_connection* nc, const int ev, void* data)
{
    cJSON *p_resp_root;
	cJSON *p_resp_item;
    uint8_t response[128];
    uint8_t *p;
    uint8_t request_body[1024] = {0};
	uint8_t safety_path[128] = {0};
	safety_attr_t safety_attr;
	int32_t ret;
	firmware_update_t *firmware_update = sdk_shm_firmware_update_info_get();
	
	//用户指针，用于保存文件大小，文件名
    struct FileInfo *userData = NULL;
 
    //当事件ev是 MG_EV_HTTP_MULTIPART_REQUEST 时，data类型是http_message
    struct http_message *httpMsg = NULL;
    if(MG_EV_HTTP_MULTIPART_REQUEST == ev)
    {
        httpMsg = (struct http_message*)data;
        get_user_from_http_request(httpMsg, safety_cur_user);
        //初次请求时，申请内存
        if(userData ==  NULL)
        {
            userData = (struct FileInfo *)malloc(sizeof(struct FileInfo));
            memset(userData, 0, sizeof(struct FileInfo));
        }
    }
    else // 已经不是第一次请求了，nc->user_data 先前已经指向 userData，所以可以用了
    {
        userData = (struct FileInfo *)nc->user_data;
    }
 
    //当事件ev是 MG_EV_HTTP_PART_BEGIN/MG_EV_HTTP_PART_DATA/MG_EV_HTTP_PART_END 时，data类型是mg_http_multipart_part
    struct mg_http_multipart_part *httpMulMsg = NULL;
    if(ev >= MG_EV_HTTP_PART_BEGIN && ev <= MG_EV_HTTP_PART_END)
    {
        httpMulMsg = (struct mg_http_multipart_part*)data;
    }
 
    switch(ev) 
    {
        case MG_EV_HTTP_MULTIPART_REQUEST:
            {   
                ///query_string为请求地址中的变量
                char filePath[32] = {0};
      
                //从请求地址里获取 key 对应的值，所以这个需要和请求地址里的 key 一样
                //这里从地址中获取文件要上传到哪个
                if(mg_get_http_var(&httpMsg->query_string, "filePath", filePath, sizeof(filePath)) > 0) 
                {
                   print_log("upload file request, %s = %s\n", "filePath", filePath); 
                }
                //保存路径，且 nc->user_data 指向该内存，下次请求就可以直接用了
                if(userData != NULL)
                {
                    snprintf(userData->filePath, sizeof(userData->filePath), "%s", filePath);
                    nc->user_data = (void *)userData;                 
                }
            }
 
            break;
        case MG_EV_HTTP_PART_BEGIN:  ///这一步获取文件名
            print_log("upload file begin!\n");
            if(httpMulMsg->file_name != NULL && strlen(httpMulMsg->file_name) > 0)
            {
                print_log("input fileName = %s\n", httpMulMsg->file_name);
                //保存文件名，且新建一个文件
                if(userData != NULL)
                {
                    //snprintf(userData->fileName, sizeof(userData->fileName), "%s%s", userData->filePath, httpMulMsg->file_name);
                    snprintf(userData->fileName, sizeof(userData->fileName), "%s%s", "/tmp/", httpMulMsg->file_name);
                    userData->fp = fopen(userData->fileName, "wb+");
 
                    //创建文件失败，回复，释放内存
                    if(userData->fp == NULL) 
                    {
                        mg_printf(nc, "%s", 
                            "HTTP/1.1 500 file fail\r\n"
                            "Content-Length: 25\r\n"
                            "Connection: close\r\n\r\n"
                            "Failed to open a file\r\n");
 
                        nc->flags |= MG_F_SEND_AND_CLOSE;
                        free(userData);
                        nc->user_data = NULL;     
                        return;
                    }                    
                }
 
            }
            break;
        case MG_EV_HTTP_PART_DATA:
            // tracef("upload file chunk size = %lu\n", httpMulMsg->data.len);
            if(userData != NULL && userData->fp != NULL) 
            {
                size_t ret = fwrite(httpMulMsg->data.p, 1, httpMulMsg->data.len, userData->fp);
                if(ret != httpMulMsg->data.len)
                {
                    mg_printf(nc, "%s",
                    "HTTP/1.1 500 write fail\r\n"
                    "Content-Length: 29\r\n\r\n"
                    "Failed to write to a file\r\n");
 
                    nc->flags |= MG_F_SEND_AND_CLOSE;
                    return;
                }     
            }
            break;
        case MG_EV_HTTP_PART_END:
            print_log("file transfer end!\n");
			snprintf((char*)firmware_update->module_name[0], 52, "%s", httpMulMsg->file_name);
            if(userData != NULL && userData->fp != NULL)
            {
            	if(userData->fp)
				{
					fclose(userData->fp);
					userData->fp = NULL;
				}
				
				p_resp_root = cJSON_CreateObject();
				if(p_resp_root != NULL)
				{
					
					ret =  safety_file_import((uint8_t *)httpMulMsg->file_name);
					if (0 == ret)
					{
                        print_log("file transfer succeed\n");
						cJSON_AddNumberToObject(p_resp_root,"code",200);
						cJSON_AddStringToObject(p_resp_root,"msg","upload Safety successful");
						p = cJSON_PrintUnformatted(p_resp_root);
					}else{
						print_log("file transfer fail, ret %d\n",ret);
						cJSON_AddNumberToObject(p_resp_root,"code",203);
						cJSON_AddStringToObject(p_resp_root,"msg","upload Safety parse error");
						p = cJSON_PrintUnformatted(p_resp_root);
					}
					
					http_back(nc,p);
					cJSON_Delete(p_resp_root);
					free(p);
				}
                //设置标志，发送完成数据（如果有）并且关闭连接
                nc->flags |= MG_F_SEND_AND_CLOSE;
                
                //关闭文件，释放内存
                if(userData->fp)
                 fclose(userData->fp);
                print_log("upload file end, free userData(%p)\n", userData);
                free(userData);
                nc->user_data = NULL;       
            }           
            break;
        case MG_EV_HTTP_MULTIPART_REQUEST_END:
            print_log("http multipart request end!\n");
            break;
        default:
            break;

    	}
}

void set_upgrade_devices(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_type_array;
    uint8_t i;
    uint8_t j;
    uint8_t *p_action;
    uint8_t response[64];
    uint8_t request_body[1024] = {0};
    firmware_update_t *p_update = sdk_shm_firmware_update_info_get();

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"deviceList"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    // if(cJSON_GetObjectItem(p_request,"sofarOta") != NULL)
    // {
    //     p_update->state = 6;        //云平台升级
    // }
    g_upgrade_type_mcu1 = 0;
    g_upgrade_type_mcu2 = 0;
    g_upgrade_type_pcs = 0;
    g_upgrade_type_pcs_m = 0;
    g_upgrade_type_pcs_s = 0;
    
    p_update->module_update_flag = 0;
    p_type_array = cJSON_GetObjectItem(p_request,"type");
    for(i=0;i<cJSON_GetArraySize(p_type_array);i++)
    {
        if(!strcmp(cJSON_GetArrayItem(p_type_array,i)->valuestring,"mcu1"))
        {
            BIT_SET(p_update->module_update_flag,MCU1_UPDATE);
            g_upgrade_type_mcu1 = 1;
        }
        else if(!strcmp(cJSON_GetArrayItem(p_type_array,i)->valuestring,"mcu2"))
        {
            BIT_SET(p_update->module_update_flag,MCU2_UPDATE);
            g_upgrade_type_mcu2 = 1;
        }
        else if(!strcmp(cJSON_GetArrayItem(p_type_array,i)->valuestring,"pcs"))
        {
            BIT_SET(p_update->module_update_flag,PCS_UPDATE);
            g_upgrade_type_pcs = 1;  //工商业储能,增加对PCS的升级
        }
        else if(!strcmp(cJSON_GetArrayItem(p_type_array,i)->valuestring,"pcs-m"))
        {
            BIT_SET(p_update->module_update_flag,DSPM_UPDATE);
            g_upgrade_type_pcs_m = 1;  //工商业储能,升级主DSP
        }
        else if(!strcmp(cJSON_GetArrayItem(p_type_array,i)->valuestring,"pcs-s"))
        {
            BIT_SET(p_update->module_update_flag,DSPS_UPDATE);
            g_upgrade_type_pcs_s = 1;  //工商业储能,升级副DSP
        }
    }
    cJSON_Delete(p_request);

    if(BIT_GET(p_update->module_update_flag,MCU1_UPDATE) || BIT_GET(p_update->module_update_flag,MCU2_UPDATE)\
    || BIT_GET(p_update->module_update_flag,PCS_UPDATE) || BIT_GET(p_update->module_update_flag,DSPM_UPDATE)\
    || BIT_GET(p_update->module_update_flag,DSPS_UPDATE))
    {
        build_empty_response(response,200,"set device list successful");
    }
    else
    {
        build_empty_response(response,210,"set device list failed");
    }

    http_back(p_nc,response);
}

void get_upgrade_progress(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
    uint8_t response[128];
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    uint8_t type[8];
    firmware_update_t *p_update;
    uint8_t i;
    int8_t progress_mcu1_app = -1;
    int8_t progress_mcu1_core = -1;

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
    {
        strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
    }
    else
    {
        memcpy(request_body,p_msg->body.p,p_msg->body.len);		
    }
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        print_log("parse request failed.");
        build_empty_response(response,202,"parse request failed.");
        http_back(p_nc,response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action,"getUpgradeProgress"))
    {
        print_log("action is not right.");
        build_empty_response(response,203,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }

    strcpy(type,cJSON_GetObjectItem(p_request,"type")->valuestring);

    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed.");
        return;
    }
    cJSON_AddNumberToObject(p_resp_root,"code",200);
    p_update = sdk_shm_firmware_update_info_get();
    if(!strcmp(type,"mcu1")) 
    {
        if(BIT_GET(p_update->module_update_flag,MCU1_UPDATE) == 0)
        {
            cJSON_AddNumberToObject(p_resp_root,"progress",-1);
            cJSON_AddStringToObject(p_resp_root,"msg","mcu1升级失败");
            goto END;
        }
        // else if((BIT_GET(p_update->module_update_flag,MCU1_UPDATE) == 1) &&\
        // (BIT_GET(p_update->module_update_flag,MCU1_APP_UPDATE) == 0) &&\
        // (BIT_GET(p_update->module_update_flag,MCU1_CORE_UPDATE) == 0))
        // {
        //     cJSON_AddNumberToObject(p_resp_root,"progress",-1);
        //     cJSON_AddStringToObject(p_resp_root,"msg","mcu1升级失败");
        //     goto END;
        // }
        for (i = 0; i < UPDATE_OBJECT_NUM; i++)
        {

            if ((p_update->file_type[i] == FILE_APP_NUM) && (p_update->chip_role[i] == CMU_MCU1_NUM))
            {
                if(p_update->update_flag[i] == 2 || p_update->module_percent[i] == -1)
                {
                    p_update->update_flag[i] = 0;
                    print_log("p_update->update_flag = 2");
                    cJSON_AddNumberToObject(p_resp_root,"progress",-1);
                    cJSON_AddStringToObject(p_resp_root,"msg","mcu1升级失败");
                    goto END;
                }
                progress_mcu1_app = p_update->module_percent[i];
            }
            if ((p_update->file_type[i] == FILE_CORE_NUM) && (p_update->chip_role[i] == CMU_MCU1_NUM))
            {
                if(p_update->update_flag[i] == 2 || p_update->module_percent[i] == -1)
                {
                    p_update->update_flag[i] = 0;
                    print_log("p_update->update_flag = 2");
                    cJSON_AddNumberToObject(p_resp_root,"progress",-1);
                    cJSON_AddStringToObject(p_resp_root,"msg","mcu1升级失败");
                    goto END;
                }
                progress_mcu1_core = p_update->module_percent[i];
            }
        }
        if((BIT_GET(p_update->module_update_flag,MCU1_APP_UPDATE) == 1) && (BIT_GET(p_update->module_update_flag,MCU1_CORE_UPDATE) == 1))  //app和core都存在
        {
            g_progress_mcu1 = (progress_mcu1_app + progress_mcu1_core)/2;
        }
        else if((BIT_GET(p_update->module_update_flag,MCU1_APP_UPDATE) == 1) && (BIT_GET(p_update->module_update_flag,MCU1_CORE_UPDATE) == 0))   //只有app
        {
            g_progress_mcu1 = progress_mcu1_app;
        }
        else if((BIT_GET(p_update->module_update_flag,MCU1_APP_UPDATE) == 0) && (BIT_GET(p_update->module_update_flag,MCU1_CORE_UPDATE) == 1))   //只有core
        {
            g_progress_mcu1 = progress_mcu1_core;
        }
        cJSON_AddNumberToObject(p_resp_root,"progress",g_progress_mcu1);
        
        if(g_progress_mcu1 == 100)
        {
            cJSON_AddStringToObject(p_resp_root,"msg","mcu1升级成功");
        }
        else if(g_progress_mcu1 == -1)
        {
            cJSON_AddStringToObject(p_resp_root,"msg","mcu1升级失败");
        }
    }
    else if(!strcmp(type,"pcs"))    //获取PCS的升级进度
    {
        pthread_mutex_lock(&g_upgrade_mtx);
        if(g_progress_pcs == -1)
        {
            print_log("g_progress_pcs = -1");
            cJSON_AddNumberToObject(p_resp_root,"progress",-1);
            cJSON_AddStringToObject(p_resp_root,"msg","PCS升级失败");
            pthread_mutex_unlock(&g_upgrade_mtx);
            goto END;
        }
        pthread_mutex_unlock(&g_upgrade_mtx);
        p_update = sdk_shm_firmware_update_info_get();
        for (i = 0; i < UPDATE_OBJECT_NUM; i++)
        {
            if((p_update->update_flag[i] == 2) &&
            (p_update->file_type[i] == FILE_APP_NUM) &&
                (p_update->chip_role[i] == PCS_M_NUM))
            {
                p_update->update_flag[i] = 0;
                print_log("p_update->update_flag = 2");
                cJSON_AddNumberToObject(p_resp_root,"progress",-1);
                cJSON_AddStringToObject(p_resp_root,"msg","PCS升级失败");
                goto END;
            }
              //如果是PCS的升级，并且读取到的共享内存升级进度在0~100范围内,并且本次读取到得数据不小于上一次读取到的数据,才更新g_pcs_progress_last
            //为什么?因为临界区问题,有可能会发生其他进程写共享内存时,这里来读,读到的值不正确！！！
            if ((p_update->file_type[i] == FILE_APP_NUM) && 
            (p_update->chip_role[i] == PCS_M_NUM) &&
             (p_update->module_percent[i] >= 0) && 
             (p_update->module_percent[i] <= 100) && 
             (p_update->module_percent[i] >= g_pcs_progress_last))
            {
                g_pcs_progress_last = p_update->module_percent[i];
            }
            if(g_pcs_progress_last == 100)
            {
                g_pcs_done = 1;
                cJSON_AddNumberToObject(p_resp_root,"progress",100);
                goto END;
            }
            else
            {
                cJSON_AddNumberToObject(p_resp_root,"progress", g_pcs_progress_last);
            }
        }
    }
    else if(!strcmp(type,"pcs-dspm"))    //获取主DSP升级进度
    {
        pthread_mutex_lock(&g_upgrade_mtx);
        if(g_progress_pcs_m == -1)
        {
            print_log("g_progress_pcs_m = -1");
            cJSON_AddNumberToObject(p_resp_root,"progress",-1);
            cJSON_AddStringToObject(p_resp_root,"msg","主DSP升级失败");
            pthread_mutex_unlock(&g_upgrade_mtx);
            goto END;
        }
        pthread_mutex_unlock(&g_upgrade_mtx);
        p_update = sdk_shm_firmware_update_info_get();
        for (i = 0; i < UPDATE_OBJECT_NUM; i++)
        {
            if((p_update->update_flag[i] == 2) &&
            (p_update->file_type[i] == FILE_APP_NUM) &&
                (p_update->chip_role[i] == PCS_M_NUM || p_update->chip_role[i] == PCS_M_NUM_LEGACY))
            {
                p_update->update_flag[i] = 0;
                g_progress_pcs_m == -1;
                print_log("p_update->update_flag = 2");
                cJSON_AddNumberToObject(p_resp_root,"progress",-1);
                cJSON_AddStringToObject(p_resp_root,"msg","主DSP升级失败");
                goto END;
            }
              //如果是PCS的升级，并且读取到的共享内存升级进度在0~100范围内,并且本次读取到得数据不小于上一次读取到的数据,才更新g_pcs_progress_last
            //为什么?因为临界区问题,有可能会发生其他进程写共享内存时,这里来读,读到的值不正确！！！
            if ((p_update->file_type[i] == FILE_APP_NUM) && 
            (p_update->chip_role[i] == PCS_M_NUM || p_update->chip_role[i] == PCS_M_NUM_LEGACY) &&
             (p_update->module_percent[i] >= 0) && 
             (p_update->module_percent[i] <= 100) && 
             (p_update->module_percent[i] >= g_pcs_progress_m_last))
            {
                g_pcs_progress_m_last = p_update->module_percent[i];
            }
        }
        if(g_pcs_progress_m_last == 100)
        {
            g_pcs_m_done = 1;
            cJSON_AddNumberToObject(p_resp_root,"progress",100);
            cJSON_AddStringToObject(p_resp_root,"msg","主DSP升级成功");
        }
        else
        {
            cJSON_AddNumberToObject(p_resp_root,"progress", g_pcs_progress_m_last);
        }
    }
    else if(!strcmp(type,"pcs-dsps"))    //获取副DSP升级进度
    {
        pthread_mutex_lock(&g_upgrade_mtx);
        if(g_progress_pcs_s == -1)
        {
            print_log("g_progress_pcs_s = -1");
            cJSON_AddNumberToObject(p_resp_root,"progress",-1);
            cJSON_AddStringToObject(p_resp_root,"msg","副DSP升级失败");
            pthread_mutex_unlock(&g_upgrade_mtx);
            goto END;
        }
        pthread_mutex_unlock(&g_upgrade_mtx);
        p_update = sdk_shm_firmware_update_info_get();
        for (i = 0; i < UPDATE_OBJECT_NUM; i++)
        {
            if((p_update->update_flag[i] == 2) &&
            (p_update->file_type[i] == FILE_APP_NUM) &&
                (p_update->chip_role[i] == PCS_S_NUM || p_update->chip_role[i] == PCS_S_NUM_LEGACY))
            {
                p_update->update_flag[i] = 0;
                g_progress_pcs_s == -1;
                print_log("p_update->update_flag = 2");
                cJSON_AddNumberToObject(p_resp_root,"progress",-1);
                cJSON_AddStringToObject(p_resp_root,"msg","副DSP升级失败");
                goto END;
            }
              //如果是PCS的升级，并且读取到的共享内存升级进度在0~100范围内,并且本次读取到得数据不小于上一次读取到的数据,才更新g_pcs_progress_last
            //为什么?因为临界区问题,有可能会发生其他进程写共享内存时,这里来读,读到的值不正确！！！
            if ((p_update->file_type[i] == FILE_APP_NUM) && 
            (p_update->chip_role[i] == PCS_S_NUM || p_update->chip_role[i] == PCS_S_NUM_LEGACY) &&
             (p_update->module_percent[i] >= 0) && 
             (p_update->module_percent[i] <= 100) && 
             (p_update->module_percent[i] >= g_pcs_progress_s_last))
            {
                g_pcs_progress_s_last = p_update->module_percent[i];
            }
        }    
        if(g_pcs_progress_s_last == 100)
        {
            g_pcs_s_done = 1;
            cJSON_AddNumberToObject(p_resp_root,"progress",100);

            cJSON_AddStringToObject(p_resp_root,"msg","副DSP升级成功");
        }
        else
        {
            cJSON_AddNumberToObject(p_resp_root,"progress", g_pcs_progress_s_last);
        }
    }
    else if(!strcmp(type,"mcu2"))
    {   
        pthread_mutex_lock(&g_upgrade_mtx);
        if(g_progress_mcu2 == -1)
        {
            print_log("g_progress_mcu2 = -1");
            cJSON_AddNumberToObject(p_resp_root,"progress",-1);
            cJSON_AddStringToObject(p_resp_root,"msg","MCU2升级失败");
            pthread_mutex_unlock(&g_upgrade_mtx);
            goto END;
        }
        pthread_mutex_unlock(&g_upgrade_mtx);

        p_update = sdk_shm_firmware_update_info_get();
        for (i = 0; i < UPDATE_OBJECT_NUM; i++)
        {
            if((p_update->update_flag[i] == 2) &&
            (p_update->file_type[i] == FILE_APP_NUM) &&
                (p_update->chip_role[i] == CMU_MCU2_NUM))
            {
                p_update->update_flag[i] = 0;
                print_log("p_update->update_flag = 2");
                cJSON_AddNumberToObject(p_resp_root,"progress",-1);
                cJSON_AddStringToObject(p_resp_root,"msg","MCU2 APP升级失败");
                goto END;
            }

            if((p_update->update_flag[i] == 2) &&
            (p_update->file_type[i] == FILE_CORE_NUM) &&
                (p_update->chip_role[i] == CMU_MCU2_NUM))
            {
                p_update->update_flag[i] = 0;
                print_log("p_update->update_flag = 2");
                cJSON_AddNumberToObject(p_resp_root,"progress",-1);
                cJSON_AddStringToObject(p_resp_root,"msg","MCU2 CORE升级失败");
                goto END;
            }

            //如果是MCU2的升级，并且读取到的共享内存升级进度在0~100范围内,并且本次读取到得数据不小于上一次读取到的数据,才更新g_mcu2_progress_app_last
            //为什么?因为临界区问题,有可能会发生其他进程写共享内存时,这里来读,读到的值不正确！！！
            if ((p_update->file_type[i] == FILE_APP_NUM) && 
            (p_update->chip_role[i] == CMU_MCU2_NUM) &&
             (p_update->module_percent[i] >= 0) && 
             (p_update->module_percent[i] <= 100) && 
             (p_update->module_percent[i] >= g_mcu2_progress_app_last))
            {
                g_mcu2_progress_app_last = p_update->module_percent[i];
            }

            //如果是MCU2的升级，并且读取到的共享内存升级进度在0~100范围内,并且本次读取到得数据不小于上一次读取到的数据,才更新g_mcu2_progress_core_last
            //为什么?因为临界区问题,有可能会发生其他进程写共享内存时,这里来读,读到的值不正确！！！
            if ((p_update->file_type[i] == FILE_CORE_NUM) && 
            (p_update->chip_role[i] == CMU_MCU2_NUM) &&
             (p_update->module_percent[i] >= 0) && 
             (p_update->module_percent[i] <= 100) && 
             (p_update->module_percent[i] >= g_mcu2_progress_core_last))
            {
                g_mcu2_progress_core_last = p_update->module_percent[i];
            }
        }
        if(((g_mcu2_progress_app_last == 100) && (g_mcu2_progress_core_last == 100) && (g_mcu2_app_exist == 1) && (g_mcu2_core_exist == 1)) ||
           ((g_mcu2_app_exist == 1) && (g_mcu2_core_exist == 0) && (g_mcu2_progress_app_last == 100)) ||
            ((g_mcu2_core_exist == 1) && (g_mcu2_app_exist == 0) && (g_mcu2_progress_core_last == 100)) )
        {
            g_mcu2_done = 1;
            cJSON_AddNumberToObject(p_resp_root,"progress",100);
            cJSON_AddStringToObject(p_resp_root,"msg","MCU2升级成功");
        }
        else if((BIT_GET(p_update->module_update_flag,MCU2_APP_UPDATE) == 1) && (BIT_GET(p_update->module_update_flag,MCU2_CORE_UPDATE) == 1))  //app和core都存在
        {
            cJSON_AddNumberToObject(p_resp_root,"progress",(g_mcu2_progress_app_last + g_mcu2_progress_core_last)/2);
        }
        else if((BIT_GET(p_update->module_update_flag,MCU2_APP_UPDATE) == 1) && (BIT_GET(p_update->module_update_flag,MCU2_CORE_UPDATE) == 0))   //只有app
        {
            cJSON_AddNumberToObject(p_resp_root,"progress",g_mcu2_progress_app_last);
        }
        else if((BIT_GET(p_update->module_update_flag,MCU2_APP_UPDATE) == 0) && (BIT_GET(p_update->module_update_flag,MCU2_CORE_UPDATE) == 1))   //只有core
        {
            cJSON_AddNumberToObject(p_resp_root,"progress",g_mcu2_progress_core_last);
        }
    }
END:
    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);
    cJSON_Delete(p_resp_root);
    free(p);
    http_back(p_nc,response);
}

/**
 * @brief 升级模块初始化
 * @return void
 */
void upgrade_module_init(void)
{
    /*下发升级列表*/
	if(!web_func_attach("/upgrade/deviceList", set_upgrade_devices))
	{
		print_log("[/upgrade/deviceList] attach failed");
	}
	/*获取升级进度*/
	if(!web_func_attach("/upgrade/getUpgradeProgress", get_upgrade_progress))
	{
		print_log("[/upgrade/getUpgradeProgress] attach failed");
	}
	/*usb升级*/
	if(!web_func_attach("/upgrade/usbUpgrade", do_usb_upgrade))
	{
		print_log("[/upgrade/usbUpgrade] attach failed");
	}
}