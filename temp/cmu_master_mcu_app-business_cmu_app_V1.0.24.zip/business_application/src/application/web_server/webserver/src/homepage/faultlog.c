#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <sys/types.h>
//#include <sys/stat.h>
//#include <unistd.h> 
#include"cJSON.h"
#include"homepage.h"
#include"common.h"
#include "event_record_task.h"
#include "web_data_interface.h"
#include "sofar_errors.h"
#include "fault_text.h"
#include "sqlite3.h"
#include "sdk_shm.h"
#include "sdk_file.h"

#define FAULT_POS_TEXT_LEN	32
#define FAULT_DB_PATH "/user/data/event/Faults.db"
#define FAULTCSV_PATH "/tmp/CMUfaults.csv"

typedef struct	{
	uint8_t start_time[32];
	uint8_t end_time[32];
}fault_records_time_t;

/**
 * @brief  	根据历史事件的故障ID，获取故障位置的显示文本
 * @param  	[in] event_id 	历史事件的故障ID
 * @param  	[out] buff 		获取到的故障位置显示文本
 * @return 	执行结果
 * @retval  =0: 成功
 * @retval  <0: 失败，返回错误代码
 */
static int32_t fault_pos_text_get(const fault_text_language_e lan, uint16_t event_id, int8_t *buff)
{
	int32_t ret = SF_OK;
	uint8_t i;
	uint16_t start_point;
	uint16_t end_point;

	if (buff == NULL)
	{
		print_log("null pointer.");
		return SF_ERR_PARA;
	}

	// CMU系统
	start_point = CMU_FAULT_START;
	end_point   = CMU_FAULT_END;
	if ((event_id >= start_point) && (event_id <= end_point))
	{
		if(lan == FAULT_TEXT_LANGUAGE_CHINESE)  //中文显示
		{
			snprintf((char*)buff, FAULT_POS_TEXT_LEN, "CMU系统");
		}
		else if(lan == FAULT_TEXT_LANGUAGE_ENGLISH)  //英文显示
		{	
			snprintf((char*)buff, FAULT_POS_TEXT_LEN, "CMU system");
		}
		return ret;
	}

	// 储能柜
	start_point = CONTAINER_FAULT_START;
	end_point   = CONTAINER_FAULT_END;
	if ((event_id >= start_point) && (event_id <= end_point))
	{
		if(lan == FAULT_TEXT_LANGUAGE_CHINESE)  //中文显示
		{
			snprintf((char*)buff, FAULT_POS_TEXT_LEN, "储能柜");
		}
		else if(lan == FAULT_TEXT_LANGUAGE_ENGLISH)  //英文显示
		{
			snprintf((char*)buff, FAULT_POS_TEXT_LEN, "Energy Storage Cabinet");
		}
		return ret;
	}

	// PCS
	start_point = PCSMODULE_CLUSTER_FAULT_START_POINT;
	end_point   = PCSMODULE_CLUSTER_FAULT_END_POINT;
	if ((event_id >= start_point) && (event_id <= end_point))
	{
		if(lan == FAULT_TEXT_LANGUAGE_CHINESE)  //中文显示
		{
			snprintf((char*)buff, FAULT_POS_TEXT_LEN, "PCS模块");
		}
		else if(lan == FAULT_TEXT_LANGUAGE_ENGLISH)  //英文显示
		{
			snprintf((char*)buff, FAULT_POS_TEXT_LEN, "PCS module");
		}
		return ret;
	}

	// 电池簇
	for (i = 0; i < BCU_DEVICE_NUM; i++)
	{
		start_point = BATTERY_CLUSTER_1_WARN_START + i * BATTERY_CLUSTER_INTERVAL;	// 0x171 + i * 0x100
		end_point   = BATTERY_CLUSTER_1_FAULT_END + i * BATTERY_CLUSTER_INTERVAL;	// 0x250 + i * 0x100
		if ((event_id >= start_point) && (event_id <= end_point))
		{
			break;
		}
	}
	if (i < BCU_DEVICE_NUM)
	{
		if(lan == FAULT_TEXT_LANGUAGE_CHINESE)  //中文显示
		{
			snprintf((char*)buff, FAULT_POS_TEXT_LEN, "电池簇%02d", (i+1));
		}
		else if(lan == FAULT_TEXT_LANGUAGE_ENGLISH)  //英文显示
		{
			snprintf((char*)buff, FAULT_POS_TEXT_LEN, "Battery Cluster %02d", (i+1));
		}
	}
	else
	{
		ret = SF_ERR_PARA;
	}

	return ret;
}

/**
 * @brief  	根据历史事件的故障ID，获取故障名称的显示文本
 * @param  	[in] event_id 	历史事件的故障ID
 * @param  	[out] buff 		获取到的故障名称显示文本
 * @return 	执行结果
 * @retval  =0: 成功
 * @retval  <0: 失败，返回错误代码
 */
static int32_t fault_name_text_get(const fault_text_language_e lan, uint16_t event_id, int8_t *buff)
{
	int32_t ret = SF_OK;
	uint8_t i;
	uint16_t start_point;
	uint16_t end_point;
	uint16_t text_index;
	int8_t text_temp[FAULT_NAME_TEXT_LEN];
	constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get();

	if (buff == NULL)
	{
		print_log("null pointer.");
		return SF_ERR_PARA;
	}

	// CMU系统
	start_point = CMU_FAULT_START;
	end_point   = CMU_FAULT_END;
	if ((event_id >= start_point) && (event_id <= end_point))
	{
		text_index = event_id - start_point;
		ret = cmu_fault_text_get(lan, text_index, text_temp);
		if (ret == SF_OK)
		{
			snprintf((char*)buff, FAULT_NAME_TEXT_LEN, text_temp);
		}
		return ret;
	}

	// 集装箱
	start_point = CONTAINER_FAULT_START;
	end_point   = CONTAINER_FAULT_END;
	if ((event_id >= start_point) && (event_id <= end_point))
	{
		if ((event_id - start_point >= CONTAINER_COOLED_FAULT_OFFSET) && (event_id - start_point < (CONTAINER_COOLED_FAULT_OFFSET + CONTAINER_COOLED_FAULT_NUM)))
		{
			text_index = event_id - start_point - CONTAINER_COOLED_FAULT_OFFSET;
			ret = cooled_fault_reason_get(lan, p_para_data->dynamic_ring.lc_type, COOLED_FIELD_FAULT_NAME, text_index, text_temp);
			if (SF_OK != ret)
			{
				// json故障表没有查找到的情况下执行
				text_index = event_id - start_point;
				ret = container_fault_text_get(lan, text_index, text_temp);
				if (ret == SF_OK)
				{
					snprintf((char*)buff, FAULT_NAME_TEXT_LEN, text_temp);
				}
			}
			else
			{
				snprintf((char*)buff, FAULT_NAME_TEXT_LEN, text_temp);
			}
		}
		else
		{
			text_index = event_id - start_point;
			ret = container_fault_text_get(lan, text_index, text_temp);
			if (ret == SF_OK)
			{
				snprintf((char*)buff, FAULT_NAME_TEXT_LEN, text_temp);
			}
		}
		return ret;
	}

	// 电池簇
	for (i = 0; i < BCU_DEVICE_NUM; i++)
	{
		start_point = BATTERY_CLUSTER_1_FAULT_START + i * BATTERY_CLUSTER_INTERVAL;	// 0x171 + i * 0x100
		end_point   = BATTERY_CLUSTER_1_FAULT_END + i * BATTERY_CLUSTER_INTERVAL;	// 0x250 + i * 0x100
		if ((event_id >= start_point) && (event_id <= end_point))
		{
			break;
		}
	}
	if (i < BCU_DEVICE_NUM)
	{
		text_index = event_id - start_point;
		ret = cluster_fault_text_get(lan, text_index, text_temp);
		if (ret == SF_OK)
		{
			snprintf((char*)buff, FAULT_NAME_TEXT_LEN, text_temp);
		}
	}
	else
	{
		ret = SF_ERR_PARA;
	}

	// PCS模块
	start_point = PCS_FAULT_START;
	end_point   = PCS_FAULT_END;
	if ((event_id >= start_point) && (event_id <= end_point))
	{
		text_index = event_id - start_point;
		ret = pcs_fault_text_get(lan, text_index, text_temp);
		if (ret == SF_OK)
		{
			snprintf((char*)buff, FAULT_NAME_TEXT_LEN, text_temp);
		}
		return ret;
	}

	return ret;
}

int32_t fault_reason_text_get(const fault_text_language_e lan, uint16_t event_id, int8_t *buff)
{
	int32_t ret = SF_OK;
	uint8_t i;
	uint16_t start_point;
	uint16_t end_point;
	uint16_t text_index;
	int8_t text_temp[FAULT_RESTORE_TEXT_LEN];
	 constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get();

	if (buff == NULL)
	{
		print_log("null pointer.");
		return SF_ERR_PARA;
	}

	// CMU系统
	start_point = CMU_FAULT_START;
	end_point   = CMU_FAULT_END;
	if ((event_id >= start_point) && (event_id <= end_point))
	{
		text_index = event_id - start_point;
		ret = cmu_reason_fault_text_get(lan, text_index, text_temp);
		if (ret == SF_OK)
		{
			snprintf((char*)buff, FAULT_RESTORE_TEXT_LEN, text_temp);
		}
		return ret;
	}

	// 集装箱
	start_point = CONTAINER_FAULT_START;
	end_point   = CONTAINER_FAULT_END;
	if ((event_id >= start_point) && (event_id <= end_point))
	{
		// 集装箱液冷故障 24（CONTAINER_COOLED_FAULT_OFFSET）个偏移量，液冷故障总长度64（CONTAINER_COOLED_FAULT_NUM）个
		if ((event_id - start_point >= CONTAINER_COOLED_FAULT_OFFSET) && (event_id - start_point < (CONTAINER_COOLED_FAULT_OFFSET + CONTAINER_COOLED_FAULT_NUM)))
		{
			text_index = event_id - start_point - CONTAINER_COOLED_FAULT_OFFSET;
			ret = cooled_fault_reason_get(lan, p_para_data->dynamic_ring.lc_type, COOLED_FIELD_FAULT_REASON, text_index, text_temp);
			if (SF_OK != ret)
			{
				// json故障表没有查找到的情况下执行
				text_index = event_id - start_point;
				ret = container_reason_fault_text_get(lan, text_index, text_temp);
				if (ret == SF_OK)
				{
					snprintf((char*)buff, FAULT_RESTORE_TEXT_LEN, text_temp);
				}
			}
			else
			{
				snprintf((char*)buff, FAULT_RESTORE_TEXT_LEN, text_temp);
			}
		}
		else
		{
			// 集装箱非液冷故障
			text_index = event_id - start_point;
			ret = container_reason_fault_text_get(lan, text_index, text_temp);
			if (ret == SF_OK)
			{
				snprintf((char*)buff, FAULT_RESTORE_TEXT_LEN, text_temp);
			}
		}
		return ret;
	}

	// 电池簇
	for (i = 0; i < BCU_DEVICE_NUM; i++)
	{
		start_point = BATTERY_CLUSTER_1_FAULT_START + i * BATTERY_CLUSTER_INTERVAL;	// 0x171 + i * 0x100
		end_point   = BATTERY_CLUSTER_1_FAULT_END + i * BATTERY_CLUSTER_INTERVAL;	// 0x250 + i * 0x100
		if ((event_id >= start_point) && (event_id <= end_point))
		{
			break;
		}
	}
	if (i < BCU_DEVICE_NUM)
	{
		text_index = event_id - start_point;
		ret = cluster_reason_fault_text_get(lan, text_index, text_temp);
		if (ret == SF_OK)
		{
			snprintf((char*)buff, FAULT_RESTORE_TEXT_LEN, text_temp);
		}
	}
	else
	{
		ret = SF_ERR_PARA;
	}

	// PCS模块
	start_point = PCS_FAULT_START;
	end_point   = PCS_FAULT_END;
	if ((event_id >= start_point) && (event_id <= end_point))
	{
		text_index = event_id - start_point;
		ret = pcs_reason_fault_text_get(lan, text_index, text_temp);
		if (ret == SF_OK)
		{
			snprintf((char*)buff, FAULT_RESTORE_TEXT_LEN, text_temp);
		}
		return ret;
	}

	return ret;
}


int32_t fault_restore_text_get(const fault_text_language_e lan, uint16_t event_id, int8_t *buff)
{
	int32_t ret = SF_OK;
	uint8_t i;
	uint16_t start_point;
	uint16_t end_point;
	uint16_t text_index;
	int8_t text_temp[FAULT_RESTORE_TEXT_LEN];
	constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get();

	if (buff == NULL)
	{
		print_log("null pointer.");
		return SF_ERR_PARA;
	}

	// CMU系统
	start_point = CMU_FAULT_START;
	end_point   = CMU_FAULT_END;
	if ((event_id >= start_point) && (event_id <= end_point))
	{
		text_index = event_id - start_point;
		ret = cmu_restore_fault_text_get(lan, text_index, text_temp);
		if (ret == SF_OK)
		{
			snprintf((char*)buff, FAULT_RESTORE_TEXT_LEN, text_temp);
		}
		return ret;
	}

	// 集装箱
	start_point = CONTAINER_FAULT_START;
	end_point   = CONTAINER_FAULT_END;
	if ((event_id >= start_point) && (event_id <= end_point))
	{
		// 集装箱液冷故障 24（CONTAINER_COOLED_FAULT_OFFSET）个偏移量，液冷故障总长度64（CONTAINER_COOLED_FAULT_NUM）个
		if ((event_id - start_point >= CONTAINER_COOLED_FAULT_OFFSET) && (event_id - start_point < (CONTAINER_COOLED_FAULT_OFFSET + CONTAINER_COOLED_FAULT_NUM)))
		{
			text_index = event_id - start_point - CONTAINER_COOLED_FAULT_OFFSET;
			ret = cooled_fault_reason_get(lan, p_para_data->dynamic_ring.lc_type, COOLED_FIELD_FAULT_RESOLVENT, text_index, text_temp);
			if (SF_OK != ret)
			{
				// json故障表没有查找到的情况下执行
				text_index = event_id - start_point;
				ret = container_restore_fault_text_get(lan, text_index, text_temp);
				if (ret == SF_OK)
				{
					snprintf((char*)buff, FAULT_RESTORE_TEXT_LEN, text_temp);
				}
			}
			else
			{
				snprintf((char*)buff, FAULT_RESTORE_TEXT_LEN, text_temp);
			}
		}
		else
		{
			text_index = event_id - start_point;
			ret = container_restore_fault_text_get(lan, text_index, text_temp);
			if (ret == SF_OK)
			{
				snprintf((char*)buff, FAULT_RESTORE_TEXT_LEN, text_temp);
			}
		}
		return ret;
	}

	// 电池簇
	for (i = 0; i < BCU_DEVICE_NUM; i++)
	{
		start_point = BATTERY_CLUSTER_1_FAULT_START + i * BATTERY_CLUSTER_INTERVAL;	// 0x171 + i * 0x100
		end_point   = BATTERY_CLUSTER_1_FAULT_END + i * BATTERY_CLUSTER_INTERVAL;	// 0x250 + i * 0x100
		if ((event_id >= start_point) && (event_id <= end_point))
		{
			break;
		}
	}
	if (i < BCU_DEVICE_NUM)
	{
		text_index = event_id - start_point;
		ret = cluster_restore_fault_text_get(lan, text_index, text_temp);
		if (ret == SF_OK)
		{
			snprintf((char*)buff, FAULT_RESTORE_TEXT_LEN, text_temp);
		}
	}
	else
	{
		ret = SF_ERR_PARA;
	}

	// PCS模块
	start_point = PCS_FAULT_START;
	end_point   = PCS_FAULT_END;
	if ((event_id >= start_point) && (event_id <= end_point))
	{
		text_index = event_id - start_point;
		ret = pcs_restore_fault_text_get(lan, text_index, text_temp);
		if (ret == SF_OK)
		{
			snprintf((char*)buff, FAULT_RESTORE_TEXT_LEN, text_temp);
		}
		return ret;
	}

	return ret;
}

static time_t string_to_timestamp(const char* str)
{
   struct tm tm_time = {0};
   if(NULL == str)
   {
      return 0;
   }
	
    // 将字符串形式的时间转换为tm结构体
    sscanf(str, "%d-%d-%d %d:%d:%d", &tm_time.tm_year, &tm_time.tm_mon, &tm_time.tm_mday, 
           &tm_time.tm_hour, &tm_time.tm_min, &tm_time.tm_sec);
    // 调整年份和月份
    if(tm_time.tm_year >= 1900)
    {
       tm_time.tm_year -= 1900; // 年份从1900年开始
    }
   if(tm_time.tm_mon >= 1)
   {
      tm_time.tm_mon -= 1; // 月份从0开始
   }
    // 将tm结构体转换为UNIX时间戳
    time_t unix_time = mktime(&tm_time) - 8 * 60 * 60;
    return unix_time;
}


int32_t sqlite_db_select(event_filter_para_t filter_para, void *p_data, uint32_t *p_data_num, uint32_t *p_total_num)
{
	sqlite3_stmt *stmt;
    char *err_msg = 0;
	int32_t rc = 0;
    sqlite3 *db;
	int total_num = 0;
	uint8_t sql[256] = {0};
	
	history_event_new_t *p_item = NULL;
	p_item = (history_event_new_t *)p_data;

	rc = sdk_fs_access((const int8_t *)FAULT_DB_PATH, SF_OK);
    if (rc == -1)  // 文件夹不存在，创建该文件夹
    {
		return(-1);
	}

    rc = sqlite3_open(FAULT_DB_PATH , &db);
    if( rc ) {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return(-1);
    }	
	
	// 查询
	if (filter_para.filter_criteria == FILTER_ID_DATE)
	{
		//snprintf(sql,256,"SELECT FAULTID, strftime('%%s', STARTTIME), strftime('%%s', ENDTIME) FROM Faults WHERE date(STARTTIME) = date( '%04d-%02d-%02d' ) AND FAULTID = %d ORDER BY STARTTIME DESC;",2000 + filter_para.year , filter_para.mon, filter_para.day, filter_para.event_id);
		snprintf(sql,256,"SELECT FAULTID, STARTTIME, ENDTIME FROM Faults WHERE date(STARTTIME) = date( '%04d-%02d-%02d' ) AND FAULTID = %d ORDER BY STARTTIME DESC;",2000 + filter_para.year , filter_para.mon, filter_para.day, filter_para.event_id);
		//printf("sql %s\n",sql);
	}
	else if(filter_para.filter_criteria == FILTER_DATE)
	{
		//snprintf(sql,256,"SELECT FAULTID, strftime('%%s', STARTTIME), strftime('%%s', ENDTIME) FROM Faults WHERE date(STARTTIME) = date( '%04d-%02d-%02d' ) ORDER BY STARTTIME DESC;", 2000 + filter_para.year , filter_para.mon, filter_para.day);
		snprintf(sql,256,"SELECT FAULTID, STARTTIME, ENDTIME FROM Faults WHERE date(STARTTIME) = date( '%04d-%02d-%02d' ) ORDER BY STARTTIME DESC;", 2000 + filter_para.year , filter_para.mon, filter_para.day);
		//printf("sql %s\n",sql);
	}	
	else if(filter_para.filter_criteria == FILTER_ID)
	{
		//snprintf(sql,256,"SELECT FAULTID, strftime('%%s', STARTTIME), strftime('%%s', ENDTIME) FROM Faults WHERE FAULTID = %d ORDER BY STARTTIME DESC;",filter_para.event_id);
		snprintf(sql,256,"SELECT FAULTID, STARTTIME, ENDTIME FROM Faults WHERE FAULTID = %d ORDER BY STARTTIME DESC;",filter_para.event_id);
		//printf("sql %s\n",sql);
	}
	else
	{
		//snprintf(sql,256,"SELECT FAULTID, strftime('%%s', STARTTIME), strftime('%%s', ENDTIME) FROM Faults ORDER BY STARTTIME DESC;");
		snprintf(sql,256,"SELECT FAULTID, STARTTIME, ENDTIME FROM Faults ORDER BY STARTTIME DESC;");
	}
	
	rc = sqlite3_prepare_v2(db, sql, -1, &stmt, 0);

	if (rc != SQLITE_OK) {
    	fprintf(stderr, "Failed to fetch data: %s\n", sqlite3_errmsg(db));
    	sqlite3_close(db);
    	return -1;
	}

	while (sqlite3_step(stmt) == SQLITE_ROW)
	{
		//printf("id = %d  %s --- %s\n", sqlite3_column_int(stmt, 0), sqlite3_column_text(stmt, 1), sqlite3_column_text(stmt, 2));
		p_item[total_num].event_id = sqlite3_column_int(stmt, 0);
        strcpy(p_item[total_num].start_time, sqlite3_column_text(stmt, 1));
        strcpy(p_item[total_num].end_time, sqlite3_column_text(stmt, 2));
		total_num ++;
	}
	*p_total_num = total_num;
	
	sqlite3_finalize(stmt);
	sqlite3_close(db);
	
	return 1;
}


//该函数用来获取故障日志
void get_fault_log(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
	cJSON *p_resp_root;
	cJSON *p_resp_array;
	cJSON *p_resp_item;
    uint8_t response[256];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    uint16_t page_index;
    uint8_t items_perpage;
    int16_t acl_fault_id;
    uint8_t *p_acl_ymd;
	uint16_t total_pages = 0;
	uint16_t acl_total  = 0; //过滤之后有多少条
	uint32_t i;
	bool filter_id_flag = false;
	bool filter_date_flag = false;
	event_filter_para_t para = {0};
	uint32_t year;
    uint32_t month;
    uint32_t day;
	uint32_t data_num = 0;
	uint32_t total_num = 0;
	history_event_new_t *p_item = NULL;
	time_t timestamp = 0;
	int8_t str_timestamp[20];
	int32_t ret;
	int32_t index;
    uint8_t dev_sn[DEVICE_SN_LEN + 1] = {0};
	constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    memset(dev_sn, 0, DEVICE_SN_LEN + 1);
	memcpy(dev_sn, p_para_data->device_sn, DEVICE_SN_LEN);

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getFaultLog"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
        cJSON_Delete(p_request);
		http_back(p_nc,response);
		return;
	}

    page_index = cJSON_GetObjectItem(p_request,"pageIndex")->valueint;
    items_perpage = cJSON_GetObjectItem(p_request,"itemsPerPage")->valueint;
	acl_fault_id = atoi(cJSON_GetObjectItem(p_request,"aclFaultID")->valuestring);
    p_acl_ymd = cJSON_GetObjectItem(p_request,"aclYmd")->valuestring;
	if (items_perpage == 0)
	{
		print_log("items_perpage error.");
		cJSON_Delete(p_request);
		return;
	}

	p_resp_array = cJSON_CreateArray();
	if(p_resp_array == NULL)
	{
		print_log("create json array failed");
		cJSON_Delete(p_request);
		return;
	}

    // 数据
	p_item = (history_event_new_t *)malloc(EVENT_RECORD_DEEP_MAX * sizeof(history_event_new_t));
	if(p_item == NULL)
	{
		print_log("malloc failed");
		cJSON_Delete(p_request);
		return;
	}
	para.page_index = page_index;
	para.items_perpage = items_perpage;
//	print_log("acl_fault_id = %d", acl_fault_id);
	if (acl_fault_id < 0)
	{
		para.event_id = 0;
	}
	else
	{
		para.event_id = acl_fault_id;
		filter_id_flag = true;
	}
	ret = strcmp(p_acl_ymd, "all");
	if (ret != 0)  //如果不是all，表示按指定的日期筛选
	{
		sscanf(p_acl_ymd,"%d-%d-%d",&year,&month,&day);
		para.year = (uint8_t)(year - 2000);
		para.mon  = (uint8_t)month;
		para.day  = (uint8_t)day;
		filter_date_flag = true;
	}
	if (filter_id_flag && filter_date_flag)
	{
		para.filter_criteria = FILTER_ID_DATE;
	}
	else if (filter_date_flag)
	{
		para.filter_criteria = FILTER_DATE;
	}
	else if (filter_id_flag)
	{
		para.filter_criteria = FILTER_ID;
	}
	else
	{
		para.filter_criteria = FILTER_ALL;
	}
	para.filter_classify = FAULT_EVENT;

	ret = sqlite_db_select(para, (void *)p_item, &data_num, &total_num);
	// print_log("total_num = %d",total_num);

	if (ret < 0)
	{
		print_log("fault log get failed, ret = %d", ret);
		cJSON_Delete(p_request);
		free(p_item);
		return;
	}

	acl_total = (uint16_t)total_num;
	if ((total_num % items_perpage) == 0)
	{
		total_pages = (uint16_t)(total_num / items_perpage);
	}
	else
	{
		total_pages = (uint16_t)((total_num / items_perpage) + 1);
	}
	// print_log("acl_total = %d, total_pages = %d", acl_total, total_pages);
	if(total_num == 0)
    {
        data_num = 0;
    }
	else if ((page_index < total_pages) || !(total_num % items_perpage))
	{
		data_num = items_perpage;
	}else{

		data_num = total_num % items_perpage;
	}
	#if 1
	for(i = 0; i < data_num; i++)
	{
		p_resp_item = cJSON_CreateObject();
		if(p_resp_item == NULL)
		{
			print_log("create json obj failed");
			cJSON_Delete(p_request);
			cJSON_Delete(p_resp_array);
		}
		index =((page_index - 1) * items_perpage) + i;
		//print_log("index = %d,", index);
		// 故障ID
		cJSON_AddNumberToObject(p_resp_item,"faultID", p_item[index].event_id);
		// 设备SN
		cJSON_AddStringToObject(p_resp_item,"devSN",dev_sn);
		// 故障起始时间
		cJSON_AddStringToObject(p_resp_item,"startTimeStamp", p_item[index].start_time);
		// 故障结束时间
        if(strcmp(p_item[index].end_time, "1970-00-00 00:00:00"))
        {
            cJSON_AddStringToObject(p_resp_item,"endTimeStamp",  p_item[index].end_time);
        }
		cJSON_AddItemToArray(p_resp_array,p_resp_item);
	}
	#else
	for(i = 193; i < 336; i++)
	{
		p_resp_item = cJSON_CreateObject();
		if(p_resp_item == NULL)
		{
			print_log("create json obj failed");
			cJSON_Delete(p_request);
			cJSON_Delete(p_resp_array);
		}
		index =((page_index - 1) * items_perpage) + i;
		//print_log("index = %d,", index);
		// 故障ID
		cJSON_AddNumberToObject(p_resp_item,"faultID", i);
		// 设备SN
		cJSON_AddStringToObject(p_resp_item,"devSN",dev_sn);
		// 故障起始时间
		cJSON_AddNumberToObject(p_resp_item,"startTimeStamp", 1711955209);
		// 故障结束时间
		cJSON_AddNumberToObject(p_resp_item,"endTimeStamp",  1711955299);
		cJSON_AddItemToArray(p_resp_array,p_resp_item);
	}
	#endif

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		print_log("create json obj failed");
		cJSON_Delete(p_request);
		cJSON_Delete(p_resp_array);
	}

	//错误码,200表示成功
	cJSON_AddNumberToObject(p_resp_root,"code",200);
	//一共有多少条
	cJSON_AddNumberToObject(p_resp_root,"totalItems",acl_total);
	//一共有多少页
	cJSON_AddNumberToObject(p_resp_root,"totalPage",total_pages);
	//液冷机组 型号 0:美的  1:空调国际  2:视源
	cJSON_AddNumberToObject(p_resp_root, "lc_type", p_para_data->dynamic_ring.lc_type);
	//将故障日志装载起来
	cJSON_AddItemToObject(p_resp_root,"data",p_resp_array);

	/*打印结果,并且不需要格式化*/
	p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_request);
	cJSON_Delete(p_resp_root);

    http_back(p_nc,p);

	free(p);
	free(p_item);
}


/**
 * @brief  	读取故障日志文件至导出
 * @param  	[in] p_fault_time：过滤时间参数
 * @param  	[out] p_data：日志
 * @param  	[out] p_total_num：数量
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
static int32_t read_faults2export(fault_records_time_t *p_fault_time, void *p_data, uint32_t *p_total_num)
{
    sqlite3_stmt *stmt = NULL;
    char *err_msg = NULL;
    int32_t rc = 0;
    sqlite3 *db = NULL;
    history_event_new_t *p_item = NULL;
    uint8_t sql[512] = {0};
    int8_t fault_name_text[FAULT_NAME_TEXT_LEN] = {0};
    uint32_t total_num = 0;
    int32_t ret = 0;
 
    rc = sqlite3_open("/user/data/event/Faults.db", &db);
    if( rc ) 
    {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return 0;
    }    
 
    snprintf(sql,256,"SELECT FAULTID, STARTTIME, ENDTIME "
            "FROM Faults "
            "WHERE date(STARTTIME) BETWEEN date('%s') AND date('%s') "
            "ORDER BY STARTTIME DESC;", p_fault_time->start_time, p_fault_time->end_time);
 
    rc = sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
    if (rc != SQLITE_OK) 
    {
        fprintf(stderr, "Failed to fetch data: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return 0;
    }
    p_item = (history_event_new_t *)p_data;
    // 遍历结果集
    while (sqlite3_step(stmt) == SQLITE_ROW) 
    {
		p_item[total_num].event_id = sqlite3_column_int(stmt, 0);
        strcpy(p_item[total_num].start_time, sqlite3_column_text(stmt, 1));
        strcpy(p_item[total_num].end_time, sqlite3_column_text(stmt, 2));
		total_num++;
	}
	*p_total_num = total_num;
 
    sqlite3_finalize(stmt);
    sqlite3_close(db);
 
    return(1);
}



 /**
   * @brief  获取 记录
   * @param  [in] *p_nc 连接信息 
   * @param  [in] *p_msg  http请求信息
   * @return
   */
void export_fault_List(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_root = NULL;
    cJSON *p_resp_item = NULL;
    cJSON *p_resp_array = NULL;
    uint8_t response[256] = {0};
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    history_event_new_t *p_item = NULL;
    uint8_t request_body[1024] = {0};
    uint32_t total_num = 0;
    int32_t year = 0, mon = 0, day = 0;
    int32_t ret = 0;
    fault_records_time_t fault_time ={0};
	constant_parameter_data_t *p_constant_data = sdk_shm_constant_parameter_data_get(); // 定值/参数
 
    memcpy(request_body,p_msg->body.p,p_msg->body.len);    
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        print_log((int8_t *)"parse request failed.");
        build_empty_response(response,203,"parse request failed.");
        http_back(p_nc,response);
        return;
    }
 
    if(NULL == cJSON_GetObjectItem(p_request,"action"))
    {
        print_log((int8_t *)"action is NULL");
        build_empty_response(response,202,"action is NULL");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
     
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action,"getFaultLogList"))
    {
        print_log((int8_t *)"action is not right.");
        build_empty_response(response,202,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
    
    if ((NULL == cJSON_GetObjectItem(p_request,"timestart")) || (NULL == cJSON_GetObjectItem(p_request,"timeend")))
    {
        print_log((int8_t *)"start/end time not right.");
        build_empty_response(response,202,"start/end time not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
 
    sscanf(cJSON_GetObjectItem(p_request,"timestart")->valuestring,"%d-%d-%d",&year,&mon,&day);
    snprintf((char*)fault_time.start_time, 32, "%04d-%02d-%02d",year,mon,day);
    
    sscanf(cJSON_GetObjectItem(p_request,"timeend")->valuestring,"%d-%d-%d",&year,&mon,&day);
    snprintf((char*)fault_time.end_time, 32, "%04d-%02d-%02d",year,mon,day);
    print_log((int8_t *)"start %s end %s \n",fault_time.start_time, fault_time.end_time);
    cJSON_Delete(p_request);

    // 数据
	p_item = (history_event_new_t *)malloc(EVENT_RECORD_DEEP_MAX * sizeof(history_event_new_t));
	if(p_item == NULL)
	{
		print_log("malloc failed");
		cJSON_Delete(p_request);
		return;
	}
 
    ret = read_faults2export(&fault_time, p_item, &total_num);
    if (ret)
    {
        p_resp_array = cJSON_CreateArray();
        if(p_resp_array == NULL)
        {
            print_log("create json obj failed");
            free(p_item);
            return;
        }

        for(uint32_t i = 0; i < total_num; i++)
        {
        
            p_resp_item = cJSON_CreateObject();
            if(p_resp_item == NULL)
            {
                print_log("create json obj failed");
                cJSON_Delete(p_resp_array);
                free(p_item);
                return;
            }
            cJSON_AddNumberToObject(p_resp_item,"ID", p_item[i].event_id);
            cJSON_AddStringToObject(p_resp_item,"st", p_item[i].start_time);
            if(strcmp(p_item[i].end_time, "1970-00-00 00:00:00"))
            {
                cJSON_AddStringToObject(p_resp_item,"et",  p_item[i].end_time);
            }
            cJSON_AddItemToArray(p_resp_array,p_resp_item);
        }

        p_resp_root = cJSON_CreateObject();
        if(p_resp_root == NULL)
        {
            print_log("create json obj failed");
            cJSON_Delete(p_resp_array);
            free(p_item);
            return;
        }

        cJSON_AddNumberToObject(p_resp_root,"code",200);
        cJSON_AddStringToObject(p_resp_root,"devSN",(char *)p_constant_data->device_sn);
        cJSON_AddItemToObject(p_resp_root,"data",p_resp_array);
        cJSON_AddStringToObject(p_resp_root,"msg",(char *)"get Fault Log List success/failed");

        p = cJSON_PrintUnformatted(p_resp_root);
        http_back(p_nc,p);

        cJSON_Delete(p_resp_root);
        free(p);
        free(p_item);
    }

}