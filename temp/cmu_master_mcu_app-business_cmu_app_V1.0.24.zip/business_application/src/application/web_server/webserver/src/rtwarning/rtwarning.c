#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"cJSON.h"
#include"rtwarning.h"
#include"common.h"
#include"web_data_interface.h"
#include"sdk_shm.h"
#include "web_broker.h"

typedef enum
{
	SUPPLY_UNDERVOLTAGE, //供电电压欠压报警
	SUPPLY_OVERVOLTAGE,  //供电电压过压报警
	TERMINAL_OVERTEMP, 		//动力端子过温报警
	TEMP_RISE_FAST,			//温升过快报警
	SOH_TOO_LOW,  //SOH过低
	FC_RS485_DISCONNECT,  //消防控制器通信失联
	IO_BOARD_DISCONNECT,  //IO采集板通信失联
	FCIO_BOARD_DISCONNECT,  //消防IO采集板通信失联
    CLUSTER_OVERVOLTAGE,
    CLUSTER_UNDERVOLTAGE,
    PACK_OVERVOLTAGE,
    PACK_UNDERVOLTAGE,
    MONOMER_OVERVOLTAGE,
    MONOMER_UNDERVOLTAGE,
    EXECDIFF_PRESSURE,
    CHARGE_MONOMER_OVERTEMP,    //充电单体过温
    CHARGE_MONOMER_UNDERTEMP,    //充电单体欠温
    DISCHARGE_MONOMER_OVERTEMP, //放电单体过温
    DISCHARGE_MONOMER_UNDERTEMP, //放电单体过温
    EXECDIFF_TEMP,
    CHARGE_OVER_CURRENT,
    DISCHARGE_OVER_CURRENT,
    SOC_TOO_LOW,
    SOC_TOO_HIGH,
    INSULATION_TOO_LOW,  //绝缘过低
    MAIN_POS_RELAY_FAULT,
    MAIN_NEGA_RELAY_FAULT,
    LAN_COMM_FAULT,
    LC_FAULT,
    FC_WARNIG,  //触发的消防告警
    FC_MODEL_FAULT,  //消防模块有故障
    DOOR_SENSOR_WARNING,
    IMMERSION_WARNING,
    GAS_WARNING,
	DR_INSTABLE,
	DEHUMIDIFIER_DISCONNECT,   // 除湿器失联
    WARNING_MAX = 255
}rtwarning_type_e;

#define WEB_BIT_0   (1<<0)
#define WEB_BIT_1   (1<<1)
#define WEB_BIT_2   (1<<2)
#define WEB_BIT_3   (1<<3)
#define WEB_BIT_4   (1<<4)
#define WEB_BIT_5   (1<<5)
#define WEB_BIT_6   (1<<6)
#define WEB_BIT_7   (1<<7)

static void get_rtwarning_array(const realtime_warn_page_t *p_rtwarning,const rtwarning_type_e type,int32_t *data_array)
{
	uint8_t cluster_index;
	telematic_data_t *p_telematic_data;

	/* CMU系统故障 */
	p_telematic_data = sdk_shm_telematic_data_get();
	switch(type)
	{
		case SUPPLY_UNDERVOLTAGE: //供电电压欠压报警
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				data_array[cluster_index] = (((p_rtwarning->battery_cluster_warn_info[cluster_index][6] & WEB_BIT_0) != 0) ? 3 :
				((((p_rtwarning->battery_cluster_warn_info[cluster_index][3] & WEB_BIT_0) != 0)) ? 2 : 
				(((p_rtwarning->battery_cluster_warn_info[cluster_index][0] & WEB_BIT_0) != 0) ? 1 : 0)));
			}
			break;
		case SUPPLY_OVERVOLTAGE:  //供电电压过压报警
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				data_array[cluster_index] = (((p_rtwarning->battery_cluster_warn_info[cluster_index][6] & WEB_BIT_1) != 0) ? 3 :
				((((p_rtwarning->battery_cluster_warn_info[cluster_index][3] & WEB_BIT_1) != 0)) ? 2 : 
				(((p_rtwarning->battery_cluster_warn_info[cluster_index][0] & WEB_BIT_1) != 0) ? 1 : 0)));
			}
			break;
		case TERMINAL_OVERTEMP: 	//动力端子过温报警
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				data_array[cluster_index] = (((p_rtwarning->battery_cluster_warn_info[cluster_index][6] & WEB_BIT_6) != 0) ? 3 :
				((((p_rtwarning->battery_cluster_warn_info[cluster_index][3] & WEB_BIT_6) != 0)) ? 2 : 
				(((p_rtwarning->battery_cluster_warn_info[cluster_index][0] & WEB_BIT_6) != 0) ? 1 : 0)));
			}
			break;
		case TEMP_RISE_FAST:		//温升过快报警
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				data_array[cluster_index] = (((p_rtwarning->battery_cluster_warn_info[cluster_index][8] & WEB_BIT_5) != 0) ? 3 :
				((((p_rtwarning->battery_cluster_warn_info[cluster_index][5] & WEB_BIT_5) != 0)) ? 2 : 
				(((p_rtwarning->battery_cluster_warn_info[cluster_index][2] & WEB_BIT_5) != 0) ? 1 : 0)));
			}
			break;
		case SOH_TOO_LOW:	
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				data_array[cluster_index] = ((p_rtwarning->battery_cluster_warn_info[cluster_index][9] & WEB_BIT_1) != 0) ? 1 : 0;
			}
			break;
		case CLUSTER_OVERVOLTAGE:
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				data_array[cluster_index] = (((p_rtwarning->battery_cluster_warn_info[cluster_index][6] & WEB_BIT_4) != 0) ? 3 :
				((((p_rtwarning->battery_cluster_warn_info[cluster_index][3] & WEB_BIT_4) != 0)) ? 2 : 
				(((p_rtwarning->battery_cluster_warn_info[cluster_index][0] & WEB_BIT_4) != 0) ? 1 : 0)));
			}
			break;
		case CLUSTER_UNDERVOLTAGE:
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				data_array[cluster_index] = (((p_rtwarning->battery_cluster_warn_info[cluster_index][6] & WEB_BIT_3) != 0) ? 3 :
				((((p_rtwarning->battery_cluster_warn_info[cluster_index][3] & WEB_BIT_3) != 0)) ? 2 : 
				(((p_rtwarning->battery_cluster_warn_info[cluster_index][0] & WEB_BIT_3) != 0) ? 1 : 0)));
			}
			break;
		case PACK_OVERVOLTAGE:
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				data_array[cluster_index] = (((p_rtwarning->battery_cluster_warn_info[cluster_index][8] & WEB_BIT_6) != 0) ? 3 :
				((((p_rtwarning->battery_cluster_warn_info[cluster_index][5] & WEB_BIT_6) != 0)) ? 2 : 
				(((p_rtwarning->battery_cluster_warn_info[cluster_index][2] & WEB_BIT_6) != 0) ? 1 : 0)));
			}
			break;
		case PACK_UNDERVOLTAGE:
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				data_array[cluster_index] = (((p_rtwarning->battery_cluster_warn_info[cluster_index][8] & WEB_BIT_7) != 0) ? 3 :
				((((p_rtwarning->battery_cluster_warn_info[cluster_index][5] & WEB_BIT_7) != 0)) ? 2 : 
				(((p_rtwarning->battery_cluster_warn_info[cluster_index][2] & WEB_BIT_7) != 0) ? 1 : 0)));
			}
			break;
		case MONOMER_OVERVOLTAGE:
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				data_array[cluster_index] = (((p_rtwarning->battery_cluster_warn_info[cluster_index][7] & WEB_BIT_4) != 0) ? 3 :
				((((p_rtwarning->battery_cluster_warn_info[cluster_index][4] & WEB_BIT_4) != 0)) ? 2 : 
				(((p_rtwarning->battery_cluster_warn_info[cluster_index][1] & WEB_BIT_4) != 0) ? 1 : 0)));
			}
			break;
		case MONOMER_UNDERVOLTAGE:
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				data_array[cluster_index] = (((p_rtwarning->battery_cluster_warn_info[cluster_index][7] & WEB_BIT_5) != 0) ? 3 :
				((((p_rtwarning->battery_cluster_warn_info[cluster_index][4] & WEB_BIT_5) != 0)) ? 2 : 
				(((p_rtwarning->battery_cluster_warn_info[cluster_index][1] & WEB_BIT_5) != 0) ? 1 : 0)));
			}
			break;
		case EXECDIFF_PRESSURE:
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				data_array[cluster_index] = (((p_rtwarning->battery_cluster_warn_info[cluster_index][7] & WEB_BIT_6) != 0) ? 3 :
				((((p_rtwarning->battery_cluster_warn_info[cluster_index][4] & WEB_BIT_6) != 0)) ? 2 : 
				(((p_rtwarning->battery_cluster_warn_info[cluster_index][1] & WEB_BIT_6) != 0) ? 1 : 0)));
			}
			break;
		case CHARGE_MONOMER_OVERTEMP:
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				data_array[cluster_index] = (((p_rtwarning->battery_cluster_warn_info[cluster_index][7] & WEB_BIT_7) != 0) ? 3 :
				((((p_rtwarning->battery_cluster_warn_info[cluster_index][4] & WEB_BIT_7) != 0)) ? 2 : 
				(((p_rtwarning->battery_cluster_warn_info[cluster_index][1] & WEB_BIT_7) != 0) ? 1 : 0)));
			}
			break;
		case CHARGE_MONOMER_UNDERTEMP:
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				data_array[cluster_index] = (((p_rtwarning->battery_cluster_warn_info[cluster_index][8] & WEB_BIT_0) != 0) ? 3 :
				((((p_rtwarning->battery_cluster_warn_info[cluster_index][5] & WEB_BIT_0) != 0)) ? 2 : 
				(((p_rtwarning->battery_cluster_warn_info[cluster_index][2] & WEB_BIT_0) != 0) ? 1 : 0)));
			}
			break;
		case DISCHARGE_MONOMER_OVERTEMP:
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				data_array[cluster_index] = (((p_rtwarning->battery_cluster_warn_info[cluster_index][8] & WEB_BIT_1) != 0) ? 3 :
				((((p_rtwarning->battery_cluster_warn_info[cluster_index][5] & WEB_BIT_1) != 0)) ? 2 : 
				(((p_rtwarning->battery_cluster_warn_info[cluster_index][2] & WEB_BIT_1) != 0) ? 1 : 0)));
			}
			break;
		case DISCHARGE_MONOMER_UNDERTEMP:
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				data_array[cluster_index] = (((p_rtwarning->battery_cluster_warn_info[cluster_index][8] & WEB_BIT_2) != 0) ? 3 :
				((((p_rtwarning->battery_cluster_warn_info[cluster_index][5] & WEB_BIT_2) != 0)) ? 2 : 
				(((p_rtwarning->battery_cluster_warn_info[cluster_index][2] & WEB_BIT_2) != 0) ? 1 : 0)));
			}
			break;
		case EXECDIFF_TEMP:
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				data_array[cluster_index] = (((p_rtwarning->battery_cluster_warn_info[cluster_index][8] & WEB_BIT_3) != 0) ? 3 :
				((((p_rtwarning->battery_cluster_warn_info[cluster_index][5] & WEB_BIT_3) != 0)) ? 2 : 
				(((p_rtwarning->battery_cluster_warn_info[cluster_index][2] & WEB_BIT_3) != 0) ? 1 : 0)));
			}
			break;
		case CHARGE_OVER_CURRENT:  //充电过流
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				data_array[cluster_index] = (((p_rtwarning->battery_cluster_warn_info[cluster_index][6] & WEB_BIT_5) != 0) ? 3 :
				((((p_rtwarning->battery_cluster_warn_info[cluster_index][3] & WEB_BIT_5) != 0)) ? 2 : 
				(((p_rtwarning->battery_cluster_warn_info[cluster_index][0] & WEB_BIT_5) != 0) ? 1 : 0)));
			}
			break;
		case DISCHARGE_OVER_CURRENT:  //放电过流
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				data_array[cluster_index] = (((p_rtwarning->battery_cluster_warn_info[cluster_index][7] & WEB_BIT_0) != 0) ? 3 :
				((((p_rtwarning->battery_cluster_warn_info[cluster_index][4] & WEB_BIT_0) != 0)) ? 2 : 
				(((p_rtwarning->battery_cluster_warn_info[cluster_index][1] & WEB_BIT_0) != 0) ? 1 : 0)));
			}
			break;
		case SOC_TOO_LOW:  //SOC过低
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				/*soc过低告警去掉*/
				data_array[cluster_index] = 0;//(((p_rtwarning->battery_cluster_warn_info[cluster_index][7] & WEB_BIT_2) != 0) ? 3 :
				//((((p_rtwarning->battery_cluster_warn_info[cluster_index][4] & WEB_BIT_2) != 0)) ? 2 : 
				//(((p_rtwarning->battery_cluster_warn_info[cluster_index][1] & WEB_BIT_2) != 0) ? 1 : 0)));
			}
			break;
		case SOC_TOO_HIGH:  //soc过高
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				data_array[cluster_index] = (((p_rtwarning->battery_cluster_warn_info[cluster_index][7] & WEB_BIT_3) != 0) ? 3 :
				((((p_rtwarning->battery_cluster_warn_info[cluster_index][4] & WEB_BIT_3) != 0)) ? 2 : 
				(((p_rtwarning->battery_cluster_warn_info[cluster_index][1] & WEB_BIT_3) != 0) ? 1 : 0)));
			}
			break;
		case INSULATION_TOO_LOW:  //绝缘阻抗过低
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				data_array[cluster_index] = (((p_rtwarning->battery_cluster_warn_info[cluster_index][7] & WEB_BIT_1) != 0) ? 3 :
				((((p_rtwarning->battery_cluster_warn_info[cluster_index][4] & WEB_BIT_1) != 0)) ? 2 : 
				(((p_rtwarning->battery_cluster_warn_info[cluster_index][1] & WEB_BIT_1) != 0) ? 1 : 0)));
			}
			break;
		case MAIN_POS_RELAY_FAULT:  //DI1
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				data_array[cluster_index] = ((p_rtwarning->battery_cluster_fault_info[cluster_index][0] & WEB_BIT_0) != 0) ? 3 : 0;
			}
			break;
		case MAIN_NEGA_RELAY_FAULT:  //DI3
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				data_array[cluster_index] = ((p_rtwarning->battery_cluster_fault_info[cluster_index][0] & WEB_BIT_2 != 0)) ? 3 : 0;
			}
			break;
		case LAN_COMM_FAULT:  //内网通讯故障
			data_array[0] = 0;
			for(cluster_index = 0;cluster_index < BCU_DEVICE_NUM;cluster_index++)
			{
				data_array[cluster_index] = ((p_rtwarning->battery_cluster_fault_info[cluster_index][1] & WEB_BIT_0) != 0) ? 3 : 0;
			}
			break;
		case LC_FAULT:  //液冷故障,属于集装箱环动故障
			if (((p_rtwarning->container_system_fault_info[3]) | \
					(p_rtwarning->container_system_fault_info[4])	| \
					(p_rtwarning->container_system_fault_info[5]) | \
					(p_rtwarning->container_system_fault_info[6]) | \
					(p_rtwarning->container_system_fault_info[7]) | \
					(p_rtwarning->container_system_fault_info[8]) | \
					(p_rtwarning->container_system_fault_info[9]) | \
					(p_rtwarning->container_system_fault_info[10])) != 0)
			{
				data_array[0] = 3;
			}
			else if (((p_rtwarning->container_system_warn_info[2]) | \
					(p_rtwarning->container_system_warn_info[3]) | \
					(p_rtwarning->container_system_warn_info[4]) | \
					(p_rtwarning->container_system_warn_info[5]) | \
					(p_rtwarning->container_system_warn_info[6]) | \
					(p_rtwarning->container_system_warn_info[7]) | \
					(p_rtwarning->container_system_warn_info[8]) | \
					(p_rtwarning->container_system_warn_info[9])) != 0)
			{
				data_array[0] = 1;
			}
			else 
			{
				data_array[0] = 0;
			}
			break;
		case FC_RS485_DISCONNECT:
			data_array[0] = ((p_rtwarning->container_system_warn_info[0] & WEB_BIT_7) != 0) ? 1 : 0;
			break;
		case IO_BOARD_DISCONNECT:   //IO采集板通讯错误
			data_array[0] = (((p_rtwarning->container_system_warn_info[1] & WEB_BIT_2) != 0) ||
					 ((p_rtwarning->container_system_warn_info[1] & WEB_BIT_3) != 0) ||
					 ((p_rtwarning->container_system_warn_info[1] & WEB_BIT_4) != 0) ||
					 ((p_rtwarning->container_system_warn_info[1] & WEB_BIT_5) != 0) ||
					 ((p_rtwarning->container_system_warn_info[1] & WEB_BIT_6) != 0) ||
					 ((p_rtwarning->container_system_warn_info[1] & WEB_BIT_7) != 0)) ? 1 : 0;
			break;
		case FCIO_BOARD_DISCONNECT:
			data_array[0] = ((p_rtwarning->container_system_warn_info[15] & WEB_BIT_5) != 0) ? 1 : 0;
			break;
		case FC_WARNIG:  //消防告警
			if ((p_rtwarning->container_system_fault_info[1] & WEB_BIT_2) != 0)
			{
				data_array[0] = 3;
			}
			else if ((p_rtwarning->container_system_warn_info[1] & WEB_BIT_1) != 0)
			{
				data_array[0] = 1;
			}
			else 
			{
				data_array[0] = 0;
			}
		
			break;
		case FC_MODEL_FAULT:  //消防故障,属于集装箱环动故障
			data_array[0] = ((p_telematic_data->container_system_status_info[2] & WEB_BIT_3) != 0) ? 1 : 0;
			break;
		case DOOR_SENSOR_WARNING:  //门磁告警,属于集装箱环动故障
			data_array[0] = ((p_rtwarning->container_system_fault_info[1] & WEB_BIT_1) != 0) ? 3 : 0;
			break;
		case IMMERSION_WARNING:  //水浸告警,属于集装箱环动故障
			data_array[0] = ((p_rtwarning->container_system_warn_info[1] & WEB_BIT_0) != 0) ? 1 : 0;
			break;
		case GAS_WARNING:  //可燃气体,属于集装箱环动故障
			data_array[0] = ((p_rtwarning->container_system_fault_info[12] & WEB_BIT_1) | \
							(p_rtwarning->container_system_fault_info[13] & 0x1F)) ? 3 : 0;
			break;
		case DR_INSTABLE:  //动环系统不稳定,属于集装箱环动故障
			data_array[0] = (p_telematic_data->CMU_system_fault_info[2] & WEB_BIT_0) ? 3 : 0;
			break;
		case DEHUMIDIFIER_DISCONNECT:
			data_array[0] = (((p_rtwarning->container_system_warn_info[16] & WEB_BIT_0) != 0) ||
					 ((p_rtwarning->container_system_warn_info[16] & WEB_BIT_1) != 0) ||
					 ((p_rtwarning->container_system_warn_info[16] & WEB_BIT_2) != 0) ||
					 ((p_rtwarning->container_system_warn_info[16] & WEB_BIT_3) != 0) ||
					 ((p_rtwarning->container_system_warn_info[16] & WEB_BIT_4) != 0) ||
					 ((p_rtwarning->container_system_warn_info[16] & WEB_BIT_5) != 0)) ? 1 : 0;
			break;
		default:
			break;
	}
}

void get_real_time_warning(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
	cJSON *p_resp_item;
    uint8_t response[2048];
    uint8_t *p_action;
	uint8_t level;
    int32_t data_array[BCU_DEVICE_NUM];  //先使用假数据
    uint8_t *p;
    uint8_t request_body[1024] = {0};
	realtime_warn_page_t realtime_warning_info;
	int32_t fault = 0;
	telematic_data_t *pcs_telematic = sdk_shm_telematic_data_get();
	pcs_telematic_info_t *pcs_fault = NULL;

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getRealTimeWarning"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		cJSON_Delete(p_request);
		http_back(p_nc,response);
		return;
	}

	level = cJSON_GetObjectItem(p_request,"level")->valueint;  //要过滤的告警级别
	cJSON_Delete(p_request);

	p_resp_item = cJSON_CreateObject();
	if(p_resp_item == NULL)
	{
		print_log("create json array failed");
		return;
	}

	realtime_warn_page_get(&realtime_warning_info);

	get_rtwarning_array(&realtime_warning_info,SUPPLY_UNDERVOLTAGE,data_array);
	cJSON_AddItemToObject(p_resp_item,"SupplyVoltageUndervoltage",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,SUPPLY_OVERVOLTAGE,data_array);
	cJSON_AddItemToObject(p_resp_item,"SupplyVoltageOvervoltage",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,TERMINAL_OVERTEMP,data_array);
	cJSON_AddItemToObject(p_resp_item,"PowerTerminalOverheating",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,TEMP_RISE_FAST,data_array);
	cJSON_AddItemToObject(p_resp_item,"RapidTemperatureRise",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,CLUSTER_OVERVOLTAGE,data_array);
	cJSON_AddItemToObject(p_resp_item,"clusterOverVoltage",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,CLUSTER_UNDERVOLTAGE,data_array);
	cJSON_AddItemToObject(p_resp_item,"clusterUnderVoltage",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,PACK_OVERVOLTAGE,data_array);
	cJSON_AddItemToObject(p_resp_item,"packOverVoltage",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,PACK_UNDERVOLTAGE,data_array);
	cJSON_AddItemToObject(p_resp_item,"packUnderVoltage",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,MONOMER_OVERVOLTAGE,data_array);
	cJSON_AddItemToObject(p_resp_item,"monomerOverVoltage",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,MONOMER_UNDERVOLTAGE,data_array);
	cJSON_AddItemToObject(p_resp_item,"monomerUnderVoltage",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,EXECDIFF_PRESSURE,data_array);
	cJSON_AddItemToObject(p_resp_item,"execDiffPressure",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,CHARGE_MONOMER_OVERTEMP,data_array);
	cJSON_AddItemToObject(p_resp_item,"chargeMonomerOverTemp",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,CHARGE_MONOMER_UNDERTEMP,data_array);
	cJSON_AddItemToObject(p_resp_item,"chargeMonomerUnderTemp",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,DISCHARGE_MONOMER_OVERTEMP,data_array);
	cJSON_AddItemToObject(p_resp_item,"DischargeMonomerOverheating",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,DISCHARGE_MONOMER_UNDERTEMP,data_array);
	cJSON_AddItemToObject(p_resp_item,"UndertemperatureOfDischargeUnit",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,EXECDIFF_TEMP,data_array);
	cJSON_AddItemToObject(p_resp_item,"execDiffTemp",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,CHARGE_OVER_CURRENT,data_array);
	cJSON_AddItemToObject(p_resp_item,"chargeOverCurrent",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,DISCHARGE_OVER_CURRENT,data_array);
	cJSON_AddItemToObject(p_resp_item,"disChargeOverCurrent",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,SOC_TOO_LOW,data_array);
	cJSON_AddItemToObject(p_resp_item,"socTooLow",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,SOC_TOO_HIGH,data_array);
	cJSON_AddItemToObject(p_resp_item,"socTooHigh",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,SOH_TOO_LOW,data_array);
	cJSON_AddItemToObject(p_resp_item,"sohTooLow",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,INSULATION_TOO_LOW,data_array);
	cJSON_AddItemToObject(p_resp_item,"insulationTooLow",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,MAIN_POS_RELAY_FAULT,data_array);
	cJSON_AddItemToObject(p_resp_item,"mainPosRelayFault",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,MAIN_NEGA_RELAY_FAULT,data_array);
	cJSON_AddItemToObject(p_resp_item,"mainNegaRelayFault",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,LAN_COMM_FAULT,data_array);
	cJSON_AddItemToObject(p_resp_item,"lanCommFault",cJSON_CreateIntArray(data_array,4));
	get_rtwarning_array(&realtime_warning_info,LC_FAULT,data_array);
	cJSON_AddNumberToObject(p_resp_item,"liquidCoolingFault",data_array[0]);
	get_rtwarning_array(&realtime_warning_info,FC_MODEL_FAULT,data_array);
	cJSON_AddNumberToObject(p_resp_item,"fireControlFault",data_array[0]);
	get_rtwarning_array(&realtime_warning_info,FC_WARNIG,data_array);
	cJSON_AddNumberToObject(p_resp_item,"fireControlWarning",data_array[0]);
	get_rtwarning_array(&realtime_warning_info,DOOR_SENSOR_WARNING,data_array);
	cJSON_AddNumberToObject(p_resp_item,"doorSensorWarning",data_array[0]);
	get_rtwarning_array(&realtime_warning_info,IMMERSION_WARNING,data_array);
	cJSON_AddNumberToObject(p_resp_item,"immersionWarning",data_array[0]);
	get_rtwarning_array(&realtime_warning_info,GAS_WARNING,data_array);
	cJSON_AddNumberToObject(p_resp_item,"gasWarning",data_array[0]);
	get_rtwarning_array(&realtime_warning_info,DR_INSTABLE,data_array);
	cJSON_AddNumberToObject(p_resp_item,"dynamicRinginstability",data_array[0]);
	get_rtwarning_array(&realtime_warning_info,FC_RS485_DISCONNECT,data_array);
	cJSON_AddNumberToObject(p_resp_item,"fc485LostConn",data_array[0]);
	get_rtwarning_array(&realtime_warning_info,IO_BOARD_DISCONNECT,data_array);
	cJSON_AddNumberToObject(p_resp_item,"IOBoardLostConn",data_array[0]);
	get_rtwarning_array(&realtime_warning_info,FCIO_BOARD_DISCONNECT,data_array);
	cJSON_AddNumberToObject(p_resp_item,"fcIOBoardLostConn",data_array[0]);
	get_rtwarning_array(&realtime_warning_info,DEHUMIDIFIER_DISCONNECT,data_array);
	cJSON_AddNumberToObject(p_resp_item,"dehumidifierLossConn",data_array[0]);
	//气体探测器失联判断，6组，遥信告警第15个字节
	fault = 0;
	fault = ((pcs_telematic->container_system_warn_info[13] >> 7) & 0x01) + \
			((pcs_telematic->container_system_warn_info[14] >> 0) & 0x01) + \
			((pcs_telematic->container_system_warn_info[14] >> 1) & 0x01) + \
			((pcs_telematic->container_system_warn_info[14] >> 2) & 0x01) + \
			((pcs_telematic->container_system_warn_info[14] >> 3) & 0x01) + \
			((pcs_telematic->container_system_warn_info[14] >> 4) & 0x01);
	if(fault)
	{
		fault = 1;
	}
	cJSON_AddNumberToObject(p_resp_item,"sensorLossConn",fault);

	pcs_fault = &pcs_telematic->pcs_module[0];
	cJSON_AddNumberToObject(p_resp_item,"IsoWarn",((pcs_fault->warn_info.val >> 0) & 0x01));
	cJSON_AddNumberToObject(p_resp_item,"AuxPowerWarn",((pcs_fault->warn_info.val >> 1) & 0x01));
	cJSON_AddNumberToObject(p_resp_item,"DcSpdWarn",((pcs_fault->warn_info.val >> 2) & 0x01));
	cJSON_AddNumberToObject(p_resp_item,"AcSpdWarn",((pcs_fault->warn_info.val >> 3) & 0x01));
	cJSON_AddNumberToObject(p_resp_item,"BatUvpWarn",((pcs_fault->warn_info.val >> 4) & 0x01));
	cJSON_AddNumberToObject(p_resp_item,"BatOvpWarn",((pcs_fault->warn_info.val >> 5) & 0x01));
	cJSON_AddNumberToObject(p_resp_item,"OverTempDerate",((pcs_fault->state6.val >> 1) & 0x01));
	cJSON_AddNumberToObject(p_resp_item,"IgbtTempDerate",((pcs_fault->warn_info.val >> 8) & 0x01)); 
	cJSON_AddNumberToObject(p_resp_item,"dcRelayFeedWarn",((pcs_fault->warn_info.val >> 9) & 0x01)); 
	cJSON_AddNumberToObject(p_resp_item,"fanWarn1",((pcs_fault->warn_info.val >> 10) & 0x01)); 
	cJSON_AddNumberToObject(p_resp_item,"fanWarn2",((pcs_fault->warn_info.val >> 11) & 0x01));
	cJSON_AddNumberToObject(p_resp_item,"tempWarnPowerPort",((pcs_fault->warn_info.val >> 13) & 0x01));  
	cJSON_AddNumberToObject(p_resp_item,"busOVDerating",((pcs_fault->state6.val >> 2) & 0x01)); 
	cJSON_AddNumberToObject(p_resp_item,"ovuvDerating",((pcs_fault->state6.val >> 8) & 0x01)); 
	cJSON_AddNumberToObject(p_resp_item,"busUVDerating",((pcs_fault->state6.val >> 12) & 0x01)); 
	
	
	cJSON_AddNumberToObject(p_resp_item,"freqErrDerating",((pcs_fault->state6.val >> 13) & 0x01)); 
	cJSON_AddNumberToObject(p_resp_item,"vGridBusDerating",((pcs_fault->state6.val >> 14) & 0x01)); 
	cJSON_AddNumberToObject(p_resp_item,"fanErrDerating",((pcs_fault->state6.val >> 15) & 0x01)); 
	cJSON_AddNumberToObject(p_resp_item,"DRMsDerating",((pcs_fault->state6.val >> 5) & 0x01)); 
	cJSON_AddNumberToObject(p_resp_item,"CarrierSynWarn",((pcs_fault->warn_info.val >> 14) & 0x01)); 
	cJSON_AddNumberToObject(p_resp_item,"ResOverWarn",((pcs_fault->warn_info.val >> 6) & 0x01)); 
	
	
	// cJSON_AddNumberToObject(p_resp_item,"DCRelayFeedWarn",((pcs_fault->warn_info.val >> 9) & 0x01));
	// cJSON_AddNumberToObject(p_resp_item,"FanWarn1",((pcs_fault->warn_info.val >> 10) & 0x01));
	// cJSON_AddNumberToObject(p_resp_item,"FanWarn2",((pcs_fault->warn_info.val >> 11) & 0x01));

	fault = 0;
	fault += pcs_fault->control_fault.val;
	fault += pcs_fault->current_fault.val;
	fault += pcs_fault->grid_fault.val;
	fault += pcs_fault->hardware_signal_fault.val;
	fault += pcs_fault->sampling_fault.val;
	fault += pcs_fault->self_test_fault.val;
	fault += pcs_fault->temperature_fault.val;
	fault += pcs_fault->voltage_fault.val;
	fault += pcs_fault->communication_fault.val;
	fault += pcs_fault->supplement_fault.val;
	fault += pcs_fault->external_device_fault.val;
	fault += pcs_fault->fault12.val;
	fault += pcs_fault->fault13.val;
	if(fault)
	{
		fault = 1;
	}
	cJSON_AddNumberToObject(p_resp_item,"faultPrompt",fault);
	cJSON_AddNumberToObject(p_resp_item,"MissingSafetyDocument",((pcs_telematic->container_system_warn_info[0] >> 2) & 0x01)); 
	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		print_log("create json obj failed");
		cJSON_Delete(p_resp_item);
		return;
	}
	cJSON_AddNumberToObject(p_resp_root,"code",200);
	cJSON_AddItemToObject(p_resp_root,"data",p_resp_item);
	cJSON_AddStringToObject(p_resp_root,"msg","get real time warning successful");

	p = cJSON_PrintUnformatted(p_resp_root);

	strcpy(response,p);

	cJSON_Delete(p_resp_root);
	free(p);

	http_back(p_nc,response);
}

/**
 * @brief 告警信息模块初始化
 * @return void
 */
void warning_info_module_init(void)
{
	/*获取实时告警*/
	if(!web_func_attach("/realTimeWarning/getRealTimeWarning", get_real_time_warning))
	{
		print_log("[/realTimeWarning/getRealTimeWarning] attach failed");
	}
}