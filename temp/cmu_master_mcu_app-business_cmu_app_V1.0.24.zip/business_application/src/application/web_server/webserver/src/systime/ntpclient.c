#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <time.h>
#include <sys/time.h>
#include <arpa/inet.h>
#include "systime.h"
#include "common.h"

static void send_packet(int32_t fd)
{
    uint32_t data[12];
    struct timeval now;

    if (sizeof(data) != 48)
    {
        print_log("data len is less than 48.");
        return;
    }
    memset((uint8_t *)data, 0, sizeof(data));
    data[0] = htonl((LI << 30) | (VN << 27) | (MODE << 24) | (STRATUM << 16) | (POLL << 8) | (PREC & 0xff));
    data[1] = htonl(1 << 16);
    data[2] = htonl(1 << 16);
    //获得本地时间
    gettimeofday(&now, NULL);

    data[10] = htonl(now.tv_sec + JAN_1970);
    data[11] = htonl(NTPFRAC(now.tv_usec));

    send(fd, data, 48, 0);
}

static int8_t set_server_time(int32_t sock)
{
    int ret;
    unsigned int data[12];
    struct tm *local_time;
    time_t time_sec;
    char time_buff[128];
    NtpTime oritime, rectime, tratime, destime;
    struct timeval offtime, dlytime;
    struct timeval now;

    bzero(data, sizeof(data));
    ret = recvfrom(sock, data, sizeof(data), 0, NULL, 0);
    if (ret == -1)
    {
        print_log("read data failed.");
        return 1;
    }
    else if (ret == 0)
    {
        print_log("read data length is zero.");
        return 1;
    }
   
    //1970逆转换到1900
    gettimeofday(&now, NULL);
    destime.integer = now.tv_sec + JAN_1970;
    destime.fraction = NTPFRAC(now.tv_usec);

    printf("%d-%d-%d-%d\n",data[6],data[7],data[8],data[9]);
    //字节序转换
    oritime.integer = DATA(6);
    oritime.fraction = DATA(7);
    rectime.integer = DATA(8);
    rectime.fraction = DATA(9);
    tratime.integer = DATA(10);
    tratime.fraction = DATA(11);

    int64_t orius, recus, traus, desus, offus, dlyus;

    orius = TTLUSEC(MKSEC(oritime), MKUSEC(oritime));
    recus = TTLUSEC(MKSEC(rectime), MKUSEC(rectime));
    traus = TTLUSEC(MKSEC(tratime), MKUSEC(tratime));
    desus = TTLUSEC(now.tv_sec, now.tv_usec);

    offus = ((recus - orius) + (traus - desus)) / 2;
    dlyus = (recus - orius) + (desus - traus);

    offtime.tv_sec = GETSEC(offus);
    offtime.tv_usec = GETUSEC(offus);
    dlytime.tv_sec = GETSEC(dlyus);
    dlytime.tv_usec = GETUSEC(dlyus);

    struct timeval new;

    //粗略校时
    //new.tv_sec = tratime.integer - JAN_1970;
    //new.tv_usec = USEC(tratime.fraction);
    //精确校时
    new.tv_sec = destime.integer - JAN_1970 + offtime.tv_sec;
    new.tv_usec = USEC(destime.fraction) + offtime.tv_usec;

    memset(time_buff, 0, 100);
	//time_sec = new.tv_sec + 28800;
    time_sec = new.tv_sec;

    local_time = localtime(&time_sec);
    //sprintf(time_buff, "date -s \"%d-%d-%d %d:%d:%d\"", tm_p->tm_year + 1900, tm_p->tm_mon + 1, tm_p->tm_mday, tm_p->tm_hour, tm_p->tm_min, tm_p->tm_sec);
    //sprintf(time_buff, "date -s \"%d-%d-%d %d:%d:%d\"", tm_p->tm_year + 1900, tm_p->tm_mon + 1, tm_p->tm_mday, tm_p->tm_hour, tm_p->tm_min, tm_p->tm_sec);
    sprintf(time_buff, "date -s \"%d-%d-%d %d:%d:%d\"", local_time->tm_year + 1900, local_time->tm_mon + 1, local_time->tm_mday, local_time->tm_hour, local_time->tm_min, local_time->tm_sec);

    system(time_buff);
    system("hwclock -w");
    return 0;
}

int8_t do_ntp_sync_time(const uint8_t *p_server,const uint16_t port)
{
    int32_t ret;
    int32_t sock;
    fd_set fds_read;

    struct timeval timeout; //<sys/time.h>
    struct hostent *host;

    uint8_t addr_len = sizeof(struct sockaddr_in);
    struct sockaddr_in addr_src; //本地 socket  <netinet/in.h>
    struct sockaddr_in addr_dst; //服务器 socket

    //UDP数据报套接字
    sock = socket(PF_INET, SOCK_DGRAM, 0);
    if (sock == -1)
    {
        print_log("call socket failed.");
        return -1;
    }

    memset(&addr_src, 0, addr_len);
    addr_src.sin_family = AF_INET;
    addr_src.sin_port = htons(0);
    addr_src.sin_addr.s_addr = htonl(INADDR_ANY); //<arpa/inet.h>
    //绑定本地地址
    if (-1 == bind(sock, (struct sockaddr *)&addr_src, addr_len))
    {
        print_log("call bind failed.");
        close(sock);
        return -2;
    }
    memset(&addr_dst, 0, addr_len);
    addr_dst.sin_family = AF_INET;
    addr_dst.sin_port = htons(port);

    host = gethostbyname(p_server); //<netdb.h>
    if (host == NULL)
    {
        print_log("can not resove domain.");
        close(sock);
        return -3;
    }

    memcpy(&(addr_dst.sin_addr.s_addr), host->h_addr_list[0], 4);
    if (-1 == connect(sock, (struct sockaddr *)&addr_dst, addr_len))
    {
        print_log("can not connect server.");
        close(sock);
        return -4;
    }
    send_packet(sock);
    FD_ZERO(&fds_read);
    FD_SET(sock, &fds_read);
    timeout.tv_sec = 10;
    timeout.tv_usec = 0;

    ret = select(sock + 1, &fds_read, NULL, NULL, &timeout);
    if (ret == -1)
    {
        print_log("select error.");
        close(sock);
        return -5;
    }
    if (ret == 0)
    {
        print_log("select timed out.");
        close(sock);
        return -6;
    }
    if (FD_ISSET(sock, &fds_read))
    {
        if (1 == set_server_time(sock))
        {
            print_log("set time error.");
            close(sock);
            return -7;
        }
    }
    return 0;
}