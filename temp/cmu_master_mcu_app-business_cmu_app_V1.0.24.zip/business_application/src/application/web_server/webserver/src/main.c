#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<openssl/md5.h>
#include"mongoose.h"
#include"administrator.h"
#include"common.h"
#include"cJSON.h"
#include "batteryinfo.h"
#include "debugmanage.h"
#include "history_rtdata.h"
#include "homepage.h"
#include "network.h"
#include "protectparams.h"
#include "systime.h"
#include "rtwarning.h"
#include "sysparam.h"
#include "upgrade.h"
#include "web_data_interface.h"
#include "udiskupgrade.h"
#include "pcsInfo.h"
#include "power_history.h" 
#include "safety.h"
#include "mqtt_info.h"
#include "operation_log.h"
#include "sdk_shm.h"
#include "web_broker.h"
#include "systime.h"
#include "fault_recorder.h"
#include "csu_data_info.h"
#include "history_drdata.h"

#define HTTP_SERVER_ADDR "0.0.0.0:80"   //2023.5.4修改，避免与梁工的端口冲突
#define HTTPS_SERVER_ADDR "0.0.0.0:443"
#define LOCAL_TIME_FILE "/etc/localtime"

struct mg_serve_http_opts web_server_opts;
pthread_mutex_t g_upgrade_mtx = PTHREAD_MUTEX_INITIALIZER;  //升级过程中的互斥锁,用来控制进度
#if 0
void print_log(const int8_t *format,...)
{
	va_list arg;
	uint8_t buffer[128];
	va_start(arg,format);
	vsprintf(buffer,format,arg);	
	va_end(arg);
	printf("%s\n",buffer);
}
#endif

void ymd_to_timestamp(const uint16_t year,const uint8_t month,const uint8_t day,time_t *timestamp)
{
	struct tm tm;
	memset(&tm,0,sizeof(struct tm));
	tm.tm_year = year - 1900;
	tm.tm_mon = month - 1;
	tm.tm_mday = day;
	*timestamp = mktime(&tm) - 8 * 60 * 60;
}

void md5_calcul(const uint8_t *text,const uint8_t len,uint8_t *out)
{
	MD5_CTX md5_ctx;
	MD5_Init(&md5_ctx);
	MD5_Update(&md5_ctx,text,len);
	MD5_Final(out,&md5_ctx);
}


int8_t build_empty_response(uint8_t *response,const uint16_t code,const uint8_t *p_reason)
{
	cJSON *p_root = NULL;
	uint8_t *p;

	p_root = cJSON_CreateObject();
	if(p_root == NULL)
	{
		print_log("cjson create obj failed.");
		return -1;
	}

	cJSON_AddNumberToObject(p_root,"code",code);
	cJSON_AddStringToObject(p_root,"msg",p_reason);
	p = cJSON_PrintUnformatted(p_root);
	strcpy(response,p);
	cJSON_Delete(p_root);
	free(p);
	return 0;
}

void strip_request_body(const uint8_t *p_src,const uint8_t len,uint8_t *p_dst)
{
	uint8_t i,j;
	uint8_t tmp[512] = {0};
	if(p_src[0] == '"')
	{
		memcpy(tmp,p_src + 1,len - 1);
	}
	if(tmp[len-2] == '"')
	{
		tmp[len-2] = '\0';
	}
	j = 0;
	for(i=0;i<len;i++)
	{
		if(tmp[i] != '\\')
		{
			p_dst[j++] = tmp[i];
		}	
	}
}

void hex_to_str(const uint8_t *p_src,uint8_t *p_dst,const uint8_t len)
{
	uint8_t ddh,ddl;
	uint8_t i;
	for(i = 0; i < len; i++)
	{
		ddh = 48 + p_src[i]/16;
		ddl = 48 + p_src[i]%16;
		if(ddh > 57)
		{
			ddh = ddh + 39;
		}		
		if(ddl > 57)
		{
			ddl = ddl + 39;
		}
		p_dst[i*2] = ddh;
		p_dst[i*2+1] = ddl;
	}
}

void http_back(struct mg_connection *p_nc,uint8_t *p_data)
{
	mg_printf(p_nc, "%s", "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\nConnection: close\r\n\r\n");
	mg_printf_http_chunk(p_nc, "%s", p_data);
	mg_send_http_chunk(p_nc, "", 0);
}

void get_user_from_http_request(struct http_message *p_msg,uint8_t *p_username)
{
	struct mg_str *cookie_str;
	uint8_t username[32] = {0};
	char *p = username;
	char *q = NULL;
    char *p_request_body = NULL;
	cJSON *p_request;

    p_request_body = malloc(p_msg->body.len + 1024);
    if(p_request_body == NULL)
    {
        return;
    }
    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,p_request_body);
	}
	else
	{
		memcpy(p_request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(p_request_body);

	cookie_str = mg_get_http_header(p_msg, "Cookie");
	if(cookie_str != NULL)
	{
		mg_http_parse_header2(cookie_str,"loginName_CMU",&p,sizeof(username));
		strcpy(p_username,username);
	}
	else
	{
		if(cJSON_GetObjectItem(p_request,"userName") != NULL)
		{
			q = cJSON_GetObjectItem(p_request,"userName")->valuestring;
			if(q != NULL)
			{
				strcpy(p_username,q);
			}
		}
	}
	cJSON_Delete(p_request);
    free(p_request_body);
}

/**
 * @brief WEB功能模块初始化
 * @return void
 */
void web_func_module_init(void)
{
	//用户管理模块初始化
	web_user_manage_module_init();

	//系统时间模块初始化
	web_sys_time_module_init();

	//系统参数模块初始化
	web_sys_param_module_init();

	//网络参数模块初始化
	web_network_param_module_init();

	//CMU系统信息模块初始化
	homepage_info_module_init();

	//电池簇信息模块初始化
	battery_info_module_init();
	
	//告警信息模块初始化
	warning_info_module_init();
	
	//保护参数模块初始化
	protect_param_module_init();

	//调试参数模块初始化
	debug_param_module_init();
	
	//安规导入模块初始化
	safety_param_module_init();

	//升级模块初始化
	upgrade_module_init();
	
	//历史数据模块初始化
	history_data_module_init();

    //动环历史数据模块初始化
    history_dr_data_module_init();

	//PCS数据模块初始化
	pcsinfo_data_module_init();

	//功率曲线模块初始化
	power_history_module_init();

    //故障录波模块初始化
    fault_recorder_module_init();

	//mqtt信息模块初始化
	mqtt_info_module_init();

    //获取CSU相关数据初始化
    csu_data_info_module_init();
}

static void ev_handler(struct mg_connection *p_nc,int ev,void *p_ev_data)
{
	uint8_t ret = 0;
	struct http_message *p_msg;
	struct mg_http_multipart_part *mp;
	struct mg_str mime_type = {"application/octet-stream",24};
	struct mg_str extra_headers = {0};

	if(ev == MG_EV_HTTP_REQUEST)
	{
		p_msg = (struct http_message *)p_ev_data;
		ret = web_func_execute(p_nc, p_msg);
        if(!ret)
		{
            if (mg_vcmp(&p_msg->uri,"/download/fault_recorder.tar.gz") == 0)             			//传输PCS故障录波文件
			{
				mg_http_serve_file(p_nc, p_msg, "/user/data/pcs_fault_record/fault_recorder.tar.gz", mime_type, extra_headers);
			}
            else if (mg_vcmp(&p_msg->uri,"/download/CMUFaultRecorder.tar.gz") == 0)             			//传输PCS故障录波文件
			{
				mg_http_serve_file(p_nc, p_msg, "/user/data/cmu_fault_record/CMUFaultRecorder/CMUFaultRecorder.tar.gz", mime_type, extra_headers);
			}
            else
            {
                print_log("callback function is not installed, please check it");
                mg_serve_http(p_nc, p_msg, web_server_opts);
            }
        }
	}
}

int main()
{
	struct mg_mgr mgr;
	struct mg_connection *p_nc;
	struct mg_bind_opts bind_opts;
	int32_t ret;

	uint8_t use_https = 0; //we now use http

	mg_mgr_init(&mgr,NULL);
	memset(&bind_opts,0,sizeof(struct mg_bind_opts));
	
	if(use_https == 0)
	{
		p_nc = mg_bind(&mgr,HTTP_SERVER_ADDR,ev_handler);	
	}
	else
	{
		p_nc = mg_bind_opt(&mgr,HTTPS_SERVER_ADDR,ev_handler,bind_opts);		
	}	
	if(p_nc == NULL)
	{
		print_log("init net connection failed");
		mg_mgr_free(&mgr);
		return -1;
	}

	mg_set_protocol_http_websocket(p_nc);

	if(access(WEB_HOME_PATH,F_OK) != 0)  //目录不存在
	{
        print_log("htdocs directory is not exist\n");
		mg_mgr_free(&mgr);
		return 0;
    }

	web_server_opts.document_root = WEB_HOME_PATH;
	web_server_opts.enable_directory_listing = "yes";

	// mg_register_http_endpoint(p_nc, "/upload", ev_handler MG_UD_ARG(NULL));
	mg_register_http_endpoint(p_nc, "/upload", do_handle_upload);
	mg_set_protocol_http_websocket(p_nc);
	mg_register_http_endpoint(p_nc, "/SafetUpload", safety_upload);
	mg_set_protocol_http_websocket(p_nc);

	if(access(WEB_CONF_PATH,F_OK) != 0)  //目录不存在
	{
        mkdir(WEB_CONF_PATH,0755);
    }
	
	//第一次烧录的时候,烧录包里面没有带administrator.json文件,需要从/user/www/conf/default_config拷贝到/user/www/conf/作为默认配置
	if(access(ADMIN_JSON_FILE,F_OK) != 0) 
	{
        system("cp /user/www/conf/default_config/administrator.json /user/www/conf/");
    }

	//第一次烧录的时候,烧录包里面没有带systime.json文件,需要从/user/www/conf/default_config拷贝到/user/www/conf/作为默认配置
	if(access(SYSTIME_JSON_FILE,F_OK) != 0)
	{
        system("cp /user/www/conf/default_config/systime.json /user/www/conf/");
    }

	//第一次烧录的时候,烧录包里面没有带runtimeparams.json文件,需要从/user/www/conf/default_config拷贝到/user/www/conf/作为默认配置
	if(access(RUNTIME_PARAMS_JSON_FILE,F_OK) != 0)
	{
        system("cp /user/www/conf/default_config/runtimeparams.json /user/www/conf/");
    }

	//如果存在localtime文件则删除，使用UTC0时区
    if(access(LOCAL_TIME_FILE,F_OK) == 0)
	{
        system("mount -o remount,rw /");
        system("rm /etc/localtime");
        system("mount -o remount,ro /");
	}

	if(access(WEB_UPLOAD_DIR,F_OK) != 0)  //目录不存在
	{
		system("mkdir -p /tmp/upload");
     //   mkdir(WEB_UPLOAD_DIR,0755);
    }
	pthread_mutex_init(&g_upgrade_mtx,NULL);  //初始化互斥锁

    operation_log_conf_init();          //操作日志配置初始化

	ret = web_data_init();  //初始化并获取共享内存数据
	if(ret != 0)
	{
		mg_mgr_free(&mgr);
		pthread_mutex_destroy(&g_upgrade_mtx);  //销毁互斥锁
		return 0;
	}
	//web功能代理模块初始化
	web_broker_module_init();

	//web功能模块初始化
	web_func_module_init();

	while(1)
	{
		mg_mgr_poll(&mgr,500);
	}
	mg_mgr_free(&mgr);
	pthread_mutex_destroy(&g_upgrade_mtx);  //销毁互斥锁
	return 0;
}

