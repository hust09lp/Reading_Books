#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<arpa/inet.h>
#include<net/if.h>
#include<sys/ioctl.h>
#include<sys/socket.h>
#include"cJSON.h"
#include"network.h"
#include"common.h"
#include"sdk_net_public.h"
#include "web_broker.h"

static void trim_str(uint8_t *p_src,uint8_t *p_dst)
{
    uint16_t i;
    for(i=0;i<strlen(p_src);i++)
    {
        if(p_src[i] == '\n')
        {
            p_dst[i] = '\0';
        }
        else
        {
            p_dst[i] = p_src[i];
        }
    }
}
static void get_network_params(uint8_t *mode,uint8_t *p_ip,uint8_t *p_netmask,uint8_t *p_gw,uint8_t *p_dns1,uint8_t *p_dns2)
{
    strcpy(mode,"static");
    if(sdk_net_ip_get(ETH0, p_ip) < 0)
    {
        strncpy((char *)p_ip, "0.0.0.0", strlen("0.0.0.0"));
        return;
    }

    if(sdk_net_subnetmask_get(ETH0, p_netmask) < 0)
    {
        strncpy((char *)p_netmask, "255.255.255.0", strlen("255.255.255.0"));
        return;
    }

    if(sdk_net_gateway_get(ETH0, p_gw) < 0)
    {
        strncpy((char *)p_gw, "0.0.0.0", strlen("0.0.0.0"));
        return;
    }

    if(sdk_net_dns_get(ETH0, p_dns1) < 0)
    {
        strncpy((char *)p_dns1, "0.0.0.0", strlen("0.0.0.0"));
        return;
    }

    //当前我们只支持一个DNS,第二个DNS目前暂时不支持,先固定写死
    strncpy((char *)p_dns2, "202.96.128.86", strlen("202.96.128.86"));
}


static void modify_net_conf(const uint8_t is_dhcp, uint8_t *p_ip, uint8_t *p_netmask, uint8_t *p_gw, uint8_t *p_dns1, uint8_t *p_dns2)
{
   if(is_dhcp == 1)
   {
        system("udhcpc -b -i eth0");
        return;
   }
   if(sdk_net_ip_set(ETH0, p_ip) < 0)
   {
        print_log("set ip failed");
        return;
   }

   if(sdk_net_subnetmask_set(ETH0, p_netmask) < 0)
   {
        print_log("set subnet mask failed");
        return;
   }

   if(sdk_net_gateway_set(ETH0, p_gw) < 0)
   {
        print_log("set gateway failed");
        return;
   }

   if(sdk_net_dns_set(ETH0, p_dns1)< 0)
   {
        print_log("set dns1 failed");
        return;
   }
   //我们目前暂不支持DNS2的配置,后续看情况如何将DNS用起来
}

void get_network_sta(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
    cJSON *p_resp_item;
    uint8_t response[256];
    uint8_t *p_action;
    uint8_t mode[32] = {0};
    uint8_t ip[32] = {0};
    uint8_t netmask[32] = {0};
    uint8_t gateway[32] = {0};
    uint8_t dns1[32] = {0};
    uint8_t dns2[32] = {0};
    uint8_t *p;
    uint8_t request_body[1024] = {0};

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
    {
        strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
    }
    else
    {
        memcpy(request_body,p_msg->body.p,p_msg->body.len);		
    }
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        print_log("parse request failed.");
        build_empty_response(response,202,"parse request failed.");
        http_back(p_nc,response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action,"getNetworkPara"))
    {
        print_log("action is not right.");
        build_empty_response(response,203,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
    cJSON_Delete(p_request);

    get_network_params(mode,ip,netmask,gateway,dns1,dns2); //获取eth0接口的相关信息,因为目前集中式储能只使用到了eth0网口
 
    p_resp_item = cJSON_CreateObject();
    if(p_resp_item == NULL)
    {
        print_log("create json obj failed.");
        return;
    }
    cJSON_AddStringToObject(p_resp_item,"confMode",mode);
    cJSON_AddStringToObject(p_resp_item,"ipAddr",ip);
    cJSON_AddStringToObject(p_resp_item,"netMask",netmask);
    cJSON_AddStringToObject(p_resp_item,"defaultGw",gateway);
    cJSON_AddStringToObject(p_resp_item,"dns1",dns1);
    cJSON_AddStringToObject(p_resp_item,"dns2",dns2);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed.");
        cJSON_Delete(p_resp_item);
        return;
    }
    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddItemToObject(p_resp_root,"data",p_resp_item);
    cJSON_AddStringToObject(p_resp_root,"msg","get network parameter successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);
    cJSON_Delete(p_resp_root);
    free(p);
    http_back(p_nc,response);
}

void set_network_dhcp(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    uint8_t response[128];
    uint8_t *p_action;
    uint8_t request_body[1024] = {0};
    uint8_t cur_user[32] = {0};
	operation_log_t op_log;

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
    {
        strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
    }
    else
    {
        memcpy(request_body,p_msg->body.p,p_msg->body.len);		
    }
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        print_log("parse request failed.");
        build_empty_response(response,202,"parse request failed.");
        http_back(p_nc,response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action,"dynamicNetwork"))
    {
        print_log("action is not right.");
        build_empty_response(response,203,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
    cJSON_Delete(p_request);

    modify_net_conf(1,NULL,NULL,NULL,NULL,NULL);

    init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"设置DHCP");
	strcpy(op_log.op_status,"success");
	add_one_op_log(&op_log);

    build_empty_response(response,200,"set dynamic successful");
    http_back(p_nc,response);
}

void set_network_static(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    uint8_t response[128];
    uint8_t *p_action;
    uint8_t *p_ip;
    uint8_t *p_netmask;
    uint8_t *p_gw;
    uint8_t *p_dns1;
    uint8_t *p_dns2;
    uint8_t request_body[1024] = {0};
    uint8_t cur_user[32] = {0};
	operation_log_t op_log;

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
    {
        strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
    }
    else
    {
        memcpy(request_body,p_msg->body.p,p_msg->body.len);		
    }
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        print_log("parse request failed.");
        build_empty_response(response,202,"parse request failed.");
        http_back(p_nc,response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action,"staticNetwork"))
    {
        print_log("action is not right.");
        build_empty_response(response,203,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
   // cJSON_Delete(p_request);
    p_ip = cJSON_GetObjectItem(p_request,"ipAddr")->valuestring;
    p_netmask = cJSON_GetObjectItem(p_request,"netMask")->valuestring;
    p_gw = cJSON_GetObjectItem(p_request,"defaultGw")->valuestring;
    p_dns1 = cJSON_GetObjectItem(p_request,"dns1")->valuestring;
    p_dns2 = cJSON_GetObjectItem(p_request,"dns2")->valuestring;
    modify_net_conf(0,p_ip,p_netmask,p_gw,p_dns1,p_dns2);
    cJSON_Delete(p_request);

    init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"修改静态网络参数");
	strcpy(op_log.op_status,"success");
	add_one_op_log(&op_log);

    build_empty_response(response,200,"set static  successful");
    http_back(p_nc,response);
}

/**
 * @brief 网络参数模块初始化
 * @return void
 */
void web_network_param_module_init(void)
{
    /*获取网络参数*/
	if(!web_func_attach("/system/getNetworkPara", get_network_sta))
	{
		print_log("[/system/getNetworkPara] attach failed");
	}
	/*设置DHCP*/
	if(!web_func_attach("/system/dynamicNetwork", set_network_dhcp))
	{
		print_log("[/system/dynamicNetwork] attach failed");
	}
	/*设置静态网络参数*/
	if(!web_func_attach("/system/staticNetwork", set_network_static))
	{
		print_log("[/system/staticNetwork] attach failed");
	}
}