#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include "sdk_fs.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "cJSON.h"
#include "common.h"
#include "sdk_net_public.h"
#include "web_broker.h"
#include "fault_recorder.h"
#include "fault_recorder_data2csv.h"

typedef struct {
    char name[128];
    time_t mod_time;
}file_info_t;

//CMU故障录波文件信息列表
static cmu_fault_recorder_info_t g_fault_recorder_info[MAX_CMU_RECORDER_FILE_NUM] = {0};


static int32_t sdk_system_cmd(int8_t * cmd)
{
    FILE *fp = NULL;

    if((fp=popen(cmd, "r")) == NULL)
    {
        printf("[%s:%s:%d] %s, cmd:%s\n", __FILE__,__func__, __LINE__, strerror(errno), cmd);
        return -1;
    }
    pclose(fp);

    return 0;
}


/**
 * @brief    请求导出故障录波
 * @param	 [in] *p_nc 连接信息
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void pcs_fault_recorder_file_generate(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	uint8_t response[256];
	uint8_t *p_action = NULL;
	uint8_t *p = NULL;
	uint8_t request_body[1024] = {0};
	uint32_t index = 0;
	int32_t ret = 0;

	internal_shared_data_t *p_shared_data = internal_shared_data_get();
    memcpy(request_body, p_msg->body.p, p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response, 202, "parse request failed.");
		http_back(p_nc,response);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request, "action")->valuestring;
	if(strcmp(p_action,"generateFaultRecorderPCS"))
	{
		print_log("action is not right.");
		build_empty_response(response, 203, "action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	p_shared_data->pcs_fault_recorder_info.file_id = cJSON_GetObjectItem(p_request,"index")->valueint;
    p_shared_data->pcs_fault_recorder_info.fault_recorder_export_flag = 1;
    p_shared_data->pcs_fault_recorder_info.progress = 0;
	cJSON_Delete(p_request);

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		print_log("create json obj failed");
		build_empty_response(response, 203, "create json obj failed");
		http_back(p_nc,response);
		return;
	}

	cJSON_AddNumberToObject(p_resp_root, "code", 200);
	cJSON_AddStringToObject(p_resp_root, "msg", "successful");

	p = cJSON_PrintUnformatted(p_resp_root);

	cJSON_Delete(p_resp_root);
	http_back(p_nc, p);
	free(p);
}


/**
 * @brief    请求故障录波文件生成进度
 * @param	 [in] *p_nc 连接信息
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void pcs_fault_recorder_file_progress(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	uint8_t response[256];
	uint8_t *p_action = NULL;
	uint8_t *p = NULL;
	uint8_t request_body[1024] = {0};
	uint32_t index = 0;
	int32_t ret = 0;

	internal_shared_data_t *shared_data = internal_shared_data_get();
    memcpy(request_body, p_msg->body.p, p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response, 202, "parse request failed.");
		http_back(p_nc,response);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request, "action")->valuestring;
	if(strcmp(p_action, "getFaultRecorderProgressPCS"))
	{
		print_log("action is not right.");
		build_empty_response(response, 203, "action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	cJSON_Delete(p_request);


	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		print_log("create json obj failed");
		build_empty_response(response, 203, "create json obj failed");
		http_back(p_nc,response);
		return;
	}
	if(shared_data->pcs_fault_recorder_info.progress >= 0)
	{
		cJSON_AddNumberToObject(p_resp_root, "code", 200);
		cJSON_AddNumberToObject(p_resp_root, "progress", shared_data->pcs_fault_recorder_info.progress);
		cJSON_AddStringToObject(p_resp_root, "msg", "successful");

	}
    else
    {
		cJSON_AddNumberToObject(p_resp_root, "code", 300);
		cJSON_AddNumberToObject(p_resp_root, "progress", -1);
		cJSON_AddStringToObject(p_resp_root, "msg", "fail");

	}

	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);

}

/**
 * @brief    下载PCS故障录波文件
 * @param	 [in] *p_nc 连接信息
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void pcs_fault_recorder_file_download(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t response[256] = {0};
	int32_t ret = 0;
	
	uint8_t request_body[1024] = {0};

    memcpy(request_body, p_msg->body.p, p_msg->body.len);
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        print_log((int8_t *)"parse request failed.");
        build_empty_response(response, 202, "parse request failed.");
        http_back(p_nc, response);
        return;
    }

	if(NULL == cJSON_GetObjectItem(p_request, "action"))
	{
        print_log((int8_t *)"action is NULL");
        build_empty_response(response, 203, "action is NULL");
        http_back(p_nc, response);
        cJSON_Delete(p_request);
        return;
	}

	p_action = cJSON_GetObjectItem(p_request, "action")->valuestring;
	if(strcmp(p_action, "exportFaultRecorderPCS"))
	{
        print_log((int8_t *)"action is not right.");
        build_empty_response(response, 203, "action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
	cJSON_Delete(p_request);

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		print_log((int8_t *)"create json obj failed.");
		return;
	}

	cJSON_AddNumberToObject(p_resp_root,"code",200);
	cJSON_AddStringToObject(p_resp_root,"url","download/fault_recorder.tar.gz");
	cJSON_AddStringToObject(p_resp_root,"msg","successful");

	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);
	return;
}


/**
 * @brief          检查SD卡是否挂载
 * @return         true：挂载 false：没有挂载
 */
static bool sd_mount_status(void)
{
    char cmd[256] = {0};
    char tmp_buff[32] = {0};
    FILE *fp = NULL;

    snprintf(cmd, 256, "df | grep \"dev/mmcblk0p1\" | awk '{print $1}'");
    fp = popen(cmd,"r");
    if(fp == NULL)
    {
        return false;
    }
    fread(tmp_buff, 1, sizeof(tmp_buff), fp);
    if(!strncmp(tmp_buff, "/dev/mmcblk0p1", strlen("/dev/mmcblk0p1")))
    {
        pclose(fp);
        return true;
    }
    pclose(fp);
    return false;
}


/**
 * @brief  故障录波文件名称解析
 * @param  [in]  file_index：文件序号
 * @param  [in]  p_file_name：文件名称
 * @param  [out] 
 * @return 
 */
static void fault_record_file_name_info_parse(int file_index, char *p_file_name)
{
    char *p_pos = NULL;
    char date[32] = {0};

    p_pos = strchr(p_file_name, '-');
    if(p_pos != NULL)
    {
        strcpy(g_fault_recorder_info[file_index].file_name, p_file_name);
        strncpy((char *)date, p_file_name, p_pos - p_file_name);
        strncpy(&g_fault_recorder_info[file_index].file_time[0], &date[0], 4);
        g_fault_recorder_info[file_index].file_time[4] = '/';
        strncpy(&g_fault_recorder_info[file_index].file_time[5], &date[4], 2);
        g_fault_recorder_info[file_index].file_time[7] = '/';
        strncpy(&g_fault_recorder_info[file_index].file_time[8], &date[6], 2);
        g_fault_recorder_info[file_index].file_time[10] = ' ';
        strncpy(&g_fault_recorder_info[file_index].file_time[11], &date[8], 2);
        g_fault_recorder_info[file_index].file_time[13] = ':';
        strncpy(&g_fault_recorder_info[file_index].file_time[14], &date[10], 2);
        g_fault_recorder_info[file_index].file_time[16] = ':';
        strncpy(&g_fault_recorder_info[file_index].file_time[17], &date[12], 2);
        // strncpy(g_fault_recorder_info[file_index].file_time, p_file_name, p_pos - p_file_name);
        g_fault_recorder_info[file_index].file_index = file_index + 1;
        g_fault_recorder_info[file_index].fault_id = atoi(p_pos + 1);
        print_log("file index:%d  name:%s id:%d", g_fault_recorder_info[file_index].file_index, \
                                                  g_fault_recorder_info[file_index].file_time, \
                                                  g_fault_recorder_info[file_index].fault_id);
    
    }

}

/**
 * @brief  对比文件修改时间
 * @param  [in] 
 * @param  [out] 
 * @return 
 */
int32_t compare_mod_time(const void *a, const void *b)
{
    file_info_t *fileInfoA = (file_info_t *)a;
    file_info_t *fileInfoB = (file_info_t *)b;
    return difftime(fileInfoB->mod_time, fileInfoA->mod_time);
}


/**
 * @brief  故障录波文件名称解析
 * @param  [in]  
 * @param  [out] 
 * @return 
 */
static void fault_record_file_list_parse(uint8_t *p_file_num)
{
    DIR *p_dir = NULL;
    fs_t *p_fs = NULL;
    struct dirent *p_entry = NULL;
    file_info_t *p_files = NULL;
    struct stat statbuf;
    uint8_t file_path[128] = {0};
    uint16_t file_num = 0;
    int32_t ret = -1;
    bool sd_sta = false;
    int i = 0;

    /* 检测SD卡是否存在 */
    sd_sta = sd_mount_status();

    if(sd_sta == false)
    {
       print_log((int8_t *)"TF_CARD does not exist!!!"); 
       return; 
    }
    // 尝试打开目录
    p_dir = opendir(PATH_FAULT_RECORD_FOLDER);
    if(p_dir == NULL)
    {
        print_log((int8_t *)"open fault record dir fail");
        return;
    }

    // 遍历文件夹下的所有文件，统计文件个数
    while((p_entry = readdir(p_dir)) != NULL)
    {
        snprintf((char*)file_path, sizeof(file_path), "%s%s", PATH_FAULT_RECORD_FOLDER, p_entry->d_name);
        stat((const char *)file_path, &statbuf);
        if(p_entry->d_type == 8 && p_entry->d_name[0] != '.')
        {
            file_num++;
        }
    }

    p_files = malloc(file_num * sizeof(file_info_t));
    if(p_files == NULL)
    {
        closedir(p_dir);
        return;
    }

    rewinddir(p_dir);

    while((p_entry = readdir(p_dir)) != NULL)
    {
        if(p_entry->d_type == 8 && p_entry->d_name[0] != '.' && i < file_num)
        {
            memset(file_path, 0, sizeof(file_path));
            snprintf((char*)file_path, sizeof(file_path), "%s%s", PATH_FAULT_RECORD_FOLDER, p_entry->d_name);
            stat((const char *)file_path, &statbuf);
            strcpy(p_files[i].name, p_entry->d_name);
            p_files[i].mod_time = statbuf.st_mtime;
            i++;
        }
    }   
    qsort(p_files, file_num, sizeof(file_info_t), compare_mod_time);

    for(i = 0; i < file_num; i++)
    {
        fault_record_file_name_info_parse(i, p_files[i].name);
    }
    *p_file_num = file_num;
    closedir(p_dir);
    free(p_files);

	return;
}


/**
 * @brief    获取CMU故障录波文件列表
 * @param	 [in] *p_nc 连接信息
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void cmu_fault_recorder_file_list_get(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
    cJSON *p_fault_array = NULL;
    cJSON *p_fault_item = NULL;
	uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t response[256] = {0};
    uint8_t request_body[1024] = {0};
    uint8_t file_num = 0;
	int32_t ret = 0;
    uint8_t i = 0;
	constant_parameter_data_t *p_para_data = NULL;
	
	p_para_data = sdk_shm_constant_parameter_data_get();
    memcpy(request_body, p_msg->body.p, p_msg->body.len);
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        print_log((int8_t *)"parse request failed.");
        build_empty_response(response, 202, "parse request failed.");
        http_back(p_nc, response);
        return;
    }

	if(NULL == cJSON_GetObjectItem(p_request, "action"))
	{
        print_log((int8_t *)"action is NULL");
        build_empty_response(response, 203, "action is NULL");
        http_back(p_nc, response);
        cJSON_Delete(p_request);
        return;
	}

	p_action = cJSON_GetObjectItem(p_request, "action")->valuestring;
	if(strcmp(p_action, "getFaultRecorderList"))
	{
        print_log((int8_t *)"action is not right.");
        build_empty_response(response, 203, "action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
	cJSON_Delete(p_request);

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		print_log((int8_t *)"create json obj failed.");
		return;
	}

    p_fault_array = cJSON_CreateArray();
	if(p_fault_array == NULL)
	{
		print_log((int8_t *)"create json obj failed.");
		cJSON_Delete(p_resp_root);
		return;
	}

    fault_record_file_list_parse(&file_num);
    if(file_num > 0)
    {
        for(i = 0; i < file_num; i++)
        {
            p_fault_item = cJSON_CreateObject();
            if(p_fault_item == NULL)
            {
                print_log((int8_t *)"create json obj failed.");
				cJSON_Delete(p_fault_array);
				cJSON_Delete(p_resp_root);
                return;
            }
            cJSON_AddStringToObject(p_fault_item, "time", g_fault_recorder_info[i].file_time);
            cJSON_AddNumberToObject(p_fault_item, "FaultID", g_fault_recorder_info[i].fault_id);
            cJSON_AddNumberToObject(p_fault_item, "Index", g_fault_recorder_info[i].file_index);
            cJSON_AddItemToArray(p_fault_array, p_fault_item);
        }
        p_fault_item = cJSON_CreateObject();
        if(p_fault_item == NULL)
        {
            print_log((int8_t *)"create json obj failed.");
			cJSON_Delete(p_fault_array);
				cJSON_Delete(p_resp_root);
            return;
        }
        cJSON_AddStringToObject(p_fault_item, "time", "");
        cJSON_AddNumberToObject(p_fault_item, "FaultID", 0xFFFF);
        cJSON_AddNumberToObject(p_fault_item, "Index", 0);
        cJSON_AddItemToArray(p_fault_array, p_fault_item);
    }

	cJSON_AddNumberToObject(p_resp_root,"code", 200);
	cJSON_AddNumberToObject(p_resp_root,"lc_type", p_para_data->dynamic_ring.lc_type);
    cJSON_AddItemToObject(p_resp_root,"FaultList", p_fault_array);
	cJSON_AddStringToObject(p_resp_root,"msg", "successful");

	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);
}


/**
 * @brief   录波文件转换
 * @param	[in] file_index：文件索引号
 * @return  0：成功  -1：失败
 */
static uint8_t cmu_fault_recorder_file_trans(uint8_t file_index)
{
    int32_t ret = 0;
    char src_file[128] = {0};
    char det_file[128] = {0};
    uint8_t file_num = 0;
    uint8_t i = 0;

    fault_record_file_list_parse(&file_num);
    // 文件夹不存在，先创建文件夹
    if ((sdk_fs_access((int8_t *)PATH_FAULT_RECORD_CSV_FOLDER, FS_F_OK)) == -1)
    {
        sdk_fs_mkdir(PATH_FAULT_RECORD_CSV_FOLDER, FS_S_IRWXU|FS_S_IRWXG|FS_S_IRWXO);
        print_log((int8_t *)"direct not exist but has created!");
    }
    sdk_system_cmd((int8_t *)"rm -rf /user/data/cmu_fault_record/CMUFaultRecorder/*");

    if(file_index > 0)
    {
        sprintf(src_file, "%s%s", PATH_FAULT_RECORD_FOLDER, g_fault_recorder_info[file_index - 1].file_name);
        sprintf(det_file, "%s%s.csv", PATH_FAULT_RECORD_CSV_FOLDER, g_fault_recorder_info[file_index - 1].file_name);
        print_log((int8_t *)"src_file:%s\n", src_file);
        print_log((int8_t *)"det_file:%s\n", det_file);
        ret = fault_recorder_data2csv(src_file, det_file);
        if(ret == 0)
        {
            //对文件夹进行压缩
            sdk_system_cmd((int8_t *)"tar -cvf /user/data/cmu_fault_record/CMUFaultRecorder/CMUFaultRecorder.tar.gz -C /user/data/cmu_fault_record/CMUFaultRecorder .");
        }
    }
    else
    {
        for(i = 0; i < file_num; i++)
        {
            sprintf(src_file, "%s%s", PATH_FAULT_RECORD_FOLDER, g_fault_recorder_info[i].file_name);
            sprintf(det_file, "%s%s.csv", PATH_FAULT_RECORD_CSV_FOLDER, g_fault_recorder_info[i].file_name);
            print_log((int8_t *)"src_file:%s\n", src_file);
            print_log((int8_t *)"det_file:%s\n", det_file);
            ret = fault_recorder_data2csv(src_file, det_file);
        }
        //对文件夹进行压缩
        sdk_system_cmd((int8_t *)"tar -cvf /user/data/cmu_fault_record/CMUFaultRecorder/CMUFaultRecorder.tar.gz -C /user/data/cmu_fault_record/CMUFaultRecorder .");
    }


    return ret;
}


/**
 * @brief    请求导出故障录波
 * @param	 [in] *p_nc 连接信息
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void cmu_fault_recorder_file_generate(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	uint8_t response[256];
	uint8_t *p_action = NULL;
	uint8_t *p = NULL;
	uint8_t request_body[1024] = {0};
	uint32_t index = 0;
	int32_t ret = 0;

    memcpy(request_body, p_msg->body.p, p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response, 202, "parse request failed.");
		http_back(p_nc,response);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request, "action")->valuestring;
	if(strcmp(p_action,"generateFaultRecorderCMU"))
	{
		print_log("action is not right.");
		build_empty_response(response, 203, "action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	index = cJSON_GetObjectItem(p_request,"index")->valueint;
	cJSON_Delete(p_request);

    //根据索引值进行文件转换
    ret = cmu_fault_recorder_file_trans(index);
    if(ret)
    {
        print_log("file trans error");
		build_empty_response(response, 203, "failed");
		http_back(p_nc,response);
        return;
    }

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		print_log("create json obj failed");
		build_empty_response(response, 203, "create json obj failed");
		http_back(p_nc,response);
		return;
	}

	cJSON_AddNumberToObject(p_resp_root, "code", 200);
	cJSON_AddStringToObject(p_resp_root, "msg", "successful");

	p = cJSON_PrintUnformatted(p_resp_root);

	cJSON_Delete(p_resp_root);
	http_back(p_nc, p);
	free(p);
}


/**
 * @brief    请求故障录波文件生成进度
 * @param	 [in] *p_nc 连接信息
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void cmu_fault_recorder_file_progress(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	uint8_t response[256];
	uint8_t *p_action = NULL;
	uint8_t *p = NULL;
	uint8_t request_body[1024] = {0};
	int32_t ret = 0;

    memcpy(request_body, p_msg->body.p, p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response, 202, "parse request failed.");
		http_back(p_nc,response);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request, "action")->valuestring;
	if(strcmp(p_action, "getFaultRecorderProgressCMU"))
	{
		print_log("action is not right.");
		build_empty_response(response, 203, "action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	cJSON_Delete(p_request);


	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		print_log("create json obj failed");
		build_empty_response(response, 203, "create json obj failed");
		http_back(p_nc,response);
		return;
	}

    cJSON_AddNumberToObject(p_resp_root, "code", 200);
    cJSON_AddNumberToObject(p_resp_root, "progress", 100);
    cJSON_AddStringToObject(p_resp_root, "msg", "successful");

	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);
}


/**
 * @brief    下载CMU故障录波文件
 * @param	 [in] *p_nc 连接信息
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void cmu_fault_recorder_file_download(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t response[256] = {0};
	int32_t ret = 0;
	uint8_t request_body[1024] = {0};

    memcpy(request_body, p_msg->body.p, p_msg->body.len);
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        print_log((int8_t *)"parse request failed.");
        build_empty_response(response, 202, "parse request failed.");
        http_back(p_nc, response);
        return;
    }

	if(NULL == cJSON_GetObjectItem(p_request, "action"))
	{
        print_log((int8_t *)"action is NULL");
        build_empty_response(response, 203, "action is NULL");
        http_back(p_nc, response);
        cJSON_Delete(p_request);
        return;
	}

	p_action = cJSON_GetObjectItem(p_request, "action")->valuestring;
	if(strcmp(p_action, "exportFaultRecorderCMU"))
	{
        print_log((int8_t *)"action is not right.");
        build_empty_response(response, 203, "action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
	cJSON_Delete(p_request);

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		print_log((int8_t *)"create json obj failed.");
		return;
	}

	cJSON_AddNumberToObject(p_resp_root, "code", 200);
	cJSON_AddStringToObject(p_resp_root, "url", "download/CMUFaultRecorder.tar.gz");
	cJSON_AddStringToObject(p_resp_root, "msg", "successful");

	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);
	return;
}


/**
 * @brief 故障录波模块初始化
 * @return void
 */
void fault_recorder_module_init(void)
{
    //触发CMU生成PCS录波文件
	if(!web_func_attach("/debugManager/generateFaultRecorderPCS", pcs_fault_recorder_file_generate))
	{
		print_log("[/debugManager/generateFaultRecorderPCS] attach failed");
	}
	//获取录波进度
	if(!web_func_attach("/debugManager/getFaultRecorderProgressPCS", pcs_fault_recorder_file_progress))
	{
		print_log("[/debugManager/getFaultRecorderProgressPCS] attach failed");
	}
	//导出录波文件
	if(!web_func_attach("/debugManager/exportFaultRecorderPCS", pcs_fault_recorder_file_download))
	{
		print_log("[/debugManager/exportFaultRecorderPCS] attach failed");
	}

    //获取CMU故障录波文件列表
    if(!web_func_attach("/debugManager/getFaultRecorderList", cmu_fault_recorder_file_list_get))
	{
		print_log("[/debugManager/getFaultRecorderList] attach failed");
	}
    //触发CMU生成录波文件
	if(!web_func_attach("/debugManager/generateFaultRecorderCMU", cmu_fault_recorder_file_generate))
	{
		print_log("[/debugManager/generateFaultRecorderCMU] attach failed");
	}
	//获取录波进度
	if(!web_func_attach("/debugManager/getFaultRecorderProgressCMU", cmu_fault_recorder_file_progress))
	{
		print_log("[/debugManager/getFaultRecorderProgressCMU] attach failed");
	}
	//导出录波文件
	if(!web_func_attach("/debugManager/exportFaultRecorderCMU", cmu_fault_recorder_file_download))
	{
		print_log("[/debugManager/exportFaultRecorderCMU] attach failed");
	}
}