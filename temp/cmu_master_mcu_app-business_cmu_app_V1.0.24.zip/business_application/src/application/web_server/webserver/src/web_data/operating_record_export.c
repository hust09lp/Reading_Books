/*****************************************************************************
* File Name          : operating_record_export.c            
* Description        : 运行数据记录文件U盘导出
* Original Author    : liangguyao
* date               : 2023.02.15
******************************************************************************/

#include "operating_record_export.h"
#include "operating_data_handle.h"
#include "sdk_fs.h"
#include "sofar_log.h"
#include "sdk_store.h"
#include "sofar_errors.h"
#include "crc.h"

#include <string.h>


#define READ_MAX_COUNT    480    /* 一个文件（一天）读取的最大次数（最大理论值，3min保存一次的运行数据） 24*60/3 = 480 */


/**
 * @brief   运行时间标题栏（首行）输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @return  无
 */
static void operating_time_title_bar_input(FILE *p_fp_des)
{
    fprintf(p_fp_des, "%s,", "operating_time");
}

/**
 * @brief   遥信运行数据标题栏（首行）输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @return  无
 */
static void telematic_title_bar_input(FILE *p_fp_des)
{
    int i;
    int num;

    for (i = 0; i < CMU_SYSTEM_FAULT_LEN_BYTE; i++)
    {
        fprintf(p_fp_des, "CMU_system_fault_%d,", i);  // CMU_system_fault_info[CMU_SYSTEM_FAULT_LEN_BYTE]
    }

    for (i = 0; i < CONTAINER_SYSTEM_STATUS_LEN_BYTE; i++)
    {
        fprintf(p_fp_des, "system_status_%d,", i);  // container_system_status_info[CONTAINER_SYSTEM_STATUS_LEN_BYTE]
    }

    for (i = 0; i < CONTAINER_SYSTEM_WARN_LEN_BYTE; i++)
    {
        fprintf(p_fp_des, "system_warn_%d,", i);  // container_system_warn_info[CONTAINER_SYSTEM_WARN_LEN_BYTE]
    }

    for (i = 0; i < CONTAINER_SYSTEM_FAULT_LEN_BYTE; i++)
    {
        fprintf(p_fp_des, "system_fault_%d,", i);  // container_system_fault_info[CONTAINER_SYSTEM_FAULT_LEN_BYTE]
    }

    for (num = 0; num < BCU_DEVICE_NUM; num++)  // battery_cluster_telematic_info[BCU_DEVICE_NUM]
    {
        for (i = 0; i < BATTERY_CLUSTER_STATUS_LEN_BYTE; i++)
        {
            fprintf(p_fp_des, "battery_cluster_%d_telematic_status_%d,", num, i);  // battery_cluster_status_info[BATTERY_CLUSTER_STATUS_LEN_BYTE]
        }

        for (i = 0; i < BATTERY_CLUSTER_WARN_LEN_BYTE; i++)
        {
            fprintf(p_fp_des, "battery_cluster_%d_telematic_warn_%d,", num, i);  // battery_cluster_warn_info[BATTERY_CLUSTER_WARN_LEN_BYTE]
        }

        for (i = 0; i < BATTERY_CLUSTER_FAULT_LEN_BYTE; i++)
        {
            fprintf(p_fp_des, "battery_cluster_%d_telematic_fault_%d,", num, i);  // battery_cluster_fault_info[BATTERY_CLUSTER_FAULT_LEN_BYTE]
        }
    }
}

/**
 * @brief   cmu遥测运行数据标题栏（首行）输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @return  无
 */
static void cmu_telemetry_title_bar_input(FILE *p_fp_des)
{
    fprintf(p_fp_des, "%s,%s,", "mcu1_hardware_ver", "mcu1_software_ver");
    fprintf(p_fp_des, "%s,%s,%s,", "mcu2_software_ver", "sci_protocol_ver", "cmu_sys_state");
}

/**
 * @brief   集装箱系统遥测运行数据标题栏（首行）输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @return  无
 */
static void container_system_telemetry_title_bar_input(FILE *p_fp_des)
{
    /* 集装箱 */
    fprintf(p_fp_des, "%s,%s,", "soc", "soh");
    fprintf(p_fp_des, "%s,%s,", "charge_limits_power", "discharge_limits_power");
    fprintf(p_fp_des, "%s,%s,", "charge_limits_capacity", "discharge_limits_capacity");
    fprintf(p_fp_des, "%s,%s,%s,", "total_voltage", "total_current", "charge_discharge_power");
    fprintf(p_fp_des, "%s,%s,", "battery_cluster_number", "battery_type");

    /* 温湿度传感器 */
    fprintf(p_fp_des, "%s,%s,%s,", "bat1_humidity", "bat2_humidity", "bat3_humidity");
    fprintf(p_fp_des, "%s,%s,%s,", "bat4_humidity", "bat5_humidity", "bat6_humidity");
    fprintf(p_fp_des, "%s,%s,%s,", "bat1_temper", "bat2_temper", "bat3_temper");
    fprintf(p_fp_des, "%s,%s,%s,", "bat4_temper", "bat5_temper", "bat6_temper");

    /* 液冷机组 */
    fprintf(p_fp_des, "%s,%s,%s,", "lc_outdoor_temper", "lc_inlet_temp", "lc_outlet_temp");
    fprintf(p_fp_des, "%s,%s,", "lc_inlet_pressure", "lc_outlet_pressure");
    fprintf(p_fp_des, "%s,%s,", "lc_control_mode", "lc_sofar_mode");

    /* 消防复合型传感器 */
    fprintf(p_fp_des, "%s,%s,%s", "mix_sensor1_temp", "mix_sensor1_co_ppm", "mix_sensor1_pm25_ppm");
    fprintf(p_fp_des, "%s,%s,%s", "mix_sensor2_temp", "mix_sensor2_co_ppm", "mix_sensor2_pm25_ppm");
    fprintf(p_fp_des, "%s,%s,%s", "mix_sensor3_temp", "mix_sensor3_co_ppm", "mix_sensor3_pm25_ppm");
    fprintf(p_fp_des, "%s,%s,%s", "mix_sensor4_temp", "mix_sensor4_co_ppm", "mix_sensor4_pm25_ppm");
    fprintf(p_fp_des, "%s,%s,%s", "mix_sensor5_temp", "mix_sensor5_co_ppm", "mix_sensor5_pm25_ppm");
    fprintf(p_fp_des, "%s,%s,%s", "mix_sensor6_temp", "mix_sensor6_co_ppm", "mix_sensor6_pm25_ppm");

    /* 消防 */
    fprintf(p_fp_des, "%s,%s,", "fire_fan_start_1co", "fire_fan_start_2co");
    fprintf(p_fp_des, "%s,%s,", "fire_fan_start_3co", "fire_fan_start_4co");
    fprintf(p_fp_des, "%s,%s,", "fire_fan_start_5co", "fire_fan_start_6co");

    /* 集装箱电表 */
    fprintf(p_fp_des, "%s,%s,%s,%s", "voltage_phase_A", "voltage_phase_B", "voltage_phase_C", "active_power_combined");
    fprintf(p_fp_des, "%s,%s,%s,%s", "active_power_phase_A", "active_power_phase_B", "active_power_phase_C", "reactive_power_combined");
    fprintf(p_fp_des, "%s,%s,%s,%s", "reactive_power_phase_A", "reactive_power_phase_B", "reactive_power_phase_C", "frequency");
    fprintf(p_fp_des, "%s,%s,%s,%s", "forward_active_energy_total", "forward_active_energy_phase_A", "forward_active_energy_phase_B", "forward_active_energy_phase_C");
}

/**
 * @brief   集装箱内电池簇遥测运行数据标题栏（首行）输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @return  无
 */
static void battery_cluster_telemetry_title_bar_input(FILE *p_fp_des)
{
    int i, j;
    int num;

    for (num = 0; num < BCU_DEVICE_NUM; num++)  // battery_cluster_telemetry_info[BCU_DEVICE_NUM];
    {
        fprintf(p_fp_des, "battery_cluster_%d_software_version,", num);
        fprintf(p_fp_des, "battery_cluster_%d_BCU_comm_status,", num);
        fprintf(p_fp_des, "battery_cluster_%d_cluster_voltage,", num);
        fprintf(p_fp_des, "battery_cluster_%d_cluster_current,", num);
        fprintf(p_fp_des, "battery_cluster_%d_cluster_SOC,", num);
        fprintf(p_fp_des, "battery_cluster_%d_pos_resistance,", num);
        fprintf(p_fp_des, "battery_cluster_%d_neg_resistance,", num);

        for (i = 0; i < 4; i++)
        {
            fprintf(p_fp_des, "battery_cluster_%d_temperature_%d,", num, i);  // high_pressure_box_temperature[4]
        }

        fprintf(p_fp_des, "battery_cluster_%d_PACK_number,", num);
        fprintf(p_fp_des, "battery_cluster_%d_battery_number,", num);
        fprintf(p_fp_des, "battery_cluster_%d_total_number,", num);
        fprintf(p_fp_des, "battery_cluster_%d_temperature_number_in_PACK,", num);
        fprintf(p_fp_des, "battery_cluster_%d_total_temperature_number,", num);

        for (i = 0; i < 3; i++)
        {
            fprintf(p_fp_des, "battery_cluster_%d_highest_monomer_%d,", num, i);  // highest_monomer_voltage_cluster[3]
        }

        for (i = 0; i < 3; i++)
        {
            fprintf(p_fp_des, "battery_cluster_%d_lowest_monomer_%d,", num, i);  // lowest_monomer_voltage_cluster[3]
        }

        fprintf(p_fp_des, "battery_cluster_%d_highest_voltage,", num);
        fprintf(p_fp_des, "battery_cluster_%d_lowest_voltage,", num);
        fprintf(p_fp_des, "battery_cluster_%d_average_voltage,", num);

        for (i = 0; i < 3; i++)
        {
            fprintf(p_fp_des, "battery_cluster_%d_highest_temp_%d,", num, i);  // highest_monomer_temperature_cluster[3]
        }

        for (i = 0; i < 3; i++)
        {
            fprintf(p_fp_des, "battery_cluster_%d_lowest_temp_%d,", num, i);  // lowest_monomer_temperature_cluster[3]
        }

        fprintf(p_fp_des, "battery_cluster_%d_highest_temp,", num);
        fprintf(p_fp_des, "battery_cluster_%d_lowest_temp,", num);
        fprintf(p_fp_des, "battery_cluster_%d_average_temp,", num);

        for (i = 0; i < 3; i++)
        {
            fprintf(p_fp_des, "battery_cluster_%d_highest_SOC_%d,", num, i);  // highest_monomer_SOC_cluster[3]
        }

        for (i = 0; i < 3; i++)
        {
            fprintf(p_fp_des, "battery_cluster_%d_lowest_SOC_%d,", num, i);  // lowest_monomer_SOC_cluster[3]
        }

        fprintf(p_fp_des, "battery_cluster_%d_highest_SOC,", num);
        fprintf(p_fp_des, "battery_cluster_%d_lowest_SOC,", num);
        fprintf(p_fp_des, "battery_cluster_%d_average_SOC,", num);

        for (i = 0; i < 3; i++)
        {
            fprintf(p_fp_des, "battery_cluster_%d_highest_SOH_%d,", num, i);  // highest_monomer_SOH_cluster[3]
        }

        for (i = 0; i < 3; i++)
        {
            fprintf(p_fp_des, "battery_cluster_%d_lowest_SOH_%d,", num, i);  // lowest_monomer_SOH_cluster[3]
        }

        fprintf(p_fp_des, "battery_cluster_%d_highest_SOH,", num);
        fprintf(p_fp_des, "battery_cluster_%d_lowest_SOH,", num);
        fprintf(p_fp_des, "battery_cluster_%d_average_SOH,", num);

        for (i = 0; i < PACK_NUMBER; i++)  // monomer_info[PACK_NUMBER]
        {
            for (j = 0; j < MONOMER_NUMBER_IN_PACK; j++)
            {
                fprintf(p_fp_des, "battery_cluster_%d_voltage_%d_%d,", num, i, j);  // monomer_voltage[MONOMER_NUMBER_IN_PACK]
            }

            for (j = 0; j < MONOMER_NUMBER_IN_PACK; j++)
            {
                fprintf(p_fp_des, "battery_cluster_%d_temperature_%d_%d,", num, i, j);  // monomer_temperature[MONOMER_NUMBER_IN_PACK]
            }

            for (j = 0; j < MONOMER_NUMBER_IN_PACK; j++)
            {
                fprintf(p_fp_des, "battery_cluster_%d_SOC_%d_%d,", num, i, j);  // monomer_SOC[MONOMER_NUMBER_IN_PACK]
            }

            for (j = 0; j < MONOMER_NUMBER_IN_PACK; j++)
            {
                fprintf(p_fp_des, "battery_cluster_%d_SOH_%d_%d,", num, i, j);  // monomer_SOH[MONOMER_NUMBER_IN_PACK]
            }

            for (j = 0; j < MONOMER_NUMBER_IN_PACK; j++)
            {
                fprintf(p_fp_des, "battery_cluster_%d_SOE_%d_%d,", num, i, j);  // monomer_SOE[MONOMER_NUMBER_IN_PACK]
            }

            for (j = 0; j < MONOMER_NUMBER_IN_PACK; j++)
            {
                fprintf(p_fp_des, "battery_cluster_%d_SOP_%d_%d,", num, i, j);  // monomer_SOP[MONOMER_NUMBER_IN_PACK]
            }
        }

        for (i = 0; i < PACK_NUMBER; i++)  // pole_temperater_PACK[PACK_NUMBER][POLE_TEMP_NUM_IN_PACK]
        {
            for (j = 0; j < POLE_TEMP_NUM_IN_PACK; j++)
            {
                fprintf(p_fp_des, "battery_cluster_%d_pole_temperater_%d_%d,", num, i, j);
            }
        }

        if ((num == 0) || (num == 3) || (num == 6))
        {
            /* 换行并空出一格 */
            fprintf(p_fp_des, "\n,");
        }
    }
}

/**
 * @brief   集装箱内DCDC遥测运行数据标题栏（首行）输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @return  无
 */
static void DCDC_telemetry_title_bar_input(FILE *p_fp_des)
{
    int i;

    fprintf(p_fp_des, "%s,%s,%s,", "software_version", "battery_side_voltage", "battery_side_current");
    fprintf(p_fp_des, "%s,%s,%s,%s,", "bus_side_voltage", "positive_bus_voltage", "negative_bus_voltage", "charge_discharge_power");

    for (i = 0; i < 4; i++)
    {
        fprintf(p_fp_des, "cap_voltage_%d,", i);  // flying_cap_voltage[4]
    }

    for (i = 0; i < 4; i++)
    {
        fprintf(p_fp_des, "inductor_current_%d,", i);  // branch_inductor_current[4]
    }

    for (i = 0; i < 8; i++)
    {
        fprintf(p_fp_des, "sampling_%d,", i);  // temperature_sampling[8]
    }
}

/**
 * @brief   遥测运行数据标题栏（首行）输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @return  无
 */
static void telemetry_title_bar_input(FILE *p_fp_des)
{
    cmu_telemetry_title_bar_input(p_fp_des);
    container_system_telemetry_title_bar_input(p_fp_des);
    battery_cluster_telemetry_title_bar_input(p_fp_des);
    DCDC_telemetry_title_bar_input(p_fp_des);
    fprintf(p_fp_des, "%s\n", "end");
}

/**
 * @brief   csv文件标题栏（首行）输入
 * @param   [in] p_fs_des 已打开的目标文件指针
 * @return  无
 */
static void operating_record_title_bar_input(FILE *p_fp_des)
{
    operating_time_title_bar_input(p_fp_des);
    telematic_title_bar_input(p_fp_des);
    telemetry_title_bar_input(p_fp_des);
}

/**
 * @brief   运行时间数据输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @param   [in] p_operating_data 运行数据结构体指针
 * @return  无
 */
static void operating_time_data_input(FILE *p_fp_des, operating_data_t *p_operating_data)
{
    fprintf(p_fp_des, "%04d-%02d-%02d %02d:%02d:%02d,", (p_operating_data->operating_time.tm_year + 2000), \
            p_operating_data->operating_time.tm_mon, p_operating_data->operating_time.tm_day, \
            p_operating_data->operating_time.tm_hour, p_operating_data->operating_time.tm_min, \
            p_operating_data->operating_time.tm_sec);
}

/**
 * @brief   遥信运行数据输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @param   [in] p_operating_data 运行数据结构体指针
 * @return  无
 */
static void telematic_data_input(FILE *p_fp_des, operating_data_t *p_operating_data)
{
    int i;
    int num;

    for (i = 0; i < CMU_SYSTEM_FAULT_LEN_BYTE; i++)
    {
        fprintf(p_fp_des, "0x%x,", p_operating_data->telematic_operating_data.CMU_system_fault_info[i]);  // CMU_system_fault_info[CMU_SYSTEM_FAULT_LEN_BYTE]
    }

    for (i = 0; i < CONTAINER_SYSTEM_STATUS_LEN_BYTE; i++)
    {
        fprintf(p_fp_des, "0x%x,", p_operating_data->telematic_operating_data.container_system_status_info[i]);  // container_system_status_info[CONTAINER_SYSTEM_STATUS_LEN_BYTE]
    }

    for (i = 0; i < CONTAINER_SYSTEM_WARN_LEN_BYTE; i++)
    {
        fprintf(p_fp_des, "0x%x,", p_operating_data->telematic_operating_data.container_system_warn_info[i]);  // container_system_warn_info[CONTAINER_SYSTEM_WARN_LEN_BYTE]
    }

    for (i = 0; i < CONTAINER_SYSTEM_FAULT_LEN_BYTE; i++)
    {
        fprintf(p_fp_des, "0x%x,", p_operating_data->telematic_operating_data.container_system_fault_info[i]);  // container_system_fault_info[CONTAINER_SYSTEM_FAULT_LEN_BYTE]
    }

    for (num = 0; num < BCU_DEVICE_NUM; num++)  // battery_cluster_telematic_info[BCU_DEVICE_NUM]
    {
        for (i = 0; i < BATTERY_CLUSTER_STATUS_LEN_BYTE; i++)
        {
            fprintf(p_fp_des, "0x%x,", p_operating_data->telematic_operating_data.battery_cluster_telematic_info[num].battery_cluster_status_info[i]);  // battery_cluster_status_info[BATTERY_CLUSTER_STATUS_LEN_BYTE]
        }

        for (i = 0; i < BATTERY_CLUSTER_WARN_LEN_BYTE; i++)
        {
            fprintf(p_fp_des, "0x%x,", p_operating_data->telematic_operating_data.battery_cluster_telematic_info[num].battery_cluster_warn_info[i]);  // battery_cluster_warn_info[BATTERY_CLUSTER_WARN_LEN_BYTE]
        }

        for (i = 0; i < BATTERY_CLUSTER_FAULT_LEN_BYTE; i++)
        {
            fprintf(p_fp_des, "0x%x,", p_operating_data->telematic_operating_data.battery_cluster_telematic_info[num].battery_cluster_fault_info[i]);  // battery_cluster_fault_info[BATTERY_CLUSTER_FAULT_LEN_BYTE]
        }
    }
}

/**
 * @brief   集装箱系统遥测运行数据输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @param   [in] p_operating_data 运行数据结构体指针
 * @return  无
 */
static void cmu_telemetry_data_input(FILE *p_fp_des, operating_data_t *p_operating_data)
{
    fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.cmu_telemetry_operating_info.mcu1_hardware_ver);
    fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.cmu_telemetry_operating_info.mcu1_software_ver);
    fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.cmu_telemetry_operating_info.mcu2_software_ver);
    fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.cmu_telemetry_operating_info.sci_protocol_ver);
    fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.cmu_telemetry_operating_info.cmu_sys_state);
}

/**
 * @brief   集装箱系统遥测运行数据输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @param   [in] p_operating_data 运行数据结构体指针
 * @return  无
 */
static void container_system_telemetry_data_input(FILE *p_fp_des, operating_data_t *p_operating_data)
{
    history_container_system_telemetry_info_t *p_info = &(p_operating_data->telemetry_operating_data.container_system_telemetry_operating_info);

    /* 集装箱 */
    fprintf(p_fp_des, "%d,%d,", p_info->soc, p_info->soh);
    fprintf(p_fp_des, "%d,%d,", p_info->charge_limits_power, p_info->discharge_limits_power);
    fprintf(p_fp_des, "%d,%d,", p_info->charge_limits_capacity, p_info->discharge_limits_capacity);
    fprintf(p_fp_des, "%d,%d,%d,", p_info->total_voltage, p_info->total_current, p_info->charge_discharge_power);
    fprintf(p_fp_des, "%d,%d,", p_info->battery_cluster_number, p_info->battery_type);

    /* 温湿度传感器 */
    fprintf(p_fp_des, "%d,%d,%d,", p_info->bat1_humidity, p_info->bat2_humidity, p_info->bat3_humidity);
    fprintf(p_fp_des, "%d,%d,%d,", p_info->bat4_humidity, p_info->bat5_humidity, p_info->bat6_humidity);
    fprintf(p_fp_des, "%d,%d,%d,", p_info->bat1_temper, p_info->bat2_temper, p_info->bat3_temper);
    fprintf(p_fp_des, "%d,%d,%d,", p_info->bat4_temper, p_info->bat5_temper, p_info->bat6_temper);

    /* 液冷机组 */
    fprintf(p_fp_des, "%d,%d,%d,", p_info->lc_outdoor_temper, p_info->lc_inlet_temp, p_info->lc_outlet_temp);
    fprintf(p_fp_des, "%d,%d,", p_info->lc_inlet_pressure, p_info->lc_outlet_pressure);
    fprintf(p_fp_des, "%d,%d,", p_info->lc_control_mode, p_info->lc_sofar_mode);

    /* 消防复合型传感器 */
    fprintf(p_fp_des, "%d,%d,%d,", p_info->mix_sensor1_temp, p_info->mix_sensor1_co_ppm, p_info->mix_sensor1_pm25_ppm);
    fprintf(p_fp_des, "%d,%d,%d,", p_info->mix_sensor2_temp, p_info->mix_sensor2_co_ppm, p_info->mix_sensor2_pm25_ppm);
    fprintf(p_fp_des, "%d,%d,%d,", p_info->mix_sensor3_temp, p_info->mix_sensor3_co_ppm, p_info->mix_sensor3_pm25_ppm);
    fprintf(p_fp_des, "%d,%d,%d,", p_info->mix_sensor4_temp, p_info->mix_sensor4_co_ppm, p_info->mix_sensor4_pm25_ppm);
    fprintf(p_fp_des, "%d,%d,%d,", p_info->mix_sensor5_temp, p_info->mix_sensor5_co_ppm, p_info->mix_sensor5_pm25_ppm);
    fprintf(p_fp_des, "%d,%d,%d,", p_info->mix_sensor6_temp, p_info->mix_sensor6_co_ppm, p_info->mix_sensor6_pm25_ppm);

    /* 消防 */
    fprintf(p_fp_des, "%d,%d,", p_info->fire_fan_start_1co, p_info->fire_fan_start_2co);
    fprintf(p_fp_des, "%d,%d,", p_info->fire_fan_start_3co, p_info->fire_fan_start_4co);
    fprintf(p_fp_des, "%d,%d,", p_info->fire_fan_start_5co, p_info->fire_fan_start_6co);

    /* 集装箱电表 */
    fprintf(p_fp_des, "%f,%f,", p_info->voltage_phase_A, p_info->voltage_phase_B);
    fprintf(p_fp_des, "%f,%f,", p_info->voltage_phase_C, p_info->active_power_combined);
    fprintf(p_fp_des, "%f,%f,", p_info->active_power_phase_A, p_info->active_power_phase_B);
    fprintf(p_fp_des, "%f,%f,", p_info->active_power_phase_C, p_info->reactive_power_combined);
    fprintf(p_fp_des, "%f,%f,", p_info->reactive_power_phase_A, p_info->reactive_power_phase_B);
    fprintf(p_fp_des, "%f,%f,", p_info->reactive_power_phase_C, p_info->frequency);
    fprintf(p_fp_des, "%f,%f,", p_info->forward_active_energy_total, p_info->forward_active_energy_phase_A);
    fprintf(p_fp_des, "%f,%f,", p_info->forward_active_energy_phase_B, p_info->forward_active_energy_phase_C);
    
    /* 丢包率 */
    // fprintf(p_fp_des, "%d,%d,", p_info->lc_com_loss_rate, p_info->ff_com_loss_rate);

    // fprintf(p_fp_des, "%d,%d,", p_info->dh_com_loss_rate[0], p_info->dh_com_loss_rate[1]);
    // fprintf(p_fp_des, "%d,%d,", p_info->dh_com_loss_rate[2], p_info->dh_com_loss_rate[3]);
    // fprintf(p_fp_des, "%d,%d,", p_info->dh_com_loss_rate[4], p_info->dh_com_loss_rate[5]);

    // fprintf(p_fp_des, "%d,%d,", p_info->io_ext_com_loss_rate[0], p_info->io_ext_com_loss_rate[1]);
    // fprintf(p_fp_des, "%d,%d,", p_info->io_ext_com_loss_rate[2], p_info->io_ext_com_loss_rate[3]);
    // fprintf(p_fp_des, "%d,%d,", p_info->io_ext_com_loss_rate[4], p_info->io_ext_com_loss_rate[5]);
}

/**
 * @brief   集装箱内电池簇遥测运行数据输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @param   [in] p_operating_data 运行数据结构体指针
 * @return  无
 */
static void battery_cluster_telemetry_data_input(FILE *p_fp_des, operating_data_t *p_operating_data)
{
    int i, j;
    int num;

    for (num = 0; num < BCU_DEVICE_NUM; num++)  //battery_cluster_telemetry_info[BCU_DEVICE_NUM]
    {
        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].software_version);
        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].BCU_comm_status);
        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].cluster_voltage);
        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].cluster_current);
        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].cluster_SOC);
        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].positive_insulation_resistance);
        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].negative_insulation_resistance);

        for (i = 0; i < 4; i++)
        {
            fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].high_pressure_box_temperature[i]);  // high_pressure_box_temperature[4]
        }

        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].PACK_number_in_cluster);
        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].battery_number_in_PACK);
        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].total_battery_number);
        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].temperature_number_in_PACK);
        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].total_temperature_number);

        for (i = 0; i < 3; i++)
        {
            fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].highest_monomer_voltage_cluster[i]);  // highest_monomer_voltage_cluster[3]
        }

        for (i = 0; i < 3; i++)
        {
            fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].lowest_monomer_voltage_cluster[i]);  // lowest_monomer_voltage_cluster[3]
        }

        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].battery_node_highest_voltage);
        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].battery_node_lowest_voltage);
        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].average_voltage_monomer);

        for (i = 0; i < 3; i++)
        {
            fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].highest_monomer_temperature_cluster[i]);  // highest_monomer_temperature_cluster[3]
        }

        for (i = 0; i < 3; i++)
        {
            fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].lowest_monomer_temperature_cluster[i]);  // lowest_monomer_temperature_cluster[3]
        }

        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].battery_node_highest_temperature);
        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].battery_node_lowest_temperature);
        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].average_temperature_monomer);

        for (i = 0; i < 3; i++)
        {
            fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].highest_monomer_SOC_cluster[i]);  // highest_monomer_SOC_cluster[3]
        }

        for (i = 0; i < 3; i++)
        {
            fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].lowest_monomer_SOC_cluster[i]);  // lowest_monomer_SOC_cluster[3]
        }

        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].battery_node_highest_SOC);
        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].battery_node_lowest_SOC);
        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].average_SOC_monomer);

        for (i = 0; i < 3; i++)
        {
            fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].highest_monomer_SOH_cluster[i]);  // highest_monomer_SOH_cluster[3]
        }

        for (i = 0; i < 3; i++)
        {
            fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].lowest_monomer_SOH_cluster[i]);  // lowest_monomer_SOH_cluster[3]
        }

        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].battery_node_highest_SOH);
        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].battery_node_lowest_SOH);
        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].average_SOH_monomer);

        for (i = 0; i < PACK_NUMBER; i++)  // monomer_info[PACK_NUMBER]
        {
            for (j = 0; j < MONOMER_NUMBER_IN_PACK; j++)
            {
                fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].monomer_info[i].monomer_voltage[j]);  // monomer_voltage[MONOMER_NUMBER_IN_PACK]
            }

            for (j = 0; j < MONOMER_NUMBER_IN_PACK; j++)
            {
                fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].monomer_info[i].monomer_temperature[j]);  // monomer_temperature[MONOMER_NUMBER_IN_PACK]
            }

            for (j = 0; j < MONOMER_NUMBER_IN_PACK; j++)
            {
                fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].monomer_info[i].monomer_SOC[j]);  // monomer_SOC[MONOMER_NUMBER_IN_PACK]
            }

            for (j = 0; j < MONOMER_NUMBER_IN_PACK; j++)
            {
                fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].monomer_info[i].monomer_SOH[j]);  // monomer_SOH[MONOMER_NUMBER_IN_PACK]
            }

            for (j = 0; j < MONOMER_NUMBER_IN_PACK; j++)
            {
                fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].monomer_info[i].monomer_SOE[j]);  // monomer_SOE[MONOMER_NUMBER_IN_PACK]
            }

            for (j = 0; j < MONOMER_NUMBER_IN_PACK; j++)
            {
                fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].monomer_info[i].monomer_SOP[j]);  // monomer_SOP[MONOMER_NUMBER_IN_PACK]
            }
        }

        for (i = 0; i < PACK_NUMBER; i++)  // pole_temperater_PACK[PACK_NUMBER][POLE_TEMP_NUM_IN_PACK]
        {
            for (j = 0; j < POLE_TEMP_NUM_IN_PACK; j++)
            {
                fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.battery_cluster_telemetry_operating_info[num].pole_temperater_PACK[i][j]);
            }
        }

        if ((num == 0) || (num == 3) || (num == 6))
        {
            /* 换行并空出一格 */
            fprintf(p_fp_des, "\n,");
        }
    }
}

/**
 * @brief   集装箱内DCDC遥测运行数据输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @param   [in] p_operating_data 运行数据结构体指针
 * @return  无
 */
static void DCDC_telemetry_data_input(FILE *p_fp_des, operating_data_t *p_operating_data)
{
    int i;

    fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.DCDC_telemetry_info.software_version);
    fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.DCDC_telemetry_info.battery_side_voltage);
    fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.DCDC_telemetry_info.battery_side_current);
    fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.DCDC_telemetry_info.bus_side_voltage);
    fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.DCDC_telemetry_info.positive_bus_voltage);
    fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.DCDC_telemetry_info.negative_bus_voltage);
    fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.DCDC_telemetry_info.charge_discharge_power);

    for (i = 0; i < 4; i++)
    {
        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.DCDC_telemetry_info.flying_cap_voltage[i]);  // flying_cap_voltage[4]
    }

    for (i = 0; i < 4; i++)
    {
        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.DCDC_telemetry_info.branch_inductor_current[i]);  // branch_inductor_current[4]
    }

    for (i = 0; i < 8; i++)
    {
        fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.DCDC_telemetry_info.temperature_sampling[i]);  // temperature_sampling[8]
    }
}

/**
 * @brief   遥测运行数据输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @param   [in] p_operating_data 运行数据结构体指针
 * @return  无
 */
static void telemetry_data_input(FILE *p_fp_des, operating_data_t *p_operating_data)
{
    cmu_telemetry_data_input(p_fp_des, p_operating_data);
    container_system_telemetry_data_input(p_fp_des, p_operating_data);
    battery_cluster_telemetry_data_input(p_fp_des, p_operating_data);
    DCDC_telemetry_data_input(p_fp_des, p_operating_data);
    fprintf(p_fp_des, "%s\n", "end");
}

/**
 * @brief   csv文件运行数据行输入
 * @param   [in] p_fs_des 已打开的目标文件指针
 * @param   [in] p_operating_data 运行数据结构体指针
 * @return  无
 */
static void operating_record_data_row_input(FILE *p_fp_des, operating_data_t *p_operating_data)
{
    log_i((int8_t *)"[%s:%d] row input!\n", __func__, __LINE__);
    operating_time_data_input(p_fp_des, p_operating_data);
    telematic_data_input(p_fp_des, p_operating_data);
    telemetry_data_input(p_fp_des, p_operating_data);
}

/**
 * @brief   对读取的运行数据帧进行crc校验
 * @param   [in] p_operating_data 运行数据结构体指针
 * @return  结果
 * @retval  0 成功
 * @retval  -1 失败
 */
static int32_t operating_record_data_frame_crc_check(operating_data_t *p_operating_data)
{
    int32_t ret = -1;
    uint32_t crc;

    crc = crc32((const unsigned char *)p_operating_data, (sizeof(operating_data_t) - 4));
    if (p_operating_data->crc == crc)
    {
        ret = 0;
    }

    return ret;
}

/**
 * @brief   csv文件运行数据行输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @return  无
 */
static void operating_record_data_row_crc_error_input(FILE *p_fp_des)
{
    log_i((int8_t *)"[%s:%d] crc error input!\n", __func__, __LINE__);
    fprintf(p_fp_des, "%s,", "crc_error");
    fprintf(p_fp_des, "%s\n", "end");
}

/**
 * @brief   运行数据记录文件导出的数据处理过程
 * @param   [in] p_fs_des 已打开的目标文件指针
 * @param   [in] p_fs_src 已打开的源文件指针
 * @return  结果
 * @retval  0 成功
 * @retval  其他 失败
 */
static int32_t operating_record_export_data_process(fs_t *p_fs_des, fs_t *p_fs_src)
{
    int32_t src_size;
    int32_t once_len;
    int32_t loop_count;
    int32_t ret_len;
    int32_t crc_check;
    FILE *p_fp_des;
    operating_data_t operating_data;

    if (p_fs_des == NULL || p_fs_src == NULL)
    {
        log_i((int8_t *)"[%s:%d] null pointer!\n", __func__, __LINE__);
        return (-1);
    }

    p_fp_des = (FILE *)p_fs_des;

    src_size = sdk_fs_get_size(p_fs_src);
    once_len = sizeof(operating_data_t);
    loop_count = src_size / once_len;
    log_i((int8_t *)"[%s:%d] src_size: %d, loop_count: %d, once_len: %d\n", __func__, __LINE__, src_size, loop_count, once_len);
    if (loop_count < 1)
    {
        log_i((int8_t *)"[%s:%d] no content!\n", __func__, __LINE__);
    }
    else if (loop_count > READ_MAX_COUNT)
    {
        log_i((int8_t *)"[%s:%d] overflow!\n", __func__, __LINE__);
        loop_count = READ_MAX_COUNT;
    }

    /* csv文件标题栏（首行）输入 */
    operating_record_title_bar_input(p_fp_des);

    while (loop_count)
    {
        memset(&operating_data, 0 , sizeof(operating_data_t));
        ret_len = sdk_fs_read(p_fs_src, &operating_data, sizeof(operating_data_t));
        if (ret_len != once_len)
        {
            log_i((int8_t *)"[%s:%d] read len error! ret_len = %d\n", __func__, __LINE__, ret_len);
            return (-1);
        }

        crc_check = operating_record_data_frame_crc_check(&operating_data);
        if (crc_check < 0)
        {
            log_i((int8_t *)"[%s:%d] frame crc error!\n", __func__, __LINE__);
            operating_record_data_row_crc_error_input(p_fp_des);
        }
        else
        {
            operating_record_data_row_input(p_fp_des, &operating_data);
        }

        loop_count--;
    }

    return (0);
}


/**
 * @brief          检查SD卡是否挂载
 * @return         true：挂载 false：没有挂载
 */
static bool sd_mount_status(void)
{
    char cmd[256] = {0};
    char tmp_buff[32] = {0};
    FILE *fp = NULL;

    snprintf(cmd, 256, "df | grep \"dev/mmcblk0p1\" | awk '{print $1}'");
    fp = popen(cmd,"r");
    if(fp == NULL)
    {
        return false;
    }
    fread(tmp_buff, 1, sizeof(tmp_buff), fp);
    if(!strncmp(tmp_buff, "/dev/mmcblk0p1", strlen("/dev/mmcblk0p1")))
    {
        pclose(fp);
        return true;
    }
    pclose(fp);
    return false;
}

/**
 * @brief   运行数据记录文件U盘导出
 * @param   [in] p_date 要导出的日期结构体指针
 * @return  结果
 * @retval  0 导出成功
 * @retval  其他 导出失败
 */
int32_t operating_record_export(operating_date_t *p_date,const uint8_t *udisk_dir)
{
    char src_path[PATH_FILE_MAX_LEN];  // 源文件路径
    char des_path[PATH_FILE_MAX_LEN];  // 目标文件路径
    fs_t *p_fs_src = NULL;
    fs_t *p_fs_des = NULL;
    int32_t ret;
    bool sd_sta = false;
    
    snprintf(src_path, sizeof(src_path), PATH_OPERATING_RECORD_FOLDER "%04d/%04d%02d%02d", \
            p_date->tm_year, p_date->tm_year, p_date->tm_mon, p_date->tm_day);

    /* 检测SD卡是否存在 */
    sd_sta = sd_mount_status();
    if (sd_sta == false)
    {
        log_i((int8_t *)"\n TF_CARD does not exist!!! \n");
        return SF_ERR_NO_OBJECT;
    }

    /* 判断源文件是否存在 */
    ret = sdk_fs_access((const int8_t *)src_path, FS_F_OK);
    if (ret != 0)
    {
        log_i((int8_t *)"[%s:%d] source file does not exist! %s \n", __func__, __LINE__, src_path);
        return EXPORT_RET_SRC_FILE_ERR;
    }

    p_fs_src = sdk_fs_open((const int8_t *)src_path, FS_READ);
    if (p_fs_src == NULL)
    {
        log_i((int8_t *)"\n sdk_fs_open source file fail! \n");
        return EXPORT_RET_SRC_FILE_OPEN_ERR;
    }

    /* 将位置偏移量移动到文件头 */
    ret = sdk_fs_lseek(p_fs_src, 0);
    if (ret < 0)
    {
        log_i((int8_t *)"\n sdk_fs_lseek error! \n");
        sdk_fs_close(p_fs_src);
        return EXPORT_RET_SRC_FILE_SEEK_ERR;
    }

    snprintf(des_path, sizeof(des_path),  "%s/%04d",udisk_dir,p_date->tm_year);
    ret = sdk_fs_access((const int8_t *)des_path, FS_F_OK);
    if(ret != 0)
    {
        ret = sdk_fs_mkdir(des_path, 755);
        if (ret < 0)
        {
            log_i((int8_t *)"\n [%s:%d] sdk_fs_mkdir fail. %s \n", __func__, __LINE__, des_path);
            return SF_ERR_NDEF;
        }
        else
        {
            log_i((int8_t *)"\n [%s:%d] sdk_fs_mkdir succeed. ret = %d\n", __func__, __LINE__, ret);
        }
    }
    
    snprintf(des_path, sizeof(des_path),  "%s/%04d/%04d%02d%02d.csv", \
            udisk_dir,p_date->tm_year, p_date->tm_year, p_date->tm_mon, p_date->tm_day);

    p_fs_des = sdk_fs_open((const int8_t *)des_path, FS_CREATE_ALWAYS);
    if (p_fs_des == NULL)
    {
        log_i((int8_t *)"\n sdk_fs_open des file fail! \n");
        sdk_fs_close(p_fs_src);
        return EXPORT_RET_DES_FILE_OPEN_ERR;
    }

    log_i((int8_t *)"[%s:%d] operating_data_t, size = %d \n", __func__, __LINE__, sizeof(operating_data_t));
    log_i((int8_t *)"[%s:%d] sdk_rtc_t, size = %d \n", __func__, __LINE__, sizeof(sdk_rtc_t));
    log_i((int8_t *)"[%s:%d] telematic_operating_data_t, size = %d \n", __func__, __LINE__, sizeof(telematic_operating_data_t));
    log_i((int8_t *)"[%s:%d] telemetry_operating_data_t, size = %d \n", __func__, __LINE__, sizeof(telemetry_operating_data_t));
    log_i((int8_t *)"[%s:%d] telematic_operating_data_t, battery_cluster_telematic_info_t, size = %d \n", __func__, __LINE__, sizeof(battery_cluster_telematic_info_t));
    log_i((int8_t *)"[%s:%d] telemetry_operating_data_t, battery_cluster_telemetry_info_t, size = %d \n", __func__, __LINE__, sizeof(battery_cluster_telemetry_info_t));

    ret = operating_record_export_data_process(p_fs_des, p_fs_src);
    if (ret < 0)
    {
        ret = EXPORT_RET_DATA_ERR;
    }
    else
    {
        ret = EXPORT_RET_TURE;
    }

    sdk_fs_close(p_fs_src);
    sdk_fs_close(p_fs_des);

    return ret;
}
