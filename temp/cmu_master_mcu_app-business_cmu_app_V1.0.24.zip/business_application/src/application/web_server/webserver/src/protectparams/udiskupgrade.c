#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<dirent.h>
#include<stdbool.h>
#include"cJSON.h"
#include"udiskupgrade.h"
#include"common.h"

#define USB_SDA1 "/media/sda1/firmware"
#define USB_SDB1 "/media/sdb1/firmware"
#define USB_SDC1 "/media/sdc1/firmware"
#define USB_SDD1 "/media/sdd1/firmware"

static bool is_upgrade_file_exists(const uint8_t *udisk_dir,uint8_t *file_name)
{
    DIR *dir;
    struct dirent *entry;
    uint8_t found = 0;

    dir = opendir(udisk_dir);
    if(dir == NULL)
    {
        print_log("open dir %s failed",udisk_dir);
        return false;
    }
    while((entry = readdir(dir)) != NULL)
    {
        if(!strcmp(entry->d_name,".") || !strcmp(entry->d_name,".."))
        {
            continue;
        }

        if(strstr(entry->d_name,".sofar") && strstr(entry->d_name,"ESS2000"))  //找到U盘中要升级的文件了
        {
            sprintf(file_name,"%s/%s",udisk_dir,entry->d_name);
            found = 1;
            break;
        }
    }
    closedir(dir);

    return (found == 1) ? true : false;
}

static bool is_usb_inserted(uint8_t *dir)  //当USB存储设备插入之后,会自动挂载在/media下面
{
    if((access(USB_SDA1,F_OK) != 0) &&
        (access(USB_SDB1,F_OK) != 0) &&
        (access(USB_SDC1,F_OK) != 0) &&
        (access(USB_SDD1,F_OK) != 0)
    )
	{
        return false;
    }

    if(access(USB_SDA1,F_OK) == 0) //   /media/sda1
    {
       strcpy(dir,USB_SDA1);
    }
    else if(access(USB_SDB1,F_OK) == 0)  // /media/sdb1
    {
        strcpy(dir,USB_SDB1);
    }
    else if(access(USB_SDC1,F_OK) == 0)  // /media/sdc1
    {
        strcpy(dir,USB_SDC1);
    }
    else if(access(USB_SDD1,F_OK) == 0)  // /media/sdd1
    {
        strcpy(dir,USB_SDD1);
    }
    return true;
}

extern int8_t g_file_path[64];
extern uint8_t g_upgrade_type_mcu1;
extern uint8_t g_upgrade_type_mcu2;
extern int8_t g_progress_mcu1;
extern int8_t g_progress_mcu2;
extern uint8_t g_reboot_flag;
extern uint8_t g_mcu2_done;

extern void *do_upgrade(void *arg);

void do_usb_upgrade(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    uint8_t response[128];  //
    uint8_t *p_action;
    uint8_t i;
    uint8_t request_body[1024] = {0};
    cJSON *p_type_array;
    int8_t dir[32];
    int8_t file_path[128];

    pthread_t tid;
    pthread_attr_t attr;

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"usbUpgrade"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    g_upgrade_type_mcu1 = 0;
    g_upgrade_type_mcu2 = 0;

    p_type_array = cJSON_GetObjectItem(p_request,"type");
    for(i=0;i<cJSON_GetArraySize(p_type_array);i++)
    {
        if(!strcmp(cJSON_GetArrayItem(p_type_array,i)->valuestring,"MCU1"))
        {
            g_upgrade_type_mcu1 = 1;
        }
        else if(!strcmp(cJSON_GetArrayItem(p_type_array,i)->valuestring,"MCU2"))
        {
            g_upgrade_type_mcu2 = 1;
        }
    }
    cJSON_Delete(p_request);

    if(is_usb_inserted(dir) == false)
    {
        build_empty_response(response,210,"未检测到U盘插入");
		http_back(p_nc,response);
		return;
    }

    if(is_upgrade_file_exists(dir,file_path) == false)
    {
        build_empty_response(response,220,"升级文件不存在");
		http_back(p_nc,response);
		return;
    }

    g_progress_mcu1 = 0;
    g_progress_mcu2 = 0;
    g_reboot_flag = 0;
    g_mcu2_done = 0;
    strcpy(g_file_path,file_path);
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);  //设置线程分离属性
    pthread_create(&tid,&attr,do_upgrade,NULL);

    build_empty_response(response,200,"get usb info successful");
	http_back(p_nc,response);
}