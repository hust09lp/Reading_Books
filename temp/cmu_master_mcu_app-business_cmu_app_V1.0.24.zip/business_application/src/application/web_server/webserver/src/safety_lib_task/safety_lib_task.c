/*
 * @file    : safety_lib_task.c
 * @brief   : 安规库导入、切换等任务
 * @Company : 首航新能源
 * @author  : liuyixuan
 * @note    : 
 * @date    : 2023-01-09
 */

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <errno.h>

#include "data_shm.h"
#include "sdk_shm.h"
//#include "sdk_file.h"
#include "sdk_check.h"
#include "sdk_safety.h"
#include "safety_lib_task.h"
#include "sdk_fs.h"
#include "sofar_errors.h"
//#include "sofar_debug.h"
//#include "firmware_config.h"

//common_data_t *shm;

safety_file_package_signature_t g_safety_file_sign = {0};
uint16_t g_safety_country_code = 0;    //当前安规国家与地区,用于上位机切换安规失败时回退安规国家与地区
int8_t g_safety_firmware_object_num = 0;   //安规对应的升级对象脚标

#if (1)
#define SAFET_DEBUG_PRINT(...) printf(__VA_ARGS__);
#else
#define SAFET_DEBUG_PRINT(...)
#endif

#define SAFETY_FOLDER_PATH  "/user/data/cfg/"   //安规库文件夹所在路径


static int32_t sdk_system_cmd(int8_t * cmd)
{
    FILE *fp = NULL;

    if((fp=popen(cmd, "r")) == NULL)
    {
        printf("[%s:%s:%d] %s, cmd:%s\n", __FILE__,__func__, __LINE__, strerror(errno), cmd);
        return -1;
    }
    pclose(fp);

    return 0;
}

static int16_t new_safety_lib_sign_get(const  uint8_t *file_path)
{
	int8_t data[SAFETY_SIGNING_LENGTH] = {0};

    //检查安规是否存在，不存在则退出
    if (0 != access((const char*)file_path, F_OK))
    {
        return -1;
    }

    FILE *fp = NULL;
    if((fp = fopen((const char*)file_path,"r")) == NULL)
    {
        SAFET_DEBUG_PRINT("open failure");
        return 1;
    }
    if(fseek(fp, -SAFETY_SIGNING_LENGTH, SEEK_END) != 0)    //负数前移
    {
        SAFET_DEBUG_PRINT("seek failure");
        fclose(fp);
        return -1;
    }

    if(fread(data, SAFETY_SIGNING_LENGTH, 1, fp) != 1)
    {
        SAFET_DEBUG_PRINT("read failure");
        fclose(fp);
        return -1;
    }
    fclose(fp);
    memcpy(&g_safety_file_sign, data, sizeof(g_safety_file_sign));
    
    return 0;
}

/**
 * @brief  : 获取安规文件包的签名信息
 * @return  {0:正常}
 * @note   : 带安规文件包存在检测
 * @see    : 
 * @date   : 2023-03-06
 */
static int16_t safety_lib_sign_get(void)
{
	int8_t data[SAFETY_SIGNING_LENGTH] = {0};

    //检查安规是否存在，不存在则退出
    if (0 != access(SAFETY_LIB_PATH, F_OK))
    {
        return -1;
    }

    FILE *fp = NULL;
    if((fp = fopen((char *)SAFETY_LIB_PATH,"r")) == NULL)
    {
        SAFET_DEBUG_PRINT("open failure");
        return 1;
    }
    if(fseek(fp, -SAFETY_SIGNING_LENGTH, SEEK_END) != 0)    //负数前移
    {
        SAFET_DEBUG_PRINT("seek failure");
        fclose(fp);
        return -1;
    }

    if(fread(data, SAFETY_SIGNING_LENGTH, 1, fp) != 1)
    {
        SAFET_DEBUG_PRINT("read failure");
        fclose(fp);
        return -1;
    }
    fclose(fp);
    memcpy(&g_safety_file_sign, data, sizeof(g_safety_file_sign));
    
    return 0;
}

/**
 * @brief  : 安规文件包导入进度
 * @param   {uint16_t} max 总值
 * @param   {uint16_t} now 当前值
 * @return  {*}
 * @note   : 0->100
 * @see    : 
 * @date   : 2023-03-14
 */
static void safety_lib_progress_bar(uint16_t max, uint16_t now)
{
	firmware_update_t *p_update = sdk_shm_firmware_update_info_get();
    p_update->module_percent[g_safety_firmware_object_num] = now*100/max;    //进度条
}


/**
 * @brief  : 签名信息检验
 * @param   {uint8_t} progress_flag
 * @return  {0：正常}
 * @note   : safety_lib_sign_get()带安规文件包存在检测
 * @see    : 
 * @date   : 2023-03-14
 */
static int16_t safety_lib_sign_check(uint8_t progress_flag)
{
	int8_t data[SAFETY_PACKAGE_READ_LENGTH] = {0};
    uint32_t crc32 = 0xFFFFFFFF;
    uint16_t i = 0;
    uint32_t length = 0;    //安规文件包剩余长度
    uint32_t package_num = 0;

    if(safety_lib_sign_get() != 0)
    {
        SAFET_DEBUG_PRINT("safety_lib_sign_get failure");
        return 1;
    }
	SAFET_DEBUG_PRINT("g_safety_file_sign.file_len %d \n", g_safety_file_sign.file_len);
	
    length = g_safety_file_sign.file_len;   //获取安规文件包有效长度

    FILE *fp = NULL;
    if((fp=fopen((char *)SAFETY_LIB_PATH,"r")) == NULL)
    {
        SAFET_DEBUG_PRINT("open failure");
        return 1;
    }
    package_num = (length / SAFETY_PACKAGE_READ_LENGTH) + 1;
	
    for(i = 0; i < package_num; i++)	// length>>10 <==> length/1024; 注意：打印uint64_t的数值时要用%llu
    {
        memset(data, 0, sizeof(data));
        
        if(i == (package_num - 1))     //最后一包
        {
            if(fread(data, length % SAFETY_PACKAGE_READ_LENGTH, 1, fp) != 1)	// length&0x3FF <==> length%1024; 注意：打印uint64_t的数值时要用%llu
            {
                SAFET_DEBUG_PRINT("read failure end %d \n" ,i);
                fclose(fp);
                return 1;
            }
            sdk_check_crc32((uint8_t *)data, length % SAFETY_PACKAGE_READ_LENGTH, &crc32);//减去签名信息中CRC32字段
        }
        else
        {
            if(fread(data, SAFETY_PACKAGE_READ_LENGTH, 1, fp) != 1)
            {
                SAFET_DEBUG_PRINT("read failure %d \n",i);
                fclose(fp);
                return 1;
            }
            sdk_check_crc32((uint8_t *)data, SAFETY_PACKAGE_READ_LENGTH, &crc32);
        }
        if(progress_flag > 0)
        {
            safety_lib_progress_bar(package_num, i + 1);    //进度条
        }
    }
    fclose(fp);

    if(g_safety_file_sign.file_crc != crc32)
    {
        SAFET_DEBUG_PRINT("crc32 failure, crc32 = %d, file_crc32 = %d", crc32, g_safety_file_sign.file_crc);
        return 1;
    }

    return 0;
}


/**
 * @brief  : 签名信息检验
 * @param   {uint8_t} progress_flag
 * @return  {0：正常}
 * @note   : safety_lib_sign_get()带安规文件包存在检测
 * @see    : 
 * @date   : 2023-03-14
 */
static int16_t new_safety_lib_sign_check(uint8_t progress_flag, const  uint8_t *file_path)
{
	int8_t data[SAFETY_PACKAGE_READ_LENGTH] = {0};
    uint32_t crc32 = 0xFFFFFFFF;
    uint16_t i = 0;
    uint32_t length = 0;    //安规文件包剩余长度
    uint32_t package_num = 0;

    if(new_safety_lib_sign_get(file_path) != 0)
    {
        SAFET_DEBUG_PRINT("new_safety_lib_sign_get failure\n");
        return 1;
    }
	SAFET_DEBUG_PRINT("g_safety_file_sign.file_len %d \n", g_safety_file_sign.file_len);
	
    length = g_safety_file_sign.file_len;   //获取安规文件包有效长度

    FILE *fp = NULL;
    if((fp=fopen((const char*)file_path,"r")) == NULL)
    {
        SAFET_DEBUG_PRINT("open failure\n");
        return 1;
    }
    package_num = (length / SAFETY_PACKAGE_READ_LENGTH) + 1;
	
    for(i = 0; i < package_num; i++)	// length>>10 <==> length/1024; 注意：打印uint64_t的数值时要用%llu
    {
        memset(data, 0, sizeof(data));
        
        if(i == (package_num - 1))     //最后一包
        {
            if(fread(data, length % SAFETY_PACKAGE_READ_LENGTH, 1, fp) != 1)	// length&0x3FF <==> length%1024; 注意：打印uint64_t的数值时要用%llu
            {
                SAFET_DEBUG_PRINT("read failure end %d \n" ,i);
                fclose(fp);
                return 1;
            }
            sdk_check_crc32((uint8_t *)data, length % SAFETY_PACKAGE_READ_LENGTH, &crc32);//减去签名信息中CRC32字段
        }
        else
        {
            if(fread(data, SAFETY_PACKAGE_READ_LENGTH, 1, fp) != 1)
            {
                SAFET_DEBUG_PRINT("read failure %d \n",i);
                fclose(fp);
                return 1;
            }
            sdk_check_crc32((uint8_t *)data, SAFETY_PACKAGE_READ_LENGTH, &crc32);
        }
        if(progress_flag > 0)
        {
            safety_lib_progress_bar(package_num, i + 1);    //进度条
        }
    }
    fclose(fp);

    if(g_safety_file_sign.file_crc != crc32)
    {
        SAFET_DEBUG_PRINT("crc32 failure, crc32 = %d, file_crc32 = %d", crc32, g_safety_file_sign.file_crc);
        return 1;
    }

    return 0;
}


/**
 * @brief  : 检测安规库所在路径的文件夹是否存在，如果不存在，则创建该文件夹
 * @param  : void
 * @return  {SF_OK：文件夹已存在或者创建文件夹成功，SF_ERR_NDEF：创建文件夹失败}
 */
static int32_t safety_folder_exist(void)
{
    int32_t ret = SF_OK;

    /* 检测安规库所在路径的文件夹是否存在 */
    ret = sdk_fs_access((const int8_t *)(SAFETY_FOLDER_PATH), F_OK);
    if (ret != SF_OK)	//文件夹不存在,先创建文件夹
    {
        SAFET_DEBUG_PRINT("[%s:%d] /user/data/cfg/ Folder does not exist. \n", __func__, __LINE__);
        ret = sdk_fs_mkdir(SAFETY_FOLDER_PATH, 755);
        if (ret < 0)
        {
            SAFET_DEBUG_PRINT("[%s:%d] sdk_fs_mkdir /user/data/cfg/ fail. \n", __func__, __LINE__);
            return SF_ERR_NDEF;
        }
        else
        {
            SAFET_DEBUG_PRINT("[%s:%d] sdk_fs_mkdir succeed. ret = %d\n", __func__, __LINE__, ret);
        }
    }
    else
    {
        SAFET_DEBUG_PRINT("[%s:%d] /user/data/cfg/ Folder exist. \n", __func__, __LINE__);
    }

    return ret;
}

/**
 * @brief  : 安规库初始化
 * @param   {uint8_t} progress_flag 0:不显示进度条，1：显示进度条
 * @return  {-1：安规文件信息错误，-2：安规标准获取失败}
 * @note   : 检查安规库文件是否存在，并获取当前安规库的版本与安规国家名称
 * @see    : 
 * @date   : 2023-03-14
 */
int16_t safety_lib_init(uint8_t progress_flag)
{
    int16_t ret = -1;
	constant_parameter_data_t *p_constant_parameter = sdk_shm_constant_parameter_data_get();
    safety_attr_t safety_attr = {0};

    safety_attr.region = p_constant_parameter->safety_rdr_country;
    safety_attr.version =p_constant_parameter->ver_safety_rdr_para;

    //检验安规文件包签名信息
    if(0 != safety_lib_sign_check(progress_flag))
    {
        return -1;
    }
    
    //获取安规库的头部信息并检验
    ret = sdk_safety_lib_header_get((const int8_t *)SAFETY_LIB_PATH, &g_safety_regula_package_header);
    if (0 != ret)
    {
        SAFET_DEBUG_PRINT("sdk_safety_lib_header_get failure \n");
        return -1;
    }
    else
    {
        //更新共享内存中的安规库版本
        // shm->modbus_data.inverter_information.safety_lib_ver[0] = (uint16_t)g_safety_regula_package_header.version;
        // log_info(LOG_SAFETY_ENABLE,"1safety_lib_ver = %04x",shm->modbus_data.inverter_information.safety_lib_ver[0]);
    }

    //获取当前安规标准的名称
    ret = sdk_safety_regula_find_by_lib((const int8_t *)SAFETY_LIB_PATH, &safety_attr);
    if (0 != ret)
    {
        SAFET_DEBUG_PRINT("sdk_safety_regula_find_by_lib fail\n");
        return -2;
    }
    else
    {
        //更新共享内存中的安规标准名称
      //  memcpy(shm->modbus_data.inverter_information.safety_name, g_safety_regula_package_index_array[0].country_name, 16);
    }
    return ret;
}

/**
 * @brief  : 安规库初始化
 * @param   {uint8_t} progress_flag 0:不显示进度条，1：显示进度条
 * @return  {-1：安规文件信息错误，-2：安规标准获取失败}
 * @note   : 检查安规库文件是否存在，并获取当前安规库的版本与安规国家名称
 * @see    : 
 * @date   : 2023-03-14
 */
int16_t new_safety_lib_init(uint8_t progress_flag, const  uint8_t *file_path)
{
    int16_t ret = 0;
	constant_parameter_data_t *p_constant_parameter = sdk_shm_constant_parameter_data_get();
    safety_attr_t safety_attr = {0};

    safety_attr.region = p_constant_parameter->safety_rdr_country ;
    safety_attr.version =p_constant_parameter->ver_safety_rdr_para ;

    //检验安规文件包签名信息
    ret = new_safety_lib_sign_check(progress_flag, file_path);
    if(0 != ret)
    {
        SAFET_DEBUG_PRINT("new_safety_lib_sign_check error, ret = %d \n", ret);
        return -1;
    }
    
    //获取安规库的头部信息并检验
    ret = sdk_safety_lib_header_get(file_path, &g_safety_regula_package_header);
    if (0 != ret)
    {
        SAFET_DEBUG_PRINT("sdk_safety_lib_header_get failure \n");
        return -1;
    }
    else
    {
        //更新共享内存中的安规库版本
        // shm->modbus_data.inverter_information.safety_lib_ver[0] = (uint16_t)g_safety_regula_package_header.version;
        // log_info(LOG_SAFETY_ENABLE,"1safety_lib_ver = %04x",shm->modbus_data.inverter_information.safety_lib_ver[0]);
    }

/*
    //获取当前安规标准的名称
    ret = sdk_safety_regula_find_by_lib(file_path, &safety_attr);
    if (0 != ret)
    {
        SAFET_DEBUG_PRINT("sdk_safety_regula_find_by_lib fail \n");
        return -2;
    }
    else
    {
        //更新共享内存中的安规标准名称
      //  memcpy(shm->modbus_data.inverter_information.safety_name, g_safety_regula_package_index_array[0].country_name, 16);
    }
    */
    return ret;
}



/**
 * @brief: 安规库升级任务检测
 * @return {1：需要升级，0：不需要升级}
 * @note: 
 * @see: 
 * @date: 2023年1月9日
 */
static int16_t safety_lib_update_flag_check(void)
{
	char path[100]={0};
	int8_t update_flag_safety_lib = 0;
	firmware_update_t *p_update = sdk_shm_firmware_update_info_get();
    int8_t i = 0;

    g_safety_firmware_object_num = -1;

   // if(1 == p_update->protocol_version) //V01版2k签名
    {
        for (i = 0; i < UPDATE_OBJECT_NUM; i++)
        {
            //safety_lib
            if (!strncmp((const char *)p_update->module_object[i], SAFETY_PACKAGE_NAME_KEY, strlen(SAFETY_PACKAGE_NAME_KEY)))
            {
                bzero(path, sizeof(path));
                sprintf((char *)path, "%s%s", DIR_UPDATE_FILE, (const char *)p_update->module_name[i]);
                if(0 != access((const char *)path, F_OK)) //文件不存在
                {
                    SAFET_DEBUG_PRINT("firmware_update_flag_check safety_lib path:%s noexist!\n", path);
                }
                else
                {
                    //升级标志位置1
                    update_flag_safety_lib = 1;
                    SAFET_DEBUG_PRINT("firmware_update_flag FILE path:%s\n", path);
                }
                g_safety_firmware_object_num = i;
                break;
            }		
        }
    }
   // else if(2 == p_update->protocol_version) //V02版2k签名
    {
        //SAFETY
      //  g_safety_firmware_object_num = firmware_index_get_new(FILE_SAFETY_NUM, ALMIGHTY_NEW_NUM);
        if(g_safety_firmware_object_num >= 0)
        {
            if(p_update->update_flag[g_safety_firmware_object_num] == 1)
            {
                bzero(path, sizeof(path));
                sprintf((char *)path, "%s%s", DIR_UPDATE_FILE, (const char *)p_update->module_name[g_safety_firmware_object_num]);
                if(access((const char *)path, F_OK) < 0) //文件不存在
                {
                    SAFET_DEBUG_PRINT("firmware_update_flag_check SAFETY path:%s noexist!\n", path);
                }
                else
                {
                    update_flag_safety_lib = 1;
                }
            }
        }
    }
   // else
    {}

    return update_flag_safety_lib;
}

/**
 * @brief: 安规库导入并初始化
 * @return {-1：安规头部信息错误，-2：安规标准获取失败}
 * @note: 将安规库文件移动到/opt/bin目录下
 * @see: 
 * @date: 2023年1月9日
 */
int16_t safety_lib_import_task(void)
{
    int16_t ret = -1;
    int32_t folder_exist;
    char cmd[128] = {0};
    char path[100] = {0};
	firmware_update_t *firmware_update = sdk_shm_firmware_update_info_get();

    /* 检测安规库所在路径的文件夹是否存在 */
    folder_exist = safety_folder_exist();
    if (folder_exist < SF_OK)
    {
    	SAFET_DEBUG_PRINT("folder_exist = %d, error. \n", folder_exist);
    }

    //导入安规
    memset(cmd, 0, sizeof(cmd));
    snprintf((char *)cmd, sizeof(cmd), "mv %s%s /user/data/cfg/", DIR_UPDATE_FILE, firmware_update->module_name[g_safety_firmware_object_num]);
    sdk_system_cmd((int8_t *)cmd);
    snprintf((char *)path, sizeof(path), "/user/data/cfg/%s", firmware_update->module_name[g_safety_firmware_object_num]);
	printf("%d %s\n",g_safety_firmware_object_num , firmware_update->module_name[g_safety_firmware_object_num]);
    rename(path, SAFETY_LIB_PATH);  //将文件名改为固定文件名，避免升级包中的文件名是错误的

    ret = safety_lib_init(1);
    
   // shm->update.update_flag[g_safety_firmware_object_num] = UPDATE_NONE;
  //  memset(&(shm->update.module_object[g_safety_firmware_object_num]),0, sizeof(shm->update.module_object[g_safety_firmware_object_num]));
    g_safety_firmware_object_num = -1;

    return ret;
}

/**
 * @brief: 安规库导入并初始化
 * @return {-1：安规头部信息错误，-2：安规标准获取失败}
 * @note: 将安规库文件移动到/user/data/cfg目录下
 * @see: 
 * @date: 2023年1月9日
 */
int16_t safety_lib_import(char *file_name)
{
    int16_t ret = -1;
    int32_t folder_exist;
    char cmd[128] = {0};
    char path[100] = {0};
	firmware_update_t *firmware_update = sdk_shm_firmware_update_info_get();

	snprintf((char *)path, sizeof(path), "%s%s",DIR_UPDATE_FILE, file_name);
	ret = new_safety_lib_init(1,path);
	if (0 !=ret)
	{
		SAFET_DEBUG_PRINT("safety init error, ret = %d \n", ret);
		return ret;
	}

    /* 检测安规库所在路径的文件夹是否存在 */
    folder_exist = safety_folder_exist();
    if (folder_exist < SF_OK)
    {
    	SAFET_DEBUG_PRINT("folder_exist = %d, error. \n", folder_exist);
    }

    //导入安规
    memset(cmd, 0, sizeof(cmd));
    // snprintf((char *)cmd, sizeof(cmd), "mv %s%s /user/data/cfg/", DIR_UPDATE_FILE, file_name);
    snprintf((char *)cmd, sizeof(cmd), "cp %s%s /user/data/cfg/", DIR_UPDATE_FILE, file_name);
    sdk_system_cmd((int8_t *)cmd);
    snprintf((char *)path, sizeof(path), "/user/data/cfg/%s", file_name);
    ret = rename(path, SAFETY_LIB_PATH);  //将文件名改为固定文件名，避免升级包中的文件名是错误的	
    SAFET_DEBUG_PRINT("ret = %d \n",ret)
  	return 0;
}


/**
 * @brief: 安规库导入任务
 * @return {*}
 * @note: 
 * @see: 
 * @date: 2023年1月9日
 */
void safety_lib_update_task(void)
{
    int16_t ret = 0;
	uint16_t firmware_update_flag = 0;
	firmware_update_t *p_update = sdk_shm_firmware_update_info_get();
	
    //检查安规库导入标志位
    firmware_update_flag = safety_lib_update_flag_check();
    if (1 == firmware_update_flag)
    {
        ret = safety_lib_import_task();
        if (0 == ret)
        {
            //导入成功
            p_update->module_percent[g_safety_firmware_object_num] = 100;    //进度条
        }
        else
        {
            SAFET_DEBUG_PRINT("safety_lib_import error");
        }
        firmware_update_flag = 0;
    }
}

/**
 * @brief: 选择安规标准任务
 * @return {0：正常，-1：头部信息不对，-2：安规库中没有该安规标准/索引信息读取错误，-3：生成单独的bin文件错误}
 * @note: 
 * @see: 
 * @date: 2023年1月9日
 */
int16_t safety_change_task(void)
{
    int16_t ret = -1;
   // inverter_information_t *p_inverter_data = sdk_shm_inverter_information_get();
	constant_parameter_data_t *p_constant_parameter = sdk_shm_constant_parameter_data_get();
    safety_attr_t safety_attr = {0};

    safety_attr.region = p_constant_parameter->safety_rdr_country;
    safety_attr.version = p_constant_parameter->ver_safety_rdr_para;

  //  safety_attr.region = p_inverter_data->safety_rdr_country;
  //  safety_attr.version = p_inverter_data->ver_safety_rdr_para;

    ret = sdk_safety_lib_select((const int8_t *)SAFETY_LIB_PATH, (int8_t *)SAFETY_PATH, &safety_attr);
    if (0 != ret)
    {
        //安规标准切换失败，将安规国家与地区回退到设置前的参数
        //shm->modbus_data.inverter_information.safety_rdr_country = g_safety_country_code;
        SAFET_DEBUG_PRINT("safety change error[%s]:%d", __func__, ret);
    }
    else
    {
        //安规标准切换成功
        //shm->modbus_data.inverter_information.safety_rdr_country = safety_attr.region;
       // shm->modbus_data.inverter_information.ver_safety_rdr_para = safety_attr.version;
        g_safety_country_code = safety_attr.region;
    }

    return ret;
}

