#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cJSON.h"
#include "common.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk_safety.h"
#include "safety_lib_task.h"
#include "safety.h"
#include "web_broker.h"

/**
 * @brief    获取安规
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void get_safety(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
    cJSON *p_resp_node;
	cJSON *p_resp_array;	
    uint8_t response[256];  
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t i;
    uint8_t request_body[1024] = {0};
	int32_t ret;
	int32_t data_array[10] = {1,2,3,4,5,6,7,8,9,10};
	uint8_t country[32]= {0};
	safety_regula_package_header_t header_info = {0};
	internal_shared_data_t *p_internal_shared = internal_shared_data_get();

	
    if (p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if (p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"getTestSafety"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
	cJSON_Delete(p_request);
	


   p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",200);

	cJSON_AddNumberToObject(p_resp_root,"countryCode",p_internal_shared->pcs_safety_country_region >> 8);
	cJSON_AddNumberToObject(p_resp_root,"standardCode",p_internal_shared->pcs_safety_country_region & 0xff);
	

    p_resp_array = cJSON_CreateArray();
    if(p_resp_array == NULL)
    {
    	cJSON_Delete(p_resp_root);
		build_empty_response(response,203,"err");
		http_back(p_nc,response);
		return;
    }

	ret = sdk_safety_lib_header_get(SAFETY_LIB_PATH, &header_info);
	print_log("ret = %d",ret);
	if (0 == ret)
	{
		get_safety_regula(SAFETY_LIB_PATH,p_resp_array);
	}

	cJSON_AddItemToObject(p_resp_root,"safetyTable",p_resp_array);
	cJSON_AddStringToObject(p_resp_root,"msg","get successful");
	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);	
	http_back(p_nc,p);
	free(p);	
	
}

/**
 * @brief    设置安规信息
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void set_safety(struct mg_connection *p_nc,struct http_message *p_msg)
{

    cJSON *p_request;
    cJSON *p_resp_root;
	cJSON *p_resp_item;
	cJSON *p_data;	
    uint8_t response[256];  
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t i;
    uint8_t request_body[1024] = {0};
	uint32_t countryCode = 0 ;
	uint32_t standardCode;
	int32_t ret;
	safety_attr_t safety_attr = {0};
	constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数
	internal_shared_data_t *p_internal_data = internal_shared_data_get();
	telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();
	operation_log_t op_log;
	uint8_t cur_user[32] = {0};
	uint8_t buf[32]={0};

	print_log("set_safety in.");
    if (p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if (p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"setTestSafety"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	 //此处需要详细的操作日志类型
    init_user_basic_info(&op_log);
    get_user_from_http_request(p_msg,cur_user);
    strcpy(op_log.user_name,cur_user);
    get_user_basic_info(&op_log);

	p_data = cJSON_GetObjectItem(p_request,"data");
	countryCode = cJSON_GetObjectItem(p_data,"countryCode")->valueint;
	standardCode = cJSON_GetObjectItem(p_data,"standardCode")->valueint;
	safety_attr.region = (countryCode << 8) | standardCode;
	cJSON_Delete(p_request);
	
    ret = sdk_safety_lib_select((const int8_t *)SAFETY_LIB_PATH, (int8_t *)SAFETY_PATH, &safety_attr);
    if (0 != ret)
    {
        //安规标准切换失败，将安规国家与地区回退到设置前的参数
       // shm->modbus_data.inverter_information.safety_rdr_country = g_safety_country_code;
        print_log("safety change error[%s]:%d", __func__, ret);
		build_empty_response(response,203,"安规标准切换失败");
		http_back(p_nc,response);	

		strcpy(op_log.op_type,"设置安规标准");
		memset(buf,0x0,sizeof(buf));
		sprintf(buf,"%03d%03d",(p_para_data->safety_rdr_country>>8) & 0x00FF,p_para_data->safety_rdr_country&0x00FF);
        op_log.op_param1 = atoi((char*)buf);// ((p_para_data->safety_rdr_country >> 8) & 0x00FF) | ((p_para_data->safety_rdr_country << 8) & 0xFF00);
        memset(buf,0x0,sizeof(buf));
		sprintf(buf,"%03d%03d",(safety_attr.region>>8)&0x00FF,safety_attr.region&0x00FF);
		op_log.op_param2 = atoi((char*)buf);
        strcpy(op_log.op_status,"failed");
        add_one_op_log(&op_log);
        return;	
    }
	else
	{
		print_log("safety change[%s]:%d", __func__, ret);
	//	p_internal_data->safety_update_flag = 0x01;
		strcpy(op_log.op_type,"设置安规标准");
		p_telematic_data->container_system_warn_info[0] &= ~(1<<2);
        memset(buf,0x0,sizeof(buf));
		sprintf(buf,"%03d%03d",(p_para_data->safety_rdr_country>>8) & 0x00FF,p_para_data->safety_rdr_country&0x00FF);
        op_log.op_param1 = atoi((char*)buf);
        memset(buf,0x0,sizeof(buf));
		sprintf(buf,"%03d%03d",(safety_attr.region>>8)&0x00FF,safety_attr.region&0x00FF);
		op_log.op_param2 = atoi((char*)buf);
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
		p_para_data->safety_rdr_country =  (countryCode << 8) | standardCode;
	}

	p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
		build_empty_response(response,203,"create json obj failed"); 
		http_back(p_nc,response);	
        return;
    }

	cJSON_AddNumberToObject(p_resp_root,"code",200);
	cJSON_AddStringToObject(p_resp_root,"msg","get successful");
		
	p = cJSON_PrintUnformatted(p_resp_root);

	cJSON_Delete(p_resp_root);	
	http_back(p_nc,p);
	free(p);	
	
}

void read_safety_setting_detail( struct mg_connection *p_nc,struct http_message *p_msg )
{
    cJSON *p_request = NULL;
    uint8_t response[256];  
    uint8_t request_body[1024] = {0};

    if (p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}else{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if (p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
        goto __exit;
	}

    cJSON *p_act_js = NULL;
    p_act_js = cJSON_GetObjectItem( p_request, "action" );
    cJSON *p_cmd_code_js = NULL; 
    p_cmd_code_js = cJSON_GetObjectItem( p_request, "cmdCode" );

    if (  ( strcmp( p_act_js->valuestring      , "readSafetySettingDetail" ) != 0)
        ||( strcmp( p_cmd_code_js->valuestring , "safetyOverVol"           ) != 0)  )
    {
        print_log( "action or cmdcode value error!!!" );
        goto __exit;
    }

    cJSON *p_reply_root_js = NULL;
    p_reply_root_js = cJSON_CreateObject();
    if ( p_reply_root_js == NULL )
    {
        print_log("%s p_reply_root_js == NULL", __FUNCTION__);
        goto __exit;
    }

	cJSON_AddNumberToObject( p_reply_root_js, "code", 200);
	cJSON_AddStringToObject( p_reply_root_js, "msg", "successful");

    cJSON *p_reply_dat_js = NULL;
    p_reply_dat_js = cJSON_AddObjectToObject( p_reply_root_js, "Data" );
    if ( p_reply_dat_js == NULL )
    {
        print_log("%s p_reply_dat_js == NULL", __FUNCTION__);
        goto __exit;
    }
	cJSON_AddStringToObject( p_reply_dat_js, "code", "safetyOverVol");

    cJSON *p_reply_code_res_js = NULL;
    p_reply_code_res_js = cJSON_AddObjectToObject( p_reply_dat_js, "codeResult" );
    if ( p_reply_code_res_js == NULL )
    {
        print_log("%s p_reply_code_res_js == NULL", __FUNCTION__);
        goto __exit;
    }

	cJSON_AddNumberToObject( p_reply_code_res_js, "RemoteConfig6", BIT_GET( sdk_shm_constant_parameter_data_get()->safety_param.group5[0], 6 ) ? 1: 0 );

	char *reply_str = NULL;
	reply_str = cJSON_PrintUnformatted( p_reply_root_js );
    if ( reply_str == NULL )
    {
        print_log("%s reply_str == NULL", __FUNCTION__);
        goto __exit;
    }
	http_back( p_nc, reply_str );

__exit:
    if ( p_request != NULL )
    {
        cJSON_Delete( p_request );
    }
    if ( p_reply_root_js != NULL )
    {
        cJSON_Delete( p_reply_root_js );
    }
    if ( reply_str != NULL )
    {
        free( reply_str );
    }
    return;
}

/**
 * @brief 安规导入模块初始化
 * @return void
 */
void safety_param_module_init(void)
{
	/*获取安规库中安规列表*/
	if(!web_func_attach("/debugManager/getTestSafety", get_safety))
	{
		print_log("[/debugManager/getTestSafety] attach failed");
	}
	/*设置使用的安规*/
	if(!web_func_attach("/debugManager/setTestSafety", set_safety))
	{
		print_log("[/debugManager/setTestSafety] attach failed");
	}
	/* 读有功、过欠压降载参数 */
	if(!web_func_attach("/safetySetting/readSafetySettingDetail", read_safety_setting_detail))
	{
		print_log("[/safetySetting/readSafetySettingDetail] attach failed");
	}

}