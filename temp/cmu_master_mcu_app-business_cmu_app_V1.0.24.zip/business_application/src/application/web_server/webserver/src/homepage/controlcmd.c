#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include"cJSON.h"
#include"homepage.h"
#include"common.h"
#include "web_data_interface.h"
#include"sdk_shm.h"
#include"data_shm.h"

void do_remote_power_on(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    uint8_t response[64];
    uint8_t *p_action;
    uint8_t request_body[1024] = {0};
    debug_manage_page_write_t debug_manage_info;
	operation_log_t op_log;
	uint8_t cur_user[32] = {0};

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"remotePowerOnCmd"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
        cJSON_Delete(p_request);
		http_back(p_nc,response);
		return;
	}
	cJSON_Delete(p_request);
	printf("\n do_remote_power_on !\n");
    memset(&debug_manage_info,0,sizeof(debug_manage_page_write_t));
    debug_manage_info.CMU_system_control_on |= (1<<0);
    debug_manage_page_set(&debug_manage_info);  //将调试管理的值设置到共享内存中去

	init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"远程开机");
	/*添加开机参数,这里应该是从0->1*/
	op_log.op_param1 = 0;
	op_log.op_param2 = 1;
    strcpy(op_log.op_status,"success");
	add_one_op_log(&op_log);

    build_empty_response(response,200,"remote power on cmd successful");
    http_back(p_nc,response);

}

void do_remote_power_off(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    uint8_t response[64];
    uint8_t *p_action;
    uint8_t request_body[1024] = {0};
    debug_manage_page_write_t debug_manage_info;
	operation_log_t op_log;
	uint8_t cur_user[32] = {0};

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"remotePowerOffCmd"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
        cJSON_Delete(p_request);
		http_back(p_nc,response);
		return;
	}
	cJSON_Delete(p_request);
	printf("\n do_remote_power_off !\n");
    memset(&debug_manage_info,0,sizeof(debug_manage_page_write_t));
    debug_manage_info.CMU_system_control_off |= (1<<0);
    debug_manage_page_set(&debug_manage_info);  //将调试管理的值设置到共享内存中去

	init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	/*添加关机参数,这里应该是从1->0*/
	op_log.op_param1 = 1;
	op_log.op_param2 = 0;
	strcpy(op_log.op_type,"远程关机");
    strcpy(op_log.op_status,"success");
	add_one_op_log(&op_log);

    build_empty_response(response,200,"remote power off cmd successful");
    http_back(p_nc,response);

}

void do_energy_saving_set(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    uint8_t response[64];
    uint8_t *p_action;
    uint8_t request_body[1024] = {0};
    debug_manage_page_write_t debug_manage_info;
	operation_log_t op_log;
	uint8_t cur_user[32] = {0};
	uint8_t mode;

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"sysStateSet"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
        cJSON_Delete(p_request);
		http_back(p_nc,response);
		return;
	}
	mode = (uint8_t)(cJSON_GetObjectItem(p_request,"mode")->valueint);
	if ((mode < ENEREY_SAVING_SET_TYPE_POWER_ON) || (mode >= ENEREY_SAVING_SET_TYPE_MAX))
	{
		print_log("mode is not right.");
		build_empty_response(response,204,"mode is not right");
        cJSON_Delete(p_request);
		http_back(p_nc,response);
		return;
	}
	cJSON_Delete(p_request);
	printf("\n do_energy_saving_set ! mode = %d \n", mode);

	memset(&debug_manage_info,0,sizeof(debug_manage_page_write_t));
	init_user_basic_info(&op_log);
	strcpy(op_log.user_name,"SystemSetup");
	strcpy(op_log.user_role,"Null");
	get_user_basic_info(&op_log);
	strcpy(op_log.op_status,"success");

	switch (mode)
	{
		case ENEREY_SAVING_SET_TYPE_POWER_ON:
			debug_manage_info.CMU_system_control_on |= (1<<0);
			strcpy(op_log.op_type,"节能降耗开机");
			break;
		case ENEREY_SAVING_SET_TYPE_POWER_OFF:
			debug_manage_info.CMU_system_control_off |= (1<<0);
			strcpy(op_log.op_type,"节能降耗关机");
			break;
		case ENEREY_SAVING_SET_TYPE_POWER_HALT:
			debug_manage_info.CMU_system_control_off |= (1<<0);
			debug_manage_info.energy_saving_power_halt_flag = ENABLE;
			strcpy(op_log.op_type,"节能降耗停机");
			break;
		default:
			break;
	}
	debug_manage_page_set(&debug_manage_info);  //将调试管理的值设置到共享内存中去
	add_one_op_log(&op_log);

	if (ENEREY_SAVING_SET_TYPE_POWER_ON == mode)
	{
		build_empty_response(response,200,"power on cmd successful");
	}
	else
	{
		build_empty_response(response,200,"power off cmd successful");
	}
    http_back(p_nc,response);
}


void do_exhaust_fan_on(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    uint8_t response[64];
    uint8_t *p_action;
    uint8_t request_body[1024] = {0};
    debug_manage_page_write_t debug_manage_info;
	operation_log_t op_log;
	uint8_t cur_user[32] = {0};

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"exhaustFanOn"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
        cJSON_Delete(p_request);
		http_back(p_nc,response);
		return;
	}
	cJSON_Delete(p_request);
	printf("\n do_exhaust_fan_on !\n");
    memset(&debug_manage_info,0,sizeof(debug_manage_page_write_t));
    debug_manage_info.CMU_system_control_on |= (1<<3);
    debug_manage_page_set(&debug_manage_info);  //将调试管理的值设置到共享内存中去

	init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"开启排气扇");
    strcpy(op_log.op_status,"success");
	add_one_op_log(&op_log);

    build_empty_response(response,200,"remote exhaust fan on cmd successful");
    http_back(p_nc,response);

}

void do_exhaust_fan_off(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    uint8_t response[64];
    uint8_t *p_action;
    uint8_t request_body[1024] = {0};
    debug_manage_page_write_t debug_manage_info;
	operation_log_t op_log;
	uint8_t cur_user[32] = {0};

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"exhaustFanOff"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
        cJSON_Delete(p_request);
		http_back(p_nc,response);
		return;
	}
	cJSON_Delete(p_request);
	printf("\n do_exhaust_fan_off !\n");
    memset(&debug_manage_info,0,sizeof(debug_manage_page_write_t));
    debug_manage_info.CMU_system_control_off |= (1<<3);
    debug_manage_page_set(&debug_manage_info);  //将调试管理的值设置到共享内存中去

	init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"关闭排气扇");
    strcpy(op_log.op_status,"success");
	add_one_op_log(&op_log);

    build_empty_response(response,200,"remote exhaust fan off cmd successful");
    http_back(p_nc,response);

}


void do_fault_reset(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    uint8_t response[64];
    uint8_t *p_action;
    uint8_t request_body[1024] = {0};
    telematic_data_t *p_telematic_data = NULL;
	operation_log_t op_log;
	internal_shared_data_t *p_internal_data = NULL;
	uint8_t cur_user[32] = {0};
    
    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"faultReset"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
        cJSON_Delete(p_request);
		http_back(p_nc,response);
		return;
	}
	cJSON_Delete(p_request);
	init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"故障复位");
    strcpy(op_log.op_status,"success");
	add_one_op_log(&op_log);

    p_telematic_data = sdk_shm_telematic_data_get();
	p_internal_data  = internal_shared_data_get();
    memset(p_telematic_data->container_system_fault_info, 0 , 4);
	p_internal_data->fault_reset = ENABLE;  // 通知其他进程/线程执行故障复归
    build_empty_response(response,200,"fault reset cmd successful");
    
    http_back(p_nc,response);
}