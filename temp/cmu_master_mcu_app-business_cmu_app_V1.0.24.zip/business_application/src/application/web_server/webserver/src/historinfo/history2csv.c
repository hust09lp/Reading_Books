/*****************************************************************************
* File Name          : operating_record_export.c            
* Description        : 运行数据记录文件U盘导出
* Original Author    : liangguyao
* date               : 2023.02.15
******************************************************************************/
 
#include "history2csv.h"
//#include "operating_pcs_data_handle.h"
//#include "operating_data_handle.h"
#include "sdk_fs.h"
#include "sdk_file.h"
#include "sdk_log.h"
#include "sdk_store.h"
#include "sofar_errors.h"
#include "crc.h"

#include <string.h>


#define READ_MAX_COUNT    480    /* 一个文件（一天）读取的最大次数（最大理论值，3min保存一次的运行数据） 24*60/3 = 480 */


/**
 * @brief   运行时间标题栏（首行）输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @return  无
 */
static void operating_time_title_bar_input(FILE *p_fp_des)
{
    fprintf(p_fp_des, "%s,", "operating_time");
}

/**
 * @brief   遥信运行数据标题栏（首行）输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @return  无
 */
static void telematic_title_bar_input(FILE *p_fp_des)
{
    int i,j;
	
    // for (i = 0; i < CSU_SYSTEM_FAULT_LEN_BYTE; i++)
    // {
    //     fprintf(p_fp_des, "CSU_system_fault_%d,", i);  // CSU_system_status_info[CONTAINER_SYSTEM_STATUS_LEN_BYTE]
    // }

    // for (i = 0; i < PCS_CABINET_SYSTEM_STATUS_LEN_BYTE; i++)
    // {
    //     fprintf(p_fp_des, "PCS_system_status_%d,", i);  // CSU_system_status_info[CONTAINER_SYSTEM_STATUS_LEN_BYTE]
    // }

    // for (i = 0; i < PCS_CABINET_SYSTEM_FAULT_LEN_BYTE; i++)
    // {
    //     fprintf(p_fp_des, "PCS_system_fault_%d,", i);  // CSU_system_fault_info[PCS_CABINET_SYSTEM_FAULT_LEN_BYTE]
    // }
    for (i = 0; i < PCS_CABINET_POWER_MODULE_NUM; i++)
    {
        fprintf(p_fp_des, "pcs_module_%d_grid_fault,", i);
        fprintf(p_fp_des, "pcs_module_%d_sampling_fault,", i);
        fprintf(p_fp_des, "pcs_module_%d_self_test_fault,", i);
        fprintf(p_fp_des, "pcs_module_%d_temperature_fault,", i);
        fprintf(p_fp_des, "pcs_module_%d_voltage_fault,", i);		
        fprintf(p_fp_des, "pcs_module_%d_current_fault,", i);
        fprintf(p_fp_des, "pcs_module_%d_hardware_signal_fault,", i);
        fprintf(p_fp_des, "pcs_module_%d_control_fault,", i);
        fprintf(p_fp_des, "pcs_module_%d_communication_fault,", i);
		
		fprintf(p_fp_des, "pcs_module_%d_supplement_fault,", i);
		fprintf(p_fp_des, "pcs_module_%d_external_device_class_fault,", i);
		fprintf(p_fp_des, "pcs_module_%d_warn_info,", i);
		
    }

}

#if 0

static void data_title_bar_input(FILE *p_fp_des)
{
    fprintf(p_fp_des, "%s,%s,%s,", "Ugrid_RS", "Ugrid_ST", "Ugrid_TR");
    fprintf(p_fp_des, "%s,%s,%s,", "I_R", "I_S", "I_T");
    fprintf(p_fp_des, "%s,%s,", "DC1_Voltage", "DC2_Voltage");
    fprintf(p_fp_des, "%s,%s,%s,%s,", "CSU_Board_T", "AC_Fuse_T", "DC1_Fuse_T", "DC1_Fuse_T");
	fprintf(p_fp_des, "%s,%s,", "AC_ActivePower", "AC_ReactivePower");
    fprintf(p_fp_des, "%s,%s,", "ActivePower_Ref", "ReactivePower_Ref");

    fprintf(p_fp_des, "%s,%s,%s,", "System_State", "Water_Leakage_State", "Door_State");
    fprintf(p_fp_des, "%s,%s,", "DC1_Switch_State", "DC2_Switch_State");	
    fprintf(p_fp_des, "%s,%s,", "DC1_SPD_State", "DC2_SPD_State");
	fprintf(p_fp_des, "%s,%s,%s,%s,", "AC_SPD_State", "AC_AuxPow_SPD_State", "ACB_State", "ACB_Failed");
	fprintf(p_fp_des, "%s,%s,%s,%s,", "Fan_Failed", "Local_EPO_State", "ISO_Warn", "ISO_Fault");
	fprintf(p_fp_des, "%s,%s,%s,", "Remote_EPO_State", "BESS_Failed", "Derate_State");
	
	fprintf(p_fp_des, "%s,%s,%s,", "Run_Command", "ACB_ON_Cmd", "ACB_OFF_Cmd");
	fprintf(p_fp_des, "%s\n", "end");
}



#endif
/**
 * @brief   
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @return  无
 */
static void pcs_cabinet_title_bar_input(FILE *p_fp_des)
{
	fprintf(p_fp_des, "%s,", "system_status");
	fprintf(p_fp_des, "%s,%s,%s,", "grid_side_line_vol_rs", "grid_side_line_vol_st", "grid_side_line_vol_tr");
	fprintf(p_fp_des, "%s,%s,%s,", "ac_side_line_vol_rs", "ac_side_line_vol_st", "ac_side_line_vol_tr");
	fprintf(p_fp_des, "%s,%s,%s,", "ac_side_phase_current_r", "ac_side_phase_current_s", "ac_side_phase_current_t");
	fprintf(p_fp_des, "%s,", "ac_side_freq");
    fprintf(p_fp_des, "%s,%s,", "csu_board_temperature", "ac_fuse_temperature");
    fprintf(p_fp_des, "%s,%s,", "dc1_fuse_temperature", "dc2_fuse_temperature");
    fprintf(p_fp_des, "%s,%s,", "dc_bus_voltage1", "dc_bus_voltage2");
	fprintf(p_fp_des, "%s,%s,%s,", "dc_current1", "dc_current2", "dc_side_power");
    fprintf(p_fp_des, "%s,%s,%s,", "ac_side_active_power", "ac_side_reactive_power", "ac_side_view_power");
	fprintf(p_fp_des, "%s,%s,", "daily_charging_capacity", "daily_discharging_capacity");
	fprintf(p_fp_des, "%s,%s,%s,", "total_charging_capacity", "total_discharging_capacity", "total_run_time");
	
	fprintf(p_fp_des, "%s,%s,%s,", "ac_side_phase_vol_r", "ac_side_phase_vol_s", "ac_side_phase_vol_t");
	fprintf(p_fp_des, "%s,%s,%s,", "ac_side_phase_r_active_power", "ac_side_phase_s_active_power", "ac_side_phase_t_active_power");
	fprintf(p_fp_des, "%s,%s,%s,", "ac_side_phase_r_reactive_power", "ac_side_phase_s_reactive_power", "ac_side_phase_t_reactive_power");
	fprintf(p_fp_des, "%s,%s,%s,", "ac_side_phase_r_view_power", "ac_side_phase_s_view_power", "ac_side_phase_t_view_power");

}

/**
 * @brief   
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @return  无
 */
static void pcs_version_title_bar_input(FILE *p_fp_des)
{
    int i;
	
    fprintf(p_fp_des, "%s,%s,", "hardware_version", "communication_protocol_version");
    for (i = 0; i < 11; i++)
    {
		
    	fprintf(p_fp_des, "sn_version[%d],", i);
	}	
    fprintf(p_fp_des, "%s,%s,%s,",  "mcu1_software_version", "mcu1_boot_version_number", "mcu1_core_version_number");
	fprintf(p_fp_des, "%s,%s,%s,",	"mcu2_software_version", "mcu2_boot_version_number", "mcu2_core_version_number");
	fprintf(p_fp_des, "%s,",	"system_power");
	fprintf(p_fp_des, "%s,%s,%s,",	"max_apparent_power", "max_active_power", "max_reactive_power");
}

/**
 * @brief   
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @return  无
 */
static void pcs_module_version_title_bar_input(FILE *p_fp_des)
{
    int i,j;

    for (i = 0; i < PCS_CABINET_POWER_MODULE_NUM; i++)
    {
		for (j = 0; j < 10; ++j)
		{
			fprintf(p_fp_des, "pcs%d_sn[%d],",i, j);
		}
		
		for (j = 0; j < 4; ++j)
		{
			fprintf(p_fp_des, "pcs%d_fw_version[%d],",i, j);
		}
		
    	fprintf(p_fp_des, "pcs%d_power,pcs%d_group_num,pcs%d_device_num,", i, i, i);

		fprintf(p_fp_des, "pcs%d_max_power_s,pcs%d_max_power_p,pcs%d_max_power_q,", i, i, i);
		for (j = 0; j < 4; ++j)
		{
			fprintf(p_fp_des, "slv_fw_version[%d]_%d,", j, i);
		}		

		fprintf(p_fp_des, "pcs%d_control_board_hw_version,pcs%d_power_board_hw_version,pcs%d_output_board_hw_version,", i, i, i);
		fprintf(p_fp_des, "pcs%d_can_version1,pcs%d_can_version2,", i, i);
	
    }
}

/**
 * @brief   
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @return  无
 */
static void power_module_telemetry_title_bar_input(FILE *p_fp_des)
{
    int i;

    for (i = 0; i < PCS_CABINET_POWER_MODULE_NUM; i++)
    {
#if 0
    	fprintf(p_fp_des, "grid_volt_r_%d,grid_volt_s_%d,grid_volt_t_%d,", i, i, i);
    	fprintf(p_fp_des, "grid_volt_rs_%d,grid_volt_st_%d,grid_volt_tr_%d,", i, i, i);
		fprintf(p_fp_des, "grid_freq_%d,n_to_pe_volt_%d,", i, i);
    	fprintf(p_fp_des, "ac_current_r_%d,ac_current_s_%d,ac_current_t_%d,", i, i, i);
    	fprintf(p_fp_des, "dci_r_%d,dci_s_%d,dci_t_%d,", i, i, i);
		fprintf(p_fp_des, "gfci_%d,", i);
    	fprintf(p_fp_des, "bus_volt_p_%d,bus_volt_n_%d,bus_volt_pn_%d,", i, i, i);
		fprintf(p_fp_des, "bat_volt_%d,bat_current_%d,", i, i);
		fprintf(p_fp_des, "iso_resistence_%d,iso_det_state_%d,iso_det_uiso1_%d,iso_det_uiso1_%d,iso_volt_to_pe_%d,", i, i, i, i, i);
		//fprintf(p_fp_des, "iso_resistence_%d,iso_det_state_%d,iso_volt_to_pe_%d,", i, i, i);
		fprintf(p_fp_des, "active_power_%d,reactive_power_%d,apparent_power_%d,", i, i, i);
		fprintf(p_fp_des, "igbt_temp_ra_%d,igbt_temp_sa_%d,igbt_temp_ta_%d,", i, i, i);
		fprintf(p_fp_des, "igbt_temp_rb_%d,igbt_temp_sb_%d,igbt_temp_tb_%d,", i, i, i);
		fprintf(p_fp_des, "igbt_temp_anti_sc_%d,amb_tem_%d,", i, i);
    	fprintf(p_fp_des, "slv_grid_volt_r_%d,slv_grid_volt_s_%d,slv_grid_volt_t_%d,", i, i, i);
		fprintf(p_fp_des, "slv_dci_r_%d,slv_dci_s_%d,slv_dci_t_%d,", i, i, i);
		fprintf(p_fp_des, "slv_gfci_%d,", i);
#else
    	fprintf(p_fp_des, "pcs%d_grid_volt_rs,pcs%d_grid_volt_st,pcs%d_grid_volt_tr,", i, i, i);
		fprintf(p_fp_des, "pcs%d_grid_freq,", i);
		fprintf(p_fp_des, "pcs%d_ac_current_r,pcs%d_ac_current_s,pcs%d_ac_current_t,", i, i, i);
		fprintf(p_fp_des, "pcs%d_bus_volt_pn,pcs%d_bat_volt,pcs%d_iso_resistence,", i, i, i);
		fprintf(p_fp_des, "pcs%d_active_power,pcs%d_reactive_power,pcs%d_apparent_power,", i, i, i);
		fprintf(p_fp_des, "pcs%d_amb_temp,pcs%d_power_factor,", i, i);
		fprintf(p_fp_des, "pcs%d_Running_Hours_L,pcs%d_Running_Hours_H,", i, i);
		fprintf(p_fp_des, "pcs%d_Active_Power_R,pcs%d_Active_Power_S,pcs%d_Active_Power_T,", i, i, i);
		fprintf(p_fp_des, "pcs%d_Reactive_Power_R,pcs%d_Reactive_Power_S,pcs%d_Reactive_Power_T,", i, i, i);
		fprintf(p_fp_des, "pcs%d_Apparent_Power_R,pcs%d_Apparent_Power_S,pcs%d_Apparent_Power_T,", i, i, i);
		//fprintf(p_fp_des, "pcs%d_QvarInsRef,", i);
		
		fprintf(p_fp_des, "pcs%d_grid_volt_r,pcs%d_grid_volt_s,pcs%d_grid_volt_t,", i, i, i);
    	fprintf(p_fp_des, "pcs%d_n_to_pe_volt,", i);
    	fprintf(p_fp_des, "pcs%d_dci_r,pcs%d_dci_s,pcs%d_dci_t,", i, i, i);
		fprintf(p_fp_des, "pcs%d_gfci,", i);
		
    	fprintf(p_fp_des, "pcs%d_bus_volt_p,pcs%d_bus_volt_n,", i, i);

		fprintf(p_fp_des, "pcs%d_igbt_temp_ra,pcs%d_igbt_temp_sa,pcs%d_igbt_temp_ta,", i, i, i);
		fprintf(p_fp_des, "pcs%d_igbt_temp_rb,pcs%d_igbt_temp_sb,pcs%d_igbt_temp_tb,", i, i, i);

    	fprintf(p_fp_des, "pcs%d_slv_grid_volt_r,pcs%d_slv_grid_volt_s,pcs%d_slv_grid_volt_t,", i, i, i);

		fprintf(p_fp_des, "pcs%d_Fan_Speed_Inner1,pcs%d_Fan_Speed_Inner2,", i, i);
		fprintf(p_fp_des, "pcs%d_Fan_Speed_Outer1,pcs%d_Fan_Speed_Outer2,pcs%d_Fan_Speed_Outer3,pcs%d_Fan_Speed_Outer4,", i, i, i, i);

		fprintf(p_fp_des, "pcs%d_energy_discharge_l,pcs%d_energy_discharge_h,pcs%d_energy_charge_l,pcs%d_energy_charge_h,", i, i, i, i);
		fprintf(p_fp_des, "pcs%d_bat_current,pcs%d_iso_det_state,pcs%d_iso_volt_to_pe,", i, i, i);


#endif
	}
	//fprintf(p_fp_des, "%s\n", "end");
}


static void constant_title_bar_input(FILE *p_fp_des)
{
	fprintf(p_fp_des, "active_power, reactive_power,");
	fprintf(p_fp_des, "%s\n", "end");
}

/**
 * @brief   遥测运行数据标题栏（首行）输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @return  无
 */
static void telemetry_title_bar_input(FILE *p_fp_des)
{
    pcs_cabinet_title_bar_input(p_fp_des);
    pcs_version_title_bar_input(p_fp_des);
    pcs_module_version_title_bar_input(p_fp_des);
    power_module_telemetry_title_bar_input(p_fp_des);
  
}

/**
 * @brief   csv文件标题栏（首行）输入
 * @param   [in] p_fs_des 已打开的目标文件指针
 * @return  无
 */
static void operating_record_title_bar_input(FILE *p_fp_des)
{
    operating_time_title_bar_input(p_fp_des);
    telematic_title_bar_input(p_fp_des);
    telemetry_title_bar_input(p_fp_des);
	constant_title_bar_input(p_fp_des);
}


/**
 * @brief   运行时间数据输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @param   [in] p_operating_data 运行数据结构体指针
 * @return  无
 */
static void operating_time_data_input(FILE *p_fp_des, operating_pcs_data_t *p_operating_data)
{
    fprintf(p_fp_des, "%04d-%02d-%02d %02d:%02d:%02d,", (p_operating_data->operating_time.tm_year + 2000), \
            p_operating_data->operating_time.tm_mon, p_operating_data->operating_time.tm_day, \
            p_operating_data->operating_time.tm_hour, p_operating_data->operating_time.tm_min, \
            p_operating_data->operating_time.tm_sec);
}

static void operating_data_input(FILE *p_fp_des, operating_pcs_data_t *p_operating_data)
{
	//fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.ac_fuse_temperature);
}

/**
 * @brief   遥信运行数据输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @param   [in] p_operating_data 运行数据结构体指针
 * @return  无
 */
static void telematic_data_input(FILE *p_fp_des, operating_pcs_data_t *p_operating_data)
{
    int i,j;

    // for (i = 0; i < CSU_SYSTEM_FAULT_LEN_BYTE; i++)
    // {
    //     fprintf(p_fp_des, "0x%x,", p_operating_data->telematic_operating_data.csu_system_fault_info[i]);  // CSU_system_status_info[CONTAINER_SYSTEM_STATUS_LEN_BYTE]
    // }

    // for (i = 0; i < PCS_CABINET_SYSTEM_STATUS_LEN_BYTE; i++)
    // {
    //     fprintf(p_fp_des, "0x%x,", p_operating_data->telematic_operating_data.pcs_system_cabinet_status_info[i]);  // PCS_system_status_info[CONTAINER_SYSTEM_STATUS_LEN_BYTE]
    // }

    // for (i = 0; i < PCS_CABINET_SYSTEM_FAULT_LEN_BYTE; i++)
    // {
    //     fprintf(p_fp_des, "0x%x,", p_operating_data->telematic_operating_data.pcs_system_cabinet_fault_info[i]);  // PCS_system_fault_info[PCS_CABINET_SYSTEM_FAULT_LEN_BYTE]
    // }
    for (i = 0; i < PCS_CABINET_POWER_MODULE_NUM; i++)
    {
   
        fprintf(p_fp_des, "0x%x,", p_operating_data->telematic_operating_data.pcs_module[i].grid_fault.val);
        fprintf(p_fp_des, "0x%x,", p_operating_data->telematic_operating_data.pcs_module[i].sampling_fault.val);
        fprintf(p_fp_des, "0x%x,", p_operating_data->telematic_operating_data.pcs_module[i].self_test_fault.val);
        fprintf(p_fp_des, "0x%x,", p_operating_data->telematic_operating_data.pcs_module[i].temperature_fault.val);
        fprintf(p_fp_des, "0x%x,", p_operating_data->telematic_operating_data.pcs_module[i].voltage_fault.val);		
        fprintf(p_fp_des, "0x%x,", p_operating_data->telematic_operating_data.pcs_module[i].current_fault.val);
        fprintf(p_fp_des, "0x%x,", p_operating_data->telematic_operating_data.pcs_module[i].hardware_signal_fault.val);
        fprintf(p_fp_des, "0x%x,", p_operating_data->telematic_operating_data.pcs_module[i].control_fault.val);
        fprintf(p_fp_des, "0x%x,", p_operating_data->telematic_operating_data.pcs_module[i].communication_fault.val);
		fprintf(p_fp_des, "0x%x,", p_operating_data->telematic_operating_data.pcs_module[i].supplement_fault.val);
		fprintf(p_fp_des, "0x%x,", p_operating_data->telematic_operating_data.pcs_module[i].external_device_fault.val);
		fprintf(p_fp_des, "0x%x,", p_operating_data->telematic_operating_data.pcs_module[i].warn_info.val);

    }

}

/**
 * @brief   PCS系统遥测运行数据输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @param   [in] p_operating_data 运行数据结构体指针
 * @return  无
 */
static void pcs_cabinet_telemetry_data_input(FILE *p_fp_des, operating_pcs_data_t *p_operating_data)
{
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.system_status);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.grid_side_line_vol_rs);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.grid_side_line_vol_st);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.grid_side_line_vol_tr);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.ac_side_line_vol_st);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.ac_side_line_vol_st);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.ac_side_line_vol_tr);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.ac_side_phase_current_r);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.ac_side_phase_current_s);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.ac_side_phase_current_t);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.ac_side_freq);

	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.csu_board_temperature);
    // fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.ac_fuse_temperature);
    // fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.dc1_fuse_temperature);
    // fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.dc2_fuse_temperature);
    // fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.dc_bus_voltage1);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.dc_bus_voltage2);

	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.dc_current1);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.dc_current2);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.dc_side_power);
	
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.ac_side_active_power);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.ac_side_reactive_power);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.ac_side_view_power);

    // fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.daily_charging_capacity);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.daily_discharging_capacity);
    // fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.total_charging_capacity);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.total_discharging_capacity);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.total_run_time);
	
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.ac_side_phase_vol_r);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.ac_side_phase_vol_s);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.ac_side_phase_vol_t);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.ac_side_phase_r_active_power);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.ac_side_phase_s_active_power);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.ac_side_phase_t_active_power);	
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.ac_side_phase_r_reactive_power);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.ac_side_phase_s_reactive_power);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.ac_side_phase_t_reactive_power);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.ac_side_phase_r_view_power);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.ac_side_phase_s_view_power);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_cabinet_telemetry_info.ac_side_phase_t_view_power);
	
}

/**
 * @brief   PCS柜版本信息数据输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @param   [in] p_operating_data 运行数据结构体指针
 * @return  无
 */
static void  pcs_version_telemetry_data_input(FILE *p_fp_des, operating_pcs_data_t *p_operating_data)
{
	// uint16_t i;
	
	// //hard
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_version_telemetry_info.hardware_version_number);
	// //通信协议版本号
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_version_telemetry_info.communication_protocol_version_number);
	// //sn
	// for (i = 0 ; i < 11 ; ++i)
	// {
	// 	fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_version_telemetry_info.sn_version_number[i]);
	// }
	// //fprintf(p_fp_des, ",");

	// //MCU1软件版本号
	// //MCU1boot版本号
	// //MCU1core版本号
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_version_telemetry_info.mcu1_software_version_number);	
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_version_telemetry_info.mcu1_boot_version_number);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_version_telemetry_info.mcu1_core_version_number);


	// //MCU2软件版本号
	// //MCU2boot版本号
	// //MCU2core版本号
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_version_telemetry_info.mcu2_software_version_number);	
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_version_telemetry_info.mcu2_boot_version_number);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_version_telemetry_info.mcu2_core_version_number);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_version_telemetry_info.system_power);

	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_version_telemetry_info.max_apparent_power);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_version_telemetry_info.max_active_power);
	// fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_version_telemetry_info.max_reactive_power);
}

/**
 * @brief   PCS模块版本信息数据输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @param   [in] p_operating_data 运行数据结构体指针
 * @return  无
 */
static void  pcs_module_version_telemetry_data_input(FILE *p_fp_des, operating_pcs_data_t *p_operating_data)
{
	uint16_t i,j;

	for (i = 0; i < PCS_CABINET_POWER_MODULE_NUM; ++i)
	{
#if 0		
		for (j = 0 ; j < 10 ; ++j)
		{
			fprintf(p_fp_des, "%c", p_operating_data->telemetry_operating_data.pcs_module_version_telemetry_info[i].sn[j]);
		}
		fprintf(p_fp_des, ",");
		
		for (j = 0 ; j < 4 ; ++j)
		{
			fprintf(p_fp_des, "%c", p_operating_data->telemetry_operating_data.pcs_module_version_telemetry_info[i].fw_version[j]);
		}
		fprintf(p_fp_des, ",");
		
		for (j = 0 ; j < 4 ; ++j)
		{
			fprintf(p_fp_des, "%c", p_operating_data->telemetry_operating_data.pcs_module_version_telemetry_info[i].slv_fw_version[j]);
		}
		fprintf(p_fp_des, ",");
		
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_module_version_telemetry_info[i].group_num);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_module_version_telemetry_info[i].control_board_hw_version);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_module_version_telemetry_info[i].power_board_hw_version);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_module_version_telemetry_info[i].output_board_hw_version);
#else
		for (j = 0 ; j < 10 ; ++j)
		{
			fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_module_version_telemetry_info[i].sn[j]);
		}
		//fprintf(p_fp_des, ",");

		for (j = 0 ; j < 4 ; ++j)
		{
			fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_module_version_telemetry_info[i].fw_version[j]);
		}
		//fprintf(p_fp_des, ",");

		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_module_version_telemetry_info[i].power);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_module_version_telemetry_info[i].group_num);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_module_version_telemetry_info[i].device_num);

		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_module_version_telemetry_info[i].max_power_s);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_module_version_telemetry_info[i].max_power_p);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_module_version_telemetry_info[i].max_power_q);
	
		for (j = 0 ; j < 4 ; ++j)
		{
			fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_module_version_telemetry_info[i].slv_fw_version[j]);
		}
		//fprintf(p_fp_des, ",");

		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_module_version_telemetry_info[i].control_board_hw_version);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_module_version_telemetry_info[i].power_board_hw_version);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_module_version_telemetry_info[i].output_board_hw_version);

		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_module_version_telemetry_info[i].can_version1);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.pcs_module_version_telemetry_info[i].can_version2);
		//fprintf(p_fp_des, "%d,", 1);	
#endif

	}

}


/**
 * @brief   PCS模块版本信息数据输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @param   [in] p_operating_data 运行数据结构体指针
 * @return  无
 */
static void  pcs_module_telemetry_data_input(FILE *p_fp_des, operating_pcs_data_t *p_operating_data)
{
	uint16_t i,j;

	for (i = 0; i < PCS_CABINET_POWER_MODULE_NUM; ++i)
	{
	#if 0	
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].grid_volt_r);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].grid_volt_s);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].grid_volt_t);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].grid_volt_rs);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].grid_volt_st);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].grid_volt_tr);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].grid_freq);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].n_to_pe_volt);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].ac_current_r);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].ac_current_s);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].ac_current_t);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].dci_r);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].dci_s);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].dci_t);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].gfci);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].bus_volt_n);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].bus_volt_p);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].bus_volt_pn);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].bat_volt);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].bat_current);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].iso_resistence);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].iso_det_state);
		//fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].iso_det_uiso1);
		//fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].iso_det_uiso2);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].iso_volt_to_pe);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].active_power);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].reactive_power);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].apparent_power);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].igbt_temp_ra);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].igbt_temp_sa);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].igbt_temp_ta);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].igbt_temp_rb);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].igbt_temp_sb);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].igbt_temp_tb);
		//fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].igbt_temp_anti_sc);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].amb_temp);
		fprintf(p_fp_des, "%hd,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].slv_grid_volt_r);
		fprintf(p_fp_des, "%hd,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].slv_grid_volt_s/10.0);
		fprintf(p_fp_des, "%hd,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].slv_grid_volt_t);
		//fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].slv_dci_r);
		//fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].slv_dci_s);
		//fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].slv_dci_t);
		//fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].slv_gfci);
	#else
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].grid_volt_rs);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].grid_volt_st);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].grid_volt_tr);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].grid_freq);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].ac_current_r);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].ac_current_s);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].ac_current_t);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].bus_volt_pn);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].bat_volt);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].iso_resistence);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].active_power);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].reactive_power);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].apparent_power);		
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].amb_temp);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].power_factor);
		//fprintf(p_fp_des, "%d,", 6);
		
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].Running_Hours_L);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].Running_Hours_H);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].Active_Power_R);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].Active_Power_S);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].Active_Power_T);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].Reactive_Power_R);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].Reactive_Power_S);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].Reactive_Power_T);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].Apparent_Power_R);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].Apparent_Power_S);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].Apparent_Power_T);
	//	fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].QvarInsRef);


		
		//fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].energy_generated_l);
		//fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].energy_generated_h);

		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].grid_volt_r);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].grid_volt_s);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].grid_volt_t);		


		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].n_to_pe_volt);

		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].dci_r);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].dci_s);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].dci_t);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].gfci);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].bus_volt_p);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].bus_volt_n);

		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].igbt_temp_ra);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].igbt_temp_sa);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].igbt_temp_ta);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].igbt_temp_rb);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].igbt_temp_sb);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].igbt_temp_tb);

		fprintf(p_fp_des, "%hd,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].slv_grid_volt_r);
		fprintf(p_fp_des, "%hd,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].slv_grid_volt_s);
		fprintf(p_fp_des, "%hd,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].slv_grid_volt_t);

		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].Fan_Speed_Inner1);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].Fan_Speed_Inner2);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].Fan_Speed_Outer1);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].Fan_Speed_Outer2);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].Fan_Speed_Outer3);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].Fan_Speed_Outer4);

		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].energy_discharge_l);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].energy_discharge_h);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].energy_charge_l);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].energy_charge_h);


		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].bat_current);	
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].iso_det_state);
		fprintf(p_fp_des, "%d,", p_operating_data->telemetry_operating_data.power_module_telemetry_info[i].iso_volt_to_pe);

	#endif
	}
	
}

static void constant_data_input(FILE *p_fp_des, operating_pcs_data_t *p_operating_data)
{
	fprintf(p_fp_des, "%d,%d,", p_operating_data->history_constant_parameter.active_power, p_operating_data->history_constant_parameter.reactive_power);
	fprintf(p_fp_des, "%s\n", "end");
}

/**
 * @brief   遥测运行数据输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @param   [in] p_operating_data 运行数据结构体指针
 * @return  无
 */
static void telemetry_data_input(FILE *p_fp_des, operating_pcs_data_t *p_operating_data)
{
	pcs_cabinet_telemetry_data_input(p_fp_des, p_operating_data);
	pcs_version_telemetry_data_input(p_fp_des, p_operating_data);
	pcs_module_version_telemetry_data_input(p_fp_des, p_operating_data);
	pcs_module_telemetry_data_input(p_fp_des, p_operating_data);
    
}


/**
 * @brief   csv文件运行数据行输入
 * @param   [in] p_fs_des 已打开的目标文件指针
 * @param   [in] p_operating_data 运行数据结构体指针
 * @return  无
 */
static void operating_record_data_row_input(FILE *p_fp_des, operating_pcs_data_t *p_operating_data)
{
    log_i((int8_t *)"[%s:%d] row input!\n", __func__, __LINE__);
    operating_time_data_input(p_fp_des, p_operating_data);
    telematic_data_input(p_fp_des, p_operating_data);
    telemetry_data_input(p_fp_des, p_operating_data);
	constant_data_input(p_fp_des, p_operating_data);
}

/**
 * @brief   对读取的运行数据帧进行crc校验
 * @param   [in] p_operating_data 运行数据结构体指针
 * @return  结果
 * @retval  0 成功
 * @retval  -1 失败
 */
static int32_t operating_record_data_frame_crc_check(operating_pcs_data_t *p_operating_data)
{
    int32_t ret = -1;
    uint32_t crc;

    crc = crc32((const unsigned char *)p_operating_data, (sizeof(operating_pcs_data_t) - 4));
    if (p_operating_data->crc == crc)
    {
        ret = 0;
    }

    return ret;
}

/**
 * @brief   csv文件运行数据行输入
 * @param   [in] p_fp_des 已打开的目标文件指针
 * @return  无
 */
static void operating_record_data_row_crc_error_input(FILE *p_fp_des)
{
    log_i((int8_t *)"[%s:%d] crc error input!\n", __func__, __LINE__);
    fprintf(p_fp_des, "%s,", "crc_error");
    fprintf(p_fp_des, "%s\n", "end");
}

/**
 * @brief   运行数据记录文件导出的数据处理过程
 * @param   [in] p_fs_des 已打开的目标文件指针
 * @param   [in] p_fs_src 已打开的源文件指针
 * @return  结果
 * @retval  0 成功
 * @retval  其他 失败
 */
static int32_t operating_record_export_data_process(fs_t *p_fs_des, fs_t *p_fs_src)
{
    int32_t src_size;
    int32_t once_len;
    int32_t loop_count;
    int32_t ret_len;
    int32_t crc_check;
    FILE *p_fp_des;
    operating_pcs_data_t operating_data;

    if (p_fs_des == NULL || p_fs_src == NULL)
    {
        log_i((int8_t *)"[%s:%d] null pointer!\n", __func__, __LINE__);
        return (-1);
    }

    p_fp_des = (FILE *)p_fs_des;

    src_size = sdk_fs_get_size(p_fs_src);
    once_len = sizeof(operating_pcs_data_t);
    loop_count = src_size / once_len;
    log_i((int8_t *)"[%s:%d] src_size: %d, loop_count: %d, once_len: %d\n", __func__, __LINE__, src_size, loop_count, once_len);
    if (loop_count < 1)
    {
        log_i((int8_t *)"[%s:%d] no content!\n", __func__, __LINE__);
    }
    else if (loop_count > READ_MAX_COUNT)
    {
        log_i((int8_t *)"[%s:%d] overflow!\n", __func__, __LINE__);
        loop_count = READ_MAX_COUNT;
    }

    /* csv文件标题栏（首行）输入 */
    operating_record_title_bar_input(p_fp_des);

    while (loop_count)
    {
        memset(&operating_data, 0 , sizeof(operating_pcs_data_t));
		
        ret_len = sdk_fs_read(p_fs_src, &operating_data, sizeof(operating_pcs_data_t));
        if (ret_len != once_len)
        {
            log_i((int8_t *)"[%s:%d] read len error! ret_len = %d\n", __func__, __LINE__, ret_len);
            return (-1);
        }
		
        crc_check = operating_record_data_frame_crc_check(&operating_data);
        if (crc_check < 0)
        {
            log_i((int8_t *)"[%s:%d] frame crc error!\n", __func__, __LINE__);
            operating_record_data_row_crc_error_input(p_fp_des);
        }
        else
        {
			log_i((int8_t *)"[%s:%d] frame crc ok!\n", __func__, __LINE__);
			operating_record_data_row_input(p_fp_des, &operating_data);
        }

        loop_count--;
    }

    return (0);
}

/**
 * @brief          检查SD卡是否挂载
 * @return         true：挂载 false：没有挂载
 */
static bool sd_mount_status(void)
{
    char cmd[256] = {0};
    char tmp_buff[32] = {0};
    FILE *fp = NULL;

    snprintf(cmd, 256, "df | grep \"dev/mmcblk0p1\" | awk '{print $1}'");
    fp = popen(cmd,"r");
	if(fp == NULL)
    {
        return false;
    }
    fread(tmp_buff, 1, sizeof(tmp_buff), fp);
    if(!strncmp(tmp_buff, "/dev/mmcblk0p1", strlen("/dev/mmcblk0p1")))
    {
        pclose(fp);
        return true;
    }
    pclose(fp);
    return false;
}

/**
 * @brief   运行数据记录文件U盘导出
 * @param   [in] p_date 要导出的日期结构体指针
 * @return  结果
 * @retval  0 导出成功
 * @retval  其他 导出失败
 */
int32_t operating2csv(operating_date_t *p_date)
{
    char src_path[PATH_FILE_MAX_LEN];  // 源文件路径
    char des_path[PATH_FILE_MAX_LEN];  // 目标文件路径
    fs_t *p_fs_src = NULL;
    fs_t *p_fs_des = NULL;
    int32_t ret;
	bool sd_sta = false;
    
    snprintf(src_path, sizeof(src_path), PATH_OPERATING_RECORD_FOLDER "%04d/%04d%02d%02d", \
            p_date->tm_year + 2000, p_date->tm_year + 2000, p_date->tm_mon, p_date->tm_day);

    /* 检测SD卡是否存在 */
    sd_sta = sd_mount_status;
    if (sd_sta == false)
    {
        log_i((int8_t *)"\n TF_CARD does not exist!!! \n");
        return SF_ERR_NO_OBJECT;
    }

    /* 判断源文件是否存在 */
    ret = sdk_fs_access((const int8_t *)src_path, SF_OK);
    if (ret != 0)
    {
        log_i((int8_t *)"[%s:%d] source file does not exist! %s \n", __func__, __LINE__, src_path);
        return EXPORT_RET_SRC_FILE_ERR;
    }

    p_fs_src = sdk_fs_open((const int8_t *)src_path, FS_READ);
    if (p_fs_src == NULL)
    {
        log_i((int8_t *)"\n sdk_fs_open source file fail! \n");
        return EXPORT_RET_SRC_FILE_OPEN_ERR;
    }

    /* 将位置偏移量移动到文件头 */
    ret = sdk_fs_lseek(p_fs_src, 0);
    if (ret < 0)
    {
        log_i((int8_t *)"\n sdk_fs_lseek error! \n");
        sdk_fs_close(p_fs_src);
        return EXPORT_RET_SRC_FILE_SEEK_ERR;
    }

    snprintf(des_path, sizeof(des_path), PATH_OPERATING_RECORD_FOLDER "%04d/%04d%02d%02d.csv", \
            p_date->tm_year  + 2000 , p_date->tm_year + 2000, p_date->tm_mon, p_date->tm_day);
    p_fs_des = sdk_fs_open((const int8_t *)des_path, FS_CREATE_ALWAYS);
    if (p_fs_des == NULL)
    {
        log_i((int8_t *)"\n sdk_fs_open des file fail! \n");
        sdk_fs_close(p_fs_src);
        return EXPORT_RET_DES_FILE_OPEN_ERR;
    }

    log_i((int8_t *)"[%s:%d] operating_data_t, size = %d \n", __func__, __LINE__, sizeof(operating_pcs_data_t));
    log_i((int8_t *)"[%s:%d] sdk_rtc_t, size = %d \n", __func__, __LINE__, sizeof(sdk_rtc_t));
    log_i((int8_t *)"[%s:%d] telematic_operating_data_t, size = %d \n", __func__, __LINE__, sizeof(telematic_operating_pcs_data_t));
    log_i((int8_t *)"[%s:%d] telemetry_operating_data_t, size = %d \n", __func__, __LINE__, sizeof(telemetry_operating_pcs_data_t));

    ret = operating_record_export_data_process(p_fs_des, p_fs_src);
    if (ret < 0)
    {
        ret = EXPORT_RET_DATA_ERR;
    }
    else
    {
        ret = EXPORT_RET_TURE;
    }

    sdk_fs_close(p_fs_src);
    sdk_fs_close(p_fs_des);

    return ret;
}

int32_t extract_data(const int8_t * src_path,const int8_t * des_path)
{
    fs_t *p_fs_src = NULL;
    fs_t *p_fs_des = NULL;
    int32_t ret;
	
	
	
	/* 判断源文件是否存在 */
	  ret = sdk_fs_access(src_path, SF_OK);
	  if (ret != 0)
	  {
		  log_i((int8_t *)"[%s:%d] source file does not exist! %s \n", __func__, __LINE__, src_path);
		  return EXPORT_RET_SRC_FILE_ERR;
	  }
	
	  p_fs_src = sdk_fs_open(src_path, FS_READ);
	  if (p_fs_src == NULL)
	  {
		  log_i((int8_t *)"\n sdk_fs_open source file fail! \n");
		  return EXPORT_RET_SRC_FILE_OPEN_ERR;
	  }
	
	  /* 将位置偏移量移动到文件头 */
	  ret = sdk_fs_lseek(p_fs_src, 0);
	  if (ret < 0)
	  {
		  log_i((int8_t *)"\n sdk_fs_lseek error! \n");
		  sdk_fs_close(p_fs_src);
		  return EXPORT_RET_SRC_FILE_SEEK_ERR;
	  }

	  p_fs_des = sdk_fs_open(des_path, FS_OPEN_APPEND);
	  if (p_fs_des == NULL)
	  {
		  log_i((int8_t *)"\n sdk_fs_open des file fail! \n");
		  sdk_fs_close(p_fs_src);
		  return EXPORT_RET_DES_FILE_OPEN_ERR;
	  }

	  ret = operating_record_export_data_process(p_fs_des, p_fs_src);
	  if (ret < 0)
	  {
		  ret = EXPORT_RET_DATA_ERR;
	  }
	  else
	  {
		  ret = EXPORT_RET_TURE;
	  }
	  
	  sdk_fs_close(p_fs_src);
	  sdk_fs_close(p_fs_des);


}


