#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"cJSON.h"
#include"homepage.h"
#include"common.h"
#include "sqlite3.h"
#include "sdk_shm.h"
 
#define HOURS_NUM_PER_DAY                (24)                    // 一天24小时
#define MAXDAYS_NUM_PER_MONTH            (31)                    // 一月最多31天
#define MONTHS_NUM_PER_YEAR                (12)                    // 一年12月
#define STORAGE_TIME_LIMIT                (20)                    // 存储时间限制 20年
#define DEFAULT_REATED_POWER     125
 
#define ENERGY_DB     "/user/data/energy/energy.db"
#define ENERGY_PATH   "/user/data/energy/"
 
typedef struct
{
    uint8_t date[32];
    double charge[32];                                
    double discharge[32];    
}data_energy_t;

typedef struct
{
    int16_t year;	// 年份，如2023
    int16_t month;	// 月份，1~12
    int16_t date;	// 日期，1~31
	int16_t hour;	// 小时，0~23
    int16_t minute;
	int16_t second;
}energy_time_t;
 
typedef struct
{
    int16_t year;	// 年份，如2023
    int16_t month;	// 月份，1~12
    int16_t date;	// 日期，1~31
	int16_t hour;	// 小时，0~23
    int16_t minute;
	int16_t second;
    // int16_t weekday; // 1~7
}power_time_t;

/**
 * @brief  根据日期计算该月几天
 * @param  [in] year 年
 * @param  [in] month 月
 * @param  [out] none
 * @return 一年中的第几天 [1~366]
 */
static  int32_t getDaysInMonth(int year, int month) 
{
    int days;
 
    if (month == 4 || month == 6 || month == 9 || month == 11) {
        days = 30;
    } else if (month == 2) {
        if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
            days = 29; // 闰年2月29天
        } else {
            days = 28; // 平年2月28天
        }
    } else {
        days = 31;
    }
        return days;
}
 
void query_day_charge(sqlite3 *db, data_energy_t  *energy_data)
{
    char sql[256];
    int32_t hour = 0;
    sqlite3_stmt *stmt;
    int32_t i=0;
    
    // snprintf(sql, sizeof(sql), "SELECT date, charge, discharge FROM charge_data WHERE date LIKE '%s%';",day_energy->date);
    snprintf(sql, sizeof(sql), "SELECT strftime('%%H', date), charge, discharge FROM charge_data WHERE date LIKE '%s%%';",energy_data->date);
    //printf("sql:%s\n",sql);
    sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
 
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        hour = atoi(sqlite3_column_text(stmt, 0));
        if (hour > 23)
        {
            printf("break \n");
            break;
        }
        energy_data->charge[hour] = sqlite3_column_double(stmt, 1)/100.00;
        energy_data->discharge[hour] = sqlite3_column_double(stmt, 2)/100.00;
        i++;
        //printf("%f %f %f\n", sqlite3_column_double(stmt, 0), sqlite3_column_double(stmt, 1), sqlite3_column_double(stmt, 2));
 
    }
  //  print_log("Found %d pieces of data\n",i);
    sqlite3_finalize(stmt);
}
 
int32_t select_sqlite_db_day(uint8_t *ymd, cJSON *p_resp_data)
{
    sqlite3 *db;
    int rc;
    data_energy_t energy_data = {0};
    int32_t i;
   
    rc = sqlite3_open(ENERGY_DB, &db);
 
    if( rc ) {
       print_log((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
       return(0);
    } else {
        //print_log((int8_t *)"open database successfully\n");
        memset(&energy_data, 0, sizeof(data_energy_t));
        snprintf((char*)energy_data.date, 32,"%s",ymd);
        
        query_day_charge(db, &energy_data);
    
        cJSON_AddItemToObject(p_resp_data,"chargeEnergy",cJSON_CreateDoubleArray(energy_data.charge ,HOURS_NUM_PER_DAY));
        cJSON_AddItemToObject(p_resp_data,"dischargeEnergy",cJSON_CreateDoubleArray(energy_data.discharge,HOURS_NUM_PER_DAY));
    }
    
    sqlite3_close(db);    
    return 1; 
}
/**
 * 获取日充放电量
*/
void get_daily_charge_discharge(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
    uint8_t *p_action;
    uint8_t ymd[32];
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    uint8_t response[128] = {0};
 
    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
    {
        strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
    }
    else
    {
        memcpy(request_body,p_msg->body.p,p_msg->body.len);        
    }
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        print_log("parse request failed.");
        build_empty_response(response,202,"parse request failed.");
        http_back(p_nc,response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action,"getDailyChargeDischarge"))
    {
        print_log("action is not right.");
        build_empty_response(response,203,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
 
    strcpy(ymd,cJSON_GetObjectItem(p_request,"ymd")->valuestring); 
    cJSON_Delete(p_request);
 
    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed.");
        return ;
    }
 
    select_sqlite_db_day(ymd, p_resp_root); 
 
    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddStringToObject(p_resp_root,"msg","get daily charge discharge successful");
 
    p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_resp_root);
 
    http_back(p_nc, p);
    free(p);
}
 
void query_monthly_charge(sqlite3 *db, data_energy_t *energy_data) 
{
    char sql[256];
    int32_t day=0;
    int32_t i=0;
    
    snprintf(sql, sizeof(sql), "SELECT strftime('%%d', date), SUM(charge), SUM(discharge) FROM charge_data WHERE strftime('%%Y-%%m', date) = '%s' GROUP BY strftime('%%Y-%%m-%%d', date);", energy_data->date);
    //printf("sql:%s\n",sql);
    sqlite3_stmt *stmt;
    sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
 
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        day =  atoi(sqlite3_column_text(stmt, 0));
        energy_data->charge[day-1] = sqlite3_column_double(stmt, 1)/100.00;
        energy_data->discharge[day-1] = sqlite3_column_double(stmt, 2)/100.00;
        i++;
       // printf("%d: %d %d\n", mon-1, sqlite3_column_int(stmt, 1), sqlite3_column_int(stmt, 2));
    }
   // print_log("Found %d pieces of data\n",i);
    sqlite3_finalize(stmt);
}
 
int32_t select_sqlite_db_mon(uint8_t *ymd, cJSON *p_resp_data)
{
    sqlite3 *db;
    int rc;
    data_energy_t energy_data;
    int32_t i;
    int32_t year;
    int32_t month;
    int32_t days = 0;
    
    rc = sqlite3_open(ENERGY_DB, &db);
    if( rc ) {
       print_log((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
       return(0);
    } else {
        //print_log((int8_t *)"open database successfully\n");
        memset(&energy_data, 0, sizeof(data_energy_t));
        snprintf((char*)energy_data.date, 32,"%s",ymd);
        sscanf(ymd,"%d-%d",&year,&month);
        days = getDaysInMonth(year, month);
        query_monthly_charge(db, &energy_data);
    
        cJSON_AddItemToObject(p_resp_data,"chargeEnergy",cJSON_CreateDoubleArray(energy_data.charge ,days));
        cJSON_AddItemToObject(p_resp_data,"dischargeEnergy",cJSON_CreateDoubleArray(energy_data.discharge,days));
    }
    
    sqlite3_close(db);  
    return 1;   
}
 
/**
 * 获取月充放电量
*/
void get_monthly_charge_discharge(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
    uint8_t response[128] = {0};
    uint8_t *p_action;
    uint8_t ymd[32];
    uint8_t *p;
    uint8_t request_body[1024] = {0};
 
    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
    {
        strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
    }
    else
    {
        memcpy(request_body,p_msg->body.p,p_msg->body.len);        
    }
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        print_log("parse request failed.");
        build_empty_response(response,202,"parse request failed.");
        http_back(p_nc,response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action,"getMonthlyChargeDischarge"))
    {
        print_log("action is not right.");
        build_empty_response(response,203,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
 
    strcpy(ymd,cJSON_GetObjectItem(p_request,"ymd")->valuestring);
    cJSON_Delete(p_request);
 
    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed.");
        return ;
    }
 
    select_sqlite_db_mon(ymd, p_resp_root);
    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddStringToObject(p_resp_root,"msg","get monthly  charge discharge successful");
    p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_resp_root);
 
    http_back(p_nc,p);
    free(p);
}
 
/* Query the monthly charge for a given year */
void query_yearly_charge(sqlite3 *db, data_energy_t *energy_data) {
    char sql[256];
    int32_t mon=0;
    int32_t i=0;
    
    snprintf(sql, sizeof(sql), "SELECT strftime('%%m', date), SUM(charge), SUM(discharge) FROM charge_data WHERE strftime('%%Y', date) = '%s' GROUP BY strftime('%%Y-%%m', date);", energy_data->date);
    //printf("sql:%s\n",sql);
    sqlite3_stmt *stmt;
    sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
 
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        mon =  atoi(sqlite3_column_text(stmt, 0));
        energy_data->charge[mon-1] = sqlite3_column_double(stmt, 1)/100.00;
        energy_data->discharge[mon-1] = sqlite3_column_double(stmt, 2)/100.00;
        i++;
       // printf("%d: %d %d\n", mon-1, sqlite3_column_int(stmt, 1), sqlite3_column_int(stmt, 2));
    }
   // print_log("Found %d pieces of data\n",i);
    sqlite3_finalize(stmt);
}
 
int32_t select_sqlite_db_year(uint8_t *year, cJSON *p_resp_data)
{
    sqlite3 *db;
    int rc;
    data_energy_t energy_data;
    int32_t i;
    
    rc = sqlite3_open(ENERGY_DB, &db);
    if( rc ) {
       print_log((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
       return(0);
    } else {
        //print_log((int8_t *)"open database successfully\n");
        memset(&energy_data, 0, sizeof(data_energy_t));
        snprintf((char*)energy_data.date, 32,"%s",year);
        
        query_yearly_charge(db, &energy_data);
    
        cJSON_AddItemToObject(p_resp_data,"chargeEnergy",cJSON_CreateDoubleArray(energy_data.charge , MONTHS_NUM_PER_YEAR));
        cJSON_AddItemToObject(p_resp_data,"dischargeEnergy",cJSON_CreateDoubleArray(energy_data.discharge, MONTHS_NUM_PER_YEAR));
    }
    
    sqlite3_close(db);     
    return 1;
}
 
/**
 * 获取年充放电量
*/
void get_yearly_charge_discharge(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
    uint8_t response[128] = {0};
    uint8_t *p_action;
    uint8_t ymd[32];
  
    uint8_t *p;
    uint8_t request_body[1024] = {0};
 
    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
    {
        strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
    }
    else
    {
        memcpy(request_body,p_msg->body.p,p_msg->body.len);        
    }
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        print_log("parse request failed.");
        build_empty_response(response,202,"parse request failed.");
        http_back(p_nc,response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action,"getYearChargeDischarge"))
    {
        print_log("action is not right.");
        build_empty_response(response,203,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
 
    p = cJSON_GetObjectItem(p_request,"ymd")->valuestring;
    snprintf((char*)ymd, sizeof(ymd),"%s",p);
    cJSON_Delete(p_request);
 
    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed.");
        return ;
    }
 
    select_sqlite_db_year(ymd, p_resp_root);   
    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddStringToObject(p_resp_root,"msg","get year charge discharge successful");
 
    p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_resp_root);
 
    http_back(p_nc, p);
    free(p);
}
 
/* Query the monthly charge for a given year */
void query_total_charge(sqlite3 *db, double *p_charge, double *p_discharge, int *len) {
    char sql[256];
    int32_t year = 0;
    int32_t i = 0;
    
    snprintf(sql, sizeof(sql), "SELECT strftime(date), SUM(charge), SUM(discharge) FROM charge_data;");
    //printf("sql:%s\n",sql);
    sqlite3_stmt *stmt;
    sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
 
    while (sqlite3_step(stmt) == SQLITE_ROW) 
    {
        if (i > STORAGE_TIME_LIMIT)
        {
            break;
        }
        year =  atoi(sqlite3_column_text(stmt, 0));
        *p_charge = sqlite3_column_double(stmt, 1)/100.00;
        *p_discharge = sqlite3_column_double(stmt, 2)/100.00;
        i++;
       // printf("%d: %d %d\n", year, sqlite3_column_int(stmt, 1), sqlite3_column_int(stmt, 2));
    }
    *len = i;
  //  print_log("Found %d pieces of data",i);
    sqlite3_finalize(stmt);
}
 
int32_t select_sqlite_db_total(uint8_t *year, cJSON *p_resp_data)
{
    sqlite3 *db;
    int rc;
    double charge = 0;                 
    double discharge = 0;
    int32_t len = 0;
    
    rc = sqlite3_open(ENERGY_DB, &db);
    if( rc ) {
       print_log((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
       return(0);
    } else {
        query_total_charge(db, &charge, &discharge, &len);
    
        cJSON_AddNumberToObject(p_resp_data,"chargeEnergy", charge);
        cJSON_AddNumberToObject(p_resp_data,"dischargeEnergy", discharge);
    }
    
    sqlite3_close(db);  
    return 1;   
}
 
/**
 * 获取总的充放电量
*/
void get_total_charge_discharge(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
    uint8_t response[256];
    uint8_t *p_action;
    uint8_t *p_ymd;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    uint8_t ymd[16] = {0};
 
    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
    {
        strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
    }
    else
    {
        memcpy(request_body,p_msg->body.p,p_msg->body.len);        
    }
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        print_log("parse request failed.");
        build_empty_response(response,202,"parse request failed.");
        http_back(p_nc,response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action,"getTotalChargeDischarge"))
    {
        print_log("action is not right.");
        build_empty_response(response,203,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
 
    p_ymd = cJSON_GetObjectItem(p_request,"ymd")->valuestring;  
    if(strcmp(p_ymd,"total"))
    {
        print_log("ymd is not right.");
        build_empty_response(response,204,"request ymd is not right,should be 'total'");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
    p = cJSON_GetObjectItem(p_request,"ymd")->valuestring;
    snprintf((char*)ymd, sizeof(ymd),"%s",p);
    cJSON_Delete(p_request);
 
    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed.");
        return ;
    }
 
    select_sqlite_db_total(ymd, p_resp_root);   
    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddStringToObject(p_resp_root,"msg","get total  charge discharge successful");
 
    p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_resp_root);
 
    http_back(p_nc, p);
    free(p);
}
 
 
uint16_t get_data_array_pos(uint8_t *p_time)
{
    uint8_t hour = 0;
    uint8_t min = 0;
    uint16_t min_data = 0;
 
    sscanf(p_time, "%d:%d", &hour, &min);
    min_data = hour * 60 + min;
    return (min_data / 5);
}
 
void query_day_charge_power(sqlite3 *db, uint8_t *p_date, double *p_buf)
{
    char sql[256];
    uint8_t p_node_time[64] = {0};
    sqlite3_stmt *stmt;
    uint16_t pos = 0;
    
    snprintf(sql, sizeof(sql), "SELECT strftime('%%H:%M', date), power FROM power_data WHERE date LIKE '%s%%';",p_date);
    sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
 
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        memcpy(p_node_time, sqlite3_column_text(stmt, 0), strlen(sqlite3_column_text(stmt, 0)));
        //转换为分钟获取点位
        pos = get_data_array_pos(p_node_time);
        p_buf[pos] = sqlite3_column_double(stmt, 1);
    }
    sqlite3_finalize(stmt);
}
 
 
int32_t select_power_sqlite_db_day(power_time_t *p_time, uint8_t *p_ymd, double *p_buf)
{
    #define PATH_POWER_GENERAL_DIR     "/user/data/power/"
    sqlite3 *db;
    int rc;
    int32_t i;
    char db_name[512] = {0};
    uint8_t date[64] = {0};
 
    p_time->year -= 2000;
    sprintf(db_name, "%s%s-%d%s",PATH_POWER_GENERAL_DIR, "power", p_time->year, ".db");
    rc = sqlite3_open(db_name, &db);
 
    if( rc ) {
       print_log((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
       return(0);
    } else {
        snprintf((char*)date, 64,"%s",p_ymd);
        query_day_charge_power(db, date, p_buf);
    }
    
    sqlite3_close(db);    
    return 1; 
}
 
void get_daily_power(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
    cJSON *p_resp_item;
    uint8_t response[64];
    uint8_t *p_action;
    uint8_t ymd[32];
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    power_time_t power_time;
    int32_t data_num;
    double energy_data[288];
    uint16_t i;
    telemetry_data_t *p_telemetry_data;
    uint16_t rated_power;
 
    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
    {
        strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
    }
    else
    {
        memcpy(request_body,p_msg->body.p,p_msg->body.len);        
    }
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        print_log("parse request failed.");
        build_empty_response(response,202,"parse request failed.");
        http_back(p_nc,response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action,"getDailyPower"))
    {
        print_log("action is not right.");
        build_empty_response(response,203,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
 
    strcpy(ymd,cJSON_GetObjectItem(p_request,"ymd")->valuestring); 
    cJSON_Delete(p_request);
 
    p_resp_item = cJSON_CreateObject();
    if(p_resp_item == NULL)
    {
        print_log("create json obj failed.");
        return ;
    }
 
    memset(&power_time,0,sizeof(energy_time_t));
    sscanf(ymd,"%d-%d-%d",&power_time.year,&power_time.month,&power_time.date);
 
    memset(energy_data,0,sizeof(double) * 288);
 
    select_power_sqlite_db_day(&power_time, ymd, energy_data);
   
    #if 0
    //2023.7.27测试,主要是测试一下充放电功率是相反的这个问题
    for(i = 50; i < 130; i++)
    {
        charge_data[i] = 1440;
        discharge_data[i+144] = -900;
    }
    #endif
 
    p_telemetry_data = sdk_shm_telemetry_data_get();
    rated_power = p_telemetry_data->pcs_module_version_telemetry_info[0].power;
    rated_power /= 10;

    for(i = 0; i < 288; i++)
    {
        //一般地,我们认为不会有这么小的功率
        if(rated_power == 0)
        {
            if(abs(energy_data[i]) <= DEFAULT_REATED_POWER * 0.005)  //正负0.5%不计算在内
            {
                energy_data[i] = 0;
            }
        }
        else
        {
            if(abs(energy_data[i]) <= rated_power * 0.005)
            {
                energy_data[i] = 0;
            }
        }
    }
 
    cJSON_AddItemToObject(p_resp_item,"batPower",cJSON_CreateDoubleArray(energy_data,288)); 
 
    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed.");
        cJSON_Delete(p_resp_item);
        return ;
    }
    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddItemToObject(p_resp_root,"data",p_resp_item);
    cJSON_AddStringToObject(p_resp_root,"msg","get daily charge discharge successful");
 
    p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_resp_root);
 
    http_back(p_nc,p);
    free(p);
}
 