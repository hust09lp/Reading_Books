#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"cJSON.h"
#include"history_rtdata.h"
#include"common.h"
#include "sdk_public.h"
#include"web_data_interface.h"
#include "web_broker.h"


/**
 * @brief  	将sdk_rtc_t结构体时间转换成时间戳（秒）
 * @param  	[in] p_time         sdk_rtc_t结构体时间
 * @param  	[out] p_timestamp   时间戳（秒）
 * @return 	无
 */
static void date_time_to_timestamp(sdk_rtc_t *p_time, time_t *p_timestamp)
{
    struct tm data;

    memset(&data, 0, sizeof(data));
    data.tm_year = (int32_t)(p_time->tm_year) + 100;
    data.tm_mon  = (int32_t)(p_time->tm_mon - 1);
    data.tm_mday = (int32_t)(p_time->tm_day);
    data.tm_hour = (int32_t)(p_time->tm_hour);
    data.tm_min  = (int32_t)(p_time->tm_min);
    data.tm_sec  = (int32_t)(p_time->tm_sec);
    *p_timestamp = mktime(&data);
}

void get_cluster_history_info(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_item = NULL;
    cJSON *p_resp_array = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t response[64] = {0};
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t request_body[1024] = {0};
    uint8_t *p_start = NULL;
    uint8_t *p_end = NULL;
    sdk_rtc_t rtc_start = {0};
    sdk_rtc_t rtc_end = {0};
    uint8_t cluster_index = {0};
    history_data_page_t *p_data = NULL;
    uint32_t data_num = 0;
    uint32_t i;
    time_t item_timestamp = 0;
    uint8_t date[32] = {0};
    uint32_t year = 0, mon = 0, day = 0;
    uint32_t hour = 0, min = 0, sec = 0;

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}
    
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getClusterHistoryInfo"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		cJSON_Delete(p_request);
        http_back(p_nc,response);
		return;
	}

    p_start = cJSON_GetObjectItem(p_request,"timeStart")->valuestring;
    p_end = cJSON_GetObjectItem(p_request,"timeEnd")->valuestring;
    cluster_index = cJSON_GetObjectItem(p_request,"clusterIndex")->valueint;

    sscanf(p_start, "%04d-%02d-%02d %02d:%02d:%02d", &year, &mon, &day, 
                                                     &hour, &min, &sec);
    rtc_start.tm_year = year - 2000;
    rtc_start.tm_mon = mon;
    rtc_start.tm_day = day;
    rtc_start.tm_hour = hour;
    rtc_start.tm_min = min;
    rtc_start.tm_sec = sec;
    sscanf(p_end, "%04d-%02d-%02d %02d:%02d:%02d",   &year, &mon, &day, 
                                                     &hour, &min, &sec);
    rtc_end.tm_year = year - 2000;
    rtc_end.tm_mon = mon;
    rtc_end.tm_day = day;
    rtc_end.tm_hour = hour;
    rtc_end.tm_min = min;
    rtc_end.tm_sec = sec;

    cJSON_Delete(p_request);
    p_data = (history_data_page_t *)malloc(MAX_HISTORY_ITEMS * sizeof(history_data_page_t));
    if(p_data == NULL)
    {
        print_log("malloc memory failed");
        return;
    }
    cluster_index -= 1;
  
    if (history_data_page_get(&rtc_start,&rtc_end,cluster_index,(void *)p_data,&data_num) != 0)
    {
        print_log("history_data_page_get failed");
        data_num = 0;
       // free(p_data);
        //return;
    }
    
    p_resp_array = cJSON_CreateArray();
    if(p_resp_array == NULL)
    {
        print_log("create json array failed");
        free(p_data);
        return;
    }
    for(i = 0;i < data_num;i++)
    {
        p_resp_item = cJSON_CreateObject();
        if(p_resp_item == NULL)
        {
            print_log("create json obj failed");
            cJSON_Delete(p_resp_array);
            free(p_data);
            return;
        }
        date_time_to_timestamp(&p_data[i].operating_time,&item_timestamp);
	    sprintf(date, "%04d-%02d-%02d %02d:%02d:%02d", 2000 + p_data[i].operating_time.tm_year, 
                                                                p_data[i].operating_time.tm_mon, 
                                                                p_data[i].operating_time.tm_day, 
                                                                p_data[i].operating_time.tm_hour, 
                                                                p_data[i].operating_time.tm_min, 
                                                                p_data[i].operating_time.tm_sec); 
        cJSON_AddStringToObject(p_resp_item,"time",date);
        cJSON_AddNumberToObject(p_resp_item,"voltage",p_data[i].cluster_voltage/10.0);
        //要与PCS方向保持一致，这里电流取反
        cJSON_AddNumberToObject(p_resp_item,"current",(-(p_data[i].cluster_current - 16000)/10.0));
        cJSON_AddNumberToObject(p_resp_item,"soc",p_data[i].cluster_SOC);
        cJSON_AddNumberToObject(p_resp_item,"soh",p_data[i].average_SOH_monomer);
        cJSON_AddNumberToObject(p_resp_item,"monomerVmax",p_data[i].highest_monomer_voltage_cluster);
        cJSON_AddNumberToObject(p_resp_item,"monomerVmin",p_data[i].lowest_monomer_voltage_cluster);
        cJSON_AddNumberToObject(p_resp_item,"monomerVmean",p_data[i].average_voltage_monomer);
        cJSON_AddNumberToObject(p_resp_item,"monomerTmax",(p_data[i].highest_monomer_temperature_cluster - 40));
        cJSON_AddNumberToObject(p_resp_item,"monomerTmin",(p_data[i].lowest_monomer_temperature_cluster - 40));
        cJSON_AddNumberToObject(p_resp_item,"monomerTmean",(p_data[i].average_temperature_monomer - 40));
        cJSON_AddNumberToObject(p_resp_item,"precombT1",(p_data[i].high_pressure_box_temperature1 - 40));
        cJSON_AddNumberToObject(p_resp_item,"precombT2",(p_data[i].high_pressure_box_temperature2 - 40));
        cJSON_AddNumberToObject(p_resp_item,"precombT3",(p_data[i].high_pressure_box_temperature3 - 40));
        cJSON_AddNumberToObject(p_resp_item,"precombT4",(p_data[i].high_pressure_box_temperature4 - 40));
        cJSON_AddNumberToObject(p_resp_item,"posInsulation",p_data[i].positive_insulation_resistance);
        cJSON_AddNumberToObject(p_resp_item,"negaInsulation",p_data[i].negative_insulation_resistance);

        cJSON_AddItemToArray(p_resp_array,p_resp_item);
    }
    free(p_data); //到这里数据已经全部解析到了json里面,可以释放了

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create cjson failed");
        cJSON_Delete(p_resp_array);
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddItemToObject(p_resp_root,"data",p_resp_array);
    cJSON_AddStringToObject(p_resp_root,"msg","get cluster history info successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_resp_root);

    http_back(p_nc,p);
    free(p);
}

void get_pack_history_info(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_array = NULL;
    cJSON *p_resp_array2 = NULL;
    cJSON *p_resp_item = NULL;
    cJSON *p_resp_item2 = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t response[64];
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t *p_start = NULL;
    uint8_t *p_end = NULL;
    uint8_t request_body[1024] = {0};
    // time_t start;
    // time_t end;
    sdk_rtc_t rtc_start;
    sdk_rtc_t rtc_end;
    uint8_t cluster_index;
    uint8_t pack_index;
    history_data_page_t *p_data = NULL;
    uint32_t data_num;
    uint32_t i,j;
    time_t item_timestamp;
    int32_t data_array[4];
    uint32_t total_voltage;
    uint8_t date[32] = {0};
    uint32_t year = 0, mon = 0, day = 0;
    uint32_t hour = 0, min = 0, sec = 0;

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}
    
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getPackHistoryInfo"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		cJSON_Delete(p_request);
        http_back(p_nc,response);
		return;
	}

    p_start = cJSON_GetObjectItem(p_request,"timeStart")->valuestring;
    p_end = cJSON_GetObjectItem(p_request,"timeEnd")->valuestring;
    cluster_index = cJSON_GetObjectItem(p_request,"clusterIndex")->valueint;
    pack_index = cJSON_GetObjectItem(p_request,"packIndex")->valueint;

    sscanf(p_start, "%04d-%02d-%02d %02d:%02d:%02d", &year, &mon, &day, 
                                                     &hour, &min, &sec);
    rtc_start.tm_year = year - 2000;
    rtc_start.tm_mon = mon;
    rtc_start.tm_day = day;
    rtc_start.tm_hour = hour;
    rtc_start.tm_min = min;
    rtc_start.tm_sec = sec;
    sscanf(p_end, "%04d-%02d-%02d %02d:%02d:%02d",   &year, &mon, &day, 
                                                     &hour, &min, &sec);
    rtc_end.tm_year = year - 2000;
    rtc_end.tm_mon = mon;
    rtc_end.tm_day = day;
    rtc_end.tm_hour = hour;
    rtc_end.tm_min = min;
    rtc_end.tm_sec = sec;

    cJSON_Delete(p_request);

    p_data = (history_data_page_t *)malloc(MAX_HISTORY_ITEMS * sizeof(history_data_page_t));
    if(p_data == NULL)
    {
        print_log("malloc memory failed");
        return;
    }

    cluster_index -= 1;
    if (history_data_page_get(&rtc_start,&rtc_end,cluster_index,(void *)p_data,&data_num) != 0)
    {
        print_log("history_data_page_get failed");
        data_num = 0;
       // free(p_data);
        //return;
    }

    p_resp_array = cJSON_CreateArray();
    if(p_resp_array == NULL)
    {
        print_log("create json array failed");
        free(p_data);
        return;
    }

    pack_index -= 1;
    for(i = 0;i < data_num;i++)
    {
        total_voltage = 0;
        p_resp_item = cJSON_CreateObject();
        if(p_resp_item == NULL)
        {
            print_log("create json obj failed");
            free(p_data);
            cJSON_Delete(p_resp_array);
            return;
        }

        p_resp_array2 = cJSON_CreateArray();
        if(p_resp_array2 == NULL)
        {
            print_log("create json array failed");
            free(p_data);
            cJSON_Delete(p_resp_array);
            cJSON_Delete(p_resp_item);
            return;
        }
    
        date_time_to_timestamp(&p_data[i].operating_time,&item_timestamp);
        for(j = 0;j < 48;j++)  //一个PACK有48个电芯
        {
            total_voltage += p_data[i].monomer_info[pack_index].monomer_voltage[j];

            p_resp_item2 = cJSON_CreateObject();
            if(p_resp_item2 == NULL)
            {
                print_log("create json obj failed");
                free(p_data);
                cJSON_Delete(p_resp_array);
                cJSON_Delete(p_resp_item);
                cJSON_Delete(p_resp_array2);
                return;
            }
            
            cJSON_AddNumberToObject(p_resp_item2,"voltage",p_data[i].monomer_info[pack_index].monomer_voltage[j]);
            cJSON_AddNumberToObject(p_resp_item2,"temperatrue",(p_data[i].monomer_info[pack_index].monomer_temperature[j] - 40));
            cJSON_AddNumberToObject(p_resp_item2,"soc",p_data[i].monomer_info[pack_index].monomer_SOC[j]);
            cJSON_AddNumberToObject(p_resp_item2,"soh",p_data[i].monomer_info[pack_index].monomer_SOH[j]);

            cJSON_AddItemToArray(p_resp_array2,p_resp_item2);
        }
    	sprintf(date, "%04d-%02d-%02d %02d:%02d:%02d", 2000 + p_data[i].operating_time.tm_year, 
                                                                p_data[i].operating_time.tm_mon, 
                                                                p_data[i].operating_time.tm_day, 
                                                                p_data[i].operating_time.tm_hour, 
                                                                p_data[i].operating_time.tm_min, 
                                                                p_data[i].operating_time.tm_sec); 
        cJSON_AddStringToObject(p_resp_item,"time",date);
        cJSON_AddNumberToObject(p_resp_item,"packT1",(p_data[i].monomer_info[pack_index].pole_temperater_PACK[0] - 40));
        cJSON_AddNumberToObject(p_resp_item,"packT2",(p_data[i].monomer_info[pack_index].pole_temperater_PACK[1] - 40));
        //cJSON_AddNumberToObject(p_resp_item,"packT1",t1);
        //cJSON_AddNumberToObject(p_resp_item,"packT2",t2);
        cJSON_AddNumberToObject(p_resp_item,"packVoltage",total_voltage/1000.0);
        cJSON_AddItemToObject(p_resp_item,"data",p_resp_array2);

        cJSON_AddItemToArray(p_resp_array,p_resp_item);
    }
    free(p_data); //到这里数据已经全部解析到了json里面,可以释放了

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create cjson failed");
        cJSON_Delete(p_resp_array);
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddItemToObject(p_resp_root,"data",p_resp_array);
    cJSON_AddStringToObject(p_resp_root,"msg","get pack history info successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_resp_root);

    http_back(p_nc,p);
    free(p);
}

/**
 * @brief 历史数据模块初始化
 * @return void
 */
void history_data_module_init(void)
{
    /*获取电池簇历史信息*/
	if(!web_func_attach("/getHistoryInfo/getClusterHistoryInfo", get_cluster_history_info))
	{
		print_log("[/getHistoryInfo/getClusterHistoryInfo] attach failed");
	}
	/*获取PACK历史信息*/
	if(!web_func_attach("/getHistoryInfo/getPackHistoryInfo", get_pack_history_info))
	{
		print_log("[/getHistoryInfo/getPackHistoryInfo] attach failed");
	}
}