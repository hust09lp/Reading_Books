#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"cJSON.h"
#include"pcsInfo.h"
#include"common.h"
#include"data_shm.h"
#include"sdk_shm.h"
#include"web_data_interface.h"
#include "web_broker.h"

#define SN_LEN      (10) 
#define FWV_LEN      (4)  

static int32_t pcsm_state(int32_t pcs)
{
	heartbeat_data_t *heartbeat_data = sdk_shm_heartbeat_data_get();

	if ((pcs < 0) || (pcs > 7) || (NULL == heartbeat_data))
	{
		return -1;
	}

	if (0 == heartbeat_data->comm_state[pcs])
	{
		return 0;
	}

	if (1 == heartbeat_data->fault_state[pcs])
	{
		return 2;
	}	

		return 1;

}


/**
 * @brief    获取PCS模块概要信息
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void get_pcs_simple(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;	
    cJSON *p_resp_array;
	cJSON *p_resp_item;
    uint8_t response[158];
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
	int32_t i = 0,j = 0,len = 0;
	uint8_t str[64]={0};
	debug_manage_version_info_t version_info;
	char version_buff[32] = {0};
	
	telemetry_data_t *pcs_telemetry_data = sdk_shm_pcs_telemetry_data_get();
	power_module_telemetry_info_t *module_info = NULL;
	pcs_module_version_telemetry_info_t *module_version_info = NULL;	
	common_data_t *p_shm = sdk_shm_get();

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getPCSSimple"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		cJSON_Delete(p_request);
		http_back(p_nc,response);
		return;
	}

    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed.");
        return;
    }
	
    cJSON_AddNumberToObject(p_resp_root,"code",200);


    p_resp_array = cJSON_CreateArray();
    if(p_resp_array == NULL)
    {
        print_log("create json array failed.");
        cJSON_Delete(p_resp_root);
        return;
    }
	//Jhon modified @2023.8.2此处直接使用宏代替
	for (i = 0; i < PCS_CABINET_POWER_MODULE_NUM/*8*/; ++i)
	{
   		p_resp_item = cJSON_CreateObject();
 		if(p_resp_item == NULL)
    	{
        	print_log("create json obj failed.");
			cJSON_Delete(p_resp_array);
        	cJSON_Delete(p_resp_root);
        	return;
   		}

		module_info = &pcs_telemetry_data->power_module_telemetry_info[i];
		//module_info->apparent_power =1;
		cJSON_AddNumberToObject(p_resp_item,"state",pcsm_state(i));
		cJSON_AddNumberToObject(p_resp_item,"activePower",module_info->active_power/100.0);
		cJSON_AddNumberToObject(p_resp_item,"reactivePower",module_info->reactive_power/100.0);
		cJSON_AddNumberToObject(p_resp_item,"apparentPower",module_info->apparent_power/100.0);		
		cJSON_AddNumberToObject(p_resp_item,"gridVoltRS",module_info->grid_volt_rs/10.0);
		cJSON_AddNumberToObject(p_resp_item,"gridVoltST",module_info->grid_volt_st/10.0);
		cJSON_AddNumberToObject(p_resp_item,"gridVoltTR",module_info->grid_volt_tr/10.0);
		cJSON_AddNumberToObject(p_resp_item,"gridFreq",module_info->grid_freq/100.0);
		cJSON_AddNumberToObject(p_resp_item,"acCurrentR",module_info->ac_current_r/10.0);
		cJSON_AddNumberToObject(p_resp_item,"acCurrentS",module_info->ac_current_r/10.0);
		cJSON_AddNumberToObject(p_resp_item,"acCurrentT",module_info->ac_current_s/10.0);
		cJSON_AddNumberToObject(p_resp_item,"powerFactor",module_info->power_factor/100.0);
		// cJSON_AddNumberToObject(p_resp_item,"busVoltPN",module_info->bus_volt_pn/10.0);
		cJSON_AddNumberToObject(p_resp_item,"posHalfBusVoltPN",module_info->bus_volt_p/10.0);
		cJSON_AddNumberToObject(p_resp_item,"negHalfBusVoltPN",module_info->bus_volt_n/10.0);
		cJSON_AddNumberToObject(p_resp_item,"batVolt",module_info->bat_volt/10.0);
		cJSON_AddNumberToObject(p_resp_item,"SafetyRegion",p_shm->internal_shared_data.pcs_safety_country_region >> 8);
		cJSON_AddNumberToObject(p_resp_item,"SafetyStandard",p_shm->internal_shared_data.pcs_safety_country_region & 0xff);
		cJSON_AddNumberToObject(p_resp_item,"SafetyVersion",p_shm->internal_shared_data.pcs_safety_ver);
		cJSON_AddNumberToObject(p_resp_item,"FactoryMode",p_shm->constant_parameter_data.pcs_parameter_data[0].factory_mode);

		module_version_info = &pcs_telemetry_data->pcs_module_version_telemetry_info[i];
		len = 0;
		for (j = 0; j < SN_LEN; ++j)
		{
			len += sprintf(str+len,"%c",(module_version_info->sn[j] & 0x00FF));
			len += sprintf(str+len,"%c",((module_version_info->sn[j] >> 8)  & 0x00ff));
		}
		str[len]=0;
		cJSON_AddStringToObject(p_resp_item,"sn",str);
		snprintf(version_buff,sizeof(version_buff),"%c%d.%d.%d",module_version_info->fw_version[0],\
		module_version_info->fw_version[1],module_version_info->fw_version[2],module_version_info->fw_version[3]);
		cJSON_AddStringToObject(p_resp_item,"fwVersion",version_buff);

		snprintf(version_buff,sizeof(version_buff),"%c%d.%d.%d",module_version_info->slv_fw_version[0],\
		module_version_info->slv_fw_version[1],module_version_info->slv_fw_version[2],module_version_info->slv_fw_version[3]);
		cJSON_AddStringToObject(p_resp_item,"slvFwVersion",version_buff);

		memset(version_buff,0,sizeof(version_buff));
		if(module_version_info->control_board_hw_version >= 10)
		{
			snprintf(version_buff + strlen(version_buff),sizeof(version_buff) - strlen(version_buff),"Vx");
		}
		else
		{
			snprintf(version_buff + strlen(version_buff),sizeof(version_buff) - strlen(version_buff),"V%d",module_version_info->control_board_hw_version);
		}
		if(module_version_info->output_board_hw_version >= 10)
		{
			snprintf(version_buff + strlen(version_buff),sizeof(version_buff) - strlen(version_buff),"x");
		}
		else
		{
			snprintf(version_buff + strlen(version_buff),sizeof(version_buff) - strlen(version_buff),"%d",module_version_info->output_board_hw_version);
		}
		if(module_version_info->power_board_hw_version >= 10)
		{
			snprintf(version_buff + strlen(version_buff),sizeof(version_buff) - strlen(version_buff),"x");
		}
		else
		{
			snprintf(version_buff + strlen(version_buff),sizeof(version_buff) - strlen(version_buff),"%d",module_version_info->power_board_hw_version);
		}
		cJSON_AddStringToObject(p_resp_item,"pcsHardwareVersion",version_buff);
		//软件版本
		debug_manage_version_info_get(&version_info);
		snprintf(version_buff,sizeof(version_buff),"%c%d.%d.%d",version_info.mcu1_core_soft_version[0],
		version_info.mcu1_core_soft_version[1],version_info.mcu1_core_soft_version[2],version_info.mcu1_core_soft_version[3]);
		cJSON_AddStringToObject(p_resp_item,"mcu1CoreSwVersion",version_buff);
		snprintf(version_buff,sizeof(version_buff),"%c%d.%d.%d",version_info.mcu1_app_soft_version[0],
		version_info.mcu1_app_soft_version[1],version_info.mcu1_app_soft_version[2],version_info.mcu1_app_soft_version[3]);
		cJSON_AddStringToObject(p_resp_item,"mcu1AppSwVersion",version_buff);
		snprintf(version_buff,sizeof(version_buff),"V%d.%d",version_info.mcu1_hardware_version[0],version_info.mcu1_hardware_version[1]);
		cJSON_AddStringToObject(p_resp_item,"mcu1HwVersion",version_buff);
		cJSON_AddStringToObject(p_resp_item,"CMUHwVersion",version_buff);

		snprintf(version_buff,sizeof(version_buff),"%c%d.%d.%d",version_info.mcu2_core_soft_version[0],
		version_info.mcu2_core_soft_version[1],version_info.mcu2_core_soft_version[2],version_info.mcu2_core_soft_version[3]);
		cJSON_AddStringToObject(p_resp_item,"mcu2CoreSwVersion",version_buff);
		snprintf(version_buff,sizeof(version_buff),"%c%d.%d.%d",version_info.mcu2_app_soft_version[0],
		version_info.mcu2_app_soft_version[1],version_info.mcu2_app_soft_version[2],version_info.mcu2_app_soft_version[3]);
		cJSON_AddStringToObject(p_resp_item,"mcu2AppSwVersion",version_buff);
		snprintf(version_buff,sizeof(version_buff),"V%d.%d",version_info.mcu2_hardware_version[0],version_info.mcu2_hardware_version[1]);
		cJSON_AddStringToObject(p_resp_item,"mcu2HwVersion",version_buff);

		snprintf(version_buff,sizeof(version_buff),"%02d.%02d",version_info.bat_software_version[0],version_info.bat_software_version[1]);
		cJSON_AddStringToObject(p_resp_item,"bmsSwVersion",version_buff);

		snprintf(version_buff,sizeof(version_buff),"V%02d",version_info.can_protocol_version);
		cJSON_AddStringToObject(p_resp_item,"communication_protocol_version",version_buff);
		cJSON_AddItemToArray(p_resp_array,p_resp_item);
	
		snprintf(version_buff,sizeof(version_buff),"V%d.%d",version_info.ff_software_version[0],version_info.ff_software_version[1]);
		cJSON_AddStringToObject(p_resp_item,"FireProtectionVersion",version_buff);
	}

	cJSON_AddItemToObject(p_resp_root,"data",p_resp_array);
	cJSON_AddStringToObject(p_resp_root,"msg","get successful");

	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);
}

/**
 * @brief    获取单个PCS模块详细概要信息
 * @param	 [in] *p_nc 连接信息 *p_msg  http请求信息
 * @return
 */
void get_pcs_detailede(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;	
    cJSON *p_resp_array;
	cJSON *p_resp_item;
    uint8_t response[168] = {0};
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
	int32_t i = 0;
	int32_t len = 0;	
	int32_t index = 1;
	uint8_t str[64]={0};
	
	telemetry_data_t *pcs_telemetry_data = sdk_shm_pcs_telemetry_data_get();
	power_module_telemetry_info_t *module_info = NULL;
	pcs_module_version_telemetry_info_t *module_version_info = NULL;	

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getPCSDetailede"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		cJSON_Delete(p_request);
		http_back(p_nc,response);
		return;
	}

	//这里屏蔽掉，因为一个CMU只有一个PCS功率模块，默认为1即可
	// index = cJSON_GetObjectItem(p_request,"mcuIndex")->valueint;
	// if((index < 1) || (index > 8))
	// {
	// 	print_log("action is not right.");
	// 	build_empty_response(response,203,"action is not right");
	// 	cJSON_Delete(p_request);
	// 	http_back(p_nc,response);
	// 	return;
	// }

	
    cJSON_Delete(p_request);

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root== NULL)
	{
		print_log("create json array failed");
		return;
	}
	cJSON_AddNumberToObject(p_resp_root,"code",200);
	
	p_resp_item = cJSON_CreateObject();
	if(p_resp_item == NULL)
	{
		cJSON_Delete(p_resp_root);
		print_log("create json array failed");
		return;
	}

	module_info = &pcs_telemetry_data->power_module_telemetry_info[index -1];
	cJSON_AddNumberToObject(p_resp_item,"gridVoltR",(module_info->grid_volt_r)/10.0);
	cJSON_AddNumberToObject(p_resp_item,"gridVoltS",(module_info->grid_volt_s)/10.0);
	cJSON_AddNumberToObject(p_resp_item,"gridVoltT",(module_info->grid_volt_t)/10.0);
	cJSON_AddNumberToObject(p_resp_item,"gridVoltRS",(module_info->grid_volt_rs)/10.0);
	cJSON_AddNumberToObject(p_resp_item,"gridVoltST",(module_info->grid_volt_st)/10.0);
	cJSON_AddNumberToObject(p_resp_item,"gridVoltTR",(module_info->grid_volt_tr)/10.0);
	cJSON_AddNumberToObject(p_resp_item,"gridFreq",(module_info->grid_freq)/100.0);
	cJSON_AddNumberToObject(p_resp_item,"nToPEVolt",(module_info->n_to_pe_volt)/10.0);
	cJSON_AddNumberToObject(p_resp_item,"acCurrentR",(module_info->ac_current_r)/10.0);
	cJSON_AddNumberToObject(p_resp_item,"acCurrentS",(module_info->ac_current_r)/10.0);
	cJSON_AddNumberToObject(p_resp_item,"acCurrentT",(module_info->ac_current_s)/10.0);
	cJSON_AddNumberToObject(p_resp_item,"dciR",(int32_t)module_info->dci_r);
	cJSON_AddNumberToObject(p_resp_item,"dciS",(int32_t)module_info->dci_s);
	cJSON_AddNumberToObject(p_resp_item,"dciT",(int32_t)module_info->dci_t);
	cJSON_AddNumberToObject(p_resp_item,"gfci",(int32_t)module_info->gfci);
	cJSON_AddNumberToObject(p_resp_item,"busVoltP",(module_info->bus_volt_p)/10.0);
	cJSON_AddNumberToObject(p_resp_item,"busVoltN",(module_info->bus_volt_n)/10.0);
	cJSON_AddNumberToObject(p_resp_item,"busVoltPN",(module_info->bus_volt_pn)/10.0);
	cJSON_AddNumberToObject(p_resp_item,"batVolt",(module_info->bat_volt)/10.0);
	cJSON_AddNumberToObject(p_resp_item,"batCurrent",module_info->bat_current/10.0);
	cJSON_AddNumberToObject(p_resp_item,"isoResistence",(int32_t)module_info->iso_resistence);
	cJSON_AddNumberToObject(p_resp_item,"isoDetState",(int32_t)module_info->iso_det_state);
	//cJSON_AddNumberToObject(p_resp_item,"isoDetUiso1",module_info->iso_det_uiso1);
	//cJSON_AddNumberToObject(p_resp_item,"isoDetUiso2",module_info->iso_det_uiso2);
	cJSON_AddNumberToObject(p_resp_item,"isoVoltToPE",(module_info->iso_volt_to_pe)/10.0);
	cJSON_AddNumberToObject(p_resp_item,"activePower",(module_info->active_power)/100.0);
	cJSON_AddNumberToObject(p_resp_item,"reactivePower",(module_info->reactive_power)/100.0);
	cJSON_AddNumberToObject(p_resp_item,"apparentPower",(module_info->apparent_power)/100.0);

	cJSON_AddNumberToObject(p_resp_item,"igbtTempRA",(module_info->igbt_temp_ra)/10.0);		
	cJSON_AddNumberToObject(p_resp_item,"igbtTempSA",(module_info->igbt_temp_sa)/10.0);
	cJSON_AddNumberToObject(p_resp_item,"igbtTempTA",(module_info->igbt_temp_ta)/10.0);
	cJSON_AddNumberToObject(p_resp_item,"igbtTempRB",(module_info->igbt_temp_rb)/10.0);		
	cJSON_AddNumberToObject(p_resp_item,"igbtTempSB",(module_info->igbt_temp_sb)/10.0);
	cJSON_AddNumberToObject(p_resp_item,"igbtTempTB",(module_info->igbt_temp_tb)/10.0);		
	//cJSON_AddNumberToObject(p_resp_item,"igbtTempAntiSc",(module_info->igbt_temp_anti_sc)/10.0);

	cJSON_AddNumberToObject(p_resp_item,"ambTemp",(module_info->amb_temp)/10.0);
	cJSON_AddNumberToObject(p_resp_item,"slvGridVoltR",(module_info->slv_grid_volt_r)/10.0);
	cJSON_AddNumberToObject(p_resp_item,"slvGridVoltS",(module_info->slv_grid_volt_s)/10.0);
	cJSON_AddNumberToObject(p_resp_item,"slvGridVoltT",(module_info->slv_grid_volt_t)/10.0);	

	//cJSON_AddNumberToObject(p_resp_item,"slvDciR",module_info->slv_dci_r);
	//cJSON_AddNumberToObject(p_resp_item,"slvDciS",module_info->slv_dci_s);
	//cJSON_AddNumberToObject(p_resp_item,"slvDciT",module_info->slv_dci_t);
	//cJSON_AddNumberToObject(p_resp_item,"slvGfci",module_info->slv_gfci);

	module_version_info = &pcs_telemetry_data->pcs_module_version_telemetry_info[index];
	len = 0;
	for (i = 0; i < SN_LEN; ++i)
	{
		len += sprintf(str+len,"%c",(module_version_info->sn[i] & 0x00FF));
		len += sprintf(str+len,"%c",((module_version_info->sn[i] >> 8)	& 0x00ff));
	}
	str[len]=0;
	cJSON_AddStringToObject(p_resp_item,"sn",str);
	
	len = 0;
	for (i = 0; i < FWV_LEN; ++i)
	{
		len += sprintf(str+len,"%c",module_version_info->fw_version[i]);
	
	}
	str[len]=0;
	cJSON_AddStringToObject(p_resp_item,"fwVersion",str);
	
	len = 0;
	for (i = 0; i < FWV_LEN; ++i)
	{
		len += sprintf(str+len,"%c",module_version_info->slv_fw_version[i]);
	
	}
	str[len]=0;
	cJSON_AddStringToObject(p_resp_item,"slvFwVersion",str);
	

	cJSON_AddItemToObject(p_resp_root,"data",p_resp_item);
	cJSON_AddStringToObject(p_resp_root,"msg","get successful");
	
	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);
	
}

/**
 * @brief PCS数据模块初始化
 * @return void
 */
void pcsinfo_data_module_init(void)
{
	/*获取PCS模块信息*/
	if(!web_func_attach("/PCSInfo/getPCSSimple", get_pcs_simple))
	{
		print_log("[/PCSInfo/getPCSSimple] attach failed");
	}
	/*获取PCS模块详细信息*/
	if(!web_func_attach("/pcsInfo/getPCSDetailede", get_pcs_detailede))
	{
		print_log("[/PCSInfo/getPCSDetailede] attach failed");
	}
}
