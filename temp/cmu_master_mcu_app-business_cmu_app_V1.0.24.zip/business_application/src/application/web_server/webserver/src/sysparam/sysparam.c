#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"cJSON.h"
#include"sysparam.h"
#include"common.h"
#include"data_shm.h"
#include"sdk_net_public.h"
#include"sdk_shm.h"
#include"sdk_para.h"
#include "web_broker.h"

#define FILE_SIZE_DEVICE_PARAM      1024            // 设备配置参数文件大小

void get_system_param(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_conf;
    cJSON *p_resp_root;
    cJSON *p_resp_item;
    uint8_t response[128];
    uint8_t *p_action;
    uint8_t *p_master_or_slave;
    uint8_t *p;
    uint8_t parallel_addr;

    uint8_t request_body[1024] = {0};
    uint8_t content[128] = {0};
    FILE *fp;

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"sysParamsGet"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

    fp = fopen(SYSPARAM_JSON_FILE,"r");
    if(fp == NULL)
    {
        print_log("open json file %s failed.",SYSPARAM_JSON_FILE);
        return;
    }
    fread(content,1,128,fp);
    fclose(fp);

    p_conf = cJSON_Parse(content);
    if(p_conf == NULL)
    {
        print_log("parse config file %s failed.",SYSPARAM_JSON_FILE);
        return;
    }

    p_master_or_slave = cJSON_GetObjectItem(p_conf,"masterorslave")->valuestring;
    parallel_addr = cJSON_GetObjectItem(p_conf,"paralleladdress")->valueint;

    p_resp_item = cJSON_CreateObject();
    if(p_resp_item == NULL)
    {
        print_log("create json obj failed.");
        cJSON_Delete(p_conf);
        return;
    }

    cJSON_AddStringToObject(p_resp_item,"masterOrSlave",p_master_or_slave);
    cJSON_AddNumberToObject(p_resp_item,"parallelAddress",parallel_addr);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
         print_log("create json obj failed.");
        cJSON_Delete(p_conf);
        cJSON_Delete(p_resp_item);
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddItemToObject(p_resp_root,"data",p_resp_item);
    cJSON_AddStringToObject(p_resp_root,"msg","get system params successful");
    cJSON_Delete(p_conf);

    p = cJSON_PrintUnformatted(p_resp_root);

    strcpy(response,p);
    cJSON_Delete(p_resp_root);

    http_back(p_nc,p);
    free(p);
}

void set_system_param(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_conf;
    cJSON *p_resp_root;
    uint8_t response[128];
    uint8_t *p_action;
    uint8_t *p_master_or_slave;
    uint8_t *p;
    uint16_t parallel_addr;
    uint8_t request_body[1024] = {0};
    uint8_t content[128] = {0};
    FILE *fp;
    operation_log_t op_log;
	uint8_t cur_user[32] = {0};

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
    {
        strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
    }
    else
    {
        memcpy(request_body,p_msg->body.p,p_msg->body.len);		
    }
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        print_log("parse request failed.");
        build_empty_response(response,202,"parse request failed.");
        http_back(p_nc,response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action,"sysParamSet"))
    {
        print_log("action is not right.");
        build_empty_response(response,203,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
    p_master_or_slave = cJSON_GetObjectItem(p_request,"masterOrSlave")->valuestring;
    parallel_addr = cJSON_GetObjectItem(p_request,"parallelAddress")->valueint;

    fp = fopen(SYSPARAM_JSON_FILE,"r");
    if(fp == NULL)
    {
        print_log("open json file %s failed.",SYSPARAM_JSON_FILE);
        return;
    }
    fread(content,1,128,fp);
    fclose(fp);

    p_conf = cJSON_Parse(content);
    if(p_conf == NULL)
    {
        print_log("parse json file %s failed.",SYSPARAM_JSON_FILE);
        cJSON_Delete(p_request);
        return;
    }
    cJSON_ReplaceItemInObject(p_conf,"masterorslave",cJSON_CreateString(p_master_or_slave));
    cJSON_ReplaceItemInObject(p_conf,"paralleladdress",cJSON_CreateNumber(parallel_addr));

    cJSON_Delete(p_request);

    p = cJSON_PrintUnformatted(p_conf);

    fp = fopen(SYSPARAM_JSON_FILE,"w");
    if(fp == NULL)
    {
        print_log("open json file %s failed.",SYSPARAM_JSON_FILE);
        cJSON_Delete(p_conf);
        return;
    }
    fwrite(p,1,strlen(p),fp);
    fclose(fp);

    cJSON_Delete(p_conf);
    free(p);

    init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"修改系统参数");
    strcpy(op_log.op_status,"success");
    op_log.op_param1 = parallel_addr;
    op_log.op_param2 = parallel_addr;
	add_one_op_log(&op_log);

    build_empty_response(response,200,"set system params successful");
    http_back(p_nc,response);
}

#include "json_utils.h"

void get_external_communication_protocol(struct mg_connection *p_nc,struct http_message *p_msg)
{
    uint8_t response[128];

    if ( false == json_utils_str_key_val_str_cmp( p_msg->body.p, "/action", "getExternalCommunicationProtocol" ))
    {
        build_empty_response(response,203, "get failed");
        http_back(p_nc,response);
        return;
    }
    
    cJSON *p_root_js = cJSON_CreateObject();
    if ( p_root_js == NULL )
    {
        build_empty_response(response,203, "get failed");
        http_back(p_nc,response);
        return;
    }
    
    cJSON_AddStringToObject(  p_root_js, "code", "200" );
    cJSON_AddStringToObject(  p_root_js, "msg", "get successful" );
    cJSON_AddNumberToObject(  p_root_js, "IEC104", sdk_shm_other_parameter_data_get()->iec104_upload_enable );
    cJSON_AddNumberToObject(  p_root_js, "MODBUS", 1 );
    
    char *p_reply_str = cJSON_PrintUnformatted(p_root_js);
    if ( p_reply_str == NULL )
    {
        build_empty_response(response,203, "get failed");
        http_back(p_nc,response);
        cJSON_Delete(p_root_js);
        return;
    }

    http_back( p_nc, p_reply_str);

    cJSON_Delete(p_root_js);
    free( p_reply_str );

    return;
}

void set_external_communication_protocol(struct mg_connection *p_nc,struct http_message *p_msg)
{
    uint8_t response[128];

    cJSON *p_req_root_js = cJSON_Parse( p_msg->body.p );
    if ( p_req_root_js == NULL )
    {
        build_empty_response(response,203, "set failed");
        http_back(p_nc,response);
        return;
    }

    if (   cJSON_GetObjectItem( p_req_root_js, "action" ) == NULL 
        || cJSON_GetObjectItem( p_req_root_js, "IEC104" ) == NULL 
    )
    {
        cJSON_Delete(p_req_root_js);
        build_empty_response(response,203, "set failed");
        http_back(p_nc,response);
        return;
    }

    if ( strcmp( cJSON_GetObjectItem( p_req_root_js, "action" )->valuestring, "setExternalCommunicationProtocol" ) != 0 )
    {
        cJSON_Delete(p_req_root_js);
        build_empty_response(response,203, "set failed");
        http_back(p_nc,response);
        return;
    }

    operation_log_t op_log;
	uint8_t cur_user[32] = {0};

    init_user_basic_info( &op_log);
	get_user_from_http_request(p_msg, cur_user);
	strcpy(op_log.user_name, cur_user);
    op_log.op_param1 = sdk_shm_other_parameter_data_get()->iec104_upload_enable;
    op_log.op_param2 = cJSON_GetObjectItem( p_req_root_js, "IEC104" )->valueint;
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"设置外部IEC104使能");
	strcpy(op_log.op_status,"success");
	add_one_op_log(&op_log);

    sdk_shm_other_parameter_data_get()->iec104_upload_enable = cJSON_GetObjectItem( p_req_root_js, "IEC104" )->valueint;
    sdk_shm_get()->web_control_info.external_protocol_set_flag = 1;

    build_empty_response( response, 200, "set successful" );
    http_back( p_nc, response);

    return;
}
 
/**
 * @brief    获取通信参数
 * @param	 [in]  
 * @param	 [in] 
 * @param	 [out]
 * @return
 */
void get_com_params(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_item;
    cJSON *p_resp_root;
    uint8_t response[256];  //
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t i;
    uint8_t request_body[1024] = {0};
	uint8_t sn[16] = {0};
	uint8_t str[32] = {0};
	int32_t array[8];
	uint8_t eth0_ip[32] = {0};
	uint8_t eth3_ip[32] = {0};
	other_parameter_data_t *other_parame = sdk_shm_other_parameter_data_get();

	
    if (p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if (p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"getComParam"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);


    p_resp_root = cJSON_CreateObject();
    if (p_resp_root == NULL)
    {
        print_log("create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",200);

    p_resp_item = cJSON_CreateObject();
    if (p_resp_item == NULL)
    {
    	cJSON_Delete(p_resp_root);
        print_log("create json obj failed.");
        return;
    }

	cJSON_AddNumberToObject(p_resp_item,"addressRS485_4",other_parame->address_rs485_4);
	cJSON_AddNumberToObject(p_resp_item,"baudRateRS485_4",other_parame->baud_rate_rs485_4);
	cJSON_AddNumberToObject(p_resp_item,"stopBitRS485_4",other_parame->stop_bit_rs485_4);
	cJSON_AddNumberToObject(p_resp_item,"checkBitRS485_4",other_parame->check_bit_rs485_4);
	
	cJSON_AddNumberToObject(p_resp_item,"addressRS485_6",other_parame->address_rs485_6);
	cJSON_AddNumberToObject(p_resp_item,"baudRateRS485_6",other_parame->baud_rate_rs485_6);
	cJSON_AddNumberToObject(p_resp_item,"stopBitRS485_6",other_parame->stop_bit_rs485_6);
	cJSON_AddNumberToObject(p_resp_item,"checkBitRS485_6",other_parame->check_bit_rs485_6);

	//使用ETH1口的通讯数据
	if(sdk_net_ip_get(ETH0, eth0_ip) < 0)
    {
        strncpy((char *)eth0_ip, "0.0.0.0", strlen("0.0.0.0"));
    }
	cJSON_AddStringToObject(p_resp_item,"IPETH1",eth0_ip);
	/*
	for (i = 0; i < 16; ++i)
	{
		str[i] = other_parame->IP_ETH_1[i];	
	}
	str[i-1]=0;
	cJSON_AddStringToObject(p_resp_item,"IPETH1",str);
	cJSON_AddNumberToObject(p_resp_item,"portETH1",other_parame->port_ETH_1);
	*/
	// for (i = 0; i < 16; ++i)
	// {
	// 	str[i] =  other_parame->IP_server_ETH_1_104[i];

	// }
	// str[i-1]=0;
	// cJSON_AddStringToObject(p_resp_item,"IEC104IPServerETH1",str);
	// cJSON_AddNumberToObject(p_resp_item,"IEC104PortServerETH1",other_parame->port_server_ETH_1_104);
	// for (i = 0; i < 16; ++i)
	// {
	// 	str[i] =  other_parame->IP_server_ETH_1_61850[i];

	// }
	// str[i-1]=0;
	// cJSON_AddStringToObject(p_resp_item,"IEC61850IPServerETH1",str);
	// cJSON_AddNumberToObject(p_resp_item,"IEC61850PortServerETH1",other_parame->port_server_ETH_1_61850);


	//使用ETH2口的通讯数据
	// for (i = 0; i < 16; ++i)
	// {
	// 	str[i] = other_parame->IP_ETH_2[i];
	// }
	// str[i-1]=0;
	// cJSON_AddStringToObject(p_resp_item,"IPETH2",str);
	// //cJSON_AddNumberToObject(p_resp_item,"portETH2",other_parame->port_ETH_2);
	// for (i = 0; i < 16; ++i)
	// {
	// 	str[i] =  other_parame->IP_server_ETH_2_104[i];
	// 	//printf("%d = %c \n", i,str[i]);

	// }
	// str[i-1]=0;
	// cJSON_AddStringToObject(p_resp_item,"IEC104IPServerETH2",str);
	// cJSON_AddNumberToObject(p_resp_item,"IEC104PortServerETH2",other_parame->port_server_ETH_2_104);
	// for (i = 0; i < 16; ++i)
	// {
	// 	str[i] =  other_parame->IP_server_ETH_2_61850[i];

	// }
	// str[i-1]=0;
	// cJSON_AddStringToObject(p_resp_item,"IEC61850IPServerETH2",str);
	// cJSON_AddNumberToObject(p_resp_item,"IEC61850PortServerETH2",other_parame->port_server_ETH_2_61850);

	//使用ETH3口的通讯数据
	if(sdk_net_ip_get(ETH1, eth3_ip) < 0)
    {
        strncpy((char *)eth3_ip, "0.0.0.0", strlen("0.0.0.0"));
    }
	cJSON_AddStringToObject(p_resp_item,"IPETH3",eth3_ip);	
	/*
	for (i = 0; i < 16; ++i)
	{
		str[i] = other_parame->IP_ETH_3[i];
		
	}
	str[i-1]=0;
	cJSON_AddStringToObject(p_resp_item,"IPETH3",str);
	*/
	// cJSON_AddNumberToObject(p_resp_item,"portETH3",other_parame->port_ETH_3);
	// for (i = 0; i < 16; ++i)
	// {
	// 	str[i] =  other_parame->IP_server_ETH_3[i];

	// }
	// str[i-1]=0;
	// cJSON_AddStringToObject(p_resp_item,"IPServerETH3",str);
	// cJSON_AddNumberToObject(p_resp_item,"portServerETH3",other_parame->port_server_ETH_3);
	// cJSON_AddNumberToObject(p_resp_item,"ETH3mode",other_parame->ETH3mode);
	
	cJSON_AddItemToObject(p_resp_root,"data",p_resp_item); 
    cJSON_AddStringToObject(p_resp_root,"msg","get successful");
	
    p = cJSON_PrintUnformatted(p_resp_root);
    http_back(p_nc,p);
	cJSON_Delete(p_resp_root);
	free(p);
	
}

/**
 * @brief    设置通信参数
 * @param	 [in]  
 * @param	 [in] 
 * @param	 [out]
 * @return
 */
void set_com_params(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_data;	
    cJSON *p_resp_item;
    cJSON *p_resp_root;
    uint8_t response[1024];  //
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t i;
	uint8_t flag;
	uint8_t *p_str = NULL;
	uint8_t ip_addr[NET_ADDR_LEN_MAX];
	uint32_t ip_len;
	uint16_t len;
	uint16_t result;
	uint8_t ret;
    uint8_t request_body[1024] = {0};
	uint32_t value_int = 0;
	operation_log_t op_log;
	uint8_t cur_user[32] = {0};	
	other_parameter_data_t other_parameter_data;
	other_parameter_data_t *p_other_parameter_data = sdk_shm_other_parameter_data_get();
	web_control_info_t *sdk_shm_web_data = shm_web_control_info_get();
	
    if (p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if (p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	if ((NULL == cJSON_GetObjectItem(p_request,"action")) || (NULL == cJSON_GetObjectItem(p_request,"data")))
	{
		print_log("parameter is not right.");
		build_empty_response(response,203,"parameter is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}	
	
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"setComParam"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	p_data = cJSON_GetObjectItem(p_request,"data");

#if 1	
	if((NULL != cJSON_GetObjectItem(p_data,"addressRS485_4")) && ( NULL != cJSON_GetObjectItem(p_data,"baudRateRS485_4")) && ( NULL !=  cJSON_GetObjectItem(p_data,"stopBitRS485_4")) && ( NULL != cJSON_GetObjectItem(p_data,"checkBitRS485_4")))
	{
		flag = 0;
		value_int = cJSON_GetObjectItem(p_data,"addressRS485_4")->valueint;
		if (p_other_parameter_data->address_rs485_4 != value_int)
		{
			sdk_shm_web_data->other_parameter_data_update.address_rs485_4 = value_int;
			flag = 1;
		}
		value_int = cJSON_GetObjectItem(p_data,"baudRateRS485_4")->valueint;
		if (p_other_parameter_data->baud_rate_rs485_4 != value_int)
		{
			sdk_shm_web_data->other_parameter_data_update.baud_rate_rs485_4 = value_int;
			flag = 1;
		}		
		value_int = cJSON_GetObjectItem(p_data,"stopBitRS485_4")->valueint;
		if (p_other_parameter_data->stop_bit_rs485_4 != value_int)
		{
			sdk_shm_web_data->other_parameter_data_update.stop_bit_rs485_4 = value_int;
			flag = 1;
		}
		value_int = cJSON_GetObjectItem(p_data,"checkBitRS485_4")->valueint;
		if (p_other_parameter_data->check_bit_rs485_4 != value_int)
		{
			sdk_shm_web_data->other_parameter_data_update.check_bit_rs485_4 = value_int;
			flag = 1;
		}		

		if (flag = 1)
		{
			sdk_shm_web_data->other_parameter_update_flag[0] = 1;
		}
	}

	if((NULL != cJSON_GetObjectItem(p_data,"addressRS485_6")) && ( NULL != cJSON_GetObjectItem(p_data,"baudRateRS485_6")) && ( NULL !=  cJSON_GetObjectItem(p_data,"stopBitRS485_6")) && ( NULL != cJSON_GetObjectItem(p_data,"checkBitRS485_6")))
	{
		flag = 0;
		value_int = cJSON_GetObjectItem(p_data,"addressRS485_6")->valueint;
		if (p_other_parameter_data->address_rs485_6 != value_int)
		{
			flag = 1;
		}
		sdk_shm_web_data->other_parameter_data_update.address_rs485_6 = value_int;
		
		value_int = cJSON_GetObjectItem(p_data,"baudRateRS485_6")->valueint;
		if (p_other_parameter_data->baud_rate_rs485_6 != value_int)
		{
			flag = 1;
		}
		sdk_shm_web_data->other_parameter_data_update.baud_rate_rs485_6 = value_int;
		
		value_int = cJSON_GetObjectItem(p_data,"stopBitRS485_6")->valueint;
		if (p_other_parameter_data->stop_bit_rs485_4 != value_int)
		{
			flag = 1;
		}
		sdk_shm_web_data->other_parameter_data_update.stop_bit_rs485_4 = value_int;
		
		value_int = cJSON_GetObjectItem(p_data,"checkBitRS485_6")->valueint;
		if (p_other_parameter_data->check_bit_rs485_4 != value_int)
		{
			flag = 1;
		}		
		sdk_shm_web_data->other_parameter_data_update.check_bit_rs485_4= value_int;
		
		if (flag = 1)
		{
			sdk_shm_web_data->other_parameter_update_flag[0] = 1;
		}
	}


	if((NULL != cJSON_GetObjectItem(p_data,"IPETH1")) && ( NULL !=  cJSON_GetObjectItem(p_data,"IEC104IPServerETH1")) && ( NULL != cJSON_GetObjectItem(p_data,"IEC61850IPServerETH1")))
	{
		flag = 0;
		
		p_str = cJSON_GetObjectItem(p_data,"IPETH1")->valuestring;
		if (memcmp(p_str, &p_other_parameter_data->addr_IP_ETH_1, NET_ADDR_LEN_MAX))
		{
			flag = 1;
		}
		snprintf((char*)sdk_shm_web_data->other_parameter_data_update.addr_IP_ETH_1,NET_ADDR_LEN_MAX,"%s",p_str);
		
		p_str = cJSON_GetObjectItem(p_data,"IEC104IPServerETH1")->valuestring;
		if (memcmp(p_str, &p_other_parameter_data->addr_IP_server_ETH_1, NET_ADDR_LEN_MAX))
		{
			flag = 1;	
		}
		snprintf((char*)sdk_shm_web_data->other_parameter_data_update.addr_IP_server_ETH_1, NET_ADDR_LEN_MAX, "%s", p_str);
		
		value_int = cJSON_GetObjectItem(p_data,"IEC104PortServerETH1")->valueint;
		if (p_other_parameter_data->numr_port_server_ETH_1 != value_int)
		{
			flag = 1;
		}
		sdk_shm_web_data->other_parameter_data_update.numr_port_server_ETH_1 = value_int;

		// p_str = cJSON_GetObjectItem(p_data,"IEC61850IPServerETH1")->valuestring;
		// if (memcmp(p_str, &p_other_parameter_data->IP_server_ETH_1_61850, NET_ADDR_LEN_MAX))
		// {
		// 	flag = 1;	
		// }
		// snprintf((char*)sdk_shm_web_data->other_parameter_data_update.IP_server_ETH_1_61850, NET_ADDR_LEN_MAX, "%s", p_str);
		
		// value_int = cJSON_GetObjectItem(p_data,"IEC61850PortServerETH1")->valueint;
		// if (p_other_parameter_data->port_server_ETH_1_61850 != value_int)
		// {
		// 	flag = 1;
			
		// }	
		// sdk_shm_web_data->other_parameter_data_update.port_server_ETH_1_61850 = value_int;

		// if (flag = 1)
		// {
		// 	sdk_shm_web_data->other_parameter_update_flag[2] = 1;
		// }		
	}

	if((NULL != cJSON_GetObjectItem(p_data,"IPETH2")) && ( NULL !=  cJSON_GetObjectItem(p_data,"IEC104IPServerETH2")) && ( NULL != cJSON_GetObjectItem(p_data,"IEC61850IPServerETH2")))
	{
		flag = 0;
		/*
		p_str = cJSON_GetObjectItem(p_data,"IPETH2")->valuestring;
		if (memcmp(p_str, &p_other_parameter_data->IP_ETH_2, NET_ADDR_LEN_MAX))
		{
			flag = 1;
		}
		snprintf(sdk_shm_web_data->other_parameter_data_update.IP_ETH_2,NET_ADDR_LEN_MAX,"%s",p_str);
		*/
		// p_str = cJSON_GetObjectItem(p_data,"IEC104IPServerETH2")->valuestring;
		// if (memcmp(p_str, &p_other_parameter_data->IP_server_ETH_2_104, NET_ADDR_LEN_MAX))
		// {
		// 	flag = 1;	
		// }
		// snprintf(sdk_shm_web_data->other_parameter_data_update.IP_server_ETH_2_104, NET_ADDR_LEN_MAX, "%s", p_str);
		
		// value_int = cJSON_GetObjectItem(p_data,"IEC104PortServerETH2")->valueint;
		// if (p_other_parameter_data->port_server_ETH_2_104 != value_int)
		// {
		// 	flag = 1;
		// }
		// sdk_shm_web_data->other_parameter_data_update.port_server_ETH_2_104 = value_int;

		// p_str = cJSON_GetObjectItem(p_data,"IEC61850IPServerETH2")->valuestring;
		// if (memcmp(p_str, &p_other_parameter_data->IP_server_ETH_2_61850, NET_ADDR_LEN_MAX))
		// {
		// 	flag = 1;	
		// }
		// snprintf(sdk_shm_web_data->other_parameter_data_update.IP_server_ETH_2_61850, NET_ADDR_LEN_MAX, "%s", p_str);
		
		// value_int = cJSON_GetObjectItem(p_data,"IEC61850PortServerETH2")->valueint;
		// if (p_other_parameter_data->port_server_ETH_2_61850 != value_int)
		// {
		// 	flag = 1;
			
		// }	
		// sdk_shm_web_data->other_parameter_data_update.port_server_ETH_2_61850 = value_int;

		// if (flag = 1)
		// {
		// 	sdk_shm_web_data->other_parameter_update_flag[3] = 1;
		// }		
	}

	
	if((NULL != cJSON_GetObjectItem(p_data,"addrIPETH3")) && ( NULL != cJSON_GetObjectItem(p_data,"portETH3")) && ( NULL !=  cJSON_GetObjectItem(p_data,"addrIPServerETH3")) && ( NULL != cJSON_GetObjectItem(p_data,"portServerETH3")))
	{
		
		// flag = 0;
		// p_str = cJSON_GetObjectItem(p_data,"addrIPETH3")->valuestring;
		// if (memcmp(p_str, &p_other_parameter_data->addr_IP_ETH_3, NET_ADDR_LEN_MAX))
		// {
		// 	flag = 1;
		// }
		// snprintf(sdk_shm_web_data->other_parameter_data_update.addr_IP_ETH_3,NET_ADDR_LEN_MAX,"%s",p_str);
		
		// value_int = cJSON_GetObjectItem(p_data,"portETH3")->valueint;
		// if (p_other_parameter_data->num_port_ETH_3 != value_int)
		// {
		// 	flag = 1;
		// }
		// sdk_shm_web_data->other_parameter_data_update.port_ETH_3 = value_int;
	
		// p_str = cJSON_GetObjectItem(p_data,"addrIPServerETH3")->valuestring;
		// if (memcmp(p_str, &p_other_parameter_data->IP_server_ETH_3 , NET_ADDR_LEN_MAX))
		// {
		// 	memcpy(&sdk_shm_web_data->other_parameter_data_update.IP_server_ETH_3, p_str , NET_ADDR_LEN_MAX);
		// 	flag = 1;
		// }
		// snprintf(sdk_shm_web_data->other_parameter_data_update.IP_server_ETH_3,NET_ADDR_LEN_MAX,"%s",p_str);
		
		// value_int = cJSON_GetObjectItem(p_data,"portServerETH3")->valueint;
		// if (p_other_parameter_data->port_server_ETH_3 != value_int)
		// {
		// 	flag = 1;
		// }	
		// sdk_shm_web_data->other_parameter_data_update.port_server_ETH_3 = value_int;

		// if (flag = 1)
		// {
		// 	sdk_shm_web_data->other_parameter_update_flag[4] = 1;
		// }		
	}

#else
	if((NULL != cJSON_GetObjectItem(p_data,"addressRS485_4")) && ( NULL != cJSON_GetObjectItem(p_data,"baudRateRS485_4")) && ( NULL !=  cJSON_GetObjectItem(p_data,"stopBitRS485_4")) && ( NULL != cJSON_GetObjectItem(p_data,"checkBitRS485_4")))
	{
		flag = 0;
		value_int = cJSON_GetObjectItem(p_data,"addressRS485_4")->valueint;
		if (p_other_parameter_data->address_rs485_4 != value_int)
		{
			p_other_parameter_data->address_rs485_4 = value_int;
		}
		value_int = cJSON_GetObjectItem(p_data,"baudRateRS485_4")->valueint;
		if (p_other_parameter_data->baud_rate_rs485_4 != value_int)
		{
			p_other_parameter_data->baud_rate_rs485_4 = value_int;
		}		
		value_int = cJSON_GetObjectItem(p_data,"stopBitRS485_4")->valueint;
		if (p_other_parameter_data->stop_bit_rs485_4 != value_int)
		{
			p_other_parameter_data->stop_bit_rs485_4 = value_int;
		}
		value_int = cJSON_GetObjectItem(p_data,"checkBitRS485_4")->valueint;
		if (p_other_parameter_data->check_bit_rs485_4 != value_int)
		{
			p_other_parameter_data->check_bit_rs485_4 = value_int;
		}		

	}

	if((NULL != cJSON_GetObjectItem(p_data,"addressRS485_6")) && ( NULL != cJSON_GetObjectItem(p_data,"baudRateRS485_6")) && ( NULL !=  cJSON_GetObjectItem(p_data,"stopBitRS485_6")) && ( NULL != cJSON_GetObjectItem(p_data,"checkBitRS485_6")))
	{
		flag = 0;
		value_int = cJSON_GetObjectItem(p_data,"addressRS485_6")->valueint;
		if (p_other_parameter_data->address_rs485_6 != value_int)
		{
			p_other_parameter_data->address_rs485_6 = value_int;
		}
		value_int = cJSON_GetObjectItem(p_data,"baudRateRS485_6")->valueint;
		if (p_other_parameter_data->baud_rate_rs485_6 != value_int)
		{
			p_other_parameter_data->baud_rate_rs485_6 = value_int;
		}		
		value_int = cJSON_GetObjectItem(p_data,"stopBitRS485_6")->valueint;
		if (p_other_parameter_data->stop_bit_rs485_6 != value_int)
		{
			p_other_parameter_data->stop_bit_rs485_6 = value_int;
		}
		value_int = cJSON_GetObjectItem(p_data,"checkBitRS485_6")->valueint;
		if (p_other_parameter_data->check_bit_rs485_6 != value_int)
		{
			p_other_parameter_data->check_bit_rs485_6 = value_int;
		}		

	}


	if((NULL != cJSON_GetObjectItem(p_data,"IPETH1")) && ( NULL !=  cJSON_GetObjectItem(p_data,"IEC104IPServerETH1")) && ( NULL != cJSON_GetObjectItem(p_data,"IEC61850IPServerETH1")))
	{
		/*
		p_str = cJSON_GetObjectItem(p_data,"IPETH1")->valuestring;
		if (memcmp(p_str, &p_other_parameter_data->IP_ETH_1, NET_ADDR_LEN_MAX))
		{
			snprintf(p_other_parameter_data->IP_ETH_1, NET_ADDR_LEN_MAX, "%s", p_str);
		}
		
		value_int = cJSON_GetObjectItem(p_data,"PortETH1")->valueint;
		if (p_other_parameter_data->port_ETH_1 != value_int)
		{
			p_other_parameter_data->port_ETH_1 = value_int;
		}	
		*/
		p_str = cJSON_GetObjectItem(p_data,"IEC104IPServerETH1")->valuestring;
		if (memcmp(p_str, &p_other_parameter_data->IP_server_ETH_1_104, NET_ADDR_LEN_MAX))
		{
			snprintf(p_other_parameter_data->IP_server_ETH_1_104, NET_ADDR_LEN_MAX, "%s", p_str);	
		}
		value_int = cJSON_GetObjectItem(p_data,"IEC104PortServerETH1")->valueint;
		if (p_other_parameter_data->port_server_ETH_1_104 != value_int)
		{
			p_other_parameter_data->port_server_ETH_1_104 = value_int;
		}	

		p_str = cJSON_GetObjectItem(p_data,"IEC61850IPServerETH1")->valuestring;
		if (memcmp(p_str, &p_other_parameter_data->IP_server_ETH_1_61850, NET_ADDR_LEN_MAX))
		{
			snprintf(p_other_parameter_data->IP_server_ETH_1_61850, NET_ADDR_LEN_MAX, "%s", p_str);	
		}
		value_int = cJSON_GetObjectItem(p_data,"IEC61850PortServerETH1")->valueint;
		if (p_other_parameter_data->port_server_ETH_1_61850 != value_int)
		{
			p_other_parameter_data->port_server_ETH_1_61850 = value_int;
		}			
	}
	
	if((NULL != cJSON_GetObjectItem(p_data,"IPETH2")) && ( NULL !=  cJSON_GetObjectItem(p_data,"IEC104IPServerETH2")) && ( NULL != cJSON_GetObjectItem(p_data,"IEC61850IPServerETH2")))
	{
		/*
		p_str = cJSON_GetObjectItem(p_data,"IPETH2")->valuestring;
		if (memcmp(p_str, &p_other_parameter_data->IP_ETH_1, NET_ADDR_LEN_MAX))
		{
			snprintf(p_other_parameter_data->IP_ETH_1, NET_ADDR_LEN_MAX, "%s", p_str);
		}
		
		value_int = cJSON_GetObjectItem(p_data,"PortETH2")->valueint;
		if (p_other_parameter_data->port_ETH_2 != value_int)
		{
			p_other_parameter_data->port_ETH_2 = value_int;
		}	*/

		p_str = cJSON_GetObjectItem(p_data,"IEC104IPServerETH2")->valuestring;
		if (memcmp(p_str, &p_other_parameter_data->IP_server_ETH_1_104, NET_ADDR_LEN_MAX))
		{
			snprintf(p_other_parameter_data->IP_server_ETH_1_104, NET_ADDR_LEN_MAX, "%s", p_str);	
		}
		value_int = cJSON_GetObjectItem(p_data,"IEC104PortServerETH2")->valueint;
		if (p_other_parameter_data->port_server_ETH_1_104 != value_int)
		{
			p_other_parameter_data->port_server_ETH_1_104 = value_int;
		}	

		p_str = cJSON_GetObjectItem(p_data,"IEC61850IPServerETH2")->valuestring;
		if (memcmp(p_str, &p_other_parameter_data->IP_server_ETH_1_61850, NET_ADDR_LEN_MAX))
		{
			snprintf(p_other_parameter_data->IP_server_ETH_1_61850, NET_ADDR_LEN_MAX, "%s", p_str);	
		}
		value_int = cJSON_GetObjectItem(p_data,"IEC61850PortServerETH2")->valueint;
		if (p_other_parameter_data->port_server_ETH_1_61850 != value_int)
		{
			p_other_parameter_data->port_server_ETH_1_61850 = value_int;
		}
		
	}


	if((NULL != cJSON_GetObjectItem(p_data,"IPETH3")) && ( NULL != cJSON_GetObjectItem(p_data,"portETH3")) && ( NULL !=  cJSON_GetObjectItem(p_data,"IPServerETH3")) && ( NULL != cJSON_GetObjectItem(p_data,"portServerETH3")) && (NULL != cJSON_GetObjectItem(p_data,"ETH3mode")))
	{
		
		p_str = cJSON_GetObjectItem(p_data,"IPETH3")->valuestring;
		if (memcmp(p_str, &p_other_parameter_data->IP_ETH_3 , NET_ADDR_LEN_MAX))
		{
			snprintf(p_other_parameter_data->IP_ETH_3, NET_ADDR_LEN_MAX, "%s", p_str);

		}
		value_int = cJSON_GetObjectItem(p_data,"portETH3")->valueint;
		if (p_other_parameter_data->port_ETH_3 != value_int)
		{
			p_other_parameter_data->port_ETH_3 = value_int;
			//print_log("p_other_parameter_data->num_port_ETH_3 %d ",p_other_parameter_data->num_port_ETH_3);
		}	

		p_str = cJSON_GetObjectItem(p_data,"IPServerETH3")->valuestring;
		if (memcmp(p_str, &p_other_parameter_data->IP_server_ETH_3 , NET_ADDR_LEN_MAX))
		{
			snprintf(p_other_parameter_data->IP_server_ETH_3, NET_ADDR_LEN_MAX, "%s", p_str);
			//print_log("p_other_parameter_data->addr_IP_server_ETH_3 %s ",p_other_parameter_data->addr_IP_server_ETH_3);
		}
		value_int = cJSON_GetObjectItem(p_data,"portServerETH3")->valueint;
		if (p_other_parameter_data->port_server_ETH_3 != value_int)
		{
			p_other_parameter_data->port_server_ETH_3 = value_int;
			
		}	
		value_int = cJSON_GetObjectItem(p_data,"ETH3mode")->valueint;
		if (p_other_parameter_data->ETH3mode != value_int)
		{
			p_other_parameter_data->ETH3mode = value_int;

		}	
		
	}	
#endif

   cJSON_Delete(p_request);

	ret = sdk_para_init(FILE_TYPE_DEVICE_PARAM, FILE_SIZE_DEVICE_PARAM);
	
    len = sizeof(device_paramater_other_t);
    result = sdk_para_write(FILE_TYPE_DEVICE_PARAM, 2, (uint8_t *)&p_other_parameter_data->address_rs485_4, len);
	
    if (result == len)
    {
        ret = sdk_para_sync(FILE_TYPE_DEVICE_PARAM);
        print_log((int8_t *)"\n [ok] device param file sdk_para_sync \n"); // 测试用
    }
    else
    {
        ret = -1;
    }
	usleep(1000 * 100);
	
    result = sdk_para_write(FILE_TYPE_DEVICE_PARAM, 2, (uint8_t *)&p_other_parameter_data->address_rs485_4, len);
	
    if (result == len)
    {
    	print_log((int8_t *)"\n IP_ETH_1 %s \n",p_other_parameter_data->addr_IP_ETH_1); // 测试用
        ret = sdk_para_sync(FILE_TYPE_DEVICE_PARAM);
        print_log((int8_t *)"\n [ok] device param file sdk_para_sync \n"); // 测试用
    }
    else
    {
        ret = -1;
    }
	
	init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"修改通讯参数");
	strcpy(op_log.op_status,"success");
	add_one_op_log(&op_log);
	 
    p_resp_root = cJSON_CreateObject();
    if (p_resp_root == NULL)
    {
        print_log("create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddStringToObject(p_resp_root,"msg","set successful");
	
    p = cJSON_PrintUnformatted(p_resp_root);
    http_back(p_nc,p);
	free(p);
	cJSON_Delete(p_resp_root);
}

/**
 * @brief 系统参数模块初始化
 * @return void
 */
void web_sys_param_module_init(void)
{
	/*获取通信参数*/
	if(!web_func_attach("/paramsInfo/getComParam", get_com_params))
	{
		print_log("[/paramsInfo/getComParam] attach failed");
	}
	/*设置通信参数*/
	if(!web_func_attach("/paramsInfo/setComParam", set_com_params))
	{
		print_log("[/paramsInfo/setComParam] attach failed");
	}  
	/*获取系统参数*/
	if(!web_func_attach("/system/sysParamsGet", get_system_param))
	{
		print_log("[/system/sysParamsGet] attach failed");
	}
	/*设置系统参数*/
	if(!web_func_attach("/system/sysParamSet", set_system_param))
	{
		print_log("[/system/sysParamSet] attach failed");
	} 

	/* 获取对外通讯协议参数 */
	if(!web_func_attach("/system/getExternalCommunicationProtocol", get_external_communication_protocol ))
	{
		print_log("[/system/getExternalCommunicationProtocol] attach failed");
	} 
	/* 获取对外通讯协议参数 */
	if(!web_func_attach("/system/setExternalCommunicationProtocol", set_external_communication_protocol ))
	{
		print_log("[/system/setExternalCommunicationProtocol] attach failed");
	} 

}