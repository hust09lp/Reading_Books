#include "csu_data_info.h"
#include "cJSON.h"
#include "sdk_shm.h"
#include "web_broker.h"
#include "common.h"

#include <stdio.h>

void post_csu_data_info(struct mg_connection *p_nc,struct http_message *p_msg)
{
    char csu_post_str[200] = {0};
    char reply_str[100] = {0};
    int32_t ret_code = 200;
    internal_shared_data_t *p_internal_data = NULL;

    p_internal_data = internal_shared_data_get();
    if(p_internal_data == NULL)
    {
        return;
    }
    memcpy(csu_post_str, p_msg->body.p, p_msg->body.len);		

    cJSON *p_root_js = NULL;
    p_root_js = cJSON_Parse( csu_post_str );
    if ( p_root_js == NULL )
    {
        ret_code = 201;
        goto __exit;
    }

    cJSON *p_pcs_js = cJSON_GetObjectItem( p_root_js, "PCS" );
    if ( p_pcs_js == NULL )
    {
        ret_code = 202;
        goto __exit;
    }
    if(p_internal_data == NULL)
    {
        ret_code = 203;
        goto __exit;
    }
    else
    {
        p_internal_data->csu_dat_info.pcs.active_power = (int16_t)cJSON_GetObjectItem( p_pcs_js, "activePower" )->valuedouble * 10;
        p_internal_data->csu_dat_info.sleep_mode_disable = cJSON_GetObjectItem( p_root_js, "sleepDisable" )->valuedouble;
    }
    

__exit:

    if( p_root_js != NULL )
    {
        cJSON_Delete( p_root_js );
    }
    if ( ret_code != 200 )
    {
        printf("[%s]error code:%d\r\n", __FUNCTION__, ret_code);
    }

    build_empty_response( reply_str, ret_code, (ret_code == 200)? "parse sucessful" : "parse fail" );
    http_back( p_nc, reply_str );

    return;
}

void csu_data_info_module_init(void)
{
	if(!web_func_attach("/postCsuDataInfo", post_csu_data_info))
	{
		print_log("[/postCsuDataInfo] attach failed");
	}
}
