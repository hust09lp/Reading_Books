/** 
 * @file          fault_text.c
 * @brief         故障文本接口函数功能实现
 * @author        liangguyao
 * @version       V0.0.1     初始版本
 * @date          2023/05/18
 * @copyright     Copyright (c) 2023 by SofarSolar, All Rights Reserved.
 */


#include "fault_text.h"
#include "sofar_errors.h"
#include"cJSON.h"
#include"common.h"
#include <string.h>


#define CMU_FAULT_NUM               (0x30)      // CMU系统故障数量
#define CONTAINER_FAULT_NUM         (0x90)      // 集装箱系统故障数量
#define BATTERY_CLUSTER_FAULT_NUM   (0x50)      // 电池簇故障数量
#define PCS_FAULT_NUM               (0xFF)      // PCS故障数量


// CMU系统故障显示 (0x01 ~ 0x30)
const int8_t *p_cmu_fault_text[CMU_FAULT_NUM] = \
{
    "USB故障",
    "SD卡故障",
    "RTC时钟故障",
    "SPI通信故障",
    "SCI通信故障",
    "BCU通讯失联",
    "协议版本不一致",
    "文件设备参数与实际不一致",
    "CMU-MCU1 APP升级失败",
    "CMU-MCU1 CORE升级失败",
    "CMU-MCU2 APP升级失败",
    "CMU-MCU2 CORE升级失败",
    "CSU通信故障",
    "预留",
    "预留",
    "预留",
    "动环系统不稳定",
    "PCS通信失联",
    "CSU系统故障",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留"
};

// CMU系统故障显示 (0x01 ~ 0x30)
const int8_t *p_cmu_fault_text_en[CMU_FAULT_NUM] = \
{
    "USB fault",
    "SD card fault",
    "RTC clock fault",
    "SPI communication fault",
    "SCI communication fault",
    "BCU communication fault",
    "Inconsistent protocol versions",
    "Inconsistency between file device parameters and actual",
    "CMU-MCU1 APP Upgrade failed",
    "CMU-MCU1 CORE Upgrade failed",
    "CMU-MCU2 APP Upgrade failed",
    "CMU-MCU2 CORE Upgrade failed ",
    "CSU communication fault",
    "Reserve",
    "Reserve",
    "Reserve",
    "Unstable liquid cooling system",
    "PCS communication fault",
    "CSU system fault",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve"
};

const int8_t *p_cmu_reason_fault_text[CMU_FAULT_NUM] = \
{
    "无法识别USB",
    "无法识别SD卡",
    "RTC工作异常",
    "对端无应答",
    "对端无应答",
    "BCU和CMU之间通讯失联",
    "当前版本不是最新版本",
    "设备参数与软件参数不匹配",
    "升级文件损坏或SCI通信故障",
    "升级文件损坏或SCI通信故障",
    "升级文件损坏或SCI通信故障",
    "升级文件损坏或SCI通信故障",
    "CSU和CMU通信失联",
    "预留",
    "预留",
    "预留",
    "1小时内多次出现动环故障",
    "MCU1和PCS通信失联",
    "CSU出现严重故障",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留"
};

const int8_t *p_cmu_reason_fault_text_en[CMU_FAULT_NUM] = \
{
    "USB cannot be recognized",
    "SD card cannot be recognized",
    "the RTC is abnormal",
    "the peer end has no response",
    "the peer end has no response",
    "communication between BCU and CMU has been lost",
    "the current version is not the latest version",
    "device parameters do not match software parameters",
    "the upgrade file is damaged or the SCI communication is faulty",
    "the upgrade file is damaged or the SCI communication is faulty",
    "the upgrade file is damaged or the SCI communication is faulty",
    "the upgrade file is damaged or the SCI communication is faulty",
    "CSU is disconnect from CMU",
    "Reserve",
    "Reserve",
    "Reserve",
    "cooling system failure occurred multiple times within 1 hour",
    "the communication between MCU1 and PCS is disconnected",
    "CSU has a serious failure",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve"
};

const int8_t *p_cmu_restore_fault_text[CMU_FAULT_NUM] = \
{
    "更换CMU模块重新测试",
    "更换CMU模块重新测试",
    "检查RTC时钟硬件",
    "1等待2分钟观察故障是否消失 2检查硬件 3请联系技术支持",
    "1等待2分钟观察故障是否消失 2检查硬件 3请联系技术支持",
    "1检查BCU连接是否正常 2请联系技术支持",
    "升级到最新版本",
    "请联系技术支持",
    "检查升级文件",
    "检查升级文件",
    "检查升级文件",
    "检查升级文件",
    "预留",
    "预留",
    "预留",
    "预留",
    "根据历史故障定位频繁故障的设备，根据设备所报的故障联系售后人员",
    "1等待2分钟观察故障是否消失 2检查硬件 3请联系技术支持",
    "1检查CSU汇流柜是否出现严重故障 2请联系技术支持",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留"
};

const int8_t *p_cmu_restore_fault_text_en[CMU_FAULT_NUM] = \
{
    "change the CMU module and test again",
    "change the CMU module and test again",
    "check the RTC clock hardware",
    "1wait for 2 minutes and check whether the fault is rectified 2check hardware 3contact technical support",
    "1wait for 2 minutes and check whether the fault is rectified 2check hardware 3contact technical support",
    "1check whether the BCU connection is normal 2contact technical support",
    "upgrade to the latest version",
    "contact technical support",
    "check for upgrade file",
    "check for upgrade file",
    "check for upgrade file",
    "check for upgrade file",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "locate frequently faulty devices based on historical faults, and contact after-sales personnel based on reported faults",
    "1wait for 2 minutes and check whether the fault is rectified 2check hardware 3contact technical support",
    "1check whether the CSU bus cabinet is seriously faulty 2contact technical support",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve"
};

// 集装箱系统故障显示 (0x101 ~ 0x190)
const int8_t *p_container_fault_text[CONTAINER_FAULT_NUM] = \
{
    "紧急停机",
    "电池簇上电失败外部告警",
    "防雷故障",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "水浸故障",
    "门磁故障",
    "电池舱1 IO采集板通讯失联",
    "电池舱2 IO采集板通讯失联",
    "电池舱3 IO采集板通讯失联",
    "电池舱4 IO采集板通讯失联",
    "电池舱5 IO采集板通讯失联",
    "电池舱6 IO采集板通讯失联",
    "CAN通讯失联",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "液冷error0",
    "液冷error1",
    "液冷error2",
    "液冷error3",
    "液冷error4",
    "液冷error5",
    "液冷error6",
    "液冷error7",
    "液冷error8",
    "液冷error9",
    "液冷error10",
    "液冷error11",
    "液冷error12",
    "液冷error13",
    "液冷error14",
    "液冷error15",
    "液冷error16",
    "液冷error17",
    "液冷error18",
    "液冷error19",
    "液冷error20",
    "液冷error21",
    "液冷error22",
    "液冷error23",
    "液冷error24",
    "液冷error25",
    "液冷error26",
    "液冷error27",
    "液冷error28",
    "液冷error29",
    "液冷error30",
    "液冷error31",
    "液冷error32",
    "液冷error33",
    "液冷error34",
    "液冷error35",
    "液冷error36",
    "液冷error37",
    "液冷error38",
    "液冷error39",
    "液冷error40",
    "液冷error41",
    "液冷error42",
    "液冷error43",
    "液冷error44",
    "液冷error45",
    "液冷error46",
    "液冷error47",
    "液冷error48",
    "液冷error49",
    "液冷error50",
    "液冷error51",
    "液冷error52",
    "液冷error53",
    "液冷error54",
    "液冷error55",
    "液冷error56",
    "液冷error57",
    "液冷error58",
    "液冷error59",
    "液冷error60",
    "液冷error61",
    "液冷error62",
    "液冷error63",
    "灭火剂启动报警",
    "簇1温度报警标志",
    "簇2温度报警标志",
    "簇3温度报警标志",
    "簇4温度报警标志",
    "簇5温度报警标志",
    "簇6温度报警标志",
    "PACK温度+1#CO报警",
    "PACK温度+2#CO报警",
    "PACK温度+3#CO报警",
    "PACK温度+4#CO报警",
    "PACK温度+5#CO报警",
    "PACK温度+6#CO报警",
    "1#烟感+温感报警",
    "2#烟感+温感报警",
    "3#烟感+温感报警",
    "4#烟感+温感报警",
    "5#烟感+温感报警",
    "6#烟感+温感报警",
    "烟感+1#复合型传感器温度",
    "烟感+2#复合型传感器温度",
    "烟感+3#复合型传感器温度",
    "烟感+4#复合型传感器温度",
    "烟感+5#复合型传感器温度",
    "烟感+6#复合型传感器温度",
    "温感+复合型传感器1#CO",
    "温感+复合型传感器2#CO",
    "温感+复合型传感器3#CO",
    "温感+复合型传感器4#CO",
    "温感+复合型传感器5#CO",
    "温感+复合型传感器6#CO",
    "CMU启动消防",
    "系统存在消防隐患",
    "消防控制器通讯失联告警",
    "1#消防IO采集板通讯失联告警",
    "2#消防IO采集板通讯失联告警",
    "3#消防IO采集板通讯失联告警",
    "4#消防IO采集板通讯失联告警",
    "5#消防IO采集板通讯失联告警",
    "6#消防IO采集板通讯失联告警",
    "PCS故障",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
};

const int8_t *p_container_fault_text_en[CONTAINER_FAULT_NUM] = \
{
    "EPO(emergency stop)",
    "battery cluster power-on failure external alarm",
    "SPD(Surge Protective Device) signal",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Water immersion fault ",
    "Door magnetic fault",
    "battery compartment 1 communication with the I/O acquisition board fails",
    "battery compartment 2 communication with the I/O acquisition board fails",
    "battery compartment 3 communication with the I/O acquisition board fails",
    "battery compartment 4 communication with the I/O acquisition board fails",
    "battery compartment 5 communication with the I/O acquisition board fails",
    "battery compartment 6 communication with the I/O acquisition board fails",
    "CAN communication is lost",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "liquid cooling error0",
    "liquid cooling error1",
    "liquid cooling error2",
    "liquid cooling error3",
    "liquid cooling error4",
    "liquid cooling error5",
    "liquid cooling error6",
    "liquid cooling error7",
    "liquid cooling error8",
    "liquid cooling error9",
    "liquid cooling error10",
    "liquid cooling error11",
    "liquid cooling error12",
    "liquid cooling error13",
    "liquid cooling error14",
    "liquid cooling error15",
    "liquid cooling error16",
    "liquid cooling error17",
    "liquid cooling error18",
    "liquid cooling error19",
    "liquid cooling error20",
    "liquid cooling error21",
    "liquid cooling error22",
    "liquid cooling error23",
    "liquid cooling error24",
    "liquid cooling error25",
    "liquid cooling error26",
    "liquid cooling error27",
    "liquid cooling error28",
    "liquid cooling error29",
    "liquid cooling error30",
    "liquid cooling error31",
    "liquid cooling error32",
    "liquid cooling error33",
    "liquid cooling error34",
    "liquid cooling error35",
    "liquid cooling error36",
    "liquid cooling error37",
    "liquid cooling error38",
    "liquid cooling error39",
    "liquid cooling error40",
    "liquid cooling error41",
    "liquid cooling error42",
    "liquid cooling error43",
    "liquid cooling error44",
    "liquid cooling error45",
    "liquid cooling error46",
    "liquid cooling error47",
    "liquid cooling error48",
    "liquid cooling error49",
    "liquid cooling error50",
    "liquid cooling error51",
    "liquid cooling error52",
    "liquid cooling error53",
    "liquid cooling error54",
    "liquid cooling error55",
    "liquid cooling error56",
    "liquid cooling error57",
    "liquid cooling error58",
    "liquid cooling error59",
    "liquid cooling error60",
    "liquid cooling error61",
    "liquid cooling error62",
    "liquid cooling error63",
    "Fire extinguishing agent activation sign",
    "cluster 1 temperature alarm sign",
    "cluster 2 temperature alarm sign",
    "cluster 3 temperature alarm sign",
    "cluster 4 temperature alarm sign",
    "cluster 5 temperature alarm sign",
    "cluster 6 temperature alarm sign",
    "PACK temperature +1#CO alarm",
    "PACK temperature +2#CO alarm",
    "PACK temperature +3#CO alarm",
    "PACK temperature +4#CO alarm",
    "PACK temperature +5#CO alarm",
    "PACK temperature +6#CO alarm",
    "1# Smoke Detector + Temperature sensor alarm ",
    "2# Smoke Detector + Temperature sensor alarm ",
    "3# Smoke Detector + Temperature sensor alarm ",
    "4# Smoke Detector + Temperature sensor alarm ",
    "5# Smoke Detector + Temperature sensor alarm ",
    "6# Smoke Detector + Temperature sensor alarm ",
    "Smoke Detector+1#Composite sensor:Temperature",
    "Smoke Detector+2#Composite sensor:Temperature",
    "Smoke Detector+3#Composite sensor:Temperature",
    "Smoke Detector+4#Composite sensor:Temperature",
    "Smoke Detector+5#Composite sensor:Temperature",
    "Smoke Detector+6#Composite sensor:Temperature",
    "Temperature sensor+1#Composite sensor:CO",
    "Temperature sensor+2#Composite sensor:CO",
    "Temperature sensor+3#Composite sensor:CO",
    "Temperature sensor+4#Composite sensor:CO",
    "Temperature sensor+5#Composite sensor:CO",
    "Temperature sensor+6#Composite sensor:CO",
    "CMU starts fire protection",
    "Fire hazards in the system",
    "Fire controller communication failure alarm",
    "1# Fire I/O acquisition board communication loss alarm",
    "2# Fire I/O acquisition board communication loss alarm",
    "3# Fire I/O acquisition board communication loss alarm",
    "4# Fire I/O acquisition board communication loss alarm",
    "5# Fire I/O acquisition board communication loss alarm",
    "6# Fire I/O acquisition board communication loss alarm",
    "PCS fault",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
};

const int8_t *p_container_reason_fault_text[CONTAINER_FAULT_NUM] = \
{
    "外部紧急停机按钮被按下",
    "执行电池簇上电不成功",
    "辅电触发防雷信号",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "水浸传感器浸水",
    "储能柜对应的舱门被打开",
    "IO拓展板通讯异常 ",
    "IO拓展板通讯异常",
    "IO拓展板通讯异常",
    "IO拓展板通讯异常",
    "IO拓展板通讯异常",
    "IO拓展板通讯异常",
    "CAN通讯异常",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "查询故障代码",
    "发生消防二级报警",
    "电池簇1温度超温",
    "电池簇2温度超温",
    "电池簇3温度超温",
    "电池簇4温度超温",
    "电池簇5温度超温",
    "电池簇6温度超温",
    "电池温度过高，并检测出可燃气体",
    "电池温度过高，并检测出可燃气体",
    "电池温度过高，并检测出可燃气体",
    "电池温度过高，并检测出可燃气体",
    "电池温度过高，并检测出可燃气体",
    "电池温度过高，并检测出可燃气体",
    "电池舱内烟感和温感同时触发",
    "电池舱内烟感和温感同时触发",
    "电池舱内烟感和温感同时触发",
    "电池舱内烟感和温感同时触发",
    "电池舱内烟感和温感同时触发",
    "电池舱内烟感和温感同时触发",
    "电池舱烟感被触发，并检测到舱内温度过高",
    "电池舱烟感被触发，并检测到舱内温度过高",
    "电池舱烟感被触发，并检测到舱内温度过高",
    "电池舱烟感被触发，并检测到舱内温度过高",
    "电池舱烟感被触发，并检测到舱内温度过高",
    "电池舱烟感被触发，并检测到舱内温度过高",
    "电池舱温感被触发，并检测到可燃气体",
    "电池舱温感被触发，并检测到可燃气体",
    "电池舱温感被触发，并检测到可燃气体",
    "电池舱温感被触发，并检测到可燃气体",
    "电池舱温感被触发，并检测到可燃气体",
    "电池舱温感被触发，并检测到可燃气体",
    "CMU主动启动消防",
    "",
    "消防控制器与CMU之间通讯异常",
    "消防控制器与IO采集板之间通讯异常",
    "消防控制器与IO采集板之间通讯异常",
    "消防控制器与IO采集板之间通讯异常",
    "消防控制器与IO采集板之间通讯异常",
    "消防控制器与IO采集板之间通讯异常",
    "消防控制器与IO采集板之间通讯异常",
    "PCS模块异常",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
};

const int8_t *p_container_reason_fault_text_en[CONTAINER_FAULT_NUM] = \
{
    "The external emergency stop button is pressed",
    "Failed to power on the battery cluster",
    "Auxiliary power triggers the lightning protection signal",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "The water sensor is flooded",
    "The corresponding hatch door of the storage cabinet is opened",
    "The communication with the I/O expansion board is abnormal ",
    "The communication with the I/O expansion board is abnormal",
    "The communication with the I/O expansion board is abnormal",
    "The communication with the I/O expansion board is abnormal",
    "The communication with the I/O expansion board is abnormal",
    "The communication with the I/O expansion board is abnormal",
    "CAN communication exception",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Query fault code",
    "Battery cluster 1 overheats",
    "Battery cluster 2 overheats",
    "Battery cluster 3 overheats",
    "Battery cluster 4 overheats",
    "Battery cluster 5 overheats",
    "Battery cluster 6 overheats",
    "The battery temperature is too high and combustible gas is detected",
    "The battery temperature is too high and combustible gas is detected",
    "The battery temperature is too high and combustible gas is detected",
    "The battery temperature is too high and combustible gas is detected",
    "The battery temperature is too high and combustible gas is detected",
    "The battery temperature is too high and combustible gas is detected",
    "Smoke and temperature in the battery compartment trigger simultaneously",
    "Smoke and temperature in the battery compartment trigger simultaneously",
    "Smoke and temperature in the battery compartment trigger simultaneously",
    "Smoke and temperature in the battery compartment trigger simultaneously",
    "Smoke and temperature in the battery compartment trigger simultaneously",
    "Smoke and temperature in the battery compartment trigger simultaneously",
    "Battery compartment smoke is triggered and the cabin temperature is detected",
    "Battery compartment smoke is triggered and the cabin temperature is detected",
    "Battery compartment smoke is triggered and the cabin temperature is detected",
    "Battery compartment smoke is triggered and the cabin temperature is detected",
    "Battery compartment smoke is triggered and the cabin temperature is detected",
    "Battery compartment smoke is triggered and the cabin temperature is detected",
    "The battery compartment temperature is triggered and combustible gas is detected",
    "The battery compartment temperature is triggered and combustible gas is detected",
    "The battery compartment temperature is triggered and combustible gas is detected",
    "The battery compartment temperature is triggered and combustible gas is detected",
    "The battery compartment temperature is triggered and combustible gas is detected",
    "The battery compartment temperature is triggered and combustible gas is detected",
    "CMU initiates fire fighting actively",
    "The system has fire hazards",
    "The communication between the fire controller and the CMU is abnormal",
    "The communication between the fire control controller and the I/O acquisition board is abnormal",
    "The communication between the fire control controller and the I/O acquisition board is abnormal",
    "The communication between the fire control controller and the I/O acquisition board is abnormal",
    "The communication between the fire control controller and the I/O acquisition board is abnormal",
    "The communication between the fire control controller and the I/O acquisition board is abnormal",
    "The communication between the fire control controller and the I/O acquisition board is abnormal",
    "PCS module exception",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
};

const int8_t *p_container_restore_fault_text[CONTAINER_FAULT_NUM] = \
{
    "确认系统故障解除后恢复",
    "在WEB页面上查看系统是否提示已存在严重故障/告警,导致上电不成功",
    "打开储能柜，检查辅电进线的防雷装置",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "检查对应的水浸开关是否进水",
    "将储能柜的舱门关紧",
    "1.IO板接线不牢或是接错线;2.IO拓展板地址是否已经设置;3.通讯口损坏",
    "1.IO板接线不牢或是接错线;2.IO拓展板地址是否已经设置;3.通讯口损坏",
    "1.IO板接线不牢或是接错线;2.IO拓展板地址是否已经设置;3.通讯口损坏",
    "1.IO板接线不牢或是接错线;2.IO拓展板地址是否已经设置;3.通讯口损坏",
    "1.IO板接线不牢或是接错线;2.IO拓展板地址是否已经设置;3.通讯口损坏",
    "1.IO板接线不牢或是接错线;2.IO拓展板地址是否已经设置;3.通讯口损坏",
    "联系技术支持",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "排查现场是否有火警，确认无火警，复位消防控制器",
    "CMU主动启动消防",
    "联系技术支持",
    "消防控制器与CMU之间RS485接线不牢,或是接错线通讯口损坏",
    "消防控制器与CMU之间RS485接线不牢,或是接错线通讯口损坏",
    "消防控制器与CMU之间RS485接线不牢,或是接错线通讯口损坏",
    "消防控制器与CMU之间RS485接线不牢,或是接错线通讯口损坏",
    "消防控制器与CMU之间RS485接线不牢,或是接错线通讯口损坏",
    "消防控制器与CMU之间RS485接线不牢,或是接错线通讯口损坏",
    "消防控制器与CMU之间RS485接线不牢,或是接错线通讯口损坏",
    "联系技术支持",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
};

const int8_t *p_container_restore_fault_text_en[CONTAINER_FAULT_NUM] = \
{
    "Ensure that the system fault is rectified and then recover",
    "On the WEB page, check whether a major fault or alarm is displayed, resulting in a power-on failure",
    "Open the energy storage cabinet and check the lightning protection device of the auxiliary power supply cable",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Check whether water enters the water switch",
    "Close the door of the storage cabinet tightly",
    "1.The I/O board is improperly connected or improperly connected;2.I/O expansion board address has been set;3.Communication port damage",
    "1.The I/O board is improperly connected or improperly connected;2.I/O expansion board address has been set;3.Communication port damage",
    "1.The I/O board is improperly connected or improperly connected;2.I/O expansion board address has been set;3.Communication port damage",
    "1.The I/O board is improperly connected or improperly connected;2.I/O expansion board address has been set;3.Communication port damage",
    "1.The I/O board is improperly connected or improperly connected;2.I/O expansion board address has been set;3.Communication port damage",
    "1.The I/O board is improperly connected or improperly connected;2.I/O expansion board address has been set;3.Communication port damage",
    "Contact Technical Support",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "Check whether there is a fire alarm at the scene, confirm that there is no fire alarm, and reset the fire controller",
    "CMU initiates fire fighting actively",
    "Contact Technical Support",
    "The RS485 cable between the fire controller and the CMU is improperly connected, or the communication port is damaged",
    "The RS485 cable between the fire controller and the CMU is improperly connected, or the communication port is damaged",
    "The RS485 cable between the fire controller and the CMU is improperly connected, or the communication port is damaged",
    "The RS485 cable between the fire controller and the CMU is improperly connected, or the communication port is damaged",
    "The RS485 cable between the fire controller and the CMU is improperly connected, or the communication port is damaged",
    "The RS485 cable between the fire controller and the CMU is improperly connected, or the communication port is damaged",
    "The RS485 cable between the fire controller and the CMU is improperly connected, or the communication port is damaged",
    "Contact Technical Support",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
};

// 电池簇故障显示
// 0x201 ~ 0x250、0x301 ~ 0x350、0x401 ~ 0x450、0x501 ~ 0x550、0x601 ~ 0x650
// 0x701 ~ 0x750
const int8_t *p_cluster_fault_text[BATTERY_CLUSTER_FAULT_NUM] = \
{
    "DI1检测故障",
    "DI2检测故障",
    "DI3检测故障",
    "DI4检测故障",
    "DI5检测故障",
    "DI6检测故障",
    "DI7检测故障",
    "DI8检测故障",
    "内网通讯故障",
    "单体电压采集故障",
    "单体温度采集故障",
    "显控下发故障",
    "簇间压差故障",
    "跳机故障",
    "从控DI/DO检测故障",
    "电池极限故障",
    "程序和参数不一致故障",
    "PCS通讯故障",
    "PC强控调试模式",
    "CAN霍尔传感器故障",
    "CAN霍尔传感器通讯故障",
    "硬件自检异常",
    "极柱温度采集故障",
    "均衡故障",
    "预留",
    "预留",
    "预留",
    "预充时报",
    "脱扣前关闭风扇",
    "DBC使能已开启",
    "正常下电失败",
    "接收到所有簇故障下电",
    "BCU严重故障状态",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留"
};

const int8_t *p_cluster_fault_text_en[BATTERY_CLUSTER_FAULT_NUM] = \
{
    "DI1 detected fault",
    "DI2 detected fault",
    "DI3 detected fault",
    "DI4 detected fault",
    "DI5 detected fault",
    "DI6 detected fault",
    "DI7 detected fault",
    "DI8 detected fault",
    "Internal network communication failure",
    "Batt Cell Voltage collection fault",
    "Batt Cell Temperature collection fault",
    "Display and control issue fault",
    "Cluster Voltage difference fault",
    "Battery Trip fault",
    "Slave control DI/DO detection fault",
    "Battery limit fault",
    "Inconsistent program and parameter fault",
    "PCS communication fault",
    "PC Force debugging mode",
    "CAN Current Hall sensor fault",
    "CAN Current Hall sensor communication fault",
    "Hardware self-test abnormality",
    "Batt Pole temperature acquisition fault",
    "Batt Balanced fault",
    "Reserve",
    "Reserve",
    "Reserve",
    "Batt Pre-charge report",
    "Turn off the fan before tripping",
    "DBC Enabling enabled",
    "Normal power-off failure",
    "Received all cluster failures and powered off",
    "BCU Severe fault status",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve"
};

const int8_t *p_cluster_reason_fault_text[BATTERY_CLUSTER_FAULT_NUM] = \
{
    "主正接触器状态反馈输入故障",
    "黑启动开关状态反馈输入故障",
    "主正接触器状态反馈输入故障",
    "高压箱紧急停机故障",
    "高压箱接受到上层监控模块停机信号",
    "高压箱断路器状态反馈输入故障",
    "BCU模块的DI7输入硬件故障",
    "BCU模块的DI8输入硬件故障",
    "BMU和BCU之间CAN通讯故障",
    "PACK内单体电压采样电路故障",
    "PACK内单体温度采样电路故障",
    "BMS模块接收到显控下发的故障指令",
    "上电过程中如果电池簇间的电压过高，系统无法上电并机，报该故障",
    "发生故障导致跳机",
    "BMU模块的IO口故障",
    "电池单体运行到了极限电压、温度工况",
    "程序运行参数和配置的参数不一致",
    "与外部PCS通讯失联",
    "进入了BMS的调试模式",
    "霍尔传感器故障",
    "霍尔传感器的通讯失联",
    "BMS硬件自检发生异常,可能有部分硬件存在故障",
    "PACK端子温度采样电路异常",
    "BMS系统均衡电路异常",
    "预留",
    "预留",
    "预留",
    "启动上电过程中预充时间过长",
    "",
    "使能了测试工况下的DBC文件",
    "上位机或CMU发送正常下电命令,但此时簇级电流过大,无法下电成功",
    "上位机或CMU发送故障下电命令,之后系统无法主动恢复",
    "BCU模块本身发生故障",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留"
};

const int8_t *p_cluster_reason_fault_text_en[BATTERY_CLUSTER_FAULT_NUM] = \
{
    "The main positive contactor status feedback input is faulty",
    "The black switch status feedback input is faulty",
    "The main positive contactor status feedback input is faulty",
    "High pressure tank emergency shutdown fault",
    "The high pressure box receives the stop signal from the upper monitoring module",
    "The high pressure box circuit breaker status feedback input is faulty",
    "The DI7 input hardware of the BCU module is faulty",
    "The DI8 input hardware of the BCU module is faulty",
    "The CAN communication between the BMU and BCU is faulty",
    "The single voltage sampling circuit in PACK is faulty",
    "The temperature sampling circuit in PACK is faulty",
    "The BMS module received the fault command from the display and control module",
    "This fault is reported if the battery cluster voltage is too high and the system cannot be powered on",
    "A fault occurred and the battery Trip",
    "The I/O port on the BMU is faulty",
    "The battery unit runs at the limit voltage and temperature",
    "The program running parameters are inconsistent with the configured parameters",
    "The external PCS communication is disconnected",
    "The debugging mode of the BMS is entered",
    "Hall sensor fault",
    "Communication on Hall sensors is down",
    "BMS hardware self-test is abnormal, some hardware may be faulty",
    "The PACK terminal temperature sampling circuit is abnormal",
    "The balancing circuit of the BMS system is abnormal",
    "Reserve",
    "Reserve",
    "Reserve",
    "The precharge time during startup and power-on is too long",
    "",
    "The DBC file in the test condition was enabled",
    "The host computer or CMU sends a normal power-off command, but the cluster current is too large",
    "The host computer or CMU sends a fault power-off command, after which the system cannot actively recover",
    "The BCU module is faulty",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve"
};

const int8_t *p_cluster_restore_fault_text[BATTERY_CLUSTER_FAULT_NUM] = \
{
    "检查信号接线和高压箱内主正接触器状态，如接触器损坏则需要更换",
    "检查信号接线和黑启动开关状态,在正常并网工况，黑启动开关应处于断开状态,如该开关损坏则需要更换",
    "检查信号接线和高压箱内主负接触器状态，如接触器损坏则需要更换",
    "排查系统是否按下了紧急停机按钮，再排查紧急情况的具体故障",
    "查看历史数据和实时告警，排查上层监控的具体故障原因",
    "排查信号接线回路，并检查断路器是否为断开状态，在正常运行时该断路器应为闭合状态，如断路器损坏则需要更换",
    "系统未用到该输入IO,如出线那该故障排查系统信号接线和BCU模块状态,如BCU损坏则需进行更换",
    "系统未用到该输入IO,如出线那该故障排查系统信号接线和BCU模块状态,如BCU损坏则需进行更换",
    "检查PACK与PACK之间,PACK与高压箱之间的通讯线",
    "1、检查PACK内部的FPC和FPC与BMU连接的采样线缆;2、更换BMU模块;",
    "1、检查PACK内部的FPC和FPC与BMU连接的采样线缆;2、更换BMU模块;",
    "通过查看历史记录或实时告警定位具体故障原因进行排查",
    "检查电池簇间的SOC情况和压差情况,如果确实压差过大，需要对单簇进行补电",
    "该故障仅仅表示系统因故障跳机，通过查看历史记录或实时告警定位具体故障原因进行排查",
    "更换BMU模块测试",
    "定位异常电芯,检查该电芯的温度和电压检测情况,联系售后人员对PACK进行更换和修复",
    "请联系技术支持",
    "检查通讯线缆",
    "该模式只有运维人员才有权限进入,只在调试阶段使用,进入该模式后需要系统掉电才能退出",
    "更换霍尔传感器重新测试",
    "检查霍尔传感器与BCU之间的通讯",
    "检查定位发生故障的BMS模块,排查模块的接线是否正常,如无接线异常,联系售后人员进行更换",
    "检查端子温度采样线束和NTC",
    "1、查看PACK内电芯的差异情况;2、更换明显异常的PACK的BMU模块重新测试",
    "预留",
    "预留",
    "预留",
    "检查电池簇之间的压差，检查预充过程中预充电阻上的压降",
    "目前本系统BCU未接风扇",
    "查看现在是否是测试工况",
    "先关闭外部PCS,保证电流为0后断开某一簇的高压箱,保证系统全部下电,再检查BESS与PCS之间的通讯链路是否正常",
    "检查是否有其他故障同时发生的故障,再通过CAN盒发送复位命令让系统复位",
    "换BCU模块重新测试",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留",
    "预留"
};

const int8_t *p_cluster_restore_fault_text_en[BATTERY_CLUSTER_FAULT_NUM] = \
{
    "Check signal wiring and the status of the main positive contactor in the high pressure box. If the contactor is damaged, it needs to be replaced",
    "Check the signal wiring and the status of the black start switch. In normal grid-connected conditions, the black start switch should be in the disconnected state. If the switch is damaged, it needs to be replaced",
    "Check signal wiring and the status of the main negative contactor in the high pressure box. If the contactor is damaged, it needs to be replaced",
    "Check whether the system has pressed the emergency stop button, and then check the specific fault of the emergency",
    "View historical data and real-time alarms to locate specific causes of upper-layer monitoring faults",
    "Check the signal wiring circuit and check whether the circuit breaker is off. During normal operation, the circuit breaker should be closed. If the circuit breaker is damaged, it needs to be replaced",
    "If the input I/O is not used in the system, check the system signal cable and BCU module status. If the BCU is damaged, replace it",
    "If the input I/O is not used in the system, check the system signal cable and BCU module status. If the BCU is damaged, replace it",
    "Check the communication lines between PACK and PACK and between PACK and high pressure box",
    "1、Check the FPC inside the PACK and the sampling cable connecting the FPC to the BMU;2、Replace the BMU;",
    "1、Check the FPC inside the PACK and the sampling cable connecting the FPC to the BMU;2、Replace the BMU;",
    "Locate and rectify faults by viewing historical records or real-time alarms",
    "Check the SOC and pressure difference between the battery clusters. If the pressure difference is too large, it is necessary to recharge the single cluster",
    "The fault indicates that the system hops due to a fault. You can locate the fault by viewing historical records or real-time alarms",
    "Test to replace the BMU module",
    "Locate the abnormal battery cell, check the temperature and voltage detection of the battery cell, and contact the after-sales personnel to replace and repair the PACK",
    "Contact Technical Support",
    "Checking Communication cables",
    "Only operation and maintenance personnel have permission to enter this mode. This mode is used only during the debugging phase. After entering this mode, you need to power off the system to exit",
    "Replace the Hall sensor and retest",
    "Check communication between Hall sensor and BCU",
    "Locate the faulty BMS module and check whether cables to the module are properly connected. If no cables are connected properly, contact after-sales personnel to replace the faulty BMS module",
    "Check the terminal temperature sampling harness and NTC",
    "1、View the differences in the cells in the PACK;2、Replace the BMU module of the apparently abnormal PACK and test it again",
    "Reserve",
    "Reserve",
    "Reserve",
    "Check the pressure difference between the battery clusters and check the pressure drop on the precharge resistance during the precharge process",
    "Currently, no fan is connected to the BCU",
    "Check to see if this is a test condition",
    "Turn off the external PCS first, ensure that the current is 0, disconnect a cluster of high pressure boxes, ensure that the system is powered off, and then check whether the communication link between BESS and PCS is normal",
    "Check whether other faults occur at the same time, and then send the reset command through the CAN box to reset the system",
    "Replace the BCU module and test again",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve"
};

// PCS功率模块故障显示
// 0x801 ~ 0x8C8
const int8_t *p_pcs_fault_text[PCS_FAULT_NUM] = \
{
    "电网过压",                 // fault1
    "电网欠压",
    "电网过频",
    "电网欠频",
    "漏电流故障",
    "高穿错误",
    "低穿错误",
    "孤岛错误",
    "电网瞬时值过压1",
    "电网瞬时值过压2",
    "电网线电压错误",
    "保留",
    "保留",
    "电网电压不平衡",
    "保留",
    "保留",                       
    "电网电流采样错误",           // fault2
    "电网电流直流分量采样错误",
    "保留",
    "电网电压采样错误（交流侧）",
    "保留",
    "漏电流采样错误（交流侧）",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "电网电压一致性错误",
    "保留",
    "保留",                     
    "保留",                     // fault3
    "保留",
    "保留",
    "保留",
    "辅助电源错误",
    "逆变软启动失败",
    "保留",
    "保留",
    "交流继电器检测失败",
    "绝缘阻抗低",
    "软硬件不匹配",
    "保留",
    "保留",
    "输入反接错误",
    "保留",
    "保留",
    "保留",                       // fault4
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "模块温差过大",
    "环境温度1保护",
    "保留",
    "模块1温度保护",
    "模块2温度保护",
    "模块3温度保护",
    "模块4温度保护",
    "模块5温度保护",
    "模块6温度保护",
    "母线电压有效值不平衡",           // fault5
    "保留",
    "并网过程母线欠压",
    "保留",
    "保留",
    "电池过压",
    "保留",
    "逆变母线电压有效值软件过压",
    "逆变母线电压瞬时值软件过压",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",                       // fault6
    "Dci过流保护",
    "输出瞬时电流保护",
    "保留",
    "输出有效值电流保护",
    "保留",
    "保留",
    "输出电流不平衡",
    "保留",
    "平衡电路过流保护",
    "谐振保护",
    "软件逐波限流保护",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",                     // fault7
    "逆变母线硬件过压",
    "保留",
    "电池硬件过流",
    "保留",
    "保留",
    "交流输出硬件过流",
    "保留",
    "保留",
    "保留",
    "硬件版本不匹配",
    "保留",
    "保留",
    "过载保护1",
    "保留",
    "保留",
    "保留",                   // fault8
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",                   // fault9
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "电网相序错误",             // fault10
    "相线对地故障",
    "功率端子温度保护",
    "防短路设备错误",
    "直流继电器错误",
    "模块7温度保护",
    "模块温度低保护",
    "交流反启超时",
    "过调制",
    "设备ID不匹配",
    "主DSP通讯故障(内部CAN)",
    "载波同步信号故障",
    "保留",
    "主副DSP软件版本不匹配",
    "BMS故障",
    "保留",
    "保留",                   // fault11
    "保留",
    "保留",
    "保留",
    "EPO故障",
    "保留",
    "保留",
    "保留",
    "内部风扇1故障",
    "内部风扇2故障",
    "外部风扇1故障",
    "外部风扇2故障",
    "外部风扇3故障",
    "外部风扇4故障",
    "保留",
    "保留",
    "ISO告警提示",            // warning
    "辅源告警",
    "DC防雷告警",
    "AC防雷告警",
    "直流电压输入欠压",
    "直流电压输入过压",
    "保留",
    "保留",
    "IGBT温度告警",
    "直流继电器反馈",
    "内部风扇告警",
    "外部风扇告警",
    "BMS告警",
    "功率端子温度告警",
    "载波同步告警",
    "保留",
    "保留",                 // status6
    "过温降载",
    "母线过压降载",
    "保留",
    "保留",
    "DRMs降载",
    "保留",
    "保留",
    "电网过欠压安规降载(安规的电网过欠压)",
    "保留",
    "保留",
    "保留",
    "母线欠压降载",
    "过欠频率降载",
    "母线压差降载",
    "风扇降额提示",           
    "硬件采样偏置错误",         // fault12
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "主DSP通讯故障(外部CAN)",         // fault13
    "副DSP通信故障(SCI)",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留"
};

const int8_t *p_pcs_fault_text_en[PCS_FAULT_NUM] = \
{
    "Grid overvoltage",
    "Grid Under voltage",
    "Grid Overfrequency",
    "Grid underfrequency",
    "Leakage current fault",
    "OVRT fault",
    "LVRT fault",
    "Island error",
    "Grid Instantaneous value 1 overvoltage",
    "Grid Instantaneous value 2 overvoltage",
    "Grid Line voltage error",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Grid current sampling error",
    "Grid current DCI sampling error",
    "Reserve",
    "Grid Voltage sampling error (AC side)",
    "Reserve",
    "Leakage current sampling error (AC side)",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Grid voltage consistency error",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Auxiliary power supply error",
    "Inverter soft start failure",
    "Reserve",
    "Reserve",
    "AC relay detection failed",
    "Low insulation impedance ",
    "Reserve",
    "Reserve",
    "Reserve",
    "Input reverse connection error",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Module temperature difference suprathreshold",
    "Environmental temperature 1 protection",
    "Reserve",
    "Module 1 Temperature Protection",
    "Module 2 Temperature Protection",
    "Module 3 Temperature Protection",
    "Module 4 Temperature Protection",
    "Module 5 Temperature Protection",
    "Module 6 Temperature Protection",
    "Unbalanced effective value of bus voltage",
    "Reserve",
    "Under voltage of the busbar during grid connection",
    "Reserve",
    "Reserve",
    "Battery overvoltage",
    "Reserve",
    "Inverter bus software overvoltage ",
    "Inverter bus software under voltage",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "DCI Overcurrent protection",
    "Output instantaneous current protection",
    "Reserve",
    "Output effective value current protection",
    "Reserve",
    "Reserve",
    "Output current imbalance",
    "Reserve",
    "Reserve",
    "Reserve",
    "Software wave by wave current limiting protection",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Inverter bus hardware overvoltage",
    "Reserve",
    "Battery hardware overcurrent",
    "Reserve",
    "Reserve",
    "AC output hardware overcurrent",
    "Reserve",
    "Reserve",
    "Reserve",
    "Hardware version mismatch",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Grid phase sequence error ",
    "Phase to ground fault",
    "Short circuit protection",
    "Short-circuit protection equipment fault",
    "DC relay error",
    "Short-circuit protection equipment temperature fault",
    "Temperature module temperature low protection",
    "Communication reverse start timeout",
    "Overmodulation",
    "Device ID mismatch",
    "Main DSP communication fault (Inner CAN)",
    "Carrier synchronization signal fault",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Internal fan fault",
    "External fan fault",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "ISO Alarm prompt",
    "Auxiliary source alarm ",
    "DC SPD alarm ",
    "AC SPD alarm",
    "DC voltage input undervoltage",
    "DC voltage input overvoltage",
    "Reserve",
    "Reserve",
    "IGBT temperature alarm",
    "DC relay feedback",
    "Internal fan warning",
    "External fan warning",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Over temperature load reduction ",
    "BUS overvoltage load reduction",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "BUS undervoltage load reduction",
    "Under frequency load load reduction",
    "BUS Pressure drop load reduction",
    "Fan Derating Prompt",
    "Hardware sampling bias error",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Main DSP communication fault (External CAN)",
    "Slave DSP communication fault (SCI)",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve"
};

const int8_t *p_pcs_reason_fault_text[PCS_FAULT_NUM] = \
{
    "电网电压高于允许范围",
    "电网电压低于允许范围",
    "电网实际频率高于本地电网标准要求",
    "电网实际频率低于本地电网标准要求",
    "电气设备绝缘老化或损坏，使相与地之间的绝缘电阻下降而漏电",
    "电网电压过高持续的时间比故障穿越允许值长",
    "电网电压过低持续的时间比故障穿越允许值长",
    "检查到本地用电设备和电网断开连接",
    "电网电压异常",
    "电网瞬时电压高于允许范围",
    "电网掉电或电网电压异常",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "电网电流零偏校准异常",
    "电网电流直流分量零偏校准异常",
    "保留",
    "电网电压零偏校准异常",
    "保留",
    "漏电流零偏校准异常",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "冗余电网电压采样和控制电网电压采样差异过大",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "设备内部电路异常（辅助电源电压超出故障阈值）",
    "设备内部电路异常（交流滤波电容电压和电网电压不一致）",
    "保留",
    "保留",
    "设备内部电路异常（交流继电器粘连）",
    "1.电池簇对地短路;2.电池簇所处环境空气潮湿且同时线路对地绝缘不良.",
    "保留",
    "保留",
    "保留",
    "直流接线极性反接",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "1.环境温度高于系统最高工作温度2.PCS模块风扇故障3.PCS模块入风口堵塞",
    "1.环境温度高于系统最高工作温度2.PCS模块风扇故障3.PCS模块入风口堵塞",
    "保留",
    "1.环境温度高于系统最高工作温度2.PCS模块风扇故障3.PCS模块入风口堵塞",
    "1.环境温度高于系统最高工作温度2.PCS模块风扇故障3.PCS模块入风口堵塞",
    "1.环境温度高于系统最高工作温度2.PCS模块风扇故障3.PCS模块入风口堵塞",
    "1.环境温度高于系统最高工作温度2.PCS模块风扇故障3.PCS模块入风口堵塞",
    "1.环境温度高于系统最高工作温度2.PCS模块风扇故障3.PCS模块入风口堵塞",
    "1.环境温度高于系统最高工作温度2.PCS模块风扇故障3.PCS模块入风口堵塞",
    "模块设备异常（正负母线偏差超过阈值）",
    "保留",
    "直流侧输入电压过低或者发生母线短路",
    "保留",
    "保留",
    "设备直流端口电压高于允许范围",
    "保留",
    "直流输入电压过高",
    "直流输入电压过高",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "电网电流中直流电流分量超过允许范围",
    "电网电压急剧降低或者短路，导致设备瞬时交流电流过大而产生保护",
    "保留",
    "电网电压急剧降低或者短路，导致设备瞬时交流电流过大而产生保护",
    "保留",
    "保留",
    "1.电网异常2.PCS模块异常",
    "保留",
    "保留",
    "保留",
    "电网电压急剧降低或者短路，导致设备瞬时交流电流过大而产生保护",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "1.直流输入电压过高2.电网异常3.PCS模块异常",
    "保留",
    "1.直流输入电流过高",
    "保留",
    "保留",
    "电网电压急剧降低或者短路，导致设备瞬时交流电流过大而产生保护",
    "保留",
    "保留",
    "保留",
    "模块设备异常（检测出的硬件版本号与设计不符）",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "交流侧A/B/C相序接反",
    "相线对地阻抗低或者短路",
    "防短路模块发生短路故障",
    "防短路模块电压低",
    "模块设备异常（直流继电器开路或者粘连）",
    "防短路模块超温",
    "环境温度小于最低运行温度",
    "1.PCS模块异常",
    "1.PCS模块异常",
    "设备ID分配错误",
    "1.通讯线未连接好2. CSU控制盒异常3.PCS模块异常",
    "1.通信线未连接2.系统柜控制盒供电异常",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "1.内部风扇损坏",
    "1.外部风扇堵转  2.外部风扇损坏",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "模块设备异常（绝缘阻抗偏低）",
    "模块设备异常（辅助电源电压超出告警阈值）",
    "1.防雷器保护后失效",
    "1.防雷器保护后失效",
    "1.直流输入电压异常2.直流接线接触不良",
    "1.直流输入电压异常2.直流接线接触不良",
    "保留",
    "保留",
    "1.环境温度高于系统最高工作温度2.风扇出风口有异物3.风扇异常",
    "直流继电器异常",
    "内部风扇损坏",
    "1.外部风扇堵转2.外部风扇损坏",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "1.环境温度高于系统最高工作温度2.风扇出风口有异物3.风扇异常",
    "直流侧电压过高",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "直流侧输入电压过低",
    "电网频率过高或过低",
    "1.直流输入电压过高2.电网电压过低",
    "1.外部风扇异常2.内部风扇异常",
    "1.PCS模块异常",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "1. 通信线CAN5未连接好2. 模块设备异常(CAN芯片工作异常)",
    "1. 模块内部主辅芯片通信异常2. 模块设备异常（模块内部主辅芯片工作异常）",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留"
};

const int8_t *p_pcs_reason_fault_text_en[PCS_FAULT_NUM] = \
{
    "The grid voltage is higher than the the allowable range",
    "The grid voltage is lower than the allowable range",
    "The actual frequency of the grid is higher than the local grid standard",
    "The actual frequency of the grid is lower than the local grid standard",
    "Electrical equipment insulation aging or damage, so that the insulation resistance between the phase and the ground drops and leakage",
    "The duration of the overvoltage is longer than the allowable fault crossing value",
    "The duration of the undervoltage is longer than the allowable value of the fault crossing",
    "Check that the local power device is disconnected from the power grid",
    "Grid voltage anomaly",
    "The instantaneous power grid voltage is higher than the allowable range",
    "The power grid fails or the power grid voltage is abnormal",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Grid current zero bias calibration anomaly",
    "Zero bias calibration of DC component of power grid current is abnormal",
    "Reserve",
    "Zero bias calibration anomaly of power grid voltage",
    "Reserve",
    "Leakage current zero bias calibration abnormal",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "The difference between redundant grid voltage sampling and control grid voltage sampling is too large",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "The internal circuit of the device is abnormal (The auxiliary power supply voltage exceeds the fault threshold)",
    "The internal circuit of the device is abnormal (The AC filter capacitor voltage is inconsistent with the power grid voltage)",
    "Reserve",
    "Reserve",
    "The internal circuit of the device is abnormal (Ac relay bonding)",
    "1.Battery cluster is short circuited to the ground;2.The ambient air of the battery cluster is humid and the cables are poorly insulated from the ground",
    "Reserve",
    "Reserve",
    "Reserve",
    "The polarity of the DC cable is reversed",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "1.The ambient temperature is higher than the maximum operating temperature2.PCS module fan fault3.The inlet of the PCS module is blocked",
    "1.The ambient temperature is higher than the maximum operating temperature2.PCS module fan fault3.The inlet of the PCS module is blocked",
    "Reserve",
    "1.The ambient temperature is higher than the maximum operating temperature2.PCS module fan fault3.The inlet of the PCS module is blocked",
    "1.The ambient temperature is higher than the maximum operating temperature2.PCS module fan fault3.The inlet of the PCS module is blocked",
    "1.The ambient temperature is higher than the maximum operating temperature2.PCS module fan fault3.The inlet of the PCS module is blocked",
    "1.The ambient temperature is higher than the maximum operating temperature2.PCS module fan fault3.The inlet of the PCS module is blocked",
    "1.The ambient temperature is higher than the maximum operating temperature2.PCS module fan fault3.The inlet of the PCS module is blocked",
    "1.The ambient temperature is higher than the maximum operating temperature2.PCS module fan fault3.The inlet of the PCS module is blocked",
    "Module device exception (The deviation of positive and negative busbars exceeds the threshold)",
    "Reserve",
    "The input voltage on the DC side is too low or the bus is short-circuited",
    "Reserve",
    "Reserve",
    "The DC port voltage of the device is higher than the allowable range",
    "Reserve",
    "The DC input voltage is too high",
    "The DC input voltage is too high",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "The DC current component of the power grid current exceeds the allowable range",
    "The power grid voltage drops sharply or is short-circuited, which causes the instantaneous AC current of the device to be too large and thus generates protection",
    "Reserve",
    "The power grid voltage drops sharply or is short-circuited, which causes the instantaneous AC current of the device to be too large and thus generates protection",
    "Reserve",
    "Reserve",
    "1.Grid anomaly2.PCS module exception",
    "Reserve",
    "Reserve",
    "Reserve",
    "The power grid voltage drops sharply or is short-circuited, which causes the instantaneous AC current of the device to be too large and thus generates protection",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "1.The DC input voltage is too high2.Grid anomaly3.PCS module exception",
    "Reserve",
    "1.The DC input current is too high",
    "Reserve",
    "Reserve",
    "The power grid voltage drops sharply or is short-circuited, which causes the instantaneous AC current of the device to be too large and thus generates protection",
    "Reserve",
    "Reserve",
    "Reserve",
    "Module device exception (The detected hardware version number does not match the design)",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "The A/B/C phase sequence on the AC side is reversed",
    "Low impedance of phase line to ground or short circuit",
    "The short-circuit prevention module is faulty",
    "The short-circuit prevention module has low voltage",
    "Module device exception (The DC relay is open or stuck)",
    "The short-circuit prevention module overheats",
    "The ambient temperature is lower than the minimum operating temperature",
    "1.PCS module exception",
    "1.PCS module exception",
    "The device ID is incorrectly assigned",
    "1.The communication line is not connected properly2. The CSU control box is abnormal3.PCS module exception",
    "1.The communication line is not connected properly2.The power supply to the system cabinet control box is abnormal",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "1.Internal fan failure",
    "1.The external fan is blocked  2.External fan failure",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Module device exception (Low insulation impedance)",
    "Module device exception (The auxiliary power supply voltage exceeds the alarm threshold)",
    "1.The surge arrester fails after protection",
    "1.The surge arrester fails after protection",
    "1.The DC input voltage is abnormal2.The DC cable is in poor contact",
    "1.The DC input voltage is abnormal2.The DC cable is in poor contact",
    "Reserve",
    "Reserve",
    "1.The ambient temperature is higher than the maximum operating temperature2.A foreign body is found in the fan outlet3.Fan exception",
    "DC relay exception",
    "Internal fan failure",
    "1.The external fan is blocked2.External fan failure",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "1.The ambient temperature is higher than the maximum operating temperature2.A foreign body is found in the fan outlet3.Fan exception",
    "The DC voltage is too high",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "The input voltage on the DC side is too low",
    "The power grid frequency is too high or too low",
    "1.The DC input voltage is too high2.The power grid voltage is too low",
    "1.External fan exception2.Internal fan exception",
    "1.PCS module exception",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "1. Communication line CAN5 is not connected properly2. Module device exception(The CAN chip works abnormally)",
    "1. The communication between the primary and secondary chips in the module is abnormal2. Module device exception (The primary and secondary chips in the module are abnormal)",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve"
};

const int8_t *p_pcs_restore_fault_text[PCS_FAULT_NUM] = \
{
    "1.如果偶然出现,可能是电网短时间异常,无需人工干预;2.若频繁出现,请检查电网是否有异常",
    "1.如果偶然出现,可能是电网短时间异常,无需人工干预;2.若频繁出现,请检查电网是否有异常",
    "1.如果偶然出现,可能是电网短时间异常,无需人工干预;2.若频繁出现,请检查电网是否有异常",
    "1.如果偶然出现,可能是电网短时间异常,无需人工干预;2.若频繁出现,请检查电网是否有异常",
    "取下PV阵列输入端,然后检查外围的AC电网",
    "1.系统重新上电,模块是否恢复正常2.若否,更换相应PCS模块",
    "1.系统重新上电,模块是否恢复正常2.若否,更换相应PCS模块",
    "1.系统重新上电,模块是否恢复正常2.若否,更换相应PCS模块",
    "1.系统重新上电,模块是否恢复正常2.若否,更换相应PCS模块",
    "1.系统重新上电,模块是否恢复正常2.若否,更换相应PCS模块",
    "1.系统重新上电,模块是否恢复正常2.若否,更换相应PCS模块",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "1.系统重新上电,模块是否恢复正常2.若否,更换相应PCS模块",
    "1.系统重新上电,模块是否恢复正常2.若否,更换相应PCS模块",
    "保留",
    "1.系统重新上电,模块是否恢复正常2.若否,更换相应PCS模块",
    "保留",
    "1.系统重新上电,模块是否恢复正常2.若否,更换相应PCS模块",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "1.系统重新上电,模块是否恢复正常2.若否,更换相应PCS模块",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "1.系统重新上电,模块是否恢复正常2.若否,更换相应PCS模块",
    "1.系统重新上电,模块是否恢复正常2.若否,更换相应PCS模块",
    "保留",
    "保留",
    "1.系统重新上电,模块是否恢复正常2.若否,更换相应PCS模块",
    "1.检查储能电池簇对保护地阻抗,若出现短路或绝缘不足请整改故障点;2.检查设备的保护地线是否正确连接;3.若确认在阴雨天环境下该阻抗确实低于设定保护点，请设置“绝缘阻抗保护点”参数.",
    "保留",
    "保留",
    "保留",
    "检查输入接线是否正确",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "1.确认环境温度小于系统最高工作温度2.检查相应PCS模块风扇是否正常3.检查PCS模块入风口是否有堵塞",
    "1.确认环境温度小于系统最高工作温度2.检查相应PCS模块风扇是否正常3.检查PCS模块入风口是否有堵塞",
    "保留",
    "1.确认环境温度小于系统最高工作温度2.检查相应PCS模块风扇是否正常3.检查PCS模块入风口是否有堵塞",
    "1.确认环境温度小于系统最高工作温度2.检查相应PCS模块风扇是否正常3.检查PCS模块入风口是否有堵塞",
    "1.确认环境温度小于系统最高工作温度2.检查相应PCS模块风扇是否正常3.检查PCS模块入风口是否有堵塞",
    "1.确认环境温度小于系统最高工作温度2.检查相应PCS模块风扇是否正常3.检查PCS模块入风口是否有堵塞",
    "1.确认环境温度小于系统最高工作温度2.检查相应PCS模块风扇是否正常3.检查PCS模块入风口是否有堵塞",
    "1.确认环境温度小于系统最高工作温度2.检查相应PCS模块风扇是否正常3.检查PCS模块入风口是否有堵塞",
    "1.系统重新上电，模块是否恢复正常",
    "保留",
    "1.系统重新上电,模块是否恢复正常;2.若否,更换相应PCS模块",
    "保留",
    "保留",
    "1.系统重新上电,模块是否恢复正常;2.若否,更换相应PCS模块",
    "保留",
    "1.系统重新上电,模块是否恢复正常;2.若否,更换相应PCS模块",
    "1.系统重新上电,模块是否恢复正常;2.若否,更换相应PCS模块",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "1.系统重新上电,模块是否恢复正常;2.若否,更换相应PCS模块",
    "1.系统重新上电,模块是否恢复正常;2.若否,更换相应PCS模块",
    "保留",
    "1.系统重新上电,模块是否恢复正常;2.若否,更换相应PCS模块",
    "保留",
    "保留",
    "1.系统重新上电,模块是否恢复正常;2.若否,更换相应PCS模块",
    "保留",
    "保留",
    "保留",
    "1.系统重新上电,模块是否恢复正常;2.若否,更换相应PCS模块",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "1.系统重新上电,模块是否恢复正常;2.若否,更换相应PCS模块",
    "保留",
    "1.系统重新上电,模块是否恢复正常;2.若否,更换相应PCS模块",
    "保留",
    "保留",
    "1.系统重新上电,模块是否恢复正常;2.若否,更换相应PCS模块",
    "保留",
    "保留",
    "保留",
    "请确认PCS模块硬件版本",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "请检查电网接线相序",
    "检查相线对地阻抗，找出阻抗偏低的位置",
    "检查防短路模块硬件设备",
    "检查防短路模块电压",
    "1.系统重新上电,模块是否恢复正常;2.若否,更换相应PCS模块",
    "确认防短路模块温度不超过运行温度范围，并检查通风口",
    "确认环境温度不超过运行温度范围",
    "1.系统重新上电,模块是否恢复正常;2.若否,更换相应PCS模块",
    "1.系统重新上电,模块是否恢复正常;2.若否,更换相应PCS模块",
    "重新分配设备号",
    "1.系统下电,重新上电,模块是否恢复正常2.重新连接相应模块通讯线3.若所有模块报故障,更换CSU控制盒4.若部分模块报故,更换相应PCS模块",
    "检查系统通讯线连接是否正常",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "更换PCS模块风扇",
    "更换PCS模块风扇",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "检查绝缘阻抗数值是否在安全标准之外",
    "联系技术支持",
    "联系技术支持",
    "联系技术支持",
    "检查直流侧电压是否超出工作电压范围",
    "检查直流侧电压是否超出工作电压范围",
    "保留",
    "保留",
    "确认环境温度不超过运行温度范围，并检查通风口",
    "1.系统重新上电,模块是否恢复正常;2.若否,更换相应PCS模块",
    "更换PCS模块风扇",
    "更换PCS模块风扇",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "请确认环境温度是否会导致降载",
    "检查电池电压是否过高",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "1.检查电池电压是否过低",
    "检查电网是否异常",
    "1.检查电池电压是否过高;2.检查电网电压是否过低",
    "1.更换相应模块外部风扇;2.更换相应模块",
    "1.系统重新上电,模块是否恢复正常;2.若否,更换相应PCS模块",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "1.系统下电,重新上电,模块是否恢复正常2. 重新连接相应模块通讯线3.若所有模块报故障,更换CSU控制盒4.若部分模块报故,更换相应PCS模块",
    "1.系统下电,重新上电,模块是否恢复正常2. 重新连接相应模块通讯线3.若所有模块报故障,更换CSU控制盒4.若部分模块报故,更换相应PCS模块",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留",
    "保留"
};

const int8_t *p_pcs_restore_fault_text_en[PCS_FAULT_NUM] = \
{
    "1.If it happens by chance, it may be a short-time abnormal power grid without manual intervention;2.If this occurs frequently, check whether the power grid is abnormal",
    "1.If it happens by chance, it may be a short-time abnormal power grid without manual intervention;2.If this occurs frequently, check whether the power grid is abnormal",
    "1.If it happens by chance, it may be a short-time abnormal power grid without manual intervention;2.If this occurs frequently, check whether the power grid is abnormal",
    "1.If it happens by chance, it may be a short-time abnormal power grid without manual intervention;2.If this occurs frequently, check whether the power grid is abnormal",
    "Remove the PV array input and check the peripheral AC grid",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "Reserve",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "Reserve",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "Reserve",
    "Reserve",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "1.Check the impedance of the battery cluster to the protected ground. Rectify the fault if there is a short circuit or insufficient insulation;2.Check whether the PGND cable of the device is correctly connected;3.If it is confirmed that the impedance is indeed lower than the set protection point in a cloudy and rainy environment, set the 'insulation impedance protection point' parameter.",
    "Reserve",
    "Reserve",
    "Reserve",
    "Check whether the input cable is correctly connected",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "1.Check that the ambient temperature is lower than the maximum operating temperature2.Check whether the fan of the PCS module is normal3.Check whether the inlet of the PCS module is blocked",
    "1.Check that the ambient temperature is lower than the maximum operating temperature2.Check whether the fan of the PCS module is normal3.Check whether the inlet of the PCS module is blocked",
    "Reserve",
    "1.Check that the ambient temperature is lower than the maximum operating temperature2.Check whether the fan of the PCS module is normal3.Check whether the inlet of the PCS module is blocked",
    "1.Check that the ambient temperature is lower than the maximum operating temperature2.Check whether the fan of the PCS module is normal3.Check whether the inlet of the PCS module is blocked",
    "1.Check that the ambient temperature is lower than the maximum operating temperature2.Check whether the fan of the PCS module is normal3.Check whether the inlet of the PCS module is blocked",
    "1.Check that the ambient temperature is lower than the maximum operating temperature2.Check whether the fan of the PCS module is normal3.Check whether the inlet of the PCS module is blocked",
    "1.Check that the ambient temperature is lower than the maximum operating temperature2.Check whether the fan of the PCS module is normal3.Check whether the inlet of the PCS module is blocked",
    "1.Check that the ambient temperature is lower than the maximum operating temperature2.Check whether the fan of the PCS module is normal3.Check whether the inlet of the PCS module is blocked",
    "1.powered on the system again. Check whether the module is normal",
    "Reserve",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "Reserve",
    "Reserve",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "Reserve",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "Reserve",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "Reserve",
    "Reserve",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "Reserve",
    "Reserve",
    "Reserve",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "Reserve",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "Reserve",
    "Reserve",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "Reserve",
    "Reserve",
    "Reserve",
    "Please confirm the hardware version of the PCS module",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Check the phase sequence of the power grid connection",
    "Check the impedance of the phase line to the ground and find out where the impedance is low",
    "Check the hardware of the short-circuit prevention module",
    "Check the voltage of the anti-short-circuit module",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "Ensure that the temperature of the anti-short-circuit module does not exceed the operating temperature range, and check the vents",
    "Ensure that the ambient temperature does not exceed the operating temperature range",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "Reassign the device number",
    "1.Power off and power on the system to check whether the module is normal2.Reconnect the corresponding module communication cable3.If all modules are faulty, replace the CSU control box4.If some modules fail, replace the corresponding PCS modules",
    "Check whether the system communication cable is properly connected",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Replace the fan in the PCS module",
    "Replace the fan in the PCS module",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Check insulation impedance values outside safety standards",
    "Contact Technical Support",
    "Contact Technical Support",
    "Contact Technical Support",
    "Check whether the DC voltage exceeds the working voltage range",
    "Check whether the DC voltage exceeds the working voltage range",
    "Reserve",
    "Reserve",
    "Ensure that the ambient temperature does not exceed the operating temperature range, and check the vents",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "Replace the fan in the PCS module",
    "Replace the fan in the PCS module",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Check whether the ambient temperature will cause load loss",
    "Check whether the battery voltage is too high",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "1.Check whether the battery voltage is too low",
    "Check whether the power grid is abnormal",
    "1.Check whether the battery voltage is too high;2.Check whether the power grid voltage is too low",
    "1.Replace the external fan in the corresponding module;2.Replace the corresponding module",
    "1.powered on the system again. Check whether the module is normal2.If not, replace the PCS module",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "1.Power off and power on the system to check whether the module is normal2.Reconnect the corresponding module communication cable3.If all modules are faulty, replace the CSU control box4.If some modules fail, replace the corresponding PCS modules",
    "1.Power off and power on the system to check whether the module is normal2.Reconnect the corresponding module communication cable3.If all modules are faulty, replace the CSU control box4.If some modules fail, replace the corresponding PCS modules",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve",
    "Reserve"
};

int32_t cmu_reason_fault_text_get(const fault_text_language_e lan, uint8_t index, int8_t *buff)
{
    uint8_t len;

    if (buff == NULL)
    {
		WEB_FAULT_TEXT_PRINT("null pointer.");
		return SF_ERR_PARA;
    }

    if (index >= CMU_FAULT_NUM)
    {
		WEB_FAULT_TEXT_PRINT("error, index = %d.", index);
		return SF_ERR_PARA;
    }

    if(lan == FAULT_TEXT_LANGUAGE_CHINESE)  //中文显示
    {
      len = strlen(p_cmu_reason_fault_text[index]);
      if (len >= FAULT_RESTORE_TEXT_LEN)
      {
        WEB_FAULT_TEXT_PRINT("text len error, index = %d.", index);
        return SF_ERR_NDEF;
      }
      snprintf((char*)buff, len + 1, p_cmu_reason_fault_text[index]);
    }
    else if(lan == FAULT_TEXT_LANGUAGE_ENGLISH)//英文显示
    {
      len = strlen(p_cmu_reason_fault_text_en[index]);
      if (len >= FAULT_RESTORE_TEXT_LEN)
      {
        WEB_FAULT_TEXT_PRINT("text len error, index = %d.", index);
        return SF_ERR_NDEF;
      }
      snprintf((char*)buff, len + 1, p_cmu_reason_fault_text_en[index]);
    }

    return SF_OK;
}

int32_t cmu_restore_fault_text_get(const fault_text_language_e lan, uint8_t index, int8_t *buff)
{
    uint8_t len;

    if (buff == NULL)
    {
		WEB_FAULT_TEXT_PRINT("null pointer.");
		return SF_ERR_PARA;
    }

    if (index >= CMU_FAULT_NUM)
    {
		  WEB_FAULT_TEXT_PRINT("error, index = %d.", index);
		  return SF_ERR_PARA;
    }

    if(lan == FAULT_TEXT_LANGUAGE_CHINESE)  //中文显示
    {
      len = strlen(p_cmu_restore_fault_text[index]);
      if (len >= FAULT_RESTORE_TEXT_LEN)
      {
        WEB_FAULT_TEXT_PRINT("text len error, index = %d.", index);
        return SF_ERR_NDEF;
      }
      snprintf((char*)buff, len + 1, p_cmu_restore_fault_text[index]);
    }
    else if(lan == FAULT_TEXT_LANGUAGE_ENGLISH)//英文显示
    {
      len = strlen(p_cmu_restore_fault_text_en[index]);
      if (len >= FAULT_RESTORE_TEXT_LEN)
      {
        WEB_FAULT_TEXT_PRINT("text len error, index = %d.", index);
        return SF_ERR_NDEF;
      }
      snprintf((char*)buff, len + 1, p_cmu_restore_fault_text_en[index]);
    }

    return SF_OK;
}


/**
 * @brief  	根据索引，获取CMU的故障显示文本
 * @param  	[in] index 	索引
 * @param  	[out] buff 	获取到的CMU故障显示文本
 * @return 	执行结果
 * @retval  =0: 成功
 * @retval  <0: 失败，返回错误代码
 */
int32_t cmu_fault_text_get(const fault_text_language_e lan, uint8_t index, int8_t *buff)
{
    uint8_t len;

    if (buff == NULL)
    {
		WEB_FAULT_TEXT_PRINT("null pointer.");
		return SF_ERR_PARA;
    }

    if (index >= CMU_FAULT_NUM)
    {
		WEB_FAULT_TEXT_PRINT("error, index = %d.", index);
		return SF_ERR_PARA;
    }

    if(lan == FAULT_TEXT_LANGUAGE_CHINESE)  //中文显示
    {
        len = strlen(p_cmu_fault_text[index]);
        if (len >= FAULT_NAME_TEXT_LEN)
        {
          WEB_FAULT_TEXT_PRINT("text len error, index = %d.", index);
          return SF_ERR_NDEF;
        }
        snprintf((char*)buff, len + 1, p_cmu_fault_text[index]);
    }
    else if(lan == FAULT_TEXT_LANGUAGE_ENGLISH)  //英文显示
    {
        len = strlen(p_cmu_fault_text_en[index]);
        if (len >= FAULT_NAME_TEXT_LEN)
        {
          WEB_FAULT_TEXT_PRINT("text len error, index = %d.", index);
          return SF_ERR_NDEF;
        }
        snprintf((char*)buff, len + 1, p_cmu_fault_text_en[index]);
    }
   
    return SF_OK;
}


/**
 * @brief  	根据索引，获取集装箱的故障显示文本
 * @param  	[in] dev_id 设备id
 * @param  	[in] field_index 	字段索引
 * @param  	[in] fault_id 	故障id
 * @param  	[out] buff 	获取到的集装箱故障显示文本
 * @return 	执行结果
 * @retval  =0: 成功
 * @retval  <0: 失败，返回错误代码
 */
int32_t cooled_fault_reason_get(const fault_text_language_e lan,const uint8_t dev_id, const uint8_t field_index, const uint8_t fault_id, uint8_t *buff)
{
	cJSON *p_fault_array = NULL;
	cJSON *p_array_item = NULL;
	FILE *fp = NULL;
	uint8_t content[COOLED_FAULT_BUFF_LEN] = {0};
	uint8_t *p_str = NULL;
  uint16_t len = 0;

  // 缓存区清零
  memset(content, 0, COOLED_FAULT_BUFF_LEN);

  // 打开对应设备液冷故障json文件
  switch (dev_id)
  {
    case MIDEA_COOLED_DEV_ID:
      fp = fopen(MIDEA_COOLED_FAULT_JSON, "r");
    break;
    case AIRCONDITION_COOLED_DEV_ID:
      fp = fopen(AIRCONDITION_COOLED_FAULT_JSON, "r");
    break;
    case VISUAL_COOLED_DEV_ID:
      fp = fopen(VISUAL_COOLED_FAULT_JSON, "r");
    break;
    default:
      fp = NULL;
    break;
  }
  if(NULL == fp)
	{
		// print_log("open cooled file failed.");
		return SF_ERR_PARA;
	}

  fread(content, 1, COOLED_FAULT_BUFF_LEN, fp);
  p_fault_array = cJSON_Parse(content);
  if(NULL == p_fault_array)
	{
		print_log("parse json content failed,content:\n%s",content);
    fclose(fp);
		return SF_ERR_PARA;
	}

  p_array_item = cJSON_GetArrayItem(p_fault_array, fault_id);
  if(p_array_item == NULL)
  {
    print_log("get array item [%d] failed.", fault_id);
    cJSON_Delete(p_fault_array);
    fclose(fp);
    return SF_ERR_RD;
  }

  // 获取故障字段描述
  switch (field_index)
  {
    case COOLED_FIELD_FAULT_NAME:
      if(lan == FAULT_TEXT_LANGUAGE_CHINESE)
      {
          p_str = cJSON_GetObjectItem(p_array_item,"fault_name")->valuestring;
      }
      else if(lan == FAULT_TEXT_LANGUAGE_ENGLISH)
      {
          p_str = cJSON_GetObjectItem(p_array_item,"fault_name_en")->valuestring;
      }
      if (NULL != p_str)
      {
        len = strlen(p_str) + 1;
        if (len > FAULT_RESTORE_TEXT_LEN)
        {
          len = FAULT_RESTORE_TEXT_LEN;
        }
        snprintf((char*)buff, len, p_str);
      }
    break;
    case COOLED_FIELD_FAULT_REASON:
      if(lan == FAULT_TEXT_LANGUAGE_CHINESE)
      {
          p_str = cJSON_GetObjectItem(p_array_item,"reason")->valuestring;
      }
      else if(lan == FAULT_TEXT_LANGUAGE_ENGLISH)
      {
          p_str = cJSON_GetObjectItem(p_array_item,"reason_en")->valuestring;
      }
      
      if (NULL != p_str)
      {
        len = strlen(p_str) + 1;
        if (len > FAULT_RESTORE_TEXT_LEN)
        {
          len = FAULT_RESTORE_TEXT_LEN;
        }
        snprintf((char*)buff, len, p_str);
      }
    break;
    case COOLED_FIELD_FAULT_RESOLVENT:
      if(lan == FAULT_TEXT_LANGUAGE_CHINESE)
      {
          p_str = cJSON_GetObjectItem(p_array_item,"remedy")->valuestring;
      }
      else if(lan == FAULT_TEXT_LANGUAGE_ENGLISH)
      {
          p_str = cJSON_GetObjectItem(p_array_item,"remedy_en")->valuestring;
      }
      if (NULL != p_str)
      {
        len = strlen(p_str) + 1;
        if (len > FAULT_RESTORE_TEXT_LEN)
        {
          len = FAULT_RESTORE_TEXT_LEN;
        }
        snprintf((char*)buff, len, p_str);
      }
    break;
    default:
      p_str = NULL;
    break;
  }
  cJSON_Delete(p_fault_array);
  fclose(fp);
  if (NULL == p_str)
  {
    return SF_ERR_RD;
  }
	return SF_OK;
}

int32_t container_reason_fault_text_get(const fault_text_language_e lan, uint8_t index, int8_t *buff)
{
    uint8_t len;

    if (buff == NULL)
    {
		WEB_FAULT_TEXT_PRINT("null pointer.");
		return SF_ERR_PARA;
    }

    if (index >= CONTAINER_FAULT_NUM)
    {
		WEB_FAULT_TEXT_PRINT("error, index = %d.", index);
		return SF_ERR_PARA;
    }

    if(lan == FAULT_TEXT_LANGUAGE_CHINESE)  //中文显示
    {
        len = strlen(p_container_reason_fault_text[index]);
        if (len >= FAULT_RESTORE_TEXT_LEN)
        {
        WEB_FAULT_TEXT_PRINT("text len error, index = %d.", index);
        return SF_ERR_NDEF;
        }

        snprintf((char*)buff, len + 1, p_container_reason_fault_text[index]);
    }
    else if(lan == FAULT_TEXT_LANGUAGE_ENGLISH)  //英文显示
    {
        len = strlen(p_container_reason_fault_text_en[index]);
        if (len >= FAULT_RESTORE_TEXT_LEN)
        {
          WEB_FAULT_TEXT_PRINT("text len error, index = %d.", index);
          return SF_ERR_NDEF;
        }
        snprintf((char*)buff, len + 1, p_container_reason_fault_text_en[index]);
    }
    return SF_OK;
}

int32_t container_restore_fault_text_get(const fault_text_language_e lan, uint8_t index, int8_t *buff)
{
    uint8_t len;

    if (buff == NULL)
    {
		WEB_FAULT_TEXT_PRINT("null pointer.");
		return SF_ERR_PARA;
    }

    if (index >= CONTAINER_FAULT_NUM)
    {
		WEB_FAULT_TEXT_PRINT("error, index = %d.", index);
		return SF_ERR_PARA;
    }

    if(lan == FAULT_TEXT_LANGUAGE_CHINESE)  //中文显示
    {
      len = strlen(p_container_restore_fault_text[index]);
      if (len >= FAULT_RESTORE_TEXT_LEN)
      {
      WEB_FAULT_TEXT_PRINT("text len error, index = %d.", index);
      return SF_ERR_NDEF;
      }

      snprintf((char*)buff, len + 1, p_container_restore_fault_text[index]);
    }
    else if(lan == FAULT_TEXT_LANGUAGE_ENGLISH)  //英文显示
    {
        len = strlen(p_container_restore_fault_text_en[index]);
        if (len >= FAULT_RESTORE_TEXT_LEN)
        {
          WEB_FAULT_TEXT_PRINT("text len error, index = %d.", index);
          return SF_ERR_NDEF;
        }
        snprintf((char*)buff, len + 1, p_container_restore_fault_text_en[index]);
    }
    return SF_OK;
}


/**
 * @brief  	根据索引，获取集装箱的故障显示文本
 * @param  	[in] index 	索引
 * @param  	[out] buff 	获取到的集装箱故障显示文本
 * @return 	执行结果
 * @retval  =0: 成功
 * @retval  <0: 失败，返回错误代码
 */
int32_t container_fault_text_get(const fault_text_language_e lan, uint8_t index, int8_t *buff)
{
    uint8_t len;

    if (buff == NULL)
    {
		WEB_FAULT_TEXT_PRINT("null pointer.");
		return SF_ERR_PARA;
    }

    if (index >= CONTAINER_FAULT_NUM)
    {
		WEB_FAULT_TEXT_PRINT("error, index = %d.", index);
		return SF_ERR_PARA;
    }

    if(lan == FAULT_TEXT_LANGUAGE_CHINESE)  //中文显示
    {
      len = strlen(p_container_fault_text[index]);
      if (len >= FAULT_NAME_TEXT_LEN)
      {
      WEB_FAULT_TEXT_PRINT("text len error, index = %d.", index);
      return SF_ERR_NDEF;
      }

      snprintf((char*)buff, len + 1, p_container_fault_text[index]);
    }
    else if(lan == FAULT_TEXT_LANGUAGE_ENGLISH)  //英文显示
    {
        len = strlen(p_container_fault_text_en[index]);
        if (len >= FAULT_NAME_TEXT_LEN)
        {
          WEB_FAULT_TEXT_PRINT("text len error, index = %d.", index);
          return SF_ERR_NDEF;
        }
        snprintf((char*)buff, len + 1, p_container_fault_text_en[index]);
    }

    return SF_OK;
}


int32_t cluster_reason_fault_text_get(const fault_text_language_e lan, uint8_t index, int8_t *buff)
{
    uint8_t len;

    if (buff == NULL)
    {
		WEB_FAULT_TEXT_PRINT("null pointer.");
		return SF_ERR_PARA;
    }

    if (index >= BATTERY_CLUSTER_FAULT_NUM)
    {
		WEB_FAULT_TEXT_PRINT("error, index = %d.", index);
		return SF_ERR_PARA;
    }

    if(lan == FAULT_TEXT_LANGUAGE_CHINESE)  //中文显示
    {
      len = strlen(p_cluster_reason_fault_text[index]);
      if (len >= FAULT_RESTORE_TEXT_LEN)
      {
      WEB_FAULT_TEXT_PRINT("text len error, index = %d.", index);
      return SF_ERR_NDEF;
      }

      snprintf((char*)buff, len + 1, p_cluster_reason_fault_text[index]);
    }
    else if(lan == FAULT_TEXT_LANGUAGE_ENGLISH)  //英文显示
    {
        len = strlen(p_cluster_reason_fault_text_en[index]);
        if (len >= FAULT_RESTORE_TEXT_LEN)
        {
          WEB_FAULT_TEXT_PRINT("text len error, index = %d.", index);
          return SF_ERR_NDEF;
        }
        snprintf((char*)buff, len + 1, p_cluster_reason_fault_text_en[index]);
    }

    return SF_OK;
}

int32_t cluster_restore_fault_text_get(const fault_text_language_e lan, uint8_t index, int8_t *buff)
{
    uint8_t len;

    if (buff == NULL)
    {
		WEB_FAULT_TEXT_PRINT("null pointer.");
		return SF_ERR_PARA;
    }

    if (index >= BATTERY_CLUSTER_FAULT_NUM)
    {
		WEB_FAULT_TEXT_PRINT("error, index = %d.", index);
		return SF_ERR_PARA;
    }

    if(lan == FAULT_TEXT_LANGUAGE_CHINESE)  //中文显示
    {
      len = strlen(p_cluster_restore_fault_text[index]);
      if (len >= FAULT_RESTORE_TEXT_LEN)
      {
      WEB_FAULT_TEXT_PRINT("text len error, index = %d.", index);
      return SF_ERR_NDEF;
      }

      snprintf((char*)buff, len + 1, p_cluster_restore_fault_text[index]);
    }
    else if(lan == FAULT_TEXT_LANGUAGE_ENGLISH)  //英文显示
    {
        len = strlen(p_cluster_restore_fault_text_en[index]);
        if (len >= FAULT_RESTORE_TEXT_LEN)
        {
          WEB_FAULT_TEXT_PRINT("text len error, index = %d.", index);
          return SF_ERR_NDEF;
        }
        snprintf((char*)buff, len + 1, p_cluster_restore_fault_text_en[index]);
    }

    return SF_OK;
}


/**
 * @brief  	根据索引，获取电池簇的故障显示文本
 * @param  	[in] index 	索引
 * @param  	[out] buff 	获取到的电池簇故障显示文本
 * @return 	执行结果
 * @retval  =0: 成功
 * @retval  <0: 失败，返回错误代码
 */
int32_t cluster_fault_text_get(const fault_text_language_e lan, uint8_t index, int8_t *buff)
{
    uint8_t len;

    if (buff == NULL)
    {
		WEB_FAULT_TEXT_PRINT("null pointer.");
		return SF_ERR_PARA;
    }

    if (index >= BATTERY_CLUSTER_FAULT_NUM)
    {
		WEB_FAULT_TEXT_PRINT("error, index = %d.", index);
		return SF_ERR_PARA;
    }

    if(lan == FAULT_TEXT_LANGUAGE_CHINESE)  //中文显示
    {
      len = strlen(p_cluster_fault_text[index]);
      if (len >= FAULT_NAME_TEXT_LEN)
      {
      WEB_FAULT_TEXT_PRINT("text len error, index = %d.", index);
      return SF_ERR_NDEF;
      }

      snprintf((char*)buff, len + 1, p_cluster_fault_text[index]);
    }
    else if(lan == FAULT_TEXT_LANGUAGE_ENGLISH)  //英文显示
    {
        len = strlen(p_cluster_fault_text_en[index]);
        if (len >= FAULT_NAME_TEXT_LEN)
        {
          WEB_FAULT_TEXT_PRINT("text len error, index = %d.", index);
          return SF_ERR_NDEF;
        }
        snprintf((char*)buff, len + 1, p_cluster_fault_text_en[index]);
    }

    return SF_OK;
}

int32_t pcs_reason_fault_text_get(const fault_text_language_e lan, uint8_t index, int8_t *buff)
{
    uint8_t len;

    if (buff == NULL)
    {
		WEB_FAULT_TEXT_PRINT("null pointer.");
		return SF_ERR_PARA;
    }

    if (index >= PCS_FAULT_NUM)
    {
		WEB_FAULT_TEXT_PRINT("error, index = %d.", index);
		return SF_ERR_PARA;
    }

    if(lan == FAULT_TEXT_LANGUAGE_CHINESE)  //中文显示
    {
      len = strlen(p_pcs_reason_fault_text[index]);
      if (len >= FAULT_RESTORE_TEXT_LEN)
      {
      WEB_FAULT_TEXT_PRINT("text len error, index = %d.", index);
      return SF_ERR_NDEF;
      }

      snprintf((char*)buff, len + 1, p_pcs_reason_fault_text[index]);
    }
    else if(lan == FAULT_TEXT_LANGUAGE_ENGLISH)  //英文显示
    {
      len = strlen(p_pcs_reason_fault_text_en[index]);
      if (len >= FAULT_RESTORE_TEXT_LEN)
      {
        WEB_FAULT_TEXT_PRINT("text len error, index = %d.", index);
        return SF_ERR_NDEF;
      }
      snprintf((char*)buff, len + 1, p_pcs_reason_fault_text_en[index]);
    }

    return SF_OK;
}

int32_t pcs_restore_fault_text_get(const fault_text_language_e lan, uint8_t index, int8_t *buff)
{
    uint8_t len;

    if (buff == NULL)
    {
		WEB_FAULT_TEXT_PRINT("null pointer.");
		return SF_ERR_PARA;
    }

    if (index >= PCS_FAULT_NUM)
    {
		WEB_FAULT_TEXT_PRINT("error, index = %d.", index);
		return SF_ERR_PARA;
    }

    if(lan == FAULT_TEXT_LANGUAGE_CHINESE)  //中文显示
    {
      len = strlen(p_pcs_restore_fault_text[index]);
      if (len >= FAULT_RESTORE_TEXT_LEN)
      {
      WEB_FAULT_TEXT_PRINT("text len error, index = %d.", index);
      return SF_ERR_NDEF;
      }

      snprintf((char*)buff, len + 1, p_pcs_restore_fault_text[index]);
    }
    else if(lan == FAULT_TEXT_LANGUAGE_ENGLISH)  //英文显示
    {
      len = strlen(p_pcs_restore_fault_text_en[index]);
      if (len >= FAULT_RESTORE_TEXT_LEN)
      {
        WEB_FAULT_TEXT_PRINT("text len error, index = %d.", index);
        return SF_ERR_NDEF;
      }
      snprintf((char*)buff, len + 1, p_pcs_restore_fault_text_en[index]);
    }

    return SF_OK;
}

/**
 * @brief  	根据索引，获取PCS模块的故障显示文本
 * @param  	[in] index 	索引
 * @param  	[out] buff 	获取到的PCS模块故障显示文本
 * @return 	执行结果
 * @retval  =0: 成功
 * @retval  <0: 失败，返回错误代码
 */
int32_t pcs_fault_text_get(const fault_text_language_e lan, uint8_t index, int8_t *buff)
{
    uint8_t len;

    if (buff == NULL)
    {
		WEB_FAULT_TEXT_PRINT("null pointer.");
		return SF_ERR_PARA;
    }

    if (index >= PCS_FAULT_NUM)
    {
		WEB_FAULT_TEXT_PRINT("error, index = %d.", index);
		return SF_ERR_PARA;
    }

    if(lan == FAULT_TEXT_LANGUAGE_CHINESE)  //中文显示
    {
      len = strlen(p_pcs_fault_text[index]);
      if (len >= FAULT_NAME_TEXT_LEN)
      {
      WEB_FAULT_TEXT_PRINT("text len error, index = %d.", index);
      return SF_ERR_NDEF;
      }

      snprintf((char*)buff, len + 1, p_pcs_fault_text[index]);
    }
    else if(lan == FAULT_TEXT_LANGUAGE_ENGLISH)  //英文显示
    {
      len = strlen(p_pcs_fault_text_en[index]);
      if (len >= FAULT_NAME_TEXT_LEN)
      {
        WEB_FAULT_TEXT_PRINT("text len error, index = %d.", index);
        return SF_ERR_NDEF;
      }
      snprintf((char*)buff, len + 1, p_pcs_fault_text_en[index]);
    }

    return SF_OK;
}
