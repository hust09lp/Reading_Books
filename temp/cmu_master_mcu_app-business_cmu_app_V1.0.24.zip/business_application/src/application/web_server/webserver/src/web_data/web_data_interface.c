/** 
 * @file          web_data_interface.c
 * @brief         WEB数据接口函数功能实现
 * @author        liangguyao
 * @version       V0.0.1     初始版本
 * @date          2023/04/11
 * @copyright     Copyright (c) 2023 by SofarSolar, All Rights Reserved.
 */


#include "web_data_interface.h"
#include "operating_data_handle.h"
#include "sofar_log.h"
#include "sdk_shm.h"
#include "data_shm.h"
#include "sdk_store.h"
#include "sdk_fs.h"
#include "sofar_errors.h"
#include "event_record_task.h"
#include <string.h>
#include <time.h>
#include "sqlite3.h"
#include "sdk_file.h"

#define FAULT_DB_PATH "/user/data/event/Faults.db"

#define WEB_BIT_0   (0x01)
#define WEB_BIT_1   (0x02)
#define WEB_BIT_2   (0x04)
#define WEB_BIT_3   (0x08)
#define WEB_BIT_4   (0x10)
#define WEB_BIT_5   (0x20)
#define WEB_BIT_6   (0x40)
#define WEB_BIT_7   (0x80)

#define HISTORY_DATA_DAYS_MAX   (30)


typedef struct
{
    uint8_t  data_valid[BCU_DEVICE_NUM + 1];    // 0 - 数据无效； 非0 - 数据有效
    uint32_t data_num[BCU_DEVICE_NUM + 1];      // 事件的数量（条数）
    uint32_t data_index[BCU_DEVICE_NUM + 1];    // 当前的索引
}history_event_para_t;

typedef struct
{
    uint8_t file_num;           // 文件数量（个数）
    uint8_t minute_interval;    // 分钟间隔
    uint8_t cluster_index;      // 电池簇索引
}history_data_para_t;

/**
 * @brief  	获取WEB字节数据的状态位
 * @param  	[in] value  WEB字节数据
 * @param  	[in] bit    欲获取的bit位
 * @return 	[uint8_t] 对应bit位的状态
 */
static uint8_t web_bit_status_get(uint8_t value, uint8_t bit)
{
    uint8_t ret = 0;
    uint8_t result;

    result = value & bit;
    if (result == bit)
    {
        ret = 1;
    }

    return ret;
}

/**
 * @brief  	WEB数据初始化（若存放操作日志文件的文件夹不存在时，创建对应的文件夹）
 * @param  	[in] void
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t web_data_init(void)
{
    int32_t ret = 0;
    common_data_t *shm = NULL;

    // 映射共享内存
    shm = sdk_shm_init();

    if (shm == NULL)
    {
        WEB_DEBUG_PRINT("\n error, shm is NULL. \n");
        ret = -1;
    }

    return ret;
}

/**
 * @brief  	首页页面获取要显示的集装箱信息
 * @param  	[out] p_data 集装箱信息的数据指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t home_page_container_get(home_page_container_t *p_data)
{
    int32_t i;
    telematic_data_t *p_telematic = sdk_shm_telematic_data_get();
    telemetry_data_t *p_telemetry = sdk_shm_telemetry_data_get();

    if (p_data == NULL)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    // 集装箱
    p_data->cmu_sys_state          = p_telemetry->cmu_telemetry_info.cmu_sys_state;
    p_data->total_voltage          = p_telemetry->container_system_telemetry_info.total_voltage;
    p_data->total_current          = p_telemetry->container_system_telemetry_info.total_current;
    p_data->charge_discharge_power = p_telemetry->container_system_telemetry_info.charge_discharge_power;
    p_data->average_SOC            = p_telemetry->container_system_telemetry_info.soc;

    // 温湿度传感器
    p_data->cabinet_temperature1 = p_telemetry->container_system_telemetry_info.bat1_temper;
    p_data->cabinet_temperature2 = p_telemetry->container_system_telemetry_info.bat2_temper;
    p_data->cabinet_humidity1    = p_telemetry->container_system_telemetry_info.bat1_humidity;
    p_data->cabinet_humidity2    = p_telemetry->container_system_telemetry_info.bat2_humidity;

    // 液冷机组
    p_data->outlet_temperature_LC = p_telemetry->container_system_telemetry_info.lc_outlet_temp;
    p_data->inlet_temperature_LC  = p_telemetry->container_system_telemetry_info.lc_inlet_temp;
    p_data->outlet_pressure_LC    = p_telemetry->container_system_telemetry_info.lc_outlet_pressure;
    p_data->inlet_pressure_LC     = p_telemetry->container_system_telemetry_info.lc_inlet_pressure;
    p_data->run_mode_LC           = p_telemetry->container_system_telemetry_info.lc_control_mode;
    p_data->chg_dischg_forbid = p_telematic->container_system_status_info[0] & 0x03;
    p_data->lc_sofar_mode = p_telemetry->container_system_telemetry_info.lc_sofar_mode;

    // p_data->battery_door_status     = web_bit_status_get(p_telematic->container_system_status_info[0], WEB_BIT_2);
    // if (p_data->battery_door_status == 0)
    // {
    //     p_data->battery_door_status = web_bit_status_get(p_telematic->container_system_status_info[0], WEB_BIT_3);
    // }
    // p_data->battery_flood_status    = web_bit_status_get(p_telematic->container_system_status_info[0], WEB_BIT_1);
    // p_data->equipment_door_status   = web_bit_status_get(p_telematic->container_system_status_info[0], WEB_BIT_5);
    // p_data->equipment_flood_status  = web_bit_status_get(p_telematic->container_system_status_info[0], WEB_BIT_0);
    p_data->equipment_flood_status  = web_bit_status_get(p_telematic->container_system_status_info[1], WEB_BIT_0);
    p_data->battery_flood_status    = web_bit_status_get(p_telematic->container_system_status_info[1], WEB_BIT_1);
    p_data->equipment_door_status   = web_bit_status_get(p_telematic->container_system_status_info[1], WEB_BIT_2);
    p_data->battery_door_status = web_bit_status_get(p_telematic->container_system_status_info[1], WEB_BIT_3)\
    | web_bit_status_get(p_telematic->container_system_status_info[1], WEB_BIT_4)\
    | web_bit_status_get(p_telematic->container_system_status_info[1], WEB_BIT_5)\
    | web_bit_status_get(p_telematic->container_system_status_info[1], WEB_BIT_6)\
    | web_bit_status_get(p_telematic->container_system_status_info[1], WEB_BIT_7)\
    | web_bit_status_get(p_telematic->container_system_status_info[2], WEB_BIT_0);

    //CO浓度
    p_data->composite_sensor1_CO = p_telemetry->container_system_telemetry_info.mix_sensor1_co_ppm;
    p_data->composite_sensor2_CO = p_telemetry->container_system_telemetry_info.mix_sensor2_co_ppm;
    p_data->composite_sensor3_CO = p_telemetry->container_system_telemetry_info.mix_sensor3_co_ppm;
    p_data->composite_sensor4_CO = p_telemetry->container_system_telemetry_info.mix_sensor4_co_ppm;

    //PM2.5浓度
    p_data->composite_sensor1_PM25 = p_telemetry->container_system_telemetry_info.mix_sensor1_pm25_ppm;
    p_data->composite_sensor2_PM25 = p_telemetry->container_system_telemetry_info.mix_sensor2_pm25_ppm;
    p_data->composite_sensor3_PM25 = p_telemetry->container_system_telemetry_info.mix_sensor3_pm25_ppm;
    p_data->composite_sensor4_PM25 = p_telemetry->container_system_telemetry_info.mix_sensor4_pm25_ppm;

    //温度
    p_data->composite_sensor1_temp = p_telemetry->container_system_telemetry_info.mix_sensor1_temp;
    p_data->composite_sensor2_temp = p_telemetry->container_system_telemetry_info.mix_sensor2_temp;
    p_data->composite_sensor3_temp = p_telemetry->container_system_telemetry_info.mix_sensor3_temp;
    p_data->composite_sensor4_temp = p_telemetry->container_system_telemetry_info.mix_sensor4_temp;

    //充放电限制功率
    p_data->chg_limit_power = p_telemetry->container_system_telemetry_info.charge_limits_power;
    p_data->dischg_limit_power = p_telemetry->container_system_telemetry_info.discharge_limits_power;

    return SF_OK;
}

/**
 * @brief  	首页页面获取要显示的最新的操作日志数据
 * @param  	[in] num            欲获取操作日志的条数
 * @param  	[out] p_data        获取到的操作日志数据指针
 * @param  	[out] p_data_num    实际获取到操作日志的条数
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
// int32_t home_page_operation_log_latest_item_get(uint32_t num, void *p_data, uint32_t *p_data_num)
// {
//     int32_t ret;
//     uint32_t item_num;
//     uint32_t item_offset;

//     if ((p_data == NULL) || (p_data_num == NULL))
//     {
//         WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
//         return SF_ERR_PARA;
//     }
//     if (num > OPERATION_LOG_DEEP_MAX)
//     {
//         WEB_DEBUG_PRINT("\n [%s:%d] error, num = %d \n", __func__, __LINE__, num);
//         return SF_ERR_PARA;
//     }

//     ret = operation_log_num_get();
//     if (ret < 0)
//     {
//         log_i((int8_t *)"\n [%s:%d] error, item_num = %d \n", __func__, __LINE__, item_num);
//         return SF_ERR_RD;
//     }
//     if (ret == 0)
//     {
//         *p_data_num = 0;
//         log_i((int8_t *)"\n [%s:%d] null file. \n", __func__, __LINE__);
//         return SF_OK;
//     }
//     item_num = (uint32_t)ret;
//     item_num = (item_num > num) ? (num) : (item_num);
//     item_offset = item_num - 1;

//     ret = operation_log_item_get(item_offset, item_num, p_data, p_data_num);
//     if (ret < 0)
//     {
//         WEB_DEBUG_PRINT("\n [%s:%d] error, ret = %d \n", __func__, __LINE__, ret);
//     }
    
//     return ret;
// }

/**
 * @brief  	将event_time_t结构体时间转换成时间戳（秒）
 * @param  	[in] p_time         event_time_t结构体时间
 * @param  	[out] p_timestamp   时间戳（秒）
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t event_time_to_timestamp(const event_time_t *p_time, time_t *p_timestamp)
{
    struct tm data;

    if ((p_time == NULL) || (p_timestamp == NULL))
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    memset(&data, 0, sizeof(data));
    data.tm_year = (int32_t)(p_time->year) + 100;
    data.tm_mon  = (int32_t)(p_time->mon - 1);
    data.tm_mday = (int32_t)(p_time->day);
    data.tm_hour = (int32_t)(p_time->hour);
    data.tm_min  = (int32_t)(p_time->min);
    data.tm_sec  = (int32_t)(p_time->sec);
    *p_timestamp = mktime(&data) - 8 * 60 * 60;

    return SF_OK;
}

static time_t string_to_timestamp(const char* str)
{
   struct tm tm_time = {0};

   if(NULL == str)
   {
      return 0;
   }

    // 将字符串形式的时间转换为tm结构体
    sscanf(str, "%d-%d-%d %d:%d:%d", &tm_time.tm_year, &tm_time.tm_mon, &tm_time.tm_mday, 
           &tm_time.tm_hour, &tm_time.tm_min, &tm_time.tm_sec);

    // 调整年份和月份
    if(tm_time.tm_year >= 1900)
    {
       tm_time.tm_year -= 1900; // 年份从1900年开始
    }

   if(tm_time.tm_mon >= 1)
   {
      tm_time.tm_mon -= 1; // 月份从0开始
   }

    // 将tm结构体转换为UNIX时间戳
    time_t unix_time = mktime(&tm_time) - 8 * 60 * 60;

    return unix_time;
}

/**
 * @brief  	首页页面获取要显示的最新的5条故障日志数据
 * @param  	[out] p_data        故障日志的数据指针
 * @param  	[out] p_data_num    实际获取到故障日志的条数
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t home_page_fault_log_latest_5_item_get(void *p_data, uint32_t *p_data_num)
{
	sqlite3_stmt *stmt;
    char *err_msg = 0;
	int32_t rc = 0;
    sqlite3 *db;
	int total_num = 0;
	uint8_t sql[256] = {0};
	
	history_event_new_t *p_item = NULL;
	p_item = (history_event_new_t *)p_data;

	rc = sdk_fs_access((const int8_t *)FAULT_DB_PATH, SF_OK);
    if (rc == -1)  // 文件夹不存在，创建该文件夹
    {
		return(-1);
	}	
    rc = sqlite3_open(FAULT_DB_PATH, &db);
    if( rc ) {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return(-1);
    }	
	
	//snprintf(sql,256,"SELECT FAULTID, strftime('%%s', STARTTIME), strftime('%%s', ENDTIME) FROM Faults ORDER BY STARTTIME DESC LIMIT 5;");
    snprintf((char*)sql,256,"SELECT FAULTID, STARTTIME, ENDTIME FROM Faults ORDER BY STARTTIME DESC LIMIT 5;");
	rc = sqlite3_prepare_v2(db, sql, -1, &stmt, 0);

	if (rc != SQLITE_OK) {
    	fprintf(stderr, "Failed to fetch data: %s\n", sqlite3_errmsg(db));
    	sqlite3_close(db);
    	return -1;
	}

	while (sqlite3_step(stmt) == SQLITE_ROW)
	{
		p_item[total_num].event_id = sqlite3_column_int(stmt, 0);
        strcpy(p_item[total_num].start_time, sqlite3_column_text(stmt, 1));
        strcpy(p_item[total_num].end_time, sqlite3_column_text(stmt, 2));
		total_num ++;
	}
	*p_data_num = total_num;
	
	sqlite3_finalize(stmt);
	sqlite3_close(db);
	
	//printf("total_num: %d\n", total_num);
	return 1;
}

/**
 * @brief  	首页页面获取要显示的最新的故障日志数据
 * @param  	[in] filter_para    筛选条件参数
 * @param  	[out] p_data        故障日志的数据指针
 * @param  	[out] p_data_num    实际获取到故障日志的条数
 * @param  	[out] p_total_num   符合筛选条件的故障日志的条数
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t home_page_fault_log_latest_item_get(event_filter_para_t filter_para, void *p_data, uint32_t *p_data_num, uint32_t *p_total_num)
{
    int32_t ret = 0;
    uint32_t data_num = 0;
    uint32_t item_index = 0;
    uint32_t item_start_point;
    uint32_t item_num;
    uint32_t total_num = 0;
    uint8_t valid_file_num = 0;
    uint8_t index = 0;
    uint8_t bms_id;
    uint8_t latest_index;
    fs_t *p_fs[BCU_DEVICE_NUM + 1];    // 主设备历史事件event，BMS模块历史事件event_bms01 ~ event_bms10
    int8_t path_name[HISTORY_EVENT_PATH_NAME_MAX];
    history_event_t *p_item[BCU_DEVICE_NUM + 1] = {NULL};
    history_event_para_t para;
    time_t latest_timestamp = 0;
    time_t temp_timestamp = 0;
    uint32_t data_index;
    uint8_t i;

    if ((p_data == NULL) || (p_data_num == NULL))
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    item_start_point = (filter_para.page_index - 1) * (filter_para.items_perpage);
    if (item_start_point >= EVENT_RECORD_DEEP_MAX)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] error, item_start_point = %d, page_index = %d, items_perpage = %d \n", __func__, __LINE__, \
                        item_start_point, filter_para.page_index, filter_para.items_perpage);
        return SF_ERR_PARA;
    }
    item_num = (filter_para.page_index) * (filter_para.items_perpage);
    if (item_num > EVENT_RECORD_DEEP_MAX)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] page_index = %d, items_perpage = %d \n", __func__, __LINE__, filter_para.page_index, filter_para.items_perpage);
        item_num = EVENT_RECORD_DEEP_MAX;
    }

    ret = sdk_fs_access((const int8_t *)PATH_HISTORY_EVENT_RECOND_FOLDER, FS_F_OK);
    if (ret == -1)  // 文件夹不存在
    {
        WEB_DEBUG_PRINT("\n [%s:%d] /user/data/event/ Folder does not exist!!! \n", __func__, __LINE__);
        return SF_ERR_NO_OBJECT;
    }

    snprintf((char*)path_name, sizeof(path_name), PATH_HISTORY_EVENT_RECOND_FOLDER "event");
    ret = sdk_fs_access(path_name, FS_F_OK);
    if (ret == SF_OK)
    {
        p_fs[index] = sdk_fs_open(path_name, FS_READ);
        if (p_fs[index] != NULL)
        {
            index++;
            WEB_DEBUG_PRINT("\n [%s:%d] event open. \n", __func__, __LINE__);
        }
    }

    for (bms_id = 1; bms_id <= BCU_DEVICE_NUM; bms_id++)
    {
        snprintf((char*)path_name, sizeof(path_name), PATH_HISTORY_EVENT_RECOND_FOLDER "event_bms%02d", bms_id);
        ret = sdk_fs_access(path_name, FS_F_OK);
        if (ret == SF_OK)
        {
            p_fs[index] = sdk_fs_open(path_name, FS_READ);
            if (p_fs[index] != NULL)
            {
                index++;
                WEB_DEBUG_PRINT("\n [%s:%d] event_bms%02d open. \n", __func__, __LINE__, bms_id);
            }
        }
    }
    valid_file_num = index;
    WEB_DEBUG_PRINT("\n [%s:%d] valid_file_num = %d \n", __func__, __LINE__, valid_file_num);
    if (valid_file_num == 0)
    {
        *p_data_num = 0;
        return SF_OK;
    }
    memset(&para, 0, sizeof(history_event_para_t));

    for (index = 0; index < valid_file_num; index++)    // 分配动态内存
    {
        p_item[index] = (history_event_t *)malloc(EVENT_RECORD_DEEP_MAX * sizeof(history_event_t));
        if (p_item[index] == NULL)
        {
            WEB_DEBUG_PRINT("\n [%s:%d] malloc error, index = %d \n", __func__, __LINE__, index);
            break;  // malloc分配失败，结束循环
        }
    }
    if (index != valid_file_num)    // 存在malloc分配失败
    {
        for (i = 0; i < index; i++) // 释放已分配的动态内存
        {
            free(p_item[i]);
            p_item[i] = NULL;
        }
        WEB_DEBUG_PRINT("\n [%s:%d] free. \n", __func__, __LINE__);
        return SF_ERR_NDEF;
    }

    for (index = 0; index < valid_file_num; index++)
    {
        // 获取最新的num条故障日志
        ret = history_event_latest_item_get(p_fs[index], filter_para, (void *)(p_item[index]), &(para.data_num[index]));
        if (ret == SF_OK)
        {
            if (para.data_num[index] == 0)
            {
                para.data_valid[index] = 0;
            }
            else
            {
                total_num += para.data_num[index];
                para.data_valid[index] = 1;
            }
            WEB_DEBUG_PRINT("\n [%s:%d] data_num[%d] = %d, total_num = %d \n", __func__, __LINE__, index, para.data_num[index], total_num);
        }
        else
        {
            para.data_num[index] = 0;
            para.data_valid[index] = 0;
            WEB_DEBUG_PRINT("\n [%s:%d] error. ret = %d, index = %d \n", __func__, __LINE__, ret, index);
        }
        para.data_index[index] = 0;
        sdk_fs_close(p_fs[index]);
    }
    item_num = (total_num > item_num) ? (item_num) : (total_num);

    WEB_DEBUG_PRINT("\n [%s:%d] begin. \n", __func__, __LINE__);
    while (item_num)
    {
        // 查找首个有效的数据
        for (index = 0; index < valid_file_num; index++)
        {
            if (para.data_valid[index] == 1)    // 数据有效
            {
                break;
            }
        }
        if (index >= valid_file_num)    // 遍历没有有效数据
        {
            break;
        }
        latest_index = index;   // 将首个有效的数据索引标记为最新
        data_index = para.data_index[index];
        event_time_to_timestamp(&(p_item[index][data_index].event_time), &latest_timestamp);

        // 找出最新（时间戳最大）的那条数据
        for (index = index + 1; index < valid_file_num; index++)
        {
            if (para.data_valid[index] == 1)    // 数据有效
            {
                data_index = para.data_index[index];
                event_time_to_timestamp(&(p_item[index][data_index].event_time), &temp_timestamp);
                if (latest_timestamp < temp_timestamp)
                {
                    latest_index = index;   // 更新最新数据索引的标记
                    latest_timestamp = temp_timestamp;
                }
            }
        }
        data_index = para.data_index[latest_index];
        if (item_index >= item_start_point)
        {
            memcpy((int8_t *)p_data, &(p_item[latest_index][data_index]), sizeof(history_event_t));
            p_data = (int8_t *)p_data + sizeof(history_event_t);
            data_num++;
            WEB_DEBUG_PRINT("\n [%s:%d] latest_index = %d, item_index = %d \n", __func__, __LINE__, latest_index, item_index);
            WEB_DEBUG_PRINT("\n [%s:%d] event_id = %d \n", __func__, __LINE__, p_item[latest_index][data_index].event_id);
            WEB_DEBUG_PRINT("\n [%s:%d] %d-%d-%d  %d:%d:%d \n", __func__, __LINE__, p_item[latest_index][data_index].event_time.year, \
                                p_item[latest_index][data_index].event_time.mon, p_item[latest_index][data_index].event_time.day, \
                                p_item[latest_index][data_index].event_time.hour, p_item[latest_index][data_index].event_time.min, \
                                p_item[latest_index][data_index].event_time.sec);
        }
        WEB_DEBUG_PRINT("\n [%s:%d] item_index = %d \n", __func__, __LINE__, item_index);
        item_index++;
        para.data_index[latest_index] += 1; // 取走最新的数据后，对应的索引+1，指向下一个数据
        if (para.data_index[latest_index] >= para.data_num[latest_index])   // 从文件中取出的数据已排序完，数据有效位清零
        {
            para.data_valid[latest_index] = 0;
        }
        item_num--;
    }
    WEB_DEBUG_PRINT("\n [%s:%d] end. \n", __func__, __LINE__);

    *p_data_num  = data_num;
    *p_total_num = total_num;
    WEB_DEBUG_PRINT("\n [%s:%d] data_num = %d, total_num = %d \n", __func__, __LINE__, data_num, total_num);

    for (i = 0; i < valid_file_num; i++)    // 释放已分配的动态内存
    {
        free(p_item[i]);
        p_item[i] = NULL;
    }
    WEB_DEBUG_PRINT("\n [%s:%d] free. \n", __func__, __LINE__);

    return SF_OK;
}

/**
 * @brief  	电池簇信息页面获取要显示的信息
 * @param  	[out] p_data 电池簇信息的数据指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t cluster_info_page_get(battery_cluster_page_t *p_data)
{
    uint8_t cluster_index;
    battery_cluster_telematic_info_t *p_cluster_telematic = NULL;
    battery_cluster_telemetry_info_t *p_cluster_telemetry = NULL;

    if (p_data == NULL)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    for (cluster_index = 0; cluster_index < BCU_DEVICE_NUM; cluster_index++)
    {
        p_cluster_telematic = sdk_shm_battery_cluster_telematic_info_get(cluster_index);
        p_cluster_telemetry = sdk_shm_battery_cluster_telemetry_info_get(cluster_index);

        p_data->battery_cluster_info[cluster_index].BCU_comm_status                  = p_cluster_telemetry->BCU_comm_status;
        p_data->battery_cluster_info[cluster_index].cluster_voltage                  = p_cluster_telemetry->cluster_voltage;
        p_data->battery_cluster_info[cluster_index].cluster_current                  = p_cluster_telemetry->cluster_current;
        p_data->battery_cluster_info[cluster_index].cluster_SOC                      = p_cluster_telemetry->cluster_SOC;
        p_data->battery_cluster_info[cluster_index].average_SOH_monomer              = p_cluster_telemetry->average_SOH_monomer;
        p_data->battery_cluster_info[cluster_index].highest_monomer_voltage          = p_cluster_telemetry->highest_monomer_voltage_cluster[0];
        p_data->battery_cluster_info[cluster_index].lowest_monomer_voltage           = p_cluster_telemetry->lowest_monomer_voltage_cluster[0];
        p_data->battery_cluster_info[cluster_index].average_voltage_monomer          = p_cluster_telemetry->average_voltage_monomer;
        p_data->battery_cluster_info[cluster_index].highest_monomer_temperature      = p_cluster_telemetry->highest_monomer_temperature_cluster[0];
        p_data->battery_cluster_info[cluster_index].lowest_monomer_temperature       = p_cluster_telemetry->lowest_monomer_temperature_cluster[0];
        p_data->battery_cluster_info[cluster_index].average_temperature_monomer      = p_cluster_telemetry->average_temperature_monomer;
        p_data->battery_cluster_info[cluster_index].high_pressure_box_temperature1   = p_cluster_telemetry->high_pressure_box_temperature[0];
        p_data->battery_cluster_info[cluster_index].high_pressure_box_temperature2   = p_cluster_telemetry->high_pressure_box_temperature[1];
        p_data->battery_cluster_info[cluster_index].high_pressure_box_temperature3   = p_cluster_telemetry->high_pressure_box_temperature[2];
        p_data->battery_cluster_info[cluster_index].high_pressure_box_temperature4   = p_cluster_telemetry->high_pressure_box_temperature[3];
        p_data->battery_cluster_info[cluster_index].positive_insulation_resistance   = p_cluster_telemetry->positive_insulation_resistance;
        p_data->battery_cluster_info[cluster_index].negative_insulation_resistance   = p_cluster_telemetry->negative_insulation_resistance;
        p_data->battery_cluster_info[cluster_index].battery_node_highest_voltage     = p_cluster_telemetry->battery_node_highest_voltage;
        p_data->battery_cluster_info[cluster_index].battery_node_lowest_voltage      = p_cluster_telemetry->battery_node_lowest_voltage;
        p_data->battery_cluster_info[cluster_index].battery_node_highest_temperature = p_cluster_telemetry->battery_node_highest_temperature;
        p_data->battery_cluster_info[cluster_index].battery_node_lowest_temperature  = p_cluster_telemetry->battery_node_lowest_temperature;

        p_data->battery_cluster_info[cluster_index].cluster_cap_energy             = p_cluster_telemetry->PACK_number_in_cluster * 4300;

        p_data->battery_cluster_info[cluster_index].positive_relay_status          = web_bit_status_get(p_cluster_telematic->battery_cluster_status_info[1], WEB_BIT_0);
        p_data->battery_cluster_info[cluster_index].negative_relay_status          = web_bit_status_get(p_cluster_telematic->battery_cluster_status_info[1], WEB_BIT_2);
    }

    return SF_OK;
}

/**
 * @brief  	首页页面获取PCS相关数据
 * @param  	[out] p_data        获取到的PCS数据结构体指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t home_page_pcs_info_get(home_page_pcs_info_t *p_data)
{
    telemetry_data_t *p_telemetry = sdk_shm_telemetry_data_get();

    if (p_data == NULL)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    memcpy(p_data, &p_telemetry->power_module_telemetry_info[0], sizeof(home_page_pcs_info_t));
    return SF_OK;
}

/**
 * @brief  	电池簇信息详情页面获取要显示的PACK信息
 * @param  	[in] cluster_index  欲获取的电池簇数据索引
 * @param  	[in] pack_index     欲获取的PACK数据索引
 * @param  	[out] p_data        PACK信息的数据指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t cluster_info_page_pack_get(uint8_t cluster_index, uint8_t pack_index, web_monomer_info_t *p_data)
{
    battery_cluster_telemetry_info_t *p_cluster_telemetry = NULL;

    if (p_data == NULL)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    if ((cluster_index >= BCU_DEVICE_NUM) || (pack_index >= PACK_NUMBER))
    {
        WEB_DEBUG_PRINT("\n [%s:%d] error, cluster_index = %d, pack_index = %d \n", __func__, __LINE__, cluster_index, pack_index);
        return SF_ERR_PARA;
    }

    p_cluster_telemetry = sdk_shm_battery_cluster_telemetry_info_get(cluster_index);

    memcpy(p_data->monomer_voltage, p_cluster_telemetry->monomer_info[pack_index].monomer_voltage, MONOMER_NUMBER_IN_PACK * sizeof(uint16_t));
    memcpy(p_data->monomer_temperature, p_cluster_telemetry->monomer_info[pack_index].monomer_temperature, MONOMER_NUMBER_IN_PACK * sizeof(uint16_t));
    memcpy(p_data->monomer_SOC, p_cluster_telemetry->monomer_info[pack_index].monomer_SOC, MONOMER_NUMBER_IN_PACK * sizeof(uint16_t));
    memcpy(p_data->monomer_SOH, p_cluster_telemetry->monomer_info[pack_index].monomer_SOH, MONOMER_NUMBER_IN_PACK * sizeof(uint16_t));

    p_data->pole_temperater_PACK[0] = p_cluster_telemetry->pole_temperater_PACK[pack_index][0];
    p_data->pole_temperater_PACK[1] = p_cluster_telemetry->pole_temperater_PACK[pack_index][1];
    
    return SF_OK;
}

/**
 * @brief  	实时告警页面获取要显示的信息
 * @param  	[out] p_data 告警信息的数据指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t realtime_warn_page_get(realtime_warn_page_t *p_data)
{
    uint8_t cluster_index;
    telematic_data_t *p_telematic = NULL;
    battery_cluster_telematic_info_t *p_cluster_telematic = NULL;

    if (p_data == NULL)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    p_telematic = sdk_shm_telematic_data_get();

    memcpy(p_data->container_system_warn_info, p_telematic->container_system_warn_info, CONTAINER_SYSTEM_WARN_LEN_BYTE);    // 集装箱系统（告警信息）
    memcpy(p_data->container_system_fault_info, p_telematic->container_system_fault_info, CONTAINER_SYSTEM_FAULT_LEN_BYTE); // 集装箱系统（故障信息）

    for (cluster_index = 0; cluster_index < BCU_DEVICE_NUM; cluster_index++)
    {
        p_cluster_telematic = sdk_shm_battery_cluster_telematic_info_get(cluster_index);
        memcpy(p_data->battery_cluster_warn_info[cluster_index], p_cluster_telematic->battery_cluster_warn_info, BATTERY_CLUSTER_WARN_LEN_BYTE);    // 集装箱内电池簇（告警信息）
        memcpy(p_data->battery_cluster_fault_info[cluster_index], p_cluster_telematic->battery_cluster_fault_info, BATTERY_CLUSTER_FAULT_LEN_BYTE); // 集装箱内电池簇（故障信息）
    }

    return SF_OK;
}

/**
 * @brief  	参数配置页面获取保护参数配置
 * @param  	[out] p_data 参数的数据指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t para_config_page_protect_para_get(battery_parameter_data_t *p_data)
{
    battery_parameter_data_t *p_para = NULL;
    if (p_data == NULL)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    p_para = sdk_shm_battery_parameter_data_get(0);
    memcpy(p_data, p_para, sizeof(battery_parameter_data_t));

    return SF_OK;
}

/**
 * @brief  	下发保护参数配置
 * @param  	[in] p_data 参数的数据指针
 * @return 	void
 */
static void protect_para_set(battery_parameter_data_t *p_data)
{
    uint8_t j;

    for (j = 0; j < BCU_DEVICE_NUM; j++)
    {
        // battery_config_table_set(j, ISO_WARN_VALUE);
        // battery_config_table_set(j, CLUSTER_OVP_WARN_VALUE);
        // battery_config_table_set(j, CLUSTER_UVP_WARN_VALUE);
        // battery_config_table_set(j, PACK_OVP_WARN_VALUE);
        // battery_config_table_set(j, PACK_UVP_WARN_VALUE);
        // battery_config_table_set(j, CHARGE_OCP_WARN_VALUE);
        // battery_config_table_set(j, DISCHARGE_OCP_WARN_VALUE);
        // battery_config_table_set(j, CHARGE_MONOMER_TEMP_WARN_VALUE);
        // battery_config_table_set(j, CHARGE_MONOMER_TEMP_WARN_VALUE);
    }
}

/**
 * @brief  	参数配置页面设置保护参数配置
 * @param  	[in] p_data 参数的数据指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t para_config_page_protect_para_set(battery_parameter_data_t *p_data)
{
    uint8_t cluster_index;
    battery_parameter_data_t *p_para = NULL;
    if (p_data == NULL)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    for (cluster_index = 0; cluster_index < BCU_DEVICE_NUM; cluster_index++)
    {
        p_para = sdk_shm_battery_parameter_data_get(cluster_index);
        memcpy(p_para, p_data, sizeof(battery_parameter_data_t));
        
    }

  //  protect_para_set(p_data);

    return SF_OK;
}

/**
 * @brief  	参数配置页面获取运行数据存储参数
 * @param  	[out] p_days 运行数据存储天数参数的数据指针
 * @param  	[out] p_freq 运行数据存储频率参数的数据指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t para_config_page_storage_para_get(uint16_t *p_days, uint16_t *p_freq)
{
    constant_parameter_data_t *p_data = sdk_shm_constant_parameter_data_get();     // 定值/参数

    if ((p_data == NULL) || (p_days == NULL) || (p_freq == NULL))
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    *p_days = p_data->storage_duration_operation_data;
    *p_freq = p_data->storage_freq_operation_data;

    return SF_OK;
}

/**
 * @brief  	参数配置页面设置运行数据存储参数
 * @param  	[in] days 运行数据存储天数参数
 * @param  	[in] freq 运行数据存储频率参数
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t para_config_page_storage_para_set(uint16_t days, uint16_t freq)
{
    constant_parameter_data_t *p_data = sdk_shm_constant_parameter_data_get();     // 定值/参数
    web_control_info_t *web_control_info = shm_web_control_info_get();

    if (p_data == NULL)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    if ((p_data->storage_duration_operation_data != days) || (p_data->storage_freq_operation_data != freq))
    {
        p_data->storage_duration_operation_data = days;
        p_data->storage_freq_operation_data     = freq;
        web_control_info->run_storage_param_update_flag = 1;
    }

    return SF_OK;
}

/**
 * @brief  	参数配置页面获取充电上限SOC和放电下限SOC
 * @param  	[out] p_soc_charge_limit 充电上限SOC的数据指针
 * @param  	[out] p_soc_discharge_limit 放电下限SOC的数据指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t para_config_page_limit_soc_para_get(uint16_t *p_soc_charge_limit, uint16_t *p_soc_discharge_limit)
{
    constant_parameter_data_t *p_data = sdk_shm_constant_parameter_data_get();     // 定值/参数

    if ((p_data == NULL) || (p_soc_charge_limit == NULL) || (p_soc_discharge_limit == NULL))
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    *p_soc_charge_limit = p_data->soc_charge_limit;
    *p_soc_discharge_limit = p_data->soc_discharge_limit;

    return SF_OK;
}

/**
 * @brief  	参数配置页面设置充电上限SOC和放电下限SOC
 * @param  	[in] soc_charge_limit 充电上限SOC
 * @param  	[in] soc_discharge_limit 放电下限SOC
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t para_config_page_limit_soc_para_set(int16_t soc_charge_limit, int16_t soc_discharge_limit)
{
    constant_parameter_data_t *p_data = sdk_shm_constant_parameter_data_get();     // 定值/参数
    web_control_info_t *web_control_info = shm_web_control_info_get();

    if (p_data == NULL || web_control_info == NULL)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }
    /*数值有变化,则需要同步到共享内存和文件中*/
    if ((p_data->soc_charge_limit != soc_charge_limit) || (p_data->soc_discharge_limit != soc_discharge_limit))
    {
        p_data->soc_charge_limit = soc_charge_limit;
        p_data->soc_discharge_limit     = soc_discharge_limit;
        web_control_info->charge_discharge_soc_limit_set_flag = 1;
    }

    return SF_OK;
}

/**
 * @brief	rtc时间入参合法性/有效性检查
 * @param	[in] p_time rtc时间结构体，详见sdk_rtc_t定义  
 * @return	[int32_t] 执行结果 
 * @retval	0: 参数合法
 * @retval	<0: 参数非法，返回错误码
 */
static int32_t time_valid_check(sdk_rtc_t *p_time)
{
    uint8_t mon_days[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};	// 每个月的总天数
    int32_t ret;

    if (p_time == NULL)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

	if (((p_time->tm_year % 4 == 0) && (p_time->tm_year % 100 != 0)) || (p_time->tm_year % 400 == 0)) // 判断是否是闰年
	{
		mon_days[1] = 29;	// 闰年2月天数为29天
	}
	else
	{
		mon_days[1] = 28;	// 平年2月天数为28天
	}

    if ((p_time->tm_year > 37) || (p_time->tm_mon < 1) || (p_time->tm_mon > 12))	// 年份、月份无效 陈晓2023.3.15修改,32位系统只能到2037
	{
		ret = SF_ERR_PARA;
	}
	else if ((p_time->tm_day < 1) || (p_time->tm_day > mon_days[p_time->tm_mon - 1]))	// 日期无效	
	{
		ret = SF_ERR_PARA;
	}
	else if ((p_time->tm_hour > 23) || (p_time->tm_min > 59) || (p_time->tm_sec > 59))
	{
		ret = SF_ERR_PARA;    // 时、分、秒无效
	}
	else
	{
		ret = SF_OK;
	}

    return ret;
}

/**
 * @brief  	将sdk_rtc_t结构体时间转换成时间戳（秒）
 * @param  	[in] p_time         sdk_rtc_t结构体时间
 * @param  	[out] p_timestamp   时间戳（秒）
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
static int32_t date_time_to_timestamp(sdk_rtc_t *p_time, time_t *p_timestamp)
{
    struct tm data;

    if ((p_time == NULL) || (p_timestamp == NULL))
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    memset(&data, 0, sizeof(data));
    data.tm_year = (int32_t)(p_time->tm_year) + 100;
    data.tm_mon  = (int32_t)(p_time->tm_mon - 1);
    data.tm_mday = (int32_t)(p_time->tm_day);
    data.tm_hour = (int32_t)(p_time->tm_hour);
    data.tm_min  = (int32_t)(p_time->tm_min);
    data.tm_sec  = (int32_t)(p_time->tm_sec);
    *p_timestamp = mktime(&data) - 8 * 60 * 60;

    return SF_OK;
}

/**
 * @brief  	将时间戳（秒）转换成sdk_rtc_t结构体时间
 * @param  	[in] p_timestamp    时间戳（秒）
 * @param  	[out] p_time        sdk_rtc_t结构体时间
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
static int32_t timestamp_to_date_time(time_t *p_timestamp, sdk_rtc_t *p_time)
{
    struct tm *p_data;

    if ((p_timestamp == NULL) || (p_time == NULL))
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    p_data = localtime(p_timestamp);
    p_time->tm_year = (uint8_t)(p_data->tm_year - 100);
    p_time->tm_mon  = (uint8_t)(p_data->tm_mon + 1);
    p_time->tm_day  = (uint8_t)(p_data->tm_mday);
    p_time->tm_hour = (uint8_t)(p_data->tm_hour);
    p_time->tm_min  = (uint8_t)(p_data->tm_min);
    p_time->tm_sec  = (uint8_t)(p_data->tm_sec);

    return SF_OK;
}

/**
 * @brief  	根据起始时间点至结束时间点的时间段，来获取时间间隔和文件个数的参数
 * @details 小于3天，分钟间隔3分钟；大于等于3天，小于10天，分钟间隔30分钟；大于等于10天，小于30天，分钟间隔60分钟；大于等于30天或者小于5分钟，入参错误
 * @param  	[in] p_start_time       获取的历史数据的起始时间点
 * @param  	[in] p_end_time         获取的历史数据的结束时间点
 * @param  	[out] p_minute_interval 获取到的时间间隔
 * @param  	[out] p_file_num        获取从起始到结束，需要打开的文件个数
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
static int32_t history_data_page_para_get(sdk_rtc_t *p_start_time, sdk_rtc_t *p_end_time, uint8_t *p_minute_interval, uint8_t *p_file_num)
{
    int32_t ret;
    uint8_t minute_interval;
    sdk_rtc_t baseline;
    time_t start_timestamp = 0;
    time_t end_timestamp = 0;
    time_t baseline_timestamp = 0;
    time_t temp_timestamp = 0;
    time_t remainder;
    uint8_t quotient;

    if ((p_start_time == NULL) || (p_end_time == NULL) || (p_minute_interval == NULL) || (p_file_num == NULL))
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    date_time_to_timestamp(p_start_time, &start_timestamp);
    if (start_timestamp < 0)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] start timestamp error. \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    date_time_to_timestamp(p_end_time, &end_timestamp);
    if (end_timestamp < 0)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] end timestamp error. \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    baseline.tm_year = p_start_time->tm_year;
    baseline.tm_mon = p_start_time->tm_mon;
    baseline.tm_day = p_start_time->tm_day;
    baseline.tm_hour = 0;
    baseline.tm_min = 0;
    baseline.tm_sec = 0;
    date_time_to_timestamp(&baseline, &baseline_timestamp);
    if (baseline_timestamp < 0)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] baseline timestamp error. \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    /* 起始时间点大于结束时间点 */
    if (start_timestamp > end_timestamp)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] timestamp error. %d - %d \n", __func__, __LINE__, start_timestamp, end_timestamp);
        return SF_ERR_PARA;
    }

    /* 结束时间点大于起始时间点，但间隔小于3分钟 */
    temp_timestamp = start_timestamp + (OPERATING_RECORD_MIN_INTERVAL * 60);
    if (temp_timestamp > end_timestamp)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] timestamp error. %d - %d \n", __func__, __LINE__, start_timestamp, end_timestamp);
        return SF_ERR_PARA;
    }

    /* 结束时间点大于起始时间点，且大于30天 */
    temp_timestamp = start_timestamp + (30 * 24 * 60 * 60);
    if (temp_timestamp < end_timestamp)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] timestamp error. %d - %d \n", __func__, __LINE__, start_timestamp, end_timestamp);
        return SF_ERR_PARA;
    }

    /* 时间间隔 */
    temp_timestamp = end_timestamp - start_timestamp;
    if (temp_timestamp >= (10 * 24 * 60 * 60))    // 大于等于10天，小于30天
    {
        minute_interval = 60;
    }
    else if (temp_timestamp >= (3 * 24 * 60 * 60))  // 大于等于3天，小于10天
    {
        minute_interval = 30;
    }
    else    // 小于3天
    {
        minute_interval = OPERATING_RECORD_MIN_INTERVAL;
    }

    /* 从起始到结束，需要打开的文件个数 */
    temp_timestamp = end_timestamp - baseline_timestamp;
    quotient = (uint8_t)(temp_timestamp / (24 * 60 * 60));
    remainder = temp_timestamp % (24 * 60 * 60);
    WEB_DEBUG_PRINT("\n [%s:%d] quotient = %d, remainder = %d \n", __func__, __LINE__, quotient, remainder);
    if (remainder != 0)
    {
        quotient += 1;
    }

    *p_minute_interval = minute_interval;
    *p_file_num = quotient;

    return SF_OK;
}

/**
 * @brief  	从文件中读取运行数据记录
 * @param  	[in] p_fs 	已打开的文件指针
 * @param   [in] offset 在文件中的偏移地址
 * @param  	[in] len 	欲读取数据长度
 * @param  	[out] p_buff 	指向欲存放读取进来的数据空间
 * @return 	[int32_t] 执行结果
 * @retval  =0 读取成功
 * @retval  <0 读取失败
 */
static int32_t operating_date_read(fs_t *p_fs, uint32_t offset, uint32_t len, void *p_buff)
{
	int32_t ret = SF_OK;

	if ((p_fs == NULL) || (p_buff == NULL))
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer!\n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

	ret = sdk_fs_lseek(p_fs, offset);
    if (ret < 0)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] lseek error! ret = %d \n", __func__, __LINE__, ret);
        return SF_ERR_SEEK;
    }

	ret = sdk_fs_read(p_fs, p_buff, len);
    if (ret != len)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] read error!\n", __func__, __LINE__);
        return SF_ERR_RD;
    }

	return SF_OK;
}

/**
 * @brief  	获取历史数据
 * @param  	[in] p_start_time   获取的历史数据的起始时间点
 * @param  	[in] p_end_time     获取的历史数据的结束时间点
 * @param  	[in] p_para         参数（文件数量、分钟间隔、电池簇索引）
 * @param  	[out] p_data        历史数据的指针
 * @param  	[out] p_data_num    获取到历史数据的条数
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
static int32_t history_data_days_get(sdk_rtc_t *p_start_time, sdk_rtc_t *p_end_time, history_data_para_t *p_para, void *p_data, uint32_t *p_data_num)
{
    uint32_t data_num = 0;
    uint8_t file_loop;
    uint8_t minute_interval;
    uint8_t cluster_index;
    uint8_t index;
    uint32_t offset;
    int8_t file_name[PATH_FILE_MAX_LEN];
    fs_t *p_fs = NULL;
    time_t start_timestamp = 0;
    time_t end_timestamp = 0;
    time_t timestamp = 0;
    time_t history_data_timestamp = 0;
    time_t last_timestamp = 0;
    sdk_rtc_t rtc_time;
    int32_t ret;
    int32_t file_size;
    int32_t item_len;
    int32_t item_loop;
    operating_data_t operating_data;
    history_data_page_t history_data;
    battery_cluster_telemetry_operating_info_t *p_cluster = NULL;
    uint8_t i;

    if ((p_start_time == NULL) || (p_end_time == NULL) || (p_para == NULL) || (p_data == NULL) || (p_data_num == NULL))
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    cluster_index   = p_para->cluster_index;
    file_loop       = p_para->file_num;
    minute_interval = p_para->minute_interval;
    if (cluster_index >= BCU_DEVICE_NUM)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] cluster index error! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    if (file_loop > HISTORY_DATA_DAYS_MAX)
    {
        file_loop = HISTORY_DATA_DAYS_MAX;
    }

    date_time_to_timestamp(p_start_time, &start_timestamp);
    if (start_timestamp < 0)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] start_timestamp error. \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    date_time_to_timestamp(p_end_time, &end_timestamp);
    if (end_timestamp < 0)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] end_timestamp error. \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    WEB_DEBUG_PRINT("\n [%s:%d] file_loop = %d. \n", __func__, __LINE__, file_loop);
    for (index = 0; index < file_loop; index++)
    {
        if (index == 0)
        {
            timestamp = end_timestamp - 1;  // -1: 不包含终点时刻
        }
        else
        {
            timestamp = end_timestamp - 1 - (index * 24 * 60 * 60);
        }
        WEB_DEBUG_PRINT("\n [%s:%d] timestamp = %d \n", __func__, __LINE__, timestamp);
        timestamp_to_date_time(&timestamp, &rtc_time);

        /* 判断对应的日期文件是否存在 */
        snprintf((char*)file_name, sizeof(file_name), PATH_OPERATING_RECORD_FOLDER "%04d/%04d%02d%02d", \
            rtc_time.tm_year + 2000, rtc_time.tm_year + 2000, \
            rtc_time.tm_mon, rtc_time.tm_day);
        ret = sdk_fs_access(file_name, FS_F_OK);
        if (ret == -1)  // 文件不存在
        {
            WEB_DEBUG_PRINT("\n [%s:%d] %s does not exist. \n", __func__, __LINE__, file_name);
            continue;
        }

        p_fs = sdk_fs_open(file_name, FS_READ);
        if (p_fs == NULL)
        {
            WEB_DEBUG_PRINT("\n [%s:%d] sdk_fs_open fail. \n", __func__, __LINE__);
            continue;
        }
        else
        {
            WEB_DEBUG_PRINT("\n [%s:%d] %s open. \n", __func__, __LINE__, file_name);
        }

        file_size = sdk_fs_get_size(p_fs);
        if (file_size < 0)
        {
            WEB_DEBUG_PRINT("[%s:%d] file_size = %d \n", __func__, __LINE__, file_size);
            sdk_fs_close(p_fs);
            continue;
        }
        item_len = sizeof(operating_data_t);
        item_loop = file_size / item_len;
        WEB_DEBUG_PRINT("[%s:%d] file_size: %d, item_loop: %d, item_len: %d\n", __func__, __LINE__, file_size, item_loop, item_len);
        if (item_loop < 1)
        {
            WEB_DEBUG_PRINT("[%s:%d] no content!\n", __func__, __LINE__);
            sdk_fs_close(p_fs);
            continue;
        }
        else if (item_loop > OPERATING_DATA_READ_MAX_COUNT)
        {
            WEB_DEBUG_PRINT("[%s:%d] overflow!\n", __func__, __LINE__);
            item_loop = OPERATING_DATA_READ_MAX_COUNT;
        }
        offset = (item_loop - 1) * item_len;
        // WEB_DEBUG_PRINT("\n [%s:%d] item_loop = %d, offset = %d \n", __func__, __LINE__, item_loop, offset);

        while (item_loop)
        {
            ret = operating_date_read(p_fs, offset, sizeof(operating_data_t), &operating_data);
            if (ret == SF_OK)
            {
                date_time_to_timestamp(&(operating_data.operating_time), &history_data_timestamp);
                if ((history_data_timestamp >= start_timestamp) && (history_data_timestamp < end_timestamp))
                {
                    if ((last_timestamp == 0) || ((last_timestamp != 0) && ((history_data_timestamp + minute_interval * 60) <= last_timestamp)))
                    {
                        memcpy(&(history_data.operating_time), &(operating_data.operating_time), sizeof(sdk_rtc_t));
                        p_cluster = &(operating_data.telemetry_operating_data.battery_cluster_telemetry_operating_info[cluster_index]);
                        history_data.cluster_voltage                     = p_cluster->cluster_voltage;
                        history_data.cluster_current                     = p_cluster->cluster_current;
                        history_data.cluster_SOC                         = p_cluster->cluster_SOC;
                        history_data.average_SOH_monomer                 = p_cluster->average_SOH_monomer;
                        history_data.highest_monomer_voltage_cluster     = p_cluster->highest_monomer_voltage_cluster[0];
                        history_data.lowest_monomer_voltage_cluster      = p_cluster->lowest_monomer_voltage_cluster[0];
                        history_data.average_voltage_monomer             = p_cluster->average_voltage_monomer;
                        history_data.highest_monomer_temperature_cluster = p_cluster->highest_monomer_temperature_cluster[0];
                        history_data.lowest_monomer_temperature_cluster  = p_cluster->lowest_monomer_temperature_cluster[0];
                        history_data.average_temperature_monomer         = p_cluster->average_temperature_monomer;
                        history_data.high_pressure_box_temperature1      = p_cluster->high_pressure_box_temperature[0];
                        history_data.high_pressure_box_temperature2      = p_cluster->high_pressure_box_temperature[1];
                        history_data.high_pressure_box_temperature3      = p_cluster->high_pressure_box_temperature[2];
                        history_data.positive_insulation_resistance      = p_cluster->positive_insulation_resistance;
                        history_data.high_pressure_box_temperature4      = p_cluster->high_pressure_box_temperature[3];
                        history_data.negative_insulation_resistance      = p_cluster->negative_insulation_resistance;
                        for (i = 0; i < PACK_NUMBER; i++)
                        {
                            memcpy(history_data.monomer_info[i].monomer_voltage, p_cluster->monomer_info[i].monomer_voltage, MONOMER_NUMBER_IN_PACK * sizeof(int16_t));
                            memcpy(history_data.monomer_info[i].monomer_temperature, p_cluster->monomer_info[i].monomer_temperature, MONOMER_NUMBER_IN_PACK * sizeof(int16_t));
                            memcpy(history_data.monomer_info[i].monomer_SOC, p_cluster->monomer_info[i].monomer_SOC, MONOMER_NUMBER_IN_PACK * sizeof(uint16_t));
                            memcpy(history_data.monomer_info[i].monomer_SOH, p_cluster->monomer_info[i].monomer_SOH, MONOMER_NUMBER_IN_PACK * sizeof(uint16_t));
                            history_data.monomer_info[i].pole_temperater_PACK[0] = p_cluster->pole_temperater_PACK[i][0];
                            history_data.monomer_info[i].pole_temperater_PACK[1] = p_cluster->pole_temperater_PACK[i][0];
                        }
                        memcpy((int8_t *)p_data, &history_data, sizeof(history_data_page_t));
                        p_data = (int8_t *)p_data + sizeof(history_data_page_t);
                        data_num++;
                        last_timestamp = history_data_timestamp;
                    }
                    else
                    {
                        // WEB_DEBUG_PRINT("\n [%s:%d] last_timestamp = %d, history_data_timestamp = %d. \n", __func__, __LINE__, last_timestamp, history_data_timestamp);
                    }
                }
                else
                {
                    // WEB_DEBUG_PRINT("\n [%s:%d] %02d-%02d-%02d %02d:%02d:%02d. \n", __func__, __LINE__, \
                    //                 operating_data.operating_time.tm_year, operating_data.operating_time.tm_mon, operating_data.operating_time.tm_day, \
                    //                 operating_data.operating_time.tm_hour, operating_data.operating_time.tm_min, operating_data.operating_time.tm_sec);
                    // WEB_DEBUG_PRINT("\n [%s:%d] start_timestamp = %d, end_timestamp = %d, history_data_timestamp = %d. \n", __func__, __LINE__, \
                    //                 start_timestamp, end_timestamp, history_data_timestamp);
                }
            }
            else
            {
                // WEB_DEBUG_PRINT("\n [%s:%d] operating_date_read ret = %d. \n", __func__, __LINE__, ret);
            }
            offset -= item_len;
            item_loop--;
        }
        sdk_fs_close(p_fs);    
    }

    *p_data_num = data_num;
    WEB_DEBUG_PRINT("\n [%s:%d] data_num = %d. \n", __func__, __LINE__, data_num);

    return SF_OK;
}

/**
 * @brief  	历史数据页面获取历史数据
 * @param  	[in] p_start_time   获取的历史数据的起始时间点
 * @param  	[in] p_end_time     获取的历史数据的结束时间点
 * @param  	[in] cluster_index  欲获取的电池簇数据索引
 * @param  	[out] p_data        历史数据的指针
 * @param  	[out] p_data_num    获取到历史数据的条数
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t history_data_page_get(sdk_rtc_t *p_start_time, sdk_rtc_t *p_end_time, uint8_t cluster_index, void *p_data, uint32_t *p_data_num)
{
    int32_t ret;
    uint8_t minute_interval = OPERATING_RECORD_MIN_INTERVAL;
    uint8_t file_num = 0;
    history_data_para_t para;

    if ((p_start_time == NULL) || (p_end_time == NULL) || (p_data == NULL) || (p_data_num == NULL))
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }
    WEB_DEBUG_PRINT("\n [%s:%d] start: %02d-%02d-%02d %02d:%02d:%02d \n", __func__, __LINE__, p_start_time->tm_year, \
                    p_start_time->tm_mon, p_start_time->tm_day, p_start_time->tm_hour, p_start_time->tm_min, p_start_time->tm_sec);
    WEB_DEBUG_PRINT("\n [%s:%d] end: %02d-%02d-%02d %02d:%02d:%02d \n", __func__, __LINE__, p_end_time->tm_year, \
                    p_end_time->tm_mon, p_end_time->tm_day, p_end_time->tm_hour, p_end_time->tm_min, p_end_time->tm_sec);

    /* 检测SD卡是否存在 */
    // ret = sdk_store_is_exist(TF_CARD);
    // if (ret < SF_OK)
    // {
    //     WEB_DEBUG_PRINT("\n [%s:%d] TF_CARD does not exist!!! \n", __func__, __LINE__);
    //     return SF_ERR_NO_OBJECT;
    // }

    /* 判断/media/文件夹是否存在 */
    ret = sdk_fs_access((const int8_t *)(PATH_OPERATING_RECORD_FOLDER), FS_F_OK);
    if (ret != SF_OK)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] /media/ Folder does not exist. \n", __func__, __LINE__);
        return SF_ERR_NO_OBJECT;
    }

    ret = time_valid_check(p_start_time);
    if (ret < 0)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] p_start_time error. \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    ret = time_valid_check(p_end_time);
    if (ret < 0)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] p_end_time error. \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    if (p_data == NULL)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    if (cluster_index >= BCU_DEVICE_NUM)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] cluster index error! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    ret = history_data_page_para_get(p_start_time, p_end_time, &minute_interval, &file_num);
    if (ret < 0)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] history_data_page_para_get error. \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }
    WEB_DEBUG_PRINT("\n [%s:%d] minute_interval = %d, file_num = %d \n", __func__, __LINE__, minute_interval, file_num);
    if ((minute_interval < OPERATING_RECORD_MIN_INTERVAL) || (minute_interval > OPERATING_RECORD_MAX_INTERVAL) || (file_num > HISTORY_DATA_DAYS_MAX))
    {
        WEB_DEBUG_PRINT("\n [%s:%d] p_end_time error. \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    para.file_num = file_num;
    para.minute_interval = minute_interval;
    para.cluster_index = cluster_index;
    ret = history_data_days_get(p_start_time, p_end_time, &para, p_data, p_data_num);
    if (ret < 0)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] history_data_days_get error. \n", __func__, __LINE__);
    }

    return ret;
}

/**
 * @brief  	调试管理页面获取状态信息
 * @param  	[out] p_data 状态信息的指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t debug_manage_page_get(debug_manage_page_read_t *p_data)
{
    uint8_t cluster_index;
    battery_cluster_telematic_info_t *p_cluster_telematic = NULL;

    if (p_data == NULL)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    for (cluster_index = 0; cluster_index < BCU_DEVICE_NUM; cluster_index++)
    {
        p_cluster_telematic = sdk_shm_battery_cluster_telematic_info_get(cluster_index);
        memcpy(p_data->battery_cluster_status_info[cluster_index], p_cluster_telematic->battery_cluster_status_info, BATTERY_CLUSTER_STATUS_LEN_BYTE);
    }

    return SF_OK;
}

/**
 * @brief  	调试管理页面设置遥控数据信息
 * @param  	[in] p_data 遥控数据信息的指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t debug_manage_page_set(debug_manage_page_write_t *p_data)
{
    web_control_info_t *web_control_info;
    if (p_data == NULL)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }
    web_control_info = shm_web_control_info_get();

    memcpy(web_control_info,p_data,sizeof(debug_manage_page_write_t));

    return SF_OK;
}

/**
 * @brief  	调试管理页面显示MCU和BMS版本号信息
 * @param  	[in] p_data 遥测数据信息的指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t debug_manage_version_info_get(debug_manage_version_info_t *p_data)
{
    internal_version_info_t *version_info;
    if (p_data == NULL)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }
    version_info = internal_version_info_get();
    memcpy(p_data,version_info,sizeof(internal_version_info_t));

    return SF_OK;
}

/**
 * @brief  	设置保护参数页面进行保护参数保存
 * @param  	[in] p_data 保护参数信息的指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t protect_params_flag_set()
{
    web_control_info_t *web_control_info;
    #if 0
    if (p_data == NULL)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }
    #endif
    web_control_info = shm_web_control_info_get();

    web_control_info->battery_threshold_update_flag = 1;

    return SF_OK;
}

/**
 * @brief  	获取液冷信息和电池簇组的信息
 * @param  	无
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t get_lc_status_and_cluster_group_status(uint8_t *p_lc_sta,uint8_t *p_cluster_group1_sta,uint8_t *p_cluster_group2_sta)
{
    telematic_data_t *p_telematic;

    p_telematic = sdk_shm_telematic_data_get();

    *p_lc_sta = ((p_telematic->container_system_status_info[5] & WEB_BIT_0) != 0) ? 1 : 0;
    *p_cluster_group1_sta = ((p_telematic->container_system_status_info[2] & WEB_BIT_3) != 0) ? 1 : 0;
    *p_cluster_group2_sta = ((p_telematic->container_system_status_info[2] & WEB_BIT_4) != 0) ? 1 : 0;

    return SF_OK;
}


/**
 * @brief  	获取集装箱状态信息
 * @param  	[in] p_data 集装箱状态信息指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t container_status_info_get(container_status_info_t *p_data)
{
    telematic_data_t *p_telematic;
    if (p_data == NULL)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    p_telematic = sdk_shm_telematic_data_get();
    memcpy(p_data, p_telematic->container_system_status_info, CONTAINER_SYSTEM_STATUS_LEN_BYTE);
    return SF_OK;
}

/**
 * @brief  	获取MQTT使用的信息
 * @param  	[in] p_bms_data BMS数据指针
 * @param  	[in] p_pcs_data MQTT信息指针
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t mqtt_info_get(bms_data_t *p_bms_data, pcs_data_t *p_pcs_data)
{
    uint8_t index = 0;
    uint8_t battery_type;
    uint8_t pcs_state;
    int16_t active_power;
    uint32_t grid_su_energy;
    uint32_t get_grid_energy;
    uint32_t total_run_time;
    uint32_t total_voltage[PACK_NUMBER] = {0};
    uint8_t i;
    uint16_t j, k;
    battery_cluster_telemetry_info_t *p_bat_telemetry = NULL;
    telemetry_data_t *p_telemetry = sdk_shm_telemetry_data_get();
    internal_shared_data_t *p_internal_data = internal_shared_data_get();
    heartbeat_data_t *p_heartbeat_data = sdk_shm_heartbeat_data_get();

    if ((p_bms_data == NULL) || (p_pcs_data == NULL))
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    // BMS数据
    battery_type = (uint8_t)(p_telemetry->container_system_telemetry_info.battery_type);
    switch (battery_type)
    {
        case 1:     // 1-磷酸铁锂电池(L)
            p_bms_data->battery_type = 0x03;
            break;
        case 2:     // 2—钛酸锂电池(N)
            p_bms_data->battery_type = 0x08;
            break;
        case 3:     // 3—锰酸锂电池(T)
            p_bms_data->battery_type = 0x04;
            break;
        case 4:     // 4-三元锂电池(S)
            p_bms_data->battery_type = 0x06;
            break;
        default:
            p_bms_data->battery_type = 0x00;
            break;
    }

    active_power = p_telemetry->power_module_telemetry_info[0].active_power;
    if(abs(active_power) < 10)            //需要考虑跳动，这里使用100w作为跳动阈值
    {
        active_power = 0;
    }
    if (active_power > 0)
    {
        p_bms_data->charge_status = 0x03; // 放电中
    }
    else if (active_power < 0)
    {
        p_bms_data->charge_status = 0x02; // 充电中
    }
    else
    {
        p_bms_data->charge_status = 0x01; // 静置中
    }

    p_bms_data->charge_curr_max     = 180 * 100;
    p_bms_data->discharge_curr_max  = 180 * 100;
    p_bms_data->voltage             = (uint32_t)(p_telemetry->container_system_telemetry_info.total_voltage * 10);
    p_bms_data->current             = (uint32_t)abs(p_telemetry->container_system_telemetry_info.total_current * 100);
    p_bms_data->power               = (uint32_t)abs(p_telemetry->container_system_telemetry_info.charge_discharge_power * 1000);
    p_bms_data->soc                 = p_telemetry->container_system_telemetry_info.soc;
    p_bms_data->soh                 = p_telemetry->container_system_telemetry_info.soh;

    p_bat_telemetry = sdk_shm_battery_cluster_telemetry_info_get(index); // 电池簇遥测
    if (p_bat_telemetry == NULL)
    {
        WEB_DEBUG_PRINT("\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }
    
    p_bms_data->monomer_vmin        = (uint16_t)(p_bat_telemetry->lowest_monomer_voltage_cluster[0]);
    p_bms_data->monomer_vmin_index  = p_bat_telemetry->battery_node_lowest_voltage;
    p_bms_data->monomer_vmax        = (uint16_t)(p_bat_telemetry->highest_monomer_voltage_cluster[0]);
    p_bms_data->monomer_vmax_index  = p_bat_telemetry->battery_node_highest_voltage;
    p_bms_data->monomer_tmin        = (uint16_t)((p_bat_telemetry->lowest_monomer_temperature_cluster[0] - 40) * 10) + 1000;
    p_bms_data->monomer_tmin_index  = p_bat_telemetry->battery_node_lowest_temperature;
    p_bms_data->monomer_tmax        = (uint16_t)((p_bat_telemetry->highest_monomer_temperature_cluster[0] - 40) * 10) + 1000;
    p_bms_data->monomer_tmax_index  = p_bat_telemetry->battery_node_highest_temperature;
    p_bms_data->total_discharge     = p_internal_data->cluster_total_discharge_energy[0] * 10;
    p_bms_data->total_charge        = p_internal_data->cluster_total_charging_energy[0] * 10;
    p_bms_data->day_discharge       = p_internal_data->cluster_daily_discharge_energy[0] * 10;
    p_bms_data->day_charge          = p_internal_data->cluster_daily_charging_energy[0] * 10;
    p_bms_data->pack_num            = p_bat_telemetry->PACK_number_in_cluster;
    p_bms_data->monomer_num         = p_bat_telemetry->battery_number_in_PACK;
    p_bms_data->pack_tpoint_num     = p_bat_telemetry->temperature_number_in_PACK;

    for (i = 0; i < p_bms_data->pack_num; i++)
    {
        for (j = 0; j < p_bms_data->monomer_num; j++)
        {
            p_bms_data->pack_volt[i] += p_bat_telemetry->monomer_info[i].monomer_voltage[j];
            k = i * MONOMER_NUMBER_IN_PACK + j;
            p_bms_data->monomer_volt[k] = p_bat_telemetry->monomer_info[i].monomer_voltage[j];
            p_bms_data->monomer_temp[k] = (p_bat_telemetry->monomer_info[i].monomer_temperature[j] - 40) * 10 + 1000;
        }
        p_bms_data->pack_volt[i] = p_bms_data->pack_volt[i] / 100.0;
        p_bms_data->pack_curr[i] = p_bms_data->current;
        p_bms_data->pack_power[i] = ((p_bms_data->current / 100) * (p_bms_data->pack_volt[i] / 10));
    }

    // PCS数据
    pcs_state = p_heartbeat_data->fsm_state[0];   // PCS状态机主状态: 0=config  1=wait  2=check  3=normal  4=shutdown 5=upgrade
    if (pcs_state == 2 || pcs_state == 3)
    {
        p_pcs_data->pcs_status      = 0x02; // 工作中
    }
    else
    {
        p_pcs_data->pcs_status      = 0x01; // 静置中
    }

    active_power = p_telemetry->power_module_telemetry_info[0].active_power;
    if (active_power > 0)
    {
        p_pcs_data->charge_status = 0x03; // 放电中
    }
    else if (active_power < 0)
    {
        p_pcs_data->charge_status = 0x02; // 充电中
    }
    else
    {
        p_pcs_data->charge_status = 0x01; // 静置中
    }

    p_pcs_data->temp            = (uint16_t)(p_telemetry->power_module_telemetry_info[0].amb_temp) + 1000;
    p_pcs_data->grid_power      = 0;
    p_pcs_data->load_power      = 0;

    p_pcs_data->dc_power        = (uint32_t)abs(p_telemetry->container_system_telemetry_info.charge_discharge_power);
    p_pcs_data->ac_power        = (uint32_t)abs(p_telemetry->power_module_telemetry_info[0].active_power);

    // grid_su_energy = (uint32_t)(((p_telemetry->power_module_telemetry_info[0].energy_discharge_h) << 16) | p_telemetry->power_module_telemetry_info[0].energy_discharge_l);
    p_pcs_data->grid_su_energy  = 0;

    get_grid_energy = (uint32_t)(((p_telemetry->power_module_telemetry_info[0].energy_charge_h) << 16) | p_telemetry->power_module_telemetry_info[0].energy_charge_l);
    p_pcs_data->get_grid_energy = get_grid_energy;

    p_pcs_data->load_use_energy = 0;

    p_pcs_data->grid_volt_r     = (uint32_t)(p_telemetry->power_module_telemetry_info[0].grid_volt_r);
    p_pcs_data->grid_current_r  = (uint32_t)(p_telemetry->power_module_telemetry_info[0].ac_current_r * 10);
    p_pcs_data->grid_freq_r     = (uint32_t)(p_telemetry->power_module_telemetry_info[0].grid_freq);

    p_pcs_data->grid_volt_s     = (uint32_t)(p_telemetry->power_module_telemetry_info[0].grid_volt_s);
    p_pcs_data->grid_current_s  = (uint32_t)(p_telemetry->power_module_telemetry_info[0].ac_current_s * 10);
    p_pcs_data->grid_freq_s     = (uint32_t)(p_telemetry->power_module_telemetry_info[0].grid_freq);

    p_pcs_data->grid_volt_t     = (uint32_t)(p_telemetry->power_module_telemetry_info[0].grid_volt_t);
    p_pcs_data->grid_current_t  = (uint32_t)(p_telemetry->power_module_telemetry_info[0].ac_current_t * 10);
    p_pcs_data->grid_freq_t     = (uint32_t)(p_telemetry->power_module_telemetry_info[0].grid_freq);

    p_pcs_data->day_run_time    = 0;
    total_run_time = (uint32_t)(((p_telemetry->power_module_telemetry_info[0].Running_Hours_H) << 16) | p_telemetry->power_module_telemetry_info[0].Running_Hours_L);
    p_pcs_data->total_run_time  = total_run_time * 60 * 60;

    return SF_OK;
}

