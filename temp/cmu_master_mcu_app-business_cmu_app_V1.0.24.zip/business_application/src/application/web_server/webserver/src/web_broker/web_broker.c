#include "web_broker.h"
#include "list.h"
#include"component/sofar_log.h"
#include "common.h"
#include"cJSON.h"
#define URL_MAX_LEN     128

typedef struct{
    list_head_t tFunNode;               //fucntion链表节点信息
    uint8_t url[URL_MAX_LEN];           //HTTP功能点对应的URL
    func_cb p_func_cb;                  //功能函数回调，功能模块按需注册进web代理
}function_node_t;


//组件链表头节点
static function_node_t g_web_func_list_head;


/**
 * @brief 功能链表节点加入
 *
 * @param [in] func_node : 节点
 * @param [in] p_list_head : 链表
 * 
 * @return 1:操作成功
 *         0:操作失败
 */
static uint8_t web_func_node_add(function_node_t func_node, function_node_t *p_list_head)
{
    function_node_t *p_node = NULL;
    
    p_node = (function_node_t *)malloc(sizeof(function_node_t));
    if(NULL == p_node)
    {
        print_log("malloc failed");
        return 0;
    }

    strcpy(p_node->url, func_node.url);
    p_node->p_func_cb = func_node.p_func_cb;

    list_add(&(p_node->tFunNode), &(p_list_head->tFunNode));
    
    return 1;
}


/**
 * @brief 功能注册
 *
 * @param [in] p_url : url
 * @param [in] trans_flag : 转发标志
 * @param [in] p_func_cb : 功能函数指针    
 * 
 * @retval uint8_t
 * @return 1:操作成功
 *         0:操作失败
 */
uint8_t web_func_attach(uint8_t *p_url, func_cb p_func_cb)
{
    uint8_t ret = 0;
    function_node_t func_node;

    memset(&func_node, 0, sizeof(function_node_t));
    strcpy(func_node.url, p_url);
    func_node.p_func_cb = p_func_cb;

    //新func id插入链表
    ret = web_func_node_add(func_node, &g_web_func_list_head);
    if(!ret)
    {
        print_log("add url[%s]error", func_node.url);
        return 0;
    }
    print_log("add url[%s]success", func_node.url);
    
    return 1;
}

/**
 * @brief 功能执行
 * @param [in] p_url : url
 * @return 1:操作成功
 *         0:操作失败
 */
uint8_t web_func_execute(struct mg_connection *p_nc,struct http_message *p_msg)
{
    list_head_t *ptPos = NULL;
    function_node_t *p_func_node = NULL;
    
    list_for_each(ptPos, &g_web_func_list_head.tFunNode)
    {
        p_func_node = list_entry(ptPos, function_node_t, tFunNode);
        if (mg_vcmp(&p_msg->uri, p_func_node->url) == 0)
        {
            if(p_func_node->p_func_cb != NULL)
            {
                //执行对应的功能
                p_func_node->p_func_cb(p_nc, p_msg);  
            }
            return 1;
        }
    }
    return 0;
}


/**
 * @brief web代理模块初始化
 * @return none
 */
void web_broker_module_init(void)
{
    //初始化链表
    init_list_head(&(g_web_func_list_head.tFunNode));
}


