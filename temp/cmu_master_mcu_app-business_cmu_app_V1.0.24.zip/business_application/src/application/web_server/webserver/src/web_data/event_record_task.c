/** 
 * @file          even_record_task.c
 * @brief         历史事件记录接口函数功能实现
 * @author        duyumeng
 * @version       V0.0.1     初始版本
 * @date          2022/08/25
 * @copyright     Copyright (c) 2023 by SofarSolar, All Rights Reserved. 
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author    	  <th>Description 
 * <tr><td>2022/08/25  <td>0.0.1    <td>duyumeng  	  <td>创建初始版本  
 * <tr><td>2023/03/15  <td>0.0.2    <td>liangguyao    <td>根据需求，作以下修改:
 *                                                        1.删除DCDC模块故障；
 *                                                        2.主设备由逆变器故障变更为CMU的故障/告警；
 *                                                        3.增加电池簇模块的故障/告警。
 * </table>
 **********************************************************************************
 */


#include "event_record_task.h"
#include "sdk_shm.h"
#include "sdk_public.h"
#include "sofar_log.h"
#include "sofar_errors.h"

#include <string.h>
#include <stdbool.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

/**
 * @brief  	从文件中读取历史事件数据
 * @param  	[in] p_fs 	已打开的文件指针
 * @param   [in] offset 在文件中的偏移地址
 * @param  	[in] len 	欲读取数据长度
 * @param  	[out] p_buff 	指向欲存放读取进来的数据空间
 * @return 	[int32_t] 执行结果
 * @retval  =0 读取成功
 * @retval  <0 读取失败
 */
int32_t history_event_read(fs_t *p_fs, uint32_t offset, uint32_t len, void *p_buff)
{
	int32_t ret = SF_OK;

	if ((p_fs == NULL) || (p_buff == NULL))
    {
        EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] null pointer!\n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

	ret = sdk_fs_lseek(p_fs, offset);
    if (ret < 0)
    {
        EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] lseek error! ret = %d \n", __func__, __LINE__, ret);
        return SF_ERR_SEEK;
    }

	ret = sdk_fs_read(p_fs, p_buff, len);
    if (ret != len)
    {
        EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] read error!\n", __func__, __LINE__);
        return SF_ERR_RD;
    }

	return SF_OK;
}

/**
 * @brief  	根据历史事件的ID，判断事件的类型
 * @param  	[in] event_id 			已打开的文件指针
 * @return 	执行结果
 * @retval  1: FAULT_EVENT, 故障事件
 * @retval  2: WARN_EVENT, 告警事件
 * @retval  3: TBD_EVENT, 未定义/不明确的事件
 */
static history_event_classify_e history_event_classify_get(uint16_t event_id)
{
	history_event_classify_e event_classify = TBD_EVENT;
	uint16_t start_point;
	uint16_t end_point;
	uint8_t i;

	start_point = CMU_FAULT_START;
	end_point   = CMU_FAULT_END;
	if ((event_id >= start_point) && (event_id <= end_point))	// 0x01 ~ 0x30
	{
		event_classify = FAULT_EVENT;
		return event_classify;
	}

	start_point = CONTAINER_WARN_START;
	end_point   = CONTAINER_WARN_END;
	if ((event_id >= start_point) && (event_id <= end_point))	// 0xA1 ~ 0xFF
	{
		event_classify = WARN_EVENT;
		return event_classify;
	}

	start_point = CONTAINER_FAULT_START;
	end_point   = CONTAINER_FAULT_END;
	if ((event_id >= start_point) && (event_id <= end_point))	// 0x101 ~ 0x150
	{
		event_classify = FAULT_EVENT;
		return event_classify;
	}

	start_point = PCSMODULE_CLUSTER_FAULT_START_POINT;
	end_point   = PCSMODULE_CLUSTER_FAULT_END_POINT;
	if ((event_id >= start_point) && (event_id <= end_point))	// 0x801 ~ 0x8F0
	{
		event_classify = FAULT_EVENT;
		return event_classify;
	}


	for (i = 0; i < BCU_DEVICE_NUM; i++)
	{
		start_point = BATTERY_CLUSTER_1_WARN_START + i * BATTERY_CLUSTER_INTERVAL;	// 0x171 + i * 0x100
		end_point   = BATTERY_CLUSTER_1_WARN_END + i * BATTERY_CLUSTER_INTERVAL;	// 0x200 + i * 0x100
		if ((event_id >= start_point) && (event_id <= end_point))	// 0x171 + i * 0x100 ~ 0x200 + i * 0x100
		{
			event_classify = WARN_EVENT;
			break;
		}

		start_point = BATTERY_CLUSTER_1_FAULT_START + i * BATTERY_CLUSTER_INTERVAL;	// 0x201 + i * 0x100
		end_point   = BATTERY_CLUSTER_1_FAULT_END + i * BATTERY_CLUSTER_INTERVAL;	// 0x250 + i * 0x100
		if ((event_id >= start_point) && (event_id <= end_point))	// 0x201 + i * 0x100 ~ 0x250 + i * 0x100
		{
			event_classify = FAULT_EVENT;
			break;
		}
	}

	return event_classify;
}

/**
 * @brief  	根据入参的筛选条件参数，从文件中读取对应的最新的历史事件数据
 * @param  	[in] p_fs 			已打开的文件指针
 * @param   [in] para    		筛选条件参数
 * @param  	[out] p_data 		符合筛选条件参数的历史事件的数据指针
 * @param  	[out] p_data_num	实际获取到符合筛选条件参数的历史事件的条数
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t history_event_latest_item_get(fs_t *p_fs, event_filter_para_t para, void *p_data, uint32_t *p_data_num)
{
	uint32_t data_num = 0;
	int32_t file_size;
	uint32_t offset;
	uint32_t loop_count;
	uint32_t item_len;
    uint32_t item_num;
	history_event_t item;
	int32_t ret = SF_OK;
	history_event_classify_e event_classify;

	if ((p_fs == NULL) || (p_data == NULL) || (p_data_num == NULL))
    {
        EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] null pointer!\n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

	file_size = sdk_fs_get_size(p_fs);
	if (file_size < 0)
	{
		EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] file_size = %d \n", __func__, __LINE__, file_size);
		return ret;
	}
	item_len = sizeof(history_event_t);
	item_num = file_size / item_len;
	if (item_num == 0)
    {
        EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] error, file_size = %d, item_num = %d \n", __func__, __LINE__, file_size, item_num);
        return SF_ERR_NDEF;
    }
	else if (item_num > EVENT_RECORD_DEEP_MAX)
	{
		item_num = EVENT_RECORD_DEEP_MAX;
	}
	EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] item_num = %d, item_len = %d \n", __func__, __LINE__, item_num, item_len);
	loop_count = item_num;
	offset = (item_num - 1) * item_len;
	EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] loop_count = %d, offset = %d \n", __func__, __LINE__, loop_count, offset);

	EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] para.filter_classify = %d \n", __func__, __LINE__, para.filter_classify);
	EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] para.filter_criteria = %d \n", __func__, __LINE__, para.filter_criteria);
	EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] para: items_perpage = %d, page_index = %d \n", __func__, __LINE__, para.items_perpage, para.page_index);
	EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] para: %d-%d-%d \n", __func__, __LINE__, para.year, para.mon, para.day);
	EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] para: event_id = %d \n", __func__, __LINE__, para.event_id);

	while (loop_count)
	{
		ret = history_event_read(p_fs, offset, item_len, &item);
		if (ret == SF_OK)
		{
			event_classify = history_event_classify_get(item.event_id);
			EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] event_classify = %d \n", __func__, __LINE__, event_classify);
			EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] item: %d-%d-%d %d:%d:%d\n", __func__, __LINE__, item.event_time.year, \
										item.event_time.mon, item.event_time.day, item.event_time.hour, item.event_time.min, item.event_time.sec);
			EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] item: event_id = %d \n", __func__, __LINE__, item.event_id);
			if ((para.filter_classify == event_classify) || (para.filter_classify == ALL_EVENT))
			{
				if ((para.filter_criteria == FILTER_ALL) || \
					((para.filter_criteria == FILTER_ID) && (para.event_id == item.event_id)) || \
					((para.filter_criteria == FILTER_DATE) && (para.year == item.event_time.year) && (para.mon == item.event_time.mon) && (para.day == item.event_time.day)) || \
					((para.filter_criteria == FILTER_ID_DATE) && (para.event_id == item.event_id) && (para.year == item.event_time.year) && (para.mon == item.event_time.mon) && (para.day == item.event_time.day)))
				{
					memcpy((int8_t *)p_data, &item, item_len);
					p_data = (int8_t *)p_data + item_len;
					data_num++;
				}
				else
				{
					EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] filter criteria not match \n", __func__, __LINE__);
				}
			}
			else
			{
				EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] filter classify not match \n", __func__, __LINE__);
			}
		}
		offset -= item_len;
		loop_count--;
	}

	*p_data_num = data_num;
	EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] data_num = %d \n", __func__, __LINE__, data_num);

	return SF_OK;
}

