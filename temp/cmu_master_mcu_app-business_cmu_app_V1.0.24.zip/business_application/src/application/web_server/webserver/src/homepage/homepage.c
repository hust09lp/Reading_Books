#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<unistd.h>
#include"cJSON.h"
#include"homepage.h"
#include"common.h"
#include"web_data_interface.h"
#include "sofar_errors.h"
#include "fault_text.h"
#include"data_shm.h"
#include"sdk_shm.h"
#include "operation_log.h"
#include "web_broker.h"
 
void get_submatrix_info(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_conf;
    cJSON *p_resp_root;
    cJSON *p_resp_item;
    cJSON *p_resp_array;
    uint8_t response[128];
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    uint8_t i;
    int8_t ret;
    home_page_container_t container_info;
    telemetry_data_t *pcs_telemetry_data = sdk_shm_pcs_telemetry_data_get();
    internal_shared_data_t *p_shared_data = internal_shared_data_get();
    power_module_telemetry_info_t *module_info = NULL;

    p_shared_data->csu_hb_recv_flag = 1;
    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
    {
        strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
    }
    else
    {
        memcpy(request_body,p_msg->body.p,p_msg->body.len);        
    }
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        print_log("parse request failed.");
        build_empty_response(response,202,"parse request failed.");
        http_back(p_nc,response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action,"getSubMatrixInfo"))
    {
        print_log("action is not right.");
        build_empty_response(response,203,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
    cJSON_Delete(p_request);
 
    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed.");
        return;
    }
    
    p_resp_array = cJSON_CreateArray();
    if(p_resp_array == NULL)
    {
        print_log("create json array failed.");
        cJSON_Delete(p_resp_root);
        return;
    }
 
    if(home_page_container_get(&container_info) != 0)
    {
        cJSON_Delete(p_resp_root);
        cJSON_Delete(p_resp_array);
        return;
    }
 
    for(i=0;i<1;i++)
    {
        p_resp_item = cJSON_CreateObject();
        if(p_resp_item == NULL)
        {
            print_log("create json obj failed.");
            cJSON_Delete(p_resp_root);
            cJSON_Delete(p_resp_array);
            return;
        }
        module_info = &pcs_telemetry_data->power_module_telemetry_info[i];
        cJSON_AddNumberToObject(p_resp_item,"busSideVoltage",container_info.total_voltage);  //母线电压
        cJSON_AddNumberToObject(p_resp_item,"totalPower",module_info->active_power / 100.0); //充放电总功率
        cJSON_AddNumberToObject(p_resp_item,"gridVoltRS",module_info->grid_volt_rs/10.0);
        cJSON_AddNumberToObject(p_resp_item,"gridVoltST",module_info->grid_volt_st/10.0);
        cJSON_AddNumberToObject(p_resp_item,"gridVoltTR",module_info->grid_volt_tr/10.0);
        cJSON_AddNumberToObject(p_resp_item, "systemstatus", container_info.cmu_sys_state);
        cJSON_AddItemToArray(p_resp_array,p_resp_item);
    }
    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddItemToObject(p_resp_root,"data",p_resp_array);
    cJSON_AddStringToObject(p_resp_root,"msg","get submatrix successful");
 
    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);
 
    cJSON_Delete(p_resp_root);
    free(p);
 
    http_back(p_nc,response);
}
 
 /**
 * @brief      根据历史事件的故障ID，获取故障类型的显示文本
 * @param      [in] event_id     历史事件的故障ID
 * @param      [out] buff         获取到的故障类型显示文本
 * @return     执行结果
 * @retval  =0: 成功
 * @retval  <0: 失败，返回错误代码
 */
static int32_t home_page_fault_type_text_get(const fault_text_language_e lan, uint16_t event_id, int8_t *buff)
{
    int32_t ret = SF_OK;
    uint8_t i;
    uint16_t start_point;
    uint16_t end_point;
    uint16_t text_index;
    int8_t text_temp[FAULT_NAME_TEXT_LEN];
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get();
 
    if (buff == NULL)
    {
        print_log("null pointer.");
        return SF_ERR_PARA;
    }
 
    // CMU系统
    start_point = CMU_FAULT_START;
    end_point   = CMU_FAULT_END;
    if ((event_id >= start_point) && (event_id <= end_point))
    {
        text_index = event_id - start_point;
        ret = cmu_fault_text_get(lan, text_index, text_temp);
        if (ret == SF_OK)
        {
            snprintf((char*)buff, FAULT_NAME_TEXT_LEN, text_temp);
        }
        return ret;
    }
 
    // 集装箱
    start_point = CONTAINER_FAULT_START;
    end_point   = CONTAINER_FAULT_END;
    if ((event_id >= start_point) && (event_id <= end_point))
    {
        if ((event_id - start_point >= CONTAINER_COOLED_FAULT_OFFSET) && (event_id - start_point < (CONTAINER_COOLED_FAULT_OFFSET + CONTAINER_COOLED_FAULT_NUM)))
        {
            text_index = event_id - start_point - CONTAINER_COOLED_FAULT_OFFSET;
            ret = cooled_fault_reason_get(lan, p_para_data->dynamic_ring.lc_type, COOLED_FIELD_FAULT_NAME, text_index, text_temp);
            if (SF_OK != ret)
            {
                // json故障表没有查找到的情况下执行
                text_index = event_id - start_point;
                ret = container_fault_text_get(lan, text_index, text_temp);
                if (ret == SF_OK)
                {
                    snprintf((char*)buff, FAULT_NAME_TEXT_LEN, text_temp);
                }
            }
            else
            {
                snprintf((char*)buff, FAULT_NAME_TEXT_LEN, text_temp);
            }
        }
        else
        {
            text_index = event_id - start_point;
            ret = container_fault_text_get(lan, text_index, text_temp);
            if (ret == SF_OK)
            {
                snprintf((char*)buff, FAULT_NAME_TEXT_LEN, text_temp);
            }
        }
        return ret;
    }
 
    // 电池簇
    for (i = 0; i < BCU_DEVICE_NUM; i++)
    {
        start_point = BATTERY_CLUSTER_1_FAULT_START + i * BATTERY_CLUSTER_INTERVAL;    // 0x171 + i * 0x100
        end_point   = BATTERY_CLUSTER_1_FAULT_END + i * BATTERY_CLUSTER_INTERVAL;    // 0x250 + i * 0x100
        if ((event_id >= start_point) && (event_id <= end_point))
        {
            break;
        }
    }
    if (i < BCU_DEVICE_NUM)
    {
        text_index = event_id - start_point;
        ret = cluster_fault_text_get(lan, text_index, text_temp);
        if (ret == SF_OK)
        {
            snprintf((char*)buff, FAULT_NAME_TEXT_LEN, text_temp);
        }
    }
    else
    {
        ret = SF_ERR_PARA;
    }
 
    // PCS模块
    start_point = PCS_FAULT_START;
    end_point   = PCS_FAULT_END;
    if ((event_id >= start_point) && (event_id <= end_point))
    {
        text_index = event_id - start_point;
        ret = pcs_fault_text_get(lan, text_index, text_temp);
        if (ret == SF_OK)
        {
            snprintf((char*)buff, FAULT_NAME_TEXT_LEN, text_temp);
        }
        return ret;
    }
 
    return ret;
}
 
void get_container_info(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
    cJSON *p_resp_item;
    uint8_t response[128];
    uint8_t *p_action;
    uint8_t *p;
    uint8_t i;
    uint8_t request_body[1024] = {0};
    home_page_container_t container_info;
    battery_cluster_page_t cluster_info;
    int32_t comm_status_array[4];  //4个电池簇的通讯状态
    int32_t ret;
    history_event_new_t event_item[FUALT_LOG_LATEST_5_ITEM];
    operation_log_t operation_item[OPERATION_LOG_LATEST_5_ITEM];
    uint32_t item_num = 0;
    uint8_t lc_sta;
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
    {
        strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
    }
    else
    {
        memcpy(request_body,p_msg->body.p,p_msg->body.len);        
    }
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        print_log("parse request failed.");
        build_empty_response(response,202,"parse request failed.");
        http_back(p_nc,response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action,"getBatteryInfo"))
    {
        print_log("action is not right.");
        build_empty_response(response,203,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
 
    // index = cJSON_GetObjectItem(p_request,"batIndex")->valueint;  //暂时用不到，因为我们的监控系统当前只支持一个集装箱
    cJSON_Delete(p_request);
 
    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed.");
        return;
    }
    cJSON_AddNumberToObject(p_resp_root,"code",200);
 
    p_resp_item = cJSON_CreateObject();
    if(p_resp_item == NULL)
    {
        print_log("create json obj failed.");
        cJSON_Delete(p_resp_root);
        return;
    }
 
    if(home_page_container_get(&container_info) != 0)
    {
        cJSON_Delete(p_resp_root);
        cJSON_Delete(p_resp_item);
        return;
    }
    cJSON_AddNumberToObject(p_resp_item,"workStatus",container_info.cmu_sys_state);  //真实数据
    cJSON_AddNumberToObject(p_resp_item,"voltage",container_info.total_voltage); //电压
    //如果不是运行状态并且当前电流绝对值小于20A,排除残余电流的影响
    if((container_info.cmu_sys_state != 2) && (abs(container_info.total_current) < 20))
    {
        container_info.total_current = 0;
    }
    cJSON_AddNumberToObject(p_resp_item,"current",container_info.total_current);  //电流
    cJSON_AddNumberToObject(p_resp_item,"power",container_info.charge_discharge_power); //功率
    cJSON_AddNumberToObject(p_resp_item,"soc",container_info.average_SOC/10.0);  //soc
    cJSON_AddNumberToObject(p_resp_item,"temperature",container_info.cabinet_temperature1/10.0);//环境温度1
    cJSON_AddNumberToObject(p_resp_item,"temperature2",container_info.cabinet_temperature2/10.0);//环境温度2
    cJSON_AddNumberToObject(p_resp_item,"humidity",container_info.cabinet_humidity1/10.0);//环境湿度1
    cJSON_AddNumberToObject(p_resp_item,"humidity2",container_info.cabinet_humidity2/10.0);//环境湿度2
    cJSON_AddNumberToObject(p_resp_item,"liquidCoolingStatus",lc_sta);//液冷机组状态
    cJSON_AddNumberToObject(p_resp_item,"effluentTemp",container_info.outlet_temperature_LC/10.0); //
    cJSON_AddNumberToObject(p_resp_item,"ascentTemp",container_info.inlet_temperature_LC/10.0);
    cJSON_AddNumberToObject(p_resp_item,"effluentPressure",container_info.outlet_pressure_LC/100.00);
    cJSON_AddNumberToObject(p_resp_item,"ascentPressure",container_info.inlet_pressure_LC/100.00);
    cJSON_AddNumberToObject(p_resp_item,"batteryStormakee",container_info.battery_door_status); //电池仓门磁状态
    cJSON_AddNumberToObject(p_resp_item,"batStoreStaus",container_info.battery_flood_status); //电池仓水浸状态
    cJSON_AddNumberToObject(p_resp_item,"equipStore",container_info.equipment_door_status);  //设备仓门磁状态
    cJSON_AddNumberToObject(p_resp_item,"equipStoreStatus",container_info.equipment_flood_status); //设备仓水浸状态
	cJSON_AddNumberToObject(p_resp_item, "lc_type", p_para_data->dynamic_ring.lc_type); //液冷机组 型号 0:美的  1:空调国际  2:视源
 
    cJSON_AddItemToObject(p_resp_root,"sysStatus",p_resp_item);  //将信息加入进去

    /**以下是添加五条操作日志**/
    ret = home_page_operation_log_latest_5_item_get((void *)operation_item, &item_num);
    if ((ret < 0) || (item_num > FUALT_LOG_LATEST_5_ITEM))
    {
        item_num = 0;
    }
    cJSON *p_op_item;
    cJSON *p_op_array = cJSON_CreateArray();
    if(p_op_array == NULL)
    {
        print_log("create json array failed.");
        cJSON_Delete(p_resp_root);
        return;
    }
 
    for(uint8_t i = 0; i < item_num; i++)
    {
        p_op_item = cJSON_CreateObject();
        if(p_op_item == NULL)
        {
            print_log("create json obj failed.");
            cJSON_Delete(p_op_array); 
            cJSON_Delete(p_resp_root);
            return;
        }
        /*操作日志类型,转换为ID传输*/
        cJSON_AddNumberToObject(p_op_item,"opType", get_operationid_by_name(operation_item[i].op_type));
        cJSON_AddStringToObject(p_op_item,"timeStamp",operation_item[i].time_stamp);
        cJSON_AddItemToArray(p_op_array,p_op_item);
    }
    cJSON_AddItemToObject(p_resp_root,"opLog",p_op_array); //将五条操作日志加入到resp_root里面
 
    /**以下是添加五条故障日志**/
    ret = home_page_fault_log_latest_5_item_get((void *)event_item, &item_num);
    if ((ret < 0) || (item_num > FUALT_LOG_LATEST_5_ITEM))
    {
        item_num = 0;
    }
    cJSON *p_fault_item;
    cJSON *p_fault_array = cJSON_CreateArray();
    if(p_fault_array == NULL)
    {
        print_log("create json array failed.");
        cJSON_Delete(p_resp_root);
        return;
    }
 
    for(uint8_t i = 0; i < item_num; i++)
    {
        p_fault_item = cJSON_CreateObject();
        if(p_fault_item == NULL)
        {
            print_log("create json obj failed.");
            cJSON_Delete(p_fault_array); 
            cJSON_Delete(p_resp_root);
            return;
        }
    
        /*只传输故障ID,前端解析*/
        cJSON_AddNumberToObject(p_fault_item, "faultType", event_item[i].event_id);
        // 故障时间
        cJSON_AddStringToObject(p_fault_item, "timeStamp", event_item[i].start_time);
        cJSON_AddItemToArray(p_fault_array,p_fault_item);
    }
    cJSON_AddItemToObject(p_resp_root,"faultLog",p_fault_array); //将五条操作日志加入到resp_root里面
 
    cluster_info_page_get(&cluster_info);  //获取10个电池簇的通信状态
    for(i=0; i<4; i++)
    {
        comm_status_array[i] = cluster_info.battery_cluster_info[i].BCU_comm_status;
    }
    cJSON_AddItemToObject(p_resp_root,"clusterSwitch",cJSON_CreateIntArray(comm_status_array,4));
    cJSON_AddItemToObject(p_resp_root,"communicationSta",cJSON_CreateIntArray(comm_status_array,4));
    cJSON_AddNumberToObject(p_resp_root, "acContactorStatus", (p_telematic_data->container_system_status_info[0] & BIT(3)) ? 1 : 0);
    cJSON_AddStringToObject(p_resp_root,"msg","get getBatteryInfo successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_resp_root);
 
    http_back(p_nc,p);
    free(p);
}
 
void get_cmu_sysinfo(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
    cJSON *p_resp_item;
    uint8_t request_body[1024] = {0};
    uint8_t response[128];
    uint8_t *p_action;  
    uint8_t *p;
    battery_cluster_page_t cluster_info;
    home_page_container_t container_info;
    home_page_pcs_info_t pcs_info;
    uint16_t tmp_soh = 0;
    uint8_t BCU_cnt = 0;
 
    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
    {
        strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
    }
    else
    {
        memcpy(request_body,p_msg->body.p,p_msg->body.len);        
    }
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        print_log("parse request failed.");
        build_empty_response(response,202,"parse request failed.");
        http_back(p_nc,response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action,"getCMUSystemInfo"))
    {
        print_log("action is not right.");
        build_empty_response(response,203,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
    cJSON_Delete(p_request);
 
    p_resp_item = cJSON_CreateObject();
    if(p_resp_item == NULL)
    {
        print_log("create json obj failed.");
        return;
    }
    home_page_container_get(&container_info);
    home_page_pcs_info_get(&pcs_info);
    cluster_info_page_get(&cluster_info);
 
    for(uint8_t i=0;i<BCU_DEVICE_NUM;i++)
    {
        if(cluster_info.battery_cluster_info[i].BCU_comm_status == 1)
        {
            tmp_soh += cluster_info.battery_cluster_info[i].average_SOH_monomer;
            BCU_cnt++;
        }
        
    }
    if(BCU_cnt != 0)
    {
        tmp_soh = tmp_soh / BCU_cnt;
    }
    
    cJSON_AddNumberToObject(p_resp_item, "systemstatus", container_info.cmu_sys_state);
    cJSON_AddNumberToObject(p_resp_item, "batVolt", container_info.total_voltage);
    cJSON_AddNumberToObject(p_resp_item, "batCurrent", container_info.total_current);
    cJSON_AddNumberToObject(p_resp_item, "acVolt", pcs_info.grid_volt_r/10.0);
    cJSON_AddNumberToObject(p_resp_item, "caVolt", pcs_info.grid_volt_s/10.0);
    cJSON_AddNumberToObject(p_resp_item, "bcVolt", pcs_info.grid_volt_t/10.0);
    cJSON_AddNumberToObject(p_resp_item, "acCurrent", (pcs_info.ac_current_r/10.0));
    cJSON_AddNumberToObject(p_resp_item, "caCurrent", (pcs_info.ac_current_s/10.0));
    cJSON_AddNumberToObject(p_resp_item, "bcCurrent", (pcs_info.ac_current_t/10.0));
    cJSON_AddNumberToObject(p_resp_item, "power", container_info.charge_discharge_power);
    cJSON_AddNumberToObject(p_resp_item, "ACPower", pcs_info.active_power/100.0);
    cJSON_AddNumberToObject(p_resp_item, "chg_dischg_flag", container_info.chg_dischg_forbid);
    cJSON_AddNumberToObject(p_resp_item, "lc_sofar_mode", container_info.lc_sofar_mode);
    //停机、待机状态显示电池的正负绝缘阻抗
    if((container_info.cmu_sys_state == 0) || (container_info.cmu_sys_state == 1))
    {
        cJSON_AddNumberToObject(p_resp_item, "Insulation", cluster_info.battery_cluster_info[0].negative_insulation_resistance);
    }
    //其他状态显示PCS阻抗
    else
    {
        cJSON_AddNumberToObject(p_resp_item, "Insulation", pcs_info.iso_resistence);
    }
    cJSON_AddNumberToObject(p_resp_item, "soc", container_info.average_SOC/10.0);
    cJSON_AddNumberToObject(p_resp_item, "soh", tmp_soh);
    cJSON_AddNumberToObject(p_resp_item, "lceffluentTemp", container_info.outlet_temperature_LC/10.0);
    cJSON_AddNumberToObject(p_resp_item, "lcascentTemp", container_info.inlet_temperature_LC/10.0);
    cJSON_AddNumberToObject(p_resp_item, "lceffluentPressure", container_info.outlet_pressure_LC);
    cJSON_AddNumberToObject(p_resp_item, "lcascentPressure", container_info.inlet_pressure_LC);
    cJSON_AddNumberToObject(p_resp_item, "batteryFloodStatus", container_info.battery_flood_status);
    cJSON_AddNumberToObject(p_resp_item, "batteryDoorStatus", container_info.battery_door_status);
    cJSON_AddNumberToObject(p_resp_item, "equipmentFloodStatus", container_info.equipment_flood_status);
    cJSON_AddNumberToObject(p_resp_item, "equipmentDoorStatus", container_info.equipment_door_status);
    cJSON_AddNumberToObject(p_resp_item, "liquidCoolingStatus", container_info.run_mode_LC);
    cJSON_AddNumberToObject(p_resp_item, "chg_limt_power", container_info.chg_limit_power);
    cJSON_AddNumberToObject(p_resp_item, "dischg_limt_power", container_info.dischg_limit_power);
 
    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        cJSON_Delete(p_resp_item);
        print_log("create json obj failed.");
        return;
    }
    cJSON_AddNumberToObject(p_resp_root, "code", 200);
    cJSON_AddItemToObject(p_resp_root, "data", p_resp_item);
    cJSON_AddStringToObject(p_resp_root, "msg", "get cmu system info successful");
 
    p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_resp_root);
 
    http_back(p_nc,p);
    free(p);
}
 
 
void csu_set_sys_fault(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    uint8_t request_body[1024] = {0};
    uint8_t response[128];
    uint8_t *p_action;  
    uint8_t csu_status = 0;
    telematic_data_t *p_telematic_data = NULL;
 
    p_telematic_data = sdk_shm_telematic_data_get();
 
    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
    {
        strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
    }
    else
    {
        memcpy(request_body,p_msg->body.p,p_msg->body.len);        
    }
 
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        print_log("parse request failed.");
        build_empty_response(response,202,"parse request failed.");
        http_back(p_nc,response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action,"csuFaultSet"))
    {
        print_log("action is not right.");
        build_empty_response(response,203,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
 
    csu_status = cJSON_GetObjectItem(p_request,"csuStatus")->valueint;
    if(csu_status)
    {
        p_telematic_data->CMU_system_fault_info[2] |= (1 << 2);
    }
    else
    {
        p_telematic_data->CMU_system_fault_info[2] &= ~(1 << 2);;
    }
 
    build_empty_response(response,200,"set success");
    http_back(p_nc,response);
    cJSON_Delete(p_request);
 
}

void csu_set_sys_warn(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    uint8_t request_body[1024] = {0};
    uint8_t response[128];
    uint8_t *p_action;  
    uint8_t csu_warn = 0;
    telematic_data_t *p_telematic_data = NULL;
 
    p_telematic_data = sdk_shm_telematic_data_get();
 
    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
    {
        strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
    }
    else
    {
        memcpy(request_body,p_msg->body.p,p_msg->body.len);        
    }
 
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        print_log("parse request failed.");
        build_empty_response(response,202,"parse request failed.");
        http_back(p_nc,response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action,"csuWarnStatusSet"))
    {
        print_log("action is not right.");
        build_empty_response(response,203,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
 
    csu_warn = cJSON_GetObjectItem(p_request,"csuStatus")->valueint;
    if(csu_warn)
    {
        p_telematic_data->container_system_warn_info[0] |= (1 << 1);
    }
    else
    {
        p_telematic_data->container_system_warn_info[0] &= ~(1 << 1);;
    }
 
    build_empty_response(response,200,"set success");
    http_back(p_nc,response);
    cJSON_Delete(p_request);
 
}

/**
 * @brief    获取CMU认证版本信息
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void cmu_sys_version_info_get(struct mg_connection *p_nc,struct http_message *p_msg)
{
    uint8_t ret = 0;
    cJSON *p_request = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t response[1024] = {0}; 
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t i;
    uint8_t request_body[1024] = {0};
    char char_buff[4];
    char product_model[32] = {0};

    constant_parameter_data_t *p_constant_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    memcpy(request_body,p_msg->body.p,p_msg->body.len);	
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getSystemVersionInfo"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);


    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        return;
    }
    memset(char_buff,0,sizeof(char_buff));
    memset(product_model,0,sizeof(product_model));
    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddStringToObject(p_resp_root,"SoftwareVersion", "V000001");
    cJSON_AddStringToObject(p_resp_root,"HardwareVersion", "V000001");
    cJSON_AddStringToObject(p_resp_root,"devSN",(char *)p_constant_data->device_sn);
    char_buff[0] = (char)p_constant_data->device_sn[6];
    char_buff[1] = (char)p_constant_data->device_sn[7];
    char_buff[2] = (char)p_constant_data->device_sn[8];
    snprintf(product_model ,sizeof(product_model),"ESS-%sKLA-SA1",char_buff);
    cJSON_AddStringToObject(p_resp_root,"ProductModel",product_model);     // 产品机型

    cJSON_AddStringToObject(p_resp_root,"msg","success");

    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);
    cJSON_Delete(p_resp_root);
    free(p);
    http_back(p_nc,response);
}

/**
 * @brief cmu系统信息模块初始化
 * @return void
 */
void homepage_info_module_init(void)
{
    /*获取子阵信息*/
	if(!web_func_attach("/homePage/getSubMatrixInfo", get_submatrix_info))
	{
		print_log("[/homePage/getSubMatrixInfo] attach failed");
	}
    /*获取操作日志*/
	if(!web_func_attach("/homePage/getOperationLog", get_operation_log))
	{
		print_log("[/homePage/getOperationLog] attach failed");
	}
	/*导出操作日志*/
	if(!web_func_attach("/homePage/getOperationList", export_operation_List))
	{
		print_log("[/homePage/getOperationList] attach failed");
	}
    /*获取故障*/
	if(!web_func_attach("/homePage/getFaultLog", get_fault_log))
	{
		print_log("[/homePage/getFaultLog] attach failed");
	}
	/*导出故障日志*/
	if(!web_func_attach("/homePage/getFaultLogList", export_fault_List))
	{
		print_log("[/homePage/getFaultLogList] attach failed");
	}
	/*获取电池(集装箱)信息*/
	if(!web_func_attach("/homePage/getBatteryInfo", get_container_info))
	{
		print_log("[/homePage/getBatteryInfo] attach failed");
	}
    	/*获取某天的充放电*/
	if(!web_func_attach("/homePage/getDailyChargeDischarge", get_daily_charge_discharge))
	{
		print_log("[/homePage/getDailyChargeDischarge] attach failed");
	}
	/*获取某月的充放电*/
	if(!web_func_attach("/homePage/getMonthlyChargeDischarge", get_monthly_charge_discharge))
	{
		print_log("[/homePage/getMonthlyChargeDischarge] attach failed");
	}
	/*获取某年的充放电*/
	if(!web_func_attach("/homePage/getYearChargeDischarge", get_yearly_charge_discharge))
	{
		print_log("[/homePage/getYearChargeDischarge] attach failed");
	}
	/*获取总的充放电*/
	if(!web_func_attach("/homePage/getTotalChargeDischarge", get_total_charge_discharge))
	{
		print_log("[/homePage/getTotalChargeDischarge] attach failed");
	}
	/*获取某一天的充放电功率*/
	if(!web_func_attach("/homepage/getDailyPower", get_daily_power))
	{
		print_log("[/homepage/getDailyPower] attach failed");
	}
	/*获取CMU认证版本信息*/
	if(!web_func_attach("/homePage/getSystemVersionInfo", cmu_sys_version_info_get))
	{
		print_log("[/homePage/getSystemVersionInfo] attach failed");
	}
	/*获取CMU系统信息*/
	if(!web_func_attach("/homePage/getCMUSystemInfo", get_cmu_sysinfo))
	{
		print_log("[/homePage/getCMUSystemInfo] attach failed");
	}
	/*CSU同步故障状态*/
	if(!web_func_attach("/homePage/csuFaultSet", csu_set_sys_fault))
	{
		print_log("[/homePage/csuFaultSet] attach failed");
	}
    /*CSU同步告警状态*/
	if(!web_func_attach("/homePage/csuWarnStatusSet", csu_set_sys_warn))
	{
		print_log("[/homePage/csuWarnStatusSet] attach failed");
	}
	/*响应远程开机命令*/
	if(!web_func_attach("/controlCmd/remotePowerOnCmd", do_remote_power_on))
	{
		print_log("[/controlCmd/remotePowerOnCmd] attach failed");
	}
	/*响应远程关机命令*/
	if(!web_func_attach("/controlCmd/remotePowerOffCmd", do_remote_power_off))
	{
		print_log("[/controlCmd/remotePowerOffCmd] attach failed");
	}
	/*响应故障复位命令*/
	if(!web_func_attach("/controlCmd/faultReset", do_fault_reset))
	{
		print_log("[/controlCmd/faultReset] attach failed");
	}
	/*响应开排气扇命令*/
	if(!web_func_attach("/controlCmd/exhaustFanOn", do_exhaust_fan_on))
	{
		print_log("[/controlCmd/exhaustFanOn] attach failed");
	}
	/*响应关排气扇命令*/
	if(!web_func_attach("/controlCmd/exhaustFanOff", do_exhaust_fan_off))
	{
		print_log("[/controlCmd/exhaustFanOff] attach failed");
	}
	/*节能降耗*/
	if(!web_func_attach("/sysManager/sysStateSet", do_energy_saving_set))
	{
		print_log("[/sysManager/sysStateSet] attach failed");
	}

}