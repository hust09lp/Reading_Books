#include "js_api_common.h"
#include "json_utils.h" 
#include "operation_log.h"

#include<stdio.h>
#include<stdlib.h>
#include"debugmanage.h"
#include"cJSON.h"
#include"common.h"
#include"web_data_interface.h"
#include"sdk_shm.h"
#include "sofar_errors.h"
#include "sofar_type.h"
#include "web_broker.h"
#include "sdk_log.h"
#include <string.h>

#define WEB_BIT_0   (1<<0)
#define WEB_BIT_1   (1<<1)
#define WEB_BIT_2   (1<<2)
#define WEB_BIT_3   (1<<3)
#define WEB_BIT_4   (1<<4)
#define WEB_BIT_5   (1<<5)
#define WEB_BIT_6   (1<<6)
#define WEB_BIT_7   (1<<7)

#define PATH_DEVICE_SN_FILE     "/user/conf/dev_sn"



enum{
    Continue = 100,
    Switching_Protocols = 101,
    Processing = 102,
    OK = 200,
    Created = 201,
    Accepted = 202,
    Non_Authoriative_Information = 203,
    No_Content = 204,
    Reset_Content = 205,
    Partial_Content = 206,
    Multi_Status = 207,
    Multiple_Choices = 300,
    Moved_Permanently = 301,
    Found = 302,
    See_Other = 303,
    Not_Modified = 304,
    Use_Proxy = 305,
    Unused = 306,
    Bad_Request = 400,
    File_Not_Found = 404,
};

typedef struct
{
    int16_t monomer_OVP_warn_threshold_2;               // 单体电压2级过压报警阈值  精度：0.001V 偏移量：0
    int16_t monomer_UVP_warn_threshold_2;               // 单体电压2级欠压报警阈值  精度：0.001V 偏移量：0
    int16_t monomer_UVP_warn_threshold_3;               // 单体电压3级欠压报警阈值  精度：0.001V 偏移量：0

    int16_t PACK_OVP_warn_threshold_2;                  // PACK电压2级过压报警阈值  精度：0.1V 偏移量：0
    int16_t PACK_UVP_warn_threshold_2;                  // PACK电压2级欠压报警阈值  精度：0.1V 偏移量：0
    int16_t PACK_UVP_warn_threshold_3;                  // PACK电压3级欠压报警阈值  精度：0.1V 偏移量：0
}ft_cap_test_bat_para_data_t;

const ft_cap_test_bat_para_data_t g_enter_ft_cap_test_para = {3600, 2500, 2400, 1728, 1200, 1152};


static void get_debug_info(const debug_manage_page_read_t *p_debug_info,const debug_manage_e type,int32_t *data_array)
{
    uint8_t i;
    switch(type)
	{
		case MAJOR_POS_RELAY_DO1:
            for(i = 0;i < BCU_DEVICE_NUM;i++)
            {
                data_array[i] = ((p_debug_info->battery_cluster_status_info[i][1] & WEB_BIT_0) == 0) ? 0 : 1;
            }
            break;
        case MAJOR_NEGA_RELAY_DO3:
			for(i = 0;i < BCU_DEVICE_NUM;i++)
            {
                data_array[i] = ((p_debug_info->battery_cluster_status_info[i][1] & WEB_BIT_2) == 0) ? 0 : 1;
            }
            break;
        case PRECHARGE_RELAY_DO2:
			for(i = 0;i < BCU_DEVICE_NUM;i++)
            {
                data_array[i] = ((p_debug_info->battery_cluster_status_info[i][1] & WEB_BIT_1) == 0) ? 0 : 1;
            }
            break;
        case AUX_ELEC_RELAY_DO7:
		    for(i = 0;i < BCU_DEVICE_NUM;i++)
            {
                data_array[i] = ((p_debug_info->battery_cluster_status_info[i][1] & WEB_BIT_6) == 0) ? 0 : 1;
            }
            break;
        case RUNNING_LED_DO5:
			for(i = 0;i < BCU_DEVICE_NUM;i++)
            {
                data_array[i] = ((p_debug_info->battery_cluster_status_info[i][1] & WEB_BIT_4) == 0) ? 0 : 1;
            }
            break;
        case FAULT_LED_DO6:
			for(i = 0;i < BCU_DEVICE_NUM;i++)
            {
                data_array[i] = ((p_debug_info->battery_cluster_status_info[i][1] & WEB_BIT_5) == 0) ? 0 : 1;
            }
            break;
        case MAIN_POS_FEEDBACK_DI1:
			for(i = 0;i < BCU_DEVICE_NUM;i++)
            {
                data_array[i] = ((p_debug_info->battery_cluster_status_info[i][0] & WEB_BIT_0) == 0) ? 0 : 1;
            }
            break;
        case MAIN_NEGA_FEEDBACK_DI3:
			for(i = 0;i < BCU_DEVICE_NUM;i++)
            {
                data_array[i] = ((p_debug_info->battery_cluster_status_info[i][0] & WEB_BIT_2) == 0) ? 0 : 1;
            }
            break;
        case AUX_ELEC_SWITCH_DI2: //充电过温
			for(i = 0;i < BCU_DEVICE_NUM;i++)
            {
                data_array[i] = ((p_debug_info->battery_cluster_status_info[i][0] & WEB_BIT_1) == 0) ? 0 : 1;
            }
            break;
        case EMERGENCY_STOP_DI4: //充电欠温
			for(i = 0;i < BCU_DEVICE_NUM;i++)
            {
                data_array[i] = ((p_debug_info->battery_cluster_status_info[i][0] & WEB_BIT_3) == 0) ? 0 : 1;
            }
            break;
        case CMUFAULT_SIGNAL_DI5:
			for(i = 0;i < BCU_DEVICE_NUM;i++)
            {
                data_array[i] = ((p_debug_info->battery_cluster_status_info[i][0] & WEB_BIT_4) == 0) ? 0 : 1;
            }
            break;
        case OUTPUT_SWITCH_FEEDBACK_DI6:
		    for(i = 0;i < BCU_DEVICE_NUM;i++)
            {
                data_array[i] = ((p_debug_info->battery_cluster_status_info[i][0] & WEB_BIT_5) == 0) ? 0 : 1;
            }
            break;
        default:
            break;
    }
}

static void get_firecontrol_info(const home_page_container_t *p_container_info,const debug_firecontrol_e type,int32_t *data_array)
{
    uint8_t i;
      switch(type)
	{
		case FC_CO_CONCENTRATION:
            data_array[0] = p_container_info->composite_sensor1_CO;
            data_array[1] = p_container_info->composite_sensor2_CO;
            data_array[2] = p_container_info->composite_sensor3_CO;
            data_array[3] = p_container_info->composite_sensor4_CO;
            data_array[4] = 0;
            break;
        case FC_CO2_CONCENTRATION:
			for(i = 0;i < 5;i++)
            {
                data_array[i] = 0;
            }
            break;
        case FC_PM25_CONCENTRATION:
			data_array[0] = p_container_info->composite_sensor1_PM25;
            data_array[1] = p_container_info->composite_sensor2_PM25;
            data_array[2] = p_container_info->composite_sensor3_PM25;
            data_array[3] = p_container_info->composite_sensor4_PM25;
            data_array[4] = 0;
            break;
        case FC_TEMPERATURE:
		    data_array[0] = p_container_info->composite_sensor1_temp;
            data_array[1] = p_container_info->composite_sensor2_temp;
            data_array[2] = p_container_info->composite_sensor3_temp;
            data_array[3] = p_container_info->composite_sensor4_temp;
            data_array[4] = 0;
            break;
        default:
            break;
    }
}

void get_debug_status(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_item;
    cJSON *p_resp_root;

    uint8_t response[1024];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t i;
    uint8_t request_body[1024] = {0};
    debug_manage_page_read_t debug_info;
    battery_cluster_page_t cluster_info;
    int32_t data_array[BCU_DEVICE_NUM];
    home_page_container_t container_info;
    debug_manage_version_info_t version_info;
    uint8_t version_buff[32] = {0};

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getDebugStatus"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

    p_resp_item = cJSON_CreateObject();
    if(p_resp_item == NULL)
    {
        print_log("create json obj failed");
        return;
    }

    debug_manage_page_get(&debug_info);
    
    //电池簇信息开关
    get_debug_info(&debug_info,MAJOR_POS_RELAY_DO1,data_array);
    cJSON_AddItemToObject(p_resp_item,"majorPosRelayDO1",cJSON_CreateIntArray(data_array,4));
    get_debug_info(&debug_info,MAJOR_NEGA_RELAY_DO3,data_array);
    cJSON_AddItemToObject(p_resp_item,"majorNegaRelayDO3",cJSON_CreateIntArray(data_array,4));
    get_debug_info(&debug_info,PRECHARGE_RELAY_DO2,data_array);
    cJSON_AddItemToObject(p_resp_item,"preChargeRelayDO2",cJSON_CreateIntArray(data_array,4));
    get_debug_info(&debug_info,AUX_ELEC_RELAY_DO7,data_array);
    cJSON_AddItemToObject(p_resp_item,"auxElecRelayDO7",cJSON_CreateIntArray(data_array,4));
    get_debug_info(&debug_info,RUNNING_LED_DO5,data_array);
    cJSON_AddItemToObject(p_resp_item,"runningLedDO5",cJSON_CreateIntArray(data_array,4));
    get_debug_info(&debug_info,FAULT_LED_DO6,data_array);
    cJSON_AddItemToObject(p_resp_item,"faultLedDO6",cJSON_CreateIntArray(data_array,4));
    get_debug_info(&debug_info,MAIN_POS_FEEDBACK_DI1,data_array);
    cJSON_AddItemToObject(p_resp_item,"mainPosFeedBackDI1",cJSON_CreateIntArray(data_array,4));
    get_debug_info(&debug_info,MAIN_NEGA_FEEDBACK_DI3,data_array);
    cJSON_AddItemToObject(p_resp_item,"mainNegaFeedBackDI13",cJSON_CreateIntArray(data_array,4));
    get_debug_info(&debug_info,AUX_ELEC_SWITCH_DI2,data_array);
    cJSON_AddItemToObject(p_resp_item,"auxElecSwitchDI2",cJSON_CreateIntArray(data_array,4));
    get_debug_info(&debug_info,EMERGENCY_STOP_DI4,data_array);
    cJSON_AddItemToObject(p_resp_item,"emergencyStopDI4",cJSON_CreateIntArray(data_array,4));
    get_debug_info(&debug_info,CMUFAULT_SIGNAL_DI5,data_array);
    cJSON_AddItemToObject(p_resp_item,"cmuFaultSignalDI5",cJSON_CreateIntArray(data_array,4));
    get_debug_info(&debug_info,OUTPUT_SWITCH_FEEDBACK_DI6,data_array);
    cJSON_AddItemToObject(p_resp_item,"outputSwitchFeedBack",cJSON_CreateIntArray(data_array,4));
    cluster_info_page_get(&cluster_info);
    for(i = 0;i < BCU_DEVICE_NUM;i++)
    { 
        data_array[i] = (cluster_info.battery_cluster_info[i].BCU_comm_status == 0) ? 0 : 1; //这里通讯中断也认为是上电了
    }
    cJSON_AddItemToObject(p_resp_item,"powerCmd",cJSON_CreateIntArray(data_array,4));

    //软件版本
    debug_manage_version_info_get(&version_info);
    snprintf((char*)version_buff,sizeof(version_buff),"%c%d.%d.%d",version_info.mcu1_core_soft_version[0],
    version_info.mcu1_core_soft_version[1],version_info.mcu1_core_soft_version[2],version_info.mcu1_core_soft_version[3]);
    cJSON_AddStringToObject(p_resp_item,"mcu1CoreSwVersion",version_buff);
    snprintf((char*)version_buff,sizeof(version_buff),"%c%d.%d.%d",version_info.mcu1_app_soft_version[0],
    version_info.mcu1_app_soft_version[1],version_info.mcu1_app_soft_version[2],version_info.mcu1_app_soft_version[3]);
    cJSON_AddStringToObject(p_resp_item,"mcu1AppSwVersion",version_buff);
    snprintf((char*)version_buff,sizeof(version_buff),"V%d.%d",version_info.mcu1_hardware_version[0],version_info.mcu1_hardware_version[1]);
    cJSON_AddStringToObject(p_resp_item,"mcu1HwVersion",version_buff);

    snprintf((char*)version_buff,sizeof(version_buff),"%c%d.%d.%d",version_info.mcu2_core_soft_version[0],
    version_info.mcu2_core_soft_version[1],version_info.mcu2_core_soft_version[2],version_info.mcu2_core_soft_version[3]);
    cJSON_AddStringToObject(p_resp_item,"mcu2CoreSwVersion",version_buff);
    snprintf((char*)version_buff,sizeof(version_buff),"%c%d.%d.%d",version_info.mcu2_app_soft_version[0],
    version_info.mcu2_app_soft_version[1],version_info.mcu2_app_soft_version[2],version_info.mcu2_app_soft_version[3]);
    cJSON_AddStringToObject(p_resp_item,"mcu2AppSwVersion",version_buff);
    snprintf((char*)version_buff,sizeof(version_buff),"V%d.%d",version_info.mcu2_hardware_version[0],version_info.mcu2_hardware_version[1]);
    cJSON_AddStringToObject(p_resp_item,"mcu2HwVersion",version_buff);

    snprintf((char*)version_buff,sizeof(version_buff),"%02d.%02d",version_info.bat_software_version[0],version_info.bat_software_version[1]);
    cJSON_AddStringToObject(p_resp_item,"bmsSwVersion",version_buff);

    //液冷信息
    home_page_container_get(&container_info);
    cJSON_AddNumberToObject(p_resp_item,"lceffluentPressure",container_info.outlet_pressure_LC/100.00);
    cJSON_AddNumberToObject(p_resp_item,"lcascentPressure",container_info.inlet_pressure_LC/100.00);
    cJSON_AddNumberToObject(p_resp_item,"lceffluentTemp",container_info.inlet_temperature_LC/10.0);
    cJSON_AddNumberToObject(p_resp_item,"lcascentTemp",container_info.outlet_temperature_LC/10.0);

    //消防信息
    get_firecontrol_info(&container_info,FC_CO_CONCENTRATION,data_array);
    cJSON_AddItemToObject(p_resp_item,"coConcentration",cJSON_CreateIntArray(data_array,5));
    get_firecontrol_info(&container_info,FC_PM25_CONCENTRATION,data_array);
    cJSON_AddItemToObject(p_resp_item,"pm25Concentration",cJSON_CreateIntArray(data_array,5));
    get_firecontrol_info(&container_info,FC_TEMPERATURE,data_array);
    cJSON_AddItemToObject(p_resp_item,"temperatrue",cJSON_CreateIntArray(data_array,5));
    
    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        cJSON_Delete(p_resp_item);
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddItemToObject(p_resp_root,"data",p_resp_item);
    cJSON_AddStringToObject(p_resp_root,"msg","get debug status successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);

    cJSON_Delete(p_resp_root);
    free(p);

    http_back(p_nc,response);
}

void set_debug_status(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_item;
    uint8_t response[64];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    uint8_t cluster_index;
    operation_log_t op_log;
    uint8_t cur_user[32] = {0};
    uint8_t content[1024] = {0};
    debug_manage_page_write_t debug_manage_info;

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"setDebugStatus"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

     //此处需要详细的操作日志类型
    init_user_basic_info(&op_log);
    get_user_from_http_request(p_msg,cur_user);
    strcpy(op_log.user_name,cur_user);
    get_user_basic_info(&op_log);

    //初始化结构体
    memset(&debug_manage_info,0,sizeof(debug_manage_page_write_t));
    p_item = cJSON_GetObjectItem(p_request,"majorPosRelayDO1Devide"); //主正继电器分
    if(p_item != NULL)
    {
        cluster_index = p_item->valueint;
        cluster_index -= 1; //第几簇
        debug_manage_info.battery_DO_control_off[cluster_index] |= (1<<0);

        sprintf(op_log.op_type,"第%d簇主正继电器分",(cluster_index + 1));

        op_log.op_param1 = 0;
        op_log.op_param2 = 1;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    p_item = cJSON_GetObjectItem(p_request,"majorPosRelayDO1Join"); //主正继电器合
    if(p_item != NULL)
    {
        cluster_index = p_item->valueint;
        cluster_index -= 1; //第几簇
        debug_manage_info.battery_DO_control_on[cluster_index] |= (1<<0);

        sprintf(op_log.op_type,"第%d簇主正继电器合",(cluster_index + 1));
        op_log.op_param1 = 0;
        op_log.op_param2 = 1;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

    p_item = cJSON_GetObjectItem(p_request,"majorNegaRelayDO3Devide"); //主负继电器分
    if(p_item != NULL)
    {
        cluster_index = p_item->valueint;
        cluster_index -= 1; //第几簇
        debug_manage_info.battery_DO_control_off[cluster_index] |= (1<<2);

        sprintf(op_log.op_type,"第%d簇主负继电器分",(cluster_index + 1));
        op_log.op_param1 = 0;
        op_log.op_param2 = 1;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    p_item = cJSON_GetObjectItem(p_request,"majorNegaRelayDO3OJoin"); //主负继电器合
    if(p_item != NULL)
    {
        cluster_index = p_item->valueint;
        cluster_index -= 1; //第几簇
        debug_manage_info.battery_DO_control_on[cluster_index] |= (1<<2);

        sprintf(op_log.op_type,"第%d簇主负继电器合",(cluster_index + 1));
        op_log.op_param1 = 0;
        op_log.op_param2 = 1;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

    p_item = cJSON_GetObjectItem(p_request,"preChargeRelayDO2Devide"); //预充继电器分
    if(p_item != NULL)
    {
        cluster_index = p_item->valueint;
        cluster_index -= 1; //第几簇
        debug_manage_info.battery_DO_control_off[cluster_index] |= (1<<1);

        sprintf(op_log.op_type,"第%d簇预充继电器分",(cluster_index + 1));
        op_log.op_param1 = 0;
        op_log.op_param2 = 1;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    p_item = cJSON_GetObjectItem(p_request,"preChargeRelayDO2Join"); //预充继电器合
    if(p_item != NULL)
    {
        cluster_index = p_item->valueint;
        cluster_index -= 1; //第几簇
        debug_manage_info.battery_DO_control_on[cluster_index] |= (1<<1);

        sprintf(op_log.op_type,"第%d簇预充继电器合",(cluster_index + 1));
        op_log.op_param1 = 0;
        op_log.op_param2 = 1;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

    p_item = cJSON_GetObjectItem(p_request,"auxElecRelayDO7Devide"); //辅助继电器分
    if(p_item != NULL)
    {
        cluster_index = p_item->valueint;
        cluster_index -= 1; //第几簇
        debug_manage_info.battery_DO_control_off[cluster_index] |= (1<<6);

        sprintf(op_log.op_type,"第%d簇辅助继电器分",(cluster_index + 1));
        op_log.op_param1 = 0;
        op_log.op_param2 = 1;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    p_item = cJSON_GetObjectItem(p_request,"auxElecRelayDO7Join"); //辅助继电器合
    if(p_item != NULL)
    {
        cluster_index = p_item->valueint;
        cluster_index -= 1; //第几簇
        debug_manage_info.battery_DO_control_on[cluster_index] |= (1<<6);

        sprintf(op_log.op_type,"第%d簇辅助继电器合",(cluster_index + 1));
        op_log.op_param1 = 0;
        op_log.op_param2 = 1;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

    p_item = cJSON_GetObjectItem(p_request,"runningLedDO5Devide"); //运行显示灯分
    if(p_item != NULL)
    {
        cluster_index = p_item->valueint;
        cluster_index -= 1; //第几簇
        debug_manage_info.battery_DO_control_off[cluster_index] |= (1<<3);

        sprintf(op_log.op_type,"第%d簇运行显示灯分",(cluster_index + 1));
        op_log.op_param1 = 0;
        op_log.op_param2 = 1;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    p_item = cJSON_GetObjectItem(p_request,"runningLedDO5Join"); //运行显示灯合
    if(p_item != NULL)
    {
        cluster_index = p_item->valueint;
        cluster_index -= 1; //第几簇
        debug_manage_info.battery_DO_control_on[cluster_index] |= (1<<3);

        sprintf(op_log.op_type,"第%d簇运行显示灯合",(cluster_index + 1));
        op_log.op_param1 = 0;
        op_log.op_param2 = 1;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
   
    p_item = cJSON_GetObjectItem(p_request,"faultLedDO6Devide"); //故障显示灯分
    if(p_item != NULL)
    {
        cluster_index = p_item->valueint;
        cluster_index -= 1; //第几簇
        debug_manage_info.battery_DO_control_off[cluster_index] |= (1<<4);

        sprintf(op_log.op_type,"第%d簇故障显示灯分",(cluster_index + 1));
        op_log.op_param1 = 0;
        op_log.op_param2 = 1;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    p_item = cJSON_GetObjectItem(p_request,"faultLedDO6Join"); //故障显示灯合
    if(p_item != NULL)
    {
        cluster_index = p_item->valueint;
        cluster_index -= 1; //第几簇
        debug_manage_info.battery_DO_control_on[cluster_index] |= (1<<4);

        sprintf(op_log.op_type,"第%d簇故障显示灯合",(cluster_index + 1));
        op_log.op_param1 = 0;
        op_log.op_param2 = 1;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

    p_item = cJSON_GetObjectItem(p_request,"powerCmdDevide"); //电池簇某一簇下电
    if(p_item != NULL)
    {
        cluster_index = p_item->valueint;
        cluster_index -= 1; //第几簇
        debug_manage_info.battery_power_off |= (1<<cluster_index);

        sprintf(op_log.op_type,"第%d簇电池簇下电",(cluster_index + 1));
        op_log.op_param1 = 0;
        op_log.op_param2 = 1;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    p_item = cJSON_GetObjectItem(p_request,"powerCmdJoin"); //电池簇某一簇上电
    if(p_item != NULL)
    {
        cluster_index = p_item->valueint;
        cluster_index -= 1; //第几簇
        debug_manage_info.battery_power_on |= (1<<cluster_index);

        sprintf(op_log.op_type,"第%d簇电池簇上电",(cluster_index + 1));
        op_log.op_param1 = 0;
        op_log.op_param2 = 1;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

#if 0
    debug_manage_info.battery_power_on |= (1<<0);
    debug_manage_info.battery_power_on |= (1<<9);

    debug_manage_info.battery_DO_control_off[0] |= (1<<0);
    debug_manage_info.battery_DO_control_on[8] |= (1<<0);
#endif

    debug_manage_page_set(&debug_manage_info);  //将调试管理的值设置到共享内存中去
    cJSON_Delete(p_request);

    build_empty_response(response,200,"set debug status successful");
	http_back(p_nc,response);
}


void get_debug_pcs_switch(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_item;
    cJSON *p_resp_root;
    uint8_t response[1024];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    constant_parameter_data_t * p_constant_param_data = sdk_shm_constant_parameter_data_get();

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"PCSSwitchSet"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

	pcs_parameter_data_t * parameter_data = &(p_constant_param_data->pcs_parameter_data[0]);

    p_resp_item = cJSON_CreateObject();
    if(p_resp_item == NULL)
    {
        print_log("create json obj failed");
        return;
    }
    
    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        cJSON_Delete(p_resp_item);
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddNumberToObject(p_resp_root,"status",parameter_data->pcs_run);
    cJSON_AddStringToObject(p_resp_root,"msg","get successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);

    cJSON_Delete(p_resp_root);
    free(p);

    http_back(p_nc,response);
}

void set_debug_pcs_switch(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_item;
    uint8_t response[64];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    operation_log_t op_log;
    uint8_t cur_user[32] = {0};
    uint8_t pcs_switch;
    debug_manage_page_write_t debug_manage_info;

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"PCSSet"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

     //此处需要详细的操作日志类型
    init_user_basic_info(&op_log);
    get_user_from_http_request(p_msg,cur_user);
    strcpy(op_log.user_name,cur_user);
    get_user_basic_info(&op_log);

    //初始化结构体
    memset(&debug_manage_info,0,sizeof(debug_manage_page_write_t));
    pcs_switch = cJSON_GetObjectItem(p_request,"status")->valueint;
    if(pcs_switch)
    {
        debug_manage_info.CMU_system_control_on |= (1<<2);
        strcpy(op_log.op_type,"打开PCS开关");
        op_log.op_param1 = 0;
        op_log.op_param2 = 1;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    else
    {
        debug_manage_info.CMU_system_control_off |= (1<<2);
        strcpy(op_log.op_type,"关闭PCS开关");
        op_log.op_param1 = 0;
        op_log.op_param2 = 1;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

    debug_manage_page_set(&debug_manage_info);  //将调试管理的值设置到共享内存中去
    cJSON_Delete(p_request);

    build_empty_response(response,200,"set debug status successful");
	http_back(p_nc,response);
}


void get_debug_liquid_cooling(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_item;
    cJSON *p_resp_root;
    uint8_t response[1024];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
	common_data_t *shm = NULL;
    telematic_data_t *p_telematic = NULL;
	shm = sdk_shm_get();
    p_telematic = &shm->telematic_data;       								// 共享内存遥信数据

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"liquidCoolingGet"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

	uint8_t liquid_cooling = p_telematic->container_system_status_info[8] & 0x01;

    p_resp_item = cJSON_CreateObject();
    if(p_resp_item == NULL)
    {
        print_log("create json obj failed");
        return;
    }

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        cJSON_Delete(p_resp_item);
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddNumberToObject(p_resp_root,"status",liquid_cooling);
    cJSON_AddStringToObject(p_resp_root,"msg","get successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);

    cJSON_Delete(p_resp_root);
    free(p);

    http_back(p_nc,response);
}

void set_debug_liquid_cooling(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_item;
    uint8_t response[64];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    operation_log_t op_log;
    uint8_t cur_user[32] = {0};
    uint8_t liquid_cooling;
    debug_manage_page_write_t debug_manage_info;

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"liquidCoolingSet"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

     //此处需要详细的操作日志类型
    init_user_basic_info(&op_log);
    get_user_from_http_request(p_msg,cur_user);
    strcpy(op_log.user_name,cur_user);
    get_user_basic_info(&op_log);

    //初始化结构体
    memset(&debug_manage_info,0,sizeof(debug_manage_page_write_t));
    liquid_cooling = cJSON_GetObjectItem(p_request,"status")->valueint;
    if(liquid_cooling)
    {
        debug_manage_info.CMU_system_control_on |= (1<<1);
        strcpy(op_log.op_type,"打开液冷系统");
        op_log.op_param1 = 0;
        op_log.op_param2 = 1;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    else
    {
        debug_manage_info.CMU_system_control_off |= (1<<1);
        strcpy(op_log.op_type,"关闭液冷系统");
        op_log.op_param1 = 0;
        op_log.op_param2 = 1;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

    debug_manage_page_set(&debug_manage_info);  //将调试管理的值设置到共享内存中去
    cJSON_Delete(p_request);

    build_empty_response(response,200,"set debug status successful");
	http_back(p_nc,response);
}

void get_debug_liquid_cooling_param(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_item;
    cJSON *p_resp_root;
    uint8_t response[1024];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    common_data_t *shm = NULL;
    dynamic_ring_parameter_data_t *p_dynamic_ring_param = NULL;
	shm = sdk_shm_get();
    p_dynamic_ring_param = &shm->constant_parameter_data.dynamic_ring;      								// 共享内存遥信数据

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"liquidCoolingParamGet"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);


    p_resp_item = cJSON_CreateObject();
    if(p_resp_item == NULL)
    {
        print_log("create json obj failed");
        return;
    }

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        cJSON_Delete(p_resp_item);
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddNumberToObject(p_resp_root,"controlMode",p_dynamic_ring_param->lc_auto_mode);
    cJSON_AddNumberToObject(p_resp_root,"workMode",p_dynamic_ring_param->lc_mode);
    cJSON_AddNumberToObject(p_resp_root,"waterTemp",p_dynamic_ring_param->lc_cooling_point / 10.0);
    cJSON_AddStringToObject(p_resp_root,"msg","get successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);

    cJSON_Delete(p_resp_root);
    free(p);

    http_back(p_nc,response);
}


void set_debug_liquid_cooling_param(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_item;
    uint8_t response[64];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    operation_log_t op_log;
    uint8_t cur_user[32] = {0};
    uint8_t liquid_cooling;
    debug_manage_page_write_t debug_manage_info;
    common_data_t *shm = NULL;
    dynamic_ring_parameter_data_t *p_dynamic_ring_param = NULL;
	shm = sdk_shm_get();
    p_dynamic_ring_param = &shm->constant_parameter_data.dynamic_ring;  

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"liquidCoolingParamSet"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

     //此处需要详细的操作日志类型
    init_user_basic_info(&op_log);
    get_user_from_http_request(p_msg,cur_user);
    strcpy(op_log.user_name,cur_user);
    get_user_basic_info(&op_log);

    //初始化结构体
    memset(&debug_manage_info,0,sizeof(debug_manage_page_write_t));
    p_dynamic_ring_param->lc_auto_mode = cJSON_GetObjectItem(p_request,"controlMode")->valueint;
    p_dynamic_ring_param->lc_mode = cJSON_GetObjectItem(p_request,"workMode")->valueint;
    p_dynamic_ring_param->lc_cooling_point = (cJSON_GetObjectItem(p_request,"waterTemp")->valueint) * 10;
    //制热温度在制冷的基础上减去2度
    p_dynamic_ring_param->lc_heating_point = p_dynamic_ring_param->lc_cooling_point - 20;

    debug_manage_info.liquid_cooling_param_update_flag |= (1<<0);
    strcpy(op_log.op_type,"设置液冷参数");
    op_log.op_param1 = 0;
    op_log.op_param2 = 1;
    strcpy(op_log.op_status,"success");
    add_one_op_log(&op_log);
    
    debug_manage_page_set(&debug_manage_info);  //将调试管理的值设置到共享内存中去
    cJSON_Delete(p_request);

    build_empty_response(response,200,"set successful");
	http_back(p_nc,response);
}


void get_debug_cmu_mode(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_item;
    cJSON *p_resp_root;
    uint8_t response[1024];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    common_data_t *shm = NULL;
    constant_parameter_data_t *p_constant_param = NULL;
	shm = sdk_shm_get();
    p_constant_param = &shm->constant_parameter_data;   								// 共享内存遥信数据

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"CMUGetMode"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);


    p_resp_item = cJSON_CreateObject();
    if(p_resp_item == NULL)
    {
        print_log("create json obj failed");
        return;
    }

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        cJSON_Delete(p_resp_item);
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddNumberToObject(p_resp_root,"mode",p_constant_param->cmu_mode);
    cJSON_AddStringToObject(p_resp_root,"msg","get successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);

    cJSON_Delete(p_resp_root);
    free(p);

    http_back(p_nc,response);
}

void set_debug_cmu_mode(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_item;
    uint8_t response[64];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    operation_log_t op_log;
    uint8_t cur_user[32] = {0};
    uint8_t liquid_cooling;
    debug_manage_page_write_t debug_manage_info;
    common_data_t *shm = NULL;
    constant_parameter_data_t *p_constant_param = NULL;
	shm = sdk_shm_get();
    p_constant_param = &shm->constant_parameter_data;  

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"CMUSetMode"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

     //此处需要详细的操作日志类型
    init_user_basic_info(&op_log);
    get_user_from_http_request(p_msg,cur_user);
    strcpy(op_log.user_name,cur_user);
    get_user_basic_info(&op_log);

    //初始化结构体
    memset(&debug_manage_info,0,sizeof(debug_manage_page_write_t));
    p_constant_param->cmu_mode = cJSON_GetObjectItem(p_request,"mode")->valueint;

    debug_manage_info.cmu_mode_update_flag |= (1<<0);
    if(p_constant_param->cmu_mode)
    {
        strcpy(op_log.op_type,"设置CMU运维模式");
    }
    else
    {
        strcpy(op_log.op_type,"设置CMU运行模式");
    }
    op_log.op_param1 = 0;
    op_log.op_param2 = 1;
    strcpy(op_log.op_status,"success");
    add_one_op_log(&op_log);
    
    debug_manage_page_set(&debug_manage_info);  //将调试管理的值设置到共享内存中去
    cJSON_Delete(p_request);

    build_empty_response(response,200,"set successful");
	http_back(p_nc,response);
}


void web_reset(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
	cJSON *p_resp_item;
    uint8_t response[256];  
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t i;
    uint8_t request_body[1024] = {0};
	web_control_info_t *sdk_shm_web_data = shm_web_control_info_get();
	
    if (p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if (p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"reset"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

	sdk_shm_web_data->sys_reset |= 0x1;

	p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
		build_empty_response(response,203,"create json obj failed"); 
		http_back(p_nc,response);	
        return;
    }

	cJSON_AddNumberToObject(p_resp_root,"code",200);
	cJSON_AddStringToObject(p_resp_root,"msg","successful");
	p = cJSON_PrintUnformatted(p_resp_root);
	
	cJSON_Delete(p_resp_root);	
	http_back(p_nc,p);
	free(p);
}

void web_clear_data(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
	cJSON *p_resp_item;
    uint8_t response[256];  
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t i;
    uint8_t request_body[1024] = {0};
	web_control_info_t *sdk_shm_web_data = shm_web_control_info_get();
	
    if (p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if (p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"clearData"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

	sdk_shm_web_data->sys_reset |= (1 << 1);

	p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
		build_empty_response(response,203,"create json obj failed"); 
		http_back(p_nc,response);	
        return;
    }

	cJSON_AddNumberToObject(p_resp_root,"code",200);
	cJSON_AddStringToObject(p_resp_root,"msg","successful");
	p = cJSON_PrintUnformatted(p_resp_root);
	
	cJSON_Delete(p_resp_root);	
	http_back(p_nc,p);
	free(p);
}

void set_bat_cabinet_num(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_item;
    uint8_t response[64];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    operation_log_t op_log;
    uint8_t cur_user[32] = {0};
    debug_manage_page_write_t debug_manage_info;
    constant_parameter_data_t *p_constant_param = NULL;

    p_constant_param = sdk_shm_constant_parameter_data_get();

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"setBatCabinetNum"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

     //此处需要详细的操作日志类型
    init_user_basic_info(&op_log);
    get_user_from_http_request(p_msg,cur_user);
    strcpy(op_log.user_name,cur_user);
    get_user_basic_info(&op_log);

    //初始化结构体
    memset(&debug_manage_info,0,sizeof(debug_manage_page_write_t));
    p_constant_param->bat_cabinet_num = cJSON_GetObjectItem(p_request,"number")->valueint;

    debug_manage_info.bat_cabinet_num_update_flag |= (1<<0);
    strcpy(op_log.op_type,"设置电池仓个数");
    op_log.op_param1 = 0;
    op_log.op_param2 = 1;
    strcpy(op_log.op_status,"success");
    add_one_op_log(&op_log);
    
    debug_manage_page_set(&debug_manage_info);  //将调试管理的值设置到共享内存中去
    cJSON_Delete(p_request);

    build_empty_response(response,200,"setBatCabinetNum successful");
	http_back(p_nc,response);
}


void get_bat_cabinet_num(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
    uint8_t response[1024];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t i;
    uint8_t request_body[1024] = {0};
    constant_parameter_data_t *p_constant_param = NULL;

    p_constant_param = sdk_shm_constant_parameter_data_get();

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getBatCabinetNum"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddNumberToObject(p_resp_root,"number",p_constant_param->bat_cabinet_num);
    cJSON_AddStringToObject(p_resp_root,"msg","getBatCabinetNum successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);

    cJSON_Delete(p_resp_root);
    free(p);

    http_back(p_nc,response);
}


void set_energy_cabinet_attr(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_item;
    uint8_t response[64];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    operation_log_t op_log;
    uint8_t cur_user[32] = {0};
    debug_manage_page_write_t debug_manage_info;
    constant_parameter_data_t *p_constant_param = NULL;

    p_constant_param = sdk_shm_constant_parameter_data_get();

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"setEnergyCabinetAttr"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

     //此处需要详细的操作日志类型
    init_user_basic_info(&op_log);
    get_user_from_http_request(p_msg,cur_user);
    strcpy(op_log.user_name,cur_user);
    get_user_basic_info(&op_log);

    //初始化结构体
    memset(&debug_manage_info,0,sizeof(debug_manage_page_write_t));
    p_constant_param->energy_cabinet_FF_addr = cJSON_GetObjectItem(p_request,"EnergyCabinetFFaddr")->valueint;
    p_constant_param->energy_cabinet_num = cJSON_GetObjectItem(p_request,"EnergyCabinetNum")->valueint;

    debug_manage_info.enenrgy_cabinet_attr_update_flag |= (1<<0);
    strcpy(op_log.op_type,"设置储能柜属性");
    op_log.op_param1 = 0;
    op_log.op_param2 = 1;
    strcpy(op_log.op_status,"success");
    add_one_op_log(&op_log);
    
    debug_manage_page_set(&debug_manage_info);  //将调试管理的值设置到共享内存中去
    cJSON_Delete(p_request);

    build_empty_response(response,200,"setEnergyCabinetAttr successful");
	http_back(p_nc,response);
}


void get_energy_cabinet_attr(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_item;
    cJSON *p_resp_root;
    uint8_t response[1024];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t i;
    uint8_t request_body[1024] = {0};
    constant_parameter_data_t *p_constant_param = NULL;

    p_constant_param = sdk_shm_constant_parameter_data_get();

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getEnergyCabinetAttr"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

    p_resp_item = cJSON_CreateObject();
    if(p_resp_item == NULL)
    {
        print_log("create json obj failed");
        return;
    }

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        cJSON_Delete(p_resp_item);
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddNumberToObject(p_resp_root,"EnergyCabinetFFaddr",p_constant_param->energy_cabinet_FF_addr);
    cJSON_AddNumberToObject(p_resp_root,"EnergyCabinetNum",p_constant_param->energy_cabinet_num);
    cJSON_AddStringToObject(p_resp_root,"msg","getEnergyCabinetAttr successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);

    cJSON_Delete(p_resp_root);
    free(p);

    http_back(p_nc,response);
}

void set_bat_cluster_pack_num(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_item;
    uint8_t response[64];  
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    operation_log_t op_log;
    uint8_t cur_user[32] = {0};
    uint16_t bat_cluster_pack_num = 0;
    int32_t ret;
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数
    web_control_info_t *web_control_info = shm_web_control_info_get();

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"setBatClusterPackNum"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    bat_cluster_pack_num = cJSON_GetObjectItem(p_request,"number")->valueint;
    if ((bat_cluster_pack_num < BAT_CLUSTER_PACK_NUM_MIN) || (bat_cluster_pack_num > BAT_CLUSTER_PACK_NUM_MAX))
    {
        print_log("pack num is not right.");
		build_empty_response(response,204,"pack num is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
    }

     //此处需要详细的操作日志类型
    init_user_basic_info(&op_log);
    get_user_from_http_request(p_msg,cur_user);
    strcpy(op_log.user_name,cur_user);
    get_user_basic_info(&op_log);
    strcpy(op_log.op_status,"success");

    strcpy(op_log.op_type,"设置电池簇PACK个数");

    op_log.op_param1 = (double)(p_para_data->bat_cluster_pack_num);
    op_log.op_param2 = (double)bat_cluster_pack_num;
    
    if(p_para_data->bat_cluster_pack_num != bat_cluster_pack_num)
    {
        p_para_data->bat_cluster_pack_num = bat_cluster_pack_num;
        web_control_info->pack_num_set_flag = 1;
        add_one_op_log(&op_log);
    }

    cJSON_Delete(p_request);
    build_empty_response(response,200,"setBatClusterPackNum successful");
	http_back(p_nc,response);
}


void get_bat_cluster_pack_num(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
    uint8_t response[1024];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t i;
    uint8_t request_body[1024] = {0};
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getBatClusterPackNum"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddNumberToObject(p_resp_root,"number",p_para_data->bat_cluster_pack_num);
    cJSON_AddStringToObject(p_resp_root,"msg","getBatClusterPackNum successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);

    cJSON_Delete(p_resp_root);
    free(p);

    http_back(p_nc,response);
}


void set_energy_cabinet_sn(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_item;
    uint8_t response[64];  //
    uint8_t *p_action;
    uint8_t *p_sn;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    operation_log_t op_log;
    uint8_t cur_user[32] = {0};
    device_sn_t sn_temp;
    uint32_t sn_len;
    int32_t ret = SF_OK;
    web_control_info_t *web_control_info = shm_web_control_info_get();
    constant_parameter_data_t *p_constant_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"setEnergyCabinetSN"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    p_sn = cJSON_GetObjectItem(p_request,"sn")->valuestring;
    sn_len = strlen(p_sn);
    if (sn_len != DEVICE_SN_LEN)
    {
        print_log("sn len is not right.");
		build_empty_response(response,204,"sn len is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
    }

     //此处需要详细的操作日志类型
    init_user_basic_info(&op_log);
    get_user_from_http_request(p_msg,cur_user);
    strcpy(op_log.user_name,cur_user);
    get_user_basic_info(&op_log);

    if(strcmp(p_sn, p_constant_data->device_sn))
    {
        memset(p_constant_data->device_sn,0,sizeof(p_constant_data->device_sn));
        memcpy(p_constant_data->device_sn, p_sn, sn_len);
        web_control_info->dev_sn_set_flag = 1;
    }

    strcpy(op_log.op_type,"设置储能柜的SN");
    op_log.op_param1 = 0;
    op_log.op_param2 = 0;
    if (ret == SF_OK)
    {
        strcpy(op_log.op_status,"success");
    }
    else
    {
        strcpy(op_log.op_status,"fail");
    }
    add_one_op_log(&op_log);

    cJSON_Delete(p_request);

    if (ret == SF_OK)
    {
        build_empty_response(response,200,"setEnergyCabinetSN successful");
    }
    else
    {
        build_empty_response(response,200,"setEnergyCabinetSN failed");
    }
	http_back(p_nc,response);
}


void get_energy_cabinet_sn(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
    uint8_t response[1024];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t i;
    uint8_t request_body[1024] = {0};
    uint8_t dev_sn[DEVICE_SN_LEN + 1]; //设备SN + 结束符
    constant_parameter_data_t *p_constant_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getEnergyCabinetSN"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        return;
    }

    memcpy(dev_sn, p_constant_data->device_sn, (DEVICE_SN_LEN + 1));
    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddStringToObject(p_resp_root,"sn",dev_sn);
    cJSON_AddStringToObject(p_resp_root,"msg","getEnergyCabinetSN successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);

    cJSON_Delete(p_resp_root);
    free(p);

    http_back(p_nc,response);
}


void set_ft_cap_test_mode(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_item;
    uint8_t response[64];  //
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    operation_log_t op_log;
    uint8_t cur_user[32] = {0};
    battery_parameter_data_t param_info;
    web_control_info_t *p_web_data = NULL;
    int32_t mode_value = 0;
    uint8_t update_flag = DISABLE;
    int32_t ret;
    constant_parameter_data_t *p_constant_param      = sdk_shm_constant_parameter_data_get();

    p_web_data = shm_web_control_info_get();

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"setFactoryCapacityTest"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    // 此处需要详细的操作日志类型
    init_user_basic_info(&op_log);
    get_user_from_http_request(p_msg,cur_user);
    strcpy(op_log.user_name,cur_user);
    get_user_basic_info(&op_log);
    strcpy(op_log.op_type,"设置工厂容测模式");

    ret = para_config_page_protect_para_get(&param_info); //需求比实际较少，需要先获取一下所有数据，只修改需求的数据
    if (SF_OK != ret)
    {
        print_log("para get error.");
		build_empty_response(response,204,"para get error");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
    }

    mode_value = cJSON_GetObjectItem(p_request,"mode")->valueint;
    if (mode_value == ENABLE)
    {
        print_log( "mode_value == ENABLE\r\n" );
        if ( (p_constant_param->battery_cap_test_flag & BIT(0)) == 0 )
        {
            /* 非容测模式 切 容测模式 */
            p_constant_param->battery_cap_test_flag |= ( BIT(0) );
            print_log( "switch to cap test mode\r\n" );
        }

        op_log.op_param1 = DISABLE;
        op_log.op_param2 = ENABLE;
        update_flag = ENABLE;

    }
    else if (mode_value == DISABLE)
    {
        print_log( "mode_value == DISABLE\r\n" );
        if ( (p_constant_param->battery_cap_test_flag & BIT(0)) == 1 )
        {
            /* 容测模式 切 非容测模式  */
            p_constant_param->battery_cap_test_flag &= ~BIT(0);
        }

        op_log.op_param1 = ENABLE;
        op_log.op_param2 = DISABLE;
        update_flag = ENABLE;
    }
    else
    {
        print_log("mode is not right.");
		build_empty_response(response,204,"mode is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
    }

    strcpy(op_log.op_status,"success");
    add_one_op_log(&op_log);

    p_web_data->battery_cap_test_set_flag = update_flag;
    para_config_page_protect_para_set(&param_info);

    cJSON_Delete(p_request);

    build_empty_response(response,200,"setFactoryCapacityTest successful");
	http_back(p_nc,response);
}

/**
 * @brief    获取容测模式
 * @param         [in] *p_nc 连接信息
 * @param         [in] *p_msg  http请求信息
 * @return
 */
void get_ft_cap_test_mode(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	cJSON *p_resp_item = NULL;
	uint8_t response[256] = {0};
	uint8_t *p_action = NULL;
	int32_t ret = 0;
	uint8_t *p = NULL;
	uint8_t request_body[1024] = {0};
	common_data_t *shm = NULL;

	shm = sdk_shm_get();
	constant_parameter_data_t *p_constant_param      = sdk_shm_constant_parameter_data_get();

	memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		print_log((int8_t *)"parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	if(NULL == cJSON_GetObjectItem(p_request,"action"))
	{
		print_log((int8_t *)"action is NULL");
		build_empty_response(response,Non_Authoriative_Information,"action is NULL");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getFactoryCapacityTest"))
	{
		print_log((int8_t *)"action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
	cJSON_Delete(p_request);

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		print_log((int8_t *)"create json obj failed.");
		return;
	}

	cJSON_AddNumberToObject(p_resp_root,"code",OK);

	cJSON_AddNumberToObject(p_resp_root,"mode", (p_constant_param->battery_cap_test_flag & BIT(0))? 1:0 );
	cJSON_AddStringToObject(p_resp_root,"msg","successful");
	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);
	return;
}


/**
 * @brief    获取低功耗设置
 * @param         [in] *p_nc 连接信息
 * @param         [in] *p_msg  http请求信息
 * @return
 */
void get_low_power_setting(struct mg_connection *p_nc,struct http_message *p_msg)
{
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); 
    char reply_str[ 300 ];
    int32_t reply_str_len;

    if ( SF_FALSE == js_api_common_js_str_action_val_cmp( p_msg->body.p, "getLowPowerSetting" ))
    {
        build_empty_response( reply_str, 201, "getLowPowerSetting failed");
        http_back( p_nc, reply_str);
        return;
    }

    reply_str_len = json_utils_sprintf( reply_str, 
                                            "{", 
                                                "\"code\":200,"
                                                "\"msg\":\"getLowPowerSetting successful\","
                                                "\"mcuIndex\":1 ,"
                                                "\"idleToSleepEnable\":%d,"   , p_para_data->idle_to_sleep_enable ,  
                                                "\"idleToSleepHours\":%d,"    , p_para_data->idle_to_sleep_tm ,
                                                "\"sleepToPowOffEnable\":%d," , p_para_data->sleep_to_pow_off_enable ,
                                                "\"sleepToPowOffHours\":%d"   , p_para_data->sleep_to_pow_off_tm ,
                                            "}", 
                                 JSON_SPRINTF_END );
    if ( reply_str_len > 0 )
    {
	    http_back(p_nc , reply_str);
    }else{
        build_empty_response( reply_str, 201, "getLowPowerSetting failed");
        http_back( p_nc, reply_str);
    }

    return;
}

/**
 * @brief    设置低功耗参数
 * @param         [in] *p_nc 连接信息
 * @param         [in] *p_msg  http请求信息
 * @return
 */
void set_low_power_setting(struct mg_connection *p_nc,struct http_message *p_msg)
{
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); 
    char reply_str[ 300 ];
    int32_t reply_str_len;
    operation_log_t op_log;

    log_i((const int8_t*)"%s", __FUNCTION__);

    cJSON *p_root_js = cJSON_Parse( p_msg->body.p );
    if ( p_root_js == NULL )
    {
        log_e((const int8_t*)"%s p_root_js == NULL!!!", __FUNCTION__);
        build_empty_response( reply_str, 201, "setLowPowerSetting failed");
        http_back( p_nc, reply_str);
        return;
    }

    if (  (NULL == cJSON_GetObjectItem( p_root_js, "idleToSleepEnable"   ))
       || (NULL == cJSON_GetObjectItem( p_root_js, "idleToSleepHours"    ))
       || (NULL == cJSON_GetObjectItem( p_root_js, "sleepToPowOffEnable" ))
       || (NULL == cJSON_GetObjectItem( p_root_js, "sleepToPowOffHours"  )))
    {
        log_e((const int8_t*)"%s params == NULL!!!", __FUNCTION__);
        cJSON_Delete( p_root_js );
        build_empty_response( reply_str, 201, "setLowPowerSetting failed");
        http_back( p_nc, reply_str);
        return;
    }

    uint16_t last_idle_to_sleep_enable    = p_para_data->idle_to_sleep_enable    ; 
    uint16_t last_idle_to_sleep_tm        = p_para_data->idle_to_sleep_tm        ;
    uint16_t last_sleep_to_pow_off_enable = p_para_data->sleep_to_pow_off_enable ;
    uint16_t last_sleep_to_pow_off_tm     = p_para_data->sleep_to_pow_off_tm     ;

    p_para_data->idle_to_sleep_enable    = (uint16_t)cJSON_GetObjectItem( p_root_js, "idleToSleepEnable"   )->valueint;
    p_para_data->idle_to_sleep_tm        = (uint16_t)cJSON_GetObjectItem( p_root_js, "idleToSleepHours"    )->valueint;
    p_para_data->sleep_to_pow_off_enable = (uint16_t)cJSON_GetObjectItem( p_root_js, "sleepToPowOffEnable" )->valueint;
    p_para_data->sleep_to_pow_off_tm     = (uint16_t)cJSON_GetObjectItem( p_root_js, "sleepToPowOffHours"  )->valueint;
    
    BIT_SET( shm_web_control_info_get()->low_power_setting_flag, 0 );

    build_empty_response( reply_str, 200, "setLowPowerSetting sucessful");
    http_back( p_nc, reply_str);
    cJSON_Delete( p_root_js );

    char op_usr_name[32];

    get_user_from_http_request( p_msg, op_usr_name );
    if (  last_idle_to_sleep_enable != p_para_data->idle_to_sleep_enable )
    {
        usr_add_one_op_log( op_usr_name, "空载转休眠使能设置", true, last_idle_to_sleep_enable, p_para_data->idle_to_sleep_enable  );
    }
    if (  last_idle_to_sleep_tm != p_para_data->idle_to_sleep_tm )
    {
        usr_add_one_op_log( op_usr_name, "空载转休眠时间设置", true, last_idle_to_sleep_tm, p_para_data->idle_to_sleep_tm  );
    }
    if (  last_sleep_to_pow_off_enable != p_para_data->sleep_to_pow_off_enable )
    {
        usr_add_one_op_log( op_usr_name, "休眠转停机使能设置", true, last_sleep_to_pow_off_enable, p_para_data->sleep_to_pow_off_enable  );
    }
    if (  last_sleep_to_pow_off_tm != p_para_data->sleep_to_pow_off_tm )
    {
        usr_add_one_op_log( op_usr_name, "休眠转停机时间设置", true, last_sleep_to_pow_off_tm, p_para_data->sleep_to_pow_off_tm  );
    }

    return;
}

/**
 * @brief    获取保温模式参数
 * @param    [in] *p_nc 连接信息
 * @param    [in] *p_msg  http请求信息
 * @return
 */
void get_kepp_warm_param(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
    uint8_t response[1024];  
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"ThermosModeParamGet"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddNumberToObject(p_resp_root,"ThermosModeEnable",p_para_data->dynamic_ring2.keep_temper_enable);
    cJSON_AddNumberToObject(p_resp_root,"HeatingStartupTemperature",p_para_data->dynamic_ring2.keep_temper_heating_startup_temper);
    cJSON_AddNumberToObject(p_resp_root,"HeatingStopTemperature",p_para_data->dynamic_ring2.keep_temper_heating_exit_temper);
    cJSON_AddNumberToObject(p_resp_root,"CoolingStartupTemperature",p_para_data->dynamic_ring2.keep_temper_cooling_startup_temper);
    cJSON_AddNumberToObject(p_resp_root,"CoolingStopTemperature",p_para_data->dynamic_ring2.keep_temper_cooling_exit_temper);
    cJSON_AddStringToObject(p_resp_root,"msg","successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);

    cJSON_Delete(p_resp_root);
    free(p);

    http_back(p_nc,response);
}

/**
 * @brief    设置保温模式参数
 * @param    [in] *p_nc 连接信息
 * @param    [in] *p_msg  http请求信息
 * @return
 */
void set_keep_warm_param(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_item;
    uint8_t response[256];  
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    operation_log_t op_log;
    uint8_t cur_user[32] = {0};
    uint16_t param_temp = 0;
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数
    web_control_info_t *web_control_info = shm_web_control_info_get();
    uint8_t param_change_flag = 0;

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"ThermosModeParamSet"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    p_item = cJSON_GetObjectItem(p_request,"ThermosModeEnable");
    if(p_item != NULL)
    {
        param_temp = p_item->valueint;
        if(param_temp != p_para_data->dynamic_ring2.keep_temper_enable)
        {
            init_user_basic_info(&op_log);
            get_user_from_http_request(p_msg,cur_user);
            strcpy(op_log.user_name,cur_user);
            get_user_basic_info(&op_log);
            strcpy(op_log.op_status,"success");
            strcpy(op_log.op_type,"设置保温模式使能位");
            op_log.op_param1 = p_para_data->dynamic_ring2.keep_temper_enable;
            op_log.op_param2 = param_temp;
            add_one_op_log(&op_log);
            p_para_data->dynamic_ring2.keep_temper_enable = param_temp;
            param_change_flag = true;
        }
    }
    p_item = cJSON_GetObjectItem(p_request,"HeatingStartupTemperature");
    if(p_item != NULL)
    {
        param_temp = p_item->valueint;
        if(param_temp != p_para_data->dynamic_ring2.keep_temper_heating_startup_temper)
        {
            init_user_basic_info(&op_log);
            get_user_from_http_request(p_msg,cur_user);
            strcpy(op_log.user_name,cur_user);
            get_user_basic_info(&op_log);
            strcpy(op_log.op_status,"success");
            strcpy(op_log.op_type,"设置保温加热启动温度");
            op_log.op_param1 = p_para_data->dynamic_ring2.keep_temper_heating_startup_temper/10.0;
            op_log.op_param2 = param_temp/10.0;
            add_one_op_log(&op_log);
            p_para_data->dynamic_ring2.keep_temper_heating_startup_temper = param_temp;
            param_change_flag = true;
        }
    }
    p_item = cJSON_GetObjectItem(p_request,"HeatingStopTemperature");
    if(p_item != NULL)
    {
        param_temp = p_item->valueint;
        if(param_temp != p_para_data->dynamic_ring2.keep_temper_heating_exit_temper)
        {
            init_user_basic_info(&op_log);
            get_user_from_http_request(p_msg,cur_user);
            strcpy(op_log.user_name,cur_user);
            get_user_basic_info(&op_log);
            strcpy(op_log.op_status,"success");
            strcpy(op_log.op_type,"设置保温加热停止温度");
            op_log.op_param1 = p_para_data->dynamic_ring2.keep_temper_heating_exit_temper/10.0;
            op_log.op_param2 = param_temp/10.0;
            add_one_op_log(&op_log);
            p_para_data->dynamic_ring2.keep_temper_heating_exit_temper = param_temp;
            param_change_flag = true;
        }
    }
    p_item = cJSON_GetObjectItem(p_request,"CoolingStartupTemperature");
    if(p_item != NULL)
    {
        param_temp = p_item->valueint;
        if(param_temp != p_para_data->dynamic_ring2.keep_temper_cooling_startup_temper)
        {
            init_user_basic_info(&op_log);
            get_user_from_http_request(p_msg,cur_user);
            strcpy(op_log.user_name,cur_user);
            get_user_basic_info(&op_log);
            strcpy(op_log.op_status,"success");
            strcpy(op_log.op_type,"设置保温制冷启动温度");
            op_log.op_param1 = p_para_data->dynamic_ring2.keep_temper_cooling_startup_temper/10.0;
            op_log.op_param2 = param_temp/10.0;
            add_one_op_log(&op_log);
            p_para_data->dynamic_ring2.keep_temper_cooling_startup_temper = param_temp;
            param_change_flag = true;
        }
    }
    p_item = cJSON_GetObjectItem(p_request,"CoolingStopTemperature");
    if(p_item != NULL)
    {
        param_temp = p_item->valueint;
        if(param_temp != p_para_data->dynamic_ring2.keep_temper_cooling_exit_temper)
        {
            init_user_basic_info(&op_log);
            get_user_from_http_request(p_msg,cur_user);
            strcpy(op_log.user_name,cur_user);
            get_user_basic_info(&op_log);
            strcpy(op_log.op_status,"success");
            strcpy(op_log.op_type,"设置保温制冷停止温度");
            op_log.op_param1 = p_para_data->dynamic_ring2.keep_temper_cooling_exit_temper/10.0;
            op_log.op_param2 = param_temp/10.0;
            add_one_op_log(&op_log);
            p_para_data->dynamic_ring2.keep_temper_cooling_exit_temper = param_temp;
            param_change_flag = true;
        }
    }

    if(param_change_flag == true)
    {
        web_control_info->keep_warm_param_set_flag = 1;
    }
    cJSON_Delete(p_request);
    build_empty_response(response,200,"setBatClusterPackNum successful");
	http_back(p_nc,response);
}

/**
 * @brief    设置功率软启时间梯度
 * @param    [in] *p_nc 连接信息
 * @param    [in] *p_msg  http请求信息
 * @return
 */
void set_pcs_powerup_gradident(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    uint8_t response[64];  
    uint8_t *p_action;
    uint8_t request_body[1024] = {0};
    operation_log_t op_log;
    uint8_t cur_user[32] = {0};
    web_control_info_t *p_web_data = NULL;
    constant_parameter_data_t *p_constant_param = NULL;
    
    p_web_data = shm_web_control_info_get();
    p_constant_param = sdk_shm_constant_parameter_data_get();

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"pcsPowerupTimeGradidentSet"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    // 此处需要详细的操作日志类型
    init_user_basic_info(&op_log);
    get_user_from_http_request(p_msg,cur_user);
    strcpy(op_log.user_name,cur_user);
    get_user_basic_info(&op_log);
    strcpy(op_log.op_type,"设置PCS功率软启时间梯度");
    p_web_data->pcs_powerup_gradident_setvalue = cJSON_GetObjectItem(p_request,"pcsPowerupTimeGradident")->valueint;
    op_log.op_param1 = p_constant_param->pcs_parameter_data->power_ref_soft_start_gradident;
    op_log.op_param2 = p_web_data->pcs_powerup_gradident_setvalue;
    p_web_data->pcs_powerup_gradident_set_flag = ENABLE;
   

    strcpy(op_log.op_status,"success");
    add_one_op_log(&op_log);

    cJSON_Delete(p_request);
    build_empty_response(response,200,"successful");
	http_back(p_nc,response);
}

/**
 * @brief    获取功率软启时间梯度
 * @param    [in] *p_nc 连接信息
 * @param    [in] *p_msg  http请求信息
 * @return
 */
void get_pcs_powerup_gradident(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
    uint8_t response[1024];  
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}
    
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"pcsPowerupTimeGradidentGet"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddNumberToObject(p_resp_root,"pcsPowerupTimeGradident",p_para_data->pcs_parameter_data->power_ref_soft_start_gradident);
    cJSON_AddStringToObject(p_resp_root,"msg","successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);

    cJSON_Delete(p_resp_root);
    free(p);

    http_back(p_nc,response);
}


/**
 * @brief    设置功外部EPO类型
 * @param    [in] *p_nc 连接信息
 * @param    [in] *p_msg  http请求信息
 * @return
 */
void set_external_epo_type(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_item = NULL;
    uint8_t response[64];  
    uint8_t *p_action;
    uint8_t request_body[1024] = {0};
    operation_log_t op_log;
    uint8_t cur_user[32] = {0};
    web_control_info_t *p_web_data = NULL;
    constant_parameter_data_t *p_constant_param = NULL;
    
    p_web_data = shm_web_control_info_get();
    p_constant_param = sdk_shm_constant_parameter_data_get();

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_item = cJSON_GetObjectItem(p_request,"action");
	if(p_item == NULL || strcmp(p_item->valuestring, "setExternalEPO"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    // 此处需要详细的操作日志类型
    init_user_basic_info(&op_log);
    get_user_from_http_request(p_msg,cur_user);
    strcpy(op_log.user_name,cur_user);
    get_user_basic_info(&op_log);
    strcpy(op_log.op_type,"设置外部EPO类型");
    p_item = cJSON_GetObjectItem(p_request,"EPOSwitch");
    if(p_item == NULL)
    {   op_log.op_param1 = p_constant_param->external_epo_input_type;
        op_log.op_param2 = p_constant_param->external_epo_input_type;
        strcpy(op_log.op_status,"failed");
        add_one_op_log(&op_log);
        build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
        return;
    }
    op_log.op_param1 = p_constant_param->external_epo_input_type;
    op_log.op_param2 = p_item->valueint;
    p_constant_param->external_epo_input_type = p_item->valueint;
    p_web_data->external_epo_type_set_flag = ENABLE;
   
    strcpy(op_log.op_status,"success");
    add_one_op_log(&op_log);

    cJSON_Delete(p_request);
    build_empty_response(response,200,"successful");
	http_back(p_nc,response);
}


/**
 * @brief    设置功率因数
 * @param    [in] *p_nc 连接信息
 * @param    [in] *p_msg  http请求信息
 * @return
 */
void set_pcs_power_factor_ref(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_item = NULL;
    uint8_t response[64];  
    uint8_t *p_action;
    uint8_t request_body[1024] = {0};
    operation_log_t op_log;
    uint8_t cur_user[32] = {0};
    constant_parameter_data_t *p_constant_param = NULL;
    internal_shared_data_t *p_internal_data = NULL;
    
    p_constant_param = sdk_shm_constant_parameter_data_get();
    p_internal_data = internal_shared_data_get();

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_item = cJSON_GetObjectItem(p_request,"action");
	if(p_item == NULL || strcmp(p_item->valuestring, "pcsPowerFactorRefSet"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    // 此处需要详细的操作日志类型
    init_user_basic_info(&op_log);
    get_user_from_http_request(p_msg,cur_user);
    strcpy(op_log.user_name,cur_user);
    get_user_basic_info(&op_log);
    strcpy(op_log.op_type,"设置功率因数");
    p_item = cJSON_GetObjectItem(p_request,"pcsPowerFactorRef");
    if(p_item == NULL)
    {   op_log.op_param1 = p_constant_param->safety_param.group7[1];
        op_log.op_param2 = p_constant_param->safety_param.group7[1];
        strcpy(op_log.op_status,"failed");
        add_one_op_log(&op_log);
        build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
        return;
    }
    op_log.op_param1 = p_constant_param->safety_param.group7[1];
    op_log.op_param2 = p_item->valueint;
    p_constant_param->safety_param.group7[1] = p_item->valueint;
    BIT_SET( p_internal_data->safety_update_flag, 7 );
   
    strcpy(op_log.op_status,"success");
    add_one_op_log(&op_log);

    cJSON_Delete(p_request);
    build_empty_response(response,200,"successful");
	http_back(p_nc,response);
}

/**
 * @brief    获取功率因数
 * @param    [in] *p_nc 连接信息
 * @param    [in] *p_msg  http请求信息
 * @return
 */
void get_pcs_power_factor_ref(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
    uint8_t response[1024];  
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}
    
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"pcsPowerFactorRefGet"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",200);
    int16_t Power_factor_ref = (int16_t)p_para_data->safety_param.group7[1];
    cJSON_AddNumberToObject(p_resp_root,"pcsPowerFactorRef",Power_factor_ref);
    cJSON_AddStringToObject(p_resp_root,"msg","successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);

    cJSON_Delete(p_resp_root);
    free(p);

    http_back(p_nc,response);
}


/**
 * @brief    设置无功模式
 * @param    [in] *p_nc 连接信息
 * @param    [in] *p_msg  http请求信息
 * @return
 */
void set_pcs_reactive_power_mode(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_item = NULL;
    uint8_t response[64];  
    uint8_t *p_action;
    uint8_t request_body[1024] = {0};
    operation_log_t op_log;
    uint8_t cur_user[32] = {0};
    constant_parameter_data_t *p_constant_param = NULL;
    internal_shared_data_t *p_internal_data = NULL;
    uint16_t reactive_power_mode = 0;
    
    p_constant_param = sdk_shm_constant_parameter_data_get();
    p_internal_data = internal_shared_data_get();

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_item = cJSON_GetObjectItem(p_request,"action");
	if(p_item == NULL || strcmp(p_item->valuestring, "pcsReactivePowerModeSet"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    // 此处需要详细的操作日志类型
    init_user_basic_info(&op_log);
    get_user_from_http_request(p_msg,cur_user);
    strcpy(op_log.user_name,cur_user);
    get_user_basic_info(&op_log);
    strcpy(op_log.op_type,"设置无功模式");
    p_item = cJSON_GetObjectItem(p_request,"pcsReactivePowerMode");
    reactive_power_mode = p_constant_param->safety_param.group7[0];
    if(p_item == NULL)
    {   op_log.op_param1 = (reactive_power_mode>>1)&((1 << 3)-1);
        op_log.op_param2 = (reactive_power_mode>>1)&((1 << 3)-1);
        strcpy(op_log.op_status,"failed");
        add_one_op_log(&op_log);
        build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
        return;
    }
    op_log.op_param1 = (reactive_power_mode>>1)&((1 << 3)-1);
    op_log.op_param2 = p_item->valueint;

    uint16_t save_val = p_constant_param->safety_param.group7[0];
    save_val &= ~(0x07 << 1);
    save_val |= (p_item->valueint & 0x07) << 1;
    p_constant_param->safety_param.group7[0] = save_val;
    BIT_SET( p_internal_data->safety_update_flag, 7 );
   
    strcpy(op_log.op_status,"success");
    add_one_op_log(&op_log);

    cJSON_Delete(p_request);
    build_empty_response(response,200,"successful");
	http_back(p_nc,response);
}

/**
 * @brief    获取无功模式
 * @param    [in] *p_nc 连接信息
 * @param    [in] *p_msg  http请求信息
 * @return
 */
void get_pcs_reactive_power_mode(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
    uint8_t response[1024];  
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    uint16_t reactive_power_mode = 0;
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}
    
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"pcsReactivePowerModeGet"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        return;
    }
    reactive_power_mode = (p_para_data->safety_param.group7[0]>>1)&((1 << 3)-1);
    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddNumberToObject(p_resp_root,"pcsReactivePowerMode",reactive_power_mode);
    cJSON_AddStringToObject(p_resp_root,"msg","successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);

    cJSON_Delete(p_resp_root);
    free(p);

    http_back(p_nc,response);
}


/**
 * @brief    设置无功使能
 * @param    [in] *p_nc 连接信息
 * @param    [in] *p_msg  http请求信息
 * @return
 */
void set_pcs_reactive_power_enable(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_item = NULL;
    uint8_t response[64];  
    uint8_t *p_action;
    uint8_t request_body[1024] = {0};
    operation_log_t op_log;
    uint8_t cur_user[32] = {0};
    constant_parameter_data_t *p_constant_param = NULL;
    internal_shared_data_t *p_internal_data = NULL;
    uint16_t reactive_power_mode = 0;
    
    p_constant_param = sdk_shm_constant_parameter_data_get();
    p_internal_data = internal_shared_data_get();

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}

	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_item = cJSON_GetObjectItem(p_request,"action");
	if(p_item == NULL || strcmp(p_item->valuestring, "pcsReactivePowerEnableSet"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    // 此处需要详细的操作日志类型
    init_user_basic_info(&op_log);
    get_user_from_http_request(p_msg,cur_user);
    strcpy(op_log.user_name,cur_user);
    get_user_basic_info(&op_log);
    strcpy(op_log.op_type,"设置无功使能");
    p_item = cJSON_GetObjectItem(p_request,"pcsReactivePowerEnable");
    reactive_power_mode = p_constant_param->safety_param.group7[0];
    if(p_item == NULL)
    {   op_log.op_param1 = reactive_power_mode & 0x01;
        op_log.op_param2 = reactive_power_mode & 0x01;
        strcpy(op_log.op_status,"failed");
        add_one_op_log(&op_log);
        build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
        return;
    }
    op_log.op_param1 = reactive_power_mode & 0x01;;
    op_log.op_param2 = p_item->valueint;
    // p_constant_param->safety_param.group7[0] |= p_item->valueint & 0x01;
    if (p_item->valueint == 0)
    {
        BIT_CLR( p_constant_param->safety_param.group7[0], 0 );
    }else {
        BIT_SET( p_constant_param->safety_param.group7[0], 0 );
    }
    BIT_SET( p_internal_data->safety_update_flag, 7 );
   
    strcpy(op_log.op_status,"success");
    add_one_op_log(&op_log);

    cJSON_Delete(p_request);
    build_empty_response(response,200,"successful");
	http_back(p_nc,response);
}

/**
 * @brief    获取无功使能
 * @param    [in] *p_nc 连接信息
 * @param    [in] *p_msg  http请求信息
 * @return
 */
void get_pcs_reactive_power_enable(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
    uint8_t response[1024];  
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    uint16_t reactive_power_mode = 0;
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}
    
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"pcsReactivePowerEnableGet"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        return;
    }
    reactive_power_mode = p_para_data->safety_param.group7[0] & 0x01;
    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddNumberToObject(p_resp_root,"pcsReactivePowerEnable",reactive_power_mode);
    cJSON_AddStringToObject(p_resp_root,"msg","successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);

    cJSON_Delete(p_resp_root);
    free(p);

    http_back(p_nc,response);
}


/**
 * @brief    获取外部EPO类型
 * @param    [in] *p_nc 连接信息
 * @param    [in] *p_msg  http请求信息
 * @return
 */
void get_external_epo_type(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_resp_root;
    uint8_t response[1024];  
    uint8_t *p_action;
    uint8_t *p;
    uint8_t request_body[1024] = {0};
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数

    if(p_msg->body.p[0] == '"' && p_msg->body.p[p_msg->body.len-1] == '"')
	{
		strip_request_body(p_msg->body.p,p_msg->body.len,request_body);
	}
	else
	{
		memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	}
    
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		print_log("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getExternalEPO"))
	{
		print_log("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        print_log("create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddNumberToObject(p_resp_root,"EPOSwitch",p_para_data->external_epo_input_type);
    cJSON_AddStringToObject(p_resp_root,"msg","successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);

    cJSON_Delete(p_resp_root);
    free(p);

    http_back(p_nc,response);
}

/**
 * @brief 调试参数模块初始化
 * @return void
 */
void debug_param_module_init(void)
{
	/*获取调试管理状态*/
	if(!web_func_attach("/debugManager/getDebugStatus", get_debug_status))
	{
		print_log("[/debugManager/getDebugStatus] attach failed");
	}
	/*设置调试管理状态*/
	if(!web_func_attach("/debugManager/setDebugStatus", set_debug_status))
	{
		print_log("[/debugManager/setDebugStatus] attach failed");
	}
	/*PCS开关设置*/
	if(!web_func_attach("/debugManager/PCSSwitchSet", set_debug_pcs_switch))
	{
		print_log("[/debugManager/PCSSwitchSet] attach failed");
	}
	/*PCS开关获取*/
	if(!web_func_attach("/debugManager/PCSSwitchGet", get_debug_pcs_switch))
	{
		print_log("[/debugManager/PCSSwitchGet] attach failed");
	}
	/*液冷系统开关设置*/
	if(!web_func_attach("/debugManager/liquidCoolingSet", set_debug_liquid_cooling))
	{
		print_log("[/debugManager/liquidCoolingSet] attach failed");
	}
	/*液冷系统开关获取*/
	if(!web_func_attach("/debugManager/liquidCoolingGet", get_debug_liquid_cooling))
	{
		print_log("[/debugManager/liquidCoolingGet] attach failed");
	}
	/*设置液冷参数*/
	if(!web_func_attach("/debugManager/liquidCoolingParamSet", set_debug_liquid_cooling_param))
	{
		print_log("[/debugManager/liquidCoolingParamSet] attach failed");
	}
	/*获取液冷参数*/
	if(!web_func_attach("/debugManager/liquidCoolingParamGet", get_debug_liquid_cooling_param))
	{
		print_log("[/debugManager/liquidCoolingParamGet] attach failed");
	}
	/*设置CMU运行模式*/
	if(!web_func_attach("/debugManager/CMUSetMode", set_debug_cmu_mode))
	{
		print_log("[/debugManager/CMUSetMode] attach failed");
	}
	/*获取CMU运行模式*/
	if(!web_func_attach("/debugManager/CMUGetMode", get_debug_cmu_mode))
	{
		print_log("[/debugManager/CMUGetMode] attach failed");
	}
	/*CMU恢复出厂设置*/
	if(!web_func_attach("/debugManager/reset", web_reset))
	{
		print_log("[/debugManager/reset] attach failed");
	}

	/*CMU清除历史数据和操作日志*/
	if(!web_func_attach("/debugManager/clearData", web_clear_data))
	{
		print_log("[/debugManager/clearData attach failed");
	}

	/*设置电池仓个数*/
	if(!web_func_attach("/debugManager/setBatCabinetNum", set_bat_cabinet_num))
	{
		print_log("[/debugManager/setBatCabinetNum] attach failed");
	}
	/*获取电池仓个数*/
	if(!web_func_attach("/debugManager/getBatCabinetNum", get_bat_cabinet_num))
	{
		print_log("[/debugManager/getBatCabinetNum] attach failed");
	}
	/*设置储能柜属性*/
	if(!web_func_attach("/debugManager/setEnergyCabinetAttr", set_energy_cabinet_attr))
	{
		print_log("[/debugManager/setEnergyCabinetAttr] attach failed");
	}
	/*获取储能柜属性*/
	if(!web_func_attach("/debugManager/getEnergyCabinetAttr", get_energy_cabinet_attr))
	{
		print_log("[/debugManager/getEnergyCabinetAttr] attach failed");
	}
	/*设置电池簇PACK个数*/
	if(!web_func_attach("/debugManager/setBatClusterPackNum", set_bat_cluster_pack_num))
	{
		print_log("[/debugManager/setBatClusterPackNum] attach failed");
	}
	/*获取电池簇PACK个数*/
	if(!web_func_attach("/debugManager/getBatClusterPackNum", get_bat_cluster_pack_num))
	{
		print_log("[/debugManager/getBatClusterPackNum] attach failed");
	}
	/*设置储能柜的SN序列号（CMU）*/
	if(!web_func_attach("/debugManager/setEnergyCabinetSN", set_energy_cabinet_sn))
	{
		print_log("[/debugManager/setEnergyCabinetSN] attach failed");
	}
	/*获取储能柜的SN序列号（CMU）*/
	if(!web_func_attach("/debugManager/getEnergyCabinetSN", get_energy_cabinet_sn))
	{
		print_log("[/debugManager/getEnergyCabinetSN] attach failed");
	}
	/*设置储能柜容测模式*/
	if(!web_func_attach("/debugManager/setFactoryCapacityTest", set_ft_cap_test_mode))
	{
		print_log("[/debugManager/setFactoryCapacityTest] attach failed");
	}
	/*设置储能柜容测模式*/
	if(!web_func_attach("/debugManager/getFactoryCapacityTest", get_ft_cap_test_mode))
	{
		print_log("[/debugManager/getFactoryCapacityTest] attach failed");
	}

	/*获取低功耗设置*/
	if(!web_func_attach("/debugManager/getLowPowerSetting", get_low_power_setting))
	{
		print_log("[/debugManager/getLowPowerSetting] attach failed");
	}
	/*设置低功耗参数*/
	if(!web_func_attach("/debugManager/setLowPowerSetting", set_low_power_setting))
	{
		print_log("[/debugManager/setLowPowerSetting] attach failed");
	}

    /*获取保温模式参数*/
	if(!web_func_attach("/debugManager/ThermosModeParamGet", get_kepp_warm_param))
	{
		print_log("[/debugManager/ThermosModeParamGet] attach failed");
	}
    /*设置保温模式参数*/
	if(!web_func_attach("/debugManager/ThermosModeParamSet", set_keep_warm_param))
	{
		print_log("[/debugManager/ThermosModeParamGet] attach failed");
	}

    /*设置功率软启时间梯度*/
	if(!web_func_attach("/sysManager/pcsPowerupTimeGradidentSet", set_pcs_powerup_gradident))
	{
		print_log("[/sysManager/pcsPowerupTimeGradidentSet] attach failed");
	}
    /*获取功率软启时间梯度*/
	if(!web_func_attach("/sysManager/pcsPowerupTimeGradidentGet", get_pcs_powerup_gradident))
	{
		print_log("[/sysManager/pcsPowerupTimeGradidentGet] attach failed");
	}
    
    /*设置PCS功率因数*/
	if(!web_func_attach("/sysManager/pcsPowerFactorRefSet", set_pcs_power_factor_ref))
	{
		print_log("[/sysManager/pcsPowerFactorRefSet] attach failed");
	}
     /*获取PCS功率因数*/
	if(!web_func_attach("/sysManager/pcsPowerFactorRefGet", get_pcs_power_factor_ref))
	{
		print_log("[/sysManager/pcsPowerFactorRefGet] attach failed");
	}

    /*设置PCS无功模式*/
	if(!web_func_attach("/sysManager/pcsReactivePowerModeSet", set_pcs_reactive_power_mode))
	{
		print_log("[/sysManager/pcsReactivePowerModeSet] attach failed");
	}
     /*获取PCS无功模式*/
	if(!web_func_attach("/sysManager/pcsReactivePowerModeGet", get_pcs_reactive_power_mode))
	{
		print_log("[/sysManager/pcsReactivePowerModeGet] attach failed");
	}

    /*设置PCS无功使能*/
	if(!web_func_attach("/sysManager/pcsReactivePowerEnableSet", set_pcs_reactive_power_enable))
	{
		print_log("[/sysManager/pcsReactivePowerEnableSet] attach failed");
	}
     /*获取PCS无功使能*/
	if(!web_func_attach("/sysManager/pcsReactivePowerEnableGet", get_pcs_reactive_power_enable))
	{
		print_log("[/sysManager/pcsReactivePowerEnableGet] attach failed");
	}
    
    /*设置外部EPO输入类型*/
	if(!web_func_attach("/debugManager/setExternalEPO", set_external_epo_type))
	{
		print_log("[/sysManager/set_external_epo_type] attach failed");
	}
    /*获取外部EPO输入类型*/
	if(!web_func_attach("/debugManager/getExternalEPO", get_external_epo_type))
	{
		print_log("[/sysManager/getExternalEPO] attach failed");
	}
    
}