#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "update_file_analysis.h"
#include "process_monitor.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "errors.h"
#include "sofar_log.h"
#include <pthread.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
	common_data_t *tep = NULL;

    // sdk_log_init();
    // sdk_log_set_level(5);
	log_init((const int8_t *)PATH_CONF);
	log_set_level(LOG_LVL_DEBUG);
	
    // 映射共享内存
    tep = sdk_shm_init();

    while (tep == NULL)
	{
		sleep(2);
		UPDATE_DEBUG_PRINT((int8_t *)" sdk_shm_init \n ");
		tep = sdk_shm_init();
	}

	// 升级文件包解析
	pthread_t file_analysis;
	pthread_create(&file_analysis, NULL, &update_file_analysis, NULL);

	// 监测进程运行状态
	pthread_t process_monitor_attr;
	pthread_create(&process_monitor_attr, NULL, &process_monitor, NULL);

	while(1)
    {
	    sleep(1);
    }

	return 0;
}