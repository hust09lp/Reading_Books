#ifndef __SOFAR_TYPE_H__
#define __SOFAR_TYPE_H__

#include "data_types.h"
#include "sofar_errors.h"

#define BIT(n)                                (1<<(n))

#ifndef ARRAY_SIZE
#define ARRAY_SIZE(array)                     ( sizeof(array) / sizeof(array[0]) )
#endif

#define GET_MEMBER_OFFSET( st_type, member )  (size_t)(&((st_type *)0)->member) 

#define BIT_CPL(value, bit)         ((value) ^= (1 << (bit)))               //取反指定位
#define BIT_SET(value, bit)         ((value) |= (1 << (bit)))               //置位指定位
#define BIT_CLR(value, bit)         ((value) &=~(1 << (bit)))               //清零指定位
#define BIT_GET(value, bit)         (((value) &  (1 << (bit))) >> (bit))    //读取指定位

#define SF_MUTEX_WAIT_FOREVER       0xFFFFFFFFU ///< Wait forever timeout value.

typedef uint32_t                    modbus_idx_t;
#define MODBUS_IDX_INVALID          0xffffffff          /* 无效 modbus index */
#define ST_MEMBER_TO_MODBUS_OFFSET( st_type, member )  (GET_MEMBER_OFFSET(st_type, member) / 2)

#define SF_TRUE                     1
#define SF_FALSE                    0

#define IO_ON                       SF_TRUE
#define IO_OFF                      SF_FALSE

typedef uint8_t                     usr_uint8_t;
#define USR_U8_VAL_INVALID          0xff

typedef uint16_t                    usr_uint16_t;
#define USR_U16_VAL_INVALID         0xffff

typedef uint32_t                    usr_uint32_t;
#define USR_U32_VAL_INVALID         0xffffffff

typedef uint16_t                    dev_idx_t;
#define DEV_IDX_INVALID             0xffff
#define DEV_IDX_ALL                 0xfffe


typedef int16_t  humi_t;            //< 湿度，单位：1%
typedef int16_t  temper_t;          //< 温度，单位：0.1℃

typedef int32_t  sf_ret_t;          //< 具体参考 sofar_error.h 定义

/* 在线状态 */
typedef enum {
    OL_STA_NO_EXSIT ,               // 设备不存在
    OL_STA_ONLINE ,                 // 设备在线
    OL_STA_OFFLINE ,                // 设备离线
} ol_sta_e;

typedef enum {
    BOOL_VAL_FALSE = 0,             //< false
    BOOL_VAL_TRUE = 1,              //< true
    BOOL_VAL_INVALID = 0xFF,        //< 无效数值 
} bool_val_e;

typedef enum {
    OP_READ,
    OP_WRITE,
} op_e;

#endif
