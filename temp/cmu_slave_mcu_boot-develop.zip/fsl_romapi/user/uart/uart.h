#ifndef __UART_H__
#define __UART_H__

#include "data_types.h"
#include "fsl_lpuart.h"

void uart_init(void);
int uart_send(LPUART_Type *base, uint8_t *p_buf, uint32_t len);
int uart_receive(LPUART_Type *base, uint8_t *ch);

#endif
