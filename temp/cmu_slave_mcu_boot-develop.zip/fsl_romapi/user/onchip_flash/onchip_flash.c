

#include "onchip_flash.h"
#include "FSL_common.h"

/*! @brief FLEXSPI NOR flash driver Structure */
static flexspi_nor_config_t norConfig;

extern const flexspi_nor_config_t qspiflash_config;

#define FLASH_SIZE (4*1024*1024)


/*******************************************************************************
 * Code
 ******************************************************************************/
/* Get FLEXSPI NOR Configuration Block */
void FLEXSPI_NorFlash_GetConfig(flexspi_nor_config_t *config)
{
    /* Copy norflash config block from xip config */
    memcpy(config, &qspiflash_config, sizeof(flexspi_nor_config_t));
    config->memConfig.tag              = FLEXSPI_CFG_BLK_TAG;
    config->memConfig.version          = FLEXSPI_CFG_BLK_VERSION;
    config->memConfig.readSampleClkSrc = kFLEXSPIReadSampleClk_LoopbackFromDqsPad;
    config->memConfig.serialClkFreq =
        kFLEXSPISerialClk_133MHz; /* Serial Flash Frequencey.See System Boot Chapter for more details */
    config->memConfig.sflashA1Size   = FLASH_SIZE;
    config->memConfig.csHoldTime     = 3U;                           /* Data hold time, default value: 3 */
    config->memConfig.csSetupTime    = 3U;                           /* Date setup time, default value: 3 */
    config->memConfig.deviceType     = kFLEXSPIDeviceType_SerialNOR; /* Flash device type default type: Serial NOR */
    config->memConfig.deviceModeType = kDeviceConfigCmdType_Generic;
    config->memConfig.columnAddressWidth  = 0U;
    config->memConfig.deviceModeCfgEnable = 0U;
    config->memConfig.waitTimeCfgCommands = 0U;
    config->memConfig.configCmdEnable     = 0U;
    /* Always enable Safe configuration Frequency */
    config->memConfig.controllerMiscOption = FSL_ROM_FLEXSPI_BITMASK(kFLEXSPIMiscOffset_SafeConfigFreqEnable);
    config->memConfig.sflashPadType = kSerialFlash_4Pads; /* Pad Type: 1 - Single, 2 - Dual, 4 - Quad, 8 - Octal */
    //    config->pageSize                = FLASH_PAGE_SIZE;
    //    config->sectorSize              = FLASH_SECTOR_SIZE;
    //    config->blockSize               = FLASH_BLOCK_SIZE;
    config->ipcmdSerialClkFreq      = kFLEXSPISerialClk_30MHz; /* Clock frequency for IP command */
    /* Fast Read Quad I/O */
    config->memConfig.lookupTable[4U * NOR_CMD_LUT_SEQ_IDX_READ + 0U] =
        FSL_ROM_FLEXSPI_LUT_SEQ(CMD_SDR, FLEXSPI_1PAD, 0xebU, RADDR_SDR, FLEXSPI_4PAD, 0x18U);
    config->memConfig.lookupTable[4U * NOR_CMD_LUT_SEQ_IDX_READ + 1U] =
        FSL_ROM_FLEXSPI_LUT_SEQ(DUMMY_SDR, FLEXSPI_4PAD, 0x06U, READ_SDR, FLEXSPI_4PAD, 0x4U);
    /* Read Status */
    config->memConfig.lookupTable[4U * NOR_CMD_LUT_SEQ_IDX_READSTATUS] =
        FSL_ROM_FLEXSPI_LUT_SEQ(CMD_SDR, FLEXSPI_1PAD, 0x05U, READ_SDR, FLEXSPI_1PAD, 0x1U);
    /* Write Enable */
    config->memConfig.lookupTable[4U * NOR_CMD_LUT_SEQ_IDX_WRITEENABLE] =
        FSL_ROM_FLEXSPI_LUT_SEQ(CMD_SDR, FLEXSPI_1PAD, 0x06U, STOP, FLEXSPI_1PAD, 0x0U);
    /* Page Program - quad mode */
    config->memConfig.lookupTable[4U * NOR_CMD_LUT_SEQ_IDX_PAGEPROGRAM + 0U] =
        FSL_ROM_FLEXSPI_LUT_SEQ(CMD_SDR, FLEXSPI_1PAD, 0x32U, RADDR_SDR, FLEXSPI_1PAD, 0x18U);
    config->memConfig.lookupTable[4U * NOR_CMD_LUT_SEQ_IDX_PAGEPROGRAM + 1U] =
        FSL_ROM_FLEXSPI_LUT_SEQ(WRITE_SDR, FLEXSPI_4PAD, 0x04U, STOP, FLEXSPI_1PAD, 0x0U);
    /* Sector Erase */
    config->memConfig.lookupTable[4U * NOR_CMD_LUT_SEQ_IDX_ERASESECTOR] =
        FSL_ROM_FLEXSPI_LUT_SEQ(CMD_SDR, FLEXSPI_1PAD, 0x20U, RADDR_SDR, FLEXSPI_1PAD, 0x18U);
    /* Block Erase */
    config->memConfig.lookupTable[4U * NOR_CMD_LUT_SEQ_IDX_ERASEBLOCK] =
        FSL_ROM_FLEXSPI_LUT_SEQ(CMD_SDR, FLEXSPI_1PAD, 0xD8U, RADDR_SDR, FLEXSPI_1PAD, 0x18U);
}

/**
* @brief  ���������С
* @note   None
* @param  None
* @retval Flash�����ߴ�
*/
uint32_t onchip_flash_sectorsize_get(void)
{
    return norConfig.sectorSize;//QSPI Flash Sector Size
}

/**
* @brief  �����С��̳���
* @note   None
* @param  None
* @retval 256 or 512 for QSPI Flash
*/
uint32_t FLASH_GetProgramCmd(void)
{
    return norConfig.pageSize;//QSPI Flash Page Program
}

/**
* @brief  ��ʼ��Flash
* @note   None
* @param  None
* @retval None
*/
void onchip_flash_init(void)
{
    /* Clean up FLEXSPI NOR flash driver Structure */
    memset(&norConfig, 0U, sizeof(flexspi_nor_config_t));
    /* Setup FLEXSPI NOR Configuration Block */
    FLEXSPI_NorFlash_GetConfig(&norConfig);
    /* Initializes the FLEXSPI module for the other FLEXSPI APIs */
    ROM_FLEXSPI_NorFlash_Init(0, &norConfig);
    /* Reset the Flexspi's Cache */
    ROM_FLEXSPI_NorFlash_ClearCache(0);
}


/**
* @brief  ����ʼ��Flash
* @note   None
* @param  None
* @retval None
*/
void onchip_flash_deinit(void)
{
    /* Clear the FlexSPI LUT to avoid unexpected erase or program operion trigger */
    memset(&norConfig, 0U, sizeof(flexspi_nor_config_t));
    ROM_FLEXSPI_NorFlash_UpdateLut(0, NOR_CMD_LUT_SEQ_IDX_READSTATUS, norConfig.memConfig.lookupTable, sizeof(norConfig.memConfig.lookupTable) - (4 * NOR_CMD_LUT_SEQ_IDX_READSTATUS));
    /* Reset the Flexspi's Cache */
    ROM_FLEXSPI_NorFlash_ClearCache(0);
}

/**
 * @brief  ����Flash����
 * @note   �ù��ܽ�ɾ��һ��Flash����������
 * @param  addr: ����������ʼ��ַ
 * @retval ���ز������
 */
status_t onchip_flash_erase(uint32_t addr)
{
    status_t status;
    addr &= 0x0FFFFFFF;
    __disable_irq();
    status = ROM_FLEXSPI_NorFlash_Erase(0, &norConfig, addr, norConfig.sectorSize);
    __enable_irq();
    return status;
}


/**
 * @brief  дFlashһ��ҳ
 * @note   �ֽ���С�ڵ���һҳ
 * @param  addr: ��ʼ��ַ
 * @param  buf : д��������ʼָ��
 * @param  len : �ֽ���
 * @retval kStatus_Success�����
 */
status_t onchip_flash_page_write(uint32_t addr, const uint8_t *buf, uint32_t len)
{
    status_t status;
    addr &= 0x0FFFFFFF;
    __disable_irq();
    norConfig.pageSize = len;
    status = ROM_FLEXSPI_NorFlash_ProgramPage(0, &norConfig, addr, (const uint32_t *)buf);
    __enable_irq();
    return status;
}
/**
* @brief  ��Flash����
* @param  addr: ��ʼ��ַ
* @param  buf : ������ָ��
* @param  len : �ֽ���
* @retval kStatus_Success�����
*/
status_t onchip_flash_read(uint32_t addr, const uint8_t *buf, uint32_t len)
{
    
    memcpy((void*)buf,(void*)addr,len);
    #if 0
    status_t status;
    flexspi_xfer_t flashXfer;
    addr &= 0x0FFFFFFF;
    flashXfer.operation = kFLEXSPIOperation_Read;
    flashXfer.seqNum = 1;
    flashXfer.seqId = NOR_CMD_LUT_SEQ_IDX_READ;
    flashXfer.baseAddress = addr;
    flashXfer.isParallelModeEnable = false;
    flashXfer.rxBuffer = (uint32_t *)buf;
    flashXfer.rxSize = len;
    __disable_irq();
    ROM_FLEXSPI_NorFlash_ClearCache(0);
    status = ROM_FLEXSPI_NorFlash_CommandXfer(0, &flashXfer);
    __enable_irq();
    return status;
    #endif
    return 0;
}
/**
* @brief  ������������
* @note   None
* @param  addr: ��ʼ��ַ
* @retval CH_OK����ɣ�CH_ERR��ʧ��
*/
static uint32_t FLASH_SetcorTest(uint32_t addr)
{
    uint32_t ret, i, j;
    uint8_t *p;
    ALIGN(8) uint8_t buf[32];
    uint32_t Sector_Size = onchip_flash_sectorsize_get();
    LIB_TRACE("program addr:0x%X(%dKB) ...", addr, addr / 1024);
    ret = onchip_flash_erase(addr);

    for (i = 0; i < sizeof(buf); i++)
    {
        buf[i] = i % 0xFF;
    }

    for (i = 0; i < (Sector_Size / sizeof(buf)); i++)
    {
        ret += onchip_flash_page_write(addr + sizeof(buf) * i, buf, sizeof(buf));

        if (ret)
        {
            LIB_TRACE("issue command failed\r\n");
            return CH_ERR;
        }
    }

    LIB_TRACE("varify addr:0x%X ...", addr);

    for (i = 0; i < (Sector_Size / sizeof(buf)); i++)
    {
        p = (uint8_t *)(addr + sizeof(buf) * i);

        for (j = 0; j < sizeof(buf); j++)
        {
            if (p[j] != (j % 0xFF))
            {
                ret++;
                LIB_TRACE("ERR:[%d]:0x%02X ", i, *p);
            }
        }
    }

    if (ret == 0)
    {
        LIB_TRACE("OK\r\n");
    }

    return ret;
}

/**
* @brief  ���������ߴ����
* @note   None
* @param  addr: ��ʼ��ַ
* @retval CH_OK����ɣ�CH_ERR��ʧ��
*/
static uint32_t FLASH_SetcorSizeTest(uint32_t addr)
{
    int i;
    uint8_t *p;
    uint32_t Sector_Size = onchip_flash_sectorsize_get();
    FLASH_SetcorTest(addr);
    FLASH_SetcorTest(addr + Sector_Size);
    onchip_flash_erase(addr);
    p = (uint8_t *)(addr);

    for (i = 0; i < Sector_Size * 2; i++)
    {
        /* if (all content = 0xFF), then there is a error */
        if (*p++ != 0xFF)
        {
            break;
        }
    }

    if (i == Sector_Size * 2)
    {
        LIB_TRACE("Flash SectorTest Error in %d\r\n", i);
        return CH_ERR;
    }

    return CH_OK;
}

/**
* @brief  Flash�Բ�
* @note   ȷ�����㹻��ջ�ռ�
* @param  addr: ��ʼ��ַ
* @retval CH_OK����ɣ�CH_ERR��ʧ��
*/
uint32_t FLASH_Test(uint32_t addr, uint32_t len)
{
    int i, ret;
    uint32_t Sector_Size = onchip_flash_sectorsize_get();
    onchip_flash_init();

    for (i = 0; i < (len / Sector_Size); i++)
    {
        ret = FLASH_SetcorTest(addr + i * Sector_Size);

        if (ret != CH_OK)
        {
            return ret;
        }
    }

    return ret;
}

status_t FLEXSPI_NorFlash_GetVendorID(uint32_t instance, uint32_t *vendorID)
{
    uint32_t lut_seq[4];
    memset(lut_seq, 0, sizeof(lut_seq));
    // Read manufacturer ID
    lut_seq[0] = FSL_ROM_FLEXSPI_LUT_SEQ(CMD_SDR, FLEXSPI_1PAD, 0x9F, READ_SDR, FLEXSPI_1PAD, 4);
    ROM_FLEXSPI_NorFlash_UpdateLut(instance, NOR_CMD_LUT_SEQ_IDX_READID, (const uint32_t *)lut_seq, 1U);
    flexspi_xfer_t xfer;
    xfer.operation            = kFLEXSPIOperation_Read;
    xfer.seqId                = NOR_CMD_LUT_SEQ_IDX_READID;
    xfer.seqNum               = 1U;
    xfer.baseAddress          = 0U;
    xfer.isParallelModeEnable = false;
    xfer.rxBuffer             = vendorID;
    xfer.rxSize               = 1U;
    uint32_t status = ROM_FLEXSPI_NorFlash_CommandXfer(instance, &xfer);

    if (*vendorID != kSerialFlash_Winbond_ManufacturerID)
    {
        status = kStatus_ROM_FLEXSPINOR_Flash_NotFound;
        return status;
    }

    return status;
}

