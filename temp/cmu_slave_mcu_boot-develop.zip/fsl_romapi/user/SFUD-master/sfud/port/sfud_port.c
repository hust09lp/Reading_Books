/*
 * This file is part of the Serial Flash Universal Driver Library.
 *
 * Copyright (c) 2016-2018, Armink, <armink.ztl@gmail.com>
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * 'Software'), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * Function: Portable interface for each platform.
 * Created on: 2016-04-23
 */

#include <sfud.h>
#include <stdarg.h>
#include "fsl_gpio.h"
#include "fsl_iomuxc.h"
#include "fsl_clock.h"
#include "fsl_lpspi.h"

static char log_buf[256];

void sfud_log_debug(const char *file, const long line, const char *format, ...);

void rcc_configuration(void)
{
    CLOCK_SetMux(kCLOCK_LpspiMux, 1U);
    CLOCK_SetDiv(kCLOCK_LpspiDiv, 7U);
}

void gpio_configuration(void)
{
    gpio_pin_config_t SPI_CS_config =
    {
        .direction = kGPIO_DigitalOutput,
        .outputLogic = 1U,
        .interruptMode = kGPIO_NoIntmode
    };
    //
    GPIO_PinInit(GPIO2, 11U, &SPI_CS_config);
    //
    IOMUXC_SetPinMux(IOMUXC_GPIO_EMC_03_LPSPI2_SDI, 0U);
    IOMUXC_SetPinMux(IOMUXC_GPIO_EMC_02_LPSPI2_SDO, 0U);
    IOMUXC_SetPinMux(IOMUXC_GPIO_SD_B1_07_LPSPI2_SCK, 0U);
    //
    IOMUXC_SetPinMux(IOMUXC_GPIO_EMC_11_GPIO2_IO11, 0U);
}

void spi_configuration(void)
{
    const lpspi_master_config_t LPSPI2_config =
    {
        .baudRate = 40000000UL,
        .bitsPerFrame = 8UL,
        .cpol = kLPSPI_ClockPolarityActiveHigh,
        .cpha = kLPSPI_ClockPhaseFirstEdge,
        .direction = kLPSPI_MsbFirst,
        .pcsToSckDelayInNanoSec = 1000UL,
        .lastSckToPcsDelayInNanoSec = 1000UL,
        .betweenTransferDelayInNanoSec = 1000UL,
        .whichPcs = kLPSPI_Pcs0,
        .pcsActiveHighOrLow = kLPSPI_PcsActiveLow,
        .pinCfg = kLPSPI_SdiInSdoOut,
        .dataOutConfig = kLpspiDataOutRetained
    };
#define LPSPI2_CLOCK_FREQ (CLOCK_GetFreq(kCLOCK_Usb1PllPfd0Clk) / (7U + 1U))
    LPSPI_MasterInit(LPSPI2, &LPSPI2_config, LPSPI2_CLOCK_FREQ);
}

static void spi_lock(const sfud_spi *spi)
{
    __disable_irq();
}

static void spi_unlock(const sfud_spi *spi)
{
    __enable_irq();
}

// ʵ��ϵͳʱ��500MHz�£�10.265us
static void retry_delay_10us(void)
{
    uint32_t i = 3400;

    while (i--)
    {
        __NOP();
    }
}

// ʵ��ϵͳʱ��500MHz�£�6us
static void delay(void)
{
    uint32_t i = 2000;
    
    while(i--)
    {
        __NOP();
    }
}

/**
 * SPI write data then read data
 */
static sfud_err spi_write_read(const sfud_spi *spi, const uint8_t *write_buf, size_t write_size, uint8_t *read_buf,
                               size_t read_size)
{
    sfud_err result = SFUD_SUCCESS;
    uint8_t send_data, read_data;
    lpspi_transfer_t xfer = {0};
    xfer.configFlags = kLPSPI_MasterPcsContinuous | kLPSPI_MasterByteSwap;

    if (write_size)
    {
        SFUD_ASSERT(write_buf);
    }

    if (read_size)
    {
        SFUD_ASSERT(read_buf);
    }

    GPIO_PinWrite(GPIO2, 11, 0);

    if (write_size)
    {
        xfer.txData = (uint8_t *)write_buf;
        xfer.rxData = NULL;
        xfer.dataSize = write_size;

        if (LPSPI_MasterTransferBlocking(LPSPI2, &xfer) != kStatus_Success)
        {
            return SFUD_ERR_WRITE;
        }
    }

    if (read_size)
    {
        xfer.txData = NULL;
        xfer.rxData = read_buf;
        xfer.dataSize = read_size;

        if (LPSPI_MasterTransferBlocking(LPSPI2, &xfer) != kStatus_Success)
        {
            return SFUD_ERR_READ;
        }
    }

    GPIO_PinWrite(GPIO2, 11, 1);
    delay();
    return result;
}

#ifdef SFUD_USING_QSPI
/**
 * read flash data by QSPI
 */
static sfud_err qspi_read(const struct __sfud_spi *spi, uint32_t addr, sfud_qspi_read_cmd_format *qspi_read_cmd_format,
                          uint8_t *read_buf, size_t read_size)
{
    sfud_err result = SFUD_SUCCESS;
    /**
     * add your qspi read flash data code
     */
    return result;
}
#endif /* SFUD_USING_QSPI */

sfud_err sfud_spi_port_init(sfud_flash *flash)
{
    sfud_err result = SFUD_SUCCESS;

    /**
     * add your port spi bus and device object initialize code like this:
     * 1. rcc initialize
     * 2. gpio initialize
     * 3. spi device initialize
     * 4. flash->spi and flash->retry item initialize
     *    flash->spi.wr = spi_write_read; //Required
     *    flash->spi.qspi_read = qspi_read; //Required when QSPI mode enable
     *    flash->spi.lock = spi_lock;
     *    flash->spi.unlock = spi_unlock;
     *    flash->spi.user_data = &spix;
     *    flash->retry.delay = null;
     *    flash->retry.times = 10000; //Required
     */

    switch (flash->index)
    {
        case SFUD_W25QXX_DEVICE_INDEX:
        {
            /* RCC ��ʼ�� */
            rcc_configuration();
            /* GPIO ��ʼ�� */
            gpio_configuration();
            /* SPI �����ʼ�� */
            spi_configuration();
            /* ͬ�� Flash ��ֲ����Ľӿڼ����� */
            flash->spi.wr = spi_write_read;
            flash->spi.lock = spi_lock;
            flash->spi.unlock = spi_unlock;
            // flash->spi.user_data = &spi1;
            /* about 100 microsecond delay */
            flash->retry.delay = retry_delay_10us;
            /* adout 60 seconds timeout */
            flash->retry.times = 2 * 1000 * (1000 / 10);//60 * 10000;
            break;
        }
    }

    return result;
}

/**
 * This function is print debug info.
 *
 * @param file the file which has call this function
 * @param line the line number which has call this function
 * @param format output format
 * @param ... args
 */
void sfud_log_debug(const char *file, const long line, const char *format, ...)
{
    va_list args;
    /* args point to the first variable parameter */
    va_start(args, format);
    printf("[SFUD](%s:%ld) ", file, line);
    /* must use vprintf to print */
    vsnprintf(log_buf, sizeof(log_buf), format, args);
    printf("%s\r\n", log_buf);
    va_end(args);
}

/**
 * This function is print routine info.
 *
 * @param format output format
 * @param ... args
 */
void sfud_log_info(const char *format, ...)
{
    va_list args;
    /* args point to the first variable parameter */
    va_start(args, format);
    printf("[SFUD]");
    /* must use vprintf to print */
    vsnprintf(log_buf, sizeof(log_buf), format, args);
    printf("%s\r\n", log_buf);
    va_end(args);
}
