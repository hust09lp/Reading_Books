/*
 * Copyright 2020 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "fsl_romapi.h"
#include "fsl_wdog.h"

#include "board.h"

#include "pin_mux.h"
#include "clock_config.h"
#include "board.h"

#include "uart.h"
#include "sci.h"
#include "update.h"
#include "stdio.h"
#include "onchip_flash.h"
#include "fsl_ocotp.h"

#define EXAMPLE_OCOTP_FREQ_HZ (CLOCK_GetFreq(kCLOCK_IpgClk))
/* NOTE: enable this feature will write data to the fuse map, and this operation is
 * irreversible. Please refer to the referance manual before using the read/write
 * function, and calling the write API cautiously.
 */
#define EXAMPLE_OCOTP_SHADOW_REGISTER_READ_WRITE_ENABLE 1U

#if defined(EXAMPLE_OCOTP_SHADOW_REGISTER_READ_WRITE_ENABLE) && (EXAMPLE_OCOTP_SHADOW_REGISTER_READ_WRITE_ENABLE)

#ifndef EXAMPLE_OCOTP_FUSE_MAP_ADDRESS
#define EXAMPLE_OCOTP_FUSE_MAP_ADDRESS 6
#endif

#ifndef EXAMPLE_OCOTP_FUSE_WRITE_VALUE
#define EXAMPLE_OCOTP_FUSE_WRITE_VALUE 0x10
#endif

#endif

void boot_efuse_write(void);

int main(void)
{
    uint8_t ch;    

	
    sci_t sci;
    wdog_config_t config;
    BOARD_ConfigMPU();
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    onchip_flash_init();
    uart_init();
	boot_efuse_write();

    WDOG_GetDefaultConfig(&config);
    config.workMode.enableDebug   = true;
    config.timeoutValue = 0xBU; /* Timeout value is (0xB + 1)/2 = 6 sec. */
    WDOG_Init(WDOG1, &config);
    // �������
    WDOG_Refresh(WDOG1);
    update_upgrade();
    // ��ת
    WDOG_Refresh(WDOG1);
    update_jump();
    
    // SCIͨѶ��ʼ��
    sci.data_send = update_sci_data_send;
    sci.data_swap = update_sci_data_swap;
    sci.slave_addr = 0x01;

    while (1)
    {
        WDOG_Refresh(WDOG1);

        if (update_sci_data_receive(&ch) == 0)
        {
            sci_receive(&sci, ch);
        }

        update_proc();
    }

    return 0;
}

void boot_efuse_write(void)
{
	uint32_t version;
	status_t status;
	uint32_t fuseData = 0U;
	
		    /*
     * When the macro FSL_FEATURE_OCOTP_HAS_TIMING_CTRL is defined as 0, then the
     * OCOTP clock frequency is not used, pass in 0 directly.
     */
    OCOTP_Init(OCOTP, EXAMPLE_OCOTP_FREQ_HZ);

	/* Get the OCOTP controller version. */
    version = OCOTP_GetVersion(OCOTP);
	    /* Example code to write a fuse value and reload the shasdow register to read it back. */
    status   = kStatus_Success;
    

    status = OCOTP_ReadFuseShadowRegisterExt(OCOTP, EXAMPLE_OCOTP_FUSE_MAP_ADDRESS, &fuseData, 1);

    if (status != kStatus_Success)
    {
        printf("Could not read fuse data\r\n");
    }

    printf("The origin value of fuse address 0x%02X is 0x%08X\r\n", EXAMPLE_OCOTP_FUSE_MAP_ADDRESS, fuseData);
	if((fuseData & EXAMPLE_OCOTP_FUSE_WRITE_VALUE) == 0)
	{
		status = OCOTP_WriteFuseShadowRegister(OCOTP, EXAMPLE_OCOTP_FUSE_MAP_ADDRESS, fuseData | EXAMPLE_OCOTP_FUSE_WRITE_VALUE);
		if (kStatus_Success == status)
		{
			printf("OCOTP Write operation success!\r\n");

			status = OCOTP_ReadFuseShadowRegisterExt(OCOTP, EXAMPLE_OCOTP_FUSE_MAP_ADDRESS, &fuseData, 1);

			if (status != kStatus_Success)
			{
				printf("Could not read fuse data\r\n");
			}
			printf("The new value is 0x%08X\r\n", fuseData);
		}
		else
		{
			printf("OCOTP write operation failed. Access deny!\r\n");
		}
	}
}
