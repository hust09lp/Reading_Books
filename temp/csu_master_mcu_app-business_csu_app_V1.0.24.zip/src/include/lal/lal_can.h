/************************************************************************************
 *Description: lal_can
 *Created on: 2023-5-26
 *Author: chenxiao
 ************************************************************************************/

#ifndef __LAL_CAN_H__
#define __LAL_CAN_H__

#include<stdio.h>
#include<stdlib.h>
#include<stdint.h>
#include <arpa/inet.h>
#include<net/if.h>
#include<linux/can.h>
#include<linux/can/error.h>
#include<linux/can/raw.h>

typedef struct can_frame lal_can_msg_t;
typedef struct
{
    uint32_t baud;      ///< 波特率    
	uint32_t mode;		///< 模式
}lal_can_conf_t;
#define CAN_PORT_0 0x00
#define CAN_PORT_1 0x01

int32_t lal_can_open(const uint32_t port);
int32_t lal_can_close(const uint32_t port);
int32_t lal_can_setup(const uint32_t port, const lal_can_conf_t *p_conf);
int32_t lal_can_recv(const uint32_t port, lal_can_msg_t *p_buff, int32_t len, int32_t timeout_ms);
int32_t lal_can_send(const uint32_t port,const lal_can_msg_t *p_buff, const int32_t len);
int32_t lal_can_flush(const uint32_t port);

#endif /* __LAL_CAN_H__ */
