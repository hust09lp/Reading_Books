/************************************************************************************
 *Description: lal_spi
 *Created on: 2022-12-10
 *Author: quliuliu
 ************************************************************************************/

#ifndef __LAL_SPI_H__
#define __LAL_SPI_H__

#include "data_types.h"

#define LAL_SPI_MAX 1
//定义串口操作结构体
typedef struct lal_spi
{
    int32_t fd;        //open()后获得的句柄
    //...
}lal_spi_t;

int32_t lal_spi_mode_set(int32_t fd, uint8_t *p_mode);
int32_t lal_spi_bits_set(int32_t fd, uint8_t *p_bits);
int32_t lal_spi_max_speed_set(int32_t fd, uint32_t *p_max_speed);
int32_t lal_spi_lsb_first_set(int32_t fd, uint8_t *p_first);
int32_t lal_spi_write(int32_t fd, uint8_t *p_buf, uint32_t len);
int32_t lal_spi_read(int32_t fd, uint8_t *p_buf, uint32_t len);
int32_t lal_spi_xfer(int32_t fd, uint8_t *p_out, uint8_t *p_in, uint32_t len);

#endif /* __LAL_SPI_H__ */