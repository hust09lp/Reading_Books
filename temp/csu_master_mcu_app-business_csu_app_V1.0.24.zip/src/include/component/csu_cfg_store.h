#ifndef _CSU_CFG_STORE_H_
#define _CSU_CFG_STORE_H_

#include "csu_comb_type.h"

typedef struct 
{
    bool  power_on;
} csu_master_save_t;

/**
 *  csu_comb_cfg.json
 *  { "role": "master/slave", "eth1Ip": "192.168.2.23", "masterIp":"192.168.2.22", "csuComNum": 8 } 
 */
sf_ret_t csu_cfg_comb_cfg_save( csu_comb_save_setting_t *p_csu_comb_setting );
sf_ret_t csu_cfg_comb_cfg_restore( csu_comb_save_setting_t *p_csu_comb_setting );

sf_ret_t csu_cfg_master_info_save( csu_master_save_t *p_csu_master_save );
sf_ret_t csu_cfg_master_info_restore( csu_master_save_t *p_csu_master_save );

void csu_comb_save_setting_to_csu_comb_setting( const csu_comb_save_setting_t *p_csu_comb_save_setting, csu_comb_setting_t *p_csu_comb_setting );


#endif
