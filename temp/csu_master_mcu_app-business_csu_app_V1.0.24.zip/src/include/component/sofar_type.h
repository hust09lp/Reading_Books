#ifndef __SOFAR_TYPE_H__
#define __SOFAR_TYPE_H__

#include "data_types.h"
#include "sofar_errors.h"

#ifndef BIT
#define BIT(n)                      (1<<(n))
#endif

#define SF_FALSE                    0
#define SF_TRUE                     1

#ifndef ARRAY_SIZE
#define ARRAY_SIZE(array)           ( sizeof(array) / sizeof(array[0]) )
#endif

#define SF_MUTEX_WAIT_FOREVER       0xFFFFFFFFU ///< Wait forever timeout value.

typedef uint32_t                    modbus_idx_t;
#define MODBUS_IDX_INVALID          0xffffffff          /* 无效 modbus index */

#define INT8_MAX_VAL                127
#define INT8_MIN_VAL                -128

#define INT16_MAX_VAL               32767
#define INT16_MIN_VAL               -32768

#define INT32_MAX_VAL               2147483647
#define INT32_MIN_VAL               -2147483648

typedef uint16_t                    dev_idx_t;
#define DEV_IDX_INVALID             0xffff
#define DEV_IDX_ALL                 0xfffe

typedef uint8_t                     usr_uint8_t;
#define USR_U8_VAL_INVALID          0xff

typedef uint16_t                    usr_uint16_t;
#define USR_U16_VAL_INVALID         0xffff

typedef uint32_t                    usr_uint32_t;
#define USR_U32_VAL_INVALID         0xffffffff

typedef int16_t  humi_t;            //< 湿度，单位：1%
typedef int16_t  temper_t;          //< 温度，单位：0.1℃

typedef int32_t  sf_ret_t;          //< 具体参考 sofar_error.h 定义

#define GET_MEMBER_OFFSET( st_type, member )  (size_t)(&((st_type *)0)->member) 

/* 在线状态 */
typedef enum {
    OL_STA_NO_EXSIT ,               // 设备不存在
    OL_STA_ONLINE ,                 // 设备在线
    OL_STA_OFFLINE ,                // 设备离线
} ol_sta_e;

typedef enum {
    SCI_ROLE_MASTER ,               // SCI主
    SCI_ROLE_SLAVE ,                // SCI从
} sci_role_e;


typedef enum {
    NUM_TYPE_BIT,
    NUM_TYPE_U8,
    NUM_TYPE_I8,
    NUM_TYPE_U16,
    NUM_TYPE_I16,
    NUM_TYPE_U32,
    NUM_TYPE_I32,
    NUM_TYPE_U64,
    NUM_TYPE_I64,
    NUM_TYPE_DOUBLE,
    NUM_TYPE_FLOAT,
} num_type_e;


#endif
