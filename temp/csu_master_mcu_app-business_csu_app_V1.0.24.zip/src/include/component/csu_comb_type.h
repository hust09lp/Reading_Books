#ifndef _CSU_COMB_TYPE_H_
#define _CSU_COMB_TYPE_H_

/*---------------------CSU 并柜模块数据类型-----------------------*/
#include "sofar_type.h"


#define CSU_COMB_MAX_SLAVE_CNT       5                                                    //< 支持最大从机数量
#define CSU_COMB_START_SLAVE_ID      1                                                    //< 
#define CSU_COMB_END_SLAVE_ID        (CSU_COMB_START_SLAVE_ID + CSU_COMB_MAX_SLAVE_CNT)                   //< 

#define CSU_COMB_JUNCT_CNT           1                  //< 汇流柜个数

#pragma pack(1)
typedef enum 
{
    CSU_ROLE_SLAVE  = 0,                                //< 从机
    CSU_ROLE_MASTER = 1,                                //< 主机
    CSU_ROLE_JUNCT  = 2,                                //< 汇流柜
    CSU_ROLE_MAX,                                
    CSU_ROLE_INVALID = 0xff,                                
} csu_role_e;

typedef enum {
    SYS_STA_STOP = 0,                                   // 停机状态
    SYS_STA_STANDBY = 1 ,                               // 待机状态
    SYS_STA_RUNNING = 2 ,                               // 运行状态
    SYS_STA_FAULT = 3 ,                                 // 故障状态
    SYS_STA_UPGRADE = 4 ,                               // 升级状态
} sys_sta_e;

typedef struct 
{
    uint8_t     comb_enable;                            // 并机功能是否开启

    csu_role_e  comb_role;                              // 并机的角色
    uint8_t     local_ip[4];                            // 本机 IP

    struct 
    {
        uint8_t     enable;
        uint8_t     con_master_ip[4];                   // 连接主机 IP
    } junct;

    struct {
        uint8_t     comb_num;                           // 并机数量 主机+从机
    } master;                                           // 主机

    struct {
        usr_uint8_t local_slave_id;                     // 本机从机 ID【1~6】 
        uint8_t     con_master_ip[4];                   // 连接主机 IP
    } slave;                                            // 从机
}csu_comb_save_setting_t;

typedef struct
{
    uint8_t     comb_enable;                            // 并机功能是否开启
    uint8_t     junct_enable;                           // 汇流功能是否开启

    csu_role_e  comb_role;                              // 并机的角色
    uint8_t     local_ip[4];                            // 本机 IP
    
    struct {
        uint8_t     comb_num;                           // 并机数量 主机+从机
    } master;                                           // 主机

    struct {
        usr_uint8_t local_slave_id;                     // 本机从机 ID【1~6】 
        uint8_t     con_master_ip[4];                   // 连接主机 IP
    } slave;                                            // 从机
} csu_comb_setting_t;

typedef struct
{
    bool      valid;                                    // 节点有效标识 true：有效 false：无效
    bool      online;                                   // 在线标志  true：在线 false：离线
    char      sn[50];                                   // CSU SN
    uint8_t   ip[4];                                    // IP地址

    struct 
    {
        bool      valid;                                // 实时数据有效标志
        sys_sta_e sys_status;                           // 系统运行状态  0:停机状态，1:待机状态，2:运行状态，3:故障状态，4:升级状态
        uint8_t   charge_prohibit;                      // 禁充标志位  1：禁充 
        uint8_t   discharge_prohibit;                   // 禁放标志位  1：禁放
        int16_t   pcs_charge_max_power;                 // PCS 降额充电功率， 单位 0.01KW   // CMU 
        int16_t   pcs_discharge_max_power;              // PCS 降额放电功率， 单位 0.01KW   // CMU 
        int16_t   bat_charge_max_power;                 // 电池 降额充电功率， 单位 0.01KW
        int16_t   bat_discharge_max_power;              // 电池 降额放电功率， 单位 0.01KW
        uint16_t  SOC;                                  // 电池 SOC
        uint16_t  SOH;                                  // 电池 SOH
        uint16_t  cell_max_vol[6];                      // 电芯最高电压， 单位：1mv 
        uint16_t  cell_min_vol[6];                      // 电芯最低电压， 单位：1mv 
        int16_t   meter_power;                          // 电表功率，单位：0.01KW
        int16_t   curr_pcs_power;                       // 当前PCS功率，单位：0.01KW
        int16_t   bat_vol;                              // 电池电压，单位：0.1V
        int16_t   bat_curr;                             // 电池电流，单位：0.1A
        uint32_t  cluster_cap_energy;                   // 电池簇容量，单位： 0.01KWH
        uint16_t  cluster_num;                          // 电池簇数量
        int16_t   ac_a_curr;                            // A相电流，单位：0.1A
        int16_t   ac_b_curr;                            // b相电流，单位：0.1A
        int16_t   ac_c_curr;                            // c相电流，单位：0.1A
    } real_data;
    
    int16_t   ems_alloc_power;                          // EMS 分配的功率，单位：0.01KW
} csu_node_info_t ; 

typedef struct 
{
    bool      valid;                     // 汇流柜使能标志
    bool      online;                    // 在线标志  true：在线 false：离线
    char      sn[50];                    // SN
    uint8_t   ip[4];                     // IP地址

    struct                          
    {
        bool      enable;               // 汇流柜电表使能位
        int16_t   a_vol;                // 汇流柜电表 A相电压，单位：0.1V【如果电表不使能/用户不使能汇流柜/汇流柜离线， 该变量由主机计算（虚拟数据）】
        int16_t   b_vol;                // 汇流柜电表 B相电压，单位：0.1V【如果电表不使能/用户不使能汇流柜/汇流柜离线， 该变量由主机计算（虚拟数据）】
        int16_t   c_vol;                // 汇流柜电表 C相电压，单位：0.1V【如果电表不使能/用户不使能汇流柜/汇流柜离线， 该变量由主机计算（虚拟数据）】
        int32_t   a_curr;               // 汇流柜电表 A相电流，单位：0.1A【如果电表不使能/用户不使能汇流柜/汇流柜离线， 该变量由主机计算（虚拟数据）】
        int32_t   b_curr;               // 汇流柜电表 B相电流，单位：0.1A【如果电表不使能/用户不使能汇流柜/汇流柜离线， 该变量由主机计算（虚拟数据）】
        int32_t   c_curr;               // 汇流柜电表 C相电流，单位：0.1A【如果电表不使能/用户不使能汇流柜/汇流柜离线， 该变量由主机计算（虚拟数据）】
        int32_t   act_power;            // 汇流柜电表 有功功率，单位：0.01KW【如果电表不使能/用户不使能汇流柜/汇流柜离线， 该变量由主机计算（虚拟数据）】
    } meter_dat;
    
    bool ContactorStatus[7];            // k1~k7 接触器状态：1吸合，0断开
    bool fan_sta;                       // 汇流柜风扇状态
    uint16_t cabinet_type;              // 0：工商业400V  1：工商业690V
    int16_t cab_top_tmp;                // 汇流柜舱顶温度
    int16_t cab_buttom_tmp;             // 汇流柜舱底温度
    int16_t cab_humidity;               // 汇流柜舱内湿度

    bool cab_door_sta;                  // 汇流柜柜门状态
    bool cab_flood_sta;                 // 汇流柜水浸状态
} junct_cab_info_t ; 

typedef struct 
{
    int32_t pcc_power;                  // 并网点功率，单位：0.01KW  -输出 +输入
    int32_t loadPower;                  // 负载功率，单位：0.01KW
    uint16_t  SOC;                      // 系统SOC
    struct 
    {
        bool      enable;               // 光伏电表启用
        uint8_t   num;                  // 光伏电表数量
        int32_t   power;                // 光伏系统总功率   单位： 0.01KW
    } PV_meter;                         // 光伏电表参数
} global_info_t ; 

typedef struct 
{
    uint8_t comb_power_on;                              // 主机设置开关机
} csu_comb_usr_setting_t;


typedef struct 
{
    /* CSU 角色信息 */
    csu_comb_setting_t      comb_setting;                           // 并机设置
    csu_comb_usr_setting_t  usr_setting;                            // 用户设置
    uint8_t                 fast_power_enable;                      // 快速响应功率标志

    csu_node_info_t         master_info;                            // 主机管理下的主机信息
    csu_node_info_t         slave_info[ CSU_COMB_MAX_SLAVE_CNT ];   // 主机管理下的从机信息
    junct_cab_info_t        junct_info;                             // 汇流柜信息
    global_info_t           global_info;                            // 全局信息
} csu_combine_info_t;
#pragma pack()

#endif
