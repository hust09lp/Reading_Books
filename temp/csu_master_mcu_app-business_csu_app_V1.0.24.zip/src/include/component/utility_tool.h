#ifndef _UTILITY_TOOL_H_
#define _UTILITY_TOOL_H_

#include "sofar_type.h"

void utility_tool_network_get_ip( char *interface_name, uint8_t *p_ip );

double double_acc_conversion( double value, uint8_t dot_num );

#endif
