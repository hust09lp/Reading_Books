#ifndef __DATA_SHM_H__
#define __DATA_SHM_H__


#include "data_types.h"
#include "csu_comb_type.h"

#define SCI_V1_8_TEST 1

#define CSU_SYSTEM_FAULT_LEN_BYTE				  4       //CSU系统故障信息
#define COMBINER_CABINET_SYSTEM_STATUS_LEN_BYTE	  8       //CSU系统汇流柜状态信息
#define COMBINER_CABINET_SYSTEM_FAULT_LEN_BYTE	  16       //CSU系统汇流柜故障信息
#define GROUPS_NUM				  				  2       //PCS组播——组数量

#define  NET_ADDR_LEN_MAX                       16      // IP地址长度最大值

#define FILE_TYPE_DEVICE_PARAM                  0       // 设备配置参数文件
#define FILE_TYPE_APP_PARAM                     1       // 应用设置参数文件
#define FILE_TYPE_FACTORY_PARAM                 2       // 工厂设置参数文件
#define FILE_TYPE_EMS_PARAM                 	3       // EMS设置参数文件

#define  SAFETY_PARAM_NUM_MAX                       64      // 安规参数组数据个数

#define PATH_CONF                          "/user/conf/zlog.conf"        // 配置文件路径

#define FILE_SIZE_DEVICE_PARAM      1024            // 设备配置参数文件大小
#define FILE_SIZE_APP_PARAM         (1024 * 2)      // 应用设置参数文件大小
#define FILE_SIZE_FACTORY_PARAM     1024            // 工厂设置参数文件大小
#define FILE_SIZE_EMS_PARAM     	1024            // EMS设置参数文件大小

#define EMS_TIME_DURATION_CNT	10	
#define EMS_HOLIDAY_DATE_NUM	40	

#pragma pack(push)
#pragma pack(1)

typedef struct
{
	uint16_t b0  : 1;
	uint16_t b1  : 1;
	uint16_t b2  : 1;
	uint16_t b3  : 1;
	uint16_t b4  : 1;
	uint16_t b5  : 1;
	uint16_t b6  : 1;
	uint16_t b7  : 1;
	uint16_t b8  : 1;
	uint16_t b9  : 1;
	uint16_t b10 : 1;
	uint16_t b11 : 1;
	uint16_t b12 : 1;
	uint16_t b13 : 1;
	uint16_t b14 : 1;
	uint16_t b15 : 1;
}bits_t;

typedef struct
{
	uint16_t low  : 8;
	uint16_t high : 8;
}bytes_t;

typedef union
{
	bits_t   bits;
	bytes_t  bytes;
	uint16_t all;
}half_word_t;
/**************** 遥信数据 ****************/
typedef struct{
	uint8_t csu_system_fault_info[CSU_SYSTEM_FAULT_LEN_BYTE];								// CSU系统（故障信息）0x1~0x30
	uint8_t combiner_cabinet_system_status_info[COMBINER_CABINET_SYSTEM_STATUS_LEN_BYTE];	// CSU系统汇流柜（状态信息）0x31~0x80
	uint8_t combiner_cabinet_system_fault_info[COMBINER_CABINET_SYSTEM_FAULT_LEN_BYTE];		// CSU系统汇流柜（故障信息）
}telematic_data_t;

#pragma pack(pop)


#pragma pack(push)
#pragma pack(1)

/**************** CSU系统汇流柜0x4001~0x4200 ****************/
typedef struct{
	uint16_t hardware_version_number;
	uint16_t communication_protocol_version_number;
	uint16_t sn_version_number[11];
	uint32_t mcu1_software_version_number;
	uint32_t mcu1_boot_version_number;
	uint32_t mcu1_core_version_number;
	uint32_t mcu2_software_version_number;
	uint32_t mcu2_boot_version_number;
	uint32_t mcu2_core_version_number;
	uint16_t system_power;								//系统额定功率
	uint16_t max_apparent_power;						//最大视在功率
	uint16_t max_active_power;							//最大有功功率
	uint16_t max_reactive_power;						//最大无功功率
    uint16_t csu_sys_state;                             // 0:停机状态 1:待机状态 2:运行状态 3:故障状态 4:升级状态
	uint16_t ext_communication_protocol_version;        // 外部通信协议版本号
}sys_cabinet_version_telemetry_info_t;


/**************** CSU系统汇流柜 MCU2实时数据0x4201~0x4300 ****************/
typedef struct{
	uint16_t system_status;							//系统状态字 0：停机 1：待机 2：故障 3：充电 4：放电
	uint16_t grid_status;							//并离网状态 0：离网 1：并网
	uint16_t grid_side_line_vol_rs;               	// 网侧线电压RS        	0.1/V
	uint16_t grid_side_line_vol_st;               	// 网侧线电压ST        	0.1/V
	uint16_t grid_side_line_vol_tr;               	// 网侧线电压TR        	0.1/V
	uint16_t ac_side_line_vol_rs;            		// 交流侧线电压RS      	0.1/V
	uint16_t ac_side_line_vol_st;            		// 交流侧线电压ST      	0.1/V
	uint16_t ac_side_line_vol_tr;            		// 交流侧线电压TR      	0.1/V
	uint16_t ac_side_phase_current_r;   			//交流侧相电流R			0.1/A
	uint16_t ac_side_phase_current_s;   			//交流侧相电流S			0.1/A
	uint16_t ac_side_phase_current_t;   			//交流侧相电流T			0.1/A
	uint16_t ac_side_freq;   						//交流侧频率			0.01/HZ
	int16_t csu_board_temperature;                  // CSU板温      		0.1/C
	int16_t  at_temperature;                   		// 汇流柜环温     		0.1/C
	int32_t ac_side_active_power;					//交流侧有功功率		0.1/kW
	int32_t ac_side_reactive_power;					//交流侧无功功率		0.1/kW
	int32_t ac_side_phase_view_power;				//交流侧视在功率 		0.1/kVA
	uint32_t daily_charging_capacity;           	//日充电量    			0.1kWh
	uint32_t daily_discharging_capacity;          	//日放电量				0.1kWh
	uint32_t total_charging_capacity;           	//总充电量				1/kWh
	uint32_t total_discharging_capacity;           	//总放电量				1/kWh
	uint32_t total_run_time;						//PCS柜1总运行时间 		0.1/hour
	uint16_t ac_side_phase_vol_r;            		//交流侧相电压R        0.1/V
	uint16_t ac_side_phase_vol_s;            		// 交流侧相电压S        0.1/V
	uint16_t ac_side_phase_vol_t;            		// 交流侧相电压T        0.1/V
	int16_t ac_side_phase_r_active_power;			//交流侧R相有功功率 kW / 0.1
	int16_t ac_side_phase_s_active_power;			//交流侧S相有功功率 kW / 0.1
	int16_t ac_side_phase_t_active_power;			//交流侧T相有功功率 kW / 0.1
	int16_t ac_side_phase_r_reactive_power;			//交流侧R相无功功率 kVar / 0.1
	int16_t ac_side_phase_s_reactive_power;			//交流侧S相无功功率 kVar / 0.1
	int16_t ac_side_phase_t_reactive_power;			//交流侧T相无功功率 kVar / 0.1
	int16_t ac_side_phase_r_view_power;				//交流侧R相视在功率 kVA / 0.1
	int16_t ac_side_phase_s_view_power;				//交流侧S相视在功率 kVA / 0.1
	int16_t ac_side_phase_t_view_power;				//交流侧T相视在功率 kVA / 0.1
	int32_t anti_reflux_power;						//防逆流点表功率		0.1/kW
	uint16_t dry_temp;            		            //除湿器温度       ℃
	uint16_t dry_humidity;            		        //除湿器湿度       RH%
	int32_t photo_meter_power;						//光伏电表总功率		0.1/kW
	uint16_t res[20];								//预留
}sys_cabinet_telemetry_info_t;


/**************** 遥测数据 ****************/
typedef struct{
	sys_cabinet_version_telemetry_info_t sys_version_telemetry_info;		//系统汇流柜遥测数据
	sys_cabinet_telemetry_info_t sys_cabinet_telemetry_info;				//系统汇流柜MCU2实时数据
}telemetry_data_t;

#pragma pack(pop)


#pragma pack(push)
#pragma pack(1)

typedef struct{
	uint16_t storage_duration_operation_data;       // 运行数据存储天数 0~360天
	uint16_t storage_freq_operation_data;           // 运行数据存储频率 3min~60min
	uint16_t number_fault_record;                   // 故障录波条数 0~10条
	uint16_t safety_rdr_country;					//安规国家
	uint16_t ver_safety_rdr_para;				//安规参数版本号
	uint16_t usb_import;						//U盘导入指令
}system_parameter_data_t;


typedef struct
{
	uint16_t backflow_meter  : 1; //防逆流电表使能位0: 关闭 1：打开
	uint16_t metering_meter  : 1; //计量电表使能位0: 关闭 1：打开
	uint16_t micro_computer  : 1; //微机装置使能位0: 关闭 1：打开
	uint16_t measure_control : 1; //智能测控装置使能位0: 关闭 1：打开
	uint16_t dehumidifier    : 1; //除湿器使能位0: 关闭 1：打开
    uint16_t photovoltaic_meter : 1; //光伏电表使能位0: 关闭 1：打开
	uint16_t recv            : 10;
}rs485_device_enable_t;

typedef union
{
	rs485_device_enable_t bit;
	uint16_t all;
}rs485_device_enable_u;

typedef struct{
	int16_t active_power;						//有功功率，单位：0.1KW
	int16_t reactive_power;						//无功功率，单位：0.1KW
	uint16_t pcs_operation_mode;                // PCS运行模式设置 0x0000=并网模式 0x0001=离网模式 0x0010=恒流源模式 0x0020=恒压源模式 0x0100=AFE模式
	uint16_t bus_volt_ref;               		// bus电压给定值设定
	uint16_t const_current_ref;                 // 恒流源电流给定
	int16_t power_factor;						//功率因数给定
	uint16_t reactive_power_manage_mode;        //PCS无功管理模式设置
	uint16_t CEI016_reactive_power_manage_mode; //PCS无功管理CEI016模式设置
	uint16_t pcs_sys_power_mode; 				//PCS系统功率分配方式
	uint16_t power_soft_start_rate;	 			//功率软启动速率
	uint16_t energy_storage_nums;               // 储能柜个数（有CMU的）
	rs485_device_enable_u rs485_device_enable;  // （0=不使能，1=使能）bit0：防逆流电表使能 bit1：计量电表使能 bit2：
												//  微机装置使能 bit3：智能测控装置使能 bit4：除湿器使能
	uint16_t scenario_setting;                  // 0=标准场景，1=单储能柜场景 2= 3=单汇流柜场景
	uint16_t pcs_low_power_enable;				// PCS低功耗模式使能位
	uint16_t pcs_low_power_wait_time;			// PCS等待进入低功耗模式时间
	uint16_t humidity_set;						// 汇流柜湿度设定
	uint16_t humidity_diff_set;					// 汇流柜湿度回差设定
	uint16_t reserver[13];
}cabinet_parameter_data_t;


typedef struct{
	uint16_t	group1[SAFETY_PARAM_NUM_MAX];				//启动参数组
	uint16_t	group2[SAFETY_PARAM_NUM_MAX];				//电压保护参数组
	uint16_t	group3[SAFETY_PARAM_NUM_MAX];				//频率保护参数组
	uint16_t	group4[SAFETY_PARAM_NUM_MAX];				//DCI保护参数组
	uint16_t	group5[SAFETY_PARAM_NUM_MAX];				//远程及有功参数组
	uint16_t	group6[SAFETY_PARAM_NUM_MAX];				//频率有功参数组
	uint16_t	group7[SAFETY_PARAM_NUM_MAX];				//无功参数组
	uint16_t	group8[SAFETY_PARAM_NUM_MAX];				//电压穿越参数组
	uint16_t	group9[SAFETY_PARAM_NUM_MAX];				//孤岛、GFCI、ISO参数
}safety_param_t;

typedef struct{
	uint16_t acb_on;						//0: NA/1: acb合闸
	uint16_t acb_off;					//0: NA/1: acb分闸
	uint16_t sys_fan;					//0: 风扇关闭/1: 风扇开启
}mcu2_internal_param_t;


typedef struct{
	uint16_t remote_control_cmd;						//遥控命令字：bit0:远程开关机 bit1:故障复位 bit2:恢复出厂设置 bit3:切并网 bit4:切离网 bit5:风扇控制
	cabinet_parameter_data_t cabinet_param;				//定值参数
	mcu2_internal_param_t mcu2_inter_param;				//MCU2内部使用参数
}system_param_t;


/**************** EMS参数 ****************/
typedef struct{
	uint16_t enable_type;
	uint16_t start_time;
	uint16_t end_time;
}ems_time_attr_t;

typedef struct{
	uint16_t enable_type;
	int16_t power;
	uint16_t start_time;
	uint16_t end_time;
}ems_holiday_time_attr_t;
// 电价数据结构
#pragma pack(push)
#pragma pack(1)
typedef struct
{
	double flat_price;		//平时段电价
	double valley_price;	//谷时段电价
	double peak_price;		//峰时段电价
	double sharp_price;	//尖峰时段电价
}energy_price_t;
#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)
typedef struct{
	uint16_t demand_resp_en;							// 需求侧相应使能
	uint16_t quantity_demand_dead_zone;					// 需求侧调节死区
	uint16_t quantity_demand;							// 需求侧需量
	uint16_t anti_reflux_action_en;						// 防逆流动作使能
	uint16_t anti_reflux_action_dead_zone;				// 防逆流动作死区
	uint16_t capa_change_need_en;						// 容改需控制使能
	uint16_t capa_change_need_demand;					// 容改需需量
	uint16_t shav_peak_fill_valley_en;					// 削峰填谷使能
	ems_time_attr_t time_attr[EMS_TIME_DURATION_CNT];
	uint16_t end_charge_soc_max;						// 充电结束SOC_MAX
	int16_t pcc_power_set;								// PCC并网点功率设置
	uint16_t k1_coefficient;							// K1系数
	uint16_t theory_max_charge_power;					// 理论允许最大充电功率
	uint16_t discharge_soc_min;							// 放电结束SOC_MIN
	uint16_t discharge_power_adjust_step;				// 放电功率调节步长 --已弃用
	uint16_t k2_coefficient;							// k2系数 --已弃用
	uint16_t theory_max_discharge_power;				// 理论最大放电功率
	uint16_t soc_maintain_en;							// SOC维护使能
	uint16_t soc_maintain_power;						// SOC维护功率
	uint16_t power_adjust_ctr_en;						// 力调节使能
	uint16_t power_adjust_ctr_step;						// 无功功率调节步长
	uint16_t power_factor;								// 功率因数
	uint16_t rated_capa;								// 额定容量
	uint16_t peak_end_early_time;						// 峰时段提前结束时间
	uint16_t sharp_end_early_time;						// 尖峰时段提前结束时间
	uint16_t valley_end_early_time;						// 谷时段提前结束时间
	uint16_t noload_to_standby_time;					// 空载转待机时间
	uint16_t noload_to_shutdown_time;					// 空载转停机时间
	uint16_t poweron_early_time;						// 提前开机时间
    uint16_t self_cosum_mode_enable;					// 自发自用模式使能
    uint16_t meter_curr_dir;					        // 电表电流方向，bit0：电表1 bit1：电表2 bit2：电表3 bit3：电表4
                                                        // 0：正放负充
                                                        // 1：正充负放
    int16_t power[EMS_TIME_DURATION_CNT];               // 节点功率
}ems_data_t;

typedef struct{
	uint16_t holiday_enable;
	ems_holiday_time_attr_t time_attr[EMS_TIME_DURATION_CNT];
	half_word_t holiday_date[EMS_HOLIDAY_DATE_NUM];
}ems_holiday_data_t;
#pragma pack(pop)


#pragma pack(push)
#pragma pack(1)

typedef struct{
	uint32_t control_mode;                                  //小桔运行模式 0：本地 1：远程
	uint32_t transformer_capa;                              //变压器容量
	uint32_t elec_meter1_cnt;                               //电表1数量
    uint32_t elec_meter3_cnt;                               //电表3数量
}elec_meter_param_config_t;
#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)
typedef struct{
	uint16_t meter_cnt;                             //光伏电表数量
    uint8_t curr_dir;                               //光伏电表电流方向
}photovoltaic_meter_cfg_t;                     
#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)
/**************** 定值/参数数据 ****************/
typedef struct{
	system_parameter_data_t sys_param_data;				//CSU系统参数
	cabinet_parameter_data_t cabinet_param_data;		//柜级配置参数
	safety_param_t safety_param;						//安规文件参数
	ems_data_t ems_data;								//EMS参数
	ems_holiday_data_t ems_holiday_data;								//HOLIDAY EMS参数
	system_param_t system_param;
	uint16_t ft_cap_test;								//容测模式
	uint8_t mcu2_notice[6];								//mcu2通知消息0：不动作1：开机2：关机（给PCS发送关机3：停机（给PCS发送紧急关机）
    elec_meter_param_config_t elec_meter_param;         //电表配置参数 
    photovoltaic_meter_cfg_t photovoltaic_meter_cfg;    //光伏电表配置参数
    csu_comb_save_setting_t csu_comb_save_setting;      // 并柜参数设置
}constant_parameter_data_t;
#pragma pack(pop)

/**************** 其他参数 ****************/
typedef struct{

	uint16_t address_rs485_1;                       // RS485-1地址
	uint32_t baud_rate_rs485_1;                     // RS485-1波特率
	uint32_t data_bits_rs485_1;                     // RS485-1数据位
	uint16_t stop_bit_rs485_1;                      // RS485-1停止位
	uint16_t check_bit_rs485_1;                     // RS485-1校验位
	uint16_t address_rs485_2;                       // RS485-2地址
	uint32_t baud_rate_rs485_2;                     // RS485-2波特率
	uint32_t data_bits_rs485_2;                     // RS485-2数据位
	uint16_t stop_bit_rs485_2;                      // RS485-2停止位
	uint16_t check_bit_rs485_2;                     // RS485-2校验位

	uint16_t address_rs485_4;                       // RS485-4地址
	uint32_t baud_rate_rs485_4;                     // RS485-4波特率
	uint32_t data_bits_rs485_4;                     // RS485-4数据位
	uint16_t stop_bit_rs485_4;                      // RS485-4停止位
	uint16_t check_bit_rs485_4;                     // RS485-4校验位

	uint16_t address_rs485_5;                       // RS485-5地址
	uint32_t baud_rate_rs485_5;                     // RS485-5波特率
	uint32_t data_bits_rs485_5;                     // RS485-5数据位
	uint16_t stop_bit_rs485_5;                      // RS485-5停止位
	uint16_t check_bit_rs485_5;                     // RS485-5校验位

	uint16_t address_rs485_6;                       // RS485-6地址
	uint32_t baud_rate_rs485_6;                     // RS485-6波特率
	uint32_t data_bits_rs485_6;                     // RS485-6数据位
	uint16_t stop_bit_rs485_6;                      // RS485-6停止位
	uint16_t check_bit_rs485_6;                     // RS485-6校验位

	uint16_t address_rs485_7;                       // RS485-7地址
	uint32_t baud_rate_rs485_7;                     // RS485-7波特率
	uint32_t data_bits_rs485_7;                     // RS485-7数据位
	uint16_t stop_bit_rs485_7;                      // RS485-7停止位
	uint16_t check_bit_rs485_7;                     // RS485-7校验位

	uint8_t  IP_ETH_1[NET_ADDR_LEN_MAX];              // ETH-1 IP地址
	uint16_t port_ETH_1;                              // ETH-1 端口号
	uint8_t  IP_server_ETH_1_104[NET_ADDR_LEN_MAX];   // ETH-1 104服务器IP地址
	uint16_t port_server_ETH_1_104;                   // ETH-1 014服务器端口号
	uint8_t  IP_server_ETH_1_61850[NET_ADDR_LEN_MAX]; // ETH-1 61850服务器IP地址
	uint16_t port_server_ETH_1_61850;                 // ETH-1 61850服务器端口号

	uint8_t  IP_ETH_2[NET_ADDR_LEN_MAX];              // ETH-2 IP地址
	uint16_t port_ETH_2;                              // ETH-2 端口号
	uint8_t  gw_ETH_2[NET_ADDR_LEN_MAX];              // ETH-2 GW
	uint8_t  mask_ETH_2[NET_ADDR_LEN_MAX];            // ETH-2 MASK
	uint8_t  DNS1_ETH_2[NET_ADDR_LEN_MAX];            // ETH-2 NDS1地址
	uint8_t  DNS2_ETH_2[NET_ADDR_LEN_MAX];            // ETH-2 NDS2地址
	uint8_t  IP_server_ETH_2_104[NET_ADDR_LEN_MAX];   // ETH-2 104服务器IP地址
	uint16_t port_server_ETH_2_104;                   // ETH-2 104服务器端口号
	uint8_t  IP_server_ETH_2_61850[NET_ADDR_LEN_MAX]; // ETH-1 61850服务器IP地址
	uint16_t port_server_ETH_2_61850;                 // ETH-1 61850服务器端口号

	uint8_t  ETH3mode;								  // ETH-3 主从
	uint8_t  IP_ETH_3[NET_ADDR_LEN_MAX];              // ETH-3 IP地址
	uint16_t port_ETH_3;                              // ETH-3 端口号
	uint8_t  IP_server_ETH_3[NET_ADDR_LEN_MAX];       // ETH-3 服务器IP地址
	uint16_t port_server_ETH_3;                       // ETH-3 服务器端口号

	uint16_t state_ctr;                             // 工厂模式-状态控制字；Bit0-Bit7：工厂模式使能位 单板测试使能位 T1完成标志 老化完成标志 T2完成标志 包装测试完成标志 电池老化模式使能 电池激活
	uint16_t privilege_ctrl_word;                   // 工厂模式-特权控制字；每位写入0无效，写入1有效。Bit0：清除校准系数 Bit1：清除运行数据 Bit2：清除故障录波

}other_parameter_data_t;

#pragma pack(pop)

typedef struct{
	uint8_t flag;                                                               // 1：触发生成数据；默认0
	int8_t progress;                                                           //文件接收进度，-1代表接收失败
	int8_t file_name[20];                                                       // 日志名
}mcu2_recorder_data_t;

// 充放电量结构体
#pragma pack(push)
#pragma pack(1)
typedef struct
{
	int16_t active_power_a;				            //A相有功功率
	int16_t active_power_b;				            //B相有功功率
	int16_t active_power_c; 				        //C相有功功率
	int16_t reactive_power_a;				        //A相无功功率
	int16_t reactive_power_b;				        //B相无功功率
	int16_t reactive_power_c; 				        //C相无功功率
	int16_t view_power_a;					        //A相视在功率
	int16_t view_power_b;					        //B相视在功率
	int16_t view_power_c; 					        //C相视在功率
	int32_t view_power_total; 				        //总视在功率
	int16_t power_factor_a;    			            //A相功率因数
	int16_t power_factor_b;    			            //B相功率因数
	int16_t power_factor_c;    			            //C相功率因数
	int16_t power_factor_total;    		            //总功率因数
	uint32_t positive_reactive_energy_total;    	//当前正向无功总电能
	uint32_t positive_reactive_energy_sharp;    	//当前正向无功尖电能
	uint32_t positive_reactive_energy_peak;    		//当前正向无功峰电能
	uint32_t positive_reactive_energy_flat;    		//当前正向无功平电能
	uint32_t positive_reactive_energy_valley;    	//当前正向无功谷电能
	uint32_t negative_reactive_energy_total;    	//当前反向无功总电能
	uint32_t negative_reactive_energy_sharp;    	//当前反向无功尖电能
	uint32_t negative_reactive_energy_peak;    		//当前反向无功峰电能
	uint32_t negative_reactive_energy_flat;    		//当前反向无功平电能
	uint32_t negative_reactive_energy_valley;    	//当前反向无功谷电能
	int16_t volt_a;    							//A相电压，单位 0.1V
	int16_t volt_b;    							//B相电压，单位 0.1V
	int16_t volt_c;    							//C相电压，单位 0.1V
	int16_t current_a;    							//A相电流，单位 0.1A
	int16_t current_b;    							//B相电流，单位 0.1A
	int16_t current_c;    							//C相电流，单位 0.1A
	int32_t active_power_total; 			        //总有功功率（计量表功率）
	int32_t reactive_power_total; 			        //总无功功率
	uint32_t positive_active_energy_total;    		//当前正向有功总电能（计量表放电量）
	uint32_t positive_active_energy_sharp;    		//当前正向有功尖电能
	uint32_t positive_active_energy_peak;    		//当前正向有功峰电能
	uint32_t positive_active_energy_flat;    		//当前正向有功平电能
	uint32_t positive_active_energy_valley;    		//当前正向有功谷电能
	uint32_t negative_active_energy_total;    		//当前反向有功总电能（计量表总充电量）
	uint32_t negative_active_energy_sharp;    		//当前反向有功尖电能
	uint32_t negative_active_energy_peak;    		//当前反向有功峰电能
	uint32_t negative_active_energy_flat;    		//当前反向有功平电能
	uint32_t negative_active_energy_valley;    		//当前反向有功谷电能
	uint16_t freq;									//频率
}modbus_meter_energy_data_t;//点表里定义的电表数据，与SCI协议中的存在精度不一样，数据类型不一样的问题

typedef struct
 {
	int32_t meter_power;                                    // 计量表功率
	uint32_t meter_energy_charge;                                               // 计量表总充电量
	uint32_t meter_energy_discharge;
	uint32_t positive_active_energy_total;    		        //当前正向有功总电能
	uint32_t positive_active_energy_sharp;    		        //当前正向有功尖电能
	uint32_t positive_active_energy_peak;    		        //当前正向有功峰电能
	uint32_t positive_active_energy_flat;    		        //当前正向有功平电能
	uint32_t positive_active_energy_valley;    		        //当前正向有功谷电能
	uint32_t negative_active_energy_total;    		        //当前反向有功总电能
	uint32_t negative_active_energy_sharp;    		        //当前反向有功尖电能
	uint32_t negative_active_energy_peak;    		        //当前反向有功峰电能
	uint32_t negative_active_energy_flat;    		        //当前反向有功平电能
	uint32_t negative_active_energy_valley;    		        //当前反向有功谷电能
	modbus_meter_energy_data_t meter_data;
}meter_energy_data_t;
#pragma pack(pop)


#pragma pack(push)
#pragma pack(1)
typedef struct{
	int32_t active_power_a;				            //A相有功功率
	int32_t active_power_b;				            //B相有功功率
	int32_t active_power_c; 				        //C相有功功率
	int32_t active_power_total; 			        //总有功功率    单位：1w
	int32_t reactive_power_a;				        //A相无功功率
	int32_t reactive_power_b;				        //B相无功功率
	int32_t reactive_power_c; 				        //C相无功功率
	int32_t reactive_power_total; 			        //总无功功率
	int32_t view_power_a;					        //A相视在功率
	int32_t view_power_b;					        //B相视在功率
	int32_t view_power_c; 					        //C相视在功率
	int32_t view_power_total; 				        //总视在功率
	int16_t power_factor_a;    			            //A相功率因数
	int16_t power_factor_b;    			            //B相功率因数
	int16_t power_factor_c;    			            //C相功率因数
	int16_t power_factor_total;    		            //总功率因数
	uint32_t positive_active_energy_total;    		//当前正向有功总电能
	uint32_t positive_active_energy_sharp;    		//当前正向有功尖电能
	uint32_t positive_active_energy_peak;    		//当前正向有功峰电能
	uint32_t positive_active_energy_flat;    		//当前正向有功平电能
	uint32_t positive_active_energy_valley;    		//当前正向有功谷电能
	uint32_t positive_reactive_energy_total;    	//当前正向无功总电能
	uint32_t positive_reactive_energy_sharp;    	//当前正向无功尖电能
	uint32_t positive_reactive_energy_peak;    		//当前正向无功峰电能
	uint32_t positive_reactive_energy_flat;    		//当前正向无功平电能
	uint32_t positive_reactive_energy_valley;    	//当前正向无功谷电能
	uint32_t negative_active_energy_total;    		//当前反向有功总电能
	uint32_t negative_active_energy_sharp;    		//当前反向有功尖电能
	uint32_t negative_active_energy_peak;    		//当前反向有功峰电能
	uint32_t negative_active_energy_flat;    		//当前反向有功平电能
	uint32_t negative_active_energy_valley;    		//当前反向有功谷电能
	uint32_t negative_reactive_energy_total;    	//当前反向无功总电能
	uint32_t negative_reactive_energy_sharp;    	//当前反向无功尖电能
	uint32_t negative_reactive_energy_peak;    		//当前反向无功峰电能
	uint32_t negative_reactive_energy_flat;    		//当前反向无功平电能
	uint32_t negative_reactive_energy_valley;    	//当前反向无功谷电能
	uint32_t volt_a;    							//A相电压
	uint32_t volt_b;    							//B相电压
	uint32_t volt_c;    							//C相电压
	uint32_t current_a;    							//A相电流
	uint32_t current_b;    							//B相电流
	uint32_t current_c;    							//C相电流
	uint32_t freq;									//频率
}photovoltaic_meter_data_t;				//光伏电表数据

typedef struct 
{
    uint32_t photo_meter_daily_capacity;            // 光伏当日发电量        0.1/kWh
    uint32_t photo_meter_total_capacity;            // 光伏总发电量          0.1/kWh
    uint32_t grid_daily_input_capacity;             // 电网当日输入电能      0.1/kWh
    uint32_t grid_total_input_capacity;             // 电网总输入电能        0.1/kWh
    uint32_t grid_daily_output_capacity;            // 电网当日输出电能      0.1/kWh
    uint32_t grid_total_output_capacity;            // 电网总输出电能        0.1/kWh
    int32_t  load_power;                            // 负载功率              0.1/kWh
    uint32_t load_daily_consume_capacity;           // 负载当日耗电量        0.1/kWh
    uint32_t load_total_consume_capacity;           // 负载总耗电量          0.1/kWh
    uint32_t es_daily_discharge_capacity;           // 储能柜 当日放电电能   0.1/kWh
    uint32_t es_daily_charge_capacity;              // 储能柜 当日充电电能   0.1/kWh
    uint32_t es_total_discharge_capacity;           // 储能柜 总放电电能     0.1/kWh
    uint32_t es_total_charge_capacity;              // 储能柜 总充电电能     0.1/kWh
} sys_capacity_t;
#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)
/**************** 内部共用参数 不存储 不对外传输 ****************/
typedef struct{
	mcu2_recorder_data_t mcu2_opt_recorder;     //MCU2的操作日志导出
	mcu2_recorder_data_t mcu2_fault_recorder;   //MCU2的故障日志导出
	mcu2_recorder_data_t mcu2_debug_recorder;   //MCU2的运行日志导出
    meter_energy_data_t total_realtime_energy;  //累计实时充放电量
 	uint16_t safety_update_flag;                //安规更新标识；1有效;(主要方便安规导入时用)
                                                /**	bit0=更新安规国家、版本号
                                                    bit1=更新安规参数1
                                                    bit2=更新安规参数2
                                                    bit3=更新安规参数3
                                                    bit4=更新安规参数4
                                                    bit5=更新安规参数5
                                                    bit6=更新安规参数6
                                                    bit7=更新安规参数7
                                                    bit8=更新安规参数8
                                                    bit9=更新安规参数9
                                                **/
	uint8_t safety_import_flag;	                //安规导入完成标志，1：导入完成
	uint8_t safety_switch_flag;	                //安规切换标志，1：在修改安规国家、版本号等参数时,切换安规
	uint8_t import_result_flag;	                //安规导入成功标志，0传递中，1失败，2成功
	int8_t file_name[64];			            //导入的安规文件名称,例如，安规文件："002-009-0803.txt"，安规包："ESHV_SAFETY_0801.bin"
	int8_t root_path[64];			            //导入的安规文件目录，例如"/tmp/update/"
    uint8_t pack_num;                           //CMU pack数量，6个CMU
    photovoltaic_meter_data_t photovoltaic_meter_data[10];              //光伏电表数据
    photovoltaic_meter_data_t pcc_meter_data;                           //PCC电表数据
	uint8_t cmu_sys_status[6];                  // CMU系统运行状态
    uint16_t cabinet_type;                      // 0：工商业400V  1：工商业690V
    uint8_t sofar_cloud_enable;                 //储能云使能
    uint8_t zcs_cloud_enable;                   //ZCS云使能
    uint8_t sofar_cloud_stage;                  //储能云连接阶段
    uint8_t zcs_cloud_stage;                    //ZCS云连接阶段
	int8_t drmn_power_enable;                   // drmn功率使能
	uint16_t drmn_status;                 // 回读下发给MCU2的DRMn
	uint16_t modbus_recv_timeout;               // modbus接收超时
    uint8_t tz_update_flag;                     // 时区更新标志 bit0:储能云 bit1:ZCS云
    sys_capacity_t sys_capacity;                // 系统电能情况
}internal_shared_data_t;
#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)
/**************** web 控制操作数据（控制指令下发、参数设置） ****************/

typedef struct{
	uint16_t run_state;    // 0关机， 1开机
	uint16_t reset;
	uint16_t acb_on;
	uint16_t acb_off;
	uint16_t fan;	      // 0关， 1开
}control_cmd_data_t;

typedef struct{
	/************ 新设置的参数 ************/
	cabinet_parameter_data_t cabinet_param_data;
	other_parameter_data_t other_parameter_data_update;
	control_cmd_data_t control_cmd_data;
    ems_data_t ems_data;								    //EMS参数
    ems_holiday_data_t ems_holiday_data;								    //EMS参数
    elec_meter_param_config_t elec_meter_param;             //电表配置参数
    uint16_t csu_sn[11];                                    //CSU SN
	uint16_t ft_cap_test;								    //容测模式
    photovoltaic_meter_cfg_t photovoltaic_meter_cfg;        //光伏电表配置参数
	/************ 参数下发标志 ************/
	uint8_t other_parameter_update_flag[5];          		// 更新标志 0-无效  1-有效 数组[0]为RS485-4 数组[1]为RS485-6 数组[2]为ETH-1  数组[3]为ETH-1
	uint16_t cabinet_param_update_flag;						// bit0为ems设置标志 bit1为PCS柜功率设置 bit2 485设备使能 bit3储能柜数量 
                                                            // bit4 CSU应用场景 bit5设置容测模式 bit6变压器容量设置 bit7 SOC上下限设置
                                                            // bit10 电价设置 bit11 光伏电表配置
	uint16_t control_cmd_flag;                   			// bit0为复位指令标志 bit1为开关机指令标志 bit2为acb_on更新标致 bit3为acb_off更新标志  bit4为汇流柜分励脱扣器断开标志           0-无效  1-有效
                                                            // bit5为首航云设置开机 bit6为首航云设置关机 bit7为风扇更新标准 
    uint16_t system_param_flag;                  			// bit0为恢复出厂标志 bit1为更新ETH2标志 bit2为时间更新标志 bit3为设置CSU SN         0-无效  1-有效
                                                            // bit4为CMU同步时间标志
    uint8_t mcu2_notice;									// bit0 CMU1,依次递增
    uint8_t xiaoju_param_set_flag;                          // bit0静置 bit1充电 bit2放电 bit3充电最大限制功率 bit4放电最大限制功率
    uint8_t csu_comb_web_set_flag;                          // csu 并柜web设置标志  bit0：主从信息配置  bit1：主从开机  bit2：主从关机
}web_control_info_t;


typedef struct{
	/************ PCS柜 ************/
	uint16_t pcs_system_control[2];                   // PCS柜遥控设置
	uint16_t pcs_module_control[8][2];                  // PCS模块1-8遥控设置
}modbus_control_info_t;


#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)
#define UPDATE_OBJECT_NUM        12
//CMU固件升级数据结构
typedef struct{
	uint8_t  update_flag[UPDATE_OBJECT_NUM];            // 升级标志，0-无需升级、升级成功; 1-正在升级;
	uint8_t  module_percent[UPDATE_OBJECT_NUM];         // 升级进度,进度值为：0~100
	// uint8_t  file_type[UPDATE_OBJECT_NUM];              // 文件类型编码
	// uint16_t chip_role[UPDATE_OBJECT_NUM];              // 芯片角色编码
}firmware_update_cmu_t;

//固件升级结构体
typedef struct{
	uint8_t  state;             // 0-无; 1-下载; 2-升级; 3-升级中; 4-触发U盘 (下载和升级是分开的：处理逻辑-下载开始时把inform=1，下载完成后inform=0；但是升级只需要inform=2后就不要管，此时由独立任务(update_server)去处理)
	int8_t	 package_name[52];
	int8_t   root_path[32];     // 根路径
	uint8_t  update_flag[UPDATE_OBJECT_NUM];            // 升级标志，0-无需升级、升级成功; 1-正在升级;
	int8_t 	 module_object[UPDATE_OBJECT_NUM][9];       // 升级对象 "MCU1", "MCU2"
	int8_t 	 module_object_bak[UPDATE_OBJECT_NUM][9];   // 升级对象备份，用于不同进程之间获取升级对象
	int8_t   module_name[UPDATE_OBJECT_NUM][56];        // 固件名
	uint8_t  module_percent[UPDATE_OBJECT_NUM];         // 升级进度,进度值为：0~100
	uint8_t  file_type[UPDATE_OBJECT_NUM];              // 文件类型编码
	uint16_t chip_role[UPDATE_OBJECT_NUM];              // 芯片角色编码
    firmware_update_cmu_t dev_cmu_update[6];
	// 针对升级对象有多个相同模块组成的，获取其各个模块的升级结果的反馈 例：[1]BCU，bit0 为BCU_1的升级结果
	uint32_t module_result[UPDATE_OBJECT_NUM];          // 每个bit代表一个模块的结果，0-未升级或升级失败 1-升级成功
	uint8_t module_update_flag;                         // bit0:CSU-MCU1升级标志 bit1:CSU-MCU2升级标志
                                                        // bit2:CMU-MCU1升级标志 bit3:CMU-MCU2升级标志
                                                        // bit4:DSP-M升级标志    bit5:CMU-MCU2升级标志
	uint8_t local_ota_flag;					            // 用于获取升级结束指令后判断CSU是否重启；1:升级开始 2:升级中 3:升级结束
    uint8_t remote_ota_flag;                            // 远程升级状态 0：不存在 1：存在
    int8_t result;                                      // 整体升级结果
}firmware_update_t;
#pragma pack(pop)

// 固件升级通知
typedef enum
{
	NONE=0, DOWNLOAD, UPDATE, UPDATING, UDISK, FAIL
}inform_e;

typedef enum
{
	UPDATE_NONE, UPDATE_ING, UPDATE_FAIL,
}update_state_e;

#pragma pack(push)
#pragma pack(1)
/**************** 内部版本信息 不存储 不对外传输 ****************/
typedef struct{
    uint8_t sys_soft_version[4];                // 版本标识ASCII码+主版本数值+次版本数值+阶段版本数值  原型：V0.0.0
	uint8_t mcu2_core_soft_version[4];                // 版本标识ASCII码+主版本数值+次版本数值+阶段版本数值  原型：V0.0.0
	uint8_t mcu2_app_soft_version[4];                 // 版本标识ASCII码+主版本数值+次版本数值+阶段版本数值  原型：V0.0.0
	uint8_t mcu2_hardware_version[2];                 // 大版本号数值+小版本号数值  原型：V1.0
	uint8_t mcu1_core_soft_version[4];                // 版本标识ASCII码+主版本数值+次版本数值+阶段版本数值  原型：V0.0.0
	uint8_t mcu1_app_soft_version[4];                 // 版本标识ASCII码+主版本数值+次版本数值+阶段版本数值  原型：V0.0.0
	uint8_t mcu1_hardware_version[2];                 // 大版本号数值+小版本号数值  原型：V1.0
	uint8_t sci_protocol_version;                     // 协议版本号数值（001~255）  原型：V001
	uint8_t can_protocol_version;                     // 协议版本号数值（001~255）  原型：V001
	uint8_t iec104_protocol_version;                  // 协议版本号数值（001~255）  原型：V001
	uint8_t iec61850_protocol_version;                // 协议版本号数值（001~255）  原型：V001
	uint8_t ext_communication_protocol_version[2];				  // 外部通信协议版本号
}internal_version_info_t;
#pragma pack(pop)

/**************** 电池充放电参数参数 ****************/
typedef struct{
	uint16_t soc;
	uint16_t soh;
}soc_soh_data_t;

#pragma pack(push)
#pragma pack(1)
typedef struct{
	int16_t  charge_limit_power;					// 充电限制功率，单位： 0.01KW
	int16_t  discharge_limit_power;					// 放点限制功率，单位： 0.01KW
	uint16_t charge_soc_limit;						// SOC充电上限
	uint16_t discharge_soc_lower_limit;				// SOC放电下限
	uint16_t charge_prohibit;						// 禁止充电
	uint16_t discharge_prohibit;					// 禁止放电
	soc_soh_data_t soc_soh_data[6];                 
    int16_t pcs_chg_limit_power;                    // PCS 降额之后的充电限制功率，单位： 0.01KW
    int16_t pcs_dischg_limit_power;                 // PCS 降额之后的放电限制功率，单位： 0.01KW
    uint32_t cluster_cap_energy;                    // 电池簇电池容量，单位： 0.01KWH
    uint16_t cluster_num;                           // 电池簇数量
    int16_t total_vol;                              // 总电压，单位 1V
    int16_t total_curr;                             // 总电流，单位 1A
}bat_charge_data_t;
#pragma pack(pop)

/**************** 箱变参数 ****************/
#pragma pack(push)
#pragma pack(1)
typedef struct{
	uint8_t ultra_h_temp_trip;            		//超高温跳闸
	uint8_t H_volt_fusing_sig;					//高压熔芯熔断信号
	uint8_t H_L_volt_smoke_alarm;				//高低压室变压器室烟雾报警
	uint8_t H_L_volt_temp_alarm;				//高、低压室温感报警
	uint8_t transformer_door_open_alarm;		//变压器室门开报警
	uint8_t H_L_volt_door_open_alarm;			//高、低压室门开报警
	uint8_t H_temp_alarm;						//变压器高温报警
	uint8_t H_volt_side_switch_close;			//高压侧开关合位
	uint8_t H_volt_side_switch_open;			//高压侧开关分位
	uint8_t H_volt_side_isolate_switch_close;	//高压侧隔离开关合位
	uint8_t H_volt_side_isolate_switch_open;	//高压侧开关分位
	uint8_t H_volt_power_disappear;				//高压电源消失
	uint8_t remote_location;           			//远方位置
	uint8_t accident_total_sig;                 //事故总信号
	uint8_t alarm_total_sig;                  	//告警总信号
}transformer_remote_sig_t;
#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)
typedef struct{
	uint16_t phase_ab_volt;						// AB相测量电压
	uint16_t phase_ca_volt;						// CA相测量电压
	uint16_t phase_bc_volt;						// BC相测量电压
	uint16_t sys_freq;   						// 系统频率
	uint16_t tempA;						    	// 干变温控器A相温度
	uint16_t tempB;						    	// 干变温控器B相温度
	uint16_t tempC;						    	// 干变温控器C相温度
	uint16_t transformer_temp_humi;				//变压器室温湿度
	uint32_t positive_active_energy;			// 正向有功电度
	uint32_t positive_reactive_energy;			// 正向无功电度
}transformer_telemetry_data_t;
#pragma pack(pop)


#pragma pack(push)
#pragma pack(1)
typedef struct{
	uint8_t remote_h_volt_switch_close;			//高压开关遥控分闸
	uint8_t remote_h_volt_switch_open;			//高压开关遥控合闸
	uint8_t remote_ctl_switch_flag;				//控制标志
}transformer_remote_ctl_t;
#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)
typedef struct{
	transformer_remote_sig_t remote_sig_status;				// 遥信
	transformer_telemetry_data_t	telemetry_data;			// 遥测
	transformer_remote_ctl_t remote_ctl_switch;				// 遥控
}box_transformer_info_t;
#pragma pack(pop)


#pragma pack(push)
#pragma pack(1)
typedef struct{
	int32_t active_power;						// 有功功率
}combiner_cabinet_data_t;
#pragma pack(pop)


#pragma pack(push)
#pragma pack(1)

typedef struct{
	uint16_t update_start;		//启动升级
	uint8_t file_name[64];		//固件名称
	uint32_t file_length;		//固件长度
	uint32_t file_crc32;		//固件crc校验
	uint16_t file_num;			//升级包内升级固件个数
	uint16_t update_object;		//正在升级文件
								/**	bit0=PCS ARM
									bit1=PCS 主DSP
									bit2=PCS 副DSP
									bit3=FUSE
									bit4=BMS
									bit5=PCU
									bit6=BDU
									bit7=WIFI
									bit8=蓝牙
									bit9=AFCI
									bit10=DCDC
									bit11=MPPT **/
	uint16_t update_percent[12];	//单个升级文件的进度
	uint16_t updated_object;	//已经升级完的对象
								/**	bit0=PCS ARM
									bit1=PCS 主DSP
									bit2=PCS 副DSP
									bit3=FUSE
									bit4=BMS
									bit5=PCU
									bit6=BDU
									bit7=WIFI
									bit8=蓝牙
									bit9=AFCI
									bit10=DCDC
									bit11=MPPT **/
}modbus_other_data_t;

typedef struct{
	uint32_t mcu1_software_version_num;
	uint32_t mcu1_boot_version_num;
	uint32_t mcu1_core_version_num;
	uint16_t hardware_version_num;
	uint16_t run_mode;
	uint16_t test_mode;
	uint16_t do_ctrl;
	uint16_t di_ctrl;
	uint16_t communi_ctrl;					//bit0：CAN通讯测试 bit1：以太网通讯测试
	uint16_t communi_result;
	uint16_t usb_ctrl;						//bit0：USB测试 bit1：SD卡测试
	uint16_t usb_result;
	uint16_t test_result;
	uint16_t acb_on;						//0: NA/1：ACB合闸
	uint16_t acb_off;						//0: NA/1：ACB分闸
	uint16_t fan_ctrl;						//0：风扇关闭/1：风扇开启
}factory_test_data_t;//工厂测试

#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)

typedef struct{
	int32_t active_power_a;				            //A相有功功率
	int32_t active_power_b;				            //B相有功功率
	int32_t active_power_c; 				        //C相有功功率
	int32_t active_power_total; 			        //总有功功率
	int32_t reactive_power_a;				        //A相无功功率
	int32_t reactive_power_b;				        //B相无功功率
	int32_t reactive_power_c; 				        //C相无功功率
	int32_t reactive_power_total; 			        //总无功功率
	int32_t view_power_a;					        //A相视在功率
	int32_t view_power_b;					        //B相视在功率
	int32_t view_power_c; 					        //C相视在功率
	int32_t view_power_total; 				        //总视在功率
	int16_t power_factor_a;    			            //A相功率因数
	int16_t power_factor_b;    			            //B相功率因数
	int16_t power_factor_c;    			            //C相功率因数
	int16_t power_factor_total;    		            //总功率因数
	uint32_t positive_active_energy_total;    		//当前正向有功总电能
	uint32_t positive_active_energy_total_res;    	
	uint32_t positive_active_energy_sharp;    		//当前正向有功尖电能
	uint32_t positive_active_energy_sharp_res;
	uint32_t positive_active_energy_peak;    		//当前正向有功峰电能
	uint32_t positive_active_energy_peak_res;
	uint32_t positive_active_energy_flat;    		//当前正向有功平电能
	uint32_t positive_active_energy_flat_res; 
	uint32_t positive_active_energy_valley;    		//当前正向有功谷电能
	uint32_t positive_active_energy_valley_res;
	uint32_t negative_active_energy_total;    		//当前反向有功总电能
	uint32_t negative_active_energy_total_res;
	uint32_t negative_active_energy_sharp;    		//当前反向有功尖电能
	uint32_t negative_active_energy_sharp_res;
	uint32_t negative_active_energy_peak;    		//当前反向有功峰电能
	uint32_t negative_active_energy_peak_res;  
	uint32_t negative_active_energy_flat;    		//当前反向有功平电能
	uint32_t negative_active_energy_flat_res;
	uint32_t negative_active_energy_valley;    		//当前反向有功谷电能
	uint32_t negative_active_energy_valley_res;
	uint32_t positive_reactive_energy_total;    	//当前正向无功总电能
	uint32_t positive_reactive_energy_total_res;
	uint32_t positive_reactive_energy_sharp;    	//当前正向无功尖电能
	uint32_t positive_reactive_energy_sharp_res; 
	uint32_t positive_reactive_energy_peak;    		//当前正向无功峰电能
	uint32_t positive_reactive_energy_peak_res; 
	uint32_t positive_reactive_energy_flat;    		//当前正向无功平电能
	uint32_t positive_reactive_energy_flat_res;
	uint32_t positive_reactive_energy_valley;    	//当前正向无功谷电能
	uint32_t positive_reactive_energy_valley_res; 
	uint32_t negative_reactive_energy_total;    	//当前反向无功总电能
	uint32_t negative_reactive_energy_total_res;
	uint32_t negative_reactive_energy_sharp;    	//当前反向无功尖电能
	uint32_t negative_reactive_energy_sharp_res;
	uint32_t negative_reactive_energy_peak;    		//当前反向无功峰电能
	uint32_t negative_reactive_energy_peak_res;
	uint32_t negative_reactive_energy_flat;    		//当前反向无功平电能
	uint32_t negative_reactive_energy_flat_res; 
	uint32_t negative_reactive_energy_valley;    	//当前反向无功谷电能
	uint32_t negative_reactive_energy_valley_res;
	uint32_t volt_a;    							//A相电压
	uint32_t volt_b;    							//B相电压
	uint32_t volt_c;    							//C相电压
	uint32_t current_a;    							//A相电流
	uint32_t current_b;    							//B相电流
	uint32_t current_c;    							//C相电流
	uint32_t freq;									//频率
}energy_cabinet_meter_data_t;				//储能柜计量表数据


typedef struct{
	int32_t active_power_a;				            //A相有功功率
	int32_t active_power_b;				            //B相有功功率
	int32_t active_power_c; 				        //C相有功功率
	int32_t active_power_total; 			        //总有功功率
	int32_t reactive_power_a;				        //A相无功功率
	int32_t reactive_power_b;				        //B相无功功率
	int32_t reactive_power_c; 				        //C相无功功率
	int32_t reactive_power_total; 			        //总无功功率
	int32_t view_power_a;					        //A相视在功率
	int32_t view_power_b;					        //B相视在功率
	int32_t view_power_c; 					        //C相视在功率
	int32_t view_power_total; 				        //总视在功率
	int16_t power_factor_a;    			            //A相功率因数
	int16_t power_factor_b;    			            //B相功率因数
	int16_t power_factor_c;    			            //C相功率因数
	int16_t power_factor_total;    		            //总功率因数
	uint32_t negative_active_energy_total;    		//当前反向有功总电能
	uint32_t negative_active_energy_total_res;
	uint32_t negative_active_energy_sharp;    		//当前反向有功尖电能
	uint32_t negative_active_energy_sharp_res;
	uint32_t negative_active_energy_peak;    		//当前反向有功峰电能
	uint32_t negative_active_energy_peak_res;  
	uint32_t negative_active_energy_flat;    		//当前反向有功平电能
	uint32_t negative_active_energy_flat_res;
	uint32_t negative_active_energy_valley;    		//当前反向有功谷电能
	uint32_t negative_active_energy_valley_res;
	uint32_t negative_reactive_energy_total;    	//当前反向无功总电能
	uint32_t negative_reactive_energy_total_res;
	uint32_t negative_reactive_energy_sharp;    	//当前反向无功尖电能
	uint32_t negative_reactive_energy_sharp_res;
	uint32_t negative_reactive_energy_peak;    		//当前反向无功峰电能
	uint32_t negative_reactive_energy_peak_res;
	uint32_t negative_reactive_energy_flat;    		//当前反向无功平电能
	uint32_t negative_reactive_energy_flat_res; 
	uint32_t negative_reactive_energy_valley;    	//当前反向无功谷电能
	uint32_t negative_reactive_energy_valley_res;
	uint32_t positive_active_energy_total;    		//当前正向有功总电能
	uint32_t positive_active_energy_total_res;    	
	uint32_t positive_active_energy_sharp;    		//当前正向有功尖电能
	uint32_t positive_active_energy_sharp_res;
	uint32_t positive_active_energy_peak;    		//当前正向有功峰电能
	uint32_t positive_active_energy_peak_res;
	uint32_t positive_active_energy_flat;    		//当前正向有功平电能
	uint32_t positive_active_energy_flat_res; 
	uint32_t positive_active_energy_valley;    		//当前正向有功谷电能
	uint32_t positive_active_energy_valley_res;
	uint32_t positive_reactive_energy_total;    	//当前正向无功总电能
	uint32_t positive_reactive_energy_total_res;
	uint32_t positive_reactive_energy_sharp;    	//当前正向无功尖电能
	uint32_t positive_reactive_energy_sharp_res; 
	uint32_t positive_reactive_energy_peak;    		//当前正向无功峰电能
	uint32_t positive_reactive_energy_peak_res; 
	uint32_t positive_reactive_energy_flat;    		//当前正向无功平电能
	uint32_t positive_reactive_energy_flat_res;
	uint32_t positive_reactive_energy_valley;    	//当前正向无功谷电能
	uint32_t positive_reactive_energy_valley_res; 
	uint32_t volt_a;    							//A相电压
	uint32_t volt_b;    							//B相电压
	uint32_t volt_c;    							//C相电压
	uint32_t current_a;    							//A相电流
	uint32_t current_b;    							//B相电流
	uint32_t current_c;    							//C相电流
	uint32_t freq;									//频率
}municipal_meter_data_t;				//市电电表数据


typedef struct{
	uint8_t battery_type;					//电池类型
	uint8_t charge_status;					//充放电状态
	uint32_t charge_curr_max; 				//允许最大充电电流
	uint32_t discharge_curr_max; 			//允许最大放电电流
	uint32_t voltage;						//电池簇电压
	uint32_t current;						//电池簇电流
	uint32_t power; 						//电池簇功率
	uint16_t soc; 							//SOC
	uint16_t soh; 							//SOH
	uint16_t monomer_vmin;					//单体最低电压
	uint16_t monomer_vmin_index;			//单体最低电压序号
	uint16_t monomer_vmax; 					//单体最高电压
	uint16_t monomer_vmax_index; 			//单体最高电压序号
	uint16_t monomer_tmin;    				//单体最低温度
	uint16_t monomer_tmin_index;    		//单体最低温度序号
	uint16_t monomer_tmax;    				//单体最高温度
	uint16_t monomer_tmax_index;    		//单体最高温度序号
	uint32_t total_discharge;    			//总放电电量
	uint32_t total_discharge_res;
	uint32_t total_charge;    				//总充电电量
	uint32_t total_charge_res; 
	uint32_t day_discharge;    				//当天放电电量
	uint32_t day_discharge_res;  
	uint32_t day_charge;    				//当天充电电量
	uint32_t day_charge_res; 
	uint16_t pack_num;    					//电池模组数量
	uint16_t monomer_num;    				//每个电池模组单体数量
	uint16_t pack_tpoint_num;    			//每个电池模组温度采样点数量
	uint32_t pack_volt[8];    				//电池模组电压集合
	uint32_t pack_curr[8];    				//电池模组电流集合
	uint32_t pack_power[8];    				//电池模组功率集合
	uint16_t monomer_volt[8 * 48];    		//单体电压集合
	uint16_t monomer_temp[8 * 48];    		//温度集合
}bms_data_t;				//BMS数据

typedef struct{
	uint8_t pcs_status;								//PCS状态
	uint8_t charge_status;							//充放电状态
	uint16_t temp; 									//温度
	uint32_t grid_power; 							//电网功率
	uint32_t load_power;							//负载功率
	uint32_t dc_power;								//直流侧功率
	uint32_t ac_power; 								//交流侧功率
	uint32_t grid_su_energy; 						//馈网电量
	uint32_t grid_su_energy_res;
	uint32_t get_grid_energy;						//电网取电量
	uint32_t get_grid_energy_res;
	uint32_t load_use_energy;						//负载用电量
	uint32_t load_use_energy_res;
	uint32_t grid_volt_r; 							//电网相电压R  
	uint32_t grid_current_r; 						//电网相电流R
	uint32_t grid_freq_r;    						//电网频率R
	uint32_t grid_volt_s;    						//电网相电压S 
	uint32_t grid_current_s;    					//电网相电流S
	uint32_t grid_freq_s;    						//电网频率S
	uint32_t grid_volt_t;    						//电网相电压T
	uint32_t grid_current_t;    					//电网相电流T
	uint32_t grid_freq_t;    						//电网频率T
	uint32_t day_run_time;    						//当天运行时间（单位s）
	uint32_t total_run_time;    					//总运行时间（单位s）
}pcs_data_t;				//PCS数据

typedef struct{
	uint32_t chargr_cmd; 							//充放电命令 00:无动作；01:充电；02:放电
	uint32_t monomer_charge_limit_volt;				//单体充电截止电压
	uint32_t charge_limit_soc;						//充电截止soc
	uint32_t cluster_charge_limit_max_power; 		//电池簇充电允许最大功率
	uint32_t monomer_discharge_limit_volt;			//单体放电截止电压
	uint32_t discharge_limit_soc;					//放电截止soc
	uint32_t cluster_discharge_limit_max_power; 	//电池簇放电允许最大功率
    uint32_t dev_run_mode; 	                        //设备运行策略 1：本地策略 2：云端策略
	uint8_t param_set_falg;							//按照顺序依次占1个bit, bit为0不设置，bit为1设置
}energy_cabinet_param_t;			//储能柜参数设置

typedef struct{
	uint8_t bat_full;								//电池充满
	uint32_t bms_warn[3];							//bms告警
	uint32_t pcs_warn[3];							//pcs告警
	uint32_t dy_warn[3];							//动环告警
}dev_event_t;	

typedef struct{
	uint8_t energy_cabinet_status;						//储能柜状态 0:停机状态，1:待机状态，2:运行状态，3:故障状态，4:升级状态
	energy_cabinet_meter_data_t energy_meter_data;		//储能柜计量表数据
    municipal_meter_data_t energy_meter2_data;		    //计量表2数据
    municipal_meter_data_t energy_meter3_data[5];		//计量表3数据
	bms_data_t bms_data;								//BMS数据
	pcs_data_t pcs_data;								//PCS数据
	dev_event_t dev_event;								//设备事件
	energy_cabinet_param_t energy_cabinet_param;		//云平台设置参数
}mqtt_data_t;			//用于小桔云平台MQTT协议
#pragma pack(pop)


#define SN_MAX_LEN  32
#define VERSION_MAX_LEN  32
#define BCU_NUM_MAX 4
#define WARN_LEVEL_MAX  3
/**************** cmu数据结构 ****************/
typedef struct{
    uint8_t cmu_sn[SN_MAX_LEN];
    uint8_t pcs_sn[SN_MAX_LEN];
    uint8_t bcu_sn[BCU_NUM_MAX][SN_MAX_LEN];
    uint8_t bat_stack_sn[SN_MAX_LEN];
    uint8_t fc_sn[SN_MAX_LEN];
    uint8_t lc_sn[SN_MAX_LEN];
    uint8_t bcu_num;
    uint8_t sign_status;
}cmu_sign_in_data_t;                    //cmu注册数据


typedef struct{
    uint8_t cmu_sn[SN_MAX_LEN];
    uint8_t version[VERSION_MAX_LEN];
    uint8_t safe_version[VERSION_MAX_LEN];
    uint8_t comm_status;
    uint8_t run_status;
}cmu_property_data_t;                    //cmu属性数据


typedef struct{
    cmu_sign_in_data_t sign_data;
    cmu_property_data_t property_data;
}tcp_cmu_data_t;


/**************** pcs数据结构 ****************/
typedef struct{
  	int16_t active_power;				//有功功率，放电为正，充电为负                 0.01kW
	int16_t reactive_power;				//无功功率，逆变器端超前为正，滞后为负  0.01kVar
	int16_t apparent_power;				//视在功率 0.01kVA  
    int16_t power_factor;    			//功率因数
    int16_t grid_volt_r;				//电网相电压R  0.1V
	int16_t grid_volt_s;				//电网相电压S  0.1V
	int16_t grid_volt_t;				//电网相电压T  0.1V
	int16_t ac_current_r;				//交流侧电流R相 0.1A
	int16_t ac_current_s;				//交流侧电流S相 0.1A
	int16_t ac_current_t;				//交流侧电流T相 0.1A
    int16_t grid_freq;					//电网频率	  0.01 Hz
    int16_t bus_volt_pn;				//母线电压  0.1V
	int16_t bus_volt_p;					//正半母线电压  0.1V
	int16_t bus_volt_n;					//正半母线电压  0.1V
    int16_t bat_current;				//电池电流  0.1A
    int16_t bat_power;				    //电池功率  0.01kW
    uint32_t total_energy_charge;       //累计充电量        
    uint32_t total_energy_discharge;    //累计放电量
    uint32_t date;                      //日期
    uint32_t day_energy_charge;         //当日充电量        
    uint32_t day_energy_discharge;      //当日放电量
    uint32_t mon_energy_charge;         //当月充电量        
    uint32_t mon_energy_discharge;      //当月放电量
    uint32_t year_energy_charge;        //当年充电量        
    uint32_t year_energy_discharge;     //当年放电量
    int16_t module_temp;                //模块温度
    int16_t am_temp;                    //环境温度
    uint32_t energy_char_avaiable;      //可充电容量  
    uint32_t energy_dischar_avaiable;   //可放电容量
    uint8_t init_status;                //初始化状态
}pcs_monitor_data_t;                    //pcs监控数据


typedef struct{
    uint8_t pcs_sn[SN_MAX_LEN];                 //pcs序列号
    uint8_t pcs_model[SN_MAX_LEN];              //pcs型号
    uint8_t mdsp_version[VERSION_MAX_LEN];      //主DSP版本号
    uint8_t ldsp_version[VERSION_MAX_LEN];      //副DSP版本号
    uint16_t dev_type;                          //设备类型
    uint16_t rated_power;                       //额定功率
    uint8_t comm_status;                        //通讯状态
    uint8_t sys_status;                         //系统状态
    uint16_t rated_voltage;                     //额定电网电压
}pcs_property_data_t;                           //pcs属性数据

#define PCS_MAX_EVENT_ITEM      61
typedef struct{
    uint16_t event_id;
    uint8_t event_code;                         //0：产生；1：消除
    uint8_t event_level;                        //事件等级
    uint32_t event_time;                        //事件发生时间
}pcs_event_data_t;                              //pcs属性数据

typedef struct{
    pcs_monitor_data_t monitor_data;
    pcs_property_data_t property_data;
    pcs_event_data_t event_data[PCS_MAX_EVENT_ITEM];
}tcp_pcs_data_t;


/**************** bms数据结构 ****************/
#define  CLUSTER_NUMBER                         4       // 电池簇数量
#define  PACK_NUMBER                            8       // 一个电池簇内PACK数量
#define  MONOMER_NUMBER_IN_PACK                 48      // 一个PACK内的单体数量

#define  NORMAL         0
#define  ABNORMAL       1

#define MONOMER_LIMIT_H    3650
#define MONOMER_LIMIT_L    2500


typedef struct{
    int monomer_voltage[MONOMER_NUMBER_IN_PACK];        // PACK的单体电压Uc1-Uc48  精度：0.001V 偏移量：0
    int monomer_temperature[MONOMER_NUMBER_IN_PACK];    // PACK的单体温度Tc1-Tc48  精度：1℃
    int monomer_SOC[MONOMER_NUMBER_IN_PACK];            // PACK的单体SOC 1-48  精度：1% 偏移量：0 范围：0-100
    int monomer_SOH[MONOMER_NUMBER_IN_PACK];            // PACK的单体SOH 1-48  精度：1% 偏移量：0 范围：0-100
    int monomer_status[MONOMER_NUMBER_IN_PACK];         // PACK的单体越限状态
    int16_t pole_pack_t1;                               // PACK1的极柱温度T1  精度：1℃
    int16_t pole_pack_t2;                               // PACK1的极柱温度T2  精度：1℃
}monomer_info_t;


typedef struct{
    int16_t  cluster_voltage;                            // 簇端电压  精度：0.1V
    int16_t  cluster_current;                            // 簇端电流  精度：0.1A
    int16_t  cluster_power;                              // 簇端功率  精度：0.01KW
    uint16_t cluster_SOC;                                // 簇端SOC  精度：1%   偏移量：0
    uint16_t cluster_SOH;                                // 簇端SOH  精度：1%   偏移量：0
    uint16_t monomer_vmax;                               // 单体最高电压  精度：0.001V   偏移量：0
    uint16_t monomer_vmean;                              // 单体平均电压  精度：0.001V   偏移量：0
    uint16_t monomer_vmin;                               // 单体最低电压  精度：0.001V   偏移量：0
    uint16_t monomer_tmax;                               // 单体最高温度  精度：1℃   偏移量：0
    uint16_t monomer_tmean;                              // 单体平均温度  精度：1℃   偏移量：0
    uint16_t monomer_tmin;                               // 单体最低温度  精度：1℃   偏移量：0
    uint32_t cluster_charge_energy;                      //簇可充电量        
    uint32_t cluster_discharge_energy;                   //簇可放电量
    uint32_t total_energy_charge;                        //累计充电量        
    uint32_t total_energy_discharge;                     //累计放电量
    uint16_t positive_insulation_resistance;             //正绝缘阻抗  精度：1KΩ 偏移量：0
    uint16_t negative_insulation_resistance;             //负绝缘阻抗  精度：1KΩ 偏移量：0
    int16_t  high_pressure_box_t1;                       //高压箱温度T1  精度：1℃
    int16_t  high_pressure_box_t2;                       //高压箱温度T2  精度：1℃ 
    int16_t  high_pressure_box_t3;                       //高压箱温度T3  精度：1℃
    int16_t  high_pressure_box_t4;                       //高压箱温度T4  精度：1℃
    monomer_info_t monomer_info[PACK_NUMBER];            //PACK1-8的详细单体数据
    uint8_t init_status;                                 //初始化状态
}bms_monitor_data_t;                                     //bms监控数据


typedef struct{
    uint8_t bms_sn[SN_MAX_LEN];                 //bms序列号
    uint8_t cell_num;                           //电芯数量
    uint8_t comm_status;                        //通讯状态
    uint8_t work_status;                        //工作状态
    uint8_t char_prohibit;                      //禁充状态
    uint8_t dischar_prohibit;                   //禁充状态
    uint8_t main_pos_relay;                     //主正继电器状态
    uint8_t main_nega_relay;                    //主负继电器状态
}bms_property_data_t;                           //pcs属性数据

#define BMS_MAX_EVENT_ITEM      29
typedef struct{
    uint16_t event_id;
    uint8_t event_code;                         //0：产生；1：消除
    uint8_t event_level;                        //事件等级
    uint32_t event_time;                        //事件发生事件
}bms_event_data_t;                              //pcs属性数据

typedef struct{
    bms_monitor_data_t monitor_data;
    bms_property_data_t property_data;
    bms_event_data_t event_data[WARN_LEVEL_MAX][BMS_MAX_EVENT_ITEM];
}tcp_bms_data_t;

/**************** 电池堆数据结构 ****************/
typedef struct{
    int16_t  soc;                                       //电池堆SOC
    int16_t  soh;                                       //电池对SOH
    int16_t  temp_m;                                    //电池堆平均温度
    uint16_t charge;                                    //当前可充电量
    uint16_t discharge;                                 //当前可放电量
    uint32_t total_charge_time;                         //累计充电时长
    uint16_t volt;                                      //电池堆总电压
    int16_t current;                                    //电池堆总电流
    int16_t power;                                      //电池堆总功率
    uint32_t total_energy_charge;                       //累计充电量        
    uint32_t total_energy_discharge;                    //累计放电量
    uint16_t insulation;                                //绝缘电阻
    uint8_t init_status;                                //初始化状态
}bat_stack_monitor_data_t;                              //电池堆监控数据

typedef struct{
    uint8_t bat_stack_sn[SN_MAX_LEN];                   //bms序列号
    uint8_t comm_status;                                //通讯状态
    uint8_t work_status;                                //工作状态
    uint8_t char_prohibit;                              //禁充状态
    uint8_t dischar_prohibit;                           //禁充状态
    uint8_t bcu_num;                                    //电池堆内电池簇数量
    uint8_t pack_num;                                   //电池簇内PACK数量
    uint8_t cell_num;                                   //PACK内电芯数量
}bat_stack_property_data_t;                             //pcs属性数据

typedef struct{
    bat_stack_monitor_data_t monitor_data;
    bat_stack_property_data_t property_data;
}tcp_bat_stack_data_t;

/**************** 消防数据结构 ****************/
typedef struct{
  	int16_t temp;				        //复合传感器温度
	int16_t co;				            //复合传感CO浓度
	int16_t pm25;				        //复合传感PM2.5浓度
    uint8_t init_status;                //初始化状态
}fc_monitor_data_t;                     //消防监控数据

typedef struct{
    uint8_t fc_sn[SN_MAX_LEN];                  //消防序列号
    uint8_t dev_type;                           //设备类型
    uint8_t comm_status;                        //通讯状态
    uint8_t work_status;                        //消防状态
    uint8_t sd_status;                          //烟感状态
    uint8_t td_status;                          //温感状态
}fc_property_data_t;                            //消防属性数据

#define FC_MAX_EVENT_ITEM      50
typedef struct{
    uint16_t event_id;
    uint8_t event_code;                         //0：产生；1：消除
    uint8_t event_level;                        //事件等级
    uint32_t event_time;                        //事件发生事件
}fc_event_data_t;                               //消防事件数据

typedef struct{
    fc_monitor_data_t monitor_data;
    fc_property_data_t property_data;
    fc_event_data_t event_data[FC_MAX_EVENT_ITEM];
}tcp_fc_data_t;


/**************** 液冷数据结构 ****************/
typedef struct{
  	int16_t wp_output;				            //水泵流速
	int16_t fan_output;				            //风机输出
	int16_t effluent_temp;				        //出水温度
    int16_t ascent_temp;				        //回水温度
    int16_t effluent_pressure;				    //出水压力
    int16_t ascent_pressure;				    //回水压力
    int16_t temp;				                //环境温度
    uint8_t init_status;                        //初始化状态
}lc_monitor_data_t;                             //液冷监控数据

typedef struct{
    uint8_t lc_sn[SN_MAX_LEN];                  //液冷序列号
    uint8_t dev_type;                           //设备类型
    uint8_t comm_status;                        //通讯状态
    uint8_t work_status;                        //运行状态
    uint8_t work_mode;                          //运行模式
    uint8_t warn_status;                        //告警状态
    uint8_t wp_status;                          //水泵状态
    uint8_t cp_status;                          //压缩机状态
    uint8_t eh_status;                          //电加热状态
    uint8_t fan_status;                         //风机状态
}lc_property_data_t;                            //液冷属性数据

#define LC_MAX_EVENT_ITEM      60
typedef struct{
    uint16_t event_id;
    uint8_t event_code;                         //0：产生；1：消除
    uint8_t event_level;                        //事件等级
    uint32_t event_time;                        //事件发生事件
}lc_event_data_t;                               //液冷事件数据

typedef struct{
    lc_monitor_data_t monitor_data;
    lc_property_data_t property_data;
    lc_event_data_t event_data[FC_MAX_EVENT_ITEM];
}tcp_lc_data_t;


typedef struct{
    tcp_cmu_data_t cmu_data;
    tcp_pcs_data_t pcs_data;
    tcp_bms_data_t bms_data[CLUSTER_NUMBER];
    tcp_bat_stack_data_t bat_stack_data;
    tcp_fc_data_t fc_data;
    tcp_lc_data_t lc_data;
}energy_cabinet_data_t;


typedef struct{
	telematic_data_t telematic_data;                    // 104 遥信数据
	telemetry_data_t telemetry_data;                    // 104 遥测数据
	constant_parameter_data_t constant_parameter_data;  // 104 定值/参数
	other_parameter_data_t other_parameter_data;        // 其他参数
	internal_shared_data_t internal_shared_data;		// 内部共用参数
	firmware_update_t update;                           // 升级相关信息
	web_control_info_t web_control_info;                // web控制操作相关信息
	internal_version_info_t internal_version_info;      // 内部版本信息
	bat_charge_data_t bat_charge_data[6];
	energy_price_t energy_price;
	box_transformer_info_t box_transformer_data;		// 箱变信息
	combiner_cabinet_data_t combiner_cabinet_data;		// 汇流柜数据
	mqtt_data_t mqtt_data;								//小桔云平台数据
    csu_combine_info_t csu_combine_data;                // CSU 主从并柜信息
    energy_cabinet_data_t energy_cabinet_data;          // 储能柜数据
}common_data_t;


#endif /* __DATA_SHM_H__ */


