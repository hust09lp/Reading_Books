#ifndef __APP_COMMON_H__
#define __APP_COMMON_H__


#include "data_types.h"

#define MAX_SLAVE_COUNT 6
#define MAX_IP_LEN 16

typedef enum
{
    DO5_INDEX  = 74,
    DO7_INDEX  = 69,
    DO8_INDEX  = 80,
    DO9_INDEX  = 71,
    DO10_INDEX = 72,
    DO11_INDEX = 77,
    DO12_INDEX = 74,
    DO13_INDEX = 79,
    DO14_INDEX = 78,
}DIDO_NUM_E;

//以下定义针对sdk_dido_write使用
#define INDEX_DO_OUT5                   (5)  

#define DI_DO_HIGH 1
#define DI_DO_LOW  0

#define BIT_CPL(value, bit) ((value) ^= (1 << (bit)))           //取反指定位
#define BIT_SET(value, bit) ((value) |= (1 << (bit)))           //置位指定位
#define BIT_CLR(value, bit) ((value) &=~(1 << (bit)))           //清零指定位
#define BIT_GET(value, bit) (((value) &  (1 << (bit))) >> (bit))  //读取指定位

#define CMU1_IP  "192.168.2.100"
#define CMU2_IP  "192.168.2.101"
#define CMU3_IP  "192.168.2.102"
#define CMU4_IP  "192.168.2.103"
#define CMU5_IP  "192.168.2.104"
#define CMU6_IP  "192.168.2.105"

#define DRM0   "/sys/devices/platform/soc/2100000.aips-bus/2198000.adc/iio:device0/in_voltage9_raw"
#define DRM1   "/sys/devices/platform/soc/2100000.aips-bus/2198000.adc/iio:device0/in_voltage3_raw"
#define DRM2   "/sys/devices/platform/soc/2100000.aips-bus/2198000.adc/iio:device0/in_voltage4_raw"
#define DRM3   "/sys/devices/platform/soc/2100000.aips-bus/2198000.adc/iio:device0/in_voltage1_raw"
#define DRM4   "/sys/devices/platform/soc/2100000.aips-bus/2198000.adc/iio:device0/in_voltage2_raw"

#define DRMN_POWER_RATIO_CFG   "/user/conf/drmn_power_ratio_cfg.json"
#endif