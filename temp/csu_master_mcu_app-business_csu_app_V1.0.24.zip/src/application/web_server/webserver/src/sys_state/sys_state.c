#include "cJSON.h"
#include "cJSON_ext.h"
#include "json_utils.h"
#include "common.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "libghttp.h"
#include "app_common.h"
#include "web_data_trans2cmu.h"
#include "csu_state_monitor.h"
#include "web_broker.h"
#include "cmu_data_monitor.h"
#include "sys_state.h"
#include "operation_log.h"
#include "fault_log.h"
#include "upgrade.h"
#include "mem_utils.h"
#include "utility_tool.h"
#include "mongoose.h"

#include "data_shm.h"

#define METER_MIN_ERR_POWER               (1.0)                             // 电表功率最小误差，单位：1KW
#define METER_MAX_ERR_POWER               (1.73)                            // 电表功率最大误差，单位：1KW
#define CAB_AUX_MAX_POWER                 (6.0)                             // 储能柜辅电最大功率，单位：1KW
#define CSU_COMB_PARALLEL_CAB_MAX_CNT     (CSU_COMB_MAX_SLAVE_CNT + 1)      // 最大并机数量

typedef struct 
{
    bool     online;    // 在线状态
    double_t power;     // 功率，单位：1KW
} dev_power_info_t; 

typedef struct {
    uint8_t  cab_num;                                              // 并柜数量
    dev_power_info_t  cab_ems[ CSU_COMB_PARALLEL_CAB_MAX_CNT ];    // 储能柜功率 +放电 -充电 【索引 0：主机  1之后：从机】
    dev_power_info_t  cab_meter[ CSU_COMB_PARALLEL_CAB_MAX_CNT ];  // 储能柜功率 +放电 -充电 【索引 0：主机  1之后：从机】
    dev_power_info_t  pv;                                          // 光伏功率 +放电 
    dev_power_info_t  grid;                                        // 电网功率 +输入 -输出
} input_power_info_t;

typedef struct {
    uint8_t           cab_num;                                     // 并柜数量
    dev_power_info_t  cab_meter[ CSU_COMB_PARALLEL_CAB_MAX_CNT ];  // 储能柜功率 +放电 -充电 【索引 0：主机  1之后：从机】
    double_t          cab_sum_power;                               // 储能柜总和功率【计算】 +放电 -充电 ，单位：1KW
    dev_power_info_t  pv;                                          // 光伏功率 +放电
    dev_power_info_t  grid;                                        // 电网功率 +输入 -输出
    dev_power_info_t  load;                                        // 负载功率 +输入
} show_power_info_t;

typedef struct{
    uint16_t sys_status;
    int16_t bat_volt;
    int16_t bat_current;
    double ac_volt;
    double ca_volt;
    double bc_volt;
    double ac_current;
    double ca_current;
    double bc_current;
    int16_t power;
    uint16_t insulation;
    uint16_t soc;
    uint16_t soh;
    double lceffluent_temp;
    double lcascent_temp;
    uint16_t lceffluent_pressure;
    uint16_t lcascent_pressure;
    uint16_t battery_flood_status;
    uint16_t battery_door_status;
    uint16_t equipment_flood_status;
    uint16_t equipment_door_status;
    uint16_t liquid_cooling_status;
}cmu_sys_info_t;                        //CMU系统信息


typedef struct
{
    double total_power[6];
    double energy_meter_power;
    double pv_power;
    double pcc_power;
    double load_power;
}DEV_POWER_DATA_T;

typedef struct
{
    double charge[32];                                
    double discharge[32];    
}data_energy_t;

static uint8_t g_sys_status = MAX;          //系统状态

static cmu_sys_info_t cmu_sys_info[MAX_SLAVE_COUNT] = {0};

static DEV_POWER_DATA_T g_dev_power = {0};    //功率数据

static uint8_t cmu_ip_tbl[MAX_SLAVE_COUNT][MAX_IP_LEN] = {CMU1_IP, CMU2_IP, CMU3_IP, CMU4_IP, CMU5_IP, CMU6_IP};

static uint32_t s_topo_err_pack_cnt = 0;     // 拓扑图误包次数

/**
 * @brief   设置本地CMU状态位
 * @param	 [in] index CMU编号
 * @param	 [in] sys_status CMU状态
 * @note    
 * @return  
 */
void cmu_sys_status_set(uint8_t index, uint16_t sys_status)
{
    cmu_sys_info[index - 1].sys_status = sys_status;
}


/**
 * @brief   检测汇流柜是否有严重故障
 * @param   
 * @note    
 * @return  
 */
uint8_t combiner_cabinet_get_serious_fault(void)
{
	telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();

    // 系统严重故障&汇流柜重要故障检测，需做系统关机
    if((p_telematic_data->csu_system_fault_info[0] & FAULT_BIT_4) |                   //SCI通信故障
       (p_telematic_data->csu_system_fault_info[1] & FAULT_BIT_7) |                   // CSU并柜从机：本机通信失联（3级）
       (p_telematic_data->csu_system_fault_info[2] & FAULT_BIT_2) |                   //并网开关位置故障& FAULT_BIT_7) | 
    (p_telematic_data->combiner_cabinet_system_fault_info[0] & FAULT_BIT_2) |         //监控板过温保护
    (p_telematic_data->combiner_cabinet_system_fault_info[0] & FAULT_BIT_3) |         //AC舱过温保护
    (p_telematic_data->combiner_cabinet_system_fault_info[1] & FAULT_BIT_1) |         //门禁告警
    (p_telematic_data->combiner_cabinet_system_fault_info[1] & FAULT_BIT_3) |         //并网开关位置故障
    (p_telematic_data->combiner_cabinet_system_fault_info[1] & FAULT_BIT_7) |         //绝缘监测故障
    (p_telematic_data->combiner_cabinet_system_fault_info[4] & FAULT_BIT_3) |         //PCS模块机型读取错误
    (p_telematic_data->combiner_cabinet_system_fault_info[4] & FAULT_BIT_5) |         //STS开关位置故障
    (p_telematic_data->combiner_cabinet_system_fault_info[4] & FAULT_BIT_6) |         //QF3故障
    (p_telematic_data->combiner_cabinet_system_fault_info[2] & FAULT_BIT_1))          //远程REPO故障(紧急故障)
    {
        return FAULT_YES;
    }
    return FAULT_NO;
}



/**
 * @brief    系统是否满足开机条件，根据三级故障来判定，不需要关心CMU故障
 * @return  ture:满足；false:不满足
 */
bool if_poweron_allow(void)
{
    if(combiner_cabinet_get_serious_fault() == FAULT_NO)
    {
        return true;
    }
    return false;
}



/**
 * @brief    CSU系统状态
 * @return  sys_status_e
 */
sys_status_e sys_status_get(void)
{
    uint8_t dev_num;
    // uint8_t dev_status = 0;
    uint8_t online_cnt = 0;

    //先检查CSU本身是否处于升级状态
    if(if_dev_in_upgrade_status())
    {
        return UPGRADE;
    }

    for(dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
    {
        if(dev_is_online(dev_num))
        {
            online_cnt++;
            break;
        }
    }
    if(online_cnt == 0)
    {
        return STOP;
    }

    //只要有一个在线CMU处于升级状态，系统就属于升级状态
    for(dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
    {
        if(dev_is_online(dev_num))
        {
            if(cmu_sys_info[dev_num - 1].sys_status == UPGRADE)
            {
                return UPGRADE;
            }
        }
    }

    //只要有一个在线CMU处于运行状态，系统就属于运行状态
    for(dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
    {
        if(dev_is_online(dev_num))
        {
            if(cmu_sys_info[dev_num - 1].sys_status == RUN)
            {
                return RUN;
            }
        }
    }

    //CMU全部故障、箱变故障或者汇流柜严重故障，系统就属于故障状态
    g_sys_status = FAULT;
    for(dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
    {
        if(combiner_cabinet_get_serious_fault() != FAULT_NO)
        {
            break;
        }
        if(dev_is_online(dev_num))
        {
            if(cmu_sys_info[dev_num - 1].sys_status != FAULT)
            {
                g_sys_status = MAX;
                break;
            }
        }
    }
    
    if(g_sys_status == FAULT)
    {
        return FAULT;
    }

    //CMU全部停机，系统就属于停机状态
    g_sys_status = STOP;
    for(dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
    {
        if(dev_is_online(dev_num))
        {
            if(cmu_sys_info[dev_num - 1].sys_status != STOP)
            {
                g_sys_status = MAX;
                break;
            }
        }
    }
    
    if(g_sys_status == STOP)
    {
        return STOP;
    }

    //CMU全部待机，系统就属于待机状态
    g_sys_status = WAIT;
    for(dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
    {
        if(dev_is_online(dev_num))
        {
            if(cmu_sys_info[dev_num - 1].sys_status != WAIT)
            {
                g_sys_status = MAX;
                break;
            }
        }
    }
    
    if(g_sys_status == WAIT)
    {
        return WAIT;
    }

    //CMU全部休眠，系统就属于休眠状态
    g_sys_status = SLEEP;
    for(dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
    {
        if(dev_is_online(dev_num))
        {
            if(cmu_sys_info[dev_num - 1].sys_status != SLEEP)
            {
                g_sys_status = MAX;
                break;
            }
        }
    }
    
    if(g_sys_status == SLEEP)
    {
        return SLEEP;
    }

    return false;
}


/**
 * @brief    CMU系统状态
 * @return  sys_status_e
 */
sys_status_e cmu_sys_status_get(void)
{
    uint8_t dev_num;
    // uint8_t dev_status = 0;
    uint8_t online_cnt = 0;

    for(dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
    {
        if(dev_is_online(dev_num))
        {
            online_cnt++;
            break;
        }
    }
    if(online_cnt == 0)
    {
        return STOP;
    }

    //只要有一个在线CMU处于升级状态，系统就属于升级状态
    for(dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
    {
        if(dev_is_online(dev_num))
        {
            if(cmu_sys_info[dev_num - 1].sys_status == UPGRADE)
            {
                return UPGRADE;
            }
        }
    }

    //只要有一个在线CMU处于运行状态，系统就属于运行状态
    for(dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
    {
        if(dev_is_online(dev_num))
        {
            if(cmu_sys_info[dev_num - 1].sys_status == RUN)
            {
                return RUN;
            }
        }
    }

    //CMU全部故障、箱变故障或者汇流柜严重故障，系统就属于故障状态
    g_sys_status = FAULT;
    for(dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
    {
        if(dev_is_online(dev_num))
        {
            if(cmu_sys_info[dev_num - 1].sys_status != FAULT)
            {
                g_sys_status = MAX;
                break;
            }
        }
    }
    
    if(g_sys_status == FAULT)
    {
        return FAULT;
    }

    //CMU全部停机，系统就属于停机状态
    g_sys_status = STOP;
    for(dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
    {
        if(dev_is_online(dev_num))
        {
            if(cmu_sys_info[dev_num - 1].sys_status != STOP)
            {
                g_sys_status = MAX;
                break;
            }
        }
    }
    
    if(g_sys_status == STOP)
    {
        return STOP;
    }

    //CMU全部待机，系统就属于待机状态
    g_sys_status = WAIT;
    for(dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
    {
        if(dev_is_online(dev_num))
        {
            if(cmu_sys_info[dev_num - 1].sys_status != WAIT)
            {
                g_sys_status = MAX;
                break;
            }
        }
    }

    if(g_sys_status == WAIT)
    {
        return WAIT;
    }

    //CMU全部休眠，系统就属于休眠状态
    g_sys_status = SLEEP;
    for(dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
    {
        if(dev_is_online(dev_num))
        {
            if(cmu_sys_info[dev_num - 1].sys_status != SLEEP)
            {
                g_sys_status = MAX;
                break;
            }
        }
    }
    
    if(g_sys_status == SLEEP)
    {
        return SLEEP;
    }

    return false;
}

/**
 * @brief    CSU系统信息获取
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void csu_sys_info_get(struct mg_connection *p_nc,struct http_message *p_msg)
{
    uint8_t ret = 0;
    uint8_t url[128] = {0};
    cJSON *p_request = NULL;
    cJSON *p_resp_array = NULL;
    cJSON *p_resp_item = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t disp_op_logs;
    int32_t total_op_logs = 0;
    history_event_new_t event_item[FUALT_LOG_LATEST_5_ITEM];
    operation_log_t operation_item[OPERATION_LOG_LATEST_5_ITEM];
    uint32_t item_num = 0;
	int8_t fault_type_text[64];
    uint8_t response[1024*2] = {0}; 
    cJSON *p_response = NULL;
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t request_body[128] = {0};
    uint8_t text_name[128] = {0};
    int32_t total_power = 0;
    uint8_t time_stamp[16] = {0};
    uint8_t uri[] = {"/homePage/getCMUSystemInfo"};
    uint8_t json_str[] = {"{\"action\":\"getCMUSystemInfo\"}"};  

    combiner_cabinet_data_t *p_combiner_cabinet_data =  sdk_shm_combiner_cabinet_data_get();
    box_transformer_info_t *p_box_transformer_data = sdk_shm_box_transformer_data_info_get();
	transformer_telemetry_data_t *p_telemetry_data = &(p_box_transformer_data->telemetry_data);

    memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		SYS_STATE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getSystemInfo"))
	{
		SYS_STATE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

    for(uint8_t dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
    {
        if(dev_is_online(dev_num))
        {
            sprintf(url, "%s%s%s", "http://", cmu_ip_tbl[dev_num - 1], uri);
            ret = http_net_post(url, json_str, response);
            if(ret != 1)
            {
                continue;
            }
            // SYS_STATE_DEBUG_PRINT("%s", response);
            p_response = cJSON_Parse(response);
            if(p_response == NULL)
            {
                SYS_STATE_DEBUG_PRINT("parse request failed.");
                continue;
            }
            cJSON *data = cJSON_GetObjectItem(p_response, "data");
            if(data == NULL)
            {
                SYS_STATE_DEBUG_PRINT("parse data failed.");
                continue;
            }

            cmu_sys_info[dev_num - 1].sys_status = cJSON_GetObjectItem(data,"systemstatus")->valueint;
            cmu_sys_info[dev_num - 1].bat_volt = cJSON_GetObjectItem(data,"batVolt")->valueint;
            cmu_sys_info[dev_num - 1].bat_current = cJSON_GetObjectItem(data,"batCurrent")->valueint;
            cmu_sys_info[dev_num - 1].ac_volt = cJSON_GetObjectItem(data,"acVolt")->valuedouble;
            cmu_sys_info[dev_num - 1].ca_volt = cJSON_GetObjectItem(data,"caVolt")->valuedouble;
            cmu_sys_info[dev_num - 1].bc_volt = cJSON_GetObjectItem(data,"bcVolt")->valuedouble;
            cmu_sys_info[dev_num - 1].ac_current = cJSON_GetObjectItem(data,"acCurrent")->valuedouble;
            cmu_sys_info[dev_num - 1].ca_current = cJSON_GetObjectItem(data,"caCurrent")->valuedouble;
            cmu_sys_info[dev_num - 1].bc_current = cJSON_GetObjectItem(data,"bcCurrent")->valuedouble;
            cmu_sys_info[dev_num - 1].power = cJSON_GetObjectItem(data,"ACPower")->valueint;
            if(cJSON_GetObjectItem(data,"Insulation") != NULL)
            {
                cmu_sys_info[dev_num - 1].insulation = cJSON_GetObjectItem(data,"Insulation")->valueint;
            }
            cmu_sys_info[dev_num - 1].soc = cJSON_GetObjectItem(data,"soc")->valueint;
            cmu_sys_info[dev_num - 1].soh = cJSON_GetObjectItem(data,"soh")->valueint;
            cmu_sys_info[dev_num - 1].lceffluent_temp = cJSON_GetObjectItem(data,"lceffluentTemp")->valuedouble;
            cmu_sys_info[dev_num - 1].lcascent_temp = cJSON_GetObjectItem(data,"lcascentTemp")->valuedouble;
            cmu_sys_info[dev_num - 1].lceffluent_pressure = cJSON_GetObjectItem(data,"lceffluentPressure")->valueint;
            cmu_sys_info[dev_num - 1].lcascent_pressure = cJSON_GetObjectItem(data,"lcascentPressure")->valueint;
            cmu_sys_info[dev_num - 1].battery_flood_status = cJSON_GetObjectItem(data,"batteryFloodStatus")->valueint;
            cmu_sys_info[dev_num - 1].battery_door_status = cJSON_GetObjectItem(data,"batteryDoorStatus")->valueint;
            cmu_sys_info[dev_num - 1].equipment_flood_status = cJSON_GetObjectItem(data,"equipmentFloodStatus")->valueint;
            cmu_sys_info[dev_num - 1].equipment_door_status = cJSON_GetObjectItem(data,"equipmentDoorStatus")->valueint;
            cmu_sys_info[dev_num - 1].liquid_cooling_status = cJSON_GetObjectItem(data,"liquidCoolingStatus")->valueint;
            cJSON_Delete(p_response);
        }
	}
    p_resp_array = cJSON_CreateArray();
    if(p_resp_array == NULL)
    {
        SYS_STATE_DEBUG_PRINT("create json array failed");
        return;
    }

    csu_combine_info_t *p_csu_combine_info = &sdk_shm_get()->csu_combine_data;

    if ( p_csu_combine_info->comb_setting.comb_enable == SF_TRUE
        && p_csu_combine_info->comb_setting.comb_role == CSU_ROLE_MASTER)
    {
        for ( size_t i = 0; i < p_csu_combine_info->comb_setting.master.comb_num; i++ )
        {
            /*  */
            p_resp_item = cJSON_CreateObject();
            if(p_resp_item == NULL)
            {
                SYS_STATE_DEBUG_PRINT("create json obj failed");
                cJSON_Delete(p_resp_array);
                return;
            }

            csu_node_info_t *p_node_info = (i == 0)? &p_csu_combine_info->master_info: &p_csu_combine_info->slave_info[i-1];

            cJSON_AddNumberToObject(p_resp_item,"devNum"       , i );
            cJSON_AddNumberToObject(p_resp_item,"systemstatus" , p_node_info->real_data.sys_status );
            cJSON_AddNumberToObject(p_resp_item,"batVolt"      , p_node_info->real_data.bat_vol / 10.0 );
            cJSON_AddNumberToObject(p_resp_item,"batCurrent"   , p_node_info->real_data.bat_curr / 10.0 );
            cJSON_AddNumberToObject(p_resp_item,"power"        , p_node_info->real_data.meter_power / 100.0  );
            cJSON_AddNumberToObject(p_resp_item,"soc"          , p_node_info->real_data.SOC );
            cJSON_AddNumberToObject(p_resp_item,"soh"          , p_node_info->real_data.SOH );

            
            cJSON_AddNumberToObject(p_resp_item,"acVolt"               , 0);
            cJSON_AddNumberToObject(p_resp_item,"caVolt"               , 0);
            cJSON_AddNumberToObject(p_resp_item,"bcVolt"               , 0);
            cJSON_AddNumberToObject(p_resp_item,"acCurrent"            , 0);
            cJSON_AddNumberToObject(p_resp_item,"caCurrent"            , 0);
            cJSON_AddNumberToObject(p_resp_item,"bcCurrent"            , 0);
            cJSON_AddNumberToObject(p_resp_item,"Insulation"           , 0);
            cJSON_AddNumberToObject(p_resp_item,"lceffluentTemp"       , 0);
            cJSON_AddNumberToObject(p_resp_item,"lcascentTemp"         , 0);
            cJSON_AddNumberToObject(p_resp_item,"lceffluentPressure"   , 0);
            cJSON_AddNumberToObject(p_resp_item,"lcascentPressure"     , 0);
            cJSON_AddNumberToObject(p_resp_item,"batteryFloodStatus"   , 0);
            cJSON_AddNumberToObject(p_resp_item,"batteryDoorStatus"    , 0);
            cJSON_AddNumberToObject(p_resp_item,"equipmentFloodStatus" , 0);
            cJSON_AddNumberToObject(p_resp_item,"equipmentDoorStatus"  , 0);
            cJSON_AddNumberToObject(p_resp_item,"liquidCoolingStatus"  , 0);
            total_power += p_node_info->real_data.meter_power;
            cJSON_AddItemToArray(p_resp_array,p_resp_item);
        }
    }else{
        //添加在线CMU系统信息
        for(uint8_t i = 0; i < MAX_SLAVE_COUNT; i++)
        {
            if(dev_is_online(i + 1))
            {
                p_resp_item = cJSON_CreateObject();
                if(p_resp_item == NULL)
                {
                    SYS_STATE_DEBUG_PRINT("create json obj failed");
                    cJSON_Delete(p_resp_array);
                    return;
                }
                cJSON_AddNumberToObject(p_resp_item,"devNum",i + 1);
                cJSON_AddNumberToObject(p_resp_item,"systemstatus",cmu_sys_info[i].sys_status);
                cJSON_AddNumberToObject(p_resp_item,"batVolt",cmu_sys_info[i].bat_volt);
                cJSON_AddNumberToObject(p_resp_item,"batCurrent",cmu_sys_info[i].bat_current);
                cJSON_AddNumberToObject(p_resp_item,"acVolt",cmu_sys_info[i].ac_volt);
                cJSON_AddNumberToObject(p_resp_item,"caVolt",cmu_sys_info[i].ca_volt);
                cJSON_AddNumberToObject(p_resp_item,"bcVolt",cmu_sys_info[i].bc_volt);
                cJSON_AddNumberToObject(p_resp_item,"acCurrent",cmu_sys_info[i].ac_current);
                cJSON_AddNumberToObject(p_resp_item,"caCurrent",cmu_sys_info[i].ca_current);
                cJSON_AddNumberToObject(p_resp_item,"bcCurrent",cmu_sys_info[i].bc_current);
                cJSON_AddNumberToObject(p_resp_item,"power",cmu_sys_info[i].power);
                cJSON_AddNumberToObject(p_resp_item,"Insulation",cmu_sys_info[i].insulation);
                cJSON_AddNumberToObject(p_resp_item,"soc",cmu_sys_info[i].soc);
                cJSON_AddNumberToObject(p_resp_item,"soh",cmu_sys_info[i].soh);
                cJSON_AddNumberToObject(p_resp_item,"lceffluentTemp",cmu_sys_info[i].lceffluent_temp);
                cJSON_AddNumberToObject(p_resp_item,"lcascentTemp",cmu_sys_info[i].lcascent_temp);
                cJSON_AddNumberToObject(p_resp_item,"lceffluentPressure",cmu_sys_info[i].lceffluent_pressure);
                cJSON_AddNumberToObject(p_resp_item,"lcascentPressure",cmu_sys_info[i].lcascent_pressure);
                cJSON_AddNumberToObject(p_resp_item,"batteryFloodStatus",cmu_sys_info[i].battery_flood_status);
                cJSON_AddNumberToObject(p_resp_item,"batteryDoorStatus",cmu_sys_info[i].battery_door_status);
                cJSON_AddNumberToObject(p_resp_item,"equipmentFloodStatus",cmu_sys_info[i].equipment_flood_status);
                cJSON_AddNumberToObject(p_resp_item,"equipmentDoorStatus",cmu_sys_info[i].equipment_door_status);
                cJSON_AddNumberToObject(p_resp_item,"liquidCoolingStatus",cmu_sys_info[i].liquid_cooling_status);
                total_power += cmu_sys_info[i].power;
                cJSON_AddItemToArray(p_resp_array,p_resp_item);
            }
        }
    } 

    //添加在线状态
    cJSON *p_online_array = cJSON_CreateArray();

    if ( p_csu_combine_info->comb_setting.comb_enable == SF_TRUE 
        && p_csu_combine_info->comb_setting.comb_role == CSU_ROLE_MASTER)
    {
        for ( size_t i = 0; i < (CSU_COMB_MAX_SLAVE_CNT + 1); i++ )
        {
            if ( i == 0 )
            {
                cJSON_AddItemToArray(p_online_array, cJSON_CreateNumber( p_csu_combine_info->master_info.online ));
            }else{
                cJSON_AddItemToArray(p_online_array, cJSON_CreateNumber( p_csu_combine_info->slave_info[i-1].online ));
            }
        }
    }else{
        for(uint16_t i = 0; i < MAX_SLAVE_COUNT; i++)
        {
            cJSON_AddItemToArray(p_online_array, cJSON_CreateNumber(dev_is_online(i + 1)));
        }
    }

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        SYS_STATE_DEBUG_PRINT("create json obj failed");
        cJSON_Delete(p_resp_array);
        return;
    }

    junct_cab_info_t *p_junct_cab_info = &sdk_shm_csu_combine_data_get()->junct_info;
    /* 启用并柜的情况下，使用 系统电能信息 */
    if ( p_csu_combine_info->comb_setting.comb_enable == SF_TRUE 
        && (p_csu_combine_info->comb_setting.comb_role == CSU_ROLE_MASTER
            || p_csu_combine_info->comb_setting.comb_role == CSU_ROLE_JUNCT))
    {
        cJSON_AddNumberToObject(p_resp_root,"CSUabVolt", p_junct_cab_info->meter_dat.a_vol / 10.0 );
        cJSON_AddNumberToObject(p_resp_root,"CSUbcVolt", p_junct_cab_info->meter_dat.b_vol / 10.0 );
        cJSON_AddNumberToObject(p_resp_root,"CSUcaVolt", p_junct_cab_info->meter_dat.c_vol / 10.0 );
        cJSON_AddNumberToObject(p_resp_root,"CSUacCurrent", p_junct_cab_info->meter_dat.a_curr / 10.0 );
        cJSON_AddNumberToObject(p_resp_root,"CSUcaCurrent", p_junct_cab_info->meter_dat.b_curr / 10.0 );
        cJSON_AddNumberToObject(p_resp_root,"CSUbcCurrent", p_junct_cab_info->meter_dat.c_curr / 10.0 );
        cJSON_AddNumberToObject(p_resp_root,"CSUtotalPower",total_power / 100);
    }else{
        cJSON_AddNumberToObject(p_resp_root,"CSUabVolt",cmu_sys_info[0].ac_volt);
        cJSON_AddNumberToObject(p_resp_root,"CSUcaVolt",cmu_sys_info[0].ca_volt);
        cJSON_AddNumberToObject(p_resp_root,"CSUbcVolt",cmu_sys_info[0].bc_volt);
        cJSON_AddNumberToObject(p_resp_root,"CSUacCurrent",cmu_sys_info[0].ac_current);
        cJSON_AddNumberToObject(p_resp_root,"CSUcaCurrent",cmu_sys_info[0].ca_current);
        cJSON_AddNumberToObject(p_resp_root,"CSUbcCurrent",cmu_sys_info[0].bc_current);
        cJSON_AddNumberToObject(p_resp_root,"CSUtotalPower",total_power );
    }

    cJSON_AddNumberToObject(p_resp_root,"code",OK);
    cJSON_AddNumberToObject(p_resp_root,"CSUsystemstatus",sys_status_get());
    cJSON_AddNumberToObject(p_resp_root,"CSUInsulation",cmu_sys_info[0].insulation);
    cJSON_AddNumberToObject(p_resp_root,"CSUpccPower",p_combiner_cabinet_data->active_power);
    cJSON_AddItemToObject(p_resp_root,"online",p_online_array);
    cJSON_AddItemToObject(p_resp_root,"data",p_resp_array);


    junct_cab_info_t   *p_junct = &sdk_shm_get()->csu_combine_data.junct_info;
    csu_comb_setting_t *p_comb_setting = &sdk_shm_get()->csu_combine_data.comb_setting;
    internal_shared_data_t *p_internal_shared_data = &sdk_shm_get()->internal_shared_data;
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();
    telemetry_data_t *p_telemetry = sdk_shm_telemetry_data_get();

    if ( sdk_shm_get()->constant_parameter_data.cabinet_param_data.scenario_setting == 3 )
    {
        /* 单汇流柜场景 */
        /* 直接根据自身情况 */
        cJSON_AddNumberToObject(p_resp_root,"CombinerCabinetEnable", 1 );

        cJSON_AddNumberToObject(p_resp_root, "CabinTopTemperature"   , p_telemetry->sys_cabinet_telemetry_info.dry_temp );
        cJSON_AddNumberToObject(p_resp_root, "CabinBottomTemperature", p_telemetry->sys_cabinet_telemetry_info.at_temperature / 10 );
        cJSON_AddNumberToObject(p_resp_root, "Humidity"              , p_telemetry->sys_cabinet_telemetry_info.dry_humidity );
        cJSON_AddNumberToObject(p_resp_root, "FanStatus"             , mem_utils_get_bit_val( p_telematic_data->combiner_cabinet_system_status_info, 26 ) );
        cJSON_AddNumberToObject(p_resp_root, "DoorStatus"            , mem_utils_get_bit_val( p_telematic_data->combiner_cabinet_system_status_info, 2 ) );
        cJSON_AddNumberToObject(p_resp_root, "FloodStatus"           , mem_utils_get_bit_val( p_telematic_data->combiner_cabinet_system_status_info, 1 ) );

        uint8_t con_sta[ ARRAY_SIZE(  p_junct->ContactorStatus ) ] = {0};
        for (size_t i = 0; i < ARRAY_SIZE(con_sta) ; i++)
        {
            con_sta[i] = mem_utils_get_bit_val( p_telematic_data->combiner_cabinet_system_status_info, 19+i ) ;
        }
        cJSON_AddNumberArrayToObject( p_resp_root, "ContactorStatus" , NUM_TYPE_U8 , con_sta, ARRAY_SIZE(con_sta));

    }else if ( p_comb_setting->junct_enable == SF_TRUE )
    {
        /* 根据主机传回的数据进行显示 */
        cJSON_AddNumberToObject(p_resp_root,"CombinerCabinetEnable", 1 );

        cJSON_AddNumberToObject(p_resp_root, "highPressureSystemFlag", p_junct->cabinet_type );
        cJSON_AddNumberToObject(p_resp_root, "CabinTopTemperature"   , p_junct->cab_top_tmp );
        cJSON_AddNumberToObject(p_resp_root, "CabinBottomTemperature", p_junct->cab_buttom_tmp / 10 );
        cJSON_AddNumberToObject(p_resp_root, "Humidity"              , p_junct->cab_humidity );
        cJSON_AddNumberToObject(p_resp_root, "FanStatus"             , p_junct->fan_sta );
        cJSON_AddNumberToObject(p_resp_root, "DoorStatus"            , p_junct->cab_door_sta );
        cJSON_AddNumberToObject(p_resp_root, "FloodStatus"           , p_junct->cab_flood_sta );
        cJSON_AddNumberArrayToObject( p_resp_root, "ContactorStatus" , NUM_TYPE_U8 , p_junct->ContactorStatus, sizeof( p_junct->ContactorStatus ));
    }else{
        cJSON_AddNumberToObject(p_resp_root,"CombinerCabinetEnable", 0 );
        cJSON_AddNumberToObject(p_resp_root, "highPressureSystemFlag", 0 );
        cJSON_AddNumberToObject(p_resp_root, "CabinTopTemperature"   , 0 );
        cJSON_AddNumberToObject(p_resp_root, "CabinBottomTemperature", 0 );
        cJSON_AddNumberToObject(p_resp_root, "Humidity"              , 0 );
        cJSON_AddNumberToObject(p_resp_root, "FanStatus"             , 0 );
        cJSON_AddNumberToObject(p_resp_root, "DoorStatus"            , 0 );
        cJSON_AddNumberToObject(p_resp_root, "FloodStatus"           , 0 );
        cJSON_AddNumberArrayToObject( p_resp_root, "ContactorStatus" , NUM_TYPE_U8 , p_junct->ContactorStatus, sizeof( p_junct->ContactorStatus ));
    }

	/**以下是添加五条操作日志**/
    ret = home_page_operation_log_latest_5_item_get((void *)operation_item, &item_num);
    if ((ret < 0) || (item_num > FUALT_LOG_LATEST_5_ITEM))
    {
        item_num = 0;
    }
    cJSON *p_op_item;
	cJSON *p_op_array = cJSON_CreateArray();
	if(p_op_array == NULL)
	{
        SYS_STATE_DEBUG_PRINT("create json array failed.");
        cJSON_Delete(p_resp_root);
        return;
	}

    for(uint8_t i = 0; i < item_num; i++)
    {
        p_op_item = cJSON_CreateObject();
        if(p_op_item == NULL)
        {
            SYS_STATE_DEBUG_PRINT("create json obj failed.");
            cJSON_Delete(p_op_array); 
            cJSON_Delete(p_resp_root);
            return;
        }
         /*操作日志类型,转换为ID传输*/
        cJSON_AddNumberToObject(p_op_item,"opType", get_operationid_by_name(operation_item[i].op_type));
        cJSON_AddStringToObject(p_op_item,"timeStamp",operation_item[i].time_stamp);
        cJSON_AddItemToArray(p_op_array,p_op_item);
    }
    cJSON_AddItemToObject(p_resp_root,"opLog",p_op_array); 

	/**以下是添加五条故障日志**/
    ret = home_page_fault_log_latest_5_item_get((void *)event_item, &item_num);
    if ((ret < 0) || (item_num > FUALT_LOG_LATEST_5_ITEM))
    {
        item_num = 0;
    }
    cJSON *p_fault_item;
    cJSON *p_fault_array = cJSON_CreateArray();
    if(p_fault_array == NULL)
    {
        SYS_STATE_DEBUG_PRINT("create json array failed.");
        cJSON_Delete(p_resp_root);
        return;
    }

    for(uint8_t i = 0; i < item_num; i++)
    {
        p_fault_item = cJSON_CreateObject();
        if(p_fault_item == NULL)
        {
            SYS_STATE_DEBUG_PRINT("create json obj failed.");
            cJSON_Delete(p_fault_array); 
            cJSON_Delete(p_resp_root);
            return;
        }
    
         /*只传输故障ID,前端解析*/
        cJSON_AddNumberToObject(p_fault_item, "faultType", event_item[i].event_id);
        // 故障时间
        cJSON_AddStringToObject(p_fault_item,"timeStamp",event_item[i].start_time);
        cJSON_AddItemToArray(p_fault_array,p_fault_item);
    }
    cJSON_AddItemToObject(p_resp_root,"faultLog",p_fault_array); //将五条操作日志加入到resp_root里面

    cJSON_AddStringToObject(p_resp_root,"msg","success");

    p = cJSON_PrintUnformatted(p_resp_root);
    http_back(p_nc,p);
    cJSON_Delete(p_resp_root);
    free(p);
}

/**
 * @brief    判断储能柜功率和计量表功率方向是否一致
 * @param	 [in] total_dc_power：储能柜直流功率 
 * @param	 [in] energy_meter_power：计量表功率
 * @return
 */
bool if_power_direction_same(double total_dc_power, double energy_meter_power)
{
    if(((total_dc_power > 0) && (energy_meter_power < 0)) || ((total_dc_power < 0) && (energy_meter_power > 0)))
    {
        return false;
    }
    return true;
}

sf_ret_t input_power_info_printf( input_power_info_t *p_input_power_info )
{
    log_i("-----------------input_power_info_printf--------------------\r\n");
    printf("cab_num = %d\r\n", p_input_power_info->cab_num);
    printf("master cab_ems[0].online = %d\r\n", p_input_power_info->cab_ems[0].online);
    printf("master cab_ems[0].power = %f\r\n", p_input_power_info->cab_ems[0].power);
    printf("master cab_meter[0].online = %d\r\n", p_input_power_info->cab_meter[0].online);
    printf("master cab_meter[0].power = %f\r\n", p_input_power_info->cab_meter[0].power);

    for (size_t i = 1; i < CSU_COMB_PARALLEL_CAB_MAX_CNT; i++)
    {
        printf("slave cab_ems[%d].online = %d\r\n", i, p_input_power_info->cab_ems[i].online);
        printf("slave cab_ems[%d].power = %f\r\n", i, p_input_power_info->cab_ems[i].power);
        printf("slave cab_meter[%d].online = %d\r\n", i, p_input_power_info->cab_meter[i].online);
        printf("slave cab_meter[%d].power = %f\r\n", i, p_input_power_info->cab_meter[i].power);
    }

    printf("pv.online = %d\r\n", p_input_power_info->pv.online);
    printf("pv.power = %f\r\n", p_input_power_info->pv.power);
    
    printf("grid.online = %d\r\n", p_input_power_info->grid.online);
    printf("grid.power = %f\r\n", p_input_power_info->grid.power);

    return SF_OK;
}

sf_ret_t show_power_info_printf( show_power_info_t *p_show_power_info )
{
    log_i("-----------------show_power_info_printf--------------------\r\n");
    printf("cab_num = %d\r\n", p_show_power_info->cab_num);
    printf("cab_sum_power = %f\r\n", p_show_power_info->cab_sum_power);
    printf("master cab_meter[0].online = %d\r\n", p_show_power_info->cab_meter[0].online);
    printf("master cab_meter[0].power = %f\r\n", p_show_power_info->cab_meter[0].power);

    for (size_t i = 1; i < CSU_COMB_PARALLEL_CAB_MAX_CNT; i++)
    {
        printf("slave cab_meter[%d].online = %d\r\n", i, p_show_power_info->cab_meter[i].online);
        printf("slave cab_meter[%d].power = %f\r\n", i, p_show_power_info->cab_meter[i].power);
    }

    printf("pv.online = %d\r\n", p_show_power_info->pv.online);
    printf("pv.power = %f\r\n", p_show_power_info->pv.power);
    
    printf("grid.online = %d\r\n", p_show_power_info->grid.online);
    printf("grid.power = %f\r\n", p_show_power_info->grid.power);

    return SF_OK;
}

sf_ret_t input_power_info_package( input_power_info_t *p_input_power_info )
{
    internal_shared_data_t *p_internal_shared_data = &sdk_shm_get()->internal_shared_data;
    csu_combine_info_t     *p_csu_combine_info     = &sdk_shm_get()->csu_combine_data;

    p_input_power_info->cab_num = p_csu_combine_info->comb_setting.master.comb_num;

    /* 主机必须在线 */
    p_input_power_info->cab_ems[0].online = 1;
    p_input_power_info->cab_ems[0].power  = p_csu_combine_info->master_info.ems_alloc_power / 100.0f;
    p_input_power_info->cab_meter[0].online = 1;
    p_input_power_info->cab_meter[0].power  = p_csu_combine_info->master_info.real_data.meter_power / 100.0f;

    /* 从机 */
    for (size_t i = 0; i < CSU_COMB_MAX_SLAVE_CNT ; i++)
    {
        p_input_power_info->cab_ems[ i+1 ].online = p_csu_combine_info->slave_info[i].online;
        p_input_power_info->cab_ems[ i+1 ].power  = p_csu_combine_info->slave_info[i].ems_alloc_power / 100.0f;
        p_input_power_info->cab_meter[ i+1 ].online = p_csu_combine_info->slave_info[i].online;
        p_input_power_info->cab_meter[ i+1 ].power  = p_csu_combine_info->slave_info[i].real_data.meter_power / 100.0f;
    }

    /* PV */
    p_input_power_info->pv.power = p_csu_combine_info->global_info.PV_meter.power / 100.0;
    
    /* 电网 */
    p_input_power_info->grid.power = p_csu_combine_info->global_info.pcc_power / 100.0;

    return SF_OK;
}

/* 拓扑图展示 */
int32_t sys_state_topo_show_vertify( input_power_info_t *p_input_power_info, show_power_info_t *p_show_power_info )
{
    double max_err_power = ( METER_MAX_ERR_POWER >= METER_MIN_ERR_POWER )? METER_MAX_ERR_POWER : METER_MIN_ERR_POWER;
    static show_power_info_t valid_show_power = {.cab_meter[0].online = true};        // 上一次有效数据
    show_power_info_t tmp_show_power = {0};        
    int32_t ret_code = 0;

    max_err_power += CAB_AUX_MAX_POWER;

    for ( size_t i = 0; i < CSU_COMB_PARALLEL_CAB_MAX_CNT; i++ )
    {
        /* 离线的设备必须功率为0 */
        if (   p_input_power_info->cab_ems[i].online == SF_FALSE
            && p_input_power_info->cab_ems[i].power != 0 )
        {
            /* 离线功率不为0，错误 */
            ret_code = -1;
            goto __exit;
        }
    }

    /* 计算储能柜功率是否正确 */
    for ( size_t i = 0; i < CSU_COMB_PARALLEL_CAB_MAX_CNT; i++ )
    {
        if ( p_input_power_info->cab_ems[i].online == SF_TRUE )
        {
            /* 误差取大值 + 辅电影响 */
            double_t max_meter_power;
            double_t min_meter_power;

            
            if ( p_input_power_info->cab_ems[i].power > 0 )
            {
                /* 放电区间 */
                max_meter_power = p_input_power_info->cab_ems[i].power + max_err_power;
                min_meter_power = -max_err_power;
            }
            else
            {
                /* 充电区间 */
                max_meter_power = max_err_power;
                min_meter_power = p_input_power_info->cab_ems[i].power - max_err_power;;
            }
            
            if (   p_input_power_info->cab_meter[i].power > max_meter_power
                || p_input_power_info->cab_meter[i].power < min_meter_power )
            {
                /* 超出框定范围，错误 */
                ret_code = -2;
                goto __exit;
            }
        }
    }

    /* 计算汇流功率 */
    double_t sum_cab_power = 0;

    for ( size_t i = 0; i < CSU_COMB_PARALLEL_CAB_MAX_CNT; i++ )
    {
        if ( p_input_power_info->cab_ems[i].online == SF_TRUE )
        {
            sum_cab_power += p_input_power_info->cab_meter[i].power;
        }
    }

    double_t pv_power = p_input_power_info->pv.power;

    /* 取绝对值 */
    if ( pv_power < 0 )
        pv_power = -pv_power;

    /* 能量守恒计算 */
    double_t load_power = pv_power + sum_cab_power + p_input_power_info->grid.power;
    // printf( "load_power[%0.2f] = pv[%0.2f] + sum_cab_power[%0.2f] + grid[%0.2f]\r\n",  
    //     load_power, pv_power, sum_cab_power, p_input_power_info->grid.power);

    if (  (load_power < (-METER_MIN_ERR_POWER))
       && (load_power < (-METER_MAX_ERR_POWER)) )
    {
        /* 负载方向错误，且超过误差范围数值 */
        ret_code = -3;
        goto __exit;
    }

    /* 负载方向错误，未超过误差，纠正 */
    if ( load_power < 0 )
        load_power = 0;

    valid_show_power.load.online = 1;
    valid_show_power.load.power  = load_power;

    valid_show_power.pv.online   = p_input_power_info->pv.online;
    valid_show_power.pv.power    = p_input_power_info->pv.power;

    valid_show_power.grid = p_input_power_info->grid;
    valid_show_power.cab_sum_power = sum_cab_power;
    memcpy( valid_show_power.cab_meter, p_input_power_info->cab_meter, sizeof( valid_show_power.cab_meter ));

__exit:
    memcpy( p_show_power_info, &valid_show_power, sizeof( show_power_info_t ));
    if ( ret_code < 0 )
    {
        s_topo_err_pack_cnt++;
        printf("%s error ret_code:%d, err pack cnt:%d!!!\r\n", __func__, ret_code, s_topo_err_pack_cnt);
    }
    return ret_code;
}


void getParallelDeviceInfo2(struct mg_connection *p_nc,struct http_message *p_msg)
{
    uint8_t response[1024] = {0}; 
    char tmp_str[50];
    int32_t vertify_code;

    if ( SF_FALSE == json_utils_str_key_val_str_cmp( p_msg->body.p, "/action", "getParallelDeviceInfo" ))
    {
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
        return;
    }
    input_power_info_t input_power_info;
    show_power_info_t show_power_info;

    memset( &input_power_info, 0, sizeof( input_power_info ) );
    memset( &show_power_info , 0, sizeof( show_power_info  ) );
    input_power_info_package( &input_power_info );
    sys_state_topo_show_vertify( &input_power_info, &show_power_info );

    // input_power_info_printf( &input_power_info );
    // show_power_info_printf( &show_power_info );

    cJSON *p_root_js = cJSON_CreateObject();
    if ( p_root_js == NULL )
    {
        return;
    }

    common_data_t *p_common_data = sdk_shm_get();
    csu_combine_info_t *p_csu_combine = &sdk_shm_get()->csu_combine_data;

    cJSON_AddNumberToObject( p_root_js ,"vertifyCode"           , 200 );
    cJSON_AddNumberToObject( p_root_js ,"code"                  , 200 );
    cJSON_AddNumberToObject( p_root_js ,"MasterSlaveModeEnable" , p_common_data->csu_combine_data.comb_setting.comb_enable );
    cJSON_AddNumberToObject( p_root_js ,"DevIndex"              , ( p_csu_combine->comb_setting.comb_role == CSU_ROLE_MASTER )? 0 :
                                                                  ( p_csu_combine->comb_setting.comb_role == CSU_ROLE_SLAVE )? p_csu_combine->comb_setting.slave.local_slave_id : 
                                                                  ( p_csu_combine->comb_setting.comb_role == CSU_ROLE_JUNCT )? 80 : 255 );
    cJSON_AddNumberToObject( p_root_js ,"abVolt"                , p_csu_combine->junct_info.meter_dat.a_vol / 10.0 );
    cJSON_AddNumberToObject( p_root_js ,"bcVolt"                , p_csu_combine->junct_info.meter_dat.b_vol / 10.0 );
    cJSON_AddNumberToObject( p_root_js ,"caVolt"                , p_csu_combine->junct_info.meter_dat.c_vol / 10.0 );

    cJSON_AddNumberToObject( p_root_js ,"SOC"                   , p_csu_combine->global_info.SOC );
    cJSON_AddNumberToObject( p_root_js ,"photovoltaicMeterState", p_csu_combine->global_info.PV_meter.enable);
    cJSON_AddNumberToObject( p_root_js ,"solarOnLineNumber"     , (p_csu_combine->global_info.PV_meter.enable) ? p_csu_combine->global_info.PV_meter.num   : 0 );
    
    cJSON_AddNumberToObject( p_root_js ,"pccPower"              , double_acc_conversion( show_power_info.grid.power, 2) );
    cJSON_AddNumberToObject( p_root_js ,"loadPower"             , double_acc_conversion( show_power_info.load.power, 2) );
    cJSON_AddNumberToObject( p_root_js ,"solarPower"            , double_acc_conversion( show_power_info.pv.power, 2) );

    cJSON_AddNumberToObject( p_root_js ,"errPackCnt"            , s_topo_err_pack_cnt );

    cJSON *p_ParallelDeviceInfo_js = cJSON_AddArrayToObject( p_root_js, "ParallelDeviceInfo" );
    if ( p_ParallelDeviceInfo_js == NULL )
    {
        cJSON_Delete( p_root_js );
        return;
    }
    
    for (size_t i = 0; i < p_csu_combine->comb_setting.master.comb_num; i++)
    {
        /* 主 + 从 */
        csu_node_info_t *p_node_info = NULL;

        p_node_info = ( i == 0 )? &p_csu_combine->master_info : &p_csu_combine->slave_info[ i-1 ];

        cJSON *p_node_js = cJSON_CreateObject();
        if ( p_node_js == NULL )
        {
            cJSON_Delete( p_root_js );
            return;
        }

        sprintf( tmp_str ,"%d.%d.%d.%d", p_node_info->ip[0], p_node_info->ip[1], 
                                         p_node_info->ip[2], p_node_info->ip[3]);
        cJSON_AddStringToObject( p_node_js , "Ip"           , tmp_str );
        cJSON_AddNumberToObject( p_node_js , "Index"        , i );
        cJSON_AddNumberToObject( p_node_js , "onLineStatus" , show_power_info.cab_meter[i].online );
        cJSON_AddNumberToObject( p_node_js , "power"        , double_acc_conversion( show_power_info.cab_meter[i].power, 2) );
        cJSON_AddItemToArray( p_ParallelDeviceInfo_js, p_node_js );
    }

    cJSON_AddNumberToObject(p_root_js, "meterPower", double_acc_conversion( show_power_info.cab_sum_power, 2) );
    char *p_send_str = cJSON_PrintUnformatted( p_root_js );
    if ( p_send_str == NULL )
    {
        cJSON_Delete( p_root_js );
        return;
    }
    http_back( p_nc, p_send_str );

    cJSON_Delete( p_root_js );
    free( p_send_str );

    return;
}

void getParallelDeviceInfo(struct mg_connection *p_nc,struct http_message *p_msg)
{
    int32_t act_power = 0;
    uint8_t response[1024] = {0}; 
    char tmp_str[50];

    if ( SF_FALSE == json_utils_str_key_val_str_cmp( p_msg->body.p, "/action", "getParallelDeviceInfo" ))
    {
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
        return;
    }

    cJSON *p_root_js = cJSON_CreateObject();
    if ( p_root_js == NULL )
    {
        return;
    }

    common_data_t *p_common_data = sdk_shm_get();
    csu_combine_info_t *p_csu_combine = &sdk_shm_get()->csu_combine_data;

    cJSON_AddNumberToObject( p_root_js ,"code"                  , 200 );
    cJSON_AddNumberToObject( p_root_js ,"MasterSlaveModeEnable" , p_common_data->csu_combine_data.comb_setting.comb_enable );
    cJSON_AddNumberToObject( p_root_js ,"DevIndex"              , ( p_csu_combine->comb_setting.comb_role == CSU_ROLE_MASTER )? 0 :
                                                                  ( p_csu_combine->comb_setting.comb_role == CSU_ROLE_SLAVE )? p_csu_combine->comb_setting.slave.local_slave_id : 
                                                                  ( p_csu_combine->comb_setting.comb_role == CSU_ROLE_JUNCT )? 80 : 255 );
    cJSON_AddNumberToObject( p_root_js ,"abVolt"                , p_csu_combine->junct_info.meter_dat.a_vol / 10.0 );
    cJSON_AddNumberToObject( p_root_js ,"bcVolt"                , p_csu_combine->junct_info.meter_dat.b_vol / 10.0 );
    cJSON_AddNumberToObject( p_root_js ,"caVolt"                , p_csu_combine->junct_info.meter_dat.c_vol / 10.0 );
    // cJSON_AddNumberToObject( p_root_js ,"meterPower"            , p_csu_combine->junct_info.meter_dat.act_power / 100.0 );
    cJSON_AddNumberToObject( p_root_js ,"pccPower"              , p_csu_combine->global_info.pcc_power / 100.0 );
    cJSON_AddNumberToObject( p_root_js ,"SOC"                   , p_csu_combine->global_info.SOC );
    cJSON_AddNumberToObject( p_root_js ,"loadPower"             , p_csu_combine->global_info.loadPower / 100.0 );
    cJSON_AddNumberToObject( p_root_js ,"photovoltaicMeterState", p_csu_combine->global_info.PV_meter.enable);
    cJSON_AddNumberToObject( p_root_js ,"solarOnLineNumber"     , (p_csu_combine->global_info.PV_meter.enable) ? p_csu_combine->global_info.PV_meter.num   : 0 );
    cJSON_AddNumberToObject( p_root_js ,"solarPower"            , (p_csu_combine->global_info.PV_meter.enable) ? p_csu_combine->global_info.PV_meter.power / 100.0 : 0 );
    
    cJSON *p_ParallelDeviceInfo_js = cJSON_AddArrayToObject( p_root_js, "ParallelDeviceInfo" );
    if ( p_ParallelDeviceInfo_js == NULL )
    {
        cJSON_Delete( p_root_js );
        return;
    }

    sub_matrix_info_t *p_sub_matrix_info = get_sub_matrix_info();

    for (size_t i = 0; i < p_csu_combine->comb_setting.master.comb_num; i++)
    {
        /* 主 + 从 */
        csu_node_info_t *p_node_info = NULL;
        bool online_sta = false;

        if ( i == 0 )
        {
            /* 添加主机信息 */
            p_node_info = &p_csu_combine->master_info;
        }else{
            /* 添加从机信息 */   
            p_node_info = &p_csu_combine->slave_info[ i - 1 ];
        }

        if ( p_csu_combine->comb_setting.comb_role == CSU_ROLE_MASTER 
            && i == 0 )
        {
            /* 自身为主机 */
            online_sta = p_sub_matrix_info[0].online;
        }
        else if ( p_csu_combine->comb_setting.comb_role == CSU_ROLE_SLAVE
               && p_csu_combine->comb_setting.slave.local_slave_id == i )
        {
            /* 从机自身离线信息，以CMU在线为主 */   
            online_sta = p_sub_matrix_info[0].online;
        }
        else{
            online_sta = p_node_info->online;
        }

        cJSON *p_node_js = cJSON_CreateObject();
        if ( p_node_js == NULL )
        {
            cJSON_Delete( p_root_js );
            return;
        }

        sprintf( tmp_str ,"%d.%d.%d.%d", p_node_info->ip[0], p_node_info->ip[1], 
                                        p_node_info->ip[2], p_node_info->ip[3]);
        cJSON_AddStringToObject( p_node_js , "Ip"           , tmp_str );
        cJSON_AddNumberToObject( p_node_js , "Index"        , i );
        cJSON_AddNumberToObject( p_node_js , "onLineStatus" , online_sta );
        cJSON_AddNumberToObject( p_node_js , "power"        , p_node_info->real_data.meter_power / 100.0 );
        act_power += p_node_info->real_data.meter_power;
        cJSON_AddItemToArray( p_ParallelDeviceInfo_js, p_node_js );
    }
    cJSON_AddNumberToObject(p_root_js, "meterPower", act_power / 100.0);
    char *p_send_str = cJSON_PrintUnformatted( p_root_js );
    if ( p_send_str == NULL )
    {
        cJSON_Delete( p_root_js );
        return;
    }
    http_back( p_nc, p_send_str );

    cJSON_Delete( p_root_js );
    free( p_send_str );

    return;
}

/**
 * @brief    子阵信息涉及到CMU连接状态，需要单独特殊处理
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void cmu_sub_matrix_info_handle(struct mg_connection *p_nc,struct http_message *p_msg)
{
    uint8_t ret = 0;
    cJSON *p_request = NULL;
    cJSON *p_resp_array = NULL;
    cJSON *p_resp_item = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t response[1024] = {0}; 
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t i;
    uint8_t request_body[128] = {0};
    int32_t solar_power = 0;
    uint32_t total_energy = 0;
    int32_t load_power = 0;
    DEV_POWER_DATA_T current_dev_power = {0};

    sub_matrix_info_t *p_sub_matrix_info = get_sub_matrix_info();
    internal_shared_data_t *p_internal_data = sdk_shm_internal_shared_data_get();
    combiner_cabinet_data_t *p_combiner_cabinet_data =  sdk_shm_combiner_cabinet_data_get();
    box_transformer_info_t *p_box_transformer_data = sdk_shm_box_transformer_data_info_get();
    bat_charge_data_t *p_bat_charge_data = sdk_shm_bat_charge_data_info_get();
    constant_parameter_data_t *p_constant_para = sdk_shm_constant_parameter_data_get();
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();

    memcpy(request_body,p_msg->body.p,p_msg->body.len);	
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		SYS_STATE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getSubMatrixInfo"))
	{
		SYS_STATE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

    //计算各个功率数据
    current_dev_power.energy_meter_power = ((p_internal_data->total_realtime_energy.meter_power / 100) * 100) / 1000.0;
    current_dev_power.pcc_power = (-p_telemetry_data->sys_cabinet_telemetry_info.anti_reflux_power / 10.0);
    
    //光伏功率&光伏发电量
    if(p_constant_para->system_param.cabinet_param.rs485_device_enable.bit.photovoltaic_meter)
    {
        for(i = 0; i < p_constant_para->photovoltaic_meter_cfg.meter_cnt; i++)
        {
            solar_power += p_internal_data->photovoltaic_meter_data[i].active_power_total;
            total_energy += p_internal_data->photovoltaic_meter_data[i].positive_active_energy_total;
        }
    }

    current_dev_power.pv_power = ((solar_power / 100) * 100) / 1000.0;

    //负载功率，按照中心功率为0进行计算
    load_power = -((solar_power / 100.0) + (p_internal_data->total_realtime_energy.meter_power / 100.0) - (p_telemetry_data->sys_cabinet_telemetry_info.anti_reflux_power / 1.0));
    current_dev_power.load_power = -load_power / 10.0;


    p_resp_array = cJSON_CreateArray();
    if(p_resp_array == NULL)
    {
        SYS_STATE_DEBUG_PRINT("create json array failed");
        return;
    }

    for(i = 0; i < MAX_SLAVE_COUNT; i++)
    {
        p_resp_item = cJSON_CreateObject();
        if(p_resp_item == NULL)
        {
            SYS_STATE_DEBUG_PRINT("create json obj failed");
            cJSON_Delete(p_resp_array);
            return;
        }
        cJSON_AddNumberToObject(p_resp_item,"busSideVoltage",p_sub_matrix_info[i].bus_side_vol);
        // current_dev_power.total_power[i] = p_sub_matrix_info[i].total_power;
        // if(if_power_direction_same(current_dev_power.total_power[i], current_dev_power.energy_meter_power) == true)
        // {
        //     cJSON_AddNumberToObject(p_resp_item,"totalPower", p_sub_matrix_info[i].total_power);
        //     g_dev_power.total_power[i] = current_dev_power.total_power[i];
        // }
        // else
        // {
        //     cJSON_AddNumberToObject(p_resp_item,"totalPower", g_dev_power.total_power[i]);
        // }
        if(p_sub_matrix_info[i].online)
        {
            cJSON_AddNumberToObject(p_resp_item,"totalPower", current_dev_power.energy_meter_power);
        }
        cJSON_AddNumberToObject(p_resp_item,"onLine",p_sub_matrix_info[i].online);
        cJSON_AddNumberToObject(p_resp_item,"devNum",p_sub_matrix_info[i].dev_num);
        cJSON_AddItemToArray(p_resp_array,p_resp_item);
    }

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        SYS_STATE_DEBUG_PRINT("create json obj failed");
        cJSON_Delete(p_resp_array);
        return;
    }
    cJSON_AddNumberToObject(p_resp_root,"code",OK);
    cJSON_AddItemToObject(p_resp_root,"data",p_resp_array);
    cJSON_AddNumberToObject(p_resp_root,"abVolt",p_sub_matrix_info[0].grid_volt_rs);
    cJSON_AddNumberToObject(p_resp_root,"caVolt",p_sub_matrix_info[0].grid_volt_st);
    cJSON_AddNumberToObject(p_resp_root,"bcVolt",p_sub_matrix_info[0].grid_volt_tr);
    //系统SOC
    uint8_t bcu_cnt = 0;
    uint16_t soc = 0;
    for(i = 0; i < 6; i++)
    {
        if(p_bat_charge_data[0].soc_soh_data[i].soc != 0xFFFF)
        {
            soc += p_bat_charge_data[0].soc_soh_data[i].soc;
            bcu_cnt++;
        }
    }
    if(bcu_cnt != 0)
    {
        cJSON_AddNumberToObject(p_resp_root,"SOC", soc / bcu_cnt);
    }
    else
    {
        cJSON_AddNumberToObject(p_resp_root,"SOC", 0);
    }

    //方向一致
    if(if_power_direction_same(current_dev_power.total_power[0], current_dev_power.energy_meter_power) == true)
    {
        cJSON_AddNumberToObject(p_resp_root,"meterPower", current_dev_power.energy_meter_power);
        cJSON_AddNumberToObject(p_resp_root,"pccPower", current_dev_power.pcc_power);
        if(p_constant_para->system_param.cabinet_param.rs485_device_enable.bit.photovoltaic_meter)
        {
            cJSON_AddNumberToObject(p_resp_root,"solarPower", current_dev_power.pv_power);
        }
        else
        {
            cJSON_AddNumberToObject(p_resp_root,"solarPower", 0);
        } 
        if(load_power > 0)
        {
            cJSON_AddNumberToObject(p_resp_root,"loadPower", 0);
        }
        else
        {
            cJSON_AddNumberToObject(p_resp_root,"loadPower", current_dev_power.load_power);
        }
        memcpy(&g_dev_power, &current_dev_power, sizeof(DEV_POWER_DATA_T));
    }
    else
    {
        cJSON_AddNumberToObject(p_resp_root,"meterPower", g_dev_power.energy_meter_power);
        cJSON_AddNumberToObject(p_resp_root,"pccPower", g_dev_power.pcc_power);
        if(p_constant_para->system_param.cabinet_param.rs485_device_enable.bit.photovoltaic_meter)
        {
            cJSON_AddNumberToObject(p_resp_root,"solarPower", g_dev_power.pv_power);
        }
        else
        {
            cJSON_AddNumberToObject(p_resp_root,"solarPower", 0);
        } 
        if(load_power > 0)
        {
            cJSON_AddNumberToObject(p_resp_root,"loadPower", 0);
        }
        else
        {
            cJSON_AddNumberToObject(p_resp_root,"loadPower", g_dev_power.load_power);
        }
    }

    cJSON_AddStringToObject(p_resp_root,"msg","get submatrix successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);
    cJSON_Delete(p_resp_root);
    free(p);
    http_back(p_nc,response);
}


/**
 * @brief    获取CSU认证版本信息
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void csu_sys_version_info_get(struct mg_connection *p_nc,struct http_message *p_msg)
{
    uint8_t ret = 0;
    cJSON *p_request = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t response[1024] = {0}; 
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t i;
    uint8_t request_body[128] = {0};

    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();

    memcpy(request_body,p_msg->body.p,p_msg->body.len);	
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		SYS_STATE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getSystemVersionInfo"))
	{
		SYS_STATE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);


    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        SYS_STATE_DEBUG_PRINT("create json obj failed");
        return;
    }
    cJSON_AddNumberToObject(p_resp_root,"code",OK);
    cJSON_AddStringToObject(p_resp_root,"SoftwareVersion", "V000001");
    cJSON_AddStringToObject(p_resp_root,"HardwareVersion", "V000001");
    cJSON_AddStringToObject(p_resp_root,"devSN",(char *)p_telemetry_data->sys_version_telemetry_info.sn_version_number);

    cJSON_AddStringToObject(p_resp_root,"msg","success");

    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);
    cJSON_Delete(p_resp_root);
    free(p);
    http_back(p_nc,response);
}




/**
 * @brief 系统状态模块初始化
 * @return void
 */
void web_sys_state_module_init(void)
{
	if(!web_func_attach("/homePage/getSubMatrixInfo", TRANS_UNNEED, cmu_sub_matrix_info_handle))	 	//获取子阵信息
	{
		SYS_STATE_DEBUG_PRINT("[/homePage/getSubMatrixInfo] attach failed");
	}
	if(!web_func_attach("/homePage/getParallelDeviceInfo", TRANS_UNNEED, getParallelDeviceInfo2))	 	//获取子阵信息
	{
		SYS_STATE_DEBUG_PRINT("[/homePage/getParallelDeviceInfo] attach failed");
	}
	if(!web_func_attach("/CSUhomepage/getSystemInfo", TRANS_UNNEED, csu_sys_info_get))	 		        //获取CSU系统信息
	{
		SYS_STATE_DEBUG_PRINT("[/CSUhomepage/getSystemInfo] attach failed");
	}
	if(!web_func_attach("/CSUhomePage/getSystemVersionInfo", TRANS_UNNEED, csu_sys_version_info_get))	 //获取CSU系统认证版本信息
	{
		SYS_STATE_DEBUG_PRINT("[/CSUhomePage/getSystemVersionInfo] attach failed");
	}
}

