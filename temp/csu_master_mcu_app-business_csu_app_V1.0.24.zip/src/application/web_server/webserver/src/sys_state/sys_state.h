#ifndef __SYS_STATE_H__
#define __SYS_STATE_H__

#include"mongoose.h"
#include "component/sofar_log.h"

#if (1)
#define SYS_STATE_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else
#define SYS_STATE_DEBUG_PRINT(...) {do {} while(0);}
#endif

#define FAULT_BIT_0   (1<<0)
#define FAULT_BIT_1   (1<<1)
#define FAULT_BIT_2   (1<<2)
#define FAULT_BIT_3   (1<<3)
#define FAULT_BIT_4   (1<<4)
#define FAULT_BIT_5   (1<<5)
#define FAULT_BIT_6   (1<<6)
#define FAULT_BIT_7   (1<<7)

typedef enum{
    STOP = 0,
    WAIT,
    RUN,
    FAULT,
    UPGRADE,
    SLEEP,
    MAX
}sys_status_e;


/**
 * @brief   设置本地CMU状态位
 * @param	 [in] index CMU编号
 * @param	 [in] sys_status CMU状态
 * @note    
 * @return  
 */
void cmu_sys_status_set(uint8_t index, uint16_t sys_status);


/**
 * @brief    CSU系统状态
 * @return  sys_status_e
 */
sys_status_e sys_status_get(void);


/**
 * @brief    CMU系统状态
 * @return  sys_status_e
 */
sys_status_e cmu_sys_status_get(void);

/**
 * @brief   检测汇流柜是否有严重故障
 * @param   
 * @note    
 * @return  
 */
uint8_t combiner_cabinet_get_serious_fault(void);

/**
 * @brief    系统是否满足开机条件，根据箱变故障来判定，不需要关心CMU故障
 * @return  ture:满足；false:不满足
 */
bool if_poweron_allow(void);

/**
 * @brief 系统状态模块初始化
 * @return void
 */
void web_sys_state_module_init(void);


#endif