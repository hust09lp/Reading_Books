#ifndef __COMMON_H__
#define __COMMON_H__

#include"mongoose.h"

#define WEB_HOME_PATH "/user/www/htdocs"
#define WEB_CONF_PATH "/user/www/conf/"
#define ADMIN_JSON_FILE "/user/www/conf/administrator.json"
#define SYSTIME_JSON_FILE "/user/www/conf/systime.json"
#define SYSPARAM_JSON_FILE "/user/www/conf/sysparam.json"
#define NETWORK_CONF_FILE "/opt/conf/network"
#define NETWORK_CONF_FILE_TMP "/opt/conf/network_tmp"

#define ETH1NETWORK_CONF_FILE "/opt/conf/eth1_network"
#define ETH1NETWORK_CONF_FILE_TMP "/opt/conf/eth1_network_tmp"

#define WEB_OPERATION_LOG_PATH "/user/www/conf/operationlog"  //操作日志文件
#define PROTECT_PARAMS_JSON_FILE "/user/www/conf/protectparams.json"  //保护参数临时使用的配置文件，后面修改为接口获取，因为WEB不需要维护这些参数
#define RUNTIME_PARAMS_JSON_FILE "/user/www/conf/runtimeparams.json"
#define DEBUG_STATUS_JSON_FILE "/user/www/conf/debugstatus.json"
#define WEB_UPLOAD_DIR "/tmp/upload"
#define LOCAL_TIME_FILE "/etc/localtime"


/**
 * @brief          获取当前时间时间戳
 * @return         [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t get_sys_timestamp(void);

/**
 * @brief          RTC转换时间戳
 * @return         [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t date_time_to_timestamp(struct tm *p_date);


/**
 * @brief    MD5计算
 * @param	 [in] *text 数据
 * @param	 [in] len 长度 
 * @param	 [in] *out 字符输出
 * @return
 */
void md5_calcul(const uint8_t *text,const uint8_t len,uint8_t *out);


/**
 * @brief    HTTP空包回复，用于HTTP请求失败回复
 * @param	 [in] *response 数据
 * @param	 [in] code 状态码 
 * @param	 [in] *p_reason 原因 
 * @return
 */
int8_t build_empty_response(uint8_t *response,const uint16_t code,const uint8_t *p_reason);


/**
 * @brief    16进制转字符串
 * @param	 [in] *p_src 原始数据 
 * @param	 [in] len 数据长度
 * @param	 [out] *p_dst 目标数据 
 * @return
 */
void hex_to_str(const uint8_t *p_src, uint8_t *p_dst, const uint8_t len);


/**
 * @brief    HTTP数据发送
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_data 数据内容 
 * @return
 */
void http_back(struct mg_connection *p_nc, uint8_t *p_data);


/**
 * @brief    通过cookie获取用户名信息
 * @param	 [in] *p_msg  http请求信息
 * @param	 [out] *p_username 用户名 
 * @return
 */
void get_user_from_http_request(struct http_message *p_msg, uint8_t *p_username);
#endif
