#include "mongoose.h"
#include "cJSON.h"
#include "openssl/md5.h"
#include "component/sofar_log.h"
#include "sdk/sdk_public.h"
#include "sofar_errors.h"
#include "web_broker.h"

#define TIME_DIFF 8 * 60 * 60

/**
 * @brief          获取当前时间时间戳
 * @return         [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t get_sys_timestamp(void)
{
    sdk_rtc_t rtc_time = {0};
    struct tm local_time = {0};
    int32_t ret;
    time_t curr_timestamp = 0;

    ret = sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
    if (ret != SF_OK)
    {
        printf("rtc get failed");
    }

    local_time.tm_year = (int32_t)(rtc_time.tm_year + 100);
    local_time.tm_mon  = (int32_t)(rtc_time.tm_mon - 1);
    local_time.tm_mday = (int32_t)(rtc_time.tm_day);
    local_time.tm_hour = (int32_t)(rtc_time.tm_hour);
    local_time.tm_min  = (int32_t)(rtc_time.tm_min);
    local_time.tm_sec  = (int32_t)(rtc_time.tm_sec);
    curr_timestamp = mktime(&local_time) - TIME_DIFF;

    return curr_timestamp;
}


/**
 * @brief          RTC转换时间戳
 * @return         [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t date_time_to_timestamp(struct tm *p_date)
{
    time_t timestamp = 0;

    p_date->tm_year -= 1900;
    p_date->tm_mon  -= 1;
    timestamp = mktime(p_date) - TIME_DIFF;

    return timestamp;
}


/**
 * @brief    MD5计算
 * @param	 [in] *text 数据
 * @param	 [in] len 长度 
 * @param	 [in] *out 字符输出
 * @return
 */
void md5_calcul(const uint8_t *text,const uint8_t len,uint8_t *out)
{
	MD5_CTX md5_ctx;
	MD5_Init(&md5_ctx);
	MD5_Update(&md5_ctx,text,len);
	MD5_Final(out,&md5_ctx);
}


/**
 * @brief    HTTP空包回复，用于HTTP请求失败回复
 * @param	 [in] *response 数据
 * @param	 [in] code 状态码 
 * @param	 [in] *p_reason 原因 
 * @return
 */
int8_t build_empty_response(uint8_t *response,const uint16_t code,const uint8_t *p_reason)
{
	cJSON *p_root = NULL;
	uint8_t *p = NULL;

	p_root = cJSON_CreateObject();
	if(p_root == NULL)
	{
		return -1;
	}

	cJSON_AddNumberToObject(p_root,"code",code);
	cJSON_AddStringToObject(p_root,"msg",p_reason);
	p = cJSON_PrintUnformatted(p_root);
	strcpy(response, p);
	cJSON_Delete(p_root);
	free(p);
	return 0;
}


/**
 * @brief    16进制转字符串
 * @param	 [in] *p_src 原始数据 
 * @param	 [in] len 数据长度
 * @param	 [out] *p_dst 目标数据 
 * @return
 */
void hex_to_str(const uint8_t *p_src, uint8_t *p_dst, const uint8_t len)
{
	uint8_t ddh,ddl;
	uint8_t i;
	for(i = 0; i < len; i++)
	{
		ddh = 48 + p_src[i] / 16;
		ddl = 48 + p_src[i] % 16;
		if(ddh > 57)
		{
			ddh = ddh + 39;
		}
		if(ddl > 57)
		{
			ddl = ddl + 39;
		}
		p_dst[i * 2] = ddh;
		p_dst[i * 2 + 1] = ddl;
	}
}


/**
 * @brief    HTTP数据发送
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_data 数据内容 
 * @return
 */
void http_back(struct mg_connection *p_nc, uint8_t *p_data)
{
	mg_printf(p_nc, "%s", "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\nConnection: close\r\n\r\n");
	mg_printf_http_chunk(p_nc, "%s", p_data);
	mg_send_http_chunk(p_nc, "", 0);
}


/**
 * @brief    通过cookie获取用户名信息
 * @param	 [in] *p_msg  http请求信息
 * @param	 [out] *p_username 用户名 
 * @return
 */
void get_user_from_http_request(struct http_message *p_msg, uint8_t *p_username)
{
	struct mg_str *cookie_str = NULL;
	uint8_t username[32] = {0};
	char *p = username;
	cookie_str = mg_get_http_header(p_msg, "Cookie");
	if(cookie_str != NULL)
	{
		mg_http_parse_header2(cookie_str,"loginName_CMU",&p,sizeof(username));
		strcpy(p_username,username);
	}
}

/**
 * @brief    获取当前使用的语言类型
 * @param	 
 * @param	 
 * @return 返回当前的语言类型,0表示中文,1表示英文
 */
static uint8_t gs_current_language_instance;   //单例(静态化对象,对外开放操作接口)
uint8_t get_current_language()
{
	return gs_current_language_instance;
}

/**
 * @brief    设置当前使用的语言类型
 * @param	 [in] language  语言类型
 * @param	 [out] 无
 * @return 返回当前的语言类型,0表示中文,1表示英文
 */
void set_current_language(const uint8_t language)
{
	gs_current_language_instance = language;
}