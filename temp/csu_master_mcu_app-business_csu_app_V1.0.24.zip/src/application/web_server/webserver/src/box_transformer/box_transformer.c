#include "cJSON.h"
#include "common.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "web_broker.h"
#include "app_common.h"
#include "box_transformer.h"
#include "mongoose.h"


/**
 * @brief    float类型字符串转换，拿掉无效数字0
 * @param     [in] *p_str 字符串
 * @return   字符串
 */
uint8_t *float_str_covert(uint8_t *p_str)
{
    uint8_t len = strlen(p_str);
    for(uint8_t i = len - 1; i >= 0; i--)
    {
        if(p_str[i] == '\0')
        {
            continue;
        } 
        
        if(i == 0) 
        {
            return p_str;
        }
        //小数点退出
        if(p_str[i] == '.') 
        {
            p_str[i] = '\0';
            return p_str;
        }
        
        if(p_str[i] != '0') 
        {
            return p_str;
        }
 
        //把零消除掉
        if(p_str[i] == '0')
        {
            p_str[i] = '\0';
        }
        //如果小数点后一位也是零，那么将小数点也给消除掉
        if(p_str[i] == '0' && p_str[i - 1] != '0')
        {
            if(p_str[i - 1] == '.')
            {
                p_str[i - 1] = '\0';
                return p_str;
            }
            p_str[i] = '\0';
            return p_str;
        }
    }
    return p_str;
}



/**
 * @brief    添加模拟量参数
 * @param     [in] data 数据
 * @param     [in] *name_str 字段名称 
 * @param     [out] *p_item json数据包 
 * @param     [in] *digital 背书
 * @return
 */
static void simulate_data_add_by_name_str(float32_t data, uint8_t *p_name, cJSON *p_root_item, uint16_t digital)
{
    cJSON *item = NULL;
    uint8_t num_str[26]={0};
 
    item = cJSON_CreateArray();
    if(item == NULL)
    {
        BOX_TRANSFORMER_DEBUG_PRINT("create json array failed");
        return;
    }
	float32_t value = data / digital;
	switch(digital)
	{
		case 3:
		case 10:
		case 50:
			snprintf(num_str,sizeof(num_str),"%1.1f",value);
			break;
		
		case 100:
			snprintf(num_str,sizeof(num_str),"%1.2f",value);
			break;
		
		case 1000:
			snprintf(num_str,sizeof(num_str),"%1.3f",value);
			break;
		
		default:
			break;
	}

	uint8_t *p_str = float_str_covert(num_str);
	cJSON_AddItemToObject(p_root_item, p_name, cJSON_CreateRaw(p_str));
}


/**
 * @brief    获取箱变遥信信息
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void get_box_transformer_remote_sig(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_item = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t response[1024];
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t request_body[64] = {0};

	box_transformer_info_t *p_box_transformer_data = sdk_shm_box_transformer_data_info_get();
	transformer_remote_sig_t *p_remote_sig = &(p_box_transformer_data->remote_sig_status);
  
	memcpy(request_body,p_msg->body.p,p_msg->body.len);	
	p_request = cJSON_Parse(request_body);
    if (p_request == NULL)
	{
		BOX_TRANSFORMER_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"getRemoteSig"))
	{
		BOX_TRANSFORMER_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        BOX_TRANSFORMER_DEBUG_PRINT("create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",OK);

    p_resp_item = cJSON_CreateObject();
    if(p_resp_item == NULL)
    {
    	cJSON_Delete(p_resp_root);
		build_empty_response(response,Non_Authoriative_Information,"err");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
    }
	
    cJSON_AddNumberToObject(p_resp_item,"ultraHTempTrip",p_remote_sig->ultra_h_temp_trip);
	cJSON_AddNumberToObject(p_resp_item,"HVoltFusingSig",p_remote_sig->H_volt_fusing_sig); 
    cJSON_AddNumberToObject(p_resp_item,"HLVoltSmokeAlarm",p_remote_sig->H_L_volt_smoke_alarm);
	cJSON_AddNumberToObject(p_resp_item,"HLVoltTempAlarm",p_remote_sig->H_L_volt_temp_alarm); 
    cJSON_AddNumberToObject(p_resp_item,"transformerDoorOpenAlarm",p_remote_sig->transformer_door_open_alarm);
	cJSON_AddNumberToObject(p_resp_item,"HLVoltDoorOpenAlarm",p_remote_sig->H_L_volt_door_open_alarm); 
    cJSON_AddNumberToObject(p_resp_item,"HTempAlarm",p_remote_sig->H_temp_alarm);
	cJSON_AddNumberToObject(p_resp_item,"HVoltSideSwitchClose",p_remote_sig->H_volt_side_switch_close); 
    cJSON_AddNumberToObject(p_resp_item,"HVoltSideSwitchOpen",p_remote_sig->H_volt_side_switch_open);
	cJSON_AddNumberToObject(p_resp_item,"HVoltSideIsolateSwitchClose",p_remote_sig->H_volt_side_isolate_switch_close); 
    cJSON_AddNumberToObject(p_resp_item,"HVoltSideIsolateSwitchOpen",p_remote_sig->H_volt_side_isolate_switch_open);
	cJSON_AddNumberToObject(p_resp_item,"HVoltPowerDisappear",p_remote_sig->H_volt_power_disappear); 
    cJSON_AddNumberToObject(p_resp_item,"remoteLocation",p_remote_sig->remote_location);
	cJSON_AddNumberToObject(p_resp_item,"accidentSig",p_remote_sig->accident_total_sig); 
    cJSON_AddNumberToObject(p_resp_item,"alarmSig",p_remote_sig->alarm_total_sig);

	cJSON_AddItemToObject(p_resp_root,"data",p_resp_item);
	cJSON_AddStringToObject(p_resp_root,"msg","get successful");
		
	p = cJSON_PrintUnformatted(p_resp_root);
    BOX_TRANSFORMER_DEBUG_PRINT("ems param[out]:%s", p);
	cJSON_Delete(p_resp_root);	
	http_back(p_nc,p);
	free(p);

}


/**
 * @brief    获取箱变遥测数据
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void get_box_transformer_telemetry_data(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_item = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t response[1024];
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t request_body[64] = {0};

	box_transformer_info_t *p_box_transformer_data = sdk_shm_box_transformer_data_info_get();
	transformer_telemetry_data_t *p_telemetry_data = &(p_box_transformer_data->telemetry_data);
  
	memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
    if (p_request == NULL)
	{
		BOX_TRANSFORMER_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"getSimulateData"))
	{
		BOX_TRANSFORMER_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        BOX_TRANSFORMER_DEBUG_PRINT("create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",OK);

    p_resp_item = cJSON_CreateObject();
    if(p_resp_item == NULL)
    {
    	cJSON_Delete(p_resp_root);
		build_empty_response(response,Non_Authoriative_Information,"err");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
    }

	simulate_data_add_by_name_str(p_telemetry_data->phase_ab_volt, "phaseABvol", p_resp_item, 1);
	simulate_data_add_by_name_str(p_telemetry_data->phase_ca_volt, "phaseCAvol", p_resp_item, 1);
	simulate_data_add_by_name_str(p_telemetry_data->phase_bc_volt, "phaseBCvol", p_resp_item, 1);
	simulate_data_add_by_name_str(p_telemetry_data->sys_freq, "sys_freq", p_resp_item, 1);
	simulate_data_add_by_name_str(p_telemetry_data->tempA, "tempA", p_resp_item, 1);
	simulate_data_add_by_name_str(p_telemetry_data->tempB, "tempB", p_resp_item, 1);
	simulate_data_add_by_name_str(p_telemetry_data->tempC, "tempC", p_resp_item, 1);
	simulate_data_add_by_name_str(p_telemetry_data->transformer_temp_humi, "transformerTempHumi", p_resp_item, 10);
	simulate_data_add_by_name_str(p_telemetry_data->positive_active_energy, "positiveActiveEnergy", p_resp_item, 100);
	simulate_data_add_by_name_str(p_telemetry_data->positive_reactive_energy, "reverseActiveEnergy", p_resp_item, 100);

	cJSON_AddItemToObject(p_resp_root,"data",p_resp_item);
	cJSON_AddStringToObject(p_resp_root,"msg","get successful");
		
	p = cJSON_PrintUnformatted(p_resp_root);
    BOX_TRANSFORMER_DEBUG_PRINT("ems param[out]:%s", p);
	cJSON_Delete(p_resp_root);	
	http_back(p_nc,p);
	free(p);

}


/**
 * @brief    设置遥控
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void set_box_transformer_remote_switch(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t response[1024];
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t request_body[128] = {0};

	box_transformer_info_t *p_box_transformer_data = sdk_shm_box_transformer_data_info_get();
	transformer_remote_ctl_t *p_remote_ctl_switch = &(p_box_transformer_data->remote_ctl_switch);

	memcpy(request_body,p_msg->body.p,p_msg->body.len);	
    BOX_TRANSFORMER_DEBUG_PRINT("param[in]:%s", request_body);
	p_request = cJSON_Parse(request_body);
    if (p_request == NULL)
	{
		BOX_TRANSFORMER_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	if (NULL == cJSON_GetObjectItem(p_request,"action"))
	{
		BOX_TRANSFORMER_DEBUG_PRINT("parameter is not right.");
		build_empty_response(response,Non_Authoriative_Information,"parameter is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}	
	

	if (strcmp(p_action,"remoteHVoltSwitchOpen") == 0)
	{
		BIT_SET(p_remote_ctl_switch->remote_ctl_switch_flag, 0);
	}
	else if (strcmp(p_action,"remoteHVoltSwitchClose") == 0)
	{
		BIT_SET(p_remote_ctl_switch->remote_ctl_switch_flag, 1);
	}
	else
	{
		BOX_TRANSFORMER_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if (p_resp_root == NULL)
    {
        BOX_TRANSFORMER_DEBUG_PRINT("create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",OK);
    cJSON_AddStringToObject(p_resp_root,"msg","set successful");
	
    p = cJSON_PrintUnformatted(p_resp_root);
    http_back(p_nc,p);
	free(p);
	cJSON_Delete(p_resp_root);
}


/**
 * @brief 箱变管理模块初始化
 * @return void
 */
void web_box_transformer_module_init(void)
{
	if(!web_func_attach("/boxTransformer/getRemoteSig", TRANS_UNNEED, get_box_transformer_remote_sig))	 		//获取箱变遥信状态
	{
		BOX_TRANSFORMER_DEBUG_PRINT("[/boxTransformer/getRemoteSig] attach failed");
	}
	if(!web_func_attach("/boxTransformer/getTelemetryData", TRANS_UNNEED, get_box_transformer_telemetry_data))	//获取箱变模拟量
	{
		BOX_TRANSFORMER_DEBUG_PRINT("[/boxTransformer/getTelemetryData] attach failed");
	}
	if(!web_func_attach("/boxTransformer/setBreakerSwitch", TRANS_UNNEED, set_box_transformer_remote_switch))	//设置箱变遥控断路器开关
	{
		BOX_TRANSFORMER_DEBUG_PRINT("[/boxTransformer/setBreakerSwitch] attach failed");
	}
}

