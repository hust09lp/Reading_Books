#ifndef __BOX_TRANSFORMER_H__
#define __BOX_TRANSFORMER_H__
#include"mongoose.h"
#include "component/sofar_log.h"

#if (1)
#define BOX_TRANSFORMER_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else
#define BOX_TRANSFORMER_DEBUG_PRINT(...) {do {} while(0);}
#endif


/**
 * @brief 箱变管理模块初始化
 * @return void
 */
void web_box_transformer_module_init(void);


#endif