#ifndef __SYS_LOG_H__
#define __SYS_LOG_H__

#include"mongoose.h"
#include "component/sofar_log.h"

#if (1)
#define SYS_LOG_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else
#define SYS_LOG_DEBUG_PRINT(...) {do {} while(0);}
#endif


/**
 * @brief 系统日志模块初始化
 * @return void
 */
void web_sys_log_module_init(void);


#endif