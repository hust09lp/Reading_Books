#include "cJSON.h"
#include "common.h"
#include "sdk/sdk_fs.h"
#include "sdk/sdk_file.h"
#include "sdk/sdk_public.h"
#include "sqlite3.h"
#include "operation_log.h"
#include "sys_log.h"
#include "data_shm.h"
#include "sdk_shm.h"

#define MAX_BUFF (200 * 250)   //每一条最多占用200字节,最多可以有250条
#define PATH_HISTORY_EVENT_RECOND_FOLDER	"/user/data/event/"
#define OPERATION_DB_PATH                   "/user/data/event/Operation.db"
#define OPERATION_CSV_PATH                  "/tmp/CSUoperation.csv"
#define INVALID_OPERATION_ID     (255)

static int32_t sqlite_db_create_table(void);

typedef struct    
{
    uint8_t start_time[32];
    uint8_t end_time[32];
}operation_records_time_t;

struct operationlog_mapping {
    int operationlog_id;
    char *operationlog_text;
};

/*
/*
操作日志词条-中文
*/
const struct operationlog_mapping operationlog_mappings[] =  \
{
    {1,"设置DHCP"},
    {2,"修改静态网络参数"},
    {3,"修改通讯参数"},
    {4,"修改PCS柜有功功率值"},
    {5,"修改PCS柜无功功率值"},
    {6,"设置EMS参数"},
    {7,"设置EMS电价参数"},
    {8,"设置防逆流电表使能"},
    {9,"设置计量电表使能"},
    {10,"设置微机装置使能"},
    {11,"设置测控装置使能"},
    {12,"设置除湿器使能"},
    {13,"设置储能柜数量"},
    {14,"设置CSU应用场景"},
    {15,"设置小桔四元组"},
    {16,"设置变压器容量"},
    {17,"设置电表3数量"},
    {18,"设置用户ODM"},
    {19,"NTP同步时间"},
    {20,"批量删除用户"},
    {21,"删除用户"},
    {22,"添加用户"},
    {23,"重置密码"},
    {24,"批量重置密码"},
    {25,"修改用户信息"},
    {26,"用户登录"},
    {27,"设置时区"},
    {29,"设置控制模式"},
    {38,"同步系统时间"},
    {39,"设置光伏电表参数"},
    {40,"设置光伏电表使能"},
    {41,"本地升级"},
    {42,"远程升级"},
    {43,"sofar云平台服务使能"},
    {44,"zcs云平台服务使能"},
    {45,"设置DRMn功率比例参数"}
};

/**
 * @brief  根据操作日志获取对应的ID号
 * @param  [in] *operationlog_text 操作日志文本 
 * @return
 */
int32_t get_operationid_by_name(const char *operationlog_text)
{
    int operationid;
    uint32_t i;
    int num_mappings = sizeof(operationlog_mappings) / sizeof(operationlog_mappings[0]);

    for(i = 0; i < num_mappings; i++)
    {
        if(!strcmp(operationlog_text, operationlog_mappings[i].operationlog_text))  //匹配成功
        {
            return operationlog_mappings[i].operationlog_id;
        }
    }
    return INVALID_OPERATION_ID;
}


/**
 * @brief  根据操作日志ID获取对应的操作名称
 * @param  [in] id 操作日志ID 
 * @return
 */
char *get_operation_name_by_id(int id)
{
    uint32_t i;
    int num_mappings = sizeof(operationlog_mappings) / sizeof(operationlog_mappings[0]);

    for(i = 0; i < num_mappings; i++)
    {
        if(operationlog_mappings[i].operationlog_id == id)  //匹配成功
        {
            return operationlog_mappings[i].operationlog_text;
        }
    }
    return NULL;
}


/**
 * @brief   初始化操作日志结构体
 * @param   [in] 操作日志结构体指针
 * @param   [out] 操作日志结构体指针
 * @return  无
 */
void init_user_basic_info(operation_log_t *oplog)
{
	memset(oplog,0,sizeof(operation_log_t));
	strncpy(oplog->phone_num,"未知",strlen("未知"));
	oplog->dev_sn[0] = 0; //序列号
	strncpy(oplog->user_role,"未知",strlen("未知"));
	oplog->op_param1 = 0;
	oplog->op_param2 = 0;
	strncpy(oplog->op_status,"failed",strlen("failed"));
}


/**
 * @brief   根据已知信息获取账户中的其他信息
 * @return  无
 */
void get_user_basic_info(operation_log_t *p_oplog)
{
	FILE *fp;
	cJSON *p_root_array = NULL;
	cJSON *p_item = NULL;
	uint8_t *p_uname = NULL;
	uint8_t *p_buff = NULL;
	uint8_t i;

	fp = fopen(ADMIN_JSON_FILE,"r");
	if(fp == NULL)
	{
		SYS_LOG_DEBUG_PRINT("open admin json file failed.");
		return;
	}
	p_buff = (uint8_t *)malloc(MAX_BUFF);
	if(p_buff == NULL)
	{
		SYS_LOG_DEBUG_PRINT("malloc memory failed.");
		fclose(fp);
		return;
	}

	fread(p_buff,1,MAX_BUFF,fp);
	fclose(fp);
	p_root_array = cJSON_Parse(p_buff);

	if(p_root_array == NULL)
	{
		SYS_LOG_DEBUG_PRINT("parse admin json data failed.");
        free(p_buff);
		return;
	}
    free(p_buff);

	for(i=0;i<cJSON_GetArraySize(p_root_array);i++)
	{
		p_item = cJSON_GetArrayItem(p_root_array,i);
		p_uname = cJSON_GetObjectItem(p_item,"username")->valuestring;
		if(!strcmp(p_oplog->user_name,p_uname))  //找到了
		{
			if(cJSON_GetObjectItem(p_item,"phonenum") != NULL)  //有可能电话字段不存在
			{
				strcpy(p_oplog->phone_num,cJSON_GetObjectItem(p_item,"phonenum")->valuestring);
			}
			strcpy(p_oplog->user_role,cJSON_GetObjectItem(p_item,"role")->valuestring);
			break; //找到了就退出
		}
	}
    sprintf(p_oplog->time_stamp,"%d",time(NULL));
	cJSON_Delete(p_root_array);
}

/**
 * @brief  检查操作日志数据库文件是否存在和有效
 * @param  [in] none
 * @param  [out] none
 * @return 0-数据库文件正常   -1-数据库文件异常
 */
static int32_t op_log_db_file_check(void)
{
	int32_t ret = -1;
	fs_t *p_fs = NULL;
	
	
    ret = sdk_fs_access((const int8_t *)OPERATION_DB_PATH, F_OK);
    if (ret == -1)  // 文件不存在，创建该文件
    {
		log_i("\n Operation.db is not exist\n");
		sqlite_db_create_table();
		return (0);
    }
	else     // 文件存在，检查文件大小是否为0
	{
		log_i("\n Operation.db is exist\n");
		p_fs = sdk_fs_open((const int8_t *)OPERATION_DB_PATH,FS_READ);
		if ( p_fs != NULL)
		{
			ret = sdk_fs_get_size(p_fs);
			sdk_fs_close(p_fs);
			log_i("\n Operation.db open success,file size:%d\n",ret);
			if (ret == 0)
			{
				log_i("\nre creat  Operation.db\n");
				sdk_fs_remove((const int8_t *)OPERATION_DB_PATH);
				sqlite_db_create_table();
			}
		}
		else 
		{
			return (-1);
		}
	}
	return (0);
}

/**
 * @brief   添加一条操作日志,该函数为公共函数,不同模块记录操作日志时调用该函数即可
 * @return  无
 */
void add_one_op_log(operation_log_t *p_oplog)
{
	sqlite3 *db = NULL;
    int32_t ret;
	sdk_rtc_t rtc_time;
    uint8_t date_time[32] = {0};
		
    op_log_db_file_check();
	ret = sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
	if (ret != 0)
    {
		SYS_LOG_DEBUG_PRINT((int8_t *)"\n [%s:%d] sdk_rtc_get fail \n", __func__, __LINE__);
		return;
    }
	snprintf(date_time, 32, "%04d-%02d-%02d %02d:%02d:%02d", 2000 + rtc_time.tm_year,rtc_time.tm_mon, rtc_time.tm_day, rtc_time.tm_hour, rtc_time.tm_min, rtc_time.tm_sec);

    ret = sqlite3_open(OPERATION_DB_PATH, &db);
    if(ret) 
    {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return;
    }
    else
    {
        char *sql = "INSERT INTO Operation (USERNAME, PHONENUM, USERROLE, OPTYPE, DEVSN, PARAM1, PARAM2, OPSTATUS, TIME) VALUES \
            (?, ?, ?, ?, ?, ?, ?, ?, ?);";
        sqlite3_stmt *stmt;
        sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
        sqlite3_bind_text(stmt, 1, p_oplog->user_name, -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt, 2, p_oplog->phone_num, -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt, 3, p_oplog->user_role, -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt, 4, p_oplog->op_type, -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt, 5, p_oplog->dev_sn, -1, SQLITE_STATIC);
        sqlite3_bind_double(stmt, 6, p_oplog->op_param1);
        sqlite3_bind_double(stmt, 7, p_oplog->op_param2);    
        sqlite3_bind_text(stmt, 8, p_oplog->op_status, -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt, 9, date_time, -1, SQLITE_STATIC);    

        ret = sqlite3_step(stmt);
    	if (ret != SQLITE_DONE) 
        {
            SYS_LOG_DEBUG_PRINT((int8_t *)"sqlite3_step error");
        } 
        sqlite3_finalize(stmt);
    }
	sqlite3_close(db);
}

static time_t string_to_timestamp(const char* str)
{
    struct tm tm_time = {0};
    if(NULL == str)
    {
        return 0;
    }
    // 将字符串形式的时间转换为tm结构体
    sscanf(str, "%d-%d-%d %d:%d:%d", &tm_time.tm_year, &tm_time.tm_mon, &tm_time.tm_mday, 
           &tm_time.tm_hour, &tm_time.tm_min, &tm_time.tm_sec);

    time_t unix_time = date_time_to_timestamp(&tm_time);
    return unix_time;
}

/**
 * @brief   从数据库读取所有操作日志内容
 * @param   [in] p_nc 表示http连接指针
 * @param   [in] p_msg 表示http连接的请求体内容
 * @return  无
 */
static int32_t sqlite_db_select(oplog_filter_t filter_para, void *p_data, uint32_t *p_data_num, uint32_t *p_total_num)
{
	sqlite3_stmt *stmt = NULL;
    char *err_msg = 0;
	int32_t rc = 0;
    sqlite3 *db = NULL;
	int total_num = 0;
	uint8_t sql[256] = {0};
    uint8_t sql_len = 0;
    uint8_t filter_flag = 0;
    uint32_t year = 0;
    uint32_t month = 0;
    uint32_t day = 0;
	
	operation_log_t *p_item = NULL;
	p_item = (operation_log_t *)p_data;

	rc = sdk_fs_access(OPERATION_DB_PATH, F_OK);
    if (rc == -1)  // 文件夹不存在，创建该文件夹
    {
		return(-1);
	}

    rc = sqlite3_open(OPERATION_DB_PATH , &db);
    if( rc ) 
    {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return(-1);
    }	
	
	// 查询
    // 根据过滤条件拼接字符串
    snprintf(sql, 256, "SELECT ID, USERNAME, PHONENUM, USERROLE, OPTYPE, DEVSN, PARAM1, PARAM2, OPSTATUS, TIME FROM Operation ");
    sql_len = strlen(sql);
    if(strcmp(filter_para.user_name,"all"))  //如果是all，表示不过滤
    {
        snprintf(sql + sql_len, 256 - sql_len, "WHERE USERNAME LIKE '%s' ", filter_para.user_name);
        sql_len = strlen(sql);
        filter_flag = 1;
    }
    if(strcmp(filter_para.op_type,"all"))  //如果是all，表示不过滤
    {
        if(filter_flag)
        {
            snprintf(sql + sql_len, 256 - sql_len, "AND OPTYPE LIKE '%s' ", filter_para.op_type);
            sql_len = strlen(sql);
        }
        else
        {
            snprintf(sql + sql_len, 256 - sql_len, "WHERE OPTYPE LIKE '%s' ", filter_para.op_type);
            sql_len = strlen(sql);
            filter_flag = 1;
        }
    }
    if(strcmp(filter_para.user_role,"all"))  //如果是all，表示不过滤
    {
        if(filter_flag)
        {
            snprintf(sql + sql_len, 256 - sql_len, "AND USERROLE LIKE '%s' ", filter_para.user_role);
            sql_len = strlen(sql);
        }
        else
        {
            snprintf(sql + sql_len, 256 - sql_len, "WHERE USERROLE LIKE '%s' ", filter_para.user_role);
            sql_len = strlen(sql);
            filter_flag = 1;
        }
    }
    if(strcmp(filter_para.op_status,"all"))  //如果是all，表示不过滤
    {
        if(filter_flag)
        {
            snprintf(sql + sql_len, 256 - sql_len, "AND OPSTATUS LIKE '%s' ", filter_para.op_status);
            sql_len = strlen(sql);
        }
        else
        {
            snprintf(sql + sql_len, 256 - sql_len, "WHERE OPSTATUS LIKE '%s' ", filter_para.op_status);
            sql_len = strlen(sql);
            filter_flag = 1;
        }
    }
    if(strcmp(filter_para.time_stamp,"all"))  //如果是all，表示不过滤
    {
        sscanf(filter_para.time_stamp,"%d-%d-%d", &year, &month, &day);
        if(filter_flag)
        {
            snprintf(sql + sql_len, 256 - sql_len, "AND date(TIME) = date( '%04d-%02d-%02d' ) ", year , month, day);
            sql_len = strlen(sql);
        }
        else
        {
            snprintf(sql + sql_len, 256 - sql_len, "WHERE date(TIME) = date( '%04d-%02d-%02d' ) ", year , month, day);
            sql_len = strlen(sql);
            filter_flag = 1;
        }
    }

	snprintf(sql + sql_len, 256 - sql_len, "ORDER BY TIME DESC");

	rc = sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
	if (rc != SQLITE_OK) 
    {
    	fprintf(stderr, "Failed to fetch data: %s\n", sqlite3_errmsg(db));
    	sqlite3_close(db);
    	return -1;
	}

	while (sqlite3_step(stmt) == SQLITE_ROW)
	{
        strcpy(p_item[total_num].user_name, sqlite3_column_text(stmt, 1));
        strcpy(p_item[total_num].phone_num, sqlite3_column_text(stmt, 2));
        strcpy(p_item[total_num].user_role, sqlite3_column_text(stmt, 3));
        strcpy(p_item[total_num].op_type, sqlite3_column_text(stmt, 4));
        strcpy(p_item[total_num].dev_sn, sqlite3_column_text(stmt, 5));
        p_item[total_num].op_param1 = sqlite3_column_double(stmt, 6);
		p_item[total_num].op_param2 = sqlite3_column_double(stmt,7);
        strcpy(p_item[total_num].op_status, sqlite3_column_text(stmt, 8));
        strcpy(p_item[total_num].time_stamp, sqlite3_column_text(stmt, 9));
		total_num ++;
	}
	*p_total_num = total_num;
	
	sqlite3_finalize(stmt);
	sqlite3_close(db);
	
	return 1;
}


/**
 * @brief   获取操作日志
 * @param   [in] p_nc 表示http连接指针
 * @param   [in] p_msg 表示http连接的请求体内容
 * @return  无
 */
void get_operation_log(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_root = NULL;
    cJSON *p_resp_array = NULL;
    cJSON *p_resp_item = NULL;
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t request_body[256];
    uint8_t response[64]; 
    uint16_t page_index;  //要第几页数据
    uint8_t items_perpage;  //每页有多少条数据
    oplog_filter_t op_filter;  //数据过滤结构体
    uint8_t *p_filter_item = NULL;
    operation_log_t *p_item = NULL;
    uint32_t data_num = 0;
	uint32_t total_num = 0;
    uint16_t total_pages = 0;
	uint16_t acl_total  = 0; //过滤之后有多少条
    uint32_t i;
    int32_t index;
    double param[2];
    uint8_t time_stamp[16] = {0};
    int32_t ret = 0;
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();

    memset(request_body,0,sizeof(request_body));
    memcpy(request_body,p_msg->body.p,p_msg->body.len);	
    //解析请求体
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		SYS_LOG_DEBUG_PRINT((int8_t *)"parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

    //根据前端协议,此处请求的action必须为getOperationLog
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getOperationLog"))
	{
		SYS_LOG_DEBUG_PRINT((int8_t *)"action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
        cJSON_Delete(p_request);
		http_back(p_nc,response);
		return;
	}

    //需要那一页数据
    page_index = cJSON_GetObjectItem(p_request,"pageIndex")->valueint;

    //每一页多少数据
    items_perpage = cJSON_GetObjectItem(p_request,"itemsPerPage")->valueint;
    
    memset(&op_filter,0,sizeof(oplog_filter_t));
    //前端根据用户名过滤
    p_filter_item = cJSON_GetObjectItem(p_request,"aclUserName")->valuestring;
    strncpy(op_filter.user_name,p_filter_item,strlen(p_filter_item));

    //前端根据操作类型过滤,操作类型目前需要搜集,或者支持前端输入,不再以下拉框的形式
    int id = atoi(cJSON_GetObjectItem(p_request,"aclAction")->valuestring);
    p_filter_item = get_operation_name_by_id(id);
    if(p_filter_item == NULL)
    {
        strcpy(op_filter.op_type,"all");
    }
    else
    {
        strncpy(op_filter.op_type,p_filter_item,strlen(p_filter_item));
    }
    
    //前端根据角色过滤
    p_filter_item = cJSON_GetObjectItem(p_request,"aclRole")->valuestring;
    strncpy(op_filter.user_role,p_filter_item,strlen(p_filter_item));

    //前端根据操作结果过滤,成功或者失败
    p_filter_item = cJSON_GetObjectItem(p_request,"aclStatus")->valuestring;
    strncpy(op_filter.op_status,p_filter_item,strlen(p_filter_item));

    //前端根据日期,需要哪一天的数据
    p_filter_item = cJSON_GetObjectItem(p_request,"aclYmd")->valuestring;
    strncpy(op_filter.time_stamp,p_filter_item,strlen(p_filter_item));

    //释放前端请求json指针
    cJSON_Delete(p_request);

    // 数据
	p_item = (operation_log_t *)malloc(MAX_OPERATION_ITEMS * sizeof(operation_log_t));
	if(p_item == NULL)
	{
		SYS_LOG_DEBUG_PRINT((int8_t *)"malloc failed");
		return;
	}

	ret = sqlite_db_select(op_filter, (void *)p_item, &data_num, &total_num);
	if (ret < 0)
	{
		SYS_LOG_DEBUG_PRINT((int8_t *)"operation log get failed, ret = %d", ret);
		free(p_item);
		return;
	}

	acl_total = (uint16_t)total_num;
	if ((total_num % items_perpage) == 0)
	{
		total_pages = (uint16_t)(total_num / items_perpage);
	}
	else
	{
		total_pages = (uint16_t)((total_num / items_perpage) + 1);
	}

    if(total_num == 0)
    {
		data_num = 0;
    }
	else if ((page_index < total_pages) || !(total_num % items_perpage))
	{
		data_num = items_perpage;
	}
    else
    {
		data_num = total_num % items_perpage;
	}

	p_resp_array = cJSON_CreateArray();
	if(p_resp_array == NULL)
	{
		SYS_LOG_DEBUG_PRINT("create json array failed");
        free(p_item);
		return;
	}

    for(i = 0; i < data_num; i++)
    {
        p_resp_item = cJSON_CreateObject();
        if(p_resp_item == NULL)
        {
            SYS_LOG_DEBUG_PRINT("create json obj failed");
            cJSON_Delete(p_resp_array); 
            free(p_item);
            return;
        }
        index =((page_index - 1) * items_perpage) + i;
        cJSON_AddStringToObject(p_resp_item,"userName",p_item[index].user_name);
         /*约定0表示运维人员,1表示终端用户*/
        if(!strcmp(p_item[index].user_role, "operator"))
        {
            cJSON_AddNumberToObject(p_resp_item,"userRole", 0);
        }
        else
        {
            cJSON_AddNumberToObject(p_resp_item,"userRole", 1);
        }
       // cJSON_AddStringToObject(p_resp_item,"userRole",p_item[index].user_role);
         /*对操作类型进行转换*/
        cJSON_AddNumberToObject(p_resp_item,"opType", get_operationid_by_name(p_item[index].op_type));
        if(!strcmp(p_item[index].phone_num, "未知"))
        {
            cJSON_AddStringToObject(p_resp_item, "phoneNum", "-");
        }
        else
        {
            cJSON_AddStringToObject(p_resp_item, "phoneNum", p_item[index].phone_num);
        }
        // cJSON_AddStringToObject(p_resp_item,"devSN",p_item[index].dev_sn);
        cJSON_AddStringToObject(p_resp_item,"devSN",(char *)p_telemetry_data->sys_version_telemetry_info.sn_version_number);
        param[0] = p_item[index].op_param1;
        param[1] = p_item[index].op_param2;
        cJSON_AddItemToObject(p_resp_item,"opParam",cJSON_CreateDoubleArray(param,2));
        cJSON_AddStringToObject(p_resp_item,"status",p_item[index].op_status);
        cJSON_AddStringToObject(p_resp_item,"timestamp",p_item[index].time_stamp);
        cJSON_AddItemToArray(p_resp_array,p_resp_item);
    }

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		SYS_LOG_DEBUG_PRINT("create json obj failed");
		cJSON_Delete(p_resp_array);
        free(p_item);
        return;
	}

    cJSON_AddNumberToObject(p_resp_root,"code",OK);
    cJSON_AddNumberToObject(p_resp_root,"totalPage",total_pages);
    cJSON_AddNumberToObject(p_resp_root,"totalItems",acl_total);
    cJSON_AddItemToObject(p_resp_root,"data",p_resp_array);
    cJSON_AddStringToObject(p_resp_root,"msg","get operation log successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_resp_root);
    //将生成的请求包发送到前端
    http_back(p_nc,p);

    //释放
	free(p);
	free(p_item);
}


/**
 * @brief  创建操作日志数据库文件
 * @param  
 * @param  
 * @return
 */
static int32_t sqlite_db_create_table(void) 
{
    char *err_msg = NULL;
	int rc = 0;
    sqlite3 *db = NULL;

	char *sql_Faults = "CREATE TABLE IF NOT EXISTS Operation("  \
            "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
            "USERNAME       TEXT   NOT NULL," \
            "PHONENUM       TEXT   NOT NULL," \
            "USERROLE       TEXT   NOT NULL," \
            "OPTYPE         TEXT   NOT NULL," \
            "DEVSN          TEXT   NOT NULL," \
            "PARAM1         INT    NOT NULL," \
            "PARAM2         INT    NOT NULL," \
            "OPSTATUS       TEXT   NOT NULL," \
            "TIME           TEXT   NOT NULL);";

	char *sql_trigger = "CREATE TRIGGER limit_rows AFTER INSERT ON Operation "
						"BEGIN "
							"DELETE FROM Operation WHERE ID IN ("
								"SELECT ID FROM Operation "
								"ORDER BY ID ASC "
								"LIMIT (SELECT CASE WHEN (SELECT COUNT(*) FROM Operation) > 5000 THEN 1 ELSE 0 END)"
							"); "
						"END;";
	
    rc = sqlite3_open(OPERATION_DB_PATH, &db);
    if( rc ) 
    {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return(0);
    }

    rc = sqlite3_exec(db, sql_Faults, 0, 0, &err_msg);
    if (rc != SQLITE_OK) 
    {
        fprintf(stderr, "Failed to create table: %s\n", err_msg);
        sqlite3_free(err_msg);
    }

	rc = sqlite3_exec(db, sql_trigger, 0, 0, &err_msg);
	if (rc != SQLITE_OK) 
    {
		fprintf(stderr, "SQL error: %s\n", err_msg);
		sqlite3_free(err_msg);
	} else {
		fprintf(stdout, "Trigger created successfully\n");
	}
	
	sqlite3_close(db);
	return(1);
}


/**
 * @brief  操作日志配置初始化
 * @param  
 * @param  
 * @return
 */
void operation_log_conf_init(void)
{
	int32_t ret = 0;
	
    // 文件夹不存在，若不存在则创建该文件夹
	ret = sdk_fs_access((const int8_t *)PATH_HISTORY_EVENT_RECOND_FOLDER, F_OK);
    if (ret == -1)          
    {
        SYS_LOG_DEBUG_PRINT("\n [%s:%d] /user/data/event/ Folder does not exist!!! \n", __func__, __LINE__);
        ret = sdk_fs_mkdir((const char *)PATH_HISTORY_EVENT_RECOND_FOLDER, 755);
        if (ret < 0)
        {
            SYS_LOG_DEBUG_PRINT((int8_t *)"\n [%s:%d] sdk_fs_mkdir fail, ret = %d \n", __func__, __LINE__, ret);
        }
    }	
    //判断文件是否存在,如果文件不存在就进行创建
	ret = sdk_fs_access((const int8_t *)OPERATION_DB_PATH, F_OK);
    if (ret == -1)
    {
		sqlite_db_create_table();
    }    
}


/**
 * @brief  	首页页面获取要显示的最新的5条操作日志数据
 * @param  	[out] p_data        操作日志的数据指针
 * @param  	[out] p_data_num    实际获取到操作日志的条数
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t home_page_operation_log_latest_5_item_get(void *p_data, uint32_t *p_data_num)
{
	sqlite3_stmt *stmt = NULL;
    char *err_msg = NULL;
	int32_t rc = 0;
    sqlite3 *db = NULL;
	int total_num = 0;
	uint8_t sql[256] = {0};
	
	operation_log_t *p_item = NULL;
	p_item = (operation_log_t *)p_data;

	rc = sdk_fs_access(OPERATION_DB_PATH, F_OK);
    if (rc == -1)  // 文件夹不存在，创建该文件夹
    {
		return(-1);
	}	
    rc = sqlite3_open(OPERATION_DB_PATH, &db);
    if(rc) 
    {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return(-1);
    }	
	
    snprintf(sql, 256, "SELECT ID, USERNAME, PHONENUM, USERROLE, OPTYPE, DEVSN, PARAM1, PARAM2, OPSTATUS, TIME FROM Operation ORDER BY TIME DESC LIMIT 5;");
	rc = sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
	if (rc != SQLITE_OK) 
    {
    	fprintf(stderr, "Failed to fetch data: %s\n", sqlite3_errmsg(db));
    	sqlite3_close(db);
    	return -1;
	}

	while (sqlite3_step(stmt) == SQLITE_ROW)
	{
        strcpy(p_item[total_num].user_name, sqlite3_column_text(stmt, 1));
        strcpy(p_item[total_num].phone_num, sqlite3_column_text(stmt, 2));
        strcpy(p_item[total_num].user_role, sqlite3_column_text(stmt, 3));
        strcpy(p_item[total_num].op_type, sqlite3_column_text(stmt, 4));
        strcpy(p_item[total_num].dev_sn, sqlite3_column_text(stmt, 5));
        p_item[total_num].op_param1 = sqlite3_column_double(stmt, 6);
		p_item[total_num].op_param2 = sqlite3_column_double(stmt,7);
        strcpy(p_item[total_num].op_status, sqlite3_column_text(stmt, 8));
        strcpy(p_item[total_num].time_stamp, sqlite3_column_text(stmt, 9));
		total_num ++;
	}
	*p_data_num = total_num;
	
	sqlite3_finalize(stmt);
	sqlite3_close(db);
	
	return 1;
}


/**
 * @brief  	读取操作日志文件至导出
 * @param  	[in] p_operation_time：过滤时间参数
 * @param  	[out] p_data：日志
 * @param  	[out] p_total_num：数量
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
static int32_t read_operation_log2export(operation_records_time_t *p_operation_time, void *p_data, uint32_t *p_total_num)
{
	sqlite3_stmt *stmt = NULL;
    char *err_msg = NULL;
	int32_t rc = 0;
    sqlite3 *db = NULL;
	uint8_t sql[512] = {0};
    int total_num = 0;
    operation_log_t *p_item = NULL;
    int32_t ret = 0;

    rc = sqlite3_open(OPERATION_DB_PATH, &db);
    if( rc ) 
    {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return 0;
    }	

    snprintf(sql,256,"SELECT USERNAME, PHONENUM, USERROLE, OPTYPE, DEVSN, PARAM1, PARAM2, OPSTATUS, TIME "
            "FROM Operation "
            "WHERE date(TIME) BETWEEN date('%s') AND date('%s') "
            "ORDER BY TIME DESC;", p_operation_time->start_time, p_operation_time->end_time);

	rc = sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
	if (rc != SQLITE_OK) 
    {
		fprintf(stderr, "Failed to fetch data: %s\n", sqlite3_errmsg(db));
		sqlite3_close(db);
		return 0;
	}
    p_item = (operation_log_t *)p_data;
	// 遍历结果集
	while (sqlite3_step(stmt) == SQLITE_ROW) 
    {
        strcpy(p_item[total_num].user_name, sqlite3_column_text(stmt, 0));
        strcpy(p_item[total_num].phone_num, sqlite3_column_text(stmt, 1));
        strcpy(p_item[total_num].user_role, sqlite3_column_text(stmt, 2));
        strcpy(p_item[total_num].op_type, sqlite3_column_text(stmt, 3));
        strcpy(p_item[total_num].dev_sn, sqlite3_column_text(stmt, 4));
        p_item[total_num].op_param1 = sqlite3_column_double(stmt, 5);
		p_item[total_num].op_param2 = sqlite3_column_double(stmt,6);
        strcpy(p_item[total_num].op_status, sqlite3_column_text(stmt, 7));
        strcpy(p_item[total_num].time_stamp, sqlite3_column_text(stmt, 8));
		total_num ++;
	}
    *p_total_num = total_num;

	sqlite3_finalize(stmt);
	sqlite3_close(db);

	return(1);
}



 /**
   * @brief  获取 记录
   * @param  [in] *p_nc 连接信息 
   * @param  [in] *p_msg  http请求信息
   * @return
   */
void export_operation_List(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
    cJSON *p_resp_array = NULL;
    cJSON *p_resp_item = NULL;
	uint8_t *p_action = NULL;
	uint8_t *p = NULL;
    double param[2] = {0};
    uint8_t response[256] = {0};
	uint8_t request_body[128] = {0};
	int32_t year = 0, mon = 0, day = 0;
    int32_t ret = 0;
	operation_records_time_t operation_time = {0};
    operation_log_t *p_item = NULL;
	uint32_t total_num = 0;
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();

	memcpy(request_body,p_msg->body.p,p_msg->body.len);	
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		SYS_LOG_DEBUG_PRINT((int8_t *)"parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	if(NULL == cJSON_GetObjectItem(p_request,"action"))
	{
		 SYS_LOG_DEBUG_PRINT((int8_t *)"action is NULL");
		 build_empty_response(response,Non_Authoriative_Information,"action is NULL");
		 http_back(p_nc,response);
		 cJSON_Delete(p_request);
		 return;
	}
	 
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getOperationList"))
	{
		 SYS_LOG_DEBUG_PRINT((int8_t *)"action is not right.");
		 build_empty_response(response,Non_Authoriative_Information,"action is not right");
		 http_back(p_nc,response);
		 cJSON_Delete(p_request);
		 return;
	}
	
	if ((NULL == cJSON_GetObjectItem(p_request,"timestart")) || (NULL == cJSON_GetObjectItem(p_request,"timeend")))
	{
		SYS_LOG_DEBUG_PRINT((int8_t *)"start/end time not right.");
		 build_empty_response(response,Non_Authoriative_Information,"start/end time not right");
		 http_back(p_nc,response);
		 cJSON_Delete(p_request);
		 return;
	}

	sscanf(cJSON_GetObjectItem(p_request,"timestart")->valuestring,"%d-%d-%d",&year,&mon,&day);
	snprintf(operation_time.start_time, 32, "%04d-%02d-%02d",year,mon,day);
	
	sscanf(cJSON_GetObjectItem(p_request,"timeend")->valuestring,"%d-%d-%d",&year,&mon,&day);
	snprintf(operation_time.end_time, 32, "%04d-%02d-%02d",year,mon,day);
	SYS_LOG_DEBUG_PRINT((int8_t *)"start %s end %s \n",operation_time.start_time, operation_time.end_time);
	cJSON_Delete(p_request);

    // 数据
	p_item = (operation_log_t *)malloc(MAX_OPERATION_ITEMS * sizeof(operation_log_t));
	if(p_item == NULL)
	{
		SYS_LOG_DEBUG_PRINT((int8_t *)"malloc failed");
		return;
	}

	ret = read_operation_log2export(&operation_time, p_item, &total_num);
	if (ret)
	{
        p_resp_array = cJSON_CreateArray();
        if(p_resp_array == NULL)
        {
            SYS_LOG_DEBUG_PRINT("create json array failed");
            free(p_item);
            return;
        }
        for(uint32_t i = 0; i < total_num; i++)
        {
            p_resp_item = cJSON_CreateObject();
            if(p_resp_item == NULL)
            {
                SYS_LOG_DEBUG_PRINT("create json obj failed");
                cJSON_Delete(p_resp_array); 
                free(p_item);
                return;
            }
            cJSON_AddStringToObject(p_resp_item,"Name",p_item[i].user_name);
            if(!strcmp(p_item[i].user_role, "operator"))
            {
                cJSON_AddNumberToObject(p_resp_item,"Role", 0);
            }
            else
            {
                cJSON_AddNumberToObject(p_resp_item,"Role", 1);
            }
            cJSON_AddNumberToObject(p_resp_item,"ID", get_operationid_by_name(p_item[i].op_type));
            param[0] = p_item[i].op_param1;
            param[1] = p_item[i].op_param2;
            cJSON_AddItemToObject(p_resp_item,"Param",cJSON_CreateDoubleArray(param,2));
            if(!strcmp(p_item[i].op_status, "success"))
            {
                cJSON_AddNumberToObject(p_resp_item,"status", 1);
            }
            else
            {
                cJSON_AddNumberToObject(p_resp_item,"status", 0);
            }
            cJSON_AddStringToObject(p_resp_item,"tm",p_item[i].time_stamp);
            cJSON_AddItemToArray(p_resp_array,p_resp_item);
        }
	}

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		SYS_LOG_DEBUG_PRINT("create json obj failed");
		cJSON_Delete(p_resp_array);
        free(p_item);
        return;
	}

    cJSON_AddNumberToObject(p_resp_root,"code",OK);
    cJSON_AddStringToObject(p_resp_root,"devSN",(char *)p_telemetry_data->sys_version_telemetry_info.sn_version_number);
    cJSON_AddItemToObject(p_resp_root,"data",p_resp_array);
    cJSON_AddStringToObject(p_resp_root,"msg","get operation log successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_resp_root);
    //将生成的请求包发送到前端
    http_back(p_nc,p);

    //释放
	free(p);
	free(p_item);

 }