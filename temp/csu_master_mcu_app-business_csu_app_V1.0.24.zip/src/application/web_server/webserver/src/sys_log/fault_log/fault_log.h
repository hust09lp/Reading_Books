#ifndef __FAULT_LOG_H__
#define __FAULT_LOG_H__

#include <time.h>
#include "mongoose.h"
#define FUALT_LOG_LATEST_5_ITEM (5)
#define HISTORY_EVENT_PATH_NAME_MAX			60

#define FAULT_NAME_TEXT_LEN                 (128)       // 故障名称最大长度
#define EVENT_RECORD_DEEP_MAX				(5000)	    // 每个文件的事件记录的最大深度（条数）

// 历史事件分类
typedef enum
{
    ALL_EVENT   = 0,        // 不进行事件分类，所有的事件
    FAULT_EVENT = 1,        // 仅故障事件
    WARN_EVENT  = 2,        // 仅告警事件
    TBD_EVENT   = 3,        // 仅未定义/不明确的事件
}history_event_classify_e;

// web筛选条件
typedef enum
{
    FILTER_ALL      = 0,    // 所有的故障事件，不进行筛选
    FILTER_ID       = 1,    // 仅筛选指定的故障ID事件
    FILTER_DATE     = 2,    // 仅筛选指定的日期故障事件
    FILTER_ID_DATE  = 3,    // 仅筛选指定故障ID并且指定日期的故障事件
}event_filter_criteria_e;

typedef enum{
  FAULT_TEXT_LANGUAGE_CHINESE,     //中文显示
  FAULT_TEXT_LANGUAGE_ENGLISH,    //英文显示
  FAULT_TEXT_LANGUAGE_END,
}fault_text_language_e;

// 筛选条件参数
typedef struct
{
    history_event_classify_e  filter_classify;  // 筛选分类：history_event_classify_e
                                                // ALL_EVENT   = 0（不进行事件分类，所有的事件）
                                                // FAULT_EVENT = 1（仅故障事件）
                                                // WARN_EVENT  = 2（仅告警事件）
                                                // TBD_EVENT   = 3（仅未定义/不明确的事件）
    event_filter_criteria_e  filter_criteria;   // web端筛选条件：event_filter_criteria_e
                                                // FILTER_ALL       = 0（所有的故障事件，不进行筛选）
                                                // FILTER_ID        = 1（仅筛选指定的故障ID事件）
                                                // FILTER_DATE      = 2（仅筛选指定的日期故障事件）
                                                // FILTER_ID_DATE   = 3（仅筛选指定故障ID并且指定日期的故障事件）
    uint16_t event_id;                          // 筛选指定的故障ID，当filter_criteria的值为FILTER_ID或FILTER_ID_DATE时，此故障ID值才有效，否则此故障ID值无效
    uint8_t  year;                              // 筛选指定的故障日期（年），当filter_criteria的值为FILTER_DATE或FILTER_ID_DATE时，此值才有效，否则此值无效
    uint8_t  mon;                               // 筛选指定的故障日期（月），当filter_criteria的值为FILTER_DATE或FILTER_ID_DATE时，此值才有效，否则此值无效
    uint8_t  day;                               // 筛选指定的故障日期（日），当filter_criteria的值为FILTER_DATE或FILTER_ID_DATE时，此值才有效，否则此值无效
    uint8_t  items_perpage;                     // 一页显示多少条
    uint16_t page_index;                        // 显示第几页的索引
}event_filter_para_t;


typedef struct 
{
    uint16_t event_id;
    uint8_t start_time[32];
    uint8_t end_time[32];
}history_event_new_t;

typedef struct
{
    uint8_t year;
    uint8_t mon;
    uint8_t day;
    uint8_t hour;
    uint8_t min;
    uint8_t sec;    
}event_time_t;


/**
 * @brief  	首页页面获取要显示的最新的5条故障日志数据
 * @param  	[out] p_data        故障日志的数据指针
 * @param  	[out] p_data_num    实际获取到故障日志的条数
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t home_page_fault_log_latest_5_item_get(void *p_data, uint32_t *p_data_num);

/**
 * @brief   获取故障日志
 * @param   [in] p_nc 表示http连接指针
 * @param   [in] p_msg 表示http连接的请求体内容
 * @return  无
 */
void get_fault_log(struct mg_connection *p_nc,struct http_message *p_msg);

 /**
   * @brief  获取 记录
   * @param  [in] *p_nc 连接信息 
   * @param  [in] *p_msg  http请求信息
   * @return
   */
void export_fault_List(struct mg_connection *p_nc,struct http_message *p_msg);

#endif