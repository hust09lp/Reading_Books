#include "data_shm.h"
#include "sdk_shm.h"
#include "cJSON.h"
#include "common.h"
#include "sofar_errors.h"
#include "sqlite3.h"
#include "sdk/sdk_fs.h"
#include "sdk/sdk_file.h"
#include "sys_log.h"
#include "fault_log.h"

#define FAULT_DB_PATH "/user/data/event/Faults.db"

typedef struct	{
	uint8_t start_time[32];
	uint8_t end_time[32];
}fault_records_time_t;


static time_t string_to_timestamp(const char* str)
{
    struct tm tm_time = {0};
    if(NULL == str)
    {
        return 0;
    }
    // 将字符串形式的时间转换为tm结构体
    sscanf(str, "%d-%d-%d %d:%d:%d", &tm_time.tm_year, &tm_time.tm_mon, &tm_time.tm_mday, 
           &tm_time.tm_hour, &tm_time.tm_min, &tm_time.tm_sec);

    time_t unix_time = date_time_to_timestamp(&tm_time);
    return unix_time;
}

static int32_t sqlite_db_select(event_filter_para_t filter_para, void *p_data, uint32_t *p_data_num, uint32_t *p_total_num)
{
	sqlite3_stmt *stmt;
    char *err_msg = 0;
	int32_t rc = 0;
    sqlite3 *db;
	int total_num = 0;
	uint8_t sql[256] = {0};
	
	history_event_new_t *p_item = NULL;
	p_item = (history_event_new_t *)p_data;

	rc = sdk_fs_access(FAULT_DB_PATH, SF_OK);
    if (rc == -1)  // 文件夹不存在，创建该文件夹
    {
		return(-1);
	}

    rc = sqlite3_open(FAULT_DB_PATH , &db);
    if( rc ) {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return(-1);
    }	
	
	// 查询
	if (filter_para.filter_criteria == FILTER_ID_DATE)
	{
		//snprintf(sql,256,"SELECT FAULTID, strftime('%%s', STARTTIME), strftime('%%s', ENDTIME) FROM Faults WHERE date(STARTTIME) = date( '%04d-%02d-%02d' ) AND FAULTID = %d ORDER BY STARTTIME DESC;",2000 + filter_para.year , filter_para.mon, filter_para.day, filter_para.event_id);
		snprintf(sql,256,"SELECT FAULTID, STARTTIME, ENDTIME FROM Faults WHERE date(STARTTIME) = date( '%04d-%02d-%02d' ) AND FAULTID = %d ORDER BY STARTTIME DESC;",2000 + filter_para.year , filter_para.mon, filter_para.day, filter_para.event_id);
	}
	else if(filter_para.filter_criteria == FILTER_DATE)
	{
		//snprintf(sql,256,"SELECT FAULTID, strftime('%%s', STARTTIME), strftime('%%s', ENDTIME) FROM Faults WHERE date(STARTTIME) = date( '%04d-%02d-%02d' ) ORDER BY STARTTIME DESC;", 2000 + filter_para.year , filter_para.mon, filter_para.day);
		snprintf(sql,256,"SELECT FAULTID, STARTTIME, ENDTIME FROM Faults WHERE date(STARTTIME) = date( '%04d-%02d-%02d' ) ORDER BY STARTTIME DESC;", 2000 + filter_para.year , filter_para.mon, filter_para.day);
	}	
	else if(filter_para.filter_criteria == FILTER_ID)
	{
		//snprintf(sql,256,"SELECT FAULTID, strftime('%%s', STARTTIME), strftime('%%s', ENDTIME) FROM Faults WHERE FAULTID = %d ORDER BY STARTTIME DESC;",filter_para.event_id);
		snprintf(sql,256,"SELECT FAULTID, STARTTIME, ENDTIME FROM Faults WHERE FAULTID = %d ORDER BY STARTTIME DESC;",filter_para.event_id);
	}
	else
	{
		//snprintf(sql,256,"SELECT FAULTID, strftime('%%s', STARTTIME), strftime('%%s', ENDTIME) FROM Faults ORDER BY STARTTIME DESC;");
		snprintf(sql,256,"SELECT FAULTID, STARTTIME, ENDTIME FROM Faults ORDER BY STARTTIME DESC;");
	}
	
	
	rc = sqlite3_prepare_v2(db, sql, -1, &stmt, 0);

	if (rc != SQLITE_OK) {
    	fprintf(stderr, "Failed to fetch data: %s\n", sqlite3_errmsg(db));
    	sqlite3_close(db);
    	return -1;
	}

	while (sqlite3_step(stmt) == SQLITE_ROW)
	{
		p_item[total_num].event_id = sqlite3_column_int(stmt, 0);
        strcpy(p_item[total_num].start_time, sqlite3_column_text(stmt, 1));
        strcpy(p_item[total_num].end_time, sqlite3_column_text(stmt, 2));
		total_num ++;
	}
	*p_total_num = total_num;
	
	sqlite3_finalize(stmt);
	sqlite3_close(db);

	return 1;
}


/**
 * @brief   获取故障日志
 * @param   [in] p_nc 表示http连接指针
 * @param   [in] p_msg 表示http连接的请求体内容
 * @return  无
 */
void get_fault_log(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	cJSON *p_resp_array = NULL;
	cJSON *p_resp_item = NULL;
    uint8_t response[256];  //
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t request_body[128] = {0};
    uint16_t page_index;
    uint8_t items_perpage;
    int16_t acl_fault_id;
    uint8_t *p_acl_ymd = NULL;
	uint16_t total_pages = 0;
	uint16_t acl_total  = 0; //过滤之后有多少条
	uint32_t i;
	bool filter_id_flag = false;
	bool filter_date_flag = false;
	event_filter_para_t para = {0};
	uint32_t year;
    uint32_t month;
    uint32_t day;
	uint32_t data_num = 0;
	uint32_t total_num = 0;
	history_event_new_t *p_item = NULL;
	time_t timestamp = 0;
	int8_t str_timestamp[20];
	int32_t ret;
	int32_t index;
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();

	memcpy(request_body,p_msg->body.p,p_msg->body.len);	
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		SYS_LOG_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getFaultLog"))
	{
		SYS_LOG_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
        cJSON_Delete(p_request);
		http_back(p_nc,response);
		return;
	}

    page_index = cJSON_GetObjectItem(p_request,"pageIndex")->valueint;
    items_perpage = cJSON_GetObjectItem(p_request,"itemsPerPage")->valueint;
	acl_fault_id = atoi(cJSON_GetObjectItem(p_request,"aclFaultID")->valuestring);
    p_acl_ymd = cJSON_GetObjectItem(p_request,"aclYmd")->valuestring;
	if (items_perpage == 0)
	{
		SYS_LOG_DEBUG_PRINT("items_perpage error.");
		cJSON_Delete(p_request);
		return;
	}

	p_resp_array = cJSON_CreateArray();
	if(p_resp_array == NULL)
	{
		SYS_LOG_DEBUG_PRINT("create json array failed");
		cJSON_Delete(p_request);
		return;
	}

    // 数据
	p_item = (history_event_new_t *)malloc(EVENT_RECORD_DEEP_MAX * sizeof(history_event_new_t));
	if(p_item == NULL)
	{
		SYS_LOG_DEBUG_PRINT("malloc failed");
		cJSON_Delete(p_request);
		return;
	}
	para.page_index = page_index;
	para.items_perpage = items_perpage;
	if (acl_fault_id < 0)
	{
		para.event_id = 0;
	}
	else
	{
		para.event_id = acl_fault_id;
		filter_id_flag = true;
	}
	ret = strcmp(p_acl_ymd, "all");
	if (ret != 0)  //如果不是all，表示按指定的日期筛选
	{
		sscanf(p_acl_ymd,"%d-%d-%d",&year,&month,&day);
		para.year = (uint8_t)(year - 2000);
		para.mon  = (uint8_t)month;
		para.day  = (uint8_t)day;
		filter_date_flag = true;
	}
	if (filter_id_flag && filter_date_flag)
	{
		para.filter_criteria = FILTER_ID_DATE;
	}
	else if (filter_date_flag)
	{
		para.filter_criteria = FILTER_DATE;
	}
	else if (filter_id_flag)
	{
		para.filter_criteria = FILTER_ID;
	}
	else
	{
		para.filter_criteria = FILTER_ALL;
	}
	para.filter_classify = FAULT_EVENT;
	ret = sqlite_db_select(para, (void *)p_item, &data_num, &total_num);
	if(ret < 0)
	{
		SYS_LOG_DEBUG_PRINT("fault log get failed, ret = %d", ret);
		cJSON_Delete(p_request);
		free(p_item);
		return;
	}

	acl_total = (uint16_t)total_num;
	if ((total_num % items_perpage) == 0)
	{
		total_pages = (uint16_t)(total_num / items_perpage);
	}
	else
	{
		total_pages = (uint16_t)((total_num / items_perpage) + 1);
	}

    if(total_num == 0)
    {
        data_num = 0;
    }
	else if ((page_index < total_pages) || !(total_num % items_perpage))
	{
		data_num = items_perpage;
	}
    else
    {
		data_num = total_num % items_perpage;
	}

	for(i = 0; i < data_num; i++)
	{
     
		p_resp_item = cJSON_CreateObject();
		if(p_resp_item == NULL)
		{
			SYS_LOG_DEBUG_PRINT("create json obj failed");
			cJSON_Delete(p_request);
			cJSON_Delete(p_resp_array);
		}
		index =((page_index - 1) * items_perpage) + i;
		// 故障ID
		cJSON_AddNumberToObject(p_resp_item,"faultID", p_item[index].event_id);
        // SN
        cJSON_AddStringToObject(p_resp_item,"devSN",(char *)p_telemetry_data->sys_version_telemetry_info.sn_version_number);
		// 故障开始时间
		cJSON_AddStringToObject(p_resp_item,"startTimeStamp", p_item[index].start_time);
		// 故障结束时间
        if(strcmp(p_item[index].end_time, "1970-00-00 00:00:00"))
        {
            cJSON_AddStringToObject(p_resp_item,"endTimeStamp",  p_item[index].end_time);
        }
		cJSON_AddItemToArray(p_resp_array,p_resp_item);
	}

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		SYS_LOG_DEBUG_PRINT("create json obj failed");
		cJSON_Delete(p_request);
		cJSON_Delete(p_resp_array);
	}

	cJSON_AddNumberToObject(p_resp_root,"code",OK);
	cJSON_AddNumberToObject(p_resp_root,"totalItems",acl_total);
	cJSON_AddNumberToObject(p_resp_root,"totalPage",total_pages);
	cJSON_AddItemToObject(p_resp_root,"data",p_resp_array);

	p = cJSON_PrintUnformatted(p_resp_root);

    cJSON_Delete(p_request);
	cJSON_Delete(p_resp_root);

    http_back(p_nc,p);

	free(p);
	free(p_item);
}


/**
 * @brief  	读取故障日志文件至导出
 * @param  	[in] p_fault_time：过滤时间参数
 * @param  	[out] p_data：日志
 * @param  	[out] p_total_num：数量
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
static int32_t read_faults2export(fault_records_time_t *p_fault_time, void *p_data, uint32_t *p_total_num)
{
    sqlite3_stmt *stmt = NULL;
    char *err_msg = NULL;
    int32_t rc = 0;
    sqlite3 *db = NULL;
    history_event_new_t *p_item = NULL;
    uint8_t sql[512] = {0};
    int8_t fault_name_text[FAULT_NAME_TEXT_LEN] = {0};
    uint32_t total_num = 0;
    int32_t ret = 0;
 
    rc = sqlite3_open("/user/data/event/Faults.db", &db);
    if( rc ) 
    {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return 0;
    }    
 
    snprintf(sql,256,"SELECT FAULTID, STARTTIME, ENDTIME "
            "FROM Faults "
            "WHERE date(STARTTIME) BETWEEN date('%s') AND date('%s') "
            "ORDER BY STARTTIME DESC;", p_fault_time->start_time, p_fault_time->end_time);
 
    rc = sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
    if (rc != SQLITE_OK) 
    {
        fprintf(stderr, "Failed to fetch data: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return 0;
    }
    p_item = (history_event_new_t *)p_data;
    // 遍历结果集
    while (sqlite3_step(stmt) == SQLITE_ROW) 
    {
		p_item[total_num].event_id = sqlite3_column_int(stmt, 0);
        strcpy(p_item[total_num].start_time, sqlite3_column_text(stmt, 1));
        strcpy(p_item[total_num].end_time, sqlite3_column_text(stmt, 2));
		total_num++;
	}
	*p_total_num = total_num;
 
    sqlite3_finalize(stmt);
    sqlite3_close(db);
 
    return(1);
}



 /**
   * @brief  获取 记录
   * @param  [in] *p_nc 连接信息 
   * @param  [in] *p_msg  http请求信息
   * @return
   */
void export_fault_List(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_root = NULL;
    cJSON *p_resp_item = NULL;
    cJSON *p_resp_array = NULL;
    uint8_t response[256] = {0};
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    history_event_new_t *p_item = NULL;
    uint8_t request_body[128] = {0};
    uint32_t total_num = 0;
    int32_t year = 0, mon = 0, day = 0;
    int32_t ret = 0;
    fault_records_time_t fault_time ={0};
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();
 
    memcpy(request_body,p_msg->body.p,p_msg->body.len);    
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        SYS_LOG_DEBUG_PRINT((int8_t *)"parse request failed.");
        build_empty_response(response,Accepted,"parse request failed.");
        http_back(p_nc,response);
        return;
    }
 
    if(NULL == cJSON_GetObjectItem(p_request,"action"))
    {
        SYS_LOG_DEBUG_PRINT((int8_t *)"action is NULL");
        build_empty_response(response,Non_Authoriative_Information,"action is NULL");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
     
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action,"getFaultLogList"))
    {
        SYS_LOG_DEBUG_PRINT((int8_t *)"action is not right.");
        build_empty_response(response,Non_Authoriative_Information,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
    
    if ((NULL == cJSON_GetObjectItem(p_request,"timestart")) || (NULL == cJSON_GetObjectItem(p_request,"timeend")))
    {
        SYS_LOG_DEBUG_PRINT((int8_t *)"start/end time not right.");
        build_empty_response(response,Non_Authoriative_Information,"start/end time not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
 
    sscanf(cJSON_GetObjectItem(p_request,"timestart")->valuestring,"%d-%d-%d",&year,&mon,&day);
    snprintf(fault_time.start_time, 32, "%04d-%02d-%02d",year,mon,day);
    
    sscanf(cJSON_GetObjectItem(p_request,"timeend")->valuestring,"%d-%d-%d",&year,&mon,&day);
    snprintf(fault_time.end_time, 32, "%04d-%02d-%02d",year,mon,day);
    SYS_LOG_DEBUG_PRINT((int8_t *)"start %s end %s \n",fault_time.start_time, fault_time.end_time);
    cJSON_Delete(p_request);

    // 数据
	p_item = (history_event_new_t *)malloc(EVENT_RECORD_DEEP_MAX * sizeof(history_event_new_t));
	if(p_item == NULL)
	{
		SYS_LOG_DEBUG_PRINT("malloc failed");
		cJSON_Delete(p_request);
		return;
	}
 
    ret = read_faults2export(&fault_time, p_item, &total_num);
    if (ret)
    {
        p_resp_array = cJSON_CreateArray();
        if(p_resp_array == NULL)
        {
            SYS_LOG_DEBUG_PRINT("create json obj failed");
            free(p_item);
            return;
        }

        for(uint32_t i = 0; i < total_num; i++)
        {
        
            p_resp_item = cJSON_CreateObject();
            if(p_resp_item == NULL)
            {
                SYS_LOG_DEBUG_PRINT("create json obj failed");
                cJSON_Delete(p_resp_array);
                free(p_item);
                return;
            }
            cJSON_AddNumberToObject(p_resp_item,"ID", p_item[i].event_id);
            cJSON_AddStringToObject(p_resp_item,"st", p_item[i].start_time);
            if(strcmp(p_item[i].end_time, "1970-00-00 00:00:00"))
            {
                cJSON_AddStringToObject(p_resp_item,"et",  p_item[i].end_time);
            }
            cJSON_AddItemToArray(p_resp_array,p_resp_item);
        }

        p_resp_root = cJSON_CreateObject();
        if(p_resp_root == NULL)
        {
            SYS_LOG_DEBUG_PRINT("create json obj failed");
            cJSON_Delete(p_resp_array);
            free(p_item);
            return;
        }

        cJSON_AddNumberToObject(p_resp_root,"code",OK);
        cJSON_AddStringToObject(p_resp_root,"devSN",(char *)p_telemetry_data->sys_version_telemetry_info.sn_version_number);
        cJSON_AddItemToObject(p_resp_root,"data",p_resp_array);
        cJSON_AddStringToObject(p_resp_root,"msg",(char *)"get Fault Log List success/failed");

        p = cJSON_PrintUnformatted(p_resp_root);
        http_back(p_nc,p);

        cJSON_Delete(p_resp_root);
        free(p);
        free(p_item);
    }

}


/**
 * @brief  	首页页面获取要显示的最新的5条故障日志数据
 * @param  	[out] p_data        故障日志的数据指针
 * @param  	[out] p_data_num    实际获取到故障日志的条数
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t home_page_fault_log_latest_5_item_get(void *p_data, uint32_t *p_data_num)
{
	sqlite3_stmt *stmt;
    char *err_msg = 0;
	int32_t rc = 0;
    sqlite3 *db;
	int total_num = 0;
	uint8_t sql[256] = {0};
	
	history_event_new_t *p_item = NULL;
	p_item = (history_event_new_t *)p_data;

	rc = sdk_fs_access(FAULT_DB_PATH, SF_OK);
    if (rc == -1)  // 文件夹不存在，创建该文件夹
    {
		return(-1);
	}	
    rc = sqlite3_open(FAULT_DB_PATH, &db);
    if( rc ) {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return(-1);
    }	
	
	//snprintf(sql,256,"SELECT FAULTID, strftime('%%s', STARTTIME), strftime('%%s', ENDTIME) FROM Faults ORDER BY STARTTIME DESC LIMIT 5;");
	snprintf(sql,256,"SELECT FAULTID, STARTTIME, ENDTIME FROM Faults ORDER BY STARTTIME DESC LIMIT 5;");

	rc = sqlite3_prepare_v2(db, sql, -1, &stmt, 0);

	if (rc != SQLITE_OK) 
    {
    	fprintf(stderr, "Failed to fetch data: %s\n", sqlite3_errmsg(db));
    	sqlite3_close(db);
    	return -1;
	}

	while (sqlite3_step(stmt) == SQLITE_ROW)
	{
		p_item[total_num].event_id = sqlite3_column_int(stmt, 0);
        strcpy(p_item[total_num].start_time, sqlite3_column_text(stmt, 1));
        strcpy(p_item[total_num].end_time, sqlite3_column_text(stmt, 1));
		total_num ++;
	}
	*p_data_num = total_num;
	
	sqlite3_finalize(stmt);
	sqlite3_close(db);
	
	return 1;
}
