#include "cJSON.h"
#include "common.h"
#include "app_common.h"
#include "libghttp.h"
#include "web_broker.h"
#include "sys_log.h"
#include "operation_log.h"
#include "fault_log.h"


/**
 * @brief 系统日志模块初始化
 * @return void
 */
void web_sys_log_module_init(void)
{
    operation_log_conf_init();
	if(!web_func_attach("/CSUhomePage/getOperationLog", TRANS_UNNEED, get_operation_log))	 	    //获取操作日志
	{
		SYS_LOG_DEBUG_PRINT("[/CSUhomePage/getOperationLog] attach failed");
	}
	if(!web_func_attach("/CSUhomePage/getOperationList", TRANS_UNNEED, export_operation_List))	    //导出操作日志
	{
		SYS_LOG_DEBUG_PRINT("[/CSUhomePage/getOperationList] attach failed");
	}
	if(!web_func_attach("/CSUhomePage/getFaultLog", TRANS_UNNEED, get_fault_log))	 		        //获取故障日志
	{
		SYS_LOG_DEBUG_PRINT("[/CSUhomePage/getFaultLog] attach failed");
	}
	if(!web_func_attach("/CSUhomePage/getFaultLogList", TRANS_UNNEED, export_fault_List))	        //导出故障日志
	{
		SYS_LOG_DEBUG_PRINT("[/CSUhomePage/getFaultLogList] attach failed");
	}
    if(!web_func_attach("/homePage/getOperationList", TRANS_NEED, NULL))	                        //导出CMU操作日志
	{
		SYS_LOG_DEBUG_PRINT("[/homePage/getOperationList] attach failed");
	}
    if(!web_func_attach("/homePage/getFaultLogList", TRANS_NEED, NULL))	                            //导出CMU故障日志
	{
		SYS_LOG_DEBUG_PRINT("[/homePage/getFaultLogList] attach failed");
	} 
}