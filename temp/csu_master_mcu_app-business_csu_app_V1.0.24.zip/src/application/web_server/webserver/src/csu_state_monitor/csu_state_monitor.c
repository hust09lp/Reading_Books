#include <pthread.h>
#include "sdk_shm.h"
#include "sdk/sdk_public.h"
#include "sdk/sdk_dido.h"
#include "data_shm.h"
#include "libghttp.h"
#include "csu_state_monitor.h"
#include "cmu_data_monitor.h"
#include "sys_state.h"
#include "cJSON.h"
#include "app_common.h"

static uint8_t cmu_ip_tbl[MAX_SLAVE_COUNT][MAX_IP_LEN] = {CMU1_IP, CMU2_IP, CMU3_IP, CMU4_IP, CMU5_IP, CMU6_IP};
static uint8_t g_warning_status = 0;

/**
 * @brief    系统关机
 * @param	 
 * @return   
 */
void sys_power_off(void)
{
    uint8_t uri[128] = {0};
    uint8_t json_str[512] = {0};
    uint8_t ret = 0;
    uint8_t url[128] = {0};
    uint8_t response[2048] = {0};
    web_control_info_t *p_web_data = sdk_shm_web_control_data_get();
    
    strcpy(uri, "/controlCmd/remotePowerOffCmd");
    sprintf(json_str, "{\"action\":\"remotePowerOffCmd\"}");
    BIT_SET(p_web_data->control_cmd_flag, 1);
    p_web_data->control_cmd_data.run_state = 0;
    BIT_SET( p_web_data->csu_comb_web_set_flag, 2 );
    for(uint8_t dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
    {
        // if((dev_is_online(dev_num)) && (cmu_sys_info[dev_num - 1].sys_status == RUN))
        if(dev_is_online(dev_num))
        {
            // 打包URL
            sprintf(url, "%s%s%s", "http://", cmu_ip_tbl[dev_num - 1], uri);
            ret = http_net_post(url, json_str, response);
            if(ret != 1)
            {
                continue;
            }
        }
	}
}


/**
 * @brief    系统关机
 * @param	 
 * @return   
 */
void sys_power_on(void)
{
    uint8_t uri[128] = {0};
    uint8_t json_str[512] = {0};
    uint8_t ret = 0;
    uint8_t url[128] = {0};
    uint8_t response[2048] = {0};
    web_control_info_t *p_web_data = sdk_shm_web_control_data_get();

    strcpy(uri, "/controlCmd/remotePowerOnCmd");
    sprintf(json_str, "{\"action\":\"remotePowerOnCmd\"}");

    BIT_SET(p_web_data->control_cmd_flag, 1);
    p_web_data->control_cmd_data.run_state = 1;
    BIT_SET( p_web_data->csu_comb_web_set_flag, 1 );
    for(uint8_t dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
    {
        if(dev_is_online(dev_num))
        {
            // 打包URL
            sprintf(url, "%s%s%s", "http://", cmu_ip_tbl[dev_num - 1], uri);
            ret = http_net_post(url, json_str, response);
            if(ret != 1)
            {
                continue;
            }
        }
	}
}


/**
 * @brief    向CMU同步系统故障状态
 * @param	 
 * @return   
 */
void sys_fault_sync(uint8_t csu_status)
{
    uint8_t uri[128] = {0};
    uint8_t json_str[512] = {0};
    uint8_t ret = 0;
    uint8_t url[128] = {0};
    uint8_t response[2048] = {0};

    strcpy(uri, "/homePage/csuFaultSet");
    sprintf(json_str, "{\"action\":\"csuFaultSet\",\"csuStatus\":%d}", csu_status);
    for(uint8_t dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
    {
        if(dev_is_online(dev_num))
        {
            // 打包URL
            sprintf(url, "%s%s%s", "http://", cmu_ip_tbl[dev_num - 1], uri);
            ret = http_net_post(url, json_str, response);
            if(ret != 1)
            {
                continue;
            }
        }
	}
}

/**
 * @brief    向CMU同步系统告警状态
 * @param	 
 * @return   
 */
static void sys_warning_status_sync(void)
{
    uint8_t warning_status = 0; 
    uint8_t csu_status = 0;
    uint8_t uri[128] = {0};
    uint8_t json_str[512] = {0};
    uint8_t ret = 0;
    uint8_t url[128] = {0};
    uint8_t response[2048] = {0};

    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();
    //把所有的一级告警信息摘出来进行判断
    warning_status = ((p_telematic_data->csu_system_fault_info[0] & FAULT_BIT_0) |
                     (p_telematic_data->csu_system_fault_info[0] & FAULT_BIT_1) |
                     (p_telematic_data->csu_system_fault_info[0] & FAULT_BIT_2) |
                     (p_telematic_data->csu_system_fault_info[0] & FAULT_BIT_3) |
                     (p_telematic_data->csu_system_fault_info[1] & FAULT_BIT_1) |
                     (p_telematic_data->csu_system_fault_info[1] & FAULT_BIT_2) |
                     (p_telematic_data->csu_system_fault_info[1] & FAULT_BIT_3) |
                     (p_telematic_data->csu_system_fault_info[1] & FAULT_BIT_4) |
                     (p_telematic_data->csu_system_fault_info[1] & FAULT_BIT_5) |
                     (p_telematic_data->csu_system_fault_info[1] & FAULT_BIT_6) |
                     (p_telematic_data->csu_system_fault_info[2] & FAULT_BIT_0) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[0] & FAULT_BIT_0) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[0] & FAULT_BIT_1) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[0] & FAULT_BIT_4) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[0] & FAULT_BIT_5) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[0] & FAULT_BIT_6) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[0] & FAULT_BIT_7) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[1] & FAULT_BIT_0) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[1] & FAULT_BIT_2) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[1] & FAULT_BIT_4) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[1] & FAULT_BIT_5) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[1] & FAULT_BIT_6) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[2] & FAULT_BIT_0) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[2] & FAULT_BIT_2) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[2] & FAULT_BIT_3) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[2] & FAULT_BIT_4) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[2] & FAULT_BIT_5) |   
                     (p_telematic_data->combiner_cabinet_system_fault_info[2] & FAULT_BIT_6) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[2] & FAULT_BIT_7) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[3] & FAULT_BIT_0) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[3] & FAULT_BIT_1) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[3] & FAULT_BIT_2) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[3] & FAULT_BIT_3) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[3] & FAULT_BIT_4) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[3] & FAULT_BIT_5) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[3] & FAULT_BIT_6) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[3] & FAULT_BIT_7) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[4] & FAULT_BIT_0) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[4] & FAULT_BIT_1) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[4] & FAULT_BIT_2) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[4] & FAULT_BIT_4) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[4] & FAULT_BIT_7) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[5] & FAULT_BIT_0) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[5] & FAULT_BIT_2) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[5] & FAULT_BIT_3) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[5] & FAULT_BIT_4) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[5] & FAULT_BIT_5) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[5] & FAULT_BIT_6) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[5] & FAULT_BIT_7) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[6] & FAULT_BIT_0) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[6] & FAULT_BIT_1) |
                     (p_telematic_data->combiner_cabinet_system_fault_info[6] & FAULT_BIT_2));

    if(g_warning_status != warning_status)
    {
        //告警产生
        if(g_warning_status == 0)
        {
            CSU_STATE_DEBUG_PRINT((int8_t *)"csu warning start------->\n");
            csu_status = 1;
            g_warning_status = warning_status;
        }
        //告警结束
        else if(warning_status == 0)
        {
            CSU_STATE_DEBUG_PRINT((int8_t *)"csu warning end------->\n");
            csu_status = 0;
            g_warning_status = warning_status;
        } 

        strcpy(uri, "/homePage/csuWarnStatusSet");
        sprintf(json_str, "{\"action\":\"csuWarnStatusSet\",\"csuStatus\":%d}", csu_status);
        for(uint8_t dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
        {
            if(dev_is_online(dev_num))
            {
                // 打包URL
                sprintf(url, "%s%s%s", "http://", cmu_ip_tbl[dev_num - 1], uri);
                ret = http_net_post(url, json_str, response);
                if(ret != 1)
                {
                    continue;
                }
            }
        }
    }
}


/**
 * @brief  节能降耗处理
 * @param  [in] none
 * @return none
 */
static void energy_save_handle(void)
{
    uint8_t uri[128] = {0};
    uint8_t json_str[512] = {0};
    uint8_t ret = 0;
    uint8_t url[128] = {0};
    uint8_t response[2048] = {0};

    common_data_t *shm = sdk_shm_get();
    web_control_info_t *sdk_shm_web_data = &shm->web_control_info;

    strcpy(uri, "/sysManager/sysStateSet");
    for(uint8_t i = 0; i < MAX_SLAVE_COUNT; i++)
    {
        if(shm->constant_parameter_data.mcu2_notice[i] != 0)
        {
            if(dev_is_online(i + 1))
            {
                // 打包URL
                sprintf(url, "%s%s%s", "http://", cmu_ip_tbl[i], uri);
                sprintf(json_str, "{\"action\":\"sysStateSet\",\"mode\":%d}", shm->constant_parameter_data.mcu2_notice[i]);
                ret = http_net_post(url, json_str, response);
                if(ret)
                {
                    BIT_SET(sdk_shm_web_data->mcu2_notice, i);
                    shm->constant_parameter_data.mcu2_notice[i] = 0;
                }
            }
        }
    }
}

/**
 * @brief  检测CMU离线情况，并置位告警状态
 * @param  [in] none
 * @return none
 */
static void cmu_online_monitor(void)
{
	uint8_t *p_fault = NULL;
	telematic_data_t *p_telematic_data = NULL;
    constant_parameter_data_t *p_constant_param = NULL;

	/* CSU系统故障 */
	p_telematic_data = sdk_shm_telematic_data_get();
	p_fault = p_telematic_data->csu_system_fault_info;
    p_constant_param = sdk_shm_constant_parameter_data_get();

    for(uint8_t i = 0; i < p_constant_param->cabinet_param_data.energy_storage_nums; i++)
    {
        //根据在线状态更新对应的bit点位
        if(dev_is_online(i + 1))
        {
            BIT_CLR(p_fault[1], i + 1);
        }
        else
        {
            BIT_SET(p_fault[1], i + 1);
        }
    }
}


/**
 * @brief  检测首航云开关机检测
 * @param  [in] none
 * @return none
 */
static void sofar_cloud_power_status_monitor(void)
{
    web_control_info_t *p_web_data = sdk_shm_web_control_data_get();

    if(BIT_GET(p_web_data->control_cmd_flag, 5))
    {
        CSU_STATE_DEBUG_PRINT((int8_t *)"sofar func set--------->poweron\n");
        BIT_CLR(p_web_data->control_cmd_flag, 5);
        sys_power_on();
    }

    if(BIT_GET(p_web_data->control_cmd_flag, 6))
    {
        CSU_STATE_DEBUG_PRINT((int8_t *)"sofar func set--------->poweroff\n");
        BIT_CLR(p_web_data->control_cmd_flag, 6);
        sys_power_off();
    }
}


/**
 * @brief    更新系统时间
 * @param	 
 * @return   
 */
void sys_time_sync(void)
{
    cJSON *p_root = NULL;
    sdk_rtc_t rtc_time = {0};
    char ymd[32] = {0};
    char hms[32] = {0};
    uint8_t uri[128] = {0};
    uint8_t ret = 0;
    uint8_t url[128] = {0};
    uint8_t response[2048] = {0};
    char *p = NULL;

    strcpy(uri, "/system/customSetTime");

	sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
    sprintf(ymd, "%04d-%02d-%02d", rtc_time.tm_year + 2000, rtc_time.tm_mon, rtc_time.tm_day);
    sprintf(hms, "%02d:%02d:%02d", rtc_time.tm_hour, rtc_time.tm_min, rtc_time.tm_sec);

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        return;
    }
    cJSON_AddStringToObject(p_root, "action", "customSetTime");
    cJSON_AddStringToObject(p_root,"userName","EMS");
    cJSON_AddStringToObject(p_root, "customYMD", ymd);
    cJSON_AddStringToObject(p_root, "customHMS", hms);

    p = cJSON_PrintUnformatted(p_root);

    sprintf(url, "%s%s%s", "http://", cmu_ip_tbl[0], uri);
    http_net_post(url, p, response);
    cJSON_Delete(p_root);
    free(p);
}


/**
 * @brief  检测同步CMU系统时间
 * @param  [in] none
 * @return none
 */
static void sys_time_sync_cmu_dev(void)
{
    web_control_info_t *p_web_data = sdk_shm_web_control_data_get();

    if(BIT_GET(p_web_data->system_param_flag, 4))
    {
        CSU_STATE_DEBUG_PRINT((int8_t *)"set cmu func--------->sync time\n");
        BIT_CLR(p_web_data->system_param_flag, 4);
        sys_time_sync();
    }
}


/**
 * @brief  检测设备系统时间夏令时是否发生变化
 * @param  [in] none
 * @return none
 */
static void sys_time_dst_is_change(void)
{
    static int is_dst = 0;
    time_t current_timestamp = 0;

    web_control_info_t *p_web_data = sdk_shm_web_control_data_get();
    current_timestamp = time(NULL);
    struct tm *tm_local = localtime(&current_timestamp);
    //令时发生变化，需要同步一下CMU以及CSU-MCU2时间
    if(tm_local->tm_isdst != is_dst)
    {
        CSU_STATE_DEBUG_PRINT((int8_t *)"isDst change--------->sync time\n");
        BIT_SET(p_web_data->system_param_flag, 2);
        BIT_SET(p_web_data->system_param_flag, 4);
        is_dst = tm_local->tm_isdst;
    }
}

/**
 * @brief  检测系统3级故障，若存在则拉高对应DO
 * @param  [in] none
 * @return none
 */
static void sys_3_level_fault_monitor(void)
{
    if((combiner_cabinet_get_serious_fault() == FAULT_YES) || (cmu_sys_status_get() == FAULT))
    {
        //存在三级故障
        //输出故障IO(INDEX_DO_OUT5)
        sdk_dido_write(INDEX_DO_OUT5, DI_DO_HIGH);
        return;
    } 
    sdk_dido_write(INDEX_DO_OUT5, DI_DO_LOW);
    return;
}


/**
 * @brief  CSU状态检测线程
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
void *csu_state_monitor_func(void *arg)
{
    uint8_t last_sys_status = MAX;
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();
    static uint8_t cmu_online_monitor_delay = 0;
    sleep(5);
    while(1)
    {
        // 故障处理，通报CSU系统故障
        if(FAULT_YES == combiner_cabinet_get_serious_fault())
        {
            if(cmu_sys_status_get() != FAULT)
            {
                sys_fault_sync(1);
                sdk_delay_ms(2500);
            }
        }
        else
        {
            if(cmu_sys_status_get() == FAULT)
            {
                sys_fault_sync(0);
                sdk_delay_ms(3500);
            }
        }
        //告警状态同步
        sys_warning_status_sync();
        // 实时同步系统状态
        p_telemetry_data->sys_version_telemetry_info.csu_sys_state = sys_status_get();
        //MCU2节能降耗处理
        energy_save_handle();
        //CMU离线检测 上电后延迟30秒检测，防止CMU和CSU启动时间不一致误报
        if (cmu_online_monitor_delay < 60)
        {
            cmu_online_monitor_delay++;
        }
        else
        {
            cmu_online_monitor();
        }
        //首航云开关机检测
        sofar_cloud_power_status_monitor();
        //CMU系统时间同步
        sys_time_sync_cmu_dev();
        //检测系统时间夏令时是否发生变化
        sys_time_dst_is_change();

        sdk_delay_ms(500);
    }
}


/**
 * @brief  系统故障检测线程
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
void *sys_fault_monitor_func(void *arg)
{
    sleep(2);
    while(1)
    {
        //系统三级故障检测
        sys_3_level_fault_monitor();

        sdk_delay_ms(500);
    }
}


/**
 * @brief   csu系统状态管理模块初始化
 * @param   
 * @note    
 * @return  
 */
void csu_state_monitor_module_init(void)
{
	int16_t ret = 0;
    pthread_t sys_state_process; 
    // 初始化线程属性
    pthread_attr_t info_record_attr;

    ret = pthread_attr_init(&info_record_attr);
    if (ret)
    {
        log_e((int8_t *)"\n [%s:%d] pthread_attr_init error!!! \n", __func__, __LINE__);
        return; 
    }
    
    // 设置线程属性为分离状态
    ret = pthread_attr_setdetachstate(&info_record_attr, PTHREAD_CREATE_DETACHED);
    if (ret)
    {
        log_e((int8_t *)"\n [%s:%d] pthread_attr_setdetachstate info_record_attr error!!! \n", __func__, __LINE__);
		return; 
    }	
	
    pthread_create(&sys_state_process, &info_record_attr, &csu_state_monitor_func, NULL);
	if (ret)
    {
        log_e((int8_t *)"\n [%s:%d] pthread_create operating_record error!!! \n", __func__, __LINE__);
		return; 
    }

    pthread_t sys_fault_do_monitor_process; 
    pthread_create(&sys_fault_do_monitor_process, &info_record_attr, &sys_fault_monitor_func, NULL);
	if (ret)
    {
        log_e((int8_t *)"\n [%s:%d] pthread_create operating_record error!!! \n", __func__, __LINE__);
		return; 
    }
}

