
#ifndef __CSU_SYS_STATE_H__
#define __CSU_SYS_STATE_H__


#include "data_types.h"

#if (1)
#define CSU_STATE_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else
#define CSU_STATE_DEBUG_PRINT(...) {do {} while(0);}
#endif

#define FAULT_NO          (0)
#define FAULT_YES         (1)


/**
 * @brief   csu系统状态管理模块初始化
 * @param   
 * @note    
 * @return  
 */
void csu_state_monitor_module_init(void);


#endif /* __SYS_STATE_H__ */
