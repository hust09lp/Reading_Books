#include "cJSON.h"
#include "params_info.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "app_common.h"
#include "common.h"
#include "operation_log.h"
#include "web_broker.h"

/**
 * @brief    获取PCS功率
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void get_pcs_power_value(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_item = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t response[168];
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t request_body[64] = {0}; 
	common_data_t *shm = NULL;
	cabinet_parameter_data_t *p_cabinet_param = NULL;

	shm = sdk_shm_get();

	memcpy(request_body,p_msg->body.p,p_msg->body.len);	
	p_request = cJSON_Parse(request_body);
    if (p_request == NULL)
	{
		PARAM_INFO_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"getPCSParam"))
	{
		PARAM_INFO_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        PARAM_INFO_DEBUG_PRINT("create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",OK);

    p_resp_item = cJSON_CreateObject();
    if(p_resp_item == NULL)
    {
    	cJSON_Delete(p_resp_root);
		build_empty_response(response,Non_Authoriative_Information,"err");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;

    }
	
	p_cabinet_param = &shm->constant_parameter_data.cabinet_param_data;
	cJSON_AddNumberToObject(p_resp_item,"activePower",p_cabinet_param->active_power/10);
	cJSON_AddNumberToObject(p_resp_item,"reactivePower",p_cabinet_param->reactive_power/10); 

	cJSON_AddItemToObject(p_resp_root,"data",p_resp_item);
	cJSON_AddStringToObject(p_resp_root,"msg","get successful");
		
	p = cJSON_PrintUnformatted(p_resp_root);

	cJSON_Delete(p_resp_root);	
	http_back(p_nc,p);
	free(p);
}


/**
 * @brief    设置PCS功率
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void set_pcs_power_value(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_item = NULL;
    cJSON *p_resp_root = NULL;
	cJSON *p_data = NULL;
    uint8_t response[168];  //
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t request_body[64] = {0};
	float64_t activePower;
	float64_t reactivePower;
	operation_log_t op_log;
	uint8_t cur_user[32] = {0};
	web_control_info_t *sdk_shm_web_data = sdk_shm_web_control_data_get();
	cabinet_parameter_data_t *p_cabinet_param = NULL;
	
	memcpy(request_body,p_msg->body.p,p_msg->body.len);	
	p_request = cJSON_Parse(request_body);
    if (p_request == NULL)
	{
		PARAM_INFO_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	if ((NULL == cJSON_GetObjectItem(p_request,"action")) || (NULL == cJSON_GetObjectItem(p_request,"data")))
	{
		PARAM_INFO_DEBUG_PRINT("parameter is not right.");
		build_empty_response(response,Non_Authoriative_Information,"parameter is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;

	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"setPCSParam"))
	{
		PARAM_INFO_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	p_data = cJSON_GetObjectItem(p_request,"data");
	activePower = cJSON_GetObjectItem(p_data,"activePower")->valuedouble;
	reactivePower = cJSON_GetObjectItem(p_data,"reactivePower")->valuedouble;
	PARAM_INFO_DEBUG_PRINT("new activePower %f new reactivePower %f",activePower, reactivePower);
    cJSON_Delete(p_request);

	p_cabinet_param = &sdk_shm_web_data->cabinet_param_data;

	PARAM_INFO_DEBUG_PRINT("old activePower %d old reactivePower %d",p_cabinet_param->active_power/10, p_cabinet_param->reactive_power/10.0);
	
    init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);


	if (p_cabinet_param->active_power/10.0 != activePower)
	{
		op_log.op_param1 =	p_cabinet_param->active_power/10.0;
		op_log.op_param2 = activePower;
		strcpy(op_log.op_type,"修改PCS柜有功功率值");
		strcpy(op_log.op_status,"success");
		add_one_op_log(&op_log);
	}

	if (p_cabinet_param->reactive_power/10.0 != reactivePower)
	{
		op_log.op_param1 = p_cabinet_param->reactive_power/10.0;
		op_log.op_param2 = reactivePower;
		strcpy(op_log.op_type,"修改PCS柜无功功率值");
		strcpy(op_log.op_status,"success");
		add_one_op_log(&op_log);
	}

	p_cabinet_param->active_power  = activePower * 10;
	p_cabinet_param->reactive_power  = reactivePower * 10;
	BIT_SET(sdk_shm_web_data->cabinet_param_update_flag, 1);

    p_resp_root = cJSON_CreateObject();
    if (p_resp_root == NULL)
    {
        PARAM_INFO_DEBUG_PRINT("create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",OK);
    cJSON_AddStringToObject(p_resp_root,"msg","set successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_resp_root);
    http_back(p_nc,p);
	free(p);
}


/**
 * @brief 参数设置模块初始化
 * @return void
 */
void web_param_info_module_init(void)
{
	if(!web_func_attach("/paramsInfo/getPCSParam", TRANS_UNNEED, get_pcs_power_value))	//设置PCS柜/模块参数
	{
		PARAM_INFO_DEBUG_PRINT("[/paramsInfo/getPCSParam] attach failed");
	}
	if(!web_func_attach("/paramsInfo/setPCSParam", TRANS_UNNEED, set_pcs_power_value))	//获取PCS柜/模块参数
	{
		PARAM_INFO_DEBUG_PRINT("[/paramsInfo/setPCSParam] attach failed");
	}
	if(!web_func_attach("/paramsInfo/getEOLAlarmThreshold", TRANS_NEED, NULL))	//获取EOL告警阈值参数数
	{
		PARAM_INFO_DEBUG_PRINT("[/paramsInfo/getEOLAlarmThreshold] attach failed");
	}
	if(!web_func_attach("/paramsInfo/setEOLAlarmThreshold", TRANS_NEED, NULL))	//设置EOL告警阈值参数
	{
		PARAM_INFO_DEBUG_PRINT("[/paramsInfo/setEOLAlarmThreshold] attach failed");
	}
}

