#ifndef __PARAMS_INFO_H__
#define __PARAMS_INFO_H__

#include"mongoose.h"
#include "component/sofar_log.h"

#if (1)
#define PARAM_INFO_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else
#define PARAM_INFO_DEBUG_PRINT(...) {do {} while(0);}
#endif


/**
 * @brief 参数设置模块初始化
 * @return void
 */
void web_param_info_module_init(void);

#endif