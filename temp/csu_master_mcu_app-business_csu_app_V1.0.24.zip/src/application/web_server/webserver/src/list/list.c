#include "list.h"

/**
 * @brief 前后两节点之间插入一个新的节点
 *
 * @param [in] ptNew : 新加入的节点
 * @param [in] ptPrev : 前节点
 * @param [in] ptNext : 后节点
 * 
 * @return none
 */
static void _list_add(p_list_head_t ptNew, p_list_head_t ptPrev, p_list_head_t ptNext)
{
    ptNext->ptPrev = ptNew;
    ptNew->ptNext = ptNext;
    ptNew->ptPrev = ptPrev;
    ptPrev->ptNext = ptNew;
}


/**
 * @brief 判断该链表是否为空
 *
 * @param [in] ptHead : 节点
 * 
 * @retval bool
 * @return TRUE : 链表为空
 *         FALSE : 链表不为空
 */
bool list_empty(p_list_head_t ptHead)
{
    return ptHead->ptNext == ptHead;
}

/**
 * @brief 插入一个新的节点
 *
 * @param [in] ptNew : 新加入的节点
 * @param [in] ptHead : 插入点
 * 
 * @return void
 */
void list_add(p_list_head_t ptNew, p_list_head_t ptHead)
{
    _list_add(ptNew, ptHead, ptHead->ptNext);
}


