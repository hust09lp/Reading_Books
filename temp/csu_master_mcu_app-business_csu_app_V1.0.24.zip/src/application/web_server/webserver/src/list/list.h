#ifndef __LIST_H__
#define __LIST_H__

#include "stdbool.h"

typedef struct list_head{
    struct list_head *ptNext, *ptPrev;
}list_head_t, *p_list_head_t;

#define list_head_init(name) { &(name), &(name) }

//定义LIST并静态初始化一个空的通用双向链表
#define list_head(name) \
list_head_t name = list_head_init(name)

//动态初始化一个空的通用双向链表
#define init_list_head(ptr) do{ \
    (ptr)->ptNext = (ptr); \
    (ptr)->ptPrev = (ptr); \
}while(0)

//动态分配一个包含通用双向链表的结构体
#define new_list_node(type, node) {\
    node = (type *)malloc(sizeof(type));\
}


//获取链表中第一个节点地址(该地址指向其主结构)
#define get_first_node(type, p, list_name, pGetNode) {\
    pGetNode = NULL;\
    while(!ty_list_empty(&(p)->list_name)){\
        pGetNode = ty_list_entry((&(p)->list_name)->ptNext, type, list_name);\
        break;\
    }\
}

//获取包含该通用链表节点的结构体的首址
#define list_entry(ptr, type, member) \
    ((type *)((char *)(ptr)-(size_t)(&((type *)0)->member)))

//遍历链表
#define list_for_each(pos, head) \
    for(pos = (head)->ptNext; (NULL != pos) && (pos != (head)); pos = pos->ptNext)



/**
 * @brief 判断该链表是否为空
 *
 * @param [in] ptHead : 节点
 * 
 * @retval bool
 * @return TRUE : 链表为空
 *         FALSE : 链表不为空
 */
bool list_empty(p_list_head_t ptHead);

/**
 * @brief 插入一个新的节点
 *
 * @param [in] ptNew : 新加入的节点
 * @param [in] ptHead : 插入点
 * 
 * @return void
 */
void list_add(p_list_head_t ptNew, p_list_head_t ptHead);


#endif
