#ifndef __USER_MANAGE_H__
#define __USER_MANAGE_H__

#include "mongoose.h"
#include "component/sofar_log.h"

typedef enum
{
	LOGIN_OK,
	LOGIN_FAILED,
	LOGIN_MAX
}login_status_e;

#if (1)
#define USER_MANEGE_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else
#define USER_MANEGE_DEBUG_PRINT(...) {do {} while(0);}
#endif


/**
 * @brief 用户管理模块初始化
 * @return void
 */
void web_user_manage_module_init(void);

#endif
