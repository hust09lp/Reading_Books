#include "sdk_public.h"
#include "cJSON.h"
#include "app_common.h"
#include "web_broker.h"
#include "user_manage.h"
#include "common.h"
#include "operation_log.h"


#define MAX_BUFF (200 * 250)   //每一条最多占用200字节,最多可以有250条
#define DEFAULT_PASSWORD_MD5 "d000670b645d5fc3dea909b4e21a455c"
#define MAX_OPERATOR 50   
#define MAX_ENDUSER 200
#define MAX_BUFF (200 * 250)   //每一条最多占用200字节,最多可以有250条


/**
 * @brief    获取当前用户数量
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void get_current_user_num(uint8_t *p_operator_num, uint8_t *p_enduser_num)
{
	FILE *fp = NULL;
	cJSON *p_conf_array = NULL;
	uint8_t *p_buff = NULL;
	uint8_t i;
	uint8_t *p_role = NULL; 
	cJSON *p_conf_item = NULL;

	fp = fopen(ADMIN_JSON_FILE,"r");
	if(fp == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("open [%s] failed.");
		return;
	}

	p_buff = (uint8_t *)malloc(MAX_BUFF);
	if(p_buff == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("malloc memory failed.");
		fclose(fp);
		return;
	}

	fread(p_buff, 1, MAX_BUFF, fp);
	fclose(fp);

	p_conf_array = cJSON_Parse(p_buff);
	if(p_conf_array == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("parse config [%s] failed.",ADMIN_JSON_FILE);
		free(p_buff);
		return;
	}
	free(p_buff);  //此时p_buff里面的json数据已经全部解析到了p_conf_array里面,这个已经没有用了,可以释放了

	*p_operator_num = 0;
	*p_enduser_num = 0;
	for(i = 0; i < cJSON_GetArraySize(p_conf_array); i++)
	{
		p_conf_item = cJSON_GetArrayItem(p_conf_array, i);
		p_role = cJSON_GetObjectItem(p_conf_item,"role")->valuestring;
		if(!strcmp(p_role,"operator"))
		{
			*p_operator_num += 1;
		}
		else if(!strcmp(p_role,"enduser"))
		{
			*p_enduser_num += 1;
		}
	}
	cJSON_Delete(p_conf_array);
}


/**
 * @brief    获取用户信息
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void get_user_info(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_conf_array = NULL;
	cJSON *p_conf_item = NULL;
	cJSON *p_resp_data_array = NULL;
	cJSON *p_resp_data_item = NULL;
	cJSON *p_resp_root = NULL;
	uint8_t *p_action = NULL;
	uint8_t *p_uname = NULL;
	uint8_t *p_role = NULL;
	uint8_t *p_creat_time = NULL;
	uint8_t *p_stat = NULL;
	uint8_t *p_phonenum = NULL;
	uint8_t *p = NULL;
	FILE *fp = NULL;
	uint16_t i;
	uint8_t *p_buff = NULL;
	uint8_t response[64];
	uint8_t request_body[128] = {0};

	memcpy(request_body, p_msg->body.p, p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("request body is not json.");
		build_empty_response(response,Accepted,"request body is not json.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action, "getUserInfo"))
	{
		USER_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response, Non_Authoriative_Information, "action is not right");
		cJSON_Delete(p_request);
		http_back(p_nc, response);
		return;
	}
	cJSON_Delete(p_request);

	fp = fopen(ADMIN_JSON_FILE,"r");
	if(fp == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("open [%s] failed.");
		return;
	}
	p_buff = (uint8_t *)malloc(MAX_BUFF);
	if(p_buff == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("malloc memory failed.");
		fclose(fp);
		return;
	}

	fread(p_buff, 1, MAX_BUFF, fp);
	fclose(fp);

	p_conf_array = cJSON_Parse(p_buff);
	if(p_conf_array == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("parse config [%s] failed.", ADMIN_JSON_FILE);
		free(p_buff);
		return;
	}
	free(p_buff);

	p_resp_data_array = cJSON_CreateArray();
	if(p_resp_data_array == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("create data array failed.");
		cJSON_Delete(p_conf_array);
		return;
	}
	
	for(i = 0; i < cJSON_GetArraySize(p_conf_array);i++)
	{
		p_phonenum = NULL;
		p_conf_item = cJSON_GetArrayItem(p_conf_array,i);
		p_uname = cJSON_GetObjectItem(p_conf_item,"username")->valuestring;
		p_role = cJSON_GetObjectItem(p_conf_item,"role")->valuestring;
		p_creat_time = cJSON_GetObjectItem(p_conf_item,"createtime")->valuestring;
		p_stat = cJSON_GetObjectItem(p_conf_item,"status")->valuestring;
		if(cJSON_GetObjectItem(p_conf_item,"phonenum") != NULL)
		{
			p_phonenum = cJSON_GetObjectItem(p_conf_item,"phonenum")->valuestring;
		}
		p_resp_data_item = cJSON_CreateObject();
		if(p_resp_data_item == NULL)
		{
			USER_MANEGE_DEBUG_PRINT("create data item failed.");
			cJSON_Delete(p_conf_array);
			cJSON_Delete(p_resp_data_array);
			return;
		}
		cJSON_AddStringToObject(p_resp_data_item,"userName",p_uname);
		cJSON_AddStringToObject(p_resp_data_item,"userRole",p_role);
		cJSON_AddStringToObject(p_resp_data_item,"createTime",p_creat_time);
		cJSON_AddStringToObject(p_resp_data_item,"accountStat",p_stat);
		if(p_phonenum != NULL)
		{
			cJSON_AddStringToObject(p_resp_data_item,"phoneNum",p_phonenum);
		}
		cJSON_AddItemToArray(p_resp_data_array,p_resp_data_item);
	}
	cJSON_Delete(p_conf_array);
	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("create json obj failed.");
        cJSON_Delete(p_resp_data_array);
		return;
	}
	cJSON_AddItemToObject(p_resp_root,"data",p_resp_data_array);
	cJSON_AddNumberToObject(p_resp_root,"code",OK);
	cJSON_AddStringToObject(p_resp_root,"msg","get user info successful.");

	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	
	free(p);
}


/**
 * @brief    删除用户
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void delete_users(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;	
	cJSON *p_user_info_array = NULL;
	cJSON *p_user_info_item = NULL;
	cJSON *p_conf_array = NULL;
	cJSON *p_conf_item = NULL;
	FILE *fp = NULL;
	uint8_t response[128] = {0};
	uint8_t *p_buff = NULL;
	uint8_t *p_action = NULL;
	uint8_t num;
	uint8_t i,j;
	uint8_t user_to_del[32][64];
	uint8_t *p = NULL;
	uint8_t request_body[4096] = {0};
	uint8_t cur_user[32] = {0};
	operation_log_t op_log;
	
	memcpy(request_body, p_msg->body.p, p_msg->body.len);		
	for(i = 0; i < 32; i++)
	{
		memset(user_to_del[i], 0, 64);
	}

	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response, Accepted, "parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action, "deleteUser"))
	{
		USER_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
	
	num = cJSON_GetObjectItem(p_request,"num")->valueint;
	p_user_info_array = cJSON_GetObjectItem(p_request,"userInfo");
	if(num != cJSON_GetArraySize(p_user_info_array))
	{
		USER_MANEGE_DEBUG_PRINT("num is not equal to array size.");
		cJSON_Delete(p_request);
		return;
	}

	for(i = 0; i < num; i++)
	{
		p_user_info_item = cJSON_GetArrayItem(p_user_info_array, i);
		strcpy(user_to_del[i], cJSON_GetObjectItem(p_user_info_item, "userName")->valuestring);		
	}
	cJSON_Delete(p_request);

	fp = fopen(ADMIN_JSON_FILE,"r");
	if(fp == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("open %s failed.", ADMIN_JSON_FILE);
		return;
	}
	p_buff = (uint8_t *)malloc(MAX_BUFF);
	if(p_buff == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("malloc memory failed.");
		fclose(fp);
		return;
	}
	memset(p_buff, 0, MAX_BUFF);
	fread(p_buff, 1, MAX_BUFF, fp);
	fclose(fp);

	p_conf_array = cJSON_Parse(p_buff);
	if(p_conf_array == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("parse conf file failed.");
		free(p_buff);
		return;
	}
	free(p_buff);

	for(i = 0; i < num; i++)
	{
		for(j = 0; j < cJSON_GetArraySize(p_conf_array); j++)
		{
			p_conf_item = cJSON_GetArrayItem(p_conf_array, j);
			if((!strcmp(user_to_del[i], cJSON_GetObjectItem(p_conf_item,"username")->valuestring) &&
			(strcmp(user_to_del[i], "admin"))))
			{
				cJSON_DeleteItemFromArray(p_conf_array, j);
				break; //此处退出内循环即可。因为用户名字的唯一性，所以没有必要继续循环下去
			}
		}
	}

	p = cJSON_PrintUnformatted(p_conf_array);

	fp = fopen(ADMIN_JSON_FILE,"w");
	if(fp == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("open %s failed.", ADMIN_JSON_FILE);
		cJSON_Delete(p_conf_array);
		return;
	}
	fwrite(p,1,strlen(p),fp);
	fclose(fp);

	cJSON_Delete(p_conf_array);
	free(p);

	init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	if(num > 1)
	{
		strcpy(op_log.op_type,"批量删除用户");
	}
	else
	{
		strcpy(op_log.op_type,"删除用户");
	}
	strcpy(op_log.op_status,"success");
	add_one_op_log(&op_log);

	
	build_empty_response(response,OK,"delete successful");
	http_back(p_nc,response);
}


/**
 * @brief    添加用户
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void add_one_user(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_conf_array = NULL;
	cJSON *p_conf_item = NULL;
	uint8_t *p_action = NULL;
	uint8_t *p_uname = NULL;
	uint8_t *p_conf_uname = NULL;
	uint8_t *p_role = NULL;
	uint8_t *p_pwd = NULL;
	uint8_t *p_phonenum = NULL;
	uint8_t *p = NULL;
	uint8_t i;
	FILE *fp = NULL;
	uint8_t response[128];
	uint8_t request_body[256] = {0};
	uint8_t *p_buff = NULL;
	uint8_t md5[16] = {0};
	uint8_t md5_str[33] = {0};
	operation_log_t op_log;
	uint8_t cur_user[32] = {0};
	uint8_t p_operator_num;
	uint8_t p_enduser_num;
    sdk_rtc_t rtc_time = {0};
    uint8_t rtc_date[32] = {0};

	memcpy(request_body, p_msg->body.p, p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response, Accepted, "parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request, "action")->valuestring;
	if(strcmp(p_action, "addUser"))
	{
		USER_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response, Non_Authoriative_Information, "action is not right");
		cJSON_Delete(p_request);
		http_back(p_nc,response);
		return;
	}
	p_uname = cJSON_GetObjectItem(p_request, "userName")->valuestring;
	p_role = cJSON_GetObjectItem(p_request, "userRole")->valuestring;
	p_pwd = cJSON_GetObjectItem(p_request, "loginPwd")->valuestring;
	get_current_user_num(&p_operator_num, &p_enduser_num);

	if(!strcmp(p_role,"operator") && (p_operator_num >= MAX_OPERATOR))
	{
		USER_MANEGE_DEBUG_PRINT("operator num is larger than 50");
		build_empty_response(response, 205, "operator num is larger than 50");
		cJSON_Delete(p_request);
		http_back(p_nc,response);
		return;
	}

	if(!strcmp(p_role,"enduser") && (p_enduser_num >= MAX_ENDUSER))
	{
		USER_MANEGE_DEBUG_PRINT("enduser num is larger than 200");
		build_empty_response(response, 206, "enduser num is larger than 200");
		cJSON_Delete(p_request);
		http_back(p_nc,response);
		return;
	}

	if(cJSON_GetObjectItem(p_request, "phoneNum") != NULL)
	{
		p_phonenum = cJSON_GetObjectItem(p_request, "phoneNum")->valuestring;
	}

	fp = fopen(ADMIN_JSON_FILE,"r");
	if(fp == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("open [%s] failed.");
		return;
	}

	p_buff = (uint8_t *)malloc(MAX_BUFF);
	if(p_buff == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("malloc memory failed.");
		fclose(fp);
		return;
	}
	fread(p_buff, 1, MAX_BUFF, fp);
	fclose(fp);

	p_conf_array = cJSON_Parse(p_buff);
	if(p_conf_array == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("parse config [%s] failed.", ADMIN_JSON_FILE);
		free(p_buff);
		return;
	}
	free(p_buff);  //此时p_buff里面的json数据已经全部解析到了p_conf_array里面,这个已经没有用了,可以释放了
	
	for(i = 0; i < cJSON_GetArraySize(p_conf_array); i++)
	{
		p_conf_item = cJSON_GetArrayItem(p_conf_array, i);
		p_conf_uname = cJSON_GetObjectItem(p_conf_item, "username")->valuestring;
		if(!strcmp(p_conf_uname, p_uname))  //名字具有唯一性，不能重复
		{
			USER_MANEGE_DEBUG_PRINT("username already exists.");
			cJSON_Delete(p_request);
			cJSON_Delete(p_conf_array);
			build_empty_response(response, 204, "username already exists.");
			http_back(p_nc, response);
			return;
		}
	}
	p_conf_item = cJSON_CreateObject();
	if(p_conf_item == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("create obj failed.");
		cJSON_Delete(p_request);
		cJSON_Delete(p_conf_array);
		return;
	}
	md5_calcul(p_pwd, strlen(p_pwd), md5);
	hex_to_str(md5, md5_str, 16);

    //获取系统时钟时间
    sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
    sprintf(rtc_date, "%04d-%02d-%02d %02d:%02d:%02d", rtc_time.tm_year + 2000, rtc_time.tm_mon, rtc_time.tm_day, 
                                                       rtc_time.tm_hour, rtc_time.tm_min, rtc_time.tm_sec);
	
	cJSON_AddStringToObject(p_conf_item,"username", p_uname);
	cJSON_AddStringToObject(p_conf_item,"password", md5_str);
	cJSON_AddStringToObject(p_conf_item,"role", p_role);
	cJSON_AddStringToObject(p_conf_item,"createtime", rtc_date);
	cJSON_AddStringToObject(p_conf_item,"status", "activated");
	if(p_phonenum != NULL)
	{
		cJSON_AddStringToObject(p_conf_item, "phonenum", p_phonenum);
	}
	cJSON_Delete(p_request);
	cJSON_AddItemToArray(p_conf_array, p_conf_item);
	p = cJSON_PrintUnformatted(p_conf_array);

	fp = fopen(ADMIN_JSON_FILE,"w");
	if(fp == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("open %s failed.", ADMIN_JSON_FILE);
		cJSON_Delete(p_conf_array);
		return;
	}
	fwrite(p, 1, strlen(p), fp);
	fclose(fp);

	cJSON_Delete(p_conf_array);
	free(p);
	sync();

	init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg, cur_user);
	strcpy(op_log.user_name, cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type, "添加用户");
	strcpy(op_log.op_status, "success");
	add_one_op_log(&op_log);

	build_empty_response(response, OK, "add user successful");
	http_back(p_nc, response);
}


/**
 * @brief    重置用户密码
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void reset_password(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_user_info_array = NULL;
	cJSON *p_user_info_item = NULL;
	cJSON *p_conf_array = NULL;
	cJSON *p_conf_item = NULL;
	FILE *fp = NULL;
	uint8_t *p = NULL;
	uint8_t *p_action = NULL;
	uint8_t i, j;
	uint8_t num;
	uint8_t response[128];
	uint8_t request_body[1024] = {0};
	uint8_t user_reset_pwd[32][64];
	uint8_t *p_buff = NULL;
	operation_log_t op_log;
	uint8_t cur_user[32] = {0};

	for(i = 0; i < 32; i++)
	{
		memset(user_reset_pwd[i], 0, 64); //初始化二维数组
	}

	memcpy(request_body, p_msg->body.p, p_msg->body.len);	
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response, Accepted, "parse request failed.");
		http_back(p_nc, response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request, "action")->valuestring;
	if(strcmp(p_action, "resetPwd"))
	{
		USER_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information, "action is not right");
		http_back(p_nc, response);
		cJSON_Delete(p_request);
		return;
	}
	num = cJSON_GetObjectItem(p_request,"num")->valueint;
	p_user_info_array = cJSON_GetObjectItem(p_request, "userInfo");

	if(num != cJSON_GetArraySize(p_user_info_array))
	{
		USER_MANEGE_DEBUG_PRINT("num is not equal to array size.");
		cJSON_Delete(p_request);
		return;
	}
	for(i = 0; i < num; i++)
	{
		p_user_info_item = cJSON_GetArrayItem(p_user_info_array, i);
		strcpy(user_reset_pwd[i], cJSON_GetObjectItem(p_user_info_item, "userName")->valuestring);		
	}
	cJSON_Delete(p_request);

	fp = fopen(ADMIN_JSON_FILE,"r");
	if(fp == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("open [%s] failed.");
		return;
	}

	p_buff = (uint8_t *)malloc(MAX_BUFF);
	if(p_buff == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("malloc memory failed.");
		fclose(fp);
		return;
	}
	fread(p_buff, 1, MAX_BUFF, fp);
	fclose(fp);

	p_conf_array = cJSON_Parse(p_buff);
	if(p_conf_array == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("parse config [%s] failed.",ADMIN_JSON_FILE);
		free(p_buff);
		return;
	}
	free(p_buff);  //此时p_buff里面的json数据已经全部解析到了p_conf_array里面,这个已经没有用了,可以释放了

	for(i = 0; i < num; i++)
	{
		for(j = 0; j < cJSON_GetArraySize(p_conf_array); j++)
		{
			p_conf_item = cJSON_GetArrayItem(p_conf_array, j);
			if(!strcmp(user_reset_pwd[i], cJSON_GetObjectItem(p_conf_item,"username")->valuestring))
			{
				cJSON_ReplaceItemInObject(p_conf_item,"password", cJSON_CreateString(DEFAULT_PASSWORD_MD5));
				break; //此处退出内循环即可。因为用户名字的唯一性，所以没有必要继续循环下去
			}
		}
	}
	p = cJSON_PrintUnformatted(p_conf_array);

	fp = fopen(ADMIN_JSON_FILE,"w");
	if(fp == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("open %s failed.",ADMIN_JSON_FILE);
		cJSON_Delete(p_conf_array);
		return;
	}
	fwrite(p, 1, strlen(p), fp);
	fclose(fp);

	cJSON_Delete(p_conf_array);
	free(p);

	init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg, cur_user);
	strcpy(op_log.user_name, cur_user);
	get_user_basic_info(&op_log);
	if(num > 1)
	{
		strcpy(op_log.op_type,"批量重置密码");
	}
	else
	{
		strcpy(op_log.op_type,"重置密码");
	}
	strcpy(op_log.op_status, "success");
	add_one_op_log(&op_log);

	build_empty_response(response, OK, "reset pwd successful");
	http_back(p_nc, response);
}


/**
 * @brief    编辑用户信息
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void edit_user_info(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_conf_array = NULL;
	cJSON *p_conf_item = NULL;
	uint8_t *p_action = NULL;
	uint8_t *p_uname = NULL;
	uint8_t *p_conf_uname = NULL;
	uint8_t *p_role = NULL;
	uint8_t *p_pwd = NULL;
	uint8_t *p_phonenum = NULL;
	uint8_t *p = NULL;
	uint8_t i;
	FILE *fp = NULL;
	uint8_t response[128];
	uint8_t request_body[128] = {0};
	uint8_t *p_buff = NULL;
	uint8_t md5[16] = {0};
	uint8_t md5_str[33] = {0};
	operation_log_t op_log;
	uint8_t cur_user[32] = {0};

	memcpy(request_body, p_msg->body.p,p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response, Accepted, "parse request failed.");
		http_back(p_nc, response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"modifyUser"))
	{
		USER_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
	p_uname = cJSON_GetObjectItem(p_request,"userName")->valuestring;
	p_role = cJSON_GetObjectItem(p_request,"userRole")->valuestring;
	p_pwd = cJSON_GetObjectItem(p_request,"loginPwd")->valuestring;
	md5_calcul(p_pwd,strlen(p_pwd),md5);
	hex_to_str(md5,md5_str,16);
	if(cJSON_GetObjectItem(p_request,"phoneNum") != NULL)
	{
		p_phonenum = cJSON_GetObjectItem(p_request,"phoneNum")->valuestring;
	}

	fp = fopen(ADMIN_JSON_FILE,"r");
	if(fp == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("open [%s] failed.");
		return;
	}

	p_buff = (uint8_t *)malloc(MAX_BUFF);
	if(p_buff == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("malloc memory failed.");
		fclose(fp);
		return;
	}
	memset(p_buff,0,MAX_BUFF);
	fread(p_buff,1,MAX_BUFF,fp);
	fclose(fp);

	p_conf_array = cJSON_Parse(p_buff);
	if(p_conf_array == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("parse config [%s] failed.",ADMIN_JSON_FILE);
		free(p_buff);
		return;
	}
	free(p_buff);  //此时p_buff里面的json数据已经全部解析到了p_conf_array里面,这个已经没有用了,可以释放了

	for(i=0;i<cJSON_GetArraySize(p_conf_array);i++)
	{
		p_conf_item = cJSON_GetArrayItem(p_conf_array,i);
		p_conf_uname = cJSON_GetObjectItem(p_conf_item,"username")->valuestring;
		if(!strcmp(p_conf_uname,p_uname))  //名字具有唯一性，不能重复
		{
			cJSON_ReplaceItemInObject(p_conf_item,"password",cJSON_CreateString(md5_str));
			cJSON_ReplaceItemInObject(p_conf_item,"role",cJSON_CreateString(p_role));
			if(p_phonenum != NULL)
			{
				if(cJSON_GetObjectItem(p_conf_item,"phonenum") != NULL)
				{
					cJSON_ReplaceItemInObject(p_conf_item,"phonenum",cJSON_CreateString(p_phonenum));
				}
				else
				{
					cJSON_AddStringToObject(p_conf_item,"phonenum",p_phonenum);
				}
			}
			else  //删除了电话号码
			{
				if(cJSON_GetObjectItem(p_conf_item,"phonenum") != NULL)
				{
					cJSON_DeleteItemFromObject(p_conf_item,"phonenum");
				}
			}
			break; //要编辑的已经找到，没有必要继续循环
		}
	}

	cJSON_Delete(p_request);
	p = cJSON_PrintUnformatted(p_conf_array);

	fp = fopen(ADMIN_JSON_FILE,"w");
	if(fp == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("open %s failed.",ADMIN_JSON_FILE);
		cJSON_Delete(p_conf_array);
		return;
	}
	fwrite(p,1,strlen(p),fp);
	fclose(fp);

	cJSON_Delete(p_conf_array);
	free(p);

	init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"修改用户信息");
	strcpy(op_log.op_status,"success");
	add_one_op_log(&op_log);

	build_empty_response(response,OK,"modify  user successful");
	http_back(p_nc,response);
}


/**
 * @brief    登录返回判断是否成功
 * @param	 [in] *p_user_name：用户名
 * @param	 [in] *p_pass_word：密码
 * @param	 [out] *role：角色
 * @return
 */
static login_status_e is_login_success(const uint8_t *p_user_name, const uint8_t *p_pass_word, uint8_t *p_role)
{
	cJSON *p_root_array;
	cJSON *p_array_item;
	FILE *fp;
	login_status_e login_status = LOGIN_FAILED;
	uint8_t content[MAX_BUFF] = {0};
	uint8_t md5[16] = {0};
	uint8_t md5_str[33] = {0};
	uint8_t *p_uname,*p_pwd,*p_stat;
	uint8_t i;
	md5_calcul(p_pass_word,strlen(p_pass_word), md5);
	hex_to_str(md5,md5_str,16);

	fp = fopen(ADMIN_JSON_FILE,"r");
	if(fp == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("open file %s failed.", ADMIN_JSON_FILE);
		return LOGIN_FAILED;
	}
	fread(content, 1, MAX_BUFF, fp);
	fclose(fp);
	USER_MANEGE_DEBUG_PRINT("parse json content,content:\n%s", content);
	p_root_array = cJSON_Parse(content);
	if(p_root_array == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("parse json content failed,content:\n%s", content);
		return LOGIN_FAILED;
	}
	for(i = 0; i < cJSON_GetArraySize(p_root_array); i++)
	{
		p_array_item = cJSON_GetArrayItem(p_root_array, i);
		if(p_array_item == NULL)
		{
			USER_MANEGE_DEBUG_PRINT("get array item [%d] failed.", i);
			goto END;
		}
	 	p_uname = cJSON_GetObjectItem(p_array_item,"username")->valuestring;
		p_pwd = cJSON_GetObjectItem(p_array_item,"password")->valuestring;
		p_stat = cJSON_GetObjectItem(p_array_item,"status")->valuestring;
		if(!strcmp(p_user_name, p_uname) && !strcmp(md5_str, p_pwd) && !strcmp(p_stat, "activated"))
		{
			USER_MANEGE_DEBUG_PRINT("get username [%s],password is ok and the account is activated", p_uname);
			login_status = LOGIN_OK;
			strcpy(p_role, cJSON_GetObjectItem(p_array_item, "role")->valuestring);
			goto END;
		}
	}
	END:
	if(p_root_array != NULL)
	{
		cJSON_Delete(p_root_array);
	}
	return login_status;
}


/**
 * @brief    用户登录
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void do_login(struct mg_connection *p_nc,struct http_message *p_msg)
{
	uint8_t response[64] = {0};
	uint8_t request_body[128] = {0};
	uint8_t *p_action = NULL;
	uint8_t *p_username = NULL;
	uint8_t *p_password = NULL;
	uint8_t *p_reason = NULL;
	uint8_t status_code;
	operation_log_t op_log;
	uint8_t user_role[16] = {0};
	cJSON *p_root = NULL;
	cJSON *p_resp_root  = NULL;
	uint8_t *p  = NULL;

	memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	
	p_root = cJSON_Parse(request_body);
	if(p_root == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("parse query string failed");
		status_code = Accepted;
		p_reason = "parse query string failed";
		goto END;
	}

	p_action = cJSON_GetObjectItem(p_root,"action")->valuestring;
	if(strcmp(p_action,"login"))
	{
		USER_MANEGE_DEBUG_PRINT("action is not right");
		status_code = Non_Authoriative_Information;
		p_reason = "action is not right";
		goto END;
	}

	p_username = cJSON_GetObjectItem(p_root,"userName")->valuestring;
	p_password = cJSON_GetObjectItem(p_root,"passWord")->valuestring;

	init_user_basic_info(&op_log);
	strcpy(op_log.user_name, p_username);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type, "用户登录");
	
	if(is_login_success(p_username,p_password,user_role) == LOGIN_OK)
	{
		status_code = OK;
		p_reason = "login successful";
		strcpy(op_log.op_status,"success");
		add_one_op_log(&op_log);
		goto END;
	}
	else
	{
		USER_MANEGE_DEBUG_PRINT("login failed");
		status_code = Created;
		strcpy(op_log.op_status, "failed");
		add_one_op_log(&op_log);
		p_reason = "login failed";
	}

	END:
	if(p_root != NULL)
	{
		cJSON_Delete(p_root);
	}

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		USER_MANEGE_DEBUG_PRINT("action is not right");
		return;
	}
	cJSON_AddNumberToObject(p_resp_root,"code", status_code);
	cJSON_AddStringToObject(p_resp_root,"userRole", user_role);
	cJSON_AddStringToObject(p_resp_root,"devType", "CSU");
	cJSON_AddNumberToObject(p_resp_root,"cmuCount", MAX_SLAVE_COUNT);
	cJSON_AddStringToObject(p_resp_root,"msg", p_reason);

	p = cJSON_PrintUnformatted(p_resp_root);
	strcpy(response, p);

	cJSON_Delete(p_resp_root);
	free(p);
	
	http_back(p_nc, response);
}


/**
 * @brief 用户管理模块初始化
 * @return void
 */
void web_user_manage_module_init(void)
{
	if(!web_func_attach("/userLogin", TRANS_UNNEED, do_login))  //不用将登录信息传递到CMU，cookie不带language字段
	{
		USER_MANEGE_DEBUG_PRINT("[/userLogin] attach failed");
	}
	if(!web_func_attach("/system/getUserInfo", TRANS_UNNEED, get_user_info))
	{
		USER_MANEGE_DEBUG_PRINT("[/system/getUserInfo] attach failed");
	}
	if(!web_func_attach("/system/deleteUser", TRANS_NEED, delete_users))
	{
		USER_MANEGE_DEBUG_PRINT("[/system/deleteUser] attach failed");
	}
	if(!web_func_attach("/system/addUser", TRANS_NEED, add_one_user))
	{
		USER_MANEGE_DEBUG_PRINT("[/system/addUser] attach failed");
	}
	if(!web_func_attach("/system/resetPwd", TRANS_NEED, reset_password))
	{
		USER_MANEGE_DEBUG_PRINT("[/system/resetPwd] attach failed");
	}
	if(!web_func_attach("/system/modifyUser", TRANS_NEED, edit_user_info))
	{
		USER_MANEGE_DEBUG_PRINT("[/system/modifyUser] attach failed");
	}
}
