#include "csu_cfg_store.h"
#include "sdk/sdk_fs.h"
#include "sofar_errors.h"
#include "cJSON.h"
#include "common.h"
#include "sdk_shm.h"
#include "operation_log.h"
#include "app_common.h"
#include "web_broker.h"
#include "sys_manage.h"
#include "app_common.h"
#include "sdk_public.h"
#include "sofar_type.h"
#include <unistd.h>
#include <stdio.h>
#include "libghttp.h"
#include "app_common.h"
#include "csu_comb_type.h"
#include "web_data_trans2slave.h"

static bool s_cap_test_mode  = SF_FALSE;

/**
 * @brief    请求导出MCU2日志
 * @param	 [in] *p_nc 连接信息
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void get_mcu2faultlog(struct mg_connection *p_nc,struct http_message *p_msg)
{

	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	uint8_t response[256];
	uint8_t *p_action = NULL;
	uint8_t *p = NULL;
	uint8_t request_body[64] = {0};

	internal_shared_data_t *shared_data = sdk_shm_internal_shared_data_get();

	memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if (p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"getmcu2log"))
	{
		SYS_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	cJSON_Delete(p_request);

	shared_data->mcu2_fault_recorder.progress = 0;
	shared_data->mcu2_fault_recorder.flag = 1;


	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("create json obj failed");
		build_empty_response(response,Non_Authoriative_Information,"create json obj failed");
		http_back(p_nc,response);
		return;
	}

	cJSON_AddNumberToObject(p_resp_root,"code",OK);
	cJSON_AddStringToObject(p_resp_root,"msg","successful");

	p = cJSON_PrintUnformatted(p_resp_root);

	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);

}


/**
 * @brief    MCU2日志进度
 * @param	 [in] *p_nc 连接信息
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void get_mcu2faultlog_Progres(struct mg_connection *p_nc,struct http_message *p_msg)
{

	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	uint8_t response[256];
	uint8_t *p_action = NULL;
	uint8_t *p = NULL;
	uint8_t request_body[64] = {0};

	internal_shared_data_t *shared_data = sdk_shm_internal_shared_data_get();

	memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if (p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"getmcu2logProgress"))
	{
		SYS_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	cJSON_Delete(p_request);


	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("create json obj failed");
		build_empty_response(response,Non_Authoriative_Information,"create json obj failed");
		http_back(p_nc,response);
		return;
	}
	if (shared_data->mcu2_fault_recorder.progress >= 0)
	{
		cJSON_AddNumberToObject(p_resp_root,"code",OK);
		cJSON_AddNumberToObject(p_resp_root,"progress",shared_data->mcu2_fault_recorder.progress);
		cJSON_AddStringToObject(p_resp_root,"msg","successful");

	}else{
		cJSON_AddNumberToObject(p_resp_root,"code",300);
		cJSON_AddNumberToObject(p_resp_root,"progress",-1);
		cJSON_AddStringToObject(p_resp_root,"msg","fail");

	}

	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);

}

/**
 * @brief    MCU2日志下载请求
 * @param	 [in] *p_nc 连接信息
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void export_mcu2faultlog(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	uint8_t response[256] = {0};
	uint8_t *p_action = NULL;
	uint8_t *p = NULL;
    uint8_t slave_index = 0;
    char dev_ip[16] = {0};
    char url[256] = {0};
    char file_name[256] = {0};
	uint8_t request_body[128] = {0};
    int ret = 0;

	memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	if(NULL == cJSON_GetObjectItem(p_request,"action"))
	{
		 SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is NULL");
		 build_empty_response(response,Non_Authoriative_Information,"action is NULL");
		 http_back(p_nc,response);
		 cJSON_Delete(p_request);
		 return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"exportmcu2log"))
	{
		 SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is not right.");
		 build_empty_response(response,Non_Authoriative_Information,"action is not right");
		 http_back(p_nc,response);
		 cJSON_Delete(p_request);
		 return;
	}
    slave_index = cJSON_GetObjectItem(p_request, "slaveIndex")->valueint;
	cJSON_Delete(p_request);

    if((slave_index != 0) && (CSU_ROLE_MASTER == csu_role_get()))
    {
        //获取从机IP
        if(!get_slave_ip(slave_index, dev_ip))
        {
            build_empty_response(response, Accepted, "parse request failed.");
            http_back(p_nc, response);
            return;
        }
        //下载文件
        //打包URL
        memset(url, 0, sizeof(url));
        sprintf(url, "%s%s/%s", "http://", dev_ip, "download/mcu2log");
        //执行文件下载
        // 检测保存路径是否存在
        ret = sdk_fs_access((int8_t *)"/opt/data/recorder/", FS_S_IRWXO);
        if (ret < 0)
        {
            if(sdk_fs_mkdir("/opt/data/recorder/", FS_S_IRWXU|FS_S_IRWXG|FS_S_IRWXO) < 0)
            {
                build_empty_response(response, Accepted, "parse request failed.");
                http_back(p_nc, response);
                return;
            }
        }
        snprintf(file_name, sizeof(file_name), "%s%s", "/opt/data/recorder/", "mcu2_fault_recorder");
        ret = http_net_file_dowaload(url, "/download/mcu2log", file_name);
        if(!ret)
        {
            SYS_MANEGE_DEBUG_PRINT("file download error");
            build_empty_response(response, Accepted, "file download failed.");
            http_back(p_nc, response);
            return;
        }
    }

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"create json obj failed.");
		return ;
	}

	cJSON_AddNumberToObject(p_resp_root,"code",OK);
	cJSON_AddStringToObject(p_resp_root,"url","download/mcu2log");
	cJSON_AddStringToObject(p_resp_root,"msg","successful");

	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);
	return;
}


/**
 * @brief    请求导出MCU2日志
 * @param	 [in] *p_nc 连接信息
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void get_mcu2optlog(struct mg_connection *p_nc,struct http_message *p_msg)
{

	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	uint8_t response[256];
	uint8_t *p_action = NULL;
	uint8_t *p = NULL;
	uint8_t request_body[64] = {0};
	int32_t ret;

	internal_shared_data_t *shared_data = sdk_shm_internal_shared_data_get();

	memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if (p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"getmcu2optlog"))
	{
		SYS_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	cJSON_Delete(p_request);

	shared_data->mcu2_opt_recorder.progress = 0;
	shared_data->mcu2_opt_recorder.flag = 1;


	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("create json obj failed");
		build_empty_response(response,Non_Authoriative_Information,"create json obj failed");
		http_back(p_nc,response);
		return;
	}

	cJSON_AddNumberToObject(p_resp_root,"code",OK);
	cJSON_AddStringToObject(p_resp_root,"msg","successful");

	p = cJSON_PrintUnformatted(p_resp_root);

	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);

}



/**
 * @brief    MCU2日志进度
 * @param	 [in] *p_nc 连接信息
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void get_mcu2optlog_Progres(struct mg_connection *p_nc,struct http_message *p_msg)
{

	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	uint8_t response[256];
	uint8_t *p_action = NULL;
	uint8_t *p = NULL;
	uint8_t i;
	uint8_t request_body[64] = {0};

	internal_shared_data_t *shared_data = sdk_shm_internal_shared_data_get();

	memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if (p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"getmcu2optlogProgress"))
	{
		SYS_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
	cJSON_Delete(p_request);

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("create json obj failed");
		build_empty_response(response,Non_Authoriative_Information,"create json obj failed");
		http_back(p_nc,response);
		return;
	}
	if (shared_data->mcu2_opt_recorder.progress >= 0)
	{
		cJSON_AddNumberToObject(p_resp_root,"code",OK);
		cJSON_AddNumberToObject(p_resp_root,"progress",shared_data->mcu2_opt_recorder.progress);
		cJSON_AddStringToObject(p_resp_root,"msg","successful");

	}else{
		cJSON_AddNumberToObject(p_resp_root,"code",300);
		cJSON_AddNumberToObject(p_resp_root,"progress",-1);
		cJSON_AddStringToObject(p_resp_root,"msg","fail");

	}

	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);

}

/**
 * @brief    MCU2日志下载请求
 * @param	 [in] *p_nc 连接信息
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void export_mcu2optlog(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	uint8_t response[256] = {0};
	uint8_t *p_action = NULL;
	uint8_t *p = NULL;
    uint8_t slave_index = 0;
    char dev_ip[16] = {0};
    char url[256] = {0};
    char file_name[256] = {0};
	uint8_t request_body[128] = {0};
    int ret = 0;

	memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	if(NULL == cJSON_GetObjectItem(p_request,"action"))
	{
		 SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is NULL");
		 build_empty_response(response,Non_Authoriative_Information,"action is NULL");
		 http_back(p_nc,response);
		 cJSON_Delete(p_request);
		 return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"exportmcu2optlog"))
	{
		 SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is not right.");
		 build_empty_response(response,Non_Authoriative_Information,"action is not right");
		 http_back(p_nc,response);
		 cJSON_Delete(p_request);
		 return;
	}
    slave_index = cJSON_GetObjectItem(p_request, "slaveIndex")->valueint;
	cJSON_Delete(p_request);

    if((slave_index != 0) && (CSU_ROLE_MASTER == csu_role_get()))
    {
        //获取从机IP
        if(!get_slave_ip(slave_index, dev_ip))
        {
            build_empty_response(response, Accepted, "parse request failed.");
            http_back(p_nc, response);
            return;
        }
        //下载文件
        //打包URL
        memset(url, 0, sizeof(url));
        sprintf(url, "%s%s/%s", "http://", dev_ip, "download/mcu2optlog");
        //执行文件下载
        // 检测保存路径是否存在
        ret = sdk_fs_access((int8_t *)"/opt/data/recorder/", FS_S_IRWXO);
        if (ret < 0)
        {
            if(sdk_fs_mkdir("/opt/data/recorder/", FS_S_IRWXU|FS_S_IRWXG|FS_S_IRWXO) < 0)
            {
                build_empty_response(response, Accepted, "parse request failed.");
                http_back(p_nc, response);
                return;
            }
        }
        snprintf(file_name, sizeof(file_name), "%s%s", "/opt/data/recorder/", "mcu2_opt_recorder");
        ret = http_net_file_dowaload(url, "/download/mcu2optlog", file_name);
        if(!ret)
        {
            SYS_MANEGE_DEBUG_PRINT("file download error");
            build_empty_response(response, Accepted, "file download failed.");
            http_back(p_nc, response);
            return;
        }
    }

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"create json obj failed.");
		return ;
	}

	cJSON_AddNumberToObject(p_resp_root,"code",OK);
	cJSON_AddStringToObject(p_resp_root,"url","download/mcu2optlog");
	cJSON_AddStringToObject(p_resp_root,"msg","successful");

	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	 http_back(p_nc,p);
	 free(p);
	return;
}

/**
 * @brief    请求导出MCU2日志
 * @param	 [in] *p_nc 连接信息
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void get_mcu2debuglog(struct mg_connection *p_nc,struct http_message *p_msg)
{

	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	uint8_t response[256];
	uint8_t *p_action = NULL;
	uint8_t *p = NULL;
	uint8_t request_body[64] = {0};
	int32_t ret;

	internal_shared_data_t *shared_data = sdk_shm_internal_shared_data_get();

	memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if (p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"getmcu2debuglog"))
	{
		SYS_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	cJSON_Delete(p_request);

	shared_data->mcu2_debug_recorder.progress = 0;
	shared_data->mcu2_debug_recorder.flag = 1;


	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("create json obj failed");
		build_empty_response(response,Non_Authoriative_Information,"create json obj failed");
		http_back(p_nc,response);
		return;
	}

	cJSON_AddNumberToObject(p_resp_root,"code",OK);
	cJSON_AddStringToObject(p_resp_root,"msg","successful");

	p = cJSON_PrintUnformatted(p_resp_root);

	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);

}



/**
 * @brief    MCU2日志进度
 * @param	 [in] *p_nc 连接信息
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void get_mcu2debuglog_Progres(struct mg_connection *p_nc,struct http_message *p_msg)
{

	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	uint8_t response[256];
	uint8_t *p_action = NULL;
	uint8_t *p = NULL;
	uint8_t i;
	uint8_t request_body[64] = {0};

	internal_shared_data_t *shared_data = sdk_shm_internal_shared_data_get();

	memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if (p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"getmcu2debuglogProgress"))
	{
		SYS_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
	cJSON_Delete(p_request);

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("create json obj failed");
		build_empty_response(response,Non_Authoriative_Information,"create json obj failed");
		http_back(p_nc,response);
		return;
	}
	if (shared_data->mcu2_debug_recorder.progress >= 0)
	{
		cJSON_AddNumberToObject(p_resp_root,"code",OK);
		cJSON_AddNumberToObject(p_resp_root,"progress",shared_data->mcu2_debug_recorder.progress);
		cJSON_AddStringToObject(p_resp_root,"msg","successful");

	}else{
		cJSON_AddNumberToObject(p_resp_root,"code",300);
		cJSON_AddNumberToObject(p_resp_root,"progress",-1);
		cJSON_AddStringToObject(p_resp_root,"msg","fail");

	}

	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);

}

/**
 * @brief    MCU2日志下载请求
 * @param	 [in] *p_nc 连接信息
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void export_mcu2debuglog(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	uint8_t response[256] = {0};
	uint8_t *p_action = NULL;
	uint8_t *p = NULL;
    uint8_t slave_index = 0;
    char dev_ip[16] = {0};
    char url[256] = {0};
    char file_name[256] = {0};
	uint8_t request_body[128] = {0};
    int ret = 0;

	memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	if(NULL == cJSON_GetObjectItem(p_request,"action"))
	{
		 SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is NULL");
		 build_empty_response(response,Non_Authoriative_Information,"action is NULL");
		 http_back(p_nc,response);
		 cJSON_Delete(p_request);
		 return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"exportmcu2debuglog"))
	{
		 SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is not right.");
		 build_empty_response(response,Non_Authoriative_Information,"action is not right");
		 http_back(p_nc,response);
		 cJSON_Delete(p_request);
		 return;
	}
    slave_index = cJSON_GetObjectItem(p_request, "slaveIndex")->valueint;
	cJSON_Delete(p_request);

    if((slave_index != 0) && (CSU_ROLE_MASTER == csu_role_get()))
    {
        //获取从机IP
        if(!get_slave_ip(slave_index, dev_ip))
        {
            build_empty_response(response, Accepted, "parse request failed.");
            http_back(p_nc, response);
            return;
        }
        //下载文件
        //打包URL
        memset(url, 0, sizeof(url));
        sprintf(url, "%s%s/%s", "http://", dev_ip, "download/mcu2debuglog");
        //执行文件下载
        // 检测保存路径是否存在
        ret = sdk_fs_access((int8_t *)"/opt/data/recorder/", FS_S_IRWXO);
        if (ret < 0)
        {
            if(sdk_fs_mkdir("/opt/data/recorder/", FS_S_IRWXU|FS_S_IRWXG|FS_S_IRWXO) < 0)
            {
                build_empty_response(response, Accepted, "parse request failed.");
                http_back(p_nc, response);
                return;
            }
        }
        snprintf(file_name, sizeof(file_name), "%s%s", "/opt/data/recorder/", "mcu2_debug_recorder");
        ret = http_net_file_dowaload(url, "/download/mcu2debuglog", file_name);
        if(!ret)
        {
            SYS_MANEGE_DEBUG_PRINT("file download error");
            build_empty_response(response, Accepted, "file download failed.");
            http_back(p_nc, response);
            return;
        }
    }

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"create json obj failed.");
		return ;
	}

	cJSON_AddNumberToObject(p_resp_root,"code",OK);
	cJSON_AddStringToObject(p_resp_root,"url","download/mcu2debuglog");
	cJSON_AddStringToObject(p_resp_root,"msg","successful");

	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	 http_back(p_nc,p);
	 free(p);
	return;
}
/**
 * @brief    获取RS485使能
 * @param         [in] *p_nc 连接信息
 * @param         [in] *p_msg  http请求信息
 * @return
 */
static void get_rs485_enable(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	cJSON *p_resp_item = NULL;
	uint8_t response[256] = {0};
	uint8_t *p_action = NULL;
	uint8_t *p = NULL;
	uint8_t request_body[128] = {0};
	common_data_t *shm = NULL;

	shm = sdk_shm_get();
	constant_parameter_data_t *p_para_data = &shm->constant_parameter_data;

	memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	if(NULL == cJSON_GetObjectItem(p_request,"action"))
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is NULL");
		build_empty_response(response,Non_Authoriative_Information,"action is NULL");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"rs485InfoGet"))
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	cJSON_Delete(p_request);


	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"create json obj failed.");
		return;
	}

	cJSON_AddNumberToObject(p_resp_root,"code",OK);
	
	cJSON_AddNumberToObject(p_resp_root,"antiBackFlowMeterState",p_para_data->system_param.cabinet_param.rs485_device_enable.bit.backflow_meter);
	cJSON_AddNumberToObject(p_resp_root,"meteringMeterState",p_para_data->system_param.cabinet_param.rs485_device_enable.bit.metering_meter);
	cJSON_AddNumberToObject(p_resp_root,"microComputerDeviceState",p_para_data->system_param.cabinet_param.rs485_device_enable.bit.micro_computer);
	cJSON_AddNumberToObject(p_resp_root,"measureControlState",p_para_data->system_param.cabinet_param.rs485_device_enable.bit.measure_control);
	cJSON_AddNumberToObject(p_resp_root,"dehumidifierState",p_para_data->system_param.cabinet_param.rs485_device_enable.bit.dehumidifier);
    cJSON_AddNumberToObject(p_resp_root,"photovoltaicMeterState",p_para_data->system_param.cabinet_param.rs485_device_enable.bit.photovoltaic_meter);

	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);
	return;
}


 /**
 * @brief    设置RS485使能
 * @param         [in] *p_nc 连接信息
 * @param         [in] *p_msg  http请求信息
 * @return
 */
static void set_rs485_enable(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	uint8_t response[256] = {0};
	uint8_t *p_action = NULL;
	uint8_t valueint;
	int32_t ret = 0;
	uint8_t *p = NULL;
	uint8_t request_body[128] = {0};
    uint8_t cur_user[32] = {0};
	operation_log_t op_log;
	web_control_info_t *sdk_shm_web_data = sdk_shm_web_control_data_get();
    constant_parameter_data_t *p_constant_param = sdk_shm_constant_parameter_data_get();

	memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	if(NULL == cJSON_GetObjectItem(p_request,"action"))
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is NULL");
		build_empty_response(response,Non_Authoriative_Information,"action is NULL");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"rs485InfoSet"))
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);

	sdk_shm_web_data->cabinet_param_data.rs485_device_enable.bit.backflow_meter = cJSON_GetObjectItem(p_request,"antiBackFlowMeterState")->valueint;
	if(sdk_shm_web_data->cabinet_param_data.rs485_device_enable.bit.backflow_meter != p_constant_param->cabinet_param_data.rs485_device_enable.bit.backflow_meter)
    {
        strcpy(op_log.op_type,"设置防逆流电表使能");
        op_log.op_param1 =	p_constant_param->cabinet_param_data.rs485_device_enable.bit.backflow_meter;
        op_log.op_param2 = sdk_shm_web_data->cabinet_param_data.rs485_device_enable.bit.backflow_meter;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
	sdk_shm_web_data->cabinet_param_data.rs485_device_enable.bit.metering_meter = cJSON_GetObjectItem(p_request,"meteringMeterState")->valueint;
	if(sdk_shm_web_data->cabinet_param_data.rs485_device_enable.bit.metering_meter != p_constant_param->cabinet_param_data.rs485_device_enable.bit.metering_meter)
    {
        strcpy(op_log.op_type,"设置计量电表使能");
        op_log.op_param1 =	p_constant_param->cabinet_param_data.rs485_device_enable.bit.metering_meter;
        op_log.op_param2 = sdk_shm_web_data->cabinet_param_data.rs485_device_enable.bit.metering_meter;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
	sdk_shm_web_data->cabinet_param_data.rs485_device_enable.bit.micro_computer = cJSON_GetObjectItem(p_request,"microComputerDeviceState")->valueint;
	if(sdk_shm_web_data->cabinet_param_data.rs485_device_enable.bit.micro_computer != p_constant_param->cabinet_param_data.rs485_device_enable.bit.micro_computer)
    {
        strcpy(op_log.op_type,"设置微机装置使能");
        op_log.op_param1 =	p_constant_param->cabinet_param_data.rs485_device_enable.bit.micro_computer;
        op_log.op_param2 = sdk_shm_web_data->cabinet_param_data.rs485_device_enable.bit.micro_computer;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
	sdk_shm_web_data->cabinet_param_data.rs485_device_enable.bit.measure_control = cJSON_GetObjectItem(p_request,"measureControlState")->valueint;
	if(sdk_shm_web_data->cabinet_param_data.rs485_device_enable.bit.measure_control != p_constant_param->cabinet_param_data.rs485_device_enable.bit.measure_control)
    {
        strcpy(op_log.op_type,"设置测控装置使能");
        op_log.op_param1 =	p_constant_param->cabinet_param_data.rs485_device_enable.bit.measure_control;
        op_log.op_param2 = sdk_shm_web_data->cabinet_param_data.rs485_device_enable.bit.measure_control;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
	sdk_shm_web_data->cabinet_param_data.rs485_device_enable.bit.dehumidifier = cJSON_GetObjectItem(p_request,"dehumidifierState")->valueint;
	if(sdk_shm_web_data->cabinet_param_data.rs485_device_enable.bit.dehumidifier != p_constant_param->cabinet_param_data.rs485_device_enable.bit.dehumidifier)
    {
        strcpy(op_log.op_type,"设置除湿器使能");
        op_log.op_param1 =	p_constant_param->cabinet_param_data.rs485_device_enable.bit.dehumidifier;
        op_log.op_param2 = sdk_shm_web_data->cabinet_param_data.rs485_device_enable.bit.dehumidifier;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
	sdk_shm_web_data->cabinet_param_data.rs485_device_enable.bit.photovoltaic_meter = cJSON_GetObjectItem(p_request,"photovoltaicMeterState")->valueint;
	if(sdk_shm_web_data->cabinet_param_data.rs485_device_enable.bit.photovoltaic_meter != p_constant_param->cabinet_param_data.rs485_device_enable.bit.photovoltaic_meter)
    {
        strcpy(op_log.op_type,"设置光伏电表使能");
        op_log.op_param1 =	p_constant_param->cabinet_param_data.rs485_device_enable.bit.photovoltaic_meter;
        op_log.op_param2 = sdk_shm_web_data->cabinet_param_data.rs485_device_enable.bit.photovoltaic_meter;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }

	BIT_SET(sdk_shm_web_data->cabinet_param_update_flag, 2);
	cJSON_Delete(p_request);

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"create json obj failed.");
		return ;
	}


	cJSON_AddNumberToObject(p_resp_root,"code",OK);
	cJSON_AddStringToObject(p_resp_root,"msg","successful");
	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);
	return;
}


/**
 * @brief    设置储能柜（带PCS模块）数量
 * @param         [in] *p_nc 连接信息
 * @param         [in] *p_msg  http请求信息
 * @return
 */
static void set_pcs_module_nums(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	uint8_t response[256] = {0};
	uint8_t *p_action = NULL;
	uint8_t valueint;
	uint8_t *p = NULL;
	uint8_t request_body[128] = {0};
    uint8_t cur_user[32] = {0};
	operation_log_t op_log;

	web_control_info_t *sdk_shm_web_data = sdk_shm_web_control_data_get();
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get();

	memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	if(NULL == cJSON_GetObjectItem(p_request,"action"))
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is NULL");
		build_empty_response(response,Non_Authoriative_Information,"action is NULL");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"setPcsModuleNums"))
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	valueint = cJSON_GetObjectItem(p_request,"pcsModuleNums")->valueint;
	sdk_shm_web_data->cabinet_param_data.energy_storage_nums = valueint;
	BIT_SET(sdk_shm_web_data->cabinet_param_update_flag, 3);
	cJSON_Delete(p_request);

	init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"设置储能柜数量");
    op_log.op_param1 =	p_para_data->cabinet_param_data.energy_storage_nums;
	op_log.op_param2 = sdk_shm_web_data->cabinet_param_data.energy_storage_nums;
    strcpy(op_log.op_status,"success");
    add_one_op_log(&op_log);

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"create json obj failed.");
		return ;
	}


	cJSON_AddNumberToObject(p_resp_root,"code",OK);
	cJSON_AddStringToObject(p_resp_root,"msg","successful");
	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);
	return;
}

/**
 * @brief    获取储能柜（带PCS模块）数量
 * @param         [in] *p_nc 连接信息
 * @param         [in] *p_msg  http请求信息
 * @return
 */
static void get_pcs_module_nums(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	cJSON *p_resp_item = NULL;
	uint8_t response[256] = {0};
	uint8_t *p_action = NULL;
	uint8_t *p = NULL;
	uint8_t request_body[128] = {0};
	common_data_t *shm = NULL;

	shm = sdk_shm_get();
	constant_parameter_data_t *p_para_data = &shm->constant_parameter_data;

	memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	if(NULL == cJSON_GetObjectItem(p_request,"action"))
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is NULL");
		build_empty_response(response,Non_Authoriative_Information,"action is NULL");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getPcsModuleNums"))
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
	cJSON_Delete(p_request);

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"create json obj failed.");
		return;
	}

	cJSON_AddNumberToObject(p_resp_root,"code",OK);
	cJSON_AddNumberToObject(p_resp_root,"pcsModuleNums",p_para_data->system_param.cabinet_param.energy_storage_nums);
	cJSON_AddStringToObject(p_resp_root,"msg","successful");
	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);
	return;
}

/**
 * @brief    设置CSU应用场景
 * @param         [in] *p_nc 连接信息
 * @param         [in] *p_msg  http请求信息
 * @return
 */
static void set_csu_scenario(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	uint8_t response[256] = {0};
	uint8_t *p_action = NULL;
	uint8_t valueint;
	uint8_t *p = NULL;
	uint8_t request_body[128] = {0};
    uint8_t cur_user[32] = {0};
	operation_log_t op_log;

	web_control_info_t *sdk_shm_web_data = sdk_shm_web_control_data_get();
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get();

	memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	if(NULL == cJSON_GetObjectItem(p_request,"action"))
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is NULL");
		build_empty_response(response,Non_Authoriative_Information,"action is NULL");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"setCsuScenario"))
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	valueint = cJSON_GetObjectItem(p_request,"csuScenario")->valueint;
    
	sdk_shm_web_data->cabinet_param_data.scenario_setting = valueint;
    if ( sdk_shm_web_data->cabinet_param_data.scenario_setting == 3 )
    {
        /* 单汇流柜场景 */
        cJSON *p_masterIp_js = cJSON_GetObjectItem( p_request, "masterIP" );
        if ( p_masterIp_js != NULL )
        {
            /* 并柜功能测试 */
            int32_t ip[4];
            sscanf( p_masterIp_js->valuestring, "%d.%d.%d.%d", &ip[0], &ip[1], &ip[2], &ip[3] );
            sdk_shm_constant_parameter_data_get()->csu_comb_save_setting.junct.con_master_ip[0] = (uint8_t)ip[0];
            sdk_shm_constant_parameter_data_get()->csu_comb_save_setting.junct.con_master_ip[1] = (uint8_t)ip[1];
            sdk_shm_constant_parameter_data_get()->csu_comb_save_setting.junct.con_master_ip[2] = (uint8_t)ip[2];
            sdk_shm_constant_parameter_data_get()->csu_comb_save_setting.junct.con_master_ip[3] = (uint8_t)ip[3];

            BIT_SET( sdk_shm_web_control_data_get()->csu_comb_web_set_flag, 0 );
        }
    }

	BIT_SET(sdk_shm_web_data->cabinet_param_update_flag, 4);
	cJSON_Delete(p_request);

	init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"设置CSU应用场景");
    op_log.op_param1 =	p_para_data->system_param.cabinet_param.scenario_setting;
	op_log.op_param2 = sdk_shm_web_data->cabinet_param_data.scenario_setting;
    strcpy(op_log.op_status,"success");
    add_one_op_log(&op_log);

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"create json obj failed.");
		return ;
	}


	cJSON_AddNumberToObject(p_resp_root,"code",OK);
	cJSON_AddStringToObject(p_resp_root,"msg","successful");
	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);
	return;
}

/**
 * @brief    获取CSU应用场景
 * @param         [in] *p_nc 连接信息
 * @param         [in] *p_msg  http请求信息
 * @return
 */
static void get_csu_scenario(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	cJSON *p_resp_item = NULL;
	uint8_t response[256] = {0};
	uint8_t *p_action = NULL;
	uint8_t *p = NULL;
	uint8_t request_body[128] = {0};
	common_data_t *shm = NULL;

	shm = sdk_shm_get();
	constant_parameter_data_t *p_para_data = &shm->constant_parameter_data;

	memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	if(NULL == cJSON_GetObjectItem(p_request,"action"))
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is NULL");
		build_empty_response(response,Non_Authoriative_Information,"action is NULL");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getCsuScenario"))
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
	cJSON_Delete(p_request);

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"create json obj failed.");
		return;
	}

    char ip_str[20];

    uint8_t *p_ip = sdk_shm_constant_parameter_data_get()->csu_comb_save_setting.junct.con_master_ip;
     sprintf( ip_str , "%d.%d.%d.%d", p_ip[0], p_ip[1], p_ip[2], p_ip[3] );
	cJSON_AddStringToObject(p_resp_root,"masterIP", ip_str);

	cJSON_AddNumberToObject(p_resp_root,"code",OK);
	cJSON_AddNumberToObject(p_resp_root,"csuScenario",p_para_data->system_param.cabinet_param.scenario_setting);
	cJSON_AddStringToObject(p_resp_root,"msg","successful");
	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);
	return;
}


/**
 * @brief   设置容测模式
 * @param   [in] *p_nc 连接信息
 * @param   [in] *p_msg  http请求信息
 * @return
 */
static void set_ft_cap_test_mode(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	uint8_t response[256] = {0};
	uint8_t *p_action = NULL;
	uint8_t valueint;
	uint8_t *p = NULL;
	uint8_t request_body[128] = {0};
	web_control_info_t *sdk_shm_web_data = sdk_shm_web_control_data_get();

	memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	if(NULL == cJSON_GetObjectItem(p_request,"action"))
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is NULL");
		build_empty_response(response,Non_Authoriative_Information,"action is NULL");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"setFactoryCapacityTest"))
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	valueint = cJSON_GetObjectItem(p_request,"mode")->valueint;
	sdk_shm_web_data->ft_cap_test = valueint;
	BIT_SET(sdk_shm_web_data->cabinet_param_update_flag, 5);
	cJSON_Delete(p_request);

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"create json obj failed.");
		return ;
	}

	cJSON_AddNumberToObject(p_resp_root,"code",OK);
	cJSON_AddStringToObject(p_resp_root,"msg","successful");
	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);
	return;
}

void *get_cmu_cap_test_task( void *arg )
{
	uint8_t ret = 0;
    uint8_t url[128] = {0};
    uint8_t response[1024];
    uint16_t sys_status = 0;
    cJSON *p_response = NULL;
	uint8_t dev_num = 1;
	uint8_t uri[] = {"/debugManager/getFactoryCapacityTest"};
    uint8_t json_str[] = {"{\"action\":\"getFactoryCapacityTest\"}"}; 
	static uint8_t cmu_ip_tbl[MAX_SLAVE_COUNT][MAX_IP_LEN] = {CMU1_IP, CMU2_IP, CMU3_IP, CMU4_IP, CMU5_IP, CMU6_IP};

    while (1)
    {
		for(dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
		{
			// 打包URL
        	sprintf(url, "%s%s%s", "http://", cmu_ip_tbl[dev_num - 1], uri);
			ret = http_net_post(url, json_str, response);
			if(ret != 1)
			{
				continue;
			}
			else
			{
				p_response = cJSON_Parse(response);
                if(p_response != NULL)
                {
                    if(cJSON_GetObjectItem( p_response, "mode" ) != NULL)
                    {
                        if(cJSON_GetObjectItem( p_response, "mode" )->valueint == 1)
                        {
                            s_cap_test_mode = true;
                            cJSON_Delete(p_response);
                            break;
                        }
                        else
                        {
                            cJSON_Delete(p_response);
                        }
                    }
                }
			}
		}

        /* 只要有一个处于容测模式，则整套系统处于容测模式 */
        if ( s_cap_test_mode == true )
        {
            web_control_info_t *sdk_shm_web_data = sdk_shm_web_control_data_get();
            sdk_shm_web_data->ft_cap_test = 1;
            BIT_SET(sdk_shm_web_data->cabinet_param_update_flag, 5);
			pthread_exit(NULL);
        }
        usleep( 1000*1000 );
    }

}

/**
 * @brief        获取容测模式初始化
 * @param        
 * @return       
 * @retval       
 * @retval       
 */
void get_cmu_cap_test_init( void )
{
	pthread_t cap_test_thread;

	if ( pthread_create( &cap_test_thread, NULL , get_cmu_cap_test_task, NULL ) != 0 )
	{
		perror("pthread_create get_cmu_cap_test_task");
        return;
	}
}


/**
 * @brief        往文件中写入小桔四元组信息
 * @param        [out] p_dev_info 指向欲写入的数据地址
 * @return       [int32_t] 执行结果
 * @retval       =0 读取成功
 * @retval       <0 读取失败
 */
int32_t mqtt_dev_info_write(mqtt_dev_info_t *p_dev_info)
{
    int32_t ret = SF_OK;
    fs_t *p_fs;

    if (p_dev_info->validity_flag != DEVICE_INFO_FILE_VALID)
    {
        SYS_MANEGE_DEBUG_PRINT("sn validity flag error!");
        return SF_ERR_PARA;
    }

    p_fs = sdk_fs_open((const int8_t *)PATH_MQTT_DEV_INFO_FILE, FS_OPEN_ALWAYS | FS_WRITE);
    if (p_fs == NULL)
    {
        SYS_MANEGE_DEBUG_PRINT("open file %s failed", PATH_MQTT_DEV_INFO_FILE);
        return SF_ERR_OPEN;
    }

    /* 将位置偏移量移动到文件头 */
    ret = sdk_fs_lseek(p_fs, 0);
    if (ret < 0)
    {
        SYS_MANEGE_DEBUG_PRINT("sdk_fs_lseek error!");
        sdk_fs_close(p_fs);
        return SF_ERR_SEEK;
    }

    ret = sdk_fs_write(p_fs, p_dev_info, sizeof(mqtt_dev_info_t));
    if (ret != sizeof(mqtt_dev_info_t))
    {
        SYS_MANEGE_DEBUG_PRINT("write error!");
        sdk_fs_close(p_fs);
        return SF_ERR_RD;
    }

    sdk_fs_close(p_fs);

    return SF_OK;
}

/**
 * @brief        从文件中读取小桔四元组信息
 * @param        [out] p_sn 指向欲存放读取进来的数据空间
 * @return       [int32_t] 执行结果
 * @retval       =0 读取成功
 * @retval       <0 读取失败
 */
int32_t mqtt_dev_info_read(mqtt_dev_info_t *p_dev_info)
{
    int32_t ret = SF_OK;
    fs_t *p_fs;

    ret = sdk_fs_access((const int8_t *)PATH_MQTT_DEV_INFO_FILE, FS_F_OK);
    if (ret == SF_OK)
    {
        p_fs = sdk_fs_open((const int8_t *)PATH_MQTT_DEV_INFO_FILE, FS_READ);
        if (p_fs == NULL)
        {
            SYS_MANEGE_DEBUG_PRINT("open file %s failed", PATH_MQTT_DEV_INFO_FILE);
            return SF_ERR_OPEN;
        }

        /* 将位置偏移量移动到文件头 */
        ret = sdk_fs_lseek(p_fs, 0);
        if (ret < 0)
        {
            SYS_MANEGE_DEBUG_PRINT("sdk_fs_lseek error!");
            sdk_fs_close(p_fs);
            return SF_ERR_SEEK;
        }

        ret = sdk_fs_read(p_fs, p_dev_info, sizeof(mqtt_dev_info_t));
        if (ret != sizeof(mqtt_dev_info_t))
        {
            SYS_MANEGE_DEBUG_PRINT("read error!");
            sdk_fs_close(p_fs);
            return SF_ERR_RD;
        }

        sdk_fs_close(p_fs);

        if (p_dev_info->validity_flag == DEVICE_INFO_FILE_VALID)
        {
            ret = SF_OK;
        }
        else
        {
            ret = SF_ERR_NDEF;
        }
    }

    return ret;
}


/**
 * @brief  获取MQTT四元组信息
 * @param  [in] *p_nc 连接信息
 * @param  [in] *p_msg  http请求信息
 * @return
 */
static void get_mqtt_dev_info(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	cJSON *p_resp_item = NULL;
	uint8_t response[256] = {0};
	uint8_t *p_action = NULL;
	int32_t ret = 0;
	uint8_t *p = NULL;
	uint8_t request_body[128] = {0};
    mqtt_dev_info_t dev_info = {0};

	memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	if(NULL == cJSON_GetObjectItem(p_request,"action"))
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is NULL");
		build_empty_response(response,Non_Authoriative_Information,"action is NULL");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"devInfoGet"))
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
	cJSON_Delete(p_request);

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"create json obj failed.");
		return;
	}

    ret = mqtt_dev_info_read(&dev_info);
    if(ret != SF_OK)
    {
        SYS_MANEGE_DEBUG_PRINT((int8_t *)"mqtt dev info read error");
        build_empty_response(response,201,"read error");
		http_back(p_nc,response);
        cJSON_Delete(p_resp_root);
        return;
    }

	cJSON_AddNumberToObject(p_resp_root,"code",OK);
	cJSON_AddStringToObject(p_resp_root,"clientID",dev_info.clientID);
	cJSON_AddStringToObject(p_resp_root,"devName",dev_info.dev_name);
	cJSON_AddStringToObject(p_resp_root,"productKey",dev_info.pro_key);
	cJSON_AddStringToObject(p_resp_root,"devSecret",dev_info.dev_secret);
    cJSON_AddStringToObject(p_resp_root,"devSN",dev_info.dev_sn);
    cJSON_AddStringToObject(p_resp_root,"pcsSN",dev_info.pcs_sn);
	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);
	return;
}


/**
 * @brief 设置MQTT四元组信息
 * @param [in] *p_nc 连接信息
 * @param [in] *p_msg  http请求信息
 * @return
 */
static void set_mqtt_dev_info(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_item = NULL;
    cJSON *p_resp_array = NULL;
    uint8_t response[64];  //
    uint8_t *p_action = NULL;
    uint8_t *p_clientID = NULL;
    uint8_t *p_dev_name = NULL;
    uint8_t *p_pro_key = NULL;
    uint8_t *p_dev_secret = NULL;
    uint8_t *p_dev_sn = NULL;
    uint8_t *p_pcs_sn = NULL;
    uint8_t *p_meter2_sn = NULL;
    uint8_t request_body[256] = {0};
    mqtt_dev_info_t dev_info = {0};
    uint8_t cur_user[32] = {0};
	operation_log_t op_log;
    uint16_t array_size = 0;
    uint8_t i = 0;
    int32_t ret;

    memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"devInfoSet"))
	{
		SYS_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    p_clientID = cJSON_GetObjectItem(p_request,"clientID")->valuestring;
    p_dev_name = cJSON_GetObjectItem(p_request,"devName")->valuestring;
    p_pro_key = cJSON_GetObjectItem(p_request,"productKey")->valuestring;
    p_dev_secret = cJSON_GetObjectItem(p_request,"devSecret")->valuestring;
    p_dev_sn = cJSON_GetObjectItem(p_request,"devSN")->valuestring;
    p_pcs_sn = cJSON_GetObjectItem(p_request,"pcsSN")->valuestring;
    p_meter2_sn = cJSON_GetObjectItem(p_request,"meter2SN")->valuestring;
    //对电表3 SN参数进行解析
	if(NULL != cJSON_GetObjectItem(p_request,"meter3SN"))
	{
		p_resp_array = cJSON_GetObjectItem(p_request,"meter3SN");
		array_size = cJSON_GetArraySize(p_resp_array);
		if(array_size == 0)
		{
			SYS_MANEGE_DEBUG_PRINT("array size is 0");
		}
        else
        {
            for(i = 0; i < array_size; i++)
            {
                strcpy(dev_info.meter3_sn[i], cJSON_GetArrayItem(p_resp_array, i)->valuestring);
            }
        }
	}

    //初始化结构体
    strcpy(dev_info.clientID, p_clientID);
    strcpy(dev_info.dev_name, p_dev_name);
    strcpy(dev_info.pro_key, p_pro_key);
    strcpy(dev_info.dev_secret, p_dev_secret);
    strcpy(dev_info.dev_sn, p_dev_sn);
    strcpy(dev_info.pcs_sn, p_pcs_sn);
    strcpy(dev_info.meter2_sn, p_meter2_sn);
    dev_info.validity_flag = DEVICE_INFO_FILE_VALID;

    SYS_MANEGE_DEBUG_PRINT("clientID = %s", dev_info.clientID);
    SYS_MANEGE_DEBUG_PRINT("dev_name = %s", dev_info.dev_name);
    SYS_MANEGE_DEBUG_PRINT("pro_key = %s", dev_info.pro_key);
    SYS_MANEGE_DEBUG_PRINT("dev_secret = %s", dev_info.dev_secret);
    SYS_MANEGE_DEBUG_PRINT("dev_sn = %s", dev_info.dev_sn);
    SYS_MANEGE_DEBUG_PRINT("pcs_sn = %s", dev_info.pcs_sn);
    SYS_MANEGE_DEBUG_PRINT("meter2_sn = %s", dev_info.meter2_sn);
    for(i = 0; i < array_size; i++)
    {
        SYS_MANEGE_DEBUG_PRINT("meter3_sn[%d] = %s", i, dev_info.meter3_sn[i]);
    }

	init_user_basic_info(&op_log);
	// get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,"admin");
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"设置小桔四元组");
    ret = mqtt_dev_info_write(&dev_info);
    if (ret == SF_OK)
    {
        build_empty_response(response,OK,"dev info set successful");
        strcpy(op_log.op_status,"success");
    }
    else
    {
        build_empty_response(response,201,"dev info set failed");
        strcpy(op_log.op_status,"fail");
    }
    add_one_op_log(&op_log);
	http_back(p_nc,response);
    cJSON_Delete(p_request);
}


/**
 * @brief        往文件中写入小桔服务器域名信息
 * @param        [out] p_host_info 指向欲写入的数据地址
 * @return       [int32_t] 执行结果
 * @retval       =0 读取成功
 * @retval       <0 读取失败
 */
int32_t mqtt_server_host_write(mqtt_server_host_t *p_host_info)
{
    int32_t ret = SF_OK;
    fs_t *p_fs;

    if (p_host_info->validity_flag != DEVICE_INFO_FILE_VALID)
    {
        SYS_MANEGE_DEBUG_PRINT("data validity flag error!");
        return SF_ERR_PARA;
    }

    p_fs = sdk_fs_open((const int8_t *)PATH_MQTT_SERVER_HOST_FILE, FS_OPEN_ALWAYS | FS_WRITE);
    if (p_fs == NULL)
    {
        SYS_MANEGE_DEBUG_PRINT("open file %s failed", PATH_MQTT_SERVER_HOST_FILE);
        return SF_ERR_OPEN;
    }

    /* 将位置偏移量移动到文件头 */
    ret = sdk_fs_lseek(p_fs, 0);
    if (ret < 0)
    {
        SYS_MANEGE_DEBUG_PRINT("sdk_fs_lseek error!");
        sdk_fs_close(p_fs);
        return SF_ERR_SEEK;
    }

    ret = sdk_fs_write(p_fs, p_host_info, sizeof(mqtt_server_host_t));
    if (ret != sizeof(mqtt_server_host_t))
    {
        SYS_MANEGE_DEBUG_PRINT("write error!");
        sdk_fs_close(p_fs);
        return SF_ERR_RD;
    }

    sdk_fs_close(p_fs);

    return SF_OK;
}

/**
 * @brief        从文件中读取小桔服务器域名信息
 * @param        [out] p_sn 指向欲存放读取进来的数据空间
 * @return       [int32_t] 执行结果
 * @retval       =0 读取成功
 * @retval       <0 读取失败
 */
int32_t mqtt_server_host_read(mqtt_server_host_t *p_host_info)
{
    int32_t ret = SF_OK;
    fs_t *p_fs;

    ret = sdk_fs_access((const int8_t *)PATH_MQTT_SERVER_HOST_FILE, FS_F_OK);
    if (ret == SF_OK)
    {
        p_fs = sdk_fs_open((const int8_t *)PATH_MQTT_SERVER_HOST_FILE, FS_READ);
        if (p_fs == NULL)
        {
            SYS_MANEGE_DEBUG_PRINT("open file %s failed", PATH_MQTT_SERVER_HOST_FILE);
            return SF_ERR_OPEN;
        }

        /* 将位置偏移量移动到文件头 */
        ret = sdk_fs_lseek(p_fs, 0);
        if (ret < 0)
        {
            SYS_MANEGE_DEBUG_PRINT("sdk_fs_lseek error!");
            sdk_fs_close(p_fs);
            return SF_ERR_SEEK;
        }

        ret = sdk_fs_read(p_fs, p_host_info, sizeof(mqtt_server_host_t));
        if (ret != sizeof(mqtt_server_host_t))
        {
            SYS_MANEGE_DEBUG_PRINT("read error!");
            sdk_fs_close(p_fs);
            return SF_ERR_RD;
        }

        sdk_fs_close(p_fs);

        if (p_host_info->validity_flag == DEVICE_INFO_FILE_VALID)
        {
            ret = SF_OK;
        }
        else
        {
            ret = SF_ERR_NDEF;
        }
    }

    return ret;
}


/**
 * @brief  获取MQTT四元组信息
 * @param  [in] *p_nc 连接信息
 * @param  [in] *p_msg  http请求信息
 * @return
 */
static void get_mqtt_server_host(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	cJSON *p_resp_item = NULL;
	uint8_t response[256] = {0};
	uint8_t *p_action = NULL;
	int32_t ret = 0;
	uint8_t *p = NULL;
	uint8_t request_body[128] = {0};
    mqtt_server_host_t server_host = {0};

	memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	if(NULL == cJSON_GetObjectItem(p_request,"action"))
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is NULL");
		build_empty_response(response,Non_Authoriative_Information,"action is NULL");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"serverHostGet"))
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
	cJSON_Delete(p_request);

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"create json obj failed.");
		return;
	}

    ret = mqtt_server_host_read(&server_host);
    if(ret != SF_OK)
    {
        SYS_MANEGE_DEBUG_PRINT((int8_t *)"mqtt dev info read error");
        build_empty_response(response,201,"read error");
		http_back(p_nc,response);
        return;
    }

	cJSON_AddNumberToObject(p_resp_root,"code",OK);
	cJSON_AddStringToObject(p_resp_root,"serverHost",server_host.host);
	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);
	return;
}


/**
 * @brief 设置MQTT四元组信息
 * @param [in] *p_nc 连接信息
 * @param [in] *p_msg  http请求信息
 * @return
 */
static void set_mqtt_server_host(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_item = NULL;
    uint8_t response[64];  //
    uint8_t *p_action = NULL;
    uint8_t *p_host = NULL;
    uint8_t request_body[256] = {0};
    mqtt_server_host_t server_host = {0};
    uint8_t cur_user[32] = {0};
	operation_log_t op_log;
    int32_t ret;

    memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"serverHostSet"))
	{
		SYS_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    p_host = cJSON_GetObjectItem(p_request,"serverHost")->valuestring;
    SYS_MANEGE_DEBUG_PRINT("p_host = %s", p_host);

    //初始化结构体
    strcpy(server_host.host, p_host);
    server_host.validity_flag = DEVICE_INFO_FILE_VALID;

    SYS_MANEGE_DEBUG_PRINT("host = %s", server_host.host);

    ret = mqtt_server_host_write(&server_host);
    if (ret == SF_OK)
    {
        build_empty_response(response,OK,"server host set successful");
    }
    else
    {
        build_empty_response(response,201,"server host set failed");
    }
	http_back(p_nc,response);
    cJSON_Delete(p_request);
}


/**
 * @brief  16进制字符串转数组
 * @param  [in] *p_str 字符串
 * @param  [out] *p_array  数组
 * @param  [in] size  长度
 * @return
 */
void hex_string_to_array(char *p_str, char *p_array, int size) 
{
    memset(p_array, 0, size);
    for (int i = 0; i < size; i++) 
    {
        sscanf(p_str + i * 2, "%02x", &p_array[i]);
    }
}


/**
 * @brief  设置控制参数
 * @param  [in] *p_nc 连接信息
 * @param  [in] *p_msg  http请求信息
 * @return
 */
static void set_dev_config_param(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_item = NULL;
    uint8_t response[64] = {0};  //
    uint8_t *p_action = NULL;
    uint8_t request_body[2048] = {0};
    uint8_t cur_user[32] = {0};
	operation_log_t op_log;
    int32_t ret;

    web_control_info_t *p_web_data = sdk_shm_web_control_data_get();
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get();
    memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"setConfigParameter"))
	{
		SYS_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);

    //控制模式
    p_web_data->elec_meter_param.control_mode = cJSON_GetObjectItem(p_request,"controlMode")->valueint;
    if(p_web_data->elec_meter_param.control_mode != p_para_data->elec_meter_param.control_mode)
    {
        strcpy(op_log.op_type,"设置控制模式");
        op_log.op_param1 =	p_para_data->elec_meter_param.control_mode;
        op_log.op_param2 = p_web_data->elec_meter_param.control_mode;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    //变压器容量
    p_web_data->elec_meter_param.transformer_capa = cJSON_GetObjectItem(p_request,"Capacity")->valueint * 10;
    if(p_web_data->elec_meter_param.transformer_capa != p_para_data->elec_meter_param.transformer_capa)
    {
        strcpy(op_log.op_type,"设置变压器容量");
        op_log.op_param1 =	p_para_data->elec_meter_param.transformer_capa / 10;
        op_log.op_param2 = p_web_data->elec_meter_param.transformer_capa / 10;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    //设置电表1数量
    p_web_data->elec_meter_param.elec_meter1_cnt = cJSON_GetObjectItem(p_request,"Meter1Quantity")->valueint;
    if(p_web_data->elec_meter_param.elec_meter1_cnt != p_para_data->elec_meter_param.elec_meter1_cnt)
    {
        strcpy(op_log.op_type,"设置电表1数量");
        op_log.op_param1 =	p_para_data->elec_meter_param.elec_meter1_cnt;
        op_log.op_param2 = p_web_data->elec_meter_param.elec_meter1_cnt;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    }
    //设置电表3数量
    p_web_data->elec_meter_param.elec_meter3_cnt = cJSON_GetObjectItem(p_request,"Meter3Quantity")->valueint;
    if(p_web_data->elec_meter_param.elec_meter3_cnt != p_para_data->elec_meter_param.elec_meter3_cnt)
    {
        strcpy(op_log.op_type,"设置电表3数量");
        op_log.op_param1 =	p_para_data->elec_meter_param.elec_meter3_cnt;
        op_log.op_param2 = p_web_data->elec_meter_param.elec_meter3_cnt;
        strcpy(op_log.op_status,"success");
        add_one_op_log(&op_log);
    } 

    BIT_SET(p_web_data->cabinet_param_update_flag, 6);

    build_empty_response(response,OK,"set successful");
	http_back(p_nc,response);

    cJSON_Delete(p_request);
}


/**
 * @brief  读取配置参数
 * @param  [in] *p_nc 连接信息
 * @param  [in] *p_msg  http请求信息
 * @return
 */
static void get_dev_config_param(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	uint8_t response[256] = {0};
	uint8_t *p_action = NULL;
	int32_t ret = 0;
	uint8_t *p = NULL;
	uint8_t request_body[128] = {0};
    uint8_t elec_meter_index = 0;
    uint8_t meter3_addr[20] = {0};
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get();

	memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	if(NULL == cJSON_GetObjectItem(p_request,"action"))
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is NULL");
		build_empty_response(response,Non_Authoriative_Information,"action is NULL");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getConfigParameter"))
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    elec_meter_index = cJSON_GetObjectItem(p_request,"Meter3Number")->valueint;
	cJSON_Delete(p_request);

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"create json obj failed.");
		return;
	}

	cJSON_AddNumberToObject(p_resp_root,"code",OK);
	cJSON_AddNumberToObject(p_resp_root,"controlMode",p_para_data->elec_meter_param.control_mode);
    cJSON_AddNumberToObject(p_resp_root,"Capacity",p_para_data->elec_meter_param.transformer_capa / 10);
    cJSON_AddNumberToObject(p_resp_root,"Meter1Quantity",p_para_data->elec_meter_param.elec_meter1_cnt);
    cJSON_AddNumberToObject(p_resp_root,"Meter3Quantity",p_para_data->elec_meter_param.elec_meter3_cnt);

	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);
	return;
}


/**
 * @brief  设置CSU SN
 * @param  [in] *p_nc 连接信息
 * @param  [in] *p_msg  http请求信息
 * @return
 */
static void set_csu_sn(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_item = NULL;
    uint8_t response[64] = {0};  //
    uint8_t *p_action = NULL;
    uint8_t request_body[256] = {0};
    int32_t ret;
    web_control_info_t *sdk_shm_web_data = sdk_shm_web_control_data_get();

    memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"csuSNSet"))
	{
		SYS_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    strcpy((char *)sdk_shm_web_data->csu_sn, cJSON_GetObjectItem(p_request,"csuSN")->valuestring);
    BIT_SET(sdk_shm_web_data->system_param_flag, 3);
    SYS_MANEGE_DEBUG_PRINT("csu sn = %s", sdk_shm_web_data->csu_sn);
    build_empty_response(response,OK,"set successful");
	http_back(p_nc,response);

    cJSON_Delete(p_request);
}


/**
 * @brief  读取CSU SN
 * @param  [in] *p_nc 连接信息
 * @param  [in] *p_msg  http请求信息
 * @return
 */
static void get_csu_sn(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	uint8_t response[256] = {0};
	uint8_t *p_action = NULL;
	int32_t ret = 0;
	uint8_t *p = NULL;
	uint8_t request_body[128] = {0};
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();

	memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	if(NULL == cJSON_GetObjectItem(p_request,"action"))
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is NULL");
		build_empty_response(response,Non_Authoriative_Information,"action is NULL");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"csuSNGet"))
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
	cJSON_Delete(p_request);

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"create json obj failed.");
		return;
	}

	cJSON_AddNumberToObject(p_resp_root,"code",OK);
    cJSON_AddStringToObject(p_resp_root,"csuSN",(char *)p_telemetry_data->sys_version_telemetry_info.sn_version_number);
	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);
	return;
}


/**
 * @brief  设置光伏电表参数
 * @param  [in] *p_nc 连接信息
 * @param  [in] *p_msg  http请求信息
 * @return
 */
static void set_photovoltaic_meter_cfg(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_item = NULL;
    uint8_t response[64] = {0};  //
    uint8_t *p_action = NULL;
    uint8_t request_body[256] = {0};
    uint8_t cur_user[32] = {0};
	operation_log_t op_log;
    int32_t ret;

    web_control_info_t *sdk_shm_web_data = sdk_shm_web_control_data_get();
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get();
    memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"PhotovoltaicMeterSet"))
	{
		SYS_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    sdk_shm_web_data->photovoltaic_meter_cfg.meter_cnt = cJSON_GetObjectItem(p_request,"MeterQuantity")->valueint;
    sdk_shm_web_data->photovoltaic_meter_cfg.curr_dir = cJSON_GetObjectItem(p_request,"PVMetercurrentDirection")->valueint;

    BIT_SET(sdk_shm_web_data->cabinet_param_update_flag, 11);
    build_empty_response(response,OK,"set successful");
	http_back(p_nc,response);

	init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"设置光伏电表参数");
    strcpy(op_log.op_status,"success");
    add_one_op_log(&op_log);

    cJSON_Delete(p_request);
}


/**
 * @brief  读取光伏电表参数
 * @param  [in] *p_nc 连接信息
 * @param  [in] *p_msg  http请求信息
 * @return
 */
static void get_photovoltaic_meter_cfg(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	cJSON *p_resp_root = NULL;
	uint8_t response[256] = {0};
	uint8_t *p_action = NULL;
	int32_t ret = 0;
	uint8_t *p = NULL;
	uint8_t request_body[128] = {0};
    constant_parameter_data_t *p_const_param = sdk_shm_constant_parameter_data_get();

	memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
	if(p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	if(NULL == cJSON_GetObjectItem(p_request,"action"))
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is NULL");
		build_empty_response(response,Non_Authoriative_Information,"action is NULL");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"PhotovoltaicMeterGet"))
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
	cJSON_Delete(p_request);

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT((int8_t *)"create json obj failed.");
		return;
	}

	cJSON_AddNumberToObject(p_resp_root,"code",OK);
    cJSON_AddNumberToObject(p_resp_root,"MeterQuantity",p_const_param->photovoltaic_meter_cfg.meter_cnt);
    cJSON_AddNumberToObject(p_resp_root,"PVMeterCurrentDirection",p_const_param->photovoltaic_meter_cfg.curr_dir);

	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);
	return;
}

/**
 * @brief  设置CSU并机参数
 * @param  [in] *p_nc 连接信息
 * @param  [in] *p_msg  http请求信息
 * @return
 */
static void csu_comb_param_set(struct mg_connection *p_nc,struct http_message *p_msg)
{
	uint8_t request_body[256] = {0};
    cJSON *p_req_root_js = NULL;
    sf_ret_t ret = SF_OK;

	memcpy( request_body, p_msg->body.p, p_msg->body.len );

    p_req_root_js = cJSON_Parse( request_body );
    if ( p_req_root_js == NULL )    
    {
        ret = SF_ERR_PARA;
        goto __exit;
    }

    cJSON *p_action_js                  = cJSON_GetObjectItem( p_req_root_js, "action" );
    cJSON *p_ParallelCabinetEnable_js   = cJSON_GetObjectItem( p_req_root_js, "ParallelCabinetEnable" );
    cJSON *p_MasterSlaveSetting_js      = cJSON_GetObjectItem( p_req_root_js, "MasterSlaveSetting" );
    cJSON *p_ParallelCabinetNumber_js   = cJSON_GetObjectItem( p_req_root_js, "ParallelCabinetNumber" );
    cJSON *p_Host_IP_js                 = cJSON_GetObjectItem( p_req_root_js, "Host_IP" );
    cJSON *p_csu_eth1_js                = cJSON_GetObjectItem( p_req_root_js, "csu_eth1" );
    cJSON *p_CombinerCabinetEnable_js   = cJSON_GetObjectItem( p_req_root_js, "CombinerCabinetEnable" );
    cJSON *p_SlaveNumber_js             = cJSON_GetObjectItem( p_req_root_js, "SlaveNumber" );

    if (   ( NULL == p_action_js )
        || ( NULL == p_ParallelCabinetEnable_js )
        || ( NULL == p_MasterSlaveSetting_js )
        || ( NULL == p_ParallelCabinetNumber_js )
        || ( NULL == p_Host_IP_js )
        || ( NULL == p_CombinerCabinetEnable_js )
        || ( NULL == p_SlaveNumber_js )
        || ( NULL == p_csu_eth1_js ))
    {
        ret = SF_ERR_PARA;
        goto __exit;
    }

    
	if ( strcmp( p_action_js->valuestring,"ParallelCabinetParamSet" ) != 0 )
    {
        ret = SF_ERR_PARA;
        goto __exit;
    }

    csu_comb_save_setting_t *p_csu_comb_save_setting = &sdk_shm_constant_parameter_data_get()->csu_comb_save_setting;
    p_csu_comb_save_setting->comb_enable            = p_ParallelCabinetEnable_js->valueint ;
    p_csu_comb_save_setting->comb_role              = (p_MasterSlaveSetting_js->valueint == 1)? CSU_ROLE_MASTER : CSU_ROLE_SLAVE;
    p_csu_comb_save_setting->master.comb_num        = p_ParallelCabinetNumber_js->valueint ;
    p_csu_comb_save_setting->slave.local_slave_id   = p_SlaveNumber_js->valueint ;
    sscanf( p_Host_IP_js->valuestring , "%d.%d.%d.%d", 
                                    &p_csu_comb_save_setting->slave.con_master_ip[0], &p_csu_comb_save_setting->slave.con_master_ip[1],
                                    &p_csu_comb_save_setting->slave.con_master_ip[2], &p_csu_comb_save_setting->slave.con_master_ip[3] );
    p_csu_comb_save_setting->junct.enable           = p_CombinerCabinetEnable_js->valueint ;

    if (    p_csu_comb_save_setting->comb_enable == SF_TRUE
        && p_csu_comb_save_setting->comb_role   == CSU_ROLE_SLAVE
        && p_csu_comb_save_setting->master.comb_num < (p_csu_comb_save_setting->slave.local_slave_id + 1))
   {
       /* 设置的并柜数量不符合，内部纠正 */
       p_csu_comb_save_setting->master.comb_num = (p_csu_comb_save_setting->slave.local_slave_id + 1);
   }

    BIT_SET( sdk_shm_web_control_data_get()->csu_comb_web_set_flag, 0);

__exit:
    if ( p_req_root_js  )
    {
        cJSON_Delete( p_req_root_js );
    }

    if ( ret != SF_OK )
    {
		http_back( p_nc, "{\"code\":203,\"msg\":\"failed\"}");
    }else{
		http_back( p_nc, "{\"code\":200,\"msg\":\"successful\"}");
    }
    return;
}


/**
 * @brief  读取CSU并机参数
 * @param  [in] *p_nc 连接信息
 * @param  [in] *p_msg  http请求信息
 * @return
 */
static void csu_comb_param_get(struct mg_connection *p_nc,struct http_message *p_msg)
{
	uint8_t request_body[256] = {0};
    cJSON *p_req_root_js = NULL;
    sf_ret_t ret = SF_OK;

	memcpy( request_body, p_msg->body.p, p_msg->body.len );
    p_req_root_js = cJSON_Parse( request_body );
    if ( p_req_root_js == NULL )    
    {
        ret = SF_ERR_PARA;
        goto __exit;
    }

    cJSON *p_action_js = cJSON_GetObjectItem( p_req_root_js, "action" );
    if ( p_action_js == NULL )
    {
        ret = SF_ERR_PARA;
        goto __exit;
    }

    if ( strcmp( p_action_js->valuestring, "ParallelCabinetParamGet" ) != 0 )
    {
        ret = SF_ERR_PARA;
        goto __exit;
    }

    cJSON *p_rep_root_js = NULL;
    p_rep_root_js = cJSON_CreateObject();
    if ( p_rep_root_js == NULL )
    {
        ret = SF_ERR_NO_OBJECT;
        goto __exit;
    }

    // csu_comb_setting_t *p_csu_comb_setting = &sdk_shm_csu_combine_data_get()->comb_setting;
    web_control_info_t *p_web_control_info = sdk_shm_web_control_data_get();
    csu_comb_save_setting_t *p_csu_comb_save_setting = &sdk_shm_constant_parameter_data_get()->csu_comb_save_setting;
    csu_combine_info_t *p_csu_combine_info = &sdk_shm_get()->csu_combine_data; 
    char ip_str[20] = {0};
    
    cJSON_AddNumberToObject( p_rep_root_js, "code"                  , 200);
    cJSON_AddNumberToObject( p_rep_root_js, "CombinerCabinetEnable" , p_csu_comb_save_setting->junct.enable);
    sprintf( ip_str, "%d.%d.%d.%d",  p_csu_combine_info->junct_info.ip[0], p_csu_combine_info->junct_info.ip[1],
                                     p_csu_combine_info->junct_info.ip[2], p_csu_combine_info->junct_info.ip[3] );
    cJSON_AddStringToObject( p_rep_root_js, "CombinerCabinetIP"     , ip_str );
    cJSON_AddNumberToObject( p_rep_root_js, "ParallelCabinetEnable" , p_csu_comb_save_setting->comb_enable );
    cJSON_AddNumberToObject( p_rep_root_js, "MasterSlaveSetting"    , p_csu_comb_save_setting->comb_role   );
    cJSON_AddNumberToObject( p_rep_root_js, "ParallelCabinetNumber" , p_csu_comb_save_setting->master.comb_num);
    cJSON_AddNumberToObject( p_rep_root_js, "SlaveNumber"           , p_csu_comb_save_setting->slave.local_slave_id);
    sprintf( ip_str, "%d.%d.%d.%d", p_csu_comb_save_setting->slave.con_master_ip[0], p_csu_comb_save_setting->slave.con_master_ip[1], p_csu_comb_save_setting->slave.con_master_ip[2], p_csu_comb_save_setting->slave.con_master_ip[3]);
    cJSON_AddStringToObject( p_rep_root_js, "Host_IP"               , ip_str );
    sprintf( ip_str, "%d.%d.%d.%d",  sdk_shm_get()->csu_combine_data.comb_setting.local_ip[0], sdk_shm_get()->csu_combine_data.comb_setting.local_ip[1], sdk_shm_get()->csu_combine_data.comb_setting.local_ip[2], sdk_shm_get()->csu_combine_data.comb_setting.local_ip[3] );
    cJSON_AddStringToObject( p_rep_root_js, "csu_eth1"              , ip_str );
    cJSON_AddStringToObject( p_rep_root_js, "msg"                   , "successful" );

    char *p_rep_str = NULL;
    p_rep_str = cJSON_PrintUnformatted( p_rep_root_js );
    if ( p_rep_str == NULL )
    {
        ret = SF_ERR_NO_OBJECT;
        goto __exit;
    }
	http_back(p_nc, p_rep_str);

__exit:
    if ( p_req_root_js  )
    {
        cJSON_Delete( p_req_root_js );
    }
    if ( p_rep_root_js  )
    {
        cJSON_Delete( p_rep_root_js );
    }
    if ( p_rep_str == NULL )
    {
        free( p_rep_str );
    }    
    if ( ret != SF_OK )
    {
		http_back( p_nc, "{\"code\":203,\"msg\":\"failed\"}");
    }
    return;
}


/**
 * @brief  保存DRM参数设置
 * @param  [in] power_ratio:功率比例参数
 * @return none
 */
void drmn_cfg_save(int8_t *power_ratio)
{
    cJSON *p_root = NULL;
    char *p_cfg = NULL;
    fs_t *p_fs = NULL;
    int ret = 0;

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        SYS_MANEGE_DEBUG_PRINT("json creat error.");
        return;
    }
    
    cJSON_AddNumberToObject(p_root, "DrmPowerRatio_1" , power_ratio[0]);
    cJSON_AddNumberToObject(p_root, "DrmPowerRatio_2" , power_ratio[1]);
    cJSON_AddNumberToObject(p_root, "DrmPowerRatio_3" , power_ratio[2]);
    cJSON_AddNumberToObject(p_root, "DrmPowerRatio_4" , power_ratio[3]);

    p_cfg = cJSON_PrintUnformatted(p_root);
    if(p_cfg == NULL)
    {
        SYS_MANEGE_DEBUG_PRINT("json print error.");
        cJSON_Delete(p_root);
        return;
    }

    p_fs = sdk_fs_open((const int8_t *)DRMN_POWER_RATIO_CFG, FS_CREATE_ALWAYS | FS_WRITE);
    if(p_fs == NULL)
    {
        SYS_MANEGE_DEBUG_PRINT("file open error.");
        cJSON_Delete(p_root);
        return;
    }
    /* 将位置偏移量移动到文件头 */
    sdk_fs_lseek(p_fs, 0 );
    sdk_fs_write(p_fs, p_cfg, strlen(p_cfg));

    cJSON_Delete(p_root);
    sdk_fs_close(p_fs);
    free(p_cfg);
}

/**
 * @brief 系统管理模块初始化
 * @return void
 */
void web_sys_manage_module_init(void)
{
	if(!web_func_attach("/sysManager/getmcu2log", TRANS_UNNEED, get_mcu2faultlog))
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/getmcu2log] attach failed");
	}
	if(!web_func_attach("/sysManager/getmcu2logProgress", TRANS_UNNEED, get_mcu2faultlog_Progres))
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/getmcu2logProgress] attach failed");
	}
	if(!web_func_attach("/sysManager/exportmcu2log", TRANS_UNNEED, export_mcu2faultlog))
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/exportmcu2log] attach failed");
	}
	if(!web_func_attach("/sysManager/getmcu2optlog", TRANS_UNNEED, get_mcu2optlog))				//生成MUC2操作log
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/getmcu2optlog] attach failed");
	}
	if(!web_func_attach("/sysManager/getmcu2optlogProgress", TRANS_UNNEED, get_mcu2optlog_Progres))	//MUC2操作log进度
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/getmcu2optlogProgress] attach failed");
	}
	if(!web_func_attach("/sysManager/exportmcu2optlog", TRANS_UNNEED, export_mcu2optlog))		//下载MUC2操作log
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/exportmcu2optlog] attach failed");
	}
	if(!web_func_attach("/sysManager/rs485InfoGet", TRANS_UNNEED, get_rs485_enable))			//获取485设备使能状态
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/rs485InfoGet] attach failed");
	}
	if(!web_func_attach("/sysManager/rs485InfoSet", TRANS_UNNEED, set_rs485_enable))			//设置485设备使能状态
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/rs485InfoSet] attach failed");
	}


	if(!web_func_attach("/sysManager/setPcsModuleNums", TRANS_UNNEED, set_pcs_module_nums))				//设置储能柜（带PCS模块）数量
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/setPcsModuleNums] attach failed");
	}
	if(!web_func_attach("/sysManager/getPcsModuleNums", TRANS_UNNEED, get_pcs_module_nums))				//获取储能柜（带PCS模块）数量
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/getPcsModuleNums] attach failed");
	}
	if(!web_func_attach("/sysManager/setCsuScenario", TRANS_UNNEED, set_csu_scenario))					//设置CSU应用场景
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/setCsuScenario] attach failed");
	}
	if(!web_func_attach("/sysManager/getCsuScenario", TRANS_UNNEED, get_csu_scenario))					//获取CSU应用场景
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/getCsuScenario] attach failed");
	}
	if(!web_func_attach("/debugManager/setFactoryCapacityTest", TRANS_NEED, set_ft_cap_test_mode))		//设置储能柜容测模式
	{
		SYS_MANEGE_DEBUG_PRINT("[/debugManager/setFactoryCapacityTest] attach failed");
	}
	if(!web_func_attach("/debugManager/getFactoryCapacityTest", TRANS_NEED, NULL))		//获取储能柜容测模式
	{
		SYS_MANEGE_DEBUG_PRINT("[/debugManager/getFactoryCapacityTest] attach failed");
	}
	if(!web_func_attach("/mqttSetParam/devInfoSet", TRANS_UNNEED, set_mqtt_dev_info))		//写入MQTT四元组
	{
		SYS_MANEGE_DEBUG_PRINT("[/mqttSetParam/devInfoSet] attach failed");
	}
	if(!web_func_attach("/mqttSetParam/devInfoGet", TRANS_UNNEED, get_mqtt_dev_info))		//获取MQTT四元组
	{
		SYS_MANEGE_DEBUG_PRINT("[/mqttSetParam/devInfoGet] attach failed");
	}
	if(!web_func_attach("/mqttSetParam/serverHostSet", TRANS_UNNEED, set_mqtt_server_host))		        //设置服务器类型
	{
		SYS_MANEGE_DEBUG_PRINT("[/mqttSetParam/serverHostSet] attach failed");
	}
	if(!web_func_attach("/mqttSetParam/serverHostGet", TRANS_UNNEED, get_mqtt_server_host))		        //获取服务器类型
	{
		SYS_MANEGE_DEBUG_PRINT("[/mqttSetParam/serverHostGet] attach failed");
	}
	if(!web_func_attach("/system/getLanguageType", TRANS_NEED, NULL)) //获取设置的语言类型，该语言类型暂时由CMU保存
	{
		SYS_MANEGE_DEBUG_PRINT("[/system/getLanguageType] attach failed");
	}
    if(!web_func_attach("/sysManager/setConfigParameter", TRANS_UNNEED, set_dev_config_param))		//设置控制参数
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/setConfigParameter] attach failed");
	}
	if(!web_func_attach("/sysManager/getConfigParameter", TRANS_UNNEED, get_dev_config_param))		//读取控制参数
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/getConfigParameter] attach failed");
	}
	if(!web_func_attach("/sysManager/csuSNSet", TRANS_UNNEED, set_csu_sn))		//设置汇流柜SN
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/csuSNSet] attach failed");
	}
	if(!web_func_attach("/sysManager/csuSNGet", TRANS_UNNEED, get_csu_sn))		//读取汇流柜SN
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/csuSNGet] attach failed");
	}
	if(!web_func_attach("/sysManager/PhotovoltaicMeterSet", TRANS_UNNEED, set_photovoltaic_meter_cfg))		//设置光伏电表参数
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/PhotovoltaicMeterSet] attach failed");
	}
	if(!web_func_attach("/sysManager/PhotovoltaicMeterGet", TRANS_UNNEED, get_photovoltaic_meter_cfg))		//读取光伏电表参数
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/PhotovoltaicMeterGet] attach failed");
	}
		if(!web_func_attach("/sysManager/ParallelCabinetParamSet", TRANS_UNNEED, csu_comb_param_set ))
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/ParallelCabinetParamSet] attach failed");
	}
	if(!web_func_attach("/sysManager/ParallelCabinetParamGet", TRANS_UNNEED, csu_comb_param_get ))
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/ParallelCabinetParamGet] attach failed");
	}
	if(!web_func_attach("/sysManager/getmcu2debuglog", TRANS_UNNEED, get_mcu2debuglog))				//生成MUC2操作log
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/getmcu2debuglog] attach failed");
	}
	if(!web_func_attach("/sysManager/getmcu2debuglogProgress", TRANS_UNNEED, get_mcu2debuglog_Progres))	//MUC2操作log进度
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/getmcu2debuglogProgress] attach failed");
	}
	if(!web_func_attach("/sysManager/exportmcu2debuglog", TRANS_UNNEED, export_mcu2debuglog))		//下载MUC2操作log
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/exportmcu2debuglog] attach failed");
	}
	if(!web_func_attach("/sysManager/pcsPowerupTimeGradidentSet", TRANS_NEED, NULL))	// 设置PCS功率软启时间梯度
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/pcsPowerupTimeGradidentSet] attach failed");
	}
	if(!web_func_attach("/sysManager/pcsPowerupTimeGradidentGet", TRANS_NEED, NULL))	// 获取PCS功率软启时间梯度
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/pcsPowerupTimeGradidentGet] attach failed");
	}
	if(!web_func_attach("/sysManager/pcsPowerFactorRefSet", TRANS_NEED, NULL))	// 设置PCS功率因数
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/pcsPowerFactorRefSet] attach failed");
	}
	if(!web_func_attach("/sysManager/pcsPowerFactorRefGet", TRANS_NEED, NULL))	// 获取PCSPCS功率因数
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/pcsPowerFactorRefGet] attach failed");
	}
	if(!web_func_attach("/sysManager/pcsReactivePowerModeSet", TRANS_NEED, NULL))	// 设置PCS无功模式
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/pcsReactivePowerModeSet] attach failed");
	}
	if(!web_func_attach("/sysManager/pcsReactivePowerModeGet", TRANS_NEED, NULL))	// 获取PCS无功模式
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/pcsReactivePowerModeGet] attach failed");
	}
	if(!web_func_attach("/sysManager/pcsReactivePowerEnableSet", TRANS_NEED, NULL))	// 设置PCS无功使能
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/pcsReactivePowerEnableSet] attach failed");
	}
	if(!web_func_attach("/sysManager/pcsReactivePowerEnableGet", TRANS_NEED, NULL))	// 获取PCS无功使能
	{
		SYS_MANEGE_DEBUG_PRINT("[/sysManager/pcsReactivePowerEnableGet] attach failed");
	}
}