#ifndef __EMS_H__
#define __EMS_H__

#include"mongoose.h"

typedef struct
{
	uint32_t meter_energy_charge;						// 计量表总充电量
	uint32_t meter_energy_discharge;					// 计量表总放电量
}energy_data_t;	


/**
 * @brief  EMS循环获取充放电线程
 */
void ems_energy_get_thread(void);


/**
 * @brief EMS管理模块初始化
 * @return void
 */
void web_ems_manage_module_init(void);

#endif