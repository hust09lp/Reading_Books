#ifndef __SYS_MANAGE_H__
#define __SYS_MANAGE_H__

#include "component/sofar_log.h"

#if (1)
#define SYS_MANEGE_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else
#define SYS_MANEGE_DEBUG_PRINT(...) {do {} while(0);}
#endif

#define PATH_MQTT_DEV_INFO_FILE     "/user/conf/mqtt_dev_info"
#define DEVICE_INFO_FILE_VALID	(0xAA55)	// 文件有效标志
#define METER3_MAX_NUM         5            //电表3最大数量
typedef struct
{
    uint16_t validity_flag;			        // 文件有效性标志
    uint8_t clientID[128];
    uint8_t dev_name[128];
    uint8_t pro_key[128];
    uint8_t dev_secret[128];
    uint8_t dev_sn[128];
    uint8_t pcs_sn[128];
    uint8_t meter2_sn[128];
    uint8_t meter3_sn[METER3_MAX_NUM][128];
}mqtt_dev_info_t;

#define PATH_MQTT_SERVER_HOST_FILE     "/user/conf/mqtt_server_host"
typedef struct
{
    uint16_t validity_flag;			        // 文件有效性标志
    uint8_t host[128];
}mqtt_server_host_t;

#define PATH_USER_ODM_INFO_FILE     "/user/conf/user_odm_info"
typedef struct
{
    uint16_t validity_flag;			        // 文件有效性标志
    uint8_t odm_param;
}user_odm_info_t;

/**
 * @brief 系统管理模块初始化
 * @return void
 */
void web_sys_manage_module_init(void);

/**
 * @brief        获取容测模式初始化
 * @param        
 * @return       
 * @retval       
 * @retval       
 */
void get_cmu_cap_test_init( void );

#endif