#include "cJSON.h"
#include "common.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk/sdk_para.h"
#include "sdk/sdk_public.h"
#include "sdk/sdk_fs.h"
#include "web_data_trans2cmu.h"
#include "libghttp.h"
#include "app_common.h"
#include "sqlite3.h"
#include "web_broker.h"
#include "sys_manage.h"
#include "operation_log.h"
#include "cmu_data_monitor.h"
#include "ems_manage.h"

#define INVALID_POWER   32767

#define HISTORY_YEAR_START           (2023)      // 时间小于2023，不进行历史电量记录

#define HOURS_NUM_PER_DAY				(24)					// 一天24小时
#define MONTHS_NUM_PER_YEAR				(12)					// 一年12月
#define STORAGE_TIME_LIMIT				(20)					// 存储时间限制 20年

#define ENERGY_INCOME_DB "/user/data/energy/energy_income.db"
#define ENERGY_INCOME_PATH "/user/data/energy/"

// 时间变化类型
#define YEAR_CHANGE						5
#define MONTH_CHANGE					4
#define DAY_CHANGE						3
#define HOUR_CHANGE						2
#define MIN_CHANGE						1
#define NO_CHANGE						0
// 电量时间结构体
#pragma pack(push)
#pragma pack(1)
typedef struct
{
    int16_t year;	// 年份，如2023
    int16_t month;	// 月份，1~12
    int16_t day;	// 日期，1~31
	int16_t hour;	// 小时，0~23
    int16_t minute;
	int16_t second;
}energy_time_t;
#pragma pack(pop)

// 收益数据结构,每个小时
#pragma pack(push)
#pragma pack(1)
typedef struct
{
    double charge_income;		//充电收益，统一命名（充电是支出）
    double discharge_income;	//放电收益
}energy_income_t;
#pragma pack(pop)

static energy_time_t now_time;         					                    // 当前时间
static energy_time_t last_savetime;						                    // 上一次保存时间
static ems_time_attr_t ems_time_attr[EMS_TIME_DURATION_CNT] = {0};			//削峰填谷时间段属性
static energy_price_t energy_price = {0};				                    //电价
static energy_income_t energy_income = {0};				                    //收益
static energy_data_t meter_energy_last = {0};                               //上次数据记录
static energy_data_t meter_energy_now = {0};                                //当前数据记录

static uint8_t cmu_ip_tbl[MAX_SLAVE_COUNT][MAX_IP_LEN] = {CMU1_IP, CMU2_IP, CMU3_IP, CMU4_IP, CMU5_IP, CMU6_IP};
static uint8_t *month_name[12] = {"Jan", "Fed", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};

/**
 * @brief  系统rtc时间获取
 * @param  [in] none
 * @param  [out] none
 * @return 当前时间结构体
 */
static energy_time_t get_energy_time(void)
{
    int32_t ret = 0;
    sdk_rtc_t now;
	energy_time_t current = {0, 0, 0, 0, 0, 0};

    ret = sdk_rtc_get(RTC_BIN_FORMAT, &now);
	if (ret != 0)
	{
		return current;
	}

    current.year = now.tm_year + 2000;
    current.month = now.tm_mon;
    current.day = now.tm_day;
    current.hour = now.tm_hour;
    current.minute = now.tm_min;
    current.second = now.tm_sec;

    return current;  
}


/**
 * @brief  时间变化判断函数
 * @param  [in] updatetime 更新时的时间
 * @param  [in] lastsavetime 上一次保存的时间
 * @param  [out] none
 * @return 时间变化类型(0~4)
 */
static uint8_t get_energy_timechange(energy_time_t updatetime, energy_time_t lastsavetime)
{
	if (updatetime.year < HISTORY_YEAR_START)	// 年限不合理，不进行历史电量记录
	{
		return NO_CHANGE;
	}

	if (lastsavetime.year != updatetime.year)
	{
		return YEAR_CHANGE;
	}
	if (lastsavetime.month != updatetime.month)
	{
		return MONTH_CHANGE;
	}
	if (lastsavetime.day != updatetime.day)
	{
		return DAY_CHANGE;
	}
	if (lastsavetime.hour != updatetime.hour)
	{
		return HOUR_CHANGE;
	}
	if (lastsavetime.minute != updatetime.minute)
	{
		return MIN_CHANGE;
	}
	return NO_CHANGE;
}


/**
 * @brief  更新上一次生产时间
 * @param  [in] updatetime 
 * @param  [out] lastproductiontime
 * @return none
 */
static void energy_update_lastsavetime(energy_time_t *p_last_time, energy_time_t update_time)
{
	if (NULL == p_last_time)
	{
		return;
	}

	memcpy(p_last_time, &update_time, sizeof(energy_time_t));

	return;
}


/**
 * @brief  更新削峰填谷时间属性
 * @return none
 */
static void update_ems_time_attr(void)
{
	ems_data_t *p_ems_data = sdk_shm_ems_data_info_get();

	memcpy(ems_time_attr, p_ems_data->time_attr, sizeof(ems_time_attr_t) * EMS_TIME_DURATION_CNT);
}


/**
 * @brief  更新削峰填谷电价属性
 * @return none
 */
static void update_ems_price_attr(void)
{
	common_data_t *shm = NULL;

	shm = sdk_shm_get();
	
	if(NULL == shm)
	{
		return ;
	}
	energy_price.flat_price = shm->energy_price.flat_price;
	energy_price.valley_price = shm->energy_price.valley_price;
	energy_price.peak_price = shm->energy_price.peak_price;
	energy_price.sharp_price = shm->energy_price.sharp_price;

}



/**
 * @brief    设置EMS参数
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void set_ems_param(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_data = NULL;	
    cJSON *p_resp_item = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t response[1024];  //
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
	uint16_t len;
	uint16_t result;
	uint8_t ret;
    uint8_t request_body[4096] = {0};
	uint32_t value_int = 0;
	uint8_t cur_user[32] = {0};	
	operation_log_t op_log;
	ems_data_t *p_ems_data = NULL;
	ems_holiday_data_t *p_ems_holiday_data = NULL;
	uint16_t rated_capacity = 0;
	uint8_t i;
    int16_t power = 0;
    uint16_t month_index = 0;
	csu_combine_info_t *p_csu_combine = sdk_shm_csu_combine_data_get();
	bat_charge_data_t *p_bat_info = sdk_shm_bat_charge_data_info_get();

	web_control_info_t *sdk_shm_web_data = sdk_shm_web_control_data_get();
    internal_shared_data_t *p_shared_data = sdk_shm_internal_shared_data_get();
    p_ems_data = &(sdk_shm_web_data->ems_data);
    p_ems_holiday_data = &(sdk_shm_web_data->ems_holiday_data);
    memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
    if (p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	if ((NULL == cJSON_GetObjectItem(p_request,"action")) || (NULL == cJSON_GetObjectItem(p_request,"data")))
	{
		SYS_MANEGE_DEBUG_PRINT("parameter is not right.");
		build_empty_response(response,Non_Authoriative_Information,"parameter is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}	
	
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"setEMSParam"))
	{
		SYS_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	p_data = cJSON_GetObjectItem(p_request,"data");
	p_ems_data->demand_resp_en = cJSON_GetObjectItem(p_data,"demandRespEn")->valueint;
	p_ems_data->quantity_demand = (cJSON_GetObjectItem(p_data,"quantityDemand")->valueint) * 10 ;
	p_ems_data->quantity_demand_dead_zone = (cJSON_GetObjectItem(p_data,"demandRespDeadZone")->valueint) / 100;

	p_ems_data->anti_reflux_action_en = cJSON_GetObjectItem(p_data,"anti-refluxActionEn")->valueint;
	p_ems_data->anti_reflux_action_dead_zone = (cJSON_GetObjectItem(p_data,"anti-refluxActionDeadZone")->valueint) / 100;

	p_ems_data->capa_change_need_en = cJSON_GetObjectItem(p_data,"capaChangeNeedEn")->valueint;
	p_ems_data->capa_change_need_demand = (cJSON_GetObjectItem(p_data,"capaChangeNeedDemand")->valueint) * 10;

	p_ems_data->shav_peak_fill_valley_en = cJSON_GetObjectItem(p_data,"shavPeakFillValleyEn")->valueint;


	if(NULL != cJSON_GetObjectItem(p_data,"timeAttr"))
	{
		cJSON *p_resp_array = cJSON_GetObjectItem(p_data,"timeAttr");

		uint16_t array_size = cJSON_GetArraySize(p_resp_array);
		if(array_size == 0)
		{
			SYS_MANEGE_DEBUG_PRINT("array size is 0");
		}

		//数据清0
		memset(p_ems_data->time_attr, 0, sizeof(ems_time_attr_t) * EMS_TIME_DURATION_CNT);
		for(uint8_t i = 0; i < EMS_TIME_DURATION_CNT; i++)
		{
			if(i < array_size)
			{
				cJSON *item = cJSON_GetArrayItem(p_resp_array, i);
				p_ems_data->time_attr[i].enable_type = cJSON_GetObjectItem(item,"enableType")->valueint;
				p_ems_data->time_attr[i].start_time = cJSON_GetObjectItem(item,"startTime")->valueint;
				p_ems_data->time_attr[i].end_time = cJSON_GetObjectItem(item,"endTime")->valueint;
				power = cJSON_GetObjectItem(item,"power")->valueint;
				p_ems_data->power[i] = (power == INVALID_POWER) ? INVALID_POWER : power * 10;
			}
			else
			{
				p_ems_data->power[i] = INVALID_POWER;
			}
			SYS_MANEGE_DEBUG_PRINT("enable_type:%d", p_ems_data->time_attr[i].enable_type);
			SYS_MANEGE_DEBUG_PRINT("start_time:%d", p_ems_data->time_attr[i].start_time);
			SYS_MANEGE_DEBUG_PRINT("end_time:%d", p_ems_data->time_attr[i].end_time);
			SYS_MANEGE_DEBUG_PRINT("Power:%d", p_ems_data->power[i]);
		}
	}
	else
	{
		memset(p_ems_data->time_attr, 0, sizeof(ems_time_attr_t) * EMS_TIME_DURATION_CNT);
		for(uint8_t i = 0; i < EMS_TIME_DURATION_CNT; i++)
		{
            p_ems_data->power[i] = INVALID_POWER;
            SYS_MANEGE_DEBUG_PRINT("Power:%d", p_ems_data->power[i]);
		}
	}
	update_ems_time_attr();

	p_ems_data->end_charge_soc_max = cJSON_GetObjectItem(p_data,"endChargeSOCMax")->valueint;
	p_ems_data->pcc_power_set = (cJSON_GetObjectItem(p_data,"pccPowerSet")->valueint) * 10;
	p_ems_data->k1_coefficient = cJSON_GetObjectItem(p_data,"k1Coefficient")->valueint;
	p_ems_data->theory_max_charge_power = (cJSON_GetObjectItem(p_data,"theoryMaxChargePower")->valueint) * 10;

	p_ems_data->discharge_soc_min = cJSON_GetObjectItem(p_data,"dischargeSOCMin")->valueint;
	p_ems_data->discharge_power_adjust_step = (cJSON_GetObjectItem(p_data,"dischargePowerAdjuStep")->valueint) * 10;
	p_ems_data->k2_coefficient = cJSON_GetObjectItem(p_data,"k2Coefficient")->valueint;
	p_ems_data->theory_max_discharge_power = (cJSON_GetObjectItem(p_data,"theoryMaxDischargePower")->valueint) * 10;

	p_ems_data->soc_maintain_en = cJSON_GetObjectItem(p_data,"SOCMaintainEn")->valueint;
	p_ems_data->soc_maintain_power = (cJSON_GetObjectItem(p_data,"SOCMaintainPower")->valueint) * 10;

	p_ems_data->power_adjust_ctr_en = cJSON_GetObjectItem(p_data,"powerAdjuCtrlEn")->valueint;
	p_ems_data->power_adjust_ctr_step = (cJSON_GetObjectItem(p_data,"powerAdjuStep")->valueint) * 10;

	p_ems_data->power_factor = cJSON_GetObjectItem(p_data,"powerFactor")->valueint;
    //额定容量=系统pack数量*43Kwh
	for (i = 0; i < MAX_SLAVE_COUNT; i++)
	{
		rated_capacity += p_bat_info[i].cluster_cap_energy * p_bat_info[i].cluster_num * 0.01f;
	}
	if ((true == p_csu_combine->comb_setting.comb_enable) && (CSU_ROLE_MASTER == p_csu_combine->comb_setting.comb_role))
	{
		for (i = 0; i < CSU_COMB_MAX_SLAVE_CNT; i++)
		{
			rated_capacity += p_csu_combine->slave_info[i].real_data.cluster_cap_energy * p_csu_combine->slave_info[i].real_data.cluster_num * 0.01f;
		}
	}
	p_ems_data->rated_capa = rated_capacity;
	p_ems_data->peak_end_early_time = cJSON_GetObjectItem(p_data,"peakEndEarlyTime")->valueint;
	p_ems_data->sharp_end_early_time = cJSON_GetObjectItem(p_data,"sharpEndEarlyTime")->valueint;
	p_ems_data->valley_end_early_time = cJSON_GetObjectItem(p_data,"valleyEndEarlyTime")->valueint;

	p_ems_data->noload_to_standby_time = cJSON_GetObjectItem(p_data,"noLoadToStandbyTime")->valuedouble * 10;
	p_ems_data->noload_to_shutdown_time = cJSON_GetObjectItem(p_data,"noLoadToShutDownTime")->valuedouble * 10;
	p_ems_data->poweron_early_time = cJSON_GetObjectItem(p_data,"powerOffEarlyTime")->valueint;
    p_ems_data->self_cosum_mode_enable = cJSON_GetObjectItem(p_data,"selfCosumModeEnable")->valueint;

    if(cJSON_GetObjectItem(p_data,"meter1Mode")->valueint)
    {
        BIT_SET(p_ems_data->meter_curr_dir, 0);
    }
    else
    {
        BIT_CLR(p_ems_data->meter_curr_dir, 0);
    }

    if(cJSON_GetObjectItem(p_data,"meter2Mode")->valueint)
    {
        BIT_SET(p_ems_data->meter_curr_dir, 1);
    }
    else
    {
        BIT_CLR(p_ems_data->meter_curr_dir, 1);
    }

    if(cJSON_GetObjectItem(p_data,"meter3Mode")->valueint)
    {
        BIT_SET(p_ems_data->meter_curr_dir, 2);
    }
    else
    {
        BIT_CLR(p_ems_data->meter_curr_dir, 2);
    }

    if(cJSON_GetObjectItem(p_data,"meter4Mode")->valueint)
    {
        BIT_SET(p_ems_data->meter_curr_dir, 3);
    }
    else
    {
        BIT_CLR(p_ems_data->meter_curr_dir, 3);
    }

	memset(p_ems_holiday_data->time_attr, 0, sizeof(ems_holiday_time_attr_t) * EMS_TIME_DURATION_CNT);
	memset(p_ems_holiday_data->holiday_date, 0xFF, sizeof(p_ems_holiday_data->holiday_date));
	for(uint8_t i = 0; i < EMS_TIME_DURATION_CNT; i++)
	{
		p_ems_holiday_data->time_attr[i].power = INVALID_POWER;
	}
	if(NULL != cJSON_GetObjectItem(p_data,"Strategy2Param"))
	{
		uint16_t holiday_enable;
		cJSON *p_holiday_data = cJSON_GetObjectItem(p_data,"Strategy2Param");
		if(NULL != cJSON_GetObjectItem(p_holiday_data,"Strategy2Enable"))
		{
			holiday_enable = cJSON_GetObjectItem(p_holiday_data,"Strategy2Enable")->valueint;
		}

		if(holiday_enable)
		{
			cJSON *p_time_array = cJSON_GetObjectItem(p_holiday_data,"timeAttr");
			uint16_t array_size = cJSON_GetArraySize(p_time_array);
			if(array_size == 0)
			{
				SYS_MANEGE_DEBUG_PRINT("array size is 0");
			}
			for(uint8_t i = 0; i < EMS_TIME_DURATION_CNT; i++)
			{
				if(i < array_size)
				{
					cJSON *item = cJSON_GetArrayItem(p_time_array, i);
					p_ems_holiday_data->time_attr[i].enable_type = cJSON_GetObjectItem(item,"enableType")->valueint;
					p_ems_holiday_data->time_attr[i].start_time = cJSON_GetObjectItem(item,"startTime")->valueint;
					p_ems_holiday_data->time_attr[i].end_time = cJSON_GetObjectItem(item,"endTime")->valueint;
					power = cJSON_GetObjectItem(item,"power")->valueint;
					p_ems_holiday_data->time_attr[i].power = (power == INVALID_POWER) ? INVALID_POWER : power * 10;
				}
				else
				{
					p_ems_holiday_data->time_attr[i].power = INVALID_POWER;
				}
				SYS_MANEGE_DEBUG_PRINT("enable_type:%d", p_ems_holiday_data->time_attr[i].enable_type);
				SYS_MANEGE_DEBUG_PRINT("start_time:%d", p_ems_holiday_data->time_attr[i].start_time);
				SYS_MANEGE_DEBUG_PRINT("end_time:%d", p_ems_holiday_data->time_attr[i].end_time);
				SYS_MANEGE_DEBUG_PRINT("Power:%d", p_ems_holiday_data->time_attr[i].power);
			}
			p_ems_holiday_data->holiday_enable = 0;
			cJSON *p_weekend_array = cJSON_GetObjectItem(p_holiday_data,"Weekend");
			uint16_t p_weekend_array_size = cJSON_GetArraySize(p_weekend_array);
			for (uint8_t i = 0; i < p_weekend_array_size; i++)
			{
				uint16_t value = cJSON_GetArrayItem(p_weekend_array, i)->valueint;
				if(6 == value)
				{
					BIT_SET(p_ems_holiday_data->holiday_enable, 0);
				}
				else if(7 == value)
				{
					BIT_SET(p_ems_holiday_data->holiday_enable, 1);
				}
			}

			for (uint8_t i = 0; i < 12; i++)
			{
				cJSON *p_month_array = cJSON_GetObjectItem(p_holiday_data, month_name[i]);
				uint16_t p_month_array_size = cJSON_GetArraySize(p_month_array);
				SYS_MANEGE_DEBUG_PRINT("i:%d\n", i);
				SYS_MANEGE_DEBUG_PRINT("size:%d\n", p_month_array_size);
				if(p_month_array_size != 0)
				{
					BIT_SET(p_ems_holiday_data->holiday_enable, 2);
				}
				SYS_MANEGE_DEBUG_PRINT("p_month_array_size:%d\n", p_month_array_size);
				SYS_MANEGE_DEBUG_PRINT("p_ems_holiday_data->holiday_enable:%d\n", p_ems_holiday_data->holiday_enable);
				for (uint8_t j = 0; j < p_month_array_size; j++)
				{
					p_ems_holiday_data->holiday_date[month_index].bytes.high = i + 1;
					p_ems_holiday_data->holiday_date[month_index].bytes.low = cJSON_GetArrayItem(p_month_array, j)->valueint;
					SYS_MANEGE_DEBUG_PRINT("cJSON_GetArrayItem(p_month_array, j)->valueint: %d\n",cJSON_GetArrayItem(p_month_array, j)->valueint);
					month_index++;
				}
				if(month_index >= EMS_HOLIDAY_DATE_NUM)
				{
					break;
				}
			}
		}
		else
		{
			p_ems_holiday_data->holiday_enable = 0;
		}
	}
	else
	{
		p_ems_holiday_data->holiday_enable = 0;
	}
    cJSON_Delete(p_request);

    init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"设置EMS参数");

    //判断是否存在互斥功能
    if(p_ems_data->self_cosum_mode_enable && (p_ems_data->anti_reflux_action_en || 
                                              p_ems_data->capa_change_need_en))
    {
        strcpy(op_log.op_status,"failed");
		add_one_op_log(&op_log);
		build_empty_response(response,Multiple_Choices,"param conflict");
		http_back(p_nc,response);        
        return;
    }

	BIT_SET(sdk_shm_web_data->cabinet_param_update_flag, 0);

    p_resp_root = cJSON_CreateObject();
    if (p_resp_root == NULL)
    {
        SYS_MANEGE_DEBUG_PRINT("create json obj failed");
		strcpy(op_log.op_status,"failed");
		add_one_op_log(&op_log);
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",OK);
    cJSON_AddStringToObject(p_resp_root,"msg","set successful");

	strcpy(op_log.op_status,"success");
	add_one_op_log(&op_log);
	
    p = cJSON_PrintUnformatted(p_resp_root);
    http_back(p_nc,p);
	free(p);
	cJSON_Delete(p_resp_root);
}


/**
 * @brief    获取EMS参数
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void get_ems_param(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_item = NULL;
	cJSON *p_time_attr_item = NULL;
	cJSON *p_holiday_item = NULL;
	cJSON *p_resp_array = NULL;
	cJSON *p_holiday_obj = NULL;
	cJSON *p_holiday_time = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t response[512];
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t request_body[64] = {0};
	common_data_t *shm = NULL;
    int16_t power = 0;
	int32_t holiday_data[31];
	uint8_t index;

	shm = sdk_shm_get();
    ems_data_t *p_ems_data = &shm->constant_parameter_data.ems_data; 
    ems_holiday_data_t *p_ems_holiday_data= &(shm->constant_parameter_data.ems_holiday_data);
    internal_shared_data_t *p_shared_data = &shm->internal_shared_data; 

	memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
    if (p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"getEMSParam"))
	{
		SYS_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        SYS_MANEGE_DEBUG_PRINT("create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",OK);

    p_resp_item = cJSON_CreateObject();
    if(p_resp_item == NULL)
    {
    	cJSON_Delete(p_resp_root);
		build_empty_response(response,Non_Authoriative_Information,"err");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
    }

	p_resp_array = cJSON_CreateArray();
    if(p_resp_array == NULL)
    {
    	cJSON_Delete(p_resp_root);
		cJSON_Delete(p_resp_item);
		build_empty_response(response,Non_Authoriative_Information,"err");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
    }
	
    cJSON_AddNumberToObject(p_resp_item,"demandRespEn",p_ems_data->demand_resp_en);
	cJSON_AddNumberToObject(p_resp_item,"quantityDemand",p_ems_data->quantity_demand / 10); 
	cJSON_AddNumberToObject(p_resp_item,"demandRespDeadZone",(p_ems_data->quantity_demand_dead_zone) * 100);
    cJSON_AddNumberToObject(p_resp_item,"anti-refluxActionEn",p_ems_data->anti_reflux_action_en);
	cJSON_AddNumberToObject(p_resp_item,"anti-refluxActionDeadZone",(p_ems_data->anti_reflux_action_dead_zone) * 100); 

    cJSON_AddNumberToObject(p_resp_item,"capaChangeNeedEn",p_ems_data->capa_change_need_en);
	cJSON_AddNumberToObject(p_resp_item,"capaChangeNeedDemand",p_ems_data->capa_change_need_demand / 10); 
    cJSON_AddNumberToObject(p_resp_item,"shavPeakFillValleyEn",p_ems_data->shav_peak_fill_valley_en);

	cJSON_AddItemToObject(p_resp_item,"timeAttr",p_resp_array);

    for(uint8_t i = 0; i < EMS_TIME_DURATION_CNT; i++)
    {
		if((p_ems_data->time_attr[i].enable_type == 0) || (p_ems_data->time_attr[i].enable_type == 1))
		{
			continue;
		}
        p_time_attr_item = cJSON_CreateObject();
        if(p_time_attr_item == NULL)
        {
            SYS_MANEGE_DEBUG_PRINT("create json obj failed");
            cJSON_Delete(p_resp_array);
            return;
        }
        cJSON_AddNumberToObject(p_time_attr_item,"enableType",p_ems_data->time_attr[i].enable_type);
        cJSON_AddNumberToObject(p_time_attr_item,"startTime",p_ems_data->time_attr[i].start_time);
        cJSON_AddNumberToObject(p_time_attr_item,"endTime",p_ems_data->time_attr[i].end_time);
        power = (p_ems_data->power[i] == INVALID_POWER) ? INVALID_POWER : (p_ems_data->power[i] / 10);
        cJSON_AddNumberToObject(p_time_attr_item,"Power",power);
        cJSON_AddItemToArray(p_resp_array,p_time_attr_item);
    }
	
	cJSON_AddNumberToObject(p_resp_item,"endChargeSOCMax",p_ems_data->end_charge_soc_max); 
    cJSON_AddNumberToObject(p_resp_item,"pccPowerSet",p_ems_data->pcc_power_set / 10);
	cJSON_AddNumberToObject(p_resp_item,"k1Coefficient",p_ems_data->k1_coefficient); 
    cJSON_AddNumberToObject(p_resp_item,"theoryMaxChargePower",p_ems_data->theory_max_charge_power / 10);
	cJSON_AddNumberToObject(p_resp_item,"dischargeSOCMin",p_ems_data->discharge_soc_min); 
    cJSON_AddNumberToObject(p_resp_item,"dischargePowerAdjuStep",p_ems_data->discharge_power_adjust_step / 10);
	cJSON_AddNumberToObject(p_resp_item,"k2Coefficient",p_ems_data->k2_coefficient); 
    cJSON_AddNumberToObject(p_resp_item,"theoryMaxDischargePower",p_ems_data->theory_max_discharge_power / 10);
	cJSON_AddNumberToObject(p_resp_item,"SOCMaintainEn",p_ems_data->soc_maintain_en); 
	cJSON_AddNumberToObject(p_resp_item,"SOCMaintainPower",p_ems_data->soc_maintain_power / 10); 
    cJSON_AddNumberToObject(p_resp_item,"powerAdjuCtrlEn",p_ems_data->power_adjust_ctr_en);
	cJSON_AddNumberToObject(p_resp_item,"powerAdjuStep",p_ems_data->power_adjust_ctr_step / 10);
	cJSON_AddNumberToObject(p_resp_item,"powerFactor",p_ems_data->power_factor); 
    cJSON_AddNumberToObject(p_resp_item,"ratedCapa",p_ems_data->rated_capa);
	cJSON_AddNumberToObject(p_resp_item,"peakEndEarlyTime",p_ems_data->peak_end_early_time); 
    cJSON_AddNumberToObject(p_resp_item,"sharpEndEarlyTime",p_ems_data->sharp_end_early_time);
	cJSON_AddNumberToObject(p_resp_item,"valleyEndEarlyTime",p_ems_data->valley_end_early_time); 
    cJSON_AddNumberToObject(p_resp_item,"noLoadToStandbyTime",p_ems_data->noload_to_standby_time / 10.0); 
    cJSON_AddNumberToObject(p_resp_item,"noLoadToShutDownTime",p_ems_data->noload_to_shutdown_time / 10.0); 
    cJSON_AddNumberToObject(p_resp_item,"powerOffEarlyTime",p_ems_data->poweron_early_time); 
    cJSON_AddNumberToObject(p_resp_item,"selfCosumModeEnable",p_ems_data->self_cosum_mode_enable); 

    cJSON_AddNumberToObject(p_resp_item,"meter1Mode",BIT_GET(p_ems_data->meter_curr_dir, 0)); 
    cJSON_AddNumberToObject(p_resp_item,"meter2Mode",BIT_GET(p_ems_data->meter_curr_dir, 1)); 
    cJSON_AddNumberToObject(p_resp_item,"meter3Mode",BIT_GET(p_ems_data->meter_curr_dir, 2)); 
    cJSON_AddNumberToObject(p_resp_item,"meter4Mode",BIT_GET(p_ems_data->meter_curr_dir, 3)); 

    cJSON_AddNumberToObject(p_resp_item,"powerType",p_shared_data->cabinet_type); 
	p_holiday_obj = cJSON_CreateObject();
    if(p_holiday_obj == NULL)
    {
    	cJSON_Delete(p_resp_root);
		cJSON_Delete(p_resp_item);
		cJSON_Delete(p_resp_array);
		build_empty_response(response,Non_Authoriative_Information,"err");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
    }
	p_holiday_time = cJSON_CreateArray();
    if(p_holiday_time == NULL)
    {
		cJSON_Delete(p_resp_root);
		cJSON_Delete(p_resp_item);
		cJSON_Delete(p_resp_array);
		cJSON_Delete(p_holiday_obj);
		build_empty_response(response,Non_Authoriative_Information,"err");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
    }
	cJSON_AddItemToObject(p_resp_item,"Strategy2Param",p_holiday_obj);
	cJSON_AddNumberToObject(p_holiday_obj,"Strategy2Enable",p_ems_holiday_data->holiday_enable?1:0);
	cJSON_AddNumberToObject(p_holiday_obj,"CurrentYear",2004);
	cJSON_AddItemToObject(p_holiday_obj,"timeAttr",p_holiday_time);

    for(uint8_t i = 0; i < EMS_TIME_DURATION_CNT; i++)
    {
		if((p_ems_holiday_data->time_attr[i].enable_type == 0) || (p_ems_holiday_data->time_attr[i].enable_type == 1))
		{
			continue;
		}
        p_time_attr_item = cJSON_CreateObject();
        if(p_time_attr_item == NULL)
        {
            SYS_MANEGE_DEBUG_PRINT("create json obj failed");
            cJSON_Delete(p_holiday_time);
            return;
        }
        cJSON_AddNumberToObject(p_time_attr_item,"enableType",p_ems_holiday_data->time_attr[i].enable_type);
        cJSON_AddNumberToObject(p_time_attr_item,"startTime",p_ems_holiday_data->time_attr[i].start_time);
        cJSON_AddNumberToObject(p_time_attr_item,"endTime",p_ems_holiday_data->time_attr[i].end_time);
        power = (p_ems_holiday_data->time_attr[i].power == INVALID_POWER) ? INVALID_POWER : (p_ems_holiday_data->time_attr[i].power / 10);
        cJSON_AddNumberToObject(p_time_attr_item,"Power",power);
        cJSON_AddItemToArray(p_holiday_time,p_time_attr_item);
    }

	p_holiday_item = cJSON_CreateObject();
	if(p_holiday_item == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("create json obj failed");
		cJSON_Delete(p_resp_item);
		return;
	}
	// cJSON_AddItemToObject(p_resp_item,"Weekend",p_holiday_obj);
	memset(holiday_data,0xFF,sizeof(holiday_data));
	index = 0;
	if(BIT_GET(p_ems_holiday_data->holiday_enable,0))
	{
		holiday_data[index++] = 6;
	}
	if(BIT_GET(p_ems_holiday_data->holiday_enable,1))
	{
		holiday_data[index++] = 7;
	}
    cJSON_AddItemToObject(p_holiday_obj,"Weekend",cJSON_CreateIntArray(holiday_data, index));
	for (uint8_t i = 0; i < 12; i++)
	{
		index = 0;
		if((i >= (p_ems_holiday_data->holiday_date[0].bytes.high - 1)) && (i < p_ems_holiday_data->holiday_date[EMS_HOLIDAY_DATE_NUM - 1].bytes.high))
		{
			for (uint8_t j = 0; j < EMS_HOLIDAY_DATE_NUM; j++)
			{
				SYS_MANEGE_DEBUG_PRINT("%d-%d\n",p_ems_holiday_data->holiday_date[j].bytes.high,p_ems_holiday_data->holiday_date[j].bytes.low);
				if(p_ems_holiday_data->holiday_date[j].bytes.high == (i + 1))
				{
					holiday_data[index++] = p_ems_holiday_data->holiday_date[j].bytes.low;
				}
				else if(p_ems_holiday_data->holiday_date[j].all == 0xFFFF)
				{
					break;
				}
			}
		}
		cJSON_AddItemToObject(p_holiday_obj,month_name[i],cJSON_CreateIntArray(holiday_data, index));
	}
	
	cJSON_AddItemToObject(p_resp_root,"data",p_resp_item);
	cJSON_AddStringToObject(p_resp_root,"msg","get successful");
	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);	
	http_back(p_nc,p);
	free(p);
}

/**
 * @brief    设置EMS电价参数
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void set_ems_energy_price_param(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_data = NULL;	
    cJSON *p_resp_item = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t response[1024];  //
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
	uint8_t flag = 0;
	uint16_t len;
	uint16_t result;
	uint8_t ret;
    uint8_t request_body[4096] = {0};
	uint32_t value_int = 0;
	uint8_t cur_user[32] = {0};	
	operation_log_t op_log;
	common_data_t *shm = NULL;

	web_control_info_t *sdk_shm_web_data = sdk_shm_web_control_data_get();
	shm = sdk_shm_get();

    memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
    if (p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"setEnergyPrice"))
	{
		SYS_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}


	shm->energy_price.flat_price = cJSON_GetObjectItem(p_request,"flatPrice")->valuedouble;
	shm->energy_price.valley_price = cJSON_GetObjectItem(p_request,"valleyPrice")->valuedouble;
	shm->energy_price.peak_price = cJSON_GetObjectItem(p_request,"peakPrice")->valuedouble;
	shm->energy_price.sharp_price = cJSON_GetObjectItem(p_request,"sharpPrice")->valuedouble;

	BIT_SET(sdk_shm_web_data->cabinet_param_update_flag, 10);

	update_ems_price_attr();
    cJSON_Delete(p_request);

	init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"设置EMS电价参数");
	 
    p_resp_root = cJSON_CreateObject();
    if (p_resp_root == NULL)
    {
        SYS_MANEGE_DEBUG_PRINT("create json obj failed");
		strcpy(op_log.op_status,"failed");
		add_one_op_log(&op_log);
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",OK);
    cJSON_AddStringToObject(p_resp_root,"msg","set successful");

	strcpy(op_log.op_status,"success");
	add_one_op_log(&op_log);
	
    p = cJSON_PrintUnformatted(p_resp_root);
    http_back(p_nc,p);
	free(p);
	cJSON_Delete(p_resp_root);
}


/**
 * @brief    获取EMS电价参数
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void get_ems_energy_price_param(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t response[512];
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t request_body[64] = {0};
	common_data_t *shm = NULL;

	shm = sdk_shm_get();

	memcpy(request_body,p_msg->body.p,p_msg->body.len);	
	p_request = cJSON_Parse(request_body);
    if (p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"getEnergyPrice"))
	{
		SYS_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        SYS_MANEGE_DEBUG_PRINT("create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",OK);
	cJSON_AddNumberToObject(p_resp_root,"flatPrice",shm->energy_price.flat_price);
	cJSON_AddNumberToObject(p_resp_root,"valleyPrice",shm->energy_price.valley_price);
	cJSON_AddNumberToObject(p_resp_root,"peakPrice",shm->energy_price.peak_price);
	cJSON_AddNumberToObject(p_resp_root,"sharpPrice",shm->energy_price.sharp_price);

	cJSON_AddStringToObject(p_resp_root,"msg","get successful");
		
	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);	
	http_back(p_nc,p);
	free(p);
}


/**
 * @brief    获取EMS电价走势数据
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void get_ems_energy_price_trend(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_item = NULL;
	cJSON *p_time_attr_item = NULL;
	cJSON *p_resp_array = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t response[512];
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t request_body[64] = {0};
	common_data_t *shm = NULL;

	ems_data_t *p_ems_data = sdk_shm_ems_data_info_get();   
	shm = sdk_shm_get();

	memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
    if (p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"getEnergyPriceTrend"))
	{
		SYS_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        SYS_MANEGE_DEBUG_PRINT("create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",OK);

	p_resp_array = cJSON_CreateArray();
    if(p_resp_array == NULL)
    {
    	cJSON_Delete(p_resp_root);
		cJSON_Delete(p_resp_item);
		build_empty_response(response,Non_Authoriative_Information,"err");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
    }
	

    for(uint8_t i = 0; i < EMS_TIME_DURATION_CNT; i++)
    {
		if(p_ems_data->time_attr[i].enable_type != 0)
		{
			p_time_attr_item = cJSON_CreateObject();
			if(p_time_attr_item == NULL)
			{
				SYS_MANEGE_DEBUG_PRINT("create json obj failed");
				cJSON_Delete(p_resp_array);
				return;
			}
			if(p_ems_data->time_attr[i].enable_type == 1)			//平时段
			{
				cJSON_AddNumberToObject(p_time_attr_item,"price",shm->energy_price.flat_price);
			}	
			else if(p_ems_data->time_attr[i].enable_type == 2)
			{
				cJSON_AddNumberToObject(p_time_attr_item,"price",shm->energy_price.valley_price);
			}
			else if(p_ems_data->time_attr[i].enable_type == 3)
			{
				cJSON_AddNumberToObject(p_time_attr_item,"price",shm->energy_price.peak_price);
			}
			else if(p_ems_data->time_attr[i].enable_type == 4)
			{
				cJSON_AddNumberToObject(p_time_attr_item,"price",shm->energy_price.sharp_price);
			}
			cJSON_AddNumberToObject(p_time_attr_item,"enableType",p_ems_data->time_attr[i].enable_type);
			cJSON_AddNumberToObject(p_time_attr_item,"startTime",p_ems_data->time_attr[i].start_time);
			cJSON_AddNumberToObject(p_time_attr_item,"endTime",p_ems_data->time_attr[i].end_time);
			cJSON_AddItemToArray(p_resp_array,p_time_attr_item);
		}

    }
	cJSON_AddItemToObject(p_resp_root,"timeAttr",p_resp_array);
	cJSON_AddStringToObject(p_resp_root,"msg","get successful");
		
	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);	
	http_back(p_nc,p);
	free(p);
}


/**
 * @brief  创建数据库文件
 * @return none
 */
static int32_t create_energy_income_table(void) 
{
    sqlite3 *db;
    char *sql = "CREATE TABLE IF NOT EXISTS charge_data (date TEXT PRIMARY KEY, charge_income REAL, discharge_income REAL);";
    char *err_msg = 0;
	int rc = 0;
	
    rc = sqlite3_open(ENERGY_INCOME_DB, &db);
    if( rc ) {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return(0);
    }

    rc = sqlite3_exec(db, sql, 0, 0, &err_msg);

    if (rc != SQLITE_OK) {
        fprintf(stderr, "Failed to create table: %s\n", err_msg);
        sqlite3_free(err_msg);
    }

	sqlite3_close(db);
	return(1);
}

/**
 * @brief  检查充放电量数据库文件是否存在和有效
 * @param  [in] none
 * @param  [out] none
 * @return 0-数据库文件正常   -1-数据库文件异常
 */
static int32_t ems_energy_db_file_check(void)
{
	int32_t ret = -1;
	fs_t *p_fs = NULL;
	
	
    ret = sdk_fs_access((const int8_t *)ENERGY_INCOME_DB, F_OK);
    if (ret == -1)  // 文件不存在，创建该文件
    {
		log_i("\nenergy_income.db is not exist\n");
		create_energy_income_table();
		return (0);
    }
	else     // 文件存在，检查文件大小是否为0
	{
		log_i("\nenergy_income.db is exist\n");
		p_fs = sdk_fs_open((const int8_t *)ENERGY_INCOME_DB,FS_READ);
		if ( p_fs != NULL)
		{
			ret = sdk_fs_get_size(p_fs);
			sdk_fs_close(p_fs);
			log_i("\nenergy_income.db open success,file size:%d\n",ret);
			if (ret == 0)
			{
				log_i("\nre creat energy_income.db\n");
				sdk_fs_remove((const int8_t *)ENERGY_INCOME_DB);
				create_energy_income_table();
			}
		}
		else 
		{
			return (-1);
		}
	}
	return (0);
}

/**
 * @brief  创建数据库文件
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return none
 */
static int32_t sqlite_db_update_income_data(double charge_income, double discharge_income)
{
	sqlite3 *db;
	char *zErrMsg = 0;
	int rc;
    char date[32]={0};

	snprintf(date, sizeof(date),"%04d-%02d-%02d %02d:00:00",now_time.year,\
			now_time.month,now_time.day,now_time.hour);

	// SYS_MANEGE_DEBUG_PRINT("[date:%s] charge_income:%d  discharge_income:%d  ", date, charge_income, discharge_income);

	ems_energy_db_file_check();
	rc = sqlite3_open(ENERGY_INCOME_DB, &db);
	if(rc) 
	{
	   fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
	   return(0);
	} 
	else 
	{
		char *sql = "INSERT OR REPLACE INTO charge_data (date, charge_income, discharge_income) VALUES (?, ?, ?);";
		sqlite3_stmt *stmt;
		sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
		sqlite3_bind_text(stmt, 1, date, -1, SQLITE_STATIC);
		sqlite3_bind_double(stmt, 2, charge_income);
		sqlite3_bind_double(stmt, 3, discharge_income);
		sqlite3_step(stmt);
		sqlite3_finalize(stmt);
	}
	sqlite3_close(db);	 

}


/**
 * @brief 根据当前时间获取用电属性
 * @return 0：不使能，1：平时段，2：谷时段，3：峰时段，4：尖峰时段
 */
static uint8_t get_elec_attr_by_current_time(void)
{
	uint8_t time_str[5] = {0};

	sprintf(time_str, "%d%d", now_time.hour, now_time.minute);
	uint16_t current_time = atoi(time_str);
	for(uint8_t i = 0; i < EMS_TIME_DURATION_CNT; i++)
	{
		if(ems_time_attr[i].enable_type)
		{
			if((current_time >= ems_time_attr[i].start_time) && (current_time <= ems_time_attr[i].end_time))
			{
				return ems_time_attr[i].enable_type;
			}
		}
	}
	return 0;
}


/**
 * @brief 根据当前时间获取电价
 * @return 当前时间段电价
 */
static uint8_t get_elec_price_by_current_time(void)
{
	uint8_t enable_type = 0;

	enable_type = get_elec_attr_by_current_time();
	
	if(enable_type == 0 || enable_type == 1)
	{
		return energy_price.flat_price;
	}
	else if(enable_type == 2)
	{
		return energy_price.valley_price;
	}
	else if(enable_type == 3)
	{
		return energy_price.peak_price;
	}
	else if(enable_type == 4)
	{
		return energy_price.sharp_price;
	}
}


/**
 * @brief 定时循环获取电池充放电信息
 */
static void get_charge_discharge_per_minute(void)
{
	uint32_t tmp_charge = 0;
	uint32_t tmp_discharge = 0;
    internal_shared_data_t *p_internal_data = NULL;

	p_internal_data = sdk_shm_internal_shared_data_get();
    meter_energy_now.meter_energy_charge = p_internal_data->total_realtime_energy.meter_energy_charge;
    meter_energy_now.meter_energy_discharge = p_internal_data->total_realtime_energy.meter_energy_discharge;    

    tmp_charge = meter_energy_now.meter_energy_charge - meter_energy_last.meter_energy_charge;
    tmp_discharge = meter_energy_now.meter_energy_discharge - meter_energy_last.meter_energy_discharge;
	//进行计价处理
	// SYS_MANEGE_DEBUG_PRINT("tmp_charge:%d.", tmp_charge);
	// SYS_MANEGE_DEBUG_PRINT("tmp_discharge:%d.", tmp_discharge);
	//根据当前时间获取电价
	uint8_t elec_price = get_elec_price_by_current_time();
	//计算充放电收益
	energy_income.charge_income += (tmp_charge * elec_price) / 100.0;
	energy_income.discharge_income += (tmp_discharge * elec_price) / 100.0;

    memcpy(&meter_energy_last, &meter_energy_now, sizeof(energy_data_t));
}


/**
 * @brief  更新并保存收益
 * @param  [in] change 变更类型
 * @return 执行结果 0：成功 -1：失败
 */
int32_t energy_income_update()
{
	sqlite_db_update_income_data(energy_income.charge_income, energy_income.discharge_income);
	// memset(&energy_income, 0, sizeof(energy_income_t));
}


/**
 * @brief  电量获取管理
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
void ems_energy_get_manage(void)
{
	uint8_t change = 0;

	now_time =  get_energy_time();	

	change = get_energy_timechange(now_time, last_savetime);
	// SYS_MANEGE_DEBUG_PRINT("change is %d\n", change);
	if(change > 0)
	{
		if(change == MIN_CHANGE)
		{
			//每分钟去读取充放电量并进行计价处理
			get_charge_discharge_per_minute();
			energy_income_update();
			energy_update_lastsavetime(&last_savetime, now_time);
		}
		else
		{
			//每小时存储一次
			energy_income_update();
			energy_update_lastsavetime(&last_savetime, now_time);
			memset(&energy_income, 0, sizeof(energy_income_t));
		}
	}
}


typedef struct
{
	uint8_t date[32];
	double charge_income[32];								
	double discharge_income[32];	
}data_energy_income_t;


/**
  * @brief  从数据库获取数据
  * @return
  */
static void query_day_charge(sqlite3 *db, data_energy_income_t *energy_data)
{
    char sql[256];
	int32_t hour = 0;
	sqlite3_stmt *stmt;
	int32_t i = 0;
	
    snprintf(sql, sizeof(sql), "SELECT strftime('%%H', date), charge_income, discharge_income FROM charge_data WHERE date LIKE '%s%%';",energy_data->date);
    sqlite3_prepare_v2(db, sql, -1, &stmt, 0);

    while (sqlite3_step(stmt) == SQLITE_ROW) 
	{
		hour =atoi(sqlite3_column_text(stmt, 0));
		if (hour > 23)
		{
			printf("break \n");
			break;
		}
		energy_data->charge_income[hour] = sqlite3_column_double(stmt, 1);
		energy_data->discharge_income[hour] = sqlite3_column_double(stmt, 2);
		i++;

    }
	// SYS_MANEGE_DEBUG_PRINT("Found %d pieces of data\n",i);
	
    sqlite3_finalize(stmt);
}


/**
  * @brief  添加每日收益到json数据
  * @param  [in] year年
  * @param  [out] *p_resp_data json数据
  * @return
  */
static int32_t select_sqlite_db_day(uint8_t *year, cJSON *p_resp_data)
{
	sqlite3 *db;
	int rc;
	data_energy_income_t energy_data = {0};
    int32_t i;

	rc = sqlite3_open("/user/data/energy/energy_income.db", &db);
	if(rc) 
	{
	   SYS_MANEGE_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
	   return(0);
	} 
	else 
	{
		memset(&energy_data, 0, sizeof(data_energy_income_t));
		snprintf(energy_data.date, 32,"%s",year);
		
		query_day_charge(db, &energy_data);
	
		// cJSON_AddItemToObject(p_resp_data,"chargeIncome",cJSON_CreateDoubleArray(energy_data.charge_income ,HOURS_NUM_PER_DAY));
		// cJSON_AddItemToObject(p_resp_data,"disChargeIncome",cJSON_CreateDoubleArray(energy_data.discharge_income,HOURS_NUM_PER_DAY));
		cJSON_AddItemToObject(p_resp_data,"chargeIncome",cJSON_CreateDoubleArray(0 ,HOURS_NUM_PER_DAY));
		cJSON_AddItemToObject(p_resp_data,"disChargeIncome",cJSON_CreateDoubleArray(0,HOURS_NUM_PER_DAY));
	
    }
	
	sqlite3_close(db);	 
}


/**
  * @brief  获取日收益
  * @param  [in] *p_nc 连接信息 
  * @param  [in] *p_msg  http请求信息
  * @return
  */
void get_daily_charge_discharge_income(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_root = NULL;
    cJSON *p_resp_data = NULL;
    cJSON *p_resp_item = NULL;	
    uint8_t response[256] = {0};
    uint8_t *p_action = NULL;
	int32_t i = 0;
    uint8_t *p = NULL;
	uint8_t ymd[16] = {0};
    uint8_t request_body[128] = {0};
	energy_time_t energy_time;
		
	memcpy(request_body,p_msg->body.p,p_msg->body.len);	
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getDailyChargeDischargeIncome"))
	{
		SYS_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    p = cJSON_GetObjectItem(p_request,"ymd")->valuestring;
	snprintf(ymd, sizeof(ymd),"%s",p);
	
    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        SYS_MANEGE_DEBUG_PRINT("create json obj failed.");
        return ;
    }

	cJSON_AddNumberToObject(p_resp_root,"code",OK);

	select_sqlite_db_day(ymd, p_resp_root);	

	cJSON_AddStringToObject(p_resp_root,"msg","get successful");
	
	p = cJSON_PrintUnformatted(p_resp_root);
	http_back(p_nc,p); 
	cJSON_Delete(p_resp_root);
	free(p);	
}


static void query_monthly_charge(sqlite3 *db, data_energy_income_t *energy_data) 
{
    char sql[256];
	int32_t day=0;
	int32_t i=0;
	
    snprintf(sql, sizeof(sql), "SELECT strftime('%%d', date), SUM(charge_income), SUM(discharge_income) FROM charge_data WHERE strftime('%%Y-%%m', date) = '%s' GROUP BY strftime('%%Y-%%m-%%d', date);", energy_data->date);
	sqlite3_stmt *stmt;
    sqlite3_prepare_v2(db, sql, -1, &stmt, 0);

    while (sqlite3_step(stmt) == SQLITE_ROW) 
	{
		day =  atoi(sqlite3_column_text(stmt, 0));
		energy_data->charge_income[day-1] = sqlite3_column_double(stmt, 1);
		energy_data->discharge_income[day-1] = sqlite3_column_double(stmt, 2);
		i++;
    }

    sqlite3_finalize(stmt);
}


/**
 * @brief  判断是否为闰年
 * @param  [in] year 待判断的年份
 * @param  [out] none
 * @return 结果 true：是闰年  false：不是闰年
 */
bool leap_year_judge(int16_t year)
{
	if (((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0))	//闰年
	{
		return true;
	}
	else
	{
		return false;
	}
}


/**
  * @brief  获取目标月份天数
  * @param  [in] year 年
  * @param  [in] month 月
  * @return 天数
  */
uint8_t get_day_count(int16_t year, int16_t month)
{
	uint8_t month_days[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	//闰年
	if(leap_year_judge(year))
	{
		month_days[1] = 29;
	}

	if((year < now_time.year) || (month < now_time.month))			//往年往月
	{
		return month_days[month - 1];
	}
	//当前月份
	return now_time.day;
}


static int32_t select_sqlite_db_mon(uint8_t *ymd, cJSON *p_resp_data)
{
	sqlite3 *db;
	int rc;
	data_energy_income_t energy_data;
    int32_t i;
	int32_t year;
	int32_t month;
	uint8_t day_cnt = 0;
	
	rc = sqlite3_open("/user/data/energy/energy_income.db", &db);
	if(rc) 
	{
	   SYS_MANEGE_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
	   return(0);
	} 
	else 
	{
		//SYS_MANEGE_DEBUG_PRINT((int8_t *)"open database successfully\n");
		memset(&energy_data, 0, sizeof(data_energy_income_t));
		snprintf(energy_data.date, 32,"%s",ymd);
		sscanf(ymd,"%d-%d",&year,&month);
		
		query_monthly_charge(db, &energy_data);

		day_cnt = get_day_count(year, month);
	
		// cJSON_AddItemToObject(p_resp_data,"chargeIncome",cJSON_CreateDoubleArray(energy_data.charge_income ,day_cnt));
		// cJSON_AddItemToObject(p_resp_data,"disChargeIncome",cJSON_CreateDoubleArray(energy_data.discharge_income,day_cnt));
		cJSON_AddItemToObject(p_resp_data,"chargeIncome",cJSON_CreateDoubleArray(0, day_cnt));
		cJSON_AddItemToObject(p_resp_data,"disChargeIncome",cJSON_CreateDoubleArray(0, day_cnt));
	}
	
	sqlite3_close(db);	 
}


/**
  * @brief  获取月收益
  * @param  [in] *p_nc 连接信息 
  * @param  [in] *p_msg  http请求信息
  * @return
  */
void get_monthly_charge_discharge_income(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_root = NULL;
    cJSON *p_resp_data = NULL;
    cJSON *p_resp_item = NULL;	
    uint8_t response[256] = {0};
    uint8_t *p_action = NULL;
	int32_t i = 0;
    uint8_t *p = NULL;
	uint8_t ymd[32] = {0};
    uint8_t request_body[128] = {0};
	energy_time_t energy_time;
		
	memcpy(request_body,p_msg->body.p,p_msg->body.len);	
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getMonthlyChargeDischargeIncome"))
	{
		SYS_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
	
    p = cJSON_GetObjectItem(p_request,"ymd")->valuestring;
	snprintf(ymd, sizeof(ymd),"%s",p);
    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        SYS_MANEGE_DEBUG_PRINT("create json obj failed.");
        return ;
    }

	cJSON_AddNumberToObject(p_resp_root,"code",OK);

	select_sqlite_db_mon(ymd, p_resp_root);	

	cJSON_AddStringToObject(p_resp_root,"msg","get successful");
	
	p = cJSON_PrintUnformatted(p_resp_root);
	http_back(p_nc,p);
	cJSON_Delete(p_resp_root);
	free(p);	
}


static void query_yearly_charge(sqlite3 *db, data_energy_income_t *energy_data) 
{
    char sql[256];
	int32_t mon=0;
	int32_t i=0;
	
    snprintf(sql, sizeof(sql), "SELECT strftime('%%m', date), SUM(charge_income), SUM(discharge_income) FROM charge_data WHERE strftime('%%Y', date) = '%s' GROUP BY strftime('%%Y-%%m', date);", energy_data->date);

	sqlite3_stmt *stmt;
    sqlite3_prepare_v2(db, sql, -1, &stmt, 0);

    while (sqlite3_step(stmt) == SQLITE_ROW) 
	{
		mon =  atoi(sqlite3_column_text(stmt, 0));
		energy_data->charge_income[mon-1] = sqlite3_column_double(stmt, 1);
		energy_data->discharge_income[mon-1] = sqlite3_column_double(stmt, 2);
		i++;
    }

    sqlite3_finalize(stmt);
}


static int32_t select_sqlite_db_year(uint8_t *year, cJSON *p_resp_data)
{
	sqlite3 *db;
	int rc;
	data_energy_income_t energy_data;
	uint8_t months = 0;
    int32_t i;
	
	rc = sqlite3_open("/user/data/energy/energy_income.db", &db);
	if(rc) 
	{
	   SYS_MANEGE_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
	   return(0);
	} 
	else 
	{
		memset(&energy_data, 0, sizeof(data_energy_income_t));
		snprintf(energy_data.date, 32,"%s",year);
		
		query_yearly_charge(db, &energy_data);
		if(atoi(year) < now_time.year)
		{
			months = 12;
		}
		else
		{
			months = now_time.month;
		}
	
		// cJSON_AddItemToObject(p_resp_data,"chargeIncome",cJSON_CreateDoubleArray(energy_data.charge_income , months));
		// cJSON_AddItemToObject(p_resp_data,"disChargeIncome",cJSON_CreateDoubleArray(energy_data.discharge_income, months));
		cJSON_AddItemToObject(p_resp_data,"chargeIncome",cJSON_CreateDoubleArray(0, months));
		cJSON_AddItemToObject(p_resp_data,"disChargeIncome",cJSON_CreateDoubleArray(0, months));
	}
	
	sqlite3_close(db);	 
}

/**
  * @brief  获取年收益
  * @param  [in] *p_nc 连接信息 
  * @param  [in] *p_msg  http请求信息
  * @return
  */
void get_yearly_charge_discharge_income(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_root = NULL;
    cJSON *p_resp_data = NULL;
    cJSON *p_resp_item = NULL;	
    uint8_t response[256] = {0};
    uint8_t *p_action = NULL;
	int32_t i = 0;
    uint8_t *p = NULL;
	uint8_t ymd[16] = {0};
    uint8_t request_body[128] = {0};
	energy_time_t energy_time;
		
	memcpy(request_body,p_msg->body.p,p_msg->body.len);	
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		SYS_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getYearChargeDischargeIncome"))
	{
		SYS_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    p = cJSON_GetObjectItem(p_request,"ymd")->valuestring;
	snprintf(ymd, sizeof(ymd),"%s",p);

    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        SYS_MANEGE_DEBUG_PRINT("create json obj failed.");
        return ;
    }

	cJSON_AddNumberToObject(p_resp_root,"code",OK);

	select_sqlite_db_year(ymd, p_resp_root);	

	cJSON_AddStringToObject(p_resp_root,"msg","get successful");
	p = cJSON_PrintUnformatted(p_resp_root);
	
	http_back(p_nc,p);
	cJSON_Delete(p_resp_root);
	free(p);	
}


static void query_total_charge(sqlite3 *db, data_energy_income_t *energy_data, int *len) 
{
    char sql[256];
	int32_t year = 0;
	int32_t i = 0;
	
    snprintf(sql, sizeof(sql), "SELECT strftime('%%Y', date), SUM(charge_income), SUM(discharge_income) FROM charge_data  GROUP BY strftime('%%Y', date);");
	sqlite3_stmt *stmt;
    sqlite3_prepare_v2(db, sql, -1, &stmt, 0);

    while (sqlite3_step(stmt) == SQLITE_ROW) 
	{
		if (i > STORAGE_TIME_LIMIT)
		{
			break;
		}
		year =  atoi(sqlite3_column_text(stmt, 0));
		energy_data->charge_income[i] = sqlite3_column_double(stmt, 1);
		energy_data->discharge_income[i] = sqlite3_column_double(stmt, 2);
		i++;
    }
	*len = i;
    sqlite3_finalize(stmt);
}

static int32_t select_sqlite_db_total(uint8_t *year, cJSON *p_resp_data)
{
	sqlite3 *db;
	int rc;
	data_energy_income_t energy_data;
    int32_t len = 0;
	
	rc = sqlite3_open("/user/data/energy/energy_income.db", &db);
	if(rc) 
	{
	   SYS_MANEGE_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
	   return(0);
	} 
	else 
	{
		memset(&energy_data, 0, sizeof(data_energy_income_t));

		query_total_charge(db, &energy_data, &len);
	
		// cJSON_AddItemToObject(p_resp_data,"chargeIncome",cJSON_CreateDoubleArray(energy_data.charge_income,len));
		// cJSON_AddItemToObject(p_resp_data,"disChargeIncome",cJSON_CreateDoubleArray(energy_data.discharge_income,len));
		cJSON_AddItemToObject(p_resp_data,"chargeIncome",cJSON_CreateDoubleArray(0, len));
		cJSON_AddItemToObject(p_resp_data,"disChargeIncome",cJSON_CreateDoubleArray(0, len));
	}
	
	sqlite3_close(db);	 
}

/**
  * @brief  获取总收益
  * @param  [in] *p_nc 连接信息 
  * @param  [in] *p_msg  http请求信息
  * @return
  */
void get_total_charge_discharge_income(struct mg_connection *p_nc,struct http_message *p_msg)
{
	cJSON *p_request = NULL;
	 cJSON *p_resp_root = NULL;
	 cJSON *p_resp_data = NULL;
	 cJSON *p_resp_item = NULL; 
	 uint8_t response[256] = {0};
	 uint8_t *p_action = NULL;
	 int32_t i = 0;
	 uint8_t *p = NULL;
	 uint8_t ymd[16] = {0};
	 uint8_t request_body[128] = {0};
	 energy_time_t energy_time;
		 
	 memcpy(request_body,p_msg->body.p,p_msg->body.len);
	 p_request = cJSON_Parse(request_body);
	 if(p_request == NULL)
	 {
		 SYS_MANEGE_DEBUG_PRINT("parse request failed.");
		 build_empty_response(response,Accepted,"parse request failed.");
		 http_back(p_nc,response);
		 return;
	 }
	 p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	 if(strcmp(p_action,"getTotalChargeDischargeIncome"))
	 {
		 SYS_MANEGE_DEBUG_PRINT("action is not right.");
		 build_empty_response(response,Non_Authoriative_Information,"action is not right");
		 http_back(p_nc,response);
		 cJSON_Delete(p_request);
		 return;
	 }
	 p = cJSON_GetObjectItem(p_request,"ymd")->valuestring;
	 snprintf(ymd, sizeof(ymd),"%s",p);
	
	 cJSON_Delete(p_request);
	
	 p_resp_root = cJSON_CreateObject();
	 if(p_resp_root == NULL)
	 {
		 SYS_MANEGE_DEBUG_PRINT("create json obj failed.");
		 return ;
	 }
	
	 cJSON_AddNumberToObject(p_resp_root,"code",OK);
	
	 select_sqlite_db_total(ymd, p_resp_root);	 
	
	 cJSON_AddStringToObject(p_resp_root,"msg","get successful");
	 p = cJSON_PrintUnformatted(p_resp_root);
	 
	 http_back(p_nc,p);
	 cJSON_Delete(p_resp_root);
	 free(p);

}


/**
 * @brief  同步EMS参数，断电记忆回复
 * @return none
 */
void ems_param_update()
{
    internal_shared_data_t *p_internal_data = NULL;
	update_ems_time_attr();
	update_ems_price_attr();

    //读取当前数据作为基数
	p_internal_data = sdk_shm_internal_shared_data_get();
    while((p_internal_data->total_realtime_energy.meter_energy_charge == 0) && (p_internal_data->total_realtime_energy.meter_energy_discharge == 0))
    {
        sleep(1);
    }
    meter_energy_last.meter_energy_charge = p_internal_data->total_realtime_energy.meter_energy_charge;
    meter_energy_last.meter_energy_discharge = p_internal_data->total_realtime_energy.meter_energy_discharge;    
}

/**
 * @brief  获取当前小时的数据库数据，如果有则作为基质，否则读取电池实时数据作为基值
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
int32_t select_charge_discharge(uint8_t *date, double *charge, double *discharge)
{
	sqlite3 *db;
	sqlite3_stmt *stmt;
	int32_t rc;
	int32_t i=0;
	uint8_t sql[256] = {0};

	rc = sqlite3_open("/user/data/energy/energy_income.db", &db);
	if( rc ) 
	{
	   printf("Can't open database: %s\n", sqlite3_errmsg(db));
	   return(0);
	} 
	else 
	{
		snprintf(sql, sizeof(sql), "SELECT strftime('%%Y', date), charge_income, discharge FROM discharge_income  WHERE date = '%s';",date);
		sqlite3_prepare_v2(db, sql, -1, &stmt, 0);

		while (sqlite3_step(stmt) == SQLITE_ROW) 
		{
			*charge = sqlite3_column_double(stmt, 1);
			*discharge = sqlite3_column_double(stmt, 2);
			i++;
		}
	}
	
    sqlite3_finalize(stmt);
	sqlite3_close(db);	
}


/**
 * @brief  循环获取每分钟充放电量进行计价处理
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
static void *ems_energy_get_loop(void *arg)
{
    uint8_t ret = 0;
    sdk_rtc_t now;
    uint8_t date[32]= {0};

	sleep(1);							// 线程,上电延时1s启动
	ems_param_update();
	create_energy_income_table();
	if (now.tm_hour)
	{
		snprintf(date, sizeof(date), "%04d-%02d-%02d %02d:00:00",now.tm_year + 2000,now.tm_mon,now.tm_day,now.tm_hour);
		select_charge_discharge(date, &energy_income.charge_income, &energy_income.discharge_income);
	}
	last_savetime = get_energy_time();
	while(1)
	{   	
        ems_energy_get_manage(); 
        usleep(2000 * 1000);				
	}

	pthread_exit(NULL);

}


/**
 * @brief  EMS循环获取充放电线程
 */
void ems_energy_get_thread(void)
{
	pthread_t ems_energy;
	pthread_attr_t attr;

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);

	if(pthread_create(&ems_energy,&attr,ems_energy_get_loop,NULL) != 0)
	{
		perror("pthread_create ems_energy_get_thread");
	}

	pthread_attr_destroy(&attr);
	return;
}


/**
 * @brief EMS管理模块初始化
 * @return void
 */
void web_ems_manage_module_init(void)
{
	if(!web_func_attach("/EMSManager/setEMSParam", TRANS_UNNEED, set_ems_param))	//设置EMS参数
	{
		SYS_MANEGE_DEBUG_PRINT("[/EMSManager/setEMSParam] attach failed");
	}
	if(!web_func_attach("/EMSManager/getEMSParam", TRANS_UNNEED, get_ems_param))	//获取EMS参数
	{
		SYS_MANEGE_DEBUG_PRINT("[/EMSManager/getEMSParam] attach failed");
	}
	if(!web_func_attach("/EMSManager/setEnergyPrice", TRANS_UNNEED, set_ems_energy_price_param))	//设置不同时段电价
	{
		SYS_MANEGE_DEBUG_PRINT("[/EMSManager/setEnergyPrice] attach failed");
	}
	if(!web_func_attach("/EMSManager/getEnergyPrice", TRANS_UNNEED, get_ems_energy_price_param))	//获取不同时段电价
	{
		SYS_MANEGE_DEBUG_PRINT("[/EMSManager/getEnergyPrice] attach failed");
	}
	if(!web_func_attach("/EMSManager/getEnergyPriceTrend", TRANS_UNNEED, get_ems_energy_price_trend))	//获取电价走势数据
	{
		SYS_MANEGE_DEBUG_PRINT("[/EMSManager/getEnergyPriceTrend] attach failed");
	}
	if(!web_func_attach("/EMSManager/getDailyChargeDischargeIncome", TRANS_UNNEED, get_daily_charge_discharge_income))	//获取每日充放电收益
	{
		SYS_MANEGE_DEBUG_PRINT("[/EMSManager/getDailyChargeDischargeIncome] attach failed");
	}
	if(!web_func_attach("/EMSManager/getMonthlyChargeDischargeIncome", TRANS_UNNEED, get_monthly_charge_discharge_income))	//获取每月充放电收益
	{
		SYS_MANEGE_DEBUG_PRINT("[/EMSManager/getMonthlyChargeDischargeIncome] attach failed");
	}
	if(!web_func_attach("/EMSManager/getYearChargeDischargeIncome", TRANS_UNNEED, get_yearly_charge_discharge_income))	//获取每年充放电收益
	{
		SYS_MANEGE_DEBUG_PRINT("[/EMSManager/getYearChargeDischargeIncome] attach failed");
	}
	if(!web_func_attach("/EMSManager/getTotalChargeDischargeIncome", TRANS_UNNEED, get_total_charge_discharge_income))	//获取总充放电收益
	{
		SYS_MANEGE_DEBUG_PRINT("[/EMSManager/getTotalChargeDischargeIncome] attach failed");
	}

    // ems_energy_get_thread();
}
