#include "web_broker.h"
#include "comm_manage.h"
#include "network/network.h"
#include "rs485/rs485.h"
#include "cloudcfg/cloud_cfg.h"

/**
 * @brief 通信管理模块初始化
 * @return void
 */
void web_comm_manage_module_init(void)
{
    //IP配置初始化
    network_ip_cfg_set();
    //网络通信IP初始化
	if(!web_func_attach("/CSUsystem/getNetworkPara", TRANS_UNNEED, get_network_sta))
	{
		COMM_MANEGE_DEBUG_PRINT("[/CSUsystem/getNetworkPara] attach failed");
	}
	if(!web_func_attach("/CSUsystem/dynamicNetwork", TRANS_UNNEED, set_network_dhcp))
	{
		COMM_MANEGE_DEBUG_PRINT("[/CSUsystem/dynamicNetwork] attach failed");
	}
	if(!web_func_attach("/CSUsystem/staticNetwork", TRANS_UNNEED, set_network_static))
	{
		COMM_MANEGE_DEBUG_PRINT("[/CSUsystem/staticNetwork] attach failed");
	}
    //RS485通信IP初始化
	if(!web_func_attach("/system/getComParam", TRANS_UNNEED, get_com_params))
	{
		COMM_MANEGE_DEBUG_PRINT("[/system/getComParam] attach failed");
	}
	if(!web_func_attach("/system/setComParam", TRANS_UNNEED, set_com_params))
	{
		COMM_MANEGE_DEBUG_PRINT("[/system/setComParam] attach failed");
	}
    //云平台服务初始化
   	if(!web_func_attach("/system/getCloudServer", TRANS_UNNEED, get_cloud_service_cfg))
	{
		COMM_MANEGE_DEBUG_PRINT("[/system/getCloudServer] attach failed");
	}
	if(!web_func_attach("/system/setCloudServer", TRANS_UNNEED, set_cloud_service_cfg))
	{
		COMM_MANEGE_DEBUG_PRINT("[/system/setCloudServer] attach failed");
	} 
    //modbus通信超时设置
    if(!web_func_attach("/system/setModbusTimeoutProtection", TRANS_UNNEED, set_modbus_recv_timeout))
	{
		COMM_MANEGE_DEBUG_PRINT("[/system/setModbusTimeoutProtection] attach failed");
	} 
    //modbus通信超时读取
    if(!web_func_attach("/system/getModbusTimeoutProtection", TRANS_UNNEED, get_modbus_recv_timeout))
	{
		COMM_MANEGE_DEBUG_PRINT("[/system/getModbusTimeoutProtection] attach failed");
	} 
    
	/* 获取对外通讯协议参数 */
	if(!web_func_attach("/system/getExternalCommunicationProtocol", TRANS_NEED, NULL ))
	{
		COMM_MANEGE_DEBUG_PRINT("[/system/getExternalCommunicationProtocol] attach failed");
	} 
	/* 获取对外通讯协议参数 */
	if(!web_func_attach("/system/setExternalCommunicationProtocol", TRANS_NEED, NULL ))
	{
		COMM_MANEGE_DEBUG_PRINT("[/system/setExternalCommunicationProtocol] attach failed");
	} 
}
