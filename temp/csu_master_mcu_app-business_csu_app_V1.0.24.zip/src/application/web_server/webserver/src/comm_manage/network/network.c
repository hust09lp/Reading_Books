#include "cJSON.h"
#include "network.h"
#include "common.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk/sdk_net_public.h"
#include "sdk_fs.h"
#include "comm_manage.h"
#include "operation_log.h"


#define DEV_NET_CFG   "/user/conf/net_cfg.json"
#define MODBUS_CFG   "/user/conf/modbus_timeout.json"

#define STATIC_MODE 0
#define DHCP_MODE   1


/**
 * @brief  保存CSU IP设置方式
 * @param  [in] ip_cfg 0:静态 1：动态
 * @return none
 */
void csu_net_cfg_save(uint8_t ip_cfg)
{
    cJSON *p_root = NULL;
    char *p_cfg = NULL;
    fs_t *p_fs = NULL;
    int ret = 0;

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        COMM_MANEGE_DEBUG_PRINT("json creat error.");
        return;
    }
    
    cJSON_AddNumberToObject(p_root, "cfgMode" , ip_cfg);

    p_cfg = cJSON_PrintUnformatted(p_root);
    if(p_cfg == NULL)
    {
        COMM_MANEGE_DEBUG_PRINT("json print error.");
        cJSON_Delete(p_root);
        return;
    }

    p_fs = sdk_fs_open((const int8_t *)DEV_NET_CFG, FS_CREATE_ALWAYS | FS_WRITE);
    if(p_fs == NULL)
    {
        COMM_MANEGE_DEBUG_PRINT("file open error.");
        cJSON_Delete(p_root);
        return;
    }
    /* 将位置偏移量移动到文件头 */
    sdk_fs_lseek(p_fs, 0 );
    sdk_fs_write(p_fs, p_cfg, strlen(p_cfg));

    cJSON_Delete(p_root);
    sdk_fs_close(p_fs);
    free(p_cfg);
}


/**
 * @brief  读取CSU IP设置方式,默认静态
 * @param
 * @return int 0:静态 1：动态
 */
int csu_net_cfg_get(void)
{
    char mode_cfg[64] = {0};
    cJSON *p_root = NULL;
    fs_t *p_fs = NULL;
    int ret = 0;
    int mode = 0;

    p_fs = sdk_fs_open((const int8_t *)DEV_NET_CFG, FS_READ);
    if (p_fs == NULL)
    {
        return STATIC_MODE;
    }

    /* 将位置偏移量移动到文件头 */
    ret = sdk_fs_lseek( p_fs, 0 );
    if (ret < 0)
    {
        return STATIC_MODE;
    }

    ret = sdk_fs_read(p_fs, mode_cfg, sizeof(mode_cfg));
    if ( ret <= 0 )
    {
        sdk_fs_close(p_fs);
        return STATIC_MODE;
    }

    p_root =  cJSON_Parse(mode_cfg);
    if (p_root == NULL)
    {
        sdk_fs_close(p_fs);
        return STATIC_MODE;
    }

    if(cJSON_GetObjectItem(p_root, "cfgMode") != NULL)
    {
        mode = cJSON_GetObjectItem(p_root, "cfgMode")->valueint;
    }
    sdk_fs_close(p_fs);
    cJSON_Delete(p_root);
    return mode;
}


/**
 * @brief  	获取动态IP地址
 * @return 	1:成功 0：失败
 */
uint8_t net_dynamic_ip_get(char *p_ip)
{
    char cmd[256] = {0};
    char tmp_buff[32] = {0};
    FILE *fp = NULL;
    uint8_t ret = 0;
    
    //获取IP地址
    snprintf(cmd, 256, "ip addr show eth1 | grep 'dynamic ' | awk '{print $2}' | cut -d/ -f1");
	fp = popen(cmd,"r");

    while (fgets(tmp_buff, sizeof(tmp_buff), fp));
    if(strlen(tmp_buff))
    {
        COMM_MANEGE_DEBUG_PRINT((int8_t *)"ip:%s", tmp_buff);
        memcpy(p_ip, tmp_buff, strlen(tmp_buff));
        ret = 1;
    }
    else
    {
        COMM_MANEGE_DEBUG_PRINT((int8_t *)"ip get error");
        ret = 0;
    }
    pclose(fp);

    return ret;
}




static void get_network_params(uint8_t device, uint8_t *mode,uint8_t *p_ip,uint8_t *p_netmask,uint8_t *p_gw,uint8_t *p_dns1,uint8_t *p_dns2)
{
    if(csu_net_cfg_get() == STATIC_MODE)
    {
        strcpy(mode,"static");
        if(sdk_net_ip_get(device, p_ip) < 0)
        {
            strncpy(p_ip, "0.0.0.0", strlen("0.0.0.0"));
            return;
        }
    }
    else if(csu_net_cfg_get() == DHCP_MODE)
    {
        strcpy(mode,"dynamic");
        if(net_dynamic_ip_get(p_ip) != 1)
        {
            if(sdk_net_ip_get(device, p_ip) < 0)
            {
                strncpy(p_ip, "0.0.0.0", strlen("0.0.0.0"));
                return;
            }
        }
    }
    
    if(sdk_net_subnetmask_get(device, p_netmask) < 0)
    {
        strncpy(p_netmask, "255.255.255.0", strlen("255.255.255.0"));
        return;
    }

    if(sdk_net_gateway_get(device, p_gw) < 0)
    {
        strncpy(p_gw, "0.0.0.0", strlen("0.0.0.0"));
        return;
    }

    if(sdk_net_dns_get(device, p_dns1) < 0)
    {
        strncpy(p_dns1, "0.0.0.0", strlen("0.0.0.0"));
        return;
    }

    //当前我们只支持一个DNS,第二个DNS目前暂时不支持,先固定写死
    strncpy(p_dns2, "202.96.128.86", strlen("202.96.128.86"));
}


static void modify_net_conf(uint8_t device,const uint8_t is_dhcp, uint8_t *p_ip, uint8_t *p_netmask, uint8_t *p_gw, uint8_t *p_dns1, uint8_t *p_dns2)
{
   if(is_dhcp == 1)
   {
		if (ETH1 == device)
		{
			 system("udhcpc -b -i eth1");
        	 return;		   
		}
        system("udhcpc -b -i eth0");
        return;
   }
   if(sdk_net_ip_set(device, p_ip) < 0)
   {
        COMM_MANEGE_DEBUG_PRINT("set ip failed");
        return;
   }

   if(sdk_net_subnetmask_set(device, p_netmask) < 0)
   {
        COMM_MANEGE_DEBUG_PRINT("set subnet mask failed");
        return;
   }

   if(sdk_net_gateway_set(device, p_gw) < 0)
   {
        COMM_MANEGE_DEBUG_PRINT("set gateway failed");
        return;
   }

   if(sdk_net_dns_set(device, p_dns1)< 0)
   {
        COMM_MANEGE_DEBUG_PRINT("set dns1 failed");
        return;
   }
   //我们目前暂不支持DNS2的配置,后续看情况如何将DNS用起来
}


/**
 * @brief    获取当前网络信息
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void get_network_sta(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_root = NULL;
    cJSON *p_resp_item = NULL;
    uint8_t response[256];
    uint8_t *p_action = NULL;
    uint8_t mode[32] = {0};
    uint8_t ip[32] = {0};
    uint8_t netmask[32] = {0};
    uint8_t gateway[32] = {0};
    uint8_t dns1[32] = {0};
    uint8_t dns2[32] = {0};
    uint8_t *p = NULL;
    uint8_t request_body[128] = {0};

    memcpy(request_body,p_msg->body.p,p_msg->body.len);	
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        COMM_MANEGE_DEBUG_PRINT("parse request failed.");
        build_empty_response(response,Accepted,"parse request failed.");
        http_back(p_nc,response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action,"getNetworkPara"))
    {
        COMM_MANEGE_DEBUG_PRINT("action is not right.");
        build_empty_response(response,Non_Authoriative_Information,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }

    cJSON_Delete(p_request);

	get_network_params(ETH1, mode, ip, netmask, gateway, dns1, dns2); //获取ethX接口的相关信息

    p_resp_item = cJSON_CreateObject();
    if(p_resp_item == NULL)
    {
        COMM_MANEGE_DEBUG_PRINT("create json obj failed.");
        return;
    }
    cJSON_AddStringToObject(p_resp_item,"confMode",mode);
    cJSON_AddStringToObject(p_resp_item,"ipAddr",ip);
    cJSON_AddStringToObject(p_resp_item,"netMask",netmask);
    cJSON_AddStringToObject(p_resp_item,"defaultGw",gateway);
    cJSON_AddStringToObject(p_resp_item,"dns1",dns1);
    cJSON_AddStringToObject(p_resp_item,"dns2",dns2);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        COMM_MANEGE_DEBUG_PRINT("create json obj failed.");
        cJSON_Delete(p_resp_item);
        return;
    }
    cJSON_AddNumberToObject(p_resp_root,"code",OK);
    cJSON_AddItemToObject(p_resp_root,"data",p_resp_item);
    cJSON_AddStringToObject(p_resp_root,"msg","get network parameter successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);
    cJSON_Delete(p_resp_root);
    free(p);
    http_back(p_nc,response);
}


/**
 * @brief    设置动态网络
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void set_network_dhcp(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    uint8_t response[128];
    uint8_t *p_action = NULL;
    uint8_t request_body[128] = {0};
    uint8_t cur_user[32] = {0};
	operation_log_t op_log;

    memcpy(request_body,p_msg->body.p,p_msg->body.len);	
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        COMM_MANEGE_DEBUG_PRINT("parse request failed.");
        build_empty_response(response,Accepted,"parse request failed.");
        http_back(p_nc,response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action,"dynamicNetwork"))
    {
        COMM_MANEGE_DEBUG_PRINT("action is not right.");
        build_empty_response(response,Non_Authoriative_Information,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }

    cJSON_Delete(p_request);

    system("/etc/init.d/S41dhcpcd restart");

	modify_net_conf(ETH1,1,NULL,NULL,NULL,NULL,NULL);
	
    init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"设置DHCP");
	strcpy(op_log.op_status,"success");
	add_one_op_log(&op_log);

    build_empty_response(response,OK,"set dynamic successful");
    http_back(p_nc,response);
    csu_net_cfg_save(DHCP_MODE);
}


/**
 * @brief    设置静态网络
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void set_network_static(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    uint8_t response[128];
    uint8_t *p_action = NULL;
    uint8_t *p_ip = NULL;
    uint8_t *p_netmask = NULL;
    uint8_t *p_gw = NULL;
    uint8_t *p_dns1 = NULL;
    uint8_t *p_dns2 = NULL;
    uint8_t request_body[256] = {0};
    uint8_t cur_user[32] = {0};
	operation_log_t op_log;
	
    memcpy(request_body,p_msg->body.p,p_msg->body.len);		
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        COMM_MANEGE_DEBUG_PRINT("parse request failed.");
        build_empty_response(response,Accepted,"parse request failed.");
        http_back(p_nc,response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action,"staticNetwork"))
    {
        COMM_MANEGE_DEBUG_PRINT("action is not right.");
        build_empty_response(response,Non_Authoriative_Information,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }

    p_ip = cJSON_GetObjectItem(p_request,"ipAddr")->valuestring;
    p_netmask = cJSON_GetObjectItem(p_request,"netMask")->valuestring;
    p_gw = cJSON_GetObjectItem(p_request,"defaultGw")->valuestring;
    p_dns1 = cJSON_GetObjectItem(p_request,"dns1")->valuestring;
    p_dns2 = cJSON_GetObjectItem(p_request,"dns2")->valuestring;

	modify_net_conf(ETH1, 0, p_ip, p_netmask, p_gw, p_dns1, p_dns2);	
    
    cJSON_Delete(p_request);

    init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg, cur_user);
	strcpy(op_log.user_name, cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"修改静态网络参数");
	strcpy(op_log.op_status,"success");
	add_one_op_log(&op_log);

    build_empty_response(response,OK,"set static  successful");
    http_back(p_nc,response);
    csu_net_cfg_save(STATIC_MODE);
}


/**
 * @brief    根据配置执行IP分配方式
 * @return
 */
void network_ip_cfg_set(void)
{
    if(csu_net_cfg_get() == DHCP_MODE)
    {
        system("/etc/init.d/S41dhcpcd restart");
        // system("start-stop-daemon -K -x /sbin/dhcpcd -p /var/run/dhcpcd/pid -o");
    }
}


/**
 * @brief  保存modbus超时参数
 * @param  [in]timeout：超时时间
 * @return none
 */
void modbus_recv_timeout_save(uint16_t timeout)
{
    cJSON *p_root = NULL;
    char *p_cfg = NULL;
    fs_t *p_fs = NULL;
    int ret = 0;

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        COMM_MANEGE_DEBUG_PRINT("json creat error.");
        return;
    }
    
    cJSON_AddNumberToObject(p_root, "Timeout" , timeout);

    p_cfg = cJSON_PrintUnformatted(p_root);
    if(p_cfg == NULL)
    {
        COMM_MANEGE_DEBUG_PRINT("json print error.");
        cJSON_Delete(p_root);
        return;
    }

    p_fs = sdk_fs_open((const int8_t *)MODBUS_CFG, FS_CREATE_ALWAYS | FS_WRITE);
    if(p_fs == NULL)
    {
        COMM_MANEGE_DEBUG_PRINT("file open error.");
        cJSON_Delete(p_root);
        return;
    }
    /* 将位置偏移量移动到文件头 */
    sdk_fs_lseek(p_fs, 0 );
    sdk_fs_write(p_fs, p_cfg, strlen(p_cfg));

    cJSON_Delete(p_root);
    sdk_fs_close(p_fs);
    free(p_cfg);
}


/**
 * @brief  保存modbus超时参数
 * @param
 * @return 超时时间
 */
uint16_t modbus_recv_timeout_get(void)
{
    char mode_cfg[64] = {0};
    cJSON *p_root = NULL;
    fs_t *p_fs = NULL;
    int ret = 0;
    int timeout = 0;

    p_fs = sdk_fs_open((const int8_t *)MODBUS_CFG, FS_READ);
    if (p_fs == NULL)
    {
        return 0;
    }

    /* 将位置偏移量移动到文件头 */
    ret = sdk_fs_lseek( p_fs, 0 );
    if (ret < 0)
    {
        return 0;
    }

    ret = sdk_fs_read(p_fs, mode_cfg, sizeof(mode_cfg));
    if ( ret <= 0 )
    {
        sdk_fs_close(p_fs);
        return 0;
    }

    p_root =  cJSON_Parse(mode_cfg);
    if (p_root == NULL)
    {
        sdk_fs_close(p_fs);
        return 0;
    }

    if(cJSON_GetObjectItem(p_root, "Timeout") != NULL)
    {
        timeout = cJSON_GetObjectItem(p_root, "Timeout")->valueint;
    }
    sdk_fs_close(p_fs);
    cJSON_Delete(p_root);
    return timeout;
}


/**
 * @brief    设置modbus接收数据超时
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void set_modbus_recv_timeout(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    uint8_t response[128];
    uint8_t *p_action = NULL;
    uint8_t request_body[256] = {0};
    internal_shared_data_t *p_shared_para = sdk_shm_internal_shared_data_get();
	
    memcpy(request_body,p_msg->body.p,p_msg->body.len);		
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        COMM_MANEGE_DEBUG_PRINT("parse request failed.");
        build_empty_response(response,Accepted,"parse request failed.");
        http_back(p_nc,response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action,"setModbusTimeoutProtection"))
    {
        COMM_MANEGE_DEBUG_PRINT("action is not right.");
        build_empty_response(response,Non_Authoriative_Information,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
    p_shared_para->modbus_recv_timeout = cJSON_GetObjectItem(p_request,"Timeout")->valueint;

    cJSON_Delete(p_request);

    build_empty_response(response,OK,"set static  successful");
    http_back(p_nc,response);
    modbus_recv_timeout_save(p_shared_para->modbus_recv_timeout);
}


/**
 * @brief    获取modbus接收数据超时
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void get_modbus_recv_timeout(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t response[128];
    uint8_t *p_action = NULL;
    uint8_t request_body[256] = {0};
    char *p = NULL;
    internal_shared_data_t *p_shared_para = sdk_shm_internal_shared_data_get();
	
    memcpy(request_body,p_msg->body.p,p_msg->body.len);		
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        COMM_MANEGE_DEBUG_PRINT("parse request failed.");
        build_empty_response(response,Accepted,"parse request failed.");
        http_back(p_nc,response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action,"getModbusTimeoutProtection"))
    {
        COMM_MANEGE_DEBUG_PRINT("action is not right.");
        build_empty_response(response,Non_Authoriative_Information,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }

    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        COMM_MANEGE_DEBUG_PRINT("create json obj failed.");
        cJSON_Delete(p_resp_root);
        return;
    }
    cJSON_AddNumberToObject(p_resp_root,"code",OK);
    cJSON_AddNumberToObject(p_resp_root,"Timeout",p_shared_para->modbus_recv_timeout);
    cJSON_AddStringToObject(p_resp_root,"msg","successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);
    cJSON_Delete(p_resp_root);
    free(p);
    http_back(p_nc,response);
}