#include "cJSON.h"
#include "common.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk/sdk_para.h"
#include "sdk/sdk_fs.h"
#include "comm_manage.h"
#include "operation_log.h"

#define MAX_TIMEZONE            25
#define CLOUD_CFG_PATH          "/user/conf/cloud_cfg.json"


static uint8_t g_cloud_cfg_set_reboot = 0;


/**
 * @brief    CSU升级检查重启
 * @return
 */
static void *check_for_reboot(void *arg)
{
	while(1)
	{
		if(g_cloud_cfg_set_reboot)
		{
            system("sync");
			system("reboot -f");
		}
        sleep(1);
	}
}


/**
 * @brief    获取云服务配置
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void get_cloud_service_cfg(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t response[256] = {0}; 
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t request_body[256] = {0};
    internal_shared_data_t *p_shared_para = sdk_shm_internal_shared_data_get();

    memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
    if (p_request == NULL)
	{
		COMM_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"getCloudServer"))
	{
		COMM_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

    COMM_MANEGE_DEBUG_PRINT("sofar cloud service: %d", p_shared_para->sofar_cloud_enable);
    COMM_MANEGE_DEBUG_PRINT("zcs cloud service: %d", p_shared_para->zcs_cloud_enable);

    p_resp_root = cJSON_CreateObject();
    if (p_resp_root == NULL)
    {
        COMM_MANEGE_DEBUG_PRINT("create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code", OK);
	cJSON_AddNumberToObject(p_resp_root,"sofarCloud", p_shared_para->sofar_cloud_enable);
    cJSON_AddNumberToObject(p_resp_root,"SofarCloudActive", p_shared_para->sofar_cloud_stage);
	cJSON_AddNumberToObject(p_resp_root,"zcsCloud", p_shared_para->zcs_cloud_enable);
    cJSON_AddNumberToObject(p_resp_root,"ZCSCloudActive", p_shared_para->zcs_cloud_stage);
    cJSON_AddStringToObject(p_resp_root,"msg","get successful");
	
    p = cJSON_PrintUnformatted(p_resp_root);
    http_back(p_nc,p);
	cJSON_Delete(p_resp_root);
	free(p);
}

/**
 * @brief    设置云服务配置
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void set_cloud_service_cfg(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;	
    cJSON *p_cfg = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t response[1024]; 
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t request_body[512] = {0};
	operation_log_t op_log;
	uint8_t cur_user[32] = {0};	
    FILE *fp = NULL;
    uint8_t cfg_buff[256] = {0};
    uint8_t sofar_enable = 0, zcs_enable = 0;
    uint8_t sofar_set_enable = 0, zcs_set_enable = 0;
    pthread_t tid;
    pthread_attr_t attr;

    internal_shared_data_t *p_shared_para = sdk_shm_internal_shared_data_get();
    memcpy(request_body,p_msg->body.p,p_msg->body.len);	
	p_request = cJSON_Parse(request_body);
    if (p_request == NULL)
	{
		COMM_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"setCloudServer"))
	{
		COMM_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    if(NULL != cJSON_GetObjectItem(p_request,"sofarCloud"))
    {
        sofar_enable = cJSON_GetObjectItem(p_request,"sofarCloud")->valueint;
        if(sofar_enable != p_shared_para->sofar_cloud_enable)
        {
            sofar_set_enable = 1;
        }
    }
    if(NULL != cJSON_GetObjectItem(p_request,"zcsCloud"))
    {
        zcs_enable = cJSON_GetObjectItem(p_request,"zcsCloud")->valueint;
        if(zcs_enable != p_shared_para->zcs_cloud_enable)
        {
            zcs_set_enable = 1;
        }
    }
    cJSON_Delete(p_request);
    if((sofar_set_enable == 0) && (zcs_set_enable == 0))
    {
        COMM_MANEGE_DEBUG_PRINT("param not change!");
		build_empty_response(response, 600, "cloud service set failed");
		http_back(p_nc,response);
        return;
    }

	p_cfg = cJSON_CreateObject();
	if(p_cfg == NULL)
	{
        COMM_MANEGE_DEBUG_PRINT("create json obj failed");
        return;
	}

    if(sofar_set_enable)
    {
        cJSON_AddNumberToObject(p_cfg,"sofar", sofar_enable);
        init_user_basic_info(&op_log);
        get_user_from_http_request(p_msg, cur_user);
        strcpy(op_log.user_name, cur_user);
        get_user_basic_info(&op_log);
        strcpy(op_log.op_type, "sofar云平台服务使能");
        op_log.op_param1 = p_shared_para->sofar_cloud_enable;
        op_log.op_param2 = sofar_enable;
        strcpy(op_log.op_status, "success");
        add_one_op_log(&op_log);
    }
    else
    {
        cJSON_AddNumberToObject(p_cfg,"sofar", p_shared_para->sofar_cloud_enable);
    }
    
    if(zcs_set_enable)
    {
        cJSON_AddNumberToObject(p_cfg,"zcs", zcs_enable);
        init_user_basic_info(&op_log);
        get_user_from_http_request(p_msg, cur_user);
        strcpy(op_log.user_name, cur_user);
        get_user_basic_info(&op_log);
        strcpy(op_log.op_type, "zcs云平台服务使能");
        op_log.op_param1 = p_shared_para->zcs_cloud_enable;
        op_log.op_param2 = zcs_enable;
        strcpy(op_log.op_status, "success");
        add_one_op_log(&op_log);
    }
    else
    {
        cJSON_AddNumberToObject(p_cfg,"zcs", p_shared_para->zcs_cloud_enable);
    }
	p = cJSON_PrintUnformatted(p_cfg);

	fp = fopen(CLOUD_CFG_PATH,"w");
	if(fp == NULL)
	{
		COMM_MANEGE_DEBUG_PRINT("open [%s] failed.", CLOUD_CFG_PATH);
        cJSON_Delete(p_cfg);
	    free(p);
		return;
	}
	fwrite(p,1,strlen(p),fp);
	fclose(fp);
	cJSON_Delete(p_cfg);
	free(p);

    p_resp_root = cJSON_CreateObject();
    if (p_resp_root == NULL)
    {
        COMM_MANEGE_DEBUG_PRINT("create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",OK);
    cJSON_AddStringToObject(p_resp_root,"msg","set successful");
	
    p = cJSON_PrintUnformatted(p_resp_root);
    http_back(p_nc,p);
	free(p);
	cJSON_Delete(p_resp_root);

    g_cloud_cfg_set_reboot = 1;
    pthread_create(&tid, NULL,check_for_reboot,NULL);

}
