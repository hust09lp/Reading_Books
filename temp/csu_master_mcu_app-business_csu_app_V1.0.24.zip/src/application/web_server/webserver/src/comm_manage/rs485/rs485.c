#include "cJSON.h"
#include "common.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk/sdk_para.h"
#include "comm_manage.h"
#include "operation_log.h"
#include "rs485.h"

/**
 * @brief    读取485通信参数
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void get_com_params(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_item = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t response[256]; 
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t request_body[64] = {0};
	other_parameter_data_t *other_parame = sdk_shm_other_parameter_data_get();

    memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
    if (p_request == NULL)
	{
		COMM_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"getComParam"))
	{
		COMM_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);


    p_resp_root = cJSON_CreateObject();
    if (p_resp_root == NULL)
    {
        COMM_MANEGE_DEBUG_PRINT("create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",OK);

    p_resp_item = cJSON_CreateObject();
    if (p_resp_item == NULL)
    {
    	cJSON_Delete(p_resp_root);
        COMM_MANEGE_DEBUG_PRINT("create json obj failed.");
        return;
    }

	cJSON_AddNumberToObject(p_resp_item,"addressRS485_4",other_parame->address_rs485_4);
	cJSON_AddNumberToObject(p_resp_item,"baudRateRS485_4",other_parame->baud_rate_rs485_4);
	cJSON_AddNumberToObject(p_resp_item,"stopBitRS485_4",other_parame->stop_bit_rs485_4);
	cJSON_AddNumberToObject(p_resp_item,"checkBitRS485_4",other_parame->check_bit_rs485_4);
	
	cJSON_AddNumberToObject(p_resp_item,"addressRS485_6",other_parame->address_rs485_6);
	cJSON_AddNumberToObject(p_resp_item,"baudRateRS485_6",other_parame->baud_rate_rs485_6);
	cJSON_AddNumberToObject(p_resp_item,"stopBitRS485_6",other_parame->stop_bit_rs485_6);
	cJSON_AddNumberToObject(p_resp_item,"checkBitRS485_6",other_parame->check_bit_rs485_6);

	cJSON_AddItemToObject(p_resp_root,"data",p_resp_item); 
    cJSON_AddStringToObject(p_resp_root,"msg","get successful");
	
    p = cJSON_PrintUnformatted(p_resp_root);
    http_back(p_nc,p);
	cJSON_Delete(p_resp_root);
	free(p);
	
}

/**
 * @brief    设置485通信参数
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void set_com_params(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_data = NULL;	
    cJSON *p_resp_item = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t response[1024]; 
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
	uint8_t flag;
	uint16_t len;
	uint16_t result;
	uint8_t ret;
    uint8_t request_body[64] = {0};
	uint32_t value_int = 0;
	operation_log_t op_log;
	uint8_t cur_user[32] = {0};	
	other_parameter_data_t other_parameter_data;

	other_parameter_data_t *p_other_parameter_data = sdk_shm_other_parameter_data_get();
	web_control_info_t *sdk_shm_web_data = sdk_shm_web_control_data_get();
	
    memcpy(request_body,p_msg->body.p,p_msg->body.len);	
	p_request = cJSON_Parse(request_body);
    if (p_request == NULL)
	{
		COMM_MANEGE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	if ((NULL == cJSON_GetObjectItem(p_request,"action")) || (NULL == cJSON_GetObjectItem(p_request,"data")))
	{
		COMM_MANEGE_DEBUG_PRINT("parameter is not right.");
		build_empty_response(response,Non_Authoriative_Information,"parameter is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}	
	
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if (strcmp(p_action,"setComParam"))
	{
		COMM_MANEGE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

	p_data = cJSON_GetObjectItem(p_request,"data");

	if((NULL != cJSON_GetObjectItem(p_data,"addressRS485_4")) && ( NULL != cJSON_GetObjectItem(p_data,"baudRateRS485_4")) && ( NULL !=  cJSON_GetObjectItem(p_data,"stopBitRS485_4")) && ( NULL != cJSON_GetObjectItem(p_data,"checkBitRS485_4")))
	{
		flag = 0;
		value_int = cJSON_GetObjectItem(p_data,"addressRS485_4")->valueint;
		if (p_other_parameter_data->address_rs485_4 != value_int)
		{
			p_other_parameter_data->address_rs485_4 = value_int;
			flag = 1;
		}
		value_int = cJSON_GetObjectItem(p_data,"baudRateRS485_4")->valueint;
		if (p_other_parameter_data->baud_rate_rs485_4 != value_int)
		{
			p_other_parameter_data->baud_rate_rs485_4 = value_int;
			flag = 1;
		}		
		value_int = cJSON_GetObjectItem(p_data,"stopBitRS485_4")->valueint;
		if (p_other_parameter_data->stop_bit_rs485_4 != value_int)
		{
			p_other_parameter_data->stop_bit_rs485_4 = value_int;
			flag = 1;
		}
		value_int = cJSON_GetObjectItem(p_data,"checkBitRS485_4")->valueint;
		if (p_other_parameter_data->check_bit_rs485_4 != value_int)
		{
			p_other_parameter_data->check_bit_rs485_4 = value_int;
			flag = 1;
		}		

		if (flag = 1)
		{
			sdk_shm_web_data->other_parameter_update_flag[0] = 1;
		}
	}

	if((NULL != cJSON_GetObjectItem(p_data,"addressRS485_6")) && ( NULL != cJSON_GetObjectItem(p_data,"baudRateRS485_6")) && ( NULL !=  cJSON_GetObjectItem(p_data,"stopBitRS485_6")) && ( NULL != cJSON_GetObjectItem(p_data,"checkBitRS485_6")))
	{
		flag = 0;
		value_int = cJSON_GetObjectItem(p_data,"addressRS485_6")->valueint;
		if (p_other_parameter_data->address_rs485_6 != value_int)
		{
			flag = 1;
		}
		p_other_parameter_data->address_rs485_6 = value_int;
		
		value_int = cJSON_GetObjectItem(p_data,"baudRateRS485_6")->valueint;
		if (p_other_parameter_data->baud_rate_rs485_6 != value_int)
		{
			flag = 1;
		}
		p_other_parameter_data->baud_rate_rs485_6 = value_int;
		
		value_int = cJSON_GetObjectItem(p_data,"stopBitRS485_6")->valueint;
		if (p_other_parameter_data->stop_bit_rs485_6 != value_int)
		{
			flag = 1;
		}
		p_other_parameter_data->stop_bit_rs485_6 = value_int;
		
		value_int = cJSON_GetObjectItem(p_data,"checkBitRS485_6")->valueint;
		if (p_other_parameter_data->check_bit_rs485_6 != value_int)
		{
			flag = 1;
		}		
		p_other_parameter_data->check_bit_rs485_6 = value_int;
		
		if (flag = 1)
		{
			sdk_shm_web_data->other_parameter_update_flag[1] = 1;
		}
	}

	
   cJSON_Delete(p_request);

	init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"修改通讯参数");
	strcpy(op_log.op_status,"success");
	add_one_op_log(&op_log);
	 
    p_resp_root = cJSON_CreateObject();
    if (p_resp_root == NULL)
    {
        COMM_MANEGE_DEBUG_PRINT("create json obj failed");
        return;
    }

    cJSON_AddNumberToObject(p_resp_root,"code",OK);
    cJSON_AddStringToObject(p_resp_root,"msg","set successful");
	
    p = cJSON_PrintUnformatted(p_resp_root);
    http_back(p_nc,p);
	free(p);
	cJSON_Delete(p_resp_root);
}

