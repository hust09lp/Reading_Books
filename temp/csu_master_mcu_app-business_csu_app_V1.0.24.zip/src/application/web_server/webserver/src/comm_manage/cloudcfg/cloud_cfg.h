#ifndef __CLOUD_CFG_H__
#define __CLOUD_CFG_H__

#include"mongoose.h"


/**
 * @brief    设置云服务配置
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void set_cloud_service_cfg(struct mg_connection *p_nc,struct http_message *p_msg);

/**
 * @brief    获取云服务配置
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void get_cloud_service_cfg(struct mg_connection *p_nc,struct http_message *p_msg);

#endif