#ifndef __NETWORK_H__
#define __NETWORK_H__

#include"mongoose.h"

/**
 * @brief    获取当前用户数量
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void get_network_sta(struct mg_connection *p_nc,struct http_message *p_msg);

/**
 * @brief    获取当前用户数量
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void set_network_dhcp(struct mg_connection *p_nc,struct http_message *p_msg);

/**
 * @brief    获取当前用户数量
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void set_network_static(struct mg_connection *p_nc,struct http_message *p_msg);

/**
 * @brief    根据配置执行IP分配方式
 * @return
 */
void network_ip_cfg_set(void);

/**
 * @brief    设置modbus接收数据超时
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void set_modbus_recv_timeout(struct mg_connection *p_nc,struct http_message *p_msg);

/**
 * @brief    获取modbus接收数据超时
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void get_modbus_recv_timeout(struct mg_connection *p_nc,struct http_message *p_msg);

#endif