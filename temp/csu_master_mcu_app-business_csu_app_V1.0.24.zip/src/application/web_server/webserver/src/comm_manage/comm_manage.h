#ifndef __COMM_MANAGE_H__
#define __COMM_MANAGE_H__

#include "mongoose.h"
#include "component/sofar_log.h"

#if (1)
#define COMM_MANEGE_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else
#define COMM_MANEGE_DEBUG_PRINT(...) {do {} while(0);}
#endif


/**
 * @brief 通信管理模块初始化
 * @return void
 */
void web_comm_manage_module_init(void);

#endif
