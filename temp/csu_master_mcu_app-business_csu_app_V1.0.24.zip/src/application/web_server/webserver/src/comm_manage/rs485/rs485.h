#ifndef __RS485_H__
#define __RS485_H__

#include"mongoose.h"

/**
 * @brief    获取当前用户数量
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void get_com_params(struct mg_connection *p_nc,struct http_message *p_msg);

/**
 * @brief    获取当前用户数量
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void set_com_params(struct mg_connection *p_nc,struct http_message *p_msg);

#endif