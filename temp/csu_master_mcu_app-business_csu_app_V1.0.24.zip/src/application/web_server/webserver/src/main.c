#include <openssl/md5.h>
#include "component/sofar_log.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "common.h"
#include "mongoose.h"
#include "cJSON.h"
#include "upgrade.h"
#include "web_data_trans2cmu.h"
#include "web_broker.h"
#include "user_manage.h"
#include "comm_manage.h"
#include "params_info.h"
#include "systime.h"
#include "sys_manage.h"
#include "ems_manage.h"
#include "sys_control.h"
#include "box_transformer.h"
#include "sys_state.h"
#include "cmu_data_monitor.h"
#include "csu_state_monitor.h"
#include "sys_log.h"
#include "energy_manage.h"
#include "fault_recorder.h"


#define HTTP_SERVER_ADDR "0.0.0.0:80"   //2023.5.4修改，避免与梁工的端口冲突
#define HTTPS_SERVER_ADDR "0.0.0.0:443"
struct mg_serve_http_opts web_server_opts;
pthread_mutex_t g_upgrade_mtx = PTHREAD_MUTEX_INITIALIZER;  //升级过程中的互斥锁,用来控制进度


static void ev_handler(struct mg_connection *p_nc,int ev,void *p_ev_data)
{
	uint8_t ret = 0;
	struct http_message *p_msg;
	struct mg_http_multipart_part *mp;
	struct mg_str mime_type = {"application/octet-stream",24};
	struct mg_str extra_headers = {0};


	if(ev == MG_EV_HTTP_REQUEST)
	{
		p_msg = (struct http_message *)p_ev_data;
		ret = web_func_execute(p_nc, p_msg);
		if(!ret)
		{
			if (mg_vcmp(&p_msg->uri,"/download/mcu2log") == 0)             			//传输mcu2故障log
			{
				mg_http_serve_file(p_nc, p_msg, "/opt/data/recorder/mcu2_fault_recorder", mime_type, extra_headers);
			}
			else if (mg_vcmp(&p_msg->uri,"/download/mcu2optlog") == 0)             	//传输mcu2操作log
			{
				mg_http_serve_file(p_nc, p_msg, "/opt/data/recorder/mcu2_opt_recorder", mime_type, extra_headers);
			}
			else if (mg_vcmp(&p_msg->uri,"/download/mcu2debuglog") == 0)             	//传输mcu2运行log
			{
				mg_http_serve_file(p_nc, p_msg, "/opt/data/recorder/mcu2_debug_recorder", mime_type, extra_headers);
			}
            else if (mg_vcmp(&p_msg->uri,"/download/PCSFaultRecorder.tar.gz") == 0) 
			{
				mg_http_serve_file(p_nc, p_msg, "/tmp/PCSFaultRecorder.tar.gz", mime_type, extra_headers);
			}
            else if (mg_vcmp(&p_msg->uri,"/download/CMUFaultRecorder.tar.gz") == 0) 
			{
				mg_http_serve_file(p_nc, p_msg, "/tmp/CMUFaultRecorder.tar.gz", mime_type, extra_headers);
			}
			else
			{
				mg_serve_http(p_nc,p_msg,web_server_opts);
			}
		}
	}
}

void file_init()
{
	if(access(WEB_CONF_PATH,F_OK) != 0)  //目录不存在
	{
		mkdir(WEB_CONF_PATH,0755);
	}

	//第一次烧录的时候,烧录包里面没有带administrator.json文件, 需要从/user/www/conf/default_config拷贝到/user/www/conf/作为默认配置
	if(access(ADMIN_JSON_FILE,F_OK) != 0)
	{
		system("cp /user/www/conf/default_config/administrator.json /user/www/conf/");
	}

	//第一次烧录的时候,烧录包里面没有带systime.json文件,需要从/user/www/conf/default_config拷贝到/user/www/conf/作为默认配置
	if(access(SYSTIME_JSON_FILE,F_OK) != 0)
	{
		system("cp /user/www/conf/default_config/systime.json /user/www/conf/");
	}

	//第一次烧录的时候,烧录包里面没有带runtimeparams.json文件,需要从/user/www/conf/default_config拷贝到/user/www/conf/作为默认配置
	if(access(RUNTIME_PARAMS_JSON_FILE,F_OK) != 0)
	{
		system("cp /user/www/conf/default_config/runtimeparams.json /user/www/conf/");
	}

	if(access(WEB_UPLOAD_DIR,F_OK) != 0)  //目录不存在
	{
		system("mkdir -p /tmp/upload");
	 //   mkdir(WEB_UPLOAD_DIR,0755);
	}
}


/**
 * @brief WEB功能模块初始化
 * @return void
 */
void web_func_module_init(void)
{
	//用户管理模块初始化
	web_user_manage_module_init();
	//系统时间模块初始化
	web_sys_time_module_init();
	//通信管理模块初始化
	web_comm_manage_module_init();
	//升级模块初始化
	web_upgrade_module_init();
	//参数设置模块初始化
	web_param_info_module_init();
	//系统管理模块初始化
	web_sys_manage_module_init();
	//EMS管理模块初始化
	web_ems_manage_module_init();
	//电量管理模块初始化
	web_energy_manage_module_init();
	//系统控制模块初始化
	web_sys_control_module_init();
	//箱变模块初始化
	web_box_transformer_module_init();
	//系统状态模块初始化
	web_sys_state_module_init();
	//系统日志模块初始化
	web_sys_log_module_init();
	//CMU实时数据获取模块初始化
	cmu_data_monitor_module_init();
	//CSU状态检测模块初始化
	csu_state_monitor_module_init();
    //故障录波模块初始化
    web_fault_recorder_module_init();

	//数据转发模块初始化
	web_trans2cmu_module_init();
}


int main()
{
	struct mg_mgr mgr;
	struct mg_connection *p_nc;
	struct mg_bind_opts bind_opts;
	int32_t ret;

	uint8_t use_https = 0; //we now use http

	log_init(PATH_CONF);
    log_set_level(LOG_LVL_DEBUG);

	mg_mgr_init(&mgr,NULL);
	memset(&bind_opts,0,sizeof(struct mg_bind_opts));

	if(use_https == 0)
	{
		p_nc = mg_bind(&mgr,HTTP_SERVER_ADDR,ev_handler);
	}
	else
	{
		p_nc = mg_bind_opt(&mgr,HTTPS_SERVER_ADDR,ev_handler,bind_opts);
	}
	if(p_nc == NULL)
	{
		log_e("init net connection failed");
		mg_mgr_free(&mgr);
		return -1;
	}

	mg_set_protocol_http_websocket(p_nc);

	if(access(WEB_HOME_PATH,F_OK) != 0)  //目录不存在
	{
		log_e("htdocs directory is not exist\n");
		mg_mgr_free(&mgr);
		return 0;
	}

	web_server_opts.document_root = WEB_HOME_PATH;
	web_server_opts.enable_directory_listing = "yes";

	mg_register_http_endpoint(p_nc, "/upload", upgrade_file_upload);
	mg_set_protocol_http_websocket(p_nc);
	mg_register_http_endpoint(p_nc, "/SafetUpload", safety_file_upload);
	mg_set_protocol_http_websocket(p_nc);


	file_init();

	pthread_mutex_init(&g_upgrade_mtx,NULL);  //初始化互斥锁

	ret = common_data_init();  //初始化并获取共享内存数据
	if(ret != 0)
	{
		mg_mgr_free(&mgr);
		pthread_mutex_destroy(&g_upgrade_mtx);  //销毁互斥锁
		return 0;
	}

	//web功能代理模块初始化
	web_broker_module_init();

	//web功能模块初始化
	web_func_module_init();

	// 获取容测模式初始化
	get_cmu_cap_test_init();
	while(1)
	{
		mg_mgr_poll(&mgr,500);
	}
	mg_mgr_free(&mgr);
	pthread_mutex_destroy(&g_upgrade_mtx);  //销毁互斥锁
	return 0;
}

