#ifndef __CMU_DATA_MONITOR_H__
#define __CMU_DATA_MONITOR_H__

#include"mongoose.h"
#include "component/sofar_log.h"

#if (1)
#define DATA_MONITOR_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else
#define DATA_MONITOR_DEBUG_PRINT(...) {do {} while(0);}
#endif

typedef struct{ 
    int32_t bus_side_vol;
    double total_power;             //总功率
    int16_t grid_volt_rs;		    //PCS线电压RS
	int16_t grid_volt_st;			//PCS线电压ST
	int16_t grid_volt_tr;			//PCS线电压TR
    uint8_t online;
    uint8_t dev_num;
}sub_matrix_info_t;                 // 子阵系统数据


/**
 * @brief    设备是否在线
 * @param	 [in] dev_num CMU序号
 * @return   true:在线 false:离线
 */
bool dev_is_online(uint8_t dev_num);

/**
 * @brief    获取子阵数据
 * @return 
 */
sub_matrix_info_t *get_sub_matrix_info(void);


/**
 * @brief    CMU数据实时检测模块初始化
 */
void cmu_data_monitor_module_init(void);
#endif