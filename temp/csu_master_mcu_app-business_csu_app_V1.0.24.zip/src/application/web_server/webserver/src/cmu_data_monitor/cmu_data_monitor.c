#include "cJSON.h"
#include "common.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "libghttp.h"
#include "app_common.h"
#include "web_data_trans2cmu.h"
#include "cmu_data_monitor.h"
#include "sys_state.h"
#include "web_broker.h"

#define CMU_ACK_MISS_MAX_CNT    4
static sub_matrix_info_t sub_matrix_info[MAX_SLAVE_COUNT] = {0};
static uint8_t cmu_ip_tbl[MAX_SLAVE_COUNT][MAX_IP_LEN] = {CMU1_IP, CMU2_IP, CMU3_IP, CMU4_IP, CMU5_IP, CMU6_IP};


/**
 * @brief    设备是否在线
 * @param	 [in] dev_num CMU序号
 * @return   true:在线 false:离线
 */
bool dev_is_online(uint8_t dev_num)
{
    if(sub_matrix_info[dev_num - 1].online)
    {
        return true;
    }
    return false;
}


/**
 * @brief    获取单个子设备功率
 * @param	 [in] dev_num CMU序号
 * @return   power
 */
int32_t get_dev_power(uint8_t dev_num)
{
    return sub_matrix_info[dev_num - 1].total_power;
}


/**
 * @brief    获取子阵数据
 * @return 
 */
sub_matrix_info_t *get_sub_matrix_info(void)
{
    return &sub_matrix_info[0];
}

/**
 * @brief 定时循环获取子阵信息
 */
static void get_cmu_sub_matrix_info_loop(void)
{
    uint8_t uri[] = {"/homePage/getSubMatrixInfo"};
    uint8_t json_str[] = {"{\"action\":\"getSubMatrixInfo\"}"};    

    uint8_t ret = 0;
    uint8_t url[128] = {0};
    uint8_t response[1024];
    uint16_t sys_status = 0;
    cJSON *p_response = NULL;
    static uint8_t ack_miss_cnt[MAX_SLAVE_COUNT] = {0};
    internal_shared_data_t *p_internal_shared_data = sdk_shm_internal_shared_data_get();

    for(uint8_t dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
    {
        // 打包URL
        sprintf(url, "%s%s%s", "http://", cmu_ip_tbl[dev_num - 1], uri);
        // IP获取接口暂未实现
        ret = http_net_post(url, json_str, response);
        if(ret != 1)
        {
            sub_matrix_info[dev_num - 1].bus_side_vol = 0;
            sub_matrix_info[dev_num - 1].total_power = 0;
            sub_matrix_info[dev_num - 1].dev_num = dev_num;
            if(ack_miss_cnt[dev_num -1] == CMU_ACK_MISS_MAX_CNT)
            {
                ack_miss_cnt[dev_num -1] = 0;
                sub_matrix_info[dev_num - 1].online = 0;
                p_internal_shared_data->cmu_sys_status[dev_num - 1] = 0xFF;
            }
            ack_miss_cnt[dev_num -1]++;
            continue;
        }
        else
        {
            // DATA_MONITOR_DEBUG_PRINT("response:%s", response);
            // 解析CMU数据
            p_response = cJSON_Parse(response);
            cJSON *data = cJSON_GetObjectItem(p_response, "data");
            cJSON *item = cJSON_GetArrayItem(data, 0);

            if(cJSON_GetObjectItem(item,"systemstatus") != NULL)
            {
                sys_status = cJSON_GetObjectItem(item,"systemstatus")->valueint;
                cmu_sys_status_set(dev_num, sys_status);
            }
            p_internal_shared_data->cmu_sys_status[dev_num - 1] = sys_status;
            sub_matrix_info[dev_num - 1].bus_side_vol = cJSON_GetObjectItem(item,"busSideVoltage")->valueint;
            sub_matrix_info[dev_num - 1].total_power = cJSON_GetObjectItem(item,"totalPower")->valuedouble;
            sub_matrix_info[dev_num - 1].grid_volt_rs = cJSON_GetObjectItem(item,"gridVoltRS")->valueint;
            sub_matrix_info[dev_num - 1].grid_volt_st = cJSON_GetObjectItem(item,"gridVoltST")->valueint;
            sub_matrix_info[dev_num - 1].grid_volt_tr = cJSON_GetObjectItem(item,"gridVoltTR")->valueint;
            sub_matrix_info[dev_num - 1].online = 1;
            sub_matrix_info[dev_num - 1].dev_num = dev_num;
            ack_miss_cnt[dev_num -1] = 0;
            cJSON_Delete(p_response);
        }
    }
}


/**
 * @brief 安规设置解析
 */
static void cmu_safety_setting_respond_parse(char *p_resp_str)
{
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_code_result_item = NULL;
    internal_shared_data_t *p_internal_shared_data = sdk_shm_internal_shared_data_get();

    p_root = cJSON_Parse(p_resp_str);
    if (p_root == NULL)
    {
        return;
    }

    if((200 != cJSON_GetObjectItem(p_root, "code" )->valueint) || (0 != strcmp( cJSON_GetObjectItem(p_root, "msg" )->valuestring, "successful" )))
    {
        cJSON_Delete(p_root);
        return;
    }

    p_data_item = cJSON_GetObjectItem(p_root, "Data");
    if(p_data_item == NULL)
    {
        cJSON_Delete(p_root);
        return;
    }

    if (0 != strcmp( cJSON_GetObjectItem(p_data_item, "code" )->valuestring, "safetyOverVol" ))
    {
        cJSON_Delete(p_root);
        return;
    }

    p_code_result_item = cJSON_GetObjectItem(p_data_item, "codeResult");
    if (p_code_result_item == NULL)
    {
        cJSON_Delete(p_root);
        return;
    }

    p_internal_shared_data->drmn_power_enable = ( 1 == cJSON_GetObjectItem(p_code_result_item, "RemoteConfig6" )->valueint )? 1: 0;
    cJSON_Delete(p_root);
    return;
}

/**
 * @brief 循环获取安规设置
 */
static void get_cmu_safety_setting_loop(void)
{
    uint8_t uri[] = {"/safetySetting/readSafetySettingDetail"};
    uint8_t json_str[] = {"{\"action\":\"readSafetySettingDetail\",\"cmdCode\":\"safetyOverVol\"}"};   
    uint8_t ret = 0;

    for( uint8_t dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++ )
    {
        if(sub_matrix_info[dev_num - 1].online)
        {
            uint8_t response[1024] = {0};
            uint8_t url[256] = {0};

            sprintf(url, "%s%s%s", "http://", cmu_ip_tbl[dev_num - 1], uri);
            ret = http_net_post(url, json_str, response);
            if(ret != 1)
            {
                continue;
            }
            cmu_safety_setting_respond_parse( response );
        }
    }
}

/**
 * @brief 定时循环获取电池充放电信息
 */
static void get_cmu_bat_charge_info_loop(void)
{
    uint8_t uri[] = {"/batteryInfo/getBatteryClusterChargeInfo"};
    uint8_t json_str[] = {"{\"action\":\"getBatteryClusterChargeInfo\"}"};   

    uint8_t ret = 0;
    uint8_t url[128] = {0};
    uint8_t response[1024] = {0};
    cJSON *p_response = NULL;

    bat_charge_data_t *bat_charge_data = sdk_shm_bat_charge_data_info_get();
    internal_shared_data_t *p_shared_data = sdk_shm_internal_shared_data_get();

  //  memset(bat_charge_data, 0, sizeof(bat_charge_data_t) * MAX_SLAVE_COUNT);

    for(uint8_t dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
    {
   //     memset(bat_charge_data[dev_num - 1].soc_soh_data, 0xFF, sizeof(bat_charge_data[dev_num - 1].soc_soh_data));
        if(sub_matrix_info[dev_num - 1].online)
        {
            // 打包URL
            sprintf(url, "%s%s%s", "http://", cmu_ip_tbl[dev_num - 1], uri);
            // IP获取接口暂未实现
            ret = http_net_post(url, json_str, response);
            if(ret != 1)
            {
                continue;
            }
            // DATA_MONITOR_DEBUG_PRINT("%s", response);
            // 解析CMU数据
            p_response = cJSON_Parse(response);
            if(p_response == NULL)
            {
                DATA_MONITOR_DEBUG_PRINT("parse request failed.");
                continue;
            }
            cJSON *data = cJSON_GetObjectItem(p_response, "data");
            if(data == NULL)
            {
                DATA_MONITOR_DEBUG_PRINT("parse data failed.");
                continue;
            }

            uint16_t array_size = cJSON_GetArraySize(data);
            if(array_size == 0)
            {
                DATA_MONITOR_DEBUG_PRINT("array size is error");
                cJSON_Delete(p_response);
                return;
            }

            uint16_t cluster_num = 0;

            // DATA_MONITOR_DEBUG_PRINT("size:%d", array_size);
            for (size_t i = 0; i < ARRAY_SIZE( bat_charge_data[dev_num - 1].soc_soh_data ); i++)
            {
                if ( i < array_size )
                {
                    cJSON *item = cJSON_GetArrayItem(data, i);
                    if((cJSON_GetObjectItem(item,"communicationSta")->valueint) == 1)
                    {
                        bat_charge_data[dev_num - 1].soc_soh_data[i].soc = cJSON_GetObjectItem(item,"soc")->valueint;
                        bat_charge_data[dev_num - 1].soc_soh_data[i].soh = cJSON_GetObjectItem(item,"soh")->valueint;
                        if(cJSON_GetObjectItem(item,"clusterCapEng") != NULL)
                        {
                            bat_charge_data[dev_num - 1].cluster_cap_energy = cJSON_GetObjectItem(item,"clusterCapEng")->valuedouble * 100;
                        }
                        cluster_num++;
                    }else if ((cJSON_GetObjectItem(item,"communicationSta")->valueint) == 0)
                    {
                        bat_charge_data[dev_num - 1].soc_soh_data[i].soc = 0xFFFF;
                        bat_charge_data[dev_num - 1].soc_soh_data[i].soh = 0xFFFF;
                    }
                } else {
                    bat_charge_data[dev_num - 1].soc_soh_data[i].soc = 0xFFFF;
                    bat_charge_data[dev_num - 1].soc_soh_data[i].soh = 0xFFFF;
                }
            }
            
            bat_charge_data[dev_num - 1].cluster_num        = cluster_num;
            
            bat_charge_data[dev_num - 1].charge_limit_power = cJSON_GetObjectItem(p_response,"chargeLimitPower")->valueint;
            bat_charge_data[dev_num - 1].discharge_limit_power = cJSON_GetObjectItem(p_response,"dischargeLimitPower")->valueint;
            bat_charge_data[dev_num - 1].charge_soc_limit = cJSON_GetObjectItem(p_response,"chargeSocLimit")->valueint;
            bat_charge_data[dev_num - 1].discharge_soc_lower_limit = cJSON_GetObjectItem(p_response,"dischargeSocLowerLimit")->valueint;
            bat_charge_data[dev_num - 1].charge_prohibit = cJSON_GetObjectItem(p_response,"chargeProhibit")->valueint;
            bat_charge_data[dev_num - 1].discharge_prohibit = cJSON_GetObjectItem(p_response,"dischargeProhibit")->valueint;

            if ( cJSON_GetObjectItem( p_response,"totalBatVol") != NULL ) 
            {
                bat_charge_data[dev_num - 1].total_vol  = cJSON_GetObjectItem( p_response,"totalBatVol")->valueint;
            }
            if ( cJSON_GetObjectItem( p_response,"totalBatCurr") != NULL ) 
            {
                bat_charge_data[dev_num - 1].total_curr = cJSON_GetObjectItem( p_response,"totalBatCurr")->valueint;
            }
            if(cJSON_GetObjectItem(p_response,"pcsChgLimitPower") != NULL)
            {
                bat_charge_data[dev_num - 1].pcs_chg_limit_power = cJSON_GetObjectItem(p_response,"pcsChgLimitPower")->valueint;
            }
            if(cJSON_GetObjectItem(p_response,"pcsDischgLimitPower") != NULL)
            {
                bat_charge_data[dev_num - 1].pcs_dischg_limit_power = cJSON_GetObjectItem(p_response,"pcsDischgLimitPower")->valueint;
            }
            if(cJSON_GetObjectItem(p_response,"packNum") != NULL)
            {
                p_shared_data->pack_num = cJSON_GetObjectItem(p_response,"packNum")->valueint;
            }
            cJSON_Delete(p_response);
        }
        else
        {
            for (size_t i = 0; i < ARRAY_SIZE( bat_charge_data[dev_num - 1].soc_soh_data ); i++)
            {
                bat_charge_data[dev_num - 1].soc_soh_data[i].soc = 0xFFFF;
                bat_charge_data[dev_num - 1].soc_soh_data[i].soh = 0xFFFF;
            }
        }
	}
}


/**
 * @brief 循环通知CSU信息
 */
static void post_csu_data_info_loop(void)
{
    char uri[] = "/postCsuDataInfo";
    cJSON *p_root = NULL;
    cJSON *p_power_item = NULL;
    char *p = NULL;
    constant_parameter_data_t *p_const_param = sdk_shm_constant_parameter_data_get();
    ems_data_t *p_ems_data = sdk_shm_ems_data_info_get();

    p_power_item = cJSON_CreateObject();
    if(p_power_item == NULL || p_ems_data == NULL)
    {
        return;
    }
    cJSON_AddNumberToObject(p_power_item, "activePower", p_const_param->cabinet_param_data.active_power / 10.0);
    
    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        cJSON_Delete(p_power_item);
    }
    cJSON_AddItemToObject(p_root, "PCS", p_power_item);
    if(p_ems_data->self_cosum_mode_enable == 1 || p_ems_data->shav_peak_fill_valley_en == 1)
    {
        cJSON_AddNumberToObject(p_root, "sleepDisable", 1);
    }
    else
    {
        cJSON_AddNumberToObject(p_root, "sleepDisable", 0);
    }

    p = cJSON_PrintUnformatted(p_root);
    cJSON_Delete(p_root);

    for( uint8_t dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
    {
        if(sub_matrix_info[dev_num - 1].online)
        {
            char url[100] = {0};
            char resp_str[300] = {0};

            sprintf(url, "http://%s%s", cmu_ip_tbl[dev_num - 1], uri);
            uint8_t ret = http_net_post(url, p, resp_str);
            if(ret != 1)
            {
                DATA_MONITOR_DEBUG_PRINT("[%s] post csu data to cmu[%d] error!!!\r\n", __FUNCTION__, dev_num);
                continue;
            }
        }
    }
    free(p);
}

/**
 * @brief  循环获取CMU信息线程
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
static void *cmu_data_monitor_func(void *arg)
{
    uint8_t ret = 0;

	sleep(1);							        // 线程,上电延时1s启动
	while(1)
	{   	
        get_cmu_sub_matrix_info_loop();        //子阵信息，判断CMU是否在线	
        get_cmu_bat_charge_info_loop();        //电池充放电信息，定时下发mcu2
        get_cmu_safety_setting_loop();          // 获取安规参数设置
        post_csu_data_info_loop();
        
		usleep(3000*1000);		
	}
	pthread_exit(NULL);
}


/**
 * @brief    CMU数据实时检测模块初始化
 */
void cmu_data_monitor_module_init(void)
{
	pthread_t sub_matrix;
	pthread_attr_t attr;

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);

	if(pthread_create(&sub_matrix, &attr, cmu_data_monitor_func, NULL) != 0)
	{
		perror("pthread_create thread_scicomm");
	}

	pthread_attr_destroy(&attr);
	return;
}
