#include "web_broker.h"
#include "list.h"
#include "web_data_trans2cmu.h"
#include"component/sofar_log.h"
#include "sdk_shm.h"
#include "cJSON.h"
#include "csu_comb_type.h"
#include "web_data_trans2slave.h"

#define URL_MAX_LEN     64

typedef struct{
    list_head_t tFunNode;               //fucntion链表节点信息
    uint8_t trans_flag;                 //转发标志，0：不需要转发 1：需要转发
    uint8_t url[URL_MAX_LEN];           //HTTP功能点对应的URL
    func_cb p_func_cb;                  //功能函数回调，功能模块按需注册进web代理
}function_node_t;


//组件链表头节点
static function_node_t g_web_func_list_head;


/**
 * @brief 功能链表节点加入
 *
 * @param [in] func_node : 节点
 * @param [in] p_list_head : 链表
 * 
 * @return 1:操作成功
 *         0:操作失败
 */
static uint8_t web_func_node_add(function_node_t func_node, function_node_t *p_list_head)
{
    function_node_t *p_node = NULL;
    
    p_node = (function_node_t *)malloc(sizeof(function_node_t));
    if(NULL == p_node)
    {
        log_e("malloc failed");
        return 0;
    }

    strcpy(p_node->url, func_node.url);
    p_node->trans_flag = func_node.trans_flag;
    p_node->p_func_cb = func_node.p_func_cb;

    list_add(&(p_node->tFunNode), &(p_list_head->tFunNode));
    
    return 1;
}


/**
 * @brief 判断是否需要主从机转发
 *
 * @retval uint8_t
 * @return 从机序号
 */
uint8_t get_slave_index(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    uint8_t request_body[1024 * 10] = {0};
    uint8_t slave_index = 0;
    list_head_t *ptPos = NULL;
    function_node_t *p_func_node = NULL;

    //这里要判断是否是发往从机的指令，因为注册的时候未设置转发，这里直接转发	
    memcpy(request_body, p_msg->body.p, p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		return 0;
	}

    if(cJSON_GetObjectItem(p_request, "slaveIndex") != NULL)
    {
        slave_index = cJSON_GetObjectItem(p_request, "slaveIndex")->valueint;
        if((slave_index > CSU_COMB_MAX_SLAVE_CNT) && (slave_index != 0xFF))
        {
            slave_index = 0;
        }
    }
    cJSON_Delete(p_request);

    return slave_index;
}

/**
 * @brief 功能注册
 *
 * @param [in] p_url : url
 * @param [in] trans_flag : 转发标志
 * @param [in] p_func_cb : 功能函数指针    
 * 
 * @retval uint8_t
 * @return 1:操作成功
 *         0:操作失败
 */
uint8_t web_func_attach(uint8_t *p_url, uint8_t trans_flag, func_cb p_func_cb)
{
    uint8_t ret = 0;
    function_node_t func_node;

    memset(&func_node, 0, sizeof(function_node_t));
    strcpy(func_node.url, p_url);
    func_node.trans_flag = trans_flag;
    func_node.p_func_cb = p_func_cb;

    //新func id插入链表
    ret = web_func_node_add(func_node, &g_web_func_list_head);
    if(!ret)
    {
        log_e("add url[%s]error", func_node.url);
        return 0;
    }
    log_i("add url[%s]success", func_node.url);
    
    return 1;
}

/**
 * @brief 功能执行
 * @param [in] p_url : url
 * @return 1:操作成功
 *         0:操作失败
 */
uint8_t web_func_execute(struct mg_connection *p_nc,struct http_message *p_msg)
{
    uint8_t slave_index = 0;
    list_head_t *ptPos = NULL;
    function_node_t *p_func_node = NULL;

    //如果处于主机模式，则获取从机序号
    if(CSU_ROLE_MASTER == csu_role_get())
    {
        slave_index = get_slave_index(p_nc, p_msg);
    }

    //指令过滤，涉及到主从机模式下多指令转发，需要在本地进行处理
    //升级列表下发
    //PCS故障录波文件下载
    //储能柜故障录波文件下载
    //MCU2故障日志、操作日志、运行日志导出
    if((mg_vcmp(&p_msg->uri, "/upgrade/deviceList") == 0) ||
        (mg_vcmp(&p_msg->uri, "/debugManager/exportFaultRecorderPCS") == 0) ||
        (mg_vcmp(&p_msg->uri, "/debugManager/exportFaultRecorderCMU") == 0) ||
        (mg_vcmp(&p_msg->uri, "/sysManager/exportmcu2log") == 0) ||
        (mg_vcmp(&p_msg->uri, "/sysManager/exportmcu2optlog") == 0) ||
        (mg_vcmp(&p_msg->uri, "/sysManager/exportmcu2debuglog") == 0))
    {
        slave_index = 0;
    }
    
    list_for_each(ptPos, &g_web_func_list_head.tFunNode)
    {
        p_func_node = list_entry(ptPos, function_node_t, tFunNode);
        if (mg_vcmp(&p_msg->uri, p_func_node->url) == 0)
        {
            printf( "p_func_node->url:%s\r\n", p_func_node->url);
            //主从模式下从机指令
            if((CSU_ROLE_MASTER == csu_role_get()) && (slave_index != 0))
            {
                //转发至对应从机
                web_data_trans2slave_by_uri(p_nc, p_msg, p_func_node->url);
                //广播指令自身也要处理
                if(slave_index == 0xFF)
                {
                    if(p_func_node->p_func_cb != NULL)
                    {
                        //执行对应的功能
                        p_func_node->p_func_cb(p_nc, p_msg);  
                    }
                    if(p_func_node->trans_flag)
                    {
                        //执行转发
                        web_data_trans2cmu_by_uri(p_nc, p_msg, p_func_node->url);
                    } 
                }
            } 
            //非主从模式指令
            else
            {
                if(p_func_node->p_func_cb != NULL)
                {
                    //执行对应的功能
                    p_func_node->p_func_cb(p_nc, p_msg);  
                }
                if(p_func_node->trans_flag)
                {
                    //执行转发
                    web_data_trans2cmu_by_uri(p_nc, p_msg, p_func_node->url);
                }
            }
            return 1;
        }
    }

    return 0;

}


/**
 * @brief web代理模块初始化
 * @return none
 */
void web_broker_module_init(void)
{
    //初始化链表
    init_list_head(&(g_web_func_list_head.tFunNode));
}


