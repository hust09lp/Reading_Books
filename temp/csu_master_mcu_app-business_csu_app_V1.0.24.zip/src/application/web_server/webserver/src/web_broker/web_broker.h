#ifndef __WEB_BROKER_H__
#define __WEB_BROKER_H__

#include "mongoose.h"
#include "list.h"


#define TRANS_NEED      1
#define TRANS_UNNEED    0


//功能回调
typedef void (*func_cb)(struct mg_connection *p_nc, struct http_message *p_msg);

/**
 * @brief web代理模块初始化
 * @return none
 */
void web_broker_module_init(void);

/**
 * @brief 功能注册
 *
 * @param [in] p_url : url
 * @param [in] trans_flag : 转发标志
 * @param [in] p_func_cb : 功能函数指针    
 * 
 * @retval uint8_t
 * @return 1:操作成功
 *         0:操作失败
 */
uint8_t web_func_attach(uint8_t *p_url, uint8_t trans_flag, func_cb p_func_cb);

/**
 * @brief 功能执行
 * @param   [in] p_nc 表示http连接指针
 * @param   [in] p_msg 表示http连接的请求体内容
 * @return 1:操作成功
 *         0:操作失败
 */
uint8_t web_func_execute(struct mg_connection *p_nc,struct http_message *p_msg);

#endif  // __TY_HOOK_H__
