#ifndef __FAULT_RECORDER_H__
#define __FAULT_RECORDER_H__

#include "mongoose.h"
#include "component/sofar_log.h"

#if (1)
#define FAULT_RECORDER_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else
#define FAULT_RECORDER_DEBUG_PRINT(...) {do {} while(0);}
#endif


/**
 * @brief 故障录波模块初始化
 * @return void
 */
void web_fault_recorder_module_init(void);

#endif
