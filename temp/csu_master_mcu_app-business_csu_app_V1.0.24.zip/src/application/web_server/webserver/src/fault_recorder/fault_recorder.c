#include "sdk_public.h"
#include "cJSON.h"
#include "web_broker.h"
#include "common.h"
#include "app_common.h"
#include "libghttp.h"
#include "fault_recorder.h"
#include "csu_comb_type.h"
#include "web_data_trans2slave.h"


/**
 * @brief    导出PCS录波文件
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void export_pcs_fault_recorder(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_response = NULL;
    cJSON *p_resp_root = NULL;
    char *p_uri = NULL;
    uint8_t *p = NULL;
    uint8_t request_body[128] = {0};
    uint8_t response[256] = {0};
    char url[128] = {0};
    char file_name[256] = {0};
    char dev_ip[16] = {0};
    int32_t ret = 0;
    uint8_t slave_index = 0;
    char export_uri[] = {"/debugManager/exportFaultRecorderPCS"};

    memcpy(request_body, p_msg->body.p, p_msg->body.len);	
    //解析判断是否处于主从机摸下从机故障录波导出
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        FAULT_RECORDER_DEBUG_PRINT((int8_t *)"json data parse error");
        build_empty_response(response, Accepted, "parse request failed.");
		http_back(p_nc, response);
		return;
    }
    slave_index = cJSON_GetObjectItem(p_request, "slaveIndex")->valueint;
    cJSON_Delete(p_request);

    if((slave_index != 0) && (CSU_ROLE_MASTER == csu_role_get()))
    {
        //获取从机IP
        if(!get_slave_ip(slave_index, dev_ip))
        {
            build_empty_response(response, Accepted, "parse request failed.");
            http_back(p_nc, response);
            return;
        }
    }
    else
    {
        strcpy(dev_ip, CMU1_IP);
    }

    sprintf(url, "%s%s%s", "http://", dev_ip, export_uri);
    ret = http_net_post(url, request_body, response);
    if(ret)
    {
        FAULT_RECORDER_DEBUG_PRINT("response:%s", response);
        p_response = cJSON_Parse(response);
        if(p_response == NULL)
        {
            FAULT_RECORDER_DEBUG_PRINT((int8_t *)"json data parse error");
            return;
        }
        p_uri = cJSON_GetObjectItem(p_response, "url")->valuestring;
        //打包URL
        memset(url, 0, sizeof(url));
        if((slave_index != 0) && (CSU_ROLE_MASTER == csu_role_get()))
        {
            sprintf(url, "%s%s%s", "http://", dev_ip, p_uri);
        }
        else
        {
            sprintf(url, "%s%s/%s", "http://", dev_ip, p_uri);
        }
        //执行文件下载
        snprintf(file_name, sizeof(file_name), "%s%s", "/tmp/", "PCSFaultRecorder.tar.gz");
        ret = http_net_file_dowaload(url, p_uri, file_name);
        if(!ret)
        {
            FAULT_RECORDER_DEBUG_PRINT("file download error");
            cJSON_Delete(p_response);
            return;
        }
        cJSON_Delete(p_response);
        
        p_resp_root = cJSON_CreateObject();
        if(p_resp_root == NULL)
        {
            FAULT_RECORDER_DEBUG_PRINT("create json obj failed");
            return;
        }
        cJSON_AddNumberToObject(p_resp_root,"code",OK);
        cJSON_AddStringToObject(p_resp_root,"url","/download/PCSFaultRecorder.tar.gz");
        p = cJSON_PrintUnformatted(p_resp_root);
        cJSON_Delete(p_resp_root);
        http_back(p_nc,p);
        free(p);
    }
}


/**
 * @brief    导出CMU录波文件
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void export_cmu_fault_recorder(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_response = NULL;
    cJSON *p_resp_root = NULL;
    char *p_uri = NULL;
    uint8_t *p = NULL;
    uint8_t request_body[128] = {0};
    uint8_t response[256] = {0};
    char url[128] = {0};
    char file_name[256] = {0};
    char dev_ip[16] = {0};
    int32_t ret = 0;
    uint8_t slave_index = 0;
    char export_uri[] = {"/debugManager/exportFaultRecorderCMU"};

    memcpy(request_body, p_msg->body.p, p_msg->body.len);	
    //解析判断是否处于主从机摸下从机故障录波导出
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        FAULT_RECORDER_DEBUG_PRINT((int8_t *)"json data parse error");
        build_empty_response(response, Accepted, "parse request failed.");
		http_back(p_nc, response);
		return;
    }
    slave_index = cJSON_GetObjectItem(p_request, "slaveIndex")->valueint;
    cJSON_Delete(p_request);

    if((slave_index != 0) && (CSU_ROLE_MASTER == csu_role_get()))
    {
        //获取从机IP
        if(!get_slave_ip(slave_index, dev_ip))
        {
            build_empty_response(response, Accepted, "parse request failed.");
            http_back(p_nc, response);
            return;
        }
    }
    else
    {
        strcpy(dev_ip, CMU1_IP);
    }

    sprintf(url, "%s%s%s", "http://", dev_ip, export_uri);
    ret = http_net_post(url, request_body, response);
    if(ret)
    {
        FAULT_RECORDER_DEBUG_PRINT("response:%s", response);
        p_response = cJSON_Parse(response);
        if(p_response == NULL)
        {
            FAULT_RECORDER_DEBUG_PRINT((int8_t *)"json data parse error");
            return;
        }
        p_uri = cJSON_GetObjectItem(p_response, "url")->valuestring;
        //打包URL
        memset(url, 0, sizeof(url));
        if((slave_index != 0) && (CSU_ROLE_MASTER == csu_role_get()))
        {
            sprintf(url, "%s%s%s", "http://", dev_ip, p_uri);
        }
        else
        {
            sprintf(url, "%s%s/%s", "http://", dev_ip, p_uri);
        }
        //执行文件下载
        snprintf(file_name, sizeof(file_name), "%s%s", "/tmp/", "CMUFaultRecorder.tar.gz");
        ret = http_net_file_dowaload(url, p_uri, file_name);
        if(!ret)
        {
            FAULT_RECORDER_DEBUG_PRINT("file download error");
            cJSON_Delete(p_response);
            return;
        }
        cJSON_Delete(p_response);
        p_resp_root = cJSON_CreateObject();
        if(p_resp_root == NULL)
        {
            FAULT_RECORDER_DEBUG_PRINT("create json obj failed");
            return;
        }
        cJSON_AddNumberToObject(p_resp_root,"code",OK);
        cJSON_AddStringToObject(p_resp_root,"url","/download/CMUFaultRecorder.tar.gz");
        p = cJSON_PrintUnformatted(p_resp_root);
        cJSON_Delete(p_resp_root);
        http_back(p_nc,p);
        free(p);
    }
}


/**
 * @brief 故障录波模块初始化
 * @return void
 */
void web_fault_recorder_module_init(void)
{
    //PCS录波生成导出
    //触发CMU生成PCS录波文件
	if(!web_func_attach("/debugManager/generateFaultRecorderPCS", TRANS_NEED, NULL))                        
	{
		FAULT_RECORDER_DEBUG_PRINT("[/debugManager/generateFaultRecorderPCS] attach failed");
	}
    //获取录波进度
    if(!web_func_attach("/debugManager/getFaultRecorderProgressPCS", TRANS_NEED, NULL))                     
	{
		FAULT_RECORDER_DEBUG_PRINT("[/debugManager/getFaultRecorderProgressPCS] attach failed");
	}
    //导出录波文件
    if(!web_func_attach("/debugManager/exportFaultRecorderPCS", TRANS_UNNEED, export_pcs_fault_recorder))   
	{
		FAULT_RECORDER_DEBUG_PRINT("[/debugManager/exportFaultRecorderPCS] attach failed");
	}

    //储能柜录波生成导出
    //获取CMU故障录波文件列表
    if(!web_func_attach("/debugManager/getFaultRecorderList", TRANS_NEED, NULL))
	{
		FAULT_RECORDER_DEBUG_PRINT("[/debugManager/getFaultRecorderList] attach failed");
	}
    //触发CMU生成录波文件
	if(!web_func_attach("/debugManager/generateFaultRecorderCMU", TRANS_NEED, NULL))
	{
		FAULT_RECORDER_DEBUG_PRINT("[/debugManager/generateFaultRecorderCMU] attach failed");
	}
	//获取录波进度
	if(!web_func_attach("/debugManager/getFaultRecorderProgressCMU", TRANS_NEED, NULL))
	{
		FAULT_RECORDER_DEBUG_PRINT("[/debugManager/getFaultRecorderProgressCMU] attach failed");
	}
	//导出录波文件
	if(!web_func_attach("/debugManager/exportFaultRecorderCMU", TRANS_UNNEED, export_cmu_fault_recorder))
	{
		FAULT_RECORDER_DEBUG_PRINT("[/debugManager/exportFaultRecorderCMU] attach failed");
	}
}
