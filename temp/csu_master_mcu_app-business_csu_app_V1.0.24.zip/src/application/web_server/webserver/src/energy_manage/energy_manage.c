#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cJSON.h"
#include "common.h"
#include "sqlite3.h"
#include "sdk_shm.h"
#include "web_broker.h"
#include "energy_manage.h"
#include "energy_op.h"
#include "libghttp.h"
#include "mem_utils.h"
#include "sdk_log.h"
#include <math.h>

#define HOURS_NUM_PER_DAY                (24)                    // 一天24小时
#define MONTHS_NUM_PER_YEAR              (12)                    // 一年12月
#define STORAGE_TIME_LIMIT               (20)                    // 存储时间限制 20年
 
#define PATH_POWER_GENERAL_DIR     "/user/data/power/"
#define ENERGY_PATH   "/user/data/energy/"
#define POWER_FLOW_DB	 "/user/data/power/power_flow.db"	    // 能流功率数据库文件路径
#define ENERGY_DB "/user/data/energy/meter_energy.db"       // 数据库文件路径
#define PCC_ENERGY_DB "/user/data/energy/pcc_energy.db"     // 数据库文件路径
#define PV_ENERGY_DB "/user/data/energy/pv_energy.db"       // 数据库文件路径
#define LOAD_ENERGY_DB "/user/data/energy/load_energy.db"   // 数据库文件路径

typedef enum {
    ENG_DAT_TYPE_DAY,
    ENG_DAT_TYPE_MONTH,
    ENG_DAT_TYPE_YEAR,
    ENG_DAT_TYPE_TOTAL,
} eng_dat_type_e;

typedef struct 
{
    data_energy_t meter;
    data_energy_t pcc;
    data_energy_t pv;
    data_energy_t load;
} energy_dat_info_t;

/**
 * @brief  根据日期计算该月几天
 * @param  [in] year 年
 * @param  [in] month 月
 * @param  [out] none
 * @return 一年中的第几天 [1~366]
 */
static int32_t get_days_in_month(int year, int month) 
{
    int days;
 
    if (month == 4 || month == 6 || month == 9 || month == 11) 
    {
        days = 30;
    } 
    else if (month == 2) 
    {
        if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) 
        {
            days = 29; // 闰年2月29天
        } 
        else 
        {
            days = 28; // 平年2月28天
        }
    } 
    else
    {
        days = 31;
    }
        return days;
}



/**
 * @brief   获取并柜从机电量数据
 * @param [in] p_slave_ip ： 从机IP地址
 * @param [in] req_str    ： 请求字符串
 * @param [in] type       ： 数据类型
 * @param [out] p_energy_dat_info ： 电量数据
 * @return SF_OK:成功  其他:失败
 */ 
static sf_ret_t get_csu_comb_slave_charge_discharge_info( uint8_t *p_slave_ip, char *req_str, eng_dat_type_e type, energy_dat_info_t *p_energy_dat_info )
{
    char resp_str[2048] = {0};
    char url[300] = {0};
    int ret = 0;

    sprintf( url, "http://%d.%d.%d.%d/CSUhomepage/%s", p_slave_ip[0], p_slave_ip[1], p_slave_ip[2], p_slave_ip[3],
                                                       (type == ENG_DAT_TYPE_DAY   ) ? "getDailyChargeDischarge"   :
                                                       (type == ENG_DAT_TYPE_MONTH ) ? "getMonthlyChargeDischarge" :
                                                       (type == ENG_DAT_TYPE_YEAR  ) ? "getYearChargeDischarge"    :
                                                       (type == ENG_DAT_TYPE_TOTAL ) ? "getTotalChargeDischarge"   : "getDailyChargeDischarge" );
    ret = http_net_post( url, req_str, resp_str);
    if ( ret != 1 )
    {
        /* 失败 */
        return SF_ERR_NDEF;
    }

    cJSON *p_resp_root = cJSON_Parse(resp_str);
    if ( p_resp_root == NULL )
    {
        return SF_ERR_NDEF;
    }

    cJSON *p_chargeEnergy_js    = cJSON_GetObjectItem( p_resp_root, "chargeEnergy" );
    cJSON *p_dischargeEnergy_js = cJSON_GetObjectItem( p_resp_root, "dischargeEnergy" );
    cJSON *p_pccEnergyIn_js     = cJSON_GetObjectItem( p_resp_root, "pccEnergyIn" );
    cJSON *p_pccEnergyOut_js    = cJSON_GetObjectItem( p_resp_root, "pccEnergyOut" );
    cJSON *p_pvEnergy_js        = cJSON_GetObjectItem( p_resp_root, "pvEnergy" );
    cJSON *p_loadEnergy_js      = cJSON_GetObjectItem( p_resp_root, "loadEnergy" );

   if (   p_chargeEnergy_js    == NULL 
       || p_dischargeEnergy_js == NULL 
       || p_pccEnergyIn_js     == NULL 
       || p_pccEnergyOut_js    == NULL 
       || p_pvEnergy_js        == NULL 
       || p_loadEnergy_js      == NULL )
    {
        cJSON_Delete(p_resp_root);
        return SF_ERR_NO_OBJECT;
    }

    for (size_t i = 0; i < cJSON_GetArraySize( p_chargeEnergy_js ); i++)
    {
        p_energy_dat_info->meter.charge[i] = cJSON_GetArrayItem( p_chargeEnergy_js, i )->valuedouble;
    }
    for (size_t i = 0; i < cJSON_GetArraySize( p_dischargeEnergy_js ); i++)
    {
        p_energy_dat_info->meter.discharge[i] = cJSON_GetArrayItem( p_dischargeEnergy_js, i )->valuedouble;
    }
    for (size_t i = 0; i < cJSON_GetArraySize( p_pccEnergyIn_js ); i++)
    {
        p_energy_dat_info->pcc.charge[i] = cJSON_GetArrayItem( p_pccEnergyIn_js, i )->valuedouble;
    }
    for (size_t i = 0; i < cJSON_GetArraySize( p_pccEnergyOut_js ); i++)
    {
        p_energy_dat_info->pcc.discharge[i] = cJSON_GetArrayItem( p_pccEnergyOut_js, i )->valuedouble;
    }
    for (size_t i = 0; i < cJSON_GetArraySize( p_pvEnergy_js ); i++)
    {
        p_energy_dat_info->pv.charge[i] = cJSON_GetArrayItem( p_pvEnergy_js, i )->valuedouble;
    }
    for (size_t i = 0; i < cJSON_GetArraySize( p_loadEnergy_js ); i++)
    {
        p_energy_dat_info->load.charge[i] = cJSON_GetArrayItem( p_loadEnergy_js, i )->valuedouble;
    }
    
    cJSON_Delete(p_resp_root);

    return SF_OK;
}

/**
 * @brief   根据自身的并机角色获取从机电量数据
 * @param [in] tm_str       ： 时间信息
 * @param [in] http_req_str ： http请求字符串
 * @param [in] type         ： 数据类型
 * @param [out] p_energy_dat_info ： 电量数据
 * @return SF_OK:成功  其他:失败
 */ 
static sf_ret_t get_global_charge_discharge_info( char *tm_str, char *http_req_str, eng_dat_type_e type, energy_dat_info_t *p_energy_dat_info )
{
    csu_comb_setting_t *p_csu_comb_setting = &sdk_shm_get()->csu_combine_data.comb_setting;
    csu_node_info_t *p_csu_node_info   = sdk_shm_get()->csu_combine_data.slave_info;
    energy_dat_info_t slave_energy_dat_info = {0};
    data_energy_t meter_energy_data = {0};
    data_energy_t pcc_energy_data   = {0};
    data_energy_t pv_energy_data    = {0};
    data_energy_t load_energy_data  = {0};

    // printf( "--------------------------tm_str:%s\r\n", tm_str );

    switch ( type )
    {
        case ENG_DAT_TYPE_DAY:
            select_sqlite_db_day( tm_str, &meter_energy_data , ENERGY_DB      , METER     ); 
            select_sqlite_db_day( tm_str, &pcc_energy_data   , PCC_ENERGY_DB  , PCC_METER ); 
            select_sqlite_db_day( tm_str, &pv_energy_data    , PV_ENERGY_DB   , PV_METER  ); 
            select_sqlite_db_day( tm_str, &load_energy_data  , LOAD_ENERGY_DB , LOAD      ); 
            break;
            
        case ENG_DAT_TYPE_MONTH:
            select_sqlite_db_mon( tm_str, &meter_energy_data , ENERGY_DB      , METER     ); 
            select_sqlite_db_mon( tm_str, &pcc_energy_data   , PCC_ENERGY_DB  , PCC_METER ); 
            select_sqlite_db_mon( tm_str, &pv_energy_data    , PV_ENERGY_DB   , PV_METER  ); 
            select_sqlite_db_mon( tm_str, &load_energy_data  , LOAD_ENERGY_DB , LOAD      ); 
            break;
            
        case ENG_DAT_TYPE_YEAR:
            select_sqlite_db_year( tm_str, &meter_energy_data , ENERGY_DB      , METER     ); 
            select_sqlite_db_year( tm_str, &pcc_energy_data   , PCC_ENERGY_DB  , PCC_METER ); 
            select_sqlite_db_year( tm_str, &pv_energy_data    , PV_ENERGY_DB   , PV_METER  ); 
            select_sqlite_db_year( tm_str, &load_energy_data  , LOAD_ENERGY_DB , LOAD      ); 
            break;
            
        case ENG_DAT_TYPE_TOTAL:
            select_sqlite_db_total( tm_str, &meter_energy_data.charge[0] , &meter_energy_data.discharge[0] , ENERGY_DB      , METER     ); 
            select_sqlite_db_total( tm_str, &pcc_energy_data.charge[0]   , &pcc_energy_data.discharge[0]   , PCC_ENERGY_DB  , PCC_METER ); 
            select_sqlite_db_total( tm_str, &pv_energy_data.charge[0]    , &pv_energy_data.discharge[0]    , PV_ENERGY_DB   , PV_METER  ); 
            select_sqlite_db_total( tm_str, &load_energy_data.charge[0]  , &load_energy_data.discharge[0]  , LOAD_ENERGY_DB , LOAD      ); 
            break;

        default:
            return SF_ERR_NDEF;
    }

    if (   p_csu_comb_setting->comb_enable == SF_TRUE 
        && p_csu_comb_setting->comb_role   == CSU_ROLE_MASTER )
    {
        /* 主机需要对从机数据做累加 */
        for (size_t i = 0; i < (p_csu_comb_setting->master.comb_num - 1); i++)
        {
            if (   p_csu_node_info[i].valid  == SF_TRUE 
                && p_csu_node_info[i].online == SF_TRUE )
            {
                if ( SF_OK !=  get_csu_comb_slave_charge_discharge_info( p_csu_node_info[i].ip, http_req_str, type, &slave_energy_dat_info ))
                    continue;
                
                /* 对在线的从机数据进行累加 */
                for (size_t j = 0; j < ARRAY_SIZE( meter_energy_data.charge ); j++)
                {
                    meter_energy_data.charge[j]    += slave_energy_dat_info.meter.charge[j];
                    meter_energy_data.discharge[j] += slave_energy_dat_info.meter.discharge[j];
                    // load_energy_data.charge[j]     += slave_energy_dat_info.load.charge[j];
                    /* 能量守恒计算 */
                    load_energy_data.charge[j] = ( pcc_energy_data.charge[j] + pv_energy_data.charge[j] + meter_energy_data.discharge[j] ) 
                                                 - ( pcc_energy_data.discharge[j] + meter_energy_data.charge[j] );
                    /* 四舍五入，保留小数点后一位 */
                    load_energy_data.charge[j] = round( load_energy_data.charge[j] * 10 ) / 10;
                    if ( load_energy_data.charge[j] < 0 )
                        load_energy_data.charge[j] = 0;
                }
            }
        }
    }

    memcpy( &p_energy_dat_info->meter, &meter_energy_data, sizeof(data_energy_t) );
    memcpy( &p_energy_dat_info->pcc  , &pcc_energy_data  , sizeof(data_energy_t) );
    memcpy( &p_energy_dat_info->pv   , &pv_energy_data   , sizeof(data_energy_t) );
    memcpy( &p_energy_dat_info->load , &load_energy_data , sizeof(data_energy_t) );

    return SF_OK;
}


/**
 * @brief    获取日充放电数据
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void get_daily_charge_discharge(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t *p_action = NULL;
    uint8_t ymd[32] = {0};
    uint8_t *p = NULL;
    uint8_t request_body[128] = {0};
    uint8_t response[128] = {0};
    data_energy_t energy_data = {0};
 
    memcpy(request_body, p_msg->body.p, p_msg->body.len);    
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        ENERGY_MANAGE_DEBUG_PRINT("parse request failed.");
        build_empty_response(response, Accepted, "parse request failed.");
        http_back(p_nc, response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action, "getDailyChargeDischarge"))
    {
        ENERGY_MANAGE_DEBUG_PRINT("action is not right.");
        build_empty_response(response, Non_Authoriative_Information, "action is not right");
        http_back(p_nc, response);
        cJSON_Delete(p_request);
        return;
    }
 
    strcpy(ymd,cJSON_GetObjectItem(p_request,"ymd")->valuestring); 
    cJSON_Delete(p_request);
 
    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        ENERGY_MANAGE_DEBUG_PRINT("create json obj failed.");
        return;
    }

    energy_dat_info_t energy_data_info = {0};

    get_global_charge_discharge_info( ymd, request_body, ENG_DAT_TYPE_DAY, &energy_data_info );
    cJSON_AddItemToObject(p_resp_root, "chargeEnergy"   , cJSON_CreateDoubleArray( energy_data_info.meter.charge   , HOURS_NUM_PER_DAY));
    cJSON_AddItemToObject(p_resp_root, "dischargeEnergy", cJSON_CreateDoubleArray( energy_data_info.meter.discharge, HOURS_NUM_PER_DAY));
    cJSON_AddItemToObject(p_resp_root, "pccEnergyIn"    , cJSON_CreateDoubleArray( energy_data_info.pcc.charge     , HOURS_NUM_PER_DAY));
    cJSON_AddItemToObject(p_resp_root, "pccEnergyOut"   , cJSON_CreateDoubleArray( energy_data_info.pcc.discharge  , HOURS_NUM_PER_DAY));
    cJSON_AddItemToObject(p_resp_root, "pvEnergy"       , cJSON_CreateDoubleArray( energy_data_info.pv.charge      , HOURS_NUM_PER_DAY));
    cJSON_AddItemToObject(p_resp_root, "loadEnergy"     , cJSON_CreateDoubleArray( energy_data_info.load.charge    , HOURS_NUM_PER_DAY));

    cJSON_AddNumberToObject(p_resp_root,"code", OK);
    cJSON_AddStringToObject(p_resp_root,"msg", "get daily charge discharge successful");
 
    p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_resp_root);
 
    http_back(p_nc, p);
    free(p);
}

/**
 * @brief    获取月充放电数据
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void get_monthly_charge_discharge(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t response[128] = {0};
    uint8_t request_body[128] = {0};
    uint8_t *p_action = NULL;
    uint8_t ymd[32] = {0};
    uint8_t *p = NULL;
    data_energy_t energy_data = {0};
    int year = 0, month = 0, days = 0;
 
    memcpy(request_body, p_msg->body.p, p_msg->body.len);   
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        ENERGY_MANAGE_DEBUG_PRINT("parse request failed.");
        build_empty_response(response, Accepted, "parse request failed.");
        http_back(p_nc, response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request, "action")->valuestring;
    if(strcmp(p_action, "getMonthlyChargeDischarge"))
    {
        ENERGY_MANAGE_DEBUG_PRINT("action is not right.");
        build_empty_response(response, Non_Authoriative_Information, "action is not right");
        http_back(p_nc, response);
        cJSON_Delete(p_request);
        return;
    }
 
    strcpy(ymd, cJSON_GetObjectItem(p_request, "ymd")->valuestring);
    cJSON_Delete(p_request);

    sscanf(ymd, "%d-%d", &year, &month);
    days = get_days_in_month(year, month);
 
    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        ENERGY_MANAGE_DEBUG_PRINT("create json obj failed.");
        return ;
    }

    energy_dat_info_t energy_data_info = {0};

    get_global_charge_discharge_info( ymd, request_body, ENG_DAT_TYPE_MONTH, &energy_data_info );
    cJSON_AddItemToObject( p_resp_root, "chargeEnergy"   , cJSON_CreateDoubleArray( energy_data_info.meter.charge   , days));
    cJSON_AddItemToObject( p_resp_root, "dischargeEnergy", cJSON_CreateDoubleArray( energy_data_info.meter.discharge, days));
    cJSON_AddItemToObject( p_resp_root, "pccEnergyIn"    , cJSON_CreateDoubleArray( energy_data_info.pcc.charge     , days));
    cJSON_AddItemToObject( p_resp_root, "pccEnergyOut"   , cJSON_CreateDoubleArray( energy_data_info.pcc.discharge  , days));
    cJSON_AddItemToObject( p_resp_root, "pvEnergy"       , cJSON_CreateDoubleArray( energy_data_info.pv.charge      , days));
    cJSON_AddItemToObject( p_resp_root, "loadEnergy"     , cJSON_CreateDoubleArray( energy_data_info.load.charge    , days));

    cJSON_AddNumberToObject(p_resp_root, "code", OK);
    cJSON_AddStringToObject(p_resp_root, "msg", "get monthly charge discharge successful");
    p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_resp_root);
 
    http_back(p_nc, p);
    free(p);
}
 
/**
 * @brief    获取年充放电数据
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void get_yearly_charge_discharge(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t response[128] = {0};
    uint8_t request_body[128] = {0};
    uint8_t *p_action = NULL;
    uint8_t ymd[32] = {0};
    uint8_t *p = NULL;
    data_energy_t energy_data = {0};

    memcpy(request_body, p_msg->body.p, p_msg->body.len);  
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        ENERGY_MANAGE_DEBUG_PRINT("parse request failed.");
        build_empty_response(response, Accepted, "parse request failed.");
        http_back(p_nc, response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request, "action")->valuestring;
    if(strcmp(p_action, "getYearChargeDischarge"))
    {
        ENERGY_MANAGE_DEBUG_PRINT("action is not right.");
        build_empty_response(response, Non_Authoriative_Information, "action is not right");
        http_back(p_nc, response);
        cJSON_Delete(p_request);
        return;
    }
 
    p = cJSON_GetObjectItem(p_request, "ymd")->valuestring;
    snprintf(ymd, sizeof(ymd), "%s", p);
    cJSON_Delete(p_request);
 
    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        ENERGY_MANAGE_DEBUG_PRINT("create json obj failed.");
        return ;
    }

    energy_dat_info_t energy_data_info = {0};

    get_global_charge_discharge_info( ymd, request_body, ENG_DAT_TYPE_YEAR, &energy_data_info );
    cJSON_AddItemToObject( p_resp_root, "chargeEnergy"   , cJSON_CreateDoubleArray( energy_data_info.meter.charge   , MONTHS_NUM_PER_YEAR));
    cJSON_AddItemToObject( p_resp_root, "dischargeEnergy", cJSON_CreateDoubleArray( energy_data_info.meter.discharge, MONTHS_NUM_PER_YEAR));
    cJSON_AddItemToObject( p_resp_root, "pccEnergyIn"    , cJSON_CreateDoubleArray( energy_data_info.pcc.charge     , MONTHS_NUM_PER_YEAR));
    cJSON_AddItemToObject( p_resp_root, "pccEnergyOut"   , cJSON_CreateDoubleArray( energy_data_info.pcc.discharge  , MONTHS_NUM_PER_YEAR));
    cJSON_AddItemToObject( p_resp_root, "pvEnergy"       , cJSON_CreateDoubleArray( energy_data_info.pv.charge      , MONTHS_NUM_PER_YEAR));
    cJSON_AddItemToObject( p_resp_root, "loadEnergy"     , cJSON_CreateDoubleArray( energy_data_info.load.charge    , MONTHS_NUM_PER_YEAR));
 
    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddStringToObject(p_resp_root,"msg","get year charge discharge successful");
 
    p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_resp_root);
 
    http_back(p_nc, p);
    free(p);
}
 

 
/**
 * @brief    获取总充放电数据
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void get_total_charge_discharge(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t response[128] = {0};
    uint8_t request_body[128] = {0};
    uint8_t *p_action = NULL;
    uint8_t *p_ymd = NULL;
    uint8_t *p = NULL;
    double charge = 0;                 
    double discharge = 0;
    uint8_t ymd[16] = {0};
    int num = 0;
 
    memcpy(request_body, p_msg->body.p, p_msg->body.len);    
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        ENERGY_MANAGE_DEBUG_PRINT("parse request failed.");
        build_empty_response(response, Accepted, "parse request failed.");
        http_back(p_nc, response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request, "action")->valuestring;
    if(strcmp(p_action, "getTotalChargeDischarge"))
    {
        ENERGY_MANAGE_DEBUG_PRINT("action is not right.");
        build_empty_response(response, Non_Authoriative_Information, "action is not right");
        http_back(p_nc, response);
        cJSON_Delete(p_request);
        return;
    }
 
    p_ymd = cJSON_GetObjectItem(p_request, "ymd")->valuestring;  
    if(strcmp(p_ymd, "total"))
    {
        ENERGY_MANAGE_DEBUG_PRINT("ymd is not right.");
        build_empty_response(response, 204, "request ymd is not right,should be 'total'");
        http_back(p_nc, response);
        cJSON_Delete(p_request);
        return;
    }
    p = cJSON_GetObjectItem(p_request, "ymd")->valuestring;
    snprintf(ymd, sizeof(ymd), "%s", p);
    cJSON_Delete(p_request);
 
    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        ENERGY_MANAGE_DEBUG_PRINT("create json obj failed.");
        return ;
    }

    energy_dat_info_t energy_data_info = {0};

    get_global_charge_discharge_info( ymd, request_body, ENG_DAT_TYPE_TOTAL, &energy_data_info );
    cJSON_AddNumberToObject( p_resp_root, "chargeEnergy"   , energy_data_info.meter.charge[0]    );
    cJSON_AddNumberToObject( p_resp_root, "dischargeEnergy", energy_data_info.meter.discharge[0] );
    cJSON_AddNumberToObject( p_resp_root, "pccEnergyIn"    , energy_data_info.pcc.charge[0]      );
    cJSON_AddNumberToObject( p_resp_root, "pccEnergyOut"   , energy_data_info.pcc.discharge[0]   );
    cJSON_AddNumberToObject( p_resp_root, "pvEnergy"       , energy_data_info.pv.charge[0]       );
    cJSON_AddNumberToObject( p_resp_root, "loadEnergy"     , energy_data_info.load.charge[0]     );

    cJSON_AddNumberToObject(p_resp_root,"code",OK);
    cJSON_AddStringToObject(p_resp_root,"msg","get total  charge discharge successful");
 
    p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_resp_root);
 
    http_back(p_nc, p);
    free(p);
}
 
 
uint16_t get_data_array_pos(uint8_t *p_time)
{
    uint8_t hour = 0;
    uint8_t min = 0;
    uint16_t min_data = 0;
 
    sscanf(p_time, "%d:%d", &hour, &min);
    min_data = hour * 60 + min;
    return (min_data / 5);
}
 

/**
 * @brief    从数据库读取日功率数据
 * @param	 [in] *p_time 时间 
 * @param	 [in] *p_ymd  指令功率时间
 * @param	 [out] *p_buf 功率数据
 * @param	 [in]  type   类型
 * @return
 */
static int32_t select_power_sqlite_db_day(power_time_t *p_time, uint8_t *p_ymd, dev_power_info_t *p_power, uint8_t type)
{
    sqlite3 *db = NULL;
    sqlite3_stmt *stmt = NULL;
    char db_name[64] = {0};
    uint8_t date[64] = {0};
    char sql[256] = {0};
    uint8_t p_node_time[64] = {0};
    uint16_t pos = 0;
    int rc = 0;

    snprintf(date, 64,"%s",p_ymd);
 
    if(type == ENERGY_METER)
    {
        p_time->year -= 2000;
        sprintf(db_name, "%s%s-%d%s",PATH_POWER_GENERAL_DIR, "power", p_time->year, ".db");
        rc = sqlite3_open(db_name, &db);
        if(rc) 
        {
            ENERGY_MANAGE_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
            return(0);
        } 
        else 
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%H:%M', date), power FROM power_data WHERE date LIKE '%s%%';",date);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
        
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                memcpy(p_node_time, sqlite3_column_text(stmt, 0), strlen(sqlite3_column_text(stmt, 0)));
                //转换为分钟获取点位
                pos = get_data_array_pos(p_node_time);
                p_power->meter_power[pos] = sqlite3_column_double(stmt, 1) / 1000.00;
            }
            sqlite3_finalize(stmt);
        }
    }
    else if(type == ENERGY_FLOW)
    {
        rc = sqlite3_open(POWER_FLOW_DB, &db);
        if(rc) 
        {
            ENERGY_MANAGE_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
            return(0);
        } 
        else 
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%H:%M', date), pcc_power, pv_power, load_power FROM power_data WHERE date LIKE '%s%%';",date);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
        
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                memcpy(p_node_time, sqlite3_column_text(stmt, 0), strlen(sqlite3_column_text(stmt, 0)));
                //转换为分钟获取点位
                pos = get_data_array_pos(p_node_time);
                p_power->pcc_power[pos] = sqlite3_column_double(stmt, 1) / 1000.00;
                p_power->pv_power[pos] = sqlite3_column_double(stmt, 2) / 1000.00;
                p_power->load_power[pos] = sqlite3_column_double(stmt, 3) / 1000.00;
            }
            sqlite3_finalize(stmt);
        }
    }

    sqlite3_close(db);    
    return 1; 
}


void dev_power_info_print( dev_power_info_t *p_dev_power_info )
{
    mem_utils_print_double_dat( "meter_power:",  p_dev_power_info->meter_power, ARRAY_SIZE( p_dev_power_info->meter_power ), "%0.3f ", 10, true );
    // mem_utils_print_double_dat( "pcc_power:",  p_dev_power_info->pcc_power, ARRAY_SIZE( p_dev_power_info->meter_power ), "%0.3f ", 10, true );
    // mem_utils_print_double_dat( "pv_power:",  p_dev_power_info->pv_power, ARRAY_SIZE( p_dev_power_info->meter_power ), "%0.3f ", 10, true );
    // mem_utils_print_double_dat( "load_power:",  p_dev_power_info->load_power, ARRAY_SIZE( p_dev_power_info->meter_power ), "%0.3f ", 10, true );
}

/**
 * @brief   获取并柜从机功率数据
 * @param [in] p_slave_ip    ： 从机IP地址
 * @param [in] req_str       ： 请求字符串
 * @param [out] p_power_info ： 从机功率数据
 * @return SF_OK:成功  其他:失败
 */ 
static sf_ret_t get_csu_comb_slave_daily_power( uint8_t *p_slave_ip, char *req_str, dev_power_info_t *p_power_info )
{
    char resp_str[2048] = {0};
    char url[300] = {0};
    int ret = 0;
    
    sprintf( url, "http://%d.%d.%d.%d/CSUhomepage/getDailyPower", p_slave_ip[0], p_slave_ip[1], p_slave_ip[2], p_slave_ip[3]);

    ret = http_net_post( url, req_str, resp_str);
    if ( ret != 1 )
    {
        /* 失败 */
        return SF_ERR_NDEF;
    }

    cJSON *p_root_js = cJSON_Parse( resp_str );
    if ( p_root_js == NULL )
    {
        return SF_ERR_NO_OBJECT;
    }

    cJSON *p_data_js = cJSON_GetObjectItem( p_root_js, "data" );
    if ( p_data_js == NULL )
    {
        cJSON_Delete( p_root_js );
        return SF_ERR_NO_OBJECT;
    }

    cJSON *p_batPower_js  = cJSON_GetObjectItem( p_data_js, "batPower" );
    cJSON *p_pccPower_js  = cJSON_GetObjectItem( p_data_js, "pccPower" );
    cJSON *p_pvPower_js   = cJSON_GetObjectItem( p_data_js, "pvPower" );
    cJSON *p_loadPower_js = cJSON_GetObjectItem( p_data_js, "loadPower" );

    if (   p_batPower_js  == NULL
        || p_pccPower_js  == NULL
        || p_pvPower_js   == NULL
        || p_loadPower_js == NULL )
    {
        cJSON_Delete( p_root_js );
        return SF_ERR_NO_OBJECT;
    }

    for (size_t i = 0; i < ARRAY_SIZE( p_power_info->meter_power); i++)
    {
        p_power_info->meter_power[i] = cJSON_GetArrayItem( p_batPower_js, i )->valuedouble;
    }
    
    for (size_t i = 0; i < ARRAY_SIZE( p_power_info->pcc_power ); i++)
    {
        p_power_info->pcc_power[i] = cJSON_GetArrayItem( p_pccPower_js, i )->valuedouble;
    }
    
    for (size_t i = 0; i < ARRAY_SIZE( p_power_info->pv_power ); i++)
    {
        p_power_info->pv_power[i] = cJSON_GetArrayItem( p_pvPower_js, i )->valuedouble;
    }
    
    for (size_t i = 0; i < ARRAY_SIZE( p_power_info->load_power ); i++)
    {
        p_power_info->load_power[i] = cJSON_GetArrayItem( p_loadPower_js, i )->valuedouble;
    }
    
    cJSON_Delete( p_root_js );

    return SF_OK;
}

/**
 * @brief    获取日功率数据
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void get_daily_power(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_root = NULL;
    cJSON *p_resp_item = NULL;
    cJSON *p_bat_item = NULL;
    cJSON *p_pv_item = NULL;
    cJSON *p_pcc_item = NULL;
    cJSON *p_load_item = NULL;
    uint8_t response[64] = {0};
    uint8_t *p_action = NULL;
    uint8_t ymd[32] = {0};
    uint8_t *p = NULL;
    uint8_t request_body[128] = {0};
    dev_power_info_t power_data = {0}; 
    dev_power_info_t slave_power_info = {0};
    dev_power_info_t local_power_info = {0};
    power_time_t power_time = {0};
 
    memset( (void*)&power_data, 0, sizeof( dev_power_info_t ) );
    memcpy(request_body,p_msg->body.p,p_msg->body.len);   
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        ENERGY_MANAGE_DEBUG_PRINT("parse request failed.");
        build_empty_response(response,202,"parse request failed.");
        http_back(p_nc,response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action,"getDailyPower"))
    {
        ENERGY_MANAGE_DEBUG_PRINT("action is not right.");
        build_empty_response(response,203,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
 
    strcpy(ymd,cJSON_GetObjectItem(p_request,"ymd")->valuestring); 
    cJSON_Delete(p_request);
 
    sscanf(ymd,"%d-%d-%d", &power_time.year, &power_time.month, &power_time.day);

    p_resp_item = cJSON_CreateObject();
    if(p_resp_item == NULL)
    {
        ENERGY_MANAGE_DEBUG_PRINT("create json obj failed.");
        return ;
    }

    //计量表
    select_power_sqlite_db_day(&power_time, ymd, &power_data, ENERGY_METER);
    select_power_sqlite_db_day(&power_time, ymd, &power_data, ENERGY_FLOW);
    
    csu_comb_setting_t *p_csu_comb_setting = &sdk_shm_get()->csu_combine_data.comb_setting;
    csu_node_info_t *p_csu_node_info = sdk_shm_get()->csu_combine_data.slave_info;

    memcpy( &local_power_info, &power_data, sizeof( dev_power_info_t ) );
    // dev_power_info_print( &local_power_info );

    if (   p_csu_comb_setting->comb_enable == SF_TRUE 
        && p_csu_comb_setting->comb_role   == CSU_ROLE_MASTER )
    {
        /* 主机需要对从机数据做累加 */
        for (size_t i = 0; i < (p_csu_comb_setting->master.comb_num - 1); i++)
        {
            memset( &slave_power_info, 0, sizeof( dev_power_info_t ));
            if (   p_csu_node_info[i].valid  == SF_TRUE 
                && p_csu_node_info[i].online == SF_TRUE )
            {
                /* 对在线的从机数据进行累加 */
                get_csu_comb_slave_daily_power( p_csu_node_info[i].ip, request_body, &slave_power_info );

                // printf("slave_power_info\r\n");
                // dev_power_info_print( &slave_power_info );

                for (size_t j = 0; j < ARRAY_SIZE( local_power_info.meter_power ); j++)
                {
                    local_power_info.meter_power[j] += slave_power_info.meter_power[j];
                }
                for (size_t j = 0; j < ARRAY_SIZE( local_power_info.load_power ); j++)
                {
                    /* 负载功率直接用能量守恒计算得出 */
                    /**
                     * 中心点角度 
                     * pv    +放电
                     * meter +放电 -充电
                     * pcc   +输出 -输入
                     **/
                    local_power_info.load_power[j] = local_power_info.meter_power[j] + local_power_info.pv_power[j] - local_power_info.pcc_power[j];
                    // printf( "[%d]load_power:%f = meter_power:%f + pv_power:%f - pcc_power:%f ;\r\n", 
                    //     j ,local_power_info.load_power[j] , local_power_info.meter_power[j] , local_power_info.pv_power[j], local_power_info.pcc_power[j] );
                    /* 四舍五入，保留小数点后3位 */
                    local_power_info.load_power[j] = round( local_power_info.load_power[j] * 1000 ) / 1000;
                    if ( local_power_info.load_power[j] < 0 )
                    {
                        local_power_info.load_power[j] = 0;
                    }

                }
            }
        }
    }
    
    //能流
    cJSON_AddItemToObject(p_resp_item,"batPower",cJSON_CreateDoubleArray(local_power_info.meter_power, POWER_RECORD_CNT_PER_DAY)); 
    cJSON_AddItemToObject(p_resp_item,"pccPower",cJSON_CreateDoubleArray(local_power_info.pcc_power, POWER_RECORD_CNT_PER_DAY));  
    cJSON_AddItemToObject(p_resp_item,"pvPower",cJSON_CreateDoubleArray(local_power_info.pv_power, POWER_RECORD_CNT_PER_DAY)); 
    cJSON_AddItemToObject(p_resp_item,"loadPower",cJSON_CreateDoubleArray(local_power_info.load_power, POWER_RECORD_CNT_PER_DAY)); 

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        ENERGY_MANAGE_DEBUG_PRINT("create json obj failed.");
        cJSON_Delete(p_resp_item);
        return ;
    }
    cJSON_AddNumberToObject(p_resp_root,"code",OK);
    cJSON_AddItemToObject(p_resp_root,"data",p_resp_item);
    cJSON_AddStringToObject(p_resp_root,"msg","get daily charge discharge successful");
 
    p = cJSON_PrintUnformatted(p_resp_root);
    cJSON_Delete(p_resp_root);
 
    http_back(p_nc,p);
    free(p);
}

/**
 * @brief 能量管理模块初始化
 * @return void
 */
void web_energy_manage_module_init(void)
{
    if(!web_func_attach("/CSUhomepage/getDailyPower", TRANS_UNNEED, get_daily_power))	 	//获取CSU日功率曲线数据
	{
		ENERGY_MANAGE_DEBUG_PRINT("[/CSUhomepage/getDailyPower] attach failed");
	}
    if(!web_func_attach("/CSUhomepage/getDailyChargeDischarge", TRANS_UNNEED, get_daily_charge_discharge))    //获取CSU日充放电数据
	{
		ENERGY_MANAGE_DEBUG_PRINT("[/CSUhomepage/getDailyChargeDischarge] attach failed");
	}
    if(!web_func_attach("/CSUhomepage/getMonthlyChargeDischarge", TRANS_UNNEED, get_monthly_charge_discharge))    //获取CSU月充放电数据
	{
		ENERGY_MANAGE_DEBUG_PRINT("[/CSUhomepage/getMonthlyChargeDischarge] attach failed");
	}
    if(!web_func_attach("/CSUhomePage/getYearChargeDischarge", TRANS_UNNEED, get_yearly_charge_discharge))        //获取CSU年充放电数据
	{
		ENERGY_MANAGE_DEBUG_PRINT("[/CSUhomePage/getYearChargeDischarge] attach failed");
	}
    if(!web_func_attach("/CSUhomepage/getTotalChargeDischarge", TRANS_UNNEED, get_total_charge_discharge))        //获取CSU总充放电数据
	{
		ENERGY_MANAGE_DEBUG_PRINT("[/CSUhomepage/getTotalChargeDischarge] attach failed");
	}
}
