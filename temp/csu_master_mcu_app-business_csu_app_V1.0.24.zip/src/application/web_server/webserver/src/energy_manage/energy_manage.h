#ifndef __ENERGY_MANAGE_H__
#define __ENERGY_MANAGE_H__

#include"mongoose.h"
#include "component/sofar_log.h"

#if (1)
#define ENERGY_MANAGE_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else
#define ENERGY_MANAGE_DEBUG_PRINT(...) {do {} while(0);}
#endif

#define POWER_RECORD_CNT_PER_DAY        288
typedef struct{
    double meter_power[POWER_RECORD_CNT_PER_DAY];
    double pcc_power[POWER_RECORD_CNT_PER_DAY];
    double pv_power[POWER_RECORD_CNT_PER_DAY];
    double load_power[POWER_RECORD_CNT_PER_DAY];
}dev_power_info_t;

enum{
    ENERGY_METER = 0,
    ENERGY_FLOW
};

typedef struct
{
    int16_t year;	        // 年份，如2023
    int16_t month;	        // 月份，1~12
    int16_t day;	        // 日期，1~31
	int16_t hour;	        // 小时，0~23
    int16_t minute;
	int16_t second;
}power_time_t;

/**
 * @brief 能量管理模块初始化
 * @return void
 */
void web_energy_manage_module_init(void);


#endif