#ifndef __SYSTIME_H__
#define __SYSTIME_H__

#include"mongoose.h"
#include "component/sofar_log.h"

#if (1)
#define SYS_TIME_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else
#define SYS_TIME_DEBUG_PRINT(...) {do {} while(0);}
#endif

/**
 * @brief 系统时间模块初始化
 * @return void
 */
void web_sys_time_module_init(void);

#endif