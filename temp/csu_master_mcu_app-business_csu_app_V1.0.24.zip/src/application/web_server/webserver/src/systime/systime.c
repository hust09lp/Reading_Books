#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sdk/sdk_public.h"
#include "sofar_errors.h"
#include "cJSON.h"
#include "systime.h"
#include "common.h"
#include "operation_log.h"
#include "web_broker.h"
#include "app_common.h"
#include "data_shm.h"
#include "sdk_shm.h"

//时区调整
struct timezone_mapping {
        const int timezone_id;
        const char* timezone_path;
    };
 
//时区对应的时区文件,其中有一些文案错误的，等web改完再改。比如UTC-0500中间没有冒号，阿德莱德写成阿德菜德
static const struct timezone_mapping timezone_mappings[] = {
    {1,   "/opt/share/zoneinfo/Europe/Andorra"},
    {2,   "/opt/share/zoneinfo/Asia/Dubai"},
    {3,   "/opt/share/zoneinfo/Asia/Kabul"},
    {4,   "/opt/share/zoneinfo/America/Antigua"},
    {5,   "/opt/share/zoneinfo/America/Anguilla"},
    {6,   "/opt/share/zoneinfo/Europe/Tirane"},
    {7,   "/opt/share/zoneinfo/Asia/Yerevan"},
    {8,   "/opt/share/zoneinfo/Africa/Luanda"},
    {9,   "/opt/share/zoneinfo/Antarctica/McMurdo"},
    {10,  "/opt/share/zoneinfo/Antarctica/Casey"},
    {11,  "/opt/share/zoneinfo/Antarctica/Davis"},
    {12,  "/opt/share/zoneinfo/Antarctica/DumontDUrville"},
    {13,  "/opt/share/zoneinfo/Antarctica/Mawson"},
    {14,  "/opt/share/zoneinfo/Antarctica/Palmer"},
    {15,  "/opt/share/zoneinfo/Antarctica/Rothera"},
    {16,  "/opt/share/zoneinfo/Antarctica/Syowa"},
    {17,  "/opt/share/zoneinfo/Antarctica/Troll"},
    {18,  "/opt/share/zoneinfo/Antarctica/Vostok"},
    {19,  "/opt/share/zoneinfo/America/Argentina/Buenos_Aires"},
    {20,  "/opt/share/zoneinfo/America/Argentina/Cordoba"},
    {21,  "/opt/share/zoneinfo/America/Argentina/Salta"},
    {22,  "/opt/share/zoneinfo/America/Argentina/Jujuy"},
    {23,  "/opt/share/zoneinfo/America/Argentina/Tucuman"},
    {24,  "/opt/share/zoneinfo/America/Argentina/Catamarca"},
    {25,  "/opt/share/zoneinfo/America/Argentina/La_Rioja"},
    {26,  "/opt/share/zoneinfo/America/Argentina/San_Juan"},
    {27,  "/opt/share/zoneinfo/America/Argentina/Mendoza"},
    {28,  "/opt/share/zoneinfo/America/Argentina/San_Luis"},
    {29,  "/opt/share/zoneinfo/America/Argentina/Rio_Gallegos"},
    {30,  "/opt/share/zoneinfo/America/Argentina/Ushuaia"},
    {31,  "/opt/share/zoneinfo/Pacific/Pago_Pago"},
    {32,  "/opt/share/zoneinfo/Europe/Vienna"},
    {33,  "/opt/share/Australia/Lord_Howe"},
    {34,  "/opt/share/zoneinfo/Antarctica/Macquarie"},
    {35,  "/opt/share/zoneinfo/Australia/Hobart"},
    {36,  "/opt/share/zoneinfo/Australia/Melbourne"},
    {37,  "/opt/share/zoneinfo/Australia/Sydney"},
    {38,  "/opt/share/zoneinfo/Australia/Broken_Hill"},
    {39,  "/opt/share/zoneinfo/Australia/Brisbane"},
    {40,  "/opt/share/zoneinfo/Australia/Lindeman"},
    {41,  "/opt/share/zoneinfo/Australia/Adelaide"},
    {42,  "/opt/share/zoneinfo/Australia/Darwin"},
    {43,  "/opt/share/zoneinfo/Australia/Perth"},
    {44,  "/opt/share/zoneinfo/Australia/Eucla"},
    {45,  "/opt/share/zoneinfo/America/Aruba"},
    {46,  "/opt/share/zoneinfo/Europe/Mariehamn"},
    {47,  "/opt/share/zoneinfo/Asia/Baku"},
    {48,  "/opt/share/zoneinfo/Europe/Sarajevo"},
    {49,  "/opt/share/zoneinfo/America/Barbados"},
    {50,  "/opt/share/zoneinfo/Asia/Dhaka"},
    {51,  "/opt/share/zoneinfo/Europe/Brussels"},
    {52,  "/opt/share/zoneinfo/Africa/Ouagadougou"},
    {53,  "/opt/share/zoneinfo/Europe/Sofia"},
    {54,  "/opt/share/zoneinfo/Asia/Bahrain"},
    {55,  "/opt/share/zoneinfo/Africa/Bujumbura"},
    {56,  "/opt/share/zoneinfo/Africa/Porto-Novo"},
    {57,  "/opt/share/zoneinfo/America/St_Barthelemy"},
    {58,  "/opt/share/zoneinfo/Atlantic/Bermuda"},
    {59,  "/opt/share/zoneinfo/Asia/Brunei"},
    {60,  "/opt/share/zoneinfo/America/La_Paz"},
    {61,  "/opt/share/zoneinfo/America/Kralendijk"},
    {62,  "/opt/share/zoneinfo/America/Noronha"},
    {63,  "/opt/share/zoneinfo/America/Belem"},
    {64,  "/opt/share/zoneinfo/America/Fortaleza"},
    {65,  "/opt/share/zoneinfo/America/Recife"},
    {66,  "/opt/share/zoneinfo/America/Araguaina"},
    {67,  "/opt/share/zoneinfo/America/Maceio"},
    {68,  "/opt/share/zoneinfo/America/Bahia"},
    {69,  "/opt/share/zoneinfo/America/Sao_Paulo"},
    {70,  "/opt/share/zoneinfo/America/Campo_Grande"},
    {71,  "/opt/share/zoneinfo/America/Cuiaba"},
    {72,  "/opt/share/zoneinfo/America/Santarem"},
    {73,  "/opt/share/zoneinfo/America/Porto_Velho"},
    {74,  "/opt/share/zoneinfo/America/Boa_Vista"},
    {75,  "/opt/share/zoneinfo/America/Manaus"},
    {76,  "/opt/share/zoneinfo/America/Eirunepe"},
    {77,  "/opt/share/zoneinfo/America/Rio_Branco"},
    {78,  "/opt/share/zoneinfo/America/Nassau"},
    {79,  "/opt/share/zoneinfo/Asia/Thimphu"},
    {80,  "/opt/share/zoneinfo/Africa/Gaborone"},
    {81,  "/opt/share/zoneinfo/Europe/Minsk"},
    {82,  "/opt/share/zoneinfo/America/Belize"},
    {83,  "/opt/share/zoneinfo/America/St_Johns"},
    {84,  "/opt/share/zoneinfo/America/Halifax"},
    {85,  "/opt/share/zoneinfo/America/Glace_Bay"},
    {86,  "/opt/share/zoneinfo/America/Moncton"},
    {87,  "/opt/share/zoneinfo/America/Goose_Bay"},
    {88,  "/opt/share/zoneinfo/America/Blanc-Sablon"},
    {89,  "/opt/share/zoneinfo/America/Toronto"},
    {90,  "/opt/share/zoneinfo/America/Iqaluit"},
    {91,  "/opt/share/zoneinfo/America/Atikokan"},
    {92,  "/opt/share/zoneinfo/America/Winnipeg"},
    {93,  "/opt/share/zoneinfo/America/Resolute"},
    {94,  "/opt/share/zoneinfo/America/Rankin_Inlet"},
    {95,  "/opt/share/zoneinfo/America/Regina"},
    {96,   "/opt/share/zoneinfo/America/Swift_Current"},
    {97,  "/opt/share/zoneinfo/America/Edmonton"},
    {98,  "/opt/share/zoneinfo/America/Cambridge_Bay"},
    {99,  "/opt/share/zoneinfo/America/Inuvik"},
    {100, "/opt/share/zoneinfo/America/Creston"},
    {101, "/opt/share/zoneinfo/America/Dawson_Creek"},
    {102, "/opt/share/zoneinfo/America/Fort_Nelson"},
    {103, "/opt/share/zoneinfo/America/Whitehorse"},
    {104, "/opt/share/zoneinfo/America/Dawson"},
    {105, "/opt/share/zoneinfo/America/Vancouver"},
    {106, "/opt/share/zoneinfo/Indian/Cocos"},
    {107, "/opt/share/zoneinfo/Africa/Kinshasa"},
    {108, "/opt/share/zoneinfo/Africa/Lubumbashi"},
    {109, "/opt/share/zoneinfo/Africa/Bangui"},
    {110, "/opt/share/zoneinfo/Africa/Brazzaville"},
    {111, "/opt/share/zoneinfo/Europe/Zurich"},
    {112, "/opt/share/zoneinfo/Africa/Abidjan"},
    {113, "/opt/share/zoneinfo/Pacific/Rarotonga"},
    {114, "/opt/share/zoneinfo/America/Santiago"},
    {115, "/opt/share/zoneinfo/America/Punta_Arenas"},
    {116, "/opt/share/zoneinfo/Pacific/Easter"},
    {117, "/opt/share/zoneinfo/Africa/Douala"},
    {118, "/opt/share/zoneinfo/Asia/Shanghai"},
    {119, "/opt/share/zoneinfo/Asia/Urumqi"},
    {120, "/opt/share/zoneinfo/America/Bogota"},
    {121, "/opt/share/zoneinfo/America/Costa_Rica"},
    {122, "/opt/share/zoneinfo/America/Havana"},
    {123, "/opt/share/zoneinfo/Atlantic/Cape_Verde"},
    {124, "/opt/share/zoneinfo/America/Curacao"},
    {125, "/opt/share/zoneinfo/Indian/Christmas"},
    {126, "/opt/share/zoneinfo/Asia/Nicosia"},
    {127, "/opt/share/zoneinfo/Asia/Famagusta"},
    {128, "/opt/share/zoneinfo/Europe/Prague"},
    {129, "/opt/share/zoneinfo/Europe/Berlin"},
    {130, "/opt/share/zoneinfo/Europe/Busingen"},
    {131, "/opt/share/zoneinfo/Africa/Djibouti"},
    {132, "/opt/share/zoneinfo/Europe/Copenhagen"},
    {133, "/opt/share/zoneinfo/America/Dominica"},
    {134, "/opt/share/zoneinfo/America/Santo_Domingo"},
    {135, "/opt/share/zoneinfo/Africa/Algiers"},
    {136, "/opt/share/zoneinfo/America/Guayaquil"},
    {137, "/opt/share/zoneinfo/Pacific/Galapagos"},
    {138, "/opt/share/zoneinfo/Europe/Tallinn"},
    {139, "/opt/share/zoneinfo/Africa/Cairo"},
    {140, "/opt/share/zoneinfo/Africa/El_Aaiun"},
    {141, "/opt/share/zoneinfo/Africa/Asmara"},
    {142, "/opt/share/zoneinfo/Europe/Madrid"},
    {143, "/opt/share/zoneinfo/Africa/Ceuta"},
    {144, "/opt/share/zoneinfo/Atlantic/Canary"},
    {145, "/opt/share/zoneinfo/Africa/Addis_Ababa"},
    {146, "/opt/share/zoneinfo/Europe/Helsinki"},
    {147, "/opt/share/zoneinfo/Pacific/Fiji"},
    {148, "/opt/share/zoneinfo/Atlantic/Stanley"},
    {149, "/opt/share/zoneinfo/Pacific/Chuuk"},
    {150, "/opt/share/zoneinfo/Pacific/Pohnpei"},
    {151, "/opt/share/zoneinfo/Pacific/Kosrae"},
    {152, "/opt/share/zoneinfo/Atlantic/Faroe"},
    {153, "/opt/share/zoneinfo/Europe/Paris"},
    {154, "/opt/share/zoneinfo/Africa/Libreville"},
    {155, "/opt/share/zoneinfo/Europe/London"},
    {156, "/opt/share/zoneinfo/America/Grenada"},
    {157, "/opt/share/zoneinfo/Asia/Tbilisi"},
    {158, "/opt/share/zoneinfo/America/Cayenne"},
    {159, "/opt/share/zoneinfo/Europe/Guernsey"},
    {160, "/opt/share/zoneinfo/Africa/Accra"},
    {161, "/opt/share/zoneinfo/Europe/Gibraltar"},
    {162, "/opt/share/zoneinfo/America/Nuuk"},
    {163, "/opt/share/zoneinfo/America/Danmarkshavn"},
    {164, "/opt/share/zoneinfo/America/Scoresbysund"},
    {165, "/opt/share/zoneinfo/America/Thule"},
    {166, "/opt/share/zoneinfo/Africa/Banjul"},
    {167, "/opt/share/zoneinfo/Africa/Conakry"},
    {168, "/opt/share/zoneinfo/America/Guadeloupe"},
    {169, "/opt/share/zoneinfo/Africa/Malabo"},
    {170, "/opt/share/zoneinfo/Europe/Athens"},
    {171, "/opt/share/zoneinfo/Atlantic/South_Georgia"},
    {172, "/opt/share/zoneinfo/America/Guatemala"},
    {173, "/opt/share/zoneinfo/Pacific/Guam"},
    {174, "/opt/share/zoneinfo/Africa/Bissau"},
    {175, "/opt/share/zoneinfo/America/Guyana"},
    {176, "/opt/share/zoneinfo/Asia/Hong_Kong"},
    {177, "/opt/share/zoneinfo/America/Tegucigalpa"},
    {178, "/opt/share/zoneinfo/Europe/Zagreb"},
    {179, "/opt/share/zoneinfo/America/Port-au-Prince"},
    {180, "/opt/share/zoneinfo/Europe/Budapest"},
    {181, "/opt/share/zoneinfo/Asia/Jakarta"},
    {182, "/opt/share/zoneinfo/Asia/Pontianak"},
    {183, "/opt/share/zoneinfo/Asia/Makassar"},
    {184, "/opt/share/zoneinfo/Asia/Jayapura"},
    {185, "/opt/share/zoneinfo/Europe/Dublin"},
    {186, "/opt/share/zoneinfo/Asia/Jerusalem"},
    {187, "/opt/share/zoneinfo/Europe/Isle_of_Man"},
    {188, "/opt/share/zoneinfo/Asia/Kolkata"},
    {189, "/opt/share/zoneinfo/Indian/Chagos"},
    {190, "/opt/share/zoneinfo/Asia/Baghdad"},
    {191, "/opt/share/zoneinfo/Asia/Tehran"},
    {192, "/opt/share/zoneinfo/Atlantic/Reykjavik"},
    {193, "/opt/share/zoneinfo/Europe/Rome"},
    {194, "/opt/share/zoneinfo/Europe/Jersey"},
    {195, "/opt/share/zoneinfo/America/Jamaica"},
    {196, "/opt/share/zoneinfo/Asia/Amman"},
    {197, "/opt/share/zoneinfo/Asia/Tokyo"},
    {198, "/opt/share/zoneinfo/Africa/Nairobi"},
    {199, "/opt/share/zoneinfo/Asia/Bishkek"},
    {200, "/opt/share/zoneinfo/Asia/Phnom_Penh"},
    {201, "/opt/share/zoneinfo/Pacific/Tarawa"},
    {202, "/opt/share/zoneinfo/Pacific/Kanton"},
    {203, "/opt/share/zoneinfo/Pacific/Kiritimati"},
    {204, "/opt/share/zoneinfo/Indian/Comoro"},
    {205, "/opt/share/zoneinfo/America/St_Kitts"},
    {206, "/opt/share/zoneinfo/Asia/Pyongyang"},
    {207, "/opt/share/zoneinfo/Asia/Seoul"},
    {208, "/opt/share/zoneinfo/Asia/Kuwait"},
    {209, "/opt/share/zoneinfo/America/Cayman"},
    {210, "/opt/share/zoneinfo/Asia/Almaty"},
    {211, "/opt/share/zoneinfo/Asia/Qyzylorda"},
    {212, "/opt/share/zoneinfo/Asia/Qostanay"},
    {213, "/opt/share/zoneinfo/Asia/Aqtobe"},
    {214, "/opt/share/zoneinfo/Asia/Aqtau"},
    {215, "/opt/share/zoneinfo/Asia/Atyrau"},
    {216, "/opt/share/zoneinfo/Asia/Oral"},
    {217, "/opt/share/zoneinfo/Asia/Vientiane"},
    {218, "/opt/share/zoneinfo/Asia/Beirut"},
    {219, "/opt/share/zoneinfo/America/St_Lucia"},
    {220, "/opt/share/zoneinfo/Europe/Vaduz"},
    {221, "/opt/share/zoneinfo/Asia/Colombo"},
    {222, "/opt/share/zoneinfo/Africa/Monrovia"},
    {223, "/opt/share/zoneinfo/Africa/Maseru"},
    {224, "/opt/share/zoneinfo/Europe/Vilnius"},
    {225, "/opt/share/zoneinfo/Europe/Luxembourg"},
    {226, "/opt/share/zoneinfo/Europe/Riga"},
    {227, "/opt/share/zoneinfo/Africa/Tripoli"},
    {228, "/opt/share/zoneinfo/Africa/Casablanca"},
    {229, "/opt/share/zoneinfo/Europe/Monaco"},
    {230, "/opt/share/zoneinfo/Europe/Chisinau"},
    {231, "/opt/share/zoneinfo/Europe/Podgorica"},
    {232, "/opt/share/zoneinfo/America/Marigot"},
    {233, "/opt/share/zoneinfo/Indian/Antananarivo"},
    {234, "/opt/share/zoneinfo/Pacific/Majuro"},
    {235, "/opt/share/zoneinfo/Pacific/Kwajalein"},
    {236, "/opt/share/zoneinfo/Europe/Skopje"},
    {237, "/opt/share/zoneinfo/Africa/Bamako"},
    {238, "/opt/share/zoneinfo/Asia/Yangon"},
    {239, "/opt/share/zoneinfo/Asia/Ulaanbaatar"},
    {240, "/opt/share/zoneinfo/Asia/Hovd"},
    {241, "/opt/share/zoneinfo/Asia/Macau"},
    {242, "/opt/share/zoneinfo/Pacific/Saipan"},
    {243, "/opt/share/zoneinfo/America/Martinique"},
    {244, "/opt/share/zoneinfo/Africa/Nouakchott"},
    {245, "/opt/share/zoneinfo/America/Montserrat"},
    {246, "/opt/share/zoneinfo/Europe/Malta"},
    {247, "/opt/share/zoneinfo/Indian/Mauritius"},
    {248, "/opt/share/zoneinfo/Indian/Maldives"},
    {249, "/opt/share/zoneinfo/Africa/Blantyre"},
    {250, "/opt/share/zoneinfo/America/Mexico_City"},
    {251, "/opt/share/zoneinfo/America/Cancun"},
    {252, "/opt/share/zoneinfo/America/Merida"},
    {253, "/opt/share/zoneinfo/America/Monterrey"},
    {254, "/opt/share/zoneinfo/America/Matamoros"},
    {255, "/opt/share/zoneinfo/America/Chihuahua"},
    {256, "/opt/share/zoneinfo/America/Ciudad_Juarez"},
    {257, "/opt/share/zoneinfo/America/Ojinaga"},
    {258, "/opt/share/zoneinfo/America/Mazatlan"},
    {259, "/opt/share/zoneinfo/America/Bahia_Banderas"},
    {260, "/opt/share/zoneinfo/America/Hermosillo"},
    {261, "/opt/share/zoneinfo/America/Tijuana"},
    {262, "/opt/share/zoneinfo/Asia/Kuala_Lumpur"},
    {263, "/opt/share/zoneinfo/Asia/Kuching"},
    {264, "/opt/share/zoneinfo/Africa/Maputo"},
    {265, "/opt/share/zoneinfo/Africa/Windhoek"},
    {266, "/opt/share/zoneinfo/Pacific/Noumea"},
    {267, "/opt/share/zoneinfo/Africa/Niamey"},
    {268, "/opt/share/zoneinfo/Pacific/Norfolk"},
    {269, "/opt/share/zoneinfo/Africa/Lagos"},
    {270, "/opt/share/zoneinfo/America/Managua"},
    {271, "/opt/share/zoneinfo/Europe/Amsterdam"},
    {272, "/opt/share/zoneinfo/Europe/Oslo"},
    {273, "/opt/share/zoneinfo/Asia/Kathmandu"},
    {274, "/opt/share/zoneinfo/Pacific/Nauru"},
    {275, "/opt/share/zoneinfo/Pacific/Niue"},
    {276, "/opt/share/zoneinfo/Pacific/Auckland"},
    {277, "/opt/share/zoneinfo/Pacific/Chatham"},
    {278, "/opt/share/zoneinfo/Asia/Muscat"},
    {279, "/opt/share/zoneinfo/America/Panama"},
    {280, "/opt/share/zoneinfo/America/Lima"},
    {281, "/opt/share/zoneinfo/Pacific/Tahiti"},
    {282, "/opt/share/zoneinfo/Pacific/Marquesas"},
    {283, "/opt/share/zoneinfo/Pacific/Gambier"},
    {284, "/opt/share/zoneinfo/Pacific/Port_Moresby"},
    {285, "/opt/share/zoneinfo/Pacific/Bougainville"},
    {286, "/opt/share/zoneinfo/Asia/Manila"},
    {287, "/opt/share/zoneinfo/Asia/Karachi"},
    {288, "/opt/share/zoneinfo/Europe/Warsaw"},
    {289, "/opt/share/zoneinfo/America/Miquelon"},
    {290, "/opt/share/zoneinfo/Pacific/Pitcairn"},
    {291, "/opt/share/zoneinfo/America/Puerto_Rico"},
    {292, "/opt/share/zoneinfo/Asia/Gaza"},
    {293, "/opt/share/zoneinfo/Asia/Hebron"},
    {294, "/opt/share/zoneinfo/Europe/Lisbon"},
    {295, "/opt/share/zoneinfo/Atlantic/Madeira"},
    {296, "/opt/share/zoneinfo/Atlantic/Azores"},
    {297, "/opt/share/zoneinfo/Pacific/Palau"},
    {298, "/opt/share/zoneinfo/America/Asuncion"},
    {299, "/opt/share/zoneinfo/Asia/Qatar"},
    {300, "/opt/share/zoneinfo/Indian/Reunion"},
    {301, "/opt/share/zoneinfo/Europe/Bucharest"},
    {302, "/opt/share/zoneinfo/Europe/Belgrade"},
    {303, "/opt/share/zoneinfo/Europe/Kaliningrad"},
    {304, "/opt/share/zoneinfo/Europe/Moscow"},
    {305, "/opt/share/zoneinfo/Europe/Simferopol"},
    {306, "/opt/share/zoneinfo/Europe/Kirov"},
    {307, "/opt/share/zoneinfo/Europe/Volgograd"},
    {308, "/opt/share/zoneinfo/Europe/Astrakhan"},
    {309, "/opt/share/zoneinfo/Europe/Saratov"},
    {310, "/opt/share/zoneinfo/Europe/Ulyanovsk"},
    {311, "/opt/share/zoneinfo/Europe/Samara"},
    {312, "/opt/share/zoneinfo/Asia/Yekaterinburg"},
    {313, "/opt/share/zoneinfo/Asia/Omsk"},
    {314, "/opt/share/zoneinfo/Asia/Novosibirsk"},
    {315, "/opt/share/zoneinfo/Asia/Barnaul"},
    {316, "/opt/share/zoneinfo/Asia/Tomsk"},
    {317, "/opt/share/zoneinfo/Asia/Novokuznetsk"},
    {318, "/opt/share/zoneinfo/Asia/Krasnoyarsk"},
    {319, "/opt/share/zoneinfo/Asia/Irkutsk"},
    {320, "/opt/share/zoneinfo/Asia/Chita"},
    {321, "/opt/share/zoneinfo/Asia/Yakutsk"},
    {322, "/opt/share/zoneinfo/Asia/Khandyga"},
    {323, "/opt/share/zoneinfo/Asia/Vladivostok"},
    {324, "/opt/share/zoneinfo/Asia/Ust-Nera"},
    {325, "/opt/share/zoneinfo/Asia/Magadan"},
    {326, "/opt/share/zoneinfo/Asia/Sakhalin"},
    {327, "/opt/share/zoneinfo/Asia/Srednekolymsk"},
    {328, "/opt/share/zoneinfo/Asia/Kamchatka"},
    {329, "/opt/share/zoneinfo/Asia/Anadyr"},
    {330, "/opt/share/zoneinfo/Africa/Kigali"},
    {331, "/opt/share/zoneinfo/Asia/Riyadh"},
    {332, "/opt/share/zoneinfo/Pacific/Guadalcanal"},
    {333, "/opt/share/zoneinfo/Indian/Mahe"},
    {334, "/opt/share/zoneinfo/Africa/Khartoum"},
    {335, "/opt/share/zoneinfo/Europe/Stockholm"},
    {336, "/opt/share/zoneinfo/Asia/Singapore"},
    {337, "/opt/share/zoneinfo/Atlantic/St_Helena"},
    {338, "/opt/share/zoneinfo/Europe/Ljubljana"},
    {339, "/opt/share/zoneinfo/Arctic/Longyearbyen"},
    {340, "/opt/share/zoneinfo/Europe/Bratislava"},
    {341, "/opt/share/zoneinfo/Africa/Freetown"},
    {342, "/opt/share/zoneinfo/Europe/San_Marino"},
    {343, "/opt/share/zoneinfo/Africa/Dakar"},
    {344, "/opt/share/zoneinfo/Africa/Mogadishu"},
    {345, "/opt/share/zoneinfo/America/Paramaribo"},
    {346, "/opt/share/zoneinfo/Africa/Juba"},
    {347, "/opt/share/zoneinfo/Africa/Sao_Tome"},
    {348, "/opt/share/zoneinfo/America/El_Salvador"},
    {349, "/opt/share/zoneinfo/America/Lower_Princes"},
    {350, "/opt/share/zoneinfo/Asia/Damascus"},
    {351, "/opt/share/zoneinfo/Africa/Mbabane"},
    {352, "/opt/share/zoneinfo/America/Grand_Turk"},
    {353, "/opt/share/zoneinfo/Africa/Ndjamena"},
    {354, "/opt/share/zoneinfo/Indian/Kerguelen"},
    {355, "/opt/share/zoneinfo/Africa/Lome"},
    {356, "/opt/share/zoneinfo/Asia/Bangkok"},
    {357, "/opt/share/zoneinfo/Asia/Dushanbe"},
    {358, "/opt/share/zoneinfo/Pacific/Fakaofo"},
    {359, "/opt/share/zoneinfo/Asia/Dili"},
    {360, "/opt/share/zoneinfo/Asia/Ashgabat"},
    {361, "/opt/share/zoneinfo/Africa/Tunis"},
    {362, "/opt/share/zoneinfo/Pacific/Tongatapu"},
    {363, "/opt/share/zoneinfo/Europe/Istanbul"},
    {364, "/opt/share/zoneinfo/America/Port_of_Spain"},
    {365, "/opt/share/zoneinfo/Pacific/Funafuti"},
    {366, "/opt/share/zoneinfo/Asia/Taipei"},
    {367, "/opt/share/zoneinfo/Africa/Dar_es_Salaam"},
    {368, "/opt/share/zoneinfo/Europe/Kyiv"},
    {369, "/opt/share/zoneinfo/Africa/Kampala"},
    {370, "/opt/share/zoneinfo/Pacific/Midway"},
    {371, "/opt/share/zoneinfo/Pacific/Wake"},
    {372, "/opt/share/zoneinfo/America/New_York"},
    {373, "/opt/share/zoneinfo/America/Detroit"},
    {374, "/opt/share/zoneinfo/America/Kentucky/Louisville"},
    {375, "/opt/share/zoneinfo/America/Kentucky/Monticello"},
    {376, "/opt/share/zoneinfo/America/Indiana/Indianapolis"},
    {377, "/opt/share/zoneinfo/America/Indiana/Vincennes"},
    {378, "/opt/share/zoneinfo/America/Indiana/Winamac"},
    {379, "/opt/share/zoneinfo/America/Indiana/Marengo"},
    {380, "/opt/share/zoneinfo/America/Indiana/Petersburg"},
    {381, "/opt/share/zoneinfo/America/Indiana/Vevay"},
    {382, "/opt/share/zoneinfo/America/Chicago"},
    {383, "/opt/share/zoneinfo/America/Indiana/Tell_City"},
    {384, "/opt/share/zoneinfo/America/Indiana/Knox"},
    {385, "/opt/share/zoneinfo/America/Menominee"},
    {386, "/opt/share/zoneinfo/America/North_Dakota/Center"},
    {387, "/opt/share/zoneinfo/America/North_Dakota/New_Salem"},
    {388, "/opt/share/zoneinfo/America/North_Dakota/Beulah"},
    {389, "/opt/share/zoneinfo/America/Denver"},
    {390, "/opt/share/zoneinfo/America/Boise"},
    {391, "/opt/share/zoneinfo/America/Phoenix"},
    {392, "/opt/share/zoneinfo/America/Los_Angeles"},
    {393, "/opt/share/zoneinfo/America/Anchorage"},
    {394, "/opt/share/zoneinfo/America/Juneau"},
    {395, "/opt/share/zoneinfo/America/Sitka"},
    {396, "/opt/share/zoneinfo/America/Metlakatla"},
    {397, "/opt/share/zoneinfo/America/Yakutat"},
    {398, "/opt/share/zoneinfo/America/Nome"},
    {399, "/opt/share/zoneinfo/America/Adak"},
    {400, "/opt/share/zoneinfo/Pacific/Honolulu"},
    {401, "/opt/share/zoneinfo/America/Montevideo"},
    {402, "/opt/share/zoneinfo/Asia/Samarkand"},
    {403, "/opt/share/zoneinfo/Asia/Tashkent"},
    {404, "/opt/share/zoneinfo/Europe/Vatican"},
    {405, "/opt/share/zoneinfo/America/St_Vincent"},
    {406, "/opt/share/zoneinfo/America/Caracas"},
    {407, "/opt/share/zoneinfo/America/Tortola"},
    {408, "/opt/share/zoneinfo/America/St_Thomas"},
    {409, "/opt/share/zoneinfo/Asia/Ho_Chi_Minh"},
    {410, "/opt/share/zoneinfo/Pacific/Efate"},
    {411, "/opt/share/zoneinfo/Pacific/Wallis"},
    {412, "/opt/share/zoneinfo/Pacific/Apia"},
    {413, "/opt/share/zoneinfo/Asia/Aden"},
    {414, "/opt/share/zoneinfo/Indian/Mayotte"},
    {415, "/opt/share/zoneinfo/Africa/Johannesburg"},
    {416, "/opt/share/zoneinfo/Africa/Lusaka"},
    {417, "/opt/share/zoneinfo/Africa/Harare"},
};


/**
 * @brief    根据字符串形式的时区信息，获取时区ID
 * @param	 [in] *p_tz  时区名称
 * @return   时区ID 
 */
uint16_t get_time_zone_id(char *p_tz)
{
    int i = 0;
    int num_mappings = sizeof(timezone_mappings) / sizeof(timezone_mappings[0]);

    for(int i = 0; i < num_mappings; i++)
    {
        if(strstr(timezone_mappings[i].timezone_path, p_tz) != NULL)
        {
            return timezone_mappings[i].timezone_id;
        }
    }
    return 0xFFFF;
}



/**
 * @brief    根据字符串形式的时区信息，为系统设置对应的时区
 * @param	 [in] timezone_id 时区ID 
 * @param	 [out] *p_tz  时区名称
 * @return
 */
void convert_time_zone(const int timezone_id, char *p_tz)
{
    char command[256] = {0};
    int offset = strlen("\"/opt/share/zoneinfo/") - 1;
    int num_mappings = sizeof(timezone_mappings) / sizeof(timezone_mappings[0]);

    if(timezone_id >= 1 && timezone_id <= num_mappings)
    {
        SYS_TIME_DEBUG_PRINT("time zone id set to %d.\n",timezone_id);
        SYS_TIME_DEBUG_PRINT("time zone is set to %s.\n",timezone_mappings[timezone_id - 1].timezone_path);
        strncpy(p_tz, &timezone_mappings[timezone_id - 1].timezone_path[offset], strlen(timezone_mappings[timezone_id - 1].timezone_path) - offset);
        SYS_TIME_DEBUG_PRINT("tz set to %s.\n", p_tz);
        sprintf(command, "ln -sf %s /etc/localtime", timezone_mappings[timezone_id - 1].timezone_path);
        system("mount -o remount,rw /");
        system("rm /etc/localtime");
        system(command);
        system("hwclock -w");
        system("mount -o remount,ro /");
    }
}


void get_system_time_info(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request;
    cJSON *p_conf;
    cJSON *p_resp_root;
    cJSON *p_resp_item;
    uint8_t response[128];
    uint8_t *p_action;
    uint8_t *p;
    uint16_t timezone_id;
    char *p_tz = NULL;
    uint8_t request_body[128] = {0};
    uint8_t content[128] = {0};
    sdk_rtc_t rtc_time = {0};
    uint8_t date_time[32] = {0};
    FILE *fp = NULL;
    int32_t ret = 0;

    memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		SYS_TIME_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,202,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getSysTimeInfo"))
	{
		SYS_TIME_DEBUG_PRINT("action is not right.");
		build_empty_response(response,203,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

    fp = fopen(SYSTIME_JSON_FILE,"r");
    if(fp == NULL)
    {
        SYS_TIME_DEBUG_PRINT("open json file %s failed.",SYSTIME_JSON_FILE);  
        return;   
    }
    fread(content, 1, 128, fp);
    fclose(fp);

    p_conf = cJSON_Parse(content);
    if(p_conf == NULL)
    {
        SYS_TIME_DEBUG_PRINT("parse file %s content failed.",SYSTIME_JSON_FILE);
        return;
    }
    if(cJSON_GetObjectItem(p_conf,"tz") != NULL)
    {
        p_tz = cJSON_GetObjectItem(p_conf,"tz")->valuestring;
    }
    if(p_tz != NULL)
    {
        timezone_id = get_time_zone_id(p_tz);
    }
    
    cJSON_Delete(p_conf);
    
    p_resp_item = cJSON_CreateObject();
    if(p_resp_item == NULL)
    {
        SYS_TIME_DEBUG_PRINT("create json  obj failed.");
        return;       
    }

	ret = sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
	if (ret != 0)
    {
		SYS_TIME_DEBUG_PRINT((int8_t *)"\n [%s:%d] sdk_rtc_get fail \n", __func__, __LINE__);
		return;
    }
	snprintf(date_time, 32, "%04d-%02d-%02d %02d:%02d:%02d", 2000 + rtc_time.tm_year,rtc_time.tm_mon, rtc_time.tm_day, rtc_time.tm_hour, rtc_time.tm_min, rtc_time.tm_sec);

    cJSON_AddStringToObject(p_resp_item,"currentTime", date_time);
    cJSON_AddNumberToObject(p_resp_item,"timeZoneID", timezone_id);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        SYS_TIME_DEBUG_PRINT("create json  obj failed.");
        cJSON_Delete(p_resp_item);
        return;       
    }
    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddItemToObject(p_resp_root,"data",p_resp_item);
    cJSON_AddStringToObject(p_resp_root,"msg","getSysTimeInfo successfu.");

    p = cJSON_PrintUnformatted(p_resp_root);
    http_back(p_nc,p);
    free(p);
    cJSON_Delete(p_resp_root);
}


/**
 * @brief    设置系统时间
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void ntp_sync_time(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_conf = NULL;
    uint8_t *p_action = NULL;
    uint8_t *p_status = NULL;
    uint8_t *p_server = NULL;
    uint16_t port;
    uint16_t timezone_id;
    uint8_t *p = NULL;
    uint8_t response[128];
    uint8_t request_body[512] = {0};
    uint8_t content[128] = {0};
    char cmd[256] = {0};
    char recv_data[256] = {0};
    FILE *fp = NULL;
    operation_log_t op_log;
	uint8_t cur_user[32] = {0};

    memcpy(request_body,p_msg->body.p,p_msg->body.len);	
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		SYS_TIME_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"ntpSyncTime"))
	{
		SYS_TIME_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    /*NTP服务器相关参数获取*/
    p_status = cJSON_GetObjectItem(p_request,"ntpStatus")->valuestring;
    p_server = cJSON_GetObjectItem(p_request,"ntpServer")->valuestring; //用户也可能更新了ntp的服务器
    port = cJSON_GetObjectItem(p_request,"ntpPort")->valueint;

    /*记录配置*/
    fp = fopen(SYSTIME_JSON_FILE,"r");
    if(fp == NULL)
    {
        SYS_TIME_DEBUG_PRINT("open json file %s failed.",SYSTIME_JSON_FILE);  
        cJSON_Delete(p_request);
        return;   
    }
    fread(content, 1, 128, fp);
    fclose(fp);

    p_conf = cJSON_Parse(content);
    if(p_conf == NULL)
    {
        SYS_TIME_DEBUG_PRINT("parse config file %s failed.",SYSTIME_JSON_FILE);
        cJSON_Delete(p_request);
        return;
    }
    cJSON_ReplaceItemInObject(p_conf,"ntpstatus",cJSON_CreateString(p_status));
    cJSON_ReplaceItemInObject(p_conf,"ntpserver",cJSON_CreateString(p_server));
    cJSON_ReplaceItemInObject(p_conf,"ntpport",cJSON_CreateNumber(port));

    p = cJSON_PrintUnformatted(p_conf);
    fp = fopen(SYSTIME_JSON_FILE,"w");
    if(fp == NULL)
    {
        SYS_TIME_DEBUG_PRINT("open json file %s failed.",SYSTIME_JSON_FILE);  
        cJSON_Delete(p_request);
        return;   
    }
    fwrite(p, 1, strlen(p), fp);
    fclose(fp);
    cJSON_Delete(p_conf);
    free(p);

    /*记录操作日志*/
    init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"NTP同步时间");

    /*如果没有使能NTP但是却点击了同步操作，此时不进行响应*/
    if(strcmp(p_status,"enable"))
    {
        SYS_TIME_DEBUG_PRINT("ntp is not enabled.");
		build_empty_response(response,204,"ntp is not enabled");
        strcpy(op_log.op_status,"failed");
        add_one_op_log(&op_log);
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
    }
    
    /*开始进行时间同步*/
    snprintf((char *)cmd, sizeof(cmd) - 1, "ntpdate %s", p_server);
    SYS_TIME_DEBUG_PRINT("p_server = %s.",p_server); 
    fp = popen(cmd,"r");
	fread(recv_data, 1, sizeof(recv_data), fp);
    pclose(fp); 
    if (!strstr(recv_data, "step time server") && !strstr(recv_data, "adjust time server"))
    {
        SYS_TIME_DEBUG_PRINT("sync time failed.");
        strcpy(op_log.op_status,"failed");
        add_one_op_log(&op_log);
        build_empty_response(response,205,"ntp sync time failed");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
    }

    strcpy(op_log.op_status,"success");
    add_one_op_log(&op_log);

    build_empty_response(response, OK, "ntp sync time successful");
    http_back(p_nc,response);
}
 
static void get_ntp_info(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    uint8_t *p_action = NULL;
    cJSON *p_resp_item;
    cJSON *p_resp_root;
    uint8_t response[128];
    uint8_t request_body[128] = {0};
    uint8_t content[128] = {0};
    FILE *fp;
    cJSON *p_conf;
    uint8_t *p_status;
    uint8_t *p_server;
    uint8_t *p;
    uint16_t port;

    memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		SYS_TIME_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getNtpInfo"))
	{
		SYS_TIME_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}
    cJSON_Delete(p_request);

    /*读取NTP服务相关信息*/
    fp = fopen(SYSTIME_JSON_FILE,"r");
    if(fp == NULL)
    {
        SYS_TIME_DEBUG_PRINT("open json file %s failed.",SYSTIME_JSON_FILE);  
        return;   
    }
    fread(content, 1, 128, fp);
    fclose(fp);

    p_conf = cJSON_Parse(content);
    if(p_conf == NULL)
    {
        SYS_TIME_DEBUG_PRINT("parse file %s content failed.",SYSTIME_JSON_FILE);
        return;
    }

    p_status = cJSON_GetObjectItem(p_conf,"ntpstatus")->valuestring;
    p_server = cJSON_GetObjectItem(p_conf,"ntpserver")->valuestring;
    port = cJSON_GetObjectItem(p_conf,"ntpport")->valueint;

    /*将读取到的信息封装为JSON格式*/
    p_resp_item = cJSON_CreateObject();
    if(p_resp_item == NULL)
    {
        SYS_TIME_DEBUG_PRINT("create json  obj failed.");
        cJSON_Delete(p_conf);
        return;       
    }

    cJSON_AddStringToObject(p_resp_item,"ntpStatus",p_status);
    cJSON_AddStringToObject(p_resp_item,"ntpServer",p_server);
    cJSON_AddNumberToObject(p_resp_item,"ntpPort",port);
    cJSON_Delete(p_conf);

    /*将结果返回给前端进行显示*/
    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        SYS_TIME_DEBUG_PRINT("create json  obj failed.");
        cJSON_Delete(p_resp_item);
        return;       
    }
    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddItemToObject(p_resp_root,"data",p_resp_item);
    cJSON_AddStringToObject(p_resp_root,"msg","getNtpInfo successfu.");

    p = cJSON_PrintUnformatted(p_resp_root);
    http_back(p_nc,p);
    free(p);
    cJSON_Delete(p_resp_root);
}

/**
 * @brief    设置系统时间
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void custom_set_time(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    uint8_t *p_action = NULL;
    uint8_t *p_ymd = NULL;  //年月日
    uint8_t *p_hms = NULL;  //时分秒
    uint8_t response[128];
    uint8_t request_body[128] = {0};
    uint8_t cmd[128] = {0};
    operation_log_t op_log;
	uint8_t cur_user[32] = {0};
    web_control_info_t *p_web_control = sdk_shm_web_control_data_get();

    memcpy(request_body,p_msg->body.p,p_msg->body.len);
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		SYS_TIME_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"customSetTime"))
	{
		SYS_TIME_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    p_ymd = cJSON_GetObjectItem(p_request,"customYMD")->valuestring;
    p_hms = cJSON_GetObjectItem(p_request,"customHMS")->valuestring;

    sprintf(cmd,"date -s \"%s %s\"",p_ymd,p_hms);
    system(cmd);
    system("hwclock -w");
    cJSON_Delete(p_request);
    BIT_SET(p_web_control->system_param_flag, 2);

    init_user_basic_info(&op_log);
	get_user_from_http_request(p_msg,cur_user);
	strcpy(op_log.user_name,cur_user);
	get_user_basic_info(&op_log);
	strcpy(op_log.op_type,"同步系统时间");
    strcpy(op_log.op_status,"success");
    add_one_op_log(&op_log);

    build_empty_response(response,OK,"custom set time successful");
    http_back(p_nc,response);
}


/**
 * @brief    设置系统时区
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void set_timezone_info(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_conf = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t response[512];
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint16_t timezone_id;
    uint8_t request_body[512] = {0};
    uint8_t content[256] = {0};
    FILE *fp = NULL;
    operation_log_t op_log;
    uint8_t cur_user[32] = {0};
    char tz[128] = {0};
    web_control_info_t *p_web_control = sdk_shm_web_control_data_get();
    internal_shared_data_t *p_shared_data = sdk_shm_internal_shared_data_get();
 
    memcpy(request_body,p_msg->body.p,p_msg->body.len);        
    p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
    {
        SYS_TIME_DEBUG_PRINT("parse request failed.");
        build_empty_response(response,202,"parse request failed.");
        http_back(p_nc,response);
        return;
    }
    p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(p_action,"setTimeZone"))
    {
        SYS_TIME_DEBUG_PRINT("action is not right.");
        build_empty_response(response,203,"action is not right");
        http_back(p_nc,response);
        cJSON_Delete(p_request);
        return;
    }
 
    /*获取要设置的时区值(ID)*/
    timezone_id = cJSON_GetObjectItem(p_request,"timeZoneID")->valueint;
    cJSON_Delete(p_request);
 
    /*时区转换*/
    convert_time_zone(timezone_id, tz);
 
    /*将新的时区设置保存下来*/
    fp = fopen(SYSTIME_JSON_FILE,"r");
    if(fp == NULL)
    {
        SYS_TIME_DEBUG_PRINT("open json file %s failed.",SYSTIME_JSON_FILE);  
        return;   
    }
    fread(content, 1, 128, fp);
    fclose(fp);
 
    p_conf = cJSON_Parse(content);
    if(p_conf == NULL)
    {
        SYS_TIME_DEBUG_PRINT("parse file %s content failed.",SYSTIME_JSON_FILE);
        return;
    }
    cJSON_ReplaceItemInObject(p_conf,"timezone_id",cJSON_CreateNumber(timezone_id));
    if(cJSON_GetObjectItem(p_conf,"tz") != NULL)
    {
        cJSON_ReplaceItemInObject(p_conf,"tz",cJSON_CreateString(tz));
    }
    else
    {
        cJSON_AddStringToObject(p_conf, "tz", tz);
    }
    
    p = cJSON_PrintUnformatted(p_conf);
 
    fp = fopen(SYSTIME_JSON_FILE,"w");
    if(fp == NULL)
    {
        SYS_TIME_DEBUG_PRINT("open json file %s failed.",SYSTIME_JSON_FILE);  
        cJSON_Delete(p_conf);
        return;   
    }
    fwrite(p, 1, strlen(p), fp);
    fclose(fp);
    cJSON_Delete(p_conf);
    free(p);
 
    /*记录操作日志*/
    init_user_basic_info(&op_log);
    get_user_from_http_request(p_msg,cur_user);
    strcpy(op_log.user_name,cur_user);
    get_user_basic_info(&op_log);
    strcpy(op_log.op_type,"设置时区");
    strcpy(op_log.op_status,"success");
    add_one_op_log(&op_log);
    //通知上报云平台时区信息
    BIT_SET(p_shared_data->tz_update_flag, 0);
    BIT_SET(p_shared_data->tz_update_flag, 1);
    // 时区更新之后需要同步本地时间至CMU CSU-MCU2
    BIT_SET(p_web_control->system_param_flag, 2);
    BIT_SET(p_web_control->system_param_flag, 4);
    /*返回结果到前端*/
    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        SYS_TIME_DEBUG_PRINT("create json  obj failed.");
        return;       
    }
    cJSON_AddNumberToObject(p_resp_root,"code",200);
    cJSON_AddStringToObject(p_resp_root,"msg","setTimeZone successfu.");
 
    p = cJSON_PrintUnformatted(p_resp_root);
    http_back(p_nc,p);
    free(p);
    cJSON_Delete(p_resp_root);
}


/**
 * @brief 系统时间模块初始化
 * @return void
 */
void web_sys_time_module_init(void)
{
    if(!web_func_attach("/system/customSetTime", TRANS_NEED, custom_set_time))
	{
		SYS_TIME_DEBUG_PRINT("[/system/customSetTime] attach failed");
	}
	if(!web_func_attach("/system/getSysTimeInfo", TRANS_UNNEED, get_system_time_info))
	{
		SYS_TIME_DEBUG_PRINT("[/system/getSysTimeInfo] attach failed");
	}
	if(!web_func_attach("/system/ntpSyncTime", TRANS_NEED, ntp_sync_time))
	{
		SYS_TIME_DEBUG_PRINT("[/system/ntpSyncTime] attach failed");
	}
    if(!web_func_attach("/system/getNtpInfo", TRANS_UNNEED, get_ntp_info))
	{
		SYS_TIME_DEBUG_PRINT("[/system/getNtpInfo] attach failed");
	}
    if(!web_func_attach("/system/setTimeZone", TRANS_UNNEED, set_timezone_info))
    {
        SYS_TIME_DEBUG_PRINT("[/system/setTimeZone] attach failed");
    }
}

