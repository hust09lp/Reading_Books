#ifndef __WEB_DATA_TRANS2CMU_H__
#define __WEB_DATA_TRANS2CMU_H__

#include"mongoose.h"
#include "component/sofar_log.h"

#if (1)
#define DATA_TRANS_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else
#define DATA_TRANS_DEBUG_PRINT(...) {do {} while(0);}
#endif


/**
 * @brief    对web数据进行转发处理
 * @param	 [in] *p_nc 连接信息
 * @param	 [in] *p_uri 目标资源URI
 * @param	 [in] *p_req_body web请求报文
 * @param	 [in] cmu_index CMU序号,若为0则对在所有在线设备进行转发
 * @return   无
 */
void web_data_trans_handle(struct mg_connection *p_nc, uint8_t *p_uri, uint8_t *p_req_body, uint8_t cmu_index);


/**
 * @brief    根据URI转发web数据至CMU设备
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @param	 [in] *p_uri  请求URI
 * @return
 */
void web_data_trans2cmu_by_uri(struct mg_connection *p_nc,struct http_message *p_msg, uint8_t *p_uri);


/**
 * @brief 数据转发模块初始化
 * @return void
 */
void web_trans2cmu_module_init(void);

#endif