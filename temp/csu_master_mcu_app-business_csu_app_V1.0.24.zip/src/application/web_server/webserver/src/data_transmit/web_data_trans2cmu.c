#include "cJSON.h"
#include "common.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "libghttp.h"
#include "app_common.h"
#include "web_data_trans2cmu.h"
#include "web_broker.h"
#include "cmu_data_monitor.h"

#define WEB_DATA_BUFF_SIZE  (4 * 1024 * 1024)

static uint8_t cmu_ip_tbl[MAX_SLAVE_COUNT][MAX_IP_LEN] = {CMU1_IP, CMU2_IP, CMU3_IP, CMU4_IP, CMU5_IP, CMU6_IP};


/**
 * @brief    对web数据进行转发
 * @param	 [in] *p_nc 连接信息
 * @param	 [in] *p_uri 目标资源URI
 * @param	 [in] *p_req_body web请求报文
 * @param	 [in] cmu_index CMU序号,若为0则对在所有在线设备进行转发
 * @return   无
 */
static void web_data_trans2cmu(struct mg_connection *p_nc, uint8_t *p_uri, uint8_t *p_req_body, uint8_t cmu_index)
{
    uint8_t ret = 0;
    uint8_t url[128] = {0};
    uint8_t *p_resp_data = NULL;
    uint8_t *p_response_data = NULL;
    cJSON *p_response = NULL;
    uint8_t *p = NULL;

    // 打包URL
    p_resp_data = malloc(WEB_DATA_BUFF_SIZE);
    if(p_resp_data == NULL)
    {
        DATA_TRANS_DEBUG_PRINT("malloc error");
        return;
    }
    p_response_data = malloc(WEB_DATA_BUFF_SIZE);
    if(p_response_data == NULL)
    {
        DATA_TRANS_DEBUG_PRINT("malloc error");
        free(p_resp_data);
        return;
    }
    sprintf(url, "%s%s%s", "http://", cmu_ip_tbl[cmu_index - 1], p_uri);

    ret = http_net_post(url, p_req_body, p_resp_data);
    if(ret != 1)
    {
        DATA_TRANS_DEBUG_PRINT("get cmu data failed.");
        DATA_TRANS_DEBUG_PRINT("resp:%s", p_resp_data);
		build_empty_response(p_response_data,200,"get cmu data failed..");
		http_back(p_nc,p_response_data);
        free(p_resp_data);
        free(p_response_data);
        return;
    }
    // DATA_TRANS_DEBUG_PRINT("resp:%s", resp_data);

    // 解析CMU数据
	p_response = cJSON_Parse(p_resp_data);
    if(p_response == NULL)
	{
        DATA_TRANS_DEBUG_PRINT("parse response failed.");
		build_empty_response(p_response_data,Accepted,"parse response failed.");
		http_back(p_nc,p_response_data);
        free(p_resp_data);
        free(p_response_data);
		return;
	}

    cJSON_AddNumberToObject(p_response,"mcuIndex",cmu_index);

    p = cJSON_PrintUnformatted(p_response);
    strcpy(p_response_data,p);
    cJSON_Delete(p_response);
    free(p);

    http_back(p_nc,p_response_data);
    free(p_resp_data);
    free(p_response_data);
}


/**
 * @brief    对web数据进行转发处理
 * @param	 [in] *p_nc 连接信息
 * @param	 [in] *p_uri 目标资源URI
 * @param	 [in] *p_req_body web请求报文
 * @param	 [in] cmu_index CMU序号,若为0则对在所有在线设备进行转发
 * @return   无
 */
void web_data_trans_handle(struct mg_connection *p_nc, uint8_t *p_uri, uint8_t *p_req_body, uint8_t cmu_index)
{
    if(cmu_index > 0)                                                   //指定设备转发
    {
        web_data_trans2cmu(p_nc, p_uri, p_req_body, cmu_index);
        return;
    }

    for(uint8_t dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
    {
        if(dev_is_online(dev_num))
        {
            web_data_trans2cmu(p_nc, p_uri, p_req_body, dev_num);
        }
    }
}

/**
 * @brief    根据URI转发web数据至CMU设备
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @param	 [in] *p_uri  请求URI
 * @return
 */
void web_data_trans2cmu_by_uri(struct mg_connection *p_nc,struct http_message *p_msg, uint8_t *p_uri)
{
    uint8_t ret = 0;
    cJSON *p_request = NULL;
    uint8_t response[2048];                 
    uint8_t request_body[2048] = {0};
    uint8_t cmu_index = 0;
    uint8_t cur_user[32] = {0};
    uint8_t *p = NULL;

    memcpy(request_body,p_msg->body.p,p_msg->body.len);		
    // DATA_TRANS_DEBUG_PRINT("msg:%s", p_msg->body.p);
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		DATA_TRANS_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

    cJSON *p_mcu_index = cJSON_GetObjectItem(p_request,"mcuIndex");
    if(p_mcu_index == NULL)
    {
        cmu_index = 0;
    }
    else
    {
        cmu_index = cJSON_GetObjectItem(p_request,"mcuIndex")->valueint;
    }

    //添加用户
    get_user_from_http_request(p_msg,cur_user);
    cJSON_AddStringToObject(p_request,"userName",cur_user);

    p = cJSON_PrintUnformatted(p_request);
    web_data_trans_handle(p_nc, p_uri, p, cmu_index);
    free(p);
    cJSON_Delete(p_request);

}


/**
 * @brief 安规参数接口初始化
 * @return void
 */
static void safety_param_func_init(void)
{
    if(!web_func_attach("/debugManager/getTestSafety", TRANS_NEED, NULL))          //获取安规库中安规列表
	{
		DATA_TRANS_DEBUG_PRINT("[/debugManager/getTestSafety] attach failed");
	}
    if(!web_func_attach("/debugManager/setTestSafety", TRANS_NEED, NULL))          //设置使用的安规
	{
		DATA_TRANS_DEBUG_PRINT("[/debugManager/setTestSafety] attach failed");
	}
}


/**
 * @brief 开机处理，因为需要通知MCU2，开关机做特殊处理
 * @return void
 */
static void cmu_sys_power_on(struct mg_connection *p_nc,struct http_message *p_msg)
{
    web_control_info_t *p_web_data = sdk_shm_web_control_data_get();
    BIT_SET(p_web_data->control_cmd_flag, 1);
    p_web_data->control_cmd_data.run_state = 1;
    BIT_SET( p_web_data->csu_comb_web_set_flag, 1 );
}

/**
 * @brief 关机机处理，因为需要通知MCU2，开关机做特殊处理
 * @return void
 */
static void cmu_sys_power_off(struct mg_connection *p_nc,struct http_message *p_msg)
{
    web_control_info_t *p_web_data = sdk_shm_web_control_data_get();
    BIT_SET(p_web_data->control_cmd_flag, 1);
    p_web_data->control_cmd_data.run_state = 0;
    BIT_SET( p_web_data->csu_comb_web_set_flag, 2 );
}


/**
 * @brief 远程控制接口初始化
 * @return void
 */
static void control_cmd_func_init(void)
{
    if(!web_func_attach("/controlCmd/exhaustFanOn", TRANS_NEED, NULL))          //开排气扇
	{
		DATA_TRANS_DEBUG_PRINT("[/controlCmd/exhaustFanOn] attach failed");
	}
    if(!web_func_attach("/controlCmd/exhaustFanOff", TRANS_NEED, NULL))          //关排气扇
	{
		DATA_TRANS_DEBUG_PRINT("[/controlCmd/exhaustFanOff] attach failed");
	}
    if(!web_func_attach("/controlCmd/faultReset", TRANS_NEED, NULL))            //故障重启
	{
		DATA_TRANS_DEBUG_PRINT("[/controlCmd/faultReset] attach failed");
	}
    if(!web_func_attach("/controlCmd/localControl", TRANS_NEED, NULL))            //本地控制
	{
		DATA_TRANS_DEBUG_PRINT("[/controlCmd/localControl] attach failed");
	}
    if(!web_func_attach("/controlCmd/remoteControl", TRANS_NEED, NULL))            //远程控制
	{
		DATA_TRANS_DEBUG_PRINT("[/controlCmd/remoteControl] attach failed");
	}
    if(!web_func_attach("/controlCmd/remotePowerOnCmd", TRANS_NEED, cmu_sys_power_on))          //远程开机
	{
		DATA_TRANS_DEBUG_PRINT("[/controlCmd/remotePowerOnCmd] attach failed");
	}
    if(!web_func_attach("/controlCmd/remotePowerOffCmd", TRANS_NEED, cmu_sys_power_off))         //远程关机
	{
		DATA_TRANS_DEBUG_PRINT("[/controlCmd/remotePowerOffCmd] attach failed");
	}
}


/**
 * @brief 调试数据接口初始化
 * @return void
 */
static void debug_manage_func_init(void)
{
    if(!web_func_attach("/debugManager/getDebugStatus", TRANS_NEED, NULL))          //调试状态获取
	{
		DATA_TRANS_DEBUG_PRINT("[/debugManager/getDebugStatus] attach failed");
	}
    if(!web_func_attach("/debugManager/setDebugStatus", TRANS_NEED, NULL))          //调试状态设置
	{
		DATA_TRANS_DEBUG_PRINT("[/debugManager/setDebugStatus] attach failed");
	}
    if(!web_func_attach("/debugManager/reset", TRANS_NEED, NULL))                   //CMU恢复出厂
	{
		DATA_TRANS_DEBUG_PRINT("[/debugManager/reset] attach failed");
	}
    if(!web_func_attach("/debugManager/PCSSwitchSet", TRANS_NEED, NULL))            //PCS开关设置
	{
		DATA_TRANS_DEBUG_PRINT("[/debugManager/PCSSwitchSet] attach failed");
	}
    if(!web_func_attach("/debugManager/PCSSwitchGet", TRANS_NEED, NULL))            //PCS开关获取
	{
		DATA_TRANS_DEBUG_PRINT("[/debugManager/PCSSwitchGet] attach failed");
	}
    if(!web_func_attach("/debugManager/liquidCoolingSet", TRANS_NEED, NULL))        //液冷系统开关设置
	{
		DATA_TRANS_DEBUG_PRINT("[/debugManager/liquidCoolingSet] attach failed");
	}
    if(!web_func_attach("/debugManager/liquidCoolingGet", TRANS_NEED, NULL))        //液冷系统开关获取
	{
		DATA_TRANS_DEBUG_PRINT("[/debugManager/liquidCoolingGet] attach failed");
	}
    if(!web_func_attach("/debugManager/liquidCoolingParamSet", TRANS_NEED, NULL))    //设置液冷参数
	{
		DATA_TRANS_DEBUG_PRINT("[/debugManager/liquidCoolingParamSet] attach failed");
	}
    if(!web_func_attach("/debugManager/liquidCoolingParamGet", TRANS_NEED, NULL))    //获取液冷参数
	{
		DATA_TRANS_DEBUG_PRINT("[/debugManager/liquidCoolingParamGet] attach failed");
	}
    if(!web_func_attach("/debugManager/CMUSetMode", TRANS_NEED, NULL))              //设置CMU运行模式
	{
		DATA_TRANS_DEBUG_PRINT("[/debugManager/CMUSetMode] attach failed");
	}
    if(!web_func_attach("/debugManager/CMUGetMode", TRANS_NEED, NULL))              //获取CMU运行模式
	{
		DATA_TRANS_DEBUG_PRINT("[/debugManager/CMUGetMode] attach failed");
	}
    if(!web_func_attach("/debugManager/setBatCabinetNum", TRANS_NEED, NULL))        //设置电池仓个数
	{
		DATA_TRANS_DEBUG_PRINT("[/debugManager/setBatCabinetNum] attach failed");
	}
    if(!web_func_attach("/debugManager/getBatCabinetNum", TRANS_NEED, NULL))        //获取电池仓个数
	{
		DATA_TRANS_DEBUG_PRINT("[debugManager/getBatCabinetNum] attach failed");
	}
    if(!web_func_attach("/debugManager/setEnergyCabinetAttr", TRANS_NEED, NULL))     //设置储能柜属性
	{
		DATA_TRANS_DEBUG_PRINT("[/debugManager/setEnergyCabinetAttr] attach failed");
	}
    if(!web_func_attach("/debugManager/getEnergyCabinetAttr", TRANS_NEED, NULL))     //获取储能柜属性
	{
		DATA_TRANS_DEBUG_PRINT("[/debugManager/getEnergyCabinetAttr] attach failed");
	}
    if(!web_func_attach("/debugManager/setBatClusterPackNum", TRANS_NEED, NULL))     //设置电池簇PACK个数
	{
		DATA_TRANS_DEBUG_PRINT("[/debugManager/setBatClusterPackNum] attach failed");
	}
    if(!web_func_attach("/debugManager/getBatClusterPackNum", TRANS_NEED, NULL))     //获取电池簇PACK个数
	{
		DATA_TRANS_DEBUG_PRINT("[/debugManager/getBatClusterPackNum] attach failed");
	}
    if(!web_func_attach("/debugManager/setEnergyCabinetSN", TRANS_NEED, NULL))     //设置储能柜的SN序列号（CMU）
	{
		DATA_TRANS_DEBUG_PRINT("[/debugManager/setEnergyCabinetSN] attach failed");
	}
    if(!web_func_attach("/debugManager/getEnergyCabinetSN", TRANS_NEED, NULL))     //获取储能柜的SN序列号（CMU）
	{
		DATA_TRANS_DEBUG_PRINT("[/debugManager/getEnergyCabinetSN] attach failed");
	}
	if(!web_func_attach("/debugManager/setLowPowerSetting", TRANS_NEED, NULL))     // 设置低功耗参数
    {
        DATA_TRANS_DEBUG_PRINT("[/debugManager/setLowPowerSetting] attach failed");
    }
    if(!web_func_attach("/debugManager/getLowPowerSetting", TRANS_NEED, NULL))     // 获取低功耗设置
    {
      DATA_TRANS_DEBUG_PRINT("[/debugManager/getLowPowerSetting] attach failed");
    }
    if(!web_func_attach("/debugManager/ThermosModeParamGet", TRANS_NEED, NULL))     // 获取保温模式参数
    {
      DATA_TRANS_DEBUG_PRINT("[/debugManager/ThermosModeParamGet] attach failed");
    }
    if(!web_func_attach("/debugManager/ThermosModeParamSet", TRANS_NEED, NULL))     // 设置保温模式参数
    {
      DATA_TRANS_DEBUG_PRINT("[/debugManager/ThermosModeParamSet] attach failed");
    }
    if(!web_func_attach("/debugManager/getExternalEPO", TRANS_NEED, NULL))     // 获取外部EPO类型
    {
      DATA_TRANS_DEBUG_PRINT("[/debugManager/getExternalEPO] attach failed");
    }
    if(!web_func_attach("/debugManager/setExternalEPO", TRANS_NEED, NULL))     // 设置外部EPO类型
    {
      DATA_TRANS_DEBUG_PRINT("[/debugManager/setExternalEPO] attach failed");
    }
}


/**
 * @brief 历史数据接口初始化
 * @return void
 */
static void history_data_func_init(void)
{
    if(!web_func_attach("/getHistoryInfo/getClusterHistoryInfo", TRANS_NEED, NULL))      //获取电池簇历史数据
	{
		DATA_TRANS_DEBUG_PRINT("[/getHistoryInfo/getClusterHistoryInfo] attach failed");
	}
    if(!web_func_attach("/getHistoryInfo/getPackHistoryInfo", TRANS_NEED, NULL))        //获取电池簇内部电池包pack数据
	{
		DATA_TRANS_DEBUG_PRINT("[/getHistoryInfo/getPackHistoryInfo] attach failed");
	}
    if(!web_func_attach("/getHistoryInfo/exportClusterHistoryInfo", TRANS_NEED, NULL))  //导出电池簇历史数据
	{
		DATA_TRANS_DEBUG_PRINT("[/getHistoryInfo/exportClusterHistoryInfo] attach failed");
	}
    if(!web_func_attach("/getHistoryInfo/exportPackHistoryInfo", TRANS_NEED, NULL))      //导出pack历史数据
	{
		DATA_TRANS_DEBUG_PRINT("[/getHistoryInfo/exportPackHistoryInfo] attach failed");
	}
    if(!web_func_attach("/getHistoryInfo/getPowerList", TRANS_NEED, NULL))              //获取PCS历史数据
	{
		DATA_TRANS_DEBUG_PRINT("[/getHistoryInfo/getPowerList] attach failed");
	}
    if(!web_func_attach("/getHistoryInfo/exportPowerList", TRANS_NEED, NULL))           //下载PCS历史数据
	{
		DATA_TRANS_DEBUG_PRINT("[/getHistoryInfo/exportPowerList] attach failed");
	}
    if(!web_func_attach("/getHistoryInfo/getDynamicEnvironmentList", TRANS_NEED, NULL))  //获取动环历史数据
	{
		DATA_TRANS_DEBUG_PRINT("[/getHistoryInfo/getDynamicEnvironmentList] attach failed");
	}
}


/**
 * @brief    设置运行参数
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void sys_run_param_set(struct mg_connection *p_nc,struct http_message *p_msg)
{
    uint8_t uri[128] = {0};
    uint8_t ret = 0;
    uint8_t url[128] = {0};
    cJSON *p_request = NULL;
    cJSON *p_response = NULL;
    char *p = NULL;
    uint8_t response[2048] = {0};
    uint8_t request_body[128] = {0};
    uint8_t cur_user[32] = {0};
    uint8_t cmu_index = 0;

    web_control_info_t *p_web_data = sdk_shm_web_control_data_get();
    memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		DATA_TRANS_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	cmu_index = cJSON_GetObjectItem(p_request,"mcuIndex")->valueint;

    //添加用户
    get_user_from_http_request(p_msg, cur_user);
    cJSON_AddStringToObject(p_request, "userName", cur_user);
    p = cJSON_PrintUnformatted(p_request);
    strcpy(uri, "/paramsInfo/setRunTimeParams");
    sprintf(url, "%s%s%s", "http://", cmu_ip_tbl[cmu_index - 1], uri);
    ret = http_net_post(url, p, response);
    if(ret != 1)
    {
        build_empty_response(response, Accepted, "set runtime parameters failed");
        cJSON_Delete(p_request);
        free(p);
        http_back(p_nc,response);
        return;
    }
    else
    {
        p_response = cJSON_Parse(response);
        if(p_response == NULL)
        {
            DATA_TRANS_DEBUG_PRINT("parse request failed.");
            build_empty_response(response,Accepted,"parse request failed.");
            http_back(p_nc,response);
            cJSON_Delete(p_request);
            free(p);
            return;
        }
        if(cJSON_GetObjectItem(p_response,"code")->valueint != OK)
        {
            http_back(p_nc,response);
            cJSON_Delete(p_request);
            cJSON_Delete(p_response);
            free(p);
            return;
        }
    }
    p_web_data->ems_data.end_charge_soc_max = cJSON_GetObjectItem(p_request,"socUpperLimit")->valueint;
    p_web_data->ems_data.discharge_soc_min = cJSON_GetObjectItem(p_request,"socLowerLimit")->valueint;
    BIT_SET(p_web_data->cabinet_param_update_flag, 7);
    cJSON_Delete(p_request);
    free(p);

    build_empty_response(response, OK, "set runtime parameters successful");
    http_back(p_nc, response);
}

/**
 * @brief 参数配置接口初始化
 * @return void
 */
static void param_conf_func_init(void)
{
    if(!web_func_attach("/paramsInfo/getProtectParams", TRANS_NEED, NULL))      //获取保护参数
	{
		DATA_TRANS_DEBUG_PRINT("[/paramsInfo/getProtectParams] attach failed");
	}
    if(!web_func_attach("/paramsInfo/setProtectParams", TRANS_NEED, NULL))      //设置保护参数
	{
		DATA_TRANS_DEBUG_PRINT("[/paramsInfo/setProtectParams] attach failed");
	}
    if(!web_func_attach("/paramsInfo/getRunTimeParams", TRANS_NEED, NULL))       //获取运行参数
	{
		DATA_TRANS_DEBUG_PRINT("[/paramsInfo/getRunTimeParams] attach failed");
	}
    if(!web_func_attach("/paramsInfo/setRunTimeParams", TRANS_UNNEED, sys_run_param_set))       //设置运行参数
	{
		DATA_TRANS_DEBUG_PRINT("[/paramsInfo/setRunTimeParams] attach failed");
	}
    if(!web_func_attach("/paramsInfo/getRunStorageParams", TRANS_NEED, NULL))     //获取运行存储参数
	{
		DATA_TRANS_DEBUG_PRINT("[/paramsInfo/getRunStorageParams] attach failed");
	}
    if(!web_func_attach("/paramsInfo/setRunStorageParams", TRANS_NEED, NULL))      //设置运行存储参数
	{
		DATA_TRANS_DEBUG_PRINT("[/paramsInfo/setRunStorageParams] attach failed");
	}
}


/**
 * @brief 实时告警信息接口初始化
 * @return void
 */
static void rtwarning_info_func_init(void)
{
    if(!web_func_attach("/realTimeWarning/getRealTimeWarning", TRANS_NEED, NULL))    //获取实时告警信息
	{
		DATA_TRANS_DEBUG_PRINT("[realTimeWarning/getRealTimeWarning] attach failed");
	}
}


/**
 * @brief 概要信息接口初始化
 * @return void
 */
static void summary_info_func_init(void)
{
    if(!web_func_attach("/batteryInfo/getBatteryClusterInfo", TRANS_NEED, NULL))    //获取电池簇信息
	{
		DATA_TRANS_DEBUG_PRINT("[/batteryInfo/getBatteryClusterInfo] attach failed");
	}
    if(!web_func_attach("/batteryInfo/getBatteryDetailInfo", TRANS_NEED, NULL))    //获取电池簇详细信息
	{
		DATA_TRANS_DEBUG_PRINT("[/batteryInfo/getBatteryDetailInfo] attach failed");
	}
    if(!web_func_attach("/PCSInfo/getPCSSimple", TRANS_NEED, NULL))                 //获取PCS模块信息
	{
		DATA_TRANS_DEBUG_PRINT("[/PCSInfo/getPCSSimple] attach failed");
	}
    if(!web_func_attach("/pcsInfo/getPCSDetailede", TRANS_NEED, NULL))              //获取PCS模块详细信息
	{
		DATA_TRANS_DEBUG_PRINT("[/pcsInfo/getPCSDetailede] attach failed");
	}
}



/**
 * @brief 首页接口初始化
 * @return void
 */
static void homepage_func_init(void)
{
    if(!web_func_attach("/homePage/getCMUSystemInfo", TRANS_NEED, NULL))    //获取CMU系统信息
	{
		DATA_TRANS_DEBUG_PRINT("[/homePage/getCMUSystemInfo] attach failed");
	}
    if(!web_func_attach("/homePage/getPCSSystemInfo", TRANS_NEED, NULL))    //获取PCS模块信息
	{
		DATA_TRANS_DEBUG_PRINT("[/homePage/getPCSSystemInfo] attach failed");
	}
    if(!web_func_attach("/homePage/getBatteryInfo", TRANS_NEED, NULL))      //获取电池系统信息
	{
		DATA_TRANS_DEBUG_PRINT("[/homePage/getOperationLog] attach failed");
	}
    if(!web_func_attach("/homePage/getOperationLog", TRANS_NEED, NULL))      //获取操作日志
	{
		DATA_TRANS_DEBUG_PRINT("[/homePage/getOperationLog] attach failed");
	}
    if(!web_func_attach("/homePage/getFaultLog", TRANS_NEED, NULL))         //获取故障日志
	{
		DATA_TRANS_DEBUG_PRINT("[/homePage/getFaultLog] attach failed");
	}
    if(!web_func_attach("/homePage/getDailyChargeDischarge", TRANS_NEED, NULL))      //获取某天充放电量
	{
		DATA_TRANS_DEBUG_PRINT("[/homePage/getDailyChargeDischarge] attach failed");
	}
    if(!web_func_attach("/homePage/getMonthlyChargeDischarge", TRANS_NEED, NULL))    //获取某月充放电量
	{
		DATA_TRANS_DEBUG_PRINT("[/homePage/getMonthlyChargeDischarge] attach failed");
	}
    if(!web_func_attach("/homePage/getYearChargeDischarge", TRANS_NEED, NULL))       //获取某年充放电量
	{
		DATA_TRANS_DEBUG_PRINT("[/homePage/getYearChargeDischarge] attach failed");
	}
    if(!web_func_attach("/homePage/getTotalChargeDischarge", TRANS_NEED, NULL))      //获取总的充放电量
	{
		DATA_TRANS_DEBUG_PRINT("[/homePage/getTotalChargeDischarge] attach failed");
	}
    if(!web_func_attach("/homepage/getDailyPower", TRANS_NEED, NULL))               //获取功率曲线
	{
		DATA_TRANS_DEBUG_PRINT("[/homepage/getDailyPower] attach failed");
	}
    if(!web_func_attach("/homePage/getSystemVersionInfo", TRANS_NEED, NULL))         //获取CMU认证版本信息
	{
		DATA_TRANS_DEBUG_PRINT("[/homePage/getSystemVersionInfo] attach failed");
	}
}



/**
 * @brief 通信接口初始化
 * @return void
 */
static void comm_param_func_init(void)
{
    if(!web_func_attach("/system/getNetworkPara", TRANS_NEED, NULL))          //获取静态IP
	{
		DATA_TRANS_DEBUG_PRINT("[/system/getNetworkPara] attach failed");
	}
    if(!web_func_attach("/system/dynamicNetwork", TRANS_NEED, NULL))          //使能动态IP
	{
		DATA_TRANS_DEBUG_PRINT("[/system/dynamicNetwork] attach failed");
	}
    if(!web_func_attach("/system/staticNetwork", TRANS_NEED, NULL))           //使能静态IP
	{
		DATA_TRANS_DEBUG_PRINT("[/system/staticNetwork] attach failed");
	}

    if(!web_func_attach("/paramsInfo/getComParam", TRANS_NEED, NULL))         //获取485通信参数
	{
		DATA_TRANS_DEBUG_PRINT("[/paramsInfo/getComParam] attach failed");
	} 
    if(!web_func_attach("/paramsInfo/setComParam", TRANS_NEED, NULL))          //设置485通信参数
	{
		DATA_TRANS_DEBUG_PRINT("[/paramsInfo/setComParam] attach failed");
	} 
}


/**
 * @brief 数据转发模块初始化
 * @return void
 */
void web_trans2cmu_module_init(void)
{
    comm_param_func_init();             //通信
    homepage_func_init();               //首页
    summary_info_func_init();           //概要信息
    rtwarning_info_func_init();         //实时告警
    param_conf_func_init();             //参数配置
    history_data_func_init();           //历史数据
    debug_manage_func_init();           //调试信息
    control_cmd_func_init();            //控制
    safety_param_func_init();           //安规参数
}



