#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "common.h"
#include "libghttp.h"
#include "web_data_trans2cmu.h"
#include "libghttp/ghttp.h"
#include "libghttp/ghttp_constants.h"

/**
 * @brief    HTTP获取CMU数据接口
 * @param	 [in] *p_uri url 
 * @param	 [in] *p_params 报文内容
 * @param	 [in] timeout 超时时间参数
 * @param	 [out] *p_resp_body 返回报文
 * @return   0：失败；1：成功
 */
uint8_t http_net_post(uint8_t* p_uri, uint8_t* p_params, uint8_t *p_resp_body) 
{  
    ghttp_request *request = NULL;  
    uint8_t *resp_buf = NULL;
    int resp_len;
    ghttp_status status;  

    request = ghttp_request_new();  
    if(ghttp_set_uri(request, p_uri) == -1)  
    {
        DATA_TRANS_DEBUG_PRINT("ghttp set uri error");
        ghttp_request_destroy(request);
        return 0;
    } 
    if(ghttp_set_type(request, ghttp_type_post) == -1)
    {
        DATA_TRANS_DEBUG_PRINT("ghttp set type error");
        ghttp_request_destroy(request);
        return 0;
    }

    if(p_params == NULL)
    {
        DATA_TRANS_DEBUG_PRINT("params is NULL,error");
        ghttp_request_destroy(request);
        return 0;
    }

    if((strstr(p_uri, "History") != NULL) || (strstr(p_uri, "generateFaultRecorderCMU") != NULL))
    {
        ghttp_set_sock_timeout(request, SOCK_TIMEOUT_30S);
    }
    else
    {
        ghttp_set_sock_timeout(request, SOCK_TIMEOUT_5S);
    }

    ghttp_set_header(request, http_hdr_Content_Type,"application/x-www-form-urlencoded"); 
    ghttp_set_sync(request, ghttp_sync); //set sync  
    ghttp_set_body(request, p_params, strlen(p_params)); //  
    ghttp_prepare(request);  
    status = ghttp_process(request);  
    if(status == ghttp_error)  
    {
        ghttp_request_destroy(request);
        // ghttp_close(request);
        return 0;
    }

    resp_buf = ghttp_get_body(request);
    resp_len = ghttp_get_body_len( request );
    if ( resp_len > 0 )
    {
        memcpy(p_resp_body, resp_buf, resp_len);
    }
    
    ghttp_request_destroy(request);
    // ghttp_close(request);
    return 1;  
} 


/**
 * @brief  生成16位随机字符串
 */
void random_str_generate(uint8_t *p_str)
{
    #define CHAR_MIN1 'a'
    #define CHAR_MAX1 'z' 

    srand(time(NULL));                              //通过时间函数设置随机数种子，使得每次运行结果随机。

    for(uint8_t i = 0; i < 16; i++)
    {
        p_str[i] = rand() % ('Z' - 'a' + 1) + 'a';  //生成要求范围内的随机数。
    }
}


/**
 * @brief    HTTP升级文件传输接口
 * @param	 [in] *p_uri url 
 * @param	 [in] *p_params 报文内容
 * @param	 [out] *p_resp_body 返回报文
 * @return   0：失败；1：成功
 */
uint8_t http_net_update_data_post(uint8_t* p_uri, uint8_t* p_params, uint32_t param_len, uint8_t *p_resp_body, uint8_t *file_name, char *p_cookie_str) 
{  
    uint8_t random_str[17] = {0}; 
    uint8_t content_type[128] = {0}; 
    ghttp_request *request = NULL;  
    uint8_t *resp_buf = NULL;
    ghttp_status status;  
    uint8_t start_str[512] = {0};
    uint8_t end_str[128] = {0};
    uint8_t *update_packet = NULL;

    request = ghttp_request_new();  
    if(ghttp_set_uri(request, p_uri) == -1)  
    {
        DATA_TRANS_DEBUG_PRINT("ghttp set uri error");
        ghttp_request_destroy(request);
        return 0;
    } 
    if(ghttp_set_type(request, ghttp_type_post) == -1)
    {
        DATA_TRANS_DEBUG_PRINT("ghttp set type error");
        ghttp_request_destroy(request);
        return 0;
    }

    if(p_params == NULL)
    {
        DATA_TRANS_DEBUG_PRINT("params is NULL,error");
        ghttp_request_destroy(request);
        return 0;
    }

    ghttp_set_header(request, http_hdr_Accept,"application/json, text/plain, */*"); 
    ghttp_set_header(request, http_hdr_Accept_Encoding,"gzip, deflate"); 
    ghttp_set_header(request, http_hdr_Accept_Language,"zh-CN,zh;q=0.9"); 
    ghttp_set_header(request, http_hdr_Connection,"keep-alive"); 
    if(p_cookie_str != NULL)
    {
        ghttp_set_header(request, http_hdr_Set_Cookie, p_cookie_str); 
    }
    random_str_generate(random_str);
    sprintf(content_type, "%s%s", "multipart/form-data; boundary=----WebKitFormBoundary",random_str);  
    ghttp_set_header(request, http_hdr_Content_Type,content_type); 
    ghttp_set_sync(request, ghttp_sync); 

    update_packet = malloc(param_len + 1024);
    if(update_packet == NULL)
    {
        DATA_TRANS_DEBUG_PRINT("malloc error");
        ghttp_request_destroy(request);
        return 0;
    }

    memset(content_type, 0, 128);
    sprintf(content_type, "%s%s", "Content-Type: application/octet-stream");

    uint8_t content_disposition[128] = {0}; 
    sprintf(content_disposition, "%s%s""\"%s\"""%s""\"%s\"", "Content-Disposition: ","multipart/form-data; name=", "file","; filename=",file_name);

    sprintf(start_str, "%s%s%s%s%s%s%s", "------WebKitFormBoundary",random_str,"\r\n",content_disposition,"\r\n",content_type,"\r\n\r\n");  

    strcpy(update_packet, start_str);
    memcpy(&update_packet[strlen(start_str)], p_params, param_len);

    sprintf(end_str, "%s%s%s%s%s", "\r\n","------WebKitFormBoundary",random_str,"--","\r\n");  

    memcpy(&update_packet[strlen(start_str) + param_len], end_str, strlen(end_str));
    ghttp_set_body(request, update_packet, param_len + strlen(start_str) + strlen(end_str)); //  
    ghttp_prepare(request);  
    status = ghttp_process(request);  
    if(status == ghttp_error)  
    {
        ghttp_request_destroy(request);
        ghttp_close(request);
        free(update_packet);
        return 0;
    }

    resp_buf = ghttp_get_body(request);
    memcpy(p_resp_body, resp_buf, strlen(resp_buf));
    ghttp_request_destroy(request);
    ghttp_close(request);
    free(update_packet);
    return 1;  
} 


/**
 * @brief    HTTP文件下载
 * @param	 [in] *p_uri url 
 * @param	 [in] *p_params 报文内容
 * @param	 [out] *p_file_name 文件名称
 * @return   0：失败；1：成功
 */
uint8_t http_net_file_dowaload(uint8_t *p_uri, uint8_t *p_params, char *p_file_name) 
{  
    ghttp_request *request = NULL;  
    char *p_buf = NULL;
    int file_len = 0;
    ghttp_status status;  
    int32_t ret = 0;
    FILE  *fp = NULL;

    request = ghttp_request_new();  
    if(ghttp_set_type(request, ghttp_type_get) == -1)
    {
        DATA_TRANS_DEBUG_PRINT("ghttp set type error");
        ghttp_request_destroy(request);
        return 0;
    }

    if(ghttp_set_uri(request, p_uri) == -1)  
    {
        DATA_TRANS_DEBUG_PRINT("ghttp set uri error");
        ghttp_request_destroy(request);
        return 0;
    } 

    if(p_params == NULL)
    {
        DATA_TRANS_DEBUG_PRINT("params is NULL,error");
        ghttp_request_destroy(request);
        return 0;
    }

    ghttp_set_header(request, http_hdr_Accept,"application/json, text/plain, */*"); 
    ghttp_set_header(request, http_hdr_Accept_Encoding,"gzip, deflate"); 
    ghttp_set_header(request, http_hdr_Accept_Language,"zh-CN,zh;q=0.9"); 
    ghttp_set_header(request, http_hdr_Connection,"keep-alive"); 
    ghttp_set_sync(request, ghttp_sync); 
    ghttp_set_body(request, p_params, strlen(p_params));
    ghttp_prepare(request);  
    status = ghttp_process(request);  
    if(status == ghttp_error)  
    {
        goto error;
    }
    file_len = ghttp_get_body_len(request);
    p_buf = ghttp_get_body(request);
    fp = fopen(p_file_name, "wb+");
    if(fp == NULL) 
    {
        goto error;
    }
    ret = fwrite(p_buf, 1, file_len, fp);
    if(ret != file_len)
    {
        goto error;
    }
    fclose(fp);
    ghttp_request_destroy(request);
    ghttp_close(request);
    return 1;  

error:
    if(fp != NULL)
    {
        fclose(fp);
    }
    ghttp_request_destroy(request);
    ghttp_close(request);
    return 0;
} 
