#ifndef __WEB_DATA_TRANS2SLAVE_H__
#define __WEB_DATA_TRANS2SLAVE_H__

#include"mongoose.h"
#include "component/sofar_log.h"


/**
 * @brief    根据索引获取从机IP
 * @param	 [in] slave_index 从机序号
 * @param	 [out] *p_ip 从机IP地址
 * @return   1:成功；0：失败
 */
uint8_t get_slave_ip(uint8_t slave_index, char *p_ip);


/**
 * @brief  获取CSU主从机角色
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
csu_role_e csu_role_get(void);


/**
 * @brief    根据URI转发web数据至从机设备
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @param	 [in] *p_uri  请求URI
 * @return
 */
void web_data_trans2slave_by_uri(struct mg_connection *p_nc,struct http_message *p_msg, uint8_t *p_uri);

#endif