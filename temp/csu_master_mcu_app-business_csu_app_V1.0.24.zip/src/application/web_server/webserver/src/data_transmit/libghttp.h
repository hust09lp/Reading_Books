#ifndef LIBGHTTP_H
#define LIBGHTTP_H

#define SOCK_TIMEOUT_30S    30
#define SOCK_TIMEOUT_5S     5

/**
 * @brief    HTTP获取CMU数据接口
 * @param	 [in] *p_uri url 
 * @param	 [in] *p_params 报文内容
 * @param	 [in] timeout 超时时间参数
 * @param	 [out] *p_resp_body 返回报文
 * @return   0：失败；1：成功
 */
uint8_t http_net_post(uint8_t* p_uri, uint8_t* p_params, uint8_t *p_resp_body);

/**
 * @brief    HTTP升级文件传输接口
 * @param	 [in] *p_uri url 
 * @param	 [in] *p_params 报文内容
 * @param	 [out] *p_resp_body 返回报文
 * @return   0：失败；1：成功
 */
uint8_t http_net_update_data_post(uint8_t* p_uri, uint8_t* p_params, uint32_t param_len, uint8_t *p_resp_body, uint8_t *file_name, char *p_cookie_str);

/**
 * @brief    HTTP文件下载
 * @param	 [in] *p_uri url 
 * @param	 [in] *p_params 报文内容
 * @param	 [out] *p_file_name 文件名称
 * @return   0：失败；1：成功
 */
uint8_t http_net_file_dowaload(uint8_t *p_uri, uint8_t *p_params, char *p_file_name);

#endif