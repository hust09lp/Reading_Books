#include "cJSON.h"
#include "common.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "libghttp.h"
#include "app_common.h"
#include "web_data_trans2cmu.h"
#include "web_broker.h"
#include "cmu_data_monitor.h"
#include "libghttp/ghttp.h"
#include "libghttp/ghttp_constants.h"

#define WEB_DATA_BUFF_SIZE  (4 * 1024 * 1024)


/**
 * @brief    主从模式下数据转发
 * @param	 [in] *p_uri url 
 * @param	 [in] *p_params 报文内容
* @param	 [in] *p_cookie cookie内容
 * @param	 [out] *p_resp_body 返回报文
 * @return   0：失败；1：成功
 */
static uint8_t slave_data_post(uint8_t* p_uri, uint8_t* p_params, const char *p_cookie, uint8_t *p_resp_body) 
{  
    ghttp_request *request = NULL;  
    uint8_t *resp_buf = NULL;
    ghttp_status status;  

    request = ghttp_request_new();  
    if(ghttp_set_uri(request, p_uri) == -1)  
    {
        DATA_TRANS_DEBUG_PRINT("ghttp set uri error");
        ghttp_request_destroy(request);
        return 0;
    } 
    if(ghttp_set_type(request, ghttp_type_post) == -1)
    {
        DATA_TRANS_DEBUG_PRINT("ghttp set type error");
        ghttp_request_destroy(request);
        return 0;
    }

    if(p_params == NULL)
    {
        DATA_TRANS_DEBUG_PRINT("params is NULL,error");
        ghttp_request_destroy(request);
        return 0;
    }

    if((strstr(p_uri, "History") != NULL) || (strstr(p_uri, "deviceList") != NULL) || (strstr(p_uri, "generateFaultRecorderCMU") != NULL))
    {
        ghttp_set_sock_timeout(request, SOCK_TIMEOUT_30S);
    }
    else
    {
        ghttp_set_sock_timeout(request, SOCK_TIMEOUT_5S);
    }

    ghttp_set_header(request, http_hdr_Content_Type,"application/x-www-form-urlencoded"); 
    if(p_cookie != NULL)
    {
        ghttp_set_header(request, http_hdr_Set_Cookie, p_cookie);
    }
    ghttp_set_sync(request, ghttp_sync); //set sync  
    ghttp_set_body(request, p_params, strlen(p_params)); //  
    ghttp_prepare(request);  
    status = ghttp_process(request);  
    if(status == ghttp_error)  
    {
        ghttp_request_destroy(request);
        ghttp_close(request);
        return 0;
    }

    resp_buf = ghttp_get_body(request);
    memcpy(p_resp_body, resp_buf, strlen(resp_buf));
    ghttp_request_destroy(request);
    ghttp_close(request);
    return 1;  
} 


/**
 * @brief  获取CSU主从机角色
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
csu_role_e csu_role_get(void)
{
	csu_combine_info_t *p_csu_combine = sdk_shm_csu_combine_data_get();
	if(true == p_csu_combine->comb_setting.comb_enable)
	{
		return p_csu_combine->comb_setting.comb_role;
	}
	else
	{
		return CSU_ROLE_SLAVE;
	}
}


/**
 * @brief    根据索引获取从机IP
 * @param	 [in] slave_index 从机序号
 * @param	 [out] *p_ip 从机IP地址
 * @return   1:成功；0：失败
 */
uint8_t get_slave_ip(uint8_t slave_index, char *p_ip)
{
    int i = 0;
    csu_combine_info_t *p_csu_combine = sdk_shm_csu_combine_data_get();

    for(i = 0; i < sizeof(p_csu_combine->slave_info[slave_index - 1].ip); i++)
    {
        if(p_csu_combine->slave_info[slave_index - 1].ip[i] != 0)
        {
            break;
        }
    }

    if(i == sizeof(p_csu_combine->slave_info[slave_index - 1].ip))
    {
        return 0;
    }

    sprintf(p_ip, "%d.%d.%d.%d", p_csu_combine->slave_info[slave_index - 1].ip[0], 
                                 p_csu_combine->slave_info[slave_index - 1].ip[1], 
                                 p_csu_combine->slave_info[slave_index - 1].ip[2], 
                                 p_csu_combine->slave_info[slave_index - 1].ip[3]);
    return 1;
}



/**
 * @brief    对web数据进行转发
 * @param	 [in] *p_nc 连接信息
 * @param	 [in] *p_uri 目标资源URI
 * @param	 [in] *p_req_body web请求报文
 * @param	 [in] slave_index 从机序号
 * @return   无
 */
static void web_data_trans2slave(struct mg_connection *p_nc, struct http_message *p_msg, uint8_t *p_uri, uint8_t *p_req_body, uint8_t slave_index)
{
    uint8_t ret = 0;
    char slave_ip[16] = {0};
    uint8_t url[1024] = {0};
    uint8_t *p_resp_data = NULL;
    uint8_t *p_response_data = NULL;
    cJSON *p_response = NULL;
    uint8_t *p = NULL;
    uint8_t *q = NULL;
    char *v = NULL;
    int len = 0;
    char cookie[1024] = {0};
    struct mg_str *cookie_str = NULL;
    csu_combine_info_t *p_csu_combine = sdk_shm_csu_combine_data_get();

    //获取cookie
	cookie_str = mg_get_http_header(p_msg, "Cookie");
	if(cookie_str != NULL)
	{
        v = strstr(cookie_str->p, "\r\n");
        len = v - cookie_str->p;
        strncpy(cookie, cookie_str->p, len);
        q = cookie;
	}

    // 打包URL
    p_resp_data = malloc(WEB_DATA_BUFF_SIZE);
    if(p_resp_data == NULL)
    {
        DATA_TRANS_DEBUG_PRINT("malloc error");
        return;
    }
    p_response_data = malloc(WEB_DATA_BUFF_SIZE);
    if(p_response_data == NULL)
    {
        DATA_TRANS_DEBUG_PRINT("malloc error");
        free(p_resp_data);
        return;
    }
    //获取从机IP
    //广播指令
    if(slave_index == 0xFF)
    {
        for(int i = 0; i < CSU_COMB_MAX_SLAVE_CNT; i++)
        {
            if((p_csu_combine->slave_info[i].valid == SF_TRUE) && (p_csu_combine->slave_info[i].online == SF_TRUE))
            {
                memset(slave_ip, 0, sizeof(slave_ip));
                ret = get_slave_ip(i + 1, slave_ip);
                if(!ret)
                {
                    continue;
                }
                sprintf(url, "%s%s%s", "http://", slave_ip, p_uri);
                slave_data_post(url, p_req_body, q, p_resp_data);
            }
        }
        free(p_resp_data);
        free(p_response_data);
        return;
    }
    ret = get_slave_ip(slave_index, slave_ip);
    if(!ret)
    {
        DATA_TRANS_DEBUG_PRINT("get slave ip failed.");
        build_empty_response(p_response_data, Accepted, "get slave ip failed.");
        http_back(p_nc, p_response_data);
        free(p_resp_data);
        free(p_response_data);
        return;
    }
    sprintf(url, "%s%s%s", "http://", slave_ip, p_uri);
    ret = slave_data_post(url, p_req_body, q, p_resp_data);
    if(ret != 1)
    {
        DATA_TRANS_DEBUG_PRINT("get slave data failed.");
        DATA_TRANS_DEBUG_PRINT("resp:%s", p_resp_data);
		build_empty_response(p_response_data, Accepted, "get data error");
		http_back(p_nc, p_response_data);
        free(p_resp_data);
        free(p_response_data);
        return;
    }

	p_response = cJSON_Parse(p_resp_data);
    if(p_response == NULL)
	{
        DATA_TRANS_DEBUG_PRINT("parse response failed.");
		build_empty_response(p_response_data, Accepted, "parse response failed.");
		http_back(p_nc, p_response_data);
        free(p_resp_data);
        free(p_response_data);
		return;
	}

    cJSON_AddNumberToObject(p_response, "slaveIndex", slave_index);

    p = cJSON_PrintUnformatted(p_response);
    strcpy(p_response_data, p);
    cJSON_Delete(p_response);
    free(p);

    http_back(p_nc, p_response_data);
    free(p_resp_data);
    free(p_response_data);
}


/**
 * @brief    根据URI转发web数据至从机设备
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @param	 [in] *p_uri  请求URI
 * @return
 */
void web_data_trans2slave_by_uri(struct mg_connection *p_nc, struct http_message *p_msg, uint8_t *p_uri)
{
    uint8_t ret = 0;
    cJSON *p_request = NULL;
    uint8_t response[2048];                 
    uint8_t request_body[2048] = {0};
    uint8_t slave_index = 0;
    uint8_t *p = NULL;

    memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		DATA_TRANS_DEBUG_PRINT("parse request failed.");
		build_empty_response(response, Accepted, "parse request failed.");
		http_back(p_nc, response);
		return;
	}

    slave_index = cJSON_GetObjectItem(p_request, "slaveIndex")->valueint;
    p = cJSON_PrintUnformatted(p_request);
    web_data_trans2slave(p_nc, p_msg, p_uri, p, slave_index);
    free(p);
    cJSON_Delete(p_request);

}

