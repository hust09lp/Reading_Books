#include "cJSON.h"
#include "common.h"
#include "sdk_shm.h"
#include "data_shm.h"
#include "libghttp.h"
#include "app_common.h"
#include "web_data_trans2cmu.h"
#include "sys_state.h"
#include "web_broker.h"
#include "sys_control.h"
#include "cmu_data_monitor.h"

static uint8_t cmu_ip_tbl[MAX_SLAVE_COUNT][MAX_IP_LEN] = {CMU1_IP, CMU2_IP, CMU3_IP, CMU4_IP, CMU5_IP, CMU6_IP};

/**
 * @brief    CSU远程控制
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
void csu_remote_control(struct mg_connection *p_nc,struct http_message *p_msg)
{
    uint8_t uri[128] = {0};
    uint8_t json_str[512] = {0};
    uint8_t ret = 0;
    uint8_t url[128] = {0};
    cJSON *p_request = NULL;
    cJSON *p_resp_item = NULL;
    cJSON *p_resp_root = NULL;
    uint16_t array_size;
    uint8_t response[2048] = {0};
    cJSON *p_response = NULL;
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t request_body[128] = {0};
    uint8_t cur_user[32] = {0};

    web_control_info_t *p_web_data = sdk_shm_web_control_data_get();
    memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		SYS_CONTROL_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

    //添加用户
    get_user_from_http_request(p_msg,cur_user);

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"remotePowerOnCmd") == 0)
	{
        sprintf(json_str, "{\"action\":\"remotePowerOnCmd\",\"userName\":\"%s\"}", cur_user);
        strcpy(uri, "/controlCmd/remotePowerOnCmd");
        //检查是否具备开机条件
        if(!if_poweron_allow())
        {
            SYS_CONTROL_DEBUG_PRINT("power on is not allowed.");
            build_empty_response(response,201,"汇流柜故障，不允许开机");
            http_back(p_nc,response);
            return;
        }
        BIT_SET(p_web_data->control_cmd_flag, 1);
        p_web_data->control_cmd_data.run_state = 1;
        BIT_SET(p_web_data->csu_comb_web_set_flag, 1);
	}
    else if(strcmp(p_action,"remotePowerOffCmd") == 0)
    {
        strcpy(uri, "/controlCmd/remotePowerOffCmd");
        sprintf(json_str, "{\"action\":\"remotePowerOffCmd\",\"userName\":\"%s\"}", cur_user);
        BIT_SET(p_web_data->control_cmd_flag, 1);
        p_web_data->control_cmd_data.run_state = 0;
        BIT_SET(p_web_data->csu_comb_web_set_flag, 2);
    }
    else if(strcmp(p_action,"faultReset") == 0)
    {
        strcpy(uri, "/controlCmd/faultReset");
        sprintf(json_str, "{\"action\":\"faultReset\",\"userName\":\"%s\"}", cur_user);
        BIT_SET(p_web_data->control_cmd_flag, 0);
        p_web_data->control_cmd_data.reset = 1;
    }
    
    cJSON_Delete(p_request);

    for(uint8_t dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
    {
        if(dev_is_online(dev_num))
        {
            // 打包URL
            sprintf(url, "%s%s%s", "http://", cmu_ip_tbl[dev_num - 1], uri);
            ret = http_net_post(url, json_str, response);
            if(ret != 1)
            {
                continue;
            }
            // SYS_CONTROL_DEBUG_PRINT("%s", response);
            // 解析CMU数据
            p_response = cJSON_Parse(response);
            if(p_response == NULL)
            {
                SYS_CONTROL_DEBUG_PRINT("parse request failed.");
                continue;
            } 

            cJSON_Delete(p_response);
        }
	}

    //打包上传数据
    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        SYS_CONTROL_DEBUG_PRINT("create json obj failed");
        return;
    }
    cJSON_AddNumberToObject(p_resp_root,"code",OK);
    cJSON_AddStringToObject(p_resp_root,"msg","successful");

    p = cJSON_PrintUnformatted(p_resp_root);
    strcpy(response,p);
    cJSON_Delete(p_resp_root);
    free(p);

    http_back(p_nc,response);

}


/**
 * @brief  小桔测试控制
 * @param  [in] *p_nc 连接信息
 * @param  [in] *p_msg  http请求信息
 * @return
 */
static void mqtt_cmd_test(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_item = NULL;
    uint8_t response[64] = {0};  //
    uint8_t *p_action = NULL;
    uint8_t request_body[256] = {0};
    common_data_t *shm = NULL;
	energy_cabinet_param_t *p_param = NULL;

	shm = sdk_shm_get();
	p_param = &shm->mqtt_data.energy_cabinet_param;

    memcpy(request_body,p_msg->body.p,p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		SYS_CONTROL_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}
	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"cmdTest"))
	{
		SYS_CONTROL_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		http_back(p_nc,response);
		cJSON_Delete(p_request);
		return;
	}

    p_param->chargr_cmd = cJSON_GetObjectItem(p_request,"cmd")->valueint;
    p_param->cluster_charge_limit_max_power = cJSON_GetObjectItem(p_request,"chargeLimitPower")->valueint;
    p_param->cluster_discharge_limit_max_power = cJSON_GetObjectItem(p_request,"dischargeLimitPower")->valueint;
    p_param->charge_limit_soc = cJSON_GetObjectItem(p_request,"chargeLimitSoc")->valueint;
    p_param->discharge_limit_soc = cJSON_GetObjectItem(p_request,"dischargeLimitSoc")->valueint;

    SYS_CONTROL_DEBUG_PRINT("chargr_cmd = %d", p_param->chargr_cmd);
    SYS_CONTROL_DEBUG_PRINT("cluster_charge_limit_max_power = %d", p_param->cluster_charge_limit_max_power);
    SYS_CONTROL_DEBUG_PRINT("cluster_discharge_limit_max_power = %d", p_param->cluster_discharge_limit_max_power);
    SYS_CONTROL_DEBUG_PRINT("charge_limit_soc = %d", p_param->charge_limit_soc);
    SYS_CONTROL_DEBUG_PRINT("discharge_limit_soc = %d", p_param->discharge_limit_soc);

    BIT_SET(p_param->param_set_falg, 0);
    BIT_SET(p_param->param_set_falg, 2);
    BIT_SET(p_param->param_set_falg, 3);
    BIT_SET(p_param->param_set_falg, 5);
    BIT_SET(p_param->param_set_falg, 6);

    build_empty_response(response,OK,"set successful");
	http_back(p_nc,response);

    cJSON_Delete(p_request);
}


/**
 * @brief 系统控制模块初始化
 * @return void
 */
void web_sys_control_module_init(void)
{
	if(!web_func_attach("/CSUhomePage/remotePowerOnCmd", TRANS_UNNEED, csu_remote_control))	 		//CSU远程开机
	{
		SYS_CONTROL_DEBUG_PRINT("[/CSUhomePage/remotePowerOnCmd] attach failed");
	}
	if(!web_func_attach("/CSUhomePage/remotePowerOffCmd", TRANS_UNNEED, csu_remote_control))	 	//CSU远程关机
	{
		SYS_CONTROL_DEBUG_PRINT("[/CSUhomePage/remotePowerOffCmd] attach failed");
	}
	if(!web_func_attach("/CSUhomePage/faultReset", TRANS_UNNEED, csu_remote_control))	 	        //CSU故障重启
	{
		SYS_CONTROL_DEBUG_PRINT("[/CSUhomePage/faultReset] attach failed");
	}
    if(!web_func_attach("/mqttTest/cmdTest", TRANS_UNNEED, mqtt_cmd_test))	 	        //小桔测试控制
	{
		SYS_CONTROL_DEBUG_PRINT("[/mqttTest/cmdTest] attach failed");
	}
}


