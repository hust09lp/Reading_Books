#ifndef __SYS_CONTROL_H__
#define __SYS_CONTROL_H__
#include "mongoose.h"
#include "component/sofar_log.h"

#if (1)
#define SYS_CONTROL_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else
#define SYS_CONTROL_DEBUG_PRINT(...) {do {} while(0);}
#endif


/**
 * @brief 系统控制模块初始化
 * @return void
 */
void web_sys_control_module_init(void);


#endif
