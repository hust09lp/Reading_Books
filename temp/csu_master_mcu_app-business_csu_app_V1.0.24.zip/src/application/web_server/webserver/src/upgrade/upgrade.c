#include "cJSON.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "common.h"
#include "sdk/sdk_fs.h"
#include "web_data_trans2cmu.h"
#include "libghttp.h"
#include "app_common.h"
#include "sdk/sdk_public.h"
#include "web_broker.h"
#include "sys_state.h"
#include "cmu_data_monitor.h"
#include "upgrade.h"
#include "operation_log.h"
#include "user_timer.h"
#include "web_data_trans2slave.h"

static uint8_t g_reboot_flag = 0;
static uint8_t init_flag = 0;
static uint8_t g_cur_user[32] = {0};
static user_timer_hd g_upgrade_progress_timer = NULL;

static uint8_t cmu_ip_tbl[MAX_SLAVE_COUNT][MAX_IP_LEN] = {CMU1_IP, CMU2_IP, CMU3_IP, CMU4_IP, CMU5_IP, CMU6_IP};

struct FileInfo{
	FILE  *fp;
    char filePath[128];
    char fileName[128];	
};

/********************************
csu_list:
bit0:mcu1升级标志 bit1:mcu2升级标志

cmu_list:
bit0:mcu1升级标志 bit1:mcu2升级标志
bit2:dspm升级标志 bit3:dspl升级标志

**********************************/
typedef struct
{
    uint8_t sys_upgrade;                    //0：未升级  1：升级 2：升级结束
    uint16_t csu_list;      
    uint16_t cmu_list[MAX_SLAVE_COUNT];
}UPGRADE_LIST_INFO_T;

static UPGRADE_LIST_INFO_T g_upgrade_list_info = {0};

static int32_t sdk_system_cmd(int8_t * cmd)
{
    FILE *fp = NULL;

    if((fp=popen(cmd, "r")) == NULL)
    {
        printf("[%s:%s:%d] %s, cmd:%s\n", __FILE__,__func__, __LINE__, strerror(errno), cmd);
        return -1;
    }
    pclose(fp);

    return 0;
}


/**
* 功  能   : 获取文件长度
* 输  入   : path为文件路径或名称
* 输  出   :
* 返  回   ：文件长度
*/
static uint64_t file_get_size(const int8_t *path)
{
	uint64_t filesize = -1;
	struct stat statbuff;
	if (stat((char *)path, &statbuff) < 0)
	{
		return filesize;
	}
	else
	{
		filesize = statbuff.st_size;
	}
	return filesize;
}

/**
 * @brief    升级文件上传
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] ev  
 * @param	 [in] p_data 数据内容
 * @return
 */
void upgrade_file_upload(struct mg_connection *p_nc, const int ev, void *p_data)
{
    cJSON *p_resp_root = NULL;
	cJSON *p_resp_item = NULL;
    uint8_t response[128];
    uint8_t *p = NULL;
    uint8_t request_body[128] = {0};
	int32_t i;
	firmware_update_t *firmware_update = sdk_shm_update_data_get();

	//用户指针，用于保存文件大小，文件名
    struct FileInfo *userData = NULL;
 
    //当事件ev是 MG_EV_HTTP_MULTIPART_REQUEST 时，data类型是http_message
    struct http_message *httpMsg = NULL;
    if(MG_EV_HTTP_MULTIPART_REQUEST == ev)
    {
        httpMsg = (struct http_message*)p_data;
        //初次请求时，申请内存
        if(userData ==  NULL)
        {
            userData = (struct FileInfo *)malloc(sizeof(struct FileInfo));
            memset(userData, 0, sizeof(struct FileInfo));
        }
    }
    else // 已经不是第一次请求了，p_nc->user_data 先前已经指向 userData，所以可以用了
    {
        userData = (struct FileInfo *)p_nc->user_data;
    }
 
    //当事件ev是 MG_EV_HTTP_PART_BEGIN/MG_EV_HTTP_PART_DATA/MG_EV_HTTP_PART_END 时，data类型是mg_http_multipart_part
    struct mg_http_multipart_part *httpMulMsg = NULL;
    if(ev >= MG_EV_HTTP_PART_BEGIN && ev <= MG_EV_HTTP_PART_END)
    {
        httpMulMsg = (struct mg_http_multipart_part*)p_data;
    }
    
    switch(ev) 
    {
        case MG_EV_HTTP_MULTIPART_REQUEST:
            {   
                ///query_string为请求地址中的变量
                char filePath[32] = {0};
      
                //从请求地址里获取 key 对应的值，所以这个需要和请求地址里的 key 一样
                //这里从地址中获取文件要上传到哪个
                if(mg_get_http_var(&httpMsg->query_string, "filePath", filePath, sizeof(filePath)) > 0) 
                {
                   UPGRADE_DEBUG_PRINT("upload file request, %s = %s\n", "filePath", filePath); 
                }
 
                //保存路径，且 nc->user_data 指向该内存，下次请求就可以直接用了
                if(userData != NULL)
                {
                    snprintf(userData->filePath, sizeof(userData->filePath), "%s", filePath);
                    p_nc->user_data = (void *)userData;                 
                }
            }
 
            break;
        case MG_EV_HTTP_PART_BEGIN:  ///这一步获取文件名
            UPGRADE_DEBUG_PRINT("upload file begin!\n");
            if(httpMulMsg->file_name != NULL && strlen(httpMulMsg->file_name) > 0)
            {
                UPGRADE_DEBUG_PRINT("input fileName = %s\n", httpMulMsg->file_name);
                //保存文件名，且新建一个文件
                if(userData != NULL)
                {
                    //snprintf(userData->fileName, sizeof(userData->fileName), "%s%s", userData->filePath, httpMulMsg->file_name);
                    snprintf(userData->fileName, sizeof(userData->fileName), "%s%s", "/tmp/", httpMulMsg->file_name);
                    userData->fp = fopen(userData->fileName, "wb+");
 
                    //创建文件失败，回复，释放内存
                    if(userData->fp == NULL) 
                    {
                        mg_printf(p_nc, "%s", 
                            "HTTP/1.1 500 file fail\r\n"
                            "Content-Length: 25\r\n"
                            "Connection: close\r\n\r\n"
                            "Failed to open a file\r\n");
 
                        p_nc->flags |= MG_F_SEND_AND_CLOSE;
                        free(userData);
                        p_nc->user_data = NULL;     
                        return;
                    }                    
                }
            }
            break;
        case MG_EV_HTTP_PART_DATA:
            // tracef("upload file chunk size = %lu\n", httpMulMsg->data.len);
            if(userData != NULL && userData->fp != NULL) 
            {
                size_t ret = fwrite(httpMulMsg->data.p, 1, httpMulMsg->data.len, userData->fp);
                if(ret != httpMulMsg->data.len)
                {
                    mg_printf(p_nc, "%s",
                    "HTTP/1.1 500 write fail\r\n"
                    "Content-Length: 29\r\n\r\n"
                    "Failed to write to a file\r\n");
 
                    p_nc->flags |= MG_F_SEND_AND_CLOSE;
                    return;
                }     
            }
            break;
        case MG_EV_HTTP_PART_END:
            UPGRADE_DEBUG_PRINT("file transfer end!\n");
            //设置标志，发送完成数据（如果有）并且关闭连接
            p_nc->flags |= MG_F_SEND_AND_CLOSE;
            //关闭文件，释放内存
            fclose(userData->fp);
            if(userData != NULL && userData->fp != NULL)
            {
                if(strstr(httpMulMsg->file_name,".sofar") && strstr(httpMulMsg->file_name,"ESS3M44"))  //属于工商业储能的升级包
                {
                    for (i = 0; i < UPDATE_OBJECT_NUM; ++i)
                    {
                        firmware_update->chip_role[i] = 0;
                        firmware_update->module_percent[i] = 0;
                    }
                    snprintf(firmware_update->package_name, 52, "%s", httpMulMsg->file_name);
			        snprintf(firmware_update->root_path , 32, "%s", "/tmp/");
                    build_empty_response(response,OK,"文件上传成功");
                    http_back(p_nc,response);
                }
                else
                {
                    build_empty_response(response,600,"文件名称错误");
                    http_back(p_nc,response);
                }
            }
            UPGRADE_DEBUG_PRINT("upload file end, free userData(%p)\n", userData);
            free(userData);
            p_nc->user_data = NULL;             
            break;
        case MG_EV_HTTP_MULTIPART_REQUEST_END:
            UPGRADE_DEBUG_PRINT("http multipart request end!\n");
            break;
        default:
            break;

    	}
}


/**
 * @brief    安规文件转发至在线CMU设备
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static uint8_t safety_file_trans2cmu(struct mg_connection *p_nc, char *p_cookie_str)
{
    uint8_t ret = 0;
    uint8_t url[128] = {0};
    uint8_t resp_data[1024] = {0}; 
    uint8_t response[512] = {0};
    int8_t path[128] = {0};
    uint32_t file_length = 0;
    uint8_t *update_data = NULL;
    FILE *fp = NULL;

    firmware_update_t *firmware_update = sdk_shm_update_data_get();

    snprintf((char *)path, sizeof(path) - 1, "%s%s", "/tmp/", firmware_update->module_name[0]);
    file_length = file_get_size(path);
    UPGRADE_DEBUG_PRINT("\n p_update->root_path: %s,path=%s,package_name=%s,szie=%llu\n", "/tmp/",path,firmware_update->module_name[0],file_length);
    
    
    update_data = (uint8_t *)malloc(file_length + 1);
    if(update_data == NULL)
    {
        UPGRADE_DEBUG_PRINT("malloc error");
        return 0;
    }

    if ((fp = fopen((char *)path, "rb")) == NULL)
    {
        UPGRADE_DEBUG_PRINT("file open error");
        free(update_data);
        return 0;
    }
    
    uint32_t read_size = fread(update_data, 1, file_length, fp);
    if (read_size != file_length) 
    {
        UPGRADE_DEBUG_PRINT("file read error,read_size=%d", read_size);
        fclose(fp);
        free(update_data);
        return 0;
    }
    UPGRADE_DEBUG_PRINT("read_size=%d", read_size);

	for(uint8_t dev_num = 1; dev_num < MAX_SLAVE_COUNT + 1; dev_num++)
    {
        if(dev_is_online(dev_num))
        {
            sprintf(url, "%s%s%s", "http://", cmu_ip_tbl[dev_num - 1], "/SafetUpload");
    		UPGRADE_DEBUG_PRINT("url:%s", url);
			ret = http_net_update_data_post(url, update_data, read_size, resp_data,firmware_update->module_name[0], p_cookie_str);
			if(ret != 1)
			{
				UPGRADE_DEBUG_PRINT("safety file trans error.");
                fclose(fp);
                free(update_data);
				return 0;
			}
			else
			{
				UPGRADE_DEBUG_PRINT("resp:%s", resp_data);
			}
        }
    }

    fclose(fp);
    free(update_data);

    return 1;
}


/**
 * @brief    安规文件转发至在线从机设备
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static uint8_t safety_file_trans2slave(struct mg_connection *p_nc, char *p_cookie_str)
{
    uint8_t ret = 0;
    uint8_t url[128] = {0};
    uint8_t resp_data[1024] = {0}; 
    uint8_t response[512] = {0};
    int8_t path[128] = {0};
    char slave_ip[16] = {0};
    uint32_t file_length = 0;
    uint8_t *update_data = NULL;
    FILE *fp = NULL;
    int i = 0;

    csu_combine_info_t *p_csu_combine = sdk_shm_csu_combine_data_get();
    firmware_update_t *firmware_update = sdk_shm_update_data_get();

    snprintf((char *)path, sizeof(path) - 1, "%s%s", "/tmp/", firmware_update->module_name[0]);
    file_length = file_get_size(path);
    UPGRADE_DEBUG_PRINT("\n p_update->root_path: %s,path=%s,package_name=%s,szie=%llu\n", "/tmp/",path,firmware_update->module_name[0],file_length);
    
    
    update_data = (uint8_t *)malloc(file_length + 1);
    if(update_data == NULL)
    {
        UPGRADE_DEBUG_PRINT("malloc error");
        return 0;
    }

    if ((fp = fopen((char *)path, "rb")) == NULL)
    {
        UPGRADE_DEBUG_PRINT("file open error");
        free(update_data);
        return 0;
    }
    
    uint32_t read_size = fread(update_data, 1, file_length, fp);
    if (read_size != file_length) 
    {
        UPGRADE_DEBUG_PRINT("file read error,read_size=%d", read_size);
        fclose(fp);
        free(update_data);
        return 0;
    }
    UPGRADE_DEBUG_PRINT("read_size=%d", read_size);

    for(int i = 0; i < CSU_COMB_MAX_SLAVE_CNT; i++)
    {
        if((p_csu_combine->slave_info[i].valid == SF_TRUE) && (p_csu_combine->slave_info[i].online == SF_TRUE))
        {
            memset(slave_ip, 0, sizeof(slave_ip));
            ret = get_slave_ip(i + 1, slave_ip);
            if(!ret)
            {
                continue;
            }
            sprintf(url, "%s%s%s", "http://", slave_ip, "/SafetUpload");
			ret = http_net_update_data_post(url, update_data, read_size, resp_data,firmware_update->module_name[0], p_cookie_str);
			if(ret != 1)
			{
				UPGRADE_DEBUG_PRINT("safety file trans error.");
                fclose(fp);
                free(update_data);
				return 0;
			}
			else
			{
				UPGRADE_DEBUG_PRINT("resp:%s", resp_data);
			}
        }
    }

    fclose(fp);
    free(update_data);

    return 1;
}


/**
 * @brief    升级文件上传
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] ev  
 * @param	 [in] p_data 数据内容
 * @return
 */
void safety_file_upload(struct mg_connection *p_nc, const int ev, void *p_data)
{
    cJSON *p_resp_root = NULL;
	cJSON *p_resp_item = NULL;
    uint8_t response[128];
    uint8_t *p = NULL;
    uint8_t request_body[128] = {0};
	uint8_t safety_path[128] = {0};
	// safety_attr_t safety_attr;
	int32_t ret;
    static char cookie[256] = {0};
    struct mg_str *cookie_str = NULL;
	firmware_update_t *firmware_update = sdk_shm_update_data_get();

	//用户指针，用于保存文件大小，文件名
    struct FileInfo *userData = NULL;
 
    //当事件ev是 MG_EV_HTTP_MULTIPART_REQUEST 时，data类型是http_message
    struct http_message *httpMsg = NULL;
    if(MG_EV_HTTP_MULTIPART_REQUEST == ev)
    {
        httpMsg = (struct http_message*)p_data;
        //初次请求时，申请内存
        if(userData ==  NULL)
        {
            userData = (struct FileInfo *)malloc(sizeof(struct FileInfo));
            memset(userData, 0, sizeof(struct FileInfo));
        }
        cookie_str = mg_get_http_header(httpMsg, "Cookie");
        memset(cookie, 0, sizeof(cookie));
        //因为包含其他协议头数据，这里逐个字符添加
        for(uint8_t i = 0; i < sizeof(cookie); i++)
        {
            if(cookie_str->p[i] != '\n')
            {
                cookie[i] = cookie_str->p[i];
            }
            else
            {
                break;
            }
        }
    }
    else // 已经不是第一次请求了，p_nc->user_data 先前已经指向 userData，所以可以用了
    {
        userData = (struct FileInfo *)p_nc->user_data;
    }
 
    //当事件ev是 MG_EV_HTTP_PART_BEGIN/MG_EV_HTTP_PART_DATA/MG_EV_HTTP_PART_END 时，data类型是mg_http_multipart_part
    struct mg_http_multipart_part *httpMulMsg = NULL;
    if(ev >= MG_EV_HTTP_PART_BEGIN && ev <= MG_EV_HTTP_PART_END)
    {
        httpMulMsg = (struct mg_http_multipart_part*)p_data;
    }
 
    switch(ev) 
    {
        case MG_EV_HTTP_MULTIPART_REQUEST:
            {   
                ///query_string为请求地址中的变量
                char filePath[32] = {0};
      
                //从请求地址里获取 key 对应的值，所以这个需要和请求地址里的 key 一样
                //这里从地址中获取文件要上传到哪个
                if(mg_get_http_var(&httpMsg->query_string, "filePath", filePath, sizeof(filePath)) > 0) 
                {
                   UPGRADE_DEBUG_PRINT("upload file request, %s = %s\n", "filePath", filePath); 
                }
 
                //保存路径，且 p_nc->user_data 指向该内存，下次请求就可以直接用了
                if(userData != NULL)
                {
                    snprintf(userData->filePath, sizeof(userData->filePath), "%s", filePath);
                    p_nc->user_data = (void *)userData;                 
                }
            }
 
            break;
        case MG_EV_HTTP_PART_BEGIN:  ///这一步获取文件名
            UPGRADE_DEBUG_PRINT("upload file begin!\n");
            if(httpMulMsg->file_name != NULL && strlen(httpMulMsg->file_name) > 0)
            {
                UPGRADE_DEBUG_PRINT("input fileName = %s\n", httpMulMsg->file_name);
                //保存文件名，且新建一个文件
                if(userData != NULL)
                {
                    //snprintf(userData->fileName, sizeof(userData->fileName), "%s%s", userData->filePath, httpMulMsg->file_name);
                    snprintf(userData->fileName, sizeof(userData->fileName), "%s%s", "/tmp/", httpMulMsg->file_name);
                    userData->fp = fopen(userData->fileName, "wb+");
 
                    //创建文件失败，回复，释放内存
                    if(userData->fp == NULL) 
                    {
                        mg_printf(p_nc, "%s", 
                            "HTTP/1.1 500 file fail\r\n"
                            "Content-Length: 25\r\n"
                            "Connection: close\r\n\r\n"
                            "Failed to open a file\r\n");
 
                        p_nc->flags |= MG_F_SEND_AND_CLOSE;
                        free(userData);
                        p_nc->user_data = NULL;     
                        return;
                    }                    
                }
 
            }
            break;
        case MG_EV_HTTP_PART_DATA:
            // tracef("upload file chunk size = %lu\n", httpMulMsg->data.len);
            if(userData != NULL && userData->fp != NULL) 
            {
                size_t ret = fwrite(httpMulMsg->data.p, 1, httpMulMsg->data.len, userData->fp);
                if(ret != httpMulMsg->data.len)
                {
                    mg_printf(p_nc, "%s",
                    "HTTP/1.1 500 write fail\r\n"
                    "Content-Length: 29\r\n\r\n"
                    "Failed to write to a file\r\n");
 
                    p_nc->flags |= MG_F_SEND_AND_CLOSE;
                    return;
                }     
            }
            break;
        case MG_EV_HTTP_PART_END:
            UPGRADE_DEBUG_PRINT("file transfer end!\n");
			snprintf(firmware_update->module_name[0], 52, "%s", httpMulMsg->file_name);
            if(userData != NULL && userData->fp != NULL)
            {
            	if(userData->fp)
				{
					fclose(userData->fp);
					userData->fp = NULL;
				}
				
				p_resp_root = cJSON_CreateObject();
				if(p_resp_root != NULL)
				{
		            cJSON_AddNumberToObject(p_resp_root,"code",OK);
                    cJSON_AddStringToObject(p_resp_root,"msg","upload Safety successful");
                    p = cJSON_PrintUnformatted(p_resp_root);

					http_back(p_nc,p);
					cJSON_Delete(p_resp_root);
					free(p);
				}
                //设置标志，发送完成数据（如果有）并且关闭连接
                p_nc->flags |= MG_F_SEND_AND_CLOSE;
                
                //关闭文件，释放内存
                if(userData->fp)
                 fclose(userData->fp);
                UPGRADE_DEBUG_PRINT("upload file end, free userData(%p)\n", userData);
                free(userData);
                p_nc->user_data = NULL;       
            }           
            break;
        case MG_EV_HTTP_MULTIPART_REQUEST_END:
            UPGRADE_DEBUG_PRINT("http multipart request end!\n");
			safety_file_trans2cmu(p_nc, cookie);
            //主从机模式下，需要对从机进行广播转发
            if(CSU_ROLE_MASTER == csu_role_get())
            {
                safety_file_trans2slave(p_nc, cookie);
            }
            break;
        default:
            break;

    	}
}


/**
 * @brief    是否处于升级状态
 * @return   true：升级 false：未升级
 */
bool if_dev_in_upgrade_status(void)
{
    if(g_upgrade_list_info.sys_upgrade == 1)
    {
        return true;
    }
    return false;
}


/**
 * @brief    升级是否结束
 * @return   true：升级结束 false：未结束
 */
static bool if_dev_upgrade_done(void)
{
    uint8_t i = 0, j = 0;
    firmware_update_t *firmware_update = sdk_shm_update_data_get();

    if((firmware_update->state == UPDATE) || (firmware_update->state == UPDATING))
    {
        return false;
    }

    //判断是否存在CSU子模块升级
    if(g_upgrade_list_info.csu_list != 0)
    {
        //CSU-MCU1
        if(BIT_GET(g_upgrade_list_info.csu_list, 0))
        {
            for (i = 0; i < UPDATE_OBJECT_NUM; ++i)
            {
                if (firmware_update->chip_role[i] == CSU_MCU1_NUM)
                {
                    if(firmware_update->update_flag[i] == UPDATE_ING)
                    {
                        return false;
                    }
                }
            }	
        }

        //CSU-MCU2
        if(BIT_GET(g_upgrade_list_info.csu_list, 1))
        {
            for (i = 0; i < UPDATE_OBJECT_NUM; ++i)
            {
                if (firmware_update->chip_role[i] == CSU_MCU2_NUM)
                {
                    if(firmware_update->update_flag[i] == UPDATE_ING)
                    {
                        return false;
                    }
                }
            }	
        }
    }

    for(i = 0; i < MAX_SLAVE_COUNT; i++)
    {
        //判断是否存在CMU子模块升级
        if(g_upgrade_list_info.cmu_list[i] != 0)
        {
            //CMU-MCU1
            if(BIT_GET(g_upgrade_list_info.cmu_list[i], 0))
            {
                for (j = 0; j < UPDATE_OBJECT_NUM; ++j)
                {
                    if (firmware_update->chip_role[j] == CMU_MCU1_NUM)
                    {
                        if(firmware_update->dev_cmu_update[i].update_flag[j] == UPDATE_ING)
                        {
                            return false;
                        }
                    }
                }	
            }

            //CMU-MCU2
            if(BIT_GET(g_upgrade_list_info.cmu_list[i], 1))
            {
                for (j = 0; j < UPDATE_OBJECT_NUM; ++j)
                {
                    if (firmware_update->chip_role[j] == CMU_MCU2_NUM)
                    {
                        if(firmware_update->dev_cmu_update[i].update_flag[j] == UPDATE_ING)
                        {
                            return false;
                        }
                    }
                }	
            }

            //DSP-M
            if(BIT_GET(g_upgrade_list_info.cmu_list[i], 2))
            {
                for (j = 0; j < UPDATE_OBJECT_NUM; ++j)
                {
                    if (firmware_update->chip_role[j] == PCS_M_NUM)
                    {
                        if(firmware_update->dev_cmu_update[i].update_flag[j] == UPDATE_ING)
                        {
                            return false;
                        }
                    }
                }	
            }

            //DSP-L
            if(BIT_GET(g_upgrade_list_info.cmu_list[i], 3))
            {
                for (j = 0; j < UPDATE_OBJECT_NUM; ++j)
                {
                    if (firmware_update->chip_role[j] == PCS_S_NUM)
                    {
                        if(firmware_update->dev_cmu_update[i].update_flag[j] == UPDATE_ING)
                        {
                            return false;
                        }
                    }
                }	
            }
        }
    }
    return true;
}


/**
 * @brief    是否需要重启
 * @return   true：升级结束 false：未结束
 */
static bool if_sys_need_reboot(void)
{
    firmware_update_t *firmware_update = sdk_shm_update_data_get();


    //判断是否存在CSU子模块升级
    if(g_upgrade_list_info.csu_list != 0)
    {
        //CSU-MCU1
        if(BIT_GET(g_upgrade_list_info.csu_list, 0))
        {
            return true;
        }
    }

    return false;
}



/**
 * @brief    升级日志记录
 * @return
 */
static void upgrade_log(uint8_t *user_name)
{
    operation_log_t op_log = {0};
    firmware_update_t *firmware_update = sdk_shm_update_data_get();

    init_user_basic_info(&op_log);
	strcpy(op_log.user_name, user_name);
	get_user_basic_info(&op_log);
    strcpy(op_log.op_type,"本地升级");
    if(firmware_update->result == 0)
    {
        strcpy(op_log.op_status,"success");
    }
    else
    {
        strcpy(op_log.op_status,"failed");
    }
    add_one_op_log(&op_log);
}


/**
 * @brief    CSU升级进度查询
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void get_upgrade_progress(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_root = NULL;
	cJSON *p_progress_array = NULL;
    uint8_t response[1024] = {0};
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t request_body[128] = {0};
    uint8_t tmp_str[32] = {0};
    int32_t i = 0;
	int32_t j = 0;
	int32_t total_percent = 0;
	int32_t num = 0;
    uint8_t result = 0;
    static uint8_t inited = 0;
	firmware_update_t *firmware_update = sdk_shm_update_data_get();

    memcpy(request_body, p_msg->body.p, p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		UPGRADE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request,"action")->valuestring;
	if(strcmp(p_action,"getUpgradeProgress"))
	{
		UPGRADE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		cJSON_Delete(p_request);
		http_back(p_nc,response);
		return;
	}
    cJSON_Delete(p_request);

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		UPGRADE_DEBUG_PRINT("create json object failed");
        build_empty_response(response, Accepted, "error");
        return;
	}

    //判断系统是否是升级状态
    if(g_upgrade_list_info.sys_upgrade == 0)
    {
        cJSON_AddNumberToObject(p_resp_root, "code", OK);
        cJSON_AddNumberToObject(p_resp_root, "UpgradeStatus", 0);
        p = cJSON_PrintUnformatted(p_resp_root);
        http_back(p_nc, p);
        cJSON_Delete(p_resp_root);
        free(p);
        return;
    }

    p_progress_array = cJSON_CreateArray();

    //判断是否存在CSU子模块升级
    if(g_upgrade_list_info.csu_list != 0)
    {
        //CSU-MCU1
        if(BIT_GET(g_upgrade_list_info.csu_list, 0))
        {
            cJSON *p_csu_cmu1_item = cJSON_CreateObject();
            total_percent = 0;
            num = 0;
            result = 0;
            for (i = 0; i < UPDATE_OBJECT_NUM; ++i)
            {
                if (firmware_update->chip_role[i] == CSU_MCU1_NUM)
                {
                    UPGRADE_DEBUG_PRINT("module_percent[%d] %d", i, firmware_update->module_percent[i]);
                    total_percent += firmware_update->module_percent[i];
                    num++;
                    result = firmware_update->update_flag[i];
                }
            }	
            cJSON_AddStringToObject(p_csu_cmu1_item, "dev", "csu-mcu1");
            if(num)
            {
                cJSON_AddNumberToObject(p_csu_cmu1_item, "Progress", (total_percent / num));
                cJSON_AddNumberToObject(p_csu_cmu1_item, "Status", result);
            }
            else
            {
                cJSON_AddNumberToObject(p_csu_cmu1_item, "Progress", 0);
                cJSON_AddNumberToObject(p_csu_cmu1_item, "Status", 1);
            }
            cJSON_AddItemToArray(p_progress_array, p_csu_cmu1_item);
        }

        //CSU-MCU2
        if(BIT_GET(g_upgrade_list_info.csu_list, 1))
        {
            cJSON *p_csu_cmu2_item = cJSON_CreateObject();
            total_percent = 0;
            num = 0;
            result = 0;
            for (i = 0; i < UPDATE_OBJECT_NUM; ++i)
            {
                if (firmware_update->chip_role[i] == CSU_MCU2_NUM)
                {
                    UPGRADE_DEBUG_PRINT("module_percent[%d] %d", i, firmware_update->module_percent[i]);
                    total_percent += firmware_update->module_percent[i];
                    num++;
                    result = firmware_update->update_flag[i];
                }
            }	
            cJSON_AddStringToObject(p_csu_cmu2_item, "dev", "csu-mcu2");
            if(num)
            {
                cJSON_AddNumberToObject(p_csu_cmu2_item, "Progress", (total_percent / num));
                cJSON_AddNumberToObject(p_csu_cmu2_item, "Status", result);
            }
            else
            {
                cJSON_AddNumberToObject(p_csu_cmu2_item, "Progress", 0);
                cJSON_AddNumberToObject(p_csu_cmu2_item, "Status", 1);
            }
            cJSON_AddItemToArray(p_progress_array, p_csu_cmu2_item);
        }
    }

    for(i = 0; i < MAX_SLAVE_COUNT; i++)
    {
        //判断是否存在CMU子模块升级
        if(g_upgrade_list_info.cmu_list[i] != 0)
        {
            //CMU-MCU1
            if(BIT_GET(g_upgrade_list_info.cmu_list[i], 0))
            {
                cJSON *p_cmu_cmu1_item = cJSON_CreateObject();
                total_percent = 0;
                num = 0;
                result = 0;
                for (j = 0; j < UPDATE_OBJECT_NUM; ++j)
                {
                    if (firmware_update->chip_role[j] == CMU_MCU1_NUM)
                    {
                        UPGRADE_DEBUG_PRINT("module_percent[%d] %d", j, firmware_update->dev_cmu_update[i].module_percent[j]);
                        total_percent += firmware_update->dev_cmu_update[i].module_percent[j];
                        num++;
                        result = firmware_update->dev_cmu_update[i].update_flag[j];
                    }
                }	
                memset(tmp_str, 0, sizeof(tmp_str));
                sprintf(tmp_str, "cmu%d-mcu1", i + 1);
                cJSON_AddStringToObject(p_cmu_cmu1_item, "dev", tmp_str);
                if(num)
                {
                    cJSON_AddNumberToObject(p_cmu_cmu1_item, "Progress", (total_percent / num));
                    cJSON_AddNumberToObject(p_cmu_cmu1_item, "Status", result);
                }
                else
                {
                    cJSON_AddNumberToObject(p_cmu_cmu1_item, "Progress", 0);
                    cJSON_AddNumberToObject(p_cmu_cmu1_item, "Status", 1);
                }
                cJSON_AddItemToArray(p_progress_array, p_cmu_cmu1_item);
            }

            //CMU-MCU2
            if(BIT_GET(g_upgrade_list_info.cmu_list[i], 1))
            {
                cJSON *p_cmu_cmu2_item = cJSON_CreateObject();
                total_percent = 0;
                num = 0;
                result = 0;
                for (j = 0; j < UPDATE_OBJECT_NUM; ++j)
                {
                    if (firmware_update->chip_role[j] == CMU_MCU2_NUM)
                    {
                        UPGRADE_DEBUG_PRINT("module_percent[%d] %d", j, firmware_update->dev_cmu_update[i].module_percent[j]);
                        total_percent += firmware_update->dev_cmu_update[i].module_percent[j];
                        num++;
                        result = firmware_update->dev_cmu_update[i].update_flag[j];
                    }
                }	
                memset(tmp_str, 0, sizeof(tmp_str));
                sprintf(tmp_str, "cmu%d-mcu2", i + 1);
                cJSON_AddStringToObject(p_cmu_cmu2_item, "dev", tmp_str);
                if(num)
                {
                    cJSON_AddNumberToObject(p_cmu_cmu2_item, "Progress", (total_percent/num));
                    cJSON_AddNumberToObject(p_cmu_cmu2_item, "Status", result);
                }
                else
                {
                    cJSON_AddNumberToObject(p_cmu_cmu2_item, "Progress", 0);
                    cJSON_AddNumberToObject(p_cmu_cmu2_item, "Status", 1);
                }
                cJSON_AddItemToArray(p_progress_array, p_cmu_cmu2_item);
            }

            //DSP-M
            if(BIT_GET(g_upgrade_list_info.cmu_list[i], 2))
            {
                cJSON *p_pcsm_item = cJSON_CreateObject();
                total_percent = 0;
                num = 0;
                result = 0;
                for (j = 0; j < UPDATE_OBJECT_NUM; ++j)
                {
                    if (firmware_update->chip_role[j] == PCS_M_NUM)
                    {
                        UPGRADE_DEBUG_PRINT("module_percent[%d] %d", j, firmware_update->dev_cmu_update[i].module_percent[j]);
                        total_percent += firmware_update->dev_cmu_update[i].module_percent[j];
                        num++;
                        result = firmware_update->dev_cmu_update[i].update_flag[j];
                    }
                }	
                memset(tmp_str, 0, sizeof(tmp_str));
                sprintf(tmp_str, "pcs%d-dspm", i + 1);
                cJSON_AddStringToObject(p_pcsm_item, "dev", tmp_str);
                if(num)
                {
                    cJSON_AddNumberToObject(p_pcsm_item, "Progress", (total_percent/num));
                    cJSON_AddNumberToObject(p_pcsm_item, "Status", result);
                }
                else
                {
                    cJSON_AddNumberToObject(p_pcsm_item, "Progress", 0);
                    cJSON_AddNumberToObject(p_pcsm_item, "Status", 1);
                }
                cJSON_AddItemToArray(p_progress_array, p_pcsm_item);
            }

            //DSP-L
            if(BIT_GET(g_upgrade_list_info.cmu_list[i], 3))
            {
                cJSON *p_pcsl_item = cJSON_CreateObject();
                total_percent = 0;
                num = 0;
                result = 0;
                for (j = 0; j < UPDATE_OBJECT_NUM; ++j)
                {
                    if (firmware_update->chip_role[j] == PCS_S_NUM)
                    {
                        UPGRADE_DEBUG_PRINT("module_percent[%d] %d", j, firmware_update->dev_cmu_update[i].module_percent[j]);
                        total_percent += firmware_update->dev_cmu_update[i].module_percent[j];
                        num++;
                        result = firmware_update->dev_cmu_update[i].update_flag[j];
                    }
                }	
                memset(tmp_str, 0, sizeof(tmp_str));
                sprintf(tmp_str, "pcs%d-dsps", i + 1);
                cJSON_AddStringToObject(p_pcsl_item, "dev", tmp_str);
                if(num)
                {
                    cJSON_AddNumberToObject(p_pcsl_item, "Progress", (total_percent/num));
                    cJSON_AddNumberToObject(p_pcsl_item, "Status", result);
                }
                else
                {
                    cJSON_AddNumberToObject(p_pcsl_item, "Progress", 0);
                    cJSON_AddNumberToObject(p_pcsl_item, "Status", 1);
                }
                cJSON_AddItemToArray(p_progress_array, p_pcsl_item);
            }
        }
    }

    cJSON_AddNumberToObject(p_resp_root, "code", OK);
    cJSON_AddNumberToObject(p_resp_root, "UpgradeStatus", g_upgrade_list_info.sys_upgrade);
    cJSON_AddItemToObject(p_resp_root, "ProgressInfo", p_progress_array);
	cJSON_AddStringToObject(p_resp_root,"msg","get upgrade progress successful/");
    p = cJSON_PrintUnformatted(p_resp_root);
    http_back(p_nc, p);
    cJSON_Delete(p_resp_root);
    free(p);

    return;
}


/**
 * @brief    CSU设置升级列表
 * @param	 [in] *p_list_data：升级列表数据 
 * @return   -1：失败 0：成功
 */
static int32_t upgrade_csu_dev_list_set(uint8_t *p_list_data)
{
    cJSON *p_request = NULL;
    cJSON *p_list_info = NULL;
    cJSON *p_csu_item = NULL;
    int array_size = 0;
    uint8_t mcu1 = 0;
	uint8_t mcu2 = 0;

    firmware_update_t *firmware_update = sdk_shm_update_data_get();

    p_request = cJSON_Parse(p_list_data);
    p_list_info = cJSON_GetObjectItem(p_request, "ListInfo");
	p_csu_item = cJSON_GetObjectItem(p_list_info, "csu");
    array_size = cJSON_GetArraySize(p_csu_item);
    if(array_size > 0)
    {
        for(uint8_t i = 0; i < array_size; i++)
        {
            if(strcmp((cJSON_GetArrayItem(p_csu_item, i)->valuestring),"csu-mcu1") == 0)
            {
                mcu1 = 1;
            }
            if(strcmp((cJSON_GetArrayItem(p_csu_item, i)->valuestring),"csu-mcu2") == 0)
            {
                mcu2 = 1;
            }
        }
    }
    cJSON_Delete(p_request);

    firmware_update->module_update_flag = 0;
	if (mcu1)
	{
        BIT_SET(firmware_update->module_update_flag, 0);
        BIT_SET(g_upgrade_list_info.csu_list, 0);
	}
    else
	{
        BIT_CLR(firmware_update->module_update_flag, 0);
        BIT_CLR(g_upgrade_list_info.csu_list, 0);
	}
	
	if (mcu2)
	{
        BIT_SET(firmware_update->module_update_flag, 1);
        BIT_SET(g_upgrade_list_info.csu_list, 1);
	}
    else
	{
        BIT_CLR(firmware_update->module_update_flag, 1);
        BIT_CLR(g_upgrade_list_info.csu_list, 1);
	}

	if (mcu1 || mcu2)
	{
		firmware_update->state = 2;
	}
    return 0;
}


/**
 * @brief    cmu升级包传输
 * @param	 [in] dev_num  cmu编号
 * @return
 */
static uint8_t upgrade_file_trans(uint8_t dev_num)
{
    uint8_t ret = 0;
    uint8_t url[128] = {0};
    uint8_t resp_data[1024] = {0}; 
    uint8_t response[512] = {0};
    int8_t path[128] = {0};
    uint32_t file_length = 0;
    uint8_t *update_data = NULL;
    FILE *fp = NULL;

    firmware_update_t *firmware_update = sdk_shm_update_data_get();

    snprintf((char *)path, sizeof(path) - 1, "%s%s", "/tmp/", firmware_update->package_name);
    file_length = file_get_size(path);
    UPGRADE_DEBUG_PRINT("\n p_update->root_path: %s,path=%s,package_name=%s,szie=%llu\n", "/tmp/",path,firmware_update->package_name,file_length);
    
    
    update_data = (uint8_t *)malloc(file_length + 1);
    if(update_data == NULL)
    {
        UPGRADE_DEBUG_PRINT("malloc error");
        return 0;
    }

    if ((fp = fopen((char *)path, "rb")) == NULL)
    {
        UPGRADE_DEBUG_PRINT("file open error");
        free(update_data);
        return 0;
    }
    
    uint32_t read_size = fread(update_data, 1, file_length, fp);
    if (read_size != file_length) 
    {
        UPGRADE_DEBUG_PRINT("file read error,read_size=%d", read_size);
        fclose(fp);
        free(update_data);
        return 0;
    }
    UPGRADE_DEBUG_PRINT("read_size=%d", read_size);

    // 打包URL
    sprintf(url, "%s%s%s", "http://", cmu_ip_tbl[dev_num], "/upload");
    UPGRADE_DEBUG_PRINT("url:%s", url);
    
    ret = http_net_update_data_post(url, update_data, read_size, resp_data, firmware_update->package_name, NULL);
    if(ret != 1)
    {
        UPGRADE_DEBUG_PRINT("update packet trans error.");
        fclose(fp);
        free(update_data);
        return 0;
    }

    UPGRADE_DEBUG_PRINT("resp:%s", resp_data);
    fclose(fp);
    free(update_data);

    return 1;
}


/**
 * @brief    cmu升级列表信息转发（包括升级包）
 * @param	 [in] dev_index：设备编码 
 * @param	 [in] dev_list：升级列表信息
 * @return   -1：失败 0：成功
 */
static int32_t upgrade_device_list_info_trans(uint8_t dev_index, uint16_t dev_list)
{
    uint8_t uri[] = {"/upgrade/deviceList"};
    uint8_t url[128] = {0};
    uint8_t response[1024];
    cJSON *p_req_root = NULL;
    cJSON *p_type_array = NULL;
    uint8_t *p_json_str = NULL;
    uint8_t ret = 0;


    //第一步打包升级列表
    p_req_root = cJSON_CreateObject();
    if(p_req_root == NULL)
    {
        UPGRADE_DEBUG_PRINT("create json object failed");
        return -1;
    }

    p_type_array = cJSON_CreateArray();
    if(p_type_array == NULL)
    {
        UPGRADE_DEBUG_PRINT("create json array failed");
        cJSON_Delete(p_req_root);
        return -1;
    }

    if(BIT_GET(dev_list, 0))
    {
        cJSON_AddItemToArray(p_type_array, cJSON_CreateString("mcu1")); 
    }
    if(BIT_GET(dev_list, 1))
    {
        cJSON_AddItemToArray(p_type_array, cJSON_CreateString("mcu2")); 
    } 
    if(BIT_GET(dev_list, 2))
    {
        cJSON_AddItemToArray(p_type_array, cJSON_CreateString("pcs-m")); 
    }
    if(BIT_GET(dev_list, 3))
    {
        cJSON_AddItemToArray(p_type_array, cJSON_CreateString("pcs-s")); 
    }
    cJSON_AddStringToObject(p_req_root,"action", "deviceList");
    cJSON_AddItemToObject(p_req_root,"type", p_type_array);

    p_json_str = cJSON_PrintUnformatted(p_req_root);

    sprintf(url, "%s%s%s", "http://", cmu_ip_tbl[dev_index], uri);
    //设置设备列表
    ret = http_net_post(url, p_json_str, response);
    if(ret != 1)
    {
        return -1;
    }
    UPGRADE_DEBUG_PRINT("%s", response);
    cJSON_Delete(p_req_root);
    free(p_json_str);

    if(strstr(response, "successful") == NULL)
    {
        return -1;
    }
    //转发升级包
    ret = upgrade_file_trans(dev_index);
    if(!ret)
    {
        return -1;
    }

    return 0;

}



/**
 * @brief    CMU设置升级列表
 * @param	 [in] *p_list_data：升级列表数据 
 * @return   -1：失败 0：成功
 */
static int32_t upgrade_cmu_dev_list_set(uint8_t *p_list_data)
{
    cJSON *p_request = NULL;
    cJSON *p_list_info = NULL;
    cJSON *p_cmu_item = NULL;
    int array_size = 0;
    uint8_t mcu1 = 0, mcu2 = 0;
    uint8_t dsp_m = 0, dsp_l = 0;
    uint8_t i = 0;
    int32_t ret = 0;

    firmware_update_t *firmware_update = sdk_shm_update_data_get();

    p_request = cJSON_Parse(p_list_data);
    p_list_info = cJSON_GetObjectItem(p_request, "ListInfo");
	p_cmu_item = cJSON_GetObjectItem(p_list_info, "cmu");
    array_size = cJSON_GetArraySize(p_cmu_item);
    if(array_size > 0)
    {
        for(uint8_t i = 0; i < array_size; i++)
        {
            if(strcmp((cJSON_GetArrayItem(p_cmu_item, i)->valuestring),"cmu-mcu1") == 0)
            {
                mcu1 = 1;
            }
            if(strcmp((cJSON_GetArrayItem(p_cmu_item, i)->valuestring),"cmu-mcu2") == 0)
            {
                mcu2 = 1;
            }
            if(strcmp((cJSON_GetArrayItem(p_cmu_item, i)->valuestring),"pcs-dspm") == 0)
            {
                dsp_m = 1;
            }
            if(strcmp((cJSON_GetArrayItem(p_cmu_item, i)->valuestring),"pcs-dsps") == 0)
            {
                dsp_l = 1;
            }
        }
    }
    cJSON_Delete(p_request);

    if(mcu1 || mcu2 || dsp_m || dsp_l)
    {
        firmware_update->state = 2;
        //根据在线状态进行数据处理
        for(i = 0; i < MAX_SLAVE_COUNT; i++)
        {
            if(!dev_is_online(i + 1))
            {
                continue;
            }

            if (mcu1)
            {
                BIT_SET(g_upgrade_list_info.cmu_list[i], 0);
            }
            else
            {
                BIT_CLR(g_upgrade_list_info.cmu_list[i], 0);
            }
            
            if (mcu2)
            {
                BIT_SET(g_upgrade_list_info.cmu_list[i], 1);
            }
            else
            {
                BIT_CLR(g_upgrade_list_info.cmu_list[i], 1);
            }

            if (dsp_m)
            {
                BIT_SET(g_upgrade_list_info.cmu_list[i], 2);
            }
            else
            {
                BIT_CLR(g_upgrade_list_info.cmu_list[i], 2);
            }

            if (dsp_l)
            {
                BIT_SET(g_upgrade_list_info.cmu_list[i], 3);
            }
            else
            {
                BIT_CLR(g_upgrade_list_info.cmu_list[i], 3);
            }

            ret = upgrade_device_list_info_trans(i, g_upgrade_list_info.cmu_list[i]);
            if(ret)
            {
                UPGRADE_DEBUG_PRINT("cmu dev list info trans error.");
                return ret;
            }
        }
    }

    for(i = 0; i < MAX_SLAVE_COUNT; i++)
    {
        memset(firmware_update->dev_cmu_update[i].update_flag, 1, sizeof(firmware_update->dev_cmu_update[i].update_flag));
    }

    return 0;
}


/**
 * @brief    升级状态监测
 * @return
 */
static void *upgrade_status_monitor_func(void *arg)
{
    
	while(1)
	{
        //检查各个升级模块是否结束
        if(if_dev_upgrade_done())
        {
            g_upgrade_list_info.sys_upgrade = 2;
            g_reboot_flag = 1;
            sleep(2);
        }

		if(g_reboot_flag)
		{
            upgrade_log(g_cur_user);
            UPGRADE_DEBUG_PRINT("update finish, sys reboot...");
            system("sync");
            sleep(5);
			system("reboot -f");
		}
        sleep(2);
	}
}


/**
 * @brief    升级状态监测
 * @return
 */
static void upgrade_status_monitor(void)
{
    pthread_t tid;

    pthread_create(&tid, NULL, upgrade_status_monitor_func, NULL);
}


/**
 * @brief    CSU设置升级列表
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void upgrade_device_list(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t response[1024];
    uint8_t *p_action = NULL;
    uint8_t *p = NULL;
    uint8_t request_body[1024] = {0};
	uint8_t path[128] = {0};
	firmware_update_t *firmware_update = sdk_shm_update_data_get();
			
    memcpy(request_body, p_msg->body.p, p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		UPGRADE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response, Accepted, "parse request failed.");
		http_back(p_nc,response);
		return;
	}

	p_action = cJSON_GetObjectItem(p_request, "action")->valuestring;
	if(strcmp(p_action, "deviceList"))
	{
		UPGRADE_DEBUG_PRINT("action is not right.");
		build_empty_response(response, Non_Authoriative_Information, "action is not right");
		cJSON_Delete(p_request);
		http_back(p_nc, response);
		return;
	}
    cJSON_Delete(p_request);

    snprintf(path, 256, "%s%s", firmware_update->root_path, firmware_update->package_name);
	if ((sdk_fs_access(path, FS_F_OK)) == -1)
	{
		UPGRADE_DEBUG_PRINT("Upgrade file does not exist");
		build_empty_response(response, 600, "Upgrade file does not exist");
		http_back(p_nc,response);
		return;
	}
    
    //1、CSU升级列表处理
    if(upgrade_csu_dev_list_set(request_body) != 0)
    {
        build_empty_response(response, Non_Authoriative_Information, "update list set error");
		http_back(p_nc,response);
		return;
    }
    //2、CMU升级列表处理
    if(upgrade_cmu_dev_list_set(request_body) != 0)
    {
        build_empty_response(response, Non_Authoriative_Information, "update list set error");
		http_back(p_nc,response);
		return;
    }

    //3、状态监测线程启动
    if(!init_flag)
    {
        init_flag = 1;
        upgrade_status_monitor();
    }
    get_user_from_http_request(p_msg, g_cur_user);
    //4、设置升级本地标志
    g_upgrade_list_info.sys_upgrade = 1;
    firmware_update->local_ota_flag = 1;

    //此处加延时，等待升级进程提取升级文件
    sleep(3);
	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		UPGRADE_DEBUG_PRINT("create json array failed");
	}
	cJSON_AddNumberToObject(p_resp_root, "code", OK);
    cJSON_AddStringToObject(p_resp_root, "msg", "update list set success");
	p = cJSON_PrintUnformatted(p_resp_root);

	http_back(p_nc, p);
	cJSON_Delete(p_resp_root);
	free(p);

}


/**
 * @brief 升级模块初始化
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return void
 */
static void upgrade_dev_progress_get(struct mg_connection *p_nc,struct http_message *p_msg)
{
    uint8_t i = 0, j = 0;
    firmware_update_t *firmware_update = sdk_shm_update_data_get();

    get_upgrade_progress(p_nc, p_msg);	
    if(g_upgrade_progress_timer != NULL)
    {
        if(user_timer_is_timeout(g_upgrade_progress_timer) == SF_TRUE)
        {
            UPGRADE_DEBUG_PRINT("upgrade progress timer timeout");
            //判断是否存在CSU子模块升级
            if(g_upgrade_list_info.csu_list != 0)
            {
                //CSU-MCU1
                if(BIT_GET(g_upgrade_list_info.csu_list, 0))
                {
                    for (i = 0; i < UPDATE_OBJECT_NUM; ++i)
                    {
                        if (firmware_update->chip_role[i] == CSU_MCU1_NUM)
                        {
                            if(firmware_update->update_flag[i] == UPDATE_ING)
                            {
                                firmware_update->update_flag[i] = UPDATE_FAIL;
                            }
                        }
                    }	
                }

                //CSU-MCU2
                if(BIT_GET(g_upgrade_list_info.csu_list, 1))
                {
                    for (i = 0; i < UPDATE_OBJECT_NUM; ++i)
                    {
                        if (firmware_update->chip_role[i] == CSU_MCU2_NUM)
                        {
                            if(firmware_update->update_flag[i] == UPDATE_ING)
                            {
                                firmware_update->update_flag[i] = UPDATE_FAIL;
                            }
                        }
                    }	
                }
            }

            for(i = 0; i < MAX_SLAVE_COUNT; i++)
            {
                //判断是否存在CMU子模块升级
                if(g_upgrade_list_info.cmu_list[i] != 0)
                {
                    //CMU-MCU1
                    if(BIT_GET(g_upgrade_list_info.cmu_list[i], 0))
                    {
                        for (j = 0; j < UPDATE_OBJECT_NUM; ++j)
                        {
                            if (firmware_update->chip_role[j] == CMU_MCU1_NUM)
                            {
                                if(firmware_update->dev_cmu_update[i].update_flag[j] == UPDATE_ING)
                                {
                                    firmware_update->dev_cmu_update[i].update_flag[j] = UPDATE_FAIL;
                                }
                            }
                        }	
                    }

                    //CMU-MCU2
                    if(BIT_GET(g_upgrade_list_info.cmu_list[i], 1))
                    {
                        for (j = 0; j < UPDATE_OBJECT_NUM; ++j)
                        {
                            if (firmware_update->chip_role[j] == CMU_MCU2_NUM)
                            {
                                if(firmware_update->dev_cmu_update[i].update_flag[j] == UPDATE_ING)
                                {
                                    firmware_update->dev_cmu_update[i].update_flag[j] = UPDATE_FAIL;
                                }
                            }
                        }	
                    }

                    //DSP-M
                    if(BIT_GET(g_upgrade_list_info.cmu_list[i], 2))
                    {
                        for (j = 0; j < UPDATE_OBJECT_NUM; ++j)
                        {
                            if (firmware_update->chip_role[j] == PCS_M_NUM)
                            {
                                if(firmware_update->dev_cmu_update[i].update_flag[j] == UPDATE_ING)
                                {
                                    firmware_update->dev_cmu_update[i].update_flag[j] = UPDATE_FAIL;
                                }
                            }
                        }	
                    }

                    //DSP-L
                    if(BIT_GET(g_upgrade_list_info.cmu_list[i], 3))
                    {
                        for (j = 0; j < UPDATE_OBJECT_NUM; ++j)
                        {
                            if (firmware_update->chip_role[j] == PCS_S_NUM)
                            {
                                if(firmware_update->dev_cmu_update[i].update_flag[j] == UPDATE_ING)
                                {
                                    firmware_update->dev_cmu_update[i].update_flag[j] = UPDATE_FAIL;
                                }
                            }
                        }	
                    }
                }
            }
            firmware_update->result = -1;
        }
    }
}


/**
 * @brief 是否为主从机模式下从机升级
 * @param	 [in] *p_msg  http请求信息
 * @param	 [in] *p_index  从机ID
 * @return 0：非主从模式 1：主从模式
 */
static uint8_t is_master_slave_mode(struct http_message *p_msg, uint8_t *p_index)
{
    uint8_t slave_index = 0;
    uint8_t request_body[1024] = {0};
    uint8_t response[1024];
    cJSON *p_request = NULL;
    csu_combine_info_t *p_csu_combine = sdk_shm_csu_combine_data_get();

    if(CSU_ROLE_MASTER != csu_role_get())
    {
        *p_index = 0;
        return 0;
    }
    
    memcpy(request_body, p_msg->body.p, p_msg->body.len);		
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		UPGRADE_DEBUG_PRINT("parse request failed.");
		return 0;
	}

    slave_index = cJSON_GetObjectItem(p_request, "slaveIndex")->valueint;
    UPGRADE_DEBUG_PRINT("slave_index = %d", slave_index);

    cJSON_Delete(p_request);

    if((CSU_ROLE_MASTER == csu_role_get()) && (slave_index != 0))
    {
        *p_index = slave_index;
        return 1;
    }
    *p_index = 0;
    return 0;
}


/**
 * @brief    向从机上传升级文件
 * @param	 [in] *p_list_data：升级列表数据 
 * @return   0：失败 1：成功
 */
static int32_t slave_dev_upgrade_file_upload(uint8_t *p_path, uint8_t slave_index)
{
    uint8_t ret = 0;
    char slave_ip[16] = {0};
    uint8_t url[128] = {0};
    uint8_t resp_data[1024] = {0}; 
    uint8_t response[512] = {0};
    uint32_t file_length = 0;
    uint8_t *update_data = NULL;
    FILE *fp = NULL;

    firmware_update_t *firmware_update = sdk_shm_update_data_get();

    file_length = file_get_size(p_path);
    UPGRADE_DEBUG_PRINT("path=%s, szie=%llu\n",p_path, file_length);
    
    update_data = (uint8_t *)malloc(file_length + 1);
    if(update_data == NULL)
    {
        UPGRADE_DEBUG_PRINT("malloc error");
        return 0;
    }

    if ((fp = fopen((char *)p_path, "rb")) == NULL)
    {
        UPGRADE_DEBUG_PRINT("file open error");
        free(update_data);
        return 0;
    }
    
    uint32_t read_size = fread(update_data, 1, file_length, fp);
    if (read_size != file_length) 
    {
        UPGRADE_DEBUG_PRINT("file read error,read_size=%d", read_size);
        fclose(fp);
        free(update_data);
        return 0;
    }
    UPGRADE_DEBUG_PRINT("read_size=%d", read_size);

    ret = get_slave_ip(slave_index, slave_ip);
    if(!ret)
    {
        DATA_TRANS_DEBUG_PRINT("get slave ip failed.");
        fclose(fp);
        free(update_data);
        return 0;
    }

    // 打包URL
    sprintf(url, "%s%s%s", "http://", slave_ip, "/upload");
    UPGRADE_DEBUG_PRINT("url:%s", url);
    
    ret = http_net_update_data_post(url, update_data, read_size, resp_data, firmware_update->package_name, NULL);
    if(ret != 1)
    {
        UPGRADE_DEBUG_PRINT("update packet trans error.");
        fclose(fp);
        free(update_data);
        return 0;
    }

    UPGRADE_DEBUG_PRINT("resp:%s", resp_data);
    fclose(fp);
    free(update_data);

    return 1;
}


/**
 * @brief    向从机转发升级列表
 * @param	 [in] *p_list_data：升级列表数据 
 * @return   void
 */
static void slave_dev_upgrade_list_upload(struct mg_connection *p_nc, struct http_message *p_msg, uint8_t slave_index)
{
    web_data_trans2slave_by_uri(p_nc, p_msg, "/upgrade/deviceList");
}



/**
 * @brief    主从模式下从机升级
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void slave_dev_upgrade(struct mg_connection *p_nc,struct http_message *p_msg, uint8_t slave_index)
{
    uint8_t path[128] = {0};
    uint8_t response[1024] = {0};
    firmware_update_t *firmware_update = sdk_shm_update_data_get();

    snprintf(path, 256, "%s%s", firmware_update->root_path, firmware_update->package_name);
    if ((sdk_fs_access(path, FS_F_OK)) == -1)
    {
        UPGRADE_DEBUG_PRINT("Upgrade file does not exist");
        build_empty_response(response, 600, "Upgrade file does not exist");
        http_back(p_nc, response);
        return;
    }

    //1、上传升级文件
    if(!slave_dev_upgrade_file_upload(path, slave_index))
    {
        build_empty_response(response, Non_Authoriative_Information, "升级列表下发失败");
        http_back(p_nc, response);
        return;
    }
    //2、设置升级列表
    slave_dev_upgrade_list_upload(p_nc, p_msg, slave_index);

    return;
}


/**
 * @brief 升级模块初始化
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return void
 */
static void upgrade_dev_list_set(struct mg_connection *p_nc,struct http_message *p_msg)
{
    uint8_t slave_index = 0;

    //先判断是否为主从机模式下从机升级
    if(is_master_slave_mode(p_msg, &slave_index))
    {
        slave_dev_upgrade(p_nc, p_msg, slave_index);
        return;
    }
    //非主从模式升级或者主从模式下主机升级
    else
    {
        upgrade_device_list(p_nc, p_msg);

        if(g_upgrade_progress_timer == NULL)
        {
            g_upgrade_progress_timer = user_timer_create(NULL, NULL);
            if (g_upgrade_progress_timer == NULL)
            {
                UPGRADE_DEBUG_PRINT("upgrade progress timer create error");
                return;
            }
            user_timer_set_timeout(g_upgrade_progress_timer, UPGRADE_TIMEOUT, false);
        }
        else
        {
            user_timer_refresh(g_upgrade_progress_timer);
        }
    }
}

/**
 * @brief    获取CSU相关版本信息
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void csu_version_info_get(struct mg_connection *p_nc,struct http_message *p_msg)
{
    cJSON *p_request = NULL;
    uint8_t response[1024] = {0};
	uint8_t *action = NULL;
    uint8_t *p = NULL;
    cJSON *p_resp_root = NULL;
    uint8_t request_body[128] = {0};
	uint8_t version_buff[32] = {0};
    internal_version_info_t *p_version_info = sdk_shm_internal_version_info_get();

    memcpy(request_body,p_msg->body.p,p_msg->body.len);	
	p_request = cJSON_Parse(request_body);
    if(p_request == NULL)
	{
		UPGRADE_DEBUG_PRINT("parse request failed.");
		build_empty_response(response,Accepted,"parse request failed.");
		http_back(p_nc,response);
		return;
	}

	action = cJSON_GetObjectItem(p_request,"action")->valuestring;
    if(strcmp(action,"getVersionInfo"))
	{
		UPGRADE_DEBUG_PRINT("action is not right.");
		build_empty_response(response,Non_Authoriative_Information,"action is not right");
		cJSON_Delete(p_request);
		http_back(p_nc,response);
		return;
	}
    cJSON_Delete(p_request);

    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        UPGRADE_DEBUG_PRINT("create json obj failed.");
        return;
    }
	
    cJSON_AddNumberToObject(p_resp_root,"code",200);

    //系统版本号
	snprintf(version_buff, sizeof(version_buff), "%c%d.%d.%d", p_version_info->sys_soft_version[0],
	                                                           p_version_info->sys_soft_version[1],
                                                               p_version_info->sys_soft_version[2],
                                                               p_version_info->sys_soft_version[3]);
    cJSON_AddStringToObject(p_resp_root,"SYSVersion", version_buff);

    //mcu1 core版本号
	snprintf(version_buff, sizeof(version_buff), "%c%d.%d.%d", p_version_info->mcu1_core_soft_version[0],
	                                                           p_version_info->mcu1_core_soft_version[1],
                                                               p_version_info->mcu1_core_soft_version[2],
                                                               p_version_info->mcu1_core_soft_version[3]);
    cJSON_AddStringToObject(p_resp_root,"mcu1CoreSwVersion", version_buff);

    //mcu1 app版本号
	snprintf(version_buff, sizeof(version_buff), "%c%d.%d.%d", p_version_info->mcu1_app_soft_version[0],
	                                                           p_version_info->mcu1_app_soft_version[1],
                                                               p_version_info->mcu1_app_soft_version[2],
                                                               p_version_info->mcu1_app_soft_version[3]);
    cJSON_AddStringToObject(p_resp_root,"mcu1AppSwVersion", version_buff);

    //mcu2 core版本号
	snprintf(version_buff, sizeof(version_buff), "%c%d.%d.%d", p_version_info->mcu2_core_soft_version[0],
	                                                           p_version_info->mcu2_core_soft_version[1],
                                                               p_version_info->mcu2_core_soft_version[2],
                                                               p_version_info->mcu2_core_soft_version[3]);
    cJSON_AddStringToObject(p_resp_root,"mcu2CoreSwVersion", version_buff);

    //mcu2 app版本号
	snprintf(version_buff, sizeof(version_buff), "%c%d.%d.%d", p_version_info->mcu2_app_soft_version[0],
	                                                           p_version_info->mcu2_app_soft_version[1],
                                                               p_version_info->mcu2_app_soft_version[2],
                                                               p_version_info->mcu2_app_soft_version[3]);
    cJSON_AddStringToObject(p_resp_root,"mcu2AppSwVersion", version_buff);

    //硬件版本号
	snprintf(version_buff, sizeof(version_buff), "V%d.%d", p_version_info->mcu1_hardware_version[0],
	                                                       p_version_info->mcu1_hardware_version[1]);
    cJSON_AddStringToObject(p_resp_root,"HWversion", version_buff);

    cJSON_AddStringToObject(p_resp_root,"msg","get successful");
	p = cJSON_PrintUnformatted(p_resp_root);
	cJSON_Delete(p_resp_root);
	http_back(p_nc,p);
	free(p);
}


/**
 * @brief 升级模块初始化
 * @return void
 */
void web_upgrade_module_init(void)
{
	if(!web_func_attach("/upgrade/deviceList", TRANS_UNNEED, upgrade_dev_list_set))
	{
		UPGRADE_DEBUG_PRINT("[/upgrade/deviceList] attach failed");
	}
	if(!web_func_attach("/upgrade/getUpgradeProgress", TRANS_UNNEED, upgrade_dev_progress_get))
	{
		UPGRADE_DEBUG_PRINT("[/upgrade/getUpgradeProgress] attach failed");
	}
	if(!web_func_attach("/csuVersionInfo/getVersionInfo", TRANS_UNNEED, csu_version_info_get))
	{
		UPGRADE_DEBUG_PRINT("[/csuVersionInfo/getVersionInfo] attach failed");
	}
}
