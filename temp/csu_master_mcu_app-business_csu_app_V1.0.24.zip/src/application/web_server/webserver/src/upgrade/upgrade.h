#ifndef __UPGRADE_H__
#define __UPGRADE_H__

#include"mongoose.h"
#include "component/sofar_log.h"

#if (1)
#define UPGRADE_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else
#define USER_MANEGE_DEBUG_PRINT(...) {do {} while(0);}
#endif

#define UPGRADE_TIMEOUT         6 * 60 * 1000

typedef enum
{
    FILE_APP_NUM = 0x00,
    FILE_CORE_NUM,
    FILE_KERNEL_NUM,
    FILE_ROOTFS_NUM,
    FILE_SAFETY_NUM,
    FILE_PACK_NUM = 0x80,
} file_type_num_e;

typedef enum
{
    ALMIGHTY_NUM = 0x00,    // 不查询编码
    PCS_M_NUM = 0x22,
    PCS_S_NUM = 0x23,
    CSU_MCU1_NUM = 0x33,
    CSU_MCU2_NUM = 0x34,
    CMU_MCU1_NUM = 0x3b,
    CMU_MCU2_NUM = 0x3c,
} obj_num_e;



/**
 * @brief    升级文件上传
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] ev  
 * @param	 [in] p_data 数据内容
 * @return
 */
void upgrade_file_upload(struct mg_connection *p_nc, const int ev, void *p_data);


/**
 * @brief    升级文件上传
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] ev  
 * @param	 [in] p_data 数据内容
 * @return
 */
void safety_file_upload(struct mg_connection *p_nc, const int ev, void *p_data);

/**
 * @brief    是否处于升级状态
 * @return   true：升级 false：未升级
 */
bool if_dev_in_upgrade_status(void);

/**
 * @brief 升级模块初始化
 * @return void
 */
void web_upgrade_module_init(void);

#endif