#ifndef __SOFAR_FILE_TRANS_H__
#define __SOFAR_FILE_TRANS_H__



/**
 * @brief    HTTP获取CMU数据接口
 * @param	 [in] *p_uri url 
 * @param	 [in] *p_params 报文内容
 * @param	 [in] timeout 超时时间参数
 * @param	 [out] *p_resp_body 返回报文
 * @return   0：失败；1：成功
 */
uint8_t http_net_post(char* p_uri, char* p_params, char *p_resp_body);

/**
 * @brief    HTTP升级文件传输接口
 * @param	 [in] *p_uri url 
 * @param	 [in] *p_params 报文内容
 * @param	 [out] *p_resp_body 返回报文
 * @return   0：失败；1：成功
 */
uint8_t http_net_update_data_post(uint8_t* p_uri, uint8_t* p_params, uint32_t param_len, uint8_t *p_resp_body, uint8_t *file_name);


/**
 * @brief    cmu升级包传输
 * @param	 [in] dev_num  cmu编号
 * @return
 */
uint8_t cmu_update_packet_trans(uint8_t dev_num);


/**
 * @brief   对CMU进行升级列表&升级文件下发
 * @note
 * @return
 */
uint8_t sofar_cmu_ota_devlist_file_upload(void);

/**
 * @brief    安规升级文件传输
 * @param	 [in] dev_num  cmu编号
 * @return
 */
uint8_t cmu_safety_upgrade_packet_trans(uint8_t dev_num);


#endif