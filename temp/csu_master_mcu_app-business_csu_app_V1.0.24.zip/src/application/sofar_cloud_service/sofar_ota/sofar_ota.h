#ifndef __SOFAR_OTA_H__
#define __SOFAR_OTA_H__


#if (1)
#define SOFAR_OTA_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else
#define SOFAR_OTA_DEBUG_PRINT(...) {do {} while(0);}
#endif

#define FILE_NAME                       "ESS3M44_ota.sofar"
#define SOFAR_OTA_FILE_NAME             "/tmp/ESS3M44_ota.sofar"

#define SAFETY_NAME                     "EBI_safe.sofar"
#define SOFAR_SAFETY_FILE_NAME          "/tmp/EBI_safe.sofar"

#define     UPDATE_PATH                 "/tmp/update/"  			// 升级固件路径
#define     UPDATE_PATH_TMP             "/tmp/update/temp"  		// 暂时存放删除签名后的固件

#define     ESS3M44             9       // 产品类型：工商业储能
#define     MODEL_ESS3M44       17      // 产品机型
#define SIGNING_MSG_LENGTH      2048
#define DATA_LENGTH             1024
// 作用：是指把原来对齐方式设置压栈，并设新的对齐方式设置为一个字节对齐
#pragma pack(push)
#pragma pack(1)

//V02软件固件签名信息，见《软件固件签名规则》
typedef struct
{
  uint8_t         protocol_version;   //协议版本号
  uint32_t        file_len;           //文件长度 小端模式
  uint32_t        file_crc;           //有效字节crc32
  uint8_t         reserved1[70];      //预留
  int8_t          version;            //工程名称
  uint8_t         reserved2[19];      //预留
  uint8_t         file_type;          //文件类型
  uint8_t         reserved3[127];     //预留
} firmware_signature_t;

#define SIGNING_LENGTH          1024    //签名信息长度

/**
 * @brief  : V02版签名信息
 * @note   :
 */
typedef struct
{
  uint8_t file_type;    // 文件类型
  uint8_t chip_role;    // 芯片角色
  uint8_t name[56];     // 固件名称
  uint32_t addr;        // 起始偏移地址
  uint32_t length;      // 长度
  uint8_t version[20];  // 版本号
  uint8_t reserved[18]; // 预留
} firmware_msg_V02_t;

typedef struct
{
  uint8_t protocol_version;            //协议版本号
  uint8_t company[16];                 // 公司名称
  uint8_t product_type_code;           // 产品类型编码
  uint16_t product_model_code;         // 产品型号编码
  uint8_t package_name[52];            // 固件包名称
  uint8_t release_time[6];             // 固件包打包日期
  uint8_t module_total;                // 固件模块数量
  uint8_t reserved1[58];               // 预留
  firmware_msg_V02_t firmware_msg[18]; // 各固件信息
  uint8_t reserved2[31];               // 预留
  uint32_t package_length;             // 固件包总长
  uint32_t package_crc32;              // CRC32
} package_signing_msg_V02_t;

#pragma pack(pop) // 作用：恢复对齐状态

#pragma pack(push)
#pragma pack(1)
#define UPDATE_OBJECT_NUM        12
//固件升级结构体
typedef struct{
    uint8_t  module_total;                              //升级子设备数量
	uint8_t  update_flag[UPDATE_OBJECT_NUM];            // 升级标志，0-无需升级、升级成功; 1-正在升级;
	char 	 module_object[UPDATE_OBJECT_NUM][9];       // 升级对象 "MCU1", "MCU2"
	char     module_name[UPDATE_OBJECT_NUM][56];        // 固件名
	char     module_percent[UPDATE_OBJECT_NUM];         // 升级进度,进度值为：0~100，依次为CSU-MCU1 CSU-MCU2 CMU-MCU1 CMU-MCU2 PCS-M PCS-S
	uint8_t  file_type[UPDATE_OBJECT_NUM];              // 文件类型编码
	uint16_t chip_role[UPDATE_OBJECT_NUM];              // 芯片角色编码
	uint32_t module_result[UPDATE_OBJECT_NUM];          // 每个byte代表一个模块的结果，0-未升级或升级失败 1-升级成功
}sofar_firmware_update_t;
#pragma pack(pop)

// 新格式的文件类型编码
typedef enum
{
    FILE_APP_NUM = 0x00,
    FILE_CORE_NUM = 0x01,
    FILE_KERNEL_NUM,
    FILE_ROOTFS_NUM,
    FILE_SAFETY_NUM,
    FILE_PACK_NUM = 0x80,
} file_type_num_e;

// 新格式的芯片编码
typedef enum
{
    ALMIGHTY_NUM = 0x00,    // 不查询编码
    PCS_M_NUM = 0x22,
    PCS_S_NUM = 0x23,
    CSU_MCU1_NUM = 0x33,
    CSU_MCU2_NUM = 0x34,
    CMU_MCU1_NUM = 0x3b,
    CMU_MCU2_NUM = 0x3c,
} obj_num_e;


#define FILE_DOWNLOAD_FAIL          "downloadFailed"
#define FILE_DOWNLOAD_SUCCESS       "donwloadSuccessed"
#define FILE_VERTICATION_FAIL       "vertifcationFailed"
#define FILE_VERTICATION_SUCCESS    "vertifcationSuccessed"
#define FILE_TRANSMISSION_FAIL      "transmissionFailed"
#define FILE_TRANSMISSION_SUCCESS   "transmissionSuccessed"
#define FILE_UPGRADING              "upgrading"
#define FILE_UPGRADING_FAIL         "upgradeFailed"
#define FILE_UPGRADING_SUCCESS      "upgradeSuccessed"
#define FILE_VERSIONeRROR           "versionError"
#define FILE_DEVICE_OFFLINE         "deviceOffline"
#define FILE_TASK_CONFLICT          "taskConflict"
#define FILE_TIMEOUT                "timeout"

#define OPT_TIMEOUT         3
#define OPT_RUNNING         2
#define OPT_SUCCESS         1
#define OPT_FAILED          0

#define OTA_TIMEOUT_SEC     (15 * 60)


#define HTTP_FILE_URL_LEN_MAX           128
#define HTTP_FILE_SIGN_LEN_MAX          64

enum{
    OTA_UPGRADING = 0,          //升级中
    OTA_UPGRADE_SUCCESS,        //升级成功
    OTA_UPGRADE_FAIL            //升级失败
};

enum{
    OTA_NONE = 0,
    OTA_FILE_DOWNLOAD,          //文件下载
    OTA_FILE_VERTICATE,         //文件校验
    OTA_FILE_EXTRAC,            //文件提取
    OTA_FILE_TRANS,             //文件转发
    OTA_UPGRADE,                //设备升级
    OTA_UPGRADE_MONITOR,        //升级监测
    OTA_UPGRADE_DONE,           //升级结束
};

typedef struct{
    char http_file_url[HTTP_FILE_URL_LEN_MAX];
    char http_file_sign[HTTP_FILE_SIGN_LEN_MAX];
    char request_id[HTTP_FILE_SIGN_LEN_MAX];
    uint16_t ota_tick_cnt;
    uint8_t ota_status;
}sofar_ota_info_t;

/**
 * @brief   获取文件长度
 * @param   [in] path:文件路径
 * @note
 * @return
 */
uint64_t file_get_size(const char *path);

/**
 * @brief   升级信息获取
 * @note
 * @return
 */
sofar_ota_info_t *sofar_ota_info_get(void);

/**
 * @brief   安规升级信息获取
 * @note
 * @return
 */
sofar_ota_info_t *sofar_safety_upgrade_info_get(void);

/**
 * @brief   固件信息获取
 * @note
 * @return
 */
sofar_firmware_update_t *sofar_firmware_info_get(void);

/**
 * @brief   OTA服务模块初始化
 * @param
 * @note
 * @return
 */
void sofar_ota_module_init(void);


#endif