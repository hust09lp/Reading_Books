#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include "cJSON.h"
#include "sofar_log.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk_public.h"
#include "sofar_ota.h"
#include "app_common.h"
#include "mqtt_client_service.h"
#include"libghttp/ghttp.h"
#include"libghttp/ghttp_constants.h"

static uint8_t g_cmu_ip_tbl[MAX_SLAVE_COUNT][MAX_IP_LEN] = {CMU1_IP, CMU2_IP, CMU3_IP, CMU4_IP, CMU5_IP, CMU6_IP};

/**
 * @brief  生成16位随机字符串
 */
static void random_str_generate(uint8_t *p_str)
{
    #define CHAR_MIN1 'a'
    #define CHAR_MAX1 'z' 

    srand(time(NULL));                              //通过时间函数设置随机数种子，使得每次运行结果随机。

    for(uint8_t i = 0; i < 16; i++)
    {
        p_str[i] = rand() % ('Z' - 'a' + 1) + 'a';  //生成要求范围内的随机数。
    }
}


/**
 * @brief    HTTP获取CMU数据接口
 * @param	 [in] *p_uri url 
 * @param	 [in] *p_params 报文内容
 * @param	 [in] timeout 超时时间参数
 * @param	 [out] *p_resp_body 返回报文
 * @return   0：失败；1：成功
 */
uint8_t http_net_post(char* p_uri, char* p_params, char *p_resp_body) 
{  
    ghttp_request *request = NULL;  
    char *resp_buf = NULL;
    ghttp_status status;  

    request = ghttp_request_new();  
    if(ghttp_set_uri(request, p_uri) == -1)  
    {
        SOFAR_OTA_DEBUG_PRINT((int8_t *)"ghttp set uri error");
        return 0;
    } 
    if(ghttp_set_type(request, ghttp_type_post) == -1)
    {
        SOFAR_OTA_DEBUG_PRINT((int8_t *)"ghttp set type error");
        return 0;
    }

    if(p_params == NULL)
    {
        SOFAR_OTA_DEBUG_PRINT((int8_t *)"params is NULL,error");
        return 0;
    }

    ghttp_set_header(request, http_hdr_Content_Type,"application/x-www-form-urlencoded"); 
    ghttp_set_sync(request, ghttp_sync); //set sync  
    ghttp_set_body(request, p_params, strlen(p_params)); //  
    ghttp_prepare(request);  
    status = ghttp_process(request);  
    if(status == ghttp_error)  
    {
        ghttp_request_destroy(request);
        ghttp_close(request);
        return 0;
    }

    resp_buf = ghttp_get_body(request);
    memcpy(p_resp_body, resp_buf, strlen(resp_buf));
    ghttp_request_destroy(request);
    ghttp_close(request);
    return 1;  
} 

/**
 * @brief    HTTP升级文件传输接口
 * @param	 [in] *p_uri url 
 * @param	 [in] *p_params 报文内容
 * @param	 [out] *p_resp_body 返回报文
 * @return   0：失败；1：成功
 */
uint8_t http_net_update_data_post(char* p_uri, uint8_t* p_params, uint32_t param_len, uint8_t *p_resp_body, uint8_t *file_name) 
{  
    uint8_t random_str[17] = {0}; 
    char content_type[128] = {0}; 
    ghttp_request *request = NULL;  
    char *resp_buf = NULL;
    ghttp_status status;  
    char start_str[512] = {0};
    char end_str[128] = {0};
    char *update_packet = NULL;

    request = ghttp_request_new();  
    if(ghttp_set_uri(request, p_uri) == -1)  
    {
        SOFAR_OTA_DEBUG_PRINT((int8_t *)"ghttp set uri error");
        return 0;
    } 
    if(ghttp_set_type(request, ghttp_type_post) == -1)
    {
        SOFAR_OTA_DEBUG_PRINT((int8_t *)"ghttp set type error");
        return 0;
    }

    if(p_params == NULL)
    {
        SOFAR_OTA_DEBUG_PRINT((int8_t *)"params is NULL,error");
        return 0;
    }

    ghttp_set_header(request, http_hdr_Accept,"application/json, text/plain, */*"); 
    ghttp_set_header(request, http_hdr_Accept_Encoding,"gzip, deflate"); 
    ghttp_set_header(request, http_hdr_Accept_Language,"zh-CN,zh;q=0.9"); 
    ghttp_set_header(request, http_hdr_Connection,"keep-alive"); 
    ghttp_set_header(request, http_hdr_Set_Cookie, "loginName_CMU=cloud; openId=asfafsfsfsdfsdfsdfdsf; userRole_CMU=operator"); 
    random_str_generate(random_str);
    sprintf(content_type, "%s%s", "multipart/form-data; boundary=----WebKitFormBoundary",random_str);  
    ghttp_set_header(request, http_hdr_Content_Type, content_type); 
    ghttp_set_sync(request, ghttp_sync); 

    update_packet = malloc(param_len + 1024);
    if(update_packet == NULL)
    {
        SOFAR_OTA_DEBUG_PRINT((int8_t *)"malloc error");
        return 0;
    }

    memset(content_type, 0, 128);
    sprintf(content_type, "%s", "Content-Type: application/octet-stream");

    char content_disposition[128] = {0}; 
    sprintf(content_disposition, "%s%s""\"%s\"""%s""\"%s\"", "Content-Disposition: ","multipart/form-data; name=", "file","; filename=",file_name);

    sprintf(start_str, "%s%s%s%s%s%s%s", "------WebKitFormBoundary",random_str,"\r\n",content_disposition,"\r\n",content_type,"\r\n\r\n");  

    strcpy(update_packet, start_str);
    memcpy(&update_packet[strlen(start_str)], p_params, param_len);

    sprintf(end_str, "%s%s%s%s%s", "\r\n","------WebKitFormBoundary",random_str,"--","\r\n");  

    memcpy(&update_packet[strlen(start_str) + param_len], end_str, strlen(end_str));
    ghttp_set_body(request, update_packet, param_len + strlen(start_str) + strlen(end_str)); //  
    ghttp_prepare(request);  
    status = ghttp_process(request);  
    if(status == ghttp_error)  
    {
        ghttp_clean(request); 
        ghttp_close(request);
        free(update_packet);
        return 0;
    }

    resp_buf = ghttp_get_body(request);
    memcpy(p_resp_body, resp_buf, strlen(resp_buf));
    ghttp_clean(request);  
    ghttp_close(request);
    free(update_packet);
    return 1;  
} 


/**
 * @brief    cmu升级包传输
 * @param	 [in] dev_num  cmu编号
 * @return
 */
uint8_t cmu_update_packet_trans(uint8_t dev_num)
{
    uint8_t ret = 0;
    char url[128] = {0};
    uint8_t resp_data[1024] = {0}; 
    char path[128] = {0};
    uint32_t file_length = 0;
    uint8_t *update_data = NULL;
    FILE *fp = NULL;

    snprintf((char *)path, sizeof(path) - 1, "%s%s", "/tmp/", FILE_NAME);
    file_length = file_get_size(path);
    SOFAR_OTA_DEBUG_PRINT((int8_t *)"\n p_update->root_path: %s, path=%s, package_name=%s, szie=%llu\n", "/tmp/", path, FILE_NAME);
    
    update_data = (uint8_t *)malloc(file_length + 1);
    if(update_data == NULL)
    {
        SOFAR_OTA_DEBUG_PRINT((int8_t *)"malloc error");
        return 0;
    }

    if ((fp = fopen((char *)path, "rb")) == NULL)
    {
        SOFAR_OTA_DEBUG_PRINT((int8_t *)"file open error");
        free(update_data);
        return 0;
    }
    
    uint32_t read_size = fread(update_data, 1, file_length, fp);
    if (read_size != file_length) 
    {
        SOFAR_OTA_DEBUG_PRINT((int8_t *)"file read error,read_size=%d", read_size);
        fclose(fp);
        free(update_data);
        return 0;
    }
    SOFAR_OTA_DEBUG_PRINT((int8_t *)"read_size=%d", read_size);

    // 打包URL
    sprintf(url, "%s%s%s", "http://", g_cmu_ip_tbl[dev_num - 1], "/upload");
    SOFAR_OTA_DEBUG_PRINT((int8_t *)"url:%s", url);
    
    ret = http_net_update_data_post(url, update_data, read_size, resp_data, (uint8_t *)FILE_NAME);
    if(ret != 1)
    {
        SOFAR_OTA_DEBUG_PRINT((int8_t *)"update packet trans error.");
        fclose(fp);
        free(update_data);
        return 0;
    }

    SOFAR_OTA_DEBUG_PRINT((int8_t *)"resp:%s", resp_data);
    fclose(fp);
    free(update_data);

    return 1;
}


/**
 * @brief   对CMU进行升级列表&升级文件下发
 * @note
 * @return
 */
uint8_t sofar_cmu_ota_devlist_file_upload(void) 
{
    uint8_t uri[] = {"/upgrade/deviceList"};
    uint8_t ret = 0;
    char url[128] = {0};
    char response[1024] = {0};
    cJSON *p_type_array = NULL;
    cJSON *p_req_root = NULL;
    sofar_firmware_update_t *p_sofar_firmware_update = sofar_firmware_info_get();

    p_req_root = cJSON_CreateObject();
    if(p_req_root == NULL)
    {
        SOFAR_OTA_DEBUG_PRINT((int8_t *)"create json array failed");
        return OPT_FAILED;
    }

    p_type_array = cJSON_CreateArray();
    if(p_type_array == NULL)
    {
        SOFAR_OTA_DEBUG_PRINT((int8_t *)"create json array failed");
        cJSON_Delete(p_req_root);
        return OPT_FAILED;
    }

    for(uint8_t i = 0; i < UPDATE_OBJECT_NUM; i++)
    {
        if(!strcmp(p_sofar_firmware_update->module_object[i], "CMU-MCU1"))
        {
            cJSON_AddItemToArray(p_type_array, cJSON_CreateString("mcu1"));
        }
        if(!strcmp(p_sofar_firmware_update->module_object[i], "CMU-MCU2"))
        {
            cJSON_AddItemToArray(p_type_array, cJSON_CreateString("mcu2")); 
        }  
        if(!strcmp(p_sofar_firmware_update->module_object[i], "PCS-M"))
        {
            cJSON_AddItemToArray(p_type_array, cJSON_CreateString("pcs-m")); 
        } 
        if(!strcmp(p_sofar_firmware_update->module_object[i], "PCS-S"))
        {
            cJSON_AddItemToArray(p_type_array, cJSON_CreateString("pcs-s")); 
        } 
    }

    cJSON_AddStringToObject(p_req_root,"action", "deviceList");
    cJSON_AddNumberToObject(p_req_root,"sofarOta", 1);
    cJSON_AddItemToObject(p_req_root,"type", p_type_array);

    char *json_str = cJSON_PrintUnformatted(p_req_root);

    sprintf(url, "%s%s%s", "http://", g_cmu_ip_tbl[0], uri);
    ret = http_net_post(url, json_str, response);
    if(ret != 1)
    {
        return OPT_FAILED;
    }
    SOFAR_OTA_DEBUG_PRINT((int8_t *)"%s", response);
    cJSON_Delete(p_req_root);
    free(json_str);

    if(strstr(response, "successful") == NULL)
    {
        return OPT_FAILED;
    }
    ret = cmu_update_packet_trans(1);
    if(!ret)
    {
        return OPT_FAILED;
    }

    return OPT_SUCCESS;
}


/**
 * @brief    安规升级文件传输
 * @param	 [in] dev_num  cmu编号
 * @return
 */
uint8_t cmu_safety_upgrade_packet_trans(uint8_t dev_num)
{
    uint8_t ret = 0;
    char url[128] = {0};
    uint8_t resp_data[1024] = {0}; 
    char path[128] = {0};
    uint32_t file_length = 0;
    uint8_t *update_data = NULL;
    FILE *fp = NULL;

    snprintf((char *)path, sizeof(path) - 1, "%s%s", "/tmp/", SAFETY_NAME);
    file_length = file_get_size(path);
    SOFAR_OTA_DEBUG_PRINT((int8_t *)"\n p_update->root_path: %s, path=%s, package_name=%s, szie=%llu\n", "/tmp/", path, FILE_NAME);
    
    update_data = (uint8_t *)malloc(file_length + 1);
    if(update_data == NULL)
    {
        SOFAR_OTA_DEBUG_PRINT((int8_t *)"malloc error");
        return 0;
    }

    if ((fp = fopen((char *)path, "rb")) == NULL)
    {
        SOFAR_OTA_DEBUG_PRINT((int8_t *)"file open error");
        free(update_data);
        return 0;
    }
    
    uint32_t read_size = fread(update_data, 1, file_length, fp);
    if (read_size != file_length) 
    {
        SOFAR_OTA_DEBUG_PRINT((int8_t *)"file read error,read_size=%d", read_size);
        fclose(fp);
        free(update_data);
        return 0;
    }
    SOFAR_OTA_DEBUG_PRINT((int8_t *)"read_size=%d", read_size);

    // 打包URL
    sprintf(url, "%s%s%s", "http://", g_cmu_ip_tbl[dev_num - 1], "/SafetUpload");
    SOFAR_OTA_DEBUG_PRINT((int8_t *)"url:%s", url);
    
    ret = http_net_update_data_post(url, update_data, read_size, resp_data, (uint8_t *)FILE_NAME);
    if(ret != 1)
    {
        SOFAR_OTA_DEBUG_PRINT((int8_t *)"update packet trans error.");
        fclose(fp);
        free(update_data);
        return 0;
    }

    SOFAR_OTA_DEBUG_PRINT((int8_t *)"resp:%s", resp_data);
    fclose(fp);
    free(update_data);

    return 1;
}
