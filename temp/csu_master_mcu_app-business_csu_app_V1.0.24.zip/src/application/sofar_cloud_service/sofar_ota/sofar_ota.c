#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pthread.h>
#include "cJSON.h"
#include "sofar_log.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk_public.h"
#include "curl.h"
#include "easy.h"
#include "sofar_ota.h"
#include "app_common.h"
#include "mqtt_client_service.h"
#include "sofar_file_trans.h"
#include "sqlite3.h"

struct st_oplog_info
{
	char user_name[32]; 				//用户名
	char phone_num[16]; 				//手机号
	char user_role[16]; 				//用户角色
	char op_type[64];				//该部分使用中文直接传到前端
	char dev_sn[16]; 				//设备SN
	double op_param1;   				//操作参数1
	double op_param2; 					//操作参数2
	char op_status[16]; 				//操作状态,成功还是失败
	char time_stamp[32]; 			//操作时间,格式为时间戳
    time_t op_time;
};
typedef struct st_oplog_info operation_log_t;

static sofar_ota_info_t g_sofar_safety_upgrade_info = {0};

static sofar_ota_info_t g_sofar_ota_info = {0};
static package_signing_msg_V02_t g_package_V02 = {0};
static sofar_firmware_update_t g_sofar_firmware_update = {0};

#define OPERATION_DB_PATH                   "/user/data/event/Operation.db"

typedef struct
{
    uint8_t file_number;
    uint8_t obj_number;
    uint8_t module_object[UPDATE_OBJECT_NUM];
} role_coding_new_t;

// 新格式的芯片角色编码与对象简称
static role_coding_new_t g_role_coding_new[UPDATE_OBJECT_NUM] =
{
    /*      文件类型编码（新）    芯片角色编码（新）       类型           */
    {FILE_APP_NUM,  CSU_MCU1_NUM,  "CSU-MCU1"},
    {FILE_CORE_NUM, CSU_MCU1_NUM,  "CSU-MCU1"},
    {FILE_APP_NUM,  CSU_MCU2_NUM,  "CSU-MCU2"},
    {FILE_CORE_NUM, CSU_MCU2_NUM,  "CSU-MCU2"},

    {FILE_APP_NUM,  CMU_MCU1_NUM,  "CMU-MCU1"},
    {FILE_CORE_NUM, CMU_MCU1_NUM,  "CMU-MCU1"},
    {FILE_APP_NUM,  CMU_MCU2_NUM,  "CMU-MCU2"},
    {FILE_CORE_NUM, CMU_MCU2_NUM,  "CMU-MCU2"},

    {FILE_APP_NUM,  PCS_M_NUM,     "PCS-M"},
    {FILE_APP_NUM,  PCS_S_NUM,     "PCS-S"},
};

static uint32_t g_crc32 = 0xFFFFFFFF;
static const uint32_t g_crc32_table[] =
{
    0x00000000, 0x77073096, 0xee0e612c, 0x990951ba, 0x076dc419, 0x706af48f,
    0xe963a535, 0x9e6495a3, 0x0edb8832, 0x79dcb8a4, 0xe0d5e91e, 0x97d2d988,
    0x09b64c2b, 0x7eb17cbd, 0xe7b82d07, 0x90bf1d91, 0x1db71064, 0x6ab020f2,
    0xf3b97148, 0x84be41de, 0x1adad47d, 0x6ddde4eb, 0xf4d4b551, 0x83d385c7,
    0x136c9856, 0x646ba8c0, 0xfd62f97a, 0x8a65c9ec, 0x14015c4f, 0x63066cd9,
    0xfa0f3d63, 0x8d080df5, 0x3b6e20c8, 0x4c69105e, 0xd56041e4, 0xa2677172,
    0x3c03e4d1, 0x4b04d447, 0xd20d85fd, 0xa50ab56b, 0x35b5a8fa, 0x42b2986c,
    0xdbbbc9d6, 0xacbcf940, 0x32d86ce3, 0x45df5c75, 0xdcd60dcf, 0xabd13d59,
    0x26d930ac, 0x51de003a, 0xc8d75180, 0xbfd06116, 0x21b4f4b5, 0x56b3c423,
    0xcfba9599, 0xb8bda50f, 0x2802b89e, 0x5f058808, 0xc60cd9b2, 0xb10be924,
    0x2f6f7c87, 0x58684c11, 0xc1611dab, 0xb6662d3d, 0x76dc4190, 0x01db7106,
    0x98d220bc, 0xefd5102a, 0x71b18589, 0x06b6b51f, 0x9fbfe4a5, 0xe8b8d433,
    0x7807c9a2, 0x0f00f934, 0x9609a88e, 0xe10e9818, 0x7f6a0dbb, 0x086d3d2d,
    0x91646c97, 0xe6635c01, 0x6b6b51f4, 0x1c6c6162, 0x856530d8, 0xf262004e,
    0x6c0695ed, 0x1b01a57b, 0x8208f4c1, 0xf50fc457, 0x65b0d9c6, 0x12b7e950,
    0x8bbeb8ea, 0xfcb9887c, 0x62dd1ddf, 0x15da2d49, 0x8cd37cf3, 0xfbd44c65,
    0x4db26158, 0x3ab551ce, 0xa3bc0074, 0xd4bb30e2, 0x4adfa541, 0x3dd895d7,
    0xa4d1c46d, 0xd3d6f4fb, 0x4369e96a, 0x346ed9fc, 0xad678846, 0xda60b8d0,
    0x44042d73, 0x33031de5, 0xaa0a4c5f, 0xdd0d7cc9, 0x5005713c, 0x270241aa,
    0xbe0b1010, 0xc90c2086, 0x5768b525, 0x206f85b3, 0xb966d409, 0xce61e49f,
    0x5edef90e, 0x29d9c998, 0xb0d09822, 0xc7d7a8b4, 0x59b33d17, 0x2eb40d81,
    0xb7bd5c3b, 0xc0ba6cad, 0xedb88320, 0x9abfb3b6, 0x03b6e20c, 0x74b1d29a,
    0xead54739, 0x9dd277af, 0x04db2615, 0x73dc1683, 0xe3630b12, 0x94643b84,
    0x0d6d6a3e, 0x7a6a5aa8, 0xe40ecf0b, 0x9309ff9d, 0x0a00ae27, 0x7d079eb1,
    0xf00f9344, 0x8708a3d2, 0x1e01f268, 0x6906c2fe, 0xf762575d, 0x806567cb,
    0x196c3671, 0x6e6b06e7, 0xfed41b76, 0x89d32be0, 0x10da7a5a, 0x67dd4acc,
    0xf9b9df6f, 0x8ebeeff9, 0x17b7be43, 0x60b08ed5, 0xd6d6a3e8, 0xa1d1937e,
    0x38d8c2c4, 0x4fdff252, 0xd1bb67f1, 0xa6bc5767, 0x3fb506dd, 0x48b2364b,
    0xd80d2bda, 0xaf0a1b4c, 0x36034af6, 0x41047a60, 0xdf60efc3, 0xa867df55,
    0x316e8eef, 0x4669be79, 0xcb61b38c, 0xbc66831a, 0x256fd2a0, 0x5268e236,
    0xcc0c7795, 0xbb0b4703, 0x220216b9, 0x5505262f, 0xc5ba3bbe, 0xb2bd0b28,
    0x2bb45a92, 0x5cb36a04, 0xc2d7ffa7, 0xb5d0cf31, 0x2cd99e8b, 0x5bdeae1d,
    0x9b64c2b0, 0xec63f226, 0x756aa39c, 0x026d930a, 0x9c0906a9, 0xeb0e363f,
    0x72076785, 0x05005713, 0x95bf4a82, 0xe2b87a14, 0x7bb12bae, 0x0cb61b38,
    0x92d28e9b, 0xe5d5be0d, 0x7cdcefb7, 0x0bdbdf21, 0x86d3d2d4, 0xf1d4e242,
    0x68ddb3f8, 0x1fda836e, 0x81be16cd, 0xf6b9265b, 0x6fb077e1, 0x18b74777,
    0x88085ae6, 0xff0f6a70, 0x66063bca, 0x11010b5c, 0x8f659eff, 0xf862ae69,
    0x616bffd3, 0x166ccf45, 0xa00ae278, 0xd70dd2ee, 0x4e048354, 0x3903b3c2,
    0xa7672661, 0xd06016f7, 0x4969474d, 0x3e6e77db, 0xaed16a4a, 0xd9d65adc,
    0x40df0b66, 0x37d83bf0, 0xa9bcae53, 0xdebb9ec5, 0x47b2cf7f, 0x30b5ffe9,
    0xbdbdf21c, 0xcabac28a, 0x53b39330, 0x24b4a3a6, 0xbad03605, 0xcdd70693,
    0x54de5729, 0x23d967bf, 0xb3667a2e, 0xc4614ab8, 0x5d681b02, 0x2a6f2b94,
    0xb40bbe37, 0xc30c8ea1, 0x5a05df1b, 0x2d02ef8d
};

void update_check_crc32(uint8_t *buf, int len)
{
    uint8_t *p = NULL;

    for (p = buf; len > 0; ++p, --len)
    {
        g_crc32 = (uint32_t)(g_crc32_table[(g_crc32 ^ *p) & 0xFF] ^ (g_crc32 >> 8));
    }
}



/**
 * @brief   升级信息获取
 * @note
 * @return
 */
sofar_ota_info_t *sofar_ota_info_get(void)
{
    return &g_sofar_ota_info;
}

/**
 * @brief   安规升级信息获取
 * @note
 * @return
 */
sofar_ota_info_t *sofar_safety_upgrade_info_get(void)
{
    return &g_sofar_safety_upgrade_info;
}


/**
 * @brief   固件信息获取
 * @note
 * @return
 */
sofar_firmware_update_t *sofar_firmware_info_get(void)
{
    return &g_sofar_firmware_update;
}


/**
 * @brief   shell指令
 * @note
 * @return 
 */
static int32_t sdk_system_cmd(int8_t * cmd)
{
    FILE *fp = NULL;

    if((fp=popen((char *)cmd, "r")) == NULL)
    {
        return -1;
    }
    pclose(fp);

    return 0;
}


/**
 * @brief   初始化操作日志结构体
 * @param   [in] 操作日志结构体指针
 * @param   [out] 操作日志结构体指针
 * @return  无
 */
void init_user_basic_info(operation_log_t *oplog)
{
	memset(oplog,0,sizeof(operation_log_t));
	strncpy(oplog->phone_num,"未知",strlen("未知"));
	oplog->dev_sn[0] = 0; //序列号
	strncpy(oplog->user_role,"未知",strlen("未知"));
	oplog->op_param1 = 0;
	oplog->op_param2 = 0;
	strncpy(oplog->op_status,"failed",strlen("failed"));
}


/**
 * @brief   添加一条操作日志,该函数为公共函数,不同模块记录操作日志时调用该函数即可
 * @return  无
 */
void add_one_op_log(operation_log_t *p_oplog)
{
	sqlite3 *db = NULL;
    int32_t ret;
	sdk_rtc_t rtc_time;
    char date_time[32] = {0};
		
	ret = sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
	if (ret != 0)
    {
		SOFAR_OTA_DEBUG_PRINT((int8_t *)"\n [%s:%d] sdk_rtc_get fail \n", __func__, __LINE__);
		return;
    }
	snprintf(date_time, 32, "%04d-%02d-%02d %02d:%02d:%02d", 2000 + rtc_time.tm_year,rtc_time.tm_mon, rtc_time.tm_day, rtc_time.tm_hour, rtc_time.tm_min, rtc_time.tm_sec);

    ret = sqlite3_open(OPERATION_DB_PATH, &db);
    if(ret) 
    {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return;
    }
    else
    {
        char *sql = "INSERT INTO Operation (USERNAME, PHONENUM, USERROLE, OPTYPE, DEVSN, PARAM1, PARAM2, OPSTATUS, TIME) VALUES \
            (?, ?, ?, ?, ?, ?, ?, ?, ?);";
        sqlite3_stmt *stmt;
        sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
        sqlite3_bind_text(stmt, 1, p_oplog->user_name, -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt, 2, p_oplog->phone_num, -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt, 3, p_oplog->user_role, -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt, 4, p_oplog->op_type, -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt, 5, p_oplog->dev_sn, -1, SQLITE_STATIC);
        sqlite3_bind_double(stmt, 6, p_oplog->op_param1);
        sqlite3_bind_double(stmt, 7, p_oplog->op_param2);    
        sqlite3_bind_text(stmt, 8, p_oplog->op_status, -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt, 9, date_time, -1, SQLITE_STATIC);    

        ret = sqlite3_step(stmt);
    	if (ret != SQLITE_DONE) 
        {
            SOFAR_OTA_DEBUG_PRINT((int8_t *)"sqlite3_step error");
        } 
        sqlite3_finalize(stmt);
    }
	sqlite3_close(db);
}

/**
 * @brief    升级日志记录
 * @return
 */
static void upgrade_log(void)
{
    operation_log_t op_log = {0};
    firmware_update_t *firmware_update = sdk_shm_update_data_get();

	strncpy(op_log.phone_num,"未知",strlen("未知"));
	op_log.dev_sn[0] = 0; //序列号
	strncpy(op_log.user_role,"未知",strlen("未知"));
	op_log.op_param1 = 0;
	op_log.op_param2 = 0;
	strncpy(op_log.op_status,"failed",strlen("failed"));
	strcpy(op_log.user_name, "cloud");
    strcpy(op_log.op_type,"远程升级");
    if(firmware_update->result == 0)
    {
        strcpy(op_log.op_status,"success");
    }
    else
    {
        strcpy(op_log.op_status,"failed");
    }
    add_one_op_log(&op_log);
}




/**
 * @brief   升级信息清除
 * @note
 * @return
 */
static void sofar_ota_info_clear(void)
{
    firmware_update_t *firmware_update = sdk_shm_update_data_get();

    memset(&g_sofar_ota_info, 0, sizeof(sofar_ota_info_t));
    memset(&g_sofar_safety_upgrade_info, 0, sizeof(sofar_ota_info_t));
    memset(&g_package_V02, 0, sizeof(package_signing_msg_V02_t));
    memset(&g_sofar_firmware_update, 0, sizeof(sofar_firmware_update_t));
    firmware_update->remote_ota_flag = 0;
    g_crc32 = 0xFFFFFFFF;
    //清除升级文件
    sdk_system_cmd((int8_t *)"rm -rf /user/update/*");
    sdk_system_cmd((int8_t *)"rm -rf /tmp/*.sofar");
    sdk_system_cmd((int8_t *)"mount -o remount,ro /");

    firmware_update->result = -1;
    upgrade_log();
}

/**
 * @brief   升级响应
 * @param   [in] ota_result：升级结果
 * @param   [in] ota_process：升级进度
 * @param   [in] p_error：异常码
 * @note
 * @return
 */
static void sofar_ota_status_response(uint8_t ota_result, uint8_t ota_process, char *p_error)
{
    cJSON *p_root = NULL;
    char *p = NULL;

    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        SOFAR_OTA_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "requestId", g_sofar_ota_info.request_id);
    cJSON_AddStringToObject(p_root, "nodeId", p_mqtt_cfg->dev_sn.csu_sn);
    cJSON_AddNumberToObject(p_root, "result", ota_result);
    cJSON_AddNumberToObject(p_root, "process", ota_process);
    if(p_error)
    {
        cJSON_AddStringToObject(p_root, "code", p_error);
    }

    p = cJSON_PrintUnformatted(p_root);
    cJSON_Delete(p_root);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.ota_ack_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    free(p);  
}


/**
 * @brief   升级文件下载
 * @param   [in] url：远程文件文件路径
 * @param   [in] p_filename：本地文件存储路径
 * @note
 * @return
 */
static uint8_t sofar_download_file(const char *p_url, const char *p_filename) 
{
    CURL *p_curl = NULL;
    FILE *p_fp = NULL;
    CURLcode res = CURLE_OK;
    curl_global_init(CURL_GLOBAL_DEFAULT); 
    p_curl = curl_easy_init();
    p_fp = fopen(p_filename, "w");
    SOFAR_OTA_DEBUG_PRINT((int8_t *)"curl version:%s\n", curl_version());
    if(p_curl && p_fp) 
    {
        // 设置下载选项
        curl_easy_setopt(p_curl, CURLOPT_POST, 0);
        curl_easy_setopt(p_curl, CURLOPT_URL, p_url);
        curl_easy_setopt(p_curl, CURLOPT_WRITEDATA, p_fp);
        curl_easy_setopt(p_curl, CURLOPT_USERAGENT, "PostmanRuntime/7.37.3");
        curl_easy_setopt(p_curl, CURLOPT_SSL_VERIFYHOST, 0);
	    curl_easy_setopt(p_curl, CURLOPT_SSL_VERIFYPEER, 0);
        // 执行下载请求
        res = curl_easy_perform(p_curl);
        if (res != CURLE_OK) 
        {
            SOFAR_OTA_DEBUG_PRINT((int8_t *)"error: %s\n", curl_easy_strerror(res));
            fclose(p_fp);
            curl_easy_cleanup(p_curl);
            return OPT_FAILED;
        }
        fclose(p_fp);
    } 
    else 
    {
        SOFAR_OTA_DEBUG_PRINT((int8_t *)"init error\n");
        if(p_fp)
        {
            fclose(p_fp);
        }
        if(p_curl) 
        {
            curl_easy_cleanup(p_curl);
        }
        return OPT_FAILED;
    }

    curl_easy_cleanup(p_curl);
    return OPT_SUCCESS;
}


/**
 * @brief   获取文件长度
 * @param   [in] path:文件路径
 * @note
 * @return
 */
uint64_t file_get_size(const char *path)
{
    uint64_t filesize = -1;
    struct stat statbuff;
    if (stat((char *)path, &statbuff) < 0)
    {
        return filesize;
    }
    else
    {
        filesize = statbuff.st_size;
    }
    return filesize;
}


/**
 * @brief   升级文件CRC32校验
 * @param   [in] path：本地文件存储路径
 * @param   [in] length：长度
 * @note
 * @return
 */
uint32_t firmware_check(const int8_t *path, uint64_t length)
{
    // uint32_t crc32 = 0xFFFFFFFF;
    uint32_t i = 0;
    uint32_t check_value;
    uint8_t data[DATA_LENGTH + 26] = {0};

    FILE *fp = NULL;
    if ((fp = fopen((char *)path, "r")) == NULL)
    {
        return 1;
    }

    for (i = 0; i < (length >> 10) + 1; i++) // length>>10 <==> length/1024; 注意：打印uint64_t的数值时要用%llu
    {
        memset(data, 0, sizeof(data));

        if (i == (length >> 10)) // 最后一包
        {
            if (fread(data, length & 0x3FF, 1, fp) != 1) // length&0x3FF <==> length%1024; 注意：打印uint64_t的数值时要用%llu
            {
                fclose(fp);
                return 1;
            }
            update_check_crc32(data, length & 0x3FF); // 减去签名信息中CRC32字段
        }
        else
        {
            if (fread(data, DATA_LENGTH, 1, fp) != 1)
            {
                fclose(fp);
                return 1;
            }
            update_check_crc32(data, DATA_LENGTH);
        }
    }

    fclose(fp);

    return check_value = ~g_crc32;
}

/**
 * @brief  : 拷贝对象简称
 * @param   [in] file_type 文件类型
 * @param   [in] chip_role 芯片角色
 * @param   [in] *p_object 对象字符
 * @return  0:正常
 */
static uint16_t update_obj_cpy(uint8_t file_type, uint8_t chip_role, int8_t *p_object)
{
  uint8_t i = 0;

  // 匹配文件类型编码与芯片角色编码，新旧编码进行匹配，用于兼容旧编码
  for (i = 0; i < UPDATE_OBJECT_NUM; i++)
  {
    // 新格式芯片角色编码 芯片角色编码一致
    if ((file_type == g_role_coding_new[i].file_number)
        && (chip_role == g_role_coding_new[i].obj_number))
    {
      memcpy((char *)p_object, (char *)g_role_coding_new[i].module_object,sizeof(g_role_coding_new[i].module_object));
	  p_object[8] = '\0';
      return true;
    }
  }

  return false;
}


/**
 * @brief   升级文件校验
 * @param   [in] p_filename：本地文件存储路径
 * @note
 * @return
 */
static uint8_t sofar_vertificate_file(const char *p_filename) 
{
    int8_t data[SIGNING_MSG_LENGTH] = {0};
    uint32_t package_crc32_count = 0xFFFFFFFF;
    uint64_t file_length = 0;

    file_length = file_get_size(p_filename);
    // 提取固件包签名信息
    FILE *fp = NULL;
    if ((fp = fopen((char *)p_filename, "rb")) == NULL)
    {
        return false;
    }
    if (fseek(fp, file_length - SIGNING_MSG_LENGTH, SEEK_SET) != 0)
    {
        fclose(fp);
        return false;
    }
    if (fread(data, SIGNING_MSG_LENGTH, 1, fp) != 1)
    {
        fclose(fp);
        return false;
    }
    fclose(fp);

    package_crc32_count = firmware_check((int8_t *)p_filename, file_length - 4); // 获取固件包的CRC32

    memcpy(&g_package_V02, data, SIGNING_MSG_LENGTH);

    // 校验固件包的长度
    if (g_package_V02.package_length != file_length - SIGNING_MSG_LENGTH)
    {
        return false;
    }
    // 校验固件包的CRC32
    if (g_package_V02.package_crc32 != package_crc32_count)
    {
        return false;
    }

    // 校验机型,见《嵌入式软件打包工具签名详细信息》
    if (ESS3M44 != g_package_V02.product_type_code || MODEL_ESS3M44 != g_package_V02.product_model_code)
    {
        SOFAR_OTA_DEBUG_PRINT((int8_t *)"dev model error");
        return false;
    }
    return true;
}


/**
 * @brief   升级文件提取
 * @param   [in] p_filename：本地文件存储路径
 * @note
 * @return
 */
static uint8_t sofar_extrct_file(const char *p_filename) 
{
    int32_t i = 0;
    uint8_t module_total = 0;
    
    module_total = g_package_V02.module_total;

    for (i = 0; i < module_total; i++)
    {
        strncpy((char *)g_sofar_firmware_update.module_name[i], (char *)g_package_V02.firmware_msg[i].name, sizeof(g_sofar_firmware_update.module_name[i]) - 1);
        g_sofar_firmware_update.file_type[i] = g_package_V02.firmware_msg[i].file_type;
        g_sofar_firmware_update.chip_role[i] = g_package_V02.firmware_msg[i].chip_role;
        update_obj_cpy(g_sofar_firmware_update.file_type[i], g_sofar_firmware_update.chip_role[i], (int8_t *)g_sofar_firmware_update.module_object[i]);


        SOFAR_OTA_DEBUG_PRINT((int8_t *)" g_sofar_firmware_update.module_name[%x] = %s \n", i, g_sofar_firmware_update.module_name[i]);
        SOFAR_OTA_DEBUG_PRINT((int8_t *)" g_sofar_firmware_update.module_object[%x] = %s \n", i, g_sofar_firmware_update.module_object[i]);
        SOFAR_OTA_DEBUG_PRINT((int8_t *)" g_sofar_firmware_update.file_type[%x] = %x \n", i, g_sofar_firmware_update.file_type[i]);
        SOFAR_OTA_DEBUG_PRINT((int8_t *)" g_sofar_firmware_update.chip_role[%x] = %x \n", i, g_sofar_firmware_update.chip_role[i]);
    }

    g_sofar_firmware_update.module_total = module_total;
    SOFAR_OTA_DEBUG_PRINT((int8_t *)"dev total = %d", g_sofar_firmware_update.module_total);
    return OPT_SUCCESS;
}

/**
 * @brief   启动升级
 * @note
 * @return
 */
static uint8_t sofar_ota_start(void) 
{
    uint8_t i = 0;
    int ret = 0;
    uint8_t cmu_ota_flag = 0;
    uint8_t retry_times = 0;

    firmware_update_t *p_update = sdk_shm_update_data_get();
    for (i = 0; i < UPDATE_OBJECT_NUM; ++i)
    {
        p_update->chip_role[i] = 0;
        p_update->module_percent[i] = 0;
    }
    snprintf((char *)p_update->package_name, 52, "%s", FILE_NAME);
    snprintf((char *)p_update->root_path , 32, "%s", "/tmp/");

    //对固件信息进行检查
    for(uint8_t i = 0; i < UPDATE_OBJECT_NUM; i++)
    {
        //是否存在CSU升级
        if(!strcmp(g_sofar_firmware_update.module_object[i], "CSU-MCU1"))
        {
            BIT_SET(p_update->module_update_flag, 0);
            p_update->state = 2;
        }
        if(!strcmp(g_sofar_firmware_update.module_object[i], "CSU-MCU2"))
        {
            BIT_SET(p_update->module_update_flag, 1);
            p_update->state = 2;
        }    
        //是否存在CMU升级，如果存在则进行升级列表下发&升级文件下发
        if((!strcmp(g_sofar_firmware_update.module_object[i], "CMU-MCU1")) ||
           (!strcmp(g_sofar_firmware_update.module_object[i], "CMU-MCU2")) ||
           (!strcmp(g_sofar_firmware_update.module_object[i], "PCS-M"))    ||
           (!strcmp(g_sofar_firmware_update.module_object[i], "PCS-S")))
        {
            cmu_ota_flag = 1;
        }
    }
    if(cmu_ota_flag)
    {
        while (retry_times < 3)
        {
            ret = sofar_cmu_ota_devlist_file_upload();
            if(ret == OPT_SUCCESS)
            {
                break;
            }
            else
            {
                sleep(2);
                retry_times++;
            }
        }
        return ret;
    }
    return OPT_SUCCESS; 
}


/**
 * @brief   监测升级进度
 * @note
 * @return 
 */
static uint8_t sofar_ota_progress_monitor(uint8_t *p_percent) 
{
    uint8_t i = 0;
    uint16_t total_percent = 0;

    firmware_update_t *p_update = sdk_shm_update_data_get();

    SOFAR_OTA_DEBUG_PRINT((int8_t *)"*******************************************");
    for (i = 0; i < UPDATE_OBJECT_NUM; ++i)
    {
        // SOFAR_OTA_DEBUG_PRINT((int8_t *)"chip_role[%d] %d", i, p_update->chip_role[i]);
        if (p_update->chip_role[i] == CSU_MCU1_NUM)
        {
            SOFAR_OTA_DEBUG_PRINT((int8_t *)"csu-mcu1 module_percent[%d] %d", i, p_update->module_percent[i]);
            total_percent += p_update->module_percent[i];
        }
        if (p_update->chip_role[i] == CSU_MCU2_NUM)
        {
            SOFAR_OTA_DEBUG_PRINT((int8_t *)"csu-mcu2 module_percent[%d] %d", i, p_update->module_percent[i]);
            total_percent += p_update->module_percent[i];
        }
        if (p_update->chip_role[i] == CMU_MCU1_NUM)
        {
            SOFAR_OTA_DEBUG_PRINT((int8_t *)"cmu-mcu1 module_percent[%d] %d", i, p_update->dev_cmu_update[0].module_percent[i]);
            total_percent += p_update->dev_cmu_update[0].module_percent[i];
        }
        if (p_update->chip_role[i] == CMU_MCU2_NUM)
        {
            SOFAR_OTA_DEBUG_PRINT((int8_t *)"cmu-mcu2 module_percent[%d] %d", i, p_update->dev_cmu_update[0].module_percent[i]);
            total_percent += p_update->dev_cmu_update[0].module_percent[i];
        }
        if (p_update->chip_role[i] == PCS_M_NUM)
        {
            SOFAR_OTA_DEBUG_PRINT((int8_t *)"pcs master module_percent[%d] %d", i, p_update->dev_cmu_update[0].module_percent[i]);
            total_percent += p_update->dev_cmu_update[0].module_percent[i];
        }
        if (p_update->chip_role[i] == PCS_S_NUM)
        {
            SOFAR_OTA_DEBUG_PRINT((int8_t *)"pcs slave module_percent[%d] %d", i, p_update->dev_cmu_update[0].module_percent[i]);
            total_percent += p_update->dev_cmu_update[0].module_percent[i];
        }
    }	

    // for(i = 0; i < UPDATE_OBJECT_NUM; i++)
    // {
    //     total_percent += p_update->module_percent[i];
    // }
    *p_percent = total_percent / g_sofar_firmware_update.module_total;
    if(*p_percent == 100)
    {
        return OPT_SUCCESS;
    }
    g_sofar_ota_info.ota_tick_cnt++;
    if(g_sofar_ota_info.ota_tick_cnt > OTA_TIMEOUT_SEC)
    {
        return OPT_TIMEOUT;
    }
	// SOFAR_OTA_DEBUG_PRINT((int8_t *)"total_percent %d%%", *p_percent);
    return OPT_RUNNING;
}


/**
 * @brief   升级结束处理
 * @note
 * @return 
 */
static void sofar_ota_done_handle(void) 
{
    upgrade_log();
    sdk_system_cmd((int8_t *)"rm -rf /user/update/*");
    sdk_system_cmd((int8_t *)"rm -rf /tmp/*.sofar");
    sdk_system_cmd((int8_t *)"mount -o remount,ro /");

    system("sync");
    sleep(5);
    system("reboot -f");
}

/**
 * @brief   判断是否允许升级
 * @note
 * @return 
 */
static uint8_t sys_ota_is_allow(void) 
{
    telemetry_data_t *p_telemetry_data = NULL;

    p_telemetry_data = sdk_shm_telemetry_data_get();
    if((p_telemetry_data->sys_version_telemetry_info.csu_sys_state != 1) && (p_telemetry_data->sys_version_telemetry_info.csu_sys_state != 2))
    {
        return OPT_SUCCESS;
    }
    return OPT_FAILED;
}


/**
 * @brief   http升级文件下载服务线程
 * @param   [in] arg
 * @note
 * @return
 */
static void *sofar_ota_service(void *arg)
{
    int ret = 0;
    uint8_t ota_percent = 0;
    static uint8_t sec_cnt = 0;
    firmware_update_t *p_update = sdk_shm_update_data_get();

	while(1)
	{
        switch (g_sofar_ota_info.ota_status)
        {
            case OTA_NONE:
                sec_cnt = 0;
                ota_percent = 0;
                break;

            case OTA_FILE_DOWNLOAD:
                //判断系统状态，如处于运行状态则不允许升级
                if(!sys_ota_is_allow())
                {
                    sofar_ota_status_response(OTA_UPGRADE_FAIL, 0, FILE_TASK_CONFLICT);
                    SOFAR_OTA_DEBUG_PRINT((int8_t *)"sys status is running");
                    sofar_ota_info_clear();  
                    break;                  
                }
                p_update->remote_ota_flag = 1;
                ret = sofar_download_file(g_sofar_ota_info.http_file_url, SOFAR_OTA_FILE_NAME);
                if(ret == OPT_SUCCESS)
                {
                    sofar_ota_status_response(OTA_UPGRADING, 0, FILE_DOWNLOAD_SUCCESS);
                    g_sofar_ota_info.ota_status = OTA_FILE_VERTICATE;
                    SOFAR_OTA_DEBUG_PRINT((int8_t *)"file download success");
                }
                else
                {
                    sofar_ota_status_response(OTA_UPGRADE_FAIL, 0, FILE_DOWNLOAD_FAIL);
                    SOFAR_OTA_DEBUG_PRINT((int8_t *)"file download fail");
                    sofar_ota_info_clear();
                }
                break;

            case OTA_FILE_VERTICATE:
                ret = sofar_vertificate_file(SOFAR_OTA_FILE_NAME);
                if(ret == OPT_SUCCESS)
                {
                    sofar_ota_status_response(OTA_UPGRADING, 0, FILE_VERTICATION_SUCCESS);
                    g_sofar_ota_info.ota_status = OTA_FILE_EXTRAC;
                    SOFAR_OTA_DEBUG_PRINT((int8_t *)"file verticate success");
                }
                else
                {
                    sofar_ota_status_response(OTA_UPGRADE_FAIL, 0, FILE_VERTICATION_FAIL);
                    SOFAR_OTA_DEBUG_PRINT((int8_t *)"file verticate fail");
                    sofar_ota_info_clear();
                }
                break;

            case OTA_FILE_EXTRAC:
                ret = sofar_extrct_file(SOFAR_OTA_FILE_NAME);
                if(ret == OPT_SUCCESS)
                {
                    g_sofar_ota_info.ota_status = OTA_UPGRADE;
                    SOFAR_OTA_DEBUG_PRINT((int8_t *)"file extrct success");
                }
                else
                {
                    sofar_ota_status_response(OTA_UPGRADE_FAIL, 0, FILE_VERTICATION_FAIL);
                    SOFAR_OTA_DEBUG_PRINT((int8_t *)"file extrct fail");
                    sofar_ota_info_clear();
                }
                break;

            case OTA_UPGRADE:
                //判断系统状态，如处于运行状态则不允许升级
                if(!sys_ota_is_allow())
                {
                    sofar_ota_status_response(OTA_UPGRADE_FAIL, 0, FILE_TASK_CONFLICT);
                    SOFAR_OTA_DEBUG_PRINT((int8_t *)"sys status is running");
                    sofar_ota_info_clear();  
                    break;                  
                }
                ret = sofar_ota_start();
                if(ret == OPT_SUCCESS)
                {
                    g_sofar_ota_info.ota_status = OTA_UPGRADE_MONITOR;
                    sofar_ota_status_response(OTA_UPGRADING, 0, FILE_TRANSMISSION_SUCCESS);
                    SOFAR_OTA_DEBUG_PRINT((int8_t *)"ota start success");
                }
                else
                {
                    sofar_ota_status_response(OTA_UPGRADE_FAIL, 0, FILE_TRANSMISSION_FAIL);
                    SOFAR_OTA_DEBUG_PRINT((int8_t *)"ota start fail");
                    sofar_ota_info_clear();
                }
                break;

            case OTA_UPGRADE_MONITOR:
                ret = sofar_ota_progress_monitor(&ota_percent);
                if(ret == OPT_SUCCESS)
                {
                    g_sofar_ota_info.ota_status = OTA_UPGRADE_DONE;
                    sofar_ota_status_response(OTA_UPGRADE_SUCCESS, ota_percent, FILE_UPGRADING_SUCCESS);
                    SOFAR_OTA_DEBUG_PRINT((int8_t *)"file upgrade success");
                }
                else if(ret == OPT_TIMEOUT)
                {
                    sofar_ota_status_response(OTA_UPGRADE_FAIL, ota_percent, FILE_TIMEOUT);
                    SOFAR_OTA_DEBUG_PRINT((int8_t *)"file upgrade timeout");
                    sofar_ota_info_clear();
                }
                else if(ret == OPT_FAILED)
                {
                    sofar_ota_status_response(OTA_UPGRADE_FAIL, ota_percent, FILE_UPGRADING_FAIL);
                    SOFAR_OTA_DEBUG_PRINT((int8_t *)"file upgrade fail");
                    sofar_ota_info_clear();
                }
                else
                {
                    sec_cnt++;
                    if(sec_cnt % 3 == 0)
                    {
                        sofar_ota_status_response(OTA_UPGRADING, ota_percent, NULL);
                        sec_cnt = 0;
                    }
                }
                break;
            
            case OTA_UPGRADE_DONE:
                sofar_ota_done_handle();
                break;
            
            default:
                break;
        }
		usleep(1000 * 1000);
	}

    return NULL;
}


/**
 * @brief   安规升级响应
 * @param   [in] ota_result：升级结果
 * @param   [in] ota_process：升级进度
 * @param   [in] p_error：异常码
 * @note
 * @return
 */
static void sofar_safety_upgrade_status_response(uint8_t ota_result, uint8_t ota_process, char *p_error)
{
    cJSON *p_root = NULL;
    char *p = NULL;

    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        SOFAR_OTA_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "requestId", g_sofar_safety_upgrade_info.request_id);
    cJSON_AddStringToObject(p_root, "nodeId", p_mqtt_cfg->dev_sn.csu_sn);
    cJSON_AddNumberToObject(p_root, "result", ota_result);
    cJSON_AddNumberToObject(p_root, "process", ota_process);
    if(p_error)
    {
        cJSON_AddStringToObject(p_root, "code", p_error);
    }

    p = cJSON_PrintUnformatted(p_root);
    cJSON_Delete(p_root);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.ota_ack_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    free(p);  
}



/**
 * @brief   安规文件升级结束处理
 * @note
 * @return 
 */
static void sofar_safety_upgrade_done_handle(void) 
{
    //这里直接给升级成功标识，进度100%
    sofar_safety_upgrade_status_response(OTA_UPGRADE_SUCCESS, 100, FILE_UPGRADING_SUCCESS);

    memset(&g_sofar_safety_upgrade_info, 0, sizeof(sofar_ota_info_t));

    sdk_system_cmd((int8_t *)"rm -rf /tmp/*.sofar");

}


/**
 * @brief   安规升级服务线程
 * @param   [in] arg
 * @note
 * @return
 */
static void *sofar_safety_upgrade_service(void *arg)
{
    int ret = 0;

	while(1)
	{
        switch (g_sofar_safety_upgrade_info.ota_status)
        {
            case OTA_NONE:
                break;

            case OTA_FILE_DOWNLOAD:
                ret = sofar_download_file(g_sofar_safety_upgrade_info.http_file_url, SOFAR_SAFETY_FILE_NAME);
                if(ret == OPT_SUCCESS)
                {
                    sofar_safety_upgrade_status_response(OTA_UPGRADING, 0, FILE_DOWNLOAD_SUCCESS);
                    g_sofar_safety_upgrade_info.ota_status = OTA_UPGRADE;
                    SOFAR_OTA_DEBUG_PRINT((int8_t *)"file download success");
                }
                else
                {
                    sofar_safety_upgrade_status_response(OTA_UPGRADE_FAIL, 0, FILE_DOWNLOAD_FAIL);
                    SOFAR_OTA_DEBUG_PRINT((int8_t *)"file download fail");
                    sofar_ota_info_clear();
                }
                break;

            case OTA_UPGRADE:
                ret = cmu_safety_upgrade_packet_trans(1);
                if(ret == OPT_SUCCESS)
                {
                    g_sofar_safety_upgrade_info.ota_status = OTA_UPGRADE_DONE;
                    sofar_safety_upgrade_status_response(OTA_UPGRADING, 0, FILE_TRANSMISSION_SUCCESS);
                    SOFAR_OTA_DEBUG_PRINT((int8_t *)"ota start success");
                }
                else
                {
                    sofar_safety_upgrade_status_response(OTA_UPGRADE_FAIL, 0, FILE_TRANSMISSION_FAIL);
                    SOFAR_OTA_DEBUG_PRINT((int8_t *)"ota start fail");
                    sofar_ota_info_clear();
                }
                break;
            
            case OTA_UPGRADE_DONE:
                sofar_safety_upgrade_done_handle();
                break;
            
            default:
                break;
        }
		usleep(1000 * 1000);
	}

    return NULL;
}



/**
 * @brief   升级服务模块初始化
 * @param
 * @note
 * @return
 */
void sofar_ota_module_init(void)
{
	
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

    //软件升级
    pthread_t http_download;
	if(pthread_create(&http_download, &attr, sofar_ota_service, NULL) != 0)
	{
		perror("pthread_create http download service");
	}

    //安规升级
    pthread_t safety_upgrade;
	if(pthread_create(&safety_upgrade, &attr, sofar_safety_upgrade_service, NULL) != 0)
	{
		perror("pthread_create http download service");
	}

	pthread_attr_destroy(&attr);
}

