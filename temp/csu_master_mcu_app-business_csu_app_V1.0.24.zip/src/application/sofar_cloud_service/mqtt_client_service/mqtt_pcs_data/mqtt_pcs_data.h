#ifndef __MQTT_PCS_DATA_H__
#define __MQTT_PCS_DATA_H__

#include "mongoose.h"


/**
 * @brief   PCS事件列表初始化
 * @param
 * @note
 * @return
 */
void pcs_event_list_init(void);


/**
 * @brief   PCS事件全量上报
 * @param
 * @note
 * @return
 */
void pcs_event_list_upload(void);

/**
 * @brief   PCS事件数据上报
 * @param
 * @note
 * @return
 */
void pcs_event_data_upload(void);


/**
 * @brief   PCS属性数据上报
 * @param
 * @note
 * @return
 */
void pcs_property_data_upload(void);

/**
 * @brief   PCS监控数据上报
 * @param
 * @note
 * @return
 */
void pcs_monitor_data_upload(void);


#endif