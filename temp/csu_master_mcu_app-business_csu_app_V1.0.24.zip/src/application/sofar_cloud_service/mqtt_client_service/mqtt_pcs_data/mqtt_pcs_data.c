#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include "sofar_log.h"
#include "sofar_errors.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk_public.h"
#include "mongoose.h"
#include "mosquitto.h"
#include "cJSON.h"
#include "mqtt_client_service.h"

static pcs_property_data_t g_property_data = {0};
static pcs_event_data_t g_event_data[PCS_MAX_EVENT_ITEM] = {0};

/**
 * @brief   PCS事件列表初始化
 * @param
 * @note
 * @return
 */
void pcs_event_list_init(void)
{
    for(uint8_t i = 0; i < PCS_MAX_EVENT_ITEM; i++)
    {
        g_event_data[i].event_code = 1;
    }
}


/**
 * @brief   PCS事件全量上报
 * @param
 * @note
 * @return
 */
void pcs_event_list_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    char *p = NULL;
    char str[10] = {0};
    static int upload_tick_cnt = 0;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();

    //上报计时，对精确度要求不高
    if(upload_tick_cnt < MQTT_EVENT_LIST_UPLOAD_TIME_INTERVAL)
    {
        upload_tick_cnt++;
        return;
    }
    
    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    if(p_energy_cabinet_data == NULL)
    {
        return;
    }

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_energy_cabinet_data->cmu_data.sign_data.pcs_sn);
    cJSON_AddStringToObject(p_root, "product", "pcs");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }

    for(uint8_t i = 0; i < PCS_MAX_EVENT_ITEM; i++)
    {
        p_data_item = cJSON_CreateObject();
        if(p_data_item == NULL)
        {
            MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
            cJSON_Delete(p_root);
            return;
        }
        
        sprintf(str, "%d", p_energy_cabinet_data->pcs_data.event_data[i].event_id);
        cJSON_AddStringToObject(p_data_item, "eventId", str);
        sprintf(str, "%d", p_energy_cabinet_data->pcs_data.event_data[i].event_code);
        cJSON_AddStringToObject(p_data_item, "status", str);
        sprintf(str, "%d", p_energy_cabinet_data->pcs_data.event_data[i].event_level);
        cJSON_AddStringToObject(p_data_item, "type", str);
        cJSON_AddNumberToObject(p_data_item, "eventTime", get_sys_timestamp());
        cJSON_AddItemToArray(p_data_array,  p_data_item);
        memcpy(&g_event_data[i], &p_energy_cabinet_data->pcs_data.event_data[i], sizeof(pcs_event_data_t));
    }

    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.event_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    free(p);
    upload_tick_cnt = 0;
}


/**
 * @brief   PCS事件数据上报
 * @param
 * @note
 * @return
 */
void pcs_event_data_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    char *p = NULL;
    uint8_t upload_flag = 0;
    char str[10] = {0};
    char date[32] = {0};
    sdk_rtc_t rtc_time = {0};
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
    
    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    if(p_energy_cabinet_data == NULL)
    {
        return;
    }

    //获取系统时钟时间
    if (sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time) != SF_OK)
    {
        MQTT_DEBUG_PRINT((int8_t *)"rtc get failed");
    }
    
    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    sprintf(date, "%04d-%02d-%02d %02d:%02d:%02d", rtc_time.tm_year + 2000, rtc_time.tm_mon, rtc_time.tm_day,
                                                   rtc_time.tm_hour, rtc_time.tm_min, rtc_time.tm_sec);

    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_energy_cabinet_data->cmu_data.sign_data.pcs_sn);
    cJSON_AddStringToObject(p_root, "product", "pcs");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());
    cJSON_AddStringToObject(p_root, "date", date);

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }

    for(uint8_t i = 0; i < PCS_MAX_EVENT_ITEM; i++)
    {
        if(g_event_data[i].event_code != p_energy_cabinet_data->pcs_data.event_data[i].event_code)
        {
            p_data_item = cJSON_CreateObject();
            if(p_data_item == NULL)
            {
                MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
                cJSON_Delete(p_root);
                return;
            }
            
            sprintf(str, "%d", p_energy_cabinet_data->pcs_data.event_data[i].event_id);
            cJSON_AddStringToObject(p_data_item, "eventId", str);
            sprintf(str, "%d", p_energy_cabinet_data->pcs_data.event_data[i].event_code);
            cJSON_AddStringToObject(p_data_item, "status", str);
            sprintf(str, "%d", p_energy_cabinet_data->pcs_data.event_data[i].event_level);
            cJSON_AddStringToObject(p_data_item, "type", str);
            cJSON_AddNumberToObject(p_data_item, "eventTime", p_energy_cabinet_data->pcs_data.event_data[i].event_time);
            cJSON_AddItemToArray(p_data_array,  p_data_item);
            memcpy(&g_event_data[i], &p_energy_cabinet_data->pcs_data.event_data[i], sizeof(pcs_event_data_t));
            upload_flag = 1;
        }
    }

    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);
    if(upload_flag)
    {
        mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.event_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    }
    free(p);
}


/**
 * @brief   PCS属性数据上报
 * @param
 * @note
 * @return
 */
void pcs_property_data_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    cJSON *p_base_config = NULL;
    char *p = NULL;
    static uint8_t all_data_upload_flag = 1;
    uint8_t upload_flag = 0;
    static uint16_t upload_tick_cnt = 0;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
    
    //上报计时，对精确度要求不高
    if(upload_tick_cnt < MQTT_PROPERTY_UPLOAD_TIME_INTERVAL)
    {
        upload_tick_cnt++;
    }
    else
    {
        all_data_upload_flag = 1;
        upload_tick_cnt = 0;
    } 

    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    if(p_energy_cabinet_data == NULL)
    {
        return;
    }
    
    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }
    cJSON_AddStringToObject(p_root, "model", (char *)p_energy_cabinet_data->pcs_data.property_data.pcs_model);
    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_energy_cabinet_data->pcs_data.property_data.pcs_sn);
    cJSON_AddStringToObject(p_root, "product", "pcs");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_base_config = cJSON_CreateObject();
    if(p_base_config == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    //SN
    if((strcmp((char *)g_property_data.pcs_sn, (char *)p_energy_cabinet_data->pcs_data.property_data.pcs_sn)) || all_data_upload_flag)
    {
        cJSON_AddStringToObject(p_base_config, "pcs$sn", (char *)p_energy_cabinet_data->pcs_data.property_data.pcs_sn);
        strcpy((char *)g_property_data.pcs_sn, (char *)p_energy_cabinet_data->pcs_data.property_data.pcs_sn);
        upload_flag = 1;
    }
    //主DSP版本号
    if((strcmp((char *)g_property_data.mdsp_version, (char *)p_energy_cabinet_data->pcs_data.property_data.mdsp_version)) || all_data_upload_flag)
    {
        cJSON_AddStringToObject(p_base_config, "pcs$mDSPversion", (char *)p_energy_cabinet_data->pcs_data.property_data.mdsp_version);
        strcpy((char *)g_property_data.mdsp_version, (char *)p_energy_cabinet_data->pcs_data.property_data.mdsp_version);
        upload_flag = 1;
    }
    //负DSP版本号
    if((strcmp((char *)g_property_data.ldsp_version, (char *)p_energy_cabinet_data->pcs_data.property_data.ldsp_version)) || all_data_upload_flag)
    {
        cJSON_AddStringToObject(p_base_config, "pcs$lDSPversion", (char *)p_energy_cabinet_data->pcs_data.property_data.ldsp_version);
        strcpy((char *)g_property_data.ldsp_version, (char *)p_energy_cabinet_data->pcs_data.property_data.ldsp_version);
        upload_flag = 1;
    }
    //设备类型
    if((g_property_data.dev_type != p_energy_cabinet_data->pcs_data.property_data.dev_type) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "pcs$devType", p_energy_cabinet_data->pcs_data.property_data.dev_type);
        g_property_data.dev_type = p_energy_cabinet_data->pcs_data.property_data.dev_type;
        upload_flag = 1;
    }
    //额定功率
    if((g_property_data.rated_power != p_energy_cabinet_data->pcs_data.property_data.rated_power) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "pcs$ratedPower", p_energy_cabinet_data->pcs_data.property_data.rated_power);
        g_property_data.rated_power = p_energy_cabinet_data->pcs_data.property_data.rated_power;
        upload_flag = 1;
    }
    //通讯状态
    if((g_property_data.comm_status != p_energy_cabinet_data->pcs_data.property_data.comm_status) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "pcs$commStatus", p_energy_cabinet_data->pcs_data.property_data.comm_status);
        g_property_data.comm_status = p_energy_cabinet_data->pcs_data.property_data.comm_status;
        upload_flag = 1;
    }
    //系统状态
    if((g_property_data.sys_status != p_energy_cabinet_data->pcs_data.property_data.sys_status) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "pcs$sysStatus", p_energy_cabinet_data->pcs_data.property_data.sys_status);
        g_property_data.sys_status = p_energy_cabinet_data->pcs_data.property_data.sys_status;
        upload_flag = 1;
    }
    //额定电网电压，暂定为400V
    if((g_property_data.rated_voltage != 400) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "pcs$ratedVoltage", 400);
        g_property_data.rated_voltage = 400;
        upload_flag = 1;
    }
    // if((g_property_data.rated_voltage != p_energy_cabinet_data->pcs_data.property_data.rated_voltage) || all_data_upload_flag)
    // {
    //     cJSON_AddNumberToObject(p_base_config, "pcs$ratedVoltage", p_energy_cabinet_data->pcs_data.property_data.rated_voltage);
    //     g_property_data.rated_voltage = p_energy_cabinet_data->pcs_data.property_data.rated_voltage;
    //     upload_flag = 1;
    // }

    p_data_item = cJSON_CreateObject();
    if(p_data_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_base_config);
        return;
    }
    
    cJSON_AddNumberToObject(p_data_item, "dataTime", get_sys_timestamp());
    cJSON_AddItemToObject(p_data_item, "baseConfig", p_base_config);

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_data_item);
        return;
    }
    cJSON_AddItemToArray(p_data_array,  p_data_item);
    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);
    if(upload_flag)
    {
        mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.property_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    }
    all_data_upload_flag = 0;
    free(p);
}


/**
 * @brief   PCS监控数据上报
 * @param
 * @note
 * @return
 */
void pcs_monitor_data_upload(void)
{
    sdk_rtc_t rtc_time;
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    cJSON *p_base_config = NULL;
    char *p = NULL;
    uint32_t temp_date = 0;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;
    char date[32] = {0};
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    if(p_energy_cabinet_data == NULL)
    {
        return;
    }
    
    sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);   
    snprintf(date, 32,"%04d%02d%02d", rtc_time.tm_year + 2000, rtc_time.tm_mon, rtc_time.tm_day);

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }
    cJSON_AddStringToObject(p_root, "model", (char *)p_energy_cabinet_data->pcs_data.property_data.pcs_model);
    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_energy_cabinet_data->cmu_data.sign_data.pcs_sn);
    cJSON_AddStringToObject(p_root, "product", "pcs");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_base_config = cJSON_CreateObject();
    if(p_base_config == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }

    cJSON_AddNumberToObject(p_base_config, "pcs$activePower",   p_energy_cabinet_data->pcs_data.monitor_data.active_power);
    cJSON_AddNumberToObject(p_base_config, "pcs$reactivePower", p_energy_cabinet_data->pcs_data.monitor_data.reactive_power);
    cJSON_AddNumberToObject(p_base_config, "pcs$apparentPower", p_energy_cabinet_data->pcs_data.monitor_data.apparent_power);
    cJSON_AddNumberToObject(p_base_config, "pcs$powerFactor",   p_energy_cabinet_data->pcs_data.monitor_data.power_factor);
    cJSON_AddNumberToObject(p_base_config, "pcs$R_vol", p_energy_cabinet_data->pcs_data.monitor_data.grid_volt_r);
    cJSON_AddNumberToObject(p_base_config, "pcs$S_vol", p_energy_cabinet_data->pcs_data.monitor_data.grid_volt_s);
    cJSON_AddNumberToObject(p_base_config, "pcs$T_vol", p_energy_cabinet_data->pcs_data.monitor_data.grid_volt_t);
    cJSON_AddNumberToObject(p_base_config, "pcs$R_cur", p_energy_cabinet_data->pcs_data.monitor_data.ac_current_r);
    cJSON_AddNumberToObject(p_base_config, "pcs$S_cur", p_energy_cabinet_data->pcs_data.monitor_data.ac_current_s);
    cJSON_AddNumberToObject(p_base_config, "pcs$T_cur", p_energy_cabinet_data->pcs_data.monitor_data.ac_current_t);
    cJSON_AddNumberToObject(p_base_config, "pcs$gridFreq", p_energy_cabinet_data->pcs_data.monitor_data.grid_freq);
    cJSON_AddNumberToObject(p_base_config, "pcs$busVoltPN", p_energy_cabinet_data->pcs_data.monitor_data.bus_volt_pn);
    cJSON_AddNumberToObject(p_base_config, "pcs$posHalfBusVoltPN", p_energy_cabinet_data->pcs_data.monitor_data.bus_volt_p);
    cJSON_AddNumberToObject(p_base_config, "pcs$negHalfBusVoltPN", p_energy_cabinet_data->pcs_data.monitor_data.bus_volt_n);
    cJSON_AddNumberToObject(p_base_config, "pcs$batCurrent", p_energy_cabinet_data->pcs_data.monitor_data.bat_current);
    cJSON_AddNumberToObject(p_base_config, "pcs$batPower", p_energy_cabinet_data->pcs_data.monitor_data.bat_power);
    cJSON_AddNumberToObject(p_base_config, "pcs$energyCharge", p_energy_cabinet_data->pcs_data.monitor_data.total_energy_charge);
    cJSON_AddNumberToObject(p_base_config, "pcs$energyDischarge", p_energy_cabinet_data->pcs_data.monitor_data.total_energy_discharge);
    temp_date = atoi(date);
    cJSON_AddNumberToObject(p_base_config, "pcs$date", temp_date);
    //日期跨天更新，需要保证数据更新
    if(p_energy_cabinet_data->pcs_data.monitor_data.date != temp_date)
    {
        cJSON_AddNumberToObject(p_base_config, "pcs$dayEnergyCharge", 0);
        cJSON_AddNumberToObject(p_base_config, "pcs$dayEnergyDischarge", 0); 
    }
    else
    {
        cJSON_AddNumberToObject(p_base_config, "pcs$dayEnergyCharge", p_energy_cabinet_data->pcs_data.monitor_data.day_energy_charge);
        cJSON_AddNumberToObject(p_base_config, "pcs$dayEnergyDischarge", p_energy_cabinet_data->pcs_data.monitor_data.day_energy_discharge);
    }
    cJSON_AddNumberToObject(p_base_config, "pcs$monEnergyCharge", p_energy_cabinet_data->pcs_data.monitor_data.mon_energy_charge);
    cJSON_AddNumberToObject(p_base_config, "pcs$monEnergyDischarge", p_energy_cabinet_data->pcs_data.monitor_data.mon_energy_discharge);
    cJSON_AddNumberToObject(p_base_config, "pcs$yearEnergyCharge", p_energy_cabinet_data->pcs_data.monitor_data.year_energy_charge);
    cJSON_AddNumberToObject(p_base_config, "pcs$yearEnergyDischarge", p_energy_cabinet_data->pcs_data.monitor_data.year_energy_discharge);
    cJSON_AddNumberToObject(p_base_config, "pcs$tempModule", p_energy_cabinet_data->pcs_data.monitor_data.module_temp);
    cJSON_AddNumberToObject(p_base_config, "pcs$tempAm", p_energy_cabinet_data->pcs_data.monitor_data.am_temp);
    cJSON_AddNumberToObject(p_base_config, "pcs$char", p_energy_cabinet_data->pcs_data.monitor_data.energy_char_avaiable);
    cJSON_AddNumberToObject(p_base_config, "pcs$dischar", p_energy_cabinet_data->pcs_data.monitor_data.energy_dischar_avaiable);
    
    p_data_item = cJSON_CreateObject();
    if(p_data_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_base_config);
        return;
    }
    
    cJSON_AddNumberToObject(p_data_item, "dataTime", get_sys_timestamp());
    cJSON_AddItemToObject(p_data_item, "baseConfig", p_base_config);

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_data_item);
        return;
    }
    cJSON_AddItemToArray(p_data_array,  p_data_item);
    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.monitor_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS0);
    free(p);
}