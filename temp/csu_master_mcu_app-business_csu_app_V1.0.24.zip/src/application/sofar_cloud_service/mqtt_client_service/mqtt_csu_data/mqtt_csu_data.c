#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include "sofar_log.h"
#include "sqlite3.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk_public.h"
#include "mongoose.h"
#include "mosquitto.h"
#include "cJSON.h"
#include "app_common.h"
#include "mqtt_client_service.h"
#include "sofar_ota.h"
#include "mqtt_csu_data.h"
#include "sofar_file_trans.h"

#define MAX_DEBUG_RECV_BUFF_LEN 1024
#define INVALID_POWER   32767

static char *month_name[12] = {"Jan", "Fed", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};

typedef struct
{
    char csu_sn[SN_MAX_LEN];                    //SN
    char csu_version[VERSION_MAX_LEN];          //版本号
    uint8_t comm_status;                        //通讯状态
    uint8_t run_status;                         //运行状态
    uint8_t xj_online_status;                   //小桔在线状态
    uint8_t xj_work_status;                     //小桔工作状态
    uint8_t xj_work_mode;                       //小桔工作模式
}csu_property_data_t;

static csu_property_data_t g_csu_property_data = {0};
static cmu_property_data_t g_property_data = {0};

//功能回调
typedef void (*func_cb)(struct mosquitto *mosq, char *p_payload, int32_t len);
typedef struct
{
    char *p_func;
    func_cb p_func_cb; 
}csu_func_table_t;

static void csu_poweron_set(struct mosquitto *mosq, char *p_payload, int32_t len);
static void csu_poweron_status(struct mosquitto *mosq, char *p_payload, int32_t len);
static void csu_poweroff_set(struct mosquitto *mosq, char *p_payload, int32_t len);
static void csu_poweroff_status(struct mosquitto *mosq, char *p_payload, int32_t len);
static void csu_power_value_set(struct mosquitto *mosq, char *p_payload, int32_t len);
static void csu_power_value_get(struct mosquitto *mosq, char *p_payload, int32_t len);
static void csu_sync_sys_time(struct mosquitto *mosq, char *p_payload, int32_t len);
static void csu_sys_time_info_get(struct mosquitto *mosq, char *p_payload, int32_t len);
static void csu_safety_info_get(struct mosquitto *mosq, char *p_payload, int32_t len);
static void csu_safety_set(struct mosquitto *mosq, char *p_payload, int32_t len);
static void csu_fault_reset(struct mosquitto *mosq, char *p_payload, int32_t len);
static void csu_debug_data_trans(struct mosquitto *mosq, char *p_payload, int32_t len);
static void csu_remote_strategy_set(struct mosquitto *mosq, char *p_payload, int32_t len);
static void csu_remote_strategy_get(struct mosquitto *mosq, char *p_payload, int32_t len);


static csu_func_table_t func_table[] = {
    {"powerOn",         csu_poweron_set},
    {"powerOnStatus",   csu_poweron_status},
    {"powerOff",        csu_poweroff_set},
    {"powerOffStatus",  csu_poweroff_status},
    {"powerSet",        csu_power_value_set},
    {"powerGet",        csu_power_value_get},
    {"sysTimeSync",     csu_sync_sys_time},
    {"sysTimeInfoGet",  csu_sys_time_info_get},
    {"sysSafetyInfoGet",     csu_safety_info_get},
    {"sysSafetySet",    csu_safety_set},
    {"sysFaultReset",   csu_fault_reset},
    {"debugCmd",        csu_debug_data_trans},
    {"remoteStrategySet",    csu_remote_strategy_set},
    {"remoteStrategyGet",    csu_remote_strategy_get},
};


/**
 * @brief   获取时区信息
 * @param [out]p_tz 时区名称
 * @note
 * @return true：成功 false：失败
 */
bool get_local_tz(char *p_tz)
{
    char content[256] = {0};
    cJSON *p_conf = NULL;
    FILE *fp = NULL;
    char *p_timezone = NULL;

    fp = fopen(SYSTIME_JSON_FILE,"r");
    if(fp == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"open json file %s failed.",SYSTIME_JSON_FILE);  
        return false;   
    }
    fread(content, 1, 256, fp);
    fclose(fp);

    p_conf = cJSON_Parse(content);
    if(p_conf == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"parse file %s content failed.",SYSTIME_JSON_FILE);
        return false;
    }

    if(cJSON_GetObjectItem(p_conf, "tz") == NULL)
    {
        cJSON_Delete(p_conf);
        return false;
    }
    p_timezone = cJSON_GetObjectItem(p_conf, "tz")->valuestring;
    strcpy(p_tz, p_timezone);

    cJSON_Delete(p_conf);

    return true;
}


/**
 * @brief   获取每日的电量数据
 * @param   [in]*p_date：日期
 * @param   [out]*p_energy_in：输入
 * @param   [out]*p_energy_out：输出
 * @param   [in]*p_path：路径
 * @param   [in]type：类型
 * @note
 * @return
 */
void get_daily_energy_data_from_db(char *p_date, uint32_t *p_energy_in, uint32_t *p_energy_out, char *p_path, uint8_t type)
{
    sqlite3 *db = NULL;
    sqlite3_stmt *stmt = NULL;
    char sql[256] = {0};
    int rc = 0;

    *p_energy_in = 0;
    *p_energy_out = 0;
   
    rc = sqlite3_open(p_path, &db);
    if(rc) 
    {
       MQTT_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
       return;
    } 
    else 
    {
        if(type == METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%d', date), SUM(charge), SUM(discharge) FROM charge_data WHERE strftime('%%Y-%%m-%%d', date) = '%s';", p_date);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                *p_energy_in = sqlite3_column_double(stmt, 1);
                *p_energy_out = sqlite3_column_double(stmt, 2);
            }
            // MQTT_DEBUG_PRINT((int8_t *)"daily meter-->p_energy_in: %d  p_energy_out: %d", *p_energy_in, *p_energy_out);
            sqlite3_finalize(stmt);
        }
        if(type == PCC_METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%d', date), SUM(int), SUM(out) FROM pcc_energy WHERE strftime('%%Y-%%m-%%d', date) = '%s';", p_date);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                *p_energy_in = sqlite3_column_double(stmt, 1);
                *p_energy_out = sqlite3_column_double(stmt, 2);
            }
            // MQTT_DEBUG_PRINT((int8_t *)"daily pcc-->p_energy_in: %d  p_energy_out: %d", *p_energy_in, *p_energy_out);
            sqlite3_finalize(stmt);
        }
        if(type == PV_METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%d', date), SUM(int) FROM pv_energy WHERE strftime('%%Y-%%m-%%d', date) = '%s';", p_date);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                *p_energy_in = sqlite3_column_double(stmt, 1);
            }
            // MQTT_DEBUG_PRINT((int8_t *)"daily pv-->p_energy_in: %d  p_energy_out: %d", *p_energy_in, *p_energy_out);
            sqlite3_finalize(stmt);
        }
        if(type == LOAD)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%d', date), SUM(out) FROM load_energy WHERE strftime('%%Y-%%m-%%d', date) = '%s';", p_date);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                *p_energy_out = sqlite3_column_double(stmt, 1);
            }
            // MQTT_DEBUG_PRINT((int8_t *)"daily load-->p_energy_in: %d  p_energy_out: %d", *p_energy_in, *p_energy_out);
            sqlite3_finalize(stmt);
        }
    }
    
    sqlite3_close(db);    
    return; 
}


/**
 * @brief   获取总的电量数据
 * @param   [out]*p_energy_in：输入
 * @param   [out]*p_energy_out：输出
 * @param   [in]*p_path：路径
 * @param   [in]type：类型
 * @note
 * @return
 */
void get_total_energy_data_from_db(uint32_t *p_energy_in, uint32_t *p_energy_out, char *p_path, uint8_t type)
{
    sqlite3 *db = NULL;
    sqlite3_stmt *stmt = NULL;
    char sql[256] = {0};
    int rc = 0;

    *p_energy_in = 0;
    *p_energy_out = 0;
   
    rc = sqlite3_open(p_path, &db);
    if(rc) 
    {
       MQTT_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
       return;
    } 
    else 
    {
        if(type == METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime(date), SUM(charge), SUM(discharge) FROM charge_data;");
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW)
            {
                *p_energy_in = sqlite3_column_double(stmt, 1);
                *p_energy_out = sqlite3_column_double(stmt, 2);
            }
            // MQTT_DEBUG_PRINT((int8_t *)"total meter-->p_energy_in: %d  p_energy_out: %d", *p_energy_in, *p_energy_out);
            sqlite3_finalize(stmt);
        }
        if(type == PCC_METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime(date), SUM(int), SUM(out) FROM pcc_energy;");
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                *p_energy_in = sqlite3_column_double(stmt, 1);
                *p_energy_out = sqlite3_column_double(stmt, 2);
            }
            // MQTT_DEBUG_PRINT((int8_t *)"total pcc-->p_energy_in: %d  p_energy_out: %d", *p_energy_in, *p_energy_out);
            sqlite3_finalize(stmt);
        }
        if(type == PV_METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime(date), SUM(int) FROM pv_energy;");
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                *p_energy_in = sqlite3_column_double(stmt, 1);
            }
            // MQTT_DEBUG_PRINT((int8_t *)"total pv-->p_energy_in: %d  p_energy_out: %d", *p_energy_in, *p_energy_out);
            sqlite3_finalize(stmt);
        }
        if(type == LOAD)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime(date), SUM(out) FROM load_energy;");
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                *p_energy_out = sqlite3_column_double(stmt, 1);
            }
            // MQTT_DEBUG_PRINT((int8_t *)"total load-->p_energy_in: %d  p_energy_out: %d", *p_energy_in, *p_energy_out);
            sqlite3_finalize(stmt);
        }
    }
    
    sqlite3_close(db);    
    return; 
}


/**
 * @brief   储能单元属性数据上报
 * @param
 * @note
 * @return
 */
void cmu_property_data_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    cJSON *p_base_config = NULL;
    char *p = NULL;
    static uint8_t all_data_upload_flag = 1;
    uint8_t upload_flag = 0;
    static uint16_t upload_tick_cnt = 0;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();

    //上报计时，对精确度要求不高
    if(upload_tick_cnt < MQTT_PROPERTY_UPLOAD_TIME_INTERVAL)
    {
        upload_tick_cnt++;
    }
    else
    {
        all_data_upload_flag = 1;
        upload_tick_cnt = 0;
    }

    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    if(p_energy_cabinet_data == NULL)
    {
        return;
    }
    
    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_energy_cabinet_data->cmu_data.property_data.cmu_sn);
    cJSON_AddStringToObject(p_root, "product", "cmu");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_base_config = cJSON_CreateObject();
    if(p_base_config == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    //SN
    if((strcmp((char *)g_property_data.cmu_sn, (char *)p_energy_cabinet_data->cmu_data.property_data.cmu_sn)) || all_data_upload_flag)
    {
        cJSON_AddStringToObject(p_base_config, "cmu$sn", (char *)p_energy_cabinet_data->cmu_data.property_data.cmu_sn);
        strcpy((char *)g_property_data.cmu_sn, (char *)p_energy_cabinet_data->cmu_data.property_data.cmu_sn);
        upload_flag = 1;
    }
    //版本号
    if((strcmp((char *)g_property_data.version, (char *)p_energy_cabinet_data->cmu_data.property_data.version)) || all_data_upload_flag)
    {
        cJSON_AddStringToObject(p_base_config, "cmu$version", (char *)p_energy_cabinet_data->cmu_data.property_data.version);
        strcpy((char *)g_property_data.version, (char *)p_energy_cabinet_data->cmu_data.property_data.version);
        upload_flag = 1;
    }
    //安规版本号
    if((strcmp((char *)g_property_data.safe_version, (char *)p_energy_cabinet_data->cmu_data.property_data.safe_version)) || all_data_upload_flag)
    {
        cJSON_AddStringToObject(p_base_config, "cmu$safetyVersion", (char *)p_energy_cabinet_data->cmu_data.property_data.safe_version);
        strcpy((char *)g_property_data.safe_version, (char *)p_energy_cabinet_data->cmu_data.property_data.safe_version);
        upload_flag = 1;
    }
    //通讯状态
    //查询CSU遥信信息判断CMU是否失联
    uint8_t cmu_comm_status = BIT_GET(p_telematic_data->csu_system_fault_info[1], 1);
    if((g_property_data.comm_status != cmu_comm_status) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "cmu$commStatus", !cmu_comm_status);
        g_property_data.comm_status = cmu_comm_status;
        upload_flag = 1;
    }
    //运行状态
    if((g_property_data.run_status != p_energy_cabinet_data->cmu_data.property_data.run_status) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "cmu$runStatus", p_energy_cabinet_data->cmu_data.property_data.run_status);
        g_property_data.run_status = p_energy_cabinet_data->cmu_data.property_data.run_status;
        upload_flag = 1;
    }

    //CSU
    //SN
    telemetry_data_t *p_telemetry_data = NULL;

    p_telemetry_data = sdk_shm_telemetry_data_get();
    cJSON_AddStringToObject(p_base_config, "cmu$csu_sn", (char *)p_telemetry_data->sys_version_telemetry_info.sn_version_number);
    //版本号
    char version_buff[32] = {0};
    internal_version_info_t *p_version_info = NULL;
    
    p_version_info = sdk_shm_internal_version_info_get();
    snprintf(version_buff, sizeof(version_buff), "%c%d.%d.%d", p_version_info->sys_soft_version[0],
	                                                           p_version_info->sys_soft_version[1],
                                                               p_version_info->sys_soft_version[2],
                                                               p_version_info->sys_soft_version[3]);
    cJSON_AddStringToObject(p_base_config, "cmu$csu_version", version_buff);
    cJSON_AddNumberToObject(p_base_config, "cmu$csu_commStatus", p_mqtt_cfg->mqtt_connect_status);
    cJSON_AddNumberToObject(p_base_config, "cmu$csu_runStatus", p_telemetry_data->sys_version_telemetry_info.csu_sys_state);
    cJSON_AddNumberToObject(p_base_config, "cmu$csu_xjOnlineStatus", 0);
    cJSON_AddNumberToObject(p_base_config, "cmu$csu_xjWorkStatus", 0);
    cJSON_AddNumberToObject(p_base_config, "cmu$csu_xjWorkMode", 0);

    //消防
    //消防状态
    cJSON_AddNumberToObject(p_base_config, "cmu$fc_workStatus", p_energy_cabinet_data->fc_data.property_data.work_status);
    //烟感状态
    cJSON_AddNumberToObject(p_base_config, "cmu$fc_sdStatus", p_energy_cabinet_data->fc_data.property_data.sd_status);
    //温感状态
    cJSON_AddNumberToObject(p_base_config, "cmu$fc_tdStatus", p_energy_cabinet_data->fc_data.property_data.td_status);

    //液冷
    //运行模式
    cJSON_AddNumberToObject(p_base_config, "cmu$lc_runMode", p_energy_cabinet_data->lc_data.property_data.work_mode);
    //告警状态
    cJSON_AddNumberToObject(p_base_config, "cmu$lc_warnStatus", p_energy_cabinet_data->lc_data.property_data.warn_status);


    p_data_item = cJSON_CreateObject();
    if(p_data_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_base_config);
        return;
    }
    
    cJSON_AddNumberToObject(p_data_item, "dataTime", get_sys_timestamp());
    cJSON_AddItemToObject(p_data_item, "baseConfig", p_base_config);

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_data_item);
        return;
    }
    cJSON_AddItemToArray(p_data_array,  p_data_item);
    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);

    if(upload_flag)
    {
        mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.property_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    }
    all_data_upload_flag = 0;
    free(p);
}

/**
 * @brief   CSU属性数据上报
 * @param
 * @note
 * @return
 */
void csu_property_data_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    cJSON *p_base_config = NULL;
    char *p = NULL;
    char version_buff[32] = {0};
    static uint8_t all_data_upload_flag = 1;
    uint8_t upload_flag = 0;
    static uint16_t upload_tick_cnt = 0;
    telemetry_data_t *p_telemetry_data = NULL;
    internal_version_info_t *p_version_info = NULL;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
    
    p_version_info = sdk_shm_internal_version_info_get();
    p_telemetry_data = sdk_shm_telemetry_data_get();

    //上报计时，对精确度要求不高
    if(upload_tick_cnt < MQTT_PROPERTY_UPLOAD_TIME_INTERVAL)
    {
        upload_tick_cnt++;
    }
    else
    {
        all_data_upload_flag = 1;
        upload_tick_cnt = 0;
    }
    
    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }
    cJSON_AddStringToObject(p_root, "model", (char *)"ESS433");
    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_mqtt_cfg->dev_sn.csu_sn);
    cJSON_AddStringToObject(p_root, "product", "csu");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_base_config = cJSON_CreateObject();
    if(p_base_config == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    //SN
    if((strcmp(g_csu_property_data.csu_sn, (char *)p_telemetry_data->sys_version_telemetry_info.sn_version_number)) || all_data_upload_flag)
    {
        cJSON_AddStringToObject(p_base_config, "csu$sn", (char *)p_telemetry_data->sys_version_telemetry_info.sn_version_number);
        strcpy(g_csu_property_data.csu_sn, (char *)p_telemetry_data->sys_version_telemetry_info.sn_version_number);
        upload_flag = 1;
    }
    //版本号
    snprintf(version_buff, sizeof(version_buff), "%c%d.%d.%d", p_version_info->sys_soft_version[0],
	                                                           p_version_info->sys_soft_version[1],
                                                               p_version_info->sys_soft_version[2],
                                                               p_version_info->sys_soft_version[3]);
    if((strcmp(g_csu_property_data.csu_version, version_buff)) || all_data_upload_flag)
    {
        cJSON_AddStringToObject(p_base_config, "csu$version", version_buff);
        strcpy(g_csu_property_data.csu_version, version_buff);
        upload_flag = 1;
    }
    if((g_csu_property_data.comm_status != p_mqtt_cfg->mqtt_connect_status) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "csu$commStatus", p_mqtt_cfg->mqtt_connect_status);
        g_csu_property_data.comm_status = p_mqtt_cfg->mqtt_connect_status;
        upload_flag = 1;
    }
    if((g_csu_property_data.run_status != p_telemetry_data->sys_version_telemetry_info.csu_sys_state) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "csu$runStatus", p_telemetry_data->sys_version_telemetry_info.csu_sys_state);
        g_csu_property_data.run_status = p_telemetry_data->sys_version_telemetry_info.csu_sys_state;
        upload_flag = 1;
    }

    if(all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "csu$xjOnlineStatus", 0);
        cJSON_AddNumberToObject(p_base_config, "csu$xjWorkStatus", 0);
        cJSON_AddNumberToObject(p_base_config, "csu$xjWorkMode", 0);
    }

    p_data_item = cJSON_CreateObject();
    if(p_data_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_base_config);
        return;
    }
    
    cJSON_AddNumberToObject(p_data_item, "dataTime", get_sys_timestamp());
    cJSON_AddItemToObject(p_data_item, "baseConfig", p_base_config);

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_data_item);
        return;
    }
    cJSON_AddItemToArray(p_data_array,  p_data_item);
    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);

    if(upload_flag)
    {
        mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.property_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    }
    all_data_upload_flag = 0;
    free(p);
}


/**
 * @brief   储能单元监控数据上报
 * @param
 * @note
 * @return
 */
void cmu_monitor_data_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    cJSON *p_base_config = NULL;
    char *p = NULL;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();

    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    if(p_energy_cabinet_data == NULL)
    {
        return;
    }

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_energy_cabinet_data->cmu_data.property_data.cmu_sn);
    cJSON_AddStringToObject(p_root, "product", "cmu");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_base_config = cJSON_CreateObject();
    if(p_base_config == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }

    //电池堆
    cJSON_AddNumberToObject(p_base_config, "cmu$soc",   p_energy_cabinet_data->bat_stack_data.monitor_data.soc);
    cJSON_AddNumberToObject(p_base_config, "cmu$soh", p_energy_cabinet_data->bat_stack_data.monitor_data.soh);
    cJSON_AddNumberToObject(p_base_config, "cmu$temM", p_energy_cabinet_data->bat_stack_data.monitor_data.temp_m);
    cJSON_AddNumberToObject(p_base_config, "cmu$char",   p_energy_cabinet_data->bat_stack_data.monitor_data.charge);
    cJSON_AddNumberToObject(p_base_config, "cmu$dischar", p_energy_cabinet_data->bat_stack_data.monitor_data.discharge);
    cJSON_AddNumberToObject(p_base_config, "cmu$Volt", p_energy_cabinet_data->bat_stack_data.monitor_data.volt);
    cJSON_AddNumberToObject(p_base_config, "cmu$Curr", p_energy_cabinet_data->bat_stack_data.monitor_data.current);
    cJSON_AddNumberToObject(p_base_config, "cmu$Power", p_energy_cabinet_data->bat_stack_data.monitor_data.power);
    cJSON_AddNumberToObject(p_base_config, "cmu$insulation", p_energy_cabinet_data->bat_stack_data.monitor_data.insulation);
    //消防
    cJSON_AddNumberToObject(p_base_config, "cmu$co", p_energy_cabinet_data->fc_data.monitor_data.co);
    //液冷
    cJSON_AddNumberToObject(p_base_config, "cmu$effluentTemp", p_energy_cabinet_data->lc_data.monitor_data.effluent_temp);
    cJSON_AddNumberToObject(p_base_config, "cmu$ascentTemp", p_energy_cabinet_data->lc_data.monitor_data.ascent_temp);
    cJSON_AddNumberToObject(p_base_config, "cmu$effluentPressure", p_energy_cabinet_data->lc_data.monitor_data.effluent_pressure);
    cJSON_AddNumberToObject(p_base_config, "cmu$ascentPressure", p_energy_cabinet_data->lc_data.monitor_data.ascent_pressure);
    //PCS
    cJSON_AddNumberToObject(p_base_config, "cmu$activePower",   p_energy_cabinet_data->pcs_data.monitor_data.active_power);

    //计量电表日/总充放电量
    char date[32] = {0};
    sdk_rtc_t rtc_time = {0};
    uint32_t meter_charge = 0;
    uint32_t meter_discharge = 0;

    sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);  
    snprintf(date, 32,"%04d-%02d-%02d", rtc_time.tm_year + 2000, rtc_time.tm_mon, rtc_time.tm_day);

    get_daily_energy_data_from_db(date, &meter_charge, &meter_discharge, ENERGY_DB, METER);
    cJSON_AddNumberToObject(p_base_config, "cmu$dayReactiveEnergy", meter_charge);
    cJSON_AddNumberToObject(p_base_config, "cmu$dayActiveEnergy", meter_discharge);
    get_total_energy_data_from_db(&meter_charge, &meter_discharge, ENERGY_DB, METER);
    cJSON_AddNumberToObject(p_base_config, "cmu$toatlReactiveEnergy", meter_charge);
    cJSON_AddNumberToObject(p_base_config, "cmu$toatlActiveEnergy", meter_discharge);

    p_data_item = cJSON_CreateObject();
    if(p_data_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_base_config);
        return;
    }
    
    cJSON_AddNumberToObject(p_data_item, "dataTime", get_sys_timestamp());
    cJSON_AddItemToObject(p_data_item, "baseConfig", p_base_config);

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_data_item);
        return;
    }
    cJSON_AddItemToArray(p_data_array,  p_data_item);
    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.monitor_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS0);
    free(p);
}


/**
 * @brief   CSU监控数据上报
 * @param
 * @note
 * @return
 */
void csu_monitor_data_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    cJSON *p_base_config = NULL;
    char *p = NULL;
    int32_t load_power = 0;
    int32_t solar_power = 0;
    uint32_t meter_charge = 0;
    uint32_t meter_discharge = 0;
    uint32_t energy_in = 0;
    uint32_t energy_out = 0;
    char date[32] = {0};
    sdk_rtc_t rtc_time = {0};
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();
    internal_shared_data_t *p_internal_data = sdk_shm_internal_shared_data_get();
    constant_parameter_data_t *p_constant_para = sdk_shm_constant_parameter_data_get();

    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    if(p_energy_cabinet_data == NULL)
    {
        return;
    }

    sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);  
    snprintf(date, 32,"%04d-%02d-%02d", rtc_time.tm_year + 2000, rtc_time.tm_mon, rtc_time.tm_day);

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "model", (char *)"ESS433");
    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_mqtt_cfg->dev_sn.csu_sn);
    cJSON_AddStringToObject(p_root, "product", "csu");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_base_config = cJSON_CreateObject();
    if(p_base_config == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }

    cJSON_AddNumberToObject(p_base_config, "csu$gridPower", p_telemetry_data->sys_cabinet_telemetry_info.anti_reflux_power * 10);
    //是否需要考虑浮动功率
    //光伏功率&光伏发电量
    if(p_constant_para->system_param.cabinet_param.rs485_device_enable.bit.photovoltaic_meter)
    {
        for(uint8_t i = 0; i < p_constant_para->photovoltaic_meter_cfg.meter_cnt; i++)
        {
            solar_power += p_internal_data->photovoltaic_meter_data[i].active_power_total;
        }
    }
    //负载功率，按照中心功率为0进行计算
    load_power = (solar_power / 10.0) + (p_internal_data->total_realtime_energy.meter_power / 10.0) - (p_telemetry_data->sys_cabinet_telemetry_info.anti_reflux_power * 10.0);
    load_power = (load_power / 10) * 10;
    load_power = (load_power > 0) ? load_power : 0;
    cJSON_AddNumberToObject(p_base_config, "csu$loadPower", load_power);
    cJSON_AddNumberToObject(p_base_config, "csu$pvPower", solar_power);
    cJSON_AddNumberToObject(p_base_config, "csu$batPower", p_internal_data->total_realtime_energy.meter_power);

    //日
    get_daily_energy_data_from_db(date, &energy_in, &energy_out, PV_ENERGY_DB, PV_METER);
    cJSON_AddNumberToObject(p_base_config, "csu$pvDailyEnergy", energy_in);
    get_total_energy_data_from_db(&energy_in, &energy_out, PV_ENERGY_DB, PV_METER);
    cJSON_AddNumberToObject(p_base_config, "csu$pvTotalEnergy", energy_in);

    get_daily_energy_data_from_db(date, &energy_in, &energy_out, PCC_ENERGY_DB, PCC_METER);
    cJSON_AddNumberToObject(p_base_config, "csu$pccDailyInputEnergy", energy_in);
    cJSON_AddNumberToObject(p_base_config, "csu$pccDailyOutputEnergy", energy_out);
    get_total_energy_data_from_db(&energy_in, &energy_out, PCC_ENERGY_DB, PCC_METER);
    cJSON_AddNumberToObject(p_base_config, "csu$pccTotalInputEnergy", energy_in);
    cJSON_AddNumberToObject(p_base_config, "csu$pccTotalOutputEnergy", energy_out);

    get_daily_energy_data_from_db(date, &energy_in, &energy_out, LOAD_ENERGY_DB, LOAD);
    cJSON_AddNumberToObject(p_base_config, "csu$loadDailyEnergy", energy_out);
    get_total_energy_data_from_db(&energy_in, &energy_out, LOAD_ENERGY_DB, LOAD);
    cJSON_AddNumberToObject(p_base_config, "csu$loadTotalEnergy", energy_out);

    get_daily_energy_data_from_db(date, &meter_charge, &meter_discharge, ENERGY_DB, METER);
    cJSON_AddNumberToObject(p_base_config, "csu$emDailyChargeEnergy", meter_charge);
    cJSON_AddNumberToObject(p_base_config, "csu$emDailyDischargeEnergy", meter_discharge);
    get_total_energy_data_from_db(&meter_charge, &meter_discharge, ENERGY_DB, METER);
    cJSON_AddNumberToObject(p_base_config, "csu$emTotalChargeEnergy", meter_charge);
    cJSON_AddNumberToObject(p_base_config, "csu$emTotalDischargeEnergy", meter_discharge);



    p_data_item = cJSON_CreateObject();
    if(p_data_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_base_config);
        return;
    }
    
    cJSON_AddNumberToObject(p_data_item, "dataTime", get_sys_timestamp());
    cJSON_AddItemToObject(p_data_item, "baseConfig", p_base_config);

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_data_item);
        return;
    }
    cJSON_AddItemToArray(p_data_array,  p_data_item);
    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.monitor_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS0);
    free(p);
}


/**
 * @brief   设备时区上报
 * @param
 * @note
 * @return
 */
void csu_local_timezone_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_array = NULL;
    cJSON *p_data_item = NULL;
    char *p = NULL;
    char tz[128] = {0};
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
    
    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "model", (char *)"ESS433");
    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_mqtt_cfg->dev_sn.csu_sn);
    cJSON_AddStringToObject(p_root, "product", "csu");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_data_item = cJSON_CreateObject();
    if(p_data_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    //获取时区名称
    if(get_local_tz(tz) == true)
    {
        cJSON_AddStringToObject(p_data_item, "TZ", tz);
    }

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_data_item);
        return;
    }
    cJSON_AddItemToArray(p_data_array, p_data_item);

    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.timezone_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);

    free(p);
}


/**
 * @brief   NTP事件数据上报
 * @param
 * @note
 * @return
 */
void csu_ntp_event_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    char *p = NULL;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
    
    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "model", (char *)"ESS433");
    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_mqtt_cfg->dev_sn.csu_sn);
    cJSON_AddStringToObject(p_root, "product", "csu");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }

    p_data_item = cJSON_CreateObject();
    if(p_data_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_data_array);
        return;
    }
    
    cJSON_AddStringToObject(p_data_item, "eventId", "ntpRequest");
    cJSON_AddStringToObject(p_data_item, "status", "0");
    cJSON_AddStringToObject(p_data_item, "type", "3");
    cJSON_AddItemToArray(p_data_array,  p_data_item);

    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.event_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);

    free(p);
}




/**
 * @brief   开机
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] p_payload:消息
 * @param   [in] len:消息长度
 * @note
 * @return
 */
static void csu_poweron_set(struct mosquitto *mosq, char *p_payload, int32_t len)
{
    cJSON *p_request = NULL;
    char *p = NULL;
    mqtt_config_t *p_mqtt_cfg = NULL;
    web_control_info_t *p_web_data = sdk_shm_web_control_data_get();

    p_mqtt_cfg = mqtt_cfg_get();
    p_request = cJSON_Parse(p_payload);
    if(p_request == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"data parse error");
        return;
    }
    //执行开机
    BIT_SET(p_web_data->control_cmd_flag, 5);

    cJSON_AddNumberToObject(p_request, "result", SUCCESS);
    p = cJSON_PrintUnformatted(p_request);
    cJSON_Delete(p_request);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.func_set_ack_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    free(p);
}


/**
 * @brief   获取开机状态
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] p_payload:消息
 * @param   [in] len:消息长度
 * @note
 * @return
 */
static void csu_poweron_status(struct mosquitto *mosq, char *p_payload, int32_t len)
{
    cJSON *p_request = NULL;
    char *p = NULL;
    mqtt_config_t *p_mqtt_cfg = NULL;
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();

    p_mqtt_cfg = mqtt_cfg_get();
    p_request = cJSON_Parse(p_payload);
    if(p_request == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"data parse error");
        return;
    }

    //开机状态
    if(p_telemetry_data->sys_version_telemetry_info.csu_sys_state == 2)
    {
        cJSON_AddNumberToObject(p_request, "status", 1);
    }
    //非开机状态定义为关机
    else
    {
        cJSON_AddNumberToObject(p_request, "status", 0);
    }
    cJSON_AddNumberToObject(p_request, "result", SUCCESS);
    p = cJSON_PrintUnformatted(p_request);
    cJSON_Delete(p_request);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.func_set_ack_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    free(p);
}


/**
 * @brief   关机
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] p_payload:消息
 * @param   [in] len:消息长度
 * @note
 * @return
 */
static void csu_poweroff_set(struct mosquitto *mosq, char *p_payload, int32_t len)
{
    cJSON *p_request = NULL;
    char *p = NULL;
    mqtt_config_t *p_mqtt_cfg = NULL;
    web_control_info_t *p_web_data = sdk_shm_web_control_data_get();

    p_mqtt_cfg = mqtt_cfg_get();
    p_request = cJSON_Parse(p_payload);
    if(p_request == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"data parse error");
        return;
    }
    //执行关机
    BIT_SET(p_web_data->control_cmd_flag, 6);

    cJSON_AddNumberToObject(p_request, "result", SUCCESS);
    p = cJSON_PrintUnformatted(p_request);
    cJSON_Delete(p_request);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.func_set_ack_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    free(p);
}


/**
 * @brief   获取关机状态
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] p_payload:消息
 * @param   [in] len:消息长度
 * @note
 * @return
 */
static void csu_poweroff_status(struct mosquitto *mosq, char *p_payload, int32_t len)
{
    cJSON *p_request = NULL;
    char *p = NULL;
    mqtt_config_t *p_mqtt_cfg = NULL;
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();

    p_mqtt_cfg = mqtt_cfg_get();
    p_request = cJSON_Parse(p_payload);
    if(p_request == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"data parse error");
        return;
    }

    //开机状态
    if(p_telemetry_data->sys_version_telemetry_info.csu_sys_state == 2)
    {
        cJSON_AddNumberToObject(p_request, "status", 1);
    }
    //非开机状态定义为关机
    else
    {
        cJSON_AddNumberToObject(p_request, "status", 0);
    }
    cJSON_AddNumberToObject(p_request, "result", SUCCESS);
    p = cJSON_PrintUnformatted(p_request);
    cJSON_Delete(p_request);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.func_set_ack_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    free(p);
}


/**
 * @brief   设置功率
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] p_payload:消息
 * @param   [in] len:消息长度
 * @note
 * @return
 */
static void csu_power_value_set(struct mosquitto *mosq, char *p_payload, int32_t len)
{
    int16_t active_power = 0;
    cJSON *p_request = NULL;
    cJSON *p_param = NULL;
    char *p = NULL;
    mqtt_config_t *p_mqtt_cfg = NULL;
    web_control_info_t *p_web_data = sdk_shm_web_control_data_get();

    p_mqtt_cfg = mqtt_cfg_get();
    p_request = cJSON_Parse(p_payload);
    if(p_request == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"data parse error");
        return;
    }
    p_param = cJSON_GetObjectItem(p_request,"params");

    //执行设置功率
    BIT_SET(p_web_data->cabinet_param_update_flag, 1);
    active_power = atoi(cJSON_GetObjectItem(p_param, "power")->valuestring);
    p_web_data->cabinet_param_data.active_power = active_power * 10;
    cJSON_DeleteItemFromObject(p_request, "params");
    cJSON_AddNumberToObject(p_request, "result", SUCCESS);
    p = cJSON_PrintUnformatted(p_request);
    cJSON_Delete(p_request);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.func_set_ack_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    free(p);
}


/**
 * @brief   获取功率
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] p_payload:消息
 * @param   [in] len:消息长度
 * @note
 * @return
 */
static void csu_power_value_get(struct mosquitto *mosq, char *p_payload, int32_t len)
{
    cJSON *p_request = NULL;
    cJSON *p_param = NULL;
    char *p = NULL;
    char power_buff[32] = {0};
    mqtt_config_t *p_mqtt_cfg = NULL;
    constant_parameter_data_t *p_const_data = sdk_shm_constant_parameter_data_get();

    p_mqtt_cfg = mqtt_cfg_get();
    p_request = cJSON_Parse(p_payload);
    if(p_request == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"data parse error");
        return;
    }

    p_param = cJSON_CreateObject();
    if(p_param == NULL)
    {
        cJSON_Delete(p_request);
        return;
    }
    sprintf(power_buff, "%d", p_const_data->cabinet_param_data.active_power / 10);
    cJSON_AddStringToObject(p_param, "power", power_buff);
    cJSON_AddItemToObject(p_request, "params", p_param);

    cJSON_AddNumberToObject(p_request, "result", SUCCESS);
    p = cJSON_PrintUnformatted(p_request);
    cJSON_Delete(p_request);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.func_set_ack_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    free(p);
}

/**
 * @brief   小桔运行模式设置
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] p_payload:消息
 * @param   [in] len:消息长度
 * @note
 * @return
 */
// static void csu_xj_work_mode_set(struct mosquitto *mosq, char *p_payload, int32_t len)
// {
//     int16_t work_mode = 0;
//     cJSON *p_request = NULL;
//     cJSON *p_param = NULL;
//     char *p = NULL;
//     mqtt_config_t *p_mqtt_cfg = NULL;
//     // web_control_info_t *p_web_data = sdk_shm_web_control_data_get();

//     p_mqtt_cfg = mqtt_cfg_get();
//     p_request = cJSON_Parse(p_payload);
//     if(p_request == NULL)
//     {
//         MQTT_DEBUG_PRINT((int8_t *)"data parse error");
//         return;
//     }
//     p_param = cJSON_GetObjectItem(p_request,"params");

//     //执行设置模式
//     // BIT_SET(p_web_data->cabinet_param_update_flag, 1);
//     work_mode = atoi(cJSON_GetObjectItem(p_param, "mode")->valuestring);
//     // p_web_data->cabinet_param_data.active_power = active_power * 10;
//     cJSON_DeleteItemFromObject(p_request, "params");
//     cJSON_AddNumberToObject(p_request, "result", SUCCESS);
//     p = cJSON_PrintUnformatted(p_request);
//     cJSON_Delete(p_request);
//     mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.func_set_ack_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
//     free(p);
// }


/**
 * @brief    保存时区信息
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void save_timezone_info(char *p_tz)
{

    cJSON *p_conf = NULL;
    char content[256] = {0};
    FILE *fp = NULL;
    char *p = NULL;

    /*将新的时区设置保存下来*/
    fp = fopen(SYSTIME_JSON_FILE,"r");
    if(fp == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"open json file %s failed.",SYSTIME_JSON_FILE);  
        return;   
    }
    fread(content, 1, 128, fp);
    fclose(fp);
 
    p_conf = cJSON_Parse(content);
    if(p_conf == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"parse file %s content failed.",SYSTIME_JSON_FILE);
        return;
    }

    if(cJSON_GetObjectItem(p_conf,"tz") != NULL)
    {
        cJSON_ReplaceItemInObject(p_conf,"tz",cJSON_CreateString(p_tz));
    }
    else
    {
        cJSON_AddStringToObject(p_conf, "tz", p_tz);
    }
    
    p = cJSON_PrintUnformatted(p_conf);
 
    fp = fopen(SYSTIME_JSON_FILE,"w");
    if(fp == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"open json file %s failed.",SYSTIME_JSON_FILE);  
        cJSON_Delete(p_conf);
        free(p);
        return;   
    }
    fwrite(p, 1, strlen(p), fp);
    fclose(fp);
    cJSON_Delete(p_conf);
    free(p);
}


/**
 * @brief   获取安规信息
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] p_payload:消息
 * @param   [in] len:消息长度
 * @note
 * @return
 */
static void csu_safety_info_get(struct mosquitto *mosq, char *p_payload, int32_t len)
{
    uint8_t ret = 0;
    cJSON *p_response = NULL;
    cJSON *p_request = NULL;
    char *p = NULL;
    char url[128] = {0};
    char response[1024 * 8] = {0};
    uint8_t uri[] = {"/debugManager/getTestSafety"};
    char json_str[] = {"{\"action\":\"getTestSafety\"}"}; 
    mqtt_config_t *p_mqtt_cfg = NULL;

    p_mqtt_cfg = mqtt_cfg_get();
    p_request = cJSON_Parse(p_payload);
    if(p_request == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"data parse error");
        return;
    }

    //第一步：从CMU获取安规信息列表
    sprintf(url, "%s%s%s", "http://", CMU1_IP, uri);
    ret = http_net_post(url, json_str, response);
    if(ret)
    {
        p_response = cJSON_Parse(response);
        if(p_response == NULL)
        {
            MQTT_DEBUG_PRINT((int8_t *)"data parse error");
            cJSON_Delete(p_request);
            return;
        }
    }
    cJSON_DeleteItemFromObject(p_response, "code");
    cJSON_DeleteItemFromObject(p_response, "msg");
    //第二步：打包上传至云平台
    cJSON_AddItemToObject(p_request, "params", p_response);
    cJSON_AddNumberToObject(p_request, "result", SUCCESS);
    p = cJSON_PrintUnformatted(p_request);
    cJSON_Delete(p_request);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.func_set_ack_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    free(p);
}


/**
 * @brief   安规设置
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] p_payload:消息
 * @param   [in] len:消息长度
 * @note
 * @return
 */
static void csu_safety_set(struct mosquitto *mosq, char *p_payload, int32_t len)
{
    int country_code = 0;
    int standard_code = 0;
    cJSON *p_response = NULL;
    cJSON *p_request = NULL;
    cJSON *p_params = NULL;
    char *p = NULL;
    char url[128] = {0};
    char response[1024 * 8] = {0};
    uint8_t uri[] = {"/debugManager/setTestSafety"};
    mqtt_config_t *p_mqtt_cfg = NULL;

    p_mqtt_cfg = mqtt_cfg_get();
    p_request = cJSON_Parse(p_payload);
    if(p_request == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"data parse error");
        return;
    }

    //第一步：解析安规地区和标准
    p_params = cJSON_GetObjectItem(p_request,"params");
    country_code = cJSON_GetObjectItem(p_params, "countryCode")->valueint;
    standard_code = cJSON_GetObjectItem(p_params, "standardCode")->valueint;

    //第二步打包转发至CMU
    p_response = cJSON_CreateObject();
    if(p_response == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"json create error");
        cJSON_Delete(p_request);
        return;
    }
    cJSON *p_data = NULL;
    p_data = cJSON_CreateObject();
    if(p_data == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"json create error");
        cJSON_Delete(p_request);
        cJSON_Delete(p_response);
        return;
    }
    cJSON_AddNumberToObject(p_data, "countryCode", country_code);
    cJSON_AddNumberToObject(p_data, "standardCode", standard_code);
    cJSON_AddItemToObject(p_response, "data", p_data);
    cJSON_AddStringToObject(p_response, "action", "setTestSafety");
    cJSON_AddStringToObject(p_response,"userName", "cloud");
    p = cJSON_PrintUnformatted(p_response);

    sprintf(url, "%s%s%s", "http://", CMU1_IP, uri);
    http_net_post(url, p, response);

    cJSON_Delete(p_response);
    free(p);
    p = NULL;

    cJSON_DeleteItemFromObject(p_request, "params");
    cJSON_AddNumberToObject(p_request, "result", SUCCESS);
    p = cJSON_PrintUnformatted(p_request);
    cJSON_Delete(p_request);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.func_set_ack_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    free(p);
}

/**
 * @brief   故障复位
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] p_payload:消息
 * @param   [in] len:消息长度
 * @note
 * @return
 */
static void csu_fault_reset(struct mosquitto *mosq, char *p_payload, int32_t len)
{
    cJSON *p_response = NULL;
    cJSON *p_request = NULL;
    char *p = NULL;
    char url[128] = {0};
    char response[1024 * 8] = {0};
    uint8_t uri[] = {"/controlCmd/faultReset"};
    mqtt_config_t *p_mqtt_cfg = NULL;

    p_mqtt_cfg = mqtt_cfg_get();
    p_request = cJSON_Parse(p_payload);
    if(p_request == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"data parse error");
        return;
    }

    p_response = cJSON_CreateObject();
    if(p_response == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"json create error");
        cJSON_Delete(p_request);
        return;
    }
    cJSON *p_data = NULL;
    p_data = cJSON_CreateObject();
    if(p_data == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"json create error");
        cJSON_Delete(p_request);
        cJSON_Delete(p_response);
        return;
    }

    cJSON_AddStringToObject(p_response, "action", "faultReset");
    cJSON_AddStringToObject(p_response,"userName", "cloud");
    p = cJSON_PrintUnformatted(p_response);

    sprintf(url, "%s%s%s", "http://", CMU1_IP, uri);
    http_net_post(url, p, response);

    cJSON_Delete(p_response);
    free(p);
    p = NULL;

    cJSON_DeleteItemFromObject(p_request, "params");
    cJSON_AddNumberToObject(p_request, "result", SUCCESS);
    p = cJSON_PrintUnformatted(p_request);
    cJSON_Delete(p_request);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.func_set_ack_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    free(p);
}


/**
 * @brief   连接本地modbus-server进行modbus数据读取
 * @param   [in] p_data:消息
 * @param   [in] data_len:长度
 * @param   [out] p_out:返回数据
 * @note
 * @return  0:失败 >0:返回数据长度
 */
static int modbus_data_debug(char *p_data, int32_t data_len, char *p_out)
{
    int sockfd = 0;
    struct timeval tv;
    struct sockaddr_in serv_addr;

    if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) 
    {
        return 0;
    }

    memset(&serv_addr, '0', sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(502);

    if(inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) 
    {
        close(sockfd);
        return 0;
    }

    if(connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) 
    {
        close(sockfd);
        return 0;
    }

    tv.tv_sec = 3;
    tv.tv_usec = 0;
    setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, (const char*)&tv, sizeof(tv));
    MQTT_DEBUG_PRINT((int8_t *)"send-->");
    print_frame(p_data, data_len);

    ssize_t sent_bytes = send(sockfd, p_data, data_len, 0);
    if (sent_bytes < 0) 
    {
        close(sockfd);
        return 0;
    }
    ssize_t recv_bytes = recv(sockfd, p_out, MAX_DEBUG_RECV_BUFF_LEN, 0);

    if (recv_bytes > 0) 
    {
        MQTT_DEBUG_PRINT((int8_t *)"recv-->");
        print_frame(p_out, recv_bytes);
        close(sockfd);
        return recv_bytes;
    }

    close(sockfd);
    return 0;
}


/**
 * @brief   调试指令，按照modbus协议进行查询
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] p_payload:消息
 * @param   [in] len:消息长度
 * @note
 * @return
 */
static void csu_debug_data_trans(struct mosquitto *mosq, char *p_payload, int32_t len)
{
    int ret = 0;
    int i = 0;
    cJSON *p_request = NULL;
    cJSON *p_param = NULL;
    char *p_data = NULL;
    char *p_buff = NULL;
    int buff_len = 0;
    char *p = NULL;
    char recv_buff[MAX_DEBUG_RECV_BUFF_LEN] = {0};
    char data_ack[MAX_DEBUG_RECV_BUFF_LEN * 2] = {0};
    mqtt_config_t *p_mqtt_cfg = NULL;

    p_mqtt_cfg = mqtt_cfg_get();
    p_request = cJSON_Parse(p_payload);
    if(p_request == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"data parse error");
        return;
    }

    //1、获取调试数据
    p_param = cJSON_GetObjectItem(p_request,"params");
    p_data = cJSON_GetObjectItem(p_param, "data")->valuestring;
    buff_len = strlen(p_data) / 2;
    p_buff = (char *)malloc(buff_len);
    if(p_buff == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"malloc failed");
        cJSON_Delete(p_request);
        return;
    }
    memset(p_buff, 0, buff_len);

    for(i = 0; i < buff_len; i++) 
    {
        char byte_str[3] = {p_data[2 * i], p_data[2 * i + 1], '\0'};
        p_buff[i] = (uint8_t)strtol(byte_str, NULL, 16);
    }
    ret = modbus_data_debug(p_buff, buff_len, recv_buff);
    if(!ret)
    {
        cJSON_AddNumberToObject(p_request, "result", FAIL);
    }
    else
    {
        cJSON_AddNumberToObject(p_request, "result", SUCCESS);
        for(i = 0; i < ret; i++)
        {
            sprintf(data_ack + 2 * i, "%02x", recv_buff[i]);
            cJSON_AddStringToObject(p_param, "dataAck", data_ack);
        }
    }
    cJSON_DeleteItemFromObject(p_param, "data");
    p = cJSON_PrintUnformatted(p_request);
    cJSON_Delete(p_request);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.func_set_ack_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    free(p);
    free(p_buff);
}


/**
 * @brief   云平台设置本地EMS参数
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] p_payload:消息
 * @param   [in] len:消息长度
 * @note
 * @return
 */
static void csu_remote_strategy_set(struct mosquitto *mosq, char *p_payload, int32_t len)
{
    int i = 0;
    int16_t power = 0;
    uint16_t month_index = 0;
    cJSON *p_request = NULL;
    cJSON *p_param = NULL;
    char *p = NULL;
    ems_data_t *p_ems_data = NULL;
	ems_holiday_data_t *p_ems_holiday_data = NULL;
    mqtt_config_t *p_mqtt_cfg = NULL;

    p_mqtt_cfg = mqtt_cfg_get();
	web_control_info_t *sdk_shm_web_data = sdk_shm_web_control_data_get();
    p_ems_data = &(sdk_shm_web_data->ems_data);
    p_ems_holiday_data = &(sdk_shm_web_data->ems_holiday_data);

    p_request = cJSON_Parse(p_payload);
    if(p_request == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"data parse error");
        return;
    }

    p_param = cJSON_GetObjectItem(p_request, "params");
    p_ems_data->shav_peak_fill_valley_en = cJSON_GetObjectItem(p_param, "cpfvEnable")->valueint;
    p_ems_data->self_cosum_mode_enable = cJSON_GetObjectItem(p_param, "autoMode")->valueint;
	if(NULL != cJSON_GetObjectItem(p_param, "peakValleyStrategy"))
	{
        cJSON *p_pv_strategy = cJSON_GetObjectItem(p_param, "peakValleyStrategy");
		cJSON *p_resp_array = cJSON_GetObjectItem(p_pv_strategy, "timeAttr");

		uint16_t array_size = cJSON_GetArraySize(p_resp_array);
		if(array_size == 0)
		{
			MQTT_DEBUG_PRINT((int8_t *)"array size is 0");
		}

		//数据清0
		memset(p_ems_data->time_attr, 0, sizeof(ems_time_attr_t) * EMS_TIME_DURATION_CNT);
		for(i = 0; i < EMS_TIME_DURATION_CNT; i++)
		{
			if(i < array_size)
			{
				cJSON *item = cJSON_GetArrayItem(p_resp_array, i);
				p_ems_data->time_attr[i].enable_type = cJSON_GetObjectItem(item,"enableType")->valueint;
				p_ems_data->time_attr[i].start_time = cJSON_GetObjectItem(item,"startTime")->valueint;
				p_ems_data->time_attr[i].end_time = cJSON_GetObjectItem(item,"endTime")->valueint;
				power = cJSON_GetObjectItem(item,"power")->valueint;
				p_ems_data->power[i] = (power == INVALID_POWER) ? INVALID_POWER : power * 10;
			}
			else
			{
				p_ems_data->power[i] = INVALID_POWER;
			}
			MQTT_DEBUG_PRINT((int8_t *)"enable_type:%d", p_ems_data->time_attr[i].enable_type);
			MQTT_DEBUG_PRINT((int8_t *)"start_time:%d", p_ems_data->time_attr[i].start_time);
			MQTT_DEBUG_PRINT((int8_t *)"end_time:%d", p_ems_data->time_attr[i].end_time);
			MQTT_DEBUG_PRINT((int8_t *)"Power:%d", p_ems_data->power[i]);
		}
	}
	else
	{
		memset(p_ems_data->time_attr, 0, sizeof(ems_time_attr_t) * EMS_TIME_DURATION_CNT);
		for(i = 0; i < EMS_TIME_DURATION_CNT; i++)
		{
            p_ems_data->power[i] = INVALID_POWER;
            MQTT_DEBUG_PRINT((int8_t *)"Power:%d", p_ems_data->power[i]);
		}
	}

    memset(p_ems_holiday_data->time_attr, 0, sizeof(ems_holiday_time_attr_t) * EMS_TIME_DURATION_CNT);
	memset(p_ems_holiday_data->holiday_date, 0xFF, sizeof(p_ems_holiday_data->holiday_date));
    for(i = 0; i < EMS_TIME_DURATION_CNT; i++)
	{
		p_ems_holiday_data->time_attr[i].power = INVALID_POWER;
	}
	if(NULL != cJSON_GetObjectItem(p_param, "vacationStrategy"))
	{
		uint16_t holiday_enable = 0;
		cJSON *p_va_strategy = cJSON_GetObjectItem(p_param, "vacationStrategy");

		holiday_enable = cJSON_GetObjectItem(p_va_strategy, "vacationStrategy")->valueint;

		if(holiday_enable)
		{
			cJSON *p_time_array = cJSON_GetObjectItem(p_va_strategy, "timeAttr");
			uint16_t array_size = cJSON_GetArraySize(p_time_array);
			if(array_size == 0)
			{
				MQTT_DEBUG_PRINT((int8_t *)"array size is 0");
			}
			for(uint8_t i = 0; i < EMS_TIME_DURATION_CNT; i++)
			{
				if(i < array_size)
				{
					cJSON *item = cJSON_GetArrayItem(p_time_array, i);
					p_ems_holiday_data->time_attr[i].enable_type = cJSON_GetObjectItem(item,"enableType")->valueint;
					p_ems_holiday_data->time_attr[i].start_time = cJSON_GetObjectItem(item,"startTime")->valueint;
					p_ems_holiday_data->time_attr[i].end_time = cJSON_GetObjectItem(item,"endTime")->valueint;
					power = cJSON_GetObjectItem(item,"power")->valueint;
					p_ems_holiday_data->time_attr[i].power = (power == INVALID_POWER) ? INVALID_POWER : power * 10;
				}
				else
				{
					p_ems_holiday_data->time_attr[i].power = INVALID_POWER;
				}
				MQTT_DEBUG_PRINT((int8_t *)"enable_type:%d", p_ems_holiday_data->time_attr[i].enable_type);
				MQTT_DEBUG_PRINT((int8_t *)"start_time:%d", p_ems_holiday_data->time_attr[i].start_time);
				MQTT_DEBUG_PRINT((int8_t *)"end_time:%d", p_ems_holiday_data->time_attr[i].end_time);
				MQTT_DEBUG_PRINT((int8_t *)"Power:%d", p_ems_holiday_data->time_attr[i].power);
			}
			p_ems_holiday_data->holiday_enable = 0;
			cJSON *p_weekend_array = cJSON_GetObjectItem(p_va_strategy, "Weekend");
			uint16_t p_weekend_array_size = cJSON_GetArraySize(p_weekend_array);
			for (uint8_t i = 0; i < p_weekend_array_size; i++)
			{
				uint16_t value = cJSON_GetArrayItem(p_weekend_array, i)->valueint;
				if(6 == value)
				{
					BIT_SET(p_ems_holiday_data->holiday_enable, 0);
				}
				else if(7 == value)
				{
					BIT_SET(p_ems_holiday_data->holiday_enable, 1);
				}
			}

			for (uint8_t i = 0; i < 12; i++)
			{
				cJSON *p_month_array = cJSON_GetObjectItem(p_va_strategy, month_name[i]);
				uint16_t p_month_array_size = cJSON_GetArraySize(p_month_array);
				MQTT_DEBUG_PRINT((int8_t *)"i:%d\n", i);
				MQTT_DEBUG_PRINT((int8_t *)"size:%d\n", p_month_array_size);
				if(p_month_array_size != 0)
				{
					BIT_SET(p_ems_holiday_data->holiday_enable, 2);
				}
				MQTT_DEBUG_PRINT((int8_t *)"p_month_array_size:%d\n", p_month_array_size);
				MQTT_DEBUG_PRINT((int8_t *)"p_ems_holiday_data->holiday_enable:%d\n", p_ems_holiday_data->holiday_enable);
				for (uint8_t j = 0; j < p_month_array_size; j++)
				{
					p_ems_holiday_data->holiday_date[month_index].bytes.high = i + 1;
					p_ems_holiday_data->holiday_date[month_index].bytes.low = cJSON_GetArrayItem(p_month_array, j)->valueint;
					MQTT_DEBUG_PRINT((int8_t *)"cJSON_GetArrayItem(p_month_array, j)->valueint: %d\n",cJSON_GetArrayItem(p_month_array, j)->valueint);
					month_index++;
				}
				if(month_index >= EMS_HOLIDAY_DATE_NUM)
				{
					break;
				}
			}
		}
		else
		{
			p_ems_holiday_data->holiday_enable = 0;
		}
	}
	else
	{
		p_ems_holiday_data->holiday_enable = 0;
	}
    BIT_SET(sdk_shm_web_data->cabinet_param_update_flag, 0);

    cJSON_DeleteItemFromObject(p_request, "params");
    cJSON_AddNumberToObject(p_request, "result", SUCCESS);
    p = cJSON_PrintUnformatted(p_request);
    cJSON_Delete(p_request);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.func_set_ack_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    free(p);
}


/**
 * @brief   获取EMS参数
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] p_payload:消息
 * @param   [in] len:消息长度
 * @note
 * @return
 */
static void csu_remote_strategy_get(struct mosquitto *mosq, char *p_payload, int32_t len)
{
    cJSON *p_request = NULL;
    cJSON *p_param = NULL;
    cJSON *p_pv_strategy = NULL;
    cJSON *p_va_strategy = NULL;
    cJSON *p_resp_array = NULL;
    cJSON *p_time_attr_item = NULL;
    cJSON *p_holiday_item = NULL;
    char *p = NULL;
	common_data_t *shm = NULL;
    int16_t power = 0;
	int32_t holiday_data[31];
	uint8_t index;
    mqtt_config_t *p_mqtt_cfg = NULL;

	shm = sdk_shm_get();
    ems_data_t *p_ems_data = &shm->constant_parameter_data.ems_data; 
    ems_holiday_data_t *p_ems_holiday_data = &(shm->constant_parameter_data.ems_holiday_data);
    
    p_mqtt_cfg = mqtt_cfg_get();
    p_request = cJSON_Parse(p_payload);
    if(p_request == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"data parse error");
        return;
    }
    p_param = cJSON_CreateObject();
    if(p_param == NULL)
    {
		cJSON_Delete(p_request);
		return;
    }
    cJSON_AddItemToObject(p_request, "params", p_param);

    cJSON_AddNumberToObject(p_param, "cpfvEnable", p_ems_data->shav_peak_fill_valley_en);
    cJSON_AddNumberToObject(p_param, "autoMode", p_ems_data->self_cosum_mode_enable);

    p_pv_strategy = cJSON_CreateObject();
    if(p_pv_strategy == NULL)
    {
		cJSON_Delete(p_request);
		return;
    }
    cJSON_AddItemToObject(p_param, "peakValleyStrategy", p_pv_strategy);

    p_resp_array = cJSON_CreateArray();
    if(p_resp_array == NULL)
    {
		cJSON_Delete(p_request);
		return;
    }
	cJSON_AddItemToObject(p_pv_strategy, "timeAttr", p_resp_array);

    for(uint8_t i = 0; i < EMS_TIME_DURATION_CNT; i++)
    {
		if((p_ems_data->time_attr[i].enable_type == 0) || (p_ems_data->time_attr[i].enable_type == 1))
		{
			continue;
		}
        p_time_attr_item = cJSON_CreateObject();
        if(p_time_attr_item == NULL)
        {
            MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
            cJSON_Delete(p_resp_array);
            return;
        }
        cJSON_AddNumberToObject(p_time_attr_item, "enableType", p_ems_data->time_attr[i].enable_type);
        cJSON_AddNumberToObject(p_time_attr_item, "startTime", p_ems_data->time_attr[i].start_time);
        cJSON_AddNumberToObject(p_time_attr_item, "endTime", p_ems_data->time_attr[i].end_time);
        power = (p_ems_data->power[i] == INVALID_POWER) ? INVALID_POWER : (p_ems_data->power[i] / 10);
        cJSON_AddNumberToObject(p_time_attr_item, "power", power);
        cJSON_AddItemToArray(p_resp_array, p_time_attr_item);
    }

    p_va_strategy = cJSON_CreateObject();
    if(p_va_strategy == NULL)
    {
		cJSON_Delete(p_request);
		return;
    }
    cJSON_AddItemToObject(p_param, "vacationStrategy", p_va_strategy);
    cJSON_AddNumberToObject(p_va_strategy, "vacationStrategy", p_ems_holiday_data->holiday_enable ? 1 : 0);

    p_resp_array = cJSON_CreateArray();
    if(p_resp_array == NULL)
    {
		cJSON_Delete(p_request);
		return;
    }
	cJSON_AddItemToObject(p_va_strategy, "timeAttr", p_resp_array);

    for(uint8_t i = 0; i < EMS_TIME_DURATION_CNT; i++)
    {
		if((p_ems_holiday_data->time_attr[i].enable_type == 0) || (p_ems_holiday_data->time_attr[i].enable_type == 1))
		{
			continue;
		}
        p_time_attr_item = cJSON_CreateObject();
        if(p_time_attr_item == NULL)
        {
            MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
            cJSON_Delete(p_request);
            return;
        }
        cJSON_AddNumberToObject(p_time_attr_item, "enableType", p_ems_holiday_data->time_attr[i].enable_type);
        cJSON_AddNumberToObject(p_time_attr_item, "startTime", p_ems_holiday_data->time_attr[i].start_time);
        cJSON_AddNumberToObject(p_time_attr_item, "endTime", p_ems_holiday_data->time_attr[i].end_time);
        power = (p_ems_holiday_data->time_attr[i].power == INVALID_POWER) ? INVALID_POWER : (p_ems_holiday_data->time_attr[i].power / 10);
        cJSON_AddNumberToObject(p_time_attr_item, "power", power);
        cJSON_AddItemToArray(p_resp_array, p_time_attr_item);
    }

	p_holiday_item = cJSON_CreateObject();
	if(p_holiday_item == NULL)
	{
		MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
		cJSON_Delete(p_request);
		return;
	}

	memset(holiday_data, 0xFF, sizeof(holiday_data));
	index = 0;
	if(BIT_GET(p_ems_holiday_data->holiday_enable, 0))
	{
		holiday_data[index++] = 6;
	}
	if(BIT_GET(p_ems_holiday_data->holiday_enable, 1))
	{
		holiday_data[index++] = 7;
	}
    cJSON_AddItemToObject(p_va_strategy, "Weekend", cJSON_CreateIntArray(holiday_data, index));
	for (uint8_t i = 0; i < 12; i++)
	{
		index = 0;
		if((i >= (p_ems_holiday_data->holiday_date[0].bytes.high - 1)) && (i < p_ems_holiday_data->holiday_date[EMS_HOLIDAY_DATE_NUM - 1].bytes.high))
		{
			for (uint8_t j = 0; j < EMS_HOLIDAY_DATE_NUM; j++)
			{
				MQTT_DEBUG_PRINT((int8_t *)"%d-%d\n",p_ems_holiday_data->holiday_date[j].bytes.high,p_ems_holiday_data->holiday_date[j].bytes.low);
				if(p_ems_holiday_data->holiday_date[j].bytes.high == (i + 1))
				{
					holiday_data[index++] = p_ems_holiday_data->holiday_date[j].bytes.low;
				}
				else if(p_ems_holiday_data->holiday_date[j].all == 0xFFFF)
				{
					break;
				}
			}
		}
		cJSON_AddItemToObject(p_va_strategy, month_name[i], cJSON_CreateIntArray(holiday_data, index));
	}

    cJSON_AddNumberToObject(p_request, "result", SUCCESS);
    p = cJSON_PrintUnformatted(p_request);
    cJSON_Delete(p_request);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.func_set_ack_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    free(p);
}


/**
 * @brief   获取系统时间信息
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] p_payload:消息
 * @param   [in] len:消息长度
 * @note
 * @return
 */
static void csu_sys_time_info_get(struct mosquitto *mosq, char *p_payload, int32_t len)
{
    cJSON *p_request = NULL;
    cJSON *p_param = NULL;
    char *p = NULL;
    mqtt_config_t *p_mqtt_cfg = NULL;
    char tz[128] = {0};

    p_mqtt_cfg = mqtt_cfg_get();
    p_request = cJSON_Parse(p_payload);
    if(p_request == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"data parse error");
        return;
    }

    p_param = cJSON_CreateObject();
    if(p_param == NULL)
    {
        cJSON_Delete(p_request);
        return;
    }
    cJSON_AddNumberToObject(p_param, "time", time(NULL));
    if(get_local_tz(tz))
    {
        cJSON_AddStringToObject(p_param, "timeZone", tz);
    }
    else
    {
        cJSON_AddStringToObject(p_param, "timeZone", "Asia/Shanghai");
    }
    cJSON_AddItemToObject(p_request, "params", p_param);

    cJSON_AddNumberToObject(p_request, "result", SUCCESS);
    p = cJSON_PrintUnformatted(p_request);
    cJSON_Delete(p_request);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.func_set_ack_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    free(p);
}


/**
 * @brief   同步系统时间
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] p_payload:消息
 * @param   [in] len:消息长度
 * @note
 * @return
 */
static void csu_sync_sys_time(struct mosquitto *mosq, char *p_payload, int32_t len)
{
    cJSON *p_request = NULL;
    cJSON *p_param = NULL;
    char *p = NULL;
    int32_t timestamp = 0;
    char *p_tz = NULL;
    char tz[256] = {0};
    char cmd[256] = {0};
    char date_str[80] = {0};
    char tz_update_flag = 0;
    mqtt_config_t *p_mqtt_cfg = NULL;

    internal_shared_data_t *p_shared_data = sdk_shm_internal_shared_data_get();
    web_control_info_t *p_web_control = sdk_shm_web_control_data_get();
    p_mqtt_cfg = mqtt_cfg_get();
    p_request = cJSON_Parse(p_payload);
    if(p_request == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"data parse error");
        return;
    }
    p_param = cJSON_GetObjectItem(p_request,"params");
    //这里对新旧云平台做个判断，旧平台数据不再进行时间同步
    if(cJSON_GetObjectItem(p_param, "timeZone") == NULL)
    {
        cJSON_Delete(p_request);
        return;
    }
    timestamp = cJSON_GetObjectItem(p_param, "time")->valueint;
    p_tz = cJSON_GetObjectItem(p_param, "timeZone")->valuestring;

    //判断是否需要更新时区
    if(get_local_tz(tz))
    {
        if(!strcmp(tz, p_tz))
        {
            MQTT_DEBUG_PRINT((int8_t *)"same tz, do not need update[%s]", tz);
        }
        else
        {
            tz_update_flag = 1;
        }
    }
    else
    {
        tz_update_flag = 1;
    }

    if(tz_update_flag)
    {
        //更新时区
        memset(tz, 0, sizeof(tz));
        sprintf(tz, "%s%s", "/opt/share/zoneinfo/", p_tz);
        MQTT_DEBUG_PRINT((int8_t *)"tz set to %s.\n", tz);
        sprintf(cmd, "ln -sf %s /etc/localtime", tz);
        system("mount -o remount,rw /");
        system("rm /etc/localtime");
        system(cmd);
        system("hwclock -w");
        system("mount -o remount,ro /");
        save_timezone_info(p_tz);
        BIT_SET(p_shared_data->tz_update_flag, 0);
        BIT_SET(p_shared_data->tz_update_flag, 1);
    }
    //更新时间
    struct tm *tm_local = localtime((time_t *)&timestamp);
    strftime(date_str, sizeof(date_str), "%Y-%m-%d %H:%M:%S", tm_local);
    MQTT_DEBUG_PRINT((int8_t *)"date: %s", date_str);
    memset(cmd, 0, sizeof(cmd));
    sprintf(cmd,"date -s \"%s\"", date_str);
    system(cmd);
    system("hwclock -w");

    //同时给MCU2和CMU同步系统时间
    BIT_SET(p_web_control->system_param_flag, 2);
    BIT_SET(p_web_control->system_param_flag, 4);

    cJSON_DeleteItemFromObject(p_request, "params");
    cJSON_AddNumberToObject(p_request, "result", SUCCESS);
    p = cJSON_PrintUnformatted(p_request);
    cJSON_Delete(p_request);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.func_set_ack_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    free(p);
}


/**
 * @brief   升级响应
 * @param   [in] ota_result：升级结果
 * @param   [in] ota_process：升级进度
 * @param   [in] p_error：异常码
 * @note
 * @return
 */
static void sofar_ota_status_response(char *p_request_id, uint8_t ota_result, uint8_t ota_process, char *p_error)
{
    cJSON *p_root = NULL;
    char *p = NULL;

    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        SOFAR_OTA_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "requestId", p_request_id);
    cJSON_AddStringToObject(p_root, "nodeId", p_mqtt_cfg->dev_sn.csu_sn);
    cJSON_AddNumberToObject(p_root, "result", ota_result);
    cJSON_AddNumberToObject(p_root, "process", ota_process);
    if(p_error)
    {
        cJSON_AddStringToObject(p_root, "code", p_error);
    }

    p = cJSON_PrintUnformatted(p_root);
    cJSON_Delete(p_root);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.ota_ack_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    free(p);  
}



/**
 * @brief   数据接收解析
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] p_topic：主题
 * @param   [in] p_payload:消息
 * @param   [in] len:消息长度
 * @note
 * @return
 */
void mqtt_data_parse(struct mosquitto *mosq, char *p_topic, char *p_payload, int32_t len)
{
    mqtt_config_t *p_mqtt_cfg = NULL;
    cJSON *p_request = NULL;
    char *p_function = NULL;
    char *p_node_id = NULL;
    char *p = NULL;
    sofar_ota_info_t *p_ota_info = NULL;
    sofar_ota_info_t *p_safety_upgrade_info = NULL;

    p_mqtt_cfg = mqtt_cfg_get();

    p_request = cJSON_Parse(p_payload);
    if(p_request == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"data parse error");
        return;
    }
    p_node_id = cJSON_GetObjectItem(p_request,"nodeId")->valuestring;
    if(strcmp(p_node_id, p_mqtt_cfg->dev_sn.csu_sn))
    {
        MQTT_DEBUG_PRINT((int8_t *)"node id error");
        cJSON_AddNumberToObject(p_request, "result", FAIL);
        p = cJSON_PrintUnformatted(p_request);
        cJSON_Delete(p_request);
        mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.func_set_ack_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
        free(p);
        return;
    }
    //服务设置
    if(!strcmp(p_topic, p_mqtt_cfg->mqtt_topic.func_set_topic))
    {
        MQTT_DEBUG_PRINT((int8_t *)"function set");
        if(cJSON_GetObjectItem(p_request,"functionName") == NULL)
        {
            cJSON_Delete(p_request);
            return;
        }
        p_function = cJSON_GetObjectItem(p_request,"functionName")->valuestring;

        int num = sizeof(func_table) / sizeof(func_table[0]);
        for(int i = 0; i < num; i++)
        {
            if(!strcmp(p_function, func_table[i].p_func))
            {
                func_table[i].p_func_cb(mosq, p_payload, len);
            }
        }
    }
    //升级
    if(!strcmp(p_topic, p_mqtt_cfg->mqtt_topic.ota_topic))
    {
        //此处根据fileType字段确定是安规升级还是固件升级
        char *p_file_type = NULL;
        int file_type = 0;

        if(cJSON_GetObjectItem(p_request,"fileType") != NULL)
        {
            p_file_type = cJSON_GetObjectItem(p_request,"fileType")->valuestring;
            file_type = atoi(p_file_type);
        }
        //固件升级
        if(file_type == SOFTWARE)
        {
            p_ota_info =  sofar_ota_info_get();

            if(p_ota_info->ota_status == OTA_NONE)
            {
                MQTT_DEBUG_PRINT((int8_t *)"sofar ota-------->");
                strcpy(p_ota_info->http_file_url, (cJSON_GetObjectItem(p_request,"url")->valuestring));
                strcpy(p_ota_info->http_file_sign, (cJSON_GetObjectItem(p_request,"sign")->valuestring));
                strcpy(p_ota_info->request_id, (cJSON_GetObjectItem(p_request,"requestId")->valuestring));
                p_ota_info->ota_status = OTA_FILE_DOWNLOAD;
            }
            else
            {
                char *p_request_id = NULL;
                p_request_id = cJSON_GetObjectItem(p_request,"requestId")->valuestring;
                sofar_ota_status_response(p_request_id, OTA_UPGRADE_FAIL, 0, FILE_UPGRADING);
            }
        }
        //安规升级
        else if(file_type == SAFETY)
        {
            p_safety_upgrade_info = sofar_safety_upgrade_info_get();

            if(p_safety_upgrade_info->ota_status == OTA_NONE)
            {
                MQTT_DEBUG_PRINT((int8_t *)"sofar safety upgrade-------->");
                strcpy(p_safety_upgrade_info->http_file_url, (cJSON_GetObjectItem(p_request,"url")->valuestring));
                strcpy(p_safety_upgrade_info->http_file_sign, (cJSON_GetObjectItem(p_request,"sign")->valuestring));
                strcpy(p_safety_upgrade_info->request_id, (cJSON_GetObjectItem(p_request,"requestId")->valuestring));
                p_safety_upgrade_info->ota_status = OTA_FILE_DOWNLOAD;
            }
        }
    }
    cJSON_Delete(p_request);
}
