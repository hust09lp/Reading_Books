#ifndef __MQTT_FC_DATA_H__
#define __MQTT_FC_DATA_H__

#include "mongoose.h"

/**
 * @brief   消防事件列表初始化
 * @param
 * @note
 * @return
 */
void fc_event_list_init(void);

/**
 * @brief   消防事件数据上报
 * @param
 * @note
 * @return
 */
void fc_event_list_upload(void);


/**
 * @brief   消防事件数据上报
 * @param
 * @note
 * @return
 */
void fc_event_data_upload(void);


/**
 * @brief   消防属性数据上报
 * @param
 * @note
 * @return
 */
void fc_property_data_upload(void);

/**
 * @brief   消防监控数据上报
 * @param
 * @note
 * @return
 */
void fc_monitor_data_upload(void);


#endif