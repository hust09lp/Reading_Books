#ifndef __MQTT_CLIENT_SERVICE_H__
#define __MQTT_CLIENT_SERVICE_H__

#include "sdk_log.h"
#include "sdk_public.h"


#if (1)
#define MQTT_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else
#define MQTT_DEBUG_PRINT(...) {do {} while(0);}
#endif

#define SUCCESS     1
#define FAIL        0

#define MQTT_HOST    "eu-emqx.sofarcloud.com"                   //域名
#define MQTT_PORT    28883                                      //端口号
#define MONITOR_REPORT_INTERVAL         300 * 1000              //监控项上报间隔
#define SYS_TIME_SYNC_INTERVAL          24 * 60 * 60 * 1000     //同步系统时间
#define TLS_ENABLE                      1                       //TLS加密使能
#define KEEP_ALIVE                      100  
#define SESSION                         1
#define MQTT_QOS0                       0
#define MQTT_QOS1                       1
#define WILL_CONTENG                    "_disconnect"      

#define CLIENT_ID    "sofarsolar"          //客户端ID
#define USER_NAME    "sofarsolar"          //登录用户名
#define PASSWORD     "sofarsolar"          //登录密码

enum{
    OFFLINE =   0,
    ONLINE
};

enum{
    FREE =   0,
    BUSY
};

enum{
    CFG_ENABLE =   1,
    NETWORK_ENABLE,
    CONNECT_SUCCESS,
};

#define MQTT_PROPERTY_UPLOAD_TIME_INTERVAL      (5 * 60 * 10)       //10分钟上报一次属性数据
#define MQTT_EVENT_LIST_UPLOAD_TIME_INTERVAL    (5 * 60 * 10)       //10分钟上报一次事件全量数据


#define TOPIC_MAX_LEN       128
typedef struct{
    //上报
    char monitor_upload_topic[TOPIC_MAX_LEN];
    char property_upload_topic[TOPIC_MAX_LEN];
    char event_upload_topic[TOPIC_MAX_LEN];
    //属性设置
    char property_set_topic[TOPIC_MAX_LEN];
    char property_set_ack_topic[TOPIC_MAX_LEN];
    //属性读取
    char property_get_topic[TOPIC_MAX_LEN];
    char property_get_ack_topic[TOPIC_MAX_LEN];
    //功能调用
    char func_set_topic[TOPIC_MAX_LEN];
    char func_set_ack_topic[TOPIC_MAX_LEN];
    //固件升级
    char ota_topic[TOPIC_MAX_LEN];
    char ota_ack_topic[TOPIC_MAX_LEN];
    //网络拓扑结构上报
    char topology_topic[TOPIC_MAX_LEN];
    //时区上报上报
    char timezone_topic[TOPIC_MAX_LEN];
}mqtt_topic_t;


#define SN_MAX_LEN      32
#define PV_METER_NUM    3
typedef struct{
    char csu_sn[SN_MAX_LEN];
    char meter_sn[SN_MAX_LEN];
    char pcc_meter_sn[SN_MAX_LEN];
    char pv_meter_sn[PV_METER_NUM][SN_MAX_LEN];
}dev_sn_t;


typedef struct{
    uint32_t    report_interval;        //上报时间间隔
    char        client_id[128];         //客户端ID
    char        username[128];          //用户名
    char        password[128];          //密码
    char        host[128];              //域名
    uint32_t    port;                   //端口号
    uint32_t    keepalive;              //维活时间
    uint32_t    qos;                    //消息质量等级
    uint32_t    session;                //会话
    char        will_content[64];       //遗愿消息
    uint8_t     enable_SSL;             //使能TLS
    char        cafile[64];             //CA证书路径
	uint8_t     mqtt_connect_status;    //mqtt连接状态
    struct mosquitto  *mosq;            //实例句柄
    mqtt_topic_t mqtt_topic;            //主题信息
    dev_sn_t    dev_sn;                 //SN信息
    uint8_t     mqtt_busy;              //mqtt状态
}mqtt_config_t;


#define MAX_TIMER                       7
enum{
    METER_MONITOR_TIMER = 0,
    PCS_MONITOR_TIMER   = 1,
    BMS_MONITOR_TIMER   = 2,
    BAT_STACK_MONITOR_TIMER   = 3,
    FC_MONITOR_TIMER   = 4,
    LC_STACK_MONITOR_TIMER   = 5,
    MQTT_STATUS_TIMER   = 6,
};

#define TIME_OUT_2_SEC			(2)			        // 2S超时
#define MONITOR_TIME_OUT_SEC	(5 * 60)            // 5分钟超时

/**
 * @brief          获取当前时间时间戳
 * @return         [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
long long get_sys_timestamp(void);


/**
 * @brief   获取mqtt配置信息
 * @note
 * @return
 */
mqtt_config_t *mqtt_cfg_get(void);


/**
 * @brief   获取保存上次记录时间点的全局变量的指针
 * @param   index:编号
 * @return  (static修饰的)全局变量的地址作为返回值
 */
sdk_rtc_t *operating_time_get(uint8_t index);


/**
 * @brief   运行数据时间记录
 * @param   [in] p_rtc_time 当前的RTC时间结构体指针
 * @note    g_operating_time_record 记录保存运行的时间
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t operating_time_set(sdk_rtc_t *p_rtc_time, uint8_t index);

/**
 * @brief   消息发布
 * @param   [in] p_topic:主题信息
 * @param   [in] p_payload：数据
 * @param   [in] payload_len：数据长度
 * @note 
 * @return
 */
void mqtt_msg_publish(char *p_topic, uint8_t *p_payload, uint16_t payload_len, uint8_t qos);


/**
 * @brief   mqtt client服务模块初始化
 * @param
 * @note
 * @return
 */
void mqtt_client_module_init(void);

#endif