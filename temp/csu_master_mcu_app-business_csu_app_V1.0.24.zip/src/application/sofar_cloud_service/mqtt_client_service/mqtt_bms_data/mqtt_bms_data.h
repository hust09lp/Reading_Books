#ifndef __MQTT_BMS_DATA_H__
#define __MQTT_BMS_DATA_H__

#include "mongoose.h"


/**
 * @brief   电池簇事件列表初始化
 * @param
 * @note
 * @return
 */
void bms_event_list_init(void);


/**
 * @brief   电池簇事件全量数据上报
 * @param
 * @note
 * @return
 */
void bms_event_list_upload(void);

/**
 * @brief   电池簇事件数据上报
 * @param
 * @note
 * @return
 */
void bms_event_data_upload(void);

/**
 * @brief   电池簇属性数据上报
 * @param
 * @note
 * @return
 */
void bms_property_data_upload(void);

/**
 * @brief   PCS监控数据上报
 * @param
 * @note
 * @return
 */
void bms_monitor_data_upload(void);


#endif