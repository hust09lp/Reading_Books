#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <time.h>
#include "sys/time.h"
#include "signal.h"
#include "sofar_log.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk_public.h"
#include "sofar_errors.h"
#include "mosquitto.h"
#include "mqtt_meter_data.h"
#include "mqtt_pcs_data.h"
#include "mqtt_bms_data.h"
#include "mqtt_bat_stack_data.h"
#include "mqtt_fc_data.h"
#include "mqtt_lc_data.h"
#include "mqtt_csu_data.h"
#include "sofar_ota.h"
#include "mqtt_client_service.h"
#include "user_timer.h"
#include "timestamp.h"
#include "app_common.h"

static mqtt_config_t g_mqtt_cfg = {0};
#define TIME_DIFF 8 * 60 * 60

static void dev_monitor_data_upload_timer_init(void);

/**
 * @brief          获取当前时间时间戳
 * @return         [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
long long get_sys_timestamp(void)
{
    return time(NULL);
}


/**
 * @brief   故障列表初始化
 * @param
 * @return
 */
static void event_list_init(void)
{
    pcs_event_list_init();
    bms_event_list_init();
    fc_event_list_init();
    lc_event_list_init();
}


/**
 * @brief   获取mqtt配置信息
 * @note
 * @return
 */
mqtt_config_t *mqtt_cfg_get(void)
{
    return &g_mqtt_cfg;
}

/**
 * @brief  	检测设备是否离线
 * @return 	1：在线 0：离线
 */
static uint8_t mqtt_is_online(void)
{
    return g_mqtt_cfg.mqtt_connect_status;
}


/**
 * @brief   消息发布
 * @param   [in] p_topic:主题信息
 * @param   [in] p_payload：数据
 * @param   [in] payload_len：数据长度
 * @note 
 * @return
 */
void mqtt_msg_publish(char *p_topic, uint8_t *p_payload, uint16_t payload_len, uint8_t qos)
{
    uint32_t ret = 0;
    
    ret = mosquitto_publish(g_mqtt_cfg.mosq, NULL, p_topic, payload_len, p_payload, qos, 0);
    if(ret != 0)
    {
        MQTT_DEBUG_PRINT((int8_t *)"publish  error\n");
        return;
    }
}


/**
 * @brief   订阅所有下行主题
 * @param   [in] mosq：mosquitto客户端句柄
 * @note
 * @return
 */
static void subscribe_all_topic(struct mosquitto *mosq)
{
    mosquitto_subscribe(mosq, NULL, g_mqtt_cfg.mqtt_topic.property_set_topic, MQTT_QOS1);
    mosquitto_subscribe(mosq, NULL, g_mqtt_cfg.mqtt_topic.property_get_topic, MQTT_QOS1);
    mosquitto_subscribe(mosq, NULL, g_mqtt_cfg.mqtt_topic.func_set_topic, MQTT_QOS1);
    mosquitto_subscribe(mosq, NULL, g_mqtt_cfg.mqtt_topic.ota_topic, MQTT_QOS1);

    // mosquitto_subscribe(mosq, NULL, g_mqtt_cfg.mqtt_topic.monitor_upload_topic, MQTT_QOS1);
    // mosquitto_subscribe(mosq, NULL, g_mqtt_cfg.mqtt_topic.property_upload_topic, MQTT_QOS1);
    // mosquitto_subscribe(mosq, NULL, g_mqtt_cfg.mqtt_topic.event_upload_topic, MQTT_QOS1);
    // mosquitto_subscribe(mosq, NULL, g_mqtt_cfg.mqtt_topic.property_set_ack_topic, MQTT_QOS1);
    // mosquitto_subscribe(mosq, NULL, g_mqtt_cfg.mqtt_topic.property_get_ack_topic, MQTT_QOS1);
    // mosquitto_subscribe(mosq, NULL, g_mqtt_cfg.mqtt_topic.func_set_ack_topic, MQTT_QOS1);
    // mosquitto_subscribe(mosq, NULL, g_mqtt_cfg.mqtt_topic.topology_topic, MQTT_QOS1);
}


/**
 * @brief   主题订阅数据接收回调
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] userdata：用户数据
 * @param   [out] message:云端数据
 * @note
 * @return
 */
static void message_callback(struct mosquitto *mosq, void *userdata, const struct mosquitto_message *message)
{
    if (message->payloadlen)
	{
        MQTT_DEBUG_PRINT((int8_t *)"topic : %s len = %d", message->topic, message->payloadlen);
        MQTT_DEBUG_PRINT((int8_t *)"payload : %s len = %d\n", message->payload, message->payloadlen);
        mqtt_data_parse(mosq, message->topic, message->payload, message->payloadlen);
    }
}


/**
 * @brief   连接状态回调
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] userdata：用户数据
 * @param   [in] result：状态
 * @note
 * @return
 */
static void connect_callback(struct mosquitto *mosq, void *userdata, int result)
{
    internal_shared_data_t *p_shared_data = sdk_shm_internal_shared_data_get();

    if (result == 0)
	{
        MQTT_DEBUG_PRINT((int8_t *)"Connect success\n");
        g_mqtt_cfg.mqtt_connect_status = ONLINE;
        p_shared_data->sofar_cloud_stage = CONNECT_SUCCESS;
        subscribe_all_topic(mosq);

        //上报时区信息
        csu_local_timezone_upload();
    }
}


/**
 * @brief   连接断开状态回调
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] userdata：用户数据
 * @param   [in] result：状态
 * @note
 * @return
 */
static void disconnect_callback(struct mosquitto *mosq, void *userdata, int result)
{
    int ret = 0;

    MQTT_DEBUG_PRINT((int8_t *)"disconnect----->reconenct\n");
    g_mqtt_cfg.mqtt_connect_status = OFFLINE;
    ret = mosquitto_reconnect(mosq);
    if(ret != MOSQ_ERR_SUCCESS)
    {
        MQTT_DEBUG_PRINT((int8_t *)"reconnect error---------->%d\n", ret);
    }
}


/**
 * @brief   主题发布状态回调
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] obj
 * @param   [in] mosq：mosquitto客户端句柄
 * @note
 * @return
 */
static void publish_callback(struct mosquitto *mosq, void *obj, int mid)
{

}

/**
 * @brief   SN信息初始化
 * @param  
 * @note
 * @return
 */
static void dev_sn_init(void)
{
    telemetry_data_t *p_telemetry_data = NULL;
    p_telemetry_data = sdk_shm_telemetry_data_get();
    strcpy(g_mqtt_cfg.dev_sn.csu_sn, (char *)p_telemetry_data->sys_version_telemetry_info.sn_version_number);
    sprintf(g_mqtt_cfg.dev_sn.meter_sn, "%s_00_01", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.dev_sn.pcc_meter_sn, "%s_01_01", g_mqtt_cfg.dev_sn.csu_sn);
    for(uint8_t i = 0; i < PV_METER_NUM; i++)
    {
        sprintf(g_mqtt_cfg.dev_sn.pv_meter_sn[i], "%s_02_%02d", g_mqtt_cfg.dev_sn.csu_sn, i + 1);
    }
    MQTT_DEBUG_PRINT((int8_t *)"csu sn:%s\n", g_mqtt_cfg.dev_sn.csu_sn);
    MQTT_DEBUG_PRINT((int8_t *)"meter sn:%s\n", g_mqtt_cfg.dev_sn.meter_sn);
    MQTT_DEBUG_PRINT((int8_t *)"pcc meter sn:%s\n", g_mqtt_cfg.dev_sn.pcc_meter_sn);
    for(uint8_t i = 0; i < PV_METER_NUM; i++)
    {
        MQTT_DEBUG_PRINT((int8_t *)"pv meter[%d] sn:%s\n", i + 1, g_mqtt_cfg.dev_sn.pv_meter_sn[i]);
    }
}



/**
 * @brief   主题信息初始化
 * @param  
 * @note
 * @return
 */
static void mqtt_topic_init(void)
{
    sprintf(g_mqtt_cfg.mqtt_topic.monitor_upload_topic, "V1/data/%s/json", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.mqtt_topic.property_upload_topic, "V1/prop/%s/json", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.mqtt_topic.event_upload_topic, "V1/event/%s/json", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.mqtt_topic.property_set_topic, "V1/propSet/%s/json", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.mqtt_topic.property_set_ack_topic, "V1/propSetReply/%s/json", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.mqtt_topic.property_get_topic, "V1/propRead/%s/json", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.mqtt_topic.property_get_ack_topic, "V1/propReadReply/%s/json", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.mqtt_topic.func_set_topic, "V1/function/%s/json", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.mqtt_topic.func_set_ack_topic, "V1/functionReply/%s/json", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.mqtt_topic.ota_topic, "V1/ota/%s/json", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.mqtt_topic.ota_ack_topic, "V1/otaReply/%s/json", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.mqtt_topic.topology_topic, "V1/topology/%s/json", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.mqtt_topic.timezone_topic, "V1/timezone/%s/json", g_mqtt_cfg.dev_sn.csu_sn);

    MQTT_DEBUG_PRINT((int8_t *)"monitor_upload_topic:%s\n", g_mqtt_cfg.mqtt_topic.monitor_upload_topic);
    MQTT_DEBUG_PRINT((int8_t *)"property_upload_topic:%s\n", g_mqtt_cfg.mqtt_topic.property_upload_topic);
    MQTT_DEBUG_PRINT((int8_t *)"event_upload_topic:%s\n", g_mqtt_cfg.mqtt_topic.event_upload_topic);
    MQTT_DEBUG_PRINT((int8_t *)"property_set_topic:%s\n", g_mqtt_cfg.mqtt_topic.property_set_topic);
    MQTT_DEBUG_PRINT((int8_t *)"property_set_ack_topic:%s\n", g_mqtt_cfg.mqtt_topic.property_set_ack_topic);
    MQTT_DEBUG_PRINT((int8_t *)"property_get_topic:%s\n", g_mqtt_cfg.mqtt_topic.property_get_topic);
    MQTT_DEBUG_PRINT((int8_t *)"property_get_ack_topic:%s\n", g_mqtt_cfg.mqtt_topic.property_get_ack_topic);
    MQTT_DEBUG_PRINT((int8_t *)"func_set_topic:%s\n", g_mqtt_cfg.mqtt_topic.func_set_topic);
    MQTT_DEBUG_PRINT((int8_t *)"func_set_ack_topic:%s\n", g_mqtt_cfg.mqtt_topic.func_set_ack_topic);
    MQTT_DEBUG_PRINT((int8_t *)"ota_topic:%s\n", g_mqtt_cfg.mqtt_topic.ota_topic);
    MQTT_DEBUG_PRINT((int8_t *)"ota_ack_topic:%s\n", g_mqtt_cfg.mqtt_topic.ota_ack_topic);
    MQTT_DEBUG_PRINT((int8_t *)"topology_topic:%s\n", g_mqtt_cfg.mqtt_topic.topology_topic);
    MQTT_DEBUG_PRINT((int8_t *)"timezone_topic:%s\n", g_mqtt_cfg.mqtt_topic.timezone_topic);
}


/**
 * @brief   mqtt连接配置初始化
 * @param  
 * @note
 * @return
 */
static void mqtt_cfg_init(void)
{
    g_mqtt_cfg.report_interval = MONITOR_REPORT_INTERVAL;
    strcpy(g_mqtt_cfg.host, MQTT_HOST);
    g_mqtt_cfg.port = MQTT_PORT;

    //供测试使用
    // strcpy(g_mqtt_cfg.client_id, CLIENT_ID);
    strcpy(g_mqtt_cfg.username, USER_NAME);
    strcpy(g_mqtt_cfg.password, PASSWORD);

    if(TLS_ENABLE)
    {
        strcpy(g_mqtt_cfg.cafile, "/user/data/sofarcloud.com.cer");
    }
    g_mqtt_cfg.enable_SSL = TLS_ENABLE;
    g_mqtt_cfg.keepalive = KEEP_ALIVE;
    g_mqtt_cfg.session = SESSION;
    strcpy(g_mqtt_cfg.will_content, WILL_CONTENG);
    g_mqtt_cfg.mqtt_busy = FREE;
    dev_sn_init();
    mqtt_topic_init();
    strcpy(g_mqtt_cfg.client_id, g_mqtt_cfg.dev_sn.csu_sn);
}


/**
 * @brief  	时区更新上报
 * @return 	
 */
static void mqtt_tz_update_upload(void)
{
    internal_shared_data_t *p_shared_data = sdk_shm_internal_shared_data_get();

    if((g_mqtt_cfg.mqtt_connect_status == ONLINE) && (BIT_GET(p_shared_data->tz_update_flag, 0)))
    {
        csu_local_timezone_upload();
        BIT_CLR(p_shared_data->tz_update_flag, 0);
    } 
}


/**
 * @brief  	属性数据上报
 * @return 	
 */
static void mqtt_data_property_upload(void)
{
    sofar_ota_info_t *p_sofar_ota_info = NULL;

    constant_parameter_data_t *p_constant_param = sdk_shm_constant_parameter_data_get();
    p_sofar_ota_info = sofar_ota_info_get();

    if((mqtt_is_online()) && (p_sofar_ota_info->ota_status == OTA_NONE))
    {
        bat_stack_topology_data_upload();                  
        csu_property_data_upload();
        meter_property_data_upload();
        if((p_constant_param->cabinet_param_data.rs485_device_enable.bit.photovoltaic_meter) && (p_constant_param->photovoltaic_meter_cfg.meter_cnt > 0))
        {
            pv_meter_property_data_upload();
        }
        if(p_constant_param->cabinet_param_data.rs485_device_enable.bit.backflow_meter > 0)
        {
            pcc_meter_property_data_upload();
        }
        cmu_property_data_upload();
        pcs_property_data_upload();
        bms_property_data_upload();
        bat_stack_property_data_upload();
        fc_property_data_upload();
        lc_property_data_upload();
        mqtt_tz_update_upload();
    } 
}


/**
 * @brief  	事件数据上报
 * @return 	
 */
static void mqtt_data_event_upload(void)
{
    sofar_ota_info_t *p_sofar_ota_info = NULL;
    p_sofar_ota_info = sofar_ota_info_get();

    if((mqtt_is_online()) && (p_sofar_ota_info->ota_status == OTA_NONE))
    {
        pcs_event_data_upload();
        bms_event_data_upload();
        fc_event_data_upload();
        lc_event_data_upload();
    } 
}

/**
 * @brief  	定时事件全量数据上报
 * @return 	
 */
static void mqtt_data_all_event_upload(void)
{
    sofar_ota_info_t *p_sofar_ota_info = NULL;
    p_sofar_ota_info = sofar_ota_info_get();

    if((mqtt_is_online()) && (p_sofar_ota_info->ota_status == OTA_NONE))
    {
        pcs_event_list_upload();
        bms_event_list_upload();
        fc_event_list_upload();
        lc_event_list_upload();
    } 
}


/**
 * @brief   获取子设备数据初始化状态
 * @param   [in] arg
 * @note
 * @return
 */
static uint8_t sub_dev_data_init_status_get(void)
{
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;

    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    if((p_energy_cabinet_data->pcs_data.monitor_data.init_status != SUCCESS) ||
       (p_energy_cabinet_data->bat_stack_data.monitor_data.init_status != SUCCESS) ||
       (p_energy_cabinet_data->fc_data.monitor_data.init_status != SUCCESS) ||
       (p_energy_cabinet_data->lc_data.monitor_data.init_status != SUCCESS) ||
       (p_energy_cabinet_data->cmu_data.sign_data.sign_status != SUCCESS))
    {
        return 0;
    }
    return 1;
}


/**
 * @brief  	CSU监控项定时上报回调
 * @return 	
 */
void csu_monitor_data_upload_timer_cb(void *p_user_arg) 
{
    sofar_ota_info_t *p_sofar_ota_info = NULL;
    p_sofar_ota_info = sofar_ota_info_get();

    if((mqtt_is_online()) && (p_sofar_ota_info->ota_status == OTA_NONE))
    {
        csu_monitor_data_upload();
    }
}

/**
 * @brief  	CSU监控项定时上报
 * @return 	
 */
static void csu_monitor_data_upload_timer(void)
{
    user_timer_hd csu_monitor_timer = NULL;

    csu_monitor_timer = user_timer_create(csu_monitor_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(csu_monitor_timer, 2 * 1000, MONITOR_REPORT_INTERVAL);     
}


/**
 * @brief  	储能单元监控项定时上报回调
 * @return 	
 */
void cmu_monitor_data_upload_timer_cb(void *p_user_arg) 
{
    sofar_ota_info_t *p_sofar_ota_info = NULL;
    p_sofar_ota_info = sofar_ota_info_get();

    if((mqtt_is_online()) && (p_sofar_ota_info->ota_status == OTA_NONE))
    {
        cmu_monitor_data_upload();
    }
}


/**
 * @brief  	储能单元监控项定时上报
 * @return 	
 */
static void cmu_monitor_data_upload_timer(void)
{
    user_timer_hd cmu_monitor_timer = NULL;

    cmu_monitor_timer = user_timer_create(cmu_monitor_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(cmu_monitor_timer, 3 * 1000, MONITOR_REPORT_INTERVAL);     
}


/**
 * @brief  	电表监控项定时上报回调
 * @return 	
 */
void meter_monitor_data_upload_timer_cb(void *p_user_arg) 
{
    sofar_ota_info_t *p_sofar_ota_info = NULL;
    p_sofar_ota_info = sofar_ota_info_get();

    if((mqtt_is_online()) && (p_sofar_ota_info->ota_status == OTA_NONE))
    {
        meter_monitor_data_upload();
    }
}

/**
 * @brief  	电表监控项定时上报
 * @return 	
 */
static void meter_monitor_data_upload_timer(void)
{
    user_timer_hd meter_monitor_timer = NULL;

    meter_monitor_timer = user_timer_create(meter_monitor_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(meter_monitor_timer, 8 * 1000, MONITOR_REPORT_INTERVAL);     
}


user_timer_hd pv_meter_monitor_timer = NULL;
/**
 * @brief   PV电表数据定时任务回调
 * @param
 * @note
 * @return
 */
void pv_meter_monitor_data_upload_timer_cb(void *p_user_arg)
{
    static uint8_t pv_meter_cnt = 0;
    constant_parameter_data_t *p_constant_param = sdk_shm_constant_parameter_data_get();

    if((mqtt_is_online()) && (p_constant_param->cabinet_param_data.rs485_device_enable.bit.photovoltaic_meter) && (p_constant_param->photovoltaic_meter_cfg.meter_cnt > 0))
    {
        pv_meter_monitor_data_upload(pv_meter_cnt);
        pv_meter_cnt++;
        user_timer_set_timeout(pv_meter_monitor_timer, 1 * 1000, false);
        if(pv_meter_cnt >= p_constant_param->photovoltaic_meter_cfg.meter_cnt)
        {
            pv_meter_cnt = 0;
            user_timer_set_timeout(pv_meter_monitor_timer, MONITOR_REPORT_INTERVAL - p_constant_param->photovoltaic_meter_cfg.meter_cnt, true);
        }
    }
}


/**
 * @brief   PV电表数据定时上报
 * @param
 * @note
 * @return
 */
void pv_meter_monitor_data_upload_timer(void)
{
    

    pv_meter_monitor_timer = user_timer_create(pv_meter_monitor_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(pv_meter_monitor_timer, 12 * 1000, MONITOR_REPORT_INTERVAL);    
}


/**
 * @brief   PCC电表数据定时任务回调
 * @param
 * @note
 * @return
 */
void pcc_meter_monitor_data_upload_timer_cb(void *p_user_arg)
{
    sofar_ota_info_t *p_sofar_ota_info = NULL;

    constant_parameter_data_t *p_constant_para = sdk_shm_constant_parameter_data_get();
    p_sofar_ota_info = sofar_ota_info_get();

    if((mqtt_is_online()) && (p_sofar_ota_info->ota_status == OTA_NONE) && (p_constant_para->cabinet_param_data.rs485_device_enable.bit.backflow_meter))
    {
        pcc_meter_monitor_data_upload();
    }
}


/**
 * @brief   PCC电表数据定时上报
 * @param
 * @note
 * @return
 */
void pcc_meter_monitor_data_upload_timer(void)
{
    user_timer_hd pcc_meter_monitor_timer = NULL;

    pcc_meter_monitor_timer = user_timer_create(pcc_meter_monitor_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(pcc_meter_monitor_timer, 13 * 1000, MONITOR_REPORT_INTERVAL);    
}



/**
 * @brief  	PCS监控项定时上报回调
 * @return 	
 */
void pcs_monitor_data_upload_timer_cb(void *p_user_arg) 
{
    sofar_ota_info_t *p_sofar_ota_info = NULL;
    p_sofar_ota_info = sofar_ota_info_get();

    if((mqtt_is_online()) && (p_sofar_ota_info->ota_status == OTA_NONE))
    {
        pcs_monitor_data_upload();
    }
}

/**
 * @brief  	PCS监控项定时上报
 * @return 	
 */
static void pcs_monitor_data_upload_timer(void)
{
    user_timer_hd pcs_monitor_timer = NULL;

    pcs_monitor_timer = user_timer_create(pcs_monitor_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(pcs_monitor_timer, 15 * 1000, MONITOR_REPORT_INTERVAL);    
}


/**
 * @brief  	BMS监控项定时上报回调
 * @return 	
 */
void bms_monitor_data_upload_timer_cb(void *p_user_arg) 
{
    sofar_ota_info_t *p_sofar_ota_info = NULL;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;

    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    p_sofar_ota_info = sofar_ota_info_get();

    if((mqtt_is_online()) && (p_sofar_ota_info->ota_status == OTA_NONE))
    {
        for(uint8_t i = 0; i < p_energy_cabinet_data->cmu_data.sign_data.bcu_num; i++)
        {
            bms_monitor_data_upload();
        }
    }
}

/**
 * @brief  	BMS监控项定时上报
 * @return 	
 */
static void bms_monitor_data_upload_timer(void)
{
    user_timer_hd bms_monitor_timer = NULL;

    bms_monitor_timer = user_timer_create(bms_monitor_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(bms_monitor_timer, 20 * 1000, MONITOR_REPORT_INTERVAL);   
}


/**
 * @brief  	电池堆监控项定时上报回调
 * @return 	
 */
void bat_stack_monitor_data_upload_timer_cb(void *p_user_arg) 
{
    sofar_ota_info_t *p_sofar_ota_info = NULL;
    p_sofar_ota_info = sofar_ota_info_get();

    if((mqtt_is_online()) && (p_sofar_ota_info->ota_status == OTA_NONE))
    {
        bat_stack_monitor_data_upload();
    }
}

/**
 * @brief  	电池堆监控项定时上报
 * @return 	
 */
static void bat_stack_monitor_data_upload_timer(void)
{
    user_timer_hd bs_monitor_timer = NULL;

    bs_monitor_timer = user_timer_create(bat_stack_monitor_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(bs_monitor_timer, 25 * 1000, MONITOR_REPORT_INTERVAL);    
}


/**
 * @brief  	消防监控项定时上报回调
 * @return 	
 */
void fc_monitor_data_upload_timer_cb(void *p_user_arg) 
{
    sofar_ota_info_t *p_sofar_ota_info = NULL;
    p_sofar_ota_info = sofar_ota_info_get();

    if((mqtt_is_online()) && (p_sofar_ota_info->ota_status == OTA_NONE))
    {
        fc_monitor_data_upload();
    }
}

/**
 * @brief  	消防监控项定时上报
 * @return 	
 */
static void fc_monitor_data_upload_timer(void)
{
    user_timer_hd fc_monitor_timer = NULL;

    fc_monitor_timer = user_timer_create(fc_monitor_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(fc_monitor_timer, 30 * 1000, MONITOR_REPORT_INTERVAL);    
}


/**
 * @brief  	液冷监控项定时上报回调
 * @return 	
 */
void lc_monitor_data_upload_timer_cb(void *p_user_arg) 
{
    sofar_ota_info_t *p_sofar_ota_info = NULL;
    p_sofar_ota_info = sofar_ota_info_get();

    if((mqtt_is_online()) && (p_sofar_ota_info->ota_status == OTA_NONE))
    {
        lc_monitor_data_upload();
    }
}

/**
 * @brief  	液冷监控项定时上报
 * @return 	
 */
static void lc_monitor_data_upload_timer(void)
{
    user_timer_hd lc_monitor_timer = NULL;

    lc_monitor_timer = user_timer_create(lc_monitor_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(lc_monitor_timer, 35 * 1000, MONITOR_REPORT_INTERVAL);   
}


/**
 * @brief  	定时同步系统时间回调
 * @return 	
 */
void sys_time_sync_timer_cb(void *p_user_arg) 
{
    sofar_ota_info_t *p_sofar_ota_info = NULL;
    p_sofar_ota_info = sofar_ota_info_get();

    if((mqtt_is_online()) && (p_sofar_ota_info->ota_status == OTA_NONE))
    {
        csu_ntp_event_upload();
    }
}

/**
 * @brief  	定时同步系统时间
 * @return 	
 */
static void sys_time_sync_timer(void)
{
    user_timer_hd ntp_monitor_timer = NULL;

    ntp_monitor_timer = user_timer_create(sys_time_sync_timer_cb, NULL);
    user_timer_detail_set_timeout(ntp_monitor_timer, 40 * 1000, SYS_TIME_SYNC_INTERVAL);   
}



/**
 * @brief   实时数据上报服务
 * @param   [in] arg
 * @note
 * @return
 */
static void *mqtt_real_time_upload_service(void *arg)
{

    while(!mqtt_is_online())
    {
        sleep(2);
    }
    
    dev_monitor_data_upload_timer_init();

    while(1)
	{  
        // 属性数据上报，即时上报
        mqtt_data_property_upload();
        //事件数据上报，即时上报
        mqtt_data_event_upload();
        //定时上报事件全量数据
        mqtt_data_all_event_upload();
        usleep(1000 * 200);
    }
    return NULL;
}


/**
 * @brief   实时数据上报线程
 * @param
 * @note
 * @return
 */
void mqtt_real_time_upload_init(void)
{
	pthread_t real_time_upload;
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	if(pthread_create(&real_time_upload, &attr, mqtt_real_time_upload_service, NULL) != 0)
	{
		perror("pthread_create tcp server service");
	}
	pthread_attr_destroy(&attr);
}


/**
 * @brief  	获取网路状态
 * @return 	0：没有外网 1：有外网可连接服务器
 */
static uint8_t get_curr_net_status(void)
{
    char *p_host[3] = {
        "www.google.com",
        "www.baidu.com",
        "cn.pool.ntp.org"
    };
    static uint32_t i = 0;
    char cmd[256] = {0};
    char tmp_buff[32] = {0};
    FILE *fp = NULL;

    //ping小桔服务器，查看网络状态
    snprintf(cmd, 256, "ping -c 1 -W 1 %s | awk '/packet loss/{print $7}'", p_host[i % 3]);
	fp = popen(cmd,"r");

    fread(tmp_buff, 1, sizeof(tmp_buff), fp);
    i++;
    printf("ping ack:%s\n", tmp_buff);
	if(!strncmp(tmp_buff, "0%", strlen("0%")))
	{
		pclose(fp);
		return 1;
	}
    pclose(fp);
    return 0;
}


/**
 * @brief  	定时器初始化
 * @return
 */
static void dev_monitor_data_upload_timer_init(void)
{
    //开启各个上报定时器
    csu_monitor_data_upload_timer();
    cmu_monitor_data_upload_timer();
    meter_monitor_data_upload_timer();
    pv_meter_monitor_data_upload_timer();
    pcc_meter_monitor_data_upload_timer();
    pcs_monitor_data_upload_timer();
    bms_monitor_data_upload_timer();
    bat_stack_monitor_data_upload_timer();
    fc_monitor_data_upload_timer();
    lc_monitor_data_upload_timer();
    //同步系统时间
    sys_time_sync_timer();
}


/**
 * @brief   mqtt client服务线程
 * @param   [in] arg
 * @note
 * @return
 */
static void *mqtt_client_service(void *arg)
{
    struct mosquitto  *mosq = NULL;
    internal_shared_data_t *p_shared_data = sdk_shm_internal_shared_data_get();
    
    //libmosquitto 库初始化
    mosquitto_lib_init();

    //mqtt连接配置初始化
    mqtt_cfg_init();

    //创建mosquitto客户端
    mosq = mosquitto_new(g_mqtt_cfg.client_id, g_mqtt_cfg.session, NULL);
    if (!mosq)
	{
        MQTT_DEBUG_PRINT((int8_t *)"create client failed..\n");
        mosquitto_lib_cleanup();
        return NULL;
    }
    g_mqtt_cfg.mosq = mosq;

    //加载用户名和密码
    mosquitto_username_pw_set(g_mqtt_cfg.mosq, g_mqtt_cfg.username, g_mqtt_cfg.password);
    //设置重连信息
    mosquitto_reconnect_delay_set(g_mqtt_cfg.mosq, 2, 10, true);

    //设置 SSL/TLS 参数
    if(g_mqtt_cfg.enable_SSL)
    {
        mosquitto_tls_set(g_mqtt_cfg.mosq, "/user/conf/sofarcloud.com.cer", NULL, NULL, NULL, NULL);
        mosquitto_tls_opts_set(g_mqtt_cfg.mosq, 0, NULL, NULL);
    }

    // //注册回调
    mosquitto_connect_callback_set(g_mqtt_cfg.mosq, connect_callback);
    mosquitto_message_callback_set(g_mqtt_cfg.mosq, message_callback);
    mosquitto_publish_callback_set(g_mqtt_cfg.mosq, publish_callback);
    mosquitto_disconnect_callback_set(g_mqtt_cfg.mosq, disconnect_callback);

    //等待网络连接
    p_shared_data->sofar_cloud_stage = CFG_ENABLE;
    while (!get_curr_net_status())
    {
        sleep(2);
    }

    p_shared_data->sofar_cloud_stage = NETWORK_ENABLE;
    while (!sub_dev_data_init_status_get())
    {
        sleep(2);
    }

    //连接服务器
    if (mosquitto_connect(g_mqtt_cfg.mosq, g_mqtt_cfg.host, g_mqtt_cfg.port, g_mqtt_cfg.keepalive) != MOSQ_ERR_SUCCESS)
    {
        printf("unable to connect.\n");
        mosquitto_reconnect(g_mqtt_cfg.mosq);
        usleep(1000 * 2000);
    }

    //故障列表初始化
    event_list_init();

    //数据上报初始化
    mqtt_real_time_upload_init();
	while(1)
	{   
        if(mosquitto_loop_forever(mosq, 100, 1) != MOSQ_ERR_SUCCESS)
        {
            mosquitto_reconnect(mosq);
        }
		usleep(1000 * 200);
	}
}

/**
 * @brief   mqtt client服务模块初始化
 * @param
 * @note
 * @return
 */
void mqtt_client_module_init(void)
{
	pthread_t mqtt_client;
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	if(pthread_create(&mqtt_client, &attr, mqtt_client_service, NULL) != 0)
	{
		perror("pthread_create tcp server service");
	}
	pthread_attr_destroy(&attr);
}