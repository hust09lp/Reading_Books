#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include "data_shm.h"
#include "sdk_shm.h"
#include "errors.h"
#include "sofar_log.h"
#include "mqtt_client_service.h"
#include "sofar_ota.h"



/**
 * @brief   判断首航云服务是否开启
 * @param 
 * @note
 * @return 1：开启  0：未开启
 */
static uint8_t if_sofar_cloud_service_enable(void)
{
    internal_shared_data_t *p_shared_para = sdk_shm_internal_shared_data_get();

    return (p_shared_para->sofar_cloud_enable);
}

/**
 * @brief   首航云服务进程
 * @param   [in] arg
 * @note
 * @return
 */
int main(int argc, char *argv[])
{
	int32_t ret;

    //日志初始化
	log_init((int8_t *)PATH_CONF);
    log_set_level(LOG_LVL_DEBUG);
    sleep(5);
    //共享内存初始化
	ret = common_data_init();  
	if(ret != 0)
	{
		return 0;
	}
    sleep(10);

    while (!if_sofar_cloud_service_enable())
    {
        MQTT_DEBUG_PRINT((int8_t *)"sofar cloud service not enable\n");
        sleep(5);
    }
    
    //mqtt client务模块初始化
    mqtt_client_module_init();

    //升级模块初始化
    sofar_ota_module_init();

	while(1)
	{
		sleep(1);
	}

	return 0;
}