#ifndef __ZCS_CERT_H__
#define __ZCS_CERT_H__

#include "sdk_log.h"

#if (1)
#define ZCS_CERT_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else
#define ZCS_CERT_DEBUG_PRINT(...) {do {} while(0);}
#endif

#define PRIVATE_PATH    "/user/conf/ssl_conf/privkey.pem"
#define PUBLIC_PATH     "/user/conf/ssl_conf/pubkey.pem"
#define CSR_PATH        "/user/conf/ssl_conf/domain.csr"
#define CERT_PATH       "/user/conf/ssl_conf/zcs.pem"
#define CA_PATH         "/user/conf/ssl_conf/AmazonRootCA1.pem"

#define WHITE_LIST_URL  "https://x22kooigla.execute-api.eu-west-1.amazonaws.com/beta/whitelist"
#define NEW_CERT_URL    "https://x22kooigla.execute-api.eu-west-1.amazonaws.com/beta/newcert"

/**
 * @brief   ZCS联网证书获取
 * @param
 * @note
 * @return 0:成功 -1:失败
 */
int8_t zcs_cert_get(void);


#endif