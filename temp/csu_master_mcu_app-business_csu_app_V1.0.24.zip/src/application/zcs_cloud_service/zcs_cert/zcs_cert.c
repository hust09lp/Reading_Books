#include <stdlib.h>
#include <string.h>
#include <pem.h>
#include "zcs_cert.h"
#include "curl.h"
#include "easy.h"
#include "cJSON.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "mqtt_client_service.h"


/**
 * @brief   本地公钥、私钥以及CSR证书获取
 * @param
 * @note
 * @return 0:成功 -1:失败
 */
static int8_t zcs_dev_local_cfg_info_apply(void)
{
    EVP_PKEY_CTX *p_ctx = NULL;
    EVP_PKEY *p_key = NULL;
    EVP_PKEY *p_param = NULL;
    X509_REQ *p_req = NULL;
    X509_NAME *p_subj = NULL;
    FILE *p_pub_file = NULL;
    FILE *p_pri_file = NULL;
    FILE *p_csr_file = NULL;
    char csu_sn[32] = {0};                    //SN
    telemetry_data_t *p_telemetry_data = NULL;

    p_telemetry_data = sdk_shm_telemetry_data_get();
    strcpy(csu_sn, (char *)p_telemetry_data->sys_version_telemetry_info.sn_version_number);

    p_ctx = EVP_PKEY_CTX_new_id(EVP_PKEY_RSA, NULL);
    p_param = EVP_PKEY_new();

    if (EVP_PKEY_keygen_init(p_ctx) <= 0) 
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"Error initializing RSA key generation\n");
        goto error;
    }
    if (EVP_PKEY_CTX_set_rsa_keygen_bits(p_ctx, 2048) <= 0) 
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"Error setting RSA key size\n");
        goto error;
    }

    if (EVP_PKEY_keygen(p_ctx, &p_key) <= 0) 
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"Error generating RSA key\n");
        goto error;
    }

    EVP_PKEY_CTX_free(p_ctx);
 
    // 保存公钥到文件
    p_pub_file = fopen(PUBLIC_PATH, "w");
    if (!p_pub_file) 
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"Error opening public.pem for writing\n");
        goto error;
    }
    if (PEM_write_PUBKEY(p_pub_file, p_key) != 1) 
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"Error writing public key\n");
        goto error;
    }
    fclose(p_pub_file);

    // 保存私钥到文件
    p_pri_file = fopen(PRIVATE_PATH, "w");
    if (!p_pri_file) 
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"Error opening private.pem for writing\n");
        goto error;
    }
    if (PEM_write_PrivateKey(p_pri_file, p_key, NULL, NULL, 0, NULL, NULL) != 1) 
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"Error writing private key\n");
        goto error;
    }
    fclose(p_pri_file);

    // 生成 CSR 文件
    p_req = X509_REQ_new();
    if (!p_req) 
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"Error creating X509_REQ object\n");
        goto error;
    }

    // 创建 X509_NAME 对象并初始化
    p_subj = X509_NAME_new();
    if (!p_subj) 
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"Error creating X509_NAME object\n");
        goto error;
    }

    // 添加条目到 X509_NAME 对象
    if (!X509_NAME_add_entry_by_txt(p_subj, "C", MBSTRING_ASC, (const unsigned char *)"AU", -1, -1, 0)) 
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"Error adding entry to X509_NAME object\n");
        X509_NAME_free(p_subj); // 释放 subj 对象
        goto error;
    }
    if (!X509_NAME_add_entry_by_txt(p_subj, "CN", MBSTRING_ASC, (const unsigned char *)csu_sn, -1, -1, 0)) 
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"Error adding entry to X509_NAME object\n");
        X509_NAME_free(p_subj); // 释放 subj 对象
        goto error;
    }

    // 将 X509_NAME 对象设置为 X509_REQ 的主题信息
    if (!X509_REQ_set_subject_name(p_req, p_subj)) 
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"Error setting subject name in X509_REQ\n");
        X509_NAME_free(p_subj); // 释放 subj 对象
        goto error;
    }
    // 将公钥设置到 CSR
    if (!X509_REQ_set_pubkey(p_req, p_key)) 
    {
        printf("Error setting public key in X509_REQ\n");
        goto error;
    }

    // 签署 CSR
    if (!X509_REQ_sign(p_req, p_key, EVP_sha256())) 
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"Error signing X509_REQ\n");
        goto error;
    }

    // 保存 CSR 到文件
    p_csr_file = fopen(CSR_PATH, "w");
    if (!p_csr_file) 
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"Error opening example.csr for writing\n");
        goto error;
    }
    if (!PEM_write_X509_REQ(p_csr_file, p_req)) 
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"Error writing CSR\n");
        goto error;
    }
    fclose(p_csr_file);

    X509_NAME_free(p_subj);
    EVP_PKEY_free(p_key);
    EVP_PKEY_free(p_param);
    X509_REQ_free(p_req);

    ZCS_CERT_DEBUG_PRINT((int8_t *)"Public and private keys, and CSR have been saved.\n");
    return 0;

error:
    if(p_key != NULL)
    {
        EVP_PKEY_free(p_key);
    }
    if(p_param != NULL)
    {
        EVP_PKEY_free(p_param);
    }
    if(p_req != NULL)
    {
        X509_REQ_free(p_req);
    }
    return -1;
}


/**
 * @brief   base64加密
 * @param
 * @note
 * @return
 */
static void base64_encode(const unsigned char *p_data, int data_len, char **pp_out, int *p_out_len) 
{
    BIO *bmem, *b64;
    BUF_MEM *bptr;
 
    b64 = BIO_new(BIO_f_base64());
    bmem = BIO_new(BIO_s_mem());
    b64 = BIO_push(b64, bmem);
    BIO_write(b64, p_data, data_len);
    BIO_flush(b64);
    BIO_get_mem_ptr(b64, &bptr);
    
    *p_out_len = bptr->length;
    *pp_out = (char *)malloc(bptr->length + 1);
    memcpy(*pp_out, bptr->data, bptr->length);
    (*pp_out)[bptr->length] = '\0';
 
    BIO_free_all(b64);
}


/**
 * @brief   对文件进行base64加密
 * @param   [in]p_path:文件路径
 * @param   [out]p_out:输入加密字符串
 * @note
 * @return 0:成功 -1:失败
 */
static int8_t get_file_content_encode_base64(char *p_path, char *p_out)
{
    FILE *p_file = NULL;
    char *p_data = NULL;
    char *p_encoded_data = NULL;
    int encoded_len;

    p_file = fopen(p_path, "rb");
    if (!p_file) 
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"File opening failed");
        return -1;
    }
 
    fseek(p_file, 0, SEEK_END);
    long fsize = ftell(p_file);
    fseek(p_file, 0, SEEK_SET);
 
    p_data = malloc(fsize);
    fread(p_data, fsize, 1, p_file);
    fclose(p_file);
    base64_encode((unsigned char *)p_data, fsize, &p_encoded_data, &encoded_len);
    strcpy(p_out, p_encoded_data);
 
    free(p_data);
    free(p_encoded_data);
 
    return 0;
}


static size_t WriteCallback(void *contents, size_t size, size_t nmemb, void *userp) 
{
    size_t realsize = size * nmemb;
    char *p_str = NULL;
    cJSON *p_data = NULL;
    char *p_cert = NULL;
    FILE *p_cert_file = NULL;

    p_str = (char *)contents;
    // 这里可以处理获取到的数据，例如保存到文件或者打印出来等
    // 这里简单起见，直接输出接收到的数据
    ZCS_CERT_DEBUG_PRINT((int8_t *)"%s", p_str);
	p_data = cJSON_Parse(p_str);
	if(p_data == NULL)
	{
		ZCS_CERT_DEBUG_PRINT((int8_t *)"parse request failed.");
		return 0;
	}
	if(NULL == cJSON_GetObjectItem(p_data, "certificate"))
	{
		ZCS_CERT_DEBUG_PRINT((int8_t *)"action is NULL");
		cJSON_Delete(p_data);
		return 0;
	}    
    p_cert = cJSON_GetObjectItem(p_data, "certificate")->valuestring;

    p_cert_file = fopen(CERT_PATH, "w");
    if (!p_cert_file) 
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"Error opening zcs.cert writing\n");
        cJSON_Delete(p_data);
        return 0;
    }
    fwrite(p_cert, 1, strlen(p_cert), p_cert_file);
	fclose(p_cert_file);
    cJSON_Delete(p_data);

    return realsize;
}


/**
 * @brief   白名单申请
 * @param
 * @note
 * @return 0:成功 -1:失败
 */
static int8_t zcs_dev_white_list_apply(void)
{
    int8_t ret = 0;
	cJSON *p_resp_root = NULL;
	char *p = NULL;
    char public_key_encode[2048] = {0};
    CURL *p_curl = NULL;
    CURLcode res = CURLE_OK;
    int i = 0, j = 0;
    char csu_sn[32] = {0};                    //SN
    telemetry_data_t *p_telemetry_data = NULL;

    p_telemetry_data = sdk_shm_telemetry_data_get();
    strcpy(csu_sn, (char *)p_telemetry_data->sys_version_telemetry_info.sn_version_number);

    ret = get_file_content_encode_base64(PUBLIC_PATH, public_key_encode);
    if(ret != 0)
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"get public key encode error");
        return -1;
    }
    //删除换行符
    for (i = 0, j = 0; i < strlen(public_key_encode); i++) 
    {
        if (public_key_encode[i] != '\n') 
        {
            public_key_encode[j] = public_key_encode[i]; 
            j++;
        }
    }
    public_key_encode[j] = '\0';
    ZCS_CERT_DEBUG_PRINT((int8_t *)"get public key encode:%s", public_key_encode);

	p_resp_root = cJSON_CreateObject();
	if(p_resp_root == NULL)
	{
		ZCS_CERT_DEBUG_PRINT((int8_t *)"create json obj failed.");
		return -1;
	}

	cJSON_AddStringToObject(p_resp_root,"deviceId", csu_sn);
    cJSON_AddStringToObject(p_resp_root,"pubKey", public_key_encode);
    cJSON_AddStringToObject(p_resp_root,"thingDef", "power_magic_v1");
    cJSON_AddStringToObject(p_resp_root,"hwVer", "0");
	cJSON_AddNumberToObject(p_resp_root,"dateProduced", 20240802);

	p = cJSON_PrintUnformatted(p_resp_root);
    ZCS_CERT_DEBUG_PRINT((int8_t *)"json:%s", p);

    curl_global_init(CURL_GLOBAL_DEFAULT); 
    p_curl = curl_easy_init();

    struct curl_slist *headers = NULL;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    curl_easy_setopt(p_curl, CURLOPT_HTTPHEADER, headers);

    curl_easy_setopt(p_curl, CURLOPT_URL, WHITE_LIST_URL);
    curl_easy_setopt(p_curl, CURLOPT_SSL_VERIFYHOST, 0);
    curl_easy_setopt(p_curl, CURLOPT_SSL_VERIFYPEER, 0);
    curl_easy_setopt(p_curl, CURLOPT_POSTFIELDS, p);
    // curl_easy_setopt(p_curl, CURLOPT_WRITEFUNCTION, WriteCallback);

    res = curl_easy_perform(p_curl);
    if (res != CURLE_OK) 
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"error: %s\n", curl_easy_strerror(res));
        curl_easy_cleanup(p_curl);
        cJSON_Delete(p_resp_root);
        free(p);
        return -1;
    }
    else
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"ok\n");
    }
    curl_easy_cleanup(p_curl);
    cJSON_Delete(p_resp_root);
    free(p);
 
    return 0;
}


/**
 * @brief   证书申请
 * @param
 * @note
 * @return 0:成功 -1:失败
 */
static int8_t zcs_dev_new_cert_apply(void)
{
    int8_t ret = 0;
    char csr_encode[2048] = {0};
    char csr_header[4096] = {0};
    CURL *p_curl = NULL;
    CURLcode res = CURLE_OK;
    int i = 0, j = 0;

    ret = get_file_content_encode_base64(CSR_PATH, csr_encode);
    if(ret != 0)
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"get csr encode error");
        return -1;
    }
    
    //删除换行符
    for (i = 0, j = 0; i < strlen(csr_encode); i++) 
    {
        if (csr_encode[i] != '\n') 
        {
            csr_encode[j] = csr_encode[i]; 
            j++;
        }
    }
    csr_encode[j] = '\0';
    ZCS_CERT_DEBUG_PRINT((int8_t *)"get csr encode:%s", csr_encode);

    curl_global_init(CURL_GLOBAL_DEFAULT); 
    p_curl = curl_easy_init();

    struct curl_slist *headers = NULL;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    headers = curl_slist_append(headers, "Content-Length: 0");
    sprintf(csr_header, "device-csr:%s", csr_encode);
    headers = curl_slist_append(headers, csr_header);

    curl_easy_setopt(p_curl, CURLOPT_POST, 0);
    curl_easy_setopt(p_curl, CURLOPT_URL, NEW_CERT_URL);
    curl_easy_setopt(p_curl, CURLOPT_SSL_VERIFYHOST, 0);
    curl_easy_setopt(p_curl, CURLOPT_SSL_VERIFYPEER, 0);
    curl_easy_setopt(p_curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(p_curl, CURLOPT_POSTFIELDS, "{}");
    curl_easy_setopt(p_curl, CURLOPT_WRITEFUNCTION, WriteCallback);

    res = curl_easy_perform(p_curl);
    if (res != CURLE_OK) 
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"error: %s\n", curl_easy_strerror(res));
        curl_easy_cleanup(p_curl);
        return -1;
    }
    else
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"ok\n");
    }

    curl_easy_cleanup(p_curl);
 
    return 0;
}


/**
 * @brief   ZCS联网证书获取
 * @param
 * @note
 * @return 0:成功 -1:失败
 */
int8_t zcs_cert_get(void)
{
    int8_t ret = 0;

    //获取公钥、私钥以及CSR证书
    ret = zcs_dev_local_cfg_info_apply();
    if(ret == -1)
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"zcs_dev_local_cfg_info_apply error: %d\n", ret);
        return ret;
    }
    //第一步，添加白名单
    ret = zcs_dev_white_list_apply();
    if(ret == -1)
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"zcs_dev_white_list_apply error: %d\n", ret);
        return ret;
    }
    //第二步，申请证书
    ret = zcs_dev_new_cert_apply();
    if(ret == -1)
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"zcs_dev_new_cert_apply error: %d\n", ret);
        return ret;
    }

    return 0;
}