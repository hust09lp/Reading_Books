#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include "sofar_log.h"
#include "sofar_errors.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk_public.h"
#include "mosquitto.h"
#include "cJSON.h"
#include "mqtt_client_service.h"

static bms_property_data_t g_property_data[CLUSTER_NUMBER] = {0};
static tcp_bms_data_t g_bms_data[CLUSTER_NUMBER] = {0};

/**
 * @brief   电池簇事件列表初始化
 * @param
 * @note
 * @return
 */
void bms_event_list_init(void)
{
    for(uint8_t i = 0; i < CLUSTER_NUMBER; i++)
    {
        for(uint8_t level = 0; level < WARN_LEVEL_MAX; level++)
        {
            for(uint8_t j = 0; j < BMS_MAX_EVENT_ITEM; j++)
            {
                g_bms_data[i].event_data[level][j].event_code = 1;
            }
        }
    }
}


/**
 * @brief   电池簇事件数据上报
 * @param
 * @note
 * @return
 */
void bms_event_data_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    char *p = NULL;
    uint8_t upload_flag = 0;
    static uint8_t cluster_index = 0;
    char str[10] = {0};
    char date[32] = {0};
    sdk_rtc_t rtc_time = {0};
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
    
    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    if(p_energy_cabinet_data == NULL)
    {
        return;
    }

    //获取系统时钟时间
    if (sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time) != SF_OK)
    {
        MQTT_DEBUG_PRINT((int8_t *)"rtc get failed");
    }

    sprintf(date, "%04d-%02d-%02d %02d:%02d:%02d", rtc_time.tm_year + 2000, rtc_time.tm_mon, rtc_time.tm_day,
                                                   rtc_time.tm_hour, rtc_time.tm_min, rtc_time.tm_sec);
    
    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_energy_cabinet_data->cmu_data.sign_data.bcu_sn[cluster_index]);
    cJSON_AddStringToObject(p_root, "product", "bms");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());
    cJSON_AddStringToObject(p_root, "date", date);

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }

    for(uint8_t level = 0; level < WARN_LEVEL_MAX; level++)
    {
        for(uint8_t i = 0; i < BMS_MAX_EVENT_ITEM; i++)
        {
            if(g_bms_data[cluster_index].event_data[level][i].event_code != p_energy_cabinet_data->bms_data[cluster_index].event_data[level][i].event_code)
            {
                p_data_item = cJSON_CreateObject();
                if(p_data_item == NULL)
                {
                    MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
                    cJSON_Delete(p_root);
                    return;
                }
                memset(str, 0, sizeof(str));
                sprintf(str, "%d", p_energy_cabinet_data->bms_data[cluster_index].event_data[level][i].event_id);
                cJSON_AddStringToObject(p_data_item, "eventId", str);
                memset(str, 0, sizeof(str));
                sprintf(str, "%d", p_energy_cabinet_data->bms_data[cluster_index].event_data[level][i].event_code);
                cJSON_AddStringToObject(p_data_item, "status", str);
                memset(str, 0, sizeof(str));
                sprintf(str, "%d", p_energy_cabinet_data->bms_data[cluster_index].event_data[level][i].event_level);
                cJSON_AddStringToObject(p_data_item, "type", str);
                cJSON_AddNumberToObject(p_data_item, "eventTime", p_energy_cabinet_data->bms_data[cluster_index].event_data[level][i].event_time);
                cJSON_AddItemToArray(p_data_array,  p_data_item);
                memcpy(&g_bms_data[cluster_index].event_data[level][i], &p_energy_cabinet_data->bms_data[cluster_index].event_data[level][i], sizeof(bms_event_data_t));
                upload_flag = 1;
            }
        }
    }

    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);
    if(upload_flag)
    {
        mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.event_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    }
    free(p);

    cluster_index++;
    if(cluster_index >= p_energy_cabinet_data->cmu_data.sign_data.bcu_num)
    {
        cluster_index = 0;
    }
}

/**
 * @brief   电池簇属性数据上报
 * @param
 * @note
 * @return
 */
void bms_property_data_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    cJSON *p_base_config = NULL;
    char *p = NULL;

    static uint8_t cluster_index = 0;
    static uint8_t all_data_upload_flag = 1;
    uint8_t upload_flag = 0;
    static uint16_t upload_tick_cnt = 0;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();

    //上报计时，对精确度要求不高
    if(upload_tick_cnt < MQTT_PROPERTY_UPLOAD_TIME_INTERVAL)
    {
        upload_tick_cnt++;
    }
    else
    {
        all_data_upload_flag = 1;
        // upload_tick_cnt = 0;
    } 
    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    if(p_energy_cabinet_data == NULL)
    {
        return;
    }
    
    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_energy_cabinet_data->bms_data[cluster_index].property_data.bms_sn);
    cJSON_AddStringToObject(p_root, "product", "bms");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_base_config = cJSON_CreateObject();
    if(p_base_config == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    //SN
    if((strcmp((char *)g_property_data[cluster_index].bms_sn, (char *)p_energy_cabinet_data->bms_data[cluster_index].property_data.bms_sn)) || all_data_upload_flag)
    {
        cJSON_AddStringToObject(p_base_config, "bcu$sn", (char *)p_energy_cabinet_data->bms_data[cluster_index].property_data.bms_sn);
        strcpy((char *)g_property_data[cluster_index].bms_sn, (char *)p_energy_cabinet_data->bms_data[cluster_index].property_data.bms_sn);
        upload_flag = 1;
    }
    //电芯数量
    if((g_property_data[cluster_index].cell_num != p_energy_cabinet_data->bms_data[cluster_index].property_data.cell_num) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "bcu$cellNum", p_energy_cabinet_data->bms_data[cluster_index].property_data.cell_num);
        g_property_data[cluster_index].cell_num = p_energy_cabinet_data->bms_data[cluster_index].property_data.cell_num;
        upload_flag = 1;
    }
    //通讯状态
    if((g_property_data[cluster_index].comm_status != p_energy_cabinet_data->bms_data[cluster_index].property_data.comm_status) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "bcu$commStatus", p_energy_cabinet_data->bms_data[cluster_index].property_data.comm_status);
        g_property_data[cluster_index].comm_status = p_energy_cabinet_data->bms_data[cluster_index].property_data.comm_status;
        upload_flag = 1;
    }
    //工作状态
    if((g_property_data[cluster_index].work_status != p_energy_cabinet_data->bms_data[cluster_index].property_data.work_status) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "bcu$workStatus", p_energy_cabinet_data->bms_data[cluster_index].property_data.work_status);
        g_property_data[cluster_index].work_status = p_energy_cabinet_data->bms_data[cluster_index].property_data.work_status;
        upload_flag = 1;
    }
    //禁充状态
    if((g_property_data[cluster_index].char_prohibit != p_energy_cabinet_data->bms_data[cluster_index].property_data.char_prohibit) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "bcu$charProhibit", p_energy_cabinet_data->bms_data[cluster_index].property_data.char_prohibit);
        g_property_data[cluster_index].char_prohibit = p_energy_cabinet_data->bms_data[cluster_index].property_data.char_prohibit;
        upload_flag = 1;
    }
    //禁放状态
    if((g_property_data[cluster_index].dischar_prohibit != p_energy_cabinet_data->bms_data[cluster_index].property_data.dischar_prohibit) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "bcu$discharProhibit", p_energy_cabinet_data->bms_data[cluster_index].property_data.dischar_prohibit);
        g_property_data[cluster_index].dischar_prohibit = p_energy_cabinet_data->bms_data[cluster_index].property_data.dischar_prohibit;
        upload_flag = 1;
    }
    //主正继电器状态
    if((g_property_data[cluster_index].main_pos_relay != p_energy_cabinet_data->bms_data[cluster_index].property_data.main_pos_relay) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "bcu$mainPosRelay", p_energy_cabinet_data->bms_data[cluster_index].property_data.main_pos_relay);
        g_property_data[cluster_index].main_pos_relay = p_energy_cabinet_data->bms_data[cluster_index].property_data.main_pos_relay;
        upload_flag = 1;
    }
    //主负继电器状态
    if((g_property_data[cluster_index].main_nega_relay != p_energy_cabinet_data->bms_data[cluster_index].property_data.main_nega_relay) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "bcu$mainNegaRelay", p_energy_cabinet_data->bms_data[cluster_index].property_data.main_nega_relay);
        g_property_data[cluster_index].main_nega_relay = p_energy_cabinet_data->bms_data[cluster_index].property_data.main_nega_relay;
        upload_flag = 1;
    }

    p_data_item = cJSON_CreateObject();
    if(p_data_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_base_config);
        return;
    }
    
    cJSON_AddNumberToObject(p_data_item, "dataTime", get_sys_timestamp());
    cJSON_AddItemToObject(p_data_item, "baseConfig", p_base_config);

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_data_item);
        return;
    }
    cJSON_AddItemToArray(p_data_array,  p_data_item);
    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);
    if(upload_flag)
    {
        mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.property_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
        cluster_index++;
    }
    free(p);

    if(cluster_index >= p_energy_cabinet_data->cmu_data.sign_data.bcu_num)
    {
        cluster_index = 0;
        upload_tick_cnt = 0;
        all_data_upload_flag = 0;
    }
}

/**
 * @brief   BMS监控数据上报
 * @param
 * @note
 * @return
 */
void bms_monitor_data_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    cJSON *p_base_config = NULL;
    cJSON *p_pack_array = NULL;
    cJSON *p_pack = NULL;
    char *p = NULL;
    static uint8_t cluster_index = 0;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();

    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    if(p_energy_cabinet_data == NULL)
    {
        return;
    }

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_energy_cabinet_data->cmu_data.sign_data.bcu_sn[cluster_index]);
    cJSON_AddStringToObject(p_root, "product", "bms");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_base_config = cJSON_CreateObject();
    if(p_base_config == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }

    cJSON_AddNumberToObject(p_base_config, "bcu$volt",   p_energy_cabinet_data->bms_data[cluster_index].monitor_data.cluster_voltage);
    cJSON_AddNumberToObject(p_base_config, "bcu$current", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.cluster_current);
    cJSON_AddNumberToObject(p_base_config, "bcu$power", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.cluster_power);
    cJSON_AddNumberToObject(p_base_config, "bcu$soc",   p_energy_cabinet_data->bms_data[cluster_index].monitor_data.cluster_SOC);
    cJSON_AddNumberToObject(p_base_config, "bcu$soh", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.cluster_SOH);
    cJSON_AddNumberToObject(p_base_config, "bcu$monomerVmax", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_vmax);
    cJSON_AddNumberToObject(p_base_config, "bcu$monomerVmean", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_vmean);
    cJSON_AddNumberToObject(p_base_config, "bcu$monomerVmin", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_vmin);
    cJSON_AddNumberToObject(p_base_config, "bcu$monomerTmax", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_tmax);
    cJSON_AddNumberToObject(p_base_config, "bcu$monomerTmean", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_tmean);
    cJSON_AddNumberToObject(p_base_config, "bcu$monomerTmin", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_tmin);
    cJSON_AddNumberToObject(p_base_config, "bcu$charEnergy", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.cluster_charge_energy);
    cJSON_AddNumberToObject(p_base_config, "bcu$discharEnergy", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.cluster_discharge_energy);
    cJSON_AddNumberToObject(p_base_config, "bcu$totalEnergyCharge", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.total_energy_charge);
    cJSON_AddNumberToObject(p_base_config, "bcu$totalEnergyDischarge", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.total_energy_discharge);
    cJSON_AddNumberToObject(p_base_config, "bcu$posInsulation", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.positive_insulation_resistance);
    cJSON_AddNumberToObject(p_base_config, "bcu$NegInsulation", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.negative_insulation_resistance);
    cJSON_AddNumberToObject(p_base_config, "bcu$HBtemp1", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.high_pressure_box_t1);
    cJSON_AddNumberToObject(p_base_config, "bcu$HBtemp2", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.high_pressure_box_t2);
    cJSON_AddNumberToObject(p_base_config, "bcu$HBtemp3", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.high_pressure_box_t3);
    cJSON_AddNumberToObject(p_base_config, "bcu$HBtemp4", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.high_pressure_box_t4);

    p_data_item = cJSON_CreateObject();
    if(p_data_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_base_config);
        return;
    }
    cJSON_AddNumberToObject(p_data_item, "dataTime", get_sys_timestamp());
    cJSON_AddItemToObject(p_data_item, "baseConfig", p_base_config);
    //根据pack数量进行json打包
    p_pack_array = cJSON_CreateArray();
    if(p_pack_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_base_config);
        return;
    }

    for(uint8_t i = 0; i < p_energy_cabinet_data->bat_stack_data.property_data.pack_num; i++)
    {
        p_pack = cJSON_CreateObject();
        if(p_pack == NULL)
        {
            MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
            cJSON_Delete(p_root);
            cJSON_Delete(p_base_config);
            cJSON_Delete(p_pack_array);
            return;
        }
        cJSON_AddItemToObject(p_pack, "volt", cJSON_CreateIntArray(p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[i].monomer_voltage, MONOMER_NUMBER_IN_PACK));
        cJSON_AddItemToObject(p_pack, "temp", cJSON_CreateIntArray(p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[i].monomer_temperature, MONOMER_NUMBER_IN_PACK));
        cJSON_AddItemToObject(p_pack, "soc", cJSON_CreateIntArray(p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[i].monomer_SOC, MONOMER_NUMBER_IN_PACK));
        cJSON_AddItemToObject(p_pack, "soh", cJSON_CreateIntArray(p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[i].monomer_SOH, MONOMER_NUMBER_IN_PACK));
        cJSON_AddItemToObject(p_pack, "status", cJSON_CreateIntArray(p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[i].monomer_status, MONOMER_NUMBER_IN_PACK));

        cJSON *p_pole_temp = cJSON_CreateArray();
        cJSON_InsertItemInArray(p_pole_temp, 0, cJSON_CreateNumber(p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[i].pole_pack_t1));
        cJSON_InsertItemInArray(p_pole_temp, 1, cJSON_CreateNumber(p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[i].pole_pack_t2));
        cJSON_AddItemToObject(p_pack, "poleTemp", p_pole_temp);
        cJSON_AddItemToArray(p_pack_array, p_pack);
    }
    cJSON_AddItemToObject(p_data_item, "bcu$pack", p_pack_array);

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_data_item);
        return;
    }
    cJSON_AddItemToArray(p_data_array,  p_data_item);
    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);

    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.monitor_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS0);
    free(p);

    cluster_index++;
    if(cluster_index >= p_energy_cabinet_data->cmu_data.sign_data.bcu_num)
    {
        cluster_index = 0;
    }
}