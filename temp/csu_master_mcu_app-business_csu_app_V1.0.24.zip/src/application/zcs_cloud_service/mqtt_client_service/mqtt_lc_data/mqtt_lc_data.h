#ifndef __MQTT_LC_DATA_H__
#define __MQTT_LC_DATA_H__

// #include "mongoose.h"

/**
 * @brief   液冷事件列表初始化
 * @param
 * @note
 * @return
 */
void lc_event_list_init(void);


/**
 * @brief   液冷事件数据上报
 * @param
 * @note
 * @return
 */
void lc_event_data_upload(void);

/**
 * @brief   液冷属性数据上报
 * @param
 * @note
 * @return
 */
void lc_property_data_upload(void);

/**
 * @brief   液冷监控数据上报
 * @param
 * @note
 * @return
 */
void lc_monitor_data_upload(void);


#endif