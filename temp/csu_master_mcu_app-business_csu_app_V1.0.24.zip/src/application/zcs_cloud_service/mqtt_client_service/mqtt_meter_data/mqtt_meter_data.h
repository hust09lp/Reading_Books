#ifndef __MQTT_METER_DATA_H__
#define __MQTT_METER_DATA_H__

// #include "mongoose.h"


/**
 * @brief   电表属性数据上报
 * @param
 * @note
 * @return
 */
void meter_property_data_upload(void);

/**
 * @brief   电表监控数据上报
 * @param
 * @note
 * @return
 */
void meter_monitor_data_upload(void);


/**
 * @brief   PV电表属性数据上报
 * @param
 * @note
 * @return
 */
void pv_meter_property_data_upload(void);


/**
 * @brief   PV电表监控数据上报
 * @param
 * @note
 * @return
 */
void pv_meter_monitor_data_upload(uint8_t meter_cnt);

/**
 * @brief   PCC电表属性数据上报
 * @param
 * @note
 * @return
 */
void pcc_meter_property_data_upload(void);

/**
 * @brief   PCC电表监控数据上报
 * @param
 * @note
 * @return
 */
void pcc_meter_monitor_data_upload(void);


#endif