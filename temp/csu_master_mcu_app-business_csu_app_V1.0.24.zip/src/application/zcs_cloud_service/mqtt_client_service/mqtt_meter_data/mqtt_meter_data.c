#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include "sofar_log.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk_public.h"
#include "stdlib.h"
#include "mosquitto.h"
#include "cJSON.h"
#include "app_common.h"
#include "mqtt_client_service.h"


typedef struct
{
    char meter_sn[SN_MAX_LEN];                  //SN
    uint8_t comm_status;                        //通讯状态
}meter_property_data_t;

static meter_property_data_t g_meter_property_data = {0};
static meter_property_data_t g_pcc_meter_property_data = {0};
static meter_property_data_t g_pv_meter_property_data[PV_METER_NUM] = {0};

/**
 * @brief   电表属性数据上报
 * @param
 * @note
 * @return
 */
void meter_property_data_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    cJSON *p_base_config = NULL;
    char *p = NULL;
    static uint8_t all_data_upload_flag = 1;
    uint8_t upload_flag = 0;
    static uint16_t upload_tick_cnt = 0;
    uint8_t meter_comm_status = 0;
    telematic_data_t *p_telematic_data = NULL;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
    
    p_telematic_data = sdk_shm_telematic_data_get();

    //上报计时，对精确度要求不高
    if(upload_tick_cnt < MQTT_PROPERTY_UPLOAD_TIME_INTERVAL)
    {
        upload_tick_cnt++;
    }
    else
    {
        all_data_upload_flag = 1;
        upload_tick_cnt = 0;
    }
    
    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_mqtt_cfg->dev_sn.meter_sn);
    cJSON_AddStringToObject(p_root, "product", "meter");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_base_config = cJSON_CreateObject();
    if(p_base_config == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    //SN
    if((strcmp(g_meter_property_data.meter_sn, p_mqtt_cfg->dev_sn.meter_sn)) || all_data_upload_flag)
    {
        cJSON_AddStringToObject(p_base_config, "em$sn", p_mqtt_cfg->dev_sn.meter_sn);
        strcpy(g_meter_property_data.meter_sn, p_mqtt_cfg->dev_sn.meter_sn);
        upload_flag = 1;
    }
    //通讯状态
    meter_comm_status = BIT_GET(p_telematic_data->combiner_cabinet_system_fault_info[3], 6);
    if((g_meter_property_data.comm_status != meter_comm_status) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "em$commStatus", !meter_comm_status);
        g_meter_property_data.comm_status = meter_comm_status;
        upload_flag = 1;
    }

    p_data_item = cJSON_CreateObject();
    if(p_data_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_base_config);
        return;
    }
    
    cJSON_AddNumberToObject(p_data_item, "dataTime", get_sys_timestamp());
    cJSON_AddItemToObject(p_data_item, "baseConfig", p_base_config);

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_data_item);
        return;
    }
    cJSON_AddItemToArray(p_data_array,  p_data_item);
    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);
    if(upload_flag)
    {
        mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.property_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    }
    all_data_upload_flag = 0;
    free(p);
}

/**
 * @brief   电表监控数据上报
 * @param
 * @note
 * @return
 */
void meter_monitor_data_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    cJSON *p_base_config = NULL;
    char *p = NULL;
    int32_t meter_power = 0;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
    internal_shared_data_t *p_internal_data = sdk_shm_internal_shared_data_get();

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "nodeId", p_mqtt_cfg->dev_sn.meter_sn);
    cJSON_AddStringToObject(p_root, "product", "meter");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_base_config = cJSON_CreateObject();
    if(p_base_config == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    meter_power = (p_internal_data->total_realtime_energy.meter_power / 100) * 100;
    cJSON_AddNumberToObject(p_base_config, "em$activePower", meter_power);
    cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergySharp", p_internal_data->total_realtime_energy.positive_active_energy_sharp);
    cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergyPeak", p_internal_data->total_realtime_energy.positive_active_energy_peak);
    cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergyFlat", p_internal_data->total_realtime_energy.positive_active_energy_flat);
    cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergyValley", p_internal_data->total_realtime_energy.positive_active_energy_valley);
    cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergy", p_internal_data->total_realtime_energy.positive_active_energy_total);
    cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergySharp", p_internal_data->total_realtime_energy.negative_active_energy_sharp);
    cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergyPeak", p_internal_data->total_realtime_energy.negative_active_energy_peak);
    cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergyFlat", p_internal_data->total_realtime_energy.negative_active_energy_flat);
    cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergyValley", p_internal_data->total_realtime_energy.negative_active_energy_valley);
    cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergy", p_internal_data->total_realtime_energy.negative_active_energy_total);

    p_data_item = cJSON_CreateObject();
    if(p_data_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_base_config);
        return;
    }
    
    cJSON_AddNumberToObject(p_data_item, "dataTime", get_sys_timestamp());
    cJSON_AddItemToObject(p_data_item, "baseConfig", p_base_config);

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_data_item);
        return;
    }
    cJSON_AddItemToArray(p_data_array,  p_data_item);
    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.monitor_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS0);
    free(p);
}


/**
 * @brief   PV电表属性数据上报
 * @param
 * @note
 * @return
 */
void pv_meter_property_data_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    cJSON *p_base_config = NULL;
    char *p = NULL;
    static uint8_t all_data_upload_flag = 1;
    uint8_t upload_flag = 0;
    static uint8_t pv_meter_cnt = 0;
    static uint16_t upload_tick_cnt = 0;
    uint8_t meter_comm_status = 0;
    telematic_data_t *p_telematic_data = NULL;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
    constant_parameter_data_t *p_constant_param = sdk_shm_constant_parameter_data_get();

    p_telematic_data = sdk_shm_telematic_data_get();

    //上报计时，对精确度要求不高
    if(upload_tick_cnt < MQTT_PROPERTY_UPLOAD_TIME_INTERVAL / 2)
    {
        upload_tick_cnt++;
    }
    else
    {
        all_data_upload_flag = 1;
        upload_tick_cnt = 0;
    }
    
    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_mqtt_cfg->dev_sn.pv_meter_sn[pv_meter_cnt]);
    cJSON_AddStringToObject(p_root, "product", "pv meter");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_base_config = cJSON_CreateObject();
    if(p_base_config == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    //SN
    if((strcmp(g_pv_meter_property_data[pv_meter_cnt].meter_sn, p_mqtt_cfg->dev_sn.pv_meter_sn[pv_meter_cnt])) || all_data_upload_flag)
    {
        cJSON_AddStringToObject(p_base_config, "em$sn", p_mqtt_cfg->dev_sn.pv_meter_sn[pv_meter_cnt]);
        strcpy(g_pv_meter_property_data[pv_meter_cnt].meter_sn, p_mqtt_cfg->dev_sn.pv_meter_sn[pv_meter_cnt]);
        upload_flag = 1;
    }
    //通讯状态
    meter_comm_status = BIT_GET(p_telematic_data->combiner_cabinet_system_fault_info[6], pv_meter_cnt);
    if((g_pv_meter_property_data[pv_meter_cnt].comm_status != meter_comm_status) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "em$commStatus", !meter_comm_status);
        g_pv_meter_property_data[pv_meter_cnt].comm_status = meter_comm_status;
        upload_flag = 1;
    }

    p_data_item = cJSON_CreateObject();
    if(p_data_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_base_config);
        return;
    }
    
    cJSON_AddNumberToObject(p_data_item, "dataTime", get_sys_timestamp());
    cJSON_AddItemToObject(p_data_item, "baseConfig", p_base_config);

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_data_item);
        return;
    }
    cJSON_AddItemToArray(p_data_array,  p_data_item);
    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);
    if(upload_flag)
    {
        mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.property_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    }
    all_data_upload_flag = 0;
    free(p);

    pv_meter_cnt++;
    if(pv_meter_cnt >= p_constant_param->photovoltaic_meter_cfg.meter_cnt)
    {
        pv_meter_cnt = 0;
    }
}


/**
 * @brief   PV电表监控数据上报
 * @param
 * @note
 * @return
 */
void pv_meter_monitor_data_upload(uint8_t meter_cnt)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    cJSON *p_base_config = NULL;
    char *p = NULL;
    int32_t meter_power = 0;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
    internal_shared_data_t *p_internal_data = sdk_shm_internal_shared_data_get();
    constant_parameter_data_t *p_constant_param = sdk_shm_constant_parameter_data_get();

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "nodeId", p_mqtt_cfg->dev_sn.pv_meter_sn[meter_cnt]);
    cJSON_AddStringToObject(p_root, "product", "pv meter");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_base_config = cJSON_CreateObject();
    if(p_base_config == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }

    if((p_constant_param->photovoltaic_meter_cfg.meter_cnt == 0) || (p_constant_param->system_param.cabinet_param.rs485_device_enable.bit.photovoltaic_meter == 0))
    {
        cJSON_AddNumberToObject(p_base_config, "em$activePower", 0);
        cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergySharp", 0);
        cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergyPeak", 0);
        cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergyFlat", 0);
        cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergyValley", 0);
        cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergy", 0);
        cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergySharp", 0);
        cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergyPeak", 0);
        cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergyFlat", 0);
        cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergyValley", 0);
        cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergy", 0);
    }
    else
    {
        meter_power = (p_internal_data->photovoltaic_meter_data[meter_cnt].active_power_total / 100) * 100;
        cJSON_AddNumberToObject(p_base_config, "em$activePower", meter_power);
        cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergySharp", p_internal_data->photovoltaic_meter_data[meter_cnt].positive_active_energy_sharp);
        cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergyPeak", p_internal_data->photovoltaic_meter_data[meter_cnt].positive_active_energy_peak);
        cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergyFlat", p_internal_data->photovoltaic_meter_data[meter_cnt].positive_active_energy_flat);
        cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergyValley", p_internal_data->photovoltaic_meter_data[meter_cnt].positive_active_energy_valley);
        cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergy", p_internal_data->photovoltaic_meter_data[meter_cnt].positive_active_energy_total);
        cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergySharp", p_internal_data->photovoltaic_meter_data[meter_cnt].negative_active_energy_sharp);
        cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergyPeak", p_internal_data->photovoltaic_meter_data[meter_cnt].negative_active_energy_peak);
        cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergyFlat", p_internal_data->photovoltaic_meter_data[meter_cnt].negative_active_energy_flat);
        cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergyValley", p_internal_data->photovoltaic_meter_data[meter_cnt].negative_active_energy_valley);
        cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergy", p_internal_data->photovoltaic_meter_data[meter_cnt].negative_active_energy_total);
    }

    p_data_item = cJSON_CreateObject();
    if(p_data_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_base_config);
        return;
    }
    
    cJSON_AddNumberToObject(p_data_item, "dataTime", get_sys_timestamp());
    cJSON_AddItemToObject(p_data_item, "baseConfig", p_base_config);

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_data_item);
        return;
    }
    cJSON_AddItemToArray(p_data_array,  p_data_item);
    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.monitor_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS0);
    free(p);
}


/**
 * @brief   PCC电表属性数据上报
 * @param
 * @note
 * @return
 */
void pcc_meter_property_data_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    cJSON *p_base_config = NULL;
    char *p = NULL;
    static uint8_t all_data_upload_flag = 1;
    uint8_t upload_flag = 0;
    static uint16_t upload_tick_cnt = 0;
    uint8_t meter_comm_status = 0;
    telematic_data_t *p_telematic_data = NULL;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();

    p_telematic_data = sdk_shm_telematic_data_get();

    //上报计时，对精确度要求不高
    if(upload_tick_cnt < MQTT_PROPERTY_UPLOAD_TIME_INTERVAL)
    {
        upload_tick_cnt++;
    }
    else
    {
        all_data_upload_flag = 1;
        upload_tick_cnt = 0;
    }
    
    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_mqtt_cfg->dev_sn.pcc_meter_sn);
    cJSON_AddStringToObject(p_root, "product", "pcc meter");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_base_config = cJSON_CreateObject();
    if(p_base_config == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    //SN
    if((strcmp(g_pcc_meter_property_data.meter_sn, p_mqtt_cfg->dev_sn.pcc_meter_sn)) || all_data_upload_flag)
    {
        cJSON_AddStringToObject(p_base_config, "em$sn", p_mqtt_cfg->dev_sn.pcc_meter_sn);
        strcpy(g_pcc_meter_property_data.meter_sn, p_mqtt_cfg->dev_sn.pcc_meter_sn);
        upload_flag = 1;
    }
    //通讯状态
    meter_comm_status = BIT_GET(p_telematic_data->combiner_cabinet_system_fault_info[3], 7);
    if((g_pcc_meter_property_data.comm_status != meter_comm_status) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "em$commStatus", !meter_comm_status);
        g_pcc_meter_property_data.comm_status = meter_comm_status;
        upload_flag = 1;
    }

    p_data_item = cJSON_CreateObject();
    if(p_data_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_base_config);
        return;
    }
    
    cJSON_AddNumberToObject(p_data_item, "dataTime", get_sys_timestamp());
    cJSON_AddItemToObject(p_data_item, "baseConfig", p_base_config);

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_data_item);
        return;
    }
    cJSON_AddItemToArray(p_data_array,  p_data_item);
    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);
    if(upload_flag)
    {
        mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.property_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    }
    all_data_upload_flag = 0;
    free(p);
}



/**
 * @brief   PCC电表监控数据上报
 * @param
 * @note
 * @return
 */
void pcc_meter_monitor_data_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    cJSON *p_base_config = NULL;
    char *p = NULL;
    int32_t meter_power = 0;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
    internal_shared_data_t *p_internal_data = sdk_shm_internal_shared_data_get();
    constant_parameter_data_t *p_constant_param = sdk_shm_constant_parameter_data_get();

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "nodeId", p_mqtt_cfg->dev_sn.pcc_meter_sn);
    cJSON_AddStringToObject(p_root, "product", "pcc meter");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_base_config = cJSON_CreateObject();
    if(p_base_config == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }

    if(p_constant_param->system_param.cabinet_param.rs485_device_enable.bit.backflow_meter == 0)
    {
        cJSON_AddNumberToObject(p_base_config, "em$activePower", 0);
        cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergySharp", 0);
        cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergyPeak", 0);
        cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergyFlat", 0);
        cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergyValley", 0);
        cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergy", 0);
        cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergySharp", 0);
        cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergyPeak", 0);
        cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergyFlat", 0);
        cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergyValley", 0);
        cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergy", 0);
    }
    else
    {
        meter_power = (abs(p_internal_data->pcc_meter_data.active_power_total / 1000) > 1) ? p_internal_data->pcc_meter_data.active_power_total : 0;
        cJSON_AddNumberToObject(p_base_config, "em$activePower", meter_power);
        cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergySharp", p_internal_data->pcc_meter_data.positive_active_energy_sharp);
        cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergyPeak", p_internal_data->pcc_meter_data.positive_active_energy_peak);
        cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergyFlat", p_internal_data->pcc_meter_data.positive_active_energy_flat);
        cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergyValley", p_internal_data->pcc_meter_data.positive_active_energy_valley);
        cJSON_AddNumberToObject(p_base_config, "em$toatlActiveEnergy", p_internal_data->pcc_meter_data.positive_active_energy_total);
        cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergySharp", p_internal_data->pcc_meter_data.negative_active_energy_sharp);
        cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergyPeak", p_internal_data->pcc_meter_data.negative_active_energy_peak);
        cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergyFlat", p_internal_data->pcc_meter_data.negative_active_energy_flat);
        cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergyValley", p_internal_data->pcc_meter_data.negative_active_energy_valley);
        cJSON_AddNumberToObject(p_base_config, "em$toatlReactiveEnergy", p_internal_data->pcc_meter_data.negative_active_energy_total);
    }

    p_data_item = cJSON_CreateObject();
    if(p_data_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_base_config);
        return;
    }
    
    cJSON_AddNumberToObject(p_data_item, "dataTime", get_sys_timestamp());
    cJSON_AddItemToObject(p_data_item, "baseConfig", p_base_config);

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_data_item);
        return;
    }
    cJSON_AddItemToArray(p_data_array,  p_data_item);
    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.monitor_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS0);
    free(p);
}