#ifndef __MQTT_CSU_DATA_H__
#define __MQTT_CSU_DATA_H__

// #include "mongoose.h"

#define ENERGY_DB "/user/data/energy/meter_energy.db"       // 数据库文件路径
#define PCC_ENERGY_DB "/user/data/energy/pcc_energy.db"     // 数据库文件路径
#define PV_ENERGY_DB "/user/data/energy/pv_energy.db"       // 数据库文件路径
#define LOAD_ENERGY_DB "/user/data/energy/load_energy.db"   // 数据库文件路径

enum{
    METER = 0,                                          // 计量表                            
    PCC_METER,                                          // PCC电表
    PV_METER,                                           // PV电表
    LOAD                                                // 负载
};

/**
 * @brief   CMU属性数据上报
 * @param
 * @note
 * @return
 */
void cmu_property_data_upload(void);

/**
 * @brief   CSU属性数据上报
 * @param
 * @note
 * @return
 */
void csu_property_data_upload(void);

/**
 * @brief   CSU监控数据上报
 * @param
 * @note
 * @return
 */
void csu_monitor_data_upload(void);

/**
 * @brief   NTP事件数据上报
 * @param
 * @note
 * @return
 */
void csu_ntp_event_upload(void);

/**
 * @brief   设备时区上报
 * @param
 * @note
 * @return
 */
void csu_local_timezone_upload(void);


/**
 * @brief   数据接收解析
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] p_topic：主题
 * @param   [in] p_payload:消息
 * @param   [in] len:消息长度
 * @note
 * @return
 */
void mqtt_data_parse(struct mosquitto *mosq, char *p_topic, char *p_payload, int32_t len);

#endif