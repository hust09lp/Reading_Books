#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include "sofar_log.h"
#include "sqlite3.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk_public.h"
#include "stdlib.h"
#include "mosquitto.h"
#include "cJSON.h"
#include "app_common.h"
#include "mqtt_client_service.h"
#include "mqtt_csu_data.h"
// #include "sofar_ota.h"

#define SYSTIME_JSON_FILE "/user/www/conf/systime.json"

typedef struct
{
    char csu_sn[SN_MAX_LEN];                    //SN
    char csu_version[VERSION_MAX_LEN];          //版本号
    uint8_t comm_status;                        //通讯状态
    uint8_t run_status;                         //运行状态
    uint8_t xj_online_status;                   //小桔在线状态
    uint8_t xj_work_status;                     //小桔工作状态
    uint8_t xj_work_mode;                       //小桔工作模式
}csu_property_data_t;

static csu_property_data_t g_csu_property_data = {0};
static cmu_property_data_t g_property_data = {0};

/**
 * @brief   CMU属性数据上报
 * @param
 * @note
 * @return
 */
void cmu_property_data_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    cJSON *p_base_config = NULL;
    char *p = NULL;
    static uint8_t all_data_upload_flag = 1;
    uint8_t upload_flag = 0;
    static uint16_t upload_tick_cnt = 0;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();

    //上报计时，对精确度要求不高
    if(upload_tick_cnt < MQTT_PROPERTY_UPLOAD_TIME_INTERVAL)
    {
        upload_tick_cnt++;
    }
    else
    {
        all_data_upload_flag = 1;
        upload_tick_cnt = 0;
    }

    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    if(p_energy_cabinet_data == NULL)
    {
        return;
    }
    
    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_energy_cabinet_data->cmu_data.property_data.cmu_sn);
    cJSON_AddStringToObject(p_root, "product", "cmu");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_base_config = cJSON_CreateObject();
    if(p_base_config == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    //SN
    if((strcmp((char *)g_property_data.cmu_sn, (char *)p_energy_cabinet_data->cmu_data.property_data.cmu_sn)) || all_data_upload_flag)
    {
        cJSON_AddStringToObject(p_base_config, "cmu$sn", (char *)p_energy_cabinet_data->cmu_data.property_data.cmu_sn);
        strcpy((char *)g_property_data.cmu_sn, (char *)p_energy_cabinet_data->cmu_data.property_data.cmu_sn);
        upload_flag = 1;
    }
    //版本号
    if((strcmp((char *)g_property_data.version, (char *)p_energy_cabinet_data->cmu_data.property_data.version)) || all_data_upload_flag)
    {
        cJSON_AddStringToObject(p_base_config, "cmu$version", (char *)p_energy_cabinet_data->cmu_data.property_data.version);
        strcpy((char *)g_property_data.version, (char *)p_energy_cabinet_data->cmu_data.property_data.version);
        upload_flag = 1;
    }
    //通讯状态
    //查询CSU遥信信息判断CMU是否失联
    uint8_t cmu_comm_status = BIT_GET(p_telematic_data->csu_system_fault_info[1], 1);
    if((g_property_data.comm_status != cmu_comm_status) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "cmu$commStatus", !cmu_comm_status);
        g_property_data.comm_status = cmu_comm_status;
        upload_flag = 1;
    }
    //运行状态
    if((g_property_data.run_status != p_energy_cabinet_data->cmu_data.property_data.run_status) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "cmu$runStatus", p_energy_cabinet_data->cmu_data.property_data.run_status);
        g_property_data.run_status = p_energy_cabinet_data->cmu_data.property_data.run_status;
        upload_flag = 1;
    }

    p_data_item = cJSON_CreateObject();
    if(p_data_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_base_config);
        return;
    }
    
    cJSON_AddNumberToObject(p_data_item, "dataTime", get_sys_timestamp());
    cJSON_AddItemToObject(p_data_item, "baseConfig", p_base_config);

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_data_item);
        return;
    }
    cJSON_AddItemToArray(p_data_array,  p_data_item);
    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);

    if(upload_flag)
    {
        mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.property_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    }
    all_data_upload_flag = 0;
    free(p);
}

/**
 * @brief   CSU属性数据上报
 * @param
 * @note
 * @return
 */
void csu_property_data_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    cJSON *p_base_config = NULL;
    char *p = NULL;
    char version_buff[32] = {0};
    static uint8_t all_data_upload_flag = 1;
    uint8_t upload_flag = 0;
    static uint16_t upload_tick_cnt = 0;
    telemetry_data_t *p_telemetry_data = NULL;
    internal_version_info_t *p_version_info = NULL;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
    
    p_version_info = sdk_shm_internal_version_info_get();
    p_telemetry_data = sdk_shm_telemetry_data_get();

    //上报计时，对精确度要求不高
    if(upload_tick_cnt < MQTT_PROPERTY_UPLOAD_TIME_INTERVAL)
    {
        upload_tick_cnt++;
    }
    else
    {
        all_data_upload_flag = 1;
        upload_tick_cnt = 0;
    }
    
    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }
    cJSON_AddStringToObject(p_root, "model", (char *)"ESS433");
    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_mqtt_cfg->dev_sn.csu_sn);
    cJSON_AddStringToObject(p_root, "product", "csu");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_base_config = cJSON_CreateObject();
    if(p_base_config == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    //SN
    if((strcmp(g_csu_property_data.csu_sn, (char *)p_telemetry_data->sys_version_telemetry_info.sn_version_number)) || all_data_upload_flag)
    {
        cJSON_AddStringToObject(p_base_config, "csu$sn", (char *)p_telemetry_data->sys_version_telemetry_info.sn_version_number);
        strcpy(g_csu_property_data.csu_sn, (char *)p_telemetry_data->sys_version_telemetry_info.sn_version_number);
        upload_flag = 1;
    }
    //版本号
    snprintf(version_buff, sizeof(version_buff), "%c%d.%d.%d", p_version_info->sys_soft_version[0],
	                                                           p_version_info->sys_soft_version[1],
                                                               p_version_info->sys_soft_version[2],
                                                               p_version_info->sys_soft_version[3]);
    if((strcmp(g_csu_property_data.csu_version, version_buff)) || all_data_upload_flag)
    {
        cJSON_AddStringToObject(p_base_config, "csu$version", version_buff);
        strcpy(g_csu_property_data.csu_version, version_buff);
        upload_flag = 1;
    }
    if((g_csu_property_data.comm_status != p_mqtt_cfg->mqtt_connect_status) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "csu$commStatus", p_mqtt_cfg->mqtt_connect_status);
        g_csu_property_data.comm_status = p_mqtt_cfg->mqtt_connect_status;
        upload_flag = 1;
    }
    if((g_csu_property_data.run_status != p_telemetry_data->sys_version_telemetry_info.csu_sys_state) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "csu$runStatus", p_telemetry_data->sys_version_telemetry_info.csu_sys_state);
        g_csu_property_data.run_status = p_telemetry_data->sys_version_telemetry_info.csu_sys_state;
        upload_flag = 1;
    }

    if(all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "csu$xjOnlineStatus", 0);
        cJSON_AddNumberToObject(p_base_config, "csu$xjWorkStatus", 0);
        cJSON_AddNumberToObject(p_base_config, "csu$xjWorkMode", 0);
    }

    p_data_item = cJSON_CreateObject();
    if(p_data_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_base_config);
        return;
    }
    
    cJSON_AddNumberToObject(p_data_item, "dataTime", get_sys_timestamp());
    cJSON_AddItemToObject(p_data_item, "baseConfig", p_base_config);

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_data_item);
        return;
    }
    cJSON_AddItemToArray(p_data_array,  p_data_item);
    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);

    if(upload_flag)
    {
        mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.property_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    }
    all_data_upload_flag = 0;
    free(p);
}


/**
 * @brief   获取每日的电量数据
 * @param   [in]*p_date：日期
 * @param   [out]*p_energy_in：输入
 * @param   [out]*p_energy_out：输出
 * @param   [in]*p_path：路径
 * @param   [in]type：类型
 * @note
 * @return
 */
void get_daily_energy_data_from_db(char *p_date, uint32_t *p_energy_in, uint32_t *p_energy_out, char *p_path, uint8_t type)
{
    sqlite3 *db = NULL;
    sqlite3_stmt *stmt = NULL;
    char sql[256] = {0};
    int rc = 0;

    *p_energy_in = 0;
    *p_energy_out = 0;
   
    rc = sqlite3_open(p_path, &db);
    if(rc) 
    {
       MQTT_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
       return;
    } 
    else 
    {
        if(type == METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%d', date), SUM(charge), SUM(discharge) FROM charge_data WHERE strftime('%%Y-%%m-%%d', date) = '%s';", p_date);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                *p_energy_in = sqlite3_column_double(stmt, 1);
                *p_energy_out = sqlite3_column_double(stmt, 2);
            }
            MQTT_DEBUG_PRINT((int8_t *)"daily meter-->p_energy_in: %d  p_energy_out: %d", *p_energy_in, *p_energy_out);
            sqlite3_finalize(stmt);
        }
        if(type == PCC_METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%d', date), SUM(int), SUM(out) FROM pcc_energy WHERE strftime('%%Y-%%m-%%d', date) = '%s';", p_date);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                *p_energy_in = sqlite3_column_double(stmt, 1);
                *p_energy_out = sqlite3_column_double(stmt, 2);
            }
            MQTT_DEBUG_PRINT((int8_t *)"daily pcc-->p_energy_in: %d  p_energy_out: %d", *p_energy_in, *p_energy_out);
            sqlite3_finalize(stmt);
        }
        if(type == PV_METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%d', date), SUM(int) FROM pv_energy WHERE strftime('%%Y-%%m-%%d', date) = '%s';", p_date);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                *p_energy_in = sqlite3_column_double(stmt, 1);
            }
            MQTT_DEBUG_PRINT((int8_t *)"daily pv-->p_energy_in: %d  p_energy_out: %d", *p_energy_in, *p_energy_out);
            sqlite3_finalize(stmt);
        }
        if(type == LOAD)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%d', date), SUM(out) FROM load_energy WHERE strftime('%%Y-%%m-%%d', date) = '%s';", p_date);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                *p_energy_out = sqlite3_column_double(stmt, 1);
            }
            MQTT_DEBUG_PRINT((int8_t *)"daily load-->p_energy_in: %d  p_energy_out: %d", *p_energy_in, *p_energy_out);
            sqlite3_finalize(stmt);
        }
    }
    
    sqlite3_close(db);    
    return; 
}


/**
 * @brief   获取总的电量数据
 * @param   [out]*p_energy_in：输入
 * @param   [out]*p_energy_out：输出
 * @param   [in]*p_path：路径
 * @param   [in]type：类型
 * @note
 * @return
 */
void get_total_energy_data_from_db(uint32_t *p_energy_in, uint32_t *p_energy_out, char *p_path, uint8_t type)
{
    sqlite3 *db = NULL;
    sqlite3_stmt *stmt = NULL;
    char sql[256] = {0};
    int rc = 0;

    *p_energy_in = 0;
    *p_energy_out = 0;
   
    rc = sqlite3_open(p_path, &db);
    if(rc) 
    {
       MQTT_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
       return;
    } 
    else 
    {
        if(type == METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime(date), SUM(charge), SUM(discharge) FROM charge_data;");
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW)
            {
                *p_energy_in = sqlite3_column_double(stmt, 1);
                *p_energy_out = sqlite3_column_double(stmt, 2);
            }
            MQTT_DEBUG_PRINT((int8_t *)"total meter-->p_energy_in: %d  p_energy_out: %d", *p_energy_in, *p_energy_out);
            sqlite3_finalize(stmt);
        }
        if(type == PCC_METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime(date), SUM(int), SUM(out) FROM pcc_energy;");
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                *p_energy_in = sqlite3_column_double(stmt, 1);
                *p_energy_out = sqlite3_column_double(stmt, 2);
            }
            MQTT_DEBUG_PRINT((int8_t *)"total pcc-->p_energy_in: %d  p_energy_out: %d", *p_energy_in, *p_energy_out);
            sqlite3_finalize(stmt);
        }
        if(type == PV_METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime(date), SUM(int) FROM pv_energy;");
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                *p_energy_in = sqlite3_column_double(stmt, 1);
            }
            MQTT_DEBUG_PRINT((int8_t *)"total pv-->p_energy_in: %d  p_energy_out: %d", *p_energy_in, *p_energy_out);
            sqlite3_finalize(stmt);
        }
        if(type == LOAD)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime(date), SUM(out) FROM load_energy;");
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                *p_energy_out = sqlite3_column_double(stmt, 1);
            }
            MQTT_DEBUG_PRINT((int8_t *)"total load-->p_energy_in: %d  p_energy_out: %d", *p_energy_in, *p_energy_out);
            sqlite3_finalize(stmt);
        }
    }
    
    sqlite3_close(db);    
    return; 
}



/**
 * @brief   CSU监控数据上报
 * @param
 * @note
 * @return
 */
void csu_monitor_data_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    cJSON *p_base_config = NULL;
    char *p = NULL;
    int32_t load_power = 0;
    int32_t solar_power = 0;
    uint32_t meter_charge = 0;
    uint32_t meter_discharge = 0;
    uint32_t energy_in = 0;
    uint32_t energy_out = 0;
    char date[32] = {0};
    sdk_rtc_t rtc_time = {0};
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();
    internal_shared_data_t *p_internal_data = sdk_shm_internal_shared_data_get();
    constant_parameter_data_t *p_constant_para = sdk_shm_constant_parameter_data_get();

    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    if(p_energy_cabinet_data == NULL)
    {
        return;
    }

    sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);  
    snprintf(date, 32,"%04d-%02d-%02d", rtc_time.tm_year + 2000, rtc_time.tm_mon, rtc_time.tm_day);

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "model", (char *)"ESS433");
    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_mqtt_cfg->dev_sn.csu_sn);
    cJSON_AddStringToObject(p_root, "product", "csu");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_base_config = cJSON_CreateObject();
    if(p_base_config == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }

    cJSON_AddNumberToObject(p_base_config, "csu$gridPower", p_telemetry_data->sys_cabinet_telemetry_info.anti_reflux_power * 10);
    //是否需要考虑浮动功率
    //光伏功率&光伏发电量
    if(p_constant_para->system_param.cabinet_param.rs485_device_enable.bit.photovoltaic_meter)
    {
        for(uint8_t i = 0; i < p_constant_para->photovoltaic_meter_cfg.meter_cnt; i++)
        {
            solar_power += p_internal_data->photovoltaic_meter_data[i].active_power_total;
        }
    }
    //负载功率，按照中心功率为0进行计算
    load_power = (solar_power / 10.0) + (p_internal_data->total_realtime_energy.meter_power / 10.0) - (p_telemetry_data->sys_cabinet_telemetry_info.anti_reflux_power * 10.0);
    load_power = (load_power / 10) * 10;
    load_power = (load_power > 0) ? load_power : 0;
    cJSON_AddNumberToObject(p_base_config, "csu$loadPower", load_power);

    //日
    get_daily_energy_data_from_db(date, &energy_in, &energy_out, PV_ENERGY_DB, PV_METER);
    cJSON_AddNumberToObject(p_base_config, "csu$pvDailyEnergy", energy_in);
    get_total_energy_data_from_db(&energy_in, &energy_out, PV_ENERGY_DB, PV_METER);
    cJSON_AddNumberToObject(p_base_config, "csu$pvTotalEnergy", energy_in);

    get_daily_energy_data_from_db(date, &energy_in, &energy_out, PCC_ENERGY_DB, PCC_METER);
    cJSON_AddNumberToObject(p_base_config, "csu$pccDailyInputEnergy", energy_in);
    cJSON_AddNumberToObject(p_base_config, "csu$pccDailyOutputEnergy", energy_out);
    get_total_energy_data_from_db(&energy_in, &energy_out, PCC_ENERGY_DB, PCC_METER);
    cJSON_AddNumberToObject(p_base_config, "csu$pccTotalInputEnergy", energy_in);
    cJSON_AddNumberToObject(p_base_config, "csu$pccTotalOutputEnergy", energy_out);

    get_daily_energy_data_from_db(date, &energy_in, &energy_out, LOAD_ENERGY_DB, LOAD);
    cJSON_AddNumberToObject(p_base_config, "csu$loadDailyEnergy", energy_out);
    get_total_energy_data_from_db(&energy_in, &energy_out, LOAD_ENERGY_DB, LOAD);
    cJSON_AddNumberToObject(p_base_config, "csu$loadTotalEnergy", energy_out);

    get_daily_energy_data_from_db(date, &meter_charge, &meter_discharge, ENERGY_DB, METER);
    cJSON_AddNumberToObject(p_base_config, "csu$emDailyChargeEnergy", meter_charge);
    cJSON_AddNumberToObject(p_base_config, "csu$emDailyDischargeEnergy", meter_discharge);
    get_total_energy_data_from_db(&meter_charge, &meter_discharge, ENERGY_DB, METER);
    cJSON_AddNumberToObject(p_base_config, "csu$emTotalChargeEnergy", meter_charge);
    cJSON_AddNumberToObject(p_base_config, "csu$emTotalDischargeEnergy", meter_discharge);

    p_data_item = cJSON_CreateObject();
    if(p_data_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_base_config);
        return;
    }
    
    cJSON_AddNumberToObject(p_data_item, "dataTime", get_sys_timestamp());
    cJSON_AddItemToObject(p_data_item, "baseConfig", p_base_config);

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_data_item);
        return;
    }
    cJSON_AddItemToArray(p_data_array,  p_data_item);
    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.monitor_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS0);
    free(p);
}


/**
 * @brief   NTP事件数据上报
 * @param
 * @note
 * @return
 */
void csu_ntp_event_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    char *p = NULL;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
    
    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "model", (char *)"ESS433");
    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_mqtt_cfg->dev_sn.csu_sn);
    cJSON_AddStringToObject(p_root, "product", "csu");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }

    p_data_item = cJSON_CreateObject();
    if(p_data_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    
    cJSON_AddStringToObject(p_data_item, "eventId", "ntpRequest");
    cJSON_AddStringToObject(p_data_item, "status", "0");
    cJSON_AddStringToObject(p_data_item, "type", "3");
    cJSON_AddItemToArray(p_data_array,  p_data_item);

    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.event_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);

    free(p);
}


/**
 * @brief   获取时区信息
 * @param [out]p_tz 时区名称
 * @note
 * @return true：成功 false：失败
 */
bool get_local_tz(char *p_tz)
{
    char content[256] = {0};
    cJSON *p_conf = NULL;
    FILE *fp = NULL;
    char *p_timezone = NULL;

    fp = fopen(SYSTIME_JSON_FILE,"r");
    if(fp == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"open json file %s failed.",SYSTIME_JSON_FILE);  
        return false;   
    }
    fread(content, 1, 256, fp);
    fclose(fp);

    p_conf = cJSON_Parse(content);
    if(p_conf == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"parse file %s content failed.",SYSTIME_JSON_FILE);
        return false;
    }

    if(cJSON_GetObjectItem(p_conf, "tz") == NULL)
    {
        cJSON_Delete(p_conf);
        return false;
    }
    p_timezone = cJSON_GetObjectItem(p_conf, "tz")->valuestring;
    strcpy(p_tz, p_timezone);

    cJSON_Delete(p_conf);

    return true;
}


/**
 * @brief    保存时区信息
 * @param	 [in] *p_nc 连接信息 
 * @param	 [in] *p_msg  http请求信息
 * @return
 */
static void save_timezone_info(char *p_tz)
{

    cJSON *p_conf = NULL;
    char content[256] = {0};
    FILE *fp = NULL;
    char *p = NULL;

    /*将新的时区设置保存下来*/
    fp = fopen(SYSTIME_JSON_FILE,"r");
    if(fp == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"open json file %s failed.",SYSTIME_JSON_FILE);  
        return;   
    }
    fread(content, 1, 128, fp);
    fclose(fp);
 
    p_conf = cJSON_Parse(content);
    if(p_conf == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"parse file %s content failed.",SYSTIME_JSON_FILE);
        return;
    }

    if(cJSON_GetObjectItem(p_conf,"tz") != NULL)
    {
        cJSON_ReplaceItemInObject(p_conf,"tz",cJSON_CreateString(p_tz));
    }
    else
    {
        cJSON_AddStringToObject(p_conf, "tz", p_tz);
    }
    
    p = cJSON_PrintUnformatted(p_conf);
 
    fp = fopen(SYSTIME_JSON_FILE,"w");
    if(fp == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"open json file %s failed.",SYSTIME_JSON_FILE);  
        cJSON_Delete(p_conf);
        free(p);
        return;   
    }
    fwrite(p, 1, strlen(p), fp);
    fclose(fp);
    cJSON_Delete(p_conf);
    free(p);
}


/**
 * @brief   设备时区上报
 * @param
 * @note
 * @return
 */
void csu_local_timezone_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    char *p = NULL;
    char tz[128] = {0};
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
    
    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "model", (char *)"ESS433");
    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_mqtt_cfg->dev_sn.csu_sn);
    cJSON_AddStringToObject(p_root, "product", "csu");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());
    //获取时区名称
    if(get_local_tz(tz) == true)
    {
        cJSON_AddStringToObject(p_root, "TZ", tz);
    }
    
    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.timezone_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);

    free(p);
}




/**
 * @brief   开机
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] p_payload:消息
 * @param   [in] len:消息长度
 * @note
 * @return
 */
static void csu_poweron_set(struct mosquitto *mosq, char *p_payload, int32_t len)
{
    cJSON *p_request = NULL;
    char *p = NULL;
    mqtt_config_t *p_mqtt_cfg = NULL;
    web_control_info_t *p_web_data = sdk_shm_web_control_data_get();

    p_mqtt_cfg = mqtt_cfg_get();
    p_request = cJSON_Parse(p_payload);
    if(p_request == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"data parse error");
        return;
    }
    //执行开机
    BIT_SET(p_web_data->control_cmd_flag, 5);

    cJSON_AddNumberToObject(p_request, "result", SUCCESS);
    p = cJSON_PrintUnformatted(p_request);
    cJSON_Delete(p_request);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.func_set_ack_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    free(p);
}


/**
 * @brief   关机
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] p_payload:消息
 * @param   [in] len:消息长度
 * @note
 * @return
 */
static void csu_poweroff_set(struct mosquitto *mosq, char *p_payload, int32_t len)
{
    cJSON *p_request = NULL;
    char *p = NULL;
    mqtt_config_t *p_mqtt_cfg = NULL;
    web_control_info_t *p_web_data = sdk_shm_web_control_data_get();

    p_mqtt_cfg = mqtt_cfg_get();
    p_request = cJSON_Parse(p_payload);
    if(p_request == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"data parse error");
        return;
    }
    //执行关机
    BIT_SET(p_web_data->control_cmd_flag, 6);

    cJSON_AddNumberToObject(p_request, "result", SUCCESS);
    p = cJSON_PrintUnformatted(p_request);
    cJSON_Delete(p_request);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.func_set_ack_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    free(p);
}


/**
 * @brief   设置功率
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] p_payload:消息
 * @param   [in] len:消息长度
 * @note
 * @return
 */
static void csu_power_value_set(struct mosquitto *mosq, char *p_payload, int32_t len)
{
    int16_t active_power = 0;
    cJSON *p_request = NULL;
    cJSON *p_param = NULL;
    char *p = NULL;
    mqtt_config_t *p_mqtt_cfg = NULL;
    web_control_info_t *p_web_data = sdk_shm_web_control_data_get();

    p_mqtt_cfg = mqtt_cfg_get();
    p_request = cJSON_Parse(p_payload);
    if(p_request == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"data parse error");
        return;
    }
    p_param = cJSON_GetObjectItem(p_request,"params");

    //执行设置功率
    BIT_SET(p_web_data->cabinet_param_update_flag, 1);
    active_power = atoi(cJSON_GetObjectItem(p_param, "power")->valuestring);
    p_web_data->cabinet_param_data.active_power = active_power * 10;
    cJSON_DeleteItemFromObject(p_request, "params");
    cJSON_AddNumberToObject(p_request, "result", SUCCESS);
    p = cJSON_PrintUnformatted(p_request);
    cJSON_Delete(p_request);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.func_set_ack_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    free(p);
}


/**
 * @brief   同步系统时间
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] p_payload:消息
 * @param   [in] len:消息长度
 * @note
 * @return
 */
static void csu_sync_sys_time(struct mosquitto *mosq, char *p_payload, int32_t len)
{
    cJSON *p_request = NULL;
    cJSON *p_param = NULL;
    int timestamp = 0;
    char date_str[80] = {0};
    char cmd[128] = {0};

    web_control_info_t *p_web_control = sdk_shm_web_control_data_get();
    p_request = cJSON_Parse(p_payload);
    if(p_request == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"data parse error");
        return;
    }
    p_param = cJSON_GetObjectItem(p_request,"params");
    timestamp = cJSON_GetObjectItem(p_param, "ts")->valueint;

    //更新时间
    struct tm *tm_local = localtime((time_t *)&timestamp);
    strftime(date_str, sizeof(date_str), "%Y-%m-%d %H:%M:%S", tm_local);
    MQTT_DEBUG_PRINT((int8_t *)"date: %s", date_str);
    memset(cmd, 0, sizeof(cmd));
    sprintf(cmd,"date -s \"%s\"", date_str);
    system(cmd);
    system("hwclock -w");

    //同时给MCU2和CMU同步系统时间
    BIT_SET(p_web_control->system_param_flag, 2);
    BIT_SET(p_web_control->system_param_flag, 4);

    cJSON_Delete(p_request);
}


/**
 * @brief   设置系统时区
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] p_payload:消息
 * @param   [in] len:消息长度
 * @note
 * @return
 */
static void csu_sync_sys_tz(struct mosquitto *mosq, char *p_payload, int32_t len)
{
    cJSON *p_request = NULL;
    cJSON *p_param = NULL;
    char *p_tz = NULL;
    char tz[256] = {0};
    char cmd[256] = {0};
    char tz_update_flag = 0;

    internal_shared_data_t *p_shared_data = sdk_shm_internal_shared_data_get();
    web_control_info_t *p_web_control = sdk_shm_web_control_data_get();
    p_request = cJSON_Parse(p_payload);
    if(p_request == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"data parse error");
        return;
    }
    p_param = cJSON_GetObjectItem(p_request,"params");
    p_tz = cJSON_GetObjectItem(p_param, "TZ")->valuestring;

    //判断是否需要更新时区
    if(get_local_tz(tz))
    {
        if(!strcmp(tz, p_tz))
        {
            MQTT_DEBUG_PRINT((int8_t *)"same tz, do not need update[%s]", tz);
        }
        else
        {
            tz_update_flag = 1;
        }
    }
    else
    {
        tz_update_flag = 1;
    }

    if(tz_update_flag)
    {
        //更新时区
        memset(tz, 0, sizeof(tz));
        sprintf(tz, "%s%s", "/opt/share/zoneinfo/", p_tz);
        MQTT_DEBUG_PRINT((int8_t *)"tz set to %s.\n", tz);
        sprintf(cmd, "ln -sf %s /etc/localtime", tz);
        system("mount -o remount,rw /");
        system("rm /etc/localtime");
        system(cmd);
        system("hwclock -w");
        system("mount -o remount,ro /");
        save_timezone_info(p_tz);
        BIT_SET(p_shared_data->tz_update_flag, 0);
        BIT_SET(p_shared_data->tz_update_flag, 1);
    }

    //同时给MCU2和CMU同步系统时间
    BIT_SET(p_web_control->system_param_flag, 2);
    BIT_SET(p_web_control->system_param_flag, 4);

    cJSON_Delete(p_request);
}


/**
 * @brief   升级响应
 * @param   [in] ota_result：升级结果
 * @param   [in] ota_process：升级进度
 * @param   [in] p_error：异常码
 * @note
 * @return
 */
// static void sofar_ota_status_response(char *p_request_id, uint8_t ota_result, uint8_t ota_process, char *p_error)
// {
//     cJSON *p_root = NULL;
//     char *p = NULL;

//     mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
//     p_root = cJSON_CreateObject();
//     if(p_root == NULL)
//     {
//         MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
//         return;
//     }

//     cJSON_AddStringToObject(p_root, "requestId", p_request_id);
//     cJSON_AddStringToObject(p_root, "nodeId", p_mqtt_cfg->dev_sn.csu_sn);
//     cJSON_AddNumberToObject(p_root, "result", ota_result);
//     cJSON_AddNumberToObject(p_root, "process", ota_process);
//     if(p_error)
//     {
//         cJSON_AddStringToObject(p_root, "code", p_error);
//     }

//     p = cJSON_PrintUnformatted(p_root);
//     cJSON_Delete(p_root);
//     mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.ota_ack_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
//     free(p);  
// }



/**
 * @brief   数据接收解析
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] p_topic：主题
 * @param   [in] p_payload:消息
 * @param   [in] len:消息长度
 * @note
 * @return
 */
void mqtt_data_parse(struct mosquitto *mosq, char *p_topic, char *p_payload, int32_t len)
{
    mqtt_config_t *p_mqtt_cfg = NULL;
    cJSON *p_request = NULL;
    char *p_function = NULL;
    char *p_node_id = NULL;
    char *p = NULL;
    // sofar_ota_info_t *p_ota_info = NULL;

    p_mqtt_cfg = mqtt_cfg_get();

    p_request = cJSON_Parse(p_payload);
    if(p_request == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"data parse error");
        return;
    }
    p_node_id = cJSON_GetObjectItem(p_request,"nodeId")->valuestring;
    if(strcmp(p_node_id, p_mqtt_cfg->dev_sn.csu_sn))
    {
        MQTT_DEBUG_PRINT((int8_t *)"node id error");
        cJSON_AddNumberToObject(p_request, "result", FAIL);
        p = cJSON_PrintUnformatted(p_request);
        cJSON_Delete(p_request);
        mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.func_set_ack_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
        return;
    }
    //服务设置
    if(!strcmp(p_topic, p_mqtt_cfg->mqtt_topic.func_set_topic))
    {
        MQTT_DEBUG_PRINT((int8_t *)"function set");
        if(cJSON_GetObjectItem(p_request,"functionName") == NULL)
        {
            return;
        }
        p_function = cJSON_GetObjectItem(p_request,"functionName")->valuestring;
        if(!strcmp(p_function, "powerOn"))
        {
            csu_poweron_set(mosq, p_payload, len);
        }
        else if(!strcmp(p_function, "powerOff"))
        {
            csu_poweroff_set(mosq, p_payload, len);
        }
        else if(!strcmp(p_function, "powerSet"))
        {
            csu_power_value_set(mosq, p_payload, len);
        }
        else if(!strcmp(p_function, "sysTimeSync"))
        {
            csu_sync_sys_time(mosq, p_payload, len);
        }
        else if(!strcmp(p_function, "sysTimeZoneSync"))
        {
            csu_sync_sys_tz(mosq, p_payload, len);
        }
    }
    //升级
    // if(!strcmp(p_topic, p_mqtt_cfg->mqtt_topic.ota_topic))
    // {
    //     p_ota_info =  sofar_ota_info_get();
    //     if(p_ota_info->ota_status == OTA_NONE)
    //     {
    //         MQTT_DEBUG_PRINT((int8_t *)"sofar ota-------->");
    //         strcpy(p_ota_info->http_file_url, (cJSON_GetObjectItem(p_request,"url")->valuestring));
    //         strcpy(p_ota_info->http_file_sign, (cJSON_GetObjectItem(p_request,"sign")->valuestring));
    //         strcpy(p_ota_info->request_id, (cJSON_GetObjectItem(p_request,"requestId")->valuestring));
    //         p_ota_info->ota_status = OTA_FILE_DOWNLOAD;
    //     }
    //     else
    //     {
    //         char *p_request_id = NULL;
    //         p_request_id = cJSON_GetObjectItem(p_request,"requestId")->valuestring;
    //         sofar_ota_status_response(p_request_id, OTA_UPGRADE_FAIL, 0, FILE_UPGRADING);
    //     }
        
    // }
    cJSON_Delete(p_request);
}
