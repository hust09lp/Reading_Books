#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include "sofar_log.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk_public.h"
#include "mosquitto.h"
#include "cJSON.h"
#include "mqtt_client_service.h"


static bat_stack_property_data_t g_property_data = {0};
static cmu_sign_in_data_t g_sign_data = {0};

/**
 * @brief   电池堆拓扑数据上报
 * @param
 * @note
 * @return
 */
void bat_stack_topology_data_upload(void)
{
    cJSON *p_root = NULL;
    cJSON *p_node_item = NULL;
    cJSON *p_bat_stack_array = NULL;
    cJSON *p_bcu_array = NULL;
    char *p = NULL;
    uint8_t upload_flag = 0;
    static uint8_t all_data_upload_flag = 1;
    static uint16_t upload_tick_cnt = 0;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();

    //上报计时，对精确度要求不高
    if(upload_tick_cnt < MQTT_PROPERTY_UPLOAD_TIME_INTERVAL)
    {
        upload_tick_cnt++;
    }
    else
    {
        all_data_upload_flag = 1;
        upload_tick_cnt = 0;
    }   
    
    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    if(p_energy_cabinet_data == NULL)
    {
        return;
    }
    
    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    p_node_item = cJSON_CreateObject();
    if(p_node_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }

    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_mqtt_cfg->dev_sn.csu_sn);
    cJSON_AddStringToObject(p_root, "model", (char *)"CSU");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());
    if((strcmp((char *)g_sign_data.bat_stack_sn, (char *)p_energy_cabinet_data->cmu_data.sign_data.bat_stack_sn)) ||
       (strcmp((char *)g_sign_data.bcu_sn, (char *)p_energy_cabinet_data->cmu_data.sign_data.bcu_sn)) || 
       all_data_upload_flag)
    {
        p_bat_stack_array = cJSON_CreateArray();
        if(p_bat_stack_array == NULL)
        {
            MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
            cJSON_Delete(p_root);
            cJSON_Delete(p_node_item);
            return;
        }
        //先打包PCS---电池堆
        cJSON_AddItemToArray(p_bat_stack_array, cJSON_CreateString((char *)p_energy_cabinet_data->cmu_data.sign_data.bat_stack_sn));
        cJSON_AddItemToObject(p_node_item, (char *)p_energy_cabinet_data->cmu_data.sign_data.pcs_sn, p_bat_stack_array);
       
       //再打包电池堆---电池簇
        p_bcu_array = cJSON_CreateArray();
        if(p_bcu_array == NULL)
        {
            MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
            cJSON_Delete(p_root);
            cJSON_Delete(p_node_item);
            cJSON_Delete(p_bat_stack_array);
            return;
        }
        for(uint8_t i = 0; i < p_energy_cabinet_data->cmu_data.sign_data.bcu_num; i++)
        {
            cJSON_AddItemToArray(p_bcu_array, cJSON_CreateString((char *)p_energy_cabinet_data->cmu_data.sign_data.bcu_sn[i]));
        }
        cJSON_AddItemToObject(p_node_item, (char *)p_energy_cabinet_data->cmu_data.sign_data.bat_stack_sn, p_bcu_array);

        strcpy((char *)g_sign_data.bat_stack_sn, (char *)p_energy_cabinet_data->cmu_data.sign_data.bat_stack_sn);
        for(uint8_t i = 0; i < p_energy_cabinet_data->cmu_data.sign_data.bcu_num; i++)
        {
            strcpy((char *)g_sign_data.bcu_sn[i], (char *)p_energy_cabinet_data->cmu_data.sign_data.bcu_sn[i]);
        }
        
        upload_flag = 1;
    }

    cJSON_AddItemToObject(p_root, "data", p_node_item);

    p = cJSON_PrintUnformatted(p_root);
    cJSON_Delete(p_root);
    if(upload_flag)
    {
        mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.topology_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    }
    all_data_upload_flag = 0;
    free(p);
}


/**
 * @brief   电池堆属性数据上报
 * @param
 * @note
 * @return
 */
void bat_stack_property_data_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    cJSON *p_base_config = NULL;
    char *p = NULL;
    static uint8_t all_data_upload_flag = 1;
    uint8_t upload_flag = 0;
    static uint16_t upload_tick_cnt = 0;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();

    //上报计时，对精确度要求不高
    if(upload_tick_cnt < MQTT_PROPERTY_UPLOAD_TIME_INTERVAL)
    {
        upload_tick_cnt++;
    }
    else
    {
        all_data_upload_flag = 1;
        upload_tick_cnt = 0;
    }
    
    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    if(p_energy_cabinet_data == NULL)
    {
        return;
    }
    
    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_energy_cabinet_data->bat_stack_data.property_data.bat_stack_sn);
    cJSON_AddStringToObject(p_root, "product", "batStack");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_base_config = cJSON_CreateObject();
    if(p_base_config == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    //SN
    if((strcmp((char *)g_property_data.bat_stack_sn, (char *)p_energy_cabinet_data->bat_stack_data.property_data.bat_stack_sn)) || all_data_upload_flag)
    {
        cJSON_AddStringToObject(p_base_config, "batStack$sn", (char *)p_energy_cabinet_data->bat_stack_data.property_data.bat_stack_sn);
        strcpy((char *)g_property_data.bat_stack_sn, (char *)p_energy_cabinet_data->bat_stack_data.property_data.bat_stack_sn);
        upload_flag = 1;
    }
    //通讯状态
    if((g_property_data.comm_status != p_energy_cabinet_data->bat_stack_data.property_data.comm_status) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "batStack$commStatus", p_energy_cabinet_data->bat_stack_data.property_data.comm_status);
        g_property_data.comm_status = p_energy_cabinet_data->bat_stack_data.property_data.comm_status;
        upload_flag = 1;
    }
    //工作状态
    if((g_property_data.work_status != p_energy_cabinet_data->bat_stack_data.property_data.work_status) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "batStack$workStatus", p_energy_cabinet_data->bat_stack_data.property_data.work_status);
        g_property_data.work_status = p_energy_cabinet_data->bat_stack_data.property_data.work_status;
        upload_flag = 1;
    }
    //禁充状态
    if((g_property_data.char_prohibit != p_energy_cabinet_data->bat_stack_data.property_data.char_prohibit) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "batStack$charProhibit", p_energy_cabinet_data->bat_stack_data.property_data.char_prohibit);
        g_property_data.char_prohibit = p_energy_cabinet_data->bat_stack_data.property_data.char_prohibit;
        upload_flag = 1;
    }
    //禁放状态
    if((g_property_data.dischar_prohibit != p_energy_cabinet_data->bat_stack_data.property_data.dischar_prohibit) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "batStack$discharProhibit", p_energy_cabinet_data->bat_stack_data.property_data.dischar_prohibit);
        g_property_data.dischar_prohibit = p_energy_cabinet_data->bat_stack_data.property_data.dischar_prohibit;
        upload_flag = 1;
    }
    //电池堆内电池簇数量
    if((g_property_data.bcu_num != p_energy_cabinet_data->bat_stack_data.property_data.bcu_num) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "batStack$bcuNum", p_energy_cabinet_data->bat_stack_data.property_data.bcu_num);
        g_property_data.bcu_num = p_energy_cabinet_data->bat_stack_data.property_data.bcu_num;
        upload_flag = 1;
    }
    //电池簇内PACK数量
    if((g_property_data.pack_num != p_energy_cabinet_data->bat_stack_data.property_data.pack_num) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "batStack$packNum", p_energy_cabinet_data->bat_stack_data.property_data.pack_num);
        g_property_data.pack_num = p_energy_cabinet_data->bat_stack_data.property_data.pack_num;
        upload_flag = 1;
    }
    //PACK内电芯数量
    if((g_property_data.cell_num != p_energy_cabinet_data->bat_stack_data.property_data.cell_num) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "batStack$cellNum", p_energy_cabinet_data->bat_stack_data.property_data.cell_num);
        g_property_data.cell_num = p_energy_cabinet_data->bat_stack_data.property_data.cell_num;
        upload_flag = 1;
    }

    p_data_item = cJSON_CreateObject();
    if(p_data_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_base_config);
        return;
    }
    
    cJSON_AddNumberToObject(p_data_item, "dataTime", get_sys_timestamp());
    cJSON_AddItemToObject(p_data_item, "baseConfig", p_base_config);

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_data_item);
        return;
    }
    cJSON_AddItemToArray(p_data_array,  p_data_item);
    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);
    if(upload_flag)
    {
        mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.property_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    }
    all_data_upload_flag = 0;
    free(p);
}

/**
 * @brief   电池堆监控数据上报
 * @param
 * @note
 * @return
 */
void bat_stack_monitor_data_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    cJSON *p_base_config = NULL;
    char *p = NULL;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();

    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    if(p_energy_cabinet_data == NULL)
    {
        return;
    }

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_energy_cabinet_data->cmu_data.sign_data.bat_stack_sn);
    cJSON_AddStringToObject(p_root, "product", "batStack");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_base_config = cJSON_CreateObject();
    if(p_base_config == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }

    cJSON_AddNumberToObject(p_base_config, "batStack$soc",   p_energy_cabinet_data->bat_stack_data.monitor_data.soc);
    cJSON_AddNumberToObject(p_base_config, "batStack$soh", p_energy_cabinet_data->bat_stack_data.monitor_data.soh);
    cJSON_AddNumberToObject(p_base_config, "batStack$temM", p_energy_cabinet_data->bat_stack_data.monitor_data.temp_m);
    cJSON_AddNumberToObject(p_base_config, "batStack$char",   p_energy_cabinet_data->bat_stack_data.monitor_data.charge);
    cJSON_AddNumberToObject(p_base_config, "batStack$dischar", p_energy_cabinet_data->bat_stack_data.monitor_data.discharge);
    cJSON_AddNumberToObject(p_base_config, "batStack$totalCharTm", p_energy_cabinet_data->bat_stack_data.monitor_data.total_charge_time);
    cJSON_AddNumberToObject(p_base_config, "batStack$Volt", p_energy_cabinet_data->bat_stack_data.monitor_data.volt);
    cJSON_AddNumberToObject(p_base_config, "batStack$Curr", p_energy_cabinet_data->bat_stack_data.monitor_data.current);
    cJSON_AddNumberToObject(p_base_config, "batStack$Power", p_energy_cabinet_data->bat_stack_data.monitor_data.power);
    cJSON_AddNumberToObject(p_base_config, "batStack$totalChar", p_energy_cabinet_data->bat_stack_data.monitor_data.total_energy_charge);
    cJSON_AddNumberToObject(p_base_config, "batStack$totalDischar", p_energy_cabinet_data->bat_stack_data.monitor_data.total_energy_discharge);
    cJSON_AddNumberToObject(p_base_config, "batStack$insulation", p_energy_cabinet_data->bat_stack_data.monitor_data.insulation);

    p_data_item = cJSON_CreateObject();
    if(p_data_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_base_config);
        return;
    }
    
    cJSON_AddNumberToObject(p_data_item, "dataTime", get_sys_timestamp());
    cJSON_AddItemToObject(p_data_item, "baseConfig", p_base_config);

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_data_item);
        return;
    }
    cJSON_AddItemToArray(p_data_array,  p_data_item);
    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.monitor_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS0);
    free(p);
}