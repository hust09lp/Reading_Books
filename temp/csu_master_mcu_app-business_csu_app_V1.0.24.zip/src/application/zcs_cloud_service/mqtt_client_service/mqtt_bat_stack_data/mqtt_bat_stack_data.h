#ifndef __MQTT_BAT_STACK_DATA_H__
#define __MQTT_BAT_STACK_DATA_H__

// #include "mongoose.h"

/**
 * @brief   电池堆拓扑数据上报
 * @param
 * @note
 * @return
 */
void bat_stack_topology_data_upload(void);


/**
 * @brief   电池堆属性数据上报
 * @param
 * @note
 * @return
 */
void bat_stack_property_data_upload(void);

/**
 * @brief   电池堆监控数据上报
 * @param
 * @note
 * @return
 */
void bat_stack_monitor_data_upload(void);


#endif