#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include "sofar_log.h"
#include "sofar_errors.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk_public.h"
#include "stdlib.h"
#include "mosquitto.h"
#include "cJSON.h"
#include "mqtt_client_service.h"


static fc_property_data_t g_property_data = {0};
static fc_event_data_t g_event_data[FC_MAX_EVENT_ITEM] = {0};

/**
 * @brief   消防事件列表初始化
 * @param
 * @note
 * @return
 */
void fc_event_list_init(void)
{
    for(uint8_t i = 0; i < FC_MAX_EVENT_ITEM; i++)
    {
        g_event_data[i].event_code = 1;
    }
}


/**
 * @brief   消防事件数据上报
 * @param
 * @note
 * @return
 */
void fc_event_data_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    char *p = NULL;
    uint8_t upload_flag = 0;
    char str[10] = {0};
    char date[32] = {0};
    sdk_rtc_t rtc_time = {0};
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
    
    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    if(p_energy_cabinet_data == NULL)
    {
        return;
    }
    
    //获取系统时钟时间
    if (sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time) != SF_OK)
    {
        MQTT_DEBUG_PRINT((int8_t *)"rtc get failed");
    }

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    sprintf(date, "%04d-%02d-%02d %02d:%02d:%02d", rtc_time.tm_year + 2000, rtc_time.tm_mon, rtc_time.tm_day,
                                                   rtc_time.tm_hour, rtc_time.tm_min, rtc_time.tm_sec);

    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_energy_cabinet_data->cmu_data.sign_data.fc_sn);
    cJSON_AddStringToObject(p_root, "product", "fc");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());
    cJSON_AddStringToObject(p_root, "date", date);

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }

    for(uint8_t i = 0; i < FC_MAX_EVENT_ITEM; i++)
    {
        if(g_event_data[i].event_code != p_energy_cabinet_data->fc_data.event_data[i].event_code)
        {
            p_data_item = cJSON_CreateObject();
            if(p_data_item == NULL)
            {
                MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
                cJSON_Delete(p_root);
                return;
            }
            
            sprintf(str, "%d", p_energy_cabinet_data->fc_data.event_data[i].event_id);
            cJSON_AddStringToObject(p_data_item, "eventId", str);
            sprintf(str, "%d", p_energy_cabinet_data->fc_data.event_data[i].event_code);
            cJSON_AddStringToObject(p_data_item, "status", str);
            sprintf(str, "%d", p_energy_cabinet_data->fc_data.event_data[i].event_level);
            cJSON_AddStringToObject(p_data_item, "type", str);
            cJSON_AddNumberToObject(p_data_item, "eventTime", p_energy_cabinet_data->fc_data.event_data[i].event_time);
            cJSON_AddItemToArray(p_data_array,  p_data_item);
            memcpy(&g_event_data[i], &p_energy_cabinet_data->fc_data.event_data[i], sizeof(fc_event_data_t));
            upload_flag = 1;
        }
    }

    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);
    if(upload_flag)
    {
        mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.event_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    }
    free(p);
}


/**
 * @brief   消防属性数据上报
 * @param
 * @note
 * @return
 */
void fc_property_data_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    cJSON *p_base_config = NULL;
    char *p = NULL;
    static uint8_t all_data_upload_flag = 1;
    uint8_t upload_flag = 0;
    static uint16_t upload_tick_cnt = 0;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();
    
    //上报计时，对精确度要求不高
    if(upload_tick_cnt < MQTT_PROPERTY_UPLOAD_TIME_INTERVAL)
    {
        upload_tick_cnt++;
    }
    else
    {
        all_data_upload_flag = 1;
        upload_tick_cnt = 0;
    } 

    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    if(p_energy_cabinet_data == NULL)
    {
        return;
    }
    
    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_energy_cabinet_data->fc_data.property_data.fc_sn);
    cJSON_AddStringToObject(p_root, "product", "fc");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_base_config = cJSON_CreateObject();
    if(p_base_config == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    //SN
    if((strcmp((char *)g_property_data.fc_sn, (char *)p_energy_cabinet_data->fc_data.property_data.fc_sn)) || all_data_upload_flag)
    {
        cJSON_AddStringToObject(p_base_config, "fc$sn", (char *)p_energy_cabinet_data->fc_data.property_data.fc_sn);
        strcpy((char *)g_property_data.fc_sn, (char *)p_energy_cabinet_data->fc_data.property_data.fc_sn);
        upload_flag = 1;
    }
    //设备类型
    if((g_property_data.dev_type != p_energy_cabinet_data->fc_data.property_data.dev_type) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "fc$devType", p_energy_cabinet_data->fc_data.property_data.dev_type);
        g_property_data.dev_type = p_energy_cabinet_data->fc_data.property_data.dev_type;
        upload_flag = 1;
    }
    //通讯状态
    if((g_property_data.comm_status != p_energy_cabinet_data->fc_data.property_data.comm_status) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "fc$commStatus", p_energy_cabinet_data->fc_data.property_data.comm_status);
        g_property_data.comm_status = p_energy_cabinet_data->fc_data.property_data.comm_status;
        upload_flag = 1;
    }
    //消防状态
    if((g_property_data.work_status != p_energy_cabinet_data->fc_data.property_data.work_status) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "fc$workStatus", p_energy_cabinet_data->fc_data.property_data.work_status);
        g_property_data.work_status = p_energy_cabinet_data->fc_data.property_data.work_status;
        upload_flag = 1;
    }
    //烟感状态
    if((g_property_data.sd_status != p_energy_cabinet_data->fc_data.property_data.sd_status) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "fc$sdStatus", p_energy_cabinet_data->fc_data.property_data.sd_status);
        g_property_data.sd_status = p_energy_cabinet_data->fc_data.property_data.sd_status;
        upload_flag = 1;
    }
    //温感状态
    if((g_property_data.td_status != p_energy_cabinet_data->fc_data.property_data.td_status) || all_data_upload_flag)
    {
        cJSON_AddNumberToObject(p_base_config, "fc$tdStatus", p_energy_cabinet_data->fc_data.property_data.td_status);
        g_property_data.td_status = p_energy_cabinet_data->fc_data.property_data.td_status;
        upload_flag = 1;
    }

    p_data_item = cJSON_CreateObject();
    if(p_data_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_base_config);
        return;
    }
    
    cJSON_AddNumberToObject(p_data_item, "dataTime", get_sys_timestamp());
    cJSON_AddItemToObject(p_data_item, "baseConfig", p_base_config);

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_data_item);
        return;
    }
    cJSON_AddItemToArray(p_data_array,  p_data_item);
    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);
    if(upload_flag)
    {
        mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.property_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS1);
    }
    all_data_upload_flag = 0;
    free(p);
}


/**
 * @brief   消防监控数据上报
 * @param
 * @note
 * @return
 */
void fc_monitor_data_upload(void)
{
    cJSON *p_root_array = NULL;
    cJSON *p_root = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_data_array = NULL;
    cJSON *p_base_config = NULL;
    char *p = NULL;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;
    mqtt_config_t *p_mqtt_cfg = mqtt_cfg_get();

    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    if(p_energy_cabinet_data == NULL)
    {
        return;
    }

    p_root = cJSON_CreateObject();
    if(p_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_root, "nodeId", (char *)p_energy_cabinet_data->cmu_data.sign_data.fc_sn);
    cJSON_AddStringToObject(p_root, "product", "fc");
    cJSON_AddNumberToObject(p_root, "ts", get_sys_timestamp());

    p_base_config = cJSON_CreateObject();
    if(p_base_config == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }

    cJSON_AddNumberToObject(p_base_config, "fc$temp", p_energy_cabinet_data->fc_data.monitor_data.temp);
    cJSON_AddNumberToObject(p_base_config, "fc$co", p_energy_cabinet_data->fc_data.monitor_data.co);
    cJSON_AddNumberToObject(p_base_config, "fc$pm25", p_energy_cabinet_data->fc_data.monitor_data.pm25);

    p_data_item = cJSON_CreateObject();
    if(p_data_item == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_base_config);
        return;
    }
    
    cJSON_AddNumberToObject(p_data_item, "dataTime", get_sys_timestamp());
    cJSON_AddItemToObject(p_data_item, "baseConfig", p_base_config);

    p_data_array = cJSON_CreateArray();
    if(p_data_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        cJSON_Delete(p_data_item);
        return;
    }
    cJSON_AddItemToArray(p_data_array,  p_data_item);
    cJSON_AddItemToObject(p_root, "data", p_data_array);

    p_root_array = cJSON_CreateArray();
    if(p_root_array == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        cJSON_Delete(p_root);
        return;
    }
    cJSON_AddItemToArray(p_root_array, p_root);

    p = cJSON_PrintUnformatted(p_root_array);
    cJSON_Delete(p_root_array);
    mqtt_msg_publish(p_mqtt_cfg->mqtt_topic.monitor_upload_topic, (uint8_t *)p, strlen(p), MQTT_QOS0);
    free(p);
}