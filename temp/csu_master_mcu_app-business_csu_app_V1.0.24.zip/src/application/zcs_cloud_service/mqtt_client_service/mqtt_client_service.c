#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include "sys/time.h"
#include "signal.h"
#include "sofar_log.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk_public.h"
#include "sofar_errors.h"
#include "mqtt_client_service.h"
#include "zcs_cert.h"
#include "mosquitto.h"
#include "cJSON.h"
#include "mqtt_meter_data.h"
#include "mqtt_pcs_data.h"
#include "mqtt_bms_data.h"
#include "mqtt_bat_stack_data.h"
#include "mqtt_fc_data.h"
#include "mqtt_lc_data.h"
#include "mqtt_csu_data.h"
#include "user_timer.h"
#include "app_common.h"

static mqtt_config_t g_mqtt_cfg = {0};


/**
 * @brief   获取mqtt配置信息
 * @note
 * @return
 */
mqtt_config_t *mqtt_cfg_get(void)
{
    return &g_mqtt_cfg;
}


/**
 * @brief   订阅所有下行主题
 * @param   [in] mosq：mosquitto客户端句柄
 * @note
 * @return
 */
static void subscribe_all_topic(struct mosquitto *mosq)
{
    mosquitto_subscribe(mosq, NULL, g_mqtt_cfg.mqtt_topic.func_set_topic, MQTT_QOS0);
}


/**
 * @brief   主题订阅数据接收回调
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] userdata：用户数据
 * @param   [out] message:云端数据
 * @note
 * @return
 */
static void message_callback(struct mosquitto *mosq, void *userdata, const struct mosquitto_message *message)
{
    if (message->payloadlen)
	{
        MQTT_DEBUG_PRINT((int8_t *)"topic : %s len = %d", message->topic, message->payloadlen);
        MQTT_DEBUG_PRINT((int8_t *)"payload : %s len = %d\n", message->payload, message->payloadlen);
        mqtt_data_parse(mosq, message->topic, message->payload, message->payloadlen);
    }
}


/**
 * @brief   连接状态回调
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] userdata：用户数据
 * @param   [in] result：状态
 * @note
 * @return
 */
static void connect_callback(struct mosquitto *mosq, void *userdata, int result)
{
    internal_shared_data_t *p_shared_data = sdk_shm_internal_shared_data_get();

    if (result == 0)
	{
        MQTT_DEBUG_PRINT((int8_t *)"Connect success\n");
        //进行时区上报
        csu_local_timezone_upload();
        g_mqtt_cfg.mqtt_connect_status = ONLINE;
        p_shared_data->zcs_cloud_stage = CONNECT_SUCCESS;
        subscribe_all_topic(mosq);
    }
}


/**
 * @brief   连接断开状态回调
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] userdata：用户数据
 * @param   [in] result：状态
 * @note
 * @return
 */
static void disconnect_callback(struct mosquitto *mosq, void *userdata, int result)
{
    int ret = 0;

    MQTT_DEBUG_PRINT((int8_t *)"disconnect----->reconnect\n");
    g_mqtt_cfg.mqtt_connect_status = OFFLINE;
    ret = mosquitto_reconnect(mosq);
    if(ret != MOSQ_ERR_SUCCESS)
    {
        MQTT_DEBUG_PRINT((int8_t *)"reconnect error---------->%d\n", ret);
    }
}


/**
 * @brief   主题发布状态回调
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] obj
 * @param   [in] mosq：mosquitto客户端句柄
 * @note
 * @return
 */
static void publish_callback(struct mosquitto *mosq, void *obj, int mid)
{
    MQTT_DEBUG_PRINT((int8_t *)"data publish success--->");
}


/**
 * @brief   主题信息初始化
 * @param  
 * @note
 * @return
 */
static void mqtt_topic_init(void)
{
    sprintf(g_mqtt_cfg.mqtt_topic.monitor_upload_topic, "V1/data/%s/json", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.mqtt_topic.property_upload_topic, "V1/prop/%s/json", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.mqtt_topic.event_upload_topic, "V1/event/%s/json", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.mqtt_topic.property_set_topic, "V1/propSet/%s/json", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.mqtt_topic.property_set_ack_topic, "V1/propSetReply/%s/json", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.mqtt_topic.property_get_topic, "V1/propRead/%s/json", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.mqtt_topic.property_get_ack_topic, "V1/propReadReply/%s/json", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.mqtt_topic.func_set_topic, "V1/function/%s/json", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.mqtt_topic.func_set_ack_topic, "V1/functionReply/%s/json", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.mqtt_topic.ota_topic, "V1/ota/%s/json", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.mqtt_topic.ota_ack_topic, "V1/otaReply/%s/json", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.mqtt_topic.topology_topic, "V1/topology/%s/json", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.mqtt_topic.timezone_topic, "V1/timezone/%s/json", g_mqtt_cfg.dev_sn.csu_sn);

    MQTT_DEBUG_PRINT((int8_t *)"monitor_upload_topic:%s\n", g_mqtt_cfg.mqtt_topic.monitor_upload_topic);
    MQTT_DEBUG_PRINT((int8_t *)"property_upload_topic:%s\n", g_mqtt_cfg.mqtt_topic.property_upload_topic);
    MQTT_DEBUG_PRINT((int8_t *)"event_upload_topic:%s\n", g_mqtt_cfg.mqtt_topic.event_upload_topic);
    MQTT_DEBUG_PRINT((int8_t *)"property_set_topic:%s\n", g_mqtt_cfg.mqtt_topic.property_set_topic);
    MQTT_DEBUG_PRINT((int8_t *)"property_set_ack_topic:%s\n", g_mqtt_cfg.mqtt_topic.property_set_ack_topic);
    MQTT_DEBUG_PRINT((int8_t *)"property_get_topic:%s\n", g_mqtt_cfg.mqtt_topic.property_get_topic);
    MQTT_DEBUG_PRINT((int8_t *)"property_get_ack_topic:%s\n", g_mqtt_cfg.mqtt_topic.property_get_ack_topic);
    MQTT_DEBUG_PRINT((int8_t *)"func_set_topic:%s\n", g_mqtt_cfg.mqtt_topic.func_set_topic);
    MQTT_DEBUG_PRINT((int8_t *)"func_set_ack_topic:%s\n", g_mqtt_cfg.mqtt_topic.func_set_ack_topic);
    MQTT_DEBUG_PRINT((int8_t *)"ota_topic:%s\n", g_mqtt_cfg.mqtt_topic.ota_topic);
    MQTT_DEBUG_PRINT((int8_t *)"ota_ack_topic:%s\n", g_mqtt_cfg.mqtt_topic.ota_ack_topic);
    MQTT_DEBUG_PRINT((int8_t *)"topology_topic:%s\n", g_mqtt_cfg.mqtt_topic.topology_topic);
    MQTT_DEBUG_PRINT((int8_t *)"timezone_topic:%s\n", g_mqtt_cfg.mqtt_topic.timezone_topic);
}


/**
 * @brief   SN信息初始化
 * @param  
 * @note
 * @return
 */
static void dev_sn_init(void)
{
    telemetry_data_t *p_telemetry_data = NULL;
    p_telemetry_data = sdk_shm_telemetry_data_get();
    strcpy(g_mqtt_cfg.dev_sn.csu_sn, (char *)p_telemetry_data->sys_version_telemetry_info.sn_version_number);
    sprintf(g_mqtt_cfg.dev_sn.meter_sn, "%s_00_01", g_mqtt_cfg.dev_sn.csu_sn);
    sprintf(g_mqtt_cfg.dev_sn.pcc_meter_sn, "%s_01_01", g_mqtt_cfg.dev_sn.csu_sn);
    for(uint8_t i = 0; i < PV_METER_NUM; i++)
    {
        sprintf(g_mqtt_cfg.dev_sn.pv_meter_sn[i], "%s_02_%02d", g_mqtt_cfg.dev_sn.csu_sn, i + 1);
    }
    MQTT_DEBUG_PRINT((int8_t *)"csu sn:%s\n", g_mqtt_cfg.dev_sn.csu_sn);
    MQTT_DEBUG_PRINT((int8_t *)"meter sn:%s\n", g_mqtt_cfg.dev_sn.meter_sn);
    MQTT_DEBUG_PRINT((int8_t *)"pcc meter sn:%s\n", g_mqtt_cfg.dev_sn.pcc_meter_sn);
    for(uint8_t i = 0; i < PV_METER_NUM; i++)
    {
        MQTT_DEBUG_PRINT((int8_t *)"pv meter[%d] sn:%s\n", i + 1, g_mqtt_cfg.dev_sn.pv_meter_sn[i]);
    }
}


/**
 * @brief          获取当前时间时间戳
 * @return         [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
long long get_sys_timestamp(void)
{
    return time(NULL);
}


/**
 * @brief   消息发布
 * @param   [in] p_topic:主题信息
 * @param   [in] p_payload：数据
 * @param   [in] payload_len：数据长度
 * @note 
 * @return
 */
void mqtt_msg_publish(char *p_topic, uint8_t *p_payload, uint16_t payload_len, uint8_t qos)
{
    uint32_t ret = 0;
    cJSON *p_data = NULL;
    char *p = NULL;
    
    ret = mosquitto_publish(g_mqtt_cfg.mosq, NULL, p_topic, payload_len, p_payload, qos, 0);
    if(ret != 0)
    {
        MQTT_DEBUG_PRINT((int8_t *)"publish  error\n");
        return;
    }
    p_data = cJSON_Parse((char *)p_payload);
    if(p_data == NULL)
    {
        return;
    }
    p = cJSON_Print(p_data);
    MQTT_DEBUG_PRINT((int8_t *)"topic : %s", p_topic);
    printf("payload : %s\n", p);
    cJSON_Delete(p_data);
    free(p);
}



/**
 * @brief  	CSU监控项定时上报回调
 * @return 	
 */
void csu_monitor_data_upload_timer_cb(void *p_user_arg) 
{
    if(g_mqtt_cfg.mqtt_connect_status == ONLINE)
    {
        csu_monitor_data_upload();
    }
}

/**
 * @brief  	CSU监控项定时上报
 * @return 	
 */
static void csu_monitor_data_upload_timer(void)
{
    user_timer_hd csu_monitor_timer = NULL;

    csu_monitor_timer = user_timer_create(csu_monitor_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(csu_monitor_timer, 2 * 1000, MONITOR_REPORT_INTERVAL);     
}


/**
 * @brief  	电表监控项定时上报回调
 * @return 	
 */
void meter_monitor_data_upload_timer_cb(void *p_user_arg) 
{
    if(g_mqtt_cfg.mqtt_connect_status == ONLINE)
    {
        meter_monitor_data_upload();
    }
}

/**
 * @brief  	电表监控项定时上报
 * @return 	
 */
static void meter_monitor_data_upload_timer(void)
{
    user_timer_hd meter_monitor_timer = NULL;

    meter_monitor_timer = user_timer_create(meter_monitor_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(meter_monitor_timer, 8 * 1000, MONITOR_REPORT_INTERVAL);     
}


user_timer_hd pv_meter_monitor_timer = NULL;
/**
 * @brief   PV电表数据定时任务回调
 * @param
 * @note
 * @return
 */
void pv_meter_monitor_data_upload_timer_cb(void *p_user_arg)
{
    static uint8_t pv_meter_cnt = 0;
    constant_parameter_data_t *p_constant_param = sdk_shm_constant_parameter_data_get();

    if((g_mqtt_cfg.mqtt_connect_status == ONLINE) && (p_constant_param->cabinet_param_data.rs485_device_enable.bit.photovoltaic_meter) && (p_constant_param->photovoltaic_meter_cfg.meter_cnt > 0))
    {
        pv_meter_monitor_data_upload(pv_meter_cnt);
        pv_meter_cnt++;
        user_timer_set_timeout(pv_meter_monitor_timer, 1 * 1000, false);
        if(pv_meter_cnt >= p_constant_param->photovoltaic_meter_cfg.meter_cnt)
        {
            pv_meter_cnt = 0;
            user_timer_set_timeout(pv_meter_monitor_timer, MONITOR_REPORT_INTERVAL - p_constant_param->photovoltaic_meter_cfg.meter_cnt, true);
        }
    }
}


/**
 * @brief   PV电表数据定时上报
 * @param
 * @note
 * @return
 */
void pv_meter_monitor_data_upload_timer(void)
{
    

    pv_meter_monitor_timer = user_timer_create(pv_meter_monitor_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(pv_meter_monitor_timer, 12 * 1000, MONITOR_REPORT_INTERVAL);    
}


/**
 * @brief   PCC电表数据定时任务回调
 * @param
 * @note
 * @return
 */
void pcc_meter_monitor_data_upload_timer_cb(void *p_user_arg)
{
    constant_parameter_data_t *p_constant_param = sdk_shm_constant_parameter_data_get();

    if((g_mqtt_cfg.mqtt_connect_status == ONLINE) && (p_constant_param->cabinet_param_data.rs485_device_enable.bit.backflow_meter))
    {
        pcc_meter_monitor_data_upload();
    }
}


/**
 * @brief   PCC电表数据定时上报
 * @param
 * @note
 * @return
 */
void pcc_meter_monitor_data_upload_timer(void)
{
    user_timer_hd pcc_meter_monitor_timer = NULL;

    pcc_meter_monitor_timer = user_timer_create(pcc_meter_monitor_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(pcc_meter_monitor_timer, 13 * 1000, MONITOR_REPORT_INTERVAL);    
}



/**
 * @brief  	PCS监控项定时上报回调
 * @return 	
 */
void pcs_monitor_data_upload_timer_cb(void *p_user_arg) 
{
    if(g_mqtt_cfg.mqtt_connect_status == ONLINE)
    {
        pcs_monitor_data_upload();
    }
}

/**
 * @brief  	PCS监控项定时上报
 * @return 	
 */
static void pcs_monitor_data_upload_timer(void)
{
    user_timer_hd pcs_monitor_timer = NULL;

    pcs_monitor_timer = user_timer_create(pcs_monitor_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(pcs_monitor_timer, 15 * 1000, MONITOR_REPORT_INTERVAL);    
}


/**
 * @brief  	BMS监控项定时上报回调
 * @return 	
 */
void bms_monitor_data_upload_timer_cb(void *p_user_arg) 
{
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;

    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    if(g_mqtt_cfg.mqtt_connect_status == ONLINE)
    {
        for(uint8_t i = 0; i < p_energy_cabinet_data->cmu_data.sign_data.bcu_num; i++)
        {
            bms_monitor_data_upload();
        }
    }
}

/**
 * @brief  	BMS监控项定时上报
 * @return 	
 */
static void bms_monitor_data_upload_timer(void)
{
    user_timer_hd bms_monitor_timer = NULL;

    bms_monitor_timer = user_timer_create(bms_monitor_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(bms_monitor_timer, 20 * 1000, MONITOR_REPORT_INTERVAL);   
}


/**
 * @brief  	电池堆监控项定时上报回调
 * @return 	
 */
void bat_stack_monitor_data_upload_timer_cb(void *p_user_arg) 
{
    if(g_mqtt_cfg.mqtt_connect_status == ONLINE)
    {
        bat_stack_monitor_data_upload();
    }
}

/**
 * @brief  	电池堆监控项定时上报
 * @return 	
 */
static void bat_stack_monitor_data_upload_timer(void)
{
    user_timer_hd bs_monitor_timer = NULL;

    bs_monitor_timer = user_timer_create(bat_stack_monitor_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(bs_monitor_timer, 25 * 1000, MONITOR_REPORT_INTERVAL);    
}


/**
 * @brief  	消防监控项定时上报回调
 * @return 	
 */
void fc_monitor_data_upload_timer_cb(void *p_user_arg) 
{
    if(g_mqtt_cfg.mqtt_connect_status == ONLINE)
    {
        fc_monitor_data_upload();
    }
}

/**
 * @brief  	消防监控项定时上报
 * @return 	
 */
static void fc_monitor_data_upload_timer(void)
{
    user_timer_hd fc_monitor_timer = NULL;

    fc_monitor_timer = user_timer_create(fc_monitor_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(fc_monitor_timer, 30 * 1000, MONITOR_REPORT_INTERVAL);    
}


/**
 * @brief  	液冷监控项定时上报回调
 * @return 	
 */
void lc_monitor_data_upload_timer_cb(void *p_user_arg) 
{
    if(g_mqtt_cfg.mqtt_connect_status == ONLINE)
    {
        lc_monitor_data_upload();
    }
}

/**
 * @brief  	液冷监控项定时上报
 * @return 	
 */
static void lc_monitor_data_upload_timer(void)
{
    user_timer_hd lc_monitor_timer = NULL;

    lc_monitor_timer = user_timer_create(lc_monitor_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(lc_monitor_timer, 35 * 1000, MONITOR_REPORT_INTERVAL);   
}

/**
 * @brief   故障列表初始化
 * @param
 * @return
 */
static void event_list_init(void)
{
    pcs_event_list_init();
    bms_event_list_init();
    fc_event_list_init();
    lc_event_list_init();
}



/**
 * @brief  	属性数据上报
 * @return 	
 */
static void mqtt_data_property_upload(void)
{
    // sofar_ota_info_t *p_sofar_ota_info = NULL;
    // p_sofar_ota_info = sofar_ota_info_get();
    constant_parameter_data_t *p_constant_param = sdk_shm_constant_parameter_data_get();

    if(g_mqtt_cfg.mqtt_connect_status == ONLINE)
    {
        bat_stack_topology_data_upload();                  
        csu_property_data_upload();
        meter_property_data_upload();
        if((p_constant_param->cabinet_param_data.rs485_device_enable.bit.photovoltaic_meter) && (p_constant_param->photovoltaic_meter_cfg.meter_cnt > 0))
        {
            pv_meter_property_data_upload();
        }
        if(p_constant_param->cabinet_param_data.rs485_device_enable.bit.backflow_meter > 0)
        {
            pcc_meter_property_data_upload();
        }
        cmu_property_data_upload();
        pcs_property_data_upload();
        bms_property_data_upload();
        bat_stack_property_data_upload();
        fc_property_data_upload();
        lc_property_data_upload();
    } 
}


/**
 * @brief  	事件数据上报
 * @return 	
 */
static void mqtt_data_event_upload(void)
{
    // sofar_ota_info_t *p_sofar_ota_info = NULL;
    // p_sofar_ota_info = sofar_ota_info_get();

    if(g_mqtt_cfg.mqtt_connect_status == ONLINE)
    {
        pcs_event_data_upload();
        bms_event_data_upload();
        fc_event_data_upload();
        lc_event_data_upload();
    } 
}


/**
 * @brief  	时区更新上报
 * @return 	
 */
static void mqtt_tz_update_upload(void)
{
    internal_shared_data_t *p_shared_data = sdk_shm_internal_shared_data_get();

    if((g_mqtt_cfg.mqtt_connect_status == ONLINE) && (BIT_GET(p_shared_data->tz_update_flag, 1)))
    {
        csu_local_timezone_upload();
        BIT_CLR(p_shared_data->tz_update_flag, 1);
    } 
}



/**
 * @brief   实时数据上报服务
 * @param   [in] arg
 * @note
 * @return
 */
static void *mqtt_real_time_upload_service(void *arg)
{
    while(1)
	{  
        // 属性数据上报，即时上报
        mqtt_data_property_upload();
        //事件数据上报，即时上报
        mqtt_data_event_upload();
        //时区更新上报
        mqtt_tz_update_upload();
        usleep(1000 * 200);
    }
    return NULL;
}


/**
 * @brief   实时数据上报线程
 * @param
 * @note
 * @return
 */
void mqtt_real_time_upload_init(void)
{
	pthread_t real_time_upload;
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	if(pthread_create(&real_time_upload, &attr, mqtt_real_time_upload_service, NULL) != 0)
	{
		perror("pthread_create tcp server service");
	}
	pthread_attr_destroy(&attr);
}




/**
 * @brief   mqtt client服务线程
 * @param   [in] arg
 * @note
 * @return
 */
static void *mqtt_client_service(void *arg)
{
    struct mosquitto *p_mosq = NULL;

    //libmosquitto 库初始化
    mosquitto_lib_init();

    dev_sn_init();
    mqtt_topic_init();

    p_mosq = mosquitto_new(mqtt_cfg_get()->dev_sn.csu_sn, true, NULL);
    if(!p_mosq) {
        // Handle error
        return NULL;
    }

    g_mqtt_cfg.mosq = p_mosq;
 
    mosquitto_tls_set(p_mosq, CA_PATH, NULL, CERT_PATH, PRIVATE_PATH, NULL);
    mosquitto_tls_opts_set(p_mosq, true, NULL, NULL);
    mosquitto_tls_insecure_set(p_mosq, true);


    //注册回调
    mosquitto_connect_callback_set(g_mqtt_cfg.mosq, connect_callback);
    mosquitto_message_callback_set(g_mqtt_cfg.mosq, message_callback);
    mosquitto_publish_callback_set(g_mqtt_cfg.mosq, publish_callback);
    mosquitto_disconnect_callback_set(g_mqtt_cfg.mosq, disconnect_callback);

 
    int ret = mosquitto_connect(p_mosq, MQTT_HOST, MQTT_PORT, 60);
    if(ret != MOSQ_ERR_SUCCESS) 
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"mosquitto_connect error\n");
        mosquitto_destroy(p_mosq);
        return NULL;
    }
    else
    {
        ZCS_CERT_DEBUG_PRINT((int8_t *)"mosquitto_connect ok\n");
    }

    //故障列表初始化
    event_list_init();

    //初始化各个定时器
    csu_monitor_data_upload_timer();
    meter_monitor_data_upload_timer();
    pv_meter_monitor_data_upload_timer();
    pcc_meter_monitor_data_upload_timer();
    pcs_monitor_data_upload_timer();
    bms_monitor_data_upload_timer();
    bat_stack_monitor_data_upload_timer();
    fc_monitor_data_upload_timer();
    lc_monitor_data_upload_timer();

    mqtt_real_time_upload_init();
	while(1)
	{   
        if(mosquitto_loop_forever(p_mosq, 100, 1) != MOSQ_ERR_SUCCESS)
        {
            mosquitto_reconnect(p_mosq);
        }
		usleep(1000 * 200);
	}
    return NULL;
}

/**
 * @brief   mqtt client服务模块初始化
 * @param
 * @note
 * @return
 */
void zcs_mqtt_client_module_init(void)
{
	pthread_t mqtt_client;
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	if(pthread_create(&mqtt_client, &attr, mqtt_client_service, NULL) != 0)
	{
		perror("pthread_create tcp server service");
	}
	pthread_attr_destroy(&attr);
}