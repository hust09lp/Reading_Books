#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include "data_shm.h"
#include "sdk_shm.h"
#include "errors.h"
#include "sofar_log.h"
#include "zcs_cert.h"
#include "mqtt_client_service.h"


/**
 * @brief  	获取网路状态
 * @return 	0：没有外网 1：有外网可连接服务器
 */
static uint8_t get_curr_net_status(void)
{
    char *p_host[3] = {
        "www.google.com",
        "www.baidu.com",
        "cn.pool.ntp.org"
    };
    static uint32_t i = 0;
    char cmd[256] = {0};
    char tmp_buff[32] = {0};
    FILE *fp = NULL;

    snprintf(cmd, 256, "ping -c 1 -W 1 %s | awk '/packet loss/{print $7}'", p_host[i % 3]);
	fp = popen(cmd,"r");

    fread(tmp_buff, 1, sizeof(tmp_buff), fp);
    i++;
    printf("ping ack:%s\n", tmp_buff);
	if(!strncmp(tmp_buff, "0%", strlen("0%")))
	{
		pclose(fp);
		return 1;
	}
    pclose(fp);
    return 0;
}


/**
 * @brief   判断ZCS云服务是否开启
 * @param 
 * @note
 * @return 1：开启  0：未开启
 */
static uint8_t if_zcs_cloud_service_enable(void)
{
    internal_shared_data_t *p_shared_para = sdk_shm_internal_shared_data_get();

    return (p_shared_para->zcs_cloud_enable);
}


/**
 * @brief   ZCS云服务进程
 * @param   [in] arg
 * @note
 * @return
 */
int main(int argc, char *argv[])
{
	int32_t ret;
    internal_shared_data_t *p_shared_data = sdk_shm_internal_shared_data_get();

    //日志初始化
	log_init((int8_t *)PATH_CONF);
    log_set_level(LOG_LVL_DEBUG);
    sleep(5);
    //共享内存初始化
	ret = common_data_init();  
	if(ret != 0)
	{
		return 0;
	}
    sleep(10);

    p_shared_data = sdk_shm_internal_shared_data_get();
    
    while (!if_zcs_cloud_service_enable())
    {
        printf("zcs cloud service not enable\n");
        sleep(5);
    }
    p_shared_data->zcs_cloud_stage = CFG_ENABLE;
    //等待网络连接
    while (!get_curr_net_status())
    {
        sleep(2);
    }
    p_shared_data->zcs_cloud_stage = NETWORK_ENABLE;
    //https 证书获取
    while(zcs_cert_get() != 0)
    {
        sleep(2);
    }
    p_shared_data->zcs_cloud_stage = CERT_ENABLE;
    //mqtt client务模块初始化
    zcs_mqtt_client_module_init();

	while(1)
	{
		sleep(1);
	}

	return 0;
}