#include <stdio.h>
#include <string.h>
 #include <unistd.h>
#include <pthread.h>
#include "sdk_shm.h"
#include "sdk_version.h"
#include "sofar_log.h"
#include "data_shm.h"
#include "integration_task.h"


#define VERSION_SIZE_MAX            (10)
#define HARDWARE_VERSION_SIZE       (2)
#define SOFTWARE_VERSION_SIZE       (4)

// #define ADC_CHANNEL                 (8)
// #define ADC_CONVERT_SPACING         (512)

// #define VERSION_LOW_VALUE           (0x30)


static integrated_version_t g_integrated_info;

#if 0
/**
 * @brief  获取mcu1硬件版本号
 * @param  [in]  len_max 传入版本号字节长度，避免数据超出传入数组的大小
 * @param  [out] p_version  版本数据存在p_version所指向的地址中，传出参数
 * @return 执行结果  >=0:版本号的实际长度   <0:失败
 */
int16_t mcu1_hardver_get(uint8_t *p_version, uint16_t len_max)
{
    int16_t len = 0;
    int32_t adc_result = 0;
    int32_t times_tmp = 0;

    if(NULL == p_version || len_max < HARDWARE_VERSION_SIZE)
    {
        return -1;
    }
    
    INTE_DEBUG_LOG((int8_t *)"[mcu1_hardver_get] adc result get before!\n");
    // adc_result = sdk_adc_get(ADC_CHANNEL);
    sdk_adc_read(ADC_CHANNEL, &adc_result);

    INTE_DEBUG_LOG((int8_t *)"[mcu1_hardver_get] adc result get over!\n");
    if(adc_result < 0)
    {
        return -1;
    }
    times_tmp = (adc_result-1)/ADC_CONVERT_SPACING;      

    switch(times_tmp)
    {
        case 0:
        {
            p_version[len++] = 'V';
            p_version[len++] = VERSION_HIGH_VALUE1;
            p_version[len++] = '.';
            p_version[len++] = VERSION_LOW_VALUE; 
            break;
        }
        case 1:
        {
            p_version[len++] = 'V';
            p_version[len++] = VERSION_HIGH_VALUE2;
            p_version[len++] = '.';
            p_version[len++] = VERSION_LOW_VALUE;
            break;
        }
        case 2:
        {
            p_version[len++] = 'V';
            p_version[len++] = VERSION_HIGH_VALUE3;
            p_version[len++] = '.';
            p_version[len++] = VERSION_LOW_VALUE;
            break;
        }
        case 3:
        {
            p_version[len++] = 'V';
            p_version[len++] = VERSION_HIGH_VALUE4;
            p_version[len++] = '.';
            p_version[len++] = VERSION_LOW_VALUE;
            break;
        }
        case 4:
        {
            p_version[len++] = 'V';
            p_version[len++] = VERSION_HIGH_VALUE5;
            p_version[len++] = '.';
            p_version[len++] = VERSION_LOW_VALUE;
            break;
        }
        case 5:
        {
            p_version[len++] = 'V';
            p_version[len++] = VERSION_HIGH_VALUE6;
            p_version[len++] = '.';
            p_version[len++] = VERSION_LOW_VALUE;
            break;
        }
        case 6:
        {
            p_version[len++] = 'V';
            p_version[0] = VERSION_HIGH_VALUE7;
            p_version[len++] = '.';
            p_version[1] = VERSION_LOW_VALUE;
            break;
        }
        case 7:
        {
            p_version[len++] = 'V';
            p_version[len++] = VERSION_HIGH_VALUE8;
            p_version[len++] = '.';
            p_version[len++] = VERSION_LOW_VALUE;
            break;
        }
        default:
        {
            return -1;
        }
    }

    return len;
}

#endif

/**
 * @brief  综合版本号获取--有变动则更新上传
 * @param  [in]  none
 * @param  [out] none
 * @return none
 */
void integrated_version_get(void)
{
    int32_t len_hard = 0;
    int32_t len_core = 0;
    int32_t tmp = 0;
    int8_t version[VERSION_SIZE_MAX];
	int8_t boot_version[4] = {0};
    common_data_t *shm = NULL;

    shm = sdk_shm_get();
	telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();              // 遥测
    if(NULL == shm)
    {
        return;
    }

    memset(version, '0', sizeof(version));

    INTE_DEBUG_LOG((int8_t *)"[integrated_version_get] ready to get hardware version!\n");
    // 1、获取mcu1硬件版本号
    // len_hard = mcu1_hardver_get(version, VERSION_SIZE_MAX);
    len_hard = sdk_version_get(HW_VERSION_TYPE, version, VERSION_SIZE_MAX);
 
    INTE_DEBUG_LOG((int8_t *)"[integrated_version_get] get_len_hard = %d\n", len_hard);
    INTE_DEBUG_LOG((int8_t *)"[integrated_version_get] get_hard_ver_0 = %c\n", version[0]);
    INTE_DEBUG_LOG((int8_t *)"[integrated_version_get] get_hard_ver_1 = %c\n", version[1]);
    INTE_DEBUG_LOG((int8_t *)"[integrated_version_get] get_hard_ver_2 = %c\n", version[2]);
    INTE_DEBUG_LOG((int8_t *)"[integrated_version_get] get_hard_ver_3 = %c\n", version[3]);
    
    if(len_hard > 0)
    {
        // 比较版本号是否变更
        tmp = memcmp(version, g_integrated_info.mcu1_hardware_version, len_hard);
        if(0 != tmp)
        {
            // 清共享内存mcu1硬件版本号
            // memset(shm->internal_version_info.mcu1_hardware_version, 0, sizeof(uint8_t)*HARDWARE_VERSION_SIZE);
            // 更新至共享内存
            shm->internal_version_info.mcu1_hardware_version[0] = version[1] - '0';
            shm->internal_version_info.mcu1_hardware_version[1] = version[3] - '0';
            // mcu2硬件版本号与mcu1一致
            //memcpy(shm->internal_version_info.mcu2_hardware_version, shm->internal_version_info.mcu1_hardware_version, sizeof(shm->internal_version_info.mcu2_hardware_version));
            // 更新记录
            memcpy(g_integrated_info.mcu1_hardware_version, version, len_hard);
			memcpy(&p_telemetry_data->sys_version_telemetry_info.hardware_version_number, shm->internal_version_info.mcu1_hardware_version, 2);

        }
    }

    memset(version, '0', sizeof(version));

    // 2、获取mcu1core层软件版本号
    len_core = sdk_version_get(CORE_VERSION_TYPE, version, VERSION_SIZE_MAX);
    INTE_DEBUG_LOG((int8_t *)"[integrated_version_get] get_len_core = %d\n", len_core);
    INTE_DEBUG_LOG((int8_t *)"[integrated_version_get] get_core_ver_0 = %c\n", version[0]);
    INTE_DEBUG_LOG((int8_t *)"[integrated_version_get] get_core_ver_1 = %c\n", version[1]);
    INTE_DEBUG_LOG((int8_t *)"[integrated_version_get] get_core_ver_2 = %c\n", version[2]);
    INTE_DEBUG_LOG((int8_t *)"[integrated_version_get] get_core_ver_3 = %c\n", version[3]);
    INTE_DEBUG_LOG((int8_t *)"[integrated_version_get] get_core_ver_4 = %c\n", version[4]);
    INTE_DEBUG_LOG((int8_t *)"[integrated_version_get] get_core_ver_5 = %c\n", version[5]);

    if(len_core > 0)
    {
        // 比较版本号是否变更
        tmp = memcmp(version, g_integrated_info.mcu1_core_soft_version, len_core);
        if(0 != tmp)
        {
            // 更新至共享内存
            shm->internal_version_info.mcu1_core_soft_version[0] = version[0];
            shm->internal_version_info.mcu1_core_soft_version[1] = version[1] - '0';
            shm->internal_version_info.mcu1_core_soft_version[2] = version[3] - '0';
            shm->internal_version_info.mcu1_core_soft_version[3] = version[5] - '0';
			memcpy(&p_telemetry_data->sys_version_telemetry_info.mcu1_core_version_number,shm->internal_version_info.mcu1_core_soft_version,4);
			printf("p_telemetry_data->sys_version_telemetry_info.mcu1_core_version_number[%d]\n",p_telemetry_data->sys_version_telemetry_info.mcu1_core_version_number);
            // 更新记录
            memcpy(g_integrated_info.mcu1_core_soft_version, version, len_core);

        }
    }


	// 2、获取mcu1boot层软件版本号
    len_core = sdk_version_get(BOOT_VERSION_TYPE, version, VERSION_SIZE_MAX);
	if(len_core > 0)
    {
   
    	INTE_DEBUG_LOG((int8_t *)"[integrated_version_get] get_len_core = %d\n", len_core);
   		INTE_DEBUG_LOG((int8_t *)"[integrated_version_get] get_boot_ver_0 = %c\n", version[0]);
   	 	INTE_DEBUG_LOG((int8_t *)"[integrated_version_get] get_boot_ver_1 = %c\n", version[1]);
    	INTE_DEBUG_LOG((int8_t *)"[integrated_version_get] get_boot_ver_2 = %c\n", version[2]);
    	INTE_DEBUG_LOG((int8_t *)"[integrated_version_get] get_boot_ver_3 = %c\n", version[3]);
   	 	INTE_DEBUG_LOG((int8_t *)"[integrated_version_get] get_boot_ver_4 = %c\n", version[4]);
    	INTE_DEBUG_LOG((int8_t *)"[integrated_version_get] get_boot_ver_5 = %c\n", version[5]);

		boot_version[0] = version[0];
		boot_version[1] = version[1] - '0';
		boot_version[2] = version[3] - '0';
		boot_version[3] = version[5] - '0';

		memcpy(&p_telemetry_data->sys_version_telemetry_info.mcu1_boot_version_number, boot_version, 4);
		printf("mcu1_boot_version_number %d \n",p_telemetry_data->sys_version_telemetry_info.mcu1_boot_version_number);

	}
    return;
}

void integration_version_init(void)
{

    memset(g_integrated_info.mcu1_hardware_version, '0', sizeof(g_integrated_info.mcu1_hardware_version));
    memset(g_integrated_info.mcu1_core_soft_version, '0', sizeof(g_integrated_info.mcu1_core_soft_version));
    return;
}

/**
 * @brief  综合任务线程
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
void *thread_integration(void *arg)
{
    INTE_DEBUG_LOG((int8_t *)"[thread_integration] ready to init!\n");
    integration_version_init();
    INTE_DEBUG_LOG((int8_t *)"[thread_integration] init over!\n");

    // 综合版本获取及上传	
	integrated_version_get();

	while(1)
	{   
        //INTE_DEBUG_LOG((int8_t *)"[thread_integration] ready to get version!\n");

		sleep(1);				
	}

	pthread_exit(NULL);
}

/**
 * @brief  启动综合任务线程
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
void integration_task_start(void)
{
    int32_t ret = 0;
	pthread_attr_t inte_attr;
	pthread_t integration_task;
	
    // 初始化线程属性
    ret = pthread_attr_init(&inte_attr);
    if (ret)
    {
        INTE_DEBUG_LOG((int8_t *)"\n [%s:%d] pthread_attr_init error!!! \n", __func__, __LINE__);
        return; // 线程属性初始化出错退出
    }
    
    // 设置线程属性为分离状态
    ret = pthread_attr_setdetachstate(&inte_attr, PTHREAD_CREATE_DETACHED);
    if (ret)
    {
        INTE_DEBUG_LOG((int8_t *)"\n [%s:%d] pthread_attr_setdetachstate info_record_attr error!!! \n", __func__, __LINE__);
        return; // 线程分离属性设置出错退出
    }
    // 创建综合任务线程
    ret = pthread_create(&integration_task, &inte_attr, &thread_integration, NULL);
    if (ret)
    {
        INTE_DEBUG_LOG((int8_t *)"\n [%s:%d] pthread_create integration_task error!!! \n", __func__, __LINE__);
        return; // 线程创建出错退出
    }  

    // 销毁线程属性结构,它在重新初始化之前不能重新使用
    pthread_attr_destroy(&inte_attr);

	return;
}

