#ifndef __CRC_H__
#define __CRC_H__



#include "data_types.h"

// uint16_t __crc_modbus(uint8_t *data, uint8_t len);
// #define crc_modbus(data, len)	__crc_modbus((uint8_t *)data, (uint8_t)len)

// extern const uint8_t table_hig[];               					//MLPadd  2021.10.15
// extern const uint8_t table_low[];

uint16_t crc16_modbus(uint8_t *data, uint8_t len);
uint32_t crc32( const unsigned char *buf, unsigned int size);

#endif
