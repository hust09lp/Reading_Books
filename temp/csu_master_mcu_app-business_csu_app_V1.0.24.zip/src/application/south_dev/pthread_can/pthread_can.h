#ifndef __PTHREAD_CAN_H__ 
#define __PTHREAD_CAN_H__
#include "data_shm.h"

#if (0)
#define CAN_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else 
#define CAN_DEBUG_PRINT(...) {do {} while(0);}
#endif

typedef struct 
{
	uint8_t src_addr;		// source address
	uint8_t src_type;		// source device type
	uint8_t dst_addr;		// destination address
	uint8_t dst_type;		// destination device type	
	uint8_t fun_code;		// CAN Frame function code
	uint8_t flag;		    // Q:test 添加的连续标志
	uint8_t type;			// 帧类型，1：数据帧；2:请求帧；3：应答帧
	uint8_t prio;			// CAN Frame fun_code priority	

	uint16_t addr;			// 数据帧的功能码对应的偏移地址	
}can_msg_t;


typedef union{
	uint32_t id_val;
	struct{
		uint32_t src_addr:	5;	// source address
		uint32_t src_type:	3;	// source device type
		uint32_t dst_addr:	5;	// destination address
		uint32_t dst_type:	3;	// destination device type
		uint32_t fun_code:	7;	// < CAN Frame function code
        uint32_t flag:	    1;	// 连续标志 0非连续，1是连续帧
        uint32_t type:	    2;	// 帧类型1：数据帧；2：功能帧-请求帧；3：功能帧-应答帧
		uint32_t prio:		3;	// < CAN Frame fun_code priority
		uint32_t  : 		2;	// < Reserved. 
        uint32_t format:	1;	// 0 表示标准帧，1表示拓展帧
	}bit;
}can_frame_id_u;

void innercan_task_start(void);
#endif