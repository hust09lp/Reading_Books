#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

#include <unistd.h>
#include <sys/time.h>
#include <string.h>
#include <sys/prctl.h>
#include "sdk_can.h"
#include "sdk_shm.h"
#include "sdk_public.h"
#include "app_common.h"
#include "sdk_fs.h"
#include "command_parser.h"
#include "pthread_can.h"

#define CAN1_PORT (0)
#define CAN2_PORT (1)
void *thread_can_test(void *arg)
{
	CAN_DEBUG_PRINT("thread_can_test\n");
	can_msg_t can_msg = {0};
	sdk_can_cfg_t can_cfg;
	uint8_t data[8] = {0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88};
	uint8_t recv_data[8] = {0x88,0x77,0x66,0x55,0x44,0x33,0x22,0x11};

	can_cfg.baud = SDK_CAN_BAUD_500K;
	can_cfg.mode = SDK_CAN_MODE_NORMAL;


	if(sdk_can_open(CAN2_PORT) < 0)
	{
		CAN_DEBUG_PRINT("\n [%s:%d] open CAN1 fail!\n",__func__, __LINE__);
		pthread_exit(NULL);
	}

	if (sdk_can_setup(CAN2_PORT, &can_cfg) < 0)
	{
		CAN_DEBUG_PRINT("sdk_can_setup can1 fail! \n");
		pthread_exit(NULL);
	}
	if(sdk_can_open(CAN1_PORT) < 0)
	{
		CAN_DEBUG_PRINT("\n [%s:%d] open CAN0 fail!\n",__func__, __LINE__);
		pthread_exit(NULL);
	}

	if (sdk_can_setup(CAN1_PORT, &can_cfg) < 0)
	{
		CAN_DEBUG_PRINT("sdk_can_setup can0 fail! \n");
		pthread_exit(NULL);
	}
	int32_t rc = 0;
	sdk_can_frame_t txframe = {0};
	sdk_can_frame_t rxframe = {0};
	can_frame_id_u can_frame_id;

	while(1)
	{
		#if 1
		CAN_DEBUG_PRINT("factory_data.test_mode[%d]\n",factory_data.test_mode);
		if((factory_data.test_mode == 0) || ((factory_data.communi_ctrl & 0x01) != 1))
		{
			usleep(100*1000);				// 1s
			CAN_DEBUG_PRINT("thread_can_test is sleep\r\n");
			continue;
		}
		BIT_CLR(factory_data.communi_result, 0);
		// sleep(2);
		memset(&can_msg,0,sizeof(can_msg_t));
		txframe.len = 8;
		txframe.id = 0x12345678 | 0x80000000;
		memcpy(&(txframe.data[0]), data, 8);
		CAN_DEBUG_PRINT("sdk_can_write(1, &txframe, 1)\r\n");   //打印数据
		// cup_sofar_can_send(0,&can_msg,txframe.data,8);
		rc = sdk_can_write(CAN1_PORT, &txframe, 1);
		CAN_DEBUG_PRINT(" rc1 = %d\r\n", rc);
		// usleep(500*1000);
		rc = sdk_can_read(CAN2_PORT, &rxframe, 1, 2000); //加锁
		CAN_DEBUG_PRINT(" rc = %d\r\n", rc);
		if (rc > 0)     // 接收到CAN的数据
		{
			//CAN_DEBUG_PRINT("cup_sofar_can_rev: recv data\n");
			//data_print(txframe.data, 8);   //打印数据

			can_frame_id.id_val = rxframe.id;

			can_msg.src_addr = can_frame_id.bit.src_addr;
			can_msg.src_type = can_frame_id.bit.src_type;
			can_msg.dst_addr = can_frame_id.bit.dst_addr;
			can_msg.dst_type = can_frame_id.bit.dst_type;
			can_msg.fun_code = can_frame_id.bit.fun_code;
			can_msg.flag = can_frame_id.bit.flag;//Q:不添加这个连续标志的话，当帧结构为长帧时，没法立马返回数据，该如何进行处理
			can_msg.type = can_frame_id.bit.type;
			can_msg.prio = can_frame_id.bit.prio;

			CAN_DEBUG_PRINT("CAN_RECV 0: id[%x],index[%x],fun_code[%d],recv data from src_type[%d],src_addr[%d],dst_type[%d],dst_addr[%d],flag[%d],type[%d],prio[%d]!\n",
				(can_frame_id.id_val & 0x1fffffff),txframe.data[0],can_msg.fun_code,can_msg.src_type,can_msg.src_addr,can_msg.dst_type,can_msg.dst_addr,can_msg.flag,can_msg.type,can_msg.prio);
			//data_print(txframe.data, 8);   //打印数据
			//if((rxframe.id == 0x10008001) )
			if(memcmp(rxframe.data, data, 8) == 0)
			{
				CAN_DEBUG_PRINT("thread_can6 recv 0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88\n");
				txframe.len = 8;
				txframe.id = 0x12222222 | 0x80000000;
				//txframe.id = 0x1FFFFFF2;
				memcpy(&(txframe.data[0]), recv_data, 8);
				CAN_DEBUG_PRINT("%X\r\n",txframe.id);
				CAN_DEBUG_PRINT("thread_can6 send 0x88,0x77,0x66,0x55,0x44,0x33,0x22,0x11\n");
				sdk_can_write(CAN2_PORT, &txframe, 1);

				rc = sdk_can_read(CAN1_PORT, &rxframe, 1, 2000); //加锁

				if (rc > 0)     // 接收到CAN的数据
				{
					//CAN_DEBUG_PRINT("cup_sofar_can_rev: recv data\n");
					//data_print(txframe.data, 8);   //打印数据

					can_frame_id.id_val = rxframe.id;

					can_msg.src_addr = can_frame_id.bit.src_addr;
					can_msg.src_type = can_frame_id.bit.src_type;
					can_msg.dst_addr = can_frame_id.bit.dst_addr;
					can_msg.dst_type = can_frame_id.bit.dst_type;
					can_msg.fun_code = can_frame_id.bit.fun_code;
					can_msg.flag = can_frame_id.bit.flag;//Q:不添加这个连续标志的话，当帧结构为长帧时，没法立马返回数据，该如何进行处理
					can_msg.type = can_frame_id.bit.type;
					can_msg.prio = can_frame_id.bit.prio;

					CAN_DEBUG_PRINT("CAN_RECV 1: id[%x],index[%x],fun_code[%d],recv data from src_type[%d],src_addr[%d],dst_type[%d],dst_addr[%d],flag[%d],type[%d],prio[%d]!\n",
						(can_frame_id.id_val & 0x1fffffff),txframe.data[0],can_msg.fun_code,can_msg.src_type,can_msg.src_addr,can_msg.dst_type,can_msg.dst_addr,can_msg.flag,can_msg.type,can_msg.prio);
					//data_print(txframe.data, 8);   //打印数据
					//if((rxframe.id == 0x10008001) )
					if(memcmp(rxframe.data, recv_data, 8) == 0)
					{
						// txframe.len = 8;
						// txframe.id = 0x13333333 | 0x80000000;
						// //txframe.id = 0x1FFFFFF2;
						// memcpy(&(txframe.data[0]), data, 8);
						// CAN_DEBUG_PRINT("%X\r\n",txframe.id);
						// sdk_can_write(0, &txframe, 1);
						BIT_SET(factory_data.communi_result, 0);
					}
				}
				else
				{
					CAN_DEBUG_PRINT("sdk_can_read can0 error[%d]\n",rc);
				}
			}
		}
		else
		{
			CAN_DEBUG_PRINT("sdk_can_read can0 error[%d]\n",rc);
		}
		BIT_CLR(factory_data.communi_ctrl, 0);
		#endif

	}

	pthread_exit(NULL);
}



void innercan_task_start(void)
{
	pthread_attr_t attr;

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);

	pthread_t can_test_id;
	if(pthread_create(&can_test_id,&attr,thread_can_test,NULL) != 0)
	{
		perror("pthread_create thread_can_test");
	}
	pthread_attr_destroy(&attr);
	return;

}



