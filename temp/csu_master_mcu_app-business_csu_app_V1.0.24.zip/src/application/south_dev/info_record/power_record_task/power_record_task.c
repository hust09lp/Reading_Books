#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include "sdk_shm.h"
#include "sdk_fs.h"
#include "sdk_public.h"
#include "sofar_log.h"
#include "sqlite3.h"
#include "data_shm.h"
#include "info_record.h"
#include "power_record_task.h"

#define PATH_POWER_GENERAL_DIR	 "/user/data/power/"			// 功率存储总目录
#define POWER_FLOW_DB	 "/user/data/power/power_flow.db"	    // 能流功率数据库文件路径
#define PV_METER_MAX_NUM             3

static power_record_task_t g_power_record_task = {0};

static void power_record_init(void);


/**
 * @brief  获取当前时间
 * @param  [in] none
 * @param  [out] none
 * @return 返回当前时间结构体变量
 */
static void update_current_time(power_time_t *p_time)
{
    int32_t ret = 0;
    sdk_rtc_t now = {0};

    ret = sdk_rtc_get(RTC_BIN_FORMAT, &now);
    if (ret != 0)
    {
        return;
    }

    p_time->year = (int16_t)now.tm_year + 2000;
    p_time->month = (int16_t)now.tm_mon;
    p_time->day = (int16_t)now.tm_day;
    p_time->hour = (int16_t)now.tm_hour;
    p_time->minute = (int16_t)now.tm_min;
    p_time->second = (int16_t)now.tm_sec;

}


/**
 * @brief  时间变化判断函数
 * @param  [in] updatetime 更新时的时间
 * @param  [in] lastsavetime 上一次保存的时间
 * @param  [out] none
 * @return 时间变化类型
 */
static uint8_t get_time_change(power_time_t updatetime, power_time_t lastsavetime)
{
	if (updatetime.year < HISTORY_POWER_YEAR_START)	// 年限不合理，不进行功率记录
	{
		return POWER_NO_CHANGE;
	}
 
	if (lastsavetime.year != updatetime.year)
	{
		return POWER_YEAR_CHANGE;
	}
	if (lastsavetime.month != updatetime.month)
	{
		return POWER_MONTH_CHANGE;
	}
	if (lastsavetime.day != updatetime.day)
	{
		return POWER_DAY_CHANGE;
	}
	if (lastsavetime.hour != updatetime.hour)
	{
		return POWER_HOUR_CHANGE;
	}
    if (lastsavetime.minute != updatetime.minute)
    {
        return POWER_SOME_MINS_CHANGE;
    }

	return POWER_NO_CHANGE;
}

/**
 * @brief  创建数据库
 * @param  [in] 
 * @param  [in]
 * @param  [out]
 * @return 
 *
 */
static void create_energy_meter_power_table(void)
{
    sqlite3 *db;
    char *sql = "CREATE TABLE IF NOT EXISTS power_data (date TEXT PRIMARY KEY, power REAL);";
    char *err_msg = 0;
    int rc = 0;
    char db_name[512] = {0};
    sdk_rtc_t now;

    sdk_rtc_get(RTC_BIN_FORMAT, &now);

    sprintf(db_name, "%s%s-%d%s",PATH_POWER_GENERAL_DIR, "power", now.tm_year, ".db");
    
    rc = sqlite3_open(db_name, &db);
    if(rc) 
    {
        INFO_RECORD_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
        return;
    }
 
    rc = sqlite3_exec(db, sql, 0, 0, &err_msg);
    if (rc != SQLITE_OK) 
    {
        INFO_RECORD_DEBUG_PRINT((int8_t *)"Failed to create table: %s\n", err_msg);
        sqlite3_free(err_msg);
    }
 
    sqlite3_close(db);
}


/**
 * @brief  创建能流功率数据库(PCC PV 负载，限制365天)
 * @param  [in] 
 * @param  [in]
 * @param  [out]
 * @return 
 *
 */
static void create_energy_flow_power_table(void)
{
    sqlite3 *db = NULL;
    char *sql = "CREATE TABLE IF NOT EXISTS power_data (date TEXT PRIMARY KEY, pcc_power REAL, pv_power REAL, load_power REAL);";
    char *sql_trigger = "CREATE TRIGGER delete_old_records AFTER INSERT ON power_data "
						"BEGIN "
							"DELETE FROM power_data WHERE date < DATE('now', '-365 days');"
                        "END;";
    char *err_msg = NULL;
    int rc = 0;

    rc = sqlite3_open(POWER_FLOW_DB, &db);
    if(rc) 
    {
        INFO_RECORD_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
        return;
    }
 
    rc = sqlite3_exec(db, sql, 0, 0, &err_msg);
    if (rc != SQLITE_OK) 
    {
        INFO_RECORD_DEBUG_PRINT((int8_t *)"Failed to create table: %s\n", err_msg);
    }

 	rc = sqlite3_exec(db, sql_trigger, 0, 0, &err_msg);
	if (rc != SQLITE_OK) {
		fprintf(stderr, "SQL error: %s\n", err_msg);
	} 
    else 
    {
		fprintf(stdout, "Trigger created successfully\n");
	}

    sqlite3_free(err_msg);
    sqlite3_close(db);
}


/**
 * @brief  检查功率曲线数据库文件是否存在和有效
 * @param  [in] *p_file：数据库文件
 * @param  [in] type：类型
 * @return 0-数据库文件正常   -1-数据库文件异常
 */
static int32_t power_db_file_check(char *p_file, uint8_t type)
{
	int32_t ret = -1;
	fs_t *p_fs = NULL;
	
    ret = sdk_fs_access((const int8_t *)p_file, F_OK);
    if (ret == -1) 
    {
        if(type == ENERGY_METER)
        {
            create_energy_meter_power_table();
        }
        else if(type == ENERGY_FLOW)
        {
            create_energy_flow_power_table();
        }
        return 0;
    }
	else
	{
		p_fs = sdk_fs_open((const int8_t *)p_file,FS_READ);
		if ( p_fs != NULL)
		{
			ret = sdk_fs_get_size(p_fs);
			sdk_fs_close(p_fs);
			if (ret == 0)
			{
				sdk_fs_remove((const int8_t *)p_file);
                if(type == ENERGY_METER)
                {
                    create_energy_meter_power_table();
                }
                else if(type == ENERGY_FLOW)
                {
                    create_energy_flow_power_table();
                }
			}
		}
		else 
		{
			return -1;
		}
	}
	return 0;
}

/**
 * @brief  更新数据库充放电量
 * @param  [in] date 日期(2023-07-11 10:00:00)
 * @param  [in] charge 充电量
 * @param  [in] discharge 放电量
 * @return 0失败 1成功
 */
static int32_t sqlite_db_update_energy_meter_power_data(uint8_t *date, int32_t power)
{
    sqlite3 *db = NULL;
    int32_t rc = 0;
    int32_t ret = 0;
    int32_t retry_count = 0;
    char db_name[512] = {0};
    sdk_rtc_t now;

    ret = sdk_rtc_get(RTC_BIN_FORMAT, &now);
    sprintf(db_name, "%s%s-%d%s",PATH_POWER_GENERAL_DIR, "power", now.tm_year, ".db");
    power_db_file_check(db_name, ENERGY_METER);

    INFO_RECORD_DEBUG_PRINT((int8_t *)"[update meter power date:%s power:%d]\n", date, power);
    
    rc = sqlite3_open(db_name, &db);
    if( rc ) 
    {
       INFO_RECORD_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
       return(0);
    } 
    else 
    {
        char *sql = "INSERT OR REPLACE INTO power_data (date, power) VALUES (?, ?);";
        sqlite3_stmt *stmt;
        sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
        sqlite3_bind_text(stmt, 1, (char *)date, -1, SQLITE_STATIC);
        sqlite3_bind_int(stmt, 2, power);
 
        while ((SQLITE_DONE != (ret = sqlite3_step(stmt))) && (retry_count < 5))
        {
            retry_count++;
            printf( "sqlite3_step err ret = %d \n",ret);
            usleep(1000);
        }
        
        sqlite3_finalize(stmt);
    }
    sqlite3_close(db);    

    return(1);
}


/**
 * @brief  更新数据库充放电量
 * @param  [in] date 日期(2023-07-11 10:00:00)
 * @param  [in] charge 充电量
 * @param  [in] discharge 放电量
 * @return 0失败 1成功
 */
static int32_t sqlite_db_update_energy_flow_power_data(uint8_t *p_date, power_record_task_t *p_power_data)
{
    sqlite3 *db = NULL;
    int32_t rc = 0;
    int32_t ret = 0;
    int32_t retry_count = 0;

    power_db_file_check(POWER_FLOW_DB, ENERGY_FLOW);

    INFO_RECORD_DEBUG_PRINT((int8_t *)"[update flow power date:%s pcc power:%d pv power:%d load power:%d]\n", p_date, \
                                                        p_power_data->pcc_power, p_power_data->pv_power, p_power_data->load_power);
    
    rc = sqlite3_open(POWER_FLOW_DB, &db);
    if( rc ) 
    {
       INFO_RECORD_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
       return(0);
    } 
    else 
    {
        char *sql = "INSERT OR REPLACE INTO power_data (date, pcc_power, pv_power, load_power) VALUES (?, ?, ?, ?);";
        sqlite3_stmt *stmt = NULL;
        sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
        sqlite3_bind_text(stmt, 1, (char *)p_date, -1, SQLITE_STATIC);
        sqlite3_bind_int(stmt, 2, p_power_data->pcc_power);
        sqlite3_bind_int(stmt, 3, p_power_data->pv_power);
        sqlite3_bind_int(stmt, 4, p_power_data->load_power);
 
        while ((SQLITE_DONE != (ret = sqlite3_step(stmt))) && (retry_count < 5))
        {
            retry_count++;
            printf( "sqlite3_step err ret = %d \n",ret);
            usleep(1000);
        }
        
        sqlite3_finalize(stmt);
    }
    sqlite3_close(db);    

    return(1);
}


/**
 * @brief  历史功率存储函数
 * @param  [in] p_task 功率存储任务结构体指针
 * @param  [in] time_type 存储的时间类型（1~4）
 * @param  [out] none
 * @return 存储结果 0：成功  -1：失败/异常
 */
int32_t history_power_record(power_record_task_t *p_task, uint8_t time_type)
{
    power_time_t *p_time = NULL;
    uint8_t date[32] = {0};

    p_time = &p_task->now_time;

    if (time_type == POWER_YEAR_CHANGE)
    {
        //根据年份创建新的计量表数据库文件
        power_record_init();
        return -1;
    }

    snprintf((char *)date, sizeof(date), "%04d-%02d-%02d %02d:%02d:00", p_time->year, p_time->month, p_time->day, \
                                                                        p_time->hour, p_time->minute);
    sqlite_db_update_energy_meter_power_data(date, g_power_record_task.energy_meter_power);
    usleep(1000);
    sqlite_db_update_energy_flow_power_data(date, &g_power_record_task);
    
    return 0;
}


/**
 * @brief  更新设备功率数据
 * @param  [in] none
 * @param  [out] none
 * @return 获取结果 0：成功  -1：失败
 */
static int32_t update_dev_power_data(void)
{
    uint8_t i = 0;
    power_record_task_t *p_task = NULL;
    internal_shared_data_t *p_internal_data = NULL;
    constant_parameter_data_t *p_constant_para = NULL;
    
    p_constant_para = sdk_shm_constant_parameter_data_get();
	p_internal_data = internal_shared_data_get();
    p_task = &g_power_record_task;

    //计量表
    p_task->energy_meter_power = p_internal_data->total_realtime_energy.meter_power;
    //PCC
    p_task->pcc_power = 0;
    if(p_constant_para->system_param.cabinet_param.rs485_device_enable.bit.backflow_meter)
    {
        p_task->pcc_power = p_internal_data->pcc_meter_data.active_power_total;
    }
    //PV
    p_task->pv_power = 0;
    if(p_constant_para->system_param.cabinet_param.rs485_device_enable.bit.photovoltaic_meter)
    {
        for(i = 0; i < PV_METER_MAX_NUM; i++)
        {
            p_task->pv_power += p_internal_data->photovoltaic_meter_data[i].active_power_total;
        }
    }
    //负载
    p_task->load_power = p_task->pv_power + p_task->energy_meter_power - p_task->pcc_power;
    p_task->load_power = (p_task->load_power > 0) ? p_task->load_power : 0;
    return 0;
}

/**
 * @brief  充放电功率记录管理任务
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void power_record_task(void)
{
    uint8_t change = 0;
    int32_t ret = 0;
    power_record_task_t *p_task = NULL;

    p_task = &g_power_record_task;

    // 更新功率数据
    update_dev_power_data();
    // 获取当前时间
    update_current_time(&p_task->now_time);
    // 获取变化类型
    change = get_time_change(p_task->now_time, p_task->last_time);
    if((p_task->now_time.minute % DISPLAY_ACCURACY == 0) && (p_task->now_time.minute != p_task->last_time.minute))
    {
        ret = history_power_record(p_task, change);
        if (ret == 0)
        {
            p_task->last_time = p_task->now_time;
        }
    }
    
    return;
}

/**
 * @brief  功率记录初始化
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void power_record_init(void)
{
    int32_t ret = 0;

    // 文件夹不存在，先创建文件夹
	if ((sdk_fs_access((int8_t *)PATH_POWER_GENERAL_DIR, FS_F_OK)) == -1)
	{
		ret = sdk_fs_mkdir(PATH_POWER_GENERAL_DIR, FS_S_IRWXU|FS_S_IRWXG|FS_S_IRWXO);
        if (ret == -1)
        {
            INFO_RECORD_DEBUG_PRINT((int8_t *)"\n[power_record_init] mkdir failed!\n");
            return;
        }
        else
        {
            INFO_RECORD_DEBUG_PRINT((int8_t *)"\n[power_record_init] '/user/data/power/' direct not exist but has created! \r\n");
        }	
	}

    //初始化数据库
    create_energy_meter_power_table();   
    //初始化能流功率数据库
    create_energy_flow_power_table();

    //初始化全局变量
    memset(&g_power_record_task, 0, sizeof(power_record_task_t));

    // 每次上电，记录当前时间为上一次对比时间
    INFO_RECORD_DEBUG_PRINT((int8_t *)"[power_record_init] ready to record last time\n");
    update_current_time(&g_power_record_task.last_time);
    INFO_RECORD_DEBUG_PRINT((int8_t *)"[power_record_init] last_time init %04d.%02d.%02d %02dh \n", g_power_record_task.last_time.year, \
								g_power_record_task.last_time.month, g_power_record_task.last_time.day, g_power_record_task.last_time.hour);

    return;
}


/**
 * @brief  功率记录线程（用于充放电功率存储）
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
void *thread_history_power(void *arg)
{
	power_record_init();
    INFO_RECORD_DEBUG_PRINT((int8_t *)"[power_record_init] init over!\n");

    while (1)
    {
        power_record_task();
        sleep(1); 
    }
    
    pthread_exit(NULL);
}

