#ifndef __POWER_RECORD_TASK_H__
#define __POWER_RECORD_TASK_H__

#include "data_types.h"

#define HISTORY_POWER_YEAR_START           (2023)

#define DISPLAY_ACCURACY             (5)

// 时间变化类型
#define POWER_YEAR_CHANGE				    5
#define POWER_MONTH_CHANGE					4
#define POWER_DAY_CHANGE					3
#define POWER_HOUR_CHANGE					2
#define POWER_SOME_MINS_CHANGE              1
#define POWER_NO_CHANGE						0

#pragma pack(push)
#pragma pack(1)
typedef struct
{
    int16_t year;	        // 年份，如2023
    int16_t month;	        // 月份，1~12
    int16_t day;	        // 日期，1~31
	int16_t hour;	        // 小时，0~23
    int16_t minute;
	int16_t second;
}power_time_t;
#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)
typedef struct
{
    power_time_t now_time;              // 当前时间
    power_time_t last_time;             // 上一次保存时间
    int32_t energy_meter_power;         // 计量表实时功率
    int32_t pcc_power;                  // PCC电表功率
    int32_t pv_power;                   // PV电表功率
    int32_t load_power;                 // 负载功率
}power_record_task_t;
#pragma pack(pop)

enum{
    ENERGY_METER = 0,
    ENERGY_FLOW
};

/**
 * @brief  功率记录线程（用于充放电功率存储）
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
void *thread_history_power(void *arg);

#endif
