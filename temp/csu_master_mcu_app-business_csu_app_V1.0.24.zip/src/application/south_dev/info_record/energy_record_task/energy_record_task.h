#ifndef __ENERGY_RECORD_TASK_H__
#define __ENERGY_RECORD_TASK_H__

#include "data_types.h"
#include "data_shm.h"


// 时间变化类型
#define YEAR_CHANGE                         4
#define MONTH_CHANGE                        3
#define DAY_CHANGE                          2
#define HOUR_CHANGE                         1
#define NO_CHANGE                           0

// 电量时间结构体
#pragma pack(push)
#pragma pack(1)
typedef struct
{
    int16_t year;	// 年份，如2023
    int16_t month;	// 月份，1~12
    int16_t day;	// 日期，1~31
	int16_t hour;	// 小时，0~23
    int16_t minute;
	int16_t second;
}energy_time_t;

typedef struct
{
	uint32_t meter_energy_charge;						// 计量表总充电量
	uint32_t meter_energy_discharge;					// 计量表总放电量
}energy_data_t;	

typedef struct{
    energy_time_t last_save_time;         	            // 上次记录时间
	energy_time_t now_time;                             // 当前时间
	energy_data_t meter_energy_last;                    // 计量表上次记录数据
	energy_data_t meter_energy_now;                     // 计量表当前数据
    energy_data_t pcc_energy_last;                      // PCC上次记录数据
	energy_data_t pcc_energy_now;                       // PCC当前数据
    energy_data_t pv_energy_last;                       // PV上次记录数据
	energy_data_t pv_energy_now;                        // PV当前数据
}energy_record_task_t;

#pragma pack(pop)


#define HISTORY_YEAR_START           (2024)      // 时间小于2023，不进行历史电量记录
#define PV_METER_MAX_NUM             3

/**
 * @brief  历史电量线程（用于历史电量数据存储）
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
void *thread_history_energy(void *arg);
#endif