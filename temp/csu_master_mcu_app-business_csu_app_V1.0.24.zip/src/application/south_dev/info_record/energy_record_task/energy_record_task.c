#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include "sdk_shm.h"
#include "sdk_fs.h"
#include "sdk_public.h"
#include "sqlite3.h"
#include "sofar_log.h"
#include "app_common.h"
#include "info_record.h"
#include "energy_record_task.h"
#include "energy_op.h"

//相关宏定义
#define PATH_ENERGY_GENERAL_DIR	 "/user/data/energy/"		// 电量存储总目录
#define ENERGY_DB "/user/data/energy/meter_energy.db"       // 数据库文件路径
#define PCC_ENERGY_DB "/user/data/energy/pcc_energy.db"     // 数据库文件路径
#define PV_ENERGY_DB "/user/data/energy/pv_energy.db"       // 数据库文件路径
#define LOAD_ENERGY_DB "/user/data/energy/load_energy.db"   // 数据库文件路径

static energy_record_task_t g_energy_record_task;           // 历史电量任务

static uint8_t meter_init_flag = 0;                         // bit0:计量表 bit1:PV bit2:PCC
static uint8_t meter_data_update_flag = 0;                  // bit0:计量表 bit1:PV bit2:PCC

static void energy_info_update( void );

/**
 * @brief  设置上次数据记录时间
 * @param  [in] now:当前时间
 * @return none
 */
static void set_last_savetime(sdk_rtc_t *now) 
{
	energy_time_t *p_time = NULL;
	
	p_time = &g_energy_record_task.last_save_time;
	
	if(NULL == p_time)
	{
		return;
	}
	
	p_time->year = now->tm_year + 2000;
	p_time->month = now->tm_mon;
	p_time->day = now->tm_day;
	p_time->hour = now->tm_hour;
	p_time->minute = now->tm_min;
	p_time->second = now->tm_sec;
}


/**
 * @brief  系统rtc时间获取
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void get_energy_time(void)
{
    sdk_rtc_t now;
    energy_time_t *p_time = NULL;
 
    p_time = &g_energy_record_task.now_time;
    sdk_rtc_get(RTC_BIN_FORMAT, &now);
    if(NULL == p_time)
    {
        return;
    }
 
    p_time->year = now.tm_year + 2000;
    p_time->month = now.tm_mon;
    p_time->day = now.tm_day;
    p_time->hour = now.tm_hour;
    p_time->minute = now.tm_min;
    p_time->second = now.tm_sec;

}

/**
 * @brief  时间变化判断函数
 * @param  [in] updatetime 更新时的时间
 * @param  [in] lastsavetime 上一次保存的时间
 * @param  [out] none
 * @return 时间变化类型
 */
static uint8_t get_energy_timechange(energy_time_t updatetime, energy_time_t lastsavetime)
{
    if(updatetime.year < HISTORY_YEAR_START)    //年限不合理，不进行历史电量记录
    {
        return 0;
    }
 
    if (lastsavetime.year != updatetime.year)
    {
        return YEAR_CHANGE;
    }
    if (lastsavetime.month != updatetime.month)
    {
        return MONTH_CHANGE;
    }
    if (lastsavetime.day != updatetime.day)
    {
        return DAY_CHANGE;
    }
    if (lastsavetime.hour != updatetime.hour)
    {
        return HOUR_CHANGE;
    }
    return 0;
}


/**
 * @brief  更新上一次生产时间
 * @param  [in] updatetime 
 * @param  [out] lastproductiontime
 * @return none
 */
static void energy_update_lastsavetime(energy_time_t *p_last_time, energy_time_t update_time)
{
    if (NULL == p_last_time)
    {
        return;
    }
 
    memcpy(p_last_time, &update_time, sizeof(energy_time_t));
 
    return;
}


/**
 * @brief  创建数据库
 * @param  [in] 
 * @param  [in]
 * @param  [out]
 * @return 
 *
 */
static void create_energy_table(void)
{
    sqlite3 *db;
    char *sql = "CREATE TABLE IF NOT EXISTS charge_data (date TEXT PRIMARY KEY, charge REAL, discharge REAL);";
    char *err_msg = 0;
    int rc = 0;
    
    rc = sqlite3_open(ENERGY_DB, &db);
    if( rc ) 
    {
        INFO_RECORD_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
        return;
    }
 
    rc = sqlite3_exec(db, sql, 0, 0, &err_msg);
    if (rc != SQLITE_OK) 
    {
        INFO_RECORD_DEBUG_PRINT((int8_t *)"Failed to create table: %s\n", err_msg);
        sqlite3_free(err_msg);
    }
    sqlite3_close(db);
}


/**
 * @brief  创建PCC数据库
 * @param  [in] 
 * @param  [in]
 * @param  [out]
 * @return 
 *
 */
static void create_pcc_energy_table(void)
{
    sqlite3 *db = NULL;
    char *sql = "CREATE TABLE IF NOT EXISTS pcc_energy (date TEXT PRIMARY KEY, int REAL, out REAL);";
    char *err_msg = NULL;
    int rc = 0;
    
    rc = sqlite3_open(PCC_ENERGY_DB, &db);
    if( rc ) 
    {
        INFO_RECORD_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
        sqlite3_free(err_msg);
        return;
    }
 
    rc = sqlite3_exec(db, sql, 0, 0, &err_msg);
    if (rc != SQLITE_OK) 
    {
        INFO_RECORD_DEBUG_PRINT((int8_t *)"Failed to create table: %s\n", err_msg);
        sqlite3_free(err_msg);
    }
    sqlite3_free(err_msg);
    sqlite3_close(db);
}


/**
 * @brief  创建PV数据库
 * @param  [in] 
 * @param  [in]
 * @param  [out]
 * @return 
 *
 */
static void create_pv_energy_table(void)
{
    sqlite3 *db = NULL;
    char *sql = "CREATE TABLE IF NOT EXISTS pv_energy (date TEXT PRIMARY KEY, int REAL);";
    char *err_msg = NULL;
    int rc = 0;
    
    rc = sqlite3_open(PV_ENERGY_DB, &db);
    if( rc ) 
    {
        INFO_RECORD_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
        sqlite3_free(err_msg);
        return;
    }
 
    rc = sqlite3_exec(db, sql, 0, 0, &err_msg);
    if (rc != SQLITE_OK) 
    {
        INFO_RECORD_DEBUG_PRINT((int8_t *)"Failed to create table: %s\n", err_msg);
        sqlite3_free(err_msg);
    }
    sqlite3_free(err_msg);
    sqlite3_close(db);
}

/**
 * @brief  创建PV数据库
 * @param  [in] 
 * @param  [in]
 * @param  [out]
 * @return 
 *
 */
static void create_load_energy_table(void)
{
    sqlite3 *db = NULL;
    char *sql = "CREATE TABLE IF NOT EXISTS load_energy (date TEXT PRIMARY KEY, out REAL);";
    char *err_msg = NULL;
    int rc = 0;
    
    rc = sqlite3_open(LOAD_ENERGY_DB, &db);
    if( rc ) 
    {
        INFO_RECORD_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
        sqlite3_free(err_msg);
        return;
    }
 
    rc = sqlite3_exec(db, sql, 0, 0, &err_msg);
    if (rc != SQLITE_OK) 
    {
        INFO_RECORD_DEBUG_PRINT((int8_t *)"Failed to create table: %s\n", err_msg);
        sqlite3_free(err_msg);
    }
    sqlite3_free(err_msg);
    sqlite3_close(db);
}


/**
 * @brief  检查充放电量数据库文件是否存在和有效
 * @param  [in] meter_type：电表类型
 * @param  [in] p_path：数据库路径
 * @return 0-数据库文件正常   -1-数据库文件异常
 */
static int32_t energy_db_file_check(uint8_t meter_type, char *p_path)
{
	int32_t ret = -1;
	fs_t *p_fs = NULL;
	
    ret = sdk_fs_access((const int8_t *)p_path, F_OK);
    if (ret == -1)
    {
        if(meter_type == METER)
        {
            create_energy_table();
        }
		else if(meter_type == PCC_METER)
        {
            create_pcc_energy_table();
        }
        else if(meter_type == PV_METER)
        {
            create_pv_energy_table();
        }
        else if(meter_type == LOAD)
        {
            create_load_energy_table();
        }
		return (0);
    }
	else
	{
		p_fs = sdk_fs_open((const int8_t *)p_path, FS_READ);
		if ( p_fs != NULL)
		{
			ret = sdk_fs_get_size(p_fs);
			sdk_fs_close(p_fs);
			if (ret == 0)
			{
				sdk_fs_remove((const int8_t *)p_path);
                if(meter_type == METER)
                {
                    create_energy_table();
                }
                else if(meter_type == PCC_METER)
                {
                    create_pcc_energy_table();
                }
                else if(meter_type == PV_METER)
                {
                    create_pv_energy_table();
                }
                else if(meter_type == LOAD)
                {
                    create_load_energy_table();
                }
			}
		}
		else 
		{
			return (-1);
		}
	}
	return (0);
}


/**
 * @brief  获取当前小时的数据库数据，如果有则作为基质，否则读取电池实时数据作为基值
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
int32_t select_charge_discharge(uint8_t *date, uint32_t *charge, uint32_t *discharge, uint8_t meter_type, char *p_path)
{
	sqlite3 *db = NULL;
	sqlite3_stmt *stmt = NULL;
	int32_t rc = 0;
	char sql[256] = {0};

	rc = sqlite3_open(p_path, &db);
	if( rc ) 
    {
	   INFO_RECORD_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
	   return(0);
	} 
    else 
    {
        if(meter_type == METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%Y', date), charge, discharge FROM charge_data  WHERE date = '%s';",date);
            INFO_RECORD_DEBUG_PRINT((int8_t *)"sql:%s\n",sql);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);

            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                *charge = sqlite3_column_int(stmt, 1);
                *discharge = sqlite3_column_int(stmt, 2);
            }
            INFO_RECORD_DEBUG_PRINT((int8_t *)"current hour data from db: charge = %d discharge = %d\n", *charge, *discharge);
        }
        else if(meter_type == PCC_METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%Y', date), int, out FROM pcc_energy  WHERE date = '%s';",date);
            INFO_RECORD_DEBUG_PRINT((int8_t *)"sql:%s\n",sql);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);

            while (sqlite3_step(stmt) == SQLITE_ROW)
            {
                *discharge = sqlite3_column_int(stmt, 1);
                *charge = sqlite3_column_int(stmt, 2);
            }
            INFO_RECORD_DEBUG_PRINT((int8_t *)"current hour data from db: pcc in = %d pcc out = %d\n", *discharge, *charge);
        }
        else if(meter_type == PV_METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%Y', date), int FROM pv_energy  WHERE date = '%s';",date);
            INFO_RECORD_DEBUG_PRINT((int8_t *)"sql:%s\n",sql);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);

            while (sqlite3_step(stmt) == SQLITE_ROW)
            {
                *charge = sqlite3_column_int(stmt, 1);
            }
            INFO_RECORD_DEBUG_PRINT((int8_t *)"current hour data from db: pv in = %d\n", *charge);
        }
        else if(meter_type == LOAD)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%Y', date), out FROM load_energy  WHERE date = '%s';",date);
            INFO_RECORD_DEBUG_PRINT((int8_t *)"sql:%s\n",sql);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);

            while (sqlite3_step(stmt) == SQLITE_ROW)
            {
                *discharge = sqlite3_column_int(stmt, 1);
            }
            INFO_RECORD_DEBUG_PRINT((int8_t *)"current hour data from db: load out = %d\n", *charge);
        }
	}
	
    sqlite3_finalize(stmt);
	sqlite3_close(db);	

    return 1;
}


/**
 * @brief  计算负载电能
 * @param  [in] *p_date：日期
 * @return 负载电能
 */
static int32_t calculate_load_energy(uint8_t *p_date)
{
    uint32_t charge = 0;
    uint32_t discharge = 0;
    uint32_t pcc_in = 0;
    uint32_t pcc_out = 0;
    uint32_t pv_in = 0;
    uint32_t pv_out = 0;
    int32_t load_out = 0;

	select_charge_discharge(p_date, &charge, &discharge, METER, ENERGY_DB);
    usleep(1000);
    select_charge_discharge(p_date, &pcc_out, &pcc_in, PCC_METER, PCC_ENERGY_DB);
    usleep(1000);
    select_charge_discharge(p_date, &pv_in, &pv_out, PV_METER, PV_ENERGY_DB);

    //负载电能 = 计量表(discharge) - 计量表(charge) + PV(in) + PCC(in) - PCC(out)
    load_out = discharge + pv_in + pcc_in - charge - pcc_out;
	load_out = (load_out > 0) ? load_out : 0;
    return load_out;
}


/**
 * @brief  更新数据库充放电量
 * @param  [in] date 日期(2023-07-11 10:00:00)
 * @param  [in] charge 充电量
 * @param  [in] discharge 放电量
 * @param  [in] meter_type 电表类型
 * @param  [in] discharge p_path 数据库路径
 * @return 0失败 1成功
 */
static int32_t sqlite_db_update_data(uint8_t *date, uint32_t charge, uint32_t discharge, uint8_t meter_type, char *p_path)
{
    sqlite3 *db = NULL;
    int32_t rc = 0;
    int32_t ret = 0;
    int32_t retry_count = 0;
 
    // INFO_RECORD_DEBUG_PRINT((int8_t *)"[%s %d date %s %d %d]\n", __func__, __LINE__, date, charge, discharge);
    
    energy_db_file_check(meter_type, p_path);
    rc = sqlite3_open(p_path, &db);
    if( rc ) 
    {
       INFO_RECORD_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
       return(0);
    } 
    else 
    {
        if(meter_type == METER)
        {
            char *sql = "INSERT OR REPLACE INTO charge_data (date, charge, discharge) VALUES (?, ?, ?);";
            sqlite3_stmt *stmt;
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            sqlite3_bind_text(stmt, 1, (char *)date, -1, SQLITE_STATIC);
            sqlite3_bind_int(stmt, 2, charge);
            sqlite3_bind_int(stmt, 3, discharge);

            while ((SQLITE_DONE != (ret = sqlite3_step(stmt))) && (retry_count < 5))
            {
                retry_count++;
                INFO_RECORD_DEBUG_PRINT((int8_t *)"sqlite3_step err ret = %d \n",ret);
                usleep(1000);
            }
            INFO_RECORD_DEBUG_PRINT((int8_t *)"[date %s meter charge = %d meter discharge = %d]\n", date, charge, discharge);
            sqlite3_finalize(stmt);
        }
        else if(meter_type == PCC_METER)
        {
            char *sql = "INSERT OR REPLACE INTO pcc_energy (date, int, out) VALUES (?, ?, ?);";
            sqlite3_stmt *stmt;
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            sqlite3_bind_text(stmt, 1, (char *)date, -1, SQLITE_STATIC);
            sqlite3_bind_int(stmt, 2, charge);
            sqlite3_bind_int(stmt, 3, discharge);

            while ((SQLITE_DONE != (ret = sqlite3_step(stmt))) && (retry_count < 5))
            {
                retry_count++;
                INFO_RECORD_DEBUG_PRINT((int8_t *)"sqlite3_step err ret = %d \n",ret);
                usleep(1000);
            }
            INFO_RECORD_DEBUG_PRINT((int8_t *)"[date %s pcc in = %d pcc out = %d]\n", date, charge, discharge);
            sqlite3_finalize(stmt);
        }
        else if(meter_type == PV_METER)
        {
            char *sql = "INSERT OR REPLACE INTO pv_energy (date, int) VALUES (?, ?);";
            sqlite3_stmt *stmt;
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            sqlite3_bind_text(stmt, 1, (char *)date, -1, SQLITE_STATIC);
            sqlite3_bind_int(stmt, 2, charge);

            while ((SQLITE_DONE != (ret = sqlite3_step(stmt))) && (retry_count < 5))
            {
                retry_count++;
                INFO_RECORD_DEBUG_PRINT((int8_t *)"sqlite3_step err ret = %d \n",ret);
                usleep(1000);
            }
            INFO_RECORD_DEBUG_PRINT((int8_t *)"[date %s pv in = %d]\n", date, charge);
            sqlite3_finalize(stmt);
        }
        else if(meter_type == LOAD)
        {
            char *sql = "INSERT OR REPLACE INTO load_energy (date, out) VALUES (?, ?);";
            sqlite3_stmt *stmt;
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            sqlite3_bind_text(stmt, 1, (char *)date, -1, SQLITE_STATIC);
            sqlite3_bind_int(stmt, 2, discharge);

            while ((SQLITE_DONE != (ret = sqlite3_step(stmt))) && (retry_count < 5))
            {
                retry_count++;
                INFO_RECORD_DEBUG_PRINT((int8_t *)"sqlite3_step err ret = %d \n",ret);
                usleep(1000);
            }
            INFO_RECORD_DEBUG_PRINT((int8_t *)"[date %s load out = %d]\n", date, discharge);
            sqlite3_finalize(stmt);
        }
    }
    sqlite3_file_control(db, p_path, SQLITE_FCNTL_SYNC, NULL);
    sqlite3_close(db);    

    return(1);
}


/**
 * @brief  计算计量表充放电数据
 * @param  [out] p_charge：充电
 * @param  [out] p_discharge：放电
 * @return none
 */
static void calculate_meter_total_charge_discharge(uint32_t *p_charge, uint32_t *p_discharge)
{
	internal_shared_data_t *p_internal_data;

	p_internal_data = internal_shared_data_get();

    *p_charge = p_internal_data->total_realtime_energy.meter_energy_charge;
    *p_discharge = p_internal_data->total_realtime_energy.meter_energy_discharge;
}

/**
 * @brief  计算PCC表充放电数据
 * @param  [out] p_charge：充电
 * @param  [out] p_discharge：放电
 * @return none
 */
static void calculate_pcc_meter_total_charge_discharge(uint32_t *p_charge, uint32_t *p_discharge)
{
	internal_shared_data_t *p_internal_data = NULL;

	p_internal_data = internal_shared_data_get();

    *p_charge = p_internal_data->pcc_meter_data.positive_active_energy_total;
    *p_discharge = p_internal_data->pcc_meter_data.negative_active_energy_total;

    // INFO_RECORD_DEBUG_PRINT((int8_t *)"in = %d    out = %d\n", *p_discharge, *p_charge);

}


/**
 * @brief  计算PV表充放电数据
 * @param  [out] p_charge：充电
 * @param  [out] p_discharge：放电
 * @return none
 */
static void calculate_pv_meter_total_charge_discharge(uint32_t *p_charge, uint32_t *p_discharge)
{
    uint8_t i = 0;
    uint32_t pv_in = 0;
	internal_shared_data_t *p_internal_data = NULL;

	p_internal_data = internal_shared_data_get();
    for(i = 0; i < PV_METER_MAX_NUM; i++)
    {
        pv_in += p_internal_data->photovoltaic_meter_data[i].positive_active_energy_total;
    }

    *p_charge = pv_in;

    // INFO_RECORD_DEBUG_PRINT((int8_t *)"in = %d \n", *p_charge);

}


/**
 * @brief  计量表统计数据基数初始化
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void meter_energy_base_data_init(void)
{
    sdk_rtc_t now;
    uint8_t date[32]= {0};
    uint32_t last_record_charge = 0;
    uint32_t last_record_discharge = 0;

    sdk_rtc_get(RTC_BIN_FORMAT, &now);

	if (now.tm_hour)
	{
		snprintf((char *)date, sizeof(date), "%04d-%02d-%02d %02d:00:00", now.tm_year + 2000, now.tm_mon, now.tm_day, now.tm_hour);
		select_charge_discharge(date, &last_record_charge, &last_record_discharge, METER, ENERGY_DB);
	}

	calculate_meter_total_charge_discharge(&g_energy_record_task.meter_energy_last.meter_energy_charge, \
		 &g_energy_record_task.meter_energy_last.meter_energy_discharge);

    if(g_energy_record_task.meter_energy_last.meter_energy_charge >= last_record_charge)
    {
        g_energy_record_task.meter_energy_last.meter_energy_charge -= last_record_charge;
    }
    if(g_energy_record_task.meter_energy_last.meter_energy_discharge >= last_record_discharge)
    {
        g_energy_record_task.meter_energy_last.meter_energy_discharge -= last_record_discharge;
    }
}


/**
 * @brief  PCC表统计数据基数初始化
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void pcc_energy_base_data_init(void)
{
    sdk_rtc_t now;
    uint8_t date[32]= {0};
    uint32_t last_record_charge = 0;
    uint32_t last_record_discharge = 0;

    sdk_rtc_get(RTC_BIN_FORMAT, &now);

	if (now.tm_hour)
	{
		snprintf((char *)date, sizeof(date), "%04d-%02d-%02d %02d:00:00", now.tm_year + 2000, now.tm_mon, now.tm_day, now.tm_hour);
		select_charge_discharge(date, &last_record_charge, &last_record_discharge, PCC_METER, PCC_ENERGY_DB);
	}

	calculate_pcc_meter_total_charge_discharge(&g_energy_record_task.pcc_energy_last.meter_energy_charge, \
		 &g_energy_record_task.pcc_energy_last.meter_energy_discharge);

    if(g_energy_record_task.pcc_energy_last.meter_energy_charge >= last_record_charge)
    {
        g_energy_record_task.pcc_energy_last.meter_energy_charge -= last_record_charge;
    }
    if(g_energy_record_task.pcc_energy_last.meter_energy_discharge >= last_record_discharge)
    {
        g_energy_record_task.pcc_energy_last.meter_energy_discharge -= last_record_discharge;
    }
}


/**
 * @brief  PV表统计数据基数初始化
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void pv_energy_base_data_init(void)
{
    sdk_rtc_t now;
    uint8_t date[32]= {0};
    uint32_t last_record_charge = 0;
    uint32_t last_record_discharge = 0;

    sdk_rtc_get(RTC_BIN_FORMAT, &now);

	if (now.tm_hour)
	{
		snprintf((char *)date, sizeof(date), "%04d-%02d-%02d %02d:00:00", now.tm_year + 2000, now.tm_mon, now.tm_day, now.tm_hour);
		select_charge_discharge(date, &last_record_charge, &last_record_discharge, PV_METER, PV_ENERGY_DB);
	}

	calculate_pv_meter_total_charge_discharge(&g_energy_record_task.pv_energy_last.meter_energy_charge, \
		 &g_energy_record_task.pv_energy_last.meter_energy_discharge);

    if(g_energy_record_task.pv_energy_last.meter_energy_charge >= last_record_charge)
    {
        g_energy_record_task.pv_energy_last.meter_energy_charge -= last_record_charge;
    }
    if(g_energy_record_task.pv_energy_last.meter_energy_discharge >= last_record_discharge)
    {
        g_energy_record_task.pv_energy_last.meter_energy_discharge -= last_record_discharge;
    }
}


/**
 * @brief  更新计量表通信标志
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void update_meter_comm_init_flag(void)
{
    internal_shared_data_t *p_internal_data = NULL;

	p_internal_data = internal_shared_data_get();
    if((p_internal_data->total_realtime_energy.meter_energy_charge == 0) && (p_internal_data->total_realtime_energy.meter_energy_discharge == 0))
    {
        BIT_CLR(meter_init_flag, 0);
    }
    else
    {
        //通信OK，更新标志以及基数值
        BIT_SET(meter_init_flag, 0);
        meter_energy_base_data_init();
    }
}


/**
 * @brief  更新PCC表通信标志
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void update_pcc_meter_comm_init_flag(void)
{
    internal_shared_data_t *p_internal_data = NULL;

	p_internal_data = internal_shared_data_get();
    if((p_internal_data->pcc_meter_data.positive_active_energy_total == 0) && (p_internal_data->pcc_meter_data.negative_active_energy_total == 0))
    {
        BIT_CLR(meter_init_flag, 1);
    }
    else
    {
        //通信OK，更新标志以及基数值
        BIT_SET(meter_init_flag, 1);
        pcc_energy_base_data_init();
    }
}


/**
 * @brief  更新PV表通信标志
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void update_pv_meter_comm_init_flag(void)
{
    uint8_t i = 0;
    uint32_t pv_in = 0;
    uint32_t pv_out = 0;
    internal_shared_data_t *p_internal_data = NULL;

	p_internal_data = internal_shared_data_get();

    for(i = 0; i < PV_METER_MAX_NUM; i++)
    {
        pv_in += p_internal_data->photovoltaic_meter_data[i].positive_active_energy_total;
        pv_out += p_internal_data->photovoltaic_meter_data[i].negative_active_energy_total;
    }
    if((pv_in == 0) && (pv_out == 0))
    {
        BIT_CLR(meter_init_flag, 2);
    }
    else
    {
        //通信OK，更新标志以及基数值
        BIT_SET(meter_init_flag, 2);
        pv_energy_base_data_init();
    }
}

/**
 * @brief  电量统计线程
 * @param  [in] 
 * @param  [out] 
 * @return 
 */
static void energy_record_task(void)
{
    uint8_t change = 0;
    uint32_t charge = 0;
    uint32_t discharge = 0;
    uint32_t pcc_in = 0;
    uint32_t pcc_out = 0;
    uint32_t pv_in = 0;
    int32_t load_out = 0;
    uint8_t date[32] = {0};
    energy_record_task_t *p_task = NULL;
    energy_time_t *p_time = NULL;
    
    p_task = &g_energy_record_task;
 
    // 1、检查刷新电表通信标志
    //计量表
    if(!BIT_GET(meter_init_flag, 0))
    {
        update_meter_comm_init_flag();
    }
    if(BIT_GET(meter_init_flag, 0))
    {
        calculate_meter_total_charge_discharge(&p_task->meter_energy_now.meter_energy_charge, &p_task->meter_energy_now.meter_energy_discharge);

        if((p_task->meter_energy_now.meter_energy_charge < p_task->meter_energy_last.meter_energy_charge) ||
                (p_task->meter_energy_now.meter_energy_discharge < p_task->meter_energy_last.meter_energy_discharge))
        {
            INFO_RECORD_DEBUG_PRINT((int8_t *)"bug:p_task->meter_energy_now.meter_energy_charge=%d, p_task->meter_energy_last.meter_energy_charge=%d, \
                p_task->meter_energy_now.meter_energy_discharge=%d, p_task->meter_energy_last.meter_energy_discharge=%d\n",  \
                p_task->meter_energy_now.meter_energy_charge, p_task->meter_energy_last.meter_energy_charge, 
                p_task->meter_energy_now.meter_energy_discharge, p_task->meter_energy_last.meter_energy_discharge);
                BIT_CLR(meter_data_update_flag, 0);
        }
        else
        {
            BIT_SET(meter_data_update_flag, 0);
        }

        if(BIT_GET(meter_data_update_flag, 0))
        {
            //获取这段时间的充放电量(当前总的减去之前记录的总计)
            charge = p_task->meter_energy_now.meter_energy_charge - p_task->meter_energy_last.meter_energy_charge;
            discharge = p_task->meter_energy_now.meter_energy_discharge - p_task->meter_energy_last.meter_energy_discharge;
            BIT_CLR(meter_data_update_flag, 0);
        }
    }

    //PCC表
    if(!BIT_GET(meter_init_flag, 1))
    {
        update_pcc_meter_comm_init_flag();
    }
    if(BIT_GET(meter_init_flag, 1))
    {
        calculate_pcc_meter_total_charge_discharge(&p_task->pcc_energy_now.meter_energy_charge, &p_task->pcc_energy_now.meter_energy_discharge);

        if((p_task->pcc_energy_now.meter_energy_charge < p_task->pcc_energy_last.meter_energy_charge) ||
                (p_task->pcc_energy_now.meter_energy_discharge < p_task->pcc_energy_last.meter_energy_discharge))
        {
            INFO_RECORD_DEBUG_PRINT((int8_t *)"bug:p_task->pcc_energy_now.meter_energy_charge=%d, p_task->pcc_energy_last.meter_energy_charge=%d, \
                p_task->pcc_energy_now.meter_energy_discharge=%d, p_task->pcc_energy_last.meter_energy_discharge=%d\n",  \
                p_task->pcc_energy_now.meter_energy_charge, p_task->pcc_energy_last.meter_energy_charge, 
                p_task->pcc_energy_now.meter_energy_discharge, p_task->pcc_energy_last.meter_energy_discharge);
            BIT_CLR(meter_data_update_flag, 1);
        }
        else
        {
            BIT_SET(meter_data_update_flag, 1);
        }

        if(BIT_GET(meter_data_update_flag, 1))
        {
            //获取这段时间的充放电量(当前总的减去之前记录的总计)
            pcc_out = p_task->pcc_energy_now.meter_energy_charge - p_task->pcc_energy_last.meter_energy_charge;
            pcc_in = p_task->pcc_energy_now.meter_energy_discharge - p_task->pcc_energy_last.meter_energy_discharge;
            BIT_CLR(meter_data_update_flag, 1);
        }
    }

    //PV表
    if(!BIT_GET(meter_init_flag, 2))
    {
        update_pv_meter_comm_init_flag();
    }
    if(BIT_GET(meter_init_flag, 2))
    {
        calculate_pv_meter_total_charge_discharge(&p_task->pv_energy_now.meter_energy_charge, &p_task->pv_energy_now.meter_energy_discharge);

        if((p_task->pv_energy_now.meter_energy_charge < p_task->pv_energy_last.meter_energy_charge) ||
                (p_task->pv_energy_now.meter_energy_discharge < p_task->pv_energy_last.meter_energy_discharge))
        {
            INFO_RECORD_DEBUG_PRINT((int8_t *)"bug:p_task->pv_energy_now.meter_energy_charge=%d, p_task->pcc_energpv_energy_lasty_last.meter_energy_charge=%d, \
                p_task->pv_energy_now.meter_energy_discharge=%d, p_task->pv_energy_last.meter_energy_discharge=%d\n",  \
                p_task->pv_energy_now.meter_energy_charge, p_task->pv_energy_last.meter_energy_charge, 
                p_task->pv_energy_now.meter_energy_discharge, p_task->pv_energy_last.meter_energy_discharge);
            BIT_CLR(meter_data_update_flag, 2);
        }
        else
        {
            BIT_SET(meter_data_update_flag, 2);
        }

        if(BIT_GET(meter_data_update_flag, 2))
        {
            //获取这段时间的充放电量(当前总的减去之前记录的总计)
            pv_in = p_task->pv_energy_now.meter_energy_charge - p_task->pv_energy_last.meter_energy_charge;
            BIT_CLR(meter_data_update_flag, 2);
        }
    }

    // 2、获取当前时间
    get_energy_time();
 
    change = get_energy_timechange(p_task->now_time, p_task->last_save_time);
 
    if(NO_CHANGE == change)
    {
        //五分钟更新一次当前小时电量记录
        if ((p_task->now_time.minute - p_task->last_save_time.minute) > 4)
        {	
            p_time = &g_energy_record_task.now_time;
 
            snprintf((char *)date, sizeof(date),"%04d-%02d-%02d %02d:00:00",p_time->year,\
                        p_time->month, p_time->day, p_time->hour);
         
			sqlite_db_update_data(date, charge, discharge, METER, ENERGY_DB);
            usleep(1000);
            sqlite_db_update_data(date, pcc_in, pcc_out, PCC_METER, PCC_ENERGY_DB);
            usleep(1000);
            sqlite_db_update_data(date, pv_in, 0, PV_METER, PV_ENERGY_DB);
            usleep(1000);
            load_out = calculate_load_energy(date);
            sqlite_db_update_data(date, 0, load_out, LOAD, LOAD_ENERGY_DB);
            p_task->last_save_time.minute = p_task->now_time.minute;

            energy_info_update();
        }
    } 
    
    //3、更新数据到数据库
    if(change)
    {
        p_time = &g_energy_record_task.now_time;
 
        if (HOUR_CHANGE == change)
        { 
            //避免外部同步系统时间时出现00:00:00导致出现时间存储异常
            //如果出现则把当前的能量数据保存至本地零点
            if(!p_time->hour)
            {
                snprintf((char *)date, sizeof(date),"%04d-%02d-%02d %02d:00:00",p_time->year,\
                    p_time->month, p_time->day, p_time->hour);   
            }
            else
            {
                snprintf((char *)date, sizeof(date),"%04d-%02d-%02d %02d:00:00",p_time->year,\
                    p_time->month, p_time->day, p_time->hour - 1);   
            }
  
			//时切换 将当前电量写入前一小时
			sqlite_db_update_data(date, charge, discharge, METER, ENERGY_DB);
            usleep(1000);
            sqlite_db_update_data(date, pcc_in, pcc_out, PCC_METER, PCC_ENERGY_DB);
            usleep(1000);
            sqlite_db_update_data(date, pv_in, 0, PV_METER, PV_ENERGY_DB);
            usleep(1000);
            load_out = calculate_load_energy(date);
            sqlite_db_update_data(date, 0, load_out, LOAD, LOAD_ENERGY_DB);
			//更新到上一小时当天累计电量
			p_task->meter_energy_last.meter_energy_charge = p_task->meter_energy_now.meter_energy_charge;
			p_task->meter_energy_last.meter_energy_discharge = p_task->meter_energy_now.meter_energy_discharge;

            p_task->pcc_energy_last.meter_energy_charge = p_task->pcc_energy_now.meter_energy_charge;
			p_task->pcc_energy_last.meter_energy_discharge = p_task->pcc_energy_now.meter_energy_discharge;

            p_task->pv_energy_last.meter_energy_charge = p_task->pv_energy_now.meter_energy_charge;
			p_task->pv_energy_last.meter_energy_discharge = p_task->pv_energy_now.meter_energy_discharge;
    
            energy_info_update();
        }
        else
        {
            //日、月、年切换 将当前记录写入前一小时记录
            //第二天时MCU传过来的当天充放电会清零，使用最近一次保存的电量记录到前面一小时
			// get_last_hour(date);
            snprintf((char *)date, sizeof(date),"%04d-%02d-%02d 23:00:00",p_task->last_save_time.year,
                                                                          p_task->last_save_time.month,
                                                                          p_task->last_save_time.day);
			sqlite_db_update_data(date, charge, discharge, METER, ENERGY_DB);
            usleep(1000);
            sqlite_db_update_data(date, pcc_in, pcc_out, PCC_METER, PCC_ENERGY_DB);
            usleep(1000);
            sqlite_db_update_data(date, pv_in, 0, PV_METER, PV_ENERGY_DB);
            usleep(1000);
            load_out = calculate_load_energy(date);
            sqlite_db_update_data(date, 0, load_out, LOAD, LOAD_ENERGY_DB);
			p_task->meter_energy_last.meter_energy_charge = p_task->meter_energy_now.meter_energy_charge;
			p_task->meter_energy_last.meter_energy_discharge = p_task->meter_energy_now.meter_energy_discharge;

            p_task->pcc_energy_last.meter_energy_charge = p_task->pcc_energy_now.meter_energy_charge;
			p_task->pcc_energy_last.meter_energy_discharge = p_task->pcc_energy_now.meter_energy_discharge;

            p_task->pv_energy_last.meter_energy_charge = p_task->pv_energy_now.meter_energy_charge;
			p_task->pv_energy_last.meter_energy_discharge = p_task->pv_energy_now.meter_energy_discharge;

            energy_info_update();
        }
        //更新数据
        energy_update_lastsavetime(&p_task->last_save_time, p_task->now_time);    // 更新时间指针
        //time
    }    
}

/**
 * @brief  发电量记录管理任务初始化
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void energy_record_init(void)
{
    sdk_rtc_t now;

    sdk_rtc_get(RTC_BIN_FORMAT, &now);
    // 文件夹不存在，先创建文件夹
    if ((sdk_fs_access((int8_t *)PATH_ENERGY_GENERAL_DIR, FS_F_OK)) == -1)
    {
        sdk_fs_mkdir(PATH_ENERGY_GENERAL_DIR, FS_S_IRWXU|FS_S_IRWXG|FS_S_IRWXO);
        INFO_RECORD_DEBUG_PRINT((int8_t *)"\n[energy_record_init] '/user/data/energy/' direct not exist but has created! \r\n");
    }
 
    //初始化计量表数据库
    create_energy_table();
    //初始PCC表数据库
    create_pcc_energy_table();
    //初始PV表数据库
    create_pv_energy_table();
    //初始负载数据库
    create_load_energy_table();
 
    //初始化全局变量
    memset(&g_energy_record_task, 0, sizeof(energy_record_task_t));
    
    //记录时间作为基准时间
    set_last_savetime(&now);
}
 
/*
 * @brief  历史电量线程（用于历史电量数据存储）
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
void *thread_history_energy(void *arg)
{
    // uint16_t cnt;

	energy_record_init();
    sleep(60);                              // 延时60s再去开始记录数据，避免电表数据没有更新完整
    energy_info_update();
    while (1)
    {
		energy_record_task();	

        // if ( (cnt++) >= 20 )    
        // {
        //     energy_info_update();
        //     cnt = 0;
        // }

		sleep(1);
    }
    
    pthread_exit(NULL);
}

/**
 * @brief  计算当日电能数据
 * @param  [in] p_energy_list ： 当天小时电能列表
 * @return 总电能，电能单位：0.1kwh
 * @note   
 */
uint32_t energy_data_cal_daliy_energy( double *p_energy_list )
{
    double energy = 0;

    for ( size_t i = 0; i < 24; i++ )
    {
        energy += p_energy_list[i];
    }
    
    return ( energy * 10 );
}

/**
 * @brief  更新能量数据
 * @param  [in] 无
 * @return 无
 * @note   
 */
static void energy_info_update( void )
{
    sys_cabinet_telemetry_info_t *p_sys_cabinet_telemetry_info = &sdk_shm_telemetry_data_get()->sys_cabinet_telemetry_info;
    internal_shared_data_t *p_internal_shared_data = &sdk_shm_get()->internal_shared_data;

    data_energy_t meter_energy_data = {0};
    data_energy_t pcc_energy_data   = {0};
    data_energy_t pv_energy_data    = {0};
    data_energy_t load_energy_data  = {0};
    energy_time_t *p_time = NULL;
    char tm_str[30] = {0};

    /* PV power +发电 */
    /* es power +放电 -充电 */
    /* pcc +输出 -输入 */
    /* load +耗电 */

    p_time = &g_energy_record_task.now_time;
 
    snprintf( tm_str, sizeof( tm_str ),"%04d-%02d-%02d ",p_time->year, p_time->month, p_time->day);
    select_sqlite_db_day( tm_str, &meter_energy_data , ENERGY_DB      , METER     ); 
    select_sqlite_db_day( tm_str, &pcc_energy_data   , PCC_ENERGY_DB  , PCC_METER ); 
    select_sqlite_db_day( tm_str, &pv_energy_data    , PV_ENERGY_DB   , PV_METER  ); 
    select_sqlite_db_day( tm_str, &load_energy_data  , LOAD_ENERGY_DB , LOAD      ); 
    
    p_internal_shared_data->sys_capacity.photo_meter_daily_capacity  = energy_data_cal_daliy_energy( pv_energy_data.charge );
    p_internal_shared_data->sys_capacity.grid_daily_input_capacity   = energy_data_cal_daliy_energy( pcc_energy_data.charge );
    p_internal_shared_data->sys_capacity.grid_daily_output_capacity  = energy_data_cal_daliy_energy( pcc_energy_data.discharge );
    p_internal_shared_data->sys_capacity.load_daily_consume_capacity = energy_data_cal_daliy_energy( load_energy_data.charge);
    p_internal_shared_data->sys_capacity.es_daily_discharge_capacity = energy_data_cal_daliy_energy( meter_energy_data.discharge );
    p_internal_shared_data->sys_capacity.es_daily_charge_capacity    = energy_data_cal_daliy_energy( meter_energy_data.charge );

    select_sqlite_db_total( tm_str, &meter_energy_data.charge[0] , &meter_energy_data.discharge[0] , ENERGY_DB      , METER     ); 
    select_sqlite_db_total( tm_str, &pcc_energy_data.charge[0]   , &pcc_energy_data.discharge[0]   , PCC_ENERGY_DB  , PCC_METER ); 
    select_sqlite_db_total( tm_str, &pv_energy_data.charge[0]    , &pv_energy_data.discharge[0]    , PV_ENERGY_DB   , PV_METER  ); 
    select_sqlite_db_total( tm_str, &load_energy_data.charge[0]  , &load_energy_data.discharge[0]  , LOAD_ENERGY_DB , LOAD      ); 
         
    p_internal_shared_data->sys_capacity.photo_meter_total_capacity  = pv_energy_data.charge[0]       * 10;
    p_internal_shared_data->sys_capacity.grid_total_input_capacity   = pcc_energy_data.charge[0]      * 10;
    p_internal_shared_data->sys_capacity.grid_total_output_capacity  = pcc_energy_data.discharge[0]   * 10;
    p_internal_shared_data->sys_capacity.load_total_consume_capacity = load_energy_data.charge[0]     * 10;
    p_internal_shared_data->sys_capacity.es_total_discharge_capacity = meter_energy_data.discharge[0] * 10;
    p_internal_shared_data->sys_capacity.es_total_charge_capacity    = meter_energy_data.charge[0]    * 10;

    int32_t es_power   = p_internal_shared_data->total_realtime_energy.meter_power / 100;
    int32_t pcc_power  = p_sys_cabinet_telemetry_info->anti_reflux_power;
    int32_t pv_power   = p_sys_cabinet_telemetry_info->photo_meter_power;
    int32_t load_power =  0 - (es_power + pcc_power + pv_power);
    if ( load_power < 0  )
        load_power = 0;
        
    p_internal_shared_data->sys_capacity.load_power = load_power;
    
    // printf( "---------------es_power:%d, pcc_power:%d, pv_power:%d, load_power:%d\n", es_power, pcc_power, pv_power, p_internal_shared_data->sys_capacity.load_power );
    // /* 打印 sys_capacity 里所有变量 */
    // printf( "load_power:%d\r\n"                  , p_internal_shared_data->sys_capacity.load_power );
    
    // printf("photo_meter_daily_capacity:%d\r\n"   , p_internal_shared_data->sys_capacity.photo_meter_daily_capacity );
    // printf("photo_meter_total_capacity:%d\r\n"   , p_internal_shared_data->sys_capacity.photo_meter_total_capacity );
    // printf("grid_daily_input_capacity:%d\r\n"    , p_internal_shared_data->sys_capacity.grid_daily_input_capacity );
    // printf("grid_total_input_capacity:%d\r\n"    , p_internal_shared_data->sys_capacity.grid_total_input_capacity );
    // printf("grid_daily_output_capacity:%d\r\n"   , p_internal_shared_data->sys_capacity.grid_daily_output_capacity );
    // printf("grid_total_output_capacity:%d\r\n"   , p_internal_shared_data->sys_capacity.grid_total_output_capacity );
    // printf("load_power:%d\r\n"                   , p_internal_shared_data->sys_capacity.load_power );
    // printf("load_daily_consume_capacity:%d\r\n"  , p_internal_shared_data->sys_capacity.load_daily_consume_capacity );
    // printf("load_total_consume_capacity:%d\r\n"  , p_internal_shared_data->sys_capacity.load_total_consume_capacity );
    // printf("es_daily_discharge_capacity:%d\r\n"  , p_internal_shared_data->sys_capacity.es_daily_discharge_capacity );
    // printf("es_daily_charge_capacity:%d\r\n"     , p_internal_shared_data->sys_capacity.es_daily_charge_capacity );
    // printf("es_total_discharge_capacity:%d\r\n"  , p_internal_shared_data->sys_capacity.es_total_discharge_capacity );
    // printf("es_total_charge_capacity:%d\r\n"     , p_internal_shared_data->sys_capacity.es_total_charge_capacity );

    return;
}
