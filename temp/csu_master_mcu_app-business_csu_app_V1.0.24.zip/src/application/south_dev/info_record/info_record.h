#ifndef __INFO_RECORD_H__
#define __INFO_RECORD_H__

#include "data_types.h"
#include "data_shm.h"

#if (1)
#define INFO_RECORD_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else
#define INFO_RECORD_DEBUG_PRINT(...) {do {} while(0);}
#endif


/** 
 * @brief   信息记录任务启动（用于信息存储，包括运行数据、计量表功率数据、计量表充放电量数据）
 * @param
 * @return
 */
void info_record_module_init(void);

#endif  /* __INFO_RECORD_TASK_H__ */
