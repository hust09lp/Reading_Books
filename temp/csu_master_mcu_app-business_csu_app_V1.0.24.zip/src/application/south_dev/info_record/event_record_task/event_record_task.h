#ifndef __SYS_EVENT_RECORD_TASK_H__
#define __SYS_EVENT_RECORD_TASK_H__

#include "data_types.h"
#include "sdk_fs.h"

#include <stdio.h>
#include <stdlib.h>
#include <time.h>


// 打印开关
#if (1)
#define EVENT_RECORD_DEBUG_PRINT(...) printf(__VA_ARGS__);
#else
#define EVENT_RECORD_DEBUG_PRINT(...)
#endif

#pragma pack(push)
#pragma pack(1)
typedef struct
{
    uint8_t year;
    uint8_t mon;
    uint8_t day;
    uint8_t hour;
    uint8_t min;
    uint8_t sec;    
}event_time_t;

typedef struct _history_event_t
{
    uint16_t event_id;
    event_time_t event_time;
	struct _history_event_t *next;
}history_event_t;
#pragma pack(pop)

 
/**
 * @brief  	历史事件存储，当事件id状态0->1时产生一个故障记录
 * @param  	[in] void
 * @return 	void
 */
void *thread_history_event(void *arg);


#endif

