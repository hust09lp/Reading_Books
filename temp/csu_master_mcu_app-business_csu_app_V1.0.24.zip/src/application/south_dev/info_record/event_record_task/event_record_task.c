#include "event_record_task.h"
#include "event_fault_text.h"
#include "sdk_shm.h"
#include "sdk_public.h"
#include "sdk_log.h"
#include "sofar_errors.h"
#include "data_shm.h"
#include <string.h>
#include <stdbool.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>
#include "app_common.h"
#include "sqlite3.h"



#define FAULT_DB_PATH "/user/data/event/Faults.db"
#define SDK_OK  0
#define PATH_HISTORY_EVENT_RECOND_FOLDER	"/user/data/event/"

uint8_t g_csu_system_fault[CSU_SYSTEM_FAULT_LEN_BYTE] = {0};
uint8_t g_combiner_cabinet_fault_pre[COMBINER_CABINET_SYSTEM_FAULT_LEN_BYTE] = {0};

int32_t sqlite_db_create_table(void);



/**
 * @brief  检查故障日志数据库文件是否存在和有效
 * @param  [in] none
 * @param  [out] none
 * @return 0-数据库文件正常   -1-数据库文件异常
 */
static int32_t event_db_file_check(void)
{
	int32_t ret = -1;
	fs_t *p_fs = NULL;
	
	
    ret = sdk_fs_access((const int8_t *)FAULT_DB_PATH, F_OK);
    if (ret == -1)  // 文件不存在，创建该文件
    {
		log_i((int8_t *)"\n Faults.db  is not exist\n");
		sqlite_db_create_table();
		return (0);
    }
	else     // 文件存在，检查文件大小是否为0
	{
		log_i((int8_t *)"\nFaults.db  is exist\n");
		p_fs = sdk_fs_open((const int8_t *)FAULT_DB_PATH,FS_READ);
		if ( p_fs != NULL)
		{
			ret = sdk_fs_get_size(p_fs);
			sdk_fs_close(p_fs);
			log_i((int8_t *)"\nFaults.db  open success,file size:%d\n",ret);
			if (ret == 0)
			{
				log_i((int8_t *)"\nre creat Faults.db \n");
				sdk_fs_remove((const int8_t *)FAULT_DB_PATH);
				sqlite_db_create_table();
			}
		}
		else 
		{
			return (-1);
		}
	}
	return (0);
}


static int32_t history_event_start_write(uint16_t event_id)
{
	sqlite3 *db;
	sdk_rtc_t rtc_time;
    int32_t ret;
	char *errMsg = NULL;
	char sql[128] = {0};
		
	ret = sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
	if (ret != SDK_OK)
    {
		log_i((int8_t *)"\n [%s:%d] sdk_rtc_get fail \n", __func__, __LINE__);
		return (-1);
    }
	event_db_file_check();
	snprintf(sql, 128, "INSERT INTO Faults (FAULTID, STARTTIME, ENDTIME) VALUES (%d, '%04d-%02d-%02d %02d:%02d:%02d', '1970-00-00 00:00:00');" \
	,event_id, 2000 + rtc_time.tm_year,rtc_time.tm_mon, rtc_time.tm_day, rtc_time.tm_hour, rtc_time.tm_min, rtc_time.tm_sec);

	
    ret = sqlite3_open("/user/data/event/Faults.db", &db);
    if( ret ) {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return(-1);
    }

	ret = sqlite3_exec(db, sql, 0, 0, &errMsg);
	
	if (ret != SQLITE_OK) {
		fprintf(stderr, "SQL error: %s\n", errMsg);
		sqlite3_free(errMsg);
		return (-1);
	} else {
	   fprintf(stdout, "Records created successfully\n");
	}
	sqlite3_close(db);
	return(0);
}

static int32_t history_event_end_write(uint16_t event_id)
{
	sqlite3 *db;
	sqlite3_stmt *stmt;
	sdk_rtc_t rtc_time;
    int32_t ret;
	char *errMsg = NULL;
	char sql_update[128] = {0};
	char new_end_time[32] = {0};
	
	
	event_db_file_check();
	// 查询最近一条故障ID为1的记录
	snprintf(sql_update, 128, "SELECT ID FROM Faults WHERE FAULTID = %d ORDER BY ID DESC LIMIT 1;",event_id);
	
    ret = sqlite3_open("/user/data/event/Faults.db", &db);
    if( ret ) {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return(-1);
    }
	
	ret = sqlite3_prepare_v2(db, sql_update, -1, &stmt, 0);
	
	if (ret != SQLITE_OK) {
		fprintf(stderr, "Failed to fetch data: %s\n", sqlite3_errmsg(db));
		sqlite3_close(db);
		return (-1);
	}
	
	int latest_id;
	// 如果有结果
	if (sqlite3_step(stmt) == SQLITE_ROW) {
		latest_id = sqlite3_column_int(stmt, 0);
	} else {
		fprintf(stderr, "No record found with the provided FAULTID.\n");
		sqlite3_close(db);
		return (-1);
	}
	
	sqlite3_finalize(stmt);

	ret = sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
	if (ret != SDK_OK)
    {
		log_i((int8_t *)"\n [%s:%d] sdk_rtc_get fail \n", __func__, __LINE__);
		sqlite3_close(db);
		return (-1);
    }	
	// 更新这条记录的结束时间
	sprintf(new_end_time, "'%04d-%02d-%02d %02d:%02d:%02d'", 2000 + rtc_time.tm_year,rtc_time.tm_mon, rtc_time.tm_day, rtc_time.tm_hour, rtc_time.tm_min, rtc_time.tm_sec);
	sprintf(sql_update, "UPDATE Faults SET ENDTIME = %s WHERE ID = %d;", new_end_time, latest_id);
	
	ret = sqlite3_exec(db, sql_update, 0, 0, &errMsg);
	
	if (ret != SQLITE_OK) {
		fprintf(stderr, "SQL error: %s\n", errMsg);
		sqlite3_free(errMsg);
		sqlite3_close(db);
		return (-1);
	} else {
		fprintf(stdout, "Record updated successfully\n");
	}
	
	sqlite3_close(db);
	return (0);
}


/**
 * @brief  	CSU故障历史事件管理
 * @param  	[in] void
 * @return 	void
 */
void CSU_fault_history_event_manage(void)
{
	uint8_t *p_fault = NULL;
	uint16_t id;
	uint8_t i = 0, j = 0;
	int32_t ret;
	telematic_data_t *p_telematic_data;

	/* CMU系统故障 */
	p_telematic_data = sdk_shm_telematic_data_get();
	p_fault = p_telematic_data->csu_system_fault_info;

	ret = memcmp(p_fault, g_csu_system_fault, CSU_SYSTEM_FAULT_LEN_BYTE);
	if (ret != 0)
	{
		for(i = 0; i < CSU_SYSTEM_FAULT_LEN_BYTE; i++)
		{
			EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] p_fault[%d] = %d  g_csu_system_fault[%d] = %d\n", __func__, __LINE__,i , p_fault[i], i, g_csu_system_fault[i]);
			for(j = 0; j < 8; j++)
			{
				EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] [%d]  %d %d\n", __func__, __LINE__,i ,((p_fault[i] >> j) & 0x01) ,((g_csu_system_fault[i] >> j) & 0x01));
				if((((p_fault[i] >> j) & 0x01) != ((g_csu_system_fault[i] >> j) & 0x01)))
				{
					//存储事件
					id = 8*i + j + 1;
					if ((g_csu_system_fault[i] >> j) & 0x01)
					{
						ret = history_event_end_write(id);
                        if(ret == 0)
                        {
                            EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d end ret %d\n", __func__, __LINE__, id,ret);
                            BIT_CLR(g_csu_system_fault[i], j);
                        }
					}
					else
					{
						ret = history_event_start_write(id);
                        if(ret == 0)
                        {
                            EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d start\n", __func__, __LINE__, id);
							BIT_SET(g_csu_system_fault[i], j);
                        }	
					}
				}
			}
		}
		// memcpy(g_csu_system_fault, p_fault, CSU_SYSTEM_FAULT_LEN_BYTE);
	}	

}


/**
 * @brief  	系统汇流柜故障历史事件管理
 * @param  	[in] void
 * @return 	void
 */
void csu_system_combiner_cabinet_fault_history_event_manage(void)
{
	uint8_t *p_fault = NULL;
	uint16_t id;
	uint8_t i = 0, j = 0;
	int32_t ret;
	telematic_data_t *p_telematic_data;

	/* 系统汇流柜故障 */
	p_telematic_data = sdk_shm_telematic_data_get();
	p_fault = p_telematic_data->combiner_cabinet_system_fault_info;

	ret = memcmp(p_fault, g_combiner_cabinet_fault_pre, COMBINER_CABINET_SYSTEM_FAULT_LEN_BYTE);
	if (ret != 0)
	{
		for(i = 0; i < COMBINER_CABINET_SYSTEM_FAULT_LEN_BYTE; i ++)
		{
			EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] p_fault[%d] = %d  g_combiner_cabinet_fault_pre[%d] = %d\n", __func__, __LINE__,i , p_fault[i], i, g_combiner_cabinet_fault_pre[i]);
			for(j = 0; j < 8; j++)
			{
				if((((p_fault[i] >> j) & 0x01) != ((g_combiner_cabinet_fault_pre[i] >> j) & 0x01)))
				{
					//存储事件
					id = 8*i + j + 101;
					if ((g_combiner_cabinet_fault_pre[i] >> j) & 0x01)
					{
						ret = history_event_end_write(id);
                        if(ret == 0)
                        {
                            EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d end ret %d\n", __func__, __LINE__, id,ret);
                            BIT_CLR(g_combiner_cabinet_fault_pre[i], j);
                        }
					}
					else
					{
						ret = history_event_start_write(id);
                        if(ret == 0)
                        {
						    EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] history_event_write id = %d start\n", __func__, __LINE__, id);		
                            BIT_SET(g_combiner_cabinet_fault_pre[i], j);
                        }
                    }
				}
			}
		}
		// memcpy(g_combiner_cabinet_fault_pre, p_fault, COMBINER_CABINET_SYSTEM_FAULT_LEN_BYTE);
	}	
}


/**
 * @brief  	主设备历史事件管理
 * @param  	[in] void
 * @return 	void
 */
void master_device_history_event_manage(void)
{

	/* CSU系统故障 */
	CSU_fault_history_event_manage();
	/* CSU系统汇流柜故障 */
	csu_system_combiner_cabinet_fault_history_event_manage();
}


/**
 * @brief  	历史事件存储，当事件id状态0->1时产生一个故障记录
 * @param  	[in] void
 * @return 	void
 */
void history_event_manage(void)
{
	master_device_history_event_manage();
}

/* Create the table if it doesn't exist */
int32_t sqlite_db_create_table(void) 
{
    char *err_msg = 0;
	int rc = 0;
    sqlite3 *db;
	char *sql_Faults = "CREATE TABLE IF NOT EXISTS Faults("  \
            "ID INTEGER PRIMARY KEY AUTOINCREMENT," \
            "FAULTID         INT    NOT NULL," \
            "STARTTIME       TEXT   NOT NULL," \
            "ENDTIME         TEXT   NOT NULL);";

	char *sql_info = "CREATE TABLE IF NOT EXISTS FaultInfo("  \
            "FAULTID         INT    NOT NULL," \
            "FaultName       TEXT   NOT NULL," \
            "Reason      	 TEXT," \
            "Suggestion      TEXT," \
            "FaultGrade      TEXT);";
	
	char *sql_trigger = "CREATE TRIGGER limit_rows AFTER INSERT ON Faults "
						"BEGIN "
							"DELETE FROM Faults WHERE ID IN ("
								"SELECT ID FROM Faults "
								"ORDER BY ID ASC "
								"LIMIT (SELECT CASE WHEN (SELECT COUNT(*) FROM Faults) > 5000 THEN 1 ELSE 0 END)"
							"); "
						"END;";
	
    rc = sqlite3_open(FAULT_DB_PATH, &db);
    if( rc ) {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return(0);
    }

    rc = sqlite3_exec(db, sql_Faults, 0, 0, &err_msg);
    if (rc != SQLITE_OK) {
        fprintf(stderr, "Failed to create table: %s\n", err_msg);
        sqlite3_free(err_msg);
    }

    rc = sqlite3_exec(db, sql_info, 0, 0, &err_msg);
    if (rc != SQLITE_OK) {
        fprintf(stderr, "Failed to create table: %s\n", err_msg);
        sqlite3_free(err_msg);
    }

	rc = sqlite3_exec(db, sql_trigger, 0, 0, &err_msg);
	if (rc != SQLITE_OK) {
		fprintf(stderr, "SQL error: %s\n", err_msg);
		sqlite3_free(err_msg);
	} else {
		fprintf(stdout, "Trigger created successfully\n");
	}
	
	sqlite3_close(db);
	return(1);
}


/**
 * @brief  	恢复所有未结束的故障列表
 * @param  	[in] void
 * @return 	void
 */
void history_event_list_reset(void)
{
    sqlite3 *db = NULL;
    char *err_msg = NULL;
    int rc = 0;
	sdk_rtc_t rtc_time = {0};
    char current_date[32] = {0};
    char sql[256] = {0};
    int32_t ret = 0;
		
	ret = sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
	if (ret != SDK_OK)
    {
		return;
    }	
    sprintf(current_date, "%04d-%02d-%02d %02d:%02d:%02d", 2000 + rtc_time.tm_year,rtc_time.tm_mon, rtc_time.tm_day, rtc_time.tm_hour, rtc_time.tm_min, rtc_time.tm_sec);
    sprintf(sql, "UPDATE Faults SET ENDTIME = REPLACE(ENDTIME, '1970-00-00 00:00:00', '%s') WHERE ENDTIME LIKE '%1970-00-00 00:00:00%';", current_date);

    rc = sqlite3_open(FAULT_DB_PATH, &db);
    if (rc != SQLITE_OK) 
    {
        fprintf(stderr, "Cannot open database: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return;
    }
 
    rc = sqlite3_exec(db, sql, NULL, NULL, &err_msg);
    if (rc != SQLITE_OK) 
    {
        fprintf(stderr, "SQL error: %s\n", err_msg);
        sqlite3_free(err_msg);
        sqlite3_close(db);
        return;
    }
 
    sqlite3_close(db);
}


/** 
 * @brief   历史事件线程（用于记录故障及告警事件的信息存储）
 * @param
 * @return 	void
 */
void *thread_history_event(void *arg)
{
	int32_t ret = 0;
	
	ret = sdk_fs_access((const int8_t *)PATH_HISTORY_EVENT_RECOND_FOLDER, F_OK);
    if (ret == -1)  // 文件夹不存在，创建该文件夹
    {
        EVENT_RECORD_DEBUG_PRINT("\n [%s:%d] /user/data/event/ Folder does not exist!!! \n", __func__, __LINE__);
        ret = sdk_fs_mkdir((const char *)PATH_HISTORY_EVENT_RECOND_FOLDER, 755);
        if (ret < 0)
        {
            log_i((int8_t *)"\n [%s:%d] sdk_fs_mkdir fail, ret = %d \n", __func__, __LINE__, ret);
        }
    }	
    //判断文件是否存在,如果文件不存在就进行创建
	ret = sdk_fs_access((const int8_t *)FAULT_DB_PATH, F_OK);
    if (ret == -1)  // 文件不存在，创建该文件
    {
		sqlite_db_create_table();
		sqlite_db_FaultInfo_init();
    }

    //此处遍历所有的故障信息，如果存在未结束故障则手动恢复
    history_event_list_reset();
		
    while (1)
    {
        history_event_manage();
        sleep(1); // sdk_delay_ms(1000);	// 1s
    }
    
    pthread_exit(NULL);
}


