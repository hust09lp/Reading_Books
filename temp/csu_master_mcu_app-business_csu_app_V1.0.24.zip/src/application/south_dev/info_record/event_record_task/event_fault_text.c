#include "event_fault_text.h"
#include "sofar_errors.h"
#include <string.h>
#include "sqlite3.h"

#define CSU_FAULT_NUM               (0x14)      // CSU系统故障数量
#define COMBINER_CABINET_FAULT_NUM  (0x36)      // CSU系统汇流柜故障数量


// CSU系统故障显示 (0x01 ~ 0x10)
const char *p_csu_fault_text[CSU_FAULT_NUM] = \
{
    "USB故障",
    "SD卡故障",
    "RTC时钟故障",
    "SPI通信故障",
    "SCI通信故障",
    "PCS通讯失联",
    "协议版本不一致",
    "文件设备参数与实际不一致",
    "箱变通信故障",
    "CMU1通信失联",
    "CMU2通信失联",
    "CMU3通信失联",
    "CMU4通信失联",
    "CMU5通信失联",
    "CMU6通信失联",
    "并柜主机通信失联",
    "并柜从机通信失联",
    "并柜汇流柜通信失联",
    "汇流柜总故障",
    "预留"
};

const char *p_csu_grade_fault_text[CSU_FAULT_NUM] = \
{
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "预留"
};


const char *p_combiner_cabinet_fault_text[COMBINER_CABINET_FAULT_NUM] = \
{
    "监控板过温告警",
    "AC舱过温告警",
    "监控板过温保护",
    "AC舱过温保护",
    "监控板低温告警",
    "AC舱低温告警",
    "监控板温度传感器故障",
    "AC舱温度传感器故障",
    "水浸告警",
    "门禁告警",
    "AC SPD故障",
    "并网开关位置故障",
    "风扇1故障",
    "风扇2故障",
    "绝缘监测设备故障",
    "绝缘监测故障",
    "储能柜故障",
    "远程REPO故障",
    "PCSM1 AC断路器故障",
    "PCSM2 AC断路器故障",
    "PCSM3 AC断路器故障",
    "PCSM4 AC断路器故障",
    "PCSM5 AC断路器故障",
    "PCSM6 AC断路器故障",
    "PCSM1 CAN通讯失联",
    "PCSM2 CAN通讯失联",
    "PCSM3 CAN通讯失联",
    "PCSM4 CAN通讯失联",
    "PCSM5 CAN通讯失联",
    "PCSM6 CAN通讯失联",
    "计量电表失联",
    "防逆流电表失联",
    "微机装置失联",
    "抽湿器失联",
    "测控装置失联",
    "PCS模块机型读取错误",
    "防逆流失败",
    "STS开关位置故障",
    "旁路开关故障",
    "SPD1告警",
    "SPD2告警",
    "QF1开关故障",
    "计量电表2失联",
    "第一块计量电表3失联",
    "第二块计量电表3失联",
    "第三块计量电表3失联",
    "第四块计量电表3失联",
    "第五块计量电表3失联",
    "第一块光伏电表失联",
    "第二块光伏电表失联",
    "第三块光伏电表失联",
    "预留",
    "预留",
    "预留"
};

const char *p_combiner_cabinet_grade_fault_text[COMBINER_CABINET_FAULT_NUM] = \
{
    "次要",
    "次要",
    "重要",
    "重要",
    "次要",
    "次要",
    "次要",
    "次要",
    "重要",
    "重要",
    "次要",
    "重要",
    "重要",
    "次要",
    "次要",
    "重要",
    "重要",
    "紧急",
    "重要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "重要",
    "次要",
    "次要",
    "重要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "次要",
    "预留",
    "预留",
    "预留",
};


/**
 * @brief  	根据索引，获取CSU的故障等级显示文本
 * @param  	[in] index 	索引
 * @param  	[out] buff 	获取到的CSU故障等级显示文本
 * @return 	执行结果
 * @retval  =0: 成功
 * @retval  <0: 失败，返回错误代码
 */

int32_t csu_fault_text(sqlite3 *db)
{
	int32_t i;
	int32_t ret;
	char sql[256] = {0};
	char *errMsg = NULL;

	for (i = 0; i < CSU_FAULT_NUM; ++i)
	{
		snprintf(sql, 256, "INSERT INTO FaultInfo (FAULTID, FaultName, Reason, Suggestion, FaultGrade) VALUES (%d, '%s', '%s','%s','%s');" \
				,i+1 , p_csu_fault_text[i], "", "", p_csu_grade_fault_text[i]);
		ret = sqlite3_exec(db, sql, 0, 0, &errMsg);
	
		if (ret != SQLITE_OK) 
        {
			fprintf(stderr, "SQL error: %s\n", errMsg);
			sqlite3_free(errMsg);
			return (-1);
		}	
	}

    return 0;
}

int32_t combiner_cabinet_fault_text(sqlite3 *db)
{
	int32_t i;
	int32_t ret;
	char sql[256] = {0};
	char *errMsg = NULL;

	for (i = 0; i < COMBINER_CABINET_FAULT_NUM; ++i)
	{
		snprintf(sql, 256, "INSERT INTO FaultInfo (FAULTID, FaultName, Reason, Suggestion, FaultGrade) VALUES (%d, '%s', '%s','%s','%s');" \
				,i+1 , p_combiner_cabinet_fault_text[i], "", "", p_combiner_cabinet_grade_fault_text[i]);
		ret = sqlite3_exec(db, sql, 0, 0, &errMsg);
	
		if (ret != SQLITE_OK) 
        {
			fprintf(stderr, "SQL error: %s\n", errMsg);
			sqlite3_free(errMsg);
			return (-1);
		}
	}
    return 0;
}


int32_t sqlite_db_FaultInfo_init(void) 
{
	int32_t rc = 0;
    sqlite3 *db = NULL;
	
    rc = sqlite3_open("/user/data/event/Faults.db", &db);
    if( rc ) 
    {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        return(0);
    }

	csu_fault_text(db);
    combiner_cabinet_fault_text(db);

	sqlite3_close(db);

    return 0;
}


