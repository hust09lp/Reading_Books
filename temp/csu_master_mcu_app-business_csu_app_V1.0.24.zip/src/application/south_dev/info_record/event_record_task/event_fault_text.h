/** 
 * @file          fault_text.h
 * @brief         故障文本接口函数说明
 * @author        liangguyao
 * @version       V0.0.1     初始版本
 * @date          2023/05/18
 * @copyright     Copyright (c) 2023 by SofarSolar, All Rights Reserved.
 */


#ifndef __FAULT_TEXT_H__
#define __FAULT_TEXT_H__


#include "data_types.h"


#if (1)
#define WEB_FAULT_TEXT_PRINT(...) printf(__VA_ARGS__);
#else
#define WEB_FAULT_TEXT_PRINT(...)
#endif

#define FAULT_NAME_TEXT_LEN         (64)        // 故障名称最大长度

/**
 * @brief  	根据索引，获取CSU故障等级显示文本
 * @param  	[in] index 	索引
 * @param  	[out] buff 	获取到的CMU故障显示文本
 * @return 	执行结果
 * @retval  =0: 成功
 * @retval  <0: 失败，返回错误代码
 */

int32_t sqlite_db_FaultInfo_init(void);

#endif /* __FAULT_TEXT_H__ */
