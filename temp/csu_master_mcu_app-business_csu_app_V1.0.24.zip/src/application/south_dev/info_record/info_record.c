#include <pthread.h>
#include <unistd.h>
#include "sdk_public.h"
#include "sdk_log.h"
#include "event_record_task.h"
#include "energy_record_task.h"
#include "power_record_task.h"
#include "info_record.h"


/** 
 * @brief   信息记录任务启动（用于信息存储，包括运行数据、计量表功率数据、计量表充放电量数据）
 * @param
 * @return
 */
void info_record_module_init(void)
{
    int16_t ret = 0;
    pthread_attr_t info_record_attr;

    // 初始化线程属性
    ret = pthread_attr_init(&info_record_attr);
    if (ret)
    {
        INFO_RECORD_DEBUG_PRINT((int8_t *)"\n [%s:%d] pthread_attr_init error!!! \n", __func__, __LINE__);
        exit(-1); // 线程属性初始化出错
    }
	
    // 设置线程属性为分离状态
    ret = pthread_attr_setdetachstate(&info_record_attr, PTHREAD_CREATE_DETACHED);
    if (ret)
    {
        INFO_RECORD_DEBUG_PRINT((int8_t *)"\n [%s:%d] pthread_attr_setdetachstate info_record_attr error!!! \n", __func__, __LINE__);
        exit(-1); // 线程分离属性设置出错
    }

    // 历史电量&功率线程
    pthread_t history_energy;
    ret = pthread_create(&history_energy, &info_record_attr, &thread_history_energy, NULL);
    if (ret)
    {
        INFO_RECORD_DEBUG_PRINT((int8_t *)"\n [%s:%d] pthread_create history_energy error!!! \n", __func__, __LINE__);
        return; // 线程创建出错退出
    }

    // 历史功率线程
    pthread_t history_power;
    ret = pthread_create(&history_power, &info_record_attr, &thread_history_power, NULL);
    if (ret)
    {
        INFO_RECORD_DEBUG_PRINT((int8_t *)"\n [%s:%d] pthread_create history_power error!!! \n", __func__, __LINE__);
        return; // 线程创建出错退出
    }
	
    // 历史事件线程
    pthread_t history_event;
    ret = pthread_create(&history_event, &info_record_attr, &thread_history_event, NULL);
    if (ret)
    {
        INFO_RECORD_DEBUG_PRINT((int8_t *)"\n [%s:%d] pthread_create history_event error!!! \n", __func__, __LINE__);
		exit(-1);// 线程创建出错退出
    }

    // 销毁线程属性结构,它在重新初始化之前不能重新使用
    pthread_attr_destroy(&info_record_attr);

}

