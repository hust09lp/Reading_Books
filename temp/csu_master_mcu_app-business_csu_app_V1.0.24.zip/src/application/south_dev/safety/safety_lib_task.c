/*
 * @file    : safety_lib_task.c
 * @brief   : 安规库导入、切换等任务
 * @Company : 首航新能源
 * @author  : liuyixuan
 * @note    : 
 * @date    : 2023-01-09
 */

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <errno.h>
#include <pthread.h>

#include "data_shm.h"
#include "sdk_shm.h"
//#include "sdk_file.h"
#include "sdk_check.h"
#include "sdk_safety.h"
#include "safety_lib_task.h"
//#include "sofar_debug.h"
//#include "firmware_config.h"

//common_data_t *shm;

safety_file_package_signature_t g_safety_file_sign = {0};
uint16_t g_safety_country_code = 0;    //当前安规国家与地区,用于上位机切换安规失败时回退安规国家与地区
int8_t g_safety_firmware_object_num = 0;   //安规对应的升级对象脚标
uint8_t safety_change_flag = 0;
#define     UPDATE_PATH                 "/user/update/"  				 // 升级固件路径

#if (1)
#define SAFET_DEBUG_PRINT(...) printf(__VA_ARGS__);
#else
#define SAFET_DEBUG_PRINT(...)
#endif

void set_safety_change_flag(uint8_t flag)
{
	safety_change_flag = flag;
}

static int32_t sdk_system_cmd(int8_t * cmd)
{
    FILE *fp = NULL;

    if((fp=popen(cmd, "r")) == NULL)
    {
        printf("[%s:%s:%d] %s, cmd:%s\n", __FILE__,__func__, __LINE__, strerror(errno), cmd);
        return -1;
    }
    pclose(fp);

    return 0;
}


/**
 * @brief  : 获取安规文件包的签名信息
 * @return  {0:正常}
 * @note   : 带安规文件包存在检测
 * @see    : 
 * @date   : 2023-03-06
 */
static int16_t safety_lib_sign_get(void)
{
	int8_t data[SAFETY_SIGNING_LENGTH] = {0};

    //检查安规是否存在，不存在则退出
    if (0 != access(SAFETY_LIB_PATH, F_OK))
    {
        return -1;
    }

    FILE *fp = NULL;
    if((fp = fopen((char *)SAFETY_LIB_PATH,"r")) == NULL)
    {
        SAFET_DEBUG_PRINT("open failure");
        return 1;
    }
    if(fseek(fp, -SAFETY_SIGNING_LENGTH, SEEK_END) != 0)    //负数前移
    {
        SAFET_DEBUG_PRINT("seek failure");
        fclose(fp);
        return -1;
    }

    if(fread(data, SAFETY_SIGNING_LENGTH, 1, fp) != 1)
    {
        SAFET_DEBUG_PRINT("read failure");
        fclose(fp);
        return -1;
    }
    fclose(fp);
    memcpy(&g_safety_file_sign, data, sizeof(g_safety_file_sign));
    
    return 0;
}

/**
 * @brief  : 安规文件包导入进度
 * @param   {uint16_t} max 总值
 * @param   {uint16_t} now 当前值
 * @return  {*}
 * @note   : 0->100
 * @see    : 
 * @date   : 2023-03-14
 */
static void safety_lib_progress_bar(uint16_t max, uint16_t now)
{
	firmware_update_t *p_update = sdk_shm_firmware_update_info_get();
    p_update->module_percent[g_safety_firmware_object_num] = now*100/max;    //进度条
}


int little2big(int le) {

    return (le & 0xff) << 24 
            | (le & 0xff00) << 8 
            | (le & 0xff0000) >> 8 
            | (le >> 24) & 0xff;
}


/**
 * @brief  : 签名信息检验
 * @param   {uint8_t} progress_flag
 * @return  {0：正常}
 * @note   : safety_lib_sign_get()带安规文件包存在检测
 * @see    : 
 * @date   : 2023-03-14
 */
static int16_t safety_lib_sign_check(uint8_t progress_flag)
{
	int8_t data[SAFETY_PACKAGE_READ_LENGTH] = {0};
    uint32_t crc32 = 0xFFFFFFFF;
    uint16_t i = 0;
    uint32_t length = 0;    //安规文件包剩余长度
    uint32_t package_num = 0;
	//SAFET_DEBUG_PRINT("g_safety_file_sign.file_len %d \n", g_safety_file_sign.file_len);
    if(safety_lib_sign_get() != 0)
    {
        SAFET_DEBUG_PRINT("safety_lib_sign_get failure");
        return 1;
    }
	SAFET_DEBUG_PRINT("g_safety_file_sign.file_len %d \n", g_safety_file_sign.file_len);
	//SAFET_DEBUG_PRINT("file_len %d \n", little2big(g_safety_file_sign.file_len));
	
    length = g_safety_file_sign.file_len;   //获取安规文件包有效长度

    FILE *fp = NULL;
    if((fp=fopen((char *)SAFETY_LIB_PATH,"r")) == NULL)
    {
        SAFET_DEBUG_PRINT("open failure");
        return 1;
    }
    package_num = (length / SAFETY_PACKAGE_READ_LENGTH) + 1;
	SAFET_DEBUG_PRINT("package_num %d \n" ,package_num);
    for(i = 0; i < package_num; i++)	// length>>10 <==> length/1024; 注意：打印uint64_t的数值时要用%llu
    {
        memset(data, 0, sizeof(data));
        
        if(i == (package_num - 1))     //最后一包
        {
            if(fread(data, length % SAFETY_PACKAGE_READ_LENGTH, 1, fp) != 1)	// length&0x3FF <==> length%1024; 注意：打印uint64_t的数值时要用%llu
            {
                SAFET_DEBUG_PRINT("read failure end %d \n" ,i);
                fclose(fp);
                return 1;
            }
            sdk_check_crc32((uint8_t *)data, length % SAFETY_PACKAGE_READ_LENGTH, &crc32);//减去签名信息中CRC32字段
        }
        else
        {
            if(fread(data, SAFETY_PACKAGE_READ_LENGTH, 1, fp) != 1)
            {
                SAFET_DEBUG_PRINT("read failure %d \n",i);
                fclose(fp);
                return 1;
            }
            sdk_check_crc32((uint8_t *)data, SAFETY_PACKAGE_READ_LENGTH, &crc32);
        }
        if(progress_flag > 0)
        {
            safety_lib_progress_bar(package_num, i + 1);    //进度条
        }
    }
    fclose(fp);

    if(g_safety_file_sign.file_crc != crc32)
    {
        SAFET_DEBUG_PRINT("crc32 failure, crc32 = %d, file_crc32 = %d", crc32, g_safety_file_sign.file_crc);
        return 1;
    }

    return 0;
}


/**
 * @brief  : 安规库初始化
 * @param   {uint8_t} progress_flag 0:不显示进度条，1：显示进度条
 * @return  {-1：安规文件信息错误，-2：安规标准获取失败}
 * @note   : 检查安规库文件是否存在，并获取当前安规库的版本与安规国家名称
 * @see    : 
 * @date   : 2023-03-14
 */
int16_t safety_lib_init(uint8_t progress_flag)
{
    int16_t ret = 0;
	constant_parameter_data_t *p_constant_parameter = sdk_shm_constant_parameter_data_get();
    safety_attr_t safety_attr = {0};

    safety_attr.region = p_constant_parameter->sys_param_data.safety_rdr_country ;
    safety_attr.version =p_constant_parameter->sys_param_data.ver_safety_rdr_para ;

    //检验安规文件包签名信息
    if(0 != safety_lib_sign_check(progress_flag))
    {
        return -1;
    }
    
    //获取安规库的头部信息并检验
    ret = sdk_safety_lib_header_get((const int8_t *)SAFETY_LIB_PATH, &g_safety_regula_package_header);
    if (0 != ret)
    {
        SAFET_DEBUG_PRINT("sdk_safety_lib_header_get failure \n");
        return -1;
    }
    else
    {
        //更新共享内存中的安规库版本
        // shm->modbus_data.inverter_information.safety_lib_ver[0] = (uint16_t)g_safety_regula_package_header.version;
        // log_info(LOG_SAFETY_ENABLE,"1safety_lib_ver = %04x",shm->modbus_data.inverter_information.safety_lib_ver[0]);
    }
	#if 0
    //获取当前安规标准的名称
    ret = sdk_safety_regula_find_by_lib((const int8_t *)SAFETY_LIB_PATH, &safety_attr);
    if (0 != ret)
    {
        SAFET_DEBUG_PRINT("sdk_safety_regula_find_by_lib fail");
        return -2;
    }
    else
    {
        //更新共享内存中的安规标准名称
      //  memcpy(shm->modbus_data.inverter_information.safety_name, g_safety_regula_package_index_array[0].country_name, 16);
    }
	#endif
    return ret;
}

/**
 * @brief: 安规库升级任务检测
 * @return {1：需要升级，0：不需要升级}
 * @note: 
 * @see: 
 * @date: 2023年1月9日
 */
static int16_t safety_lib_update_flag_check(void)
{
	char path[100]={0};
	int8_t update_flag_safety_lib = 0;
	firmware_update_t *p_update = sdk_shm_firmware_update_info_get();
    int8_t i = 0;

    g_safety_firmware_object_num = -1;

   // if(1 == p_update->protocol_version) //V01版2k签名
    {
        for (i = 0; i < UPDATE_OBJECT_NUM; i++)
        {
            //safety_lib
            if (!strncmp((const char *)p_update->module_object[i], SAFETY_PACKAGE_NAME_KEY, strlen(SAFETY_PACKAGE_NAME_KEY)))
            {
                bzero(path, sizeof(path));
                sprintf((char *)path, "%s%s", UPDATE_PATH, (const char *)p_update->module_name[i]);//DIR_UPDATE_FILE
                if(0 != access((const char *)path, F_OK)) //文件不存在
                {
                    SAFET_DEBUG_PRINT("firmware_update_flag_check safety_lib path:%s noexist!\n", path);
                }
                else
                {
                    //升级标志位置1
                    update_flag_safety_lib = 1;
                    SAFET_DEBUG_PRINT("firmware_update_flag FILE path:%s\n", path);
                }
                g_safety_firmware_object_num = i;
                break;
            }		
        }
    }
   // else if(2 == p_update->protocol_version) //V02版2k签名
    {
        //SAFETY
      //  g_safety_firmware_object_num = firmware_index_get_new(FILE_SAFETY_NUM, ALMIGHTY_NEW_NUM);
        if(g_safety_firmware_object_num >= 0)
        {
            if(p_update->update_flag[g_safety_firmware_object_num] == 1)
            {
                bzero(path, sizeof(path));
                sprintf((char *)path, "%s%s", UPDATE_PATH, (const char *)p_update->module_name[g_safety_firmware_object_num]);
                if(access((const char *)path, F_OK) < 0) //文件不存在
                {
                    SAFET_DEBUG_PRINT("firmware_update_flag_check SAFETY path:%s noexist!\n", path);
                }
                else
                {
                    update_flag_safety_lib = 1;
                }
            }
        }
    }
   // else
    {}

    return update_flag_safety_lib;
}

/**
 * @brief: 安规库导入并初始化
 * @return {-1：安规头部信息错误，-2：安规标准获取失败}
 * @note: 将安规库文件移动到/opt/bin目录下
 * @see: 
 * @date: 2023年1月9日
 */
int16_t safety_lib_import_task(void)
{
	printf("safety_lib_import_task\n");
    int16_t ret = -1;
    char cmd[128] = {0};
    char path[100] = {0};
	firmware_update_t *firmware_update = sdk_shm_firmware_update_info_get();
    //导入安规
    memset(cmd, 0, sizeof(cmd));
    snprintf((char *)cmd, sizeof(cmd), "mv %s%s /opt/data/cfg/", UPDATE_PATH, firmware_update->module_name[g_safety_firmware_object_num]);
    sdk_system_cmd((int8_t *)cmd);
    snprintf((char *)path, sizeof(path), "/opt/data/cfg/%s", firmware_update->module_name[g_safety_firmware_object_num]);
	printf("%d %s\n",g_safety_firmware_object_num , firmware_update->module_name[g_safety_firmware_object_num]);
    rename(path, SAFETY_LIB_PATH);  //将文件名改为固定文件名，避免升级包中的文件名是错误的

    ret = safety_lib_init(1);
    if(0 == ret)
    {
    	firmware_update->module_percent[g_safety_firmware_object_num] = 100;    //进度条
        firmware_update->update_flag[g_safety_firmware_object_num] = UPDATE_NONE;
    }
    //shm->update.update_flag[g_safety_firmware_object_num] = UPDATE_NONE;
    //memset(&(shm->update.module_object[g_safety_firmware_object_num]),0, sizeof(shm->update.module_object[g_safety_firmware_object_num]));
    g_safety_firmware_object_num = -1;

    return ret;
}

/**
 * @brief: 安规库导入并初始化
 * @return {-1：安规头部信息错误，-2：安规标准获取失败}
 * @note: 将安规库文件移动到/opt/bin目录下
 * @see: 
 * @date: 2023年1月9日
 */
int16_t safety_lib_import(char* root_path, char *file_name)
{
    int16_t ret = -1;
    char cmd[128] = {0};
    char path[100] = {0};
	

    //导入安规
    memset(cmd, 0, sizeof(cmd));
    snprintf((char *)cmd, sizeof(cmd), "mv %s%s /opt/data/cfg/",root_path,file_name);
    sdk_system_cmd((int8_t *)cmd);
    snprintf((char *)path, sizeof(path), "/opt/data/cfg/%s", file_name);
    rename(path, SAFETY_LIB_PATH);  //将文件名改为固定文件名，避免升级包中的文件名是错误的


	ret = safety_lib_init(1);
	if (0 !=ret)
	{
		SAFET_DEBUG_PRINT("safety init error \n");
		return ret;
	}
  	return 0;
    
}


/**
 * @brief: 安规库导入任务
 * @return {*}
 * @note: 
 * @see: 
 * @date: 2023年1月9日
 */
void safety_lib_update_task(void)
{
    int16_t ret = 0;
	uint16_t firmware_update_flag = 0;
	firmware_update_t *p_update = sdk_shm_firmware_update_info_get();
	
    //检查安规库导入标志位
    firmware_update_flag = safety_lib_update_flag_check();
    if (1 == firmware_update_flag)
    {
        ret = safety_lib_import_task();
        //ret = safety_lib_import("");
        if (0 != ret)
        {
         	SAFET_DEBUG_PRINT("safety_lib_import error\n");
        }
		else
		{
			SAFET_DEBUG_PRINT("safety_lib_import success\n");
		}
        
        
    }
}

/**
 * @brief: 选择安规标准任务
 * @return {0：正常，-1：头部信息不对，-2：安规库中没有该安规标准/索引信息读取错误，-3：生成单独的bin文件错误}
 * @note: 
 * @see: 
 * @date: 2023年1月9日
 */
int16_t safety_change_task(void)
{
    int16_t ret = -1;
   // inverter_information_t *p_inverter_data = sdk_shm_inverter_information_get();
	constant_parameter_data_t *p_constant_parameter = sdk_shm_constant_parameter_data_get();
    safety_attr_t safety_attr = {0};

    safety_attr.region = p_constant_parameter->sys_param_data.safety_rdr_country ;
    safety_attr.version = p_constant_parameter->sys_param_data.ver_safety_rdr_para ;
	common_data_t *p_shm;
	p_shm = sdk_shm_get();

	if(NULL == p_shm)
	{
		return ret;
	}
	
  //  safety_attr.region = p_inverter_data->safety_rdr_country;
  //  safety_attr.version = p_inverter_data->ver_safety_rdr_para;

    ret = sdk_safety_lib_select((const int8_t *)SAFETY_LIB_PATH, (int8_t *)SAFETY_PATH, &safety_attr);
    if (0 != ret)
    {
        //安规标准切换失败，将安规国家与地区回退到设置前的参数
        //shm->modbus_data.inverter_information.safety_rdr_country = g_safety_country_code;
        SAFET_DEBUG_PRINT("safety change error[%s]:%d", __func__, ret);
    }
    else
    {
        //安规标准切换成功
        //shm->modbus_data.inverter_information.safety_rdr_country = safety_attr.region;
       // shm->modbus_data.inverter_information.ver_safety_rdr_para = safety_attr.version;
       SAFET_DEBUG_PRINT("safety change success[%s]:%d\n", __func__, ret);
       p_shm->internal_shared_data.safety_update_flag = 1;
        g_safety_country_code = safety_attr.region;
    }

    return ret;
}

// 测试代码
void test_safe_init(void)
{
    
    constant_parameter_data_t *p_constant_parameter = sdk_shm_constant_parameter_data_get();
    

    p_constant_parameter->sys_param_data.safety_rdr_country = 5;
    p_constant_parameter->sys_param_data.ver_safety_rdr_para = 1;

	return;
}


void read_safety_file()
{
	uint32_t start_addr = 0;
	uint8_t buff[128] = {0};
	for(int32_t i = 0;i < 9;i++)
	{
		start_addr = i * 128;
		get_file_data((const int8_t *)SAFETY_PATH,start_addr,128,  buff);
		parse_safety_param(buff,start_addr/2);
	}
}
void *thread_safety(void *arg)
{
	
	int32_t n1, n2, n3;
	internal_shared_data_t * inter_param = internal_shared_data_get();
	if(access((const int8_t *)SAFETY_PATH, F_OK)==0)
	{
		SAFET_DEBUG_PRINT("init:import safety\n");
		read_safety_file();
	}
    //safety_lib_init(1);
    
	while(1)
    {
    	
        //安规库导入任务
        safety_lib_update_task();
		if(inter_param->safety_switch_flag == 1)
		{
			inter_param->safety_switch_flag = 0;
			safety_change_task();
		}
		//SAFET_DEBUG_PRINT("safety_import_flag[%d],file_name[%s],root_path[%s]\n",inter_param->safety_import_flag,inter_param->file_name,inter_param->root_path);
		if(inter_param->safety_import_flag == 1)
		{
			inter_param->safety_import_flag = 0;
			if(3 == sscanf((const char *)inter_param->file_name,"%d-%d-%d.txt",&n1,&n2,&n3))
		    {
		    	SAFET_DEBUG_PRINT("[%s:%s:%d] import safety[%s%s]\n", __FILE__,__func__, __LINE__,inter_param->root_path,inter_param->file_name);
				
				import_safety_file(inter_param->root_path,inter_param->file_name);
		    }

			if((NULL != strstr(inter_param->file_name, ".bin")) && (NULL != strstr(inter_param->file_name, "SAFETY")))
			{
				safety_lib_import(inter_param->root_path,inter_param->file_name);
			}
			
		}
		#if 0
		if(access((const char *)"/user/update/safe", F_OK)==0)
		{
			test_safe_init();
			system("rm /user/update/safe");
			safety_change_task();
		}
		#endif
		
		sleep(1);
    }
	
	pthread_exit(NULL);
}


/**
 * @brief  启动安规库线程
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
void safety_task_start(void)
{
	pthread_t safety_task_id;
	
	pthread_attr_t attr;

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);

	if(pthread_create(&safety_task_id,&attr,thread_safety,NULL) != 0)
	{
		perror("pthread_create safety_task_start");
	}

	
	pthread_attr_destroy(&attr);
	return;
	
}


