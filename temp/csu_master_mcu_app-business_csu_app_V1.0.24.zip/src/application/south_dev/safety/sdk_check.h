/************************************************************************************
 *Description: sdk_check
 *Created on: 2022-06-20
 *Author: quliuliu
 ************************************************************************************/

#ifndef __SDK_CHECK_H__
#define __SDK_CHECK_H__

#include "data_types.h"

/****************************************************************
 **描 述: CRC校验
 **入 参: 
 **出 参：
 **返 回:
 */
uint16_t sdk_check_crc16(uint8_t *buf, int len);
uint16_t sdk_check_crc32(uint8_t *buf, int len, uint32_t *crc);
uint32_t sdk_check_crc32_standard(uint8_t *buf, int len);
uint32_t CheckCRC32(uint8_t *buf, int len);


#endif /* __SDK_CHECK_H__ */