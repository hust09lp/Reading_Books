/*
 * @file    : safety_lib_task.h
 * @brief   : 
 * @Company : 首航新能源
 * @author  : liuyixuan
 * @note    : 
 * @date    : 2023-01-09
 */

#ifndef __SAFETY_LIB_TASK_H 
#define __SAFETY_LIB_TASK_H  

#include "data_types.h"


/**************************************************************************
*   结构体
**************************************************************************/
#pragma pack(1) //字节对齐
//安规文件包签名信息
typedef struct
{
    uint8_t         protocol_version;   //协议版本号
    uint32_t        file_len;           //文件长度 小端模式
    uint32_t        file_crc;           //有效字节crc32
    uint8_t         reserved1[70];      //预留
    int8_t          version;            //工程名称
    uint8_t         reserved2[19];      //预留
    uint8_t         file_type;          //文件类型
    uint8_t         reserved3[127];     //预留
}safety_file_package_signature_t;
#pragma pack()

/**************************************************************************
*   宏定义
**************************************************************************/
#define SAFETY_SIGNING_LENGTH 1024
#define SAFETY_PACKAGE_READ_LENGTH 1024

#define SAFETY_LIB_PATH "/opt/data/cfg/CSU_SAFETY.bin"    //安规库所在路径
#define SAFETY_PATH "/opt/data/cfg/safety"              //使用的安规文件所在路径
//安规库文件名
#define SAFETY_PACKAGE_NAME "320KW_SAFETY.bin"
//固件名称包含的关键字
#define SAFETY_PACKAGE_NAME_KEY "SAFETY" 
//固件升级文件目录
#define DIR_UPDATE_FILE "/tmp/"



/**************************************************************************
*   对外变量
**************************************************************************/
//当前安规国家与地区,用于上位机切换安规失败时回退安规国家与地区
extern uint16_t g_safety_country_code;


/*******************************************************************************
** 对外接口函数
*******************************************************************************/
//安规库初始化
int16_t safety_lib_init(uint8_t progress_flag);
//安规库导入并初始化
int16_t safety_lib_import_task(void);
//安规库导入任务
void safety_lib_update_task(void);
//选择安规标准任务
int16_t safety_change_task(void);

int16_t safety_lib_import(char* root_path, char *file_name);

#endif

