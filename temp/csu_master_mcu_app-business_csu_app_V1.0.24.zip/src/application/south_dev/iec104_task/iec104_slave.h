#ifndef __IEC104_SLAVE_H__
#define __IEC104_SLAVE_H__

#include "data_types.h"

#if (0)
#define IEC104_DEBUG_PRINT(...) printf(__VA_ARGS__);
#else
#define IEC104_DEBUG_PRINT(...) {do {} while(0);}
#endif

#define YX_SYS_START_ADDR       0x01
#define YX_BAT_START_ADDR       0x100

/*遥信*/
#define YX_PCS_SYSTEM_FAULT_START_ADDR       0xD01
#define YX_PCS_CABINET_STATUS_START_ADDR       0xD31
#define YX_PCS_CABINET_FAULT_START_ADDR       0XD81
#define YX_PCS_MODULE_START_ADDR       0xE01
#define YX_PCS_MODULE_START_ADDR_2       0xEB1

/*遥测*/
#define YC_PCS_CABINET_VERSION_START_ADDR       0x014001//0x010001
#define YC_PCS_CABINET_INFO_START_ADDR       0x014201//0x010201
#define YC_PCS_MODULE_INFO_START_ADDR       0x014301//0x010301
#define YC_PCS_MODULE_INFO_START_ADDR_2       0x014333//0x010301
#define YC_PCS_MODULE_INFO_START_ADDR_3       0x014365//0x010301

#define YC_PCS_MODULE_VERSION_START_ADDR      0x0143B1//0x0103B1
#define YC_PCS_MODULE_VERSION_START_ADDR_2      0x0143E3

/*参数*/
#define PARA_PCS_MODULE_START_ADDR      0x8301
#define PARA_PCS_SYS_START_ADDR      0x8241
#define PARA_PCS_MULTICAST_START_ADDR      0x82A1

#define PARA_CSU_SYS_START_ADDR      0x8201
/*安规参数*/
#define PARA_SAFETY_START_ADDR      0x8101
#define PARA_SAFETY_END_ADDR        0x8400


/*遥控*/          
#define YK_SWITCH_ADDR          0x6201
#define YK_FAULT_RESET_ADDR 				0x6202

#define YK_PCS_MODULE_START_ADDR           0x6211
#define YK_PCS_MODULE_END_ADDR           0x6290
#define YK_MCU2_INTERNAL_ADDR           0x600301



#define PCS_YX_SYS_LEN              (PCS_CABINET_SYSTEM_STATUS_LEN_BYTE + PCS_CABINET_SYSTEM_FAULT_LEN_BYTE)

#define YC_SYS_START_ADDR       0x4001
#define YC_BAT_START_ADDR       0x4100
#define YC_DCDC_START_ADDR      0x4B00

#define PARA_SYS_START_ADDR     0x8001
#define PARA_BAT_START_ADDR     0x8100
#define PARA_POWER_START_ADDR   0x8200

#define PARA_SYS_LEN            0x08
#define PARA_BAT_LEN            0x148
#define PARA_POWER_LEN          0x02

#define YK_START_ADDR           0x6001
#define YK_NUM_MAX              (20)


typedef struct
{
    int addr;
    uint16_t value;
} para_value_t;

typedef struct
{
    para_value_t para_value[0x7f];
    uint8_t num;
} para_value_record_t;

typedef struct{
    uint8_t flag;           // 是否需要转成modbus数据的标志
    uint8_t num;            // 获取的数据个数
    uint8_t current;        // 104已发送的数据个数
    uint16_t start_add;     // 数据起始地址
    uint16_t end_add;       // 数据结束地址
    uint16_t data[256];     // 104数据各地址对应的值
    uint16_t msg_len;       // 报文总长度
}modbus_convert_info_t;

typedef enum{
    END_CONVERT = 0,
    START_CONVERT,
}modbus_convert_flag_t;

#define print_log(format,argc...){ \
	printf("%s[%s:%d]=>",__FILE__,__func__,__LINE__); \
	printf(format,##argc); \
	printf("\n"); \
}

void iec104_slave_task_start(void);

/**
 * @brief   获取记录的预置参数信息地址
 * @param   
 * @return  预置参数结构体首地址
 */
para_value_record_t *para_value_record_get(void);

/**
 * @brief   获取与主站的连接
 * @param   
 * @return  返回连接的指针
 */
void *cs104_conn_get(int index);

/**
 * @brief   获取CMU返回的104数据
 * @param   
 * @return  返回104数据
 */
modbus_convert_info_t *cmu_iec104_data_get(void);
void cmu_modbus_info_set(uint8_t num, uint16_t start_add, uint16_t end_add);

#endif



