#include <string.h>
#include <stdio.h>
#include <errno.h>
#include "function_handle.h"
#include "iec104_slave.h"
#include "param_record.h"
#include "sci_task.h"
#include "sdk_shm.h"
#include "sdk_fs.h"
#include "sdk_safety.h"

// 文件传输名称记录
typedef struct {
    uint32_t id;              // 目录 ID
    uint8_t file_len;  
    int8_t file_path[64];              
}file_info_t;

static file_info_t g_file_info = {0};
static FILE *fp_bin = NULL;

/**
 * @brief  可写文件校验
 * @param  [in] p_name 文件名称
 * @param  [in] len 文件名称长度
 * @note   
 * @return 0 成功，1 未知错误，2 文件名不支持
 */
static uint8_t file_write_check(int8_t *p_name, uint8_t len)
{
	int n1, n2, n3;
    if(3 == sscanf((char *) p_name,"%d-%d-%d.txt",&n1,&n2,&n3))//安规文件，格式如123-000-0803.txt
    {
    	printf("file_write_check: this is safety file!\n");
        return 0;
    }

	if (strstr((char *)p_name, ".bin"))
	{
		printf("file_write_check: this is .bin file!\n");
		return (0);
	}

	if (strstr((char *)p_name, ".sofar"))
	{
		printf("file_write_check: this is .sofar file!\n");
		return (0);
	}
	else
	{
		return (2);
	}
}


int32_t import_safety_file(int8_t *path, int8_t *file_name)
{
	
	char name[128] = {0};
	snprintf(name, sizeof(name), "%s%s", path,file_name);
	IEC104_DEBUG_PRINT("\n import_safety_file [%s]\n",name);
	common_data_t *p_shm = sdk_shm_get();
	int32_t ret = -1;
	
	char cmd[128] = {0};
	safety_attr_t safety_attr = {0};

	if(NULL == p_shm)
	{
		return ret;
	}
	
	// ret = sdk_safety_txt_to_bin((int8_t *)name, (int8_t *)"/opt/data/cfg/safety", &safety_attr, 0);
	
	snprintf((char *)cmd, sizeof(cmd), "rm -rf %s", name);
	//sdk_system_cmd(cmd);
	system(cmd);
	if(ret == 0)
	{
		p_shm->constant_parameter_data.sys_param_data.safety_rdr_country = safety_attr.region;
		p_shm->constant_parameter_data.sys_param_data.ver_safety_rdr_para = safety_attr.version;
		p_shm->internal_shared_data.safety_update_flag = 1;
	}
	else
	{
		IEC104_DEBUG_PRINT("import_safety_file failed\n");
	}
	return ret;
}

/**
 * @brief  可写文件校验
 * @param  [in] offset 文件偏移
 * @param  [in] p_data 写入数据
 * @param  [in] len 写入数据长度
 * @note   
 * @return 0 成功，1 未知错误，2 文件名不支持
 */
static uint8_t firmware_data_write(uint32_t offset, int8_t *p_data, uint8_t len, uint8_t flag)
{
    int32_t rc = 0;
    char name[64] = {0};
    int32_t len2 = 0;
	printf("file_data_trs_set data 222:");
	for(int i = 0;i < 235;i++)
	{
		printf("%02x ",p_data[i]);
	}
	printf("\n");
	printf("firmware_data_write len=%d\n",len);
    snprintf(name, sizeof(name), "/tmp/update/%s", g_file_info.file_path);
    firmware_update_t *p_update = sdk_shm_firmware_update_info_get();
    IEC104_DEBUG_PRINT("\n 升级文件路径：%s \n", name);

	int n1, n2, n3;
	uint8_t safety_flag = 0;
    if(3 == sscanf((const char *)g_file_info.file_path,"%d-%d-%d.txt",&n1,&n2,&n3))
    {
    	printf("[%s:%s:%d] %s\n", __FILE__,__func__, __LINE__, "safety flag = 1");
        safety_flag = 1;
    }
    
    // 检测升级文件夹路径是否存在
    rc = sdk_fs_access((int8_t *)"/tmp/update/", FS_S_IRWXO);
    if (rc < 0)
    {
        IEC104_DEBUG_PRINT("\n 升级文件路径不存在 \n");
        if(sdk_fs_mkdir("/tmp/update/", FS_S_IRWXU|FS_S_IRWXG|FS_S_IRWXO) < 0)
        {
            IEC104_DEBUG_PRINT("\n 升级文件路径创建失败 \n");
            return (2);
        }
		IEC104_DEBUG_PRINT("\n 升级文件路径创建成功 \n");
    }

	if(fp_bin == NULL)
	{
		if((fp_bin = fopen((char *)name, "w")) == NULL)//a+
		{
			printf("[%s:%s:%d] %s\n", __FILE__,__func__, __LINE__, strerror(errno));
			return -1;
		}
	}
	
	
	if (fseek(fp_bin, offset, SEEK_SET) != 0) {
        perror("fseek");
        return -1;
    }
	//if (fwrite(p_data, len, 1, fp_bin) != 1)
	len2 = fwrite(p_data, 1, len, fp_bin);
	printf("[%s:%s:%d]len2=%d\n", __FILE__,__func__, __LINE__,len2);
	if (len2 != len)
	{
		printf("[%s:%s:%d] %s\r\n",  __FILE__,__func__, __LINE__, strerror(errno));
		
		fclose(fp_bin);
		return -1;
	}
	if (flag == 0)
    {
        fclose(fp_bin);
		fp_bin = NULL;
    }

	if((0 == flag) && (1 == safety_flag))
	{
		import_safety_file((int8_t *)"/tmp/update/",g_file_info.file_path);
	}
	
	if((0 == flag) && (NULL != strstr((char *)g_file_info.file_path, ".bin")))
	{
		// safety_lib_import("/tmp/update/",g_file_info.file_path);
	}

	if((NULL != p_update) && (0 == flag) && (NULL != strstr(name, ".sofar")))
	{
		strcpy((char *)p_update->root_path,"/tmp/update/");
		memcpy(p_update->package_name,g_file_info.file_path,sizeof(g_file_info.file_path));
		p_update->module_update_flag |= 0x07;//开启升级触发标志
		update_state_set(UPDATE);
		
	}

    return (0);
}


/**
 * @brief   参数变更同步
 * @param
 * @note   参数发生变化，将参数同步更新到共享内存
 * @return 0:正常；<0:异常
 */
int32_t para_change_synch()
{
    uint16_t *p_data = NULL;
    uint8_t i = 0; // 循环使用临时变量
    uint16_t value = 0;

    para_value_record_t *p_para_value_record = para_value_record_get();
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get();

    for (i = 0; i < p_para_value_record->num; i++)
    {
        value = p_para_value_record->para_value[i].addr;
        value -= (PARA_SYS_START_ADDR - 1);
        // IEC104_DEBUG_PRINT("\n addr = %x value = %x\n", value, p_para_value_record->para_value[i].value);

        //CSU系统
        if ((value >= 1) && (value < 0x07))
        {
            p_data = &(p_para_data->sys_param_data.storage_duration_operation_data);
            *(p_data + value - 1) = p_para_value_record->para_value[i].value;
            dev_param_save();
            dev_param_save();
            IEC104_DEBUG_PRINT("p_para_value_record");
        }
        //CSU系统汇流柜
        else if((value >= 0x41) && (value < 0x4B))
        {
            p_data = ( uint16_t* )&(p_para_data->cabinet_param_data.active_power);
            *(p_data + value - 0x41) = p_para_value_record->para_value[i].value;

            system_param_t temp = {0};
	        memcpy(&temp,&p_para_data->system_param,sizeof(system_param_t));
            temp.cabinet_param.active_power = p_para_data->cabinet_param_data.active_power;
            temp.cabinet_param.reactive_power = p_para_data->cabinet_param_data.reactive_power;
            // set_constant_data(0x2001,(uint16_t*)&temp,sizeof(temp)/2);
            set_constant_data( FUNCID_SET_POWER,(uint16_t*)&temp.cabinet_param.active_power,
                               MEMBER_DAT_NUM_CAL( &temp.cabinet_param.active_power, &temp.cabinet_param.reactive_power ) );
        }
        //EMS参数
        else if ((value >= 0x0401) && (value < 0x0438))
        {
            p_data = &(p_para_data->ems_data.demand_resp_en);
            *(p_data + value - 0x0401) = p_para_value_record->para_value[i].value;
            set_ems_data();
            set_holiday_ems_data();
        }
        else
        {
            IEC104_DEBUG_PRINT("\n 数据异常 \n");
            return true;
        }
        IEC104_DEBUG_PRINT("\n 参数地址 %x ；参数设置数据 %x\n", value, p_para_value_record->para_value[i].value);
    }

    return (0);
}


/**
 * @brief   newTime转换成RTCtime
 * @param   [in] newTime
 * @param   [in] RTCtine
 * @note   
 * @return
 */
void new2rtc_time_change(CP56Time2a newTime, sdk_rtc_t *p_rtc_time)
{
    //uint16_t sec = 0;

    p_rtc_time->tm_year = CP56Time2a_getYear(newTime);
    p_rtc_time->tm_mon = CP56Time2a_getMonth(newTime);
    p_rtc_time->tm_day = CP56Time2a_getDayOfMonth(newTime);
    p_rtc_time->tm_weekday = CP56Time2a_getDayOfWeek(newTime);
    p_rtc_time->tm_hour = CP56Time2a_getHour(newTime);
    p_rtc_time->tm_min = CP56Time2a_getMinute(newTime);
	p_rtc_time->tm_sec = CP56Time2a_getSecond(newTime);
    //sec = (newTime->encodedValue[1]<<8)|newTime->encodedValue[0];
    //p_rtc_time->tm_sec = (uint8_t)((sec + 500)/1000);   // 四舍五入
}

/**
 * @brief   时间同步
 * @param   [in] newTime
 * @note   IEC104的时钟同步功能激活时调用
 * @return
 */
int32_t system_time_update(CP56Time2a newTime)
{
    CP56Time2a time_temp = newTime;
    sdk_rtc_t rtc_time;  

    new2rtc_time_change(time_temp,&rtc_time);
    sdk_rtc_set(RTC_BIN_FORMAT, &rtc_time);

    return 0;
}

/**
 * @brief  升级状态设置
 * @param  [in] state // 0-无; 1-下载; 2-升级; 3-升级中; 4-触发U盘; 5-升级失败
 * @note   NONE=0, DOWNLOAD=1, UPDATE=2, UPDATING=3, UDISK=4, FAIL=5
 * @return
 */
void update_state_set(inform_e state)
{
    firmware_update_t *p_data = sdk_shm_firmware_update_info_get();

    p_data->state = state;
}


/**
 * @brief  读文件激活确认
 * @param  [in] asdu 文件名称
 * @param  [out] p_file_activate_con 文件激活确认
 * @note   
 * @return 0 成功，1 未知错误，2 文件名不支持
 */
int32_t file_activate_con_get(CS101_ASDU asdu, file_activate_con_t *p_file_activate_con)
{
    uint32_t id = 0;
    uint32_t size = 0;
    uint8_t len = 0;
    int8_t name[64] = {0};
    uint8_t rc = 0;
	FileIdentify file_obj = NULL;
	file_obj =	(FileIdentify) CS101_ASDU_getElement(asdu, 0);

    // 获取要写入的文件信息
    len = FileIdentify_getLen(file_obj, FILE_WRITE_ACTIVATE);
	printf("len=%d\n",len);
    //FileIdentify_getName(file_obj, FILE_READ_DIRECTORY, name);
	FileIdentify_getName(file_obj, FILE_WRITE_ACTIVATE, name);
	printf("name=%s\n",name);
    id = FileIdentify_getID(file_obj, FILE_WRITE_ACTIVATE);
	printf("id=%d\n",id);
    size = FileIdentify_getOffset(file_obj, FILE_WRITE_ACTIVATE);
	printf("size=%d\n",size);
    // 可写文件名称对比
    rc = file_write_check(name, len);

    p_file_activate_con->result = rc;
    p_file_activate_con->file_name_len = len;
    memcpy(p_file_activate_con->file_name, name, 64);
    p_file_activate_con->file_id = id;
    p_file_activate_con->file_size = size;

    g_file_info.id = id;
    g_file_info.file_len = len;
    memcpy(g_file_info.file_path, name, 64);

    return (rc);
}


/**
 * @brief  设置文件具体内容
 * @param  [in] asdu 文件名称
 * @param  [out] p_file_data_trs_con 文件传输确认
 * @note   
 * @return
 */
int32_t file_data_trs_set(CS101_ASDU asdu, file_data_trs_con_t *p_file_data_trs_con)
{
    uint32_t id = 0;
    uint32_t data_segment = 0;
    uint8_t flag = 0; // 是否有后续标志
    uint8_t len = 0;
    int8_t rc = 0;
	uint8_t data[255] = {0};
	FileIdentify file_obj = NULL;
	file_obj =  (FileIdentify) CS101_ASDU_getElement(asdu, 0);

    // 获取写入文件数据的信息
    id = FileIdentify_getID(file_obj, FILE_WRITE_DATA);
    data_segment = FileIdentify_getOffset(file_obj, FILE_WRITE_DATA);
	printf("firmware_data_write data_segment=%d\n",data_segment);
    flag = FileIdentify_getFlag(file_obj, FILE_WRITE_DATA);
	printf("firmware_data_write flag=%d\n",flag);
    FileIdentify_getChecksum(file_obj, FILE_WRITE_DATA);
    //len = CS101_ASDU_getNumberOfElements(asdu);
    len = FileIdentify_getLen(file_obj, FILE_WRITE_DATA);
	FileIdentify_get_data(file_obj, FILE_WRITE_DATA,data);
	printf("file_data_trs_set data 111:");
	for(int i = 0;i < 235;i++)
	{
		printf("%02x ",data[i]);
	}
	printf("\n");
	//len=100;
    rc = firmware_data_write(data_segment, (int8_t *)data, len, flag);//

    p_file_data_trs_con->file_id = id;
    p_file_data_trs_con->file_size = data_segment;
    p_file_data_trs_con->result = flag;

    return (rc);
}


