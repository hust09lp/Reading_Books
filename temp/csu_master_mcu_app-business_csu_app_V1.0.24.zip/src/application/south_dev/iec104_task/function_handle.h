#ifndef __FUNCTION_HANDLE_H__
#define __FUNCTION_HANDLE_H__

#include "data_types.h"
#include "cs104_slave.h"
#include "data_shm.h"
#include "sdk_public.h"

/**
 * @brief   参数变更同步
 * @param   
 * @note   参数发生变化，将参数同步更新到共享内存
 * @return
 */
int32_t para_change_synch();

/**
 * @brief   参数变更同步
 * @param   [in] newTime
 * @note   参数发生变化，将参数同步更新到共享内存
 * @return
 */
int32_t system_time_update(CP56Time2a newTime);


/**
 * @brief  升级状态设置
 * @param  [in] state // 0-无; 1-下载; 2-升级; 3-升级中; 4-触发U盘; 5-升级失败
 * @note   NONE=0, DOWNLOAD=1, UPDATE=2, UPDATING=3, UDISK=4, FAIL=5
 * @return
 */
void update_state_set(inform_e state);

/**
 * @brief   newTime转换成RTCtime
 * @param   [in] newTime
 * @param   [in] RTCtine
 * @note   
 * @return
 */
void new2rtc_time_change(CP56Time2a newTime, sdk_rtc_t *p_rtc_time);


/**
 * @brief  读文件激活确认
 * @param  [in] asdu 文件名称
 * @param  [out] p_file_activate_con 文件激活确认
 * @note   
 * @return 0 成功，1 未知错误，2 文件名不支持
 */
int32_t file_activate_con_get(CS101_ASDU asdu, file_activate_con_t *p_file_activate_con);


/**
 * @brief  设置文件具体内容
 * @param  [in] asdu 文件名称
 * @param  [out] p_file_data_trs_con 文件传输确认
 * @note   
 * @return
 */
int32_t file_data_trs_set(CS101_ASDU asdu, file_data_trs_con_t *p_file_data_trs_con);


#endif