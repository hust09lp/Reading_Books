#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <pthread.h>
#include <sys/prctl.h>
#include <arpa/inet.h>
#include "cs104_slave.h"
#include "cs104_connection.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "iec104_slave.h"
#include "sci_task.h"
#include "function_handle.h"
#include "sdk_public.h"
#include "sdk_safety.h"
#include "app_common.h"
#include "cs101_information_objects.h"
#include "mem_utils.h"

#define MAX_IP_LEN 16
static uint8_t g_connect_flag;
telematic_data_t g_telematic_data;
char server_ip_tbl[MAX_SLAVE_COUNT][MAX_IP_LEN] = {CMU1_IP, CMU2_IP, CMU3_IP, CMU4_IP, CMU5_IP, CMU6_IP};
uint8_t g_system_status;
time_t g_last_conn_time;

CS101_AppLayerParameters g_alParams = NULL;
static CS104_Slave g_slave = NULL;
CS104_Connection g_con[MAX_SLAVE_COUNT] = {NULL};
uint32_t g_mcu_addr_offset[MAX_SLAVE_COUNT] = {0x000000, 0x030000, 0x060000, 0x090000, 0x0c0000, 0x0f0000};
uint32_t g_para_addr_offset[MAX_SLAVE_COUNT] = {0x000, 0x300, 0x600, 0x900, 0xc00, 0xf00};

modbus_convert_info_t g_modbus_info = {0};


#if (1)
#define IEC104_SLAVE_LOG_D(...) do{ log_i(__VA_ARGS__) }while(0)
#else
#define IEC104_SLAVE_LOG_D(...) 
#endif

#define IEC104_SLAVE_LOG_E(...) do{ log_e(__VA_ARGS__) }while(0)

#ifndef MAX_TRY_COUNT
#define MAX_TRY_COUNT 5
#endif
#ifndef POWERSET_FUNCID
#define POWERSET_FUNCID 0x2001
#endif

// 预置参数记录               
static para_value_record_t g_para_value_record = {0};

modbus_convert_info_t *cmu_iec104_data_get(void)
{
    return &g_modbus_info;
}

void convert_iec104_to_modbus(CS101_ASDU asdu)
{

    int addrs;
    uint16_t value = 0; 
    int16_t transfer_value;
    float data;
    int num = CS101_ASDU_getNumberOfElements(asdu);
    int typeID = CS101_ASDU_getTypeID(asdu);
    uint8_t *payload = CS101_ASDU_getPayload(asdu);
    if (num > g_modbus_info.num)
    {
        //printf("not need this iec104 data. num=%d, modbusnum=%d\n", num, g_modbus_info.num);
        return;
    }
    //printf("start convert iec104 data to modbus data! num = %d, typeid=%d\n", num, typeID);

    for (int i = 0; i < num; i++)
    {
        InformationObject io = CS101_ASDU_getElement(asdu, i);
        if (io)
        {
            addrs = InformationObject_getObjectAddress(io);

            if (typeID == P_SC_RD_1)
            {
                //printf("addrs: %04x\n", addrs);
                addrs = payload[3+i*7] + payload[3+i*7+1] * 0x100 + payload[3+i*7+2] * 0x10000;
                //printf("self parse addrs: %04x\n", addrs); // 使用库解析的地址不一致
            }
            
            if ((addrs >= g_modbus_info.start_add) && (addrs <= g_modbus_info.end_add))
            {
                if (typeID == P_SC_RD_1)
                {
                    value = payload[3+i*7+5] + ((uint16_t)payload[3+i*7+6] << 8);
                    transfer_value = value;
                    //printf("parse: %d   self parse: %d\n", ParaValue_getValue((ParaValue)io), value);// 使用库解析的值不一致
                }
                else if (typeID == M_SP_NA_1)
                {
                    value = SinglePointInformation_getValue((SinglePointInformation)io);
                    //printf("single 104 data is: %x\n", value);
                }
                else
                {
                    data = MeasuredValueShort_getValue((MeasuredValueShort)io);
                    if(data < 0)
                    {
                        data = -data;
                        value = data;
                        transfer_value = (int16_t)value;
                        transfer_value = -transfer_value;
                    }
                    else
                    {
                        value = data;
                        transfer_value = (int16_t)value;
                    }
                    //printf("104 data is: %d,%x\n", data, transfer_value);
                }
                g_modbus_info.data[g_modbus_info.current] = transfer_value;
                g_modbus_info.current++;
                //printf("index and data: %d  %d\n", g_modbus_info.current, transfer_value);
            }
            else
            {
                MeasuredValueShort_destroy((MeasuredValueShort)io);
                printf("addr is error: %04x! do not need the data.\n", addrs);
                return;
            }
            MeasuredValueShort_destroy((MeasuredValueShort)io);
        }
        else
        {
            printf("message has no valid information object i = %x\n", i);
            return;
        }
    }

    if (g_modbus_info.current < g_modbus_info.num)
    {
        printf("num %d is small! waiting for %d\n", g_modbus_info.current, g_modbus_info.num - g_modbus_info.current);
        return;
    }

    g_modbus_info.flag = END_CONVERT;
}

void cmu_modbus_info_set(uint8_t num,  uint16_t start_add, uint16_t end_add)
{
    g_modbus_info.flag = START_CONVERT;
    g_modbus_info.num = num;
    g_modbus_info.current = 0;
    g_modbus_info.start_add = start_add;
    g_modbus_info.end_add = end_add;
}

/**
 * @brief   获取记录的预置参数信息地址
 * @param   
 * @return  预置参数结构体首地址
 */
para_value_record_t *para_value_record_get(void)
{
    return (&g_para_value_record);
}

void *cs104_conn_get(int index)
{
    if (index >= MAX_SLAVE_COUNT)
        return NULL;
    
    return (void *)g_con[index];
}

static void
connectionHandler (void* parameter, CS104_Connection connection, CS104_ConnectionEvent event)
{
	uint8_t index = *(uint8_t *)parameter; 

    switch (event) {
    case CS104_CONNECTION_OPENED:
        printf("Connection established[%d]\n", index);
        break;
    case CS104_CONNECTION_CLOSED:
        printf("Connection closed[%d]\n", index);
        g_con[index] = NULL;
        break;
    case CS104_CONNECTION_STARTDT_CON_RECEIVED:
        printf("Received STARTDT_CON[%d]\n", index);
        break;
    case CS104_CONNECTION_STOPDT_CON_RECEIVED:
        printf("Received STOPDT_CON[%d]\n", index);
        break;
    }
}

#if 0
static CS101_ASDU get_new_single_point_asdu(CS101_ASDU asdu, const uint8_t index)
{
    uint16_t i;
    uint32_t address;
    CS101_ASDU newAsdu = NULL;
    newAsdu = CS101_ASDU_create(g_alParams, false, CS101_ASDU_getCOT(asdu),
                                                0, 1, false, false);                                   
    if(newAsdu == NULL)
    {
        print_log("create new asdu failed");
        return NULL;
    }
    for(i=0; i<CS101_ASDU_getNumberOfElements(asdu); i++)
    {
        SinglePointInformation io = (SinglePointInformation) CS101_ASDU_getElement(asdu, i);
        if(io == NULL)
        {
            print_log("CS101_ASDU_getElement [%d] failed", i);
            CS101_ASDU_destroy(newAsdu);
            return NULL;
        }
        address = InformationObject_getObjectAddress((InformationObject) io); //获取单点遥信地址
        InformationObject_setObjectAddress((InformationObject) io, g_mcu_addr_offset[index] + address);  //更新上报的地址,需要进行偏移
        if(CS101_ASDU_addInformationObject(newAsdu, (InformationObject) io) == false) //将该IO添加到新申请的asdu中
        {
            print_log("CS101_ASDU_addInformationObject [%d] failed", i);
            SinglePointInformation_destroy(io);
            CS101_ASDU_destroy(newAsdu);
            return NULL;
        }
        SinglePointInformation_destroy(io);
    }
    //此时所有的信息都在新的asdu里面了
    return newAsdu;
}
#endif
static void handle_telemetry_value_asdu(CS101_ASDU asdu, const uint8_t index)
{
    uint8_t i;
    int32_t ioa;
    uint8_t num;
    uint8_t *payload;
    InformationObject io;
   
    num = CS101_ASDU_getNumberOfElements(asdu);
    payload = CS101_ASDU_getPayload(asdu);
    for(i=0; i<num; i++)
    {
        io = CS101_ASDU_getElement(asdu, i);
        ioa = payload[i*8] + payload[i*8+1] * 0x100 + payload[i*8+2] * 0x10000;
        if(ioa == 0x430F)  //CMU系统状态
        {
            g_system_status = MeasuredValueShort_getValue((MeasuredValueShort)io);
        }
        MeasuredValueShort_destroy((MeasuredValueShort)io);
    }
}

void asdu_info_print( CS101_ASDU asdu )
{
	IEC104_DEBUG_PRINT("RECVD ASDU type: %s(%i) elements: %i\n",
            TypeID_toString(CS101_ASDU_getTypeID(asdu)),
            CS101_ASDU_getTypeID(asdu),
            CS101_ASDU_getNumberOfElements(asdu)); 
}

/*
 * CS101_ASDUReceivedHandler implementation
 *
 * For CS104 the address parameter has to be ignored
 */
static bool
masterAsduHandler (void* parameter, int address, CS101_ASDU asdu)
{
    g_last_conn_time = time(NULL);  //有数据到来，更新时间
	uint8_t index = *(uint8_t *)parameter; //非常重要的参数,知道是哪个CMU传递过来的数据,然后根据点表信息重新包装数据
	// IEC104_DEBUG_PRINT("RECVD ASDU type: %s(%i) elements: %i\n",
    //         TypeID_toString(CS101_ASDU_getTypeID(asdu)),
    //         CS101_ASDU_getTypeID(asdu),
    //         CS101_ASDU_getNumberOfElements(asdu));
    asdu_info_print( asdu );
	if (CS101_ASDU_getTypeID(asdu) == M_SP_NA_1) {  //单点遥信
		//handle_telemetic_value_asdu(asdu, index);
        if(g_slave != NULL)
        {
            CS104_Slave_enqueueASDU(g_slave, asdu);
        }
	}
    else if (CS101_ASDU_getTypeID(asdu) == M_ME_NC_1) {  //ASDU_13遥测
		handle_telemetry_value_asdu(asdu, index);
        if(g_slave != NULL)
        {
            CS104_Slave_enqueueASDU(g_slave, asdu);
        }
	}
	else if (CS101_ASDU_getTypeID(asdu) == P_SC_RD_1) {  //ASDU_202读定值参数
        if(g_slave != NULL)
        {
            CS104_Slave_enqueueASDU(g_slave, asdu);
        }
	}
    if (g_modbus_info.flag == START_CONVERT)
    {
        convert_iec104_to_modbus(asdu);
    }
    return true;
}

/* Callback handler to log sent or received messages (optional) */
static void
masterRawMessageHandler(void* parameter, uint8_t* msg, int msgSize, bool sent)
{
	#if 0
	uint8_t index = *(uint8_t *)parameter;

    if (sent)
    {
    	// IEC104_DEBUG_PRINT("master[%d] SEND: ", index);
    }  
    else
    {
    	// IEC104_DEBUG_PRINT("master[%d] RCVD: ", index);
    }

    int i;
    for (i = 0; i < msgSize; i++) {
    //    IEC104_DEBUG_PRINT("%02x ", msg[i]);
    }

    IEC104_DEBUG_PRINT("\n");
	#else

    // if ( sent )
    // {
    //     mem_utils_print_hex_dat(  "IEC104 master send:", msg, msgSize, 20, true );
    // }else {
    //     mem_utils_print_hex_dat(  "IEC104 master recv:", msg, msgSize, 20, true );
    // }

	#endif
}


static void init_iec104_connection(uint8_t index)
{
    uint16_t port = IEC_60870_5_104_DEFAULT_PORT;
    uint8_t *p_tmp_index;

    g_con[index] = CS104_Connection_create(server_ip_tbl[index], port);
    if(g_con[index] == NULL)
    {
        IEC104_DEBUG_PRINT("call CS104_Connection_create failed\n");
        return;
    }

    p_tmp_index = (uint8_t *)malloc(sizeof(uint8_t));
    if(p_tmp_index == NULL)
    {
        printf("malloc failed\n");
        return;
    }
    *p_tmp_index = index;
    //设置连接的回调函数
    CS104_Connection_setConnectionHandler(g_con[index], connectionHandler, (void *)p_tmp_index);
    //设置数据接收的回调函数
    CS104_Connection_setASDUReceivedHandler(g_con[index], masterAsduHandler, (void *)p_tmp_index);
    //设置收发数据帧时的回调函数
    CS104_Connection_setRawMessageHandler(g_con[index], masterRawMessageHandler, (void *)p_tmp_index);

    IEC104_DEBUG_PRINT("Connecting to: %s:%i\n", server_ip_tbl[index], port);
    //如果成功连接到服务器
    if (CS104_Connection_connect(g_con[index])) {
        IEC104_DEBUG_PRINT("Connected to %s successful!\n",server_ip_tbl[index]);
        //发送首次握手U帧0x68, 0x04, 0x07, 0x00, 0x00, 0x00
        CS104_Connection_sendStartDT(g_con[index]);
    }
    else  //如果连接到服务器失败
    {
        IEC104_DEBUG_PRINT("Connected to %s failed!\n",server_ip_tbl[index]);
        CS104_Connection_destroy(g_con[index]);
        g_con[index] = NULL;
        free(p_tmp_index);
    }
}

void
printCP56Time2a(CP56Time2a time)
{
    IEC104_DEBUG_PRINT("%02i:%02i:%02i %02i/%02i/%04i", CP56Time2a_getHour(time),
                             CP56Time2a_getMinute(time),
                             CP56Time2a_getSecond(time),
                             CP56Time2a_getDayOfMonth(time),
                             CP56Time2a_getMonth(time),
                             CP56Time2a_getYear(time) + 2000);
}

/* Callback handler to log sent or received messages (optional) */
static void
slaveRawMessageHandler(void* parameter, IMasterConnection conneciton, uint8_t* msg, int msgSize, bool sent)
{
    if (sent)
    {
    	printf("slave SEND: ");

        int i;
        for (i = 0; i < msgSize; i++) {
            printf("%02x ", msg[i]);
        }
        printf("\r\n");
    }  
    else
    {
    	printf("slave RCVD: ");
        int i;
        for (i = 0; i < msgSize; i++) {
            printf("%02x ", msg[i]);
        }
        printf("\r\n");
    }

}

static bool
clockSyncHandler (void* parameter, IMasterConnection connection, CS101_ASDU asdu, CP56Time2a newTime)
{
	IEC104_DEBUG_PRINT("Process time sync command with time ");
	printCP56Time2a(newTime);
	IEC104_DEBUG_PRINT("\n");
	
	sdk_rtc_t rtc_time;
	sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
	printf("system time one:%02i:%02i:%02i (%02i)%02i/%02i/%04i", rtc_time.tm_hour,
                         rtc_time.tm_min,
                         rtc_time.tm_sec,
                         rtc_time.tm_weekday,
                         rtc_time.tm_day,
                         rtc_time.tm_mon,
                         rtc_time.tm_year+2000);
	printf("\n");
	
	/* Set time for ACT_CON message */
//	CP56Time2a_setFromMsTimestamp(newTime, Hal_getTimeInMs());
	//CP56Time2a_setFromMsTimestamp(newTime, newSystemTimeInMs);

	/* update system time here */
	system_time_update(newTime);
	sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
	printf("system time two:%02i:%02i:%02i (%02i)%02i/%02i/%04i", rtc_time.tm_hour,
                         rtc_time.tm_min,
                         rtc_time.tm_sec,
                         rtc_time.tm_weekday,
                         rtc_time.tm_day,
                         rtc_time.tm_mon,
                         rtc_time.tm_year+2000);
	printf("\n");
	return true;
}

static bool handle_telematic_info(IMasterConnection connection)
{
    InformationObject io = NULL;
    CS101_ASDU newAsdu = NULL;
    telematic_data_t *p_telematic_data = NULL;
    uint8_t *p_data8 = NULL;
    uint16_t i = 0;
    uint8_t j = 0;
    uint32_t data_num;
    uint8_t value = 0;
    int32_t addr = 0;
    uint8_t temp;

    CS101_AppLayerParameters alParams = IMasterConnection_getApplicationLayerParameters(connection);
    p_telematic_data = sdk_shm_telematic_data_get();

    //CSU系统故障信息
    p_data8 = (uint8_t *)(&(p_telematic_data->csu_system_fault_info[0]));
    data_num = 0;
    for(i = 0; i < CSU_SYSTEM_FAULT_LEN_BYTE; i++)
    {
        if(newAsdu == NULL)
        {
            newAsdu = CS101_ASDU_create(alParams, false, CS101_COT_INTERROGATED_BY_STATION,
                                                0, 1, false, false);
            if(newAsdu == NULL)
            {
                printf("CS101_ASDU_create failed\n");
                return false;
            }
        }
        for (j = 0; j < 8; j++)
        {
            addr = (i * 8) + j + YX_SYS_START_ADDR;
            value = (*(p_data8 + i) >> j) & 0x01;
            io = (InformationObject)SinglePointInformation_create(NULL, addr, value, IEC60870_QUALITY_GOOD);
            CS101_ASDU_addInformationObject(newAsdu, io);
            InformationObject_destroy(io);
            data_num += 1;
            if((data_num % 56) == 0)  //三个IOA+一个值，一个遥信占据四个字节
            {
                IMasterConnection_sendASDU(connection, newAsdu);
                CS101_ASDU_destroy(newAsdu);
                newAsdu = NULL;
            }
        }
    }
    if(newAsdu != NULL)
    {
        IMasterConnection_sendASDU(connection, newAsdu);
        CS101_ASDU_destroy(newAsdu);
        newAsdu = NULL;
    }

    //CSU系统汇流柜（状态信息）0x31~0x80
   // printf("GSYSTE：%d\n", g_system_status);
    temp = p_telematic_data->combiner_cabinet_system_status_info[0];
    if((g_system_status == 1) || (g_system_status == 2)) //CMU系统状态是1或2
    {
        temp |= 0x01;
    }
    else
    {
        temp &= 0xFE;
    }
    newAsdu = CS101_ASDU_create(alParams, false, CS101_COT_INTERROGATED_BY_STATION,
                                                0, 1, false, false);
    if(newAsdu == NULL)
    {
        printf("CS101_ASDU_create failed\n");
        return false;
    }
    for(i = 0; i < 8; i++)
    {
        addr = i + 0x31;
        value = (temp >> i) & 0x01;
        io = (InformationObject)SinglePointInformation_create(NULL, addr, value, IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);
        InformationObject_destroy(io);
    }

    IMasterConnection_sendASDU(connection, newAsdu);
    CS101_ASDU_destroy(newAsdu);
    newAsdu = NULL;

    p_data8 = (uint8_t *)(&p_telematic_data->combiner_cabinet_system_status_info[1]);
    data_num = 0;
    for(i = 0; i < COMBINER_CABINET_SYSTEM_STATUS_LEN_BYTE; i++)
    {
        if(newAsdu == NULL)
        {
            newAsdu = CS101_ASDU_create(alParams, false, CS101_COT_INTERROGATED_BY_STATION,
                                                0, 1, false, false);
            if(newAsdu == NULL)
            {
                printf("CS101_ASDU_create failed\n");
                return false;
            }
        }
        for (j = 0; j < 8; j++)
        {
            addr = (i * 8) + j + 0x39;
            value = (*(p_data8 + i) >> j) & 0x01;
            io = (InformationObject)SinglePointInformation_create(NULL, addr, value, IEC60870_QUALITY_GOOD);
            CS101_ASDU_addInformationObject(newAsdu, io);
            InformationObject_destroy(io);
            data_num += 1;
            if((data_num % 56) == 0)  //三个IOA+一个值，一个遥信占据四个字节
            {
                IMasterConnection_sendASDU(connection, newAsdu);
                CS101_ASDU_destroy(newAsdu);
                newAsdu = NULL;
            }
        }
    }
    if(newAsdu != NULL)
    {
        IMasterConnection_sendASDU(connection, newAsdu);
        CS101_ASDU_destroy(newAsdu);
        newAsdu = NULL;
    }
    
    //CSU系统汇流柜（故障信息）
    data_num = 0;
    p_data8 = (uint8_t *)(&p_telematic_data->combiner_cabinet_system_fault_info[0]);
    for(i = 0; i < COMBINER_CABINET_SYSTEM_FAULT_LEN_BYTE; i++)
    {
        if(newAsdu == NULL)
        {
            newAsdu = CS101_ASDU_create(alParams, false, CS101_COT_INTERROGATED_BY_STATION,
                                                0, 1, false, false);
            if(newAsdu == NULL)
            {
                printf("CS101_ASDU_create failed\n");
                return false;
            }
        }
        for (j = 0; j < 8; j++)
        {
            addr = (i * 8) + j + 0x81;
            value = (*(p_data8 + i) >> j) & 0x01;
            io = (InformationObject)SinglePointInformation_create(NULL, addr, value, IEC60870_QUALITY_GOOD);
            CS101_ASDU_addInformationObject(newAsdu, io);
            InformationObject_destroy(io);
            data_num += 1;
            if((data_num % 56) == 0)  //三个IOA+一个值，一个遥信占据四个字节
            {
                IMasterConnection_sendASDU(connection, newAsdu);
                CS101_ASDU_destroy(newAsdu);
                newAsdu = NULL;
            }
        }
    }
    if(newAsdu != NULL)
    {
        IMasterConnection_sendASDU(connection, newAsdu);
        CS101_ASDU_destroy(newAsdu);
        newAsdu = NULL;
    }
    memcpy(&g_telematic_data, p_telematic_data, sizeof(telematic_data_t)); //缓存一份作为变化之前的值
    return true;
}

//处理遥测数据
static bool handle_telemetry_upload_info(const CS101_CauseOfTransmission cot)
{   
    uint8_t i;
    int16_t *p_data;
    int32_t *p_data_32;
    CS101_ASDU newAsdu = NULL;
    InformationObject io = NULL;
    uint32_t ioa;  //IOA
    telemetry_data_t *p_telemetry_data = NULL;

    p_telemetry_data = sdk_shm_telemetry_data_get();
    internal_shared_data_t *internal_shared_data = internal_shared_data_get();
    /*基本信息(地址范围0x4001~0x4200)*/
    newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
    if(newAsdu == NULL)
    {
        printf("CS101_ASDU_create failed\n");
        return false;
    }
    /*CSU系统汇流柜硬件版本号*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4001, (p_telemetry_data->sys_version_telemetry_info.hardware_version_number & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*通信协议版本号*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4002, (p_telemetry_data->sys_version_telemetry_info.communication_protocol_version_number & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);

    p_data = (int16_t *)(&p_telemetry_data->sys_version_telemetry_info.sn_version_number);
    for (i = 0; i < 11; i++)
    {
        ioa = 0x4003 + i;
        // 注意要调整字节序
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, htons(*(p_data + i)), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
    }
    /*MCU1软件版本号低16位*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x400E, (p_telemetry_data->sys_version_telemetry_info.mcu1_software_version_number & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*MCU1软件版本号高16位*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x400F, ((p_telemetry_data->sys_version_telemetry_info.mcu1_software_version_number >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*MCU1BOOT版本号低16位*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4010, (p_telemetry_data->sys_version_telemetry_info.mcu1_boot_version_number & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*MCU1BOOT版本号高16位*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4011, ((p_telemetry_data->sys_version_telemetry_info.mcu1_boot_version_number >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*MCU1CORE版本号低16位*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4012, (p_telemetry_data->sys_version_telemetry_info.mcu1_core_version_number & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*MCU1CORE版本号高16位*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4013, ((p_telemetry_data->sys_version_telemetry_info.mcu1_core_version_number >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*MCU2软件版本号低16位*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4014, (p_telemetry_data->sys_version_telemetry_info.mcu2_software_version_number & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*MCU2软件版本号高16位*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4015, ((p_telemetry_data->sys_version_telemetry_info.mcu2_software_version_number >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*MCU2BOOT版本号低16位*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4016, (p_telemetry_data->sys_version_telemetry_info.mcu2_boot_version_number & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*MCU2BOOT版本号高16位*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4017, ((p_telemetry_data->sys_version_telemetry_info.mcu2_boot_version_number >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*MCU2CORE版本号低16位*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4018, (p_telemetry_data->sys_version_telemetry_info.mcu2_core_version_number & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*MCU2CORE版本号低16位*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4019, ((p_telemetry_data->sys_version_telemetry_info.mcu2_core_version_number >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*系统额定功率*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x401A, 1250, IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*最大视在功率*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x401B, 1375, IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*最大有功功率*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x401C, 1375, IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*最大无功功率*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x401D, 1250, IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*外部通信协议版本号*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x401F, htons(p_telemetry_data->sys_version_telemetry_info.ext_communication_protocol_version), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    #if 0
    p_data = (int16_t *)(&p_telemetry_data->sys_version_telemetry_info.system_power);
    for(i = 0; i < 4; i++)
    {
        ioa = 0x401A + i;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
    }
    #endif
    CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
    CS101_ASDU_destroy(newAsdu);
    usleep(50);

    newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
    if(newAsdu == NULL)
    {
        printf("CS101_ASDU_create failed\n");
        return false;
    }
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x401E, p_telemetry_data->sys_version_telemetry_info.csu_sys_state, IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
    CS101_ASDU_destroy(newAsdu);
    usleep(50);
    
    /*MCU2实时数据(地址范围0x4201~0x4300)*/
    p_data = (int16_t *)(&p_telemetry_data->sys_cabinet_telemetry_info.system_status);
    newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
    if(newAsdu == NULL)
    {
        printf("CS101_ASDU_create failed\n");
        return false;
    }
    for (i = 0; i < 14; i++)
    {
        ioa = 0x4201 + i;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
    }
    CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
    CS101_ASDU_destroy(newAsdu);
    usleep(50);

    /*汇流柜交流侧有功功率（低16位）*/
    newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
    if(newAsdu == NULL)
    {
        printf("CS101_ASDU_create failed\n");
        return false;
    }

    /*汇流柜交流侧有功功率（低16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x420F, (p_telemetry_data->sys_cabinet_telemetry_info.ac_side_active_power & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*汇流柜交流侧有功功率（高16位））*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4210, ((p_telemetry_data->sys_cabinet_telemetry_info.ac_side_active_power >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*汇流柜交流侧无功功率（低16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4211, (p_telemetry_data->sys_cabinet_telemetry_info.ac_side_reactive_power & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*汇流柜交流侧无功功率（高16位））*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4212, ((p_telemetry_data->sys_cabinet_telemetry_info.ac_side_reactive_power >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*汇流柜交流侧视在功率（低16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4213, (p_telemetry_data->sys_cabinet_telemetry_info.ac_side_phase_view_power & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*汇流柜交流侧视在功率（高16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4214, ((p_telemetry_data->sys_cabinet_telemetry_info.ac_side_phase_view_power >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*汇流柜当日充电量（低16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4215, (p_telemetry_data->sys_cabinet_telemetry_info.daily_charging_capacity & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*汇流柜当日充电量（高16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4216, ((p_telemetry_data->sys_cabinet_telemetry_info.daily_charging_capacity >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*汇流柜当日放电量（低16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4217, (p_telemetry_data->sys_cabinet_telemetry_info.daily_discharging_capacity & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*汇流柜当日放电量（高16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4218, ((p_telemetry_data->sys_cabinet_telemetry_info.daily_discharging_capacity >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*汇流柜总充电量（低16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4219, (p_telemetry_data->sys_cabinet_telemetry_info.total_charging_capacity & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*汇流柜总充电量（高16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x421A, ((p_telemetry_data->sys_cabinet_telemetry_info.total_charging_capacity >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*汇流柜总放电量（低16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x421B, (p_telemetry_data->sys_cabinet_telemetry_info.total_discharging_capacity & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*汇流柜总放电量（高16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x421C, ((p_telemetry_data->sys_cabinet_telemetry_info.total_discharging_capacity >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*汇流柜总运行时间（低16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x421D, (p_telemetry_data->sys_cabinet_telemetry_info.total_run_time & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*汇流柜总运行时间（高16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x421E, ((p_telemetry_data->sys_cabinet_telemetry_info.total_run_time >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);

    p_data = (int16_t *)(&p_telemetry_data->sys_cabinet_telemetry_info.ac_side_phase_vol_r);
    for(i = 0; i < 12; i++)
    {
        ioa = 0x421F + i;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
    }

    /*防逆流电表功率（低16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x422B, (p_telemetry_data->sys_cabinet_telemetry_info.anti_reflux_power & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*防逆流电表功率（高16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x422C, ((p_telemetry_data->sys_cabinet_telemetry_info.anti_reflux_power >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);

    CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
    CS101_ASDU_destroy(newAsdu);
    usleep(50);

    newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
    if(newAsdu == NULL)
    {
        printf("CS101_ASDU_create failed\n");
        return false;
    }
    p_data = (int16_t *)(&internal_shared_data->total_realtime_energy.meter_data.active_power_a);
    for(i = 0; i < 9; i++)
    {
        ioa = 0x422D + i;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
    }
    /*计量电表1总视在功率*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4236, (internal_shared_data->total_realtime_energy.meter_data.view_power_total & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*计量电表1总视在功率*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4237, ((internal_shared_data->total_realtime_energy.meter_data.view_power_total >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    p_data = (int16_t *)(&internal_shared_data->total_realtime_energy.meter_data.power_factor_a);
    for(i = 0; i < 4; i++)
    {
        ioa = 0x4238 + i;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
    }
    CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
    CS101_ASDU_destroy(newAsdu);
    usleep(50);

    newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
    if(newAsdu == NULL)
    {
        printf("CS101_ASDU_create failed\n");
        return false;
    }
    p_data_32 = (int32_t *)(&internal_shared_data->total_realtime_energy.meter_data.positive_reactive_energy_total);
    for(i = 0; i < 10; i ++)
    {
        ioa = 0x423C + (i * 2);
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, (*(p_data_32 + i) & 0xFFFF), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa + 1, ((*(p_data_32 + i) >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
    }
    p_data = (int16_t *)(&internal_shared_data->total_realtime_energy.meter_data.volt_a);
    for(i = 0; i < 6; i++)
    {
        ioa = 0x4250 + i;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
    }
    CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
    CS101_ASDU_destroy(newAsdu);
    usleep(50);

    newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
    if(newAsdu == NULL)
    {
        printf("CS101_ASDU_create failed\n");
        return false;
    }
    p_data_32 = (int32_t *)(&internal_shared_data->total_realtime_energy.meter_data.active_power_total);
    for(i = 0; i < 12; i++)
    {
        ioa = 0x4256 + (i * 2);
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, (*(p_data_32 + i) & 0xFFFF), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa + 1, ((*(p_data_32 + i) >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
    }
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x426E, internal_shared_data->total_realtime_energy.meter_data.freq, IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);

    /*汇流柜除湿器温度*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x426F, p_telemetry_data->sys_cabinet_telemetry_info.dry_temp, IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*汇流柜除湿器湿度*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4270, p_telemetry_data->sys_cabinet_telemetry_info.dry_humidity, IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);

    /*光伏电表总功率（低16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4271, (p_telemetry_data->sys_cabinet_telemetry_info.photo_meter_power & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*光伏电表总功率（高16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4272, ((p_telemetry_data->sys_cabinet_telemetry_info.photo_meter_power >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);

    sys_capacity_t *p_sys_capacity = &sdk_shm_get()->internal_shared_data.sys_capacity;

    /*光伏当日发电量（低16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4273, (p_sys_capacity->photo_meter_daily_capacity & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*光伏当日发电量（高16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4274, ((p_sys_capacity->photo_meter_daily_capacity >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);

    /*光伏总发电量（低16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4275, (p_sys_capacity->photo_meter_total_capacity & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*光伏总发电量（高16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4276, ((p_sys_capacity->photo_meter_total_capacity >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);

    /*电网当日输入电能（低16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4277, (p_sys_capacity->grid_daily_input_capacity & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*电网当日输入电能（高16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4278, ((p_sys_capacity->grid_daily_input_capacity >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    
    /*电网总输入电能（低16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4279, (p_sys_capacity->grid_total_input_capacity & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*电网总输入电能（高16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x427A, ((p_sys_capacity->grid_total_input_capacity >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    
    /*电网当日输出电能（低16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x427B, (p_sys_capacity->grid_daily_output_capacity & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*电网当日输出电能（高16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x427C, ((p_sys_capacity->grid_daily_output_capacity >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);

    /*电网总输出电能（低16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x427D, (p_sys_capacity->grid_total_output_capacity & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*电网总输出电能（高16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x427E, ((p_sys_capacity->grid_total_output_capacity >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    
    /*负载功率（低16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x427F, (p_sys_capacity->load_power & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*负载功率（高16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4280, ((p_sys_capacity->load_power >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    
    /*负载当日耗电量（低16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4281, (p_sys_capacity->load_daily_consume_capacity & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*负载当日耗电量（高16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4282, ((p_sys_capacity->load_daily_consume_capacity >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);

    /*负载总耗电量（低16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4283, (p_sys_capacity->load_total_consume_capacity & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*负载总耗电量（高16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4284, ((p_sys_capacity->load_total_consume_capacity >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);

    /*储能柜 当日放电电能（低16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4285, (p_sys_capacity->es_daily_discharge_capacity & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*储能柜 当日放电电能（高16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4286, ((p_sys_capacity->es_daily_discharge_capacity >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    
    /*储能柜 当日充电电能（低16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4287, (p_sys_capacity->es_daily_charge_capacity & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*储能柜 当日充电电能（高16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4288, ((p_sys_capacity->es_daily_charge_capacity >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    
    /*储能柜 总放电电能（低16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x4289, (p_sys_capacity->es_total_discharge_capacity & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*储能柜 总放电电能（高16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x428A, ((p_sys_capacity->es_total_discharge_capacity >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    
    /*储能柜 总充电电能（低16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x428B, (p_sys_capacity->es_total_charge_capacity & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);
    /*储能柜 总充电电能（高16位）*/
    io = (InformationObject) MeasuredValueShort_create(NULL, 0x428C, ((p_sys_capacity->es_total_charge_capacity >> 16) & 0xFFFF), IEC60870_QUALITY_GOOD);
    CS101_ASDU_addInformationObject(newAsdu, io);  
    InformationObject_destroy(io);

    CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
    CS101_ASDU_destroy(newAsdu);
    usleep(50);

    return true;    
}

static bool handle_constant_upload_info(const CS101_CauseOfTransmission cot)
{
    uint16_t i;
    int16_t *p_data;
    CS101_ASDU newAsdu = NULL;
    InformationObject io = NULL;
    uint32_t ioa;  //IOA
    uint8_t data_num;
    constant_parameter_data_t *p_constant_parameter = NULL;
   
    p_constant_parameter = sdk_shm_constant_parameter_data_get();

    /*CSU系统汇流柜 系统 (地址范围0x8001~0x8040)*/
    newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
    if(newAsdu == NULL)
    {
        printf("CS101_ASDU_create failed\n");
        return false;
    }
    p_data = (int16_t *)(&p_constant_parameter->sys_param_data.storage_duration_operation_data);
    for (i = 0; i < 6; i++)
    {
        ioa = 0x8001 + i;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
    }
    CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
    CS101_ASDU_destroy(newAsdu);
    usleep(50);

    /*CSU系统汇流柜 系统参数 （地址范围0x8041-0x8100）*/
    newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
    if(newAsdu == NULL)
    {
        printf("CS101_ASDU_create failed\n");
        return false;
    }
    p_data = (int16_t *)(&p_constant_parameter->system_param.cabinet_param.active_power);
    for (i = 0; i < 30; i++)
    {
        ioa = 0x8041 + i;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
    }
    CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
    CS101_ASDU_destroy(newAsdu);
    usleep(50);

    /*CSU安规参数(文件) (地址范围0x8101-0x8400)*/
    data_num = 0;
    newAsdu = NULL;
    p_data = (int16_t *)(&p_constant_parameter->safety_param.group1[0]);
    for(i = 0; i < 576; i++)
    {
        if(newAsdu == NULL)
        {
            newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
            if(newAsdu == NULL)
            {
                printf("CS101_ASDU_create failed\n");
                return false;
            }
        }
    
        ioa = 0x8101 + i;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
        data_num += 1;
        if(data_num == 30)  //30*8 = 240,留下15个字节作为头部
        {
            CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
            CS101_ASDU_destroy(newAsdu);
            usleep(50);
            data_num = 0;
            newAsdu = NULL;
        }
    }
    if(newAsdu != NULL)  //残留部分
    {
        CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
        CS101_ASDU_destroy(newAsdu);
        usleep(50);
    }
   
    /*CSU EMS参数 (地址范围0x8401~0x8500)*/
    data_num = 0;
    newAsdu = NULL;
    p_data = (int16_t *)(&p_constant_parameter->ems_data.demand_resp_en);
    for(i = 0; i < 55; i++)
    {
        if(newAsdu == NULL)
        {
            newAsdu = CS101_ASDU_create(g_alParams, false, cot, 0, 1, false, false);
            if(newAsdu == NULL)
            {
                printf("CS101_ASDU_create failed\n");
                return false;
            }
        }
    
        ioa = 0x8401 + i;
        io = (InformationObject) MeasuredValueShort_create(NULL, ioa, *(p_data + i), IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);  
        InformationObject_destroy(io);
        data_num += 1;
        if(data_num == 30)  //30*8 = 240,留下15个字节作为头部
        {
            CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
            CS101_ASDU_destroy(newAsdu);
            usleep(50);
            data_num = 0;
            newAsdu = NULL;
        }
    }
    if(newAsdu != NULL)  //残留部分
    {
        CS104_Slave_enqueueASDU(g_slave, newAsdu);  //发送出去
        CS101_ASDU_destroy(newAsdu);
        usleep(50);
    }
  
    return true;
}

//响应总召唤
static bool interrogationHandler(void* parameter, IMasterConnection connection, CS101_ASDU asdu, uint8_t qoi)
{
	uint8_t index = 0;
	if(qoi != 20)
	{
		printf("qoi error\n");
		return false;
	}
	IMasterConnection_sendACT_CON(connection, asdu, false);     // 接收确认帧
    g_connect_flag = 0;
    handle_telematic_info(connection);   //CSU侧遥信
    handle_telemetry_upload_info(CS101_COT_INTERROGATED_BY_STATION);//CSU侧遥测
    handle_constant_upload_info(CS101_COT_INTERROGATED_BY_STATION); //CSU侧定值参数
    g_connect_flag = 1;

	for(index=0; index<MAX_SLAVE_COUNT; index++)
	{
		if(g_con[index] != NULL)
		{
			//按顺序发送总召唤68 0E 00 00 00 00 64 01 06 00 01 00 00 00 00 14
        	CS104_Connection_sendInterrogationCommand(g_con[index], CS101_COT_ACTIVATION, 1, IEC60870_QOI_STATION);
            g_last_conn_time = time(NULL); //客户端开始计时
            //修改了协议，不对上位机的总召唤进行处理
		}
	}
    IMasterConnection_sendACT_TERM(connection, asdu); // 结束确认帧

    return true;
}

//添加定值区与参数特征标识
static void param_add_sn_flag(CS101_StaticASDU self,uint16_t sn,uint8_t flag)
{
	IEC104_DEBUG_PRINT("sn=%d,flag=%d\n",sn,flag);
	/*定值区*/
	self->encodedData[self->asduHeaderLength++] = (uint8_t) (sn & 0xff);
	self->encodedData[self->asduHeaderLength++] = (uint8_t) ((sn>>8) & 0xff);
	/*参数特征*/
	self->encodedData[self->asduHeaderLength++] = flag;
	
    self->payload = self->encodedData + self->asduHeaderLength;
    IEC104_DEBUG_PRINT("asduHeaderLength=%d\n",self->asduHeaderLength);
}

static bool para_read_processing(void *parameter, IMasterConnection connection, CS101_ASDU asdu)
{
    uint8_t num = 0;
    bool flag = 0;
    ParaValue iom = NULL;
    uint8_t i;
    int32_t ioa = 0;
    int32_t ioa_new;
    uint8_t cmu_index = 0;
    uint8_t *payload = NULL;
    InformationObject io = NULL;
    constant_parameter_data_t *p_para_data = NULL;
    CS101_ASDU newAsdu = NULL;
    uint16_t obj_count = 0;
    int16_t *p_data = NULL;

    p_para_data = sdk_shm_constant_parameter_data_get();
    CS101_AppLayerParameters alParams = IMasterConnection_getApplicationLayerParameters(connection);

    num = CS101_ASDU_getNumberOfElements(asdu);
    flag = CS101_ASDU_isSequence(asdu);
    // 是否为全部参数读取
    if ((num == 0) && (flag == false))
    {
        printf("不支持一次性读取所有数据");
        return false;
    }

    for (i = 0; i < num; i++) 
    {
        iom = (ParaValue) CS101_ASDU_getElement(asdu, i);
        ioa = InformationObject_getObjectAddress((ParaValue) iom);  //信息地址
        InformationObject_destroy(iom); 

        if(ioa >= 0x8001 && ioa <= 0x8040)  //汇流柜系统
        {
            p_data = &(p_para_data->sys_param_data.storage_duration_operation_data) + (ioa - 0x8001);
            io = (InformationObject)ParaValue_create(NULL, ioa, *p_data, 33, 2);
        }

        if(ioa >= 0x8041 && ioa <= 0x8100)  //汇流柜系统参数
        {
            p_data = &(p_para_data->cabinet_param_data.active_power) + (ioa - 0x8041);
            io = (InformationObject)ParaValue_create(NULL, ioa, *p_data, 33, 2);
        }

        // if(ioa >= 0x8101 && ioa <= 0x8400) //安规参数
        // {
        //     p_data = &(p_para_data->safety_param.group1[0]) + (ioa - 0x8101);
        //     io = (InformationObject)ParaValue_create(NULL, ioa, *p_data, 33, 2);
        // }

        if(ioa >= 0x8401 && ioa <= 0x8500) //EMS参数
        {
            p_data = &(p_para_data->ems_data.demand_resp_en) + (ioa - 0x8401);
            io = (InformationObject)ParaValue_create(NULL, ioa, *p_data, 33, 2);
        }

        if(io != NULL)
        {
            if(newAsdu == NULL)
            {
                newAsdu = CS101_ASDU_create(alParams, false, CS101_COT_ACTIVATION_CON,
                    0, 1, false, false);
                param_add_sn_flag((CS101_StaticASDU)newAsdu, 1, 0);   
            }
            CS101_ASDU_addInformationObject(newAsdu, io); 
            InformationObject_destroy(io); 
            obj_count++;
            if ((obj_count % 25) == 0)	// 判断是否达为最大值，是否需要重新创建
            {
                IMasterConnection_sendASDU(connection, newAsdu);
                CS101_ASDU_destroy(newAsdu);
                newAsdu = NULL;
            }  
        }
    }
    //表示CSU部分有参数请求
    if(obj_count != 0)
    {
        if(newAsdu != NULL)
        {
            IMasterConnection_sendASDU(connection, newAsdu);
            CS101_ASDU_destroy(newAsdu);
        }
        return true;
    }
    //以下是发给CMU的
    payload = CS101_ASDU_getPayload(asdu);
    for (i = 0; i < num; i++) 
    {
        iom = (ParaValue) CS101_ASDU_getElement(asdu, i);
        ioa = InformationObject_getObjectAddress((ParaValue) iom);  //信息地址
        InformationObject_destroy(iom);
    
        if(ioa >= 0x8101 && ioa <= 0x8400)  // 安规参数
        {
            cmu_index = 0;
            ioa_new = ioa;
        }
        else if(ioa >= 0x8701 && ioa <= 0x8940)  //MCU1的定值参数
        {
            cmu_index = 0;
            ioa_new = ioa;
        }
        else if((ioa >= 0x8A01) && (ioa <= 0x8C40))//MCU2的定值参数
        {
            printf("ioa:%x\n", ioa);
            cmu_index = 1;
            ioa_new = ioa - 0x300;
        }
        else if(ioa >= 0x8D01 && ioa <= 0x8F40)//MCU3的定值参数
        {
            cmu_index = 2;
            ioa_new = ioa - 0x600;
        }
        else if(ioa >= 0x9001 && ioa <= 0x9240)//MCU4的定值参数
        {
            cmu_index = 3;
            ioa_new = ioa - 0x900;
        }
        else if(ioa >= 0x9301 && ioa <= 0x9540)//MCU5的定值参数
        {
            cmu_index = 4;
            ioa_new = ioa - 0xC00;
        }
        else if(ioa >= 0x9601 && ioa <= 0x9840)//MCU6的定值参数
        {
            cmu_index = 5;
            ioa_new = ioa - 0xF00;
        }
        else
        {
            printf("addr error!\n");
            return false;
        }

        payload[2+i*3] = (uint8_t)(ioa_new & 0xff);  //最低位
        payload[2+i*3+1] = (uint8_t)((ioa_new/0x100) & 0xff);  //中间位
        payload[2+i*3+2] = (uint8_t)((ioa_new/0x10000) & 0xff);
    }
    if(g_con[cmu_index] != NULL)
    {
        return CS104_Connection_sendASDU(g_con[cmu_index], asdu);
    }
    return false;
}

static bool para_write_processing(void *parameter, IMasterConnection connection, CS101_ASDU asdu)
{
    uint8_t num = 0;
    bool flag = 0;
    uint8_t i;
    InformationObject io;
    int32_t ioa = 0;
    int32_t ioa_new;
    uint16_t value = 0;
    uint8_t index = 0;
    uint8_t *payload;
    uint8_t cmu_index;

    para_value_record_t *p_para_value_record = &g_para_value_record;

    printf("===============================>para write....\n");
    if(CS101_ASDU_getCOT(asdu) == CS101_COT_ACTIVATION) //主站发送原因为6
    {
        num = CS101_ASDU_getNumberOfElements(asdu);
        flag = CS101_ASDU_isSequence(asdu);
        if ((num == 0) && (flag == 0))  //表示这是一个参数固化命令
        {
            for(i=0; i<MAX_SLAVE_COUNT; i++)
            {
                if(g_con[i] != NULL)
                {
                    CS104_Connection_sendASDU(g_con[i], asdu); //分别给各个子站下发参数固化命令
                }
            }
            //para_sync();
            CS101_ASDU_setCOT(asdu, CS101_COT_ACTIVATION_CON);  //返回给主站上位机一个激活确认
            IMasterConnection_sendASDU(connection, asdu);
            return true;
        }
        IEC104_DEBUG_PRINT("\n********参数预置*********\n");
        memset(p_para_value_record, 0, sizeof(para_value_record_t));
        payload = CS101_ASDU_getPayload(asdu);
        for (i = 0; i < num; i++)
        {
            io = CS101_ASDU_getElement(asdu, i);
            ioa = InformationObject_getObjectAddress(io);
            if (((ioa >= 0x8001) && (ioa < 0x8438))
                && ( !((ioa >= PARA_SAFETY_START_ADDR) && (ioa < PARA_SAFETY_END_ADDR)) )  ) //汇流柜参数 且 不在安规参数范围内
            {
                value = ParaValue_getValue((ParaValue)io);
                index = p_para_value_record->num;
                p_para_value_record->para_value[index].addr = ioa;
                p_para_value_record->para_value[index].value = value;
                p_para_value_record->num++;
            }
            else
            {
                if((ioa >= PARA_SAFETY_START_ADDR) && (ioa < PARA_SAFETY_END_ADDR)) 
                {
                    cmu_index = 0;
                    ioa_new = ioa;
                } 
                else if(ioa >= 0x8701 && ioa <= 0x8940)  //MCU1的定值参数
                {
                    cmu_index = 0;
                    ioa_new = ioa;
                }
                else if(ioa >= 0x8A01 && ioa <= 0x8C40)//MCU2的定值参数
                {
                    cmu_index = 1;
                    ioa_new = ioa - 0x300;
                }
                else if(ioa >= 0x8D01 && ioa <= 0x8F40)//MCU3的定值参数
                {
                    cmu_index = 2;
                    ioa_new = ioa - 0x600;
                }
                else if(ioa >= 0x9001 && ioa <= 0x9240)//MCU4的定值参数
                {
                    cmu_index = 3;
                    ioa_new = ioa - 0x900;
                }
                else if(ioa >= 0x9301 && ioa <= 0x9540)//MCU5的定值参数
                {
                    cmu_index = 4;
                    ioa_new = ioa - 0xC00;
                }
                else if(ioa >= 0x9601 && ioa <= 0x9840)//MCU6的定值参数
                {
                    cmu_index = 5;
                    ioa_new = ioa - 0xF00;
                }
                else
                {
                    printf("addr error!\n");
                    return false;
                }

                payload[3+i*7] = (uint8_t)(ioa_new & 0xff);  //最低位
                payload[3+i*7+1] = (uint8_t)((ioa_new/0x100) & 0xff);  //中间位
                payload[3+i*7+2] = (uint8_t)((ioa_new/0x10000) & 0xff);
                InformationObject_destroy(io);

                if(g_con[cmu_index] != NULL)
                {
                    CS104_Connection_sendASDU(g_con[cmu_index], asdu);
                }
            }
        }

        CS101_ASDU_setCOT(asdu, CS101_COT_ACTIVATION_CON);  //返回给主站上位机一个激活确认
        IMasterConnection_sendASDU(connection, asdu);
        return true;
    }
    else if  (CS101_ASDU_getCOT(asdu) == CS101_COT_DEACTIVATION)
	{
		//参数撤销
		IEC104_DEBUG_PRINT("\n********参数撤销*********\n");
        for(i=0; i<MAX_SLAVE_COUNT; i++)
        {
            if(g_con[i] != NULL)
            {
                CS104_Connection_sendASDU(g_con[i], asdu); //分别给各个子站下发参数固化命令
            }
        }
        memset(p_para_value_record, 0, sizeof(para_value_record_t));
		CS101_ASDU_setCOT(asdu, CS101_COT_DEACTIVATION_CON);
		IMasterConnection_sendASDU(connection, asdu);			 
	}
	else
	{
		IEC104_DEBUG_PRINT("\n********未识别*********\n");
		CS101_ASDU_setCOT(asdu, CS101_COT_UNKNOWN_COT);
		IMasterConnection_sendASDU(connection, asdu);
	}		

    return true;  
}

static int32_t sdk_system_cmd(int8_t * cmd)
{
    FILE *fp = NULL;

    if((fp=popen((char *)cmd, "r")) == NULL)
    {
        return -1;
    }
    pclose(fp);

    return 0;
}

static bool remote_control_processing(void *parameter, IMasterConnection connection, CS101_ASDU asdu)
{
    InformationObject io;
    int32_t ioa = 0;
    int32_t ioa_new;
    uint8_t *payload;
    SingleCommand sc = NULL;
    web_control_info_t *p_web_data = shm_web_control_info_get();

    io = CS101_ASDU_getElement(asdu, 0);
    if(io == NULL)
    {
        return false;
    }
    ioa = InformationObject_getObjectAddress(io);
    sc = (SingleCommand)io;
    InformationObject_destroy(io);
    if(ioa == 0x6001)  //远程开关机
    {
        printf("CSU 遥控=====>远程开关机\n");
        payload = CS101_ASDU_getPayload(asdu);
        ioa_new = 0x6011;
        payload[0] = (uint8_t)(ioa_new & 0xff);  //最低位
        payload[1] = (uint8_t)((ioa_new/0x100) & 0xff);  //中间位
        payload[2] = (uint8_t)((ioa_new/0x10000) & 0xff);
        if(g_con[0] != NULL)
        {
            CS104_Connection_sendASDU(g_con[0], asdu);  //遥控下发
        }
        if (SingleCommand_getState(sc))  //开机
        {
            BIT_SET(p_web_data->control_cmd_flag, 1);
            p_web_data->control_cmd_data.run_state = 1;
            BIT_SET( p_web_data->csu_comb_web_set_flag, 1 );
        }
        else   //关机
        {
            BIT_SET(p_web_data->control_cmd_flag, 1);
            p_web_data->control_cmd_data.run_state = 0;    
            BIT_SET( p_web_data->csu_comb_web_set_flag, 2 );
        }
    }
    if(ioa == 0x6002)  //故障复位
    {
        if (SingleCommand_isSelect(sc) == true) // 遥控选择
        {
            printf("CSU 遥控=====>故障复位,遥控选择...\n");
        }
        else
        {
            printf("CSU 遥控=====>故障复位,遥控执行...[%d]\n", SingleCommand_getState(sc));
            payload = CS101_ASDU_getPayload(asdu);
            ioa_new = 0x6013;
            payload[0] = (uint8_t)(ioa_new & 0xff);  //最低位
            payload[1] = (uint8_t)((ioa_new/0x100) & 0xff);  //中间位
            payload[2] = (uint8_t)((ioa_new/0x10000) & 0xff);
            if(g_con[0] != NULL)
            {
                CS104_Connection_sendASDU(g_con[0], asdu);  //遥控下发
            }
        }
        #if 0
        payload = CS101_ASDU_getPayload(asdu);
        ioa_new = 0x6013;
        payload[0] = (uint8_t)(ioa_new & 0xff);  //最低位
        payload[1] = (uint8_t)((ioa_new/0x100) & 0xff);  //中间位
        payload[2] = (uint8_t)((ioa_new/0x10000) & 0xff);
        if(g_con[0] != NULL)
        {
            CS104_Connection_sendASDU(g_con[0], asdu);  //遥控下发
        }
        #endif
    }
    if(ioa == 0x6003)  // 清除历史数据
    {
        printf("CSU 遥控=====>清除历史数据\n");
        payload = CS101_ASDU_getPayload(asdu);
        ioa_new = 0x6015;
        payload[0] = (uint8_t)(ioa_new & 0xff);  //最低位
        payload[1] = (uint8_t)((ioa_new/0x100) & 0xff);  //中间位
        payload[2] = (uint8_t)((ioa_new/0x10000) & 0xff);
        if(g_con[0] != NULL)
        {
            CS104_Connection_sendASDU(g_con[0], asdu);  //遥控下发
        }
        if (SingleCommand_getState(sc))  // 清除历史数据
        {
            printf("[%s:%d] web clear data \n",__func__, __LINE__);
            system("rm -rf /user/data/event/*;rm -rf /user/data/power/*;rm -rf /user/data/energy/*;");
            sdk_system_cmd((int8_t *)"sync");
            sleep(1);
            sdk_system_cmd((int8_t *)"reboot -f");
        }
    }
    if(ioa == 0x6005)  //汇流柜分励脱扣器断开
    {
        printf("CSU 遥控=====>汇流柜分励脱扣器断开\n");
        if (SingleCommand_getState(sc))  //开机
        {
            BIT_SET(p_web_data->control_cmd_flag, 4);
        }
    }
    if(ioa == 0x6006)  //汇流柜风扇
    {
        printf("CSU 遥控=====>风扇\n");
        if (SingleCommand_getState(sc))  //开机
        {
            BIT_SET(p_web_data->control_cmd_flag, 5);
        }
        else
        {
            BIT_CLR(p_web_data->control_cmd_flag, 5);
        }
    }
    payload = CS101_ASDU_getPayload(asdu);
    payload[0] = (uint8_t)(ioa & 0xff);  //最低位
    payload[1] = (uint8_t)((ioa/0x100) & 0xff);  //中间位
    payload[2] = (uint8_t)((ioa/0x10000) & 0xff);
    CS101_ASDU_setCOT(asdu, CS101_COT_ACTIVATION_CON);
    // CS101_ASDU_setCOT(asdu, CS101_COT_ACTIVATION_TERMINATION);
    IMasterConnection_sendASDU(connection, asdu);
    usleep(50);
    CS101_ASDU_setCOT(asdu, CS101_COT_ACTIVATION_TERMINATION);
    IMasterConnection_sendASDU(connection, asdu);

    return true;
}

static bool file_processing(void *parameter, IMasterConnection connection, CS101_ASDU asdu)
{
    uint8_t ctrl_id = 0;
    FileIdentify file_obj = NULL;
    CS101_ASDU newAsdu = NULL;
    InformationObject io = NULL;
    file_activate_con_t file_activate_con = {0};
    file_data_trs_con_t file_data_trs_con = {0};
    uint8_t flag = 0;
	file_obj =	(FileIdentify) CS101_ASDU_getElement(asdu, 0);

    CS101_AppLayerParameters alParams = IMasterConnection_getApplicationLayerParameters(connection);
    ctrl_id = FileIdentify_getCtrlID(file_obj);
    printf("FileIdentify_getCtrlID=%d\n",ctrl_id);

    file_activate_con_t *p_file_activate_con = &file_activate_con;
    file_data_trs_con_t *p_file_data_trs_con = &file_data_trs_con;
    switch (ctrl_id)
    {
        case FILE_WRITE_ACTIVATE:
            // 返回是否可写的结果
            file_activate_con_get(asdu, p_file_activate_con);

            // 发送写数据激活确认
            newAsdu = CS101_ASDU_create(alParams, false, CS101_COT_ACTIVATION_CON,
                                        0, 1, false, false);
            io = (InformationObject)FileIdentify_create(NULL, 0, FILE_WEITE_ACTIVATE_CON, p_file_activate_con);
            CS101_ASDU_addInformationObject(newAsdu, io);

            InformationObject_destroy(io);
            IMasterConnection_sendASDU(connection, newAsdu);
            CS101_ASDU_destroy(newAsdu);
            break;
        
        case FILE_WRITE_DATA:
            printf("write data...\n");
			flag = FileIdentify_getFlag(file_obj, FILE_WRITE_DATA);
			if(0 != flag)
			{
				file_data_trs_set(asdu, p_file_data_trs_con);
			}
            newAsdu = CS101_ASDU_create(alParams, false, CS101_COT_ACTIVATION_CON,
                                        0, 1, false, false);
            io = (InformationObject)FileIdentify_create(NULL, 0, FILE_WRITE_DATA_CON, p_file_data_trs_con);
            CS101_ASDU_addInformationObject(newAsdu, io);

            InformationObject_destroy(io);
            IMasterConnection_sendASDU(connection, newAsdu);
            CS101_ASDU_destroy(newAsdu);

			if(0 == flag)
			{
				file_data_trs_set(asdu, p_file_data_trs_con);
			}
            break;

        default:

            CS101_ASDU_setCOT(asdu, CS101_COT_UNKNOWN_COT);
            IMasterConnection_sendASDU(connection, asdu);
            break;
    }
    return true;
}

static bool gnrx_power_set_processing(void *parameter, IMasterConnection connection, CS101_ASDU asdu)
{
    int32_t ioa = 0;
   // uint8_t *payload;
    InformationObject io = NULL;
    float32_t value = 0;
    uint8_t i;
    constant_parameter_data_t *p_para_data;
    system_param_t system_param;
    uint8_t done_flag;

    CS101_ASDU_setCOT(asdu, CS101_COT_ACTIVATION_CON);
    IMasterConnection_sendASDU(connection, asdu);

    memset(&system_param, 0, sizeof(system_param_t));
    p_para_data = sdk_shm_constant_parameter_data_get();
    if(p_para_data == NULL)
    {
        print_log("p_para_data is NULL");
        return false;
    }
    memcpy(&system_param, &p_para_data->system_param, sizeof(system_param_t));

    io = CS101_ASDU_getElement(asdu, 0);
    ioa = InformationObject_getObjectAddress(io);  //地址ASDU_50
    value = SetpointCommandShort_getValue((SetpointCommandShort)io);
    InformationObject_destroy(io); 
    done_flag = 0;

    if(ioa == 0x6201)
    {
        printf("==============>下发有功功率,value=%f\n", value);
        system_param.cabinet_param.active_power = (int16_t)value;
        for(i = 0; i < MAX_TRY_COUNT; i++)
        { 
            if( 0 == set_constant_data( FUNCID_SET_POWER, 
                                       (uint16_t*)&system_param.cabinet_param.active_power, 
                                       MEMBER_DAT_NUM_CAL(&system_param.cabinet_param.active_power, &system_param.cabinet_param.reactive_power)))
            {
                done_flag = 1;
                break;
            }
            usleep(200 * 1000);
        }
        if (done_flag == 1)
        {
            p_para_data->system_param.cabinet_param.active_power = (int16_t)value;
        }
        #if 0
        usleep(200 * 1000);
        set_constant_data(0x2001, (uint16_t*)&temp, sizeof(temp)/2);
        usleep(200 * 1000);
        set_constant_data(0x2001, (uint16_t*)&temp, sizeof(temp)/2);
        usleep(200 * 1000);
        set_constant_data(0x2001, (uint16_t*)&temp, sizeof(temp)/2);
        usleep(200 * 1000);
        set_constant_data(0x2001, (uint16_t*)&temp, sizeof(temp)/2);
        #endif
    }
    if(ioa == 0x6202)
    {
        printf("==============>下发无功功率,value=%f\n", value);
        system_param.cabinet_param.reactive_power = value;
        p_para_data->system_param.cabinet_param.reactive_power = value;
        set_constant_data( FUNCID_SET_POWER, (uint16_t*)&system_param.cabinet_param.active_power, 
                           MEMBER_DAT_NUM_CAL(&system_param.cabinet_param.active_power, &system_param.cabinet_param.reactive_power));
    }   
#if 0
    newAsdu = CS101_ASDU_create(alParams, false, CS101_COT_ACTIVATION_TERMINATION,
                                                    0, 1, false, false);
    if (newAsdu == NULL)
    {
        printf("create new asdu failed\n");
        return false;
    }
    IMasterConnection_sendASDU(connection, newAsdu);
    CS101_ASDU_destroy(newAsdu);
#endif
    return true;
}

//接收到遥控或者定值参数的命令
static bool
slaveAsduHandler(void* parameter, IMasterConnection connection, CS101_ASDU asdu)
{
    FileIdentify file_obj = NULL;
     IEC104_DEBUG_PRINT("RECVD ASDU type: %s(%i) elements: %i\n",
                       TypeID_toString(CS101_ASDU_getTypeID(asdu)),
                       CS101_ASDU_getTypeID(asdu),
                       CS101_ASDU_getNumberOfElements(asdu));
    if (CS101_ASDU_getTypeID(asdu) == P_SC_RD_1)    // 读取参数
    {
        IEC104_DEBUG_PRINT("\n measured scaled values  P_SC_RD_1: \n");
        para_read_processing(parameter, connection, asdu);
    }
    else if (CS101_ASDU_getTypeID(asdu) == P_SC_WT_1) //203主站参数预置命令
    {
        IEC104_DEBUG_PRINT(" measured scaled values (P_SC_WT_1):\n");
        para_write_processing(parameter, connection, asdu);
    }
    else if (CS101_ASDU_getTypeID(asdu) == C_SE_NC_1) //50---下发功率
    {
        IEC104_DEBUG_PRINT("power set (C_SE_NA_1):\n");
      //  g_connect_flag = 0;
        gnrx_power_set_processing(parameter, connection, asdu);  //读取遥测信息
       // g_connect_flag = 1;
    }
    else if (CS101_ASDU_getTypeID(asdu) == C_SC_NA_1)   // 遥控数据
    {
        IEC104_DEBUG_PRINT("received single command\n");
        remote_control_processing(parameter, connection, asdu);
    }
    else if(CS101_ASDU_getTypeID(asdu) == F_FR_NA_2)
    {
        IEC104_DEBUG_PRINT("   event of protection equipment (F_FR_NA_2):\n");
        file_obj =  (FileIdentify) CS101_ASDU_getElement(asdu, 0);
        IEC104_DEBUG_PRINT("FileIdentify_getDataType=%d\n",FileIdentify_getDataType(file_obj));
        if (FileIdentify_getDataType(file_obj) == 2)
        {
            // 文件传输逻辑处理
            file_processing(parameter, connection, asdu);
        }
        else
        {
            // 异常不处理
            CS101_ASDU_setCOT(asdu, CS101_COT_UNKNOWN_COT);
            IMasterConnection_sendASDU(connection, asdu);
        }
    }
    return true;
}

static bool connectionRequestHandler(void* parameter, const char* ipAddress)
{
    printf("New connection from %s\n", ipAddress);

    return true;
}

static void connectionEventHandler(void* parameter, IMasterConnection con, CS104_PeerConnectionEvent event)
{
    if (event == CS104_CON_EVENT_CONNECTION_OPENED) {
        printf("Connection opened (%p)\n", con);
    }
    else if (event == CS104_CON_EVENT_CONNECTION_CLOSED) {
        printf("Connection closed (%p)\n", con);
     //   g_connect_flag = 0;
    }
    else if (event == CS104_CON_EVENT_ACTIVATED) {
        printf("Connection activated (%p)\n", con);
    }
    else if (event == CS104_CON_EVENT_DEACTIVATED) {
        printf("Connection deactivated (%p)\n", con);
    }
}

static void handle_telematic_changed_info(CS104_Slave slave, CS101_AppLayerParameters alParams)
{
    InformationObject io = NULL;
    uint16_t i = 0;
    uint16_t j = 0;
    uint32_t addr = 0;
    uint8_t value = 0;
    uint8_t *p_data_now = NULL;
    uint8_t *p_data_last = NULL;
    telematic_data_t *p_telematic_data = NULL;
    CS101_ASDU newAsdu = NULL;
    uint8_t temp;

    p_telematic_data = sdk_shm_telematic_data_get();
    
    //监视CSU系统遥信变位
    p_data_now = (uint8_t *)(&p_telematic_data->csu_system_fault_info[0]);
    p_data_last = (uint8_t *)(&g_telematic_data.csu_system_fault_info[0]);

    for (i = 0; i < CSU_SYSTEM_FAULT_LEN_BYTE; i++)
    {
        for (j = 0; j < 8; j++)
        {
            if (((*(p_data_now + i) >> j) & 0x01) != ((*(p_data_last + i) >> j) & 0x01)) //遥信点位发生变化
            {
                addr = (i * 8) + j + YX_SYS_START_ADDR;
                value = (*(p_data_now + i) >> j) & 0x01;
                io = (InformationObject)SinglePointInformation_create(NULL, addr, value, IEC60870_QUALITY_GOOD);

                newAsdu = CS101_ASDU_create(alParams, false, CS101_COT_SPONTANEOUS,
                                            0, 1, false, false);
                if(newAsdu == NULL)
                {
                    printf("create new asdu failed\n");
                    return;
                }
                
                CS101_ASDU_addInformationObject(newAsdu, io);
                InformationObject_destroy(io);
                CS104_Slave_enqueueASDU(slave, newAsdu);
                CS101_ASDU_destroy(newAsdu);
            }
        }
        *(p_data_last + i) = *(p_data_now + i);  //重新赋值
    }

    //监视CSU系统汇流柜（状态信息）变化
    temp = p_telematic_data->combiner_cabinet_system_status_info[0];
    if((g_system_status == 1) || (g_system_status == 2)) //CMU系统状态是1或2
    {
        temp |= 0x01;
    }
    else
    {
        temp &= 0xFE;
    }
    newAsdu = CS101_ASDU_create(alParams, false, CS101_COT_INTERROGATED_BY_STATION,
                                                0, 1, false, false);
    if(newAsdu == NULL)
    {
        printf("CS101_ASDU_create failed\n");
        return;
    }
    for(i = 0; i < 8; i++)
    {
        addr = i + 0x31;
        value = (temp >> i) & 0x01;
        io = (InformationObject)SinglePointInformation_create(NULL, addr, value, IEC60870_QUALITY_GOOD);
        CS101_ASDU_addInformationObject(newAsdu, io);
        InformationObject_destroy(io);
    }

    CS104_Slave_enqueueASDU(slave, newAsdu);
    CS101_ASDU_destroy(newAsdu);
    newAsdu = NULL;

    p_data_now = (uint8_t *)(&p_telematic_data->combiner_cabinet_system_status_info[0]);
    p_data_last = (uint8_t *)(&g_telematic_data.combiner_cabinet_system_status_info[0]);
    for (i = 0; i < COMBINER_CABINET_SYSTEM_STATUS_LEN_BYTE; i++)
    {
        for (j = 0; j < 8; j++)
        {
            if (((*(p_data_now + i) >> j) & 0x01) != ((*(p_data_last + i) >> j) & 0x01))
            {
                addr = (i * 8) + j + 0x31;
                value = (*(p_data_now + i) >> j) & 0x01;
                io = (InformationObject)SinglePointInformation_create(NULL, addr, value, IEC60870_QUALITY_GOOD);

                newAsdu = CS101_ASDU_create(alParams, false, CS101_COT_SPONTANEOUS,
                                            0, 1, false, false);
                if(newAsdu == NULL)
                {
                    printf("create new asdu failed\n");
                    return;
                }

                CS101_ASDU_addInformationObject(newAsdu, io);
                InformationObject_destroy(io);
                CS104_Slave_enqueueASDU(slave, newAsdu);
                CS101_ASDU_destroy(newAsdu);  
            }
        }
        *(p_data_last + i) = *(p_data_now + i);  //重新赋值
    }

    //监视CSU系统汇流柜（故障信息）变化
    p_data_now = (uint8_t *)(&p_telematic_data->combiner_cabinet_system_fault_info[0]);
    p_data_last = (uint8_t *)(&g_telematic_data.combiner_cabinet_system_fault_info[0]);
    for (i = 0; i < COMBINER_CABINET_SYSTEM_FAULT_LEN_BYTE; i++)
    {
        for (j = 0; j < 8; j++)
        {
            if (((*(p_data_now + i) >> j) & 0x01) != ((*(p_data_last + i) >> j) & 0x01))
            {
                addr = (i * 8) + j + 0x81;
                value = (*(p_data_now + i) >> j) & 0x01;
                io = (InformationObject)SinglePointInformation_create(NULL, addr, value, IEC60870_QUALITY_GOOD);

                newAsdu = CS101_ASDU_create(alParams, false, CS101_COT_SPONTANEOUS,
                                            0, 1, false, false);
                if(newAsdu == NULL)
                {
                    printf("create new asdu failed\n");
                    return;
                }
                
                CS101_ASDU_addInformationObject(newAsdu, io);
                InformationObject_destroy(io);
                CS104_Slave_enqueueASDU(slave, newAsdu);
                CS101_ASDU_destroy(newAsdu);
            }
        }
        *(p_data_last + i) = *(p_data_now + i);  //重新赋值
    }
    memcpy(&g_telematic_data, p_telematic_data, sizeof(telematic_data_t)); //缓存一份作为变化之前的值
    return;
}


/**
 * @brief   iec104 从机功能（ETH）任务
 * @param   
 * @note    
 * @return  
 */
void *thread_iec104_slave(void *arg)
{
    #if 0
    uint16_t power_data = 0;
    float32_t value;
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get();
    system_param_t temp = {0};
    #endif
	prctl(PR_SET_NAME, "iec104_slave");
    uint8_t index = 0;
    /* create a new slave/server instance with default connection parameters and
     * default message queue size */
    CS104_Slave slave = CS104_Slave_create(500, 200);

    CS104_Slave_setLocalAddress(slave, "0.0.0.0");
    CS104_Slave_setLocalPort(slave, 2404);

    /* Set mode to a single redundancy group
     * NOTE: library has to be compiled with CONFIG_CS104_SUPPORT_SERVER_MODE_SINGLE_REDUNDANCY_GROUP enabled (=1)
     */
  //  CS104_Slave_setServerMode(slave, CS104_MODE_SINGLE_REDUNDANCY_GROUP);
    CS104_Slave_setServerMode(slave, CS104_MODE_CONNECTION_IS_REDUNDANCY_GROUP);
    CS104_Slave_setMaxOpenConnections(slave, 5);

    /* get the connection parameters - we need them to create correct ASDUs -
     * you can also modify the parameters here when default parameters are not to be used */
    CS101_AppLayerParameters alParams = CS104_Slave_getAppLayerParameters(slave);
	g_alParams = alParams;

    Lib60870_enableDebugOutput(0);

    IEC104_DEBUG_PRINT("\n CS101_AppLayerParameters:\n");
    IEC104_DEBUG_PRINT(" sizeOfTypeId:%i  sizeOfVSQ:%i  sizeOfCOT:%i  originatorAddress:%i\n", alParams->sizeOfTypeId, alParams->sizeOfVSQ, alParams->sizeOfCOT, alParams->originatorAddress);
    IEC104_DEBUG_PRINT(" sizeOfCA:%i  sizeOfIOA:%i  maxSizeOfASDU:%i\n", alParams->sizeOfCA, alParams->sizeOfIOA, alParams->maxSizeOfASDU);    

    /* when you have to tweak the APCI parameters (t0-t3, k, w) you can access them here */
    CS104_APCIParameters apciParams = CS104_Slave_getConnectionParameters(slave);

    IEC104_DEBUG_PRINT("\n APCI parameters:\n");
    IEC104_DEBUG_PRINT(" t0:%i  t1:%i  t2:%i  t3:%i\n", apciParams->t0, apciParams->t1, apciParams->t2, apciParams->t3);
    IEC104_DEBUG_PRINT(" k:%i  w:%i\n", apciParams->k, apciParams->w);

    /* set the callback handler for the clock synchronization command */
    CS104_Slave_setClockSyncHandler(slave, clockSyncHandler, NULL);

    /* set the callback handler for the interrogation command */
    CS104_Slave_setInterrogationHandler(slave, interrogationHandler, NULL);

    /* set handler for other message types */
    CS104_Slave_setASDUHandler(slave, slaveAsduHandler, NULL);

    /* set handler to handle connection requests (optional) */
    CS104_Slave_setConnectionRequestHandler(slave, connectionRequestHandler, NULL);

    /* set handler to track connection events (optional) */
    CS104_Slave_setConnectionEventHandler(slave, connectionEventHandler, NULL);

    /* uncomment to log messages */
    CS104_Slave_setRawMessageHandler(slave, slaveRawMessageHandler, NULL);

    g_slave = slave;

    CS104_Slave_start(slave);

    if (CS104_Slave_isRunning(slave) == false) 
    {    
        IEC104_DEBUG_PRINT("Starting server failed!\n");    
        goto exit_program;
    }
	
	//先初始化所有的socket客户端
	for(index=0; index<MAX_SLAVE_COUNT; index++)
	{
		init_iec104_connection(index);
	}
    while (1) {
        sleep(2);
		for(index=0; index<MAX_SLAVE_COUNT; index++)
		{
			if(g_con[index] == NULL)
			{
				init_iec104_connection(index);
			}
            else
            {
                if(abs(time(NULL) - g_last_conn_time) >= 100) //100秒还没收到数据
                {
                    CS104_Connection_destroy(g_con[index]);
                    g_con[index] = NULL;
                    init_iec104_connection(index);
                    if(g_con[index] != NULL)
                    {
                        CS104_Connection_sendInterrogationCommand(g_con[index], CS101_COT_ACTIVATION, 1, IEC60870_QOI_STATION);
                    }
                }
            }
		}
        if(g_connect_flag != 0)
        {
            handle_telematic_changed_info(slave, alParams);
            handle_telemetry_upload_info(CS101_COT_PERIODIC);//CSU侧遥测
            handle_constant_upload_info(CS101_COT_PERIODIC);
        }
    }

    CS104_Slave_stop(slave);

exit_program:
    CS104_Slave_destroy(slave);
    usleep(500);
    return NULL;
}
/**
 * @brief   iec104 从机功能（ETH）任务启动
 * @param   
 * @note    
 * @return  
 */
void iec104_slave_task_start(void)
{
	pthread_t iec104_task_id;
	pthread_attr_t attr;

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);

	if(pthread_create(&iec104_task_id,&attr,thread_iec104_slave,NULL) != 0)
	{
		perror("pthread_create thread_can_test");
	}
	pthread_attr_destroy(&attr);
	return;
}
