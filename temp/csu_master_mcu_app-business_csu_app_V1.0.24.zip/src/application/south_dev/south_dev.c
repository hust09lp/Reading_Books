#include <unistd.h>
#include "info_record.h"
#include "iec104_slave.h"
#include "data_shm.h"
#include "sofar_log.h"
#include "sdk_public.h"
#include "sdk_shm.h"
#include "sci_task.h"
#include "sdk_dido.h"
#include "integration_task.h"
#include "param_record.h"
#include "web_control_task.h"
#include "command_parser.h"
#include "tcp_server_service.h"
#include "pthread_can.h"

int32_t main(int32_t argc, char **argv)
{
    log_init((int8_t *)PATH_CONF);
    log_set_level(LOG_LVL_DEBUG);
	
    // 映射共享内存
    common_data_t *tep = sdk_shm_init();

    if (tep == NULL)
    {
        log_i((int8_t *)"\n tep \n");
    }
    //参数储存模块初始化
    param_record_module_init();
    // sci模块初始化
    sci_module_init();
	// 综合管理线程
    integration_task_start();
    // iec104从站线程 
    iec104_slave_task_start();
    // 信息存储模块初始化
    info_record_module_init();
	// 响应web控制操作
    web_control_task_start();
    // 箱变信息线程
    // box_transformer_task_start();
    // modbus模块初始化
    modbus_start();
    // TCP 服务端模块初始化
    tcp_server_module_init();
    // CAN 测试模块初始化
    innercan_task_start();
	
    while(1)
    {
        sleep(5);
    }

	log_finish();

    return 0;
}





