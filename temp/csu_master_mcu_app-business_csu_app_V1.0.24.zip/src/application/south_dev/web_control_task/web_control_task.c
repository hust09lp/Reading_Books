#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sofar_errors.h>
#include <sofar_log.h>
#include <pthread.h>
#include "web_control_task.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk_public.h"
#include "sdk_para.h"
#include "sdk_net_public.h"
#include "sci_task.h"
#include "app_common.h"
#include "param_record.h"
#include "command_parser.h"


/**
 * @brief   响应 web 指令操作
 * @param
 * @return
 * @note    检测共享内存对应标志位，若电控操作标志位被置位，则发对应控制指令
 */
static void csu_control_handle(void)
{
	web_control_info_t *p_web_data = shm_web_control_info_get();
	if(NULL == p_web_data)
	{
		return;
	}
	constant_parameter_data_t * p_param = sdk_shm_constant_parameter_data_get();
	system_param_t temp = {0};
	memcpy(&temp,&p_param->system_param,sizeof(system_param_t));

    //故障复位指令
    if(BIT_GET(p_web_data->control_cmd_flag, 0))
	{
		temp.remote_control_cmd &= ~((1 << 1) & 0xffff);
		temp.remote_control_cmd |= ((p_web_data->control_cmd_data.reset << 1) & 0xffff);
		set_constant_data( FUNCID_SET_REMOTE_CTRL , (uint16_t*)&temp.remote_control_cmd, 1 );
		// set_constant_data(0x2001,(uint16_t*)&temp,sizeof(temp)/2);
		//reset();
        BIT_CLR(p_web_data->control_cmd_flag, 0);
	}
    //开关机指令
    if(BIT_GET(p_web_data->control_cmd_flag, 1))
	{
		temp.remote_control_cmd &= ~((1 << 0) & 0xffff);
		temp.remote_control_cmd |= ((p_web_data->control_cmd_data.run_state << 0) & 0xffff);
		set_constant_data( FUNCID_SET_REMOTE_CTRL ,(uint16_t*)&temp.remote_control_cmd, 1 );
		// set_constant_data(0x2001, (uint16_t*)&temp, sizeof(temp) / 2);
        BIT_CLR(p_web_data->control_cmd_flag, 1);
	}
    //汇流柜分励脱扣器断开指令
    if(BIT_GET(p_web_data->control_cmd_flag, 4))
	{
        set_gpio(DO9_INDEX,true);
		sdk_delay_ms(300);
		set_gpio(DO9_INDEX,false);
        BIT_CLR(p_web_data->control_cmd_flag, 4);
	}
    //时间同步
    if(BIT_GET(p_web_data->system_param_flag, 2))
	{
        sync_time();
        BIT_CLR(p_web_data->system_param_flag, 2);
	}
}



/**
 * @brief   响应 EMS 指令操作
 * @param
 * @return
 * @note    检测共享内存对应标志位，若电控操作标志位被置位，则发对应控制指令
 */
static void ems_control_handle(void)
{
	uint8_t ret = 0;

	web_control_info_t *p_web_data = shm_web_control_info_get();
	if(NULL == p_web_data)
	{
		return;
	}
    //EMS参数设置
    if(BIT_GET(p_web_data->cabinet_param_update_flag, 0))
	{
		ret = set_ems_data();
		if(ret < 0)
		{
			log_e((int8_t *)"[%s][%d]set ems data error, ret = %d\n", __func__,__LINE__,ret);
			return;
		}
		ret = set_holiday_ems_data();
		if(ret < 0)
		{
			log_e((int8_t *)"[%s][%d]set holiday ems data error, ret = %d\n", __func__,__LINE__,ret);
			return;
		}
        BIT_CLR(p_web_data->cabinet_param_update_flag, 0);
		ems_param_save(); // 测试掉电记忆
	}
    //电价设置
    if(BIT_GET(p_web_data->cabinet_param_update_flag, 10))
	{
        BIT_CLR(p_web_data->cabinet_param_update_flag, 10);
		ems_param_save(); // 测试掉电记忆
	}
}


/**
 * @brief   系统参数设置
 * @param
 * @return
 * @note    检测共享内存对应标志位，若电控操作标志位被置位，则发对应控制指令
 */
static void sys_run_param_set_handle(void)
{
	uint8_t ret = 0;

	web_control_info_t *p_web_data = shm_web_control_info_get();
	if(NULL == p_web_data)
	{
		return;
	}

    if(BIT_GET(p_web_data->cabinet_param_update_flag, 7))
	{
        BIT_CLR(p_web_data->cabinet_param_update_flag, 7);
        ret = set_sys_run_param();
		if(ret < 0)
		{
			log_e((int8_t *)"[%s][%d]set mqtt param error, ret = %d\n", __func__,__LINE__,ret);
			return;
		}
	}
}



/**
 * @brief   响应节能降耗指令操作
 * @param
 * @return
 * @note    检测共享内存对应标志位，若电控操作标志位被置位，则发对应控制指令
 */
static void ems_energy_save_handle(void)
{
	web_control_info_t *p_web_data = shm_web_control_info_get();
	if(NULL == p_web_data)
	{
		return;
	}

	if (p_web_data->mcu2_notice)
	{
		set_mcu2_notice_info();
	}
}


/**
 * @brief   响应 箱变 指令操作
 * @param
 * @return
 * @note    检测共享内存对应标志位，若电控操作标志位被置位，则发对应控制指令
 */
static void box_transformer_control_handle(void)
{
	box_transformer_info_t *p_box_transformer_data = sdk_shm_box_transformer_data_info_get();
	if(p_box_transformer_data == NULL)
	{
		log_e((int8_t *)"param is NULL, error");
		return;
	}
	transformer_remote_ctl_t *p_remote_ctl_switch = &(p_box_transformer_data->remote_ctl_switch);

	if (p_remote_ctl_switch->remote_ctl_switch_flag != 0)
	{
		// 执行断路器操作
		// box_transformer_breaker_switch_set(p_remote_ctl_switch->remote_ctl_switch_flag);
		p_remote_ctl_switch->remote_ctl_switch_flag = 0;
	}
}


/**
 * @brief   响应 web 对pcs参数设置的操作
 * @param
 * @return
 * @note    检测共享内存中 更新标志位，若置位，
 */
static void update_pcs_param(void)
{
	web_control_info_t *p_web_data = shm_web_control_info_get();
	if(NULL == p_web_data)
	{
		return;
	}

	constant_parameter_data_t * p_param = sdk_shm_constant_parameter_data_get();
	cabinet_parameter_data_t *p_cabinet_param = &p_web_data->cabinet_param_data;

	system_param_t temp = {0};
	memcpy(&temp,&p_param->system_param,sizeof(system_param_t));

	//PCS柜参数更新
	if (p_web_data->cabinet_param_update_flag & 0x02)
	{
		log_i((int8_t *)"active_power_ref=%d,reactive_power_ref=%d\n",p_cabinet_param->active_power,p_cabinet_param->reactive_power);

		temp.cabinet_param.active_power = p_cabinet_param->active_power;
		temp.cabinet_param.reactive_power = p_cabinet_param->reactive_power;
		// set_constant_data(0x2001,(uint16_t*)&temp,sizeof(temp)/2);
		set_constant_data( FUNCID_SET_POWER , (uint16_t*)&temp.cabinet_param.active_power, 
							MEMBER_DAT_NUM_CAL( &temp.cabinet_param.active_power, &temp.cabinet_param.reactive_power ) );

		p_web_data->cabinet_param_update_flag &= 0xFD;
	}
	// CSU的485设备使能
	if (p_web_data->cabinet_param_update_flag & 0x04)
	{
		temp.cabinet_param.rs485_device_enable.all = p_cabinet_param->rs485_device_enable.all;
		// set_constant_data(0x2001,(uint16_t*)&temp,sizeof(temp)/2);
		set_constant_data( FUNCID_SET_CONST_PARAM , (uint16_t*)&temp.cabinet_param.energy_storage_nums, 
							MEMBER_DAT_NUM_CAL( &temp.cabinet_param.energy_storage_nums, &temp.cabinet_param.humidity_diff_set ) );

		p_web_data->cabinet_param_update_flag &= 0xFB;
	}
	// CSU的储能柜(带PCS模块)数量设定
	if (p_web_data->cabinet_param_update_flag & 0x08)
	{
		temp.cabinet_param.energy_storage_nums = p_cabinet_param->energy_storage_nums;
		// set_constant_data(0x2001,(uint16_t*)&temp,sizeof(temp)/2);
		set_constant_data( FUNCID_SET_CONST_PARAM , (uint16_t*)&temp.cabinet_param.energy_storage_nums, 
							MEMBER_DAT_NUM_CAL( &temp.cabinet_param.energy_storage_nums, &temp.cabinet_param.humidity_diff_set ) );

		p_web_data->cabinet_param_update_flag &= 0xF7;
	}
	// CSU的应用场景
	if (p_web_data->cabinet_param_update_flag & 0x10)
	{
		temp.cabinet_param.scenario_setting = p_cabinet_param->scenario_setting;
		// set_constant_data(0x2001,(uint16_t*)&temp,sizeof(temp)/2);
		set_constant_data( FUNCID_SET_CONST_PARAM , (uint16_t*)&temp.cabinet_param.energy_storage_nums, 
                           MEMBER_DAT_NUM_CAL( &temp.cabinet_param.energy_storage_nums, &temp.cabinet_param.humidity_diff_set ) );

		p_web_data->cabinet_param_update_flag &= 0xEF;
	}
	// 容测模式
	if (p_web_data->cabinet_param_update_flag & 0x20)
	{
		set_ft_cap_test_mode(p_web_data->ft_cap_test);
		p_web_data->cabinet_param_update_flag &= 0xDF;
	}
}


/**
 * @brief   mqtt小桔参数设置，下发至MCU2
 * @param
 * @return
 * @note    检测共享内存对应标志位，若电控操作标志位被置位，则发对应控制指令
 */
static void mqtt_control_handle(void)
{
    uint8_t ret = 0;
    uint8_t param_set_flag = 0;

	web_control_info_t *p_web_data = shm_web_control_info_get();
	if(NULL == p_web_data)
	{
		return;
	}

    if(BIT_GET(p_web_data->xiaoju_param_set_flag, 0))
    {
        param_set_flag = 1;
        BIT_CLR(p_web_data->xiaoju_param_set_flag, 0);
    }
    if(BIT_GET(p_web_data->xiaoju_param_set_flag, 1))
    {
        param_set_flag = 1;
        BIT_CLR(p_web_data->xiaoju_param_set_flag, 1);
    }
    if(BIT_GET(p_web_data->xiaoju_param_set_flag, 2))
    {
        param_set_flag = 1;
        BIT_CLR(p_web_data->xiaoju_param_set_flag, 2);
    }
    if(BIT_GET(p_web_data->xiaoju_param_set_flag, 3))
    {
        param_set_flag = 1;
        BIT_CLR(p_web_data->xiaoju_param_set_flag, 3);
    }
    if(BIT_GET(p_web_data->xiaoju_param_set_flag, 4))
    {
        param_set_flag = 1;
        BIT_CLR(p_web_data->xiaoju_param_set_flag, 4);
    }

    if(param_set_flag)              //进行数据下发
    {
        ret = set_mqtt_param();
		if(ret < 0)
		{
			log_e((int8_t *)"[%s][%d]set mqtt param error, ret = %d\n", __func__,__LINE__,ret);
			return;
		}
    }
}


/**
 * @brief   电表配置参数设置
 * @param
 * @return
 * @note    检测共享内存对应标志位，若电控操作标志位被置位，则发对应控制指令
 */
static void elec_meter_config_param_set(void)
{
    uint8_t ret = 0;

	web_control_info_t *p_web_data = shm_web_control_info_get();
	if(NULL == p_web_data)
	{
		return;
	}

    if(BIT_GET(p_web_data->cabinet_param_update_flag, 6))
    {
        ret = set_elec_meter_config_param();
		if(ret < 0)
		{
            log_e((int8_t *)"\n [%s:%d] elec meter config param set error!!! \n", __func__, __LINE__);
			return;
		}
        BIT_CLR(p_web_data->cabinet_param_update_flag, 6);
    }
}


/**
 * @brief   CSU SN写入，下发至MCU2
 * @param
 * @return
 * @note    检测共享内存对应标志位，若电控操作标志位被置位，则发对应控制指令
 */
static void csu_sn_write_handle(void)
{
    uint8_t param_set_flag = 0;

	web_control_info_t *p_web_data = shm_web_control_info_get();
	if(NULL == p_web_data)
	{
		return;
	}

    if(BIT_GET(p_web_data->system_param_flag, 3))
    {
        param_set_flag = 1;
        BIT_CLR(p_web_data->system_param_flag, 3);
    }

    if(param_set_flag)              //进行数据下发
    {
        set_csu_sn();
    }
}

/**
 * @brief   光伏电表参数配置，下发至MCU2
 * @param
 * @return
 * @note    检测共享内存对应标志位，若电控操作标志位被置位，则发对应控制指令
 */
static void photovoltaic_meter_cfg_handle(void)
{
    uint8_t param_set_flag = 0;

	web_control_info_t *p_web_data = shm_web_control_info_get();
	if(NULL == p_web_data)
	{
		return;
	}

    if(BIT_GET(p_web_data->cabinet_param_update_flag, 11))
    {
        param_set_flag = 1;
        BIT_CLR(p_web_data->cabinet_param_update_flag, 11);
    }

    if(param_set_flag)              //进行数据下发
    {
        photovoltaic_meter_cfg_set();
    }
}


/**
 * @brief   设备配置参数保存
 * @param
 * @return
 * @note 
 */
static void dev_param_cfg_save(void)
{
	web_control_info_t *p_web_data = shm_web_control_info_get();
	if(NULL == p_web_data)
	{
		return;
	}

    if((p_web_data->other_parameter_update_flag[0] == 1) || (p_web_data->other_parameter_update_flag[1] == 1))
    {
        dev_param_save();
        p_web_data->other_parameter_update_flag[0] = 0;
        p_web_data->other_parameter_update_flag[1] = 0;
    }
}



/**
 * @brief   响应 web 的控制操作
 * @param
 * @return
 */
void *thread_web_control(void *arg)
{
	usleep(1000 * 180);	// 通讯板上电后 延时180ms再开始发送指令，否则前面几帧指令容易丢失

	while (1)
	{
		csu_control_handle();
		update_pcs_param();
		ems_control_handle();
		ems_energy_save_handle();
		box_transformer_control_handle();
        mqtt_control_handle();
        elec_meter_config_param_set();
        csu_sn_write_handle();
        photovoltaic_meter_cfg_handle();
        sys_run_param_set_handle();
        dev_param_cfg_save();
		usleep(1000 * 500);	// 500ms
	}

	pthread_exit(NULL);
}

/**
 * @brief   web 控制操作响应任务启动（用于实现web的控制指令、参数设置指令下发、参数更新等）
 * @param
 * @return
 */
void web_control_task_start(void)
{
	int16_t ret = 0;
	pthread_attr_t web_control_attr;
	pthread_t web_control;

	// 初始化线程属性
	ret = pthread_attr_init(&web_control_attr);
	if (ret)
	{
		log_e((int8_t *)"\n [%s:%d] pthread_attr_init error!!! \n", __func__, __LINE__);
		return; // 线程属性初始化出错退出
	}

	// 设置线程属性为分离状态
	ret = pthread_attr_setdetachstate(&web_control_attr, PTHREAD_CREATE_DETACHED);
	if (ret)
	{
		log_e((int8_t *)"\n [%s:%d] pthread_attr_setdetachstate web_control_attr error!!! \n", __func__, __LINE__);
		return; // 线程分离属性设置出错退出
	}

	ret = pthread_create(&web_control, &web_control_attr, &thread_web_control, NULL);
	if (ret)
	{
		log_e((int8_t *)"\n [%s:%d] pthread_create web_control error!!! \n", __func__, __LINE__);
		return; // 线程创建出错退出
	}

	// 销毁线程属性结构,它在重新初始化之前不能重新使用
	pthread_attr_destroy(&web_control_attr);
}
