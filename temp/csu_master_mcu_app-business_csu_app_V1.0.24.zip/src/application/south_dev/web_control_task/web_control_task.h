/** 
 * @file          web_control_task.h
 * @brief         响应 web 控制操作的任务线程的外部接口
 * @author        xiaojuying
 * @note
 * @version       V0.0.1     初版
 * @date          2023/5/6
 */


#ifndef __WEB_CONTROL_TASK_H__
#define __WEB_CONTROL_TASK_H__

#include "data_types.h"

/** 
 * @brief   web 控制操作响应任务启动（用于实现web的控制指令、参数设置指令下发、参数更新等）
 * @param
 * @return
 */
void web_control_task_start(void);

#endif  /* __WEB_CONTROL_TASK_H__ */
