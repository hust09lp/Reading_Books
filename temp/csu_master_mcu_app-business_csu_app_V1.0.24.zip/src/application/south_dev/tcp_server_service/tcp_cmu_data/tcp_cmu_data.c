#include <string.h>
#include "sdk_public.h"
#include "cJSON.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "data_shm.h"
#include "app_common.h"
#include "mongoose.h"
// #include "sofar_ota.h"
#include "tcp_cmu_data.h"
#include "tcp_server_service.h"

/**
 * @brief   cmu注册数据处理
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
static void cmu_sign_in_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len)
{
    cJSON *p_request = NULL;
    cJSON *p_response = NULL;
    char *p = NULL;
    sdk_rtc_t rtc_time;
    char ymd[32] = {0};
    char hms[32] = {0};
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;

    p_request = cJSON_Parse(p_data);
    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    p_energy_cabinet_data->cmu_data.sign_data.bcu_num = cJSON_GetObjectItem(p_request,"bcuNum")->valueint;
    strcpy((char *)p_energy_cabinet_data->cmu_data.sign_data.cmu_sn, cJSON_GetObjectItem(p_request,"cmuSn")->valuestring);
    strcpy((char *)p_energy_cabinet_data->cmu_data.sign_data.pcs_sn, cJSON_GetObjectItem(p_request,"pcsSn")->valuestring);
    // strcpy((char *)p_energy_cabinet_data->cmu_data.sign_data.bcu_sn, cJSON_GetObjectItem(p_request,"bcuSn")->valuestring);
	cJSON *p_bcu_array = cJSON_GetObjectItem(p_request,"bcuSn");
    uint16_t array_size = cJSON_GetArraySize(p_bcu_array);
    if(array_size > 0)
    {
        for(uint8_t i = 0; i < array_size; i++)
        {
            // cJSON *item = cJSON_GetArrayItem(p_bcu_array, i);
            strcpy((char *)p_energy_cabinet_data->cmu_data.sign_data.bcu_sn[i], cJSON_GetArrayItem(p_bcu_array, i)->valuestring);
        }
    }
    strcpy((char *)p_energy_cabinet_data->cmu_data.sign_data.bat_stack_sn, cJSON_GetObjectItem(p_request,"batStackSn")->valuestring);
    strcpy((char *)p_energy_cabinet_data->cmu_data.sign_data.fc_sn, cJSON_GetObjectItem(p_request,"fcSn")->valuestring);
    strcpy((char *)p_energy_cabinet_data->cmu_data.sign_data.lc_sn, cJSON_GetObjectItem(p_request,"lcSn")->valuestring);
    TCP_DEBUG_PRINT((int8_t *)"bcu num : %d", p_energy_cabinet_data->cmu_data.sign_data.bcu_num);
    TCP_DEBUG_PRINT((int8_t *)"cmu sn : %s", p_energy_cabinet_data->cmu_data.sign_data.cmu_sn);
    TCP_DEBUG_PRINT((int8_t *)"pcs sn : %s", p_energy_cabinet_data->cmu_data.sign_data.pcs_sn);
    for(uint8_t i = 0; i < p_energy_cabinet_data->cmu_data.sign_data.bcu_num; i++)
    {
        TCP_DEBUG_PRINT((int8_t *)"bcu sn : %s", p_energy_cabinet_data->cmu_data.sign_data.bcu_sn[i]);
    }
    TCP_DEBUG_PRINT((int8_t *)"bat sn : %s", p_energy_cabinet_data->cmu_data.sign_data.bat_stack_sn);
    TCP_DEBUG_PRINT((int8_t *)"fc sn : %s", p_energy_cabinet_data->cmu_data.sign_data.fc_sn);
    TCP_DEBUG_PRINT((int8_t *)"lc sn : %s", p_energy_cabinet_data->cmu_data.sign_data.lc_sn);
    cJSON_Delete(p_request);

    p_response = cJSON_CreateObject();
    if(p_response == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
    sprintf(ymd, "%04d-%02d-%02d", rtc_time.tm_year + 2000, rtc_time.tm_mon, rtc_time.tm_day);
    sprintf(hms, "%02d:%02d:%02d", rtc_time.tm_hour, rtc_time.tm_min, rtc_time.tm_sec);

    cJSON_AddStringToObject(p_response, "devtype", "cmu");
    cJSON_AddStringToObject(p_response, "cmdtype", "signIn");
    cJSON_AddStringToObject(p_response, "YMD", ymd);
    cJSON_AddStringToObject(p_response, "HMS", hms);
    cJSON_AddNumberToObject(p_response, "result", SUCCESS);

    p = cJSON_PrintUnformatted(p_response);
    cJSON_Delete(p_response);
    tcp_send(p_nc, (uint8_t *)p, strlen(p));
    free(p);
    p_energy_cabinet_data->cmu_data.sign_data.sign_status = 1;
}


/**
 * @brief   cmu心跳数据处理
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
static void cmu_heartbeat_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len)
{
    cJSON *p_response = NULL;
    char *p = NULL;

    p_response = cJSON_CreateObject();
    if(p_response == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_response, "devtype", "cmu");
    cJSON_AddStringToObject(p_response, "cmdtype", "heartbeat");
    cJSON_AddNumberToObject(p_response, "result", SUCCESS);

    p = cJSON_PrintUnformatted(p_response);
    cJSON_Delete(p_response);
    tcp_send(p_nc, (uint8_t *)p, strlen(p));
    free(p);
}


/**
 * @brief   cmu心跳数据处理
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
static void cmu_property_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len)
{
    cJSON *p_request = NULL;
    cJSON *p_response = NULL;
    cJSON *p_data_item = NULL;
    char *p = NULL;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;

    p_request = cJSON_Parse(p_data);
    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    p_data_item = cJSON_GetObjectItem(p_request,"data");
    strcpy((char *)p_energy_cabinet_data->cmu_data.property_data.cmu_sn, cJSON_GetObjectItem(p_data_item,"sn")->valuestring);
    strcpy((char *)p_energy_cabinet_data->cmu_data.property_data.version, cJSON_GetObjectItem(p_data_item,"version")->valuestring);
    if(cJSON_GetObjectItem(p_data_item,"safetyVersion") != NULL)
    {
        strcpy((char *)p_energy_cabinet_data->cmu_data.property_data.safe_version, cJSON_GetObjectItem(p_data_item,"safetyVersion")->valuestring);
    }
    p_energy_cabinet_data->cmu_data.property_data.run_status = cJSON_GetObjectItem(p_data_item,"runStatus")->valueint;

    TCP_DEBUG_PRINT((int8_t *)"cmu sn : %s", p_energy_cabinet_data->cmu_data.property_data.cmu_sn);
    TCP_DEBUG_PRINT((int8_t *)"version : %s", p_energy_cabinet_data->cmu_data.property_data.version);
    TCP_DEBUG_PRINT((int8_t *)"run status : %d", p_energy_cabinet_data->cmu_data.property_data.run_status);

    cJSON_Delete(p_request);

    p_response = cJSON_CreateObject();
    if(p_response == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_response, "devtype", "cmu");
    cJSON_AddStringToObject(p_response, "cmdtype", "property");
    cJSON_AddNumberToObject(p_response, "result", SUCCESS);

    p = cJSON_PrintUnformatted(p_response);
    cJSON_Delete(p_response);
    tcp_send(p_nc, (uint8_t *)p, strlen(p));
    free(p);
}


/**
 * @brief   子模块升级状态设置
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
static void cmu_dev_upgrade_status_set(uint8_t module_percent, uint8_t module_index, uint8_t dev_index)
{
    firmware_update_t *p_update = sdk_shm_firmware_update_info_get();

    if(module_percent == -1)
    {
        p_update->dev_cmu_update[dev_index - 1].update_flag[module_index] = UPDATE_FAIL;
    }
    else if(module_percent == 100)
    {
        p_update->dev_cmu_update[dev_index - 1].update_flag[module_index] = UPDATE_NONE;
    }
    else
    {
        p_update->dev_cmu_update[dev_index - 1].update_flag[module_index] = UPDATE_ING;
    }
}


/**
 * @brief   cmu升级数据处理
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
static void cmu_ota_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len, uint8_t dev_index)
{
    cJSON *p_request = NULL;
    cJSON *p_response = NULL;
    cJSON *p_data_item = NULL;
    char *p = NULL;
    firmware_update_t *p_update = sdk_shm_firmware_update_info_get();

    p_request = cJSON_Parse(p_data);
    p_data_item = cJSON_GetObjectItem(p_request,"data");
    //把升级进度填进对应的列表
    for (uint8_t i = 0; i < UPDATE_OBJECT_NUM; ++i)
    {
        if((p_update->chip_role[i] == CMU_MCU1_NUM) && (p_update->file_type[i] == FILE_APP_NUM))
        {
            if(cJSON_GetObjectItem(p_data_item, "mcu1_app") != NULL)
            {
                p_update->dev_cmu_update[dev_index - 1].module_percent[i] = cJSON_GetObjectItem(p_data_item, "mcu1_app")->valueint;
                printf("module_percent[%d] %d\n", i, p_update->dev_cmu_update[dev_index - 1].module_percent[i]);
                cmu_dev_upgrade_status_set(p_update->dev_cmu_update[dev_index - 1].module_percent[i], i, dev_index);
            }
        }
        if((p_update->chip_role[i] == CMU_MCU1_NUM) && (p_update->file_type[i] == FILE_CORE_NUM))
        {
            if(cJSON_GetObjectItem(p_data_item, "mcu1_core") != NULL)
            {
                p_update->dev_cmu_update[dev_index - 1].module_percent[i] = cJSON_GetObjectItem(p_data_item, "mcu1_core")->valueint;
                printf("module_percent[%d] %d\n", i, p_update->dev_cmu_update[dev_index - 1].module_percent[i]);
                cmu_dev_upgrade_status_set(p_update->dev_cmu_update[dev_index - 1].module_percent[i], i, dev_index);
            }
        }
        if((p_update->chip_role[i] == CMU_MCU2_NUM) && (p_update->file_type[i] == FILE_APP_NUM))
        {
            if(cJSON_GetObjectItem(p_data_item, "mcu2_app") != NULL)
            {
                p_update->dev_cmu_update[dev_index - 1].module_percent[i] = cJSON_GetObjectItem(p_data_item, "mcu2_app")->valueint;
                printf("module_percent[%d] %d\n", i, p_update->dev_cmu_update[dev_index - 1].module_percent[i]);
                cmu_dev_upgrade_status_set(p_update->dev_cmu_update[dev_index - 1].module_percent[i], i, dev_index);
            }
        }
        if((p_update->chip_role[i] == CMU_MCU2_NUM) && (p_update->file_type[i] == FILE_CORE_NUM))
        {
            if(cJSON_GetObjectItem(p_data_item, "mcu2_core") != NULL)
            {
                p_update->dev_cmu_update[dev_index - 1].module_percent[i] = cJSON_GetObjectItem(p_data_item, "mcu2_core")->valueint;
                printf("module_percent[%d] %d\n", i, p_update->dev_cmu_update[dev_index - 1].module_percent[i]);
                cmu_dev_upgrade_status_set(p_update->dev_cmu_update[dev_index - 1].module_percent[i], i, dev_index);
            }
        }
        if(p_update->chip_role[i] == PCS_M_NUM)
        {
            if(cJSON_GetObjectItem(p_data_item, "pcs_m") != NULL)
            {
                p_update->dev_cmu_update[dev_index - 1].module_percent[i] = cJSON_GetObjectItem(p_data_item, "pcs_m")->valueint;
                printf("module_percent[%d] %d\n", i, p_update->dev_cmu_update[dev_index - 1].module_percent[i]);
                cmu_dev_upgrade_status_set(p_update->dev_cmu_update[dev_index - 1].module_percent[i], i, dev_index);
            }
        }
        if(p_update->chip_role[i] == PCS_S_NUM)
        {
            if(cJSON_GetObjectItem(p_data_item, "pcs_s") != NULL)
            {
                p_update->dev_cmu_update[dev_index - 1].module_percent[i] = cJSON_GetObjectItem(p_data_item, "pcs_s")->valueint;
                printf("module_percent[%d] %d\n", i, p_update->dev_cmu_update[dev_index - 1].module_percent[i]);
                cmu_dev_upgrade_status_set(p_update->dev_cmu_update[dev_index - 1].module_percent[i], i, dev_index);
            }
        }
    }

    cJSON_Delete(p_request);

    p_response = cJSON_CreateObject();
    if(p_response == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_response, "devtype", "cmu");
    cJSON_AddStringToObject(p_response, "cmdtype", "ota");
    cJSON_AddNumberToObject(p_response, "result", SUCCESS);

    p = cJSON_PrintUnformatted(p_response);
    cJSON_Delete(p_response);
    tcp_send(p_nc, (uint8_t *)p, strlen(p));
    free(p);
}


/**
 * @brief   cmu数据处理
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
void cmu_data_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len, uint8_t dev_index)
{
    cJSON *p_request = NULL;
    char *p_cmd_type = NULL;
    
    p_request = cJSON_Parse(p_data);
    p_cmd_type = cJSON_GetObjectItem(p_request,"cmdtype")->valuestring;
    if(!strcmp(p_cmd_type, "signIn"))
    {
        cmu_sign_in_handle(p_nc, p_data, data_len);
    }
    if(!strcmp(p_cmd_type, "heartbeat"))
    {
        cmu_heartbeat_handle(p_nc, p_data, data_len);
    }
    if(!strcmp(p_cmd_type, "property"))
    {
        cmu_property_handle(p_nc, p_data, data_len);
    }
    if(!strcmp(p_cmd_type, "ota"))
    {
        cmu_ota_handle(p_nc, p_data, data_len, dev_index);
    }
    cJSON_Delete(p_request);
}