#ifndef __TCP_CMU_DATA_H__
#define __TCP_CMU_DATA_H__

#include "mongoose.h"

// 新格式的文件类型编码
typedef enum
{
    FILE_APP_NUM = 0x00,
    FILE_CORE_NUM = 0x01,
    FILE_KERNEL_NUM,
    FILE_ROOTFS_NUM,
    FILE_SAFETY_NUM,
    FILE_PACK_NUM = 0x80,
} file_type_num_e;

// 新格式的芯片编码
typedef enum
{
    ALMIGHTY_NUM = 0x00,    // 不查询编码
    PCS_M_NUM = 0x22,
    PCS_S_NUM = 0x23,
    CSU_MCU1_NUM = 0x33,
    CSU_MCU2_NUM = 0x34,
    CMU_MCU1_NUM = 0x3b,
    CMU_MCU2_NUM = 0x3c,
} obj_num_e;

/**
 * @brief   cmu数据处理
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
void cmu_data_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len, uint8_t dev_index);


#endif