#include <string.h>
#include "sdk_public.h"
#include "sdk_shm.h"
#include "data_shm.h"
#include "cJSON.h"
#include "app_common.h"
#include "mongoose.h"
#include "tcp_pcs_data.h"
#include "tcp_server_service.h"

const uint16_t g_pcs_event_list[PCS_MAX_EVENT_ITEM] = {
    0x1000, 0x1001, 0x1002, 0x1003, 0x1010, 0x1020, 0x1021, 0x1022, 
    0x1023, 0x1024, 0x1025, 0x1026, 0x1027, 0x1030, 0x1040, 0x1050,
    0x1060, 0x1070, 0x1080, 0x1090, 0x1091, 0x1092, 0x1093, 0x1094,
    0x1095, 0x1096, 0x1097, 0x10A0, 0x10A1, 0x10A2, 0x10A3, 0x10B0,
    0x10B1, 0x10B2, 0x10B3, 0x10B4, 0x10B5, 0x10B6, 0x10B7, 0x10B8,
    0x10C0, 0x10C1, 0x10C2, 0x10C3, 0x10C4, 0x10C5, 0x10D0, 0x10D1,
    0x10E0, 0x10E1, 0x10E2, 0x10E3, 0x10E4, 0x10F0, 0x10F1, 0x1110,
    0x1120, 0x1121, 0x1130, 0x1131, 0x1132
};

/**
 * @brief   pcs监控数据处理
 * @param	[in] *p_nc 连接信息 
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
static void pcs_monitor_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len)
{
    cJSON *p_request = NULL;
    cJSON *p_response = NULL;
    cJSON *p_data_item = NULL;
    char *p = NULL;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;

    p_request = cJSON_Parse(p_data);
    p_data_item = cJSON_GetObjectItem(p_request,"data");
    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    p_energy_cabinet_data->pcs_data.monitor_data.active_power = cJSON_GetObjectItem(p_data_item,"activepower")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.reactive_power = cJSON_GetObjectItem(p_data_item,"reactivePower")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.apparent_power = cJSON_GetObjectItem(p_data_item,"apparentPower")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.power_factor = cJSON_GetObjectItem(p_data_item,"powerFactor")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.grid_volt_r = cJSON_GetObjectItem(p_data_item,"R_vol")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.grid_volt_s = cJSON_GetObjectItem(p_data_item,"S_vol")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.grid_volt_t = cJSON_GetObjectItem(p_data_item,"T_vol")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.ac_current_r = cJSON_GetObjectItem(p_data_item,"R_cur")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.ac_current_s = cJSON_GetObjectItem(p_data_item,"S_cur")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.ac_current_t = cJSON_GetObjectItem(p_data_item,"T_cur")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.grid_freq = cJSON_GetObjectItem(p_data_item,"gridFreq")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.bus_volt_pn = cJSON_GetObjectItem(p_data_item,"busVoltPN")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.bus_volt_p = cJSON_GetObjectItem(p_data_item,"posHalfBusVoltPN")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.bus_volt_n = cJSON_GetObjectItem(p_data_item,"negHalfBusVoltPN")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.bat_current = cJSON_GetObjectItem(p_data_item,"batCurrent")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.bat_power = cJSON_GetObjectItem(p_data_item,"batPower")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.total_energy_charge = cJSON_GetObjectItem(p_data_item,"energyCharge")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.total_energy_discharge = cJSON_GetObjectItem(p_data_item,"energyDischarge")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.date = cJSON_GetObjectItem(p_data_item,"date")->valueint;    
    p_energy_cabinet_data->pcs_data.monitor_data.day_energy_charge = cJSON_GetObjectItem(p_data_item,"dayEnergyCharge")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.day_energy_discharge = cJSON_GetObjectItem(p_data_item,"dayEnergyDischarge")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.mon_energy_charge = cJSON_GetObjectItem(p_data_item,"monEnergyCharge")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.mon_energy_discharge = cJSON_GetObjectItem(p_data_item,"monEnergyDischarge")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.year_energy_charge = cJSON_GetObjectItem(p_data_item,"yearEnergyCharge")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.year_energy_discharge = cJSON_GetObjectItem(p_data_item,"yearEnergyDischarge")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.module_temp = cJSON_GetObjectItem(p_data_item,"tempModule")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.am_temp = cJSON_GetObjectItem(p_data_item,"tempAm")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.energy_char_avaiable = cJSON_GetObjectItem(p_data_item,"char")->valueint;
    p_energy_cabinet_data->pcs_data.monitor_data.energy_dischar_avaiable = cJSON_GetObjectItem(p_data_item,"dischar")->valueint;
    
    TCP_DEBUG_PRINT((int8_t *)"active_power : %d", p_energy_cabinet_data->pcs_data.monitor_data.active_power);
    TCP_DEBUG_PRINT((int8_t *)"reactive_power : %d", p_energy_cabinet_data->pcs_data.monitor_data.reactive_power);
    TCP_DEBUG_PRINT((int8_t *)"apparent_power : %d", p_energy_cabinet_data->pcs_data.monitor_data.apparent_power);
    TCP_DEBUG_PRINT((int8_t *)"power_factor : %d", p_energy_cabinet_data->pcs_data.monitor_data.power_factor);
    TCP_DEBUG_PRINT((int8_t *)"grid_volt_r : %d", p_energy_cabinet_data->pcs_data.monitor_data.grid_volt_r);
    TCP_DEBUG_PRINT((int8_t *)"grid_volt_s : %d", p_energy_cabinet_data->pcs_data.monitor_data.grid_volt_s);
    TCP_DEBUG_PRINT((int8_t *)"grid_volt_t : %d", p_energy_cabinet_data->pcs_data.monitor_data.grid_volt_t);
    TCP_DEBUG_PRINT((int8_t *)"ac_current_r : %d", p_energy_cabinet_data->pcs_data.monitor_data.ac_current_r);
    TCP_DEBUG_PRINT((int8_t *)"ac_current_s : %d", p_energy_cabinet_data->pcs_data.monitor_data.ac_current_s);
    TCP_DEBUG_PRINT((int8_t *)"ac_current_t : %d", p_energy_cabinet_data->pcs_data.monitor_data.ac_current_t);
    TCP_DEBUG_PRINT((int8_t *)"grid_freq : %d", p_energy_cabinet_data->pcs_data.monitor_data.grid_freq);
    TCP_DEBUG_PRINT((int8_t *)"bus_volt_pn : %d", p_energy_cabinet_data->pcs_data.monitor_data.bus_volt_pn);
    TCP_DEBUG_PRINT((int8_t *)"bus_volt_p : %d", p_energy_cabinet_data->pcs_data.monitor_data.bus_volt_p);
    TCP_DEBUG_PRINT((int8_t *)"bus_volt_n : %d", p_energy_cabinet_data->pcs_data.monitor_data.bus_volt_n);
    TCP_DEBUG_PRINT((int8_t *)"bat_current : %d", p_energy_cabinet_data->pcs_data.monitor_data.bat_current);
    TCP_DEBUG_PRINT((int8_t *)"bat_power : %d", p_energy_cabinet_data->pcs_data.monitor_data.bat_power);
    TCP_DEBUG_PRINT((int8_t *)"total_energy_charge : %d", p_energy_cabinet_data->pcs_data.monitor_data.total_energy_charge);
    TCP_DEBUG_PRINT((int8_t *)"total_energy_discharge : %d", p_energy_cabinet_data->pcs_data.monitor_data.total_energy_discharge);
    TCP_DEBUG_PRINT((int8_t *)"day_energy_charge : %d", p_energy_cabinet_data->pcs_data.monitor_data.day_energy_charge);
    TCP_DEBUG_PRINT((int8_t *)"day_energy_discharge : %d", p_energy_cabinet_data->pcs_data.monitor_data.day_energy_discharge);
    TCP_DEBUG_PRINT((int8_t *)"module_temp : %d", p_energy_cabinet_data->pcs_data.monitor_data.module_temp);
    TCP_DEBUG_PRINT((int8_t *)"am_temp : %d", p_energy_cabinet_data->pcs_data.monitor_data.am_temp);

    cJSON_Delete(p_request);

    p_response = cJSON_CreateObject();
    if(p_response == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_response, "devtype", "pcs");
    cJSON_AddStringToObject(p_response, "cmdtype", "monitor");
    cJSON_AddNumberToObject(p_response, "result", SUCCESS);
    p_energy_cabinet_data->pcs_data.monitor_data.init_status = SUCCESS;
    p = cJSON_PrintUnformatted(p_response);
    cJSON_Delete(p_response);
    tcp_send(p_nc, (uint8_t *)p, strlen(p));
    free(p);

}


/**
 * @brief   pcs属性数据处理
 * @param	[in] *p_nc 连接信息 
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
static void pcs_property_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len)
{
    cJSON *p_request = NULL;
    cJSON *p_response = NULL;
    cJSON *p_data_item = NULL;
    char *p = NULL;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;

    p_request = cJSON_Parse(p_data);
    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    p_data_item = cJSON_GetObjectItem(p_request,"data");
    strcpy((char *)p_energy_cabinet_data->pcs_data.property_data.pcs_sn, cJSON_GetObjectItem(p_data_item,"sn")->valuestring);
    strcpy((char *)p_energy_cabinet_data->pcs_data.property_data.pcs_model, cJSON_GetObjectItem(p_data_item,"model")->valuestring);
    strcpy((char *)p_energy_cabinet_data->pcs_data.property_data.mdsp_version, cJSON_GetObjectItem(p_data_item,"mDSPversion")->valuestring);
    strcpy((char *)p_energy_cabinet_data->pcs_data.property_data.ldsp_version, cJSON_GetObjectItem(p_data_item,"lDSPversion")->valuestring);
    p_energy_cabinet_data->pcs_data.property_data.dev_type = cJSON_GetObjectItem(p_data_item,"devType")->valueint;
    p_energy_cabinet_data->pcs_data.property_data.rated_power = cJSON_GetObjectItem(p_data_item,"ratedPower")->valueint;
    p_energy_cabinet_data->pcs_data.property_data.comm_status = cJSON_GetObjectItem(p_data_item,"commStatus")->valueint;
    p_energy_cabinet_data->pcs_data.property_data.sys_status = cJSON_GetObjectItem(p_data_item,"sysStatus")->valueint;
    p_energy_cabinet_data->pcs_data.property_data.rated_voltage = cJSON_GetObjectItem(p_data_item,"ratedVolt")->valueint;

    TCP_DEBUG_PRINT((int8_t *)"pcs sn : %s", p_energy_cabinet_data->pcs_data.property_data.pcs_sn);
    TCP_DEBUG_PRINT((int8_t *)"mdsp_version : %s", p_energy_cabinet_data->pcs_data.property_data.mdsp_version);
    TCP_DEBUG_PRINT((int8_t *)"ldsp_version : %s", p_energy_cabinet_data->pcs_data.property_data.ldsp_version);
    TCP_DEBUG_PRINT((int8_t *)"dev_type : %d", p_energy_cabinet_data->pcs_data.property_data.dev_type);
    TCP_DEBUG_PRINT((int8_t *)"rated_power : %d", p_energy_cabinet_data->pcs_data.property_data.rated_power);
    TCP_DEBUG_PRINT((int8_t *)"comm_status : %d", p_energy_cabinet_data->pcs_data.property_data.comm_status);
    TCP_DEBUG_PRINT((int8_t *)"sys_status : %d", p_energy_cabinet_data->pcs_data.property_data.sys_status);
    TCP_DEBUG_PRINT((int8_t *)"rated_voltage : %d", p_energy_cabinet_data->pcs_data.property_data.rated_voltage);
    

    cJSON_Delete(p_request);

    p_response = cJSON_CreateObject();
    if(p_response == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_response, "devtype", "pcs");
    cJSON_AddStringToObject(p_response, "cmdtype", "property");
    cJSON_AddNumberToObject(p_response, "result", SUCCESS);

    p = cJSON_PrintUnformatted(p_response);
    cJSON_Delete(p_response);
    tcp_send(p_nc, (uint8_t *)p, strlen(p));
    free(p);
}


/**
 * @brief   获取事件序列下标
 * @param   [in] event_id:事件ID
 * @note
 * @return  事件序列下标
 */
static uint8_t pcs_event_array_index_get(uint8_t index, uint16_t event_id)
{
    energy_cabinet_data_t *p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();

    for(uint8_t i = 0; i < PCS_MAX_EVENT_ITEM; i++)
    {
        if(event_id == p_energy_cabinet_data->pcs_data.event_data[i].event_id)
        {
            return i;
        }
    }
    return 0xFF;
}


/**
 * @brief   pcs事件数据处理
 * @param	[in] *p_nc 连接信息 
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
static void pcs_event_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len)
{
    cJSON *p_request = NULL;
    cJSON *p_response = NULL;
    char *p = NULL;
    uint8_t index = 0;
    uint8_t event_array_index = 0xFF;
    uint16_t event_id = 0;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;

    p_request = cJSON_Parse(p_data);
    index = cJSON_GetObjectItem(p_request,"cmuIndex")->valueint;
    TCP_DEBUG_PRINT((int8_t *)"cmu index : %d", index);
    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    event_id = cJSON_GetObjectItem(p_request,"ID")->valueint;
    event_array_index = pcs_event_array_index_get(index, event_id);
    if(event_array_index == 0xFF)
    {
        TCP_DEBUG_PRINT((int8_t *)"event id [0x%04x] not exit", event_id);
        tcp_error_info_send(p_nc, "pcs", "event");
        return;
    }
    p_energy_cabinet_data->pcs_data.event_data[event_array_index].event_id = cJSON_GetObjectItem(p_request,"ID")->valueint;
    p_energy_cabinet_data->pcs_data.event_data[event_array_index].event_code = cJSON_GetObjectItem(p_request,"code")->valueint;
    p_energy_cabinet_data->pcs_data.event_data[event_array_index].event_level = cJSON_GetObjectItem(p_request,"level")->valueint;
    p_energy_cabinet_data->pcs_data.event_data[event_array_index].event_time = time(NULL);

    TCP_DEBUG_PRINT((int8_t *)"event_id: 0x%04x", p_energy_cabinet_data->pcs_data.event_data[event_array_index].event_id);
    TCP_DEBUG_PRINT((int8_t *)"event_code: %d", p_energy_cabinet_data->pcs_data.event_data[event_array_index].event_code);
    TCP_DEBUG_PRINT((int8_t *)"event_level: %d", p_energy_cabinet_data->pcs_data.event_data[event_array_index].event_level);
    TCP_DEBUG_PRINT((int8_t *)"event_time: %d", p_energy_cabinet_data->pcs_data.event_data[event_array_index].event_time);

    cJSON_Delete(p_request);

    p_response = cJSON_CreateObject();
    if(p_response == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_response, "devtype", "pcs");
    cJSON_AddStringToObject(p_response, "cmdtype", "event");
    cJSON_AddNumberToObject(p_response, "result", SUCCESS);

    p = cJSON_PrintUnformatted(p_response);
    cJSON_Delete(p_response);
    tcp_send(p_nc, (uint8_t *)p, strlen(p));
    free(p);
}


/**
 * @brief   pcs事件ID列表初始化
 * @note
 * @return
 */
void pcs_event_id_list_init(void)
{
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;

    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    for(uint8_t i = 0; i < PCS_MAX_EVENT_ITEM; i++)
    {
        p_energy_cabinet_data->pcs_data.event_data[i].event_id = g_pcs_event_list[i];
        p_energy_cabinet_data->pcs_data.event_data[i].event_code = EVENT_END;
        p_energy_cabinet_data->pcs_data.event_data[i].event_level = EVENT_LEVEL3;
    }
}


/**
 * @brief   pcs数据处理
 * @param	[in] *p_nc 连接信息 
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
void pcs_data_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len)
{
    cJSON *p_request = NULL;
    char *p_cmd_type = NULL;
    
    p_request = cJSON_Parse(p_data);
    p_cmd_type = cJSON_GetObjectItem(p_request,"cmdtype")->valuestring;
    if(!strcmp(p_cmd_type, "monitor"))
    {
        pcs_monitor_handle(p_nc, p_data, data_len);
    }
    if(!strcmp(p_cmd_type, "property"))
    {
        pcs_property_handle(p_nc, p_data, data_len);
    }
    if(!strcmp(p_cmd_type, "event"))
    {
        pcs_event_handle(p_nc, p_data, data_len);
    }
    cJSON_Delete(p_request);
}
