#ifndef __TCP_SERVER_SERVICE_H__
#define __TCP_SERVER_SERVICE_H__

#include "sdk_log.h"
#include "mongoose.h"

#if (0)
#define TCP_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else
#define TCP_DEBUG_PRINT(...) {do {} while(0);}
#endif

#define SUCCESS     1
#define FAIL        0

#define EVENT_START         0
#define EVENT_END           1

#define EVENT_LEVEL1        1
#define EVENT_LEVEL2        2
#define EVENT_LEVEL3        3

/**
 * @brief          获取当前时间时间戳
 * @return         [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t get_sys_timestamp(void);


/**
 * @brief   数据接收回调
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
void tcp_send(struct mg_connection *p_nc, uint8_t *p_data, uint16_t data_len);

/**
 * @brief   数据错误处理
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
void tcp_error_info_send(struct mg_connection *p_nc, char *p_dev_type, char *p_cmd_type);

/**
 * @brief   tcp server服务模块初始化
 * @param
 * @note
 * @return
 */
void tcp_server_module_init(void);

#endif