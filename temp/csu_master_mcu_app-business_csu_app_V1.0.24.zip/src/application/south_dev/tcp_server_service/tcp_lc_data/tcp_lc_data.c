#include <string.h>
#include "sdk_public.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "cJSON.h"
#include "app_common.h"
#include "mongoose.h"
#include "tcp_server_service.h"

const uint16_t g_lc_event_list[LC_MAX_EVENT_ITEM] = {
    0x5000, 0x5010, 0x5020, 0x5030, 0x5031, 0x5040, 0x5050, 0x5060, 
    0x5061, 0x5062, 0x5063, 0x5070, 0x5080, 0x5081, 0x5090, 0x50A0, 
    0x50B0, 0x50B1, 0x50C0, 0x50D0, 0x50D1, 0x50E0, 0x50E1, 0x50F0, 
    0x50F1, 0x5100, 0x5101, 0x5102, 0x5103, 0x5104, 0x5105, 0x5106, 
    0x5107, 0x5110, 0x5111, 0x5112, 0x5120, 0x5130, 0x5131, 0x5140, 
    0x5150, 0x5160, 0x5170, 0x5171, 0x5172, 0x5173, 0x5174, 0x5180, 
    0x5190, 0x51A0, 0x51B0, 0x51C0, 0x51C1, 0x51C2, 0x51C3, 0x51D0, 
    0x51D1, 0x51E1, 0x51E2, 0x51E3
};

const uint16_t g_lc_event_level_list[LC_MAX_EVENT_ITEM] = {
    EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, 
    EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, 
    EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, 
    EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, 
    EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, 
    EVENT_LEVEL3, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, 
    EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, 
    EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1
};

/**
 * @brief   液冷监控数据处理
 * @param	[in] *p_nc 连接信息 
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
static void lc_monitor_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len)
{
    cJSON *p_request = NULL;
    cJSON *p_response = NULL;
    cJSON *p_data_item = NULL;
    char *p = NULL;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;

    p_request = cJSON_Parse(p_data);
    p_data_item = cJSON_GetObjectItem(p_request,"data");
    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    p_energy_cabinet_data->lc_data.monitor_data.wp_output = cJSON_GetObjectItem(p_data_item,"wpOutput")->valueint;
    p_energy_cabinet_data->lc_data.monitor_data.fan_output = cJSON_GetObjectItem(p_data_item,"fanOutput")->valueint;
    p_energy_cabinet_data->lc_data.monitor_data.effluent_temp = cJSON_GetObjectItem(p_data_item,"effluentTemp")->valueint;
    p_energy_cabinet_data->lc_data.monitor_data.ascent_temp = cJSON_GetObjectItem(p_data_item,"ascentTemp")->valueint;
    p_energy_cabinet_data->lc_data.monitor_data.effluent_pressure = cJSON_GetObjectItem(p_data_item,"effluentPressure")->valueint;
    p_energy_cabinet_data->lc_data.monitor_data.ascent_pressure = cJSON_GetObjectItem(p_data_item,"ascentPressure")->valueint;
    p_energy_cabinet_data->lc_data.monitor_data.temp = cJSON_GetObjectItem(p_data_item,"temp")->valueint;

    TCP_DEBUG_PRINT((int8_t *)"wp_output : %d", p_energy_cabinet_data->lc_data.monitor_data.wp_output);
    TCP_DEBUG_PRINT((int8_t *)"fan_output : %d", p_energy_cabinet_data->lc_data.monitor_data.fan_output);
    TCP_DEBUG_PRINT((int8_t *)"effluent_temp : %d", p_energy_cabinet_data->lc_data.monitor_data.effluent_temp);
    TCP_DEBUG_PRINT((int8_t *)"ascent_temp : %d", p_energy_cabinet_data->lc_data.monitor_data.ascent_temp);
    TCP_DEBUG_PRINT((int8_t *)"effluent_pressure : %d", p_energy_cabinet_data->lc_data.monitor_data.effluent_pressure);
    TCP_DEBUG_PRINT((int8_t *)"ascent_pressure : %d", p_energy_cabinet_data->lc_data.monitor_data.ascent_pressure);
    TCP_DEBUG_PRINT((int8_t *)"temp : %d", p_energy_cabinet_data->lc_data.monitor_data.temp);

    cJSON_Delete(p_request);

    p_response = cJSON_CreateObject();
    if(p_response == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_response, "devtype", "lc");
    cJSON_AddStringToObject(p_response, "cmdtype", "monitor");
    cJSON_AddNumberToObject(p_response, "result", SUCCESS);
    p_energy_cabinet_data->lc_data.monitor_data.init_status = SUCCESS;
    p = cJSON_PrintUnformatted(p_response);
    cJSON_Delete(p_response);
    tcp_send(p_nc, (uint8_t *)p, strlen(p));
    free(p);

}


/**
 * @brief   液冷属性数据处理
 * @param	[in] *p_nc 连接信息 
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
static void lc_property_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len)
{
    cJSON *p_request = NULL;
    cJSON *p_response = NULL;
    cJSON *p_data_item = NULL;
    char *p = NULL;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;

    p_request = cJSON_Parse(p_data);
    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    p_data_item = cJSON_GetObjectItem(p_request,"data");
    strcpy((char *)p_energy_cabinet_data->lc_data.property_data.lc_sn, cJSON_GetObjectItem(p_data_item,"sn")->valuestring);
    p_energy_cabinet_data->lc_data.property_data.dev_type = cJSON_GetObjectItem(p_data_item,"devType")->valueint;
    p_energy_cabinet_data->lc_data.property_data.comm_status = cJSON_GetObjectItem(p_data_item,"commStatus")->valueint;
    p_energy_cabinet_data->lc_data.property_data.work_status = cJSON_GetObjectItem(p_data_item,"workStatus")->valueint;
    p_energy_cabinet_data->lc_data.property_data.work_mode = cJSON_GetObjectItem(p_data_item,"runMode")->valueint;
    p_energy_cabinet_data->lc_data.property_data.warn_status = cJSON_GetObjectItem(p_data_item,"warnStatus")->valueint;
    p_energy_cabinet_data->lc_data.property_data.wp_status = cJSON_GetObjectItem(p_data_item,"wpStatus")->valueint;
    p_energy_cabinet_data->lc_data.property_data.cp_status = cJSON_GetObjectItem(p_data_item,"cpStatus")->valueint;
    p_energy_cabinet_data->lc_data.property_data.eh_status = cJSON_GetObjectItem(p_data_item,"ehStatus")->valueint;
    p_energy_cabinet_data->lc_data.property_data.fan_status = cJSON_GetObjectItem(p_data_item,"fanStatus")->valueint;

    TCP_DEBUG_PRINT((int8_t *)"lc sn : %s", p_energy_cabinet_data->lc_data.property_data.lc_sn);
    TCP_DEBUG_PRINT((int8_t *)"dev_type : %d", p_energy_cabinet_data->lc_data.property_data.dev_type);
    TCP_DEBUG_PRINT((int8_t *)"comm_status : %d", p_energy_cabinet_data->lc_data.property_data.comm_status);
    TCP_DEBUG_PRINT((int8_t *)"work_status : %d", p_energy_cabinet_data->lc_data.property_data.work_status);
    TCP_DEBUG_PRINT((int8_t *)"work_mode : %d", p_energy_cabinet_data->lc_data.property_data.work_mode);
    TCP_DEBUG_PRINT((int8_t *)"warn_status : %d", p_energy_cabinet_data->lc_data.property_data.warn_status);
    TCP_DEBUG_PRINT((int8_t *)"wp_status : %d", p_energy_cabinet_data->lc_data.property_data.wp_status);
    TCP_DEBUG_PRINT((int8_t *)"cp_status : %d", p_energy_cabinet_data->lc_data.property_data.cp_status);
    TCP_DEBUG_PRINT((int8_t *)"eh_status : %d", p_energy_cabinet_data->lc_data.property_data.eh_status);
    TCP_DEBUG_PRINT((int8_t *)"fan_status : %d", p_energy_cabinet_data->lc_data.property_data.fan_status);

    cJSON_Delete(p_request);

    p_response = cJSON_CreateObject();
    if(p_response == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_response, "devtype", "lc");
    cJSON_AddStringToObject(p_response, "cmdtype", "property");
    cJSON_AddNumberToObject(p_response, "result", SUCCESS);

    p = cJSON_PrintUnformatted(p_response);
    cJSON_Delete(p_response);
    tcp_send(p_nc, (uint8_t *)p, strlen(p));
    free(p);
}


/**
 * @brief   获取事件序列下标
 * @param   [in] event_id:事件ID
 * @note
 * @return  事件序列下标
 */
static uint8_t lc_event_array_index_get(uint8_t index, uint16_t event_id)
{
    energy_cabinet_data_t *p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();

    for(uint8_t i = 0; i < LC_MAX_EVENT_ITEM; i++)
    {
        if(event_id == p_energy_cabinet_data->lc_data.event_data[i].event_id)
        {
            return i;
        }
    }
    return 0xFF;
}


/**
 * @brief   液冷事件数据处理
 * @param	[in] *p_nc 连接信息 
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
static void lc_event_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len)
{
    cJSON *p_request = NULL;
    cJSON *p_response = NULL;
    char *p = NULL;
    uint8_t index = 0;
    uint8_t event_array_index = 0xFF;
    uint16_t event_id = 0;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;

    p_request = cJSON_Parse(p_data);
    index = cJSON_GetObjectItem(p_request,"cmuIndex")->valueint;
    TCP_DEBUG_PRINT((int8_t *)"cmu index : %d", index);
    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    event_id = cJSON_GetObjectItem(p_request,"ID")->valueint;
    event_array_index = lc_event_array_index_get(index, event_id);
    if(event_array_index == 0xFF)
    {
        TCP_DEBUG_PRINT((int8_t *)"event id [0x%04x] not exit", event_id);
        tcp_error_info_send(p_nc, "lc", "event");
        return;
    }
    p_energy_cabinet_data->lc_data.event_data[event_array_index].event_id = cJSON_GetObjectItem(p_request,"ID")->valueint;
    p_energy_cabinet_data->lc_data.event_data[event_array_index].event_code = cJSON_GetObjectItem(p_request,"code")->valueint;
    p_energy_cabinet_data->lc_data.event_data[event_array_index].event_level = cJSON_GetObjectItem(p_request,"level")->valueint;
    p_energy_cabinet_data->lc_data.event_data[event_array_index].event_time = time(NULL);

    TCP_DEBUG_PRINT((int8_t *)"event_id: 0x%04x", p_energy_cabinet_data->lc_data.event_data[event_array_index].event_id);
    TCP_DEBUG_PRINT((int8_t *)"event_code: %d", p_energy_cabinet_data->lc_data.event_data[event_array_index].event_code);
    TCP_DEBUG_PRINT((int8_t *)"event_level: %d", p_energy_cabinet_data->lc_data.event_data[event_array_index].event_level);
    TCP_DEBUG_PRINT((int8_t *)"event_time: %d", p_energy_cabinet_data->lc_data.event_data[event_array_index].event_time);

    cJSON_Delete(p_request);

    p_response = cJSON_CreateObject();
    if(p_response == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_response, "devtype", "lc");
    cJSON_AddStringToObject(p_response, "cmdtype", "event");
    cJSON_AddNumberToObject(p_response, "result", SUCCESS);

    p = cJSON_PrintUnformatted(p_response);
    cJSON_Delete(p_response);
    tcp_send(p_nc, (uint8_t *)p, strlen(p));
    free(p);
}


/**
 * @brief   消防事件ID列表初始化
 * @note
 * @return
 */
void lc_event_id_list_init(void)
{
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;

    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    for(uint8_t i = 0; i < LC_MAX_EVENT_ITEM; i++)
    {
        p_energy_cabinet_data->lc_data.event_data[i].event_id = g_lc_event_list[i];
        p_energy_cabinet_data->lc_data.event_data[i].event_code = EVENT_END;
        p_energy_cabinet_data->lc_data.event_data[i].event_level = g_lc_event_level_list[i];
    }
}


/**
 * @brief   液冷数据处理
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
void lc_data_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len)
{
    cJSON *p_request = NULL;
    char *p_cmd_type = NULL;
    
    p_request = cJSON_Parse(p_data);
    p_cmd_type = cJSON_GetObjectItem(p_request,"cmdtype")->valuestring;
    if(!strcmp(p_cmd_type, "monitor"))
    {
        lc_monitor_handle(p_nc, p_data, data_len);
    }
    if(!strcmp(p_cmd_type, "property"))
    {
        lc_property_handle(p_nc, p_data, data_len);
    }
    if(!strcmp(p_cmd_type, "event"))
    {
        lc_event_handle(p_nc, p_data, data_len);
    }
    cJSON_Delete(p_request);
}
