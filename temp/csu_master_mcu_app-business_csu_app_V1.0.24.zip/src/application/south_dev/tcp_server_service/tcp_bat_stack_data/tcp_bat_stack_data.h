#ifndef __TCP_BAT_STACK_DATA_H__
#define __TCP_BAT_STACK_DATA_H__

#include "mongoose.h"


/**
 * @brief   电池堆数据处理
 * @param	[in] *p_nc 连接信息 
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
void bat_stack_data_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len);


#endif