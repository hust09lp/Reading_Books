#include <string.h>
#include "sdk_public.h"
#include "sdk_shm.h"
#include "data_shm.h"
#include "cJSON.h"
#include "app_common.h"
#include "mongoose.h"
#include "tcp_server_service.h"


/**
 * @brief   电池堆监控数据处理
 * @param	[in] *p_nc 连接信息 
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
static void bat_stack_monitor_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len)
{
    cJSON *p_request = NULL;
    cJSON *p_response = NULL;
    cJSON *p_data_item = NULL;
    char *p = NULL;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;

    p_request = cJSON_Parse(p_data);
    p_data_item = cJSON_GetObjectItem(p_request,"data");
    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    p_energy_cabinet_data->bat_stack_data.monitor_data.soc = cJSON_GetObjectItem(p_data_item,"soc")->valueint;
    p_energy_cabinet_data->bat_stack_data.monitor_data.soh = cJSON_GetObjectItem(p_data_item,"soh")->valueint;
    p_energy_cabinet_data->bat_stack_data.monitor_data.temp_m = cJSON_GetObjectItem(p_data_item,"temM")->valueint;
    p_energy_cabinet_data->bat_stack_data.monitor_data.charge = cJSON_GetObjectItem(p_data_item,"char")->valueint;
    p_energy_cabinet_data->bat_stack_data.monitor_data.discharge = cJSON_GetObjectItem(p_data_item,"dischar")->valueint;
    p_energy_cabinet_data->bat_stack_data.monitor_data.total_charge_time = cJSON_GetObjectItem(p_data_item,"totalCharTm")->valueint;
    p_energy_cabinet_data->bat_stack_data.monitor_data.volt = cJSON_GetObjectItem(p_data_item,"Volt")->valueint;
    p_energy_cabinet_data->bat_stack_data.monitor_data.current = cJSON_GetObjectItem(p_data_item,"Curr")->valueint;
    p_energy_cabinet_data->bat_stack_data.monitor_data.power = cJSON_GetObjectItem(p_data_item,"Power")->valueint;
    p_energy_cabinet_data->bat_stack_data.monitor_data.total_energy_charge = cJSON_GetObjectItem(p_data_item,"totalChar")->valueint;
    p_energy_cabinet_data->bat_stack_data.monitor_data.total_energy_discharge = cJSON_GetObjectItem(p_data_item,"totalDischar")->valueint;
    p_energy_cabinet_data->bat_stack_data.monitor_data.insulation = cJSON_GetObjectItem(p_data_item,"insulation")->valueint;

    TCP_DEBUG_PRINT((int8_t *)"soc : %d", p_energy_cabinet_data->bat_stack_data.monitor_data.soc);
    TCP_DEBUG_PRINT((int8_t *)"soh : %d", p_energy_cabinet_data->bat_stack_data.monitor_data.soh);
    TCP_DEBUG_PRINT((int8_t *)"temp_m : %d", p_energy_cabinet_data->bat_stack_data.monitor_data.temp_m);
    TCP_DEBUG_PRINT((int8_t *)"charge : %d", p_energy_cabinet_data->bat_stack_data.monitor_data.charge);
    TCP_DEBUG_PRINT((int8_t *)"discharge : %d", p_energy_cabinet_data->bat_stack_data.monitor_data.discharge);
    TCP_DEBUG_PRINT((int8_t *)"total_charge_time : %d", p_energy_cabinet_data->bat_stack_data.monitor_data.total_charge_time);
    TCP_DEBUG_PRINT((int8_t *)"volt : %d", p_energy_cabinet_data->bat_stack_data.monitor_data.volt);
    TCP_DEBUG_PRINT((int8_t *)"current : %d", p_energy_cabinet_data->bat_stack_data.monitor_data.current);
    TCP_DEBUG_PRINT((int8_t *)"power : %d", p_energy_cabinet_data->bat_stack_data.monitor_data.power);
    TCP_DEBUG_PRINT((int8_t *)"total_energy_charge : %d", p_energy_cabinet_data->bat_stack_data.monitor_data.total_energy_charge);
    TCP_DEBUG_PRINT((int8_t *)"total_energy_discharge : %d", p_energy_cabinet_data->bat_stack_data.monitor_data.total_energy_discharge);
    TCP_DEBUG_PRINT((int8_t *)"insulation : %d", p_energy_cabinet_data->bat_stack_data.monitor_data.insulation);

    cJSON_Delete(p_request);

    p_response = cJSON_CreateObject();
    if(p_response == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_response, "devtype", "batstack");
    cJSON_AddStringToObject(p_response, "cmdtype", "monitor");
    cJSON_AddNumberToObject(p_response, "result", SUCCESS);
    p_energy_cabinet_data->bat_stack_data.monitor_data.init_status = SUCCESS;
    p = cJSON_PrintUnformatted(p_response);
    cJSON_Delete(p_response);
    tcp_send(p_nc, (uint8_t *)p, strlen(p));
    free(p);

}


/**
 * @brief   电池堆属性数据处理
 * @param	[in] *p_nc 连接信息 
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
static void bat_stack_property_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len)
{
    cJSON *p_request = NULL;
    cJSON *p_response = NULL;
    cJSON *p_data_item = NULL;
    char *p = NULL;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;

    p_request = cJSON_Parse(p_data);
    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    p_data_item = cJSON_GetObjectItem(p_request,"data");
    strcpy((char *)p_energy_cabinet_data->bat_stack_data.property_data.bat_stack_sn, cJSON_GetObjectItem(p_data_item,"sn")->valuestring);
    p_energy_cabinet_data->bat_stack_data.property_data.comm_status = cJSON_GetObjectItem(p_data_item,"commStatus")->valueint;
    p_energy_cabinet_data->bat_stack_data.property_data.work_status = cJSON_GetObjectItem(p_data_item,"workStatus")->valueint;
    p_energy_cabinet_data->bat_stack_data.property_data.char_prohibit = cJSON_GetObjectItem(p_data_item,"charProhibit")->valueint;
    p_energy_cabinet_data->bat_stack_data.property_data.dischar_prohibit = cJSON_GetObjectItem(p_data_item,"discharProhibit")->valueint;
    p_energy_cabinet_data->bat_stack_data.property_data.bcu_num = cJSON_GetObjectItem(p_data_item,"bcuNum")->valueint;
    p_energy_cabinet_data->bat_stack_data.property_data.pack_num = cJSON_GetObjectItem(p_data_item,"pcakNum")->valueint;
    p_energy_cabinet_data->bat_stack_data.property_data.cell_num = cJSON_GetObjectItem(p_data_item,"cellNum")->valueint;

    TCP_DEBUG_PRINT((int8_t *)"bat stack sn : %s", p_energy_cabinet_data->bat_stack_data.property_data.bat_stack_sn);
    TCP_DEBUG_PRINT((int8_t *)"comm_status : %d", p_energy_cabinet_data->bat_stack_data.property_data.comm_status);
    TCP_DEBUG_PRINT((int8_t *)"work_status : %d", p_energy_cabinet_data->bat_stack_data.property_data.work_status);
    TCP_DEBUG_PRINT((int8_t *)"char_prohibit : %d", p_energy_cabinet_data->bat_stack_data.property_data.char_prohibit);
    TCP_DEBUG_PRINT((int8_t *)"dischar_prohibit : %d", p_energy_cabinet_data->bat_stack_data.property_data.dischar_prohibit);
    TCP_DEBUG_PRINT((int8_t *)"bcu_num : %d", p_energy_cabinet_data->bat_stack_data.property_data.bcu_num);
    TCP_DEBUG_PRINT((int8_t *)"pack_num : %d", p_energy_cabinet_data->bat_stack_data.property_data.pack_num);
    TCP_DEBUG_PRINT((int8_t *)"cell_num : %d", p_energy_cabinet_data->bat_stack_data.property_data.cell_num);

    cJSON_Delete(p_request);

    p_response = cJSON_CreateObject();
    if(p_response == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_response, "devtype", "batstack");
    cJSON_AddStringToObject(p_response, "cmdtype", "property");
    cJSON_AddNumberToObject(p_response, "result", SUCCESS);

    p = cJSON_PrintUnformatted(p_response);
    cJSON_Delete(p_response);
    tcp_send(p_nc, (uint8_t *)p, strlen(p));
    free(p);
}


/**
 * @brief   电池堆数据处理
 * @param	[in] *p_nc 连接信息 
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
void bat_stack_data_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len)
{
    cJSON *p_request = NULL;
    char *p_cmd_type = NULL;
    
    p_request = cJSON_Parse(p_data);
    p_cmd_type = cJSON_GetObjectItem(p_request,"cmdtype")->valuestring;
    if(!strcmp(p_cmd_type, "monitor"))
    {
        bat_stack_monitor_handle(p_nc, p_data, data_len);
    }
    if(!strcmp(p_cmd_type, "property"))
    {
        bat_stack_property_handle(p_nc, p_data, data_len);
    }
    cJSON_Delete(p_request);
}
