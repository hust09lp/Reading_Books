#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include "data_shm.h"
#include "sdk_shm.h"
#include "errors.h"
#include "sdk_public.h"
#include "sofar_log.h"
#include "mongoose.h"
#include "cJSON.h"
#include "app_common.h"
#include "tcp_cmu_data.h"
#include "tcp_pcs_data.h"
#include "tcp_bms_data.h"
#include "tcp_bat_stack_data.h"
#include "tcp_fc_data.h"
#include "tcp_lc_data.h"
#include "tcp_server_service.h"


#define TCP_SERVER_ADDR "0.0.0.0:2000" 
#define TIME_DIFF 8 * 60 * 60

/**
 * @brief          获取当前时间时间戳
 * @return         [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t get_sys_timestamp(void)
{
    sdk_rtc_t rtc_time = {0};
    struct tm local_time = {0};
    int32_t ret;
    time_t curr_timestamp = 0;

    ret = sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
    if (ret != SF_OK)
    {
        printf("rtc get failed");
    }

    local_time.tm_year = (int32_t)(rtc_time.tm_year + 100);
    local_time.tm_mon  = (int32_t)(rtc_time.tm_mon - 1);
    local_time.tm_mday = (int32_t)(rtc_time.tm_day);
    local_time.tm_hour = (int32_t)(rtc_time.tm_hour);
    local_time.tm_min  = (int32_t)(rtc_time.tm_min);
    local_time.tm_sec  = (int32_t)(rtc_time.tm_sec);
    curr_timestamp = mktime(&local_time) - TIME_DIFF;

    return curr_timestamp;
}


/**
 * @brief   获取cmu设备编码
 * @param   [in] p_nc:连接信息
 * @note
 * @return  cmu设备编码
 */
static uint8_t dev_index_get(struct mg_connection *p_nc)
{
    char ip[16] = {0};

    sprintf(ip, "%d:%d:%d:%d", p_nc->rem.ip[0], p_nc->rem.ip[1], p_nc->rem.ip[2], p_nc->rem.ip[3]);

    if(strcmp(ip, CMU1_IP))
    {
        return 1;
    }
    else if(strcmp(ip, CMU2_IP))
    {
        return 2;
    }
    else if(strcmp(ip, CMU3_IP))
    {
        return 3;
    }
    else if(strcmp(ip, CMU4_IP))
    {
        return 4;
    }
    else if(strcmp(ip, CMU5_IP))
    {
        return 5;
    }
    else if(strcmp(ip, CMU6_IP))
    {
        return 6;
    }

    return 0;
}


/**
 * @brief   TCP数据处理
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
static void tcp_data_handle(struct mg_connection *p_nc, uint8_t *p_data, uint16_t data_len)
{
    cJSON *p_request = NULL;
    char *p_dev_type = NULL;
    char *p_json_print = NULL;
    uint8_t dev_index = 0;

    p_request = cJSON_Parse((char *)p_data);
    if(p_request == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"parse request failed.");
        return;
    }
    p_json_print = cJSON_Print(p_request);
    TCP_DEBUG_PRINT((int8_t *)"recv:%s\n", p_json_print);
    free(p_json_print);

    dev_index = dev_index_get(p_nc);
    if(!dev_index)
    {
        cJSON_Delete(p_request);
        return;
    }

    p_dev_type = cJSON_GetObjectItem(p_request,"devtype")->valuestring;
    if(!strcmp(p_dev_type, "cmu"))
    {
        TCP_DEBUG_PRINT((int8_t *)"dev type is %s", p_dev_type);
        cmu_data_handle(p_nc, (char *)p_data, data_len, dev_index);
    }
    if(!strcmp(p_dev_type, "pcs"))
    {
        TCP_DEBUG_PRINT((int8_t *)"dev type is %s", p_dev_type);
        pcs_data_handle(p_nc, (char *)p_data, data_len);
    }
    if(!strcmp(p_dev_type, "bms"))
    {
        TCP_DEBUG_PRINT((int8_t *)"dev type is %s", p_dev_type);
        bms_data_handle(p_nc, (char *)p_data, data_len);
    }
    if(!strcmp(p_dev_type, "batstack"))
    {
        TCP_DEBUG_PRINT((int8_t *)"dev type is %s", p_dev_type);
        bat_stack_data_handle(p_nc, (char *)p_data, data_len);
    }
    if(!strcmp(p_dev_type, "fc"))
    {
        TCP_DEBUG_PRINT((int8_t *)"dev type is %s", p_dev_type);
        fc_data_handle(p_nc, (char *)p_data, data_len);
    }
    if(!strcmp(p_dev_type, "lc"))
    {
        TCP_DEBUG_PRINT((int8_t *)"dev type is %s", p_dev_type);
        lc_data_handle(p_nc, (char *)p_data, data_len);
    }
    cJSON_Delete(p_request);
}


/**
 * @brief   数据接收回调
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
void tcp_send(struct mg_connection *p_nc, uint8_t *p_data, uint16_t data_len)
{
    cJSON *p_request = NULL;
    char *p_json_print = NULL;

    if(p_nc == NULL)
    {
        return;
    }
    p_request = cJSON_Parse((char *)p_data);
    if(p_request == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"parse request failed.");
        return;
    }
    p_json_print = cJSON_Print(p_request);
    TCP_DEBUG_PRINT((int8_t *)"send:%s\n", p_json_print);
    cJSON_Delete(p_request);
    free(p_json_print);
    mg_send(p_nc, p_data, data_len);
}


/**
 * @brief   数据错误处理
 * @param   [in] p_nc:连接信息
 * @param   [in] p_dev_type:设备类型
 * @param   [in] p_cmd_type:指令类型
 * @note
 * @return
 */
void tcp_error_info_send(struct mg_connection *p_nc, char *p_dev_type, char *p_cmd_type)
{
    cJSON *p_response = NULL;
    char *p = NULL;

    p_response = cJSON_CreateObject();
    if(p_response == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_response, "devtype", p_dev_type);
    cJSON_AddStringToObject(p_response, "cmdtype", p_cmd_type);
    cJSON_AddNumberToObject(p_response, "result", FAIL);

    p = cJSON_PrintUnformatted(p_response);
    cJSON_Delete(p_response);
    tcp_send(p_nc, (uint8_t *)p, strlen(p));
    free(p);
}



/**
 * @brief   数据接收回调
 * @param   [in] p_nc:网络连接信息
 * @param   [in] ev:消息类别
 * @param   [in] p_ev_data:数据内容
 * @note
 * @return
 */
static void ev_handler(struct mg_connection *p_nc, int ev, void *p_ev_data)
{
    struct mg_iobuf *p_recv = NULL;

    switch(ev)
    {
        case MG_EV_ACCEPT:
            TCP_DEBUG_PRINT((int8_t *)"client connected");
            break;

        case MG_EV_READ:
            // TCP_DEBUG_PRINT((int8_t *)"data recv");
            p_recv = &p_nc->recv;
            // TCP_DEBUG_PRINT((int8_t *)"%s\n", p_recv->buf);
            tcp_data_handle(p_nc, p_recv->buf, p_recv->len);
            memset(p_recv->buf, 0, p_recv->len);
            p_recv->len = 0;
            break;

        default:
            break;
    }
}


/**
 * @brief   事件列表初始化
 * @note
 * @return
 */
static void event_id_list_init(void)
{
    pcs_event_id_list_init();
    bms_event_id_list_init();
    fc_event_id_list_init();
    lc_event_id_list_init();
}


/**
 * @brief   tcp server服务线程
 * @param   [in] arg
 * @note
 * @return
 */
void *tcp_server_service(void *arg)
{
	struct mg_mgr mgr;
	struct mg_connection *p_nc;

    // mg_log_set(MG_LL_DEBUG);  // Set log level
    //TCP SERVER初始化
	mg_mgr_init(&mgr);
	p_nc = mg_listen(&mgr, TCP_SERVER_ADDR, ev_handler, NULL);
	if(p_nc == NULL)
	{
		TCP_DEBUG_PRINT((int8_t *)"init net connection failed");
		mg_mgr_free(&mgr);
		return NULL;
	}

    event_id_list_init();

	while(1)
	{
		mg_mgr_poll(&mgr,500);
	}
	mg_mgr_free(&mgr);

}



/**
 * @brief   tcp server服务模块初始化
 * @param
 * @note
 * @return
 */
void tcp_server_module_init(void)
{
	pthread_t tcp_server;
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	if(pthread_create(&tcp_server, &attr, tcp_server_service, NULL) != 0)
	{
		perror("pthread_create tcp server service");
	}
	pthread_attr_destroy(&attr);
}