#include <string.h>
#include "sdk_public.h"
#include "sdk_shm.h"
#include "data_shm.h"
#include "cJSON.h"
#include "app_common.h"
#include "mongoose.h"
#include "tcp_pcs_data.h"
#include "tcp_server_service.h"

const uint16_t g_fc_event_list[FC_MAX_EVENT_ITEM] = {
    0x4000, 0x4010, 0x4011, 0x4012, 0x4013, 0x4014, 0x4015, 0x4016, 
    0x4017, 0x4020, 0x4021, 0x4022, 0x4023, 0x4030, 0x4031, 0x4032, 
    0x4033, 0x4040, 0x4041, 0x4042, 0x4043, 0x4050, 0x4051, 0x4052, 
    0x4053, 0x4060, 0x4061, 0x4062, 0x4063, 0x4070, 0x4071, 0x4072, 
    0x4073, 0x4080, 0x4081, 0x4082, 0x4083, 0x4090, 0x4091, 0x4092, 
    0x4093, 0x40A0, 0x40B0, 0x40B1, 0x40B2, 0x40B3, 0x40C0, 0x40D0, 
    0x40E0, 0x40F0

};

const uint16_t g_fc_event_level_list[FC_MAX_EVENT_ITEM] = {
    EVENT_LEVEL3, EVENT_LEVEL1, EVENT_LEVEL3, EVENT_LEVEL1, EVENT_LEVEL3, EVENT_LEVEL1, EVENT_LEVEL3, EVENT_LEVEL1, 
    EVENT_LEVEL3, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, 
    EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, 
    EVENT_LEVEL1, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, 
    EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL3, 
    EVENT_LEVEL3, EVENT_LEVEL3, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, EVENT_LEVEL1, 
    EVENT_LEVEL1, EVENT_LEVEL1

};

/**
 * @brief   消防监控数据处理
 * @param	[in] *p_nc 连接信息 
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
static void fc_monitor_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len)
{
    cJSON *p_request = NULL;
    cJSON *p_response = NULL;
    cJSON *p_data_item = NULL;
    char *p = NULL;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;

    p_request = cJSON_Parse(p_data);
    p_data_item = cJSON_GetObjectItem(p_request,"data");
    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    p_energy_cabinet_data->fc_data.monitor_data.temp = cJSON_GetObjectItem(p_data_item,"temp")->valueint;
    p_energy_cabinet_data->fc_data.monitor_data.co = cJSON_GetObjectItem(p_data_item,"co")->valueint;
    p_energy_cabinet_data->fc_data.monitor_data.pm25 = cJSON_GetObjectItem(p_data_item,"pm25")->valueint;

    TCP_DEBUG_PRINT((int8_t *)"temp : %d", p_energy_cabinet_data->fc_data.monitor_data.temp);
    TCP_DEBUG_PRINT((int8_t *)"co : %d", p_energy_cabinet_data->fc_data.monitor_data.co);
    TCP_DEBUG_PRINT((int8_t *)"pm25 : %d", p_energy_cabinet_data->fc_data.monitor_data.pm25);

    cJSON_Delete(p_request);

    p_response = cJSON_CreateObject();
    if(p_response == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_response, "devtype", "fc");
    cJSON_AddStringToObject(p_response, "cmdtype", "monitor");
    cJSON_AddNumberToObject(p_response, "result", SUCCESS);
    p_energy_cabinet_data->fc_data.monitor_data.init_status = SUCCESS;
    p = cJSON_PrintUnformatted(p_response);
    cJSON_Delete(p_response);
    tcp_send(p_nc, (uint8_t *)p, strlen(p));
    free(p);

}


/**
 * @brief   消防属性数据处理
 * @param	[in] *p_nc 连接信息 
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
static void fc_property_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len)
{
    cJSON *p_request = NULL;
    cJSON *p_response = NULL;
    cJSON *p_data_item = NULL;
    char *p = NULL;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;

    p_request = cJSON_Parse(p_data);
    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    p_data_item = cJSON_GetObjectItem(p_request,"data");
    strcpy((char *)p_energy_cabinet_data->fc_data.property_data.fc_sn, cJSON_GetObjectItem(p_data_item,"sn")->valuestring);
    p_energy_cabinet_data->fc_data.property_data.dev_type = cJSON_GetObjectItem(p_data_item,"devType")->valueint;
    p_energy_cabinet_data->fc_data.property_data.comm_status = cJSON_GetObjectItem(p_data_item,"commStatus")->valueint;
    p_energy_cabinet_data->fc_data.property_data.work_status = cJSON_GetObjectItem(p_data_item,"workStatus")->valueint;
    p_energy_cabinet_data->fc_data.property_data.sd_status = cJSON_GetObjectItem(p_data_item,"sdStatus")->valueint;
    p_energy_cabinet_data->fc_data.property_data.td_status = cJSON_GetObjectItem(p_data_item,"tdStatus")->valueint;

    TCP_DEBUG_PRINT((int8_t *)"fc sn : %s", p_energy_cabinet_data->fc_data.property_data.fc_sn);
    TCP_DEBUG_PRINT((int8_t *)"dev_type : %d", p_energy_cabinet_data->fc_data.property_data.dev_type);
    TCP_DEBUG_PRINT((int8_t *)"comm_status : %d", p_energy_cabinet_data->fc_data.property_data.comm_status);
    TCP_DEBUG_PRINT((int8_t *)"work_status : %d", p_energy_cabinet_data->fc_data.property_data.work_status);
    TCP_DEBUG_PRINT((int8_t *)"sd_status : %d", p_energy_cabinet_data->fc_data.property_data.sd_status);
    TCP_DEBUG_PRINT((int8_t *)"td_status : %d", p_energy_cabinet_data->fc_data.property_data.td_status);

    cJSON_Delete(p_request);

    p_response = cJSON_CreateObject();
    if(p_response == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_response, "devtype", "fc");
    cJSON_AddStringToObject(p_response, "cmdtype", "property");
    cJSON_AddNumberToObject(p_response, "result", SUCCESS);

    p = cJSON_PrintUnformatted(p_response);
    cJSON_Delete(p_response);
    tcp_send(p_nc, (uint8_t *)p, strlen(p));
    free(p);
}


/**
 * @brief   获取事件序列下标
 * @param   [in] event_id:事件ID
 * @note
 * @return  事件序列下标
 */
static uint8_t fc_event_array_index_get(uint8_t index, uint16_t event_id)
{
    energy_cabinet_data_t *p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();

    for(uint8_t i = 0; i < FC_MAX_EVENT_ITEM; i++)
    {
        if(event_id == p_energy_cabinet_data->fc_data.event_data[i].event_id)
        {
            return i;
        }
    }
    return 0xFF;
}


/**
 * @brief   消防事件数据处理
 * @param	[in] *p_nc 连接信息 
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
static void fc_event_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len)
{
    cJSON *p_request = NULL;
    cJSON *p_response = NULL;
    char *p = NULL;
    uint8_t index = 0;
    uint8_t event_array_index = 0xFF;
    uint16_t event_id = 0;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;

    p_request = cJSON_Parse(p_data);
    index = cJSON_GetObjectItem(p_request,"cmuIndex")->valueint;
    TCP_DEBUG_PRINT((int8_t *)"cmu index : %d", index);
    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    event_id = cJSON_GetObjectItem(p_request,"ID")->valueint;
    event_array_index = fc_event_array_index_get(index, event_id);
    if(event_array_index == 0xFF)
    {
        TCP_DEBUG_PRINT((int8_t *)"event id [0x%04x] not exit", event_id);
        tcp_error_info_send(p_nc, "fc", "event");
        return;
    }
    p_energy_cabinet_data->fc_data.event_data[event_array_index].event_id = cJSON_GetObjectItem(p_request,"ID")->valueint;
    p_energy_cabinet_data->fc_data.event_data[event_array_index].event_code = cJSON_GetObjectItem(p_request,"code")->valueint;
    p_energy_cabinet_data->fc_data.event_data[event_array_index].event_level = cJSON_GetObjectItem(p_request,"level")->valueint;
    p_energy_cabinet_data->fc_data.event_data[event_array_index].event_time = time(NULL);

    TCP_DEBUG_PRINT((int8_t *)"event_id: 0x%04x", p_energy_cabinet_data->fc_data.event_data[event_array_index].event_id);
    TCP_DEBUG_PRINT((int8_t *)"event_code: %d", p_energy_cabinet_data->fc_data.event_data[event_array_index].event_code);
    TCP_DEBUG_PRINT((int8_t *)"event_level: %d", p_energy_cabinet_data->fc_data.event_data[event_array_index].event_level);
    TCP_DEBUG_PRINT((int8_t *)"event_time: %d", p_energy_cabinet_data->fc_data.event_data[event_array_index].event_time);

    cJSON_Delete(p_request);

    p_response = cJSON_CreateObject();
    if(p_response == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_response, "devtype", "fc");
    cJSON_AddStringToObject(p_response, "cmdtype", "event");
    cJSON_AddNumberToObject(p_response, "result", SUCCESS);

    p = cJSON_PrintUnformatted(p_response);
    cJSON_Delete(p_response);
    tcp_send(p_nc, (uint8_t *)p, strlen(p));
    free(p);
}


/**
 * @brief   消防事件ID列表初始化
 * @note
 * @return
 */
void fc_event_id_list_init(void)
{
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;

    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    for(uint8_t i = 0; i < FC_MAX_EVENT_ITEM; i++)
    {
        p_energy_cabinet_data->fc_data.event_data[i].event_id = g_fc_event_list[i];
        p_energy_cabinet_data->fc_data.event_data[i].event_code = EVENT_END;
        p_energy_cabinet_data->fc_data.event_data[i].event_level = g_fc_event_level_list[i];
    }
}


/**
 * @brief   消防数据处理
 * @param	[in] *p_nc 连接信息 
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
void fc_data_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len)
{
    cJSON *p_request = NULL;
    char *p_cmd_type = NULL;
    
    p_request = cJSON_Parse(p_data);
    p_cmd_type = cJSON_GetObjectItem(p_request,"cmdtype")->valuestring;
    if(!strcmp(p_cmd_type, "monitor"))
    {
        fc_monitor_handle(p_nc, p_data, data_len);
    }
    if(!strcmp(p_cmd_type, "property"))
    {
        fc_property_handle(p_nc, p_data, data_len);
    }
    if(!strcmp(p_cmd_type, "event"))
    {
        fc_event_handle(p_nc, p_data, data_len);
    }
    cJSON_Delete(p_request);
}
