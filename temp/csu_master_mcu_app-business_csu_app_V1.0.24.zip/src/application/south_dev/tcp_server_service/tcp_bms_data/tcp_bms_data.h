#ifndef __TCP_BMS_DATA_H__
#define __TCP_BMS_DATA_H__

#include "mongoose.h"

/**
 * @brief   bms事件ID列表初始化
 * @note
 * @return
 */
void bms_event_id_list_init(void);

/**
 * @brief   bms数据处理
 * @param	[in] *p_nc 连接信息 
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
void bms_data_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len);


#endif