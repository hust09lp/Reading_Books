#include <string.h>
#include "sdk_public.h"
#include "sdk_shm.h"
#include "data_shm.h"
#include "cJSON.h"
#include "app_common.h"
#include "mongoose.h"
#include "tcp_server_service.h"

const uint16_t g_bms_event_list[BMS_MAX_EVENT_ITEM] = {
    0x2000, 0x2010, 0x2011, 0x2020, 0x2030, 0x2040, 0x2050, 0x2060, 
    0x2061, 0x2062, 0x2070, 0x2071, 0x2072, 0x2073, 0x2080, 0x2090, 
    0x2091, 0x20A0, 0x20B0, 0x20C0, 0x20D0, 0x20E0, 0x20E1, 0x20F0, 
    0x2100, 0x2110, 0x2111, 0x2120, 0x2130
};

/**
 * @brief   bms监控数据处理
 * @param	[in] *p_nc 连接信息 
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
static void bms_monitor_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len)
{
    cJSON *p_request = NULL;
    cJSON *p_response = NULL;
    cJSON *p_data_item = NULL;
    cJSON *p_pack_item = NULL;
    char *p = NULL;
    uint8_t cluster_index = 0;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;

    p_request = cJSON_Parse(p_data);
    cluster_index = cJSON_GetObjectItem(p_request,"clusterIndex")->valueint;
    TCP_DEBUG_PRINT((int8_t *)"cluster index : %d", cluster_index);
    p_data_item = cJSON_GetObjectItem(p_request,"data");
    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    cluster_index -= 1;
    p_energy_cabinet_data->bms_data[cluster_index].monitor_data.cluster_voltage = cJSON_GetObjectItem(p_data_item,"volt")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].monitor_data.cluster_current = cJSON_GetObjectItem(p_data_item,"current")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].monitor_data.cluster_power = cJSON_GetObjectItem(p_data_item,"power")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].monitor_data.cluster_SOC = cJSON_GetObjectItem(p_data_item,"soc")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].monitor_data.cluster_SOH = cJSON_GetObjectItem(p_data_item,"soh")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_vmax = cJSON_GetObjectItem(p_data_item,"monomerVmax")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_vmean = cJSON_GetObjectItem(p_data_item,"monomerVmean")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_vmin = cJSON_GetObjectItem(p_data_item,"monomerVmin")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_tmax = cJSON_GetObjectItem(p_data_item,"monomerTmax")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_tmean = cJSON_GetObjectItem(p_data_item,"monomerTmean")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_tmin = cJSON_GetObjectItem(p_data_item,"monomerTmin")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].monitor_data.cluster_charge_energy = cJSON_GetObjectItem(p_data_item,"charEnergy")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].monitor_data.cluster_discharge_energy = cJSON_GetObjectItem(p_data_item,"discharEnergy")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].monitor_data.total_energy_charge = cJSON_GetObjectItem(p_data_item,"totalEnergyCharge")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].monitor_data.total_energy_discharge = cJSON_GetObjectItem(p_data_item,"totalEnergyDischarge")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].monitor_data.positive_insulation_resistance = cJSON_GetObjectItem(p_data_item,"posInsulation")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].monitor_data.negative_insulation_resistance = cJSON_GetObjectItem(p_data_item,"NegInsulation")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].monitor_data.high_pressure_box_t1 = cJSON_GetObjectItem(p_data_item,"HBtemp1")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].monitor_data.high_pressure_box_t2 = cJSON_GetObjectItem(p_data_item,"HBtemp2")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].monitor_data.high_pressure_box_t3 = cJSON_GetObjectItem(p_data_item,"HBtemp3")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].monitor_data.high_pressure_box_t4 = cJSON_GetObjectItem(p_data_item,"HBtemp4")->valueint;

    TCP_DEBUG_PRINT((int8_t *)"cluster_voltage: %d", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.cluster_voltage);
    TCP_DEBUG_PRINT((int8_t *)"cluster_current: %d", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.cluster_current);
    TCP_DEBUG_PRINT((int8_t *)"cluster_power: %d", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.cluster_power);
    TCP_DEBUG_PRINT((int8_t *)"cluster_SOC: %d", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.cluster_SOC);
    TCP_DEBUG_PRINT((int8_t *)"cluster_SOH: %d", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.cluster_SOH);
    TCP_DEBUG_PRINT((int8_t *)"monomer_vmax: %d", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_vmax);
    TCP_DEBUG_PRINT((int8_t *)"monomer_vmean: %d", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_vmean);
    TCP_DEBUG_PRINT((int8_t *)"monomer_vmin: %d", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_vmin);
    TCP_DEBUG_PRINT((int8_t *)"monomer_tmax: %d", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_tmax);
    TCP_DEBUG_PRINT((int8_t *)"monomer_tmean: %d", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_tmean);
    TCP_DEBUG_PRINT((int8_t *)"cluster_charge_energy: %d", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.cluster_charge_energy);
    TCP_DEBUG_PRINT((int8_t *)"cluster_discharge_energy: %d", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.cluster_discharge_energy);
    TCP_DEBUG_PRINT((int8_t *)"total_energy_charge: %d", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.total_energy_charge);
    TCP_DEBUG_PRINT((int8_t *)"total_energy_discharge: %d", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.total_energy_discharge);
    TCP_DEBUG_PRINT((int8_t *)"positive_insulation_resistance: %d", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.positive_insulation_resistance);
    TCP_DEBUG_PRINT((int8_t *)"negative_insulation_resistance: %d", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.negative_insulation_resistance);
    TCP_DEBUG_PRINT((int8_t *)"high_pressure_box_t1: %d", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.high_pressure_box_t1);
    TCP_DEBUG_PRINT((int8_t *)"high_pressure_box_t2: %d", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.high_pressure_box_t2);
    TCP_DEBUG_PRINT((int8_t *)"high_pressure_box_t3: %d", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.high_pressure_box_t3);
    TCP_DEBUG_PRINT((int8_t *)"high_pressure_box_t4: %d", p_energy_cabinet_data->bms_data[cluster_index].monitor_data.high_pressure_box_t4);

    if(NULL != cJSON_GetObjectItem(p_data_item,"pack1"))
    {
        p_pack_item = cJSON_GetObjectItem(p_data_item,"pack1");
        cJSON *pack1volt = cJSON_GetObjectItem(p_pack_item,"pack1volt");
        cJSON *pack1temp = cJSON_GetObjectItem(p_pack_item,"pack1temp");
        cJSON *pack1soc = cJSON_GetObjectItem(p_pack_item,"pack1soc");
        cJSON *pack1soh = cJSON_GetObjectItem(p_pack_item,"pack1soh");

		for(uint8_t i = 0; i < MONOMER_NUMBER_IN_PACK; i++)
		{
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[0].monomer_voltage[i] = cJSON_GetArrayItem(pack1volt, i)->valueint;
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[0].monomer_temperature[i] = cJSON_GetArrayItem(pack1temp, i)->valueint;
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[0].monomer_SOC[i] = cJSON_GetArrayItem(pack1soc, i)->valueint;
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[0].monomer_SOH[i] = cJSON_GetArrayItem(pack1soh, i)->valueint;
            //判断单体电压是否越限
            if((p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[0].monomer_voltage[i] > MONOMER_LIMIT_H) ||
               (p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[0].monomer_voltage[i] < MONOMER_LIMIT_L))
            {
                p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[0].monomer_status[i] = ABNORMAL;
            }   
            else
            {
                p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[0].monomer_status[i] = NORMAL;
            }
		}
        p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[0].pole_pack_t1 = cJSON_GetObjectItem(p_pack_item,"pack1Ttemp1")->valueint;
        p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[0].pole_pack_t2 = cJSON_GetObjectItem(p_pack_item,"pack1Ttemp2")->valueint;
    }

    if(NULL != cJSON_GetObjectItem(p_data_item,"pack2"))
    {
        p_pack_item = cJSON_GetObjectItem(p_data_item,"pack2");
        cJSON *pack1volt = cJSON_GetObjectItem(p_pack_item,"pack2volt");
        cJSON *pack1temp = cJSON_GetObjectItem(p_pack_item,"pack2temp");
        cJSON *pack1soc = cJSON_GetObjectItem(p_pack_item,"pack2soc");
        cJSON *pack1soh = cJSON_GetObjectItem(p_pack_item,"pack2soh");

		for(uint8_t i = 0; i < MONOMER_NUMBER_IN_PACK; i++)
		{
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[1].monomer_voltage[i] = cJSON_GetArrayItem(pack1volt, i)->valueint;
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[1].monomer_temperature[i] = cJSON_GetArrayItem(pack1temp, i)->valueint;
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[1].monomer_SOC[i] = cJSON_GetArrayItem(pack1soc, i)->valueint;
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[1].monomer_SOH[i] = cJSON_GetArrayItem(pack1soh, i)->valueint;
		    //判断单体电压是否越限
            if((p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[1].monomer_voltage[i] > MONOMER_LIMIT_H) ||
               (p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[1].monomer_voltage[i] < MONOMER_LIMIT_L))
            {
                p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[1].monomer_status[i] = ABNORMAL;
            }   
            else
            {
                p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[1].monomer_status[i] = NORMAL;
            }
        }
        p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[1].pole_pack_t1 = cJSON_GetObjectItem(p_pack_item,"pack2Ttemp1")->valueint;
        p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[1].pole_pack_t2 = cJSON_GetObjectItem(p_pack_item,"pack2Ttemp2")->valueint;
    }

    if(NULL != cJSON_GetObjectItem(p_data_item,"pack3"))
    {
        p_pack_item = cJSON_GetObjectItem(p_data_item,"pack3");
        cJSON *pack1volt = cJSON_GetObjectItem(p_pack_item,"pack3volt");
        cJSON *pack1temp = cJSON_GetObjectItem(p_pack_item,"pack3temp");
        cJSON *pack1soc = cJSON_GetObjectItem(p_pack_item,"pack3soc");
        cJSON *pack1soh = cJSON_GetObjectItem(p_pack_item,"pack3soh");

		for(uint8_t i = 0; i < MONOMER_NUMBER_IN_PACK; i++)
		{
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[2].monomer_voltage[i] = cJSON_GetArrayItem(pack1volt, i)->valueint;
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[2].monomer_temperature[i] = cJSON_GetArrayItem(pack1temp, i)->valueint;
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[2].monomer_SOC[i] = cJSON_GetArrayItem(pack1soc, i)->valueint;
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[2].monomer_SOH[i] = cJSON_GetArrayItem(pack1soh, i)->valueint;
		    //判断单体电压是否越限
            if((p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[2].monomer_voltage[i] > MONOMER_LIMIT_H) ||
               (p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[2].monomer_voltage[i] < MONOMER_LIMIT_L))
            {
                p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[2].monomer_status[i] = ABNORMAL;
            }   
            else
            {
                p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[2].monomer_status[i] = NORMAL;
            }		
        }
        p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[2].pole_pack_t1 = cJSON_GetObjectItem(p_pack_item,"pack3Ttemp1")->valueint;
        p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[2].pole_pack_t2 = cJSON_GetObjectItem(p_pack_item,"pack3Ttemp2")->valueint;
    }

    if(NULL != cJSON_GetObjectItem(p_data_item,"pack4"))
    {
        p_pack_item = cJSON_GetObjectItem(p_data_item,"pack4");
        cJSON *pack1volt = cJSON_GetObjectItem(p_pack_item,"pack4volt");
        cJSON *pack1temp = cJSON_GetObjectItem(p_pack_item,"pack4temp");
        cJSON *pack1soc = cJSON_GetObjectItem(p_pack_item,"pack4soc");
        cJSON *pack1soh = cJSON_GetObjectItem(p_pack_item,"pack4soh");

		for(uint8_t i = 0; i < MONOMER_NUMBER_IN_PACK; i++)
		{
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[3].monomer_voltage[i] = cJSON_GetArrayItem(pack1volt, i)->valueint;
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[3].monomer_temperature[i] = cJSON_GetArrayItem(pack1temp, i)->valueint;
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[3].monomer_SOC[i] = cJSON_GetArrayItem(pack1soc, i)->valueint;
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[3].monomer_SOH[i] = cJSON_GetArrayItem(pack1soh, i)->valueint;
		    //判断单体电压是否越限
            if((p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[3].monomer_voltage[i] > MONOMER_LIMIT_H) ||
               (p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[3].monomer_voltage[i] < MONOMER_LIMIT_L))
            {
                p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[3].monomer_status[i] = ABNORMAL;
            }   
            else
            {
                p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[3].monomer_status[i] = NORMAL;
            }
        }
        p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[3].pole_pack_t1 = cJSON_GetObjectItem(p_pack_item,"pack4Ttemp1")->valueint;
        p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[3].pole_pack_t2 = cJSON_GetObjectItem(p_pack_item,"pack4Ttemp2")->valueint;
    }

    if(NULL != cJSON_GetObjectItem(p_data_item,"pack5"))
    {
        p_pack_item = cJSON_GetObjectItem(p_data_item,"pack5");
        cJSON *pack1volt = cJSON_GetObjectItem(p_pack_item,"pack5volt");
        cJSON *pack1temp = cJSON_GetObjectItem(p_pack_item,"pack5temp");
        cJSON *pack1soc = cJSON_GetObjectItem(p_pack_item,"pack5soc");
        cJSON *pack1soh = cJSON_GetObjectItem(p_pack_item,"pack5soh");

		for(uint8_t i = 0; i < MONOMER_NUMBER_IN_PACK; i++)
		{
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[4].monomer_voltage[i] = cJSON_GetArrayItem(pack1volt, i)->valueint;
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[4].monomer_temperature[i] = cJSON_GetArrayItem(pack1temp, i)->valueint;
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[4].monomer_SOC[i] = cJSON_GetArrayItem(pack1soc, i)->valueint;
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[4].monomer_SOH[i] = cJSON_GetArrayItem(pack1soh, i)->valueint;
		    //判断单体电压是否越限
            if((p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[4].monomer_voltage[i] > MONOMER_LIMIT_H) ||
               (p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[4].monomer_voltage[i] < MONOMER_LIMIT_L))
            {
                p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[4].monomer_status[i] = ABNORMAL;
            }   
            else
            {
                p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[4].monomer_status[i] = NORMAL;
            }
        }
        p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[4].pole_pack_t1 = cJSON_GetObjectItem(p_pack_item,"pack5Ttemp1")->valueint;
        p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[4].pole_pack_t2 = cJSON_GetObjectItem(p_pack_item,"pack5Ttemp2")->valueint;
    }

    if(NULL != cJSON_GetObjectItem(p_data_item,"pack6"))
    {
        p_pack_item = cJSON_GetObjectItem(p_data_item,"pack6");
        cJSON *pack1volt = cJSON_GetObjectItem(p_pack_item,"pack6volt");
        cJSON *pack1temp = cJSON_GetObjectItem(p_pack_item,"pack6temp");
        cJSON *pack1soc = cJSON_GetObjectItem(p_pack_item,"pack6soc");
        cJSON *pack1soh = cJSON_GetObjectItem(p_pack_item,"pack6soh");

		for(uint8_t i = 0; i < MONOMER_NUMBER_IN_PACK; i++)
		{
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[5].monomer_voltage[i] = cJSON_GetArrayItem(pack1volt, i)->valueint;
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[5].monomer_temperature[i] = cJSON_GetArrayItem(pack1temp, i)->valueint;
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[5].monomer_SOC[i] = cJSON_GetArrayItem(pack1soc, i)->valueint;
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[5].monomer_SOH[i] = cJSON_GetArrayItem(pack1soh, i)->valueint;
		    //判断单体电压是否越限
            if((p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[5].monomer_voltage[i] > MONOMER_LIMIT_H) ||
               (p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[5].monomer_voltage[i] < MONOMER_LIMIT_L))
            {
                p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[5].monomer_status[i] = ABNORMAL;
            }   
            else
            {
                p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[5].monomer_status[i] = NORMAL;
            }
        }
        p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[5].pole_pack_t1 = cJSON_GetObjectItem(p_pack_item,"pack6Ttemp1")->valueint;
        p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[5].pole_pack_t2 = cJSON_GetObjectItem(p_pack_item,"pack6Ttemp2")->valueint;
    }

    if(NULL != cJSON_GetObjectItem(p_data_item,"pack7"))
    {
        p_pack_item = cJSON_GetObjectItem(p_data_item,"pack7");
        cJSON *pack1volt = cJSON_GetObjectItem(p_pack_item,"pack7volt");
        cJSON *pack1temp = cJSON_GetObjectItem(p_pack_item,"pack7temp");
        cJSON *pack1soc = cJSON_GetObjectItem(p_pack_item,"pack7soc");
        cJSON *pack1soh = cJSON_GetObjectItem(p_pack_item,"pack7soh");

		for(uint8_t i = 0; i < MONOMER_NUMBER_IN_PACK; i++)
		{
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[6].monomer_voltage[i] = cJSON_GetArrayItem(pack1volt, i)->valueint;
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[6].monomer_temperature[i] = cJSON_GetArrayItem(pack1temp, i)->valueint;
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[6].monomer_SOC[i] = cJSON_GetArrayItem(pack1soc, i)->valueint;
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[6].monomer_SOH[i] = cJSON_GetArrayItem(pack1soh, i)->valueint;
		    //判断单体电压是否越限
            if((p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[6].monomer_voltage[i] > MONOMER_LIMIT_H) ||
               (p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[6].monomer_voltage[i] < MONOMER_LIMIT_L))
            {
                p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[6].monomer_status[i] = ABNORMAL;
            }   
            else
            {
                p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[6].monomer_status[i] = NORMAL;
            }
        }
        p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[6].pole_pack_t1 = cJSON_GetObjectItem(p_pack_item,"pack7Ttemp1")->valueint;
        p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[6].pole_pack_t2 = cJSON_GetObjectItem(p_pack_item,"pack7Ttemp2")->valueint;
    }

    if(NULL != cJSON_GetObjectItem(p_data_item,"pack8"))
    {
        p_pack_item = cJSON_GetObjectItem(p_data_item,"pack8");
        cJSON *pack1volt = cJSON_GetObjectItem(p_pack_item,"pack8volt");
        cJSON *pack1temp = cJSON_GetObjectItem(p_pack_item,"pack8temp");
        cJSON *pack1soc = cJSON_GetObjectItem(p_pack_item,"pack8soc");
        cJSON *pack1soh = cJSON_GetObjectItem(p_pack_item,"pack8soh");

		for(uint8_t i = 0; i < MONOMER_NUMBER_IN_PACK; i++)
		{
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[7].monomer_voltage[i] = cJSON_GetArrayItem(pack1volt, i)->valueint;
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[7].monomer_temperature[i] = cJSON_GetArrayItem(pack1temp, i)->valueint;
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[7].monomer_SOC[i] = cJSON_GetArrayItem(pack1soc, i)->valueint;
            p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[7].monomer_SOH[i] = cJSON_GetArrayItem(pack1soh, i)->valueint;
		    //判断单体电压是否越限
            if((p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[7].monomer_voltage[i] > MONOMER_LIMIT_H) ||
               (p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[7].monomer_voltage[i] < MONOMER_LIMIT_L))
            {
                p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[7].monomer_status[i] = ABNORMAL;
            }   
            else
            {
                p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[7].monomer_status[i] = NORMAL;
            }
        }
        p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[7].pole_pack_t1 = cJSON_GetObjectItem(p_pack_item,"pack8Ttemp1")->valueint;
        p_energy_cabinet_data->bms_data[cluster_index].monitor_data.monomer_info[7].pole_pack_t2 = cJSON_GetObjectItem(p_pack_item,"pack8Ttemp2")->valueint;
    }

    cJSON_Delete(p_request);

    p_response = cJSON_CreateObject();
    if(p_response == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_response, "devtype", "bms");
    cJSON_AddStringToObject(p_response, "cmdtype", "monitor");
    cJSON_AddNumberToObject(p_response, "result", SUCCESS);
    p_energy_cabinet_data->bms_data[cluster_index].monitor_data.init_status = SUCCESS;
    p = cJSON_PrintUnformatted(p_response);
    cJSON_Delete(p_response);
    tcp_send(p_nc, (uint8_t *)p, strlen(p));
    free(p);

}


/**
 * @brief   bms属性数据处理
 * @param	[in] *p_nc 连接信息 
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
static void bms_property_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len)
{
    cJSON *p_request = NULL;
    cJSON *p_response = NULL;
    cJSON *p_data_item = NULL;
    char *p = NULL;
    uint8_t cluster_index = 0;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;

    p_request = cJSON_Parse(p_data);
    cluster_index = cJSON_GetObjectItem(p_request,"clusterIndex")->valueint;
    TCP_DEBUG_PRINT((int8_t *)"cluster index : %d", cluster_index);
    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    p_data_item = cJSON_GetObjectItem(p_request,"data");
    cluster_index -= 1;
    strcpy((char *)p_energy_cabinet_data->bms_data[cluster_index].property_data.bms_sn, cJSON_GetObjectItem(p_data_item,"sn")->valuestring);
    p_energy_cabinet_data->bms_data[cluster_index].property_data.cell_num = cJSON_GetObjectItem(p_data_item,"cellNum")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].property_data.comm_status = cJSON_GetObjectItem(p_data_item,"commStatus")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].property_data.work_status = cJSON_GetObjectItem(p_data_item,"workStatus")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].property_data.char_prohibit = cJSON_GetObjectItem(p_data_item,"charProhibit")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].property_data.dischar_prohibit = cJSON_GetObjectItem(p_data_item,"discharProhibit")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].property_data.main_pos_relay = cJSON_GetObjectItem(p_data_item,"mainPosRelay")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].property_data.main_nega_relay = cJSON_GetObjectItem(p_data_item,"mainNegaRelay")->valueint;

    TCP_DEBUG_PRINT((int8_t *)"bms sn : %s", p_energy_cabinet_data->bms_data[cluster_index].property_data.bms_sn);
    TCP_DEBUG_PRINT((int8_t *)"cell_num : %d", p_energy_cabinet_data->bms_data[cluster_index].property_data.cell_num);
    TCP_DEBUG_PRINT((int8_t *)"comm_status : %d", p_energy_cabinet_data->bms_data[cluster_index].property_data.comm_status);
    TCP_DEBUG_PRINT((int8_t *)"work_status : %d", p_energy_cabinet_data->bms_data[cluster_index].property_data.work_status);
    TCP_DEBUG_PRINT((int8_t *)"char_prohibit : %d", p_energy_cabinet_data->bms_data[cluster_index].property_data.char_prohibit);
    TCP_DEBUG_PRINT((int8_t *)"dischar_prohibit : %d", p_energy_cabinet_data->bms_data[cluster_index].property_data.dischar_prohibit);
    TCP_DEBUG_PRINT((int8_t *)"main_pos_relay : %d", p_energy_cabinet_data->bms_data[cluster_index].property_data.main_pos_relay);
    TCP_DEBUG_PRINT((int8_t *)"main_nega_relay : %d", p_energy_cabinet_data->bms_data[cluster_index].property_data.main_nega_relay);
    cJSON_Delete(p_request);

    p_response = cJSON_CreateObject();
    if(p_response == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_response, "devtype", "bms");
    cJSON_AddStringToObject(p_response, "cmdtype", "property");
    cJSON_AddNumberToObject(p_response, "result", SUCCESS);

    p = cJSON_PrintUnformatted(p_response);
    cJSON_Delete(p_response);
    tcp_send(p_nc, (uint8_t *)p, strlen(p));
    free(p);
}


/**
 * @brief   获取事件序列下标
 * @param   [in] event_id:事件ID
 * @note
 * @return  事件序列下标
 */
static uint8_t bms_event_array_index_get(uint8_t cmu_index, uint8_t cluster_index, uint16_t event_id)
{
    energy_cabinet_data_t *p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();

    for(uint8_t i = 0; i < BMS_MAX_EVENT_ITEM; i++)
    {
        if(event_id == p_energy_cabinet_data->bms_data[cluster_index].event_data[0][i].event_id)
        {
            return i;
        }
    }
    return 0xFF;
}


/**
 * @brief   bms事件数据处理
 * @param	[in] *p_nc 连接信息 
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
static void bms_event_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len)
{
    cJSON *p_request = NULL;
    cJSON *p_response = NULL;
    char *p = NULL;
    uint8_t cmu_index = 0;
    uint8_t cluster_index = 0;
    uint8_t event_array_index = 0xFF;
    uint16_t event_id = 0;
    uint8_t level = 0;
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;

    p_request = cJSON_Parse(p_data);
    cmu_index = cJSON_GetObjectItem(p_request,"cmuIndex")->valueint;
    cluster_index = cJSON_GetObjectItem(p_request,"clusterIndex")->valueint;
    TCP_DEBUG_PRINT((int8_t *)"cmu index : %d", cmu_index);
    TCP_DEBUG_PRINT((int8_t *)"cluster index : %d", cluster_index);
    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    event_id = cJSON_GetObjectItem(p_request,"ID")->valueint;
    cluster_index -= 1;
    event_array_index = bms_event_array_index_get(cmu_index, cluster_index, event_id);
    if(event_array_index == 0xFF)
    {
        printf("event id [0x%04x] not exit", event_id);
        tcp_error_info_send(p_nc, "bms", "event");
        return;
    }

    level = cJSON_GetObjectItem(p_request,"level")->valueint - 1;

    p_energy_cabinet_data->bms_data[cluster_index].event_data[level][event_array_index].event_id = cJSON_GetObjectItem(p_request,"ID")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].event_data[level][event_array_index].event_code = cJSON_GetObjectItem(p_request,"code")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].event_data[level][event_array_index].event_level = cJSON_GetObjectItem(p_request,"level")->valueint;
    p_energy_cabinet_data->bms_data[cluster_index].event_data[level][event_array_index].event_time = time(NULL);

    TCP_DEBUG_PRINT((int8_t *)"event_id: 0x%04x\n", p_energy_cabinet_data->bms_data[cluster_index].event_data[level][event_array_index].event_id);
    TCP_DEBUG_PRINT((int8_t *)"event_code: %d\n", p_energy_cabinet_data->bms_data[cluster_index].event_data[level][event_array_index].event_code);
    TCP_DEBUG_PRINT((int8_t *)"event_level: %d\n", p_energy_cabinet_data->bms_data[cluster_index].event_data[level][event_array_index].event_level);
    TCP_DEBUG_PRINT((int8_t *)"event_time: %d\n", p_energy_cabinet_data->bms_data[cluster_index].event_data[level][event_array_index].event_time);

    cJSON_Delete(p_request);

    p_response = cJSON_CreateObject();
    if(p_response == NULL)
    {
        TCP_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }

    cJSON_AddStringToObject(p_response, "devtype", "bms");
    cJSON_AddStringToObject(p_response, "cmdtype", "event");
    cJSON_AddNumberToObject(p_response, "result", SUCCESS);

    p = cJSON_PrintUnformatted(p_response);
    cJSON_Delete(p_response);
    tcp_send(p_nc, (uint8_t *)p, strlen(p));
    free(p);
}


/**
 * @brief   bms事件ID列表初始化
 * @note
 * @return
 */
void bms_event_id_list_init(void)
{
    energy_cabinet_data_t *p_energy_cabinet_data = NULL;

    p_energy_cabinet_data = sdk_shm_energy_cabinet_data_get();
    for(uint8_t i = 0; i < CLUSTER_NUMBER; i++)
    {
        for(uint8_t level = 0; level < WARN_LEVEL_MAX; level++)
        {
            for(uint8_t j = 0; j < BMS_MAX_EVENT_ITEM; j++)
            {
                p_energy_cabinet_data->bms_data[i].event_data[level][j].event_id = g_bms_event_list[j];
                p_energy_cabinet_data->bms_data[i].event_data[level][j].event_code = EVENT_END;
                p_energy_cabinet_data->bms_data[i].event_data[level][j].event_level = level + 1;
            }
        }
    }
}


/**
 * @brief   bms数据处理
 * @param	[in] *p_nc 连接信息 
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
void bms_data_handle(struct mg_connection *p_nc, char *p_data, uint16_t data_len)
{
    cJSON *p_request = NULL;
    char *p_cmd_type = NULL;
    
    p_request = cJSON_Parse(p_data);
    p_cmd_type = cJSON_GetObjectItem(p_request,"cmdtype")->valuestring;
    if(!strcmp(p_cmd_type, "monitor"))
    {
        bms_monitor_handle(p_nc, p_data, data_len);
    }
    if(!strcmp(p_cmd_type, "property"))
    {
        bms_property_handle(p_nc, p_data, data_len);
    }
    if(!strcmp(p_cmd_type, "event"))
    {
        bms_event_handle(p_nc, p_data, data_len);
    }
    cJSON_Delete(p_request);
}
