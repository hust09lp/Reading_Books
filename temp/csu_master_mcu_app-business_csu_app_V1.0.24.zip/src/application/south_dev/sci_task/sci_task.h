#ifndef __SCI_TASK_H__
#define __SCI_TASK_H__

#include <pthread.h>
#include "data_types.h"
#include "data_shm.h"

// 从机地址
#define DEV_ADDR_CONTAINER              (0x01)          // 设备地址

// SCI串口端号
#define SDK_UART2			            (1)				// 串口端号

// 版本信息
#define SOFTVER_SIZE                    (4)             // 软件版本大小
#define HARDVER_SIZE                    (2)             // 硬件版本大小

// 协议版本号
#define SCI_PROTOCOL_SYMBOL             'V'
#define SCI_VERTION1                    (0x01)          // SCI协议版本号数值

// 命令码
#define FUNCID_HANDSHAKED               (0x1000)        /* 上电握手 */
#define FUNCID_SEND_THRESHOLD_INFO   	(0x2000)        /* 下发动作阈值 */
#if SCI_V1_8_TEST
#define FUNCID_SYNC_TIME   				(0x2000)        /* 下发系统时间 */
#else
#define FUNCID_SYNC_TIME   				(0x2010)        /* 下发系统时间 */
#endif

#if SCI_V1_8_TEST
#define FUNCID_GET_REALTIME_DATA        (0x3001)        /* 获取实时数据 */
#else
#define FUNCID_GET_REALTIME_DATA        (0x3000)        /* 获取实时数据 */
#endif

#define MEMBER_DAT_NUM_CAL( start_member_pt, end_member_pt )    ((( (uint16_t*)end_member_pt ) - ((uint16_t*)start_member_pt )) + 1 )
#define MEMBER_DAT_LEN_CAL( start_member_pt, end_member_pt )    ((( (uint8_t* )end_member_pt ) - ((uint8_t* )start_member_pt )) + sizeof( uint16_t ) )

#define FUNCID_SET_POWER                    0x2001              /*下发功率*/
#define FUNCID_SET_REMOTE_CTRL              0x2015              /*下发遥控*/
#define FUNCID_SET_CONST_PARAM              0x2016              /*下发定值参数*/

#define FUNCID_SET_ENET_PARM                0x2002              /*下发网络配置参数*/
#define FUNCID_SET_EMS_PARM                 0x2003              /*下发EMS参数*/
#define FUNCID_SET_BAT_CHARGE_PARM          0x2004              /*下发电池充放电参数*/
#define FUNCID_SET_FT_CAP_TEST_MODE         0x2007              /*设置容测模式*/
#define FUNCID_SET_NOTICE_INFO              0x2008              /*设置MCU2通知*/
#define FUNCID_SET_SN                       0x2009              /*写入SN*/
#define FUNCID_SET_HOLIDAY_EMS_PARM         0x200A              /*下发HOLIDAY EMS参数*/
#define FUNCID_SET_DRMN                     0x200B              /*下发DRMn*/
#define FUNCID_SET_MASTER_SLAVE_CONST       0x2011              /*写入主从柜常量参数*/
#define FUNCID_SET_MASTER_SLAVE_VAR         0x2012              /*写入主从柜变量参数*/
#define FUNCID_SET_PHOTOVOLTAIC_METER_CFG   0x2013              /*写入光伏电表参数*/
#define FUNCID_SET_SYS_RUN_PARAM            0x2014              /*写入系统常量参数*/
#define FUNCID_SET_ELEC_METER_PARAM         0x2030              /*电表配置参数*/
#define FUNCID_SET_MQTT_PARAM               0x2031              /*小桔参数*/

#define FUNCID_GET_POWER                    0x3001              /*获取功率*/
#define FUNCID_GET_REMOTE_CTRL              0x3015              /*获取遥控*/
#define FUNCID_GET_REMOTE_MEAS              0x3016              /*获取遥测*/
#define FUNCID_GET_REMOTE_SIG               0x3017              /*获取遥信*/

#define FUNCID_GET_ETH_DATA        		    0x3002              /* 获取ETH2网络数据 */
#define FUNCID_PCS_UPDATE_FLAG        	    0x9030        		/* 通知PCS模块升级状态 */
#define FUNCID_GET_EMS_PARM                 0x3003              /*获取EMS参数*/
#define FUNCID_GET_ELEC_METER_DATA          0x3006              /*获取计量表详细数据*/
#define FUNCID_GET_FT_CAP_TEST_MODE         0x3007              /*获取容测模式*/
#define FUNCID_GET_NOTICE_INFO              0x3008              /*获取MCU2通知*/
#define FUNCID_GET_SN                       0x3009              /*读取SN*/
#define FUNCID_GET_HOLIDAY_EMS_PARM         0x300A              /*获取HOLIDAY EMS参数*/
#define FUNCID_GET_DRMN                     0x300B              /*获取DRMn*/
#define FUNCID_GET_MASTER_SLAVE_VAR         0x3011              /*获取主从柜数据*/
#define FUNCID_GET_PHOTOVOLTAIC_METER_DATA  0x3012              /*获取光伏电表数据*/
#define FUNCID_GET_PHOTOVOLTAIC_METER_CFG   0x3013              /*获取光伏电表参数*/
#define FUNCID_GET_SYS_RUN_PARAM            0x3014              /*获取系统常量参数*/
#define FUNCID_GET_ELEC_METER_PARAM         0x3030              /*电表配置参数*/
#define FUNCID_GET_MQTT_PARAM               0x3031              /*获取小桔参数*/

#define FUNCID_WRSAFETYPARA_START               0x2021               /*写安规参数-开机参数*/        
#define FUNCID_WRSAFETYPARA_GRIDVPROTECT        0x2022                /*写安规参数-电网电压保护参数*/        
#define FUNCID_WRSAFETYPARA_GRIDFREQPROTECT     0x2023                /*写安规参数-电网频率保护参数*/        
#define FUNCID_WRSAFETYPARA_DCIPROTECT          0x2024                /*写安规参数-DCI保护参数*/        
#define FUNCID_WRSAFETYPARA_REMOTEONOFFCTRL     0x2025                /*写安规参数-有功及远程开关机参数*/        
#define FUNCID_WRSAFETYPARA_FREQPWRCTRL         0x2026                /*写安规参数-频率有功参数*/        
#define FUNCID_WRSAFETYPARA_REACTIVEPWR         0x2027                /*写安规参数-无功参数*/        
#define FUNCID_WRSAFETYPARA_LVRT                0x2028                /*写安规参数-电压穿越参数*/        
#define FUNCID_WRSAFETYPARA_OTHER               0x2029                /*写安规参数-ISO孤岛参数*/ 

#define READ_ONCE       0
#define READ_REPEAT     1

#define PARA_SAFETY_BLOCK_U8CNT		128

#define NET_PARAM_CNT		16								/*网络参数的个数*/


#define PATH_SAFETY_FILE				"/opt/data/cfg/safety"



// 通讯监控
#define UART_INIT_RETRYCNT              (3)             // 串口初始化失败重试次数
#define CMD_RETRYCNT_MAX                (3)             // 命令重发次数max
#define COMMBREAKCNT_MAX                (60)            // 通讯异常报中断的累计次数
#define SENDERR_CNT_MAX                 (50)            // 100ms * 50 = 5s，持续异常5s发送失败

// 收发缓存
#define SCI_BUF_SIZE		            (255)           // 收发缓存区大小
#define DATA_SIZE_MAX                   (245)           // 收发缓存区数据段max
#define INDEX_DATA_HOST                 (7)             // 主机数据索引
#define INDEX_DATA_SLAVE                (6)             // 从机数据索引


#if (0)
#define SCI_DEBUG_LOG(...) log_i(__VA_ARGS__)

#define print_frame(buf, len) \
    do {                                               \
        uint16_t tmp_length = (len);                     \
        uint16_t tmp_i = 0;                              \
        for (tmp_i = 0; tmp_i < tmp_length; ) { \
            printf(" %02X", (buf)[tmp_i]);  \
			tmp_i++;	\
			if((tmp_i % 16) == 0) {	\
				printf("\n");  \
			}	\
        }                                              \
        printf("\n");                    \
    } while (0)
#else
#define SCI_DEBUG_LOG(...) {do {} while(0);}
#define print_frame(buf, len) {do {} while(0);}
#endif


/**************************************************************************
*   All Structures and Common Constants
**************************************************************************/
#pragma pack(push)
#pragma pack(1)
typedef union
{
    float32_t data;
    struct
    {
        uint16_t low;
        uint16_t high;
    }apart;
    
}quad_bytes_u;
#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)
/* 版本信息-接收 */
typedef struct{
	uint16_t hardware_version_number;
	uint32_t software_version_number;
	uint16_t communication_protocol_version_number;
	uint32_t boot_version_number;
	uint32_t core_version_number;
	uint16_t sn_version_number[11];
	uint16_t system_power;
	uint16_t max_apparent_power;						//最大视在功率
	uint16_t max_active_power;							//最大有功功率
	uint16_t max_reactive_power;						//最大无功功率
}sci_handack_t;

#pragma pack(pop)

/* ETH2网络信息-接收 */
typedef struct{
	uint8_t  IP_ETH_2[NET_ADDR_LEN_MAX];              // ETH-2 IP地址
    uint8_t  gw_ETH_2[NET_ADDR_LEN_MAX];              // ETH-2 GW
	uint8_t  mask_ETH_2[NET_ADDR_LEN_MAX];            // ETH-2 MASK
	uint8_t  DNS1_ETH_2[NET_ADDR_LEN_MAX];            // ETH-2 NDS1地址
}sci_eth_info_t;


#pragma pack(push)
#pragma pack(1)
/* 实时数据-接收 */

typedef struct{
	uint16_t flag;
    //汇流柜状态信息
	uint8_t combiner_cabinet_system_status_info[COMBINER_CABINET_SYSTEM_STATUS_LEN_BYTE];
    uint8_t res1[4];
    //汇流柜故障信息
	uint8_t combiner_cabinet_system_fault_info[COMBINER_CABINET_SYSTEM_FAULT_LEN_BYTE];
    uint8_t res2[10];
    //遥控命令字
    uint16_t ctl_cmd; 
    //定值参数
    cabinet_parameter_data_t cabinet_param_data;
    //实时数据
    sys_cabinet_telemetry_info_t sys_cabinet_telemetry_info;
    //内部使用参数
    mcu2_internal_param_t mcu2_inter_param;
    uint16_t cabinet_type;              // 0：工商业400V  1：工商业690V
}sci_realtimedata_t;

typedef struct{

    uint16_t flag;                              // 跟随数据标志位
}sci_realtimetemp_t;

#pragma pack(pop)



#pragma pack(push)
#pragma pack(1)
/* 遥控数据下发 */
typedef struct{

    uint16_t LC_on_off_ctrl;                            // 液冷系统开关机 0-关机 1-开机

}sci_telecommand_t;
#pragma pack(pop)



#pragma pack(push)
#pragma pack(1)

typedef struct{

    uint16_t pcs_run;                       			// PCS开机指令 1=开机 0=关机
    uint16_t pcs_cmd;                       			// PCS命令字 b0: 0=NA，1=故障复位 b1: 0=NA，1=开环使能 b2: 0=NA，1=软件复位 b3: 0=NA，1=绝缘监测使能
    int16_t active_power_ref;                      	 // 有功功率给定，放电为正，充电为负
    int16_t reactive_power_ref;                      	 // 无功功率给定，逆变器端超前为正，滞后为负
    uint16_t pcs_operation_mode;                   		// PCS运行模式设置 0x0000=并网模式 0x0001=离网模式 0x0010=恒流源模式 0x0020=恒压源模式 0x0100=AFE模式
    uint16_t bus_volt_ref;               				// bus电压给定值设定
    uint16_t openloop_volt_set;               			// 开环输出电压设置
    uint16_t const_current_ref;                  // 恒流源电流给定
    uint16_t battery_pack1_soc;               			// 电池组1 SOC 1%
    uint16_t battery_pack2_soc;                  // 电池组2 SOC 1%
    uint16_t battery_pack3_soc;               	
    uint16_t battery_pack4_soc;                 
    uint16_t battery_pack5_soc;               	
    uint16_t battery_pack6_soc;                 
    uint16_t battery_pack7_soc;               	
    uint16_t battery_pack8_soc;                 
    uint16_t battery_pack9_soc;               	
    uint16_t battery_pack10_soc;                
    uint16_t battery_pack11_soc;               	
    uint16_t battery_pack12_soc;                
}sci_param_t;

typedef struct{
	uint16_t dev_id;
	sci_param_t parameter;
}sci_thresholdinfo_t;

#pragma pack(pop)


#pragma pack(push)
#pragma pack(1)
/* 通讯数据 */
typedef struct 
{
    sci_handack_t handack;
	sci_thresholdinfo_t thresholdinfo;
    sci_realtimedata_t realtimedata;
	sci_realtimetemp_t realtimetemp;
	sci_eth_info_t net_param;
}sci_localbuf_t;

#pragma pack(pop)


/* 通讯阶段 */
typedef enum{

    STAGE_SHAKE_HAND = 0,           // 上电握手 
    STAGE_GET_ETHDATA,              // 获取网络数据
    STAGE_GET_CFGDATA,              // 获取配置数据，可能存在多个
    STAGE_GET_REALTIMEDATA,         // 获取实时数据
    STAGE_OTHER,                    // 其他阶段

}sci_stage_e;

/* 通讯任务 */
typedef struct{

    int32_t bupdate;			    // 0：非升级状态，1:处于升级状态
    int32_t call_falg;           // 下发阈值函数调用标志
    int32_t para_init_finish;       // 定值参数首次下发完成标志
    int32_t course_flag;            // 交互进行标志
	int32_t devaddr;			    // 用于记录当前发送包的设备地址
	int32_t commbreak_flag;		    // 通讯中断标志 0：正常，1:通讯中断
	int32_t commerr_cnt;	        // 记录通讯异常包连续次数
    uint8_t txbuf[SCI_BUF_SIZE];    // 发送包缓存
    uint8_t rxbuf[SCI_BUF_SIZE];    // 接收包缓存
	sci_stage_e stage;		        // 通讯任务阶段

}sci_task_t;


/**************************************************************************
*   Function declaration
**************************************************************************/

/**
 * @brief  sci任务升级标志位置1
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
void update_flag_set(void);

/**
 * @brief  sci任务升级标志位清0
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
void update_flag_clear(void);

/**
 * @brief  下发定值参数
 * @param  [in]  function_id 下发数据功能码，具体见data_shm.h
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
int32_t set_constant_data(uint16_t function_id,uint16_t *p_data, uint32_t data_num);

/**
 * @brief  获取sci通信收发互斥锁
 * @param  [out] none
 * @param  [in] none
 * @return sci通信收发互斥锁指针
 */
pthread_mutex_t *sci_mutex_get(void);

/**
 * @brief  启动SCI通讯线程
 * @param  none
 * @return none
 */ 
void sci_task_start(void);


/**
 * @brief  下发EMS参数
 * @param  [in]  none
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
int32_t set_ems_data(void);
/**
 * @brief  下发节假日EMS参数
 * @param  [in]  none
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
int32_t set_holiday_ems_data(void);

/**
 * @brief  设置容测模式
 * @param  [in]  none
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
void set_ft_cap_test_mode(uint16_t mode);

/**
 * @brief  下发小桔设置参数
 * @param  [in]  none
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
int32_t set_mqtt_param(void);

/**
 * @brief  SCI通讯模块初始化
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
void sci_module_init(void);

/**
* @brief		同步时间
* @return		void
*/
void sync_time(void);

/**
 * @brief  下发CSU SN
 * @param  [in]  none
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
int32_t set_csu_sn(void);


/**
 * @brief  下发配置光伏电表参数
 * @param  [in]  none
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
int32_t photovoltaic_meter_cfg_set(void);

/**
 * @brief  下发系统常量参数
 * @param  [in]  none
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
int32_t set_sys_run_param(void);

/**
 * @brief  下发EMS节能降耗通知信息
 * @param  [in]  none
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
void set_mcu2_notice_info(void);

/**
 * @brief  下发电表设置参数
 * @param  [in]  none
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
int32_t set_elec_meter_config_param(void);

/**
 * @brief  sci任务状态设置
 * @param  [in] stage 待设置的状态 具体见sci_stage_e
 * @param  [out] none
 * @return none
 */
void task_stage_set(uint16_t stage);

#endif

