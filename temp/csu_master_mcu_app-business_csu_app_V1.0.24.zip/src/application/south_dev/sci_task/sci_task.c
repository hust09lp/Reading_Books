#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/prctl.h>
#include <unistd.h>
#include <arpa/inet.h>
#include "update_task.h"
#include "sdk_shm.h"
#include "data_shm.h"
#include "cu_sofar_sci.h"
#include "sdk_uart.h"
#include "sofar_log.h"
#include "sdk_public.h"
#include "sci_task.h"
#include "app_common.h"
#include "mem_utils.h"
#include "command_parser.h"


typedef union
{
    float32_t float_value;
    uint8_t uint8[4];
}float_union;


#define SCI_TIMEOUT_MS		    	   (800)			// general串口读取超时时间800ms
#define FLAG_REALTEMP0		    	  (0x0000)			// 实时数据跟随下发标志值，高字节为电池类数据长度，低字节为是否下发此类数据

#define SCI_SYS_TIME_UPDATE             (60 * 60)       // 更新系统时间
#define SCI_EMS_DATA                    (5)             // EMS数据获取间隔5s
#define SCI_BAT_CHARGE_DATA_UPDATE		(15)			// 充放电数据更新间隔5s
#define SCI_ELEC_METER_DATA				(2)			    // 计量表数据获取时间间隔2s
#define SCI_ELEC_METER3_DATA			(3)			    // 计量表3数据获取时间间隔10s
#define SCI_PHOTOVOLTAIC_METER_DATA		(5)			    // 光伏电表数据获取时间间隔10s
#define SCI_INFO_NOTICE					(2)			    // MCU2通知信息时间间隔2s
#define SCI_FAN_CTRL                    (10)            // 汇流柜风扇启停检测间隔5s
#define SCI_ELEC_METER_CONFIG           (10)            // 电表配置参数
#define SCI_SET_MASTER_SLAVE_UPDATE     (15)			// 主从机数据更新间隔15s
#define SCI_GET_MASTER_SLAVE_UPDATE     (30)		    // 主从机数据更新间隔30s,作为从机时使用

static sci_task_t g_sci_task;							// sci任务结构体缓存
static sci_localbuf_t g_sci_localbuf;					// sci数据结构体缓存
pthread_mutex_t sofar_sci_mutex;						//通信互斥锁
static csu_combine_info_t g_sci_master_slave_data;     // sci 主从机数据缓存
static bat_charge_data_t g_sci_bat_charge_data[6];     // sci 电池数据缓存
static uint8_t g_sci_cmu_sys_status[6];     // sci cmu状态缓存

/**
 * @brief  获取sci通信收发互斥锁
 * @param  [in] none
 * @param  [out] none
 * @return sci通信收发互斥锁指针
 */
pthread_mutex_t *sci_mutex_get(void)
{
	return &sofar_sci_mutex;
}

/**
 * @brief  sci任务状态设置
 * @param  [in] stage 待设置的状态 具体见sci_stage_e
 * @param  [out] none
 * @return none
 */
void task_stage_set(uint16_t stage)
{
	g_sci_task.stage = stage;
	return;
}

/**
 * @brief  sci任务升级标志位置1
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
void update_flag_set(void)
{
    g_sci_task.bupdate = 1;
    return;
}

/**
 * @brief  sci任务升级标志位清0
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
void update_flag_clear(void)
{
    g_sci_task.bupdate = 0;
    return;
}

/**
 * @brief  判断sci任务升级标志位是否为1
 * @param  [in] none
 * @param  [out] none
 * @return true：正在升级  false：未在升级
 */
static bool is_update_flag(void)
{
    bool ret = false;
    firmware_update_t *p_update = sdk_shm_firmware_update_info_get();
    //CSU任一模块处于升级状态都禁止业务通信
	if((1 == g_sci_task.bupdate) || (p_update->local_ota_flag == 1) || (p_update->remote_ota_flag == 1))
	{
		ret = true;
	}
	else
	{
		ret = false;
	}
	return ret;
}

/**
 * @brief  交互标志位置1
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void course_flag_set(void)
{
	g_sci_task.course_flag = 1;
	return;
}

/**
 * @brief  交互标志位清除
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void course_flag_clear(void)
{
	g_sci_task.course_flag = 0;
	return;
}

/**
 * @brief  判断交互标志位是否为1
 * @param  [in] none
 * @param  [out] none
 * @return true：正在交互  false：未在交互
 */
static bool is_course_flag(void)
{
	bool ret = false;

	if(1 == g_sci_task.course_flag)
	{
		ret = true;
	}
	else
	{
		ret = false;
	}

	return ret;
}

/**
 * @brief  获取SCI通信状态是否就绪
 * @param  [in] none
 * @param  [out] none
 * @return true：就绪  false：未就绪
 */
static bool sci_is_ready(void)
{
    int32_t cnt = 10000;

	if(is_update_flag() == true)
    {
        return false;
    }

	while(cnt--)
	{
		if(false == is_course_flag())
		{
			break;
		}
		usleep(1000 * 1);
	}
	
	if(-1 == cnt)
	{
		SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] error! cnt= %d\n",__func__, __LINE__,cnt);
		return false;
	}
    return true;
}


float32_t uint32_to_float(uint16_t value1, uint16_t value2)
{
    float_union packet;
    uint8_t buf[4] = {0x00, 0x00, 0x00, 0x00}; 

    buf[0] = (uint8_t)((value1 >> 8) & 0xFF);
    buf[1] = (uint8_t)((value1) & 0xFF);
    buf[2] = (uint8_t)((value2 >> 8) & 0xFF);
    buf[3] = (uint8_t)((value2) & 0xFF);
    uint32_t uint32 = ((buf[0]<<24) & 0XFFFFFFFF) + ((buf[1]<<16) & 0XFFFFFF) + ((buf[2]<<8) & 0XFFFF) + buf[3];

    for(uint8_t i = 0; i < 4; i++)
    {
        packet.uint8[i] = (uint8_t)(uint32>>(i*8));
    }

    return packet.float_value;
}


/**
 * @brief  获取CSU主从机角色
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
csu_role_e csu_role_get(void)
{
	csu_combine_info_t *p_csu_combine = sdk_shm_csu_combine_data_get();
	if(true == p_csu_combine->comb_setting.comb_enable)
	{
		return p_csu_combine->comb_setting.comb_role;
	}
	else
	{
		return CSU_ROLE_SLAVE;
	}
}

/**
 * @brief  结构体初始化打包
 * @param  [out] p_sofar sci结构体缓存，具体见cu_sofar_sci_t
 * @param  [in] funcid 功能码
 * @param  [in] p_data 数据段缓存指针
 * @param  [in] data_len 数据段的长度
 * @return none
 */
static void regular_data_pack(cu_sofar_sci_t *p_sofar, uint16_t func_id, uint8_t *p_data, uint8_t data_len)
{
	if(p_sofar == NULL || p_data == NULL)
	{
		return;
	}

	p_sofar->version = SCI_VERTION1;
	p_sofar->dev_addr = DEV_ADDR_CONTAINER;
	p_sofar->function_id = func_id;
	p_sofar->data_len = data_len;
	p_sofar->p_data = p_data;

	return;
}

/**
 * @brief  参数、数据列表初始化
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void sci_data_init(void)
{
	memset(&g_sci_task, 0, sizeof(g_sci_task));
	SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] task clear over\n",__func__, __LINE__);
	
	// 结构体初始化
	g_sci_task.stage = STAGE_SHAKE_HAND;
	g_sci_task.devaddr = DEV_ADDR_CONTAINER; 
	
	
	SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] task init over\n",__func__, __LINE__);

	memset(&g_sci_localbuf, 0, sizeof(sci_localbuf_t));
	g_sci_localbuf.realtimetemp.flag = FLAG_REALTEMP0;
	
}


/**
 * @brief  sci通讯任务初始化
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void sci_task_init(void)
{
	int32_t retry_cnt = UART_INIT_RETRYCNT;
	sdk_uart_conf_t arrt = {UART_BAUD_RATE_115200, UART_DATA_BITS_8, UART_STOP_BITS_1, UART_PARITY_NONE, UART_HWFLOW_OFF};

	while(retry_cnt--)
	{
		// 打开串口
		if(sdk_uart_open(SDK_UART2) != 0) 
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] sdk_uart_open faild\n",__func__, __LINE__);
			continue;
		}
		SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] sdk_uart_open over\n",__func__, __LINE__);

		// 配置串口
		SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] uart setup start!\n",__func__, __LINE__);	
		if(sdk_uart_setup(SDK_UART2, &arrt) == 0)
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] sdk_setup over\n",__func__, __LINE__);
			break;
		}
		SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] sdk_uart_setup faild\n"),__func__, __LINE__);
	}

	// 参数数据列表初始化
	sci_data_init();

	return;
}

/**
 * @brief  通讯异常计数
 * @param  [in] devid  设备地址
 * @param  [in] berror 1 异常；0 正常
 * @param  [in] btimeout 1 接收超时异常；0 正常接收未超时
 * @param  [out] none
 * @return none
 */
static void sci_error_handle(int32_t devid, int32_t berror, int32_t btimeout)
{
	uint32_t step_cnt = 1;
	common_data_t *shm = NULL;

	shm = sdk_shm_get();

	if(devid != DEV_ADDR_CONTAINER)
	{
		return;
	}
	if(btimeout == 1)
	{
		step_cnt = 2;
	}
	//连续通讯异常包统计
	if(berror)
	{
		g_sci_task.commerr_cnt += step_cnt;
		if(g_sci_task.commerr_cnt >= COMMBREAKCNT_MAX)
		{
			g_sci_task.commerr_cnt = COMMBREAKCNT_MAX;
			g_sci_task.commbreak_flag = 1;
			// g_sci_task.commbreak_flag |= 1 << (devid - 1) ;
			// 置共享内存里对应故障位--SCI通信故障
			shm->telematic_data.csu_system_fault_info[0] |= (1 << 4);
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] sci commbreak!\n"),__func__, __LINE__);
		}
	}
	else
	{
		g_sci_task.commerr_cnt = 0;
		g_sci_task.commbreak_flag = 0; 
		// SCI故障之后恢复，握手一次；清共享内存里对应故障位
		if(shm->telematic_data.csu_system_fault_info[0] & (1 << 4))
		{
			task_stage_set(STAGE_SHAKE_HAND);
		}
		
		shm->telematic_data.csu_system_fault_info[0] &= ~(1 << 4);
	}
	return;
}


/**
 * @brief  版本号（设备信息）更新至共享内存
 * @param  [in] none
 * @param  [out] none
 * @return none
 */

void sci_update_deviceinfo_to_shm(void)
{
	telemetry_data_t *shm_tmp = sdk_shm_telemetry_data_get();
    internal_version_info_t * p_version_info = internal_version_info_get();
	
	if(NULL != shm_tmp)
	{
		shm_tmp->sys_version_telemetry_info.hardware_version_number = g_sci_localbuf.handack.hardware_version_number;
		shm_tmp->sys_version_telemetry_info.communication_protocol_version_number = g_sci_localbuf.handack.communication_protocol_version_number;
		shm_tmp->sys_version_telemetry_info.mcu2_software_version_number = g_sci_localbuf.handack.software_version_number;
        memcpy(p_version_info->mcu2_app_soft_version, &shm_tmp->sys_version_telemetry_info.mcu2_software_version_number, 4);
		shm_tmp->sys_version_telemetry_info.mcu2_boot_version_number = g_sci_localbuf.handack.boot_version_number;
		shm_tmp->sys_version_telemetry_info.mcu2_core_version_number = g_sci_localbuf.handack.core_version_number;
        memcpy(p_version_info->mcu2_core_soft_version, &shm_tmp->sys_version_telemetry_info.mcu2_core_version_number, 4);
		shm_tmp->sys_version_telemetry_info.system_power = g_sci_localbuf.handack.system_power;
		memcpy(shm_tmp->sys_version_telemetry_info.sn_version_number,g_sci_localbuf.handack.sn_version_number,sizeof(g_sci_localbuf.handack.sn_version_number));
		shm_tmp->sys_version_telemetry_info.max_apparent_power = g_sci_localbuf.handack.max_apparent_power;
		shm_tmp->sys_version_telemetry_info.max_active_power = g_sci_localbuf.handack.max_active_power;
		shm_tmp->sys_version_telemetry_info.max_reactive_power = g_sci_localbuf.handack.max_reactive_power;
	}
	return;
}


/**
 * @brief  sci实时数据更新至共享内存
 * @param  [in] none
 * @param  [out] none
 * @return none
 */	

void sci_update_realtimedata_to_shm(void)
{
    sci_realtimedata_t *p_realtimedata = NULL;
	common_data_t *shm = NULL;
    telematic_data_t *p_telematic = NULL;
    telemetry_data_t *p_telemetry = NULL;
	constant_parameter_data_t *p_cabinet = NULL;
    internal_shared_data_t *p_shared_data = NULL;

	shm = sdk_shm_get();
    p_realtimedata = &g_sci_localbuf.realtimedata;      					// 实时数据缓存
	if(shm == NULL || p_realtimedata == NULL)
	{
		return;
	}

    p_telematic = &shm->telematic_data;     		// 共享内存遥信数据
    p_telemetry = &shm->telemetry_data;     		// 共享内存遥测数据
	p_cabinet = &shm->constant_parameter_data;		// 共享内存定值参数
    p_shared_data = &shm->internal_shared_data;  // 共享内存内部参数

    //汇流柜状态信息
    memcpy(&p_telematic->combiner_cabinet_system_status_info,&p_realtimedata->combiner_cabinet_system_status_info,COMBINER_CABINET_SYSTEM_STATUS_LEN_BYTE);
	//汇流柜故障信息
	memcpy(&p_telematic->combiner_cabinet_system_fault_info,&p_realtimedata->combiner_cabinet_system_fault_info,COMBINER_CABINET_SYSTEM_FAULT_LEN_BYTE);
	//定值参数
    p_cabinet->system_param.remote_control_cmd = p_realtimedata->ctl_cmd;
	memcpy(&p_cabinet->cabinet_param_data,&p_realtimedata->cabinet_param_data,sizeof(cabinet_parameter_data_t));
	memcpy(&p_cabinet->system_param.cabinet_param,&p_realtimedata->cabinet_param_data,sizeof(cabinet_parameter_data_t));
	//实时数据
	memcpy(&p_telemetry->sys_cabinet_telemetry_info,&p_realtimedata->sys_cabinet_telemetry_info,sizeof(sys_cabinet_telemetry_info_t));
	//内部使用参数
	memcpy(&p_cabinet->system_param.mcu2_inter_param,&p_realtimedata->mcu2_inter_param,sizeof(mcu2_internal_param_t));
	//机型
    p_shared_data->cabinet_type = p_realtimedata->cabinet_type;
    return;
}

/**
 * @brief  握手信息赋值至参数缓存
 * @param  [in] p_para_buf 发送数据缓存指针
 * @param  [out] none
 * @return >0:打包字节数  -1:失败
 */
static int32_t sci_onpack_handshake(uint8_t *p_para_buf)
{
	int32_t len = 0;
	if(p_para_buf == NULL)
	{
		return -1;
	}

	p_para_buf[len++] = (uint8_t)(0x00);
	p_para_buf[len++] = (uint8_t)(0x11);
	p_para_buf[len++] = (uint8_t)(0x22);
	p_para_buf[len++] = (uint8_t)(0x33);
	p_para_buf[len++] = (uint8_t)(0x44);
	return len;
}


/**
 * @brief  主从机常量参数缓存
 * @param  [in] p_para_buf 发送数据缓存指针
 * @param  [out] none
 * @return >0:数据字节数  -1:失败
 */
static int32_t sci_onpack_master_slave_const(uint8_t *p_para_buf)
{
	int32_t len = 0;
	uint16_t csu_role = csu_role_get();

	p_para_buf[len++] = (uint8_t)((csu_role >> 8) & 0xff);	// 跟随标志高字节
	p_para_buf[len++] = (uint8_t)((csu_role >> 0) & 0xff);	// 跟随标志低字节
	
	return len;
}

/**
 * @brief  主从机变量参数缓存
 * @param  [in] p_para_buf 发送数据缓存指针
 * @param  [out] none
 * @return >0:数据字节数  -1:失败
 */
static int32_t sci_onpack_master_slave_var(uint8_t *p_para_buf)
{
	int32_t len = 0;
	uint8_t i;
	uint16_t cmu_chg_dch_flag = 0;
	csu_combine_info_t *p_csu_combine = sdk_shm_csu_combine_data_get();
	bat_charge_data_t *bat_charge_data = sdk_shm_bat_charge_data_info_get();
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();

	memcpy(&g_sci_master_slave_data.slave_info[0], &p_csu_combine->slave_info[0], sizeof(p_csu_combine->slave_info));
	memcpy(&g_sci_bat_charge_data[0], &bat_charge_data[0], sizeof(g_sci_bat_charge_data[0]));
	for(i = 0; i < MAX_SLAVE_COUNT; i++)
	{
		if(0 == i)
		{
			SCI_DEBUG_LOG((int8_t *)"bat_charge_data[i].pcs_dischg_limit_power:%d\r\n",bat_charge_data[i].pcs_dischg_limit_power);
			SCI_DEBUG_LOG((int8_t *)"bat_charge_data[i].pcs_chg_limit_power:%d\r\n",bat_charge_data[i].pcs_chg_limit_power);
			p_para_buf[len++] = (uint8_t)(((bat_charge_data[i].pcs_dischg_limit_power) >> 8) & 0xff);	// 跟随标志高字节
			p_para_buf[len++] = (uint8_t)(((bat_charge_data[i].pcs_dischg_limit_power) >> 0) & 0xff);	// 跟随标志低字节
			p_para_buf[len++] = (uint8_t)(((bat_charge_data[i].pcs_chg_limit_power) >> 8) & 0xff);	// 跟随标志高字节
			p_para_buf[len++] = (uint8_t)(((bat_charge_data[i].pcs_chg_limit_power) >> 0) & 0xff);	// 跟随标志低字节
			if(SYS_STA_RUNNING == p_telemetry_data->sys_version_telemetry_info.csu_sys_state)
			{
				BIT_SET(cmu_chg_dch_flag, i);
			}
		}
		else
		{
			p_para_buf[len++] = (uint8_t)((((int16_t)g_sci_master_slave_data.slave_info[i - 1].real_data.pcs_discharge_max_power) >> 8) & 0xff);	// 跟随标志高字节
			p_para_buf[len++] = (uint8_t)((((int16_t)g_sci_master_slave_data.slave_info[i - 1].real_data.pcs_discharge_max_power) >> 0) & 0xff);	// 跟随标志低字节
			p_para_buf[len++] = (uint8_t)((((int16_t)g_sci_master_slave_data.slave_info[i - 1].real_data.pcs_charge_max_power) >> 8) & 0xff);	// 跟随标志高字节
			p_para_buf[len++] = (uint8_t)((((int16_t)g_sci_master_slave_data.slave_info[i - 1].real_data.pcs_charge_max_power) >> 0) & 0xff);	// 跟随标志低字节
			if(SYS_STA_RUNNING == g_sci_master_slave_data.slave_info[i-1].real_data.sys_status)
			{
				BIT_SET(cmu_chg_dch_flag, i);
			}
		}
	}
	p_para_buf[len++] = (uint8_t)((cmu_chg_dch_flag >> 8) & 0xff);	// 跟随标志高字节
	p_para_buf[len++] = (uint8_t)((cmu_chg_dch_flag >> 0) & 0xff);	// 跟随标志低字节
	
	return len;
}

/**
 * @brief  检查主从机参数是否变化
 * @param  [in] p_para_buf 发送数据缓存指针
 * @param  [out] none
 * @return >0:数据字节数  -1:失败
 */
static bool master_slave_var_check(void)
{
	bool ret = false;
	uint8_t i;
	csu_combine_info_t *p_csu_combine = sdk_shm_csu_combine_data_get();
	bat_charge_data_t *bat_charge_data = sdk_shm_bat_charge_data_info_get();
	internal_shared_data_t *p_internal_shared_data = internal_shared_data_get();
	if(CSU_ROLE_SLAVE == csu_role_get())
	{
		for(i = 0; (i < MAX_SLAVE_COUNT) && (false == ret); i++)
		{
			if((g_sci_cmu_sys_status[i] != p_internal_shared_data->cmu_sys_status[i]) || \
				(g_sci_bat_charge_data[i].charge_prohibit != bat_charge_data[i].charge_prohibit) || \
				(g_sci_bat_charge_data[i].discharge_prohibit != bat_charge_data[i].discharge_prohibit) || \
				(g_sci_bat_charge_data[i].pcs_chg_limit_power != bat_charge_data[i].pcs_chg_limit_power) || \
				(g_sci_bat_charge_data[i].pcs_dischg_limit_power != bat_charge_data[i].pcs_dischg_limit_power) || \
				(g_sci_bat_charge_data[i].charge_limit_power != bat_charge_data[i].charge_limit_power) || \
				(g_sci_bat_charge_data[i].discharge_limit_power != bat_charge_data[i].discharge_limit_power))
			{
				ret = true;
			}
		}
	}
	else
	{
		for(i = 0; (i < MAX_SLAVE_COUNT) && (false == ret); i++)
		{
			if(0 == i)
			{
				if((g_sci_cmu_sys_status[i] != p_internal_shared_data->cmu_sys_status[i]) || \
					(g_sci_bat_charge_data[i].charge_prohibit != bat_charge_data[i].charge_prohibit) || \
					(g_sci_bat_charge_data[i].discharge_prohibit != bat_charge_data[i].discharge_prohibit) || \
					(g_sci_bat_charge_data[i].pcs_chg_limit_power != bat_charge_data[i].pcs_chg_limit_power) || \
					(g_sci_bat_charge_data[i].pcs_dischg_limit_power != bat_charge_data[i].pcs_dischg_limit_power) || \
					(g_sci_bat_charge_data[i].charge_limit_power != bat_charge_data[i].charge_limit_power) || \
					(g_sci_bat_charge_data[i].discharge_limit_power != bat_charge_data[i].discharge_limit_power))
				{
					ret = true;
				}
			}
			else
			{
				if(p_csu_combine->slave_info[i - 1].online)
				{
					if((g_sci_cmu_sys_status[i] != p_csu_combine->slave_info[i - 1].real_data.sys_status) || \
						(g_sci_master_slave_data.slave_info[i - 1].real_data.charge_prohibit != p_csu_combine->slave_info[i - 1].real_data.charge_prohibit) || \
						(g_sci_master_slave_data.slave_info[i - 1].real_data.discharge_prohibit != p_csu_combine->slave_info[i - 1].real_data.discharge_prohibit) || \
						(g_sci_master_slave_data.slave_info[i - 1].real_data.pcs_charge_max_power != p_csu_combine->slave_info[i - 1].real_data.pcs_charge_max_power) || \
						(g_sci_master_slave_data.slave_info[i - 1].real_data.pcs_discharge_max_power != p_csu_combine->slave_info[i - 1].real_data.pcs_discharge_max_power) || \
						(g_sci_master_slave_data.slave_info[i - 1].real_data.bat_charge_max_power != p_csu_combine->slave_info[i - 1].real_data.bat_charge_max_power) || \
						(g_sci_master_slave_data.slave_info[i - 1].real_data.bat_discharge_max_power != p_csu_combine->slave_info[i - 1].real_data.bat_discharge_max_power))
					{
						ret = true;
					}
				}

			}
		}
	}

	return ret;
}

/**
 * @brief  功率变更后查询从机功率
 * @param  [in] p_para_buf 发送数据缓存指针
 * @param  [out] none
 * @return >0:数据字节数  -1:失败
 */
static bool master_slave_power_check(void)
{
	csu_combine_info_t *p_csu_combine = sdk_shm_csu_combine_data_get();

	return p_csu_combine->fast_power_enable;
}

/**
 * @brief  u16数据赋值至u8参数缓存
 * @param  [in] p_buf 数据发送缓存指针
 * @param  [in] p_data 待打包的u16数据块首地址
 * @param  [in] data_num 待打包的u16数据个数
 * @param  [out] none
 * @return >0:打包字节数  -1:失败
 */
static int32_t sci_onpack_txdata(uint8_t *p_buf, uint16_t *p_data, int32_t data_num)
{
	int32_t i = 0;
	int32_t len = 0;
	
	if(NULL == p_buf || NULL == p_data)
	{
		return -1;
	}

	if(data_num > (SCI_BUF_SIZE / sizeof(uint16_t)))
	{
		SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] data_num is out of range!\n",__func__, __LINE__);
		return -1;
	}

	for(i=0; i<data_num; i++)
	{
		// 发送u16数据，高位在前，低位在后
		p_buf[len++] = (uint8_t)((p_data[i] >> 8) & 0xff);
		p_buf[len++] = (uint8_t)((p_data[i] >> 0) & 0xff);
	}
	
	return len;
}


/**
 * @brief  握手应答数据解析
 * @param  [in] p_data 指向应答包的数据段起始位置
 * @param  [in] buf_len	有效数据段长度 
 * @param  [out] none
 * @return 0：成功  -1：失败
 */
void sci_onparse_handshake(uint8_t *p_data) 
{
	sci_handack_t *p_hand = NULL;
	
	internal_version_info_t *temp = internal_version_info_get();
	p_hand = &g_sci_localbuf.handack;

	if(p_data == NULL || p_hand == NULL)
	{
		return;
	}
	p_hand->hardware_version_number = (p_data[0] << 8) | (p_data[1]);
	p_hand->software_version_number = (p_data[2] << 24) | (p_data[3] << 16) | (p_data[4] << 8) | (p_data[5]);
	p_hand->communication_protocol_version_number = (p_data[6] << 8) | (p_data[7]);
	p_hand->boot_version_number = (p_data[8] << 24) | (p_data[9] << 16) | (p_data[10] << 8) | (p_data[11]);
	p_hand->core_version_number = (p_data[12] << 24) | (p_data[13] << 16) | (p_data[14] << 8) | (p_data[15]);
	memcpy((uint8_t *)&p_hand->sn_version_number,p_data+16,sizeof(p_hand->sn_version_number));
	p_hand->system_power = (p_data[38] << 8) | (p_data[39]);
	p_hand->max_apparent_power = (p_data[40] << 8) | (p_data[41]);
	p_hand->max_active_power = (p_data[42] << 8) | (p_data[43]);
	p_hand->max_reactive_power = (p_data[44] << 8) | (p_data[45]);
	memcpy(temp->mcu2_hardware_version, &p_hand->hardware_version_number, 2);
	p_hand->system_power = (p_data[38] << 24) | (p_data[39] << 16) | (p_data[40] << 8) | (p_data[41]);
	
	return;
}


/**
 * @brief  实时接收数据解析
 * @param  [in] pbuf 应答包数据段缓存指针
 * @param  [in] data_len 应答包数据段长度
 * @param  [out] none
 * @return -1：解析异常  0：mcu2实时数据未上传成功解析  1：mcu2实时数据已上传且成功解析
 */

int32_t sci_onparse_realtimedata(uint8_t *pbuf, uint8_t data_len)
{
	sci_realtimedata_t *p_data = NULL;
	int16_t *p_tmp = NULL;
	uint16_t *p_tmp1 = NULL;
	int32_t *p_tmp2 = NULL;
	uint16_t *p_tmp3 = NULL;
	
	int32_t i = 0;
	int32_t j = 0;
	int32_t index = 0;
	p_data = &g_sci_localbuf.realtimedata;
	if(p_data == NULL || pbuf == NULL || data_len <2)
	{
		return -1;
	}

	// 跟随数据标志位
	p_data->flag = (uint16_t)((pbuf[0] << 8) | pbuf[1]);
	SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] rxframe-realtime.flag = %x\n", __func__, __LINE__,p_data->flag);

	if((p_data->flag & 0x01) == 0)
	{
		SCI_DEBUG_LOG((int8_t *)"realtimedata flag != 1,Do not process data\n");
		return 0;
	}

    // 状态信息 4Bytes
    for(i = 0,j = 2; i < COMBINER_CABINET_SYSTEM_STATUS_LEN_BYTE;i=i+2,j=j+2)
    {
    	p_data->combiner_cabinet_system_status_info[i] = pbuf[j+1];
		p_data->combiner_cabinet_system_status_info[i+1] = pbuf[j];
    }

    // 故障信息 6Bytes
   	for(i = 0,j = 10; i < COMBINER_CABINET_SYSTEM_FAULT_LEN_BYTE;i=i+2,j=j+2)
    {
    	p_data->combiner_cabinet_system_fault_info[i] = pbuf[j+1];
		p_data->combiner_cabinet_system_fault_info[i+1] = pbuf[j];
    }

	// 命令字 2Bytes
	p_data->ctl_cmd = (uint16_t)((pbuf[26] << 8) | pbuf[27]);
	// 定值参数 60Bytes
	p_tmp = &g_sci_localbuf.realtimedata.cabinet_param_data.active_power;
    for(i = 28; i < 88; i += 2)
	{
		// 接收组装为u16数据，高位在前，低位在后
		p_tmp[index++] = ((pbuf[i] << 8) | pbuf[i+1]);
	}
	// 实时数据 136Bytes
	p_tmp1 = &g_sci_localbuf.realtimedata.sys_cabinet_telemetry_info.system_status;
	index = 0;
    for(i = 88; i < 116; i += 2)
	{
		// 接收组装为u16数据，高位在前，低位在后
		p_tmp1[index++] = ((pbuf[i] << 8) | pbuf[i+1]);
	}
	p_tmp2 = &g_sci_localbuf.realtimedata.sys_cabinet_telemetry_info.ac_side_active_power;
	index= 0;
	for(i = 116; i < 148; i += 4)
	{
		p_tmp2[index++] = ((pbuf[i] << 24) | (pbuf[i+1] << 16) | (pbuf[i+2] << 8) | pbuf[i+3]);
	}
	p_tmp3 = &g_sci_localbuf.realtimedata.sys_cabinet_telemetry_info.ac_side_phase_vol_r;
	index = 0;
    for(i = 148; i < 172; i += 2)
	{
		// 接收组装为u16数据，高位在前，低位在后
		p_tmp3[index++] = ((pbuf[i] << 8) | pbuf[i+1]);
	}
	// 防逆流电表功率
	uint16_t LL = htons(*(uint16_t *)&pbuf[172]);
	uint16_t HH = htons(*(uint16_t *)&pbuf[174]);
	p_data->sys_cabinet_telemetry_info.anti_reflux_power = uint32_to_float(LL, HH);
    p_data->sys_cabinet_telemetry_info.dry_temp = htons(*(uint16_t *)&pbuf[176]);
    p_data->sys_cabinet_telemetry_info.dry_humidity = htons(*(uint16_t *)&pbuf[178]);

	//内部使用参数
	p_tmp3 = &g_sci_localbuf.realtimedata.mcu2_inter_param.acb_on;
	index = 0;
    for(i = 224; i < 230; i += 2)
	{
		// 接收组装为u16数据，高位在前，低位在后
		p_tmp3[index++] = ((pbuf[i] << 8) | pbuf[i+1]);
	}
	return 1;
}


/**
 * @brief  发送指令
 * @param  [in] dev_addr 从机地址
 * @param  [in] function_id 功能码                               
 * @param  [in] data_len 数据段长度
 * @param  [in] p_data 数据段首地址
 * @param  [out] none
 * @return 0：成功  -1：失败
 */
int32_t sci_send_command(uint8_t dev_addr,uint16_t function_id, int32_t data_len, uint8_t *p_data)
{
    uint8_t txbuf[SCI_BUF_SIZE] = {0};
    int32_t send_len = 0;
	int32_t ret = -1;
    cu_sofar_sci_t sci_pack_tx;

	regular_data_pack(&sci_pack_tx, function_id, p_data, data_len);
    memset(txbuf, 0, SCI_BUF_SIZE);

    // 打包
    send_len = cu_sofar_sci_pack(&sci_pack_tx, txbuf, SCI_BUF_SIZE);
	if(send_len == -1)
	{
		SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] pack err ret = %d!\n", __func__, __LINE__,send_len);
		return -1;
	}
    SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] send_len = %d\n", __func__, __LINE__,send_len);

    // 发送
    ret = sdk_uart_write(SDK_UART2, txbuf, send_len);
    
    if(ret < 0)
    {
        SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] sci cmd send fail!\n",__func__, __LINE__);
		sci_error_handle(g_sci_task.devaddr, 1, 0);						// 异常未超时
		return -1;
    }
    else
    {
        SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] sci send_frame: ",__func__, __LINE__);
        print_frame(txbuf, send_len);
        // mem_sci_format_print( SCI_ROLE_MASTER, FR_IN_POS_HEAD, txbuf, send_len );
    }

    return 0;
}



/**
 * @brief  读取应答数据
 * @param  [in] time_out_ms	串口读取超时时间 
 * @param  [out] ack_data_buffer 应答数据段首地址
 * @param  [in] buf_len 接收缓存大小
 * @param  [in] function_id 功能码 
 * @return 读取结果 >=0：数据段长度  -1：失败
 */
int32_t sci_read_ackdata(int32_t time_out_ms, uint8_t *ack_data_buffer, uint8_t buf_len, uint16_t function_id)
{
    uint8_t rxbuf[SCI_BUF_SIZE] = {0};
    int32_t ret = -1;
    int32_t valid_data_len = 0;
    int32_t recv_len = 0;
    cu_sofar_sci_t sci_pack_rx;

	if(NULL == ack_data_buffer)
	{
		return -1;
	}
    
	regular_data_pack(&sci_pack_rx, function_id, &rxbuf[INDEX_DATA_SLAVE], SCI_BUF_SIZE);
    
    // 接收
    memset(rxbuf, 0, SCI_BUF_SIZE);
    memset(ack_data_buffer, 0, buf_len);
    ret = sdk_uart_read(SDK_UART2, rxbuf, SCI_BUF_SIZE, time_out_ms);
    SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] recv_len = %d\n", __func__, __LINE__,ret);

    if(ret < 0)
    {
        SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] uart read fail!\n",__func__, __LINE__);
		sci_error_handle(g_sci_task.devaddr, 1, 1);						// 异常且超时
        return -1;
    }

    recv_len = (ret > SCI_BUF_SIZE)?SCI_BUF_SIZE:ret;
    SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] sci recv_frame: ",__func__, __LINE__);
    print_frame(rxbuf, recv_len);

    // 框架解包
    ret = cu_sofar_sci_unpack(DEV_ADDR_CONTAINER, function_id, &sci_pack_rx, rxbuf, recv_len);
    if(ret != 0)
    {
        SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] unpack fail and ret = %d!\n",__func__, __LINE__,ret);
		sci_error_handle(g_sci_task.devaddr, 1, 0);						// 异常未超时
        return -1;
    }

    valid_data_len = rxbuf[3]-2;
    // 限幅
    valid_data_len = (int32_t)((valid_data_len>buf_len)?buf_len:valid_data_len);

    memcpy(ack_data_buffer, &rxbuf[INDEX_DATA_SLAVE], valid_data_len);
    SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] sci recv ok\n",__func__, __LINE__);
    
    return valid_data_len;
}

/**
 * @brief  上电握手过程--交互
 * @param  [in] none
 * @param  [out] none
 * @return 0:成功  -1:失败
 */
static int32_t sci_handshake_course(void)
{
	uint8_t i = 0;
	int32_t ret = -1;
	int32_t data_len = 0;			// 发送数据长度
	int32_t valid_data_len = 0;		// 接收有效数据长度

	course_flag_set();				// 交互开始
	// 1、发送
	memset(g_sci_task.txbuf, 0, SCI_BUF_SIZE);
	data_len = sci_onpack_handshake(&g_sci_task.txbuf[INDEX_DATA_HOST]);
	
	if(data_len == -1)
	{
		course_flag_clear();
		return -1;
	}

	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		// 发送握手数据
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_HANDSHAKED, data_len, &g_sci_task.txbuf[INDEX_DATA_HOST]);

        // 获取应答结果
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_HANDSHAKED);
		} 
		pthread_mutex_unlock(&sofar_sci_mutex);

		if(ret > 0)
		{	
			valid_data_len = ret;
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n" ,__func__, __LINE__,valid_data_len);
			break;
		}

		usleep(1000 * 100);

	}
	// 数据处理
	if (valid_data_len > 0)		
	{		
		// 解析握手信息
		sci_onparse_handshake(&g_sci_task.rxbuf[INDEX_DATA_SLAVE]);	
		// 版本信息上传至共享内存
		sci_update_deviceinfo_to_shm();
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
		ret = 0;

	}
	course_flag_clear();				// 交互结束

	return ret;
}


/**
 * @brief  SCI 回应数据处理
 * @param  [in] p_resp_playload_dat  ： 回应数据
 * @param  [in] resp_playload_datlen ： 回应数据长度
 * @return SF_OK：成功  非SF_OK：失败
 * @note   
 */
typedef sf_ret_t (*respond_proc_callback)( uint8_t *p_resp_playload_dat, uint16_t resp_playload_datlen );

/**
 * @brief  sci 请求数据
 * @param  [in] function_id             ： 功能ID
 * @param  [in] request_playload_dat    ： 请求数据
 * @param  [in] request_playload_datlen ： 请求数据长度
 * @param  [in] respond_proc_cb         ： 回应处理回调
 * @return SF_OK：成功  非SF_OK：失败
 * @note   
 */
static sf_ret_t _sci_requset_data( uint16_t function_id, uint8_t *request_playload_dat, uint16_t request_playload_datlen,
                                  respond_proc_callback respond_proc_cb )
{
    sf_ret_t ret = SF_OK;
    
    if ( sci_is_ready() == SF_FALSE ) 
    {
        return SF_ERR_BUSY;
    }

	course_flag_set();
    
	memset( &g_sci_task.txbuf, 0, SCI_BUF_SIZE);
	memset( &g_sci_task.rxbuf, 0, SCI_BUF_SIZE);
    memcpy( &g_sci_task.txbuf[INDEX_DATA_HOST], request_playload_dat, request_playload_datlen );
    
    uint32_t rd_len = -1;

    for ( size_t i = 0; i < CMD_RETRYCNT_MAX; i++ )
	{
		pthread_mutex_lock( &sofar_sci_mutex );
		if( 0 == sci_send_command(DEV_ADDR_CONTAINER, function_id, request_playload_datlen, &g_sci_task.txbuf[INDEX_DATA_HOST] ))
		{
			rd_len = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, function_id);
		} 
		pthread_mutex_unlock(&sofar_sci_mutex);
		if( rd_len >= 0 )
		{
            if ( rd_len == 0 )
            {
                log_w( (int8_t*)"sci respond playload is empty!!!" );
            }
			break;
		}
		usleep(1000 * 100);
	}

    if ( rd_len < 0 )
    {
        log_e( (int8_t*)"[%s]sci respond error!!!", __FUNCTION__ );
        ret = SF_ERR_NDEF;
    }

	// 数据处理
    if ( SF_OK == respond_proc_cb( &g_sci_task.rxbuf[INDEX_DATA_SLAVE], rd_len ))
    {
        /* 正常 */
        sci_error_handle(g_sci_task.devaddr, 0, 0);
    } else {
        /* 处理异常 */
        sci_error_handle(g_sci_task.devaddr, 1, 0);
        ret = SF_ERR_PARA;
    }
	course_flag_clear();		// 交互结束

    return ret;
}


/**
 * @brief  sci 回应遥测数据处理
 * @param  [in] p_resp_dat  ：回应的数据 
 * @param  [in] resp_datlen ：回应的数据长度
 * @return SF_OK:成功  非SF_OK:失败
 */
static sf_ret_t _sci_respond_remote_meas_handle( uint8_t *p_resp_playload_dat, uint16_t resp_playload_datlen )
{
	if ( resp_playload_datlen != ( MEMBER_DAT_LEN_CAL( &g_sci_localbuf.realtimedata.cabinet_param_data.energy_storage_nums,   \
														&g_sci_localbuf.realtimedata.cabinet_param_data.scenario_setting )     \
								+ MEMBER_DAT_LEN_CAL( &g_sci_localbuf.realtimedata.sys_cabinet_telemetry_info.system_status, \
														&g_sci_localbuf.realtimedata.sys_cabinet_telemetry_info.res[0] ) - sizeof(uint16_t) \
								+ MEMBER_DAT_LEN_CAL( &g_sci_localbuf.realtimedata.cabinet_param_data.humidity_set, \
														&g_sci_localbuf.realtimedata.cabinet_param_data.humidity_diff_set ) \
									+ sizeof( g_sci_localbuf.realtimedata.cabinet_type )))
    {
        return SF_ERR_PARA;
    }

    uint8_t  *p_u8_data = NULL;
    uint16_t *p_u16_data = NULL;
    uint32_t *p_u32_data = NULL;
	uint16_t LL;
	uint16_t HH;

    p_u8_data  = p_resp_playload_dat;
    /* 拷贝 储能柜个数 ~ 应用场景 数据 */
    p_u16_data = (uint16_t*)&g_sci_localbuf.realtimedata.cabinet_param_data.energy_storage_nums;
    for( ; p_u16_data <= (uint16_t*)&g_sci_localbuf.realtimedata.cabinet_param_data.scenario_setting ; )
    {
        *p_u16_data = (uint16_t)( p_u8_data[0] << 8 ) | p_u8_data[1] ;
        p_u8_data  += 2;
        p_u16_data += 1;
    }

    /* 拷贝 系统状态字 ~ 除湿器湿度 数据 */
    p_u16_data = (uint16_t*)&g_sci_localbuf.realtimedata.sys_cabinet_telemetry_info.system_status;
    for( ; p_u16_data <= (uint16_t*)&g_sci_localbuf.realtimedata.sys_cabinet_telemetry_info.at_temperature ; )
    {
        *p_u16_data = (uint16_t)( p_u8_data[0] << 8 ) | p_u8_data[1] ;
        p_u8_data  += 2;
        p_u16_data += 1;
    }

    /* 拷贝 交流侧有功功率 ~ PCS柜1总运行时间 数据 */
    p_u32_data = (uint32_t*)&g_sci_localbuf.realtimedata.sys_cabinet_telemetry_info.ac_side_active_power;
    for( ; p_u32_data <= (uint32_t*)&g_sci_localbuf.realtimedata.sys_cabinet_telemetry_info.total_run_time ; )
    {
        *p_u32_data = (uint32_t)( p_u8_data[0] << 24 ) | ( p_u8_data[1] << 16 ) | ( p_u8_data[2] << 8 ) | p_u8_data[3] ;
        p_u8_data  += 4;
        p_u32_data += 1;
    }

    p_u16_data = (uint16_t*)&g_sci_localbuf.realtimedata.sys_cabinet_telemetry_info.ac_side_phase_vol_r;
    for( ; p_u16_data <= (uint16_t*)&g_sci_localbuf.realtimedata.sys_cabinet_telemetry_info.ac_side_phase_t_view_power ; )
    {
        *p_u16_data = (uint16_t)( p_u8_data[0] << 8 ) | p_u8_data[1] ;
        p_u8_data  += 2;
        p_u16_data += 1;
    }

	LL = htons(*(uint16_t *)&p_u8_data[0]);
	HH = htons(*(uint16_t *)&p_u8_data[2]);
	g_sci_localbuf.realtimedata.sys_cabinet_telemetry_info.anti_reflux_power = uint32_to_float(LL, HH);
    p_u8_data  += 4;

    p_u16_data = (uint16_t*)&g_sci_localbuf.realtimedata.sys_cabinet_telemetry_info.dry_temp;
    for( ; p_u16_data <= (uint16_t*)&g_sci_localbuf.realtimedata.sys_cabinet_telemetry_info.dry_humidity ; )
    {
        *p_u16_data = (uint16_t)( p_u8_data[0] << 8 ) | p_u8_data[1] ;
        p_u8_data  += 2;
        p_u16_data += 1;
    }

    p_u16_data = (uint16_t*)&g_sci_localbuf.realtimedata.cabinet_type;
    *p_u16_data = (uint16_t)( p_u8_data[0] << 8 ) | p_u8_data[1] ;
	p_u8_data += 2;

    p_u16_data = (uint16_t*)&g_sci_localbuf.realtimedata.cabinet_param_data.humidity_set;
    for( ; p_u16_data <= (uint16_t*)&g_sci_localbuf.realtimedata.cabinet_param_data.humidity_diff_set ; )
    {
        *p_u16_data = (uint16_t)( p_u8_data[0] << 8 ) | p_u8_data[1] ;
        p_u8_data  += 2;
        p_u16_data += 1;
    }
	LL = htons(*(uint16_t *)&p_u8_data[0]);
	HH = htons(*(uint16_t *)&p_u8_data[2]);
	g_sci_localbuf.realtimedata.sys_cabinet_telemetry_info.photo_meter_power = uint32_to_float(LL, HH);
    p_u8_data  += 4;

    return SF_OK;
}

/**
 * @brief  sci 回应遥控数据处理
 * @param  [in] p_resp_dat  ：回应的数据 
 * @param  [in] resp_datlen ：回应的数据长度
 * @return SF_OK:成功  非SF_OK:失败
 */
static sf_ret_t _sci_respond_remote_ctrl_handle( uint8_t *p_resp_playload_dat, uint16_t resp_playload_datlen )
{
    if ( resp_playload_datlen != sizeof( uint16_t ))
    {
        SCI_DEBUG_LOG((int8_t *)"%s para error, resp_playload_datlen!!!\r\n", __FUNCTION__ );

        return SF_ERR_PARA;
    }
    g_sci_localbuf.realtimedata.ctl_cmd = (uint16_t)( (p_resp_playload_dat[0] << 8) | p_resp_playload_dat[1] );
    return SF_OK;
}

/**
 * @brief  sci 回应功率数据
 * @param  [in] p_resp_dat  ：回应的数据 
 * @param  [in] resp_datlen ：回应的数据长度
 * @return SF_OK:成功  非SF_OK:失败
 */
static sf_ret_t _sci_respond_power_setting_handle( uint8_t *p_resp_playload_dat, uint16_t resp_playload_datlen )
{
    if ( resp_playload_datlen != 4)
    {
        SCI_DEBUG_LOG((int8_t *)"%s para error, resp_playload_datlen!!!\r\n", __FUNCTION__ );

        return SF_ERR_PARA;
    }

    g_sci_localbuf.realtimedata.cabinet_param_data.active_power   = (int16_t)( (p_resp_playload_dat[0] << 8) | p_resp_playload_dat[1] );
    g_sci_localbuf.realtimedata.cabinet_param_data.reactive_power = (int16_t)( (p_resp_playload_dat[2] << 8) | p_resp_playload_dat[3] );

    return SF_OK;
}

/**
 * @brief  sci 回应遥信数据处理
 * @param  [in] p_resp_dat  ：回应的数据 
 * @param  [in] resp_datlen ：回应的数据长度
 * @return SF_OK:成功  非SF_OK:失败
 */
static sf_ret_t _sci_respond_remote_sig_handle( uint8_t *p_resp_playload_dat, uint16_t resp_playload_datlen )
{
    if ( resp_playload_datlen != (  sizeof( g_sci_localbuf.realtimedata.combiner_cabinet_system_status_info ) 
                                  + sizeof( g_sci_localbuf.realtimedata.combiner_cabinet_system_fault_info  )))
    {
        return SF_ERR_PARA;
    }

    // 状态信息 8Bytes
    for (size_t i = 0; i < COMBINER_CABINET_SYSTEM_STATUS_LEN_BYTE; i += 2)
    {
        g_sci_localbuf.realtimedata.combiner_cabinet_system_status_info[i]   = p_resp_playload_dat[i+1];
        g_sci_localbuf.realtimedata.combiner_cabinet_system_status_info[i+1] = p_resp_playload_dat[i];
    }
    
    // 故障信息 16Bytes
    for (size_t i = 0; i < COMBINER_CABINET_SYSTEM_FAULT_LEN_BYTE; i += 2)
    {
        g_sci_localbuf.realtimedata.combiner_cabinet_system_fault_info[i]   = p_resp_playload_dat[ 8 + i+1];
        g_sci_localbuf.realtimedata.combiner_cabinet_system_fault_info[i+1] = p_resp_playload_dat[ 8 + i];
    }
	// 不清楚这行是做什么的，但是会影响遥控的回读，先屏蔽
    // g_sci_localbuf.realtimedata.ctl_cmd = (uint16_t)( (p_resp_playload_dat[0] << 8) | p_resp_playload_dat[1] );
    return SF_OK;
}

/**
 * @brief  获取实时数据过程--交互
 * @param  [in] none
 * @param  [out] none
 * @return 0:成功  负数:失败
 */
static void sci_realtimedata_course( void )
{
	_sci_requset_data( FUNCID_GET_POWER      , NULL, 0, _sci_respond_power_setting_handle );
	_sci_requset_data( FUNCID_GET_REMOTE_CTRL, NULL, 0, _sci_respond_remote_ctrl_handle );
	_sci_requset_data( FUNCID_GET_REMOTE_MEAS, NULL, 0, _sci_respond_remote_meas_handle );
	_sci_requset_data( FUNCID_GET_REMOTE_SIG , NULL, 0, _sci_respond_remote_sig_handle  );

    sci_update_realtimedata_to_shm();
}


/**
 * @brief  握手应答数据解析
 * @param  [in] p_data 指向应答包的数据段起始位置
 * @param  [in] buf_len	有效数据段长度 
 * @param  [out] none
 * @return 0：成功  -1：失败
 */
int32_t sci_onparse_ethdata(uint8_t *p_data,uint8_t data_len) 
{
	sci_eth_info_t *p_eth_info = NULL;
	p_eth_info = &g_sci_localbuf.net_param;

	if((p_eth_info == NULL) || (data_len < 16))
	{
		SCI_DEBUG_LOG((int8_t *)"\n [%s:%d]  data error\n",__func__, __LINE__);
		return -1;
	}

	for(int32_t i = 0; i < data_len;i++)
	{
		if(p_data[i] > 255)
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d]  net data error\n",__func__, __LINE__);
			return -1;
		}
	}

    snprintf((char *)p_eth_info->IP_ETH_2,NET_ADDR_LEN_MAX, "%d.%d.%d.%d", p_data[0], p_data[1], p_data[2], p_data[3]);
	snprintf((char *)p_eth_info->gw_ETH_2,NET_ADDR_LEN_MAX, "%d.%d.%d.%d", p_data[4], p_data[5], p_data[6], p_data[7]);
	snprintf((char *)p_eth_info->mask_ETH_2,NET_ADDR_LEN_MAX, "%d.%d.%d.%d", p_data[8], p_data[9], p_data[10], p_data[11]);
	snprintf((char *)p_eth_info->DNS1_ETH_2, NET_ADDR_LEN_MAX,"%d.%d.%d.%d", p_data[12], p_data[13], p_data[14], p_data[15]);
	return 0;
}


void sci_update_eth_data_to_shm(void)
{
    sci_eth_info_t *pdata = NULL;
	common_data_t *shm = NULL;
    

	shm = sdk_shm_get();
    pdata = &g_sci_localbuf.net_param;      					
	if(shm == NULL || pdata == NULL)
	{
		return;
	}

    memcpy(&shm->other_parameter_data.IP_ETH_2,&pdata->IP_ETH_2,NET_ADDR_LEN_MAX);
	memcpy(&shm->other_parameter_data.mask_ETH_2,&pdata->gw_ETH_2,NET_ADDR_LEN_MAX);
	memcpy(&shm->other_parameter_data.gw_ETH_2,&pdata->mask_ETH_2,NET_ADDR_LEN_MAX);
	memcpy(&shm->other_parameter_data.DNS1_ETH_2,&pdata->DNS1_ETH_2,NET_ADDR_LEN_MAX);

	return;
}

/**
 * @brief  获取网络数据过程--交互
 * @param  [in] none
 * @param  [out] none
 * @return 0:成功  负数:失败
 */
static int32_t sci_ethdata_course(void)
{
	uint8_t i = 0;
	int32_t ret = -1;
	int32_t rtn = -1;
	int32_t valid_data_len = 0;
	int32_t data_len = 0;		// 发送数据长度

    if(sci_is_ready() != true)
    {
        return -1;
    }
	course_flag_set();			// 交互开始
	memset(g_sci_task.txbuf, 0, SCI_BUF_SIZE);
	
	for(i=0; i<CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_GET_ETH_DATA, data_len, &g_sci_task.txbuf[INDEX_DATA_HOST]);
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_GET_ETH_DATA);
		} 
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{
			valid_data_len = ret;
			break;
		}
		usleep(1000 * 100);
	}
	// 数据处理
	if(valid_data_len > 0)
	{
		// 网络数据解析
		ret = sci_onparse_ethdata(&g_sci_task.rxbuf[INDEX_DATA_SLAVE], valid_data_len);	
		if(ret != -1)
		{
			sci_update_eth_data_to_shm();
			// 清共享内存计数
			sci_error_handle(g_sci_task.devaddr, 0, 0);
			rtn = 0;
		}
		else
		{
			sci_error_handle(g_sci_task.devaddr, 1, 0);				// 解析异常
			rtn = -1;
		}
	}
	course_flag_clear();		// 交互结束
	return rtn;
}


/**
* @brief		同步时间
* @return		void
*/
void sync_time(void)
{
	uint8_t *time_buf = NULL;
	uint8_t len = 0;
	int32_t ret = 0;
	int32_t i = 0;

    if(sci_is_ready() != true)
    {
        return;
    }
	course_flag_set();			// 交互开始
	
	sdk_rtc_t rtc_time;
	sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
	SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] system time:%02i:%02i:%02i (%02i)%02i/%02i/%04i\n",__func__, __LINE__, rtc_time.tm_hour,
                         rtc_time.tm_min,
                         rtc_time.tm_sec,
                         rtc_time.tm_weekday,
                         rtc_time.tm_day,
                         rtc_time.tm_mon,
                         rtc_time.tm_year + 2000);
	
	time_buf = &g_sci_task.txbuf[INDEX_DATA_HOST];
	
	time_buf[len++] = (rtc_time.tm_sec >> 8) & 0xff;
	time_buf[len++] = (rtc_time.tm_sec >> 0) & 0xff;
	time_buf[len++] = (rtc_time.tm_min >> 8) & 0xff;
	time_buf[len++] = (rtc_time.tm_min >> 0) & 0xff;
	time_buf[len++] = (rtc_time.tm_hour >> 8) & 0xff;
	time_buf[len++] = (rtc_time.tm_hour >> 0) & 0xff;
	#if SCI_V1_8_TEST
	time_buf[len++] = (rtc_time.tm_weekday >> 8) & 0xff;
	time_buf[len++] = (rtc_time.tm_weekday >> 0) & 0xff;
	#endif
	time_buf[len++] = (rtc_time.tm_day >> 8) & 0xff;
	time_buf[len++] = (rtc_time.tm_day >> 0) & 0xff;
	time_buf[len++] = (rtc_time.tm_mon >> 8) & 0xff;
	time_buf[len++] = (rtc_time.tm_mon >> 0) & 0xff;
	time_buf[len++] = (rtc_time.tm_year >> 8) & 0xff;
	time_buf[len++] = (rtc_time.tm_year >> 0) & 0xff;
	
	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		// 发送握手数据
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_SYNC_TIME, len, &g_sci_task.txbuf[INDEX_DATA_HOST]);
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_SYNC_TIME);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__, ret);
			break;
		}
		usleep(1000 * 100);
	}
	if(ret > 0)
	{
		// 无数据处理
		if(1 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
		{
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] sync_time Set ok!!!\n"),__func__, __LINE__);
		}
		else if(0 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
		{
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] sync_time Set fail!\n"),__func__, __LINE__);	
		}
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束
	return;
}


/**
* @brief		周期更新系统时间
* @return		void
*/
void period_sync_time()
{
	static uint8_t wait_cnt = 0;
 
    if(wait_cnt++ < SCI_SYS_TIME_UPDATE)
    {
        return;
    }

    wait_cnt = 0;
    sync_time();
}


uint8_t get_hour_from_short_type_time(uint16_t time)
{
	char tmp_time[5] = {0};
	char hour[2] = {0};

	sprintf(tmp_time, "%d", time);
	if((strlen(tmp_time) == 1) || (strlen(tmp_time) == 2))
	{
		return 0;
	} 
	else if(strlen(tmp_time) == 3)
	{
		memcpy(hour, tmp_time, 1);
	}
	else
	{
		memcpy(hour, tmp_time, 2);
	}

	return atoi(hour);
}


uint8_t get_min_from_short_type_time(uint16_t time)
{
	char tmp_time[5] = {0};
	char min[2] = {0};

	sprintf(tmp_time, "%d", time);
	if((strlen(tmp_time) == 1) || (strlen(tmp_time) == 2))
	{
		memcpy(min, tmp_time, strlen(tmp_time));
	}
	else if(strlen(tmp_time) == 3)
	{
		memcpy(min, &tmp_time[1], 2);
	}
	else
	{
		memcpy(min, &tmp_time[2], 2);
	}

	return atoi(min);
}


uint16_t get_time_form_hour_min(uint8_t hour, uint8_t min)
{
	char tmp_time[5] = {0};

	if(min < 10)
	{
		//如果分钟是1-9则前面补0
		sprintf(tmp_time, "%d%d%d", hour, 0, min);
	}
	else
	{
		sprintf(tmp_time, "%d%d", hour, min);
	}
	
	return atoi(tmp_time);
}



/**
* @brief		EMS数据解析
* @return		void
*/
static void sci_onparse_ems_parm(uint8_t *p_data)
{
	common_data_t *shm = NULL;
	ems_data_t *p_ems_para_data = NULL;

	shm = sdk_shm_get();
	p_ems_para_data = &shm->constant_parameter_data.ems_data;
	if(p_ems_para_data == NULL)
	{
		SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ems param data is NULL\n",__func__, __LINE__);
		return;
	}

	// 提取参数并同步至共享内存
	p_ems_para_data->demand_resp_en = 			htons(*(uint16_t *)&p_data[0]);
	p_ems_para_data->quantity_demand_dead_zone = htons(*(uint16_t *)&p_data[2]);
	p_ems_para_data->quantity_demand = 			htons(*(uint16_t *)&p_data[4]);
	p_ems_para_data->anti_reflux_action_en = 	htons(*(uint16_t *)&p_data[6]);
	p_ems_para_data->anti_reflux_action_dead_zone = htons(*(uint16_t *)&p_data[8]);
	p_ems_para_data->capa_change_need_en = 		htons(*(uint16_t *)&p_data[10]);
	p_ems_para_data->capa_change_need_demand = 	htons(*(uint16_t *)&p_data[12]);
	p_ems_para_data->shav_peak_fill_valley_en =	htons(*(uint16_t *)&p_data[14]);
	for(uint8_t i = 0; i < EMS_TIME_DURATION_CNT; i++)
	{
		p_ems_para_data->time_attr[i].enable_type = htons(*(uint16_t *)&p_data[16 + i * 6]);
		p_ems_para_data->time_attr[i].start_time = get_time_form_hour_min(p_data[18 + i * 6], p_data[19 + i * 6]);
		p_ems_para_data->time_attr[i].end_time = get_time_form_hour_min(p_data[20 + i * 6], p_data[21 + i * 6]);
	} 
	p_ems_para_data->end_charge_soc_max = 		htons(*(uint16_t *)&p_data[76]);
	p_ems_para_data->pcc_power_set = 			htons(*(int16_t *)&p_data[78]);
	p_ems_para_data->k1_coefficient = 			htons(*(uint16_t *)&p_data[80]);
	p_ems_para_data->theory_max_charge_power = 	htons(*(uint16_t *)&p_data[82]);
	p_ems_para_data->discharge_soc_min = 		htons(*(uint16_t *)&p_data[84]);
	p_ems_para_data->discharge_power_adjust_step = htons(*(uint16_t *)&p_data[86]);
	p_ems_para_data->k2_coefficient = 			htons(*(uint16_t *)&p_data[88]);
	p_ems_para_data->theory_max_discharge_power = htons(*(uint16_t *)&p_data[90]);
	p_ems_para_data->soc_maintain_en = 			htons(*(uint16_t *)&p_data[92]);
	p_ems_para_data->soc_maintain_power = 		htons(*(uint16_t *)&p_data[94]);
	p_ems_para_data->power_adjust_ctr_en = 		htons(*(uint16_t *)&p_data[96]);
	p_ems_para_data->power_adjust_ctr_step = 	htons(*(uint16_t *)&p_data[98]);
	p_ems_para_data->power_factor = 			htons(*(uint16_t *)&p_data[100]);
	p_ems_para_data->rated_capa = 				htons(*(uint16_t *)&p_data[102]);
	p_ems_para_data->peak_end_early_time = 		htons(*(uint16_t *)&p_data[104]);
	p_ems_para_data->sharp_end_early_time = 	htons(*(uint16_t *)&p_data[106]);
	p_ems_para_data->valley_end_early_time = 	htons(*(uint16_t *)&p_data[108]);
    p_ems_para_data->noload_to_standby_time = 	htons(*(uint16_t *)&p_data[110]);
    p_ems_para_data->noload_to_shutdown_time = 	htons(*(uint16_t *)&p_data[112]);
    p_ems_para_data->poweron_early_time = 	    htons(*(uint16_t *)&p_data[114]);
    p_ems_para_data->self_cosum_mode_enable = 	htons(*(uint16_t *)&p_data[116]);
    p_ems_para_data->meter_curr_dir = 	        htons(*(uint16_t *)&p_data[118]);
	for(uint8_t i = 0; i < EMS_TIME_DURATION_CNT; i++)
	{
		p_ems_para_data->power[i] = htons(*(int16_t *)&p_data[120 + 2 * i]);
	} 
}

/**
* @brief		主从机数据解析
* @return		void
*/
static void sci_onparse_master_slave_parm(uint8_t *p_data)
{
	csu_combine_info_t *p_csu_combine = sdk_shm_csu_combine_data_get();
	uint8_t i;
	uint8_t index = 0;

	g_sci_master_slave_data.comb_setting.comb_role = htons(*(uint16_t *)&p_data[index]);
	SCI_DEBUG_LOG((int8_t *)"g_sci_master_slave_data->role : %d\r\n",p_csu_combine->comb_setting.comb_role);
	index += 2;
    p_csu_combine->master_info.ems_alloc_power = htons(*(uint16_t *)&p_data[index]);
	index += 2;
	for (i = 0; i < (MAX_SLAVE_COUNT - 1); i++)
	{
		p_csu_combine->slave_info[i].ems_alloc_power = htons(*(uint16_t *)&p_data[index]);
		SCI_DEBUG_LOG((int8_t *)"p_csu_combine->csu_slave_power_list[i] : %d\r\n", p_csu_combine->slave_info[i].ems_alloc_power);
		index += 2;
	}
}

/**
* @brief		上电获取从机EMS参数
* @return		void
*/
static void sci_get_ems_parm(uint8_t repeat_flat)
{
	uint16_t i;
	int16_t ret = -1;
	// SCI打包接口数据段不能填空，定义临时变量
	uint8_t tmp_buf[1] = {0};
    static uint8_t wait_cnt = 0;

    if((wait_cnt++ < SCI_EMS_DATA) && (repeat_flat))
    {
        return;
    }

    if(sci_is_ready() != true)
    {
        return;
    }
	course_flag_set();			// 交互开始
	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_GET_EMS_PARM, 0, tmp_buf);
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_GET_EMS_PARM);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__,ret);
			break;
		}
		else
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__,ret);
		}
		usleep(1000 * 100);
	}
	if(ret > 0)
	{
		// 解析EMS信息
		sci_onparse_ems_parm(&g_sci_task.rxbuf[INDEX_DATA_SLAVE]);	
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束
    wait_cnt = 0;
}


/**
 * @brief  打包EMS参数
 * @param  [in]  none
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
static int32_t ems_data_pack(uint8_t *p_data)
{
	uint8_t offet = 0;
    ems_data_t *p_ems_para_data = NULL;

    web_control_info_t *p_web_contol_data = shm_web_control_info_get();
	p_ems_para_data = &(p_web_contol_data->ems_data);
	if(p_ems_para_data == NULL)
	{
		return -1;
	}

    //判断是否存在互斥功能
    if(p_ems_para_data->self_cosum_mode_enable && (p_ems_para_data->anti_reflux_action_en || 
                                                   p_ems_para_data->capa_change_need_en))
    {
        return -1;
    }

	p_data[offet++] = p_ems_para_data->demand_resp_en >> 8;
	p_data[offet++] = p_ems_para_data->demand_resp_en & 0xff;
	p_data[offet++] = p_ems_para_data->quantity_demand_dead_zone >> 8;
	p_data[offet++] = p_ems_para_data->quantity_demand_dead_zone & 0xff;
	p_data[offet++] = p_ems_para_data->quantity_demand >> 8;
	p_data[offet++] = p_ems_para_data->quantity_demand & 0xff;
	p_data[offet++] = p_ems_para_data->anti_reflux_action_en >> 8;
	p_data[offet++] = p_ems_para_data->anti_reflux_action_en & 0xff;
	p_data[offet++] = p_ems_para_data->anti_reflux_action_dead_zone >> 8;
	p_data[offet++] = p_ems_para_data->anti_reflux_action_dead_zone & 0xff;
	p_data[offet++] = p_ems_para_data->capa_change_need_en >> 8;
	p_data[offet++] = p_ems_para_data->capa_change_need_en & 0xff;
	p_data[offet++] = p_ems_para_data->capa_change_need_demand >> 8;
	p_data[offet++] = p_ems_para_data->capa_change_need_demand & 0xff;
	p_data[offet++] = p_ems_para_data->shav_peak_fill_valley_en >> 8;
	p_data[offet++] = p_ems_para_data->shav_peak_fill_valley_en & 0xff;
	for(uint8_t i = 0; i < EMS_TIME_DURATION_CNT; i++)
	{
		p_data[offet++] = p_ems_para_data->time_attr[i].enable_type >> 8;
		p_data[offet++] = p_ems_para_data->time_attr[i].enable_type & 0xff;
		p_data[offet++] = get_hour_from_short_type_time(p_ems_para_data->time_attr[i].start_time);
		p_data[offet++] = get_min_from_short_type_time(p_ems_para_data->time_attr[i].start_time);
		p_data[offet++] = get_hour_from_short_type_time(p_ems_para_data->time_attr[i].end_time);
		p_data[offet++] = get_min_from_short_type_time(p_ems_para_data->time_attr[i].end_time);
	}
	p_data[offet++] = p_ems_para_data->end_charge_soc_max >> 8;
	p_data[offet++] = p_ems_para_data->end_charge_soc_max & 0xff;
	p_data[offet++] = p_ems_para_data->pcc_power_set >> 8;
	p_data[offet++] = p_ems_para_data->pcc_power_set & 0xff;
	p_data[offet++] = p_ems_para_data->k1_coefficient >> 8;
	p_data[offet++] = p_ems_para_data->k1_coefficient & 0xff;
	p_data[offet++] = p_ems_para_data->theory_max_charge_power >> 8;
	p_data[offet++] = p_ems_para_data->theory_max_charge_power & 0xff;
	p_data[offet++] = p_ems_para_data->discharge_soc_min >> 8;
	p_data[offet++] = p_ems_para_data->discharge_soc_min & 0xff;
	p_data[offet++] = p_ems_para_data->discharge_power_adjust_step >> 8;
	p_data[offet++] = p_ems_para_data->discharge_power_adjust_step & 0xff;
	p_data[offet++] = p_ems_para_data->k2_coefficient >> 8;
	p_data[offet++] = p_ems_para_data->k2_coefficient & 0xff;
	p_data[offet++] = p_ems_para_data->theory_max_discharge_power >> 8;
	p_data[offet++] = p_ems_para_data->theory_max_discharge_power & 0xff;
	p_data[offet++] = p_ems_para_data->soc_maintain_en >> 8;
	p_data[offet++] = p_ems_para_data->soc_maintain_en & 0xff;
	p_data[offet++] = p_ems_para_data->soc_maintain_power >> 8;
	p_data[offet++] = p_ems_para_data->soc_maintain_power & 0xff;
	p_data[offet++] = p_ems_para_data->power_adjust_ctr_en >> 8;
	p_data[offet++] = p_ems_para_data->power_adjust_ctr_en & 0xff;
	p_data[offet++] = p_ems_para_data->power_adjust_ctr_step >> 8;
	p_data[offet++] = p_ems_para_data->power_adjust_ctr_step & 0xff;
	p_data[offet++] = p_ems_para_data->power_factor >> 8;
	p_data[offet++] = p_ems_para_data->power_factor & 0xff;
	p_data[offet++] = p_ems_para_data->rated_capa >> 8;
	p_data[offet++] = p_ems_para_data->rated_capa & 0xff;
	p_data[offet++] = p_ems_para_data->peak_end_early_time >> 8;
	p_data[offet++] = p_ems_para_data->peak_end_early_time & 0xff;
	p_data[offet++] = p_ems_para_data->sharp_end_early_time >> 8;
	p_data[offet++] = p_ems_para_data->sharp_end_early_time & 0xff;
	p_data[offet++] = p_ems_para_data->valley_end_early_time >> 8;
	p_data[offet++] = p_ems_para_data->valley_end_early_time & 0xff;
	p_data[offet++] = p_ems_para_data->noload_to_standby_time >> 8;
	p_data[offet++] = p_ems_para_data->noload_to_standby_time & 0xff;
	p_data[offet++] = p_ems_para_data->noload_to_shutdown_time >> 8;
	p_data[offet++] = p_ems_para_data->noload_to_shutdown_time & 0xff;
	p_data[offet++] = p_ems_para_data->poweron_early_time >> 8;
	p_data[offet++] = p_ems_para_data->poweron_early_time & 0xff;
	p_data[offet++] = p_ems_para_data->self_cosum_mode_enable >> 8;
	p_data[offet++] = p_ems_para_data->self_cosum_mode_enable & 0xff;
	p_data[offet++] = p_ems_para_data->meter_curr_dir >> 8;
	p_data[offet++] = p_ems_para_data->meter_curr_dir & 0xff;
	for(uint8_t i = 0; i < EMS_TIME_DURATION_CNT; i++)
	{
		p_data[offet++] = p_ems_para_data->power[i] >> 8;
		p_data[offet++] = p_ems_para_data->power[i] & 0xff;
	}
    
	return offet;
}


/**
 * @brief  下发EMS参数
 * @param  [in]  none
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
int32_t set_ems_data(void)
{
	uint8_t i = 0;
	int16_t ret = -1;
	uint8_t len = 0;
    ems_data_t *p_ems_para_data = NULL;

    web_control_info_t *p_web_contol_data = shm_web_control_info_get();
	p_ems_para_data = &(p_web_contol_data->ems_data);
	if(p_ems_para_data == NULL)
	{
		return -1;
	}
    if(sci_is_ready() != true)
    {
        return -1;
    }
	memset(g_sci_task.txbuf, 0, SCI_BUF_SIZE);
	len = ems_data_pack(g_sci_task.txbuf);
	if(len < 0)
	{
		return -1;
	}

	course_flag_set();			// 交互开始
	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_SET_EMS_PARM, len, g_sci_task.txbuf);
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_SET_EMS_PARM);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__, ret);
			break;
		}
		else
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__, ret);
		}
		usleep(1000 * 100);

	}
	if(ret > 0)
	{
		// 无数据处理
		if(1 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
		{
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] set_ems_data Set ok!!!\n"),__func__, __LINE__);
            ret = 0;
		}
		else if(0 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
		{
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] set_ems_data Set fail!\n"),__func__, __LINE__);	
            ret = -1;
		}
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束
    //设置成功过后进行读取，同步至贡献内存
    sci_get_ems_parm(0);
	return ret;
}

/**
* @brief		EMS数据解析
* @return		void
*/
static void sci_onparse_holiday_ems_parm(uint8_t *p_data)
{
	common_data_t *shm = NULL;
	ems_holiday_data_t *p_ems_para_data = NULL;
	uint16_t offset = 0;
	shm = sdk_shm_get();
	p_ems_para_data = &shm->constant_parameter_data.ems_holiday_data;
	if(p_ems_para_data == NULL)
	{
		SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ems param data is NULL\n",__func__, __LINE__);
		return;
	}

	// 提取参数并同步至共享内存

	p_ems_para_data->holiday_enable = 			htons(*(uint16_t *)&p_data[offset]);
	offset += 2;
	for(uint8_t i = 0; i < EMS_TIME_DURATION_CNT; i++)
	{
		p_ems_para_data->time_attr[i].enable_type = htons(*(uint16_t *)&p_data[offset]);
		offset += 2;
		p_ems_para_data->time_attr[i].power = htons(*(uint16_t *)&p_data[offset]);
		offset += 2;
		p_ems_para_data->time_attr[i].start_time = get_time_form_hour_min(p_data[offset], p_data[offset + 1]);
		offset += 2;
		p_ems_para_data->time_attr[i].end_time = get_time_form_hour_min(p_data[offset], p_data[offset + 1]);
		offset += 2;
	}
	for(uint8_t i = 0; i < EMS_HOLIDAY_DATE_NUM; i++)
	{
		p_ems_para_data->holiday_date[i].all = htons(*(int16_t *)&p_data[offset]);
		offset += 2;
	} 
}
/**
* @brief		上电获取从机EMS参数
* @return		void
*/
static void sci_get_holiday_ems_parm(uint8_t repeat_flat)
{
	uint16_t i;
	int16_t ret = -1;
	// SCI打包接口数据段不能填空，定义临时变量
	uint8_t tmp_buf[1] = {0};
    static uint8_t wait_cnt = 0;

    if((wait_cnt++ < SCI_EMS_DATA) && (repeat_flat))
    {
        return;
    }

    if(sci_is_ready() != true)
    {
        return;
    }
	course_flag_set();			// 交互开始
	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_GET_HOLIDAY_EMS_PARM, 0, tmp_buf);
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_GET_HOLIDAY_EMS_PARM);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__,ret);
			break;
		}
		else
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__,ret);
		}
		usleep(1000 * 100);
	}
	if(ret > 0)
	{
		// 解析EMS信息
		sci_onparse_holiday_ems_parm(&g_sci_task.rxbuf[INDEX_DATA_SLAVE]);	
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束
    wait_cnt = 0;
}
/**
 * @brief  打包EMS参数
 * @param  [in]  none
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
static int32_t ems_holiday_data_pack(uint8_t *p_data)
{
	uint8_t offset = 0;
    ems_holiday_data_t *p_ems_para_data = NULL;

    web_control_info_t *p_web_contol_data = shm_web_control_info_get();
	p_ems_para_data = &(p_web_contol_data->ems_holiday_data);
	if(p_ems_para_data == NULL)
	{
		return -1;
	}

	p_data[offset++] = p_ems_para_data->holiday_enable >> 8;
	p_data[offset++] = p_ems_para_data->holiday_enable & 0xff;
	for(uint8_t i = 0; i < EMS_TIME_DURATION_CNT; i++)
	{
		p_data[offset++] = p_ems_para_data->time_attr[i].enable_type >> 8;
		p_data[offset++] = p_ems_para_data->time_attr[i].enable_type & 0xff;
		p_data[offset++] = p_ems_para_data->time_attr[i].power >> 8;
		p_data[offset++] = p_ems_para_data->time_attr[i].power & 0xff;
		p_data[offset++] = get_hour_from_short_type_time(p_ems_para_data->time_attr[i].start_time);
		p_data[offset++] = get_min_from_short_type_time(p_ems_para_data->time_attr[i].start_time);
		p_data[offset++] = get_hour_from_short_type_time(p_ems_para_data->time_attr[i].end_time);
		p_data[offset++] = get_min_from_short_type_time(p_ems_para_data->time_attr[i].end_time);
	}
	for(uint8_t i = 0; i < EMS_HOLIDAY_DATE_NUM; i++)
	{
		p_data[offset++] = p_ems_para_data->holiday_date[i].bytes.high;
		p_data[offset++] = p_ems_para_data->holiday_date[i].bytes.low;
	}
	return offset;
}


/**
 * @brief  下发EMS参数
 * @param  [in]  none
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
int32_t set_holiday_ems_data(void)
{
	uint8_t i = 0;
	int16_t ret = -1;
	uint8_t len = 0;

    if(sci_is_ready() != true)
    {
        return -1;
    }
	memset(g_sci_task.txbuf, 0, SCI_BUF_SIZE);
	len = ems_holiday_data_pack(g_sci_task.txbuf);
	if(len < 0)
	{
		return -1;
	}

	course_flag_set();			// 交互开始
	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_SET_HOLIDAY_EMS_PARM, len, g_sci_task.txbuf);
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_SET_HOLIDAY_EMS_PARM);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__, ret);
			break;
		}
		else
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__, ret);
		}
		usleep(1000 * 100);

	}
	if(ret > 0)
	{
		// 无数据处理
		if(1 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
		{
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] set_ems_data Set ok!!!\n"),__func__, __LINE__);
            ret = 0;
		}
		else if(0 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
		{
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] set_ems_data Set fail!\n"),__func__, __LINE__);	
            ret = -1;
		}
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束
    //设置成功过后进行读取，同步至贡献内存
    sci_get_holiday_ems_parm(0);
	return ret;
}

/**
* @brief		读取小桔设置参数
* @return		void
*/
static void get_mqtt_param(void)
{
	uint16_t i;
	int16_t ret = -1;
	// SCI打包接口数据段不能填空，定义临时变量
	uint8_t tmp_buf[1] = {0};

    if(sci_is_ready() != true)
    {
        return;
    }
	course_flag_set();			// 交互开始

	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_GET_MQTT_PARAM, 0, tmp_buf);
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_GET_MQTT_PARAM);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__,ret);
			break;
		}
		else
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__,ret);
		}
		usleep(1000 * 100);
	}
	if(ret > 0)
	{
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束
}

/**
 * @brief  下发小桔设置参数
 * @param  [in]  none
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
int32_t set_mqtt_param(void)
{
	uint8_t i = 0;
	int16_t ret = -1;
    uint32_t value = 0;
	uint8_t len = 0;

    mqtt_data_t *p_mqtt_param = &(sdk_shm_get()->mqtt_data);

    if(sci_is_ready() != true)
    {
        return -1;
    }

	memset(g_sci_task.txbuf, 0, SCI_BUF_SIZE);
    value = htonl(p_mqtt_param->energy_cabinet_param.chargr_cmd);
    memcpy(&g_sci_task.txbuf[len], &value, 4);
    len += 4;
    value = htonl(p_mqtt_param->energy_cabinet_param.cluster_charge_limit_max_power);
    memcpy(&g_sci_task.txbuf[len], &value, 4);
    len += 4;
    value = htonl(p_mqtt_param->energy_cabinet_param.cluster_discharge_limit_max_power);
    memcpy(&g_sci_task.txbuf[len], &value, 4);
    len += 4;

	course_flag_set();			// 交互开始
	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_SET_MQTT_PARAM, len, g_sci_task.txbuf);
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_SET_MQTT_PARAM);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__, ret);
			break;
		}
		else
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__, ret);
		}
		usleep(1000 * 100);

	}
	if(ret > 0)
	{
		// 无数据处理
		if(1 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
		{
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] set_ems_data Set ok!!!\n"),__func__, __LINE__);
		}
		else if(0 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
		{
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] set_ems_data Set fail!\n"),__func__, __LINE__);	
		}
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束
    //设置结束之后去读取更新共享内存
    get_mqtt_param();
	return ret;
}


/**
* @brief		读取系统常量参数
* @return		void
*/
static void get_sys_run_param(void)
{
	uint16_t i;
	int16_t ret = -1;
	// SCI打包接口数据段不能填空，定义临时变量
	uint8_t tmp_buf[1] = {0};

    constant_parameter_data_t *p_const_param = sdk_shm_constant_parameter_data_get();
    if(sci_is_ready() != true)
    {
        return;
    }
	course_flag_set();			// 交互开始

	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_GET_SYS_RUN_PARAM, 0, tmp_buf);
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_GET_SYS_RUN_PARAM);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__,ret);
			break;
		}
		else
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__,ret);
		}
		usleep(1000 * 100);
	}
	if(ret > 0)
	{
        p_const_param->ems_data.discharge_soc_min = g_sci_task.rxbuf[INDEX_DATA_SLAVE];
        p_const_param->ems_data.end_charge_soc_max = g_sci_task.rxbuf[INDEX_DATA_SLAVE + 1];
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束
}

/**
 * @brief  下发系统常量参数
 * @param  [in]  none
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
int32_t set_sys_run_param(void)
{
	uint8_t i = 0;
	int16_t ret = -1;
	uint8_t len = 0;

    web_control_info_t *p_web_control_data = &(sdk_shm_get()->web_control_info);

    if(sci_is_ready() != true)
    {
        return -1;
    }

	memset(g_sci_task.txbuf, 0, SCI_BUF_SIZE);
    g_sci_task.txbuf[len++] = p_web_control_data->ems_data.discharge_soc_min;
    g_sci_task.txbuf[len++] = p_web_control_data->ems_data.end_charge_soc_max;

	course_flag_set();			// 交互开始
	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_SET_SYS_RUN_PARAM, len, g_sci_task.txbuf);
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_SET_SYS_RUN_PARAM);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__, ret);
			break;
		}
		else
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__, ret);
		}
		usleep(1000 * 100);

	}
	if(ret > 0)
	{
		// 无数据处理
		if(1 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
		{
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] set_ems_data Set ok!!!\n"),__func__, __LINE__);
		}
		else if(0 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
		{
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] set_ems_data Set fail!\n"),__func__, __LINE__);	
		}
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束
    //设置结束之后去读取更新共享内存
    get_sys_run_param();
	return ret;
}



/**
 * @brief  下发CSU SN
 * @param  [in]  none
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
int32_t set_csu_sn(void)
{
	uint8_t i = 0;
	int16_t ret = -1;
	uint8_t len = 0;

    web_control_info_t *p_web_control_data = &(sdk_shm_get()->web_control_info);

    if(sci_is_ready() != true)
    {
        return -1;
    }

    course_flag_set();
    //先使能工厂模式写入
	memset(g_sci_task.txbuf, 0, SCI_BUF_SIZE);
    BIT_SET(g_sci_task.txbuf[1], 3);
    len = 2;
	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_SET_FT_CAP_TEST_MODE, len, g_sci_task.txbuf);
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_SET_FT_CAP_TEST_MODE);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__, ret);
			break;
		}
		else
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__, ret);
		}
		usleep(1000 * 100);
	}
    
    //写入SN
    if(ret)
    {
        memset(g_sci_task.txbuf, 0, SCI_BUF_SIZE);
        memcpy(&g_sci_task.txbuf[22], p_web_control_data->csu_sn, sizeof(p_web_control_data->csu_sn));
        len = 44;
        for(i = 0; i < CMD_RETRYCNT_MAX; i++)
        {
            pthread_mutex_lock(&sofar_sci_mutex);
            ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_SET_SN, len, g_sci_task.txbuf);
            if(ret == 0)
            {
                ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_SET_SN);
            }
            pthread_mutex_unlock(&sofar_sci_mutex);
            if(ret > 0)
            {	
                SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__, ret);
                break;
            }
            else
            {
                SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__, ret);
            }
            usleep(1000 * 100);

        }
        if(ret > 0)
        {
            // 无数据处理
            if(1 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
            {
                SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] set_ems_data Set ok!!!\n"),__func__, __LINE__);
            }
            else if(0 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
            {
                SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] set_ems_data Set fail!\n"),__func__, __LINE__);	
            }
            // 清异常通讯计数
            sci_error_handle(g_sci_task.devaddr, 0, 0);
        }        
    }
    course_flag_clear();
    //读取SN
    if(ret)
    {
        sci_handshake_course();
    }

	return ret;
}


/**
 * @brief  读取光伏电表配置
 * @param  [in] none
 * @param  [out] none
 * @return 0:成功  -1:失败
 */
static int32_t photovoltaic_meter_cfg_get(void)
{
	uint16_t i;
	int16_t ret = -1;
    char *pbuf = NULL;
	// SCI打包接口数据段不能填空，定义临时变量
	uint8_t tmp_buf[1] = {0};
    constant_parameter_data_t *p_constant_para = sdk_shm_constant_parameter_data_get();

    if(sci_is_ready() != true)
    {
        return -1;
    }
	course_flag_set();			// 交互开始

	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_GET_PHOTOVOLTAIC_METER_CFG, 0, tmp_buf);
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_GET_PHOTOVOLTAIC_METER_CFG);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__,ret);
			break;
		}
		else
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__,ret);
		}
		usleep(1000 * 100);
	}
	if(ret > 0)
	{
        pbuf = (char *)&g_sci_task.rxbuf[0];
        p_constant_para->photovoltaic_meter_cfg.meter_cnt        = htons(*(uint16_t *)&pbuf[INDEX_DATA_SLAVE]);
        p_constant_para->photovoltaic_meter_cfg.curr_dir        = pbuf[INDEX_DATA_SLAVE + 2];
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束

    return 0;
}



/**
 * @brief  下发配置光伏电表参数
 * @param  [in]  none
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
int32_t photovoltaic_meter_cfg_set(void)
{
	uint8_t i = 0;
	int16_t ret = -1;
	uint8_t len = 0;
    web_control_info_t *p_web_contol_data = shm_web_control_info_get();
    
    if(sci_is_ready() != true)
    {
        return -1;
    }
	memset(g_sci_task.txbuf, 0, SCI_BUF_SIZE);

	g_sci_task.txbuf[len++] = p_web_contol_data->photovoltaic_meter_cfg.meter_cnt >> 8;
	g_sci_task.txbuf[len++] = p_web_contol_data->photovoltaic_meter_cfg.meter_cnt & 0xff;
    g_sci_task.txbuf[len++] = p_web_contol_data->photovoltaic_meter_cfg.curr_dir;

	course_flag_set();			// 交互开始
	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_SET_PHOTOVOLTAIC_METER_CFG, len, g_sci_task.txbuf);
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_SET_PHOTOVOLTAIC_METER_CFG);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__, ret);
			break;
		}
		else
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__, ret);
		}
		usleep(1000 * 100);

	}
	if(ret > 0)
	{
		// 无数据处理
		if(1 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
		{
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] photovoltaic_meter_cfg_set Set ok!!!\n"),__func__, __LINE__);
            ret = 0;
		}
		else if(0 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
		{
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] photovoltaic_meter_cfg_set Set fail!\n"),__func__, __LINE__);	
            ret = -1;
		}
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束
    //设置完成之后直接读取，更新共享内存
    photovoltaic_meter_cfg_get();
	return ret;
}


/**
* @brief 读取电表配置参数
* @param
* @return		void
*/
static void get_elec_meter_config_param(void)
{
	uint16_t i;
	int16_t ret = -1;
    char *pbuf = NULL;
	// SCI打包接口数据段不能填空，定义临时变量
	uint8_t tmp_buf[1] = {0};
    constant_parameter_data_t *p_constant_para = NULL;

    p_constant_para = sdk_shm_constant_parameter_data_get();
    if(sci_is_ready() != true)
    {
        return;
    }
    // 交互开始
	course_flag_set();			

	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_GET_ELEC_METER_PARAM, 0, tmp_buf);
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_GET_ELEC_METER_PARAM);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__,ret);
			break;
		}
		else
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__,ret);
		}
		usleep(1000 * 100);
	}
	if(ret > 0)
	{
		// 解析更新变压器容量
        pbuf = (char *)&g_sci_task.rxbuf[0];
        p_constant_para->elec_meter_param.control_mode = htonl(*(uint32_t *)&pbuf[INDEX_DATA_SLAVE]);
        p_constant_para->elec_meter_param.transformer_capa = htonl(*(uint32_t *)&pbuf[INDEX_DATA_SLAVE + 4]);
        p_constant_para->elec_meter_param.elec_meter1_cnt = htonl(*(uint32_t *)&pbuf[INDEX_DATA_SLAVE + 8]);
        p_constant_para->elec_meter_param.elec_meter3_cnt = htonl(*(uint32_t *)&pbuf[INDEX_DATA_SLAVE + 12]);

		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束
}


/**
 * @brief  下发电表设置参数
 * @param  [in]  none
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
int32_t set_elec_meter_config_param(void)
{
	uint8_t i = 0;
	int16_t ret = -1;
    uint32_t value = 0;
	uint8_t len = 0;

    web_control_info_t *p_web_control_data = &(sdk_shm_get()->web_control_info);

    if(sci_is_ready() != true)
    {
        return -1;
    }

	memset(g_sci_task.txbuf, 0, SCI_BUF_SIZE);
    value = htonl(p_web_control_data->elec_meter_param.control_mode);
    memcpy(&g_sci_task.txbuf[len], &value, 4);
    len += 4;
    value = htonl(p_web_control_data->elec_meter_param.transformer_capa);
    memcpy(&g_sci_task.txbuf[len], &value, 4);
    len += 4;
    value = htonl(p_web_control_data->elec_meter_param.elec_meter1_cnt);
    memcpy(&g_sci_task.txbuf[len], &value, 4);
    len += 4;
    value = htonl(p_web_control_data->elec_meter_param.elec_meter3_cnt);
    memcpy(&g_sci_task.txbuf[len], &value, 4);
    len += 4;

	course_flag_set();			// 交互开始
	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_SET_ELEC_METER_PARAM, len, g_sci_task.txbuf);
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_SET_ELEC_METER_PARAM);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__, ret);
			break;
		}
		else
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__, ret);
		}
		usleep(1000 * 100);

	}
	if(ret > 0)
	{
		// 无数据处理
		if(1 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
		{
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] set_ems_data Set ok!!!\n"),__func__, __LINE__);
		}
		else if(0 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
		{
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] set_ems_data Set fail!\n"),__func__, __LINE__);	
		}
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束
    //设置结束之后去读取更新共享内存
    get_elec_meter_config_param();
	return ret;
}


/**
* @brief		获取容测模式
* @return		void
*/
static void get_ft_cap_test_mode(void)
{
	uint16_t i;
	int16_t ret = -1;
    char *pbuf = NULL;
	// SCI打包接口数据段不能填空，定义临时变量
	uint8_t tmp_buf[1] = {0};
	constant_parameter_data_t *p_constant_para = sdk_shm_constant_parameter_data_get();

    if(sci_is_ready() != true)
    {
        return;
    }
	course_flag_set();			// 交互开始

	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		// 获取EMS参数
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_GET_FT_CAP_TEST_MODE, 0, tmp_buf);
        // 获取应答结果
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_GET_FT_CAP_TEST_MODE);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__,ret);
			break;
		}
		else
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__,ret);
		}
		usleep(1000 * 100);
	}
	if(ret > 0)
	{
        pbuf = (char *)&g_sci_task.rxbuf[0];
		p_constant_para->ft_cap_test = htons(*(uint16_t *)&pbuf[INDEX_DATA_SLAVE]);
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束
}


/**
 * @brief  设置容测模式
 * @param  [in]  none
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
void set_ft_cap_test_mode(uint16_t mode)
{
	uint8_t i = 0;
	int16_t ret = -1;

    if(sci_is_ready() != true)
    {
        return;
    }
	memset(g_sci_task.txbuf, 0, SCI_BUF_SIZE);
	course_flag_set();			// 交互开始
	g_sci_task.txbuf[0] = mode >> 8;
	g_sci_task.txbuf[1] = mode & 0xff;
	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_SET_FT_CAP_TEST_MODE, 2, g_sci_task.txbuf);
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_SET_FT_CAP_TEST_MODE);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__, ret);
			break;
		}
		else
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__, ret);
		}
		usleep(1000 * 100);

	}
	if(ret > 0)
	{
		// 无数据处理
		if(1 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
		{
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d]Set ok!!!\n"),__func__, __LINE__);
		}
		else if(0 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
		{
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d]Set fail!\n"),__func__, __LINE__);	
		}
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束
	get_ft_cap_test_mode();

	return;
}


/**
 * @brief  设置MCU2主从机常量
 * @param  [in]  none
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
void set_master_slave_const(void)
{
	uint8_t i = 0;
	int16_t ret = -1;
	int32_t data_len = 0;
	uint8_t role_err = 0;

	if(g_sci_master_slave_data.comb_setting.comb_role != csu_role_get())
	{
		role_err = 1;
		g_sci_master_slave_data.comb_setting.comb_role = csu_role_get();
	}
	if(role_err)
	{
		if(sci_is_ready() != true)
		{
			return;
		}
		memset(g_sci_task.txbuf, 0, SCI_BUF_SIZE);
		course_flag_set();			// 交互开始
		data_len = sci_onpack_master_slave_const(&g_sci_task.txbuf[0]);
		for(i = 0; i < CMD_RETRYCNT_MAX; i++)
		{
			pthread_mutex_lock(&sofar_sci_mutex);
			ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_SET_MASTER_SLAVE_CONST, data_len, g_sci_task.txbuf);
			if(ret == 0)
			{
				ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_SET_MASTER_SLAVE_CONST);
			}
			pthread_mutex_unlock(&sofar_sci_mutex);
			if(ret > 0)
			{	
				SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__, ret);
				break;
			}
			else
			{
				SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__, ret);
			}
			usleep(1000 * 100);

		}
		if(ret > 0)
		{
			// 无数据处理
			if(1 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
			{
				SCI_DEBUG_LOG((int8_t *)("\n [%s:%d]Set ok!!!\n"),__func__, __LINE__);
			}
			else if(0 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
			{
				SCI_DEBUG_LOG((int8_t *)("\n [%s:%d]Set fail!\n"),__func__, __LINE__);	
			}
			// 清异常通讯计数
			sci_error_handle(g_sci_task.devaddr, 0, 0);
		}
		course_flag_clear();			// 交互结束
	}

	return;
}

/**
 * @brief  设置MCU2主从机变量
 * @param  [in]  none
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
void set_master_slave_var(void)
{
	uint8_t i = 0;
	int16_t ret = -1;
	int32_t data_len = 0;
    static uint8_t wait_cnt = 0;
	uint8_t updata_flag = 0;

    if(CSU_ROLE_SLAVE == csu_role_get())
    {
        return;
    }

    if(wait_cnt++ > SCI_SET_MASTER_SLAVE_UPDATE)
    {
        updata_flag = 1;
    } 
    if(sci_is_ready() != true)
    {
        return;
    }
	memset(g_sci_task.txbuf, 0, SCI_BUF_SIZE);
	if((updata_flag) || (true == master_slave_var_check()))
	{
		course_flag_set();			// 交互开始
		data_len = sci_onpack_master_slave_var(&g_sci_task.txbuf[0]);
		SCI_DEBUG_LOG((int8_t *)"set_master_slave_var data_len:%d\r\n",data_len);
		for(i = 0; i < CMD_RETRYCNT_MAX; i++)
		{
			pthread_mutex_lock(&sofar_sci_mutex);
			ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_SET_MASTER_SLAVE_VAR, data_len, g_sci_task.txbuf);
			if(ret == 0)
			{
				ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_SET_MASTER_SLAVE_VAR);
			}
			pthread_mutex_unlock(&sofar_sci_mutex);
			if(ret > 0)
			{	
				SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__, ret);
				break;
			}
			else
			{
				SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__, ret);
			}
			usleep(1000 * 100);

		}
		if(ret > 0)
		{
			// 无数据处理
			if(1 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
			{
				SCI_DEBUG_LOG((int8_t *)("\n [%s:%d]Set ok!!!\n"),__func__, __LINE__);
			}
			else if(0 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
			{
				SCI_DEBUG_LOG((int8_t *)("\n [%s:%d]Set fail!\n"),__func__, __LINE__);	
			}
			// 清异常通讯计数
			sci_error_handle(g_sci_task.devaddr, 0, 0);
		}
		course_flag_clear();			// 交互结束
		wait_cnt = 0;
	}
	return;
}


/**
* @brief		获取主从机参数
* @return		void
*/
static void sci_get_master_slave_parm()
{
	uint16_t i;
	int16_t ret = -1;
	// SCI打包接口数据段不能填空，定义临时变量
	uint8_t tmp_buf[1] = {0};
	uint8_t updata_flag = 0;
    static uint8_t wait_cnt = 0;
	uint16_t delay_cnt = 0;

    if(CSU_ROLE_SLAVE == csu_role_get())
    {
        delay_cnt = SCI_GET_MASTER_SLAVE_UPDATE;
    }
	else
	{
        updata_flag = 1;
	}
    if(wait_cnt++ > delay_cnt)
    {
        updata_flag = 1;
    }

    if(sci_is_ready() != true)
    {
        return;
    }
	if((updata_flag) || (master_slave_power_check()))
	{
		SCI_DEBUG_LOG((int8_t *)"updata_flag : %d\r\n", updata_flag);
		course_flag_set();			// 交互开始
		for(i = 0; i < CMD_RETRYCNT_MAX; i++)
		{
			pthread_mutex_lock(&sofar_sci_mutex);
			ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_GET_MASTER_SLAVE_VAR, 0, tmp_buf);
			if(ret == 0)
			{
				ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_GET_MASTER_SLAVE_VAR);
			}
			pthread_mutex_unlock(&sofar_sci_mutex);
			if(ret > 0)
			{	
				SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__,ret);
				break;
			}
			else
			{
				SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__,ret);
			}
			usleep(1000 * 100);
		}
		if(ret > 0)
		{
			// 解析EMS信息
			sci_onparse_master_slave_parm(&g_sci_task.rxbuf[INDEX_DATA_SLAVE]);	
			// 清异常通讯计数
			sci_error_handle(g_sci_task.devaddr, 0, 0);
		}
		course_flag_clear();			// 交互结束
		wait_cnt = 0;
	}

}


void copy_elec_meter_data_to_shm(uint8_t *p_data)
{
	internal_shared_data_t *p_internal_data = NULL;
    p_internal_data = internal_shared_data_get();
	//根据点表进行精度的转换
	p_internal_data->total_realtime_energy.meter_data.active_power_a = (int32_t)(htonl(*(int32_t *)&p_data[1]))/100;
	p_internal_data->total_realtime_energy.meter_data.active_power_b = (int32_t)(htonl(*(int32_t *)&p_data[5]))/100;
	p_internal_data->total_realtime_energy.meter_data.active_power_c = (int32_t)(htonl(*(int32_t *)&p_data[9]))/100;
	p_internal_data->total_realtime_energy.meter_data.reactive_power_a = (int32_t)(htonl(*(int32_t *)&p_data[17]))/100;
	p_internal_data->total_realtime_energy.meter_data.reactive_power_b = (int32_t)(htonl(*(int32_t *)&p_data[21]))/100;
	p_internal_data->total_realtime_energy.meter_data.reactive_power_c = (int32_t)(htonl(*(int32_t *)&p_data[25]))/100;
	p_internal_data->total_realtime_energy.meter_data.view_power_a = (int32_t)(htonl(*(int32_t *)&p_data[33]))/100;
	p_internal_data->total_realtime_energy.meter_data.view_power_b = (int32_t)(htonl(*(int32_t *)&p_data[37]))/100;
	p_internal_data->total_realtime_energy.meter_data.view_power_c = (int32_t)(htonl(*(int32_t *)&p_data[41]))/100;
	p_internal_data->total_realtime_energy.meter_data.view_power_total = (int32_t)(htonl(*(int32_t *)&p_data[45]))/100;
	p_internal_data->total_realtime_energy.meter_data.power_factor_a = (int16_t)(htons(*(int16_t *)&p_data[49]))/10;
	p_internal_data->total_realtime_energy.meter_data.power_factor_b = (int16_t)(htons(*(int16_t *)&p_data[51]))/10;
	p_internal_data->total_realtime_energy.meter_data.power_factor_c = (int16_t)(htons(*(int16_t *)&p_data[53]))/10;
	p_internal_data->total_realtime_energy.meter_data.power_factor_total = (int16_t)(htons(*(int16_t *)&p_data[55]))/10;
	p_internal_data->total_realtime_energy.meter_data.positive_reactive_energy_total = (uint32_t)(htonl(*(uint32_t *)&p_data[97]))/10;
	p_internal_data->total_realtime_energy.meter_data.positive_reactive_energy_sharp = (uint32_t)(htonl(*(uint32_t *)&p_data[101]))/10;
	p_internal_data->total_realtime_energy.meter_data.positive_reactive_energy_peak = (uint32_t)(htonl(*(uint32_t *)&p_data[105]))/10;
	p_internal_data->total_realtime_energy.meter_data.positive_reactive_energy_flat = (uint32_t)(htonl(*(uint32_t *)&p_data[109]))/10;
	p_internal_data->total_realtime_energy.meter_data.positive_reactive_energy_valley = (uint32_t)(htonl(*(uint32_t *)&p_data[113]))/10;
	p_internal_data->total_realtime_energy.meter_data.negative_reactive_energy_total = (uint32_t)(htonl(*(uint32_t *)&p_data[117]))/10;
	p_internal_data->total_realtime_energy.meter_data.negative_reactive_energy_sharp = (uint32_t)(htonl(*(uint32_t *)&p_data[121]))/10;
	p_internal_data->total_realtime_energy.meter_data.negative_reactive_energy_peak = (uint32_t)(htonl(*(uint32_t *)&p_data[125]))/10;
	p_internal_data->total_realtime_energy.meter_data.negative_reactive_energy_flat = (uint32_t)(htonl(*(uint32_t *)&p_data[129]))/10;
	p_internal_data->total_realtime_energy.meter_data.negative_reactive_energy_valley = (uint32_t)(htonl(*(uint32_t *)&p_data[133]))/10;
	p_internal_data->total_realtime_energy.meter_data.volt_a = (uint32_t)htonl(*(uint32_t *)&p_data[137]);
	p_internal_data->total_realtime_energy.meter_data.volt_b = (uint32_t)htonl(*(uint32_t *)&p_data[141]);
	p_internal_data->total_realtime_energy.meter_data.volt_c = (uint32_t)htonl(*(uint32_t *)&p_data[145]);
	p_internal_data->total_realtime_energy.meter_data.current_a = (uint32_t)(htonl(*(uint32_t *)&p_data[149]))/10;
	p_internal_data->total_realtime_energy.meter_data.current_b = (uint32_t)(htonl(*(uint32_t *)&p_data[153]))/10;
	p_internal_data->total_realtime_energy.meter_data.current_c = (uint32_t)(htonl(*(uint32_t *)&p_data[157]))/10;
	p_internal_data->total_realtime_energy.meter_data.active_power_total = (int32_t)(htonl(*(int32_t *)&p_data[13]))/100;
	p_internal_data->total_realtime_energy.meter_data.reactive_power_total = (int32_t)(htonl(*(int32_t *)&p_data[29]))/100;
	p_internal_data->total_realtime_energy.meter_data.positive_active_energy_total = (uint32_t)(htonl(*(uint32_t *)&p_data[57]))/10;
	p_internal_data->total_realtime_energy.meter_data.positive_active_energy_sharp = (uint32_t)(htonl(*(uint32_t *)&p_data[61]))/10;
	p_internal_data->total_realtime_energy.meter_data.positive_active_energy_peak = (uint32_t)(htonl(*(uint32_t *)&p_data[65]))/10;
	p_internal_data->total_realtime_energy.meter_data.positive_active_energy_flat = (uint32_t)(htonl(*(uint32_t *)&p_data[69]))/10;
	p_internal_data->total_realtime_energy.meter_data.positive_active_energy_valley = (uint32_t)(htonl(*(uint32_t *)&p_data[73]))/10;
	p_internal_data->total_realtime_energy.meter_data.negative_active_energy_total = (uint32_t)(htonl(*(uint32_t *)&p_data[77]))/10;
	p_internal_data->total_realtime_energy.meter_data.negative_active_energy_sharp = (uint32_t)(htonl(*(uint32_t *)&p_data[81]))/10;
	p_internal_data->total_realtime_energy.meter_data.negative_active_energy_peak = (uint32_t)(htonl(*(uint32_t *)&p_data[85]))/10;
	p_internal_data->total_realtime_energy.meter_data.negative_active_energy_flat = (uint32_t)(htonl(*(uint32_t *)&p_data[89]))/10;
	p_internal_data->total_realtime_energy.meter_data.negative_active_energy_valley = (uint32_t)(htonl(*(uint32_t *)&p_data[93]))/10;
	p_internal_data->total_realtime_energy.meter_data.freq = (uint32_t)htonl(*(uint32_t *)&p_data[161]);
	
	
}

/**
* @brief		计量表数据解析
* @return		void
*/
static void sci_onparse_elec_data_parm(uint8_t *p_data)
{
	energy_cabinet_meter_data_t *p_energy_meter_data = NULL;
    internal_shared_data_t *p_internal_data = NULL;
    constant_parameter_data_t *p_const_data = NULL;
    uint32_t energy_charge = 0;
    uint32_t energy_discharge = 0;
    uint8_t meter_idnex = 0;

    p_const_data = sdk_shm_constant_parameter_data_get();
    p_internal_data = internal_shared_data_get();
	p_energy_meter_data = &sdk_shm_get()->mqtt_data.energy_meter_data;
	if(p_energy_meter_data == NULL)
	{
		SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] energy data is NULL\n",__func__, __LINE__);
		return;
	}

	// 提取参数并同步至共享内存
    //第一个字节为计量表索引检验值
    meter_idnex = p_data[0];
    if(meter_idnex == 0xFF)
    {
        SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] meter param error\n",__func__, __LINE__);
        return;
    }
	p_energy_meter_data->active_power_a = 			htonl(*(int32_t *)&p_data[1]);
    p_energy_meter_data->active_power_a =           abs(p_energy_meter_data->active_power_a);
	p_energy_meter_data->active_power_b = 			htonl(*(int32_t *)&p_data[5]);
    p_energy_meter_data->active_power_b =           abs(p_energy_meter_data->active_power_b);
	p_energy_meter_data->active_power_c = 			htonl(*(int32_t *)&p_data[9]);
    p_energy_meter_data->active_power_c =           abs(p_energy_meter_data->active_power_c);
	p_energy_meter_data->active_power_total = 		htonl(*(int32_t *)&p_data[13]);
    p_energy_meter_data->active_power_total =       abs(p_energy_meter_data->active_power_total);
	p_energy_meter_data->reactive_power_a = 		htonl(*(int32_t *)&p_data[17]);
    p_energy_meter_data->reactive_power_a =         abs(p_energy_meter_data->reactive_power_a);
	p_energy_meter_data->reactive_power_b = 		htonl(*(int32_t *)&p_data[21]);
    p_energy_meter_data->reactive_power_b =         abs(p_energy_meter_data->reactive_power_b);
	p_energy_meter_data->reactive_power_c = 		htonl(*(int32_t *)&p_data[25]);
    p_energy_meter_data->reactive_power_c =         abs(p_energy_meter_data->reactive_power_c);
	p_energy_meter_data->reactive_power_total =		htonl(*(int32_t *)&p_data[29]);
    p_energy_meter_data->reactive_power_total =     abs(p_energy_meter_data->reactive_power_total);
	p_energy_meter_data->view_power_a = 			htonl(*(int32_t *)&p_data[33]);
    p_energy_meter_data->view_power_a =             abs(p_energy_meter_data->view_power_a);
	p_energy_meter_data->view_power_b = 			htonl(*(int32_t *)&p_data[37]);
    p_energy_meter_data->view_power_b =             abs(p_energy_meter_data->view_power_b);
	p_energy_meter_data->view_power_c = 			htonl(*(int32_t *)&p_data[41]);
    p_energy_meter_data->view_power_c =             abs(p_energy_meter_data->view_power_c);
	p_energy_meter_data->view_power_total =			htonl(*(int32_t *)&p_data[45]);
    p_energy_meter_data->view_power_total =         abs(p_energy_meter_data->view_power_total);
	p_energy_meter_data->power_factor_a = 			htons(*(int16_t *)&p_data[49]);
    p_energy_meter_data->power_factor_a =           abs(p_energy_meter_data->power_factor_a) + 1000;
	p_energy_meter_data->power_factor_b = 			htons(*(int16_t *)&p_data[51]);
    p_energy_meter_data->power_factor_b =           abs(p_energy_meter_data->power_factor_b) + 1000;
	p_energy_meter_data->power_factor_c = 			htons(*(int16_t *)&p_data[53]);
    p_energy_meter_data->power_factor_c =           abs(p_energy_meter_data->power_factor_c) + 1000;
	p_energy_meter_data->power_factor_total =		htons(*(int16_t *)&p_data[55]);
    p_energy_meter_data->power_factor_total =           abs(p_energy_meter_data->power_factor_total) + 1000;
    //根据电流方向确认正反向数据
    if(BIT_GET(p_const_data->ems_data.meter_curr_dir, 0))
    {
        energy_discharge = htonl(*(uint32_t *)&p_data[57]);
        if(energy_discharge)
        {
            p_energy_meter_data->negative_active_energy_total = htonl(*(uint32_t *)&p_data[57]);
        }
        p_energy_meter_data->negative_active_energy_sharp = htonl(*(uint32_t *)&p_data[61]);
        p_energy_meter_data->negative_active_energy_peak = 	htonl(*(uint32_t *)&p_data[65]);
        p_energy_meter_data->negative_active_energy_flat = 	htonl(*(uint32_t *)&p_data[69]);
        p_energy_meter_data->negative_active_energy_valley = 	htonl(*(uint32_t *)&p_data[73]);

        energy_charge = htonl(*(uint32_t *)&p_data[77]);
        if(energy_charge)
        {
            p_energy_meter_data->positive_active_energy_total = htonl(*(uint32_t *)&p_data[77]);
        }
        p_energy_meter_data->positive_active_energy_sharp = htonl(*(uint32_t *)&p_data[81]);
        p_energy_meter_data->positive_active_energy_peak = 	htonl(*(uint32_t *)&p_data[85]);
        p_energy_meter_data->positive_active_energy_flat = 	htonl(*(uint32_t *)&p_data[89]);
        p_energy_meter_data->positive_active_energy_valley = 	htonl(*(uint32_t *)&p_data[93]);

        p_energy_meter_data->negative_reactive_energy_total = 	htonl(*(uint32_t *)&p_data[97]);
        p_energy_meter_data->negative_reactive_energy_sharp = 	htonl(*(uint32_t *)&p_data[101]);
        p_energy_meter_data->negative_reactive_energy_peak = 	htonl(*(uint32_t *)&p_data[105]);
        p_energy_meter_data->negative_reactive_energy_flat = 	htonl(*(uint32_t *)&p_data[109]);
        p_energy_meter_data->negative_reactive_energy_valley = 	htonl(*(uint32_t *)&p_data[113]);

        p_energy_meter_data->positive_reactive_energy_total = 	htonl(*(uint32_t *)&p_data[117]);
        p_energy_meter_data->positive_reactive_energy_sharp = 	htonl(*(uint32_t *)&p_data[121]);
        p_energy_meter_data->positive_reactive_energy_peak = 	htonl(*(uint32_t *)&p_data[125]);
        p_energy_meter_data->positive_reactive_energy_flat = 	htonl(*(uint32_t *)&p_data[129]);
        p_energy_meter_data->positive_reactive_energy_valley = 	htonl(*(uint32_t *)&p_data[133]);    
    }
    else
    {
        energy_discharge = htonl(*(uint32_t *)&p_data[57]);
        if(energy_discharge)
        {
            p_energy_meter_data->positive_active_energy_total = htonl(*(uint32_t *)&p_data[57]);
        }
        p_energy_meter_data->positive_active_energy_sharp = htonl(*(uint32_t *)&p_data[61]);
        p_energy_meter_data->positive_active_energy_peak = 	htonl(*(uint32_t *)&p_data[65]);
        p_energy_meter_data->positive_active_energy_flat = 	htonl(*(uint32_t *)&p_data[69]);
        p_energy_meter_data->positive_active_energy_valley = 	htonl(*(uint32_t *)&p_data[73]);

        energy_charge = htonl(*(uint32_t *)&p_data[77]);
        if(energy_charge)
        {
            p_energy_meter_data->negative_active_energy_total = htonl(*(uint32_t *)&p_data[77]);
        }
        p_energy_meter_data->negative_active_energy_sharp = htonl(*(uint32_t *)&p_data[81]);
        p_energy_meter_data->negative_active_energy_peak = 	htonl(*(uint32_t *)&p_data[85]);
        p_energy_meter_data->negative_active_energy_flat = 	htonl(*(uint32_t *)&p_data[89]);
        p_energy_meter_data->negative_active_energy_valley = 	htonl(*(uint32_t *)&p_data[93]);
        
        p_energy_meter_data->positive_reactive_energy_total = 	htonl(*(uint32_t *)&p_data[97]);
        p_energy_meter_data->positive_reactive_energy_sharp = 	htonl(*(uint32_t *)&p_data[101]);
        p_energy_meter_data->positive_reactive_energy_peak = 	htonl(*(uint32_t *)&p_data[105]);
        p_energy_meter_data->positive_reactive_energy_flat = 	htonl(*(uint32_t *)&p_data[109]);
        p_energy_meter_data->positive_reactive_energy_valley = 	htonl(*(uint32_t *)&p_data[113]);
        
        p_energy_meter_data->negative_reactive_energy_total = 	htonl(*(uint32_t *)&p_data[117]);
        p_energy_meter_data->negative_reactive_energy_sharp = 	htonl(*(uint32_t *)&p_data[121]);
        p_energy_meter_data->negative_reactive_energy_peak = 	htonl(*(uint32_t *)&p_data[125]);
        p_energy_meter_data->negative_reactive_energy_flat = 	htonl(*(uint32_t *)&p_data[129]);
        p_energy_meter_data->negative_reactive_energy_valley = 	htonl(*(uint32_t *)&p_data[133]);
    }

	p_energy_meter_data->volt_a = 	htonl(*(uint32_t *)&p_data[137]);
	p_energy_meter_data->volt_b = 	htonl(*(uint32_t *)&p_data[141]);
	p_energy_meter_data->volt_c = 	htonl(*(uint32_t *)&p_data[145]);
	p_energy_meter_data->current_a = 	htonl(*(uint32_t *)&p_data[149]);
	p_energy_meter_data->current_b = 	htonl(*(uint32_t *)&p_data[153]);
	p_energy_meter_data->current_c = 	htonl(*(uint32_t *)&p_data[157]);
	p_energy_meter_data->freq = 		htonl(*(uint32_t *)&p_data[161]);

	//拷贝电表数据
	copy_elec_meter_data_to_shm(p_data);

    //更新至共享数据区，用于计算充放电、功率曲线数据
    p_internal_data->total_realtime_energy.meter_power = htonl(*(int32_t *)&p_data[13]);
    p_internal_data->total_realtime_energy.meter_energy_charge = p_energy_meter_data->negative_active_energy_total;
    p_internal_data->total_realtime_energy.meter_energy_discharge = p_energy_meter_data->positive_active_energy_total;
    p_internal_data->total_realtime_energy.positive_active_energy_total = p_energy_meter_data->positive_active_energy_total;
    p_internal_data->total_realtime_energy.positive_active_energy_sharp = p_energy_meter_data->positive_active_energy_sharp;
    p_internal_data->total_realtime_energy.positive_active_energy_peak = p_energy_meter_data->positive_active_energy_peak;
    p_internal_data->total_realtime_energy.positive_active_energy_flat = p_energy_meter_data->positive_active_energy_flat;
    p_internal_data->total_realtime_energy.positive_active_energy_valley = p_energy_meter_data->positive_active_energy_valley;
    p_internal_data->total_realtime_energy.negative_active_energy_total = p_energy_meter_data->negative_active_energy_total;
    p_internal_data->total_realtime_energy.negative_active_energy_sharp = p_energy_meter_data->negative_active_energy_sharp;
    p_internal_data->total_realtime_energy.negative_active_energy_peak = p_energy_meter_data->negative_active_energy_peak;
    p_internal_data->total_realtime_energy.negative_active_energy_flat = p_energy_meter_data->negative_active_energy_flat;
    p_internal_data->total_realtime_energy.negative_active_energy_valley = p_energy_meter_data->negative_active_energy_valley;
}

/**
* @brief		读取计量表1数据
* @return		void
*/
static void sci_get_elec_meter1_data()
{
	uint16_t i;
	int16_t ret = -1;
	// SCI打包接口数据段不能填空，定义临时变量
	uint8_t tmp_buf[1] = {0};
    static uint8_t wait_cnt = 0;
 
    if(wait_cnt++ < SCI_ELEC_METER_DATA)
    {
        return;
    }

    if(sci_is_ready() != true)
    {
        return;
    }
	course_flag_set();			// 交互开始

	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		// 获取计量表参数
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_GET_ELEC_METER_DATA, 1, tmp_buf);
        // 获取应答结果
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_GET_ELEC_METER_DATA);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__,ret);
			break;
		}
		else
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__,ret);
		}
		usleep(1000 * 100);
	}
	if(ret > 0)
	{
		// 解析计量表数据并更新至共享内存
		sci_onparse_elec_data_parm(&g_sci_task.rxbuf[INDEX_DATA_SLAVE]);	
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束
    wait_cnt = 0;
}


/**
* @brief		计量表2数据解析
* @return		void
*/
static void sci_onparse_elec_meter2_data_parm(uint8_t *p_data)
{
	municipal_meter_data_t *p_energy_meter2_data = NULL;
    constant_parameter_data_t *p_const_data = NULL;
    uint8_t meter_idnex = 0;
    
    p_const_data = sdk_shm_constant_parameter_data_get();
	p_energy_meter2_data = &sdk_shm_get()->mqtt_data.energy_meter2_data;
	if(p_energy_meter2_data == NULL)
	{
		SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] energy data is NULL\n",__func__, __LINE__);
		return;
	}

	// 提取参数并同步至共享内存
    //第一个字节为计量表索引检验值
    meter_idnex = p_data[0];
    if(meter_idnex == 0xFF)
    {
        SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] meter param error\n",__func__, __LINE__);
        return;
    }
	p_energy_meter2_data->active_power_a = 			htonl(*(int32_t *)&p_data[1]);
    p_energy_meter2_data->active_power_a =          abs(p_energy_meter2_data->active_power_a);
	p_energy_meter2_data->active_power_b = 			htonl(*(int32_t *)&p_data[5]);
    p_energy_meter2_data->active_power_b =          abs(p_energy_meter2_data->active_power_b);
	p_energy_meter2_data->active_power_c = 			htonl(*(int32_t *)&p_data[9]);
    p_energy_meter2_data->active_power_c =          abs(p_energy_meter2_data->active_power_c);
	p_energy_meter2_data->active_power_total = 		htonl(*(int32_t *)&p_data[13]);
    p_energy_meter2_data->active_power_total =      abs(p_energy_meter2_data->active_power_total);
	p_energy_meter2_data->reactive_power_a = 		htonl(*(int32_t *)&p_data[17]);
    p_energy_meter2_data->reactive_power_a =        abs(p_energy_meter2_data->reactive_power_a);
	p_energy_meter2_data->reactive_power_b = 		htonl(*(int32_t *)&p_data[21]);
    p_energy_meter2_data->reactive_power_b =        abs(p_energy_meter2_data->reactive_power_b);
	p_energy_meter2_data->reactive_power_c = 		htonl(*(int32_t *)&p_data[25]);
    p_energy_meter2_data->reactive_power_c =        abs(p_energy_meter2_data->reactive_power_c);
	p_energy_meter2_data->reactive_power_total =	htonl(*(int32_t *)&p_data[29]);
    p_energy_meter2_data->reactive_power_total =    abs(p_energy_meter2_data->reactive_power_total);
	p_energy_meter2_data->view_power_a = 			htonl(*(int32_t *)&p_data[33]);
    p_energy_meter2_data->view_power_a =            abs(p_energy_meter2_data->view_power_a);
	p_energy_meter2_data->view_power_b = 			htonl(*(int32_t *)&p_data[37]);
    p_energy_meter2_data->view_power_b =            abs(p_energy_meter2_data->view_power_b);
	p_energy_meter2_data->view_power_c = 			htonl(*(int32_t *)&p_data[41]);
    p_energy_meter2_data->view_power_c =            abs(p_energy_meter2_data->view_power_c);
	p_energy_meter2_data->view_power_total =		htonl(*(int32_t *)&p_data[45]);
    p_energy_meter2_data->view_power_total =        abs(p_energy_meter2_data->view_power_total);
	p_energy_meter2_data->power_factor_a = 			htons(*(int16_t *)&p_data[49]);
    p_energy_meter2_data->power_factor_a =           abs(p_energy_meter2_data->power_factor_a) + 1000;
	p_energy_meter2_data->power_factor_b = 			htons(*(int16_t *)&p_data[51]);
    p_energy_meter2_data->power_factor_b =          abs(p_energy_meter2_data->power_factor_b) + 1000;
	p_energy_meter2_data->power_factor_c = 			htons(*(int16_t *)&p_data[53]);
    p_energy_meter2_data->power_factor_c =          abs(p_energy_meter2_data->power_factor_c) + 1000;
	p_energy_meter2_data->power_factor_total =		htons(*(int16_t *)&p_data[55]);
    p_energy_meter2_data->power_factor_total =      abs(p_energy_meter2_data->power_factor_total) + 1000;
    //根据电流方向确认正反向数据
    if(BIT_GET(p_const_data->ems_data.meter_curr_dir, 1))
    {
        p_energy_meter2_data->negative_active_energy_total =    htonl(*(uint32_t *)&p_data[57]);
        p_energy_meter2_data->negative_active_energy_sharp =    htonl(*(uint32_t *)&p_data[61]);
        p_energy_meter2_data->negative_active_energy_peak = 	htonl(*(uint32_t *)&p_data[65]);
        p_energy_meter2_data->negative_active_energy_flat = 	htonl(*(uint32_t *)&p_data[69]);
        p_energy_meter2_data->negative_active_energy_valley = 	htonl(*(uint32_t *)&p_data[73]);

        p_energy_meter2_data->positive_active_energy_total = 	htonl(*(uint32_t *)&p_data[77]);
        p_energy_meter2_data->positive_active_energy_sharp =    htonl(*(uint32_t *)&p_data[81]);
        p_energy_meter2_data->positive_active_energy_peak = 	htonl(*(uint32_t *)&p_data[85]);
        p_energy_meter2_data->positive_active_energy_flat = 	htonl(*(uint32_t *)&p_data[89]);
        p_energy_meter2_data->positive_active_energy_valley = 	htonl(*(uint32_t *)&p_data[93]);

        p_energy_meter2_data->negative_reactive_energy_total = 	htonl(*(uint32_t *)&p_data[97]);
        p_energy_meter2_data->negative_reactive_energy_sharp = 	htonl(*(uint32_t *)&p_data[101]);
        p_energy_meter2_data->negative_reactive_energy_peak = 	htonl(*(uint32_t *)&p_data[105]);
        p_energy_meter2_data->negative_reactive_energy_flat = 	htonl(*(uint32_t *)&p_data[109]);
        p_energy_meter2_data->negative_reactive_energy_valley = htonl(*(uint32_t *)&p_data[113]);
        
        p_energy_meter2_data->positive_reactive_energy_total = 	htonl(*(uint32_t *)&p_data[117]);
        p_energy_meter2_data->positive_reactive_energy_sharp = 	htonl(*(uint32_t *)&p_data[121]);
        p_energy_meter2_data->positive_reactive_energy_peak = 	htonl(*(uint32_t *)&p_data[125]);
        p_energy_meter2_data->positive_reactive_energy_flat = 	htonl(*(uint32_t *)&p_data[129]);
        p_energy_meter2_data->positive_reactive_energy_valley = htonl(*(uint32_t *)&p_data[133]);
    }
    else
    {
        p_energy_meter2_data->positive_active_energy_total =    htonl(*(uint32_t *)&p_data[57]);
        p_energy_meter2_data->positive_active_energy_sharp =    htonl(*(uint32_t *)&p_data[61]);
        p_energy_meter2_data->positive_active_energy_peak = 	htonl(*(uint32_t *)&p_data[65]);
        p_energy_meter2_data->positive_active_energy_flat = 	htonl(*(uint32_t *)&p_data[69]);
        p_energy_meter2_data->positive_active_energy_valley = 	htonl(*(uint32_t *)&p_data[73]);

        p_energy_meter2_data->negative_active_energy_total = 	htonl(*(uint32_t *)&p_data[77]);
        p_energy_meter2_data->negative_active_energy_sharp =    htonl(*(uint32_t *)&p_data[81]);
        p_energy_meter2_data->negative_active_energy_peak = 	htonl(*(uint32_t *)&p_data[85]);
        p_energy_meter2_data->negative_active_energy_flat = 	htonl(*(uint32_t *)&p_data[89]);
        p_energy_meter2_data->negative_active_energy_valley = 	htonl(*(uint32_t *)&p_data[93]);

        p_energy_meter2_data->positive_reactive_energy_total = 	htonl(*(uint32_t *)&p_data[97]);
        p_energy_meter2_data->positive_reactive_energy_sharp = 	htonl(*(uint32_t *)&p_data[101]);
        p_energy_meter2_data->positive_reactive_energy_peak = 	htonl(*(uint32_t *)&p_data[105]);
        p_energy_meter2_data->positive_reactive_energy_flat = 	htonl(*(uint32_t *)&p_data[109]);
        p_energy_meter2_data->positive_reactive_energy_valley = htonl(*(uint32_t *)&p_data[113]);

        p_energy_meter2_data->negative_reactive_energy_total = 	htonl(*(uint32_t *)&p_data[117]);
        p_energy_meter2_data->negative_reactive_energy_sharp = 	htonl(*(uint32_t *)&p_data[121]);
        p_energy_meter2_data->negative_reactive_energy_peak = 	htonl(*(uint32_t *)&p_data[125]);
        p_energy_meter2_data->negative_reactive_energy_flat = 	htonl(*(uint32_t *)&p_data[129]);
        p_energy_meter2_data->negative_reactive_energy_valley = htonl(*(uint32_t *)&p_data[133]);
    }

	p_energy_meter2_data->volt_a = 	    htonl(*(uint32_t *)&p_data[137]);
	p_energy_meter2_data->volt_b = 	    htonl(*(uint32_t *)&p_data[141]);
	p_energy_meter2_data->volt_c = 	    htonl(*(uint32_t *)&p_data[145]);
	p_energy_meter2_data->current_a = 	htonl(*(uint32_t *)&p_data[149]);
	p_energy_meter2_data->current_b = 	htonl(*(uint32_t *)&p_data[153]);
	p_energy_meter2_data->current_c = 	htonl(*(uint32_t *)&p_data[157]);
	p_energy_meter2_data->freq = 		htonl(*(uint32_t *)&p_data[161]);
}


/**
* @brief		读取计量表2数据
* @return		void
*/
static void sci_get_elec_meter2_data(void)
{
	uint16_t i;
	int16_t ret = -1;
	// SCI打包接口数据段不能填空，定义临时变量
    uint8_t meter_code = 1;
	uint8_t tmp_buf[1] = {0};
    static uint8_t wait_cnt = 0;
 
    if(wait_cnt++ < SCI_ELEC_METER_DATA)
    {
        return;
    }

    if(sci_is_ready() != true)
    {
        return;
    }
	course_flag_set();			// 交互开始
    tmp_buf[0] |=  (meter_code << 6);
	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		// 获取计量表参数
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_GET_ELEC_METER_DATA, 1, tmp_buf);
        // 获取应答结果
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_GET_ELEC_METER_DATA);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__,ret);
			break;
		}
		else
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__,ret);
		}
		usleep(1000 * 100);
	}
	if(ret > 0)
	{
		// 解析计量表数据并更新至共享内存
		sci_onparse_elec_meter2_data_parm(&g_sci_task.rxbuf[INDEX_DATA_SLAVE]);	
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束
    wait_cnt = 0;
}


/**
* @brief		计量表3数据解析
* @return		void
*/
static void sci_onparse_elec_meter3_data_parm(uint8_t *p_data, uint8_t meter_code)
{
	municipal_meter_data_t *p_energy_meter3_data = NULL;
    constant_parameter_data_t *p_const_data = NULL;
    uint8_t meter_idnex = 0;
    
    p_const_data = sdk_shm_constant_parameter_data_get();
	p_energy_meter3_data = &sdk_shm_get()->mqtt_data.energy_meter3_data[meter_code];
	if(p_energy_meter3_data == NULL)
	{
		SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] energy data is NULL\n",__func__, __LINE__);
		return;
	}

	// 提取参数并同步至共享内存
    //第一个字节为计量表索引检验值
    meter_idnex = p_data[0];
    if(meter_idnex == 0xFF)
    {
        SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] meter param error\n",__func__, __LINE__);
        return;
    }
	p_energy_meter3_data->active_power_a = 			htonl(*(int32_t *)&p_data[1]);
    p_energy_meter3_data->active_power_a =          abs(p_energy_meter3_data->active_power_a);
	p_energy_meter3_data->active_power_b = 			htonl(*(int32_t *)&p_data[5]);
    p_energy_meter3_data->active_power_b =          abs(p_energy_meter3_data->active_power_b);
	p_energy_meter3_data->active_power_c = 			htonl(*(int32_t *)&p_data[9]);
    p_energy_meter3_data->active_power_c =          abs(p_energy_meter3_data->active_power_c);
	p_energy_meter3_data->active_power_total = 		htonl(*(int32_t *)&p_data[13]);
    p_energy_meter3_data->active_power_total =      abs(p_energy_meter3_data->active_power_total);
	p_energy_meter3_data->reactive_power_a = 		htonl(*(int32_t *)&p_data[17]);
    p_energy_meter3_data->reactive_power_a =        abs(p_energy_meter3_data->reactive_power_a);
	p_energy_meter3_data->reactive_power_b = 		htonl(*(int32_t *)&p_data[21]);
    p_energy_meter3_data->reactive_power_b =        abs(p_energy_meter3_data->reactive_power_b);
	p_energy_meter3_data->reactive_power_c = 		htonl(*(int32_t *)&p_data[25]);
    p_energy_meter3_data->reactive_power_c =        abs(p_energy_meter3_data->reactive_power_c);
	p_energy_meter3_data->reactive_power_total =	htonl(*(int32_t *)&p_data[29]);
    p_energy_meter3_data->reactive_power_total =    abs(p_energy_meter3_data->reactive_power_total);
	p_energy_meter3_data->view_power_a = 			htonl(*(int32_t *)&p_data[33]);
    p_energy_meter3_data->view_power_a =            abs(p_energy_meter3_data->view_power_a);
	p_energy_meter3_data->view_power_b = 			htonl(*(int32_t *)&p_data[37]);
    p_energy_meter3_data->view_power_b =            abs(p_energy_meter3_data->view_power_b);
	p_energy_meter3_data->view_power_c = 			htonl(*(int32_t *)&p_data[41]);
    p_energy_meter3_data->view_power_c =            abs(p_energy_meter3_data->view_power_c);
	p_energy_meter3_data->view_power_total =		htonl(*(int32_t *)&p_data[45]);
    p_energy_meter3_data->view_power_total =        abs(p_energy_meter3_data->view_power_total);
	p_energy_meter3_data->power_factor_a = 			htons(*(int16_t *)&p_data[49]);
    p_energy_meter3_data->power_factor_a =          abs(p_energy_meter3_data->power_factor_a) + 1000;
	p_energy_meter3_data->power_factor_b = 			htons(*(int16_t *)&p_data[51]);
    p_energy_meter3_data->power_factor_b =          abs(p_energy_meter3_data->power_factor_b) + 1000;
	p_energy_meter3_data->power_factor_c = 			htons(*(int16_t *)&p_data[53]);
    p_energy_meter3_data->power_factor_c =          abs(p_energy_meter3_data->power_factor_c) + 1000;
	p_energy_meter3_data->power_factor_total =		htons(*(int16_t *)&p_data[55]);
    p_energy_meter3_data->power_factor_total =      abs(p_energy_meter3_data->power_factor_total) + 1000;
    //根据电流方向确认正反向数据
    if(BIT_GET(p_const_data->ems_data.meter_curr_dir, 2))
    {
        p_energy_meter3_data->negative_active_energy_total =    htonl(*(uint32_t *)&p_data[57]);
        p_energy_meter3_data->negative_active_energy_sharp =    htonl(*(uint32_t *)&p_data[61]);
        p_energy_meter3_data->negative_active_energy_peak = 	htonl(*(uint32_t *)&p_data[65]);
        p_energy_meter3_data->negative_active_energy_flat = 	htonl(*(uint32_t *)&p_data[69]);
        p_energy_meter3_data->negative_active_energy_valley = 	htonl(*(uint32_t *)&p_data[73]);

        p_energy_meter3_data->positive_active_energy_total = 	htonl(*(uint32_t *)&p_data[77]);
        p_energy_meter3_data->positive_active_energy_sharp =    htonl(*(uint32_t *)&p_data[81]);
        p_energy_meter3_data->positive_active_energy_peak = 	htonl(*(uint32_t *)&p_data[85]);
        p_energy_meter3_data->positive_active_energy_flat = 	htonl(*(uint32_t *)&p_data[89]);
        p_energy_meter3_data->positive_active_energy_valley = 	htonl(*(uint32_t *)&p_data[93]);

        p_energy_meter3_data->negative_reactive_energy_total = 	htonl(*(uint32_t *)&p_data[97]);
        p_energy_meter3_data->negative_reactive_energy_sharp = 	htonl(*(uint32_t *)&p_data[101]);
        p_energy_meter3_data->negative_reactive_energy_peak = 	htonl(*(uint32_t *)&p_data[105]);
        p_energy_meter3_data->negative_reactive_energy_flat = 	htonl(*(uint32_t *)&p_data[109]);
        p_energy_meter3_data->negative_reactive_energy_valley = htonl(*(uint32_t *)&p_data[113]);
        
        p_energy_meter3_data->positive_reactive_energy_total = 	htonl(*(uint32_t *)&p_data[117]);
        p_energy_meter3_data->positive_reactive_energy_sharp = 	htonl(*(uint32_t *)&p_data[121]);
        p_energy_meter3_data->positive_reactive_energy_peak = 	htonl(*(uint32_t *)&p_data[125]);
        p_energy_meter3_data->positive_reactive_energy_flat = 	htonl(*(uint32_t *)&p_data[129]);
        p_energy_meter3_data->positive_reactive_energy_valley = htonl(*(uint32_t *)&p_data[133]);
    }
    else
    {
        p_energy_meter3_data->positive_active_energy_total =    htonl(*(uint32_t *)&p_data[57]);
        p_energy_meter3_data->positive_active_energy_sharp =    htonl(*(uint32_t *)&p_data[61]);
        p_energy_meter3_data->positive_active_energy_peak = 	htonl(*(uint32_t *)&p_data[65]);
        p_energy_meter3_data->positive_active_energy_flat = 	htonl(*(uint32_t *)&p_data[69]);
        p_energy_meter3_data->positive_active_energy_valley = 	htonl(*(uint32_t *)&p_data[73]);

        p_energy_meter3_data->negative_active_energy_total = 	htonl(*(uint32_t *)&p_data[77]);
        p_energy_meter3_data->negative_active_energy_sharp =    htonl(*(uint32_t *)&p_data[81]);
        p_energy_meter3_data->negative_active_energy_peak = 	htonl(*(uint32_t *)&p_data[85]);
        p_energy_meter3_data->negative_active_energy_flat = 	htonl(*(uint32_t *)&p_data[89]);
        p_energy_meter3_data->negative_active_energy_valley = 	htonl(*(uint32_t *)&p_data[93]);

        p_energy_meter3_data->positive_reactive_energy_total = 	htonl(*(uint32_t *)&p_data[97]);
        p_energy_meter3_data->positive_reactive_energy_sharp = 	htonl(*(uint32_t *)&p_data[101]);
        p_energy_meter3_data->positive_reactive_energy_peak = 	htonl(*(uint32_t *)&p_data[105]);
        p_energy_meter3_data->positive_reactive_energy_flat = 	htonl(*(uint32_t *)&p_data[109]);
        p_energy_meter3_data->positive_reactive_energy_valley = htonl(*(uint32_t *)&p_data[113]);

        p_energy_meter3_data->negative_reactive_energy_total = 	htonl(*(uint32_t *)&p_data[117]);
        p_energy_meter3_data->negative_reactive_energy_sharp = 	htonl(*(uint32_t *)&p_data[121]);
        p_energy_meter3_data->negative_reactive_energy_peak = 	htonl(*(uint32_t *)&p_data[125]);
        p_energy_meter3_data->negative_reactive_energy_flat = 	htonl(*(uint32_t *)&p_data[129]);
        p_energy_meter3_data->negative_reactive_energy_valley = htonl(*(uint32_t *)&p_data[133]);
    }

	p_energy_meter3_data->volt_a = 	    htonl(*(uint32_t *)&p_data[137]);
	p_energy_meter3_data->volt_b = 	    htonl(*(uint32_t *)&p_data[141]);
	p_energy_meter3_data->volt_c = 	    htonl(*(uint32_t *)&p_data[145]);
	p_energy_meter3_data->current_a = 	htonl(*(uint32_t *)&p_data[149]);
	p_energy_meter3_data->current_b = 	htonl(*(uint32_t *)&p_data[153]);
	p_energy_meter3_data->current_c = 	htonl(*(uint32_t *)&p_data[157]);
	p_energy_meter3_data->freq = 		htonl(*(uint32_t *)&p_data[161]);
}


/**
* @brief		读取计量表3数据
* @return		void
*/
static void sci_get_elec_meter3_data(void)
{
	uint16_t i;
	int16_t ret = -1;
	// SCI打包接口数据段不能填空，定义临时变量
    uint8_t meter_code = 2;
	uint8_t tmp_buf[1] = {0};
    static uint8_t meter_cnt = 0; 
    static uint8_t wait_cnt = 0;

    constant_parameter_data_t *p_constant_para = sdk_shm_constant_parameter_data_get();

    //不存在电表3则直接返回
    if(!p_constant_para->elec_meter_param.elec_meter3_cnt)
    {
        return;
    }
 
    if(wait_cnt++ < SCI_ELEC_METER3_DATA)
    {
        return;
    }

    if(sci_is_ready() != true)
    {
        return;
    }
	course_flag_set();			// 交互开始
    tmp_buf[0] |=  meter_cnt;
    tmp_buf[0] |=  (meter_code << 6);
	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		// 获取计量表参数
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_GET_ELEC_METER_DATA, 1, tmp_buf);
        // 获取应答结果
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_GET_ELEC_METER_DATA);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__,ret);
			break;
		}
		else
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__,ret);
		}
		usleep(1000 * 100);
	}
	if(ret > 0)
	{
		// 解析计量表数据并更新至共享内存
		sci_onparse_elec_meter3_data_parm(&g_sci_task.rxbuf[INDEX_DATA_SLAVE], meter_cnt);	
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束
    wait_cnt = 0;
    meter_cnt++;
    if(meter_cnt >= p_constant_para->elec_meter_param. elec_meter3_cnt)
    {
        meter_cnt = 0;
    }
}


/**
* @brief		光伏电表数据解析
* @return		void
*/
static void sci_onparse_get_photovoltaic_meter_data_parm(uint8_t *p_data, uint8_t meter_code)
{
	photovoltaic_meter_data_t *p_photovoltaic_meter_data = NULL;
    constant_parameter_data_t *p_const_data = NULL;
    internal_shared_data_t *p_internal_data = NULL;
    uint8_t meter_idnex = 0;

    p_internal_data = internal_shared_data_get();
    p_const_data = sdk_shm_constant_parameter_data_get();
	p_photovoltaic_meter_data = &p_internal_data->photovoltaic_meter_data[meter_code];
	if(p_photovoltaic_meter_data == NULL)
	{
		SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] energy data is NULL\n",__func__, __LINE__);
		return;
	}

	// 提取参数并同步至共享内存
    //第一个字节为计量表索引检验值
    meter_idnex = p_data[0];
    if(meter_idnex == 0xFF)
    {
        SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] meter param error\n",__func__, __LINE__);
        return;
    }
	p_photovoltaic_meter_data->active_power_a = 			htonl(*(int32_t *)&p_data[1]);
	p_photovoltaic_meter_data->active_power_b = 			htonl(*(int32_t *)&p_data[5]);
	p_photovoltaic_meter_data->active_power_c = 			htonl(*(int32_t *)&p_data[9]);
	p_photovoltaic_meter_data->active_power_total = 		htonl(*(int32_t *)&p_data[13]);
	p_photovoltaic_meter_data->reactive_power_a = 		    htonl(*(int32_t *)&p_data[17]);
	p_photovoltaic_meter_data->reactive_power_b = 		    htonl(*(int32_t *)&p_data[21]);
	p_photovoltaic_meter_data->reactive_power_c = 		    htonl(*(int32_t *)&p_data[25]);
	p_photovoltaic_meter_data->reactive_power_total =	    htonl(*(int32_t *)&p_data[29]);
	p_photovoltaic_meter_data->view_power_a = 			    htonl(*(int32_t *)&p_data[33]);
	p_photovoltaic_meter_data->view_power_b = 			    htonl(*(int32_t *)&p_data[37]);
	p_photovoltaic_meter_data->view_power_c = 			    htonl(*(int32_t *)&p_data[41]);
	p_photovoltaic_meter_data->view_power_total =		    htonl(*(int32_t *)&p_data[45]);
	p_photovoltaic_meter_data->power_factor_a = 			htons(*(int16_t *)&p_data[49]);
	p_photovoltaic_meter_data->power_factor_b = 			htons(*(int16_t *)&p_data[51]);
	p_photovoltaic_meter_data->power_factor_c = 			htons(*(int16_t *)&p_data[53]);
	p_photovoltaic_meter_data->power_factor_total =		    htons(*(int16_t *)&p_data[55]);
    //根据电流方向确认正反向数据
    if(BIT_GET(p_const_data->ems_data.meter_curr_dir, 1))
    {
        p_photovoltaic_meter_data->negative_active_energy_total =   htonl(*(uint32_t *)&p_data[57]);
        p_photovoltaic_meter_data->negative_active_energy_sharp =   htonl(*(uint32_t *)&p_data[61]);
        p_photovoltaic_meter_data->negative_active_energy_peak = 	htonl(*(uint32_t *)&p_data[65]);
        p_photovoltaic_meter_data->negative_active_energy_flat = 	htonl(*(uint32_t *)&p_data[69]);
        p_photovoltaic_meter_data->negative_active_energy_valley = 	htonl(*(uint32_t *)&p_data[73]);

        p_photovoltaic_meter_data->positive_active_energy_total = 	htonl(*(uint32_t *)&p_data[77]);
        p_photovoltaic_meter_data->positive_active_energy_sharp =   htonl(*(uint32_t *)&p_data[81]);
        p_photovoltaic_meter_data->positive_active_energy_peak = 	htonl(*(uint32_t *)&p_data[85]);
        p_photovoltaic_meter_data->positive_active_energy_flat = 	htonl(*(uint32_t *)&p_data[89]);
        p_photovoltaic_meter_data->positive_active_energy_valley = 	htonl(*(uint32_t *)&p_data[93]);

        p_photovoltaic_meter_data->negative_reactive_energy_total = htonl(*(uint32_t *)&p_data[97]);
        p_photovoltaic_meter_data->negative_reactive_energy_sharp = htonl(*(uint32_t *)&p_data[101]);
        p_photovoltaic_meter_data->negative_reactive_energy_peak = 	htonl(*(uint32_t *)&p_data[105]);
        p_photovoltaic_meter_data->negative_reactive_energy_flat = 	htonl(*(uint32_t *)&p_data[109]);
        p_photovoltaic_meter_data->negative_reactive_energy_valley = htonl(*(uint32_t *)&p_data[113]);
        
        p_photovoltaic_meter_data->positive_reactive_energy_total = htonl(*(uint32_t *)&p_data[117]);
        p_photovoltaic_meter_data->positive_reactive_energy_sharp = htonl(*(uint32_t *)&p_data[121]);
        p_photovoltaic_meter_data->positive_reactive_energy_peak = 	htonl(*(uint32_t *)&p_data[125]);
        p_photovoltaic_meter_data->positive_reactive_energy_flat = 	htonl(*(uint32_t *)&p_data[129]);
        p_photovoltaic_meter_data->positive_reactive_energy_valley = htonl(*(uint32_t *)&p_data[133]);
    }
    else
    {
        p_photovoltaic_meter_data->positive_active_energy_total =   htonl(*(uint32_t *)&p_data[57]);
        p_photovoltaic_meter_data->positive_active_energy_sharp =   htonl(*(uint32_t *)&p_data[61]);
        p_photovoltaic_meter_data->positive_active_energy_peak = 	htonl(*(uint32_t *)&p_data[65]);
        p_photovoltaic_meter_data->positive_active_energy_flat = 	htonl(*(uint32_t *)&p_data[69]);
        p_photovoltaic_meter_data->positive_active_energy_valley = 	htonl(*(uint32_t *)&p_data[73]);

        p_photovoltaic_meter_data->negative_active_energy_total = 	htonl(*(uint32_t *)&p_data[77]);
        p_photovoltaic_meter_data->negative_active_energy_sharp =   htonl(*(uint32_t *)&p_data[81]);
        p_photovoltaic_meter_data->negative_active_energy_peak = 	htonl(*(uint32_t *)&p_data[85]);
        p_photovoltaic_meter_data->negative_active_energy_flat = 	htonl(*(uint32_t *)&p_data[89]);
        p_photovoltaic_meter_data->negative_active_energy_valley = 	htonl(*(uint32_t *)&p_data[93]);

        p_photovoltaic_meter_data->positive_reactive_energy_total = htonl(*(uint32_t *)&p_data[97]);
        p_photovoltaic_meter_data->positive_reactive_energy_sharp = htonl(*(uint32_t *)&p_data[101]);
        p_photovoltaic_meter_data->positive_reactive_energy_peak = 	htonl(*(uint32_t *)&p_data[105]);
        p_photovoltaic_meter_data->positive_reactive_energy_flat = 	htonl(*(uint32_t *)&p_data[109]);
        p_photovoltaic_meter_data->positive_reactive_energy_valley = htonl(*(uint32_t *)&p_data[113]);

        p_photovoltaic_meter_data->negative_reactive_energy_total = htonl(*(uint32_t *)&p_data[117]);
        p_photovoltaic_meter_data->negative_reactive_energy_sharp = htonl(*(uint32_t *)&p_data[121]);
        p_photovoltaic_meter_data->negative_reactive_energy_peak = 	htonl(*(uint32_t *)&p_data[125]);
        p_photovoltaic_meter_data->negative_reactive_energy_flat = 	htonl(*(uint32_t *)&p_data[129]);
        p_photovoltaic_meter_data->negative_reactive_energy_valley = htonl(*(uint32_t *)&p_data[133]);
    }

	p_photovoltaic_meter_data->volt_a = 	    htonl(*(uint32_t *)&p_data[137]);
	p_photovoltaic_meter_data->volt_b = 	    htonl(*(uint32_t *)&p_data[141]);
	p_photovoltaic_meter_data->volt_c = 	    htonl(*(uint32_t *)&p_data[145]);
	p_photovoltaic_meter_data->current_a = 	    htonl(*(uint32_t *)&p_data[149]);
	p_photovoltaic_meter_data->current_b = 	    htonl(*(uint32_t *)&p_data[153]);
	p_photovoltaic_meter_data->current_c = 	    htonl(*(uint32_t *)&p_data[157]);
	p_photovoltaic_meter_data->freq = 		    htonl(*(uint32_t *)&p_data[161]);

}




/**
* @brief		读取光伏电表数据
* @return		void
*/
static void sci_get_photovoltaic_meter_data(void)
{
	uint16_t i;
	int16_t ret = -1;
	// SCI打包接口数据段不能填空，定义临时变量
	uint8_t tmp_buf[1] = {0};
    static uint8_t meter_cnt = 0; 
    static uint8_t wait_cnt = 0;

    constant_parameter_data_t *p_constant_para = sdk_shm_constant_parameter_data_get();
 
    if(wait_cnt++ < SCI_PHOTOVOLTAIC_METER_DATA)
    {
        return;
    }

    if(sci_is_ready() != true)
    {
        return;
    }
	course_flag_set();			// 交互开始
    tmp_buf[0] = meter_cnt;
	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		// 获取计量表参数
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_GET_PHOTOVOLTAIC_METER_DATA, 1, tmp_buf);
        // 获取应答结果
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_GET_PHOTOVOLTAIC_METER_DATA);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__,ret);
			break;
		}
		else
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__,ret);
		}
		usleep(1000 * 100);
	}
	if(ret > 0)
	{
		// 解析计量表数据并更新至共享内存
		sci_onparse_get_photovoltaic_meter_data_parm(&g_sci_task.rxbuf[INDEX_DATA_SLAVE], meter_cnt);	
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束
    wait_cnt = 0;
    meter_cnt++;
    if(meter_cnt >= p_constant_para->photovoltaic_meter_cfg.meter_cnt)
    {
        meter_cnt = 0;
    }
}


/**
* @brief		PCC电表数据解析
* @return		void
*/
static void sci_onparse_pcc_meter_data_parm(uint8_t *p_data)
{
	photovoltaic_meter_data_t *p_pcc_meter_data = NULL;
    constant_parameter_data_t *p_const_data = NULL;
    internal_shared_data_t *p_internal_data = NULL;
    uint8_t meter_idnex = 0;

    p_internal_data = internal_shared_data_get();
    p_const_data = sdk_shm_constant_parameter_data_get();
	p_pcc_meter_data = &p_internal_data->pcc_meter_data;
	if(p_pcc_meter_data == NULL)
	{
		SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] energy data is NULL\n",__func__, __LINE__);
		return;
	}

	// 提取参数并同步至共享内存
    //第一个字节为计量表索引检验值
    meter_idnex = p_data[0];
    if(meter_idnex == 0xFF)
    {
        SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] meter param error\n",__func__, __LINE__);
        return;
    }
	p_pcc_meter_data->active_power_a = 			htonl(*(int32_t *)&p_data[1]);
	p_pcc_meter_data->active_power_b = 			htonl(*(int32_t *)&p_data[5]);
	p_pcc_meter_data->active_power_c = 			htonl(*(int32_t *)&p_data[9]);
	p_pcc_meter_data->active_power_total = 		htonl(*(int32_t *)&p_data[13]);
	p_pcc_meter_data->reactive_power_a = 		    htonl(*(int32_t *)&p_data[17]);
	p_pcc_meter_data->reactive_power_b = 		    htonl(*(int32_t *)&p_data[21]);
	p_pcc_meter_data->reactive_power_c = 		    htonl(*(int32_t *)&p_data[25]);
	p_pcc_meter_data->reactive_power_total =	    htonl(*(int32_t *)&p_data[29]);
	p_pcc_meter_data->view_power_a = 			    htonl(*(int32_t *)&p_data[33]);
	p_pcc_meter_data->view_power_b = 			    htonl(*(int32_t *)&p_data[37]);
	p_pcc_meter_data->view_power_c = 			    htonl(*(int32_t *)&p_data[41]);
	p_pcc_meter_data->view_power_total =		    htonl(*(int32_t *)&p_data[45]);
	p_pcc_meter_data->power_factor_a = 			htons(*(int16_t *)&p_data[49]);
	p_pcc_meter_data->power_factor_b = 			htons(*(int16_t *)&p_data[51]);
	p_pcc_meter_data->power_factor_c = 			htons(*(int16_t *)&p_data[53]);
	p_pcc_meter_data->power_factor_total =		    htons(*(int16_t *)&p_data[55]);
    //根据电流方向确认正反向数据
    if(BIT_GET(p_const_data->ems_data.meter_curr_dir, 3))
    {
        p_pcc_meter_data->negative_active_energy_total =   htonl(*(uint32_t *)&p_data[57]);
        p_pcc_meter_data->negative_active_energy_sharp =   htonl(*(uint32_t *)&p_data[61]);
        p_pcc_meter_data->negative_active_energy_peak = 	htonl(*(uint32_t *)&p_data[65]);
        p_pcc_meter_data->negative_active_energy_flat = 	htonl(*(uint32_t *)&p_data[69]);
        p_pcc_meter_data->negative_active_energy_valley = 	htonl(*(uint32_t *)&p_data[73]);

        p_pcc_meter_data->positive_active_energy_total = 	htonl(*(uint32_t *)&p_data[77]);
        p_pcc_meter_data->positive_active_energy_sharp =   htonl(*(uint32_t *)&p_data[81]);
        p_pcc_meter_data->positive_active_energy_peak = 	htonl(*(uint32_t *)&p_data[85]);
        p_pcc_meter_data->positive_active_energy_flat = 	htonl(*(uint32_t *)&p_data[89]);
        p_pcc_meter_data->positive_active_energy_valley = 	htonl(*(uint32_t *)&p_data[93]);

        p_pcc_meter_data->negative_reactive_energy_total = htonl(*(uint32_t *)&p_data[97]);
        p_pcc_meter_data->negative_reactive_energy_sharp = htonl(*(uint32_t *)&p_data[101]);
        p_pcc_meter_data->negative_reactive_energy_peak = 	htonl(*(uint32_t *)&p_data[105]);
        p_pcc_meter_data->negative_reactive_energy_flat = 	htonl(*(uint32_t *)&p_data[109]);
        p_pcc_meter_data->negative_reactive_energy_valley = htonl(*(uint32_t *)&p_data[113]);
        
        p_pcc_meter_data->positive_reactive_energy_total = htonl(*(uint32_t *)&p_data[117]);
        p_pcc_meter_data->positive_reactive_energy_sharp = htonl(*(uint32_t *)&p_data[121]);
        p_pcc_meter_data->positive_reactive_energy_peak = 	htonl(*(uint32_t *)&p_data[125]);
        p_pcc_meter_data->positive_reactive_energy_flat = 	htonl(*(uint32_t *)&p_data[129]);
        p_pcc_meter_data->positive_reactive_energy_valley = htonl(*(uint32_t *)&p_data[133]);
    }
    else
    {
        p_pcc_meter_data->positive_active_energy_total =   htonl(*(uint32_t *)&p_data[57]);
        p_pcc_meter_data->positive_active_energy_sharp =   htonl(*(uint32_t *)&p_data[61]);
        p_pcc_meter_data->positive_active_energy_peak = 	htonl(*(uint32_t *)&p_data[65]);
        p_pcc_meter_data->positive_active_energy_flat = 	htonl(*(uint32_t *)&p_data[69]);
        p_pcc_meter_data->positive_active_energy_valley = 	htonl(*(uint32_t *)&p_data[73]);

        p_pcc_meter_data->negative_active_energy_total = 	htonl(*(uint32_t *)&p_data[77]);
        p_pcc_meter_data->negative_active_energy_sharp =   htonl(*(uint32_t *)&p_data[81]);
        p_pcc_meter_data->negative_active_energy_peak = 	htonl(*(uint32_t *)&p_data[85]);
        p_pcc_meter_data->negative_active_energy_flat = 	htonl(*(uint32_t *)&p_data[89]);
        p_pcc_meter_data->negative_active_energy_valley = 	htonl(*(uint32_t *)&p_data[93]);

        p_pcc_meter_data->positive_reactive_energy_total = htonl(*(uint32_t *)&p_data[97]);
        p_pcc_meter_data->positive_reactive_energy_sharp = htonl(*(uint32_t *)&p_data[101]);
        p_pcc_meter_data->positive_reactive_energy_peak = 	htonl(*(uint32_t *)&p_data[105]);
        p_pcc_meter_data->positive_reactive_energy_flat = 	htonl(*(uint32_t *)&p_data[109]);
        p_pcc_meter_data->positive_reactive_energy_valley = htonl(*(uint32_t *)&p_data[113]);

        p_pcc_meter_data->negative_reactive_energy_total = htonl(*(uint32_t *)&p_data[117]);
        p_pcc_meter_data->negative_reactive_energy_sharp = htonl(*(uint32_t *)&p_data[121]);
        p_pcc_meter_data->negative_reactive_energy_peak = 	htonl(*(uint32_t *)&p_data[125]);
        p_pcc_meter_data->negative_reactive_energy_flat = 	htonl(*(uint32_t *)&p_data[129]);
        p_pcc_meter_data->negative_reactive_energy_valley = htonl(*(uint32_t *)&p_data[133]);
    }

	p_pcc_meter_data->volt_a = 	    htonl(*(uint32_t *)&p_data[137]);
	p_pcc_meter_data->volt_b = 	    htonl(*(uint32_t *)&p_data[141]);
	p_pcc_meter_data->volt_c = 	    htonl(*(uint32_t *)&p_data[145]);
	p_pcc_meter_data->current_a = 	    htonl(*(uint32_t *)&p_data[149]);
	p_pcc_meter_data->current_b = 	    htonl(*(uint32_t *)&p_data[153]);
	p_pcc_meter_data->current_c = 	    htonl(*(uint32_t *)&p_data[157]);
	p_pcc_meter_data->freq = 		    htonl(*(uint32_t *)&p_data[161]);
}


/**
* @brief		读取PCC电表数据
* @return		void
*/
static void sci_get_pcc_meter_data(void)
{
	uint16_t i;
	int16_t ret = -1;
	// SCI打包接口数据段不能填空，定义临时变量
    uint8_t meter_code = 3;
	uint8_t tmp_buf[1] = {0};
    static uint8_t wait_cnt = 0;
 
    if(wait_cnt++ < SCI_ELEC_METER_DATA)
    {
        return;
    }

    if(sci_is_ready() != true)
    {
        return;
    }
	course_flag_set();			// 交互开始
    tmp_buf[0] |=  (meter_code << 6);
	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		// 获取计量表参数
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_GET_ELEC_METER_DATA, 1, tmp_buf);
        // 获取应答结果
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_GET_ELEC_METER_DATA);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__,ret);
			break;
		}
		else
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__,ret);
		}
		usleep(1000 * 100);
	}
	if(ret > 0)
	{
		// 解析计量表数据并更新至共享内存
		sci_onparse_pcc_meter_data_parm(&g_sci_task.rxbuf[INDEX_DATA_SLAVE]);	
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束
    wait_cnt = 0;
}



/**
 * @brief  下发EMS节能降耗通知信息
 * @param  [in]  none
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
void set_mcu2_notice_info(void)
{
	uint8_t i = 0;
	int16_t ret = -1;
	uint8_t len = 6;

	constant_parameter_data_t *p_constant_para = sdk_shm_constant_parameter_data_get();
	web_control_info_t *p_web_data = shm_web_control_info_get();

    if(sci_is_ready() != true)
    {
        return;
    }

	memset(g_sci_task.txbuf, 0, SCI_BUF_SIZE);

	for(uint8_t i = 0; i < 6; i++)
	{
		if(BIT_GET(p_web_data->mcu2_notice, i))
		{
			p_constant_para->mcu2_notice[i] = 0;
			BIT_CLR(p_web_data->mcu2_notice, i);
		}
	}
	memcpy(g_sci_task.txbuf, p_constant_para->mcu2_notice, 6);
	course_flag_set();			// 交互开始

	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_SET_NOTICE_INFO, len, g_sci_task.txbuf);
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_SET_NOTICE_INFO);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__, ret);
			break;
		}
		else
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__, ret);
		}
		usleep(1000 * 100);
	}
	if(ret > 0)
	{
		// 无数据处理
		if(1 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
		{
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] set_mcu2_notice_info Set ok!!!\n"),__func__, __LINE__);
		}
		else if(0 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
		{
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] set_mcu2_notice_info Set fail!\n"),__func__, __LINE__);	
		}
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束
	return;

}


/**
* @brief		获取MCU2通知信息
* @return		void
*/
static void sci_get_mcu2_notice_info(void)
{
	uint16_t i;
	int16_t ret = -1;
	// SCI打包接口数据段不能填空，定义临时变量
	uint8_t tmp_buf[1] = {0};
	common_data_t *shm = sdk_shm_get();
	csu_combine_info_t *p_csu_combine = sdk_shm_csu_combine_data_get();
    static uint8_t wait_cnt = 0;
	if((true == p_csu_combine->comb_setting.comb_enable) && (CSU_ROLE_SLAVE == p_csu_combine->comb_setting.comb_role))
	{
		return;
	}
    if(wait_cnt++ < SCI_INFO_NOTICE)
    {
        return;
    }

    if(sci_is_ready() != true)
    {
        return;
    }
	course_flag_set();			// 交互开始
	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		// 获取MCU2通知信息
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_GET_NOTICE_INFO, 0, tmp_buf);
        // 获取应答结果
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_GET_NOTICE_INFO);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__,ret);
			break;
		}
		else
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__,ret);
		}
		usleep(1000 * 100);
	}
	if(ret > 0)
	{
		// 更新通知至共享内存
		for(uint8_t i = 0; i < sizeof(shm->constant_parameter_data.mcu2_notice); i++)
		{
			shm->constant_parameter_data.mcu2_notice[i] = g_sci_task.rxbuf[INDEX_DATA_SLAVE + i];
		}
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束
    wait_cnt = 0;
}


/**
 * @brief  风扇控制任务，间隔5s
 */
void fan_ctrl(void)
{
    int16_t ac_fuse_temp = 0;
    telemetry_data_t *p_telemetry = NULL;
	static uint8_t state_flag = false;
    static uint8_t wait_cnt = 0;
	constant_parameter_data_t * p_param = sdk_shm_constant_parameter_data_get();
	web_control_info_t *p_web_data = shm_web_control_info_get();
	system_param_t temp = {0};
	memcpy(&temp,&p_param->system_param,sizeof(system_param_t));
 
    if(wait_cnt++ < SCI_FAN_CTRL)
    {
        return;
    } 

    p_telemetry = sdk_shm_telemetry_data_get();
    ac_fuse_temp = p_telemetry->sys_cabinet_telemetry_info.at_temperature;
	if((false == state_flag) && ((BIT_GET(p_web_data->control_cmd_flag, 7)) || (ac_fuse_temp > 450))) // 45度
    {
		state_flag = true;
        set_gpio(DO8_INDEX,true);
		BIT_SET(temp.remote_control_cmd, 5);
		set_constant_data( FUNCID_SET_REMOTE_CTRL , (uint16_t*)&temp.remote_control_cmd, 1 );
    }
    else if((true == state_flag) && (ac_fuse_temp < 400) && (!BIT_GET(p_web_data->control_cmd_flag, 7))) // 40度
    {
		state_flag = false;
        set_gpio(DO8_INDEX,false);
		BIT_CLR(temp.remote_control_cmd, 5);
		set_constant_data( FUNCID_SET_REMOTE_CTRL , (uint16_t*)&temp.remote_control_cmd, 1 );
    }
    wait_cnt = 0;
}

int32_t get_drm_voltage(char *drmn_path)
{
    FILE *fp = NULL;
	char buffer[8]={0};
	char buffer2[8]={0};
    int32_t adc_value=0;
    int32_t voltage=0;
	char cmd[128];
	
	snprintf(cmd, sizeof(cmd), "cat %s", drmn_path);
    fp=popen(cmd,"r");
    fgets(buffer, sizeof(buffer), fp);
    pclose(fp);
    if(memcmp(buffer, buffer2, sizeof(buffer))==0)
	{
		SCI_DEBUG_LOG((int8_t *)"erro: this drms adc device is no exit !!!\n");
		return -1;
	}
	if (0 == strlen(buffer))
	{
		return 1625; // 0.95V 当读取不到数值时，默认返回视作悬空的采样值
	}

    adc_value = atoi(buffer);
    voltage = adc_value*4096/3360;  //电压（mv）
    // voltage = adc_value*3000/4096;  //电压（mv）
    return voltage;
}

int32_t drmn_read(uint16_t *drmn_value)
{
	char *drmn_path[4]={DRM1, DRM2, DRM3, DRM4};
	uint8_t drm_num = sizeof(drmn_path) / sizeof(drmn_path[0]);
	uint8_t i;
	int32_t drm_vol;
	if(NULL == drmn_value)
	{
		return -1;
	}
	
	for(i=0; i<drm_num; i++)
	{
		drm_vol = get_drm_voltage(drmn_path[i]);
		if(drm_vol >= 1000) {BIT_CLR(*drmn_value,i); BIT_CLR(*drmn_value,i + drm_num);}
		else if(drm_vol >= 200) {BIT_CLR(*drmn_value,i); BIT_SET(*drmn_value,i + drm_num);}
		else {BIT_SET(*drmn_value,i); BIT_CLR(*drmn_value,i + drm_num);}
		SCI_DEBUG_LOG((int8_t *)"index : %d, drm_vol : %d\r\n", i, drm_vol);
	}
	return 0;
}

/**
* @brief		获取DRMn
* @return		void
*/
static void sci_get_drmn(void)
{
	uint16_t i;
	int16_t ret = -1;
	// SCI打包接口数据段不能填空，定义临时变量
	uint8_t tmp_buf[1] = {0};
	internal_shared_data_t *internal_shared_data = internal_shared_data_get();

    if ( internal_shared_data->drmn_power_enable != 1 )
    {
        return;
    }

    if(sci_is_ready() != true)
    {
        return;
    }
	course_flag_set();			// 交互开始
	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		// 获取MCU2通知信息
		ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_GET_DRMN, 0, tmp_buf);
        // 获取应答结果
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_GET_DRMN);
		}
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{	
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__,ret);
			break;
		}
		else
		{
			SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__,ret);
		}
		usleep(1000 * 100);
	}
	if(ret > 0)
	{
		// 更新通知至共享内存
		internal_shared_data->drmn_status = (g_sci_task.rxbuf[INDEX_DATA_SLAVE] << 8) | (g_sci_task.rxbuf[INDEX_DATA_SLAVE + 1]);
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束
}
/**
 * @brief  drm功能
 */
void drmn_power_ctrl(void)
{
	static uint16_t last_drmn = 0;
	uint16_t now_drmn = 0;
	internal_shared_data_t *internal_shared_data = internal_shared_data_get();

    if ( internal_shared_data->drmn_power_enable != 1 )
    {
        return;
    }

	drmn_read(&now_drmn);
	if(last_drmn != now_drmn)
	{
		last_drmn = now_drmn;
		return;
	}
	if(now_drmn != internal_shared_data->drmn_status)
	{
		set_constant_data(FUNCID_SET_DRMN,(uint16_t*)&now_drmn, 1);
		sci_get_drmn();
	}
	return;
}

/**
 * @brief  打包电池充放电参数
 * @param  [in]  none
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
static int32_t bat_charge_data_pack(uint8_t *p_data)
{
	uint8_t offet = 0;
	uint8_t i, j;
	bat_charge_data_t *bat_charge_data = sdk_shm_bat_charge_data_info_get();
	csu_combine_info_t *p_csu_combine = sdk_shm_csu_combine_data_get();
	internal_shared_data_t *p_internal_shared_data = internal_shared_data_get();
	if(bat_charge_data == NULL)
	{
		return -1;
	}
	if((CSU_ROLE_MASTER == csu_role_get()))
	{
		for(i = 0; i < 6; i++)
		{
			for(j = 0; j < 6; j++)
			{
				if( 0 == i)
				{
					p_data[offet++] = bat_charge_data[i].soc_soh_data[j].soc >> 8;
					p_data[offet++] = bat_charge_data[i].soc_soh_data[j].soc & 0xff;
				}
				else if((p_csu_combine->slave_info[i - 1].online) && (0 == j))
				{
					p_data[offet++] = p_csu_combine->slave_info[i - 1].real_data.SOC >> 8;
					p_data[offet++] = p_csu_combine->slave_info[i - 1].real_data.SOC & 0xff;
				}
				else
				{
					p_data[offet++] = 0xFF;
					p_data[offet++] = 0xFF;
				}
			}
		}
		for(i = 0; i < 6; i++)
		{
			for(j = 0; j < 6; j++)
			{
				if(0 == i)
				{
					p_data[offet++] = bat_charge_data[i].soc_soh_data[j].soh >> 8;
					p_data[offet++] = bat_charge_data[i].soc_soh_data[j].soh & 0xff;
				}
				else if((p_csu_combine->slave_info[i - 1].online ) && (0 == j ))
				{
					p_data[offet++] = p_csu_combine->slave_info[i - 1].real_data.SOH >> 8;
					p_data[offet++] = p_csu_combine->slave_info[i - 1].real_data.SOH & 0xff;
				}
				else
				{
					p_data[offet++] = 0xFF;
					p_data[offet++] = 0xFF;
				}
			}
		}

		for(i = 0; i < 6; i++)
		{
			if(0 == i)
			{
				p_data[offet++] = bat_charge_data[i].charge_limit_power >> 8;
				p_data[offet++] = bat_charge_data[i].charge_limit_power & 0xff;
				p_data[offet++] = bat_charge_data[i].discharge_limit_power >> 8;
				p_data[offet++] = bat_charge_data[i].discharge_limit_power & 0xff;
			}
			else
			{
				p_data[offet++] = p_csu_combine->slave_info[i -1].real_data.bat_charge_max_power >> 8;
				p_data[offet++] = p_csu_combine->slave_info[i -1].real_data.bat_charge_max_power & 0xff;
				p_data[offet++] = p_csu_combine->slave_info[i -1].real_data.bat_discharge_max_power >> 8;
				p_data[offet++] = p_csu_combine->slave_info[i -1].real_data.bat_discharge_max_power & 0xff;
			}
		}

		for(i = 0; i < 6; i++)
		{
			p_data[offet++] = 0;
			p_data[offet++] = 0;
			p_data[offet++] = 0;
			p_data[offet++] = 0;
		}

		offet++;
		for(i = 0; i < 6; i++)
		{
			if(0 == i)
			{
				if(bat_charge_data[i].charge_prohibit)
				{
					BIT_SET(p_data[offet], i);
				}
			}
			else if((!p_csu_combine->slave_info[i-1].online) || (p_csu_combine->slave_info[i-1].real_data.charge_prohibit))
			{
				BIT_SET(p_data[offet], i);
			}
			else{}
		}
		offet += 2;
		for(i = 0; i < 6; i++)
		{
			if(0 == i)
			{
				if(bat_charge_data[i].discharge_prohibit)
				{
					BIT_SET(p_data[offet], i);
				}
			}
			else if((!p_csu_combine->slave_info[i-1].online) || (p_csu_combine->slave_info[i-1].real_data.discharge_prohibit))
			{
				BIT_SET(p_data[offet], i);
			}
			else{}
		}
		offet++;
		for(i = 0; i < 6; i++)
		{
			if(0 == i)
			{
				p_data[offet++] = p_internal_shared_data->cmu_sys_status[i];
				g_sci_cmu_sys_status[i] = p_internal_shared_data->cmu_sys_status[i];
			}
			else
			{
				if(p_csu_combine->slave_info[i - 1].online)
				{
					p_data[offet++] = p_csu_combine->slave_info[i - 1].real_data.sys_status;
					g_sci_cmu_sys_status[i] = p_csu_combine->slave_info[i - 1].real_data.sys_status;
				}
				else
				{
					p_data[offet++] = 0xFF;
					g_sci_cmu_sys_status[i] = 0xFF;
				}
			}
		}
	}
	else
	{
		memcpy(&g_sci_bat_charge_data[0], &bat_charge_data[0], sizeof(g_sci_bat_charge_data));
		for(i = 0; i < 6; i++)
		{
			for(j = 0; j < 6; j++)
			{
				p_data[offet++] = bat_charge_data[i].soc_soh_data[j].soc >> 8;
				p_data[offet++] = bat_charge_data[i].soc_soh_data[j].soc & 0xff;
			}
		}

		for(i = 0; i < 6; i++)
		{
			for(j = 0; j < 6; j++)
			{
				p_data[offet++] = bat_charge_data[i].soc_soh_data[j].soh >> 8;
				p_data[offet++] = bat_charge_data[i].soc_soh_data[j].soh & 0xff;
			}
		}

		for(i = 0; i < 6; i++)
		{
			p_data[offet++] = bat_charge_data[i].charge_limit_power >> 8;
			p_data[offet++] = bat_charge_data[i].charge_limit_power & 0xff;
			p_data[offet++] = bat_charge_data[i].discharge_limit_power >> 8;
			p_data[offet++] = bat_charge_data[i].discharge_limit_power & 0xff;
		}

		for(i = 0; i < 6; i++)
		{
			p_data[offet++] = bat_charge_data[i].charge_soc_limit >> 8;
			p_data[offet++] = bat_charge_data[i].charge_soc_limit & 0xff;
			p_data[offet++] = bat_charge_data[i].discharge_soc_lower_limit >> 8;
			p_data[offet++] = bat_charge_data[i].discharge_soc_lower_limit & 0xff;
		}

		offet++;
		for(i = 0; i < 6; i++)
		{
			if(bat_charge_data[i].charge_prohibit)
			{
				BIT_SET(p_data[offet], i);
			}
		}
		offet += 2;
		for(i = 0; i < 6; i++)
		{
			if(bat_charge_data[i].discharge_prohibit)
			{
				BIT_SET(p_data[offet], i);
			}
		}
		offet++;
		for(i = 0; i < 6; i++)
		{
			p_data[offet++] = p_internal_shared_data->cmu_sys_status[i];
			g_sci_cmu_sys_status[i] = p_internal_shared_data->cmu_sys_status[i];
		}

	}

	return offet;
}

/**
 * @brief  充放电信息设置，间隔5s
 */
static void set_bat_charge_data(void)
{
	uint8_t i = 0;
	int16_t ret = -1;
	uint8_t len = 0;
	bat_charge_data_t *bat_charge_data = sdk_shm_bat_charge_data_info_get();
    static uint8_t wait_cnt = 0;
	uint8_t updata_flag = 0;
 
    if(wait_cnt++ > SCI_BAT_CHARGE_DATA_UPDATE)
    {
        updata_flag = 1;
    }
    if(sci_is_ready() != true)
    {
        return;
    }
	if((updata_flag) || (master_slave_var_check()))
	{
		if(bat_charge_data == NULL)
		{	
			return;
		}
		
		memset(g_sci_task.txbuf, 0, SCI_BUF_SIZE);
		len = bat_charge_data_pack(g_sci_task.txbuf);
		if(len < 0)
		{
			return;
		}
		course_flag_set();			// 交互开始
		for(i = 0; i < CMD_RETRYCNT_MAX; i++)
		{
			pthread_mutex_lock(&sofar_sci_mutex);
			ret = sci_send_command(DEV_ADDR_CONTAINER, FUNCID_SET_BAT_CHARGE_PARM, len, g_sci_task.txbuf);
			if(ret == 0)
			{
				ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, FUNCID_SET_BAT_CHARGE_PARM);
			}
			pthread_mutex_unlock(&sofar_sci_mutex);
			if(ret > 0)
			{	
				SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack ok and valid_data_len = %d\n",__func__, __LINE__, ret);
				break;
			}
			else
			{
				SCI_DEBUG_LOG((int8_t *)"\n [%s:%d] ack error and ret = %d\n",__func__, __LINE__, ret);
			}
			usleep(1000 * 100);
		}
		if(ret > 0)
		{
			// 无数据处理
			if(1 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
			{
				SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] set_bat_charge_data Set ok!!!\n"),__func__, __LINE__);
			}
			else if(0 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
			{
				SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] set_bat_charge_data Set fail!\n"),__func__, __LINE__);	
			}
			// 清异常通讯计数
			sci_error_handle(g_sci_task.devaddr, 0, 0);
		}
		course_flag_clear();			// 交互结束
		wait_cnt = 0;
	}

}


/**
 * @brief  下发动作阈值过程--交互
 * @param  [in] funcid 下发阈值对应功能码
 * @param  [in] p_data 待发送数据首地址
 * @param  [in] data_num 待发送数据个数
 * @param  [out] none
 * @return 0:成功  -1:失败
 */
static int32_t sci_threshold_course(uint16_t function_id, uint16_t *p_data, uint32_t data_num)
{
	uint8_t i = 0;
	int32_t data_len = 0;		// 发送数据长度
	int32_t ret = -1;

	if(NULL == p_data)
	{
		return -1;
	}

	course_flag_set();			// 交互开始
	memset(g_sci_task.txbuf, 0, SCI_BUF_SIZE);
	data_len = sci_onpack_txdata(&g_sci_task.txbuf[INDEX_DATA_HOST], p_data, data_num);
	if(data_len == -1)
	{
		course_flag_clear();
		return -1;
	}
		
	for(i = 0; i < CMD_RETRYCNT_MAX; i++)
	{
		pthread_mutex_lock(&sofar_sci_mutex);
		ret = sci_send_command(DEV_ADDR_CONTAINER, function_id, data_len, &g_sci_task.txbuf[INDEX_DATA_HOST]);
		if(ret == 0)
		{
			ret = sci_read_ackdata(SCI_TIMEOUT_MS, &g_sci_task.rxbuf[INDEX_DATA_SLAVE], DATA_SIZE_MAX, function_id);
		} 
		pthread_mutex_unlock(&sofar_sci_mutex);
		if(ret > 0)
		{
			break;
		}
		usleep(1000 * 100);
	}
	if(ret > 0)
	{
		// 无数据处理
		if(1 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
		{
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] 2-Threshold Set ok!!!\n"),__func__, __LINE__);
			ret = 0;
		}
		else if(0 == g_sci_task.rxbuf[INDEX_DATA_SLAVE])
		{
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] 2-Threshold Set fail!\n"),__func__, __LINE__);	
			ret = -1;
		}
		// 清异常通讯计数
		sci_error_handle(g_sci_task.devaddr, 0, 0);
	}
	course_flag_clear();			// 交互结束

	return ret;
}


/**
 * @brief  下发定值参数
 * @param  [in]  function_id 下发数据功能码，具体见data_shm.h
 * @param  [out] none
 * @return 0：成功   -1：失败
 */
int32_t set_constant_data(uint16_t function_id,uint16_t *p_data, uint32_t data_num)
{
	int32_t ret = 0;

    if(is_update_flag() == true)
    {
        return -1;
    }

    if(sci_is_ready() != true)
    {
        return -1;
    }

	ret = sci_threshold_course(function_id, p_data, data_num);
	task_stage_set(STAGE_GET_REALTIMEDATA);

	return ret;
}


/**
 * @brief  SCI通讯任务管理
 * @param  [in] arg
 * @param  [out] none
 * @return 0:正常  负数:异常
 */
static int32_t sci_task_manage(void)
{
	int32_t ret = -1;
	sci_localbuf_t *p_localbuf = NULL;
    constant_parameter_data_t *p_constant_para = sdk_shm_constant_parameter_data_get();

	p_localbuf = &g_sci_localbuf;
	if(NULL == p_localbuf)
	{
		return ret;
	}

    if(is_update_flag() == true)
    {
        return ret;
    }
	
    SCI_DEBUG_LOG((int8_t *)("\n [%s:%d]  g_sci_task.stage: %d\n"),__func__, __LINE__, g_sci_task.stage);
	// 直接判断阶段
	switch(g_sci_task.stage)
	{
		case STAGE_SHAKE_HAND:
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d]  shake hand!\n"),__func__, __LINE__);
			ret = sci_handshake_course();
			if(ret == 0)
			{
				task_stage_set(STAGE_GET_ETHDATA);
			}
			break;

		case STAGE_GET_ETHDATA:
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] get eth data!\n"),__func__, __LINE__);
			sci_ethdata_course();
			task_stage_set(STAGE_GET_CFGDATA);
			break;

        case STAGE_GET_CFGDATA:
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] get cfg data!\n"),__func__, __LINE__);
            //上电之后更新系统时间,之后按照定时更新
            sync_time();
            //上电读取电表配置参数
	        get_elec_meter_config_param();
            //获取光伏电表配置参数
            photovoltaic_meter_cfg_get();
			task_stage_set(STAGE_GET_REALTIMEDATA);
			break;

		case STAGE_GET_REALTIMEDATA:
			SCI_DEBUG_LOG((int8_t *)("\n [%s:%d] get realtime data!\n"),__func__, __LINE__);
			sci_realtimedata_course();
			fan_ctrl();
			break;

		default:
			break;
	}
    
    period_sync_time();
    sci_get_ems_parm(1);
    sci_get_holiday_ems_parm(1);
	set_bat_charge_data();
	sci_get_elec_meter1_data();
    //只有在小桔场景下才会去读取电表2、电表3数据
    if(p_constant_para->cabinet_param_data.scenario_setting == 2)
    {
        sci_get_elec_meter2_data();
        sci_get_elec_meter3_data();
    }
    //如果存在光伏电表则循环读取光伏电表数据
    if(p_constant_para->photovoltaic_meter_cfg.meter_cnt)
    {
        sci_get_photovoltaic_meter_data();
    }
    //如果使能防逆流电表则读取pcc电表数据
    if(p_constant_para->cabinet_param_data.rs485_device_enable.bit.backflow_meter)
    {
        sci_get_pcc_meter_data();
    }
    sci_get_mcu2_notice_info();
	set_master_slave_const();
	set_master_slave_var(); // 作为从机时不执行
    sci_get_master_slave_parm();//作为从机和主机时，执行频率不同
	return ret;
}

/**
 * @brief  SCI通讯线程
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
void *thread_scicomm(void *arg)
{
	prctl(PR_SET_NAME, "scicomm_thread");
	sleep(1);							// 集装箱的sci线程,上电延时1s启动
	
	sci_task_init();

	while(1)
	{   	
		sci_task_manage();
		usleep(200 * 1000);				// 1000ms
	}

	pthread_exit(NULL);

}

/**
 * @brief  SCI通讯线程
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
void *thread_fast_scicomm(void *arg)
{
	prctl(PR_SET_NAME, "thread_fast_scicomm");
	sleep(10);							// 集装箱的sci线程,上电延时1s启动

	while(1)
	{
		drmn_power_ctrl();
		usleep(100 * 1000);				// 100ms
	}

	pthread_exit(NULL);

}
/**
 * @brief  SCI通讯模块初始化
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
void sci_module_init(void)
{
	pthread_t container_sci;
	pthread_t update_mcu2;
	pthread_t fast_sci;
	pthread_attr_t attr;

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);

	if(pthread_create(&container_sci,&attr,thread_scicomm,NULL) != 0)
	{
		perror("pthread_create thread_scicomm");
	}

	if(pthread_create(&fast_sci,&attr,thread_fast_scicomm,NULL) != 0)
	{
		perror("pthread_create thread_fast_scicomm");
	}
	if(pthread_create(&update_mcu2,&attr,thread_update,NULL) != 0)
	{
		perror("pthread_create thread_update");
	}
	
	pthread_attr_destroy(&attr);
	return;
}

