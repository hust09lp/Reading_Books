#ifndef __UPDATE_TASK_H__
#define	__UPDATE_TASK_H__

#include "data_types.h"


#define FUNCID_UPGRADE_GET_CHIPROLE  		(0x9010)                    // 获取芯片角色功能码
#define	FUNCID_TRANSFER_FILEDATA  			(0x9020)                    // 传输升级数据功能码
#define	FUNCID_TRANSFER_FILEDATA_STOP 		(0x9021)                    // 升级数据终止传输功能码
#define FUNCID_UPDATE_START_NOW             (0x9022)                    // 开始升级功能码


#define T_PATH_SIZE				            (100)                       // 路径长度
#define FIRM_DATA_RETRY_CNT                 (8)                         // 升级数据重发次数
#define FIRM_DATA_SIZE_PER_PACK             (238)                       // 每包升级数据大小

#define SIGNATURE_LEN_1K                    (1024)                      // 签名信息长度
#define SIGNATURE_VERSION                   (0x03)                      // 签名信息版本

#define FILE_TYPE_CODE_APP                  (0x00)                      // 文件类型编码-APP
#define FILE_TYPE_CODE_CORE                 (0x01)                      // 文件类型编码-CORE
#define CHIP_ROLE_CODE_MCU2                 (0x34)                      // MCU2芯片角色编码
#define CHIP_MODEL_CODE_MCU2                ("R0")                      // MCU2芯片代号

#define FUNCID_FILE_TRANS_START  		(0xA000)                    // 文件传输开始
#define FUNCID_FILE_TRANS_SEND  		(0xA001)                    // 下发升级文件数据
#define FUNCID_FILE_TRANS_END 			(0xA002)                    // 文件传输完成

#define FUNCID_FILE_GET_START  		(0xA010)                    // 文件接收开始
#define FUNCID_FILE_GET      		(0xA011)                    // 接收文件数据

#if (0)
#define T_DEBUG_LOG(...) log_i(__VA_ARGS__);
#else
#define T_DEBUG_LOG(...) {do {} while(0);}
#endif

typedef enum{

    STAGE_FIRM_SEND_FIRM1 = 0,           // core固件下发阶段(含校验) 
    STAGE_FIRM_SEND_FIRM2,               // app固件下发阶段（含校验）
    STAGE_UPDATE_CMD_SEND,               // 升级命令下发阶段
    STAGE_DEFAULT_NONE_UPDATE,           // 不升级返回升级失败阶段

}update_stage_e;

// V02软件固件签名信息，见《软件固件签名规则》
#pragma pack(push)
#pragma pack(1)
typedef struct
{
    uint8_t         protocol_version;   // 协议版本号
    uint32_t        file_len;           // 有效文件长度 小端模式
    uint32_t        file_crc;           // 有效字节crc32
    int8_t          chip_type[30];      // 芯片型号
    int8_t          soft_version[20];   // 软件版本
    int8_t          hard_version[20];   // 硬件版本
    int8_t          project_name[30];   // 工程名称
    int8_t          creation_date[12];  // 生成日期
    uint32_t        code_start_addr;    // 程序起始地址
    uint8_t         chip_role;          // 芯片角色编码
    int8_t          chip_code[2];       // 芯片代号,如M1
    uint8_t         file_type;          // 文件类型编码
    uint8_t         reserved[127];      // 预留
}firmware_signature_t;
#pragma pack(pop)

// 升级标志共用体
#pragma pack(push)
#pragma pack(1)
typedef union
{
    struct{
        uint32_t firm1:1;
        uint32_t firm2:1;
        uint32_t rsv1:30;
    }bit;

    uint32_t total; 
}update_flag_u;
#pragma pack(pop)

// 固件专属信息结构体
#pragma pack(push)
#pragma pack(1)
typedef struct
{
    int8_t path[T_PATH_SIZE];
    int32_t index;
    firmware_signature_t signature_info;
}firmware_info_t;
#pragma pack(pop)

// 固件升级任务结构体
#pragma pack(push)
#pragma pack(1)
typedef struct
{
    // uint8_t update_fail_warn;     // Bit0:mcu1-app升级失败 Bit1:mcu1-core升级失败 Bit2:mcu2-app升级失败 Bit3:mcu2-core升级失败 Bit4-7:预留
    update_flag_u update_flag;
    update_stage_e stage;
    firmware_info_t mcu2_firm1;
    firmware_info_t mcu2_firm2;
}firmware_update_task_t;
#pragma pack(pop)


/**
 * @brief  MCU2升级线程
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
void *thread_update(void *arg);


#endif