#ifndef _DEV_CONFIG_H
#define _DEV_CONFIG_H

#define MAX_CLUSTER_NUM             6
#define PACK_NUM_IN_CLUSTER         8
#define BAT_NUM_IN_PACK             48

#ifndef ARRAY_SIZE
#define ARRAY_SIZE(array) (sizeof(array) / sizeof(array[0]))
#endif

#endif
