#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include "data_shm.h"
#include "sdk_shm.h"
//#include "modbus.h"
#include "modbus-private.h"
#include "sdk_public.h"
#include "sci_task.h"
#include "sdk_fs.h"
#include "cs104_slave.h"
#include "cs104_connection.h"
#include "iec104_slave.h"
#include "cmu_command_parser.h"

#include "mem_utils.h"
#include "sdk_log.h"

#define  CMU_SYSTEM_FAULT_LEN_BYTE              6       // CMU-1系统（故障信息）所占字节数
#define  CONTAINER_SYSTEM_STATUS_LEN_BYTE       14      // CMU-1储能柜系统（状态信息）所占字节数
#define  CONTAINER_SYSTEM_WARN_LEN_BYTE         18      // CMU-1储能柜系统（告警信息）所占字节数
#define  CONTAINER_SYSTEM_FAULT_LEN_BYTE        18      // CMU-1储能柜系统（故障信息）所占字节数

#define  BATTERY_CLUSTER_STATUS_LEN_BYTE        4       // CMU-1电池柜内电池簇（状态信息）所占字节数
#define  BATTERY_CLUSTER_WARN_LEN_BYTE          18      // CMU-1电池柜内电池簇（告警信息）所占字节数
#define  BATTERY_CLUSTER_FAULT_LEN_BYTE         10      // CMU-1电池柜内电池簇（故障信息）所占字节数

#define  BCU_DEVICE_NUM                         6      // 系统实际最大电池簇数量
#define  BATTERY_PCS_MODULE_STATE_NUM           15      // PCS功率模块状态所点寄存器数

#define  PCS_MODULE_PARAM_REG_NUM               6      // PCS模块参数 寄存器数
#define  PCS_MODULE_STATE_NUM           15      // PCS功率模块状态所点寄存器数
#define  PCS_MODULE_STATE_NUM           15      // PCS功率模块状态所点寄存器数

#define  BATTERY_TELECOMMAND_LEN_BYTE           12      // CMU-1电池柜内电池簇遥控信息所占字节数

#if (1)
#define MODBUS_DEBUG_LOG(format, ...) log_i((const int8_t*)format, ##__VA_ARGS__)
#else
#define MODBUS_DEBUG_LOG(...) {do {} while(0);}
#endif

#if (1)
#define MODBUS_DEBUG_LOG_DATA(...) printf(__VA_ARGS__)
#else
#define MODBUS_DEBUG_LOG_DATA(...) {do {} while(0);}
#endif

typedef struct 
{
    uint16_t base_addr;
    uint16_t end_addr;
} addr_info_t;

static int32_t iec104_raw_dat_to_modbus_dat( addr_info_t *p_iec, addr_info_t *p_mb, modbus_frame_t *modbus_frame, uint16_t *data_buff,uint16_t type_id);
static void modbus_convert_info_print( modbus_convert_info_t *p_modbus_convert_info );

// void mem_utils_print_u16_dat( char *head_str, uint16_t *dat, uint16_t dat_len, uint8_t col_num, bool col_num_print  )
// {
//     if( head_str )
//     {
//         printf("%s ", head_str);
//     }

//     printf( "dat len:%d , data:", dat_len );
//     for (size_t i = 0; i < dat_len; i++)
//     {
//         if( (i % col_num) == 0 )
//         {
//             printf( "\r\n" );
//             if( col_num_print )
//             {
//                 printf("%04d: ", i / col_num);
//             }
//         }
//         printf( "%04X ", dat[i] );
//     }
//     printf( "\r\n");
// }

/**
 * @brief   modbus应答时间等待
 * @param   
 * @note    
 * @return  
 */
void _sleep_response_timeout(modbus_t *ctx)
{
    /* Response timeout is always positive */
#ifdef _WIN32
    /* usleep doesn't exist on Windows */
    Sleep((ctx->response_timeout.tv_sec * 1000) + (ctx->response_timeout.tv_usec / 1000));
#else
    /* usleep source code */
    struct timespec request, remaining;
    request.tv_sec = ctx->response_timeout.tv_sec;
    request.tv_nsec = ((long int) ctx->response_timeout.tv_usec) * 1000;
    while (nanosleep(&request, &remaining) == -1 && errno == EINTR) {
        request = remaining;
    }
#endif
}

/**
 * @brief   modbus发送数据
 * @param   
 * @note    
 * @return  
 */
int send_msg(modbus_t *ctx, uint8_t *msg, int msg_length)
{
    int rc;
    int i;

    msg_length = ctx->backend->send_msg_pre(msg, msg_length);
    if (0) {//ctx->debug
    
    	MODBUS_DEBUG_LOG_DATA("send_msg:");
        for (i = 0; i < msg_length; i++)
            MODBUS_DEBUG_LOG_DATA("[%.2X]", msg[i]);
        MODBUS_DEBUG_LOG_DATA("\n");
    }

    /* In recovery mode, the write command will be issued until to be
       successful! Disabled by default. */
    do {
        rc = ctx->backend->send(ctx, msg, msg_length);
        if (rc == -1) {
            _error_print(ctx, NULL);
            if (ctx->error_recovery & MODBUS_ERROR_RECOVERY_LINK) {
#ifdef _WIN32
                const int wsa_err = WSAGetLastError();
                if (wsa_err == WSAENETRESET || wsa_err == WSAENOTCONN ||
                    wsa_err == WSAENOTSOCK || wsa_err == WSAESHUTDOWN ||
                    wsa_err == WSAEHOSTUNREACH || wsa_err == WSAECONNABORTED ||
                    wsa_err == WSAECONNRESET || wsa_err == WSAETIMEDOUT) {
                    modbus_close(ctx);
                    _sleep_response_timeout(ctx);
                    modbus_connect(ctx);
                } else {
                    _sleep_response_timeout(ctx);
                    modbus_flush(ctx);
                }
#else
                int saved_errno = errno;

                if ((errno == EBADF || errno == ECONNRESET || errno == EPIPE)) {
                    modbus_close(ctx);
                    _sleep_response_timeout(ctx);
                    modbus_connect(ctx);
                } else {
                    _sleep_response_timeout(ctx);
                    modbus_flush(ctx);
                }
                errno = saved_errno;
#endif
            }
        }
    } while ((ctx->error_recovery & MODBUS_ERROR_RECOVERY_LINK) && rc == -1);

    if (rc > 0 && rc != msg_length) {
        errno = EMBBADDATA;
        return -1;
    }

    return rc;
}

/**
 * @brief   modbus-tcp转104报文
 * @param   
 * @note    
 * @return  
 */
int32_t modbusTCPToIEC104_2(uint16_t slave, uint16_t reg_num, uint8_t *data, uint8_t len, IEC60870_5_TypeID typeid)
{
    CS101_ASDU asdu = NULL;
    
    CS104_Connection cs104_conn = NULL;
    cs104_conn = cs104_conn_get(slave - MODBUS_DEVICE_ADDR_FIRST_CMU);
    if (cs104_conn == NULL)
    {
        printf("cs104 is disconnect.\n");
        return MODBUS_EXCEPTION_SLAVE_OR_SERVER_FAILURE;
    }

    CS101_AppLayerParameters alParams = CS104_Connection_getAppLayerParameters(cs104_conn);

    asdu = CS101_ASDU_create(alParams, false, CS101_COT_ACTIVATION, 0, 1, false, false);
    if(asdu == NULL)
    {
        printf("CS101_ASDU_create failed\n");
        return MODBUS_EXCEPTION_SLAVE_OR_SERVER_FAILURE;
    }

    CS101_ASDU_setTypeID(asdu, typeid);
    CS101_ASDU_setSequence(asdu, 0);
    CS101_ASDU_setNumberOfElements(asdu, reg_num);

    CS101_ASDU_addPayload(asdu, data, len);

    if(cs104_conn != NULL)
    {
        CS104_Connection_sendASDU(cs104_conn, asdu);
    }

    CS101_ASDU_destroy(asdu);
    printf("%s sucess\r\n", __FUNCTION__);
    return 0;
}
/**
 * @brief   modbus-tcp转104报文
 * @param   
 * @note    
 * @return  
 */
int32_t modbusTCPToIEC104(uint16_t slave, uint16_t reg_num, uint8_t *data, uint8_t len, IEC60870_5_TypeID typeid)
{
    CS101_ASDU asdu = NULL;
    
    CS104_Connection cs104_conn = NULL;
    cs104_conn = cs104_conn_get(slave - MODBUS_DEVICE_ADDR_FIRST_CMU);
    if (cs104_conn == NULL)
    {
        printf("cs104 is disconnect.\n");
        return MODBUS_EXCEPTION_SLAVE_OR_SERVER_FAILURE;
    }

    CS101_AppLayerParameters alParams = CS104_Connection_getAppLayerParameters(cs104_conn);

    asdu = CS101_ASDU_create(alParams, false, CS101_COT_ACTIVATION, 0, 1, false, false);
    if(asdu == NULL)
    {
        printf("CS101_ASDU_create failed\n");
        return MODBUS_EXCEPTION_SLAVE_OR_SERVER_FAILURE;
    }

    CS101_ASDU_setTypeID(asdu, typeid);
    CS101_ASDU_setSequence(asdu, 0);
    CS101_ASDU_setNumberOfElements(asdu, reg_num);

    CS101_ASDU_addPayload(asdu, data, len);

    if(cs104_conn != NULL)
    {
        CS104_Connection_sendASDU(cs104_conn, asdu);
    }

    CS101_ASDU_destroy(asdu);

    return 0;
}

/**
 * @brief   等待104应答
 * @param   
 * @note    
 * @return  
 */
int32_t wait_for_iec104Data(uint16_t *data_buff)
{
    uint16_t i = 0;
    modbus_convert_info_t *modbus_status = NULL;
    // 延时等待3s
    for (i = 0; i < 600; i++)
    {
        modbus_status = cmu_iec104_data_get();
        if (modbus_status->flag == END_CONVERT)
        {
            memcpy(data_buff, modbus_status->data, modbus_status->num*sizeof(uint16_t));
            return 0;
        }
        usleep(5000);
    }
    modbus_status->flag = END_CONVERT;

    return MODBUS_EXCEPTION_SLAVE_OR_SERVER_BUSY;
}

/**
 * @brief  CMU遥控命令的发送
 * @param   
 * @note    
 * @return  
 */
void send_cmu_remoteCtrl(modbus_frame_t *modbus_frame, uint16_t *data)
{
    //cmu_modbus_info_set(modbus_frame->reg_num, modbus_frame->address, modbus_frame->address);
    modbusTCPToIEC104(modbus_frame->slave, modbus_frame->reg_num, (uint8_t*)data, modbus_frame->reg_num*4+2, C_SC_NA_1);
    //cmu_modbus_info_reset();
}

/**
 * @brief  CMU时钟同步的发送
 * @param   
 * @note    
 * @return  
 */
void send_cmu_clock_syn(modbus_frame_t *modbus_frame, uint16_t *data)
{
    //cmu_modbus_info_set(modbus_frame->reg_num, modbus_frame->address, modbus_frame->address);
    modbusTCPToIEC104(modbus_frame->slave, modbus_frame->reg_num, (uint8_t*)data, 12, C_CS_NA_1);
    //cmu_modbus_info_reset();
}

/**
 * @brief  modbus转104并发送数据，根据报文判断是否需要等待应答
 * @param   
 * @note    
 * @return  
 */
int32_t send_IEC104_msg(uint16_t slave, int typeID, modbus_convert_info_t *convert_info, uint16_t *data_buff, int *p_len)
{
    int32_t rc = 0;
    modbus_convert_info_t *modbus_status = cmu_iec104_data_get();
    cmu_modbus_info_set(convert_info->current, convert_info->start_add, convert_info->end_add);
    rc = modbusTCPToIEC104(slave, convert_info->current, (uint8_t *)convert_info->data, convert_info->msg_len, typeID);
    if (rc == 0 && typeID != P_SC_WT_1 && typeID != C_SC_NA_1)
    {
        rc = wait_for_iec104Data(data_buff);
    }
    modbus_status->flag = END_CONVERT;
    if (p_len != NULL)
    {
        *p_len += convert_info->current;
    }
    convert_info->current = 0;
    convert_info->msg_len = 2; // 前两字节固定的，不用清除
    
    return rc;
}

/**
 * @brief  数据U16转换成16位状态
 * @param   
 * @note    
 * @return  
 */
void convert_u16_to_bit(uint16_t reg_num, uint16_t *buff, uint16_t *data_buff)
{
    uint16_t i = 0;
    uint16_t j = 0;
    uint16_t value = 0;
    
    for (i = 0; i < reg_num*16; i++)
    {
        value |= (buff[i] << (i%16));
        if (i%16 == 15)
        {
            data_buff[j] |= value;
            value = 0;
            j++;
        }
    }

    if (i%16 != 15)
    {
        data_buff[j] |= value;
    }
}

/**
 * @brief  104地址打包
 * @param   
 * @note    
 * @return  
 */
void IEC104_packag_address(modbus_convert_info_t *convert_info, uint16_t address)
{
    uint8_t *p_data = (uint8_t *)convert_info->data;

    p_data[convert_info->msg_len++] = (uint8_t)(address & 0xff);  //最低位
    p_data[convert_info->msg_len++] = (uint8_t)((address/0x100) & 0xff);  //中间位
    p_data[convert_info->msg_len++] = (uint8_t)((address/0x10000) & 0xff);
    if (convert_info->end_add < address)
    {
        convert_info->end_add = address;
    }
    convert_info->current++;
}

/**
 * @brief  设备系统参数应答处理
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
static int32_t modbus_reply_user_device_system_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t offset_addr = 0, i, j;
    uint16_t max_length = 0, ms;
    device_system_param_t device_system = {0};
    sdk_rtc_t time = {0};
    uint8_t data[MODBUS_MAX_MESSAGE_LENGTH] = {0};
    uint16_t address = 0, start_index = 0;
    modbus_frame_t syn_frame = {0};

    offset_addr = modbus_frame->address - USER_DEVICE_SYSTEM_ADDR_START;
    max_length = sizeof(device_system_param_t);
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d]  slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    if (offset_addr < 0 || (offset_addr + modbus_frame->reg_num)*2 > max_length) 
    {
        return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }
    //printf("TEST!!!");

    //从共享内存中组合出与modbus点表顺序相同的结构体
    sdk_rtc_get(RTC_BIN_FORMAT, &time);
    MODBUS_DEBUG_LOG("[%s:%d] %04d.%02d.%02d, %02d:%02d:%02d\n",__func__, __LINE__,  time.tm_year+2000,time.tm_mon, time.tm_day,time.tm_hour,time.tm_min,time.tm_sec);
    device_system.tm_year = time.tm_year+2000;
    device_system.tm_mon = time.tm_mon;
    device_system.tm_day = time.tm_day;
    device_system.tm_hour = time.tm_hour;
    device_system.tm_min = time.tm_min;
    device_system.tm_sec = time.tm_sec;

    memcpy(data_buff, &device_system, sizeof(device_system_param_t)); 

    switch (modbus_frame->function)
    {
        case MODBUS_FC_READ_HOLDING_REGISTERS:
        case MODBUS_FC_READ_INPUT_REGISTERS: 
        {
            memcpy(data_buff, data_buff + offset_addr, modbus_frame->reg_num * 2); 
            break;
        }
        case MODBUS_FC_WRITE_MULTIPLE_REGISTERS:
        {
            if(((modbus_frame->address >= USER_DEVICE_SYSTEM_ADDR_START) && (modbus_frame->address <= USER_DEVICE_SYSTEM_ADDR_START+6)) && (modbus_frame->reg_num != 6))// 时间必须6个寄存器连写
            {
                return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
            }
            //printf("req data:%x, %x, %x, %x, %x, %x, %x\n", modbus_frame->req[0],modbus_frame->req[1],modbus_frame->req[2],modbus_frame->req[3],modbus_frame->req[4],modbus_frame->req[5], modbus_frame->offset);
            for (i = offset_addr, j = 6; i < (offset_addr + modbus_frame->reg_num); i++, j += 2) {
               /* 6 and 7 = first value */
                data_buff[i] = (modbus_frame->req[modbus_frame->offset + j] << 8) + modbus_frame->req[modbus_frame->offset + j + 1];
                //printf("change data:%x\n", data_buff[i]);
            }
            memcpy(&device_system, data_buff, sizeof(device_system_param_t));
            time.tm_year = device_system.tm_year - 2000;
            time.tm_mon = device_system.tm_mon;
            time.tm_day = device_system.tm_day;
            time.tm_hour = device_system.tm_hour;
            time.tm_min = device_system.tm_min;
            time.tm_sec = device_system.tm_sec;
            #if 0
            if(0 != sdk_rtc_set(RTC_BIN_FORMAT, &time))
            {
                return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
            }
            #endif
            data[start_index++] = (uint8_t)(address & 0xff);  //最低位
            data[start_index++] = (uint8_t)((address/0x100) & 0xff);  //中间位
            data[start_index++] = (uint8_t)((address/0x10000) & 0xff);
            ms = time.tm_sec;
            ms *= 1000;
            data[start_index++] = (uint8_t)ms;
            data[start_index++] = (uint8_t)(ms>>8);
            data[start_index++] = time.tm_min;
            data[start_index++] = time.tm_hour;
            data[start_index++] = time.tm_day;
            data[start_index++] = time.tm_mon;
            data[start_index++] = time.tm_year;
            memcpy(&syn_frame, modbus_frame, sizeof(syn_frame));
            syn_frame.slave = MODBUS_CURRENT_CMU_NUM + MODBUS_DEVICE_ADDR_CSU;
            send_cmu_clock_syn(&syn_frame, (uint16_t*)data);
            //printf("syn cmu clock!\n");
            break;
        }

        default:
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
    }
    
    return 0;
}

/**
 * @brief  CMU系统信息应答处理
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_user_cmu_system_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t i = 0;
    int32_t rc = 0;
    uint16_t offset_addr = 0;
    uint16_t address = 0;
    int typeID = M_ME_NC_1;
    int len = 0;
    modbus_convert_info_t convert_info = {0};
    uint8_t *p_data = (uint8_t *)convert_info.data;

    offset_addr = modbus_frame->address - USER_CMU_SYSTEM_ADDR_START;
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d] slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

	//该地址段数据只支持读取
	if((modbus_frame->function != MODBUS_FC_READ_HOLDING_REGISTERS) && (modbus_frame->function != MODBUS_FC_READ_INPUT_REGISTERS))
	{
		return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
	}
	
    if (offset_addr < 0 || (offset_addr + modbus_frame->reg_num) > USER_CMU_SYSTEM_ADDR_END - USER_CMU_SYSTEM_ADDR_START + 1) 
    {
        return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }
    p_data[0] = 1;
    p_data[1] = 0;
    convert_info.msg_len = 2;
    convert_info.num = modbus_frame->reg_num;

    address = 0x4301 + offset_addr;
    convert_info.current = 0;

	//该地址段数据只支持读取
	if((modbus_frame->function != MODBUS_FC_READ_HOLDING_REGISTERS) && (modbus_frame->function != MODBUS_FC_READ_INPUT_REGISTERS))
	{
		return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
	}

    for (i = 0; i < convert_info.num; i++)
    {
    	if (convert_info.current == 0 )
        {
            convert_info.start_add = address;
        }
        IEC104_packag_address(&convert_info, address);
        address++;

        if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
        {
            rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
            if (rc != 0)
            {
                return rc;
            }
            
        }
    }

    if (convert_info.current != 0)
    {
        rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
    }
    
    return rc;
}

/**
 * @brief  集装箱系统信息应答处理,数据需要转换成相应104的地址转发
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_user_container_system_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t i = 0;
    int32_t rc = 0;
    uint16_t offset_addr = 0;
    uint16_t address = 0;
    int typeID = M_ME_NC_1;
    int len = 0;
    modbus_convert_info_t convert_info = {0};
    uint8_t *p_data = (uint8_t *)convert_info.data;

    offset_addr = modbus_frame->address - USER_CONTAINER_SYSTEM_ADDR_START;
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d] slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

	//该地址段数据只支持读取
	if((modbus_frame->function != MODBUS_FC_READ_HOLDING_REGISTERS) && (modbus_frame->function != MODBUS_FC_READ_INPUT_REGISTERS))
	{
		return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
	}
	
    if (offset_addr < 0 || (offset_addr + modbus_frame->reg_num) > USER_CONTAINER_SYSTEM_ADDR_END - USER_CONTAINER_SYSTEM_ADDR_START + 1) 
    {
        return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }
    p_data[0] = 1;
    p_data[1] = 0;
    convert_info.msg_len = 2;
	convert_info.num = modbus_frame->reg_num;
	address = modbus_frame->address;
	convert_info.current = 0;

	//该地址段数据只支持读取
	if((modbus_frame->function != MODBUS_FC_READ_HOLDING_REGISTERS) && (modbus_frame->function != MODBUS_FC_READ_INPUT_REGISTERS))
	{
		return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
	}

    for (i = 0; i < convert_info.num; i++)
    {
    	if (convert_info.current == 0 )
        {
            convert_info.start_add = address;
        }
        IEC104_packag_address(&convert_info, address);
        address++;

        if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
        {
            rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
            if (rc != 0)
            {
                return rc;
            }
            
        }
    }

    if (convert_info.current != 0)
    {
        rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
    }
    
    return rc;
}

#include "dev_iec104_st.h"
#include "dev_modbus_st.h"
#if 0
int32_t modbus_reply_user_battery_cluster_info2( modbus_frame_t *modbus_frame, uint16_t *data_buff )
{
    const uint16_t cluster_modbus_addr[] = MODBUS_MEAS_USR_CLUSTERn_DAT_ADDR_LIST;
    const uint16_t cluster_iec_addr[]    = IEC104_MEAS_CLUSTERn_DAT_ADDR_LIST;
    
    modbus_convert_info_t convert_info = {0};
    uint16_t iec_cluster_base_addr = 0;
    uint16_t mb_cluster_base_addr = 0;
    uint16_t iec_reg_addr = 0;
    uint16_t mb_reg_addr = modbus_frame->address;
    uint16_t mb_reg_offset = 0;
    int32_t len = 0, rc = 0;
    
    /*---- 计算 modbus 地址 和偏移量是否 在合法范围内 */
    if ( (modbus_frame->address + modbus_frame->reg_num) > USER_BATTERY_CLUSTER_ADDR_END  )
    {
        /* 超出范围 */
        return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }

    convert_info.data[0] = 0x0001;
    convert_info.msg_len = 2;

    for ( size_t i = 0; i < modbus_frame->reg_num; i++, mb_reg_addr++)
    {
        uint16_t cluster_index = ARRAY_SIZE( cluster_modbus_addr ) - 1;

        /*---- 计算对应的电池簇位置 */
        for ( ; cluster_index != 0 ; cluster_index--)
        {
            if ( mb_reg_addr >= cluster_modbus_addr[ cluster_index ]  )
            {
                break;
            }
        }
        mb_cluster_base_addr  = cluster_modbus_addr[ cluster_index ];
        iec_cluster_base_addr = cluster_iec_addr[ cluster_index ];

        if ( mb_reg_addr >= MODDUS_MEAS_CLUSTERn_POLE_ADDR( mb_cluster_base_addr ))
        {
            /* 极柱 温度范围 */
            mb_reg_offset = mb_reg_addr - MODDUS_MEAS_CLUSTERn_POLE_ADDR( mb_cluster_base_addr );
            iec_reg_addr = IEC104_MEAS_CLUSTERn_POLE_ADDR ( iec_cluster_base_addr ) + mb_reg_offset;

        } else if ( mb_reg_addr >= MODDUS_MEAS_CLUSTERn_PACKn_INFO_ADDR( mb_cluster_base_addr, 0 ))
        {
            uint16_t pack_dat_reg_offset;
            uint16_t pack_id;
            
            /* PACK数据范围 */
            mb_reg_offset = mb_reg_addr - MODDUS_MEAS_CLUSTERn_PACKn_INFO_ADDR( mb_cluster_base_addr, 0 );

            /* 计算 pack 位置 */
            pack_id             = mb_reg_offset / (sizeof( mb_pack_info_t ) / 2);
            pack_dat_reg_offset = mb_reg_offset % (sizeof( mb_pack_info_t ) / 2);

            iec_reg_addr = IEC104_MEAS_CLUSTERn_PACKn_INFO_ADDR ( iec_cluster_base_addr, pack_id) + pack_dat_reg_offset;
        } else {
            /* 普通数据范围 */
            mb_reg_offset = mb_reg_addr - mb_cluster_base_addr;
            iec_reg_addr  = iec_cluster_base_addr + mb_reg_offset;
        }
        if (convert_info.current == 0 )
        {
            convert_info.start_add = iec_reg_addr;
        }

        // MODBUS_DEBUG_LOG("mb reg addr:%d(0x%06X), iec_reg_addr:%d(0x%06X)\n", mb_reg_addr, mb_reg_addr, iec_reg_addr, iec_reg_addr);
        /*-- 打包获取 */
        IEC104_packag_address( &convert_info, iec_reg_addr );
        if (convert_info.current >= 70)
        // if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
        {       
            uint16_t tmp_len = len;

            // modbus_convert_info_print( &convert_info );
            rc = send_IEC104_msg( modbus_frame->slave, M_ME_NC_1, &convert_info, &data_buff[tmp_len], &len);
            if (rc != 0)
            {
                return rc;
            }
            // mem_utils_print_u16_dat( "recv dat:", &data_buff[tmp_len], len, 10, 1 );
        }
    }

    if (convert_info.current != 0)
    {
        uint16_t tmp_len = len;
        // modbus_convert_info_print( &convert_info );
        rc = send_IEC104_msg(modbus_frame->slave, M_ME_NC_1, &convert_info, &data_buff[len], &len);
        // mem_utils_print_u16_dat( "recv dat1111:", &data_buff[tmp_len], len, 10, 1 );
    }
    
    return rc;
}
#endif
/**
 * @brief  电池簇1信息应答处理,此数据需要转换成相应104的地址
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_user_battery_cluster_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t i = 0;
    int32_t rc = 0;
    uint16_t offset_addr = 0;
    uint16_t address = 0;
    int typeID = M_ME_NC_1;
    int len = 0;
    modbus_convert_info_t convert_info = {0};
    uint8_t *p_data = (uint8_t *)convert_info.data;

    offset_addr = modbus_frame->address - USER_BATTERY_CLUSTER_ADDR_START;
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d] slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

	//该地址段数据只支持读取
	if((modbus_frame->function != MODBUS_FC_READ_HOLDING_REGISTERS) && (modbus_frame->function != MODBUS_FC_READ_INPUT_REGISTERS))
	{
		return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
	}
	
    if (offset_addr < 0 || (offset_addr + modbus_frame->reg_num) >= USER_BATTERY_CLUSTER_ADDR_END - USER_BATTERY_CLUSTER_ADDR_START + 1) 
    {
        return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }
    p_data[0] = 1;
    p_data[1] = 0;
    convert_info.msg_len = 2;
	address = modbus_frame->address;
	convert_info.current = 0;
	convert_info.num = modbus_frame->reg_num;

	//该地址段数据只支持读取
	if((modbus_frame->function != MODBUS_FC_READ_HOLDING_REGISTERS) && (modbus_frame->function != MODBUS_FC_READ_INPUT_REGISTERS))
	{
		return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
	}
	
    for (i = 0; i < convert_info.num; i++)
    {
    	if (convert_info.current == 0)
    	{
            convert_info.start_add = address;
        }
        IEC104_packag_address(&convert_info, address);
        address++;

        if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
        {
            rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
            if (rc != 0)
            {
                return rc;
            }
            
        }
    }

    if (convert_info.current != 0)
    {
        rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
    }
    
    return rc;
}

int32_t modbus_reply_user_battery_cluster_info2(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t i = 0;
    int32_t rc = 0;
    uint16_t offset_addr = 0;
    uint16_t address = 0;
    int typeID = M_ME_NC_1;
    int len = 0;
    modbus_convert_info_t convert_info = {0};
    uint8_t *p_data = (uint8_t *)convert_info.data;

    offset_addr = modbus_frame->address - USER_BATTERY2_CLUSTER_ADDR_START;
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d] slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

	//该地址段数据只支持读取
	if((modbus_frame->function != MODBUS_FC_READ_HOLDING_REGISTERS) && (modbus_frame->function != MODBUS_FC_READ_INPUT_REGISTERS))
	{
		return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
	}
	
    if (offset_addr < 0 || (offset_addr + modbus_frame->reg_num) >= USER_BATTERY6_CLUSTER_ADDR_END - USER_BATTERY2_CLUSTER_ADDR_START + 1) 
    {
        return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }
    p_data[0] = 1;
    p_data[1] = 0;
    convert_info.msg_len = 2;
	address = modbus_frame->address;
	convert_info.current = 0;
	convert_info.num = modbus_frame->reg_num;

	//该地址段数据只支持读取
	if((modbus_frame->function != MODBUS_FC_READ_HOLDING_REGISTERS) && (modbus_frame->function != MODBUS_FC_READ_INPUT_REGISTERS))
	{
		return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
	}
	
    for (i = 0; i < convert_info.num; i++)
    {
		if (convert_info.current == 0 )
        {
            convert_info.start_add = address;
        }
        IEC104_packag_address(&convert_info, address);
        address++;

        if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
        {
            rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
            if (rc != 0)
            {
                return rc;
            }
            
        }
    }

    if (convert_info.current != 0)
    {
        rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
    }
    
    return rc;
}



/**
 * @brief  集装箱系统故障信息应答处理,此数据需要转换成相应104的地址,并对相应的位做映射处理
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_user_container_fault_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t i = 0;
    int32_t rc = 0;
    uint16_t offset_addr = 0;
    uint16_t address = 0, comm_buf[200];
	uint8_t temp_buff[400] = {0};
    int typeID = M_ME_NC_1;
    int len = 0;
    modbus_convert_info_t convert_info = {0};
    uint8_t *p_data = (uint8_t *)convert_info.data;

    offset_addr = modbus_frame->address - USER_CONTAINER_FAULT_ADDR_START;
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d] slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

	//该地址段数据只支持读取
	if((modbus_frame->function != MODBUS_FC_READ_HOLDING_REGISTERS) && (modbus_frame->function != MODBUS_FC_READ_INPUT_REGISTERS))
	{
		return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
	}

	if((modbus_frame->address <= CMU_SYS_FAULT_INFO_ADDR_END) && ((modbus_frame->address + modbus_frame->reg_num - 1) > CMU_SYS_FAULT_INFO_ADDR_END))
	{
		return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
	}
	else if((modbus_frame->address <= ENERGY_CABINET_STATUS_INFO_ADDR_END) && ((modbus_frame->address + modbus_frame->reg_num - 1) > ENERGY_CABINET_STATUS_INFO_ADDR_END))
	{
		return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
	}
	else if((modbus_frame->address <= ENERGY_CABINET_WARN_INFO_ADDR_END) && ((modbus_frame->address + modbus_frame->reg_num - 1) > ENERGY_CABINET_WARN_INFO_ADDR_END))
	{
		return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
	}
	else if((modbus_frame->address <= ENERGY_CABINET_FAULT_INFO_ADDR_END) && ((modbus_frame->address + modbus_frame->reg_num - 1) > ENERGY_CABINET_FAULT_INFO_ADDR_END))
	{
		return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
	}
	#if 0
    if (offset_addr < 0 || (offset_addr + modbus_frame->reg_num) > USER_CONTAINER_FAULT_ADDR_END - USER_CONTAINER_FAULT_ADDR_START + 1) 
    {
        return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }
	#endif
    p_data[0] = 1;
    p_data[1] = 0;
    convert_info.msg_len = 2;
    convert_info.num = (CMU_SYSTEM_FAULT_LEN_BYTE + CONTAINER_SYSTEM_STATUS_LEN_BYTE + CONTAINER_SYSTEM_WARN_LEN_BYTE + CONTAINER_SYSTEM_FAULT_LEN_BYTE)/2;

    address = 0x1;
    convert_info.current = 0;

    for (i = 0; i < convert_info.num; i++)
    {
    	if (convert_info.current == 0 )
        {
            convert_info.start_add = address;
        }
        IEC104_packag_address(&convert_info, address);
        address++;

        if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
        {
            rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &comm_buf[len], &len);
            if (rc != 0)
            {
                return rc;
            }
            
        }
    }

    if (convert_info.current != 0)
    {
        rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &comm_buf[len], &len);
    }
	//下面几组数据在CMU内都是连续存储，只需一次请求，但是要计算偏移
	if((modbus_frame->address >= 0x0101) && (modbus_frame->address <= 0x0103))//储能柜故障信息
	{
		offset_addr = modbus_frame->address - 0x0101;
	}
	else if((modbus_frame->address >= 0x0131) && (modbus_frame->address <= 0x0137))//状态信息(IO状态) 
	{
		offset_addr = modbus_frame->address - 0x0131 + 3;
	}
	else if((modbus_frame->address >= 0x01A1) && (modbus_frame->address <= 0x01A9))//告警信息
	{
		offset_addr = modbus_frame->address - 0x01A1 + 3 + 7;
	}
	else if((modbus_frame->address >= 0x0231) && (modbus_frame->address <= 0x0239))//故障信息
	{
		offset_addr = modbus_frame->address - 0x0231 + 3 + 7 + 9;
	}
	else
	{
		return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
	}
	//由于Modbus点表里0x0233为了让“液冷-故障”在连续的四个寄存器中，相比于104增加了一个U8，所以对应的需要往后平移
	for (i = 0; i < len; i++) {
        temp_buff[2 * i] = (uint8_t)(comm_buf[i] & 0xFF);       
        temp_buff[2 * i + 1] = (uint8_t)((comm_buf[i] >> 8) & 0xFF); 
    }
	for (i = 2 * len - 1; i > 41; i--) {
        temp_buff[i] = temp_buff[i - 1];
    }
	
    temp_buff[41] = 0;//在第41位补充的U8

    for (i = 0; i < len; i++) {
        comm_buf[i] = ((uint16_t)temp_buff[2 * i + 1] << 8) | (uint16_t)temp_buff[2 * i];
    }
	if((offset_addr < len) && (offset_addr + modbus_frame->reg_num <= len))
	{
		memcpy(data_buff, comm_buf+offset_addr, modbus_frame->reg_num*2);
	}
	else
	{
		return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
	}
    
    return rc;
}

int32_t modbus_reply_single_data(modbus_frame_t *modbus_frame, uint16_t *p_buf)
{
    return modbus_reply_user_cmu_system_info(modbus_frame, p_buf);
}

//根据地址计算电池簇遥信数据的偏移
static uint16_t get_bat_data_offset(uint16_t address)
{
	uint16_t offset_addr = 0;
	uint16_t i = 0;
	
	if(address > 0x02c0)
	{
		i = (address - 0x02c0)/0x100;
	}

	address -= i * 0x100;
	if((address >= 0x02c1) && (address <= 0x02e0))
	{
		offset_addr = address - 0x02c1 + i * 16;
	}
	else if((address >= 0x02e1) && (address <= 0x0370))
	{
		offset_addr = 2 + address - 0x02e1 + i * 16;
	}
	else if((address >= 0x0371) && (address <= 0x03c0))
	{
		offset_addr = 2 + 9 + address - 0x0371 + i * 16;
	}
	return offset_addr;
}

/**
 * @brief  电池簇系统故障信息应答处理,此数据需要转换成相应104的地址,并对相应的位做映射处理
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_user_battery_fault_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t i = 0;
    int32_t rc = 0;
    uint16_t offset_addr = 0;
    uint16_t address = 0, comm_buf[200];
    int typeID = M_ME_NC_1;
    int len = 0;
    modbus_convert_info_t convert_info = {0};
    uint8_t *p_data = (uint8_t *)convert_info.data;

    offset_addr = modbus_frame->address - USER_BATTERY_FAULT_ADDR_START;
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d] slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

	//该地址段数据只支持读取
	if((modbus_frame->function != MODBUS_FC_READ_HOLDING_REGISTERS) && (modbus_frame->function != MODBUS_FC_READ_INPUT_REGISTERS))
	{
		return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
	}
	
    if (offset_addr < 0 || (offset_addr + modbus_frame->reg_num) > USER_BATTERY_ADDR_END - USER_BATTERY_FAULT_ADDR_START + 1) 
    {
        return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }
    p_data[0] = 1;
    p_data[1] = 0;
    convert_info.msg_len = 2;
    convert_info.num = (BATTERY_CLUSTER_STATUS_LEN_BYTE + BATTERY_CLUSTER_WARN_LEN_BYTE + BATTERY_CLUSTER_FAULT_LEN_BYTE)/2*BCU_DEVICE_NUM;

    address = 1 + (CMU_SYSTEM_FAULT_LEN_BYTE + CONTAINER_SYSTEM_STATUS_LEN_BYTE + CONTAINER_SYSTEM_WARN_LEN_BYTE + CONTAINER_SYSTEM_FAULT_LEN_BYTE)/2;
    convert_info.current = 0;

    for (i = 0; i < convert_info.num; i++)
    {
    	if (convert_info.current == 0 )
        {
            convert_info.start_add = address;
        }
        IEC104_packag_address(&convert_info, address);
        address++;

        if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
        {
            rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &comm_buf[len], &len);
            if (rc != 0)
            {
                return rc;
            }
            
        }
    }

    if (convert_info.current != 0)
    {
        rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &comm_buf[len], &len);
    }
	
	offset_addr = get_bat_data_offset(modbus_frame->address);
	if((offset_addr < len) && (offset_addr + modbus_frame->reg_num <= len))
	{
		memcpy(data_buff, comm_buf+offset_addr, modbus_frame->reg_num*2);
	}
	else
	{
		return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
	}
	
    return rc;
}

/**
 * @brief  PCS系统故障信息应答处理,此数据需要转换成相应104的地址,并对相应的位做映射处理
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_user_pcs_fault_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t i = 0;
    int32_t rc = 0;
    uint16_t offset_addr = 0;
    uint16_t address = 0, comm_buf[200];
    int typeID = M_ME_NC_1;
    int len = 0;
    modbus_convert_info_t convert_info = {0};
    uint8_t *p_data = (uint8_t *)convert_info.data;

    offset_addr = modbus_frame->address - USER_PCS_FAULT_ADDR_START;
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d] slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

	//该地址段数据只支持读取
	if((modbus_frame->function != MODBUS_FC_READ_HOLDING_REGISTERS) && (modbus_frame->function != MODBUS_FC_READ_INPUT_REGISTERS))
	{
		return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
	}
	
    if (offset_addr < 0 || (offset_addr + modbus_frame->reg_num) > USER_PCS_FAULT_ADDR_END - USER_PCS_FAULT_ADDR_START + 1) 
    {
        return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }
    p_data[0] = 1;
    p_data[1] = 0;
    convert_info.msg_len = 2;
    convert_info.num = BATTERY_PCS_MODULE_STATE_NUM;

    address = 1 + (CMU_SYSTEM_FAULT_LEN_BYTE + CONTAINER_SYSTEM_STATUS_LEN_BYTE + CONTAINER_SYSTEM_WARN_LEN_BYTE + CONTAINER_SYSTEM_FAULT_LEN_BYTE)/2 +
        (BATTERY_CLUSTER_STATUS_LEN_BYTE + BATTERY_CLUSTER_WARN_LEN_BYTE + BATTERY_CLUSTER_FAULT_LEN_BYTE)/2*BCU_DEVICE_NUM;
    convert_info.current = 0;

    for (i = 0; i < convert_info.num; i++)
    {
    	if (convert_info.current == 0 )
        {
            convert_info.start_add = address;
        }
        IEC104_packag_address(&convert_info, address);
        address++;

        if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
        {
            rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &comm_buf[len], &len);
            if (rc != 0)
            {
                return rc;
            }
        }
    }

    modbus_convert_info_print( &convert_info );
    if (convert_info.current != 0)
    {
        rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &comm_buf[len], &len);
    }
	memcpy(data_buff, comm_buf+offset_addr, modbus_frame->reg_num*2);
    return rc;
}


static void modbus_convert_info_print( modbus_convert_info_t *p_modbus_convert_info )
{
    printf( "conv info start:%d(0x%04x), end:%d(0x%04x), num:%d, curr:%d\r\n", 
            p_modbus_convert_info->start_add, p_modbus_convert_info->start_add, 
            p_modbus_convert_info->end_add,     p_modbus_convert_info->end_add, 
            p_modbus_convert_info->num, p_modbus_convert_info->current );
    
    printf( "data : 0x%04X ", p_modbus_convert_info->data[0] );

    uint8_t *p_dat =  (uint8_t*)&p_modbus_convert_info->data[1] ;
    uint16_t rd_addr = p_modbus_convert_info->start_add;

    for (size_t i = 0; i < 256 ; )
    {
        uint32_t tmp_reg_addr = 0;
        tmp_reg_addr = ( p_dat[ i ] << 0 ) | ( p_dat[ i + 1] << 8 ) | ( p_dat[ i + 2] << 16 ) ;
        printf( "%06X ", tmp_reg_addr );
        i += 3;
        rd_addr++;    
        if ( rd_addr > p_modbus_convert_info->end_add )
            break;
    }
    printf( "\r\n" );
}

static int32_t iec104_raw_dat_to_modbus_dat( addr_info_t *p_iec, addr_info_t *p_mb, modbus_frame_t *modbus_frame, uint16_t *data_buff,uint16_t type_id)
{
    modbus_convert_info_t convert_info = {0};
    uint16_t iec_reg_addr = 0;
    int32_t rc = 0, len = 0;

    if ((modbus_frame->address + modbus_frame->reg_num) > p_mb->end_addr  ) 
    {
        MODBUS_DEBUG_LOG("[error]%s illegal address", __FUNCTION__);
        return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }

    iec_reg_addr = p_iec->base_addr + (modbus_frame->address - p_mb->base_addr );
    convert_info.data[0] = 0x0001;
    convert_info.msg_len = 2;

    for ( size_t i = 0; i < modbus_frame->reg_num; i++)
    {
        if (convert_info.current == 0 )
        {
            convert_info.start_add = iec_reg_addr;
        }

        IEC104_packag_address(&convert_info, iec_reg_addr);
        convert_info.num++;
        iec_reg_addr++;
        if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
        {
            rc = send_IEC104_msg(modbus_frame->slave, type_id, &convert_info, &data_buff[len], &len);
            if (rc != 0)
            {
                return rc;
            }
        }
    }

    if (convert_info.current != 0)
    {
        modbus_convert_info_print( &convert_info );
        rc = send_IEC104_msg(modbus_frame->slave, type_id, &convert_info, &data_buff[len], &len);
        mem_utils_print_u16_dat( "iec dat ", data_buff , len, 10, true );
    }
    return rc;
}


int32_t modbus_reply_user_pcs_power_data_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
	//该地址段数据只支持读取
	if((modbus_frame->function != MODBUS_FC_READ_HOLDING_REGISTERS) && (modbus_frame->function != MODBUS_FC_READ_INPUT_REGISTERS))
	{
		return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
	}

    addr_info_t iec_pcs_dev_info = { .base_addr = IEC104_USER_PCS_POWER_DATA_START,
                                     .end_addr  = IEC104_USER_PCS_POWER_DATA_END,
                                   };
    addr_info_t mb_pcs_dev_info = { .base_addr = MB_MEAS_USER_PCS_POWER_DATA_ADDR_START,
                                    .end_addr  = MB_MEAS_USER_PCS_POWER_DATA_ADDR_END,
                                  };
    return iec104_raw_dat_to_modbus_dat( &iec_pcs_dev_info, &mb_pcs_dev_info, modbus_frame, data_buff,M_ME_NC_1 );
}

int32_t modbus_reply_user_pcs_dev_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
	//该地址段数据只支持读取
	if((modbus_frame->function != MODBUS_FC_READ_HOLDING_REGISTERS) && (modbus_frame->function != MODBUS_FC_READ_INPUT_REGISTERS))
	{
		return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
	}
    addr_info_t iec_pcs_dev_info = { .base_addr = IEC104_USER_PCS_DEV_INFO_START,
                                     .end_addr  = IEC104_USER_PCS_DEV_INFO_END,
                                   };
    addr_info_t mb_pcs_dev_info = { .base_addr = MB_MEAS_USER_PCS_DEV_INFO_ADDR_START,
                                    .end_addr  = MB_MEAS_USER_PCS_DEV_INFO_ADDR_END,
                                  };
    return iec104_raw_dat_to_modbus_dat( &iec_pcs_dev_info, &mb_pcs_dev_info, modbus_frame, data_buff,M_ME_NC_1 );
}


int32_t modbus_reply_user_pcs_param_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
	uint16_t i = 0;
    int32_t rc = 0;
    uint16_t offset_addr = 0;
    uint16_t address = 0;
    int typeID = 0;
    int len = 0;
    modbus_convert_info_t convert_info = {0};
    uint8_t *p_data = (uint8_t *)convert_info.data;

    offset_addr = modbus_frame->address - MB_MEAS_USER_PCS_PARAM_ADDR_START;
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d] slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    p_data[0] = 1;
    p_data[1] = 0;
    convert_info.msg_len = 2;

    address = 0x8901+offset_addr;
	convert_info.current = 0;
	convert_info.num = modbus_frame->reg_num;

    switch (modbus_frame->function)
    {
        case MODBUS_FC_READ_HOLDING_REGISTERS:
        case MODBUS_FC_READ_INPUT_REGISTERS: 
        {
            typeID = P_SC_RD_1;
			
		    for (i = 0; i < convert_info.num; i++)
            {
                if (convert_info.current == 0 )
		        {
		            convert_info.start_add = address;
		        }
		        IEC104_packag_address(&convert_info, address);
		        address++;

		        if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
		        {
		            rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
		            if (rc != 0)
		            {
		                return rc;
		            }
		            
		        }
            }

            if (convert_info.current != 0)
            {
                rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
            }
            break;
        }
        case MODBUS_FC_WRITE_SINGLE_REGISTER:
        {
            typeID = P_SC_WT_1;
            p_data[convert_info.msg_len++] = 0x80;
            p_data[convert_info.msg_len++] = (uint8_t)(address & 0xff);  //最低位
            p_data[convert_info.msg_len++] = (uint8_t)((address/0x100) & 0xff);  //中间位
            p_data[convert_info.msg_len++] = (uint8_t)((address/0x10000) & 0xff);
            p_data[convert_info.msg_len++] = 0x01;
            p_data[convert_info.msg_len++] = 0x02;
            p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+4];
            p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+3];
            address++;
            rc = modbusTCPToIEC104(modbus_frame->slave, modbus_frame->reg_num, p_data, convert_info.msg_len, typeID);//参数预置
            if(rc == 0)
            {
            	rc = modbusTCPToIEC104(modbus_frame->slave, 0, p_data, 0, typeID);//参数固化
            }
            
            break;
        }
        case MODBUS_FC_WRITE_MULTIPLE_REGISTERS:
        {
            typeID = P_SC_WT_1;
            p_data[convert_info.msg_len++] = 0x80;
            for (i = 0; i < convert_info.num; i++)
            {
            	if (convert_info.current == 0 )
		        {
		            convert_info.start_add = address;
		        }
                p_data[convert_info.msg_len++] = (uint8_t)(address & 0xff);  //最低位
                p_data[convert_info.msg_len++] = (uint8_t)((address/0x100) & 0xff);  //中间位
                p_data[convert_info.msg_len++] = (uint8_t)((address/0x10000) & 0xff);
                p_data[convert_info.msg_len++] = 0x01;
                p_data[convert_info.msg_len++] = 0x02;
                // p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+6];
                // p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+5];
                p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+7+(2*i)]; 
                p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+6+(2*i)];
                convert_info.end_add = address;
                convert_info.current++;
                address++;

                if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
                {
                    rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
                    if (rc != 0)
                    {
                        break;
                    }else{
                        rc = modbusTCPToIEC104(modbus_frame->slave, 0, p_data, 0, typeID);
                    }
                    convert_info.msg_len = 3;
                }
            }
			if (convert_info.current != 0)
			{
				rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
			}
			if(rc == 0)
			{
				rc = modbusTCPToIEC104(modbus_frame->slave, 0, p_data, 0, typeID);
			}
            
            break;
        }

        default:
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
    }
    
    return rc;
}



/**
 * @brief  协议兼容信息应答处理,此数据需要转换成相应104的地址,并对相应的位做映射处理
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t cmu_modbus_reply_user_protocol_compatible_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    user_protocol_compatible_info_t protocol_compatible;

    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d] slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    protocol_compatible.protocol_effective_version = PROTOCOL_EFFECTIVE_VERSION; //协议版本固定

    memcpy(data_buff, &protocol_compatible, sizeof(user_protocol_compatible_info_t));
    
    return 0; 
}

/**
 * @brief  集装箱系统信息应答处理,此数据需要转换成相应104的地址
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_admin_container_system_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t i = 0;
    int32_t rc = 0;
    uint16_t offset_addr = 0;
    uint16_t address = 0;
    uint8_t num = 0;
    int typeID = M_ME_NC_1;
    int len = 0;
    modbus_convert_info_t convert_info = {0};

    offset_addr = modbus_frame->address - ADMIN_CONTAINER_SYSTEM_ADDR_START;
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d] slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    convert_info.msg_len = 2;

    address = 0x432A + offset_addr;
    for (i = 0; i < modbus_frame->reg_num;)
    {
        if (address == 0x432F)
        {
            address = 0x4330;
        }
        else if (address >= 0x4335 && address <= 0x4346)
        {
            address = 0x4347;
        }

        if (modbus_frame->address + i >= MODBUS_A_PHASE_VOLTAGE_ADDR && modbus_frame->address + i <= MODBUS_C_PHASE_ACTIVE_POWER_ADDR)
        {
            i += 2;
        }
        else
        {
            i++;
        }

        IEC104_packag_address(&convert_info, address);
        address++;
        num++;

        if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
        {
            rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
            if (rc != 0)
            {
                return rc;
            }
        }
    }

    if (convert_info.current != 0)
    {
        rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
    }
    
    return rc;
}

/**
 * @brief  电池簇信息应答处理,数据需要转换成相应104的地址转发
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_admin_battery_cluster_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t i = 0;
    int32_t rc = 0;
    uint16_t offset_addr = 0;
    uint16_t address = 0;
    uint16_t in_battery_offset_addr = 0;
    uint16_t base_address = 0;
    uint16_t pack_num = 0;
    uint16_t pack_offset = 0;
    uint16_t pole_offset = 0;
    uint16_t offset = 0;
    int typeID = M_ME_NC_1;
    int len = 0;
    modbus_convert_info_t convert_info = {0};

    offset_addr = modbus_frame->address - ADMIN_BATTERY_CLUSTER_ADDR_START;
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d] slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    convert_info.msg_len = 2;

    base_address = IEC104_USER_BATTERY_CLUSTER_ADDR_START + (offset_addr / MODBUS_ADMIN_BATTERY_CLUSTER_INTERVAL)*IEC104_BATTERY_CLUSTER_INTERVAL;
    address = base_address + (offset_addr % MODBUS_ADMIN_BATTERY_CLUSTER_INTERVAL);
    convert_info.start_add = address;
    for (i = 0; i < modbus_frame->reg_num; i++)
    {
        in_battery_offset_addr = (offset_addr + i) % MODBUS_ADMIN_BATTERY_CLUSTER_INTERVAL;
        if (in_battery_offset_addr >= 0 && in_battery_offset_addr <= (MODBUS_ADMIN_PACK5_SOP_ADDR_END - ADMIN_BATTERY_CLUSTER_ADDR_START))
        {
            pack_offset = in_battery_offset_addr % MODBUS_ADMIN_PACK_INTERVAL;
            pack_num = in_battery_offset_addr / MODBUS_ADMIN_PACK_INTERVAL;
            address = base_address + pack_num*IEC104_PACK_INTERVAL + pack_offset + MODBUS_USER_PACK_INTERVAL;
        }
        else if (in_battery_offset_addr >= (MODBUS_ADMIN_PACK6_UC_ADDR_START - ADMIN_BATTERY_CLUSTER_ADDR_START) && 
                in_battery_offset_addr <= (MODBUS_ADMIN_PACK8_SOP_ADDR_END - ADMIN_BATTERY_CLUSTER_ADDR_START))
        {
            offset = in_battery_offset_addr - (MODBUS_ADMIN_PACK6_UC_ADDR_START - ADMIN_BATTERY_CLUSTER_ADDR_START);
            address = base_address + (IEC104_ADMIN_PACK6_UC_ADDR_START - IEC104_USER_BATTERY_CLUSTER_ADDR_START) + offset;
        }
        else
        {
            pole_offset = in_battery_offset_addr - (MODBUS_ADMIN_PACK6_POLE_TEMP_ADDR_START - ADMIN_BATTERY_CLUSTER_ADDR_START);
            address = base_address + (IEC104_ADMIN_PACK6_POLE_TEMP_ADDR_START - IEC104_USER_BATTERY_CLUSTER_ADDR_START) + pole_offset;
        }

        IEC104_packag_address(&convert_info, address);

        if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
        {
            rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
            if (rc != 0)
            {
                return rc;
            }
        }
    }

    if (convert_info.current != 0)
    {
        rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
    }
    
    return rc;
}

/**
 * @brief  集装箱故障信息应答处理,数据需要转换成相应104的地址转发
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_admin_container_fault_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t i = 0;
    uint16_t j = 0;
    int32_t rc = 0;
    uint16_t offset_addr = 0;
    uint16_t buff[256] = {0};
    uint16_t address = 0;
    int typeID = M_SP_NA_1;
    int num = 0;
    int len = 0;
    modbus_convert_info_t convert_info = {0};

    offset_addr = modbus_frame->address - ADMIN_CONTAINER_FAULT_ADDR_START;
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d] slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    convert_info.msg_len = 2;

    address = 0x101+offset_addr;
    convert_info.start_add = address;
    for (i = 0; i < modbus_frame->reg_num; i++)
    {
        num++;
        for (j = 0; j < 16; j++)
        {
            if (address >= IEC104_USER_LC_STATUS_ADDR_START && address <= IEC104_USER_LC_STATUS_ADDR_END)
            {
                address = IEC104_USER_LC_STATUS_ADDR_END + 1;
            } else if (address >= IEC104_USER_LC_WARN_ADDR_START && address <= IEC104_USER_LC_WARN_ADDR_END)
            {
                address = IEC104_USER_LC_WARN_ADDR_END + 1;
            } else if (address >= IEC104_USER_LC_FAULT_ADDR_START && address <= IEC104_USER_LC_FAULT_ADDR_END)
            {
                address = IEC104_USER_LC_FAULT_ADDR_END + 1;
            }

            IEC104_packag_address(&convert_info, address);
            address++;

            if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
            {
                rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, buff, NULL);
                if (rc != 0)
                {
                    return rc;
                }
                convert_u16_to_bit(num, buff, &data_buff[len]);
                len += num;
                num = 0;
            }
        }
    }

    if (convert_info.current != 0)
    {
        rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, buff, NULL);
        if (rc == 0)
        {
            convert_u16_to_bit(num, buff, &data_buff[len]);
        }
    }
    
    return rc;
}

/**
 * @brief  PCS故障信息应答处理,数据需要转换成相应104的地址转发
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_admin_pcs_fault_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t i = 0;
    int32_t rc = 0;
    uint16_t offset_addr = 0;
    uint16_t buff[256] = {0};
    uint16_t address = 0;
    int num = 0;
    int typeID = M_SP_NA_1;
    int len = 0;
    modbus_convert_info_t convert_info = {0};

    offset_addr = modbus_frame->address - ADMIN_PCS_FAULT_ADDR_START;
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d] slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    convert_info.msg_len = 2;

    address = 0x8C1+offset_addr;
    for (i = 0; i < modbus_frame->reg_num; i++)
    {
        IEC104_packag_address(&convert_info, address);
        address++;
        num++;

        if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
        {
            rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, buff, NULL);
            if (rc != 0)
            {
                return rc;
            }
            convert_u16_to_bit(num, buff, &data_buff[len]);
            len += num;
            num = 0;
        }
    }

    if (num != 0)
    {
        rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, buff, NULL);
        if (rc == 0)
        {
            convert_u16_to_bit(num, buff, &data_buff[len]);
        }
    }
    
    return rc;
}

/**
 * @brief  CMU定值参数应答处理,数据需要转换成相应104的地址转发
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_admin_cmu_param_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t i = 0;
    int32_t rc = 0;
    uint16_t offset_addr = 0;
    uint16_t address = 0;
    int typeID = 0;
    int len = 0;
    modbus_convert_info_t convert_info = {0};
    uint8_t *p_data = (uint8_t *)convert_info.data;

    offset_addr = modbus_frame->address - ADMIN_CMU_CONSTANT_PARAM_ADDR_START;
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d] slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    p_data[0] = 1;
    p_data[1] = 0;
    convert_info.msg_len = 2;

    address = 0x8701+offset_addr;
	convert_info.current = 0;
	convert_info.num = modbus_frame->reg_num;

    switch (modbus_frame->function)
    {
        case MODBUS_FC_READ_HOLDING_REGISTERS:
        case MODBUS_FC_READ_INPUT_REGISTERS: 
        {
            typeID = P_SC_RD_1;
			
            for (i = 0; i < convert_info.num; i++)
            {
                if (convert_info.current == 0 )
		        {
		            convert_info.start_add = address;
		        }
		        IEC104_packag_address(&convert_info, address);
		        address++;

		        if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
		        {
		            rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
		            if (rc != 0)
		            {
		                return rc;
		            }
		            
		        }
            }

            if (convert_info.current != 0)
            {
                rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
            }
            break;
        }
        case MODBUS_FC_WRITE_SINGLE_REGISTER:
        {
            typeID = P_SC_WT_1;
            p_data[convert_info.msg_len++] = 0x80;
            p_data[convert_info.msg_len++] = (uint8_t)(address & 0xff);  //最低位
            p_data[convert_info.msg_len++] = (uint8_t)((address/0x100) & 0xff);  //中间位
            p_data[convert_info.msg_len++] = (uint8_t)((address/0x10000) & 0xff);
            p_data[convert_info.msg_len++] = 0x01;
            p_data[convert_info.msg_len++] = 0x02;
            p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+4];
            p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+3];
            address++;
            rc = modbusTCPToIEC104(modbus_frame->slave, modbus_frame->reg_num, p_data, convert_info.msg_len, typeID);//参数预置
            if(rc == 0)
            {
            	rc = modbusTCPToIEC104(modbus_frame->slave, 0, p_data, 0, typeID);//参数固化
            }
            
            break;
        }
        case MODBUS_FC_WRITE_MULTIPLE_REGISTERS:
        {
            typeID = P_SC_WT_1;
            p_data[convert_info.msg_len++] = 0x80;
            for (i = 0; i < convert_info.num; i++)
            {
            	if (convert_info.current == 0 )
		        {
		            convert_info.start_add = address;
		        }
                p_data[convert_info.msg_len++] = (uint8_t)(address & 0xff);  //最低位
                p_data[convert_info.msg_len++] = (uint8_t)((address/0x100) & 0xff);  //中间位
                p_data[convert_info.msg_len++] = (uint8_t)((address/0x10000) & 0xff);
                p_data[convert_info.msg_len++] = 0x01;
                p_data[convert_info.msg_len++] = 0x02;
                // p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+6];
                // p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+5];
                p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+7+(2*i)]; 
                p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+6+(2*i)];
                convert_info.end_add = address;
                convert_info.current++;
                address++;

                if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
                {
                    rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
                    if (rc != 0)
                    {
                        break;
                    }else{
                        rc = modbusTCPToIEC104(modbus_frame->slave, 0, p_data, 0, typeID);
                    }
                    convert_info.msg_len = 3;
                }
            }
			if (convert_info.current != 0)
			{
				rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
			}
            if(rc == 0)
            {
            	rc = modbusTCPToIEC104(modbus_frame->slave, 0, p_data, 0, typeID);
            }
            
            break;
        }

        default:
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
    }
    
    return rc;
}


/**
 * @brief  CMU定值参数应答处理,数据需要转换成相应104的地址转发
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_user_remote_adjust( modbus_frame_t *modbus_frame, uint16_t *data_buff )
{
    uint16_t i = 0;
    int32_t rc = 0;
    uint16_t offset_addr = 0;
    uint16_t address = 0;
    int typeID = 0;
    int len = 0;
    modbus_convert_info_t convert_info = {0};
    uint8_t *p_data = (uint8_t *)convert_info.data;

    #define IEC104_ADJ_ENG_STROE_CAB_SETTING_ADDR           0x8701
    #define IEC104_ADJ_CHARGE_SOC_MAX_ADDR                  ( IEC104_ADJ_ENG_STROE_CAB_SETTING_ADDR + 35 - 1 )
    #define IEC104_ADJ_CHARGE_SOC_MIN_ADDR                  ( IEC104_ADJ_ENG_STROE_CAB_SETTING_ADDR + 36 - 1 )

    // offset_addr = modbus_frame->address - ADMIN_CONTAINER_CONSTANT_PARAM_ADDR_START;
    offset_addr = modbus_frame->address - MB_ADJ_USER_ADDR_START;
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d] slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    p_data[0] = 1;
    p_data[1] = 0;
    convert_info.msg_len = 2;

    // address = 0x8701+offset_addr;
    address = IEC104_ADJ_CHARGE_SOC_MAX_ADDR + offset_addr;
    convert_info.start_add = address;

    switch (modbus_frame->function)
    {
        case MODBUS_FC_READ_HOLDING_REGISTERS:
        case MODBUS_FC_READ_INPUT_REGISTERS: 
        {
            typeID = P_SC_RD_1;
            for (i = 0; i < modbus_frame->reg_num; i++)
            {
                IEC104_packag_address(&convert_info, address);
                address++;

                if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
                {
                    rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
                    if (rc != 0)
                    {
                        break;
                    }else{
                        rc = modbusTCPToIEC104(modbus_frame->slave, 0, p_data, 0, typeID);
                    }
                    MODBUS_DEBUG_LOG(" M1 len:%d, data:%04X, %04X\r\n", len , data_buff[0], data_buff[1]);
                }
            }

            if (convert_info.current != 0)
            {
                rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
                MODBUS_DEBUG_LOG(" M2 start addr:%d(0x%04X) len:%d, data:%04X, %04X\r\n", convert_info.start_add, convert_info.start_add, \
                                         len , data_buff[0], data_buff[1]);
            }
            break;
        }
        case MODBUS_FC_WRITE_SINGLE_REGISTER:
        {
            typeID = P_SC_WT_1;
            p_data[convert_info.msg_len++] = 0x80;
            p_data[convert_info.msg_len++] = (uint8_t)(address & 0xff);  //最低位
            p_data[convert_info.msg_len++] = (uint8_t)((address/0x100) & 0xff);  //中间位
            p_data[convert_info.msg_len++] = (uint8_t)((address/0x10000) & 0xff);
            p_data[convert_info.msg_len++] = 0x01;
            p_data[convert_info.msg_len++] = 0x02;
            p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+4];
            p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+3];
            address++;
            rc = modbusTCPToIEC104(modbus_frame->slave, modbus_frame->reg_num, p_data, convert_info.msg_len, typeID);
            modbusTCPToIEC104(modbus_frame->slave, 0, p_data, 0, typeID);
            break;
        }
        case MODBUS_FC_WRITE_MULTIPLE_REGISTERS:
        {
            typeID = P_SC_WT_1;
            p_data[convert_info.msg_len++] = 0x80;
            for (i = 0; i < modbus_frame->reg_num; i++)
            {
                p_data[convert_info.msg_len++] = (uint8_t)(address & 0xff);  //最低位
                p_data[convert_info.msg_len++] = (uint8_t)((address/0x100) & 0xff);  //中间位
                p_data[convert_info.msg_len++] = (uint8_t)((address/0x10000) & 0xff);
                p_data[convert_info.msg_len++] = 0x01;
                p_data[convert_info.msg_len++] = 0x02;
                // p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+6];
                // p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+5];
                p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+7+(2*i)]; 
                p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+6+(2*i)];
                convert_info.end_add = address;
                convert_info.current++;
                address++;

                if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
                {
                    rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
                    if (rc != 0)
                    {
                        break;
                    }else{
                        rc = modbusTCPToIEC104(modbus_frame->slave, 0, p_data, 0, typeID);
                    }
                    convert_info.msg_len = 3;
                }
            }
			if (convert_info.current != 0)
			{
				rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
			}
            
            modbusTCPToIEC104(modbus_frame->slave, 0, p_data, 0, typeID);
            break;
        }

        default:
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
    }
    
    return rc;
}

/**
 * @brief  集装箱定值参数应答处理,数据需要转换成相应104的地址转发
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_use_container_param_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t i = 0;
    int32_t rc = 0;
    uint16_t offset_addr = 0;
    uint8_t data[MODBUS_MAX_MESSAGE_LENGTH] = {0};
    uint16_t address = 0;
    uint16_t start_add = 0;
    uint16_t typeID = 0;
    uint16_t msg_len = 0;

    offset_addr = modbus_frame->address - ADMIN_CONTAINER_CONSTANT_PARAM_ADDR_START;
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d] slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    data[0] = 1;
    data[1] = 0;

    address = 0x8701+offset_addr;
    start_add = address;

    switch (modbus_frame->function)
    {
        case MODBUS_FC_READ_HOLDING_REGISTERS:
        case MODBUS_FC_READ_INPUT_REGISTERS: 
        {
            typeID = P_SC_RD_1;
            msg_len = modbus_frame->reg_num*3+2;
            for (i = 0; i < modbus_frame->reg_num; i++)
            {
                data[2+i*3] = (uint8_t)(address & 0xff);  //最低位
                data[2+i*3+1] = (uint8_t)((address/0x100) & 0xff);  //中间位
                data[2+i*3+2] = (uint8_t)((address/0x10000) & 0xff);
                address++;
            }
            cmu_modbus_info_set(modbus_frame->reg_num, start_add, address - 1);
            modbusTCPToIEC104(modbus_frame->slave, modbus_frame->reg_num, data, msg_len, typeID);
            rc = wait_for_iec104Data(data_buff);
            break;
        }
        case MODBUS_FC_WRITE_SINGLE_REGISTER:
        {
            typeID = P_SC_WT_1;
            msg_len = modbus_frame->reg_num*7+3;
            data[2] = 0x80;
            data[3+i*7] = (uint8_t)(address & 0xff);  //最低位
            data[3+i*7+1] = (uint8_t)((address/0x100) & 0xff);  //中间位
            data[3+i*7+2] = (uint8_t)((address/0x10000) & 0xff);
            data[3+i*7+3] = 0x01;
            data[3+i*7+4] = 0x02;
            data[3+i*7+5] = modbus_frame->req[modbus_frame->offset+4];
            data[3+i*7+6] = modbus_frame->req[modbus_frame->offset+3];
            address++;
            rc = modbusTCPToIEC104(modbus_frame->slave, modbus_frame->reg_num, data, modbus_frame->reg_num*7+3, typeID);
            modbusTCPToIEC104(modbus_frame->slave, 0, data, 0, typeID);
            break;
        }
        case MODBUS_FC_WRITE_MULTIPLE_REGISTERS:
        {
            typeID = P_SC_WT_1;
            msg_len = modbus_frame->reg_num*7+3;
            data[2] = 0x80;
            for (i = 0; i < modbus_frame->reg_num; i++)
            {
                data[3+i*7] = (uint8_t)(address & 0xff);  //最低位
                data[3+i*7+1] = (uint8_t)((address/0x100) & 0xff);  //中间位
                data[3+i*7+2] = (uint8_t)((address/0x10000) & 0xff);
                data[3+i*7+3] = 0x01;
                data[3+i*7+4] = 0x02;
                // data[3+i*7+5] = modbus_frame->req[modbus_frame->offset+6];
                // data[3+i*7+6] = modbus_frame->req[modbus_frame->offset+5];
                data[3+i*7+5] = modbus_frame->req[modbus_frame->offset+7+(2*i)];
                data[3+i*7+6] = modbus_frame->req[modbus_frame->offset+6+(2*i)];
                address++;
            }
            rc = modbusTCPToIEC104(modbus_frame->slave, modbus_frame->reg_num, data, modbus_frame->reg_num*7+3, typeID);
            modbusTCPToIEC104(modbus_frame->slave, 0, data, 0, typeID);
            break;
        }

        default:
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
    }
    
    return rc;
}

/**
 * @brief  集装箱定值参数应答处理,数据需要转换成相应104的地址转发
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_admin_container_param_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t i = 0;
    int32_t rc = 0;
    uint16_t offset_addr = 0;
    uint16_t address = 0;
    uint16_t typeID = 0;
	int len = 0;
	modbus_convert_info_t convert_info = {0};
	uint8_t *p_data = (uint8_t *)convert_info.data;
	p_data[0] = 1;
    p_data[1] = 0;
    convert_info.msg_len = 2;

    offset_addr = modbus_frame->address - ADMIN_CONTAINER_CONSTANT_PARAM_ADDR_START;
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d] slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    address = 0x8741+offset_addr;
	convert_info.current = 0;
	convert_info.num = modbus_frame->reg_num;

    switch (modbus_frame->function)
    {
        case MODBUS_FC_READ_HOLDING_REGISTERS:
        case MODBUS_FC_READ_INPUT_REGISTERS: 
        {
			typeID = P_SC_RD_1;//P_SC_RD_1
		    
		    for (i = 0; i < convert_info.num; i++)
            {
                if (convert_info.current == 0 )
		        {
		            convert_info.start_add = address;
		        }
		        IEC104_packag_address(&convert_info, address);
		        address++;

		        if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
		        {
		            rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
		            if (rc != 0)
		            {
		                return rc;
		            }
		            
		        }
            }

		    modbus_convert_info_print( &convert_info );
		    if (convert_info.current != 0)
		    {
		        rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
		    }
            break;
        }
        case MODBUS_FC_WRITE_SINGLE_REGISTER:
        {
            typeID = P_SC_WT_1;
            p_data[convert_info.msg_len++] = 0x80;
            p_data[convert_info.msg_len++] = (uint8_t)(address & 0xff);  //最低位
            p_data[convert_info.msg_len++] = (uint8_t)((address/0x100) & 0xff);  //中间位
            p_data[convert_info.msg_len++] = (uint8_t)((address/0x10000) & 0xff);
            p_data[convert_info.msg_len++] = 0x01;
            p_data[convert_info.msg_len++] = 0x02;
            p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+4];
            p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+3];
            address++;
            rc = modbusTCPToIEC104(modbus_frame->slave, modbus_frame->reg_num, p_data, convert_info.msg_len, typeID);//参数预置
            if(rc == 0)
            {
            	rc = modbusTCPToIEC104(modbus_frame->slave, 0, p_data, 0, typeID);//参数固化
            }
            
            break;
        }
        case MODBUS_FC_WRITE_MULTIPLE_REGISTERS:
        {
            typeID = P_SC_WT_1;
            p_data[convert_info.msg_len++] = 0x80;
            for (i = 0; i < convert_info.num; i++)
            {
            	if (convert_info.current == 0 )
		        {
		            convert_info.start_add = address;
		        }
                p_data[convert_info.msg_len++] = (uint8_t)(address & 0xff);  //最低位
                p_data[convert_info.msg_len++] = (uint8_t)((address/0x100) & 0xff);  //中间位
                p_data[convert_info.msg_len++] = (uint8_t)((address/0x10000) & 0xff);
                p_data[convert_info.msg_len++] = 0x01;
                p_data[convert_info.msg_len++] = 0x02;
                // p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+6];
                // p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+5];
                p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+7+(2*i)]; 
                p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+6+(2*i)];
                convert_info.end_add = address;
                convert_info.current++;
                address++;

                if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
                {
                    rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
                    if (rc != 0)
                    {
                        break;
                    }else{
                        rc = modbusTCPToIEC104(modbus_frame->slave, 0, p_data, 0, typeID);
                    }
                    convert_info.msg_len = 3;
                }
            }
			if (convert_info.current != 0)
			{
				rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
			}
            if(rc == 0)
            {
            	rc = modbusTCPToIEC104(modbus_frame->slave, 0, p_data, 0, typeID);
            }
            
            break;
        }

        default:
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
    }
    
    return rc;
}

int32_t modbus_reply_safety_param_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t i = 0;
    int32_t rc = 0;
    uint16_t offset_addr = 0;
    uint16_t address = 0;
    uint16_t typeID = 0;
	int len = 0;
	modbus_convert_info_t convert_info = {0};
	uint8_t *p_data = (uint8_t *)convert_info.data;
	p_data[0] = 1;
    p_data[1] = 0;
    convert_info.msg_len = 2;

    offset_addr = modbus_frame->address - IEC104_SAFETY_PARAM_ADDR_START;
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d] slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    address = IEC104_SAFETY_PARAM_ADDR_START + offset_addr;
	convert_info.current = 0;
	convert_info.num = modbus_frame->reg_num;

    switch (modbus_frame->function)
    {
        case MODBUS_FC_READ_HOLDING_REGISTERS:
        case MODBUS_FC_READ_INPUT_REGISTERS: 
        {
			typeID = P_SC_RD_1;//P_SC_RD_1
		    
		    for (i = 0; i < convert_info.num; i++)
            {
                if (convert_info.current == 0 )
		        {
		            convert_info.start_add = address;
		        }
		        IEC104_packag_address(&convert_info, address);
		        address++;

		        if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
		        {
		            rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
		            if (rc != 0)
		            {
		                return rc;
		            }
		            
		        }
            }

		    modbus_convert_info_print( &convert_info );
		    if (convert_info.current != 0)
		    {
		        rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
		    }
            break;
        }
        case MODBUS_FC_WRITE_SINGLE_REGISTER:
        {
            typeID = P_SC_WT_1;
            p_data[convert_info.msg_len++] = 0x80;
            p_data[convert_info.msg_len++] = (uint8_t)(address & 0xff);  //最低位
            p_data[convert_info.msg_len++] = (uint8_t)((address/0x100) & 0xff);  //中间位
            p_data[convert_info.msg_len++] = (uint8_t)((address/0x10000) & 0xff);
            p_data[convert_info.msg_len++] = 0x01;
            p_data[convert_info.msg_len++] = 0x02;
            p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+4];
            p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+3];
            address++;
            printf( "modbus_frame->reg_num:%d\r\n", modbus_frame->reg_num );
            
            int32_t modbusTCPToIEC104_2(uint16_t slave, uint16_t reg_num, uint8_t *data, uint8_t len, IEC60870_5_TypeID typeid);

            rc = modbusTCPToIEC104_2(modbus_frame->slave, modbus_frame->reg_num, p_data, convert_info.msg_len, typeID);//参数预置
            // rc = modbusTCPToIEC104(modbus_frame->slave, modbus_frame->reg_num, p_data, convert_info.msg_len, typeID);//参数预置
            if(rc == 0)
            {
            	rc = modbusTCPToIEC104(modbus_frame->slave, 0, p_data, 0, typeID);//参数固化
            }
            
            break;
        }
        case MODBUS_FC_WRITE_MULTIPLE_REGISTERS:
        {
            typeID = P_SC_WT_1;
            p_data[convert_info.msg_len++] = 0x80;
            for (i = 0; i < convert_info.num; i++)
            {
            	if (convert_info.current == 0 )
		        {
		            convert_info.start_add = address;
		        }
                p_data[convert_info.msg_len++] = (uint8_t)(address & 0xff);  //最低位
                p_data[convert_info.msg_len++] = (uint8_t)((address/0x100) & 0xff);  //中间位
                p_data[convert_info.msg_len++] = (uint8_t)((address/0x10000) & 0xff);
                p_data[convert_info.msg_len++] = 0x01;
                p_data[convert_info.msg_len++] = 0x02;
                p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+7+(2*i)]; 
                p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+6+(2*i)];

                convert_info.end_add = address;
                convert_info.current++;
                address++;

                if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
                {
                    rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
                    if (rc != 0)
                    {
                        break;
                    }else{
                        rc = modbusTCPToIEC104(modbus_frame->slave, 0, p_data, 0, typeID);
                    }
                    convert_info.msg_len = 3;
                }
            }
			if (convert_info.current != 0)
			{
				rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
			}
            if(rc == 0)
            {
            	rc = modbusTCPToIEC104(modbus_frame->slave, 0, p_data, 0, typeID);
            }
            
            break;
        }

        default:
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
    }
    
    return rc;
}

// int32_t modbus_reply_safety_param_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
// {
//     addr_info_t iec_safety_info = { .base_addr = IEC104_SAFETY_PARAM_ADDR_START,
//                                      .end_addr  = IEC104_SAFETY_PARAM_ADDR_END,
//                                    };
//     addr_info_t mb_safety_info = { .base_addr = MB_MEAS_SAFETY_PARAM_ADDR_START,
//                                     .end_addr  = MB_MEAS_SAFETY_PARAM_ADDR_END,
//                                   };
//     log_i("%s", __FUNCTION__);

//     return iec104_raw_dat_to_modbus_dat( &iec_safety_info, &mb_safety_info, modbus_frame, data_buff, P_SC_RD_1 );
// }

/**
 * @brief  电池簇定值参数应答处理,数据需要转换成相应104的地址转发
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_admin_battery_param_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t i = 0;
    int32_t rc = 0;
    uint16_t offset_addr = 0;
    uint16_t address = 0;
    uint16_t typeID = 0;
	int len = 0;
	modbus_convert_info_t convert_info = {0};
	uint8_t *p_data = (uint8_t *)convert_info.data;
	p_data[0] = 1;
    p_data[1] = 0;
    convert_info.msg_len = 2;

    offset_addr = modbus_frame->address - ADMIN_BATTERY_CONSTANT_PARAM_ADDR_START;
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d] slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);


    address = 0x8801 + offset_addr;
	convert_info.current = 0;
	convert_info.num = modbus_frame->reg_num;

    switch (modbus_frame->function)
    {
        case MODBUS_FC_READ_HOLDING_REGISTERS:
        case MODBUS_FC_READ_INPUT_REGISTERS: 
        {
            typeID = P_SC_RD_1;
			
		    for (i = 0; i < convert_info.num; i++)
            {
                if (convert_info.current == 0 )
		        {
		            convert_info.start_add = address;
		        }
		        IEC104_packag_address(&convert_info, address);
		        address++;

		        if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
		        {
		            rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
		            if (rc != 0)
		            {
		                return rc;
		            }
		            
		        }
            }

            if (convert_info.current != 0)
            {
                rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
            }
            break;
        }
        case MODBUS_FC_WRITE_SINGLE_REGISTER:
        {
            typeID = P_SC_WT_1;
            p_data[convert_info.msg_len++] = 0x80;
            p_data[convert_info.msg_len++] = (uint8_t)(address & 0xff);  //最低位
            p_data[convert_info.msg_len++] = (uint8_t)((address/0x100) & 0xff);  //中间位
            p_data[convert_info.msg_len++] = (uint8_t)((address/0x10000) & 0xff);
            p_data[convert_info.msg_len++] = 0x01;
            p_data[convert_info.msg_len++] = 0x02;
            p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+4];
            p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+3];
            address++;
            rc = modbusTCPToIEC104(modbus_frame->slave, modbus_frame->reg_num, p_data, convert_info.msg_len, typeID);//参数预置
            if(rc == 0)
            {
            	modbusTCPToIEC104(modbus_frame->slave, 0, p_data, 0, typeID);//参数固化
            }
            
            break;
        }
        case MODBUS_FC_WRITE_MULTIPLE_REGISTERS:
        {
           typeID = P_SC_WT_1;
            p_data[convert_info.msg_len++] = 0x80;
            for (i = 0; i < convert_info.num; i++)
            {
            	if (convert_info.current == 0 )
		        {
		            convert_info.start_add = address;
		        }
                p_data[convert_info.msg_len++] = (uint8_t)(address & 0xff);  //最低位
                p_data[convert_info.msg_len++] = (uint8_t)((address/0x100) & 0xff);  //中间位
                p_data[convert_info.msg_len++] = (uint8_t)((address/0x10000) & 0xff);
                p_data[convert_info.msg_len++] = 0x01;
                p_data[convert_info.msg_len++] = 0x02;
                // p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+6];
                // p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+5];
                p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+7+(2*i)]; 
                p_data[convert_info.msg_len++] = modbus_frame->req[modbus_frame->offset+6+(2*i)];
                convert_info.end_add = address;
                convert_info.current++;
                address++;

                if (convert_info.msg_len >= IEC104_MSG_MAX_LEN)
                {
                    rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
                    if (rc != 0)
                    {
                        break;
                    }else{
                        rc = modbusTCPToIEC104(modbus_frame->slave, 0, p_data, 0, typeID);
                    }
                    convert_info.msg_len = 3;
                }
            }
			if (convert_info.current != 0)
			{
				rc = send_IEC104_msg(modbus_frame->slave, typeID, &convert_info, &data_buff[len], &len);
			}
            if(rc == 0)
            {
            	rc = modbusTCPToIEC104(modbus_frame->slave, 0, p_data, 0, typeID);
            }
            
            break;
        }

        default:
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
    }
    
    return rc;
}

/**
 * @brief  PCS定值参数应答处理,数据需要转换成相应104的地址转发
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_admin_pcs_param_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t i = 0;
    int32_t rc = 0;
    uint16_t offset_addr = 0;
    uint8_t data[MODBUS_MAX_MESSAGE_LENGTH] = {0};
    uint16_t address = 0;
    uint16_t start_add = 0;
    uint16_t typeID = 0;
    uint16_t msg_len = 0;

    offset_addr = modbus_frame->address - ADMIN_PCS_CONSTANT_PARAM_ADDR_START;
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d] slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    data[0] = 1;
    data[1] = 0;

    address = 0x8901 + offset_addr;
    start_add = address;

    switch (modbus_frame->function)
    {
        case MODBUS_FC_READ_HOLDING_REGISTERS:
        case MODBUS_FC_READ_INPUT_REGISTERS: 
        {
            typeID = P_SC_RD_1;
            msg_len = modbus_frame->reg_num*3+2;
            for (i = 0; i < modbus_frame->reg_num; i++)
            {
                data[2+i*3] = (uint8_t)(address & 0xff);  //最低位
                data[2+i*3+1] = (uint8_t)((address/0x100) & 0xff);  //中间位
                data[2+i*3+2] = (uint8_t)((address/0x10000) & 0xff);
                address++;
            }
            cmu_modbus_info_set(modbus_frame->reg_num, start_add, address - 1);
            modbusTCPToIEC104(modbus_frame->slave, modbus_frame->reg_num, data, msg_len, typeID);
            rc = wait_for_iec104Data(data_buff);
            break;
        }
        case MODBUS_FC_WRITE_SINGLE_REGISTER:
        {
            typeID = P_SC_WT_1;
            msg_len = modbus_frame->reg_num*7+3;
            data[2] = 0x80;
            data[3+i*7] = (uint8_t)(address & 0xff);  //最低位
            data[3+i*7+1] = (uint8_t)((address/0x100) & 0xff);  //中间位
            data[3+i*7+2] = (uint8_t)((address/0x10000) & 0xff);
            data[3+i*7+3] = 0x01;
            data[3+i*7+4] = 0x02;
            data[3+i*7+5] = modbus_frame->req[modbus_frame->offset+4];
            data[3+i*7+6] = modbus_frame->req[modbus_frame->offset+3];
            address++;
            modbusTCPToIEC104(modbus_frame->slave, 0, data, 0, typeID);
            break;
        }
        case MODBUS_FC_WRITE_MULTIPLE_REGISTERS:
        {
            typeID = P_SC_WT_1;
            msg_len = modbus_frame->reg_num*7+3;
            data[2] = 0x80;
            for (i = 0; i < modbus_frame->reg_num; i++)
            {
                data[3+i*7] = (uint8_t)(address & 0xff);  //最低位
                data[3+i*7+1] = (uint8_t)((address/0x100) & 0xff);  //中间位
                data[3+i*7+2] = (uint8_t)((address/0x10000) & 0xff);
                data[3+i*7+3] = 0x01;
                data[3+i*7+4] = 0x02;
                // data[3+i*7+5] = modbus_frame->req[modbus_frame->offset+6];
                // data[3+i*7+6] = modbus_frame->req[modbus_frame->offset+5];
                data[3+i*7+5] = modbus_frame->req[modbus_frame->offset+7+(2*i)];
                data[3+i*7+6] = modbus_frame->req[modbus_frame->offset+6+(2*i)];
                
                address++;
            }
            modbusTCPToIEC104(modbus_frame->slave, 0, data, 0, typeID);
            break;
        }

        default:
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
    }
    
    return rc;
}

/**
 * @brief  CMU遥控应答处理,数据需要转换成相应104的地址转发
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_admin_cmu_remote_ctrl_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    int32_t rc = 0;
    uint16_t offset_addr = 0;
    uint8_t data[MODBUS_MAX_MESSAGE_LENGTH] = {0};
    uint16_t address = 0;
	uint16_t value = ((modbus_frame->req[modbus_frame->offset + 3]<<8)&0xff00)|((modbus_frame->req[modbus_frame->offset + 4]<<0)&0x00ff);
    offset_addr = modbus_frame->address - ADMIN_CMU_REMOTE_CONTROL_ADDR_START;
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d] slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    //data[0] = 1;
    //data[1] = 0;    
    
    address = 0x6011 + offset_addr;

    switch (modbus_frame->function)
    {
        case MODBUS_FC_WRITE_SINGLE_REGISTER:
        {
        	#if 0
            data[2+i*3] = (uint8_t)(address & 0xff);  //最低位
            data[2+i*3+1] = (uint8_t)((address/0x100) & 0xff);  //中间位
            data[2+i*3+2] = (uint8_t)((address/0x10000) & 0xff);
            data[2+i*3+3] = modbus_frame->req[modbus_frame->offset+4];
			#endif
			data[0] = (uint8_t)(address & 0xff);  //最低位
            data[1] = (uint8_t)((address/0x100) & 0xff);  //中间位
            data[2] = (uint8_t)((address/0x10000) & 0xff);
			data[3] &= ~(1 << 7);//遥控执行;
			
			if(0 == value)
			{
				data[3] &= ~(1 << 0);//0;
			}
			else
			{
				data[3] |= 1 << 0;//1;
			}
            address++;
            break;
        }

        default:
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
    }

    //modbusTCPToIEC104(modbus_frame->slave, modbus_frame->reg_num, data, modbus_frame->reg_num*4+2, C_SC_NA_1);
    rc = modbusTCPToIEC104(modbus_frame->slave, 1, data, 4, C_SC_NA_1);
    return rc;
}

/**
 * @brief  电池簇遥控应答处理,数据需要转换成相应104的地址转发
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_admin_battery_remote_ctrl_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    int32_t rc = 0;
    uint16_t offset_addr = 0;
    uint8_t data[MODBUS_MAX_MESSAGE_LENGTH] = {0};
    uint16_t address = 0;
	uint16_t value = ((modbus_frame->req[modbus_frame->offset + 3]<<8)&0xff00)|((modbus_frame->req[modbus_frame->offset + 4]<<0)&0x00ff);

    offset_addr = modbus_frame->address - ADMIN_BATTERY_REMOTE_CONTROL_ADDR_START;
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d] slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    //data[0] = 1;
    //data[1] = 0;    

    address = 0x6021 + offset_addr;

    switch (modbus_frame->function)
    {
        case MODBUS_FC_WRITE_SINGLE_REGISTER:
        {
        	#if 0
            data[2+i*3] = (uint8_t)(address & 0xff);  //最低位
            data[2+i*3+1] = (uint8_t)((address/0x100) & 0xff);  //中间位
            data[2+i*3+2] = (uint8_t)((address/0x10000) & 0xff);
            data[2+i*3+3] = modbus_frame->req[modbus_frame->offset+4];
            address++;
			#endif
			data[0] = (uint8_t)(address & 0xff);  //最低位
            data[1] = (uint8_t)((address/0x100) & 0xff);  //中间位
            data[2] = (uint8_t)((address/0x10000) & 0xff);
			data[3] &= ~(1 << 7);//遥控执行;
			
			if(0 == value)
			{
				data[3] &= ~(1 << 0);//0;
			}
			else
			{
				data[3] |= 1 << 0;//1;
			}
            break;
        }

        default:
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
    }

    //modbusTCPToIEC104(modbus_frame->slave, modbus_frame->reg_num, data, modbus_frame->reg_num*4+2, C_SC_NA_1);
    rc = modbusTCPToIEC104(modbus_frame->slave, 1, data, 4, C_SC_NA_1);
    return rc;
}

/**
 * @brief  PCS模块遥控应答处理,数据需要转换成相应104的地址转发
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_admin_pcs_remote_ctrl_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    int32_t rc = 0;
    uint16_t offset_addr = 0;
    uint8_t data[MODBUS_MAX_MESSAGE_LENGTH] = {0};
    uint16_t address = 0;
	uint16_t value = ((modbus_frame->req[modbus_frame->offset + 3]<<8)&0xff00)|((modbus_frame->req[modbus_frame->offset + 4]<<0)&0x00ff);

    offset_addr = modbus_frame->address - ADMIN_PCS_REMOTE_CONTROL_ADDR_START;
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d] slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    //data[0] = 1;
    //data[1] = 0;    

    address = 0x6071 + offset_addr;

    switch (modbus_frame->function)
    {
        case MODBUS_FC_WRITE_SINGLE_REGISTER:
        {
        	#if 0
            data[2+i*3] = (uint8_t)(address & 0xff);  //最低位
            data[2+i*3+1] = (uint8_t)((address/0x100) & 0xff);  //中间位
            data[2+i*3+2] = (uint8_t)((address/0x10000) & 0xff);
            data[2+i*3+3] = modbus_frame->req[modbus_frame->offset+4];
            address++;
			#endif
			data[0] = (uint8_t)(address & 0xff);  //最低位
            data[1] = (uint8_t)((address/0x100) & 0xff);  //中间位
            data[2] = (uint8_t)((address/0x10000) & 0xff);
			data[3] &= ~(1 << 7);//遥控执行;
			
			if(0 == value)
			{
				data[3] &= ~(1 << 0);//0;
			}
			else
			{
				data[3] |= 1 << 0;//1;
			}
            break;
        }

        default:
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
    }

    //modbusTCPToIEC104(modbus_frame->slave, modbus_frame->reg_num, data, modbus_frame->reg_num*4+2, C_SC_NA_1);
    rc = modbusTCPToIEC104(modbus_frame->slave, 1, data, 4, C_SC_NA_1);
    return rc;
}



/**
 * @brief  CMU数据读取总入口,函数里面对地址进行区分（依据协议点表大类分），再调用相关处理函数，
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t cmu_modbus_reply_read(modbus_t *ctx, modbus_frame_t *modbus_frame)
{
    uint16_t i;
    uint16_t end_addr = 0;
    uint8_t rsp[MODBUS_MAX_MESSAGE_LENGTH] = {0};
    uint8_t rsp_length = 0;
    sft_t sft;
    uint16_t data_buff[MODBUS_MAX_MESSAGE_LENGTH] = {0};
    int32_t rc = MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;

    sft.slave = modbus_frame->slave;
    sft.function = modbus_frame->function;
    sft.t_id = ctx->backend->prepare_response_tid(modbus_frame->req, (int *)&(modbus_frame->req_length));

    if (modbus_frame->reg_num < 1 || MODBUS_MAX_READ_REGISTERS < modbus_frame->reg_num) 
    {
        return modbus_reply_exception(ctx, modbus_frame->req, rc);
    }

    end_addr = modbus_frame->address + modbus_frame->reg_num -1;
    if ((modbus_frame->address >= USER_DEVICE_SYSTEM_ADDR_START) && (end_addr <= USER_DEVICE_SYSTEM_ADDR_END))
    {
        rc = modbus_reply_user_device_system_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= USER_CMU_SYSTEM_ADDR_START) && (end_addr <= USER_CMU_SYSTEM_ADDR_END))
    {
        rc = modbus_reply_user_cmu_system_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= USER_CONTAINER_SYSTEM_ADDR_START) && (end_addr <= USER_CONTAINER_SYSTEM_ADDR_END))
    {
        rc = modbus_reply_user_container_system_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= USER_BATTERY_CLUSTER_ADDR_START) && (end_addr <= USER_BATTERY_CLUSTER_ADDR_END))
    {
        // rc = modbus_reply_user_battery_cluster_info(modbus_frame, data_buff);
        rc = modbus_reply_user_battery_cluster_info2(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= USER_CONTAINER_FAULT_ADDR_START) && (end_addr <= USER_CONTAINER_FAULT_ADDR_END))
    {
        rc = modbus_reply_user_container_fault_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= USER_BATTERY_FAULT_ADDR_START) && (end_addr <= USER_BATTERY_FAULT_ADDR_END))
    {
        rc = modbus_reply_user_battery_fault_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= USER_PCS_FAULT_ADDR_START) && (end_addr <= USER_PCS_FAULT_ADDR_END))
    {
        rc = modbus_reply_user_pcs_fault_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= MB_MEAS_USER_PCS_PARAM_ADDR_START) && (end_addr <= MB_MEAS_USER_PCS_PARAM_ADDR_END))
    {
        rc = modbus_reply_user_pcs_param_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= MB_MEAS_SAFETY_PARAM_ADDR_START) && (end_addr <= MB_MEAS_SAFETY_PARAM_ADDR_END))
    {
        rc = modbus_reply_safety_param_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= MB_MEAS_USER_PCS_DEV_INFO_ADDR_START) && (end_addr <= MB_MEAS_USER_PCS_DEV_INFO_ADDR_END))
    {
        rc = modbus_reply_user_pcs_dev_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= MB_MEAS_USER_PCS_POWER_DATA_ADDR_START) && (end_addr <= MB_MEAS_USER_PCS_POWER_DATA_ADDR_END))
    {
        rc = modbus_reply_user_pcs_power_data_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= MB_ADJ_USER_ADDR_START) && ( end_addr <= MB_ADJ_USER_ADDR_END ))
    {
        rc = modbus_reply_user_remote_adjust(modbus_frame, data_buff);
    }

    else if ((modbus_frame->address >= USER_PROTOCOL_COMPATIBLE_ADDR_START) && (end_addr <= USER_PROTOCOL_COMPATIBLE_ADDR_END))
    {
        rc = cmu_modbus_reply_user_protocol_compatible_info(modbus_frame, data_buff);
    }
    /*以下为管理员数据*/
    #if 1
    else if ((modbus_frame->address >= ADMIN_CONTAINER_SYSTEM_ADDR_START) && (end_addr <= ADMIN_CONTAINER_SYSTEM_ADDR_END))
    {
        rc = modbus_reply_admin_container_system_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= ADMIN_BATTERY_CLUSTER_ADDR_START) && (end_addr <= ADMIN_BATTERY_CLUSTER_ADDR_END))
    {
        rc = modbus_reply_admin_battery_cluster_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= ADMIN_CONTAINER_FAULT_ADDR_START) && (end_addr <= ADMIN_CONTAINER_FAULT_ADDR_END))
    {
        rc = modbus_reply_admin_container_fault_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= ADMIN_PCS_FAULT_ADDR_START) && (end_addr <= ADMIN_PCS_FAULT_ADDR_END))
    {
        rc = modbus_reply_admin_pcs_fault_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= ADMIN_CMU_CONSTANT_PARAM_ADDR_START) && (end_addr <= ADMIN_CMU_CONSTANT_PARAM_ADDR_END))
    {
        rc = modbus_reply_admin_cmu_param_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= ADMIN_CONTAINER_CONSTANT_PARAM_ADDR_START) && (end_addr <= ADMIN_CONTAINER_CONSTANT_PARAM_ADDR_END))
    {
        rc = modbus_reply_admin_container_param_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= ADMIN_BATTERY_CONSTANT_PARAM_ADDR_START) && (end_addr <= ADMIN_BATTERY_CONSTANT_PARAM_ADDR_END))
    {
        rc = modbus_reply_admin_battery_param_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= ADMIN_PCS_CONSTANT_PARAM_ADDR_START) && (end_addr <= ADMIN_PCS_CONSTANT_PARAM_ADDR_END))
    {
        rc = modbus_reply_admin_pcs_param_info(modbus_frame, data_buff);
    }
    #endif
    if (rc != 0)
    {
        return modbus_reply_exception(ctx, modbus_frame->req, rc);
    }

    rsp_length = ctx->backend->build_response_basis(&sft, rsp);
    rsp[rsp_length++] = modbus_frame->reg_num << 1;

// 注意版本号是否正确？
    for (i = 0; i < modbus_frame->reg_num; i++) {
        rsp[rsp_length++] = data_buff[i] >> 8;
        rsp[rsp_length++] = data_buff[i] & 0xFF;
    }
    
    return (ctx->backend->backend_type == _MODBUS_BACKEND_TYPE_RTU &&
            modbus_frame->slave == MODBUS_BROADCAST_ADDRESS) ? 0 : send_msg(ctx, rsp, rsp_length); 
}

/**
 * @brief  CMU数据写总入口,函数里面对地址进行区分（依据协议点表大类分），再调用相关处理函数，
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t cmu_modbus_reply_write(modbus_t *ctx, modbus_frame_t *modbus_frame)
{
    //uint16_t end_addr = 0;
    uint8_t rsp[MODBUS_MAX_MESSAGE_LENGTH] = {0};
    uint8_t rsp_length = 0;
    sft_t sft;
    uint16_t data_buff[MODBUS_MAX_MESSAGE_LENGTH] = {0};
    int32_t rc = MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;

    sft.slave = modbus_frame->slave;
    sft.function = modbus_frame->function;
    sft.t_id = ctx->backend->prepare_response_tid(modbus_frame->req, (int *)&(modbus_frame->req_length));

    if (modbus_frame->reg_num < 1 || MODBUS_MAX_READ_REGISTERS < modbus_frame->reg_num) 
    {
        return modbus_reply_exception(ctx, modbus_frame->req, rc);
    }

    if (   ( modbus_frame->address >= MB_ADJ_USER_ADDR_START) 
        && ((modbus_frame->address + modbus_frame->reg_num) <= MB_ADJ_USER_ADDR_END ))
    {
        rc = modbus_reply_user_remote_adjust(modbus_frame, data_buff);
    }

    //end_addr = modbus_frame->address + modbus_frame->reg_num -1;
    #if 0
    if ((modbus_frame->address >= USER_DEVICE_SYSTEM_ADDR_START) && (end_addr <= USER_DEVICE_SYSTEM_ADDR_END))
    {
        rc = modbus_reply_user_device_system_info(modbus_frame, data_buff);
    }
    else
    #endif
    #if 1
    if ((modbus_frame->address >= ADMIN_CMU_CONSTANT_PARAM_ADDR_START) && ((modbus_frame->address + modbus_frame->reg_num) <= ADMIN_CMU_CONSTANT_PARAM_ADDR_END))
    {
        rc = modbus_reply_admin_cmu_param_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= ADMIN_CONTAINER_CONSTANT_PARAM_ADDR_START) && ((modbus_frame->address + modbus_frame->reg_num) <= ADMIN_CONTAINER_CONSTANT_PARAM_ADDR_END))
    {
        rc = modbus_reply_admin_container_param_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= ADMIN_BATTERY_CONSTANT_PARAM_ADDR_START) && ((modbus_frame->address + modbus_frame->reg_num) <= ADMIN_BATTERY_CONSTANT_PARAM_ADDR_END))
    {
        rc = modbus_reply_admin_battery_param_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= ADMIN_PCS_CONSTANT_PARAM_ADDR_START) && ((modbus_frame->address + modbus_frame->reg_num) <= ADMIN_PCS_CONSTANT_PARAM_ADDR_END))
    {
        rc = modbus_reply_admin_pcs_param_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= ADMIN_CMU_REMOTE_CONTROL_ADDR_START) && ((modbus_frame->address + modbus_frame->reg_num) <= ADMIN_CMU_REMOTE_CONTROL_ADDR_END))
    {
        rc = modbus_reply_admin_cmu_remote_ctrl_info(modbus_frame, data_buff);
    }
    // else if ((modbus_frame->address >= ADMIN_BATTERY_REMOTE_CONTROL_ADDR_START) && ((modbus_frame->address + modbus_frame->reg_num) <= ADMIN_BATTERY_REMOTE_CONTROL_ADDR_END))
    // {
    //     rc = modbus_reply_admin_battery_remote_ctrl_info(modbus_frame, data_buff);
    // }
    // else if ((modbus_frame->address >= ADMIN_PCS_REMOTE_CONTROL_ADDR_START) && ((modbus_frame->address + modbus_frame->reg_num) <= ADMIN_PCS_REMOTE_CONTROL_ADDR_END))
    // {
    //     rc = modbus_reply_admin_pcs_remote_ctrl_info(modbus_frame, data_buff);
    // }
    else
    #endif
    {
        rc = MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
    }

    if(rc != 0)
    {
        return modbus_reply_exception( ctx, modbus_frame->req, MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS);
    }
    
    rsp_length = ctx->backend->build_response_basis(&sft, rsp);
    /* 4 to copy the address (2) and the no. of registers */
    memcpy(rsp + rsp_length, modbus_frame->req + rsp_length, 4);
    rsp_length += 4;

    /* Suppress any responses when the request was a broadcast */
	return (ctx->backend->backend_type == _MODBUS_BACKEND_TYPE_RTU &&
            modbus_frame->slave == MODBUS_BROADCAST_ADDRESS) ? 0 : send_msg(ctx, rsp, rsp_length); 
}

/**
 * @brief  modbus协议分析总入口函数，根据读表功能码再调用相关处理函数，
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t cmu_modbus_analysis(modbus_t *ctx, modbus_frame_t *modbus_frame)
{
    switch (modbus_frame->function)
    {
        case MODBUS_FC_READ_HOLDING_REGISTERS:
            cmu_modbus_reply_read(ctx, modbus_frame);
            break;
        case MODBUS_FC_WRITE_SINGLE_REGISTER:
        case MODBUS_FC_WRITE_MULTIPLE_REGISTERS:
            cmu_modbus_reply_write(ctx, modbus_frame);
            break;

        default:
            modbus_reply_exception(ctx, modbus_frame->req, MODBUS_EXCEPTION_ILLEGAL_FUNCTION);
            break;
    }

    return 0;
}
