/*
 * @file    : sofar_debug.h
 * @brief   : 用于debug，将程序运行信息打印到终端
 * @Company : 首航新能源
 * @author  : liuyixuan
 * @note    : 分级控制
 * @date    : 2023-02-10
 */
#ifndef __SOFAR_DEBUG_H__
#define __SOFAR_DEBUG_H__

#include "stdio.h"
#include "stdint.h"

//定义日志级别
enum LOG_LEVEL {
	LOG_LEVEL_OFF = 0,
	LOG_LEVEL_DEBUG,
	LOG_LEVEL_ERR,
	LOG_LEVEL_WARN,
	LOG_LEVEL_INFO,
	LOG_LEVEL_ALL,
};

#define	DISABLE	    0
#define	ENABLE	    1

////////////////////////////  以下是自定义修改部分  ////////////////////////////

// #define __LOG_PRINTF    //日志模块总开关，注释掉将关闭日志输出

#define LOG_PRINTF_LEVEL	                LOG_LEVEL_OFF   //log等级

#define LOG_SHARED_MEMORY_ENABLE            (0)     //共享内存
#define LOG_FIRMWARE_UPDATE_ENABLE          (0)     //升级
#define LOG_WEB_ENABLE                      (0)     //web
#define LOG_MODBUS_ENABLE                   (0)     //Modbus
#define LOG_MODBUS_MESSAGE_ENABLE           (0)     //Modbus报文
#define LOG_DSP_485COMM_ENABLE              (0)     //DSP通信
#define LOG_DSP_UPDATE_ENABLE               (0)     //DSP升级
#define LOG_CAN1_ENABLE                     (0)     //can
#define LOG_DCDC_SCI_ENABLE                 (0)     //DCDC
#define LOG_ENERGY_RECORD_ENABLE            (0)     //电量
#define LOG_HISTORY_EVENT_ENABLE            (0)     //历史事件，通用任务
#define LOG_SAFETY_ENABLE                   (0)     //安规
#define LOG_PLC_ENABLE                      (0)     //PLC
#define LOG_PLC_UPDATE_ENABLE               (0)     //PLC升级
#define LOG_PLC_UPDATE_MESSAGE_ENABLE       (0)     //PLC升级报文

////////////////////////////          end          ////////////////////////////

// 颜色打印
#define COLOUR_NONE         "\033[m"
#define COLOUR_RED          "\033[0;32;31m"
#define COLOUR_LIGHT_RED    "\033[1;31m"
#define COLOUR_GREEN        "\033[0;32;32m"
#define COLOUR_LIGHT_GREEN  "\033[1;32m"
#define COLOUR_BLUE         "\033[0;32;34m"
#define COLOUR_LIGHT_BLUE   "\033[1;34m"
#define COLOUR_DARY_GRAY    "\033[1;30m"
#define COLOUR_CYAN         "\033[0;36m"
#define COLOUR_LIGHT_CYAN   "\033[1;36m"
#define COLOUR_PURPLE       "\033[0;35m"
#define COLOUR_LIGHT_PURPLE "\033[1;35m"
#define COLOUR_BROWN        "\033[0;33m"
#define COLOUR_YELLOW       "\033[1;33m"
#define COLOUR_LIGHT_GRAY   "\033[0;37m"
#define COLOUR_WHITE        "\033[1;37m"


#ifdef __LOG_PRINTF
#define LOG_PRINTF(format, ...) printf(format, ##__VA_ARGS__)
#else
#define LOG_PRINTF(format, ...)
#endif

#ifdef __LOG_PRINTF
//仅调试时使用 例：log_debug(DEBUG_DSP_COMM_ENABLE, "arr = %s", arr);
#define log_debug(log_state, format, ...) \
        do \
        { \
            if(ENABLE != log_state)\
            break;\
            if(LOG_PRINTF_LEVEL >= LOG_LEVEL_DEBUG)\
            LOG_PRINTF("[ "COLOUR_PURPLE"Debug"COLOUR_NONE" ]:"format"\n",##__VA_ARGS__ );\
        } while (0)

//错误 例：log_err(DEBUG_DSP_COMM_ENABLE, "arr = %s", arr);
#define log_err(log_state, format, ...) \
        do \
        { \
            if(ENABLE != log_state)\
            break;\
            if(LOG_PRINTF_LEVEL >= LOG_LEVEL_ERR)\
            LOG_PRINTF("[ Error -> file:%s/func:%s/line:%d]: " format "\n",\
                        __FILE__, __func__, __LINE__, ##__VA_ARGS__ );\
        } while (0)

//警告 例：log_warn(DEBUG_DSP_COMM_ENABLE, "arr = %s", arr);
#define log_warn(log_state, format, ...) \
        do \
        { \
            if(ENABLE != log_state)\
            break;\
            if(LOG_PRINTF_LEVEL >= LOG_LEVEL_WARN)\
            LOG_PRINTF("[ Warning -> file:%s/func:%s/line:%d]: " format "\n",\
                        __FILE__, __func__, __LINE__, ##__VA_ARGS__ );\
        } while (0)

//通信、交互信息 例：log_info(DEBUG_DSP_COMM_ENABLE, "arr = %s", arr);
#define log_info(log_state, format, ...) \
        do \
        { \
            if(ENABLE != log_state)\
            break;\
            if(LOG_PRINTF_LEVEL >= LOG_LEVEL_INFO)\
            LOG_PRINTF("[ Info -> func:%s]: "format"\n",\
                     __func__, ##__VA_ARGS__ );\
        } while (0)
#else
#define log_debug(log_state, format, ...) 
#define log_err(log_state, format, ...) 
#define log_warn(log_state, format, ...) 
#define log_info(log_state, format, ...)
#endif


#endif  // __SDK_DEBUG_H__
