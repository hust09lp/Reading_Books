#ifndef __COMMAND_PARSER_H__
#define __COMMAND_PARSER_H__

#include "data_types.h"
#include "modbus.h"
#include "modbus_common.h"


#define USER_DEVICE_SYSTEM_ADDR_START               1001    // 设备系统参数起始地址
#define USER_DEVICE_SYSTEM_ADDR_END                 2000    // 设备系统参数结束地址
#define USER_CSU_SYSTEM_ADDR_START                  0x4001//10001   // CSU系统信息起始地址
#define USER_CSU_SYSTEM_ADDR_END                    0x4200//10600   // CSU系统信息结束地址
#define USER_SYSTEM_FAULT_ADDR_START                11001   // 储能系统故障状态信息开始地址
#define USER_SYSTEM_FAULT_ADDR_END                  12000   // 储能系统故障状态信息结束地址
#define USER_SYSTEM_CONSTANT_PARAM_ADDR_START       12001   // 储能系统定值参数开始地址
#define USER_SYSTEM_CONSTANT_PARAM_ADDR_END         12200   // 储能系统定值参数结束地址
#define USER_SYSTEM_REMOTE_CONTROL_ADDR_START       0x6011//13001   // 储能系统遥控开始地址
#define USER_SYSTEM_REMOTE_CONTROL_ADDR_END         0x6020//13100   // 储能系统遥控结束地址
#define USER_PROTOCOL_COMPATIBLE_ADDR_START         20000   // 协议兼容信息开始地址
#define USER_PROTOCOL_COMPATIBLE_ADDR_END           20400   // 协议兼容信息结束地址

#define ADMIN_SYSTEM_CABINET_ADDR_START             0x4201//20401   // 储能系统MCU2起始地址
#define ADMIN_SYSTEM_CABINET_ADDR_END               0x4300//20700   // 储能系统MCU2结束地址
#define ADMIN_SYSTEM_FAULT_ADDR_START               22001   // 储能系统故障状态信息开始地址
#define ADMIN_SYSTEM_FAULT_ADDR_END                 23000   // 储能系统故障状态信息结束地址
#define ADMIN_CSU_CONSTANT_PARAM_ADDR_START         0x8001//23001   // CSU定值参数开始地址
#define ADMIN_CSU_CONSTANT_PARAM_ADDR_END           0x8040//23100   // CSU定值参数结束地址
#define ADMIN_SYSTEM_CONSTANT_PARAM_ADDR_START      0x8041//23101   // 储能系统定值参数开始地址
#define ADMIN_SYSTEM_CONSTANT_PARAM_ADDR_END        0x8100//23300   // 储能系统定值参数结束地址
#define ADMIN_EMS_CONSTANT_PARAM_ADDR_START         0x8401//23301   // EMS定值参数开始地址
#define ADMIN_EMS_CONSTANT_PARAM_ADDR_END           0x8500//23600   // EMS定值参数结束地址
#define ADMIN_SYSTEM_REMOTE_CONTROL_ADDR_START      0x6001//25001   // 储能系统遥控开始地址
#define ADMIN_SYSTEM_REMOTE_CONTROL_ADDR_END        0x6010//25100   // 储能系统遥控结束地址

#define FACTORY_TEST_ADDR_START                     65000   // 产测开始地址
#define FACTORY_TEST_END                            65535   // 产测结束地址

#define  MODBUS_SYSTEM_STATUS_LEN_BYTE       10    // 集装箱系统（状态信息）所占字节数
#define  MODBUS_SYSTEM_WARN_LEN_BYTE         16    // 集装箱系统（告警信息）所占字节数
#define  MODBUS_SYSTEM_FAULT_LEN_BYTE        6     // 集装箱系统（故障信息）所占字节数
#define  MODBUS_TCP_FRAME_HEAD_LEN_BYTE      7     // TCP帧头所占字节数
#define  MODBUS_RTU_FRAME_DATA_LEN_BYTE      1     // RTU帧头所占字节数

#pragma pack(push)
#pragma pack(1)
/**************** 用户数据部分 ****************/


typedef struct{
	uint16_t hardware_version_number;
	uint16_t communication_protocol_version_number;
	uint16_t sn_version_number[11];
	uint32_t mcu1_software_version_number;
	uint32_t mcu1_boot_version_number;
	uint32_t mcu1_core_version_number;
	uint32_t mcu2_software_version_number;
	uint32_t mcu2_boot_version_number;
	uint32_t mcu2_core_version_number;
	uint16_t system_power;								//系统额定功率
	uint16_t max_apparent_power;						//最大视在功率
	uint16_t max_active_power;							//最大有功功率
	uint16_t max_reactive_power;						//最大无功功率
    uint16_t system_sta;                                // 储能系统状态
	uint16_t ext_communication_protocol_version;        // 外部通信协议版本号
}csu_system_telemetry_info_t;

/**************** 储能系统故障设置 ****************/
typedef struct {
    union {
        uint16_t system_fault_info;
        struct {
            uint16_t sci_communicate_fault: 1;
            uint16_t pcs_communicate_loss: 1;
            uint16_t protocol_version_diff: 1;
            uint16_t file_device_param_diff: 1;
            uint16_t reserve: 12;
        }bit;
    }first_addr_info_u;
    uint16_t reserve[2];
}user_system_fault_info_t;

typedef struct {
    union {
        uint16_t system_status_info;
        struct {
            uint16_t running_state: 1;
            uint16_t cabinet_fault_state: 1;
            uint16_t remote_stop_fault_state: 1;
            uint16_t reserve: 13;
        }bit;
    }first_addr_info_u;
    uint16_t restatusserve[4];
}user_system_status_info_t;

typedef struct {
    union {
        uint16_t system_warn_info;
        struct {
            uint16_t monitorBoardOverTempWarnFirst: 1;
            uint16_t monitorBoardOverTempProtectThird: 1;
            uint16_t monitorBoardUnderTempProtectFirst: 1;
            uint16_t monitorBoardTempSensorFaultFirst: 1;
            uint16_t cabinetFaultFirst: 1;
            uint16_t remoteREPOFaultThird: 1;
            uint16_t MeasureMeterDisconnectFirst: 1;
            uint16_t antiRefluxMeterDisconnectFirst: 1;
            uint16_t microComputerDisconnectFirst: 1;
            uint16_t measurDeviceDisconnectFirst: 1;
            uint16_t pcsModelErrorThird: 1;
            uint16_t antiRefluxFailedFirst: 1;
            uint16_t reserve: 4;
        }bit;
    }first_addr_info_u;
    uint16_t reserve[7];
}user_system_warn_info_t;

typedef struct {
    user_system_fault_info_t system_fault;
    user_system_status_info_t system_status;
    user_system_warn_info_t system_warn;
}user_system_fault_warn_status_info_t;

/**************** 储能系统参数设置 ****************/
typedef struct {
    int16_t active_power;						//有功功率
	int16_t reactive_power;						//无功功率
}user_system_param_info_t;

/**************** 管理员数据部分 ****************/
/**************** 集装箱故障信息设置 ****************/
typedef struct{
    uint8_t system_fault_info[MODBUS_SYSTEM_FAULT_LEN_BYTE];              	// 储能系统故障信息 用户数据
    uint8_t system_status_info[MODBUS_SYSTEM_STATUS_LEN_BYTE];             // 储能系统状态信息（IO状态）用户数据
    uint8_t system_warn_info[MODBUS_SYSTEM_WARN_LEN_BYTE];                 // 储能系统告警信息 用户数据
}admin_system_fault_info_t;

/**************** 储能系统参数设置 ****************/
typedef struct{
	int16_t active_power;						//有功功率
	int16_t reactive_power;						//无功功率
    uint16_t pcs_operation_mode;                // PCS运行模式设置 0x0000=并网模式 0x0001=离网模式 0x0010=恒流源模式 0x0020=恒压源模式 0x0100=AFE模式
	uint16_t bus_volt_ref;               		// bus电压给定值设定
	uint16_t const_current_ref;                 // 恒流源电流给定
	int16_t power_factor;						//功率因数给定
	uint16_t reactive_power_manage_mode;        //PCS无功管理模式设置
	uint16_t CEI016_reactive_power_manage_mode; //PCS无功管理CEI016模式设置
	uint16_t pcs_sys_power_mode; 				//PCS系统功率分配方式
	uint16_t power_soft_start_rate;	 			//功率软启动速率
    uint16_t energy_storage_nums;               // 储能柜个数（有CMU的）
	rs485_device_enable_u rs485_device_enable;  // （0=不使能，1=使能）bit0：防逆流电表使能 bit1：计量电表使能 bit2：
												//  微机装置使能 bit3：智能测控装置使能 bit4：除湿器使能
	uint16_t scenario_setting;                  // 0=标准场景，1=单储能柜场景
	uint16_t pcs_low_power_enable;				// PCS低功耗模式使能位
	uint16_t pcs_low_power_wait_time;			// PCS等待进入低功耗模式时间
	uint16_t humidity_set;						// 汇流柜湿度设定
	uint16_t humidity_diff_set;					// 汇流柜湿度回差设定
}admin_system_param_info_t;

typedef struct{
	uint16_t tm_year;								//系统时钟：年							
	uint16_t tm_mon;								//系统时钟：月
	uint16_t tm_day;								//系统时钟：日
	uint16_t tm_hour;								//系统时钟：时
	uint16_t tm_min;								//系统时钟：分
	uint16_t tm_sec;								//系统时钟：秒
}device_time_param_t;
typedef struct{
	system_parameter_data_t sys_param;			//储能系统参数
	device_time_param_t sys_time;				//系统时间
}modbus_system_parameter_data_t;
typedef struct {
    user_system_param_info_t user_system_param;
    modbus_system_parameter_data_t system_param;
    admin_system_param_info_t admin_system_param;
    ems_data_t ems_data;
	ems_holiday_data_t ems_holiday_data;
}modbus_constant_param_info_t;

typedef struct {
    uint16_t remote_power;                       			// 远程开关机
    uint16_t fault_reset;								        //故障复位
    uint16_t clear_data;										//清除历史数据
	uint16_t restore_factory;								        //恢复出厂设置
	uint16_t discon_shunt;								        //汇流柜分励脱扣器断开
	uint16_t fan_ctrl;								        //汇流柜风扇
}modbus_csu_remote_ctrl_t;

typedef struct {
    uint16_t system_status;							//系统状态字 0：停机 1：待机 2：故障 3：充电 4：放电
	uint16_t grid_status;							//并离网状态 0：离网 1：并网
	uint16_t grid_side_line_vol_rs;               	// 网侧线电压RS        	0.1/V
	uint16_t grid_side_line_vol_st;               	// 网侧线电压ST        	0.1/V
	uint16_t grid_side_line_vol_tr;               	// 网侧线电压TR        	0.1/V
	uint16_t ac_side_line_vol_rs;            		// 交流侧线电压RS      	0.1/V
	uint16_t ac_side_line_vol_st;            		// 交流侧线电压ST      	0.1/V
	uint16_t ac_side_line_vol_tr;            		// 交流侧线电压TR      	0.1/V
	uint16_t ac_side_phase_current_r;   			//交流侧相电流R			0.1/A
	uint16_t ac_side_phase_current_s;   			//交流侧相电流S			0.1/A
	uint16_t ac_side_phase_current_t;   			//交流侧相电流T			0.1/A
	uint16_t ac_side_freq;   						//交流侧频率			0.01/HZ
	int16_t csu_board_temperature;                  // CSU板温      		0.1/C
	int16_t  at_temperature;                   		// 汇流柜环温     		0.1/C
	int32_t ac_side_active_power;					//交流侧有功功率		0.1/kW
	int32_t ac_side_reactive_power;					//交流侧无功功率		0.1/kW
	int32_t ac_side_phase_view_power;				//交流侧视在功率 		0.1/kVA
	uint32_t daily_charging_capacity;           	//日充电量    			0.1kWh
	uint32_t daily_discharging_capacity;          	//日放电量				0.1kWh
	uint32_t total_charging_capacity;           	//总充电量				1/kWh
	uint32_t total_discharging_capacity;           	//总放电量				1/kWh
	uint32_t total_run_time;						//PCS柜1总运行时间 		0.1/hour
	uint16_t ac_side_phase_vol_r;            		//交流侧相电压R        0.1/V
	uint16_t ac_side_phase_vol_s;            		// 交流侧相电压S        0.1/V
	uint16_t ac_side_phase_vol_t;            		// 交流侧相电压T        0.1/V
	int16_t ac_side_phase_r_active_power;			//交流侧R相有功功率 kW / 0.1
	int16_t ac_side_phase_s_active_power;			//交流侧S相有功功率 kW / 0.1
	int16_t ac_side_phase_t_active_power;			//交流侧T相有功功率 kW / 0.1
	int16_t ac_side_phase_r_reactive_power;			//交流侧R相无功功率 kVar / 0.1
	int16_t ac_side_phase_s_reactive_power;			//交流侧S相无功功率 kVar / 0.1
	int16_t ac_side_phase_t_reactive_power;			//交流侧T相无功功率 kVar / 0.1
	int16_t ac_side_phase_r_view_power;				//交流侧R相视在功率 kVA / 0.1
	int16_t ac_side_phase_s_view_power;				//交流侧S相视在功率 kVA / 0.1
	int16_t ac_side_phase_t_view_power;				//交流侧T相视在功率 kVA / 0.1
	int32_t anti_reflux_power;						//防逆流点表功率		0.1/kW
	modbus_meter_energy_data_t meter_data;			//储能柜计量表数据
	uint16_t dry_temp;            		            //除湿器温度       ℃
	uint16_t dry_humidity;            		        //除湿器湿度       RH%
	int32_t photo_meter_power;						//光伏电表总功率		0.1/kW
}modbus_mcu2_realtime_data_t;//MCU2实时数据

extern factory_test_data_t factory_data;
#pragma pack(pop)

void modbus_start(void);
int32_t modbus_analysis(modbus_t *ctx, const uint8_t *req, int32_t req_length, modbus_mapping_t *mb_mapping);
int32_t get_Master_fd(void);
void set_Master_fd(int32_t fd);

/**
 * @brief  产测更改IO输出
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t set_gpio(int32_t num,int8_t value);

#endif



