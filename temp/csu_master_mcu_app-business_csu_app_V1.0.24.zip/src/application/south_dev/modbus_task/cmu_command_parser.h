#ifndef __CMU_COMMAND_PARSER_H__
#define __CMU_COMMAND_PARSER_H__

#include "data_types.h"
#include "modbus.h"
#include "modbus_common.h"
#include "cs104_connection.h"

/******************** 用户数据地址 ********************/
#define USER_CMU_SYSTEM_ADDR_START                  0x4301   // CMU系统信息起始地址
#define USER_CMU_SYSTEM_ADDR_END                    0x431D   // CMU系统信息结束地址
#define USER_CONTAINER_SYSTEM_ADDR_START            0x431E   // 集装箱系统信息起始地址
#define USER_CONTAINER_SYSTEM_TEMP_SPEC_ADDR		10113   // 集装箱系统电池仓温度特殊地址 104对应偏移
#define USER_CONTAINER_SYSTEM_TYPE_SPEC_START_ADDR	10114   // 集装箱系统电池仓液冷机组型号特殊开始地址 104对应偏移

#define USER_CONTAINER_SYSTEM_ADDR_END              0x4400   // 集装箱系统信息结束地址
#define USER_BATTERY_CLUSTER_ADDR_START             0x4401   // 电池簇信息起始地址
#define USER_BATTERY_CLUSTER_ADDR_END               0x4E00   // 电池簇信息结束地址
#define USER_BATTERY2_CLUSTER_ADDR_START            0xA401   // 电池簇2信息起始地址
#define USER_BATTERY6_CLUSTER_ADDR_END              0xEE00   // 电池簇6信息结束地址
#define USER_CONTAINER_FAULT_ADDR_START             0x0101   // 集装箱故障状态信息开始地址
#define USER_CONTAINER_FAULT_ADDR_END               0x02C0   // 集装箱故障状态信息结束地址
#define USER_BATTERY_FAULT_ADDR_START               0x02C1   // 电池簇故障状态信息开始地址
#define USER_BATTERY_FAULT_ADDR_END                 0x03C0   // 电池簇故障状态信息结束地址
#define USER_BATTERY_ADDR_END                 		0x08C0   // 电池簇故障状态信息结束地址
#define USER_PCS_FAULT_ADDR_START                   0x08C1   // PCS故障状态信息开始地址
#define USER_PCS_FAULT_ADDR_END                     0x09C0   // PCS故障状态信息结束地址

#define MB_MEAS_SAFETY_PARAM_ADDR_START             0x8101   // 安规参数开始地址
#define MB_MEAS_SAFETY_PARAM_ADDR_END               0x8400   // 安规参数结束地址

#define MB_MEAS_USER_PCS_PARAM_ADDR_START           0x8901   // PCS功率模块参数
#define MB_MEAS_USER_PCS_PARAM_ADDR_END             0x8940   // 
#define MB_MEAS_USER_PCS_POWER_DATA_ADDR_START      0xEE01   // PCS功率模块数据
#define MB_MEAS_USER_PCS_POWER_DATA_ADDR_END        0xEEB0   // 
#define MB_MEAS_USER_PCS_DEV_INFO_ADDR_START        0xEEB1   // PCS功率模块设备信息
#define MB_MEAS_USER_PCS_DEV_INFO_ADDR_END          0xEF00   // 

#define MB_ADJ_USER_ADDR_START                      18001   // 遥调（定值参数）
#define MB_ADJ_USER_ADDR_END                        18200   // 


/******************** 管理员数据地址 ********************/
#define ADMIN_CONTAINER_SYSTEM_ADDR_START           20401   // 集装箱系统信息起始地址
#define ADMIN_CONTAINER_SYSTEM_ADDR_END             20700   // 集装箱系统信息结束地址
#define ADMIN_BATTERY_CLUSTER_ADDR_START            20701   // 电池簇信息起始地址
#define ADMIN_BATTERY_CLUSTER_ADDR_END              33300   // 电池簇信息结束地址
#define ADMIN_CONTAINER_FAULT_ADDR_START            34001   // 集装箱故障状态信息开始地址
#define ADMIN_CONTAINER_FAULT_ADDR_END              34028   // 集装箱故障状态信息结束地址
#define ADMIN_PCS_FAULT_ADDR_START                  34125   // PCS故障状态信息开始地址
#define ADMIN_PCS_FAULT_ADDR_END                    34152   // PCS故障状态信息结束地址
#define ADMIN_CMU_CONSTANT_PARAM_ADDR_START         0x8701   // CMU系统定值参数开始地址
#define ADMIN_CMU_CONSTANT_PARAM_ADDR_END           0x8740   // CMU系统定值参数结束地址
#define ADMIN_CONTAINER_CONSTANT_PARAM_ADDR_START   0x8741   // 集装箱系统定值参数开始地址
#define ADMIN_CONTAINER_CONSTANT_PARAM_ADDR_END     0x8800   // 集装箱系统定值参数结束地址
#define ADMIN_BATTERY_CONSTANT_PARAM_ADDR_START     0x8801   // 电池簇定值参数开始地址
#define ADMIN_BATTERY_CONSTANT_PARAM_ADDR_END       0x8900   // 电池簇定值参数结束地址
#define ADMIN_PCS_CONSTANT_PARAM_ADDR_START         35601   // PCS定值参数开始地址
#define ADMIN_PCS_CONSTANT_PARAM_ADDR_END           35700   // PCS定值参数结束地址
#define ADMIN_CMU_REMOTE_CONTROL_ADDR_START         0x6011   // CMU系统遥控开始地址
#define ADMIN_CMU_REMOTE_CONTROL_ADDR_END           0x6020   // CMU系统遥控结束地址
#define ADMIN_BATTERY_REMOTE_CONTROL_ADDR_START     0x6021   // 电池簇系统遥控开始地址
#define ADMIN_BATTERY_REMOTE_CONTROL_ADDR_END       0x6070   // 电池簇系统遥控结束地址
#define ADMIN_PCS_REMOTE_CONTROL_ADDR_START         0x6071   // PCS系统遥控开始地址
#define ADMIN_PCS_REMOTE_CONTROL_ADDR_END           0x6080   // PCS系统遥控结束地址

#define MODBUS_USER_MONITOR_SOH_ADDR				(10452)	// PACK1单体SOH
#define MODBUS_USER_PACK1_UC_ADDR_START           	(10453)
#define MODBUS_USER_PACK1_TC_ADDR_END             	(10548)
#define MODBUS_USER_PACK5_TC_ADDR_END             	(10932)	// PACK5单体温度
#define MODBUS_USER_PACK1_POLE_TEMP_ADDR_START		(10933)	// PACK1极柱温度

#define MODBUS_ADMIN_PACK1_SOC_ADDR_START			(20701)	// PACK1单体SOC
#define MODBUS_ADMIN_PACK1_SOP_ADDR_END				(20892)	// PACK1单体SOP
#define MODBUS_ADMIN_PACK5_SOP_ADDR_END				(21660)	// PACK1单体SOP
#define MODBUS_ADMIN_PACK6_UC_ADDR_START				(21661)	// PACK1单体SOP
#define MODBUS_ADMIN_PACK8_SOP_ADDR_END             (22524)	// PACK8单体SOP
#define MODBUS_ADMIN_PACK6_POLE_TEMP_ADDR_START		(22525)	// PACK6极柱温度

#define MODBUS_USER_PACK_INTERVAL						(96)	// Modbus PACK数量
#define MODBUS_ADMIN_PACK_INTERVAL						(192)	// Modbus PACK数量
#define MODBUS_USER_BATTERY_CLUSTER_INTERVAL        542//800     // 用户数据里单簇点位数量
#define MODBUS_ADMIN_BATTERY_CLUSTER_INTERVAL       2100    // 用户数据里单簇点位数量
#define MODBUS_BATTERY_CLUSTER_FAULT_LEN_BYTES      32      // 电池簇故障状态地址数

#define IEC104_USER_BATTERY_CLUSTER_ADDR_START		(0x4401)
#define IEC104_USER_BATTERY_CLUSTER2_ADDR_START		(0xA401)
#define IEC104_USER_CABINET_ADDR_START				(0x431E)
#define IEC104_USER_TEMP_SPEC_ADDR					(0x432F)
#define IEC104_USER_TYPE_SPEC_ADDR_START    		(0x4335)
#define IEC104_USER_PACK1_UC_ADDR_START				(0x4435)
#define IEC104_ADMIN_PACK1_SOC_ADDR_START           (0x4495)
#define IEC104_ADMIN_PACK1_SOP_ADDR_END             (0x4554)
#define IEC104_USER_PACK2_UC_ADDR_START             (0x4555)
#define IEC104_USER_PACK2_TC_ADDR_END               (0x45B4)
#define IEC104_USER_PACK5_TC_ADDR_END               (0x4914)
#define IEC104_ADMIN_PACK5_SOC_ADDR_START           (0x4915)
#define IEC104_ADMIN_PACK6_UC_ADDR_START           	(0x49D5)
#define IEC104_ADMIN_PACK8_SOP_ADDR_END             (0x4C80)
#define IEC104_ADMIN_PACK6_POLE_TEMP_ADDR_START		(0x4D3F)

#define IEC104_SAFETY_PARAM_ADDR_START              (0x8101)
#define IEC104_SAFETY_PARAM_ADDR_END                (0x8400)

#define IEC104_USER_PCS_PARAM_ADDR_START            (0x8901)
#define IEC104_USER_PCS_PARAM_ADDR_END              (0x8940)
#define IEC104_USER_PCS_POWER_DATA_START            (0xEE01)
#define IEC104_USER_PCS_POWER_DATA_END              (0xEEB0)
#define IEC104_USER_PCS_DEV_INFO_START              (0xEEB1)
#define IEC104_USER_PCS_DEV_INFO_END                (0xEF00)

#define IEC104_USER_PACK1_T1_ADDR_START             (0x4C81)
#define IEC104_USER_PACK5_T2_ADDR_END               (0x4D3E)
#define IEC104_USER_PACK1_POLE_TEMP_ADDR_START		(0x4D35)
#define IEC104_USER_LC_STATUS_ADDR_START            (0x171)
#define IEC104_USER_LC_STATUS_ADDR_END              (0x190)
#define IEC104_USER_LC_WARN_ADDR_START              (0x1B1)
#define IEC104_USER_LC_WARN_ADDR_END                (0x1F0)
#define IEC104_USER_LC_FAULT_ADDR_START             (0x242)
#define IEC104_USER_LC_FAULT_ADDR_END               (0x281)

#define IEC104_SECOND_BATTERY_CLUSTER_INTERVAL      (0x6000)
#define IEC104_THIRD_BATTERY_CLUSTER_INTERVAL       (0x1000)

#define IEC104_BATTERY_CLUSTER_INTERVAL             (0x0A00)
#define IEC104_PACK_INTERVAL                        (288)
#define IEC104_PACK_SPEC_START						(53-1)
#define IEC104_PACK_SPEC_TEMP_START					(2357-1)

#define IEC104_MSG_MAX_LEN							(240)

#define  MODBUS_CMU_FAULT_ADDR_START                16001
#define  MODBUS_CMU_FAULT_ADDR_END                  16003
#define  MODBUS_CONTAINER_STATUS_ADDR_START         16004
#define  MODBUS_CONTAINER_STATUS_ADDR_END           16010
#define  MODBUS_CONTAINER_WARN_ADDR_START           16011
#define  MODBUS_CONTAINER_WARN_ADDR_END             16019
#define  MODBUS_CONTAINER_FAULT_ADDR_START          16020
#define  MODBUS_CONTAINER_FAULT_ADDR_END            16028

#define  MODBUS_CMU_FAULT_LEN_BYTE                  6   // CMU 系统故障 所占字节数
#define  MODBUS_CONTAINER_STATUS_LEN_BYTE           14  // 集装箱系统（状态信息）所占字节数
#define  MODBUS_CONTAINER_WARN_LEN_BYTE             18  // 集装箱系统（告警信息）所占字节数
#define  MODBUS_CONTAINER_FAULT_LEN_BYTE            18  // 集装箱系统（故障信息）所占字节数
#define  MODBUS_BATTERY_STATUS_LEN_BYTE             4   // 电池簇（状态信息）所占字节数
#define  MODBUS_BATTERY_WARN_LEN_BYTE               18  // 电池簇（告警信息）所占字节数
#define  MODBUS_BATTERY_FAULT_LEN_BYTE              10  // 电池簇（故障信息）所占字节数
#define  MODBUS_PCS_FAULT_LEN_BYTE                  56  // PCS模块（故障信息）所占字节数

#define MODBUS_A_PHASE_VOLTAGE_ADDR					20432
#define MODBUS_C_PHASE_ACTIVE_POWER_ADDR			20462

#define MODBUS_CONTAINER_ALL_FAULTS_LEN_BYTE        (MODBUS_CMU_FAULT_LEN_BYTE+MODBUS_CONTAINER_STATUS_LEN_BYTE+MODBUS_CONTAINER_WARN_LEN_BYTE+MODBUS_CONTAINER_FAULT_LEN_BYTE)

#define MODBUS_DEVICE_ADDR_CSU                      1
#define MODBUS_DEVICE_ADDR_FIRST_CMU				1
#define MODBUS_DEVICE_ADDR_LAST_CMU				    6
#define MODBUS_CURRENT_CMU_NUM                      (1)

#define CSU_SYS_FAULT_INFO_ADDR_START  0x0001
#define CSU_SYS_FAULT_INFO_ADDR_END  0x0030
#define COMBINER_CABINET_STATUS_INFO_ADDR_START  0x0031
#define COMBINER_CABINET_STATUS_INFO_ADDR_END  0x0080
#define COMBINER_CABINET_FAULT_INFO_ADDR_START  0x0081
#define COMBINER_CABINET_FAULT_INFO_ADDR_END  0x0100
#define CMU_SYS_FAULT_INFO_ADDR_START  0x0101
#define CMU_SYS_FAULT_INFO_ADDR_END  0x0130
#define ENERGY_CABINET_STATUS_INFO_ADDR_START  0x0131
#define ENERGY_CABINET_STATUS_INFO_ADDR_END  0x01A0
#define ENERGY_CABINET_WARN_INFO_ADDR_START  0x01A1
#define ENERGY_CABINET_WARN_INFO_ADDR_END  0x0230
#define ENERGY_CABINET_FAULT_INFO_ADDR_START  0x0231
#define ENERGY_CABINET_FAULT_INFO_ADDR_END  0x02C0
#define BCU_ADDR_INTERVAL  0x0100
#define BCU1_STATUS_INFO_ADDR_START  0x02C1
#define BCU1_STATUS_INFO_ADDR_END  0x03C0
#define BCU_STATUS_INFO_ADDR_END  0x08C0//0x03C0
#define BCU1_WARN_INFO_ADDR_START  0x02E1
#define BCU1_WARN_INFO_ADDR_END  0x0370
#define BCU1_FAULT_INFO_ADDR_START  0x0371
#define BCU1_FAULT_INFO_ADDR_END  0x03C0
#define BCU2_STATUS_INFO_ADDR_START  BCU1_STATUS_INFO_ADDR_START + BCU_ADDR_INTERVAL
#define BCU2_STATUS_INFO_ADDR_END  BCU1_STATUS_INFO_ADDR_END + BCU_ADDR_INTERVAL
#define BCU2_WARN_INFO_ADDR_START  BCU1_WARN_INFO_ADDR_START + BCU_ADDR_INTERVAL
#define BCU2_WARN_INFO_ADDR_END  BCU1_WARN_INFO_ADDR_END + BCU_ADDR_INTERVAL
#define BCU2_FAULT_INFO_ADDR_START  BCU1_FAULT_INFO_ADDR_START + BCU_ADDR_INTERVAL
#define BCU2_FAULT_INFO_ADDR_END  BCU1_FAULT_INFO_ADDR_END + BCU_ADDR_INTERVAL
#define PCS_FAULT_INFO_ADDR_START  0x08C1
#define PCS_FAULT_INFO_ADDR_END  0x09C0
#pragma pack(push)
#pragma pack(1)
/**************** 用户数据部分 ****************/
typedef struct{
	uint16_t cmu_hardware_version_number;
	uint32_t mcu1_software_version_number;
	uint32_t mcu1_boot_version_number;
	uint32_t mcu1_core_version_number;
	uint32_t mcu2_software_version_number;
	uint32_t mcu2_boot_version_number;
	uint32_t mcu2_core_version_number;
	uint16_t communication_protocol_version_number;
    uint16_t system_state;
}cmu_system_telemetry_info_t;

typedef struct{
    uint16_t cmu_fault_iec104_addr;
	uint16_t container_status_iec104_addr;
	uint16_t container_warn_iec104_addr;
	uint16_t container_fault_iec104_addr;
}iec104_fault_addr_info_t;
#pragma pack(pop)

void _sleep_response_timeout(modbus_t *ctx);
int send_msg(modbus_t *ctx, uint8_t *msg, int msg_length);
void send_cmu_remoteCtrl(modbus_frame_t *modbus_frame, uint16_t *data);
void send_cmu_clock_syn(modbus_frame_t *modbus_frame, uint16_t *data);

int32_t cmu_modbus_analysis(modbus_t *ctx, modbus_frame_t *modbus_frame);
int32_t modbus_reply_single_data(modbus_frame_t *modbus_frame, uint16_t *p_buf);

/**
 * @brief   modbus-tcp转104报文
 * @param   
 * @note    
 * @return  
 */
int32_t modbusTCPToIEC104(uint16_t slave, uint16_t reg_num, uint8_t *data, uint8_t len, IEC60870_5_TypeID typeid);
#endif