#ifndef _SF_MB_ST_H_
#define _SF_MB_ST_H_

#include "data_types.h"
#include "dev_config.h"
#include "sofar_type.h"

#define GET_MODBUS_ADDR_OFFSET( st_type, member )  ( GET_MEMBER_OFFSET(st_type, member) / 2 )

typedef struct 
{
    int16_t vol   [ BAT_NUM_IN_PACK ];    // PACK1单体电压Uc1-Uc48           
    int16_t temper[ BAT_NUM_IN_PACK ];    // PACK1单体温度Tc1-Tc48           
} mb_pack_info_t;

typedef struct 
{
    int16_t positive;
    int16_t negative;
} mb_pole_tmper_t;

typedef struct 
{
    uint16_t sw_ver;                   //< 软件版本
    uint16_t bcu_com_sta;              //< BCU通信状态
    int16_t  cluster_vol;              //< 簇端电压
    int16_t  cluster_curr;             //< 簇端电流
    uint16_t cluster_SOC;              //< 簇端SOC
    uint16_t pos_bus_ins_imped;        //< 正母线绝缘阻抗
    uint16_t neg_bus_Ins_Imped;        //< 负母线绝缘阻抗
    int16_t  hig_vol_ele_box_tmper[4]; //< 高压箱温度T1-T4
    uint16_t pack_num_in_cluster;      //< 簇内PACK数量
    uint16_t bat_num_in_pack;          //< PACK内电芯数量
    uint16_t total_bat_num;            //< 总电芯数量
    uint16_t tmper_num_in_pack;        //< PACK内温度个数
    uint16_t total_tmper_num;          //< 总温度个数
    int16_t  bat_max_vol[3];           //< 单簇最高单体电压前三Umax1-3
    int16_t  bat_min_vol[3];           //< 单簇最低单体电压前三Umin1-3
    uint16_t bat_max_vol_id;           //< 单簇最高单体电压的电池节号
    uint16_t bat_min_vol_id;           //< 单簇最低单体电压的电池节号
    int16_t  bat_mean_vol;             //< 单体电压平均值Umean
    int16_t  bat_max_tmper[3];         //< 单簇最高单体温度前三Tmax1-3
    int16_t  bat_min_tmper[3];         //< 单簇最低单体温度前三Tmin1-3
    uint16_t bat_max_tmper_id;         //< 单簇最高单体温度的电池节号
    uint16_t bat_min_tmper_id;         //< 单簇最低单体温度的电池节号
    int16_t  bat_mean_tmper;           //< 单体温度平均值Tmean
    uint16_t bat_max_SOC[3];           //< 单簇最高单体SOC前三SOCmax1-3
    uint16_t bat_min_SOC[3];           //< 单簇最低单体SOC前三SOCmin1-3
    uint16_t bat_max_SOC_id;           //< 单簇最高单体SOC的电池节号
    uint16_t bat_min_SOC_id;           //< 单簇最低单体SOC的电池节号
    uint16_t bat_mean_SOC;             //< 单体SOC平均值SOCmean
    uint16_t bat_max_SOH[3];           //< 单簇最高单体SOH前三SOHmax1-3
    uint16_t bat_min_SOH[3];           //< 单簇最高单体SOH前三SOHmin1-3
    uint16_t bat_max_SOH_id;           //< 单簇最高单体SOH的电池节号
    uint16_t bat_min_SOH_id;           //< 单簇最低单体SOH的电池节号
    uint16_t bat_mean_SOH;             //< 单体SOH平均值
    mb_pack_info_t pack_info[ PACK_NUM_IN_CLUSTER ];   //< PACK 信息
    mb_pole_tmper_t pack_pole[ PACK_NUM_IN_CLUSTER ];  //< PACK 极柱温度
} mb_cluster_info_t;

 


typedef mb_cluster_info_t mb_cluster_data_t;
#define MODBUS_MEAS_USR_CLUSTER1_DAT_ADDR             10401
#define MODBUS_MEAS_USR_CLUSTER2_DAT_ADDR             11241
#define MODBUS_MEAS_USR_CLUSTER3_DAT_ADDR             12101
#define MODBUS_MEAS_USR_CLUSTER4_DAT_ADDR             13001
#define MODBUS_MEAS_USR_CLUSTER5_DAT_ADDR             13901
#define MODBUS_MEAS_USR_CLUSTER6_DAT_ADDR             14801
#define MODBUS_MEAS_USR_CLUSTERn_DAT_ADDR_LIST        { MODBUS_MEAS_USR_CLUSTER1_DAT_ADDR, MODBUS_MEAS_USR_CLUSTER2_DAT_ADDR, \
                                                        MODBUS_MEAS_USR_CLUSTER3_DAT_ADDR, MODBUS_MEAS_USR_CLUSTER4_DAT_ADDR, \
                                                        MODBUS_MEAS_USR_CLUSTER5_DAT_ADDR, MODBUS_MEAS_USR_CLUSTER6_DAT_ADDR }
#define MODBUS_MEAS_USR_CLUSTERn_DAT_ADDR_RANGE_SIZE        835

#define MODDUS_MEAS_CLUSTERn_POLE_ADDR( cluster_dat_base_addr )  ( cluster_dat_base_addr \
                                                                +  GET_MODBUS_ADDR_OFFSET( mb_cluster_data_t, pack_pole[0] ) ) 
#define MODDUS_MEAS_CLUSTERn_PACKn_INFO_ADDR( cluster_dat_base_addr, pack_idx )  ( cluster_dat_base_addr \
                                                                +  GET_MODBUS_ADDR_OFFSET( mb_cluster_data_t, pack_info[pack_idx] ) ) 


#define MODBUS_MEAS_USR_PCS_POWER_SETTING_BASE           16301
#define MODBUS_MEAS_USR_PCS_POWER_SETTING_END            16310

#define MODBUS_MEAS_USR_PCS_POWER_DATA_BASE              16311
#define MODBUS_MEAS_USR_PCS_POWER_DATA_END               16500

#define MODBUS_MEAS_USR_PCS_DEV_INFO_BASE               16501
#define MODBUS_MEAS_USR_PCS_DEV_INFO_END                16560



#endif
