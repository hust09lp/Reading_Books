#include <errno.h>
#include <unistd.h>
#include <arpa/inet.h> 
#include "data_shm.h"
#include "sdk_shm.h"
#include "command_parser.h"
#include "modbus-private.h"
#include "sdk_public.h"
#include "sci_task.h"
#include "sdk_fs.h"
#include "cmu_command_parser.h"
#include "app_common.h"
#include "param_record.h"
#include "sdk_net_public.h"
#include "sdk_log.h"
#include "sofar_type.h"


#ifndef MAX_TRY_COUNT
#define MAX_TRY_COUNT 5
#endif
#ifndef POWERSET_FUNCID
#define POWERSET_FUNCID 0x2001
#endif

#define MODBUS_TEST 0

#define TEST_START_ADDR	65000
#define TEST_MODE_ADDR	65008
#define TEST_DO_ADDR	65009
#define TEST_DI_ADDR	65010
#define TEST_COMMUNI_ADDR	65011
#define TEST_USB_SD_ADDR	65013
#define TEST_ACB_ON_ADDR	65016
#define TEST_ACB_OFF_ADDR	65017
#define TEST_FAN_CTRL_ADDR	65018
#define TEST_END_ADDR	65536

#define CMU_INFO_ADDR_START  0x4301
#define CMU_INFO_ADDR_END  0x431D


#define PATH_GPIO	"/sys/class/gpio/"
#define PATH_GPIO_EXPORT	"/sys/class/gpio/export"

#if (0)
#define MODBUS_DEBUG_LOG(format, ...) log_i((const int8_t*)format, ##__VA_ARGS__)
#else
#define MODBUS_DEBUG_LOG(...) {do {} while(0);}
#endif

#if (0)
#define MODBUS_DEBUG_LOG_DATA(...) printf(__VA_ARGS__)
#else
#define MODBUS_DEBUG_LOG_DATA(...) {do {} while(0);}
#endif

extern common_data_t *shm;
int32_t Master_fd=0;

factory_test_data_t factory_data = {0};
static uint8_t eth_test_flag = 0;

//功能回调
typedef int32_t (*func_cb)(modbus_frame_t *modbus_frame, uint16_t *data_buff);

typedef struct
{
    uint16_t start_addr;
    uint16_t end_addr;
    func_cb  p_func_cb;
}modbus_func_table_t;

int32_t modbus_reply_csu_fault_info(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_combiner_cabinet_status_info(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_combiner_cabinet_fault_info(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_user_container_fault_info(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_user_battery_fault_info(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_user_pcs_fault_info(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_user_csu_system_info(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_admin_cabinet_system_info(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_user_cmu_system_info(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_user_container_system_info(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_user_battery_cluster_info(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_user_battery_cluster_info2(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_admin_csu_param_info(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_admin_system_param_info(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_admin_ems_param_info(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_admin_cmu_param_info(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_admin_container_param_info(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_admin_battery_param_info(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_user_pcs_param_info(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_user_pcs_dev_info(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_safety_param_info(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_user_pcs_power_data_info(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_csu_remote_ctrl(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_admin_cmu_remote_ctrl_info(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_admin_battery_remote_ctrl_info(modbus_frame_t *modbus_frame, uint16_t *data_buff);
int32_t modbus_reply_admin_pcs_remote_ctrl_info(modbus_frame_t *modbus_frame, uint16_t *data_buff);

#include "proto_addr.h"

cmu_iec_mb_addr_t cmu_iec_mb_addr_list[] = CMU_IEC_MB_ADDR_LIST;

static modbus_func_table_t modbus_func_table[] = {
	//遥信地址
    //储能系统
    {CSU_SYS_FAULT_INFO_ADDR_START,           CSU_SYS_FAULT_INFO_ADDR_END,           modbus_reply_csu_fault_info},
    {COMBINER_CABINET_STATUS_INFO_ADDR_START, COMBINER_CABINET_STATUS_INFO_ADDR_END, modbus_reply_combiner_cabinet_status_info},
    {COMBINER_CABINET_FAULT_INFO_ADDR_START,  COMBINER_CABINET_FAULT_INFO_ADDR_END,  modbus_reply_combiner_cabinet_fault_info},
    // //储能柜
    // {CMU_SYS_FAULT_INFO_ADDR_START,           ENERGY_CABINET_FAULT_INFO_ADDR_END,           modbus_reply_user_container_fault_info},//一次性获取
    //电池簇#1
    // {BCU1_STATUS_INFO_ADDR_START,              BCU_STATUS_INFO_ADDR_END,              modbus_reply_user_battery_fault_info},//一次性获取
    //PCS
    // {PCS_FAULT_INFO_ADDR_START,               PCS_FAULT_INFO_ADDR_END,               modbus_reply_user_pcs_fault_info},
    //遥测
    {USER_CSU_SYSTEM_ADDR_START,               USER_CSU_SYSTEM_ADDR_END,               modbus_reply_user_csu_system_info},
    {ADMIN_SYSTEM_CABINET_ADDR_START,               ADMIN_SYSTEM_CABINET_ADDR_END,               modbus_reply_admin_cabinet_system_info},
    // {USER_CMU_SYSTEM_ADDR_START,               USER_CMU_SYSTEM_ADDR_END,               modbus_reply_user_cmu_system_info},
    // {USER_CONTAINER_SYSTEM_ADDR_START,               USER_CONTAINER_SYSTEM_ADDR_END,               modbus_reply_user_container_system_info},
    // {USER_BATTERY_CLUSTER_ADDR_START,               USER_BATTERY_CLUSTER_ADDR_END,               modbus_reply_user_battery_cluster_info},
    // {USER_BATTERY2_CLUSTER_ADDR_START,               USER_BATTERY6_CLUSTER_ADDR_END,               modbus_reply_user_battery_cluster_info2},
    {ADMIN_CSU_CONSTANT_PARAM_ADDR_START,               ADMIN_CSU_CONSTANT_PARAM_ADDR_END,               modbus_reply_admin_csu_param_info},
    {ADMIN_SYSTEM_CONSTANT_PARAM_ADDR_START,               ADMIN_SYSTEM_CONSTANT_PARAM_ADDR_END,               modbus_reply_admin_system_param_info},
    {ADMIN_EMS_CONSTANT_PARAM_ADDR_START,               ADMIN_EMS_CONSTANT_PARAM_ADDR_END,               modbus_reply_admin_ems_param_info},
    // {ADMIN_CMU_CONSTANT_PARAM_ADDR_START,               ADMIN_CMU_CONSTANT_PARAM_ADDR_END,               modbus_reply_admin_cmu_param_info},
    // {ADMIN_CONTAINER_CONSTANT_PARAM_ADDR_START,               ADMIN_CONTAINER_CONSTANT_PARAM_ADDR_END,               modbus_reply_admin_container_param_info},
    // {ADMIN_BATTERY_CONSTANT_PARAM_ADDR_START,               ADMIN_BATTERY_CONSTANT_PARAM_ADDR_END,               modbus_reply_admin_battery_param_info},
    // {MB_MEAS_USER_PCS_PARAM_ADDR_START,               MB_MEAS_USER_PCS_PARAM_ADDR_END,               modbus_reply_user_pcs_param_info},
    // {MB_MEAS_USER_PCS_POWER_DATA_ADDR_START,               MB_MEAS_USER_PCS_POWER_DATA_ADDR_END,               modbus_reply_user_pcs_power_data_info},
    // {MB_MEAS_USER_PCS_DEV_INFO_ADDR_START,               MB_MEAS_USER_PCS_DEV_INFO_ADDR_END,               modbus_reply_user_pcs_dev_info},

	//遥控
	{ADMIN_SYSTEM_REMOTE_CONTROL_ADDR_START,               ADMIN_SYSTEM_REMOTE_CONTROL_ADDR_END,               modbus_reply_csu_remote_ctrl},
};

/**
 * @brief  系统相关命令执行
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
static int32_t sdk_system_cmd(void * cmd)
{
    FILE *fp = NULL;

    if((fp=popen((char*)cmd, "r")) == NULL)
    {
        printf("[%s:%s:%d] %s, cmd:%s\n", __FILE__,__func__, __LINE__, strerror(errno), (char*)cmd);
        return -1;
    }
    pclose(fp);

    return 0;
}

/**
 * @brief  获取当前客户端句柄
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t get_Master_fd(void)
{
	return Master_fd;
}

/**
 * @brief  设置当前客户端句柄
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
void set_Master_fd(int32_t fd)
{
	Master_fd = fd;
}

int32_t sync_time_to_cmu(modbus_frame_t *modbus_frame,sdk_rtc_t *time)
{
    int32_t rc = 0;
    uint8_t data[MODBUS_MAX_MESSAGE_LENGTH] = {0};
    uint16_t address = 0, start_index = 0;
    uint16_t ms = 0;

    data[start_index++] = (uint8_t)(address & 0xff);  //最低位
    data[start_index++] = (uint8_t)((address/0x100) & 0xff);  //中间位
    data[start_index++] = (uint8_t)((address/0x10000) & 0xff);
    
    ms = time->tm_sec;
    ms *= 1000;
    
    data[start_index++] = (uint8_t)ms;//毫秒低位
    data[start_index++] = (uint8_t)(ms>>8);//毫秒高位
    data[start_index++] = time->tm_min;
    data[start_index++] = time->tm_hour;
    data[start_index++] = time->tm_day;
    data[7] = (uint8_t) ((data[7] & 0x1f) | ((time->tm_weekday & 0x07) << 5));//星期与日是同一U8表示
    data[start_index++] = time->tm_mon;
    data[start_index++] = time->tm_year;
    
    rc = modbusTCPToIEC104(modbus_frame->slave, 1, (uint8_t*)data, start_index, 103);
    return rc;
}
/**
 * @brief  定值参数设置处理
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t constant_param_set(modbus_frame_t *modbus_frame, modbus_constant_param_info_t *constatnt_param)
{
    int i = 0;
    int j = 0;
    int32_t rc = MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    system_param_t system_param;
    sdk_rtc_t time = {0};
    web_control_info_t *p_web_control = shm_web_control_info_get();
    // 适配定值参数片发
    memcpy(&system_param, &shm->constant_parameter_data.system_param, sizeof(system_param_t));
    for (i = modbus_frame->address; i < modbus_frame->address + modbus_frame->reg_num; i++)
    {
        if (i >= ADMIN_CSU_CONSTANT_PARAM_ADDR_START && i <= ADMIN_CSU_CONSTANT_PARAM_ADDR_END)
        {
            memcpy(&(shm->constant_parameter_data.sys_param_data.storage_duration_operation_data), &constatnt_param->system_param.sys_param.storage_duration_operation_data, sizeof(system_parameter_data_t));
            dev_param_save();
            dev_param_save();
            rc = 0;
            //设置时间
            if(modbus_frame->address + modbus_frame->reg_num > 0x8007)
            {
                time.tm_year = constatnt_param->system_param.sys_time.tm_year - 2000;
                time.tm_mon = constatnt_param->system_param.sys_time.tm_mon;
                time.tm_day = constatnt_param->system_param.sys_time.tm_day;
                time.tm_hour = constatnt_param->system_param.sys_time.tm_hour;
                time.tm_min = constatnt_param->system_param.sys_time.tm_min;
                time.tm_sec = constatnt_param->system_param.sys_time.tm_sec;
                rc = sdk_rtc_set(RTC_BIN_FORMAT, &time);
                if(rc == 0)
                {
                    BIT_SET(p_web_control->system_param_flag, 2);
                    rc = sync_time_to_cmu(modbus_frame,&time);
                }
                
            }
            i = ADMIN_CSU_CONSTANT_PARAM_ADDR_END + 1;
            
        }
        else if (i >= ADMIN_SYSTEM_CONSTANT_PARAM_ADDR_START && i <= ADMIN_SYSTEM_CONSTANT_PARAM_ADDR_END)
        {
            if (i >= ADMIN_SYSTEM_CONSTANT_PARAM_ADDR_START && i <= (ADMIN_SYSTEM_CONSTANT_PARAM_ADDR_START + 1) )
            {
                /* 有功功率/无功功率 */
                for(j = 0; j < MAX_TRY_COUNT; j++)
                {
                    rc = set_constant_data( FUNCID_SET_POWER, (uint16_t*)&constatnt_param->admin_system_param.active_power, 
                                            MEMBER_DAT_NUM_CAL( &constatnt_param->admin_system_param.active_power, &constatnt_param->admin_system_param.reactive_power ));
                    if(rc == 0)
                    {
                        memcpy(&(shm->constant_parameter_data.cabinet_param_data.active_power), &constatnt_param->admin_system_param.active_power, 
                                MEMBER_DAT_LEN_CAL( &constatnt_param->admin_system_param.active_power, &constatnt_param->admin_system_param.reactive_power ));
                        break;
                    }
                    usleep(200 * 1000);
                }
            }
            else if (i >= ( ADMIN_SYSTEM_CONSTANT_PARAM_ADDR_START + 10 ) && i <= (ADMIN_SYSTEM_CONSTANT_PARAM_ADDR_START + 12) )
            {
                /* 储能柜个数 / RS485通信设备使能 / 应用场景设定 */
                for(j = 0; j < MAX_TRY_COUNT; j++)
                {
                    rc = set_constant_data( FUNCID_SET_CONST_PARAM, (uint16_t*)&constatnt_param->admin_system_param.energy_storage_nums, 
                                            MEMBER_DAT_NUM_CAL( &constatnt_param->admin_system_param.energy_storage_nums, &constatnt_param->admin_system_param.humidity_diff_set ));
                    if(rc == 0)
                    {
                        memcpy(&(shm->constant_parameter_data.cabinet_param_data.energy_storage_nums), &constatnt_param->admin_system_param.energy_storage_nums, 
                                MEMBER_DAT_LEN_CAL( &constatnt_param->admin_system_param.energy_storage_nums, &constatnt_param->admin_system_param.humidity_diff_set ));
                        break;
                    }
                    usleep(200 * 1000);
                }
            }
            else if (i >= ( ADMIN_SYSTEM_CONSTANT_PARAM_ADDR_START + 15 ) && i <= (ADMIN_SYSTEM_CONSTANT_PARAM_ADDR_START + 16) )
            {
                /* 汇流柜湿度设定 / 汇流柜湿度回差设定 */
                for(j = 0; j < MAX_TRY_COUNT; j++)
                {
                    rc = set_constant_data( FUNCID_SET_CONST_PARAM, (uint16_t*)&constatnt_param->admin_system_param.energy_storage_nums, 
                                            MEMBER_DAT_NUM_CAL( &constatnt_param->admin_system_param.energy_storage_nums, &constatnt_param->admin_system_param.humidity_diff_set ));
                    if(rc == 0)
                    {
                        memcpy(&(shm->constant_parameter_data.cabinet_param_data.energy_storage_nums), &constatnt_param->admin_system_param.energy_storage_nums, 
                                MEMBER_DAT_LEN_CAL( &constatnt_param->admin_system_param.energy_storage_nums, &constatnt_param->admin_system_param.humidity_diff_set ));
                        break;
                    }
                    usleep(200 * 1000);
                }
            }
            else if (i >= ( ADMIN_SYSTEM_CONSTANT_PARAM_ADDR_START + 2 ) && i <= (ADMIN_SYSTEM_CONSTANT_PARAM_ADDR_START + 9) )
            {
                /* PCS运行模式设置 / bus电压给定值设定(恒压源模式) / 恒流源电流给定(恒流源模式) / 功率因数给定
                   PCS无功模式设定 / PCS CEI016模式设定 / PCS系统功率分配方式 / 功率软启动速率 【不支持】*/
                /* 直接拷贝 */
                memcpy(&(shm->constant_parameter_data.cabinet_param_data.pcs_operation_mode), &constatnt_param->admin_system_param.pcs_operation_mode, 
                        MEMBER_DAT_LEN_CAL( &constatnt_param->admin_system_param.pcs_operation_mode, &constatnt_param->admin_system_param.power_soft_start_rate ));

            }else{
                /* PCS低功耗模式使能 / PCS进入低功耗模式等待时间 */
                /* 其他【不支持】，直接拷贝 */
                memcpy(&(shm->constant_parameter_data.cabinet_param_data.pcs_low_power_enable), &constatnt_param->admin_system_param.pcs_low_power_enable, 
                        MEMBER_DAT_LEN_CAL( &constatnt_param->admin_system_param.pcs_low_power_enable, &constatnt_param->admin_system_param.pcs_low_power_wait_time ));
                memset(&(shm->constant_parameter_data.cabinet_param_data.reserver), 0, sizeof(shm->constant_parameter_data.cabinet_param_data.reserver) );
            }

            // memcpy(&system_param.cabinet_param.active_power, &constatnt_param->admin_system_param.active_power, sizeof(admin_system_param_info_t));
            // for(j = 0; j < MAX_TRY_COUNT; j++)
            // {
            //     rc = set_constant_data(POWERSET_FUNCID, (uint16_t*)&system_param, sizeof(system_param)/2);
            //     if(rc == 0)
            //     {
            //         memcpy(&(shm->constant_parameter_data.cabinet_param_data.active_power), &constatnt_param->admin_system_param.active_power, sizeof(admin_system_param_info_t));
            //         break;
            //     }
            //     usleep(200 * 1000);
            // }
        }
        else if (i >= ADMIN_EMS_CONSTANT_PARAM_ADDR_START && i <= ADMIN_EMS_CONSTANT_PARAM_ADDR_END)
        {
            memcpy(&(shm->web_control_info.ems_data.demand_resp_en), &constatnt_param->ems_data.demand_resp_en, sizeof(ems_data_t) + sizeof(ems_holiday_data_t));
            rc = set_ems_data();
            rc = set_holiday_ems_data();
            i = ADMIN_EMS_CONSTANT_PARAM_ADDR_END + 1;
        }
        else
        {
            rc = MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
            break;
        }
    }

    return rc;
}

/**
 * @brief  用户遥控命令执行处理
 * @param   
 * @note    该函数被modbus_analysis函数调用
 * @return  0-成功，其它-失败原因
 */
int32_t user_remote_ctrl_set(modbus_frame_t *modbus_frame, uint16_t value)
{
    uint16_t address = 0, i, start_index = 0;
    uint8_t data[MODBUS_MAX_MESSAGE_LENGTH] = {0};

    if(modbus_frame->address == USER_SYSTEM_REMOTE_CONTROL_ADDR_START)//远程开关机
    {
        //printf("Modbus-TCP Remote power on/off\n");
        address = 0x6011;
    }
    else if(modbus_frame->address == USER_SYSTEM_REMOTE_CONTROL_ADDR_START + 1)    // 故障复位
    {
        //printf("Modbus-TCP Fault reset\n");
        address = 0x6013;
    }
    else
    {
        //printf("Modbus-TCP remote error!\n");
        return 2;
    }

    switch (modbus_frame->function)
    {
        case MODBUS_FC_WRITE_SINGLE_REGISTER:
        {
            data[start_index] = (uint8_t)(address & 0xff);  //最低位
            data[start_index+1] = (uint8_t)((address/0x100) & 0xff);  //中间位
            data[start_index+2] = (uint8_t)((address/0x10000) & 0xff);
            data[start_index+3] = value&0xFF;
            address++;
            break;
        }

        default:
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
    }
    for(i=0; i<MODBUS_CURRENT_CMU_NUM; i++)
    {
        modbus_frame_t control_frame = {0};

        memcpy(&control_frame, modbus_frame, sizeof(control_frame));
        control_frame.slave = i+MODBUS_CURRENT_CMU_NUM + MODBUS_DEVICE_ADDR_CSU;
        send_cmu_remoteCtrl(&control_frame, (uint16_t*)data);
    }

    return 0;
}

int32_t cmu_remote_ctrl(modbus_frame_t *modbus_frame,uint16_t addr,uint16_t value)
{
    int32_t rc = 0;
	uint8_t data[MODBUS_MAX_MESSAGE_LENGTH] = {0};
	uint16_t address = addr;
	data[0] = (uint8_t)(address & 0xff);  //最低位
    data[1] = (uint8_t)((address/0x100) & 0xff);  //中间位
    data[2] = (uint8_t)((address/0x10000) & 0xff);
	data[3] &= ~(1 << 7);//遥控执行;
	
	if(0 == value)
	{
		data[3] &= ~(1 << 0);//0;
	}
	else
	{
		data[3] |= 1 << 0;//1;
	}
	rc = modbusTCPToIEC104(modbus_frame->slave, 1, data, 4, 45);
    return rc;
}

/**
 * @brief  用户遥控命令执行处理
 * @param   
 * @note    该函数被modbus_analysis函数调用
 * @return  0-成功，其它-失败原因
 */
int32_t csu_remote_ctrl_set(modbus_frame_t *modbus_frame, modbus_csu_remote_ctrl_t* value)
{
	int32_t rc = 0;
	system_param_t temp = {0};
	constant_parameter_data_t * p_param = sdk_shm_constant_parameter_data_get();
	memcpy(&temp,&p_param->system_param,sizeof(system_param_t));

	web_control_info_t *p_web_data = shm_web_control_info_get();
    switch (modbus_frame->function)
    {
        case MODBUS_FC_WRITE_SINGLE_REGISTER:
        {
        	if(modbus_frame->address == 0x6001)
        	{
        		if(value->remote_power == 1)//开关机
	            {
					rc = cmu_remote_ctrl(modbus_frame,0x6011,1);
					p_web_data->control_cmd_flag |= 1 << 1;
	            	p_web_data->control_cmd_data.run_state = 1;
					
	            }
				else
				{
					rc = cmu_remote_ctrl(modbus_frame,0x6011,0);
					p_web_data->control_cmd_flag |= 1 << 1;
            		p_web_data->control_cmd_data.run_state = 0; 
				}
        	}

			if(modbus_frame->address == 0x6002)//故障复位
        	{
        		if(value->fault_reset == 1)
	            {
					rc = cmu_remote_ctrl(modbus_frame,0x6013,1);
					p_web_data->control_cmd_flag |= 1 << 0;
	            	p_web_data->control_cmd_data.reset = 1;
	            }
				else
				{
					rc = cmu_remote_ctrl(modbus_frame,0x6013,0);
					p_web_data->control_cmd_flag |= 1 << 0;
	            	p_web_data->control_cmd_data.reset = 0;
				}
        	}

            if(modbus_frame->address == 0x6003)//清除历史数据
            {
                if(value->clear_data == 1)
                {
                    rc = cmu_remote_ctrl(modbus_frame,0x6015,1);
                    log_i((int8_t *)"[%s:%d] modbus clear data \n",__func__, __LINE__);
                    system("rm -rf /user/data/event/*;rm -rf /user/data/power/*;rm -rf /user/data/energy/*;");
                    sdk_system_cmd("sync");
                    sleep(1);
                    sdk_system_cmd("reboot -f");
                }
                else
                {
                    rc = cmu_remote_ctrl(modbus_frame,0x6015,0);
                }
            }
            if(modbus_frame->address == 0x6005)
            {
                if(value->discon_shunt == 1)//汇流柜分励脱扣器断开
                {
                    BIT_SET(p_web_data->control_cmd_flag, 4);
                    value->discon_shunt = 0;
                }
            }
            if(modbus_frame->address == 0x6006)
            {
                if(value->fan_ctrl == 1)//汇流柜风扇
                {
                    BIT_SET(p_web_data->control_cmd_flag, 7);
                }
                else
                {
                    BIT_CLR(p_web_data->control_cmd_flag, 7);
                }
            }
            break;
        }

        default:
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
    }

    return rc;
}


/**
 * @brief  设备系统参数应答处理
 * @param   
 * @note    该函数被modbus_analysis函数调用
 * @return  0-成功，其它-失败原因
 */
static int32_t modbus_reply_user_device_system_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t offset_addr = 0, i, j;
    uint16_t max_length = 0;
    device_system_param_t device_system = {0};
    sdk_rtc_t time = {0};

    offset_addr = modbus_frame->address - USER_DEVICE_SYSTEM_ADDR_START;
    max_length = sizeof(device_system_param_t);
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d]  slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    if (offset_addr < 0 || (offset_addr + modbus_frame->reg_num)*2 > max_length) 
    {
        return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }
    //printf("TEST!!!");

    //从共享内存中组合出与modbus点表顺序相同的结构体
    sdk_rtc_get(RTC_BIN_FORMAT, &time);
    MODBUS_DEBUG_LOG("[%s:%d] %04d.%02d.%02d, %02d:%02d:%02d\n",__func__, __LINE__,  time.tm_year+2000,time.tm_mon, time.tm_day,time.tm_hour,time.tm_min,time.tm_sec);
    device_system.tm_year = time.tm_year+2000;
    device_system.tm_mon = time.tm_mon;
    device_system.tm_day = time.tm_day;
    device_system.tm_hour = time.tm_hour;
    device_system.tm_min = time.tm_min;
    device_system.tm_sec = time.tm_sec;

    memcpy(data_buff, &device_system, sizeof(device_system_param_t)); 

    switch (modbus_frame->function)
    {
        case MODBUS_FC_READ_HOLDING_REGISTERS:
        case MODBUS_FC_READ_INPUT_REGISTERS: 
        {
            memcpy(data_buff, data_buff + offset_addr, modbus_frame->reg_num * 2); 
            break;
        }
        case MODBUS_FC_WRITE_MULTIPLE_REGISTERS:
        {
            if(((modbus_frame->address >= USER_DEVICE_SYSTEM_ADDR_START) && (modbus_frame->address <= USER_DEVICE_SYSTEM_ADDR_START+6)) && (modbus_frame->reg_num != 6))// 时间必须6个寄存器连写
            {
                return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
            }
            //printf("req data:%x, %x, %x, %x, %x, %x, %x\n", modbus_frame->req[0],modbus_frame->req[1],modbus_frame->req[2],modbus_frame->req[3],modbus_frame->req[4],modbus_frame->req[5], modbus_frame->offset);
            for (i = offset_addr, j = 6; i < (offset_addr + modbus_frame->reg_num); i++, j += 2) {
               /* 6 and 7 = first value */
                data_buff[i] = (modbus_frame->req[modbus_frame->offset + j] << 8) + modbus_frame->req[modbus_frame->offset + j + 1];
                //printf("change data:%x\n", data_buff[i]);
            }
            memcpy(&device_system, data_buff, sizeof(device_system_param_t));
            time.tm_year = device_system.tm_year - 2000;
            time.tm_mon = device_system.tm_mon;
            time.tm_day = device_system.tm_day;
            time.tm_hour = device_system.tm_hour;
            time.tm_min = device_system.tm_min;
            time.tm_sec = device_system.tm_sec;
            if(0 != sdk_rtc_set(RTC_BIN_FORMAT, &time))
            {
                return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
            }
            /*同步时钟到CMU*/
            uint16_t address = 0, start_index = 0, ms;
            modbus_frame_t syn_frame = {0};
            uint8_t data[MODBUS_MAX_MESSAGE_LENGTH] = {0};

            data[start_index++] = (uint8_t)(address & 0xff);  //最低位
            data[start_index++] = (uint8_t)((address/0x100) & 0xff);  //中间位
            data[start_index++] = (uint8_t)((address/0x10000) & 0xff);
            ms = time.tm_sec;
            ms *= 1000;
            data[start_index++] = (uint8_t)ms;
            data[start_index++] = (uint8_t)(ms>>8);
            data[start_index++] = time.tm_min;
            data[start_index++] = time.tm_hour;
            data[start_index++] = time.tm_day;
            data[start_index++] = time.tm_mon;
            data[start_index++] = time.tm_year;
            memcpy(&syn_frame, modbus_frame, sizeof(syn_frame));
            for(i=0; i<MODBUS_CURRENT_CMU_NUM; i++)
            {
                syn_frame.slave = i + MODBUS_CURRENT_CMU_NUM + MODBUS_DEVICE_ADDR_CSU;
                send_cmu_clock_syn(&syn_frame, (uint16_t*)data);
            }
            break;
        }

        default:
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
    }
    
    return 0;
}

/**
 * @brief  CSU系统信息应答处理
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_user_csu_system_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t offset_addr = 0, *p_data = NULL, i;
    uint16_t max_length = 0;
    csu_system_telemetry_info_t csu_system_info = {0};
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();

    offset_addr = modbus_frame->address - USER_CSU_SYSTEM_ADDR_START;
    max_length = sizeof(csu_system_telemetry_info_t);
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d]  slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

	//该地址段数据只支持读取
	if((modbus_frame->function != MODBUS_FC_READ_HOLDING_REGISTERS) && (modbus_frame->function != MODBUS_FC_READ_INPUT_REGISTERS))
	{
		return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
	}
	
    if (offset_addr < 0 || (offset_addr + modbus_frame->reg_num) * 2 > max_length) 
    {
        return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }

    #if 0
        shm->telemetry_data.sys_version_telemetry_info.hardware_version_number = 100;
        shm->telemetry_data.sys_version_telemetry_info.mcu2_software_version_number = 200;
        shm->telemetry_data.sys_version_telemetry_info.max_reactive_power = 300;
    #endif
    //从共享内存中组合出与modbus点表顺序相同的结构体
    memcpy(&csu_system_info, &(shm->telemetry_data.sys_version_telemetry_info), sizeof(csu_system_telemetry_info_t)); 
    /*以下参数参考104做法为固定值*/
    csu_system_info.system_power = 1250;
    csu_system_info.max_active_power = 1375;
    csu_system_info.max_reactive_power = 1250;
    csu_system_info.max_apparent_power = 1375;
    for(i=0; i<sizeof(csu_system_info.sn_version_number)/sizeof(csu_system_info.sn_version_number[0]); i++)
    {
        csu_system_info.sn_version_number[i] = htons(csu_system_info.sn_version_number[i]);// 高低字节互换
    }

    csu_system_info.system_sta = p_telemetry_data->sys_version_telemetry_info.csu_sys_state;
    csu_system_info.ext_communication_protocol_version = htons(p_telemetry_data->sys_version_telemetry_info.ext_communication_protocol_version);
    MODBUS_DEBUG_LOG( "sys_version_telemetry_info.csu_sys_state:%d\r\n", p_telemetry_data->sys_version_telemetry_info.csu_sys_state );

    //p_data = &csu_system_info.hardware_version_number;
   // memcpy(data_buff, p_data + offset_addr, modbus_frame->reg_num * 2); 

	switch (modbus_frame->function)
    {
        case MODBUS_FC_READ_HOLDING_REGISTERS:
        case MODBUS_FC_READ_INPUT_REGISTERS: 
        {
            p_data = &csu_system_info.hardware_version_number;
   		    memcpy(data_buff, p_data + offset_addr, modbus_frame->reg_num * 2); 
            break;
        }
        case MODBUS_FC_WRITE_SINGLE_REGISTER:
        case MODBUS_FC_WRITE_MULTIPLE_REGISTERS:
        {
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
        }

        default:
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
    }
    
    return 0;
}

/**
 * @brief  储能系统故障信息应答处理
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_user_system_fault_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t offset_addr = 0, *p_data = NULL;
    uint16_t max_length = 0, buff[100] = {0};
    uint8_t i;
    int32_t rc;
    user_system_fault_warn_status_info_t system_fault_info = {0};

    offset_addr = modbus_frame->address - USER_SYSTEM_FAULT_ADDR_START;
    max_length = sizeof(user_system_fault_warn_status_info_t);
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d]  slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    if (offset_addr < 0 || (offset_addr + modbus_frame->reg_num) * 2 > max_length) 
    {
        return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }

    #if MODBUS_TEST
        shm->telematic_data.csu_system_fault_info[0] |= 0x20;
        shm->telematic_data.combiner_cabinet_system_status_info[0] |= 0x01; // 运行状态
        shm->telematic_data.combiner_cabinet_system_status_info[2] |= 0x01; // 远程急停故障状态
        shm->telematic_data.combiner_cabinet_system_fault_info[0] |= 0x40;  // 监控板温度传感器故障（1级）
        shm->telematic_data.combiner_cabinet_system_fault_info[4] |= 0x08;  // PCS模块机型读取错误（3级）
    #endif
    //从共享内存中组合出与modbus点表顺序相同的结构体
    MODBUS_DEBUG_LOG("run status:%x", shm->telematic_data.combiner_cabinet_system_status_info[0]);
    system_fault_info.system_fault.first_addr_info_u.system_fault_info = (shm->telematic_data.csu_system_fault_info[0] >> 4) & 0x0F;

    //system_fault_info.system_status.first_addr_info_u.bit.running_state = (shm->telematic_data.combiner_cabinet_system_status_info[0] >> 0) & 0x01;
    for(i=0; i<MODBUS_CURRENT_CMU_NUM; i++)
    {
        modbus_frame_t read_frame = {0};

        read_frame.address = 0x271F;
        read_frame.reg_num = 1;
        read_frame.slave = i+MODBUS_CURRENT_CMU_NUM + MODBUS_DEVICE_ADDR_CSU;

        rc = modbus_reply_single_data(&read_frame, buff); //读取CMU状态
        if(rc != 0) // 读取不到数据则默认为0
        {
            buff[0] = 0;
        }
        MODBUS_DEBUG_LOG("CMU state:%x", buff[0]);
        if((buff[0] == 1) || (buff[0] == 2)) //CMU系统状态是1或2
        {
            system_fault_info.system_status.first_addr_info_u.bit.running_state = 1;
        }
        else
        {
            system_fault_info.system_status.first_addr_info_u.bit.running_state = 0;
            break;
        }
    }    
    //printf("csu_system_fault_info:%x\n", shm->telematic_data.csu_system_fault_info[0]);
    //shm->telematic_data.csu_system_fault_info[0] |= 0x010;

    system_fault_info.system_fault.first_addr_info_u.system_fault_info = (shm->telematic_data.csu_system_fault_info[0] >> 4) & 0x0F; // SCI通信故障（3级）..
    system_fault_info.system_status.first_addr_info_u.bit.cabinet_fault_state = (shm->telematic_data.combiner_cabinet_system_status_info[1] >> 7) & 0x01;
    system_fault_info.system_status.first_addr_info_u.bit.remote_stop_fault_state = (shm->telematic_data.combiner_cabinet_system_status_info[2] >> 0) & 0x01;
    system_fault_info.system_warn.first_addr_info_u.bit.monitorBoardOverTempWarnFirst = (shm->telematic_data.combiner_cabinet_system_fault_info[0] >> 0) & 0x01;
    system_fault_info.system_warn.first_addr_info_u.bit.monitorBoardOverTempProtectThird = (shm->telematic_data.combiner_cabinet_system_fault_info[0] >> 2) & 0x01;
    system_fault_info.system_warn.first_addr_info_u.bit.monitorBoardUnderTempProtectFirst = (shm->telematic_data.combiner_cabinet_system_fault_info[0] >> 4) & 0x01;
    system_fault_info.system_warn.first_addr_info_u.bit.monitorBoardTempSensorFaultFirst = (shm->telematic_data.combiner_cabinet_system_fault_info[0] >> 6) & 0x01;
    system_fault_info.system_warn.first_addr_info_u.bit.cabinetFaultFirst = (shm->telematic_data.combiner_cabinet_system_fault_info[2] >> 0) & 0x01;
    system_fault_info.system_warn.first_addr_info_u.bit.remoteREPOFaultThird = (shm->telematic_data.combiner_cabinet_system_fault_info[2] >> 1) & 0x01;
    system_fault_info.system_warn.first_addr_info_u.bit.MeasureMeterDisconnectFirst = (shm->telematic_data.combiner_cabinet_system_fault_info[3] >> 6) & 0x01;
    system_fault_info.system_warn.first_addr_info_u.bit.antiRefluxMeterDisconnectFirst = (shm->telematic_data.combiner_cabinet_system_fault_info[3] >> 7) & 0x01;
    system_fault_info.system_warn.first_addr_info_u.bit.microComputerDisconnectFirst = (shm->telematic_data.combiner_cabinet_system_fault_info[4] >> 0) & 0x01;
    system_fault_info.system_warn.first_addr_info_u.bit.measurDeviceDisconnectFirst = (shm->telematic_data.combiner_cabinet_system_fault_info[4] >> 2) & 0x01;
    system_fault_info.system_warn.first_addr_info_u.bit.pcsModelErrorThird = (shm->telematic_data.combiner_cabinet_system_fault_info[4] >> 3) & 0x01;
    system_fault_info.system_warn.first_addr_info_u.bit.antiRefluxFailedFirst = (shm->telematic_data.combiner_cabinet_system_fault_info[4] >> 4) & 0x01;

    p_data = (uint16_t*)&system_fault_info;
    //MODBUS_DEBUG_LOG("data address: %x, buf address = %x, off addr=%x, sys addr=%x", (uint32_t)p_data, (uint32_t)data_buff, (uint32_t)&offset_addr, (uint32_t)&system_fault_info);
    memcpy(data_buff, p_data + offset_addr, modbus_frame->reg_num * 2); 

    return 0;
}

/**
 * @brief  储能系统参数应答处理
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_user_system_param_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint32_t i,j;
    int32_t rc = 0;
    uint16_t data = 0, *p_data = NULL;
    uint16_t offset_addr = 0;
    uint16_t max_length = 0;
    modbus_constant_param_info_t constant_param;

    offset_addr = modbus_frame->address - USER_SYSTEM_CONSTANT_PARAM_ADDR_START;
    max_length = sizeof(user_system_param_info_t);
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d]  slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    if (offset_addr < 0 || (offset_addr + modbus_frame->reg_num) * 2 > max_length) 
    {
        return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }
    
    #if MODBUS_TEST
        shm->constant_parameter_data.cabinet_param_data.active_power = 100;
        shm->constant_parameter_data.cabinet_param_data.reactive_power = -100;
    #endif
    //从共享内存中组合出与modbus点表顺序相同的结构体
    memcpy(&constant_param.user_system_param.active_power, &(shm->constant_parameter_data.cabinet_param_data.active_power), sizeof(user_system_param_info_t));
    memcpy(data_buff, &constant_param.user_system_param.active_power, sizeof(user_system_param_info_t));

    switch (modbus_frame->function)
    {
        case MODBUS_FC_READ_HOLDING_REGISTERS:
        case MODBUS_FC_READ_INPUT_REGISTERS: 
        {
            p_data = (uint16_t*)&constant_param.user_system_param.active_power;
            memcpy(data_buff, p_data + offset_addr, modbus_frame->reg_num * 2);
            break;
        }
        case MODBUS_FC_WRITE_SINGLE_REGISTER:
        {
            data = (modbus_frame->req[modbus_frame->offset + 3] << 8) + modbus_frame->req[modbus_frame->offset + 4];

            data_buff[offset_addr] = data;
            memcpy(&constant_param.user_system_param.active_power, data_buff, sizeof(user_system_param_info_t));
            rc = constant_param_set(modbus_frame, &constant_param);
            break;
        }
        case MODBUS_FC_WRITE_MULTIPLE_REGISTERS:
        {
            for (i = offset_addr, j = 6; i < (offset_addr + modbus_frame->reg_num); i++, j += 2) {
               /* 6 and 7 = first value */
                data_buff[i] = (modbus_frame->req[modbus_frame->offset + j] << 8) + modbus_frame->req[modbus_frame->offset + j + 1];
            }
            memcpy(&constant_param.user_system_param.active_power, data_buff, sizeof(user_system_param_info_t));
            rc = constant_param_set(modbus_frame, &constant_param);
            break;
        }

        default:
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
    }

    return rc;
}

/**
 * @brief  储能系统遥控
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_user_system_remote_ctrl_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t value = 0;
    uint16_t offset_addr = 0;
    uint16_t max_length = 0;

    offset_addr = modbus_frame->address - USER_SYSTEM_REMOTE_CONTROL_ADDR_START;
    max_length = sizeof(csu_system_telemetry_info_t);
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d]  slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    if (offset_addr < 0 || (offset_addr + modbus_frame->reg_num) > max_length) 
    {
        return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }

    switch (modbus_frame->function)
    {
        case MODBUS_FC_WRITE_SINGLE_REGISTER:
        {
            value = (modbus_frame->req[modbus_frame->offset + 3] << 8) + modbus_frame->req[modbus_frame->offset + 4];

            user_remote_ctrl_set(modbus_frame, value);
            break;
        }

        default:
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
    } 

    return 0;
}

/**
 * @brief  协议兼容信息应答处理
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_user_protocol_compatible_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    user_protocol_compatible_info_t protocol_compatible;

    if(modbus_frame->reg_num != 1)
    {
        return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
    }
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d] slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    protocol_compatible.protocol_effective_version = PROTOCOL_EFFECTIVE_VERSION;

    memcpy(data_buff, &protocol_compatible, sizeof(user_protocol_compatible_info_t));
    
    return 0; 
}

/**
 * @brief  MCU2实时信息应答处理
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_admin_cabinet_system_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t offset_addr = 0;
    uint16_t max_length = 0;
	uint16_t len = 0;
	modbus_mcu2_realtime_data_t mcu2_data = {0};

    offset_addr = modbus_frame->address - ADMIN_SYSTEM_CABINET_ADDR_START;
    max_length = sizeof(modbus_mcu2_realtime_data_t);
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d]  slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);


	//该地址段数据只支持读取
	if((modbus_frame->function != MODBUS_FC_READ_HOLDING_REGISTERS) && (modbus_frame->function != MODBUS_FC_READ_INPUT_REGISTERS))
	{
		return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
	}
	
    if (offset_addr < 0 || (offset_addr + modbus_frame->reg_num) > max_length) 
    {
        return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }

    #if MODBUS_TEST
        shm->telemetry_data.sys_cabinet_telemetry_info.system_status = 1;           // 系统运行状态
        shm->telemetry_data.sys_cabinet_telemetry_info.total_run_time = 1234;       // 汇流柜总运行时间
        shm->telemetry_data.sys_cabinet_telemetry_info.anti_reflux_power = -124;    // 防逆流电表功率
    #endif
    //MODBUS_DEBUG_LOG("TESTMODBUS temp=%x\n", shm->telemetry_data.sys_cabinet_telemetry_info.csu_board_temperature);
    //从共享内存中组合出与modbus点表顺序相同的结构体
    //memcpy(&cabinet_telemetry_info, &(shm->telemetry_data.sys_cabinet_telemetry_info.system_status), sizeof(sys_cabinet_telemetry_info_t)); 
	len = GET_MEMBER_OFFSET(modbus_mcu2_realtime_data_t, meter_data);
	memcpy(&mcu2_data, &(shm->telemetry_data.sys_cabinet_telemetry_info.system_status), len); 
	memcpy(&(mcu2_data.meter_data), &(shm->internal_shared_data.total_realtime_energy.meter_data), sizeof(modbus_meter_energy_data_t));
    memcpy(&(mcu2_data.dry_temp), &(shm->telemetry_data.sys_cabinet_telemetry_info.dry_temp), sizeof(uint16_t) * 4);
    //p_data = &cabinet_telemetry_info.system_status;
    //memcpy(data_buff, p_data + offset_addr, modbus_frame->reg_num * 2);

	switch (modbus_frame->function)
    {
        case MODBUS_FC_READ_HOLDING_REGISTERS:
        case MODBUS_FC_READ_INPUT_REGISTERS: 
        {
            //p_data = &cabinet_telemetry_info.system_status;
            uint16_t seq_id = offset_addr + 1;
            uint16_t *p_mcu2_dat = &mcu2_data.system_status;
            uint16_t *p_cap_dat  = (uint16_t*)&sdk_shm_get()->internal_shared_data.sys_capacity;

            for (size_t i = 0; i < modbus_frame->reg_num; i++, seq_id++)
            {
                if ( seq_id >= 1 && seq_id <= 114 )
                {
                    data_buff[i] = p_mcu2_dat[ seq_id - 1 ];
                }
                else if ( seq_id >= 115 && seq_id <= 140 )
                {
                    data_buff[i] = p_cap_dat[ seq_id - 115 ];
                }
            }
            
            // p_data = &mcu2_data.system_status;
    		// memcpy(data_buff, p_data + offset_addr, modbus_frame->reg_num * 2); 

            break;
        }
        case MODBUS_FC_WRITE_SINGLE_REGISTER:
        case MODBUS_FC_WRITE_MULTIPLE_REGISTERS:
        {
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
        }

        default:
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
    }
    
    return 0;
}

/**
 * @brief  储能系统故障信息应答处理
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_admin_system_fault_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t offset_addr = 0, *p_data = NULL;
    uint16_t max_length = 0;
    admin_system_fault_info_t system_fault_info = {0};

    offset_addr = modbus_frame->address - ADMIN_SYSTEM_FAULT_ADDR_START;
    max_length = sizeof(admin_system_fault_info_t);
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d]  slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    if (offset_addr < 0 || (offset_addr + modbus_frame->reg_num) * 2 > max_length) 
    {
        return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }

    #if MODBUS_TEST
        shm->telematic_data.csu_system_fault_info[0] |= 0x03;                   // USB故障（1级）SD卡故障（1级）
        shm->telematic_data.combiner_cabinet_system_status_info[0] |= 0x70;     // STS状态输出常开开入量-AC SPD故障状态
        shm->telematic_data.combiner_cabinet_system_fault_info[1] |= 0x74;      // AC SPD故障（1级）,风扇1故障（1级）风扇2故障（1级）绝缘监测设备故障（1级）
    #endif
    //从共享内存中组合出与modbus点表顺序相同的结构体
    memcpy(&system_fault_info.system_fault_info, &(shm->telematic_data.csu_system_fault_info), CSU_SYSTEM_FAULT_LEN_BYTE);
    memcpy(&system_fault_info.system_status_info, &(shm->telematic_data.combiner_cabinet_system_status_info), COMBINER_CABINET_SYSTEM_STATUS_LEN_BYTE);
    memcpy(&system_fault_info.system_warn_info, &(shm->telematic_data.combiner_cabinet_system_fault_info), COMBINER_CABINET_SYSTEM_FAULT_LEN_BYTE);

    p_data = (uint16_t*)&system_fault_info;
    memcpy(data_buff, p_data + offset_addr, modbus_frame->reg_num * 2);
    
    return 0;
}

/**
 * @brief  CSU系统参数应答处理
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_admin_csu_param_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint32_t i,j;
    int32_t rc = 0;
    uint16_t data = 0, *p_data = NULL;
    uint16_t offset_addr = 0;
    uint16_t max_length = 0;
    modbus_constant_param_info_t constant_param = {0};
    sdk_rtc_t time = {0};
    offset_addr = modbus_frame->address - ADMIN_CSU_CONSTANT_PARAM_ADDR_START;
    max_length = sizeof(modbus_system_parameter_data_t);
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d]  slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    if (offset_addr < 0 || (offset_addr + modbus_frame->reg_num) * 2 > max_length) 
    {
        return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }
    
    #if MODBUS_TEST
        shm->constant_parameter_data.sys_param_data.storage_duration_operation_data = 140;
    #endif

    sdk_rtc_get(RTC_BIN_FORMAT, &time);
    MODBUS_DEBUG_LOG("[%s:%d] %04d.%02d.%02d, %02d:%02d:%02d\n",__func__, __LINE__,  time.tm_year+2000,time.tm_mon, time.tm_day,time.tm_hour,time.tm_min,time.tm_sec);
    constant_param.system_param.sys_time.tm_year = time.tm_year+2000;
    constant_param.system_param.sys_time.tm_mon = time.tm_mon;
    constant_param.system_param.sys_time.tm_day = time.tm_day;
    constant_param.system_param.sys_time.tm_hour = time.tm_hour;
    constant_param.system_param.sys_time.tm_min = time.tm_min;
    constant_param.system_param.sys_time.tm_sec = time.tm_sec;

    //从共享内存中组合出与modbus点表顺序相同的结构体
    memcpy(&constant_param.system_param.sys_param.storage_duration_operation_data, &(shm->constant_parameter_data.sys_param_data.storage_duration_operation_data), sizeof(system_parameter_data_t));
	memcpy(data_buff, &constant_param.system_param.sys_param.storage_duration_operation_data, sizeof(modbus_system_parameter_data_t));
    

    switch (modbus_frame->function)
    {
        case MODBUS_FC_READ_HOLDING_REGISTERS:
        case MODBUS_FC_READ_INPUT_REGISTERS: 
        {
            p_data = &constant_param.system_param.sys_param.storage_duration_operation_data;
            memcpy(data_buff, p_data + offset_addr, modbus_frame->reg_num * 2);
            break;
        }
        case MODBUS_FC_WRITE_SINGLE_REGISTER:
        {
            data = (modbus_frame->req[modbus_frame->offset + 3] << 8) + modbus_frame->req[modbus_frame->offset + 4];

            data_buff[offset_addr] = data;
            memcpy(&constant_param.system_param.sys_param.storage_duration_operation_data, data_buff, sizeof(modbus_system_parameter_data_t));
            rc = constant_param_set(modbus_frame, &constant_param);
            break;
        }
        case MODBUS_FC_WRITE_MULTIPLE_REGISTERS:
        {
            for (i = offset_addr, j = 6; i < (offset_addr + modbus_frame->reg_num); i++, j += 2) {
               /* 6 and 7 = first value */
                data_buff[i] = (modbus_frame->req[modbus_frame->offset + j] << 8) + modbus_frame->req[modbus_frame->offset + j + 1];
            }
            memcpy(&constant_param.system_param.sys_param.storage_duration_operation_data, data_buff, sizeof(modbus_system_parameter_data_t));
            rc = constant_param_set(modbus_frame, &constant_param);
            break;
        }

        default:
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
    }
    
    return rc;
}

/**
 * @brief  CSU遥控应答处理
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_csu_remote_ctrl(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    int32_t rc = 0;
    uint16_t data = 0;
    uint16_t offset_addr = 0;
    uint16_t max_length = 0;
	modbus_csu_remote_ctrl_t sys_remote_ctrl;

    offset_addr = modbus_frame->address - ADMIN_SYSTEM_REMOTE_CONTROL_ADDR_START;
    max_length = sizeof(modbus_csu_remote_ctrl_t);
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d]  slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    if (offset_addr < 0 || (offset_addr + modbus_frame->reg_num) * 2 > max_length) 
    {
        return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }
    

    switch (modbus_frame->function)
    {
        case MODBUS_FC_READ_HOLDING_REGISTERS:
        case MODBUS_FC_READ_INPUT_REGISTERS: 
        {
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
        }
        case MODBUS_FC_WRITE_SINGLE_REGISTER:
        {
            data = (modbus_frame->req[modbus_frame->offset + 3] << 8) + modbus_frame->req[modbus_frame->offset + 4];

            data_buff[offset_addr] = data;
            memcpy(&sys_remote_ctrl, data_buff, sizeof(modbus_csu_remote_ctrl_t));
            rc = csu_remote_ctrl_set(modbus_frame, &sys_remote_ctrl);
            break;
        }
        case MODBUS_FC_WRITE_MULTIPLE_REGISTERS:
        {
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
        }

        default:
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
    }
    
    return rc;
}


/**
 * @brief  储能系统参数应答处理
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_admin_system_param_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint32_t i,j;
    int32_t rc = 0;
    uint16_t data = 0, *p_data = NULL;
    uint16_t offset_addr = 0;
    uint16_t max_length = 0;
    modbus_constant_param_info_t constant_param;

    offset_addr = modbus_frame->address - ADMIN_SYSTEM_CONSTANT_PARAM_ADDR_START;
    max_length = sizeof(cabinet_parameter_data_t);
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d]  slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);

    if (offset_addr < 0 || (offset_addr + modbus_frame->reg_num) * 2 > max_length) 
    {
        return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }

    #if MODBUS_TEST
        shm->constant_parameter_data.cabinet_param_data.pcs_operation_mode = 1;         // PCS运行模式设置
        shm->constant_parameter_data.cabinet_param_data.pcs_low_power_wait_time = 10;   // PCS等待进入低功耗模式时间
    #endif
    //从共享内存中组合出与modbus点表顺序相同的结构体
    memcpy(&constant_param.admin_system_param.active_power, &(shm->constant_parameter_data.cabinet_param_data.active_power), sizeof(admin_system_param_info_t));

    memcpy(data_buff, &constant_param.admin_system_param.active_power, sizeof(admin_system_param_info_t));

    switch (modbus_frame->function)
    {
        case MODBUS_FC_READ_HOLDING_REGISTERS:
        case MODBUS_FC_READ_INPUT_REGISTERS:
            p_data = (uint16_t*)&constant_param.admin_system_param.active_power;
            memcpy(data_buff, p_data + offset_addr, modbus_frame->reg_num * 2); 
            break;
        case MODBUS_FC_WRITE_SINGLE_REGISTER:
        {
            data = (modbus_frame->req[modbus_frame->offset + 3] << 8) + modbus_frame->req[modbus_frame->offset + 4];

            data_buff[offset_addr] = data;
            memcpy(&constant_param.admin_system_param.active_power, data_buff, sizeof(admin_system_param_info_t));
            rc = constant_param_set(modbus_frame, &constant_param);
            break;
        }
        case MODBUS_FC_WRITE_MULTIPLE_REGISTERS:
        {
            for (i = offset_addr, j = 6; i < (offset_addr + modbus_frame->reg_num); i++, j += 2) {
               /* 6 and 7 = first value */
                data_buff[i] = (modbus_frame->req[modbus_frame->offset + j] << 8) + modbus_frame->req[modbus_frame->offset + j + 1];
            }
            memcpy(&constant_param.admin_system_param.active_power, data_buff, sizeof(admin_system_param_info_t));
            rc = constant_param_set(modbus_frame, &constant_param);
            break;
        }

        default:
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
            break;
    }
    
    return rc;
}

/**
 * @brief  EMS参数应答处理
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_admin_ems_param_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    int32_t rc = 0;
    uint32_t i,j;
    uint16_t data = 0, *p_data = NULL;
    uint16_t offset_addr = 0;
    uint16_t max_length = 0;
    modbus_constant_param_info_t constant_param;

    offset_addr = modbus_frame->address - ADMIN_EMS_CONSTANT_PARAM_ADDR_START;
    max_length = sizeof(ems_data_t) + sizeof(ems_holiday_data_t);
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d]  slave[%d],func[%d],address[%d],recv_length[%d] max_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num,max_length);
	#if 1
    if (offset_addr < 0 || (offset_addr + modbus_frame->reg_num) * 2 > max_length + 6) //少了3个参数，临时+6
    {
        return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }
	#endif
    #if MODBUS_TEST
        shm->constant_parameter_data.ems_data.demand_resp_en = 1;       // 需求侧相应使能
        shm->constant_parameter_data.ems_data.poweron_early_time = 10;  // 提前开机时间
    #endif
    //从共享内存中组合出与modbus点表顺序相同的结构体
    memcpy(&constant_param.ems_data.demand_resp_en, &(shm->constant_parameter_data.ems_data.demand_resp_en), sizeof(ems_data_t) + sizeof(ems_holiday_data_t));

    memcpy(data_buff, &constant_param.ems_data.demand_resp_en, sizeof(ems_data_t) + sizeof(ems_holiday_data_t));

    switch (modbus_frame->function)
    {
        case MODBUS_FC_READ_HOLDING_REGISTERS:
        case MODBUS_FC_READ_INPUT_REGISTERS:
            p_data = &constant_param.ems_data.demand_resp_en;
            memcpy(data_buff, p_data + offset_addr, modbus_frame->reg_num * 2);
            break;
        case MODBUS_FC_WRITE_SINGLE_REGISTER:
        {
            data = (modbus_frame->req[modbus_frame->offset + 3] << 8) + modbus_frame->req[modbus_frame->offset + 4];

            data_buff[offset_addr] = data;
            memcpy(&constant_param.ems_data.demand_resp_en, data_buff, sizeof(ems_data_t) + sizeof(ems_holiday_data_t));
            rc = constant_param_set(modbus_frame, &constant_param);
            break;
        }
        case MODBUS_FC_WRITE_MULTIPLE_REGISTERS:
        {
            for (i = offset_addr, j = 6; i < (offset_addr + modbus_frame->reg_num); i++, j += 2) {
               /* 6 and 7 = first value */
                data_buff[i] = (modbus_frame->req[modbus_frame->offset + j] << 8) + modbus_frame->req[modbus_frame->offset + j + 1];
            }
            memcpy(&constant_param.ems_data.demand_resp_en, data_buff, sizeof(ems_data_t) + sizeof(ems_holiday_data_t));
            rc = constant_param_set(modbus_frame, &constant_param);
            break;
        }

        default:
            return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
            break;
    }
    
    return rc;
}
/**
 * @brief  储能系统故障参数应答处理
 * @param   
 * @note    该函数被modbus_analysis函数调用
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_csu_fault_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t *p_data = NULL;
    telematic_data_t *p_telematic_data = NULL;

    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d]  slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);
    p_telematic_data = sdk_shm_telematic_data_get();
	//该地址段数据只支持读取
	if((modbus_frame->function != MODBUS_FC_READ_HOLDING_REGISTERS) && (modbus_frame->function != MODBUS_FC_READ_INPUT_REGISTERS))
	{
		return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
	}
	
    if (modbus_frame->reg_num * 2 > sizeof(p_telematic_data->csu_system_fault_info)) 
    {
        return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }

    p_data = (uint16_t*)&p_telematic_data->csu_system_fault_info;
    memcpy(data_buff, p_data, modbus_frame->reg_num * 2); 

    return 0;
}


/**
 * @brief  汇流柜系统运行状态应答处理
 * @param   
 * @note    该函数被modbus_analysis函数调用
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_combiner_cabinet_status_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t *p_data = NULL;
    uint16_t offset_addr;
    telematic_data_t *p_telematic_data = NULL;

    offset_addr = modbus_frame->address - COMBINER_CABINET_STATUS_INFO_ADDR_START;
    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d]  slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);
    p_telematic_data = sdk_shm_telematic_data_get();

	//该地址段数据只支持读取
	if((modbus_frame->function != MODBUS_FC_READ_HOLDING_REGISTERS) && (modbus_frame->function != MODBUS_FC_READ_INPUT_REGISTERS))
	{
		return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
	}
	
    if (modbus_frame->reg_num * 2 > sizeof(p_telematic_data->combiner_cabinet_system_status_info)) 
    {
        return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }

    p_data = (uint16_t*)&p_telematic_data->combiner_cabinet_system_status_info;
    memcpy(data_buff, p_data + offset_addr, modbus_frame->reg_num * 2); 

    return 0;
}

/**
 * @brief  汇流柜系统故障状态应答处理
 * @param   
 * @note    该函数被modbus_analysis函数调用
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_combiner_cabinet_fault_info(modbus_frame_t *modbus_frame, uint16_t *data_buff)
{
    uint16_t *p_data = NULL;
    telematic_data_t *p_telematic_data = NULL;

    MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d]  slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,modbus_frame->slave,modbus_frame->function,modbus_frame->address,modbus_frame->reg_num);
    p_telematic_data = sdk_shm_telematic_data_get();

	//该地址段数据只支持读取
	if((modbus_frame->function != MODBUS_FC_READ_HOLDING_REGISTERS) && (modbus_frame->function != MODBUS_FC_READ_INPUT_REGISTERS))
	{
		return MODBUS_EXCEPTION_ILLEGAL_FUNCTION;
	}
	
    if (modbus_frame->reg_num * 2 > sizeof(p_telematic_data->combiner_cabinet_system_fault_info)) 
    {
        return MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }

    p_data = (uint16_t*)&p_telematic_data->combiner_cabinet_system_fault_info;
    memcpy(data_buff, p_data, modbus_frame->reg_num * 2); 

    return 0;
}

#if 1

/**
 * @brief  产测USB测试
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t usb_check()
{
	int16_t ret = -1;
	//struct stat file_path_check = {0};
	//ret = stat("/media/sda1/firmware/", &file_path_check);
	//ret = sdk_fs_access("/media/sda1/firmware/", F_OK);
 	ret = sdk_fs_access((const int8_t*)"/media/sda1/", F_OK);
	return ret;
}

/**
 * @brief  产测SD卡测试
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t sd_card_check()
{
	int16_t ret = -1;
	//struct stat file_path_check = {0};
	//ret = stat("/media/mmcblk0p1", &file_path_check);
	ret = sdk_fs_access((const int8_t*)"/media/mmcblk0p1", F_OK);
	return ret;
}

/**
 * @brief  产测获取IO状态
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t get_gpio(int32_t num)
{
	int32_t ret = 0;
	fs_t *p_fs = NULL;
	char buf[32]={0};
	int8_t path[64]={0};

	snprintf((char*)path, 64,"%sgpio%d",PATH_GPIO,num);
	ret = sdk_fs_access(path, F_OK);
    if (ret == -1) 
    {
		MODBUS_DEBUG_LOG("\n [%s:%d] %sFolder does not exist!!! \n", __func__, __LINE__,path);
		// GPIO文件夹不存在，需导出该GPIO
		
		p_fs = sdk_fs_open( (const int8_t*)PATH_GPIO_EXPORT, FS_WRITE);
		snprintf(buf, 32,"%d",num);
        sdk_fs_write(p_fs, buf, strlen(buf));
		//sdk_fs_write(p_fs, &num, 4);
		sdk_fs_close(p_fs);

		snprintf(buf, 64,"%sgpio%d/direction",PATH_GPIO,num);
		p_fs = sdk_fs_open(path, FS_WRITE);
        sdk_fs_write(p_fs, "in", strlen("in"));
		sdk_fs_close(p_fs);		
    }
	
	

	snprintf((char*)path, 64,"%sgpio%d/value",PATH_GPIO,num);
	p_fs = sdk_fs_open(path, FS_READ);
		
	ret = sdk_fs_read(p_fs, buf, 1);
	if (ret != 1)
	{
		MODBUS_DEBUG_LOG("\n [%s:%d] read error!\n", __func__, __LINE__);
		sdk_fs_close(p_fs);
		return -1;
	}else
	{
		MODBUS_DEBUG_LOG("\n [%s:%d] value = %d\n", __func__, __LINE__,atoi(buf));
	}	

	sdk_fs_close(p_fs);
	return atoi(buf);
		
}

/**
 * @brief  产测更改IO输出
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t set_gpio(int32_t num,int8_t value)
{
	int32_t ret = 0;
	fs_t *p_fs = NULL;
	char buf[32]={0};
	int8_t path[64]={0};


	snprintf((char*)path, 64,"%sgpio%d",PATH_GPIO,num);
	ret = sdk_fs_access(path, F_OK);
    if (ret == -1) 
    {
		MODBUS_DEBUG_LOG("\n [%s:%d] %sFolder does not exist!!! \n", __func__, __LINE__,path);
		// GPIO文件夹不存在，需导出该GPIO
		
		p_fs = sdk_fs_open((const int8_t*) PATH_GPIO_EXPORT, FS_WRITE);
		snprintf(buf, 32,"%d",num);
        sdk_fs_write(p_fs, buf, strlen(buf));
		//sdk_fs_write(p_fs, &num, 4);
		sdk_fs_close(p_fs);

		snprintf(buf, 64,"%sgpio%d/direction",PATH_GPIO,num);
		p_fs = sdk_fs_open(path, FS_WRITE);
        sdk_fs_write(p_fs, "out", strlen("out"));
		sdk_fs_close(p_fs);		
    }
	
	
	snprintf((char*)path, 64,"%sgpio%d/value",PATH_GPIO,num);
	printf("path %s\n",path);
	p_fs = sdk_fs_open(path, FS_WRITE);
		
	if (value)
	{
		ret = sdk_fs_write(p_fs, "1", 1);
	}
	else
	{
		ret = sdk_fs_write(p_fs, "0", 1);
	}
	
	sdk_fs_close(p_fs);
	
	if (ret < 1)
	{
		MODBUS_DEBUG_LOG("\n [%s:%d] write error!\n", __func__, __LINE__);
	
		return -1;
	}

	return 0;
}

/**
 * @brief  产测-网口测试
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int test_ethx(int dev_name)
{
  	char buf[LINE_MAX] = {0};
  	char cmd[LINE_MAX] = {0};
  	FILE *fp = NULL;

	if (0 == dev_name)
	{
		snprintf(cmd, LINE_MAX, "ifconfig eth1 down");
	}else if(1 == dev_name)
	{
		snprintf(cmd, LINE_MAX, "ifconfig eth0 down");
	}else
	{
		return -1;
	}

	//printf("%s \n",cmd);
	if ((fp = popen(cmd, "r")) == NULL)
	{
		return -1;
  	}else{
		pclose(fp);
  	}

	
/**/

	if (0 == dev_name)
	{
		
		snprintf(cmd, LINE_MAX, "ping -c 4 -w 3 -I eth0 192.168.1.120 | grep \"packet loss\" | awk '{print $7}' | tr -d '%%'");
	}
	else
	{
		sleep(3);
		snprintf(cmd, LINE_MAX, "ping -c 4 -w 3 -I eth1 192.168.1.120 | grep \"packet loss\" | awk '{print $7}' | tr -d '%%'");
	}

	//printf("%s \n",cmd);
  	if ((fp = popen(cmd, "r")) == NULL)
  	{
    	return -1;
  	}

  	while (fgets(buf, LINE_MAX, fp));
	pclose(fp);


	if (0 == dev_name)
	{
		snprintf(cmd, LINE_MAX, "ifconfig eth1 up");
	}else if(1 == dev_name)
	{
		snprintf(cmd, LINE_MAX, "ifconfig eth0 up");
	}else
	{
		return -1;
	}
  
	if ((fp = popen(cmd, "r")) == NULL)
	{
		return -1;
  	}else{
		pclose(fp);
  	}


	printf("buf %s-------\n",buf);
	if ((atoi(buf) > 80) || (strlen(buf) == 0))
	{
		return -1;
	}

	return 1;
}



/**
 * @brief  do检测
 * @param  [in] ctrl ： 指定测试哪几个do口 b0~b8:DO5,DO7,DO8~DO14  1:闭合 0:断开
 * @param  [out] none
 * @return 0：成功；-1：失败
 */
int32_t do_check(uint16_t ctrl)
{

	int8_t value = 0;

	value = (ctrl >> 0) & 0X01;
	set_gpio(74,value);

	value = (ctrl >> 1) & 0X01;
	set_gpio(69,value);

	value = (ctrl >> 2) & 0X01;
	set_gpio(80,value);

	value = (ctrl >> 3) & 0X01;
	set_gpio(71,value);

	value = (ctrl >> 4) & 0X01;
	set_gpio(72,value);

	value = (ctrl >> 5) & 0X01;
	set_gpio(77,value);

	value = (ctrl >> 6) & 0X01;
	set_gpio(74,value);

	value = (ctrl >> 7) & 0X01;
	set_gpio(79,value);	
	
	value = (ctrl >> 8) & 0X01;
	set_gpio(78,value);	

	return 0;
	
}

/**
 * @brief  di检测
 * @param  [in] none
 * @param  [out] none
 * @return di口状态值，1：闭合 0：断开 b0~b8: DI17~DI25
 */
uint16_t di_check()
{


	int32_t value;
	int32_t ret = 0;

	value = get_gpio(70);
	ret |= value;
	
	value = get_gpio(64);
	ret |= value << 1;  
  
	value = get_gpio(65);
	ret |= value << 2; 

	value = get_gpio(115);
	ret |= value << 3; 	

	value = get_gpio(116);
	ret |= value << 4; 

	value = get_gpio(66);
	ret |= value << 5;

	value = get_gpio(67);
	ret |= value << 6; 

	value = get_gpio(68);
	ret |= value << 7;

	value = get_gpio(137);
	ret |= value << 8;	

	printf("di_check ret %x\n",ret);
	return ret;
}

/**
 * @brief  ETH检测
 * @param  [in] none
 * @param  [out] none
 * @return 网口测试结果，0：成功 -1：失败
 */

int32_t ETH_check()
{
	
	if (-1 == test_ethx(0))
	{
		return -1;
	}


	if (-1 == test_ethx(1))
	{
		return -1;
	}

	printf("ETH_check OK \n");

	return 0;	
}

/**
 * @brief  产测更改net相关参数
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
static void modify_net_conf(uint8_t device, void *p_ip, void *p_netmask, void *p_gw, void *p_dns1, void *p_dns2)
{

   if(sdk_net_ip_set(device, (uint8_t *)p_ip) < 0)
   {
        MODBUS_DEBUG_LOG("set ip failed");
        return;
   }

   if(sdk_net_subnetmask_set(device, (uint8_t *)p_netmask) < 0)
   {
        MODBUS_DEBUG_LOG("set subnet mask failed");
        return;
   }

   if(sdk_net_gateway_set(device, (uint8_t *)p_gw) < 0)
   {
        MODBUS_DEBUG_LOG("set gateway failed");
        return;
   }

   if(sdk_net_dns_set(device, (uint8_t *)p_dns1)< 0)
   {
        MODBUS_DEBUG_LOG("set dns1 failed");
        return;
   }
 
}

/**
 * @brief  产测写相关功能实现，
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_write_factory_config_info(const uint8_t *req, factory_test_data_t *ctx)
{
	int32_t rc = 0;
    uint16_t address = 0;
    //uint16_t length = 0;
    //uint16_t address_end = 0;
    //machine_info_t *p_data = &(shm->modbus_data.machine_info);
    //struct tm temp_tm;
    //int8_t rctmp1 = 0, rctmp2 = 0, rctmp3 = 0;

    address = (req[2] << 8) + req[3]; 
    //length = (req[4] << 8) + req[5]; 
	//if(req[1] == MODBUS_FC_WRITE_SINGLE_REGISTER)
	//{
	//	length = 1;
	//}
    //address_end = address + length - 1;

	if (address ==  TEST_MODE_ADDR)
	{
		if(factory_data.test_mode == 0)//
		{
			modify_net_conf(4, "192.168.2.200", "255.255.255.0", "192.168.2.1", "8.8.8.8", "114.114.114.114");
			sdk_system_cmd("rm -rf /user/data/*");
			sdk_system_cmd("rm -rf /user/www/conf/systime.json.json");                
			sdk_system_cmd("rm -rf /user/www/conf/runtimeparams.json");        
			sdk_system_cmd("rm -rf /user/www/conf/administrator.json");
			sdk_system_cmd("rm -rf /user/www/conf/operationlog");
			sdk_system_cmd("sync");
			rc = 0;
		}else if(factory_data.test_mode == 1)
		{
			modify_net_conf(4, "192.168.1.130", "255.255.255.0", "192.168.1.1", "8.8.8.8", "114.114.114.114");
			rc = 0;
		}
		
	}
	
    if(address == TEST_DO_ADDR)
    {
    	MODBUS_DEBUG_LOG("[%s:%d] do_check ctrl[%x]\n",__func__, __LINE__,factory_data.do_ctrl);
		rc = do_check(factory_data.do_ctrl);                      
    }

	if(address == TEST_COMMUNI_ADDR)
	{
		
		if(factory_data.communi_ctrl == 0x01)//CAN通讯测试
		{
			//  
			//factory_data.communi_result &= ~(1 << 0);
			sleep(1);
			//rc = CAN_check();
			//if(0 == rc)
			//{
				//factory_data.communi_result |= (1 << 1);
			//}
		}
		else if(factory_data.communi_ctrl == 0x02)//ETH通讯测试
		{
			//
			factory_data.communi_result &= ~(1 << 1);
			eth_test_flag = 1;
			
		}
		rc = 0;//通过测试结果去查询，非异常
		MODBUS_DEBUG_LOG("[%s:%d] communi_check ctrl[%x],result[%x]\n",__func__, __LINE__,factory_data.communi_ctrl,factory_data.communi_result);
	}

	if(address == TEST_USB_SD_ADDR)
	{
		
		if(factory_data.usb_ctrl == 0x01)//USB测试
		{
			//  
			factory_data.usb_result &= ~(1 << 0);
			rc = usb_check();
			if(0 == rc)
			{
				factory_data.usb_result |= (1 << 0);
			}
		}
		else if(factory_data.usb_ctrl == 0x02)//SD卡测试
		{
			//
			factory_data.usb_result &= ~(1 << 1);
			rc = sd_card_check();
			if(0 == rc)
			{
				factory_data.usb_result |= (1 << 1);
			}
			
		}
		rc = 0;//有无SD/usb，都通过测试结果去查询，非异常
		MODBUS_DEBUG_LOG("[%s:%d] USB/SD card check ctrl[%.2X],result[%.2X]\n",__func__, __LINE__,factory_data.usb_ctrl,factory_data.usb_result);
	}

	if (address ==  TEST_ACB_ON_ADDR)//ACB合闸
	{
		system_param_t temp = {0};
		constant_parameter_data_t *p_para_data = NULL;
		p_para_data = sdk_shm_constant_parameter_data_get();
		memcpy(&temp,&p_para_data->system_param,sizeof(system_param_t));
		if(factory_data.acb_on == 1)
		{
			// temp.mcu2_inter_param.acb_on = 1;
            BIT_SET( temp.remote_control_cmd, 3 );
			MODBUS_DEBUG_LOG("[%s:%d] factory test:ACB ON\n",__func__, __LINE__);
		}
		// rc = set_constant_data(FUNCID_SET_PCSC_PARM,(uint16_t*)&temp,sizeof(temp)/2); 
		rc = set_constant_data( FUNCID_SET_REMOTE_CTRL , (uint16_t*)&temp.remote_control_cmd, 1 );
	}

	if (address ==  TEST_ACB_OFF_ADDR)//ACB分闸
	{
		system_param_t temp = {0};
		constant_parameter_data_t *p_para_data = NULL;
		p_para_data = sdk_shm_constant_parameter_data_get();
		memcpy(&temp,&p_para_data->system_param,sizeof(system_param_t));
		if(factory_data.acb_off == 1)
		{
			temp.mcu2_inter_param.acb_off = 1;
            BIT_SET( temp.remote_control_cmd, 4 );
			MODBUS_DEBUG_LOG("[%s:%d] factory test:ACB OFF\n",__func__, __LINE__);
		}
		// rc = set_constant_data(FUNCID_SET_PCSC_PARM,(uint16_t*)&temp,sizeof(temp)/2); 
		rc = set_constant_data( FUNCID_SET_REMOTE_CTRL , (uint16_t*)&temp.remote_control_cmd, 1 );
	}

	if (address ==  TEST_FAN_CTRL_ADDR)//控制风扇
	{
		system_param_t temp = {0};
		constant_parameter_data_t *p_para_data = NULL;
		p_para_data = sdk_shm_constant_parameter_data_get();
		memcpy(&temp,&p_para_data->system_param,sizeof(system_param_t));
		temp.mcu2_inter_param.sys_fan = factory_data.fan_ctrl;
		MODBUS_DEBUG_LOG("[%s:%d] factory test:FAN ctrl[%d]\n",__func__, __LINE__,factory_data.fan_ctrl);
		// rc = set_constant_data(FUNCID_SET_PCSC_PARM,(uint16_t*)&temp,sizeof(temp)/2); 
	}
	
	return rc;
}

/**
 * @brief  产测相关的modbus功能
 * @param  [in] none
 * @param  [out] none
 * @return 网口测试结果，0：成功 -1：失败
 */
int32_t factory_test(modbus_t *ctx, const uint8_t *req, int32_t req_length)
{
	uint8_t offset = 0;
	uint8_t slave = 0;
	uint8_t function = 0;
	uint16_t address = 0;
	uint16_t recv_length = 0;
	uint16_t recv_bytes = 0;
	uint16_t offset_addr = 0;
	uint16_t max_length = 0;
	uint8_t rsp[MODBUS_MAX_MESSAGE_LENGTH] = {0};
	uint8_t rsp_length = 0;
	sft_t sft;
	uint16_t i, j;
	uint16_t index = 0;
    uint16_t data_buff[1500] = {0};

	int32_t rc = 0;

	if (ctx == NULL) {
		errno = EINVAL;
		return -1;
	}

	offset = ctx->backend->header_length;
	slave = req[offset - 1];
	function = req[offset];
	address = (req[offset + 1] << 8) + req[offset + 2];
	recv_length = (req[offset + 3] << 8) + req[offset + 4];
	offset_addr = address - TEST_START_ADDR;
	max_length = sizeof(factory_test_data_t);
	MODBUS_DEBUG_LOG((int8_t *)("\n [%s:%d]  offset[%d],slave[%d],func[%d],address[%d],recv_length[%d]!\n"),__func__, __LINE__,offset,slave,function,address,recv_length);

	sft.slave = slave;
	sft.function = function;
	sft.t_id = ctx->backend->prepare_response_tid(req, (int *)&req_length);

	//初始化，从共享内存中组合出与modbus点表顺序相同的结构体
	factory_data.mcu1_software_version_num = shm->telemetry_data.sys_version_telemetry_info.mcu1_software_version_number;
	factory_data.mcu1_boot_version_num = shm->telemetry_data.sys_version_telemetry_info.mcu1_boot_version_number;
	factory_data.mcu1_core_version_num = shm->telemetry_data.sys_version_telemetry_info.mcu1_core_version_number;
	factory_data.hardware_version_num = shm->telemetry_data.sys_version_telemetry_info.hardware_version_number;
	//factory_data.hardware_version_num = 2;
	//printf("factory_data.hardware_version_num[%d],shm->telemetry_data.pcs_version_telemetry_info.hardware_version_number[%d]\n",factory_data.hardware_version_num,shm->telemetry_data.pcs_version_telemetry_info.hardware_version_number);
	factory_data.run_mode = factory_data.test_mode;
	memset(data_buff,0,sizeof(data_buff));
	memcpy(data_buff, &factory_data, sizeof(factory_test_data_t)); 
	
	/* Data are flushed on illegal number of values errors. */
	switch (function) {
	case MODBUS_FC_READ_HOLDING_REGISTERS:
	case MODBUS_FC_READ_INPUT_REGISTERS: 
	{
		if (recv_length < 1 || MODBUS_MAX_READ_REGISTERS < recv_length) 
		{
			return modbus_reply_exception( ctx, req, MODBUS_EXCEPTION_ILLEGAL_DATA_VALUE);
		} 
		else if (offset_addr < 0 || (offset_addr + recv_length) > max_length) 
		{
			return modbus_reply_exception( ctx, req, MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS);
		} 
		else 
		{
			rsp_length = ctx->backend->build_response_basis(&sft, rsp);//rsp_length:2
			//memcpy(rsp, req, rsp_length);

			rsp[rsp_length++] = recv_length << 1;
			index = offset_addr + recv_length;
			if(TEST_DI_ADDR == address)//读DI数据后赋值
			{
				
				factory_data.di_ctrl = di_check();
				MODBUS_DEBUG_LOG("[%s:%d] di_check result[%x]\n",__func__, __LINE__,factory_data.di_ctrl);
				rsp[rsp_length++] = factory_data.di_ctrl >> 8;
			    rsp[rsp_length++] = factory_data.di_ctrl & 0xFF;
				offset_addr++;
			}
			
			for (i = offset_addr; i < index; i++) 
			{
				rsp[rsp_length++] = data_buff[i] >> 8;
				rsp[rsp_length++] = data_buff[i] & 0xFF;
			}
			
			
		}
	}
		break;

	case MODBUS_FC_WRITE_SINGLE_REGISTER: {
		

		if (offset_addr < 0 || offset_addr >= max_length) 
		{
			return modbus_reply_exception( ctx, req, MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS);
		} 
		else 
		{
			uint16_t data = (req[offset + 3] << 8) + req[offset + 4];

			data_buff[offset_addr] = data;
			memcpy(rsp, req, req_length);//0x06功能码，从站返回报文和主站发送请求的报文格式及数据内容一模一样。
			rsp_length = req_length;

			memcpy(&(factory_data), data_buff, sizeof(factory_test_data_t));
		   
			rc = modbus_write_factory_config_info(&req[offset - 1], &(factory_data));
			if(rc == 0)
			{
				//rsp_length = ctx->backend->build_response_basis(&sft, rsp);//rsp_length:2
				/* 4 to copy the address (2) and the no. of registers */
			   // memcpy(rsp + rsp_length, req + rsp_length, 4);
				//rsp_length += 4;
			}
			else
			{
				return modbus_reply_exception( ctx, req, MODBUS_EXCEPTION_ILLEGAL_DATA_VALUE);
			}

		}
	}
		break;
	case MODBUS_FC_WRITE_MULTIPLE_REGISTERS: {
		recv_bytes = req[offset + 5];
		if (recv_length < 1 || MODBUS_MAX_WRITE_REGISTERS < recv_length || recv_bytes != recv_length * 2)
		{
			return modbus_reply_exception( ctx, req, MODBUS_EXCEPTION_ILLEGAL_DATA_VALUE);
		} 
		else if (offset_addr < 0 || (offset_addr + recv_length) > max_length) 
		{
			return modbus_reply_exception( ctx, req, MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS);
		} 
		else 
		{
			for (i = offset_addr, j = 6; i < (offset_addr + recv_length); i++, j += 2) {
			   /* 6 and 7 = first value */
				data_buff[i] = (req[offset + j] << 8) + req[offset + j + 1];
			}
			memcpy(&(factory_data), data_buff, sizeof(factory_test_data_t));
			
			rc = modbus_write_factory_config_info(&req[offset - 1], &(factory_data));
			if(rc == 0)
			{
				rsp_length = ctx->backend->build_response_basis(&sft, rsp);//rsp_length:2
				/* 4 to copy the address (2) and the no. of registers */
				memcpy(rsp + rsp_length, req + rsp_length, 4);
				rsp_length += 4;
			}
			else
			{
				return modbus_reply_exception( ctx, req, MODBUS_EXCEPTION_ILLEGAL_DATA_VALUE);
			}
		}
	}
		break;

	default:
		return modbus_reply_exception( ctx, req, MODBUS_EXCEPTION_ILLEGAL_FUNCTION);
		break;
	}
	/* Suppress any responses when the request was a broadcast */
   // return (ctx->backend->backend_type == _MODBUS_BACKEND_TYPE_RTU &&
			//slave == MODBUS_BROADCAST_ADDRESS) ? 0 : modbus_send_raw_request(ctx, rsp, rsp_length); 
	return (ctx->backend->backend_type == _MODBUS_BACKEND_TYPE_RTU &&
			slave == MODBUS_BROADCAST_ADDRESS) ? 0 : send_msg(ctx, rsp, rsp_length); 
}
#endif

/**
 * @brief  CSU数据读取总入口,函数里面对地址进行区分（依据协议点表大类分），再调用相关处理函数，
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_info(modbus_t *ctx, modbus_frame_t *modbus_frame)
{
    uint16_t end_addr = 0;
    uint8_t rsp[MODBUS_MAX_MESSAGE_LENGTH] = {0};
    uint8_t rsp_length = 0;
    sft_t sft;
    uint16_t i;
    uint16_t data_buff[1500] = {0};
    int32_t rc = MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;

    sft.slave = modbus_frame->slave;
    sft.function = modbus_frame->function;
    sft.t_id = ctx->backend->prepare_response_tid(modbus_frame->req, (int *)&(modbus_frame->req_length));
    
    if (modbus_frame->reg_num < 1 || MODBUS_MAX_READ_REGISTERS < modbus_frame->reg_num) 
    {
        return modbus_reply_exception(ctx, modbus_frame->req, rc);
    }

    end_addr = modbus_frame->address + modbus_frame->reg_num -1;

	//遍历功能列表
    for(uint8_t i = 0; i < (sizeof(modbus_func_table) / sizeof(modbus_func_table[0])); i++)
    {
        if((modbus_frame->address >= modbus_func_table[i].start_addr) && (end_addr <= modbus_func_table[i].end_addr))
        {
            rc = modbus_func_table[i].p_func_cb(modbus_frame, data_buff);
        }
    }
	
	if((modbus_frame->address >= FACTORY_TEST_ADDR_START) && (end_addr <= FACTORY_TEST_END))//产测用寄存器
    {
        rc = factory_test(ctx, modbus_frame->req, modbus_frame->req_length);
        if(1 == eth_test_flag)
        {
            eth_test_flag = 0;
            rc = ETH_check();
            if(0 == rc)
            {
                factory_data.communi_result |= (1 << 1);
            }
        }
        return 0;
    }
    if (rc != 0)
    {
        if(rc < 0)//参数下发时可能失败，返回-1，但是异常码不能为负数
        {
            rc = MODBUS_EXCEPTION_SLAVE_OR_SERVER_FAILURE;
        }
        return modbus_reply_exception(ctx, modbus_frame->req, rc);
    }

	if(modbus_frame->function == MODBUS_FC_WRITE_SINGLE_REGISTER)//0x06功能码
	{
		rsp_length = ctx->backend->build_response_basis(&sft, rsp);
        /* 4 to copy the address (2) and the no. of registers */
        memcpy(rsp + rsp_length, modbus_frame->req + rsp_length, 4);
        rsp_length += 4;
	}
	else if(modbus_frame->function == MODBUS_FC_WRITE_MULTIPLE_REGISTERS)//0x10功能码
	{
		rsp_length = ctx->backend->build_response_basis(&sft, rsp);
        /* 4 to copy the address (2) and the no. of registers */
        memcpy(rsp + rsp_length, modbus_frame->req + rsp_length, 4);
        rsp_length += 4;
	}
	else if((modbus_frame->function == MODBUS_FC_READ_HOLDING_REGISTERS) || (modbus_frame->function == MODBUS_FC_READ_INPUT_REGISTERS))//0x03
	{
		rsp_length = ctx->backend->build_response_basis(&sft, rsp);
    	rsp[rsp_length++] = modbus_frame->reg_num << 1;

	    for (i = 0; i < modbus_frame->reg_num; i++) {
	        rsp[rsp_length++] = data_buff[i] >> 8;
	        rsp[rsp_length++] = data_buff[i] & 0xFF;
	    }
	}
    
    return (ctx->backend->backend_type == _MODBUS_BACKEND_TYPE_RTU &&
            modbus_frame->slave == MODBUS_BROADCAST_ADDRESS) ? 0 : send_msg(ctx, rsp, rsp_length); 
}

/**
 * @brief  CSU数据写总入口,函数里面对地址进行区分（依据协议点表大类分），再调用相关处理函数，
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_reply_write(modbus_t *ctx, modbus_frame_t *modbus_frame)
{
    uint16_t end_addr = 0;
    uint8_t rsp[MODBUS_MAX_MESSAGE_LENGTH] = {0};
    uint8_t rsp_length = 0;
    sft_t sft;
    uint16_t data_buff[1500] = {0};
    int32_t rc = MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;

    sft.slave = modbus_frame->slave;
    sft.function = modbus_frame->function;
    sft.t_id = ctx->backend->prepare_response_tid(modbus_frame->req, (int *)&(modbus_frame->req_length));

    if (modbus_frame->reg_num < 1 || MODBUS_MAX_READ_REGISTERS < modbus_frame->reg_num) 
    {
        return modbus_reply_exception(ctx, modbus_frame->req, rc);
    }

    end_addr = modbus_frame->address + modbus_frame->reg_num -1;
    if ((modbus_frame->address >= USER_DEVICE_SYSTEM_ADDR_START) && (end_addr <= USER_DEVICE_SYSTEM_ADDR_END))
    {
        rc = modbus_reply_user_device_system_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= USER_SYSTEM_CONSTANT_PARAM_ADDR_START) && (end_addr <= USER_SYSTEM_CONSTANT_PARAM_ADDR_END))
    {
        rc = modbus_reply_user_system_param_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= USER_SYSTEM_REMOTE_CONTROL_ADDR_START) && (end_addr <= USER_SYSTEM_REMOTE_CONTROL_ADDR_END))
    {
        rc = modbus_reply_user_system_remote_ctrl_info(modbus_frame, data_buff);
    }
#if 0
    else if ((modbus_frame->address >= ADMIN_CSU_CONSTANT_PARAM_ADDR_START) && (end_addr <= ADMIN_CSU_CONSTANT_PARAM_ADDR_END))
    {
        rc = modbus_reply_admin_csu_param_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= ADMIN_SYSTEM_CONSTANT_PARAM_ADDR_START) && (end_addr <= ADMIN_SYSTEM_CONSTANT_PARAM_ADDR_END))
    {
        rc = modbus_reply_admin_system_param_info(modbus_frame, data_buff);
    }
    else if ((modbus_frame->address >= ADMIN_EMS_CONSTANT_PARAM_ADDR_START) && (end_addr <= ADMIN_EMS_CONSTANT_PARAM_ADDR_END))
    {
        rc = modbus_reply_admin_ems_param_info(modbus_frame, data_buff);
    }
#endif
    else if((modbus_frame->address >= FACTORY_TEST_ADDR_START) && (end_addr <= FACTORY_TEST_END))//产测用寄存器
    {
        factory_test(ctx, modbus_frame->req, modbus_frame->req_length);
        if(1 == eth_test_flag)
        {
            eth_test_flag = 0;
            rc = ETH_check();
            if(0 == rc)
            {
                factory_data.communi_result |= (1 << 1);
            }
        }
    }
    else
    {
        rc = MODBUS_EXCEPTION_ILLEGAL_DATA_ADDRESS;
    }

    if(rc != 0)
    {
        return modbus_reply_exception( ctx, modbus_frame->req, rc);
    }
    
    rsp_length = ctx->backend->build_response_basis(&sft, rsp);
    /* 4 to copy the address (2) and the no. of registers */
    memcpy(rsp + rsp_length, modbus_frame->req + rsp_length, 4);
    rsp_length += 4;

    /* Suppress any responses when the request was a broadcast */
	return (ctx->backend->backend_type == _MODBUS_BACKEND_TYPE_RTU &&
            modbus_frame->slave == MODBUS_BROADCAST_ADDRESS) ? 0 : send_msg(ctx, rsp, rsp_length); 
}

#include "mem_utils.h"

/**
 * @brief  modbus协议分析总入口函数，根据读表功能码再调用相关处理函数，
 * @param   
 * @note    
 * @return  0-成功，其它-失败原因
 */
int32_t modbus_analysis(modbus_t *ctx, const uint8_t *req, int32_t req_length, modbus_mapping_t *mb_mapping)
{
    modbus_frame_t modbus_frame;

    modbus_frame.offset = ctx->backend->header_length;
    modbus_frame.address = ((req[modbus_frame.offset + 1]<<8)&0xff00)|((req[modbus_frame.offset + 2]<<0)&0x00ff);
    modbus_frame.reg_num = ((req[modbus_frame.offset + 3]<<8)&0xff00)|((req[modbus_frame.offset + 4]<<0)&0x00ff);
    modbus_frame.slave = *(req + modbus_frame.offset - 1);
	modbus_frame.function = *(req + modbus_frame.offset);
    modbus_frame.req = req;
    modbus_frame.req_length = req_length;

    if(0x06 == modbus_frame.function)//写单个寄存器
	{
		modbus_frame.reg_num = 1;
	} 
    if((modbus_frame.offset == MODBUS_TCP_FRAME_HEAD_LEN_BYTE) && ((modbus_frame.req[2] != 0) || (modbus_frame.req[3] != 0))) // 协议必须为00，表示modbus协议
    {
        modbus_reply_exception(ctx, modbus_frame.req, MODBUS_EXCEPTION_ILLEGAL_DATA_VALUE);
        return -1;
    }
    if (modbus_frame.slave < MODBUS_DEVICE_ADDR_CSU || modbus_frame.slave > MODBUS_DEVICE_ADDR_LAST_CMU)
    {
        MODBUS_DEBUG_LOG("dev addr is error.\n");
        modbus_reply_exception(ctx, modbus_frame.req, MODBUS_EXCEPTION_SLAVE_OR_SERVER_FAILURE);
        return -1;
    }
	
	// printf("[%s:%d] start_add[%04X], register_num[%d],func[%x]\n",__func__, __LINE__, modbus_frame.address,modbus_frame.reg_num,modbus_frame.function);
    // mem_utils_print_hex_dat( "\r\nmodbus recv: ", req, req_length, 10, true );
	
	// for(int i = 0;i < req_length;i++)
	// {
	// 	MODBUS_DEBUG_LOG_DATA("[%.2X]",req[i]);
	// }
	// MODBUS_DEBUG_LOG_DATA("\n");
	
    /* 转发CMU */
    bool cmu_modbus_relay = false;
    
    for(  int i = 0; i < ARRAY_SIZE( cmu_iec_mb_addr_list ); i++)
    {
        if ( modbus_frame.address >= cmu_iec_mb_addr_list[i].start_addr && modbus_frame.address <= cmu_iec_mb_addr_list[i].end_addr )
        {
            cmu_modbus_relay = true;
            break;
        }
    }   
    if ( cmu_modbus_relay )
    {
        sf_ret_t csu_modbus_cmd_relay( modbus_t *ctx, const uint8_t *req, uint16_t req_len );
        csu_modbus_cmd_relay( ctx, req, req_length);
        return;
    }

    /* 无需转发，CSU自行处理 */
    switch (modbus_frame.function)
    {
        case MODBUS_FC_READ_HOLDING_REGISTERS:
        case MODBUS_FC_WRITE_SINGLE_REGISTER:
        case MODBUS_FC_WRITE_MULTIPLE_REGISTERS:
            modbus_reply_info(ctx, &modbus_frame);
            break;

        default:
            modbus_reply_exception(ctx, req, MODBUS_EXCEPTION_ILLEGAL_FUNCTION);
            break;
    }

    return 0;
}
