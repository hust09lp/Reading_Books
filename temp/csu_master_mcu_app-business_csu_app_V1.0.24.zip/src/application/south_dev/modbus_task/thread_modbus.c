#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include "data_shm.h"
#include "sdk_shm.h"
#include "sdk_log.h"
#include "cmu_command_parser.h"
#include "command_parser.h"
#include "user_timer.h"
#include "app_common.h"
#include <netinet/in.h>
#include <ifaddrs.h>
#include <netinet/tcp.h>
#include <sys/epoll.h>
#include <arpa/inet.h>
#include "mem_utils.h"

modbus_mapping_t *mb_mapping;
static user_timer_hd g_modbus_recv_timer = NULL;

#define LOG_MODBUS_ENABLE                  0
//#define MODBUS_RTU_MAX_ADU_LENGTH          1500
#define MAX_EVENTS 10

#define EPOLL_WAIT  1 * 1000

static sf_ret_t cmu_modbus_client_init( void );
static void *cmu_modbus_client_thread( void *arg );
static int32_t cmu_modbus_reconnect( void );
static void cmu_modbus_heatbeat_probe( void );

modbus_mapping_t* get_modbus_mapping(void)
{
	return(mb_mapping);
}

void init_modbus_addr(void)
{

	mb_mapping = modbus_mapping_new_start_address(
					40000, 0,
					40000, 0,
					24000, 4096,//24000为协议寄存器地址的首地址，第二个参数为开辟的空间
					40000, 0);  
}

int32_t modbus_get_ethx(modbus_t *ctx)
{
 	int32_t ret = -1;

    int32_t sock = modbus_get_socket(ctx);

    struct sockaddr_in local_addr;
    socklen_t addr_len = sizeof(local_addr);
    if (getsockname(sock, (struct sockaddr*)&local_addr, &addr_len) == -1) {
        log_i((int8_t *)"getsockname\n");
        return -1;
    }

    char local_ip[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &local_addr.sin_addr, local_ip, sizeof(local_ip));
    log_i((int8_t *)"Local IP associated with socket: %s\n", local_ip);

    struct ifaddrs *ifaddr, *ifa;
    if (getifaddrs(&ifaddr) == -1) {
        perror("getifaddrs");
        return -1;
    }

    for (ifa = ifaddr; ifa != NULL; ifa = ifa->ifa_next) {
        if (ifa->ifa_addr == NULL) continue;
        if (ifa->ifa_addr->sa_family == AF_INET) {
            char interface_ip[INET_ADDRSTRLEN];
            struct sockaddr_in *addr = (struct sockaddr_in *)ifa->ifa_addr;
            inet_ntop(AF_INET, &addr->sin_addr, interface_ip, sizeof(interface_ip));

            if (strcmp(local_ip, interface_ip) == 0) {
                printf("Socket is associated with interface: %s\n", ifa->ifa_name);
				if (strcmp(ifa->ifa_name, "eth1") == 0)
				{
					ret = 1;	
				}else if(strcmp(ifa->ifa_name, "eth0") == 0)
				{
					ret = 0;
				}
                break;
            }
        }
    }

    freeifaddrs(ifaddr);
    return ret;
}

int32_t enable_keepalive(modbus_t *ctx) {
    int32_t sock = modbus_get_socket(ctx);
    if (sock == -1) {
        return -1;
    }

    int32_t optval = 1;
    // Enable keep-alive
    if (setsockopt(sock, SOL_SOCKET, SO_KEEPALIVE, &optval, sizeof(optval)) < 0) {
        perror("setsockopt");
        return -1;
    }

    // Optional: Set keep-alive parameters
    // For example, set the start time and interval for probes
    int32_t keepidle = 30;   // Start keep-alive after 60 seconds
    int32_t keepinterval = 5; // Send a probe every 5 seconds
    int32_t keep_count = 5;
    if (setsockopt(sock, IPPROTO_TCP, TCP_KEEPIDLE, &keepidle, sizeof(keepidle)) < 0) {
        perror("setsockopt");
        return -1;
    }
    if (setsockopt(sock, IPPROTO_TCP, TCP_KEEPINTVL, &keepinterval, sizeof(keepinterval)) < 0) {
        perror("setsockopt");
        return -1;
    }
	if (setsockopt(sock, SOL_TCP, TCP_KEEPCNT, (void *)&keep_count, sizeof(keep_count))) {
		perror("Error setsockopt(TCP_KEEPCNT) failed");
		return -1;
	}			

    return 0;
}

void *thread_tcp_modbus(void *arg)
{
	modbus_t *ctx;
    int32_t server_socket, client_socket;
    int32_t epfd;
    struct epoll_event ev, events[MAX_EVENTS];
	modbus_mapping_t *tcp_mb_mapping = NULL;
    int32_t nfds, i;
	uint8_t query[MODBUS_TCP_MAX_ADU_LENGTH];
	int32_t rc = 0;
    internal_shared_data_t *p_shared_data = NULL;

    web_control_info_t *p_web_data = shm_web_control_info_get();
	tcp_mb_mapping = get_modbus_mapping();
    ctx = modbus_new_tcp("0.0.0.0", MODBUS_TCP_DEFAULT_PORT);

	modbus_set_debug(ctx, LOG_MODBUS_ENABLE);
	
	if(ctx == NULL)
	{
		log_i((int8_t *)("modbus open tcp faild"));
		modbus_free(ctx);	
		pthread_exit(NULL);
	}

    server_socket = modbus_tcp_listen(ctx, 10);
    if (server_socket == -1) {
		log_i((int8_t *)"\n\n modbus_tcp_listen fail \n\n");
		modbus_free(ctx);	
		pthread_exit(NULL);
    }

    epfd = epoll_create(10);
    if (epfd == -1) {
        log_i((int8_t *)"Failed to create epoll instance\n");
        close(server_socket);
        modbus_free(ctx);
        pthread_exit(NULL);
    }

    ev.events = EPOLLIN;
    ev.data.fd = server_socket;
    if (epoll_ctl(epfd, EPOLL_CTL_ADD, server_socket, &ev) == -1) {
        log_i((int8_t *)"Failed to add server socket to epoll\n");
        close(server_socket);
        modbus_free(ctx);
        pthread_exit(NULL);
    }

    //初始话modbus接收定时器
    if(g_modbus_recv_timer == NULL)
    {
        g_modbus_recv_timer = user_timer_create(NULL, NULL);
        if (g_modbus_recv_timer == NULL)
        {
            log_i((int8_t *)"modbus recv timer create error");
            close(server_socket);
            modbus_free(ctx);
            pthread_exit(NULL);
        }
    }

    for (;;) 
    {
        p_shared_data = internal_shared_data_get();
        nfds = epoll_wait(epfd, events, MAX_EVENTS, EPOLL_WAIT);
        if (nfds == -1) {
            perror("epoll_wait failed\n");
            break;
        }

        for (i = 0; i < nfds; i++) 
		{
            if (events[i].data.fd == server_socket)
			{
                client_socket = modbus_tcp_accept(ctx, &server_socket);
                if (client_socket == -1) {
                    log_i((int8_t *)"Accept failure\n");
                    continue;
                }

                ev.events = EPOLLIN|EPOLLET;
                ev.data.fd = client_socket;
                if (epoll_ctl(epfd, EPOLL_CTL_ADD, client_socket, &ev) == -1) 
				{
                    log_i((int8_t *)"Failed to add client socket to epoll\n");
                    close(client_socket);
                }
				else
				{
					if ((1 == modbus_get_ethx(ctx)) && (0 == get_Master_fd()))
					{
						set_Master_fd(client_socket);			
					}
					log_i((int8_t *)"add client socket fd %d to epoll\n",ev.data.fd);
					rc = enable_keepalive(ctx);
					if (rc == -1)
					{
						log_i((int8_t *)"\n\n enable_keepalive fail \n\n");
					}
				}
            }
			else 
			{
				// log_i((int8_t *)"receiv fd %d \n",events[i].data.fd);
				modbus_set_socket(ctx, events[i].data.fd);
                //接收到数据之后刷新定时器
                if(p_shared_data->modbus_recv_timeout > 0)
                {
                    user_timer_set_timeout(g_modbus_recv_timer, p_shared_data->modbus_recv_timeout * 1000, false);
                }
                int rc = modbus_receive(ctx, query);
                if (rc > 0) {
                    modbus_analysis(ctx, query, rc, tcp_mb_mapping);
                    modbus_flush(ctx); // 清空缓存, 保证下一次正常数据可以通信
                }
				else 
				{
                	log_i((int8_t *)"del client socket %d to epoll\n",events[i].data.fd);
					if (get_Master_fd() == events[i].data.fd)
					{
						set_Master_fd(0);
					}
                    epoll_ctl(epfd, EPOLL_CTL_DEL, events[i].data.fd, NULL);
                    close(events[i].data.fd);
                }
            }
        }
        //判断是否超时，如果超时直接清空功率
        if(user_timer_is_timeout(g_modbus_recv_timer) == SF_TRUE)
        {
            if(p_shared_data->modbus_recv_timeout > 0)
            {
                //执行设置功率
                log_i((int8_t *)"clear dev power");
                BIT_SET(p_web_data->cabinet_param_update_flag, 1);
                p_web_data->cabinet_param_data.active_power = 0;
                user_timer_set_timeout(g_modbus_recv_timer, p_shared_data->modbus_recv_timeout * 1000, false);
            }
        }
    }

    close(server_socket);
    modbus_free(ctx);
    return NULL;
}

uint8_t get_rs485_check(int check)
{
    uint8_t  value = 'N';

    switch(check)
    {
        case 0:
			value = 'N';
			break;
        case 1:
			value = 'O';
		break;
		case 2:
			value = 'E';
		break;
        default:
            value = 'N';
        break;
	}

	return value;
}



void *thread_rtu_modbus(void *arg)
{
	int32_t rc = 0;
	uint8_t *query = NULL;
    modbus_t *ctx = NULL;
	modbus_mapping_t *rtu_mb_mapping = NULL;
	other_parameter_data_t *other_parame = sdk_shm_other_parameter_data_get();
	
	rtu_mb_mapping = get_modbus_mapping();
	modbus_set_debug(ctx, LOG_MODBUS_ENABLE);

	ctx = modbus_new_rtu("/dev/ttymxc2", other_parame->baud_rate_rs485_4 , get_rs485_check( other_parame->check_bit_rs485_4), other_parame->data_bits_rs485_4, other_parame->stop_bit_rs485_4+1);
	//printf("baud_rate_rs485_4[%d],check_bit_rs485_4[%d],data_bits_rs485_4[%d],stop_bit_rs485_4[%d]\n",other_parame->baud_rate_rs485_4,other_parame->data_bits_rs485_4,other_parame->stop_bit_rs485_4+1);
	//ctx = modbus_new_rtu("/dev/ttymxc2", 9600, 'N', 8, 1);
	
	if(ctx == NULL)
	{
        log_i((int8_t *)"modbus ttymxc2 open faild");
	}
	//modbus_set_slave(ctx, 4);   //设置通信地址
    modbus_set_slave(ctx, other_parame->address_rs485_4);   //设置通信地址
	query = (uint8_t *)malloc(MODBUS_RTU_MAX_ADU_LENGTH);
	modbus_connect(ctx);
    log_i((int8_t *)"modbus_connect RS485_4");
	while(1)
    {
		rc = modbus_receive(ctx, query);
		if((rc != -1) && (rc != 0))
		{
            log_i((int8_t *)"modbus_receive ttymxc2");
			modbus_analysis(ctx, query, rc, rtu_mb_mapping);
		}	
    }
	pthread_exit(NULL);
}

void *thread_rtu_modbus_6(void *arg)
{
	int32_t rc = 0;
	uint8_t *query = NULL;
    modbus_t *ctx = NULL;
	modbus_mapping_t *rtu_mb_mapping = NULL;
	other_parameter_data_t *other_parame = sdk_shm_other_parameter_data_get();
	
	rtu_mb_mapping = get_modbus_mapping();
	modbus_set_debug(ctx, LOG_MODBUS_ENABLE);

	ctx = modbus_new_rtu("/dev/ttymxc3", other_parame->baud_rate_rs485_6 , get_rs485_check( other_parame->check_bit_rs485_6), other_parame->data_bits_rs485_6, other_parame->stop_bit_rs485_6+1);
	//ctx = modbus_new_rtu("/dev/ttymxc3", 9600, 'N', 8, 1);

	if(ctx == NULL)
	{
        log_i((int8_t *)"modbus ttymxc3 open faild");
	}
	//modbus_set_slave(ctx, 6);   //设置通信地址
    modbus_set_slave(ctx, other_parame->address_rs485_6);   //设置通信地址
	query = (uint8_t *)malloc(MODBUS_RTU_MAX_ADU_LENGTH);
	modbus_connect(ctx);
    log_i((int8_t *)"modbus_connect rs485_6");
	while(1)
    {
		rc = modbus_receive(ctx, query);
		if((rc != -1) && (rc != 0))
		{
            log_i((int8_t *)"modbus_receive ttymxc3");
			modbus_analysis(ctx, query, rc, rtu_mb_mapping);
		}	
    }
	pthread_exit(NULL);
}


void modbus_start(void)
{

	init_modbus_addr(); 

	pthread_t tcp_modbus;
	pthread_attr_t attr;

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);

	if(pthread_create(&tcp_modbus,&attr,thread_tcp_modbus,NULL) != 0)
	{
		perror("pthread_create modbus_start");
	}
	
	

	pthread_t rtu_modbus;//RS485_4

	if(pthread_create(&rtu_modbus,&attr,&thread_rtu_modbus,NULL) !=0)
	{
		perror("pthread_create modbus_start 4");
	}


	pthread_t rtu_modbus_6;//RS485_6

	if(pthread_create(&rtu_modbus_6,&attr,&thread_rtu_modbus_6,NULL) !=0)
	{
		perror("pthread_create modbus_start 6");
	}
	pthread_attr_destroy(&attr);

    cmu_modbus_client_init();

	return;
}



#include <sys/time.h>
#include <fcntl.h>


struct 
{
    pthread_mutex_t sock_mutex;
    int32_t         mb_sock_fd;
    user_timer_hd   online_tm;
    user_timer_hd   heatbeat_tm;
} s_cmu_mb_client;

#if (1)
#define THREAD_MODBUS_DEBUG(...)    do{ printf( "--------------------------[Debug]" ); printf( __VA_ARGS__ ); }while(0)
#else
#define THREAD_MODBUS_DEBUG(...)    do{}while(0)
#endif

#define THREAD_MODBUS_ERROR(...)    do{ printf( "--------------------------[Error][%s]", __func__ ); printf( __VA_ARGS__ ); }while(0)

static sf_ret_t cmu_modbus_client_init( void )
{
    if ( 0 > pthread_mutex_init( &s_cmu_mb_client.sock_mutex, NULL ))
    {
        THREAD_MODBUS_ERROR( "sock mutex init fail!!!\r\n" );
        return SF_ERR_NO_OBJECT;
    }
    
    s_cmu_mb_client.mb_sock_fd  = -1;
    s_cmu_mb_client.online_tm   = user_timer_create(NULL, NULL);
    s_cmu_mb_client.heatbeat_tm = user_timer_create(NULL, NULL);
    if (   s_cmu_mb_client.online_tm   == NULL 
        || s_cmu_mb_client.heatbeat_tm == NULL )
    {
        THREAD_MODBUS_ERROR( "online timer or heartbeat timer create fail!!!\r\n" );
        return SF_ERR_NO_OBJECT;
    }
    user_timer_set_timeout( s_cmu_mb_client.online_tm   , 60 * 1000, SF_FALSE );
    user_timer_set_timeout( s_cmu_mb_client.heatbeat_tm , 10 * 1000, SF_FALSE );

	pthread_t cmu_client_thread;
	pthread_attr_t attr;

	pthread_attr_init( &attr );
	pthread_attr_setdetachstate( &attr, PTHREAD_CREATE_DETACHED);
    if( pthread_create( &cmu_client_thread, &attr, &cmu_modbus_client_thread, NULL) !=0 )
	{
	    THREAD_MODBUS_ERROR("pthread_create cmu_modbus_client_thread ");
        return SF_ERR_NO_OBJECT;
	}
	pthread_attr_destroy( &attr );

    cmu_modbus_reconnect();
    return SF_OK;
}


static void *cmu_modbus_client_thread( void *arg )
{
    THREAD_MODBUS_DEBUG("start....\r\n");
    while (1)
    {
        if ( user_timer_is_timeout( s_cmu_mb_client.online_tm ) )    
        {
            user_timer_refresh( s_cmu_mb_client.online_tm );
            cmu_modbus_reconnect();
        }
    
        if ( user_timer_is_timeout( s_cmu_mb_client.heatbeat_tm ) )
        {
            user_timer_refresh( s_cmu_mb_client.heatbeat_tm );
            cmu_modbus_heatbeat_probe();
        }
        sleep(1);
    }
    pthread_exit( NULL );
}

sf_ret_t csu_modbus_get_relay_data( int sock_fd, uint16_t tran_id, uint8_t *relay_data, int32_t *p_relay_dat_len )
{
    uint8_t recv_buff[1024] = {0};

    for( ;; )
    {
        uint16_t recv_tran_id = 0;

        int32_t recv_len = recv( s_cmu_mb_client.mb_sock_fd, recv_buff, sizeof( recv_buff ), 0 );
        if ( recv_len <= 0 )
        {
            /* 接收不到（超时）或是接收错误，则退出 */
            return SF_ERR_NO_OBJECT;
        }
        
        /* 非对应的回应包，可能出现串包 */
        /* 串包原因，CMU正常请求很久之后才回复，下次读取的时候收到上一条指令的回复 */
        /* 处理方式：再次尝试读取心跳包 */
        // mem_utils_print_hex_dat( "recv data:", recv_buff, recv_len, 10, true ); 
        recv_tran_id = (recv_buff[0] << 8) | recv_buff[1];
        if ( recv_tran_id == tran_id )
        {
            memcpy( relay_data, recv_buff, recv_len );
            *p_relay_dat_len = recv_len;
            return SF_OK;
        }
    }
}

sf_ret_t csu_modbus_cmd_relay( modbus_t *ctx, const uint8_t *req, uint16_t req_len )
{
    uint16_t tran_id = (req[0] << 8) | req[1];
    uint8_t recv_buff[1024] = {0};
    int recv_len = 0;
    sf_ret_t ret = SF_ERR_NDEF;

    /* 转发modbus指令 */
    pthread_mutex_lock( &s_cmu_mb_client.sock_mutex );

    if ( s_cmu_mb_client.mb_sock_fd > 0 )
    {
        // mem_utils_print_hex_dat( "send data:", (uint8_t*)req, req_len, 10, true ); 
        if ( req_len != send( s_cmu_mb_client.mb_sock_fd, req, req_len, 0 ))
        {
            /* 发送长度不等，跳出 */
            goto __exit;
        }
        ret = csu_modbus_get_relay_data( s_cmu_mb_client.mb_sock_fd, tran_id, recv_buff, &recv_len );

    }
__exit:
    pthread_mutex_unlock( &s_cmu_mb_client.sock_mutex );
    if ( ret != SF_OK )
    {
        modbus_reply_exception( ctx, req, MODBUS_EXCEPTION_SLAVE_OR_SERVER_FAILURE );
    }
    else
    {
        send_msg( ctx, recv_buff, recv_len );
    }
    return ret;
}

sf_ret_t cmu_modbus_recv_heartbeat_reply( int sock_fd, uint16_t tran_id )
{
    uint8_t heartbeat_reply[] = { 0, 0, 0x00, 0x00, 0x00, 0x05, 0x01, 0x03, 0x02, 0xAA, 0xBB };
    uint8_t recv_buff[1024] = {0};

    heartbeat_reply[ 0 ] = ( tran_id >> 8 ) & 0xFF;
    heartbeat_reply[ 1 ] = ( tran_id >> 0 ) & 0xFF;
    for( ;; )
    {
        int32_t recv_len = recv( s_cmu_mb_client.mb_sock_fd, recv_buff, sizeof( recv_buff ), 0 );
        if ( recv_len <= 0 )
        {
            /* 接收不到（超时）或是接收错误，则退出 */
            return SF_ERR_NO_OBJECT;
        }
        
        /* 非心跳包，可能出现串包 */
        /* 串包原因，CMU正常请求很久之后才回复，等到心跳读取的时候才读到该回复 */
        /* 处理方式：再次尝试读取心跳包 */
        // mem_utils_print_hex_dat( "recv data:", recv_buff, recv_len, 10, true ); 
        if ( 0 == memcmp( recv_buff, heartbeat_reply, sizeof( heartbeat_reply ) ))
        {
            /* 网络正常情况下，接收到属于自己的心跳包 */
            user_timer_refresh( s_cmu_mb_client.online_tm );
            return SF_OK;
        }
    }
}

static void cmu_modbus_heatbeat_probe( void )
{
    /* 查询 0xFFFF 寄存器作为心跳 */
    uint8_t heartbeat_req[] = { 0, 0, 0x00, 0x00, 0x00, 0x06, 0x01, 0x03, 0xFF, 0xFF, 0x00, 0x01 };
    static uint16_t tran_id = 0x1234;

    tran_id++;
    heartbeat_req[ 0 ] = ( tran_id >> 8 ) & 0xFF;
    heartbeat_req[ 1 ] = ( tran_id >> 0 ) & 0xFF;

    pthread_mutex_lock( &s_cmu_mb_client.sock_mutex );

    if ( s_cmu_mb_client.mb_sock_fd < 0 )
    {
        goto __exit;
    }

    // mem_utils_print_hex_dat( "send data:", (uint8_t*)heartbeat_req, sizeof(heartbeat_req), 10, true ); 
    if (sizeof( heartbeat_req ) != send( s_cmu_mb_client.mb_sock_fd, heartbeat_req, sizeof( heartbeat_req ), 0 ))
    {
        THREAD_MODBUS_ERROR( "send heartbeat req error\r\n" );
        goto __exit;
    }
    cmu_modbus_recv_heartbeat_reply( s_cmu_mb_client.mb_sock_fd, tran_id );

__exit:
    pthread_mutex_unlock( &s_cmu_mb_client.sock_mutex );

    return;
}

// static void cmu_modbus_heatbeat_probe( void )
// {
//     /* 查询 0xFFFF 寄存器作为心跳 */
//     const uint8_t heartbeat_req[]   = { 0xAA, 0xBB, 0x00, 0x00, 0x00, 0x06, 0x01, 0x03, 0xFF, 0xFF, 0x00, 0x01 };
//     const uint8_t heartbeat_reply[] = { 0xAA, 0xBB, 0x00, 0x00, 0x00, 0x05, 0x01, 0x03, 0x02, 0xAA, 0xBB };
//     uint8_t recv_buff[200] = {0};

//     pthread_mutex_lock( &s_cmu_mb_client.sock_mutex );
//     THREAD_MODBUS_DEBUG("cmu_modbus_heatbeat_probe start....\r\n");

//     if ( s_cmu_mb_client.mb_sock_fd < 0 )
//     {
//         goto __exit;
//     }

//     mem_utils_print_hex_dat( "send data:", (uint8_t*)heartbeat_req, sizeof(heartbeat_req), 10, true ); 
//     if (sizeof( heartbeat_req ) != send( s_cmu_mb_client.mb_sock_fd, heartbeat_req, sizeof( heartbeat_req ), 0 ))
//     {
//         THREAD_MODBUS_ERROR( "send heartbeat req error\r\n" );
//         goto __exit;
//     }

//     int32_t recv_len = recv( s_cmu_mb_client.mb_sock_fd, recv_buff, sizeof( recv_buff ), 0 );
//     // if ( recv_len > 0 )
//     // {
//     //     if ( 0 == memcmp( recv_buff, heartbeat_reply, sizeof( heartbeat_reply ) ))
//     //     {
//     //         /* 接收到心跳包 */
//     //         user_timer_refresh( s_cmu_mb_client.online_tm );
//     //     }else{
//     //         /* 非心跳包，可能出现串包 */
//     //         /* 串包原因，CMU正常请求很久之后才回复，等到心跳读取的时候才读到该回复 */
//     //         /* 处理方式：尝试读取心跳包 */
//     //     }
//     // }

//     if ( recv_len > 0 )
//         mem_utils_print_hex_dat( "recv data:", recv_buff, recv_len, 10, true ); 

//     if (  sizeof( heartbeat_reply ) != recv_len )
//     {
//         /* 可能出现chuan'baochuanbao */
//         THREAD_MODBUS_ERROR( "recv heartbeat reply error, recv len:%d\r\n", recv_len );
//         goto __exit;
//     }
//     if ( 0 == memcmp( recv_buff, heartbeat_reply, sizeof( heartbeat_reply ) ))
//     {
//         /* 接收到心跳包 */
//         user_timer_refresh( s_cmu_mb_client.online_tm );
//     }

// __exit:
//     THREAD_MODBUS_DEBUG("cmu_modbus_heatbeat_probe end....\r\n");
//     pthread_mutex_unlock( &s_cmu_mb_client.sock_mutex );
//     return;
// }

static int32_t cmu_modbus_reconnect( void )
{
    struct sockaddr_in serv_addr;
    int socket_fd;
    
    THREAD_MODBUS_DEBUG("%s\r\n", __func__ );

    pthread_mutex_lock( &s_cmu_mb_client.sock_mutex );
    if ( s_cmu_mb_client.mb_sock_fd > 0 )
    {
        /* 关闭原有连接 */
        close( s_cmu_mb_client.mb_sock_fd );
        s_cmu_mb_client.mb_sock_fd = -1;
    }
    pthread_mutex_unlock( &s_cmu_mb_client.sock_mutex );

    memset( &serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;                
    serv_addr.sin_port = htons( 1502 ); 
    
    socket_fd = socket( AF_INET, SOCK_STREAM, 0 );
    if ( socket_fd < 0  )
    {
        THREAD_MODBUS_ERROR( "create socket error!!!" );
        return -1;
    }
    
    if(inet_pton( AF_INET, "192.168.2.100", &serv_addr.sin_addr) <= 0)
    {
        THREAD_MODBUS_ERROR("inet_pton error\n");
        close( socket_fd );
        return -2;
    }

    /* 设置sock发送超时时间为1秒 */
    struct timeval tv = { .tv_sec = 1, .tv_usec = 0 };
    setsockopt(socket_fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    /* 设置sock接收超时时间为3秒 */
    tv.tv_sec = 3;
    setsockopt(socket_fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    if(connect(socket_fd,(struct sockaddr*)&serv_addr,sizeof(serv_addr)) < 0)
    {
        THREAD_MODBUS_ERROR("socket connect error\n");
        close( socket_fd );
        return -4;
    }
    
    pthread_mutex_lock( &s_cmu_mb_client.sock_mutex );
    if ( s_cmu_mb_client.mb_sock_fd > 0 )
    {
        /* 关闭原有连接 */
        close( s_cmu_mb_client.mb_sock_fd );
        s_cmu_mb_client.mb_sock_fd = -1;
    }
    s_cmu_mb_client.mb_sock_fd = socket_fd;
    pthread_mutex_unlock( &s_cmu_mb_client.sock_mutex );
    
    THREAD_MODBUS_DEBUG( "connect cmu modbus success\r\n" );

    return 0;
}
