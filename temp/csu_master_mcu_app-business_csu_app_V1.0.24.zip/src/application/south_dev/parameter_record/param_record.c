#include <string.h>
#include <unistd.h>
#include "sdk_shm.h"
#include "sdk_para.h"
#include "sdk_net_public.h"
#include "sofar_log.h"
#include "sdk_public.h"
#include "param_record.h"
#include "cJSON.h"
#include "sdk_fs.h"
#include "app_common.h"

#define CLOUD_CFG_PATH          "/user/conf/cloud_cfg.json"
#define DEV_TIMEZONE_PATH       "/user/conf/timezone/timezone.json"
#define MODBUS_RECV_PATH       "/user/conf/modbus_timeout.json"

/**
 * @brief   initialization of device configuration parameters
 * @note    文件有效性标志
 *          RS485-4地址、波特率、停止位、校验位、RS485-6地址、波特率、停止位、校验位
 *          ETH-1 IP地址、端口号
 *          ETH-1 服务器IP地址、端口号
 *          ETH-3 IP地址、端口号
 *          ETH-3 服务器IP地址、端口号
 *          远程开关机 0-关机 1-开机
 *          液冷系统开关机 手动模式下才生效 0-关机 1-开机
 *          运行数据存储天数 0~360天
 *          运行数据存储频率 3min~60min
 *          故障录波条数 0~10条
 *          电池簇编号
 *          cmu模式设置 0 运行模式，1 运维模式
*/
static device_paramater_t g_dev_param_init = {1, 
                                              {1, 9600, 8, 0, 0, 
                                               2, 9600, 8, 0, 0, 
                                               4, 9600, 8, 0, 0, 
                                               5, 9600, 8, 0, 0, 
                                               6, 9600, 8, 0, 0, 
                                               7, 9600, 8, 0, 0, 
                                               {"192.168.1.100"}, 255,
                                               {"192.168.1.101"}, 255,
                                               {"192.168.1.102"}, 255,                                        
                                               {"192.168.1.120"}, 255,
                                               {"192.168.1.1"}, 
                                               {"255.255.255.0"},
                                               {"8.8.8.8"},
                                               {"1.2.3.4"},
                                               {"192.168.2.101"}, 255,
                                               {"192.168.2.102"}, 255,
                                               1,
                                               {"192.168.5.101"}, 255,
                                               {"192.168.3.101"}, 255,
                                               },
                                              {365,
                                               5,
                                               10,
                                               0,
                                               0,
                                               }}; 


/**
 * @brief   initialization of factory parameters
 * @note    文件有效性标志
 *          工厂模式-状态控制字
 *          工厂模式-特权控制字
*/
static factory_paramater_t g_factory_param_init = {1, 0, 0};
static ems_paramater_t g_ems_param_init = {0};
static device_paramater_t g_dev_param;
static factory_paramater_t g_factory_param;
static ems_paramater_t g_ems_param;

/**
* @brief		EMS数据存储
* @return		-1:失败
*/
int32_t ems_param_save(void)
{
    int32_t ret = 0;
    int32_t result = 0;
    int32_t len = 0;
    common_data_t *shm = NULL;

    ems_paramater_t *p_data = &g_ems_param;
    shm = sdk_shm_get();
    ems_data_t *p_para_data = sdk_shm_ems_data_info_get(); 
    ems_holiday_data_t *p_holiday_data = sdk_shm_holiday_ems_data_info_get(); 
    energy_price_t *p_price_data = &shm->energy_price; 
    if ((NULL == p_data) || (NULL == p_para_data))
    {
        return -1;
    }

    p_data->validity_flag = FILE_VALID;
    
    memcpy(&(p_data->ems_parameter_data), p_para_data, sizeof(ems_data_t));
    memcpy(&(p_data->ems_holiday_data), p_holiday_data, sizeof(ems_holiday_data_t));
    memcpy(&(p_data->energy_price), p_price_data, sizeof(energy_price_t));
    
    len = sizeof(ems_paramater_t);
    result = sdk_para_write(FILE_TYPE_EMS_PARAM, 0, (uint8_t *)p_data, len);

    if (result == len)
    {
        ret = sdk_para_sync(FILE_TYPE_EMS_PARAM);
    }
    else
    {
        ret = -1;
    }
	ret = sdk_para_read(FILE_TYPE_EMS_PARAM, 0, (uint8_t *)(&g_ems_param), len);

    return ret;
}


/**
* @brief		设备参数存储
* @return		-1:失败
*/
int32_t dev_param_save(void)
{
    
    int32_t ret = 0;
    int32_t result = 0;
    int32_t len = 0;
    device_paramater_t *p_data = &g_dev_param;
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数
	other_parameter_data_t *p_other_data = sdk_shm_other_parameter_data_get();		// 其他参数

    if ((NULL == p_data) || (NULL == p_para_data) || (NULL == p_other_data))
    {
        return -1;
    }

    p_data->validity_flag = FILE_VALID;
    memcpy(&(g_dev_param.dev_param_other_data.address_rs485_4), (&(p_other_data->address_rs485_4)), sizeof(device_paramater_other_t)); 
	memcpy(&(g_dev_param.device_paramater_sys_data.storage_duration_operation_data), (&(p_para_data->sys_param_data.storage_duration_operation_data)), sizeof(device_paramater_sys_t));

    len = sizeof(device_paramater_t);
    result = sdk_para_write(FILE_TYPE_DEVICE_PARAM, 0, (uint8_t *)p_data, len);
    if (result == len)
    {
        ret = sdk_para_sync(FILE_TYPE_DEVICE_PARAM);
    }
    else
    {
        ret = -1;
    }
	ret = sdk_para_read(FILE_TYPE_DEVICE_PARAM, 0, (uint8_t *)(&g_dev_param), len);

    return ret;
}


/**
 * @brief        设备配置参数文件初始化
 * @param        
 * @return       
 * @retval       0      初始化成功
 * @retval       其他   异常
 */
static int32_t dev_param_file_init(void)
{
    uint16_t flag = 0;
    int32_t ret = 0;
    int32_t result = 0;
    uint32_t len = 0;

    ret = sdk_para_init(FILE_TYPE_DEVICE_PARAM, FILE_SIZE_DEVICE_PARAM);
    if (0 == ret)
    {
        ret = sdk_para_read(FILE_TYPE_DEVICE_PARAM, 0, (uint8_t *)(&flag), 2);

        if (2 == ret)
        {
            if (FILE_VALID == flag)
            {
                ret = 0;
                PARAM_RECORD_DEBUG_PRINT((int8_t *)"\n device param file has been initialized!!! \n"); // 测试用
                goto __exit;
            }
        }
        else
        {
            PARAM_RECORD_DEBUG_PRINT((int8_t *)"\n [error] read device param file fail!!! \n");
        }
    }
    else if (ret < 0)
    {
        PARAM_RECORD_DEBUG_PRINT((int8_t *)"\n [error] sdk_para_init->device param fail!!! \n");
        goto __exit;
    }

    // 给设备配置参数写默认值
    len = sizeof(device_paramater_t);
    result = sdk_para_write(FILE_TYPE_DEVICE_PARAM, 0, (uint8_t *)(&g_dev_param_init), len);
    if (result == len)
    {
        ret = sdk_para_sync(FILE_TYPE_DEVICE_PARAM);
        PARAM_RECORD_DEBUG_PRINT((int8_t *)"\n [ok] device param file init success \n"); // 测试用
    }
    else
    {
        ret = -1;
    }
     result = sdk_para_write(FILE_TYPE_DEVICE_PARAM, 0, (uint8_t *)(&g_dev_param_init), len);
    if (result == len)
    {
        ret = sdk_para_sync(FILE_TYPE_DEVICE_PARAM);
        PARAM_RECORD_DEBUG_PRINT((int8_t *)"\n [ok] device param file init success \n"); // 测试用
    }
    else
    {
        ret = -1;
    }   

__exit:
    return ret;
}


/**
 * @brief        工厂参数文件初始化
 * @param        
 * @return       
 * @retval       0   初始化成功
 * @retval       <0  异常
 */
static int32_t factory_param_file_init(void)
{
    uint16_t flag = 0;
    int32_t ret = 0;
    int32_t result = 0;
    uint32_t len = 0;

    ret = sdk_para_init(FILE_TYPE_FACTORY_PARAM, FILE_SIZE_FACTORY_PARAM);

    if (0 == ret)
    {
        ret = sdk_para_read(FILE_TYPE_FACTORY_PARAM, 0, (uint8_t *)(&flag), 2);

        if (2 == ret)
        {
            if (FILE_VALID == flag)
            {
                ret = 0;
                PARAM_RECORD_DEBUG_PRINT((int8_t *)"\n factory param file has been initialized!!! \n"); // 测试用
                goto __exit;
            }
        }
        else
        {
            PARAM_RECORD_DEBUG_PRINT((int8_t *)"\n [error] read factory param file fail!!! \n");
        }
    }
    else if (ret < 0)
    {
        PARAM_RECORD_DEBUG_PRINT((int8_t *)"\n [error] sdk_para_init factory param fail! \n");
        goto __exit;
    }

    // 给工厂参数写默认值
    len = sizeof(factory_paramater_t);
    result = sdk_para_write(FILE_TYPE_FACTORY_PARAM, 0, (uint8_t *)(&g_factory_param_init), len);
    if (result == len)
    {
        ret = sdk_para_sync(FILE_TYPE_FACTORY_PARAM);
        PARAM_RECORD_DEBUG_PRINT((int8_t *)"\n [ok] factory param file init success!!!\n"); // 测试用
    }
    else
    {
        ret = -1;
    }

__exit:
    return ret;
}


/**
 * @brief        EMS参数文件初始化
 * @param        
 * @return       
 * @retval       0   初始化成功
 * @retval       <0  异常
 */
static int32_t ems_param_file_init(void)
{
    uint16_t flag = 0;
    int32_t ret = 0;
    int32_t result = 0;
    uint32_t len = 0;

    ret = sdk_para_init(FILE_TYPE_EMS_PARAM, FILE_SIZE_EMS_PARAM);

    if (0 == ret)
    {
        ret = sdk_para_read(FILE_TYPE_EMS_PARAM, 0, (uint8_t *)(&flag), 2);

        if (2 == ret)
        {
            if (FILE_VALID == flag)
            {
                ret = 0;
                PARAM_RECORD_DEBUG_PRINT((int8_t *)"\n ems param file has been initialized!!! \n"); // 测试用
                goto __exit;
            }
        }
        else
        {
            PARAM_RECORD_DEBUG_PRINT((int8_t *)"\n [error] read ems param file fail!!! \n");
        }
    }
    else if (ret < 0)
    {
        PARAM_RECORD_DEBUG_PRINT((int8_t *)"\n [error] sdk_para_init ems param fail! \n");
        goto __exit;
    }

    // 给EMS参数写默认值
    len = sizeof(ems_paramater_t);
    result = sdk_para_write(FILE_TYPE_EMS_PARAM, 0, (uint8_t *)(&g_ems_param_init), len);
    if (result == len)
    {
        ret = sdk_para_sync(FILE_TYPE_EMS_PARAM);
        PARAM_RECORD_DEBUG_PRINT((int8_t *)"\n [ok] ems param file init success!!!\n"); // 测试用
    }
    else
    {
        ret = -1;
    }

__exit:
    return ret;
}


/**
 * @brief   设备参数文件初始化
 * @param        
 * @return       
 * @retval
 */
void param_record_file_init(void)
{
    int32_t ret = 0;

    ret = dev_param_file_init();
    if (ret < 0)
    {
        PARAM_RECORD_DEBUG_PRINT((int8_t *)"\n [error] dev param file init fail!!!\n");
    }
    
    ret = factory_param_file_init();
    if (ret < 0)
    {
        PARAM_RECORD_DEBUG_PRINT((int8_t *)"\n [error] factory param file init fail!!!\n");
    }

    ret = ems_param_file_init();
    if (ret < 0)
    {
        PARAM_RECORD_DEBUG_PRINT((int8_t *)"\n [error] ems param file init fail!!!\n");
    }
}


/**
 * @brief   对共享内存的数据初始化
 * @param
 * @return  
 * @note    对应配置参数，优先从文件读取，若文件读取失败，则赋默认值
 */
void shm_data_init(void)
{
    int32_t ret = 0;
    uint32_t len = 0;

    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();              // 遥信
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();              // 遥测
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get(); // 定值/参数
    other_parameter_data_t *p_other_data = sdk_shm_other_parameter_data_get();      // 其他参数
    internal_shared_data_t *p_internal_data = internal_shared_data_get();           // 内部共用参数
    web_control_info_t *p_web_info = shm_web_control_info_get();                    // web 控制操作数据

	internal_version_info_t *p_version_info = internal_version_info_get();          // 内部版本信息
    firmware_update_t *p_update_info = sdk_shm_firmware_update_info_get();          // 升级相关信息
    ems_data_t *p_ems_para_data = sdk_shm_ems_data_info_get();
    energy_price_t *p_ems_price_data = &sdk_shm_get()->energy_price;
    box_transformer_info_t *p_box_transformer_data = sdk_shm_box_transformer_data_info_get();

    if ((NULL == p_telematic_data) || (NULL == p_telemetry_data) || (NULL == p_para_data) || (NULL == p_other_data) \
        || (NULL == p_internal_data) || (NULL == p_web_info) || (NULL == p_update_info) || (NULL == p_version_info) \
        || (NULL == p_ems_para_data))
    {
        PARAM_RECORD_DEBUG_PRINT((int8_t *)"[%s:%d] Null pointer \n", __func__, __LINE__);
        return;
    }

    // 初始化 共享内存中 遥信信息
    memset(p_telematic_data, 0, sizeof(telematic_data_t));

    // 初始化 共享内存中 遥测信息
    memset(p_telemetry_data, 0, sizeof(telemetry_data_t));

    // 初始化 共享内存中 内部共用参数
    memset(p_internal_data, 0, sizeof(internal_shared_data_t));

	// 初始化 共享内存中 升级相关数据
    memset(p_update_info, 0, sizeof(firmware_update_t));
	
    // 初始化 共享内存中 web 控制操作数据
    memset(p_web_info, 0, sizeof(web_control_info_t));

    // 初始化 共享内存软件版本号
    memset(p_version_info, 0, sizeof(internal_version_info_t));

    // 初始化 共享内存EMS数据
    memset(p_ems_para_data, 0, sizeof(ems_data_t));

    memset(p_box_transformer_data, 0, sizeof(box_transformer_info_t));

    p_version_info->sys_soft_version[0] = SYS_SOFTWARE_VERSION_TPYE;
    p_version_info->sys_soft_version[1] = SYS_SOFTWARE_MAJOR_VERSION;
    p_version_info->sys_soft_version[2] = SYS_SOFTWARE_MINOR_VERSION;
    p_version_info->sys_soft_version[3] = SYS_SOFTWARE_STAGE_VERSION;
    
    p_version_info->mcu1_app_soft_version[0] = MCU1_SOFTWARE_VERSION_TPYE;
    p_version_info->mcu1_app_soft_version[1] = MCU1_SOFTWARE_MAJOR_VERSION;
    p_version_info->mcu1_app_soft_version[2] = MCU1_SOFTWARE_MINOR_VERSION;
    p_version_info->mcu1_app_soft_version[3] = MCU1_SOFTWARE_STAGE_VERSION;
    p_version_info->can_protocol_version = CAN_PROTOCOL_VERSION;

    p_version_info->ext_communication_protocol_version[0] = EXTERNAL_PROTOCOL_MAJOR_VERSION;
    p_version_info->ext_communication_protocol_version[1] = EXTERNAL_PROTOCOL_MINOR_VERSION;

	memcpy(&p_telemetry_data->sys_version_telemetry_info.mcu1_software_version_number,p_version_info->mcu1_app_soft_version,4);
    memcpy(&p_telemetry_data->sys_version_telemetry_info.ext_communication_protocol_version,p_version_info->ext_communication_protocol_version,2);

    len = sizeof(device_paramater_t);
    ret = sdk_para_read(FILE_TYPE_DEVICE_PARAM, 0, (uint8_t *)(&g_dev_param), len);
    if (ret == len)
    {
        memcpy(&(p_para_data->sys_param_data.storage_duration_operation_data), (&(g_dev_param.device_paramater_sys_data.storage_duration_operation_data)), sizeof(device_paramater_sys_t));
        memcpy(&(p_other_data->address_rs485_4), &(g_dev_param.dev_param_other_data.address_rs485_4), sizeof(device_paramater_other_t));
    } 
    else    // 设备配置参数读取失败
    {
        memcpy(&(p_para_data->sys_param_data.storage_duration_operation_data), (&(g_dev_param_init.device_paramater_sys_data.storage_duration_operation_data)), sizeof(device_paramater_sys_t));
        memcpy(&(p_other_data->address_rs485_4), &(g_dev_param_init.dev_param_other_data.address_rs485_4), sizeof(device_paramater_other_t));
        PARAM_RECORD_DEBUG_PRINT((int8_t *)"\n [error] device_paramater read fail \n"); // 测试用
    }

    len = sizeof(factory_paramater_t);
    ret = sdk_para_read(FILE_TYPE_FACTORY_PARAM, 0, (uint8_t *)(&g_factory_param), len);
    if (ret == len)
    {
        memcpy(&(p_other_data->state_ctr), &(g_factory_param.state_ctr), (sizeof(factory_paramater_t) - 2));
    } 
    else    // 工厂参数读取失败
    {
        memcpy(&(p_other_data->state_ctr), &(g_factory_param_init.state_ctr), (sizeof(factory_paramater_t) - 2));
        PARAM_RECORD_DEBUG_PRINT((int8_t *)"\n [error] factory_paramater read fail \n"); // 测试用
    }

    len = sizeof(ems_paramater_t);
    ret = sdk_para_read(FILE_TYPE_EMS_PARAM, 0, (uint8_t *)(&g_ems_param), len);
    if (ret == len)
    {
        memcpy(p_ems_para_data, &g_ems_param.ems_parameter_data, (sizeof(ems_data_t)));
        memcpy(p_ems_price_data, &g_ems_param.energy_price, (sizeof(energy_price_t)));
    } 
    else    // EMS参数读取失败
    {
        PARAM_RECORD_DEBUG_PRINT((int8_t *)"\n [error] ems_paramater read fail \n"); // 测试用
    }
}


/**
 * @brief   云服务使能参数初始化
 * @param
 * @return  
 * @note    对应配置参数，优先从文件读取，若文件读取失败，则赋默认值
 */
static void cloud_cfg_param_init(void)
{
    cJSON *p_cfg = NULL;
    FILE *fp = NULL;
	uint8_t cfg_buff[64] = {0};
    internal_shared_data_t *p_shared_para = internal_shared_data_get();

    fp = fopen(CLOUD_CFG_PATH,"r");
	if(fp == NULL)
	{
		PARAM_RECORD_DEBUG_PRINT((int8_t *)"open [%s] failed.");
		return;
	}

	fread(cfg_buff, 1, sizeof(cfg_buff), fp);
	fclose(fp);
	p_cfg = cJSON_Parse((char *)cfg_buff);
	if(p_cfg == NULL)
	{
		PARAM_RECORD_DEBUG_PRINT((int8_t *)"parse config [%s] failed.", CLOUD_CFG_PATH);
        p_shared_para->sofar_cloud_enable = 1;
        p_shared_para->zcs_cloud_enable = 0;
		return;
	}

    p_shared_para->sofar_cloud_enable = cJSON_GetObjectItem(p_cfg,"sofar")->valueint;
    p_shared_para->zcs_cloud_enable = cJSON_GetObjectItem(p_cfg,"zcs")->valueint;
    PARAM_RECORD_DEBUG_PRINT((int8_t *)"sofar cloud service: %d", p_shared_para->sofar_cloud_enable);
    PARAM_RECORD_DEBUG_PRINT((int8_t *)"zcs cloud service: %d", p_shared_para->zcs_cloud_enable);
    cJSON_Delete(p_cfg);
}


/**
 * @brief   modbus接收超时参数初始化
 * @param
 * @return  
 * @note    对应配置参数，优先从文件读取，若文件读取失败，则赋默认值
 */
static void modbus_recv_param_init(void)
{
    cJSON *p_cfg = NULL;
    FILE *fp = NULL;
	uint8_t cfg_buff[64] = {0};
    internal_shared_data_t *p_shared_para = internal_shared_data_get();

    fp = fopen(MODBUS_RECV_PATH,"r");
	if(fp == NULL)
	{
		PARAM_RECORD_DEBUG_PRINT((int8_t *)"open [%s] failed.");
        p_shared_para->modbus_recv_timeout = 0;
		return;
	}

	fread(cfg_buff, 1, sizeof(cfg_buff), fp);
	fclose(fp);
	p_cfg = cJSON_Parse((char *)cfg_buff);
	if(p_cfg == NULL)
	{
		PARAM_RECORD_DEBUG_PRINT((int8_t *)"parse config [%s] failed.", DEV_TIMEZONE_PATH);
        p_shared_para->modbus_recv_timeout = 0;
		return;
	}

    p_shared_para->modbus_recv_timeout = cJSON_GetObjectItem(p_cfg, "Timeout")->valueint;

    cJSON_Delete(p_cfg);
}


/**
 * @brief 参数存储模块初始化
 * @return void
 */
void param_record_module_init(void)
{
    //参数储存模块初始化
    param_record_file_init();
    //共享内存数据初始化
    shm_data_init();
    //云服务使能参数初始化
    cloud_cfg_param_init();
    //modbus通信超时参数初始化
    modbus_recv_param_init();
}

