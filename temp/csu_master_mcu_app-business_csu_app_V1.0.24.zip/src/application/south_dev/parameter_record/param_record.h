#ifndef __PARAM_RECORD_H__
#define __PARAM_RECORD_H__

#include "component/sofar_log.h"

#if (1)
#define PARAM_RECORD_DEBUG_PRINT(...) log_i(__VA_ARGS__);
#else
#define PARAM_RECORD_DEBUG_PRINT(...) {do {} while(0);}
#endif

// 系统软件版本号
#define SYS_SOFTWARE_VERSION_TPYE           ('V')           // 版本类型，暂固定为 V
#define SYS_SOFTWARE_MAJOR_VERSION          (1)             // 主版本号
#define SYS_SOFTWARE_MINOR_VERSION          (0)             // 次版本号
#define SYS_SOFTWARE_STAGE_VERSION          (27)            // 阶段版本号


// MCU1应用层软件版本号
#define MCU1_SOFTWARE_VERSION_TPYE           ('V')           // 版本类型，暂固定为 V
#define MCU1_SOFTWARE_MAJOR_VERSION          (0)             // 主版本号
#define MCU1_SOFTWARE_MINOR_VERSION          (2)             // 次版本号
#define MCU1_SOFTWARE_STAGE_VERSION          (24)            // 阶段版本号

// CAN协议版本
#define CAN_PROTOCOL_VERSION                 (1)             // can协议版本号
#define FILE_VALID                  		 0x01            // 文件有效标志

// 外部通信协议版本号
#define EXTERNAL_PROTOCOL_MAJOR_VERSION       (1)               // 主版本号
#define EXTERNAL_PROTOCOL_MINOR_VERSION       (86)              // 次版本号

#pragma pack(push)
#pragma pack(1)
/**************** 设备配置参数-其他参数 需与共享内存中对应参数排列一致 ****************/
typedef struct{
	uint16_t address_rs485_1;                       // RS485-1地址
	uint32_t baud_rate_rs485_1;                     // RS485-1波特率
	uint32_t data_bits_rs485_1;                     // RS485-1数据位
	uint16_t stop_bit_rs485_1;                      // RS485-1停止位
	uint16_t check_bit_rs485_1;                     // RS485-1校验位
	uint16_t address_rs485_2;                       // RS485-2地址
	uint32_t baud_rate_rs485_2;                     // RS485-2波特率
	uint32_t data_bits_rs485_2;                     // RS485-2数据位
	uint16_t stop_bit_rs485_2;                      // RS485-2停止位
	uint16_t check_bit_rs485_2;                     // RS485-2校验位

	uint16_t address_rs485_4;                       // RS485-4地址
	uint32_t baud_rate_rs485_4;                     // RS485-4波特率
	uint32_t data_bits_rs485_4;                     // RS485-4数据位
	uint16_t stop_bit_rs485_4;                      // RS485-4停止位
	uint16_t check_bit_rs485_4;                     // RS485-4校验位

	uint16_t address_rs485_5;                       // RS485-5地址
	uint32_t baud_rate_rs485_5;                     // RS485-5波特率
	uint32_t data_bits_rs485_5;                     // RS485-5数据位
	uint16_t stop_bit_rs485_5;                      // RS485-5停止位
	uint16_t check_bit_rs485_5;                     // RS485-5校验位

	uint16_t address_rs485_6;                       // RS485-6地址
	uint32_t baud_rate_rs485_6;                     // RS485-6波特率
	uint32_t data_bits_rs485_6;                     // RS485-6数据位
	uint16_t stop_bit_rs485_6;                      // RS485-6停止位
	uint16_t check_bit_rs485_6;                     // RS485-6校验位

	uint16_t address_rs485_7;                       // RS485-7地址
	uint32_t baud_rate_rs485_7;                     // RS485-7波特率
	uint32_t data_bits_rs485_7;                     // RS485-7数据位
	uint16_t stop_bit_rs485_7;                      // RS485-7停止位
	uint16_t check_bit_rs485_7;                     // RS485-7校验位

    uint8_t  IP_ETH_1[NET_ADDR_LEN_MAX];              // ETH-1 IP地址
    uint16_t port_ETH_1;                              // ETH-1 端口号
    uint8_t  IP_server_ETH_1_104[NET_ADDR_LEN_MAX];   // ETH-1 104服务器IP地址
    uint16_t port_server_ETH_1_104;                   // ETH-1 014服务器端口号
    uint8_t  IP_server_ETH_1_61850[NET_ADDR_LEN_MAX]; // ETH-1 61850服务器IP地址
    uint16_t port_server_ETH_1_61850;                 // ETH-1 61850服务器端口号 
    
    uint8_t  IP_ETH_2[NET_ADDR_LEN_MAX];              // ETH-2 IP地址
    uint16_t port_ETH_2;                              // ETH-2 端口号
    uint8_t  gw_ETH_2[NET_ADDR_LEN_MAX];              // ETH-2 GW
	uint8_t  mask_ETH_2[NET_ADDR_LEN_MAX];            // ETH-2 MASK
	uint8_t  DNS1_ETH_2[NET_ADDR_LEN_MAX];            // ETH-2 NDS1地址
	uint8_t  DNS2_ETH_2[NET_ADDR_LEN_MAX];            // ETH-2 NDS2地址
    uint8_t  IP_server_ETH_2_104[NET_ADDR_LEN_MAX];   // ETH-2 104服务器IP地址
    uint16_t port_server_ETH_2_104;                   // ETH-2 104服务器端口号   
    uint8_t  IP_server_ETH_2_61850[NET_ADDR_LEN_MAX]; // ETH-1 61850服务器IP地址
    uint16_t port_server_ETH_2_61850;                 // ETH-1 61850服务器端口号 

	uint8_t  ETH3mode;								  // ETH-3 主从
    uint8_t  IP_ETH_3[NET_ADDR_LEN_MAX];              // ETH-3 IP地址
    uint16_t port_ETH_3;                              // ETH-3 端口号
    uint8_t  IP_server_ETH_3[NET_ADDR_LEN_MAX];       // ETH-3 服务器IP地址
    uint16_t port_server_ETH_3;                       // ETH-3 服务器端口号

    uint16_t state_ctr;                             // 工厂模式-状态控制字；Bit0-Bit7：工厂模式使能位 单板测试使能位 T1完成标志 老化完成标志 T2完成标志 包装测试完成标志 电池老化模式使能 电池激活
    uint16_t privilege_ctrl_word;                   // 工厂模式-特权控制字；每位写入0无效，写入1有效。Bit0：清除校准系数 Bit1：清除运行数据 Bit2：清除故障录波

}device_paramater_other_t;


/**************** 设备配置参数-CMU系统参数 定值/参数数据 需与共享内存中对应参数排列一致 ****************/
typedef  struct {

    uint16_t storage_duration_operation_data;       // 运行数据存储天数 0~360天
    uint16_t storage_freq_operation_data;           // 运行数据存储频率 3min~60min
    uint16_t number_fault_record;                   // 故障录波条数 0~10条
    uint16_t safety_rdr_country;					//安规国家
	uint16_t ver_safety_rdr_para;				//安规参数版本号
    
}device_paramater_sys_t;


/**************** 设备配置参数 ****************/
typedef  struct {

    uint16_t validity_flag;                             // 文件有效性标志
    device_paramater_other_t dev_param_other_data;      // 需通过非104协议传输的其他设置参数 
    device_paramater_sys_t device_paramater_sys_data;   // 系统设置参数

}device_paramater_t;
#pragma pack(pop)

#pragma pack(push)
#pragma pack(1)
/**************** 工厂设置参数 ****************/
typedef  struct {

    uint16_t validity_flag;         // 文件有效性标志

    // 工厂模式-状态控制字；
    uint16_t state_ctr;             // Bit0-Bit7：工厂模式使能位 单板测试使能位 T1完成标志 老化完成标志 T2完成标志 包装测试完成标志 电池老化模式使能 电池激活

    // 工厂模式-特权控制字；每位写入0无效，写入1有效。
    uint16_t privilege_ctrl_word;   // Bit0：清除校准系数 Bit1：清除运行数据 Bit2：清除故障录波

}factory_paramater_t;
#pragma pack(pop)


#pragma pack(push)
#pragma pack(1)
/**************** EMS参数 ****************/
typedef  struct {

    uint16_t validity_flag;         // 文件有效性标志
    ems_data_t ems_parameter_data;
    energy_price_t energy_price;
    ems_holiday_data_t ems_holiday_data;
}ems_paramater_t;
#pragma pack(pop)


/**
 * @brief   设备配置参数存储
 * @param   
 * @retval  0       成功
 * @retval  其他    失败
*/
int32_t dev_param_save(void);


/**
 * @brief   工厂参数存储
 * @param   
 * @retval  0       成功
 * @retval  其他    失败
*/
int32_t factory_param_save(void);


/**
 * @brief   EMS参数存储
 * @param   
 * @retval  0       成功
 * @retval  其他    失败
*/
int32_t ems_param_save(void);


/**
 * @brief 参数存储模块初始化
 * @return void
 */
void param_record_module_init(void);

#endif
