#ifndef __BOX_TRANSFORMER_H__
#define __BOX_TRANSFORMER_H__


#include "data_types.h"

#define RS_656          1       //金盘
#define XBJK200         2       //伊戈尔

#define MODBUS_02_READ_CMD       0x02
#define MODBUS_03_READ_CMD       0x03
#define MODBUS_04_READ_CMD       0x04
#define MODBUS_05_WRITE_CMD      0x05
#define MODBUS_06_WRITE_CMD      0x06
#define MODBUS_10_WRITE_CMD      0x10
#define MODBUS_18_WRITE_CMD      0x18

#define TRANSFORMER RS_656
#if(TRANSFORMER == RS_656)
#define MEASURE_DEV_SLAVE_ADDR	1       //测控地址
#define THERMOSTAT_SLAVE_ADDR	2       //温控地址
#define ELEC_METER_SLAVE_ADDR	3       //电表地址
#define TEMP_HUMI_SLAVE_ADDR	4       //温湿度传感地址

#define MEASURE_DEV_CMD_02_ADDR_START      0x0000  // 起始地址
#define MEASURE_DEV_CMD_02_REG_CNT         0x0032  // 寄存器数量

#define MEASURE_DEV_CMD_04_ADDR_START      0x0000  // 起始地址
#define MEASURE_DEV_CMD_04_REG_CNT         0x001A  // 寄存器数量

#define THERMOSTAT_DEV_CMD_03_ADDR_START   0x0000  // 起始地址
#define THERMOSTAT_DEV_CMD_03_REG_CNT      0x0003  // 寄存器数量

#define ELEC_METER_DEV_CMD_03_ADDR_START   0x001A  // 起始地址
#define ELEC_METER_DEV_CMD_03_REG_CNT      0x000C  // 寄存器数量

#define TEMP_HUMI_DEV_CMD_04_ADDR_START   0x0020  // 起始地址
#define TEMP_HUMI_DEV_CMD_04_REG_CNT      0x0003  // 寄存器数量

#define CMD_05_BREAKER_ADDR               0x0003         

#elif(TRANSFORMER == XBJK200)

#define MODBUS_SLAVE_ADDR	1

/********02指令**************/
#define CMD_02_ADDR_START      0x0000  // 起始地址
#define CMD_02_REG_CNT         0x005D  // 寄存器数量

/********03指令**************/
#define CMD_03_CUR_AREA_CODE_ADDR    0x0FFF  // 当前定值区地址
#define CMD_CUR_AREA_CODE_REG_CNT    0x0001  // 寄存器数量

#define CMD_03_CUR_AREA_DATA_ADDR    0x1000  // 当前定值区地址
#define CMD_CUR_AREA_DATA_REG_CNT    0x0038  // 寄存器数量


/********04指令**************/
#define CMD_04_TYPE1_ADDR_START      0x2000  // 起始地址
#define CMD_04_TYPE1_REG_CNT         0x001E  // 寄存器数量

#define CMD_04_TYPE2_ADDR_START      0x2100  // 起始地址
#define CMD_04_TYPE2_REG_CNT         0x0010  // 寄存器数量

/********05指令**************/
#define CMD_05_CTL_CMD               0xFF00
#define CMD_05_SIG_RESET_ADDR        0x3000  // 复归地址
#define CMD_05_BREAKER1_OFF_ADDR     0x3001  // 遥跳断路器 1
#define CMD_05_BREAKER1_ON_ADDR      0x3002  // 遥合断路器 1
#define CMD_05_BREAKER2_OFF_ADDR     0x3003  // 遥跳断路器 2
#define CMD_05_BREAKER2_ON_ADDR      0x3004  // 遥合断路器 2
#define CMD_05_BREAKER3_OFF_ADDR     0x3005  // 遥跳断路器 3
#define CMD_05_BREAKER3_ON_ADDR      0x3006  // 遥合断路器 3
#define CMD_05_BREAKER4_OFF_ADDR     0x3007  // 遥跳断路器 4
#define CMD_05_BREAKER4_ON_ADDR      0x3008  // 遥合断路器 4

/********06指令**************/
#define CMD_06_FIXED_AREA_SWITCH_ADDR   0x4000  // 定值区切换地址
#define CMD_06_PLATE_SWITCH_ADDR        0x4001  // 压板投退地址

/********10指令**************/
#define CMD_10_FIXED_AREA_DATA_ADDR     0x1000  // 当前定值区数据地址
#define CMD_10_REG_CNT                  0x0038  // 寄存器数量
#define DATA_LEN                        0x70

#define CMD_10_TIME_ADDR                0x1900  // 校时寄存器地址
#define CMD_10_TIME_REG_CNT             0x0003  // 寄存器数量
#define TIME_DATA_LEN                   0x06
#endif

#define BOX_TRANSFORMER_UART    2

#define BOX_TRANSFORMER_TIMEOUE	500
#define BOX_TRANSFORMER_BUF_SIZE	256
// (p_data[11] << 16) + (p_data[10] << 24) + p_data[9] + (p_data[8] << 8)

#define GET_BIT(x, bit) ((x & (1 << bit)) >> bit)

#define MODBUS_GET_INT32_FROM_INT8(tab_int8, index) \
    (tab_int8[(index)    ] << 8) + \
    (tab_int8[(index) + 1]) + \
    (tab_int8[(index) + 2] << 24) + \
    (tab_int8[(index) + 3] << 16)

#define print_log(format,argc...){ \
	printf("%s[%s:%d]=>",__FILE__,__func__,__LINE__); \
	printf(format,##argc); \
	printf("\n"); \
}

#define print_frame(buf, len) \
    do {                                               \
        uint8_t tmp_length = (len);                     \
        uint8_t tmp_i = 0;                              \
        for (tmp_i = 0; tmp_i < tmp_length; ) { \
            printf(" %02X", (buf)[tmp_i]);  \
			tmp_i++;	\
			if((tmp_i % 16) == 0) {	\
				printf("\n");  \
			}	\
        }                                              \
        printf("\n");                    \
    } while (0)

typedef struct{
    int32_t course_flag;            		// 交互进行标志
	int32_t devaddr;			    		// 用于记录当前发送包的设备地址
	int32_t commbreak_flag;		    		// 通讯中断标志 0：正常，1:通讯中断
	int32_t commerr_cnt;	        		// 记录通讯异常包连续次数
    uint8_t txbuf[BOX_TRANSFORMER_BUF_SIZE];    // 发送包缓存
    uint8_t rxbuf[BOX_TRANSFORMER_BUF_SIZE];    // 接收包缓存
}box_transformer_task_t;

/**
 * @brief  断路器控制
 * @param  [in] ctl_flag:控制类型标识，bit0~bit7
 */
void box_transformer_breaker_switch_set(uint8_t ctl_flag);


#endif
