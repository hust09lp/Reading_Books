/*****************************************************************************
* File Name			: box_transformer.c			
* Description		: 	
* Original Author	: xt
* date				: 
******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/prctl.h>
#include <unistd.h>

#include "update_task.h"
#include "sdk_shm.h"
#include "data_shm.h"
#include "cu_sofar_sci.h"
#include "sdk_uart.h"
#include "sofar_log.h"
#include "sdk_public.h"
#include "sci_task.h"
#include "modbus.h"
#include "box_transformer.h"
#include "data_shm.h"

static box_transformer_task_t g_box_transformer_data = {0};

#define COMMBREAKCNT_MAX	1		//通信最大中断数量
static uint8_t commerr_cnt = 0;		//通信异常计数
static uint8_t commbreak_flag = 0;	//通信中断标志

/**
 * @brief  参数、数据列表初始化
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void box_transformer_data_init(void)
{
	memset(&g_box_transformer_data, 0, sizeof(box_transformer_task_t));
	print_log((int8_t *)"\n [%s:%d] task init over\n",__func__, __LINE__);
}


/**
 * @brief  通讯异常计数
 * @param  [in] devid  设备地址
 * @param  [in] berror 1 异常；0 正常
 * @param  [in] btimeout 1 接收超时异常；0 正常接收未超时
 * @param  [out] none
 * @return none
 */
static void box_transformer_error_handle(int32_t devid, int32_t berror, int32_t btimeout)
{
	uint32_t step_cnt = 1;
	common_data_t *shm = NULL;

	shm = sdk_shm_get();

	if(btimeout == 1)
	{
		step_cnt = 2;
	}
	//连续通讯异常包统计
	if(berror)
	{
		commerr_cnt += step_cnt;
		if(commerr_cnt >= COMMBREAKCNT_MAX)
		{
			commerr_cnt = COMMBREAKCNT_MAX;
			commbreak_flag = 1;
			// g_sci_task.commbreak_flag |= 1 << (devid - 1) ;
			// 置共享内存里对应故障位--箱变通信故障
			shm->telematic_data.csu_system_fault_info[1] |= (1 << 0);
			print_log((int8_t *)("\n [%s:%d] tranformer commbreak!\n"),__func__, __LINE__);
		}
	}
	else
	{
		commerr_cnt = 0;
		commbreak_flag = 0; 
		// 箱变故障之后恢复，握手一次；清共享内存里对应故障位
		shm->telematic_data.csu_system_fault_info[1] &= ~(1 << 0);
	}
	return;
}


/**
 * @brief  箱变通讯任务初始化
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void box_transformer_task_init(void)
{
	int32_t retry_cnt = UART_INIT_RETRYCNT;
	sdk_uart_conf_t arrt = {UART_BAUD_RATE_9600, UART_DATA_BITS_8, UART_STOP_BITS_1, UART_PARITY_NONE, UART_HWFLOW_OFF};

	while(retry_cnt--)
	{
		// 打开串口
		if(sdk_uart_open(BOX_TRANSFORMER_UART) != 0) 
		{
			print_log((int8_t *)"\n [%s:%d] sdk_uart_open faild\n",__func__, __LINE__);
			continue;
		}
		print_log((int8_t *)"\n [%s:%d] sdk_uart_open over\n",__func__, __LINE__);

		// 配置串口
		print_log((int8_t *)"\n [%s:%d] uart setup start!\n",__func__, __LINE__);	
		if(sdk_uart_setup(BOX_TRANSFORMER_UART, &arrt) == 0)
		{
			print_log((int8_t *)"\n [%s:%d] sdk_setup over\n",__func__, __LINE__);
			break;
		}
		print_log((int8_t *)("\n [%s:%d] sdk_uart_setup faild\n"),__func__, __LINE__);
	}

	// 参数数据列表初始化
	box_transformer_data_init();

	return;
}


/**
 * @brief  modbus数据打包
 * @param  [in] addr：地址
 * @param  [in] func_code：功能码
 * @param  [in] p_data：数据内容
 * @param  [in] data_len：数据长度
 * @param  [out] p_buff：打包数据
 * @return >0:正常  0:异常
 */
static uint8_t modbus_pack(uint8_t addr, uint8_t func_code, uint8_t *p_data, uint8_t data_len, uint8_t *p_buff)
{
	uint8_t pos = 0;

	if(p_data == NULL || p_buff == NULL)
	{
		print_log("param is NULL, error");
		return 0;
	}

	p_buff[pos++] = addr;
	p_buff[pos++] = func_code;

	memcpy(&p_buff[2], p_data, data_len);
	pos += data_len;

	uint16_t crc16 = crc16_modbus(p_buff, pos);
	p_buff[pos++]  = crc16 >> 8;
	p_buff[pos++] = crc16 & 0xff;

	return pos;
}


/**
 * @brief  modbus数据合法性校验
 * @param  [in] p_buff：数据
 * @param  [in] buff_len：数据长度
 * @return >0:正常  0:异常
 */
static uint8_t modbus_unpack(uint8_t *p_buff, uint8_t buff_len)
{
	uint8_t func_code = 0;

	if(p_buff == NULL || buff_len == 0)
	{
		print_log("param is NULL, error");
		return 0;
	}

	func_code = p_buff[1];

	if((func_code != MODBUS_02_READ_CMD) && (func_code != MODBUS_03_READ_CMD) && (func_code != MODBUS_04_READ_CMD) && \
	   (func_code != MODBUS_05_WRITE_CMD) && (func_code != MODBUS_06_WRITE_CMD) && (func_code != MODBUS_10_WRITE_CMD) && \
	   (func_code != MODBUS_18_WRITE_CMD))
	{
		print_log("data unpack error");
		return 0;
	}

	uint16_t crc16 = crc16_modbus(p_buff, buff_len - 2);
	uint16_t tmp_crc = htons(*(uint16_t *)&p_buff[buff_len - 2]);

	if(crc16 != (tmp_crc))
	{
		print_log("crc checksum error, crc16:%04x  tmp_crc:%04x", crc16, tmp_crc);
		return 0;
	}

	return 1;
}


#if(TRANSFORMER == RS_656)
/**
 * @brief  modbus箱变遥信信息处理
 * @param  [in] p_data：数据内容
 * @return none
 */
static void remote_sig_info_handle(uint8_t *p_data)
{
	box_transformer_info_t *p_box_transformer_data = sdk_shm_box_transformer_data_info_get();
	transformer_remote_sig_t *p_remote_sig = &(p_box_transformer_data->remote_sig_status);

	if(p_box_transformer_data == NULL)
	{
		print_log("box transformer data is NULL\n" );
		return;
	}
	p_remote_sig->ultra_h_temp_trip = 			GET_BIT(p_data[0], 2);
	p_remote_sig->H_temp_alarm = 				GET_BIT(p_data[0], 3);
	p_remote_sig->transformer_door_open_alarm = GET_BIT(p_data[1], 0);
	p_remote_sig->H_L_volt_door_open_alarm = 	GET_BIT(p_data[1], 1);
	p_remote_sig->H_L_volt_smoke_alarm = 		GET_BIT(p_data[1], 5);
	p_remote_sig->H_L_volt_temp_alarm = 		GET_BIT(p_data[1], 6);
	p_remote_sig->H_volt_side_switch_close = 	GET_BIT(p_data[1], 7);
	p_remote_sig->H_volt_side_switch_open = 	GET_BIT(p_data[2], 0);
	p_remote_sig->H_volt_side_isolate_switch_close = GET_BIT(p_data[3], 0);
	p_remote_sig->H_volt_side_isolate_switch_open = GET_BIT(p_data[3], 1);
	p_remote_sig->remote_location = 			GET_BIT(p_data[3], 2);
	p_remote_sig->H_volt_fusing_sig = 			GET_BIT(p_data[3], 3);
	p_remote_sig->H_volt_power_disappear = 		GET_BIT(p_data[3], 4);
	p_remote_sig->alarm_total_sig = 			GET_BIT(p_data[6], 0);
	p_remote_sig->accident_total_sig = 			GET_BIT(p_data[6], 1);

}

/**
 * @brief  测控遥测数据处理
 * @param  [in] p_data：数据内容
 * @return none
 */
static void telemetry_data_handle(uint8_t *p_data)
{
	box_transformer_info_t *p_box_transformer_data = sdk_shm_box_transformer_data_info_get();
	transformer_telemetry_data_t *p_telemetry_data = &(p_box_transformer_data->telemetry_data);

	if(p_box_transformer_data == NULL)
	{
		print_log("box transformer data is NULL\n" );
		return;
	}

	p_telemetry_data->phase_ab_volt = htons(*(uint16_t *)&p_data[6]);
	p_telemetry_data->phase_ca_volt = htons(*(uint16_t *)&p_data[8]);
	p_telemetry_data->phase_bc_volt = htons(*(uint16_t *)&p_data[10]);
	p_telemetry_data->sys_freq = htons(*(uint16_t *)&p_data[18]);
}


/**
 * @brief  温控器数据处理
 * @param  [in] p_data：数据内容
 * @return none
 */
static void thermostat_data_handle(uint8_t *p_data)
{
	box_transformer_info_t *p_box_transformer_data = sdk_shm_box_transformer_data_info_get();
	transformer_telemetry_data_t *p_telemetry_data = &(p_box_transformer_data->telemetry_data);

	if(p_box_transformer_data == NULL)
	{
		print_log("box transformer data is NULL\n" );
		return;
	}

	p_telemetry_data->tempA = htons(*(uint16_t *)&p_data[0]);
	p_telemetry_data->tempB = htons(*(uint16_t *)&p_data[2]);
	p_telemetry_data->tempC = htons(*(uint16_t *)&p_data[4]);
}


/**
 * @brief  电表数据处理
 * @param  [in] p_data：数据内容
 * @return none
 */
static void elec_meter_data_handle(uint8_t *p_data)
{
	box_transformer_info_t *p_box_transformer_data = sdk_shm_box_transformer_data_info_get();
	transformer_telemetry_data_t *p_telemetry_data = &(p_box_transformer_data->telemetry_data);

	if(p_box_transformer_data == NULL)
	{
		print_log("box transformer data is NULL\n" );
		return;
	}
	//实际取值/100
	p_telemetry_data->positive_active_energy = MODBUS_GET_INT32_FROM_INT8(p_data, 0);
	p_telemetry_data->positive_reactive_energy = MODBUS_GET_INT32_FROM_INT8(p_data, 20);
}


/**
 * @brief  温湿度传感数据处理
 * @param  [in] p_data：数据内容
 * @return none
 */
static void temp_humi_data_handle(uint8_t *p_data)
{
	box_transformer_info_t *p_box_transformer_data = sdk_shm_box_transformer_data_info_get();
	transformer_telemetry_data_t *p_telemetry_data = &(p_box_transformer_data->telemetry_data);

	if(p_box_transformer_data == NULL)
	{
		print_log("box transformer data is NULL\n" );
		return;
	}
	//实际取值/10(%)
	p_telemetry_data->transformer_temp_humi = htons(*(uint16_t *)&p_data[2]);
}


/**
 * @brief  modbus数据解析
 * @param  [in] p_buff：数据内容
 * @param  [in] buff_len：数据长度
 * @return >0:正常  0:异常
 */
static uint8_t modbus_parse(uint8_t *p_buff, uint8_t buff_len)
{
	uint8_t func_code = 0;
	uint8_t slave_addr = 0;

	slave_addr = p_buff[0];
	func_code = p_buff[1];

	if(slave_addr == MEASURE_DEV_SLAVE_ADDR)
	{
		box_transformer_error_handle(0, 0, 0);
		switch(func_code)
		{
			case MODBUS_02_READ_CMD:
				remote_sig_info_handle(&p_buff[3]);
				break;

			case MODBUS_04_READ_CMD:
				telemetry_data_handle(&p_buff[3]);
				break;
			
			default:
				break;
		}
	}
	else if(slave_addr == THERMOSTAT_SLAVE_ADDR)
	{
		box_transformer_error_handle(0, 0, 0);
		if(func_code == MODBUS_03_READ_CMD)
		{
			thermostat_data_handle(&p_buff[3]);
		}
	}
	else if(slave_addr == ELEC_METER_SLAVE_ADDR)
	{
		box_transformer_error_handle(0, 0, 0);
		if(func_code == MODBUS_03_READ_CMD)
		{
			elec_meter_data_handle(&p_buff[3]);
		}
	}
	else if(slave_addr == TEMP_HUMI_SLAVE_ADDR)
	{
		box_transformer_error_handle(0, 0, 0);
		if(func_code == MODBUS_04_READ_CMD)
		{
			temp_humi_data_handle(&p_buff[3]);
		}
	}
	return 1;
}


/**
 * @brief  获取遥信信息,寄存器地址：0~49
 */
static void get_remote_sig_info()
{
	int32_t recv_len = -1;
	uint8_t tx_payload[4] = {0};
	
	memset(g_box_transformer_data.txbuf, 0, sizeof(g_box_transformer_data.txbuf));
	// 查询状态
	MODBUS_SET_INT16_TO_INT8(tx_payload, 0, MEASURE_DEV_CMD_02_ADDR_START);
	MODBUS_SET_INT16_TO_INT8(tx_payload, 2, MEASURE_DEV_CMD_02_REG_CNT);

	uint8_t len = modbus_pack(MEASURE_DEV_SLAVE_ADDR, MODBUS_02_READ_CMD, tx_payload, 4, g_box_transformer_data.txbuf);
	if(len > 0)
	{
		// for(uint8_t i = 0; i < UART_INIT_RETRYCNT; i++)
		for(uint8_t i = 0; i < 1; i++)
		{
			print_frame(g_box_transformer_data.txbuf, len);
			int32_t ret = sdk_uart_write(BOX_TRANSFORMER_UART, g_box_transformer_data.txbuf, len);
			
			// 获取应答结果
			if(ret >= 0)
			{
			 	recv_len = sdk_uart_read(BOX_TRANSFORMER_UART, g_box_transformer_data.rxbuf, BOX_TRANSFORMER_BUF_SIZE, BOX_TRANSFORMER_TIMEOUE);
				if(recv_len > 0)
				{	
					print_log("ack ok and valid_data_len = %d\n",recv_len);
					print_frame(g_box_transformer_data.rxbuf, recv_len);
					modbus_unpack(g_box_transformer_data.rxbuf, recv_len);
					modbus_parse(g_box_transformer_data.rxbuf, recv_len);
					break;
				}
				else
				{
					box_transformer_error_handle(0, 1, 1);
					print_log("ack error and ret = %d\n",ret);
				}
			}
			
			usleep(1000 * 100);
		}
	}
}


/**
 * @brief  获取04指令遥测信息
 */
static void get_telemetry_data()
{
	int32_t recv_len = -1;
	uint8_t tx_payload[4] = {0};
	
	memset(g_box_transformer_data.txbuf, 0, sizeof(g_box_transformer_data.txbuf));
	// 查询数据
	MODBUS_SET_INT16_TO_INT8(tx_payload, 0, MEASURE_DEV_CMD_04_ADDR_START);
	MODBUS_SET_INT16_TO_INT8(tx_payload, 2, MEASURE_DEV_CMD_04_REG_CNT);

	uint8_t len = modbus_pack(MEASURE_DEV_SLAVE_ADDR, MODBUS_04_READ_CMD, tx_payload, 4, g_box_transformer_data.txbuf);
	if(len > 0)
	{
		// for(uint8_t i = 0; i < UART_INIT_RETRYCNT; i++)
		for(uint8_t i = 0; i < 1; i++)
		{
			print_frame(g_box_transformer_data.txbuf, len);
			int32_t ret = sdk_uart_write(BOX_TRANSFORMER_UART, g_box_transformer_data.txbuf, len);
			
			// 获取应答结果
			if(ret >= 0)
			{
			 	recv_len = sdk_uart_read(BOX_TRANSFORMER_UART, g_box_transformer_data.rxbuf, BOX_TRANSFORMER_BUF_SIZE, BOX_TRANSFORMER_TIMEOUE);
				if(recv_len > 0)
				{	
					print_log("ack ok and valid_data_len = %d\n",recv_len);
					print_frame(g_box_transformer_data.rxbuf, recv_len);
					modbus_unpack(g_box_transformer_data.rxbuf, recv_len);
					modbus_parse(g_box_transformer_data.rxbuf, recv_len);
					break;
				}
				else
				{
					box_transformer_error_handle(0, 1, 1);
					print_log("ack error and ret = %d\n",ret);
				}
			}
			
			usleep(1000 * 100);
		}
	}
}


/**
 * @brief  获取温控器遥测信息
 */
static void get_thermostat_data()
{
	int32_t recv_len = -1;
	uint8_t tx_payload[4] = {0};
	
	memset(g_box_transformer_data.txbuf, 0, sizeof(g_box_transformer_data.txbuf));
	// 查询数据
	MODBUS_SET_INT16_TO_INT8(tx_payload, 0, THERMOSTAT_DEV_CMD_03_ADDR_START);
	MODBUS_SET_INT16_TO_INT8(tx_payload, 2, THERMOSTAT_DEV_CMD_03_REG_CNT);

	uint8_t len = modbus_pack(THERMOSTAT_SLAVE_ADDR, MODBUS_03_READ_CMD, tx_payload, 4, g_box_transformer_data.txbuf);
	if(len > 0)
	{
		// for(uint8_t i = 0; i < UART_INIT_RETRYCNT; i++)
		for(uint8_t i = 0; i < 1; i++)
		{
			print_frame(g_box_transformer_data.txbuf, len);
			int32_t ret = sdk_uart_write(BOX_TRANSFORMER_UART, g_box_transformer_data.txbuf, len);
			
			// 获取应答结果
			if(ret >= 0)
			{
			 	recv_len = sdk_uart_read(BOX_TRANSFORMER_UART, g_box_transformer_data.rxbuf, BOX_TRANSFORMER_BUF_SIZE, BOX_TRANSFORMER_TIMEOUE);
				if(recv_len > 0)
				{	
					print_log("ack ok and valid_data_len = %d\n",recv_len);
					print_frame(g_box_transformer_data.rxbuf, recv_len);
					modbus_unpack(g_box_transformer_data.rxbuf, recv_len);
					modbus_parse(g_box_transformer_data.rxbuf, recv_len);
					break;
				}
				else
				{
					box_transformer_error_handle(0, 1, 1);
					print_log("ack error and ret = %d\n",ret);
				}
			}
			
			usleep(1000 * 100);
		}
	}
}


/**
 * @brief  获取电表遥测信息
 */
static void get_elec_meter_data()
{
	int32_t recv_len = -1;
	uint8_t tx_payload[4] = {0};
	
	memset(g_box_transformer_data.txbuf, 0, sizeof(g_box_transformer_data.txbuf));
	// 查询数据
	MODBUS_SET_INT16_TO_INT8(tx_payload, 0, ELEC_METER_DEV_CMD_03_ADDR_START);
	MODBUS_SET_INT16_TO_INT8(tx_payload, 2, ELEC_METER_DEV_CMD_03_REG_CNT);

	uint8_t len = modbus_pack(ELEC_METER_SLAVE_ADDR, MODBUS_03_READ_CMD, tx_payload, 4, g_box_transformer_data.txbuf);
	if(len > 0)
	{
		// for(uint8_t i = 0; i < UART_INIT_RETRYCNT; i++)
		for(uint8_t i = 0; i < 1; i++)
		{
			print_frame(g_box_transformer_data.txbuf, len);
			int32_t ret = sdk_uart_write(BOX_TRANSFORMER_UART, g_box_transformer_data.txbuf, len);
			
			// 获取应答结果
			if(ret >= 0)
			{
			 	recv_len = sdk_uart_read(BOX_TRANSFORMER_UART, g_box_transformer_data.rxbuf, BOX_TRANSFORMER_BUF_SIZE, BOX_TRANSFORMER_TIMEOUE);
				if(recv_len > 0)
				{	
					print_log("ack ok and valid_data_len = %d\n",recv_len);
					print_frame(g_box_transformer_data.rxbuf, recv_len);
					modbus_unpack(g_box_transformer_data.rxbuf, recv_len);
					modbus_parse(g_box_transformer_data.rxbuf, recv_len);
					break;
				}
				else
				{
					box_transformer_error_handle(0, 1, 1);
					print_log("ack error and ret = %d\n",ret);
				}
			}
			
			usleep(1000 * 100);
		}
	}
}


/**
 * @brief  获取温湿度传感信息
 */
static void get_temp_humi_data()
{
	int32_t recv_len = -1;
	uint8_t tx_payload[4] = {0};
	
	memset(g_box_transformer_data.txbuf, 0, sizeof(g_box_transformer_data.txbuf));
	// 查询数据
	MODBUS_SET_INT16_TO_INT8(tx_payload, 0, TEMP_HUMI_DEV_CMD_04_ADDR_START);
	MODBUS_SET_INT16_TO_INT8(tx_payload, 2, TEMP_HUMI_DEV_CMD_04_REG_CNT);

	uint8_t len = modbus_pack(TEMP_HUMI_SLAVE_ADDR, MODBUS_03_READ_CMD, tx_payload, 4, g_box_transformer_data.txbuf);
	if(len > 0)
	{
		// for(uint8_t i = 0; i < UART_INIT_RETRYCNT; i++)
		for(uint8_t i = 0; i < 1; i++)
		{
			print_frame(g_box_transformer_data.txbuf, len);
			int32_t ret = sdk_uart_write(BOX_TRANSFORMER_UART, g_box_transformer_data.txbuf, len);
			
			// 获取应答结果
			if(ret >= 0)
			{
			 	recv_len = sdk_uart_read(BOX_TRANSFORMER_UART, g_box_transformer_data.rxbuf, BOX_TRANSFORMER_BUF_SIZE, BOX_TRANSFORMER_TIMEOUE);
				if(recv_len > 0)
				{	
					print_log("ack ok and valid_data_len = %d\n",recv_len);
					print_frame(g_box_transformer_data.rxbuf, recv_len);
					modbus_unpack(g_box_transformer_data.rxbuf, recv_len);
					modbus_parse(g_box_transformer_data.rxbuf, recv_len);
					break;
				}
				else
				{
					box_transformer_error_handle(0, 1, 1);
					print_log("ack error and ret = %d\n",ret);
				}
			}
			
			usleep(1000 * 100);
		}
	}
}


/**
 * @brief  断路器控制
 * @param  [in] ctl_flag:控制类型标识，bit0~bit7
 */
void box_transformer_breaker_switch_set(uint8_t ctl_flag)
{
	int32_t recv_len = -1;
	uint8_t tx_payload[4] = {0};
	
	memset(g_box_transformer_data.txbuf, 0, sizeof(g_box_transformer_data.txbuf));

	MODBUS_SET_INT16_TO_INT8(tx_payload, 0, CMD_05_BREAKER_ADDR);
	switch(ctl_flag)
	{
		case 0x01:
			MODBUS_SET_INT16_TO_INT8(tx_payload, 2, 0x0000);
			break;

		case 0x02:
			MODBUS_SET_INT16_TO_INT8(tx_payload, 2, 0xFF00);
			break;

		default:
			break;
	}

	uint8_t len = modbus_pack(MEASURE_DEV_SLAVE_ADDR, MODBUS_05_WRITE_CMD, tx_payload, 4, g_box_transformer_data.txbuf);
	if(len > 0)
	{
		// for(uint8_t i = 0; i < UART_INIT_RETRYCNT; i++)
		for(uint8_t i = 0; i < 1; i++)
		{
			print_frame(g_box_transformer_data.txbuf, len);
			int32_t ret = sdk_uart_write(BOX_TRANSFORMER_UART, g_box_transformer_data.txbuf, len);
			
			// 获取应答结果
			if(ret >= 0)
			{
			 	recv_len = sdk_uart_read(BOX_TRANSFORMER_UART, g_box_transformer_data.rxbuf, BOX_TRANSFORMER_BUF_SIZE, BOX_TRANSFORMER_TIMEOUE);
				if(recv_len > 0)
				{	
					print_log("ack ok and valid_data_len = %d\n",recv_len);
					print_frame(g_box_transformer_data.rxbuf, recv_len);
					modbus_unpack(g_box_transformer_data.rxbuf, recv_len);
					modbus_parse(g_box_transformer_data.rxbuf, recv_len);
					break;
				}
				else
				{
					box_transformer_error_handle(0, 1, 0);
					print_log("ack error and ret = %d\n",ret);
				}
			}
			
			usleep(1000 * 100);
		}
	}
}
#endif

#if(TRANSFORMER == XBJK200)
/**
 * @brief  遥信信息处理
 * @param  [in] p_data：数据内容
 * @return none
 */
static void remote_sig_info_handle(uint8_t *p_data)
{
	box_transformer_info_t *p_box_transformer_data = sdk_shm_box_transformer_data_info_get();
	transformer_remote_sig_t *p_remote_sig = &(p_box_transformer_data->remote_sig_status);

	if(p_box_transformer_data == NULL)
	{
		print_log("box transformer data is NULL\n" );
		return;
	}
	p_remote_sig->ultra_h_temp_trip = 			GET_BIT(p_data[0], 2);
	p_remote_sig->H_temp_alarm = 				GET_BIT(p_data[0], 3);
	p_remote_sig->transformer_door_open_alarm = GET_BIT(p_data[2], 2);
	p_remote_sig->H_L_volt_door_open_alarm = 	GET_BIT(p_data[2], 1);
	p_remote_sig->H_L_volt_smoke_alarm = 		GET_BIT(p_data[1], 7);
	p_remote_sig->H_L_volt_temp_alarm = 		GET_BIT(p_data[2], 0);
	p_remote_sig->H_volt_side_switch_close = 	GET_BIT(p_data[1], 2);
	p_remote_sig->H_volt_side_switch_open = 	GET_BIT(p_data[1], 3);
	p_remote_sig->H_volt_side_isolate_switch_close = GET_BIT(p_data[2], 3);
	p_remote_sig->H_volt_side_isolate_switch_open = GET_BIT(p_data[2], 4);
	p_remote_sig->remote_location = 			GET_BIT(p_data[3], 1);
	p_remote_sig->H_volt_fusing_sig = 			GET_BIT(p_data[1], 4);
	p_remote_sig->H_volt_power_disappear = 		GET_BIT(p_data[2], 5);
	p_remote_sig->alarm_total_sig = 			GET_BIT(p_data[8], 7);
	p_remote_sig->accident_total_sig = 			GET_BIT(p_data[9], 0);
}

/**
 * @brief  遥测数据处理
 * @param  [in] p_data：数据内容
 * @param  [in] data_len：数据长度
 * @return none
 */
static void telemetry_data_handle(uint8_t *p_data, uint8_t data_len)
{
	box_transformer_info_t *p_box_transformer_data = sdk_shm_box_transformer_data_info_get();
	transformer_telemetry_data_t *p_telemetry_data = &(p_box_transformer_data->telemetry_data);

	if(p_box_transformer_data == NULL)
	{
		print_log("box transformer data is NULL\n" );
		return;
	}

	// 单寄存器数据类型
	if(data_len == 68)
	{
		p_telemetry_data->phase_ab_volt = htons(*(uint16_t *)&p_data[6]);
		p_telemetry_data->phase_ca_volt = htons(*(uint16_t *)&p_data[8]);
		p_telemetry_data->phase_bc_volt = htons(*(uint16_t *)&p_data[10]);
		p_telemetry_data->sys_freq = 	  htons(*(uint16_t *)&p_data[36]);
		p_telemetry_data->tempA = 		  htons(*(uint16_t *)&p_data[60]);
		p_telemetry_data->tempB = 		  htons(*(uint16_t *)&p_data[62]);
		p_telemetry_data->tempC = 		  htons(*(uint16_t *)&p_data[64]);
		p_telemetry_data->transformer_temp_humi = htons(*(uint16_t *)&p_data[66]);
	}
	// 双寄存器数据类型
	else if(data_len == 32)
	{
		p_simulate_data->positive_active_energy = MODBUS_GET_INT32_FROM_INT8(p_data, 0);
		p_simulate_data->positive_reactive_energy =  MODBUS_GET_INT32_FROM_INT8(p_data, 4);
	}
}


/**
 * @brief  modbus数据解析
 * @param  [in] p_buff：数据内容
 * @param  [in] buff_len：数据长度
 * @return >0:正常  0:异常
 */
static uint8_t modbus_parse(uint8_t *p_buff, uint8_t buff_len)
{
	uint8_t func_code = 0;

	func_code = p_buff[1];
	box_transformer_error_handle(0, 0, 0);
	switch(func_code)
	{
		case MODBUS_02_READ_CMD:
			remote_sig_info_handle(&p_buff[3]);
			break;
			
		case MODBUS_04_READ_CMD:
			simulate_data_handle(&p_buff[3], buff_len - 5);		// 根据接受的数据长度判断是什么类型的数据
			break;

		case MODBUS_05_WRITE_CMD:
		case MODBUS_06_WRITE_CMD:
		case MODBUS_10_WRITE_CMD:	
			break;

		default:
			break;
	}
	return 1;
}


/**
 * @brief  获取遥信信息,寄存器地址：0000~005C
 */
static void get_remote_sig_info()
{
	int32_t recv_len = -1;
	uint8_t tx_payload[4] = {0};
	
	memset(g_box_transformer_data.txbuf, 0, sizeof(g_box_transformer_data.txbuf));
	// 查询状态
	MODBUS_SET_INT16_TO_INT8(tx_payload, 0, CMD_02_ADDR_START);
	MODBUS_SET_INT16_TO_INT8(tx_payload, 2, CMD_02_REG_CNT);

	uint8_t len = modbus_pack(MODBUS_SLAVE_ADDR, MODBUS_02_READ_CMD, tx_payload, 4, g_box_transformer_data.txbuf);
	if(len > 0)
	{
		// for(uint8_t i = 0; i < UART_INIT_RETRYCNT; i++)
		for(uint8_t i = 0; i < 1; i++)
		{
			print_frame(g_box_transformer_data.txbuf, len);
			int32_t ret = sdk_uart_write(BOX_TRANSFORMER_UART, g_box_transformer_data.txbuf, len);
			
			// 获取应答结果
			if(ret >= 0)
			{
			 	recv_len = sdk_uart_read(BOX_TRANSFORMER_UART, g_box_transformer_data.rxbuf, BOX_TRANSFORMER_BUF_SIZE, BOX_TRANSFORMER_TIMEOUE);
				if(recv_len > 0)
				{	
					print_log("ack ok and valid_data_len = %d\n",recv_len);
					print_frame(g_box_transformer_data.rxbuf, recv_len);
					modbus_unpack(g_box_transformer_data.rxbuf, recv_len);
					modbus_parse(g_box_transformer_data.rxbuf, recv_len);
					break;
				}
				else
				{
					box_transformer_error_handle(0, 1, 1);
					print_log("ack error and ret = %d\n",ret);
				}
			}
			
			usleep(1000 * 100);
		}
	}
}


/**
 * @brief  获取04指令信息,寄存器地址：2000~201D  2100~210E，因地址不连续，需要分两次读取
 * @param  [in] type：1、读取单寄存器类型数据；2、读取双寄存器类型数据
 */
static void get_simulate_data(uint8_t type)
{
	int32_t recv_len = -1;
	uint8_t tx_payload[4] = {0};
	
	memset(g_box_transformer_data.txbuf, 0, sizeof(g_box_transformer_data.txbuf));
	// 查询数据
	if(type == 1)
	{
		MODBUS_SET_INT16_TO_INT8(tx_payload, 0, CMD_04_TYPE1_ADDR_START);
		MODBUS_SET_INT16_TO_INT8(tx_payload, 2, CMD_04_TYPE1_REG_CNT);
	}
	else if(type == 2)
	{
		MODBUS_SET_INT16_TO_INT8(tx_payload, 0, CMD_04_TYPE2_ADDR_START);
		MODBUS_SET_INT16_TO_INT8(tx_payload, 2, CMD_04_TYPE2_REG_CNT);
	}

	uint8_t len = modbus_pack(MODBUS_SLAVE_ADDR, MODBUS_04_READ_CMD, tx_payload, 4, g_box_transformer_data.txbuf);
	if(len > 0)
	{
		// for(uint8_t i = 0; i < UART_INIT_RETRYCNT; i++)
		for(uint8_t i = 0; i < 1; i++)
		{
			print_frame(g_box_transformer_data.txbuf, len);
			int32_t ret = sdk_uart_write(BOX_TRANSFORMER_UART, g_box_transformer_data.txbuf, len);
			
			// 获取应答结果
			if(ret >= 0)
			{
			 	recv_len = sdk_uart_read(BOX_TRANSFORMER_UART, g_box_transformer_data.rxbuf, BOX_TRANSFORMER_BUF_SIZE, BOX_TRANSFORMER_TIMEOUE);
				if(recv_len > 0)
				{	
					print_log("ack ok and valid_data_len = %d\n",recv_len);
					print_frame(g_box_transformer_data.rxbuf, recv_len);
					modbus_unpack(g_box_transformer_data.rxbuf, recv_len);
					modbus_parse(g_box_transformer_data.rxbuf, recv_len);
					break;
				}
				else
				{
					box_transformer_error_handle(0, 1, 1);
					print_log("ack error and ret = %d\n",ret);
				}
			}
			
			usleep(1000 * 100);
		}
	}
}



/**
 * @brief  断路器控制
 * @param  [in] ctl_flag:控制类型标识，bit0~bit7
 */
void box_transformer_breaker_switch_set(uint8_t ctl_flag)
{
	int32_t recv_len = -1;
	uint8_t tx_payload[4] = {0};
	
	memset(g_box_transformer_data.txbuf, 0, sizeof(g_box_transformer_data.txbuf));

	switch(ctl_flag)
	{
		case 0x01:
			MODBUS_SET_INT16_TO_INT8(tx_payload, 0, CMD_05_BREAKER2_OFF_ADDR);
			break;

		case 0x02:
			MODBUS_SET_INT16_TO_INT8(tx_payload, 0, CMD_05_BREAKER2_ON_ADDR);
			break;

		default:
			break;
	}

	MODBUS_SET_INT16_TO_INT8(tx_payload, 2, CMD_05_CTL_CMD);

	uint8_t len = modbus_pack(MODBUS_SLAVE_ADDR, MODBUS_05_WRITE_CMD, tx_payload, 4, g_box_transformer_data.txbuf);
	if(len > 0)
	{
		// for(uint8_t i = 0; i < UART_INIT_RETRYCNT; i++)
		for(uint8_t i = 0; i < 1; i++)
		{
			print_frame(g_box_transformer_data.txbuf, len);
			int32_t ret = sdk_uart_write(BOX_TRANSFORMER_UART, g_box_transformer_data.txbuf, len);
			
			// 获取应答结果
			if(ret >= 0)
			{
			 	recv_len = sdk_uart_read(BOX_TRANSFORMER_UART, g_box_transformer_data.rxbuf, BOX_TRANSFORMER_BUF_SIZE, BOX_TRANSFORMER_TIMEOUE);
				if(recv_len > 0)
				{	
					print_log("ack ok and valid_data_len = %d\n",recv_len);
					print_frame(g_box_transformer_data.rxbuf, recv_len);
					modbus_unpack(g_box_transformer_data.rxbuf, recv_len);
					modbus_parse(g_box_transformer_data.rxbuf, recv_len);
					break;
				}
				else
				{
					box_transformer_error_handle(0, 1, 0);
					print_log("ack error and ret = %d\n",ret);
				}
			}
			
			usleep(1000 * 100);
		}
	}
}
#endif

/**
 * @brief  箱变通讯任务管理,同步箱变信息
 * @param  [in] arg
 * @param  [out] none
 * @return 0:正常  负数:异常
 */
static int32_t box_transformer_task_manage(void)
{
// #if(TRANSFORMER == RS_656)
// 	// 获取遥信信息
// 	get_remote_sig_info();
// 	// 获取遥测数据
// 	get_telemetry_data();
// 	// 获取温控数据
// 	get_thermostat_data();
// 	// 获取电表数据
// 	get_elec_meter_data();
// 	// 获取电表数据
// 	get_temp_humi_data();
// #elif
// 	// 获取遥信信息
// 	get_remote_sig_info();
// 	// 获取遥测数据
// 	get_simulate_data(1);
// 	get_simulate_data(2);
// #endif
}


/**
 * @brief  箱变通讯线程
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
void *thread_transformer_comm(void *arg)
{
    uint8_t ret = 0;

	prctl(PR_SET_NAME, "box_transformer_comm_thread");
	sleep(1);							// 箱变线程,上电延时1s启动

	box_transformer_task_init();

	// box_transformer_task_manage();
	
	while(1)
	{   	
		box_transformer_task_manage();
		usleep(2000*1000);				// 500ms
	}

	pthread_exit(NULL);

}

/**
 * @brief  启动箱变通讯线程
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
void box_transformer_task_start(void)
{
	pthread_t box_transformer;
	pthread_attr_t attr;

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);

	if(pthread_create(&box_transformer,&attr,thread_transformer_comm,NULL) != 0)
	{
		perror("pthread_create thread_scicomm");
	}

	pthread_attr_destroy(&attr);
	return;
	
}