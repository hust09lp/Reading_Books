/** 
 * @file          default_parameters.c
 * @brief         默认参数备份及恢复接口函数功能实现
 * @author        liangguyao
 * @version       V0.0.1     初始版本
 * @date          2023/3/10
 * @copyright     Copyright (c) 2023 by SofarSolar, All Rights Reserved. 
 */


#include "default_parameters.h"
#include "sdk_fs.h"
#include "sdk_public.h"
#include "sdk_shm.h"
#include "sofar_log.h"
#include "sofar_errors.h"

#include <string.h>
#include <stdlib.h>


#define FLAG_ONE_KEY_RESET_SET	  	1
#define FLAG_ONE_KEY_RESET_CLEAR  	0


/**
 * @brief	包装测试完成, 备份出厂参数
 * @param	void	
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t backup_factory_parameter(void)
{
    return 0;
}

/**
 * @brief  	将一键恢复出厂设置的标志位写入文件保存
 * @param  	[in] flag 一键恢复出厂设置的标志位
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
static int32_t write_one_key_factory_reset_flag(int32_t flag)
{
    int32_t ret = SF_OK;
    uint32_t len;
    fs_t *p_fs;

    p_fs = sdk_fs_open((const int8_t *)PATH_ONE_KEY_FACTORY_RESET, FS_OPEN_ALWAYS);
    if (p_fs == NULL)
    {
        log_i((int8_t *)"\n [%s:%d] sdk_fs_open fail \n", __func__, __LINE__);
        return SF_ERR_OPEN;
    }

    len = sizeof(int32_t);
    ret = sdk_fs_write(p_fs, &flag, len);
	sdk_fs_close(p_fs);
    if (ret != len)
    {
        log_i((int8_t *)"\n [%s:%d] write fail: ret = %d, len = %d \n", __func__, __LINE__, ret, len);
        ret = SF_ERR_WR;
    }

    return ret;
}

/**
 * @brief  	读文件里一键恢复出厂设置的标志位
 * @param  	[in] void
 * @return 	[int32_t] 执行结果
 * @retval  1或0: 标志位值
 * @retval  -1: 失败
 */
static int32_t read_one_key_factory_reset_flag(void)
{
    int32_t ret;
	int32_t flag = FLAG_ONE_KEY_RESET_CLEAR;
    uint32_t len;
    fs_t *p_fs;

    p_fs = sdk_fs_open((const int8_t *)PATH_ONE_KEY_FACTORY_RESET, FS_READ);
    if (p_fs == NULL)
    {
        log_i((int8_t *)"\n [%s:%d] sdk_fs_open fail \n", __func__, __LINE__);
        return SF_ERR_OPEN;
    }

    len = sizeof(int32_t);
    ret = sdk_fs_read(p_fs, &flag, len);
	sdk_fs_close(p_fs);
    if (ret != len)
    {
        log_i((int8_t *)"\n [%s:%d] write fail: ret = %d, len = %d \n", __func__, __LINE__, ret, len);
        return SF_ERR_RD;
    }

    return (flag);
}

/**
 * @brief	一键恢复出厂设置的APP层处理
 * @details 1.将标志位写入文件 2.重启
 * @param	void
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t one_key_factory_reset_app_proc(void)
{
	int32_t ret;

	/* 1、将要一键恢复出厂设置的标志位写入文件 */
	ret = write_one_key_factory_reset_flag(FLAG_ONE_KEY_RESET_SET);
	if (ret == 0)
	{
		/* 2、重启arm，重新初始化 */
		log_i((int8_t *)"\n [%s:%d] reboot \n", __func__, __LINE__);
    	sdk_sys_reset();	//system("reboot -f");
	}
	else
	{
		log_i((int8_t *)"\n [%s:%d] write flag fail \n", __func__, __LINE__);
	}

	return ret;
}

/**
 * @brief	一键恢复出厂设置的守护进程处理
 * @details 1.读文件里的标志位 2.恢复出厂时备份出厂参数 3.清文件标志位
 * @param	void
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t one_key_factory_reset_daemon_proc(void)
{
	int32_t flag;
	int32_t ret = 0;

	flag = read_one_key_factory_reset_flag();

	if (flag == FLAG_ONE_KEY_RESET_SET)
	{
		//1、参数恢复
        /* 是否有安规待确定，先屏蔽 */
		//system("cp /user/data/factory_cfg/safety /user/data/cfg/safety");

		//2、数据清除
		sdk_fs_remove((const int8_t *)"/user/data/opt_record/");
		sdk_fs_remove((const int8_t *)"/user/data/battery/record/");
		sdk_fs_remove((const int8_t *)"/user/data/event/");
		sdk_fs_remove((const int8_t *)"/user/data/energy/");

		//3、清文件标志位
		ret = write_one_key_factory_reset_flag(FLAG_ONE_KEY_RESET_CLEAR);
		if (ret < 0)
		{
			log_i((int8_t *)"\n [%s:%d] clear flag fail \n", __func__, __LINE__);
		}
	}

	return ret;
}

