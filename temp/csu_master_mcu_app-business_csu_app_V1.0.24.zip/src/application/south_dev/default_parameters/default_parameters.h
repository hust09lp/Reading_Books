/** 
 * @file          default_parameters.h
 * @brief         默认参数备份及恢复接口函数
 * @author        liangguyao
 * @version       V0.0.1     初始版本
 * @date          2023/3/10
 * @copyright     Copyright (c) 2023 by SofarSolar, All Rights Reserved. 
 */

#ifndef __DEFAULT_PARAMETERS_H__
#define __DEFAULT_PARAMETERS_H__

#include "data_types.h"


#define PATH_ONE_KEY_FACTORY_RESET    "/user/data/one_key_reset"    // 一键恢复出厂设置的标志位文件



#pragma pack(push)
#pragma pack(1)

#pragma pack(pop)

/**
 * @brief	包装测试完成, 备份出厂参数
 * @param	void	
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t backup_factory_parameter(void);

/**
 * @brief	一键恢复出厂设置的APP层处理
 * @details 1.将标志位写入文件 2.重启
 * @param	void
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t one_key_factory_reset_app_proc(void);

/**
 * @brief	一键恢复出厂设置的守护进程处理
 * @details 1.读文件里的标志位 2.恢复出厂时备份出厂参数 3.清文件标志位
 * @param	void
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
int32_t one_key_factory_reset_daemon_proc(void);


#endif  /* __DEFAULT_PARAMETERS_H__ */