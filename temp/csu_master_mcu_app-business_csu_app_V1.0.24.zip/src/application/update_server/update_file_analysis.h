#ifndef _UPDATE_FILE_ANALYSIS_H_
#define _UPDATE_FILE_ANALYSIS_H_

#include "data_types.h"
#include "sdk_log.h"

#if (0)
#define UPDATE_DEBUG_PRINT(...) log_i((int8_t *)__VA_ARGS__);
#else
#define UPDATE_DEBUG_PRINT(...) {do {} while(0);}
#endif

#define     UPDATE_SELECT_U_PATH        1
#define     UPDATE_SELECT_OPT_PATH      2
//#define     UDISK_PATH                  "/media/sda/firmware/"  // U盘路径
#define     UDISK_PATH                  "/media/sda1/firmware/"  // U盘路径
#define     UPDATE_PATH                 "/user/update/"  				 // 升级固件路径
#define     UPDATE_PATH_TMP             "/user/update/temp"  		 // 暂时存放删除签名后的固件


#define     ESS3M44                    9   // 产品类型：工商业储能
#define     MODEL_ESS3M44              17   // 产品机型


// 新格式的文件类型编码
typedef enum
{
    FILE_APP_NUM = 0x00,
    FILE_CORE_NUM,
    FILE_KERNEL_NUM,
    FILE_ROOTFS_NUM,
    FILE_SAFETY_NUM,
    FILE_PACK_NUM = 0x80,
} file_type_num_e;

// 新格式的芯片编码
typedef enum
{
    ALMIGHTY_NUM = 0x00,    // 不查询编码
    //集中式储能
    PCS_M_NUM = 0x30,
    PCS_S_NUM,
    PCS_C_NUM,
    PCS_MCU1_NUM,
    PCS_MCU2_NUM,
    CSU_MCU1_NUM = 0x33,
    CSU_MCU2_NUM = 0x34,
} obj_num_e;


/**
 * @brief   升级文件包解析
 * @param   [in] arg
 * @note
 * @return
 */
void *update_file_analysis(void *arg);

#endif /* _UPDATE_FILE_CHECK_H_ */