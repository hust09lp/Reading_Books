#ifndef _PROCESS_MONITOR_H_
#define _PROCESS_MONITOR_H_

#include "data_types.h"
#include "sofar_log.h"

#if (1)
#define PROCESS_MONITOR_DEBUG_PRINT(...) log_i((int8_t *)__VA_ARGS__);
#else
#define PROCESS_MONITOR_DEBUG_PRINT(...) {do {} while(0);}
#endif



/**
 * @brief   进程运行状态监测线程
 * @param   [in] arg
 * @note
 * @return
 */
void *process_monitor(void *arg);

#endif