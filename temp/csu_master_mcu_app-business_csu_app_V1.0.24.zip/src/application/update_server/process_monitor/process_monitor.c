#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "sdk/sdk_public.h"
#include "data_types.h"
#include "process_monitor.h"

#define D_STAT_MAX_CNT     10
#define PROCESS_MONITOR_NUM 4
#define CMD_BUFFER_SIZE    256
#define RECV_BUFFER_SIZE   32

static const char *process_names[PROCESS_MONITOR_NUM] = {
    "web_server",
    "south_dev",
    "/bin/mount",
    "df"
};

/**
 * @brief 获取进程PID
 * @param process_name 进程名称
 * @return PID或-1（如果未找到）
 */
static int get_process_pid(const char *process_name) 
{
    char cmd[CMD_BUFFER_SIZE] = {0};
    char recv_buff[RECV_BUFFER_SIZE] = {0};
    int pid = 0;
    FILE *fp;

    snprintf(cmd, sizeof(cmd), "ps aux | grep %s | grep -v grep | awk '{print $1}'", process_name);
    fp = popen(cmd, "r");
    if (!fp) 
    {
        PROCESS_MONITOR_DEBUG_PRINT("Failed to execute command");
        return -1;
    }

    if (fread(recv_buff, 1, sizeof(recv_buff) - 1, fp) <= 0) 
    {
        PROCESS_MONITOR_DEBUG_PRINT("Failed to read from pipe");
        pclose(fp);
        return -1;
    }

    recv_buff[RECV_BUFFER_SIZE - 1] = '\0'; 
    pid = atoi(recv_buff);
    pclose(fp);

    PROCESS_MONITOR_DEBUG_PRINT("process:%s  pid:%d", process_name, pid);

    return pid;
}

/**
 * @brief 获取进程运行状态
 * @param pid 进程ID
 * @return 0:正常  1:异常状态（D）
 */
static uint8_t get_process_stat(int pid) 
{
    char cmd[CMD_BUFFER_SIZE] = {0};
    char recv_buff[RECV_BUFFER_SIZE] = {0};
    FILE *fp;

    snprintf(cmd, sizeof(cmd), "cat /proc/%d/stat | awk '{print $3}'", pid);
    fp = popen(cmd, "r");
    if (!fp) 
    {
        PROCESS_MONITOR_DEBUG_PRINT("Failed to execute command");
        return 0; 
    }

    if (fread(recv_buff, 1, sizeof(recv_buff) - 1, fp) <= 0) 
    {
        PROCESS_MONITOR_DEBUG_PRINT("Failed to read from pipe");
        pclose(fp);
        return 0;
    }

    recv_buff[RECV_BUFFER_SIZE - 1] = '\0'; 
    pclose(fp);

    if (!strncmp(recv_buff, "D", strlen("D"))) 
    {
        PROCESS_MONITOR_DEBUG_PRINT("stat:D");
        return 1;
    }
    else if (!strncmp(recv_buff, "Z", strlen("Z"))) 
    {
        PROCESS_MONITOR_DEBUG_PRINT("stat:Z");
        return 1;
    }
    else if (!strncmp(recv_buff, "S", strlen("S"))) 
    {
        PROCESS_MONITOR_DEBUG_PRINT("stat:S");
        return 0;
    }
    return 0;
}


/**
 * @brief 输入重启日志到文件
 */
static void d_stat_info_save(void) 
{
    int ret = -1;
    FILE *file = NULL;
    char str[1024] = {0};
	sdk_rtc_t rtc_time = {0};
    char date_time[32] = {0};
		
	ret = sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
	if (ret != 0)
    {
		return;
    }
	snprintf(date_time, 32, "%04d-%02d-%02d %02d:%02d:%02d", 2000 + rtc_time.tm_year,rtc_time.tm_mon, rtc_time.tm_day, rtc_time.tm_hour, rtc_time.tm_min, rtc_time.tm_sec);

    sprintf(str, "%s  %s\n", date_time, "d-reboot");

    file = fopen("/opt/d_reboot.txt", "a");
    if (file == NULL) 
    {
        return;
    }

    fgets(str, sizeof(str), stdin);

    fputs(str, file); 

    fclose(file);

    return;
}


/**
 * @brief 强制系统重启
 */
static void sys_reboot(void) 
{
    system("echo 1 > /proc/sys/kernel/sysrq");
    system("echo b > /proc/sysrq-trigger");
}

/**
 * @brief 进程运行状态监测线程
 * @param arg 参数（未使用）
 */
void *process_monitor(void *arg) 
{
    static int d_stat_cnt[PROCESS_MONITOR_NUM] = {0};
    int pid;
    uint8_t result;
    int i;

    while (1)
    {
        for (i = 0; i < PROCESS_MONITOR_NUM; i++) 
        {
            pid = get_process_pid(process_names[i]);
            if (pid == -1) 
            {
                continue;
            }
            result = get_process_stat(pid);
            if (result == 1) 
            {
                d_stat_cnt[i]++;
            }
            else
            {
                d_stat_cnt[i] = 0;
            }
    
            if (d_stat_cnt[i] > D_STAT_MAX_CNT) 
            {
                //此处记录-->opt/d_reboot.txt
                d_stat_info_save();
                PROCESS_MONITOR_DEBUG_PRINT("D/Z stat:sys reboot----");
                sys_reboot();
                d_stat_cnt[i] = 0; 
            }
        }

        sleep(10);
    }
}
