#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "update_file_analysis.h"
#include "process_monitor.h"
#include "data_shm.h"
#include "sdk_shm.h"
#include "errors.h"
#include "sofar_log.h"
#include <pthread.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    pthread_t file_analysis;
	pthread_attr_t attr;

	log_init((int8_t *)PATH_CONF);
    log_set_level(LOG_LVL_DEBUG);
	// 映射共享内存
	common_data_t *tep = sdk_shm_init();
	if (!tep)
	{
		UPDATE_DEBUG_PRINT((int8_t *)" pcs_sdk_shm_init fail\n ");
		return -1;
	}

	// 升级文件包解析
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);

	if(pthread_create(&file_analysis,&attr,update_file_analysis,NULL) != 0)
	{
		perror("pthread_create update_file_analysis");
	}

	// 监测进程运行状态
	pthread_t process_monitor_attr;
	pthread_create(&process_monitor_attr, NULL, &process_monitor, NULL);

	pthread_attr_destroy(&attr);

	while(1)
	{
		sleep(1);
	}

	log_finish();

	return 0;
}