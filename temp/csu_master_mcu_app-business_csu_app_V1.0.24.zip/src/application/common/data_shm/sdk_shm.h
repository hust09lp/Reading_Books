
#ifndef __SDK_SHM_H__
#define __SDK_SHM_H__


#include "data_shm.h"
#include "data_types.h"


/**
 * @brief    共享内存初始化 （main函数初始化时调用它，收到-1 则终止）
 * @param    void    
 * @return   失败NULL,成功为指向的内容
 */
common_data_t *sdk_shm_init(void);

/**
 * @brief  	共享内存初始化
 * @param  	[in] void
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t common_data_init(void);


/**
 * @brief    获取shm指针的地址
 * @param
 * @return
 */
common_data_t **sdk_shm_addr_get(void);


/**
 * @brief    获取shm指向的内容
 * @param        
 * @return    
 */
common_data_t *sdk_shm_get(void);


/**
 * @brief    获取共享内存里 遥信数据 的基地址
 * @param
 * @return
 */
telematic_data_t *sdk_shm_telematic_data_get(void);

/**
 * @brief    获取共享内存里 遥测数据 的基地址
 * @param
 * @return
 */
telemetry_data_t *sdk_shm_telemetry_data_get(void);

/**
 * @brief    获取共享内存里 定值/参数数据 的基地址
 * @param
 * @return
 */
constant_parameter_data_t *sdk_shm_constant_parameter_data_get(void);

/**
 * @brief    获取共享内存里 其他参数 的基地址
 * @param
 * @return
 */
other_parameter_data_t *sdk_shm_other_parameter_data_get(void);

/**
 * @brief    获取共享内存里 内部共用参数 的基地址
 * @param
 * @return
 */
internal_shared_data_t *sdk_shm_internal_shared_data_get(void);

/**
 * @brief    获取共享内存里 升级参数 的基地址
 * @param
 * @return
 */
firmware_update_t *sdk_shm_update_data_get(void);


/**
 * @brief    获取web控制数据 的基地址
 * @param
 * @return
 */
web_control_info_t *sdk_shm_web_control_data_get(void);


/**
 * @brief    获取共享内存里 内部版本信息 的基地址
 * @param
 * @return
 */
internal_version_info_t *sdk_shm_internal_version_info_get(void);


/**
 * @brief    获取共享内存里 电池充放电信息 的基地址
 * @param
 * @return
 */
bat_charge_data_t *sdk_shm_bat_charge_data_info_get(void);

/**
 * @brief    获取共享内存里 EMS信息 的基地址
 * @param
 * @return
 */
ems_data_t *sdk_shm_ems_data_info_get(void);


/**
 * @brief    获取共享内存里 箱变信息 的基地址
 * @param
 * @return
 */
box_transformer_info_t *sdk_shm_box_transformer_data_info_get(void);


/**
 * @brief    获取共享内存里 汇流柜数据 的基地址
 * @param
 * @return
 */
combiner_cabinet_data_t *sdk_shm_combiner_cabinet_data_get(void);

/**
 * @brief    获取共享内存里 储能柜 的基地址
 * @param
 * @return
 */
energy_cabinet_data_t *sdk_shm_energy_cabinet_data_get(void);

/**
 * @brief    获取共享内存里 内部共用参数 的基地址
 * @param
 * @return
 */
internal_shared_data_t *internal_shared_data_get(void);

#endif


