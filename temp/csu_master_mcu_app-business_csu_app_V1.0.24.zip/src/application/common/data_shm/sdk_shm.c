#include <stdio.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include "sdk_shm.h"
#include "component/sofar_log.h"


//定义common_data_t类型的全局变量
static common_data_t *shm = NULL;


static common_data_t *shmdata()
{
    int32_t shmid;
	key_t shmkey = ftok("/",'a');
	if(shmkey == -1)
	{
		printf("[%s:%s:%d] %s\n", __FILE__,__func__, __LINE__, strerror(errno));
		return NULL;
	}

    // 创建共享内存
	shmid = shmget(shmkey,sizeof(common_data_t),0666|IPC_CREAT);
	if(shmid == -1)
	{
        // 获取共享内存ID
        shmid = shmget(shmkey,0,0);
        if(shmid == -1)
        {
            printf("[%s:%s:%d] %s\n", __FILE__,__func__, __LINE__, strerror(errno));
            return NULL;
        }
	}
	
    //获取共享内存
	common_data_t * shmaddr = (common_data_t*)shmat(shmid,0,0);
	if(shmaddr==(common_data_t*)-1)
	{
		printf("[%s:%s:%d] %s\n", __FILE__,__func__, __LINE__, strerror(errno));
		return NULL;
	}
       
	return shmaddr;
}


/**
 * @brief    共享内存初始化 （main函数初始化时调用它，收到-1 则终止）
 * @param    void    
 * @return   失败NULL,成功为指向的内容
 */
common_data_t *sdk_shm_init(void)    
{
    shm = shmdata();
    if(!(shm))
    {
        printf("[%s:%s:%d] read create shmdata failed\n", __FILE__,__func__, __LINE__);
        return NULL;
    }

    return shm;
}


/**
 * @brief  	共享内存初始化
 * @param  	[in] void
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
int32_t common_data_init(void)
{
    int32_t ret = 0;
    common_data_t *shm = NULL;

    shm = sdk_shm_init();
    if (shm == NULL)
    {
        log_i((int8_t *)"\n error, shm is NULL. \n");
        ret = -1;
    }
    return ret;
}

/**
 * @brief    获取shm指针的地址
 * @param
 * @return
 */
common_data_t **sdk_shm_addr_get(void)
{
    return &shm;
}

/**
 * @brief    获取shm指向的内容
 * @param        
 * @return    
 */
common_data_t *sdk_shm_get(void)
{
    return shm;
}

/**
 * @brief    获取共享内存里 遥信数据 的基地址
 * @param
 * @return
 */
telematic_data_t *sdk_shm_telematic_data_get(void)
{
    return(&(shm->telematic_data));
}

/**
 * @brief    获取共享内存里 遥测数据 的基地址
 * @param
 * @return
 */
telemetry_data_t *sdk_shm_telemetry_data_get(void)
{
    return(&(shm->telemetry_data));
}

/**
 * @brief    获取共享内存里 定值/参数数据 的基地址
 * @param
 * @return
 */
constant_parameter_data_t *sdk_shm_constant_parameter_data_get(void)
{
    return(&(shm->constant_parameter_data));
}

/**
 * @brief    获取共享内存里 其他参数 的基地址
 * @param
 * @return
 */
other_parameter_data_t *sdk_shm_other_parameter_data_get(void)
{
    return(&(shm->other_parameter_data));
}

/**
 * @brief    获取共享内存里 内部共用参数 的基地址
 * @param
 * @return
 */
internal_shared_data_t *sdk_shm_internal_shared_data_get(void)
{
	return(&(shm->internal_shared_data));
}

/**
 * @brief    获取共享内存里 升级参数 的基地址
 * @param
 * @return
 */
firmware_update_t *sdk_shm_update_data_get(void)
{
	return(&(shm->update));
}


/**
 * @brief    获取web控制数据 的基地址
 * @param
 * @return
 */
web_control_info_t *sdk_shm_web_control_data_get(void)
{
    return(&(shm->web_control_info));
}


/**
 * @brief    获取共享内存里 内部版本信息 的基地址
 * @param
 * @return
 */
internal_version_info_t *sdk_shm_internal_version_info_get(void)
{  
	return(&(shm->internal_version_info));
}


/**
 * @brief    获取共享内存里 电池充放电信息 的基地址
 * @param
 * @return
 */
bat_charge_data_t *sdk_shm_bat_charge_data_info_get(void)
{
    return(&(shm->bat_charge_data[0]));
}

/**
 * @brief    获取共享内存里 EMS信息 的基地址
 * @param
 * @return
 */
ems_data_t *sdk_shm_ems_data_info_get(void)
{
    return(&(shm->constant_parameter_data.ems_data));
}


/**
 * @brief    获取共享内存里 箱变信息 的基地址
 * @param
 * @return
 */
box_transformer_info_t *sdk_shm_box_transformer_data_info_get(void)
{
    return(&(shm->box_transformer_data));
}


/**
 * @brief    获取共享内存里 汇流柜数据 的基地址
 * @param
 * @return
 */
combiner_cabinet_data_t *sdk_shm_combiner_cabinet_data_get(void)
{
    return(&(shm->combiner_cabinet_data));
}


/**
 * @brief    获取共享内存里 储能柜 的基地址
 * @param
 * @return
 */
energy_cabinet_data_t *sdk_shm_energy_cabinet_data_get(void)
{
    return(&(shm->energy_cabinet_data));
}

/**
 * @brief    获取共享内存里 内部共用参数 的基地址
 * @param
 * @return
 */
internal_shared_data_t *internal_shared_data_get(void)
{
	return(&(shm->internal_shared_data));
}
