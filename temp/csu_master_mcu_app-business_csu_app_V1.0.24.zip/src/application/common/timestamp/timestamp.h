#ifndef __TIMESTAMP_H__
#define __TIMESTAMP_H__

#include <unistd.h>
#include "sdk_public.h"


/**
 * @brief  	将sdk_rtc_t结构体时间转换成时间戳（秒）
 * @param  	[in] p_date         sdk_rtc_t结构体时间
 * @return 	[long long] 执行结果
 * @retval  64位时间戳
 */
long long transform_to_timestamp(sdk_rtc_t *p_date);


/**
 * @brief  	将时间戳（秒）转换成sdk_rtc_t结构体时间
 * @param  	[in] p_timestamp    时间戳（秒）
 * @param  	[out] p_time        sdk_rtc_t结构体时间
 * @return 	无
 */
void timestamp_to_date_time(long long timestamp, sdk_rtc_t *p_date);

#endif
