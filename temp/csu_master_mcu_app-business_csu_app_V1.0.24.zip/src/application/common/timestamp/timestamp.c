#include <unistd.h>
#include <time.h>
#include "sdk_public.h"
#include "sdk_shm.h"


#define SECONDS_IN_A_DAY    86400
#define SECONDS_IN_HOUR     3600
#define SECONDS_IN_MINUTE   60

// static int mon_table[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

/**
 * @brief  	判断是否为闰年
 * @param  	[in] year：年
 * @return 	1：闰年 0：平年
 */
int is_leap_year(int year) 
{
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}

/**
 * @brief  	根据年份获取2月份天数
 * @param  	[in] year：年
 * @return 	2月份天数
 */
int days_in_february(int year) 
{
    return is_leap_year(year) ? 29 : 28;
}

/**
 * @brief  	获取给定月天数
 * @param  	[in] year：年
 * @return 	月份天数
 */
int days_in_month(int year, int month) 
{
    int mon_table[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    if (month == 2) 
    {
        return days_in_february(year);
    }
    return mon_table[month - 1];
}


/**
 * @brief  	计算从1970年1月1日到给定日期的总天数
 * @param  	[in] year：年
 * @param  	[in] month：月
 * @param  	[in] day：日
 * @return 	天数
 */
int days_from_1970(int year, int month, int day) 
{
    int days = 0;

    for (int y = 1970; y < year; y++) 
    {
        days += is_leap_year(y) ? 366 : 365;
    }
    for (int m = 1; m < month; m++) 
    {
        days += days_in_month(year, m);
    }
    days += day - 1;                                // 减1是因为月份的天数是从1开始计算的
    return days;
}

/**
 * @brief  	将时间戳（秒）转换成sdk_rtc_t结构体时间
 * @param  	[in] p_timestamp    时间戳（秒）
 * @param  	[out] p_time        sdk_rtc_t结构体时间
 * @return 	无
 */
void timestamp_to_date_time(long long timestamp, sdk_rtc_t *p_date) 
{
    int days = 0, hours = 0, minutes = 0, seconds = 0;

    days = timestamp / SECONDS_IN_A_DAY;                // 总天数
    seconds = timestamp % SECONDS_IN_A_DAY;             // 最后一天的秒数
    hours = seconds / SECONDS_IN_HOUR;                  // 小时
    seconds %= SECONDS_IN_HOUR;
    minutes = seconds / SECONDS_IN_MINUTE;              // 分钟
    seconds %= SECONDS_IN_MINUTE;                       //秒

    int year = 1970, month = 1, day = 1;
    int total_days = days_from_1970(year, month, day) + days;

    while (total_days >= days_in_month(year, month)) 
    {
        total_days -= days_in_month(year, month);
        month++;
        if (month > 12) 
        {
            month = 1;
            year++;
        }
    }
    day = total_days + 1;                               // 加1是因为天数是从1开始计算的

    p_date->tm_year = year - 2000;
    p_date->tm_mon = month;
    p_date->tm_day = day;
    p_date->tm_hour = hours;
    p_date->tm_min = minutes;
    p_date->tm_sec = seconds;

}


/**
 * @brief  	将sdk_rtc_t结构体时间转换成时间戳（秒）
 * @param  	[in] p_date         sdk_rtc_t结构体时间
 * @return 	[long long] 执行结果
 * @retval  64位时间戳
 */
long long transform_to_timestamp(sdk_rtc_t *p_date)
{
	uint32_t day = 0, hour = 0, minute = 0;
    uint32_t year = 0;
	long long second = 0;
	int32_t i = 0;
    int mon_table[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	
    year = p_date->tm_year + 2000;
	for(i = 1970; i < year; i++)                                                    /* 从1970年到设定年份有多少闰年平年 */
	{
		if(((i % 4 == 0) && (i % 100 != 0)) || (i % 400 == 0))
		{
			day += 366;
		}
		else
		{
			day += 365;
		}
	}

	if(((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0))                 /* 判断设定年份是不是闰年 */
	{
		mon_table[1]++;
	}

	for(i = 0; i < p_date->tm_mon - 1; i++)
	{
	  day += mon_table[i];
	}

	day += p_date->tm_day - 1;

	hour = day * 24 + p_date->tm_hour;
	minute = hour * SECONDS_IN_MINUTE + p_date->tm_min;
	second = minute * SECONDS_IN_MINUTE + p_date->tm_sec;

	return second;
}






