#include "csu_cfg_store.h"
#include "sdk_fs.h"
#include "cJSON.h"
#include "sdk_shm.h"

#include <string.h>
#include <stdlib.h>

#define PATH_CSU_COMB_CFG               "/user/conf/csu_comb_cfg.json"
#define PATH_CSU_COMB_SLAVE_INFO        "/user/conf/csu_comb_slave.json"
#define PATH_CSU_COMB_MASTER_INFO       "/user/conf/csu_comb_master.json"

#if (1)
    #define CSU_CFG_STORE_LOG_D(...) do{ printf(__VA_ARGS__);printf("\r\n"); }while(0)
#else
    #define CSU_CFG_STORE_LOG_D(...) do{}while(0)
#endif
#define CSU_CFG_STORE_LOG_E(...) do{ printf("[ERROR]");printf(__VA_ARGS__);printf("\r\n"); }while(0)

/**
 *  csu_comb_cfg.json 格式如下
 *  { "role": "master/slave", "eth1Ip": "192.168.2.23", "masterIp":"192.168.2.22", "csuCombNum": 8 } 
 */
sf_ret_t csu_cfg_comb_cfg_save( csu_comb_save_setting_t *p_csu_comb_setting )
{
    sf_ret_t ret = SF_OK;
    char ip_str[20] = {0};
    cJSON *p_root_js = NULL;
    char *p_cfg_str = NULL;
    fs_t *p_fs = NULL;

    CSU_CFG_STORE_LOG_D("%s", __FUNCTION__);

    p_root_js = cJSON_CreateObject();
    if ( p_root_js == NULL )
    {
        ret = SF_ERR_NO_OBJECT;
        goto __exit;
    }
    
    cJSON_AddBoolToObject( p_root_js  , "enable"     , p_csu_comb_setting->comb_enable);
    cJSON_AddStringToObject( p_root_js, "role"       , ( p_csu_comb_setting->comb_role == CSU_ROLE_MASTER )? "master"   :
                                                       ( p_csu_comb_setting->comb_role == CSU_ROLE_SLAVE  )? "slave"    : "unknow" );
    cJSON_AddNumberToObject( p_root_js, "slaveId" , p_csu_comb_setting->slave.local_slave_id );
    sprintf( ip_str, "%d.%d.%d.%d", p_csu_comb_setting->slave.con_master_ip[0], p_csu_comb_setting->slave.con_master_ip[1], p_csu_comb_setting->slave.con_master_ip[2], p_csu_comb_setting->slave.con_master_ip[3] );
    cJSON_AddStringToObject( p_root_js, "masterIp"    , ip_str );
    cJSON_AddNumberToObject( p_root_js, "csuCombNum"  , p_csu_comb_setting->master.comb_num );
    cJSON_AddNumberToObject( p_root_js, "junctEnable" , p_csu_comb_setting->junct.enable );
    sprintf( ip_str, "%d.%d.%d.%d", p_csu_comb_setting->junct.con_master_ip[0], p_csu_comb_setting->junct.con_master_ip[1]
                                  , p_csu_comb_setting->junct.con_master_ip[2], p_csu_comb_setting->junct.con_master_ip[3]);
    cJSON_AddStringToObject( p_root_js, "junctMasterIp" , ip_str );

    p_cfg_str = cJSON_PrintUnformatted( p_root_js );
    if ( p_cfg_str == NULL )
    {
        ret = SF_ERR_PARA;
        goto __exit;
    }

    p_fs = sdk_fs_open((const int8_t *)PATH_CSU_COMB_CFG, FS_CREATE_ALWAYS | FS_WRITE);
    if (p_fs == NULL)
    {
        ret = SF_ERR_OPEN;
        goto __exit;
    }

    /* 将位置偏移量移动到文件头 */
    ret = sdk_fs_lseek( p_fs, 0 );
    if (ret < 0)
    {
        ret = SF_ERR_SEEK;
        goto __exit;
    }

    ret = sdk_fs_write(p_fs, p_cfg_str, strlen( p_cfg_str ) );
    if ( ret != strlen( p_cfg_str ) )
    {
        ret = SF_ERR_WR;
        goto __exit;
    }
    ret = SF_OK;

__exit:
    if ( p_root_js != NULL )
    {
        cJSON_Delete( p_root_js );
    }
    if ( p_cfg_str != NULL )
    {
        free( p_cfg_str );
    }
    if ( p_fs != NULL )
    {
        sdk_fs_close( p_fs );
    }
    if ( ret < SF_OK )
    {
        CSU_CFG_STORE_LOG_E( "%s error, ret:%d!!!", __FUNCTION__, ret );
    }
    return ret;
}

sf_ret_t csu_cfg_comb_cfg_restore( csu_comb_save_setting_t *p_csu_comb_setting )
{
    char cfg_str[200] = {0};
    sf_ret_t ret = SF_OK;
    cJSON *p_root_js = NULL;
    fs_t *p_fs = NULL;

    CSU_CFG_STORE_LOG_D("%s", __FUNCTION__);

    p_fs = sdk_fs_open((const int8_t *)PATH_CSU_COMB_CFG, FS_READ);
    if (p_fs == NULL)
    {
        ret = SF_ERR_OPEN;
        goto __exit;
    }

    /* 将位置偏移量移动到文件头 */
    ret = sdk_fs_lseek( p_fs, 0 );
    if (ret < 0)
    {
        ret = SF_ERR_SEEK;
        goto __exit;
    }

    ret = sdk_fs_read( p_fs, cfg_str, sizeof( cfg_str ) );
    if ( ret <= 0 )
    {
        ret = SF_ERR_RD;
        goto __exit;
    }

    p_root_js =  cJSON_Parse( cfg_str );
    if ( p_root_js == NULL )
    {
        ret = SF_ERR_PARA;
        goto __exit;
    }

    cJSON *p_enable_js     = cJSON_GetObjectItem( p_root_js, "enable" );
    cJSON *p_role_js       = cJSON_GetObjectItem( p_root_js, "role" );
    // cJSON *p_eth1Ip_js     = cJSON_GetObjectItem( p_root_js, "eth1Ip" );
    cJSON *p_masterIp_js    = cJSON_GetObjectItem( p_root_js, "masterIp" );
    cJSON *p_csuCombNum_js  = cJSON_GetObjectItem( p_root_js, "csuCombNum" );
    cJSON *p_slaveId_js     = cJSON_GetObjectItem( p_root_js, "slaveId" );
    cJSON *p_junctEnable_js = cJSON_GetObjectItem( p_root_js, "junctEnable" );
    cJSON *p_junctMasterIp_js = cJSON_GetObjectItem( p_root_js, "junctMasterIp" );

    if(    ( p_role_js == NULL )
        || ( p_enable_js == NULL )
        || ( p_masterIp_js == NULL )
        || ( p_csuCombNum_js == NULL ))
    {
        ret = SF_ERR_PARA;
        goto __exit;
    }

    if ( strcmp( p_role_js->valuestring, "master" ) == 0 )
    {
        p_csu_comb_setting->comb_role = CSU_ROLE_MASTER;
    } else if ( strcmp( p_role_js->valuestring, "slave" ) == 0 )
    {
        p_csu_comb_setting->comb_role = CSU_ROLE_SLAVE;
    }
    int32_t ip[4];

    p_csu_comb_setting->comb_enable = p_enable_js->valueint;
    sscanf( p_masterIp_js->valuestring , "%d.%d.%d.%d", &ip[0], &ip[1], &ip[2], &ip[3] );
    p_csu_comb_setting->slave.con_master_ip[0] = ip[0];
    p_csu_comb_setting->slave.con_master_ip[1] = ip[1];
    p_csu_comb_setting->slave.con_master_ip[2] = ip[2];
    p_csu_comb_setting->slave.con_master_ip[3] = ip[3];
    p_csu_comb_setting->master.comb_num = p_csuCombNum_js->valueint;
    if ( p_junctEnable_js != NULL )
    {
        p_csu_comb_setting->junct.enable = p_junctEnable_js->valueint; 
        CSU_CFG_STORE_LOG_D( "junctEnable:%d", p_junctEnable_js->valueint );
    }   
    if ( p_junctMasterIp_js != NULL )
    {
        sscanf( p_junctMasterIp_js->valuestring , "%d.%d.%d.%d", &ip[0], &ip[1], &ip[2], &ip[3] );
        p_csu_comb_setting->junct.con_master_ip[0] = ip[0];
        p_csu_comb_setting->junct.con_master_ip[1] = ip[1];
        p_csu_comb_setting->junct.con_master_ip[2] = ip[2];
        p_csu_comb_setting->junct.con_master_ip[3] = ip[3];
        CSU_CFG_STORE_LOG_D( "junctMasterIp:%d.%d.%d.%d", p_csu_comb_setting->junct.con_master_ip[0], p_csu_comb_setting->junct.con_master_ip[1]
                                                        , p_csu_comb_setting->junct.con_master_ip[2], p_csu_comb_setting->junct.con_master_ip[3]);
    }   
    if ( p_slaveId_js != NULL )
    {
        p_csu_comb_setting->slave.local_slave_id = p_slaveId_js->valueint; 
        CSU_CFG_STORE_LOG_D( "slaveId:%d", p_slaveId_js->valueint );
    }

    ret = SF_OK;

    CSU_CFG_STORE_LOG_D( "restore role:%s, master ip:%s, comb num:%d", 
                p_role_js->valuestring, p_masterIp_js->valuestring, p_csuCombNum_js->valueint );

__exit:
    if ( p_fs != NULL )
    {
        sdk_fs_close( p_fs );
    }
    if ( p_root_js != NULL )
    {
        cJSON_Delete( p_root_js );
    }

    if ( ret < SF_OK )
    {
        CSU_CFG_STORE_LOG_E( "%s error, set defalut!!!, ret:%d", __FUNCTION__, ret );
        // *p_role = CSU_ROLE_MASTER;
        // *p_csu_comb_num = 1;
    }
    return ret;
}


/**
 *  "{ "CombPowerSta": "off"  }"
 **/

sf_ret_t csu_cfg_master_info_save( csu_master_save_t *p_csu_master_save )
{
    cJSON *p_root_js = NULL;
    char *p_master_save_str = NULL;
    sf_ret_t ret = SF_OK;
    fs_t *p_fs = NULL;

    CSU_CFG_STORE_LOG_D("%s", __FUNCTION__);

    p_root_js = cJSON_CreateObject();
    if ( p_root_js == NULL )
    {
        ret = SF_ERR_NO_OBJECT;
        goto __exit;
    }

    cJSON_AddStringToObject( p_root_js, "CombPowerSta", (p_csu_master_save->power_on == SF_TRUE)? "on": "off" );

    p_master_save_str = cJSON_PrintUnformatted( p_root_js );
    if ( p_master_save_str == NULL )
    {
        ret = SF_ERR_PARA;
        goto __exit;
    }

    p_fs = sdk_fs_open((const int8_t *)PATH_CSU_COMB_MASTER_INFO, FS_CREATE_ALWAYS | FS_WRITE);
    if (p_fs == NULL)
    {
        ret = SF_ERR_OPEN;
        goto __exit;
    }

    /* 将位置偏移量移动到文件头 */
    ret = sdk_fs_lseek( p_fs, 0 );
    if (ret < 0)
    {
        ret = SF_ERR_SEEK;
        goto __exit;
    }

    ret = sdk_fs_write(p_fs, p_master_save_str, strlen( p_master_save_str ) );
    if ( ret != strlen( p_master_save_str ) )
    {
        ret = SF_ERR_WR;
        goto __exit;
    }
    ret = SF_OK;

__exit:
    if ( p_root_js )
    {
        cJSON_Delete( p_root_js );
    }
    if ( p_master_save_str )
    {
        free( p_master_save_str );
    }
    if ( p_fs )
    {
        sdk_fs_close( p_fs );
    }
    if ( ret < SF_OK )
    {
        CSU_CFG_STORE_LOG_E( "%s error, ret:%d!!!", __FUNCTION__, ret );
    }

    return ret;
}

sf_ret_t csu_cfg_master_info_restore( csu_master_save_t *p_csu_master_save )
{
    char master_save_str[500] = {0};
    sf_ret_t ret = SF_OK;
    cJSON *p_root_js = NULL;
    fs_t *p_fs = NULL;

    CSU_CFG_STORE_LOG_D("%s", __FUNCTION__);
    p_fs = sdk_fs_open((const int8_t *)PATH_CSU_COMB_MASTER_INFO, FS_READ);
    if (p_fs == NULL)
    {
        ret = SF_ERR_OPEN;
        goto __exit;
    }

    /* 将位置偏移量移动到文件头 */
    ret = sdk_fs_lseek( p_fs, 0 );
    if (ret < 0)
    {
        ret = SF_ERR_SEEK;
        goto __exit;
    }

    ret = sdk_fs_read( p_fs, master_save_str, sizeof( master_save_str ) );
    if ( ret <= 0 )
    {
        ret = SF_ERR_RD;
        goto __exit;
    }

    p_root_js = cJSON_Parse( master_save_str );
    if ( p_root_js == NULL )
    {
        ret = SF_ERR_PARA;
        goto __exit;
    }

    cJSON *p_CombPowerSta_js = cJSON_GetObjectItem( p_root_js, "CombPowerSta" );
    if ( p_CombPowerSta_js == NULL )
    {
        ret = SF_ERR_NO_OBJECT;
        goto __exit;
    }

    p_csu_master_save->power_on = ( 0 == strcmp( p_CombPowerSta_js->valuestring, "on" ) )? SF_TRUE : SF_FALSE;
        
    ret = SF_OK;

__exit:
    if ( p_fs )
    {
        sdk_fs_close( p_fs );
    }
    if ( p_root_js )
    {
        cJSON_Delete( p_root_js );
    }
    if ( ret < SF_OK )
    {
        CSU_CFG_STORE_LOG_E( "%s error, ret:%d!!!", __FUNCTION__, ret );
        p_csu_master_save->power_on = SF_FALSE;
    }

    return ret;
}


void csu_comb_save_setting_to_csu_comb_setting( const csu_comb_save_setting_t *p_csu_comb_save_setting, csu_comb_setting_t *p_csu_comb_setting )
{
    if ( sdk_shm_get()->constant_parameter_data.cabinet_param_data.scenario_setting == 3 )
    {
        /* 单汇流柜场景下，其他并柜设置无效 */
        if (   p_csu_comb_save_setting->junct.con_master_ip[0] != 0
            || p_csu_comb_save_setting->junct.con_master_ip[1] != 0
            || p_csu_comb_save_setting->junct.con_master_ip[2] != 0
            || p_csu_comb_save_setting->junct.con_master_ip[3] != 0 )
        {
            p_csu_comb_setting->comb_enable = SF_TRUE;
            p_csu_comb_setting->comb_role   = CSU_ROLE_JUNCT;
            memcpy( p_csu_comb_setting->slave.con_master_ip, p_csu_comb_save_setting->junct.con_master_ip, sizeof( p_csu_comb_setting->slave.con_master_ip ));
        }
        return;
    }

    p_csu_comb_setting->comb_enable  = p_csu_comb_save_setting->comb_enable;
    p_csu_comb_setting->comb_role    = p_csu_comb_save_setting->comb_role;
    p_csu_comb_setting->junct_enable = p_csu_comb_save_setting->junct.enable;
    
    p_csu_comb_setting->master.comb_num        = p_csu_comb_save_setting->master.comb_num;
    p_csu_comb_setting->slave.local_slave_id   = p_csu_comb_save_setting->slave.local_slave_id;
    memcpy( p_csu_comb_setting->slave.con_master_ip, p_csu_comb_save_setting->slave.con_master_ip, sizeof( p_csu_comb_save_setting->slave.con_master_ip ) );

    return;
}