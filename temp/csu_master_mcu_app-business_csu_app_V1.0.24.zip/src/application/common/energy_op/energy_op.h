#ifndef _ENERGY_OP_H_
#define _ENERGY_OP_H_

#include "sofar_type.h"

enum{
    METER = 0,                                          // 计量表                            
    PCC_METER,                                          // PCC电表
    PV_METER,                                           // PV电表
    LOAD                                                // 负载
};

typedef struct
{
    uint8_t date[32];
    double charge[32];                 
    double discharge[32];
}data_energy_t;

/**
 * @brief    按照日期获取电量数据
 * @param	 [in] *p_ymd:日期 
 * @param	 [out] *p_energy_data：电量数据
 * @param	 [in] *p_path：路径
 * @param	 [in] type：类型
 * @return
 */ 
int32_t select_sqlite_db_day(char *p_ymd, data_energy_t *p_energy_data, char *p_path, uint8_t type);

/**
 * @brief    按照月份获取电量数据
 * @param	 [in] *p_ymd:日期 
 * @param	 [out] *p_energy_data：电量数据
 * @param	 [in] *p_path：路径
 * @param	 [in] type：类型
 * @return
 */ 
int32_t select_sqlite_db_mon(char *p_ymd, data_energy_t *p_energy_data, char *p_path, uint8_t type);
 
/**
 * @brief    按照年份获取电量数据
 * @param	 [in] *p_ymd:日期 
 * @param	 [out] *p_energy_data：电量数据
 * @param	 [in] *p_path：路径
 * @param	 [in] type：类型
 * @return
 */ 
int32_t select_sqlite_db_year(char *p_ymd, data_energy_t *p_energy_data, char *p_path, uint8_t type);

/**
 * @brief    获取总电量数据
 * @param	 [in] *p_ymd:日期 
 * @param	 [out] *p_energy_data：电量数据
 * @param	 [in] *p_path：路径
 * @param	 [in] type：类型
 * @param	 [in] *p_num：数量
 * @return
 */ 
int32_t select_sqlite_db_total(char *p_ymd, double *p_charge, double *p_discharge, char *p_path, uint8_t type);


#endif
