#include "energy_op.h"
#include "sqlite3.h"
#include "sdk_log.h"

#include <string.h>
#include <stdlib.h>

#if (1)
#define ENERGY_OP_DEBUG_PRINT(...) do{log_i(__VA_ARGS__);}while(0);
#else
#define ENERGY_OP_DEBUG_PRINT(...) {do {} while(0);}
#endif

/**
 * @brief    按照日期获取电量数据
 * @param	 [in] *p_ymd:日期 
 * @param	 [out] *p_energy_data：电量数据
 * @param	 [in] *p_path：路径
 * @param	 [in] type：类型
 * @return
 */ 
int32_t select_sqlite_db_day(char *p_ymd, data_energy_t *p_energy_data, char *p_path, uint8_t type)
{
    sqlite3 *db = NULL;
    sqlite3_stmt *stmt = NULL;
    char sql[256] = {0};
    int32_t hour = 0;
    int rc = 0;
    
    memset(p_energy_data, 0, sizeof(data_energy_t));
   
    rc = sqlite3_open(p_path, &db);
    if(rc) 
    {
       ENERGY_OP_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
       return 0;
    } 
    else 
    {
        if(type == METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%H', date), charge, discharge FROM charge_data WHERE date LIKE '%s%%';", p_ymd);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
        
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                hour = atoi(sqlite3_column_text(stmt, 0));
                if (hour > 23)
                {
                    ENERGY_OP_DEBUG_PRINT((int8_t *)"break \n");
                    break;
                }
                p_energy_data->charge[hour] = sqlite3_column_double(stmt, 1) / 100.00;
                p_energy_data->discharge[hour] = sqlite3_column_double(stmt, 2) / 100.00;
            }
            sqlite3_finalize(stmt);
        }
        if(type == PCC_METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%H', date), int, out FROM pcc_energy WHERE date LIKE '%s%%';", p_ymd);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
        
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                hour = atoi(sqlite3_column_text(stmt, 0));
                if (hour > 23)
                {
                    ENERGY_OP_DEBUG_PRINT((int8_t *)"break \n");
                    break;
                }
                p_energy_data->charge[hour] = sqlite3_column_double(stmt, 1) / 100.00;
                p_energy_data->discharge[hour] = sqlite3_column_double(stmt, 2) / 100.00;
            }
            sqlite3_finalize(stmt);
        }
        if(type == PV_METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%H', date), int FROM pv_energy WHERE date LIKE '%s%%';", p_ymd);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
        
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                hour = atoi(sqlite3_column_text(stmt, 0));
                if (hour > 23)
                {
                    ENERGY_OP_DEBUG_PRINT((int8_t *)"break \n");
                    break;
                }
                p_energy_data->charge[hour] = sqlite3_column_double(stmt, 1) / 100.00;
            }
            sqlite3_finalize(stmt);
        }
        if(type == LOAD)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%H', date), out FROM load_energy WHERE date LIKE '%s%%';", p_ymd);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
        
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                hour = atoi(sqlite3_column_text(stmt, 0));
                if (hour > 23)
                {
                    ENERGY_OP_DEBUG_PRINT((int8_t *)"break \n");
                    break;
                }
                p_energy_data->charge[hour] = sqlite3_column_double(stmt, 1) / 100.00;
            }
            sqlite3_finalize(stmt);
        }
    }
    
    sqlite3_close(db);    
    return 1; 
}



/**
 * @brief    按照月份获取电量数据
 * @param	 [in] *p_ymd:日期 
 * @param	 [out] *p_energy_data：电量数据
 * @param	 [in] *p_path：路径
 * @param	 [in] type：类型
 * @return
 */ 
int32_t select_sqlite_db_mon(char *p_ymd, data_energy_t *p_energy_data, char *p_path, uint8_t type)
{
    sqlite3 *db = NULL;
    sqlite3_stmt *stmt = NULL;
    char sql[256] = {0};
    int32_t day = 0;
    int rc = 0;

    memset(p_energy_data, 0, sizeof(data_energy_t));
    
    rc = sqlite3_open(p_path, &db);
    if(rc) 
    {
       ENERGY_OP_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
       return 0;
    } 
    else 
    {
        if(type == METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%d', date), SUM(charge), SUM(discharge) FROM charge_data WHERE strftime('%%Y-%%m', date) = '%s' GROUP BY strftime('%%Y-%%m-%%d', date);", p_ymd);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                day =  atoi(sqlite3_column_text(stmt, 0));
                p_energy_data->charge[day-1] = sqlite3_column_double(stmt, 1) / 100.00;
                p_energy_data->discharge[day-1] = sqlite3_column_double(stmt, 2) / 100.00;
            }
            sqlite3_finalize(stmt);
        }
        else if(type == PCC_METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%d', date), SUM(int), SUM(out) FROM pcc_energy WHERE strftime('%%Y-%%m', date) = '%s' GROUP BY strftime('%%Y-%%m-%%d', date);", p_ymd);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                day =  atoi(sqlite3_column_text(stmt, 0));
                p_energy_data->charge[day-1] = sqlite3_column_double(stmt, 1) / 100.00;
                p_energy_data->discharge[day-1] = sqlite3_column_double(stmt, 2) / 100.00;
            }
            sqlite3_finalize(stmt);
        }
        else if(type == PV_METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%d', date), SUM(int) FROM pv_energy WHERE strftime('%%Y-%%m', date) = '%s' GROUP BY strftime('%%Y-%%m-%%d', date);", p_ymd);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                day =  atoi(sqlite3_column_text(stmt, 0));
                p_energy_data->charge[day-1] = sqlite3_column_double(stmt, 1) / 100.00;
            }
            sqlite3_finalize(stmt);
        }
        else if(type == LOAD)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%d', date), SUM(out) FROM load_energy WHERE strftime('%%Y-%%m', date) = '%s' GROUP BY strftime('%%Y-%%m-%%d', date);", p_ymd);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                day =  atoi(sqlite3_column_text(stmt, 0));
                p_energy_data->charge[day-1] = sqlite3_column_double(stmt, 1) / 100.00;
            }
            sqlite3_finalize(stmt);
        }
    }
    
    sqlite3_close(db);  
    return 1;   
}
 
/**
 * @brief    按照年份获取电量数据
 * @param	 [in] *p_ymd:日期 
 * @param	 [out] *p_energy_data：电量数据
 * @param	 [in] *p_path：路径
 * @param	 [in] type：类型
 * @return
 */ 
int32_t select_sqlite_db_year(char *p_ymd, data_energy_t *p_energy_data, char *p_path, uint8_t type)
{
    sqlite3 *db = NULL;
    sqlite3_stmt *stmt = NULL;
    char sql[256] = {0};
    int32_t mon = 0;
    int rc = 0;

    memset(p_energy_data, 0, sizeof(data_energy_t));
    
    rc = sqlite3_open(p_path, &db);
    if(rc) 
    {
       ENERGY_OP_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
       return 0;
    }
    else 
    {
        if(type == METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%m', date), SUM(charge), SUM(discharge) FROM charge_data WHERE strftime('%%Y', date) = '%s' GROUP BY strftime('%%Y-%%m', date);", p_ymd);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                mon =  atoi(sqlite3_column_text(stmt, 0));
                p_energy_data->charge[mon - 1] = sqlite3_column_double(stmt, 1) / 100.00;
                p_energy_data->discharge[mon - 1] = sqlite3_column_double(stmt, 2) / 100.00;
            }
            sqlite3_finalize(stmt);
        }
        else if(type == PCC_METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%m', date), SUM(int), SUM(out) FROM pcc_energy WHERE strftime('%%Y', date) = '%s' GROUP BY strftime('%%Y-%%m', date);", p_ymd);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                mon =  atoi(sqlite3_column_text(stmt, 0));
                p_energy_data->charge[mon - 1] = sqlite3_column_double(stmt, 1) / 100.00;
                p_energy_data->discharge[mon - 1] = sqlite3_column_double(stmt, 2) / 100.00;
            }
            sqlite3_finalize(stmt);
        }
        else if(type == PV_METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%m', date), SUM(int) FROM pv_energy WHERE strftime('%%Y', date) = '%s' GROUP BY strftime('%%Y-%%m', date);", p_ymd);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                mon =  atoi(sqlite3_column_text(stmt, 0));
                p_energy_data->charge[mon - 1] = sqlite3_column_double(stmt, 1) / 100.00;
            }
            sqlite3_finalize(stmt);
        }
        else if(type == LOAD)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime('%%m', date), SUM(out) FROM load_energy WHERE strftime('%%Y', date) = '%s' GROUP BY strftime('%%Y-%%m', date);", p_ymd);
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                mon =  atoi(sqlite3_column_text(stmt, 0));
                p_energy_data->charge[mon - 1] = sqlite3_column_double(stmt, 1) / 100.00;
            }
            sqlite3_finalize(stmt);
        }
    }
    
    sqlite3_close(db);     
    return 1;
}
 

/**
 * @brief    获取总电量数据
 * @param	 [in] *p_ymd:日期 
 * @param	 [out] *p_energy_data：电量数据
 * @param	 [in] *p_path：路径
 * @param	 [in] type：类型
 * @param	 [in] *p_num：数量
 * @return
 */ 
int32_t select_sqlite_db_total(char *p_ymd, double *p_charge, double *p_discharge, char *p_path, uint8_t type)
{
    sqlite3 *db = NULL;
    sqlite3_stmt *stmt = NULL;
    char sql[256] = {0};
    int rc = 0;

    *p_charge = 0;
    *p_discharge = 0;
   
    rc = sqlite3_open(p_path, &db);
    if(rc) 
    {
       ENERGY_OP_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
       return 0;
    } 
    else 
    {
        if(type == METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime(date), SUM(charge), SUM(discharge) FROM charge_data;");
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW)
            {
                *p_charge = sqlite3_column_double(stmt, 1) / 100.00;
                *p_discharge = sqlite3_column_double(stmt, 2) / 100.00;
            }
            sqlite3_finalize(stmt);
        }
        if(type == PCC_METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime(date), SUM(int), SUM(out) FROM pcc_energy;");
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                *p_charge = sqlite3_column_double(stmt, 1) / 100.00;
                *p_discharge = sqlite3_column_double(stmt, 2) / 100.00;
            }
            sqlite3_finalize(stmt);
        }
        if(type == PV_METER)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime(date), SUM(int) FROM pv_energy;");
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                *p_charge = sqlite3_column_double(stmt, 1) / 100.00;
            }
            sqlite3_finalize(stmt);
        }
        if(type == LOAD)
        {
            snprintf(sql, sizeof(sql), "SELECT strftime(date), SUM(out) FROM load_energy;");
            sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
            while (sqlite3_step(stmt) == SQLITE_ROW) 
            {
                *p_charge = sqlite3_column_double(stmt, 1) / 100.00;
            }
            sqlite3_finalize(stmt);
        }
    }
    
    sqlite3_close(db);    
    return 1; 
}
