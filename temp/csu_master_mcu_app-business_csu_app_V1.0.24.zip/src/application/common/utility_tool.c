
#include "utility_tool.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <net/if.h>

/**
 * @brief  获取对应网卡地址
 * @param  [in]  interface_name  ：网卡名称
 * @param  [out] p_ip            ：网卡对应IP地址
 * @return 
 * @note   
 */
void utility_tool_network_get_ip( char *interface_name, uint8_t *p_ip )
{
    int fd;
    struct ifreq ifr;
    char ip[INET_ADDRSTRLEN];

    // 创建 socket
    fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd == -1) {
        perror("socket");
        return;
    }

    // 设置查询的网卡名称
    ifr.ifr_addr.sa_family = AF_INET;
    strncpy(ifr.ifr_name, interface_name, IFNAMSIZ - 1);

    // 通过 ioctl 获取网卡的 IP 地址
    if (ioctl(fd, SIOCGIFADDR, &ifr) == -1) {
        perror("ioctl");
        close(fd);
        return;
    }

    // 提取 IP 地址
    struct sockaddr_in *ipaddr = (struct sockaddr_in *)&ifr.ifr_addr;
    inet_ntop(AF_INET, &ipaddr->sin_addr, ip, sizeof(ip));

    p_ip[0] = (ipaddr->sin_addr.s_addr >>  0) & 0xFF ;
    p_ip[1] = (ipaddr->sin_addr.s_addr >>  8) & 0xFF ;
    p_ip[2] = (ipaddr->sin_addr.s_addr >> 16) & 0xFF ;
    p_ip[3] = (ipaddr->sin_addr.s_addr >> 24) & 0xFF ;

    // printf("IP address of %s: %s, 0x%08X\n", interface_name, ip, ipaddr->sin_addr);

    close(fd);
}

double double_acc_conversion( double value, uint8_t dot_num )
{
    double ret_value = 0;
    int64_t mul_num = 1;
    int64_t num;

    for ( size_t i = 0; i < dot_num; i++ )
    {
        mul_num = mul_num * 10;
    }
    
    num = value * mul_num;
    return (double)num / (double)mul_num;
}
