#include "mem_utils.h"

#include <stdio.h>

/**
 * @brief  基于位数据的拷贝函数，用于没有字节对齐的 “位操作”。
 *         操作方法类似 memcpy， 只是   memcpy 是 “字节操作”
 * @param  [in] p_dst_dat      ： 目的数据 地址
 * @param  [in] dst_bit_offset ： 目的数据 位偏移
 * @param  [in] p_src_dat      ： 源数据 地址 
 * @param  [in] src_bit_offset ： 源数据 位偏移
 * @param  [in] cp_bit_len     ： 拷贝的位长度
 * @return 无
 * @note   
 * eg:
 *     uint8_t dst_dat[10] = "*******"; 
 *     uint8_t src_dat[10] = "*******"; 
 *     memcpy_bits( dst_dat, 13, src_dat, 6, 10 );  //< 将 src_dat第7位之后的10位数据 拷贝到 dst_dat的第13位 之后的10位数据
 * 
 * src                   [0]               [1]                      [2]
 *                        0 1 2 3 4 5 6  7  8  9  10 11 12 13 14 15 16 17 18 19 *******
 *                                    |<-----------copy---------->|
 *       0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 *******
 * dst  [0]             [1]                    [2]                     [3]
 */
void memcpy_bits( uint8_t *p_dst_dat, uint16_t dst_bit_offset, uint8_t *p_src_dat, uint16_t src_bit_offset, uint16_t cp_bit_len )
{
    uint16_t tmp_cp_bit_len = cp_bit_len;
    uint16_t dst_idx = 0, dst_bit_pos = 0;
    uint16_t src_idx = 0, src_bit_pos = 0;

    for ( ; tmp_cp_bit_len > 0; tmp_cp_bit_len--)
    {
        dst_idx     = dst_bit_offset >> 3;           //< /8
        dst_bit_pos = dst_bit_offset & 0x0007;       //< %8
        
        src_idx     = src_bit_offset >> 3;           //< /8
        src_bit_pos = src_bit_offset & 0x0007;       //< %8

        BIT_COPY_A_BIT( p_dst_dat[ dst_idx ], dst_bit_pos, p_src_dat[ src_idx ], src_bit_pos );

        dst_bit_offset++;
        src_bit_offset++;
    }
}

/**
 * @brief  获取对应的位数据
 * @param  [in] p_dat      ： 数组
 * @param  [in] bit_offset ： 偏移/位置
 * @return 对应的位数值  0/1
 * @note   
 */
uint8_t mem_utils_get_bit_val( uint8_t *p_dat, uint16_t bit_offset )
{
    uint16_t idx = 0, bit_pos = 0;
    
    idx     = bit_offset >> 3;           //< /8
    bit_pos = bit_offset & 0x0007;       //< %8

    return (p_dat[ idx ] & BIT( bit_pos )) ? 1 : 0;
}

/**
 * @brief  设置对应的位数据
 * @param  [in] p_dat      ： 数组
 * @param  [in] bit_offset ： 偏移/位置
 * @param  [in] val        ： 位数据 0/1
 * @return SF_OK：成功   非SF_OK：失败
 * @note   
 */
sf_ret_t mem_utils_set_bit_val( uint8_t *p_dat, uint16_t bit_offset, uint8_t val )
{
    uint16_t idx = 0, bit_pos = 0;
    
    idx     = bit_offset >> 3;           //< /8
    bit_pos = bit_offset & 0x0007;       //< %8

    if ( val == 1 )
    {
        p_dat[ idx ] |= BIT( bit_pos );

    }else if ( val == 0 ) 
    {
        p_dat[ idx ] &= ~BIT( bit_pos );
    }else {
        return SF_ERR_PARA;
    }

    return SF_OK;
}

/**
 * @brief  内存数据打印接口
 * @param  [in] head_str       ： 抬头数据
 * @param  [in] dat            ： 内存数据
 * @param  [in] dat_len        ： 内存数据长度
 * @param  [in] col_num        ： 显示列数
 * @param  [in] row_id_print   ： 是否打印行号
 * @return 无
 * @note   
 */
void mem_utils_print_hex_dat( char *head_str, uint8_t *dat, uint16_t dat_len, uint8_t col_num, bool row_id_print )
{
    if( head_str )
    {
        printf("%s ", head_str);
    }

    printf( "dat len:%d , data:", dat_len );
    for (size_t i = 0; i < dat_len; i++)
    {
        if( (i % col_num) == 0 )
        {
            printf( "\r\n" );
            if( row_id_print )
            {
                printf("%04d: ", i / col_num);
            }
        }
        printf( "%02X ", dat[i] );
    }
    printf( "\r\n");
}

/**
 * @brief  内存数据打印接口（double类型）
 * @param  [in] head_str       ： 抬头数据
 * @param  [in] dat            ： 内存数据
 * @param  [in] dat_len        ： 内存数据长度
 * @param  [in] format         ： 打印格式
 * @param  [in] col_num        ： 显示列数
 * @param  [in] row_id_print   ： 是否打印行号
 * @return 无
 * @note   
 */
void mem_utils_print_double_dat( char *head_str, double *dat, uint16_t dat_len, char *format, uint8_t col_num, bool row_id_print )
{
    if ( format == NULL )
        return;

    if( head_str )
    {
        printf("%s ", head_str);
    }
    
    printf( "dat len:%d , data:", dat_len );
    for (size_t i = 0; i < dat_len; i++)
    {
        if( (i % col_num) == 0 )
        {
            printf( "\r\n" );
            if( row_id_print )
            {
                printf("%04d: ", i / col_num);
            }
        }
        printf( format, dat[i] );
    }
    printf( "\r\n");
}

/**
 * @brief  内存数据打印接口（U16类型）
 * @param  [in] head_str       ： 抬头数据
 * @param  [in] dat            ： 内存数据
 * @param  [in] dat_len        ： 内存数据长度
 * @param  [in] col_num        ： 显示列数
 * @param  [in] row_id_print   ： 是否打印行号
 * @return 无
 * @note   
 */
void mem_utils_print_u16_dat( char *head_str, uint16_t *dat, uint16_t dat_len, uint8_t col_num, bool row_id_print )
{
    if( head_str )
    {
        printf("%s ", head_str);
    }

    printf( "dat len:%d , data:", dat_len );
    for (size_t i = 0; i < dat_len; i++)
    {
        if( (i % col_num) == 0 )
        {
            printf( "\r\n" );
            if( row_id_print )
            {
                printf("%04d: ", i / col_num);
            }
        }
        printf( "%04X ", dat[i] );
    }
    printf( "\r\n");
}

/**
 * @brief  打印SCI数据
 * @param  [in] sci_role        ： SCI数据来源角色
 * @param  [in] fr_in_pos       ： frame_input_dat 数据开始位置
 * @param  [in] frame_input_dat ： 帧数据
 * @param  [in] framelen        ： 数据长度
 * @return 无
 * @note   
 */
void mem_sci_format_print( sci_role_e sci_role, fr_in_pos_e fr_in_pos, uint8_t *frame_input_dat, uint16_t framelen )
{
    uint16_t print_offset = 0;
    uint16_t print_len    = 0;
    uint16_t remain_len   = framelen;
    
    if ( fr_in_pos == FR_IN_POS_HEAD )
    {
        print_len = ( sci_role == SCI_ROLE_MASTER )? 7: 6 ;
        mem_utils_print_hex_dat( "HEADER:", frame_input_dat + print_offset , print_len, 10, SF_FALSE );
        print_offset += print_len;
        remain_len   -= print_len;
        fr_in_pos = FR_IN_POS_BODY;
    }

    if ( fr_in_pos == FR_IN_POS_BODY )
    {
        print_len = remain_len - 2;
        mem_utils_print_hex_dat( "BODY:", frame_input_dat + print_offset , print_len, 10, SF_TRUE );
        print_offset += print_len;
        remain_len   -= print_len;
        fr_in_pos = FR_IN_POS_CRC;
    }

    if ( fr_in_pos == FR_IN_POS_CRC )
    {
        mem_utils_print_hex_dat( "CRC:", frame_input_dat + print_offset , print_len, 2, SF_FALSE );
    }
}