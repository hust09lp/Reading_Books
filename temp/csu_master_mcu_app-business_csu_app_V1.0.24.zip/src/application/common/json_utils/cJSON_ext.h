#ifndef _CJSON_EXT_H_
#define _CJSON_EXT_H_

#include "sofar_type.h"
#include "cJSON.h"

cJSON_bool cJSON_AddNumberArrayToObject( cJSON * object, char *ArrayName, num_type_e num_type, void *p_num_array, int array_size );

#endif
