#include "cJSON_ext.h"
#include "mem_utils.h"



cJSON_bool cJSON_AddNumberArrayToObject( cJSON * object, char *ArrayName, num_type_e num_type, void *p_num_array, int array_size )
{
    cJSON *p_num_array_js = cJSON_CreateArray();
    if ( p_num_array_js == NULL )
    {
        return false;
    }

    for (size_t i = 0; i < array_size; i++)
    {
        cJSON *p_num_js = NULL;

        if ( num_type == NUM_TYPE_BIT )
        {
            double num = mem_utils_get_bit_val( p_num_array, i );
            p_num_js = cJSON_CreateNumber( num );
        }
        else if ( num_type == NUM_TYPE_U8 )
        {
            uint8_t *p_num_u8 = p_num_array;
            p_num_js = cJSON_CreateNumber( (double)p_num_u8[i] );
        }
        else if ( num_type == NUM_TYPE_I8 )
        {
            int8_t *p_num_i8 = p_num_array;
            p_num_js = cJSON_CreateNumber( (double)p_num_i8[i] );
        }
        else if ( num_type == NUM_TYPE_U16 )
        {
            uint16_t *p_num_u16 = p_num_array;
            p_num_js = cJSON_CreateNumber( (double)p_num_u16[i] );
        }
        else if ( num_type == NUM_TYPE_I16 )
        {
            int16_t *p_num_i16 = p_num_array;
            p_num_js = cJSON_CreateNumber( (double)p_num_i16[i] );
        }
        else if ( num_type == NUM_TYPE_U32 )
        {
            uint32_t *p_num_u32 = p_num_array;
            p_num_js = cJSON_CreateNumber( (double)p_num_u32[i] );
        }
        else if ( num_type == NUM_TYPE_I32 )
        {
            int32_t *p_num_i32 = p_num_array;
            p_num_js = cJSON_CreateNumber( (double)p_num_i32[i] );
        }
        else if ( num_type == NUM_TYPE_U64 )
        {
            uint64_t *p_num_u64 = p_num_array;
            p_num_js = cJSON_CreateNumber( (double)p_num_u64[i] );
        }
        else if ( num_type == NUM_TYPE_I64 )
        {
            uint64_t *p_num_i64 = p_num_array;
            p_num_js = cJSON_CreateNumber( (double)p_num_i64[i] );
        }
        else if ( num_type == NUM_TYPE_DOUBLE )
        {
            double *p_num_double = p_num_array;
            p_num_js = cJSON_CreateNumber( (double)p_num_double[i] );
        }
        else if ( num_type == NUM_TYPE_FLOAT )
        {
            double *p_num_float = p_num_array;
            p_num_js = cJSON_CreateNumber( (double)p_num_float[i] );
        }
        
        if ( p_num_js == NULL )
        {
            cJSON_Delete( p_num_array_js );
            return false;
        }else{
            cJSON_AddItemToArray( p_num_array_js, p_num_js );
        }
    }

    cJSON_bool ret = cJSON_AddItemToObject( object, ArrayName, p_num_array_js );
    if ( ret == false )
    {
        cJSON_Delete( p_num_array_js );
    }
    return ret;
}
