#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include "data_shm.h"
#include "sdk_shm.h"
#include "errors.h"
#include "sofar_log.h"
#include "user_timer.h"
#include "utility_tool.h"
#include "csu_comb_master.h"
#include "csu_comb_slave.h"
#include "app_common.h"

#include "csu_cfg_store.h"
#include "sdk_log.h"

#if (1)
    #define CSU_MANAGE_LOG_D(...) do{ printf(__VA_ARGS__);printf("\r\n"); }while(0)
#else
    #define CSU_MANAGE_LOG_D(...) do{}while(0)
#endif

#define CSU_MANAGE_LOG_E(...) do{ printf("[ERROR]"); printf(__VA_ARGS__);printf("\r\n"); }while(0)

static csu_comb_setting_t s_last_csu_comb_setting = { .comb_enable = SF_FALSE };
static bat_charge_data_t *p_bat_charge_data = NULL;
static bool s_usr_ctrl_power_sta = SF_FALSE;
static uint16_t s_last_scenario_setting = 0;

void csu_manage_local_ip_refresh( void )
{
    csu_combine_info_t *p_csu_combine_info = sdk_shm_csu_combine_data_get();
    utility_tool_network_get_ip( "eth1", p_csu_combine_info->comb_setting.local_ip );
}

void csu_manage_set_power_sta_monitor( void )
{
    web_control_info_t *p_web_control_info = sdk_shm_web_control_data_get();

    if ( BIT_GET( p_web_control_info->csu_comb_web_set_flag, 1 ) )
    {
        /* 开机 */
        BIT_CLR( p_web_control_info->csu_comb_web_set_flag, 1 );
        s_usr_ctrl_power_sta = SF_TRUE;
        csu_master_save_sys_power_sta( s_usr_ctrl_power_sta );
        if ( ( s_last_csu_comb_setting.comb_enable == SF_TRUE )
            || ( s_last_csu_comb_setting.comb_role == CSU_ROLE_MASTER ) )
        {
            csu_master_set_sys_power_sta( SF_TRUE );
        }
    }
    if ( BIT_GET( p_web_control_info->csu_comb_web_set_flag, 2 ) )
    {
        /* 关机 */
        BIT_CLR( p_web_control_info->csu_comb_web_set_flag, 2 );
        s_usr_ctrl_power_sta = SF_FALSE;
        csu_master_save_sys_power_sta( s_usr_ctrl_power_sta );
        if ( ( s_last_csu_comb_setting.comb_enable == SF_TRUE )
            || ( s_last_csu_comb_setting.comb_role == CSU_ROLE_MASTER ) )
        {
            csu_master_set_sys_power_sta( SF_FALSE );
        }
    }
}

void csu_manage_scenario_setting_monitor( void )
{
    if ( s_last_scenario_setting != sdk_shm_constant_parameter_data_get()->system_param.cabinet_param.scenario_setting )
    {
        bool last_is_sig_junct = (s_last_scenario_setting == 3);

        s_last_scenario_setting = sdk_shm_constant_parameter_data_get()->system_param.cabinet_param.scenario_setting;

        bool now_is_sig_junct  = (s_last_scenario_setting == 3);

        if ( now_is_sig_junct != last_is_sig_junct )
        {
            web_control_info_t *p_web_control_info = sdk_shm_web_control_data_get();
            CSU_MANAGE_LOG_D("now_is_sig_junct:%d != last_is_sig_junct:%d", now_is_sig_junct, last_is_sig_junct);
            BIT_SET( p_web_control_info->csu_comb_web_set_flag, 0 );
        }
    }
}

void csu_manage_web_setting_monitor( void )
{
    web_control_info_t *p_web_control_info = sdk_shm_web_control_data_get();
    csu_combine_info_t *p_csu_combine_info = sdk_shm_csu_combine_data_get();

    if ( BIT_GET( p_web_control_info->csu_comb_web_set_flag, 0 ) )
    {
        CSU_MANAGE_LOG_D("csu combine manage service reset");
        
        /* 结束原有角色 */
        if ( s_last_csu_comb_setting.comb_enable == SF_TRUE )
        {
            if ( s_last_csu_comb_setting.comb_role == CSU_ROLE_MASTER )
            {
                csu_master_module_exit();
            }
            else if (   s_last_csu_comb_setting.comb_role == CSU_ROLE_SLAVE 
                     || s_last_csu_comb_setting.comb_role == CSU_ROLE_JUNCT )
            {
                csu_comb_slave_exit();
            }
        }
        
        csu_comb_save_setting_t csu_comb_save_setting;

        memcpy( &csu_comb_save_setting, &sdk_shm_constant_parameter_data_get()->csu_comb_save_setting, sizeof( csu_comb_save_setting_t ) );
        csu_cfg_comb_cfg_save( &csu_comb_save_setting );
        csu_comb_save_setting_to_csu_comb_setting( &sdk_shm_constant_parameter_data_get()->csu_comb_save_setting, &p_csu_combine_info->comb_setting );
        
        /* 开启新角色 */
        if ( p_csu_combine_info->comb_setting.comb_enable == SF_TRUE )
        {
            if ( p_csu_combine_info->comb_setting.comb_role == CSU_ROLE_MASTER )
            {
                /* 方式1 */
                // csu_master_save_sys_power_sta( s_usr_ctrl_power_sta );

                /* 方式2 */
                // if (   (sdk_shm_telemetry_data_get()->sys_version_telemetry_info.csu_sys_state == 0)
                //     || (sdk_shm_telemetry_data_get()->sys_version_telemetry_info.csu_sys_state == 2) )
                // {
                //     bool set_power_sta = ( sdk_shm_telemetry_data_get()->sys_version_telemetry_info.csu_sys_state == 2 )? SF_TRUE: SF_FALSE;
                //     csu_master_save_sys_power_sta( set_power_sta );
                // }else{
                //     /* 中间态，状态不确定，沿用用户控制 */
                //     csu_master_save_sys_power_sta( s_usr_ctrl_power_sta );
                // }
                
                csu_master_module_init();
            }
            else if (  p_csu_combine_info->comb_setting.comb_role == CSU_ROLE_SLAVE 
                    || p_csu_combine_info->comb_setting.comb_role == CSU_ROLE_JUNCT )
            {
                csu_comb_slave_init();
            }
        }
        s_last_csu_comb_setting = p_csu_combine_info->comb_setting;
        BIT_CLR( p_web_control_info->csu_comb_web_set_flag, 0 );
    }
}

void csu_manage_init( void )
{
    csu_combine_info_t *p_csu_combine_info = sdk_shm_csu_combine_data_get();
    csu_comb_setting_t *p_csu_comb_setting = &p_csu_combine_info->comb_setting;
    csu_comb_save_setting_t csu_comb_save_setting;
    
    p_bat_charge_data = sdk_shm_bat_charge_data_info_get();
    s_last_scenario_setting = sdk_shm_constant_parameter_data_get()->system_param.cabinet_param.scenario_setting;
    memset( &csu_comb_save_setting, 0, sizeof( csu_comb_save_setting ) );
    memset( p_csu_comb_setting, 0, sizeof( csu_comb_setting_t ) );
    if ( SF_OK != csu_cfg_comb_cfg_restore( &csu_comb_save_setting ))
    {
        /* 默认不开启 */
        csu_comb_save_setting.comb_enable = 0;
        csu_comb_save_setting.master.comb_num = 1;
        csu_comb_save_setting.junct.enable = 0;

        csu_cfg_comb_cfg_save( &csu_comb_save_setting );
    } 
    
    memcpy( &sdk_shm_constant_parameter_data_get()->csu_comb_save_setting, &csu_comb_save_setting, sizeof( csu_comb_save_setting_t ) );
    csu_comb_save_setting_to_csu_comb_setting( &csu_comb_save_setting, p_csu_comb_setting );

    csu_manage_local_ip_refresh();
    if ( p_csu_comb_setting->comb_enable == SF_TRUE )
    {
        if ( p_csu_comb_setting->comb_role == CSU_ROLE_MASTER )
        {
            csu_master_module_init();
        }
        else if (  p_csu_comb_setting->comb_role == CSU_ROLE_SLAVE
                || p_csu_comb_setting->comb_role == CSU_ROLE_JUNCT )
        {
            csu_comb_slave_init();
        }
    }
    s_usr_ctrl_power_sta = ( sdk_shm_telemetry_data_get()->sys_version_telemetry_info.csu_sys_state == 2 )? SF_TRUE: SF_FALSE;
    s_last_csu_comb_setting = *p_csu_comb_setting;
    return;
}

/**
 * @brief   CSU主从管理进程
 * @param   [in] arg
 * @note
 * @return
 */
int main(int argc, char *argv[])
{
	int32_t ret;

    // //日志初始化
	log_init((int8_t *)PATH_CONF);
    log_set_level(LOG_LVL_DEBUG);
    //共享内存初始化
	ret = common_data_init();  
	if(ret != 0)
	{
		return 0;
	}
    
    /* 等待其他进程初始化完成 */
    sleep(5);

    signal(SIGPIPE, SIG_IGN);
    csu_manage_init();

	while(1)
	{
        csu_manage_set_power_sta_monitor();
        csu_manage_scenario_setting_monitor();
        csu_manage_web_setting_monitor();
        csu_manage_local_ip_refresh();
		sleep(5);
	}

	return 0;
}