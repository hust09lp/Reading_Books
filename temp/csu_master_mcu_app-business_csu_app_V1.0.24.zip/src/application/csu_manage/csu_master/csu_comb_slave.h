#ifndef _CSU_COMB_SLAVE_H_
#define _CSU_COMB_SLAVE_H_

#include "sofar_type.h"

/**
 * @brief  CSU并机从设备初始化，并创建相关资源
 * @param  [in] 无
 * @return 无
 * @note   
 */
void csu_comb_slave_init( void );

/**
 * @brief  CSU并机从设备模式退出，资源回收，复位数据
 * @param  [in] 无
 * @return 无
 * @note   
 */
void csu_comb_slave_exit( void );

#endif
