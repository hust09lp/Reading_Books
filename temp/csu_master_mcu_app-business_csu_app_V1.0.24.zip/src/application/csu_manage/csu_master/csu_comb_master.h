#ifndef _CSU_COMB_MASTER_H_
#define _CSU_COMB_MASTER_H_

#include "sdk_log.h"
#include "mongoose.h"

/**
 * @brief   CSU主机模块初始化
 * @param
 * @note
 * @return
 */
void csu_master_module_init(void);

/**
 * @brief   CSU主机模块 退出
 * @param
 * @note
 * @return
 */
void csu_master_module_exit(void);

/**
 * @brief  设置主从机系统电源状态并保存
 * @param  [in] power_sta： 电源状态【true：开  false: 关】
 * @return SF_OK：成功   非SF_OK：失败
 * @note   
 */
sf_ret_t csu_master_set_sys_power_sta( bool power_sta );

/**
 * @brief  保存主从机系统电源状态
 * @param  [in] power_sta： 电源状态【true：开  false: 关】
 * @return SF_OK：成功   非SF_OK：失败
 * @note   
 */
sf_ret_t csu_master_save_sys_power_sta( bool power_sta );

#endif