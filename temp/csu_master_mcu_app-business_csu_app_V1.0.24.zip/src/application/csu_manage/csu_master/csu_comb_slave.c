#include "csu_comb_type.h"
#include "cJSON.h"
#include "cJSON_ext.h"
#include "data_shm.h"
#include "app_common.h"
#include "user_timer.h"
#include "csu_cfg_store.h"
#include "sdk_shm.h"
#include "csu_cfg.h"
#include "mem_utils.h"
#include <string.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <fcntl.h>

#include "sdk_log.h"

#define CSU_COMB_SLAVE_MUL_SMU_DEBUG      1  //< 多机模拟调试

#if (1)
#define CSU_COMB_SLAVE_TCP_MSG_PRINT(...) do{ printf(__VA_ARGS__);printf("\r\n"); }while(0)
#else
#define CSU_COMB_SLAVE_TCP_MSG_PRINT(...) do{}while(0)
#endif

#if (0)
#define CSU_COMB_SLAVE_LOG_D(...) do{ printf("[DEBUG]"); printf(__VA_ARGS__);printf("\r\n"); }while(0)
#else
#define CSU_COMB_SLAVE_LOG_D(...) do{}while(0)
#endif

#define CSU_COMB_SLAVE_LOG_W(...) do{ printf("[WARN]"); printf(__VA_ARGS__);printf("\r\n"); }while(0)
#define CSU_COMB_SLAVE_LOG_E(...) do{ printf("[ERROR]"); printf(__VA_ARGS__);printf("\r\n"); }while(0)

typedef struct
{
    csu_comb_setting_t  *p_setting;                      // 并柜设置，指向共享内存
    csu_combine_info_t  *p_comb_info;                    // 指向并柜共享内存
    struct 
    {
        csu_node_info_t     *p_slave;                   // 本地数据【从机】
        junct_cab_info_t    *p_junct;                   // 本地数据【汇流柜】
    } local_info;
    
    telematic_data_t    *p_telematic_data;               // 遥信信息，指向共享内存
    struct 
    {
        pthread_t       background_pthread;             // 后台处理线程
        pthread_t       tcp_recv_pthread;               // TCP 数据接收线程
        user_timer_hd   online_tm;                      // 在线定时器检查，超时代表离线
        int             con_socket;                     // 与主机连接的socket
        char            master_sn_str[50];              // 缓存主机SN数据
    } run;
} csu_comb_slave_info_t;

static csu_comb_slave_info_t s_csu_comb_slave_info;     // 并柜从机数据

static void csu_comb_slave_data_init( void );
static void csu_comb_slave_msg_handle( int socket, uint8_t *p_msg_dat, int32_t msg_dat_len );
static void global_comb_info_handle( cJSON *p_root_js );

static void csu_comb_slave_signIn_task( void );
static void csu_comb_slave_heartbeat_task( void );
static void csu_comb_online_manage_task( void );
static void csu_comb_slave_report_monitor( void );
static void csu_comb_junct_report_monitor( void );

static void csu_comb_slave_signIn_request( void );
static void csu_slave_real1_report( void );
static int csu_comb_slave_connect( uint8_t *p_master_ip );
static void csu_junct_local_real1_report( void );
static void csu_slave_local_info_fresh( void );
static void csu_slave_local_junct_info_fresh( void );
static void csu_comb_slave_set_online( bool online );

ssize_t csu_comb_slave_send ( const void *send_buff, size_t send_len, char *err_str);
static void csu_comb_signIn_request_send( csu_role_e role );
static void csu_comb_slave_json_handle( int socket, cJSON *p_root_js );

/**
 * @brief  tcp 接收线程服务
 * @param  [in] arg ：线程用户参数
 * @return 无
 * @note   
 */
void *csu_comb_slave_tcp_recv_service(void *arg)
{
    uint8_t recv_buff[ 4096 ];
    int32_t recv_len = 0;

    while (1)
    {
        memset( recv_buff, 0, sizeof( recv_buff ) );
        if ( s_csu_comb_slave_info.run.con_socket > 0 )
        {
            recv_len = recv( s_csu_comb_slave_info.run.con_socket, recv_buff, sizeof( recv_buff ), 0);
            if ( recv_len > 0 )
            {
                CSU_COMB_SLAVE_TCP_MSG_PRINT( "\r\nslave recv:%s", (char*)recv_buff );
                csu_comb_slave_msg_handle( s_csu_comb_slave_info.run.con_socket, recv_buff, recv_len );
            }
        } 
        usleep(1000);
    }
}

/**
 * @brief  后台数据处理 服务
 * @param  [in] arg ：线程用户参数
 * @return 无
 * @note   
 */
void *csu_comb_slave_background_service(void *arg)
{
    while (1)
    {
        /* tcp 心跳，定时15s , 6次超时 */
        csu_comb_slave_heartbeat_task();
        
        /* 掉线重连机制 */
        csu_comb_online_manage_task();
        
        /* 注册 */
        csu_comb_slave_signIn_task();

        /* 数据上报（变化上报/间隔上报） */
        if ( s_csu_comb_slave_info.p_setting->comb_role == CSU_ROLE_SLAVE )
        {
            csu_comb_slave_report_monitor();
        }
        else if ( s_csu_comb_slave_info.p_setting->comb_role == CSU_ROLE_JUNCT )
        {
            csu_comb_junct_report_monitor();
        }

        usleep(10000);
    }
}

/**
 * @brief  CSU并机从设备模式退出，资源回收，复位数据
 * @param  [in] 无
 * @return 无
 * @note   
 */
void csu_comb_slave_exit( void )
{
    /* 回收资源 */
    if ( s_csu_comb_slave_info.run.tcp_recv_pthread != 0 )
    {
        pthread_cancel( s_csu_comb_slave_info.run.tcp_recv_pthread );
        pthread_join( s_csu_comb_slave_info.run.tcp_recv_pthread, NULL );
        s_csu_comb_slave_info.run.tcp_recv_pthread = 0;
    }
    
    if ( s_csu_comb_slave_info.run.background_pthread != 0 )
    {
        pthread_cancel( s_csu_comb_slave_info.run.background_pthread );
        pthread_join( s_csu_comb_slave_info.run.background_pthread, NULL );
        s_csu_comb_slave_info.run.background_pthread = 0;
    }
    
    if ( s_csu_comb_slave_info.run.con_socket > 0 )
    {
        close( s_csu_comb_slave_info.run.con_socket );
        s_csu_comb_slave_info.run.con_socket = 0;
    }

    if ( s_csu_comb_slave_info.run.online_tm != NULL )
    {
        user_timer_delete( s_csu_comb_slave_info.run.online_tm );
        s_csu_comb_slave_info.run.online_tm = NULL;
    }
    
    /* 复位数据 */
    mem_utils_set_bit_val( s_csu_comb_slave_info.p_telematic_data->csu_system_fault_info, 15, 0 );
    mem_utils_set_bit_val( s_csu_comb_slave_info.p_telematic_data->csu_system_fault_info, 16, 0 );
    mem_utils_set_bit_val( s_csu_comb_slave_info.p_telematic_data->csu_system_fault_info, 17, 0 );
    memset( &s_csu_comb_slave_info.run, 0, sizeof( s_csu_comb_slave_info.run ) );
    if ( s_csu_comb_slave_info.local_info.p_slave  )
        memset( &s_csu_comb_slave_info.local_info.p_slave, 0, sizeof( csu_node_info_t ) );
    if ( s_csu_comb_slave_info.local_info.p_slave  )
        memset( &s_csu_comb_slave_info.local_info.p_junct, 0, sizeof( junct_cab_info_t ) );
}

/**
 * @brief  本机在线管理任务
 * @param  [in] 无
 * @return 无
 * @note   
 */
static void csu_comb_online_manage_task( void )
{
    if ( s_csu_comb_slave_info.p_comb_info->master_info.online == SF_TRUE )
    {
        if ( user_timer_is_timeout( s_csu_comb_slave_info.run.online_tm)  )
        {
            csu_comb_slave_set_online( SF_FALSE );
        }
    }
}

/**
 * @brief  心跳上报任务
 * @param  [in] 无
 * @return 无
 * @note   
 */
static void csu_comb_slave_heartbeat_task( void ) 
{ 
    static user_timer_hd heartbeat_tm = NULL; 

    if ( heartbeat_tm == NULL )
    {
        heartbeat_tm = user_timer_create( NULL, NULL );
        if ( heartbeat_tm == NULL )
        {
            CSU_COMB_SLAVE_LOG_E( "create heartbeat_tm timer error!!!" );
            return;
        }
        user_timer_set_timeout( heartbeat_tm, SLAVE_HEARTBEAT_INV_TM_MS, SF_FALSE );
    }
    
    if ( SF_FALSE == user_timer_is_timeout( heartbeat_tm )  )
    {
        return;
    }
    user_timer_refresh( heartbeat_tm );

    /* 心跳报文上报 */
    char reply_str[512] = {0};

    sprintf( reply_str, 
        "{\"devtype\":%d,\"cmdtype\":\"heartbeat\",\"csuSn\":\"%s\"}",
            s_csu_comb_slave_info.p_setting->comb_role,
                        (s_csu_comb_slave_info.p_setting->comb_role == CSU_ROLE_SLAVE) ? s_csu_comb_slave_info.local_info.p_slave->sn:
                        (s_csu_comb_slave_info.p_setting->comb_role == CSU_ROLE_JUNCT) ? s_csu_comb_slave_info.local_info.p_junct->sn: "0" );
    
    csu_comb_slave_send( reply_str, strlen( reply_str ), "send heartbeat error");
}

/**
 * @brief  从机注册请求
 * @param  [in] 无
 * @return 无
 * @note   
 */
static void csu_comb_slave_signIn_request( void ) 
{
    if ( s_csu_comb_slave_info.run.tcp_recv_pthread != 0 )
    {
        pthread_cancel( s_csu_comb_slave_info.run.tcp_recv_pthread );
        pthread_join( s_csu_comb_slave_info.run.tcp_recv_pthread, NULL );
        s_csu_comb_slave_info.run.tcp_recv_pthread = 0;
    }
    if ( s_csu_comb_slave_info.run.con_socket > 0 )
    {
        close( s_csu_comb_slave_info.run.con_socket);
        s_csu_comb_slave_info.run.con_socket = 0;
    }

    int socket_fd = csu_comb_slave_connect( s_csu_comb_slave_info.p_setting->slave.con_master_ip );
    if ( socket_fd < 0 )
    {
        return;
    }
    s_csu_comb_slave_info.run.con_socket = socket_fd;

	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	if(pthread_create( &s_csu_comb_slave_info.run.tcp_recv_pthread, &attr, csu_comb_slave_tcp_recv_service, NULL) != 0)
	{
		CSU_COMB_SLAVE_LOG_E("pthread_create csu_comb_slave_tcp_recv_service");
	}
    CSU_COMB_SLAVE_LOG_D( "tcp_recv_pthread:%d", (int)s_csu_comb_slave_info.run.tcp_recv_pthread );

    csu_comb_signIn_request_send( s_csu_comb_slave_info.p_setting->comb_role );

    return;
}

/**
 * @brief  从机注册任务
 * @param  [in] 无
 * @return 无
 * @note   
 */
static void csu_comb_slave_signIn_task( void ) 
{ 
    static user_timer_hd signIn_tm = NULL; 

    if ( signIn_tm == NULL )
    {
        signIn_tm = user_timer_create( NULL, NULL );
        if ( signIn_tm == NULL ) 
        {
            CSU_COMB_SLAVE_LOG_E( "create signIn timer error!!!" );
            return;
        }
        user_timer_set_timeout( signIn_tm, SLAVE_SIGIN_INV_TM_MS, SF_FALSE );
    }

    /* 在线不需要注册 */
    if (   SF_TRUE == s_csu_comb_slave_info.p_comb_info->master_info.online 
        || SF_FALSE == user_timer_is_timeout( signIn_tm ) )
    {
        return;
    }

    user_timer_refresh( signIn_tm );
    csu_comb_slave_signIn_request();

    return;
}

/**
 * @brief  从机注册消息处理
 * @param  [in] p_root_js ： 注册消息JSON根节点
 * @return 无
 * @note   
 */
void csu_slave_signIn_handle( cJSON* p_root_js )
{
    cJSON *p_sn_js = cJSON_GetObjectItem( p_root_js, "csuSn" );
    if ( p_sn_js == NULL )
    {
        CSU_COMB_SLAVE_LOG_E("%s p_sn_js == NULL", __FUNCTION__);
        return;
    }

    if ( cJSON_GetObjectItem( p_root_js, "result" )->valueint != 1 )
    {
        CSU_COMB_SLAVE_LOG_E("%s result error!!!", __FUNCTION__);
        return;
    }
    strcpy( s_csu_comb_slave_info.run.master_sn_str, p_sn_js->valuestring );

    if ( s_csu_comb_slave_info.p_setting->comb_role == CSU_ROLE_SLAVE )
    {
        csu_slave_local_info_fresh();
        csu_slave_real1_report();
    }
    else if ( s_csu_comb_slave_info.p_setting->comb_role == CSU_ROLE_JUNCT )
    {
        csu_slave_local_junct_info_fresh();
        csu_junct_local_real1_report();
    }
}

/**
 * @brief  从机控制消息处理
 * @param  [in] p_root_js ： 消息JSON根节点
 * @return 无
 * @note   
 */
void csu_slave_control_handle( cJSON* p_root_js )
{
    cJSON *p_ctrl_js = cJSON_GetObjectItem( p_root_js, "power" );
    constant_parameter_data_t *p_constant_parameter_info = sdk_shm_constant_parameter_data_get();

    if ( p_ctrl_js != NULL )
    {
        web_control_info_t *p_web_data = sdk_shm_web_control_data_get();

        if ( strcmp(p_ctrl_js->valuestring, "on") == 0 ) 
        {
            BIT_SET(p_web_data->control_cmd_flag, 5);
            CSU_COMB_SLAVE_LOG_D("master set power on");
        }else if ( strcmp(p_ctrl_js->valuestring, "off") == 0 ) 
        {
            BIT_SET(p_web_data->control_cmd_flag, 6);
            CSU_COMB_SLAVE_LOG_D("master set power off");
        }else if ( strcmp(p_ctrl_js->valuestring, "energy_save_on") == 0 ) 
        {
            p_constant_parameter_info->mcu2_notice[0] = 1;
            CSU_COMB_SLAVE_LOG_D("master set energy_save_on");
        }else if ( strcmp(p_ctrl_js->valuestring, "energy_save_off") == 0 ) 
        {
            p_constant_parameter_info->mcu2_notice[0] = 2;
            CSU_COMB_SLAVE_LOG_D("master set energy_save_off");
        }else if ( strcmp(p_ctrl_js->valuestring, "energy_save_stop") == 0 ) 
        {
            p_constant_parameter_info->mcu2_notice[0] = 3;
            CSU_COMB_SLAVE_LOG_D("master set energy_save_stop");
        }
    }
}

/**
 * @brief  从机实时消息处理
 * @param  [in] p_root_js ： 消息JSON根节点
 * @return 无
 * @note   
 */
void csu_slave_real1_handle( cJSON* p_root_js )
{
    cJSON *p_outP_js = cJSON_GetObjectItem( p_root_js, "outP" );
    if ( p_outP_js == NULL )
    {
        CSU_COMB_SLAVE_LOG_E("%s p_outP_js == NULL", __FUNCTION__);
        return;
    }

    s_csu_comb_slave_info.local_info.p_slave->ems_alloc_power = p_outP_js->valuedouble * 100;

    web_control_info_t *sdk_shm_web_data = sdk_shm_web_control_data_get();
    cabinet_parameter_data_t *p_cabinet_param = &sdk_shm_web_data->cabinet_param_data;
    int16_t set_act_power = s_csu_comb_slave_info.local_info.p_slave->ems_alloc_power / 10;

    if ( p_cabinet_param->active_power != set_act_power )
    {
        p_cabinet_param->active_power = set_act_power;
        BIT_SET(sdk_shm_web_data->cabinet_param_update_flag, 1);
        CSU_COMB_SLAVE_LOG_D( "set active power:%0.1f", p_cabinet_param->active_power / 10.0 );
    }

    return;
}

static void csu_comb_junct_report_monitor( void ) 
{
    static user_timer_hd report_tm = NULL; 
    bool report = SF_FALSE;

    if ( report_tm == NULL )
    {
        report_tm = user_timer_create( NULL, NULL );
        if ( report_tm == NULL )
        {
            CSU_COMB_SLAVE_LOG_E( "create csu_comb_junct_report_monitor error!!!" );
            return;
        }
        user_timer_set_timeout( report_tm, SLAVE_REAL_DAT_REPORT_INV_TM_MS, SF_FALSE );
    }

    if( s_csu_comb_slave_info.p_comb_info->master_info.online == SF_FALSE )
    {
        return;
    }

    if ( user_timer_is_timeout( report_tm ) )
    {
        user_timer_refresh( report_tm );
        report = SF_TRUE;
    }

    csu_slave_local_junct_info_fresh();

    static junct_cab_info_t last_junct_cab_info = {0};
    junct_cab_info_t *p_junct_cab_info = s_csu_comb_slave_info.local_info.p_junct;

    if( ( 0 != memcmp( p_junct_cab_info->ContactorStatus, last_junct_cab_info.ContactorStatus, sizeof(last_junct_cab_info.ContactorStatus) ) )
        || ( p_junct_cab_info->meter_dat.enable     != last_junct_cab_info.meter_dat.enable    )
        || ( p_junct_cab_info->meter_dat.a_vol      != last_junct_cab_info.meter_dat.a_vol     )
        || ( p_junct_cab_info->meter_dat.b_vol      != last_junct_cab_info.meter_dat.b_vol     )
        || ( p_junct_cab_info->meter_dat.c_vol      != last_junct_cab_info.meter_dat.c_vol     )
        || ( p_junct_cab_info->meter_dat.act_power  != last_junct_cab_info.meter_dat.act_power )
        || ( p_junct_cab_info->fan_sta              != last_junct_cab_info.fan_sta             )
        || ( p_junct_cab_info->cabinet_type         != last_junct_cab_info.cabinet_type        )
        || ( p_junct_cab_info->cab_top_tmp          != last_junct_cab_info.cab_top_tmp         )
        || ( p_junct_cab_info->cab_buttom_tmp       != last_junct_cab_info.cab_buttom_tmp      )
        || ( p_junct_cab_info->cab_humidity         != last_junct_cab_info.cab_humidity        )
        || ( p_junct_cab_info->cab_flood_sta        != last_junct_cab_info.cab_flood_sta       )
        || ( p_junct_cab_info->cab_door_sta         != last_junct_cab_info.cab_door_sta        ))
    {
        memcpy( &last_junct_cab_info, p_junct_cab_info, sizeof( junct_cab_info_t ) );
        report = SF_TRUE;
    }

    if ( report )
    {
        csu_junct_local_real1_report();
    }
}

/**
 * @brief  从机数据上报监控【定时+变化闪报】
 * @param  [in] 无
 * @return 无
 * @note   
 */
static void csu_comb_slave_report_monitor( void ) 
{ 
    static user_timer_hd report_tm = NULL; 
    bool report = SF_FALSE;

    if ( report_tm == NULL )
    {
        report_tm = user_timer_create( NULL, NULL );
        if ( report_tm == NULL )
        {
            CSU_COMB_SLAVE_LOG_E( "create report_tm error!!!" );
            return;
        }
        user_timer_set_timeout( report_tm, SLAVE_REAL_DAT_REPORT_INV_TM_MS, SF_FALSE );
    }

    if ( user_timer_is_timeout( report_tm ) )
    {
        user_timer_refresh( report_tm );
        report = SF_TRUE;
    }

    csu_slave_local_info_fresh();

    csu_node_info_t *p_cur_csu_node_info = s_csu_comb_slave_info.local_info.p_slave;
    static csu_node_info_t last_csu_node_info = {0};

    /* 监控以下变量是否发生变化 */
    if (   (p_cur_csu_node_info->valid                             != last_csu_node_info.valid)
        || (p_cur_csu_node_info->online                            != last_csu_node_info.online)
        || (p_cur_csu_node_info->real_data.sys_status              != last_csu_node_info.real_data.sys_status)
        || (p_cur_csu_node_info->real_data.charge_prohibit         != last_csu_node_info.real_data.charge_prohibit)
        || (p_cur_csu_node_info->real_data.discharge_prohibit      != last_csu_node_info.real_data.discharge_prohibit)
        || (p_cur_csu_node_info->real_data.pcs_charge_max_power    != last_csu_node_info.real_data.pcs_charge_max_power)
        || (p_cur_csu_node_info->real_data.pcs_discharge_max_power != last_csu_node_info.real_data.pcs_discharge_max_power)
        || (p_cur_csu_node_info->real_data.bat_charge_max_power    != last_csu_node_info.real_data.bat_charge_max_power)
        || (p_cur_csu_node_info->real_data.bat_discharge_max_power != last_csu_node_info.real_data.bat_discharge_max_power)
        || (p_cur_csu_node_info->real_data.curr_pcs_power          != last_csu_node_info.real_data.curr_pcs_power)
        || (p_cur_csu_node_info->real_data.SOC                     != last_csu_node_info.real_data.SOC)
        || (p_cur_csu_node_info->real_data.SOH                     != last_csu_node_info.real_data.SOH))
    {
        memcpy( &last_csu_node_info, p_cur_csu_node_info, sizeof( csu_node_info_t ) );
        report = SF_TRUE;
    }
    
    /* 防止电表频繁变化上传 */
    int16_t dis_power = ( p_cur_csu_node_info->real_data.meter_power > last_csu_node_info.real_data.meter_power) ?
                          p_cur_csu_node_info->real_data.meter_power - last_csu_node_info.real_data.meter_power
                        : last_csu_node_info.real_data.meter_power - p_cur_csu_node_info->real_data.meter_power;
    if ( dis_power > 10) 
    {
        /* 波动超过0.1KW */
        memcpy( &last_csu_node_info, p_cur_csu_node_info, sizeof( csu_node_info_t ) );
        report = SF_TRUE;
    }

    if ( s_csu_comb_slave_info.p_comb_info->master_info.online == SF_TRUE
        && report == SF_TRUE )
    {
        csu_slave_real1_report();
    }
}

static void csu_slave_local_junct_info_fresh( void )
{
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();

    internal_shared_data_t *p_internal_shared_data = &sdk_shm_get()->internal_shared_data;

    for (size_t i = 0; i < ARRAY_SIZE( s_csu_comb_slave_info.local_info.p_junct->ContactorStatus ); i++)
    {
        if (mem_utils_get_bit_val( p_telematic_data->combiner_cabinet_system_status_info, 19 + i ))
        {
            s_csu_comb_slave_info.local_info.p_junct->ContactorStatus[i] = 1;
        }else{
            s_csu_comb_slave_info.local_info.p_junct->ContactorStatus[i] = 0;
        }
    }
    s_csu_comb_slave_info.local_info.p_junct->fan_sta       = mem_utils_get_bit_val( p_telematic_data->combiner_cabinet_system_status_info, 26 );
    s_csu_comb_slave_info.local_info.p_junct->cab_door_sta  = mem_utils_get_bit_val( p_telematic_data->combiner_cabinet_system_status_info, 2 );
    s_csu_comb_slave_info.local_info.p_junct->cab_flood_sta = mem_utils_get_bit_val( p_telematic_data->combiner_cabinet_system_status_info, 1 );
    
    s_csu_comb_slave_info.local_info.p_junct->cabinet_type        = p_internal_shared_data->cabinet_type;
    s_csu_comb_slave_info.local_info.p_junct->cab_buttom_tmp      = p_telemetry_data->sys_cabinet_telemetry_info.at_temperature;
    s_csu_comb_slave_info.local_info.p_junct->cab_top_tmp         = p_telemetry_data->sys_cabinet_telemetry_info.dry_temp;
    s_csu_comb_slave_info.local_info.p_junct->cab_humidity        = p_telemetry_data->sys_cabinet_telemetry_info.dry_humidity;
    
    s_csu_comb_slave_info.local_info.p_junct->meter_dat.enable    = sdk_shm_get()->constant_parameter_data.cabinet_param_data.rs485_device_enable.bit.metering_meter;
    if (   s_csu_comb_slave_info.local_info.p_junct->meter_dat.enable == SF_TRUE )
    {
        /* 开启计量表时，使用自身数据 */
        /* 主机离线时，使用自身数据 */
        s_csu_comb_slave_info.local_info.p_junct->meter_dat.a_vol     = p_internal_shared_data->total_realtime_energy.meter_data.volt_a;
        s_csu_comb_slave_info.local_info.p_junct->meter_dat.b_vol     = p_internal_shared_data->total_realtime_energy.meter_data.volt_b;
        s_csu_comb_slave_info.local_info.p_junct->meter_dat.c_vol     = p_internal_shared_data->total_realtime_energy.meter_data.volt_c;
        s_csu_comb_slave_info.local_info.p_junct->meter_dat.a_curr    = p_internal_shared_data->total_realtime_energy.meter_data.current_a;
        s_csu_comb_slave_info.local_info.p_junct->meter_dat.b_curr    = p_internal_shared_data->total_realtime_energy.meter_data.current_b;
        s_csu_comb_slave_info.local_info.p_junct->meter_dat.c_curr    = p_internal_shared_data->total_realtime_energy.meter_data.current_c;
        s_csu_comb_slave_info.local_info.p_junct->meter_dat.act_power = p_internal_shared_data->total_realtime_energy.meter_data.active_power_total * 10;
    }
}

/**
 * @brief  从机数据本地信息刷新
 * @param  [in] 无
 * @return 无
 * @note   
 */
static void csu_slave_local_info_fresh( void )
{
    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();
    bat_charge_data_t *p_bat_charge_data = sdk_shm_bat_charge_data_info_get();
    internal_shared_data_t *p_internal_shared_data = sdk_shm_internal_shared_data_get();

    s_csu_comb_slave_info.local_info.p_slave->real_data.valid    = SF_TRUE;
    s_csu_comb_slave_info.local_info.p_slave->real_data.sys_status              = p_telemetry_data->sys_version_telemetry_info.csu_sys_state;
    s_csu_comb_slave_info.local_info.p_slave->real_data.charge_prohibit         = p_bat_charge_data->charge_prohibit;
    s_csu_comb_slave_info.local_info.p_slave->real_data.discharge_prohibit      = p_bat_charge_data->discharge_prohibit;
    s_csu_comb_slave_info.local_info.p_slave->real_data.bat_charge_max_power    = p_bat_charge_data->charge_limit_power;
    s_csu_comb_slave_info.local_info.p_slave->real_data.bat_discharge_max_power = p_bat_charge_data->discharge_limit_power;
    s_csu_comb_slave_info.local_info.p_slave->real_data.pcs_charge_max_power    = p_bat_charge_data->pcs_chg_limit_power;
    s_csu_comb_slave_info.local_info.p_slave->real_data.pcs_discharge_max_power = p_bat_charge_data->pcs_dischg_limit_power;
    s_csu_comb_slave_info.local_info.p_slave->real_data.meter_power             = p_internal_shared_data->total_realtime_energy.meter_power / 10 ;
    s_csu_comb_slave_info.local_info.p_slave->real_data.curr_pcs_power          = p_telemetry_data->sys_cabinet_telemetry_info.ac_side_active_power * 10;
    s_csu_comb_slave_info.local_info.p_slave->real_data.bat_vol                 = p_bat_charge_data->total_vol * 10;
    s_csu_comb_slave_info.local_info.p_slave->real_data.bat_curr                = p_bat_charge_data->total_curr * 10;
    s_csu_comb_slave_info.local_info.p_slave->real_data.cluster_cap_energy      = p_bat_charge_data->cluster_cap_energy;
    s_csu_comb_slave_info.local_info.p_slave->real_data.cluster_num             = p_bat_charge_data->cluster_num;
    s_csu_comb_slave_info.local_info.p_slave->real_data.ac_a_curr               = p_internal_shared_data->total_realtime_energy.meter_data.current_a;
    s_csu_comb_slave_info.local_info.p_slave->real_data.ac_b_curr               = p_internal_shared_data->total_realtime_energy.meter_data.current_b;
    s_csu_comb_slave_info.local_info.p_slave->real_data.ac_c_curr               = p_internal_shared_data->total_realtime_energy.meter_data.current_c;

    uint8_t valid_soc_cnt = 0;
    uint16_t sum_soc = 0;
    uint16_t sum_soh = 0;

    for (size_t i = 0; i < ARRAY_SIZE( p_bat_charge_data->soc_soh_data ); i++)
    {
        if ( p_bat_charge_data->soc_soh_data[i].soc != 0XFFFF )
        {
            valid_soc_cnt ++;
            sum_soc += p_bat_charge_data->soc_soh_data[i].soc;
            sum_soh += p_bat_charge_data->soc_soh_data[i].soh;
        }
    }
    if ( valid_soc_cnt != 0 )
    {
        s_csu_comb_slave_info.local_info.p_slave->real_data.SOC = sum_soc / valid_soc_cnt;
        s_csu_comb_slave_info.local_info.p_slave->real_data.SOH = sum_soh / valid_soc_cnt;
    }

    if ( s_csu_comb_slave_info.p_comb_info->master_info.online == SF_FALSE )
    {
        /* 当主机离线时，以自身数据为主 */
        internal_shared_data_t *internal_shared_data = sdk_shm_internal_shared_data_get();

        s_csu_comb_slave_info.p_comb_info->global_info.SOC =s_csu_comb_slave_info.local_info.p_slave->real_data.SOC;
        s_csu_comb_slave_info.p_comb_info->junct_info.meter_dat.a_vol     = internal_shared_data->total_realtime_energy.meter_data.volt_a;
        s_csu_comb_slave_info.p_comb_info->junct_info.meter_dat.b_vol     = internal_shared_data->total_realtime_energy.meter_data.volt_b;
        s_csu_comb_slave_info.p_comb_info->junct_info.meter_dat.c_vol     = internal_shared_data->total_realtime_energy.meter_data.volt_c;
        s_csu_comb_slave_info.p_comb_info->junct_info.meter_dat.act_power = internal_shared_data->total_realtime_energy.meter_data.active_power_total;
    }
}

/**
 * @brief  从机实时数据上报
 * @param  [in] 无
 * @return 无
 * @note   
 */
static void csu_slave_real1_report( void )
{
    csu_node_info_t *p_slave_info = s_csu_comb_slave_info.local_info.p_slave;

    cJSON *p_root_js = cJSON_CreateObject();
    if ( p_root_js == NULL )
    {
        return;
    }

    cJSON_AddStringToObject( p_root_js, "cmdtype", "real1" );
    cJSON_AddNumberToObject( p_root_js, "devtype", s_csu_comb_slave_info.p_setting->comb_role  );
    cJSON_AddStringToObject( p_root_js, "csuSn"  , s_csu_comb_slave_info.local_info.p_slave->sn );

    cJSON *p_data_js = cJSON_AddObjectToObject( p_root_js, "data" );
    if ( p_data_js == NULL )
    {
        cJSON_Delete( p_root_js );
        return;
    }

    cJSON_AddNumberToObject( p_data_js, "soc"               , p_slave_info->real_data.SOC  );
    cJSON_AddNumberToObject( p_data_js, "soh"               , p_slave_info->real_data.SOH  );
    cJSON_AddNumberToObject( p_data_js, "runStatus"         , p_slave_info->real_data.sys_status  );
    cJSON_AddNumberToObject( p_data_js, "ChargeFlag"        , p_slave_info->real_data.charge_prohibit  );
    cJSON_AddNumberToObject( p_data_js, "DischargeFlag"     , p_slave_info->real_data.discharge_prohibit  );
    cJSON_AddNumberToObject( p_data_js, "ChargeLoad"        , p_slave_info->real_data.pcs_charge_max_power / 100.0  );
    cJSON_AddNumberToObject( p_data_js, "DischargeLoad"     , p_slave_info->real_data.pcs_discharge_max_power / 100.0  );
    cJSON_AddNumberToObject( p_data_js, "BattChargeLoad"    , p_slave_info->real_data.bat_charge_max_power / 100.0  );
    cJSON_AddNumberToObject( p_data_js, "BattDischargeLoad" , p_slave_info->real_data.bat_discharge_max_power / 100.0  );
    cJSON_AddNumberToObject( p_data_js, "meterP"            , p_slave_info->real_data.meter_power / 100.0  );
    cJSON_AddNumberToObject( p_data_js, "currP"             , p_slave_info->real_data.curr_pcs_power / 100.0  );
    cJSON_AddNumberToObject( p_data_js, "batVol"            , p_slave_info->real_data.bat_vol / 10.0 );
    cJSON_AddNumberToObject( p_data_js, "batCurr"           , p_slave_info->real_data.bat_curr / 10.0 );
    cJSON_AddNumberToObject( p_data_js, "aCurr"             , p_slave_info->real_data.ac_a_curr / 10.0 );
    cJSON_AddNumberToObject( p_data_js, "bCurr"             , p_slave_info->real_data.ac_b_curr / 10.0 );
    cJSON_AddNumberToObject( p_data_js, "cCurr"             , p_slave_info->real_data.ac_c_curr / 10.0 );
    cJSON_AddNumberArrayToObject( p_data_js, "cellVmax", NUM_TYPE_U16 , s_csu_comb_slave_info.local_info.p_slave->real_data.cell_max_vol, 
                                                                        ARRAY_SIZE( s_csu_comb_slave_info.local_info.p_slave->real_data.cell_max_vol ) );
    cJSON_AddNumberArrayToObject( p_data_js, "cellVmin", NUM_TYPE_U16 , s_csu_comb_slave_info.local_info.p_slave->real_data.cell_min_vol, 
                                                                        ARRAY_SIZE( s_csu_comb_slave_info.local_info.p_slave->real_data.cell_min_vol ) );

    char *p_str = cJSON_PrintUnformatted( p_root_js );
    if ( p_str == NULL )
    {
        cJSON_Delete( p_root_js );
        return;
    }
    csu_comb_slave_send( p_str, strlen( p_str ), "csu_slave_real1_report error!!!");

    free( p_str );
    cJSON_Delete( p_root_js );
    return;
}

static void csu_junct_local_real1_report( void )
{
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();
    cJSON *p_root_js = cJSON_CreateObject();
    if ( p_root_js == NULL || p_telematic_data == NULL )
    {
        return;
    }

    cJSON_AddStringToObject( p_root_js, "cmdtype", "real1" );
    cJSON_AddNumberToObject( p_root_js, "devtype", s_csu_comb_slave_info.p_setting->comb_role  );
    cJSON_AddStringToObject( p_root_js, "csuSn"  , s_csu_comb_slave_info.local_info.p_junct->sn );

    cJSON *p_data_js = cJSON_AddObjectToObject( p_root_js, "data" );
    if ( p_data_js == NULL )
    {
        cJSON_Delete( p_root_js );
        return;
    }

    junct_cab_info_t *p_junct_info = s_csu_comb_slave_info.local_info.p_junct;

    cJSON_AddNumberToObject( p_data_js, "meterEnable"            , p_junct_info->meter_dat.enable );
    cJSON_AddNumberToObject( p_data_js, "gridVolSystemFlag"      , p_junct_info->cabinet_type );
    cJSON_AddNumberToObject( p_data_js, "CabinTopTemperature"    , p_junct_info->cab_top_tmp );
    cJSON_AddNumberToObject( p_data_js, "CabinBottomTemperature" , p_junct_info->cab_buttom_tmp );
    cJSON_AddNumberToObject( p_data_js, "Humidity"               , p_junct_info->cab_humidity );
    cJSON_AddNumberToObject( p_data_js, "FanStatus"              , p_junct_info->fan_sta );
    cJSON_AddNumberToObject( p_data_js, "DoorStatus"             , p_junct_info->cab_door_sta );
    cJSON_AddNumberToObject( p_data_js, "FloodStatus"            , p_junct_info->cab_flood_sta );

    // 汇流柜故障 = 监控板过温保护 || AC舱过温保护 || 门禁告警
    if(mem_utils_get_bit_val(&p_telematic_data->combiner_cabinet_system_fault_info[0],2) == 1 \
    || mem_utils_get_bit_val(&p_telematic_data->combiner_cabinet_system_fault_info[0],3) == 1 \
    || mem_utils_get_bit_val(&p_telematic_data->combiner_cabinet_system_fault_info[1],1) == 1 )
    {
        cJSON_AddNumberToObject( p_data_js, "FaultStatus" , 1 );
    }
    else
    {
        cJSON_AddNumberToObject( p_data_js, "FaultStatus" , 0 );
    }
    
    
    if ( p_junct_info->meter_dat.enable == SF_TRUE )    
    {
        cJSON *p_meter_dat_js = cJSON_AddObjectToObject( p_data_js, "meterData" );
        if ( p_meter_dat_js == NULL )
        {
            cJSON_Delete( p_root_js );
            return;
        }
        cJSON_AddNumberToObject( p_meter_dat_js, "abVolt"  , p_junct_info->meter_dat.a_vol / 10 );
        cJSON_AddNumberToObject( p_meter_dat_js, "caVolt"  , p_junct_info->meter_dat.b_vol / 10 );
        cJSON_AddNumberToObject( p_meter_dat_js, "bcVolt"  , p_junct_info->meter_dat.c_vol / 10 );
        cJSON_AddNumberToObject( p_meter_dat_js, "aCurr"   , p_junct_info->meter_dat.a_curr / 10 );
        cJSON_AddNumberToObject( p_meter_dat_js, "bCurr"   , p_junct_info->meter_dat.b_curr / 10 );
        cJSON_AddNumberToObject( p_meter_dat_js, "cCurr"   , p_junct_info->meter_dat.c_curr / 10 );
        cJSON_AddNumberToObject( p_meter_dat_js, "acPower" , p_junct_info->meter_dat.act_power );
    }

    cJSON *p_con_sta_array_js = cJSON_AddArrayToObject( p_data_js, "ContactorStatus" );
    if ( p_con_sta_array_js == NULL )
    {
        cJSON_Delete( p_root_js );
        return;
    }

    for (size_t i = 0; i < ARRAY_SIZE( s_csu_comb_slave_info.local_info.p_junct->ContactorStatus ); i++)
    {
        cJSON *p_con_sta_js = cJSON_CreateNumber( s_csu_comb_slave_info.local_info.p_junct->ContactorStatus[i] );
        if ( p_con_sta_js == NULL )
        {
            cJSON_Delete( p_root_js );
            return;
        }
        cJSON_AddItemToArray( p_con_sta_array_js, p_con_sta_js );
    }

    char *p_str = cJSON_PrintUnformatted( p_root_js );
    if ( p_str == NULL )
    {
        cJSON_Delete( p_root_js );
        return;
    }
    csu_comb_slave_send( p_str, strlen( p_str ), "csu_junct_local_real1_report error!!!");

    free( p_str );
    cJSON_Delete( p_root_js );
    return;
}


/**
 * @brief  从机接受消息处理
 * @param  [in] socket      :  tcp 通讯套接字
 * @param  [in] p_msg_dat   ： 接收到的数据
 * @param  [in] msg_dat_len ： 接收到的数据长度
 * @return 无
 * @note   
 */
static void csu_comb_slave_msg_handle( int socket, uint8_t *p_msg_dat, int32_t msg_dat_len ) 
{
    int remain_dat_len = msg_dat_len;
    char *p_js_str       = (char*)p_msg_dat;
    char *p_next_js_str  = NULL;

    while ( remain_dat_len > 0 )
    {
        cJSON *p_root_js = cJSON_ParseWithLengthOpts( p_js_str, remain_dat_len, (const char **)&p_next_js_str, 0);

        if ( p_root_js != NULL )
        {
            csu_comb_slave_json_handle( socket, p_root_js );
        }else{
            CSU_COMB_SLAVE_LOG_W( "p_root_js == NULL, remain_dat_len:%d!!!", remain_dat_len );
            return;
        }

        if ( p_next_js_str == NULL )
        {
            break;
        }

        remain_dat_len = remain_dat_len - (p_next_js_str - p_js_str);
        p_js_str = p_next_js_str;
        p_next_js_str = NULL;
    }
}


static void csu_comb_slave_json_handle( int socket, cJSON *p_root_js ) 
{
    cJSON *p_devtype_js = cJSON_GetObjectItem( p_root_js, "devtype" );
    cJSON *p_cmd_js     = cJSON_GetObjectItem( p_root_js, "cmdtype" );
    cJSON *p_sn_js      = cJSON_GetObjectItem( p_root_js, "csuSn" );

    if ( p_devtype_js == NULL || p_cmd_js == NULL || p_sn_js == NULL)
    {
        CSU_COMB_SLAVE_LOG_E( "p_devtype_js == NULL || p_cmd_js == NULL || p_sn_js == NULL !!!" );
        return;
    }
    
    if ( p_devtype_js->valueint != 1 )
    {
        CSU_COMB_SLAVE_LOG_E("%s devtype:%d error!!!", __FUNCTION__, p_devtype_js->valueint);
        return;
    }

    if ( strcmp( p_cmd_js->valuestring, "signIn" ) == 0 )
    {
        csu_slave_signIn_handle( p_root_js );
        return;
    } 

    if ( strcmp( p_sn_js->valuestring, s_csu_comb_slave_info.run.master_sn_str ) != 0 )
    {
        CSU_COMB_SLAVE_LOG_W( "master sn error!!!" );
        return;
    }
    csu_comb_slave_set_online( SF_TRUE );

    if ( strcmp( p_cmd_js->valuestring, "real1" ) == 0 )
    {
        csu_slave_real1_handle( p_root_js );
    } 
    else if ( strcmp( p_cmd_js->valuestring, "heartbeat" ) == 0 )
    {
        s_csu_comb_slave_info.p_comb_info->master_info.online = SF_TRUE;
        user_timer_refresh( s_csu_comb_slave_info.run.online_tm );
    } 
    else if ( strcmp( p_cmd_js->valuestring, "control" ) == 0 )
    {
        csu_slave_control_handle( p_root_js );
    } 
    else if ( strcmp( p_cmd_js->valuestring, "globalInfo" ) == 0 )
    {
        global_comb_info_handle( p_root_js );
    } 
    cJSON_Delete( p_root_js );
}

/**
 * @brief  从模块初始化
 * @param  [in] 无
 * @return 无
 * @note   
 */
void csu_comb_slave_init( void )
{
    CSU_COMB_SLAVE_LOG_D("%s", __FUNCTION__);
    csu_comb_slave_data_init();

	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	if(pthread_create( &s_csu_comb_slave_info.run.background_pthread, &attr, csu_comb_slave_background_service, NULL) != 0)
	{
		CSU_COMB_SLAVE_LOG_E("pthread_create csu_comb_slave_background_service");
	}
    // CSU_COMB_SLAVE_LOG_D( "background_pthread:%d", (int)s_csu_comb_slave_info.run.background_pthread );
	pthread_attr_destroy(&attr);
}

/**
 * @brief  从模块数据初始化
 * @param  [in] 无
 * @return 无
 * @note   
 */
static void csu_comb_slave_data_init( void )
{
    csu_combine_info_t *p_csu_combine_info = sdk_shm_csu_combine_data_get();
    memset( &s_csu_comb_slave_info, 0, sizeof( csu_comb_slave_info_t ) );
    

    s_csu_comb_slave_info.p_telematic_data  = sdk_shm_telematic_data_get();
    s_csu_comb_slave_info.p_comb_info       = sdk_shm_csu_combine_data_get();
    s_csu_comb_slave_info.p_setting         = &p_csu_combine_info->comb_setting;
    memset( &s_csu_comb_slave_info.p_comb_info->master_info  , 0, sizeof( s_csu_comb_slave_info.p_comb_info->master_info ) );
    memset( &s_csu_comb_slave_info.p_comb_info->slave_info   , 0, sizeof( s_csu_comb_slave_info.p_comb_info->slave_info ) );
    memset( &s_csu_comb_slave_info.p_comb_info->junct_info   , 0, sizeof( s_csu_comb_slave_info.p_comb_info->junct_info ) );
    memset( &s_csu_comb_slave_info.p_comb_info->global_info  , 0, sizeof( s_csu_comb_slave_info.p_comb_info->global_info ) );

    s_csu_comb_slave_info.local_info.p_junct = &s_csu_comb_slave_info.p_comb_info->junct_info;
    if ( s_csu_comb_slave_info.p_setting->comb_role == CSU_ROLE_SLAVE )
    {
        s_csu_comb_slave_info.local_info.p_slave = &s_csu_comb_slave_info.p_comb_info->slave_info[ s_csu_comb_slave_info.p_setting->slave.local_slave_id - 1 ];
        s_csu_comb_slave_info.local_info.p_slave->valid  = SF_TRUE;
        s_csu_comb_slave_info.local_info.p_slave->online = SF_TRUE;
        strcpy( s_csu_comb_slave_info.local_info.p_slave->sn, (char*)sdk_shm_telemetry_data_get()->sys_version_telemetry_info.sn_version_number ); 

    #if CSU_COMB_SLAVE_MUL_SMU_DEBUG 
        sprintf( s_csu_comb_slave_info.local_info.p_slave->sn, "%s-S%d", s_csu_comb_slave_info.local_info.p_slave->sn, s_csu_comb_slave_info.p_setting->slave.local_slave_id );
    #endif
        csu_slave_local_info_fresh();

        CSU_COMB_SLAVE_LOG_D( "local slave sn:%s", s_csu_comb_slave_info.local_info.p_slave->sn );

    }else if ( s_csu_comb_slave_info.p_setting->comb_role == CSU_ROLE_JUNCT )
    {
        s_csu_comb_slave_info.local_info.p_junct->valid  = SF_TRUE;
        s_csu_comb_slave_info.local_info.p_junct->online = SF_TRUE;
        strcpy( s_csu_comb_slave_info.local_info.p_junct->sn, (char*)sdk_shm_telemetry_data_get()->sys_version_telemetry_info.sn_version_number ); 
    #if CSU_COMB_SLAVE_MUL_SMU_DEBUG 
        strcat( s_csu_comb_slave_info.local_info.p_junct->sn, "-J0" );
    #endif
        CSU_COMB_SLAVE_LOG_D( "local junction sn:%s", s_csu_comb_slave_info.local_info.p_junct->sn );
    }
    mem_utils_set_bit_val( s_csu_comb_slave_info.p_telematic_data->csu_system_fault_info, 15, 0 );
    mem_utils_set_bit_val( s_csu_comb_slave_info.p_telematic_data->csu_system_fault_info, 16, 0 );
    mem_utils_set_bit_val( s_csu_comb_slave_info.p_telematic_data->csu_system_fault_info, 17, 0 );

    if ( s_csu_comb_slave_info.p_setting->comb_role == CSU_ROLE_SLAVE )
        mem_utils_set_bit_val( s_csu_comb_slave_info.p_telematic_data->csu_system_fault_info, 15, 1 );
    else if ( s_csu_comb_slave_info.p_setting->comb_role == CSU_ROLE_JUNCT )
        mem_utils_set_bit_val( s_csu_comb_slave_info.p_telematic_data->csu_system_fault_info, 17, 1 );

    s_csu_comb_slave_info.run.con_socket = -1;
    s_csu_comb_slave_info.run.online_tm  = user_timer_create( NULL, NULL );
    if (s_csu_comb_slave_info.run.online_tm == NULL)
    {
        CSU_COMB_SLAVE_LOG_E( "%s create online timer error!!!", __FUNCTION__ );
        return;
    }
    user_timer_set_timeout( s_csu_comb_slave_info.run.online_tm   , SLAVE_OFFLINE_TM_MS, false );
    csu_comb_slave_signIn_request();
    
    return;
}

/**
 * @brief  从机连接主机
 * @param  [in] p_master_ip ：主机IP
 * @return 返回socket套接字
 *          大于0：成功
 *          小于0：失败
 * @note   
 */
static int csu_comb_slave_connect( uint8_t *p_master_ip )
{
    char master_ip_str[20] = {0};
    struct sockaddr_in serv_addr;
    struct timeval tv;
    int socket_fd;
    
    sprintf( master_ip_str, "%d.%d.%d.%d",  p_master_ip[0], p_master_ip[1], p_master_ip[2], p_master_ip[3]);

    tv.tv_sec = 1;
    tv.tv_usec = 0;
    memset(&serv_addr,0,sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;                
    serv_addr.sin_port = htons( CSU_COMBIN_TCP_SERVER_PORT ); 

    socket_fd = socket(AF_INET, SOCK_STREAM, 0);
    if ( socket_fd < 0  )
    {
        CSU_COMB_SLAVE_LOG_E( "create socket error!!!" );
        return -1;
    }
    CSU_COMB_SLAVE_LOG_D("master_ip:%s , connect socket fd:%d", master_ip_str, socket_fd);

    if(inet_pton(AF_INET, master_ip_str, &serv_addr.sin_addr) <= 0)
    {
        CSU_COMB_SLAVE_LOG_E("inet_pton error\n");
        close( socket_fd );
        return -2;
    }

    setsockopt(socket_fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    if(connect(socket_fd,(struct sockaddr*)&serv_addr,sizeof(serv_addr)) < 0)
    {
        CSU_COMB_SLAVE_LOG_E("socket connect error\n");
        close( socket_fd );
        return -4;
    }

    return socket_fd;
}

/**
 * @brief  tcp数据发送接口
 * @param  [in] __fd     ：通讯套接字
 * @param  [in] __buf    ：发送数据
 * @param  [in] __n      ：数据长度
 * @param  [in] __flags  ：标志位
 * @return 
 * @note   参照 send接口
 */
ssize_t csu_comb_slave_send ( const void *send_buff, size_t send_len, char *err_str)
{
    size_t ret_len = -1;

    CSU_COMB_SLAVE_TCP_MSG_PRINT( "\r\nslave send:%s", (char*)send_buff );
    if ( s_csu_comb_slave_info.run.con_socket != 0 )
    {
        ret_len = send ( s_csu_comb_slave_info.run.con_socket, send_buff, send_len, 0);
        if ( ret_len != send_len )
        {
            CSU_COMB_SLAVE_LOG_E( "%s\r\n", err_str );
        }
    }
    return ret_len;
}

static void global_comb_info_handle( cJSON *p_root_js )
{
    uint16_t junct_cab_fault = 0;
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();

    uint8_t comb_num = cJSON_GetObjectItem( p_root_js, "ParallelNum" )->valueint;
    if ( comb_num != s_csu_comb_slave_info.p_comb_info->comb_setting.master.comb_num )
    {
        /* 数量不一致，从机同步保存 */
        s_csu_comb_slave_info.p_comb_info->comb_setting.master.comb_num = comb_num;
        sdk_shm_constant_parameter_data_get()->csu_comb_save_setting.master.comb_num = comb_num;
        
        csu_comb_save_setting_t csu_comb_save_setting;
    
        memcpy( &csu_comb_save_setting, &sdk_shm_constant_parameter_data_get()->csu_comb_save_setting, sizeof( csu_comb_save_setting_t ) );
        csu_cfg_comb_cfg_save( &csu_comb_save_setting );
        CSU_COMB_SLAVE_LOG_D( "comb_num save!!! %d", comb_num );
    }
    
    cJSON *p_ParallelList_js = cJSON_GetObjectItem( p_root_js, "ParallelList" );
    if ( p_ParallelList_js != NULL )
    {
        for (size_t i = 0; i < cJSON_GetArraySize( p_ParallelList_js ); i++)
        {
            cJSON *p_dev_info_js = cJSON_GetArrayItem( p_ParallelList_js, i );
            
            if ( p_dev_info_js == NULL )
                break;
            
            if ( cJSON_GetObjectItem( p_dev_info_js, "devtype" )->valueint == 0 )
            {
                /* 从机 */
                int slave_id = cJSON_GetObjectItem( p_dev_info_js, "slaveId" )->valueint;
                csu_node_info_t *p_slave = &s_csu_comb_slave_info.p_comb_info->slave_info[ slave_id - 1 ];

                if ( slave_id == s_csu_comb_slave_info.p_setting->slave.local_slave_id )
                    continue;

                p_slave->real_data.meter_power = cJSON_GetObjectItem( p_dev_info_js, "power" )->valuedouble * 100.0;
                p_slave->online                = cJSON_GetObjectItem( p_dev_info_js, "online" )->valueint;
                sscanf( cJSON_GetObjectItem( p_dev_info_js, "ip" )->valuestring , "%hhu.%hhu.%hhu.%hhu", 
                                                    &p_slave->ip[0], &p_slave->ip[1], &p_slave->ip[2], &p_slave->ip[3]);
                p_slave->real_data.sys_status = cJSON_GetObjectItem( p_dev_info_js, "sysStatus" )->valueint;
                p_slave->real_data.SOC        = cJSON_GetObjectItem( p_dev_info_js, "soc"       )->valueint;
                p_slave->real_data.SOH        = cJSON_GetObjectItem( p_dev_info_js, "soh"       )->valueint;
                p_slave->real_data.bat_vol    = cJSON_GetObjectItem( p_dev_info_js, "batVol"    )->valuedouble * 10;
                p_slave->real_data.bat_curr   = cJSON_GetObjectItem( p_dev_info_js, "batCurr"   )->valuedouble * 10;
            }
            else if ( cJSON_GetObjectItem( p_dev_info_js, "devtype" )->valueint == 1 )
            {
                /* 主机 */
                csu_node_info_t *p_master = &s_csu_comb_slave_info.p_comb_info->master_info;

                p_master->real_data.meter_power = cJSON_GetObjectItem( p_dev_info_js, "power" )->valuedouble * 100;
                p_master->online                = cJSON_GetObjectItem( p_dev_info_js, "online" )->valueint;
                sscanf( cJSON_GetObjectItem( p_dev_info_js, "ip" )->valuestring , "%hhu.%hhu.%hhu.%hhu", 
                                                &p_master->ip[0], &p_master->ip[1], &p_master->ip[2], &p_master->ip[3]);
                p_master->real_data.sys_status = cJSON_GetObjectItem( p_dev_info_js, "sysStatus" )->valueint;
                p_master->real_data.SOC        = cJSON_GetObjectItem( p_dev_info_js, "soc"       )->valueint;
                p_master->real_data.SOH        = cJSON_GetObjectItem( p_dev_info_js, "soh"       )->valueint;
                p_master->real_data.bat_vol    = cJSON_GetObjectItem( p_dev_info_js, "batVol"    )->valuedouble * 10;
                p_master->real_data.bat_curr   = cJSON_GetObjectItem( p_dev_info_js, "batCurr"   )->valuedouble * 10;
            }
        }
    }

    s_csu_comb_slave_info.p_comb_info->global_info.pcc_power       = cJSON_GetObjectItem( p_root_js, "pccMeterPower" )->valuedouble * 100;
    s_csu_comb_slave_info.p_comb_info->global_info.loadPower       = cJSON_GetObjectItem( p_root_js, "loadPower"     )->valuedouble * 100;
    s_csu_comb_slave_info.p_comb_info->global_info.PV_meter.enable = cJSON_GetObjectItem( p_root_js, "pvMeterEnable" )->valueint;
    s_csu_comb_slave_info.p_comb_info->global_info.PV_meter.num    = cJSON_GetObjectItem( p_root_js, "pvNum"         )->valueint;
    s_csu_comb_slave_info.p_comb_info->global_info.PV_meter.power  = cJSON_GetObjectItem( p_root_js, "pvPower"       )->valuedouble * 100;
    s_csu_comb_slave_info.p_comb_info->global_info.SOC             = cJSON_GetObjectItem( p_root_js, "systemSOC"     )->valueint;

    junct_cab_info_t *p_junct_cab_info = s_csu_comb_slave_info.local_info.p_junct;

    cJSON *p_JunctionCabinet_js = cJSON_GetObjectItem( p_root_js, "JunctionCabinet" );
    if ( p_JunctionCabinet_js == NULL )
        return;

    if (   (( s_csu_comb_slave_info.p_setting->comb_role == CSU_ROLE_JUNCT) && ( p_junct_cab_info->meter_dat.enable == SF_FALSE ))
        || ( s_csu_comb_slave_info.p_setting->comb_role == CSU_ROLE_SLAVE) )
    {
        /**
         * 汇流柜没有开启电表功能
         * 角色为从机
         * 接收主机传来的汇流柜信息
         */
        cJSON *p_MeterData_js = cJSON_GetObjectItem( p_JunctionCabinet_js, "MeterData" );

        p_junct_cab_info->meter_dat.a_vol     = cJSON_GetObjectItem( p_MeterData_js, "abVolt" )->valuedouble * 10;
        p_junct_cab_info->meter_dat.b_vol     = cJSON_GetObjectItem( p_MeterData_js, "caVolt" )->valuedouble * 10;
        p_junct_cab_info->meter_dat.c_vol     = cJSON_GetObjectItem( p_MeterData_js, "bcVolt" )->valuedouble * 10;
        p_junct_cab_info->meter_dat.a_curr    = cJSON_GetObjectItem( p_MeterData_js, "aCurr" )->valuedouble * 10;
        p_junct_cab_info->meter_dat.b_curr    = cJSON_GetObjectItem( p_MeterData_js, "bCurr" )->valuedouble * 10;
        p_junct_cab_info->meter_dat.c_curr    = cJSON_GetObjectItem( p_MeterData_js, "cCurr" )->valuedouble * 10;
        p_junct_cab_info->meter_dat.act_power = cJSON_GetObjectItem( p_MeterData_js, "acPower" )->valueint * 100;
    }

    p_junct_cab_info->cabinet_type   = cJSON_GetObjectItem( p_JunctionCabinet_js, "gridVolSystemFlag"       )->valueint;
    p_junct_cab_info->cab_top_tmp    = cJSON_GetObjectItem( p_JunctionCabinet_js, "CabinTopTemperature"     )->valueint;
    p_junct_cab_info->cab_buttom_tmp = cJSON_GetObjectItem( p_JunctionCabinet_js, "CabinBottomTemperature"  )->valueint;
    p_junct_cab_info->cab_humidity   = cJSON_GetObjectItem( p_JunctionCabinet_js, "Humidity"                )->valueint;
    p_junct_cab_info->fan_sta        = cJSON_GetObjectItem( p_JunctionCabinet_js, "FanStatus"               )->valueint;
    p_junct_cab_info->cab_door_sta   = cJSON_GetObjectItem( p_JunctionCabinet_js, "DoorStatus"              )->valueint;
    p_junct_cab_info->cab_flood_sta  = cJSON_GetObjectItem( p_JunctionCabinet_js, "FloodStatus"             )->valueint;
    cJSON *p_cab_fault_js            = cJSON_GetObjectItem( p_JunctionCabinet_js, "FaultStatus"             );
    if(p_cab_fault_js != NULL)
    {
        junct_cab_fault = p_cab_fault_js->valueint;
    }
    // 汇流柜上报故障后置位主柜的汇流柜故障位
    if(junct_cab_fault)
    {
        BIT_SET(p_telematic_data->csu_system_fault_info[2], 2);
    }
    else 
    {
        BIT_CLR(p_telematic_data->csu_system_fault_info[2], 2);
    }

    s_csu_comb_slave_info.p_setting->junct_enable = cJSON_GetObjectItem( p_JunctionCabinet_js, "Enable" )->valueint;
    cJSON *p_con_sta_array_js = cJSON_GetObjectItem( p_JunctionCabinet_js, "ContactorStatus" );
    for (size_t i = 0; i < cJSON_GetArraySize( p_con_sta_array_js ) ; i++)
    {
        p_junct_cab_info->ContactorStatus[i] = cJSON_GetArrayItem( p_con_sta_array_js, i )->valueint;
    }
}

static void csu_comb_signIn_request_send( csu_role_e role )
{
    cJSON *p_root_js = cJSON_CreateObject();
    if ( p_root_js == NULL )    
    {
        return;
    }

    cJSON_AddStringToObject( p_root_js, "cmdtype"  , "signIn"  );
    cJSON_AddNumberToObject( p_root_js, "devtype"  , s_csu_comb_slave_info.p_comb_info->comb_setting.comb_role );
    cJSON_AddStringToObject( p_root_js, "csuSN"    , ( role == CSU_ROLE_SLAVE )? s_csu_comb_slave_info.local_info.p_slave->sn: 
                                                     ( role == CSU_ROLE_JUNCT )? s_csu_comb_slave_info.local_info.p_junct->sn: "0");
    cJSON_AddStringToObject( p_root_js, "protVer"  , CSU_COMBIN_TCP_PROT_VER );
    if ( role == CSU_ROLE_SLAVE )
    {
        cJSON_AddNumberToObject( p_root_js, "slaveId"  , s_csu_comb_slave_info.p_comb_info->comb_setting.slave.local_slave_id );
        cJSON_AddNumberToObject( p_root_js, "battCap"  , s_csu_comb_slave_info.local_info.p_slave->real_data.cluster_cap_energy / 100.0 );
        cJSON_AddNumberToObject( p_root_js, "battRack" , s_csu_comb_slave_info.local_info.p_slave->real_data.cluster_num );
    }

    char *send_str = cJSON_PrintUnformatted( p_root_js );
    if ( send_str == NULL )
    {
        cJSON_Delete( p_root_js );
        return;
    }
    csu_comb_slave_send( send_str, strlen( send_str ), "csu_comb_signIn_request_send error!!!" );

    free( send_str );
    cJSON_Delete( p_root_js );
    return;
}

static void csu_comb_slave_set_online( bool online )
{
    s_csu_comb_slave_info.p_comb_info->master_info.online = online;
    csu_role_e role = s_csu_comb_slave_info.p_setting->comb_role;

    if ( online == SF_TRUE )
    {
        user_timer_set_timeout( s_csu_comb_slave_info.run.online_tm , SLAVE_OFFLINE_TM_MS, false );
        if ( role == CSU_ROLE_SLAVE )
        {
            if ( mem_utils_get_bit_val( s_csu_comb_slave_info.p_telematic_data->csu_system_fault_info, 15 ) == 1 )
            {
                CSU_COMB_SLAVE_LOG_D( "master online" );
                mem_utils_set_bit_val( s_csu_comb_slave_info.p_telematic_data->csu_system_fault_info, 15, 0 );
            }
        }
        else if ( role == CSU_ROLE_JUNCT )
        {
            if ( mem_utils_get_bit_val( s_csu_comb_slave_info.p_telematic_data->csu_system_fault_info, 17 ) == 1 )
            {
                CSU_COMB_SLAVE_LOG_D( "junction online" );
                mem_utils_set_bit_val( s_csu_comb_slave_info.p_telematic_data->csu_system_fault_info, 17, 0 );
            }
        }
    }else{
        if ( role == CSU_ROLE_SLAVE )
        {
            if ( mem_utils_get_bit_val( s_csu_comb_slave_info.p_telematic_data->csu_system_fault_info, 15 ) == 0 )
            {
                CSU_COMB_SLAVE_LOG_D( "master offline" );
                mem_utils_set_bit_val( s_csu_comb_slave_info.p_telematic_data->csu_system_fault_info, 15, 1 );
            }
        }
        else if ( role == CSU_ROLE_JUNCT )
        {
            if ( mem_utils_get_bit_val( s_csu_comb_slave_info.p_telematic_data->csu_system_fault_info, 17 ) == 0 )
            {
                CSU_COMB_SLAVE_LOG_D( "junction offline" );
                mem_utils_set_bit_val( s_csu_comb_slave_info.p_telematic_data->csu_system_fault_info, 17, 1 );
            }
        }
    }
}