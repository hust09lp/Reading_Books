#ifndef _CSU_CFG_H_
#define _CSU_CFG_H_

#define CSU_COMBIN_TCP_SERVER_PORT        3001

#define CSU_COMBIN_TCP_PROT_VER          "1.5"

#define SLAVE_HEARTBEAT_INV_TM_MS         5000
#define SLAVE_OFFLINE_TM_MS               ( SLAVE_HEARTBEAT_INV_TM_MS * 6 )

#define SLAVE_SIGIN_INV_TM_MS             10000     //< 掉线情况下注册间隔时间
#define SLAVE_REAL_DAT_REPORT_INV_TM_MS   10000     //< 数据上报时间间隔



#endif
