#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include "data_shm.h"
#include "sdk_shm.h"
#include "errors.h"
#include "sofar_log.h"
#include "mongoose.h"
#include "cJSON.h"
#include "cJSON_ext.h"
#include "app_common.h"
#include "mem_utils.h"
#include "json_utils.h"

#include "csu_cfg.h"
#include "csu_comb_master.h"
#include "csu_cfg_store.h"
#include "csu_comb_type.h"
#include "user_timer.h"
#include "utility_tool.h"


typedef struct 
{
    csu_role_e  role;
    dev_idx_t   salveIdx;
} csu_dev_pos_t;

static pthread_t s_csu_master_pthread = 0;
static struct mg_connection *s_p_nc = NULL;
static struct mg_mgr s_mgr;

#define EMS_ALLOC_POWER_REPORT_INV_TM_MS        (10 * 1000)

#if(0)
#define CSU_COMB_MASTER_TCP_INFO_PRINT( format, ...) do{ log_i((const int8_t*)format, __VA_ARGS__ ); }while(0)
#else
#define CSU_COMB_MASTER_TCP_INFO_PRINT(...) do{}while(0)
#endif

#if (0)
#define CSU_COMB_MASTER_TCP_MSG_PRINT(...) do{ printf(__VA_ARGS__);printf("\r\n"); }while(0)
#else
#define CSU_COMB_MASTER_TCP_MSG_PRINT(...) do{}while(0)
#endif

#if (1)
#define CSU_COMB_MASTER_LOG_D(...) do{ log_i((const int8_t*)__VA_ARGS__);printf("\r\n"); }while(0)
#else
#define CSU_COMB_MASTER_LOG_D(...) do{}while(0)
#endif

#define CSU_COMB_MASTER_LOG_E(...) do{ printf("[ERROR]"); printf(__VA_ARGS__);printf("\r\n"); }while(0)

typedef struct 
{
    user_timer_hd           online_tm;     // 在线超时定时器
    struct mg_connection    *p_net_con;          // 网络连接接口
} slave_run_info_t; 

typedef struct
{
    bool                enable;
    csu_combine_info_t  *p_comb_info;                               // 指向并柜共享内存
    telematic_data_t    *p_telematic_data;
    
    // char                sn[50];                                    
    uint8_t             signIn_slave_num;                           // 已注册从机数量
    slave_run_info_t    slave_run_info[ CSU_COMB_MAX_SLAVE_CNT ];   // 
    slave_run_info_t    junct_run_info;                             // 
} csu_comb_master_manage_info_t;
#define SYNC_ACTION_ARRAY_LEN     (5)
const char* sync_action_array[SYNC_ACTION_ARRAY_LEN] =
{
    "off",
    "on",
    "energy_save_on",
    "energy_save_off",
    "energy_save_stop",
};

static csu_comb_master_manage_info_t s_master_manage_info;

static bool csu_master_slave_signIn_handle( struct mg_connection *p_nc,  cJSON *p_root_js ); 
static void csu_master_slave_real1_handle( cJSON *p_root_js );
static void csu_master_junct_real1_handle( cJSON *p_root_js );
static void csu_master_slave_heartBeat_handle( cJSON *p_root_js );
static csu_dev_pos_t _csu_master_search_dev_pos( char *csu_sn_str );
// static dev_idx_t csu_master_alloc_new_slave_id( char *csu_sn_str, bool *p_create );
static void csu_master_fill_common_json_item( cJSON *p_root_js, char *cmd_str, char *csu_sn_str );
static void csu_master_dev_online_flag_refresh( void );

static void csu_master_task_loop( void );
static void csu_master_slave_online_monitor( void );
static void csu_master_slave_power_sta_monitor( void );
static void csu_master_ems_alloct_power_monitor( void );

static void csu_master_ems_alloct_power_report( void );
static void csu_master_module_data_init(void);
// static void csu_master_slave_node_enable( dev_idx_t slave_id, char *csu_sn_str );
static bool csu_master_mg_send(struct mg_connection *c, const void *buf, size_t len);
static sf_ret_t csu_master_slave_power_sta_sync( dev_idx_t sync_slave_idx , uint8_t action);

static void local_data_fresh_task_loop( void );
static void global_comb_info_sync_task_loop( void );
static void global_comb_info_sync( void );

static void _csu_master_dev_release( char *csu_sn_str );
static bool csu_master_alloc_new_dev( csu_dev_pos_t allow_csu_dev_pos, char *csu_sn_str, struct mg_connection *p_nc );
static void csu_comb_master_close_slave_tcp_con( struct mg_connection *p_nc );
static void csu_master_dev_set_online_sta( csu_role_e dev_role, dev_idx_t slave_idx , ol_sta_e online_sta );
static void tcp_json_handle( struct mg_connection *p_nc, cJSON *p_root_js );

/**
 * @brief   TCP数据处理
 * @param   [in] p_data:数据内容
 * @param   [in] data_len:数据长度
 * @note
 * @return
 */
static void tcp_data_handle(struct mg_connection *p_nc, uint8_t *p_data, uint16_t data_len)
{
    CSU_COMB_MASTER_TCP_INFO_PRINT( "tcp data from [%d.%d.%d.%d], data len:%d",  p_nc->rem.ip[0],p_nc->rem.ip[1],p_nc->rem.ip[2],p_nc->rem.ip[3], data_len );
    CSU_COMB_MASTER_TCP_MSG_PRINT( "\r\n[%d.%d.%d.%d]recv data:%s", p_nc->rem.ip[0],p_nc->rem.ip[1],p_nc->rem.ip[2],p_nc->rem.ip[3],  p_data );

    int remain_dat_len = data_len;
    char *p_js_str       = (char*)p_data;
    char *p_next_js_str  = NULL;

    while ( remain_dat_len > 0 )
    {
        cJSON *p_root_js = cJSON_ParseWithLengthOpts( p_js_str, remain_dat_len, (const char **)&p_next_js_str, 0);

        if ( p_root_js != NULL )
        {
            tcp_json_handle( p_nc, p_root_js );
        }else{
            CSU_COMB_MASTER_LOG_D( "p_root_js == NULL, remain_dat_len:%d!!!", remain_dat_len );
            return;
        }

        if ( p_next_js_str == NULL )
        {
            break;
        }

        CSU_COMB_MASTER_TCP_MSG_PRINT( "p_next_js_str:%s\r\n",  p_next_js_str );
        remain_dat_len = remain_dat_len - (p_next_js_str - p_js_str);
        p_js_str = p_next_js_str;
        p_next_js_str = NULL;
    }
}

static void tcp_json_handle( struct mg_connection *p_nc, cJSON *p_root_js )
{
    cJSON *p_cmd_js     = cJSON_GetObjectItem( p_root_js, "cmdtype" );
    cJSON *p_devtype_js = cJSON_GetObjectItem( p_root_js, "devtype" );
    if ( p_cmd_js == NULL || p_devtype_js == NULL )
    {
        CSU_COMB_MASTER_LOG_E( "p_cmd_js == NULL || p_devtype_js == NULL!!!" );
        return;
    }
    CSU_COMB_MASTER_TCP_INFO_PRINT( "cmdtype:%s, devtype:%d", p_cmd_js->valuestring, p_devtype_js->valueint );

    csu_role_e role = p_devtype_js->valueint;
    
    if ( role != CSU_ROLE_JUNCT && role != CSU_ROLE_SLAVE )
    {
        CSU_COMB_MASTER_LOG_E( "role != CSU_ROLE_JUNCT && role != CSU_ROLE_SLAVE!!!" );
        return;
    }
    if (   ( s_master_manage_info.p_comb_info->comb_setting.comb_enable != 1)
        && ( role == CSU_ROLE_JUNCT ))
    {
        /* 未开启并柜使能，拒绝注册汇流柜 */
        CSU_COMB_MASTER_LOG_E( "Refuse CSU_ROLE_JUNCT!!!" );
        return;
    }

    if ( strcmp( p_cmd_js->valuestring, "signIn" ) == 0 )
    {
        csu_master_slave_signIn_handle( p_nc, p_root_js );
    } 
    else if ( strcmp( p_cmd_js->valuestring, "real1" ) == 0 )
    {
        if ( role == CSU_ROLE_SLAVE )
            csu_master_slave_real1_handle( p_root_js );
        else if ( role == CSU_ROLE_JUNCT )
            csu_master_junct_real1_handle( p_root_js );
    } 
    else if ( strcmp( p_cmd_js->valuestring, "heartbeat" ) == 0 )
    {
        csu_master_slave_heartBeat_handle( p_root_js );
    } 
    cJSON_Delete( p_root_js );
}
/**
 * @brief   网络事件回调
 * @param   [in] p_nc:网络连接信息
 * @param   [in] ev:消息类别
 * @param   [in] p_ev_data:数据内容
 * @note
 * @return
 */
static void ev_handler(struct mg_connection *p_nc, int ev, void *p_ev_data)
{
    struct mg_iobuf *p_recv = NULL;

    switch(ev)
    {
        case MG_EV_ACCEPT:
            CSU_COMB_MASTER_LOG_D("client connected");
            break;

        case MG_EV_CLOSE:
            CSU_COMB_MASTER_LOG_D("client close");
            csu_comb_master_close_slave_tcp_con( p_nc );
            break;

        case MG_EV_READ:
            p_recv = &p_nc->recv;
            tcp_data_handle(p_nc, p_recv->buf, p_recv->len);
            memset(p_recv->buf, 0, p_recv->len);
            p_recv->len = 0;
            break;

        default:
            break;
    }
}


/**
 * @brief   tcp server服务线程
 * @param   [in] arg
 * @note
 * @return
 */
void *csu_master_service(void *arg)
{
    char tcp_server_addr[50];

    sprintf( tcp_server_addr, "0.0.0.0:%d", CSU_COMBIN_TCP_SERVER_PORT );

	mg_mgr_init(&s_mgr);
	s_p_nc = mg_listen(&s_mgr, tcp_server_addr, ev_handler, NULL);
	if(s_p_nc == NULL)
	{
		CSU_COMB_MASTER_LOG_D("init net connection failed");
		mg_mgr_free( &s_mgr );
		return NULL;
	}

	while(1)
	{
        csu_master_task_loop();
		mg_mgr_poll(&s_mgr, 100);
        usleep(1000);
	}
	mg_mgr_free(&s_mgr);
}

/**
 * @brief   CSU主机模块 退出
 * @param
 * @note
 * @return
 */
void csu_master_module_exit(void)
{
    CSU_COMB_MASTER_LOG_D("%s", __FUNCTION__);
    if ( s_csu_master_pthread != 0 )
    {
        /* 退出线程 */
        pthread_cancel( s_csu_master_pthread );
        pthread_join( s_csu_master_pthread, NULL );
        s_csu_master_pthread = 0;
    }

    if ( s_p_nc != NULL )
    {
        mg_mgr_free( &s_mgr );
        s_p_nc = NULL;
    }

    /* 回收所有资源 */
    slave_run_info_t *p_slave_run_info  = s_master_manage_info.slave_run_info;
    csu_node_info_t  *p_csu_node_info   = s_master_manage_info.p_comb_info->slave_info;  
    for (size_t i = 0; i < CSU_COMB_MAX_SLAVE_CNT; i++)
    {
        if ( p_csu_node_info[i].valid == SF_TRUE )
        {
            if ( p_slave_run_info[i].online_tm != NULL) 
            {
                user_timer_delete( p_slave_run_info[i].online_tm );
            }
        }
    }

    slave_run_info_t *p_junct_run_info  = &s_master_manage_info.junct_run_info;
    junct_cab_info_t *p_junct_node_info = &s_master_manage_info.p_comb_info->junct_info;

    if ( p_junct_node_info->valid == SF_TRUE 
        || p_junct_run_info->online_tm != NULL)
    {
        user_timer_delete( p_junct_run_info->online_tm );
    }

    /* 复位所有数据 */
    mem_utils_set_bit_val( s_master_manage_info.p_telematic_data->csu_system_fault_info, 16, 0 );
    s_master_manage_info.p_comb_info->fast_power_enable = 0;
    memset( &s_master_manage_info.p_comb_info->slave_info, 0, sizeof( s_master_manage_info.p_comb_info->slave_info ) );
    memset( &s_master_manage_info.slave_run_info, 0, sizeof(s_master_manage_info.slave_run_info) );
    s_master_manage_info.enable = SF_FALSE;
}

/**
 * @brief   CSU主机模块初始化
 * @param
 * @note
 * @return
 */
void csu_master_module_init(void)
{
    CSU_COMB_MASTER_LOG_D("%s", __FUNCTION__);
    csu_master_module_data_init();

	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	if(pthread_create(&s_csu_master_pthread, &attr, csu_master_service, NULL) != 0)
	{
		perror("pthread_create csu master service");
	}
    CSU_COMB_MASTER_LOG_D( "s_csu_master_pthread:%d", (int)s_csu_master_pthread );
	pthread_attr_destroy(&attr);

    s_master_manage_info.enable = SF_TRUE;
}

/**
 * @brief  主机模块数据初始化
 * @param  [in] 无
 * @return 无
 */
static void csu_master_module_data_init(void)
{
    memset( &s_master_manage_info, 0, sizeof( csu_comb_master_manage_info_t ) );

    s_master_manage_info.p_telematic_data  = sdk_shm_telematic_data_get();
    s_master_manage_info.p_comb_info       = sdk_shm_csu_combine_data_get();

    if (s_master_manage_info.p_comb_info->comb_setting.master.comb_num == 0)
        s_master_manage_info.p_comb_info->comb_setting.master.comb_num = 1;

    memset( &s_master_manage_info.p_comb_info->master_info  , 0, sizeof( s_master_manage_info.p_comb_info->master_info ) );
    memset( &s_master_manage_info.p_comb_info->slave_info   , 0, sizeof( s_master_manage_info.p_comb_info->slave_info ) );
    memset( &s_master_manage_info.p_comb_info->junct_info   , 0, sizeof( s_master_manage_info.p_comb_info->junct_info ) );
    memset( &s_master_manage_info.p_comb_info->global_info  , 0, sizeof( s_master_manage_info.p_comb_info->global_info ) );

    /* 开机初始化数据 */
    strcpy( s_master_manage_info.p_comb_info->master_info.sn, (char*)sdk_shm_telemetry_data_get()->sys_version_telemetry_info.sn_version_number ); 
    s_master_manage_info.p_comb_info->master_info.valid  = SF_TRUE;
    s_master_manage_info.p_comb_info->master_info.online = SF_TRUE;

    mem_utils_set_bit_val( s_master_manage_info.p_telematic_data->csu_system_fault_info, 15, 0 );

    /* 需要并从机时先提示从机失联 */
    if (s_master_manage_info.p_comb_info->comb_setting.master.comb_num > 1)
        mem_utils_set_bit_val( s_master_manage_info.p_telematic_data->csu_system_fault_info, 16, 1 );
    else
        mem_utils_set_bit_val( s_master_manage_info.p_telematic_data->csu_system_fault_info, 16, 0 );

    /* 需要并汇流柜时先提示汇流柜失联 */
    if (s_master_manage_info.p_comb_info->comb_setting.junct_enable == 1)
        mem_utils_set_bit_val( s_master_manage_info.p_telematic_data->csu_system_fault_info, 17, 1 );
    else
        mem_utils_set_bit_val( s_master_manage_info.p_telematic_data->csu_system_fault_info, 17, 0 );

    memset( &s_master_manage_info.p_comb_info->slave_info, 0, sizeof(s_master_manage_info.p_comb_info->slave_info) );

    csu_master_save_t csu_master_save = { 0 };
    if ( SF_OK != csu_cfg_master_info_restore( &csu_master_save ))
    {
        /* 读取失败，同步系统状态再保存 */
        CSU_COMB_MASTER_LOG_E( "csu master restore error,set defalut!!!" );
        memset( &csu_master_save, 0, sizeof( csu_master_save ) );
        csu_master_save.power_on = ( sdk_shm_telemetry_data_get()->sys_version_telemetry_info.csu_sys_state == 2 )? SF_TRUE: SF_FALSE;
        csu_cfg_master_info_save( &csu_master_save );
    }
    s_master_manage_info.p_comb_info->usr_setting.comb_power_on = csu_master_save.power_on? 1 : 0;

}

/**
 * @brief  保存主从机系统电源状态
 * @param  [in] power_sta： 电源状态【true：开  false: 关】
 * @return SF_OK：成功   非SF_OK：失败
 * @note   
 */
sf_ret_t csu_master_save_sys_power_sta( bool power_sta )
{
    csu_master_save_t csu_master_save;
    sf_ret_t ret;

    memset( &csu_master_save, 0, sizeof(csu_master_save_t) );
    ret = csu_cfg_master_info_restore( &csu_master_save );
    if ( ret != SF_OK )
    {
        memset( &csu_master_save, 0, sizeof(csu_master_save_t) );
        csu_master_save.power_on = power_sta;
        return csu_cfg_master_info_save( &csu_master_save );
    }
    
    if ( csu_master_save.power_on != power_sta )
    {
        csu_master_save.power_on = power_sta;
        return csu_cfg_master_info_save( &csu_master_save );
    }

    return SF_OK;
}

/**
 * @brief  设置主从机系统电源状态并保存
 * @param  [in] power_sta： 电源状态【true：开  false: 关】
 * @return SF_OK：成功   非SF_OK：失败
 * @note   
 */
sf_ret_t csu_master_set_sys_power_sta( bool power_sta )
{
    csu_master_save_t csu_master_save = {0};

    if ( s_master_manage_info.enable == SF_FALSE )
    {
        return SF_ERR_NDEF;
    }

    if ( s_master_manage_info.p_comb_info->usr_setting.comb_power_on != power_sta )
    {
        s_master_manage_info.p_comb_info->usr_setting.comb_power_on = power_sta;
        csu_master_save.power_on = power_sta;
        // csu_cfg_master_info_save( &csu_master_save );
        csu_master_slave_power_sta_sync( DEV_IDX_ALL, s_master_manage_info.p_comb_info->usr_setting.comb_power_on );
    }

    return SF_OK;
}

/**
 * @brief  申请新slave id
 * @param  [in]  csu_sn_str ： 要申请 slave id 的SN字符串
 * @param  [out] p_create   ： 当前slave id 是否属于新建
 * @return 返回 slave id ，如为 DEV_IDX_INVALID 则无效
 * @note   
 */
static bool csu_master_alloc_new_dev( csu_dev_pos_t allow_csu_dev_pos, char *csu_sn_str, struct mg_connection *p_nc )   
{
    /* 查看节点是否存在 */
    // csu_dev_pos_t last_pos = _csu_master_search_dev_pos( csu_sn_str );

    // /* 查看节点位置是否相同 */
    // if ( last_pos.role == CSU_ROLE_SLAVE || last_pos.role == CSU_ROLE_JUNCT )
    // {
    //     if (   last_pos.role     == allow_csu_dev_pos.role
    //         && last_pos.salveIdx == allow_csu_dev_pos.salveIdx )
    //     {
    //         /* 相同直接返回 */
    //         return SF_TRUE; 
    //     }
    //     /* 不相同则释放 */
    // }

    _csu_master_dev_release( csu_sn_str );

    /* 占领位置 */
    slave_run_info_t *p_run_info = NULL;
    if ( allow_csu_dev_pos.role == CSU_ROLE_JUNCT )
    {
        if ( s_master_manage_info.p_comb_info->junct_info.online  ) 
        {
            /* 位置被占用且在线，分配失败 */        
            CSU_COMB_MASTER_LOG_E( "other junction cabinet exsit!!!" );
            return SF_FALSE;
        }
        
        p_run_info = &s_master_manage_info.junct_run_info;

        /* 占领位置 */
        junct_cab_info_t *p_junct_cab_info = &s_master_manage_info.p_comb_info->junct_info;

        strcpy( p_junct_cab_info->sn, csu_sn_str );
        memcpy( p_junct_cab_info->ip, &p_nc->rem.ip[0] , sizeof(p_junct_cab_info->ip));
        p_junct_cab_info->online = SF_TRUE;
        p_junct_cab_info->valid = SF_TRUE; 

    } else if ( allow_csu_dev_pos.role == CSU_ROLE_SLAVE )
    {
        dev_idx_t slaveIdx = allow_csu_dev_pos.salveIdx;
        csu_node_info_t *p_slave = &s_master_manage_info.p_comb_info->slave_info[ slaveIdx ];

        /* 位置被占用且在线，分配失败 */
        if ( p_slave->online )
        {
            CSU_COMB_MASTER_LOG_E( "other slave cabinet exsit!!!" );
            return SF_FALSE;
        }
        /* 占领位置 */
        p_run_info = &s_master_manage_info.slave_run_info[ slaveIdx ];

        strcpy( p_slave->sn, csu_sn_str );
        memcpy( p_slave->ip, &p_nc->rem.ip[0], sizeof(p_slave->ip));
        p_slave->online = SF_TRUE;
        p_slave->valid = SF_TRUE;
        // CSU_COMB_MASTER_LOG_D( "slave id:%d online", allow_csu_dev_pos.salveIdx );
    }

    if ( p_run_info->p_net_con != NULL )
    {
        /* 新连接，则把原有连接关闭 */
        // mg_close_conn( s_master_manage_info.slave_run_info[ csu_idx ].p_net_con );
    }
    /* 更新通讯链接 */
    p_run_info->p_net_con = p_nc;
    /* 创建资源，刷新数据 */
    p_run_info->online_tm = user_timer_create( NULL, NULL );
    user_timer_set_timeout( p_run_info->online_tm, SLAVE_OFFLINE_TM_MS, false );
    user_timer_refresh( p_run_info->online_tm );
    csu_master_dev_online_flag_refresh();
    
    return SF_TRUE;
}

// /**
//  * @brief  申请新slave id
//  * @param  [in]  csu_sn_str ： 要申请 slave id 的SN字符串
//  * @param  [out] p_create   ： 当前slave id 是否属于新建
//  * @return 返回 slave id ，如为 DEV_IDX_INVALID 则无效
//  * @note   
//  */
// static dev_idx_t csu_master_alloc_new_slave_id(  char *csu_sn_str, bool *p_create )   
// {
//     dev_idx_t new_slave_id = csu_master_search_slave_id( csu_sn_str );

//     if ( new_slave_id != DEV_IDX_INVALID )
//     {
//         /* 列表中已存在，无需再次申请 */
//         *p_create = SF_FALSE;
//         return new_slave_id;
//     }

//     /* 搜索未使用节点 */
//     for (size_t i = 0; i < (s_master_manage_info.p_comb_info->comb_setting.master.comb_num - 1); i++)
//     {
//         csu_node_info_t *p_slave_info       = &s_master_manage_info.p_comb_info->slave_info[i];

//         if ( p_slave_info->valid == SF_FALSE )
//         {
//             new_slave_id = i;
//             csu_master_slave_node_enable( new_slave_id, csu_sn_str );
//             s_master_manage_info.signIn_slave_num++;
//             *p_create = SF_TRUE;
//             break;
//         }
//     }

//     if ( new_slave_id == DEV_IDX_INVALID )
//     {
//         CSU_COMB_MASTER_LOG_E( "alloc new slave id error!!!" );
//     }

//     return new_slave_id;
// }

// /**
//  * @brief  根据设备SN查找对应的 slave id
//  * @param  [in] csu_sn_str：设备SN字符串
//  * @return 返回 对应的slave id
//  *         DEV_IDX_INVALID：未查找到对应的索引
//  */
// static dev_idx_t csu_master_search_slave_id( char *csu_sn_str )   
// {
//     dev_idx_t csu_idx = DEV_IDX_INVALID;

//     for (size_t i = 0; i < (s_master_manage_info.p_comb_info->comb_setting.master.comb_num - 1); i++)
//     {
//         csu_node_info_t *p_slave_info = &s_master_manage_info.p_comb_info->slave_info[i];

//         if ( p_slave_info->valid == SF_FALSE )
//             break;
        
//         if ( strcmp( p_slave_info->sn, csu_sn_str ) == 0 )
//         {
//             csu_idx = i;
//             break;
//         }
//     }

//     return csu_idx;
// }


static void _csu_master_dev_release( char *csu_sn_str )   
{
    csu_dev_pos_t csu_dev_pos = _csu_master_search_dev_pos( csu_sn_str );

    if ( csu_dev_pos.role == CSU_ROLE_JUNCT )
    {
        if ( s_master_manage_info.junct_run_info.p_net_con != NULL)
        {
            /* 新连接，则把原有连接关闭 */
            // mg_close_conn( s_master_manage_info.slave_run_info[ csu_idx ].p_net_con );
        }
        s_master_manage_info.junct_run_info.p_net_con = NULL;
        memset( &s_master_manage_info.p_comb_info->junct_info, 0, sizeof( junct_cab_info_t ));
    }
    else if ( csu_dev_pos.role == CSU_ROLE_SLAVE )
    {
        slave_run_info_t *p_slave_run_info = &s_master_manage_info.slave_run_info[ csu_dev_pos.salveIdx ];

        if ( p_slave_run_info->p_net_con != NULL)
        {
            /* 新连接，则把原有连接关闭 */
            // mg_close_conn( s_master_manage_info.slave_run_info[ csu_idx ].p_net_con );
        }
        p_slave_run_info->p_net_con = NULL;

        csu_node_info_t *p_csu_node_info = &s_master_manage_info.p_comb_info->slave_info[ csu_dev_pos.salveIdx ];
        memset( p_csu_node_info, 0, sizeof( csu_node_info_t ) );
    }
}

static csu_dev_pos_t _csu_master_search_dev_pos( char *csu_sn_str )   
{
    csu_dev_pos_t csu_dev_pos = { .role     = CSU_ROLE_INVALID,
                                  .salveIdx = DEV_IDX_INVALID };

    if ( 0 == strcmp( s_master_manage_info.p_comb_info->master_info.sn, csu_sn_str ))
    {
        csu_dev_pos.role = CSU_ROLE_MASTER;
        return csu_dev_pos;
    }

    if ( 0 == strcmp( s_master_manage_info.p_comb_info->junct_info.sn, csu_sn_str ))
    {
        csu_dev_pos.role = CSU_ROLE_JUNCT;
        return csu_dev_pos;
    }

    dev_idx_t csu_idx = DEV_IDX_INVALID;

    for (size_t i = 0; i < (s_master_manage_info.p_comb_info->comb_setting.master.comb_num - 1); i++)
    {
        csu_node_info_t *p_slave_info = &s_master_manage_info.p_comb_info->slave_info[i];

        if ( p_slave_info->valid == SF_FALSE )
            break;
        
        if ( strcmp( p_slave_info->sn, csu_sn_str ) == 0 )
        {
            csu_idx = i;
            break;
        }
    }

    if ( csu_idx != DEV_IDX_INVALID ) 
    {
        csu_dev_pos.role     = CSU_ROLE_SLAVE;
        csu_dev_pos.salveIdx = csu_idx;
    }

    return csu_dev_pos;
}


/**
 * @brief  从机注册消息处理
 * @param  [in] p_nc      ： 从机网络连接
 * @param  [in] p_root_js ： 根节点json数据
 * @return 无
 * @note   
 */
static bool csu_master_slave_signIn_handle( struct mg_connection *p_nc,  cJSON *p_root_js )   
{
    cJSON *p_sn_js       = cJSON_GetObjectItem( p_root_js, "csuSn" );
    cJSON *p_devtype_js  = cJSON_GetObjectItem( p_root_js, "devtype" );
    cJSON *p_protVer_js  = cJSON_GetObjectItem( p_root_js, "protVer" );

    /*----------------------参数合法性检测--------------------------*/
    if ( p_devtype_js == NULL || p_protVer_js == NULL || p_sn_js == NULL )
    {
        CSU_COMB_MASTER_LOG_E( "p_devtype_js == NULL || p_protVer_js == NULL || p_sn_js == NULL" );
        return SF_FALSE;
    }

    if (   p_devtype_js->valueint != CSU_ROLE_SLAVE
        && p_devtype_js->valueint != CSU_ROLE_JUNCT )
    {
        CSU_COMB_MASTER_LOG_E( "sigin devtype error!!!" );
        return SF_FALSE;
    }

    if ( (s_master_manage_info.p_comb_info->comb_setting.junct_enable == SF_FALSE) 
      && ( p_devtype_js->valueint == CSU_ROLE_JUNCT ) )
    {
        CSU_COMB_MASTER_LOG_E( "junct_enable == SF_FALSE , dev type:CSU_ROLE_JUNCT!!!" );
        return SF_FALSE;
    }

    if ( 0 != strcmp( p_protVer_js->valuestring, CSU_COMBIN_TCP_PROT_VER ))
    {
        CSU_COMB_MASTER_LOG_E( "tcp protocol ver not match!!!" );
        return SF_FALSE;
    }

    cJSON *p_battCap_js  = NULL;
    cJSON *p_battRack_js = NULL;
    cJSON *p_slaveId_js = NULL;
    if ( p_devtype_js->valueint == CSU_ROLE_SLAVE )
    {
        p_slaveId_js = cJSON_GetObjectItem( p_root_js, "slaveId" );
        p_battCap_js  = cJSON_GetObjectItem( p_root_js, "battCap" );
        p_battRack_js = cJSON_GetObjectItem( p_root_js, "battRack" );
        if ( p_battCap_js  == NULL || p_battRack_js == NULL || p_slaveId_js == NULL )
        {
            CSU_COMB_MASTER_LOG_E( "p_battCap_js  == NULL || p_battRack_js == NULL || p_slaveId_js == NULL!!!" );
            return SF_FALSE;
        }
        if (!(   p_slaveId_js->valueint >= CSU_COMB_START_SLAVE_ID 
              && p_slaveId_js->valueint <= CSU_COMB_END_SLAVE_ID  ))
        {
            CSU_COMB_MASTER_LOG_E( "p_slaveId_js.val out of range!!!" );
            return SF_FALSE;
        }
    }

    csu_dev_pos_t csu_dev_pos = {.role = CSU_ROLE_INVALID , .salveIdx = DEV_IDX_INVALID};
    csu_dev_pos.role     = p_devtype_js->valueint;
    if ( csu_dev_pos.role == CSU_ROLE_SLAVE )
        csu_dev_pos.salveIdx = p_slaveId_js->valueint - 1;
        
    if ( SF_FALSE == csu_master_alloc_new_dev( csu_dev_pos , p_sn_js->valuestring, p_nc ))
    {
        CSU_COMB_MASTER_LOG_E( "csu_master_alloc_new_dev errorr!!!" );
        return SF_FALSE;
    }

    if ( csu_dev_pos.role == CSU_ROLE_SLAVE )
    {
         s_master_manage_info.p_comb_info->slave_info[ csu_dev_pos.salveIdx ].real_data.cluster_cap_energy = p_battCap_js->valuedouble * 100.0;
         s_master_manage_info.p_comb_info->slave_info[ csu_dev_pos.salveIdx ].real_data.cluster_num = p_battRack_js->valueint;
    }

    cJSON *p_rep_js = cJSON_CreateObject();
    if ( p_rep_js == NULL )
    {
        return SF_FALSE;
    }

    csu_master_fill_common_json_item( p_rep_js, "signIn", s_master_manage_info.p_comb_info->master_info.sn );
    cJSON_AddNumberToObject( p_rep_js, "result"  , 1 );
    cJSON_AddNumberToObject( p_rep_js, "csuNum"  , s_master_manage_info.p_comb_info->comb_setting.master.comb_num );

    char *p_reply_str = cJSON_PrintUnformatted( p_rep_js );
    if ( p_rep_js == NULL )
    {
        cJSON_Delete( p_rep_js );
        return SF_FALSE;
    }
    csu_master_mg_send( p_nc, p_reply_str, strlen( p_reply_str ) );
    
    cJSON_Delete( p_rep_js );
    free( p_reply_str );

    if ( p_devtype_js->valueint == CSU_ROLE_SLAVE )
    {
        csu_master_slave_power_sta_sync( p_slaveId_js->valueint - 1, s_master_manage_info.p_comb_info->usr_setting.comb_power_on );
    }
    return SF_TRUE;
}

/**
 * @brief  json 数据填充相同字段数据
 * @param  [in] p_root_js  : 根节点json
 * @param  [in] cmd_str    : 命令字符串
 * @param  [in] csu_sn_str : 设备SN
 * @return 无
 * @note   
 */
static void csu_master_fill_common_json_item( cJSON *p_root_js, char *cmd_str, char *csu_sn_str )   
{
    // uint8_t *p_ip = s_master_manage_info.p_comb_info->comb_setting.local_ip;
    // char ip_str[20] = {0};

    // sprintf( ip_str, "%d.%d.%d.%d", p_ip[0], p_ip[1], p_ip[2], p_ip[3] );
    cJSON_AddNumberToObject( p_root_js, "devtype", 1 );
    // cJSON_AddStringToObject( p_root_js, "csuIp", ip_str );
    cJSON_AddStringToObject( p_root_js, "csuSn", csu_sn_str );
    cJSON_AddStringToObject( p_root_js, "cmdtype", cmd_str );
}

static void csu_master_junct_real1_handle( cJSON *p_root_js )   
{
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();
    uint16_t junct_cab_fault = 0;

    cJSON *p_sn_js = cJSON_GetObjectItem( p_root_js, "csuSn" );
    if ( p_sn_js == NULL || p_telematic_data == NULL )
    {
        return;
    }

    if ( 0 != strcmp( s_master_manage_info.p_comb_info->junct_info.sn, p_sn_js->valuestring ))
    {
        CSU_COMB_MASTER_LOG_E( "recv real1 sn is not match!!!" );
        return;
    }

    cJSON *p_data_js = cJSON_GetObjectItem( p_root_js, "data" );
    if ( p_data_js == NULL )
    {
        return;
    }
    
    junct_cab_info_t *p_junct = &s_master_manage_info.p_comb_info->junct_info;

    p_junct->meter_dat.enable = cJSON_GetObjectItem( p_data_js, "meterEnable" )->valueint;
    p_junct->cabinet_type     = cJSON_GetObjectItem( p_data_js, "gridVolSystemFlag" )->valueint;
    p_junct->cab_top_tmp      = cJSON_GetObjectItem( p_data_js, "CabinTopTemperature" )->valueint;
    p_junct->cab_buttom_tmp   = cJSON_GetObjectItem( p_data_js, "CabinBottomTemperature" )->valueint;
    p_junct->cab_humidity     = cJSON_GetObjectItem( p_data_js, "Humidity" )->valueint;
    p_junct->cab_door_sta     = cJSON_GetObjectItem( p_data_js, "DoorStatus" )->valueint;
    p_junct->cab_flood_sta    = cJSON_GetObjectItem( p_data_js, "FloodStatus" )->valueint;
    p_junct->fan_sta          = cJSON_GetObjectItem( p_data_js, "FanStatus" )->valueint;
    cJSON *p_cab_fault_js             = cJSON_GetObjectItem( p_data_js, "FaultStatus"             );
    if(p_cab_fault_js != NULL)
    {
        junct_cab_fault = p_cab_fault_js->valueint;
    }
   
    // 汇流柜上报故障后置位主柜的汇流柜故障位
    if(junct_cab_fault)
    {
        BIT_SET(p_telematic_data->csu_system_fault_info[2], 2);
    }
    else 
    {
        BIT_CLR(p_telematic_data->csu_system_fault_info[2], 2);
    }
    
    if (p_junct->meter_dat.enable == 1)
    {
        cJSON *p_meter_dat_js = cJSON_GetObjectItem( p_data_js, "meterData" );
        if ( p_meter_dat_js == NULL )
        {
            return;
        }
        p_junct->meter_dat.a_vol     = cJSON_GetObjectItem( p_meter_dat_js, "abVolt" )->valueint * 10;
        p_junct->meter_dat.b_vol     = cJSON_GetObjectItem( p_meter_dat_js, "caVolt" )->valueint * 10;
        p_junct->meter_dat.c_vol     = cJSON_GetObjectItem( p_meter_dat_js, "bcVolt" )->valueint * 10;
        p_junct->meter_dat.act_power = cJSON_GetObjectItem( p_meter_dat_js, "acPower" )->valuedouble;
        p_junct->meter_dat.a_curr    = cJSON_GetObjectItem( p_meter_dat_js, "aCurr" )->valuedouble * 10.0;
        p_junct->meter_dat.b_curr    = cJSON_GetObjectItem( p_meter_dat_js, "bCurr" )->valuedouble * 10.0;
        p_junct->meter_dat.c_curr    = cJSON_GetObjectItem( p_meter_dat_js, "cCurr" )->valuedouble * 10.0;
    }
    cJSON *p_con_sta_array_js = cJSON_GetObjectItem( p_data_js, "ContactorStatus" );

    for (size_t i = 0; i < ARRAY_SIZE(p_junct->ContactorStatus) ; i++)
    {
        p_junct->ContactorStatus[i] = cJSON_GetArrayItem( p_con_sta_array_js, i )->valueint;
    }
}

/**
 * @brief  从机实时数据处理
 * @param  [in] p_root_js ：根节点json
 * @return 无
 * @note   
 */
static void csu_master_slave_real1_handle( cJSON *p_root_js )   
{
    cJSON *p_sn_js = cJSON_GetObjectItem( p_root_js, "csuSn" );
    if ( p_sn_js == NULL )
    {
        return;
    }
    
    csu_dev_pos_t dev_pos = _csu_master_search_dev_pos( p_sn_js->valuestring );
    if ( dev_pos.role != CSU_ROLE_SLAVE || dev_pos.salveIdx == DEV_IDX_INVALID )
    {
        /* 不存在，不回应 */
        return;
    }

    cJSON *p_data_js = cJSON_GetObjectItem( p_root_js, "data" );
    if ( p_data_js == NULL )
    {
        return;
    }

    cJSON *p_soc_js               = cJSON_GetObjectItem( p_data_js, "soc"               );
    cJSON *p_soh_js               = cJSON_GetObjectItem( p_data_js, "soh"               );
    cJSON *p_runStatus_js         = cJSON_GetObjectItem( p_data_js, "runStatus"         );
    cJSON *p_ChargeFlag_js        = cJSON_GetObjectItem( p_data_js, "ChargeFlag"        );
    cJSON *p_DischargeFlag_js     = cJSON_GetObjectItem( p_data_js, "DischargeFlag"     );
    cJSON *p_ChargeLoad_js        = cJSON_GetObjectItem( p_data_js, "ChargeLoad"        );
    cJSON *p_DischargeLoad_js     = cJSON_GetObjectItem( p_data_js, "DischargeLoad"     );
    cJSON *p_BattChargeLoad_js    = cJSON_GetObjectItem( p_data_js, "BattChargeLoad"    );
    cJSON *p_BattDischargeLoad_js = cJSON_GetObjectItem( p_data_js, "BattDischargeLoad" );
    cJSON *p_cellVmax_js          = cJSON_GetObjectItem( p_data_js, "cellVmax"          );
    cJSON *p_cellVmin_js          = cJSON_GetObjectItem( p_data_js, "cellVmin"          );
    cJSON *p_meterP_js            = cJSON_GetObjectItem( p_data_js, "meterP"            );
    cJSON *p_currP_js             = cJSON_GetObjectItem( p_data_js, "currP"             );
    cJSON *p_batVol_js            = cJSON_GetObjectItem( p_data_js, "batVol"            );
    cJSON *p_batCurr_js           = cJSON_GetObjectItem( p_data_js, "batCurr"           );
    cJSON *p_aCurr_js             = cJSON_GetObjectItem( p_data_js, "aCurr"             );
    cJSON *p_bCurr_js             = cJSON_GetObjectItem( p_data_js, "bCurr"             );
    cJSON *p_cCurr_js             = cJSON_GetObjectItem( p_data_js, "cCurr"             );

    if (   (p_soc_js               == NULL)
        || (p_soh_js               == NULL)
        || (p_runStatus_js         == NULL)
        || (p_ChargeFlag_js        == NULL)
        || (p_DischargeFlag_js     == NULL)
        || (p_ChargeLoad_js        == NULL)
        || (p_DischargeLoad_js     == NULL)
        || (p_BattChargeLoad_js    == NULL)
        || (p_BattDischargeLoad_js == NULL)
        || (p_cellVmax_js          == NULL)
        || (p_cellVmin_js          == NULL)
        || (p_meterP_js            == NULL)
        || (p_currP_js             == NULL)
        || (p_aCurr_js             == NULL)
        || (p_bCurr_js             == NULL)
        || (p_cCurr_js             == NULL)
        )
    {
        return;
    }

    csu_node_info_t *p_csu_node_info = &s_master_manage_info.p_comb_info->slave_info[ dev_pos.salveIdx ];

    p_csu_node_info->real_data.sys_status              = p_runStatus_js->valueint;
    p_csu_node_info->real_data.charge_prohibit         = p_ChargeFlag_js->valueint;
    p_csu_node_info->real_data.discharge_prohibit      = p_DischargeFlag_js->valueint;
    p_csu_node_info->real_data.pcs_charge_max_power    = p_ChargeLoad_js->valuedouble * 100;
    p_csu_node_info->real_data.pcs_discharge_max_power = p_DischargeLoad_js->valuedouble * 100;
    p_csu_node_info->real_data.bat_charge_max_power    = p_BattChargeLoad_js->valuedouble * 100;
    p_csu_node_info->real_data.bat_discharge_max_power = p_BattDischargeLoad_js->valuedouble * 100;
    p_csu_node_info->real_data.SOC                     = p_soc_js->valueint;
    p_csu_node_info->real_data.SOH                     = p_soh_js->valueint;
    p_csu_node_info->real_data.meter_power             = p_meterP_js->valuedouble * 100;
    p_csu_node_info->real_data.curr_pcs_power          = p_currP_js->valuedouble * 100;
    p_csu_node_info->real_data.bat_vol                 = p_batVol_js->valuedouble * 10;
    p_csu_node_info->real_data.bat_curr                = p_batCurr_js->valuedouble * 10;
    p_csu_node_info->real_data.ac_a_curr               = p_aCurr_js->valuedouble * 10;
    p_csu_node_info->real_data.ac_b_curr               = p_bCurr_js->valuedouble * 10;
    p_csu_node_info->real_data.ac_c_curr               = p_cCurr_js->valuedouble * 10;

    for (size_t i = 0; i < ARRAY_SIZE( p_csu_node_info->real_data.cell_max_vol ); i++)
    {
        p_csu_node_info->real_data.cell_max_vol[i] = cJSON_GetArrayItem( p_cellVmax_js, i )->valueint;
    }

    for (size_t i = 0; i < ARRAY_SIZE( p_csu_node_info->real_data.cell_max_vol ); i++)
    {
        p_csu_node_info->real_data.cell_min_vol[i] = cJSON_GetArrayItem( p_cellVmin_js, i )->valueint;
    }
    
    p_csu_node_info->real_data.valid = SF_TRUE;
}

static void csu_master_slave_heartBeat_handle( cJSON *p_root_js )
{
    uint8_t *p_ip = s_master_manage_info.p_comb_info->comb_setting.local_ip;
    char    *p_sn = s_master_manage_info.p_comb_info->master_info.sn;
    char reply_str[512] = {0};

    cJSON *p_sn_js = cJSON_GetObjectItem( p_root_js, "csuSn" );
    if ( p_sn_js == NULL )
    {
        return;
    }

    csu_dev_pos_t dev_pos = _csu_master_search_dev_pos( p_sn_js->valuestring );
    // if ( dev_pos.role != CSU_ROLE_SLAVE || dev_pos.salveIdx == DEV_IDX_INVALID )
    // {
    //     /* 不存在，不回应 */
    //     return;
    // }

    if ( dev_pos.role == CSU_ROLE_SLAVE  )
    {
        slave_run_info_t *p_slave_run_info = &s_master_manage_info.slave_run_info[ dev_pos.salveIdx ];
        csu_node_info_t  *p_csu_node_info  = &s_master_manage_info.p_comb_info->slave_info[ dev_pos.salveIdx ];

        user_timer_refresh( p_slave_run_info->online_tm );
        if ( p_csu_node_info->online == SF_FALSE )
        {
            p_csu_node_info->online = SF_TRUE;
            CSU_COMB_MASTER_LOG_D( "slave id:%d online!!!", dev_pos.salveIdx + 1 );
            csu_master_dev_online_flag_refresh();
        }

        sprintf( reply_str, 
                "{\"devtype\":1,\"cmdtype\":\"heartbeat\",\"csuIp\":\"%d.%d.%d.%d\",\"csuSn\":\"%s\", \"result\":\"1\"}",
                p_ip[0], p_ip[1], p_ip[2], p_ip[3], p_sn );

        if ( p_slave_run_info->p_net_con != NULL )
        {
            csu_master_mg_send( p_slave_run_info->p_net_con, reply_str, strlen( reply_str ) );
        }
    }
    else if ( dev_pos.role == CSU_ROLE_JUNCT  )
    {
        slave_run_info_t *p_run_info = &s_master_manage_info.junct_run_info;
        junct_cab_info_t *p_node_info  = &s_master_manage_info.p_comb_info->junct_info;

        user_timer_refresh( p_run_info->online_tm );
        if ( p_node_info->online == SF_FALSE )
        {
            p_node_info->online = SF_TRUE;
            CSU_COMB_MASTER_LOG_D( "slave id:%d online!!!", dev_pos.salveIdx + 1 );
            csu_master_dev_online_flag_refresh();
        }

        sprintf( reply_str, 
                "{\"devtype\":1,\"cmdtype\":\"heartbeat\",\"csuIp\":\"%d.%d.%d.%d\",\"csuSn\":\"%s\", \"result\":\"1\"}",
                p_ip[0], p_ip[1], p_ip[2], p_ip[3], p_sn );

        if ( p_run_info->p_net_con != NULL )
        {
            csu_master_mg_send( p_run_info->p_net_con, reply_str, strlen( reply_str ) );
        }
    }
    return;
}

/**
 * @brief  csu 并机主模块任务调度
 * @param  [in] 无
 * @return 无
 * @note   
 */
static void csu_master_task_loop( void )
{
    csu_master_slave_power_sta_monitor();
    csu_master_slave_online_monitor();
    csu_master_ems_alloct_power_monitor();
    global_comb_info_sync_task_loop();
    local_data_fresh_task_loop();
}

/**
 * @brief  从机 开关状态与主机保持同步 
 * @param  [in] arg 说明
 * @return 
 * @note   
 */
static sf_ret_t csu_master_slave_power_sta_sync( dev_idx_t sync_slave_idx , uint8_t action)
{
    uint8_t *p_ip = s_master_manage_info.p_comb_info->comb_setting.local_ip;
    char    *p_sn = s_master_manage_info.p_comb_info->master_info.sn;
    char power_sta_sync_str[512] = {0};

    if ( (sync_slave_idx >= CSU_COMB_MAX_SLAVE_CNT) && ( sync_slave_idx != DEV_IDX_ALL ) )
    {
        CSU_COMB_MASTER_LOG_E( "slave id:%d error!!!", sync_slave_idx );
        return SF_ERR_PARA;
    }

    dev_idx_t end_slave_idx = 0;
    dev_idx_t slave_idx = 0;

    if ( sync_slave_idx == DEV_IDX_ALL )
    {
        end_slave_idx = s_master_manage_info.p_comb_info->comb_setting.master.comb_num - 1;
        slave_idx     = 0;
    }else{
        slave_idx     = sync_slave_idx;
        end_slave_idx = sync_slave_idx + 1;
    }

    for ( ; slave_idx < end_slave_idx; slave_idx++)
    {
        csu_node_info_t *p_slave_node_info = &s_master_manage_info.p_comb_info->slave_info[ slave_idx ];
        slave_run_info_t *p_slave_run_info = &s_master_manage_info.slave_run_info[ slave_idx ];

        if (   p_slave_node_info->valid  == SF_FALSE 
            || p_slave_node_info->online == SF_FALSE 
            || p_slave_run_info->p_net_con == NULL )
        {
            continue;
        }

        if(action >= SYNC_ACTION_ARRAY_LEN)
        {
            return SF_ERR_PARA;
        }
        sprintf( power_sta_sync_str, 
                "{\"devtype\":1,\"cmdtype\":\"control\",\"csuIp\":\"%d.%d.%d.%d\",\"csuSn\":\"%s\", \"power\":\"%s\"}",
                p_ip[0], p_ip[1], p_ip[2], p_ip[3], p_sn, 
                sync_action_array[action]);

        csu_master_mg_send( p_slave_run_info->p_net_con, power_sta_sync_str, strlen(power_sta_sync_str) );
    }

    return SF_OK;
}

/**
 * @brief  从机 开关状态监控
 * @param  [in] 无
 * @return 
 * @note   
 */
static void csu_master_slave_power_sta_monitor( void )
{
    web_control_info_t *p_web_control_info = sdk_shm_web_control_data_get();
    constant_parameter_data_t *p_constant_parameter_info = sdk_shm_constant_parameter_data_get();
    sf_ret_t ret;
    uint16_t now_energy_saving_state = 0;
    static uint16_t last_energy_saving_state = 0;

    now_energy_saving_state = (p_constant_parameter_info->ems_data.shav_peak_fill_valley_en || p_constant_parameter_info->ems_data.self_cosum_mode_enable);
    if ( last_energy_saving_state != now_energy_saving_state )
    {
        if ( now_energy_saving_state == 0 )
        {
            web_control_info_t *p_web_data = sdk_shm_web_control_data_get();

            /* 退出节能降耗，恢复主从原先状态 */
            if ( s_master_manage_info.p_comb_info->usr_setting.comb_power_on == 0 )
            {
                /* 关机 */
                BIT_SET(p_web_data->control_cmd_flag, 6);
            } else if ( s_master_manage_info.p_comb_info->usr_setting.comb_power_on == 1 )
            {
                /* 开机 */
                BIT_SET(p_web_data->control_cmd_flag, 5);
            }
        }
        last_energy_saving_state =  now_energy_saving_state;
    }

    if(now_energy_saving_state)
    {
        CSU_COMB_MASTER_LOG_D("p_constant_parameter_info->ems_data.shav_peak_fill_valley_en enable");
        for(uint8_t i = 1; i < MAX_SLAVE_COUNT; i++)
        {
            CSU_COMB_MASTER_LOG_D("mcu2_notice[%d]:%d",i,p_constant_parameter_info->mcu2_notice[i]);
            if(p_constant_parameter_info->mcu2_notice[i] != 0)
            {
                csu_node_info_t *p_csu_node_info = &s_master_manage_info.p_comb_info->slave_info[i - 1];

                CSU_COMB_MASTER_LOG_D("%d,%d,%d",p_csu_node_info->valid,p_csu_node_info->online,p_csu_node_info->real_data.valid);
                if ((p_csu_node_info->valid  == SF_TRUE) 
                    && (p_csu_node_info->online == SF_TRUE) 
                    && (p_csu_node_info->real_data.valid == SF_TRUE))
                {
                    ret = csu_master_slave_power_sta_sync( i - 1, p_constant_parameter_info->mcu2_notice[i] + 1);
                    if(ret == SF_OK)
                    {
                        BIT_SET(p_web_control_info->mcu2_notice, i);
                        p_constant_parameter_info->mcu2_notice[i] = 0;
                    }
                }
            }
        }
    }
    else
    {
        /* 一分钟同步一次开关状态 */
        static user_timer_hd power_sta_sycn_timer = NULL;

        if ( power_sta_sycn_timer == NULL )
        {
            power_sta_sycn_timer = user_timer_create( NULL, NULL );
            if ( power_sta_sycn_timer == NULL )
            {
                CSU_COMB_MASTER_LOG_E( "power_sta_sycn_timer == NULL" );
                return ;
            }
            user_timer_set_timeout( power_sta_sycn_timer,  60 * 1000, false );
        }

        if ( user_timer_is_timeout( power_sta_sycn_timer ) == SF_FALSE )
        {
            return;
        }
        user_timer_refresh( power_sta_sycn_timer );
        
        for (size_t i = 0; i < (s_master_manage_info.p_comb_info->comb_setting.master.comb_num - 1); i++)
        {
            csu_node_info_t *p_csu_node_info = &s_master_manage_info.p_comb_info->slave_info[i];
            
            if (   ( p_csu_node_info->valid  != SF_TRUE ) 
                || ( p_csu_node_info->online != SF_TRUE ) 
                || ( p_csu_node_info->real_data.valid != SF_TRUE )  )
            {
                continue;
            }

            if( !( p_csu_node_info->real_data.sys_status == SYS_STA_STOP || p_csu_node_info->real_data.sys_status == SYS_STA_RUNNING ))
            {
                continue;
            }

            bool slave_power_on = (p_csu_node_info->real_data.sys_status == SYS_STA_RUNNING) ? SF_TRUE: SF_FALSE;

            if ( s_master_manage_info.p_comb_info->usr_setting.comb_power_on != slave_power_on )
            {
                csu_master_slave_power_sta_sync( i , s_master_manage_info.p_comb_info->usr_setting.comb_power_on);
            }
        }
    }
}

/**
 * @brief  从机在线状态刷新
 * @param  [in] 无
 * @return 无
 * @note   
 */
static void csu_master_dev_online_flag_refresh( void )
{
    volatile bool online = SF_TRUE;
    firmware_update_t *p_update = sdk_shm_update_data_get();

    for (size_t i = 0; i < (s_master_manage_info.p_comb_info->comb_setting.master.comb_num - 1); i++)
    {
        // if (   s_master_manage_info.p_comb_info->slave_info[i].valid  == SF_TRUE
        //     && s_master_manage_info.p_comb_info->slave_info[i].online == SF_FALSE )
        if (   s_master_manage_info.p_comb_info->slave_info[i].online == SF_FALSE )
        {
            online = SF_FALSE;
            break;
        }
    }

    if ( online )
    {
        if ( 1 == mem_utils_get_bit_val( s_master_manage_info.p_telematic_data->csu_system_fault_info, 16) )
        {
            CSU_COMB_MASTER_LOG_D( "slave all online" );
            mem_utils_set_bit_val( s_master_manage_info.p_telematic_data->csu_system_fault_info, 16, 0 );
        }
    }else{
        //判断是否处于升级状态，在升级状态不进行状态置位
        if(p_update->state == NONE)
        {
            if ( 0 == mem_utils_get_bit_val( s_master_manage_info.p_telematic_data->csu_system_fault_info, 16) )
            {
                CSU_COMB_MASTER_LOG_D( "slave offline" );
                mem_utils_set_bit_val( s_master_manage_info.p_telematic_data->csu_system_fault_info, 16, 1 );
            }
        }
    }

    if (   s_master_manage_info.p_comb_info->junct_info.valid == SF_TRUE
        && s_master_manage_info.p_comb_info->junct_info.online == SF_FALSE )
    // if ( s_master_manage_info.p_comb_info->junct_info.online == SF_FALSE )
    {
        if ( 0 == mem_utils_get_bit_val( s_master_manage_info.p_telematic_data->csu_system_fault_info, 17) )
        {
            CSU_COMB_MASTER_LOG_D( "junction cabinet offline" );
            mem_utils_set_bit_val( s_master_manage_info.p_telematic_data->csu_system_fault_info, 17, 1 );
        }
    } else {
        if ( 1 == mem_utils_get_bit_val( s_master_manage_info.p_telematic_data->csu_system_fault_info, 17) )
        {
            CSU_COMB_MASTER_LOG_D( "junction cabinet oline" );
            mem_utils_set_bit_val( s_master_manage_info.p_telematic_data->csu_system_fault_info, 17, 0 );
        }
    }
}

static void csu_master_dev_set_online_sta( csu_role_e dev_role, dev_idx_t slave_idx , ol_sta_e online_sta )
{
    if ( dev_role == CSU_ROLE_SLAVE )
    {
        csu_node_info_t *p_slave_info = &s_master_manage_info.p_comb_info->slave_info[ slave_idx ];

        if ( online_sta == OL_STA_OFFLINE )
        {
            p_slave_info->online = SF_FALSE;
            p_slave_info->real_data.meter_power = 0;
        }else if ( online_sta == OL_STA_ONLINE )
        {
            p_slave_info->online = SF_TRUE;
        }
        csu_master_dev_online_flag_refresh();
    }
    else if ( dev_role == CSU_ROLE_JUNCT )
    {
        junct_cab_info_t *p_junct_cab_info = &s_master_manage_info.p_comb_info->junct_info;
        
        if ( online_sta == OL_STA_OFFLINE )
        {
            p_junct_cab_info->online = SF_FALSE;

        }else if ( online_sta == OL_STA_ONLINE )
        {
            p_junct_cab_info->online = SF_TRUE;
        }
        csu_master_dev_online_flag_refresh();
    }
}

/**
 * @brief  从机在线状态监控
 * @param  [in] 无
 * @return 无
 * @note   
 */
static void csu_master_slave_online_monitor( void )
{
    /* 监听所有有效从节点 */
    for (size_t i = 0; i < CSU_COMB_MAX_SLAVE_CNT; i++)
    {
        slave_run_info_t *p_slave_run_info  = &s_master_manage_info.slave_run_info[i]; 
        csu_node_info_t *p_slave_info       = &s_master_manage_info.p_comb_info->slave_info[i];

        if (   (p_slave_info->valid == SF_TRUE)
            && (p_slave_info->online == SF_TRUE) )
        {
            if ( user_timer_is_timeout( p_slave_run_info->online_tm ) )
            {
                p_slave_info->online = SF_FALSE;
                p_slave_info->real_data.meter_power = 0;
                CSU_COMB_MASTER_LOG_D( "slave id:%d offline!!!", i );
                csu_master_dev_online_flag_refresh();
            }
        }
    }
    
    slave_run_info_t *p_junct_run_info  = &s_master_manage_info.junct_run_info; 
    junct_cab_info_t *p_junct_cab_info  = &s_master_manage_info.p_comb_info->junct_info;
    if (   ( p_junct_cab_info->valid  == SF_TRUE )
        && ( p_junct_cab_info->online == SF_TRUE ) )
    {
        if ( user_timer_is_timeout( p_junct_run_info->online_tm ) )
        {
            p_junct_cab_info->online = SF_FALSE;
            CSU_COMB_MASTER_LOG_D( "junction cabinet offline!!!" );
            csu_master_dev_online_flag_refresh();
        }
    }
}

/**
 * @brief  上报EMS 分配给从机的功率
 * @param  [in] 无
 * @return 无
 * @note   
 */
static void csu_master_ems_alloct_power_report( void )
{
    uint8_t *p_ip = s_master_manage_info.p_comb_info->comb_setting.local_ip;
    char    *p_sn = s_master_manage_info.p_comb_info->master_info.sn;
    char    reply_str[512] = {0};

    for (size_t i = 0; i < (s_master_manage_info.p_comb_info->comb_setting.master.comb_num - 1); i++)
    {
        csu_node_info_t *p_csu_node_info = &s_master_manage_info.p_comb_info->slave_info[i];

        if (   ( p_csu_node_info->valid  == SF_TRUE ) 
            && ( p_csu_node_info->online == SF_TRUE ) )
        {
            double ems_alloc_power_f = (double)p_csu_node_info->ems_alloc_power / 100.0 ;

            sprintf( reply_str, 
                    "{\"devtype\":1,\"cmdtype\":\"real1\",\"csuIp\":\"%d.%d.%d.%d\",\"csuSn\":\"%s\", \"outP\":%0.2lf, \"result\":\"1\"}",
                    p_ip[0], p_ip[1], p_ip[2], p_ip[3], p_sn, ems_alloc_power_f );

            if ( s_master_manage_info.slave_run_info[i].p_net_con != NULL )
            {
                csu_master_mg_send( s_master_manage_info.slave_run_info[i].p_net_con, reply_str, strlen( reply_str )+1 );
            }
        }
    }
}

/**
 * @brief  监控 EMS分配的功率 【变化上报 + 定时上报】
 * @param  [in] 无
 * @return 无
 * @note   
 */
static void csu_master_ems_alloct_power_monitor( void )
{
    static user_timer_hd report_timer = NULL;
    bool ems_alloc_power_report = SF_FALSE;

    if ( report_timer == NULL )
    {
        /* 开机初始化 */
        report_timer = user_timer_create( NULL, NULL );
        if ( report_timer == NULL )
        {
            CSU_COMB_MASTER_LOG_E( "report_timer == NULL" );
            return;
        }
        user_timer_set_timeout( report_timer, EMS_ALLOC_POWER_REPORT_INV_TM_MS, false );
    }

    /* 定时上报 */
    if ( user_timer_is_timeout( report_timer )  )
    {
        /* 10秒上报一次 */
        user_timer_refresh( report_timer );
        ems_alloc_power_report = SF_TRUE;
    }

    static int32_t last_ems_alloc_power[ CSU_COMB_MAX_SLAVE_CNT ] = {0};

    /* 判断功率分配是否发生变化 */
    for (size_t i = 0; i < (s_master_manage_info.p_comb_info->comb_setting.master.comb_num - 1) ; i++)
    {
        csu_node_info_t *p_csu_node_info = &s_master_manage_info.p_comb_info->slave_info[i];

        if (   ( p_csu_node_info->valid  == SF_TRUE ) 
            && ( p_csu_node_info->online == SF_TRUE ) 
            && ( last_ems_alloc_power[i] != p_csu_node_info->ems_alloc_power ) )
        {
            last_ems_alloc_power[i] = p_csu_node_info->ems_alloc_power;
            ems_alloc_power_report = SF_TRUE;
        }
    }
    
    if ( ems_alloc_power_report )
    {
        csu_master_ems_alloct_power_report();
    }
}

/**
 * @brief  网络发送接口
 * @param  [in] c   ：发送连接
 * @param  [in] buf ：发送数据
 * @param  [in] len ：发送长度
 * @return 
 * @note   
 */
static bool csu_master_mg_send(struct mg_connection *c, const void *buf, size_t len) 
{
    CSU_COMB_MASTER_TCP_MSG_PRINT( "\r\nsend msg:%s", (char *)buf );

    if ( c == NULL )
    {
        CSU_COMB_MASTER_LOG_E( "\r\nc == NULL" );
        return SF_FALSE;
    }
    return mg_send( c, buf, len );
}

static void _csu_master_local_info_fresh( void )
{
    csu_node_info_t *p_master = &s_master_manage_info.p_comb_info->master_info;

    csu_master_dev_online_flag_refresh();

    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();
    bat_charge_data_t *p_bat_charge_data = sdk_shm_bat_charge_data_info_get();
    internal_shared_data_t *p_internal_shared_data = sdk_shm_internal_shared_data_get();

    p_master->real_data.valid                   = SF_TRUE;
    p_master->real_data.sys_status              = p_telemetry_data->sys_version_telemetry_info.csu_sys_state;
    p_master->real_data.charge_prohibit         = p_bat_charge_data->charge_prohibit;
    p_master->real_data.discharge_prohibit      = p_bat_charge_data->discharge_prohibit;
    p_master->real_data.bat_charge_max_power    = p_bat_charge_data->charge_limit_power;
    p_master->real_data.bat_discharge_max_power = p_bat_charge_data->discharge_limit_power;
    p_master->real_data.pcs_charge_max_power    = p_bat_charge_data->pcs_chg_limit_power;
    p_master->real_data.pcs_discharge_max_power = p_bat_charge_data->pcs_dischg_limit_power;
    p_master->real_data.meter_power             = p_internal_shared_data->total_realtime_energy.meter_power / 10 ;
    p_master->real_data.curr_pcs_power          = p_telemetry_data->sys_cabinet_telemetry_info.ac_side_active_power * 10;
    p_master->real_data.cluster_cap_energy      = p_bat_charge_data->cluster_cap_energy;
    p_master->real_data.cluster_num             = p_bat_charge_data->cluster_num;
    p_master->real_data.bat_vol                 = p_bat_charge_data->total_vol * 10;
    p_master->real_data.bat_curr                = p_bat_charge_data->total_curr * 10;

    p_master->real_data.ac_a_curr               = p_internal_shared_data->total_realtime_energy.meter_data.current_a;
    p_master->real_data.ac_b_curr               = p_internal_shared_data->total_realtime_energy.meter_data.current_b;
    p_master->real_data.ac_c_curr               = p_internal_shared_data->total_realtime_energy.meter_data.current_c;

    p_master->real_data.meter_power             = p_internal_shared_data->total_realtime_energy.meter_data.active_power_total * 10;
    memcpy( p_master->ip, s_master_manage_info.p_comb_info->comb_setting.local_ip, sizeof(p_master->ip) );

    uint8_t valid_soc_cnt = 0;
    uint16_t sum_soc = 0;
    uint16_t sum_soh = 0;

    for (size_t i = 0; i < ARRAY_SIZE( p_bat_charge_data->soc_soh_data ); i++)
    {
        if ( p_bat_charge_data->soc_soh_data[i].soc != 0XFFFF )
        {
            valid_soc_cnt ++;
            sum_soc += p_bat_charge_data->soc_soh_data[i].soc;
            sum_soh += p_bat_charge_data->soc_soh_data[i].soh;
        }
    }
    if ( valid_soc_cnt != 0 )
    {
        p_master->real_data.SOC = sum_soc / valid_soc_cnt;
        p_master->real_data.SOH = sum_soh / valid_soc_cnt;
    }
}

static void _csu_master_global_data_calculate( void )
{
    junct_cab_info_t *p_junct_cab_info = &s_master_manage_info.p_comb_info->junct_info;
    csu_node_info_t *p_master = &s_master_manage_info.p_comb_info->master_info;
    global_info_t *p_global_info = &s_master_manage_info.p_comb_info->global_info;
    constant_parameter_data_t *p_const_param = sdk_shm_constant_parameter_data_get();
    internal_shared_data_t *p_internal_data = sdk_shm_internal_shared_data_get();

    int32_t sum_power = p_master->real_data.meter_power;
    uint16_t sum_soc = p_master->real_data.SOC;
    uint8_t sum_cnt = 1;
    int32_t sum_a_curr = p_master->real_data.ac_a_curr;
    int32_t sum_b_curr = p_master->real_data.ac_b_curr;
    int32_t sum_c_curr = p_master->real_data.ac_c_curr;

    for (size_t i = 0; i < ARRAY_SIZE( s_master_manage_info.p_comb_info->slave_info ) ; i++)
    {
        csu_node_info_t *p_slave = &s_master_manage_info.p_comb_info->slave_info[i];

        if ( p_slave->valid == SF_TRUE && p_slave->online == SF_TRUE )
        {
            sum_power  += p_slave->real_data.meter_power;
            sum_soc    += p_slave->real_data.SOC;
            sum_a_curr += p_slave->real_data.ac_a_curr;
            sum_b_curr += p_slave->real_data.ac_b_curr;
            sum_c_curr += p_slave->real_data.ac_c_curr;
            sum_cnt ++;
        }
    }
    p_global_info->SOC = sum_soc / sum_cnt;

    if ( p_junct_cab_info->valid == SF_FALSE || p_junct_cab_info->online == SF_FALSE || p_junct_cab_info->meter_dat.enable == SF_FALSE )
    {
        /* 无汇流柜有效数据时候 */
        internal_shared_data_t *internal_shared_data = &sdk_shm_get()->internal_shared_data;

        /* 以主机电压为标准 */
        p_junct_cab_info->meter_dat.a_vol     = internal_shared_data->total_realtime_energy.meter_data.volt_a;
        p_junct_cab_info->meter_dat.b_vol     = internal_shared_data->total_realtime_energy.meter_data.volt_b;
        p_junct_cab_info->meter_dat.c_vol     = internal_shared_data->total_realtime_energy.meter_data.volt_c;

        /* 功率和电流以主机进行集合计算为准 */
        p_junct_cab_info->meter_dat.act_power = sum_power;
        p_junct_cab_info->meter_dat.a_curr    = sum_a_curr;
        p_junct_cab_info->meter_dat.b_curr    = sum_b_curr;
        p_junct_cab_info->meter_dat.c_curr    = sum_c_curr;
    }

    /* 计算光伏功率 */
    int32_t solar_power = 0;
    for (size_t i = 0; i < p_const_param->photovoltaic_meter_cfg.meter_cnt; i++)
    {
        solar_power += p_internal_data->photovoltaic_meter_data[i].active_power_total;
    }
    p_global_info->PV_meter.enable = p_const_param->system_param.cabinet_param.rs485_device_enable.bit.photovoltaic_meter;
    p_global_info->PV_meter.num    = p_const_param->photovoltaic_meter_cfg.meter_cnt;
    p_global_info->PV_meter.power  = solar_power / 10.0; 

    telemetry_data_t *p_telemetry_data = sdk_shm_telemetry_data_get();
    p_global_info->pcc_power = ( -p_telemetry_data->sys_cabinet_telemetry_info.anti_reflux_power * 10.0);

    /* 计算出负载功率 */
    p_global_info->loadPower = p_global_info->pcc_power - ( (-p_junct_cab_info->meter_dat.act_power) + (-p_global_info->PV_meter.power));
}

static void local_data_fresh_task_loop( void )
{
    static user_timer_hd fresh_timer = NULL;
    
    if ( fresh_timer == NULL )
    {
        fresh_timer = user_timer_create( NULL, NULL);
        user_timer_set_timeout( fresh_timer, 1000, false );
    }

    if ( user_timer_is_timeout( fresh_timer ) == SF_FALSE )
        return;

    user_timer_refresh( fresh_timer );
    
    _csu_master_local_info_fresh();
    _csu_master_global_data_calculate();
}

static void global_comb_info_sync_task_loop( void )
{
    static user_timer_hd sync_timer = NULL;

    if ( sync_timer == NULL )
    {
        sync_timer = user_timer_create( NULL, NULL);
        user_timer_set_timeout( sync_timer, 5000, false );
    }

    if ( user_timer_is_timeout( sync_timer ) == SF_FALSE )
        return;
    
    user_timer_refresh( sync_timer );

    _csu_master_local_info_fresh();
    _csu_master_global_data_calculate();

    global_comb_info_sync();
}

static void global_comb_info_sync( void )
{
    csu_node_info_t *p_slave  = s_master_manage_info.p_comb_info->slave_info;
    junct_cab_info_t *p_junct = &s_master_manage_info.p_comb_info->junct_info;
    global_info_t   *p_global = &s_master_manage_info.p_comb_info->global_info;
    csu_comb_setting_t *p_setting= &s_master_manage_info.p_comb_info->comb_setting;
    telematic_data_t *p_telematic_data = sdk_shm_telematic_data_get();
    char tmp_str[100];

    cJSON *p_root_js = cJSON_CreateObject();
    if ( p_root_js == NULL || p_telematic_data == NULL )
    {
        return;
    }
    
    csu_master_fill_common_json_item( p_root_js , "globalInfo", s_master_manage_info.p_comb_info->master_info.sn );
    cJSON_AddNumberToObject( p_root_js , "systemSOC"     , p_global->SOC );
    cJSON_AddNumberToObject( p_root_js , "loadPower"     , p_global->loadPower / 100.0 );
    cJSON_AddNumberToObject( p_root_js , "pccMeterPower" , p_global->pcc_power / 100.0 );
    cJSON_AddNumberToObject( p_root_js , "pvMeterEnable" , p_global->PV_meter.enable );
    cJSON_AddNumberToObject( p_root_js , "pvNum"         , p_global->PV_meter.num );
    cJSON_AddNumberToObject( p_root_js , "pvPower"       , p_global->PV_meter.power / 100.0 );
    cJSON_AddNumberToObject( p_root_js , "ParallelNum"   , s_master_manage_info.p_comb_info->comb_setting.master.comb_num);

    cJSON *p_ParallelList_js = cJSON_AddArrayToObject( p_root_js, "ParallelList" );
    if ( p_ParallelList_js == NULL )
    {
        cJSON_Delete( p_root_js );
        return;
    }
    
    for (size_t i = 0; i < p_setting->master.comb_num ; i++)
    {
        csu_node_info_t *p_node_info = NULL;

        if ( i == 0 )
        {
            /* 主机信息 */
            p_node_info = &s_master_manage_info.p_comb_info->master_info;
        }else{
            /* 从机信息 */
            p_node_info = &s_master_manage_info.p_comb_info->slave_info[ i - 1];
        }

        cJSON *p_node_js = cJSON_CreateObject();
        if ( p_node_js == NULL )
        {
            cJSON_Delete( p_root_js );
            return;
        }
        cJSON_AddNumberToObject( p_node_js , "devtype" ,  ( i == 0 )? CSU_ROLE_MASTER: CSU_ROLE_SLAVE );
        if ( i != 0 )
        {
            /* 从机信息 */
            cJSON_AddNumberToObject( p_node_js , "slaveId" , i );
        }

        memset( tmp_str, 0, sizeof( tmp_str ) );
        sprintf( tmp_str, "%d.%d.%d.%d", p_node_info->ip[0], p_node_info->ip[1], p_node_info->ip[2], p_node_info->ip[3] );
        cJSON_AddStringToObject( p_node_js , "ip"      , tmp_str );
        cJSON_AddNumberToObject( p_node_js , "online"  , (p_node_info->valid == SF_TRUE && p_node_info->online == SF_TRUE ) ? 1: 0 );
        cJSON_AddNumberToObject( p_node_js , "power"   , p_node_info->real_data.meter_power / 100.0 );
        cJSON_AddNumberToObject( p_node_js , "sysStatus" , p_node_info->real_data.sys_status );
        cJSON_AddNumberToObject( p_node_js , "soc"       , p_node_info->real_data.SOC );
        cJSON_AddNumberToObject( p_node_js , "soh"       , p_node_info->real_data.SOH );
        cJSON_AddNumberToObject( p_node_js , "batVol"    , p_node_info->real_data.bat_vol / 10.0 );
        cJSON_AddNumberToObject( p_node_js , "batCurr"   , p_node_info->real_data.bat_curr / 10.0 );

        cJSON_AddItemToArray( p_ParallelList_js , p_node_js );
    }

    /* 汇流柜信息 */
    cJSON *p_JunctionCabinet_js = cJSON_AddObjectToObject( p_root_js, "JunctionCabinet" );
    if ( p_JunctionCabinet_js == NULL )
    {
        cJSON_Delete( p_root_js );
        return;
    }

    cJSON_AddNumberToObject( p_JunctionCabinet_js, "Enable"                 , p_setting->junct_enable );
    cJSON_AddNumberToObject( p_JunctionCabinet_js, "MeterEnable"            , p_junct->meter_dat.enable );
    cJSON_AddNumberToObject( p_JunctionCabinet_js, "FanStatus"              , p_junct->fan_sta );
    cJSON_AddNumberToObject( p_JunctionCabinet_js, "gridVolSystemFlag"      , p_junct->cabinet_type );
    cJSON_AddNumberToObject( p_JunctionCabinet_js, "CabinTopTemperature"    , p_junct->cab_top_tmp );
    cJSON_AddNumberToObject( p_JunctionCabinet_js, "CabinBottomTemperature" , p_junct->cab_buttom_tmp );
    cJSON_AddNumberToObject( p_JunctionCabinet_js, "Humidity"               , p_junct->cab_humidity );
    cJSON_AddNumberToObject( p_JunctionCabinet_js, "DoorStatus"             , p_junct->cab_door_sta );
    cJSON_AddNumberToObject( p_JunctionCabinet_js, "FloodStatus"            , p_junct->cab_flood_sta );
    cJSON_AddNumberArrayToObject( p_JunctionCabinet_js, "ContactorStatus", NUM_TYPE_U8, p_junct->ContactorStatus, sizeof( p_junct->ContactorStatus ) );

    cJSON *p_MeterData_js = cJSON_AddObjectToObject( p_JunctionCabinet_js, "MeterData" );
    cJSON_AddNumberToObject( p_JunctionCabinet_js, "FaultStatus" , mem_utils_get_bit_val(&p_telematic_data->csu_system_fault_info[2], 2) );
    if ( p_MeterData_js == NULL )
    {
        cJSON_Delete( p_root_js );
        return;
    }
    
    cJSON_AddNumberToObject( p_MeterData_js, "abVolt"  , p_junct->meter_dat.a_vol / 10.0 );
    cJSON_AddNumberToObject( p_MeterData_js, "caVolt"  , p_junct->meter_dat.b_vol / 10.0 );
    cJSON_AddNumberToObject( p_MeterData_js, "bcVolt"  , p_junct->meter_dat.c_vol / 10.0 );
    cJSON_AddNumberToObject( p_MeterData_js, "aCurr"   , p_junct->meter_dat.a_curr / 10.0 );
    cJSON_AddNumberToObject( p_MeterData_js, "bCurr"   , p_junct->meter_dat.b_curr / 10.0 );
    cJSON_AddNumberToObject( p_MeterData_js, "cCurr"   , p_junct->meter_dat.c_curr / 10.0 );
    cJSON_AddNumberToObject( p_MeterData_js, "acPower" , p_junct->meter_dat.act_power / 100.0 );

    char *p_send_str = cJSON_PrintUnformatted( p_root_js );
    if ( p_send_str == NULL )
    {
        cJSON_Delete( p_root_js );
        return;
    }
    
    if ( p_junct->valid && p_junct->online )
    {
        csu_master_mg_send( s_master_manage_info.junct_run_info.p_net_con, p_send_str, strlen( p_send_str ) );
    }
    
    for (size_t i = 0; i < (p_setting->master.comb_num - 1); i++)
    {
        if ( p_slave[i].valid && p_slave[i].online )
        {
            csu_master_mg_send( s_master_manage_info.slave_run_info[i].p_net_con, p_send_str, strlen( p_send_str ) );
        }
    }
    
    free( p_send_str );
    cJSON_Delete( p_root_js );
    return;
}

static void csu_comb_master_close_slave_tcp_con( struct mg_connection *p_nc )
{
    if ( s_master_manage_info.junct_run_info.p_net_con == p_nc )
    {
        s_master_manage_info.junct_run_info.p_net_con = NULL;
        csu_master_dev_set_online_sta( CSU_ROLE_JUNCT, DEV_IDX_INVALID, OL_STA_OFFLINE );
        return;
    }

    for (size_t i = 0; i < CSU_COMB_MAX_SLAVE_CNT; i++)
    {
        if ( s_master_manage_info.slave_run_info[i].p_net_con == p_nc )
        {
            s_master_manage_info.slave_run_info[i].p_net_con = NULL;
            csu_master_dev_set_online_sta( CSU_ROLE_SLAVE, i, OL_STA_OFFLINE );
            return;
        }
    }
}
