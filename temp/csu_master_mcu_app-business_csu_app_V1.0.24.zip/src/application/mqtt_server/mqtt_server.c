#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "data_shm.h"
#include "sdk_shm.h"
#include "errors.h"
#include "sofar_log.h"
#include "mqtt_service.h"
#include <pthread.h>
#include <unistd.h>


/**
 * @brief   小桔mqtt服务进程
 * @param   [in] arg
 * @note
 * @return
 */
int main(int argc, char *argv[])
{
	log_init((int8_t *)PATH_CONF);
    log_set_level(LOG_LVL_DEBUG);
	// 映射共享内存
	common_data_t *tep = sdk_shm_init();
	if (!tep)
	{
		MQTT_DEBUG_PRINT((int8_t *)" sdk_shm_init fail\n ");
		return -1;
	}

	// 小桔mqtt服务线程
	pthread_t file_analysis;
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);

	if(pthread_create(&file_analysis,&attr,iothub_mqtt_service,NULL) != 0)
	{
		perror("pthread_create iothub_mqtt_service");
	}
	pthread_attr_destroy(&attr);

	while(1)
	{
		sleep(1);
	}

	log_finish();

	return 0;
}