/**
* @file        data_shm.c
* @brief       获取共享内存，各大数据块基地址
* @copyright   Shouhang
* @author   
* @note     
* @version     V1.0   
* @date        2023/02/13
*/


#include "sdk_ipc.h"
#include "sdk_shm.h"
#include <stdio.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>


//定义common_data_t类型的全局变量
common_data_t *shm = NULL;


// common_data_t *shm;
common_data_t *shmdata()
{
    int32_t shmid;
	key_t shmkey = ftok("/",'a');
	if(shmkey == -1)
	{
		printf("[%s:%s:%d] %s\n", __FILE__,__func__, __LINE__, strerror(errno));
		return NULL;
	}

    // 创建共享内存
	shmid = shmget(shmkey,sizeof(common_data_t),0666|IPC_CREAT);
	if(shmid == -1)
	{
        // 获取共享内存ID
        shmid = shmget(shmkey,0,0);
        if(shmid == -1)
        {
            printf("[%s:%s:%d] %s\n", __FILE__,__func__, __LINE__, strerror(errno));
            return NULL;
        }
	}
	
    //获取共享内存
	common_data_t * shmaddr = (common_data_t*)shmat(shmid,0,0);
	if(shmaddr==(common_data_t*)-1)
	{
		printf("[%s:%s:%d] %s\n", __FILE__,__func__, __LINE__, strerror(errno));
		return NULL;
	}
       
	return shmaddr;
}


/**
 * @brief    共享内存初始化 （main函数初始化时调用它，收到-1 则终止）
 * @param    void    
 * @return   失败NULL,成功为指向的内容
 */
common_data_t *sdk_shm_init(void)    
{
    shm = shmdata();
    if(!(shm))
    {
        printf("[%s:%s:%d] read create shmdata failed\n", __FILE__,__func__, __LINE__);
        return NULL;
    }

    return shm;
}

/**
 * @brief    获取shm指针的地址
 * @param
 * @return
 */
common_data_t **sdk_shm_addr_get(void)
{
    return &shm;
}

/**
 * @brief    获取shm指向的内容
 * @param        
 * @return    
 */
common_data_t *sdk_shm_get(void)
{
    return shm;
}

/**
 * @brief    获取共享内存里 遥信数据 的基地址
 * @param
 * @return
 */
telematic_data_t *sdk_shm_telematic_data_get(void)
{
    return(&(shm->telematic_data));
}



/**
 * @brief    获取共享内存里 遥测数据 的基地址
 * @param
 * @return
 */
telemetry_data_t *sdk_shm_telemetry_data_get(void)
{
    return(&(shm->telemetry_data));
}



/**
 * @brief    获取共享内存里 定值/参数数据 的基地址
 * @param
 * @return
 */
constant_parameter_data_t *sdk_shm_constant_parameter_data_get(void)
{
    return(&(shm->constant_parameter_data));
}



/**
 * @brief    获取共享内存里 其他参数 的基地址
 * @param
 * @return
 */
other_parameter_data_t *sdk_shm_other_parameter_data_get(void)
{
    return(&(shm->other_parameter_data));
}

/**
 * @brief    获取共享内存里 内部共用参数 的基地址
 * @param
 * @return
 */
internal_shared_data_t *internal_shared_data_get(void)
{
	return(&(shm->internal_shared_data));
}



/**
 * @brief    获取共享内存里 升级信息 的基地址
 * @param
 * @return
 */
firmware_update_t *sdk_shm_firmware_update_info_get(void)
{
    return(&(shm->update));
}

/**
 * @brief    获取共享内存里 web控制操作相关信息 的基地址
 * @param
 * @return
 */
web_control_info_t *shm_web_control_info_get(void)
{
    return(&(shm->web_control_info));
}

/**
 * @brief    获取共享内存里 内部版本信息 的基地址
 * @param
 * @return
 */
internal_version_info_t *internal_version_info_get(void)
{
     
	return(&(shm->internal_version_info));
}

