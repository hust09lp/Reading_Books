#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include <pthread.h>
#include"cJSON.h"
#include"data_shm.h"
#include"sdk_shm.h"
#include"sdk_para.h"
#include"sdk_public.h"
#include"app_common.h"
#include"sofar_errors.h"
#include"mqtt_func_handle.h"
#include"mqtt_service.h"
#include"mqtt_cmu_data_update.h"
#include"mqtt_energy_handle.h"
#include"libghttp/ghttp.h"
#include"libghttp/ghttp_constants.h"

static uint8_t cmu_ip_tbl[MAX_SLAVE_COUNT][MAX_IP_LEN] = {CMU1_IP, CMU2_IP, CMU3_IP, CMU4_IP, CMU5_IP, CMU6_IP};

/**
 * @brief    HTTP获取CMU数据接口
 * @param	 [in] *p_uri url 
 * @param	 [in] *p_params 报文内容
 * @param	 [in] timeout 超时时间参数
 * @param	 [out] *p_resp_body 返回报文
 * @return   0：失败；1：成功
 */
uint8_t http_net_post(char* p_uri, char* p_params, char *p_resp_body) 
{  
    ghttp_request *request = NULL;  
    char *resp_buf = NULL;
    ghttp_status status;  

    request = ghttp_request_new();  
    if(ghttp_set_uri(request, p_uri) == -1)  
    {
        MQTT_DEBUG_PRINT((int8_t *)"ghttp set uri error");
        return 0;
    } 
    if(ghttp_set_type(request, ghttp_type_post) == -1)
    {
        MQTT_DEBUG_PRINT((int8_t *)"ghttp set type error");
        return 0;
    }

    if(p_params == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"params is NULL,error");
        return 0;
    }

    ghttp_set_header(request, http_hdr_Content_Type,"application/x-www-form-urlencoded"); 
    ghttp_set_sync(request, ghttp_sync); //set sync  
    ghttp_set_body(request, p_params, strlen(p_params)); //  
    ghttp_prepare(request);  
    status = ghttp_process(request);  
    if(status == ghttp_error)  
    {
        ghttp_request_destroy(request);
        ghttp_close(request);
        return 0;
    }

    resp_buf = ghttp_get_body(request);
    memcpy(p_resp_body, resp_buf, strlen(resp_buf));
    ghttp_request_destroy(request);
    ghttp_close(request);
    return 1;  
} 


/**
 * @brief 定时CMU信息，用于小桔云平台上报
 */
static void mqtt_iothub_get_cmu_data(void)
{
    char uri[] = {"/mqttUpload/getUploadData"};
    char json_str[] = {"{\"action\":\"getUploadData\"}"};    

    uint8_t dev_num = 1;
    uint8_t ret = 0;
    uint16_t i;
    uint16_t array_size = 0;
    char url[128] = {0};
    char response[1024 * 8] = {0};
    cJSON *p_response = NULL;
    common_data_t *shm = NULL;
	bms_data_t *p_bms_shm_data = NULL;
    pcs_data_t *p_pcs_data = NULL;
    static uint32_t cnt = 0;

    if(cnt < 2)
    {
        cnt++;
        return;
    }

	shm = sdk_shm_get();
	p_bms_shm_data = &shm->mqtt_data.bms_data;
	if(p_bms_shm_data == NULL)
	{
		MQTT_DEBUG_PRINT((int8_t *)"\n [%s:%d] bms data is NULL\n");
		return;
	}
    
	p_pcs_data = &shm->mqtt_data.pcs_data;
	if(p_pcs_data == NULL)
	{
		MQTT_DEBUG_PRINT((int8_t *)"\n [%s:%d] pcs data is NULL\n");
		return;
	}

    // 打包URL
    sprintf(url, "%s%s%s", "http://", cmu_ip_tbl[dev_num - 1], uri);
    ret = http_net_post(url, json_str, response);
    if(ret != 1)
    {
        MQTT_DEBUG_PRINT((int8_t *)"connect cmu error");
        return;
    }
    else
    {
        // MQTT_DEBUG_PRINT((int8_t *)"response:%s", response);
        // 解析CMU数据
        p_response = cJSON_Parse(response);
        if(p_response == NULL)
        {
            MQTT_DEBUG_PRINT((int8_t *)"json data parse error");
            return;
        }

        cJSON *bms_item = cJSON_GetObjectItem(p_response, "BMS");
        p_bms_shm_data->battery_type = cJSON_GetObjectItem(bms_item,"batteryType")->valueint;
        p_bms_shm_data->charge_status = cJSON_GetObjectItem(bms_item,"chargeStatus")->valueint;
        p_bms_shm_data->charge_curr_max = cJSON_GetObjectItem(bms_item,"chargeCurrMax")->valueint;
        p_bms_shm_data->discharge_curr_max = cJSON_GetObjectItem(bms_item,"dischargeCurrMax")->valueint;
        p_bms_shm_data->voltage = cJSON_GetObjectItem(bms_item,"voltage")->valueint;
        p_bms_shm_data->current = cJSON_GetObjectItem(bms_item,"current")->valueint;
        p_bms_shm_data->power = cJSON_GetObjectItem(bms_item,"power")->valueint;
        p_bms_shm_data->soc = cJSON_GetObjectItem(bms_item,"soc")->valueint;
        p_bms_shm_data->soh = cJSON_GetObjectItem(bms_item,"soh")->valueint;
        p_bms_shm_data->monomer_vmin = cJSON_GetObjectItem(bms_item,"monomerVmin")->valueint;
        p_bms_shm_data->monomer_vmin_index = cJSON_GetObjectItem(bms_item,"monomerVminIndex")->valueint;
        p_bms_shm_data->monomer_vmax = cJSON_GetObjectItem(bms_item,"monomerVmax")->valueint;
        p_bms_shm_data->monomer_vmax_index = cJSON_GetObjectItem(bms_item,"monomerVmaxIndex")->valueint;
        p_bms_shm_data->monomer_tmin = cJSON_GetObjectItem(bms_item,"monomerTmin")->valueint;
        p_bms_shm_data->monomer_tmin_index = cJSON_GetObjectItem(bms_item,"monomerTminIndex")->valueint;
        p_bms_shm_data->monomer_tmax = cJSON_GetObjectItem(bms_item,"monomerTmax")->valueint;
        p_bms_shm_data->monomer_tmax_index = cJSON_GetObjectItem(bms_item,"monomerTmaxIndex")->valueint;
        p_bms_shm_data->total_discharge = cJSON_GetObjectItem(bms_item,"totalDischarge")->valueint;
        p_bms_shm_data->total_charge = cJSON_GetObjectItem(bms_item,"totalcharge")->valueint;
        p_bms_shm_data->day_discharge = cJSON_GetObjectItem(bms_item,"dayDischarge")->valueint;
        p_bms_shm_data->day_charge = cJSON_GetObjectItem(bms_item,"daycharge")->valueint;
        p_bms_shm_data->pack_num = cJSON_GetObjectItem(bms_item,"packNum")->valueint;
        p_bms_shm_data->monomer_num = cJSON_GetObjectItem(bms_item,"monomerNum")->valueint;
        p_bms_shm_data->pack_tpoint_num = cJSON_GetObjectItem(bms_item,"packTpointNum")->valueint;

		cJSON *pack_volt = cJSON_GetObjectItem(bms_item,"packVolt");
		array_size = cJSON_GetArraySize(pack_volt);
        for(i = 0; i < array_size; i++)
        {
            p_bms_shm_data->pack_volt[i] = cJSON_GetArrayItem(pack_volt, i)->valueint;
        }

		cJSON *pack_curr = cJSON_GetObjectItem(bms_item,"packCurr");
		array_size = cJSON_GetArraySize(pack_curr);
        for(i = 0; i < array_size; i++)
        {
            p_bms_shm_data->pack_curr[i] = cJSON_GetArrayItem(pack_curr, i)->valueint;
        }

		cJSON *pack_power = cJSON_GetObjectItem(bms_item,"packPower");
		array_size = cJSON_GetArraySize(pack_power);
        for(i = 0; i < array_size; i++)
        {
            p_bms_shm_data->pack_power[i] = cJSON_GetArrayItem(pack_power, i)->valueint;
        }

		cJSON *monomer_volt = cJSON_GetObjectItem(bms_item,"monomerVolt");
		array_size = cJSON_GetArraySize(monomer_volt);
        for(i = 0; i < array_size; i++)
        {
            p_bms_shm_data->monomer_volt[i] = cJSON_GetArrayItem(monomer_volt, i)->valueint;
        }

		cJSON *monomer_temp = cJSON_GetObjectItem(bms_item,"monomerTemp");
		array_size = cJSON_GetArraySize(monomer_temp);
        for(i = 0; i < array_size; i++)
        {
            p_bms_shm_data->monomer_temp[i] = cJSON_GetArrayItem(monomer_temp, i)->valueint;
        }

        cJSON *pcs_item = cJSON_GetObjectItem(p_response, "PCS");
        p_pcs_data->pcs_status = cJSON_GetObjectItem(pcs_item,"PCSStatus")->valueint;
        p_pcs_data->charge_status = cJSON_GetObjectItem(pcs_item,"chargeStatus")->valueint;
        p_pcs_data->temp = cJSON_GetObjectItem(pcs_item,"temp")->valueint;
        p_pcs_data->grid_power = cJSON_GetObjectItem(pcs_item,"gridPower")->valueint;
        p_pcs_data->load_power = cJSON_GetObjectItem(pcs_item,"loadPower")->valueint;
        p_pcs_data->dc_power = (cJSON_GetObjectItem(pcs_item,"dcPower")->valueint) * 1000;
        p_pcs_data->ac_power = (cJSON_GetObjectItem(pcs_item,"acPower")->valueint) * 10;
        p_pcs_data->grid_su_energy = cJSON_GetObjectItem(pcs_item,"gridSuEnergy")->valueint;
        p_pcs_data->get_grid_energy = cJSON_GetObjectItem(pcs_item,"getGridEnergy")->valueint;
        p_pcs_data->load_use_energy = cJSON_GetObjectItem(pcs_item,"loadUseEnergy")->valueint;
        p_pcs_data->grid_volt_r = cJSON_GetObjectItem(pcs_item,"gridVoltR")->valueint;
        p_pcs_data->grid_current_r = cJSON_GetObjectItem(pcs_item,"gridCurrentR")->valueint;
        p_pcs_data->grid_freq_r = cJSON_GetObjectItem(pcs_item,"gridFreqR")->valueint;
        p_pcs_data->grid_volt_s = cJSON_GetObjectItem(pcs_item,"gridVoltS")->valueint;
        p_pcs_data->grid_current_s = cJSON_GetObjectItem(pcs_item,"gridCurrentS")->valueint;
        p_pcs_data->grid_freq_s = cJSON_GetObjectItem(pcs_item,"gridFreqS")->valueint;
        p_pcs_data->grid_volt_t = cJSON_GetObjectItem(pcs_item,"gridVoltT")->valueint;
        p_pcs_data->grid_current_t = cJSON_GetObjectItem(pcs_item,"gridCurrentT")->valueint;
        p_pcs_data->grid_freq_t = cJSON_GetObjectItem(pcs_item,"gridFreqT")->valueint;
        p_pcs_data->day_run_time = cJSON_GetObjectItem(pcs_item,"dayRunTime")->valueint;
        p_pcs_data->total_run_time = cJSON_GetObjectItem(pcs_item,"totalRunTime")->valueint;

        cJSON_Delete(p_response);
    }
    cnt = 0;
}


/**
 * @brief 定时CMU事件，用于小桔云平台上报
 */
static void mqtt_iothub_get_cmu_event(void)
{
    char uri[] = {"/mqttUpload/getUploadEvent"};
    char json_str[] = {"{\"action\":\"getUploadEvent\"}"};    

    uint8_t dev_num = 1;
    uint8_t ret = 0;
    char url[128] = {0};
    char response[1024] = {0};
    cJSON *p_response = NULL;
    common_data_t *shm = NULL;
	bms_data_t *p_bms_shm_data = NULL;
    dev_event_t *p_dev_event = NULL;

	shm = sdk_shm_get();
	p_bms_shm_data = &shm->mqtt_data.bms_data;
	if(p_bms_shm_data == NULL)
	{
		MQTT_DEBUG_PRINT((int8_t *)"\n [%s:%d] bms data is NULL\n");
		return;
	}

    p_dev_event = &shm->mqtt_data.dev_event;
	if(p_dev_event == NULL)
	{
		MQTT_DEBUG_PRINT((int8_t *)"\n [%s:%d] dev event is NULL\n");
		return;
	}

    // 打包URL
    sprintf(url, "%s%s%s", "http://", cmu_ip_tbl[dev_num - 1], uri);
    ret = http_net_post(url, json_str, response);
    if(ret != 1)
    {
        MQTT_DEBUG_PRINT((int8_t *)"connect cmu error");
        return;
    }
    else
    {
        // MQTT_DEBUG_PRINT((int8_t *)"response:%s", response);
        // 解析CMU数据
        p_response = cJSON_Parse(response);
        if(p_response == NULL)
        {
            MQTT_DEBUG_PRINT((int8_t *)"json data parse error");
            return;
        }
        shm->mqtt_data.energy_cabinet_status = cJSON_GetObjectItem(p_response,"energyCabinetStatus")->valueint;
        // MQTT_DEBUG_PRINT((int8_t *)"energy cabinet status:%d", shm->mqtt_data.energy_cabinet_status);
        cJSON *bms_item = cJSON_GetObjectItem(p_response, "Event");
        p_bms_shm_data->charge_status = cJSON_GetObjectItem(bms_item,"chargeStatus")->valueint;
        p_dev_event->bat_full = cJSON_GetObjectItem(bms_item,"batFull")->valueint;

        cJSON *warn1_item = cJSON_GetObjectItem(p_response, "Warn1");
        p_dev_event->bms_warn[0] = cJSON_GetObjectItem(warn1_item,"BMS")->valueint;
        p_dev_event->dy_warn[0] = cJSON_GetObjectItem(warn1_item,"DY")->valueint;

        cJSON *warn2_item = cJSON_GetObjectItem(p_response, "Warn2");
        p_dev_event->bms_warn[1] = cJSON_GetObjectItem(warn2_item,"BMS")->valueint;

        cJSON *warn3_item = cJSON_GetObjectItem(p_response, "Warn3");
        p_dev_event->bms_warn[2] = cJSON_GetObjectItem(warn3_item,"BMS")->valueint;
        p_dev_event->pcs_warn[2] = cJSON_GetObjectItem(warn3_item,"PCS")->valueint;
        p_dev_event->dy_warn[2] = cJSON_GetObjectItem(warn3_item,"DY")->valueint;

        cJSON_Delete(p_response);
    }
}


/**
 * @brief  将储能柜参数下发至CMU
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
static void mqtt_iothub_set_cmu_param(void)
{
    char uri[] = {"/mqttSetParam/paramSet"};
    cJSON *p_resp_root;
    common_data_t *shm = NULL;
    energy_cabinet_param_t *p_param = NULL;
    char *p = NULL;
    char url[128] = {0};
    char response[1024] = {0};
    uint8_t dev_num = 1;
    uint8_t ret = 0;
 
    web_control_info_t *p_web_param = shm_web_control_info_get();
    constant_parameter_data_t *p_const_param = sdk_shm_constant_parameter_data_get();
    shm = sdk_shm_get();
    p_param = &shm->mqtt_data.energy_cabinet_param;
    if(p_param == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"\n [%s:%d] data is NULL\n",__func__, __LINE__);
        return;
    }
 
    if(!((BIT_GET(p_param->param_set_falg, 1)) + (BIT_GET(p_param->param_set_falg, 2)) + \
         (BIT_GET(p_param->param_set_falg, 4)) + (BIT_GET(p_param->param_set_falg, 5))))
    {
        return;
    }
 
    p_resp_root = cJSON_CreateObject();
    if(p_resp_root == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"create json obj failed");
        return;
    }
 
    cJSON_AddStringToObject(p_resp_root,"action","paramSet");
 
    p_web_param->ems_data.end_charge_soc_max = p_const_param->ems_data.end_charge_soc_max;
    p_web_param->ems_data.discharge_soc_min = p_const_param->ems_data.discharge_soc_min;
    if(BIT_GET(p_param->param_set_falg, 1))
    {
        cJSON_AddNumberToObject(p_resp_root,"monomerChargeLimitVolt",p_param->monomer_charge_limit_volt);
        BIT_CLR(p_param->param_set_falg, 1);
    }
    if(BIT_GET(p_param->param_set_falg, 2))
    {
        cJSON_AddNumberToObject(p_resp_root,"chargeLimitSoc",p_param->charge_limit_soc);
        p_web_param->ems_data.end_charge_soc_max = p_param->charge_limit_soc / 10;
        BIT_SET(p_web_param->cabinet_param_update_flag, 7);
        BIT_CLR(p_param->param_set_falg, 2);
    } 
    if(BIT_GET(p_param->param_set_falg, 4))
    {
        cJSON_AddNumberToObject(p_resp_root,"monomerDischargeLimitVolt",p_param->monomer_discharge_limit_volt);
        BIT_CLR(p_param->param_set_falg, 4);
    } 
    if(BIT_GET(p_param->param_set_falg, 5))
    {
        cJSON_AddNumberToObject(p_resp_root,"dischargeLimitSoc",p_param->discharge_limit_soc);
        p_web_param->ems_data.discharge_soc_min = p_param->discharge_limit_soc / 10;
        BIT_SET(p_web_param->cabinet_param_update_flag, 7);
        BIT_CLR(p_param->param_set_falg, 5);
    } 
 
    p = cJSON_PrintUnformatted(p_resp_root);
    MQTT_DEBUG_PRINT((int8_t *)"param:%s", p);
    cJSON_Delete(p_resp_root);    
 
    sprintf(url, "%s%s%s", "http://", cmu_ip_tbl[dev_num - 1], uri);
    ret = http_net_post(url, p, response);
    if(ret != 1)
    {
        MQTT_DEBUG_PRINT((int8_t *)"connect cmu error");
        free(p);
        return;
    }
    else
    {
        MQTT_DEBUG_PRINT((int8_t *)"response:%s", response);
    }
    free(p);
}


/**
 * @brief    设置系统状态
 * @param	 [in]status 0:关机 1：开机
 * @return   执行状态0：失败；1：成功
 */
static uint8_t sys_set_power_status(uint8_t status)
{
    uint8_t dev_num = 1;
    char uri[128] = {0};
    char json_str[512] = {0};
    uint8_t ret = 0;
    char url[128] = {0};
    char response[2048] = {0};
    cJSON *p_response = NULL;
    uint32_t json_status = 0;

    web_control_info_t *p_web_data = shm_web_control_info_get();
    if(status == 0)
    {
        strcpy(uri, "/controlCmd/remotePowerOffCmd");
        sprintf(json_str, "{\"action\":\"remotePowerOffCmd\",\"userName\":\"mqtt\"}");
        BIT_SET(p_web_data->control_cmd_flag, 1);
        p_web_data->control_cmd_data.run_state = 0;
    }
    else if(status == 1)
    {
        strcpy(uri, "/controlCmd/remotePowerOnCmd");
        sprintf(json_str, "{\"action\":\"remotePowerOnCmd\",\"userName\":\"mqtt\"}");
        BIT_SET(p_web_data->control_cmd_flag, 1);
        p_web_data->control_cmd_data.run_state = 1;
    }
    sprintf(url, "%s%s%s", "http://", cmu_ip_tbl[dev_num - 1], uri);
    ret = http_net_post(url, json_str, response);
    if(ret != 1)
    {
        return 0;
    }
    else
    {
        p_response = cJSON_Parse(response);
        if(p_response == NULL)
        {
            MQTT_DEBUG_PRINT((int8_t *)"json data parse error");
            return 0;
        }
        json_status = cJSON_GetObjectItem(p_response,"code")->valueint;
        if(json_status == 200)
        {
            cJSON_Delete(p_response);
            return 1;
        }
        cJSON_Delete(p_response);
    }
    return 0;
}


/**
 * @brief  设置充电
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
static void mqtt_iothub_set_charge_status(void)
{
    uint8_t energy_cabinet_status = 0;
    energy_cabinet_param_t *p_param = NULL;
    web_control_info_t *sdk_shm_web_data = NULL;
    static uint32_t flag = 0;

    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get();
    p_param = &sdk_shm_get()->mqtt_data.energy_cabinet_param;
    energy_cabinet_status = sdk_shm_get()->mqtt_data.energy_cabinet_status;
    sdk_shm_web_data = &sdk_shm_get()->web_control_info;

    if(energy_cabinet_status == 0)              //执行开机
    {
        if(flag % 5 == 0)
        {
            sys_set_power_status(1);
            MQTT_DEBUG_PRINT((int8_t *)"dev power on------>");
        }
        flag++;
    }
    else if((energy_cabinet_status == 2) && (p_para_data->elec_meter_param.control_mode == 1))        //下发满功率充电
    {
        flag = 0;
        BIT_SET(sdk_shm_web_data->xiaoju_param_set_flag, 1);
        BIT_CLR(p_param->param_set_falg, 0);
    }
}


/**
 * @brief  设置放电
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
static void mqtt_iothub_set_discharge_status(void)
{
    uint8_t energy_cabinet_status = 0;
    energy_cabinet_param_t *p_param = NULL;
    web_control_info_t *sdk_shm_web_data = NULL;
    static uint32_t flag = 0;

    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get();
    p_param = &sdk_shm_get()->mqtt_data.energy_cabinet_param;
    energy_cabinet_status = sdk_shm_get()->mqtt_data.energy_cabinet_status;
    sdk_shm_web_data = &sdk_shm_get()->web_control_info;

    if(energy_cabinet_status == 0)              //执行开机
    {
        if(flag % 5 == 0)
        {
            sys_set_power_status(1);
            MQTT_DEBUG_PRINT((int8_t *)"dev power on------>");
        }
        flag++;
    }
    else if((energy_cabinet_status == 2) && (p_para_data->elec_meter_param.control_mode == 1))         //下发满功率放电
    {
        flag = 0;
        BIT_SET(sdk_shm_web_data->xiaoju_param_set_flag, 2);
        BIT_CLR(p_param->param_set_falg, 0);
    }
}


/**
 * @brief  设置关机
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
static void mqtt_iothub_set_poweroff(void)
{
    uint8_t energy_cabinet_status = 0;
    energy_cabinet_param_t *p_param = NULL;
    static uint32_t flag = 0;

    p_param = &sdk_shm_get()->mqtt_data.energy_cabinet_param;
    energy_cabinet_status = sdk_shm_get()->mqtt_data.energy_cabinet_status;

    if(energy_cabinet_status != 0)              //执行开机
    {
        if(flag % 5 == 0)
        {
            sys_set_power_status(0);
            MQTT_DEBUG_PRINT((int8_t *)"dev power off------>");
        }
        flag++;
    }
    else
    {
        flag = 0;
        BIT_CLR(p_param->param_set_falg, 0);
    }
}


/**
 * @brief  设置静置
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
static void mqtt_iothub_set_standby_status(void)
{
    energy_cabinet_param_t *p_param = NULL;
    web_control_info_t *sdk_shm_web_data = NULL;

    p_param = &sdk_shm_get()->mqtt_data.energy_cabinet_param;
    sdk_shm_web_data = &sdk_shm_get()->web_control_info;

    BIT_SET(sdk_shm_web_data->xiaoju_param_set_flag, 0);
    BIT_CLR(p_param->param_set_falg, 0);
}

/**
 * @brief  根据云端数据设置储能柜状态
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
static void mqtt_iothub_set_cmu_status(void)
{
    energy_cabinet_param_t *p_param = NULL;
    web_control_info_t *p_web_control = NULL;

    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get();
    p_web_control = &sdk_shm_get()->web_control_info;
	p_param = &sdk_shm_get()->mqtt_data.energy_cabinet_param;
    if(BIT_GET(p_param->param_set_falg, 0))              //设置充放电
    {
        switch(p_param->chargr_cmd)
        {
            case STANDBY:                                   //无动作，关机-->设置功率0
                mqtt_iothub_set_standby_status();
                break;

            case CHARGE:                                    //充电，开机-->设置默认功率
                mqtt_iothub_set_charge_status();
                break;

            case DISCHARGE:                                 //放电，开机-->设置默认功率
                mqtt_iothub_set_discharge_status();
                break;

            case POWEROFF:                                  //停机
                mqtt_iothub_set_poweroff();
                break;

            default:
                break;

        }
    }
    if((BIT_GET(p_param->param_set_falg, 3)) && (p_para_data->elec_meter_param.control_mode == 1))
    {
        //把最大充电限制功率发至MCU2
        BIT_SET(p_web_control->xiaoju_param_set_flag, 3);
        BIT_CLR(p_param->param_set_falg, 3);
    }   
    if((BIT_GET(p_param->param_set_falg, 6)) && (p_para_data->elec_meter_param.control_mode == 1))
    {
        //把最大放电限制功率发至MCU2
        BIT_SET(p_web_control->xiaoju_param_set_flag, 4);
        BIT_CLR(p_param->param_set_falg, 6);
    } 
}

/**
 * @brief    获取本地储能柜SN
 * @return   执行状态0：失败；1：成功
 */
char *energy_cabinet_sn_get(void)
{
    mqtt_dev_info_t *p_dev_info = NULL;
    p_dev_info = mqtt_dev_info_get();
    
    return (char *)p_dev_info->dev_sn;
}

/**
 * @brief    获取计量电表2 SN
 * @return   执行状态0：失败；1：成功
 */
char *energy_meter2_sn_get(void)
{
    mqtt_dev_info_t *p_dev_info = NULL;
    p_dev_info = mqtt_dev_info_get();
    
    return (char *)p_dev_info->meter2_sn;
}


/**
 * @brief    获取计量电表3 SN
 * @return   执行状态0：失败；1：成功
 */
char *energy_meter3_sn_get(uint8_t meter_code)
{
    mqtt_dev_info_t *p_dev_info = NULL;
    p_dev_info = mqtt_dev_info_get();
    
    return (char *)p_dev_info->meter3_sn[meter_code];
}


/**
 * @brief    获取本地储能柜 PCS SN
 * @return   执行状态0：失败；1：成功
 */
char *pcs_sn_get(void)
{
    mqtt_dev_info_t *p_dev_info = NULL;
    p_dev_info = mqtt_dev_info_get();

    return (char *)p_dev_info->pcs_sn;
}


/**
 * @brief  小桔数据循环更新
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
static void *mqtt_iothub_data_get_func(void *arg)
{
	sleep(1);							    // 线程,上电延时1s启动

	while(1)
	{   	
        mqtt_iothub_get_cmu_data();         //定时获取储能柜参数，主要是BMS和PCS
        mqtt_iothub_get_cmu_event();        //获取储能柜事件
        mqtt_iothub_set_cmu_param();        //设置储能柜参数
        mqtt_iothub_set_cmu_status();       //设置储能柜状态，开关机、充放电
		sleep(1);		
	}

	pthread_exit(NULL);

}


/**
 * @brief    针对小桔云平台需要，进行定时数据获取更新
 */
void mqtt_iothub_cmu_data_update(void)
{
	pthread_t mqtt_iothub;
	pthread_attr_t attr;

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);

	if(pthread_create(&mqtt_iothub,&attr,mqtt_iothub_data_get_func,NULL) != 0)
	{
		perror("pthread_create thread_mqtt_iothub");
	}

	pthread_attr_destroy(&attr);
	return;
}
