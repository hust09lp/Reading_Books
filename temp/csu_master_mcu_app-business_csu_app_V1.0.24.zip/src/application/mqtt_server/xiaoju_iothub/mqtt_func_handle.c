#include "sdk_public.h"
#include "sdk_log.h"
#include "sdk_shm.h"
#include "mqtt_service.h"
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include "data_types.h"
#include "data_shm.h"
#include "app_common.h"
#include "sofar_errors.h"
#include "sqlite3.h"
#include "mqtt_func_handle.h"
#include "mqtt_energy_handle.h"
#include "mqtt_cmu_data_update.h"
#include "user_timer.h"

//相关宏定义
#define ENERGY_DB "/user/data/energy/mqtt_energy.db"
#define ENERGY_METER2_DB "/user/data/energy/mqtt_energy_meter2.db"
#define ENERGY_METER3_DB "/user/data/energy/mqtt_energy_meter3.db"

static uint32_t g_payload_id = 0;             //mqtt payload消息序列号

typedef struct{
    uint8_t sign_flag;                  //签到完成标志
    uint8_t mqtt_busy;                  //mqtt数据繁忙标志
    uint8_t mqtt_hb_miss_cnt;           //监测心跳丢失计数
    uint8_t connect_status;             //连接状态
    uint32_t mqtt_status_tick;          //用于发送超时计时
    uint32_t reconnect_cnt;             //重连次数
    uint32_t reconnect_timeout;         //重连间隔时间
}mqtt_dev_attr_t;

static mqtt_dev_attr_t g_mqtt_attr = {0};

#define MAX_TIMER                       1
enum{
    MQTT_RECONNECT_TIMER = 0,
};

#define TIME_OUT_2_SEC			(2)			    // 2s超时
#define TIME_OUT_20_SEC			(20 * 1000)			// 20s超时
#define TIME_OUT_30_SEC			(30 * 1000)			// 30s超时
#define TIME_OUT_60_SEC			(60 * 1000)			// 60s超时
#define TIME_OUT_120_SEC		(120 * 1000)		// 120s超时

static sdk_rtc_t g_operating_time[MAX_TIMER];       // 保存上次记录的时间点

static uint16_t mqtt_payload_pack(uint16_t cmd_code, uint32_t payload_id, uint8_t *p_data, uint32_t data_len, uint8_t *p_out);

/**
 * @brief 时间转换
 */
static uint8_t hex_byte_cover_dec(uint8_t byte)
{
   uint8_t str[3] = {0};
   uint8_t H, L;

   if(byte > 9)
   {
      sprintf((char *)str, "%d", byte);

      H = str[0] - 0x30;
      L = str[1] - 0x30;

      return (H << 4 | L);
   }
   return byte;
}

/**
 * @brief   获取保存上次记录时间点的全局变量的指针
 * @param   index:编号
 * @return  (static修饰的)全局变量的地址作为返回值
 */
static sdk_rtc_t *operating_time_get(uint8_t index)
{
    return (&g_operating_time[index]);
}

/**
 * @brief   运行数据时间记录
 * @param   [in] p_rtc_time 当前的RTC时间结构体指针
 * @note    g_operating_time_record 记录保存运行的时间
 * @return  [int32_t] 执行结果
 * @retval  0: 成功
 * @retval  -1: 失败
 */
static int32_t operating_time_set(sdk_rtc_t *p_rtc_time, uint8_t index)
{
    int32_t ret = 0;
    sdk_rtc_t *p_record = operating_time_get(index);

    if (p_record == NULL || p_rtc_time == NULL)
    {
        ret = -1;
    }
    else
    {
        p_record->tm_year = p_rtc_time->tm_year;
        p_record->tm_mon = p_rtc_time->tm_mon;
        p_record->tm_day = p_rtc_time->tm_day;
        p_record->tm_hour = p_rtc_time->tm_hour;
        p_record->tm_min = p_rtc_time->tm_min;
        p_record->tm_sec = p_rtc_time->tm_sec;
        p_record->tm_weekday = p_rtc_time->tm_weekday;
    }

    MQTT_DEBUG_PRINT((int8_t *)"\n [%s:%d] operating_time_record_set[%d], ret = %d \n", __func__, __LINE__, index, ret);

    return ret;
}


/**
 * @brief  	获取mqtt连接状态信息
 * @return 	0：在线 1：离线
 */
uint8_t mqtt_attr_connect_status_get(void)
{
    return g_mqtt_attr.connect_status;
}


/**
 * @brief  	设置mqtt连接状态信息
 * @return 	0：在线 1：离线
 */
void mqtt_attr_connect_status_set(uint8_t connect_status)
{
    g_mqtt_attr.connect_status = connect_status;
}




/**
 * @brief  	检测设备是否离线
 * @return 	0：在线 1：离线
 */
static uint8_t mqtt_is_offline(void)
{
    web_control_info_t *sdk_shm_web_data = shm_web_control_info_get();
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get();

    if(g_mqtt_attr.mqtt_hb_miss_cnt > MQTT_SET_OFFLINE_HB_MISS_CNT)
    {
        g_mqtt_attr.connect_status = MQTT_OFF_LINE;
        if(p_para_data->elec_meter_param.control_mode)
        {
            MQTT_DEBUG_PRINT((int8_t *)"dev offline, switch to local control");
            //需要更新控制数据
            memcpy(&sdk_shm_web_data->elec_meter_param, &p_para_data->elec_meter_param, sizeof(elec_meter_param_config_t));
            sdk_shm_web_data->elec_meter_param.control_mode = 0;        //切换至本地模式运行
            BIT_SET(sdk_shm_web_data->cabinet_param_update_flag, 6);    //设置通知MCU2
        }
        return 1;
    }
    return 0;
}

/**
 * @brief  	获取payload id
 * @return 	payload id
 */
static uint32_t mqtt_get_payload_id(void)
{
    g_payload_id++;
    return ((g_payload_id == 0xFFFFFFFF) ? 0 : g_payload_id);
}


/**
 * @brief  	获取当前payload id，用于对ACK进行序列号校验
 * @return 	payload id
 */
static uint32_t mqtt_get_curr_payload_id(void)
{
    return g_payload_id;
}


/**
 * @brief  	计算累计除模校验
 * @param  	[in] p_data:数据内容
 * @param  	[in] data_len：数据长度
 * @return 	[uint16_t] 校验值
 */
static uint16_t mqtt_get_payload_check_sum(uint8_t *p_data, uint16_t data_len)
{
    uint32_t sum = 0;

    for(uint16_t i = 0; i < data_len; i++)
    {
        sum += p_data[i];
    }

    return (sum % 127);
}

/**
 * @brief  	同步云端系统时间
 * @param  	[in] p_date:数据内容
 * @return 
 */
static void sync_sys_time(uint8_t *p_date)
{
    char ymd[32] = {0};          //年月日
    char hms[32] = {0};          //时分秒
    char cmd[128];

    web_control_info_t *p_web_control = shm_web_control_info_get();

    sprintf(ymd, "%02x%02x-%02x-%02x", p_date[0], p_date[1], p_date[2], p_date[3]);
    sprintf(hms, "%02x:%02x:%02x", p_date[4], p_date[5], p_date[6]);

    MQTT_DEBUG_PRINT((int8_t *)"sync sys time, %s %s", ymd, hms);

    sprintf(cmd,"date -s \"%s %s\"", ymd, hms);
    system(cmd);
    system("hwclock -w");
    
    //同时给MCU2和CMU同步系统时间
    BIT_SET(p_web_control->system_param_flag, 2);
    BIT_SET(p_web_control->system_param_flag, 4);
}


/**
 * @brief  	云端设置储能柜参数回复
 * @param  	[in] param_set_falg:设置字段标志
* @param  	[in] success_falg:设置字段成功标志，按bit进行判断打包
 * @param  	[in] msg_id:消息ID
 * @return 
 */
static uint8_t energy_cabinet_param_set_ack(uint8_t param_set_falg, uint8_t success_falg, uint32_t msg_id)
{
    uint8_t param_data[MQTT_PARAM_SET_ACK_DATA_LEN] = {0};
    uint8_t *p_param_ack_payload = NULL;
    uint16_t param_ack_payload_len = 0;
    uint8_t i = 0;
    uint8_t pos = 0;
    mqtt_dev_info_t *p_dev_info = NULL;
    
    p_dev_info = mqtt_dev_info_get();
    memcpy(param_data, p_dev_info->clientID, strlen(p_dev_info->clientID));
    pos += 32;
    memcpy(&param_data[pos], energy_cabinet_sn_get(), strlen(energy_cabinet_sn_get()));
    pos += 32;
    for(i = 0; i < 8; i++)
    {
        if(BIT_GET(param_set_falg, i))
        {
            if(BIT_GET(success_falg, i))          //设置成功
            {
                param_data[pos] = ((CHARGE_CMD + i) >> 0) & 0xFF;
                param_data[pos + 1] = ((CHARGE_CMD + i) >> 8) & 0xFF;
            }
            else
            {
                param_data[pos] = ((CHARGE_CMD + i) >> 0) & 0xFF;
                param_data[pos + 1] = ((CHARGE_CMD + i) >> 8) & 0xFF;
                param_data[pos + 2] = (MQTT_DEV_ENERGY_FAULT >> 0) & 0xFF;
                param_data[pos + 3] = (MQTT_DEV_ENERGY_FAULT >> 8) & 0xFF;
                BIT_CLR(param_set_falg, i);
            }
            pos += 4;
        }
    }

    p_param_ack_payload = malloc(MQTT_PAYLOAD_BASIC_LEN + pos);
    if(p_param_ack_payload == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"malloc error");
        return MOSQ_ERR_NOMEM;
    }

    param_ack_payload_len = mqtt_payload_pack(MQTT_DEV_SET_PARAM_ACK, msg_id, param_data, pos, p_param_ack_payload);
    mosquitto_mqtt_pubscribe(get_curr_mosquitto_fd(), p_param_ack_payload, param_ack_payload_len);

    free(p_param_ack_payload);

    return param_set_falg;
}



/**
 * @brief  	云端设置储能柜参数
 * @param  	[in] p_data:数据内容
 * @param  	[in] data_len:数据长度
 * @return 
 */
static void energy_cabinet_param_set(uint8_t *p_data, uint16_t data_len, uint32_t msg_id)
{
    uint8_t param_type_num = 0;
    uint16_t param_type = 0;
    uint32_t param_value = 0;
    uint8_t param_set_falg = 0;                 //设置完成后对应bit置1
    common_data_t *shm = NULL;
	energy_cabinet_param_t *p_param = NULL;
    uint8_t energy_cabinet_status = 0;


	shm = sdk_shm_get();
    energy_cabinet_status = shm->mqtt_data.energy_cabinet_status;
	p_param = &shm->mqtt_data.energy_cabinet_param;
	if(p_param == NULL)
	{
		MQTT_DEBUG_PRINT((int8_t *)"\n [%s:%d] data is NULL\n",__func__, __LINE__);
		return;
	}
    //如若处于本地模式则执行模式切换
    web_control_info_t *sdk_shm_web_data = shm_web_control_info_get();
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get();

    // if(p_para_data->elec_meter_param.control_mode == 0)
    // {
    //     MQTT_DEBUG_PRINT((int8_t *)"dev online, switch to remote control");
    //     //需要更新控制数据
    //     memcpy(&sdk_shm_web_data->elec_meter_param, &p_para_data->elec_meter_param, sizeof(elec_meter_param_config_t));
    //     sdk_shm_web_data->elec_meter_param.control_mode = 1;        //切换至云端模式运行
    //     BIT_SET(sdk_shm_web_data->cabinet_param_update_flag, 6);    //设置通知MCU2
    // }
      
    //计算参数类型数量
    param_type_num = (data_len - 64) / PARAM_LEN;
    MQTT_DEBUG_PRINT((int8_t *)"param_type_num is %d\n", param_type_num);
    p_data = p_data + 64;
    for(uint8_t i = 0; i < param_type_num; i++)
    {
        param_type = *(uint16_t *)&p_data[i * PARAM_LEN];
        param_value = *(uint32_t *)&p_data[i * PARAM_LEN + 2];
        MQTT_DEBUG_PRINT((int8_t *)"param_type is %d\n", param_type);
        MQTT_DEBUG_PRINT((int8_t *)"param_value is %d\n", param_value);

        switch(param_type)
        {
            case CHARGE_CMD:
                p_param->chargr_cmd = param_value;
                BIT_SET(p_param->param_set_falg, 0);
                if(energy_cabinet_status == 3)          //处于故障状态
                {
                    break;
                }
                BIT_SET(param_set_falg, 0);
                break;

            case MONOMER_CHARGE_LIMIT_VOLT:
                p_param->monomer_charge_limit_volt = param_value;
                BIT_SET(p_param->param_set_falg, 1);
                if((param_value >= MQTT_ENERGY_MIN_CHARGE_LIMIT) && (param_value <= MQTT_ENERGY_MAX_CHARGE_LIMIT))
                {
                    BIT_SET(param_set_falg, 1);
                }
                break;

            case CHARGE_LIMIT_SOC:
                p_param->charge_limit_soc = param_value;
                BIT_SET(p_param->param_set_falg, 2);
                if((param_value >= MQTT_ENERGY_MIN_CHARGE_SOC) && (param_value <= MQTT_ENERGY_MAX_CHARGE_SOC))
                {
                    BIT_SET(param_set_falg, 2);
                }
                break;

            case CLUSTER_CHARGE_LIMIT_MAX_POWER:
                if((param_value < MQTT_ENERGY_MIN_POWER) || (param_value > MQTT_ENERGY_MAX_POWER))
                {
                    p_param->cluster_charge_limit_max_power = MQTT_ENERGY_MAX_POWER;
                }
                else
                {
                    p_param->cluster_charge_limit_max_power = param_value;
                }
                BIT_SET(p_param->param_set_falg, 3);
                BIT_SET(param_set_falg, 3);
                break;

            case MONOMER_DISCHARGE_LIMIT_VOLT:
                p_param->monomer_discharge_limit_volt = param_value;
                BIT_SET(p_param->param_set_falg, 4);
                if((param_value >= MQTT_ENERGY_MIN_DISCHARGE_LIMIT) && (param_value <= MQTT_ENERGY_MAX_DISCHARGE_LIMIT))
                {
                    BIT_SET(param_set_falg, 4);
                }
                break;

            case DISCHARGE_LIMIT_SOC:
                p_param->discharge_limit_soc = param_value;
                BIT_SET(p_param->param_set_falg, 5);
                if((param_value >= MQTT_ENERGY_MIN_DISCHARGE_SOC) && (param_value <= MQTT_ENERGY_MAX_DISCHARGE_SOC))
                {
                    BIT_SET(param_set_falg, 5);
                }
                break;

            case CLUSTER_DISCHARGE_LIMIT_MAX_POWER:
                if((param_value < MQTT_ENERGY_MIN_POWER) || (param_value > MQTT_ENERGY_MAX_POWER))
                {
                    p_param->cluster_discharge_limit_max_power = MQTT_ENERGY_MAX_POWER;
                }
                else
                {
                    p_param->cluster_discharge_limit_max_power = param_value;
                }
                BIT_SET(p_param->param_set_falg, 6);
                BIT_SET(param_set_falg, 6);
                break;

            case DEV_RUN_MODE:
                //需要更新控制数据
                memcpy(&sdk_shm_web_data->elec_meter_param, &p_para_data->elec_meter_param, sizeof(elec_meter_param_config_t));
                sdk_shm_web_data->elec_meter_param.control_mode = param_value - 1;      //切换运行模式
                BIT_SET(sdk_shm_web_data->cabinet_param_update_flag, 6);                //设置通知MCU2
                BIT_SET(p_param->param_set_falg, 7);
                BIT_SET(param_set_falg, 7);
                break;

            default:
                break;
        }
    }
    //执行ACK
    p_param->param_set_falg = energy_cabinet_param_set_ack(p_param->param_set_falg, param_set_falg, msg_id);
    MQTT_DEBUG_PRINT((int8_t *)"param_set_falg:%d", p_param->param_set_falg);
}


/**
 * @brief  	云端读取计量表充放电电能数据回复
 * @param  	[in] p_charge:充电量
 * @param  	[in] p_discharge:放电量
 * @param  	[in] msg_id:报文ID
 * @return 
 */
static uint8_t energy_data_read_ack(uint8_t *p_msg_data, uint32_t data_len, uint32_t msg_id, uint8_t *p_date)
{
    uint8_t *p_energy_payload = NULL;
    uint8_t *p_energy_data = NULL;
    uint32_t energy_payload_len = 0;
    uint32_t energy_data_len = 0;
    uint32_t pos = 0;
    mqtt_dev_info_t *p_dev_info = NULL;

    //智能终端编码：32byte  日期：8byte  光伏电表数量：2byte
    energy_data_len =  data_len + 42;
    p_energy_data = malloc(energy_data_len);
    if(p_energy_data == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"malloc error");
        return MOSQ_ERR_INVAL;
    }
    
    p_dev_info = mqtt_dev_info_get();
    memcpy(p_energy_data, p_dev_info->clientID, strlen(p_dev_info->clientID));
    pos += 32;

    p_energy_data[pos++] = p_date[0];
    p_energy_data[pos++] = p_date[1];
    p_energy_data[pos++] = p_date[2];
    p_energy_data[pos++] = p_date[3];
    p_energy_data[pos++] = p_date[4];
    p_energy_data[pos++] = p_date[5];
    p_energy_data[pos++] = p_date[6];
    p_energy_data[pos++] = 0xFF;

    //光伏电表数量,暂没有
    p_energy_data[pos++] = 0;
    p_energy_data[pos++] = 0;  

    memcpy(&p_energy_data[pos],  p_msg_data, data_len);

    p_energy_payload = malloc(energy_data_len + MQTT_PAYLOAD_BASIC_LEN);
    if(p_energy_payload == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"malloc error");
        free(p_energy_data);
        return MOSQ_ERR_INVAL;
    }

    energy_payload_len = mqtt_payload_pack(MQTT_DEV_GET_ENERGY_ACK, msg_id, p_energy_data, energy_data_len, p_energy_payload);
    mosquitto_mqtt_pubscribe(get_curr_mosquitto_fd(), p_energy_payload, energy_payload_len);
    free(p_energy_payload);
    free(p_energy_data);

    return MOSQ_ERR_SUCCESS;
}


/**
 * @brief  	获取某天之前的最后一条数据
 * @param  	[in] p_date:日期
 * @param  	[out] p_charge:充电数据
 * @param  	[out] p_discharge:放电数据
 * @param  	[in] meter_code:电表编号
 * @return 
 */
static int get_charge_discharge_data_from_day(char *p_path, char *p_date, uint32_t *p_charge, uint32_t *p_discharge, uint8_t meter_code)
{
    sqlite3 *db = NULL;
    sqlite3_stmt *stmt = NULL;
    const char *sql = "SELECT * FROM charge_data WHERE date < ? ORDER BY date DESC LIMIT 1;";
    int rc;

    rc = sqlite3_open(p_path, &db);
    if (rc != SQLITE_OK)
    {
        fprintf(stderr, "Cannot open database: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return 1;
    }
 
    
    rc = sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
 
    if (rc != SQLITE_OK) 
    {
        fprintf(stderr, "Failed to prepare statement: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return 1;
    }
 
    sqlite3_bind_text(stmt, 1, p_date, -1, SQLITE_TRANSIENT);
 
    while ((rc = sqlite3_step(stmt)) == SQLITE_ROW) 
    {
		*p_charge = sqlite3_column_int(stmt, meter_code * 2 - 1);
		*p_discharge = sqlite3_column_int(stmt, meter_code * 2);
    }
 
    sqlite3_finalize(stmt);
    sqlite3_close(db);
 
    return 0;
}


/**
 * @brief  	校验数据合法性，对缺失的数据进行补全
 * @param  	[in] p_path:路径
 * @param  	[in] p_date:日期
 * @param  	[out] p_charge:充电数据
 * @param  	[out] p_discharge:放电数据
 * @param  	[in] meter_code:电表编号
 * @return 
 */
static void charge_discharge_data_check(char *p_path, char *p_date, uint32_t *p_charge, uint32_t *p_discharge, uint8_t meter_code)
{
    uint32_t last_charge = 0;
    uint32_t last_discharge = 0;

    //如果第一个点位是0则读取数据库当天之前的最后一条数据
    if(p_charge[0] == 0 || p_discharge[0] == 0)
    {
        get_charge_discharge_data_from_day(p_path, p_date, &last_charge, &last_discharge, meter_code);
    }
    //如果中间数据点位是0则使用上一个点位数据
    for(uint8_t i = 0; i < 97; i++)
    {
        if(p_charge[i] == 0)
        {
            p_charge[i] = last_charge;
        }
        else
        {
            last_charge = p_charge[i];
        }

        if(p_discharge[i] == 0)
        {
            p_discharge[i] = last_discharge;
        }
        else
        {
            last_discharge = p_discharge[i];
        }
    }
}


/**
 * @brief  	云端读取计量表充放电电能数据
 * @param  	[in] p_data:数据内容
 * @param  	[in] data_len:数据长度
 * @param  	[in] msg_id:报文ID
 * @return 
 */
static void energy_data_read(uint8_t *p_data, uint16_t data_len, uint32_t msg_id)
{
    char time[32] = {0};
    uint32_t charge[97] = {0};
    uint32_t discharge[97] = {0};
    uint8_t *p_msg_data = NULL;
    uint32_t msg_data_len = 0;
    uint32_t pos = 0;
    uint32_t i = 0;
    constant_parameter_data_t *p_constant_param = sdk_shm_constant_parameter_data_get();

    //每台设备必须存在电表1和电表2，电表数量不确定
    //一个电表字节数：1584（32 + 97 * 8 *2），另外每种电表数量占2个字节
    msg_data_len = 1584 * (p_constant_param->elec_meter_param.elec_meter3_cnt + 2) + 4;
    p_msg_data = malloc(msg_data_len);
    if(p_msg_data == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"malloc error");
        return;
    }
    memset(p_msg_data, 0, msg_data_len);
    p_data = p_data + 32;
    sprintf(time, "%02x%02x-%02x-%02x", p_data[0], p_data[1], p_data[2], p_data[3]);
    MQTT_DEBUG_PRINT((int8_t *)"time:%s", time);
    //按照协议读取打包电表数据
    //首先读取市电电表2
    //获取数据库数据并按照点位插入数据
    select_charge_discharge(ENERGY_METER2_DB, (uint8_t *)time, charge, discharge);
    //校验数据合法性
    charge_discharge_data_check(ENERGY_METER2_DB, time, charge, discharge, 1);

    p_msg_data[pos++] = 1 + p_constant_param->elec_meter_param.elec_meter3_cnt;
    p_msg_data[pos++] = 0;
    memcpy(&p_msg_data[pos], energy_meter2_sn_get(), strlen(energy_meter2_sn_get()));
    pos += 32;
    //填充充电电能数据
    for(i = 0; i < 97; i++)
    {
        memcpy(&p_msg_data[pos], &charge[i], sizeof(uint32_t));
        pos += 8;
    }
    //填充放电电能数据
    for(i = 0; i < 97; i++)
    {
        memcpy(&p_msg_data[pos], &discharge[i], sizeof(uint32_t));
        pos += 8;
    }
    usleep(20);
    //读取电表3数据
    for(uint8_t j = 0; j < p_constant_param->elec_meter_param.elec_meter3_cnt; j++)
    {
        memset(charge, 0, sizeof(uint32_t) * 97);
        memset(discharge, 0, sizeof(uint32_t) * 97);
        //获取数据库数据并按照点位插入数据
        select_charge_discharge_meter3(ENERGY_METER3_DB, (uint8_t *)time, charge, discharge, j + 1);
        //校验数据合法性
        charge_discharge_data_check(ENERGY_METER3_DB, time, charge, discharge, j + 1);
        memcpy(&p_msg_data[pos], energy_meter3_sn_get(j), strlen(energy_meter3_sn_get(j)));
        pos += 32;
        //填充充电电能数据
        for(i = 0; i < 97; i++)
        {
            memcpy(&p_msg_data[pos], &charge[i], sizeof(uint32_t));
            pos += 8;
        }
        //填充放电电能数据
        for(i = 0; i < 97; i++)
        {
            memcpy(&p_msg_data[pos], &discharge[i], sizeof(uint32_t));
            pos += 8;
        }   
    }

    //读取储能电表数据
    memset(charge, 0, sizeof(uint32_t) * 97);
    memset(discharge, 0, sizeof(uint32_t) * 97);
    //获取数据库数据并按照点位插入数据
    select_charge_discharge(ENERGY_DB, (uint8_t *)time, charge, discharge);
    //校验数据合法性
    charge_discharge_data_check(ENERGY_DB, time, charge, discharge, 1);
    p_msg_data[pos++] = 1;
    p_msg_data[pos++] = 0;
    memcpy(&p_msg_data[pos], energy_cabinet_sn_get(), strlen(energy_cabinet_sn_get()));
    pos += 32;
    //填充充电电能数据
    for(i = 0; i < 97; i++)
    {
        memcpy(&p_msg_data[pos], &charge[i], sizeof(uint32_t));
        pos += 8;
    }
    //填充放电电能数据
    for(i = 0; i < 97; i++)
    {
        memcpy(&p_msg_data[pos], &discharge[i], sizeof(uint32_t));
        pos += 8;
    }
    //执行ACK
    energy_data_read_ack(p_msg_data, pos, msg_id, p_data);
    free(p_msg_data);
}


/**
 * @brief  	mqtt数据内容解包
 * @param   [in] mosq：mosquitto客户端句柄
 * @param  	[in] p_data：数据内容
 * @param  	[in] data_len：数据长度
 * @return 	
 */
void mqtt_data_unpack(struct mosquitto *mosq, uint8_t *p_data, uint16_t data_len)
{
    uint16_t cmd_code = 0;
    uint32_t msg_id = 0;
    sdk_rtc_t rtc_time = {0};
    static uint8_t timer_init_flag = 0;

    MQTT_DEBUG_PRINT((int8_t *)"recv frame:");
    print_frame(p_data, data_len);

    // mqtt_set_free();
    g_mqtt_attr.reconnect_cnt = 0;
    g_mqtt_attr.reconnect_timeout = 0;

    //校验payload id,对于下发的设置指令，不需要检验消息ID
    msg_id = *(uint32_t *)&p_data[8];
    if((*(uint16_t *)&p_data[MQTT_CMD_POS] != MQTT_DEV_SET_PARAM) && (*(uint16_t *)&p_data[MQTT_CMD_POS] != MQTT_DEV_GET_ENERGY))
    {
        if(msg_id != mqtt_get_curr_payload_id())
        {
            MQTT_DEBUG_PRINT((int8_t *)"payload id check error");
            // return;
        }
    }

    //校验累计校验值
    if(*(uint16_t *)&p_data[data_len - 2] != mqtt_get_payload_check_sum(&p_data[12], data_len - 14))
    {
        MQTT_DEBUG_PRINT((int8_t *)"check sum check error");
    }

    cmd_code = *(uint16_t *)&p_data[MQTT_CMD_POS];
    MQTT_DEBUG_PRINT((int8_t *)"[download]cmd_code = %d", cmd_code);

    switch(cmd_code)
    {
        case MQTT_DEV_SIGN_IN_ACK:
            g_mqtt_attr.sign_flag = 1;
            //进行系统时间同步
            sync_sys_time(&p_data[MQTT_DATA_POS]);
            //进行定时rtc时间初始化
            sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
            if(!timer_init_flag)
            {
                sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
                for(uint8_t i = 0; i < MAX_TIMER; i++)
                {
                    operating_time_set(&rtc_time, i);
                }
                timer_init_flag = 1;
            }
            break;

        case MQTT_DEV_HB_ACK:
            g_mqtt_attr.mqtt_hb_miss_cnt = 0;
            break;

        case MQTT_DEV_ENERGY_METER_DATA_ACK:
        case MQTT_DEV_BMS_DATA_ACK:
        case MQTT_DEV_PCS_DATA_ACK:
        case MQTT_DEV_ENERGY_METER2_DATA_ACK:
        case MQTT_DEV_ALL_METER_DATA_ACK:
        case MQTT_DEV_EVENT_ACK:
        case MQTT_DEV_WARN_ACK:
            break;

        case MQTT_DEV_SET_PARAM:
            energy_cabinet_param_set(&p_data[MQTT_DATA_POS], data_len - MQTT_PAYLOAD_BASIC_LEN, msg_id);
            break;

        case MQTT_DEV_GET_ENERGY:
            energy_data_read(&p_data[MQTT_DATA_POS], data_len - MQTT_PAYLOAD_BASIC_LEN, msg_id);
            break;

        default:
            break;
    }
}


/**
 * @brief  	mqtt数据内容打包
 * @param  	[in] cmd_code：命令代码
 * @param  	[in] payload_id：消息ID
 * @param  	[in] p_data：数据内容
 * @param  	[in] data_len：数据长度
 * @param  	[out] p_out：paylaod数据
 * @return 	[int32_t] 长度
 */
static uint16_t mqtt_payload_pack(uint16_t cmd_code, uint32_t payload_id, uint8_t *p_data, uint32_t data_len, uint8_t *p_out)
{
    uint32_t len = 0;
    uint16_t check_sum = 0;
    uint32_t pos = 0;

    if((p_data == NULL) || (p_out == NULL))
    {
        MQTT_DEBUG_PRINT((int8_t *)"param error");
        return SF_ERR_PARA;
    }
    //起始域，指定设备商，首航暂时没有
    p_out[pos++] = 0x0C;
    p_out[pos++] = 0x00;
    //长度域
    len = MQTT_PAYLOAD_BASIC_LEN + data_len;
    p_out[pos++] = len & 0xFF;
    p_out[pos++] = len >> 8;
    //版本域,按照示例填写
    p_out[pos++] = 0x04;
    p_out[pos++] = 0x01;
    p_out[pos++] = 0x00;
    p_out[pos++] = 0x01;
    //序号域
    p_out[pos++] = (payload_id >> 0) & 0xFF;
    p_out[pos++] = (payload_id >> 8) & 0xFF;
    p_out[pos++] = (payload_id >> 16) & 0xFF;
    p_out[pos++] = (payload_id >> 24) & 0xFF;
    //命令代码
    p_out[pos++] = (cmd_code >> 0) & 0xFF;
    p_out[pos++] = (cmd_code >> 8) & 0xFF;
    //数据域
    memcpy(&p_out[pos], p_data, data_len);
    //校验和,从命令代码字段开始计算
    check_sum = mqtt_get_payload_check_sum(&p_out[12], data_len + 2);
    p_out[pos + data_len] = (check_sum >> 0) & 0xFF;
    p_out[pos + data_len + 1] = (check_sum >> 8) & 0xFF;

    MQTT_DEBUG_PRINT((int8_t *)"[upload]cmd_code:%d", cmd_code);
    MQTT_DEBUG_PRINT((int8_t *)"[upload]payload:");
    print_frame(p_out, len);

    return len;
}


/**
 * @brief  	上报签到信息
 * @return 	0:成功，其他：失败
 */
uint8_t mqtt_dev_sign_in(struct mosquitto *mosq)
{
    uint8_t sign_data[MQTT_SIGN_DATA_LEN] = {0};
    sdk_rtc_t rtc_time = {0};
    int32_t ret;
    char cmd[256] = {0};
    uint8_t dev_mac[32] = {0};
    uint8_t dev_ip[32] = {0};
    char tmp_buff[32] = {0};
    FILE *fp;
    uint8_t *p_sign_payload = NULL;
    uint16_t sign_payload_len = 0;
    mqtt_dev_info_t *p_dev_info = NULL;
    uint16_t pos = 0;
    
    p_dev_info = mqtt_dev_info_get();
    //获取系统时钟时间
    ret = sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
    if (ret != SF_OK)
    {
        MQTT_DEBUG_PRINT((int8_t *)"rtc get failed");
    }

    //获取MAC地址
    snprintf(cmd, 256, "ifconfig eth1 | awk '/HWaddr/{ print $5 }'");
	fp = popen(cmd,"r");

	fread(dev_mac, 1, sizeof(dev_mac), fp);
	MQTT_DEBUG_PRINT((int8_t *)"mac:%s", dev_mac);
    pclose(fp);

    //获取IP地址
    snprintf(cmd, 256, "ip addr show eth1 | awk '/inet/{print substr($2,1)}'");
	fp = popen(cmd,"r");

    while (fgets(tmp_buff, sizeof(tmp_buff), fp));
    char *tmp_str = strchr(tmp_buff, '/');
    int8_t len = tmp_str - tmp_buff;
    memcpy(dev_ip, tmp_buff, len);
    MQTT_DEBUG_PRINT((int8_t *)"ip:%s", dev_ip);
    pclose(fp);

    memcpy(sign_data, p_dev_info->clientID, strlen(p_dev_info->clientID));
    pos += 32;
    sign_data[pos++] = 0x20;
	sign_data[pos++] = hex_byte_cover_dec(rtc_time.tm_year);
    sign_data[pos++] = hex_byte_cover_dec(rtc_time.tm_mon);
    sign_data[pos++] = hex_byte_cover_dec(rtc_time.tm_day);
    sign_data[pos++] = hex_byte_cover_dec(rtc_time.tm_hour);
    sign_data[pos++] = hex_byte_cover_dec(rtc_time.tm_min);
    sign_data[pos++] = hex_byte_cover_dec(rtc_time.tm_sec);
    sign_data[pos++] = 0xFF;
    memcpy(sign_data + pos, dev_mac, strlen((char *)dev_mac));
    pos += 32;
    memcpy(sign_data + pos, dev_ip, strlen((char *)dev_ip));

    p_sign_payload = malloc(MQTT_PAYLOAD_BASIC_LEN + sizeof(sign_data));
    if(p_sign_payload == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"malloc error");
        return MOSQ_ERR_NOMEM;
    }

    sign_payload_len = mqtt_payload_pack(MQTT_DEV_SIGN_IN, mqtt_get_payload_id(), sign_data, sizeof(sign_data), p_sign_payload);

    mosquitto_mqtt_pubscribe(mosq, p_sign_payload, sign_payload_len);

    free(p_sign_payload);

    return MOSQ_ERR_SUCCESS;
}


/**
 * @brief  	获取心跳 id
 * @return 	hb id
 */
static uint32_t mqtt_get_hb_id(void)
{
    static uint32_t hb_id = 0;

    hb_id++;
    return ((hb_id == 0xFFFFFFFF) ? 0 : hb_id);
}


/**
 * @brief  	上报心跳信息
 * @return 	0:成功，其他：失败
 */
static uint8_t mqtt_dev_hb(void)
{
    uint8_t hb_data[MQTT_HB_DATA_LEN] = {0};
    uint8_t *p_hb_payload = NULL;
    uint16_t hb_payload_len = 0;
    uint32_t hb_id = 0;
    mqtt_dev_info_t *p_dev_info = NULL;
    
    p_dev_info = mqtt_dev_info_get();
    memcpy(hb_data, p_dev_info->clientID, strlen(p_dev_info->clientID));
    hb_id = mqtt_get_hb_id();
    hb_data[32] = (hb_id >> 0) & 0xFF;
    hb_data[33] = (hb_id >> 8) & 0xFF;
    hb_data[34] = (hb_id >> 16) & 0xFF;
    hb_data[35] = (hb_id >> 24) & 0xFF;

    p_hb_payload = malloc(MQTT_PAYLOAD_BASIC_LEN + sizeof(hb_data));
    if(p_hb_payload == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"malloc error");
        return MOSQ_ERR_INVAL;
    }

    hb_payload_len = mqtt_payload_pack(MQTT_DEV_HB, mqtt_get_payload_id(), hb_data, sizeof(hb_data), p_hb_payload);

    mosquitto_mqtt_pubscribe(get_curr_mosquitto_fd(), p_hb_payload, hb_payload_len);
    g_mqtt_attr.mqtt_hb_miss_cnt++;
    free(p_hb_payload);

    return MOSQ_ERR_SUCCESS;

}


/**
 * @brief  	上报储能柜计量表数据
 * @return 	0:成功，其他：失败
 */
static uint8_t mqtt_dev_energy_meter_data_upload(void)
{
    uint8_t energy_meter_data[MQTT_ENERGY_METER_DATA_LEN] = {0};
    uint8_t *p_energy_meter_payload = NULL;
    uint16_t energy_meter_payload_len = 0;
    common_data_t *shm = NULL;
	energy_cabinet_meter_data_t *p_energy_meter_data = NULL;
    mqtt_dev_info_t *p_dev_info = NULL;
    uint16_t pos = 0;
    
    p_dev_info = mqtt_dev_info_get();
	shm = sdk_shm_get();
	p_energy_meter_data = &shm->mqtt_data.energy_meter_data;
	if(p_energy_meter_data == NULL)
	{
		MQTT_DEBUG_PRINT((int8_t *)"\n [%s:%d] energy data is NULL\n",__func__, __LINE__);
		return MOSQ_ERR_NOMEM;
	}

    memcpy(energy_meter_data, p_dev_info->clientID, strlen(p_dev_info->clientID));
    pos += 32;
    memcpy(&energy_meter_data[pos], energy_cabinet_sn_get(), strlen(energy_cabinet_sn_get()));
    pos += 32;
    memcpy(&energy_meter_data[pos], &p_energy_meter_data->active_power_a, sizeof(uint32_t) * 14);
    pos += 56;
    memcpy(&energy_meter_data[pos], &p_energy_meter_data->negative_active_energy_total, sizeof(uint32_t) * 10);
    pos += 40;
    memcpy(&energy_meter_data[pos], &p_energy_meter_data->positive_active_energy_total, sizeof(uint32_t) * 10);
    pos += 40;
    memcpy(&energy_meter_data[pos], &p_energy_meter_data->negative_reactive_energy_total, sizeof(uint32_t) * 10);
    pos += 40;
    memcpy(&energy_meter_data[pos], &p_energy_meter_data->positive_reactive_energy_total, sizeof(uint32_t) * 10);
    pos += 40;
    memcpy(&energy_meter_data[pos], &p_energy_meter_data->volt_a, sizeof(uint32_t) * 7);

    p_energy_meter_payload = malloc(MQTT_PAYLOAD_BASIC_LEN + sizeof(energy_meter_data));
    if(p_energy_meter_payload == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"malloc error");
        return MOSQ_ERR_INVAL;
    }

    energy_meter_payload_len = mqtt_payload_pack(MQTT_DEV_ENERGY_METER_DATA, mqtt_get_payload_id(), energy_meter_data, MQTT_ENERGY_METER_DATA_LEN, p_energy_meter_payload);
    mosquitto_mqtt_pubscribe(get_curr_mosquitto_fd(), p_energy_meter_payload, energy_meter_payload_len);

    free(p_energy_meter_payload);

    return MOSQ_ERR_SUCCESS;

}


/**
 * @brief  	上报市电计量表2数据
 * @return 	0:成功，其他：失败
 */
static uint8_t mqtt_dev_meter2_data_upload(void)
{
    uint8_t meter2_data[MQTT_ENERGY_METER_DATA_LEN] = {0};
    uint8_t *p_meter2_payload = NULL;
    uint16_t meter2_payload_len = 0;
    common_data_t *shm = NULL;
	municipal_meter_data_t *p_meter2_data = NULL;
    mqtt_dev_info_t *p_dev_info = NULL;
    uint16_t pos = 0;
    
    p_dev_info = mqtt_dev_info_get();
	shm = sdk_shm_get();
	p_meter2_data = &shm->mqtt_data.energy_meter2_data;
	if(p_meter2_data == NULL)
	{
		MQTT_DEBUG_PRINT((int8_t *)"\n [%s:%d] energy data is NULL\n",__func__, __LINE__);
		return MOSQ_ERR_NOMEM;
	}

    memcpy(meter2_data, p_dev_info->clientID, strlen(p_dev_info->clientID));
    pos += 32;
    memcpy(&meter2_data[pos], energy_meter2_sn_get(), strlen(energy_meter2_sn_get()));
    pos += 32;
    memcpy(&meter2_data[pos], &p_meter2_data->active_power_a, sizeof(uint32_t) * 14);
    pos += 56;
    memcpy(&meter2_data[pos], &p_meter2_data->negative_active_energy_total, sizeof(uint32_t) * 10);
    pos += 40;
    // memcpy(&meter2_data[pos], &p_meter2_data->positive_active_energy_total, sizeof(uint32_t) * 10);
    memcpy(&meter2_data[pos], &p_meter2_data->negative_reactive_energy_total, sizeof(uint32_t) * 10);
    pos += 40;
    // memcpy(&meter2_data[pos], &p_meter2_data->negative_reactive_energy_total, sizeof(uint32_t) * 10);
    memcpy(&meter2_data[pos], &p_meter2_data->positive_active_energy_total, sizeof(uint32_t) * 10);
    pos += 40;
    memcpy(&meter2_data[pos], &p_meter2_data->positive_reactive_energy_total, sizeof(uint32_t) * 10);
    pos += 40;
    memcpy(&meter2_data[pos], &p_meter2_data->volt_a, sizeof(uint32_t) * 7);

    p_meter2_payload = malloc(MQTT_PAYLOAD_BASIC_LEN + sizeof(meter2_data));
    if(p_meter2_payload == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"malloc error");
        return MOSQ_ERR_INVAL;
    }

    meter2_payload_len = mqtt_payload_pack(MQTT_DEV_ENERGY_METER2_DATA, mqtt_get_payload_id(), meter2_data, MQTT_ENERGY_METER_DATA_LEN, p_meter2_payload);
    mosquitto_mqtt_pubscribe(get_curr_mosquitto_fd(), p_meter2_payload, meter2_payload_len);
    free(p_meter2_payload);

    return MOSQ_ERR_SUCCESS;

}


/**
 * @brief  	上报市电计量表3数据
 * @return 	0:成功，其他：失败
 */
static uint8_t mqtt_dev_meter3_data_upload(void)
{
    uint8_t meter3_data[MQTT_ENERGY_METER_DATA_LEN] = {0};
    uint8_t *p_meter3_payload = NULL;
    uint16_t meter3_payload_len = 0;
    common_data_t *shm = NULL;
	municipal_meter_data_t *p_meter3_data = NULL;
    mqtt_dev_info_t *p_dev_info = NULL;
    uint16_t pos = 0;
    static uint8_t meter3_cnt = 0;
    
    constant_parameter_data_t *p_constant_param = sdk_shm_constant_parameter_data_get();

    if(p_constant_param->elec_meter_param.elec_meter3_cnt == 0)
    {
        return 0;
    }

    p_dev_info = mqtt_dev_info_get();
	shm = sdk_shm_get();
	p_meter3_data = &shm->mqtt_data.energy_meter3_data[meter3_cnt];
	if(p_meter3_data == NULL)
	{
		MQTT_DEBUG_PRINT((int8_t *)"\n [%s:%d] energy data is NULL\n",__func__, __LINE__);
		return MOSQ_ERR_NOMEM;
	}

    memcpy(meter3_data, p_dev_info->clientID, strlen(p_dev_info->clientID));
    pos += 32;
    memcpy(&meter3_data[pos], energy_meter3_sn_get(meter3_cnt), strlen(energy_meter3_sn_get(meter3_cnt)));
    pos += 32;
    memcpy(&meter3_data[pos], &p_meter3_data->active_power_a, sizeof(uint32_t) * 14);
    pos += 56;
    memcpy(&meter3_data[pos], &p_meter3_data->negative_active_energy_total, sizeof(uint32_t) * 10);
    pos += 40;
    memcpy(&meter3_data[pos], &p_meter3_data->negative_reactive_energy_total, sizeof(uint32_t) * 10);
    pos += 40;
    memcpy(&meter3_data[pos], &p_meter3_data->positive_active_energy_total, sizeof(uint32_t) * 10);
    pos += 40;
    memcpy(&meter3_data[pos], &p_meter3_data->positive_reactive_energy_total, sizeof(uint32_t) * 10);
    pos += 40;
    memcpy(&meter3_data[pos], &p_meter3_data->volt_a, sizeof(uint32_t) * 7);

    p_meter3_payload = malloc(MQTT_PAYLOAD_BASIC_LEN + sizeof(meter3_data));
    if(p_meter3_payload == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"malloc error");
        return MOSQ_ERR_INVAL;
    }

    meter3_payload_len = mqtt_payload_pack(MQTT_DEV_ENERGY_METER2_DATA, mqtt_get_payload_id(), meter3_data, MQTT_ENERGY_METER_DATA_LEN, p_meter3_payload);
    mosquitto_mqtt_pubscribe(get_curr_mosquitto_fd(), p_meter3_payload, meter3_payload_len);

    free(p_meter3_payload);
    meter3_cnt++;
    
    if(meter3_cnt >= p_constant_param->elec_meter_param.elec_meter3_cnt)
    {
        meter3_cnt = 0;
    }

    return MOSQ_ERR_SUCCESS;

}


/**
 * @brief  	上报储能柜BMS数据
 * @return 	0:成功，其他：失败
 */
static uint8_t mqtt_dev_bms_data_upload(void)
{
    uint8_t *p_bms_data = NULL;
    uint16_t bms_data_len = 0;
    uint8_t *p_bms_payload = NULL;
    uint16_t bms_payload_len = 0;
    common_data_t *shm = NULL;
	bms_data_t *p_bms_shm_data = NULL;
    uint16_t pos = 0;
    mqtt_dev_info_t *p_dev_info = NULL;
    
    p_dev_info = mqtt_dev_info_get();
	shm = sdk_shm_get();
	p_bms_shm_data = &shm->mqtt_data.bms_data;
	if(p_bms_shm_data == NULL)
	{
		MQTT_DEBUG_PRINT((int8_t *)"\n [%s:%d] bms data is NULL\n",__func__, __LINE__);
		return MOSQ_ERR_NOMEM;
	}

    //根据电池组数量分配空间
    bms_data_len = MQTT_BMS_DATA_LEN                //固定长度
    + (p_bms_shm_data->pack_num * sizeof(uint32_t))     //pack电压
    + (p_bms_shm_data->pack_num * sizeof(uint32_t))     //pack电流
    + (p_bms_shm_data->pack_num * sizeof(uint32_t))     //pack功率
    + (p_bms_shm_data->pack_num * p_bms_shm_data->monomer_num * sizeof(uint16_t))       //单体电压
    + (p_bms_shm_data->pack_num * p_bms_shm_data->pack_tpoint_num * sizeof(uint16_t));  //温度采样点

    p_bms_data = malloc(bms_data_len);
    if(p_bms_data == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"malloc error");
        return MOSQ_ERR_INVAL;
    }
    memset(p_bms_data, 0, bms_data_len);
    //因为电池组数量不定，这里要分段添加
    memcpy(p_bms_data, p_dev_info->clientID, strlen(p_dev_info->clientID));
    pos += 32;
    memcpy(&p_bms_data[pos], energy_cabinet_sn_get(), strlen(energy_cabinet_sn_get()));
    pos += 32;
    memcpy(&p_bms_data[pos], &p_bms_shm_data->battery_type, MQTT_BMS_DATA_LEN - 64);
    pos += (MQTT_BMS_DATA_LEN - 64);
    memcpy(&p_bms_data[pos], &p_bms_shm_data->pack_volt, p_bms_shm_data->pack_num * sizeof(uint32_t));
    pos += p_bms_shm_data->pack_num * sizeof(uint32_t);
    memcpy(&p_bms_data[pos], &p_bms_shm_data->pack_curr, p_bms_shm_data->pack_num * sizeof(uint32_t));
    pos += p_bms_shm_data->pack_num * sizeof(uint32_t);
    memcpy(&p_bms_data[pos], &p_bms_shm_data->pack_power, p_bms_shm_data->pack_num * sizeof(uint32_t));
    pos += p_bms_shm_data->pack_num * sizeof(uint32_t);
    memcpy(&p_bms_data[pos], &p_bms_shm_data->monomer_volt, p_bms_shm_data->pack_num * p_bms_shm_data->monomer_num * sizeof(uint16_t));
    pos += p_bms_shm_data->pack_num * p_bms_shm_data->monomer_num * sizeof(uint16_t);
    memcpy(&p_bms_data[pos], &p_bms_shm_data->monomer_temp, p_bms_shm_data->pack_num * p_bms_shm_data->pack_tpoint_num * sizeof(uint16_t));

    p_bms_payload = malloc(MQTT_PAYLOAD_BASIC_LEN + bms_data_len);
    if(p_bms_payload == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"malloc error");
        free(p_bms_data);
        return MOSQ_ERR_INVAL;
    }

    bms_payload_len = mqtt_payload_pack(MQTT_DEV_BMS_DATA, mqtt_get_payload_id(), p_bms_data, bms_data_len, p_bms_payload);
    mosquitto_mqtt_pubscribe(get_curr_mosquitto_fd(), p_bms_payload, bms_payload_len);
    free(p_bms_data);
    free(p_bms_payload);

    return MOSQ_ERR_SUCCESS;

}


/**
 * @brief  	上报储能柜PCS数据
 * @return 	0:成功，其他：失败
 */
static uint8_t mqtt_dev_pcs_data_upload(void)
{
    uint8_t pcs_data[MQTT_PCS_DATA_LEN] = {0};
    uint8_t *p_pcs_payload = NULL;
    uint16_t pcs_payload_len = 0;
    common_data_t *shm = NULL;
	pcs_data_t *p_pcs_data = NULL;
    mqtt_dev_info_t *p_dev_info = NULL;
    
    p_dev_info = mqtt_dev_info_get();
	shm = sdk_shm_get();
	p_pcs_data = &shm->mqtt_data.pcs_data;
	if(p_pcs_data == NULL)
	{
		MQTT_DEBUG_PRINT((int8_t *)"\n [%s:%d] pcs data is NULL\n",__func__, __LINE__);
		return MOSQ_ERR_NOMEM;
	}

    memcpy(pcs_data, p_dev_info->clientID, strlen(p_dev_info->clientID));
    memcpy(&pcs_data[32], pcs_sn_get(), strlen(pcs_sn_get()));
    memcpy(&pcs_data[64], &p_pcs_data->pcs_status, sizeof(pcs_data_t));
    p_pcs_payload = malloc(MQTT_PAYLOAD_BASIC_LEN + sizeof(pcs_data));
    if(p_pcs_payload == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"malloc error");
        return MOSQ_ERR_INVAL;
    }

    pcs_payload_len = mqtt_payload_pack(MQTT_DEV_PCS_DATA, mqtt_get_payload_id(), pcs_data, MQTT_PCS_DATA_LEN, p_pcs_payload);
    mosquitto_mqtt_pubscribe(get_curr_mosquitto_fd(), p_pcs_payload, pcs_payload_len);
    free(p_pcs_payload);

    return MOSQ_ERR_SUCCESS;

}


/**
 * @brief  	上报全局电表数据
 * @return 	0:成功，其他：失败
 */
static uint8_t mqtt_dev_all_meter_data_upload(void)
{
    uint8_t *p_all_meter_data = NULL;
    uint32_t all_meter_data_len = 0;
    uint8_t *p_all_meter_payload = NULL;
    uint16_t all_meter_payload_len = 0;
    common_data_t *shm = NULL;
	energy_cabinet_meter_data_t *p_energy_meter_data = NULL;
    municipal_meter_data_t *p_meter2_data = NULL;
    municipal_meter_data_t *p_meter3_data = NULL;
    bms_data_t *p_bms_data = NULL;
    sdk_rtc_t rtc_time = {0};
    uint16_t pos = 0;
    mqtt_dev_info_t *p_dev_info = NULL;
    constant_parameter_data_t *p_para_data = sdk_shm_constant_parameter_data_get();
    
    p_dev_info = mqtt_dev_info_get();
	shm = sdk_shm_get();
	p_energy_meter_data = &shm->mqtt_data.energy_meter_data;
	if(p_energy_meter_data == NULL)
	{
		MQTT_DEBUG_PRINT((int8_t *)"\n [%s:%d] energy data is NULL\n",__func__, __LINE__);
		return MOSQ_ERR_INVAL;
	}
	p_meter2_data = &shm->mqtt_data.energy_meter2_data;
	if(p_meter2_data == NULL)
	{
		MQTT_DEBUG_PRINT((int8_t *)"\n [%s:%d] energy data is NULL\n",__func__, __LINE__);
		return MOSQ_ERR_INVAL;
	}

	p_bms_data = &shm->mqtt_data.bms_data;
	if(p_bms_data == NULL)
	{
		MQTT_DEBUG_PRINT((int8_t *)"\n [%s:%d] bms data is NULL\n",__func__, __LINE__);
		return MOSQ_ERR_INVAL;
	}

    //智能终端：32byte 采集时间：8byte 光伏数量：2byte 市电电表（每个）：2 + (32 + 44 * 2) 储能电表：2 + 32 + 44 *2 + 2
    all_meter_data_len = 42 + 2 + (p_para_data->elec_meter_param.elec_meter3_cnt + 1) * 120 + 124;
    p_all_meter_data = malloc(all_meter_data_len);
    if(p_all_meter_data == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"malloc error");
        return MOSQ_ERR_INVAL;
    }
    memset(p_all_meter_data, 0, all_meter_data_len);

    memcpy(p_all_meter_data, p_dev_info->clientID, strlen(p_dev_info->clientID));
    pos += 32;
    //获取系统时钟时间
    if (sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time) != SF_OK)
    {
        MQTT_DEBUG_PRINT((int8_t *)"rtc get failed");
    }
    p_all_meter_data[pos++] = 0x20;
    p_all_meter_data[pos++] = hex_byte_cover_dec(rtc_time.tm_year);
    p_all_meter_data[pos++] = hex_byte_cover_dec(rtc_time.tm_mon);
    p_all_meter_data[pos++] = hex_byte_cover_dec(rtc_time.tm_day);
    p_all_meter_data[pos++] = hex_byte_cover_dec(rtc_time.tm_hour);
    p_all_meter_data[pos++] = hex_byte_cover_dec(rtc_time.tm_min);
    p_all_meter_data[pos++] = hex_byte_cover_dec(rtc_time.tm_sec);
    p_all_meter_data[pos++] = 0xFF;

    //光伏电表数量,暂没有
    p_all_meter_data[pos++] = 0;
    p_all_meter_data[pos++] = 0;  
    //市电电表数量，电表2数量固定为1，电表3数量由共享内存读取
    p_all_meter_data[pos++] = 1 + p_para_data->elec_meter_param.elec_meter3_cnt;
    p_all_meter_data[pos++] = 0; 

    //打包电表2数据
    memcpy(&p_all_meter_data[pos], energy_meter2_sn_get(), strlen(energy_meter2_sn_get()));
    pos += 32;
    //充电状态
    if(p_bms_data->charge_status == 2)
    {
        memcpy(&p_all_meter_data[pos], &p_meter2_data->active_power_total, sizeof(uint32_t));
    }
    pos += 4;
    memcpy(&p_all_meter_data[pos], &p_meter2_data->negative_active_energy_total, sizeof(uint32_t) * 10);
    pos += 40;
    //放电状态
    if(p_bms_data->charge_status == 3)
    {
        memcpy(&p_all_meter_data[pos], &p_meter2_data->active_power_total, sizeof(uint32_t));
    }

    pos += 4;
    memcpy(&p_all_meter_data[pos], &p_meter2_data->positive_active_energy_total, sizeof(uint32_t) * 10);
    pos += 40;

    //打包电表3数据
    for(uint8_t i = 0; i < p_para_data->elec_meter_param.elec_meter3_cnt; i++)
    {
        p_meter3_data = NULL;
        p_meter3_data = &shm->mqtt_data.energy_meter3_data[i];
        memcpy(&p_all_meter_data[pos], energy_meter3_sn_get(i), strlen(energy_meter3_sn_get(i)));
        pos += 32;
        //充电状态
        if(p_bms_data->charge_status == 2)
        {
            memcpy(&p_all_meter_data[pos], &p_meter3_data->active_power_total, sizeof(uint32_t));
        }
        pos += 4;
        memcpy(&p_all_meter_data[pos], &p_meter3_data->negative_active_energy_total, sizeof(uint32_t) * 10);
        pos += 40;
        //放电状态
        if(p_bms_data->charge_status == 3)
        {
            memcpy(&p_all_meter_data[pos], &p_meter3_data->active_power_total, sizeof(uint32_t));
        }

        pos += 4;
        memcpy(&p_all_meter_data[pos], &p_meter3_data->positive_active_energy_total, sizeof(uint32_t) * 10);
        pos += 40;
    }
    //储能柜电表数据，只提供一台储能柜
    p_all_meter_data[pos++] = 1;
    p_all_meter_data[pos++] = 0; 
    memcpy(&p_all_meter_data[pos], energy_cabinet_sn_get(), strlen(energy_cabinet_sn_get()));
    pos += 32;
    //充电状态
    if(p_bms_data->charge_status == 2)
    {
        memcpy(&p_all_meter_data[pos], &p_energy_meter_data->active_power_total, sizeof(uint32_t));
    }
    pos += 4;
    memcpy(&p_all_meter_data[pos], &p_energy_meter_data->negative_active_energy_total, sizeof(uint32_t) * 10);
    pos += 40;
    //放电状态
    if(p_bms_data->charge_status == 3)
    {
        memcpy(&p_all_meter_data[pos], &p_energy_meter_data->active_power_total, sizeof(uint32_t));
    }

    pos += 4;
    memcpy(&p_all_meter_data[pos], &p_energy_meter_data->positive_active_energy_total, sizeof(uint32_t) * 10);
    pos += 40;
    memcpy(&p_all_meter_data[pos], &p_bms_data->soc, sizeof(uint16_t));

    p_all_meter_payload = malloc(MQTT_PAYLOAD_BASIC_LEN + all_meter_data_len);
    if(p_all_meter_payload == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"malloc error");
        free(p_all_meter_data);
        return MOSQ_ERR_INVAL;
    }

    all_meter_payload_len = mqtt_payload_pack(MQTT_DEV_ALL_METER_DATA, mqtt_get_payload_id(), p_all_meter_data, all_meter_data_len, p_all_meter_payload);
    mosquitto_mqtt_pubscribe(get_curr_mosquitto_fd(), p_all_meter_payload, all_meter_payload_len);

    free(p_all_meter_payload);
    free(p_all_meter_data);

    return MOSQ_ERR_SUCCESS;

}

/**
 * @brief  	mqtt事件检测上报
 * @return 	0:成功，其他：失败
 */
static uint8_t mqtt_dev_event_upload(void)
{
    // uint8_t energy_cabinet_status = 0;
    // static uint8_t last_energy_cabinet_status = 0;
    uint32_t run_mode = 0;
    static uint32_t last_run_mode = 2;
    uint8_t event_data[MQTT_EVENT_DATA_LEN] = {0};
    uint8_t *p_event_payload = NULL;
    uint16_t event_payload_len = 0;
    sdk_rtc_t rtc_time = {0};
    static uint8_t last_status = 1;        //1:空闲 2：充电 3：放电
    common_data_t *shm = NULL;
	bms_data_t *p_bms_data = NULL;
    dev_event_t *p_dev_event = NULL;
    uint8_t pos = 0;
    mqtt_dev_info_t *p_dev_info = NULL;
    
    // energy_cabinet_status = sdk_shm_get()->mqtt_data.energy_cabinet_status;
    run_mode = sdk_shm_get()->constant_parameter_data.elec_meter_param.control_mode;
    p_dev_info = mqtt_dev_info_get();
	shm = sdk_shm_get();
	p_bms_data = &shm->mqtt_data.bms_data;
	if(p_bms_data == NULL)
	{
		MQTT_DEBUG_PRINT((int8_t *)"\n [%s:%d] bms data is NULL\n",__func__, __LINE__);
		return MOSQ_ERR_INVAL;
	}

    p_dev_event = &shm->mqtt_data.dev_event;
	if(p_dev_event == NULL)
	{
		MQTT_DEBUG_PRINT((int8_t *)"\n [%s:%d] dev event is NULL\n",__func__, __LINE__);
		return MOSQ_ERR_INVAL;
	}
    memcpy(event_data, p_dev_info->clientID, strlen(p_dev_info->clientID));
    pos += 32;
    memcpy(&event_data[pos], energy_cabinet_sn_get(), strlen(energy_cabinet_sn_get()));
    pos += 32;
    //开始放电
    if((last_status != 0x03) && (p_bms_data->charge_status == 0x03))
    {
        event_data[pos++] = (MQTT_DEV_EVENT_START_DISCHARGE >> 0) & 0xFF;
        event_data[pos++] = (MQTT_DEV_EVENT_START_DISCHARGE >> 8) & 0xFF;
        last_status = p_bms_data->charge_status;
    }
    //结束放电
    else if((last_status == 0x03) && (p_bms_data->charge_status != 0x03))
    {
        event_data[pos++] = (MQTT_DEV_EVENT_FINISH_DISCHARGE >> 0) & 0xFF;
        event_data[pos++] = (MQTT_DEV_EVENT_FINISH_DISCHARGE >> 8) & 0xFF;
        last_status = p_bms_data->charge_status;
    }
    //开始充电
    else if((last_status != 0x02) && (p_bms_data->charge_status == 0x02))
    {
        event_data[pos++] = (MQTT_DEV_EVENT_START_CHARGE >> 0) & 0xFF;
        event_data[pos++] = (MQTT_DEV_EVENT_START_CHARGE >> 8) & 0xFF;
        last_status = p_bms_data->charge_status;
    }
    //结束充电
    else if((last_status == 0x02) && (p_bms_data->charge_status != 0x02))
    {
        event_data[pos++] = (MQTT_DEV_EVENT_FINISH_CHARGE >> 0) & 0xFF;
        event_data[pos++] = (MQTT_DEV_EVENT_FINISH_CHARGE >> 8) & 0xFF;
        last_status = p_bms_data->charge_status;
    }
    //储能系统停机
    // else if((last_energy_cabinet_status != 0) && (energy_cabinet_status == 0))
    // {
    //     event_data[pos++] = (MQTT_DEV_EVENT_DEV_POWER_OFF >> 0) & 0xFF;
    //     event_data[pos++] = (MQTT_DEV_EVENT_DEV_POWER_OFF >> 8) & 0xFF;
    //     last_energy_cabinet_status = energy_cabinet_status;
    // }  
    // //储能系统其他状态，不上报，仅做逻辑处理
    // else if((last_energy_cabinet_status == 0) && (energy_cabinet_status != 0))
    // {
    //     // event_data[pos++] = (MQTT_DEV_EVENT_DEV_POWER_OFF >> 0) & 0xFF;
    //     // event_data[pos++] = (MQTT_DEV_EVENT_DEV_POWER_OFF >> 8) & 0xFF;
    //     last_energy_cabinet_status = energy_cabinet_status;
    //     return MOSQ_ERR_PROTOCOL;
    // }  
    //执行本地策略
    else if((last_run_mode != 0) && (run_mode == 0))
    {
        event_data[pos++] = (MQTT_DEV_EVENT_RUN_LOCAL_MODE >> 0) & 0xFF;
        event_data[pos++] = (MQTT_DEV_EVENT_RUN_LOCAL_MODE >> 8) & 0xFF;
        last_run_mode = run_mode;
    }   
    //执行远程策略
    else if((last_run_mode != 1) && (run_mode == 1))
    {
        event_data[pos++] = (MQTT_DEV_EVENT_RUN_REMOTE_MODE >> 0) & 0xFF;
        event_data[pos++] = (MQTT_DEV_EVENT_RUN_REMOTE_MODE >> 8) & 0xFF;
        last_run_mode = run_mode;
    }   
    else
    {
        return MOSQ_ERR_PROTOCOL;
    }

    //获取系统时钟时间
    if (sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time) != SF_OK)
    {
        MQTT_DEBUG_PRINT((int8_t *)"rtc get failed");
    }

    event_data[pos++] = 0x20;
	event_data[pos++] = hex_byte_cover_dec(rtc_time.tm_year);
    event_data[pos++] = hex_byte_cover_dec(rtc_time.tm_mon);
    event_data[pos++] = hex_byte_cover_dec(rtc_time.tm_day);
    event_data[pos++] = hex_byte_cover_dec(rtc_time.tm_hour);
    event_data[pos++] = hex_byte_cover_dec(rtc_time.tm_min);
    event_data[pos++] = hex_byte_cover_dec(rtc_time.tm_sec);
    event_data[pos++] = 0xFF;
    
    p_event_payload = malloc(MQTT_PAYLOAD_BASIC_LEN + sizeof(event_data));
    if(p_event_payload == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"malloc error");
        return MOSQ_ERR_INVAL;
    }

    event_payload_len = mqtt_payload_pack(MQTT_DEV_EVENT, mqtt_get_payload_id(), event_data, MQTT_EVENT_DATA_LEN, p_event_payload);
    mosquitto_mqtt_pubscribe(get_curr_mosquitto_fd(), p_event_payload, event_payload_len);

    free(p_event_payload);

    return MOSQ_ERR_SUCCESS;
}


/**
 * @brief  	mqtt告警开始检测上报
 * @return 	0:成功，其他：失败
 */
static uint8_t mqtt_dev_warn_upload(uint16_t id, uint8_t warn_level, uint8_t warn_type)
{
    uint8_t warn_data[MQTT_WARN_DATA_LEN] = {0};
    uint8_t *p_warn_payload = NULL;
    uint16_t warn_payload_len = 0;
    sdk_rtc_t rtc_time = {0};
    uint8_t pos = 0;
    mqtt_dev_info_t *p_dev_info = NULL;
    
    p_dev_info = mqtt_dev_info_get();
    memcpy(warn_data, p_dev_info->clientID, strlen(p_dev_info->clientID));
    pos += 32;
    memcpy(&warn_data[pos], energy_cabinet_sn_get(), strlen(energy_cabinet_sn_get()));
    pos += 32;
    warn_data[pos++] = (id >> 0) & 0xFF;
    warn_data[pos++] = (id >> 8) & 0xFF;
    warn_data[pos++] = warn_level;
    warn_data[pos++] = warn_type;

    //获取系统时钟时间
    if (sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time) != SF_OK)
    {
        MQTT_DEBUG_PRINT((int8_t *)"rtc get failed");
    }

    warn_data[pos++] = 0x20;
	warn_data[pos++] = hex_byte_cover_dec(rtc_time.tm_year);
    warn_data[pos++] = hex_byte_cover_dec(rtc_time.tm_mon);
    warn_data[pos++] = hex_byte_cover_dec(rtc_time.tm_day);
    warn_data[pos++] = hex_byte_cover_dec(rtc_time.tm_hour);
    warn_data[pos++] = hex_byte_cover_dec(rtc_time.tm_min);
    warn_data[pos++] = hex_byte_cover_dec(rtc_time.tm_sec);
    warn_data[pos++] = 0xFF;
    
    p_warn_payload = malloc(MQTT_PAYLOAD_BASIC_LEN + sizeof(warn_data));
    if(p_warn_payload == NULL)
    {
        MQTT_DEBUG_PRINT((int8_t *)"malloc error");
        return MOSQ_ERR_INVAL;
    }

    warn_payload_len = mqtt_payload_pack(MQTT_DEV_WARN, mqtt_get_payload_id(), warn_data, MQTT_WARN_DATA_LEN, p_warn_payload);
    mosquitto_mqtt_pubscribe(get_curr_mosquitto_fd(), p_warn_payload, warn_payload_len);

    free(p_warn_payload);

    return MOSQ_ERR_SUCCESS;
}



/**
 * @brief  	mqtt告警检测上报
 * @return 	0:成功，其他：失败
 */
static uint8_t mqtt_dev_warn_event_monitor(void)
{
    static uint32_t bms_warn[3] = {0}; 
    static uint32_t pcs_warn[3] = {0};  
    static uint32_t dy_warn[3] = {0};        
    common_data_t *shm = NULL;
    dev_event_t *p_dev_event = NULL;
    uint8_t i = 0, j = 0;
    uint16_t id = 0;

    shm = sdk_shm_get();
    p_dev_event = &shm->mqtt_data.dev_event;
	if(p_dev_event == NULL)
	{
		MQTT_DEBUG_PRINT((int8_t *)"\n [%s:%d] dev event is NULL\n",__func__, __LINE__);
		return MOSQ_ERR_INVAL;
	}

    for(i = 0; i < MQTT_WARN_MAX_LEVEL_CNT; i++)
    {
        if(bms_warn[i] != p_dev_event->bms_warn[i])     //BMS存在告警
        {
            for(j = 0; j < BIT_CNT; j++)
            {
                if((BIT_GET(bms_warn[i], j)) != (BIT_GET(p_dev_event->bms_warn[i], j)))
                {
                    if (BIT_GET(bms_warn[i], j))                //告警结束
                    {
                        id = ((j != BMS_WARN_MAX_CNT) ? (BMS_WARN_ID_START + j) : BMS_WARN_ID_MAX);
                        mqtt_dev_warn_upload(id, i + 1, MQTT_WARN_END);
                        BIT_CLR(bms_warn[i], j);                //对应bit置0
                        MQTT_DEBUG_PRINT((int8_t *)"mqtt_dev_warn_upload_end id = %d\n", id);
                        break;
                    }
                    else                                        //告警开始                                 
                    {
                        id = ((j != BMS_WARN_MAX_CNT) ? (BMS_WARN_ID_START + j) : BMS_WARN_ID_MAX);
                        mqtt_dev_warn_upload(id, i + 1, MQTT_WARN_START);
                        BIT_SET(bms_warn[i], j);                //对应bit置1           
                        MQTT_DEBUG_PRINT((int8_t *)"mqtt_dev_warn_upload_start id = %d \n", id); 
                        break;  
                    }
                }
            }
        }
    }

    for(i = 0; i < MQTT_WARN_MAX_LEVEL_CNT; i++)
    {
        if((BIT_GET(pcs_warn[i], j)) != (BIT_GET(p_dev_event->pcs_warn[i], j)))     //PCS存在告警
        {
            for(j = 0; j < BIT_CNT; j++)
            {
                if((BIT_GET(pcs_warn[i], j)) != (BIT_GET(p_dev_event->pcs_warn[i], j)))
                {
                    if (BIT_GET(pcs_warn[i], j))                //告警结束
                    {
                        id = ((j != PCS_WARN_MAX_CNT) ? (PCS_WARN_ID_START + j) : PCS_WARN_ID_MAX);
                        mqtt_dev_warn_upload(id, i + 1, MQTT_WARN_END);
                        BIT_CLR(pcs_warn[i], j);                //对应bit置0
                        MQTT_DEBUG_PRINT((int8_t *)"mqtt_dev_warn_upload_end id = %d\n", id);
                        break;
                    }
                    else                                        //告警开始                                 
                    {
                        id = ((j != PCS_WARN_MAX_CNT) ? (PCS_WARN_ID_START + j) : PCS_WARN_ID_MAX);
                        mqtt_dev_warn_upload(id, i + 1, MQTT_WARN_START);
                        BIT_SET(pcs_warn[i], j);                //对应bit置1    
                        MQTT_DEBUG_PRINT((int8_t *)"mqtt_dev_warn_upload_start id = %d \n", id); 
                        break; 
                    }
                }
            }
        }
    }

    for(i = 0; i < MQTT_WARN_MAX_LEVEL_CNT; i++)
    {
        if((BIT_GET(dy_warn[i], j)) != (BIT_GET(p_dev_event->dy_warn[i], j)))     //动环存在告警
        {
            for(j = 0; j < BIT_CNT; j++)
            {
                if((BIT_GET(dy_warn[i], j)) != (BIT_GET(p_dev_event->dy_warn[i], j)))
                {
                    if (BIT_GET(dy_warn[i], j))                //告警结束
                    {
                        id = ((j != DY_WARN_MAX_CNT) ? (DY_WARN_ID_START + j) : DY_WARN_ID_MAX);
                        mqtt_dev_warn_upload(id, i + 1, MQTT_WARN_END);
                        BIT_CLR(dy_warn[i], j);                //对应bit置0
                        MQTT_DEBUG_PRINT((int8_t *)"mqtt_dev_warn_upload_end id = %d\n", id);
                        break;
                    }
                    else                                        //告警开始                                 
                    {
                        id = ((j != DY_WARN_MAX_CNT) ? (DY_WARN_ID_START + j) : DY_WARN_ID_MAX);
                        mqtt_dev_warn_upload(id, i + 1, MQTT_WARN_START);
                        BIT_SET(dy_warn[i], j);                //对应bit置1    
                        MQTT_DEBUG_PRINT((int8_t *)"mqtt_dev_warn_upload_start id = %d \n", id);    
                        break;
                    }
                }
            }
        }
    }
    
    return MOSQ_ERR_SUCCESS;
}



/**
 * @brief  	mqtt重连
 * @return 	
 */
static void mqtt_reconnect(void)
{
    sdk_rtc_t rtc_time;

    sdk_rtc_t *p_record = operating_time_get(MQTT_RECONNECT_TIMER);
    if(sdk_is_time_over(p_record, g_mqtt_attr.reconnect_timeout) == 1)
    {
        MQTT_DEBUG_PRINT((int8_t *)"mqtt reconnect(%d)...", g_mqtt_attr.reconnect_cnt + 1);
        if(mosquitto_reconnect(get_curr_mosquitto_fd()) == MOSQ_ERR_SUCCESS)
        {
            g_mqtt_attr.mqtt_hb_miss_cnt = 0;
        }
        g_mqtt_attr.reconnect_cnt++;
        g_mqtt_attr.reconnect_timeout += TIME_OUT_2_SEC;
        if(g_mqtt_attr.reconnect_timeout > TIME_OUT_60_SEC)
        {
            g_mqtt_attr.reconnect_timeout = TIME_OUT_60_SEC;
        }
        sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
        operating_time_set(&rtc_time, MQTT_RECONNECT_TIMER);
    }
}


/**
 * @brief  	mqtt任务管理，主要负责定时数据上报
 * @return 	
 */
void mqtt_task_manage(void)
{
    if(!g_mqtt_attr.sign_flag)
    {
        return;
    }

    if(!mqtt_is_offline())
    {
        mqtt_dev_event_upload();
    }
    if(!mqtt_is_offline())
    {
        mqtt_dev_warn_event_monitor();
    }
    if(mqtt_is_offline())   //设备离线，进行重连
    {
        mqtt_reconnect();
    }
}


/**
 * @brief   设备心跳定时任务回调
 * @param
 * @note
 * @return
 */
void mqtt_dev_hb_timer_cb(void *p_user_arg)
{
    if(!mqtt_is_offline())
    {
        mqtt_dev_hb();
    }
}


/**
 * @brief   设备心跳定时任务
 * @param
 * @note
 * @return
 */
void mqtt_dev_hb_timer_init(void)
{
    user_timer_hd dev_hb_timer = NULL;

    dev_hb_timer = user_timer_create(mqtt_dev_hb_timer_cb, NULL);
    user_timer_detail_set_timeout(dev_hb_timer, 1 * 1000, TIME_OUT_30_SEC);    
}


/**
 * @brief   储能柜计量表数据定时任务回调
 * @param
 * @note
 * @return
 */
void mqtt_dev_energy_meter_data_upload_timer_cb(void *p_user_arg)
{
    if(!mqtt_is_offline())
    {
        mqtt_dev_energy_meter_data_upload();
    }
}


/**
 * @brief   储能柜计量表数据定时任务
 * @param
 * @note
 * @return
 */
void mqtt_dev_energy_meter_data_upload_timer_init(void)
{
    user_timer_hd dev_energy_meter_data_upload_timer = NULL;

    dev_energy_meter_data_upload_timer = user_timer_create(mqtt_dev_energy_meter_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(dev_energy_meter_data_upload_timer, 3 * 1000, TIME_OUT_60_SEC);    
}


/**
 * @brief   BMS数据定时任务回调
 * @param
 * @note
 * @return
 */
void mqtt_dev_bms_data_upload_timer_cb(void *p_user_arg)
{
    if(!mqtt_is_offline())
    {
        mqtt_dev_bms_data_upload();
    }
}


/**
 * @brief   BMS数据定时任务
 * @param
 * @note
 * @return
 */
void mqtt_dev_bms_data_upload_timer_init(void)
{
    user_timer_hd dev_bms_data_upload_timer = NULL;

    dev_bms_data_upload_timer = user_timer_create(mqtt_dev_bms_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(dev_bms_data_upload_timer, 5 * 1000, TIME_OUT_20_SEC);    
}



/**
 * @brief   PCS数据定时任务回调
 * @param
 * @note
 * @return
 */
void mqtt_dev_pcs_data_upload_timer_cb(void *p_user_arg)
{
    if(!mqtt_is_offline())
    {
        mqtt_dev_pcs_data_upload();
    }
}


/**
 * @brief   PCS数据定时任务
 * @param
 * @note
 * @return
 */
void mqtt_dev_pcs_data_upload_timer_init(void)
{
    user_timer_hd dev_pcs_data_upload_timer = NULL;

    dev_pcs_data_upload_timer = user_timer_create(mqtt_dev_pcs_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(dev_pcs_data_upload_timer, 7 * 1000, TIME_OUT_120_SEC);    
}


/**
 * @brief   电表2数据定时任务回调
 * @param
 * @note
 * @return
 */
void mqtt_dev_meter2_data_upload_timer_cb(void *p_user_arg)
{
    if(!mqtt_is_offline())
    {
        mqtt_dev_meter2_data_upload();
    }
}


/**
 * @brief   电表2数据定时任务
 * @param
 * @note
 * @return
 */
void mqtt_dev_meter2_data_upload_timer_init(void)
{
    user_timer_hd dev_meter2_data_upload_timer = NULL;

    dev_meter2_data_upload_timer = user_timer_create(mqtt_dev_meter2_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(dev_meter2_data_upload_timer, 9 * 1000, TIME_OUT_60_SEC);    
}

user_timer_hd dev_meter3_data_upload_timer = NULL;
/**
 * @brief   电表3数据定时任务回调
 * @param
 * @note
 * @return
 */
void mqtt_dev_meter3_data_upload_timer_cb(void *p_user_arg)
{
    static uint8_t meter3_cnt = 0;
    constant_parameter_data_t *p_constant_param = sdk_shm_constant_parameter_data_get();

    if(p_constant_param->elec_meter_param.elec_meter3_cnt == 0)
    {
        return;
    }

    if(!mqtt_is_offline())
    {
        mqtt_dev_meter3_data_upload();
        meter3_cnt++;
        user_timer_set_timeout(dev_meter3_data_upload_timer, 1 * 1000, false);
        if(meter3_cnt >= p_constant_param->elec_meter_param.elec_meter3_cnt)
        {
            meter3_cnt = 0;
            user_timer_set_timeout(dev_meter3_data_upload_timer, TIME_OUT_60_SEC - p_constant_param->elec_meter_param.elec_meter3_cnt, true);
        }
    }
}


/**
 * @brief   电表3数据定时任务
 * @param
 * @note
 * @return
 */
void mqtt_dev_meter3_data_upload_timer_init(void)
{

    dev_meter3_data_upload_timer = user_timer_create(mqtt_dev_meter3_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(dev_meter3_data_upload_timer, 11 * 1000, TIME_OUT_60_SEC);    
}



/**
 * @brief   全局电表数据定时任务回调
 * @param
 * @note
 * @return
 */
void mqtt_dev_all_meter_data_upload_timer_cb(void *p_user_arg)
{
    if(!mqtt_is_offline())
    {
        mqtt_dev_all_meter_data_upload();
    }
}


/**
 * @brief   全局电表数据定时任务
 * @param
 * @note
 * @return
 */
void mqtt_dev_all_meter_data_upload_timer_init(void)
{
    user_timer_hd dev_all_meter_data_upload_timer = NULL;

    dev_all_meter_data_upload_timer = user_timer_create(mqtt_dev_all_meter_data_upload_timer_cb, NULL);
    user_timer_detail_set_timeout(dev_all_meter_data_upload_timer, 19 * 1000, TIME_OUT_30_SEC);    
}


/**
 * @brief   实时数据上报服务
 * @param   [in] arg
 * @note
 * @return
 */
static void *mqtt_upload_service(void *arg)
{
    //等待设备注册完成
    while(!g_mqtt_attr.sign_flag)
    {
        usleep(1000 * 2000);
    }

    //初始化各个定时任务
    mqtt_dev_hb_timer_init();
    mqtt_dev_energy_meter_data_upload_timer_init();
    mqtt_dev_bms_data_upload_timer_init();
    mqtt_dev_pcs_data_upload_timer_init();
    mqtt_dev_meter2_data_upload_timer_init();
    mqtt_dev_meter3_data_upload_timer_init();
    mqtt_dev_all_meter_data_upload_timer_init();

    while(1)
	{  
        mqtt_task_manage();
        usleep(1000 * 200);
    }
    return NULL;
}


/**
 * @brief   数据上报线程
 * @param
 * @note
 * @return
 */
void mqtt_upload_module_init(void)
{
	pthread_t real_time_upload;
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	if(pthread_create(&real_time_upload, &attr, mqtt_upload_service, NULL) != 0)
	{
		perror("pthread_create tcp server service");
	}
	pthread_attr_destroy(&attr);
}
