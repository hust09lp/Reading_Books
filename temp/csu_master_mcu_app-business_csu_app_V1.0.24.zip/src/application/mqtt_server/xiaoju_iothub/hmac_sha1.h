#ifndef __HMAC_SHA1_H__
#define __HMAC_SHA1_H__

void hmac_sha1(
                unsigned char *key,
                int key_length,
                unsigned char *data,
                int data_length,
                unsigned char *digest
                );

/**
 * @brief   计算hmac_sha1
 * @param   [in] p_key：秘钥
 * @param   [in] p_text:数据
 * @param   [out] p_out:签名数据
 * @note
 * @return
 */
void hmac_sha1_string(uint8_t *p_key, uint8_t *p_text, uint8_t *p_out);

#endif //__HMAC_SHA1_H__