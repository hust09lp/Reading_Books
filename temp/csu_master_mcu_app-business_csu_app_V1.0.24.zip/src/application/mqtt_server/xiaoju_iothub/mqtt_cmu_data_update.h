#ifndef __MQTT_CMU_DATA_UPDATE_H__
#define __MQTT_CMU_DATA_UPDATE_H__

#define SYS_CMU_CNT                 6         //CMU数量

enum{
    STANDBY = 0,            //无动作
    CHARGE,                 //充电
    DISCHARGE,              //放电
    POWEROFF,               //停机
};

/**
 * @brief    获取本地储能柜SN
 * @return   执行状态0：失败；1：成功
 */
char *energy_cabinet_sn_get(void);

/**
 * @brief    获取计量电表2 SN
 * @return   执行状态0：失败；1：成功
 */
char *energy_meter2_sn_get(void);


/**
 * @brief    获取计量电表3 SN
 * @return   执行状态0：失败；1：成功
 */
char *energy_meter3_sn_get(uint8_t meter_code);

/**
 * @brief    获取本地储能柜 PCS SN
 * @return   执行状态0：失败；1：成功
 */
char *pcs_sn_get(void);

/**
 * @brief    针对小桔云平台需要，进行定时数据获取更新
 */
void mqtt_iothub_cmu_data_update(void);

#endif