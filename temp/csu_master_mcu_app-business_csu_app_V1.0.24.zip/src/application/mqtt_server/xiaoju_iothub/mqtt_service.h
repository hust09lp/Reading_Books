#ifndef __MQTT_SERVICE_H__
#define __MQTT_SERVICE_H__

#include "mosquitto.h"
#include "sdk_log.h"

#if (1)
#define MQTT_DEBUG_PRINT(...) log_i(__VA_ARGS__);

#define print_frame(buf, len) \
    do {                                               \
        uint16_t tmp_length = (len);                     \
        uint16_t tmp_i = 0;                              \
        for (tmp_i = 0; tmp_i < tmp_length; ) { \
            printf(" %02X", (buf)[tmp_i]);  \
			tmp_i++;	\
			if((tmp_i % 16) == 0) {	\
				printf("\n");  \
			}	\
        }                                              \
        printf("\n");                    \
    } while (0)

#else
#define MQTT_DEBUG_PRINT(...) {do {} while(0);}
#define print_frame(buf, len) {do {} while(0);}
#endif

#define HOST "iothub-test.xiaojukeji.com"
#define PORT 1883
#define KEEP_ALIVE 30

#define MQTT_TEST 0
#if MQTT_TEST
//用于测试的信息
#define CLINE_ID        "6_0001000TBF77236"
#define DEV_NAME        "6_0001000TBF77236"
#define PRODUCT_KEY     "5k1wlNFP1c"
#define DEV_SECRET      "YFgo8Oxg5IR4xAzCYo9YPDiQ82JeRAm3"
#define ENERGY_DEV_ID   "1"
#endif

#define PATH_MQTT_DEV_INFO_FILE     "/user/conf/mqtt_dev_info"
#define PATH_MQTT_SERVER_HOST_FILE     "/user/conf/mqtt_server_host"
#define DEVICE_INFO_FILE_VALID	(0xAA55)	// 文件有效标志

#define METER3_MAX_NUM         5            //电表3最大数量
typedef struct
{
    uint16_t validity_flag;			        // 文件有效性标志
    char clientID[128];
    char dev_name[128];
    char pro_key[128];
    char dev_secret[128];
    char dev_sn[128];
    char pcs_sn[128];
    char meter2_sn[128];
    char meter3_sn[METER3_MAX_NUM][128];
}mqtt_dev_info_t;

typedef struct
{
    uint16_t validity_flag;			        // 文件有效性标志
    char host[128];
}mqtt_server_host_t;

/**
 * @brief        获取四元组信息
 * @return       四元组地址
 */
mqtt_dev_info_t *mqtt_dev_info_get(void);

/**
 * @brief  	获取当前mosquitto句柄
 * @return 	[mosq] 句柄
 */
struct mosquitto *get_curr_mosquitto_fd(void);


/**
 * @brief   小桔mqtt服务线程
 * @param   [in] arg
 * @note
 * @return
 */
void *iothub_mqtt_service(void *arg);

/**
 * @brief   主题发布
 * @param   [in] mosq：mosquitto客户端句柄
 * @note
 * @return
 */
void mosquitto_mqtt_pubscribe(struct mosquitto *mosq, uint8_t *p_payload, uint16_t payload_len);


#endif