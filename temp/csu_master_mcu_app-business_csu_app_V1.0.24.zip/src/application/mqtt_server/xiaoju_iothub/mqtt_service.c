#include "sdk_public.h"
#include "sdk_log.h"
#include "mqtt_service.h"
#include "mosquitto.h"
#include <pthread.h>
#include <unistd.h>
#include <string.h>
#include "sdk/sdk_fs.h"
#include "data_types.h"
#include "data_shm.h"
#include "sofar_errors.h"
#include "hmac_sha1.h"
#include "mqtt_func_handle.h"
#include "mqtt_cmu_data_update.h"
#include "mqtt_energy_handle.h"

mqtt_dev_info_t g_dev_info = {0};
static struct mosquitto *gp_mosq = NULL;
static pthread_mutex_t g_mqtt_mtx = PTHREAD_MUTEX_INITIALIZER;

/**
 * @brief  	获取当前mosquitto句柄
 * @return 	[mosq] 句柄
 */
struct mosquitto * get_curr_mosquitto_fd(void)
{
    return gp_mosq;
}


/**
 * @brief  	获取网路状态
 * @return 	0：没有外网 1：有外网可连接服务器
 */
static uint8_t get_curr_net_status(void)
{
    char cmd[256] = {0};
    char tmp_buff[32] = {0};
    FILE *fp;

    //ping小桔服务器，查看网络状态
    snprintf(cmd, 256, "ping -c 1 -W 1 %s | awk '/packet loss/{print $7}'", HOST);
	fp = popen(cmd,"r");

    fread(tmp_buff, 1, sizeof(tmp_buff), fp);

	if(!strncmp(tmp_buff, "0%", strlen("0%")))
	{
		pclose(fp);
		return 1;
	}
    pclose(fp);
    return 0;
}


/**
 * @brief  	将sdk_rtc_t结构体时间转换成时间戳（秒）
 * @param  	[in] p_time         sdk_rtc_t结构体时间
 * @param  	[out] p_timestamp   时间戳（秒）
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
static int32_t date_time_to_timestamp(sdk_rtc_t *p_time, time_t *p_timestamp)
{
    struct tm data;

    if ((p_time == NULL) || (p_timestamp == NULL))
    {
        MQTT_DEBUG_PRINT((int8_t *)"\n [%s:%d] null pointer! \n", __func__, __LINE__);
        return SF_ERR_PARA;
    }

    memset(&data, 0, sizeof(data));
    data.tm_year = (int32_t)(p_time->tm_year) + 100;
    data.tm_mon  = (int32_t)(p_time->tm_mon - 1);
    data.tm_mday = (int32_t)(p_time->tm_day);
    data.tm_hour = (int32_t)(p_time->tm_hour);
    data.tm_min  = (int32_t)(p_time->tm_min);
    data.tm_sec  = (int32_t)(p_time->tm_sec);
    *p_timestamp = mktime(&data);

    return SF_OK;
}


/**
 * @brief  	获取当前时间时间戳
 * @return 	[int32_t] 执行结果
 * @retval  0: 成功
 * @retval  <0: 失败，返回错误码
 */
static int32_t get_sys_timestamp(void)
{
    sdk_rtc_t rtc_time;
    int32_t ret;
    time_t curr_timestamp = 0;

    ret = sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
    if (ret != SF_OK)
    {
        MQTT_DEBUG_PRINT((int8_t *)"rtc get failed");
    }
    date_time_to_timestamp(&rtc_time, &curr_timestamp);

    return curr_timestamp;
}


/**
 * @brief   mqtt clientID生成接口
 * @param   [out] p_clientID:用于mqtt连接的clientID
 * @note
 * @return
 */
void mosquitto_client_id_generate(uint8_t *p_clientID)
{
    mqtt_dev_info_t *p_dev_info = NULL;
    
    p_dev_info = mqtt_dev_info_get();
    sprintf((char *)p_clientID, "%s|signmethod=hmacsha1,timestamp=%d", p_dev_info->clientID, get_sys_timestamp());
}

/**
 * @brief   mqtt user name生成接口
 * @param   [out] p_name:用于mqtt连接的user name
 * @note
 * @return
 */
void mosquitto_user_name_generate(uint8_t *p_name)
{
    mqtt_dev_info_t *p_dev_info = NULL;
    
    p_dev_info = mqtt_dev_info_get();
    sprintf((char *)p_name, "%s-%s", p_dev_info->pro_key, p_dev_info->dev_name);
}


/**
 * @brief   mqtt登录密码生成接口
 * @param   [out] p_password:用于mqtt连接的password
 * @note
 * @return
 */
void mosquitto_password_generate(uint8_t *p_password)
{
    uint8_t tmp_str[256] = {0};
    mqtt_dev_info_t *p_dev_info = NULL;
    
    p_dev_info = mqtt_dev_info_get();
    sprintf((char *)tmp_str, "clientId%sdeviceName%sproductKey%stimestamp%d", p_dev_info->clientID, \
                                                                              p_dev_info->dev_name, \
                                                                              p_dev_info->pro_key, \
                                                                              get_sys_timestamp());
    hmac_sha1_string((uint8_t *)p_dev_info->dev_secret, tmp_str, p_password);
}

/**
 * @brief   主题订阅
 * @param   [in] mosq：mosquitto客户端句柄
 * @note
 * @return
 */
static void mosquitto_mqtt_subscribe(struct mosquitto *mosq)
{
    char topic[64] = {0};
    mqtt_dev_info_t *p_dev_info = NULL;
    
    p_dev_info = mqtt_dev_info_get();
    sprintf(topic, "/%s/%s/sub", p_dev_info->pro_key, p_dev_info->clientID);
    mosquitto_subscribe(mosq, NULL, topic, 1);
}

/**
 * @brief   主题发布
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] p_payload：数据
 * @param   [in] payload_len：数据长度
 * @note 
 * @return
 */
void mosquitto_mqtt_pubscribe(struct mosquitto *mosq, uint8_t *p_payload, uint16_t payload_len)
{
    char topic[64] = {0};
    uint32_t ret = 0;
    mqtt_dev_info_t *p_dev_info = NULL;
    
    pthread_mutex_lock(&g_mqtt_mtx);
    p_dev_info = mqtt_dev_info_get();
    sprintf(topic, "/%s/%s/pub", p_dev_info->pro_key, p_dev_info->clientID);
    ret = mosquitto_publish(mosq, NULL, topic, payload_len, p_payload, 1, 0);
    if(ret != 0)
    {
        MQTT_DEBUG_PRINT((int8_t *)"publish  error\n");
        return;
    }
    MQTT_DEBUG_PRINT((int8_t *)"publish  success\n");
    pthread_mutex_unlock(&g_mqtt_mtx);
}


/**
 * @brief   主题订阅数据接收回调
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] userdata：用户数据
 * @param   [out] message:云端数据
 * @note
 * @return
 */
void message_callback(struct mosquitto *mosq, void *userdata, const struct mosquitto_message *message)
{
    if (message->payloadlen)
	{
        MQTT_DEBUG_PRINT((int8_t *)"topic : %s len = %d", message->topic, message->payloadlen);
        mqtt_data_unpack(mosq, (uint8_t *)message->payload, message->payloadlen);
    }
}


/**
 * @brief   连接状态回调
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] userdata：用户数据
 * @param   [in] result：状态
 * @note
 * @return
 */
void connect_callback(struct mosquitto *mosq, void *userdata, int result)
{
    if (result == 0)
	{
        MQTT_DEBUG_PRINT((int8_t *)"Connect success\n");
        mosquitto_mqtt_subscribe(mosq);
        if(mqtt_attr_connect_status_get() == MQTT_OFF_LINE)
        {
            mqtt_dev_sign_in(mosq);
            mqtt_attr_connect_status_set(MQTT_ON_LINE);
        }
    }
}

/**
 * @brief   连接断开状态回调
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] userdata：用户数据
 * @param   [in] result：状态
 * @note
 * @return
 */
static void disconnect_callback(struct mosquitto *mosq, void *userdata, int result)
{
    int ret = 0;

    mqtt_attr_connect_status_set(MQTT_OFF_LINE);
    MQTT_DEBUG_PRINT((int8_t *)"disconnect----->reconenct\n");
    ret = mosquitto_reconnect(mosq);
    if(ret != MOSQ_ERR_SUCCESS)
    {
        MQTT_DEBUG_PRINT((int8_t *)"reconnect error---------->%d\n", ret);
    }
}


/**
 * @brief   主题发布状态回调
 * @param   [in] mosq：mosquitto客户端句柄
 * @param   [in] obj
 * @param   [in] mosq：mosquitto客户端句柄
 * @note
 * @return
 */
void publish_callback(struct mosquitto *mosq, void *obj, int mid)
{
    MQTT_DEBUG_PRINT((int8_t *)"publish success");
}

/**
 * @brief        从文件中读取小桔四元组信息
 * @param        [out] p_sn 指向欲存放读取进来的数据空间
 * @return       [int32_t] 执行结果
 * @retval       =0 读取成功
 * @retval       <0 读取失败
 */
int32_t mqtt_dev_info_read(mqtt_dev_info_t *p_dev_info)
{
    int32_t ret = SF_OK;
    fs_t *p_fs;

    ret = sdk_fs_access((const int8_t *)PATH_MQTT_DEV_INFO_FILE, FS_F_OK);
    if (ret == SF_OK)
    {
        p_fs = sdk_fs_open((const int8_t *)PATH_MQTT_DEV_INFO_FILE, FS_READ);
        if (p_fs == NULL)
        {
            MQTT_DEBUG_PRINT((int8_t *)"open file %s failed", PATH_MQTT_DEV_INFO_FILE);
            return SF_ERR_OPEN;
        }

        /* 将位置偏移量移动到文件头 */
        ret = sdk_fs_lseek(p_fs, 0);
        if (ret < 0)
        {
            MQTT_DEBUG_PRINT((int8_t *)"sdk_fs_lseek error!");
            sdk_fs_close(p_fs);
            return SF_ERR_SEEK;
        }

        ret = sdk_fs_read(p_fs, p_dev_info, sizeof(mqtt_dev_info_t));
        if (ret != sizeof(mqtt_dev_info_t))
        {
            MQTT_DEBUG_PRINT((int8_t *)"read error!");
            sdk_fs_close(p_fs);
            return SF_ERR_RD;
        }

        sdk_fs_close(p_fs);

        if (p_dev_info->validity_flag == DEVICE_INFO_FILE_VALID)
        {
            ret = SF_OK;
        }
        else
        {
            ret = SF_ERR_NDEF;
        }
    }

    return ret;
}

/**
 * @brief        从文件中读取小桔服务器域名信息
 * @param        [out] p_sn 指向欲存放读取进来的数据空间
 * @return       [int32_t] 执行结果
 * @retval       =0 读取成功
 * @retval       <0 读取失败
 */
int32_t mqtt_server_host_read(mqtt_server_host_t *p_server_host)
{
    int32_t ret = SF_OK;
    fs_t *p_fs;

    ret = sdk_fs_access((const int8_t *)PATH_MQTT_SERVER_HOST_FILE, FS_F_OK);
    if (ret == SF_OK)
    {
        p_fs = sdk_fs_open((const int8_t *)PATH_MQTT_SERVER_HOST_FILE, FS_READ);
        if (p_fs == NULL)
        {
            MQTT_DEBUG_PRINT((int8_t *)"open file %s failed", PATH_MQTT_SERVER_HOST_FILE);
            return SF_ERR_OPEN;
        }

        /* 将位置偏移量移动到文件头 */
        ret = sdk_fs_lseek(p_fs, 0);
        if (ret < 0)
        {
            MQTT_DEBUG_PRINT((int8_t *)"sdk_fs_lseek error!");
            sdk_fs_close(p_fs);
            return SF_ERR_SEEK;
        }

        ret = sdk_fs_read(p_fs, p_server_host, sizeof(mqtt_server_host_t));
        if (ret != sizeof(mqtt_server_host_t))
        {
            MQTT_DEBUG_PRINT((int8_t *)"read error!");
            sdk_fs_close(p_fs);
            return SF_ERR_RD;
        }

        sdk_fs_close(p_fs);

        if (p_server_host->validity_flag == DEVICE_INFO_FILE_VALID)
        {
            ret = SF_OK;
        }
        else
        {
            ret = SF_ERR_NDEF;
        }
    }

    return ret;
}


/**
 * @brief        获取四元组信息
 * @return       四元组地址
 */
mqtt_dev_info_t *mqtt_dev_info_get(void)
{
    return &g_dev_info;
}


/**
 * @brief   小桔mqtt服务线程
 * @param   [in] arg
 * @note
 * @return
 */
void *iothub_mqtt_service(void *arg)
{
	int session = 0;
    uint8_t mqtt_clientID[256] = {0};
    uint8_t mqtt_userName[128] = {0};
    uint8_t mqtt_password[64] = {0};
    mqtt_server_host_t server_host = {0};

    pthread_mutex_init(&g_mqtt_mtx, NULL);  //初始化互斥锁
    //读取四元组信息
    while (mqtt_dev_info_read(&g_dev_info) != SF_OK)
    {
        sleep(10);
    }

    //读取服务器信息
    while (mqtt_server_host_read(&server_host) != SF_OK)
    {
        sleep(10);
    }

    MQTT_DEBUG_PRINT((int8_t *)"clientID:%s\n", g_dev_info.clientID);
    MQTT_DEBUG_PRINT((int8_t *)"dev_name:%s\n", g_dev_info.dev_name);
    MQTT_DEBUG_PRINT((int8_t *)"pro_key:%s\n", g_dev_info.pro_key);
    MQTT_DEBUG_PRINT((int8_t *)"dev_secret:%s\n", g_dev_info.dev_secret);

    //libmosquitto 库初始化
    mosquitto_lib_init();

    mosquitto_client_id_generate(mqtt_clientID);
    mosquitto_user_name_generate(mqtt_userName);
    mosquitto_password_generate(mqtt_password);
    MQTT_DEBUG_PRINT((int8_t *)"mqtt_clientID:%s\n", mqtt_clientID);
    MQTT_DEBUG_PRINT((int8_t *)"mqtt_userName:%s\n", mqtt_userName);
    MQTT_DEBUG_PRINT((int8_t *)"mqtt_password:%s\n", mqtt_password);
    //等待CSU与CMU通信稳定
    sleep(10);      

    //创建mosquitto客户端
    gp_mosq = mosquitto_new((char *)mqtt_clientID, session, NULL);
    if (!gp_mosq)
	{
        MQTT_DEBUG_PRINT((int8_t *)"create client failed..\n");
        mosquitto_lib_cleanup();
        return NULL;
    }

    //加载用户名和密码
    mosquitto_username_pw_set(gp_mosq, (char *)mqtt_userName, (char *)mqtt_password);
    //设置重连信息
    mosquitto_reconnect_delay_set(gp_mosq, 2, 10, true);
    // //注册回调
    mosquitto_connect_callback_set(gp_mosq, connect_callback);
    mosquitto_message_callback_set(gp_mosq, message_callback);
    mosquitto_publish_callback_set(gp_mosq, publish_callback);
    mosquitto_disconnect_callback_set(gp_mosq, disconnect_callback);

    //对储能柜数据进行定时采集更新
    mqtt_iothub_cmu_data_update();
    //电表能量管理
    mqtt_iothub_energy_module_init();

    //等待网络连接
    while (!get_curr_net_status())
    {
        sleep(2);
    }
    
    //连接服务器
    // MQTT_DEBUG_PRINT((int8_t *)"HOST:%s\n", server_host.host);
    while (mosquitto_connect(gp_mosq, server_host.host, PORT, KEEP_ALIVE) != MOSQ_ERR_SUCCESS)
    {
        MQTT_DEBUG_PRINT((int8_t *)"unable to connect.\n")
        sleep(10);
    }

    //数据上报模块
    mqtt_upload_module_init();
    while (1)
    {
        if(mosquitto_loop_forever(gp_mosq, 100, 1) != MOSQ_ERR_SUCCESS)
        {
            mosquitto_reconnect(gp_mosq);
        }
        usleep(1000 * 100);
    }
    
    pthread_exit(NULL);
}