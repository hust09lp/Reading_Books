#ifndef __MQTT_ENERGY_HANDLE_H__
#define __MQTT_ENERGY_HANDLE_H__

#define HISTORY_YEAR_START           (2023)      // 时间小于2023，不进行历史电量记录
// 时间变化类型
#define YEAR_CHANGE						5
#define MONTH_CHANGE					4
#define DAY_CHANGE						3
#define HOUR_CHANGE						2
#define MIN_CHANGE						1
#define NO_CHANGE						0

#define MAX_STORAGE_DAYS                180

/**
 * @brief  获取指定日期的数据库数据
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
int32_t select_charge_discharge(char *p_path, uint8_t *date, uint32_t *charge, uint32_t *discharge);

/**
 * @brief  获取指定日期的数据库数据(电表3做特殊处理)
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
int32_t select_charge_discharge_meter3(char *p_path, uint8_t *date, uint32_t *charge, uint32_t *discharge, uint8_t meter_code);

/**
 * @brief  定时更新点表充放电数据至数据库
 * @return none
 */
void mqtt_iothub_update_energy_data(void);

/**
 * @brief  电表数据存储初始化
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
void energy_record_init(void);

/**
 * @brief    针对小桔云平台需要，能量储存模块
 */
void mqtt_iothub_energy_module_init(void);

#endif