
#ifndef __SDK_SHM_H__
#define __SDK_SHM_H__


#include "data_shm.h"
#include "data_types.h"


// 共享内存映射
common_data_t *shmdata();

/**
 * @brief    共享内存初始化 （main函数初始化时调用它，收到-1 则终止）
 * @param    void    
 * @return   失败NULL,成功为指向的内容
 */
common_data_t *sdk_shm_init(void);

/**
 * @brief    获取shm指针的地址
 * @param
 * @return
 */
common_data_t **sdk_shm_addr_get(void);

/**
 * @brief    获取shm指向的内容
 * @param        
 * @return    
 */
common_data_t *sdk_shm_get(void);

/**
 * @brief    获取共享内存里 遥信数据 的基地址
 * @param
 * @return
 */
telematic_data_t *sdk_shm_telematic_data_get(void);

/**
 * @brief    获取共享内存里 遥测数据 的基地址
 * @param
 * @return
 */
telemetry_data_t *sdk_shm_telemetry_data_get(void);

/**
 * @brief    获取共享内存里 定值/参数数据 的基地址
 * @param
 * @return
 */
constant_parameter_data_t *sdk_shm_constant_parameter_data_get(void);


/**
 * @brief    获取共享内存里 其他参数 的基地址
 * @param
 * @return
 */
other_parameter_data_t *sdk_shm_other_parameter_data_get(void);

/**
 * @brief    获取共享内存里 内部共享数据 的基地址
 * @param
 * @return
 */
internal_shared_data_t *internal_shared_data_get(void);



/**
 * @brief    获取共享内存里 升级信息 的基地址
 * @param
 * @return
 */
firmware_update_t *sdk_shm_firmware_update_info_get(void);

/**
 * @brief    获取共享内存里 web控制操作相关信息 的基地址
 * @param
 * @return
 */
web_control_info_t *shm_web_control_info_get(void);


/**
 * @brief    获取共享内存里 内部版本信息 的基地址
 * @param
 * @return
 */
internal_version_info_t *internal_version_info_get(void);

#endif


