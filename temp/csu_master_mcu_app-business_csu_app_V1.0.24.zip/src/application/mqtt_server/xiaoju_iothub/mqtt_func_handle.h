#ifndef __MQTT_FUNC_HANDLE_H__
#define __MQTT_FUNC_HANDLE_H__

#include "mosquitto.h"

#define MQTT_SET_OFFLINE_HB_MISS_CNT    4

#define MQTT_ON_LINE            1
#define MQTT_OFF_LINE           0

#define MQTT_PAYLOAD_BASIC_LEN  16
#define MQTT_CMD_POS            12
#define MQTT_DATA_POS           14

#define MQTT_WARN_START         0x01
#define MQTT_WARN_END           0x02

#define MQTT_WARN_MAX_LEVEL_CNT  3                   //告警等级
#define BIT_CNT                  32                  //告警bit数量

#define BMS_WARN_MAX_CNT        17                  //BMS最大告警数量
#define BMS_WARN_ID_START       2000                //BMS起始告警ID
#define BMS_WARN_ID_MAX         2999                //BMS最大告警ID

#define PCS_WARN_MAX_CNT        20                  //PCS最大告警数量
#define PCS_WARN_ID_START       3000                //PCS起始告警ID
#define PCS_WARN_ID_MAX         3999                //PCS最大告警ID

#define DY_WARN_MAX_CNT        12                  //动环最大告警数量
#define DY_WARN_ID_START       6000                //动环起始告警ID
#define DY_WARN_ID_MAX         6999                //动环最大告警ID

#define MQTT_ENERGY_MAX_CHARGE_LIMIT   3800            //允许设置的最大充电电压
#define MQTT_ENERGY_MIN_CHARGE_LIMIT   3300            //允许设置的最小充电电压

#define MQTT_ENERGY_MAX_CHARGE_SOC   1000            //允许设置的最大充电SOC
#define MQTT_ENERGY_MIN_CHARGE_SOC   800            //允许设置的最小充电SOC

#define MQTT_ENERGY_MAX_POWER   110 * 10            //允许设置的最大功率
#define MQTT_ENERGY_MIN_POWER   6                   //允许设置的最小功率


#define MQTT_ENERGY_MAX_DISCHARGE_LIMIT   3200            //允许设置的最大放电电压
#define MQTT_ENERGY_MIN_DISCHARGE_LIMIT   2400            //允许设置的最小放电电压

#define MQTT_ENERGY_MAX_DISCHARGE_SOC   200             //允许设置的最大放电SOC
#define MQTT_ENERGY_MIN_DISCHARGE_SOC   0               //允许设置的最小放电SOC

#define MQTT_DEV_SIGN_IN                10001
#define MQTT_DEV_SIGN_IN_ACK            20001
#define MQTT_DEV_HB                     10002
#define MQTT_DEV_HB_ACK                 20002
#define MQTT_DEV_ENERGY_METER_DATA      10003
#define MQTT_DEV_ENERGY_METER_DATA_ACK  20003
#define MQTT_DEV_BMS_DATA               10004
#define MQTT_DEV_BMS_DATA_ACK           20004
#define MQTT_DEV_PCS_DATA               10005
#define MQTT_DEV_PCS_DATA_ACK           20005
#define MQTT_DEV_ENERGY_METER2_DATA     10008
#define MQTT_DEV_ENERGY_METER2_DATA_ACK 20008

#define MQTT_DEV_ALL_METER_DATA         10010
#define MQTT_DEV_ALL_METER_DATA_ACK     20010

#define MQTT_DEV_EVENT                  12001
#define MQTT_DEV_EVENT_ACK              22001

#define MQTT_DEV_WARN                   12002
#define MQTT_DEV_WARN_ACK               22002

#define MQTT_DEV_SET_PARAM              21001
#define MQTT_DEV_SET_PARAM_ACK          11001

#define MQTT_DEV_GET_ENERGY             21002
#define MQTT_DEV_GET_ENERGY_ACK         11002

#define PARAM_LEN  6

typedef enum{
    CHARGE_CMD = 11000,                         //充放电命令
    MONOMER_CHARGE_LIMIT_VOLT = 11001,          //单体充电截止电压
    CHARGE_LIMIT_SOC = 11002,                   //充电截止soc
    CLUSTER_CHARGE_LIMIT_MAX_POWER = 11003,     //电池簇充电允许最大功率
    MONOMER_DISCHARGE_LIMIT_VOLT = 11004,       //单体放电截止电压
    DISCHARGE_LIMIT_SOC = 11005,                //放电截止soc
    CLUSTER_DISCHARGE_LIMIT_MAX_POWER = 11006,  //电池簇放电允许最大功率
    DEV_RUN_MODE = 11008                        //策略切换
}mqtt_param_set_e;

#define MQTT_DEV_EVENT_START_DISCHARGE      200     //开始放电
#define MQTT_DEV_EVENT_FINISH_DISCHARGE     201     //结束放电
#define MQTT_DEV_EVENT_FINISH_CHARGE        202     //结束充电
#define MQTT_DEV_EVENT_START_CHARGE         203     //开始充电
#define MQTT_DEV_EVENT_DEV_POWER_OFF        204     //储能系统停机
#define MQTT_DEV_EVENT_RUN_LOCAL_MODE       205     //执行本地策略
#define MQTT_DEV_EVENT_RUN_REMOTE_MODE      206     //执行远程策略

#define MQTT_DEV_ENERGY_FAULT           2999

#define MQTT_SIGN_DATA_LEN                  104
#define MQTT_HB_DATA_LEN                    36
#define MQTT_ENERGY_METER_DATA_LEN          308
#define MQTT_ALL_METER_DATA_LEN             168
#define MQTT_BMS_DATA_LEN                   144     //因为电池组数量不定，这里只定义固定部分长度
#define MQTT_PCS_DATA_LEN                   152 
#define MQTT_EVENT_DATA_LEN                 74 
#define MQTT_WARN_DATA_LEN                  76 
#define MQTT_PARAM_SET_ACK_DATA_LEN         92 
#define MQTT_ENERGY_ACK_DATA_LEN            1630

/**
 * @brief 设置mqtt资源繁忙状态
 */
void mqtt_set_busy(void);

/**
 * @brief  	mqtt数据内容解包
 * @param   [in] mosq：mosquitto客户端句柄
 * @param  	[in] p_data：数据内容
 * @param  	[in] data_len：数据长度
 * @return 	
 */
void mqtt_data_unpack(struct mosquitto *mosq, uint8_t *p_data, uint16_t data_len);


/**
 * @brief  	mqtt任务管理，主要负责定时数据上报
 * @return 	
 */
void mqtt_task_manage(void);

/**
 * @brief  	上报签到信息
 * @return 	0:成功，其他：失败
 */
uint8_t mqtt_dev_sign_in(struct mosquitto *mosq);

/**
 * @brief  	获取mqtt连接状态信息
 * @return 	0：在线 1：离线
 */
uint8_t mqtt_attr_connect_status_get(void);

/**
 * @brief  	设置mqtt连接状态信息
 * @return 	0：在线 1：离线
 */
void mqtt_attr_connect_status_set(uint8_t connect_status);


/**
 * @brief   数据上报线程
 * @param
 * @note
 * @return
 */
void mqtt_upload_module_init(void);

#endif