#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include <time.h>
#include <pthread.h>
#include"data_shm.h"
#include"sdk_shm.h"
#include"sdk_para.h"
#include"sdk_public.h"
#include"app_common.h"
#include"sofar_errors.h"
#include"sdk_fs.h"
#include"sqlite3.h"
#include"sofar_log.h"
#include"mqtt_energy_handle.h"
#include"mqtt_service.h"


typedef struct
{
    int16_t year;	// 年份，如2023
    int16_t month;	// 月份，1~12
    int16_t day;	// 日期，1~31
	int16_t hour;	// 小时，0~23
    int16_t minute;
	int16_t second;
}energy_time_t;

//针对每个类型电表设置不同的计时变量
static energy_time_t g_meter1_last_save_time = {0};         	    //上次记录时间
static energy_time_t g_meter1_now_time = {0};                       //当前时间

static energy_time_t g_meter2_last_save_time = {0};         	    //上次记录时间
static energy_time_t g_meter2_now_time = {0};                       //当前时间

static energy_time_t g_meter3_last_save_time = {0};         	    //上次记录时间
static energy_time_t g_meter3_now_time = {0};                       //当前时间

//相关宏定义
#define PATH_ENERGY_GENERAL_DIR	 "/user/data/energy/"			// 电量存储总目录
#define ENERGY_DB "/user/data/energy/mqtt_energy.db"
#define ENERGY_METER2_DB "/user/data/energy/mqtt_energy_meter2.db"
#define ENERGY_METER3_DB "/user/data/energy/mqtt_energy_meter3.db"

/**
 * @brief  创建数据库
 * @param  [in] 
 * @param  [in]
 * @param  [out]
 * @return 
 *
 */
static void create_energy_table(void)
{
    char *err_msg = 0;
    int rc = 0;
    sqlite3 *db;
    char *sql = "CREATE TABLE IF NOT EXISTS charge_data (date TEXT PRIMARY KEY, charge REAL, discharge REAL);";
    char *sql_trigger = "CREATE TRIGGER delete_old_records AFTER INSERT ON charge_data "
						"BEGIN "
							"DELETE FROM charge_data WHERE date < DATE('now', '-180 days');"
                        "END;";

    rc = sqlite3_open(ENERGY_DB, &db);
    if(rc) 
    {
        MQTT_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
        return;
    }
 
    rc = sqlite3_exec(db, sql, 0, 0, &err_msg);
    if (rc != SQLITE_OK) 
    {
        MQTT_DEBUG_PRINT((int8_t *)"Failed to create table: %s\n", err_msg);
        sqlite3_free(err_msg);
    }
 
 	rc = sqlite3_exec(db, sql_trigger, 0, 0, &err_msg);
	if (rc != SQLITE_OK) {
		fprintf(stderr, "SQL error: %s\n", err_msg);
		sqlite3_free(err_msg);
	} 
    else 
    {
		fprintf(stdout, "Trigger created successfully\n");
	}
    sqlite3_close(db);
}


/**
 * @brief  创建市电电表数据存储(计量表2)数据库
 * @param  [in] 
 * @param  [in]
 * @param  [out]
 * @return 
 *
 */
static void create_energy_meter2_table(void)
{
    char *err_msg = 0;
    int rc = 0;
    sqlite3 *db;
    char *sql = "CREATE TABLE IF NOT EXISTS charge_data (date TEXT PRIMARY KEY, charge REAL, discharge REAL);";
    char *sql_trigger = "CREATE TRIGGER delete_old_records AFTER INSERT ON charge_data "
						"BEGIN "
							"DELETE FROM charge_data WHERE date < DATE('now', '-180 days');"
                        "END;";

    rc = sqlite3_open(ENERGY_METER2_DB, &db);
    if(rc) 
    {
        MQTT_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
        return;
    }
 
    rc = sqlite3_exec(db, sql, 0, 0, &err_msg);
    if (rc != SQLITE_OK) 
    {
        MQTT_DEBUG_PRINT((int8_t *)"Failed to create table: %s\n", err_msg);
        sqlite3_free(err_msg);
    }
 
 	rc = sqlite3_exec(db, sql_trigger, 0, 0, &err_msg);
	if (rc != SQLITE_OK) {
		fprintf(stderr, "SQL error: %s\n", err_msg);
		sqlite3_free(err_msg);
	} 
    else 
    {
		fprintf(stdout, "Trigger created successfully\n");
	}
    sqlite3_close(db);
}


/**
 * @brief  创建市电电表数据存储(计量表3)数据库
 * @param  [in] 
 * @param  [in]
 * @param  [out]
 * @return 
 *
 */
static void create_energy_meter3_table(void)
{
    char *err_msg = 0;
    int rc = 0;
    sqlite3 *db;
    char *sql = "CREATE TABLE IF NOT EXISTS charge_data (date TEXT PRIMARY KEY, charge1 REAL, discharge1 REAL,\
                                                                                charge2 REAL, discharge2 REAL,\
                                                                                charge3 REAL, discharge3 REAL,\
                                                                                charge4 REAL, discharge4 REAL,\
                                                                                charge5 REAL, discharge5 REAL);";
    char *sql_trigger = "CREATE TRIGGER delete_old_records AFTER INSERT ON charge_data "
						"BEGIN "
							"DELETE FROM charge_data WHERE date < DATE('now', '-180 days');"
                        "END;";

    rc = sqlite3_open(ENERGY_METER3_DB, &db);
    if(rc) 
    {
        MQTT_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
        return;
    }
 
    rc = sqlite3_exec(db, sql, 0, 0, &err_msg);
    if (rc != SQLITE_OK) 
    {
        MQTT_DEBUG_PRINT((int8_t *)"Failed to create table: %s\n", err_msg);
        sqlite3_free(err_msg);
    }
 
 	rc = sqlite3_exec(db, sql_trigger, 0, 0, &err_msg);
	if (rc != SQLITE_OK) {
		fprintf(stderr, "SQL error: %s\n", err_msg);
		sqlite3_free(err_msg);
	} 
    else 
    {
		fprintf(stdout, "Trigger created successfully\n");
	}
    sqlite3_close(db);
}




/**
 * @brief  系统rtc时间获取
 * @param  [in] meter_code:电表编号0-2
 * @param  [out] none
 * @return none
 */
static void get_energy_time(uint8_t meter_code)
{
    sdk_rtc_t now;
    energy_time_t *p_time = NULL;

    switch(meter_code)
    {
        case 0:
            p_time = &g_meter1_now_time;
            break;

        case 1:
            p_time = &g_meter2_now_time;
            break;  

        case 2:
            p_time = &g_meter3_now_time;
            break;         
    }
 
    sdk_rtc_get(RTC_BIN_FORMAT, &now);
    if(NULL == p_time)
    {
        return;
    }
 
    p_time->year = now.tm_year + 2000;
    p_time->month = now.tm_mon;
    p_time->day = now.tm_day;
    p_time->hour = now.tm_hour;
    p_time->minute = now.tm_min;
    p_time->second = now.tm_sec;
}

/**
 * @brief  更新上一次记录时间
 * @param  [in] p_last_time 
 * @param  [in] update_time 
 * @return none
 */
static void energy_update_lastsavetime(energy_time_t *p_last_time, energy_time_t update_time)
{
    if (NULL == p_last_time)
    {
        return;
    }
 
    memcpy(p_last_time, &update_time, sizeof(energy_time_t));
 
    return;
}


/**
 * @brief  时间变化判断函数
 * @param  [in] updatetime 更新时的时间
 * @param  [in] lastsavetime 上一次保存的时间
 * @param  [out] none
 * @return 时间变化类型
 */
static uint8_t get_energy_timechange(energy_time_t updatetime, energy_time_t lastsavetime)
{
    if(updatetime.year < HISTORY_YEAR_START)    //年限不合理，不进行历史电量记录
    {
        return NO_CHANGE;
    }
 
    if (lastsavetime.year != updatetime.year)
    {
        return YEAR_CHANGE;
    }
    if (lastsavetime.month != updatetime.month)
    {
        return MONTH_CHANGE;
    }
    if (lastsavetime.day != updatetime.day)
    {
        return DAY_CHANGE;
    }
    // if (lastsavetime.hour != updatetime.hour)
    // {
    //     return HOUR_CHANGE;
    // }
    if (lastsavetime.minute != updatetime.minute)
    {
        return MIN_CHANGE;
    } 
    return NO_CHANGE;
}


/**
 * @brief  根据时间确认数据位置，15分钟一个点，一天96个点
 * @param  [in] date 日期，只有时-分(10:00)
 * @return 0失败 1成功
 */
static uint8_t sqlite_db_get_data_pos(uint8_t *date)
{
    int hour = 0;
    int min = 0;
    uint8_t pos = 0;

    sscanf((char *)date, "%d-%d", &hour, &min);
    // MQTT_DEBUG_PRINT((int8_t *)"hour = %d min = %d\n", hour, min);

    pos = hour * 4 + min / 15;

    // MQTT_DEBUG_PRINT((int8_t *)"pos = %d\n", pos);
    return pos;
}


/**
 * @brief  检查电表电量统计数据库文件是否存在和有效
 * @param  [in] none
 * @param  [out] none
 * @return 0-数据库文件正常   -1-数据库文件异常
 */
static int32_t mqtt_energy_db_file_check(char *p_path)
{
	int32_t ret = -1;
	fs_t *p_fs = NULL;
	
	
    ret = sdk_fs_access((const int8_t *)p_path, F_OK);
    if (ret == -1)  // 文件不存在，创建该文件
    {
		MQTT_DEBUG_PRINT((int8_t *)"mqtt_energy.db is not exist\n");
		create_energy_table();
		return (0);
    }
	else     // 文件存在，检查文件大小是否为0
	{
		MQTT_DEBUG_PRINT((int8_t *) "mqtt_energy.db is exist\n");
		p_fs = sdk_fs_open((const int8_t *)p_path,FS_READ);
		if ( p_fs != NULL)
		{
			ret = sdk_fs_get_size(p_fs);
			sdk_fs_close(p_fs);
			MQTT_DEBUG_PRINT((int8_t *)"\n mqtt_energy.db open success,file size:%d\n",ret);
			if (ret == 0)
			{
				MQTT_DEBUG_PRINT((int8_t *)"creat  mqtt_energy.db\n");
				sdk_fs_remove((const int8_t *)p_path);
				create_energy_table();
			}
		}
		else 
		{
			return (-1);
		}
	}
	return (0);
}

/**
 * @brief  更新数据库充放电量
 * @param  [in] date 日期(2023-07-11 10:00:00)
 * @param  [in] charge 充电量
 * @param  [in] discharge 放电量
 * @return 0失败 1成功
 */
static int32_t sqlite_db_update_data(char *p_path, char *date, uint32_t charge, uint32_t discharge)
{
    sqlite3 *db;
    int32_t rc;
    int32_t ret;
    int32_t retry_count = 0;

    mqtt_energy_db_file_check(p_path);
    rc = sqlite3_open(p_path, &db);
    if(rc) 
    {
        MQTT_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
        return(0);
    } 
    else 
    {
        char *sql = "INSERT OR REPLACE INTO charge_data (date, charge, discharge) VALUES (?, ?, ?);";
        sqlite3_stmt *stmt;
        sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
        sqlite3_bind_text(stmt, 1, date, -1, SQLITE_STATIC);
        sqlite3_bind_int(stmt, 2, charge);
        sqlite3_bind_int(stmt, 3, discharge);
 
        while ((SQLITE_DONE != (ret = sqlite3_step(stmt))) && (retry_count < 5))
        {
            retry_count++;
            MQTT_DEBUG_PRINT((int8_t *)"sqlite3_step err ret = %d \n",ret);
            usleep(1000);
        }
        
        sqlite3_finalize(stmt);
    }
    sqlite3_close(db);    

    return(1);
}


/**
 * @brief  获取指定日期的数据库数据
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
int32_t select_charge_discharge(char *p_path, uint8_t *date, uint32_t *charge, uint32_t *discharge)
{
	sqlite3 *db;
	sqlite3_stmt *stmt;
	int32_t rc;
	char sql[256] = {0};
    uint8_t time[64] = {0};
    uint8_t pos = 0;

	rc = sqlite3_open(p_path, &db);
	if(rc) 
    {
	    MQTT_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
	    return(0);
	} 
    else 
    {
		snprintf(sql, sizeof(sql), "SELECT strftime('%%H-%%M', date), charge, discharge FROM charge_data WHERE date LIKE '%s%%';",date);
        sqlite3_prepare_v2(db, sql, -1, &stmt, 0);

		while (sqlite3_step(stmt) == SQLITE_ROW) 
		{
            strcpy((char *)time, (char *)sqlite3_column_text(stmt, 0));
            pos = sqlite_db_get_data_pos(time);
			charge[pos] = sqlite3_column_int(stmt, 1);
			discharge[pos] = sqlite3_column_int(stmt, 2);
		}
	}
    sqlite3_finalize(stmt);
	sqlite3_close(db);	

    return 1;
}


/**
 * @brief  获取指定日期的数据库数据(电表3做特殊处理)
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
int32_t select_charge_discharge_meter3(char *p_path, uint8_t *date, uint32_t *charge, uint32_t *discharge, uint8_t meter_code)
{
	sqlite3 *db;
	sqlite3_stmt *stmt;
	int32_t rc;
	char sql[512] = {0};
    uint8_t time[64] = {0};
    uint8_t pos = 0;
    
	rc = sqlite3_open(p_path, &db);
	if(rc) 
    {
	    MQTT_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
	    return(0);
	} 
    else 
    {
		snprintf(sql, sizeof(sql), "SELECT strftime('%%H-%%M', date), charge1, discharge1,\
                                                                      charge2, discharge2,\
                                                                      charge3, discharge3,\
                                                                      charge4, discharge4,\
                                                                      charge5, discharge5 FROM charge_data WHERE date LIKE '%s%%';",date);
        sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
		while (sqlite3_step(stmt) == SQLITE_ROW) 
		{
            strcpy((char *)time, (char *)sqlite3_column_text(stmt, 0));
            pos = sqlite_db_get_data_pos(time);
			charge[pos] = sqlite3_column_int(stmt, meter_code * 2 - 1);
			discharge[pos] = sqlite3_column_int(stmt, meter_code * 2);
		}
	}
    sqlite3_finalize(stmt);
	sqlite3_close(db);	

    return 1;
}


/**
 * @brief  更新数据库充放电量,因为涉及到多个电表3，这里做特殊处理
 * @param  [in] date 日期(2023-07-11 10:00:00)
 * @param  [in] p_charge 充电量
 * @param  [in] p_discharge 放电量
 * @return 0失败 1成功
 */
static int32_t sqlite_db_update_meter3_data(char *p_path, char *date, uint32_t *p_charge, uint32_t *p_discharge)
{
    sqlite3 *db = NULL;
    int32_t rc = 0;
    int32_t ret = 0;
    int32_t retry_count = 0;

    mqtt_energy_db_file_check(p_path);
    rc = sqlite3_open(p_path, &db);
    if(rc) 
    {
        MQTT_DEBUG_PRINT((int8_t *)"Can't open database: %s\n", sqlite3_errmsg(db));
        return(0);
    } 
    else 
    {
        char *sql = "INSERT OR REPLACE INTO charge_data (date, charge1, discharge1,\
                                                               charge2, discharge2,\
                                                               charge3, discharge3,\
                                                               charge4, discharge4,\
                                                               charge5, discharge5) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
        sqlite3_stmt *stmt;
        sqlite3_prepare_v2(db, sql, -1, &stmt, 0);
        sqlite3_bind_text(stmt, 1, date, -1, SQLITE_STATIC);
        sqlite3_bind_int(stmt, 2, p_charge[0]);
        sqlite3_bind_int(stmt, 3, p_discharge[0]);
        sqlite3_bind_int(stmt, 4, p_charge[1]);
        sqlite3_bind_int(stmt, 5, p_discharge[1]);
        sqlite3_bind_int(stmt, 6, p_charge[2]);
        sqlite3_bind_int(stmt, 7, p_discharge[2]);
        sqlite3_bind_int(stmt, 8, p_charge[3]);
        sqlite3_bind_int(stmt, 9, p_discharge[3]);
        sqlite3_bind_int(stmt, 10, p_charge[4]);
        sqlite3_bind_int(stmt, 11, p_discharge[4]);
 
        while ((SQLITE_DONE != (ret = sqlite3_step(stmt))) && (retry_count < 5))
        {
            retry_count++;
            MQTT_DEBUG_PRINT((int8_t *)"sqlite3_step err ret = %d \n",ret);
            usleep(1000);
        }
        
        sqlite3_finalize(stmt);
    }
    sqlite3_close(db);    

    return(1);
}


/**
 * @brief  定时更新电表1充放电数据至数据库
 * @return none
 */
void mqtt_iothub_update_meter1_energy_data(void)
{
    uint8_t change = 0;
    uint32_t charge = 0;
    uint32_t discharge = 0;
    char date[32] = {0};
    energy_time_t *p_time = NULL;
    energy_cabinet_meter_data_t *p_energy_meter_data = NULL;
    
    // 1、获取各电量实时值
	p_energy_meter_data = &sdk_shm_get()->mqtt_data.energy_meter_data;
	if(p_energy_meter_data == NULL)
	{
		MQTT_DEBUG_PRINT((int8_t *)"energy data is NULL\n");
		return;
	}

    // 2、获取当前时间
    get_energy_time(0);
    change = get_energy_timechange(g_meter1_now_time, g_meter1_last_save_time);
    if(MIN_CHANGE == change)
    {
        if ((g_meter1_now_time.minute % 15) == 0)                  //整15分钟采集更新一次
        {	
            p_time = &g_meter1_now_time;
            snprintf(date, sizeof(date),"%04d-%02d-%02d %02d:%02d:00",p_time->year,\
                        p_time->month, p_time->day, p_time->hour, p_time->minute);
            //执行计量表1数据储存
            discharge = p_energy_meter_data->positive_active_energy_total; 
            charge = p_energy_meter_data->negative_active_energy_total;     
            MQTT_DEBUG_PRINT((int8_t *)"update db data, charge = %d  discharge = %d\n", charge, discharge); 
			sqlite_db_update_data(ENERGY_DB, date, charge, discharge);
            g_meter1_last_save_time.minute = g_meter1_now_time.minute;
        }
    }
    //日期变化时需要把数据记录到前一天24:00时刻
    else if((DAY_CHANGE == change) || (MONTH_CHANGE == change) || (YEAR_CHANGE == change))                           
    {
        //记录到前一天24:00：00时刻
        //注意，跨天跨月跨年要单独处理
        if((MONTH_CHANGE == change) || (YEAR_CHANGE == change))
        {
            p_time = &g_meter1_last_save_time;
            snprintf(date, sizeof(date),"%04d-%02d-%02d 24:00:00",p_time->year,\
                                                                    p_time->month,\
                                                                    p_time->day);
        }
        else if(DAY_CHANGE == change)
        {
            p_time = &g_meter1_now_time;
            snprintf(date, sizeof(date),"%04d-%02d-%02d 24:00:00",p_time->year,\
                                                                    p_time->month,\
                                                                    p_time->day - 1);
        }
        //执行电表1数据储存
        discharge = p_energy_meter_data->positive_active_energy_total; 
        charge = p_energy_meter_data->negative_active_energy_total;     
        MQTT_DEBUG_PRINT((int8_t *)"update db data, charge = %d  discharge = %d\n", charge, discharge); 
        sqlite_db_update_data(ENERGY_DB, date, charge, discharge);

        //记录到当天00:00:00时刻
        p_time = &g_meter1_now_time;
        snprintf(date, sizeof(date),"%04d-%02d-%02d %02d:%02d:00",p_time->year,\
                    p_time->month, p_time->day, p_time->hour, p_time->minute);
        discharge = p_energy_meter_data->positive_active_energy_total; 
        charge = p_energy_meter_data->negative_active_energy_total;     
        MQTT_DEBUG_PRINT((int8_t *)"update db data, charge = %d  discharge = %d\n", charge, discharge); 
        sqlite_db_update_data(ENERGY_DB, date, charge, discharge);
        energy_update_lastsavetime(&g_meter1_last_save_time, g_meter1_now_time);    // 更新时间指针
    }
}


/**
 * @brief  定时更新电表2充放电数据至数据库
 * @return none
 */
void mqtt_iothub_update_meter2_energy_data(void)
{
    uint8_t change = 0;
    uint32_t charge = 0;
    uint32_t discharge = 0;
    char date[32] = {0};
    energy_time_t *p_time = NULL;
    municipal_meter_data_t *p_meter2_data = NULL;
    
    // 1、获取各电量实时值
	p_meter2_data = &sdk_shm_get()->mqtt_data.energy_meter2_data;
	if(p_meter2_data == NULL)
	{
		MQTT_DEBUG_PRINT((int8_t *)"energy data is NULL\n");
		return;
	}

    // 2、获取当前时间
    get_energy_time(1);
    change = get_energy_timechange(g_meter2_now_time, g_meter2_last_save_time);
    if(MIN_CHANGE == change)
    {
        p_time = &g_meter2_now_time;
        if ((p_time->minute % 15) == 0)                  //整15分钟采集更新一次
        {	
            snprintf(date, sizeof(date),"%04d-%02d-%02d %02d:%02d:00",p_time->year,\
                        p_time->month, p_time->day, p_time->hour, p_time->minute);
            //执行计量表2数据储存
            discharge = p_meter2_data->positive_active_energy_total; 
            charge = p_meter2_data->negative_active_energy_total;     
            MQTT_DEBUG_PRINT((int8_t *)"update db data, charge = %d  discharge = %d\n", charge, discharge); 
			sqlite_db_update_data(ENERGY_METER2_DB, date, charge, discharge);           
            g_meter2_last_save_time.minute = g_meter2_now_time.minute;
        }
    }
    //日期变化时需要把数据记录到前一天24:00时刻
    else if((DAY_CHANGE == change) || (MONTH_CHANGE == change) || (YEAR_CHANGE == change))                           
    {
        //记录到前一天24:00：00时刻
        //注意，跨天跨月跨年要单独处理
        if((MONTH_CHANGE == change) || (YEAR_CHANGE == change))
        {
            p_time = &g_meter2_last_save_time;
            snprintf(date, sizeof(date),"%04d-%02d-%02d 24:00:00",p_time->year,\
                                                                    p_time->month,\
                                                                    p_time->day);
        }
        else if(DAY_CHANGE == change)
        {
            p_time = &g_meter2_now_time;
            snprintf(date, sizeof(date),"%04d-%02d-%02d 24:00:00",p_time->year,\
                                                                    p_time->month,\
                                                                    p_time->day - 1);
        }
        //执行电表2数据储存
        discharge = p_meter2_data->positive_active_energy_total; 
        charge = p_meter2_data->negative_active_energy_total;     
        MQTT_DEBUG_PRINT((int8_t *)"update db data, charge = %d  discharge = %d\n", charge, discharge); 
        sqlite_db_update_data(ENERGY_METER2_DB, date, charge, discharge);

        //记录到当天00:00:00时刻
        p_time = &g_meter2_now_time;
        snprintf(date, sizeof(date),"%04d-%02d-%02d %02d:%02d:00",p_time->year,\
        p_time->month, p_time->day, p_time->hour, p_time->minute);
        discharge = p_meter2_data->positive_active_energy_total; 
        charge = p_meter2_data->negative_active_energy_total;     
        MQTT_DEBUG_PRINT((int8_t *)"update db data, charge = %d  discharge = %d\n", charge, discharge); 
        sqlite_db_update_data(ENERGY_METER2_DB, date, charge, discharge);
        energy_update_lastsavetime(&g_meter2_last_save_time, g_meter2_now_time);    // 更新时间指针
    }
}


/**
 * @brief  定时更新电表3充放电数据至数据库
 * @return none
 */
void mqtt_iothub_update_meter3_energy_data(void)
{
    uint8_t change = 0;
    uint32_t charge[METER3_MAX_NUM] = {0};
    uint32_t discharge[METER3_MAX_NUM] = {0};
    char date[32] = {0};
    energy_time_t *p_time = NULL;
    municipal_meter_data_t *p_meter3_data = NULL;
    uint8_t i = 0;
    
    constant_parameter_data_t *p_constant_param = sdk_shm_constant_parameter_data_get();

    get_energy_time(2);
    change = get_energy_timechange(g_meter3_now_time, g_meter3_last_save_time);
    if(MIN_CHANGE == change)
    {
        p_time = &g_meter3_now_time;
        if ((p_time->minute % 15) == 0)                  //整15分钟采集更新一次
        {	
            for(i = 0; i < p_constant_param->elec_meter_param.elec_meter3_cnt; i++)
            {
                p_meter3_data = NULL;
                p_meter3_data = &sdk_shm_get()->mqtt_data.energy_meter3_data[i];
                charge[i] = p_meter3_data->negative_active_energy_total;
                discharge[i] = p_meter3_data->positive_active_energy_total;
            }
            snprintf(date, sizeof(date),"%04d-%02d-%02d %02d:%02d:00",p_time->year,\
                        p_time->month, p_time->day, p_time->hour, p_time->minute);
            //执行计量表3数据储存
			sqlite_db_update_meter3_data(ENERGY_METER3_DB, date, charge, discharge);           
            g_meter3_last_save_time.minute = g_meter3_now_time.minute;
        }
    }
    //日期变化时需要把数据记录到前一天24:00时刻
    else if((DAY_CHANGE == change) || (MONTH_CHANGE == change) || (YEAR_CHANGE == change))                           
    {
        //记录到前一天24:00：00时刻
        //注意，跨天跨月跨年要单独处理
        if((MONTH_CHANGE == change) || (YEAR_CHANGE == change))
        {
            p_time = &g_meter3_last_save_time;
            snprintf(date, sizeof(date),"%04d-%02d-%02d 24:00:00",p_time->year,\
                                                                    p_time->month,\
                                                                    p_time->day);
        }
        else if(DAY_CHANGE == change)
        {
            p_time = &g_meter3_now_time;
            snprintf(date, sizeof(date),"%04d-%02d-%02d 24:00:00",p_time->year,\
                                                                    p_time->month,\
                                                                    p_time->day - 1);
        }
        //执行电表3数据储存
        for(i = 0; i < p_constant_param->elec_meter_param.elec_meter3_cnt; i++)
        {
            p_meter3_data = NULL;
            p_meter3_data = &sdk_shm_get()->mqtt_data.energy_meter3_data[i];
            charge[i] = p_meter3_data->negative_active_energy_total;
            discharge[i] = p_meter3_data->positive_active_energy_total;
        }   
        sqlite_db_update_meter3_data(ENERGY_METER3_DB, date, charge, discharge);

        //记录到当天00:00:00时刻
        p_time = &g_meter3_now_time;
        snprintf(date, sizeof(date),"%04d-%02d-%02d %02d:%02d:00",p_time->year,\
        p_time->month, p_time->day, p_time->hour, p_time->minute);    
        sqlite_db_update_meter3_data(ENERGY_METER3_DB, date, charge, discharge);
        energy_update_lastsavetime(&g_meter3_last_save_time, g_meter3_now_time);    // 更新时间指针
    }
}


/**
 * @brief  设置上次记录时间
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
static void set_last_savetime(sdk_rtc_t *now, energy_time_t *p_time) 
{
	if(NULL == p_time)
	{
		return;
	}
	
	p_time->year = now->tm_year + 2000;
	p_time->month = now->tm_mon;
	p_time->day = now->tm_day;
	p_time->hour = now->tm_hour;
	p_time->minute = now->tm_min;
	p_time->second = now->tm_sec;
}


/**
 * @brief  电表数据存储初始化
 * @param  [in] none
 * @param  [out] none
 * @return none
 */
void energy_record_init(void)
{
    sdk_rtc_t now;

    sdk_rtc_get(RTC_BIN_FORMAT, &now);
    
    // 文件夹不存在，先创建文件夹
    if ((sdk_fs_access((int8_t *)PATH_ENERGY_GENERAL_DIR, FS_F_OK)) == -1)
    {
        sdk_fs_mkdir((char *)PATH_ENERGY_GENERAL_DIR, FS_S_IRWXU|FS_S_IRWXG|FS_S_IRWXO);
        MQTT_DEBUG_PRINT((int8_t *)"\n[energy_record_init] '/user/data/energy/' direct not exist but has created! \r\n");
    }
 
    //初始化数据库
    create_energy_table();
    //初始化计量表2数据库
    create_energy_meter2_table();
    //初始化计量表3数据库
    create_energy_meter3_table();
    //记录时间作为基准时间
    set_last_savetime(&now, &g_meter1_last_save_time);
    set_last_savetime(&now, &g_meter2_last_save_time);
    set_last_savetime(&now, &g_meter3_last_save_time);
}


/**
 * @brief  小桔数据循环更新
 * @param  [in] arg
 * @param  [out] none
 * @return none
 */
static void *mqtt_iothub_energy_manage_service(void *arg)
{
	sleep(1);							    // 线程,上电延时1s启动
    energy_record_init();                   // 初始化数据库

	while(1)
	{   	
        //电表1
        mqtt_iothub_update_meter1_energy_data();
        //电表2
        mqtt_iothub_update_meter2_energy_data();
        // //电表3
        mqtt_iothub_update_meter3_energy_data();
		sleep(1);		
	}

	pthread_exit(NULL);

}



/**
 * @brief    针对小桔云平台需要，能量储存模块
 */
void mqtt_iothub_energy_module_init(void)
{
	pthread_t energy_module;
	pthread_attr_t attr;

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);

	if(pthread_create(&energy_module, &attr, mqtt_iothub_energy_manage_service, NULL) != 0)
	{
		perror("pthread_create thread_mqtt_iothub");
	}

	pthread_attr_destroy(&attr);
	return;
}