#ifndef __TICK_TIMER_H__
#define __TICK_TIMER_H__

#include "data_types.h"
#include "sofar_type.h"

typedef void*   tick_timer_handle_t;

/**------------------------------------------------------
 *                 tick timer 组件
 -------------------------------------------------------*/

 /**
 * @brief  tick timer 组件初始化
 * @param  [in] 无
 * @return 0：成功  -1：失败 
 */
sf_ret_t tick_timer_init( void );

/**
 * @brief  创建 tick timer
 * @param  [in] 无
 * @return 非NULL：tick timer句柄
 *         NULL：创建失败  
 */
tick_timer_handle_t tick_timer_create( void );

/**
 * @brief  删除 tick timer
 * @param  [in] usr_tm_hd : tick timer 句柄
 * @return SF_TRUE  : 成功
 *         SF_FALSE : 失败
 */
bool tick_timer_delete( tick_timer_handle_t usr_tm_hd );

/**
 * @brief  刷新tick timer，并清除超时状态
 * @param  [in] usr_tm_hd : tick timer 句柄
 * @return SF_TRUE  : 成功
 *         SF_FALSE : 失败
 */
bool tick_timer_refresh( tick_timer_handle_t usr_tm_hd );

/**
 * @brief  重设tick timer超时时间，并清除超时状态
 * @param  [in] usr_tm_hd : tick timer 句柄
 * @return SF_TRUE  : 成功
 *         SF_FALSE : 失败
 */
bool tick_timer_set_timeout( tick_timer_handle_t usr_tm_hd, uint32_t timeout_ms );

/**
 * @brief  判断tick timer是否已经超时
 * @param  [in] usr_tm_hd : tick timer 句柄
 * @return SF_TRUE  : 超时
 *         SF_FALSE : 未超时
 */
bool tick_timer_is_timeout( tick_timer_handle_t usr_tm_hd );

/**
 * @brief  设置tick timer超时状态
 * @param  [in] usr_tm_hd   : tick timer 句柄
 * @param  [in] timeout_sta : 超时状态
 * @return SF_TRUE  : 成功
 *         SF_FALSE : 失败
 */
bool tick_timer_set_timeout_sta( tick_timer_handle_t usr_tm_hd, bool timeout_sta );

#endif
