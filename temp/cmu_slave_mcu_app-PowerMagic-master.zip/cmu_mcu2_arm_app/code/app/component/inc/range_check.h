#ifndef __RANGE_CHECK_H__
#define __RANGE_CHECK_H__

#include "data_types.h"

/**------------------------------------------------------------------------------------------------
 *      
 *   一、 point 和 range 的关系
 *      N个点(point) 将线分成 N+1个区域(range)，如下
 *  
 *        range0        range1        range2         range3         range4             range5
 *      -----------|--------------|-----------|----------------|----------------|-------------------
 *              point1         point2      point3           point4            point5 
 * 
 *  
 * 
 *   二、参数逻辑
 *      以下以 触发方向为 RANGE_TRIG_DIR_INCREASE 【增加方向】做举例
 *      触发举例：
 *                            触发方向 RANGE_TRIG_DIR_INCREASE
 *                                ----> 
 *               range0         ret  point          range1
 *          ---------------------|----|--------------------------------
 *                                    ^........ 
 *                                   val 
 *           当 val ≥ point ，并持续 trig_valid_cnt 次，进入range1 区间
 * 
 *      
 *  
 *      回退举例：
 *                            触发方向 RANGE_TRIG_DIR_INCREASE
 *                                ----> 
 *               range0         ret  point          range1
 *          ---------------------|----|--------------------------------
 *                          .....^ 
 *                              val  
 *           当 val ≤ (point - ret ) ，并持续 ret_trig_valid_cnt 次，进入range0 区间
 ------------------------------------------------------------------------------------------------**/
typedef int32_t                 range_val_t;                        //< 该组件数值类型 
typedef void*                   range_handle_t;                     //< 句柄

typedef uint8_t                 range_id_t;                         //< range id 数据类型
#define RANGE_ID_INVALID        0xff                                //< 无效 range id， 一般是开机未确定

typedef uint16_t                trig_cnt_t;
#define TRIG_MAX_CNT            0xffff

/* 区域触发的方向 */
typedef enum {
    RANGE_TRIG_DIR_INCREASE,                              //< 数值增加 方向触发
    RANGE_TRIG_DIR_DISCREASE,                             //< 数值减少 方向触发
} range_trig_dir_t;

/* 点信息 */
typedef struct {
    range_val_t      point_val;                             //< 点数值
    range_val_t      ret_diff_val;                          //< 回差值，只能为 正值
} point_t;

/**
 * @brief  区域 ID 改变回调函数，当 区域ID 发生改变时，将触发该回调
 * @param  [in] range_id  当前数值所处 区域ID 【经过过滤和消抖】
 * @param  [in] p_usr_arg   用户回调参数
 */
typedef void(*range_change_callback)( uint8_t range_id, void *p_usr_arg );

/* 区域区间 检测设置 */
typedef struct {
    range_trig_dir_t        trig_dir;                   //< 触发方向
    trig_cnt_t              trig_valid_cnt;             //< 触发有效次数
    trig_cnt_t              ret_diff_valid_cnt;         //< 回差 触发有效次数
    range_change_callback   range_change_cb;            //< 区域ID 改变回调通知
    void                    *p_cb_arg;                  //< 回调参数
} range_setting_t;

/**
 * @brief  区域检测创建   
 * @param  [in] points          所有点的信息，顺序必须是 从小到大
 * @param  [in] point_num       点数量
 * @param  [in] p_range_setting   区域设置 【触发设置 / 回调设置】
 * @return 区域检测句柄，后续通过此句柄进行 输入 或是 获得数据
 */
range_handle_t range_check_create( point_t *points, uint16_t point_num, range_setting_t *p_range_setting );

/**
 * @brief  区域检测 资源释放 
 * @param  [in] range_hd 区域检测句柄
 * @return true： 成功
 *         false：失败。可能原因：句柄无效
 */
bool range_check_delete( range_handle_t range_hd );

/**
 * @brief  区域检测 状态复位 
 * @param  [in] range_hd 区域检测句柄
 * @return true： 成功
 *         false：失败。可能原因：句柄无效
 */
bool range_check_reset( range_handle_t range_hd );

/**
 * @brief  
 * @param  [in] range_hd 区域句柄
 * @param  [in] val    输出数值
 * @return true： 成功
 *         false：失败。可能原因：句柄无效
 */
bool range_check_input( range_handle_t range_hd, range_val_t val );

/**
 * @brief  获取当前 区域ID
 * @param  [in] range_hd 区域句柄
 * @return 当前区域所处的 区间/区域 ID
 */
range_id_t range_get_range_id( range_handle_t range_hd );

/**
 * @brief  设置当前 区域ID
 * @param  [in] range_hd 区域句柄
 * @param  [in] range_id 区域ID
 * @return SF_OK：成功  小于SF_OK: 失败
 */
int32_t range_set_range_id( range_handle_t range_hd, range_id_t range_id );

#endif
