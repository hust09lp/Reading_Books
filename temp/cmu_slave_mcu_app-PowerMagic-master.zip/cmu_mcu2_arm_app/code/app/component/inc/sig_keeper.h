#ifndef _SIG_KEEPER_H_
#define _SIG_KEEPER_H_

#include "sofar_type.h"

typedef void* sig_keeper_hd;

typedef struct {
    bool     hig_prio_sig;
    uint32_t keep_tm_ms;
} sig_keeper_setting_t;

/**
 * @brief  信号保持器初始化
 * @param  [in] 无
 * @return SF_OK：成功  非SF_OK：失败
 * @note   
 */
sf_ret_t bool_sig_keeper_init( void );

/**
 * @brief  创建信号保持器
 * @param  [in] p_sig_keeper_setting :  信号保持器设置【非必选，可谓NULL】
 *                                      NULL则按默认：true 信号保持时间为5s
 * @return 信号保持器句柄，失败为NULL
 */
sig_keeper_hd bool_sig_keeper_create( sig_keeper_setting_t *p_sig_keeper_setting );

/**
 * @brief  信号保持器
 * @param  [in] sig_keeper              : 信号保持器句柄
 * @param  [in] p_sig_keeper_setting    : 信号保持设置参数
 * @return SF_OK：成功  非SF_OK：失败
 */
sf_ret_t bool_sig_keep_setting( sig_keeper_hd sig_keeper, sig_keeper_setting_t *p_sig_keeper_setting );

/**
 * @brief  信号保持器 输入信号
 * @param  [in] sig_keeper : 信号保持器句柄
 * @param  [in] sig_val    : 信号数值
 * @return 返回当前保持信号
 */
bool_val_e bool_sig_keeper_input( sig_keeper_hd sig_keeper, bool_val_e sig_val );

/**
 * @brief  获取 保持器 信号
 * @param  [in] sig_keeper : 信号保持器句柄
 * @return 返回当前保持信号
 */
bool_val_e bool_sig_keeper_get( sig_keeper_hd sig_keeper );

/**
 * @brief  设置 保持器 信号 
 * @param  [in] sig_keeper : 信号保持器句柄
 * @param  [in] sig_val    : 信号数值
 * @return SF_OK：成功  非SF_OK：失败
 */
sf_ret_t bool_sig_keeper_set( sig_keeper_hd sig_keeper, bool_val_e sig_val );


#endif
