#ifndef __APP_MODBUS_H__
#define __APP_MODBUS_H__

#include "data_types.h"

typedef struct {
    uint16_t slave_addr;
    uint16_t reg_addr;
    uint16_t reg_num;
} mb_reg_t;

typedef struct {
    uint32_t pre_req_wait_tm_ms;
    uint32_t rsp_timeout_ms;
} mb_tm_t;


/**
 * @brief   初始化RTU
 * @param   [in] index modbus下标
 * @param   [in] slave_address 从机地址
 * @param   [in] baud 波特率
 * @return  返回执行结果：
 * @return  0 正常
 * @return  -1：异常
 * @note    使用场景：modbus作为主机和从机时均需使用
 */
int32_t app_modbus_rtu_init(uint32_t index, uint32_t slave_address, uint32_t baud);


/**
 * @brief   设置响应超时时间
 * @param   [in] index modbus下标
 * @param   [in] timeout_ms 毫秒,范围值0~10000
 * @return  返回执行结果：
 * @return  0 正常
 * @return  -1：异常
 * @note    modbus作为主机时的从机响应超时时间
 */
int32_t app_modbus_response_timeout_set(uint32_t index, uint32_t timeout_ms);

/**
 * @brief   读取保持寄存器值
 * @param   [in] index modbus下标
 * @param   [in] slave_address 从机地址
 * @param   [in] addr 起始寄存器地址
 * @param   [in] nb 寄存器数量
 * @param   [out] dest 读取的数据的指针
 * @param   [in]  pre_wait_tm_ms 发送指令前的等待时间
 * @return  返回执行结果：-1异常
 * @note    使用场景：modbus作为主机时使用，会发送数据并处理从机返回的数据
 */
int32_t app_modbus_registers_read(uint32_t index, uint32_t slave_address, int32_t addr, int32_t nb, uint16_t *dest, uint32_t pre_wait_tm_ms);

/**
 * @brief   写单个保持寄存器
 * @param   [in] index modbus下标
 * @param   [in] slave_address 从机地址
 * @param   [in] addr 寄存器地址
 * @param   [in] value 写入值
 * @param   [in]  pre_wait_tm_ms 发送指令前的等待时间
 * @return  返回执行结果：-1异常
 * @note    使用场景：modbus作为主机时使用，会发送数据并处理从机返回的数据
 */
int32_t app_modbus_register_write(uint32_t index, uint32_t slave_address, int32_t addr, const uint16_t value, uint32_t pre_wait_tm_ms);

/**
 * @brief   写多个保持寄存器
 * @param   [in] index modbus下标
 * @param   [in] slave_address 从机地址
 * @param   [in] addr 寄存器起始地址
 * @param   [in] nb 寄存器数量
 * @param   [in] data 写入值的指针
 * @param   [in]  pre_wait_tm_ms 发送指令前的等待时间
 * @return  返回执行结果：-1异常
 * @note    使用场景：modbus作为主机时使用，会发送数据并处理从机返回的数据
 */
int32_t app_modbus_registers_write(uint32_t index, uint32_t slave_address, int32_t addr, int32_t nb, const uint16_t *data, uint32_t pre_wait_tm_ms);

/**
 * @brief   读取线圈状态
 * @param   [in]  index modbus下标
 * @param   [in] slave_address 从机地址
 * @param   [in]  addr  起始线圈地址
 * @param   [in]  nb    要读取的线圈数量 (最大0x7D0)
 * @param   [out] p_des 读取的数据的指针
 * @param   [in]  pre_wait_tm_ms 发送指令前的等待时间
 * @return  返回执行结果：
 * @retval  >=0 正常
 * @retval  < 0 为异常，详情见sofar_errors.h
 * @note    使用场景：modbus作为主机时使用，会发送数据并处理从机返回的数据
 *          注意：读取的数据，0表示OFF，1表示ON。第1个数据标识查询的起始地址线圈的状态值，其他线圈依次类推。
 */
int32_t app_modbus_coils_read(uint32_t index, uint32_t slave_address, int32_t addr, int32_t nb, uint8_t *p_dest, uint32_t pre_wait_tm_ms);

/**
 * @brief   写单个线圈
 * @param   [in] index modbus下标
 * @param   [in] slave_address 从机地址
 * @param   [in] addr  线圈地址
 * @param   [in] value 要写入的值：false或true
 * @param   [in]  pre_wait_tm_ms 发送指令前的等待时间
 * @return  返回执行结果：
 * @retval  >=0 正常
 * @retval  < 0 为异常，详情见sofar_errors.h
 * @note    使用场景：modbus作为主机时使用，会发送数据并处理从机返回的数据
 *          注意：写入的值，false表示OFF，true表示ON。
 */
int32_t app_modbus_coil_write(uint32_t index, uint32_t slave_address, int32_t addr, const bool value, uint32_t pre_wait_tm_ms);

/**
 * @brief   写多个线圈
 * @param   [in] index  modbus下标
 * @param   [in] slave_address 从机地址
 * @param   [in] addr   起始线圈地址
 * @param   [in] nb     要写入的线圈数量 (最大0x7B0)
 * @param   [in] p_data 要写入值的指针
 * @return  返回执行结果：
 * @retval  >=0 正常
 * @retval  < 0 为异常，详情见sofar_errors.h
 * @note    使用场景：modbus作为主机时使用，会发送数据并处理从机返回的数据
 *          注意：写入的值，0表示OFF，1表示ON。第1个数据标识写入的起始地址线圈的状态值，其他线圈依次类推。
 */
int32_t app_modbus_coils_write(uint32_t index, uint32_t slave_address, int32_t addr, int32_t nb, const uint8_t *p_data, uint32_t pre_wait_tm_ms);

/**
 * @brief   modbus连接
 * @param   [in] index modbus下标
 * @return  返回执行结果：
 * @return  0 正常
 * @return  -1：异常
 * @note    modbus的rtu函数需要使用，在rtu初始化之后需要调用此函数连接
 */
int32_t app_modbus_connect(uint32_t index);

/**
 * @brief   modbus关闭
 * @param   [in] index modbus下标
 * @return  返回执行结果：
 * @return  0 正常
 * @return  -1：异常
 */
int32_t app_modbus_close(uint32_t index);


#endif
