#ifndef __EXTERN_IO_H__
#define __EXTERN_IO_H__

#include "data_types.h"
#include "sofar_type.h"

#define EXTERN_IO_PORT_NUM              8

/**
  * @enum io_sta_e
  * @brief  IO 电平状态
  */
typedef enum {
    IO_STA_LOW = 0,                 //< 低电平
    IO_STA_HIG = 1,                 //< 高电平
    IO_STA_NONE,                    //< 未知【不存在的端口】
} io_sta_e;

/**
 * @brief  IO 拓展模块 DI 电平变化回调 
 * @param  [in] mod_index  ：IO 拓展板模块 索引/位置 （ 0 ~ (EXTERN_IO_PORT_NUM - 1) ）
 * @param  [in] io_port    ：DI 端口 【0开始】
 * @param  [in] io_lv      ：电平状态
 */
typedef void (*ext_io_input_lv_change_callback)( uint8_t mod_index, uint8_t io_port, bool io_lv );

/**
 * @brief  IO 拓展模块 在线状态 变化回调 
 * @param  [in] mod_index  ：IO 拓展板模块 索引/位置 （ 0 ~ (EXTERN_IO_PORT_NUM - 1) ）
 * @param  [in] online     ：在线状态
 */
typedef void (*ext_io_mod_online_change_callback)( uint8_t mod_index, bool online );

/**
 * @brief  IO 拓展板初始化
 * @param  [in] modbus_idx ：modbus index
 * @param  [in] baud_rate   ：通讯速率
 * @param  [in] modbus_init ：是否需要进行modbus初始化
 * @param  [in] lv_change_cb ：电平变化回调 【可选】
 * @param  [in] online_change_cb  ：IO拓展板在线状态回调【可选】
 * @return 
 */
sf_ret_t extern_io_init( uint32_t modbus_idx, uint32_t baud_rate, bool modbus_init,
                        ext_io_input_lv_change_callback lv_change_cb,  
                        ext_io_mod_online_change_callback online_change_cb );
/**
 * @brief  IO 拓展模块 使能
 * @param  [in] mod_index     : io拓展板模块 索引/位置 （ 0 ~ (EXTERN_IO_PORT_NUM - 1) ）
 * @param  [in] enable        : 对应位置 使能轮询 （ 1：使能 0：不使能 ）
 * @param  [in] mb_slave_addr : 对应模块 modbus 从机地址
 * @return SF_OK：成功  小于SF_OK: 失败
 */
sf_ret_t  extern_io_set_mod_enable( uint8_t mod_index, bool enable, uint8_t mb_slave_addr );

/**
 * @brief  设置 IO 拓展模块 端口电平【同步】
 * @param  [in] mod_index : io拓展板模块 索引/位置 （ 0 ~ (EXTERN_IO_PORT_NUM - 1) ）
 * @param  [in] io_port   : DO 端口 【0开始】
 * @param  [in] lv        : 电平状态
 * @return SF_OK：成功  小于SF_OK: 失败
 */
sf_ret_t  extern_io_set_output_lv( uint8_t mod_index, uint8_t io_port, bool lv );

/**
 * @brief  设置 IO 拓展模块 端口电平【同步】
 * @param  [in] mod_index : io拓展板模块 索引/位置 （ 0 ~ (EXTERN_IO_PORT_NUM - 1) ）
 * @param  [in] io_port   : DO 端口 【0开始】
 * @param  [in] lv        : 电平状态
 * @return SF_OK：成功  小于SF_OK: 失败
 */
sf_ret_t  extern_io_set_output_lv_sync( uint8_t mod_index, uint8_t io_port, bool lv );

/**
 * @brief  获取 IO拓展模块 在线状态
 * @param  [in] mod_index : io拓展板模块 索引/位置 （ 0 ~ (EXTERN_IO_PORT_NUM - 1) ）
 * @return 详见返回值 枚举说明
 */
ol_sta_e extern_io_get_online_sta( uint8_t mod_index );

/**
 * @brief  获取 IO拓展模块 DI电平 【缓存获取】
 * @param  [in] mod_index : io拓展板模块 索引/位置 （ 0 ~ (EXTERN_IO_PORT_NUM - 1) ）
 * @param  [in] io_port   : DI端口
 * @return 详见返回值 枚举说明
 */
io_sta_e extern_io_get_input_lv( uint8_t mod_index, uint8_t io_port );

/**
 * @brief  获取 IO拓展模块 DI电平【同步获取，modbus获取】
 * @param  [in] mod_index : io拓展板模块 索引/位置 （ 0 ~ (EXTERN_IO_PORT_NUM - 1) ）
 * @param  [in] io_port   : DI端口
 * @return 详见返回值 枚举说明
 */
io_sta_e extern_io_get_input_lv_sync( uint8_t mod_index, uint8_t io_port );

/**
 * @brief  获取 IO 拓展板丢包率
 * @param  [in] mod_index : io拓展板模块 索引/位置 （ 0 ~ (EXTERN_IO_PORT_NUM - 1) ）
 * @return 返回丢包率
 */
rate_t extern_io_get_com_loss_rate( uint8_t mod_index );

/**
 * @brief  IO 拓展板 任务调度
 * @param  [in] void
 */
void extern_io_task_loop( void );

#endif
