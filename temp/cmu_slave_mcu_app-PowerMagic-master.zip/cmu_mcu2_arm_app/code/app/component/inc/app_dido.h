#ifndef __APP_DIDO_H__
#define __APP_DIDO_H__

#include "sofar_type.h"

/**
 * @brief  读取 DI 滤波之后的数值
 * @param  [in] di_id : DI id数值 （DI_1 ~ DI_MAX）
 * @return 0：低电平  1：高电平  -1：参数错误
 * @note   
 */
int32_t app_dido_read( uint8_t di_id );

/**
 * @brief  dido 滤波任务 【上层循环调用】
 * @return 
 * @note   
 */
void app_dido_filter_task_loop( void );

#endif
