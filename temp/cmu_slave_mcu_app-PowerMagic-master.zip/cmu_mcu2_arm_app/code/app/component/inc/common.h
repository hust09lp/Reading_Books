/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     common.h
  * @brief    App common functional module header file
  * @company  SOFARSOLAR
  * @author   HH
  * @note
  * @version  V01
  * @date     2023/02/22
  */
/*****************************************************************************/

#ifndef __COMMON_H__
#define __COMMON_H__

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Include project file ------------------------------------------------------

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#undef NULL
#define NULL                                                                (0)

#undef FALSE
#define FALSE                                                               (0)
#undef TRUE
#define TRUE                                                                (1)

#define INACTIVE                                                            (0)
#define ACTIVE                                                              (1)

#define OFF                                                                 (0)
#define ON                                                                  (1)

#define DISABLE                                                             (0)
#define ENABLE                                                              (1)

#define DEBUG_MODE                                                          (0)

//
#define PI_DIV3     (1.0471975511965977461f)
#define PI          (3.1415926535897932385f)
#define DOUBLE_PI   (6.2831853071795864793f)
#define SQRT2       (1.4142136f)
#define SQRT3       (1.7320508f)
#define DIV_SQRT3   (0.5773503f)
#define ONE_DIV3    (0.3333333f)
#define TWO_DIV3    (0.6666666f)

#define BIT_CPL(var, bit) ((var) ^= (1 << (bit)))
#define BIT_SET(var, bit) ((var) |= (1 << (bit)))
#define BIT_CLR(var, bit) ((var) &=~(1 << (bit)))
#define BIT_GET(var, bit) (((var) & (1 << bit)) >> bit)

#define ALG_ABC2ALPHABETA(a, b, c, alpha, beta)                 \
do {                                                            \
    alpha = 0.66667f * (a) - 0.33333f * (b) - 0.33333f * (c);   \
    beta = 0.57735f * (b) - 0.57735f * (c);                     \
} while (0)

#define ALG_ALPHABETA2ABC(alpha, beta, a, b, c)                 \
do {                                                            \
    a = alpha;                                                  \
    b = 0.866025f * (beta) - 0.5f * (alpha);                    \
    c = -0.866025f * (beta) - 0.5f * (alpha);                   \
} while (0)

#define ALG_ALPHABETA2DQ(alpha, beta, sin_theta, cos_theta, d, q) \
do {                                                              \
    d = (alpha) * (sin_theta) - (beta) * (cos_theta);             \
    q = (beta) * (sin_theta) + (alpha) * (cos_theta);             \
} while(0)

#define ALG_DQ2ALPHABETA(d, q, sin_theta, cos_theta, alpha, beta) \
do {                                                              \
    alpha = (d) * (sin_theta) + (q) * (cos_theta);                \
    beta = (q) * (sin_theta) - (d) * (cos_theta);                 \
} while(0)

#define ALG_THEATA_ROTATION(d1, q1, sin_theta, cos_theta, d2, q2) \
do {                                                              \
    d2 = (d1) * (cos_theta) + (q1) * (sin_theta);                 \
    q2 = (q1) * (cos_theta) - (d1) * (sin_theta);                 \
} while(0)

#define BIG_2_SMALL(high, low)                          (((high) << 8) | (low))

#define PARAMETER_ACCURACY_MAGNIFICATION_0                          (0.00001f)
#define PARAMETER_ACCURACY_MAGNIFICATION_1                          (0.0001f)
#define PARAMETER_ACCURACY_MAGNIFICATION_2                          (0.001f)
#define PARAMETER_ACCURACY_MAGNIFICATION_3                          (0.01f)
#define PARAMETER_ACCURACY_MAGNIFICATION_4                          (0.1f)
#define PARAMETER_ACCURACY_MAGNIFICATION_5                          (1.0f)
#define PARAMETER_ACCURACY_MAGNIFICATION_6                          (10.0f)
#define PARAMETER_ACCURACY_MAGNIFICATION_7                          (100.0f)
#define PARAMETER_ACCURACY_MAGNIFICATION_8                          (1000.0f)
#define PARAMETER_ACCURACY_MAGNIFICATION_9                          (10000.0f)

#define MASK_BITS(n)                                           ((1 << (n)) - 1)
/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
// data read/write status code definition
typedef enum
{
	DATA_FREE = 0,
	DATA_READING,
	DATA_WRITING,
}DATA_RW_E;

typedef enum
{
	NO_ERR       =  0,
	NO_DATA      = -1,
	DATA_BUSY    = -2,
	WRITE_FAIL   = -3,
	READ_FAIL    = -4,
	ADDR_INVALID = -5
}RESULT_E;

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/
typedef _Bool                                                           bool_t;
typedef float                                                        float32_t;
typedef double                                                       float64_t;

typedef struct
{
	uint16_t b0  : 1;
	uint16_t b1  : 1;
	uint16_t b2  : 1;
	uint16_t b3  : 1;
	uint16_t b4  : 1;
	uint16_t b5  : 1;
	uint16_t b6  : 1;
	uint16_t b7  : 1;
	uint16_t b8  : 1;
	uint16_t b9  : 1;
	uint16_t b10 : 1;
	uint16_t b11 : 1;
	uint16_t b12 : 1;
	uint16_t b13 : 1;
	uint16_t b14 : 1;
	uint16_t b15 : 1;
}bits_t;

typedef struct
{
	uint16_t low  : 8;
	uint16_t high : 8;
}bytes_t;

typedef union
{
	bits_t   bits;
	bytes_t  bytes;
	uint16_t all;
}half_word_t;

typedef union
{
	uint8_t     byte[4];
	half_word_t half_word[2];
	uint32_t    all;
}word_t;

typedef struct
{
	float32_t high_limit;
	float32_t low_limit;
	float32_t *output_high;
	float32_t *output_low;
	uint8_t   *mode;
	float32_t *input;
	float32_t *output;
}hysteresis_t;

typedef union
{
    float32_t float_value;
    uint8_t uint8[4];
}float_union;

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void clear_struct_data(uint8_t *ptr, uint32_t size);
void fill_struct_data(uint8_t *ptr, uint8_t value, uint32_t size);
void memory_copy(void *dest, const void *src, uint32_t num);
void memory_set(void *dest, uint8_t data, uint32_t num);
void constrain_float_data(float32_t *data, float32_t low, float32_t high);
void constrain_uint16_t_data(uint16_t *data, uint16_t low, uint16_t high);
void constrain_int16_t_data(int16_t *data, int16_t low, int16_t high);
void constrain_uint32_t_data(uint32_t *data, uint32_t low, uint32_t high);
void constrain_float32_t_data(float32_t *data, float32_t low, float32_t high);
void bcd_to_hex(uint8_t *bcd, uint8_t *hex);
void hex_to_bcd(uint8_t *bcd, uint8_t *hex);
void hysteresis_process(hysteresis_t *hysteresis);
float32_t uint32_to_float(uint16_t value1, uint16_t value2);
float32_t uint32_to_float_2(uint8_t* value);
int32_t max(int32_t value1, int32_t value2);
int32_t min(int32_t value1, int32_t value2);
float32_t absolute(float32_t value);
uint32_t abs_int2uint(int32_t value);
int32_t min_three_argu(int32_t value1, int32_t value2, int32_t value3);
//int8_t transfer_index(uint8_t *index_array, uint8_t value);
extern inline void check_uint16_validity(uint16_t data, uint16_t low, uint16_t high, bool_t *result);
extern inline void check_uint8_validity(uint8_t data, uint8_t low, uint8_t high, bool_t *result);
extern inline void check_int16_validity(int16_t data, int16_t low, int16_t high, bool_t *result);
int8_t symbol_judgment_int16(int16_t data);
void word_2_byte(uint32_t dest, uint8_t *source, uint8_t *index);
void byte_2_word(uint32_t *dest, uint8_t *source, uint8_t *index);
void byte_2_halfword(uint16_t *dest, uint8_t *source, uint8_t *index);
void halfword_2_byte(uint16_t source, uint8_t *dest, uint8_t *index);
float32_t calc_vector_modulus(float32_t value1, float32_t value2);
#endif
/******************************************************************************
* End of module
******************************************************************************/
