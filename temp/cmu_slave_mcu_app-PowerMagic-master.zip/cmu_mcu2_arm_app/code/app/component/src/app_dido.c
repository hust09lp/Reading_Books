#include "app_dido.h"
#include "app_cfg.h"

#include "sdk.h"
#include "sdk_core.h"


#define VALID_LV_CNT                    90      //< 检测有效电平次数

typedef struct 
{
    bool    enable;
    uint8_t tmp_lv_cnt;
    uint8_t tmp_level;
    uint8_t level;
} di_filter_t;

di_filter_t di_filter[ DI_MAX ] = { { 0, 0, 0 } };

/**
 * @brief  开启 DI ID 滤波功能
 * @param  [in] di_id： DI id数值
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
static sf_ret_t _app_di_filter_enable(uint8_t di_id)
{
    if( di_id >= DI_MAX )
    {
        sdk_log_e("%s di_id:%d out of range", __FUNCTION__, di_id );
        return SF_ERR_PARA;
    }

    di_filter[ di_id ].enable      = SF_TRUE;
    di_filter[ di_id ].level       = sdk_dido_read( di_id );
    di_filter[ di_id ].tmp_level   = di_filter[ di_id ].level;
    di_filter[ di_id ].tmp_lv_cnt  = 0;

    return SF_OK;
}

/**
 * @brief  读取 DI 滤波之后的数值
 * @param  [in] di_id : DI id数值 （DI_1 ~ DI_MAX）
 * @return 0：低电平  1：高电平  -1：参数错误
 * @note   
 */
int32_t app_dido_read(uint8_t di_id)
{
    if( di_id >= DI_MAX )
    {
        sdk_log_e("%s di_id:%d out of range", __FUNCTION__, di_id );
        return -1;
    }

    if( di_filter[ di_id ].enable == false )
    {
        _app_di_filter_enable( di_id );
    }

    return di_filter[ di_id ].level;
}

/**
 * @brief  dido 滤波任务 【上层循环调用】
 * @return 
 * @note   
 */
void app_dido_filter_task_loop( void )
{
    for (size_t i = 0; i < ARRAY_SIZE( di_filter ) ; i++)
    {
        if( di_filter[i].enable )
        {
            int32_t di_lv = sdk_dido_read( i );

            if( di_lv != di_filter[i].tmp_level )
            {
                di_filter[i].tmp_level  = di_lv;
                di_filter[i].tmp_lv_cnt = 0;
            }else{
                di_filter[i].tmp_lv_cnt++;
            }

            if( di_filter[i].tmp_lv_cnt >= VALID_LV_CNT )
            {
                di_filter[i].level = di_filter[i].tmp_level;
            }
        }
    }
}
