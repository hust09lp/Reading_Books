#include "range_check.h"

#include "sdk.h"
#include "sdk_core.h"

#include <string.h>

#define STRUCT_ENTRY( ptr, type, member )   ((type*)((uint8_t*)ptr - (uint8_t*)(&((type *)0)->member)))
#define ARRAY_SIZE(array)                   ( array / array[0] )

#define MAX_RANGE_NODE_NUM                  20
#define MAX_POINT_NUM                       5

/* 坐标点被触发和回退的信息 */
typedef struct {
    trig_cnt_t    trig_cnt;                   //< 触发次数， 当持续超过 trig_valid_cnt 次，进入对应区间
    trig_cnt_t    ret_cnt ;                   //< 回退次数， 当持续超过 ret_diff_valid_cnt 次，退出对应区间
} point_info_t;

/* 区间范围相关信息 */
typedef struct {
    struct range_check
    {
        range_setting_t setting;                        //< 区间设置信息【触发信息 和 回调信息】
        uint8_t         point_num;                      //< 坐标点 数量
        point_t         points[ MAX_POINT_NUM ];        //< 坐标点信息 【坐标值 和 回退值】
    } attr;                                             //< 属性 【即为用户设置】

    struct {
        range_id_t      now_range_id;                   //< 当前所处区间 ID
        point_info_t    point_infos[ MAX_POINT_NUM ];   //< 对应坐标点被触发的信息
    } run;                                              //< 运行信息
} range_node_t;

typedef struct {
    bool            valid;
    range_node_t    range_node;
} range_node_info_t;

static range_node_info_t  s_range_node_list[ MAX_RANGE_NODE_NUM ] = {{.valid = false}};


static range_node_t* _range_node_malloc( void );
static bool _range_check_set_range_id( range_node_t *p_range_node, range_id_t range_id );
//static uint8_t node_num = 0;

/**
 * @brief  区域检测创建   
 * @param  [in] points          所有点的信息
 * @param  [in] point_num       点数量
 * @param  [in] p_range_setting   区域设置 【触发设置 / 回调设置】
 * @return 区域检测句柄，后续通过此句柄进行 输入 或是 获得数据
 */
range_handle_t range_check_create( point_t *points, uint16_t point_num, range_setting_t *p_range_setting )
{
    range_node_t *p_new_range;

    if( point_num > MAX_POINT_NUM )
    {
        return NULL;
    }

    p_new_range = _range_node_malloc();
    if( p_new_range == NULL )
    {
        sdk_log_e("p_new_range == NULL");
        return NULL;
    }

    memset( p_new_range, 0, sizeof( range_node_t ) );

    p_new_range->attr.setting   = *p_range_setting;
    p_new_range->attr.point_num = point_num;
    memcpy( p_new_range->attr.points, points, sizeof(point_t) * point_num );
    p_new_range->run.now_range_id = RANGE_ID_INVALID;
    /* TODO：合法性检查 */
    /* .... */
    // node_num++;
    // sdk_log_d("create - node_num:%d", node_num);

    return (range_handle_t)p_new_range;
}

/**
 * @brief  区域检测 资源释放 
 * @param  [in] range_hd 区域检测句柄
 * @return true： 成功
 *         false：失败。可能原因：句柄无效
 */
bool range_check_delete( range_handle_t range_hd )
{
    if( range_hd == NULL )
    {
        return false;
    }

    range_node_info_t *p_range_node_info = STRUCT_ENTRY( range_hd, range_node_info_t, range_node );

    if( ((uint8_t*)p_range_node_info - (uint8_t*)s_range_node_list) % sizeof( range_node_info_t ) != 0 )
    {
        return false;
    }

    memset( p_range_node_info, 0, sizeof( range_node_info_t ) );
    // node_num--;
    // sdk_log_d("delete - node_num:%d", node_num);
    
    return true;
}

/**
 * @brief  区域检测 状态复位 
 * @param  [in] range_hd 区域检测句柄
 * @return true： 成功
 *         false：失败。可能原因：句柄无效
 */
bool range_check_reset( range_handle_t range_hd )
{
    if( range_hd == NULL )
    {
        return false;
    }

    range_node_info_t *p_range_node_info = STRUCT_ENTRY( range_hd, range_node_info_t, range_node );
    p_range_node_info->range_node.run.now_range_id = RANGE_ID_INVALID;
    memset( p_range_node_info->range_node.run.point_infos, 0, sizeof( p_range_node_info->range_node.run.point_infos) );
    
    return true;
}

static bool _range_check_set_range_id( range_node_t *p_range_node, range_id_t range_id )
{
    if( range_id == RANGE_ID_INVALID )
    {
        return false;
    }

    if( p_range_node->run.now_range_id != range_id )
    {
        p_range_node->run.now_range_id = range_id;
        if( p_range_node->attr.setting.range_change_cb )
        {
            p_range_node->attr.setting.range_change_cb(p_range_node->run.now_range_id, p_range_node->attr.setting.p_cb_arg);
        }
    }
    return true;
}

/**
 * @brief  
 * @param  [in] range_hd 区域句柄
 * @param  [in] val    输出数值
 * @return true： 成功
 *         false：失败。可能原因：句柄无效
 */
bool    range_check_input( range_handle_t range_hd, range_val_t val )
{
    uint8_t      i, usr_point_num;
    point_t      *p_usr_point_list;
    point_info_t *p_run_points_info;

    range_node_t *p_range_node = (range_node_t *)range_hd;

    if( p_range_node == NULL )
    {
        return false;
    }

    usr_point_num       = p_range_node->attr.point_num;
    p_usr_point_list    = p_range_node->attr.points;
    p_run_points_info   = p_range_node->run.point_infos;

    /**
     *  累计 触发次数 和 回退次数 
     * 由于触发和回退为互斥关系，所以
     * 触发累计增加时，会将回退累计清零
     * 回退累计增加时，会将触发累计清零 
     */
    for( i = 0; i < usr_point_num; i++ ) 
    {
        if( p_range_node->attr.setting.trig_dir == RANGE_TRIG_DIR_INCREASE )
        {
            /* 数值往增加的方向触发 */
            if( p_usr_point_list[i].point_val <= val )
            {
                /** 
                 * ↑    val
                 * ↑  --------  point_val
                 * ↑            ret_val
                 * ↑  --------  point_val - ret_val
                 */
                /* 触发 */
                p_run_points_info[i].ret_cnt = 0;
                if( p_run_points_info[i].trig_cnt < TRIG_MAX_CNT )
                {
                    p_run_points_info[i].trig_cnt++;
                }
            }
            else if ((p_usr_point_list[i].point_val - p_usr_point_list[i].ret_diff_val) >= val)
            {
                /**
                 * ↑   
                 * ↑ --------  point_val
                 * ↑           ret_val
                 * ↑ --------  point_val - ret_val
                 * ↑    val
                 */
                /* 回退 */
                p_run_points_info[i].trig_cnt = 0;
                if( p_run_points_info[i].ret_cnt < TRIG_MAX_CNT )
                {
                    p_run_points_info[i].ret_cnt++;
                }
            }
            else
            {
                /**
                 * ↑   
                 * ↑ --------  point_val
                 * ↑    val    ret_val
                 * ↑ --------  point_val - ret_val
                 * ↑    
                 */
                if ( p_range_node->run.now_range_id == RANGE_ID_INVALID )
                {
                    /* 刚开始，未确定位置 */
                    p_run_points_info[i].trig_cnt = 0;
                    if( p_run_points_info[i].ret_cnt < TRIG_MAX_CNT )
                    {
                        p_run_points_info[i].ret_cnt++;
                    }
                }else {
                    p_run_points_info[i].ret_cnt = 0;
                    p_run_points_info[i].trig_cnt = 0;
                }
            }
        }
        else if (p_range_node->attr.setting.trig_dir == RANGE_TRIG_DIR_DISCREASE)
        {
            /* 数值往减小的方向触发 */
            if( p_usr_point_list[i].point_val >= val )
            {
                /** 
                 * ↓  --------  point_val + ret_val
                 * ↓            ret_val
                 * ↓  --------  point_val
                 * ↓    val
                 */
                /* 触发 */
                p_run_points_info[i].ret_cnt = 0;
                if( p_run_points_info[i].trig_cnt < TRIG_MAX_CNT )
                {
                    p_run_points_info[i].trig_cnt++;
                }
            }else if( (p_usr_point_list[i].point_val + p_usr_point_list[i].ret_diff_val) <= val )
            {
                /** 
                 * ↓    val
                 * ↓  --------  point_val + ret_val
                 * ↓            ret_val
                 * ↓  --------  point_val
                 */
                /* 回退 */
                p_run_points_info[i].trig_cnt = 0;
                if( p_run_points_info[i].ret_cnt < TRIG_MAX_CNT )
                {
                    p_run_points_info[i].ret_cnt++;
                }
            }
            else
            {
                /** 
                 * ↓    
                 * ↓  --------  point_val + ret_val
                 * ↓     val    ret_val
                 * ↓  --------  point_val
                 */
                if ( p_range_node->run.now_range_id == RANGE_ID_INVALID )
                {
                    /* 刚开始，未确定位置 */
                    p_run_points_info[i].trig_cnt = 0;
                    if( p_run_points_info[i].ret_cnt < TRIG_MAX_CNT )
                    {
                        p_run_points_info[i].ret_cnt++;
                    }
                }else{
                    p_run_points_info[i].ret_cnt = 0;
                    p_run_points_info[i].trig_cnt = 0;
                }
            }
        }
    }

    if( p_range_node->attr.setting.trig_dir == RANGE_TRIG_DIR_INCREASE )
    {
        /* 增加方向时候， 触发以高区间优先，回退以低区间优先 */
        range_id_t trig_max_range_id = RANGE_ID_INVALID;
        range_id_t ret_min_range_id  = RANGE_ID_INVALID;

        for( i = 0; i < usr_point_num; i++ ) 
        {
            /* 触发检查，从高往低查 */
            if( (trig_max_range_id == RANGE_ID_INVALID)
                && (p_run_points_info[ usr_point_num - i - 1 ].trig_cnt >= p_range_node->attr.setting.trig_valid_cnt) )
            {
                trig_max_range_id = usr_point_num - i;
            }
            
            /* 回退检查，从低往高查 */
            if( (ret_min_range_id == RANGE_ID_INVALID)
                && (p_run_points_info[ i ].ret_cnt >= p_range_node->attr.setting.ret_diff_valid_cnt) )
            {
                ret_min_range_id = i;
            }
        }
        
        if( p_range_node->run.now_range_id == RANGE_ID_INVALID )
        {
            if( trig_max_range_id != RANGE_ID_INVALID )
            {
                _range_check_set_range_id( p_range_node, trig_max_range_id );
            }
            else if (ret_min_range_id != RANGE_ID_INVALID)
            {
                _range_check_set_range_id( p_range_node, ret_min_range_id );
            }
        }

        if( p_range_node->run.now_range_id != RANGE_ID_INVALID )
        {
            bool trig_debug = false;
            bool ret_debug = false;

            if( trig_max_range_id != RANGE_ID_INVALID )
            {
                /* 触发更高区间，以更高区间为主 */
                if( trig_max_range_id > p_range_node->run.now_range_id )
                {
                    _range_check_set_range_id( p_range_node, trig_max_range_id );
                    trig_debug = true;
                }
            }

            if( ret_min_range_id != RANGE_ID_INVALID )
            {
                /* 回退低区间，以回退为准 */
                if( ret_min_range_id < p_range_node->run.now_range_id )
                {
                    _range_check_set_range_id( p_range_node, ret_min_range_id );
                    ret_debug = true;
                }
            }
            
            if( (trig_debug == true) && (ret_debug == true) )
            {
                sdk_log_d("ERROR:both trig / ret is true!!!!!");
            }
        }
    }

    if( p_range_node->attr.setting.trig_dir == RANGE_TRIG_DIR_DISCREASE )
    {
        /* 减小方向时候， 触发以低区间优先，回退以高区间优先 */
        range_id_t trig_min_range_id = RANGE_ID_INVALID;
        range_id_t ret_max_range_id  = RANGE_ID_INVALID;

        for( i = 0; i < usr_point_num; i++ ) 
        {
            /* 触发检查，从低往高查 */
            if( (trig_min_range_id == RANGE_ID_INVALID)
                && ( p_run_points_info[ i ].trig_cnt >= p_range_node->attr.setting.trig_valid_cnt) )
            {
                trig_min_range_id = i;
            }
            
            /* 回退检查，从高往低查 */
            if( ( ret_max_range_id == RANGE_ID_INVALID )
                && (p_run_points_info[ usr_point_num - i - 1 ].ret_cnt >= p_range_node->attr.setting.ret_diff_valid_cnt) )
            {
                ret_max_range_id = usr_point_num - i;
            }
        }

        if( p_range_node->run.now_range_id == RANGE_ID_INVALID )
        {
            if( trig_min_range_id != RANGE_ID_INVALID )
            {
                _range_check_set_range_id( p_range_node, trig_min_range_id );
            }
            else if (ret_max_range_id != RANGE_ID_INVALID)
            {
                _range_check_set_range_id( p_range_node, ret_max_range_id );
            }
        }

        if( p_range_node->run.now_range_id != RANGE_ID_INVALID )
        {
            bool trig_debug = false;
            bool ret_debug = false;

             if( trig_min_range_id != RANGE_ID_INVALID )
            {
                /* 触发更低区间，以低区间为主 */
                if( trig_min_range_id < p_range_node->run.now_range_id )
                {
                    _range_check_set_range_id( p_range_node, trig_min_range_id );
                    trig_debug = true;
                }
            }

            if( ret_max_range_id != RANGE_ID_INVALID )
            {
                /* 回退高区间，以回退为准 */
                if( ret_max_range_id > p_range_node->run.now_range_id )
                {
                    _range_check_set_range_id( p_range_node, ret_max_range_id );
                    ret_debug = true;
                }
            }
            
            if( (trig_debug == true) && (ret_debug == true) )
            {
                sdk_log_d("ERROR2:both trig / ret is true!!!!!");
            }
        }
    }
    return true;
}

/**
 * @brief  获取当前 区域ID
 * @param  [in] range_hd 区域句柄
 * @return 当前区域所处的 区间/区域 ID
 */
range_id_t range_get_range_id( range_handle_t range_hd )
{
    range_node_t *p_range_node = (range_node_t *)range_hd;

    return p_range_node->run.now_range_id;
}

/**
 * @brief  设置当前 区域ID
 * @param  [in] range_hd 区域句柄
 * @param  [in] range_id 区域ID
 * @return SF_OK：成功  小于SF_OK: 失败
 */
int32_t range_set_range_id( range_handle_t range_hd, range_id_t range_id )
{
    range_node_t *p_range_node = (range_node_t *)range_hd;

    if ( range_hd == NULL )
    {
        return SF_ERR_PARA;
    }

    p_range_node->run.now_range_id = range_id;
    memset( p_range_node->run.point_infos, 0, sizeof( p_range_node->run.point_infos) );

    return SF_OK;
}

static range_node_t* _range_node_malloc( void )
{
    uint8_t i;

    for ( i = 0; i < MAX_RANGE_NODE_NUM; i++)
    {
        if( s_range_node_list[i].valid == false )
        {
            s_range_node_list[i].valid = true;
            return &s_range_node_list[i].range_node;
        }
    }
    return NULL;
}
