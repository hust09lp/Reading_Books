#include "sig_keeper.h"

#include "sdk.h"
#include "sdk_core.h"
#include "sdk_log.h"

#define  SIG_KEEPER_NODE_MAX_NUM        30

/**
  * @struct 
  * @brief  信号保持器
  */
typedef struct 
{
    struct 
    {
        bool        node_valid;             //< 节点有效信息
        bool_val_e  real_sig;               //< 当前真实信号
        bool_val_e  keep_sig;               //< 当前保持信号
        uint32_t    keep_sig_tick_stamp;    //< 当前保持信号tick时间戳
    } run;
    
    struct 
    {
        bool     hig_prio_sig;
        uint32_t keep_tm_tick_cnt;
    } attr;                                 //< 信号保持设置
} sig_keeper_node_t;

static sig_keeper_node_t s_sig_keeper_nodes[ SIG_KEEPER_NODE_MAX_NUM ];      //< 信号保持器静态内存
static sdk_os_mutex_id_t s_sig_keeper_nodes_mutex = NULL;                    //< 信号保持器静态内存 互斥锁

static void bool_sig_keeper_fresh( sig_keeper_hd sig_keeper );

/**
 * @brief  信号保持器初始化
 * @param  [in] 无
 * @return SF_OK：成功  非SF_OK：失败
 * @note   
 */
sf_ret_t bool_sig_keeper_init( void )
{
    sdk_os_mutex_attr_t attr = { .name = "sig_keeper" };

    s_sig_keeper_nodes_mutex = sdk_os_mutex_new( &attr );
    if ( s_sig_keeper_nodes_mutex == NULL )
    {
        sdk_log_e( "create sig keeper mutex error!!!" );
        return SF_ERR_NO_OBJECT;
    }
    memset( s_sig_keeper_nodes, 0, sizeof( s_sig_keeper_nodes ) );

    return SF_OK;
}

/**
 * @brief  创建信号保持器
 * @param  [in] p_sig_keeper_setting : 信号保持器设置【非必选，可谓NULL】，NULL则按默认 true持续时间5s作为设置
 * @return 信号保持器句柄，失败为NULL
 */
sig_keeper_hd bool_sig_keeper_create( sig_keeper_setting_t *p_sig_keeper_setting )
{
    sig_keeper_node_t *p_new_node = NULL;

    sdk_os_mutex_acquire( s_sig_keeper_nodes_mutex, SF_MUTEX_WAIT_FOREVER);
    for (size_t i = 0; i < ARRAY_SIZE( s_sig_keeper_nodes ); i++)
    {
        if ( s_sig_keeper_nodes[i].run.node_valid == false )
        {
            p_new_node = &s_sig_keeper_nodes[i];
            p_new_node->run.node_valid = SF_TRUE;
            p_new_node->run.real_sig = BOOL_VAL_INVALID;
            p_new_node->run.keep_sig = BOOL_VAL_INVALID;

            if ( p_sig_keeper_setting != NULL )
            {
                p_new_node->attr.hig_prio_sig     = p_sig_keeper_setting->hig_prio_sig;
                p_new_node->attr.keep_tm_tick_cnt = sdk_os_tick_from_millisecond( p_sig_keeper_setting->keep_tm_ms );
            }else{
                p_new_node->attr.hig_prio_sig     = SF_TRUE;
                p_new_node->attr.keep_tm_tick_cnt = sdk_os_tick_from_millisecond( 5*1000 );
            }
            break;
        }
    }
    sdk_os_mutex_release( s_sig_keeper_nodes_mutex );

    if ( p_new_node == NULL )
    {
        sdk_log_e( "create sig keeper error!!!" );
    }
    return (sig_keeper_hd)p_new_node;
}

/**
 * @brief  信号保持器
 * @param  [in] sig_keeper              : 信号保持器句柄
 * @param  [in] p_sig_keeper_setting    : 信号保持设置参数
 * @return SF_OK：成功  非SF_OK：失败
 */
sf_ret_t bool_sig_keep_setting( sig_keeper_hd sig_keeper, sig_keeper_setting_t *p_sig_keeper_setting )
{
    sig_keeper_node_t *p_node = (sig_keeper_node_t *)sig_keeper;

    if ( sig_keeper == NULL )
    {
        return SF_ERR_PARA;
    }
    p_node->attr.hig_prio_sig     = p_sig_keeper_setting->hig_prio_sig;
    p_node->attr.keep_tm_tick_cnt = sdk_os_tick_from_millisecond( p_sig_keeper_setting->keep_tm_ms );

    return SF_OK;
}

/**
 * @brief  信号保持器 输入信号
 * @param  [in] sig_keeper : 信号保持器句柄
 * @param  [in] sig_val    : 信号数值
 * @return 返回当前保持信号
 */
bool_val_e bool_sig_keeper_input( sig_keeper_hd sig_keeper, bool_val_e sig_val )
{
    if ( sig_keeper == NULL )
    {
        return BOOL_VAL_INVALID;
    }

    if ( sig_val != BOOL_VAL_INVALID )
    {
        ((sig_keeper_node_t *)sig_keeper)->run.real_sig = sig_val;
    }
    
    bool_sig_keeper_fresh( sig_keeper );

    return ((sig_keeper_node_t *)sig_keeper)->run.keep_sig;
}

/**
 * @brief  获取 保持器 信号
 * @param  [in] sig_keeper : 信号保持器句柄
 * @return 返回当前保持信号
 */
bool_val_e bool_sig_keeper_get( sig_keeper_hd sig_keeper )
{
    bool_sig_keeper_fresh( sig_keeper );
    
    return ((sig_keeper_node_t *)sig_keeper)->run.keep_sig;
}

/**
 * @brief  设置 保持器 信号 
 * @param  [in] sig_keeper : 信号保持器句柄
 * @param  [in] sig_val    : 信号数值
 * @return SF_OK：成功  非SF_OK：失败
 */
sf_ret_t bool_sig_keeper_set( sig_keeper_hd sig_keeper, bool_val_e sig_val  )
{
    sig_keeper_node_t *p_node = (sig_keeper_node_t *)sig_keeper;

    p_node->run.keep_sig            = sig_val;
    p_node->run.keep_sig_tick_stamp = sdk_tick_get();

    return SF_OK;
}

/**
 * @brief  信号保持器内部状态 刷新
 * @param  [in] sig_keeper : 信号保持器句柄
 */
static void bool_sig_keeper_fresh( sig_keeper_hd sig_keeper )
{
    sig_keeper_node_t *p_node = (sig_keeper_node_t *)sig_keeper;
    uint32_t now_tick = sdk_tick_get();

    if ( p_node->run.real_sig == BOOL_VAL_INVALID )
    {
        /* 真实信号为无效信号则不处理 */
        return;
    }

    if ( p_node->run.keep_sig == BOOL_VAL_INVALID )
    {
        /* 当前保持信号处于 无效值，直接切换 */
        p_node->run.keep_sig = p_node->run.real_sig;
    } 

    if ( p_node->run.real_sig != p_node->run.keep_sig )
    {
        /* 真实信号和保持信号不同，判断是否具备切换的条件 */
        if ( p_node->run.real_sig == p_node->attr.hig_prio_sig )
        {
            /* 高优先级信号，直接更新 */
            p_node->run.keep_sig            = p_node->run.real_sig;
            p_node->run.keep_sig_tick_stamp = now_tick;
        } else {
            if ( ( now_tick - p_node->run.keep_sig_tick_stamp ) >= p_node->attr.keep_tm_tick_cnt )
            {
                /* 低优先级信号，判断是否满足条件，满足则切换信号 */
                p_node->run.keep_sig            = p_node->run.real_sig;
                p_node->run.keep_sig_tick_stamp = now_tick;
            }
        }
    } else {
        /* 真实信号与保持信号相同，更新时间 */
        p_node->run.keep_sig_tick_stamp = now_tick;
    }
}
