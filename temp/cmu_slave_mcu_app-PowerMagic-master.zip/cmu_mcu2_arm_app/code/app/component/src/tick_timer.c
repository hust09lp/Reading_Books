#include "tick_timer.h"

#include "sdk.h"
#include "sdk_core.h"
#include "sofar_errors.h"

#define USER_TIMER_MAX_CNT          40          //<  最大支持创建 tick timer个数

/**
  * @struct tick_timer_t
  * @brief  记录tick timer 临时信息，也作为句柄的实际结构体
  */
typedef struct{
    bool     valid;                //< 有效
    uint32_t start_tick;           //< 开始时的tick点
    uint32_t timout_tick_cnt;      //< 超时的tick个数
} tick_timer_t;


static sdk_os_mutex_id_t s_tick_timer_mutex = NULL;
/* tick timer 列表，供上层分配使用 */
static tick_timer_t tick_timer_list[ USER_TIMER_MAX_CNT ] = { 
                                                            {.valid = SF_FALSE} 
                                                          };

/**
 * @brief  tick timer 组件初始化
 * @param  [in] 无
 * @return 0：成功  -1：失败 
 */
sf_ret_t tick_timer_init( void )
{
    sdk_os_mutex_attr_t mutex_attr = { .name = "tick_timer_mutex" };

    s_tick_timer_mutex = sdk_os_mutex_new( &mutex_attr );
    if ( NULL == s_tick_timer_mutex )
    {
        sdk_log_e( "%s create mutex error!!!", __FUNCTION__ );
        return -1;
    }

    return SF_OK;
}

/**
 * @brief  创建 tick timer
 * @param  [in] 无
 * @return 非NULL：tick timer句柄
 *         NULL：创建失败  
 */
tick_timer_handle_t tick_timer_create( void )
{
    tick_timer_handle_t new_tick_timer_hd = NULL;

    sdk_os_mutex_acquire( s_tick_timer_mutex, SF_MUTEX_WAIT_FOREVER );
    /* 寻找空闲的tick timer */
    for (size_t i = 0; i < USER_TIMER_MAX_CNT; i++)
    {
        if( tick_timer_list[i].valid == SF_FALSE )
        {
            tick_timer_list[i].valid = SF_TRUE;
            new_tick_timer_hd = &tick_timer_list[i];
            break;
        }
    }
    sdk_os_mutex_release( s_tick_timer_mutex );

    if( new_tick_timer_hd == NULL )
        sdk_log_e("%s error!!!", __FUNCTION__);

    return new_tick_timer_hd;
}

/**
 * @brief  删除 tick timer
 * @param  [in] usr_tm_hd : tick timer 句柄
 * @return SF_TRUE  : 成功
 *         SF_FALSE : 失败
 */
bool tick_timer_delete( tick_timer_handle_t usr_tm_hd )
{
    if( usr_tm_hd == NULL )
    {
        return SF_FALSE;
    }

    sdk_os_mutex_acquire( s_tick_timer_mutex, SF_MUTEX_WAIT_FOREVER );
    tick_timer_t *p_usr_timer = (tick_timer_t*)usr_tm_hd;

    p_usr_timer->timout_tick_cnt = 0;
    p_usr_timer->start_tick      = 0;
    p_usr_timer->valid           = SF_FALSE;
    sdk_os_mutex_release( s_tick_timer_mutex );
    
    // tick_timer_cnt--;
    // sdk_log_d( "delete tick_timer_cnt:%d", tick_timer_cnt );

    return SF_TRUE;
}

/**
 * @brief  刷新tick timer，并清除超时状态
 * @param  [in] usr_tm_hd : tick timer 句柄
 * @return SF_TRUE  : 成功
 *         SF_FALSE : 失败
 */
bool tick_timer_refresh( tick_timer_handle_t usr_tm_hd )
{
    tick_timer_t *p_usr_timer = (tick_timer_t*)usr_tm_hd;

    if( usr_tm_hd == NULL )
    {
        return SF_FALSE;
    }
    
    p_usr_timer->start_tick      = sdk_tick_get();
    return SF_TRUE; 
}

/**
 * @brief  重设tick timer超时时间，并清除超时状态
 * @param  [in] usr_tm_hd : tick timer 句柄
 * @return SF_TRUE  : 成功
 *         SF_FALSE : 失败
 */
bool tick_timer_set_timeout( tick_timer_handle_t usr_tm_hd, uint32_t timeout_ms )
{
    tick_timer_t *p_usr_timer = (tick_timer_t*)usr_tm_hd;

    p_usr_timer->start_tick      = sdk_tick_get();
    p_usr_timer->timout_tick_cnt = sdk_os_tick_from_millisecond( timeout_ms );

    return SF_TRUE; 
}

/**
 * @brief  判断tick timer是否已经超时
 * @param  [in] usr_tm_hd : tick timer 句柄
 * @return SF_TRUE  : 超时
 *         SF_FALSE : 未超时
 */
bool tick_timer_is_timeout( tick_timer_handle_t usr_tm_hd )
{
    tick_timer_t *p_usr_timer = (tick_timer_t*)usr_tm_hd;
    uint32_t now_tick        = sdk_tick_get();

    if ((now_tick - p_usr_timer->start_tick) >= p_usr_timer->timout_tick_cnt)
    {
        return SF_TRUE;
    }
    else
    {
        return SF_FALSE;
    }
}

/**
 * @brief  设置tick timer超时状态
 * @param  [in] usr_tm_hd   : tick timer 句柄
 * @param  [in] timeout_sta : 超时状态
 * @return SF_TRUE  : 成功
 *         SF_FALSE : 失败
 */
bool tick_timer_set_timeout_sta( tick_timer_handle_t usr_tm_hd, bool timeout_sta )
{
    tick_timer_t *p_usr_timer = (tick_timer_t*)usr_tm_hd;
    uint32_t now_tick         = sdk_tick_get();

    if ( usr_tm_hd == NULL )
    {
        return false;
    }

    if ( timeout_sta )
    {
        /* 将时间线拉到超时状态 */
        p_usr_timer->start_tick = now_tick - p_usr_timer->timout_tick_cnt - 1;
    } else {
        /* 将时间线拉到正常状态 */
        p_usr_timer->start_tick = sdk_tick_get();
    }

    return true;
}
