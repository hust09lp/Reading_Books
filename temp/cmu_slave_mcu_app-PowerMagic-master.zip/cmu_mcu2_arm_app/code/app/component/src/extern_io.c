#include "extern_io.h"
#include "tick_timer.h"
#include "app_modbus.h"

#include "sdk.h"
#include "sdk_core.h"
#include "sofar_errors.h"

#include <string.h>

#define PACKAGE_LOSE_CAL_PRINT          0               //< 丢包率计算打印   

#define SET_IO_RETRY_CNT                3               // 设置 IO电平 重设次数

#define EXT_IO_MOD_DI0_ADDR             0               // IO 拓展板 DI0 寄存器地址
#define EXT_IO_MOD_DO0_ADDR             16              // IO 拓展板 DO0 寄存器地址

#define EXTERN_IO_MOD_MAX_NUM           6               // IO 拓展板 最大个数

#define READ_FAIL_MAX_CNT               30              // 设备连续读取N次错误 则进入离线模式
#define READ_ONLINE_CYCLE_TM_MS         1000            // 在线设备读取时间间隔
#define READ_OFFLINE_CYCLE_TM_MS        30000           // 离线设备读取时间间隔

typedef struct {
    bool        enable;
    bool        online;
    uint8_t     rd_fail_cnt;

    uint32_t    total_fail_cnt;
    uint32_t    total_cnt;
    rate_t      com_loss_rate;

    uint8_t     slave_addr;
    io_sta_e    di_lv [ EXTERN_IO_PORT_NUM ];
    io_sta_e    do_lv[ EXTERN_IO_PORT_NUM ];

    bool        usr_do_set[ EXTERN_IO_PORT_NUM ];
    io_sta_e    usr_do_lv [ EXTERN_IO_PORT_NUM ];
} ext_io_mod_t;

typedef struct {
    uint32_t                          modbus_idx;
    ext_io_input_lv_change_callback   lv_change_cb;
    ext_io_mod_online_change_callback online_change_cb;
} ext_io_usr_t;

static sdk_os_mutex_id_t s_ext_io_mod_mutex = NULL;
static ext_io_mod_t s_ext_io_mod[ EXTERN_IO_MOD_MAX_NUM ] = { { false } };
static ext_io_usr_t s_ext_io_usr = { NULL };

static tick_timer_handle_t s_online_read_timer = NULL;
static tick_timer_handle_t s_offline_read_timer = NULL;

static void _extern_io_modbus_read_di_lv( bool rd_online );
static void _extern_io_modbus_usr_set_do_lv( void );

/**
 * @brief  IO 拓展板初始化
 * @param  [in] modbus_idx ：modbus index
 * @param  [in] baud_rate   ：通讯速率
 * @param  [in] modbus_init ：是否需要进行modbus初始化
 * @param  [in] lv_change_cb ：电平变化回调
 * @param  [in] online_change_cb  ：IO拓展板在线状态回调
 * @return 
 */
sf_ret_t extern_io_init( uint32_t modbus_idx, uint32_t baud_rate, bool modbus_init,
                        ext_io_input_lv_change_callback lv_change_cb,  
                        ext_io_mod_online_change_callback online_change_cb )
{
    s_online_read_timer  = tick_timer_create();
    s_offline_read_timer = tick_timer_create();

    if( (s_online_read_timer == NULL) || ( s_offline_read_timer == NULL ) )
    {
        return SF_ERR_PARA;
    }

    if( modbus_init == true )
    {
        app_modbus_rtu_init( modbus_idx, 1, baud_rate);
	    app_modbus_connect ( modbus_idx );
        app_modbus_response_timeout_set(modbus_idx, 200);
    }

    s_ext_io_usr.modbus_idx = modbus_idx;

    tick_timer_set_timeout( s_online_read_timer,  READ_ONLINE_CYCLE_TM_MS );
    tick_timer_set_timeout( s_offline_read_timer, READ_OFFLINE_CYCLE_TM_MS );

    memset( &s_ext_io_mod, 0, sizeof( s_ext_io_mod ));
    for (size_t mod_idx = 0; mod_idx < EXTERN_IO_MOD_MAX_NUM; mod_idx++)
    {
        ext_io_mod_t *p_ext_io_mod = &s_ext_io_mod[mod_idx];
        memset( p_ext_io_mod->di_lv, IO_STA_NONE, sizeof( p_ext_io_mod->di_lv ) );
        memset( p_ext_io_mod->do_lv, IO_STA_NONE, sizeof( p_ext_io_mod->do_lv ) );
        memset( p_ext_io_mod->usr_do_lv, IO_STA_NONE, sizeof( p_ext_io_mod->usr_do_lv ) );
        p_ext_io_mod->online = true;
    }

    s_ext_io_usr.online_change_cb = online_change_cb;
    s_ext_io_usr.lv_change_cb     = lv_change_cb;
    
    sdk_os_mutex_attr_t mutex_attr = { .name = "ext_io_mutex" };

    s_ext_io_mod_mutex = sdk_os_mutex_new( &mutex_attr );
    if ( NULL == s_ext_io_mod_mutex )
    {
        sdk_log_e( "%s create mutex error!!!", __FUNCTION__ );
        return SF_ERR_NO_OBJECT;
    }
    return SF_OK;
}

/**
 * @brief  设置 IO 拓展模块 端口电平【同步】
 * @param  [in] mod_index : io拓展板模块 索引/位置 （ 0 ~ (EXTERN_IO_PORT_NUM - 1) ）
 * @param  [in] io_port   : DO 端口 【0开始】
 * @param  [in] lv        : 电平状态
 * @return SF_OK：成功  小于SF_OK: 失败
 */
sf_ret_t extern_io_set_mod_enable( uint8_t mod_index, bool enable, uint8_t mb_slave_addr )
{
    if( mod_index >= EXTERN_IO_MOD_MAX_NUM )
    {
        return SF_ERR_PARA;
    }

    sdk_os_mutex_acquire( s_ext_io_mod_mutex, SF_MUTEX_WAIT_FOREVER );
    memset( &s_ext_io_mod[ mod_index ], 0 ,sizeof(ext_io_mod_t) );
    s_ext_io_mod[ mod_index ].online = true;
    if( enable == true )
    {
        s_ext_io_mod[ mod_index ].enable     = enable;
        s_ext_io_mod[ mod_index ].slave_addr = mb_slave_addr;
    }
    sdk_os_mutex_release( s_ext_io_mod_mutex );

    return SF_OK;
}

/**
 * @brief  设置 IO 拓展模块 端口电平【同步】
 * @param  [in] mod_index : io拓展板模块 索引/位置 （ 0 ~ (EXTERN_IO_PORT_NUM - 1) ）
 * @param  [in] io_port   : DO 端口 【0开始】
 * @param  [in] lv        : 电平状态
 * @return SF_OK：成功  小于SF_OK: 失败
 */
sf_ret_t  extern_io_set_output_lv_sync( uint8_t mod_index, uint8_t io_port, bool lv )
{
    if( (mod_index >= EXTERN_IO_MOD_MAX_NUM )
        || (io_port >= EXTERN_IO_PORT_NUM))
    {
        return SF_ERR_PARA;
    }

    if( s_ext_io_mod[ mod_index ].enable == false )
    {
        return SF_ERR_NO_READY;
    }

    ext_io_mod_t *p_ext_io_mod = &s_ext_io_mod[mod_index];
    int32_t ret = 0;

    for (size_t i = 0; i < SET_IO_RETRY_CNT; i++)
    {
        ret = app_modbus_coil_write( s_ext_io_usr.modbus_idx, p_ext_io_mod->slave_addr,
                                     EXT_IO_MOD_DO0_ADDR + io_port, lv, 80 );
        if( ret >= 0 )
        {
            break;
        }
    }

    if ( 0 > ret )
    {
        sdk_log_e("%s fail, ret:%d ", __FUNCTION__, ret);
        return SF_ERR_WR;
    }
    else
    {
        sdk_log_d("%s success, ret:%d ", __FUNCTION__, ret);
        return SF_OK;
    }
}

/**
 * @brief  设置 IO 拓展模块 端口电平【同步】
 * @param  [in] mod_index : io拓展板模块 索引/位置 （ 0 ~ (EXTERN_IO_PORT_NUM - 1) ）
 * @param  [in] io_port   : DO 端口 【0开始】
 * @param  [in] lv        : 电平状态
 * @return SF_OK：成功  小于SF_OK: 失败
 */
sf_ret_t extern_io_set_output_lv( uint8_t mod_index, uint8_t io_port, bool lv )
{
    if ((mod_index >= EXTERN_IO_MOD_MAX_NUM) || (io_port >= EXTERN_IO_PORT_NUM))
    {
        return SF_ERR_PARA;
    }

    if (s_ext_io_mod[mod_index].enable == false)
    {
        return SF_ERR_NO_OBJECT;
    }

    sdk_os_mutex_acquire( s_ext_io_mod_mutex, SF_MUTEX_WAIT_FOREVER );
    s_ext_io_mod[ mod_index ].usr_do_set[ io_port ] = true;
    s_ext_io_mod[ mod_index ].usr_do_lv [ io_port ] = lv? IO_STA_HIG: IO_STA_LOW;
    sdk_os_mutex_release( s_ext_io_mod_mutex );
    
    return SF_OK;
}

/**
 * @brief  获取 IO拓展模块 在线状态
 * @param  [in] mod_index : io拓展板模块 索引/位置 （ 0 ~ (EXTERN_IO_PORT_NUM - 1) ）
 * @return 详见返回值 枚举说明
 */
ol_sta_e extern_io_get_online_sta( uint8_t mod_index )
{
    if( mod_index >= EXTERN_IO_MOD_MAX_NUM )
    {
        return OL_STA_NO_EXSIT;
    }

    if( s_ext_io_mod[ mod_index ].enable == false )
    {
        return OL_STA_NO_EXSIT;
    }

    return (s_ext_io_mod[ mod_index ].online)? OL_STA_ONLINE: OL_STA_OFFLINE;
}

/**
 * @brief  获取 IO拓展模块 DI电平【同步获取，modbus获取】
 * @param  [in] mod_index : io拓展板模块 索引/位置 （ 0 ~ (EXTERN_IO_PORT_NUM - 1) ）
 * @param  [in] io_port   : DI端口
 * @return 详见返回值 枚举说明
 */
io_sta_e extern_io_get_input_lv_sync( uint8_t mod_index, uint8_t io_port )
{
    uint8_t di_lv = 0;
    int32_t ret = -1;

    if( (mod_index >= EXTERN_IO_MOD_MAX_NUM )
        || (io_port >= EXTERN_IO_PORT_NUM))
    {
        return IO_STA_NONE;
    }

    if( s_ext_io_mod[ mod_index ].enable == false )
    {
        return IO_STA_NONE;
    }

    for (size_t i = 0; i < 3; i++)
    {
        ret = app_modbus_coils_read( s_ext_io_usr.modbus_idx, s_ext_io_mod[ mod_index ].slave_addr, 
                                     EXT_IO_MOD_DI0_ADDR + io_port, 1, &di_lv, 80 );
        if ( ret >= 0  )
        {
            if ( di_lv )
                return IO_STA_HIG;
            else
                return IO_STA_LOW;
        }
    }
    
    return IO_STA_NONE;
}

/**
 * @brief  获取 IO拓展模块 DI电平 【缓存获取】
 * @param  [in] mod_index : io拓展板模块 索引/位置 （ 0 ~ (EXTERN_IO_PORT_NUM - 1) ）
 * @param  [in] io_port   : DI端口
 * @return 详见返回值 枚举说明
 */
io_sta_e extern_io_get_input_lv( uint8_t mod_index, uint8_t io_port )
{
    if( (mod_index >= EXTERN_IO_MOD_MAX_NUM )
        || (io_port >= EXTERN_IO_PORT_NUM))
    {
        return IO_STA_NONE;
    }

    if( s_ext_io_mod[ mod_index ].enable == false )
    {
        return IO_STA_NONE;
    }

    return s_ext_io_mod[ mod_index ].di_lv[io_port];
}

/**
 * @brief  获取 IO 拓展板丢包率
 * @param  [in] mod_index : io拓展板模块 索引/位置 （ 0 ~ (EXTERN_IO_PORT_NUM - 1) ）
 * @return 返回丢包率
 */
rate_t extern_io_get_com_loss_rate( uint8_t mod_index )
{
    if( (mod_index >= EXTERN_IO_MOD_MAX_NUM ))
    {
        return 0;
    }
    return s_ext_io_mod[ mod_index ].com_loss_rate;
}

/**
 * @brief  IO 拓展板 任务调度
 * @param  [in] void
 */
void extern_io_task_loop( void )
{
    static bool first_power_on = true;

    if( tick_timer_is_timeout( s_online_read_timer ) )
    {
        _extern_io_modbus_read_di_lv( true );
        tick_timer_refresh( s_online_read_timer );
    }

    if( tick_timer_is_timeout( s_offline_read_timer ) || ( first_power_on == true ) )
    {
        // sdk_log_d("read offline dev");
        _extern_io_modbus_read_di_lv( false );
        tick_timer_refresh( s_offline_read_timer );
        first_power_on = false;
    }

    _extern_io_modbus_usr_set_do_lv();
}

/**
 * @brief  同步 单个IO拓展 DO输出
 * @param  [in] mod_idx ：IO拓展板 索引/位置
 * @return 无
 * @note   
 */
static void _extern_io_modbus_usr_set_single_mod_do_lv( uint8_t mod_idx )
{
    ext_io_mod_t *p_ext_io_mod = &s_ext_io_mod[mod_idx];

    for (size_t io_port = 0; io_port < EXTERN_IO_PORT_NUM; io_port++)
    {
        if( p_ext_io_mod->usr_do_set[ io_port ] )
        {
            int32_t ret = app_modbus_coil_write( s_ext_io_usr.modbus_idx, p_ext_io_mod->slave_addr, \
                                                    EXT_IO_MOD_DO0_ADDR + io_port, \
                                                    p_ext_io_mod->usr_do_lv[ io_port ], 80 );
            if( ret < 0 )
            {
                sdk_log_e("set ext[%d]-io[%d] fail!!!", mod_idx, io_port);
            }
            else
            {
                sdk_log_d("set ext[%d]-io[%d] sucess!!!", mod_idx, io_port);
            }

            p_ext_io_mod->usr_do_set[ io_port ] = false;
        }
    }
}

/**
 * @brief  同步 所有IO拓展板 DO输出
 * @param  [in] 无
 * @return 无
 * @note   
 */
static void _extern_io_modbus_usr_set_do_lv( void )
{
    sdk_os_mutex_acquire( s_ext_io_mod_mutex, SF_MUTEX_WAIT_FOREVER );
    for (size_t mod_idx = 0; mod_idx < EXTERN_IO_MOD_MAX_NUM ; mod_idx++)
    {
        ext_io_mod_t *p_ext_io_mod = &s_ext_io_mod[mod_idx];

        if( (p_ext_io_mod->enable == true ) && (p_ext_io_mod->online == true) )
        {
            _extern_io_modbus_usr_set_single_mod_do_lv( mod_idx );
        }
    }
    sdk_os_mutex_release( s_ext_io_mod_mutex );
}

/**
 * @brief  读取 单个IO拓展 DI输入
 * @param  [in] mod_idx ：IO拓展板 索引/位置
 * @return 无
 * @note   
 */
static void _extern_io_modbus_read_single_mod_di_lv( uint8_t mod_idx )
{
    ext_io_mod_t *p_ext_io_mod = &s_ext_io_mod[mod_idx];
    io_sta_e di_lv[ EXTERN_IO_PORT_NUM ] = {};

    if( 0 > app_modbus_coils_read( s_ext_io_usr.modbus_idx, p_ext_io_mod->slave_addr, 
                                   EXT_IO_MOD_DI0_ADDR, EXTERN_IO_PORT_NUM, di_lv, 80 ))
    {
        // sdk_log_w( "ext[%d] io read coil fail", mod_idx );
        /* 读取失败 */
        p_ext_io_mod->total_fail_cnt++;
        p_ext_io_mod->rd_fail_cnt++;
        if( p_ext_io_mod->rd_fail_cnt >= READ_FAIL_MAX_CNT )
        {
            /* 超过失败次数，通知离线 */
            if( p_ext_io_mod->online == true )
            {
                p_ext_io_mod->online = false;
                if( s_ext_io_usr.online_change_cb )
                {
                    s_ext_io_usr.online_change_cb(mod_idx, false);
                }
            }
        }
    }else{
        /* 读取成功 */
        p_ext_io_mod->rd_fail_cnt = 0;
        
        if( p_ext_io_mod->online == false )
        {
            /* 通知设备上线 */
            p_ext_io_mod->online = true;
            if( s_ext_io_usr.online_change_cb )
            {
                s_ext_io_usr.online_change_cb(mod_idx, true);
            }
        }

        /* 查看 DI是否发生变化 */
        for (size_t io_port = 0; io_port < EXTERN_IO_PORT_NUM; io_port++)
        {
            if( di_lv[io_port] != p_ext_io_mod->di_lv[io_port] )
            {
                p_ext_io_mod->di_lv[io_port] = di_lv[io_port];
                if( s_ext_io_usr.lv_change_cb )
                {
                    s_ext_io_usr.lv_change_cb(mod_idx, io_port, (bool)di_lv[io_port]);
                }
            }
        }
    }
    p_ext_io_mod->total_cnt++;
    p_ext_io_mod->com_loss_rate = (rate_t)((float)p_ext_io_mod->total_fail_cnt / (float)p_ext_io_mod->total_cnt * 10000.0f);
}

/**
 * @brief  读取 所有 IO拓展板 DI输入
 * @param  [in] mod_idx ：IO拓展板 索引/位置
 * @return 无
 * @note   
 */
static void _extern_io_modbus_read_di_lv( bool rd_online )
{
    sdk_os_mutex_acquire( s_ext_io_mod_mutex, SF_MUTEX_WAIT_FOREVER );
    for (size_t mod_idx = 0; mod_idx < EXTERN_IO_MOD_MAX_NUM ; mod_idx++)
    {
        ext_io_mod_t *p_ext_io_mod = &s_ext_io_mod[mod_idx];

        if( (p_ext_io_mod->enable == true) && (p_ext_io_mod->online == rd_online) )
        {
            _extern_io_modbus_read_single_mod_di_lv( mod_idx );
        }
    }
    sdk_os_mutex_release( s_ext_io_mod_mutex );
    
    return ;
}
