#include "bool_filter.h"

#include "sdk.h"
#include "sdk_core.h"
#include "sofar_errors.h"

#include <string.h>

/* 滤波器最大个数 */
#define MAX_BOOL_FILTER_CNT         50

typedef struct {
    uint16_t        cnt;                //< 有效 次数 
    uint32_t        tick_cnt;           //< 有效 tick cnt
} valid_setting_t;

/* bool 滤波器信息 */
typedef struct 
{
    bool            enable;                     //< 使能
    struct {
        filter_type_e   type;                   //< 滤波器类型
        valid_setting_t true_valid;             //< true 有效设置 
        valid_setting_t false_valid;            //< false 有效设置
    } attr;                                     //< 属性
    struct {
        bool_val_e      value;                  //< 当前数值
        bool_val_e      new_val;                //< 新输入数值
        uint16_t        new_val_cnt;            //< 新输入数值 次数
        uint32_t        new_val_tick;           //< 新输入数值 tick 时间戳
    } run;                                      //< 运行数据
} bool_filter_info_t;

static bool_filter_info_t s_bool_filter_infos[ MAX_BOOL_FILTER_CNT ] = { {0} };

static void _bool_filter_val_refresh( bool_filter_info_t *p_bool_filter_info );

/**
 * @brief  bool 滤波器 初始化
 * @param  [in] 无
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
sf_ret_t bool_filter_init( void )
{
    memset( s_bool_filter_infos, 0, sizeof( s_bool_filter_infos ) );

    for (size_t i = 0; i < MAX_BOOL_FILTER_CNT; i++)
    {
        s_bool_filter_infos[ i ].run.value = BOOL_VAL_INVALID;
    }

    return SF_OK;
}

/**
 * @brief  创建 bool 滤波器
 * @param  [in] type        : bool 滤波器 类型
 * @param  [in] valid_tm_ms : 数值 有效时间 
 * @param  [in] valid_cnt   : 数值 有效次数 
 * @return bool 滤波器句柄
 * @retval NULL：失败  非NULL: 成功
 * @note   
 */
bool_filter_hd bool_filter_create( filter_type_e type, filter_setting_t *p_true_setting, filter_setting_t *p_false_setting  )
{
    bool_filter_hd new_filter_hd = NULL;
    uint8_t i;

    /* 判断参数合法性 */
    if (    ( type >= FILTER_TYPE_MAX )
        || (( type == FILTER_TYPE_CNT ) && ( (p_true_setting->cnt == FILTER_CNT_INVALID) || (p_false_setting->cnt == FILTER_CNT_INVALID)))
        || (( type == FILTER_TYPE_TM  ) && ( (p_true_setting->tm_ms == FILTER_TM_MS_INVALID) || (p_false_setting->tm_ms == FILTER_TM_MS_INVALID)))
        || (( type == FILTER_TYPE_TM_AND_CNT ) && 
                ((p_true_setting->cnt == FILTER_CNT_INVALID) || ( p_true_setting->tm_ms == FILTER_TM_MS_INVALID) 
                || (p_false_setting->cnt == FILTER_CNT_INVALID) || ( p_false_setting->tm_ms == FILTER_TM_MS_INVALID) )))
    {
        sdk_log_e("%s param error!!!", __FUNCTION__);
        return NULL;
    }

    /* 寻找没用到的节点 */
    for ( i = 0; i < MAX_BOOL_FILTER_CNT; i++)
    {
        if ( s_bool_filter_infos[i].enable == SF_FALSE ) 
        {
            s_bool_filter_infos[i].enable                   = SF_TRUE;
            s_bool_filter_infos[i].attr.type                = type;
            
            s_bool_filter_infos[i].attr.true_valid.cnt      = p_true_setting->cnt;
            s_bool_filter_infos[i].attr.true_valid.tick_cnt = sdk_os_tick_from_millisecond( p_true_setting->tm_ms );

            s_bool_filter_infos[i].attr.false_valid.cnt      = p_false_setting->cnt;
            s_bool_filter_infos[i].attr.false_valid.tick_cnt = sdk_os_tick_from_millisecond( p_false_setting->tm_ms );

            new_filter_hd = &s_bool_filter_infos[i];
            break;
        }
    }

    if( new_filter_hd == NULL )
    {
        sdk_log_e( "new_filter_hd == NULL" );
    }

    return new_filter_hd;
}

/**
 * @brief  bool 滤波器 输入数据
 * @param  [in] hd     : bool 滤波器 句柄
 * @param  [in] value  : 输入数值 
 * @return  0：成功   -1：失败
 * @note   
 */
bool_val_e bool_filter_input( bool_filter_hd hd, bool_val_e value )
{
    bool_filter_info_t *p_bool_filter_info = (bool_filter_info_t *)hd;

    if ( hd == NULL )
    {
        sdk_log_e("%s hd == NULL", __FUNCTION__);
        return BOOL_VAL_INVALID;
    }

    if ( p_bool_filter_info->enable != SF_TRUE )
    {
        sdk_log_e("%s hd is disable", __FUNCTION__);
        return BOOL_VAL_INVALID;
    }

    if ( value > BOOL_VAL_TRUE )
    {
        sdk_log_e("%s val error", __FUNCTION__);
        return BOOL_VAL_INVALID;
    }

    if ( p_bool_filter_info->run.new_val != value )
    {
        /* 记录数据翻转时候状态 */
        p_bool_filter_info->run.new_val      = value;
        p_bool_filter_info->run.new_val_cnt  = 1;
        p_bool_filter_info->run.new_val_tick = sdk_tick_get();
    } else {
        p_bool_filter_info->run.new_val_cnt++;
    }

    _bool_filter_val_refresh( p_bool_filter_info );

    return p_bool_filter_info->run.value;
}

static void _bool_filter_val_refresh( bool_filter_info_t *p_bool_filter_info )
{
    /* 查看是否满足更新条件 */
    valid_setting_t *p_valid_setting;

    if ( ( p_bool_filter_info->run.new_val == BOOL_VAL_INVALID )
      || ( p_bool_filter_info->run.new_val == p_bool_filter_info->run.value ))
        return;

    if( p_bool_filter_info->run.new_val )
        p_valid_setting = &p_bool_filter_info->attr.true_valid;
    else 
        p_valid_setting = &p_bool_filter_info->attr.false_valid;

    if ( p_bool_filter_info->attr.type == FILTER_TYPE_CNT )
    {
        /* 次数滤波 判断 */
        if ( p_bool_filter_info->run.new_val_cnt >= p_valid_setting->cnt ) 
        {
            p_bool_filter_info->run.value = p_bool_filter_info->run.new_val;
        }

    } else if ( p_bool_filter_info->attr.type == FILTER_TYPE_TM )
    {
        /* 时间滤波 判断 */
        uint32_t now_tick = sdk_tick_get();

        if ( (now_tick - p_bool_filter_info->run.new_val_tick) >= p_valid_setting->tick_cnt )
        {
            p_bool_filter_info->run.value = p_bool_filter_info->run.new_val;
        }

    } else if ( p_bool_filter_info->attr.type == FILTER_TYPE_TM_AND_CNT )
    {
        uint32_t now_tick = sdk_tick_get();

        /* 时间和次数滤波 通知判断 */
        if ( ((now_tick - p_bool_filter_info->run.new_val_tick) >= p_valid_setting->tick_cnt )
            &&( p_bool_filter_info->run.new_val_cnt >= p_valid_setting->cnt ))
        {
            p_bool_filter_info->run.value = p_bool_filter_info->run.new_val;
        }
    }
}

/**
 * @brief  获取 bool 滤波器滤波之后的数值
 * @param  [in] hd  : bool 滤波器 句柄，不可为 NULL
 * @return  滤波之后的数值 （false/true）
 */
bool_val_e bool_filter_get_val( bool_filter_hd hd )
{
    bool_filter_info_t *p_bool_filter_info = (bool_filter_info_t *)hd;

    if ( hd == NULL )
    {
        sdk_log_e("%s hd == NULL", __FUNCTION__);
        return BOOL_VAL_INVALID;
    }

    if ( p_bool_filter_info->enable != SF_TRUE )
    {
        sdk_log_e("%s hd is disable", __FUNCTION__);
        return BOOL_VAL_INVALID;
    }

    _bool_filter_val_refresh( p_bool_filter_info );

    return p_bool_filter_info->run.value;
}

/**
 * @brief  设置 bool 滤波器 数值 【一般为初始化或是外部干涉使用】
 * @param  [in] hd  : bool 滤波器 句柄
 * @param  [in] val : 设置数值
 * @return  0：成功   -1：失败
 */
sf_ret_t bool_filter_set_val( bool_filter_hd hd, bool_val_e val )
{
    bool_filter_info_t *p_bool_filter_info = (bool_filter_info_t *)hd;

    if ( hd == NULL )
    {
        sdk_log_e("%s hd == NULL", __FUNCTION__);
        return -1;
    }

    if ( p_bool_filter_info->enable != SF_TRUE )
    {
        sdk_log_e("%s hd is disable", __FUNCTION__);
        return -2;
    }

    p_bool_filter_info->run.value        = val;

    p_bool_filter_info->run.new_val      = val;
    p_bool_filter_info->run.new_val_cnt  = 0;
    p_bool_filter_info->run.new_val_tick = sdk_tick_get();

    return SF_OK;
}




