/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     shell.c
  * @brief
  * @company  SOFARSOLAR
  * @author   GZQ
  * @note
  * @version  V01
  * @date     2023/12/06
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "sci.h"
#include "bat_tmp_ctrl_api.h"

#include "shell.h"
#include "sdk.h"
#include "sdk_core.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
struct finsh_syscall *_syscall_table_begin  = NULL;
struct finsh_syscall *_syscall_table_end    = NULL;
uint8_t shell_buffer[128];

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/
void *msh_get_cmd(char *cmd, int size);

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/
/******************************************************************************
 * function_addr_init().
 * Shell instruction address initialization. [Called by.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void function_addr_init(const void *begin, const void *end)
{
	_syscall_table_begin = (struct finsh_syscall *) begin;
	_syscall_table_end = (struct finsh_syscall *) end;
}

/******************************************************************************
 * shell_init().
 * Shell module init. [Called by.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void shell_init(void)
{
	memset(shell_buffer, 0, sizeof(shell_buffer));
	extern const int FSymTab$$Base;
	extern const int FSymTab$$Limit;
	function_addr_init(&FSymTab$$Base, &FSymTab$$Limit);
	sdk_shell_regist(&msh_get_cmd);
}

/******************************************************************************
 * msh_get_cmd().
 * Shell command registration. [Called by.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void* msh_get_cmd(char *cmd, int size)
{
	struct finsh_syscall *index;
	cmd_function_t cmd_func = NULL;

	for (index = _syscall_table_begin;
			index < _syscall_table_end;
			index++)
	{
		if (strncmp(index->name, cmd, size) == 0 &&
				index->name[size] == '\0')
		{
			cmd_func = (cmd_function_t)index->func;
			break;
		}
	}

	return cmd_func;
}

/******************************************************************************
 * app_help().
 * output command help info. [Called by.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
int app_help(int argc, char **argv)
{
	sdk_log_printf("app shell commands:\n");
	{
		struct finsh_syscall *index;

		for (index = _syscall_table_begin;
				index < _syscall_table_end;
				index++)
		{
			sdk_log_printf("%-16s - %s\n", index->name, index->desc);
		}
	}
	sdk_log_printf("\n");

	return 0;
}
MSH_CMD_EXPORT(app_help, "app shell commands");

/******************************************************************************
 * vir().
 * 热管理虚拟调试命令
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
int vir(int argc, char **argv)
{
    if (SF_OK != bat_temper_ctrl_vir_debug( (argc >= 2)? argv[1] : NULL ,
                                            (argc >= 3)? argv[2] : NULL ))
    {
        sdk_log_printf( "eg: vir en 1\r\n" );
        sdk_log_printf( "    vir Tmax 38\r\n" );
        sdk_log_printf( "    vir Tmean 25.2\r\n" );
        sdk_log_printf( "    vir Tmin 10\r\n" );
        sdk_log_printf( "    vir Tenv 25.5\r\n" );
        sdk_log_printf( "    vir curr 1.5\r\n" );
        sdk_log_printf( "    vir start\r\n" );
        sdk_log_printf( "    vir stop\r\n" );
        sdk_log_printf( "    vir reset\r\n" );
        sdk_log_printf( "    vir list\r\n" );
    }
    return 0;
}
MSH_CMD_EXPORT( vir, "bat virtual temperature debug ");


/******************************************************************************
 * 打印系统当前状态
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
int sta(int argc, char **argv)
{
    system_sta_printf();
    return 0;
}
MSH_CMD_EXPORT( sta, "bat virtual temperature debug ");
