#include "main.h"
#include "app_test.h"
#include "shell.h"
#include "peripheral_task.h"
#include "sci.h"
#include "crc32.h"
#include "proj_cfg.h"
#include "tick_timer.h"
#include "bool_filter.h"
#include "sig_keeper.h"

#include "sdk.h"
#include "sdk_core.h"

#define VERSION_LENGTH_MAX          12

#define HEART_LED                   0

int8_t sdk_ver[VERSION_LENGTH_MAX] = {0};
int8_t hw_ver[VERSION_LENGTH_MAX] = {0};

/**
 * @brief     检查升级标志位
 * @param 	  无
 * @return    无
 */
void upgrade_flag_check(void)
{
	int32_t flag = 0;
	
	flag = sdk_upgrade_status_get(UT_APP);
	if(flag == FIRMWARE_UPGRADE_SUCCESS)
	{
		sdk_start_upgrade((uint8_t*)APP_FILE_NAME, 0);
	}
	
	flag = sdk_upgrade_status_get(UT_CORE);
	if(flag == FIRMWARE_UPGRADE_SUCCESS)
	{
		sdk_start_upgrade((uint8_t*)CORE_FILE_NAME, 0);
	}

}


/**
 * @brief     运行呼吸灯
 * @param 	  无
 * @return    无
 */
void led_flash(void)
{   
    static uint8_t led = 0;
    
    led = !led;    
    if (led)
    {
        sdk_led_on(0);
    }
    else
    {
        sdk_led_off(0);
    }        
}

int main(void)
{
    int32_t ret;
    
    ret = core_sdk_api_init(CORE_SDK_API_FLASH_ADDR);
    if (ret != SF_OK)
    {
        return -1;  // 获取SDK的API接口失败
    }
    sdk_log_i("main -----");

    ret = sdk_version_get(SDK_VERSION_TYPE, sdk_ver, VERSION_LENGTH_MAX);
	ret = sdk_version_get(HW_VERSION_TYPE, hw_ver, VERSION_LENGTH_MAX);
	
    sdk_log_i("sdk_ver:%s, SDK_VERSION_INFO:%s\r\n", sdk_ver, SDK_VERSION_INFO);
    if (strcmp((char *)sdk_ver, SDK_VERSION_INFO) != 0)
    {
        sdk_start_upgrade( (uint8_t*)APP_FILE_NAME , 2 );
        sdk_start_upgrade( (uint8_t*)CORE_FILE_NAME, 2 );
        sdk_log_a("SDK version unmatched, forbidden to run App code\r\n");
        return -2;  // SDK版本不一致，禁止启动App程序
    }
	
	sdk_wdt_enable( WATCHDOG_ENABLE );
    
    upgrade_flag_check();     	// 升级标记位检查
    sdk_log_i("***********************************\r\n");
    sdk_log_i("APP Project Start Running....\r\n");
    sdk_log_i("SDK Version:%s....\r\n", sdk_ver);
    sdk_log_i("APP_START_FLASH_ADDR:%08X, app Version:%s....\r\n", APP_START_FLASH_ADDR, SoftwareVersion);
    sdk_log_i("***********************************\r\n");

    // app_test_init();
    
    shell_init();
    boot_check_file_system();
    bool_filter_init();
    bool_sig_keeper_init();
    tick_timer_init();
	inboard_sci_init();
    app_backgroud_dev_init();
    app_work_init();
    app_thread_creat();

    while(1)
    {
        led_flash();
        sdk_os_delay(sdk_os_tick_from_millisecond(1000));
    }
}
