#ifndef __MAIN_H__
#define __MAIN_H__

#include "stdint.h"
#include "string.h"


#ifdef SOC_LPC54605
#define FLASH_SECTOR_SIZE                       (0x8000)  // 32KB

#define BOOT_START_FLASH_ADDR                   (0x00000000)
#endif

#ifdef SOC_LPC54606
#define FLASH_SECTOR_SIZE                       (0x8000)  // 32KB

#define BOOT_START_FLASH_ADDR                   (0x00000000)
#endif

#ifdef SOC_IMXRT1024
#define FLASH_SECTOR_SIZE                       (0x1000)  // 4KB

#define BOOT_START_FLASH_ADDR                   (0x60000000)
#endif

#define BOOT_PROGRAM_FLASH_SIZE                 (0x10000)    // 64KB
#define FACTORY_PARA_START_FLASH_ADDR           (BOOT_START_FLASH_ADDR + BOOT_PROGRAM_FLASH_SIZE)
#define FACTORY_PARA_FLASH_SIZE                 (0x10000)    // 64KB
#define CORE_START_FLASH_ADDR                   0x60020000UL//(FACTORY_PARA_START_FLASH_ADDR + FACTORY_PARA_FLASH_SIZE)
#define CORE_PROGRAM_FLASH_SIZE                 (0x100000)    // 1MB
#define APP_START_FLASH_ADDR                    (CORE_START_FLASH_ADDR + CORE_PROGRAM_FLASH_SIZE)
// Core程序提供的SDK接口API存放的地址
#define CORE_SDK_API_FLASH_ADDR                 (CORE_START_FLASH_ADDR + 0x8000)

#define VERSION_LENGTH_MAX          12


extern int8_t sdk_ver[VERSION_LENGTH_MAX];
extern int8_t hw_ver[VERSION_LENGTH_MAX];

#endif

