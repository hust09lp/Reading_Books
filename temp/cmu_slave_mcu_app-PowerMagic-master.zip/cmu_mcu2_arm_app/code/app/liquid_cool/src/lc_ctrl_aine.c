#include "lc_ctrl_aine.h"
#include "lc_type_aine.h"
#include "app_modbus.h"

#include "num_trans.h"
#include "sdk.h"
#include "sdk_core.h"

#define SOFAR_WORK_MODE_TO_AINE_WORK_MODE(sofar_wk_mode, aine_wk_mode)                                   \
    do                                                                                                   \
    {                                                                                                    \
        map_num_t tmp_aine_wk_mode;                                                                      \
        if (true == mapping_raw_num_to_map_num((raw_num_t)sofar_wk_mode, (map_num_t *)&tmp_aine_wk_mode, \
                                               work_mode_mapping, ARRAY_CNT(work_mode_mapping)))         \
        {                                                                                                \
            aine_wk_mode = (uint16_t)tmp_aine_wk_mode;                                                   \
        }                                                                                                \
    } while (0)

#define AINE_WORK_MODE_TO_SOFAR_WORK_MODE(aine_wk_mode, sofar_wk_mode)                                   \
    do                                                                                                   \
    {                                                                                                    \
        raw_num_t tmp_sofar_wk_mode;                                                                     \
        if (true == mapping_map_num_to_raw_num((map_num_t)aine_wk_mode, (raw_num_t *)&tmp_sofar_wk_mode, \
                                               work_mode_mapping, ARRAY_CNT(work_mode_mapping)))         \
        {                                                                                                \
            sofar_wk_mode = (lc_work_mode_e)tmp_sofar_wk_mode;                                           \
        }                                                                                                \
        else                                                                                             \
        {                                                                                                \
            sofar_wk_mode = LC_WORK_MODE_INVALID;                                                        \
        }                                                                                                \
    } while (0)

#define MODBUS_SLAVE_ADDR                       1
#define MODBUS_BUADRATE                         9600
#define MODBUS_MSG_TIMEOUT_MS                   200         //< MODBUS 消息超时时间

#define MB_REG_ADDR_SET_POWER_ON                1         //< 开关机   0：关机；1：开机
#define MB_REG_ADDR_SET_COOL_TMP_RET            2         //< 制冷温度回差                单位：0.1℃ [max:1.5  min:0.1  def:18.0]
#define MB_REG_ADDR_SET_HEAT_TMP                3         //< 制热温度设定                单位：0.1℃ [max:45.0  min:5.0  def:18.0]
#define MB_REG_ADDR_SET_HEAT_TMP_RET            4         //< 制热温度回差                单位：0.1℃ [max:45.0  min:5.0  def:18.0]
#define MB_REG_ADDR_SET_WORK_MODE               5         //< 模式设置   0:待机模式 / 1:自循环模式 / 2:制冷模式 / 3:制热模式
#define MB_REG_ADDR_SET_COOL_TMP                6         //< 制冷温度设定                单位：0.1℃ [max:45.0  min:5.0  def:18.0]

#define MB_REG_ADDR_R_STA_INFO                  1         //< 状态信息 
typedef struct {
    uint16_t power_on;                      //< 1       开关机
    uint16_t set_cool_tmp_ret;              //< 2       制冷温度回差
    uint16_t set_heat_tmp;                  //< 3       制热温度设定
    uint16_t set_heat_tmp_ret;              //< 4       制热温度回差
    uint16_t set_work_mode;                 //< 5       模式设置
    uint16_t set_cool_tmp;                  //< 6       制冷温度设定
    uint16_t outlet_temper;                 //< 7         //< 出水温度 ，单位：0.1℃
    uint16_t inlet_temper;                  //< 8         //< 回水温度 ，单位：0.1℃
    uint16_t outdoor_temper;                //< 9         //< 环境温度 ，单位：0.1℃
    uint16_t inlet_pressure;                //< 10        //< 进水压力 ，单位：0.01bar
    uint16_t outlet_pressure;               //< 11        //< 出水压力 ，单位：0.01bar
    uint16_t fault_info[2];                 //< 12 ~ 13 
    uint16_t fault_code;                    //< 14        //< 故障码【0~254】
    uint16_t max_warn_level;                //< 15        //< 当前告警最高等级
    uint16_t pump_rate;                     //< 16        //< 水泵转速 ，单位：0.1% 【0~1000】
    uint16_t pump_sta;                      //< 17        //< 水泵状态   【0：关闭 1：开启】
    uint16_t compressor_sta;                //< 18        //< 压缩机状态 【0：关闭 1：开启】
    uint16_t sw_id;                         //< 19        //< 软件编码
    uint16_t sw_ver;                        //< 20        //< 软件版本
    uint16_t work_mode;                     //< 21        //< 当前系统模式
} aine_lc_sta_dat_t;

const num_mapping_t work_mode_mapping[] = {
    /* sofar work mode ------------------- AINE work mode  */
    { .raw_num = LC_WORK_MODE_STANDBY     , .map_num = 0 },
    { .raw_num = LC_WORK_MODE_HEAT        , .map_num = 3 },
    { .raw_num = LC_WORK_MODE_COOL        , .map_num = 2 },
    { .raw_num = LC_WORK_MODE_WATER_LOOP  , .map_num = 1 },
};
static modbus_idx_t s_modbus_idx = MODBUS_IDX_INVALID;

static void _lc_ctrl_aine_sta_handle( bool power_on, uint8_t pump_sta, uint8_t compressor_sta, lc_sta_u *p_lc_sta);
static void _lc_ctrl_aine_warning_handle( uint16_t *p_fault, lc_warning_u *p_lc_warning );
static void _lc_ctrl_aine_fault_handle(  uint16_t *p_fault, lc_fault_u *p_lc_fault  );

sf_ret_t lc_ctrl_aine_init( modbus_idx_t modbus_idx )
{
    int32_t ret; 

    if( s_modbus_idx != MODBUS_IDX_INVALID )
    {
        app_modbus_close(s_modbus_idx);
    }

    s_modbus_idx = modbus_idx;

    ret = app_modbus_rtu_init( s_modbus_idx, MODBUS_SLAVE_ADDR, MODBUS_BUADRATE );
    if ( 0 > ret )
    {
        sdk_log_e( "%s, app_modbus_rtu_init ret:%d ", __FUNCTION__, ret);
        return ret;
    }
    
    ret = app_modbus_connect( s_modbus_idx );
    if ( 0 > ret )
    {
        sdk_log_e( "%s, app_modbus_connect ret:%d ", __FUNCTION__, ret);
        return ret;
    }

    app_modbus_response_timeout_set( s_modbus_idx, MODBUS_MSG_TIMEOUT_MS );

    sdk_log_d("%s success!!!", __FUNCTION__);

    return SF_OK;
}

sf_ret_t lc_ctrl_aine_deinit( void )
{
    if( s_modbus_idx != MODBUS_IDX_INVALID )
    {
        app_modbus_close(s_modbus_idx);
    }

    s_modbus_idx = MODBUS_IDX_INVALID;
    return SF_OK;
}

sf_ret_t lc_ctrl_aine_set_param(lc_ctrl_setting_t *p_lc_ctrl_setting)
{
    uint16_t tmp_val = 0;
    int32_t  ret;

    /* 液冷工作模式 */
    if ( SF_OK != lc_ctrl_aine_set_work_mode(p_lc_ctrl_setting->lc_mode) )
    {
        sdk_log_d("%s set work mode fail!!!, ret: %d", __FUNCTION__, ret);
        return SF_ERR_WR;
    }

    /* 温度控制方式 - 无 */
    
    /* 水泵流速 - 无 */

    /* 制冷设点 */
    tmp_val = p_lc_ctrl_setting->lc_cooling_point;
    ret = app_modbus_registers_write(s_modbus_idx, MODBUS_SLAVE_ADDR, MB_REG_ADDR_SET_COOL_TMP, 1, &tmp_val, 0);
    if ( ret < 0 )
    {
        sdk_log_d("%s set cooling point fail!!!, ret: %d", __FUNCTION__, ret);
        return SF_ERR_WR;
    }

    /* 制热设点 */
    tmp_val = p_lc_ctrl_setting->lc_heating_point;
    ret = app_modbus_registers_write(s_modbus_idx, MODBUS_SLAVE_ADDR, MB_REG_ADDR_SET_HEAT_TMP, 1, &tmp_val, 0);
    if (ret < 0)
    {
        sdk_log_d("%s set heating point fail!!!, ret: %d", __FUNCTION__, ret);
        return SF_ERR_WR;
    }

    /* 制冷回差 设定 */
    tmp_val = p_lc_ctrl_setting->lc_cooling_drop;
    ret = app_modbus_registers_write(s_modbus_idx, MODBUS_SLAVE_ADDR, MB_REG_ADDR_SET_COOL_TMP_RET, 1, &tmp_val, 0);
    if (ret < 0)
    {
        sdk_log_d("%s set cool ret fail!!!, ret: %d", __FUNCTION__, ret);
        return SF_ERR_WR;
    }

    /* 制热回差 设定 */
    tmp_val = p_lc_ctrl_setting->lc_heating_drop;
    ret = app_modbus_registers_write(s_modbus_idx, MODBUS_SLAVE_ADDR, MB_REG_ADDR_SET_HEAT_TMP_RET, 1, &tmp_val, 0);
    if (ret < 0)
    {
        sdk_log_d("%s set heating ret fail!!!, ret: %d", __FUNCTION__, ret);
        return SF_ERR_WR;
    }

    /* 制冷出水低温告警设定 - 无 */

    /* 制热出水高温告警设定 - 无 */

    /* 出水压力过高设定点 - 无 */

    /* 回水压力过低设定点 - 无 */
    
    return SF_OK;
}

sf_ret_t lc_ctrl_aine_set_flow( flow_t lc_flow )
{
    /* 不支持 */
    return SF_OK;
}

sf_ret_t lc_ctrl_aine_set_cool_temper( temper_t lc_cool_tmp )
{
    int32_t ret = app_modbus_registers_write( s_modbus_idx, MODBUS_SLAVE_ADDR, MB_REG_ADDR_SET_COOL_TMP, 1, (const uint16_t*)&lc_cool_tmp, 0 );
    return ( ret >= 0 )? SF_OK: SF_ERR_WR;
}

sf_ret_t lc_ctrl_aine_set_heat_temper( temper_t lc_heat_tmp )
{
    int32_t ret = app_modbus_registers_write( s_modbus_idx, MODBUS_SLAVE_ADDR, MB_REG_ADDR_SET_HEAT_TMP, 1, (const uint16_t*)&lc_heat_tmp, 0 );
    return ( ret >= 0 )? SF_OK: SF_ERR_WR;
}

sf_ret_t lc_ctrl_aine_set_work_mode( lc_work_mode_e lc_work_mode ) 
{
    map_num_t aine_work_mode;
    int32_t   ret = 0;

    if( lc_work_mode >= LC_WORK_MODE_MAX )
    {
        return SF_ERR_PARA;
    }

    SOFAR_WORK_MODE_TO_AINE_WORK_MODE( lc_work_mode , aine_work_mode );
    
    ret = app_modbus_registers_write( s_modbus_idx, MODBUS_SLAVE_ADDR, MB_REG_ADDR_SET_WORK_MODE, 1, (const uint16_t*)&aine_work_mode, 0 );
    return ( ret >= 0 )? SF_OK: SF_ERR_WR;
}

sf_ret_t lc_ctrl_aine_set_power_on( bool power_on )
{
    uint16_t wr_val = power_on ? 1 : 0;
    int32_t   ret = 0;

    ret = app_modbus_registers_write( s_modbus_idx, MODBUS_SLAVE_ADDR, MB_REG_ADDR_SET_POWER_ON, 1, (const uint16_t*)&wr_val, 0 );
    return ( ret >= 0 )? SF_OK: SF_ERR_WR;
}

sf_ret_t lc_ctrl_aine_get_lc_dat( lc_dat_t *p_lc_dat )
{
    aine_lc_sta_dat_t lc_sta_dat = {0};
    
    p_lc_dat->lc_type = LC_TYPE_AINE;
    
    int32_t ret = app_modbus_registers_read( s_modbus_idx, MODBUS_SLAVE_ADDR, MB_REG_ADDR_R_STA_INFO, 
                                             sizeof(aine_lc_sta_dat_t)/2, (uint16_t*)&lc_sta_dat, 0 );
    if( ret >= 0 )
    {
        raw_num_t sofar_work_mode = LC_WORK_MODE_INVALID;

        /* 转换成通用单位 */
        AINE_WORK_MODE_TO_SOFAR_WORK_MODE( lc_sta_dat.work_mode, sofar_work_mode );

        p_lc_dat->work_mode         = (lc_work_mode_e) sofar_work_mode;
        p_lc_dat->outdoor_temper    = lc_sta_dat.outdoor_temper;
        p_lc_dat->inlet_temper      = lc_sta_dat.inlet_temper;
        p_lc_dat->outlet_temper     = lc_sta_dat.outlet_temper;
        p_lc_dat->inlet_pressure    = lc_sta_dat.inlet_pressure;
        p_lc_dat->outlet_pressure   = lc_sta_dat.outlet_pressure;
        p_lc_dat->lc_flow           = lc_sta_dat.pump_rate / 10;
        p_lc_dat->lc_flow           = lc_sta_dat.pump_rate / 10;
        
        if( p_lc_dat->work_mode == LC_WORK_MODE_HEAT )
            p_lc_dat->lc_dst_tmp        = lc_sta_dat.set_heat_tmp;
        else
            p_lc_dat->lc_dst_tmp        = lc_sta_dat.set_cool_tmp;

        _lc_ctrl_aine_sta_handle( lc_sta_dat.power_on, lc_sta_dat.pump_sta, lc_sta_dat.compressor_sta, &p_lc_dat->sta );
        _lc_ctrl_aine_warning_handle( lc_sta_dat.fault_info, &p_lc_dat->warn );
        _lc_ctrl_aine_fault_handle( lc_sta_dat.fault_info, &p_lc_dat->fault );

        return SF_OK;
    }
    else
    {
        return SF_ERR_RD;
    }
}

sf_ret_t lc_ctrl_aine_get_lc_cap( lc_cap_t *p_lc_cap )
{
    p_lc_cap->lc_min_tmp       = 50;
    p_lc_cap->lc_max_tmp       = 450;
    p_lc_cap->lc_min_flow      = 60;
    p_lc_cap->lc_max_flow      = 100;
    p_lc_cap->lc_tmp_usr_ctrl  = true;
    p_lc_cap->lc_flow_usr_ctrl = true;

    return SF_OK;
}

static void _lc_ctrl_aine_sta_handle( bool power_on, uint8_t pump_sta, uint8_t compressor_sta, lc_sta_u *p_lc_sta)
{
    lc_aine_sta_u lc_sta = { .value = {0} };

    lc_sta.bit.sta.power_on = lc_sta.bit.sta.power_on_sta = power_on;

    lc_sta.bit.sta.pump_sta     = pump_sta;             // STATUS CODE 11	水泵状态
    lc_sta.bit.sta.compress_sta = compressor_sta;       // STATUS CODE 12	压缩机状态        

    *p_lc_sta = *(lc_sta_u*)&lc_sta;
}

static void _lc_ctrl_aine_warning_handle( uint16_t *p_fault, lc_warning_u *p_lc_warning )
{
    lc_aine_warning_u lc_warn = { .value = {0} };

    lc_warn.bit.warn.inlet_press_sen_fault        = (p_fault[0] & BIT(13))? 1: 0;      // WARNING CODE 10  进水水压传感器故障
    lc_warn.bit.warn.outlet_press_sen_fault       = (p_fault[1] & BIT(2))? 1: 0;       // WARNING CODE 11  出水水压传感器故障
    lc_warn.bit.warn.out_inlet_press_delta_fault  = (p_fault[1] & BIT(4))? 1: 0;       // WARNING CODE 12  进出水压差故障
    if( lc_warn.value != 0 )
    {
        lc_warn.bit.warn.total_warning_code = 1;
    }

    *p_lc_warning = *(lc_warning_u*)&lc_warn;
}

static void _lc_ctrl_aine_fault_handle(  uint16_t *p_fault, lc_fault_u *p_lc_fault  )
{
    lc_aine_fault_u lc_fault = { .value = {0} };
    
    lc_fault.bit.err.HCM_com_fault        = (p_fault[0] & BIT(0))? 1: 0;   // ERR CODE 10     485模块和HCM通信故障   
    lc_fault.bit.err.hig_vol_sw_fault     = (p_fault[0] & BIT(1))? 1: 0;   // ERR CODE 11     高压接触器故障
    lc_fault.bit.err.k2_sw_fault          = (p_fault[0] & BIT(2))? 1: 0;   // ERR CODE 12     K2接触器故障
    lc_fault.bit.err.ADC_A_vol_low        = (p_fault[0] & BIT(3))? 1: 0;   // ERR CODE 13     ACDC_A_过欠压故障
    lc_fault.bit.err.ADC_A_fault          = (p_fault[0] & BIT(4))? 1: 0;   // ERR CODE 14     ACDC_A_自身故障
    lc_fault.bit.err.fan_fault            = (p_fault[0] & BIT(5))? 1: 0;   // ERR CODE 15     风机故障
    lc_fault.bit.err.hig_press_sen_fault  = (p_fault[0] & BIT(6))? 1: 0;   // ERR CODE 16     高压传感器故障
    lc_fault.bit.err.too_hig_press        = (p_fault[0] & BIT(7))? 1: 0;   // ERR CODE 17     高压过高
    lc_fault.bit.err.low_press_sen_fault  = (p_fault[0] & BIT(8))? 1: 0;   // ERR CODE 18     低压传感器故障
    lc_fault.bit.err.too_low_press        = (p_fault[0] & BIT(9))? 1: 0;   // ERR CODE 19     低压过低
    lc_fault.bit.err.outlen_tmp_sen_fault = (p_fault[0] & BIT(10))? 1: 0;  // ERR CODE 20     出水温度传感器故障
    lc_fault.bit.err.inlen_tmp_sen_fault  = (p_fault[0] & BIT(11))? 1: 0;  // ERR CODE 21     进水温度传感器故障
    lc_fault.bit.err.pump_fault           = (p_fault[0] & BIT(12))? 1: 0;  // ERR CODE 22     水泵故障
    lc_fault.bit.err.evn_tmp_sen_fault    = (p_fault[0] & BIT(14))? 1: 0;  // ERR CODE 23     环境温度传感器故障
    lc_fault.bit.err.ac_con_fail          = (p_fault[0] & BIT(15))? 1: 0;  // ERR CODE 24     AC通讯丢失故障
    lc_fault.bit.err.ac_compress_fault    = (p_fault[1] & BIT(0))? 1: 0;   // ERR CODE 25     AC压缩机控制器故障
    lc_fault.bit.err.ptc_hig_tmp          = (p_fault[1] & BIT(1))? 1: 0;   // ERR CODE 26     PTC过温故障
    lc_fault.bit.err.hig_press_sw_fault   = (p_fault[1] & BIT(3))? 1: 0;   // ERR CODE 27     高压压力开关故障

    *p_lc_fault = *(lc_fault_u*)&lc_fault;

    return;
}
