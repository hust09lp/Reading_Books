
#include "lc_ctrl.h"
#include "lc_ctrl_media.h"
#include "lc_ctrl_aine.h"
#include "tick_timer.h"

#include "sdk.h"
#include "sdk_core.h"

#define DEF_LC_TYPE                                 LC_TYPE_MEDIA

#define READ_FAIL_MAX_CNT                           120              // 设备连续读取N次错误 则进入离线模式

#define LC_SET_RETRY_CNT                            1               // 液冷设置参数重传次数

#define LC_ONLINE_RD_INTERVAL_TM_MS                 5000
#define LC_OFFLINE_RD_INTERVAL_TM_MS                30000

#define ERR_UPLOAD_DELAY_TM_MS                      (180 * 1000)
#define ERR_UPLOAD_DELAY_CNT                        ( ERR_UPLOAD_DELAY_TM_MS / LC_ONLINE_RD_INTERVAL_TM_MS )

typedef struct {
    sf_ret_t (*lc_ctrl_init_cb)( modbus_idx_t modbus_idx );
    sf_ret_t (*lc_ctrl_deinit_cb)( void );
    sf_ret_t (*lc_ctrl_set_cb)( lc_ctrl_setting_t *p_lc_ctrl_setting );
    sf_ret_t (*lc_ctrl_set_flow_cb)( flow_t lc_flow );
    sf_ret_t (*lc_ctrl_set_cool_temper_cb)( temper_t lc_cool_tmp );
    sf_ret_t (*lc_ctrl_set_heat_temper_cb)( temper_t lc_heat_tmp );
    sf_ret_t (*lc_ctrl_set_work_mode_cb)( lc_work_mode_e lc_work_mode );
    sf_ret_t (*lc_ctrl_get_lc_dat_cb)( lc_dat_t *p_lc_dat );
    sf_ret_t (*lc_ctrl_set_power_on)( bool power_on );
    sf_ret_t (*lc_ctrl_get_lc_cap)( lc_cap_t *p_lc_cap );
} lc_dev_op;

typedef struct {
    struct {
        modbus_idx_t              mb_idx;
        lc_online_change_callback online_cb;
        lc_dat_update_callback    update_cb;
    } attr;
    struct {
        bool        online;
        lc_dat_t    lc_dat;
        rate_t      com_loss_rate;
        tick_timer_handle_t rd_timer;           // 读取实时数据 定时器
        tick_timer_handle_t vertify_timer;      // 校验数据 定时器
    } run;
} lc_ctrl_info_t;

static lc_type_e s_lc_type   = DEF_LC_TYPE;
static lc_dev_op s_dev_ops[] = {
    /* 美的液冷 */
    [ LC_TYPE_MEDIA ] = { 
        .lc_ctrl_init_cb            = lc_ctrl_media_init,
        .lc_ctrl_deinit_cb          = lc_ctrl_media_deinit,
        .lc_ctrl_set_cb             = lc_ctrl_media_set_param,
        .lc_ctrl_set_flow_cb        = lc_ctrl_media_set_flow,
        .lc_ctrl_set_cool_temper_cb = lc_ctrl_media_set_cool_temper,
        .lc_ctrl_set_heat_temper_cb = lc_ctrl_media_set_heat_temper,
        .lc_ctrl_set_work_mode_cb   = lc_ctrl_media_set_work_mode,
        .lc_ctrl_set_power_on       = lc_ctrl_media_set_power_on,
        .lc_ctrl_get_lc_dat_cb      = lc_ctrl_media_get_lc_dat,
        .lc_ctrl_get_lc_cap         = lc_ctrl_media_get_lc_cap,
    },
    /* 空调国际液冷 */
    [ LC_TYPE_AINE ] = {
        .lc_ctrl_init_cb            = lc_ctrl_aine_init,
        .lc_ctrl_deinit_cb          = lc_ctrl_aine_deinit,
        .lc_ctrl_set_cb             = lc_ctrl_aine_set_param,
        .lc_ctrl_set_flow_cb        = lc_ctrl_aine_set_flow,
        .lc_ctrl_set_cool_temper_cb = lc_ctrl_aine_set_cool_temper,
        .lc_ctrl_set_heat_temper_cb = lc_ctrl_aine_set_heat_temper,
        .lc_ctrl_set_work_mode_cb   = lc_ctrl_aine_set_work_mode,
        .lc_ctrl_set_power_on       = lc_ctrl_aine_set_power_on,
        .lc_ctrl_get_lc_dat_cb      = lc_ctrl_aine_get_lc_dat,
        .lc_ctrl_get_lc_cap         = lc_ctrl_aine_get_lc_cap,
    }
};

static uint8_t lc_err_cnt_list[ 64 ] = {0};
static lc_ctrl_info_t s_lc_ctrl_info = { .attr = { .mb_idx  = MODBUS_IDX_INVALID} ,
                                         .run  = { .lc_dat.lc_type = DEF_LC_TYPE,
                                                   .online = true } };
static sdk_os_mutex_id_t s_lc_ctrl_mutex = NULL;

/**
 * @brief  液冷机组初始化
 * @param  [in] modbus_idx modbus索引
 * @param  [in] online_cb 上线离线回调（可选）
 * @param  [in] update_cb 液冷运行数据的变化通知（可选）
 * @return SF_OK：成功  小于SF_OK: 失败
 */
sf_ret_t lc_ctrl_init( modbus_idx_t modbus_idx, lc_online_change_callback online_cb, lc_dat_update_callback update_cb )
{
    s_lc_ctrl_info.attr.mb_idx = modbus_idx;

    s_dev_ops[ s_lc_type ].lc_ctrl_deinit_cb();
    s_dev_ops[ s_lc_type ].lc_ctrl_init_cb( modbus_idx );
    
    s_lc_ctrl_info.run.rd_timer = tick_timer_create();
    if( s_lc_ctrl_info.run.rd_timer == NULL )
    {
        sdk_log_e( "rd_timer == NULL" );
        return SF_ERR_NO_OBJECT;
    }
    tick_timer_set_timeout( s_lc_ctrl_info.run.rd_timer, LC_ONLINE_RD_INTERVAL_TM_MS );
    s_lc_ctrl_info.run.online = true;

    sdk_os_mutex_attr_t mutex_attr = { .name = "lc_ctrl_mutex" };

    s_lc_ctrl_mutex = sdk_os_mutex_new( &mutex_attr );
    if ( NULL == s_lc_ctrl_mutex )
    {
        sdk_log_e( "%s create mutex error!!!", __FUNCTION__ );
        return SF_ERR_NO_OBJECT;
    }

    s_dev_ops[ s_lc_type ].lc_ctrl_set_power_on( false );

    sdk_log_d("%s success", __FUNCTION__);

    return SF_OK;
}

/**
 * @brief  液冷机组设置参数
 * @param  [in] p_lc_ctrl_setting ：设置参数
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
sf_ret_t lc_ctrl_set_param( lc_ctrl_setting_t *p_lc_ctrl_setting )
{
    sf_ret_t ret = SF_OK;

    sdk_log_d("%s", __FUNCTION__);
    if( p_lc_ctrl_setting->lc_type != s_lc_type )
    {
        s_dev_ops[ s_lc_type ].lc_ctrl_deinit_cb();

        s_lc_type = p_lc_ctrl_setting->lc_type;
        s_lc_ctrl_info.run.lc_dat.lc_type = s_lc_type;

        s_dev_ops[ s_lc_type ].lc_ctrl_init_cb( s_lc_ctrl_info.attr.mb_idx );
    }

    sdk_os_mutex_acquire( s_lc_ctrl_mutex, SF_MUTEX_WAIT_FOREVER );

    /* 自动模式下，需要开启液冷 */
    if( p_lc_ctrl_setting->lc_auto_mode == true )
    {
        ret = lc_ctrl_set_power_on(true);
    }

    /* 设置其他液冷参数参数 */
    if( ret >= 0 )
    {
        for (size_t i = 0; i < LC_SET_RETRY_CNT; i++)
        {
            ret = s_dev_ops[ s_lc_type ].lc_ctrl_set_cb( p_lc_ctrl_setting );
            if( ret >= SF_OK )
            {
                break;
            }
        }
    }
    sdk_os_mutex_release( s_lc_ctrl_mutex );

    if( ret >= SF_OK )
    {
        sdk_log_d("%s success, ret:%d ", __FUNCTION__, ret);
    }
    else
    {
        sdk_log_e("%s fail, ret:%d ", __FUNCTION__, ret);
    }

    return ret;
}

/**
 * @brief  液冷机组设置供液流量
 * @param  [in] lc_flow 流量
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
sf_ret_t lc_ctrl_set_flow( flow_t lc_flow )
{
    sf_ret_t ret = SF_OK;

    sdk_log_d("%s", __FUNCTION__);

    sdk_os_mutex_acquire( s_lc_ctrl_mutex, SF_MUTEX_WAIT_FOREVER );
    for (size_t i = 0; i < LC_SET_RETRY_CNT; i++)
    {
        ret = s_dev_ops[ s_lc_type ].lc_ctrl_set_flow_cb( lc_flow );
        if( ret > 0 )
        {
            break;
        }
    }
    sdk_os_mutex_release( s_lc_ctrl_mutex );
    
    if ( SF_OK > ret )
    {
        sdk_log_e("%s fail, ret:%d ", __FUNCTION__, ret);
    }

    return ret;
}

/**
 * @brief  液冷机组制冷温度设定
 * @param  [in] lc_cool_tmp ：液冷制冷设点温度
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
sf_ret_t lc_ctrl_set_cool_temper( temper_t lc_cool_tmp )
{
    sf_ret_t ret = SF_OK;

    sdk_log_d("%s", __FUNCTION__);

    sdk_os_mutex_acquire( s_lc_ctrl_mutex, SF_MUTEX_WAIT_FOREVER );
    for (size_t i = 0; i < LC_SET_RETRY_CNT; i++)
    {
        ret = s_dev_ops[ s_lc_type ].lc_ctrl_set_cool_temper_cb( lc_cool_tmp );
        if( ret >= SF_OK )
        {
            break;
        }
    }
    sdk_os_mutex_release( s_lc_ctrl_mutex );

    if ( SF_OK > ret )
    {
        sdk_log_e("%s fail, ret:%d ", __FUNCTION__, ret);
    }

    return ret;
}

/**
 * @brief  液冷机组制热温度设定
 * @param  [in] lc_heat_tmp ：液冷制热设点温度
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
sf_ret_t lc_ctrl_set_heat_temper( temper_t lc_heat_tmp )
{
    sf_ret_t ret = SF_OK;

    sdk_log_d("%s", __FUNCTION__);

    sdk_os_mutex_acquire( s_lc_ctrl_mutex, SF_MUTEX_WAIT_FOREVER );
    for (size_t i = 0; i < LC_SET_RETRY_CNT; i++)
    {
        ret = s_dev_ops[ s_lc_type ].lc_ctrl_set_heat_temper_cb( lc_heat_tmp );
        if( ret > 0 )
        {
            break;
        }
    }
    sdk_os_mutex_release( s_lc_ctrl_mutex );

    if ( SF_OK > ret )
    {
        sdk_log_e("%s fail, ret:%d ", __FUNCTION__, ret);
    }
    return ret;
}

/**
 * @brief  液冷机组设置工作模式
 * @param  [in] lc_work_mode ： 工作模式
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
sf_ret_t lc_ctrl_set_work_mode( lc_work_mode_e lc_work_mode )
{
    sf_ret_t ret = SF_OK;

    sdk_log_d("%s", __FUNCTION__);
    sdk_os_mutex_acquire( s_lc_ctrl_mutex, SF_MUTEX_WAIT_FOREVER );
    for (size_t i = 0; i < LC_SET_RETRY_CNT; i++)
    {
        ret = s_dev_ops[ s_lc_type ].lc_ctrl_set_work_mode_cb( lc_work_mode );
        if( ret >= SF_OK )
        {
            break;
        }
    }
    sdk_os_mutex_release( s_lc_ctrl_mutex );

    if ( SF_OK > ret )
    {
        sdk_log_e("%s fail, ret:%d ", __FUNCTION__, ret);
    }
    return ret;
}

/**
 * @brief  液冷机组设置开关机
 * @param  [in] power_on ：开关机
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
sf_ret_t lc_ctrl_set_power_on( bool power_on )
{
    sf_ret_t ret = SF_OK;

    sdk_log_d("%s:%d", __FUNCTION__, power_on);

    sdk_os_mutex_acquire( s_lc_ctrl_mutex, SF_MUTEX_WAIT_FOREVER );
    for (size_t i = 0; i < LC_SET_RETRY_CNT; i++)
    {
        ret = s_dev_ops[ s_lc_type ].lc_ctrl_set_power_on( power_on );
        if (ret >= SF_OK)
        {
            break;
        }
    }
    sdk_os_mutex_release( s_lc_ctrl_mutex );

    if ( SF_OK > ret )
    {
        sdk_log_e("%s fail, ret:%d ", __FUNCTION__, ret);
    }
    return ret;
}

/**
 * @brief  液冷机组获取液冷能力
 * @param  [in] p_lc_cap ：液冷能力
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
sf_ret_t lc_ctrl_get_lc_cap( lc_cap_t *p_lc_cap )
{
    return s_dev_ops[ s_lc_type ].lc_ctrl_get_lc_cap( p_lc_cap );
}

/**
 * @brief  获取当前液冷机组通讯丢包率
 * @param  [in] 无
 * @return 返回丢包率
 * @note   
 */
rate_t lc_ctrl_get_com_loss_rate( void )
{
    return s_lc_ctrl_info.run.com_loss_rate;
}

/**
 * @brief  液冷机组获取液冷数据
 * @param  [in] p_lc_dat ：液冷数据
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
sf_ret_t lc_ctrl_get_lc_dat( lc_dat_t *p_lc_dat )
{
    *p_lc_dat = s_lc_ctrl_info.run.lc_dat;
    return SF_OK;
}

/**
 * @brief  液冷机组获取在线状态
 * @param  [in] 
 * @return true:在线  false：离线
 * @note   
 */
bool lc_ctrl_get_online( void )
{
    return s_lc_ctrl_info.run.online;
}

/**
 * @brief  液冷机组控制任务调度【外部线程使用】
 * @param  [in] 无 
 * @return 无
 * @note   
 */
void lc_ctrl_task_loop( void )
{
    static uint32_t cal_fail_cnt = 0;
    static uint32_t cal_cnt    = 0;

    if( tick_timer_is_timeout( s_lc_ctrl_info.run.rd_timer ) )
    {
        static bool    online = false;
        static uint8_t fail_cnt = 0;

        lc_dat_t lc_dat = {.sta.value = 0};
        sdk_os_mutex_acquire( s_lc_ctrl_mutex, SF_MUTEX_WAIT_FOREVER );
        if( 0 > s_dev_ops[ s_lc_type ].lc_ctrl_get_lc_dat_cb( &lc_dat ) )
        {
            cal_fail_cnt++;
            if( (++fail_cnt) >= READ_FAIL_MAX_CNT )
            {
                online = false;
            }
        }else {
            uint64_t tmp_err_code = lc_dat.fault.value;

            online = true;
            fail_cnt = 0;

            lc_dat.fault.value = 0;
            for (size_t i = 0; i < ARRAY_SIZE( lc_err_cnt_list ); i++)
            {
                if ( tmp_err_code & BIT( i )) 
                {
                    lc_err_cnt_list[ i ]++;
                    if ( lc_err_cnt_list[ i ] >= ERR_UPLOAD_DELAY_CNT )
                    {
                        lc_dat.fault.value |= BIT( i );
                    }
                }else{
                    lc_err_cnt_list[ i ] = 0;
                }
            }

            s_lc_ctrl_info.run.lc_dat = lc_dat;
        }
        sdk_os_mutex_release( s_lc_ctrl_mutex );
        cal_cnt++;

        s_lc_ctrl_info.run.com_loss_rate = (rate_t)( (float)cal_fail_cnt / (float)cal_cnt * 10000.0f);
        
        // if ( (cal_cnt & 0x7f) == 0 )
        // {
        //     /* 128次打印一次 */
        //     sdk_log_d( "lc fail cnt:%d, total cnt:%d", cal_fail_cnt, cal_cnt );
        // }

        if( s_lc_ctrl_info.run.online != online )
        {
            /* 在线状态发生切换，根据 在线状态 切换查询时间 */
            s_lc_ctrl_info.run.online = online;
            s_lc_ctrl_info.run.lc_dat.fault.bit.err.err_code1_offline = online ? 0: 1;
            tick_timer_set_timeout( s_lc_ctrl_info.run.rd_timer, (online == true)? LC_ONLINE_RD_INTERVAL_TM_MS: LC_OFFLINE_RD_INTERVAL_TM_MS );
        }
        s_lc_ctrl_info.run.lc_dat.fault.bit.err.total_err_code = ( s_lc_ctrl_info.run.lc_dat.fault.value !=0 )? 1: 0;
        s_lc_ctrl_info.run.lc_dat.warn.bit.warn.total_warning_code = ( s_lc_ctrl_info.run.lc_dat.warn.value !=0 )? 1: 0;

        tick_timer_refresh( s_lc_ctrl_info.run.rd_timer );
    }
}
