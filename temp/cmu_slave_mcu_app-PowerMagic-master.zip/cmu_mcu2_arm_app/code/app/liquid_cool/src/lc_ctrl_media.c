#include "lc_ctrl_media.h"
#include "lc_type_media.h"
#include "num_trans.h"
#include "app_modbus.h"

#include "sdk.h"
#include "sdk_core.h"

#define MODBUS_SLAVE_ADDR                       1
#define MODBUS_BUADRATE                         9600
#define MODBUS_MSG_TIMEOUT_MS                   200         //< MODBUS 消息超时时间

#define MB_REG_ADDR_SET_POWER_ON                0           //< 开关机   0：待机；1：开机
#define MB_REG_ADDR_SET_WORK_MODE               1           //< 模式设置 0：待机 / 1：制冷 / 2：制热 / 3：自循环 / 4：自动模式
#define MB_REG_ADDR_SET_DST_TMP                 2           //< 设定温度，单位：0.1℃

#define MB_REG_ADDR_SET_TMP_CTRL_MODE           407         //< 温度控制方式 0：出水控制 1：进水控制
#define MB_REG_ADDR_SET_TMP_BAND                430         //< 温度比例带，即为温度回差    单位：0.1℃
#define MB_REG_ADDR_SET_PUMP_RATE               467         //< 水泵转速设定                单位：1%
#define MB_REG_ADDR_SET_COOL_TMP                468         //< 制冷温度设定                单位：0.1℃ [max:45.0  min:5.0  def:18.0]
#define MB_REG_ADDR_SET_HEAT_TMP                469         //< 制热温度设定                单位：0.1℃ [max:45.0  min:5.0  def:18.0]
#define MB_REG_ADDR_SET_COOL_OUTLET_LOW_TMP     483         //< 制冷出水低温告警设定        单位：0.1℃  [max:15.0  min:-30.0  def:5.0 ]
#define MB_REG_ADDR_SET_HEAT_OUTLET_HIG_TMP     484         //< 制热出水高温告警设定        单位：0.1℃  [max:50.0  min:10.0  def:45.0 ]
#define MB_REG_ADDR_SET_OUTLET_HIG_PRESS        492         //< 出水压力过高设定点          单位：0.01bar   [max:4.0   min:1.0   def:2.8]
#define MB_REG_ADDR_SET_INLET_LOW_PRESS         493         //< 回水压力过低设定点          单位：0.01bar   [max:0.5   min:0.0   def:0.4]

#define MB_REG_ADDR_R_STA_INFO                  0         //< 状态信息

typedef struct {
    struct {
        uint16_t power_on;          //< 0 开关机
        uint16_t set_lc_mode;       //< 1 设定模式
        uint16_t set_lc_tmp;        //< 2 设定供液温度
    } setting;
    struct {
        uint16_t power_on;          //< 0 开关机
        uint16_t set_lc_mode;       //< 1 设定模式
        uint16_t set_lc_tmp;        //< 2 设定供液温度
    } read;
} lc_mb_imp_param_t;

static lc_mb_imp_param_t s_lc_mb_imp_param = { .setting = { 0,0,0 } };
static bool s_lc_param_adj_enable = false;
static modbus_idx_t s_modbus_idx = MODBUS_IDX_INVALID; 

static void _lc_ctrl_media_sta_handle( bool power_on, uint16_t *p_status, lc_sta_u *p_lc_sta );
static void _lc_ctrl_media_warning_handle( uint16_t *p_fault, uint16_t *p_status, lc_warning_u *p_lc_warning );
static void _lc_ctrl_media_fault_handle(  uint16_t *p_fault, uint16_t *p_status, lc_fault_u *p_lc_fault );
void lc_ctrl_media_imp_param_adjust( void );

sf_ret_t lc_ctrl_media_init( modbus_idx_t modbus_idx )
{
    int32_t ret; 

    if( s_modbus_idx != MODBUS_IDX_INVALID )
    {
        app_modbus_close(s_modbus_idx);
    }

    s_modbus_idx = modbus_idx;

    ret = app_modbus_rtu_init( s_modbus_idx, MODBUS_SLAVE_ADDR, MODBUS_BUADRATE );
    if ( 0 > ret )
    {
        sdk_log_e( "%s, app_modbus_rtu_init ret:%d ", __FUNCTION__, ret);
        return ret;
    }
    
    ret = app_modbus_connect( s_modbus_idx );
    if ( 0 > ret )
    {
        sdk_log_e( "%s, app_modbus_connect ret:%d ", __FUNCTION__, ret);
        return ret;
    }
    // app_modbus_debug_set( s_modbus_idx, 1 );
    app_modbus_response_timeout_set( s_modbus_idx, MODBUS_MSG_TIMEOUT_MS );

    sdk_log_d("%s success!!!", __FUNCTION__);

    return SF_OK;
}

sf_ret_t lc_ctrl_media_deinit( void )
{
    if( s_modbus_idx != MODBUS_IDX_INVALID )
    {
        app_modbus_close(s_modbus_idx);
    }

    s_modbus_idx = MODBUS_IDX_INVALID;

    return SF_OK;
}

sf_ret_t lc_ctrl_media_set_param(lc_ctrl_setting_t *p_lc_ctrl_setting)
{
    uint16_t tmp_val = 0;
    int32_t ret;

    /* 液冷工作模式 */
    if ( SF_OK > lc_ctrl_media_set_work_mode(p_lc_ctrl_setting->lc_mode))
    {
        return SF_ERR_PARA;
    }

    /* 温度控制方式 */
    tmp_val = (uint16_t)p_lc_ctrl_setting->lc_ctrl_mode;
    ret = app_modbus_registers_write(s_modbus_idx, MODBUS_SLAVE_ADDR, MB_REG_ADDR_SET_TMP_CTRL_MODE, 1, &tmp_val, 0);
    if (ret < 0)
    {
        sdk_log_d("%s set water lc_ctrl_mode fail!!!, ret: %d", __FUNCTION__, ret);
        return SF_ERR_WR;
    }

    /* 水泵流速 */
    ret = app_modbus_registers_write(s_modbus_idx, MODBUS_SLAVE_ADDR, MB_REG_ADDR_SET_PUMP_RATE, 1,
                                     (uint16_t *)&p_lc_ctrl_setting->lc_pump_rate, 0);
    if (ret < 0)
    {
        sdk_log_d("%s set lc_pump_rate fail!!!, ret: %d", __FUNCTION__, ret);
        return SF_ERR_WR;
    }

    /* 制冷设点 */

    /* 制热设点 */

    /* 制冷回差 和 制热回差 -- 美的【温度比例带】*/

    /* 直接以制冷设定 设置 目标供液温度 */
    s_lc_mb_imp_param.setting.set_lc_tmp = p_lc_ctrl_setting->lc_cooling_point;
    ret = app_modbus_registers_write(s_modbus_idx, MODBUS_SLAVE_ADDR, MB_REG_ADDR_SET_DST_TMP, 1,
                                     (uint16_t *)&p_lc_ctrl_setting->lc_cooling_point, 0);
    if (ret < 0)
    {
        sdk_log_d("%s set lc_cooling_point fail!!!, ret: %d", __FUNCTION__, ret);
        return SF_ERR_WR;
    }

    /* 制冷出水低温告警设定 */
    ret = app_modbus_registers_write(s_modbus_idx, MODBUS_SLAVE_ADDR, MB_REG_ADDR_SET_COOL_OUTLET_LOW_TMP, 1,
                                     (uint16_t *)&p_lc_ctrl_setting->lc_cool_outlet_low_tmp, 0);
    if (ret < 0)
    {
        sdk_log_d("%s set lc_cool_outlet_low_tmp fail!!!, ret: %d", __FUNCTION__, ret);
        return SF_ERR_WR;
    }

    /* 制热出水高温告警设定 */
    ret = app_modbus_registers_write(s_modbus_idx, MODBUS_SLAVE_ADDR, MB_REG_ADDR_SET_HEAT_OUTLET_HIG_TMP, 1,
                                     (uint16_t *)&p_lc_ctrl_setting->lc_heat_outlet_hig_tmp, 0);
    if (ret < 0)
    {
        sdk_log_d("%s set lc_heat_outlet_hig_tmp fail!!!, ret: %d", __FUNCTION__, ret);
        return SF_ERR_WR;
    }

    /* 出水压力过高设定点 */
    ret = app_modbus_registers_write(s_modbus_idx, MODBUS_SLAVE_ADDR, MB_REG_ADDR_SET_OUTLET_HIG_PRESS, 1,
                                     (uint16_t *)&p_lc_ctrl_setting->lc_outlet_pressure_high, 0);
    if (ret < 0)
    {
        sdk_log_d("%s set lc_outlet_pressure_high fail!!!, ret: %d", __FUNCTION__, ret);
        return SF_ERR_WR;
    }

    /* 回水压力过低设定点 */
    ret = app_modbus_registers_write(s_modbus_idx, MODBUS_SLAVE_ADDR, MB_REG_ADDR_SET_INLET_LOW_PRESS, 1,
                                     (uint16_t *)&p_lc_ctrl_setting->lc_inlet_pressure_low, 0);
    if (ret < 0)
    {
        sdk_log_d("%s set lc_inlet_pressure_low fail!!!, ret: %d", __FUNCTION__, ret);
        return SF_ERR_WR;
    }

    lc_ctrl_media_adjust_set( true );
    
    return SF_OK;
}

sf_ret_t lc_ctrl_media_set_flow( flow_t lc_flow )
{
    int32_t ret = app_modbus_registers_write( s_modbus_idx, MODBUS_SLAVE_ADDR, MB_REG_ADDR_SET_PUMP_RATE, 1, (const uint16_t*)&lc_flow, 0 );
    return ( ret >= 0 )? SF_OK: SF_ERR_WR;
}

sf_ret_t lc_ctrl_media_set_cool_temper( temper_t lc_cool_tmp )
{
    int32_t ret = app_modbus_registers_write( s_modbus_idx, MODBUS_SLAVE_ADDR, MB_REG_ADDR_SET_DST_TMP, 1, (const uint16_t*)&lc_cool_tmp, 0 );
    s_lc_mb_imp_param.setting.set_lc_tmp = lc_cool_tmp;

    return ( ret >= 0 )? SF_OK: SF_ERR_WR;
}

sf_ret_t lc_ctrl_media_set_heat_temper( temper_t lc_heat_tmp )
{
    int32_t ret = app_modbus_registers_write( s_modbus_idx, MODBUS_SLAVE_ADDR, MB_REG_ADDR_SET_DST_TMP, 1, (const uint16_t*)&lc_heat_tmp, 0 );
    s_lc_mb_imp_param.setting.set_lc_tmp = lc_heat_tmp;

    return ( ret >= 0 )? SF_OK: SF_ERR_WR;
}

sf_ret_t lc_ctrl_media_set_work_mode( lc_work_mode_e lc_work_mode ) 
{
    uint16_t work_mode_map[] = { 0, 2, 1, 3 };
    int32_t  ret = 0;

    if( lc_work_mode >= LC_WORK_MODE_MAX )
    {
        return -1;
    }
    s_lc_mb_imp_param.setting.set_lc_mode = work_mode_map[ lc_work_mode ];
    ret = app_modbus_registers_write( s_modbus_idx, MODBUS_SLAVE_ADDR, MB_REG_ADDR_SET_WORK_MODE, 1, (const uint16_t*)&work_mode_map[ lc_work_mode ], 0 );
    return ( ret >= 0 )? SF_OK: SF_ERR_WR;
}

sf_ret_t lc_ctrl_media_set_power_on( bool power_on )
{
    uint16_t wr_val = power_on ? 1 : 0;
    int32_t  ret = 0;

    ret = app_modbus_registers_write( s_modbus_idx, MODBUS_SLAVE_ADDR, MB_REG_ADDR_SET_POWER_ON, 1, (const uint16_t*)&wr_val, 0 );
    s_lc_mb_imp_param.setting.power_on = wr_val;
    
    return ( ret >= 0 )? SF_OK: SF_ERR_WR;
}

sf_ret_t lc_ctrl_media_get_lc_dat( lc_dat_t *p_lc_dat )
{
    struct {
        uint16_t power_on;          //< 0 开关机
        uint16_t set_lc_mode;       //< 1 设定模式
        uint16_t set_lc_tmp;        //< 2 设定供液温度
        uint16_t reserve[7];        //< 3 ~ 9 预留       
        uint16_t fault_info[7];     //< 10 ~ 16
        uint16_t status_info[3];    //< 17 ~ 19
        uint16_t reserve1[2];       //< 20 ~ 21
        uint16_t work_mode;         //< 22 [ 0:关机；1:制冷；2:制热；3:自循环 ]
        uint16_t fault_code;        //< 23 
        uint16_t pump_rate;         //< 24 水泵转速 ，单位：1%
        uint16_t outdoor_temper;    //< 25 室外环境温度 ，单位：0.1℃
        uint16_t inlet_temper;      //< 26 进水温度 ，单位：0.1℃
        uint16_t outlet_temper;     //< 27 出水温度 ，单位：0.1℃
        uint16_t reserve2;          //< 28
        uint16_t inlet_pressure;    //< 29 进水压力，单位：0.01bar
        uint16_t outlet_pressure;   //< 30 出水压力，单位：0.01bar
    } lc_sta_dat;

    p_lc_dat->lc_type = LC_TYPE_MEDIA;
    
    int32_t ret = app_modbus_registers_read( s_modbus_idx, MODBUS_SLAVE_ADDR, MB_REG_ADDR_R_STA_INFO, sizeof(lc_sta_dat)/2, (uint16_t*)&lc_sta_dat, 0 );
    if( ret >= 0 )
    {
        lc_work_mode_e com_work_mode[] = { LC_WORK_MODE_STANDBY, LC_WORK_MODE_COOL, LC_WORK_MODE_HEAT, LC_WORK_MODE_WATER_LOOP };

        /* 转换成通用单位 */
        p_lc_dat->work_mode         = (lc_sta_dat.work_mode < 4 )? com_work_mode[ lc_sta_dat.work_mode ] : LC_WORK_MODE_INVALID ;
        p_lc_dat->outdoor_temper    = lc_sta_dat.outdoor_temper;
        p_lc_dat->inlet_temper      = lc_sta_dat.inlet_temper;
        p_lc_dat->outlet_temper     = lc_sta_dat.outlet_temper;
        p_lc_dat->inlet_pressure    = lc_sta_dat.inlet_pressure;
        p_lc_dat->outlet_pressure   = lc_sta_dat.outlet_pressure;
        p_lc_dat->lc_flow           = lc_sta_dat.pump_rate;
        p_lc_dat->lc_dst_tmp        = lc_sta_dat.set_lc_tmp;

        _lc_ctrl_media_sta_handle( lc_sta_dat.power_on, lc_sta_dat.status_info, &p_lc_dat->sta );
        _lc_ctrl_media_warning_handle( lc_sta_dat.fault_info, lc_sta_dat.status_info, &p_lc_dat->warn );
        _lc_ctrl_media_fault_handle( lc_sta_dat.fault_info, lc_sta_dat.status_info, &p_lc_dat->fault );

        s_lc_mb_imp_param.read.power_on = lc_sta_dat.power_on;
        s_lc_mb_imp_param.read.set_lc_mode = lc_sta_dat.set_lc_mode;
        s_lc_mb_imp_param.read.set_lc_tmp = lc_sta_dat.set_lc_tmp;

        lc_ctrl_media_imp_param_adjust();

        return SF_OK;
    }
    else
    {
        return SF_ERR_RD;
    }
}

void lc_ctrl_media_adjust_set( bool enable )
{
    s_lc_param_adj_enable = enable;
}

/**
 * @brief  液冷重要参数纠正
 * @param  [in] arg 说明
 * @return 
 * @note   
 */
void lc_ctrl_media_imp_param_adjust( void )
{
    if( s_lc_param_adj_enable == false )
        return;

    if(    (s_lc_mb_imp_param.setting.power_on != s_lc_mb_imp_param.read.power_on)
        || (s_lc_mb_imp_param.setting.set_lc_mode != s_lc_mb_imp_param.read.set_lc_mode) 
        || (s_lc_mb_imp_param.setting.set_lc_tmp  != s_lc_mb_imp_param.read.set_lc_tmp) )
    {
        uint16_t mb_reg_wr_vals[ 3 ] ;

        sdk_log_d( "%s", __FUNCTION__);
        mb_reg_wr_vals[ 0 ] = s_lc_mb_imp_param.setting.power_on;
        mb_reg_wr_vals[ 1 ] = s_lc_mb_imp_param.setting.set_lc_mode;
        mb_reg_wr_vals[ 2 ] = s_lc_mb_imp_param.setting.set_lc_tmp;

        app_modbus_registers_write( s_modbus_idx, MODBUS_SLAVE_ADDR, MB_REG_ADDR_SET_POWER_ON , 3, mb_reg_wr_vals, 0 );
    }
}

sf_ret_t lc_ctrl_media_get_lc_cap( lc_cap_t *p_lc_cap )
{
    p_lc_cap->lc_min_tmp       = 50;
    p_lc_cap->lc_max_tmp       = 450;
    p_lc_cap->lc_min_flow      = 60;
    p_lc_cap->lc_max_flow      = 100;
    p_lc_cap->lc_tmp_usr_ctrl  = true;
    p_lc_cap->lc_flow_usr_ctrl = true;

    return SF_OK;
}

static void _lc_ctrl_media_sta_handle( bool power_on, uint16_t *p_status, lc_sta_u *p_lc_sta )
{
    lc_media_sta_u lc_sta = { .value = {0} };
    
    lc_sta.bit.sta.power_on      = power_on;
    lc_sta.bit.sta.pump          = (p_status[0] & BIT(7))? 1: 0;        //< STATUS CODE 10   补液泵
    lc_sta.bit.sta.cool_compress = (p_status[1] & BIT(0))? 1: 0;        //< STATUS CODE 11   压缩机制冷
    lc_sta.bit.sta.env_cool      = (p_status[1] & BIT(1))? 1: 0;        //< STATUS CODE 12   自然冷却 
    lc_sta.bit.sta.heating       = (p_status[1] & BIT(2))? 1: 0;        //< STATUS CODE 13   制热运行 
    lc_sta.bit.sta.water_loop    = (p_status[1] & BIT(3))? 1: 0;        //< STATUS CODE 14   自循环状态

    *p_lc_sta = *(lc_sta_u*)&lc_sta;
}

static void _lc_ctrl_media_warning_handle( uint16_t *p_fault, uint16_t *p_status, lc_warning_u *p_lc_warning )
{
    lc_media_warning_u lc_warn = { .value = {0} };

    lc_warn.bit.warn.other                     =  (p_status[2] & BIT(15) )? 1: 0;    //< WARNING CODE 10 其他故障（总）

    lc_warn.bit.warn.env_sen_fault             =  (p_fault[0] & BIT(0) )? 1: 0;    //< WARNING CODE 11 环境温度传感器故障
    lc_warn.bit.warn.inlet_tmp_sen_fault       =  (p_fault[0] & BIT(1) )? 1: 0;    //< WARNING CODE 12 回水温度传感器故障
    lc_warn.bit.warn.outlet_tmp_sen_fault      =  (p_fault[0] & BIT(2) )? 1: 0;    //< WARNING CODE 13 出水温度传感器故障
    lc_warn.bit.warn.inlet_press_sen_fault     =  (p_fault[0] & BIT(3) )? 1: 0;    //< WARNING CODE 14 回水压力传感器故障
    lc_warn.bit.warn.outlet_press_sen_fault    =  (p_fault[0] & BIT(4) )? 1: 0;    //< WARNING CODE 15 出水压力传感器故障
    lc_warn.bit.warn.ctrl_box_tmp_sen_fault    =  (p_fault[0] & BIT(5) )? 1: 0;    //< WARNING CODE 16 电控盒温度传感器故障
    lc_warn.bit.warn.eeprom_fault              =  (p_fault[0] & BIT(7) )? 1: 0;    //< WARNING CODE 17 EEPROM故障
    lc_warn.bit.warn.clock_fault               =  (p_fault[0] & BIT(8) )? 1: 0;    //< WARNING CODE 18 时钟异常故障
    lc_warn.bit.warn.cool_fan1                 =  (p_fault[1] & BIT(6) )? 1: 0;    //< WARNING CODE 19 散热风扇1告警
    lc_warn.bit.warn.outlet_press_hig          =  (p_fault[1] & BIT(10))? 1: 0;    //< WARNING CODE 20 出水压力过高告警
    lc_warn.bit.warn.inlet_press_low           =  (p_fault[1] & BIT(11))? 1: 0;    //< WARNING CODE 21 回水压力过低告警
    lc_warn.bit.warn.out_tmp_low               =  (p_fault[1] & BIT(12))? 1: 0;    //< WARNING CODE 22 出水低温告警
    lc_warn.bit.warn.out_tmp_hig               =  (p_fault[1] & BIT(13))? 1: 0;    //< WARNING CODE 23 出水高温告警
    lc_warn.bit.warn.sys_exhaust_tmp_sen_fault =  (p_fault[2] & BIT(0) )? 1: 0;    //< WARNING CODE 24 1#排气温度传感器故障
    lc_warn.bit.warn.sys_inhale_tmp_sen_fault  =  (p_fault[2] & BIT(1) )? 1: 0;    //< WARNING CODE 25 1#吸气温度传感器故障
    lc_warn.bit.warn.fan1                      =  (p_fault[6] & BIT(0) )? 1: 0;    //< WARNING CODE 26 风机1故障
    lc_warn.bit.warn.fan2                      =  (p_fault[6] & BIT(1) )? 1: 0;    //< WARNING CODE 27 风机2故障
    lc_warn.bit.warn.fan3                      =  (p_fault[6] & BIT(2) )? 1: 0;    //< WARNING CODE 28 风机3故障

    *p_lc_warning = *(lc_warning_u*)&lc_warn;
}

static void _lc_ctrl_media_fault_handle(  uint16_t *p_fault, uint16_t *p_status, lc_fault_u *p_lc_fault  )
{
    lc_media_fault_u lc_fault = { .value = {0} };

    lc_fault.bit.err.stop_machine   = (p_status[2] & BIT(10))? 1: 0;    //< ERR CODE 10 停整机故障（总）
    lc_fault.bit.err.stop_compress1 = (p_status[2] & BIT(11))? 1: 0;    //< ERR CODE 11 停压缩机1故障（总）
    lc_fault.bit.err.stop_compress2 = (p_status[2] & BIT(12))? 1: 0;    //< ERR CODE 12 停压缩机2故障（总）
    lc_fault.bit.err.stop_heating   = (p_status[2] & BIT(13))? 1: 0;    //< ERR CODE 13 停加热故障（总）
    lc_fault.bit.err.stop_pump      = (p_status[2] & BIT(14))? 1: 0;    //< ERR CODE 14 停水泵故障（总）

    lc_fault.bit.err.inlet_tmp_sen_fault  = (p_fault[0] & BIT(1))? 1: 0;    //< ERR CODE 15      回水温度传感器故障
    lc_fault.bit.err.outlet_tmp_sen_fault = (p_fault[0] & BIT(2))? 1: 0;    //< ERR CODE 16      出水温度传感器故障
    if( (lc_fault.bit.err.outlet_tmp_sen_fault == 0) || (lc_fault.bit.err.inlet_tmp_sen_fault == 0) )
    {
        /** 
         * 若两个水温传感器均报故障，按二级故障处理，停压缩机or电加热 
         * 若只有一个传感器故障，则降低故障等级
         */
        lc_fault.bit.err.outlet_tmp_sen_fault = 0;
        lc_fault.bit.err.inlet_tmp_sen_fault = 0;
    }

    lc_fault.bit.err.inlet_press_sen_fault =  (p_fault[0] & BIT(3))? 1: 0;    //< ERR CODE 17      回水压力传感器故障
    lc_fault.bit.err.outlet_press_sen_fault =  (p_fault[0] & BIT(4))? 1: 0;    //< ERR CODE 18      出水压力传感器故障
    if( (lc_fault.bit.err.inlet_press_sen_fault == 0) || (lc_fault.bit.err.outlet_press_sen_fault == 0) )
    {
        /* 停NULL，若两个水侧压力传感器均故障，按一级故障处理，停整机 
         * 若只有一个故障，则降低故障等级
        */
        lc_fault.bit.err.inlet_press_sen_fault  = 0;
        lc_fault.bit.err.outlet_press_sen_fault = 0;
    }

    lc_fault.bit.err.vol_soc_con_fault                 = (p_fault[0] & BIT(6))?  1: 0;     //< ERR CODE 19     电压检测芯片通信故障
    lc_fault.bit.err.pow_low_vol                       = (p_fault[0] & BIT(9))?  1: 0;     //< ERR CODE 20     电源欠压告警
    lc_fault.bit.err.pow_hig_vol                       = (p_fault[0] & BIT(10))? 1: 0;     //< ERR CODE 21     电源过压告警
    lc_fault.bit.err.pump_fault                        = (p_fault[0] & BIT(12))? 1: 0;     //< ERR CODE 22     水泵故障
    lc_fault.bit.err.heating_tmp_hig_warn              = (p_fault[0] & BIT(13))? 1: 0;     //< ERR CODE 23     电加热高温告警1
    lc_fault.bit.err.monitor_commun_warn               = (p_fault[0] & BIT(15))? 1: 0;     //< ERR CODE 24     监控通信告警

    lc_fault.bit.err.outlet_press_hig                  = (p_fault[1] & BIT(10))? 1: 0;     //< ERR CODE 25     出水压力过高告警
    lc_fault.bit.err.inlet_press_low                   = (p_fault[1] & BIT(11))? 1: 0;     //< ERR CODE 26     回水压力过低告警
    if( (lc_fault.bit.err.inlet_press_sen_fault == 0) || (lc_fault.bit.err.outlet_press_sen_fault == 0) )
    {
        /** 
         * 若两个水侧压力传感器均故障，按一级故障处理，停整机 
         * 若只有一个故障，则降低故障等级
         */
        lc_fault.bit.err.outlet_press_hig              = 0;                                //< ERR CODE 25     出水压力过高告警
        lc_fault.bit.err.inlet_press_low               = 0;                                //< ERR CODE 26     回水压力过低告警
    }

    lc_fault.bit.err.water_low                         = (p_fault[1] & BIT(14))? 1: 0;     //< ERR CODE 27     系统缺水告警
    lc_fault.bit.err.sys_cool_press_sen_fault          = (p_fault[2] & BIT(2))?  1: 0;     //< ERR CODE 28     1#冷凝压力传感器故障
    lc_fault.bit.err.sys_evap_press_sen_fault          = (p_fault[2] & BIT(3))?  1: 0;     //< ERR CODE 29     1#蒸发压力传感器故障
    lc_fault.bit.err.sys_cool_press_hig_warn           = (p_fault[2] & BIT(4))?  1: 0;     //< ERR CODE 30     1#冷凝压力过高告警
    lc_fault.bit.err.sys_cool_press_hig_lock           = (p_fault[2] & BIT(5))?  1: 0;     //< ERR CODE 31     1#冷凝压力过高锁定
    lc_fault.bit.err.sys_evap_press_low                = (p_fault[2] & BIT(6))?  1: 0;     //< ERR CODE 32     1#蒸发压力过低
    lc_fault.bit.err.sys_evap_press_low_lock           = (p_fault[2] & BIT(7) )? 1: 0;     //< ERR CODE 33     1#蒸发压力过低锁定
    lc_fault.bit.err.sys_compress_exhaust_hig_tmp      = (p_fault[2] & BIT(8) )? 1: 0;     //< ERR CODE 34     1#压缩机排气高温
    lc_fault.bit.err.sys_compress_exhaust_hig_tmp_lock = (p_fault[2] & BIT(9) )? 1: 0;     //< ERR CODE 35     1#压缩机排气高温锁定
    lc_fault.bit.err.sys_compress_drv_mod_hig_tmp      = (p_fault[2] & BIT(10))? 1: 0;     //< ERR CODE 36     1#压缩机驱动模块过热
    lc_fault.bit.err.sys_compress_drv_mod_hig_tmp_lock = (p_fault[2] & BIT(11))? 1: 0;     //< ERR CODE 37     1#压缩机电流过高
    lc_fault.bit.err.sys_compress_drv_no_match         = (p_fault[2] & BIT(12))? 1: 0;     //< ERR CODE 38     1#压缩机驱动不匹配
    lc_fault.bit.err.sys_compress_drv_warn             = (p_fault[2] & BIT(13))? 1: 0;     //< ERR CODE 39     1#压缩机驱动告警
    lc_fault.bit.err.sys_compress_drv_com_fault        = (p_fault[2] & BIT(14))? 1: 0;     //< ERR CODE 40     1#压缩机驱动通信故障
    lc_fault.bit.err.sys_compress_drv_com_fault_lock   = (p_fault[2] & BIT(15))? 1: 0;     //< ERR CODE 41     1#压缩机驱动锁定告警
    lc_fault.bit.err.sys_compress_eev_drv_warn         = (p_fault[3] & BIT(0) )? 1: 0;     //< ERR CODE 42     1#EEV驱动告警
    lc_fault.bit.err.sys_eev_tmp                       = (p_fault[3] & BIT(2) )? 1: 0;     //< ERR CODE 43     1#EEV低过热度告警
    lc_fault.bit.err.sys_eev_tmp_lock                  = (p_fault[3] & BIT(3) )? 1: 0;     //< ERR CODE 44     1#EEV低过热度锁定告警
    lc_fault.bit.err.sys_compress_inv_tmp_sen_fault    = (p_fault[3] & BIT(4) )? 1: 0;     //< ERR CODE 45     1#压缩机逆变温度传感器故障
    lc_fault.bit.err.sys_hig_vol_sw_warn               = (p_fault[3] & BIT(5) )? 1: 0;     //< ERR CODE 46     1#高压开关告警
    lc_fault.bit.err.sys_hig_vol_sw_warn_lock          = (p_fault[3] & BIT(6) )? 1: 0;     //< ERR CODE 47     1#高压开关锁定告警
    lc_fault.bit.err.sys_cool_protect                  = (p_fault[3] & BIT(7) )? 1: 0;     //< ERR CODE 48     1#防冻结保护

    *p_lc_fault = *(lc_fault_u*)&lc_fault;
}

