#ifndef __LC_TYPE_MEDIA_H__
#define __LC_TYPE_MEDIA_H__

#include "data_types.h"

/* 美的液冷机组 */
typedef struct {
    uint16_t total_err_code: 1;                       //< 总故障
    uint16_t offline: 1;                              //< 离线 error code 1
    uint16_t E2_9:8;                                  //< 预留

    uint16_t stop_machine: 1;                         //< error code 10  停整机故障（总）
    uint16_t stop_compress1: 1;                       //< error code 11  停压缩机1故障（总）
    uint16_t stop_compress2: 1;                       //< error code 12  停压缩机2故障（总）
    uint16_t stop_heating: 1;                         //< error code 13  停加热故障（总）
    uint16_t stop_pump: 1;                            //< error code 14  停水泵故障（总）
    uint16_t inlet_tmp_sen_fault: 1;                  //< error code 15  回水温度传感器故障
    uint16_t outlet_tmp_sen_fault: 1;                 //< error code 16  出水温度传感器故障
    uint16_t inlet_press_sen_fault: 1;                //< error code 17  回水压力传感器故障
    uint16_t outlet_press_sen_fault: 1;               //< error code 18  出水压力传感器故障
    uint16_t vol_soc_con_fault: 1;                    //< error code 19  电压检测芯片通信故障
    uint16_t pow_low_vol: 1;                          //< error code 20  电源欠压告警
    uint16_t pow_hig_vol: 1;                          //< error code 21  电源过压告警
    uint16_t pump_fault: 1;                           //< error code 22  水泵故障
    uint16_t heating_tmp_hig_warn: 1;                 //< error code 23  电加热高温告警1
    uint16_t monitor_commun_warn: 1;                  //< error code 24  监控通信告警
    uint16_t outlet_press_hig: 1;                     //< error code 25  出水压力过高告警
    uint16_t inlet_press_low: 1;                      //< error code 26  回水压力过低告警
    uint16_t water_low: 1;                            //< error code 27  系统缺水告警
    uint16_t sys_cool_press_sen_fault: 1;             //< error code 28  1#冷凝压力传感器故障
    uint16_t sys_evap_press_sen_fault: 1;             //< error code 29  1#蒸发压力传感器故障
    uint16_t sys_cool_press_hig_warn: 1;              //< error code 30  1#冷凝压力过高告警
    uint16_t sys_cool_press_hig_lock: 1;              //< error code 31  1#冷凝压力过高锁定
    uint16_t sys_evap_press_low: 1;                   //< error code 32  1#蒸发压力过低
    uint16_t sys_evap_press_low_lock: 1;              //< error code 33  1#蒸发压力过低锁定
    uint16_t sys_compress_exhaust_hig_tmp: 1;         //< error code 34  1#压缩机排气高温
    uint16_t sys_compress_exhaust_hig_tmp_lock: 1;    //< error code 35  1#压缩机排气高温锁定
    uint16_t sys_compress_drv_mod_hig_tmp: 1;         //< error code 36  1#压缩机驱动模块过热
    uint16_t sys_compress_drv_mod_hig_tmp_lock: 1;    //< error code 37  1#压缩机电流过高
    uint16_t sys_compress_drv_no_match: 1;            //< error code 38  1#压缩机驱动不匹配
    uint16_t sys_compress_drv_warn: 1;                //< error code 39  1#压缩机驱动告警
    uint16_t sys_compress_drv_com_fault: 1;           //< error code 40  1#压缩机驱动通信故障
    uint16_t sys_compress_drv_com_fault_lock: 1;      //< error code 41  1#压缩机驱动锁定告警
    uint16_t sys_compress_eev_drv_warn: 1;            //< error code 42  1#EEV驱动告警
    uint16_t sys_eev_tmp: 1;                          //< error code 43  1#EEV低过热度告警
    uint16_t sys_eev_tmp_lock: 1;                     //< error code 44  1#EEV低过热度锁定告警
    uint16_t sys_compress_inv_tmp_sen_fault: 1;       //< error code 45  1#压缩机逆变温度传感器故障
    uint16_t sys_hig_vol_sw_warn: 1;                  //< error code 46  1#高压开关告警
    uint16_t sys_hig_vol_sw_warn_lock: 1;             //< error code 47  1#高压开关锁定告警
    uint16_t sys_cool_protect: 1;                     //< error code 48  1#防冻结保护
    uint16_t sys1_err: 1;                             //< error code 49  系统1错误
    uint16_t sys2_err: 1;                             //< error code 50  系统2错误
} lc_media_fault_t;

typedef struct {
    uint16_t total_warning_code: 1;
    uint16_t W1_9:9;                                  //< 预留

    uint16_t other: 1;                                //< WARNING CODE 10  其他故障（总）
    uint16_t env_sen_fault: 1;                        //< WARNING CODE 11  环境温度传感器故障
    uint16_t inlet_tmp_sen_fault: 1;                  //< WARNING CODE 12  回水温度传感器故障
    uint16_t outlet_tmp_sen_fault: 1;                 //< WARNING CODE 13  出水温度传感器故障
    uint16_t inlet_press_sen_fault: 1;                //< WARNING CODE 14  回水压力传感器故障
    uint16_t outlet_press_sen_fault: 1;               //< WARNING CODE 15  出水压力传感器故障
    uint16_t ctrl_box_tmp_sen_fault: 1;               //< WARNING CODE 16  电控盒温度传感器故障
    uint16_t eeprom_fault: 1;                         //< WARNING CODE 17  EEPROM故障
    uint16_t clock_fault: 1;                          //< WARNING CODE 18  时钟异常故障
    uint16_t cool_fan1: 1;                            //< WARNING CODE 19  散热风扇1告警
    uint16_t outlet_press_hig: 1;                     //< WARNING CODE 20  出水压力过高告警
    uint16_t inlet_press_low: 1;                      //< WARNING CODE 21  回水压力过低告警
    uint16_t out_tmp_low: 1;                          //< WARNING CODE 22  出水低温告警
    uint16_t out_tmp_hig: 1;                          //< WARNING CODE 23  出水高温告警
    uint16_t sys_exhaust_tmp_sen_fault: 1;            //< WARNING CODE 24  1#排气温度传感器故障
    uint16_t sys_inhale_tmp_sen_fault: 1;             //< WARNING CODE 25  1#吸气温度传感器故障
    uint16_t fan1: 1;                                 //< WARNING CODE 26  风机1故障
    uint16_t fan2: 1;                                 //< WARNING CODE 27  风机2故障
    uint16_t fan3: 1;                                 //< WARNING CODE 28  风机3故障
} lc_media_warning_t;

typedef struct {
    uint16_t power_on: 1;           //< STATUS CODE 0  液冷启停状态
    uint16_t reserve: 9;            //< STATUS CODE 1-9   
    
    uint16_t pump: 1;              //< STATUS CODE 10   补液泵
    uint16_t cool_compress: 1;     //< STATUS CODE 11   压缩机制冷
    uint16_t env_cool: 1;          //< STATUS CODE 12   自然冷却 
    uint16_t heating: 1;           //< STATUS CODE 13   制热运行 
    uint16_t water_loop: 1;        //< STATUS CODE 14   自循环状态
} lc_media_sta_t;

typedef union
{
    uint16_t value[4];
    union{
        lc_media_fault_t  err;
    }bit;
} lc_media_fault_u;

typedef union{
    uint16_t value[4];
    union{
        lc_media_warning_t  warn;
    }bit;
} lc_media_warning_u;

typedef union{
    uint16_t value[2];
    union{
        lc_media_sta_t  sta;
    }bit;
} lc_media_sta_u;

#endif
