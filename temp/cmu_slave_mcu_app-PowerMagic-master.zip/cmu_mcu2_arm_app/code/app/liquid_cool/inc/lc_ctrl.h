#ifndef __LC_CTRL_H__
#define __LC_CTRL_H__

#include "lc_data_type.h"
#include "sofar_type.h"
typedef struct {
    lc_type_e           lc_type;                         // 液冷机组型号  0:美的 1:空调国际 2:视源
    bool                lc_auto_mode;                    // 手自模式 0:手动  1：自动
    lc_work_mode_e      lc_mode;                         // 模式设置 0：待机 1：制热 2：制冷 3：自循环
    lc_tmp_ctrl_mode_e  lc_ctrl_mode;                    // 控制方式 0：出水 1：回水
    flow_t              lc_pump_rate;                    // 水泵转速设定 单位：1%
    temper_t            lc_cooling_point;                // 制冷温度设定 单位：0.1℃ 
    temper_t            lc_cooling_drop;                 // 制冷回差 单位：0.1℃ 
    temper_t            lc_heating_point;                // 制热温度设定 单位：0.1℃ 
    temper_t            lc_heating_drop;                 // 制热回差 单位：0.1℃ 
    temper_t            lc_cool_outlet_low_tmp;          // 制冷出水低温告警设定 单位：0.1℃ 
    temper_t            lc_heat_outlet_hig_tmp;          // 制热出水高温告警设定 单位：0.1℃ 
    kpa_t               lc_outlet_pressure_high;         // 出水压力过高设定点 单位：bar = 0.1Mpa = 100Kpa
    kpa_t               lc_inlet_pressure_low;           // 回水压力过低设定点 单位：bar = 0.1Mpa = 100Kpa
} lc_ctrl_setting_t;

typedef struct  {
    lc_type_e       lc_type;                // 液冷机组型号
    flow_t          lc_flow;                // 液冷机组流量
    flow_t          lc_dst_tmp;             // 液冷机组供液目标温度
    temper_t        outdoor_temper;         // 室外环境温度
    temper_t        inlet_temper;           // 进水温度
    temper_t        outlet_temper;          // 出水温度
    kpa_t           inlet_pressure;         // 进水压力
    kpa_t           outlet_pressure;        // 出水压力
    lc_work_mode_e  work_mode;              // 液冷运行模式
    lc_sta_u        sta;                    // 状态 
    lc_warning_u    warn;                   // 告警 【不会导致停机，不影响运行】
    lc_fault_u      fault;                  // 错误 【会导致停机，影响运行】
} lc_dat_t;

/**
 * @brief  液冷上线离线回调函数原型
 * @param  [in] online：在线状态
 */
typedef void (*lc_online_change_callback)( bool online );
/**
 * @brief  液冷运行参数变化通知回调函数原型
 * @param  [in] p_lc_dat：液冷数据内容
 */
typedef void (*lc_dat_update_callback)( lc_dat_t *p_lc_dat );

/**
 * @brief  液冷机组初始化
 * @param  [in] modbus_idx modbus索引
 * @param  [in] online_cb 上线离线回调（可选）
 * @param  [in] update_cb 液冷运行数据的变化通知（可选）
 * @return SF_OK：成功  小于SF_OK: 失败
 */
sf_ret_t lc_ctrl_init( modbus_idx_t modbus_idx, lc_online_change_callback online_cb, lc_dat_update_callback update_cb );

/**
 * @brief  液冷机组设置参数
 * @param  [in] p_lc_ctrl_setting ：设置参数
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
sf_ret_t lc_ctrl_set_param( lc_ctrl_setting_t *p_lc_ctrl_setting );

/**
 * @brief  液冷机组设置供液流量
 * @param  [in] lc_flow 流量
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
sf_ret_t lc_ctrl_set_flow( flow_t lc_flow );

/**
 * @brief  液冷机组制冷温度设定
 * @param  [in] lc_cool_tmp ：液冷制冷设点温度
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
sf_ret_t lc_ctrl_set_cool_temper( temper_t lc_cool_tmp );

/**
 * @brief  液冷机组制热温度设定
 * @param  [in] lc_heat_tmp ：液冷制热设点温度
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
sf_ret_t lc_ctrl_set_heat_temper( temper_t lc_heat_tmp );

/**
 * @brief  液冷机组设置工作模式
 * @param  [in] lc_work_mode ： 工作模式
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
sf_ret_t lc_ctrl_set_work_mode( lc_work_mode_e lc_work_mode );

/**
 * @brief  液冷机组设置开关机
 * @param  [in] power_on ：开关机
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
sf_ret_t lc_ctrl_set_power_on( bool power_on );

/**
 * @brief  液冷机组获取液冷数据
 * @param  [in] p_lc_dat ：液冷数据
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
sf_ret_t lc_ctrl_get_lc_dat( lc_dat_t *p_lc_dat );

/**
 * @brief  液冷机组获取液冷能力
 * @param  [in] p_lc_cap ：液冷能力
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
sf_ret_t lc_ctrl_get_lc_cap( lc_cap_t *p_lc_cap );

/**
 * @brief  获取当前液冷机组通讯丢包率
 * @param  [in] 无
 * @return 返回丢包率
 * @note   
 */
rate_t lc_ctrl_get_com_loss_rate( void );

/**
 * @brief  液冷机组获取在线状态
 * @param  [in] 
 * @return true:在线  false：离线
 * @note   
 */
bool lc_ctrl_get_online( void );

/**
 * @brief  液冷机组控制任务调度【外部线程使用】
 * @param  [in] 无 
 * @return 无
 * @note   
 */
void lc_ctrl_task_loop( void );


#endif
