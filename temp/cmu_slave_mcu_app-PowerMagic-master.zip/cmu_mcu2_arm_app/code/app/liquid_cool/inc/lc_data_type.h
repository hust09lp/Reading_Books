#ifndef __LC_COMMON_H__
#define __LC_COMMON_H__

#include "sofar_type.h"

/* 精度0.1℃ */
typedef usr_int16_t temper_t;
/* 精度 1%，范围 -100% ~ 100% */
typedef usr_int16_t flow_t;
/* 精度 1Kpa */
typedef usr_int16_t kpa_t;
/* 精度 1bar */
typedef usr_int16_t bar_t;


/* 液冷机型 */
typedef enum {
    LC_TYPE_MEDIA = 0,                      //< 美的
    LC_TYPE_AINE = 1,                       //< 空调国际
    LC_TYPE_CVTE = 2,                       //< 视源
    LC_TYPE_NUM ,                       
    LC_TYPE_MAX = LC_TYPE_NUM,
} lc_type_e;

typedef enum {
    LC_WORK_MODE_STANDBY = 0,               //< 待机
    LC_WORK_MODE_HEAT = 1,                  //< 制热
    LC_WORK_MODE_COOL = 2,                  //< 制冷
    LC_WORK_MODE_WATER_LOOP = 3,            //< 自循环
    LC_WORK_MODE_MAX,           
    LC_WORK_MODE_INVALID = 0xff,                 
} lc_work_mode_e;

typedef enum {
    LC_TMP_CTRL_MODE_OUTLET = 0,            //< 出水控制
    LC_TMP_CTRL_MODE_INLET = 1,             //< 回水控制
}lc_tmp_ctrl_mode_e;

typedef struct {
    lc_work_mode_e  lc_sta;
    temper_t        lc_temper;
    flow_t          lc_flow;
} lc_ctrl_t;

typedef struct {
    bool      lc_tmp_usr_ctrl;              //< 是否支持液冷温度调节
    temper_t  lc_min_tmp;                   //< 液冷最小温度
    temper_t  lc_max_tmp;                   //< 液冷最大温度
    bool      lc_flow_usr_ctrl;             //< 是否支持液冷流量调节
    flow_t    lc_min_flow;                  //< 液冷 最小流量
    flow_t    lc_max_flow;                  //< 液冷 最大流量
} lc_cap_t;

typedef struct {
    uint16_t total_err_code: 1;         //< 总故障标志位
    uint16_t err_code1_offline: 1;      //< ERR CODE1 液冷离线  
    uint16_t err_code2: 1;              //< ERR CODE 2  
    uint16_t err_code3: 1;              //< ERR CODE 3  
    uint16_t err_code4: 1;              //< ERR CODE 4  
    uint16_t err_code5: 1;              //< ERR CODE 5  
    uint16_t err_code6: 1;              //< ERR CODE 6  
    uint16_t err_code7: 1;              //< ERR CODE 7  
    uint16_t err_code8: 1;              //< ERR CODE 8  
    uint16_t err_code9: 1;              //< ERR CODE 9  

    uint16_t err_code10: 1;     //< ERR CODE 10 
    uint16_t err_code11: 1;     //< ERR CODE 11 
    uint16_t err_code12: 1;     //< ERR CODE 12 
    uint16_t err_code13: 1;     //< ERR CODE 13 
    uint16_t err_code14: 1;     //< ERR CODE 14 
    uint16_t err_code15: 1;     //< ERR CODE 15 
    uint16_t err_code16: 1;     //< ERR CODE 16 
    uint16_t err_code17: 1;     //< ERR CODE 17 
    uint16_t err_code18: 1;     //< ERR CODE 18 
    uint16_t err_code19: 1;     //< ERR CODE 19 
    uint16_t err_code20: 1;     //< ERR CODE 20 
    uint16_t err_code21: 1;     //< ERR CODE 21 
    uint16_t err_code22: 1;     //< ERR CODE 22 
    uint16_t err_code23: 1;     //< ERR CODE 23 
    uint16_t err_code24: 1;     //< ERR CODE 24 
    uint16_t err_code25: 1;     //< ERR CODE 25 
    uint16_t err_code26: 1;     //< ERR CODE 26 
    uint16_t err_code27: 1;     //< ERR CODE 27 
    uint16_t err_code28: 1;     //< ERR CODE 28 
    uint16_t err_code29: 1;     //< ERR CODE 29 
    uint16_t err_code30: 1;     //< ERR CODE 30 
    uint16_t err_code31: 1;     //< ERR CODE 31 
    uint16_t err_code32: 1;     //< ERR CODE 32 
    uint16_t err_code33: 1;     //< ERR CODE 33 
    uint16_t err_code34: 1;     //< ERR CODE 34 
    uint16_t err_code35: 1;     //< ERR CODE 35 
    uint16_t err_code36: 1;     //< ERR CODE 36 
    uint16_t err_code37: 1;     //< ERR CODE 37 
    uint16_t err_code38: 1;     //< ERR CODE 38 
    uint16_t err_code39: 1;     //< ERR CODE 39 
    uint16_t err_code40: 1;     //< ERR CODE 40 
    uint16_t err_code41: 1;     //< ERR CODE 41 
    uint16_t err_code42: 1;     //< ERR CODE 42 
    uint16_t err_code43: 1;     //< ERR CODE 43 
    uint16_t err_code44: 1;     //< ERR CODE 44 
    uint16_t err_code45: 1;     //< ERR CODE 45 
    uint16_t err_code46: 1;     //< ERR CODE 46 
    uint16_t err_code47: 1;     //< ERR CODE 47 
    uint16_t err_code48: 1;     //< ERR CODE 48 
    uint16_t err_code49: 1;     //< ERR CODE 49 
    uint16_t err_code50: 1;     //< ERR CODE 50 
    uint16_t err_code51: 1;     //< ERR CODE 51 
    uint16_t err_code52: 1;     //< ERR CODE 52 
    uint16_t err_code53: 1;     //< ERR CODE 53 
    uint16_t err_code54: 1;     //< ERR CODE 54 
    uint16_t err_code55: 1;     //< ERR CODE 55 
    uint16_t err_code56: 1;     //< ERR CODE 56 
    uint16_t err_code57: 1;     //< ERR CODE 57 
    uint16_t err_code58: 1;     //< ERR CODE 58 
    uint16_t err_code59: 1;     //< ERR CODE 59 
    uint16_t err_code60: 1;     //< ERR CODE 60 
    uint16_t err_code61: 1;     //< ERR CODE 61 
    uint16_t err_code62: 1;     //< ERR CODE 62 
    uint16_t err_code63: 1;     //< ERR CODE 63 
} lc_fault_t;


typedef struct {
    uint16_t total_warning_code: 1; //< 总警告标志位
    uint16_t warning_code1: 1;      //< WARNING CODE 1 
    uint16_t warning_code2: 1;      //< WARNING CODE 2  
    uint16_t warning_code3: 1;      //< WARNING CODE 3  
    uint16_t warning_code4: 1;      //< WARNING CODE 4  
    uint16_t warning_code5: 1;      //< WARNING CODE 5  
    uint16_t warning_code6: 1;      //< WARNING CODE 6  
    uint16_t warning_code7: 1;      //< WARNING CODE 7  
    uint16_t warning_code8: 1;      //< WARNING CODE 8  
    uint16_t warning_code9: 1;      //< WARNING CODE 9  
    uint16_t warning_code10: 1;     //< WARNING CODE 10 
    uint16_t warning_code11: 1;     //< WARNING CODE 11 
    uint16_t warning_code12: 1;     //< WARNING CODE 12 
    uint16_t warning_code13: 1;     //< WARNING CODE 13 
    uint16_t warning_code14: 1;     //< WARNING CODE 14 
    uint16_t warning_code15: 1;     //< WARNING CODE 15 
    uint16_t warning_code16: 1;     //< WARNING CODE 16 
    uint16_t warning_code17: 1;     //< WARNING CODE 17 
    uint16_t warning_code18: 1;     //< WARNING CODE 18 
    uint16_t warning_code19: 1;     //< WARNING CODE 19 
    uint16_t warning_code20: 1;     //< WARNING CODE 20 
    uint16_t warning_code21: 1;     //< WARNING CODE 21 
    uint16_t warning_code22: 1;     //< WARNING CODE 22 
    uint16_t warning_code23: 1;     //< WARNING CODE 23 
    uint16_t warning_code24: 1;     //< WARNING CODE 24 
    uint16_t warning_code25: 1;     //< WARNING CODE 25 
    uint16_t warning_code26: 1;     //< WARNING CODE 26 
    uint16_t warning_code27: 1;     //< WARNING CODE 27 
    uint16_t warning_code28: 1;     //< WARNING CODE 28 
    uint16_t warning_code29: 1;     //< WARNING CODE 29 
    uint16_t warning_code30: 1;     //< WARNING CODE 30 
    uint16_t warning_code31: 1;     //< WARNING CODE 31 
    uint16_t warning_code32: 1;     //< WARNING CODE 32 
    uint16_t warning_code33: 1;     //< WARNING CODE 33 
    uint16_t warning_code34: 1;     //< WARNING CODE 34 
    uint16_t warning_code35: 1;     //< WARNING CODE 35 
    uint16_t warning_code36: 1;     //< WARNING CODE 36 
    uint16_t warning_code37: 1;     //< WARNING CODE 37 
    uint16_t warning_code38: 1;     //< WARNING CODE 38 
    uint16_t warning_code39: 1;     //< WARNING CODE 39 
    uint16_t warning_code40: 1;     //< WARNING CODE 40 
    uint16_t warning_code41: 1;     //< WARNING CODE 41 
    uint16_t warning_code42: 1;     //< WARNING CODE 42 
    uint16_t warning_code43: 1;     //< WARNING CODE 43 
    uint16_t warning_code44: 1;     //< WARNING CODE 44 
    uint16_t warning_code45: 1;     //< WARNING CODE 45 
    uint16_t warning_code46: 1;     //< WARNING CODE 46 
    uint16_t warning_code47: 1;     //< WARNING CODE 47 
    uint16_t warning_code48: 1;     //< WARNING CODE 48 
    uint16_t warning_code49: 1;     //< WARNING CODE 49 
    uint16_t warning_code50: 1;     //< WARNING CODE 50 
    uint16_t warning_code51: 1;     //< WARNING CODE 51 
    uint16_t warning_code52: 1;     //< WARNING CODE 52 
    uint16_t warning_code53: 1;     //< WARNING CODE 53 
    uint16_t warning_code54: 1;     //< WARNING CODE 54 
    uint16_t warning_code55: 1;     //< WARNING CODE 55 
    uint16_t warning_code56: 1;     //< WARNING CODE 56 
    uint16_t warning_code57: 1;     //< WARNING CODE 57 
    uint16_t warning_code58: 1;     //< WARNING CODE 58 
    uint16_t warning_code59: 1;     //< WARNING CODE 59 
    uint16_t warning_code60: 1;     //< WARNING CODE 60 
    uint16_t warning_code61: 1;     //< WARNING CODE 61 
    uint16_t warning_code62: 1;     //< WARNING CODE 62 
    uint16_t warning_code63: 1;     //< WARNING CODE 63 
} lc_warning_t;

typedef struct {
    uint16_t sta_code0_power_on: 1; //< STATUS CODE 0  液冷启停状态
    uint16_t sta_code1: 1;          //< STATUS CODE 1  
    uint16_t sta_code2: 1;          //< STATUS CODE 2  
    uint16_t sta_code3: 1;          //< STATUS CODE 3  
    uint16_t sta_code4: 1;          //< STATUS CODE 4  
    uint16_t sta_code5: 1;          //< STATUS CODE 5  
    uint16_t sta_code6: 1;          //< STATUS CODE 6  
    uint16_t sta_code7: 1;          //< STATUS CODE 7  
    uint16_t sta_code8: 1;          //< STATUS CODE 8  
    uint16_t sta_code9: 1;          //< STATUS CODE 9  
    uint16_t sta_code10: 1;         //< STATUS CODE 10 
    uint16_t sta_code11: 1;         //< STATUS CODE 11 
    uint16_t sta_code12: 1;         //< STATUS CODE 12 
    uint16_t sta_code13: 1;         //< STATUS CODE 13 
    uint16_t sta_code14: 1;         //< STATUS CODE 14 
    uint16_t sta_code15: 1;         //< STATUS CODE 15 
    uint16_t sta_code16: 1;         //< STATUS CODE 16 
    uint16_t sta_code17: 1;         //< STATUS CODE 17 
    uint16_t sta_code18: 1;         //< STATUS CODE 18 
    uint16_t sta_code19: 1;         //< STATUS CODE 19 
    uint16_t sta_code20: 1;         //< STATUS CODE 20 
    uint16_t sta_code21: 1;         //< STATUS CODE 21 
    uint16_t sta_code22: 1;         //< STATUS CODE 22 
    uint16_t sta_code23: 1;         //< STATUS CODE 23 
    uint16_t sta_code24: 1;         //< STATUS CODE 24 
    uint16_t sta_code25: 1;         //< STATUS CODE 25 
    uint16_t sta_code26: 1;         //< STATUS CODE 26 
    uint16_t sta_code27: 1;         //< STATUS CODE 27 
    uint16_t sta_code28: 1;         //< STATUS CODE 28 
    uint16_t sta_code29: 1;         //< STATUS CODE 29 
    uint16_t sta_code30: 1;         //< STATUS CODE 30 
    uint16_t sta_code31: 1;         //< STATUS CODE 31 
} lc_sta_t;

typedef union{
    uint16_t array[4];
    uint64_t value;
    union{
        lc_fault_t  err;
    }bit;
} lc_fault_u;

typedef union{
    uint16_t array[4];
    uint64_t value;
    union{
        lc_warning_t  warn;
    }bit;
} lc_warning_u;

typedef union{
    uint16_t array[2];
    uint32_t value;
    union{
        lc_sta_t  sta;
    }bit;
} lc_sta_u;


#endif
