#ifndef __LC_TYPE_AINE_H__
#define __LC_TYPE_AINE_H__

#include "data_types.h"

/* 空调国际液冷机组 */

typedef struct {
    uint16_t total_err_code: 1;
    uint16_t offline: 1;                            //< 离线 error code 1
    uint16_t E2_9:8;                                //< 预留

    uint16_t HCM_com_fault: 1;                      //< ERR CODE 10  485模块和HCM通信故障
    uint16_t hig_vol_sw_fault: 1;                   //< ERR CODE 11  高压接触器故障
    uint16_t k2_sw_fault: 1;                        //< ERR CODE 12  K2接触器故障
    uint16_t ADC_A_vol_low: 1;                      //< ERR CODE 13  ACDC_A_过欠压故障
    uint16_t ADC_A_fault: 1;                        //< ERR CODE 14  ACDC_A_自身故障
    uint16_t fan_fault: 1;                          //< ERR CODE 15  风机故障
    uint16_t hig_press_sen_fault: 1;                //< ERR CODE 16  高压传感器故障
    uint16_t too_hig_press: 1;                      //< ERR CODE 17  高压过高
    uint16_t low_press_sen_fault: 1;                //< ERR CODE 18  低压传感器故障
    uint16_t too_low_press: 1;                      //< ERR CODE 19  低压过低
    uint16_t outlen_tmp_sen_fault: 1;               //< ERR CODE 20  出水温度传感器故障
    uint16_t inlen_tmp_sen_fault: 1;                //< ERR CODE 21  进水温度传感器故障
    uint16_t pump_fault: 1;                         //< ERR CODE 22  水泵故障
    uint16_t evn_tmp_sen_fault: 1;                  //< ERR CODE 23  环境温度传感器故障
    uint16_t ac_con_fail: 1;                        //< ERR CODE 24  AC通讯丢失故障
    uint16_t ac_compress_fault: 1;                  //< ERR CODE 25  AC压缩机控制器故障
    uint16_t ptc_hig_tmp: 1;                        //< ERR CODE 26  PTC过温故障
    uint16_t hig_press_sw_fault: 1;                 //< ERR CODE 27  高压压力开关故障
} lc_aine_fault_t;

typedef struct {
    uint16_t total_warning_code: 1;                 //< 总告警标志位
    uint16_t W1_9:9;                                //< 预留

    uint16_t inlet_press_sen_fault: 1;              //< WARNING CODE 10  进水水压传感器故障
    uint16_t outlet_press_sen_fault: 1;             //< WARNING CODE 11  出水水压传感器故障
    uint16_t out_inlet_press_delta_fault: 1;        //< WARNING CODE 12  进出水压差故障
} lc_aine_warning_t;

typedef struct {
    uint16_t power_on: 1;                           //< STATUS CODE 0  液冷启停状态
    uint16_t reserve: 9;                            //< STATUS CODE 1-9   

    uint16_t power_on_sta: 1;                       //< STATUS CODE 10  开关状态
    uint16_t pump_sta: 1;                           //< STATUS CODE 11  水泵状态
    uint16_t compress_sta: 1;                       //< STATUS CODE 12  压缩机状态
} lc_aine_sta_t;

typedef union{
    uint16_t array[4];
    uint64_t value;
    union{
        lc_aine_fault_t  err;
    }bit;
} lc_aine_fault_u;

typedef union{
    uint16_t array[4];
    uint64_t value;
    union{
        lc_aine_warning_t  warn;
    }bit;
} lc_aine_warning_u;

typedef union{
    uint16_t array[2];
    uint32_t value;
    union{
        lc_aine_sta_t  sta;
    }bit;
} lc_aine_sta_u;


#endif
