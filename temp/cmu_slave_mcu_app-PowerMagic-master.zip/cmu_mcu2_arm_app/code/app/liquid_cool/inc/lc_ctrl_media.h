#ifndef __LC_CTRL_MEDIA_H__
#define __LC_CTRL_MEDIA_H__

#include "lc_ctrl.h"

extern sf_ret_t lc_ctrl_media_init( modbus_idx_t modbus_idx );
extern sf_ret_t lc_ctrl_media_deinit( void );
extern sf_ret_t lc_ctrl_media_set_param( lc_ctrl_setting_t *p_lc_ctrl_setting );
extern sf_ret_t lc_ctrl_media_set_flow( flow_t lc_flow );
extern sf_ret_t lc_ctrl_media_set_cool_temper( temper_t lc_cool_tmp );
extern sf_ret_t lc_ctrl_media_set_heat_temper( temper_t lc_heat_tmp );
extern sf_ret_t lc_ctrl_media_set_work_mode( lc_work_mode_e lc_work_mode );
extern sf_ret_t lc_ctrl_media_set_power_on( bool power_on );
extern sf_ret_t lc_ctrl_media_get_lc_dat( lc_dat_t *p_lc_dat );
extern sf_ret_t lc_ctrl_media_get_lc_cap( lc_cap_t *p_lc_cap );
extern void lc_ctrl_media_adjust_set( bool enable );

#endif
