#ifndef __LC_TYPE_CVTE_H__
#define __LC_TYPE_CVTE_H__

#include "data_types.h"

/* 空调国际液冷机组 */

typedef struct {
    uint64_t total_err_code: 1;
    uint64_t err_code1: 1;      //< ERR CODE 1   高压压力传感器1故障
    uint64_t err_code2: 1;      //< ERR CODE 2   冷凝温度1过高告警
    uint64_t err_code3: 1;      //< ERR CODE 3   冷凝温度1过高锁定
    uint64_t err_code4: 1;      //< ERR CODE 4   蒸发温度1过低告警
    uint64_t err_code5: 1;      //< ERR CODE 5   蒸发温度1过低锁定
    uint64_t err_code6: 1;      //< ERR CODE 6   排气温度1过高告警
    uint64_t err_code7: 1;      //< ERR CODE 7   压缩机1AC电流过高告警
    uint64_t err_code8: 1;      //< ERR CODE 8   压缩机1驱动故障告警
    uint64_t err_code9: 1;      //< ERR CODE 9   压缩机1驱动故障锁定
    uint64_t err_code10: 1;     //< ERR CODE 10  水泵压差高锁定
    uint64_t err_code11: 1;     //< ERR CODE 11  水泵压差低锁定
    uint64_t err_code12: 1;     //< ERR CODE 12  水泵压差高告警
    uint64_t err_code13: 1;     //< ERR CODE 13  水泵压差低告警
    uint64_t err_code14: 1;     //< ERR CODE 14  水泵驱动故障告警
    uint64_t err_code15: 1;     //< ERR CODE 15  水泵驱动故障锁定
    uint64_t err_code16: 1;     //< ERR CODE 16  交流电压告警
    uint64_t err_code17: 1;     //< ERR CODE 17  外接告警
} lc_cvte_fault_t;

typedef struct {
    uint64_t total_warning_code: 1;
    uint64_t warning_code1: 1;      //< WARNING CODE 1    吸气温度传感器1故障
    uint64_t warning_code2: 1;      //< WARNING CODE 2    排气温度传感器1故障
    uint64_t warning_code3: 1;      //< WARNING CODE 3    液管温度传感器1故障
    uint64_t warning_code4: 1;      //< WARNING CODE 4    低压压力传感器1故障
    uint64_t warning_code5: 1;      //< WARNING CODE 5    蒸发温度1过高告警
    uint64_t warning_code6: 1;      //< WARNING CODE 6    压缩机1通讯故障
    uint64_t warning_code7: 1;      //< WARNING CODE 7    水温过高告警
    uint64_t warning_code8: 1;      //< WARNING CODE 8    水温过低告警
    uint64_t warning_code9: 1;      //< WARNING CODE 9    环境温度传感器故障
    uint64_t warning_code10: 1;     //< WARNING CODE 10   出水温度传感器故障
    uint64_t warning_code11: 1;     //< WARNING CODE 11   进水温度传感器故障
    uint64_t warning_code12: 1;     //< WARNING CODE 12   出水压力传感器故障
    uint64_t warning_code13: 1;     //< WARNING CODE 13   进水压力传感器故障
    uint64_t warning_code14: 1;     //< WARNING CODE 14   水泵通讯故障
    uint64_t warning_code15: 1;     //< WARNING CODE 15   上位机通讯故障
    uint64_t warning_code16: 1;     //< WARNING CODE 16   显示器通讯故障
} lc_cvte_warning_t;

typedef struct {
    uint32_t sta_code0: 1;          //< STATUS CODE 0
    uint32_t sta_code1: 1;          //< STATUS CODE 1   风机1状态
    uint32_t sta_code2: 1;          //< STATUS CODE 2   风机2状态
    uint32_t sta_code3: 1;          //< STATUS CODE 3   风机3状态
    uint32_t sta_code4: 1;          //< STATUS CODE 4   压缩机状态
} lc_cvte_sta_t;

#endif
