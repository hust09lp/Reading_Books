#include "extern_io.h"
// #include "temper_humi.h"
#include "dh_ctrl.h"
#include "lc_ctrl.h"

#include "sci_frame.h"
#include "app_dido.h"
#include "app_modbus.h"
#include "app_cfg.h"
#include "fire_fighting2.h"

#include "sdk.h"
#include "sdk_core.h"

/**
  * @brief  储能柜相关信息
  */
typedef struct {
    dev_di_sta_info_u di_sta;           //< DI 状态
    dev_do_sta_info_u do_sta;           //< DO 状态
    dev_warn_info_u   warn;             //< 告警信息
    dev_fault_info_u  fault;            //< 故障信息

    uint8_t     bat_num;                //< 电池个数
} energy_cabinet_info_t;

/* 储能柜 相关信息 */
static energy_cabinet_info_t s_energy_cabinet_info = { .bat_num = 0 };
/* 维护模式 */
static bool s_maintenance_mode = SF_FALSE;

static void _energy_cabinet_process( void );

/**
 * @brief  拓展板 在线状态回调函数
 * @param  [in] mod_num_id ：拓展板id（0~5）
 * @param  [in] online     ：在线状态
 * @return 
 */
static void _ext_io_mod_online_change_notify( uint8_t mod_num_id, bool online )
{
    sdk_log_d( "ext[%d] online-%d", mod_num_id, online );

    if (mod_num_id == 0)
    {
        // s_energy_cabinet_info.fault.bit.bat1_ext_io_offline = !(online);
        s_energy_cabinet_info.warn.bit.bat1_ext_io_offline = !(online);
    }
    else if (mod_num_id == 1)
    {
        // s_energy_cabinet_info.fault.bit.bat2_ext_io_offline = !(online);
        s_energy_cabinet_info.warn.bit.bat2_ext_io_offline = !(online);
    }
    else if (mod_num_id == 2)
    {
        // s_energy_cabinet_info.fault.bit.bat3_ext_io_offline = !(online);
        s_energy_cabinet_info.warn.bit.bat3_ext_io_offline = !(online);
    }
    else if (mod_num_id == 3)
    {
        // s_energy_cabinet_info.fault.bit.bat4_ext_io_offline = !(online);
        s_energy_cabinet_info.warn.bit.bat4_ext_io_offline = !(online);
    }
    else if (mod_num_id == 4)
    {
        // s_energy_cabinet_info.fault.bit.bat5_ext_io_offline = !(online);
        s_energy_cabinet_info.warn.bit.bat5_ext_io_offline = !(online);
    }
    else if (mod_num_id == 5)
    {
        // s_energy_cabinet_info.fault.bit.bat6_ext_io_offline = !(online);
        s_energy_cabinet_info.warn.bit.bat6_ext_io_offline = !(online);
    }
}

void ext_io_input_lv_change( uint8_t mod_index, uint8_t io_port, bool io_lv )
{
    if ( io_port == EXT_IO_DI_BAT_DOOR_PORT )
    {
        sdk_log_d( "[%d] dh op:%d", mod_index, !io_lv );
        dehumi_ctrl_op( mod_index, (io_lv == true)? DEV_OP_PAUSE: DEV_OP_RESUME);
    }
}

/**
 * @brief  储能舱初始化
 * @param  [in] 无
 * @return SF_OK：成功  小于SF_OK: 失败
 */
sf_ret_t energy_cabinet_dev_init( void )
{
    uint32_t modbus_idx = EXT_IO_MODBUS_INDEX;
    int32_t  ret = 0;

    /* 打开modbus */
    ret = app_modbus_rtu_init( modbus_idx, MOD_SLAVE_ADDR_BAT1_BOX_IO_EXT, 9600);
    if ( ret > SF_OK )
    {
        sdk_log_e( "%s, app_modbus_rtu_init error ret:%d ", __FUNCTION__, ret);
        return SF_ERR_OPEN;
    }
	ret = app_modbus_connect( modbus_idx );
    if ( ret > SF_OK )
    {
        sdk_log_e( "%s, app_modbus_rtu_init error ret:%d ", __FUNCTION__, ret);
        return SF_ERR_OPEN;
    }
    ret = app_modbus_response_timeout_set( modbus_idx, 200);
    if ( ret > SF_OK )
    {
        sdk_log_e( "%s, app_modbus_rtu_init error ret:%d ", __FUNCTION__, ret);
        return SF_ERR_NDEF;
    }

    /* IO 拓展板初始化 */
    if ( SF_OK > extern_io_init( modbus_idx , 0, SF_FALSE, ext_io_input_lv_change, _ext_io_mod_online_change_notify ) )
    {
        sdk_log_e( "%s, extern_io_init error ret:%d ", __FUNCTION__, ret);
        return ret;
    }
    
    /* 除湿器初始化 */
    if ( SF_OK != dehumi_ctrl_init(  modbus_idx ) )
    {
        sdk_log_e( "%s, dehumi_ctrl_init error!!!", __FUNCTION__);
        return ret;
    }

    return SF_OK;
}

/**
 * @brief  设备舱 数据置为默认状态
 * @param  [in] 无
 * @return SF_OK：成功  小于SF_OK: 失败
 */
sf_ret_t energy_cabinet_bat_box_dat_set_default( void )
{
    for (size_t i = 0; i < s_energy_cabinet_info.bat_num; i++)
    {
        extern_io_set_output_lv( i, EXT_IO_DO_FAN_PORT, IO_OFF );
    }
    extern_io_set_output_lv( 0, EXT_IO_DO_HIG_VOL, IO_OFF );

    sdk_dido_write( DO_DEV_FAULT_TO_CSU, !DO_DEV_FAULT_TO_CSU_VALID_LV );
    sdk_dido_write( DO_DEV_FAULT_TO_OUT, !DO_DEV_FAULT_TO_OUT_VALID_LV );

    sdk_dido_write( DO_FF_START        , IO_OFF );
    sdk_dido_write( DO_FF_ALERTOR      , IO_OFF );

    return SF_OK;
}

/**
 * @brief 获取电池舱个数  
 * @param  [in] 无
 * @return 返回电池舱个数
 */
uint8_t energy_cabinet_get_bat_box_num( void )
{
    return s_energy_cabinet_info.bat_num;
}

/**
 * @brief 设置电池舱个数  
 * @param  [in] bat_num 电池舱个数
 * @return SF_OK：成功  小于SF_OK: 失败
 */
sf_ret_t energy_cabinet_set_bat_cluster_num( uint8_t bat_num )
{
    for (size_t i = 0; i < BAT_CLUSTER_MAX; i++)
    {
        if( i < bat_num ) {
            extern_io_set_mod_enable( i, SF_TRUE, MOD_SLAVE_ADDR_BAT1_BOX_IO_EXT + i );
        }
        else
        {
            extern_io_set_mod_enable( i, SF_FALSE, 0 );
        }
    }
    dehumi_ctrl_set_num( bat_num );    

    s_energy_cabinet_info.bat_num = bat_num;

    return SF_OK;
}

/**
 * @brief  任务调度
 * @param  [in] 无
 * @return 无
 */
void energy_cabinet_task_loop( void )
{
    extern_io_task_loop();
    dehumi_ctrl_loop_task();
    _energy_cabinet_process();
}

/**
 * @brief  设置风扇状态
 * @param  [in] bat_cab_idx : 电池柜索引
 * @param  [in] fan_sta 风扇状态 【SF_TRUE(运行) / SF_FALSE(关闭)】
 * @return SF_OK：成功  小于SF_OK: 失败
 */
sf_ret_t energy_cabinet_set_fan_sta( dev_idx_t bat_cab_idx, bool fan_sta )
{    
    static bool fans_sta[ BAT_CLUSTER_MAX ] = { false };
    bool global_fan_sta = false;

    if ( !((bat_cab_idx < s_energy_cabinet_info.bat_num) || ( bat_cab_idx == DEV_IDX_ALL )) ) 
    {
        return SF_ERR_PARA;
    }

    if ( bat_cab_idx == DEV_IDX_ALL )
    {
        for (size_t i = 0; i < s_energy_cabinet_info.bat_num; i++)
        {
            fans_sta[ i ] = fan_sta;
            if ( SF_OK != extern_io_set_output_lv_sync( i , EXT_IO_DO_FAN_PORT, fan_sta))
            {
                return SF_ERR_WR;
            }
        }
    } else {
        fans_sta[ bat_cab_idx ] = fan_sta;
        if ( SF_OK != extern_io_set_output_lv_sync( bat_cab_idx , EXT_IO_DO_FAN_PORT, fan_sta))
        {
            return SF_ERR_WR;
        }
    }

    for (size_t i = 0; i < s_energy_cabinet_info.bat_num; i++)
    {
        if ( fans_sta[i] == true )
        {
            global_fan_sta = true;
            break;
        }
    }
    s_energy_cabinet_info.do_sta.bit.fan_status = global_fan_sta;


    return SF_OK;
}

/**
 * @brief  设置除湿阈值
 * @param  [in] humi     : 除湿阈值
 * @param  [in] humi_ret : 除湿回差
 * @return SF_OK：成功  小于SF_OK: 失败
 */
sf_ret_t energy_cabinet_set_dehumi_setting( uint16_t humi, uint16_t humi_ret )
{
    sf_ret_t ret = 0;

    if ( dehumi_ctrl_set_auto_mode_param( humi, humi_ret ) != SF_OK )
    {
        return SF_ERR_WR;
    } else {
        return SF_OK;
    }
}

/**
 * @brief  开启消防【让消防控制器 喷灭火剂】
 * @param  [in] on 风扇状态 【SF_TRUE(运行) / SF_FALSE(关闭)】
 * @return 无
 */
void energy_cabinet_set_fire_fighting_start( bool on )
{
    sdk_dido_write( DO_FF_START, on );
    s_energy_cabinet_info.do_sta.bit.ff_start_sta = on;
}

/**
 * @brief  开启声光报警
 * @param  [in] on 【SF_TRUE(打开) / SF_FALSE(关闭)】
 * @return 无
 */
void energy_cabinet_set_fire_fighting_alarm( bool on )
{
    sdk_dido_write( DO_FF_ALERTOR, on );

    s_energy_cabinet_info.do_sta.bit.lamp_alarm_sta = on;
}

/**
 * @brief  设置维护模式【与门磁状态相关联，维护状态下不可开门】
 * @param  [in] enable 【SF_TRUE(使能) / SF_FALSE(关闭)】
 * @return 无
 */
void energy_cabinet_set_maintenance_mode( bool enable )
{
    s_maintenance_mode = enable;
}

/**
 * @brief  对外输出故障【CSU故障/对外故障/高压盒故障】
 * @param  [in] on 【SF_TRUE(使能) / SF_FALSE(关闭)】
 * @return SF_OK：成功  小于SF_OK: 失败
 */
sf_ret_t energy_cabinet_set_fault_lv_output( bool on )
{
    static bool last_fault = SF_FALSE;
    
    if( last_fault != on )
    {
        last_fault = on;

        sdk_dido_write( DO_DEV_FAULT_TO_CSU, (on)? DO_DEV_FAULT_TO_CSU_VALID_LV : !DO_DEV_FAULT_TO_CSU_VALID_LV );
        sdk_dido_write( DO_DEV_FAULT_TO_OUT, (on)? DO_DEV_FAULT_TO_OUT_VALID_LV : !DO_DEV_FAULT_TO_OUT_VALID_LV );

        s_energy_cabinet_info.do_sta.bit.fault_to_csu = on; 
        s_energy_cabinet_info.do_sta.bit.fault_to_out = on;

        for (size_t i = 0; i < s_energy_cabinet_info.bat_num; i++)
        {
            extern_io_set_output_lv(i, EXT_IO_DO_HIG_VOL, on);
        }
    }
    return SF_OK;
}

/**
 * @brief  获取DI状态
 * @param  [out] p_dev_di_sta ：DI 状态结构体
 * @return 无
 */
void energy_cabinet_get_di_sta( dev_di_sta_info_u *p_dev_di_sta)
{
    if( p_dev_di_sta == NULL )
        return;

    *p_dev_di_sta = s_energy_cabinet_info.di_sta;
}

/**
 * @brief  获取Do状态
 * @param  [out] p_dev_do_sta ：DO 状态结构体
 * @return 无
 */
void energy_cabinet_get_do_sta( dev_do_sta_info_u *p_dev_do_sta)
{
    if( p_dev_do_sta == NULL )
        return;

    *p_dev_do_sta = s_energy_cabinet_info.do_sta;
}

/**
 * @brief  获取告警信息
 * @param  [out] p_dev_warn ：告警信息结构体
 * @return 无
 */
void energy_cabinet_get_warn( dev_warn_info_u *p_dev_warn)
{
    if( p_dev_warn == NULL )
        return;

    *p_dev_warn   = s_energy_cabinet_info.warn;
}

/**
 * @brief  获取故障信息
 * @param  [out] p_dev_fault ：故障信息结构体
 * @return 无
 */
void energy_cabinet_get_fault( dev_fault_info_u *p_dev_fault)
{
    if( p_dev_fault == NULL )
        return;

    *p_dev_fault  = s_energy_cabinet_info.fault;
}

/**
 * @brief  储能舱 相关处理逻辑
 * @param  [in] 无
 * @return 
 */
static void _energy_cabinet_process( void ) 
{
    lc_dat_t lc_dat;

    memset( &lc_dat, 0, sizeof( lc_dat )); 
    lc_ctrl_get_lc_dat( &lc_dat );
    dehumi_ctrl_input_obj_temper( lc_dat.outlet_temper );
    
    s_energy_cabinet_info.di_sta.bit.flood1         = (IO_STA_HIG == extern_io_get_input_lv( 0, EXT_IO_DI_FLOOD1_PORT )) ? 1: 0 ;
    s_energy_cabinet_info.di_sta.bit.flood2         = (IO_STA_HIG == extern_io_get_input_lv( 0, EXT_IO_DI_FLOOD2_PORT )) ? 1: 0 ;
    s_energy_cabinet_info.di_sta.bit.entrance_dev   = (IO_STA_HIG == extern_io_get_input_lv( 0, EXT_IO_DI_DEV_DOOR_PORT )) ? 1: 0 ;
    s_energy_cabinet_info.di_sta.bit.entrance_bat1  = (IO_STA_HIG == extern_io_get_input_lv( 0, EXT_IO_DI_BAT_DOOR_PORT )) ? 1: 0 ;

    s_energy_cabinet_info.di_sta.bit.entrance_bat2  = (IO_STA_HIG == extern_io_get_input_lv( 1, EXT_IO_DI_BAT_DOOR_PORT )) ? 1 : 0;
    s_energy_cabinet_info.di_sta.bit.entrance_bat3  = (IO_STA_HIG == extern_io_get_input_lv( 2, EXT_IO_DI_BAT_DOOR_PORT )) ? 1 : 0;
    s_energy_cabinet_info.di_sta.bit.entrance_bat4  = (IO_STA_HIG == extern_io_get_input_lv( 3, EXT_IO_DI_BAT_DOOR_PORT )) ? 1 : 0;
    s_energy_cabinet_info.di_sta.bit.entrance_bat5  = (IO_STA_HIG == extern_io_get_input_lv( 4, EXT_IO_DI_BAT_DOOR_PORT )) ? 1 : 0;
    s_energy_cabinet_info.di_sta.bit.entrance_bat6  = (IO_STA_HIG == extern_io_get_input_lv( 5, EXT_IO_DI_BAT_DOOR_PORT )) ? 1 : 0;

    s_energy_cabinet_info.di_sta.bit.ff_warn1       = app_dido_read( DI_FF_WARN1 );
    s_energy_cabinet_info.di_sta.bit.ff_warn2       = app_dido_read( DI_FF_WARN2 );
    s_energy_cabinet_info.di_sta.bit.ff_fault       = app_dido_read( DI_FF_COMM_FAULT );

    s_energy_cabinet_info.warn.bit.ff_warn1         = s_energy_cabinet_info.di_sta.bit.ff_warn1;

    s_energy_cabinet_info.fault.bit.ff_warn2_flag   = fire_fighting2_get_warn2_alarm_sta()? 1: 0;
        
    /* 两个 */
    if(    (s_energy_cabinet_info.di_sta.bit.flood1 == 1) 
        || (s_energy_cabinet_info.di_sta.bit.flood2 == 1)  )
    {
        s_energy_cabinet_info.warn.bit.flood_warn = 1;
    }
    else
    {
        s_energy_cabinet_info.warn.bit.flood_warn = 0;
    }

    if(    (s_energy_cabinet_info.di_sta.bit.flood1 == 1) 
        && (s_energy_cabinet_info.di_sta.bit.flood2 == 1)  )
    {
        s_energy_cabinet_info.fault.bit.flood_fault = 1;
    }
    else
    {
        s_energy_cabinet_info.fault.bit.flood_fault = 0;
    }

    if( (s_maintenance_mode == SF_FALSE) && 
        (  ( s_energy_cabinet_info.di_sta.bit.entrance_dev == 1 )
        || ( s_energy_cabinet_info.di_sta.bit.entrance_bat1 == 1 )
        || ( s_energy_cabinet_info.di_sta.bit.entrance_bat2 == 1 )
        || ( s_energy_cabinet_info.di_sta.bit.entrance_bat3 == 1 )
        || ( s_energy_cabinet_info.di_sta.bit.entrance_bat4 == 1 )
        || ( s_energy_cabinet_info.di_sta.bit.entrance_bat5 == 1 )
        || ( s_energy_cabinet_info.di_sta.bit.entrance_bat6 == 1 )))
    {
        s_energy_cabinet_info.fault.bit.entrance_fault = 1;
    }
    else
    {
        s_energy_cabinet_info.fault.bit.entrance_fault = 0;
    }

    s_energy_cabinet_info.warn.bit.bat1_ext_io_offline = (extern_io_get_online_sta( 0 ) == OL_STA_OFFLINE) ? 1: 0;
    s_energy_cabinet_info.warn.bit.bat2_ext_io_offline = (extern_io_get_online_sta( 1 ) == OL_STA_OFFLINE) ? 1: 0;
    s_energy_cabinet_info.warn.bit.bat3_ext_io_offline = (extern_io_get_online_sta( 2 ) == OL_STA_OFFLINE) ? 1: 0;
    s_energy_cabinet_info.warn.bit.bat4_ext_io_offline = (extern_io_get_online_sta( 3 ) == OL_STA_OFFLINE) ? 1: 0;
    s_energy_cabinet_info.warn.bit.bat5_ext_io_offline = (extern_io_get_online_sta( 4 ) == OL_STA_OFFLINE) ? 1: 0;
    s_energy_cabinet_info.warn.bit.bat6_ext_io_offline = (extern_io_get_online_sta( 5 ) == OL_STA_OFFLINE) ? 1: 0;


}

