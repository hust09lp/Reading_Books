#include "sdk_osif.h"
#include "sdk.h"
#include "sdk_core.h"
#include "sdk_modbus.h"
#include "sdk_dido.h"
#include "sci.h"
#include "factory_test.h"
#include "factory_dev_test.h"
#include "app_cfg.h"
#include "sdk_eeprom.h"

#define TEST_CAN_BAUD 1000UL * 500
#define TEST_CAN_MODE SDK_CAN_MODE_NORMAL

// 测试失败后的重试次数
#define RETRY_TIMES 5
// CAN通信帧数据长度
#define FRAM_DATA_LEN 8

factory_mode_e g_factory_test = FACTORY_MODE_NONE;                       // 工厂测试模式
uint8_t g_rs485_test[MODBUS_TEST_CH_MAX] = {0};                          // 工厂测试-485测试标志
uint16_t rsp_data[8] = {0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88}; // 485 测试回复数据
uint16_t rec_data[32] = {0};                                             // 485测试接收buff

uint8_t di_to_do_arry[DI_MAX] = {DO_1, DO_1, DO_2, DO_2, DO_6, DO_6, DO_5, DO_7, DO_7, DO_5, DO_8, DO_8, DO_3, DO_3, DO_4, DO_4, DO_4}; // DI测试对应的DO
uint8_t do_to_di_arry[DO_MAX] = {DI_1, DI_3, DI_13, DI_15, DI_7, DI_5, DI_8, DI_11};                                                    // DO 测试对应的DI

#define FACTORY_TEST_FILE_NAME "1:factory_test.txt"
#define FLASH_TEST_BUF_LEN 1024 // FLASH测试数据缓存区
#define EEPROM_TEST_BUF_LEN 512 // EEPROM测试数据缓存区
#define EEPROM_TEST_OFFSET 128  // EEPROM测试数据写入偏移

static uint8_t s_flash_test_buf[FLASH_TEST_BUF_LEN];
static uint8_t s_eeprom_test_buf[EEPROM_TEST_BUF_LEN];

uint8_t g_wdt_feed_disable_flag = SF_FALSE; 

/**
 * @brief		数据对比
 * @param		[in] p_src 源buff指针
 * @param		[in] p_dst  目的buff指针
 * @param		[in] length  要对比的数据长度
 * @return		数据对比结果0：数据一致  -1：数据不一致
 * @warning		无
 */
static uint8_t data_compare(uint8_t *p_src, uint8_t *p_dst, uint16_t length)
{
    while (length--)
    {
        if (*p_src++ != *p_dst++)
        {
            return FAIL;
        }
    }
    return SUCCESS;
}

/**
 * @brief  modbus从机报文解析
 * @param  [in] port_index 通道下标映射
 * @param  [in] function 功能码
 * @param  [in] p_req 请求报文信息，信息从原始报文"开始地址"开始
 * @param  [out] p_rsq 返回报文指针
 * @param  [in] rsq_size 返回报文buffer大小
 * @return 返回长度：字节数1字节 + 寄存器资料占用字节；为0时为异常情况
 */
static int32_t user_modbus_resolve(uint32_t port_index, uint32_t function, const uint8_t *p_request, uint8_t *p_response, int32_t rsq_size)
{
    uint8_t *p_data = NULL;
    uint16_t reg_num = ((p_request[2] << 8) + p_request[3]);
    uint16_t i = 0;
    uint8_t *temp = NULL;
    uint16_t value = 0;
    uint16_t n = 0;

    switch (function)
    {
    case MODBUS_FC_READ_HOLDING_REGISTERS:
        sdk_log_i("port_index %d\r\n", port_index);
        p_data = p_response;
        *p_data++ = reg_num * 2;
        for (i = 0; i < reg_num * 2; i++)
        {
            *(p_data + i) = 0;
        }
        for (i = 0; i < reg_num; i++)
        {
            n = i * 2;
            value = rsp_data[i];
            temp = (uint8_t *)&value;
            *(p_data + n) = *(temp + 1);
            *(p_data + n + 1) = *(temp);
        }
        break;
    default:
        break;
    }

    return (reg_num * 2 + 1);
}

/**
 * @brief		工厂485测试接口
 * @param		[in] test_port 要测试的485通道：通道1-4
 * @return		ret：-1 测试失败  除-1外的其他值：测试成功
 * @warning		无
 */
static int32_t factory_rs485_test(uint16_t test_port)
{
    int32_t ret = -1;
    uint8_t *p_src_buf = NULL;
    uint8_t *p_dst_buf = NULL;
    uint8_t data_check = 0;
    uint8_t i = 0;

    // test_port为无符号数
    if (test_port == 0 || test_port > MODBUS_MAX)
    {
        return RET_ERR;
    }
    // 操作的索引比传入的少1
    test_port -= 1;

    switch (test_port)
    {
    case MODBUS_INDEX1:
        g_rs485_test[MODBUS_TEST_CH1] = 1;
        for (i = 0; i < RETRY_TIMES; i++)
        {
            // 清空485通信的缓存缓存
            sdk_modbus_flush(MODBUS_INDEX1);
            sdk_modbus_flush(MODBUS_INDEX2);
            sdk_modbus_slave_set(MODBUS_INDEX1, 1);
            sdk_modbus_slave_set(MODBUS_INDEX2, 1);
            memset((uint8_t *)&rec_data, 0, sizeof(rec_data));
            // 通道1作为主机读取通道2 8个保持寄存器的值
            ret = sdk_modbus_registers_read(MODBUS_INDEX1, 0, 8, rec_data);
            if (ret == -1)
            {
                sdk_log_i("modbus port%d read hold reg faile\r\n", test_port + 1);
            }
            else
            {
                p_src_buf = (uint8_t *)&rec_data;
                p_dst_buf = (uint8_t *)&rsp_data;
                data_check = data_compare(p_src_buf, p_dst_buf, ret * 2);
                if (data_check == SUCCESS)
                {
                    sdk_log_i("modbus port%d read hold reg success %d\r\n", test_port + 1, ret);
                    break;
                }
                else
                {
                    sdk_log_i("modbus port%d read hold reg faile\r\n", test_port + 1);
                    ret = -1;
                }
            }
            sdk_os_delay(sdk_os_tick_from_millisecond(100));
        }
        g_rs485_test[MODBUS_TEST_CH1] = 0;
        break;
    case MODBUS_INDEX2:
        g_rs485_test[MODBUS_TEST_CH2] = 1;
        for (i = 0; i < RETRY_TIMES; i++)
        {
            // 清空485通信的缓存缓存
            sdk_modbus_flush(MODBUS_INDEX1);
            sdk_modbus_flush(MODBUS_INDEX2);
            sdk_modbus_slave_set(MODBUS_INDEX1, 2);
            sdk_modbus_slave_set(MODBUS_INDEX2, 2);
            memset((uint8_t *)&rec_data, 0, sizeof(rec_data));
            // 通道2作为主机读取通道1  8个保持寄存器的值
            ret = sdk_modbus_registers_read(MODBUS_INDEX2, 0, 8, rec_data);
            if (ret == -1)
            {
                sdk_log_i("modbus port%d read hold reg faile\r\n", test_port + 1);
            }
            else
            {
                p_src_buf = (uint8_t *)&rec_data;
                p_dst_buf = (uint8_t *)&rsp_data;
                data_check = data_compare(p_src_buf, p_dst_buf, ret * 2);
                if (data_check == SUCCESS)
                {
                    sdk_log_i("modbus port%d read hold reg success %d\r\n", test_port + 1, ret);
                    break;
                }
                else
                {
                    sdk_log_i("modbus port%d read hold reg faile\r\n", test_port + 1);
                    ret = -1;
                }
            }
            sdk_os_delay(sdk_os_tick_from_millisecond(100));
        }
        g_rs485_test[MODBUS_TEST_CH2] = 0;
        break;
    case MODBUS_INDEX3:
        g_rs485_test[MODBUS_TEST_CH3] = 1;
        for (i = 0; i < RETRY_TIMES; i++)
        {
            // 清空485通信的缓存缓存
            sdk_modbus_flush(MODBUS_INDEX3);
            sdk_modbus_flush(MODBUS_INDEX4);
            sdk_modbus_slave_set(MODBUS_INDEX3, 3);
            sdk_modbus_slave_set(MODBUS_INDEX4, 3);
            memset((uint8_t *)&rec_data, 0, sizeof(rec_data));
            // 通道3作为主机读取通道4  8个保持寄存器的值
            ret = sdk_modbus_registers_read(MODBUS_INDEX3, 0, 8, rec_data);
            if (ret == -1)
            {
                sdk_log_i("modbus port%d read hold reg faile\r\n", test_port + 1);
            }
            else
            {
                p_src_buf = (uint8_t *)&rec_data;
                p_dst_buf = (uint8_t *)&rsp_data;
                data_check = data_compare(p_src_buf, p_dst_buf, ret * 2);
                if (data_check == SUCCESS)
                {
                    sdk_log_i("modbus port%d read hold reg success %d\r\n", test_port + 1, ret);
                    break;
                }
                else
                {
                    sdk_log_i("modbus port%d read hold reg faile\r\n", test_port + 1);
                    ret = -1;
                }
            }
            sdk_os_delay(sdk_os_tick_from_millisecond(100));
        }
        g_rs485_test[MODBUS_TEST_CH3] = 0;
        break;
    case MODBUS_INDEX4:
        g_rs485_test[MODBUS_TEST_CH4] = 1;
        for (i = 0; i < RETRY_TIMES; i++)
        {
            // 清空485通信的缓存缓存
            sdk_modbus_flush(MODBUS_INDEX3);
            sdk_modbus_flush(MODBUS_INDEX4);
            sdk_modbus_slave_set(MODBUS_INDEX3, 4);
            sdk_modbus_slave_set(MODBUS_INDEX4, 4);
            memset((uint8_t *)&rec_data, 0, sizeof(rec_data));
            // 通道4作为主机读取通道3  8个保持寄存器的值
            ret = sdk_modbus_registers_read(MODBUS_INDEX4, 0, 8, rec_data);
            if (ret == -1)
            {
                sdk_log_i("modbus port%d read hold reg faile\r\n", test_port + 1);
            }
            else
            {
                p_src_buf = (uint8_t *)&rec_data;
                p_dst_buf = (uint8_t *)&rsp_data;
                data_check = data_compare(p_src_buf, p_dst_buf, ret * 2);
                if (data_check == SUCCESS)
                {
                    sdk_log_i("modbus port%d read hold reg success %d\r\n", test_port + 1, ret);
                    break;
                }
                else
                {
                    sdk_log_i("modbus port%d read hold reg faile\r\n", test_port + 1);
                    ret = -1;
                }
            }
            sdk_os_delay(sdk_os_tick_from_millisecond(100));
        }
        g_rs485_test[MODBUS_TEST_CH4] = 0;
        break;
    default:
        break;
    }
    return ret;
}

/**
 * @brief		工厂485测试slave回复接口
 * @param		无
 * @return		无
 * @warning		无
 */
void factory_rs485_rsp(void)
{
    int32_t rc = 0;
    uint8_t query_buffer[32] = {0};

    if (g_rs485_test[MODBUS_TEST_CH1] == 1)
    {
        // 测试通道1，通道1发送，通道2作为slave回复
        rc = sdk_modbus_receive(MODBUS_INDEX2, query_buffer);
        if (rc > 0)
        {
            sdk_log_i("port_reply:%d\r\n", MODBUS_INDEX2);
            sdk_modbus_reply(MODBUS_INDEX2, query_buffer, rc, user_modbus_resolve);
        }
    }
    if (g_rs485_test[MODBUS_TEST_CH2] == 1)
    {
        // 测试通道2，通道2发送，通道1作为slave回复
        rc = sdk_modbus_receive(MODBUS_INDEX1, query_buffer);
        if (rc > 0)
        {
            sdk_log_i("port_reply:%d\r\n", MODBUS_INDEX1);
            sdk_modbus_reply(MODBUS_INDEX1, query_buffer, rc, user_modbus_resolve);
        }
    }
    if (g_rs485_test[MODBUS_TEST_CH3] == 1)
    {
        // 测试通道3，通道3发送，通道4作为slave回复
        rc = sdk_modbus_receive(MODBUS_INDEX4, query_buffer);
        if (rc > 0)
        {
            sdk_log_i("port_reply:%d\r\n", MODBUS_INDEX4);
            sdk_modbus_reply(MODBUS_INDEX4, query_buffer, rc, user_modbus_resolve);
        }
    }
    if (g_rs485_test[MODBUS_TEST_CH4] == 1)
    {
        // 测试通道4，通道4发送，通道3作为slave回复
        rc = sdk_modbus_receive(MODBUS_INDEX3, query_buffer);
        if (rc > 0)
        {
            sdk_log_i("port_reply:%d\r\n", MODBUS_INDEX3);
            sdk_modbus_reply(MODBUS_INDEX3, query_buffer, rc, user_modbus_resolve);
        }
    }
}

void factory_can_init(void)
{
    sdk_can_cfg_t can_cfg = {TEST_CAN_BAUD, TEST_CAN_MODE};

    sdk_can_close(CAN_ID_2);
    sdk_can_open(CAN_ID_2);
    sdk_can_setup(CAN_ID_2, &can_cfg);

    sdk_can_close(CAN_ID_1);
    sdk_can_open(CAN_ID_1);
    sdk_can_setup(CAN_ID_1, &can_cfg);
}

/**
 * @brief		工厂CAN测试
 * @param		[in] test_port 要测试的CAN通道 CAN1  CAN2
 * @return		ret：测试结果  -1测试失败  其它值 测试成功
 * @warning		无
 */
static int32_t factory_can_test(void)
{
    sdk_can_frame_t txmsg = {0};
    sdk_can_frame_t rxmsg = {0};
    uint8_t *p_src_buf = NULL;
    uint8_t *p_dst_buf = NULL;
    new_can_frame_id_u can_id;
    uint8_t data_check = 0;
    uint8_t i;
    int32_t can1_ret = -1;
    int32_t can2_ret = -1;

    factory_can_init();

    txmsg.data[0] = 0x55;
    txmsg.data[1] = 0xaa;
    txmsg.data[2] = 0x11;
    txmsg.data[3] = 0x22;
    txmsg.data[4] = 0x33;
    txmsg.data[5] = 0x44;
    txmsg.data[6] = 0x55;
    txmsg.data[7] = 0x66;

    can_id.bit.src_addr = CAN1_ADDR;
    can_id.bit.src_type = CAN1_ID;
    can_id.bit.dst_addr = CAN2_ADDR;
    can_id.bit.dst_type = CAN2_ID;

    can_id.bit.fun_code = 0x10;
    can_id.bit.res = 1;
    can_id.bit.cont = 0;
    can_id.bit.frame_type = CAN_DATA_FRAME;
    can_id.bit.prio = 6;

    txmsg.id = can_id.id_val;
    txmsg.ide = SDK_CAN_EXTID;
    txmsg.rtr = SDK_CAN_DTR;
    txmsg.len = 8;
    txmsg.priv = 1;

    int32_t ret = 0;
    // 清空两路CAN缓冲区数据
    do
    {
        ret = sdk_can_read(CAN_ID_1, &rxmsg, 1, 0);
    } while (ret > 0);
    do
    {
        ret = sdk_can_read(CAN_ID_2, &rxmsg, 1, 0);
    } while (ret > 0);

    for (i = 0; i < RETRY_TIMES; i++)
    {
        // CAN1发送固定数据
        can1_ret = sdk_can_write(CAN_ID_1, &txmsg, 1);

        memset(rxmsg.data, 0, 8);
        // CAN2接收数据
        can1_ret = sdk_can_read(CAN_ID_2, &rxmsg, 1, 300);
        if (can1_ret != SUCCESS)
        {
            sdk_log_i("can1 read fail \r\n");
            can1_ret = RET_ERR;
        }
        else
        {
            p_src_buf = txmsg.data;
            p_dst_buf = rxmsg.data;
            // 比较发送数据和接收数据是否一致
            data_check = data_compare(p_src_buf, p_dst_buf, FRAM_DATA_LEN);
            if (data_check == SUCCESS)
            {
                sdk_log_i("can1 read success %d \r\n", can1_ret);
                can1_ret = SUCCESS;
            }
            else
            {
                sdk_log_i("can1 read fail \r\n");
                can1_ret = RET_ERR;
            }
        }

        // CAN2发送数据
        can2_ret = sdk_can_write(CAN_ID_2, &txmsg, 1);

        memset(rxmsg.data, 0, 8);
        // CAN1接收数据
        can2_ret = sdk_can_read(CAN_ID_1, &rxmsg, 1, 300);
        if (can2_ret != SUCCESS)
        {
            sdk_log_i("can2 read fail %d \r\n", can2_ret);
            can2_ret = RET_ERR;
        }
        else
        {
            p_src_buf = txmsg.data;
            p_dst_buf = rxmsg.data;
            // 比较发送数据和接收数据是否一致
            data_check = data_compare(p_src_buf, p_dst_buf, FRAM_DATA_LEN);
            if (data_check == SUCCESS)
            {
                sdk_log_i("can2 read success %d \r\n", can2_ret);
                can2_ret = SUCCESS;
            }
            else
            {
                sdk_log_i("can2 read fail \r\n");
                can2_ret = RET_ERR;
            }
        }
        if (can1_ret != RET_ERR && can2_ret != RET_ERR)
        {
            sdk_log_i("can test success \r\n");
            return SUCCESS;
        }
        sdk_os_delay(sdk_os_tick_from_millisecond(100));
    }
    sdk_log_i("can test fail \r\n");
    return RET_ERR;
}

/**
 * @brief		工厂DI DO测试接口
 * @param		[in] test_type 测试类型 3-DI测试   4-DO测试
 * @return		ret：-1 测试失败  除-1外的其他值：测试成功
 * @warning		无
 */
static int32_t factory_di_do_test(uint16_t test_type, uint16_t test_port)
{
    uint8_t di_status = 0;
    uint8_t i = 0;
    int32_t result1 = -1;
    int32_t result2 = -1;

    if (test_type == DI_TEST)
    {
        // test_port为无符号数，有效范围DI_1 ~ DI_17
        if (test_port == 0 || test_port > DI_MAX)
        {
            return RET_ERR;
        }

        // 操作的索引比传入的少1
        test_port -= 1;

        for (i = 0; i < RETRY_TIMES; i++)
        {
            // 第1步：将DO拉高并延时10ms
            sdk_dido_write(di_to_do_arry[test_port], ON);
            sdk_os_delay(sdk_os_tick_from_millisecond(10));

            // 第2步：读取对应的DI状态
            di_status = sdk_dido_read(test_port);

            // 第3步：判断对应的DI状态是否为高
            if (di_status == ON)
            {
                result1 = SUCCESS;
                sdk_log_i("DI%d TEST HIGH SUCCESS\r\n", test_port + 1);
            }
            else
            {
                result1 = RET_ERR;
                sdk_log_i("DI%d TEST HIGH FAIL\r\n", test_port + 1);
            }
            sdk_os_delay(sdk_os_tick_from_millisecond(10));

            // 第4步：将DO拉低并延时10ms
            sdk_dido_write(di_to_do_arry[test_port], OFF);
            sdk_os_delay(sdk_os_tick_from_millisecond(10));

            // 第5步：读取对应的DI状态
            di_status = sdk_dido_read(test_port);
            sdk_os_delay(sdk_os_tick_from_millisecond(10));

            // 第6步：判断对应的DI状态是否为低
            if (di_status == OFF)
            {
                result2 = SUCCESS;
                sdk_log_i("DI%d TEST LOW SUCCESS\r\n", test_port + 1);
            }
            else
            {
                result2 = RET_ERR;
                sdk_log_i("DI%d TEST LOW FAIL\r\n", test_port + 1);
            }
            if (result1 == SUCCESS && result2 == SUCCESS)
            {
                return SUCCESS;
            }
        }
    }
    else if (test_type == DO_TEST)
    {
        // test_port为无符号数，有效范围DO_1 ~ DO_8
        if (test_port == 0 || test_port > DO_MAX)
        {
            return RET_ERR;
        }

        // 操作的索引比传入的少1
        test_port -= 1;

        for (i = 0; i < RETRY_TIMES; i++)
        {
            // 第1步：将DO拉高并延时10ms
            sdk_dido_write(test_port, ON);
            sdk_os_delay(sdk_os_tick_from_millisecond(10));

            // 第2步：读取对应的DI状态
            di_status = sdk_dido_read(do_to_di_arry[test_port]);

            // 第3步：判断对应的DI状态是否为高
            if (di_status == ON)
            {
                result1 = SUCCESS;
                sdk_log_i("DO%d TEST HIGH SUCCESS\r\n", test_port + 1);
            }
            else
            {
                result1 = RET_ERR;
                sdk_log_i("DO%d TEST HIGH FAIL\r\n", test_port + 1);
            }
            sdk_os_delay(sdk_os_tick_from_millisecond(10));

            // 第4步：将DO拉低并延时10ms
            sdk_dido_write(test_port, OFF);
            sdk_os_delay(sdk_os_tick_from_millisecond(10));

            // 第5步：读取对应的DI状态
            di_status = sdk_dido_read(do_to_di_arry[test_port]);
            sdk_os_delay(sdk_os_tick_from_millisecond(10));

            // 第6步：判断对应的DI状态是否为低
            if (di_status == OFF)
            {
                result2 = SUCCESS;
                sdk_log_i("DO%d TEST LOW SUCCESS\r\n", test_port + 1);
            }
            else
            {
                result2 = RET_ERR;
                sdk_log_i("DO%d TEST LOW FAIL\r\n", test_port + 1);
            }
            if (result1 == SUCCESS && result2 == SUCCESS)
            {
                return SUCCESS;
            }
        }
    }
    return RET_ERR;
}

/**
 * @brief		工厂spi flash测试接口
 * @return		ret：RET_ERR 测试失败  SUCCESS 测试成功
 * @warning		无
 */
static int32_t factory_flash_test(void)
{
    int32_t fs_ret = 0;
    int32_t ret = SUCCESS;
    fs_t *p_fs = SF_NULL;
    uint32_t i = 0;

    memset((uint8_t *)&s_flash_test_buf, 0x00, sizeof(s_flash_test_buf));

    sdk_fs_close(p_fs);

    // 打开文件
    p_fs = sdk_fs_open((const int8_t *)FACTORY_TEST_FILE_NAME, FA_WRITE | FA_READ | FA_OPEN_ALWAYS);
    if (p_fs == SF_NULL)
    {
        // 打开文件失败
        ret = RET_ERR;
        // sdk_log_e("factory test file open fail");
        return ret;
    }
    else
    {
        sdk_log_i("factory test file open success");
    }

    // 填充测试数据缓存
    for (i = 0; i < sizeof(s_flash_test_buf); ++i)
    {
        s_flash_test_buf[i] = (i & 0xFF);
    }

    // 写flash测试数据
    sdk_fs_write(p_fs, s_flash_test_buf, sizeof(s_flash_test_buf));

    // 读取测试文件
    sdk_fs_lseek(p_fs, 0);
    memset((uint8_t *)&s_flash_test_buf, 0x00, sizeof(s_flash_test_buf));
    sdk_fs_read(p_fs, s_flash_test_buf, sizeof(s_flash_test_buf));

    // 比对测试文件
    for (i = 0; i < sizeof(s_flash_test_buf); ++i)
    {
        if (s_flash_test_buf[i] != (i & 0xFF))
        {
            ret = RET_ERR;
            sdk_log_e("flash read compare fail");
            break;
        }
        sdk_log_printf("%02X ", s_flash_test_buf[i]);
        if ((i + 1) % 32 == 0)
        {
            // 在32字节后添加换行
            sdk_log_printf("\r\n");
        }
    }
    sdk_log_printf("\r\n");

    // 关闭文件
    sdk_fs_close(p_fs);

    // 删除文件
    fs_ret = sdk_fs_remove((const int8_t *)FACTORY_TEST_FILE_NAME);
    if (fs_ret != SF_OK)
    {
        // 删除失败
        ret = RET_ERR;
        sdk_log_e("test file remove error !");
    }
    else
    {
        sdk_log_i("test file remove success");
    }

    if (SUCCESS == ret)
    {
        sdk_log_i("flash test success");
    }
    else
    {
        sdk_log_w("flash test fail !");
    }

    return ret;
}

/**
 * @brief		工厂eeprom测试接口
 * @return		ret：RET_ERR 测试失败  SUCCESS 测试成功
 * @warning		无
 */
static int32_t factory_eeprom_test(void)
{
    int32_t ret = SUCCESS;
    int32_t eep_ret = SUCCESS;
    uint32_t i = 0;

    // 填充测试数据缓存
    memset((uint8_t *)&s_eeprom_test_buf, 0x00, sizeof(s_eeprom_test_buf));
    for (i = 0; i < sizeof(s_eeprom_test_buf); ++i)
    {
        s_eeprom_test_buf[i] = (i & 0xFF);
    }

    //  测试写入eeprom
    sdk_eeprom_write(EEPROM_TEST_OFFSET, EEPROM_TEST_BUF_LEN, s_eeprom_test_buf);

    // 清空缓存区
    memset((uint8_t *)&s_eeprom_test_buf, 0x00, sizeof(s_eeprom_test_buf));

    // 读取eeprom数据
    eep_ret = sdk_eeprom_read(EEPROM_TEST_OFFSET, EEPROM_TEST_BUF_LEN, s_eeprom_test_buf);
    if (SF_OK == eep_ret)
    {
        sdk_log_i("eeprom read success");
    }
    else
    {
        sdk_log_w("eeprom read fail !");
    }

    // 比对回读数据
    for (i = 0; i < sizeof(s_eeprom_test_buf); ++i)
    {
        if (s_eeprom_test_buf[i] != (i & 0xFF))
        {
            ret = RET_ERR;
            sdk_log_e("eeprom read compare fail");
            break;
        }
        sdk_log_printf("%02X ", s_eeprom_test_buf[i]);
        if ((i + 1) % 32 == 0)
        {
            // 在32字节后添加换行
            sdk_log_printf("\r\n");
        }
    }
    sdk_log_printf("\r\n");

    // 还原eeprom测试区
    memset((uint8_t *)&s_eeprom_test_buf, 0xFF, sizeof(s_eeprom_test_buf));
    sdk_eeprom_write(EEPROM_TEST_OFFSET, EEPROM_TEST_BUF_LEN, s_eeprom_test_buf);

    // 读取eeprom数据
    eep_ret = sdk_eeprom_read(EEPROM_TEST_OFFSET, EEPROM_TEST_BUF_LEN, s_eeprom_test_buf);
    if (SF_OK == eep_ret)
    {
        sdk_log_i("eeprom read success");
    }
    else
    {
        sdk_log_w("eeprom read fail !");
    }

    // 比对回读数据
    for (i = 0; i < sizeof(s_eeprom_test_buf); ++i)
    {
        if (s_eeprom_test_buf[i] != 0xFF)
        {
            ret = RET_ERR;
            sdk_log_e("eeprom read compare fail");
            break;
        }
        sdk_log_printf("%02X ", s_eeprom_test_buf[i]);
        if ((i + 1) % 32 == 0)
        {
            // 在32字节后添加换行
            sdk_log_printf("\r\n");
        }
    }
    sdk_log_printf("\r\n");

    if (SUCCESS == ret)
    {
        sdk_log_i("eeprom test success");
    }
    else
    {
        sdk_log_w("eeprom test fail !");
    }

    return ret;
}

/**
 * @brief		工厂wdt测试接口
 * @param		[in] test_item 测试项 0-测试前准备 1-看门狗启动 2-复位检查
 * @return		ret：RET_ERR 测试失败  SUCCESS 测试成功
 * @warning		无
 */
static int32_t factory_wdt_test(uint16_t test_item)
{
    int32_t ret       = SUCCESS;
    int32_t DO_ctrl   = 0;
    int32_t DI_read   = 0;
    uint8_t DI_status = 0;

    switch (test_item)
    {
        case WDT_PREPARE :
            {
				//sdk_log_i(">>>>>>>>>>>>>>>>>>> WDT_PREPARE");
                // 置高所有DO并读取DI，所有DI为高返回成功
                for (DO_ctrl = DO_1; DO_ctrl < DO_MAX; ++DO_ctrl)
                {
                    sdk_dido_write(DO_ctrl, IO_ON);
                    sdk_os_delay(sdk_os_tick_from_millisecond(10));
                }
                for (DI_read = DI_1; DI_read < DI_MAX; ++DI_read)
                {
                    DI_status = sdk_dido_read(DI_read);
                    sdk_os_delay(sdk_os_tick_from_millisecond(10));
                    if (DI_status == IO_OFF)
                    {
                        ret = RET_ERR;
                        sdk_log_w("WDT: DI%d READ HIGH FAIL", DI_read + 1);
                    }
                }
                if (SUCCESS == ret)
                {
                    sdk_log_i("WDT_PREPARE success");
                }
                else
                {
                    sdk_log_w("WDT_PREPARE fail");
                }
                break;
            }
        case WDT_FEED_DISABLE :
            {
				//sdk_log_i(">>>>>>>>>>>>>>>>>>> WDT_FEED_DISABLE");
                // 禁止看门狗喂狗
                g_wdt_feed_disable_flag = SF_TRUE;    // 禁止喂狗到复位 时间间隔估计：外部看门狗2.5s 内部看门狗6s
                sdk_log_i("Start wdt test...");
                break;
            }
        case WDT_CHECK :
            {
				//sdk_log_i(">>>>>>>>>>>>>>>>>>> WDT_CHECK");
                // 看门狗复位检测，读取所有DI，若全部为低返回成功
                for (DI_read = DI_1; DI_read < DI_MAX; ++DI_read)
                {
                    DI_status = sdk_dido_read(DI_read);
                    sdk_os_delay(sdk_os_tick_from_millisecond(10));
                    if (DI_status == IO_ON && (DI_7 != DI_read && DI_10 != DI_read))
                    {
                        ret = RET_ERR;
                        sdk_log_w("WDT: DI%d READ LOW FAIL", DI_read + 1);
                    }
                }
                if (SUCCESS == ret)
                {
                    sdk_log_i("WDT_CHECK success: ALL DI LOW");
                }
                else
                {
                    sdk_log_w("WDT_CHECK fail: NOT ALL DI LOW");
                }
                break;
            }
        default :
            {
                ret = RET_ERR;
                sdk_log_w("WDT: not support test item", test_item);
                break;
            }
    }
    return ret;
}

/**
 * @brief		工厂测试总入口
 * @param		[in] test_type 测试类型 1-485测试 2-CAN测试 3-DI测试   4-DO测试
 * @param		[in] test_port 测试端口
 * @return		ret：0-测试失败  1-测试成功
 * @warning		无
 */
uint16_t factory_test(uint16_t test_type, uint16_t test_port)
{
    int32_t ret = -1;

    if ((g_factory_test != FACTORY_MODE_PCB_TEST) && (g_factory_test != FACTORY_MODE_DEV_TEST))
    {
        return FAIL;
    }

    if (g_factory_test == FACTORY_MODE_PCB_TEST)
    {
        switch (test_type)
        {
        case RS485_TEST:
            ret = factory_rs485_test(test_port);
            break;
        case CAN_TEST:
            ret = factory_can_test();
            break;
        case DI_TEST:
        case DO_TEST:
            ret = factory_di_do_test(test_type, test_port);
            break;
        case FLASH_TEST:
            ret = factory_flash_test();
            break;
        case EEPROM_TEST:
            ret = factory_eeprom_test();
            break;
		case WDT_TEST:
            ret = factory_wdt_test(test_port);
            break;
        default:
            break;
        }
    }
    else if (g_factory_test == FACTORY_MODE_DEV_TEST)
    {
        switch (test_type)
        {
        case RS485_TEST:
            ret = factory_dev_rs485_test(test_port);
            break;
        case CAN_TEST:
            ret = factory_can_test();
            break;
        case DI_TEST:
        case DO_TEST:
            ret = factory_dev_di_do_test(test_type, test_port);
            break;
        case FF_CTRL_TEST:
            ret = factory_dev_ff_test((ff_test_e)test_port);
            break;
        case IO_EXT_TEST:
            ret = factory_dev_io_extern_di_do_test(test_port);
            break;
        default:
            break;
        }
    }

    sdk_log_d("factor mode:%d test_type:%d, test_port:%d, ret:%d", g_factory_test, test_type, test_port, ret);
    if (ret == RET_ERR)
    {
        return FAIL;
    }
    else
    {
        return SUCCESS;
    }
}

factory_mode_e factory_test_task_loop(void)
{
    if (g_factory_test == ON)
    {
        if ((g_rs485_test[MODBUS_TEST_CH1] == 1) || (g_rs485_test[MODBUS_TEST_CH2] == 1) || (g_rs485_test[MODBUS_TEST_CH3] == 1) || (g_rs485_test[MODBUS_TEST_CH4] == 1))
        {
            factory_rs485_rsp();
        }
    }

    return g_factory_test;
}
