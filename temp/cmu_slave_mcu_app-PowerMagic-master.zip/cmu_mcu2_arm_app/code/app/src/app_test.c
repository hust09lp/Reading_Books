#include "peripheral_task.h"

#include "sdk.h"
#include "sdk_core.h"

#define TICK_TIMER_TEST_ENABLE          0
#define EXT_IO_TEST_ENABLE              0
#define FIRE_FIGHTING_TEST_ENABLE       0
#define SYS_MUTEX_SEM_TEST_ENABLE       0
#define TEMPER_HUMI_TEST_ENABLE         0
#define CAN_TEST_ENABLE                 0
#define BOOL_FILTER_TEST_ENABLE         0
#define RANGE_CHECK_TEST_ENABLE         0
#define SIG_KEEP_TEST_ENABLE            1

#if TICK_TIMER_TEST_ENABLE
#include "tick_timer.h"

static void _user_timer_test( void )
{
    tick_timer_handle_t test_usr_timer_hd = tick_timer_create();
    uint16_t test_cnt = 0;

    sdk_log_d("_user_timer_test");

    tick_timer_set_timeout( test_usr_timer_hd, 5000 );
    while (1)
    {
        if( tick_timer_is_timeout( test_usr_timer_hd ) )
        {
            sdk_log_d("test_usr_timer_hd timeout, restart:%d", test_cnt++);
            tick_timer_set_timeout( test_usr_timer_hd, 5000 );
        }
        sdk_os_delay(sdk_os_tick_from_millisecond(1000));
    }
}
#endif

#if EXT_IO_TEST_ENABLE
#include "extern_io.h"
#include "app_modbus.h"
#include "app_cfg.h"

void usr_ext_io_input_lv_change_notify( uint8_t mod_index, uint8_t io_port, bool io_lv )
{
    sdk_log_d("mod_index:%d, io_port:%d, io_lv:%d", mod_index, io_port, io_lv);
    extern_io_set_output_lv( mod_index, io_port, io_lv );
}

void usr_ext_io_mod_online_change_notify( uint8_t mod_index, bool online )
{
    sdk_log_d("mod_index:%d, online:%d", mod_index, online);
}

static void _user_io_extern_test( void )
{
    sdk_log_d("_user_io_extern_test");

    app_modbus_rtu_init( EXT_IO_MODBUS_INDEX, MOD_SLAVE_ADDR_BAT1_BOX_IO_EXT, 9600);	  	
	app_modbus_connect( EXT_IO_MODBUS_INDEX );
    app_modbus_response_timeout_set( EXT_IO_MODBUS_INDEX, 200);

    if( 0 != extern_io_init( EXT_IO_MODBUS_INDEX, 9600, false, usr_ext_io_input_lv_change_notify , usr_ext_io_mod_online_change_notify ))
    {
        sdk_log_d("extern_io_init error!!!");
        return;
    }

    extern_io_set_mod_enable( 0, true, 1 );
    extern_io_set_mod_enable( 1, true, 2 );
    extern_io_set_mod_enable( 2, true, 3 );
    extern_io_set_mod_enable( 3, true, 4 );

    uint8_t set_io_port = 0;
    bool    set_io_lv   = false;

    while(1)
    {
        // extern_io_task_loop();
        // sdk_os_delay(sdk_os_tick_from_millisecond(10));

        extern_io_set_output_lv_sync( 3, set_io_port, set_io_lv );
        set_io_port++;
        if ( set_io_port >= 8 )
        {
            set_io_port = 0;
            set_io_lv = !set_io_lv;
        }

        sdk_os_delay(sdk_os_tick_from_millisecond(500));
    }
}
#endif

#if TEMPER_HUMI_TEST_ENABLE
#include "temper_humi.h"

#define TEMPER_HUM_RS485_INDEX      MODBUS_INDEX4

static void _usr_temper_humi_dat_update_callback( uint8_t dev_index, int16_t temper, uint16_t humi, bool drying_sta, bool dev_warning )
{
    sdk_log_d("dev index:%d, temper:%d, humi:%d, drying_sta:%d, dev_warning:%d", dev_index, temper, humi, drying_sta, dev_warning );
}

static void _usr_temper_humi_online_change_callback( uint8_t dev_index, bool online )
{
    int16_t  temper = 0;
    uint16_t humi = 0;
    bool drying_sta;
    sdk_log_d("%s dev index:%d, online:%d", __FUNCTION__, dev_index, online );
    // temper_humi_get_temp_humi_sta( 0, &temper, &humi, &drying_sta);
    sdk_log_d("temper:%d, humi:%d", temper, humi );
}

static void _usr_temper_humi_test( void )
{

    int ret = app_modbus_rtu_init( TEMPER_HUM_RS485_INDEX , 1, 9600);
    sdk_log_d( "app_modbus_rtu_init ret:%d!!!", ret );

    if( 0 != ret)
    {
        sdk_log_d( "extern_io_init rtu init error!!!" );
        return;
    }
	app_modbus_connect( TEMPER_HUM_RS485_INDEX );
    app_modbus_response_timeout_set(TEMPER_HUM_RS485_INDEX, 200);

    if( 0 != temper_humi_init(  TEMPER_HUM_RS485_INDEX , _usr_temper_humi_online_change_callback, _usr_temper_humi_dat_update_callback ))
    {
        sdk_log_e("temper_humi_init error!!!", __FUNCTION__);
        return;
    }

    temper_humi_set_dev_enable( 0, true, 1 );
    temper_humi_set_humi_setting( 0, 85, 10 );

    while (1)
    {
        temper_humi_task_loop();
        sdk_os_delay(sdk_os_tick_from_millisecond(10));
    }
}
#endif


#if FIRE_FIGHTING_TEST_ENABLE

#include "fire_fighting2.h"

int32_t fire_fighting2_init2( modbus_idx_t modbus_idx );

static void _usr_fire_fighting2_test( void )
{
    fire_fighting2_init2( FIRE_FIGHTING_MODBUS_INDEX );

    while( 1 )
    {
        fire_fighting2_task_loop();
        sdk_os_delay(sdk_os_tick_from_millisecond(1000));
    }
}
#endif

#if SYS_MUTEX_SEM_TEST_ENABLE

static sdk_os_mutex_id_t s_test_mutex = NULL ;
static sdk_os_sem_id_t test_sem_id = NULL;

#define MUTEX_DEBUG     1
#define SEM_DEBUG       0

uint32_t thread1_stack[1024/2];
uint32_t thread2_stack[1024/2];

static void _usr_sem_mutex_test_thread1( void *arg );
static void _usr_sem_mutex_test_thread2( void *arg );

static void _usr_mutex_test_init( void );
static void _usr_mutex_test_lock( void );
static void _usr_mutex_test_unlock( void );

static void _usr_sem_test_acquire( void );
static void _usr_sem_test_init( void );

sdk_os_thread_attr_tab_t _usr_test_thread1_attr = {
    .thread_attr = {
                        "_usr_test_thread1",
                        0,
                        NULL,
                        0,
                        10,
                        (void *)thread1_stack,
                        sizeof(thread1_stack),
                        OS_APP_PRIORITY_3,
                        0,
                    },
    .func = _usr_sem_mutex_test_thread1,
    .thread_id = NULL,
};
sdk_os_thread_attr_tab_t _usr_test_thread2_attr = {
    .thread_attr = {
                        "_usr_test_thread2",
                        0,
                        NULL,
                        0,
                        10,
                        (void *)thread2_stack,
                        sizeof(thread2_stack),
                        OS_APP_PRIORITY_3,
                        0,
                    },
    .func = _usr_sem_mutex_test_thread2,
    .thread_id = NULL,
};

static void _usr_sem_mutex_test_thread1( void *arg )
{
    sdk_log_d("%s", __FUNCTION__);

#if MUTEX_DEBUG
        _usr_mutex_test_init();
        _usr_mutex_test_lock();
        _usr_mutex_test_lock();
#endif

    sdk_log_d("%s1", __FUNCTION__);

#if SEM_DEBUG
        _usr_sem_test_init();
        _usr_sem_test_acquire();
#endif

    while(1)
    {
        sdk_os_delay(sdk_os_tick_from_millisecond(1000));
    }
}

static void _usr_sem_mutex_test_thread2( void *arg )
{
    sdk_log_d("%s", __FUNCTION__);

    sdk_os_delay(sdk_os_tick_from_millisecond(1000));
    while(1)
    {
#if MUTEX_DEBUG
        sdk_log_d("%s mutex unlock", __FUNCTION__);
        _usr_mutex_test_unlock();
        sdk_log_d("%s mutex try lock", __FUNCTION__);
        _usr_mutex_test_lock();
        sdk_log_d("%s mutex locked", __FUNCTION__);
#endif

#if SEM_DEBUG
        _usr_sem_test_acquire();
#endif
        sdk_os_delay(sdk_os_tick_from_millisecond(1000));
    }
}

void _usr_sem_mutex_test_thread_init( void )
{
    int32_t ret = 0;

    ret = sdk_os_thread_new(1, &_usr_test_thread1_attr);
    if ( 0 > ret )
    {
        sdk_log_e( "%s, _usr_test_thread1 create fail, ret:%d ", __FUNCTION__, ret);
        return;
    }
    sdk_log_d( "_usr_test_thread1 create success");
    
    ret = sdk_os_thread_new(1, &_usr_test_thread2_attr);
    if ( 0 > ret )
    {
        sdk_log_e( "%s, _usr_test_thread2 create fail, ret:%d ", __FUNCTION__, ret);
        return;
    }
    sdk_log_d( "_usr_test_thread2 create success");
    
    sdk_log_d("%s success", __FUNCTION__);  

    while(1)
    {
        sdk_os_delay(sdk_os_tick_from_millisecond(1000));
    }  
}

static void _usr_mutex_test_unlock( void )
{
    int ret = sdk_os_mutex_release( s_test_mutex );
    if( ret != 0 )
    {
        sdk_log_e( "unlock mutex error" );
        return;
    }
    sdk_log_d( "unlock mutex success" );
}

static void _usr_mutex_test_lock( void )
{
    int ret = sdk_os_mutex_acquire( s_test_mutex, SF_MUTEX_WAIT_FOREVER );
    if( ret != 0 )
    {
        sdk_log_e( "lock mutex error" );
        return;
    }
    sdk_log_d( "lock mutex success" );
}

static void _usr_mutex_test_init( void )
{
    sdk_os_mutex_attr_t test_mutex_attr = {
        .name = "test_mutex"
    };

    s_test_mutex = sdk_os_mutex_new( &test_mutex_attr );
    if ( NULL == s_test_mutex )
    {
        sdk_log_e( "%s create mutex error!!!", __FUNCTION__ );
        return;
    }

    sdk_log_d("%s success", __FUNCTION__);    
}

static void _usr_sem_test_acquire( void )
{
    int32_t ret = sdk_os_sem_acquire( test_sem_id, 0 );
    if( ret != 0 )
    {
        sdk_log_e( "sdk_os_sem_acquire error!!!" );
    }
    else
    {
        sdk_log_e( "sdk_os_sem_acquire success!!!" );
    }
}

static void _usr_sem_test_init( void )
{
    sdk_os_sem_attr_t sem_attr = {
        .name = "test-sem"
    };

    test_sem_id = sdk_os_sem_new( 1 , &sem_attr );
    if ( NULL == test_sem_id )
    {
        sdk_log_e( "create test sem error!!!" );
        return ;
    }

    sdk_log_d("%s success", __FUNCTION__);    
    
}
#endif

#if CAN_TEST_ENABLE
#include "cup_sofar_can.h"
#include "num_trans.h"

#include "sdk.h"
#include "sdk_core.h"


void can_test_init( void )
{
    int32_t ret;

    ret = sdk_can_open( CAN_ID_1 );
    if( ret < 0 )    
    {
        sdk_log_e("%s open error!!!", __FUNCTION__);
        return ;
    }

    sdk_can_cfg_t can_cfg = {
        .baud = 500 * 1000,
        .mode = SDK_CAN_MODE_NORMAL
    };

    ret = sdk_can_setup( CAN_ID_1, &can_cfg );
    if( ret < 0 )    
    {
        sdk_log_e("%s setup error!!!", __FUNCTION__);
        return ;
    }

    ret = cup_sofar_can_init();
    if( ret < 0 )    
    {
        sdk_log_e("%s cup_sofar_can_init error!!!", __FUNCTION__);
        return ;
    }

    sdk_log_d("%s success!!!", __FUNCTION__);

    return;
}

void can_send_test( void )
{
    static uint32_t last_tick = 0;
    uint32_t now_tick = sdk_tick_get();

    if ((now_tick - last_tick) >= 2000)
    {
        last_tick = now_tick;
        can_id_t can_id = {
            .src_addr = 1,
            .dst_addr = 2,
            .fun_code = 1,
            .prio = 6,
            .addr = 0
        };
        
        if ( 0 > cup_sofar_can_send( CAN_ID_1, &can_id, "\x01\x02\x03\x04" , 4  ))
        {
            sdk_log_e("cup_sofar_can_send error");
        }else{
            sdk_log_d("cup_sofar_can_send success");
        }
    }
}

void can_recv_test( void )
{
    can_id_t rx_can_id = {0};
    uint8_t rx_buf[100] = {0};
    int32_t rx_len = 0;

    if( CAN_DATA_COMPLETE == cup_sofar_can_rev( CAN_ID_1, 20, &rx_can_id, rx_buf, &rx_len ) ) 
    {
        sdk_log_d( "rx src_addr:%d, dst_addr:%d, fun_code:%d, reg addr:%d" , 
                    rx_can_id.src_addr, rx_can_id.dst_addr, rx_can_id.fun_code, rx_can_id.addr  );
        util_print_hex_dat( "can dat:", rx_buf, rx_len, 10, true );
    }
}

void can_test( void )
{
    can_test_init();

    while (1)
    {
        can_recv_test();
        // can_send_test();

        sdk_os_delay(sdk_os_tick_from_millisecond(20));
    }
    
}
#endif


#if BOOL_FILTER_TEST_ENABLE
#include "bool_filter.h"
#include "app_modbus.h"
#include "extern_io.h"

void bool_filter_test( void )
{
    filter_setting_t true_filter_setting  = { .cnt = 3,  .tm_ms = 10000 } ;
    filter_setting_t false_filter_setting = { .cnt = 1, .tm_ms = 5000 } ;
    bool_filter_hd pin_bool_filter = NULL;
    
    static bool_val_e filter_warn1_lv = BOOL_VAL_FALSE;
    bool_val_e warn1_lv = BOOL_VAL_FALSE;
    int32_t di_warn1_lv = 0;

    sdk_log_d("%s", __FUNCTION__);

    bool_filter_init();

    pin_bool_filter = bool_filter_create( FILTER_TYPE_TM_AND_CNT, &true_filter_setting , &false_filter_setting );
    bool_filter_set_val( pin_bool_filter, BOOL_VAL_FALSE );
    
    while( 1 )
    {
        di_warn1_lv = sdk_dido_read( DI_FF_WARN1 );
        bool_filter_input( pin_bool_filter, di_warn1_lv );

        if ( warn1_lv != bool_filter_get_val( pin_bool_filter ) )
        {
            warn1_lv = bool_filter_get_val( pin_bool_filter );
            sdk_log_d("----" );
            sdk_log_d("warn1_lv change:%d", warn1_lv );
            sdk_log_d("----" );
        }
        sdk_os_delay(sdk_os_tick_from_millisecond(10));

    }
}
#endif


#if RANGE_CHECK_TEST_ENABLE
#include "range_check.h"

static int _range_check_test( void )
{
    #define POINT_NUM       1

    static point_t test_points[ POINT_NUM ] = {
        /* range id 0 */
        { .point_val = 20, .ret_diff_val = 0 },
    };

    range_setting_t test_range_setting = {
        .trig_dir            = RANGE_TRIG_DIR_DISCREASE,
        .trig_valid_cnt      = 3,
        .ret_diff_valid_cnt  = 3,
        .p_cb_arg            = NULL
    };

    range_handle_t test_range_handle = range_check_create( test_points, POINT_NUM, &test_range_setting );
    if( test_range_handle == NULL )
    {
        sdk_log_d("test_range_handle == NULL");
        return -1;
    }

    while (1)
    {
        range_check_input( test_range_handle, 20 );
        sdk_log_d( "---input val:%d---range id:%d", 20, range_get_range_id( test_range_handle ) );
    }
}
#endif

#include "dh_ctrl.h"
#include "app_modbus.h"
#include "tick_timer.h"
#include "extern_io.h"

void bat_door_sta_change( uint8_t mod_index, uint8_t io_port, bool io_lv )
{
    sdk_log_d("mod_index:%d, io_port:%d, io_lv:%d", mod_index, io_port, io_lv);

    if ( io_port == EXT_IO_DI_BAT_DOOR_PORT )
    {
        dehumi_ctrl_op( mod_index, (io_lv == true)? DEV_OP_PAUSE: DEV_OP_RESUME);
    }
}

void dehumi_ctrl_test( void )
{
    tick_timer_init();
    
    app_modbus_rtu_init( DRYER_MODBUS_INDEX, MOD_SLAVE_ADDR_TEMPER_HUMI, 9600);	  	
	app_modbus_connect( DRYER_MODBUS_INDEX );
    app_modbus_response_timeout_set( DRYER_MODBUS_INDEX, 200);

    dehumi_ctrl_init( DRYER_MODBUS_INDEX );
    dehumi_ctrl_set_num( 4 );


    if( 0 != extern_io_init( EXT_IO_MODBUS_INDEX, 9600, false, bat_door_sta_change , NULL ))
    {
        sdk_log_d("extern_io_init error!!!");
        return;
    }

    extern_io_set_mod_enable( 0, true, 1 );
    extern_io_set_mod_enable( 1, true, 2 );
    extern_io_set_mod_enable( 2, true, 3 );
    extern_io_set_mod_enable( 3, true, 4 );

    while (1)
    {
        extern_io_task_loop();
        dehumi_ctrl_loop_task();
        sdk_os_delay(sdk_os_tick_from_millisecond(10));
    }
    
}

#if SIG_KEEP_TEST_ENABLE

#include "sig_keeper.h"

void sig_keep_test( void )
{
    sig_keeper_hd test_sig_keeper_hd = NULL;

    bool_sig_keeper_init();

    sig_keeper_setting_t sig_keeper_setting = { .hig_prio_sig = true, .keep_tm_ms = 60000 };

    test_sig_keeper_hd = bool_sig_keeper_create( &sig_keeper_setting );

    static bool_val_e input_val      = BOOL_VAL_INVALID;        //< 仿真时改变这个数值
    static bool_val_e last_input_val = BOOL_VAL_INVALID;
    static bool_val_e ret_val        = BOOL_VAL_INVALID;
    static bool_val_e last_ret_val   = BOOL_VAL_INVALID;

    while(1)
    {
        if ( input_val != last_input_val )
        {
            sdk_log_d( "%d, input val:%d", sdk_tick_get(), input_val );
            last_input_val = input_val;
        }

        bool_sig_keeper_input( test_sig_keeper_hd, input_val );
        ret_val = bool_sig_keeper_get( test_sig_keeper_hd );
        if ( ret_val != last_ret_val )
        {
            sdk_log_d( "%d, keep val change:%d", sdk_tick_get(), ret_val );
            last_ret_val = ret_val;
        }
        sdk_os_delay( sdk_os_tick_from_millisecond(10) );
    }
}

#endif

void app_test_init( void )
{
    sig_keep_test();
    // dehumi_ctrl_test();
    // can_test();
    // _usr_sem_mutex_test_thread_init();
    // _usr_fire_fighting2_test();
    // _user_io_extern_test();
    // _usr_temper_humi_test();
    // _user_timer_test();
    // _usr_bat_temper_ctrl_test();
    // _range_check_test();
    // bool_filter_test();

    // while (1);
}
