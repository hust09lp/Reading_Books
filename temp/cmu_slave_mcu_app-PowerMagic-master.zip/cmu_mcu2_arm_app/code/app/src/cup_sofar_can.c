/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     cup_sofar_can.c
  * @brief    can module
  * @company  SOFARSOLAR
  * @author   DYM
  * @note     
  * @version  V01
  * @date     2023/03/02
  */
/*****************************************************************************/

#include "cup_sofar_can.h"
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "sdk_can.h"
#include "sdk.h"
#include "sdk_core.h"
#ifdef EBI_1725K
#include "can5_bus.h"
#endif
// #include "lal_can.h"

#define CAN_WAIT_MUTEX_TIME                                                (0)

static uint8_t g_sofar_can_ver[SOFAR_CAN_VER_LEN] = "V1.0";
static int8_t g_debug_flag = 0;

can_rev_comm_t g_can_rev_comm[SOFAR_CAN_TRS_BUF_NUMS] = {0};

const uint8_t CRC16_high[] = {

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,

       0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,

       0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,

       0x00, 0xC1, 0x81, 0x40

};

const uint8_t CRC16_low[] = {

       0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06, 0x07, 0xC7,

       0x05, 0xC5, 0xC4, 0x04, 0xCC, 0x0C, 0x0D, 0xCD, 0x0F, 0xCF, 0xCE, 0x0E,

       0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09, 0x08, 0xC8, 0xD8, 0x18, 0x19, 0xD9,

       0x1B, 0xDB, 0xDA, 0x1A, 0x1E, 0xDE, 0xDF, 0x1F, 0xDD, 0x1D, 0x1C, 0xDC,

       0x14, 0xD4, 0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3,

       0x11, 0xD1, 0xD0, 0x10, 0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3, 0xF2, 0x32,

       0x36, 0xF6, 0xF7, 0x37, 0xF5, 0x35, 0x34, 0xF4, 0x3C, 0xFC, 0xFD, 0x3D,

       0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A, 0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38,

       0x28, 0xE8, 0xE9, 0x29, 0xEB, 0x2B, 0x2A, 0xEA, 0xEE, 0x2E, 0x2F, 0xEF,

       0x2D, 0xED, 0xEC, 0x2C, 0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26,

       0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 0xA0, 0x60, 0x61, 0xA1,

       0x63, 0xA3, 0xA2, 0x62, 0x66, 0xA6, 0xA7, 0x67, 0xA5, 0x65, 0x64, 0xA4,

       0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F, 0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB,

       0x69, 0xA9, 0xA8, 0x68, 0x78, 0xB8, 0xB9, 0x79, 0xBB, 0x7B, 0x7A, 0xBA,

       0xBE, 0x7E, 0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 0xB4, 0x74, 0x75, 0xB5,

       0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71, 0x70, 0xB0,

       0x50, 0x90, 0x91, 0x51, 0x93, 0x53, 0x52, 0x92, 0x96, 0x56, 0x57, 0x97,

       0x55, 0x95, 0x94, 0x54, 0x9C, 0x5C, 0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E,

       0x5A, 0x9A, 0x9B, 0x5B, 0x99, 0x59, 0x58, 0x98, 0x88, 0x48, 0x49, 0x89,

       0x4B, 0x8B, 0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,

       0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42, 0x43, 0x83,

       0x41, 0x81, 0x80, 0x40
};

sdk_os_mutex_id_t can1_busy = NULL; 

/**
 * @brief   打印数据
 * @param   [in] p_data  需要打印的数据
 * @param   [in] len  需要打印的数据长度
 * @note    
 * @return  返回执行结果 空
 */
static void data_print(uint8_t *p_data, int32_t len)
{
    if (g_debug_flag == 1)
    {
        sdk_log_d("\n data start \n");
        for (uint8_t i = 0; i < len; i++)
        {
            sdk_log_d("p_data = %02x ", p_data[i]);
        }
        sdk_log_d("\r");
        sdk_log_d("\n data end \n");
    }
}

/**
 * @brief   crc16的计算值
 * @param   [in] p_data  需要发送的数据
 * @param   [in] len  需要发送的数据长度
 * @note    
 * @return  返回执行结果 0:正常；<0:异常
 */
uint16_t crc16(uint8_t *p_data, int32_t len)
{
    uint8_t ch_crc_hi = 0xFF; // 高CRC字节初始化
    uint8_t ch_crc_lo = 0xFF; // 低CRC字节初始化
    uint16_t w_index; // CRC循环中的索引

    while (len--)
	{
    	// 计算CRC
    	w_index = ch_crc_lo ^ *p_data++;
    	ch_crc_lo = ch_crc_hi ^ CRC16_high[w_index];
    	ch_crc_hi = CRC16_low[w_index] ;
    }

    return ((ch_crc_hi << 8) | ch_crc_lo);
}

/**
 * @brief   计算一包数据可以分成几帧数据
 * @param   [in] pack_len 需要分包数据的长度
 * @param   [in] frame_len 一帧数据的长度
 * @note    
 * @return  返回执行结果 0:正常，可以分帧数量；<0:异常
 */
static uint8_t get_frame_num(uint16_t pack_len, uint16_t frame_len)
{
    uint8_t frame_num = 0;

    frame_num = pack_len / frame_len;
    if((pack_len % frame_len) != 0)
    {
        frame_num++;
    }

    return(frame_num);
}

/**
 * @brief   发送CAN数据 长帧
 * @param   [in] index  CAN 口编号
 * @param   [in] can_id  CAN ID信息
 * @param   [in] txframe  CAN 通讯信息
 * @param   [in] p_data  需要发送的数据
 * @param   [in] len  需要发送的数据长度
 * @note    调用此函数之前需要APP层自己调用打开CAN的SDK接口
 * @return  返回执行结果 0:正常；<0:异常
 */
static int32_t long_data_send(uint32_t index, can_id_t *can_id, sdk_can_frame_t *txframe, uint8_t *p_data, int32_t len)
{
    int32_t rc = 0;
    uint8_t offset = 0;
    uint8_t frame_num = 0;
    uint16_t crc_check = 0;
    uint16_t num = 0;

    if ((can_id == NULL) || (p_data == NULL) || (len < 0) || (can_id == NULL))
    {
        return(CAN_RET_GINSENG);
    }

    //CRC计算
    crc_check = crc16(p_data, len);
    p_data[len] = crc_check & 0xff;
    p_data[len + 1] = (crc_check >> 8) & 0xff;
    
    if ((can_id->fun_code == FUN_FILE_DATA_READ) || (can_id->fun_code == FUN_UPDATE_DATA_TRS) 
        || (can_id->fun_code == FUN_FILE_DATA_WRITE))      // 文件数据帧
    {
        offset = 4;
        txframe->data[0] = 0;
        txframe->data[1] = (can_id->addr)&0xff;
        txframe->data[2] = ((can_id->addr)>>8)&0xff;
        txframe->data[3] = len&0xff;
        txframe->data[4] = (len>>8)&0xff;
        memcpy(&(txframe->data[5]), p_data, 3);        
    }
    else    //点表数据帧
    {
        offset = 3;
        txframe->data[0] = 0;
        txframe->data[1] = (can_id->addr)&0xff;
        txframe->data[2] = ((can_id->addr)>>8)&0xff;
        txframe->data[3] = len>>1;
        memcpy(&(txframe->data[4]), p_data, 4);                
    }

    data_print(txframe->data, 8);   //打印数据

    sdk_can_write(index, txframe, 1);    // 加锁

    // 计算有几帧数据
    frame_num = get_frame_num((len + offset + 2), 7);

    //后续帧数据
    for (num = 1; num < frame_num; num++)
    {
        if (num == (frame_num - 1)) //最后一帧
        {
            txframe->data[0] = 0xff;
        }
        else
        {
            txframe->data[0] = num;
        }
        memcpy(&(txframe->data[1]), &(p_data[(7 - offset) + 7 * (num - 1)]), 7);

        data_print(txframe->data, 8);   //打印数据

        sdk_can_write(index, txframe, 1);    // 加锁
    }

    return(rc);
}

/**
 * @brief   接收数据缓存区获取
 * @param   [in] txframe  CAN 通讯信息
 * @return  返回执行结果 0:正常；<0:异常
 */
static int8_t buff_index_get(sdk_can_frame_t *txframe)
{
    int8_t rc = 0;
    uint8_t index = 0;
    uint8_t num = 0;

    if (txframe == NULL)
    {
        return(-1);
    }   

    for (num = 0; num < SOFAR_CAN_TRS_BUF_NUMS; num++)
    {
        if (g_can_rev_comm[num].comm_state != SOFAR_CAN_RET_EMPTY)
        {
            if ((g_can_rev_comm[num].can_frame_id.id_val & 0x1fffffff) == txframe->id)
            {
                index = num;
                break;
            }
        }
    } 

    if (index >= SOFAR_CAN_TRS_BUF_NUMS)
    {
        rc = -1;
    }   
    else
    {
        rc = index;
    }

    return(rc);
}


/**
 * @brief   接收数据组包
 * @param   [in] can_id  CAN ID信息
 * @param   [in] txframe  CAN 通讯信息
 * @param   [in] p_data  需要发送的数据
 * @param   [in] len  需要发送的数据长度
 * @note    调用此函数之前需要APP层自己调用打开CAN的SDK接口
 * @return  返回执行结果 0:正常；<0:异常
 */
static int32_t long_data_pack(can_id_t *can_id, sdk_can_frame_t *txframe, uint8_t *p_data, int32_t *len)
{
    int32_t rc = CAN_RET_TRUE;
    uint8_t offset = 0;
    uint16_t crc_check = 0;
    uint16_t read_check = 0;
    uint16_t num = 0;
    uint8_t index = 0;

    if ((can_id == NULL) || (p_data == NULL) || (len < 0) || (can_id == NULL))
    {
        return(CAN_RET_GINSENG);
    }

    // 判断长帧的帧类型
    if ((can_id->fun_code == FUN_FILE_DATA_READ) || (can_id->fun_code == FUN_UPDATE_DATA_TRS) 
        || (can_id->fun_code == FUN_FILE_DATA_WRITE))      // 文件数据帧
    {
        offset = 4;       
    }
    else    //点表数据帧
    {
        offset = 3;               
    }

    if (txframe->data[0] == 0)  // 检测是否是第一帧数据
    {
        index = buff_index_get(txframe);
		if(index > 0)
		{
			memset(&(g_can_rev_comm[index]), 0, sizeof(can_rev_comm_t));
		}

        // 将第一帧数据放在空缓冲区
        for (num = 0; num < SOFAR_CAN_TRS_BUF_NUMS; num++)
        {
            if (g_can_rev_comm[num].comm_state == SOFAR_CAN_RET_EMPTY)
            {
                index = num;
                break;
            }
        }

        if (index >= SOFAR_CAN_TRS_BUF_NUMS)
        {
            index = 0;
            memset(&(g_can_rev_comm[index]), 0, sizeof(can_rev_comm_t));
        }

		(g_can_rev_comm[index].rev_num)++;

        // 装载第一帧数据
        g_can_rev_comm[index].can_frame_id.id_val = txframe->id; // 记录CAN ID信息
        // memcpy(&(g_can_rev_comm[index].can_frame_id.id_val), &(txframe->id), 4);
        g_can_rev_comm[index].addr = txframe->data[1] | (txframe->data[2] << 8); // 记录偏移地址

        if (offset == 4)  // 文件数据
        {
            g_can_rev_comm[index].rev_len = txframe->data[3] | (txframe->data[4] << 8); // 记录数据长度
            memcpy(&(g_can_rev_comm[index].rev_data[0]), &(txframe->data[5]), 3);     // 记录数据
        }
        else    // 点表数据
        {
            //g_can_rev_comm[index].rev_len = txframe->data[2] << 1; // 记录数据长度??? 
			g_can_rev_comm[index].rev_len = txframe->data[3] << 1;
            memcpy(&(g_can_rev_comm[index].rev_data[0]), &(txframe->data[4]), 4);     // 记录数据
        }

        g_can_rev_comm[index].comm_state = SOFAR_CAN_RET_WAIT;
		rc = CAN_RET_TRUE;
    }
    else if (txframe->data[0] == 0xff)  // 检测是否是最后一帧数据
    {
        rc = buff_index_get(txframe); // 获取缓存区存储位置
        if (rc < 0)
        {
            return(CAN_RET_RECERR);
        }
        else
        {
            index = rc;
        }

        num = (g_can_rev_comm[index].rev_num)++;
        memcpy(&(g_can_rev_comm[index].rev_data[(7 - offset) + 7 * (num - 1)]),  &(txframe->data[1]), 7);

        //CRC计算
        crc_check = crc16(&(g_can_rev_comm[index].rev_data[0]), g_can_rev_comm[index].rev_len);
        read_check = g_can_rev_comm[index].rev_data[g_can_rev_comm[index].rev_len] | (g_can_rev_comm[index].rev_data[g_can_rev_comm[index].rev_len + 1] << 8);
        if (crc_check == read_check)
        {
            can_id->addr = g_can_rev_comm[index].addr;
            *len = g_can_rev_comm[index].rev_len;
            memcpy(p_data, &(g_can_rev_comm[index].rev_data[0]), *len);

            rc = CAN_DATA_COMPLETE;
			memset(&(g_can_rev_comm[index]), 0, sizeof(can_rev_comm_t));
        }
        else
        {
            rc = CAN_RET_CRC_ERR;
        }
        g_can_rev_comm[index].comm_state = SOFAR_CAN_RET_EMPTY;
		memset(&(g_can_rev_comm[index]), 0, sizeof(can_rev_comm_t));
    }
    else    // 中间帧数据
    {
        rc = buff_index_get(txframe); // 获取缓存区存储位置
		
        if (rc < 0)
        {
            rc = CAN_RET_RECERR;
        }
        else
        {
            index = rc;
            num = (g_can_rev_comm[index].rev_num)++;
            memcpy(&(g_can_rev_comm[index].rev_data[(7- offset) + 7 * (num - 1)]),  &(txframe->data[1]), 7);


            rc = CAN_RET_TRUE;// ???
        }      
    }
  
    return(rc);
}

/**
 * @brief   发送CAN数据接收
 * @param   [in] index  CAN 口编号
 * @param   [in] timeout_ms  读取超时时间设置
 * @param   [out] can_id  接收数据的CAN ID信息
 * @param   [out] p_data  接收的数据
 * @param   [out] len  接收数据的长度
 * @note    调用此函数之前需要APP层自己调用打开CAN的SDK接口，收到完整数据包之后将数据返回
 * 			返回的数据根据不同的功能码有以下不同的情况（只有数据包时的数据帧p_data才仅是真正的数据）
 * 			p_data:数据帧时对应的是解析组包之后的数据；请求和应答帧时是应答和请求的帧数据内容
 * @return  返回执行结果 0:正常；<0:异常
 */
int32_t cup_sofar_can_rev(uint32_t index, int32_t timeout_ms, can_id_t *can_id, uint8_t *p_data, int32_t *len)
{
    can_frame_id_u can_frame_id;
	sdk_can_frame_t txframe;
    int32_t rc = 0;

    if ((can_id == NULL) || (p_data == NULL) || (len == NULL))
    {
        return(CAN_RET_GINSENG);
    }

    rc = sdk_can_read(index, &txframe, 1, timeout_ms); 
    if (rc > 0)     // 接收到CAN的数据
    {
        data_print(txframe.data, 8);   //打印数据

        can_frame_id.id_val = txframe.id; 

        can_id->src_addr = can_frame_id.bit.src_addr;
        can_id->src_type = can_frame_id.bit.src_type;
        can_id->dst_addr = can_frame_id.bit.dst_addr;
        can_id->dst_type = can_frame_id.bit.dst_type;
        can_id->fun_code = can_frame_id.bit.fun_code;
        can_id->type = can_frame_id.bit.type;
        can_id->prio = can_frame_id.bit.prio; 
		

        if (can_id->type == 1)     // 数据帧内容
        {
            if (can_frame_id.bit.flag == 1)    //长帧数据
            {
                rc = long_data_pack(can_id, &txframe, p_data, len);
            }
            else    //短帧数据
            {
                if ((can_id->fun_code == FUN_FILE_DATA_READ) || (can_id->fun_code == FUN_UPDATE_DATA_TRS) 
                    || (can_id->fun_code == FUN_FILE_DATA_WRITE))      // 文件数据帧
                {
                    can_id->addr = txframe.data[0] | (txframe.data[1] << 8);
                    *len = txframe.data[2] | (txframe.data[3] << 8);
                    memcpy(p_data, &(txframe.data[4]), 4);
                }
//				else if(can_id->fun_code == AUTO_HEART_BEAT)
//				{
//					*len = 8;
//					memcpy(p_data, &(txframe.data[0]), *len);
//				}
                else    //点表数据帧
                {
                    can_id->addr = txframe.data[0] | (txframe.data[1] << 8);
                    *len = txframe.data[2]<<1;
                    memcpy(p_data, &(txframe.data[3]), 5);                
                }
                rc = CAN_DATA_COMPLETE;
            }
        }
        else    // 非数据帧内容
        {
            memcpy(p_data, &(txframe.data[0]), 8);
            *len = txframe.len;
            rc = CAN_DATA_COMPLETE;
        }
    }
    else        //没有读取到数据
    {
        rc = CAN_RET_TIMEOUT;
    }

    return(rc);    
}


/**
 * @brief   发送CAN数据打包发送
 * @param   [in] index  CAN 口编号
 * @param   [in] can_id  CAN ID信息
 * @param   [in] p_data  需要发送的数据
 * @param   [in] len  需要发送的数据长度
 * @note    调用此函数之前需要APP层自己调用打开CAN的SDK接口,
 * @return  返回执行结果 0:正常；<0:异常
 */
int32_t cup_sofar_can_send(uint32_t index, can_id_t *can_id, uint8_t *p_data, int32_t len)
{
	can_frame_id_u can_frame_id;
	sdk_can_frame_t txframe;
    sdk_os_mutex_id_t mutex_id = 0;
    int32_t rc = 0;

	if(index == CAN1_PORT)
    {
        mutex_id = can1_busy;
    }
#ifdef EBI_1725K
	else if(index == CAN5_PORT)
	{
        mutex_id = can5_busy;
	}
#endif
    if ((can_id == NULL) || (p_data == NULL) || (len < 0))
    {
        return (CAN_RET_GINSENG);
    }

    if (len > CAN_SOFAR_DATA_MAXNUMS)
    {
        return (CAN_RET_GINSENG);
    }

    can_frame_id.bit.src_addr = can_id->src_addr;
    can_frame_id.bit.src_type = can_id->src_type;
    can_frame_id.bit.dst_addr = can_id->dst_addr;
    can_frame_id.bit.dst_type = can_id->dst_type;
    can_frame_id.bit.fun_code = can_id->fun_code;
    can_frame_id.bit.type = can_id->type;
    can_frame_id.bit.prio = can_id->prio;   
    can_frame_id.bit.format = 1;    //拓展帧
    txframe.ide = 1;    //拓展帧
	txframe.rtr = 0;    //数据帧

	//sdk_log_i("scan_frame_id = %x\r\n",can_frame_id.id_val);
    if (can_id->type == 1)     // 数据帧内容
    {
        if (len >= 5)    //长帧数据
        {
            can_frame_id.bit.flag = 1;      //  连续性帧
            txframe.id = (can_frame_id.id_val & 0x1fffffff);
            txframe.len = 8;

            rc = sdk_os_mutex_acquire(mutex_id, CAN_WAIT_MUTEX_TIME);
            if(rc == SDK_OS_OK)
            {
                long_data_send(index, can_id, &txframe, p_data, len);
                rc = sdk_os_mutex_release(mutex_id);

                if(rc != SDK_OS_OK)
                {
                    sdk_log_d("sdk_os_mutex_release fail:%d", rc);
                }
            }
            else
            {
                sdk_log_d("get mutex fail len >= 5:%d", rc);
            }
        }
        else    //短帧帧数据
        {
            can_frame_id.bit.flag = 0;      //  非连续性帧
            txframe.id = (can_frame_id.id_val & 0x1fffffff);

            if ((can_id->fun_code == FUN_FILE_DATA_READ) || (can_id->fun_code == FUN_UPDATE_DATA_TRS) 
                || (can_id->fun_code == FUN_FILE_DATA_WRITE))      // 文件数据帧
            {
                txframe.data[0] = (can_id->addr)&0xff;
                txframe.data[1] = ((can_id->addr)>>8)&0xff;
                txframe.data[2] = len&0xff;
                txframe.data[3] = (len>>8)&0xff;
                memcpy(&(txframe.data[4]), p_data, 4);
            }
            else    //点表数据帧
            {
                //txframe.data[0] = (can_id->addr)&0xff;
                //txframe.data[1] = ((can_id->addr)>>8)&0xff;  ???
                //txframe.data[2] = len>>1;
                memcpy(&(txframe.data[0]), p_data, 8); //???
            }
			txframe.len = 8; //???  这里暂时任何人不要动，牵一发而动全身。

            rc = sdk_os_mutex_acquire(mutex_id, CAN_WAIT_MUTEX_TIME);
            if(rc == SDK_OS_OK)
            {
                sdk_can_write(index, &txframe, 1);    // 加锁
                rc = sdk_os_mutex_release(mutex_id);

                if(rc != SDK_OS_OK)
                {
                    sdk_log_d("sdk_os_mutex_release fail:%d", rc);
                }
            }
            else
            {
                sdk_log_d("get mutex fail len < 5:%d", rc);
            }
        }
    }
    else    // 非数据帧内容
    {
        can_frame_id.bit.flag = 0;      //  非连续性帧
        txframe.id = (can_frame_id.id_val & 0x1fffffff); 

        memcpy(&(txframe.data[0]), p_data, 8);
		txframe.len = len; //???

        rc = sdk_os_mutex_acquire(mutex_id, CAN_WAIT_MUTEX_TIME);
        if(rc == SDK_OS_OK)
        {
            sdk_can_write(index, &txframe, 1);    // 加锁
            rc = sdk_os_mutex_release(mutex_id);

            if(rc != SDK_OS_OK)
            {
                sdk_log_d("sdk_os_mutex_release fail:%d", rc);
            }
        }
        else
        {
            sdk_log_d("get mutex fail can_id->type != 1:%d", rc);
        }
    }
    return (rc);
}

/**
 * @brief   CAN 通讯协议初始化（接收状态初始化）
 * @note    在创建CAN通讯任务，初始化时需要调用此函数，防止接收数据时的状态、缓冲区未初始化
 * @return  返回执行结果 0:正常；<0:异常
 */
int32_t cup_sofar_can_init(void)
{
    sdk_os_mutex_attr_t can_mutex_attr = { .name = "can" };

    can1_busy = sdk_os_mutex_new( &can_mutex_attr );
    if( can1_busy == NULL )
    {
        sdk_log_e("%s create can mutex error!!!", __FUNCTION__);
        return -1;
    }
    
    uint8_t index = 0;

    for (index = 0; index < SOFAR_CAN_TRS_BUF_NUMS; index++)
    {
        memset(&(g_can_rev_comm[index]), 0, sizeof(can_rev_comm_t));
    }

    return (0);
}

/** 
 * @brief        版本获取函数
 * @param        [out] p_ver 版本数据存在p_version所指向的地址中，传出参数
 * @param        [in] len 传入版本号字节长度，避免数据超出传入的数组大小 <16
 * @return       [int32_t] 执行结果
 * @retval       >=  版本号的实际长度(必须小于传入的长度) 
 * @retval       < 0 失败原因
 */
int32_t cup_sofar_can_ver_get(uint8_t *p_ver, uint16_t len)
{
    int32_t rc = 0;

    if (len > SOFAR_CAN_VER_LEN)
    {
        rc = -1;
    }
    else
    {
        memcpy(p_ver, g_sofar_can_ver, len);
    }

    return (rc);
}

/** 
 * @brief        打印信息设置函数
 * @param        [in] flag 打印信息设置函数，0不打印，1打印
 * @return       [int32_t] 执行结果
 * @retval       =0  设置成功 
 * @retval       < 0 失败原因
 */
int32_t cup_sofar_can_debug_set(int8_t flag)
{
    g_debug_flag = flag;

    return (0);
}

