#include "peripheral_task.h"
#include "sdk_osif.h"
#include "sdk.h"
#include "sdk_core.h"
#include "sdk_modbus.h"
#include "sdk_dido.h"
#include "sci.h"
#include "electricity_meter.h"
#include "factory_test.h" 

#include "fire_fighting2.h"
#include "bat_tmp_ctrl_api.h"
#include "lc_ctrl.h"
#include "energy_cabinet.h"
#include "app_dido.h"

static void app_work_process(void *argument);
static void app_ff_process(void *argument);
static void _app_backgroud_data_read( void *argument );

void system_info_update2(void);

// 线程优先级
#define SENSOR_TASK_PRIORITY   		OS_APP_PRIORITY_3
#define CAN_TASK_PRIORITY      		OS_APP_PRIORITY_4
#define SCI_TASK_PRIORITY      		OS_APP_PRIORITY_1
#define WORK_TASK_PRIORITY     		OS_APP_PRIORITY_5
#define TIMING_TASK_PRIORITY   		OS_APP_PRIORITY_6
#define SYSMANAGE_TASK_PRIORITY   	OS_APP_PRIORITY_2

#define MODBUS_TIMEOUT 	200					// 485超时时间

//线程堆栈
uint32_t g_app_thread_sensor_stack[1024/2];
uint32_t g_app_thread_can_stack[1024/4];
uint32_t g_app_thread_sci_stack[1024];
uint32_t g_app_thread_work_stack[1024/2];
uint32_t g_app_thread_ff_stack[1024/2];
uint32_t g_app_thread_timing_stack[1024/4];
uint32_t g_app_thread_sysmanage_stack[1024/4];

uint8_t sci_read_buf[255]={0};

uint16_t g_modbus_buf[MODBUS_BUF_LEN]={0};                // MODBUS数据缓存

static uint32_t heartTime[TASK_MAX_NUM];

/**
* @brief		向系统管理线程发送心跳
* @param		[in] ： id 线程id
* @param		无  
* @return		无
* @retval		无
* @warning		无
*/
void sys_send_heartbeat_to_sys_manage(TaskId id)
{
	if (id == TASK_SENSOR)
	{
		heartTime[TASK_SENSOR] = sdk_tick_get();
	}
    else if (id == TASK_CAN)
	{
		heartTime[TASK_CAN] = sdk_tick_get();
	}
	else if (id == TASK_SCI)
	{
		heartTime[TASK_SCI] = sdk_tick_get();
	}
	else if (id == TASK_WORK)
	{
		heartTime[TASK_WORK] = sdk_tick_get();
	}
	else if (id == TASK_TIMMING)
	{
		heartTime[TASK_TIMMING] = sdk_tick_get();
	}
}

/**
* @brief		检查是否有线程超时
* @param		[in] ： id 线程id
* @param		无  
* @return		无
* @retval		无
* @warning		无
*/
static void check_task_stauts(void)
{
	uint8_t   i = 0;
	uint8_t wdg_feed_flag;
	uint32_t tick;
	
	
	tick = sdk_os_tick_from_millisecond(2000);
	wdg_feed_flag = 1;
	for (i=0; i<TASK_MAX_NUM; i++)
	{		
		if ((sdk_tick_get() - heartTime[i]) > tick)		//500tick = 1s , 5000tick=10s  
		{
			wdg_feed_flag = 0;
		}
	}

	if (wdg_feed_flag) 
	{
		//sdk_wdt_feed();	  //喂狗，由内核喂狗，APP不用处理了
	}	
}

/**
* @brief		SCI通信线程
* @param		[in] ： argument 
* @return		无
* @retval		无
* @warning		无
*/
void app_sci_process(void *argument)
{
	int32_t len = 0;

	memset(sci_read_buf,0x00,sizeof(sci_read_buf));
    sdk_log_d("app_sci start\r\n");
    while(1)
    {              
		len = sdk_uart_read(SCI_PORT,sci_read_buf,sizeof(sci_read_buf),500);
		if(len > 0)
		{
			sci_receive_analysis(&inboard_sci,sci_read_buf,len);
		}
        sdk_os_delay(sdk_os_tick_from_millisecond(20));

		if (SF_TRUE == g_factory_test && SF_TRUE == g_wdt_feed_disable_flag)
        {
			//sdk_log_d("等待看门狗复位 .............\r\n");
			sdk_os_delay(sdk_os_tick_from_millisecond(100));
            while (1)
            {
                // 无限循环看门狗复位 
                ;
            }
        }
		sys_send_heartbeat_to_sys_manage(TASK_SCI);
    }
}

/**
* @brief		计时线程
* @param		argument
* @return		无
* @retval		无
* @warning		无
*/
void app_timing_process(void *argument)
{
	while(1)
	{
		sdk_os_delay(sdk_os_tick_from_millisecond(1000));
		sys_send_heartbeat_to_sys_manage(TASK_TIMMING);
	}
}

/**
* @brief		系统管理线程
* @param		argument
* @return		无
* @retval		无
* @warning		无
*/
void app_sysmanage_process(void *argument)
{
	uint8_t cnt_1s = 0;
	static uint16_t reset_count = 0;
	
	while(1)
	{
		if (g_reset_flg)
		{
			reset_count++;
			if(reset_count >100)
			{
				reset_count = 0;
				g_reset_flg = 0;
				sdk_os_delay(sdk_os_tick_from_millisecond(500));
				sdk_sys_reset();
			}
			
		}
		if(cnt_1s++ > 100)
		{
			cnt_1s = 0;
			check_task_stauts();
		}

        app_dido_filter_task_loop();
		sdk_os_delay(sdk_os_tick_from_millisecond(10));
	}
}



sdk_os_thread_attr_tab_t g_app_thread_senso_attr = {
    .thread_attr = {
                        "app_sensor_data_read",
                        0,
                        NULL,
                        0,
                        10,
                        (void *)g_app_thread_sensor_stack,
                        sizeof(g_app_thread_sensor_stack),
                        SENSOR_TASK_PRIORITY,
                        0,
                    },
    .func = _app_backgroud_data_read,
    .thread_id = NULL,
};

sdk_os_thread_attr_tab_t g_app_thread_sci_attr = {
    .thread_attr = {
                        "app_app_work_process",
                        0,
                        NULL,
                        0,
                        10,
                        (void *)g_app_thread_sci_stack,
                        sizeof(g_app_thread_sci_stack),
                        SCI_TASK_PRIORITY,
                        0,
                    },
    .func = app_sci_process,
    .thread_id = NULL,
};

sdk_os_thread_attr_tab_t g_app_thread_work_attr = {
    .thread_attr = {
                        "app_app_work_process",
                        0,
                        NULL,
                        0,
                        10,
                        (void *)g_app_thread_work_stack,
                        sizeof(g_app_thread_work_stack),
                        WORK_TASK_PRIORITY,
                        0,
                    },
    .func = app_work_process,
    .thread_id = NULL,
};


sdk_os_thread_attr_tab_t g_app_thread_ff_attr = {
    .thread_attr = {
                        "app_app_ff_process",
                        0,
                        NULL,
                        0,
                        10,
                        (void *)g_app_thread_ff_stack,
                        sizeof(g_app_thread_ff_stack),
                        WORK_TASK_PRIORITY,
                        0,
                    },
    .func = app_ff_process,
    .thread_id = NULL,
};

// sdk_os_thread_attr_tab_t g_app_thread_timing_attr = {
//     .thread_attr = {
//                         "app_timing_process",
//                         0,
//                         NULL,
//                         0,
//                         10,
//                         (void *)g_app_thread_timing_stack,
//                         sizeof(g_app_thread_timing_stack),
//                         TIMING_TASK_PRIORITY,
//                         0,
//                     },
//     .func = app_timing_process,
//     .thread_id = NULL,
// };

sdk_os_thread_attr_tab_t g_app_thread_sysmanage_attr = {
    .thread_attr = {
                        "app_sysmanage_process",
                        0,
                        NULL,
                        0,
                        10,
                        (void *)g_app_thread_sysmanage_stack,
                        sizeof(g_app_thread_sysmanage_stack),
                        SYSMANAGE_TASK_PRIORITY,
                        0,
                    },
    .func = app_sysmanage_process,
    .thread_id = NULL,
};

/**
* @brief        线程创建函数
* @param        void
* @return       执行结果
*/
int8_t app_thread_creat(void)
{	
    int32_t ret = 0;
    ret += sdk_os_thread_new(1, &g_app_thread_senso_attr);
    ret += sdk_os_thread_new(1, &g_app_thread_sci_attr);
    ret += sdk_os_thread_new(1, &g_app_thread_work_attr);
    ret += sdk_os_thread_new(1, &g_app_thread_ff_attr);
	// ret += sdk_os_thread_new(1, &g_app_thread_timing_attr);
	ret += sdk_os_thread_new(1, &g_app_thread_sysmanage_attr);
    if (ret != 0)
    {
        sdk_log_e("app_task Create fail\r\n");
    }
	return ret;
}

/**
 * @brief  热管理控制参数初始化
 * @param  [in] arg 说明
 * @return 
 * @note   
 */
static void _app_bat_temper_ctrl_init( void )
{
    if (false == bat_temper_ctrl_init())
    {
        sdk_log_e("bat_temper_ctrl_init error!!!");
    }
    else
    {
        sdk_log_d("bat_temper_ctrl_init sucess!!!");
    }
}

static bool event_warn_1 = false;
static bool event_warn_2 = false;
static bool event_share_ff_trig = false;

/**
 * @brief  消防 事件回调函数
 * @param  [in] arg 说明
 * @return 无
 * @note   无
 */
void _usr_ff_event_callback( dev_idx_t bat_cabinet_idx, ff_event_e ff_event, bool enable )
{

    sdk_log_d( "---- idx:%d, ff_event:%s, en:%d ------",  bat_cabinet_idx,
                                    (ff_event == FF_EVENT_WARN_1)  ? "FF_EVENT_WARN_1"    :
                                    (ff_event == FF_EVENT_WARN_2)  ? "FF_EVENT_WARN_2"    :
                                    (ff_event == FF_EVENT_FAN_STA) ? "FF_EVENT_FAN_STA" : "FF_EVENT_UNKONW", enable);
    switch ( ff_event )
    {
        /* 消防一级报警 */
        case FF_EVENT_WARN_1:
            event_warn_1 = enable;
            /* 声光报警 */
            energy_cabinet_set_fire_fighting_alarm( (event_warn_1 || event_warn_2) );
            break;

        /* 消防二级报警 */
        case FF_EVENT_WARN_2:
            event_warn_2 = enable;
            /* 声光报警 */
            energy_cabinet_set_fire_fighting_alarm( (event_warn_1 || event_warn_2) );
            /* 灭火剂瓶组电磁阀启动 */
            energy_cabinet_set_fire_fighting_start( event_share_ff_trig || event_warn_2 );
            /* 液冷进入消防模式 */
            bat_temper_set_fire_fighting_mode( enable );
            /* 排气扇关闭 */
            energy_cabinet_set_fan_sta( DEV_IDX_ALL, false );
            
            energy_cabinet_set_fault_lv_output( enable );
            break;

        case FF_EVENT_FAN_STA:
            /* 打开风机 */
            sdk_log_d("FF_EVENT_FAN_STA[%d]:%d", bat_cabinet_idx, enable);
            energy_cabinet_set_fan_sta( bat_cabinet_idx, enable );
            break;

        default:
            break;
    }
}

static void _usr_ff_share_trig_event( bool slave_ff_trig )
{
    sdk_log_e("%s, slave_ff_trig:%d", __FUNCTION__, slave_ff_trig );
    /* 消防气瓶 操作 */
    event_share_ff_trig = slave_ff_trig;
    energy_cabinet_set_fire_fighting_start( event_share_ff_trig || event_warn_2 );
}

/**
* @brief		IO检测和输出逻辑控制线程
* @param		[in] ： argument 
* @return		无
* @retval		无
* @warning		无
*/
static void app_work_process(void *argument)
{
    sdk_log_d("app_work_process start\r\n");  

    while(1)
    {     
        if( g_factory_test != FACTORY_MODE_NONE )
        {
            /* 工厂模式下 */
            if( g_factory_test == FACTORY_MODE_PCB_TEST )
                factory_test_task_loop();
                
            sdk_os_delay(sdk_os_tick_from_millisecond(100));
            sys_send_heartbeat_to_sys_manage(TASK_WORK);
            continue;
        }

#if LC_ENABLE
        /* 热管理控制任务处理 */
        bat_temper_ctrl_task_loop();
        /* 液冷任务处理 */
        lc_ctrl_task_loop();
#endif
		system_info_update2();
        sdk_os_delay(sdk_os_tick_from_millisecond(100));
		sys_send_heartbeat_to_sys_manage(TASK_WORK);
    }
}


static void app_ff_process(void *argument)
{
    sdk_log_d("%s start", __FUNCTION__);

    while(1)
    {     
        if( g_factory_test != FACTORY_MODE_NONE )
        {
            sdk_os_delay(sdk_os_tick_from_millisecond(100));
            continue;
        }
        
    #if FF_ENABLE
        /* 消防任务处理 */
        fire_fighting2_task_loop();
    #endif

    #if FF_SHARE_ENABLE
        fire_fight_share_task_loop();
    #endif

        sdk_os_delay(sdk_os_tick_from_millisecond(100));
		// sys_send_heartbeat_to_sys_manage(TASK_WORK);
    }
}

/**
* @brief		RS485设备数据读取线程
* @param		[in] ： argument 
* @return		无
* @retval		无
* @warning		无
*/
static void _app_backgroud_data_read( void *argument )
{
    while(1)
    {
        if( g_factory_test != FACTORY_MODE_NONE )
        {
            sdk_os_delay(sdk_os_tick_from_millisecond(200));
            sys_send_heartbeat_to_sys_manage(TASK_SENSOR);
            continue;
        }

    #if DEV_BOX_ENABLE
        energy_cabinet_task_loop();
    #endif

        // 读取电表数据
        // em_param_read( EM_RS485_INDEX, &em_data,EM_ADDR);

        sdk_os_delay(sdk_os_tick_from_millisecond(200));
        sys_send_heartbeat_to_sys_manage(TASK_SENSOR);
    }
}

/**
 * @brief  动环逻辑相关初始化
 * @param  [in] 无
 * @return 无
 * @note   
 */
void app_work_init( void )
{    
    ff_setting_t ff_setting = {
        .event_cb  = _usr_ff_event_callback,
    };
    lc_cap_t lc_cap = { false };

#if FF_ENABLE
    fire_fighting2_init( FIRE_FIGHTING_MODBUS_INDEX, &ff_setting );
#endif

#if FF_SHARE_ENABLE
    fire_fight_share_init( _usr_ff_share_trig_event );
#endif

#if LC_ENABLE
    lc_ctrl_init( LC_MODBUS_INDEX, NULL, NULL );
    _app_bat_temper_ctrl_init();

#endif
}

/**
 * @brief  后台数据采集初始化
 * @param  [in] 无
 * @return 无
 * @note   
 */
void app_backgroud_dev_init( void )
{
#if DEV_BOX_ENABLE
    energy_cabinet_dev_init();
    energy_cabinet_set_bat_cluster_num( 1 );
    energy_cabinet_bat_box_dat_set_default();
#endif
}


