#include "fire_fight_share.h"
#include "fire_fighting2.h"

#include "sci_frame.h"
#include "cup_sofar_can.h"
#include "tick_timer.h"
#include "app_cfg.h"
#include "num_trans.h"

#include "sdk.h"
#include "sdk_core.h"

// #define FF_SHARE_PR_ENABLE
#ifdef FF_SHARE_PR_ENABLE
    #define FF_SHARE_PRINT_DEBUG(format, ...)    sdk_log_d(format, ##__VA_ARGS__)
#else
    #define FF_SHARE_PRINT_DEBUG(format, ...)
#endif

/*-------------------------------- 消防并柜 ----------------------------------*/
#define FF_CAN_ID                                   CAN_ID_1
#define FF_SHARE_MAX_CNT                            6                           //< 消防控制器最大数量
#define FF_SHARE_SLAVE_MAX_CNT                      (FF_SHARE_MAX_CNT - 1)       //< 消防控制器从机最大数量
#define FF_SHARE_MASTER_ADDR                        1                           //< 消防控制器从机最大数量
#define FF_SLAVE_OFFLINE_TM_MS                      (30*1000)

#define FF_SHARE_MASTER_ADDR                        1
#define FF_SHARE_SLAVE_START_ADDR                   2

/* n毫秒获取一次从机数据 */
#define GET_SLAVE_FF_DAT_INV_TM_MS                  5000

#define BROADCAST_FF_SHARE_TRIG_TM_MS               9000

/* 从机广播地址 */
#define CAN_BROADCAST_ADDR                          0x1f

/*------------ 功能码 -------------*/
#define FUN_CODE_RD_REMOTE_SIGNAL                   1           //< 读取遥信数据
#define FUN_CODE_WR_PARAM                           20          //< 写定值参数

/*------- 遥信数据偏移地址 ---------*/
#define FF_CAN_REMOTE_SIGNAL_WARN2_OFFSET_ADDR      1

/*------- 写入定值参数偏移地址 ---------*/
#define FF_CAN_WR_PARAM_FF_FAULT_OFFSET_ADDR        1


typedef struct 
{
    tick_timer_handle_t online_tm;
    ol_sta_e            online_sta;
    ff_warn2_info_u     warn2_info;
} ff_info_t;

typedef struct {
    ff_role_e   ff_role;
    uint8_t     local_addr;

    struct {
        uint8_t   slave_cnt;
        ff_info_t slave_info[ FF_SHARE_SLAVE_MAX_CNT ];
        ff_share_trig_cb ff_share_trig;
        uint8_t   share_ff_trig;
    } master;

    struct {
        ff_info_t info;
    } slave;
    
    
} ff_share_t;

static tick_timer_handle_t s_get_slave_ff_tm_hd = NULL;
static tick_timer_handle_t s_broadcast_ff_share_tm_hd = NULL;
static ff_share_t s_ff_share = { .ff_role     = FF_ROLE_MASTER,
                                 .local_addr  = FF_SHARE_MASTER_ADDR,
                                 .master = { .slave_cnt = 0 }
                                };

// static ff_share_t s_ff_share = { .ff_role     = FF_ROLE_SLAVER,
//                                  .local_addr  = FF_SHARE_SLAVE_START_ADDR,
//                                  .master = { .slave_cnt = 1 }
//                                 };

static void _fire_fight_share_master_task_loop( void ) ;
static void _fire_fight_share_online_sta_fresh( void );
static void _fire_fight_share_master_req_slave_ff_warn2_info( void );
static void _print_can_info( char *p_head_str, can_id_t *p_can_id, uint8_t *p_dat, uint16_t dat_len );;
static void _fire_fight_share_slave_resp_ff_warn2_info( void );
static void _fire_fight_share_slave_task_loop( void );
static int32_t  _fire_fight_share_data_init( void );
static void _fire_fight_share_broadcast_ff_share_info( void );
static void _fire_fight_share_send_ff_share_trig_to_slave( bool exsit_ff_danger );

bool  fire_fight_share_master_get_slave_online_sta( ol_sta_e *get_slave_online_sta, uint8_t *get_slave_cnt )
{
    if( s_ff_share.ff_role != FF_ROLE_MASTER ) 
        return SF_FALSE;

	return SF_TRUE;
}

ff_role_e fire_fight_share_get_role( void )
{
    return s_ff_share.ff_role;
}

bool fire_fight_share_set_param( ff_role_e ff_role, uint8_t local_addr, uint8_t share_ff_cnt )
{
    uint8_t i;

    sdk_log_d( "ff_role:%d, local_addr:%d, share_ff_cnt:%d", ff_role, local_addr, share_ff_cnt );

    if( (local_addr == 0 ) || ( local_addr > FF_SHARE_MAX_CNT )
        || (ff_role >= FF_ROLE_MAX) || (share_ff_cnt > FF_SHARE_MAX_CNT)
        || ((ff_role == FF_ROLE_MASTER) && ( local_addr != FF_SHARE_MASTER_ADDR )) )
    {
        sdk_log_e( "ff_share_set_param error!!!" );
        return SF_FALSE;
    }

    s_ff_share.ff_role = ff_role;
    s_ff_share.local_addr = local_addr;

    if( s_ff_share.ff_role == FF_ROLE_MASTER )
    {
        s_ff_share.master.slave_cnt = share_ff_cnt - 1;
        for ( i = 0; i < (share_ff_cnt - 1); i++)
        {
            /* 重新刷新 离线检测timer，防止立刻掉线 */
            tick_timer_refresh( s_ff_share.master.slave_info[i].online_tm );
        }
    }else if( s_ff_share.ff_role == FF_ROLE_SLAVER )
    {
        /* 重新刷新 离线检测timer，防止立刻掉线 */
        tick_timer_refresh( s_ff_share.slave.info.online_tm );
    }

    return SF_TRUE;
}

static void _fire_fight_share_online_sta_fresh( void )
{
    uint8_t i;

    if( s_ff_share.ff_role == FF_ROLE_MASTER ) 
    {
        for ( i = 0; i < s_ff_share.master.slave_cnt; i++)
        {
            if( tick_timer_is_timeout( s_ff_share.master.slave_info[i].online_tm )
                && (s_ff_share.master.slave_info[i].online_sta != OL_STA_OFFLINE ) )
            {
                sdk_log_d( "master slave[%d] offline!!!", i );
                s_ff_share.master.slave_info[i].online_sta = OL_STA_OFFLINE;
            }
        }
    }else if( s_ff_share.ff_role == FF_ROLE_SLAVER )
    {
        if( tick_timer_is_timeout( s_ff_share.slave.info.online_tm )
            && (s_ff_share.slave.info.online_sta != OL_STA_OFFLINE ) )
        {
            sdk_log_d( "slave offline!!!" );
            s_ff_share.slave.info.online_sta = OL_STA_OFFLINE;
        }
    }
    
    ol_sta_e slave_online_sta[ FF_SHARE_MAX_CNT ] = { OL_STA_NO_EXSIT };

    if( s_ff_share.ff_role == FF_ROLE_MASTER ) 
    {
        for ( i = 0; i < s_ff_share.master.slave_cnt; i++)
        {
            slave_online_sta[i] = s_ff_share.master.slave_info[i].online_sta;
        }
        fire_fighting2_set_share_ff_online_sta( OL_STA_ONLINE, slave_online_sta );

    }else if( s_ff_share.ff_role == FF_ROLE_SLAVER )
    {
        fire_fighting2_set_share_ff_online_sta( s_ff_share.slave.info.online_sta, slave_online_sta );
    }
}
 
/**
 * @brief  请求 其他储能柜（从） 二级消防数据
 * @param  [in] 无
 * @return 无
 */
static void _fire_fight_share_master_req_slave_ff_warn2_info( void )
{
    uint8_t req_can_dat[8] = {0};
    can_id_t req_can_id = {0};
    int32_t ret = 0;
    
    req_can_id.src_addr = s_ff_share.local_addr;
    req_can_id.dst_addr = CAN_BROADCAST_ADDR;
    req_can_id.fun_code = FUN_CODE_RD_REMOTE_SIGNAL;
    req_can_id.type     = 2;
    req_can_id.prio     = 6;
    
    req_can_dat[0]      = FF_CAN_REMOTE_SIGNAL_WARN2_OFFSET_ADDR;
    req_can_dat[1]      = (FF_CAN_REMOTE_SIGNAL_WARN2_OFFSET_ADDR >> 8) & 0xff;
    req_can_dat[2]      = sizeof(ff_warn2_info_u) / 2;

    ret = cup_sofar_can_send( FF_CAN_ID, &req_can_id, req_can_dat, 3 );
    if( 0 > ret)
    {
        sdk_log_e("%s cup_sofar_can_send error!!! ret:%d", __FUNCTION__, ret);
    }
    
    return;
}

static void _fire_fight_share_master_ff_share_process( void )
{
    ff_warn2_info_u master_ff_warn2 = {.value = 0};
    uint8_t share_ff_trig = 0;

    /* 检查所有气瓶的消防 */
    for (size_t i = 0; i < s_ff_share.master.slave_cnt; i++)
    {
        /* 从机 触发到 消防气瓶的告警 */
        if ( s_ff_share.master.slave_info[i].warn2_info.bit.start_ff_solenoid )
        {
            share_ff_trig = 1;
        }
    }

    fire_fighting2_get_warn2( &master_ff_warn2 );
    if( master_ff_warn2.bit.share_ff_trig != share_ff_trig )
    {
        s_ff_share.master.ff_share_trig( share_ff_trig );
        fire_fighting2_set_share_ff_trig( share_ff_trig );
    }

    if( master_ff_warn2.bit.start_ff_solenoid )
    {
        share_ff_trig = 1;
    }

    _fire_fight_share_send_ff_share_trig_to_slave( share_ff_trig );
}

static void _fire_fight_share_send_ff_share_trig_to_slave( bool exsit_ff_danger )
{
    uint8_t req_can_dat[8] = {0};
    can_id_t req_can_id = {0};
    int32_t ret = 0;
    
    if( s_ff_share.ff_role != FF_ROLE_MASTER )
        return;

    FF_SHARE_PRINT_DEBUG("%s", __FUNCTION__);
    
    req_can_id.src_addr = s_ff_share.local_addr;
    req_can_id.dst_addr = CAN_BROADCAST_ADDR;
    req_can_id.fun_code = FUN_CODE_WR_PARAM;
    req_can_id.type     = 2;
    req_can_id.prio     = 6;
    req_can_id.addr     = FF_CAN_WR_PARAM_FF_FAULT_OFFSET_ADDR;
    
    req_can_dat[0]      = FF_CAN_WR_PARAM_FF_FAULT_OFFSET_ADDR;
    req_can_dat[1]      = (FF_CAN_WR_PARAM_FF_FAULT_OFFSET_ADDR >> 8) & 0xff;
    req_can_dat[2]      = sizeof(ff_warn2_info_u) / 2;

    req_can_dat[3]      = exsit_ff_danger;
    req_can_dat[4]      = 0;

    ret = cup_sofar_can_send( FF_CAN_ID, &req_can_id, req_can_dat, 5 );
    if( 0 > ret)
    {
        sdk_log_e("%s cup_sofar_can_send error!!! ret:%d", __FUNCTION__, ret);
    }
    
    return;
}


/**
 * @brief  读取并处理 其他储能柜（从） 二级消防数据
 * @param  [in] 无
 * @return 无
 */
static void _fire_fight_share_master_process( void )
{
    can_id_t rx_can_id = {0};
    uint8_t rx_dat[20] = {0};
    int32_t rx_len = 0;
    int32_t ret = 0;
    uint8_t index;

    ret = cup_sofar_can_rev( FF_CAN_ID, 10, &rx_can_id, rx_dat, &rx_len );
    if( ret != CAN_DATA_COMPLETE )
    {
        return;
    }

#ifdef FF_SHARE_PR_ENABLE
    _print_can_info( "master recv", &rx_can_id, rx_dat, rx_len );
#endif

    /* 通过网络内出现相同地址 */
    if( rx_can_id.src_addr == s_ff_share.local_addr) 
    {
        sdk_log_e("master dev addr conflict!!!");
        return;
    }

    /* 目的地址 非 本地地址，返回 */
    if ( rx_can_id.dst_addr != s_ff_share.local_addr ) 
        return ;
    
    /* 超出地址范围 */
    if( rx_can_id.src_addr > ( s_ff_share.master.slave_cnt + 1) ) 
    {
        sdk_log_e( "slave addr[%d] out of range!!!", rx_can_id.src_addr );
        return;        
    }

    /* 刷新从机在线信息 */
    index = rx_can_id.src_addr - FF_SHARE_SLAVE_START_ADDR;
    tick_timer_refresh( s_ff_share.master.slave_info[ index ].online_tm );

    if( s_ff_share.master.slave_info[ index ].online_sta != OL_STA_ONLINE )
    {
        /* 在线状态改变 */
        FF_SHARE_PRINT_DEBUG( "master slave[%d] online!!!", index );
        s_ff_share.master.slave_info[ index ].online_sta = OL_STA_ONLINE; 
    }

    if (rx_can_id.fun_code == FUN_CODE_RD_REMOTE_SIGNAL) 
    {
        /* 遥信数据 */
        if (rx_can_id.addr == FF_CAN_REMOTE_SIGNAL_WARN2_OFFSET_ADDR)
        {
            /* 消防二级故障信息 */
            s_ff_share.master.slave_info[ index ].warn2_info = *(ff_warn2_info_u*)rx_dat;

            FF_SHARE_PRINT_DEBUG("recv slave[%d] ff_warn2_info:%04X-%04X-%04X-%04X", index,
                s_ff_share.master.slave_info[ index ].warn2_info.array[0], 
                s_ff_share.master.slave_info[ index ].warn2_info.array[1], 
                s_ff_share.master.slave_info[ index ].warn2_info.array[2], 
                s_ff_share.master.slave_info[ index ].warn2_info.array[3]);

            // _fire_fight_share_ff_warn2_handle();
        }
    }
}


static void _fire_fight_share_master_task_loop( void )
{
    if( tick_timer_is_timeout( s_get_slave_ff_tm_hd ) )
    {
        tick_timer_set_timeout( s_get_slave_ff_tm_hd, GET_SLAVE_FF_DAT_INV_TM_MS );
        _fire_fight_share_master_req_slave_ff_warn2_info();
    }

    if( tick_timer_is_timeout( s_broadcast_ff_share_tm_hd ) )
    {
        tick_timer_set_timeout( s_broadcast_ff_share_tm_hd, BROADCAST_FF_SHARE_TRIG_TM_MS );
        _fire_fight_share_master_ff_share_process();
    }

    _fire_fight_share_master_process();

    return;
}

static void _print_can_info( char *p_head_str, can_id_t *p_can_id, uint8_t *p_dat, uint16_t dat_len )
{
    sdk_log_d( "[%s] src_addr:%d, dst_addr:%d, fun_code:%d, reg addr:%d" , p_head_str,
                p_can_id->src_addr, p_can_id->dst_addr, p_can_id->fun_code, p_can_id->addr  );
    util_print_hex_dat( "can dat:", p_dat, dat_len, 10, true );
}

static void _fire_fight_share_slave_resp_ff_warn2_info( void )
{
    ff_warn2_info_u ff_warn2_info = {.value = 0};
    uint8_t tx_dat[20] = { 0 }; 
    can_id_t tx_can_id = {0};

    sdk_log_d("%s", __FUNCTION__);

    tx_can_id.src_addr = s_ff_share.local_addr; 
    tx_can_id.dst_addr = FF_SHARE_MASTER_ADDR; 
    tx_can_id.fun_code = FUN_CODE_RD_REMOTE_SIGNAL;
    tx_can_id.type     = 1;
    tx_can_id.prio     = 6;
    tx_can_id.addr     = FF_CAN_REMOTE_SIGNAL_WARN2_OFFSET_ADDR;

    fire_fighting2_get_warn2( &ff_warn2_info );
    memcpy( tx_dat, &ff_warn2_info, sizeof( ff_warn2_info_u ) ) ;

    if( 0 > cup_sofar_can_send( FF_CAN_ID, &tx_can_id, tx_dat, 8 ) )
    {
        sdk_log_e("%s send error!!!", __FUNCTION__);
    }
}

static void _fire_fight_share_slave_msg_process( void )
{
    can_id_t rx_can_id = {0};
    uint8_t rx_dat[20] = {0};
    int32_t rx_len = 0;
    int32_t ret = 0;

    ret = cup_sofar_can_rev( FF_CAN_ID, 10, &rx_can_id, rx_dat, &rx_len );
    if( ret != CAN_DATA_COMPLETE )
    {
        return;
    }

#ifdef FF_SHARE_PR_ENABLE
    _print_can_info( "slave recv", &rx_can_id, rx_dat, rx_len );
#endif

    /* 地址过滤 */
    if((rx_can_id.dst_addr != s_ff_share.local_addr) && (rx_can_id.dst_addr != CAN_BROADCAST_ADDR) )
        return;

    /* 刷新在线状态 */
    tick_timer_refresh( s_ff_share.slave.info.online_tm );
    if (s_ff_share.slave.info.online_sta != OL_STA_ONLINE ) 
    {
        /* 改变在线状态 */
        FF_SHARE_PRINT_DEBUG( "slave online!!!" );
        s_ff_share.slave.info.online_sta = OL_STA_ONLINE;
    }

    uint16_t reg_addr = (rx_dat[1] << 8) | rx_dat[0];
    uint8_t  reg_num  = rx_dat[2];
    
    if (rx_can_id.fun_code == FUN_CODE_RD_REMOTE_SIGNAL) 
    {
        /* 请求读取遥信 */
        if( reg_addr == FF_CAN_REMOTE_SIGNAL_WARN2_OFFSET_ADDR )
        {
            /* 消防二级告警 */
            _fire_fight_share_slave_resp_ff_warn2_info();
            return;
        }
    } else if (rx_can_id.fun_code == FUN_CODE_WR_PARAM) 
    {
        if( reg_addr == FF_CAN_WR_PARAM_FF_FAULT_OFFSET_ADDR )
        {
            uint16_t reg_val = (rx_dat[4] << 8) | rx_dat[3];
            /* 通知系统存在消防隐患 */
            FF_SHARE_PRINT_DEBUG( "danger!!!, val:%d", reg_val );

            if( reg_val > 1 )
                return;

            /* 从机触发灭火剂 ，设置让主机下电 */
            fire_fighting2_set_share_ff_trig( reg_val );
        }
    }
}

void fire_fight_share_task_loop( void )
{
    if ( s_ff_share.ff_role == FF_ROLE_SLAVER )
    {
        _fire_fight_share_slave_msg_process();
    }else if ( s_ff_share.ff_role == FF_ROLE_MASTER  )
    {
        _fire_fight_share_master_task_loop();
    }
    _fire_fight_share_online_sta_fresh();
}

sf_ret_t fire_fight_share_init( ff_share_trig_cb ff_share_trig_cb )
{
    sdk_can_cfg_t can_cfg = {
        .baud = 500 * 1000,
        .mode = SDK_CAN_MODE_NORMAL
    };
    int32_t ret;

    if( ff_share_trig_cb == NULL )
        return -1;

    ret = sdk_can_open( FF_CAN_ID );
    if( ret < 0 )    
    {
        sdk_log_e("%s open error!!!", __FUNCTION__);
        return -1;
    }

    ret = sdk_can_setup( FF_CAN_ID, &can_cfg );
    if( ret < 0 )    
    {
        sdk_log_e("%s setup error!!!", __FUNCTION__);
        return -2;
    }

    ret = cup_sofar_can_init();
    if( ret < 0 )    
    {
        sdk_log_e("%s cup_sofar_can_init error!!!", __FUNCTION__);
        return -4;
    }

    s_get_slave_ff_tm_hd = tick_timer_create();
    if ( s_get_slave_ff_tm_hd == NULL )
    {
        sdk_log_e("%s s_get_slave_ff_tm_hd error!!!", __FUNCTION__);
        return -4;
    }

    s_broadcast_ff_share_tm_hd = tick_timer_create();
    if ( s_broadcast_ff_share_tm_hd == NULL )
    {
        sdk_log_e("%s s_broadcast_ff_share_tm_hd error!!!", __FUNCTION__);
        return -4;
    }

    ret = _fire_fight_share_data_init();

    s_ff_share.master.ff_share_trig = ff_share_trig_cb;

    sdk_log_d("%s success!!!", __FUNCTION__);

    return SF_OK;
}

static int32_t  _fire_fight_share_data_init( void )
{
    uint8_t i;
    
    for ( i = 0; i < FF_SHARE_SLAVE_MAX_CNT; i++)
    {
        s_ff_share.master.slave_info[i].online_tm = tick_timer_create();
        if ( s_ff_share.master.slave_info[i].online_tm == NULL )
        {
            sdk_log_e( "[%s] master create slave[%d] online tick timer error!!!", __FUNCTION__, i );
            return SF_FALSE;
        }
        tick_timer_set_timeout( s_ff_share.master.slave_info[i].online_tm, FF_SLAVE_OFFLINE_TM_MS );
    }

    s_ff_share.slave.info.online_tm  = tick_timer_create();
    if ( s_ff_share.slave.info.online_tm == NULL )
    {
        sdk_log_e( "[%s] create slave online tick timer error!!!", __FUNCTION__);
        return SF_FALSE;
    }
    tick_timer_set_timeout( s_ff_share.slave.info.online_tm, FF_SLAVE_OFFLINE_TM_MS );
    
    return SF_TRUE;
}



/**
 * 事件：
 * 1、主柜失联：（带从机情况下，没有收到从机数据）
 *      主柜处理： 自动产生告警标志位，黄灯，不影响运行 - 消防共享从机N离线
 *      
 * 2、丛柜失联：
 *      从柜处理：    自动产生故障标志位，黄灯告警，不影响运行 - 消防共享从机本机离线
 *      其他从柜处理：正常运行，绿色
 *      主柜处理
 *          一个从柜离线： 自动产生告警标志位，黄灯，不影响停机 - 消防共享从机N离线
 *          所有从柜离线： 自动产生告警标志位，黄灯，不影响停机 - 消防共享从机N离线
 * 
 * 
 * 3、主柜启动消防故障（消防二级故障）：
 *      措施：
 *          * 正常消防二级措施  - 各种对应二级故障
 *          * 通知其他从柜下电，其他从柜 红色指示 - （系统消防隐患）
 * 
 * 3、从柜启动消防故障（消防二级故障）：
 *      措施：
 *          * 正常消防二级措施  - 各种对应二级故障
 *          * 主柜
 *              获取到该从柜故障信息，通知其他从柜下电（红色指示） 标志位-（系统消防隐患）
 *              通知其他从柜下电，其他从柜下电 红色指示 标志位-（系统消防隐患）
 * 
 * 
 * 问题： 主柜与 发生二级告警的从柜失联，怎么处理？
 */

