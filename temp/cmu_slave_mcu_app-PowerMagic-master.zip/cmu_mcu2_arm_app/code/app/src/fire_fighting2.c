#include "fire_fighting2.h"
#include "tick_timer.h"
#include "app_cfg.h"
#include "app_dido.h"

#include "sdk_core.h"
#include "sdk.h"

#include "fire_fight_dev.h"
#include "fire_fight_local.h"

#define FF_WARN2_CANCEL_POW_DOWN                    1   // 消防二级下电取消 默认1
#define FF_DEV_BAT_TMPER_PROT_ENABLE                1

#define PACKAGE_LOSE_CAL_PRINT                  0               //< 丢包率计算打印 

#define FF_RD_DAT_TM_MS                         1500
#define FF_WD_DAT_TM_MS                         5000
#define MODBUS_MAX_FAIL_CNT                     20

typedef struct 
{
    bool             global_fan_sta;
    bool             fans_sta [ BAT_CLUSTER_MAX ];
    uint16_t         fan_on_co[ BAT_CLUSTER_MAX ];
    fan_reas_info_u  fan_on_reas;

    uint16_t         fan_on_co_threshold;
    uint16_t         fan_off_co_threshold;
} fan_info_t;

typedef struct 
{
    ff_dev_dat_t     ff_dev_dat;
    ff_warn2_info_u  local_warn2;
    fan_info_t       fan_info;
    bat_temper_t     bat_tmper_list[ BAT_CLUSTER_MAX ];
    
    ff_threshold_set_t threshold;
    uint8_t          bat_num;
} ff_dev_info_t;

/* 消防设备信息管理结构体 */
static ff_dev_info_t     s_ff_dev_info   = {{0}};
static ff_setting_t      s_ff_setting    = { NULL };
static uint8_t s_solenoid_trace_sta = 0;

static tick_timer_handle_t s_rd_timer_hd = NULL;
static tick_timer_handle_t s_wr_timer_hd = NULL;

static void _fire_fighting2_rd_local_ff_data( void );
static int32_t _fire_fighting2_rd_mb_ff_data( void );
static void _fire_fighting_mcu2_warn2_cal(void);
static void _fire_fighting2_fan_process( void );
static void _fire_fighting_warn2_handle( void );

static void _local_warn_event_change_cb( void )
{
#if (FF_LOCAL_DEBUG_ENABLE == 1)
    ff_warn2_info_u local_warn2 = {.value = 0};
    fire_fight_local_get_warn2( &local_warn2 );
    sdk_log_d("local warn change, warn2.value:%04X-%04X-%04X-%04X", 
                                            local_warn2.array[0], 
                                            local_warn2.array[1],
                                            local_warn2.array[2],
                                            local_warn2.array[3]);
#else
    fire_fight_local_get_warn2( &s_ff_dev_info.local_warn2 );
#endif
}

/**
 * @brief  消防功能初始化
 * @param  [in] modbus_idx modbus通讯索引
 * @param  [in] modbus_idx modbus通讯索引
 * @return SF_OK：正常  非SF_OK：异常  
 */
sf_ret_t fire_fighting2_init( modbus_idx_t modbus_idx, ff_setting_t *p_ff_setting )
{
    if ( SF_OK != fire_fight_dev_init( modbus_idx ) )
    {
        return SF_ERR_OPEN;
    }

    if ( SF_OK != fire_fight_local_init( _local_warn_event_change_cb ) )
    {
        return SF_ERR_OPEN;
    }

    s_ff_setting  = *p_ff_setting;

    s_rd_timer_hd = tick_timer_create();
    s_wr_timer_hd = tick_timer_create();

    if( (s_rd_timer_hd == NULL) || (s_wr_timer_hd == NULL) )
    {
        sdk_log_e("(s_rd_timer_hd == NULL) || (s_wr_timer_hd == NULL)");
        return SF_ERR_NO_OBJECT;
    }

    tick_timer_set_timeout( s_rd_timer_hd, FF_RD_DAT_TM_MS );
    tick_timer_set_timeout( s_wr_timer_hd, FF_WD_DAT_TM_MS );
    
    sdk_log_d("%s success", __FUNCTION__);
    
    return SF_OK;
}

/**
 * @brief  设置 消防管理电池簇个数
 * @param  [in] bat_num ： 电池簇个数
 * @return SF_OK：成功  非SF_OK：失败
 * @note   
 */
int32_t fire_fighting2_set_battery_cluster_num( uint8_t bat_num )
{
    sf_ret_t ret1 , ret2;

    ret1 = fire_fight_dev_set_bat_num( bat_num );
    ret2 = fire_fight_local_set_bat_num( bat_num );
    if ( (ret1 != SF_OK) || (ret2 != SF_OK) )
    {
        return SF_ERR_WR;
    }

    return SF_OK;
}

/**
 * @brief  开启关闭消防告警
 * @param  [in] ff_warn : 消防告警
 * @param  [in] enable  : 告警开启/关闭
 * @return SF_OK：成功  非SF_OK：失败
 * @note   
 */
sf_ret_t fire_fighting2_warn_set_enabe( ff_warn_e ff_warn, bool enable )
{
    if ( ff_warn == FF_WARN_LOW_PRESSURE  )
    {
       return fire_fight_dev_set_low_pressure_threshold( enable? s_ff_dev_info.threshold.ff_gas_pressure_low : 0 );
    }

    return SF_ERR_PARA;
}

int32_t fire_fighting2_set_threshold( ff_threshold_set_t *p_ff_threshold, uint8_t bat_num )
{
    sf_ret_t ret1 , ret2;

    s_ff_dev_info.fan_info.fan_off_co_threshold = p_ff_threshold->ff_fan_off_co;
    s_ff_dev_info.fan_info.fan_on_co_threshold = p_ff_threshold->ff_fan_start_co;
    s_ff_dev_info.bat_num = bat_num;

    ret1 = fire_fight_dev_set_threshold( p_ff_threshold, bat_num );
    ret2 = fire_fight_local_set_threshold( p_ff_threshold, bat_num );
    if ( (ret1 != SF_OK) || (ret2 != SF_OK) )
    {
        return SF_ERR_WR;
    }
    s_ff_dev_info.threshold = *p_ff_threshold;

    return SF_OK;
}

/**
 * @brief  传入电池数据 到消防控制器 内部
 * @param  [in] p_bat_dat_t ：电池数据
 * @return SF_OK：正常  非SF_OK：异常  
 * @note   
 */
sf_ret_t fire_fighting2_input_bat_info( bat_temper_t *p_bat_temper_list )
{
    if ( p_bat_temper_list == NULL )
    {
        return SF_ERR_PARA;
    }

    memcpy( s_ff_dev_info.bat_tmper_list, p_bat_temper_list, BAT_CLUSTER_MAX * sizeof( bat_temper_t ) );
    
    return SF_OK;
}

/**
 * @brief  同步消防控制器数据 【同步，直接modbus获取】
 * @param  [in] 无
 * @return SF_OK：正常  非SF_OK：异常  
 * @note   
 */
sf_ret_t fire_fighting2_dat_sync( void )
{
    for (size_t i = 0; i < 3; i++)
    {
        if ( _fire_fighting2_rd_mb_ff_data() >= 0 )
            return SF_OK;
    }
    return -1;
}

/**
 * @brief  获取 消防控制器 传感器数据信息
 * @param  [out] p_sen_dat_info   ： 传感器数据
 * @return SF_OK：正常  非SF_OK：异常  
 * @note   
 */
sf_ret_t fire_fighting2_get_data( ff_sen_dat_info_t *p_sen_dat_info )
{
    if ( p_sen_dat_info == NULL )
    {
        return SF_ERR_PARA;
    }

    *p_sen_dat_info = s_ff_dev_info.ff_dev_dat.sen_dat;

    return SF_OK;
}

/**
 * @brief  获取 气瓶气压
 * @param  [out] p_ff_gas_pressure   ： 气瓶气压
 * @return SF_OK：正常  非SF_OK：异常  
 * @note   
 */
sf_ret_t fire_fighting2_get_ff_gas_pressure( uint16_t *p_ff_gas_pressure )
{
    if ( p_ff_gas_pressure == NULL )
    {
        return SF_ERR_PARA;
    }

    *p_ff_gas_pressure = s_ff_dev_info.ff_dev_dat.ff_gas_pressure;

    return SF_OK;
}

/**
 * @brief  消防瓶共享触发标志 设置
 * @param  [in]  exsit_ff_danger ：当前存在消防隐患
 * @return 无
 */
void fire_fighting2_set_share_ff_trig( bool share_ff_trig )
{
    s_ff_dev_info.local_warn2.bit.share_ff_trig = share_ff_trig;
    return;
}

/**
 * @brief  设置 消防瓶共享在线状态
 * @param  [in]  self_online_sta    ：自身在线状态 （从机角度）
 * @param  [in]  p_slave_online_sta ：从机在线状态 （主机角度）
 * @return 无
 */
void  fire_fighting2_set_share_ff_online_sta( ol_sta_e self_online_sta, ol_sta_e *p_slave_online_sta )
{
    s_ff_dev_info.ff_dev_dat.warn1.bit.ff_share_offline = ( self_online_sta == OL_STA_OFFLINE );
    s_ff_dev_info.ff_dev_dat.warn1.bit.ff_share_slave1_offline = ( p_slave_online_sta[0] == OL_STA_OFFLINE );
    s_ff_dev_info.ff_dev_dat.warn1.bit.ff_share_slave2_offline = ( p_slave_online_sta[1] == OL_STA_OFFLINE );
    s_ff_dev_info.ff_dev_dat.warn1.bit.ff_share_slave3_offline = ( p_slave_online_sta[2] == OL_STA_OFFLINE );
    s_ff_dev_info.ff_dev_dat.warn1.bit.ff_share_slave4_offline = ( p_slave_online_sta[3] == OL_STA_OFFLINE );
    s_ff_dev_info.ff_dev_dat.warn1.bit.ff_share_slave5_offline = ( p_slave_online_sta[4] == OL_STA_OFFLINE );

    return;
}

static sf_ret_t _fire_fighting2_rd_mb_ff_data( void )
{
    static uint16_t total_fail_cnt = 0;
    static uint16_t total_cnt = 0;
    static uint8_t  fail_cnt = 0;

    #if ( PACKAGE_LOSE_CAL_PRINT == 1 )
        if ( ((total_cnt++) & 0x7F) == 0 )
        {
            sdk_log_d( "ff total:%d, fail:%d!!!", total_cnt, total_fail_cnt );
        }
    #endif

    if ( SF_OK == fire_fight_dev_rd_mb_ff_data( &s_ff_dev_info.ff_dev_dat ))
    {
        s_ff_dev_info.ff_dev_dat.warn1.bit.ff_offline = 0;
        fail_cnt = 0;
    } else {
        if (fail_cnt++ >= MODBUS_MAX_FAIL_CNT)
        {
            s_ff_dev_info.ff_dev_dat.warn1.bit.ff_offline = 1;
        }
        total_fail_cnt++;
    }

    if( s_ff_setting.update_cb )
    {
        s_ff_setting.update_cb();
    }

    return SF_OK;
}

static void _fire_fighting_warn2_handle( void )
{
    s_ff_dev_info.fan_info.fan_on_reas.bit.mix_sensor1_co_ppm = 0;
    s_ff_dev_info.fan_info.fan_on_reas.bit.mix_sensor2_co_ppm = 0;
    s_ff_dev_info.fan_info.fan_on_reas.bit.mix_sensor3_co_ppm = 0;
    s_ff_dev_info.fan_info.fan_on_reas.bit.mix_sensor4_co_ppm = 0;
    s_ff_dev_info.fan_info.fan_on_reas.bit.mix_sensor5_co_ppm = 0;
    s_ff_dev_info.fan_info.fan_on_reas.bit.mix_sensor6_co_ppm = 0;
}

static void _fire_fighting2_fan_process( void )
{
    typedef enum {
        FAN_ACT_OFF,
        FAN_ACT_ON,
        FAN_ACT_IGNORE,
    } fan_act_e;

    fan_act_e fans_next_act[ BAT_CLUSTER_MAX ];

    memset( fans_next_act, FAN_ACT_IGNORE, sizeof( fans_next_act ) );
    for (size_t i = 0; i < s_ff_dev_info.bat_num ; i++)
    {
        /* CO≥100ppm，打开风机 */
        if( s_ff_dev_info.ff_dev_dat.sen_dat.mix_sen[i].mix_sen_co >= s_ff_dev_info.fan_info.fan_on_co_threshold )
        {
            fans_next_act[ i ] = FAN_ACT_ON;
        }   
        /* CO≤50ppm，关闭风机 */
        else if( s_ff_dev_info.ff_dev_dat.sen_dat.mix_sen[i].mix_sen_co <= s_ff_dev_info.fan_info.fan_off_co_threshold )
        {
            fans_next_act[ i ] = FAN_ACT_OFF;
        }
    }

    for (size_t i = 0; i < s_ff_dev_info.bat_num ; i++)
    {
        if ( (fans_next_act[i] == FAN_ACT_ON)  && (s_ff_dev_info.fan_info.fans_sta[i] == false) ) 
        {
            if ( i == 0 )      s_ff_dev_info.fan_info.fan_on_reas.bit.mix_sensor1_co_ppm = 1;
            else if ( i == 1 ) s_ff_dev_info.fan_info.fan_on_reas.bit.mix_sensor2_co_ppm = 1;
            else if ( i == 2 ) s_ff_dev_info.fan_info.fan_on_reas.bit.mix_sensor3_co_ppm = 1;
            else if ( i == 3 ) s_ff_dev_info.fan_info.fan_on_reas.bit.mix_sensor4_co_ppm = 1;
            else if ( i == 4 ) s_ff_dev_info.fan_info.fan_on_reas.bit.mix_sensor5_co_ppm = 1;
            else if ( i == 5 ) s_ff_dev_info.fan_info.fan_on_reas.bit.mix_sensor6_co_ppm = 1;

            s_ff_dev_info.fan_info.fan_on_co[i] = s_ff_dev_info.ff_dev_dat.sen_dat.mix_sen[i].mix_sen_co;
        }
        if ( (fans_next_act[i] == FAN_ACT_OFF) && (s_ff_dev_info.fan_info.fans_sta[i] == true) ) 
        {
            if ( i == 0 )      s_ff_dev_info.fan_info.fan_on_reas.bit.mix_sensor1_co_ppm = 0;
            else if ( i == 1 ) s_ff_dev_info.fan_info.fan_on_reas.bit.mix_sensor2_co_ppm = 0;
            else if ( i == 2 ) s_ff_dev_info.fan_info.fan_on_reas.bit.mix_sensor3_co_ppm = 0;
            else if ( i == 3 ) s_ff_dev_info.fan_info.fan_on_reas.bit.mix_sensor4_co_ppm = 0;
            else if ( i == 4 ) s_ff_dev_info.fan_info.fan_on_reas.bit.mix_sensor5_co_ppm = 0;
            else if ( i == 5 ) s_ff_dev_info.fan_info.fan_on_reas.bit.mix_sensor6_co_ppm = 0;

            s_ff_dev_info.fan_info.fan_on_co[i] = 0;
        }

        /* 需要改变风扇状态 */
        if (    (( fans_next_act[i] == FAN_ACT_ON  ) && ( s_ff_dev_info.fan_info.fans_sta[i] == false ) ) 
             || (( fans_next_act[i] == FAN_ACT_OFF ) && ( s_ff_dev_info.fan_info.fans_sta[i] == true  ) ) )
        {
            s_ff_dev_info.fan_info.fans_sta[i] = (fans_next_act[i] == FAN_ACT_ON)? true: false;
            s_ff_setting.event_cb( i, FF_EVENT_FAN_STA, s_ff_dev_info.fan_info.fans_sta[i] );
        }
    }
}


static void _fire_fighting2_protect_process( void )
{
    static uint8_t last_ff_warn1_sta = 0;
    
    /* 一级告警 以消防控制器为主 */
    if( s_ff_dev_info.ff_dev_dat.do_sta.bit.ff_warn1 != last_ff_warn1_sta )
    {
        last_ff_warn1_sta = s_ff_dev_info.ff_dev_dat.do_sta.bit.ff_warn1;
        if (s_ff_setting.event_cb)
        {
            s_ff_setting.event_cb( DEV_IDX_ALL, FF_EVENT_WARN_1, s_ff_dev_info.ff_dev_dat.do_sta.bit.ff_warn1 );
        }
    }

    static uint8_t last_ff_warn2_sta = 0;
    uint8_t now_ff_warn2_sta = 0;

    if(    ( s_ff_dev_info.ff_dev_dat.do_sta.bit.ff_warn2 == 1)
        || ( s_ff_dev_info.local_warn2.value != 0))
    {
        now_ff_warn2_sta = 1;
    }
    else
    {
        now_ff_warn2_sta = 0;
    }

#if ( FF_WARN2_CANCEL_POW_DOWN == 1 )
    if( ( last_ff_warn2_sta == 0 ) && ( now_ff_warn2_sta == 1 ) )
#else
    if( now_ff_warn2_sta != last_ff_warn2_sta )
#endif
    {
        last_ff_warn2_sta = now_ff_warn2_sta;
        _fire_fighting_warn2_handle();
        if( s_ff_setting.event_cb )
        {
            s_ff_setting.event_cb( DEV_IDX_ALL, FF_EVENT_WARN_2, now_ff_warn2_sta);
        }
    }

    /* 二级消防发生时候，无需检测 CO情况 */
    if( now_ff_warn2_sta == 0 )
    {
        _fire_fighting2_fan_process();
    }
}

/**
 * @brief  消防任务调度 
 * @param  [in]  无
 * @return 无
 */
void fire_fighting2_task_loop( void )
{
    if ( tick_timer_is_timeout( s_rd_timer_hd ) )
    {
        tick_timer_refresh( s_rd_timer_hd );
        _fire_fighting2_rd_mb_ff_data();
        fire_fight_local_task_loop( s_ff_dev_info.bat_tmper_list, &s_ff_dev_info.ff_dev_dat.sen_dat );
        _fire_fighting2_protect_process();
    }

    if ( tick_timer_is_timeout( s_wr_timer_hd ) 
        && ( s_ff_dev_info.ff_dev_dat.warn1.bit.ff_offline == 0 ) )
    {
        tick_timer_refresh( s_wr_timer_hd );
        #if ( FF_DEV_BAT_TMPER_PROT_ENABLE == 1)
        fire_fight_dev_wr_bat_tmp( s_ff_dev_info.bat_tmper_list );
        #endif
    }
}

/**
 * @brief  获取 消防控制器 do 状态 【消防控制器角度】
 * @param  [out] p_warn1_lv     ：一级告警电平
 * @param  [out] p_warn2_lv     ：二级告警电平
 * @param  [out] p_com_fault_lv ：故障电平
 * @return SF_OK：正常  非SF_OK：异常  
 * @note   
 */
sf_ret_t fire_fighting2_get_mb_do_sta( uint8_t *p_warn1_lv, uint8_t *p_warn2_lv, uint8_t *p_com_fault_lv )
{
    if ( p_warn1_lv )
        *p_warn1_lv = s_ff_dev_info.ff_dev_dat.do_sta.bit.ff_warn1;
    if ( p_warn2_lv )
        *p_warn2_lv = s_ff_dev_info.ff_dev_dat.do_sta.bit.ff_warn2;
    if ( p_com_fault_lv )
        *p_com_fault_lv = s_ff_dev_info.ff_dev_dat.do_sta.bit.ff_com_falut;

    return SF_OK;
}

/**
 * @brief  获取 消防控制器 di 状态【消防控制器角度】
 * @param  [out] p_cmu_start_lv   ： CMU启动电平
 * @return SF_OK：正常  非SF_OK：异常  
 * @note   
 */
sf_ret_t fire_fighting2_get_mb_di_sta( uint8_t *p_cmu_start_lv )
{
    if ( p_cmu_start_lv == NULL )
    {
        return SF_ERR_PARA;
    }
    *p_cmu_start_lv = s_ff_dev_info.ff_dev_dat.warn2.bit.cmu_start_ff;
        
    return SF_OK;
}

/**
 * @brief  获取 消防控制器 di 状态
 * @param  [out] p_di_sta_info   ： 消防控制器 DI 状态
 * @return SF_OK：正常  非SF_OK：异常  
 * @note   
 */
sf_ret_t fire_fighting2_get_di_sta( ff_di_sta_info_u *p_di_sta_info )
{
    ff_di_sta_info_u local_ff_di_sta = {.value = 0};

    if ( p_di_sta_info == NULL )
    {
        return SF_ERR_PARA;
    }
    fire_fight_local_get_di_sta( &local_ff_di_sta );

    /* 本地消防 与 消防控制器的 di信息相结合 */
    p_di_sta_info->value = s_ff_dev_info.ff_dev_dat.di_sta.value | local_ff_di_sta.value ;

    return SF_OK;
}

/**
 * @brief  获取 消防控制器 do 状态
 * @param  [out] p_do_sta_info   ： 消防控制器 DI 状态
 * @return SF_OK：正常  非SF_OK：异常  
 * @note   
 */
sf_ret_t fire_fighting2_get_do_sta( ff_do_sta_info_u *p_do_sta_info )
{
    if ( p_do_sta_info == NULL )
    {
        return SF_ERR_PARA;
    }
    *p_do_sta_info = s_ff_dev_info.ff_dev_dat.do_sta;

    return SF_OK;
}

uint8_t fire_fighting2_get_solenoid_trace_sta( void )
{
    return s_ff_dev_info.ff_dev_dat.di_sta.bit.ff_pipe_sig;
}

/**
 * @brief  获取 消防控制器 一级告警信息
 * @param  [out] p_warn1_info   ： 一级告警信息
 * @return SF_OK：正常  非SF_OK：异常  
 * @note   
 */
sf_ret_t fire_fighting2_get_warn1( ff_warn1_info_u *p_warn1_info )
{
    ff_warn1_info_u ret_warn1_info = { .value = 0 };

    if ( p_warn1_info == NULL )
    {
        return SF_ERR_PARA;
    }

    ret_warn1_info.value = s_ff_dev_info.ff_dev_dat.warn1.value;
    *p_warn1_info = ret_warn1_info;

    // *p_warn1_info = s_ff_dev_info.warn1;
    return SF_OK;
}

/**
 * @brief  获取 消防控制器 二级告警信息
 * @param  [out] p_warn1_info   ： 二级告警信息
 * @return SF_OK：正常  非SF_OK：异常  
 * @note   
 */
sf_ret_t fire_fighting2_get_warn2( ff_warn2_info_u *p_warn2_info )
{
    ff_warn2_info_u ret_warn2_info = { .value = 0 };

    if ( p_warn2_info == NULL )
    {
        return SF_ERR_PARA;
    }

    ret_warn2_info.value = s_ff_dev_info.local_warn2.value | s_ff_dev_info.ff_dev_dat.warn2.value;
    *p_warn2_info = ret_warn2_info;

    // *p_warn2_info = s_ff_dev_info.warn2;
    return SF_OK;
}

/**
 * @brief  获取 消防控制器 二级告警状态
 * @return ture：二级告警触发  false：未触发
 * @note   
 */
bool fire_fighting2_get_warn2_alarm_sta( void )
{
    /* 结合本地消防和消防控制器的状态，判断是否有二级告警 */
    if (   ( s_ff_dev_info.local_warn2.value != 0) 
        || ( s_ff_dev_info.ff_dev_dat.do_sta.bit.ff_warn2 != 0 ) )
    {
        return SF_TRUE;
    } else {
        return SF_FALSE;
    }
}

/**
 * @brief  获取 排气扇状态和触发排气扇原因
 * @param  [in] p_fan_sta   ： 风扇状态
 * @param  [in] p_fan_reas  ： 风扇联动原因
 * @param  [in] p_fan_on_co ： 风扇联动CO数值
 * @return SF_OK：正常  非SF_OK：异常  
 * @note   
 */
sf_ret_t fire_fighting2_get_fan_info( bool *p_fan_sta, fan_reas_info_u *p_fan_reas, uint16_t *p_fan_on_co )
{
    if ( (p_fan_sta == NULL) || (p_fan_reas == NULL) || (p_fan_on_co == NULL) )
    {
        return SF_ERR_PARA;
    }

    *p_fan_sta  = s_ff_dev_info.fan_info.global_fan_sta;
    *p_fan_reas = s_ff_dev_info.fan_info.fan_on_reas;
    memcpy( p_fan_on_co, s_ff_dev_info.fan_info.fan_on_co, sizeof( s_ff_dev_info.fan_info.fan_on_co ) );
    
    return SF_OK;
}
