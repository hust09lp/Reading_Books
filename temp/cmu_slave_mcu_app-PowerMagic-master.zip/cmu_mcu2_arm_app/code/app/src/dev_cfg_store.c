#include "dev_cfg_store.h"

#include "sdk.h"
#include "sdk_core.h"

#define DEV_INFO_FILE_NAME "dev_info.cfg"

sf_ret_t _dev_cfg_info_save( dev_cfg_info_t *p_dev_cfg_info )
{
    fs_t* p_dev_cfg_fs = NULL;
    int32_t wr_len;

    sdk_log_d("%s", __FUNCTION__ );

    if( p_dev_cfg_fs == NULL )
    {
        return SF_ERR_PARA;
    }

    /* 打开文件，如果文件不存在则创建该文件 */
    p_dev_cfg_fs = sdk_fs_open((const int8_t*)DEV_INFO_FILE_NAME, FA_WRITE | FA_READ | FA_OPEN_ALWAYS);
    if( p_dev_cfg_fs == NULL )
    {
        sdk_log_e("%s open %s fail!!!", __FUNCTION__, DEV_INFO_FILE_NAME );
        return SF_ERR_OPEN;
    }

    wr_len = sdk_fs_write( p_dev_cfg_fs, p_dev_cfg_info, sizeof( dev_cfg_info_t ));
    if( wr_len != sizeof( dev_cfg_info_t ) )
    {
        sdk_log_e("%s write %s fail!!!", __FUNCTION__, DEV_INFO_FILE_NAME );
        return SF_ERR_WR;
    }
    
    sdk_fs_close( p_dev_cfg_fs );

    return SF_OK;
}

sf_ret_t _dev_cfg_info_restore( dev_cfg_info_t *p_dev_info )
{
    int32_t read_len, ret;
    fs_t*   p_fs = NULL;
    
    if( p_dev_info == NULL )
        return SF_ERR_PARA;

    p_fs = sdk_fs_open((const int8_t*)DEV_INFO_FILE_NAME, FA_READ );
    if( p_fs == NULL )
    {
        /* 文件不存在或是打开错误，重置设备信息 */
        sdk_log_e( "open %s error!!!", __FUNCTION__ );
        goto DEV_INFO_ERROR;
    }

    sdk_log_d(  "%s size:%d" , DEV_INFO_FILE_NAME, sdk_fs_get_size( p_fs ) );

    /* 文件存在 */
    read_len = sdk_fs_read( p_fs, (void*)p_dev_info, sizeof( dev_cfg_info_t ) );
    ret = sdk_fs_close( p_fs );
    if( ret != SF_OK )
    {
        sdk_log_e( "close %s error!!!", DEV_INFO_FILE_NAME );
        goto DEV_INFO_ERROR;
    }

    if( read_len != sizeof( dev_cfg_info_t ) )
    {
        /* 数据长度错误，重置设备信息 */
        sdk_log_e( "read dev_cfg_info read_len:%d", read_len );
        goto DEV_INFO_ERROR;
    }

    /* 文件内容校验 */
    if( p_dev_info->lc_type >= LC_TYPE_MAX )
    {
        /* 液冷类型错误，重置设备信息 */
        goto DEV_INFO_ERROR;
    }

    /* 数据正确，使用信息 */
    return SF_OK;

DEV_INFO_ERROR:
    /* 配置文件读取错误，重置并保存数据 */
    sdk_log_e( "%s error!!! reset default", DEV_INFO_FILE_NAME );
    memset( p_dev_info, 0, sizeof( dev_cfg_info_t ));
    p_dev_info->lc_type = LC_TYPE_MEDIA;

    return _dev_cfg_info_save( p_dev_info );
}

// dev_cfg_info_t s_dev_cfg_info = { .lc_type = LC_TYPE_MEDIA };

// int32_t _lc_ctrl_cfg_info_test( void )
// {
//     sdk_log_d("%s", __FUNCTION__);

//     if( _dev_cfg_info_restore( &s_dev_cfg_info ) < 0 )
//     {
//         sdk_log_e( "_lc_ctrl_cfg_info_restore error!!!" );
//     }

//     sdk_log_d( "s_dev_cfg_info.lc_type:%d", s_dev_cfg_info.lc_type );
//     return 0;
// }
