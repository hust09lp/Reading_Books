#include "sofar_type.h"
#include "fire_fight_dev.h"
#include "app_modbus.h"
#include "proj_cfg.h"
#include "peripheral_cfg.h"
#include "app_dido.h"

#include "sdk.h"
#include "sdk_core.h"

#define MODBUS_SLAVE_ADDR                       1
#define MODBUS_BUADRATE                         9600


/*--------------------------------------------- modbus 协议结构体 start ---------------------------------------------------------*/
/**
  * @union ff_warn1_flag_u
  * @brief 消防控制器 modbus 一级告警标志位  
  */
typedef union 
{
    uint16_t array[3];
    struct {
        uint16_t sen_smoke1   :1;   // 柜1-烟感1
        uint16_t sen_temper1  :1;   // 柜1-温感1
        uint16_t mix_temper1  :1;   // 柜1-复合传感器-1-温度≥阈值
        uint16_t mix_pm25_1   :1;   // 柜1-复合传感器-1-PM2.5≥阈值
        uint16_t mix_co_1     :1;   // 柜1-复合传感器-1-CO≥阈值
        uint16_t pack_temper1 :1;   // 柜1-pack温度告警
        uint16_t reserve1     :2;   // 保留

        uint16_t sen_smoke2   :1;   // 柜2-烟感2
        uint16_t sen_temper2  :1;   // 柜2-温感2
        uint16_t mix_temper2  :1;   // 柜2-复合传感器-2-温度≥阈值
        uint16_t mix_pm25_2   :1;   // 柜2-复合传感器-2-PM2.5≥阈值
        uint16_t mix_co_2     :1;   // 柜2-复合传感器-2-CO≥阈值
        uint16_t pack_temper2 :1;   // 柜2-pack温度告警
        uint16_t reserve2     :2;   // 保留

        uint16_t sen_smoke3   :1;   // 柜3-烟感3
        uint16_t sen_temper3  :1;   // 柜3-温感3
        uint16_t mix_temper3  :1;   // 柜3-复合传感器-3-温度≥阈值
        uint16_t mix_pm25_3   :1;   // 柜3-复合传感器-3-PM2.5≥阈值
        uint16_t mix_co_3     :1;   // 柜3-复合传感器-3-CO≥阈值
        uint16_t pack_temper3 :1;   // 柜3-pack温度告警
        uint16_t reserve3     :2;   // 保留

        uint16_t sen_smoke4   :1;   // 柜4-烟感4
        uint16_t sen_temper4  :1;   // 柜4-温感4
        uint16_t mix_temper4  :1;   // 柜4-复合传感器-4-温度≥阈值
        uint16_t mix_pm25_4   :1;   // 柜4-复合传感器-4-PM2.5≥阈值
        uint16_t mix_co_4     :1;   // 柜4-复合传感器-4-CO≥阈值
        uint16_t pack_temper4 :1;   // 柜4-pack温度告警
        uint16_t reserve4     :2;   // 保留

        uint16_t sen_smoke5   :1;   // 柜5-烟感5
        uint16_t sen_temper5  :1;   // 柜5-温感5
        uint16_t mix_temper5  :1;   // 柜5-复合传感器-5-温度≥阈值
        uint16_t mix_pm25_5   :1;   // 柜5-复合传感器-5-PM2.5≥阈值
        uint16_t mix_co_5     :1;   // 柜5-复合传感器-5-CO≥阈值
        uint16_t pack_temper5 :1;   // 柜5-pack温度告警
        uint16_t reserve5     :2;   // 保留

        uint16_t sen_smoke6   :1;   // 柜6-烟感6
        uint16_t sen_temper6  :1;   // 柜6-温感6
        uint16_t mix_temper6  :1;   // 柜6-复合传感器-6-温度≥阈值
        uint16_t mix_pm25_6   :1;   // 柜6-复合传感器-6-PM2.5≥阈值
        uint16_t mix_co_6     :1;   // 柜6-复合传感器-6-CO≥阈值
        uint16_t pack_temper6 :1;   // 柜6-pack温度告警
        uint16_t reserve6     :2;   // 保留
    } bit;
} ff_warn1_flag_u;

/**
  * @union ff_warn1_bat_t
  * @brief modbus 数据 一级告警触发时数据  
  */
typedef struct 
{
    int16_t  mix_temper_val;                        // 一级告警时-柜n-复合传感器-n-温度    单位：1℃
    uint16_t mix_pm25_val;                          // 一级告警时-柜n-复合传感器-n-PM2.5   单位：1ug/m³
    int16_t  mix_co_val;                            // 一级告警时-柜n-复合传感器-n-CO      单位：1PPm
    int16_t  pack_temper_val;                       // 一级告警时-柜n-pack温度            单位：1℃
} ff_warn1_bat_t;

/**
  * @union ff_warn2_pack_flag_u
  * @brief modbus数据 二级告警标志位【pack级】  
  */
typedef union 
{
    uint16_t array[1];
    struct {
        uint16_t pack1_tmp_mix_co1 :1;              // 柜1-pack温度+复合传感器-1-CO
        uint16_t pack2_tmp_mix_co2 :1;              // 柜2-pack温度+复合传感器-2-CO
        uint16_t pack3_tmp_mix_co3 :1;              // 柜3-pack温度+复合传感器-3-CO
        uint16_t pack4_tmp_mix_co4 :1;              // 柜4-pack温度+复合传感器-4-CO
        uint16_t pack5_tmp_mix_co5 :1;              // 柜5-pack温度+复合传感器-5-CO
        uint16_t pack6_tmp_mix_co6 :1;              // 柜6-pack温度+复合传感器-6-CO
        uint16_t cmu_io_start      :1;              // CMU启动信号→消防控制器
    } bit;
} ff_warn2_pack_flag_u;

/**
  * @union ff_warn2_bat_t
  * @brief modbus数据 二级pack告警 锁定温度值
  */
typedef struct 
{
    int16_t  temper1_val;                           // 报警时柜N温度1-锁存    单位：1℃
    int16_t  temper2_val;                           // 报警时柜N温度2-锁存    单位：1℃
    int16_t  temper3_val;                           // 报警时柜N温度3-锁存    单位：1℃
} ff_warn2_bat_t;

/**
  * @union ff_warn2_flag_u
  * @brief modbus数据 二级告警标志位【舱级】  
  */
typedef union 
{
    uint16_t array[2];
    struct {
        uint16_t sen_smoke1_sen_temper1 :1;         // 柜1-烟感1+温感1 
        uint16_t sen_smoke1_mix_temper1 :1;         // 柜1-烟感1+复合传感器1-温度
        uint16_t sen_temper1_mix_co1    :1;         // 柜1-温感1+复合传感器1-CO
        uint16_t sen_smoke2_sen_temper2 :1;         // 柜2-烟感2+温感2
        uint16_t sen_smoke2_mix_temper2 :1;         // 柜2-烟感2+复合传感器2-温度
        uint16_t sen_temper2_mix_co2    :1;         // 柜2-温感2+复合传感器2-CO
        uint16_t sen_smoke3_sen_temper3 :1;         // 柜3-烟感3+温感3
        uint16_t sen_smoke3_mix_temper3 :1;         // 柜3-烟感3+复合传感器3-温度
        uint16_t sen_temper3_mix_co3    :1;         // 柜3-温感3+复合传感器3-CO
        uint16_t sen_smoke4_sen_temper4 :1;         // 柜4-烟感4+温感4
        uint16_t sen_smoke4_mix_temper4 :1;         // 柜4-烟感4+复合传感器4-温度
        uint16_t sen_temper4_mix_co4    :1;         // 柜4-温感4+复合传感器4-CO
        uint16_t sen_smoke5_sen_temper5 :1;         // 柜5-烟感5+温感5
        uint16_t sen_smoke5_mix_temper5 :1;         // 柜5-烟感5+复合传感器5-温度
        uint16_t sen_temper5_mix_co5    :1;         // 柜5-温感5+复合传感器5-CO
        uint16_t sen_smoke6_sen_temper6 :1;         // 柜6-烟感6+温感6
        uint16_t sen_smoke6_mix_temper6 :1;         // 柜6-烟感6+复合传感器6-温度
        uint16_t sen_temper6_mix_co6    :1;         // 柜6-温感6+复合传感器6-CO
    } bit;
} ff_warn2_flag_u;

/**
  * @union ff_fault_flag_u
  * @brief modbus数据 消防故障标志位  
  */
typedef union 
{
    uint16_t array[1];
    struct {
        uint16_t ff_gas_pressure_high :1;           // 瓶组高压告警
        uint16_t ff_gas_pressure_low  :1;           // 瓶组低压告警
        uint16_t io_ext1_offline      :1;           // I/O模块1-通讯故障
        uint16_t io_ext2_offline      :1;           // I/O模块2-通讯故障
        uint16_t io_ext3_offline      :1;           // I/O模块3-通讯故障
        uint16_t io_ext4_offline      :1;           // I/O模块4-通讯故障
        uint16_t io_ext5_offline      :1;           // I/O模块5-通讯故障
        uint16_t io_ext6_offline      :1;           // I/O模块6-通讯故障
        uint16_t io_mix_sen1_offline  :1;           // 复合传感器1-通讯故障
        uint16_t io_mix_sen2_offline  :1;           // 复合传感器2-通讯故障
        uint16_t io_mix_sen3_offline  :1;           // 复合传感器3-通讯故障
        uint16_t io_mix_sen4_offline  :1;           // 复合传感器4-通讯故障
        uint16_t io_mix_sen5_offline  :1;           // 复合传感器5-通讯故障
        uint16_t io_mix_sen6_offline  :1;           // 复合传感器6-通讯故障
        uint16_t bat_num_set_zero     :1;           // 从机挂载数量为0情况
    } bit;
} ff_fault_flag_u;

/**
  * @union ff_io_sta_u
  * @brief modbus数据 消防控制器 IO 状态  
  */
typedef union 
{
    uint16_t array[3];
    struct {
        uint16_t emerg_start  :1;                   //  控制器直接接入-紧急启动       
        uint16_t emerg_stop   :1;                   //  控制器直接接入-紧急停止       
        uint16_t cmu_start    :1;                   //  控制器直接接入-CMU启动信号       
        uint16_t ff_pipe_sig  :1;                   //  控制器直接接入-信号反馈-1           
        uint16_t reserve1     :12;      

        uint16_t sen_smoke1   :1;                   // I/O模块输入-烟感1
        uint16_t sen_smoke2   :1;                   // I/O模块输入-烟感2
        uint16_t sen_smoke3   :1;                   // I/O模块输入-烟感3
        uint16_t sen_smoke4   :1;                   // I/O模块输入-烟感4
        uint16_t sen_smoke5   :1;                   // I/O模块输入-烟感5
        uint16_t sen_smoke6   :1;                   // I/O模块输入-烟感6
        uint16_t reserve2     :2;
        uint16_t sen_temper1  :1;                   // I/O模块输入-温感1
        uint16_t sen_temper2  :1;                   // I/O模块输入-温感2
        uint16_t sen_temper3  :1;                   // I/O模块输入-温感3
        uint16_t sen_temper4  :1;                   // I/O模块输入-温感4
        uint16_t sen_temper5  :1;                   // I/O模块输入-温感5
        uint16_t sen_temper6  :1;                   // I/O模块输入-温感6
        uint16_t reserve3     :2;

        uint16_t solenoid_sta :1;                   // 控制器直接输出-灭火剂瓶组启动
        uint16_t reserve4     :3;                   // 保留
        uint16_t ff_alarm     :1;                   // 控制器直接输出-声光报警
        uint16_t reserve5     :5;                   // 保留
        uint16_t ff_warn1     :1;                   // 控制器直接输出-一级告警
        uint16_t ff_warn2     :1;                   // 控制器直接输出-二级告警
        uint16_t ff_fault     :1;                   // 控制器直接输出-故障告警
    } bit;
} ff_io_sta_u;

/**
  * @struct ff_data_info_t
  * @brief modbus数据 消防控制器 
  *        收集到的数据【气瓶压力/复合传感器(温度/pm2.5/CO)】  
  */
typedef struct 
{
    uint16_t    ff_gas_pressure;                  // 瓶组压力             单位：1Kpa                             
    int16_t     mix_sen_temper[ BAT_CLUSTER_MAX ];      // 复合传感器1~6-温度    单位：1℃                        
    int16_t     mix_sen_pm25  [ BAT_CLUSTER_MAX ];      // 复合传感器1~6-PM2.5  单位：1ug/m³                 
    int16_t     mix_sen_co    [ BAT_CLUSTER_MAX ];      // 复合传感器1~6-CO     单位：1PPm                  
} ff_data_info_t;

/**
  * @struct ff_warn1_info_t
  * @brief modbus数据 一级告警时，锁存警告数据
  */
typedef struct
{
    ff_warn1_bat_t lock_warn_dat[ BAT_CLUSTER_MAX ];  
} ff_warn1_info_t;

/**
  * @struct ff_warn2_pack_info_t
  * @brief modbus数据 报警时柜 1~6 温度 锁存
  */
typedef struct
{
    ff_warn2_bat_t lock_warn_dat[ BAT_CLUSTER_MAX ]; 
} ff_warn2_pack_info_t;


typedef struct 
{
    int16_t   max_temper1;                  // 电池簇的最高温度温度值1 ,单位：1℃ //TODO : 改为有符号
    int16_t   max_temper2;                  // 电池簇的最高温度温度值2 ,单位：1℃
    int16_t   max_temper3;                  // 电池簇的最高温度温度值3 ,单位：1℃
    uint16_t  temper1_pack_id;              // 电池簇最高温度1对应pack号
    uint16_t  temper2_pack_id;              // 电池簇最高温度2对应pack号
    uint16_t  temper3_pack_id;              // 电池簇最高温度3对应pack号
} bat_mb_temper_t;

/**
  * @struct ff_bat_tmp_t
  * @brief modbus数据 电池柜 1~6 温度数据
  */
typedef struct {
    bat_mb_temper_t bat[ BAT_CLUSTER_MAX ];                
} ff_bat_tmp_t;

typedef struct {
    uint16_t    ff_gas_pressure_low;              // 消防气瓶压力表1低压阈值               单位：1 kPa
    uint16_t    ff_gas_pressure_high;             // 消防气瓶压力表1高压阈值               单位：1 kPa
    uint16_t    ff_alarm_level1_pack_temp;        // 消防一级报警PACK温度                  单位：1 ℃
    uint16_t    ff_alarm_level1_sensor_temp;      // 消防一级报警复合传感器温度            单位：1 ℃
    uint16_t    ff_alarm_level1_sensor_pm25;      // 消防一级报警复合传感器pm2.5浓度       单位：1 ug/m³
    uint16_t    ff_alarm_level2_pack_max_temp;    // 消防二级报警PACK最高温度              单位：1 ℃
    uint16_t    ff_alarm_level2_pack_sec_temp;    // 消防二级报警PACK温度次高温度          单位：1 ℃
    uint16_t    ff_alarm_level2_pack_co;          // 消防二级报警复合传感器CO浓度【pack】  单位：1 ppm
    uint16_t    ff_alarm_level2_compart_temp;     // 消防二级报警复合传感器温度            单位：1 ℃
    uint16_t    ff_alarm_level2_compart_co;       // 消防二级报警复合传感器CO浓度【舱级】  单位：1 ppm
    uint16_t    ff_solenoid_keep_tm;              // 灭火剂瓶组持续启动时间设置            单位：1 S
    uint16_t    ff_set_bat_num;                   // 从机挂载数量                          单位：个
} ff_param_set_t;

typedef struct {
    uint16_t    sw_ver;                             // 软件版本【十进制】，例如： 31 = v3.1
    uint16_t    mix_sen_type_rd;                    // 复合感器类型 0：四方光电  1：CPR-ES
    uint16_t    mix_sen_type_wr;                    // 复合感器类型 0：四方光电  1：CPR-ES
} ff_dev_info_t;

typedef struct 
{
    bool    valid;
    uint8_t sw_major_ver;
    uint8_t sw_sub_ver;
} ff_sw_t;

/*--------------------------------------------- modbus 协议结构体 end---------------------------------------------------------*/


/*--------------------------------------------- modbus 地址信息 ---------------------------------------------------------*/
#define FF_MB_REG_ADDR_R_FF_IO_STA                   1          // IO 状态
typedef ff_io_sta_u     mb_ff_io_sta_u; 

#define FF_MB_REG_ADDR_R_FF_DATA_INFO                4          // 数据信息
typedef ff_data_info_t  mb_ff_data_info_t; 

#define FF_MB_REG_ADDR_R_WARN1_FLAG                  23         // 一级告警信息
typedef ff_warn1_flag_u mb_ff_warn1_flag_u;

#define FF_MB_REG_ADDR_R_WARN1_LOCK_INFO             26         // 一级告警锁定信息
typedef ff_warn1_info_t mb_ff_warn1_info_t;

#define FF_MB_REG_ADDR_R_WARN2_PACK_FLAG             50         // 二级(PACK)告警信息
typedef ff_warn2_pack_flag_u mb_ff_warn2_pack_flag_u;
#define FF_MB_REG_ADDR_R_WARN2_PACK_LOCK_INFO        51         // 二级(PACK)告警 锁存信息 
typedef ff_warn2_pack_info_t mb_ff_warn2_pack_info_t;

#define FF_MB_REG_ADDR_R_WARN2_INFO                  69         // 二级(舱级)告警信息
typedef ff_warn2_flag_u   mb_ff_warn2_flag_u;

#define FF_MB_REG_ADDR_R_FAULT_INFO                  71         // 故障告警
typedef ff_fault_flag_u   mb_ff_fault_flag_u;

#define FF_MB_REG_ADDR_WR_BAT_DATA                   72         // 电池温度数据
typedef ff_bat_tmp_t   mb_ff_bat_tmp_t;

#define FF_MB_REG_ADDR_WR_REMOTE_START               108        // 远程启动
#define FF_MB_REG_ADDR_WR_REMOTE_RESET               109        // 远程复位

#define FF_MB_REG_ADDR_PARAM_SETTING                 110        // 参数设置
typedef ff_param_set_t    mb_ff_param_set_t;            

#define FF_MB_REG_ADDR_LOW_PRESSURE_TH               110        // 气瓶低压告警阈值

#define FF_MB_REG_ADDR_DEV_INFO                      353        // 设备信息
typedef ff_dev_info_t    mb_ff_dev_info_t;            

/*--------------------------------------------- modbus 地址信息 end---------------------------------------------------------*/

static modbus_idx_t      s_modbus_idx    = MODBUS_IDX_INVALID;
static uint8_t           s_bat_num       = 0;
static ff_sw_t           s_ff_sw         = { 0 };

static rate_t           com_loss_rate   = 0;                  //< 通讯丢包率

sf_ret_t fire_fight_dev_init( modbus_idx_t modbus_idx )
{
    ff_dev_info_t ff_dev_info = {0};

    if( s_modbus_idx != MODBUS_IDX_INVALID )
    {
        app_modbus_close(s_modbus_idx);
    }

    int32_t ret = app_modbus_rtu_init( modbus_idx, MODBUS_SLAVE_ADDR, MODBUS_BUADRATE );
    if ( 0 > ret )
    {
        sdk_log_e( "%s, app_modbus_rtu_init ret:%d ", __FUNCTION__, ret);
        return ret;
    }
    s_modbus_idx = modbus_idx;

    ret = app_modbus_connect( s_modbus_idx );
    if ( 0 > ret )
    {
        sdk_log_e( "%s, app_modbus_connect ret:%d ", __FUNCTION__, ret);
        return ret;
    }
    app_modbus_response_timeout_set( s_modbus_idx, 200 );

    return SF_OK;
}

void fire_fight_dev_get_sw_ver( uint8_t *sw_major_ver, uint8_t *sw_sub_ver )
{
    *sw_major_ver = s_ff_sw.sw_major_ver;
    *sw_sub_ver   = s_ff_sw.sw_sub_ver;
}

rate_t fire_fight_dev_get_com_loss_rate( void )
{
    return com_loss_rate;
}

sf_ret_t fire_fight_dev_set_low_pressure_threshold( uint16_t low_pressure_threshold )
{
    uint16_t pressure_threshold = low_pressure_threshold;
    
    for (size_t i = 0; i < 3; i++)
    {
        if ( 0 <= app_modbus_registers_write( s_modbus_idx, MODBUS_SLAVE_ADDR, 
                                            FF_MB_REG_ADDR_LOW_PRESSURE_TH , 1,  
                                            (const uint16_t*)&pressure_threshold, 50 ))
            return SF_OK;
    }

    return SF_ERR_WR;
}

sf_ret_t fire_fight_dev_set_pressure_threshold( uint16_t low_pressure_threshold, uint16_t hig_pressure_threshold )
{
    uint16_t pressure_thresholds[2] = {0,0};

    pressure_thresholds[0] = low_pressure_threshold;
    pressure_thresholds[1] = hig_pressure_threshold;
    
    for (size_t i = 0; i < 3; i++)
    {
        if ( 0 <= app_modbus_registers_write( s_modbus_idx, MODBUS_SLAVE_ADDR, 
                                            FF_MB_REG_ADDR_LOW_PRESSURE_TH , 2,  
                                            (const uint16_t*)pressure_thresholds, 50 ))
            return SF_OK;
    }

    return SF_ERR_WR;
}

/**
 * @brief  消防控制器 设置电池簇数量
 * @param  [in] bat_num：电池簇数量
 * @return SF_OK：正常  非SF_OK：异常  
 * @note   
 */
sf_ret_t fire_fight_dev_set_bat_num( uint8_t bat_num )
{
    uint16_t bat_num_u16 = bat_num;

    int32_t ret = app_modbus_registers_write( s_modbus_idx, MODBUS_SLAVE_ADDR, 
                                              FF_MB_REG_ADDR_PARAM_SETTING + ST_MEMBER_TO_MODBUS_OFFSET( mb_ff_param_set_t, ff_set_bat_num ), 
                                              1,(const uint16_t*)&bat_num_u16, 50 );
    if ( 0 > ret )
    {
        sdk_log_e( "%s , ret:%d ", __FUNCTION__, ret);
        return SF_ERR_WR;
    }
    else
    {
        sdk_log_d("%s success", __FUNCTION__);
    }

    s_bat_num = bat_num;

    return SF_OK;
}

/**
 * @brief  消防控制器 设置阈值
 * @param  [in] p_ff_threshold：消防控制器设置参数
 * @param  [in] bat_num：电池簇数量
 * @return SF_OK：正常  非SF_OK：异常  
 * @note   
 */
sf_ret_t fire_fight_dev_set_threshold( ff_threshold_set_t *p_ff_threshold, uint8_t bat_num )
{
    mb_ff_param_set_t mb_ff_param_set = {0};
    
    mb_ff_param_set.ff_gas_pressure_low            =  p_ff_threshold->ff_gas_pressure_low;
    mb_ff_param_set.ff_gas_pressure_high           =  p_ff_threshold->ff_gas_pressure_high;
    mb_ff_param_set.ff_alarm_level1_pack_temp      =  p_ff_threshold->ff_alarm_level1_pack_temp;
    mb_ff_param_set.ff_alarm_level1_sensor_temp    =  p_ff_threshold->ff_alarm_level1_sensor_temp;
    mb_ff_param_set.ff_alarm_level1_sensor_pm25    =  p_ff_threshold->ff_alarm_level1_sensor_pm25;
    mb_ff_param_set.ff_alarm_level2_pack_max_temp  =  p_ff_threshold->ff_alarm_level2_pack_temp;
    mb_ff_param_set.ff_alarm_level2_pack_sec_temp  =  p_ff_threshold->ff_alarm_level2_pack_temp1;
    mb_ff_param_set.ff_alarm_level2_pack_co        =  p_ff_threshold->ff_alarm_level2_sensor_co;
    mb_ff_param_set.ff_alarm_level2_compart_temp   =  p_ff_threshold->ff_alarm_level2_compart_temp;
    mb_ff_param_set.ff_alarm_level2_compart_co     =  p_ff_threshold->ff_alarm_level2_compart_co;
    mb_ff_param_set.ff_solenoid_keep_tm            =  1200;
    mb_ff_param_set.ff_set_bat_num                 =  bat_num;

    int32_t ret = app_modbus_registers_write( s_modbus_idx, MODBUS_SLAVE_ADDR, 
                                FF_MB_REG_ADDR_PARAM_SETTING , sizeof(mb_ff_param_set_t)/sizeof(uint16_t), 
                                (const uint16_t*)&mb_ff_param_set, 50 );
    if ( 0 > ret )
    {
        sdk_log_e( "%s , ret:%d ", __FUNCTION__, ret);
        return ret;
    }
    else
    {
        sdk_log_d("%s success", __FUNCTION__);
    }

    s_bat_num = bat_num;

    return SF_OK;
}

static void _fire_fighting2_rd_local_ff_data( ff_dev_dat_t *p_ff_dev_dat )
{
    p_ff_dev_dat->do_sta.bit.ff_com_falut     = app_dido_read( DI_FF_COMM_FAULT );
    p_ff_dev_dat->do_sta.bit.ff_warn1         = app_dido_read( DI_FF_WARN1 );
    p_ff_dev_dat->do_sta.bit.ff_warn2         = app_dido_read( DI_FF_WARN2 );

    p_ff_dev_dat->warn2.bit.start_ff_solenoid = p_ff_dev_dat->do_sta.bit.ff_warn2;
}

sf_ret_t fire_fight_dev_rd_mb_ff_data( ff_dev_dat_t *p_ff_dev_dat )
{
    static uint32_t  total_fail_cnt  = 0;                  //< 总消息失败次数
    static uint32_t  total_msg_cnt   = 0;                  //< 总消息次数

    struct {
        mb_ff_io_sta_u           io_sta;
        mb_ff_data_info_t        data_info;
        mb_ff_warn1_flag_u       warn1_flag;
        mb_ff_warn1_info_t       warn1_info;
        mb_ff_warn2_pack_flag_u  warn2_pack_flag;
        mb_ff_warn2_pack_info_t  warn2_pack_info;
        mb_ff_warn2_flag_u       warn2_flag;
        mb_ff_fault_flag_u       fault_flag;
    } mb_ff_sta_dat = {0};

    _fire_fighting2_rd_local_ff_data( p_ff_dev_dat );
    int32_t ret = app_modbus_registers_read( s_modbus_idx, MODBUS_SLAVE_ADDR, FF_MB_REG_ADDR_R_FF_IO_STA, 
                                             sizeof(mb_ff_sta_dat)/2, (uint16_t*)&mb_ff_sta_dat, 0 );

    if( ret < SF_OK )
    {
        total_fail_cnt++;
    }
    total_msg_cnt++;
    com_loss_rate = (rate_t)( (float)total_fail_cnt / (float)total_msg_cnt * 10000.0f );
    
    if( ret < SF_OK )
    {
        return SF_ERR_RD;
    }

    /*--------------------------------MODBUS 数据结构 转化 为 协议通用结构 ------------------------------*/
    /* 通过 IO 获取更为准确 */
    // p_ff_dev_dat->do_sta.bit.ff_com_falut               = mb_ff_sta_dat.io_sta.bit.ff_fault;
    // p_ff_dev_dat->do_sta.bit.ff_warn1                   = mb_ff_sta_dat.io_sta.bit.ff_warn1;
    // p_ff_dev_dat->do_sta.bit.ff_warn2                   = mb_ff_sta_dat.io_sta.bit.ff_warn2;
    // p_ff_dev_dat->do_sta.bit.ff_solenoid                = mb_ff_sta_dat.io_sta.bit.solenoid_sta;

    p_ff_dev_dat->di_sta.bit.smoke_sensor1              = mb_ff_sta_dat.io_sta.bit.sen_smoke1;
    p_ff_dev_dat->di_sta.bit.smoke_sensor2              = mb_ff_sta_dat.io_sta.bit.sen_smoke2;
    p_ff_dev_dat->di_sta.bit.smoke_sensor3              = mb_ff_sta_dat.io_sta.bit.sen_smoke3;
    p_ff_dev_dat->di_sta.bit.smoke_sensor4              = mb_ff_sta_dat.io_sta.bit.sen_smoke4;
    p_ff_dev_dat->di_sta.bit.smoke_sensor5              = mb_ff_sta_dat.io_sta.bit.sen_smoke5;
    p_ff_dev_dat->di_sta.bit.smoke_sensor6              = mb_ff_sta_dat.io_sta.bit.sen_smoke6;

    p_ff_dev_dat->di_sta.bit.temp_sensor1              = mb_ff_sta_dat.io_sta.bit.sen_temper1;
    p_ff_dev_dat->di_sta.bit.temp_sensor2              = mb_ff_sta_dat.io_sta.bit.sen_temper2;
    p_ff_dev_dat->di_sta.bit.temp_sensor3              = mb_ff_sta_dat.io_sta.bit.sen_temper3;
    p_ff_dev_dat->di_sta.bit.temp_sensor4              = mb_ff_sta_dat.io_sta.bit.sen_temper4;
    p_ff_dev_dat->di_sta.bit.temp_sensor5              = mb_ff_sta_dat.io_sta.bit.sen_temper5;
    p_ff_dev_dat->di_sta.bit.temp_sensor6              = mb_ff_sta_dat.io_sta.bit.sen_temper6;

    p_ff_dev_dat->di_sta.bit.ff_pipe_sig                = mb_ff_sta_dat.io_sta.bit.ff_pipe_sig;
    p_ff_dev_dat->do_sta.bit.ff_solenoid                = mb_ff_sta_dat.io_sta.bit.solenoid_sta;
    
    p_ff_dev_dat->warn1.bit.pack1_temp_alarm            = mb_ff_sta_dat.warn1_flag.bit.pack_temper1;
    p_ff_dev_dat->warn1.bit.pack2_temp_alarm            = mb_ff_sta_dat.warn1_flag.bit.pack_temper2;
    p_ff_dev_dat->warn1.bit.pack3_temp_alarm            = mb_ff_sta_dat.warn1_flag.bit.pack_temper3;
    p_ff_dev_dat->warn1.bit.pack4_temp_alarm            = mb_ff_sta_dat.warn1_flag.bit.pack_temper4;
    p_ff_dev_dat->warn1.bit.pack5_temp_alarm            = mb_ff_sta_dat.warn1_flag.bit.pack_temper5;
    p_ff_dev_dat->warn1.bit.pack6_temp_alarm            = mb_ff_sta_dat.warn1_flag.bit.pack_temper6;

    p_ff_dev_dat->warn1.bit.ff_smoke_sensor1            = mb_ff_sta_dat.warn1_flag.bit.sen_smoke1;
    p_ff_dev_dat->warn1.bit.ff_smoke_sensor2            = mb_ff_sta_dat.warn1_flag.bit.sen_smoke2;
    p_ff_dev_dat->warn1.bit.ff_smoke_sensor3            = mb_ff_sta_dat.warn1_flag.bit.sen_smoke3;
    p_ff_dev_dat->warn1.bit.ff_smoke_sensor4            = mb_ff_sta_dat.warn1_flag.bit.sen_smoke4;
    p_ff_dev_dat->warn1.bit.ff_smoke_sensor5            = mb_ff_sta_dat.warn1_flag.bit.sen_smoke5;
    p_ff_dev_dat->warn1.bit.ff_smoke_sensor6            = mb_ff_sta_dat.warn1_flag.bit.sen_smoke6;
    p_ff_dev_dat->warn1.bit.ff_temp_sensor1             = mb_ff_sta_dat.warn1_flag.bit.sen_temper1;
    p_ff_dev_dat->warn1.bit.ff_temp_sensor2             = mb_ff_sta_dat.warn1_flag.bit.sen_temper2;
    p_ff_dev_dat->warn1.bit.ff_temp_sensor3             = mb_ff_sta_dat.warn1_flag.bit.sen_temper3;
    p_ff_dev_dat->warn1.bit.ff_temp_sensor4             = mb_ff_sta_dat.warn1_flag.bit.sen_temper4;
    p_ff_dev_dat->warn1.bit.ff_temp_sensor5             = mb_ff_sta_dat.warn1_flag.bit.sen_temper5;
    p_ff_dev_dat->warn1.bit.ff_temp_sensor6             = mb_ff_sta_dat.warn1_flag.bit.sen_temper6;
    p_ff_dev_dat->warn1.bit.mix_sensor1_temp_alarm      = mb_ff_sta_dat.warn1_flag.bit.mix_temper1;
    p_ff_dev_dat->warn1.bit.mix_sensor2_temp_alarm      = mb_ff_sta_dat.warn1_flag.bit.mix_temper2;
    p_ff_dev_dat->warn1.bit.mix_sensor3_temp_alarm      = mb_ff_sta_dat.warn1_flag.bit.mix_temper3;
    p_ff_dev_dat->warn1.bit.mix_sensor4_temp_alarm      = mb_ff_sta_dat.warn1_flag.bit.mix_temper4;
    p_ff_dev_dat->warn1.bit.mix_sensor5_temp_alarm      = mb_ff_sta_dat.warn1_flag.bit.mix_temper5;
    p_ff_dev_dat->warn1.bit.mix_sensor6_temp_alarm      = mb_ff_sta_dat.warn1_flag.bit.mix_temper6;

    p_ff_dev_dat->warn1.bit.mix_sensor1_pm25_co_alarm  = (mb_ff_sta_dat.warn1_flag.bit.mix_pm25_1 || mb_ff_sta_dat.warn1_flag.bit.mix_co_1);
    p_ff_dev_dat->warn1.bit.mix_sensor2_pm25_co_alarm  = (mb_ff_sta_dat.warn1_flag.bit.mix_pm25_2 || mb_ff_sta_dat.warn1_flag.bit.mix_co_2);
    p_ff_dev_dat->warn1.bit.mix_sensor3_pm25_co_alarm  = (mb_ff_sta_dat.warn1_flag.bit.mix_pm25_3 || mb_ff_sta_dat.warn1_flag.bit.mix_co_3);
    p_ff_dev_dat->warn1.bit.mix_sensor4_pm25_co_alarm  = (mb_ff_sta_dat.warn1_flag.bit.mix_pm25_4 || mb_ff_sta_dat.warn1_flag.bit.mix_co_4);
    p_ff_dev_dat->warn1.bit.mix_sensor5_pm25_co_alarm  = (mb_ff_sta_dat.warn1_flag.bit.mix_pm25_5 || mb_ff_sta_dat.warn1_flag.bit.mix_co_5);
    p_ff_dev_dat->warn1.bit.mix_sensor6_pm25_co_alarm  = (mb_ff_sta_dat.warn1_flag.bit.mix_pm25_6 || mb_ff_sta_dat.warn1_flag.bit.mix_co_6);
    
    p_ff_dev_dat->warn1.bit.mix_sensor1_offline         = mb_ff_sta_dat.fault_flag.bit.io_mix_sen1_offline;
    p_ff_dev_dat->warn1.bit.mix_sensor2_offline         = mb_ff_sta_dat.fault_flag.bit.io_mix_sen2_offline;
    p_ff_dev_dat->warn1.bit.mix_sensor3_offline         = mb_ff_sta_dat.fault_flag.bit.io_mix_sen3_offline;
    p_ff_dev_dat->warn1.bit.mix_sensor4_offline         = mb_ff_sta_dat.fault_flag.bit.io_mix_sen4_offline;
    p_ff_dev_dat->warn1.bit.mix_sensor5_offline         = mb_ff_sta_dat.fault_flag.bit.io_mix_sen5_offline;
    p_ff_dev_dat->warn1.bit.mix_sensor6_offline         = mb_ff_sta_dat.fault_flag.bit.io_mix_sen6_offline;
    p_ff_dev_dat->warn1.bit.ff_glass_pressure_over_hig  = mb_ff_sta_dat.fault_flag.bit.ff_gas_pressure_high;
    p_ff_dev_dat->warn1.bit.ff_glass_pressure_over_low  = mb_ff_sta_dat.fault_flag.bit.ff_gas_pressure_low;

    p_ff_dev_dat->warn1.bit.ff_io_ext_offline          = (   (mb_ff_sta_dat.fault_flag.bit.io_ext1_offline)
                                                          || (mb_ff_sta_dat.fault_flag.bit.io_ext2_offline)
                                                          || (mb_ff_sta_dat.fault_flag.bit.io_ext3_offline)
                                                          || (mb_ff_sta_dat.fault_flag.bit.io_ext4_offline)
                                                          || (mb_ff_sta_dat.fault_flag.bit.io_ext5_offline)
                                                          || (mb_ff_sta_dat.fault_flag.bit.io_ext6_offline));

    for (size_t i = 0; i < BAT_CLUSTER_MAX; i++)
    {
        p_ff_dev_dat->sen_dat.mix_sen[i].mix_sen_co   = mb_ff_sta_dat.data_info.mix_sen_co[i];
        p_ff_dev_dat->sen_dat.mix_sen[i].mix_sen_pm25 = mb_ff_sta_dat.data_info.mix_sen_pm25[i];
        p_ff_dev_dat->sen_dat.mix_sen[i].mix_sen_temp = mb_ff_sta_dat.data_info.mix_sen_temper[i] * 10;
    }

    p_ff_dev_dat->warn2.bit.pack_temp_mix_co_alarm1   = mb_ff_sta_dat.warn2_pack_flag.bit.pack1_tmp_mix_co1;            // 电池柜1 PACK温度+1#CO报警
    p_ff_dev_dat->warn2.bit.pack_temp_mix_co_alarm2   = mb_ff_sta_dat.warn2_pack_flag.bit.pack2_tmp_mix_co2;            // 电池柜2 PACK温度+2#CO报警
    p_ff_dev_dat->warn2.bit.pack_temp_mix_co_alarm3   = mb_ff_sta_dat.warn2_pack_flag.bit.pack3_tmp_mix_co3;            // 电池柜3 PACK温度+3#CO报警
    p_ff_dev_dat->warn2.bit.pack_temp_mix_co_alarm4   = mb_ff_sta_dat.warn2_pack_flag.bit.pack4_tmp_mix_co4;            // 电池柜4 PACK温度+4#CO报警
    p_ff_dev_dat->warn2.bit.pack_temp_mix_co_alarm5   = mb_ff_sta_dat.warn2_pack_flag.bit.pack5_tmp_mix_co5;            // 电池柜5 PACK温度+5#CO报警
    p_ff_dev_dat->warn2.bit.pack_temp_mix_co_alarm6   = mb_ff_sta_dat.warn2_pack_flag.bit.pack6_tmp_mix_co6;            // 电池柜6 PACK温度+6#CO报警
    p_ff_dev_dat->warn2.bit.smoke_sen_temp_sen_alarm1 = mb_ff_sta_dat.warn2_flag.bit.sen_smoke1_sen_temper1;       // 电池柜 1#烟感+温感报警
    p_ff_dev_dat->warn2.bit.smoke_sen_temp_sen_alarm2 = mb_ff_sta_dat.warn2_flag.bit.sen_smoke2_sen_temper2;       // 电池柜 2#烟感+温感报警
    p_ff_dev_dat->warn2.bit.smoke_sen_temp_sen_alarm3 = mb_ff_sta_dat.warn2_flag.bit.sen_smoke3_sen_temper3;       // 电池柜 3#烟感+温感报警
    p_ff_dev_dat->warn2.bit.smoke_sen_temp_sen_alarm4 = mb_ff_sta_dat.warn2_flag.bit.sen_smoke4_sen_temper4;       // 电池柜 4#烟感+温感报警
    p_ff_dev_dat->warn2.bit.smoke_sen_temp_sen_alarm5 = mb_ff_sta_dat.warn2_flag.bit.sen_smoke5_sen_temper5;       // 电池柜 5#烟感+温感报警
    p_ff_dev_dat->warn2.bit.smoke_sen_temp_sen_alarm6 = mb_ff_sta_dat.warn2_flag.bit.sen_smoke6_sen_temper6;       // 电池柜 6#烟感+温感报警
    p_ff_dev_dat->warn2.bit.smoke_sen_mix_tmp1_alarm1 = mb_ff_sta_dat.warn2_flag.bit.sen_smoke1_mix_temper1;       // 烟感+1#复合型传感器温度
    p_ff_dev_dat->warn2.bit.smoke_sen_mix_tmp2_alarm2 = mb_ff_sta_dat.warn2_flag.bit.sen_smoke2_mix_temper2;       // 烟感+2#复合型传感器温度
    p_ff_dev_dat->warn2.bit.smoke_sen_mix_tmp3_alarm3 = mb_ff_sta_dat.warn2_flag.bit.sen_smoke3_mix_temper3;       // 烟感+3#复合型传感器温度
    p_ff_dev_dat->warn2.bit.smoke_sen_mix_tmp4_alarm4 = mb_ff_sta_dat.warn2_flag.bit.sen_smoke4_mix_temper4;       // 烟感+4#复合型传感器温度
    p_ff_dev_dat->warn2.bit.smoke_sen_mix_tmp5_alarm5 = mb_ff_sta_dat.warn2_flag.bit.sen_smoke5_mix_temper5;       // 烟感+5#复合型传感器温度
    p_ff_dev_dat->warn2.bit.smoke_sen_mix_tmp6_alarm6 = mb_ff_sta_dat.warn2_flag.bit.sen_smoke6_mix_temper6;       // 烟感+6#复合型传感器温度
    p_ff_dev_dat->warn2.bit.tmp_sen_mix_co_alarm1     = mb_ff_sta_dat.warn2_flag.bit.sen_temper1_mix_co1;          // 电池柜1 温感+复合型传感器1#CO
    p_ff_dev_dat->warn2.bit.tmp_sen_mix_co_alarm2     = mb_ff_sta_dat.warn2_flag.bit.sen_temper2_mix_co2;          // 电池柜2 温感+复合型传感器2#CO
    p_ff_dev_dat->warn2.bit.tmp_sen_mix_co_alarm3     = mb_ff_sta_dat.warn2_flag.bit.sen_temper3_mix_co3;          // 电池柜3 温感+复合型传感器3#CO
    p_ff_dev_dat->warn2.bit.tmp_sen_mix_co_alarm4     = mb_ff_sta_dat.warn2_flag.bit.sen_temper4_mix_co4;          // 电池柜4 温感+复合型传感器4#CO
    p_ff_dev_dat->warn2.bit.tmp_sen_mix_co_alarm5     = mb_ff_sta_dat.warn2_flag.bit.sen_temper5_mix_co5;          // 电池柜5 温感+复合型传感器5#CO
    p_ff_dev_dat->warn2.bit.tmp_sen_mix_co_alarm6     = mb_ff_sta_dat.warn2_flag.bit.sen_temper6_mix_co6;          // 电池柜6 温感+复合型传感器6#CO

    p_ff_dev_dat->warn2.bit.cmu_start_ff              = mb_ff_sta_dat.io_sta.bit.cmu_start;                         // 消防控制器 CMU启动信号

    p_ff_dev_dat->ff_gas_pressure                     = mb_ff_sta_dat.data_info.ff_gas_pressure;

    /* 等待消防控制器上线之后再获取消防控制器软件版本 */
    if ( s_ff_sw.valid == false )
    {
        ff_dev_info_t ff_dev_info;

        for (size_t i = 0; i < 3; i++)
        {    
            ret = app_modbus_registers_read( s_modbus_idx, MODBUS_SLAVE_ADDR, FF_MB_REG_ADDR_DEV_INFO, 
                                                sizeof( ff_dev_info) / 2, (uint16_t*)&ff_dev_info, 100 );
            if ( 0 <= ret)
            {
                /* 读取成功跳出 */
                break;
            }
        }

        s_ff_sw.valid = true;
        s_ff_sw.sw_major_ver = ff_dev_info.sw_ver / 10;
        s_ff_sw.sw_sub_ver   = ff_dev_info.sw_ver % 10;
        sdk_log_d( "fire fight software ver: V%d.%d, mix sen type:%d", s_ff_sw.sw_major_ver, s_ff_sw.sw_sub_ver, ff_dev_info.mix_sen_type_wr );
    }

    return SF_OK;
}

void fire_fight_dev_wr_bat_tmp( bat_temper_t *p_bat_temper_list )
{
    mb_ff_bat_tmp_t mb_ff_bat_tmp = { 0 };
    uint16_t reg_num = 0;
    int32_t ret = 0;

    if ( s_bat_num == 0 )
        return;

    for (size_t i = 0; i < s_bat_num; i++)
    {
        mb_ff_bat_tmp.bat[i].max_temper1     =  p_bat_temper_list[i].max_temper1    ;
        mb_ff_bat_tmp.bat[i].max_temper2     =  p_bat_temper_list[i].max_temper2    ;
        mb_ff_bat_tmp.bat[i].max_temper3     =  p_bat_temper_list[i].max_temper3    ;
        mb_ff_bat_tmp.bat[i].temper1_pack_id =  p_bat_temper_list[i].temper1_pack_id;
        mb_ff_bat_tmp.bat[i].temper2_pack_id =  p_bat_temper_list[i].temper2_pack_id;
        mb_ff_bat_tmp.bat[i].temper3_pack_id =  p_bat_temper_list[i].temper3_pack_id;
    }

    reg_num = s_bat_num * sizeof( mb_ff_bat_tmp.bat[0] ) / 2;

    ret = app_modbus_registers_write( s_modbus_idx, MODBUS_SLAVE_ADDR, FF_MB_REG_ADDR_WR_BAT_DATA, \
                                      reg_num, (const uint16_t*)&mb_ff_bat_tmp, 50 );
    if ( 0 > ret )
    {
        // sdk_log_w( "%s, ret:%d ", __FUNCTION__, ret);
    }
    
    return;
}

sf_ret_t fire_fight_dev_set_mix_sensor_type( mix_sen_type_e mix_sen_type )
{
    mb_ff_dev_info_t mb_ff_dev_info = {0};
    int32_t ret;

    if ( mix_sen_type >= MIX_SEN_TYPE_MAX ) 
    {
        return SF_ERR_PARA;
    }

    if ( 0 > app_modbus_registers_read( s_modbus_idx, MODBUS_SLAVE_ADDR, FF_MB_REG_ADDR_DEV_INFO, sizeof( mb_ff_dev_info_t ) / sizeof( uint16_t ), (uint16_t*)&mb_ff_dev_info, 20  ))
    {
        return SF_ERR_RD;
    }

    mb_ff_dev_info.mix_sen_type_wr = mix_sen_type;
    if ( 0 > app_modbus_registers_write( s_modbus_idx, MODBUS_SLAVE_ADDR, FF_MB_REG_ADDR_DEV_INFO, 
                                         sizeof( mb_ff_dev_info_t ) / sizeof( uint16_t ), (uint16_t*)&mb_ff_dev_info, 20 ))
    {
        return SF_ERR_WR;
    }
    
    return SF_OK;
}

mix_sen_type_e fire_fight_dev_get_mix_sensor_type( void )
{
    mb_ff_dev_info_t mb_ff_dev_info = {0};
    int32_t ret;

    if ( 0 > app_modbus_registers_read( s_modbus_idx, MODBUS_SLAVE_ADDR, FF_MB_REG_ADDR_DEV_INFO, sizeof( mb_ff_dev_info_t ) / sizeof( uint16_t ), (uint16_t*)&mb_ff_dev_info, 20  ))
    {
        return MIX_SEN_TYPE_MAX;
    }
    
    return (mix_sen_type_e)mb_ff_dev_info.mix_sen_type_wr;
}
