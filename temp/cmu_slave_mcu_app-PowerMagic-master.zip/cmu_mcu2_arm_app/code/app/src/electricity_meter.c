#include "electricity_meter.h"
#include "app_cfg.h"

#include "sdk.h"
#include "sdk_core.h"
#include "sdk_modbus.h"

em_param_t em_param;
em_data_t em_data;


/**
* @brief		获取电表参数
* @param		[in] ： index 485索引号 
* @param		[out] ：th  温湿度数据结构体   
* @param		[out] ：slave 温湿度传感器地址   
* @return		读取结果
* @retval		返回执行结果：-1异常
* @warning		无
*/

int em_param_read(uint32_t index,em_data_t* data, uint32_t slave)
{
    int ret=-1;
	uint16_t em_read[128];
	union data  temp_u;
	uint8_t i;

    ret=sdk_modbus_slave_set(index, slave);
    if (ret == 0)
    {    
		ret = sdk_modbus_registers_read(index,EM_REG_UA,EM_DATA_LEN,em_read); 
		if(ret != -1)
		{
			i=0;
			temp_u.dword= em_read[i]<<16 | em_read[i+1];
			data->voltage_a = temp_u.f_data/10.0f;
			i+=2;
			temp_u.dword= em_read[i]<<16 | em_read[i+1];
			data->voltage_b = temp_u.f_data/10.0f;
			i+=2;
			temp_u.dword= em_read[i]<<16 | em_read[i+1];
			data->voltage_c = temp_u.f_data/10.0f;	
		}
		ret = sdk_modbus_registers_read(index,EM_REG_PT,EM_DATA1_LEN,em_read); 
		if(ret != -1)
		{
			i=0;
			temp_u.dword= em_read[i]<<16 | em_read[i+1];
			data->combined_active_power = temp_u.f_data/10.0f;
			i+=2;
			temp_u.dword= em_read[i]<<16 | em_read[i+1];
			data->active_power_a = temp_u.f_data/10.0f;
			i+=2;
			temp_u.dword= em_read[i]<<16 | em_read[i+1];
			data->active_power_b = temp_u.f_data/10.0f;
			i+=2;
			temp_u.dword= em_read[i]<<16 | em_read[i+1];
			data->active_power_c = temp_u.f_data/10.0f;
			i+=2;
			temp_u.dword= em_read[i]<<16 | em_read[i+1];
			data->combined_reactive_power = temp_u.f_data/10.0f;
			i+=2;
			temp_u.dword= em_read[i]<<16 | em_read[i+1];
			data->reactive_power_a = temp_u.f_data/10.0f;
			i+=2;
			temp_u.dword= em_read[i]<<16 | em_read[i+1];
			data->reactive_power_b = temp_u.f_data/10.0f;
			i+=2;
			temp_u.dword= em_read[i]<<16 | em_read[i+1];
			data->reactive_power_c = temp_u.f_data/10.0f;
			i+=2;	
		}
		ret = sdk_modbus_registers_read(index,EM_REG_FREQ,EM_DATA2_LEN,em_read); 
		if(ret != -1)
		{
			i=0;
			temp_u.dword= em_read[i]<<16 | em_read[i+1];
			data->freq = temp_u.f_data/100.0f;
		}
		ret = sdk_modbus_registers_read(index,EM_REG_IMPEP,EM_DATA3_LEN,em_read);  	
		if(ret != -1)
		{
			i=0;
			temp_u.dword= em_read[i]<<16 | em_read[i+1];
			data->ImpEp = temp_u.f_data;
			i+=2;
			temp_u.dword= em_read[i]<<16 | em_read[i+1];
			data->ImpEp_A = temp_u.f_data;
			i+=2;
			temp_u.dword= em_read[i]<<16 | em_read[i+1];
			data->ImpEp_B = temp_u.f_data;
			i+=2;
			temp_u.dword= em_read[i]<<16 | em_read[i+1];
			data->ImpEp_C = temp_u.f_data;
			i+=2;
			
		}
    }
    return ret;
}  
