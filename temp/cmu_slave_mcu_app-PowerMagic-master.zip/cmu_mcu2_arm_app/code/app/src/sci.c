#include "sci.h"
#include "sci_frame.h"
#include "stddef.h"
#include "sdk.h"
#include "sdk_core.h"
#include "sdk_uart.h"
#include "peripheral_task.h"
#include "main.h"
#include "crc32.h"
#include "electricity_meter.h"
#include "ff.h"
#include "num_trans.h"
#include "factory_test.h"
#include "factory_dev_test.h"

#include "tick_timer.h"
#include "bat_tmp_ctrl_api.h"
// #include "temper_humi.h"
#include "dh_ctrl.h"
#include "energy_cabinet.h"
#include "fire_fighting2.h"
#include "fire_fight_dev.h"
#include "fire_fight_local.h"
#include "fire_fight_share.h"
#include "lc_ctrl.h"
#include "app_cfg.h"
#include "extern_io.h"
#include "app_modbus.h"

#define SCI_START_WORD_H                    0x55			/* 指令起始字 */
#define SCI_START_WORD_L                    0xAA			/* 指令起始字 */
#define SCI_MIN_LEN                         9				/* 指令最小长度 */
#define SCI_FUNCID_HANDSHAKED_H             0x10          	/* 上电握手 */
#define SCI_FUNCID_HANDSHAKED_L             0x00          	/* 上电握手 */
#define SCI_FUNCID_SEND_THRESHOLD_INFO_H    0x20          	/* 下发动作阈值 */
#define SCI_FUNCID_SEND_THRESHOLD_INFO_L    0x00          	/* 下发动作阈值 */
#define SCI_FUNCID_GET_REALTIME_DATA_H      0x30          	/* 获取实时数据 */
#define SCI_FUNCID_GET_REALTIME_DATA_L      0x00          	/* 获取实时数据 */
#define SCI_BUF_SIZE                    260


#define CHIP_ROLE                   0x3C  		// 芯片角色
#define UPDATE_BUF_SIZE             2048        // 必须大于1024

#define UPDATE_TIMEOUT_MS                   10000           //< 升级超时时间，升级过程中，超过 *ms 没有升级数据，则退出升级模式


/**
  * @enum  temp_row_index_e
  * @brief 温度数组行索引
  */
enum temp_row_index_e
{
	BAT_TEMP_1	= 0,	
	BAT_TEMP_2 	= 1,    
	BAT_TEMP_3	= 2,
    BAT_TEMP_MAX
};



/**
  * @struct pack_max_temp_num_t
  * @brief  电池簇温度和pack号
  */
typedef struct
{    
    int16_t     	temp;    		// 最大温度
	uint16_t		pack_num;    	// 温度对应包序号
}pack_max_temp_num_t;

/**
  * @struct pack_temp_min_mean_t
  * @brief  电池簇最小温度和平均温度
  */
typedef struct
{    
    int16_t     min;    	// pack最小温度
	int16_t		mean;    	// pack平均温度
}pack_min_mean_temp_t;

/**
  * @struct pack_temp_t
  * @brief  电池簇温度结构体
  */
typedef struct
{    
    pack_max_temp_num_t     	max_temp_num[3];    	// pack最大温度和对应pack号
	pack_min_mean_temp_t		min_mean_temp;    		// 最小温度和平均温度
	uint16_t  pack_voltage;								// pack电压
	int16_t   pack_current;								// pack电流，单位：0.1A
}pack_temp_t;

pack_temp_t  g_pack_temp[BAT_CLUSTER_MAX]= {0};	
extern  pack_temp_t g_pack_temp[BAT_CLUSTER_MAX];


typedef struct {
    uint8_t lc_param : 1;
    uint8_t lc_logic_param : 1;
    uint8_t dry_param : 1;
    uint8_t ff_param : 1;
    uint8_t bat_num_param : 1;
    uint8_t eng_cab_attr : 1;
    uint8_t rtc_sync : 1;
} param_init_t;


int32_t sci_handshaked(uint8_t* in_buf, uint32_t in_len, uint8_t* out_buf, uint32_t* out_len);

static int32_t update_sci_chip_role(uint8_t* p_in_buf, uint32_t in_len, uint8_t* p_out_buf, uint32_t* p_out_len);
static int32_t update_sci_file_data(uint8_t* p_in_buf, uint32_t in_len, uint8_t* p_out_buf, uint32_t* p_out_len);
static int32_t update_sci_file_finish(uint8_t* p_in_buf, uint32_t in_len, uint8_t* p_out_buf, uint32_t* p_out_len);
static int32_t update_sci_start_upgrade(uint8_t* p_in, uint32_t in_len, uint8_t* p_out, uint32_t* p_out_len);


static int32_t _realtime_dat_sci_package(uint8_t* p_package_buff);
static int32_t sci_status_data_swap(uint8_t* in_buf, uint32_t in_len, uint8_t* out_buf, uint32_t* out_len);
static int32_t sci_lc_power_control(uint8_t* in_buf, uint32_t in_len, uint8_t* out_buf, uint32_t* out_len);
static int32_t sci_lc_threshold_set(uint8_t* in_buf, uint32_t in_len, uint8_t* out_buf, uint32_t* out_len);
static int32_t sci_cmu_mode_control(uint8_t* in_buf, uint32_t in_len, uint8_t* out_buf, uint32_t* out_len);
static int32_t sci_lc_control_param_set(uint8_t* in_buf, uint32_t in_len, uint8_t* out_buf, uint32_t* out_len);
static int32_t sci_ff_threshold_set(uint8_t* in_buf, uint32_t in_len, uint8_t* out_buf, uint32_t* out_len);
static int32_t sci_dry_setting(uint8_t* in_buf, uint32_t in_len, uint8_t* out_buf, uint32_t* out_len);
static int32_t sci_bat_param_setting(uint8_t/*  */* in_buf, uint32_t in_len, uint8_t* out_buf, uint32_t* out_len);
static int32_t sci_set_fan(uint8_t* in_buf, uint32_t in_len, uint8_t* out_buf, uint32_t* out_len);
static int32_t sci_set_set_eng_cab_attr(uint8_t* in_buf, uint32_t in_len, uint8_t* out_buf, uint32_t* out_len);
static int32_t sci_set_real_time(uint8_t* in_buf, uint32_t in_len, uint8_t* out_buf, uint32_t* out_len);
static int32_t sci_enter_factory_test(uint8_t *in_buf, uint32_t in_len, uint8_t *out_buf, uint32_t *out_len);
static int32_t sci_factory_test(uint8_t *in_buf, uint32_t in_len, uint8_t *out_buf, uint32_t *out_len);
static int32_t sci_factory_test_read_dat(uint8_t *in_buf, uint32_t in_len, uint8_t *out_buf, uint32_t *out_len);
static int32_t sci_factory_test_write_dat(uint8_t *in_buf, uint32_t in_len, uint8_t *out_buf, uint32_t *out_len);
static int32_t sci_quit_factory_test(uint8_t *in_buf, uint32_t in_len, uint8_t *out_buf, uint32_t *out_len);


uint8_t g_sci_send_buf[SCI_BUF_SIZE];
sci_t inboard_sci;
static sdk_uart_conf_t p_uart_conf;
uint8_t mcu1_sys_sta;           // 0：停机  1 ：待机  2：运行  3：故障  4：升级
uint8_t bcu_ready = 0;

uint8_t   param_init = 0;
bcu_status_u  bcu_status;

bool s_file_check = false;
bool s_file_check_success = false;

Realtime_SysInfo_t2 g_system_info2;
param_init_t        param_init2 = { 0 };
lc_control_param_t2 g_lc_control_param2;
dry_param_t2        g_dry_param2 = { 0 };
bat_param_t2        g_bat_param2 = { 1 };
ff_threshold_set_t  g_ff_threshold2;

static fs_t* p_fs = NULL;
static uint8_t g_update_buf[UPDATE_BUF_SIZE];
uint8_t g_reset_flg = 0;
typedef int32_t(*fn_t)(uint8_t* in_buf, uint32_t in_len, uint8_t* out_buf, uint32_t* out_len);

#define USR_SETTING_SYNC_FINISH()       ( param_init2.lc_param == 1 \
                                          && param_init2.lc_logic_param == 1 \
                                          && param_init2.bat_num_param == 1 \
                                          && param_init2.dry_param == 1 \
                                          && param_init2.rtc_sync == 1 \
                                          && param_init2.eng_cab_attr == 1 \
                                          && param_init2.ff_param == 1 )

#pragma pack(1)
/*
主机

起始字      2b      0x55aa
从节点地址  1b      1~247
字节长度    1b      从下一个字段“预留”到“数据”的全部长度
预留        1b
命令码      1b
子命令码    1b
数据        nb
校验码      2b      从“从节点地址”到“数据”字段所有数据之和
*/
typedef struct
{
    uint8_t start_word_h;
    uint8_t start_word_l;
    uint8_t slave_addr;
    uint8_t len;
    uint8_t reserved;
    uint8_t main_command;
    uint8_t sub_command;
    uint8_t data[1];
} sci_master_t;


/*
从机：
起始字      2b      0x55aa
从节点地址  1b      1~247
字节长度    1b      从下一个字段“命令码”到“数据”的全部长度
命令码      1b
子命令码    1b
数据        nb
校验码      2b      从“从节点地址”到“数据”字段所有数据之和
*/
typedef struct
{
    uint8_t start_word_h;
    uint8_t start_word_l;
    uint8_t slave_addr;
    uint8_t len;
    uint8_t main_command;
    uint8_t sub_command;
    uint8_t data[1];
} sci_slave_t;

#pragma pack()

typedef struct
{
    uint8_t command_h;
    uint8_t command_l;
    fn_t data_in_out;
} sci_context_t;

const sci_context_t sci_context[] =
{
    {.command_h = 0x10, .command_l = 0x00, .data_in_out = sci_handshaked},
    {.command_h = 0x20, .command_l = 0x00, .data_in_out = sci_status_data_swap},
    {.command_h = 0x30, .command_l = 0x00, .data_in_out = sci_lc_power_control},
    {.command_h = 0x30, .command_l = 0x20, .data_in_out = sci_cmu_mode_control},
    {.command_h = 0x30, .command_l = 0x30, .data_in_out = sci_lc_threshold_set},
    {.command_h = 0x30, .command_l = 0x40, .data_in_out = sci_lc_control_param_set},
    {.command_h = 0x30, .command_l = 0x50, .data_in_out = sci_ff_threshold_set},
    {.command_h = 0x30, .command_l = 0x60, .data_in_out = sci_dry_setting},
    {.command_h = 0x30, .command_l = 0x70, .data_in_out = sci_bat_param_setting},
    {.command_h = 0x30, .command_l = 0x80, .data_in_out = sci_set_fan},
    {.command_h = 0x30, .command_l = 0x90, .data_in_out = sci_set_set_eng_cab_attr},
    {.command_h = 0x30, .command_l = 0xA0, .data_in_out = sci_set_real_time},
    {.command_h = 0x90, .command_l = 0x10, .data_in_out = update_sci_chip_role},
    {.command_h = 0x90, .command_l = 0x20, .data_in_out = update_sci_file_data},
    {.command_h = 0x90, .command_l = 0x21, .data_in_out = update_sci_file_finish},
    {.command_h = 0x90, .command_l = 0x22, .data_in_out = update_sci_start_upgrade},
    {.command_h = 0x40, .command_l = 0x10, .data_in_out = sci_enter_factory_test},
	{.command_h = 0x40, .command_l = 0x20, .data_in_out = sci_factory_test},
	{.command_h = 0x40, .command_l = 0x21, .data_in_out = sci_factory_test_read_dat},
	{.command_h = 0x40, .command_l = 0x22, .data_in_out = sci_factory_test_write_dat},
	{.command_h = 0x40, .command_l = 0x30, .data_in_out = sci_quit_factory_test},
};


/**
* @brief		计算校验和
* @param		[in] ：in_buf 要校验的数据
* @param		[in] ：len  要校验的数据长度
* @param		[out] out_buf 输出校验和
* @return		无
* @retval		无
* @warning		无
*/
static void checksum_calc(uint8_t* in_buf, uint32_t len, uint8_t* out_buf)
{
    uint32_t i = 0;
    uint16_t sum = 0;

    for (i = 0; i < len; i++)
    {
        sum += *(in_buf + i);
    }

    out_buf[1] = (sum >> 8) & 0xFF;
    out_buf[0] = sum & 0xFF;
}


/**
* @brief		检查校验和
* @param		[in] buf 要校验的数据
* @param		[in] ：len  要校验的数据长度
* @param		[out] checksum 要检查的校验和
* @return		检查结果
* @retval		1-校验结果一致    0-校验结果不一致
* @warning		无
*/
static uint8_t checksum_check(uint8_t* buf, uint32_t len, uint8_t* checksum)
{
    uint32_t i = 0;
    uint16_t sum = 0;

    for (i = 0; i < len; i++)
    {
        sum += *(buf + i);
    }

    if ((sum & 0xFF) == checksum[0] && ((sum >> 8) & 0xff) == checksum[1])
    {
        return 1;
    }
    else
    {
        return 0;
    }
}


/**
* @brief		内部SCI通信数据发送接口
* @param		[in] buf 要发送的数据buf
* @param		[in] len  要发送的数据长度
* @param		无
* @return		无
* @retval		无
* @warning		无
*/
void sci_send(uint8_t* buf, uint32_t len)
{
    sdk_uart_write(SCI_PORT, buf, len);
}


/**
* @brief		SCI握手
* @param		[in] sci 从机sci结构体
* @param		[in] sci_master  主机结构体
* @param		无
* @return		无
* @retval		无
* @warning		无
*/
int32_t sci_handshaked(uint8_t* in_buf,
    uint32_t in_len,
    uint8_t* out_buf,
    uint32_t* out_len)
{
    if (in_len == 5
        && in_buf[0] == 0x00
        && in_buf[1] == 0x11
        && in_buf[2] == 0x22
        && in_buf[3] == 0x33
        && in_buf[4] == 0x44)
    {
        uint32_t len = 0;

        strcpy((char*)hw_ver, (char*)HARDWARE_VERSION);

        sdk_log_d("sci_handshaked");

        out_buf[len++] = APP_VERSION_HEADER;
        out_buf[len++] = APP_MAJOR_VERSION;
        out_buf[len++] = APP_MINOR_VERSION;
        out_buf[len++] = APP_STAGE_VERSION;
        out_buf[len++] = 'V';
        out_buf[len++] = SDK_MAJOR_VERSION;
        out_buf[len++] = SDK_MINOR_VERSION;
        out_buf[len++] = SDK_STAGE_VERSION;
        out_buf[len++] = hw_ver[3] - 0x30;
        out_buf[len++] = hw_ver[5] - 0x30;
        out_buf[len++] = 0x01;
        // out_buf[len++] = sw_major_ver;
        // out_buf[len++] = sw_sub_ver;
        *out_len = len;
        return 0;
    }
    else
    {
        return -1;
    }
}


/**
* @brief		处理MUC1下传的实时数据和回复MCU2的实时数据
* @param		[in] in_buf MCU1下发的温度和pack num数据
* @param		[in] in_len  数据长度
* @param		[in] out_buf 准备上传给mcu1的数据
* @param		[out] out_len 准备上传给MCU1的数据长度
* @return		无
* @retval		无
* @warning		无
*/
static int32_t sci_status_data_swap(uint8_t* in_buf, uint32_t in_len, uint8_t* out_buf, uint32_t* out_len)
{
    uint16_t i, j;
    int16_t current = 0;
    int32_t sum_curr = 0;
    
    // sdk_log_printf("D ");
    i = 2;
    if (in_buf[1] == 0x01)       // 高字节在前
    {
        bcu_status.word = (in_buf[i] << 8) | in_buf[i + 1];
        i += 2;
        mcu1_sys_sta = in_buf[i++];
        bcu_ready = in_buf[i++];
        if (in_buf[i + 1] == 1)
        {
        }
        i += 2;
        // 获取MCU1下传的温度和pack号

        for (j = 0;j < BAT_CLUSTER_MAX;j++)
        {
            g_pack_temp[j].max_temp_num[BAT_TEMP_1].temp = (in_buf[i] << 8) | in_buf[i + 1] - 40;
            i += 2;
            g_pack_temp[j].max_temp_num[BAT_TEMP_1].pack_num = (in_buf[i] << 8) | in_buf[i + 1];
            i += 2;
            g_pack_temp[j].max_temp_num[BAT_TEMP_2].temp = (in_buf[i] << 8) | in_buf[i + 1] - 40;
            i += 2;
            g_pack_temp[j].max_temp_num[BAT_TEMP_2].pack_num = (in_buf[i] << 8) | in_buf[i + 1];
            i += 2;
            g_pack_temp[j].max_temp_num[BAT_TEMP_3].temp = (in_buf[i] << 8) | in_buf[i + 1] - 40;
            i += 2;
            g_pack_temp[j].max_temp_num[BAT_TEMP_3].pack_num = (in_buf[i] << 8) | in_buf[i + 1];
            i += 2;
            g_pack_temp[j].min_mean_temp.min = (in_buf[i] << 8) | in_buf[i + 1] - 40;
            i += 2;
            g_pack_temp[j].min_mean_temp.mean = (in_buf[i] << 8) | in_buf[i + 1] - 40;
            i += 2;
            g_pack_temp[j].pack_voltage = ((in_buf[i] << 8) | in_buf[i + 1]) / 10;
            i += 2;

            // 没有读到电池电流时默认值为0，此时不计算电流
            current = (int16_t)((in_buf[i] << 8) | in_buf[i + 1]);
            if (current == 0)
            {
                g_pack_temp[j].pack_current = current;
            }
            else
            {
                g_pack_temp[j].pack_current = current - 16000;
            }
            i += 2;
        }
    }

    volatile uint16_t pre_cool_heat = 0;

    pre_cool_heat = (uint16_t)(in_buf[i] << 8) | in_buf[i + 1];

    if ( pre_cool_heat == 1 )
    {
        bat_temper_ctrl_reset();
    }

    bat_temper_t bat_temper[ BAT_CLUSTER_MAX ]; 

    memset( bat_temper, 0, sizeof( bat_temper_t ) );
    for (size_t i = 0; i < BAT_CLUSTER_MAX; i++)
    {
        bat_temper[i].valid = (bcu_status.word & BIT(i)) ? true: false;

        bat_temper[i].max_temper1 = g_pack_temp[i].max_temp_num[0].temp;
        bat_temper[i].max_temper2 = g_pack_temp[i].max_temp_num[1].temp;
        bat_temper[i].max_temper3 = g_pack_temp[i].max_temp_num[2].temp;

        bat_temper[i].temper1_pack_id = g_pack_temp[i].max_temp_num[0].pack_num;
        bat_temper[i].temper2_pack_id = g_pack_temp[i].max_temp_num[1].pack_num;
        bat_temper[i].temper3_pack_id = g_pack_temp[i].max_temp_num[2].pack_num;
    }

    temper_t bat_max_tmp = -20000;  // 设到相反值，确保被触发替换
    temper_t bat_min_tmp = 20000;   // 设到相反值，确保被触发替换
    temper_t bat_mean_tmp = 0;
    uint8_t sum_cnt = 0;
    int32_t avg_curr = 0;

    for (size_t i = 0; i < energy_cabinet_get_bat_box_num(); i++)
    {
        if (bcu_status.word & BIT(i))
        {
            sum_cnt++;
            bat_mean_tmp += g_pack_temp[i].min_mean_temp.mean;

            /* TODO 最高温最低温筛选逻辑 */
            if (bat_max_tmp < g_pack_temp[i].max_temp_num[0].temp)
            {
                bat_max_tmp = g_pack_temp[i].max_temp_num[0].temp;
            }
            if (bat_min_tmp > g_pack_temp[i].min_mean_temp.min)
            {
                bat_min_tmp = g_pack_temp[i].min_mean_temp.min;
            }
            sum_curr += (g_pack_temp[i].pack_current > 0) ? g_pack_temp[i].pack_current : -g_pack_temp[i].pack_current;
        }
    }
    if ( sum_cnt > 0 )
    {
        bat_mean_tmp = bat_mean_tmp / sum_cnt;
        avg_curr = sum_curr / sum_cnt;
    }
    
#if SIMIU_FF_BAT_TEMP_ENABLE == 0
    fire_fighting2_input_bat_info( bat_temper );
#endif

    if ( param_init2.lc_logic_param == 1 )
    {
        bat_temper_ctrl_input( (bcu_status.word) ? true : false, 
                                avg_curr,
                                g_system_info2.lc_outdoor_temper,
                                bat_mean_tmp * 10, bat_min_tmp * 10, bat_max_tmp * 10);
    }

    *out_len = _realtime_dat_sci_package(out_buf);

    // util_print_hex_dat( "sci -> mcu2 ", out_buf, *out_len, 20, true );

    return 0;
}

static void _system_info_update_dehumidifier(void)
{
    dehumi_dat_t dev_dehumi_dat;
    
    memset( &dev_dehumi_dat, 0, sizeof(dehumi_dat_t) );
    dehumi_ctrl_get_dat( 0, &dev_dehumi_dat );
    g_system_info2.bat1_temper                  = dev_dehumi_dat.env_temper;
    g_system_info2.bat1_humidity                = dev_dehumi_dat.env_humi;
    g_system_info2.dry_sta_info.bit.drying_sta1 = dev_dehumi_dat.status;
    g_system_info2.dry_warn_info.bit.offline1   = (dehumi_ctrl_get_online( 0 ) == OL_STA_OFFLINE)? 1: 0;

    memset( &dev_dehumi_dat, 0, sizeof(dehumi_dat_t) );
    dehumi_ctrl_get_dat( 1, &dev_dehumi_dat );
    g_system_info2.bat2_temper                  = dev_dehumi_dat.env_temper;
    g_system_info2.bat2_humidity                = dev_dehumi_dat.env_humi;
    g_system_info2.dry_sta_info.bit.drying_sta2 = dev_dehumi_dat.status;
    g_system_info2.dry_warn_info.bit.offline2   = (dehumi_ctrl_get_online( 1 ) == OL_STA_OFFLINE)? 1: 0;

    memset( &dev_dehumi_dat, 0, sizeof(dehumi_dat_t) );
    dehumi_ctrl_get_dat( 2, &dev_dehumi_dat );
    g_system_info2.bat3_temper                  = dev_dehumi_dat.env_temper;
    g_system_info2.bat3_humidity                = dev_dehumi_dat.env_humi;
    g_system_info2.dry_sta_info.bit.drying_sta3 = dev_dehumi_dat.status;
    g_system_info2.dry_warn_info.bit.offline3   = (dehumi_ctrl_get_online( 2 ) == OL_STA_OFFLINE)? 1: 0;

    memset( &dev_dehumi_dat, 0, sizeof(dehumi_dat_t) );
    dehumi_ctrl_get_dat( 3, &dev_dehumi_dat );
    g_system_info2.bat4_temper                  = dev_dehumi_dat.env_temper;
    g_system_info2.bat4_humidity                = dev_dehumi_dat.env_humi;
    g_system_info2.dry_sta_info.bit.drying_sta4 = dev_dehumi_dat.status;
    g_system_info2.dry_warn_info.bit.offline4   = (dehumi_ctrl_get_online( 3 ) == OL_STA_OFFLINE)? 1: 0;

    memset( &dev_dehumi_dat, 0, sizeof(dehumi_dat_t) );
    dehumi_ctrl_get_dat( 4, &dev_dehumi_dat );
    g_system_info2.bat5_temper                  = dev_dehumi_dat.env_temper;
    g_system_info2.bat5_humidity                = dev_dehumi_dat.env_humi;
    g_system_info2.dry_sta_info.bit.drying_sta5 = dev_dehumi_dat.status;
    g_system_info2.dry_warn_info.bit.offline5   = (dehumi_ctrl_get_online( 4 ) == OL_STA_OFFLINE)? 1: 0;

    memset( &dev_dehumi_dat, 0, sizeof(dehumi_dat_t) );
    dehumi_ctrl_get_dat( 5, &dev_dehumi_dat );
    g_system_info2.bat6_temper                  = dev_dehumi_dat.env_temper;
    g_system_info2.bat6_humidity                = dev_dehumi_dat.env_humi;
    g_system_info2.dry_sta_info.bit.drying_sta6 = dev_dehumi_dat.status;
    g_system_info2.dry_warn_info.bit.offline6   = (dehumi_ctrl_get_online( 5 ) == OL_STA_OFFLINE)? 1: 0;
}

/**
 * @brief  更新实时数据结构体
 * @return 无
 * @note   
 */
void system_info_update2(void)
{
    lc_dat_t lc_dat;
    bool fan_sta = false;
    bool dry_sta = false;
    
    memset( &lc_dat, 0, sizeof( lc_dat ));
    
    fire_fighting2_get_data(&g_system_info2.ff_sen_data_info);
    fire_fighting2_get_di_sta(&g_system_info2.ff_di_sta_info);
    fire_fighting2_get_do_sta(&g_system_info2.ff_do_sta_info);
    fire_fighting2_get_warn2(&g_system_info2.ff_warn2_info);
    fire_fighting2_get_warn1(&g_system_info2.ff_warn1_info);
    fire_fighting2_get_fan_info(&fan_sta, &g_system_info2.fan_reas_info, &g_system_info2.fire_fan_start_1co);
    fire_fighting2_get_ff_gas_pressure( &g_system_info2.ff_cylinder_press );    

    _system_info_update_dehumidifier();

    energy_cabinet_get_di_sta(&g_system_info2.dev_di_sta_info);
    energy_cabinet_get_do_sta(&g_system_info2.dev_do_sta_info);
    energy_cabinet_get_warn(&g_system_info2.dev_warn_info);
    energy_cabinet_get_fault(&g_system_info2.dev_fault_info);

    lc_ctrl_get_lc_dat(&lc_dat);

    g_system_info2.lc_type            = lc_dat.lc_type;
    g_system_info2.lc_outdoor_temper  = lc_dat.outdoor_temper;
    g_system_info2.lc_inlet_temp      = lc_dat.inlet_temper;
    g_system_info2.lc_outlet_temp     = lc_dat.outlet_temper;
    g_system_info2.lc_inlet_pressure  = lc_dat.inlet_pressure;
    g_system_info2.lc_outlet_pressure = lc_dat.outlet_pressure;
    g_system_info2.lc_warn_info       = lc_dat.warn;
    g_system_info2.lc_fault_info      = lc_dat.fault;
    g_system_info2.lc_sta_info        = lc_dat.sta;
    g_system_info2.lc_flow            = lc_dat.lc_flow;
    g_system_info2.lc_dst_tmp         = lc_dat.lc_dst_tmp;
    g_system_info2.lc_control_mode    = lc_dat.work_mode;
    g_system_info2.lc_sofar_mode      = bat_temper_get_lc_sofar_mode();

    fire_fight_dev_get_sw_ver( &g_system_info2.ff_sw_major_ver, &g_system_info2.ff_sw_sub_ver );

    g_system_info2.pack_loss_rate.lc_com = lc_ctrl_get_com_loss_rate();
    g_system_info2.pack_loss_rate.ff_com = fire_fight_dev_get_com_loss_rate();

    g_system_info2.pack_loss_rate.lc_com = lc_ctrl_get_com_loss_rate();
    g_system_info2.pack_loss_rate.ff_com = fire_fight_dev_get_com_loss_rate();
    
    for ( size_t i = 0; i < ARRAY_SIZE( g_system_info2.pack_loss_rate.dh_com ); i++)
    {
        g_system_info2.pack_loss_rate.dh_com[i] = dehumi_ctrl_get_com_loss_rate( i );
    }
    
    for ( size_t i = 0; i < ARRAY_SIZE( g_system_info2.pack_loss_rate.io_ext_com ); i++)
    {
        g_system_info2.pack_loss_rate.io_ext_com[i] = extern_io_get_com_loss_rate( i );
    }

    #if LC_ENABLE 
        g_system_info2.chg_dischg_ctrl    = (bat_temper_get_allow_charge_discharge() ) ? 0: 1;
    #else
        g_system_info2.chg_dischg_ctrl = 0;
    #endif

    if ( USR_SETTING_SYNC_FINISH() )
    {
        g_system_info2.param_init_flag = 1;
    }
    //
}

static int32_t _realtime_dat_sci_package(uint8_t* p_package_buff)
{
    int32_t  i, j, pack_len;
    uint32_t* p_u32;
    uint16_t* p;

    // g_system_info2.fault_info1.bit.entrance_fault = 0;		// 屏蔽门禁故障，调试和容测的时候需要频繁打开集装箱的门，会触发门禁故障导致下电，客户现场调试后交付前要把这行代码注释调

    p_package_buff[1] = 0x03;
    p_package_buff[0] = sizeof(Realtime_SysInfo_t2);
    pack_len = 2;

    if (param_init2.lc_param == 1 && param_init2.lc_logic_param == 1
        && param_init2.dry_param == 1 && param_init2.ff_param == 1
        && param_init2.bat_num_param == 1)
    {
        g_system_info2.param_init_flag = 1;
    }

    p = (uint16_t*)&g_system_info2;
    j = 2;
    for (i = 0;i < (sizeof(Realtime_SysInfo_t2) / 2);i++)
    {
        p_package_buff[j++] = (uint8_t)((*p >> 8) & 0xff);
        p_package_buff[j++] = (uint8_t)((*p >> 0) & 0xff);
        p++;
    }

    /* U8 数据单独处理 */
    Realtime_SysInfo_t2* p_tmp_real_data = (Realtime_SysInfo_t2*)&p_package_buff[2];
    p_tmp_real_data->param_init_flag = g_system_info2.param_init_flag;
    p_tmp_real_data->lc_type = g_system_info2.lc_type;

    pack_len += sizeof(Realtime_SysInfo_t2);

    // /* 发生错误则打印 */
    // if (g_system_info2.dev_fault_info.value)
    // {
    //     sdk_log_d("dev_fault_info:%04X", g_system_info2.dev_fault_info.value);
    // }
    // if (g_system_info2.lc_fault_info.value)
    // {
    //     sdk_log_d("lc_fault_info:%04X-%04X-%04X-%04X",
    //         g_system_info2.lc_fault_info.array[0], g_system_info2.lc_fault_info.array[1],
    //         g_system_info2.lc_fault_info.array[2], g_system_info2.lc_fault_info.array[3]);
    // }
    // if (g_system_info2.ff_warn2_info.value)
    // {
    //     sdk_log_d("ff_warn2_info:%04X-%04X-%04X-%04X",
    //         g_system_info2.ff_warn2_info.array[0], g_system_info2.ff_warn2_info.array[1],
    //         g_system_info2.ff_warn2_info.array[2], g_system_info2.ff_warn2_info.array[3]);
    // }

    // if (g_system_info2.dev_warn_info.value)
    // {
    //     sdk_log_d("dev_warn_info:%04X", g_system_info2.dev_warn_info.value);
    // }
    // if (g_system_info2.lc_warn_info.value)
    // {
    //     sdk_log_d("lc_warn_info:%04X-%04X-%04X-%04X",
    //         g_system_info2.lc_warn_info.array[0], g_system_info2.lc_warn_info.array[1],
    //         g_system_info2.lc_warn_info.array[2], g_system_info2.lc_warn_info.array[3]);
    // }
    // if (g_system_info2.ff_warn1_info.value)
    // {
    //     sdk_log_d("ff_warn1_info:%04X-%04X-%04X-%04X",
    //         g_system_info2.ff_warn1_info.array[0], g_system_info2.ff_warn1_info.array[1],
    //         g_system_info2.ff_warn1_info.array[2], g_system_info2.ff_warn1_info.array[3]);
    // }
    // if (g_system_info2.dry_warn_info.value)
    // {
    //     sdk_log_d("dry_warn_info:%04X", g_system_info2.dry_warn_info.value);
    // }

    return pack_len;
}


/**
* @brief		液冷机开关机控制   功能码：0x3000
* @param		[in] buf 要设置的数据
* @param		[in] len  要设置的参数个数
* @param		无
* @return		无
* @retval		无
* @warning		无
*/
static int32_t sci_lc_power_control(uint8_t* in_buf, uint32_t in_len, uint8_t* out_buf, uint32_t* out_len)
{
    uint16_t status = 0;
    int32_t ret = 0;

    status = (in_buf[0] << 8) + in_buf[1];
    // 设置失败非法数据
    *out_len = 1;

    sdk_log_d("%s, power on:%d", __FUNCTION__, status);

    if ((status > 1) || (in_len != 2))
    {
        out_buf[0] = 0x00;
        return SCI_NO_REPLY;
    }

#if LC_ENABLE
    if (0 > lc_ctrl_set_power_on((status == 1)))
    {
        out_buf[0] = 0x00;
    }
    else
#endif
    {
        out_buf[0] = 0x01;
    }

    *out_len = 1;

    return SCI_REPLY;
}


/**
* @brief		cmu运维模式控制
* @param		[in] buf 要设置的数据
* @param		[in] len  要设置的参数个数
* @param		无
* @return		无
* @retval		无
* @warning		无
*/
static int32_t sci_cmu_mode_control(uint8_t* in_buf, uint32_t in_len, uint8_t* out_buf, uint32_t* out_len)
{
    uint16_t mode = 0;
    int32_t ret = 0;

    mode = (in_buf[0] << 8) + in_buf[1];
    // 设置失败非法数据
    *out_len = 1;

    sdk_log_d("%s mode:%d", __FUNCTION__, mode);

    if ((mode > 1) || (in_len != 2))
    {
        out_buf[0] = 0x00;
        return SCI_NO_REPLY;
    }

    energy_cabinet_set_maintenance_mode(mode);
    out_buf[0] = 0x01;
    *out_len = 1;

    return SCI_REPLY;
}


/**
* @brief		液冷机阈值参数设置
* @param		[in] buf 要设置的数据
* @param		[in] len  要设置的参数个数
* @param		无
* @return		无
* @retval		无
* @warning		无
*/
static int32_t sci_lc_threshold_set(uint8_t* in_buf, uint32_t in_len, uint8_t* out_buf, uint32_t* out_len)
{
    uint16_t* p;
    uint16_t i, j;

    lc_threshold_set_t2 lc_threshold2;

    p = (uint16_t*)&lc_threshold2;

    sdk_log_d("%s", __FUNCTION__);

    util_print_hex_dat("lc setting", in_buf, in_len, 10, true);

    if (in_len != sizeof(lc_threshold_set_t2))
    {
        out_buf[0] = 0x00;
        *out_len = 1;
        return SCI_NO_REPLY;
    }
    else
    {
        j = 0;
        for (i = 0; i < in_len / 2; i++)
        {
            *p++ = (in_buf[j] << 8) + in_buf[j + 1];
            j += 2;
        }
        out_buf[0] = 0x01;
    }

    lc_ctrl_setting_t lc_ctrl_setting = { .lc_auto_mode = 0 };

    lc_ctrl_setting.lc_type = (lc_type_e)lc_threshold2.lc_type;
    lc_ctrl_setting.lc_auto_mode = lc_threshold2.lc_auto_mode;
    lc_ctrl_setting.lc_mode = (lc_work_mode_e)lc_threshold2.lc_mode;
    lc_ctrl_setting.lc_ctrl_mode = (lc_tmp_ctrl_mode_e)lc_threshold2.lc_ctrl_mode;
    lc_ctrl_setting.lc_pump_rate = lc_threshold2.lc_pump_rate;
    lc_ctrl_setting.lc_cooling_point = lc_threshold2.lc_cooling_point;
    lc_ctrl_setting.lc_cooling_drop = lc_threshold2.lc_cooling_drop;
    lc_ctrl_setting.lc_heating_point = lc_threshold2.lc_heating_point;
    lc_ctrl_setting.lc_heating_drop = lc_threshold2.lc_heating_drop;
    lc_ctrl_setting.lc_cool_outlet_low_tmp = lc_threshold2.lc_cool_outlet_low_tmp;
    lc_ctrl_setting.lc_heat_outlet_hig_tmp = lc_threshold2.lc_heat_outlet_hig_tmp;
    lc_ctrl_setting.lc_outlet_pressure_high = lc_threshold2.lc_outlet_pressure_high;
    lc_ctrl_setting.lc_inlet_pressure_low = lc_threshold2.lc_inlet_pressure_low;

    *out_len = 1;

#if LC_ENABLE
    bat_temper_ctrl_set_enable((lc_ctrl_setting.lc_auto_mode == 0) ? false : true);
    if (0 > lc_ctrl_set_param(&lc_ctrl_setting))
    {
        /* 失败 */
        out_buf[0] = 0x00;
    }
    else
#endif
    {
        /* 成功 */
        bat_temper_ctrl_lc_param_adjust_once();
        out_buf[0] = 0x01;
    }

    param_init2.lc_param = 1;
    return SCI_REPLY;
}

/**
* @brief		液冷机控制参数设置
* @param		[in] buf 要设置的数据
* @param		[in] len  要设置的参数个数
* @param		无
* @return		无
* @retval		无
* @warning		无
*/
static int32_t sci_lc_control_param_set(uint8_t* in_buf, uint32_t in_len, uint8_t* out_buf, uint32_t* out_len)
{
    static bat_tmp_setting_t bat_tmp_setting = {0};
    uint16_t i, j;
    uint16_t* p;

    util_print_hex_dat( (char*)__FUNCTION__, in_buf, in_len, 10, true ); 

    p = (uint16_t*)&g_lc_control_param2;
    if (in_len != sizeof(lc_control_param_t2))
    {
        return SCI_NO_REPLY;
    }
    else
    {
        j = 0;
        for (i = 0;i < in_len / 2;i++)
        {
            *p++ = (in_buf[j] << 8) + in_buf[j + 1];
            j += 2;
        }
        out_buf[0] = 0x01;
    }
    *out_len = 1;

    memcpy(&bat_tmp_setting, &g_lc_control_param2, sizeof(bat_tmp_setting_t));
    if ( bat_temper_set_bat_tmp_setting(&bat_tmp_setting))
    {
        out_buf[0] = 0x01;
    }else{
        out_buf[0] = 0x00;
    }
    param_init2.lc_logic_param = 1;

    return SCI_REPLY;
}


/**
* @brief		消防阈值设置
* @param		[in] buf 要设置的数据
* @param		[in] len  要设置的参数个数
* @param		无
* @return		无
* @retval		无
* @warning		无
*/
static int32_t sci_ff_threshold_set(uint8_t* in_buf, uint32_t in_len, uint8_t* out_buf, uint32_t* out_len)
{
    int32_t ret = 0;
    uint16_t* p;
    uint16_t i, j;
    ff_threshold_set_t  ff_param_temp;

    util_print_hex_dat("ff setting", in_buf, in_len, 10, true);

    p = (uint16_t*)&g_ff_threshold2;

    if (in_len != sizeof(ff_threshold_set_t))
    {
        /* 长度错误 */
        out_buf[0] = 0x00;
        return SCI_NO_REPLY;
    }

    j = 0;
    for (i = 0;i < in_len / 2;i++)
    {
        *p++ = (in_buf[j] << 8) + in_buf[j + 1];
        j += 2;
    }
    out_buf[0] = 0x01;

    ff_param_temp = g_ff_threshold2;

#if FF_ENABLE
    if (0 > fire_fighting2_set_threshold(&ff_param_temp, g_bat_param2.bat_num))
    {
        /* 失败 */
        out_buf[0] = 0x00;
    }
    else
#endif
    {
        /* 成功 */
        out_buf[0] = 0x01;
        if ( fire_fight_share_get_role() == FF_ROLE_SLAVER )
        {
            /* 消防瓶共享模式下，从机关闭消防气瓶低压告警 */
            if ( SF_OK != fire_fighting2_warn_set_enabe( FF_WARN_LOW_PRESSURE, SF_FALSE ))
            {
                /* 失败 */
                out_buf[0] = 0x00;
            }
        }
    }
    if ( ff_param_temp.local_ff_enable == 0 )
    {
        fire_fight_local_set_enable( false );
    } else if ( ff_param_temp.local_ff_enable == 1 )
    {
        fire_fight_local_set_enable( true );
    }

    *out_len = 1;
    param_init2.ff_param = 1;

    return SCI_REPLY;
}


/**
* @brief		下发除湿逻辑阈值
* @param		[in] buf 要设置的数据
* @param		[in] len  要设置的参数个数
* @param		无
* @return		无
* @retval		无
* @warning		无
*/
static int32_t sci_dry_setting(uint8_t* in_buf, uint32_t in_len, uint8_t* out_buf, uint32_t* out_len)
{
    if (in_len != sizeof(dry_param_t2))
    {
        out_buf[0] = 0x00;
        *out_len = 1;
        return SCI_NO_REPLY;
    }
    else
    {
        uint16_t i, j = 0;
        uint16_t* p;

        p = (uint16_t*)&g_dry_param2;

        for (i = 0; i < in_len / 2; i++)
        {
            *p++ = (in_buf[j] << 8) + in_buf[j + 1];
            j += 2;
        }
        out_buf[0] = 0x01;
    }

    /* 除湿器阈值设定 */
    sdk_log_d("dst_humidity:%d, ret_humidity:%d", g_dry_param2.dst_humidity, g_dry_param2.ret_humidity);

    if ( SF_OK == energy_cabinet_set_dehumi_setting( g_dry_param2.dst_humidity, g_dry_param2.ret_humidity ) )
    {
        out_buf[0] = 0x01;
    }else{
        out_buf[0] = 0x00;
    }

    *out_len = 1;
    param_init2.dry_param = 1;

    return SCI_REPLY;
}


/**
* @brief		下发电池舱个数设置
* @param		[in] buf 要设置的数据
* @param		[in] len  要设置的参数个数
* @param		无
* @return		无
* @retval		无
* @warning		无
*/
static int32_t sci_bat_param_setting(uint8_t* in_buf, uint32_t in_len, uint8_t* out_buf, uint32_t* out_len)
{
    int32_t ret1 = 0;
    int32_t ret2 = 0;

    if (in_len != sizeof(bat_param_t2))
    {
        out_buf[0] = 0x00;
        *out_len = 1;
        return SCI_NO_REPLY;
    }
    else
    {
        uint16_t i, j = 0;
        uint16_t* p;

        p = (uint16_t*)&g_bat_param2;

        for (i = 0; i < in_len / 2; i++)
        {
            *p++ = (in_buf[j] << 8) + in_buf[j + 1];
            j += 2;
        }
        out_buf[0] = 0x01;
    }

    /* 电池参数设定 */
    sdk_log_d("sci bat num:%d", g_bat_param2.bat_num);
    ret1 = energy_cabinet_set_bat_cluster_num(g_bat_param2.bat_num );
    ret2 = fire_fighting2_set_battery_cluster_num( g_bat_param2.bat_num );
    if ( ( ret1 != SF_OK ) || ( ret2 != SF_OK ) )
    {
        out_buf[0] = 0x00;
        sdk_log_e( "%s set error!!!", __FUNCTION__ );
    } else {
        out_buf[0] = 0x01;
    }

    *out_len = 1;
    param_init2.bat_num_param = 1;

    return SCI_REPLY;
}

static int32_t sci_set_fan(uint8_t* in_buf, uint32_t in_len, uint8_t* out_buf, uint32_t* out_len)
{
    *out_len = 1;
    out_buf[0] = 0x00;

    if (in_len != sizeof(set_fan_t))
    {
        return SCI_NO_REPLY;
    }

    // if (fire_fighting2_get_warn2_alarm_sta())
    // {
    //     sdk_log_d("ff warn2 alarm enable, can not set fan");
    //     return -1;
    // }

    set_fan_t set_fan = { 0 };

    uint16_t* p_dst = (uint16_t*)&set_fan;

    for (size_t i = 0; i < (sizeof(set_fan_t) / 2); i++)
    {
        *p_dst++ = (in_buf[i * 2] << 8) | in_buf[i * 2 + 1];
    }

    sdk_log_d("%s fan sta:%d", __FUNCTION__, set_fan.fan_sta);
    energy_cabinet_set_fan_sta( DEV_IDX_ALL, (set_fan.fan_sta == 1) ? true : false);

    out_buf[0] = 0x01;

    return SCI_REPLY;
}

/**
 * @brief  SCI设置储能柜属性
 * @param  [in]  in_buf 输入命令数据
 * @param  [in]  in_len 输入命令长度
 * @param  [out] out_buf 输出命令数据
 * @param  [out] out_len 输出命令长度
 * @return 0：成功  -1：失败
 */
static int32_t sci_set_set_eng_cab_attr(uint8_t* in_buf, uint32_t in_len, uint8_t* out_buf, uint32_t* out_len)
{
    set_eng_cab_attr_t set_eng_cab_attr = { 0 };
    uint16_t* p_dst = NULL;
    int32_t ret;

    out_buf[0] = SCI_RET_FAIL;
    *out_len   = 1;

    if (in_len != sizeof( set_eng_cab_attr_t ))
    {
        sdk_log_d("%s set eng cab attr cmd len error!!!", __FUNCTION__);
        return SCI_NO_REPLY;
    }

    p_dst = (uint16_t*)&set_eng_cab_attr;
    for (size_t i = 0; i < (sizeof(set_eng_cab_attr_t) / 2); i++)
    {
        *p_dst++ = (in_buf[i * 2] << 8) | in_buf[i * 2 + 1];
    }

    sdk_log_d("%s addr:%d, num:%d", __FUNCTION__, set_eng_cab_attr.eng_cab_addr, set_eng_cab_attr.eng_cab_num);

    out_buf[0] = SCI_RET_SUCCESS;
    ret = fire_fight_share_set_param( (set_eng_cab_attr.eng_cab_addr == 1 )? FF_ROLE_MASTER : FF_ROLE_SLAVER, 
                                      set_eng_cab_attr.eng_cab_addr, set_eng_cab_attr.eng_cab_num );
    if( ret < 0 )
    {
        out_buf[0] = SCI_RET_FAIL;
    }else{
        ret = fire_fighting2_warn_set_enabe( FF_WARN_LOW_PRESSURE, ( fire_fight_share_get_role() == FF_ROLE_SLAVER )? SF_DISABLE :SF_ENABLE );
        if ( ret != SF_OK )
        {
            out_buf[0] = SCI_RET_FAIL;
        }
    }
    param_init2.eng_cab_attr = 1;

    return SCI_REPLY;
}

/**
 * @brief  SCI设置储能柜属性
 * @param  [in]  in_buf 输入命令数据
 * @param  [in]  in_len 输入命令长度
 * @param  [out] out_buf 输出命令数据
 * @param  [out] out_len 输出命令长度
 * @return 0：成功  -1：失败
 */
static int32_t sci_set_real_time(uint8_t* in_buf, uint32_t in_len, uint8_t* out_buf, uint32_t* out_len)
{
    typedef struct {
        uint16_t  sec;
        uint16_t  min;
        uint16_t  hour;
        uint16_t  week;
        uint16_t  day;
        uint16_t  month;
        uint16_t  year;
    } real_time_msg_t;

    real_time_msg_t real_time_msg = {0};
    sdk_rtc_t       sdk_rtc = {0};
    uint16_t*       p_dst = NULL;
    int32_t         ret;

    memset( &real_time_msg, 0, sizeof( real_time_msg_t ) );
    memset( &sdk_rtc, 0, sizeof( sdk_rtc_t ) );

    if (in_len != sizeof( real_time_msg_t ))
    {
        sdk_log_d("%s set eng cab attr cmd len error!!!", __FUNCTION__);
        return SCI_NO_REPLY;
    }

    p_dst = (uint16_t*)&real_time_msg;
    for (size_t i = 0; i < (sizeof(real_time_msg_t) / 2); i++)
    {
        *p_dst++ = (in_buf[i * 2] << 8) | in_buf[i * 2 + 1];
    }

    sdk_log_d("set real time:%04d-%02d-%02d, week:%d, %02d:%02d:%02d", 
                real_time_msg.year + 2000, 
                real_time_msg.month,
                real_time_msg.day, 
                real_time_msg.week, 
                real_time_msg.hour, 
                real_time_msg.min,
                real_time_msg.sec);

    sdk_rtc.tm_year     = real_time_msg.year;
    sdk_rtc.tm_mon      = real_time_msg.month;
    sdk_rtc.tm_day      = real_time_msg.day;
    sdk_rtc.tm_weekday  = real_time_msg.week;
    sdk_rtc.tm_hour     = real_time_msg.hour;
    sdk_rtc.tm_min      = real_time_msg.min;
    sdk_rtc.tm_sec      = real_time_msg.sec;

    #define RTC_BIN_FORMAT ((uint32_t)0x000000000)

    *out_len   = 1;
    ret = sdk_rtc_set( RTC_BIN_FORMAT, &sdk_rtc );
    if( ret < 0 )
    {
        out_buf[0] = SCI_RET_FAIL;
        sdk_log_e( "sdk rtc set error!!!" );
    }else{
        out_buf[0] = SCI_RET_SUCCESS;
        param_init2.rtc_sync = 1;
    }

    return SCI_REPLY;
}

/**
 * @brief                           检查升级文件完整性
 * @param p_file_name               待检查的升级文件名
 * @param [out] p_firmware_size     固件大小
 * @param [out] p_firmware_crc      固件crc
 * @return                          执行结果
 * @retval  0                       执行成功
 * @retval -1                       执行失败
 */
int32_t update_updatefile_check(char* p_file_name, uint32_t* p_firmware_size, uint32_t* p_firmware_crc, uint8_t* p_firmware_type)
{
    int32_t res;
    uint8_t file_type = 0;
    uint32_t file_crc = 0;
    uint32_t file_size = 0;
    uint32_t crc = 0;
    uint32_t i = 0;

    sdk_fs_close(p_fs);
    p_fs = sdk_fs_open((const int8_t*)p_file_name, FA_READ);
    sdk_log_e("open file[%s]", p_file_name);

    if (p_fs != NULL)
    {
        file_size = sdk_fs_get_size(p_fs);  // 获取文件大小
        res = sdk_fs_lseek(p_fs, file_size - 1024);   // 偏移到最后1k签名信息
        res = sdk_fs_read(p_fs, g_update_buf, 1024);

        if (res > 0)   // 读取成功
        {
            uint8_t* p = g_update_buf + 1;
            // 获取文件长度
            file_size = p[0] | p[1] << 8 | p[2] << 16 | p[3] << 24;
            p += 4;
            // 获取文件自带的crc32
            file_crc = p[0] | p[1] << 8 | p[2] << 16 | p[3] << 24;
            //
            // 获取文件类型
            p = g_update_buf + 128;
            file_type = *p;
            sdk_fs_lseek(p_fs, 0);
            crc = 0xFFFFFFFF;
            for (i = 0; i < file_size / UPDATE_BUF_SIZE; i++)
            {
                sdk_fs_read(p_fs, g_update_buf, UPDATE_BUF_SIZE);
                crc = sdk_check_crc32(crc, g_update_buf, UPDATE_BUF_SIZE);
            }

            i = file_size % UPDATE_BUF_SIZE;
            sdk_fs_read(p_fs, g_update_buf, i);
            crc = sdk_check_crc32(crc, g_update_buf, i);

            if (crc == file_crc)
            {
                *p_firmware_crc = file_crc;
                *p_firmware_size = file_size;
                *p_firmware_type = file_type;
                sdk_fs_close(p_fs);
                return 0;
            }
            else    // crc 校验错误
            {
                sdk_fs_close(p_fs);
                return -1;
            }
        }
        else    // 读取1k签名信息失败
        {
            sdk_fs_close(p_fs);
            return -1;
        }
    }
    else    // 文件打开失败
    {
        return -1;
    }
}

/**
 * @brief               芯片角色获取功能码解析
 * @param p_in_buf      收到的数据指针
 * @param in_len        收到的数据长度
 * @param p_out_buf     发送的数据指针
 * @param p_out_len     发送的数据长度
 * @return              解析结果
 * @retval      0       解析成功
 * @retval     -1       解析失败
 */
static int32_t update_sci_chip_role(uint8_t* p_in_buf, uint32_t in_len, uint8_t* p_out_buf, uint32_t* p_out_len)
{
    int32_t    ret     = -1;
    fs_stat_fs fs_stat = {0};

    sdk_log_i("%s chip role:%s", __FUNCTION__, p_in_buf);
    // util_print_hex_dat(NULL, p_in_buf, in_len, 32, true);

    // 检查剩余空间容量
    sdk_fs_stat_fs((const int8_t *)("1:"), (fs_stat_fs *)&fs_stat);
    sdk_log_i("block size:%d, total blocks:%d, free blocks:%d", fs_stat.f_bsize, fs_stat.f_blocks, fs_stat.f_bfree);

    // 内存出错，可用容量小于4KB, 自动格式化并重新挂载
    if (fs_stat.f_bfree <= 1)
    {
        sdk_log_i("No space is available! FATFS formatting...");

        sdk_start_upgrade((uint8_t*)APP_FILE_NAME, 0);
        sdk_start_upgrade((uint8_t*)CORE_FILE_NAME, 0);
        ret = sdk_fs_format();
        if (ret == 0)
        {
            sdk_fs_stat_fs((const int8_t *)("1:"), (fs_stat_fs *)&fs_stat);
            sdk_log_i("FATFS formatted! block size:%d, total blocks:%d, free blocks:%d", fs_stat.f_bsize, fs_stat.f_blocks, fs_stat.f_bfree);
        }
    }

    s_file_check = false;
    s_file_check_success = false;

    if (in_len == 0)
    {
        sdk_fs_close(p_fs);
        // 打开文件
        p_fs = sdk_fs_open((const int8_t*)TMP_FILE_NAME, FA_WRITE | FA_READ | FA_OPEN_ALWAYS);

        if (p_fs == NULL)
        {
            sdk_log_i("9010 file open fail\r\n");
            return SCI_NO_REPLY;
        }

        *p_out_buf = CHIP_ROLE;
        *p_out_len = 1;
        return SCI_REPLY;
    }
    else
    {
        return SCI_NO_REPLY;
    }
}

/**
 * @brief               升级文件数据接收
 * @param p_in_buf      收到的数据指针
 * @param in_len        收到的数据长度
 * @param p_out_buf     发送的数据指针
 * @param p_out_len     发送的数据长度
 * @return              解析结果
 * @retval      0       解析成功
 * @retval     -1       解析失败
 */
static int32_t update_sci_file_data(uint8_t* p_in_buf, uint32_t in_len, uint8_t* p_out_buf, uint32_t* p_out_len)
{
    static uint16_t pack_num = 0;
    int32_t res;
    uint32_t len = 0;

    // sdk_log_i("%s file data", __FUNCTION__ );
    // util_print_hex_dat(NULL, p_in_buf, in_len, 32, true);

    s_file_check = false;
    s_file_check_success = false;

    if (in_len > 2)
    {
        uint8_t* p = p_in_buf;
        uint16_t tmp = p[0] << 8 | p[1];

        if (tmp == 1)   // 第一包
        {
            pack_num = 1;
        }
        if (tmp == pack_num)    // 包序号相等
        {
            len = in_len - 2;
            res = sdk_fs_write(p_fs, p + 2, len);
            if (res != len || res <= FR_OK)  // 写失败
            {
                sdk_log_i("\r\n0x9020 file write err:%d\r\n", res);
                return SCI_NO_REPLY;
            }

            pack_num++;
        }
        else    // 包序号不等
        {
            sdk_log_i("\r\n0x9020 pack num err\r\n");
            return SCI_NO_REPLY;
        }

        p_out_buf[0] = p_in_buf[0];
        p_out_buf[1] = p_in_buf[1];
        *p_out_len = 2;
        return SCI_REPLY;
    }
    else    // 长度错误
    {
        return SCI_NO_REPLY;
    }
}



/**
 * @brief               升级文件传输完成
 * @param p_in_buf      收到的数据指针
 * @param in_len        收到的数据长度
 * @param p_out_buf     发送的数据指针
 * @param p_out_len     发送的数据长度
 * @return              解析结果
 * @retval      0       解析成功
 * @retval     -1       解析失败
 */
static int32_t update_sci_file_finish(uint8_t* p_in_buf, uint32_t in_len, uint8_t* p_out_buf, uint32_t* p_out_len)
{
    int32_t ret = 0;
    uint32_t file_size = 0;
    uint32_t file_crc = 0;
    uint8_t file_type = 0;

    sdk_log_i("%s", __FUNCTION__);
    // util_print_hex_dat(NULL, p_in_buf, in_len, 32, true);

    if( s_file_check == true )
    {
        *p_out_len = 1;
        if( s_file_check_success )
        {
            p_out_buf[0] = 1;
        }else{
            p_out_buf[0] = 0;
        }

        return SCI_REPLY;
    }

    if (in_len == 0)
    {
        sdk_fs_close(p_fs);
        ret = update_updatefile_check(TMP_FILE_NAME, &file_size, &file_crc, &file_type);
        sdk_log_i("%s file_type:%d, ret:%d", __FUNCTION__, file_type, ret);
        s_file_check = true;
        // 校验成功
        if (ret == 0)
        {
            if (file_type == 0)    // app
            {
                ret = sdk_fs_remove((const int8_t *)APP_FILE_NAME);
                if (ret != SF_OK)
                {
                    // 删除失败 警告 不退出
                    sdk_log_w("sdk_fs_remove app_file error, ret: %d", ret);
                }
                ret = sdk_fs_rename((const int8_t *)TMP_FILE_NAME, (const int8_t *)APP_FILE_NAME);
                if (ret != SF_OK)
                {
                    sdk_log_e("sdk_fs_rename app_file error, ret: %d", ret);
                    p_out_buf[0] = 0;
                    goto CHECK_EXIT;
                }
                ret = sdk_start_upgrade((uint8_t *)APP_FILE_NAME, 1);
                if (ret != SF_OK)
                {
                    sdk_log_e("sdk_start_upgrade app_file error, ret: %d", ret);
                    p_out_buf[0] = 0;
                    goto CHECK_EXIT;
                }
            }
            else if (file_type == 1)    // core
            {
                ret = sdk_fs_remove((const int8_t *)CORE_FILE_NAME);
                if (ret != SF_OK)
                {
                    // 删除失败 警告 不退出
                    sdk_log_w("core-sdk_fs_remove core_file error, ret: %d", ret);
                }
                ret = sdk_fs_rename((const int8_t *)TMP_FILE_NAME, (const int8_t *)CORE_FILE_NAME);
                if (ret != SF_OK)
                {
                    sdk_log_e("sdk_fs_rename core_file error, ret: %d", ret);
                    p_out_buf[0] = 0;
                    goto CHECK_EXIT;
                }
                ret = sdk_start_upgrade((uint8_t *)CORE_FILE_NAME, 1);
                if (ret != SF_OK)
                {
                    sdk_log_e("sdk_start_upgrade core_file error, ret: %d", ret);
                    p_out_buf[0] = 0;
                    goto CHECK_EXIT;
                }
            }
            else
            {
                sdk_log_e("file_type error!");
                p_out_buf[0] = 0;
                goto CHECK_EXIT;
            }
            // 设置成功
            p_out_buf[0] = 1;
        }
        else
        {
            p_out_buf[0] = 0;
        }
    }
    else
    {
        sdk_log_w("command wrong");
        p_out_buf[0] = 0;
    }

CHECK_EXIT:
    *p_out_len = 1;
    if (0x00 == p_out_buf[0])
    {
        s_file_check_success = false;
        sdk_log_w("execute fail");
    }
    else{
        s_file_check_success = true;
    }

    return SCI_REPLY;
}

/**
 * @brief               APP层升级流程结束
 * @param p_in_buf      收到的数据指针
 * @param in_len        收到的数据长度
 * @param p_out_buf     发送的数据指针
 * @param p_out_len     发送的数据长度
 * @return              解析结果
 * @retval      0       解析成功
 * @retval     -1       解析失败
 */
static int32_t update_sci_start_upgrade(uint8_t* p_in, uint32_t in_len, uint8_t* p_out, uint32_t* p_out_len)
{
    sdk_log_i("%s", __FUNCTION__);
    util_print_hex_dat(NULL, p_in, in_len, 32, true);

    s_file_check = false;
    s_file_check_success = false;

    // 需要回复设置成功/失败
    if (in_len == 0)
    {
        g_reset_flg = 1;    // 文件接收和解析成功后将重启标志位置1，在系统管理任务重重启
        p_out[0]    = 0x01;
    }
    else
    {
        p_out[0] = 0x00;
        sdk_log_e("execute fail");
    }
    *p_out_len = 1;
    return SCI_REPLY;
}

/**
* @brief		进入工厂测试模式 初始化rs485-2端口 
* @param		无
* @param		无
* @param		无
* @return		无
* @retval		无
* @warning		无
*/
static int32_t sci_factory_test_rs485_2_init()
{
	int32_t  ret = 0;
	/******** init rs485-2*******/
    uint32_t modbus_rs485_2 = EM_RS485_MODBUS_INDEX;
        
    /* 打开modbus */
    ret = app_modbus_rtu_init( modbus_rs485_2, EM_MODBUS_SLAVE_ADDR, 9600);
    if ( ret > SF_OK )
    {
        sdk_log_e( "%s, app_modbus_rtu_init error ret:%d ", __FUNCTION__, ret);
        return SF_ERR_OPEN;
    }
    ret = app_modbus_connect( modbus_rs485_2 );
    if ( ret > SF_OK )
    {
        sdk_log_e( "%s, app_modbus_rtu_init error ret:%d ", __FUNCTION__, ret);
        return SF_ERR_OPEN;
    }
    ret = app_modbus_response_timeout_set( modbus_rs485_2, 200);
    if ( ret > SF_OK )
    {
        sdk_log_e( "%s, app_modbus_rtu_init error ret:%d ", __FUNCTION__, ret);
        return SF_ERR_NDEF;
    }
    /******** init rs485-2*******/
	return ret;
}

/**
* @brief		进入工厂测试模式   功能码：0x4010
* @param		[in] buf 要设置的数据
* @param		[in] len  要设置的参数个数
* @param		无
* @return		无
* @retval		无
* @warning		无
*/
static int32_t sci_enter_factory_test(uint8_t *in_buf, uint32_t in_len, uint8_t *out_buf, uint32_t *out_len)
{
	int32_t ret = 0;
    uint16_t mode_val = 0;

	*out_len = 1;
    
    if ( in_len != 2 ) 
    {
	    return SCI_NO_REPLY;
    }

    mode_val = (in_buf[0] << 8) | in_buf[1];
    
    if ( mode_val == 0 )
    {
		// 初始化rs485-2端口
		sci_factory_test_rs485_2_init();
		
        /* 单板测试 */
	    g_factory_test = FACTORY_MODE_PCB_TEST;
        sdk_log_d("%s FACTORY_MODE_PCB_TEST", __FUNCTION__);
    }else if ( mode_val == 1 )
    {
        /* 辅电箱测试 */
	    g_factory_test = FACTORY_MODE_DEV_TEST;
        factory_dev_test_init();
        sdk_log_d("%s FACTORY_MODE_DEV_TEST", __FUNCTION__);
    }else 
    {
	    out_buf[0] = SCI_RET_FAIL;	
	    return SCI_REPLY;
    }
	
    out_buf[0] = SCI_RET_SUCCESS;	
	return SCI_REPLY;
}


/**
* @brief		工厂测试   功能码：0x4020
* @param		[in] buf 要设置的数据
* @param		[in] len  要设置的参数个数
* @param		无
* @return		无
* @retval		无
* @warning		无
*/
static int32_t sci_factory_test(uint8_t *in_buf, uint32_t in_len, uint8_t *out_buf, uint32_t *out_len)
{
	uint16_t test_type = 0;
	uint16_t test_port = 0;
	uint16_t test_result = 0;
	int32_t ret = 0;
	
	if(g_factory_test == OFF)
	{
		out_buf[0] = in_buf[0];
		out_buf[1] = in_buf[1];
		out_buf[2] = in_buf[2];
		out_buf[3] = in_buf[3];
		out_buf[4] = 0;
		*out_len = 5;
		ret = -1;
		return ret;
	}
	
	test_type = (in_buf[0]<<8) + in_buf[1];
	test_port = (in_buf[2]<<8) + in_buf[3];
	
	test_result = factory_test(test_type,test_port);
	
	out_buf[0] = in_buf[0];
	out_buf[1] = in_buf[1];
	out_buf[2] = in_buf[2];
	out_buf[3] = in_buf[3];
	
        sdk_log_d("%s", __FUNCTION__);
	if(test_result == SUCCESS)	// 测试成功
	{
		
		out_buf[4] = 1;
		//manual_exhaust_flag = status;
	}	
	else		// 测试失败
	{
		out_buf[4] = 0;
		
	}	
	
	*out_len = 5;
	return SCI_REPLY;
}

static int32_t sci_factory_test_read_dat(uint8_t *in_buf, uint32_t in_len, uint8_t *out_buf, uint32_t *out_len)
{
    uint16_t fact_dat_type = (in_buf[0] << 8) | in_buf[1];

    #define FACT_DAT_TYPE_MCU2_VER          1
    #define FACT_DAT_TYPE_GAS_PRESSURE      2
    #define FACT_DAT_TYPE_FF_VER            3
    #define FACT_DAT_TYPE_FF_MIX_SEN_TYPE   4

    out_buf[0] = in_buf[0];
    out_buf[1] = in_buf[1];
    out_buf[2] = out_buf[3] = out_buf[4] = out_buf[5] = 0xff;   //< 默认 返回失败
    *out_len = 6;

    sdk_log_d("%s", __FUNCTION__);

	if( g_factory_test == FACTORY_MODE_NONE )
        return SCI_REPLY;

    if ( fact_dat_type == FACT_DAT_TYPE_MCU2_VER )
    {
        out_buf[2] = APP_VERSION_HEADER;
        out_buf[3] = APP_MAJOR_VERSION;
        out_buf[4] = APP_MINOR_VERSION;
        out_buf[5] = APP_STAGE_VERSION;
    }
    else if ( fact_dat_type == FACT_DAT_TYPE_GAS_PRESSURE )
    {
        uint16_t ff_gas_pressure;

        fire_fighting2_get_ff_gas_pressure( &ff_gas_pressure );
        out_buf[2] = 0;
        out_buf[3] = 0;
        out_buf[4] = (ff_gas_pressure >> 8) & 0xff;
        out_buf[5] = (ff_gas_pressure >> 0) & 0xff;
    }
    else if ( fact_dat_type == FACT_DAT_TYPE_FF_VER )
    {
        out_buf[2] = 'V';
        fire_fight_dev_get_sw_ver( &out_buf[3], &out_buf[4] );
        out_buf[5] = 0;
    }
    else if ( fact_dat_type == FACT_DAT_TYPE_FF_MIX_SEN_TYPE )
    {
        out_buf[2] = out_buf[3] = out_buf[4] = 0;
        out_buf[5] = fire_fight_dev_get_mix_sensor_type();
    }

    return SCI_REPLY;
}

static int32_t sci_factory_test_write_dat(uint8_t *in_buf, uint32_t in_len, uint8_t *out_buf, uint32_t *out_len)
{
    uint16_t fact_dat_key = (in_buf[0] << 8) | in_buf[1];

    #define FACT_DAT_KEY_SENSOR_TYPE        1

    out_buf[0] = in_buf[0];
    out_buf[1] = in_buf[1];

    out_buf[2] = 0; //< 默认 返回失败
    *out_len = 3;

    sdk_log_d("%s", __FUNCTION__);

	if( g_factory_test == FACTORY_MODE_NONE )
        return SCI_REPLY;

    if ( fact_dat_key == FACT_DAT_KEY_SENSOR_TYPE )
    {
        uint32_t value = (in_buf[2] << 24) | (in_buf[3] << 16) | (in_buf[4] << 8) | (in_buf[5] << 0);
        if ( fire_fight_dev_set_mix_sensor_type( (mix_sen_type_e)value ) == SF_OK )
        {
            out_buf[2] = 1; // 成功
        }
    }

    return SCI_REPLY;
}

/**
* @brief		退出工厂测试模式   功能码：0x4030
* @param		[in] buf 要设置的数据
* @param		[in] len  要设置的参数个数
* @param		无
* @return		无
* @retval		无
* @warning		无
*/
static int32_t sci_quit_factory_test(uint8_t *in_buf, uint32_t in_len, uint8_t *out_buf, uint32_t *out_len)
{
	int32_t ret = 0;

	g_factory_test = FACTORY_MODE_NONE;
	
	out_buf[0] = 0x01;	
	*out_len = 1;

	// 退出工厂测试后要重启，跟MCU1保持一致
	g_reset_flg = 1;
	return ret;
}


/**
* @brief		SCI数据交互
* @param		[in] sci 从机SCI结构体
* @param		[in] sci_master  主机SCI结构体
* @return		无
* @retval		无
* @warning		无
*/
int32_t data_swap(uint8_t command_h,
    uint8_t command_l,
    uint8_t* in_buf,
    uint32_t in_len,
    uint8_t* out_buf,
    uint32_t* out_len)
{
    for (int i = 0; i < sizeof(sci_context) / sizeof(sci_context[0]); i++)
    {
        if (command_h == sci_context[i].command_h && command_l == sci_context[i].command_l)
        {
            return sci_context[i].data_in_out(in_buf, in_len, out_buf, out_len);
        }
    }

    return -1;
}

/**
 * @brief               sci 初始化
 * @param sci           sci_t 结构体指针
 * @param slave_addr    从机地址
 * @param data_send     发送回调函数
 * @param data_swap     数据交换
 */
void sci_init(sci_t* sci, uint8_t slave_addr, sci_data_send_t data_send, sci_data_swap_t data_swap)
{
    sci->slave_addr = slave_addr;
    sci->data_send = data_send;
    sci->data_swap = data_swap;
}

/**
 * @brief               sci 命令处理
 * @param sci           sci_t 结构体指针
 * @param sci_master    sci_master_t 结构体指针
 */
static void sci_handle(sci_t* sci, sci_master_t* sci_master)
{
    int32_t result = 0;
    uint32_t len = 0;

    sci_slave_t* sci_slave = (sci_slave_t*)g_sci_send_buf;
    // 起始字
    sci_slave->start_word_h = sci_master->start_word_h;
    sci_slave->start_word_l = sci_master->start_word_l;
    // 从机地址
    sci_slave->slave_addr = sci_master->slave_addr;
    sci_slave->len = 0;
    // 功能码
    sci_slave->main_command = sci_master->main_command;
    sci_slave->len++;
    sci_slave->sub_command = sci_master->sub_command;
    sci_slave->len++;

    if (sci->data_swap)
    {
        result = sci->data_swap(sci_master->main_command,
            sci_master->sub_command,
            sci_master->data,
            sci_master->len - 3,
            sci_slave->data,
            &len);
        sci_slave->len += len;

        if (result) // 执行失败
        {
            return;
        }
    }
    else
    {
        return;
    }

    // 计算校验和
    checksum_calc(&sci_slave->slave_addr, sci_slave->len + 2, &sci_slave->data[len]);

    // 发送数据
    if (sci->data_send)
    {
        // util_print_hex_dat( "data send: ",g_sci_send_buf, sci_slave->len + 6, 10, true );
        sci->data_send(g_sci_send_buf, sci_slave->len + 6);
    }
}


/**
 * @brief       sci 协议解析
 * @param sci   sci_t 结构体指针
 * @param buf   接收数据缓冲区
 * @param len   接收数据长度
 */
void sci_receive_analysis(sci_t* sci, uint8_t* buf, uint32_t len)
{
    uint8_t* buf_tmp = NULL;
    int32_t len_remain = 0, len_tmp = 0;
    sci_master_t* sci_master = NULL;

    if (buf == NULL)
    {
        return;
    }

    buf_tmp = buf;
    len_remain = len;

    while (buf_tmp < buf + len)
    {
        sci_master = (sci_master_t*)buf_tmp;

        if (sci_master->start_word_h == SCI_START_WORD_H
            && sci_master->start_word_l == SCI_START_WORD_L)
        {
            len_tmp = sci_master->len + 6;

            if (len_remain < SCI_MIN_LEN)   // 数据小于9个字节，退出
            {
                return;
            }

            if (checksum_check(&sci_master->slave_addr, sci_master->len + 2, buf_tmp + sci_master->len + 4))
            {
                if (sci->slave_addr == sci_master->slave_addr)
                {
                    sci_handle(sci, sci_master);
                }
                else
                {
                    // 地址不相等
                }
            }
            else
            {
                // 校验和错误
                return;
            }
        }
        else
        {
            // 往后偏移1个字节
            len_tmp = 1;
        }

        buf_tmp += len_tmp;
        len_remain -= len_tmp;
    }
}

/**
* @brief		SCI初始化
* @param		无
* @retval		无
* @warning		无
*/
void inboard_sci_init(void)
{
    p_uart_conf.baud_rate = UART_BAUD_RATE_115200;
    p_uart_conf.data_bits = UART_DATA_BITS_8;
    p_uart_conf.flow_ctrl = UART_HWFLOW_OFF;
    p_uart_conf.parity = UART_PARITY_NONE;
    p_uart_conf.stop_bit = UART_STOP_BITS_1;
    sdk_uart_open(SCI_PORT);
    sdk_uart_setup(SCI_PORT, &p_uart_conf);

    sci_init(&inboard_sci, SCI_SLAVE_ADDR, sci_send, data_swap);
}


/**
 * @brief  开机检查文件系统
 * @param  [in] 无
 * @return 
 * @note   
 */
void boot_check_file_system( void )
{
    int32_t    ret     = -1;
    fs_stat_fs fs_stat = {0};

    // 检查剩余空间容量
    sdk_fs_stat_fs((const int8_t *)("1:"), (fs_stat_fs *)&fs_stat);
    sdk_log_i("FATFS block size:%d, total blocks:%d, free blocks:%d", fs_stat.f_bsize, fs_stat.f_blocks, fs_stat.f_bfree);
    
    /**
     * 历史原因：v1.0.10之前 core 文件系统信息有误，有9.7M，实际flash只有8M 
     * 先版本core已经修正，正常情况在1.7M左右
     * 所以在该版本发现文件系统信息错误，必须重新格式化
     * 由于V1.0.10之前没有用到fatfs文件系统，所以可以直接格式化
     */
    if ( (fs_stat.f_blocks * fs_stat.f_bsize ) >= ( 2 * 1024 * 1024 ))
    {
        /* v1.0.10以前版本，超过2M，直接格式化 */
        sdk_log_i( "FATFS total size error!!!, FORMATTING...." );
        ret = sdk_fs_format();
        if (ret == 0)
        {
            sdk_fs_stat_fs((const int8_t *)("1:"), (fs_stat_fs *)&fs_stat);
            sdk_log_i("FATFS formatted! block size:%d, total blocks:%d, free blocks:%d", fs_stat.f_bsize, fs_stat.f_blocks, fs_stat.f_bfree);
        }else{
            sdk_log_e( "sdk_fs_format fail!!!" );
        }
    }
}

void system_sta_printf(void)
{
    sdk_log_d("---------------fault_info--------------");
    sdk_log_d("dev_fault_info:%04X", g_system_info2.dev_fault_info.value);
    sdk_log_d("lc_fault_info:%04X-%04X-%04X-%04X",
                            g_system_info2.lc_fault_info.array[0], g_system_info2.lc_fault_info.array[1],
                            g_system_info2.lc_fault_info.array[2], g_system_info2.lc_fault_info.array[3]);
    sdk_log_d("\r\n---------------warn_info--------------");
    sdk_log_d("ff_warn2_info:%04X-%04X-%04X-%04X",
                            g_system_info2.ff_warn2_info.array[0], g_system_info2.ff_warn2_info.array[1],
                            g_system_info2.ff_warn2_info.array[2], g_system_info2.ff_warn2_info.array[3]);
    sdk_log_d("dev_warn_info:%04X", g_system_info2.dev_warn_info.value);
    sdk_log_d("lc_warn_info:%04X-%04X-%04X-%04X",
                            g_system_info2.lc_warn_info.array[0], g_system_info2.lc_warn_info.array[1],
                            g_system_info2.lc_warn_info.array[2], g_system_info2.lc_warn_info.array[3]);

    sdk_log_d("ff_warn1_info:%04X-%04X-%04X-%04X",
                            g_system_info2.ff_warn1_info.array[0], g_system_info2.ff_warn1_info.array[1],
                            g_system_info2.ff_warn1_info.array[2], g_system_info2.ff_warn1_info.array[3]);
    sdk_log_d("dry_warn_info:%04X", g_system_info2.dry_warn_info.value);

    sdk_log_d("\r\n---------------sta_info--------------");
    sdk_log_d( "chg_dischg_ctrl:%d", g_system_info2.chg_dischg_ctrl );
}
