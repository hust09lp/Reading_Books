#ifndef __DEV_CFG_STORE_H__
#ifndef __DEV_CFG_STORE_H__

#include "lc_data_type.h"

/**
  * @struct 
  * @brief  设备配置结构体
  */
typedef struct 
{
    lc_type_e   lc_type;            //< 液冷机型
    uint8_t     reserve[127];       
} dev_cfg_info_t;

/**
 * @brief  设备配置保存
 * @param  [in] p_dev_cfg_info : 设备配置信息
 * @return SF_OK ：正常     其他：异常 
 */
extern int32_t _dev_cfg_info_save( dev_cfg_info_t *p_dev_cfg_info );

/**
 * @brief  设备配置读取
 * @param  [out] p_dev_cfg_info : 设备配置信息
 * @return SF_OK ：正常     其他：异常 
 */
extern int32_t _dev_cfg_info_restore( dev_cfg_info_t *p_dev_info );

#endif
