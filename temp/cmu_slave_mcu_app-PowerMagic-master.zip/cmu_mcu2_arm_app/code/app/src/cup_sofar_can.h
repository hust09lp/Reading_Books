/**
 * @file     cup_sofar_can.h
 * @brief    公司自定义CAN协议拓展帧SDK接口
 * @author   duyumeng
 * @note     无
 * @version  V1.0
 * @date     2023/2/3
 */
#ifndef __CUP_SOFAR_CAN_H__
#define __CUP_SOFAR_CAN_H__

#include "stdint.h"

#define CAN1_PORT               1
#define CAN2_PORT               2


#define SOFAR_CAN_TRS_BUF_NUMS	  8		// 接收缓冲区个数
#define SOFAR_CAN_VER_LEN	      16	// 版本号 V1.0

//canbus通讯结果
#define SOFAR_CAN_RET_EMPTY       0       // 无发送数据
#define SOFAR_CAN_RET_WAIT        1       // 等待发送,任务调用发送时填入
#define SOFAR_CAN_RET_COMPILE	  2

/***********  需要应用按实际情况修改的内容 start  ***********/

#define CAN_SOFAR_ADDR_BITS			5		//设备地址占用bit数
#define CAN_SOFAR_TYPE_BITS			3		//设备类型占用bit数

#define FUN_FILE_DATA_READ			41		//读文件数据
#define FUN_FILE_DATA_WRITE			46		//写文件数据
#define FUN_UPDATE_DATA_TRS			52		//升级数据块传输

// device type  example
typedef enum{
	DEV_PCS 		= 1,	//PCS的设备ID
	DEV_CSU_MCU 	= 2,	//CSU的设备ID，设备地址1表示MCU1，设备地址2表示MCU2
}dev_type_e;

/***********  需要应用按实际情况修改的内容  end  ***********/

//函数运行结果
#define CAN_RET_TRUE				 1      //函数正确执行无错误，但数据没有接受完毕
#define CAN_DATA_COMPLETE			 0		//函数正确执行完,数据接受完毕
#define CAN_RET_NUMERR				-1		//发送数据长度越限
#define CAN_RET_TRSERR				-2		//发送出错
#define CAN_RET_RECERR				-3		//接收出错
#define CAN_RET_TIMEOUT				-4		//超时未收到数据
#define CAN_RET_CRC_ERR				-5		//CRC校验错误
#define CAN_RET_GINSENG				-10		//入参异常

#define CAN_SOFAR_DATA_MAXNUMS		(7 * 172 - 6)	//CAN数据最大长度,发送长度不能超过此数
#define CAN_SOFAR_SEND_MAXNUMS		(100 * 12)		//CAN最长发送长度

//CAN id msg
typedef struct
{
	uint8_t src_addr;		// source address
	uint8_t src_type;		// source device type
	uint8_t dst_addr;		// destination address
	uint8_t dst_type;		// destination device type
	uint8_t fun_code;		// CAN Frame function code
	uint8_t type;			// 帧类型，1：数据帧；2:请求帧；3：应答帧
	uint8_t prio;			// CAN Frame fun_code priority

	uint16_t addr;			// 数据帧的功能码对应的偏移地址
}can_id_t;

typedef union{
	uint32_t id_val;
	struct{
		uint32_t src_addr:	5;	// source address
		uint32_t src_type:	3;	// source device type
		uint32_t dst_addr:	5;	// destination address
		uint32_t dst_type:	3;	// destination device type
		uint32_t fun_code:	7;	// < CAN Frame function code
        uint32_t flag:	    1;	// 连续标志 0非连续，1是连续帧
        uint32_t type:	    2;	// 帧类型, 1：数据帧；2：功能帧-请求帧；3：功能帧-应答帧
		uint32_t prio:		3;	// < CAN Frame priority
        uint32_t format:	1;	// 0 表示标准帧，1表示拓展帧
		uint32_t  : 		2;	// < Reserved.
	}bit;
}can_frame_id_u;

typedef struct{
    can_frame_id_u can_frame_id;      //通讯帧ID
    uint8_t comm_state;         //通讯状态
    uint8_t rev_data[CAN_SOFAR_SEND_MAXNUMS];   //接收数据缓冲区
    uint8_t rev_num;            //接收数据的帧数
    uint8_t rev_len;            //接收数据的长度
    uint16_t addr;              //地址
}can_rev_comm_t;

extern can_rev_comm_t g_can_rev_comm[SOFAR_CAN_TRS_BUF_NUMS] ;
/**
 * @brief   CAN 通讯协议初始化（接收状态初始化）
 * @note    在创建CAN通讯任务，初始化时需要调用此函数，防止接收数据时的状态、缓冲区未初始化
 * @return  返回执行结果 0:正常；<0:异常
 */
int32_t cup_sofar_can_init(void);

/**
 * @brief   发送CAN数据打包发送
 * @param   [in] index  CAN 口编号
 * @param   [in] can_msg  CAN ID信息
 * @param   [in] p_data  需要发送的数据
 * @param   [in] len  需要发送的数据长度
 * @note    调用此函数之前需要APP层自己调用打开CAN的SDK接口
 * @return  返回执行结果 0:正常；<0:异常
 */
int32_t cup_sofar_can_send(uint32_t index, can_id_t *can_id, uint8_t *p_data, int32_t len);

/**
 * @brief   发送CAN数据接收
 * @param   [in] index  CAN 口编号
 * @param   [in] timeout_ms  读取超时时间设置
 * @param   [out] can_id_msg  接收数据的CAN ID信息
 * @param   [out] p_data  接收的数据
 * @param   [out] len  接收数据的长度
 * @note    调用此函数之前需要APP层自己调用打开CAN的SDK接口，收到完整数据包之后将数据返回
 * 			返回的数据根据不同的功能码有以下不同的情况（只有数据包时的数据帧p_data才仅是真正的数据）
 * 			p_data:数据帧时对应的是解析组包之后的数据；请求和应答帧时是应答和请求的帧数据内容
 * @return  返回执行结果 0:正常；<0:异常
 */
int32_t cup_sofar_can_rev(uint32_t index, int32_t timeout_ms, can_id_t *can_id, uint8_t *p_data, int32_t *len);

/**
 * @brief        版本获取函数
 * @param        [out] p_ver 版本数据存在p_version所指向的地址中，传出参数
 * @param        [in] len 传入版本号字节长度，避免数据超出传入的数组大小
 * @return       [int32_t] 执行结果
 * @retval       >=  版本号的实际长度(必须小于传入的长度)
 * @retval       < 0 失败原因
 */
int32_t cup_sofar_can_ver_get(uint8_t *p_ver, uint16_t len);

/**
 * @brief        打印信息设置函数
 * @param        [in] flag 打印信息设置函数，0不打印，1打印
 * @return       [int32_t] 执行结果
 * @retval       =0  设置成功
 * @retval       < 0 失败原因
 */
int32_t cup_sofar_can_debug_set(int8_t flag);

/**
 * @brief   crc16的计算值
 * @param   [in] p_data  需要发送的数据
 * @param   [in] len  需要发送的数据长度
 * @note    
 * @return  返回执行结果 0:正常；<0:异常
 */
uint16_t crc16(uint8_t *p_data, int32_t len);

#endif
