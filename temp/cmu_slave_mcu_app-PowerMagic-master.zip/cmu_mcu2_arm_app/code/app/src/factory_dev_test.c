#include "sdk_osif.h"
#include "sdk.h"
#include "sdk_core.h"
#include "sdk_modbus.h"
#include "sdk_dido.h"
#include "sci.h"
#include "factory_test.h"
#include "factory_dev_test.h"

#include "extern_io.h"
#include "app_modbus.h"
#include "peripheral_cfg.h"
#include "fire_fighting2.h"
#include "fire_fight_dev.h"

// 测试失败后的重试次数
#define RETRY_TIMES   5

#define EXT_IO_MOD_INDEX        0
#define EXT_IO_DI_DO_INVALID    0xff
#define DI_DO_INVALID           0xff

/*--------------------------------------- IO拓展板配置 ----------------------------------------------*/

#define FACTORY_TEST_IO_EXT_DO_TMPER_SEN_PORT       5
#define FACTORY_TEST_IO_EXT_DO_SMOKE_SEN_PORT       6

typedef enum {
    IO_TYPE_NULL,
    IO_TYPE_MCU2,
    IO_TYPE_EXT,
} io_type_e;

typedef struct 
{
    struct {
        io_type_e type;
        uint8_t   io_port;
    } Din;

    struct {
        io_type_e type;
        uint8_t   io_port;
    } Dout;
} io_link_t;


io_link_t s_io_link_tab[] = {
    { .Din = { IO_TYPE_MCU2, DI_AEROGEL },              .Dout = { IO_TYPE_MCU2, DO_FF_ALERTOR } },
    { .Din = { IO_TYPE_EXT, EXT_IO_DI_FLOOD1_PORT },    .Dout = { IO_TYPE_MCU2, DO_DEV_FAULT_TO_CSU } },
    { .Din = { IO_TYPE_EXT, EXT_IO_DI_FLOOD2_PORT },    .Dout = { IO_TYPE_MCU2, DO_DEV_FAULT_TO_OUT } },
    { .Din = { IO_TYPE_EXT, EXT_IO_DI_DEV_DOOR_PORT },  .Dout = { IO_TYPE_EXT, EXT_IO_DO_HIG_VOL } },
    { .Din = { IO_TYPE_EXT, EXT_IO_DI_BAT_DOOR_PORT },  .Dout = { IO_TYPE_EXT, EXT_IO_DO_HIG_VOL } },
    { .Din = { IO_TYPE_EXT, EXT_IO_DI_TMPER_SEN_PORT }, .Dout = { IO_TYPE_EXT, FACTORY_TEST_IO_EXT_DO_TMPER_SEN_PORT } },
    { .Din = { IO_TYPE_EXT, EXT_IO_DI_SMOKE_SEN_PORT }, .Dout = { IO_TYPE_EXT, FACTORY_TEST_IO_EXT_DO_SMOKE_SEN_PORT } },
    { .Din = { IO_TYPE_NULL, DI_DO_INVALID },           .Dout = { IO_TYPE_EXT, EXT_IO_DO_FAN_PORT } },
};

int32_t factory_dev_io_link_test( io_type_e io_type, bool io_is_di, uint16_t test_port );

/**
 * @brief		工厂485测试接口
 * @param		[in] test_port 要测试的485通道：通道1-4
 * @return		ret：-1 测试失败  除-1外的其他值：测试成功
 * @warning		无
 */
int32_t factory_dev_rs485_test(uint16_t test_port)
{
    int32_t ret           = FACTORY_RET_ERR;
    uint8_t *p_src_buf    = NULL;
    uint8_t *p_dst_buf    = NULL;
    uint8_t data_check    = 0;
    uint8_t i             = 0;
    uint16_t tmp_vals[10] = {0};

    // test_port为无符号数
    if (test_port == 0 || test_port > MODBUS_MAX)
    {
        return FACTORY_RET_ERR;
    }
    // 操作的索引比传入的少1
    // test_port -= 1;

    switch (test_port)
    {
        case 1:
            factory_dev_test_init();  
            if ( 0 <= fire_fighting2_dat_sync() )
            {
                ret = FACTORY_RET_SUCCESS;
            }
            break;
        case 2:
            if ( 0 <= app_modbus_registers_read( MODBUS_INDEX2, 1, 0x2000, 1, tmp_vals, 0 ))
            {
                ret = FACTORY_RET_SUCCESS;
            }
            break;
        case 3:
            break;
        case 4:
            /* 对内 */
            if ( IO_STA_NONE != extern_io_get_input_lv_sync( EXT_IO_MOD_INDEX, 0 ))
            {
                ret = FACTORY_RET_SUCCESS;
            }
            
            break;
        default:
            break;
    }
    return ret;
}

static sf_ret_t _factory_dev_ff_mix_sen_con_test( void ) 
{
    ff_warn1_info_u warn1_info = {.value = 0} ;

    if( fire_fighting2_dat_sync() < 0 )
    {
        return -1;
    }

    fire_fighting2_get_warn1( &warn1_info );
    if ( 1 == warn1_info.bit.mix_sensor1_offline )
    {
        return -1;
    }

    return SF_OK;
}

static sf_ret_t _factory_dev_ff_io_ext_con_test( void ) 
{
    ff_warn1_info_u warn1_info = {.value = 0} ;

    if( fire_fighting2_dat_sync() < 0 )
    {
        return -1;
    }

    fire_fighting2_get_warn1( &warn1_info );
    // fire_fighting2_get_warn2( &warn2_info );
    // if ( 1 == warn2_info.bit.ff_io_ext1_offline )
    if ( 1 == warn1_info.bit.ff_io_ext_offline )
    {
        return -1;
    }

    return SF_OK;
}

static sf_ret_t _factory_dev_ff_do_fault_test( void ) 
{
    // ff_do_sta_info_u do_sta_info = { .value = 0 };
    int32_t mcu2_fault_lv;
    uint8_t mb_mcu2_fault_lv;

    /* 低压告警数值设高，触发消防公共故障 */
    // if(  fire_fighting2_set_pressure_threshold( 3100, 3200 ) < 0 )
    if(  fire_fight_dev_set_pressure_threshold( 3100, 3200 ) < 0 )
    {
        return -1;
    }
    sdk_log_d( "_factory_dev_ff_do_fault_test lv set 1" );

    /* 等待，确保触发消防公共故障 */
    sdk_os_delay(sdk_os_tick_from_millisecond(6000));

    if( fire_fighting2_dat_sync() < 0 )
    {
        return -1;
    }

    /* 判断故障状态是否关闭 */
    // fire_fighting2_get_do_sta( &do_sta_info );
    fire_fighting2_get_mb_do_sta( NULL, NULL, &mb_mcu2_fault_lv );
    mcu2_fault_lv = sdk_dido_read( DI_FF_COMM_FAULT );
    if ( (mb_mcu2_fault_lv != 1) || ( mcu2_fault_lv != 1 ) )
    {
        return -1;
    }

    /* 低压告警数值设到正常值，关闭消防公共故障 */
    // if(  fire_fighting2_set_pressure_threshold( 1800, 3200 ) < 0 )
    if( fire_fight_dev_set_pressure_threshold( 1800, 3200 ) < 0 )
    {
        return -1;
    }
    sdk_log_d( "_factory_dev_ff_do_fault_test lv set 0" );

    /* 等待，确保关闭消防公共故障 */
    sdk_os_delay(sdk_os_tick_from_millisecond(1000));
    if( fire_fighting2_dat_sync() < 0 )
    {
        return -1;
    }

    /* 判断故障状态是否关闭 */
    // fire_fighting2_get_do_sta( &do_sta_info );
    fire_fighting2_get_mb_do_sta( NULL, NULL, &mb_mcu2_fault_lv );
    mcu2_fault_lv = sdk_dido_read( DI_FF_COMM_FAULT );
    if ( (mb_mcu2_fault_lv != 0) || ( mcu2_fault_lv != 0 ) )
    {
        return -1;
    }

    return SF_OK;
}

static sf_ret_t _factory_dev_ff_do_warn1_test( void ) 
{
    // ff_do_sta_info_u do_sta_info = { .value = 0 };
    int32_t mcu2_warn1_lv;
    uint8_t mb_mcu2_warn1_lv;

    /* 同步消防控制器数据 */
    if( fire_fighting2_dat_sync() < 0 )
    {
        return -1;
    }

    // fire_fighting2_get_do_sta( &do_sta_info );
    fire_fighting2_get_mb_do_sta( &mb_mcu2_warn1_lv , NULL, NULL );
    mcu2_warn1_lv = sdk_dido_read( DI_FF_WARN2);
    if ( (mb_mcu2_warn1_lv != 0) || ( mcu2_warn1_lv != 0) )
    {
        return -1;
    }

    /* 模拟触发烟感 */
    if ( 0 > extern_io_set_output_lv_sync( EXT_IO_MOD_INDEX, FACTORY_TEST_IO_EXT_DO_SMOKE_SEN_PORT, 1 ))
    {
        return -1;
    }
    
    /* 等待触发一级告警 */
    sdk_os_delay(sdk_os_tick_from_millisecond(8000));

    /* 判断是否已触发一级告警 */        
    mcu2_warn1_lv = sdk_dido_read( DI_FF_WARN1 );
    if ( mcu2_warn1_lv != 1 ) 
    {
        return -1;
    }

    return SF_OK;
}


static sf_ret_t _factory_dev_ff_do_warn2_test( void ) 
{
    // ff_do_sta_info_u do_sta_info = { .value = 0 };
    int32_t mcu2_warn2_lv;
    uint8_t mb_mcu2_warn2_lv;

    /* 同步消防控制器数据 */
    if( fire_fighting2_dat_sync() < 0 )
    {
        return -1;
    }

    // fire_fighting2_get_do_sta( &do_sta_info );
    fire_fighting2_get_mb_do_sta( NULL , &mb_mcu2_warn2_lv, NULL );
    mcu2_warn2_lv = sdk_dido_read( DI_FF_WARN2 );
    if ( (mb_mcu2_warn2_lv != 0) || ( mcu2_warn2_lv != 0) )
    {
        return -1;
    }

    /* 模拟触发 烟感 + 温感 */
    if ( 0 > extern_io_set_output_lv_sync( EXT_IO_MOD_INDEX, FACTORY_TEST_IO_EXT_DO_SMOKE_SEN_PORT, 1 ))
    {
        return -1;
    }
    if ( 0 > extern_io_set_output_lv_sync( EXT_IO_MOD_INDEX, FACTORY_TEST_IO_EXT_DO_TMPER_SEN_PORT, 1 ))
    {
        return -1;
    }
    
    /* 等待触发二级告警 */
    sdk_os_delay(sdk_os_tick_from_millisecond(8000));

    /* 判断是否已触发二级告警 */        
    mcu2_warn2_lv = sdk_dido_read( DI_FF_WARN2 );
    if ( mcu2_warn2_lv != 1 ) 
    {
        return -1;
    }
    
    return SF_OK;
}

sf_ret_t factory_dev_ff_di_cmu_start_test( void ) 
{
    ff_do_sta_info_u do_sta_info = { .value = 0 };
    int32_t mcu2_cmu_start_lv;
    uint8_t mb_cmu_start_lv;

    sdk_dido_write( DO_FF_START, ON );
    sdk_os_delay(sdk_os_tick_from_millisecond(500));

    /* 同步消防控制器数据 */
    if( fire_fighting2_dat_sync() < 0 )
    {
        return -1;
    }
    fire_fighting2_get_mb_di_sta( &mb_cmu_start_lv );
    if ( mb_cmu_start_lv != ON )    
    {
        return -1;
    }

    sdk_dido_write( DO_FF_START, OFF );
    sdk_os_delay(sdk_os_tick_from_millisecond(500));
    /* 同步消防控制器数据 */
    if( fire_fighting2_dat_sync() < 0 )
    {
        return -1;
    }
    fire_fighting2_get_mb_di_sta( &mb_cmu_start_lv );
    if ( mb_cmu_start_lv != OFF )    
    {
        return -1;
    }
    
    return SF_OK;
}

sf_ret_t factory_dev_ff_cylinder_di_test( void ) 
{
    uint16_t ff_gas_pressure;

    /* 同步消防控制器数据 */
    if( fire_fighting2_dat_sync() < 0 )
    {
        return -1;
    }

    if (fire_fighting2_get_solenoid_trace_sta() == 1 )
        return SF_OK;
    else 
        return -1;
}

sf_ret_t factory_dev_ff_gas_pressure_test( void ) 
{
    uint16_t ff_gas_pressure;

    /* 同步消防控制器数据 */
    if( fire_fighting2_dat_sync() < 0 )
    {
        return -1;
    }

    /* 判断气瓶气压是否在误差范围内 */
    fire_fighting2_get_ff_gas_pressure( &ff_gas_pressure );
    if ( (ff_gas_pressure < 1800) || (ff_gas_pressure > 3200) )
    {
        return -1;
    }

    return SF_OK;
}

/**
 * @brief		工厂 消防控制器测试
 * @param		[in] test_type 测试类型 3-DI测试   4-DO测试
 * @return		ret：-1 测试失败  除-1外的其他值：测试成功
 * @warning		无
 */
int32_t factory_dev_ff_test( ff_test_e ff_test_type )
{
    int32_t ret = FACTORY_RET_ERR;

    if ( ff_test_type == FF_TEST_MIX_SEN_CONN ) 
    {
        if ( _factory_dev_ff_mix_sen_con_test() == 0 )
        {
            ret = FACTORY_RET_SUCCESS;
        }
    } else if ( ff_test_type == FF_TEST_IO_EXT_CONN ) 
    {
        if ( _factory_dev_ff_io_ext_con_test() == 0 )
        {
            ret = FACTORY_RET_SUCCESS;
        }
    } else if ( ff_test_type == FF_TEST_DO_FAULT ) 
    {
        if ( _factory_dev_ff_do_fault_test() == 0 )
        {
            ret = FACTORY_RET_SUCCESS;
        }
    } else if ( ff_test_type == FF_TEST_DO_WARN1 ) 
    {
        if ( _factory_dev_ff_do_warn1_test() == 0 )
        {
            ret = FACTORY_RET_SUCCESS;
        }
    } else if ( ff_test_type == FF_TEST_DO_WARN2 ) 
    {
        if ( _factory_dev_ff_do_warn2_test() == 0 )
        {
            ret = FACTORY_RET_SUCCESS;
        }
    } else if ( ff_test_type == FF_TEST_DI_CMU_START ) 
    {
        if ( factory_dev_ff_di_cmu_start_test() == 0 )
        {
            ret = FACTORY_RET_SUCCESS;
        }
    } else if ( ff_test_type == FF_TEST_DI_TH_SIGNAL ) 
    {
        /* 瓶组信号反馈 */
        /* 上位机提示：手动短接和断开，上位机判断对应的状态 */
        if (factory_dev_ff_cylinder_di_test() == 0)
        {
            ret = FACTORY_RET_SUCCESS;
        }
    } else if ( ff_test_type == FF_TEST_PRESS_VAL ) 
    {
        if ( factory_dev_ff_gas_pressure_test() == 0 )
        {
            ret = FACTORY_RET_SUCCESS;
        }
    }
    return ret; 
}


int32_t factory_dev_io_extern_di_do_test( uint8_t io_port )
{
    #define IO_PORT_DI_DIR_MASK     0x80
    #define IO_PORT_VALUE_MASK       0x7f

    if ( io_port & IO_PORT_DI_DIR_MASK )
    {
        /* DI */
        return factory_dev_io_link_test( IO_TYPE_EXT , true, io_port & IO_PORT_VALUE_MASK );
    } else {
        /* DO */
        return factory_dev_io_link_test( IO_TYPE_EXT , false, io_port & IO_PORT_VALUE_MASK );
    }
}

/**
 * @brief		工厂DI DO测试接口
 * @param		[in] test_type 测试类型 3-DI测试   4-DO测试
 * @return		ret：-1 测试失败  除-1外的其他值：测试成功
 * @warning		无
 */
int32_t factory_dev_di_do_test(uint16_t test_type, uint16_t test_port)
{
    if (test_type == DI_TEST)
    {
        /* DI */
        return factory_dev_io_link_test( IO_TYPE_MCU2 , true, test_port );
    } else if (test_type == DO_TEST)
    {
        /* DO */
        return factory_dev_io_link_test( IO_TYPE_MCU2 , false, test_port );
    }
    return RET_ERR;
}

static int32_t _factory_dev_io_link_set_lv( io_type_e io_type, uint16_t io_port, uint8_t io_lv )
{
    if ( io_type == IO_TYPE_MCU2 )
    {
        if( sdk_dido_write( io_port, io_lv ) < 0 ) 
            return FACTORY_RET_ERR;

    }else if ( io_type == IO_TYPE_EXT )
    {
        if(  extern_io_set_output_lv_sync( EXT_IO_MOD_INDEX, io_port, io_lv ) < 0 )
            return FACTORY_RET_ERR;
    }else
        return FACTORY_RET_ERR;

    return FACTORY_RET_SUCCESS;
}

static int32_t _factory_dev_io_link_get_lv( io_type_e io_type, uint16_t io_port )
{
    if ( io_type == IO_TYPE_MCU2 )
    {
        return sdk_dido_read( io_port );

    }else if ( io_type == IO_TYPE_EXT )
    {
        return extern_io_get_input_lv_sync( EXT_IO_MOD_INDEX, io_port );
    }else
        return -1;
}

int32_t factory_dev_io_link_test( io_type_e io_type, bool io_is_di, uint16_t test_port )
{
    io_link_t *p_io_link = NULL;
    int32_t di_status = 0;

    test_port--;

    for (size_t i = 0; i < ARRAY_SIZE( s_io_link_tab ); i++)
    {
        if ( (io_is_di == true) && ( io_type == s_io_link_tab[i].Din.type ) && ( test_port == s_io_link_tab[i].Din.io_port ) )
        {
            p_io_link = &s_io_link_tab[i];
        }
        else if ( (io_is_di == false) && ( io_type == s_io_link_tab[i].Dout.type ) && ( test_port == s_io_link_tab[i].Dout.io_port ) )
        {
            p_io_link = &s_io_link_tab[i];
        }
    }
    
    if ( p_io_link == NULL )
    {
        return FACTORY_RET_ERR;
    }
    
    if ( p_io_link->Din.type == IO_TYPE_NULL )
    {
        /* 单纯测DO */
        for (size_t i = 0; i < 3; i++)
        {
            _factory_dev_io_link_set_lv( p_io_link->Dout.type, p_io_link->Dout.io_port, ON );
            sdk_os_delay(sdk_os_tick_from_millisecond(500));
            _factory_dev_io_link_set_lv( p_io_link->Dout.type, p_io_link->Dout.io_port, OFF );
            sdk_os_delay(sdk_os_tick_from_millisecond(500));
        }
    }else{
        // 第1步：将DO拉高并延时100ms
        _factory_dev_io_link_set_lv( p_io_link->Dout.type, p_io_link->Dout.io_port, ON );
        sdk_os_delay(sdk_os_tick_from_millisecond(500));

        // 第2步：读取对应的DI状态
        di_status = _factory_dev_io_link_get_lv( p_io_link->Din.type, p_io_link->Din.io_port );

        // 第3步：判断对应的DI状态是否为高
        if (di_status != ON)
        {
            sdk_log_e("[%s], DI%d TEST ON FAIL\r\n",  ( io_type == IO_TYPE_MCU2 ) ? "IO_TYPE_MCU2":
                                                        ( io_type == IO_TYPE_EXT  ) ? "IO_TYPE_EXT": "IO_TYPE_UNKNOW",
                                                        test_port + 1);
            return FACTORY_RET_ERR;
        }

        // 第4步：将DO拉低并延时100ms
        _factory_dev_io_link_set_lv( p_io_link->Dout.type, p_io_link->Dout.io_port, OFF );
        sdk_os_delay(sdk_os_tick_from_millisecond(500));

        // 第5步：读取对应的DI状态
        di_status = _factory_dev_io_link_get_lv( p_io_link->Din.type, p_io_link->Din.io_port );

        // 第6步：判断对应的DI状态是否为低
        if (di_status != OFF)
        {
            sdk_log_e("[%s], DI%d TEST OFF FAIL\r\n",  ( io_type == IO_TYPE_MCU2 ) ? "IO_TYPE_MCU2":
                                                        ( io_type == IO_TYPE_EXT  ) ? "IO_TYPE_EXT": "IO_TYPE_UNKNOW",
                                                        test_port + 1);
            return FACTORY_RET_ERR;
        }

        sdk_log_d("[%s], DI%d TEST SUCCESS\r\n",  ( io_type == IO_TYPE_MCU2 ) ? "IO_TYPE_MCU2":
                                                    ( io_type == IO_TYPE_EXT  ) ? "IO_TYPE_EXT": "IO_TYPE_UNKNOW",
                                                    test_port + 1);
    }
    return FACTORY_RET_SUCCESS;
}

sf_ret_t factory_dev_test_init( void )
{
    sdk_dido_write( DO_FF_START, OFF );
    for (size_t i = 0; i < ARRAY_SIZE( s_io_link_tab ); i++)
    {
        _factory_dev_io_link_set_lv( s_io_link_tab[i].Dout.type, s_io_link_tab[i].Dout.io_port, OFF );
    }
    return SF_OK;
}
