#ifndef _DEV_BOX_H_
#define _DEV_BOX_H_

#include "sofar_type.h"
#include "sci_frame.h"

/**
 * @brief  储能舱初始化
 * @param  [in] 无
 * @return SF_OK：成功  小于SF_OK: 失败
 */
sf_ret_t energy_cabinet_dev_init( void );

/**
 * @brief  储能舱 数据置为默认状态
 * @param  [in] 无
 * @return SF_OK：成功  小于SF_OK: 失败
 */
sf_ret_t energy_cabinet_bat_box_dat_set_default( void );

/**
 * @brief 设置电池舱个数  
 * @param  [in] bat_box_num 电池舱个数
 * @return SF_OK：成功  小于SF_OK: 失败
 */
sf_ret_t energy_cabinet_set_bat_cluster_num( uint8_t bat_box_num );

/**
 * @brief 获取电池舱个数  
 * @param  [in] 无
 * @return 返回电池舱个数
 */
uint8_t energy_cabinet_get_bat_box_num( void );

/**
 * @brief  设置风扇状态
 * @param  [in] bat_cab_idx : 电池柜索引
 * @param  [in] fan_sta     : 风扇状态 【SF_TRUE(运行) / SF_FALSE(关闭)】
 * @return SF_OK：成功  小于SF_OK: 失败
 */
sf_ret_t energy_cabinet_set_fan_sta( dev_idx_t bat_cab_idx, bool fan_sta );

/**
 * @brief  设置除湿阈值
 * @param  [in] humi     : 除湿阈值
 * @param  [in] humi_ret : 除湿回差
 * @return SF_OK：成功  小于SF_OK: 失败
 */
sf_ret_t energy_cabinet_set_dehumi_setting( uint16_t humi, uint16_t humi_ret );

/**
 * @brief  开启消防【让消防控制器 喷灭火剂】
 * @param  [in] on 风扇状态 【SF_TRUE(运行) / SF_FALSE(关闭)】
 */
void energy_cabinet_set_fire_fighting_start( bool on );

/**
 * @brief  开启声光报警
 * @param  [in] on 【SF_TRUE(打开) / SF_FALSE(关闭)】
 * @return 无
 */
void energy_cabinet_set_fire_fighting_alarm( bool on );

/**
 * @brief  设置维护模式【与门磁状态相关联，维护状态下不可开门】
 * @param  [in] enable 【SF_TRUE(使能) / SF_FALSE(关闭)】
 * @return 无
 */
void energy_cabinet_set_maintenance_mode( bool enable );

/**
 * @brief  对外输出故障【CSU故障/对外故障/高压盒故障】
 * @param  [in] on 【SF_TRUE(使能) / SF_FALSE(关闭)】
 * @return 无
 */
sf_ret_t energy_cabinet_set_fault_lv_output( bool on );

/**
 * @brief  获取DI状态
 * @param  [out] p_dev_di_sta ：DI 状态结构体
 * @return 无
 */
void energy_cabinet_get_di_sta( dev_di_sta_info_u *p_dev_di_sta);

/**
 * @brief  获取Do状态
 * @param  [out] p_dev_do_sta ：DO 状态结构体
 * @return 无
 */
void energy_cabinet_get_do_sta( dev_do_sta_info_u *p_dev_do_sta);

/**
 * @brief  获取告警信息
 * @param  [out] p_dev_warn ：告警信息结构体
 * @return 无
 */
void energy_cabinet_get_warn( dev_warn_info_u *p_dev_warn);

/**
 * @brief  获取故障信息
 * @param  [out] p_dev_fault ：故障信息结构体
 * @return 无
 */
void energy_cabinet_get_fault( dev_fault_info_u *p_dev_fault);

/**
 * @brief  任务调度
 * @param  [in] 无
 * @return 
 */
void    energy_cabinet_task_loop( void );

#endif
