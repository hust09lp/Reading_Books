#include "bool_filter.h"
#include "sig_keeper.h"
#include "fire_fight_local.h"
#include "tick_timer.h"
#include "sci_frame.h"
#include "extern_io.h"

#include "peripheral_cfg.h"
#include "proj_cfg.h"
#include "sofar_type.h"

#include "sdk.h"
#include "sdk_core.h"
#include <string.h>

#define TMPER_OVER_RETE_CHECK_INV_TM_MS             ( 20 * 1000 )     //< 超温速率检测 时间间隔
#define TRIG_SIG_KEEP_TM_MS                         ( 3600 * 1000 )   //< 触发信号保持时间  

#define TEMPER_FAULT_OVER_RATE_INCREASE_TMPER       6       //< 温度异常温升速率 温度，单位1℃
#define TEMPER_OVER_RATE_VALID_CNT                  2       //< 温度异常温升速率 连续次数

typedef struct
{
    uint8_t valid_cnt;                          //< 记录有效个数
    uint8_t start_idx;                          //< 最开始节点索引，即为0秒索引
    int16_t max_tmp[4];                         //< 0s 20s 40s 60s
} temper_record_t;

typedef struct {
    temper_record_t     temper_record;          //< 温度记录
    bool                over_rate_sta;          //< 温升速率状态
    uint8_t             over_rate_cnt;          //< 温升速率次数，超过2，置位 over_rate_sta
} temper_over_rate_t;

typedef union 
{
    uint8_t value;
    struct 
    {
        uint8_t temper_smoke_detect      :1;    //< 烟感 + 温感
        uint8_t smoke_detect_over_temper :1;    //< 烟感 + 复合温度
        uint8_t temper_detect_over_co    :1;    //< 温感 + 复合CO
        uint8_t pack_temp                :1;    //< 电池高温 + 电池温升
        uint8_t pack_temp_mix_co         :1;    //< 电池高温 + 复合CO
        uint8_t pack_temp_rate_mix_co    :1;    //< 电池温升 + 复合CO
    } bit;
} local_warn2_u;


typedef struct 
{
    struct 
    {
        uint8_t                node_num;                        //< 节点个数
        bool                   local_enable;                    //< 本地消防使能
        bool                   threshold_enable;                //< 消防阈值有效
        ff_threshold_set_t     threshold;                       //< 消防阈值
        f_local_warn_change_cb local_warn_change_cb;            //< 本地消防告警回调函数
    } attr;                                                     //< 属性数据【设置数据】

    struct 
    {
        struct 
        {
            bool_filter_hd    temper_detect_hd;                 //< 温度探测器 滤波
            bool_filter_hd    smoke_detect_hd;                  //< 烟雾探测器 滤波
            bool_filter_hd    mix_sen_over_temper_hd;           //< 复合传感器超温 滤波
            bool_filter_hd    mix_sen_over_co_hd;               //< 复合传感器CO过高 滤波
            sig_keeper_hd     over_co_sig_keeper_hd;            //< 复合传感器CO过高 信号保持
            bool_filter_hd    bat_hig_tmper_filter_hd;          //< 电池高温 滤波
            sig_keeper_hd     bat_hig_tmper_keeper_hd;          //< 电池高温 信号保持
            sig_keeper_hd     bat_tmper_over_rate_keeper_hd;    //< 电池温升速率 信号保持

            /* 滤波 + 信号保持 之后的数值 */
            bool_val_e        mix_sen_over_temper;              //< 复合传感器 超温
            bool_val_e        mix_sen_over_co;                  //< 复合传感器 CO过高
            bool_val_e        temper_detect;                    //< 温度探测器 触发
            bool_val_e        smoke_detect;                     //< 烟雾探测器 触发
            bool_val_e        bat_hig_tmper;                    //< 电池高温 
            bool_val_e        bat_tmper_over_rate;              //< 电池温升速率过快 

            local_warn2_u     warn2;                            //< 本地消防二级告警

        } node[ BAT_CLUSTER_MAX ];
    } run;                                                      //< 运行数据
} ff_local_info_t;

static ff_local_info_t s_ff_local_info;

static void _fire_fight_local_warn2_change_check( void );
static void _fire_fight_bat_temper_over_rate_check( bat_temper_t *p_curr_bat_temper_list );
static void _fire_fight_local_warn2_data_input( ff_sen_dat_info_t *p_ff_sen_dat, bat_temper_t *p_curr_bat_temper_list );
static void _fire_fight_all_sig_fresh_and_handle( void );

sf_ret_t fire_fight_local_init( f_local_warn_change_cb ff_warn_change_cb )
{
    memset( &s_ff_local_info, 0, sizeof( ff_local_info_t ) );

    s_ff_local_info.attr.local_warn_change_cb = ff_warn_change_cb;
    s_ff_local_info.attr.local_enable = true;

    for (size_t i = 0; i < BAT_CLUSTER_MAX; i++)
    {
        /* 滤波器设置： 至少 采集3次且保持5s 信号才有效 */
        filter_setting_t bool_filter_setting     = { .cnt = 3  ,    .tm_ms = 5000 };
        /* 信号保持其设置： true信号一旦触发，保持1小时 */
        sig_keeper_setting_t sig_keeper_setting  = { .hig_prio_sig = true, .keep_tm_ms   = TRIG_SIG_KEEP_TM_MS };

        s_ff_local_info.run.node[i].temper_detect_hd        = bool_filter_create( FILTER_TYPE_TM_AND_CNT, &bool_filter_setting, &bool_filter_setting );
        s_ff_local_info.run.node[i].smoke_detect_hd         = bool_filter_create( FILTER_TYPE_TM_AND_CNT, &bool_filter_setting, &bool_filter_setting );
        s_ff_local_info.run.node[i].mix_sen_over_temper_hd  = bool_filter_create( FILTER_TYPE_TM_AND_CNT, &bool_filter_setting, &bool_filter_setting );
        s_ff_local_info.run.node[i].mix_sen_over_co_hd      = bool_filter_create( FILTER_TYPE_TM_AND_CNT, &bool_filter_setting, &bool_filter_setting );
        s_ff_local_info.run.node[i].bat_hig_tmper_filter_hd = bool_filter_create( FILTER_TYPE_TM_AND_CNT, &bool_filter_setting, &bool_filter_setting );

        s_ff_local_info.run.node[i].over_co_sig_keeper_hd         = bool_sig_keeper_create( &sig_keeper_setting );
        s_ff_local_info.run.node[i].bat_hig_tmper_keeper_hd       = bool_sig_keeper_create( &sig_keeper_setting ); 
        s_ff_local_info.run.node[i].bat_tmper_over_rate_keeper_hd = bool_sig_keeper_create( &sig_keeper_setting ); 
        if (   (s_ff_local_info.run.node[i].mix_sen_over_temper_hd  == NULL )
            || (s_ff_local_info.run.node[i].mix_sen_over_co_hd      == NULL )
            || (s_ff_local_info.run.node[i].temper_detect_hd        == NULL )
            || (s_ff_local_info.run.node[i].smoke_detect_hd         == NULL )
            || (s_ff_local_info.run.node[i].bat_hig_tmper_filter_hd == NULL )
            || (s_ff_local_info.run.node[i].over_co_sig_keeper_hd         == NULL )
            || (s_ff_local_info.run.node[i].bat_hig_tmper_keeper_hd       == NULL )
            || (s_ff_local_info.run.node[i].bat_tmper_over_rate_keeper_hd == NULL )
            )
        {
            return SF_ERR_NO_OBJECT;
        }

        bool_filter_set_val( s_ff_local_info.run.node[i].mix_sen_over_temper_hd  , BOOL_VAL_FALSE );
        bool_filter_set_val( s_ff_local_info.run.node[i].mix_sen_over_co_hd      , BOOL_VAL_FALSE );
        bool_filter_set_val( s_ff_local_info.run.node[i].temper_detect_hd        , BOOL_VAL_FALSE );
        bool_filter_set_val( s_ff_local_info.run.node[i].smoke_detect_hd         , BOOL_VAL_FALSE );
        bool_filter_set_val( s_ff_local_info.run.node[i].bat_hig_tmper_filter_hd , BOOL_VAL_FALSE );

        bool_sig_keeper_set( s_ff_local_info.run.node[i].over_co_sig_keeper_hd         , BOOL_VAL_FALSE );
        bool_sig_keeper_set( s_ff_local_info.run.node[i].bat_hig_tmper_keeper_hd       , BOOL_VAL_FALSE );
        bool_sig_keeper_set( s_ff_local_info.run.node[i].bat_tmper_over_rate_keeper_hd , BOOL_VAL_FALSE );
    }

    return SF_OK;
}

void fire_fight_local_task_loop( bat_temper_t *p_bat_temper, ff_sen_dat_info_t *p_ff_sen_dat )
{
    if ( s_ff_local_info.attr.threshold_enable == false  )
        return;
    
    _fire_fight_local_warn2_data_input( p_ff_sen_dat, p_bat_temper );
    _fire_fight_all_sig_fresh_and_handle();
    _fire_fight_local_warn2_change_check();
}

sf_ret_t fire_fight_local_set_bat_num( uint8_t num )
{
    if ( num > BAT_CLUSTER_MAX)
    {
        return SF_ERR_PARA;
    }

    s_ff_local_info.attr.node_num = num;
    
    return SF_OK;
}

sf_ret_t fire_fight_local_set_threshold( ff_threshold_set_t *p_ff_threshold_setting, uint8_t num )
{
    if ( (num > BAT_CLUSTER_MAX) || ( p_ff_threshold_setting == NULL ) )
        return SF_ERR_PARA;

    s_ff_local_info.attr.threshold        = *p_ff_threshold_setting;
    s_ff_local_info.attr.threshold_enable = true;
    s_ff_local_info.attr.node_num         = num;

    return SF_OK;
}

void fire_fight_local_set_enable( bool enable )
{
    s_ff_local_info.attr.local_enable = enable;
}

void fire_fight_local_get_warn2( ff_warn2_info_u *p_local_warn2 )
{
    p_local_warn2->bit.pack_temp_alarm1           = s_ff_local_info.run.node[0].warn2.bit.pack_temp;
    p_local_warn2->bit.pack_temp_mix_co_alarm1    = s_ff_local_info.run.node[0].warn2.bit.pack_temp_mix_co;
    p_local_warn2->bit.smoke_sen_temp_sen_alarm1  = s_ff_local_info.run.node[0].warn2.bit.temper_smoke_detect;
    p_local_warn2->bit.smoke_sen_mix_tmp1_alarm1  = s_ff_local_info.run.node[0].warn2.bit.smoke_detect_over_temper;
    p_local_warn2->bit.tmp_sen_mix_co_alarm1      = s_ff_local_info.run.node[0].warn2.bit.temper_detect_over_co;
    p_local_warn2->bit.pack_tmp_rise_co1          = s_ff_local_info.run.node[0].warn2.bit.pack_temp_rate_mix_co;

    p_local_warn2->bit.pack_temp_alarm2           = s_ff_local_info.run.node[1].warn2.bit.pack_temp;
    p_local_warn2->bit.pack_temp_mix_co_alarm2    = s_ff_local_info.run.node[1].warn2.bit.pack_temp_mix_co;
    p_local_warn2->bit.smoke_sen_temp_sen_alarm2  = s_ff_local_info.run.node[1].warn2.bit.temper_smoke_detect;
    p_local_warn2->bit.smoke_sen_mix_tmp2_alarm2  = s_ff_local_info.run.node[1].warn2.bit.smoke_detect_over_temper;
    p_local_warn2->bit.tmp_sen_mix_co_alarm2      = s_ff_local_info.run.node[1].warn2.bit.temper_detect_over_co;
    p_local_warn2->bit.pack_tmp_rise_co2          = s_ff_local_info.run.node[1].warn2.bit.pack_temp_rate_mix_co;

    p_local_warn2->bit.pack_temp_alarm3           = s_ff_local_info.run.node[2].warn2.bit.pack_temp;
    p_local_warn2->bit.pack_temp_mix_co_alarm3    = s_ff_local_info.run.node[2].warn2.bit.pack_temp_mix_co;
    p_local_warn2->bit.smoke_sen_temp_sen_alarm3  = s_ff_local_info.run.node[2].warn2.bit.temper_smoke_detect;
    p_local_warn2->bit.smoke_sen_mix_tmp3_alarm3  = s_ff_local_info.run.node[2].warn2.bit.smoke_detect_over_temper;
    p_local_warn2->bit.tmp_sen_mix_co_alarm3      = s_ff_local_info.run.node[2].warn2.bit.temper_detect_over_co;
    p_local_warn2->bit.pack_tmp_rise_co3          = s_ff_local_info.run.node[2].warn2.bit.pack_temp_rate_mix_co;

    p_local_warn2->bit.pack_temp_alarm4           = s_ff_local_info.run.node[3].warn2.bit.pack_temp;
    p_local_warn2->bit.pack_temp_mix_co_alarm4    = s_ff_local_info.run.node[3].warn2.bit.pack_temp_mix_co;
    p_local_warn2->bit.smoke_sen_temp_sen_alarm4  = s_ff_local_info.run.node[3].warn2.bit.temper_smoke_detect;
    p_local_warn2->bit.smoke_sen_mix_tmp4_alarm4  = s_ff_local_info.run.node[3].warn2.bit.smoke_detect_over_temper;
    p_local_warn2->bit.tmp_sen_mix_co_alarm4      = s_ff_local_info.run.node[3].warn2.bit.temper_detect_over_co;
    p_local_warn2->bit.pack_tmp_rise_co4          = s_ff_local_info.run.node[3].warn2.bit.pack_temp_rate_mix_co;

    p_local_warn2->bit.pack_temp_alarm5           = s_ff_local_info.run.node[4].warn2.bit.pack_temp;
    p_local_warn2->bit.pack_temp_mix_co_alarm5    = s_ff_local_info.run.node[4].warn2.bit.pack_temp_mix_co;
    p_local_warn2->bit.smoke_sen_temp_sen_alarm5  = s_ff_local_info.run.node[4].warn2.bit.temper_smoke_detect;
    p_local_warn2->bit.smoke_sen_mix_tmp5_alarm5  = s_ff_local_info.run.node[4].warn2.bit.smoke_detect_over_temper;
    p_local_warn2->bit.tmp_sen_mix_co_alarm5      = s_ff_local_info.run.node[4].warn2.bit.temper_detect_over_co;
    p_local_warn2->bit.pack_tmp_rise_co5          = s_ff_local_info.run.node[4].warn2.bit.pack_temp_rate_mix_co;

    p_local_warn2->bit.pack_temp_alarm6           = s_ff_local_info.run.node[5].warn2.bit.pack_temp;
    p_local_warn2->bit.pack_temp_mix_co_alarm6    = s_ff_local_info.run.node[5].warn2.bit.pack_temp_mix_co;
    p_local_warn2->bit.smoke_sen_temp_sen_alarm6  = s_ff_local_info.run.node[5].warn2.bit.temper_smoke_detect;
    p_local_warn2->bit.smoke_sen_mix_tmp6_alarm6  = s_ff_local_info.run.node[5].warn2.bit.smoke_detect_over_temper;
    p_local_warn2->bit.tmp_sen_mix_co_alarm6      = s_ff_local_info.run.node[5].warn2.bit.temper_detect_over_co;
    p_local_warn2->bit.pack_tmp_rise_co6          = s_ff_local_info.run.node[5].warn2.bit.pack_temp_rate_mix_co;
}
/**
 * @brief  获取本地消防 DI状态
 * @param  [in] p_local_di_sta： 本地消防 DI状态
 * @return 无
 * @note   
 */
void fire_fight_local_get_di_sta( ff_di_sta_info_u *p_local_di_sta )
{
    if ( s_ff_local_info.attr.local_enable == false )
    {
        p_local_di_sta->value = 0;
        return ;
    }

    p_local_di_sta->bit.temp_sensor1  = (s_ff_local_info.run.node[0].temper_detect == BOOL_VAL_TRUE)? 1: 0;
    p_local_di_sta->bit.smoke_sensor1 = (s_ff_local_info.run.node[0].smoke_detect  == BOOL_VAL_TRUE)? 1: 0;

    p_local_di_sta->bit.temp_sensor2  = (s_ff_local_info.run.node[1].temper_detect == BOOL_VAL_TRUE)? 1: 0;
    p_local_di_sta->bit.smoke_sensor2 = (s_ff_local_info.run.node[1].smoke_detect  == BOOL_VAL_TRUE)? 1: 0;

    p_local_di_sta->bit.temp_sensor3  = (s_ff_local_info.run.node[2].temper_detect == BOOL_VAL_TRUE)? 1: 0;
    p_local_di_sta->bit.smoke_sensor3 = (s_ff_local_info.run.node[2].smoke_detect  == BOOL_VAL_TRUE)? 1: 0;

    p_local_di_sta->bit.temp_sensor4  = (s_ff_local_info.run.node[3].temper_detect == BOOL_VAL_TRUE)? 1: 0;
    p_local_di_sta->bit.smoke_sensor4 = (s_ff_local_info.run.node[3].smoke_detect  == BOOL_VAL_TRUE)? 1: 0;

    p_local_di_sta->bit.temp_sensor5  = (s_ff_local_info.run.node[4].temper_detect == BOOL_VAL_TRUE)? 1: 0;
    p_local_di_sta->bit.smoke_sensor5 = (s_ff_local_info.run.node[4].smoke_detect  == BOOL_VAL_TRUE)? 1: 0;

    p_local_di_sta->bit.temp_sensor6  = (s_ff_local_info.run.node[5].temper_detect == BOOL_VAL_TRUE)? 1: 0;
    p_local_di_sta->bit.smoke_sensor6 = (s_ff_local_info.run.node[5].smoke_detect  == BOOL_VAL_TRUE)? 1: 0;
}

static void _fire_fight_local_warn2_change_check( void )
{
    static local_warn2_u devs_local_warn2[ BAT_CLUSTER_MAX ] = {{.value = 0}};
    bool warn2_event_change = false;

    for (size_t i = 0; i < s_ff_local_info.attr.node_num; i++)
    {
        if ( s_ff_local_info.run.node[i].warn2.value != devs_local_warn2[i].value )
        {
            devs_local_warn2[i].value = s_ff_local_info.run.node[i].warn2.value;
            warn2_event_change = true;
        }
    }

    if ( warn2_event_change )
    {
        s_ff_local_info.attr.local_warn_change_cb();
    }
}

static void _fire_fight_all_sig_fresh_and_handle( void )
{ 
     for ( size_t i = 0; i < s_ff_local_info.attr.node_num; i++ )
    {
        bool_val_e smoke_detect_filter      = bool_filter_get_val( s_ff_local_info.run.node[i].smoke_detect_hd );
        bool_val_e tmper_detect_filter      = bool_filter_get_val( s_ff_local_info.run.node[i].temper_detect_hd );
        bool_val_e mix_over_tmper_filter    = bool_filter_get_val( s_ff_local_info.run.node[i].mix_sen_over_temper_hd );
        bool_val_e mix_over_co_keep         = bool_sig_keeper_get( s_ff_local_info.run.node[i].over_co_sig_keeper_hd );
        bool_val_e bat_hig_tmper_keep       = bool_sig_keeper_get( s_ff_local_info.run.node[i].bat_hig_tmper_keeper_hd );
        bool_val_e bat_tmper_over_rate_keep = bool_sig_keeper_get( s_ff_local_info.run.node[i].bat_tmper_over_rate_keeper_hd );
        
        if ( s_ff_local_info.run.node[i].smoke_detect != smoke_detect_filter ) 
        {
            s_ff_local_info.run.node[i].smoke_detect = smoke_detect_filter;
            sdk_log_d( "\r\n[%d] smoke_detect: %02X", i, smoke_detect_filter );
        }
        if ( s_ff_local_info.run.node[i].temper_detect !=  tmper_detect_filter ) 
        {
            s_ff_local_info.run.node[i].temper_detect = tmper_detect_filter;
            sdk_log_d( "\r\n[%d] temper_detect: %02X", i, tmper_detect_filter );
        }
        if ( s_ff_local_info.run.node[i].mix_sen_over_co != mix_over_co_keep ) 
        {
            s_ff_local_info.run.node[i].mix_sen_over_co = mix_over_co_keep;
            sdk_log_d( "\r\n[%d] mix_sen_over_co: %02X", i, mix_over_co_keep );
        }
        if ( s_ff_local_info.run.node[i].mix_sen_over_temper != mix_over_tmper_filter ) 
        {
            s_ff_local_info.run.node[i].mix_sen_over_temper = mix_over_tmper_filter;
            sdk_log_d( "\r\n[%d] mix_sen_over_temper: %02X", i, mix_over_tmper_filter );
        }
        if ( s_ff_local_info.run.node[i].bat_hig_tmper != bat_hig_tmper_keep ) 
        {
            s_ff_local_info.run.node[i].bat_hig_tmper = bat_hig_tmper_keep;
            sdk_log_d( "\r\n[%d] bat_hig_tmper: %02X", i, bat_hig_tmper_keep );
        }
        if ( s_ff_local_info.run.node[i].bat_tmper_over_rate != bat_tmper_over_rate_keep ) 
        {
            s_ff_local_info.run.node[i].bat_tmper_over_rate = bat_tmper_over_rate_keep;
            sdk_log_d( "\r\n[%d] bat_tmper_over_rate: %02X", i, bat_tmper_over_rate_keep );
        }

        /* 即使本地功能关闭也必须实现的功能【原因：旧消防控制器没有这个功能】*/
        /* 电池高温 + 电池温升速率 */
        if (   ( s_ff_local_info.run.node[i].warn2.bit.pack_temp == 0 )
            && ( s_ff_local_info.run.node[i].bat_hig_tmper       == BOOL_VAL_TRUE )
            && ( s_ff_local_info.run.node[i].bat_tmper_over_rate == BOOL_VAL_TRUE ))
        {
            s_ff_local_info.run.node[i].warn2.bit.pack_temp = 1;
        }

        if ( s_ff_local_info.attr.local_enable == SF_TRUE )
        {
            /* 兜底消防功能 */
            /* 烟感 + 温感 */
            if (   ( s_ff_local_info.run.node[i].warn2.bit.temper_smoke_detect == 0 )
                && ( s_ff_local_info.run.node[i].smoke_detect  == BOOL_VAL_TRUE )
                && ( s_ff_local_info.run.node[i].temper_detect == BOOL_VAL_TRUE ))
            {
                s_ff_local_info.run.node[i].warn2.bit.temper_smoke_detect = 1;
            }

            /* 烟感 + 复合超温 */
            if (   ( s_ff_local_info.run.node[i].warn2.bit.smoke_detect_over_temper == 0 )
                && ( s_ff_local_info.run.node[i].smoke_detect        == BOOL_VAL_TRUE )
                && ( s_ff_local_info.run.node[i].mix_sen_over_temper == BOOL_VAL_TRUE ))
            {
                s_ff_local_info.run.node[i].warn2.bit.smoke_detect_over_temper = 1;
            }
            
            /* 温感 + 复合CO超阈值 */
            if (   ( s_ff_local_info.run.node[i].warn2.bit.temper_detect_over_co == 0 )
                && ( s_ff_local_info.run.node[i].temper_detect   == BOOL_VAL_TRUE )
                && ( s_ff_local_info.run.node[i].mix_sen_over_co == BOOL_VAL_TRUE ))
            {
                s_ff_local_info.run.node[i].warn2.bit.temper_detect_over_co = 1;
            }
            /* 电池高温 + 复合CO超阈值 */
            if (   ( s_ff_local_info.run.node[i].warn2.bit.pack_temp_mix_co == 0 )
                && ( s_ff_local_info.run.node[i].bat_hig_tmper   == BOOL_VAL_TRUE )
                && ( s_ff_local_info.run.node[i].mix_sen_over_co == BOOL_VAL_TRUE ))
            {
                s_ff_local_info.run.node[i].warn2.bit.pack_temp_mix_co = 1;
            }
            /* 电池温升速率 + 复合CO超阈值 */
            if (   ( s_ff_local_info.run.node[i].warn2.bit.pack_temp_rate_mix_co == 0 )
                && ( s_ff_local_info.run.node[i].bat_tmper_over_rate == BOOL_VAL_TRUE )
                && ( s_ff_local_info.run.node[i].mix_sen_over_co     == BOOL_VAL_TRUE ))
            {
                s_ff_local_info.run.node[i].warn2.bit.pack_temp_rate_mix_co = 1;
            }
        }
    }
}

static void _fire_fight_local_warn2_data_input( ff_sen_dat_info_t *p_ff_sen_dat, bat_temper_t *p_curr_bat_temper_list )
{
    for (size_t idx = 0; idx < s_ff_local_info.attr.node_num; idx++)
    {
        bool       smoke_detect_raw    = ( extern_io_get_input_lv( idx, EXT_IO_DI_SMOKE_SEN_PORT ) == IO_STA_HIG);
        bool_filter_input( s_ff_local_info.run.node[idx].smoke_detect_hd,        (bool_val_e)smoke_detect_raw) ;
        
        bool       tmper_detect_raw    = ( extern_io_get_input_lv( idx, EXT_IO_DI_TMPER_SEN_PORT ) == IO_STA_HIG);
        bool_filter_input( s_ff_local_info.run.node[idx].temper_detect_hd,       (bool_val_e)tmper_detect_raw ) ;

        bool       over_co_raw         = ( p_ff_sen_dat->mix_sen[idx].mix_sen_co >= s_ff_local_info.attr.threshold.ff_alarm_level2_compart_co );
        bool_val_e over_co_filter      = bool_filter_input( s_ff_local_info.run.node[idx].mix_sen_over_co_hd,  (bool_val_e)over_co_raw);
        bool_sig_keeper_input( s_ff_local_info.run.node[idx].over_co_sig_keeper_hd,  over_co_filter );

        bool       over_tmper_raw      = ( p_ff_sen_dat->mix_sen[idx].mix_sen_temp >= (s_ff_local_info.attr.threshold.ff_alarm_level2_compart_temp * 10) );
        bool_filter_input( s_ff_local_info.run.node[idx].mix_sen_over_temper_hd, (bool_val_e)over_tmper_raw);

        if ( p_curr_bat_temper_list[idx].valid == SF_TRUE )
        {
            bool       bat_hig_tmper_raw = (  ( p_curr_bat_temper_list[idx].max_temper1 >= s_ff_local_info.attr.threshold.ff_alarm_level2_pack_temp )
                                        && ( p_curr_bat_temper_list[idx].max_temper2 >= s_ff_local_info.attr.threshold.ff_alarm_level2_pack_temp1 ));
            bool_val_e bat_hig_tmper_filter = bool_filter_input(     s_ff_local_info.run.node[idx].bat_hig_tmper_filter_hd, (bool_val_e)bat_hig_tmper_raw );
            bool_sig_keeper_input( s_ff_local_info.run.node[idx].bat_hig_tmper_keeper_hd, bat_hig_tmper_filter );
        }
    }
    /* 温升速率单独处理，涉及时间控制 */
    _fire_fight_bat_temper_over_rate_check( p_curr_bat_temper_list );
}

static void _fire_fight_max_temper_record( int16_t curr_max_tmper, temper_record_t *p_temper_record )
{
    uint8_t record_index; 

    record_index = p_temper_record->start_idx + p_temper_record->valid_cnt;
    if ( record_index >= ARRAY_SIZE( p_temper_record->max_tmp ) )
    {
        /* 环形数组存储数据 */
        record_index -= ARRAY_SIZE( p_temper_record->max_tmp );
    }

    p_temper_record->max_tmp[ record_index ] = curr_max_tmper;
    if ( p_temper_record->valid_cnt < ARRAY_SIZE( p_temper_record->max_tmp ) )
    {
        /* 现有 有效数据 小于 缓存个数 */
        p_temper_record->valid_cnt++;
    }else{
        /* 现有 有效数据 大于等于 缓存个数 */
        p_temper_record->start_idx++;
        if ( p_temper_record->start_idx >= ARRAY_SIZE( p_temper_record->max_tmp ) )
        {
            p_temper_record->start_idx -= ARRAY_SIZE( p_temper_record->max_tmp );
        }
    } 
}

/**
 * @brief  输入电池温度，并返回温升速率状态，保持20s调用一次
 * @param  [in] idx               :  
 * @param  [in] p_curr_bat_temper :  
 * @return 
 * @note   
 */
static bool _fire_fight_input_bat_temper_and_ret_over_rate_sta( uint8_t idx, bat_temper_t *p_curr_bat_temper )
{
    static temper_over_rate_t  temper_over_rate[ BAT_CLUSTER_MAX ] = {{0,0,0}};

    temper_record_t    *p_temper_record    = &temper_over_rate[ idx ].temper_record;
    temper_over_rate_t *p_temper_over_rate = &temper_over_rate[ idx ];
    
    /* 开始记录并判断温升速率 */
    _fire_fight_max_temper_record( p_curr_bat_temper->max_temper1, p_temper_record );
    if ( p_temper_record->valid_cnt < ARRAY_SIZE( p_temper_record->max_tmp ) )
    {
        /* 数据不足，不足以判断，继续记录 */
        return p_temper_over_rate->over_rate_sta;
    }

    /* 数据足够，开始做判断 */
    /* 判断60s前的温度是否超温 */
    if ( (p_curr_bat_temper->max_temper1 - p_temper_record->max_tmp[ p_temper_record->start_idx ]) >= 6  )
    {
        /* 最高电芯温升速率≥6℃，清空数据，并记录本次温度 */
        memset( p_temper_record, 0, sizeof( temper_record_t ) ) ;
        p_temper_over_rate->over_rate_cnt++;
        _fire_fight_max_temper_record( p_curr_bat_temper->max_temper1, p_temper_record );
        sdk_log_d( "[%d] over_rate_cnt: %d\r\n", idx, p_temper_over_rate->over_rate_cnt );
    } else {
        /* 没超温 */
        p_temper_over_rate->over_rate_cnt = 0;
        if ( p_temper_over_rate->over_rate_sta == SF_TRUE )
        {
            p_temper_over_rate->over_rate_sta = SF_FALSE;
            sdk_log_d( "[%d] over_rate_sta: %d\r\n", idx, p_temper_over_rate->over_rate_sta );
        }
    }

    if ( p_temper_over_rate->over_rate_cnt >= TEMPER_OVER_RATE_VALID_CNT )
    {
        if ( p_temper_over_rate->over_rate_sta == SF_FALSE )
        {
            p_temper_over_rate->over_rate_sta = SF_TRUE;
            sdk_log_d( "[%d] over_rate_sta: %d\r\n", idx, p_temper_over_rate->over_rate_sta );
        }
    }

    return p_temper_over_rate->over_rate_sta;
}

static void _fire_fight_bat_temper_over_rate_check( bat_temper_t *p_curr_bat_temper_list )
{
    static tick_timer_handle_t check_timer = NULL;
    
    if ( check_timer == NULL )
    {
        check_timer = tick_timer_create();
        if ( check_timer == NULL )
        {
            sdk_log_e( "create check temper over rate timer error!!!" );
            return;
        }
    }

    /* 20s 检查一次 */
    if( tick_timer_is_timeout( check_timer ) == 0 )
    {
        return;
    }
    tick_timer_set_timeout( check_timer, TMPER_OVER_RETE_CHECK_INV_TM_MS );

    // sdk_log_d( "%s", __FUNCTION__ );

    /* 输入电池温度数据，获取温升是否过快 */
    for (size_t idx = 0; idx < s_ff_local_info.attr.node_num ; idx++ )
    {
        if ( p_curr_bat_temper_list[idx].valid == SF_FALSE )
        {
            continue;
        }

        sig_keeper_hd *p_sig_keeper_hd = s_ff_local_info.run.node[idx].bat_tmper_over_rate_keeper_hd;
        bool           over_rate_sta   = _fire_fight_input_bat_temper_and_ret_over_rate_sta( idx, &p_curr_bat_temper_list[idx] );
        bool_sig_keeper_input( p_sig_keeper_hd , (bool_val_e)over_rate_sta );
    }
}
