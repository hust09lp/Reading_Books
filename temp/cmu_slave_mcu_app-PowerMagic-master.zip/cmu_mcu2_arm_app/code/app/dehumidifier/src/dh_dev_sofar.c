#include "dh_dat_type.h"
#include "app_modbus.h"

#include "sdk.h"
#include "sdk_core.h"

/*---------------------------寄存器地址------------------------------------*/
#define MB_REG_ADDR_RT_DAT_INFO                 0x0001          //< 实时数据

#define MB_REG_ADDR_DEV_COM_INFO                0x0100          //< 设备信息 / 通讯信息

#define MB_REG_ADDR_SET_MODE_CTRL               0x0200          //< 除湿-控制方式
#define MB_REG_ADDR_SET_HUMIDITY                0x0201          //< 除湿-湿度设定, 单位 ：1%RH
#define MB_REG_ADDR_SET_HUMIDITY_HYSTERSIS      0x0202          //< 除湿-湿度回差, 单位 ：1%RH
#define MB_REG_ADDR_SET_REMOTE_SET_STA          0x0203          //< 除湿-远程启停控制位

typedef struct 
{
    uint16_t env_humi;                          //< 环境湿度，单位：1%
    temper_t env_temper;                        //< 环境温度，单位：0.1℃
    temper_t inside_temper;                     //< 内部温度，单位：0.1℃
    temper_t cooler_temper;                     //< 制冷片温度，单位：0.1℃
    uint16_t reserve[11];                       //< 预留
    union {
        uint16_t val;
        struct {
            uint16_t dehumi_sta    :1;          //< 除湿状态（实际）
            uint16_t wk_tmout_prot :1;          //< 工作超时保护
        } bit;
    } logic_sta;                                //< 逻辑状态

    union {
        uint16_t val;
        struct {
            uint16_t fan    :1;                 //< 风机启停状态
            uint16_t cooler :1;                 //< 制冷块启停状态
            uint16_t ptc    :1;                 //< 加热输出
        } bit;
    } component_sta;                            //< 器件状态

    union {
        uint16_t val;
        struct {
            uint16_t over_wet        :1;        //< 超湿报警
            uint16_t hig_temperature :1;        //< 超温报警
        } bit;
    } warning;                                  //< 报警

    union {
        uint16_t val;
        struct {
            uint16_t fan_fault    :1;           //< 风机故障
            uint16_t cooler_fault :1;           //< 制冷块故障
            uint16_t sensor_fault :1;           //< 传感器故障
        } bit;
    } fault;                                    //< 故障
} rt_dat_t;
/*------------------------------------------------------------*/

static modbus_idx_t s_modbus_idx = MODBUS_IDX_INVALID;

sf_ret_t dh_dev_sofar_init( modbus_idx_t modbus_idx )
{
    if ( modbus_idx == MODBUS_IDX_INVALID )
        return SF_ERR_NDEF;

    s_modbus_idx = modbus_idx;
    return SF_OK;
}

sf_ret_t dh_dev_sofar_get_dat( uint8_t mb_slave_addr, dehumi_dat_t *p_dehumi_dat )
{
    static rt_dat_t rt_dat;
    int ret;

    if ( s_modbus_idx == MODBUS_IDX_INVALID )
        return SF_ERR_NDEF;

    memset( &rt_dat, 0 , sizeof( rt_dat_t ));
    ret = app_modbus_registers_read( s_modbus_idx, mb_slave_addr, MB_REG_ADDR_RT_DAT_INFO, sizeof( rt_dat_t ) / 2, (uint16_t*)&rt_dat, 40 );
    if ( ret < 0 )
    {
        return SF_ERR_RD;
    }

    p_dehumi_dat->env_humi   = rt_dat.env_humi;
    p_dehumi_dat->env_temper = rt_dat.env_temper;
    p_dehumi_dat->status     = rt_dat.logic_sta.bit.dehumi_sta;

    return SF_OK;
}

sf_ret_t dh_dev_sofar_set_auto_param( uint8_t mb_slave_addr, humi_t dehumi_threshold, humi_t dehumi_ret )
{
    int ret; 

    if ( s_modbus_idx == MODBUS_IDX_INVALID )
        return SF_ERR_NDEF;

    // ret = app_modbus_register_write( s_modbus_idx, mb_slave_addr, MB_REG_ADDR_SET_HUMIDITY, dehumi_threshold );
    // if ( ret < 0 )
    // {
    //     return SF_ERR_WR;
    // }

    // ret = app_modbus_register_write( s_modbus_idx, mb_slave_addr, MB_REG_ADDR_SET_HUMIDITY_HYSTERSIS, dehumi_ret );
    // if ( ret < 0 )
    // {
    //     return SF_ERR_WR;
    // }

    return SF_OK;
}

sf_ret_t dh_dev_sofar_set_dehumi_sta( uint8_t mb_slave_addr, bool dehumi_sta )
{
    if ( s_modbus_idx == MODBUS_IDX_INVALID )
        return SF_ERR_NDEF;

    int ret = app_modbus_register_write( s_modbus_idx, mb_slave_addr, MB_REG_ADDR_SET_REMOTE_SET_STA, dehumi_sta? 1: 0, 50 );
    if ( ret < 0 )
    {
        return SF_ERR_WR;
    }

    return SF_OK;
}

sf_ret_t dh_dev_sofar_set_mode( uint8_t mb_slave_addr, dh_ctrl_mode_e mode )
{
    uint16_t mode_u16 = mode;

    if ( s_modbus_idx == MODBUS_IDX_INVALID )
    {
        return SF_ERR_NDEF;
    }
    
    if ( mode >= DH_CTRL_MODE_MAX )
    {
        return SF_ERR_PARA;
    }

    int ret = app_modbus_register_write( s_modbus_idx, mb_slave_addr, MB_REG_ADDR_SET_MODE_CTRL, mode_u16, 50 );
    if ( ret < 0 )
    {
        return SF_ERR_WR;
    }

    return SF_OK;
}
