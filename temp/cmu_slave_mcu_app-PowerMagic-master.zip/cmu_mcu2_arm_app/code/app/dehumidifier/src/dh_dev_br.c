#include "dh_dat_type.h"
#include "app_modbus.h"

#include "sdk.h"
#include "sdk_core.h"

/*---------------------------寄存器地址------------------------------------*/
#define MB_REG_ADDR_RW_SETTING_WORK_MODE           0x01        //< 工作模式 【0:降温型 1:升温型】
#define MB_REG_ADDR_RW_SETTING_TMPER               0x02        //< 温度设定，单位：1℃
#define MB_REG_ADDR_RW_SETTING_TMPER_RET           0x03        //< 温度回差，单位：1℃
#define MB_REG_ADDR_RW_SETTING_HUMI                0x04        //< 湿度设定，单位：1RH%
#define MB_REG_ADDR_RW_SETTING_HUMI_RET            0x05        //< 湿度回差，单位：1RH%

#define MB_REG_ADDR_R_RT_DAT                       0x0B        //< 实时数据

#define MB_REG_ADDR_R_DRYING_STA                   0x0B        //< 当前除湿状态 【1:运行 0:停止】
#define MB_REG_ADDR_R_TMPER                        0x0C        //< 当前温度，单位：1℃
#define MB_REG_ADDR_R_HUMI                         0x0D        //< 当前湿度，单位：1RH%
#define MB_REG_ADDR_R_WARN                         0x0E        //< 报警状态 【1：有报警 0：无报警】

typedef struct {
    uint16_t    dehumi_sta;                     //< 除湿状态 
    uint16_t    env_temper;                     //< 温度 ， 单位：0.1℃
    uint16_t    env_humi;                       //< 湿度 ， 单位：0.1RH%
    uint16_t    warning;                        //< 报警状态       
} rt_dat_t;
/*------------------------------------------------------------*/

static modbus_idx_t s_modbus_idx = MODBUS_IDX_INVALID;

sf_ret_t dh_dev_br_init( modbus_idx_t modbus_idx )
{
    if ( modbus_idx == MODBUS_IDX_INVALID )
        return SF_ERR_NDEF;

    s_modbus_idx = modbus_idx;
    return SF_OK;
}

sf_ret_t dh_dev_br_get_dat( uint8_t mb_slave_addr, dehumi_dat_t *p_dehumi_dat )
{
    static rt_dat_t rt_dat;
    int ret;

    if ( s_modbus_idx == MODBUS_IDX_INVALID )
        return SF_ERR_NDEF;

    memset( &rt_dat, 0 , sizeof( rt_dat_t ));
    ret = app_modbus_registers_read( s_modbus_idx, mb_slave_addr, MB_REG_ADDR_R_RT_DAT, sizeof( rt_dat_t ) / 2, (uint16_t*)&rt_dat, 40 );
    if ( ret < 0 )
    {
        return SF_ERR_RD;
    }

    p_dehumi_dat->env_humi   = rt_dat.env_humi / 10;
    p_dehumi_dat->env_temper = rt_dat.env_temper;
    p_dehumi_dat->status     = rt_dat.dehumi_sta;

    if ( (p_dehumi_dat->env_temper <= 50 ) || ( p_dehumi_dat->env_temper >= 600) )
    {
        sdk_log_e( "BR env temper:%d error!!!", p_dehumi_dat->env_temper );
    }

    return SF_OK;
}

sf_ret_t dh_dev_br_set_auto_param( uint8_t mb_slave_addr, humi_t dehumi_threshold, humi_t dehumi_ret )
{
    int ret; 

    if ( s_modbus_idx == MODBUS_IDX_INVALID )
        return SF_ERR_NDEF;

    ret = app_modbus_register_write( s_modbus_idx, mb_slave_addr, MB_REG_ADDR_RW_SETTING_HUMI, dehumi_threshold, 20 );
    if ( ret < 0 )
    {
        return SF_ERR_WR;
    }

    ret = app_modbus_register_write( s_modbus_idx, mb_slave_addr, MB_REG_ADDR_RW_SETTING_HUMI_RET, dehumi_ret, 20 );
    if ( ret < 0 )
    {
        return SF_ERR_WR;
    }

    return SF_OK;
}

sf_ret_t dh_dev_br_set_dehumi_sta( uint8_t mb_slave_addr, bool dehumi_sta )
{
    if ( s_modbus_idx == MODBUS_IDX_INVALID )
        return SF_ERR_NDEF;

    /* 不支持直接控制除湿状态 */
    return SF_ERR_FNOSUPP;
}

sf_ret_t dh_dev_br_set_mode( uint8_t mb_slave_addr, dh_ctrl_mode_e mode )
{
    if ( s_modbus_idx == MODBUS_IDX_INVALID )
    {
        return SF_ERR_NDEF;
    }
    
    /* 不支持 除湿模式设置 */
    return SF_ERR_FNOSUPP;
}
