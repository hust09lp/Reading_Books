#include "dh_ctrl.h"
#include "tick_timer.h"
#include "app_modbus.h"
#include "dh_dev_br.h"
#include "dh_dev_sofar.h"

#include "sdk.h"
#include "sdk_core.h"

#define DH_CTRL_TMP_DEBUG                   0

#if (0)
#define DEHUMI_VERBOSE( format, ... )    do { sdk_log_d( format, ##__VA_ARGS__ ); } while(0)
#else
#define DEHUMI_VERBOSE( format, ... )    do {} while(0)
#endif

#if (1)
    #define DEHUMI_DEBUG( format, ... )  do { sdk_log_d( format, ##__VA_ARGS__ ); } while(0)
    #define DEHUMI_WARN( format, ... )   do { sdk_log_w( format, ##__VA_ARGS__ ); } while(0)
    #define DEHUMI_ERROR( format, ... )  do { sdk_log_e( format, ##__VA_ARGS__ ); } while(0)
#else
    #define DEHUMI_DEBUG( format, ... )  do {} while(0)
    #define DEHUMI_ERROR( format, ... )  do {} while(0)
#endif

#define DEHUMI_DEV_MAX_NUM                  6               //< 最大除湿器个数

/*------------------------------------modbus 信息---------------------------------------------*/
#define DEHUMI_DEV_0_MB_SLAVE_ADDR          8               //< 第0个除湿器 modbus 从机地址
#define DH_MB_SLAVE_ADDR( index )           ( DEHUMI_DEV_0_MB_SLAVE_ADDR + index )
#define SET_OP_RETRY_CNT                    3
#define READ_FAIL_MAX_CNT                   6               //< 最大读取失败次数，超过次数则切为离线状态

#define MB_REG_ADDR_SOFAR_FLAG              0x0104          //< 首航标识符寄存器地址

/*------------------------------------设备类型探测设置---------------------------------------------*/
#define DH_TYPE_FAST_DETECT_CNT             10              //< 快速探测次数
#define DH_TYPE_FAST_DETECT_INV_TM_MS       6000            //< 快速探时间间隔
#define DH_TYPE_SLOW_DETECT_INV_TM_MS       60000           //< 慢速探时间间隔

/*------------------------------------设备类型探测设置---------------------------------------------*/
#define TRIG_DEHUMI_THRESHOLD               80              //< 触发除湿阈值
#define STOP_DEHUMI_THRESHOLD               70              //< 停止除湿阈值
#define TRIG_OBJ_TMP_DEWPOINT_DIFF_VAL      20              //< 触发除湿 物体温度 与 凝露值 差值，单位 0.1℃
#define STOP_OBJ_TMP_DEWPOINT_DIFF_VAL      5               //< 停止除湿 物体温度 与 凝露值 差值，单位 0.1℃

#define DEV_INFO_RD_INV_TM_MS               5000           //< 读取除湿器信息时间间隔，单位：1ms
#define DEHUMI_ONCE_WK_TM_MIN               10              //< 单次除湿时间，单位：1min
#define DEHUMI_WORK_NUM                     2               //< 同一时间支持最大除湿个数

/*----------------------------------接口-------------------------------------*/
typedef enum
{
    DEHUMI_TYPE_BR = 0,                                     //< 保瑞除湿器
    DEHUMI_TYPE_SOFAR_COMM = 1,                             //< 首航通用除湿器
    DEHUMI_TYPE_MAX,                                        //< 首航通用除湿器
    DEHUMI_TYPE_UNKNOW = 0xff,                              //< 未知设备
} dehumi_type_e;

typedef struct 
{
    sf_ret_t (*f_dh_ctrl_init_cb)( modbus_idx_t modbus_idx );
    sf_ret_t (*f_dh_ctrl_get_dat_cb)( uint8_t mb_slave_addr, dehumi_dat_t *p_dehumi_dat );
    sf_ret_t (*f_dh_ctrl_set_auto_param_cb)( uint8_t mb_slave_addr, humi_t dehumi_threshold, humi_t dehumi_ret );
    sf_ret_t (*f_dh_ctrl_set_dehumi_sta_cb)( uint8_t mb_slave_addr, bool dehumi_sta );
    sf_ret_t (*f_dh_ctrl_set_mode_cb)( uint8_t mb_slave_addr, dh_ctrl_mode_e mode );
} dh_dev_op_t;

/*--------------------------------------------------------------------------*/
typedef struct 
{
    bool            valid;                          //< 是否有效
    bool            running;                        //< 是否正在运行
    bool            online;                         //< 在线状态
    bool            logic_status;                   //< 除湿逻辑状态

    uint8_t         msg_fail_cnt;                   //< 消息失败次数

    uint32_t        total_fail_cnt;                 //< 总消息失败次数
    uint32_t        total_msg_cnt;                  //< 总消息次数
    rate_t          com_loss_rate;                  //< 通讯丢包率

    dehumi_dat_t    dat;                            //< 除湿器数据
} dehumi_dev_t;

typedef struct 
{
    struct 
    {
        modbus_idx_t modbus_idx;
        uint8_t      dev_num;                   //< 当前系统设备个数
    } attr;

    struct 
    {
        bool                obj_temper_valid;
        temper_t            obj_temper;

        dehumi_type_e       type;                       //< 
        tick_timer_handle_t wk_timer;                   //< 
        tick_timer_handle_t rd_timer;                   //< 
        dehumi_dev_t        dev[ DEHUMI_DEV_MAX_NUM ];
    } run;
} dehumi_info_t;

static dehumi_info_t s_dehumi_info;

static void _dehumi_ctrl_type_confirm_init( void );
static void _dehumi_ctrl_read_looping( void );
static void _dehumi_ctrl_work_ctrl_looping( void );
static void _dehumi_sta_change_print( void );
static temper_t _dehumi_ctrl_cal_dewPoint( temper_t temper, humi_t humi );

static dh_dev_op_t s_dh_dev_op[] = 
{
    [ DEHUMI_TYPE_BR ] = {
        .f_dh_ctrl_init_cb           = dh_dev_br_init ,
        .f_dh_ctrl_get_dat_cb        = dh_dev_br_get_dat,
        .f_dh_ctrl_set_auto_param_cb = dh_dev_br_set_auto_param,
        .f_dh_ctrl_set_dehumi_sta_cb = dh_dev_br_set_dehumi_sta,
        .f_dh_ctrl_set_mode_cb       = dh_dev_br_set_mode,
    },

    [ DEHUMI_TYPE_SOFAR_COMM ] = {
        .f_dh_ctrl_init_cb           = dh_dev_sofar_init,
        .f_dh_ctrl_get_dat_cb        = dh_dev_sofar_get_dat,
        .f_dh_ctrl_set_auto_param_cb = dh_dev_sofar_set_auto_param,
        .f_dh_ctrl_set_dehumi_sta_cb = dh_dev_sofar_set_dehumi_sta,
        .f_dh_ctrl_set_mode_cb       = dh_dev_sofar_set_mode,
    },
};

sf_ret_t dehumi_ctrl_init( modbus_idx_t modbus_idx )
{
    memset( &s_dehumi_info, 0, sizeof( s_dehumi_info ) );

    s_dehumi_info.run.type = DEHUMI_TYPE_UNKNOW;
    s_dehumi_info.attr.modbus_idx = modbus_idx;
    s_dehumi_info.attr.dev_num    = 1;

    s_dehumi_info.run.rd_timer = tick_timer_create();
    s_dehumi_info.run.wk_timer = tick_timer_create();

    if ( (s_dehumi_info.run.rd_timer == NULL)
      || (s_dehumi_info.run.wk_timer == NULL) )
    {
        sdk_log_e("%s", __FUNCTION__);
        return SF_ERR_NO_OBJECT;
    }

    tick_timer_set_timeout( s_dehumi_info.run.rd_timer, DEV_INFO_RD_INV_TM_MS );

    #if ( DH_CTRL_TMP_DEBUG == 1 )
    tick_timer_set_timeout( s_dehumi_info.run.wk_timer, DEHUMI_ONCE_WK_TM_MIN * 1000 * 3 );
    #else
    tick_timer_set_timeout( s_dehumi_info.run.wk_timer, DEHUMI_ONCE_WK_TM_MIN * 1000 * 60 );
    #endif

    return SF_OK;
}

sf_ret_t dehumi_ctrl_set_num( uint8_t dev_num )
{
    if ( dev_num > DEHUMI_DEV_MAX_NUM )
        return SF_ERR_PARA;

    s_dehumi_info.attr.dev_num = dev_num;

    for (size_t i = 0; i < dev_num; i++)
    {
        if ( s_dehumi_info.run.dev[i].valid == false )
        {
            /* 未使用位置 */
            memset( &s_dehumi_info.run.dev[i] , 0, sizeof( dehumi_dev_t ) );

            s_dehumi_info.run.dev[i].valid   = true;
            s_dehumi_info.run.dev[i].online  = true;
            s_dehumi_info.run.dev[i].running = true;
        }
    }

    return SF_OK;
}

sf_ret_t dehumi_ctrl_set_auto_mode_param( humi_t dehumi_threshold, humi_t dehumi_ret )
{
    dehumi_type_e dh_type = s_dehumi_info.run.type;

    if ( dh_type >= DEHUMI_TYPE_MAX )
        return SF_ERR_NDEF;

    for (size_t i = 0; i < s_dehumi_info.attr.dev_num; i++)
    {
        /* 存在离线，返回失败 */
        if ( s_dehumi_info.run.dev[i].online == false )
        {
            return SF_ERR_WR;
        }
    }

    for (size_t i = 0; i < s_dehumi_info.attr.dev_num; i++)
    {
        if ( s_dh_dev_op[ dh_type ].f_dh_ctrl_set_auto_param_cb != NULL )
        {
            if ( SF_OK != s_dh_dev_op[ dh_type ].f_dh_ctrl_set_auto_param_cb( DH_MB_SLAVE_ADDR(i), dehumi_threshold, dehumi_ret ) )
            {
                return SF_ERR_WR;
            }
        }
    }

    return SF_OK;
}

void dehumi_ctrl_input_obj_temper( temper_t obj_temper )
{
    s_dehumi_info.run.obj_temper_valid = true; 
    s_dehumi_info.run.obj_temper       = obj_temper;
}

sf_ret_t dehumi_ctrl_op( uint8_t dev_index, dev_op_e op )
{
    dehumi_dev_t *p_dh_dev = &s_dehumi_info.run.dev[ dev_index ];
    dehumi_type_e dh_type = s_dehumi_info.run.type;

    if ( (dev_index >= s_dehumi_info.attr.dev_num)
      || ( op >= DEV_OP_MAX ) )
    {
        return SF_ERR_PARA;
    }

    if ( op == DEV_OP_RESUME )
    {
        p_dh_dev->running      = true;
    }
    else if ( op == DEV_OP_PAUSE )
    {
        p_dh_dev->running      = false;
        p_dh_dev->logic_status = false;

        /* 强制让定时器超时，触发检测下个合适的除湿器 */
        tick_timer_set_timeout_sta( s_dehumi_info.run.rd_timer, true );
        tick_timer_set_timeout_sta( s_dehumi_info.run.wk_timer, true );
    }

    return SF_OK;
}

sf_ret_t dehumi_ctrl_get_dat( uint8_t dev_index, dehumi_dat_t *p_dehumi_dat )
{
    if (dev_index >= s_dehumi_info.attr.dev_num)
        return SF_ERR_NO_OBJECT;
    
    *p_dehumi_dat = s_dehumi_info.run.dev[ dev_index ].dat;

    return SF_OK;
}

ol_sta_e dehumi_ctrl_get_online( uint8_t dev_index )
{
    if (dev_index >= s_dehumi_info.attr.dev_num)
        return OL_STA_NO_EXSIT;
    
    return (s_dehumi_info.run.dev[ dev_index ].online )? OL_STA_ONLINE : OL_STA_OFFLINE;
}

rate_t dehumi_ctrl_get_com_loss_rate( uint8_t dev_index )
{
    if (dev_index >= DEHUMI_DEV_MAX_NUM)
        return 0;
    
    return s_dehumi_info.run.dev[ dev_index ].com_loss_rate;
}


static void _dehumi_ctrl_detect_type( void )
{
    static tick_timer_handle_t detect_timer = NULL;
    static uint8_t detect_cnt = 0;
    uint16_t tmp_reg;
    int ret = 0;
    
    if ( s_dehumi_info.run.type != DEHUMI_TYPE_UNKNOW )
    {
        return;
    }

    if ( detect_timer == NULL )
    {
        detect_timer = tick_timer_create();
    }

    if ( tick_timer_is_timeout( detect_timer ) == false )
    {
        return;
    }

    if ( detect_cnt >= DH_TYPE_FAST_DETECT_CNT )
    {
        /* 探测超过 10次如果探测不到，所有设备切为离线，并降低探测频率 */
        tick_timer_set_timeout( detect_timer, DH_TYPE_SLOW_DETECT_INV_TM_MS );

        for (size_t i = 0; i < s_dehumi_info.attr.dev_num; i++)
        {
            s_dehumi_info.run.dev[i].online = false;
        }
    } else {
        detect_cnt++;
        tick_timer_set_timeout( detect_timer, DH_TYPE_FAST_DETECT_INV_TM_MS );
    }

    DEHUMI_DEBUG("detecting dehumi type");

    for (size_t i = 0; i < s_dehumi_info.attr.dev_num; i++)
    {
        ret = app_modbus_registers_read( s_dehumi_info.attr.modbus_idx, DH_MB_SLAVE_ADDR(i), 
                                         MB_REG_ADDR_SOFAR_FLAG, 1, &tmp_reg, 50 );
        if ( ret >= 0 )
            break;
    }

    if ( ret < 0 )
    {
        return;
    }

    if( tmp_reg == (uint16_t)(('S' << 8 ) | ('F' << 0 )) )  
    {
        s_dehumi_info.run.type = DEHUMI_TYPE_SOFAR_COMM;
    }else{
        s_dehumi_info.run.type = DEHUMI_TYPE_BR;
    }

    DEHUMI_DEBUG("dehumi type:%s",  (s_dehumi_info.run.type == DEHUMI_TYPE_SOFAR_COMM) ? "DEHUMI_TYPE_SOFAR_COMM" : 
                                    (s_dehumi_info.run.type == DEHUMI_TYPE_BR)         ? "DEHUMI_TYPE_BR" : "DEHUMI_TYPE_UNKNOW" );
    _dehumi_ctrl_type_confirm_init();
}

static void _dehumi_ctrl_type_confirm_init( void )
{
    /* 探测到之后要进行初始化 */
    if ( SF_OK != s_dh_dev_op[ s_dehumi_info.run.type ].f_dh_ctrl_init_cb( s_dehumi_info.attr.modbus_idx ))
    {
        
    }
}

void dehumi_ctrl_loop_task( void )
{
#if (DH_CTRL_TMP_DEBUG == 1)
    _dehumi_sta_change_print();
#endif
    _dehumi_ctrl_detect_type();
    _dehumi_ctrl_read_looping();
    _dehumi_ctrl_work_ctrl_looping();
}

static void _dehumi_ctrl_read_looping( void )
{
    dehumi_type_e dh_type = s_dehumi_info.run.type;

    if ( s_dehumi_info.run.type >= DEHUMI_TYPE_MAX )
    {
        return;
    }

    if ( false == tick_timer_is_timeout( s_dehumi_info.run.rd_timer ) )
    {
        return;
    }
    tick_timer_refresh( s_dehumi_info.run.rd_timer );
        
    for (size_t i = 0; i < s_dehumi_info.attr.dev_num; i++)
    {
        dehumi_dev_t *p_dev = &s_dehumi_info.run.dev[i];
        dehumi_dat_t dh_dat;

        memset( &dh_dat, 0, sizeof( dehumi_dat_t ) );

        p_dev->total_msg_cnt++;
        sf_ret_t ret = s_dh_dev_op[ dh_type ].f_dh_ctrl_get_dat_cb( DH_MB_SLAVE_ADDR(i), &dh_dat );
        if ( ret != SF_OK )
        {
            p_dev->total_fail_cnt++;
            if ( p_dev->msg_fail_cnt < READ_FAIL_MAX_CNT )
            {
                p_dev->msg_fail_cnt++;
            } else {
                /* 离线 */
                p_dev->online = false;
            }

        } else {
            /* 通讯成功 */
            p_dev->msg_fail_cnt = 0;
            p_dev->online       = true;
            p_dev->dat          = dh_dat;
            p_dev->dat.dewPoint = _dehumi_ctrl_cal_dewPoint( p_dev->dat.env_temper, p_dev->dat.env_humi );

            /* 纠正状态，只有 首航通用 才能做状态纠正 */
            /* 逻辑状态 和 实际状态 不对应 */
            if (   ( dh_type == DEHUMI_TYPE_SOFAR_COMM )
                && ( p_dev->logic_status != p_dev->dat.status ) )
            {
                DEHUMI_WARN( "dh[%d] status adjust dst:%d", i , p_dev->logic_status );
                if ( SF_OK != s_dh_dev_op[ dh_type ].f_dh_ctrl_set_mode_cb( DH_MB_SLAVE_ADDR(i), DH_CTRL_MODE_REMOTE ))
                {
                    DEHUMI_WARN( "dh[%d] set remote mode fail", i );
                }
                if ( SF_OK != s_dh_dev_op[ dh_type ].f_dh_ctrl_set_dehumi_sta_cb( DH_MB_SLAVE_ADDR(i), p_dev->logic_status ))
                {
                    DEHUMI_WARN( "dh[%d] set remote sta fail", i );
                }
            }
        }
        p_dev->com_loss_rate = (rate_t)( (float)p_dev->total_fail_cnt / (float)p_dev->total_msg_cnt * 10000.0f );
    }
}

static void _dehumi_sta_change_print( void )
{
    static uint8_t last_status[ DEHUMI_DEV_MAX_NUM ] = { 0 };

    if (s_dehumi_info.run.type != DEHUMI_TYPE_SOFAR_COMM )
    {
        return;
    }

    for (size_t i = 0; i < s_dehumi_info.attr.dev_num; i++)
    {
        dehumi_dev_t *p_dev = &s_dehumi_info.run.dev[i];

        if ( p_dev->logic_status != last_status[i] )
        {
            last_status[i] = p_dev->logic_status;
            DEHUMI_DEBUG( "dh[%d] status change :%d ", i, p_dev->logic_status );
        }
    }
}

/**
 * @brief  除湿器 内部处理函数
 * @param  [in] dh_type             ： 除湿器类型
 * @param  [in] dh_dev_idx          ： 当前除湿器索引/位置 
 * @param  [in] max_dewpt_dh_dev_idx： 当前 露点最高的除湿器索引/位置 
 * @param  [in] wk_dh_dev_idx       ： 当前 正在工作的除湿器索引/位置 
 * @return 无
 * @note   
 */
static void _dehumi_ctrl_dev_handle( dehumi_type_e dh_type, dev_idx_t dh_dev_idx, dev_idx_t max_dewpt_dh_dev_idx, dev_idx_t wk_dh_dev_idx )
{
    /* 获取当前除湿器的下个动作 */
    dehumi_dev_t *p_dehumi_dev = &s_dehumi_info.run.dev[dh_dev_idx];

    if ( p_dehumi_dev->logic_status == true )
    {
        /* 检测是否需要关 */
        if (( p_dehumi_dev->dat.dewPoint <= ( s_dehumi_info.run.obj_temper + STOP_OBJ_TMP_DEWPOINT_DIFF_VAL ) )
            && ( p_dehumi_dev->dat.env_humi <= STOP_DEHUMI_THRESHOLD ) ) 
        {
            /**
             * TA ≤ Ts + 0.5℃   TA：露点  Ts：物体表面温度 
             * RH ≤ 70%        环境湿度 70%
             * 关闭除湿
             */
            DEHUMI_VERBOSE( "dh[%d] status set false", dh_dev_idx );
            s_dh_dev_op[ dh_type ].f_dh_ctrl_set_dehumi_sta_cb( DH_MB_SLAVE_ADDR( dh_dev_idx ), false );
            p_dehumi_dev->logic_status = false;
        }
        return;
    }

    /* 露点不是最高的除湿器不做处理 */
    if ( max_dewpt_dh_dev_idx != dh_dev_idx  )
    {
        return;
    }

    /* 露点最高的除湿器判断是否需要开启除湿 */
    if ( p_dehumi_dev->dat.dewPoint > ( s_dehumi_info.run.obj_temper + TRIG_OBJ_TMP_DEWPOINT_DIFF_VAL ) 
        || ( p_dehumi_dev->dat.env_humi >= TRIG_DEHUMI_THRESHOLD ))
    {
        /**
         * TA > Ts + 2℃   TA：露点  Ts：物体表面温度 
         * RH ≥ 80%        环境湿度大于 80%
         */

        /* 开启之前需要把另一个正在工作的除湿器关掉 */
        if ( (wk_dh_dev_idx != DEV_IDX_INVALID ) && (wk_dh_dev_idx != dh_dev_idx ) )
        {
            DEHUMI_VERBOSE( "dh[%d] status set false", wk_dh_dev_idx );
            s_dh_dev_op[ dh_type ].f_dh_ctrl_set_dehumi_sta_cb( DH_MB_SLAVE_ADDR( wk_dh_dev_idx ), false );
            s_dehumi_info.run.dev[wk_dh_dev_idx].logic_status = false;
        }

        DEHUMI_VERBOSE( "dh[%d] status set true", dh_dev_idx );
        s_dh_dev_op[ dh_type ].f_dh_ctrl_set_dehumi_sta_cb( DH_MB_SLAVE_ADDR( dh_dev_idx ), true );
        p_dehumi_dev->logic_status = true;
    } 

    return;
}

static void _dehumi_ctrl_work_ctrl_looping( void )
{
    dehumi_type_e dh_type = s_dehumi_info.run.type;
    dev_idx_t     wk_dev_idx = DEV_IDX_INVALID;
    dev_idx_t     max_dewpoint_dev_idx = DEV_IDX_INVALID;
    temper_t      max_dewpoint = 0;

    if (   (s_dehumi_info.attr.dev_num == 0 )
        || (s_dehumi_info.run.type != DEHUMI_TYPE_SOFAR_COMM )
        || (s_dehumi_info.run.obj_temper_valid == false ) )
    {
        return;
    }

    if ( tick_timer_is_timeout( s_dehumi_info.run.wk_timer ) == false )
    {
        return;
    }
    tick_timer_refresh( s_dehumi_info.run.wk_timer );

    DEHUMI_VERBOSE("\r\n");
    /* 筛选露点温度 最大的节点 */
    for (dev_idx_t i = 0; i < s_dehumi_info.attr.dev_num; i++)
    {
        dehumi_dev_t *p_dev = &s_dehumi_info.run.dev[i];

        DEHUMI_VERBOSE("[%s]dh[%d] - humity: %d RH, temper: %d, dewpoint: %d, status:%d",__FUNCTION__, i, p_dev->dat.env_humi, p_dev->dat.env_temper, p_dev->dat.dewPoint , p_dev->dat.status );
        if ( p_dev->logic_status == true )
        {
            wk_dev_idx = i;
        }

        /* 暂停状态下，不参与筛选 */
        if ( p_dev->running == false )
            continue;
        
        if ( max_dewpoint < p_dev->dat.dewPoint )
        {
            max_dewpoint = p_dev->dat.dewPoint;
            max_dewpoint_dev_idx = i;
        }
    }

    DEHUMI_VERBOSE("obj tmp:%d, max_dew[%d]:%dRH\r\n",s_dehumi_info.run.obj_temper, max_dewpoint_dev_idx, max_dewpoint);
    for (dev_idx_t i = 0; i < s_dehumi_info.attr.dev_num; i++)
    {
        dehumi_dev_t *p_dev = &s_dehumi_info.run.dev[i];

        if ( p_dev->running == true )
        {
            _dehumi_ctrl_dev_handle( dh_type, i, max_dewpoint_dev_idx, wk_dev_idx );
        }
    }
}

#define DEPPOINT_TAB_COL_MAX        14
#define DEPPOINT_TAB_ROW_MAX        31

/* 10℃ ~ 40℃ */
const temper_t dewpoint_temp_header[DEPPOINT_TAB_ROW_MAX]   = {100, 110, 120, 130, 140, 150, 160, 170, 180, 190, 200, 210, 220, 230, 240, 250, 260, 270, 280, 290, 300, 310, 320, 330, 340, 350, 360, 370, 380, 390, 400};
/* 30% ~ 95% */
const humi_t   dewpoint_humi_header[ DEPPOINT_TAB_COL_MAX ] = {30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95};

// 温湿度露点对照表
const temper_t dewpoint_table[ DEPPOINT_TAB_ROW_MAX ][ DEPPOINT_TAB_COL_MAX ] = 
{
    {92,  84,  76,  67,  58,  48,  36,  25,  15,  0,   -13, -3,  -50, -70},
    {102, 94,  86,  77,  67,  58,  48,  35,  25,  10,  -5,  -20, -40, -65},
    {112, 109, 95,  87,  77,  67,  55,  44,  33,  20,  5,   -10, -30, -50},
    {122, 114, 105, 96,  87,  77,  66,  53,  41,  28,  14,  -2,  -20, -45},
    {132, 124, 115, 106, 96,  86,  75,  64,  51,  35,  22,  7,   -10, -32},
    {142, 134, 125, 116, 106, 96,  84,  73,  60,  46,  31,  15,  -3,  -23},
    {152, 143, 134, 126, 116, 106, 95,  83,  70,  56,  40,  24,  5,   -13},
    {162, 153, 145, 135, 125, 115, 102, 92,  80,  65,  50,  32,  15,  -5 },
    {172, 164, 154, 145, 135, 125, 113, 102, 90,  74,  58,  40,  23,  2  },
    {182, 173, 165, 154, 145, 134, 122, 110, 98,  84,  68,  50,  32,  10 },
    {192, 183, 174, 165, 154, 144, 132, 120, 107, 94,  78,  60,  40,  20 },
    {202, 193, 184, 174, 164, 153, 142, 129, 117, 102, 86,  70,  50,  28 },
    {212, 203, 194, 184, 173, 163, 152, 138, 125, 110, 95,  78,  58,  35 },
    {222, 213, 204, 194, 184, 173, 162, 148, 135, 120, 104, 87,  68,  44 },
    {231, 223, 214, 204, 193, 182, 170, 158, 145, 130, 114, 97,  77,  53 },
    {239, 232, 223, 213, 203, 191, 180, 168, 154, 140, 123, 105, 86,  62 },
    {251, 242, 233, 223, 212, 201, 190, 177, 163, 148, 132, 114, 94,  70 },
    {261, 252, 243, 232, 222, 211, 199, 187, 173, 158, 140, 122, 103, 80 },
    {271, 262, 252, 242, 231, 220, 209, 196, 181, 167, 150, 132, 112, 88 },
    {281, 272, 262, 252, 241, 230, 213, 205, 192, 176, 159, 140, 120, 97 },
    {291, 282, 272, 262, 251, 239, 228, 214, 200, 185, 168, 150, 129, 105},
    {301, 292, 282, 269, 260, 248, 237, 224, 209, 194, 178, 159, 137, 114},
    {311, 301, 292, 281, 270, 258, 246, 233, 219, 203, 186, 168, 147, 122},
    {321, 311, 301, 290, 280, 268, 256, 242, 229, 213, 196, 176, 156, 130},
    {331, 321, 311, 295, 290, 277, 265, 252, 238, 212, 205, 186, 165, 139},
    {341, 331, 321, 310, 299, 287, 275, 262, 246, 231, 214, 195, 174, 149},
    {352, 341, 331, 320, 309, 297, 284, 270, 257, 240, 222, 203, 181, 157},
    {362, 352, 341, 330, 318, 307, 295, 279, 265, 249, 232, 212, 192, 166},
    {370, 360, 351, 339, 327, 315, 303, 289, 274, 258, 239, 220, 199, 175},
    {380, 368, 362, 349, 338, 325, 312, 298, 283, 266, 249, 230, 208, 181},
    {390, 380, 368, 358, 347, 335, 321, 307, 292, 276, 258, 238, 216, 192}
};

/**
 * @brief		根据温湿度查找露点
 * @param		[in] ： temper 温度
 * @param		[in] ：humi  湿度
 * @return
 * @retval		返回露点值
 * @warning		无
 */
static temper_t _dehumi_ctrl_cal_dewPoint( temper_t temper, humi_t humi )
{
    int8_t  row_index      = 0;
    int8_t  col_index      = 0;
    int8_t  i              = 0;
    int16_t dew_point_temp = 0;
    int8_t  col_last       = 0;

    // 取略大的一列湿度作为i的退出条件
    for (i = 0; i < DEPPOINT_TAB_COL_MAX; i++)
    {
        if ( humi <= dewpoint_humi_header[i])
        {
            break;
        }
    }
    // 索引翻转后 col_index范围为-1~13 ； 修正为0~13
    col_index = DEPPOINT_TAB_COL_MAX - i - 1;
    if (col_index < 0)
    {
        col_index = 0;
    }

    // col_last为未翻转的索引的前一列 i范围0~14  col_last范围-1~12
    if (i == DEPPOINT_TAB_COL_MAX)
    {
        col_last = i - 2;
    }
    else
    {
        col_last = i - 1;
    }

    // 取略大的一行温度作为i的退出条件
    for (i = 0; i < DEPPOINT_TAB_ROW_MAX; i++)
    {
        if ( temper <= dewpoint_temp_header[i])
        {
            break;
        }
    }
    // 退出循环后i范围0~31，越界，修正为0~30
    if (i == DEPPOINT_TAB_ROW_MAX)
    {
        i -= 1;
    }
    // 对半取更近的一行温度作为索引
    if ( temper <= dewpoint_temp_header[i] - 5)
    {
        row_index = i - 1;
    }
    else
    {
        row_index = i;
    }
    // 处理最低温导致的负索引
    if (row_index < 0)
    {
        row_index = 0;
    }

    if (( humi == dewpoint_humi_header[col_last + 1]) || (col_last == -1) || (col_index == 0))
    {
        dew_point_temp = dewpoint_table[row_index][col_index];
    }
    else
    {
        // 取线性插值，采用了整数除法，为了更精确，因此在两处分别对数值膨胀10倍，最后除100
        // 注释代码给出原表达式
        dew_point_temp = dewpoint_table[row_index][col_index + 1]
                         + (((dewpoint_table[row_index][col_index] - dewpoint_table[row_index][col_index + 1]) * 20) * ( humi - dewpoint_humi_header[col_last]) / 100);
        // dew_point_temp = dewpoint_table[row_index][col_index + 1]
        //                  + (((dewpoint_table[row_index][col_index] - dewpoint_table[row_index][col_index + 1]) * 10 / 5) * (*humi - dewpoint_humi_header[col_last] / 10 * 10) / 100);
    }
    return dew_point_temp;
}
