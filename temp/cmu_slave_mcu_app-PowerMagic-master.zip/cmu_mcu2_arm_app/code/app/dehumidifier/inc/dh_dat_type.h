#ifndef _DH_DAT_TYPE_H_
#define _DH_DAT_TYPE_H_

#include "sofar_type.h"

typedef enum 
{
    DH_CTRL_MODE_AUTO,
    DH_CTRL_MODE_BUTTON,
    DH_CTRL_MODE_REMOTE,
    DH_CTRL_MODE_MAX,
} dh_ctrl_mode_e;

/**
  * @brief  除湿器 数据
  */
typedef struct 
{
    bool     status;            //< 除湿状态
    temper_t env_temper;        //< 环境温度
    humi_t   env_humi;          //< 环境湿度
    temper_t dewPoint;          //< 对应露点
} dehumi_dat_t;

#endif
