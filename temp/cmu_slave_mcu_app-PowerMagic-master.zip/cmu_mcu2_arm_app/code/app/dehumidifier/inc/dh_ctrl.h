#ifndef __DEHUMI_CTRL_H__
#define __DEHUMI_CTRL_H__

#include "dh_dat_type.h"

/**
  * @brief  设备操作
  */
typedef enum {
    DEV_OP_PAUSE,               //< 暂停
    DEV_OP_RESUME,              //< 恢复
    DEV_OP_MAX,       
} dev_op_e;

/**
 * @brief  除湿控制组件 初始化
 * @param  [in] 无
 * @return SF_OK：成功   其他：失败
 * @note   
 */
sf_ret_t dehumi_ctrl_init( modbus_idx_t modbus_idx );

/**
 * @brief  设置除湿器数量
 * @param  [in] dev_num: 除湿器数量
 * @return SF_OK：成功   其他：失败
 * @note   
 */
sf_ret_t dehumi_ctrl_set_num( uint8_t dev_num );

/**
 * @brief  设置除湿器 自动模式下参数（以湿度为主）
 * @param  [in] dehumi_threshold: 开始除湿阈值
 * @param  [in] dehumi_ret      : 湿度回差
 * @return SF_OK：成功   其他：失败
 * @note   
 */
sf_ret_t dehumi_ctrl_set_auto_mode_param( humi_t dehumi_threshold, humi_t dehumi_ret );


/**
 * @brief  输入 当前物体的温度，
 * @param  [in] obj_temper: 当前物体温度
 * @return SF_OK：成功   其他：失败
 * @note   
 */
void dehumi_ctrl_input_obj_temper( temper_t obj_temper );

/**
 * @brief  对除湿控制组件 进行操作
 * @param  [in] dev_index ：除湿器索引
 * @param  [in] op        ：操作【暂停/继续】
 * @return SF_OK：成功   其他：失败
 * @note   
 */
sf_ret_t dehumi_ctrl_op( uint8_t dev_index, dev_op_e op );

/**
 * @brief  获取除湿器的数据
 * @param  [in]  dev_index    ：除湿器索引
 * @param  [out] p_dehumi_dat ：获取除湿器数据指针
 * @return SF_OK：成功   其他：失败
 * @note   
 */
sf_ret_t dehumi_ctrl_get_dat( uint8_t dev_index, dehumi_dat_t *p_dehumi_dat );

/**
 * @brief  获取除湿器在线情况
 * @param  [in]  dev_index ：除湿器索引
 * @return 
 *          OL_STA_NO_EXSIT ： 不存在
 *          OL_STA_ONLINE ： 在线
 *          OL_STA_OFFLINE ： 离线
 */
ol_sta_e dehumi_ctrl_get_online( uint8_t dev_index );

/**
 * @brief  获取除湿器当前通讯丢包率
 * @param  [in]  dev_index ：除湿器索引
 * @return 返回丢包率
 * @note   
 */
rate_t dehumi_ctrl_get_com_loss_rate( uint8_t dev_index );

/**
 * @brief  对除湿控制组件 任务调度
 * @param  [in] 无
 * @return 无
 * @note   
 */
void dehumi_ctrl_loop_task( void );

#endif
