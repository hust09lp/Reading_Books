#ifndef _DH_DEV_BR_H_
#define _DH_DEV_BR_H_

#include "dh_dat_type.h"

sf_ret_t dh_dev_br_init( modbus_idx_t modbus_idx );
sf_ret_t dh_dev_br_get_dat( uint8_t mb_slave_addr, dehumi_dat_t *p_dehumi_dat );
sf_ret_t dh_dev_br_set_auto_param( uint8_t mb_slave_addr, humi_t dehumi_threshold, humi_t dehumi_ret );
sf_ret_t dh_dev_br_set_dehumi_sta( uint8_t mb_slave_addr, bool dehumi_sta );
sf_ret_t dh_dev_br_set_mode( uint8_t mb_slave_addr, dh_ctrl_mode_e mode );

#endif

