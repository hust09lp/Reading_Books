#include "num_trans.h"

#include "sdk.h"
#include "sdk_core.h"

bool mapping_raw_num_to_map_num( raw_num_t raw_num , map_num_t *p_map_num, const num_mapping_t *p_num_mapping, uint16_t mapping_cnt )
{
    for (size_t i = 0; i < mapping_cnt; i++)
    {
        if( p_num_mapping[i].raw_num == raw_num )
        {
            *p_map_num = p_num_mapping[i].map_num;
            return true;
        }
    }
    return false;
}

bool mapping_map_num_to_raw_num( map_num_t map_num, raw_num_t *p_raw_num , const num_mapping_t *p_num_mapping, uint16_t mapping_cnt )
{
    for (size_t i = 0; i < mapping_cnt; i++)
    {
        if( p_num_mapping[i].map_num == map_num )
        {
            *p_raw_num = p_num_mapping[i].raw_num;
            return true;
        }
    }
    return false;
}

void util_print_hex_dat( char *head_str, uint8_t *dat, uint16_t dat_len, uint8_t col_num, bool col_num_print  )
{
    if( head_str )
    {
        sdk_log_printf("%s ", head_str);
    }

    sdk_log_printf( "dat len:%d , data:", dat_len );
    for (size_t i = 0; i < dat_len; i++)
    {
        if( (i % col_num) == 0 )
        {
            sdk_log_printf( "\r\n" );
            if( col_num_print )
            {
                sdk_log_printf("%04d: ", i / col_num);
            }
        }
        sdk_log_printf( "%02X ", dat[i] );
    }
    sdk_log_printf( "\r\n");
}
