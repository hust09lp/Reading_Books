#ifndef __NUM_TRANS_H__
#define __NUM_TRANS_H__

#include "data_types.h"

#define ARRAY_CNT(array)       ( sizeof(array) / sizeof(array[0]) )

typedef int32_t map_num_t;
typedef int32_t raw_num_t;

typedef struct{
    raw_num_t  raw_num;
    map_num_t  map_num;
} num_mapping_t;

bool mapping_raw_num_to_map_num( raw_num_t raw_num , map_num_t *p_map_num, const num_mapping_t *p_num_mapping, uint16_t mapping_cnt );
bool mapping_map_num_to_raw_num( map_num_t map_num, raw_num_t *p_raw_num , const num_mapping_t *p_num_mapping, uint16_t mapping_cnt );

void util_print_hex_dat( char *head_str, uint8_t *dat, uint16_t dat_len, uint8_t col_num, bool col_num_print  );

#endif
