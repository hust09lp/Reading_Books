#include "pre_stop.h"
#include "keep_temper.h"
#include "running_heat.h"
#include "running_cool.h"
#include "pre_heat_cool.h"
#include "usr_lc_ctrl.h"
#include "lc_ctrl.h"

#include "tick_timer.h"
#include "bat_temper_def.h"
#include "bat_tmp_ctrl_api.h"
#include "bat_tmp_ctrl_cfg.h"

typedef enum {
    SCH_STA_IDLE,
    SCH_STA_PRE_HC,
    SCH_STA_RUN_HEATING,
    SCH_STA_RUN_COOLING,
    SCH_STA_KEEP_TMP,
    SCH_STA_PRE_STOP,
} sch_sta_e;

typedef struct {
    struct {
        bool                    auto_ctrl_enable;                    //< 模块
        // bool                    keep_tmp_enable;
        bool                    bat_tmp_setting_valid;
        bat_tmp_setting_t       bat_tmp_setting;
    } attr;             

    struct {
        bool            boot_pre_hc_finish;     // 系统上电预冷预热完成标志
        bool            dis_charge_allow;       // 系统上电预冷预热完成标志

        struct 
        {
            bool              virtual_debug;
            bool              tmper_ctrl_reset;             //< 温度控制系统重置
            bool              new_bat_tmp_setting_valid;
            bat_tmp_setting_t new_bat_tmp_setting;
        } cmd;

        struct 
        {
            bool      valid;                        //< 电池数据有效位
            temper_t  bat_tmp_mean;                 //< 电池平均温度
            temper_t  bat_tmp_min;                  //< 电池最小温度
            temper_t  bat_tmp_max;                  //< 电池最大温度
            int32_t   bat_current_01A;
            temper_t  env_tmp;
        } dat;

        struct {
            bool            curr_working;
            bool            pre_stop;
            sch_sta_e       sch_sta;            // 调度状态
        } sta;
    } run;
} bat_sys_info_t;

static bat_sys_info_t s_bat_sys_info = { 
                                        // .attr = {
                                        //     .bat_tmp_setting = {
                                        //         .bat_Tds = Tds, 
                                        //         .bat_Tdm = Tdm, 
                                        //         .pump_delay_close_tm = 600, 
                                        //         .pre_check_tm_sec = 12, 
                                        //         .standby_cur = 100, 

                                        //         .pre_cool = { 
                                        //             .startup_bat_Tmax   = PRE_COOL_STARTUP_Tmax,
                                        //             .startup_bat_Tmean  = PRE_COOL_STARTUP_Tmean,
                                        //             .exit_ret_tmp = PRE_COOL_EXIT_HYS_TMP,
                                        //             .lc_tmp       = PRE_COOL_LC_TMP,
                                        //             .lc_flow      = PRE_COOL_LC_FLOW,
                                        //          }, 
                                        //         .pre_heat = {
                                        //             .startup_bat_Tmin   = PRE_HEAT_STARTUP_Tmin,
                                        //             .startup_bat_Tmean  = PRE_HEAT_STARTUP_Tmean,
                                        //             .exit_ret_tmp   = PRE_HEAT_EXIT_HYS_TMP,
                                        //             .lc_tmp         = PRE_HEAT_LC_TMP,
                                        //             .lc_flow        = PRE_HEAT_LC_FLOW,
                                        //         }, 
                                        //         .start_cool = {
                                        //             .Tmean_Tds_val  = {  0,  10,   20,  30,  40 },
                                        //             .lc_tmp         = { 0, 260, 250, 240, 230, 220 },
                                        //             .ret_tmp        = 0,
                                        //             .lc_flow        = 100,
                                        //             .tm_sec         = 300,
                                        //         }, 
                                        //         .stop_cool = {
                                        //             .Tds_ret_tmp    = 20,
                                        //             .enter_valid_tm = 300,
                                        //             .exit_valid_tm  = 0,
                                        //         }, 
                                        //         .cooling = {
                                        //             .tmp_fit_enable = 1,
                                        //             .fix_lc_tmp = 190,
                                        //             .fit_lc_tmp = {
                                        //                 .lc_min_tmp       = 190,
                                        //                 .lc_max_tmp       = 250,
                                        //                 .Tmean_lc_tmp_adj = {
                                        //                     .Tmean_Tds_val   = {  -10, 0, 10, 20, 30 },
                                        //                     .lc_tmp_adj      = { 15, 10, 5, 0, -5, -10 },
                                        //                     .ret_tmp         = 10,
                                        //                     .adj_interval_tm = 120,
                                        //                 },
                                        //                 .Tmax_lc_tmp_adj  = {
                                        //                     .Tmax_Tdm_val    = {   0,  10,  20 },
                                        //                     .lc_tmp_adj      = { 0, -10, -15, -20 },
                                        //                     .ret_tmp         = 5,
                                        //                     .adj_interval_tm = 60,
                                        //                 },
                                        //             },

                                        //             .flow_fit_enable = 0,
                                        //             .fix_lc_flow = 100,
                                        //             .fit_lc_flow = {
                                        //                 .Tdm_and_Tds_ret_tmp = 10, 
                                        //                 .Tmax_Tmin_val       = {   20, 30, 40 }, 
                                        //                 .lc_flow_adj         = { -10, 0, 10, 20 }, 
                                        //                 .ret_tmp             = 5, 
                                        //                 .adj_interval_tm     = 60, 
                                        //             },
                                        //         }, 
                                        //         .keep_tmper = {
                                        //             .enable = 0,
                                        //             .heating_startup_temper = T_heat_keeping1,
                                        //             .heating_exit_temper    = T_heat_keeping2,
                                        //             .cooling_startup_temper = T_cool_keeping1,
                                        //             .cooling_exit_temper    = T_cool_keeping2
                                        //         },
                                        //         .dis_work_tmp = {
                                        //             .pre_cooling = Tpre_COOLING3,
                                        //             .pre_heating = Tpre_HEATING3,
                                        //         }
                                        //     },
                                        // },
                                        .run = {
                                            .sta.curr_working = SF_FALSE,
                                        }};

static bool _bat_temper_ctrl_run_sta_proc( int32_t bat_current_01A );
static void _bat_temper_new_bat_tmp_setting_update( void );
static void _bat_temper_ctrl_reset_handle( void );
static bool _bat_temper_ctrl_task_loop_access( void );
static void _bat_temper_ctrl_proc_schedule( void );
static void _bat_temper_set_schedule_sta( sch_sta_e sch_sta );
/**
 * @brief 热管理控制模块 初始化 
 * @param  [in] p_bat_tmp_setting  热管理控制参数
 * @param  [in] lc_ctrl_cb          液冷控制回调函数
 * @return true：成功  false：失败
 */
bool bat_temper_ctrl_init( void )
{
    usr_lc_ctrl_init();
    pre_heat_cool_init();
    running_cool_init();
    pre_stop_init();

    pre_heat_cool_setting( &s_bat_sys_info.attr.bat_tmp_setting.pre_cool,
                           &s_bat_sys_info.attr.bat_tmp_setting.pre_heat,
                           &s_bat_sys_info.attr.bat_tmp_setting.dis_work_tmp);
    running_cool_setting( s_bat_sys_info.attr.bat_tmp_setting.bat_Tds,
                          s_bat_sys_info.attr.bat_tmp_setting.bat_Tdm,
                          &s_bat_sys_info.attr.bat_tmp_setting.start_cool,
                          &s_bat_sys_info.attr.bat_tmp_setting.stop_cool,
                          &s_bat_sys_info.attr.bat_tmp_setting.cooling );
    running_heat_setting( s_bat_sys_info.attr.bat_tmp_setting.pre_heat.startup_bat_Tmean, 
                         s_bat_sys_info.attr.bat_tmp_setting.pre_heat.startup_bat_Tmean + s_bat_sys_info.attr.bat_tmp_setting.pre_heat.exit_ret_tmp );
    return SF_TRUE;
}

/**
 * @brief  输入电池数据
 * @param  [in] valid   电池数据有效位
 * @param  [in] bat_current_01A 电池电流
 * @param  [in] bat_tmp_mean    电池平均温度
 * @param  [in] bat_tmp_min     电池最小温度
 * @param  [in] bat_tmp_max     电池最大温度
 * @return 
 */
void bat_temper_ctrl_input( bool valid, int32_t bat_current_01A, temper_t env_tmp, temper_t bat_tmp_mean, temper_t bat_tmp_min, temper_t bat_tmp_max )
{   
    if ( s_bat_sys_info.run.cmd.virtual_debug == SF_TRUE )
    {
        return;
    }

    s_bat_sys_info.run.dat.bat_tmp_mean     = bat_tmp_mean;
    s_bat_sys_info.run.dat.bat_tmp_min      = bat_tmp_min;
    s_bat_sys_info.run.dat.bat_tmp_max      = bat_tmp_max;
    s_bat_sys_info.run.dat.bat_current_01A  = bat_current_01A;
    s_bat_sys_info.run.dat.env_tmp          = env_tmp;

    s_bat_sys_info.run.dat.valid = valid;
}

static void _bat_temper_set_schedule_sta( sch_sta_e sch_sta )
{
    if ( s_bat_sys_info.run.sta.sch_sta == sch_sta )
        return;

    s_bat_sys_info.run.sta.sch_sta = sch_sta;
    BAT_TMPER_CTR_DEBUG( "sch_sta:%s",  (sch_sta == SCH_STA_IDLE        )? "SCH_STA_IDLE"        :
                                        (sch_sta == SCH_STA_PRE_HC      )? "SCH_STA_PRE_HC"      :
                                        (sch_sta == SCH_STA_RUN_HEATING )? "SCH_STA_RUN_HEATING" :
                                        (sch_sta == SCH_STA_RUN_COOLING )? "SCH_STA_RUN_COOLING" :
                                        (sch_sta == SCH_STA_KEEP_TMP    )? "SCH_STA_KEEP_TMP"    :
                                        (sch_sta == SCH_STA_PRE_STOP    )? "SCH_STA_PRE_STOP"    : "SCH_STA_UNKNOW" );
    
    /* 调度状态发生切换时，某些模块需要重新复位 */
    switch ( sch_sta )
    {
        case SCH_STA_IDLE:
            break;
        case SCH_STA_PRE_HC:
            pre_heat_cool_reset();
            break;
        case SCH_STA_RUN_HEATING:
            running_heating_reset();
            break;
        case SCH_STA_RUN_COOLING:
            running_cool_reset();
            break;
        case SCH_STA_KEEP_TMP:
            keep_temper_reset();
            break;
        case SCH_STA_PRE_STOP:
            pre_stop_reset();
            break;
        default:
            break;
    }

    switch ( sch_sta )
    {
        case SCH_STA_IDLE:
        case SCH_STA_PRE_HC:
        case SCH_STA_RUN_HEATING:
        case SCH_STA_KEEP_TMP:
            /* 打断预冷操作 */
            s_bat_sys_info.run.sta.pre_stop = SF_FALSE;
            break;
        case SCH_STA_RUN_COOLING:
            /* 制冷运行模式之后停止充放电需要做预停机操作 */
            s_bat_sys_info.run.sta.pre_stop = SF_TRUE;
            break;
        case SCH_STA_PRE_STOP:
            /* 执行预停机过程，等待状态机自然切换 */
            break;
        default:
            break;
    }
    return;
}

/* 策略调度 */
static void _bat_temper_ctrl_proc_schedule( void )
{
    temper_t bat_tmp_mean    =  s_bat_sys_info.run.dat.bat_tmp_mean;
    temper_t bat_tmp_min     =  s_bat_sys_info.run.dat.bat_tmp_min;
    temper_t bat_tmp_max     =  s_bat_sys_info.run.dat.bat_tmp_max;
    temper_t env_tmp         =  s_bat_sys_info.run.dat.env_tmp;
    uint32_t bat_current_01A =  s_bat_sys_info.run.dat.bat_current_01A;

    bool curr_working = _bat_temper_ctrl_run_sta_proc( bat_current_01A );

    /**
     * 上电未进行预冷预热 
     * 未开启保温模式
     * 以上情况均需做预冷预热判断
     **/
    if (   ( s_bat_sys_info.run.boot_pre_hc_finish == SF_FALSE) 
        || ( s_bat_sys_info.attr.bat_tmp_setting.keep_tmper.enable == SF_FALSE) )
    {
        if ( PRE_HC_STA_FINISH != pre_heat_cool_get_sta() )
        {
            /* 预冷预热 */
            _bat_temper_set_schedule_sta( SCH_STA_PRE_HC );
            if ( PRE_HC_STA_FINISH == pre_heat_cool_proc( curr_working, env_tmp, bat_tmp_mean, bat_tmp_min, bat_tmp_max ))
            {
                s_bat_sys_info.run.boot_pre_hc_finish = SF_TRUE;
            }
            return;
        }
    }

    if ( curr_working )
    {
        if (   ( bat_tmp_mean < s_bat_sys_info.attr.bat_tmp_setting.pre_heat.startup_bat_Tmean ) 
            || ( running_heating_get_sta() != RUN_HEAT_STA_IDLE ))
        {
            /* bat_tmp_mean < Tpre_heating1 */
            /* 正在加热电芯未退出 */
            /* 制热策略 */
            _bat_temper_set_schedule_sta( SCH_STA_RUN_HEATING );
            running_heating_process( bat_tmp_mean );
        }else{
            /* 制冷策略 */
            _bat_temper_set_schedule_sta( SCH_STA_RUN_COOLING );
            running_cooling_process( bat_tmp_mean, bat_tmp_min, bat_tmp_max );
        }
    }else{
        /* 需要做预停机操作 */
        if ( s_bat_sys_info.run.sta.pre_stop == SF_TRUE )
        {
            _bat_temper_set_schedule_sta( SCH_STA_PRE_STOP );
            if ( PRE_STOP_STA_FINISH == pre_stop_process( env_tmp, bat_tmp_mean, bat_tmp_min, bat_tmp_max ))
            {
                /* 所有预停机操作完成 */
                s_bat_sys_info.run.sta.pre_stop = SF_FALSE;
            }
        }else if ( s_bat_sys_info.attr.bat_tmp_setting.keep_tmper.enable == SF_TRUE )
        {
            /* 保温模式 */
            _bat_temper_set_schedule_sta( SCH_STA_KEEP_TMP );
            keep_temper_proc( curr_working, bat_tmp_mean, bat_tmp_min, bat_tmp_max );
        }
    }
}

static bool _bat_temper_ctrl_task_loop_access( void )
{
    static tick_timer_handle_t loop_timer_hd = NULL;

    if ( loop_timer_hd == NULL)
    {
        loop_timer_hd = tick_timer_create();
        tick_timer_set_timeout( loop_timer_hd, TASK_LOOP_TM_MS );
    }

    /**
     * 开启自动模式 且用户输入数据有效 且电池热管理参数有效
     * 开启消防模式
     * 以上情况可通过该过滤
     **/
    if ( !(   ( s_bat_sys_info.attr.auto_ctrl_enable == SF_TRUE && s_bat_sys_info.run.dat.valid == SF_TRUE &&  s_bat_sys_info.attr.bat_tmp_setting_valid == SF_TRUE ) \
           || ( usr_lc_ctrl_get_fire_fighting_enable() == SF_TRUE )))
    {
        return SF_FALSE;
    }

    /* 时间未到 */
    if (SF_FALSE == tick_timer_is_timeout(loop_timer_hd))
    {
        return SF_FALSE;
    }
    tick_timer_refresh( loop_timer_hd );

    return SF_TRUE;
}

/**
 * @brief  电池温度处理【供外部线程调用】
 * @return 
 */
void bat_temper_ctrl_task_loop( void )
{
    _bat_temper_new_bat_tmp_setting_update();
    
    if ( SF_FALSE == _bat_temper_ctrl_task_loop_access() )
        return;

    if ( usr_lc_ctrl_get_fire_fighting_enable() == SF_FALSE)
    {
        /* 非消防模式下，自动模式流程正常运行 */
        _bat_temper_ctrl_proc_schedule();
        _bat_temper_ctrl_reset_handle();
    }
    usr_lc_ctrl_proc();
}

static void _bat_temper_charge_discharge_allow_flag_fresh( void )
{
    if ( s_bat_sys_info.attr.auto_ctrl_enable == SF_FALSE )
    {
        /* 非自动模式下，允许充放电 */
        s_bat_sys_info.run.dis_charge_allow = SF_TRUE;
        return;
    }

    if ( s_bat_sys_info.run.boot_pre_hc_finish == SF_FALSE )
    {
        /* 开机预冷预热未完成 */
        s_bat_sys_info.run.dis_charge_allow = pre_heat_cool_get_charge_discharge_allow();
        return;
    }

    if ( s_bat_sys_info.attr.bat_tmp_setting.keep_tmper.enable == SF_TRUE )
    {
        /* 保温模式下，不进行定时预冷预热，允许充放电 */
        s_bat_sys_info.run.dis_charge_allow = SF_TRUE;
        return;
    }else{
        /* 非保温模式下，支持定时预冷预热 */
        s_bat_sys_info.run.dis_charge_allow = pre_heat_cool_get_charge_discharge_allow();
        return;
    }
}

/**
 * @brief 获取当前电池是否可以进行充放电
 * @return true：可进行充放电  false：不可进行充放电  
 */
bool bat_temper_get_allow_charge_discharge( void )
{
    _bat_temper_charge_discharge_allow_flag_fresh();
    return s_bat_sys_info.run.dis_charge_allow;
}

/**
 * @brief 获取首航热管理模式 【与液冷模式存在区别】
 * @return lc_sofar_mode_e 见枚举
 */
lc_sofar_mode_e bat_temper_get_lc_sofar_mode( void )
{
    if ( usr_lc_ctrl_get_fire_fighting_enable() == SF_TRUE)
    {
        /* 消防联动 */
        return LC_SF_MODE_FIRE_FIGHTING;
    }

    lc_work_mode_e work_mode = usr_lc_ctrl_get_lc_mode();

    switch ( s_bat_sys_info.run.sta.sch_sta )
    {
        case SCH_STA_IDLE:
            return LC_SF_MODE_STANDBY;

        case SCH_STA_PRE_HC:
            return  ( work_mode == LC_WORK_MODE_COOL       ) ? LC_SF_MODE_PRE_COOL     :
                    ( work_mode == LC_WORK_MODE_HEAT       ) ? LC_SF_MODE_PRE_HEAT     :
                    ( work_mode == LC_WORK_MODE_STANDBY    ) ? LC_SF_MODE_STANDBY      :
                    ( work_mode == LC_WORK_MODE_WATER_LOOP ) ? LC_SF_MODE_WATER_LOOP   : LC_SF_MODE_INVALID ;

        case SCH_STA_KEEP_TMP:
            return  ( work_mode == LC_WORK_MODE_COOL       ) ? LC_SF_MODE_KEEP_TEMPER :
                    ( work_mode == LC_WORK_MODE_HEAT       ) ? LC_SF_MODE_KEEP_TEMPER :
                    ( work_mode == LC_WORK_MODE_STANDBY    ) ? LC_SF_MODE_STANDBY     :
                    ( work_mode == LC_WORK_MODE_WATER_LOOP ) ? LC_SF_MODE_WATER_LOOP  : LC_SF_MODE_INVALID ;

        case SCH_STA_RUN_HEATING:
        case SCH_STA_RUN_COOLING:
        case SCH_STA_PRE_STOP:
            return ( work_mode == LC_WORK_MODE_COOL       ) ? LC_SF_MODE_COOLING    :
                   ( work_mode == LC_WORK_MODE_HEAT       ) ? LC_SF_MODE_HEATING    :
                   ( work_mode == LC_WORK_MODE_STANDBY    ) ? LC_SF_MODE_STANDBY    :
                   ( work_mode == LC_WORK_MODE_WATER_LOOP ) ? LC_SF_MODE_WATER_LOOP : LC_SF_MODE_INVALID ;
    }
    return LC_SF_MODE_INVALID;
}


/**
 * @brief  电池温控 液冷参数纠正
 * @param  [in] 无
 * @return true：成功  false：失败
 */
bool bat_temper_ctrl_lc_param_adjust_once( void )
{
    usr_lc_ctrl_param_adjust();
    return true;
}

/**
 * @brief  重新开启预冷预热
 * @param  [in] 无
 * @return 无
 * @note   
 */
void bat_temper_ctrl_reset( void )
{
    /* 热管理当前正在运行中，暂不允许重新运行 */
    /* 消防启动时，不允许复位 */
    /* 当前正在充放电 */
    if ( usr_lc_ctrl_get_lc_mode() != LC_WORK_MODE_STANDBY
        || usr_lc_ctrl_get_fire_fighting_enable() 
        || s_bat_sys_info.run.sta.curr_working == SF_TRUE)
    {
        BAT_TMPER_CTR_DEBUG("%s is running!!! forbid to restart!!!", __FUNCTION__);
        return;
    }
    BAT_TMPER_CTR_DEBUG("%s", __FUNCTION__);

    /* 预冷预热操作时间间隔 */
    static tick_timer_handle_t restart_enable_timer = NULL;

    if ( restart_enable_timer == NULL )
    {
        restart_enable_timer = tick_timer_create();
        tick_timer_set_timeout( restart_enable_timer, 600 * 1000 );
        tick_timer_set_timeout_sta( restart_enable_timer, SF_TRUE ); 
    }

    /* 一定时间内不可重复 复位热管理功能 */
    if ( false == tick_timer_is_timeout( restart_enable_timer ) )
    {
        return;
    }
    tick_timer_refresh( restart_enable_timer );

    /* 复位热管理系统 */
    s_bat_sys_info.run.cmd.tmper_ctrl_reset = SF_TRUE;
    BAT_TMPER_CTR_DEBUG("%s restart", __FUNCTION__);
}

/**
 * @brief  热管理组件 重置
 * @param  [in] 无
 * @return 无
 * @note   
 */
static void _bat_temper_ctrl_reset_handle( void )
{
    if ( s_bat_sys_info.run.cmd.tmper_ctrl_reset == SF_TRUE )
    {
        /* 重置 热管理组件，以达到再次预冷预热的效果 */
        bool virtual_debug_save = s_bat_sys_info.run.cmd.virtual_debug;
        
        memset( &s_bat_sys_info.run.cmd, 0, sizeof( s_bat_sys_info.run.cmd ));
        memset( &s_bat_sys_info.run.sta, 0, sizeof( s_bat_sys_info.run.sta ));
        if ( virtual_debug_save == SF_FALSE )
        {
            memset( &s_bat_sys_info.run.dat, 0, sizeof( s_bat_sys_info.run.dat ));
        }
        s_bat_sys_info.run.cmd.virtual_debug = virtual_debug_save;

        usr_lc_ctrl_reset();
        pre_heat_cool_reset();
        running_cool_reset();
        pre_stop_reset();
    }
}

/**
 * @brief 热管理控制 模块使能或关闭
 * @param  [in] enable  使能
 * @return true：成功  false：失败
 */
bool bat_temper_ctrl_set_enable( bool enable )
{
    s_bat_sys_info.attr.auto_ctrl_enable = enable;
    return SF_TRUE;
}

/**
 * @brief 启动消防模式
 * @param  [in] enable  使能
 * @return true：成功  false：失败
 */
bool bat_temper_set_fire_fighting_mode( bool enable )
{
    usr_lc_ctrl_set_fire_fighting_enable( enable );
    return SF_TRUE;
}

/**
 * @brief 热管理控制 参数设置 
 * @param  [in] p_bat_tmp_setting  热管理控制参数
 * @return true：成功  false：失败
 */
bool bat_temper_set_bat_tmp_setting( bat_tmp_setting_t *p_bat_tmp_setting )
{
    if( s_bat_sys_info.run.cmd.new_bat_tmp_setting_valid == SF_TRUE )
    {
        return SF_FALSE;
    }
    s_bat_sys_info.run.cmd.new_bat_tmp_setting_valid = SF_TRUE;
    s_bat_sys_info.run.cmd.new_bat_tmp_setting = *p_bat_tmp_setting;

    return SF_TRUE;
}

/** 
 * @brief  用户 热管理设置 更新生效
 * @param  [in] 无
 * @return 
 */
static void _bat_temper_new_bat_tmp_setting_update( void )
{
    if( s_bat_sys_info.run.cmd.new_bat_tmp_setting_valid )
    {
        uint16_t last_keep_tmp_enable = s_bat_sys_info.attr.bat_tmp_setting.keep_tmper.enable;

        s_bat_sys_info.run.cmd.new_bat_tmp_setting_valid = SF_FALSE;
        s_bat_sys_info.attr.bat_tmp_setting = s_bat_sys_info.run.cmd.new_bat_tmp_setting;
        
        pre_heat_cool_setting( &s_bat_sys_info.attr.bat_tmp_setting.pre_cool,
                               &s_bat_sys_info.attr.bat_tmp_setting.pre_heat,
                               &s_bat_sys_info.attr.bat_tmp_setting.dis_work_tmp);
        running_cool_setting( s_bat_sys_info.attr.bat_tmp_setting.bat_Tds,
                              s_bat_sys_info.attr.bat_tmp_setting.bat_Tdm,
                              &s_bat_sys_info.attr.bat_tmp_setting.start_cool,
                              &s_bat_sys_info.attr.bat_tmp_setting.stop_cool,
                              &s_bat_sys_info.attr.bat_tmp_setting.cooling );
        running_heat_setting( s_bat_sys_info.attr.bat_tmp_setting.pre_heat.startup_bat_Tmean, 
                              s_bat_sys_info.attr.bat_tmp_setting.pre_heat.startup_bat_Tmean + s_bat_sys_info.attr.bat_tmp_setting.pre_heat.exit_ret_tmp );
        keep_temper_set( s_bat_sys_info.attr.bat_tmp_setting.keep_tmper.heating_startup_temper, 
                         s_bat_sys_info.attr.bat_tmp_setting.keep_tmper.heating_exit_temper,  
                         s_bat_sys_info.attr.bat_tmp_setting.keep_tmper.cooling_startup_temper,  
                         s_bat_sys_info.attr.bat_tmp_setting.keep_tmper.cooling_exit_temper );

        if ( s_bat_sys_info.run.sta.sch_sta == SCH_STA_KEEP_TMP )
        {
            /* 保温状态下，关闭保温模式 */
            if ( ( last_keep_tmp_enable == SF_TRUE)
                && (s_bat_sys_info.attr.bat_tmp_setting.keep_tmper.heating_startup_temper) ) 
            {
                _bat_temper_set_schedule_sta( SCH_STA_IDLE );
                keep_temper_reset();
            }
        }

        s_bat_sys_info.attr.bat_tmp_setting_valid = SF_TRUE;
    }
}

static bool _bat_temper_ctrl_run_sta_proc( int32_t bat_current_01A )
{
    if ( s_bat_sys_info.run.sta.curr_working == SF_TRUE )
    {
        if ( bat_current_01A < s_bat_sys_info.attr.bat_tmp_setting.standby_cur )
        {
            BAT_TMPER_CTR_DEBUG( "running sta change: 0" );
            s_bat_sys_info.run.sta.curr_working = SF_FALSE;
        }
    }else{
        if ( bat_current_01A > (s_bat_sys_info.attr.bat_tmp_setting.standby_cur + 2) )
        {
            BAT_TMPER_CTR_DEBUG( "running sta change: 1" );
            s_bat_sys_info.run.sta.curr_working = SF_TRUE;
        }
    }
    return s_bat_sys_info.run.sta.curr_working;
}

sf_ret_t bat_temper_ctrl_vir_debug( char *vir_cmd, char *vir_val_str )
{
    double vir_val = 0;
    
    if ( vir_cmd == NULL )
    {
        return SF_ERR_PARA;
    }

    // BAT_TMPER_CTR_DEBUG("vir_cmd:%s : vir_val_str:%s", vir_cmd, vir_val_str );
    if ( vir_val_str != NULL )
    {
        vir_val = atof( vir_val_str );
    }

    if ( 0 == strcmp( vir_cmd, "en" ) && vir_val_str != NULL)
    {
        s_bat_sys_info.run.cmd.virtual_debug = (vir_val == 1)? SF_TRUE: SF_FALSE;
        

    }else if ( 0 == strcmp( vir_cmd, "Tmax" ) && vir_val_str != NULL)
    {
        s_bat_sys_info.run.dat.bat_tmp_max = vir_val * 10;

    }else if ( 0 == strcmp( vir_cmd, "Tmean" ) && vir_val_str != NULL)
    {
        s_bat_sys_info.run.dat.bat_tmp_mean = vir_val * 10;

    }else if ( 0 == strcmp( vir_cmd, "Tmin" ) && vir_val_str != NULL)
    {
        s_bat_sys_info.run.dat.bat_tmp_min = vir_val * 10;

    }else if ( 0 == strcmp( vir_cmd, "Tenv" ) && vir_val_str != NULL)
    {
        s_bat_sys_info.run.dat.env_tmp = vir_val * 10;

    }else if ( 0 == strcmp( vir_cmd, "curr" ) && vir_val_str != NULL)
    {
        s_bat_sys_info.run.dat.bat_current_01A = vir_val * 10;

    }else if ( 0 == strcmp( vir_cmd, "start" ))
    {
        s_bat_sys_info.run.dat.valid = SF_TRUE;

    }else if ( 0 == strcmp( vir_cmd, "stop" ))
    {
        s_bat_sys_info.run.dat.valid = SF_FALSE;

    }else if ( 0 == strcmp( vir_cmd, "reset" ))
    {
        s_bat_sys_info.run.cmd.tmper_ctrl_reset = SF_TRUE;
        s_bat_sys_info.run.boot_pre_hc_finish = SF_FALSE;
    }else if ( 0 == strcmp( vir_cmd, "list" ))
    {
        sdk_log_printf("vir enable:%d", s_bat_sys_info.run.cmd.virtual_debug );
        sdk_log_printf(" valid:%d"   , s_bat_sys_info.run.dat.valid );
        sdk_log_printf(" Tmax:%d.%d" , s_bat_sys_info.run.dat.bat_tmp_max/10, s_bat_sys_info.run.dat.bat_tmp_max %10 );
        sdk_log_printf(" Tmean:%d.%d" , s_bat_sys_info.run.dat.bat_tmp_mean/10, s_bat_sys_info.run.dat.bat_tmp_mean %10 );
        sdk_log_printf(" Tmin:%d.%d" , s_bat_sys_info.run.dat.bat_tmp_min/10, s_bat_sys_info.run.dat.bat_tmp_min %10 );
        sdk_log_printf(" Tenv:%d.%d" , s_bat_sys_info.run.dat.env_tmp/10, s_bat_sys_info.run.dat.env_tmp %10 );
        sdk_log_printf(" Curr:%d.%d\r\n" , s_bat_sys_info.run.dat.bat_current_01A/10, s_bat_sys_info.run.dat.bat_current_01A %10 );
    }else{
        return SF_ERR_PARA;
    }

    return SF_OK;
}

