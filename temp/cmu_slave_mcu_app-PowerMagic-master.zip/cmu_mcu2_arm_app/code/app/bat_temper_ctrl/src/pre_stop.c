#include "pre_stop.h"
#include "tick_timer.h"
#include "lc_data_type.h"
#include "usr_lc_ctrl.h"
#include "bat_temper_def.h"
#include "bat_tmp_ctrl_cfg.h"
#include "proj_cfg.h"

/*---------------------------------------------- 预停止配置 -------------------------------------------------------*/
#ifndef SIMIU_BAT_TEMP_ENABLE
#error "Not define SIMIU_BAT_TEMP_ENABLE, incldue proj_cfg.h"
#endif

#if ( SIMIU_BAT_TEMP_ENABLE == 0 )
#define PRE_STOP_NOR_MODE_MAX_TM_MS                     ( 3600 * 1000 )      //< 预停机 【运行转停机】的最长时间，单位：1ms 【正常】
#define PRE_STOP_LOW_PER_MODE_MAX_TM_MS                 ( 7200 * 1000 )      //< 预停机 【运行转停机】的最长时间，单位：1ms 【低性能】
#else
#define PRE_STOP_NOR_MODE_MAX_TM_MS                     ( 360 * 1000 )       //< 预停机 【运行转停机】的最长时间，单位：1ms 【正常】【调试状态下将时间缩短】
#define PRE_STOP_LOW_PER_MODE_MAX_TM_MS                 ( 720 * 1000 )       //< 预停机 【运行转停机】的最长时间，单位：1ms 【低性能】【调试状态下将时间缩短】
#endif

#define PRE_STOP_TMAX_TMIN_DIST_TMPER                   40                  //< 最大温度 和 最小温度 温差，单位：0.1℃
#define PRE_STOP_COOLING_TMEAN_TMPER_IN_NOR             350                 //< 平均温度 和 目标温度 温差，单位：0.1℃
#define PRE_STOP_COOLING_TMEAN_TMPER_IN_LOW_PER         320                 //< 平均温度 和 目标温度 温差，单位：0.1℃

/*-------------------------------------------- 预停机制冷配置 -----------------------------------------------------*/
#define PRE_STOP_COOLING_LC_TMP                         190                 //< 预停机 制冷供液温度，单位：0.1℃
#define PRE_STOP_COOLING_LC_FLOW                        100                 //< 预停机 制冷供液流量，单位：1%

/*-------------------------------------------- 预停机自循环配置 ----------------------------------------------------*/
#define PRE_STOP_WATER_LOOP_LC_FLOW                     100                 //< 预停机 自循环供液流量，单位：1%

/* Tmax、Tmin温差过大 */
#define BAT_Tmax_Tmin_DIS_TMP_OVER( bat_temper_min, bat_temper_max )   ( ((bat_temper_max) - (bat_temper_min)) >= PRE_STOP_TMAX_TMIN_DIST_TMPER )
/* Tmean温度过高 */
#define BAT_Tmean_OVER_TMP_IN_NOR( bat_temper_mean )                   ((bat_temper_mean) >= PRE_STOP_COOLING_TMEAN_TMPER_IN_NOR )
#define BAT_Tmean_OVER_TMP_IN_LOW_PER( bat_temper_mean )               ((bat_temper_mean) >= PRE_STOP_COOLING_TMEAN_TMPER_IN_LOW_PER )

static struct 
{
    tick_timer_handle_t      pre_stop_timer;
    pre_stop_sta_e           sta;
} s_pre_stop_usr_info = { .pre_stop_timer = NULL, .sta = PRE_STOP_STA_IDLE };

/**
 * @brief  重新刷新 热管理控制设置 相关设置和句柄
 * @param  [in] 无
 * @return 
 */
sf_ret_t pre_stop_init( void )
{
    BAT_TMPER_CTR_DEBUG("%s", __FUNCTION__);

    s_pre_stop_usr_info.pre_stop_timer = tick_timer_create();
    if ( s_pre_stop_usr_info.pre_stop_timer == NULL )
    {
        BAT_TMPER_CTR_ERROR( "pre_stop_timer == NULL!!!" );
        return SF_ERR_NO_OBJECT;
    }

    return SF_OK;
}

void pre_stop_reset( void )
{
    s_pre_stop_usr_info.sta      = PRE_STOP_STA_IDLE;
}

static void _pre_stop_set_sta( pre_stop_sta_e sta )
{
    if ( s_pre_stop_usr_info.sta == sta )
    {
        return;
    }
    s_pre_stop_usr_info.sta = sta;

    BAT_TMPER_CTR_DEBUG( "PRE_STOP_STA :%s",    (sta == PRE_STOP_STA_IDLE       )? "PRE_STOP_STA_IDLE"       :
                                                (sta == PRE_STOP_STA_COOLING    )? "PRE_STOP_STA_COOLING"    :
                                                (sta == PRE_STOP_STA_WATER_LOOP )? "PRE_STOP_STA_WATER_LOOP" :
                                                (sta == PRE_STOP_STA_FINISH     )? "PRE_STOP_STA_FINISH"     : "PRE_STOP_STA_UNKNOW" );
    switch ( sta )
    {
        case PRE_STOP_STA_IDLE:
            break;
        case PRE_STOP_STA_COOLING:
            usr_lc_ctrl_set_lc_param( LC_WORK_MODE_COOL, PRE_STOP_COOLING_LC_TMP, PRE_STOP_COOLING_LC_FLOW );
            break;
        case PRE_STOP_STA_WATER_LOOP:
            usr_lc_ctrl_set_lc_mode( LC_WORK_MODE_WATER_LOOP );
            break;
        case PRE_STOP_STA_FINISH:
            usr_lc_ctrl_set_lc_mode( LC_WORK_MODE_STANDBY );
            break;
        default:
            break;
    }
}

pre_stop_sta_e pre_stop_process( temper_t lc_env_tmp, temper_t bat_tmp_mean, temper_t bat_tmp_min, temper_t bat_tmp_max )
{
    static bool lc_low_performance = SF_FALSE;          // 液冷性能降低

    if ( s_pre_stop_usr_info.sta == PRE_STOP_STA_IDLE )
    {
        if ( LC_LOW_PERFORMANCE( lc_env_tmp ) )
        {
            lc_low_performance = SF_TRUE;
            tick_timer_set_timeout( s_pre_stop_usr_info.pre_stop_timer , PRE_STOP_LOW_PER_MODE_MAX_TM_MS );
        }else{
            lc_low_performance = SF_FALSE;
            tick_timer_set_timeout( s_pre_stop_usr_info.pre_stop_timer , PRE_STOP_NOR_MODE_MAX_TM_MS );
        }
    }

    if ( tick_timer_is_timeout( s_pre_stop_usr_info.pre_stop_timer ) )
    {
        /* 超时切为待机 */
        _pre_stop_set_sta( PRE_STOP_STA_FINISH );
        return s_pre_stop_usr_info.sta;
    }

    /* 电池总体较热 */
    if (   ( lc_low_performance == SF_FALSE && BAT_Tmean_OVER_TMP_IN_NOR( bat_tmp_mean ))
        || ( lc_low_performance == SF_TRUE  && BAT_Tmean_OVER_TMP_IN_LOW_PER( bat_tmp_mean )))
    {
        /* 制冷 */
        _pre_stop_set_sta( PRE_STOP_STA_COOLING );
        return s_pre_stop_usr_info.sta;
    }else{
        /* 电池温差较大 */
        if ( BAT_Tmax_Tmin_DIS_TMP_OVER( bat_tmp_min, bat_tmp_max ) )
        {
            /* 自循环 */
            _pre_stop_set_sta( PRE_STOP_STA_WATER_LOOP );
            return s_pre_stop_usr_info.sta;
        }
    }
    _pre_stop_set_sta( PRE_STOP_STA_FINISH );
    return s_pre_stop_usr_info.sta;
}
