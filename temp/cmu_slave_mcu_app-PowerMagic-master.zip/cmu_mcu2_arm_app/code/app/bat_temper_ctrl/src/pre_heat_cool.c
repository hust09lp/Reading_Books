
#include "pre_heat_cool.h"
#include "range_check.h"
#include "tick_timer.h"
#include "bool_filter.h"
#include "usr_lc_ctrl.h"

#include "bat_tmp_ctrl_api.h"
#include "bat_tmp_ctrl_cfg.h"
#include "bat_temper_def.h"

static struct {
    pre_cool_t       *p_pre_cool;
    pre_heat_t       *p_pre_heat;
    dis_work_tmp_t   *p_dis_work_tmp;

    usr_uint8_t             temper_danger_flag;
    tick_timer_handle_t     pre_heat_cool_max_tm_hd;
    pre_hc_sta_e            sta;
} s_pre_hc_usr_info =   { 
                            .p_pre_cool              = NULL,
                            .p_pre_heat              = NULL,
                            .p_dis_work_tmp          = NULL,
                            .temper_danger_flag      = USR_U8_VAL_INVALID,
                            .pre_heat_cool_max_tm_hd = NULL,
                            .sta                     = PRE_HC_STA_IDLE
                        };

static void _pre_heat_cool_set_sta( pre_hc_sta_e sta );
static void _pre_heat_cool_set_temper_danger_flag( uint8_t temper_danger_flag );
static void _pre_heat_cool_abort( bool bat_curr_work );
static void _check_danger_temper( temper_t bat_tmp_mean, temper_t bat_tmp_min, temper_t bat_tmp_max );
static void _check_exit_pre_heat_cool( temper_t bat_tmp_mean, temper_t bat_tmp_min, temper_t bat_tmp_max );
static void _checking_pre_heat_cool( temper_t env_tmp, temper_t bat_tmp_mean, temper_t bat_tmp_min, temper_t bat_tmp_max );

sf_ret_t pre_heat_cool_init( void )
{
    s_pre_hc_usr_info.pre_heat_cool_max_tm_hd = tick_timer_create();

    if ( s_pre_hc_usr_info.pre_heat_cool_max_tm_hd == NULL )
    {
        BAT_TMPER_CTR_DEBUG( "pre_heat_cool_max_tm_hd == NULL" );
        return SF_ERR_NO_OBJECT;
    }
    return SF_OK;
}

void pre_heat_cool_setting( pre_cool_t *p_pre_cool, pre_heat_t *p_pre_heat, dis_work_tmp_t *p_dis_work_tmp )
{
    s_pre_hc_usr_info.p_pre_cool     = p_pre_cool;
    s_pre_hc_usr_info.p_pre_heat     = p_pre_heat;
    s_pre_hc_usr_info.p_dis_work_tmp = p_dis_work_tmp;
}

void pre_heat_cool_reset( void )
{
    _pre_heat_cool_set_sta( PRE_HC_STA_IDLE );
}

bool pre_heat_cool_get_charge_discharge_allow( void )
{
    /* 当电池不处于危险温度时候，才允许禁充禁放 */
    return ( s_pre_hc_usr_info.temper_danger_flag == 0 )? SF_TRUE : SF_FALSE;
}

pre_hc_sta_e pre_heat_cool_get_sta( void )
{
    return s_pre_hc_usr_info.sta;
}

pre_hc_sta_e pre_heat_cool_proc( bool bat_curr_work, temper_t env_tmp, temper_t bat_tmp_mean, temper_t bat_tmp_min, temper_t bat_tmp_max )
{
    switch ( s_pre_hc_usr_info.sta )
    {
        case PRE_HC_STA_IDLE:
            _checking_pre_heat_cool( env_tmp, bat_tmp_mean, bat_tmp_min, bat_tmp_max );
            break;

        case PRE_HC_STA_HEATING:
        case PRE_HC_STA_COOLING_NOR:
        case PRE_HC_STA_COOLING_LOW_PERF:
            _check_exit_pre_heat_cool( bat_tmp_mean, bat_tmp_min, bat_tmp_max );
            _check_danger_temper( bat_tmp_mean, bat_tmp_min, bat_tmp_max );
            _pre_heat_cool_abort( bat_curr_work );
            break;

        case PRE_HC_STA_FINISH:
            break;
        default:
            break;
    } 
    return s_pre_hc_usr_info.sta;
}

static void _pre_heat_cool_abort( bool bat_curr_work )
{
    if ( (bat_curr_work == SF_TRUE) && ( s_pre_hc_usr_info.temper_danger_flag == 0 ) )
    {
        _pre_heat_cool_set_sta( PRE_HC_STA_FINISH );
    }
}

static void _check_danger_temper( temper_t bat_tmp_mean, temper_t bat_tmp_min, temper_t bat_tmp_max )
{
    if ( ( s_pre_hc_usr_info.sta == PRE_HC_STA_HEATING) )
    {
        /* 预热 */
        if (   ( bat_tmp_min  > s_pre_hc_usr_info.p_dis_work_tmp->pre_heating - PRE_HEAT_COOL_DELTA_TMP )
            && ( bat_tmp_mean > s_pre_hc_usr_info.p_dis_work_tmp->pre_heating ) )
        {
            /**
             *  预热 退出底线温度
             *  Tmin  > Tpre-heating3 - ΔT 
             *  Tmean > Tpre-heating3
             **/
            _pre_heat_cool_set_temper_danger_flag( 0 );
        }else{
             /* 仍处于底线温度之间 */
            _pre_heat_cool_set_temper_danger_flag( 1 );
        }
    }
    else if ( s_pre_hc_usr_info.sta == PRE_HC_STA_COOLING_NOR )
    {
        /* 正常预冷 */
        if (   ( bat_tmp_max  <  s_pre_hc_usr_info.p_dis_work_tmp->pre_cooling + PRE_HEAT_COOL_DELTA_TMP  )
            && ( bat_tmp_mean <= s_pre_hc_usr_info.p_dis_work_tmp->pre_cooling ))
        {
            /**
             *  预冷 退出底线温度
             *  Tmax  < Tpre-cooling3 + ΔT 
             *  Tmean <= Tpre-cooling3 
             **/
            _pre_heat_cool_set_temper_danger_flag( 0 );
        }else{
             /* 仍处于底线温度之间 */
            _pre_heat_cool_set_temper_danger_flag( 1 );
        }
    }
    else if ( s_pre_hc_usr_info.sta == PRE_HC_STA_COOLING_LOW_PERF ) 
    {
        /* 低性能模式下预冷 */
        if (   ( bat_tmp_max  <   s_pre_hc_usr_info.p_dis_work_tmp->pre_cooling + PRE_HEAT_COOL_DELTA_TMP )
            && ( bat_tmp_mean <=  s_pre_hc_usr_info.p_dis_work_tmp->pre_cooling - PRE_HEAT_COOL_DELTA_TMP ))
        {
            /**
             *  预冷 退出底线温度
             *  Tmax  < Tpre-cooling3 + ΔT 
             *  Tmean <= Tpre-cooling3 - ΔT
             **/
            _pre_heat_cool_set_temper_danger_flag( 0 );
        }else{
             /* 仍处于底线温度之间 */
            _pre_heat_cool_set_temper_danger_flag( 1 );
        }
    }
}

static void _pre_heat_cool_set_temper_danger_flag( uint8_t temper_danger_flag )
{
    if ( s_pre_hc_usr_info.temper_danger_flag != temper_danger_flag ) 
    {
        BAT_TMPER_CTR_DEBUG( "temper_danger_flag:%d", temper_danger_flag );
    }
    s_pre_hc_usr_info.temper_danger_flag = temper_danger_flag;
}

static void _pre_heat_cool_set_sta( pre_hc_sta_e sta )
{
    if ( s_pre_hc_usr_info.sta == sta )
    {
        return;
    }

    s_pre_hc_usr_info.sta = sta;
    BAT_TMPER_CTR_DEBUG( "PRE_HC_STA:%s", (sta == PRE_HC_STA_IDLE             )? "PRE_HC_STA_IDLE"             :
                                          (sta == PRE_HC_STA_HEATING          )? "PRE_HC_STA_HEATING"          :
                                          (sta == PRE_HC_STA_COOLING_NOR      )? "PRE_HC_STA_COOLING_NOR"      :
                                          (sta == PRE_HC_STA_COOLING_LOW_PERF )? "PRE_HC_STA_COOLING_LOW_PERF" :
                                          (sta == PRE_HC_STA_FINISH           )? "PRE_HC_STA_FINISH"           : "PRE_HC_STA_UNKNOW" );
    switch (sta)
    {
    case PRE_HC_STA_IDLE:
        break;
    case PRE_HC_STA_HEATING:
        usr_lc_ctrl_set_lc_param( LC_WORK_MODE_HEAT, s_pre_hc_usr_info.p_pre_heat->lc_tmp, s_pre_hc_usr_info.p_pre_heat->lc_flow );
        tick_timer_set_timeout( s_pre_hc_usr_info.pre_heat_cool_max_tm_hd, BAT_PRE_HEAT_COOL_MAX_TM_MS );
        break;
    case PRE_HC_STA_COOLING_NOR:
    case PRE_HC_STA_COOLING_LOW_PERF:
        usr_lc_ctrl_set_lc_param( LC_WORK_MODE_COOL, s_pre_hc_usr_info.p_pre_cool->lc_tmp, s_pre_hc_usr_info.p_pre_cool->lc_flow );
        tick_timer_set_timeout( s_pre_hc_usr_info.pre_heat_cool_max_tm_hd, BAT_PRE_HEAT_COOL_MAX_TM_MS );
        break;
    case PRE_HC_STA_FINISH:
        usr_lc_ctrl_set_lc_mode( LC_WORK_MODE_STANDBY );
        _pre_heat_cool_set_temper_danger_flag( 0 );
        break;
    default:
        break;
    }
}

static void _check_exit_pre_heat_cool( temper_t bat_tmp_mean, temper_t bat_tmp_min, temper_t bat_tmp_max )
{
    if ( s_pre_hc_usr_info.temper_danger_flag == 1 )
    {
        /* 温度处于危险区间，不退出预冷预热 */
        return;
    }

    if ( tick_timer_is_timeout( s_pre_hc_usr_info.pre_heat_cool_max_tm_hd ) )
    {
        /* 温度处于非危险，预冷预热超时退出 */
        _pre_heat_cool_set_sta( PRE_HC_STA_FINISH );
        return;
    }
    
    pre_cool_t *p_pre_cool = s_pre_hc_usr_info.p_pre_cool;
    pre_heat_t *p_pre_heat = s_pre_hc_usr_info.p_pre_heat;

    if (   ( s_pre_hc_usr_info.sta == PRE_HC_STA_HEATING) 
        && ( bat_tmp_min  > ( p_pre_heat->startup_bat_Tmin  + p_pre_heat->exit_ret_tmp ))
        && ( bat_tmp_mean > ( p_pre_heat->startup_bat_Tmean + p_pre_heat->exit_ret_tmp ) ))
    {
        /**
         *  预热 
         *  Tmin  > Tpre-heating2 - ΔT 
         *  Tmean > Tpre-heating2
         **/
        _pre_heat_cool_set_sta( PRE_HC_STA_FINISH );
    }
    else if (    ( s_pre_hc_usr_info.sta == PRE_HC_STA_COOLING_NOR ) 
              && ( bat_tmp_max  < (p_pre_cool->startup_bat_Tmax  - p_pre_cool->exit_ret_tmp))
              && ( bat_tmp_mean <= (p_pre_cool->startup_bat_Tmean - p_pre_cool->exit_ret_tmp) ))
    {
        /**
         *  正常预冷 
         *  Tmax  <  Tpre-cooling2 + 2ΔT 
         *  Tmean <= Tpre-cooling2 
         **/
        _pre_heat_cool_set_sta( PRE_HC_STA_FINISH );
    }
    else if (    ( s_pre_hc_usr_info.sta == PRE_HC_STA_COOLING_LOW_PERF ) 
              && ( bat_tmp_max  < (p_pre_cool->startup_bat_Tmax  - p_pre_cool->exit_ret_tmp ))
              && ( bat_tmp_mean <= (p_pre_cool->startup_bat_Tmean - p_pre_cool->exit_ret_tmp - PRE_HEAT_COOL_DELTA_TMP )))
    {
        /**
         *  非理想情况下预冷，需要将电池平均温度降得更冷
         *  Tmax  <  Tpre-cooling2 + 2ΔT 
         *  Tmean <= Tpre-cooling2 - ΔT
         **/
        _pre_heat_cool_set_sta( PRE_HC_STA_FINISH );
    }
    return;
}

static void _checking_pre_heat_cool( temper_t env_tmp, temper_t bat_tmp_mean, temper_t bat_tmp_min, temper_t bat_tmp_max )
{
    pre_cool_t *p_pre_cool = s_pre_hc_usr_info.p_pre_cool;
    pre_heat_t *p_pre_heat = s_pre_hc_usr_info.p_pre_heat;

    if ( (bat_tmp_mean < p_pre_heat->startup_bat_Tmean ) || (bat_tmp_min < p_pre_heat->startup_bat_Tmin )  )
    {
        /* 预热 */
        _pre_heat_cool_set_sta( PRE_HC_STA_HEATING );
    } 
    else if ( ( !LC_LOW_PERFORMANCE( env_tmp )) && ( bat_tmp_mean > ( p_pre_cool->startup_bat_Tmean) ))   
    {
        /* T4 < 45  , Tmean > Tpre-cooling1 + ΔT */
        /* 正常预冷 */
        _pre_heat_cool_set_sta( PRE_HC_STA_COOLING_NOR );
    }
    else if ( ( LC_LOW_PERFORMANCE( env_tmp ) ) && ( bat_tmp_mean > (p_pre_cool->startup_bat_Tmean  - PRE_HEAT_COOL_DELTA_TMP) ))
    {
        /* T4 >= 45 , Tmean > Tpre-cooling1 */
        /* 非理想情况下预冷 */
        _pre_heat_cool_set_sta( PRE_HC_STA_COOLING_LOW_PERF );
    }else{
        /* 正常温度 */
        _pre_heat_cool_set_sta( PRE_HC_STA_FINISH );
    }
}
