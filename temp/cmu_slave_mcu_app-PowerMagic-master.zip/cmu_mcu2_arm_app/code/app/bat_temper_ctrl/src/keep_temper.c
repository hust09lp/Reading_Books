#include "keep_temper.h"
#include "usr_lc_ctrl.h"

#include "bat_tmp_ctrl_cfg.h"
#include "bat_temper_def.h"

#define KEEP_TMP_HEATING_STARTUP_TMP                T_heat_keeping1
#define KEEP_TMP_HEATING_EXIT_TMP                   T_heat_keeping2
#define KEEP_TMP_HEATING_LC_TMP                     250
#define KEEP_TMP_HEATING_LC_FLOW                    100

#define KEEP_TMP_COOLING_STARTUP_TMP                T_cool_keeping1
#define KEEP_TMP_COOLING_EXIT_TMP                   T_cool_keeping2
#define KEEP_TMP_COOLING_LC_TMP                     250
#define KEEP_TMP_COOLING_LC_FLOW                    100

typedef enum
{
    KEEP_TEMPER_STA_IDLE,
    KEEP_TEMPER_STA_HEATING,
    KEEP_TEMPER_STA_COOLING,
} keep_temper_sta_e;

struct {
    keep_temper_sta_e  sta;
    temper_t start_heating_tmp;
    temper_t stop_heating_tmp;
    temper_t start_cooling_tmp;
    temper_t stop_cooling_tmp;
} s_keep_temper_usr_info = { 
                                .sta = KEEP_TEMPER_STA_IDLE,
                                .start_heating_tmp = KEEP_TMP_HEATING_STARTUP_TMP,
                                .stop_heating_tmp  = KEEP_TMP_HEATING_EXIT_TMP,
                                .start_cooling_tmp = KEEP_TMP_COOLING_STARTUP_TMP,
                                .stop_cooling_tmp  = KEEP_TMP_COOLING_EXIT_TMP,
                            };

static void keep_temper_set_sta( keep_temper_sta_e sta );

void keep_temper_init( void )
{
    s_keep_temper_usr_info.sta = KEEP_TEMPER_STA_IDLE;
}

void keep_temper_reset( void )
{
    keep_temper_set_sta( KEEP_TEMPER_STA_IDLE );
}

void keep_temper_set( temper_t start_heating_tmp, temper_t stop_heating_tmp, temper_t start_cooling_tmp, temper_t stop_cooling_tmp )
{
    s_keep_temper_usr_info.start_heating_tmp = start_heating_tmp;
    s_keep_temper_usr_info.stop_heating_tmp  = stop_heating_tmp;
    s_keep_temper_usr_info.start_cooling_tmp = start_cooling_tmp;
    s_keep_temper_usr_info.stop_cooling_tmp  = stop_cooling_tmp;
}

void keep_temper_proc( bool bat_curr_work, temper_t bat_tmp_mean, temper_t bat_tmp_min, temper_t bat_tmp_max )
{
    if ( s_keep_temper_usr_info.sta == KEEP_TEMPER_STA_IDLE )
    {
        if ( bat_tmp_min < s_keep_temper_usr_info.start_heating_tmp ) 
        {
            /* 开始制热 */
            keep_temper_set_sta( KEEP_TEMPER_STA_HEATING );
        } 
        else if ( bat_tmp_max > s_keep_temper_usr_info.start_cooling_tmp )
        {
            /* 开始制冷 */
            keep_temper_set_sta( KEEP_TEMPER_STA_COOLING );
        }
    } else if ( s_keep_temper_usr_info.sta == KEEP_TEMPER_STA_HEATING )
    {
        if ( bat_tmp_min >= s_keep_temper_usr_info.stop_heating_tmp )
        {
            /* 退出制热 */
            keep_temper_set_sta( KEEP_TEMPER_STA_IDLE );
        }
    } else if ( s_keep_temper_usr_info.sta == KEEP_TEMPER_STA_COOLING )
    {
        if ( bat_tmp_max <= s_keep_temper_usr_info.stop_cooling_tmp )
        {
            /* 退出制冷 */
            keep_temper_set_sta( KEEP_TEMPER_STA_IDLE );
        }
    }
}

static void keep_temper_set_sta( keep_temper_sta_e sta )
{
    if ( s_keep_temper_usr_info.sta == sta )
    {
        return;
    }

    s_keep_temper_usr_info.sta = sta;
    BAT_TMPER_CTR_DEBUG( "KEEP_TMP_STA :%s",    (sta == KEEP_TEMPER_STA_IDLE    )? "KEEP_TEMPER_STA_IDLE"    :
                                                (sta == KEEP_TEMPER_STA_HEATING )? "KEEP_TEMPER_STA_HEATING" :
                                                (sta == KEEP_TEMPER_STA_COOLING )? "KEEP_TEMPER_STA_COOLING" : "KEEP_TEMPER_STA_UNKNOW" );
    switch (sta)
    {
    case KEEP_TEMPER_STA_IDLE:
        usr_lc_ctrl_set_lc_mode( LC_WORK_MODE_STANDBY );
        break;
    case KEEP_TEMPER_STA_HEATING:
        usr_lc_ctrl_set_lc_param( LC_WORK_MODE_HEAT, KEEP_TMP_HEATING_LC_TMP, KEEP_TMP_HEATING_LC_FLOW );
        break;
    case KEEP_TEMPER_STA_COOLING:
        usr_lc_ctrl_set_lc_param( LC_WORK_MODE_COOL, KEEP_TMP_COOLING_LC_TMP, KEEP_TMP_COOLING_LC_FLOW );
        break;
    default:
        break;
    }
}
