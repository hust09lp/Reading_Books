#include "running_heat.h"
#include "usr_lc_ctrl.h"

#include "bat_temper_def.h"

#define RUN_HEAT_LC_TMPER           250                 //< 充放电过程中制热温度，单位：0.1℃
#define RUN_HEAT_LC_FLOW            100                 //< 充放电过程中制热水泵流速，单位：1%

static struct 
{
    struct {
        temper_t startup_tmp;
        temper_t exit_tmp;
    } attr;
    
    struct {
        run_heat_sta_e sta;
    } run;
} s_run_heat_usr_info = { .run = { .sta = RUN_HEAT_STA_IDLE } };

static void _running_heat_set_sta( run_heat_sta_e sta );

void running_heat_init( void )
{
    s_run_heat_usr_info.run.sta = RUN_HEAT_STA_IDLE;
}

void running_heat_setting( temper_t startup_tmp, temper_t exit_tmp )
{
    s_run_heat_usr_info.attr.startup_tmp = startup_tmp;
    s_run_heat_usr_info.attr.exit_tmp    = exit_tmp;
}

void running_heating_reset( void )
{
    _running_heat_set_sta( RUN_HEAT_STA_IDLE );
}

run_heat_sta_e running_heating_get_sta( void )
{
    return s_run_heat_usr_info.run.sta;
}

run_heat_sta_e running_heating_process( temper_t bat_tmp_mean )
{
    static bool is_heating = SF_FALSE;

    if ( s_run_heat_usr_info.run.sta == RUN_HEAT_STA_IDLE )
    {
        if ( bat_tmp_mean < s_run_heat_usr_info.attr.startup_tmp )
        {
            /* 开始制热 */
            _running_heat_set_sta( RUN_HEAT_STA_HEATING );
        }
    } else if ( s_run_heat_usr_info.run.sta == RUN_HEAT_STA_HEATING )
    {
        if ( bat_tmp_mean >= s_run_heat_usr_info.attr.exit_tmp )
        {
            /* 退出制热 */
            _running_heat_set_sta( RUN_HEAT_STA_FINISH );
        }
    } else if ( s_run_heat_usr_info.run.sta == RUN_HEAT_STA_FINISH )
    {
        _running_heat_set_sta( RUN_HEAT_STA_IDLE );
    }

    return s_run_heat_usr_info.run.sta;
}

static void _running_heat_set_sta( run_heat_sta_e sta )
{
    if ( sta == s_run_heat_usr_info.run.sta )
    {
        return;
    }

    BAT_TMPER_CTR_DEBUG( "RUN_HEAT_STA:%s", (sta == RUN_HEAT_STA_IDLE    )? "RUN_HEAT_STA_IDLE"    : 
                                            (sta == RUN_HEAT_STA_HEATING )? "RUN_HEAT_STA_HEATING" : 
                                            (sta == RUN_HEAT_STA_FINISH  )? "RUN_HEAT_STA_FINISH"  : "RUN_HEAT_STA_ERROR" );

    s_run_heat_usr_info.run.sta = sta;
    switch ( sta )
    {
        case RUN_HEAT_STA_IDLE:
            break;
        case RUN_HEAT_STA_HEATING:
            usr_lc_ctrl_set_lc_param( LC_WORK_MODE_HEAT, RUN_HEAT_LC_TMPER, RUN_HEAT_LC_FLOW );
            break;
        case RUN_HEAT_STA_FINISH:
            usr_lc_ctrl_set_lc_mode( LC_WORK_MODE_WATER_LOOP );
            break;
        default:
            break;
    }
}
