#include "running_cool.h"
#include "usr_lc_ctrl.h"
#include "bat_tmp_ctrl_api.h"
#include "bat_tmp_ctrl_cfg.h"
#include "bat_temper_def.h"

#include "bool_filter.h"
#include "lc_data_type.h"
#include "range_check.h"
#include "tick_timer.h"

#include "sdk.h"
#include "sdk_core.h"

/*---------------------------自适应供液温度 Tmean修正-------------------------- */
static temper_t s_cool_lc_tmp_adj_Tmean_Tds[]       = { 15, 10, 5, 0, -5, -10 };
static point_t s_cool_lc_tmp_adj_Tmean_Tds_points[] = {
    /* rang0 --- cool */
    { .point_val = -40, .ret_diff_val = 10 },
    /* rang1 */
    { .point_val = -20, .ret_diff_val = 10 },
    /* rang2 */
    { .point_val = 0,   .ret_diff_val = 10 },
    /* rang3 */
    { .point_val = 20,  .ret_diff_val = 10 },
    /* rang4 */
    { .point_val = 40,  .ret_diff_val = 10 }
    /* rang5 --- hot */
};
static range_handle_t s_cool_lc_tmp_adj_Tmean_Tds_check_hd   = NULL;
static tick_timer_handle_t s_cool_lc_tmp_adj_Tmean_Tds_timer = NULL;

/*---------------------------自适应供液温度 Tmax修正-------------------------- */
static temper_t s_cool_lc_tmp_adj_Tmax_Tdm[]       = { 0, -10, -15, -20 };
static point_t s_cool_lc_tmp_adj_Tmax_Tdm_points[] = {
    /* rang0 --- cool */
    { .point_val = 0,  .ret_diff_val = 5 },
    /* rang1 */
    { .point_val = 10, .ret_diff_val = 5 },
    /* rang2 */
    { .point_val = 20, .ret_diff_val = 5 },
    /* rang3 --- hot */
};
static range_handle_t s_cool_lc_tmp_adj_Tmax_Tdm_check_hd    = NULL;
static tick_timer_handle_t s_cool_lc_tmp_adj_Tmax_Tdm_timer = NULL;

/*--------------------------- 自适应供液流量 策略 -----------------------------*/
typedef enum {
    COOL_FLOW_ACT_ADJ = 0,                //< 供液流量 正常调节
    COOL_FLOW_ACT_INCREASE = 1,           //< 供液流量 只增不减
    COOL_FLOW_ACT_MAX = 2,                //< 供液流量输出 100%
}  flow_act_range_id_e;
static point_t s_cool_lc_flow_act_Tmean_points[] = {
    /* rang0 -- LC_FLOW_ACT_ADJ */
    { .point_val = Tds, .ret_diff_val = 10 },
    /* rang1 -- LC_FLOW_ACT_INCREASE */
    { .point_val = Tdm, .ret_diff_val = 10 },
    /* rang2 -- LC_FLOW_ACT_MAX */
};
static range_handle_t s_cool_lc_flow_act_Tmean_check_hd      = NULL;


/*--------------------------自适应供液流量调节 ΔTmax---------------------------*/
static flow_t  s_cool_lc_flow_adj[]                  = { -10, 0, 10, 20 };
static point_t s_cool_lc_flow_adj_Tmax_Tmin_points[] = {
    /* rang0 */
    { .point_val = 20, .ret_diff_val = 5 },
    /* rang1 */
    { .point_val = 30, .ret_diff_val = 5 },
    /* rang2 */
    { .point_val = 40, .ret_diff_val = 5 },
    /* rang3 */
};
static range_handle_t s_cool_lc_flow_adj_Tmax_Tmin_check_hd  = NULL;
static tick_timer_handle_t s_cool_lc_flow_adj_tick_timer = NULL;

/*--------------------------------- 制冷开机 ---------------------------------*/
static tick_timer_handle_t s_start_cool_tm_hd          = NULL;

/*--------------------------------- 达温停机 ---------------------------------*/
static tick_timer_handle_t  s_stop_cool_timer_hd = NULL;

static struct 
{
    struct
    {
        temper_t        bat_Tds;
        temper_t        bat_Tdm;
        start_cool_t    *p_start_cool;
        stop_cool_t     *p_stop_cool;
        cooling_t       *p_cooling;
    } attr;
    struct
    {
        lc_ctrl_t     lc_ctrl;
        cooling_sta_e cooling_sta;
    } run;
} s_run_cool_usr_info = {
                            .run = {
                                .lc_ctrl = {
                                    .lc_sta    = LC_WORK_MODE_WATER_LOOP,
                                    .lc_temper = 250,
                                    .lc_flow   = 100
                                }
                            }
                        };  

static void _running_cool_all_hd_reset( void );
static void _runing_cool_set_sta( cooling_sta_e sta );

/**
 * @brief 热管理控制模块 初始化 
 * @param  [in] p_bat_tmp_setting  热管理控制参数
 * @param  [in] lc_ctrl_cb          液冷控制回调函数
 * @return true：成功  false：失败
 */
bool running_cool_init( void )
{
    s_start_cool_tm_hd                 = tick_timer_create();
    s_cool_lc_flow_adj_tick_timer      = tick_timer_create();
    s_cool_lc_tmp_adj_Tmax_Tdm_timer   = tick_timer_create();
    s_cool_lc_tmp_adj_Tmean_Tds_timer  = tick_timer_create();
    s_stop_cool_timer_hd               = tick_timer_create();

    if(    ( s_cool_lc_flow_adj_tick_timer     == NULL )
        || ( s_cool_lc_tmp_adj_Tmax_Tdm_timer  == NULL )
        || ( s_cool_lc_tmp_adj_Tmean_Tds_timer == NULL )
        || ( s_start_cool_tm_hd                == NULL )
        || ( s_stop_cool_timer_hd              == NULL ))
    {
        BAT_TMPER_CTR_ERROR("%s create timer == NULL\r\n", __FUNCTION__);
        return SF_FALSE;
    }

    return SF_TRUE;
}

/**
 * @brief  开机制冷 检测，检测是否进入 开机制冷状态
 * @param  [in] bat_tmp_mean : 电池平均温度，单位：0.1℃
 * @return 
 * @note   
 */
static void _cooling_idle_process( temper_t bat_tmp_mean )
{
    /* 判断是否需要开机制冷 */
    temper_t *p_Tmean_Tds_vals = s_run_cool_usr_info.attr.p_start_cool->Tmean_Tds_val;
    temper_t Tds_val = s_run_cool_usr_info.attr.bat_Tds;
    uint8_t start_level = ARRAY_SIZE( s_run_cool_usr_info.attr.p_start_cool->Tmean_Tds_val ) ;

    for ( ; start_level != 0; start_level--)
    {
        if ( (bat_tmp_mean - Tds_val) >= p_Tmean_Tds_vals[ start_level - 1 ] )
        {
            break;
        }
    }

    switch ( start_level )
    {
        case 0:
            /* 0档自循环 */
            s_run_cool_usr_info.run.lc_ctrl.lc_sta = LC_WORK_MODE_WATER_LOOP;
            usr_lc_ctrl_set_lc_mode( LC_WORK_MODE_WATER_LOOP );
            break;

        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
            /* 其他挡位对应制冷温度 */
            BAT_TMPER_CTR_DEBUG( "COOLING_STA_START" );
            _runing_cool_set_sta( COOLING_STA_START );
            s_run_cool_usr_info.run.lc_ctrl.lc_sta    = LC_WORK_MODE_COOL;
            s_run_cool_usr_info.run.lc_ctrl.lc_temper = s_run_cool_usr_info.attr.p_start_cool->lc_tmp[ start_level ];
            s_run_cool_usr_info.run.lc_ctrl.lc_flow   = s_run_cool_usr_info.attr.p_start_cool->lc_flow;
            tick_timer_set_timeout( s_start_cool_tm_hd, s_run_cool_usr_info.attr.p_start_cool->tm_sec * 1000 );
            usr_lc_ctrl_set_lc_param( s_run_cool_usr_info.run.lc_ctrl.lc_sta, 
                                        s_run_cool_usr_info.run.lc_ctrl.lc_temper, 
                                        s_run_cool_usr_info.run.lc_ctrl.lc_flow );
            break;

        default:
            BAT_TMPER_CTR_ERROR( "COOLING_STA_START ERROR!!!" );
            break;
    }
}

/**
 * @brief  开机制冷 过程处理，等待进入 动态制冷 状态
 * @return 
 * @note   
 */
static void _cooling_start_process( void )
{
    /* 开机制冷持续一段时间 */
    if( tick_timer_is_timeout( s_start_cool_tm_hd ) == SF_TRUE )
    {
        _runing_cool_set_sta( COOLING_STA_DYNAMIC_ADJUST );
        _running_cool_all_hd_reset();
    }
}

/**
 * @brief  运行过程中，温度/流量 动态调整过程 
 * @param  [in] bat_tmp_mean : 电池平均温度，单位：0.1℃
 * @param  [in] bat_tmp_min  : 电池最小温度，单位：0.1℃
 * @param  [in] bat_tmp_max  : 电池最大温度，单位：0.1℃
 * @return 无
 * @note   
 */
static void _cooling_adjust_process( temper_t bat_tmp_mean, temper_t bat_tmp_min, temper_t bat_tmp_max )
{
    bool lc_param_change = SF_FALSE;

    if( s_run_cool_usr_info.attr.p_cooling->tmp_fit_enable )
    {
        /* 温度自适应开启 */
        /* Tmean 供液温度修正 */
        range_check_input( s_cool_lc_tmp_adj_Tmean_Tds_check_hd, bat_tmp_mean - s_run_cool_usr_info.attr.bat_Tds );
        /* 每隔一段时间修正一次 */
        if( tick_timer_is_timeout( s_cool_lc_tmp_adj_Tmean_Tds_timer ) )
        {
            tick_timer_refresh( s_cool_lc_tmp_adj_Tmean_Tds_timer );
            range_id_t Tmean_Tds_range_id = range_get_range_id( s_cool_lc_tmp_adj_Tmean_Tds_check_hd );
            if( Tmean_Tds_range_id != RANGE_ID_INVALID ) 
            {
                // s_run_cool_usr_info.run.lc_ctrl.lc_temper += s_cool_lc_tmp_adj_Tmean_Tds[ Tmean_Tds_range_id ];
                s_run_cool_usr_info.run.lc_ctrl.lc_temper += s_cool_lc_tmp_adj_Tmean_Tds[ Tmean_Tds_range_id ];
                BAT_TMPER_CTR_DEBUG( "input val:%d, fit Tmean tmp adjust:%d",  bat_tmp_mean - s_run_cool_usr_info.attr.bat_Tds, 
                                                                               s_cool_lc_tmp_adj_Tmean_Tds[ Tmean_Tds_range_id ] );
                lc_param_change = SF_TRUE;
            }
        }

        /* Tmax  供液温度修正 */
        range_check_input( s_cool_lc_tmp_adj_Tmax_Tdm_check_hd, bat_tmp_max - s_run_cool_usr_info.attr.bat_Tdm );

        /* Tmax 供液温度 纠正时间，间隔多久纠正一次 */
        if( tick_timer_is_timeout( s_cool_lc_tmp_adj_Tmax_Tdm_timer ) )
        {
            tick_timer_refresh( s_cool_lc_tmp_adj_Tmax_Tdm_timer );
            range_id_t Tmax_Tds_range_id = range_get_range_id( s_cool_lc_tmp_adj_Tmax_Tdm_check_hd );
            if( Tmax_Tds_range_id != RANGE_ID_INVALID ) 
            {
                // s_run_cool_usr_info.run.lc_ctrl.lc_temper += s_cool_lc_tmp_adj_Tmax_Tdm[ Tmax_Tds_range_id ];
                s_run_cool_usr_info.run.lc_ctrl.lc_temper += s_cool_lc_tmp_adj_Tmax_Tdm[ Tmax_Tds_range_id ];
                BAT_TMPER_CTR_DEBUG( "input val:%d, fit Tmax tmp adjust:%d", bat_tmp_max - s_run_cool_usr_info.attr.bat_Tdm,
                                                                             s_cool_lc_tmp_adj_Tmax_Tdm[ Tmax_Tds_range_id ] );
                lc_param_change = SF_TRUE;
            }
        }

        /* 受用户设置供液 最大温度 和 最小温度 限制 */
        if( s_run_cool_usr_info.run.lc_ctrl.lc_temper > s_run_cool_usr_info.attr.p_cooling->fit_lc_tmp.lc_max_tmp )
        {
            s_run_cool_usr_info.run.lc_ctrl.lc_temper = s_run_cool_usr_info.attr.p_cooling->fit_lc_tmp.lc_max_tmp;
            lc_param_change = SF_TRUE;
        }
        else if( s_run_cool_usr_info.run.lc_ctrl.lc_temper < s_run_cool_usr_info.attr.p_cooling->fit_lc_tmp.lc_min_tmp )
        {
            s_run_cool_usr_info.run.lc_ctrl.lc_temper = s_run_cool_usr_info.attr.p_cooling->fit_lc_tmp.lc_min_tmp;
            lc_param_change = SF_TRUE;
        }
    } else {
        /* 固定温度 */

        if ( s_run_cool_usr_info.run.lc_ctrl.lc_temper != s_run_cool_usr_info.attr.p_cooling->fix_lc_tmp )
        {
            s_run_cool_usr_info.run.lc_ctrl.lc_temper = s_run_cool_usr_info.attr.p_cooling->fix_lc_tmp;
            lc_param_change = SF_TRUE;
        }
    }

    if( s_run_cool_usr_info.attr.p_cooling->flow_fit_enable )
    {
        /* 流量自适应开启 */
        /* 供液策略判断 */
        range_check_input( s_cool_lc_flow_act_Tmean_check_hd, bat_tmp_mean - s_run_cool_usr_info.attr.bat_Tds );
        /* ΔTmax 供液流量调节 */
        range_check_input( s_cool_lc_flow_adj_Tmax_Tmin_check_hd, bat_tmp_max - bat_tmp_min );

        /* Tmax 供液温度 调整 */
        if( tick_timer_is_timeout( s_cool_lc_flow_adj_tick_timer ) )
        {
            tick_timer_refresh( s_cool_lc_flow_adj_tick_timer );
            range_id_t Tmax_Tmin_range_id = range_get_range_id( s_cool_lc_flow_adj_Tmax_Tmin_check_hd );
            if( Tmax_Tmin_range_id != RANGE_ID_INVALID )
            {
                s_run_cool_usr_info.run.lc_ctrl.lc_flow += s_cool_lc_flow_adj[Tmax_Tmin_range_id];
                lc_param_change = SF_TRUE;
            }
        }

        if( s_run_cool_usr_info.run.lc_ctrl.lc_flow > 100 )
        {
            s_run_cool_usr_info.run.lc_ctrl.lc_flow = 100;
            lc_param_change = SF_TRUE;
        }
        else if( s_run_cool_usr_info.run.lc_ctrl.lc_flow < 0 )
        {
            s_run_cool_usr_info.run.lc_ctrl.lc_flow = 0;
            lc_param_change = SF_TRUE;
        }
    }
    else
    {
        /* 固定流量 */
        if ( s_run_cool_usr_info.run.lc_ctrl.lc_flow != s_run_cool_usr_info.attr.p_cooling->fix_lc_flow )
        {
            s_run_cool_usr_info.run.lc_ctrl.lc_flow = s_run_cool_usr_info.attr.p_cooling->fix_lc_flow;
            lc_param_change = SF_TRUE;
        }
    }

    /*------------------------- 达温停机 --------------------------- */
    /**
     * Tmax ≤ Tds+3℃
     * Tmean <= (Tds - ΔT)
     **/
    if ( (bat_tmp_max <= (s_run_cool_usr_info.attr.bat_Tds + 30))
        && ( bat_tmp_mean <= (s_run_cool_usr_info.attr.bat_Tds - s_run_cool_usr_info.attr.p_stop_cool->Tds_ret_tmp) ))
    {
        /* 持续5分钟，触发达温停机 */
        if ( tick_timer_is_timeout( s_stop_cool_timer_hd ))
        {
            s_run_cool_usr_info.run.lc_ctrl.lc_sta = LC_WORK_MODE_WATER_LOOP;
            _runing_cool_set_sta( COOLING_STA_STOP );
            lc_param_change = SF_TRUE;
        }
    } else {
        tick_timer_refresh( s_stop_cool_timer_hd );
    }
    
    if ( lc_param_change )
    {
        usr_lc_ctrl_set_lc_param( s_run_cool_usr_info.run.lc_ctrl.lc_sta, 
                                  s_run_cool_usr_info.run.lc_ctrl.lc_temper, 
                                  s_run_cool_usr_info.run.lc_ctrl.lc_flow  );
    }
}

/**
 * @brief  达温停机 检测
 * @param  [in] bat_tmp_mean : 电池平均温度，单位：0.1℃
 * @return 无
 * @note   
 */
static void _cooling_stop_process( temper_t bat_tmp_mean )
{
    if ( bat_tmp_mean >= s_run_cool_usr_info.attr.bat_Tds )
    {
        /* 温度升高，退出达温停机，进行新一轮的制冷需求判断 */
        _runing_cool_set_sta( COOLING_STA_IDLE );
        _running_cool_all_hd_reset();
    }
}

cooling_sta_e running_cooling_get_sta( void )
{
    return s_run_cool_usr_info.run.cooling_sta;
}

/**
 * @brief  电池温度 冷却处理
 * @param  [in] bat_tmp_mean : 电池平均温度，单位：0.1℃
 * @param  [in] bat_tmp_min  : 电池最小温度，单位：0.1℃
 * @param  [in] bat_tmp_max  : 电池最大温度，单位：0.1℃
 * @return 无
 * @note   
 */
void running_cooling_process( temper_t bat_tmp_mean, temper_t bat_tmp_min, temper_t bat_tmp_max )
{
    switch ( s_run_cool_usr_info.run.cooling_sta )
    {
        case COOLING_STA_IDLE:
            _cooling_idle_process( bat_tmp_mean );
            break;

        case COOLING_STA_START:
            _cooling_start_process();
            break;

        case COOLING_STA_DYNAMIC_ADJUST:
            _cooling_adjust_process( bat_tmp_mean, bat_tmp_min, bat_tmp_max );
            break;

        case COOLING_STA_STOP:
            _cooling_stop_process( bat_tmp_mean );
            break;
        
        default:
            break;
    } 
}

/**
 * @brief  重新刷新 热管理控制设置 相关设置和句柄
 * @param  [in] 无
 * @return 
 */
static bool _running_cool_refresh_hd_setting( void )
{
    if (s_cool_lc_tmp_adj_Tmean_Tds_check_hd)
        range_check_delete(s_cool_lc_tmp_adj_Tmean_Tds_check_hd);
    if (s_cool_lc_tmp_adj_Tmax_Tdm_check_hd)
        range_check_delete(s_cool_lc_tmp_adj_Tmax_Tdm_check_hd);
    if (s_cool_lc_flow_act_Tmean_check_hd)
        range_check_delete(s_cool_lc_flow_act_Tmean_check_hd);
    if (s_cool_lc_flow_adj_Tmax_Tmin_check_hd)
        range_check_delete(s_cool_lc_flow_adj_Tmax_Tmin_check_hd);

    range_setting_t def_range_setting = { .trig_dir           = RANGE_TRIG_DIR_INCREASE,
                                          .trig_valid_cnt     = DEF_TRIG_VALID_CNT,
                                          .ret_diff_valid_cnt = DEF_RET_DIFF_VALID_CNT };

    s_cool_lc_tmp_adj_Tmean_Tds_check_hd  = range_check_create( s_cool_lc_tmp_adj_Tmean_Tds_points  , ARRAY_SIZE( s_cool_lc_tmp_adj_Tmean_Tds_points ) , &def_range_setting );
    s_cool_lc_tmp_adj_Tmax_Tdm_check_hd   = range_check_create( s_cool_lc_tmp_adj_Tmax_Tdm_points   , ARRAY_SIZE( s_cool_lc_tmp_adj_Tmax_Tdm_points )  , &def_range_setting );
    s_cool_lc_flow_act_Tmean_check_hd     = range_check_create( s_cool_lc_flow_act_Tmean_points     , ARRAY_SIZE( s_cool_lc_flow_act_Tmean_points )    , &def_range_setting );
    s_cool_lc_flow_adj_Tmax_Tmin_check_hd = range_check_create( s_cool_lc_flow_adj_Tmax_Tmin_points , ARRAY_SIZE( s_cool_lc_flow_adj_Tmax_Tmin_points ), &def_range_setting );

    if(    (s_cool_lc_tmp_adj_Tmean_Tds_check_hd == NULL) || (s_cool_lc_tmp_adj_Tmax_Tdm_check_hd == NULL)
        || (s_cool_lc_flow_act_Tmean_check_hd == NULL)    || (s_cool_lc_flow_adj_Tmax_Tmin_check_hd == NULL) )
    {
        return SF_FALSE;
    }

    tick_timer_set_timeout( s_start_cool_tm_hd                , s_run_cool_usr_info.attr.p_start_cool->tm_sec * 1000 );
    tick_timer_set_timeout( s_cool_lc_flow_adj_tick_timer     , s_run_cool_usr_info.attr.p_cooling->fit_lc_flow.adj_interval_tm * 1000 );
    tick_timer_set_timeout( s_cool_lc_tmp_adj_Tmax_Tdm_timer  , s_run_cool_usr_info.attr.p_cooling->fit_lc_tmp.Tmax_lc_tmp_adj.adj_interval_tm  * 1000 );
    tick_timer_set_timeout( s_cool_lc_tmp_adj_Tmean_Tds_timer , s_run_cool_usr_info.attr.p_cooling->fit_lc_tmp.Tmean_lc_tmp_adj.adj_interval_tm * 1000 );
    tick_timer_set_timeout( s_stop_cool_timer_hd              , s_run_cool_usr_info.attr.p_stop_cool->enter_valid_tm * 1000 );

    return SF_TRUE;
}

static void _running_cool_all_hd_reset( void )
{
    range_check_reset( s_cool_lc_tmp_adj_Tmean_Tds_check_hd );
    range_check_reset( s_cool_lc_tmp_adj_Tmax_Tdm_check_hd );
    range_check_reset( s_cool_lc_flow_act_Tmean_check_hd );
    range_check_reset( s_cool_lc_flow_adj_Tmax_Tmin_check_hd );

    tick_timer_refresh( s_start_cool_tm_hd );
    tick_timer_refresh( s_cool_lc_flow_adj_tick_timer );
    tick_timer_refresh( s_cool_lc_tmp_adj_Tmax_Tdm_timer );
    tick_timer_refresh( s_cool_lc_tmp_adj_Tmean_Tds_timer );
    tick_timer_refresh( s_stop_cool_timer_hd );
}

void running_cool_reset( void )
{
    /* 重置状态机，并将所有数值复位 */
    _runing_cool_set_sta( COOLING_STA_IDLE );
    s_run_cool_usr_info.run.lc_ctrl.lc_sta    = LC_WORK_MODE_INVALID;
    s_run_cool_usr_info.run.lc_ctrl.lc_temper = BAT_TEMPER_CTRL_DEF_LC_TMPER;
    s_run_cool_usr_info.run.lc_ctrl.lc_flow   = BAT_TEMPER_CTRL_DEF_LC_FLOW;

    _running_cool_all_hd_reset();
}

/** 
 * @brief  用户 热管理设置 更新生效
 * @param  [in] 无
 * @return 
 */
void running_cool_setting( temper_t bat_Tds, temper_t bat_Tdm, start_cool_t *p_start_cool, stop_cool_t *p_stop_cool, cooling_t *p_cooling )
{
    s_run_cool_usr_info.attr.bat_Tds      = bat_Tds;
    s_run_cool_usr_info.attr.bat_Tdm      = bat_Tdm;
    s_run_cool_usr_info.attr.p_start_cool = p_start_cool;
    s_run_cool_usr_info.attr.p_stop_cool  = p_stop_cool;
    s_run_cool_usr_info.attr.p_cooling    = p_cooling;

    /*----------------------------------- 制冷 -----------------------------------*/
    for (size_t i = 0; i < ARRAY_SIZE( s_cool_lc_tmp_adj_Tmean_Tds ); i++)
    {
        s_cool_lc_tmp_adj_Tmean_Tds[i] = p_cooling->fit_lc_tmp.Tmean_lc_tmp_adj.lc_tmp_adj[i];
    }
    for (size_t i = 0; i < ARRAY_SIZE( s_cool_lc_tmp_adj_Tmean_Tds_points ); i++)
    {
        s_cool_lc_tmp_adj_Tmean_Tds_points[i].point_val    = p_cooling->fit_lc_tmp.Tmean_lc_tmp_adj.Tmean_Tds_val[i];
        s_cool_lc_tmp_adj_Tmean_Tds_points[i].ret_diff_val = p_cooling->fit_lc_tmp.Tmean_lc_tmp_adj.ret_tmp;
    }

    for (size_t i = 0; i < ARRAY_SIZE( s_cool_lc_tmp_adj_Tmax_Tdm ); i++)
    {
        s_cool_lc_tmp_adj_Tmax_Tdm[i] = p_cooling->fit_lc_tmp.Tmax_lc_tmp_adj.lc_tmp_adj[i];
    }
    for (size_t i = 0; i < ARRAY_SIZE( s_cool_lc_tmp_adj_Tmax_Tdm_points ); i++)
    {
        s_cool_lc_tmp_adj_Tmax_Tdm_points[i].point_val    = p_cooling->fit_lc_tmp.Tmax_lc_tmp_adj.Tmax_Tdm_val[i];
        s_cool_lc_tmp_adj_Tmax_Tdm_points[i].ret_diff_val = p_cooling->fit_lc_tmp.Tmax_lc_tmp_adj.ret_tmp;
    }

    s_cool_lc_flow_act_Tmean_points[0].point_val    = s_run_cool_usr_info.attr.bat_Tds;
    s_cool_lc_flow_act_Tmean_points[0].ret_diff_val = p_cooling->fit_lc_flow.Tdm_and_Tds_ret_tmp;

    s_cool_lc_flow_act_Tmean_points[1].point_val    = s_run_cool_usr_info.attr.bat_Tdm;
    s_cool_lc_flow_act_Tmean_points[1].ret_diff_val = p_cooling->fit_lc_flow.Tdm_and_Tds_ret_tmp;

    for (size_t i = 0; i < ARRAY_SIZE( s_cool_lc_flow_adj ); i++)
    {
        s_cool_lc_flow_adj[i] = p_cooling->fit_lc_flow.lc_flow_adj[i];
    }

    for (size_t i = 0; i < ARRAY_SIZE( s_cool_lc_flow_adj_Tmax_Tmin_points ); i++)
    {
        s_cool_lc_flow_adj_Tmax_Tmin_points[i].point_val    = p_cooling->fit_lc_flow.Tmax_Tmin_val[i];
        s_cool_lc_flow_adj_Tmax_Tmin_points[i].ret_diff_val = p_cooling->fit_lc_flow.ret_tmp;
    }

    _running_cool_refresh_hd_setting();
}

static void _runing_cool_set_sta( cooling_sta_e sta )
{
    if ( s_run_cool_usr_info.run.cooling_sta != sta )
    {
        s_run_cool_usr_info.run.cooling_sta = sta;
        BAT_TMPER_CTR_DEBUG( "[%d] running cool sta:%s!!!",  sdk_tick_get(),
                                        ( sta == COOLING_STA_IDLE           )? "COOLING_STA_IDLE"           : 
                                        ( sta == COOLING_STA_START          )? "COOLING_STA_START"          : 
                                        ( sta == COOLING_STA_DYNAMIC_ADJUST )? "COOLING_STA_DYNAMIC_ADJUST" :
                                        ( sta == COOLING_STA_STOP           )? "COOLING_STA_STOP"           : "COOLING_STA_UNKNOW");
    }
}

