#include "usr_lc_ctrl.h"
#include "lc_ctrl.h"
#include "bat_tmp_ctrl_cfg.h"

#include "sdk.h"
#include "sdk_core.h"

static struct 
{
    lc_ctrl_t last_lc_ctrl;
    lc_ctrl_t lc_ctrl;

    bool      last_fire_fighting_enable;
    bool      fire_fighting_enable;

    bool      lc_param_adjust;
} s_usr_lc_ctrl_info;

static bool _usr_lc_ctrl_set_lc( lc_work_mode_e lc_work_mode, temper_t lc_temper, flow_t lc_flow );

void usr_lc_ctrl_init( void )
{
    memset( &s_usr_lc_ctrl_info, 0, sizeof( s_usr_lc_ctrl_info ) );

    s_usr_lc_ctrl_info.lc_ctrl.lc_sta    = LC_WORK_MODE_STANDBY;
    s_usr_lc_ctrl_info.lc_ctrl.lc_flow   = 100;
    s_usr_lc_ctrl_info.lc_ctrl.lc_temper = 250;
}

void usr_lc_ctrl_set_lc_mode( lc_work_mode_e work_mode )
{
    s_usr_lc_ctrl_info.lc_ctrl.lc_sta = work_mode;
}


void usr_lc_ctrl_set_lc_temper( temper_t lc_temper )
{
    s_usr_lc_ctrl_info.lc_ctrl.lc_temper = lc_temper;
}

void usr_lc_ctrl_set_lc_flow( flow_t lc_flow )
{
    s_usr_lc_ctrl_info.lc_ctrl.lc_flow = lc_flow;
}

void usr_lc_ctrl_set_lc_param( lc_work_mode_e work_mode, temper_t lc_temper, flow_t lc_flow )
{
    s_usr_lc_ctrl_info.lc_ctrl.lc_sta    = work_mode;
    s_usr_lc_ctrl_info.lc_ctrl.lc_temper = lc_temper;
    s_usr_lc_ctrl_info.lc_ctrl.lc_flow   = lc_flow;
}

void usr_lc_ctrl_set_fire_fighting_enable( bool enable )
{
    s_usr_lc_ctrl_info.fire_fighting_enable = enable;
}

bool usr_lc_ctrl_get_fire_fighting_enable( void )
{
    return s_usr_lc_ctrl_info.fire_fighting_enable;
}

lc_work_mode_e usr_lc_ctrl_get_lc_mode( void )
{
    return s_usr_lc_ctrl_info.lc_ctrl.lc_sta;
}

temper_t usr_lc_ctrl_get_lc_temper( void )
{
    return s_usr_lc_ctrl_info.lc_ctrl.lc_temper;
}

flow_t usr_lc_ctrl_get_lc_flow( void )
{
    return s_usr_lc_ctrl_info.lc_ctrl.lc_flow;
}

void usr_lc_ctrl_param_adjust( void )
{
    s_usr_lc_ctrl_info.lc_param_adjust = SF_TRUE;
}

void usr_lc_ctrl_reset( void )
{
    if ( s_usr_lc_ctrl_info.fire_fighting_enable == SF_TRUE ) 
    {
        /* 启动消防时不允许复位 */
        return;
    }

    s_usr_lc_ctrl_info.lc_ctrl.lc_sta    = LC_WORK_MODE_STANDBY;
    s_usr_lc_ctrl_info.lc_ctrl.lc_temper = BAT_TEMPER_CTRL_DEF_LC_TMPER;
    s_usr_lc_ctrl_info.lc_ctrl.lc_flow   = BAT_TEMPER_CTRL_DEF_LC_FLOW;

    s_usr_lc_ctrl_info.last_lc_ctrl.lc_sta    = LC_WORK_MODE_INVALID;
    s_usr_lc_ctrl_info.last_lc_ctrl.lc_temper = USR_I16_VAL_INVALID;
    s_usr_lc_ctrl_info.last_lc_ctrl.lc_flow   = USR_I16_VAL_INVALID;
    
    _usr_lc_ctrl_set_lc( s_usr_lc_ctrl_info.lc_ctrl.lc_sta,
                         s_usr_lc_ctrl_info.lc_ctrl.lc_temper,
                         s_usr_lc_ctrl_info.lc_ctrl.lc_flow );
}

void usr_lc_ctrl_proc( void )
{
    lc_cap_t  lc_cap;

    lc_ctrl_get_lc_cap( &lc_cap );
    
    if ( s_usr_lc_ctrl_info.fire_fighting_enable == SF_TRUE ) 
    {
        if ( s_usr_lc_ctrl_info.last_fire_fighting_enable == SF_FALSE ) 
        {
            /* 开启消防模式，强制按消防模式运行 */
            _usr_lc_ctrl_set_lc( LC_WORK_MODE_COOL, LC_SF_FF_MODE_LC_TMP, LC_SF_FF_MODE_LC_FLOW );
            s_usr_lc_ctrl_info.last_lc_ctrl.lc_sta    = LC_WORK_MODE_COOL;
            s_usr_lc_ctrl_info.last_lc_ctrl.lc_temper = LC_SF_FF_MODE_LC_TMP;
            s_usr_lc_ctrl_info.last_lc_ctrl.lc_flow   = LC_SF_FF_MODE_LC_FLOW;
            s_usr_lc_ctrl_info.last_fire_fighting_enable = SF_TRUE;
        }
        return;
    }
    s_usr_lc_ctrl_info.last_fire_fighting_enable = s_usr_lc_ctrl_info.fire_fighting_enable;

    /* 没开启消防模式，按正常运行 */
    if( lc_cap.lc_flow_usr_ctrl == 1 )
    {
        if( s_usr_lc_ctrl_info.lc_ctrl.lc_flow > lc_cap.lc_max_flow )
        {
            s_usr_lc_ctrl_info.lc_ctrl.lc_flow = lc_cap.lc_max_flow;
        }

        if( s_usr_lc_ctrl_info.lc_ctrl.lc_flow < lc_cap.lc_min_flow )
        {
            s_usr_lc_ctrl_info.lc_ctrl.lc_flow = lc_cap.lc_min_flow;
        }
    }

    if( lc_cap.lc_tmp_usr_ctrl == 1 )
    {
        if( s_usr_lc_ctrl_info.lc_ctrl.lc_temper > lc_cap.lc_max_tmp )
        {
            s_usr_lc_ctrl_info.lc_ctrl.lc_temper = lc_cap.lc_max_tmp;
        }

        if( s_usr_lc_ctrl_info.lc_ctrl.lc_temper < lc_cap.lc_min_tmp )
        {
            s_usr_lc_ctrl_info.lc_ctrl.lc_temper = lc_cap.lc_min_tmp;
        }
    }

    if (   ( s_usr_lc_ctrl_info.last_lc_ctrl.lc_sta    != s_usr_lc_ctrl_info.lc_ctrl.lc_sta    )
        || ( s_usr_lc_ctrl_info.last_lc_ctrl.lc_temper != s_usr_lc_ctrl_info.lc_ctrl.lc_temper )
        || ( s_usr_lc_ctrl_info.last_lc_ctrl.lc_flow   != s_usr_lc_ctrl_info.lc_ctrl.lc_flow   )
        || ( s_usr_lc_ctrl_info.lc_param_adjust == SF_TRUE ))
    {
        s_usr_lc_ctrl_info.lc_param_adjust = SF_FALSE;
        s_usr_lc_ctrl_info.last_lc_ctrl.lc_sta    = s_usr_lc_ctrl_info.lc_ctrl.lc_sta;
        s_usr_lc_ctrl_info.last_lc_ctrl.lc_temper = s_usr_lc_ctrl_info.lc_ctrl.lc_temper;
        s_usr_lc_ctrl_info.last_lc_ctrl.lc_flow   = s_usr_lc_ctrl_info.lc_ctrl.lc_flow;
        _usr_lc_ctrl_set_lc( s_usr_lc_ctrl_info.lc_ctrl.lc_sta, s_usr_lc_ctrl_info.lc_ctrl.lc_temper, s_usr_lc_ctrl_info.lc_ctrl.lc_flow );
    }
}

static bool _usr_lc_ctrl_set_lc( lc_work_mode_e lc_work_mode, temper_t lc_temper, flow_t lc_flow )
{
    sdk_log_d( "[%d] work_mode:%s, temper:%d, flow:%d", sdk_tick_get(),
                                (lc_work_mode == LC_WORK_MODE_STANDBY) ? "LC_WORK_MODE_STANDBY" :
                                (lc_work_mode == LC_WORK_MODE_HEAT) ? "LC_WORK_MODE_HEAT" :
                                (lc_work_mode == LC_WORK_MODE_COOL) ? "LC_WORK_MODE_COOL" :
                                (lc_work_mode == LC_WORK_MODE_WATER_LOOP) ? "LC_WORK_MODE_WATER_LOOP" : "LC_WORK_MODE_UNKONW", 
                                lc_temper, lc_flow );

    lc_ctrl_set_work_mode( lc_work_mode );

    if ((lc_work_mode == LC_WORK_MODE_COOL) || (lc_work_mode == LC_WORK_MODE_WATER_LOOP))
    {
        lc_ctrl_set_cool_temper(lc_temper);
    }
    else if (lc_work_mode == LC_WORK_MODE_HEAT)
    {
        lc_ctrl_set_heat_temper(lc_temper);
    }
    lc_ctrl_set_flow( lc_flow );

    return true;
}
