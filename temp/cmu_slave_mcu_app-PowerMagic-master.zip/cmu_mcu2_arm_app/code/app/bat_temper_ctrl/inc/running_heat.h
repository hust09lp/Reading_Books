#ifndef _RUNNING_HEAT_H_
#define _RUNNING_HEAT_H_

#include "sofar_type.h"

typedef enum {
    RUN_HEAT_STA_IDLE,
    RUN_HEAT_STA_HEATING,
    RUN_HEAT_STA_FINISH,
} run_heat_sta_e;

void running_heat_init( void );
void running_heat_setting( temper_t startup_tmp, temper_t exit_tmp );
void running_heating_reset( void );
run_heat_sta_e running_heating_get_sta( void );
run_heat_sta_e running_heating_process( temper_t bat_tmp_mean );

#endif
