#ifndef _BAT_TMP_CTRL_API_H_
#define _BAT_TMP_CTRL_API_H_

#include "bat_temper_def.h"

/**
 * @brief 热管理控制模块 初始化 
 * @param  [in] p_bat_tmp_setting  热管理控制参数
 * @param  [in] lc_ctrl_cb          液冷控制回调函数
 * @return true：成功  false：失败
 */
bool bat_temper_ctrl_init( void );

/**
 * @brief  输入电池数据
 * @param  [in] valid   电池数据有效位
 * @param  [in] bat_current_01A 电池电流
 * @param  [in] bat_tmp_mean    电池平均温度
 * @param  [in] bat_tmp_min     电池最小温度
 * @param  [in] bat_tmp_max     电池最大温度
 * @return 
 */
void bat_temper_ctrl_input( bool valid, int32_t bat_current_01A, temper_t env_tmp, temper_t bat_tmp_mean, temper_t bat_tmp_min, temper_t bat_tmp_max );

/**
 * @brief  电池温度处理【供外部线程调用】
 * @return 
 */
void bat_temper_ctrl_task_loop( void );

/**
 * @brief 获取当前电池是否可以进行充放电
 * @return true：可进行充放电  false：不可进行充放电  
 */
bool bat_temper_get_allow_charge_discharge( void );

/**
 * @brief 获取首航热管理模式 【与液冷模式存在区别】
 * @return lc_sofar_mode_e 见枚举
 */
lc_sofar_mode_e bat_temper_get_lc_sofar_mode( void );

/**
 * @brief  电池温控 液冷参数纠正
 * @param  [in] 无
 * @return true：成功  false：失败
 */
bool bat_temper_ctrl_lc_param_adjust_once( void );

/**
 * @brief  重启模块
 * @param  [in] 无
 * @return 无
 * @note   
 */
void bat_temper_ctrl_reset( void );

/**
 * @brief 热管理控制 模块使能或关闭
 * @param  [in] enable  使能
 * @return true：成功  false：失败
 */
bool bat_temper_ctrl_set_enable( bool enable );

/**
 * @brief 启动消防模式
 * @param  [in] enable  使能
 * @return true：成功  false：失败
 */
bool bat_temper_set_fire_fighting_mode( bool enable );

/**
 * @brief 热管理控制 参数设置 
 * @param  [in] p_bat_tmp_setting  热管理控制参数
 * @return true：成功  false：失败
 */
bool bat_temper_set_bat_tmp_setting( bat_tmp_setting_t *p_bat_tmp_setting );

void bat_temper_set_keep_temper_enable( bool enable, temper_t start_heating_tmp, temper_t stop_heating_tmp, temper_t start_cooling_tmp, temper_t stop_cooling_tmp );


sf_ret_t bat_temper_ctrl_vir_debug( char *vir_cmd, char *vir_val_str );

#endif
