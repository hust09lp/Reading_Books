#ifndef __BAT_TEMPER_DEF_H__
#define __BAT_TEMPER_DEF_H__

#include "lc_data_type.h"
#include "sdk.h"
#include "sdk_core.h"

#if (1)
    #define BAT_TMPER_CTR_DEBUG( format, ... )  do { sdk_log_printf("[bat_tmp_ctr]"); sdk_log_d( format, ##__VA_ARGS__ ); sdk_log_printf("\r\n"); } while(0)
    #define BAT_TMPER_CTR_ERROR( format, ... )  do { sdk_log_printf("[bat_tmp_ctr]"); sdk_log_e( format, ##__VA_ARGS__ ); sdk_log_printf("\r\n"); } while(0)
    #define BAT_TMPER_CTR_LOG_D_RAW( format, ... )  do { sdk_log_printf( format, ##__VA_ARGS__ ); } while(0)
#else
    #define BAT_TMPER_CTR_DEBUG( format, ... )  do {} while(0)
    #define BAT_TMPER_CTR_ERROR( format, ... )  do {} while(0)
#endif

typedef enum {
    LC_SF_MODE_STANDBY,                     // 待机模式
    LC_SF_MODE_COOLING,                     // 制冷模式
    LC_SF_MODE_PRE_COOL,                    // 预冷模式
    LC_SF_MODE_PRE_HEAT,                    // 预热模式
    LC_SF_MODE_WATER_LOOP,                  // 自循环模式
    LC_SF_MODE_FIRE_FIGHTING,               // 消防联动模式
    LC_SF_MODE_HEATING,                     // 制热模式
    LC_SF_MODE_KEEP_TEMPER,                 // 保温模式
    LC_SF_MODE_INVALID = 0xff,              // 无效模式
} lc_sofar_mode_e;

/* Tmean 供液温度 修正 */
typedef struct {
    temper_t  Tmean_Tds_val[ 5 ];           //< Tmean - Tds
    temper_t  lc_tmp_adj   [ 6 ];           //< 液冷 纠正温度
    temper_t  ret_tmp;                      //< 回差温度
    uint16_t  adj_interval_tm;              //< 纠正温度 时间间隔
} Tmean_lc_tmp_adj_t;                       //< Tmean 液冷 纠正温度
 
/* Tmax 供液温度 修正 */
typedef struct {
    temper_t  Tmax_Tdm_val[ 3 ];            //< Tmax - Tdm
    temper_t  lc_tmp_adj  [ 4 ];            //< 液冷 纠正温度
    temper_t  ret_tmp;                      //< 回差温度
    uint16_t  adj_interval_tm;              //< 纠正温度 时间间隔
} Tmax_lc_tmp_adj_t;                        //< Tmax 液冷 纠正温度

/* 预冷模式 相关设置 */
typedef struct {
    temper_t startup_bat_Tmax;                  //< Tmax 触发 预冷 阈值
    temper_t startup_bat_Tmean;                 //< Tmean 触发 预冷 阈值
    temper_t exit_ret_tmp;                  //< 退出 预冷回差

    temper_t lc_tmp;                        //< 预冷 液冷温度
    flow_t   lc_flow;                       //< 预冷 液冷流量
} pre_cool_t;                               //< 预冷 模式

/* 预热模式 相关设置 */
typedef struct {
    temper_t startup_bat_Tmin;                  //< Tmin 触发 预热 阈值
    temper_t startup_bat_Tmean;                 //< Tmean 触发 预热 阈值
    temper_t exit_ret_tmp;                  //< 退出 预热 回差

    temper_t lc_tmp;                        //< 预热 液冷温度
    flow_t   lc_flow;                       //< 预热 液冷流量
} pre_heat_t;                               //< 预热 模式

/* 开机制冷 相关设置 */
typedef struct {
    temper_t  Tmean_Tds_val[ 5 ];           //< Tmean - Tds  
    temper_t  lc_tmp[ 6 ];                  //< 液冷 温度
    temper_t  ret_tmp;                      //< 温度回差
    flow_t    lc_flow;                      //< 液冷 流量
    uint16_t  tm_sec;                       //< 制冷开机 持续时间
} start_cool_t;                             //< 制冷开机 

/* 停止制冷 相关设置 */
typedef struct {
    temper_t    Tds_ret_tmp;                //< Tds 正负回差，对比数据 Tmean
    uint16_t    enter_valid_tm;             //< 进入 达温停机持续时间
    uint16_t    exit_valid_tm;              //< 退出 达温停机持续时间
} stop_cool_t;                              //< 达温停机 

/* 自适应供液温度 相关设置 */
typedef struct {
    temper_t            lc_min_tmp;         //< 自适应 最小供液温度
    temper_t            lc_max_tmp;         //< 自适应 最大供液温度
    Tmean_lc_tmp_adj_t  Tmean_lc_tmp_adj;   //< Tmean 供液温度 修正
    Tmax_lc_tmp_adj_t   Tmax_lc_tmp_adj;    //< Tmax 供液温度 修正
} fit_lc_tmp_t;                             //< 自适应供液温度

/* 自适应供液流量 相关设置 */
typedef struct {
    temper_t Tdm_and_Tds_ret_tmp;           //< 供液流量策略 回差

    temper_t Tmax_Tmin_val[ 3 ];            //< Tmax - Tmin 
    flow_t   lc_flow_adj  [ 4 ];            //< 液冷 纠正流量
    temper_t ret_tmp;                       //< 回差温度回差
    uint16_t adj_interval_tm;               //< 纠正流量 时间间隔
} fit_lc_flow_t;                            //< 自适应 供液流量

/* 制冷模式下 相关设置 */
typedef struct {
    bool          tmp_fit_enable;           //< 是否开启 温度自适应
    temper_t      fix_lc_tmp;               //< 固定供液温度
    fit_lc_tmp_t  fit_lc_tmp;               //< 自适应供液温度

    bool          flow_fit_enable;          //< 是否开启 流量自适应
    flow_t        fix_lc_flow;              //< 固定供液流量
    fit_lc_flow_t fit_lc_flow;              //< 自适应供液流量
} cooling_t;                                //< 制冷调节

/* 保温模式下 相关设置 */
typedef struct {
    uint16_t enable;                        // 保温模式使能位
    uint16_t heating_startup_temper;        // 保温模式 加热启动温度
    uint16_t heating_exit_temper;           // 保温模式 加热退出温度
    uint16_t cooling_startup_temper;        // 保温模式 制冷启动温度
    uint16_t cooling_exit_temper;           // 保温模式 制冷退出温度
} keep_tmper_t;


typedef struct 
{
    temper_t  pre_cooling;                  //< 预冷 禁充禁放温度
    temper_t  pre_heating;                  //< 预热 禁充禁放温度
} dis_work_tmp_t;                           //< 禁充禁放温度 

/* 热管理控制 相关设置 */
typedef struct {
    temper_t    bat_Tds;                    //< 电芯设定 目标温度
    temper_t    bat_Tdm;                    //< 电芯设定 最大温度
    uint16_t    pump_delay_close_tm;        //< 水泵延迟关闭时间，单位:1s
    uint16_t    pre_check_tm_sec;           //< 预冷预热检查时间，单位：1s

    pre_cool_t  pre_cool;                   //< 预冷模式
    pre_heat_t  pre_heat;                   //< 预热模式
    
    start_cool_t start_cool;                //< 制冷开机
    stop_cool_t  stop_cool;                 //< 达温停机
    cooling_t    cooling;                   //< 制冷调节

    uint16_t     standby_cur;               //< 电池待机电流 单位：0.1A
    keep_tmper_t keep_tmper;                //< 保温模式设置

    dis_work_tmp_t dis_work_tmp;            //< 禁充禁放温度 
} bat_tmp_setting_t;


#endif
