#ifndef _BAT_TMP_CTRL_CFG_H_
#define _BAT_TMP_CTRL_CFG_H_

#include "proj_cfg.h"

/*-------------------------------------- 通用配置 ---------------------------------------*/
#define DEF_TRIG_VALID_CNT                              5
#define DEF_RET_DIFF_VALID_CNT                          5

#define TASK_LOOP_TM_MS                                 1000        // 任务处理时间

#define BAT_TEMPER_CTRL_DEF_LC_TMPER                    180         // 初始化默认液冷温度，单位：0.1℃
#define BAT_TEMPER_CTRL_DEF_LC_FLOW                     100         // 初始化默认液冷流量，单位：1%

/*----------------------------------------- 消防联动参数 ------------------------------------------*/
#define LC_SF_FF_MODE_LC_TMP                            100         // 消防模式供液温度，单位：0.1℃
#define LC_SF_FF_MODE_LC_FLOW                           100         // 消防模式供液流量，单位：1%

/*----------------------------------------- 热管理文档参数 ------------------------------------------*/
#define Tds                                         320             // Tds
#define Tdm                                         380             // Tdm

/*------------ 预冷预热 ---------------*/
#define Tpre_HEATING1                               150             // Tpre-heating1   
#define Tpre_HEATING2                               180             // Tpre-heating2   
#define Tpre_HEATING3                               100             // Tpre-heating3  

#define Tpre_COOLING1                               350             // Tpre-cooling1 
#define Tpre_COOLING2                               330             // Tpre-cooling2 
#define Tpre_COOLING3                               380             // Tpre-cooling3 

#define PRE_HEAT_COOL_DELTA_TMP                     30              // ΔT
#define PRE_HEAT_COOL_Tpre                          (2*3600*1000)   // tpre 

/*------------- 保温模式 -------------*/
#define T_heat_keeping1                             150             // Th-keeping1
#define T_heat_keeping2                             200             // Th-keeping2

#define T_cool_keeping1                             350             // Tc-keeping1
#define T_cool_keeping2                             320             // Tc-keeping2

// /*--------- Tmean供液温度调节 ---------*/
// #define LC_TMP_ADJ_Tmean_N1                         10              // N1 
// #define LC_TMP_ADJ_Tmean_N2                         20              // N2 
// #define LC_TMP_ADJ_Tmean_DELTA_TMP                  0               // ΔT 
// #define LC_TMP_ADJ_Tmean_DELTA_T1                   0               // ΔT1 
// #define LC_TMP_ADJ_Tmean_DELTA_T2                   0               // ΔT2 
// #define LC_TMP_ADJ_Tmean_DELTA_T3                   0               // ΔT3 

/*------------------------------ 预冷预热检测 ----------------------------- */
#ifndef SIMIU_BAT_TEMP_ENABLE
#error "Not define SIMIU_BAT_TEMP_ENABLE, incldue proj_cfg.h"
#endif

#if ( SIMIU_BAT_TEMP_ENABLE == 0 )
#define BAT_PRE_HEAT_COOL_MAX_TM_MS                 (7200 * 1000)   // 预冷预热最长时间，单位：1ms
#else
#define BAT_PRE_HEAT_COOL_MAX_TM_MS                 (240 * 1000)    // 预冷预热最长时间，单位：1ms 【调试状态下将时间缩短】
#endif

/*--------------------------- 预热 ---------------------------*/
#define PRE_HEAT_LOWEST_Tmin                        ( Tpre_HEATING3 - PRE_HEAT_COOL_DELTA_TMP )
#define PRE_HEAT_LOWEST_Tmean                       ( Tpre_HEATING3 )
#define PRE_HEAT_STARTUP_Tmin                       ( Tpre_HEATING1 - PRE_HEAT_COOL_DELTA_TMP )
#define PRE_HEAT_STARTUP_Tmean                      ( Tpre_HEATING1 )
#define PRE_HEAT_EXIT_HYS_TMP                       ( Tpre_HEATING2 - Tpre_HEATING1  )
#define PRE_HEAT_LC_TMP                             250
#define PRE_HEAT_LC_FLOW                            100

/*--------------------------- 预冷 ---------------------------*/
#define PRE_COOL_HIGHEST_Tmax                       ( Tpre_COOLING3 + PRE_HEAT_COOL_DELTA_TMP )
#define PRE_COOL_HIGHEST_Tmean                      ( Tpre_COOLING3 )
#define PRE_COOL_STARTUP_Tmax                       ( Tpre_COOLING1 + ( 2 * PRE_HEAT_COOL_DELTA_TMP ) )
#define PRE_COOL_STARTUP_Tmean                      ( Tpre_COOLING1 )
#define PRE_COOL_EXIT_HYS_TMP                       ( Tpre_COOLING1 - Tpre_COOLING2 )
#define PRE_COOL_LC_TMP                             190
#define PRE_COOL_LC_FLOW                            100

/* 环境温度大于45度，液冷性能下降 */
#define LC_LOW_PERFORMANCE( lc_env_tmp )            ( lc_env_tmp >= 450 )

#endif
