#ifndef _PRE_HEAT_COOL_H_
#define _PRE_HEAT_COOL_H_

#include "bat_temper_def.h"
#include "bat_tmp_ctrl_api.h"

typedef enum {
    PRE_HC_STA_IDLE,               // 空闲
    PRE_HC_STA_HEATING,            // 预热
    PRE_HC_STA_COOLING_NOR,        // 正常预冷
    PRE_HC_STA_COOLING_LOW_PERF,   // 非理想情况下预冷
    PRE_HC_STA_FINISH,             // 预冷预热完成
} pre_hc_sta_e;

sf_ret_t pre_heat_cool_init( void );
void pre_heat_cool_setting( pre_cool_t *p_pre_cool, pre_heat_t *p_pre_heat, dis_work_tmp_t *p_dis_work_tmp );
void pre_heat_cool_reset( void );
bool pre_heat_cool_get_charge_discharge_allow( void );
pre_hc_sta_e pre_heat_cool_get_sta( void );
pre_hc_sta_e pre_heat_cool_proc( bool bat_curr_work, temper_t env_tmp, temper_t bat_tmp_mean, temper_t bat_tmp_min, temper_t bat_tmp_max );

#endif
