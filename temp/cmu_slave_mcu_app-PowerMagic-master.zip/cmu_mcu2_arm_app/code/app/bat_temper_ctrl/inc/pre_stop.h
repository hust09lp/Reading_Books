#ifndef _PRE_STOP_H_
#define _PRE_STOP_H_

#include "bat_tmp_ctrl_api.h"

/**
  * @struct 预停止状态
  * @brief  
  */
typedef enum {
    PRE_STOP_STA_IDLE,                //< 
    PRE_STOP_STA_COOLING,             //< 停机之前制冷
    PRE_STOP_STA_WATER_LOOP,          //< 停机之前自循环
    PRE_STOP_STA_FINISH,              //< 完成所有停机之前的操作
} pre_stop_sta_e;

sf_ret_t pre_stop_init( void );
void pre_stop_reset( void );
pre_stop_sta_e pre_stop_process( temper_t lc_env_tmp, temper_t bat_tmp_mean, temper_t bat_tmp_min, temper_t bat_tmp_max );

#endif
