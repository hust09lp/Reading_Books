#ifndef _RUNNING_COOL_PROC_H_
#define _RUNNING_COOL_PROC_H_

#include "bat_temper_def.h"

typedef enum {
    COOLING_STA_IDLE,
    COOLING_STA_START,
    COOLING_STA_DYNAMIC_ADJUST,
    COOLING_STA_STOP,
    COOLING_STA_INVALID = 0xFF,
} cooling_sta_e;


bool running_cool_init( void );
void running_cool_setting( temper_t bat_Tds, temper_t bat_Tdm, start_cool_t *p_start_cool, stop_cool_t *p_stop_cool, cooling_t *p_cooling );
void running_cool_reset( void );
cooling_sta_e running_cooling_get_sta( void );
void running_cooling_process( temper_t bat_tmp_mean, temper_t bat_tmp_min, temper_t bat_tmp_max );


#endif
