#ifndef _KEEP_TEMPER_H_
#define _KEEP_TEMPER_H_

#include "sofar_type.h"

void keep_temper_init( void );
void keep_temper_reset( void );
void keep_temper_set( temper_t start_heating_tmp, temper_t stop_heating_tmp, temper_t start_cooling_tmp, temper_t stop_cooling_tmp );
void keep_temper_proc( bool bat_curr_work, temper_t bat_tmp_mean, temper_t bat_tmp_min, temper_t bat_tmp_max );

#endif
