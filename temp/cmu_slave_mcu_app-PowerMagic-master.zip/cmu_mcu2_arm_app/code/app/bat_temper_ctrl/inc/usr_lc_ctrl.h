#ifndef _USR_LC_CTRL_H_
#define _USR_LC_CTRL_H_

#include "lc_data_type.h"
#include "bat_tmp_ctrl_api.h"

void usr_lc_ctrl_init( void );

void usr_lc_ctrl_set_lc_mode( lc_work_mode_e work_mode );
void usr_lc_ctrl_set_lc_temper( temper_t lc_temper );
void usr_lc_ctrl_set_lc_flow( flow_t lc_flow );
void usr_lc_ctrl_set_lc_param( lc_work_mode_e work_mode, temper_t lc_temper, flow_t lc_flow );

void usr_lc_ctrl_set_fire_fighting_enable( bool enable );
bool usr_lc_ctrl_get_fire_fighting_enable( void );

lc_work_mode_e usr_lc_ctrl_get_lc_mode( void );
temper_t usr_lc_ctrl_get_lc_temper( void );
flow_t usr_lc_ctrl_get_lc_flow( void );

void usr_lc_ctrl_param_adjust( void );

void usr_lc_ctrl_reset( void );
void usr_lc_ctrl_proc( void );

#endif
