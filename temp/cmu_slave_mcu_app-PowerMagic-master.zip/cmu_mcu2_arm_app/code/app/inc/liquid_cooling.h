#ifndef __LIQUID_COOLING_H__
#define __LIQUID_COOLING_H__


#include <stdint.h>
#include <stddef.h>
#include "sci.h"


//#define LC_ADDR        0X01    // 消防设备地址 液体

// 要读取的寄存器个数
#define LC_RUN_REG_LEN         66

// 状态参数寄存器地址
#define LC_REG_PUMP_STATE     0x01



// 液设置参数寄存器地址
#define LC_REG_POWER      			1
#define LC_REG_PUMP_MANUAL      	2
#define LC_REG_HEAT_ENABLE          3
#define LC_REG_WATER_IN_OUT     	4
#define LC_REG_WORK_MODE     		5
#define LC_REG_COOL_VALUE   		6
#define LC_REG_HEAT_VALUE       	7
#define LC_REG_HEAT_DROP      		8
#define LC_REG_FAN_HUMIDITY     	9
#define LC_REG_HUMIDITY_DROP    	10
#define LC_REG_PUMP_RPM      		11
#define LC_REG_TEMP_OVER     		12
#define LC_REG_WATER_PRESSURE_H     13
#define LC_REG_WATER_PRESSURE_L     14

#define LC_REG_WATER_TEMP_REVISE    62
#define LC_REG_FAN_PLATE1_MANUAL    63
#define LC_REG_FAN_PLATE1_RPM    	64
#define LC_REG_FAN_PLATE2_MANUAL    65
#define LC_REG_FAN_PLATE2_RPM    	66


// 液冷控制阈值参数
#define LC_PRE_HEAT_MIN_TEMP        	10
#define LC_PRE_HEAT_MEAN_TEMP       	15
#define LC_PRE_HEAT_WATER_OUT_TEMP      35
#define LC_PRE_HEAT_DROP       			5
#define LC_PRE_COOLING_MAX_TEMP       	50
#define LC_PRE_COOLING_MEAN_TEMP       	40
#define LC_PRE_COOLING_DROP       		10
#define LC_COOLING_ON_MAX_TEMP       	35
#define LC_COOLING_ON_MEAN_TEMP       	30
#define LC_COOLING_WATER_OUT_TEMP       19
#define LC_COOLING_DROP       			5
#define LC_HEAT_COOLING_WAITE_TIME      10
#define LC_HEAT_COOLING_WATER_FLOW      400
#define LC_PUMP_OFF_DELAY      			5
#define LC_SYS_STANDBY_POWER      		5
#define LC_BAT_ROOM_FAN_ON_TEMP      	30
#define LC_BAT_ROOM_FAN_ON_HUMIDITY     50
#define LC_BAT_ROOM_FAN_OFF_TEMP      	27
#define LC_BAT_ROOM_FAN_OFF_HUMIDITY    47
#define LC_BAT_ROOM_COOLING_ON_TEMP     30
#define LC_BAT_ROOM_DRYING_ON_TEMP      27
#define LC_DEV_ROOM_FAN_ON_TEMP      	30
#define LC_DEV_ROOM_FAN_ON_HUMIDITY     50
#define LC_DEV_ROOM_FAN_OFF_TEMP      	27
#define LC_DEV_ROOM_FAN_OFF_HUMIDITY    47
#define LC_DEV_ROOM_COOLING_ON_TEMP     30
#define LC_DEV_ROOM_DRYING_ON_TEMP      27


// 液冷开关机
#define LC_POWER_OFF      	0
#define LC_POWER_ON      	1

// 液冷进出水模式
#define LC_WATER_IN      	0
#define LC_WATER_OUT      	1

// 液冷控制模式
#define LC_STANDBY_MODE      	0
#define LC_WATER_LOOP_MODE      1
#define LC_COOLING_MODE      	2
#define LC_HEATING_MODE      	3
#define LC_AUTO_MODE      		4

// 风盘模式
#define LC_FAN_OFF      		0			// 关闭风盘
#define LC_FAN_DRYING      		50			// 风盘除湿
#define LC_FAN_COOOLING      	70			// 风盘制冷
#define LC_FAN_RPM_MAX      	85			// 风盘最大速度



#define DISABLE      	0
#define ENABLE      	1


// 液冷控制状态
#define LC_STA_DRY     		0       // 除湿状态
#define LC_STA_INIT     	1       // 上电初始化状态
#define LC_STA_INIT_WAIT    2       // 上电初始化状态
#define LC_STA_CHG_DISCHG   3       // 充放电状态
#define LC_STA_STANDBY     	4       // 待机状态
#define LC_STA_SHUTDOWN     5       // 停机状态

// MCU1运行状态
#define MCU1_STOP       0
#define MCU1_STANDBY    1
#define MCU1_RUN       	2
#define MCU1_FAULT      3
#define MCU1_UPDATE     4

/**
  * @struct lc_alarm_state_u
  * @brief 告警状态定义    位:0正常,1 告警
  */
typedef union{
    struct
    {
        uint16_t 			 lack_water           :  1;   // 缺水
        uint16_t 			 compressor1_p        :  1;   // 1#冷凝压力过高告警
        uint16_t 			 compressor2_p        :  1;   // 2#冷凝压力过高告警
        uint16_t 			 outlet_press_h       :  1;   // 出水压力过高告警 
        uint16_t 			 outlet_press_l       :  1;   // 进水压力过低告警
        uint16_t             reserve1             :  11;
    }lc_alarm_state_t;
    uint16_t data;
}lc_alarm_state_u;
  

// /**
//   * @struct lc_ctrl_setting_t
//   * @brief  液冷设备控制数据结构体
//   */
// typedef struct
// {
//     uint16_t 			power;             		// 开关状态			0：关机；1：开机
// 	uint16_t			pump_manual_enable;		// 水泵手动使能		0：关闭；1：开启
// 	uint16_t			heating_enable;			// 电加热使能		0：关闭；1：开启
// 	uint16_t			water_in_out_ctrl;		// 进出水控制模式	0：回水；1：出水
// 	uint16_t			work_model;				// 模式设置	0-待机 1-自循环 2-制冷 3-制热 4-自动
// 	uint16_t			cooling_start_value;	// 制冷设点	2.0~50.0（℃）
// 	uint16_t			heating_start_value;	// 电加热设点	2.0~50.0（℃）
// 	uint16_t			heating_drop_value;		// 电加热回差	1.0~15.0（℃）整数
// 	uint16_t			fan_plate_humidity_set;	// 风盘设定湿度	0~100（%）
// 	uint16_t			humidity_drop_value;	// 湿度回差	0~30（%）
// 	uint16_t			pump_target_rpm;		// 水泵转速需求	0-100
// 	uint16_t			over_temp_value;		// 过热度设点	2.0~20.0（℃）
// 	uint16_t			water_high_pressure;	// 系统水压高设点	0~5.0（bar）
// 	uint16_t			water_low_pressure;		// 系统水压低设点	0~5.0（bar）
// }lc_ctrl_setting_t;


/**
  * @struct liquid_cooling_t
  * @brief  液冷设备数据结构体
  */
typedef struct
{
    uint16_t 			power;             		// 开关状态			0：关机；1：开机
	uint16_t			pump_manual_enable;		// 水泵手动使能		0：关闭；1：开启
	uint16_t			heating_enable;			// 电加热使能		0：关闭；1：开启
	uint16_t			water_in_out_ctrl;		// 进出水控制模式	0：回水；1：出水
	uint16_t			work_model;				// 模式设置	0-待机 1-自循环 2-制冷 3-制热 4-自动
	uint16_t			cooling_start_value;	// 制冷设点	2.0~50.0（℃）
	uint16_t			heating_start_value;	// 电加热设点	2.0~50.0（℃）
	uint16_t			heating_drop_value;		// 电加热回差	1.0~15.0（℃）整数
	uint16_t			fan_plate_humidity_set;	// 风盘设定湿度	0~100（%）
	uint16_t			humidity_drop_value;	// 湿度回差	0~30（%）
	uint16_t			pump_target_rpm;		// 水泵转速需求	0-100
	uint16_t			over_temp_value;		// 过热度设点	2.0~20.0（℃）
	uint16_t			water_high_pressure;	// 系统水压高设点	0~5.0（bar）
	uint16_t			water_low_pressure;		// 系统水压低设点	0~5.0（bar）
	uint16_t			compressor1_status;		// 压缩机1状态 0：关；1：开
	uint16_t			compressor2_status;		// 压缩机2状态 0：关；1：开
	uint16_t			pump_status;			// 水泵状态 0：关；1：开
	uint16_t			fan_status;				// 风机状态 0：关；1：开
	uint16_t			heating1_status;		// 电加热状态 0：关；1：开
	uint16_t			heating2_status;		// 电加热状态 0：关；1：开
	uint16_t			fan_plate1_status;		// 风盘1状态 0：关；1：开
	uint16_t			fan_plate2_status;		// 风盘2状态 0：关；1：开
	uint16_t			general_fault;			// 总故障 0：关；1：故障
	uint16_t			sys1_exhaust_pressure;	// 系统1高排气压力 0：正常；1：故障
	uint16_t			sys1_inhale_pressure;	// 系统1低吸气压力 0：正常；1：故障
	int16_t				sys1_exhaust_temp;		// 系统1高排气温度 0：正常；1：故障
	int16_t				sys1_temp_sensor_fault;	// 系统1内环温度传感器故障 0：正常；1：故障
	uint16_t			sys1_humidity_sensor_fault;	// 系统1内环温度传感器故障 0：正常；1：故障
	uint16_t			sys2_exhaust_pressure;	// 系统1高排气压力 0：正常；1：故障
	uint16_t			sys2_inhale_pressure;	// 系统1低吸气压力 0：正常；1：故障
	int16_t				sys2_exhaust_temp;		// 系统1高排气温度 0：正常；1：故障
	uint16_t			sys2_temp_sensor_fault;	// 系统1内环温度传感器故障 0：正常；1：故障
	uint16_t			sys2_humidity_sensor_fault;	// 系统1内环温度传感器故障 0：正常；1：故障
	uint16_t			water_out_pressure_alarm;	// 出水水压力过高过低告警 0：正常；1：故障
	uint16_t			water_in_pressure_alarm;	// 进水水压力过高过低告警 0：正常；1：故障
	int16_t				water_out_temp;				// 出水温度 0.1℃
	int16_t				water_in_temp;				// 回水温度 0.1℃
	uint16_t			water_out_pressure;			// 出水压力	0.01bar
	uint16_t			water_in_pressure;			// 进水压力 0.01bar
	uint16_t			compressor1_target_freq;	// 压缩机1目标频率 0.1HZ
	uint16_t			compressor1_current_freq;	// 压缩机1当前频率 0.1HZ
	uint16_t			fan_plate1_target_rpm;		// 风盘1目标转速 0~100(0.1V)
	uint16_t			valve1_opening;				// 阀1开度 1P
	uint16_t			valve1_step;				// 阀1步数 1P
	uint16_t			condense_pressure;			// 冷凝压力1 0.01bar
	int16_t 			exhaust_temp1;				// 排气温度1 0.1℃
	int16_t 			inhale_temp1;				// 吸气温度1 0.1℃
	uint16_t 			inhale_pressure1;			// 吸气压力1 0.01bar
	int16_t 			indoor_env_temp1;			// 室内环境温度1 0.1℃
	uint16_t 			indoor_humidity1;			// 室内湿度1 0~100.0(%)
	uint16_t			compressor2_target_freq;	// 压缩机2目标频率 0.1HZ
	uint16_t			compressor2_current_freq;	// 压缩机2当前频率 0.1HZ
	uint16_t			fan_plate2_target_rpm;		// 风盘2目标转速 0~100(0.1V)
	uint16_t			valve2_opening;				// 阀2开度 1P
	uint16_t			valve2_step;				// 阀2步数 1P
	uint16_t 			exhaust_pressure2;			// 排气压力2 0.01bar
	int16_t 			exhaust_temp2;				// 排气温度2 0.1℃
	int16_t 			inhale_temp2;				// 吸气温度2 0.1℃
	uint16_t 			inhale_pressure2;			// 吸气压力2 0.01bar
	int16_t 			indoor_env_temp2;			// 室内环境温度2 0.1℃
	uint16_t 			indoor_humidity2;			// 室内湿度2 0~100.0(%)
	int16_t 			water_out_temp_revise;		// 出水温度修正 0~100.0(%)
	uint16_t			fan_plate1_mode;			// 风盘1手动模式
	uint16_t			fan_plate1_rpm;				// 风盘1手动转速
	uint16_t			fan_plate2_mode;			// 风盘2手动模式
	uint16_t			fan_plate2_rpm;				// 风盘2手动转速
	
}liquid_cooling_t;

// /**
//   * @struct lc_ctrl_param_t
//   * @brief  液冷设备参数结构体
//   */
// typedef struct
// {
//     uint16_t 			preheat_on_min_temp;  			// 液冷PTC预加热启动最小温度
// 	uint16_t			preheat_on_mean_temp;			// 液冷PTC预加热启动平均温度
// 	uint16_t			preheat_water_out_temp;			// 液冷PTC预加热出水温度设置
// 	uint16_t			preheat_drop;					// 液冷PTC预加热回差
// 	uint16_t			pre_cooling_on_max_temp;		// 液冷预制冷启动最大温度
// 	uint16_t			pre_cooling_on_mean_temp;		// 液冷预制冷启动平均温度
// 	uint16_t			pre_cooling_drop;				// 液冷预制冷回差
// 	uint16_t			cooling_on_max_temp;			// 液冷制冷启动最大温度
// 	uint16_t			cooling_on_mean_temp;			// 液冷制冷启动平均温度
// 	uint16_t			cooling_water_out_temp;			// 液冷制冷出水温度
// 	uint16_t			cooling_drop;					// 液冷制冷回差
// 	uint16_t			heat_cooling_on_wait_time;		// 液冷加热/制冷启动等待时间
// 	uint16_t			water_flow_set;					// 液冷流量设置
// 	uint16_t			pump_off_delay;					// 水泵延迟关闭
// 	uint16_t			sys_standby_power;				// 系统待机功率
// 	uint16_t			bat_room_fan_on_temp;			// 电池仓风盘启动温度
// 	uint16_t			bat_room_fan_on_humidity;		// 电池仓风盘启动湿度
// 	uint16_t			bat_room_fan_off_temp;			// 电池仓风盘关闭温度
// 	uint16_t			bat_room_fan_off_humidity;		// 电池仓风盘关闭湿度
// 	uint16_t			bat_room_fan_cooling_temp;		// 电池仓风盘制冷开启温度
// 	uint16_t			bat_room_fan_drying_temp;		// 电池仓风盘除湿开启温度
// 	uint16_t			dev_room_fan_on_temp;			// 设备仓风盘启动温度
// 	uint16_t			dev_room_fan_on_humidity;		// 设备仓风盘启动湿度
// 	uint16_t			dev_room_fan_off_temp;			// 设备仓风盘关闭温度
// 	uint16_t			dev_room_fan_off_humidity;		// 设备仓风盘关闭湿度
// 	uint16_t			dev_room_fan_cooling_temp;		// 设备仓风盘制冷开启温度
// 	uint16_t			dev_room_fan_drying_temp;		// 设备仓风盘除湿开启温度
	
	
	
// }lc_ctrl_param_t;

/**
  * @struct lc_run_delay_t
  * @brief  液冷系统运行延时管理结构体
  */
typedef struct
{    
	uint8_t		lc_run_sta;						// 运行状态
	uint8_t		lc_ctrl_init;					// 上电控制初始化
    uint8_t     start_cooling_check;    		// 制冷检测标志
	uint8_t     start_cooling;    				// 制冷启动
	uint8_t     start_heating_check;    		// 加热检测标志
	uint8_t     start_heating;    				// 加热启动
	uint8_t     pump_stop_check;				// 制冷/加热停止后水泵延时关闭标志
	uint16_t  	cooling_heating_check_time;	// 启动加热/制冷等待计时
	int16_t   	pump_stop_time;				// 水泵停止倒计时
}lc_control_t;



/**
* @brief		获取液冷设备状态数据
* @param		[in] ： index 485索引号 
* @param		[out] ：lc  液冷设备状态结构体   
* @param		[out] ：buf 数据缓存   
* @return		电池充放电状态
* @retval		返回执行结果：-1异常
* @warning		无
*/

int lc_operation_data_read(uint32_t index ,liquid_cooling_t *lc,uint16_t *buf);

/**
* @brief		液冷设备控制
* @param		[in] ： index 485索引号 
* @param		[in] ：lc  液冷设备状态结构体    
* @return		电池充放电状态
* @retval		返回执行结果：-1异常
* @warning		无
*/

int lc_operation_ctrl(uint32_t index ,lc_threshold_set_t *lc );


int lc_single_ctrl(uint32_t index ,int32_t reg,uint16_t lc);

extern lc_control_t  lc_ctrl;

#endif
