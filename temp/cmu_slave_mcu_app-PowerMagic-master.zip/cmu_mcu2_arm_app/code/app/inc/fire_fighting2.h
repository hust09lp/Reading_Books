#ifndef __FIRE_FIGHTING2_H__
#define __FIRE_FIGHTING2_H__

#include "sci_frame.h"
#include "sofar_type.h"
#include "fire_fight_share.h"
#include "proj_cfg.h"
#include "fire_fight_dat_type.h"

typedef enum 
{
    FF_WARN_LOW_PRESSURE = 0,
    FF_WARN_HIG_PRESSURE = 1,
} ff_warn_e;

typedef enum {
    FF_EVENT_WARN_1        = 1,                   // 一级告警 事件
    FF_EVENT_WARN_2        = 2,                   // 二级告警 事件
    FF_EVENT_FAN_STA       = 3,                   // 消防排气 状态
    // FF_EVENT_OTHER_FF_TRIG = 4,                   // 其他储能柜触发消防
} ff_event_e;

/* 当发生告警时通知用户 */
typedef void ( *ff_event_callback )( dev_idx_t bat_cabinet_idx, ff_event_e ff_event, bool enable );

/* 数据更新通知 */
typedef void ( *ff_sta_update_callback )( void );

typedef struct {
    ff_event_callback       event_cb;
    ff_sta_update_callback  update_cb;
} ff_setting_t;


/**
 * @brief  消防功能初始化
 * @param  [in] modbus_idx modbus通讯索引
 * @param  [in] modbus_idx modbus通讯索引
 * @return SF_OK：成功  小于SF_OK: 失败
 */
int32_t fire_fighting2_init( modbus_idx_t modbus_idx, ff_setting_t *p_ff_setting );

/**
 * @brief  开启关闭消防告警
 * @param  [in] ff_warn : 消防告警
 * @param  [in] enable  : 告警开启/关闭
 * @return SF_OK：成功  非SF_OK：失败
 * @note   
 */
sf_ret_t fire_fighting2_warn_set_enabe( ff_warn_e ff_warn, bool enable );

/**
 * @brief  消防控制器 设置阈值
 * @param  [in] p_ff_threshold：消防控制器设置参数
 * @param  [in] bat_num：电池簇数量
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
int32_t fire_fighting2_set_threshold( ff_threshold_set_t *p_ff_threshold, uint8_t bat_num );

/**
 * @brief  设置 消防管理电池簇个数
 * @param  [in] bat_num ： 电池簇个数
 * @return SF_OK：成功  非SF_OK：失败
 * @note   
 */
int32_t fire_fighting2_set_battery_cluster_num( uint8_t bat_num );

/**
 * @brief  设置 消防控制器 气压报警阈值
 * @param  [in] low_pressure_threshold ：低压报警阈值
 * @param  [in] hig_pressure_threshold ：高压报警阈值
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
int32_t fire_fighting2_set_pressure_threshold( uint16_t low_pressure_threshold, uint16_t hig_pressure_threshold );

/**
 * @brief  传入电池数据 到消防控制器 内部
 * @param  [in] p_bat_dat_t ：电池数据
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
int32_t fire_fighting2_input_bat_info( bat_temper_t *p_bat_tmper_t );


/**
 * @brief  获取 消防控制器 di 状态【消防控制器角度】
 * @param  [out] p_cmu_start_lv   ： CMU启动电平
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
int32_t fire_fighting2_get_mb_di_sta( uint8_t *p_cmu_start_lv );

/**
 * @brief  获取 消防控制器 do 状态 【消防控制器角度】
 * @param  [out] p_warn1_lv     ：一级告警电平
 * @param  [out] p_warn2_lv     ：二级告警电平
 * @param  [out] p_com_fault_lv ：故障电平
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
int32_t fire_fighting2_get_mb_do_sta( uint8_t *p_warn1_lv, uint8_t *p_warn2_lv, uint8_t *p_com_fault_lv );

/**
 * @brief  获取 消防控制器 di 状态
 * @param  [out] p_di_sta_info   ： 消防控制器 DI 状态
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
int32_t fire_fighting2_get_di_sta( ff_di_sta_info_u *p_di_sta_info );

/**
 * @brief  获取 消防控制器 do 状态
 * @param  [out] p_do_sta_info   ： 消防控制器 DI 状态
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
int32_t fire_fighting2_get_do_sta( ff_do_sta_info_u *p_do_sta_info );

/**
 * @brief  获取 消防控制器 一级告警信息
 * @param  [out] p_warn1_info   ： 一级告警信息
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
int32_t fire_fighting2_get_warn1( ff_warn1_info_u *p_warn1_info );

/**
 * @brief  获取 消防控制器 二级告警信息
 * @param  [out] p_warn1_info   ： 二级告警信息
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
int32_t fire_fighting2_get_warn2( ff_warn2_info_u *p_warn2_info );

/**
 * @brief  获取 消防控制器 二级告警状态
 * @return ture：二级告警触发  false：未触发
 * @note   
 */
bool    fire_fighting2_get_warn2_alarm_sta( void );

/**
 * @brief  获取 消防控制器 传感器数据信息
 * @param  [out] p_sen_dat_info   ： 传感器数据
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
int32_t fire_fighting2_get_data( ff_sen_dat_info_t *p_sen_dat_info );

/**
 * @brief  获取 气瓶气压
 * @param  [out] p_ff_gas_pressure   ： 气瓶气压
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
int32_t fire_fighting2_get_ff_gas_pressure( uint16_t *p_ff_gas_pressure );

/**
 * @brief  获取 排气扇状态和触发排气扇原因
 * @param  [in] p_fan_sta   ： 风扇状态
 * @param  [in] p_fan_reas  ： 风扇联动原因
 * @param  [in] p_fan_on_co ： 风扇联动CO数值
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
int32_t fire_fighting2_get_fan_info( bool *p_fan_sta, fan_reas_info_u *p_fan_reas, uint16_t *p_fan_on_co );

/**
 * @brief  同步消防控制器数据 【同步，直接modbus获取】
 * @param  [in] 无
 * @return SF_OK：成功  小于SF_OK: 失败
 * @note   
 */
int32_t fire_fighting2_dat_sync( void );

/**
 * @brief  消防瓶共享触发标志 设置
 * @param  [in]  exsit_ff_danger ：当前存在消防隐患
 * @return 无
 */
void  fire_fighting2_set_share_ff_trig( bool exsit_ff_danger );

/**
 * @brief  设置 消防瓶共享在线状态
 * @param  [in]  self_online_sta    ：自身在线状态 （从机角度）
 * @param  [in]  p_slave_online_sta ：从机在线状态 （主机角度）
 * @return 无
 */
void  fire_fighting2_set_share_ff_online_sta( ol_sta_e self_online_sta, ol_sta_e *p_slave_online_sta );

/**
 * @brief  消防任务调度 
 * @param  [in]  无
 * @return 无
 */
void fire_fighting2_task_loop( void );


uint8_t fire_fighting2_get_solenoid_trace_sta( void );


#endif
