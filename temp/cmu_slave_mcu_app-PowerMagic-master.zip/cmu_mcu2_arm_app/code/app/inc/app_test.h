#ifndef __APP_TEST_H__
#define __APP_TEST_H__

void app_test_init( void );

#endif
