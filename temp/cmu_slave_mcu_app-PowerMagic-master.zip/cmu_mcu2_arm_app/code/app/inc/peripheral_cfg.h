#ifndef _PERIPHERAL_CFG_H_
#define _PERIPHERAL_CFG_H_

#include "app_cfg.h"

/*-------------------------------------- 硬件相关 -----------------------------------------------------*/
/*----------------------------------- 公共 -------------------------------------------------*/
#define  DI_AEROGEL                             DI_11           //< 气溶胶

/*----------------------------------- 电表定义 ----------------------------------------------*/
#define EM_RS485_MODBUS_INDEX                   MODBUS_INDEX3    // 电表通信485端口
#define EM_MODBUS_SLAVE_ADDR                    1                // 电表设备地址

/*----------------------------------- 消防DI/DO定义 -----------------------------------------*/
#define FIRE_FIGHTING_MODBUS_INDEX              MODBUS_INDEX1   // 消防控制器 modbus index
#define FIRE_FIGHTING_SLAVE_ADDR                1               // 电表设备地址

#define DI_FF_WARN1                             DI_8            // 消防一级故障
#define DI_FF_WARN2                             DI_9            // 消防二级故障
#define DI_FF_COMM_FAULT                        DI_10           // 消防公共故障

#define DO_FF_START                             DO_3            // 消防启动
#define DO_FF_ALERTOR                           DO_2            // 消防声光报警器

#define DO_DEV_FAULT_TO_CSU                     DO_5            // 设备舱 对CSU故障
#define DO_DEV_FAULT_TO_CSU_VALID_LV            0               // 设备舱 对CSU故障 有效电平
#define DO_DEV_FAULT_TO_OUT                     DO_7            // 设备舱 对外故障
#define DO_DEV_FAULT_TO_OUT_VALID_LV            1               // 设备舱 对外故障 有效电平

/*------------------------------------- 液冷定义 --------------------------------------------*/
#define LC_MODBUS_INDEX                         MODBUS_INDEX2   // 液冷机组 modbus index

/*------------------------------- --- 除湿器 定义-------------------------------------------*/
#define DRYER_MODBUS_INDEX                      MODBUS_INDEX4   // 除湿器 modbus index
#define MOD_SLAVE_ADDR_TEMPER_HUMI              8               // modbus 地址

#define DRYER_DEF_HUMIDITY                      75              // 湿度设定
#define DRYER_DEF_HUMIDITY_RET                  15              // 湿度回差

/*----------------------------------IO 拓展板 定义-------------------------------------------*/
#define EXT_IO_MODBUS_INDEX                     MODBUS_INDEX4   // IO拓展板 modbus index
#define MOD_SLAVE_ADDR_BAT1_BOX_IO_EXT          1               // 电池舱1 modbus 地址 (1~6)

/* 测试，后续恢复 0、1 */
#define EXT_IO_DI_FLOOD1_PORT                   0 // 4          // DI 水浸1 IO port
#define EXT_IO_DI_FLOOD2_PORT                   1 // 5          // DI 水浸2 IO port
#define EXT_IO_DI_DEV_DOOR_PORT                 2               // DI 配电仓 门磁 IO port
#define EXT_IO_DI_BAT_DOOR_PORT                 3               // DI 电池仓 门磁 IO port

#define EXT_IO_DI_TMPER_SEN_PORT                4               // DI 温感 IO port
#define EXT_IO_DI_SMOKE_SEN_PORT                5               // DI 烟感 IO port

#define EXT_IO_DO_FAN_PORT                      0               // DO 风扇 IO port
#define EXT_IO_DO_HIG_VOL                       4               // DO 高压盒 IO port


#endif
