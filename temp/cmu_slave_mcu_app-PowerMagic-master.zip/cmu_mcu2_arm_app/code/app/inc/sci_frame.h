#ifndef __SCI_FRAME_H__
#define __SCI_FRAME_H__

#include "data_types.h"

#include "lc_data_type.h"
#include "lc_type_media.h"
#include "lc_type_aine.h"
#include "lc_type_cvte.h"
#include "bat_temper_def.h"

/*----------------------------- SCI 帧格式 ------------------------------------*/


/*------------------MCU2 -> MCU1 ------------------*/

/**
  * @struct di_status_info_u
  * @brief  储能柜 DI
  */
typedef union {
    uint16_t value;
    struct {
        uint16_t flood1:         1;     // 水淹IO1
        uint16_t flood2:         1;     // 水淹IO2 
        uint16_t entrance_dev:   1;     // 门磁IO 设备舱
        uint16_t entrance_bat1:  1;     // 门磁IO 电池舱1
        uint16_t entrance_bat2:  1;     // 门磁IO 电池舱2
        uint16_t entrance_bat3:  1;     // 门磁IO 电池舱3
        uint16_t entrance_bat4:  1;     // 门磁IO 电池舱4
        uint16_t entrance_bat5:  1;     // 门磁IO 电池舱5
        uint16_t entrance_bat6:  1;     // 门磁IO 电池舱6
        uint16_t ff_warn1:       1;     // 消防一级告警 
        uint16_t ff_warn2:       1;     // 消防二级告警 
        uint16_t ff_fault:       1;     // 消防故障告警
    } bit;
} dev_di_sta_info_u;

/**
  * @struct dev_do_sta_info2_u
  * @brief  储能柜 DO 状态
  */
typedef union{
    uint16_t value;
    struct{
        uint16_t fan_status:        1; // 排气扇 状态
        uint16_t ff_start_sta:      1; // 消防启动 状态 
        uint16_t lamp_alarm_sta:    1; // 声光报警 状态
        uint16_t fault_to_csu:      1; // 对CSU故障信号 状态
        uint16_t fault_to_out:      1; // 对外故障信号 状态
        uint16_t fault_to_hig_vol:  1; // 对高压盒故障信号 状态
    }bit;
}dev_do_sta_info_u;

/**
  * @struct ff_di_sta_info_u
  * @brief    消防DI状态
  */
typedef union{
    uint32_t value;
    struct{
        uint16_t smoke_sensor1: 1;  // 电池仓1 烟感  
        uint16_t temp_sensor1:  1;  // 电池仓1 温感
        uint16_t smoke_sensor2: 1;  // 电池仓2 烟感     
        uint16_t temp_sensor2:  1;  // 电池仓2 温感
        uint16_t smoke_sensor3: 1;  // 电池仓3 烟感  
        uint16_t temp_sensor3:  1;  // 电池仓3 温感
        uint16_t smoke_sensor4: 1;  // 电池仓4 烟感  
        uint16_t temp_sensor4:  1;  // 电池仓4 温感
        uint16_t smoke_sensor5: 1;  // 电池仓5 烟感  
        uint16_t temp_sensor5:  1;  // 电池仓5 温感
        uint16_t smoke_sensor6: 1;  // 电池仓6 烟感  
        uint16_t temp_sensor6:  1;  // 电池仓6 温感

        uint16_t ff_pipe_sig:   1;  // 消防管道信号反馈
    }bit;
}ff_di_sta_info_u;

/**
  * @struct ff_do_sta_info_u
  * @brief    消防DO状态
  */
typedef union{
    uint32_t value;
    struct{
        uint16_t ff_solenoid        :1;     // 灭火剂电磁阀
        uint16_t ff_warn1           :1;     // 消防一级告警
        uint16_t ff_warn2           :1;     // 消防二级告警
        uint16_t ff_com_falut       :1;     // 消防公共故障信号
    }bit;
}ff_do_sta_info_u;

/**
  * @struct dry_sta_info_u
  * @brief  除湿器状态
  */
typedef union{
    uint16_t value;
    struct{
        uint16_t drying_sta1:1;                 // 电池柜1 除湿状态
        uint16_t drying_sta2:1;                 // 电池柜2 除湿状态
        uint16_t drying_sta3:1;                 // 电池柜3 除湿状态
        uint16_t drying_sta4:1;                 // 电池柜4 除湿状态
        uint16_t drying_sta5:1;                 // 电池柜5 除湿状态
        uint16_t drying_sta6:1;                 // 电池柜6 除湿状态
    }bit;
} dry_sta_info_u;

/**
  * @struct fan_reas_info_u
  * @brief  风机联动原因
  */
typedef union{
    uint16_t value;
    struct{
        uint16_t mix_sensor1_co_ppm:	1;		// 电池柜1 复合型传感器#CO超阈值
        uint16_t mix_sensor2_co_ppm:	1;		// 电池柜2 复合型传感器#CO超阈值
        uint16_t mix_sensor3_co_ppm:	1;		// 电池柜3 复合型传感器#CO超阈值
        uint16_t mix_sensor4_co_ppm:	1;		// 电池柜4 复合型传感器#CO超阈值
        uint16_t mix_sensor5_co_ppm:	1;		// 电池柜5 复合型传感器#CO超阈值
        uint16_t mix_sensor6_co_ppm:	1;		// 电池柜6 复合型传感器#CO超阈值
    }bit;
} fan_reas_info_u;

/**
  * @struct dev_warn_info1_u
  * @brief  储能柜-告警信息 
  */
typedef union{
    uint16_t value;
    struct{
        uint16_t flood_warn :    1;             // 水淹告警
        uint16_t ff_warn1   :    1;             // 消防一级告警
        uint16_t ele_meter_offline:    1;       // 电表通讯失联
        
        uint16_t bat1_ext_io_offline    :1;     // 电池仓 IO拓展板 通讯失联
        uint16_t bat2_ext_io_offline    :1;     // 电池仓 IO拓展板 通讯失联
        uint16_t bat3_ext_io_offline    :1;     // 电池仓 IO拓展板 通讯失联
        uint16_t bat4_ext_io_offline    :1;     // 电池仓 IO拓展板 通讯失联
        uint16_t bat5_ext_io_offline    :1;     // 电池仓 IO拓展板 通讯失联
        uint16_t bat6_ext_io_offline    :1;     // 电池仓 IO拓展板 通讯失联
    }bit;
} dev_warn_info_u;

/**
  * @struct ff_warn1_info_u
  * @brief  消防一级告警
  */
typedef union{
    uint16_t array[4];
    uint64_t value;
    struct{
        uint16_t total_pack_temp_alarm: 1;              // 0 电池簇总告警
        uint16_t pack1_temp_alarm:	1;					// 1 电池柜1 簇温度报警标志
        uint16_t pack2_temp_alarm:	1;					// 2 电池柜2 簇温度报警标志
        uint16_t pack3_temp_alarm:	1;					// 3 电池柜3 簇温度报警标志
        uint16_t pack4_temp_alarm:	1;					// 4 电池柜4 簇温度报警标志
        uint16_t pack5_temp_alarm:	1;					// 5 电池柜5 簇温度报警标志
        uint16_t pack6_temp_alarm:	1;					// 6 电池柜6 簇温度报警标志
        
        uint16_t ff_smoke_sensor1:  1;                  // 7 电池柜1烟感报警
        uint16_t ff_smoke_sensor2:  1;                  // 8 电池柜2烟感报警
        uint16_t ff_smoke_sensor3:  1;                  // 9 电池柜3烟感报警
        uint16_t ff_smoke_sensor4:  1;                  // 10 电池柜4烟感报警
        uint16_t ff_smoke_sensor5:  1;                  // 11 电池柜5烟感报警
        uint16_t ff_smoke_sensor6:  1;                  // 12 电池柜6烟感报警

        uint16_t ff_temp_sensor1:   1;                  // 13 电池柜1 温感报警
        uint16_t ff_temp_sensor2:   1;                  // 14 电池柜2 温感报警
        uint16_t ff_temp_sensor3:   1;                  // 15 电池柜3 温感报警
        uint16_t ff_temp_sensor4:   1;                  // 16 电池柜4 温感报警
        uint16_t ff_temp_sensor5:   1;                  // 17 电池柜5 温感报警
        uint16_t ff_temp_sensor6:   1;                  // 18 电池柜6 温感报警

        uint16_t mix_sensor1_temp_alarm:    1;          // 19 电池柜1#复合传感器温度报警标
        uint16_t mix_sensor2_temp_alarm:    1;          // 20 电池柜2#复合传感器温度报警标
        uint16_t mix_sensor3_temp_alarm:    1;          // 21 电池柜3#复合传感器温度报警标
        uint16_t mix_sensor4_temp_alarm:    1;          // 22 电池柜4#复合传感器温度报警标
        uint16_t mix_sensor5_temp_alarm:    1;          // 23 电池柜5#复合传感器温度报警标
        uint16_t mix_sensor6_temp_alarm:    1;          // 24 电池柜6#复合传感器温度报警标

        uint16_t mix_sensor1_pm25_co_alarm:	1;		    // 25 电池柜1#复合传感器pm25/co报警标志
        uint16_t mix_sensor2_pm25_co_alarm:	1;		    // 26 电池柜2#复合传感器pm25/co报警标志
        uint16_t mix_sensor3_pm25_co_alarm:	1;		    // 27 电池柜3#复合传感器pm25/co报警标志
        uint16_t mix_sensor4_pm25_co_alarm:	1;		    // 28 电池柜4#复合传感器pm25/co报警标志
        uint16_t mix_sensor5_pm25_co_alarm:	1;		    // 29 电池柜5#复合传感器pm25/co报警标志
        uint16_t mix_sensor6_pm25_co_alarm:	1;		    // 30 电池柜6#复合传感器pm25/co报警标志

        uint16_t mix_sensor1_offline:           1;      // 31 电池柜1#复合传感器 通讯故障
        uint16_t mix_sensor2_offline:           1;      // 32 电池柜2#复合传感器 通讯故障
        uint16_t mix_sensor3_offline:           1;      // 33 电池柜3#复合传感器 通讯故障
        uint16_t mix_sensor4_offline:           1;      // 34 电池柜4#复合传感器 通讯故障
        uint16_t mix_sensor5_offline:           1;      // 35 电池柜5#复合传感器 通讯故障
        uint16_t mix_sensor6_offline:           1;      // 36 电池柜6#复合传感器 通讯故障

        uint16_t ff_glass_pressure_over_hig:    1;      // 37 消防气瓶 1 高压报警
        uint16_t ff_glass_pressure_over_low:    1;      // 38 消防气瓶 1 低压报警

        uint16_t ff_share_offline         :1;           // 39 消防共享从机本机离线
        uint16_t ff_share_slave1_offline  :1;           // 40 消防共享从机1离线
        uint16_t ff_share_slave2_offline  :1;           // 41 消防共享从机2离线
        uint16_t ff_share_slave3_offline  :1;           // 42 消防共享从机3离线
        uint16_t ff_share_slave4_offline  :1;           // 43 消防共享从机4离线
        uint16_t ff_share_slave5_offline  :1;           // 44 消防共享从机5离线

        uint16_t ff_offline               :1;           // 45 消防控制器通讯失联告警
        uint16_t ff_io_ext_offline        :1;           // 46 消防控制器 IO拓展板1/2/3/4/5/6 通讯失联告警
    }bit;
} ff_warn1_info_u;

/**
  * @struct dry_warn_info_u
  * @brief  除湿器-告警信息 
  */
typedef union{
    uint16_t value;
    struct{
        uint16_t offline1:    1;              // 电池舱1 除湿器失联
        uint16_t offline2:    1;              // 电池舱2 除湿器失联
        uint16_t offline3:    1;              // 电池舱3 除湿器失联
        uint16_t offline4:    1;              // 电池舱4 除湿器失联
        uint16_t offline5:    1;              // 电池舱5 除湿器失联
        uint16_t offline6:    1;              // 电池舱6 除湿器失联

        uint16_t inter_warning1:    1;        // 电池舱1 除湿器 内部异常告警
        uint16_t inter_warning2:    1;        // 电池舱2 除湿器 内部异常告警
        uint16_t inter_warning3:    1;        // 电池舱3 除湿器 内部异常告警
        uint16_t inter_warning4:    1;        // 电池舱4 除湿器 内部异常告警
        uint16_t inter_warning5:    1;        // 电池舱5 除湿器 内部异常告警
        uint16_t inter_warning6:    1;        // 电池舱6 除湿器 内部异常告警
    }bit;
} dry_warn_info_u;


/**
  * @struct dev_fault_info_u
  * @brief  储能柜故障
  */
typedef union{
    uint16_t value;
    struct{
        uint16_t flood_fault            :1;     // 水淹故障
        uint16_t entrance_fault         :1;     // 门磁故障
        uint16_t ff_warn2_flag          :1;     // 消防二级告警总标志位【逻辑】
    }bit;
} dev_fault_info_u;


/**
  * @struct ff_warn2_info_u
  * @brief  消防 故障信息 - 消防二级报警
  */
typedef union{
    uint16_t array[4];
    uint64_t value;
    struct{
        uint16_t start_ff_solenoid:	1;                  // 0 灭火剂启动标志
        
        uint16_t pack_temp_alarm1:	1;					// 1 电池柜1 簇温度报警标志
        uint16_t pack_temp_alarm2:	1;					// 2 电池柜2 簇温度报警标志
        uint16_t pack_temp_alarm3:	1;					// 3 电池柜3 簇温度报警标志
        uint16_t pack_temp_alarm4:	1;					// 4 电池柜4 簇温度报警标志
        uint16_t pack_temp_alarm5:	1;					// 5 电池柜5 簇温度报警标志
        uint16_t pack_temp_alarm6:	1;					// 6 电池柜6 簇温度报警标志

        uint16_t pack_temp_mix_co_alarm1:  1;           // 7 电池柜1 PACK温度+1#CO报警
        uint16_t pack_temp_mix_co_alarm2:  1;           // 8 电池柜2 PACK温度+2#CO报警
        uint16_t pack_temp_mix_co_alarm3:  1;           // 9  电池柜3 PACK温度+3#CO报警
        uint16_t pack_temp_mix_co_alarm4:  1;           // 10 电池柜4 PACK温度+4#CO报警
        uint16_t pack_temp_mix_co_alarm5:  1;           // 11 电池柜5 PACK温度+5#CO报警
        uint16_t pack_temp_mix_co_alarm6:  1;           // 12 电池柜6 PACK温度+6#CO报警

        uint16_t smoke_sen_temp_sen_alarm1:  1;         // 13 电池柜 1#烟感+温感报警
        uint16_t smoke_sen_temp_sen_alarm2:  1;         // 14 电池柜 2#烟感+温感报警
        uint16_t smoke_sen_temp_sen_alarm3:  1;         // 15 电池柜 3#烟感+温感报警
        uint16_t smoke_sen_temp_sen_alarm4:  1;         // 16 电池柜 4#烟感+温感报警
        uint16_t smoke_sen_temp_sen_alarm5:  1;         // 17 电池柜 5#烟感+温感报警
        uint16_t smoke_sen_temp_sen_alarm6:  1;         // 18 电池柜 6#烟感+温感报警

        uint16_t smoke_sen_mix_tmp1_alarm1:  1;         // 19 烟感+1#复合型传感器温度
        uint16_t smoke_sen_mix_tmp2_alarm2:  1;         // 20 烟感+2#复合型传感器温度
        uint16_t smoke_sen_mix_tmp3_alarm3:  1;         // 21 烟感+3#复合型传感器温度
        uint16_t smoke_sen_mix_tmp4_alarm4:  1;         // 22 烟感+4#复合型传感器温度
        uint16_t smoke_sen_mix_tmp5_alarm5:  1;         // 23 烟感+5#复合型传感器温度
        uint16_t smoke_sen_mix_tmp6_alarm6:  1;         // 24 烟感+6#复合型传感器温度

        uint16_t tmp_sen_mix_co_alarm1:      1;         // 25 电池柜1 温感+复合型传感器1#CO
        uint16_t tmp_sen_mix_co_alarm2:      1;         // 26 电池柜2 温感+复合型传感器2#CO
        uint16_t tmp_sen_mix_co_alarm3:      1;         // 27 电池柜3 温感+复合型传感器3#CO
        uint16_t tmp_sen_mix_co_alarm4:      1;         // 28 电池柜4 温感+复合型传感器4#CO
        uint16_t tmp_sen_mix_co_alarm5:      1;         // 29 电池柜5 温感+复合型传感器5#CO
        uint16_t tmp_sen_mix_co_alarm6:      1;         // 30 电池柜6 温感+复合型传感器6#CO

        uint16_t cmu_start_ff:               1;         // 31 CMU启动消防标志
        uint16_t share_ff_trig:              1;         // 32 储能柜之间消防联动 (存在消防隐患)

        uint16_t pack_tmp_rise_co1:          1;         // 33 PACK温升+1#CO报警 
        uint16_t pack_tmp_rise_co2:          1;         // 34 PACK温升+2#CO报警 
        uint16_t pack_tmp_rise_co3:          1;         // 35 PACK温升+3#CO报警
        uint16_t pack_tmp_rise_co4:          1;         // 36 PACK温升+4#CO报警 
        uint16_t pack_tmp_rise_co5:          1;         // 37 PACK温升+5#CO报警 
        uint16_t pack_tmp_rise_co6:          1;         // 38 PACK温升+6#CO报警 
    }bit;
} ff_warn2_info_u;

typedef struct {
    int16_t             mix_sen_temp;           // 复合型传感器温度，单位，0.1℃
    uint16_t            mix_sen_co;             // 复合型传感器CO浓度，单位：ppm
    uint16_t            mix_sen_pm25;           // 复合型传感器pm2.5浓度，单位：ug/m³
} ff_sen_dat_t;

typedef struct 
{
    ff_sen_dat_t        mix_sen[ 6 ];    // 电池仓 传感器数据
} ff_sen_dat_info_t;

typedef struct 
{
    rate_t lc_com;                      //< 液冷丢包率
    rate_t ff_com;                      //< 消防丢包率
    rate_t dh_com[6];                   //< 除湿器丢包率
    rate_t io_ext_com[6];               //< IO拓展板丢包率
} pack_loss_rate_t;

#pragma pack(1)
typedef struct
{
	uint8_t             param_init_flag;        // mcu2参数初始化标记
    lc_type_e           lc_type;
    dev_di_sta_info_u   dev_di_sta_info;        // 配电仓DI 输入状态
    dev_do_sta_info_u   dev_do_sta_info;        // 配电仓DO 输入状态
    ff_di_sta_info_u    ff_di_sta_info;         // 消防DI 输入状态
    ff_do_sta_info_u    ff_do_sta_info;         // 消防DO 输入状态
    lc_sta_u            lc_sta_info;            // 液冷状态信息
    dry_sta_info_u      dry_sta_info;           // 除湿状态信息
    fan_reas_info_u     fan_reas_info;          // 消防风机联动原因

    dev_warn_info_u     dev_warn_info;          // 配电仓 告警信息
    lc_warning_u        lc_warn_info;           // 液冷告警信息
    ff_warn1_info_u     ff_warn1_info;          // 消防一级告警信息
    dry_warn_info_u     dry_warn_info;          // 除湿器告警信息

    dev_fault_info_u    dev_fault_info;         // 配电柜故障信息
    lc_fault_u          lc_fault_info;          // 液冷故障信息
    ff_warn2_info_u     ff_warn2_info;          // 消防二级报警

    uint16_t            chg_dischg_ctrl;		// 禁充禁放标志  1:

    uint16_t            bat1_humidity;          // 电池仓1 湿度，单位：1 RH%
    uint16_t            bat2_humidity;          // 电池仓2 湿度，单位：1 RH%
    uint16_t            bat3_humidity;          // 电池仓3 湿度，单位：1 RH%
    uint16_t            bat4_humidity;          // 电池仓4 湿度，单位：1 RH%
    uint16_t            bat5_humidity;          // 电池仓5 湿度，单位：1 RH%
    uint16_t            bat6_humidity;          // 电池仓6 湿度，单位：1 RH%

    int16_t             bat1_temper;            // 电池仓1 温度，单位：0.1℃
    int16_t             bat2_temper;            // 电池仓2 温度，单位：0.1℃
    int16_t             bat3_temper;            // 电池仓3 温度，单位：0.1℃
    int16_t             bat4_temper;            // 电池仓4 温度，单位：0.1℃
    int16_t             bat5_temper;            // 电池仓5 温度，单位：0.1℃
    int16_t             bat6_temper;            // 电池仓6 温度，单位：0.1℃

    int16_t             lc_outdoor_temper;      // 液冷机组 室外环境温度，单位：0.1℃
    int16_t             lc_inlet_temp;          // 液冷机组 进水温度，单位：0.1℃
    int16_t             lc_outlet_temp;         // 液冷机组 出水温度，单位：0.1℃
    uint16_t            lc_inlet_pressure;      // 液冷机组 进水压力，单位：0.01 bar
    uint16_t            lc_outlet_pressure;     // 液冷机组 出水压力，单位：0.01 bar

    uint8_t             lc_control_mode:4;      // 液冷机组 运行状态
    uint8_t             lc_sofar_mode:4;        // 液冷机组 首航逻辑运行状态
    uint8_t             lc_flow;                // 液冷机组 供液流量 1%
    uint16_t            lc_dst_tmp;             // 液冷机组 供液目标温度 0.1℃

    ff_sen_dat_info_t   ff_sen_data_info;       // 消防传感器数据

    uint16_t            fire_fan_start_1co;		// 风机联动时复合型传感器1的CO 浓度值
    uint16_t            fire_fan_start_2co;		// 风机联动时复合型传感器2的CO 浓度值
    uint16_t            fire_fan_start_3co;		// 风机联动时复合型传感器3的CO 浓度值
    uint16_t            fire_fan_start_4co;		// 风机联动时复合型传感器4的CO 浓度值
    uint16_t            fire_fan_start_5co;		// 风机联动时复合型传感器5的CO 浓度值
    uint16_t            fire_fan_start_6co;		// 风机联动时复合型传感器6的CO 浓度值

    uint16_t            ff_cylinder_press;      // 消防气瓶气压，单位：1Kpa
    uint16_t            reserve[31];            // 保留
    uint8_t             ff_sw_sub_ver;          // 消防软件次版本
    uint8_t             ff_sw_major_ver;        // 消防软件主版本
    pack_loss_rate_t    pack_loss_rate;         // 设备丢包率
}Realtime_SysInfo_t2;


#pragma pack()


/*------------------------------------------------------- 实时数据 END -----------------------------------------------------------*/

/**
  * @struct lc_threshold_set
  * @brief  液冷机阈值设置
  */
typedef struct
{
    uint16_t         lc_type;                         // 液冷机组型号  0:美的 1:空调国际 2:视源
    uint16_t         lc_auto_mode;                    // 手自模式 0:手动  1：自动
    uint16_t         lc_mode;                         // 模式设置 0：待机 1：制热 2：制冷 3：自循环
    uint16_t         lc_ctrl_mode;                    // 控制方式 0：出水 1：回水
    uint16_t         lc_pump_rate;                    // 水泵转速设定 单位：1%
    int16_t          lc_cooling_point;                // 制冷温度设定 单位：0.1℃ 
    int16_t          lc_cooling_drop;                 // 制冷回差 单位：0.1℃ 
    int16_t          lc_heating_point;                // 制热温度设定 单位：0.1℃ 
    int16_t          lc_heating_drop;                 // 制热回差 单位：0.1℃ 
    uint16_t         lc_cool_outlet_low_tmp;          // 制冷出水低温告警设定 单位：0.1℃ 
    uint16_t         lc_heat_outlet_hig_tmp;          // 制热出水高温告警设定 单位：0.1℃ 
    uint16_t         lc_outlet_pressure_high;         // 出水压力过高设定点 单位：bar
    uint16_t         lc_inlet_pressure_low;           // 回水压力过低设定点 单位：bar
} lc_threshold_set_t2;

/**
  * @struct ff_threshold_set_t
  * @brief  消防阈值设置
  */
typedef struct
{
	uint16_t		ff_gas_pressure_low;				// 消防气瓶压力表1低压阈值
	uint16_t		ff_gas_pressure_high;				// 消防气瓶压力表1高压阈值
	uint16_t		ff_alarm_level1_pack_temp;			// 消防一级报警PACK温度，单位：1℃
	uint16_t		ff_alarm_level1_sensor_temp;		// 消防一级报警复合传感器温度，单位：1℃
	uint16_t		ff_alarm_level1_sensor_co;			// 消防一级报警复合传感器CO浓度【工商业中无效】
	uint16_t		ff_alarm_level1_sensor_pm25;		// 消防一级报警复合传感器pm2.5浓度
	uint16_t		ff_alarm_level2_pack_temp;			// 消防二级报警PACK最高温度【pack】，单位：1℃
	uint16_t		ff_alarm_level2_sensor_co;			// 消防二级报警复合传感器CO浓度【pack】
	uint16_t		ff_alarm_level2_compart_temp;       // 消防二级报警复合传感器温度【舱级】，单位：1℃
	uint16_t		ff_alarm_level2_compart_co;			// 消防二级报警复合传感器CO浓度【舱级】
	uint16_t		ff_fan_start_co;					// 消防风机联动复合传感器CO浓度
	uint16_t		ff_fan_start_pm25;					// 消防风机联动复合传感器pm2.5浓度【工商业中无效】
	uint16_t		ff_control_word;					// 消防控制字 0：自动  1：手动 2：复位
	uint16_t		ff_fan_off_co;						// 关闭风机联动CO浓度
	uint16_t		ff_alarm_level2_pack_temp1;			// 消防二级报警PACK温度次高温度【pack】
	uint16_t		reserve[2];                         // 预留
	uint16_t		local_ff_enable;                    // 本地消防备份使能
}ff_threshold_set_t;

/**
  * @struct lc_control_param
  * @brief  液冷机控制参数
  */
typedef struct
{
    bat_tmp_setting_t tmp_setting;
} lc_control_param_t2;


#define SCI_DAT_TO_INT16( p_sci_dat, int16_val )            do{ int16_val = (p_sci_dat[0] << 8) || p_sci_dat[1]; }while(0)
#define SCI_DAT_TO_INT32( p_sci_dat, int32_val )            do{ int32_val = (p_sci_dat[0] << 24) || (p_sci_dat[1] << 16) || (p_sci_dat[2] << 8) || p_sci_dat[3]; }while(0)
#define SCI_DAT_TO_INT64( p_sci_dat, int64_val )            do{ int64_val = (p_sci_dat[0] << 56) || (p_sci_dat[1] << 48) || (p_sci_dat[2] << 40) || (p_sci_dat[3] << 32) \
                                                                            || (p_sci_dat[4] << 24) || (p_sci_dat[5] << 16) || (p_sci_dat[6] << 8) || p_sci_dat[7]; }while(0)
/**
  * @struct dry_param_t
  * @brief  除湿逻辑阈值
  */
typedef struct {
    uint16_t  dst_humidity;                     // 湿度设定，单位：RH%
    uint16_t  ret_humidity;                     // 湿度回差，单位：RH%
} dry_param_t2;

/**
  * @struct bat_param_t
  * @brief  设置电池仓个数
  */
typedef struct {
    uint16_t  bat_num;                          // 电池仓个数
} bat_param_t2;

/**
  * @struct set_fan_t
  * @brief  设置排气扇状态
  */
typedef struct {
    uint16_t  fan_sta;                          // 排气扇状态
} set_fan_t;


/**
  * @struct set_fan_t
  * @brief  设置储能柜属性
  */
typedef struct 
{
    uint16_t  eng_cab_addr;                     // 储能柜MCU2地址
    uint16_t  eng_cab_num;                      // 并机储能柜个数
} set_eng_cab_attr_t;

/**
  * @enum sci_ret_result_e
  * @brief  SCI 通用返回定义
  */
typedef enum {
    SCI_RET_FAIL    = 0,
    SCI_RET_SUCCESS = 1,
} sci_ret_result_e;

#define SCI_REPLY           0
#define SCI_NO_REPLY        -1

#endif
