#ifndef __SOFAR_ERROR_CODE_H__
#define __SOFAR_ERROR_CODE_H__

typedef int sf_ret_t;

#define SF_RET_OK                                   (-0)   //  0, 执行成功
#define SF_RET_COM_ERROR                            (-1)   // -1, 通用错误
#define SF_RET_INVALID_PARM                         (-2)   // -2, 无效的入参
#define SF_RET_NOT_SUPPORTED                        (-3)   // -3, 不支持

#endif
