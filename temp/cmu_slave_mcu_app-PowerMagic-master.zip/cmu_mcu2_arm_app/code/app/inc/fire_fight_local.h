#ifndef _FIRE_FIGHT_LOCAL_H_
#define _FIRE_FIGHT_LOCAL_H_

#include "sofar_type.h"
#include "fire_fight_dat_type.h"

typedef void ( *f_local_warn_change_cb )( void );

sf_ret_t fire_fight_local_init( f_local_warn_change_cb ff_warn_change_cb );

sf_ret_t fire_fight_local_set_bat_num( uint8_t num );

sf_ret_t fire_fight_local_set_threshold( ff_threshold_set_t *p_ff_threshold_setting, uint8_t num );

void fire_fight_local_set_enable( bool enable );

void fire_fight_local_task_loop( bat_temper_t *p_bat_temper, ff_sen_dat_info_t *p_ff_sen_dat );

void fire_fight_local_get_warn2( ff_warn2_info_u *p_local_warn2 );

void fire_fight_local_get_di_sta( ff_di_sta_info_u *p_local_di_sta );


#endif
