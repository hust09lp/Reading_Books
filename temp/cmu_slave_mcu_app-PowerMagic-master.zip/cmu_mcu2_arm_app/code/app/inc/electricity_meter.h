#ifndef __ELECTRICITY_H__
#define __ELECTRICITY_H__

#include <stdint.h>
#include <stddef.h>

#define EM_DATA_LEN     	6
#define EM_DATA1_LEN     	16
#define EM_DATA2_LEN     	2
#define EM_DATA3_LEN     	8

#define EM_REG_UAB     0x2000
#define EM_REG_UBC     0x2002
#define EM_REG_UCA     0x2004
#define EM_REG_UA      0x2006
#define EM_REG_UB      0x2008
#define EM_REG_UC      0x200A
#define EM_REG_IA      0x200C
#define EM_REG_IB      0x200E
#define EM_REG_IC      0x2010

#define EM_REG_PT      0x2012
#define EM_REG_PA      0x2014
#define EM_REG_PB      0x2016
#define EM_REG_PC      0x2018
#define EM_REG_QT      0x201A
#define EM_REG_QA      0x201C
#define EM_REG_QB      0x201E
#define EM_REG_QC      0x2020

#define EM_REG_PFT     0x202A
#define EM_REG_PFA     0x202C
#define EM_REG_PFB     0x202E
#define EM_REG_PFC     0x2030

#define EM_REG_FREQ    0x2044

#define EM_REG_IMPEP    	0x101E
#define EM_REG_IMPEPA    	0x1020
#define EM_REG_IMPEPB    	0x1022
#define EM_REG_IMPEPC    	0x1024
#define EM_REG_NET_IMPEP    0x1026
#define EM_REG_EXP_EP    	0x1028
#define EM_REG_EXP_EPA    	0x102A
#define EM_REG_EXP_EPB    	0x102C
#define EM_REG_EXP_EPC    	0x102E
#define EM_REG_NET_EXP_EP   0x1030


/**
  * @struct em_param_t
  * @brief  电表参数结构体
  */
typedef struct
{    
    int16_t software_version;           // 软件版本
    int16_t u_code;                     // Programming code (1 9999)
    int16_t net_select;                 // 线制选择 0：三相四线   1：三相三线
    int16_t current_rate;               // 电流转换率 (1 9999)
    int16_t voltage_rate;               // 电压转换率
    int16_t rotating_disp_time;         // 显示切换时间
    int16_t backlight_time;             // 背光时间
    int16_t Reserve;                    // 保留
    int16_t protocol;                   // 协议
    int16_t baud_rate;                  //波特率
    int16_t addr;                       //地址
}em_param_t;

/**
  * @struct em_data_t
  * @brief  电表数据结构体
  */
typedef struct
{    
	float     voltage_a;				// a相电压 		0.1
	float     voltage_b;				// b相电压 		0.1
	float     voltage_c;				// c相电压 		0.1
	float     combined_active_power;    // 组合有功功率 		0.1
	float     active_power_a;    		// a相有功功率  		0.1
	float     active_power_b;    		// b相有功功率 		0.1
	float     active_power_c;    		// c相有功功率		0.1
	float     combined_reactive_power; 	// 组合无功功率		0.1
	float     reactive_power_a;			// a相无功功率		0.1
	float     reactive_power_b;			// b相无功功率		0.1
	float     reactive_power_c;			// c相无功功率		0.1
	float     freq;						// 频率				0.01
	float     ImpEp;					// 总正向有功能量	0.1
	float     ImpEp_A;					// A相正向有功能量	0.1
	float     ImpEp_B;					// B相正向有功能量	0.1
	float     ImpEp_C;					// C相正向有功能量	0.1
}em_data_t;

union data
{
	uint32_t dword;
	float f_data;
};



extern em_data_t em_data;

int em_param_read(uint32_t index,em_data_t* data, uint32_t slave);




#endif
