#ifndef __USR_TYPE_H__
#define __USR_TYPE_H__

#include "data_types.h"


#endif
