#ifndef __BOARD_CFG_H__
#define __BOARD_CFG_H__

#include <stdint.h>

/* modbus下标对应通道关系 */
typedef enum
{
    MODBUS_INDEX1 = 0,
    MODBUS_INDEX2 = 3,
    MODBUS_INDEX3 = 1,
    MODBUS_INDEX4 = 2,
    MODBUS_MAX = 4,
} sdk_modbus_index_e;

typedef enum
{
    CAN_ID_2 = 0x00,
    CAN_ID_1 = 0x01,
    CAN_ID_MAXCH,
}sdk_can_id_e;

/**
 * @enum os_app_priority_e 
 * @brief Priority values.
 * @warning 供应用层app调用，core禁止调用
 */
typedef enum {
    OS_APP_PRIORITY_1 = 0,             ///< Priority:highest 
    OS_APP_PRIORITY_2,                 ///< Priority:2 
    OS_APP_PRIORITY_3,                 ///< Priority:3 
    OS_APP_PRIORITY_4,                 ///< Priority:4
    OS_APP_PRIORITY_5,                 ///< Priority:5
    OS_APP_PRIORITY_6,                 ///< Priority:6
    OS_APP_PRIORITY_7,                 ///< Priority:7
    OS_APP_PRIORITY_8,                 ///< Priority:8
    OS_APP_PRIORITY_9,                 ///< Priority:9
    OS_APP_PRIORITY_10,                ///< Priority:10
    OS_APP_PRIORITY_11,                ///< Priority:11
    OS_APP_PRIORITY_12,                ///< Priority:lowest
} sdk_os_priority_e;

typedef enum
{
    DI_1 = 0U,
    DI_2,
    DI_3,
    DI_4,
    DI_5,
    DI_6,
    DI_7,
    DI_8,
    DI_9,
    DI_10,
    DI_11,
    DI_12,
    DI_13,
    DI_14,
    DI_15,
    DI_16,
    DI_17,
    DI_18,
    DI_19,
    DI_20,
    DI_MAX,
}di_index_e;

typedef enum
{
    DO_1 = 0U,
    DO_2,
    DO_3,
    DO_4,
    DO_5,
    DO_6,
    DO_7,
    DO_8,
    DO_9,
    DO_10,
    DO_MAX,
}do_index_e;


#include "proj_cfg.h"
#include "peripheral_cfg.h"


#endif
