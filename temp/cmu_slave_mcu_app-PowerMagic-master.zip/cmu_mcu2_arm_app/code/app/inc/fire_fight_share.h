#ifndef __FIRE_FIGHT_SHARE_H__
#define __FIRE_FIGHT_SHARE_H__

#include "sofar_type.h"
#include "data_types.h"

typedef enum {
    FF_ROLE_MASTER,
    FF_ROLE_SLAVER,
    FF_ROLE_MAX,
} ff_role_e;

typedef void (*ff_share_trig_cb)( bool slave_ff_trig );

int32_t fire_fight_share_init( ff_share_trig_cb ff_share_trig_cb );
bool fire_fight_share_set_param( ff_role_e ff_role, uint8_t local_addr, uint8_t share_ff_cnt );
void fire_fight_share_task_loop( void );
ff_role_e fire_fight_share_get_role( void );

#endif
