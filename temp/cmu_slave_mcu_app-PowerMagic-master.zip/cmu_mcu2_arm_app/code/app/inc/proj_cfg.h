#ifndef __PROJ_CFG_H__
#define __PROJ_CFG_H__

#include "sofar_type.h"
// USER DEBUG 搜索

#define WATCHDOG_ENABLE                         1
#define LC_ENABLE                               1
#define DEV_BOX_ENABLE                          1
#define FF_ENABLE                               1
#define FF_SHARE_ENABLE                         1

/* 仿真电池温度，由于调试热管理和消防等依赖电池温度的模块 */
#define SIMIU_BAT_TEMP_ENABLE                   0           // 热管理温度仿真
#define SIMIU_FF_BAT_TEMP_ENABLE                0           // 消防温度仿真

/* 电池簇最大个数 */
#define BAT_CLUSTER_MAX                         6

/*------------------------------- 版本号 ---------------------------------*/
/* APP主版本号 */
#define APP_VERSION_HEADER                      'V'      ///< 当API的兼容性变化时，需递增(0 - 99)

/* APP主版本号.次版本号.阶段版本号 */
#define APP_MAJOR_VERSION                       1        ///< 当API的兼容性变化时，需递增(0 - 99)
#define APP_MINOR_VERSION                       0        ///< 当增加功能时(不影响API 的兼容性)，需递增(0 - 255)
#define APP_STAGE_VERSION                       27       ///< 当做Bug修复时(不影响API 的兼容性)，需递增(0 - 255)

/* 打包使用版本号 */
#define SoftwareVersion		                    "V1.0.27"
#define HardwareVersion			                

#endif
