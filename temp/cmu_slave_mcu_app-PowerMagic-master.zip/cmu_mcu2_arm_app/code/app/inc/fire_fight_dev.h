#ifndef _FIRE_FIGHT_DEV_H_
#define _FIRE_FIGHT_DEV_H_

#include "sofar_type.h"
#include "fire_fight_dat_type.h"

typedef enum {
    MIX_SEN_TYPE_SIFANG,        // 四方光电
    MIX_SEN_TYPE_CPR,           // CPR
    MIX_SEN_TYPE_MAX,           
} mix_sen_type_e;

sf_ret_t fire_fight_dev_init( modbus_idx_t modbus_idx );
void     fire_fight_dev_get_sw_ver( uint8_t *sw_major_ver, uint8_t *sw_sub_ver );
rate_t   fire_fight_dev_get_com_loss_rate( void );
sf_ret_t fire_fight_dev_set_low_pressure_threshold( uint16_t low_pressure_threshold );
sf_ret_t fire_fight_dev_set_pressure_threshold( uint16_t low_pressure_threshold, uint16_t hig_pressure_threshold );
sf_ret_t fire_fight_dev_set_bat_num( uint8_t bat_num );

sf_ret_t fire_fight_dev_set_threshold( ff_threshold_set_t *p_ff_threshold, uint8_t bat_num );
sf_ret_t fire_fight_dev_rd_mb_ff_data( ff_dev_dat_t *p_ff_dev_dat );
void fire_fight_dev_wr_bat_tmp( bat_temper_t *p_bat_temper_list );

sf_ret_t fire_fight_dev_set_mix_sensor_type( mix_sen_type_e mix_sen_type );
mix_sen_type_e fire_fight_dev_get_mix_sensor_type( void );

#endif
