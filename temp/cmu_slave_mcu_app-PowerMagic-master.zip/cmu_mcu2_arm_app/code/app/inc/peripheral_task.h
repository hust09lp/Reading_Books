#ifndef __PERIPHERAL_TASK_H__
#define __PERIPHERAL_TASK_H__

#include <stdint.h>
#include <stddef.h>
#include "app_cfg.h"

typedef enum TASK_ID
{
	TASK_SENSOR,
	TASK_CAN,
	TASK_SCI,
	TASK_WORK,
	TASK_TIMMING,
	TASK_MAX_NUM
}TaskId;



#define MODBUS_BUF_LEN    255     // MODBUS数据缓存的buff大小

#define COM_ERR_MAX     	25        	// 通信失联确认次数


/**
* @brief        线程创建函数
* @param        void
* @return       执行结果
*/
extern int8_t app_thread_creat(void);
extern void sys_send_heartbeat_to_sys_manage(TaskId id);

// extern uint16_t lc_drying_start;
// extern uint16_t lc_drying_timmer;

extern void app_work_init( void );
extern void app_backgroud_dev_init( void );


#endif
