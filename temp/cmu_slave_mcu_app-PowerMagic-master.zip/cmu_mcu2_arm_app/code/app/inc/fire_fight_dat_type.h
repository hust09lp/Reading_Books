#ifndef _FIRE_FIGHT_DAT_TYPE_H_
#define _FIRE_FIGHT_DAT_TYPE_H_

#include "sci_frame.h"

/* 未归类数据 */
typedef struct 
{
} other;

typedef struct 
{
    ff_di_sta_info_u    di_sta;
    ff_do_sta_info_u    do_sta;
    ff_warn1_info_u     warn1;
    ff_warn2_info_u     warn2;
    ff_sen_dat_info_t   sen_dat;
    uint16_t            ff_gas_pressure;    // 瓶组压力，单位：1Kpa                             
} ff_dev_dat_t;

typedef struct 
{
    bool      valid;
    int16_t   max_temper1;                  // 电池簇的最高温度温度值1 ,单位：1℃ //TODO : 改为有符号
    int16_t   max_temper2;                  // 电池簇的最高温度温度值2 ,单位：1℃
    int16_t   max_temper3;                  // 电池簇的最高温度温度值3 ,单位：1℃
    uint16_t  temper1_pack_id;              // 电池簇最高温度1对应pack号
    uint16_t  temper2_pack_id;              // 电池簇最高温度2对应pack号
    uint16_t  temper3_pack_id;              // 电池簇最高温度3对应pack号
} bat_temper_t;

// typedef struct 
// {
//     struct {
//         bool         online;                // 在线状态
//         bat_temper_t tmp;                   // 电池柜 温度数据
//     } bat[ BAT_CLUSTER_MAX ] ;
// } ff_bat_dat_t;

#endif
