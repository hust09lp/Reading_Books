#ifndef __SCI_H__
#define __SCI_H__

#include "stdint.h"


#define SCI_SOFT_VERTION            0x01
#define SCI_HARD_VERTION            0x01
#define SCI_PROTOCOL_VERTION        0x01
#define SCI_SLAVE_ADDR        		0x01
#define SCI_PORT  0


#define APP_FILE_NAME               "1:app.bin"
#define CORE_FILE_NAME              "1:core.bin"
#define UPDATE_INFO_FILE_NAME       "1:info.bin"
#define TMP_FILE_NAME               "1:tmp.bin"

//#define FIRMWARE_UPGRADE_WAIT     	 0x00       // 等待升级状态
//#define FIRMWARE_UPGRADE_START     	 0x01		// 固件准备好，boot可启动升级
#define FIRMWARE_UPGRADE_SUCCESS     0x00   	// 固件升级完成

/**
  * @struct bcu_status_u
  * @brief  故障信息2   液冷故障
  */
typedef union{
    uint16_t word;
    struct{
        uint16_t bcu1_sta:	1;			// BCU1状态
        uint16_t bcu2_sta:	1;			// BCU2状态
        uint16_t bcu3_sta:	1;			// BCU3状态
        uint16_t bcu4_sta:	1;			// BCU4状态
        uint16_t bcu5_sta:	1;			// BCU5状态
        uint16_t bcu6_sta:	1;			// BCU6状态
        uint16_t bcu7_sta:	1;			// BCU7状态
        uint16_t bcu8_sta:	1;			// BCU8状态
        uint16_t bcu9_sta:	1;			// BCU9状态
        uint16_t bcu10_sta:	1;			// BCU10状态
        uint16_t bcu11_sta:	1;			// BCU11状态
        uint16_t bcu12_sta:	1;			// BCU12状态
        uint16_t bcu13_sta:	1;			// BCU13状态
        uint16_t bcu14_sta:	1;			// BCU14状态
        uint16_t bcu15_sta:	1;			// BCU15状态
        uint16_t bcu16_sta:	1;			// BCU16状态
    }bit;
}bcu_status_u;




// 执行成功返回0， 执行失败返回非0
typedef int32_t (*sci_data_swap_t)(uint8_t command_h, uint8_t command_l, uint8_t *in_buf, uint32_t in_len, uint8_t *out_buf, uint32_t *out_len);
typedef void (*sci_data_send_t)(uint8_t *buf, uint32_t len);

typedef struct
{
    uint8_t slave_addr;            // 从机地址
    sci_data_send_t data_send;     // 发送函数
    sci_data_swap_t data_swap;     // 数据交换
} sci_t;

/**
 * @brief               sci 初始化
 * @param sci           sci_t 结构体指针
 * @param slave_addr    从机地址
 * @param data_send     发送回调函数
 * @param data_swap     数据交换
 */
void sci_init(sci_t *sci, uint8_t slave_addr, sci_data_send_t data_send, sci_data_swap_t data_swap);

/**
 * @brief       sci 协议解析
 * @param sci   sci_t 结构体指针
 * @param buf   接收数据缓冲区
 * @param len   接收数据长度
 */
void sci_receive_analysis(sci_t *sci, uint8_t *buf, uint32_t len);

void inboard_sci_init(void);
			  
void sci_send(uint8_t *buf,uint32_t len);

/**
 * @brief  开机检查文件系统
 * @param  [in] 无
 * @return 
 * @note   
 */
void boot_check_file_system( void );

void system_sta_printf(void);

extern sci_t inboard_sci;
extern uint8_t mcu1_sys_sta;
extern uint8_t bcu_ready;
extern uint8_t g_reset_flg;
extern bcu_status_u  bcu_status;

#endif
