#ifndef __FACTORY_TEST_H__
#define __FACTORY_TEST_H__

#include <stdint.h>
#include <stddef.h>
#include "peripheral_task.h"

/* Modbus function codes */
#define MODBUS_FC_READ_HOLDING_REGISTERS 0x03

// 485测试通道
#define MODBUS_TEST_CH1 0
#define MODBUS_TEST_CH2 1
#define MODBUS_TEST_CH3 2
#define MODBUS_TEST_CH4 3
#define MODBUS_TEST_CH_MAX 4

// CAN 测试通道
#define CAN_TEST_CH1 0
#define CAN_TEST_CH2 1
#define CAN_TEST_CH_MAX 2

// CAN初始化参数
#define CAN_BAUD 1000UL * 500
#define CAN_MODE SDK_CAN_MODE_NORMAL

#define CAN1_ID 0X03
#define CAN1_ADDR 0X03

#define CAN2_ID 0X03
#define CAN2_ADDR 0X02

#define CAN_DATA_FRAME 0X01
#define CAN_REQ_FRAME 0X02
#define CAN_LISTEN_FRAME 0X03

#define ON 1
#define OFF 0

#define SUCCESS 1
#define FAIL 0
#define RET_ERR -1

#define FACTORY_RET_SUCCESS 1
#define FACTORY_RET_ERR -1

/**
 * @struct can_frame_id_u
 * @brief  CAN ID定义
 */
// can frame id
typedef union
{
    uint32_t id_val;
    struct
    {
        uint32_t src_addr : 5;   // source address
        uint32_t src_type : 3;   // source device type
        uint32_t dst_addr : 5;   // destination address
        uint32_t dst_type : 3;   // destination device type
        uint32_t fun_code : 6;   // < CAN Frame function code
        uint32_t res : 1;        // < CAN Frame function code
        uint32_t cont : 1;       // < continue
        uint32_t frame_type : 2; // < CAN Frame fun_code priority
        uint32_t prio : 3;       // < Reserved.
    } bit;
} new_can_frame_id_u;

// 工厂测试类型
typedef enum
{
    RS485_TEST = 1,
    CAN_TEST = 2,
    DI_TEST = 3,
    DO_TEST = 4,
    FF_CTRL_TEST = 5,
    IO_EXT_TEST = 6,
    FLASH_TEST = 7,
    EEPROM_TEST = 8,
	WDT_TEST = 9,
} factory_test_type_e;

// 看门狗测试项
typedef enum
{
    WDT_PREPARE = 0,
    WDT_FEED_DISABLE,
    WDT_CHECK,
} wdt_test_item_e;

extern uint8_t  g_wdt_feed_disable_flag;

/* 工厂模式 */
typedef enum
{
    FACTORY_MODE_NONE,     //< 非工厂模式
    FACTORY_MODE_PCB_TEST, //< 工厂模式（单板）
    FACTORY_MODE_DEV_TEST, //< 工厂模式（辅电箱）
} factory_mode_e;


extern uint8_t g_factory_test;
extern uint16_t factory_test(uint16_t test_type, uint16_t test_port);
extern void factory_rs485_rsp(void);
factory_mode_e factory_test_task_loop(void);

#endif
