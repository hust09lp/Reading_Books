#ifndef __FACTORY_DEV_TEST_H__
#define __FACTORY_DEV_TEST_H__

#include "sofar_type.h"

typedef enum {
    FF_TEST_MIX_SEN_CONN  = 1,      //< 复合传感器通讯
    FF_TEST_IO_EXT_CONN   = 2,      //< IO拓展板通讯
    FF_TEST_DO_FAULT      = 3,      //< DO 对外故障
    FF_TEST_DO_WARN1      = 4,      //< DO 一级告警
    FF_TEST_DO_WARN2      = 5,      //< DO 二级告警
    FF_TEST_DI_CMU_START  = 6,      //< DI CMU 启动
    FF_TEST_DI_TH_SIGNAL  = 7,      //< DI 信号反馈
    FF_TEST_PRESS_VAL     = 8,      //< 气瓶气压
} ff_test_e;

int32_t factory_dev_test_init( void );

/**
 * @brief		辅电箱测试 485测试接口
 * @param		[in] test_port 要测试的485通道：通道1-4
 * @return		0：成功  小于0：失败
 * @warning		无
 */
int32_t factory_dev_rs485_test(uint16_t test_port);

/**
 * @brief		工厂 消防控制器测试
 * @param		[in] ff_test_type 消防测试类型
 * @return		0：成功  小于0：失败
 * @warning		无
 */
int32_t factory_dev_ff_test( ff_test_e ff_test_type );

/**
 * @brief		辅电箱测试 IO拓展板 DI DO 测试 
 * @param		[in] io_port  IO端口
 * @return		0：成功  小于0：失败
 * @warning		无
 */
int32_t factory_dev_io_extern_di_do_test( uint8_t io_port );

/**
 * @brief		辅电箱测试 IO DI DO 测试 
 * @param		[in] test_type 测试类型 3-DI测试   4-DO测试
 * @return		0：成功  小于0：失败
 * @warning		无
 */
int32_t factory_dev_di_do_test(uint16_t test_type, uint16_t test_port);



#endif
