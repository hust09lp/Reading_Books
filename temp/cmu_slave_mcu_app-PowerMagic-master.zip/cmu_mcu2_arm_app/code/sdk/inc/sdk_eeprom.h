#ifndef __SDK_EEPROM_H__
#define __SDK_EEPROM_H__

#include "data_types.h"

/**
 * @brief       eeprom 写数据
 * @param       dev_no
 * @param       offset    要写的数据起始地址
 * @param       len       数据长度
 * @param       p_buf     待写入数据指针
 * @return      执行结果
 * @retval      SF_OK  写入成功
 * @note        eeprom总容量 32KB = 64B * 512page
 */
int32_t sdk_eeprom_write(uint32_t offset, uint32_t len, uint8_t *p_buf);

/**
 * @brief       eeprom 读数据
 * @param       offset    要读的数据起始地址
 * @param       len       数据长度
 * @param       p_buf     待读出数据指针
 * @return      执行结果
 * @retval      >=0      读出成功
 * @retval      < 0      读取失败
 * @note        eeprom总容量 32KB = 64B * 512page
 */
int32_t sdk_eeprom_read(uint32_t offset, uint32_t len, uint8_t *p_buf);


#endif
