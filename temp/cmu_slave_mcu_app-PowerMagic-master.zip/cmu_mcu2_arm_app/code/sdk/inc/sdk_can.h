/**
 * @file     	sdk_can.h
 * @brief    	can功能定义
 * @details     主要包含了关于CAN功能的相关函数
 * @author   	renwj
 * @note     	无
 * @version  	V1.0.1 初始版本
 * @date     	2022/12/30
 * @copyright   Copyright(c) 2022 by SofarSolar, All Rights Reserved. 
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author    <th>Description
 * <tr><td>2022/2/30   <td>1.0.1    <td>renwj     <td>创建初始版本
 * <tr><td>2023/3/6    <td>1.0.2    <td>renwj     <td>去掉中断set和free接口，can帧结构定义用宏来区分rtos和linux
 * </table>
 *
 **********************************************************************************
 * @par 示例:
 * @code
 * 暂无
 * @endcode
 */
 
#ifndef __SDK_CAN_H__
#define __SDK_CAN_H__

#include "data_types.h"


#define SDK_CAN_STDID                    0
#define SDK_CAN_EXTID                    1
#define SDK_CAN_DTR                      0
#define SDK_CAN_RTR                      1

#define SDK_CAN_MODE_NORMAL         0   ///< CAN 普通模式
#define SDK_CAN_MODE_LISEN          1   ///< CAN 监听模式
#define SDK_CAN_MODE_LOOPBACK       2   ///< CAN LOOP BACK模式
#define SDK_CAN_MODE_LOOPBACK_LISEN 3   ///< CAN LOOP BACK 监听模式

#define SDK_CAN_BAUD_1M             1000UL * 1000   ///< 1 MBit/sec
//#define SDK_CAN_BAUD_800K           1000UL * 800    ///< 800 kBit/sec
#define SDK_CAN_BAUD_500K           1000UL * 500    ///< 500 kBit/sec
#define SDK_CAN_BAUD_250K           1000UL * 250    ///< 250 kBit/sec
#define SDK_CAN_BAUD_125K           1000UL * 125    ///< 125 kBit/sec
#define SDK_CAN_BAUD_100K           1000UL * 100    ///< 100 kBit/sec
#define SDK_CAN_BAUD_50K            1000UL * 50     ///< 50 kBit/sec
#define SDK_CAN_BAUD_20K            1000UL * 20     ///< 20 kBit/sec
//#define SDK_CAN_BAUD_10K            1000UL * 10     ///< 10 kBit/sec


#define  CAN_ID_MAX                 3  ///< CAN虚拟通道序号最大值

/**
* @struct sdk_can_frame_t
 * @brief CAN消息
 */
#ifdef RTOS_SYS                         // RTOS系统 CAN帧数据结构
typedef struct
{
    uint32_t id  : 29;                  ///< CAN ID, 标志格式 11 位，扩展格式 29 位
    uint32_t ide : 1;                   ///< 扩展帧标识位 标准帧or扩展帧
    uint32_t rtr : 1;                   ///< 远程帧标识位 数据帧or遥控帧
    uint32_t rsv : 1;                   ///< 保留位
    uint32_t len : 8;                   ///< 消息长度
    uint32_t priv : 8;                  ///< 报文发送优先级
    int32_t  hdr : 8;                   ///< 硬件过滤表号
    uint32_t reserved : 8;              ///< 保留
    uint8_t  data[8];                   ///< 数据段
}sdk_can_frame_t;
#else                                   // LINUX系统(非RTOS系统) CAN帧数据结构
typedef struct
{
	uint32_t id;                        ///< CAN id格式linux平台自定义
    uint32_t len : 8;                   ///< 消息长度
    uint32_t priv : 8;                  ///< 报文发送优先级
    int32_t  hdr : 8;                   ///< 硬件过滤表号
    uint32_t reserved : 8;              ///< 保留
    uint8_t  data[8];                   ///< 数据段
}sdk_can_frame_t;
#endif


/**
* @struct sdk_can_cfg_t
 * @brief 配置CAN各种属性
 */
typedef struct
{
    uint32_t baud;      ///< 波特率    
    uint32_t mode;      ///< 模式
}sdk_can_cfg_t;


/**
* @brief		CAN初始化
* @return		执行结果
* @retval		(0) 成功
* @retval		(<0) 失败 
*/
int32_t sdk_can_init(void);


/**
 * @brief       打开CAN功能 
 * @param       [in] port 虚拟CAN端口号
 * -# CAN_ID_1 - 0x00
 * -# CAN_ID_2 - 0x01
 * @return      执行结果
 * @retval      0 成功
 * @retval      <0 失败
 */
int32_t sdk_can_open(uint32_t port);


/**
 * @brief        关闭CAN功能 
 * @param        [in] port 虚拟CAN端口号
 * -# CAN_ID_1 - 0x00
 * -# CAN_ID_2 - 0x01
 * @return      执行结果
 * @retval      0 成功
 * @retval      <0 失败 
 */
int32_t sdk_can_close(uint32_t port);


/**
 * @brief        can参数配置
 * @param        [in] port 虚拟CAN端口号
 * -# CAN_ID_1 - 0x00
 * -# CAN_ID_2 - 0x01
 * @param        [in] *p_cfg can参数配置结构体指针
 * @return       执行结果
 * @retval       0 成功
 * @retval       <0 失败 
 * @warning      sdk_can_open后调用
 */
int32_t sdk_can_setup(uint32_t port, sdk_can_cfg_t * p_cfg);


/**
 * @brief       CAN发数据 加锁
 * @param       [in] port 虚拟CAN端口号
 * -# CAN_ID_1 - 0x00
 * -# CAN_ID_2 - 0x01
 * @param       [in] *p_frame CAN帧缓冲区指针
 * @param       [in] frame_size 帧数量，如:(单帧,frame_size = 1)
 * @return      执行结果
 * @retval      >=0 实际发送can帧数量，如:(实际发送1帧,返回值=1)
 * @retval      <0 失败
 * @note        执行sdk_can_open后执行才有效
 */
int32_t sdk_can_write(uint32_t port, sdk_can_frame_t *p_frame, uint32_t frame_size);


/**
 * @brief       CAN收数据 
 * @param       [in] port 虚拟CAN端口号
 * -# CAN_ID_1 - 0x00
 * -# CAN_ID_2 - 0x01
 * @param       [in] *p_frame CAN帧缓冲区指针
 * @param       [in] frame_size 帧数量，如:(单帧,frame_size = 1)
 * @param       [in] timeout_ms 超时时间
 * -# <0  一直等待，直到接收到数据为止（阻塞）
 * -# 0   不超时等待，直接返回结果
 * -# >0  接收超时等待时间：ms（阻塞）
 * @return     执行结果
 * @retval     >=0 实际接收can帧数量(实际接收1帧,返回值=1)
 * @retval     <0 失败    
 * @note       执行sdk_can_open后执行才有效
 */
int32_t sdk_can_read(uint32_t port, sdk_can_frame_t *p_frame, uint32_t frame_size, int32_t timeout_ms);


#endif

