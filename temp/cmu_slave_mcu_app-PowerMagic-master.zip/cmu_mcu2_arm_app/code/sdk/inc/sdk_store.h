/**
 * @file         sdk_store.h
 * @brief        获取指定存储设备的路径接口
 * @author       yanwei
 * @version      V0.0.1
 * @date         2023/03/06
 * @copyright    Copyright (c) 2023 by SofarSolar, All Rights Reserved.
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author    <th>Description
 * <tr><td>2023/03/06  <td>0.0.1    <td>yanwei     <td>创建初始版本
 * </table>
 *
 **********************************************************************************
 * @par 示例:
 * @code
 * 暂无
 * @endcode
 */
 
#ifndef __SDK_STORE_H__
#define __SDK_STORE_H__

#include "data_types.h"


typedef enum
{
   USB_FLASH = 0,    //U盘
   TF_CARD,          //TF卡
 }store_device_type_e;


typedef enum  
{
    U_DISK_CONNECT = 0,   ///< U盘连接
    U_DISK_DISCONNECT,    ///< U盘断开连接
    USB_COM_CONNECT,      ///< 采集棒连接
    USB_COM_DISCONNECT,   ///< 采集棒断开
}usb_evnet_e;

/**
 * @brief    回调函数的定义
 * @param    [out] event   	事件类型 usb_evnet_e
 * @param    [out] p_path 	返回设备所挂载的路径，连接类事件有效
 * @param    [out] p_len    长度，设备路经长度
 */
typedef int32_t (*f_usb_event_cb)(usb_evnet_e event,int8_t *p_path, uint32_t *p_len);

/**
 * @brief    usb事件回调
 * @param    [in] event     usb事件类型
 * @param    [in] event_cb  事件回调函数指针
 * @return   执行结果
 * @retval   0  成功
 * @retval   -1 失败 
 */
int32_t sdk_usb_evt_regist(f_usb_event_cb event_cb);


/**
 * @brief    获取指定存储设备的路径
 * @param    type   存储设备
 * @param    p_path 路径
 * @param    len    长度
 * @return   int32_t 
 * @retval	 >= 0 成功
 * @retval	 <0失败 不同值对应不 同的错误代码。
 */
int32_t sdk_store_path_get(store_device_type_e type, int8_t *p_path, uint32_t len);


/**
 * @brief    获取指定存储设备是否存在
 * @param    type 存储设备
 * @return   int32_t 
 * @retval	 >= 0 存在
 * @retval	 <0 不存在
 */
int32_t sdk_store_is_exist(store_device_type_e type);


#endif
