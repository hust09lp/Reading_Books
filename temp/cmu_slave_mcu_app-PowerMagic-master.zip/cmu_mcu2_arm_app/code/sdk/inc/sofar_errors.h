/**
 * @file         sofar_errors.h
 * @brief        错误类型定义
 * @details      主要定义了通用的错误类型，各层都可以调用
 * @author       SOFAR
 * @date         2023/02/23
 * @version      V0.0.1
 * @copyright    Copyright(c) 2022 by SofarSolar, All Rights Reserved. 
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author    <th>Description
 * <tr><td>2023/02/23  <td>0.0.1    <td>Chace     <td>创建初始版本
 * </table>
 *
 **********************************************************************************
 */

#ifndef __SOFAR_ERRORS_H__
#define __SOFAR_ERRORS_H__


#define SF_OK               (0)     ///< No errors 
#define SF_ERR_PARA         (-1)    ///< Illegal function parameter  函数参数错误/非法  
#define SF_ERR_NO_OBJECT    (-2)    ///< Object not exist            对象不存在，如设备地址/参数区/文件路径/文件不存在
#define SF_ERR_NO_READY     (-3)    ///< Not ready                   参数未挂载/文件未打开
#define SF_ERR_OPEN         (-4)    ///< open error                  打开失败
#define SF_ERR_CLOSE        (-5)    ///< close error                 关闭失败
#define SF_ERR_SEEK         (-6)    ///< File fseek error            定位指针错误
#define SF_ERR_RD           (-7)    ///< Read error                  读错误
#define SF_ERR_WR           (-8)    ///< Write error                 写错误
#define SF_ERR_BUSY         (-9)    ///< Device busy                 设备忙
#define SF_ERR_FNOSUPP      (-10)   ///< Function not support        功能不支持
#define SF_ERR_TMOUTERR     (-11)   ///< Timeout error               超时失败

#define SF_ERR_NDEF         (-99)   ///< no define                   缺省的，未定义的错误    


#endif  /* __SOFAR_ERRORS_H__ */

