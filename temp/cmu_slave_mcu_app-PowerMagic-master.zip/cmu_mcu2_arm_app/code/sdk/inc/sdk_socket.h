/**
 * @file         sdk_socket.h
 * @brief        Wi-Fi网络socket接口
 * @author       chenzq
 * @version      V0.0.3
 * @date         2023/03/07
 * @copyright    Copyright (c) 2023 by SofarSolar, All Rights Reserved.
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author     <th>Description
 * <tr><td>2023/02/16  <td>0.0.1    <td>chenzq     <td>创建初始版本
 * <tr><td>2023/03/06  <td>0.0.2    <td>chenzq     <td>参照linux socket接口更新参数，并提供参数的参考取值
 * <tr><td>2023/03/07  <td>0.0.3    <td>chenzq     <td>函数返回值使用@retval说明
 * </table>
 *
 **********************************************************************************
 * @par 示例:
 * @code
 * 暂无
 * @endcode
 */

#ifndef __SDK_SOCKET_H__
#define __SDK_SOCKET_H__

#include "data_types.h"

typedef struct 
{
  uint8_t   sa_len;
  uint8_t   sa_family;
  int8_t    sa_data[14];
}socket_addr_t;

typedef struct
{
  uint8_t   sin_len;
  uint8_t   sin_family;
  uint16_t  sin_port;
  uint32_t  sin_addr;
  int8_t    sin_zero[8];
}socket_addr_in_t;

typedef enum
{ 
  SDK_AF_LOCAL = 1,     // UNIX  
  SDK_AF_INET = 2,      // IPv4
  SDK_AF_INET6 = 10,    // IPv6
  SDK_AF_CAN = 29,      // CAN套接口
  SDK_AF_AT = 45,       // AT套接字
}af_inet_type_e;

typedef enum
{
  SDK_SOCK_STREAM = 1,  // 流套接字
  SDK_SOCK_DGRAM = 2,   // 数据报套接字
  SDK_SOCK_RAM = 3,     // 原始套接字
}sock_type_e;

typedef enum
{
  SDK_IPPROTO_IP = 0,
  SDK_IPPROTO_TCMP = 1,
  SDK_IPPROTO_TCP = 6,
  SDK_IPPROTO_UDP = 17,
  SDK_IPPROTO_IPV6 = 41,
  SDK_IPPROTO_ICMPV6 = 58,
  SDK_IPPROTO_UDPLITE = 136,
  SDK_IPPROTO_RAM = 255,
}ipproto_type_e;

typedef enum
{
  SDK_LEVEL_SOL_SOCKET = 0xfff,   // 通用套接字选项
  SDK_LEVEL_IPPROTO_IP = 0,       // IP选项
  SDK_LEVEL_IPPROTO_TCP = 6,      // TCP选项
}sockopt_type_e;

typedef enum
{
  SDK_FIONBIO = 0,                // 允许或禁止套接口的非阻塞模式
  SDK_FIONREAD,                   // 确定套接口自动读取的数据量
  SDK_SIOCATMARK,                 // 确定是否所有的带外数据都已被读入
}sock_ioctl_cmd_e;

typedef enum
{
  SDK_SO_DEBUG       = 0x0001,    // 打开或关闭调试信息
  SDK_SO_ACCEPTCONN  = 0x0002,    // 监听套接口
  SDK_SO_REUSEADDR   = 0x0004,    // 打开或关闭地址复用功能
  SDK_SO_KEEPALIVE   = 0x0008,    // 套接字连接启用保持连接数据包
  SDK_SO_DONTROUTE   = 0x0010,    // 打开或关闭路由查找功能
  SDK_SO_BROADCAST   = 0x0020,    // 允许或禁止发送广播数据
  SDK_SO_USELOOPBACK = 0x0040,    // 仅用于路由套接字
  SDK_SO_LINGER      = 0x0080,    // close或 shutdown将等到所有套接字里排队的消息成功发送或到达延迟时间后才会返回
  SDK_SO_OOBINLINE   = 0x0100,    // 套接字连接启用保持连接数据包
  SDK_SO_REUSEPORT   = 0x0200,    // 允许重用本地端口
  SDK_SO_SNDBUF      = 0x1001,    // 设置发送缓冲区的大小
  SDK_SO_RCVBUF      = 0x1002,    // 设置接收缓冲区的大小
  SDK_SO_SNDLOWAT    = 0x1003,    // 设置发送数据前的缓冲区内的最小字节数  
  SDK_SO_RCVLOWAT    = 0x1004,    // 设置接收数据前的缓冲区内的最小字节数
  SDK_SO_SNDTIMEO    = 0x1005,    // 设置发送超时时间  
  SDK_SO_RCVTIMEO    = 0x1006,    // 设置接收超时时间 
  SDK_SO_ERROR       = 0x1007,    // 获取错误状态并清除  
  SDK_SO_TYPE        = 0x1008,    // 套接口类型  
  SDK_SO_CONTIMEO    = 0x1009,    // 连接超时时间  
  SDK_SO_NO_CHECK    = 0x100a,    // 打开或关闭校验和 
}sock_opt_name_e;

/**
 * @brief    创建套接字
 * @param    [in] domain    协议族
 * -# 取值参考枚举类型 af_inet_type_e
 * @param    [in] type      协议类型
 * -# 取值参考枚举类型 sock_type_e
 * @param    [in] protocol  运输层协议,type为SDK_SOCK_RAM时，需要设置此值说明协议类型，其他类型设置0即可
 * -# 取值参考枚举类型 ipproto_type_e
 * @return   执行结果
 * @retval   返回套接字描述符(ID)  成功
 * @retval   -1 失败 
 */
int32_t sdk_socket_create(int32_t domain, int32_t type, int32_t protocol);

/**
 * @brief    绑定套接字
 * @param    [in] socket_id 套接字描述符
 * @param    [in] p_name    指向sockaddr结构体的指针，代表要绑定的地址
 * @param    [in] name_len  结构体的长度
 * @return   执行结果
 * @retval   0  成功
 * @retval   -1 失败 
 */
int32_t sdk_socket_bind (int32_t socket_id, const socket_addr_t *p_name, uint32_t name_len);

/**
 * @brief    socket服务器监听指定套接字连接
 * @param    [in] socket_id 套接字描述符
 * @param    [in] backlog   一次能够等待的最大连接数目
 * @return   执行结果
 * @retval   0  成功
 * @retval   -1 失败 
 */
int32_t sdk_socket_listen (int32_t socket_id, int32_t backlog);

/**
 * @brief    接收连接
 * @param    [in] socket_id      套接字描述符
 * @param    [out] p_addr        客户端设备地址信息
 * @param    [out] p_addr_len    客户端设备地址结构体的长度
 * @return   执行结果
 * @retval   实际读取的字节数  成功
 * @retval   -1 失败 
 */
int32_t sdk_socket_accept (int32_t socket_id, socket_addr_t *p_addr, uint32_t *p_addr_len);

/**
 * @brief    建立与指定socket的连接
 * @param    [in] socket_id 套接字描述符
 * @param    [in] p_name    服务器地址信息
 * @param    [in] name_len  服务器地址结构体的长度
 * @return   执行结果
 * @retval   0  成功
 * @retval   -1 失败 
 */
int32_t sdk_socket_connect(int32_t socket_id, const socket_addr_t *p_name, uint32_t name_len);

/**
 * @brief    关闭套接字
 * @param    [in] socket_id 套接字描述符
 * @return   int32_t 执行结果
 * @retval   0  成功
 * @retval   -1 失败 
 */
int32_t sdk_socket_close(int32_t socket_id);

/**
 * @brief    数据发送
 * @param    [in] socket_id     套接字描述符
 * @param    [in] p_data_ptr    要发送的数据指针
 * @param    [in] size          发送的数据长度
 * @param    [in] flags         标志，一般为0
 * @return   执行结果
 * @retval   发送的数据的长度  成功
 * @retval   -1 失败 
 */
int32_t sdk_socket_send (int32_t socket_id, const void *p_data_ptr, uint32_t size, int32_t flags);

/**
 * @brief    数据接收
 * @param    [in] socket_id 套接字描述符
 * @param    [out] p_mem    接收的数据指针
 * @param    [in] len       接收的数据长度
 * @param    [in] flags     标志，一般为0
 * @return   执行结果
 * @retval   接收的数据的长度  成功
 * @retval   -1 失败 
 */
int32_t sdk_socket_recv (int32_t socket_id, void *p_mem, uint32_t len, int32_t flags);

/**
 * @brief    UDP 数据发送
 * @param    [in] socket_id 套接字描述符
 * @param    [in] p_dataptr 发送的数据指针
 * @param    [in] size      发送的数据长度
 * @param    [in] flags     标志，一般为0
 * @param    [in] p_to      目标地址结构体指针
 * @param    [in] tolen     目标地址结构体长度
 * @return   执行结果
 * @retval   发送的数据的长度  成功
 * @retval   -1 失败 
 */
int32_t sdk_socket_sendto (int32_t socket_id, const void *p_dataptr, uint32_t size, int32_t flags, const socket_addr_t *p_to, uint32_t tolen);

/**
 * @brief    UDP 数据接收
 * @param    [in] socket_id 套接字描述符
 * @param    [out] p_mem    接收的数据指针
 * @param    [in] len       接收的数据长度
 * @param    [in] flags     标志，一般为0
 * @param    [out] p_from   接收地址结构体指针
 * @param    [in] p_fromlen 接收地址结构体长度
 * @return   执行结果
 * @retval   接收数据的长度  成功
 * @retval   -1 失败 
 */
int32_t sdk_socket_recvfrom (int32_t socket_id, void *p_mem, uint32_t len, int32_t flags, socket_addr_t *p_from, uint32_t *p_fromlen);

/**
 * @brief    设置套接字选项
 * @param    [in] socket_id 套接字描述符
 * @param    [in] level     协议栈配置选项
 * -# 取值参考枚举类型 sockopt_type_e
 * @param    [in] opt_name  需要设置的选项名
 * -# 取值参考枚举类型 sock_opt_name_e
 * @param    [in] p_opt_val 设置选项值的缓冲区地址
 * @param    [in] opt_len   设置选项值的缓冲区长度
 * @return   执行结果
 * @retval   0  成功
 * @retval   -1 失败 
 */
int32_t sdk_socket_opt_set(int32_t socket_id, int32_t level, int32_t opt_name, const void *p_opt_val, uint32_t opt_len);

/**
 * @brief    获取套接字选项
 * @param    [in] socket_id  套接字描述符
 * @param    [in] level      协议栈配置选项
 * -# 取值参考枚举类型 sockopt_type_e
 * @param    [in] opt_name   协议栈配置选项
 * -# 取值参考枚举类型 sock_opt_name_e
 * @param    [out] p_opt_val 协议栈配置选项
 * @param    [in] p_opt_len  协议栈配置选项
 * @return   执行结果
 * @retval   0  成功
 * @retval   -1 失败 
 */
int32_t sdk_socket_opt_get(int32_t socket_id, int32_t level, int32_t opt_name, void *p_opt_val, uint32_t *p_opt_len);

/**
 * @brief    配置套接字参数
 * @param    [in] socket_id 套接字描述符
 * @param    [in] cmd       套接字操作命令
 * -# 取值参考枚举类型 sock_ioctl_cmd_e
 * @param    [in] p_arg     操作命令所带参数
 * @return   执行结果
 * @retval   0  成功
 * @retval   -1 失败 
 */
int32_t sdk_socket_ioctl(int32_t socket_id, long cmd, void* p_arg);

/**
 * @brief    把一个16位数高低位调换
 * @param    [in] data     一个16位数值
 * @return   uint16_t 高低位调换的16位数值
 */
uint16_t sdk_htons(uint16_t data);

/**
 * @brief    将点分十进制的IPv4地址转换成网络字节序列的长整型
 * @param    [in] p_cp     点分十进制的IPv4地址指针
 * @return   uint32_t 网络字节序列的长整型数据
 */
uint32_t sdk_inet_addr(const int8_t* p_cp);


#endif  /* #define __SDK_SOCKET_H__  */
