/**
 * @file         sdk_led.h
 * @brief        LED功能定义
 * @details      主要包含了关于LED灯功能的相关函数
 * @author       SOFAR
 * @date         2023/03/06
 * @version      V0.0.1
 * @copyright    Copyright(c) 2023 by SofarSolar, All Rights Reserved. 
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author    <th>Description
 * <tr><td>2023/03/06  <td>0.0.1    <td>Chace     <td>创建初始版本
 * <tr><td>2023/03/07  <td>0.0.2    <td>renwj     <td>入参id统一修改为led_id
 * </table>
 *
 **********************************************************************************
 * @par 示例:
 * @code
 * 暂无
 * @endcode
 */

#ifndef __SDK_LED_H__
#define __SDK_LED_H__

#include "data_types.h"


#define LED_ID_MAX                            10            ///< LED编号最大值


/**
 * @brief     led闪烁
 * @param[in] led_id led编号
 * -# led编号参数不大于LED_ID_MAX(详细映射关系参看平台部提供接口映射表)
 * @param[in] period led闪烁周期(ms)
 * -# 最小闪烁周期为一个任务周期或扫描周期(10ms), 此参数需是任务及扫描周期的倍数
 * @param[in] duty led闪烁占空比(%)
 * -# 取值范围为 0 - 100(%)
 * @param[in] times led闪烁次数
 * -# -1  持续闪烁
 * -# >=0 闪烁次数
 * @return    执行结果
 * @retval    0  成功
 * @retval    <0 失败原因
 */
int32_t sdk_led_flash(uint32_t led_id, uint32_t period, uint32_t duty, int32_t times);
 
/**
 * @brief     led灯亮
 * @param[in] led_id led编号
 * -# led编号参数不大于LED_ID_MAX(详细映射关系参看平台部提供接口映射表)
 * @return    执行结果
 * @retval    0  成功
 * @retval    <0 失败原因
 */
int32_t sdk_led_on(uint32_t led_id);

/**
 * @brief     led灯灭
 * @param[in] led_id LED编号
 * -# led编号参数不大于LED_ID_MAX(详细映射关系参看平台部提供接口映射表)
 * @return    执行结果
 * @retval    0  成功
 * @retval    <0 失败原因
 */
int32_t sdk_led_off(uint32_t led_id);


#endif  /* __SDK_LED_H__ */
