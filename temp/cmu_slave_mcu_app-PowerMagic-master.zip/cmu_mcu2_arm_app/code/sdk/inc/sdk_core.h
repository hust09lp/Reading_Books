
#ifndef __SDK_CORE_H__
#define __SDK_CORE_H__

#include "sdk.h"

#include "data_types.h"

extern core_sdk_interface_t *gp_core_sdk_api;


#define sdk_version_get                         (gp_core_sdk_api->core_sdk_version_get)
#define sdk_delay_us                            (gp_core_sdk_api->core_sdk_delay_us)
#define sdk_delay_ms                            (gp_core_sdk_api->core_sdk_delay_ms)
#define sdk_os_delay                            (gp_core_sdk_api->core_sdk_os_delay)
#define sdk_os_tick_from_millisecond            (gp_core_sdk_api->core_sdk_os_tick_from_millisecond)
#define sdk_os_thread_new                       (gp_core_sdk_api->core_sdk_os_thread_new)
#define sdk_os_sem_new                          (gp_core_sdk_api->core_sdk_os_sem_new)
#define sdk_os_sem_acquire                      (gp_core_sdk_api->core_sdk_os_sem_acquire)
#define sdk_os_sem_release                      (gp_core_sdk_api->core_sdk_os_sem_release)
#define sdk_os_sem_delete                       (gp_core_sdk_api->core_sdk_os_sem_delete)
#define sdk_os_mutex_new                        (gp_core_sdk_api->core_sdk_os_mutex_new)
#define sdk_os_mutex_acquire                    (gp_core_sdk_api->core_sdk_os_mutex_acquire)
#define sdk_os_mutex_release                    (gp_core_sdk_api->core_sdk_os_mutex_release)
#define sdk_os_mutex_delete                     (gp_core_sdk_api->core_sdk_os_mutex_delete)
#define sdk_log_init                            (gp_core_sdk_api->core_sdk_log_init)
#define sdk_log_set_level                       (gp_core_sdk_api->core_sdk_log_set_level)
#define sdk_log_get_level                       (gp_core_sdk_api->core_sdk_log_get_level)
#define sdk_log_printf                          (gp_core_sdk_api->core_sdk_log_printf)
#define sdk_log_hexdump                         (gp_core_sdk_api->core_sdk_log_hexdump)
#define sdk_log_finish                          (gp_core_sdk_api->core_sdk_log_finish)
#define sdk_wdt_enable                          (gp_core_sdk_api->core_sdk_wdt_enable)
#define sdk_wdt_feed                            (gp_core_sdk_api->core_sdk_wdt_feed)
#define sdk_sys_reset                           (gp_core_sdk_api->core_sdk_sys_reset)
#define sdk_tick_get                            (gp_core_sdk_api->core_sdk_tick_get)
#define sdk_is_tick_over                        (gp_core_sdk_api->core_sdk_is_tick_over)
#define sdk_rtc_set                             (gp_core_sdk_api->core_sdk_rtc_set)
#define sdk_rtc_get                             (gp_core_sdk_api->core_sdk_rtc_get)
#define sdk_is_time_over                        (gp_core_sdk_api->core_sdk_is_time_over)
#define sdk_led_flash                           (gp_core_sdk_api->core_sdk_led_flash)
#define sdk_led_on                              (gp_core_sdk_api->core_sdk_led_on)
#define sdk_led_off                             (gp_core_sdk_api->core_sdk_led_off)
#define sdk_dido_write                          (gp_core_sdk_api->core_sdk_dido_write)
#define sdk_dido_read                           (gp_core_sdk_api->core_sdk_dido_read)
#define sdk_dido_set_irq                        (gp_core_sdk_api->core_sdk_dido_set_irq)
#define sdk_dido_free_irq                       (gp_core_sdk_api->core_sdk_dido_free_irq)
#define sdk_can_open                            (gp_core_sdk_api->core_sdk_can_open)
#define sdk_can_close                           (gp_core_sdk_api->core_sdk_can_close)
#define sdk_can_setup                           (gp_core_sdk_api->core_sdk_can_setup)
#define sdk_can_write                           (gp_core_sdk_api->core_sdk_can_write)
#define sdk_can_read                            (gp_core_sdk_api->core_sdk_can_read)
#define sdk_uart_open                           (gp_core_sdk_api->core_sdk_uart_open)
#define sdk_uart_close                          (gp_core_sdk_api->core_sdk_uart_close)
#define sdk_uart_setup                          (gp_core_sdk_api->core_sdk_uart_setup)
#define sdk_uart_write                          (gp_core_sdk_api->core_sdk_uart_write)
#define sdk_uart_read                           (gp_core_sdk_api->core_sdk_uart_read)
#define sdk_modbus_rtu_init                     (gp_core_sdk_api->core_sdk_modbus_rtu_init)
#define sdk_modbus_slave_set                    (gp_core_sdk_api->core_sdk_modbus_slave_set)
#define sdk_modbus_baud_set                     (gp_core_sdk_api->core_sdk_modbus_baud_set)
#define sdk_modbus_response_timeout_set         (gp_core_sdk_api->core_sdk_modbus_response_timeout_set)
#define sdk_modbus_connect                      (gp_core_sdk_api->core_sdk_modbus_connect)
#define sdk_modbus_close                        (gp_core_sdk_api->core_sdk_modbus_close)
#define sdk_modbus_free                         (gp_core_sdk_api->core_sdk_modbus_free)
#define sdk_modbus_receive                      (gp_core_sdk_api->core_sdk_modbus_receive)
#define sdk_modbus_reply                        (gp_core_sdk_api->core_sdk_modbus_reply)
#define sdk_modbus_registers_read               (gp_core_sdk_api->core_sdk_modbus_registers_read)
#define sdk_modbus_register_write               (gp_core_sdk_api->core_sdk_modbus_register_write)
#define sdk_modbus_registers_write              (gp_core_sdk_api->core_sdk_modbus_registers_write)
#define sdk_modbus_flush              			(gp_core_sdk_api->core_sdk_modbus_flush)
#define sdk_modbus_coils_read					(gp_core_sdk_api->core_sdk_modbus_coils_read)
#define sdk_modbus_coil_write					(gp_core_sdk_api->core_sdk_modbus_coil_write)
#define sdk_modbus_coils_write					(gp_core_sdk_api->core_sdk_modbus_coils_write)

#define sdk_para_init                           (gp_core_sdk_api->core_sdk_para_init)
#define sdk_para_write                          (gp_core_sdk_api->core_sdk_para_write)
#define sdk_para_read                           (gp_core_sdk_api->core_sdk_para_read)
#define sdk_para_sync                           (gp_core_sdk_api->core_sdk_para_sync)
#define sdk_fs_init                             (gp_core_sdk_api->core_sdk_fs_init)
#define sdk_fs_open                             (gp_core_sdk_api->core_sdk_fs_open)
#define sdk_fs_close                            (gp_core_sdk_api->core_sdk_fs_close)
#define sdk_fs_read                             (gp_core_sdk_api->core_sdk_fs_read)
#define sdk_fs_write                            (gp_core_sdk_api->core_sdk_fs_write)
#define sdk_fs_lseek                            (gp_core_sdk_api->core_sdk_fs_lseek)
#define sdk_fs_get_size                         (gp_core_sdk_api->core_sdk_fs_get_size)
#define sdk_fs_file_sync                        (gp_core_sdk_api->core_sdk_fs_file_sync)
#define sdk_fs_remove                           (gp_core_sdk_api->core_sdk_fs_remove)
#define sdk_fs_rename                           (gp_core_sdk_api->core_sdk_fs_rename)
#define sdk_fs_access                           (gp_core_sdk_api->core_sdk_fs_access)

#define	sdk_fs_mkdir							(gp_core_sdk_api->core_sdk_fs_mkdir)
#define	sdk_fs_stat_fs							(gp_core_sdk_api->core_sdk_fs_stat_fs)
#define	sdk_fs_stat_file						(gp_core_sdk_api->core_sdk_fs_stat_file)
#define	sdk_fs_dir_open							(gp_core_sdk_api->core_sdk_fs_dir_open)
#define	sdk_fs_dir_read							(gp_core_sdk_api->core_sdk_fs_dir_read)
#define	sdk_fs_dir_close						(gp_core_sdk_api->core_sdk_fs_dir_close)
#define	sdk_fs_format							(gp_core_sdk_api->core_sdk_fs_format)


#define sdk_record_init                         (gp_core_sdk_api->core_sdk_record_init)
#define sdk_record_get_max_num                  (gp_core_sdk_api->core_sdk_record_get_max_num)
#define sdk_record_get_index                    (gp_core_sdk_api->core_sdk_record_get_index)
#define sdk_record_write                        (gp_core_sdk_api->core_sdk_record_write)
#define sdk_record_read                         (gp_core_sdk_api->core_sdk_record_read)
#define sdk_record_sync                         (gp_core_sdk_api->core_sdk_record_sync)
#define sdk_record_delete                       (gp_core_sdk_api->core_sdk_record_delete)
#define sdk_start_upgrade                       (gp_core_sdk_api->core_sdk_start_upgrade)
#define sdk_upgrade_status_get                  (gp_core_sdk_api->core_sdk_upgrade_status_get)
#define sdk_net_ip_set                          (gp_core_sdk_api->core_sdk_net_ip_set)
#define sdk_net_subnetmask_set                  (gp_core_sdk_api->core_sdk_net_subnetmask_set)
#define sdk_net_gateway_set                     (gp_core_sdk_api->core_sdk_net_gateway_set)
#define sdk_net_dns_set                         (gp_core_sdk_api->core_sdk_net_dns_set)
#define sdk_net_is_linked                       (gp_core_sdk_api->core_sdk_net_is_linked)
#define sdk_timer_init                          (gp_core_sdk_api->core_sdk_timer_init)
#define sdk_timer_set                           (gp_core_sdk_api->core_sdk_timer_set)
#define sdk_timer_start                         (gp_core_sdk_api->core_sdk_timer_start)
#define sdk_timer_stop                          (gp_core_sdk_api->core_sdk_timer_stop)
#define sdk_eeprom_write                        (gp_core_sdk_api->core_sdk_eeprom_write)
#define sdk_eeprom_read                         (gp_core_sdk_api->core_sdk_eeprom_read)

#define sdk_shell_regist                        (gp_core_sdk_api->core_sdk_shell_regist)

/** 
 * SDK接口初始化
 */
int32_t core_sdk_api_init(uint32_t sdk_api_addr);

#endif


