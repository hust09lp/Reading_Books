#ifndef __SDK_MISC_H__
#define __SDK_MISC_H__

#include "data_types.h"

typedef void*(*get_cmd_pfunc)(char *cmd, int size);

/**
 * @brief shell 命令查找函数注册 
 * @param call_back 查找函数 指针
 * @return 执行结果
 * @retval =0 执行成功
 * @retval <0 执行失败 
 */
int32_t sdk_shell_regist(get_cmd_pfunc call_back);
void* app_msh_get_cmd(char *cmd, int size);


#endif
