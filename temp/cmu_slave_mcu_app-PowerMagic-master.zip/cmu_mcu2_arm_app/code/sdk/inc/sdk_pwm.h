/**
 * @file         sdk_pwm.h
 * @brief        PWM功能定义
 * @details      主要包含了关于PWM使用的功能相关函数
 * @author       SOFAR
 * @date         2023/04/14
 * @version      V0.0.1
 * @copyright    Copyright(c) 2023 by SofarSolar, All Rights Reserved.
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author    <th>Description
 * <tr><td>2023/02/23  <td>0.0.1    <td>gjh       <td>创建初始版本
 *
 * </table>
 *
 **********************************************************************************
 * @par 示例:
 * @code
 * 暂无
 * @endcode
 */

#ifndef __SDK_PWM_H__
#define __SDK_PWM_H__

#include "data_types.h"

/**
 * @enum    sdk_pwm_polarity_e
 * @brief   空闲状态枚举值
 */
typedef enum
{
    SDK_PWM_POLARITY_LOW = 0,       ///< 空闲时的极性为低电平
    SDK_PWM_POLARITY_HIGH,          ///< 空闲时的极性为高电平
} sdk_pwm_polarity_e;

/**
 * @enum    sdk_pwm_cmd_e
 * @brief   扩展功能命令
 */
typedef enum
{
    SDK_PWM_CMD_DUTYCYCLE_SET = 0,  ///< 用于扩展功能设置PWM输出占空比指令
    SDK_PWM_CMD_FREQ_SET = 1,       ///< 用于扩展功能设置PWM输出频率指令(暂不支持该指令)
    SDK_PWM_CMD_PRECISION_SET = 2,  ///< 用于扩展功能设置PWM输出频率精度，默认精度为1Hz，10表示0.1Hz精度，100表示0.01Hz精度，最大1000
} sdk_pwm_cmd_e;


/**
 * @struct  sdk_pwm_config_t
 * @brief   pwm配置结构体
 */
typedef struct
{
    uint32_t duty_percent;    ///< PWM占空比 0-100对应0%-100%
    uint32_t freq;            ///< PWM输出频率，默认1Hz，精度可以被重新设置
    uint32_t polarity;        ///< 空闲时的极性
} sdk_pwm_config_t;



/**
 * @brief       PWM 初始化
 * @return      执行结果
 * @retval 0    执行成功
 * @retval < 0  执行失败
 */
int32_t sdk_pwm_init(void);

/**
 * @brief 打开 pwm
 * @param channel   pwm 通道
 * @return          执行结果
 * @retval 0        执行成功
 * @retval < 0      执行失败
 */
int32_t sdk_pwm_open(uint32_t channel);

/**
 * @brief PWM 配置
 * @param channel       pwm 通道
 * @param pwm_config    pwm 配置结构体
 * @return              执行结果
 * @retval 0            执行成功
 * @retval < 0          执行失败
 */
int32_t sdk_pwm_config(uint32_t channel, sdk_pwm_config_t *pwm_config);


/**
 * @brief           启动 PWM
 * @param channel   pwm 通道
 * @return          执行结果
 * @retval 0        执行成功
 * @retval < 0      执行失败
 */
int32_t sdk_pwm_start(uint32_t channel);

/**
 * @brief           PWM 停止
 * @param channel   pwm 通道
 * @return          执行结果
 * @retval 0        执行成功
 * @retval < 0      执行失败
 */
int32_t sdk_pwm_stop(uint32_t channel);


/**
 * @brief           pwm 命令控制
 * @param channel   pwm 通道
 * @param cmd       功能码
 * @param args      参数
 * @return          执行结果
 * @retval 0        执行成功
 * @retval < 0      执行失败
 */
int32_t sdk_pwm_ioctl(uint32_t channel, sdk_pwm_cmd_e cmd, void *args);


#endif /* #define __SDK_PWM_H__  */
