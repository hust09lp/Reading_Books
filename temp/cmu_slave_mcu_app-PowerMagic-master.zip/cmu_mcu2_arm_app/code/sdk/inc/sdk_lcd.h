/**
 * @file         sdk_lcd.h
 * @brief        LCD显示通用定义
 * @details      主要包含了关于LCD屏幕功能的相关函数
 * @author       SOFAR
 * @date         2023/03/06
 * @version      V0.0.1
 * @copyright    Copyright(c) 2023 by SofarSolar, All Rights Reserved. 
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author    <th>Description
 * <tr><td>2023/03/06  <td>0.0.1    <td>Chace     <td>创建初始版本
 * <tr><td>2023/03/10  <td>0.0.2    <td>hewenjun  <td>增加sdk_lcd_display_string_pixel、
 *                                                    sdk_lcd_get_str_width
 * <tr><td>2023/04/23  <td>0.0.3    <td>hewenjun  <td>char改成int8_t、指针形参str改成p_str
 * </table>
 *
 **********************************************************************************
 */

#ifndef __SDK_LCD_H__
#define __SDK_LCD_H__

#include "data_types.h"


#define LCD_ID_MAX           1    ///< LCD编号最大值

#define LCD_ALIGN_LEFT       0  // 左对齐
#define LCD_ALIGN_CENTER     1  // 居中对齐
#define LCD_ALIGN_RIGHT      2  // 右对齐

#define LCD_CTRL_BACKLIGHT   0  // 控制背光灯
#define LCD_GET_ATTR         1  // 获取屏幕属性

#define LCD_CMD_BL_OFF       0  // 背光灯-OFF
#define LCD_CMD_BL_ON        1  // 背光灯-ON

/**
 * @brief     打开LCD设备
 * @param[in] lcd_id 虚拟LCD编号
 * -# LCD编号参数不大于LCD_ID_MAX(详细映射关系参看平台部提供接口映射表)
 * @return    执行结果
 * @retval    0  成功
 * @retval    <0 失败原因，详情见sf_errors.h
 * @attention 执行sdk_lcd_init后执行才有效
 */
int32_t sdk_lcd_open(uint32_t lcd_id);

/**
 * @brief     关闭LCD功能
 * @param[in] lcd_id 虚拟LCD编号
 * -# LCD编号参数不大于LCD_ID_MAX(详细映射关系参看平台部提供接口映射表)
 * @return    执行结果
 * @retval    0  成功
 * @retval    <0 失败原因，详情见sf_errors.h
 * @attention 执行sdk_lcd_init后执行才有效
 */
int32_t sdk_lcd_close(uint32_t lcd_id);

/**
 * @brief     LCD唤醒功能
 * @param[in] lcd_id 虚拟LCD编号
 * -# LCD编号参数不大于LCD_ID_MAX(详细映射关系参看平台部提供接口映射表)
 * @return    执行结果
 * @retval    0  成功
 * @retval    <0 失败原因，详情见sf_errors.h
 * @attention 执行sdk_lcd_open后执行才有效
 */
int32_t sdk_lcd_resume(uint32_t lcd_id);

/**
 * @brief     LCD进入休眠模式
 * @param[in] lcd_id 虚拟LCD编号
 * -# LCD编号参数不大于LCD_ID_MAX(详细映射关系参看平台部提供接口映射表)
 * @return    执行结果
 * @retval    0  成功  
 * @retval    <0 失败原因，详情见sf_errors.h
 * @attention 执行sdk_lcd_open后执行才有效
 * @warning   本接口调用后，需要把对应管脚也设置为低功耗模式
 */
int32_t sdk_lcd_suspend(uint32_t lcd_id);

/**
 * @brief     清空显示
 * @param[in] lcd_id 虚拟LCD编号
 * -# LCD编号参数不大于LCD_ID_MAX(详细映射关系参看平台部提供接口映射表)
 * @return    执行结果
 * @retval    0  成功
 * @retval    <0 失败原因，详情见sf_errors.h
 * @attention 执行sdk_lcd_open后执行才有效
 * @warning   本接口调用后，数据只刷新到RAM中，还没更新到LCD设备 
 */
int32_t sdk_lcd_clear(uint32_t lcd_id);

/**
 * @brief     更新LCD
 * @param[in] lcd_id 虚拟LCD编号
 * -# LCD编号参数不大于LCD_ID_MAX(详细映射关系参看平台部提供接口映射表)
 * @return    执行结果
 * @retval    0  成功
 * @retval    <0 失败原因，详情见sf_errors.h
 * @attention 执行sdk_lcd_open后执行才有效
 * @warning   本接口调用后，数据才会更新到LCD设备
 */
int32_t sdk_lcd_reflash(uint32_t lcd_id);

/**
 * @brief     LCD显示字符串
 * @param[in] lcd_id 虚拟LCD编号
 * -# LCD编号参数不大于LCD_ID_MAX(详细映射关系参看平台部提供接口映射表)
 * @param[in] line 显示行
 * @param[in] col 显示列
 * @param[in] str 显示字符串，'\0'结尾
 * @return    执行结果
 * @retval    0  成功
 * @retval    <0 失败原因，详情见sf_errors.h
 * @attention 执行sdk_lcd_open后执行才有效
 * @warning   本接口调用后，数据只刷新到RAM中，还没更新到LCD设备 
 */
int32_t sdk_lcd_display_string(uint32_t lcd_id, uint32_t line, uint32_t col, const int8_t *p_str);

/**
 * @brief     更新字符串,像素点级
 * @param     [in] lcd_id 虚拟LCD设备
 * @param     [in] line 显示行,像素点级
 * @param     [in] col 显示列,像素点级
 * @param     [in] str 显示字符串，'\0'结尾
 * @return    执行结果
 * @retval    0  成功
 * @retval    <0 失败原因，详情见sf_errors.h
 * @attention 执行sdk_lcd_open后执行才有效
 * @warning   本接口调用后，数据只刷新到RAM中，还没更新到LCD设备 
 */
int32_t sdk_lcd_display_string_pixel(uint32_t lcd_id, uint32_t line, uint32_t col, const int8_t *p_str);

/**
 * @brief     获取字符占用的像素点
 * @param     [in] lcd_id 虚拟LCD设备  
 * @param     [in] str 显示字符串，'\0'结尾
 * @return    返回结果：占用像素点宽度
 */
int32_t sdk_lcd_get_str_width(uint32_t lcd_id, const int8_t *p_str);

/**
 * @brief     LCD显示字符串对齐
 * @param[in] lcd_id 虚拟LCD编号
 * -# LCD编号参数不大于LCD_ID_MAX(详细映射关系参看平台部提供接口映射表)
 * @param[in] line 显示行  
 * @param[in] align_type 对其方式
 * -# LCD_ALIGN_LEFT - 0x00 左对齐
 * -# LCD_ALIGN_CENTER - 0x01 居中对齐
 * -# LCD_ALIGN_RIGHT - 0x02 右对齐
 * @param[in] str 显示字符串，'\0'结尾
 * @return    执行结果
 * @retval    0  成功
 * @retval    <0 失败原因，详情见sf_errors.h
 * @attention 执行sdk_lcd_open后执行才有效
 * @warning   本接口调用后，数据只刷新到RAM中，还没更新到LCD设备 
 */
int32_t sdk_lcd_display_string_align(uint32_t lcd_id, uint32_t line, uint8_t align_type, const int8_t *p_str);

/**
 * @brief     LCD清空指定长度的行
 * @param[in] lcd_id 虚拟LCD编号
 * -# LCD编号参数不大于LCD_ID_MAX(详细映射关系参看平台部提供接口映射表)
 * @param[in] line 显示行
 * @param[in] col 起始显示列
 * @param[in] width 清空的宽度
 * @return    执行结果
 * @retval    0  成功
 * @retval    <0 失败原因，详情见sf_errors.h
 * @attention 执行sdk_lcd_open后执行才有效
 * @warning   本接口调用后，数据只刷新到RAM中，还没更新到LCD设备
 */
int32_t sdk_lcd_clear_line(uint32_t lcd_id, uint32_t line, uint32_t col, uint8_t width);

/**
 * @brief     LCD翻转指定长度的行
 * @param[in] lcd_id 虚拟LCD编号
 * -# LCD编号参数不大于LCD_ID_MAX(详细映射关系参看平台部提供接口映射表)
 * @param[in] line 显示行
 * @param[in] col 起始显示列
 * @param[in] width 翻转的宽度
 * @return    执行结果
 * @retval    0  成功
 * @retval    <0 失败原因，详情见sf_errors.h
 * @attention 执行sdk_lcd_open后执行才有效
 * @warning   本接口调用后，数据只刷新到RAM中，还没更新到LCD设备 
 */
int32_t sdk_lcd_reverse_line(uint32_t lcd_id, uint32_t line, uint32_t col, uint32_t width);

/**
 * @brief     LCD显示图片
 * @param[in] lcd_id 虚拟LCD编号
 * -# LCD编号参数不大于LCD_ID_MAX(详细映射关系参看平台部提供接口映射表)
 * @param[in] x 起始行坐标  
 * @param[in] y 起始列坐标 
 * @param[in] w 图片宽度
 * @param[in] h 图片高度
 * @param[in] date 显示图片数据
 * @return    执行结果
 * @retval    0  成功
 * @retval    <0 失败原因，详情见sf_errors.h
 * @attention 执行sdk_lcd_open后执行才有效
 * @warning   本接口调用后，数据只刷新到RAM中，还没更新到LCD设备 
 */
int32_t sdk_lcd_display_bmp(uint32_t lcd_id, uint32_t x, uint32_t y, uint32_t w, uint32_t h, const uint8_t *p_data);

/**
 * @brief     LCD扩展功能 
 * @param[in] lcd_id 虚拟LCD编号
 * -# LCD编号参数不大于LCD_ID_MAX(详细映射关系参看平台部提供接口映射表)
 * @param[in] cmd 控制命令
 * -# LCD_CTRL_BACKLIGHT - 0x00 控制背光灯
 * -# LCD_GET_ATTR - 0x01 获取屏幕属性
 * @param[in] arg 控制参数
 * @return    执行结果
 * @retval    0  成功
 * @retval    <0 失败原因，详情见sf_errors.h
 * @attention 执行sdk_lcd_open后执行才有效
 * @par 示例:
 * @code
    uint32_t lcd_backlight_state = LCD_CMD_BL_ON;
    sdk_lcd_ioctl(LCD_NO, LCD_CTRL_BACKLIGHT, &lcd_backlight_state);
    
    lcd_attr_t lcd_attr;
    memset(&lcd_attr, 0, sizeof(lcd_attr_t));
    sdk_lcd_ioctl(LCD_NO, LCD_GET_ATTR, &lcd_attr);
 * @endcode
 */
int32_t sdk_lcd_ioctl(uint32_t lcd_id, uint8_t cmd, void* p_arg);


#endif /*__SDK_LCD_H__*/
