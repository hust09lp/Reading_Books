#ifndef __SDK_H__
#define __SDK_H__


#include "sofar_errors.h"
#include "sdk_can.h"
#include "sdk_uart.h"
#include "sdk_dido.h"
#include "sdk_fs.h"
#include "sdk_led.h"
#include "sdk_log.h"
#include "sdk_osif.h"
#include "sdk_modbus.h"
#include "sdk_para.h"
#include "sdk_public.h"
#include "sdk_record.h"
#include "sdk_upgrade.h"
#include "sdk_version.h"
#include "sdk_timer.h"
#include "sdk_osif.h"
#include "sdk_net_public.h"
#include "sdk_eeprom.h"
#include "sdk_misc.h"

/**
 * 软件版本号，用来生成1k签名信息时使用
 */
#define SOFTWARE_VERSION        "V0.1.12" // "V00.000.000"
#define HARDWARE_VERSION        "V0.0.1" // "V00.000.000"

/**
* 主版本号
*/
#define SDK_MAJOR_VERSION        0        ///< 当API的兼容性变化时，需递增(0 - 99)
/**
* 次版本号
*/
#define SDK_MINOR_VERSION        1        ///< 当增加功能时(不影响API 的兼容性)，需递增(0 - 255)
/**
* 阶段版本号
*/
#define SDK_STAGE_VERSION        12        ///< 当做Bug修复时(不影响API 的兼容性)，需递增(0 - 255)
/**
* SDK版本字符串(规则为: V主版本.次版本.阶段版本)
*/
#define SDK_VERSION_INFO         "V0.1.12"


typedef int32_t  (*core_sdk_version_get_f)(version_type_e type, int8_t *p_version, uint16_t len);

typedef void     (*core_sdk_delay_us_f)(uint32_t us);
typedef void     (*core_sdk_delay_ms_f)(uint32_t ms);

typedef int32_t  (*core_sdk_os_delay_f)(uint32_t ticks);
typedef uint32_t (*core_sdk_os_tick_from_millisecond_f)(uint32_t ms);
typedef int32_t  (*core_sdk_os_thread_new_f)(uint8_t thread_num, sdk_os_thread_attr_tab_t *p_attr);
typedef sdk_os_sem_id_t (*core_sdk_os_sem_new_f)(uint32_t initial_value, sdk_os_sem_attr_t *p_sem_attr);//初始化信号量
typedef sdk_os_status_e (*core_sdk_os_sem_acquire_f)(sdk_os_sem_id_t semaphore_id, uint32_t timeout);//得到信号量
typedef sdk_os_status_e (*core_sdk_os_sem_release_f)(sdk_os_sem_id_t semaphore_id);//释放信号量
typedef sdk_os_status_e (*core_sdk_os_sem_delete_f)(sdk_os_sem_id_t semaphore_id);//删除指定的信号量
typedef sdk_os_mutex_id_t (*core_sdk_os_mutex_new_f)(sdk_os_mutex_attr_t *mutex_attr);
typedef sdk_os_status_e (*core_sdk_os_mutex_acquire_f)(sdk_os_mutex_id_t mutex_id, uint32_t timeout) ;
typedef sdk_os_status_e (*core_sdk_os_mutex_release_f)(sdk_os_mutex_id_t mutex_id);
typedef sdk_os_status_e (*core_sdk_os_mutex_delete_f)(sdk_os_mutex_id_t mutex_id);

typedef int32_t  (*core_sdk_log_init_f)(void);
typedef void     (*core_sdk_log_set_level_f)(uint8_t log_level);
typedef uint8_t  (*core_sdk_log_get_level_f)(void);
typedef int      (*core_sdk_log_printf_f)(const char *p_format, ...);
typedef int32_t  (*core_sdk_log_hexdump_f)(const int8_t *p_name, uint8_t width, uint8_t *p_buf, uint16_t size);
typedef void     (*core_sdk_log_finish_f)(void);

typedef int32_t  (*core_sdk_wdt_enable_f)(uint8_t state);
typedef int32_t  (*core_sdk_wdt_feed_f)(void);
typedef void     (*core_sdk_sys_reset_f)(void);

typedef uint32_t (*core_sdk_tick_get_f)(void);
typedef bool     (*core_sdk_is_tick_over_f)(uint32_t start_tick, uint32_t interval);
typedef int32_t  (*core_sdk_rtc_set_f)(uint32_t rtc_format, sdk_rtc_t *p_time);
typedef int32_t  (*core_sdk_rtc_get_f)(uint32_t rtc_format, sdk_rtc_t *p_time);
typedef bool     (*core_sdk_is_time_over_f)(sdk_rtc_t *p_start_time, uint32_t interval);

typedef int32_t  (*core_sdk_led_flash_f)(uint32_t led_id, uint32_t period, uint32_t duty, int32_t times);
typedef int32_t  (*core_sdk_led_on_f)(uint32_t led_id);
typedef int32_t  (*core_sdk_led_off_f)(uint32_t led_id);

typedef int32_t  (*core_sdk_dido_write_f)(uint8_t do_id, bool value);
typedef int32_t  (*core_sdk_dido_read_f)(uint8_t di_id);
typedef int32_t  (*core_sdk_dido_set_irq_f)(uint8_t di_id, dido_irq_e mode, f_dido_irq_callback p_fcallback);
typedef int32_t  (*core_sdk_dido_free_irq_f)(uint8_t di_id);

typedef int32_t  (*core_sdk_can_open_f)(uint32_t port);
typedef int32_t  (*core_sdk_can_close_f)(uint32_t port);
typedef int32_t  (*core_sdk_can_setup_f)(uint32_t port, sdk_can_cfg_t * p_cfg);
typedef int32_t  (*core_sdk_can_write_f)(uint32_t port, sdk_can_frame_t *p_can_frame, uint32_t len);
typedef int32_t  (*core_sdk_can_read_f)(uint32_t port, sdk_can_frame_t *p_can_frame, uint32_t len, int32_t timeout_ms);

typedef int32_t  (*core_sdk_uart_open_f)(uint32_t port);
typedef int32_t  (*core_sdk_uart_close_f)(uint32_t port);
typedef int32_t  (*core_sdk_uart_setup_f)(uint32_t port, sdk_uart_conf_t *p_uart_conf);
typedef int32_t  (*core_sdk_uart_write_f)(uint32_t port, uint8_t *p_buf, uint32_t len);
typedef int32_t  (*core_sdk_uart_read_f)(uint32_t port, uint8_t *p_buf, uint32_t len, int32_t timeout_ms);

typedef int32_t  (*core_sdk_modbus_rtu_init_f)(uint32_t index, uint32_t slave, uint32_t baud);
typedef int32_t  (*core_sdk_modbus_slave_set_f)(uint32_t index, uint32_t slave);
typedef int32_t  (*core_sdk_modbus_baud_set_f)(uint32_t index, uint32_t baud);
typedef int32_t  (*core_sdk_modbus_response_timeout_set_f)(uint32_t index, uint32_t timeout_ms);
typedef int32_t  (*core_sdk_modbus_connect_f)(uint32_t index);
typedef int32_t  (*core_sdk_modbus_close_f)(uint32_t index);
typedef int32_t  (*core_sdk_modbus_free_f)(uint32_t index);
typedef int32_t  (*core_sdk_modbus_receive_f)(uint32_t index, uint8_t *p_req);
typedef int32_t  (*core_sdk_modbus_reply_f)(uint32_t index, const uint8_t *p_req, int req_length, modbus_function_cb pf_modbus_function);
typedef int32_t (*core_sdk_modbus_registers_read_f)(uint32_t index, int32_t addr, int32_t nb, uint16_t *dest);
typedef int32_t (*core_sdk_modbus_register_write_f)(uint32_t index, int32_t addr, const uint16_t value);
typedef int32_t (*core_sdk_modbus_registers_write_f)(uint32_t index, int32_t addr, int32_t nb, const uint16_t *data);
typedef int32_t (*core_sdk_modbus_flush_f)(uint32_t index);
typedef int32_t (*core_sdk_modbus_coils_read_f)(uint32_t index, int32_t addr, int32_t nb, uint8_t *p_dest);
typedef int32_t (*core_sdk_modbus_coil_write_f)(uint32_t index, int32_t addr, const bool value);
typedef int32_t (*core_sdk_modbus_coils_write_f)(uint32_t index, int32_t addr, int32_t nb, const uint8_t *p_data);

typedef int32_t  (*core_sdk_para_init_f)(uint32_t type, uint32_t para_size);
typedef int32_t  (*core_sdk_para_write_f)(uint32_t type, uint32_t offset, uint8_t *p_buf, uint32_t len);
typedef int32_t  (*core_sdk_para_read_f)(uint32_t type, uint32_t offset, uint8_t *p_buf, uint32_t len);
typedef int32_t  (*core_sdk_para_sync_f)(uint32_t type);

typedef int32_t  (*core_sdk_fs_init_f)(void);
typedef fs_t *   (*core_sdk_fs_open_f)(const int8_t *path, uint16_t mode);
typedef int32_t  (*core_sdk_fs_close_f)(fs_t *p_fs);
typedef int32_t  (*core_sdk_fs_read_f)(fs_t *p_fs, void *buff, uint32_t len);
typedef int32_t  (*core_sdk_fs_write_f)(fs_t *p_fs, void *buff, uint32_t len);
typedef int32_t  (*core_sdk_fs_lseek_f)(fs_t *p_fs, uint32_t offset);
typedef int32_t  (*core_sdk_fs_get_size_f)(fs_t *p_fs);
typedef int32_t  (*core_sdk_fs_file_sync_f)(fs_t *p_fs);
typedef int32_t  (*core_sdk_fs_remove_f)(const int8_t *path);
typedef int32_t  (*core_sdk_fs_rename_f)(const int8_t *oldpath, const int8_t *newpath);
typedef int32_t  (*core_sdk_fs_access_f)(const int8_t *p_path, uint32_t mode);
typedef int32_t  (*core_sdk_fs_mkdir_f)(const int8_t *p_path, uint32_t mode);
typedef int32_t  (*core_sdk_fs_stat_fs_f)(const int8_t *p_path, fs_stat_fs *p_buf);
typedef int32_t  (*core_sdk_fs_stat_file_f)(const int8_t *p_path, fs_stat_file *p_buf);
typedef fs_dir_t*  (*core_sdk_fs_dir_open_f)(const int8_t *p_path);
typedef fs_dirent_t*  (*core_sdk_fs_dir_read_f)(fs_dir_t *p_dir);
typedef int32_t  (*core_sdk_fs_dir_close_f)(fs_dir_t *p_dir);
typedef int32_t  (*core_sdk_fs_format_f)(void);

typedef int32_t  (*core_sdk_record_init_f)(uint32_t type, uint32_t one_record_size, uint32_t max_num);
typedef int32_t  (*core_sdk_record_get_max_num_f)(uint32_t type);
typedef int32_t  (*core_sdk_record_get_index_f)(uint32_t type);
typedef int32_t  (*core_sdk_record_write_f)(uint32_t type, int32_t index, uint8_t *p_buf, uint32_t len);
typedef int32_t  (*core_sdk_record_read_f)(uint32_t type, int32_t index, uint8_t *p_buf, uint32_t len);
typedef int32_t  (*core_sdk_record_sync_f)(uint32_t type);
typedef int32_t  (*core_sdk_record_delete_f)(uint32_t type);

typedef int32_t  (*core_sdk_start_upgrade_f)(uint8_t *p_dir, uint8_t flag);
typedef int32_t  (*core_sdk_upgrade_status_get_f)(uint8_t flag);

typedef int32_t (*core_sdk_net_ip_set_f)(net_device_type_e nic, uint8_t *p_ip);
typedef int32_t (*core_sdk_net_subnetmask_set_f)(net_device_type_e nic, uint8_t *p_subnet);
typedef int32_t (*core_sdk_net_gateway_set_f)(net_device_type_e nic, uint8_t *p_gateway);
typedef int32_t (*core_sdk_net_dns_set_f)(net_device_type_e nic, uint8_t *p_dns);
typedef int32_t (*core_sdk_net_is_linked_f)(net_device_type_e nic);

typedef int32_t (*core_sdk_timer_init_f)(uint32_t id, timer_type_e type);
typedef int32_t (*core_sdk_timer_set_f)(uint32_t id, timer_type_e type, uint32_t us,call_back_f call_back);
typedef int32_t (*core_sdk_timer_start_f)(uint32_t id,timer_type_e type );
typedef int32_t (*core_sdk_timer_stop_f)(uint32_t id,timer_type_e type );

typedef int32_t  (*core_sdk_modbus_indication_timeout_set_f)(uint32_t index, uint32_t timeout_ms);

typedef int32_t (*core_sdk_eeprom_read_f)(uint32_t offset, uint32_t len, uint8_t *p_buf);
typedef int32_t (*core_sdk_eeprom_write_f)(uint32_t offset, uint32_t len, uint8_t *p_buf);

typedef int32_t (*core_sdk_modbus_input_registers_read_f)(uint32_t index, int32_t addr, int32_t nb, uint16_t *dest);

typedef int32_t (*core_sdk_shell_regist_f)(get_cmd_pfunc call_back);
// ...待添加

typedef struct 
{
    core_sdk_version_get_f core_sdk_version_get;

    core_sdk_delay_us_f core_sdk_delay_us;
    core_sdk_delay_ms_f core_sdk_delay_ms;
    
    core_sdk_os_delay_f core_sdk_os_delay;
    core_sdk_os_tick_from_millisecond_f core_sdk_os_tick_from_millisecond;
    core_sdk_os_thread_new_f core_sdk_os_thread_new;
    core_sdk_os_sem_new_f core_sdk_os_sem_new;
    core_sdk_os_sem_acquire_f core_sdk_os_sem_acquire;
    core_sdk_os_sem_release_f core_sdk_os_sem_release;
    core_sdk_os_sem_delete_f core_sdk_os_sem_delete;
    core_sdk_os_mutex_new_f core_sdk_os_mutex_new;
    core_sdk_os_mutex_acquire_f core_sdk_os_mutex_acquire;
    core_sdk_os_mutex_release_f core_sdk_os_mutex_release;
    core_sdk_os_mutex_delete_f core_sdk_os_mutex_delete;

    core_sdk_log_init_f core_sdk_log_init;
    core_sdk_log_set_level_f core_sdk_log_set_level;
    core_sdk_log_get_level_f core_sdk_log_get_level;
    core_sdk_log_printf_f core_sdk_log_printf;
    core_sdk_log_hexdump_f core_sdk_log_hexdump;
    core_sdk_log_finish_f core_sdk_log_finish;

    core_sdk_wdt_enable_f core_sdk_wdt_enable;
    core_sdk_wdt_feed_f core_sdk_wdt_feed;
    core_sdk_sys_reset_f core_sdk_sys_reset;

    core_sdk_tick_get_f core_sdk_tick_get;
    core_sdk_is_tick_over_f core_sdk_is_tick_over;
    core_sdk_rtc_set_f core_sdk_rtc_set;
    core_sdk_rtc_get_f core_sdk_rtc_get;
    core_sdk_is_time_over_f core_sdk_is_time_over;


    core_sdk_led_flash_f core_sdk_led_flash;
    core_sdk_led_on_f core_sdk_led_on;
    core_sdk_led_off_f core_sdk_led_off;

    core_sdk_dido_write_f core_sdk_dido_write;
    core_sdk_dido_read_f core_sdk_dido_read;
    core_sdk_dido_set_irq_f core_sdk_dido_set_irq;
    core_sdk_dido_free_irq_f core_sdk_dido_free_irq;


    core_sdk_can_open_f core_sdk_can_open;
    core_sdk_can_close_f core_sdk_can_close;
    core_sdk_can_setup_f core_sdk_can_setup;
    core_sdk_can_write_f core_sdk_can_write;
    core_sdk_can_read_f core_sdk_can_read;

    core_sdk_uart_open_f core_sdk_uart_open;
    core_sdk_uart_close_f core_sdk_uart_close;
    core_sdk_uart_setup_f core_sdk_uart_setup;
    core_sdk_uart_write_f core_sdk_uart_write;
    core_sdk_uart_read_f core_sdk_uart_read;

    core_sdk_modbus_rtu_init_f core_sdk_modbus_rtu_init;
    core_sdk_modbus_slave_set_f core_sdk_modbus_slave_set;
    core_sdk_modbus_baud_set_f core_sdk_modbus_baud_set;
    core_sdk_modbus_response_timeout_set_f core_sdk_modbus_response_timeout_set;
    core_sdk_modbus_connect_f core_sdk_modbus_connect;
    core_sdk_modbus_close_f core_sdk_modbus_close;
    core_sdk_modbus_free_f core_sdk_modbus_free;
    core_sdk_modbus_receive_f core_sdk_modbus_receive;
    core_sdk_modbus_reply_f core_sdk_modbus_reply;
    core_sdk_modbus_registers_read_f core_sdk_modbus_registers_read;
    core_sdk_modbus_register_write_f core_sdk_modbus_register_write;
    core_sdk_modbus_registers_write_f core_sdk_modbus_registers_write;
	core_sdk_modbus_flush_f core_sdk_modbus_flush;
    core_sdk_modbus_coils_read_f core_sdk_modbus_coils_read;
    core_sdk_modbus_coil_write_f core_sdk_modbus_coil_write;
    core_sdk_modbus_coils_write_f core_sdk_modbus_coils_write;

    core_sdk_para_init_f core_sdk_para_init;
    core_sdk_para_write_f core_sdk_para_write;
    core_sdk_para_read_f core_sdk_para_read;
    core_sdk_para_sync_f core_sdk_para_sync;

    core_sdk_fs_init_f core_sdk_fs_init;
    core_sdk_fs_open_f core_sdk_fs_open;
    core_sdk_fs_close_f core_sdk_fs_close;
    core_sdk_fs_read_f core_sdk_fs_read;
    core_sdk_fs_write_f core_sdk_fs_write;
    core_sdk_fs_lseek_f core_sdk_fs_lseek;
    core_sdk_fs_get_size_f core_sdk_fs_get_size;
    core_sdk_fs_file_sync_f core_sdk_fs_file_sync;
    core_sdk_fs_remove_f core_sdk_fs_remove;
    core_sdk_fs_rename_f core_sdk_fs_rename;
	core_sdk_fs_access_f core_sdk_fs_access;
	core_sdk_fs_mkdir_f core_sdk_fs_mkdir;
	core_sdk_fs_stat_fs_f core_sdk_fs_stat_fs;
	core_sdk_fs_stat_file_f core_sdk_fs_stat_file;
	core_sdk_fs_dir_open_f core_sdk_fs_dir_open;
	core_sdk_fs_dir_read_f core_sdk_fs_dir_read;
	core_sdk_fs_dir_close_f core_sdk_fs_dir_close;
	core_sdk_fs_format_f core_sdk_fs_format;

    core_sdk_record_init_f core_sdk_record_init;
    core_sdk_record_get_max_num_f core_sdk_record_get_max_num;
    core_sdk_record_get_index_f core_sdk_record_get_index;
    core_sdk_record_write_f core_sdk_record_write;
    core_sdk_record_read_f core_sdk_record_read;
    core_sdk_record_sync_f core_sdk_record_sync;
    core_sdk_record_delete_f core_sdk_record_delete;
    
    core_sdk_start_upgrade_f core_sdk_start_upgrade;
    core_sdk_upgrade_status_get_f core_sdk_upgrade_status_get;
    
    core_sdk_net_ip_set_f core_sdk_net_ip_set;
    core_sdk_net_subnetmask_set_f core_sdk_net_subnetmask_set;
    core_sdk_net_gateway_set_f core_sdk_net_gateway_set;
    core_sdk_net_dns_set_f core_sdk_net_dns_set;
	core_sdk_net_is_linked_f core_sdk_net_is_linked;

    core_sdk_timer_init_f core_sdk_timer_init;
    core_sdk_timer_set_f  core_sdk_timer_set;
    core_sdk_timer_start_f core_sdk_timer_start;
    core_sdk_timer_stop_f core_sdk_timer_stop;

    core_sdk_modbus_indication_timeout_set_f core_sdk_modbus_indication_timeout_set;

    core_sdk_eeprom_write_f core_sdk_eeprom_write;
    core_sdk_eeprom_read_f core_sdk_eeprom_read;

    core_sdk_modbus_input_registers_read_f core_sdk_modbus_input_registers_read;

    core_sdk_shell_regist_f core_sdk_shell_regist;
    // ...待添加
}core_sdk_interface_t;


#endif

