/** 
 * @file        sdk_osif.h
 * @brief       os系统功能定义
 * @details     主要包含了关于os系统功能的相关函数
 * @author   	renwj
 * @note     	无
 * @version  	V1.0.1 初始版本
 * @date     	2022/12/30
 * @copyright   Copyright(c) 2022 by SofarSolar, All Rights Reserved. 
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author    <th>Description
 * <tr><td>2022/2/30   <td>1.0.1    <td>renwj     <td>创建初始版本
 * </table>
 *
 **********************************************************************************
 * @par 示例:
 * @code
 * 暂无
 * @endcode
 */
 
#ifndef __SDK_OSIF_H__
#define __SDK_OSIF_H__

#include "data_types.h"


///**
// * @enum os_app_priority_e 
// * @brief Priority values.
// * @warning 供应用层app调用，core禁止调用
// */
//typedef enum {
//    OS_APP_PRIORITY_1 = 0,             ///< Priority:highest 
//    OS_APP_PRIORITY_2,                 ///< Priority:2 
//    OS_APP_PRIORITY_3,                 ///< Priority:3 
//    OS_APP_PRIORITY_4,                 ///< Priority:4
//    OS_APP_PRIORITY_5,                 ///< Priority:5
//    OS_APP_PRIORITY_6,                 ///< Priority:6
//    OS_APP_PRIORITY_7,                 ///< Priority:7
//    OS_APP_PRIORITY_8,                 ///< Priority:8
//    OS_APP_PRIORITY_9,                 ///< Priority:9
//    OS_APP_PRIORITY_10,                ///< Priority:10
//    OS_APP_PRIORITY_11,                ///< Priority:11
//    OS_APP_PRIORITY_12,                ///< Priority:lowest
//} sdk_os_priority_e;

#define SDK_OS_PRIORITY_MAX             20   ///< app use Priority max number

typedef void *sdk_os_sem_id_t;
typedef void *sdk_os_mutex_id_t;

/**
 * @struct os_thread_attr_t
 * @brief Attributes structure for thread.
 */
typedef struct {
    const char                            *name;            ///< name of the thread
    uint32_t                            attr_bits;        ///< attribute bits
    void                                *cb_mem;        ///< memory for control block
    uint32_t                            cb_size;        ///< size of provided memory for control block
    uint32_t                            tick;
    void                                *stack_mem;        ///< memory for stack
    uint32_t                            stack_size;        ///< size of stack
    uint32_t                            priority;        ///< initial thread priority (default: OS_PRIORITY_NORMAL)
#ifdef __TZ_MODULEID_T__
    TZ_module_id_t                        tz_module;        ///< TrustZone module identifier
#endif
    uint32_t                            reserved;        ///< reserved (must be 0)
} sdk_os_thread_attr_t;


/**
 * @enum os_status_e
 * @brief Status code values returned by RTOS functions.
 */
typedef enum {
    SDK_OS_OK                            =  0,            ///< Operation completed successfully.
    SDK_OS_ERROR                        = -1,            ///< Unspecified RTOS error: run-time error but no other error message fits.
    SDK_OS_ERROR_TIMEOUT                = -2,            ///< Operation not completed within the timeout period.
    SDK_OS_ERROR_RESOURCE                = -3,            ///< Resource not available.
    SDK_OS_ERROR_PARAMETER                = -4,            ///< Parameter error.
    SDK_OS_ERROR_NO_MEMORY                = -5,            ///< System is out of memory: it was impossible to allocate or reserve memory for the operation.
    SDK_OS_ERROR_ISR                    = -6,            ///< Not allowed in ISR context: the function cannot be called from interrupt service routines.
    SDK_OS_STATUS_RESERVED                = 0x7FFFFFFF    ///< Prevents enum down-size compiler optimization.
} sdk_os_status_e;

/// \details Thread ID identifies the thread.
typedef void *sdk_os_thread_id_t;


/** Entry point of a thread. */
typedef void (*sdk_os_thread_func_t)(void *argument);


typedef struct
{
    sdk_os_thread_attr_t thread_attr;
    sdk_os_thread_func_t func;
    sdk_os_thread_id_t   thread_id;
}sdk_os_thread_attr_tab_t;

typedef struct {
    const char                            *name;            ///< name of the semaphore
    uint32_t                            attr_bits;        ///< attribute bits
    void                                *cb_mem;        ///< memory for control block
    uint32_t                            cb_size;        ///< size of provided memory for control block
} sdk_os_sem_attr_t;

typedef struct {
    const char                            *name;            ///< name of the mutex
    uint32_t                            attr_bits;        ///< attribute bits
    void                                *cb_mem;        ///< memory for control block
    uint32_t                            cb_size;        ///< size of provided memory for control block
} sdk_os_mutex_attr_t;

// Timeout value.
#define OS_WAIT_FOREVER                    0xFFFFFFFFU ///< Wait forever timeout value.

/**
 * @brief        Status code values returned by RTOS functions.
 * @param        [in] ticks 延时多少ticks
 * @return        执行结果 返回状态
 */
int32_t sdk_os_delay(uint32_t ticks);

/**
 * @brief        毫秒转成tick数.
 * @param        [in] ms
 * @return        执行结果 tick
 */
uint32_t sdk_os_tick_from_millisecond(uint32_t ms);

/**
 * @brief        注册线程
 * @param        [in] thread_num  线程数量
 * @param        [in] *p_attr 线程属性结构指针
 * @return        执行结果
 * @retval        -1 创建失败 
 * @retval        0  创建成功  
 */
int32_t sdk_os_thread_new(uint8_t thread_num, sdk_os_thread_attr_tab_t *p_attr);

sdk_os_sem_id_t sdk_os_sem_new(uint32_t initial_value, sdk_os_sem_attr_t *p_sem_attr); // 初始化信号量
sdk_os_status_e sdk_os_sem_acquire(sdk_os_sem_id_t semaphore_id, uint32_t timeout);    // 得到信号量
sdk_os_status_e sdk_os_sem_release(sdk_os_sem_id_t semaphore_id); // 释放信号量
sdk_os_status_e sdk_os_sem_delete(sdk_os_sem_id_t semaphore_id);  // 删除指定的信号量

sdk_os_mutex_id_t sdk_os_mutex_new(sdk_os_mutex_attr_t *p_mutex_attr);
sdk_os_status_e sdk_os_mutex_acquire(sdk_os_mutex_id_t mutex_id, uint32_t timeout) ;
sdk_os_status_e sdk_os_mutex_release(sdk_os_mutex_id_t mutex_id);
sdk_os_status_e sdk_os_mutex_delete(sdk_os_mutex_id_t mutex_id);

#endif
