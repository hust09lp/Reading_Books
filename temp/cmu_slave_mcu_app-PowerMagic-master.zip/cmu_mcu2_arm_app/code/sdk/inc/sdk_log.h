/** 
 * @file          sdk_log.h
 * @brief         log日志相关功能
 * @author        qinmingsheng
 * @version       V0.0.1     初始版本
 * @date          2022/12/19 20:15:14
 * @copyright     Copyright(c) 2022 by SofarSolar, All Rights Reserved. 
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author    <th>Description
 * <tr><td>2023/02/23  <td>0.0.1    <td>apoi     <td>创建初始版本
 * </table>
 *
 **********************************************************************************
 * @par 示例:
 * @code
 * 暂无
 * @endcode
 */

#ifndef __SDK_LOG_H__
#define __SDK_LOG_H__

#include <stdio.h>
#include "data_types.h"

#define LOG_LVL_DISABLE                     0       ///< 关闭调试
#define LOG_LVL_ASSERT                      1       ///< 表明出现了不合理数据，导致系统卡死
#define LOG_LVL_ERROR                       2       ///< 表明出现了系统错误和异常，无法正常完成目标操作。
#define LOG_LVL_WARN                        3       ///< 表明系统出现轻微的不合理但不影响运行和使用；
#define LOG_LVL_INFO                        4       ///< 用于打印程序应该出现的正常状态信息， 便于追踪定位
#define LOG_LVL_DEBUG                       5       ///< 级别最低，可以随意的使用于任何觉得有利于在调试时更详细的了解系统运行状态的东东

#define MAX_PRINT_BUF_LEN   1024

/** 
 * @brief        日志初始化函数
 * @return       [int32_t] 执行结果
 * @retval       =0 成功
 * @retval       <0 失败 初始化第三方库失败
 * @note         当返回值小于0时，只说明初始化第三方库失败，失败后会使用默认打印（不打印到文件）
 */
int32_t sdk_log_init(void);

/** 
 * @brief        设置日志打印级别
 * @param        [in] log_level 要设置的打印级别的值
 * @note         默认打印级别为3，只打印级别为1、2的数据。
 */
void sdk_log_set_level(uint8_t log_level);

/** 
 * @brief        获取日志打印级别
 * @param        void
 * @note         
 */
uint8_t sdk_log_get_level(void);

/** 
 * @brief        日志输出
 * @param        [in] *p_format 日志信息
 * @note         
 */
void sdk_log_printf(const int8_t *p_format, ...);

/**
 * @brief      按16进制模式进行打印
 * @param      [in] p_name  HEX项目的名字，将在日志头部显示 当为空时，不打印名字
 * @param      [in] width   每行16进制的数据个数据，如：16 32.
 * @param      [in] p_buf   HEX数据区
 * @param      [in] size    数据总的大小
 * @return     [int32_t] 执行结果
 * @retval     =0 成功
 * @retval     <0 失败 
 * @note        此函数的默认打引级别为5，只有打印级别设置为大于5时才有输出。
 */
int32_t sdk_log_hexdump(const char *p_name, uint8_t width, uint8_t *p_buf, uint16_t size);


/** 
 * @brief        日志结束运行时调用
 * @param        [in] void
 * @note         和sdk_log_init函数成对出现
 */
void sdk_log_finish(void);


#define sdk_log_a(...)  \
    do {\
        if (sdk_log_get_level() > LOG_LVL_DISABLE)\
        {\
            sdk_log_printf("[ASSERT]");\
            sdk_log_printf(__VA_ARGS__);\
            sdk_log_printf("\r\n");\
        }\
    } while (0)\
    
    
#define sdk_log_e(...)  \
    do {\
        if (sdk_log_get_level() > LOG_LVL_ASSERT)\
        {\
            sdk_log_printf("[ERROR]");\
            sdk_log_printf(__VA_ARGS__);\
            sdk_log_printf("\r\n");\
        }\
    } while (0)\
    
#define sdk_log_w(...)  \
    do {\
        if (sdk_log_get_level() > LOG_LVL_ERROR)\
        {\
            sdk_log_printf("[WARN]");\
            sdk_log_printf(__VA_ARGS__);\
            sdk_log_printf("\r\n");\
        }\
    } while (0)\
    
#define sdk_log_i(...)  \
    do {\
        if (sdk_log_get_level() > LOG_LVL_WARN)\
        {\
            sdk_log_printf("[INFO] ");\
            sdk_log_printf(__VA_ARGS__);\
            sdk_log_printf("\r\n");\
        }\
    } while (0)\
    
#define sdk_log_d(...)  \
    do {\
        if (sdk_log_get_level() > LOG_LVL_INFO)\
        {\
            sdk_log_printf(__VA_ARGS__);\
            sdk_log_printf("\r\n");\
        }\
    } while (0)\


#endif /*__SDK_LOG_H__*/
