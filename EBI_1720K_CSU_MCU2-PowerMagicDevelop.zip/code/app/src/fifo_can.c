/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     FIFO_CAN.c
  * @brief    FIFO CAN module
  * @company  SOFARSOLAR
  * @author   ZZJ
  * @note
  * @version  V01
  * @date     2023/08/26
  */
  /*****************************************************************************/

  /******************************************************************************
  * COMPILATION OPTION
  ******************************************************************************/

  /******************************************************************************
  * INCLUDE FILE
  ******************************************************************************/
  // Include system file -------------------------------------------------------

  // Include project file ------------------------------------------------------
#include "pcs.h"
#include "fifo_can.h"
#include "sdk.h"
#include "sdk_core.h"
#include "pcsc_opt_log.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define FIFO_CAN5_CMD_NUM                                                    48
#define FIFO_CAN1_CMD_NUM                                                    16

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
pcsm_cmd_t can1_cmd[FIFO_CAN1_CMD_NUM];
fifo_can_cmd_t fifo_can1_cmd =
{
	0,                       // head
	1,                       // empty(0: not, 1: empty)
	0,                       // tail
	0,                       // full(0: not, 1: full)
	0,                       // length
	0,                       // busy(0: not, 1: busy)
	&can1_cmd[0],            // buffer pointer
	FIFO_CAN1_CMD_NUM,       // buffer size
	0,                       // max_len
	0,                       // lost_cnt
};
bool_t pause_fifo_can1_pop;

#if DEBUG_MODE
uint32_t entry_fifo[1] = {0};
uint32_t exit_fifo[1] = {0};
uint32_t duty_fifo[1] = {0};
uint32_t base_fifo[1] = {0};
uint32_t max_duty[1] = {0};
#endif

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/
/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/******************************************************************************
 * fifo_can_init().
 * Initialize can cmd FIFO. [Called by the modbus_init()]
 *
 * @param none (I)
 * @param none (O)
 * @return none
 *****************************************************************************/
void fifo_can_init(void)
{
	pause_fifo_can1_pop = FALSE;
	clear_struct_data((uint8_t *)&can1_cmd[0],  sizeof(can1_cmd));
}

/******************************************************************************
 * fifo_can_push()
 * Push a cmd to a cmd FIFO. [Called by the mods pcsm set function]
 *
 * @param *can_cmd       (I) a cmd to be pushed
 * @param *fifo_can_cmd  (O) a cmd FIFO to be pushed
 * @return TRUE(success), FALSE(failure)
 *****************************************************************************/
bool_t fifo_can_push(fifo_can_cmd_t *fifo_can_cmd, pcsm_cmd_t *can_cmd)
{
	bool_t result = FALSE;

	// NULL pointer protection
	if((!fifo_can_cmd) |
	   (!can_cmd))
	{
		return result;
	}

	// FIFO full protection
	if(fifo_can_cmd->full)
	{
		fifo_can_cmd->lost_cnt++;
		opt_log_record("fifo_can_push fail, fifo is full, lost_cnt = %d,      \
															dst_addr = %d,    \
															fun_code = %d,    \
															offset = %d",     \
									fifo_can_cmd->lost_cnt, can_cmd->dst_addr,\
									can_cmd->fun_code, can_cmd->offset);
		return result;
	}

	if(!fifo_can_cmd->busy)
	{
		// occupy sharing resources
		fifo_can_cmd->busy = TRUE;

		fifo_can_cmd->buff[fifo_can_cmd->head++] = *can_cmd;
		if(fifo_can_cmd->head >= fifo_can_cmd->size)
		{
			fifo_can_cmd->head = 0;
		}

		fifo_can_cmd->empty = FALSE;
		fifo_can_cmd->len++;
		if(fifo_can_cmd->len >= fifo_can_cmd->max_len)
		{
			fifo_can_cmd->max_len = fifo_can_cmd->len;
		}
		if(fifo_can_cmd->len >= fifo_can_cmd->size)
		{
			fifo_can_cmd->full = TRUE;
		}

		// Release sharing resources
		fifo_can_cmd->busy = FALSE;

		result = TRUE;
	}
	else
	{
		opt_log_record("fifo_can_push fail, fifo is busy,  dst_addr = %d,  \
														fun_code = %d,     \
														offset = %d",      \
														can_cmd->dst_addr, \
														can_cmd->fun_code, \
														can_cmd->offset);
	}

	return result;
}

/******************************************************************************
 * fifo_can_pop()
 * Pop a cmd from a cmd FIFO. [Called by the task()]
 *
 * @param *fifo_can_cmd (I) a mods cmd fifo to be popped
 * @param *can_cmd      (O) a cmd to be popped
 * @return TRUE(success), FALSE(failure)
 *****************************************************************************/
bool_t fifo_can_pop(fifo_can_cmd_t *fifo_can_cmd, pcsm_cmd_t *can_cmd)
{
	bool_t result = FALSE;

	// NULL pointer protection
	if((!fifo_can_cmd) |
	   (!can_cmd))
	{
		return result;
	}

	// FIFO empty protection
	if(fifo_can_cmd->empty)
	{
		return result;
	}

	if(!fifo_can_cmd->busy)
	{
		// Occupy sharing resources
		fifo_can_cmd->busy = TRUE;

		*can_cmd = fifo_can_cmd->buff[fifo_can_cmd->tail++];
		if(fifo_can_cmd->tail >= fifo_can_cmd->size)
		{
			fifo_can_cmd->tail = 0;
		}

		fifo_can_cmd->full = FALSE;
		fifo_can_cmd->len--;
		if(fifo_can_cmd->len == 0)
		{
			fifo_can_cmd->empty = TRUE;
		}

		// Release sharing resources
		fifo_can_cmd->busy = FALSE;

		result = TRUE;
	}
	else
	{
		opt_log_record("fifo_can_pop fail, fifo is busy");
	}

	return result;
}

/******************************************************************************
 * fast_task_can1_send()
 * send can1 FIFO. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void fast_task_can1_send(void)
{
	pcsm_cmd_t can_cmd_temp;
	bool_t flag;

	flag = fifo_can_pop(&fifo_can1_cmd, &can_cmd_temp);
	if(flag)
	{
		can1_cmd_pcsm(&can_cmd_temp);
	}
}

/******************************************************************************
* End of module
******************************************************************************/
