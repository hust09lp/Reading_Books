/******************************************************************************
 * FILE IDENTIFICATION
 ******************************************************************************/
/**
 * @file     calibration.c
 * @brief    Calibration functional module
 * @company  SOFARSOLAR
 * @author   WWX
 * @note
 * @version  V01
 * @date     2023/05/19
 */
/*****************************************************************************/

/******************************************************************************
 * COMPILATION OPTION
 ******************************************************************************/

/******************************************************************************
 * INCLUDE FILE
 ******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "calibration.h"
#include "common.h"
#include "sdk_core.h"
#include "setting.h"

/******************************************************************************
 * DEFINE DESCRIPTION
 ******************************************************************************/

/******************************************************************************
 * ENUM DESCRIPTION
 ******************************************************************************/

/******************************************************************************
 * STRUCTURE DESCRIPTION
 ******************************************************************************/

/******************************************************************************
 * CONSTANT DESCRIPTION
 ******************************************************************************/
const set_value_float32_t dc_gain_table[] =
{
	// address           min                 max                 default
	{EE_T_AC_FUSE_GAIN,  TEMP_GAIN * 0.8f,   TEMP_GAIN * 1.2f,   TEMP_GAIN},
	{EE_T_DC_FUS1_GAIN,  TEMP_GAIN * 0.8f,   TEMP_GAIN * 1.2f,   TEMP_GAIN},
	{EE_T_DC_FUS2_GAIN,  TEMP_GAIN * 0.8f,   TEMP_GAIN * 1.2f,   TEMP_GAIN},
};

const set_value_float32_t dc_offset_table[] =
{
	// address            min                 max                 default
	{EE_T_AC_FUSE_OFFSET, TEMP_OFFSET * 0.1f, TEMP_OFFSET * 2.0f, TEMP_OFFSET},
	{EE_T_DC_FUS1_OFFSET, TEMP_OFFSET * 0.1f, TEMP_OFFSET * 2.0f, TEMP_OFFSET},
	{EE_T_DC_FUS2_OFFSET, TEMP_OFFSET * 0.1f, TEMP_OFFSET * 2.0f, TEMP_OFFSET},
};

const set_value_float32_t ac_gain_table[] =
{
	// address         min                  max                  default
	{EE_V_PCS_RS_GAIN, AC_VOLT_GAIN * 0.8f, AC_VOLT_GAIN * 1.2f, AC_VOLT_GAIN},
	{EE_V_PCS_ST_GAIN, AC_VOLT_GAIN * 0.8f, AC_VOLT_GAIN * 1.2f, AC_VOLT_GAIN},
	{EE_V_PCS_TR_GAIN, AC_VOLT_GAIN * 0.8f, AC_VOLT_GAIN * 1.2f, AC_VOLT_GAIN},
	{EE_V_GRD_RS_GAIN, AC_VOLT_GAIN * 0.8f, AC_VOLT_GAIN * 1.2f, AC_VOLT_GAIN},
	{EE_V_GRD_ST_GAIN, AC_VOLT_GAIN * 0.8f, AC_VOLT_GAIN * 1.2f, AC_VOLT_GAIN},
	{EE_V_GRD_TR_GAIN, AC_VOLT_GAIN * 0.8f, AC_VOLT_GAIN * 1.2f, AC_VOLT_GAIN},
	{EE_I_OUT_R_GAIN,  AC_CURRENT_GAIN * 0.8f, AC_CURRENT_GAIN * 1.2f, AC_CURRENT_GAIN},
	{EE_I_OUT_S_GAIN,  AC_CURRENT_GAIN * 0.8f, AC_CURRENT_GAIN * 1.2f, AC_CURRENT_GAIN},
	{EE_I_OUT_T_GAIN,  AC_CURRENT_GAIN * 0.8f, AC_CURRENT_GAIN * 1.2f, AC_CURRENT_GAIN},
	{EE_POWER_P_GAIN,  AC_POWER_GAIN * 0.8f, AC_POWER_GAIN * 1.2f, AC_POWER_GAIN},
	{EE_POWER_Q_GAIN,  AC_POWER_GAIN * 0.8f, AC_POWER_GAIN * 1.2f, AC_POWER_GAIN},
	{EE_POWER_S_GAIN,  AC_POWER_GAIN * 0.8f, AC_POWER_GAIN * 1.2f, AC_POWER_GAIN},
};

/******************************************************************************
 * VARIABLE DESCRIPTION
 ******************************************************************************/
calibration_t calibrate;

/******************************************************************************
 * FUNCTION PROTOTYPE
 ******************************************************************************/

/******************************************************************************
 * FUNCTION DESCRIPTION
 ******************************************************************************/

/******************************************************************************
 * calibration_init().
 * Initialize calibration module. [Called by sw_init()]
 *
 * @param none (I)
 * @param none (O)
 * @return none
 *****************************************************************************/
void calibration_init(void)
{
	uint8_t index;
	float *p_data;

	memory_set(&calibrate.status.all, 0, sizeof(calibrate));

	// Read calibrate result
	setting_get(FUT_SET, EE_CALIB_RESULT, &calibrate.status.all, sizeof(uint32_t));
	if(calibrate.status.all == 0xffffffff)
	{
		calibrate.status.all = 0;
		setting_set(FUT_SET, EE_CALIB_RESULT, &calibrate.status.all, sizeof(uint32_t));
	}

	// Read dc calibrate data
	for(index = 0; index < CALI_DC_LEN; index++)
	{
		// Gain
		p_data = &calibrate.dc[index].gain;
		setting_get(FUT_SET, dc_gain_table[index].addr, p_data, sizeof(float32_t));

		if ((*p_data < dc_gain_table[index].min) || \
			(*p_data > dc_gain_table[index].max) || \
			(*((uint32_t *)p_data) == 0xffffffff))
		{
			*p_data = dc_gain_table[index].def;
			setting_set(FUT_SET, dc_gain_table[index].addr, p_data, sizeof(float32_t));
		}

		// Offset
		p_data = &calibrate.dc[index].offset;
		setting_get(FUT_SET, dc_offset_table[index].addr, p_data, sizeof(float32_t));

		if ((*p_data < dc_offset_table[index].min) || \
			(*p_data > dc_offset_table[index].max) || \
			(*((uint32_t *)p_data) == 0xffffffff))
		{
			*p_data = dc_offset_table[index].def;
			setting_set(FUT_SET, dc_offset_table[index].addr, p_data, sizeof(float32_t));
		}
	}

	// Read dc calibrate data
	for(index = 0; index < CALI_AC_LEN; index++)
	{
		p_data = &calibrate.ac[index].gain;
		setting_get(FUT_SET, ac_gain_table[index].addr, p_data, sizeof(float32_t));

		if ((*p_data < ac_gain_table[index].min) || \
			(*p_data > ac_gain_table[index].max) || \
			(*((uint32_t *)p_data) == 0xffffffff))
		{
			*p_data = ac_gain_table[index].def;
			setting_set(FUT_SET, ac_gain_table[index].addr, p_data, sizeof(float32_t));
		}
	}
}

/******************************************************************************
 * calibrate_dc().
 * Calibrate dc type ADC samples. [Called by app()]
 *
 * @param tpye (I)
 * @param none (O)
 * @return TRUE(success), FALSE(failure)
 *****************************************************************************/
bool_t calibrate_dc(cali_dc_type_e type)
{
	float32_t x1;
	float32_t x2;
	float32_t y1;
	float32_t y2;
	float32_t gain = 0.0f;
	float32_t offset = 0.0f;
	bool_t result = FALSE;
	cali_status_t *status = &calibrate.status;

	x1 = (float32_t)calibrate.dc[type].x1;
	y1 = (float32_t)calibrate.dc[type].y1;
	x2 = (float32_t)calibrate.dc[type].x2;
	y2 = (float32_t)calibrate.dc[type].y2;

	if ((x1 == x2) || \
		(y1 == y2) || \
		(x1 == 0) || \
		(x2 == 0) || \
		(y1 == 0) || \
		(y2 == 0))
	{
		status->all &= ~(uint32_t)(1 << (type));
		return FALSE;
	}

	// Temp calibrate
	// 1/Y = gain/X + offset (Y: ADC value，X: resistance value)
	if (type <= CALI_AC_FUSE_TEMP)
	{
		gain = ((x1 * x2) / (y1 * y2)) * ((y2 - y1) / (x2 - x1));
		offset = (x2 - gain * y2) / (x2 * y2);
	}

	// DC bus calibrate
	// Y = X/gain + offset (Y: ADC value, X: vin)
	if ((gain >= dc_gain_table[type].min) &&
		(gain <= dc_gain_table[type].max) &&
		(offset >= dc_offset_table[type].min) &&
		(offset <= dc_offset_table[type].max))
	{
		calibrate.dc[type].gain = gain;
		calibrate.dc[type].offset = offset;

		setting_set(FUT_SET, dc_gain_table[type].addr, &gain, sizeof(gain));
		setting_set(FUT_SET, dc_offset_table[type].addr, &offset, sizeof(offset));
		status->all |= (uint32_t)(1 << (type));
		setting_set(FUT_SET, EE_CALIB_RESULT, &calibrate.status.all, sizeof(uint32_t));
		result = TRUE;
	}
	else
	{
		status->all &= ~(uint32_t)(1 << (type));
		result = FALSE;
	}

	return result;
}

/******************************************************************************
 * calibrate_ac().
 * Calibrate ac type ADC samples. [Called by app()]
 *
 * @param tpye (I)
 * @param none (O)
 * @return TRUE(success), FALSE(failure)
 *****************************************************************************/
bool_t calibrate_ac(cali_ac_type_e type)
{
	float32_t x;
	float32_t y;
	float32_t gain = 0.0f;
	bool_t result = FALSE;
	cali_status_t *status = &calibrate.status;

	x = (float32_t)calibrate.ac[type].x;
	y = (float32_t)calibrate.ac[type].y;

	if ((x == 0) || (y == 0))
	{
		status->all &= ~(uint32_t)(1 << (type + CALI_DC_LEN));
		return FALSE;
	}

	// AC type data calibrate
	// Y = X / gain (Y: simple value, X: vin true)
	// x_show = y_simple * gain_old (x_show: after calculate, show you the result,
	//                              y_simple: simple value, no add gain)
	// y_simple = x_show / gain_old
	// gain_new = X / Y = X / y_simple = X / x_show * gain (X: vin true)
	if (type <= CALI_CURRENT_T)
	{
		gain = x / y * calibrate.ac[type].gain;
	}

	if ((gain >= ac_gain_table[type].min) &&
		(gain <= ac_gain_table[type].max))
	{
		calibrate.ac[type].gain = gain;

		setting_set(FUT_SET, ac_gain_table[type].addr, &gain, sizeof(gain));
		status->all |= (uint32_t)(1 << (type + CALI_DC_LEN));
		setting_set(FUT_SET, EE_CALIB_RESULT, &calibrate.status.all, sizeof(uint32_t));
		result = TRUE;
	}
	else
	{
		status->all &= ~(uint32_t)(1 << (type + CALI_DC_LEN));
		result = FALSE;
	}

	return result;
}

/******************************************************************************
 * End of module
 ******************************************************************************/
