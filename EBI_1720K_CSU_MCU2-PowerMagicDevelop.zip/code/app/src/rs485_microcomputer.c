/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     rs485_microcomputer.c
  * @brief    Microcompute module
  * @company  SOFARSOLAR
  * @author   ZZJ
  * @note
  * @version  V01
  * @date     2023/09/16
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "array.h"
#include "rs485_microcomputer.h"
#include "sdk.h"
#include "sdk_core.h"
#include "pcsc_diag.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
// TODOReturn difference
#define RS485_MICROCOMPUTE                                                  (1)
#define RS485_MICROCOMPUTE_SLAVE_ADDR1                                      (1)
#define RS485_MICROCOMPUTE_SLAVE_ADDR2                                      (2)

#define MICROCOMPUTE_REGISTER_ADDR_1                                    (0 * 8)
#define MICROCOMPUTE_REGISTER_ADDR_2                                    (2 * 8)
#define MICROCOMPUTE_REGISTER_ADDR_3                                    (3 * 8)
#define MICROCOMPUTE_REGISTER_ADDR_4                                    (6 * 8)
#define MICROCOMPUTE_REGISTER_ADDR_5                                    (7 * 8)
#define MICROCOMPUTE_REGISTER_ADDR_6                                   (10 * 8)

#define MODBUS_READ_SWITCH_STATUS                                        (0x02)

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
int16_t fault_microcomputer_cnt;
int16_t fault_microcomputer_ref;
uint8_t microcomputer_buff[20];
microcomputer_t microcomputer[2];
bool_t trigger_microcomputer;
rs485_settting_parm_t rs485_microcomputer_parm;

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/
/******************************************************************************
 * rs485_microcomputer_init().
 * Initialize microcomputer debug module. [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_microcomputer_init(void)
{
	rs485_microcomputer_parm.port = RS485_MICROCOMPUTE;
	rs485_microcomputer_parm.slave_addr = 1;
	rs485_microcomputer_parm.baud = MODBUS_BAUD_9600;
	rs485_microcomputer_parm.timeout = 300;
	modbus_init(rs485_microcomputer_parm);

	fault_microcomputer_cnt = 0;
	fault_microcomputer_ref = 4;
	trigger_microcomputer = array.pcsc.pcsc_ctrl.rs485_enable.bit.micro_computer;
	clear_struct_data((uint8_t*)&microcomputer_buff, sizeof(microcomputer_buff));
	clear_struct_data((uint8_t*)&microcomputer[0], sizeof(microcomputer));
}

/******************************************************************************
 * rs485_task_microcomputer()
 * microcomputer module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_task_microcomputer(void)
{
	int16_t ret;
	half_word_t register_address, register_len;
	uint8_t len = 0;
	uint8_t data[6];
	bool_t switch_end = FALSE;
	uint8_t *p_dst = (uint8_t*)&microcomputer[0];
	static uint8_t index = 0;
	static uint8_t slave_addr = RS485_MICROCOMPUTE_SLAVE_ADDR1;
	static uint8_t modbus_fun = MODBUS_READ_SWITCH_STATUS;

	switch (index)
	{
		case 0:
			register_address.all = MICROCOMPUTE_REGISTER_ADDR_1;
			register_len.all = 8;
			p_dst += index;
			index++;
			break;
		case 1:
			register_address.all = MICROCOMPUTE_REGISTER_ADDR_2;
			register_len.all = 16;
			p_dst += index;
			index += 2;
			break;
		case 3:
			register_address.all = MICROCOMPUTE_REGISTER_ADDR_4;
			register_len.all = 16;
			p_dst += index;
			index += 2;
			break;
		case 5:
			register_address.all = MICROCOMPUTE_REGISTER_ADDR_6;
			p_dst += index;
			index = 0;
			switch_end = TRUE;
			break;
		default:
			index = 0;
			p_dst += index;
			slave_addr = RS485_MICROCOMPUTE_SLAVE_ADDR1;
			modbus_fun = MODBUS_READ_SWITCH_STATUS;
			break;
	}

	data[len++] = slave_addr;
	data[len++] = modbus_fun;
	data[len++] = register_address.bytes.high;
	data[len++] = register_address.bytes.low;
	data[len++] = register_len.bytes.high;
	data[len++] = register_len.bytes.low;

	sdk_modbus_slave_set(RS485_MICROCOMPUTE, slave_addr);
	ret = sdk_modbus_write(RS485_MICROCOMPUTE, &data[0], len);
	ret = sdk_modbus_receive_confirmation(RS485_MICROCOMPUTE, &microcomputer_buff[0]);
	if(ret > 0)
	{
		fault_microcomputer_cnt = 0;
		if(slave_addr == RS485_MICROCOMPUTE_SLAVE_ADDR2)
		{
			p_dst += sizeof(microcomputer_t);
		}
		memory_copy(p_dst, &microcomputer_buff[3], microcomputer_buff[2]);
	}
	else
	{
		sdk_modbus_flush(RS485_MICROCOMPUTE);
		if(fault_microcomputer_cnt <= fault_microcomputer_ref)
		{
			fault_microcomputer_cnt++;
		}
		else
		{
			clear_struct_data((uint8_t *)&microcomputer, sizeof(microcomputer));
		}
	}

	if(switch_end == TRUE)
	{
		if(slave_addr == RS485_MICROCOMPUTE_SLAVE_ADDR1)
		{
			slave_addr = RS485_MICROCOMPUTE_SLAVE_ADDR2;
		}
		else
		{
			slave_addr = RS485_MICROCOMPUTE_SLAVE_ADDR1;
		}
		if (slave_addr == RS485_MICROCOMPUTE_SLAVE_ADDR2)
		{
			if(modbus_fun == MODBUS_READ_SWITCH_STATUS)
			{
				modbus_fun = MODBUS_READ_SWITCH_STATUS;
			}
			else
			{
				modbus_fun = MODBUS_READ_SWITCH_STATUS;
			}
		}
	}
}

/******************************************************************************
* End of module
******************************************************************************/
