/******************************************************************************
 *
 * FILE IDENTIFICATION
 * -------------------
 *
 * File Name   : fut.c
 * Description : fut functional module
 *
 * $RCSfile    : $
 * $Author     : $
 * $Date       : $
 * $Revision   : $
 *
 ******************************************************************************
 * Copyright (c) SOFAR SH 2021
 * All right reserved.
 *****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "app_dido.h"
#include "array.h"
#include "can1_bus.h"
#include "calibration.h"
#include "fut.h"
#include "iec104.h"
#include "fifo_can.h"
#include "sdk.h"
#include "sdk_core.h"
#ifdef EBI_1725K
#include "can5_bus.h"
#endif

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
fut_t fut;
bool_t fut_flag;
float32_t fut_float_array[36];
uint16_t fut_integer_array[8];

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/******************************************************************************
 * fut_init().
 * Initialized fut. [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void fut_init(void)
{
//	csu.fut = fut;
	clear_struct_data((uint8_t *)&fut, sizeof(fut_t));
	fut_flag = FALSE;
	clear_struct_data((uint8_t *)&fut_float_array[0], sizeof(fut_float_array));
	clear_struct_data((uint8_t *)&fut_integer_array[0], sizeof(fut_integer_array));
}

/******************************************************************************
 * void uart_test(void).
 * uart_test. [Called by slow fut task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void uart_test(void)
{
	static bool_t result = TRUE;
	uint8_t i;
	uint8_t len = 8;
	uint8_t buff[8];
	uint8_t temp[8] = {0x08, 0x07, 0x06, 0x05, 0x04, 0x03, 0x02, 0x01};
	uint32_t uart_id;

    clear_struct_data(&buff[0], sizeof(buff));
	for(uart_id = 0; i < 5; uart_id++)
	{
		// receive uart test cmd bytes : 00 01 02 03 04 05 06 07
		sdk_uart_read(uart_id, buff, len, 1);
		for(i = 0; i < 8; i++)
		{
			if(buff[i] != i)
			{
				result = FALSE;
			}
		}
		if(result)
		{
			// send uart test ack bytes
			sdk_uart_write(uart_id, temp, len);
		}
		else
		{
			result = TRUE;
		}
	}
}

/******************************************************************************
 * void can_test(void).
 * void can_test. [Called by slow fut task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void can_test(void)
{
	sdk_can_frame_t test_can_tx_frame;
	sdk_can_frame_t test_can1_rx_frame;
#ifdef EBI_1725K
	sdk_can_frame_t test_can5_rx_frame;
	int32_t ret;

    clear_struct_data((uint8_t *)&test_can5_rx_frame, sizeof(sdk_can_frame_t));
#endif

    clear_struct_data((uint8_t *)&test_can_tx_frame, sizeof(sdk_can_frame_t));
    clear_struct_data((uint8_t *)&test_can1_rx_frame, sizeof(sdk_can_frame_t));

	test_can_tx_frame.ide = 0;
	test_can_tx_frame.rtr = 0;
	test_can_tx_frame.len = 8;
	test_can_tx_frame.priv = 1;
	test_can_tx_frame.data[0] = 1;
	test_can_tx_frame.data[1] = 2;
	test_can_tx_frame.data[2] = 3;
	test_can_tx_frame.data[3] = 4;
	test_can_tx_frame.data[4] = 5;
	test_can_tx_frame.data[5] = 6;
	test_can_tx_frame.data[6] = 7;
	test_can_tx_frame.data[7] = 8;

	sdk_can_read(CAN1_PORT, &test_can1_rx_frame, 1, 1);
	if(test_can1_rx_frame.id == CMD_TEST_CAN1)
	{
		test_can_tx_frame.id = ACK_TEST_CAN1;
		sdk_can_write(CAN1_PORT, &test_can_tx_frame, 1);
	}
}

/******************************************************************************
 * do_test(void).
 * do_test. [Called by slow fut task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void do_test(void)
{
	sdk_dido_write(DO1_RSVD, fut.cmd.do_tst.bits.do1);
	sdk_dido_write(DO2_STS_SW_ON, fut.cmd.do_tst.bits.do2);
	sdk_dido_write(DO3_GRID_TIED_SW_QF1_ON, fut.cmd.do_tst.bits.do3);
	sdk_dido_write(DO4_GRID_TIED_SW_QF1_OFF, fut.cmd.do_tst.bits.do4);
	sdk_dido_write(DO6_STS_SW_OFF, fut.cmd.do_tst.bits.do6);

	sdk_dido_write(DO8_SELA, fut.cmd.do_tst.bits.do7);
	sdk_dido_write(DO9_SELB, fut.cmd.do_tst.bits.do8);
}

/******************************************************************************
 * calibration_test(void).
 * calibration_test. [Called by slow fut task()]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void calibration_test(void)
{
	uint8_t i = 0;

	if((fut.calib_var.input_4_cnt == NTC_SAMPLE_NUM) ||
	   (fut.calib_var.input_2_cnt == OTHER_SAMPLE_NUM))
	{
		if((fut.calib_var.test_addr >= 0x600205) && (fut.calib_var.test_addr <= 0x600208))
		{
			calibrate.dc[CALI_AC_FUSE_TEMP].x1 = fut.calib_var.meter_array[0];
			calibrate.dc[CALI_AC_FUSE_TEMP].x2 = fut.calib_var.meter_array[1];
			calibrate.dc[CALI_AC_FUSE_TEMP].y1 = fut.calib_var.sample_array[0];
			calibrate.dc[CALI_AC_FUSE_TEMP].y2 = fut.calib_var.sample_array[1];
			calibrate_dc(CALI_AC_FUSE_TEMP);
		}
		else if((fut.calib_var.test_addr >= 0x600209) && (fut.calib_var.test_addr <= 0x60020C))
		{
#ifdef EBI_1725K
			calibrate.dc[CALI_DC1_FUSE_TEMP].x1 = fut.calib_var.meter_array[0];
			calibrate.dc[CALI_DC1_FUSE_TEMP].x2 = fut.calib_var.meter_array[1];
			calibrate.dc[CALI_DC1_FUSE_TEMP].y1 = fut.calib_var.sample_array[0];
			calibrate.dc[CALI_DC1_FUSE_TEMP].y2 = fut.calib_var.sample_array[1];
			calibrate_dc(CALI_DC1_FUSE_TEMP);
#endif
		}
		else if((fut.calib_var.test_addr >= 0x60020D) && (fut.calib_var.test_addr <= 0x600210))
		{
#ifdef EBI_1725K
			calibrate.dc[CALI_DC2_FUSE_TEMP].x1 = fut.calib_var.meter_array[0];
			calibrate.dc[CALI_DC2_FUSE_TEMP].x2 = fut.calib_var.meter_array[1];
			calibrate.dc[CALI_DC2_FUSE_TEMP].y1 = fut.calib_var.sample_array[0];
			calibrate.dc[CALI_DC2_FUSE_TEMP].y2 = fut.calib_var.sample_array[1];
			calibrate_dc(CALI_DC2_FUSE_TEMP);
#endif
		}
		else if((fut.calib_var.test_addr >= 0x600211) && (fut.calib_var.test_addr <= 0x600214))
		{
#ifdef EBI_1725K
			calibrate.dc[CALI_VBUS1].x1 = fut.calib_var.meter_array[0];
			calibrate.dc[CALI_VBUS1].x2 = fut.calib_var.meter_array[1];
			calibrate.dc[CALI_VBUS1].y1 = fut.calib_var.sample_array[0];
			calibrate.dc[CALI_VBUS1].y2 = fut.calib_var.sample_array[1];
			calibrate_dc(CALI_VBUS1);
#endif
		}
		else if((fut.calib_var.test_addr >= 0x600215) && (fut.calib_var.test_addr <= 0x600218))
		{
#ifdef EBI_1725K
			calibrate.dc[CALI_VBUS2].x1 = fut.calib_var.meter_array[0];
			calibrate.dc[CALI_VBUS2].x2 = fut.calib_var.meter_array[1];
			calibrate.dc[CALI_VBUS2].y1 = fut.calib_var.sample_array[0];
			calibrate.dc[CALI_VBUS2].y2 = fut.calib_var.sample_array[1];
			calibrate_dc(CALI_VBUS2);
#endif
		}
		else if((fut.calib_var.test_addr >= 0x600219) && (fut.calib_var.test_addr <= 0x60021A))
		{
			calibrate.ac[CALI_VPCS_RS].x = fut.calib_var.series_array[0];
			calibrate.ac[CALI_VPCS_RS].y = fut.calib_var.series_array[1];
			calibrate_ac(CALI_VPCS_RS);
		}
		else if((fut.calib_var.test_addr >= 0x60021B) && (fut.calib_var.test_addr <= 0x60021C))
		{
			calibrate.ac[CALI_VPCS_ST].x = fut.calib_var.series_array[0];
			calibrate.ac[CALI_VPCS_ST].y = fut.calib_var.series_array[1];
			calibrate_ac(CALI_VPCS_ST);
		}
		else if((fut.calib_var.test_addr >= 0x60021D) && (fut.calib_var.test_addr <= 0x60021E))
		{
			calibrate.ac[CALI_VPCS_TR].x = fut.calib_var.series_array[0];
			calibrate.ac[CALI_VPCS_TR].y = fut.calib_var.series_array[1];
			calibrate_ac(CALI_VPCS_TR);
		}
		else if((fut.calib_var.test_addr >= 0x60021F )&& (fut.calib_var.test_addr <= 0x600220))
		{
			calibrate.ac[CALI_VGRID_RS].x = fut.calib_var.series_array[0];
			calibrate.ac[CALI_VGRID_RS].y = fut.calib_var.series_array[1];
			calibrate_ac(CALI_VGRID_RS);
		}
		else if((fut.calib_var.test_addr >= 0x600221) && (fut.calib_var.test_addr <= 0x600222))
		{
			calibrate.ac[CALI_VGRID_ST].x = fut.calib_var.series_array[0];
			calibrate.ac[CALI_VGRID_ST].y = fut.calib_var.series_array[1];
			calibrate_ac(CALI_VGRID_ST);
		}
		else if((fut.calib_var.test_addr >= 0x600223) && (fut.calib_var.test_addr <= 0x600224))
		{
			calibrate.ac[CALI_VGRID_TR].x = fut.calib_var.series_array[0];
			calibrate.ac[CALI_VGRID_TR].y = fut.calib_var.series_array[1];
			calibrate_ac(CALI_VGRID_TR);
		}
		else if((fut.calib_var.test_addr >= 0x600225) && (fut.calib_var.test_addr <= 0x600226))
		{
			calibrate.ac[CALI_CURRENT_R].x = fut.calib_var.series_array[0];
			calibrate.ac[CALI_CURRENT_R].y = fut.calib_var.series_array[1];
			calibrate_ac(CALI_CURRENT_R);
		}
		else if((fut.calib_var.test_addr >= 0x600227) && (fut.calib_var.test_addr <= 0x600228))
		{
			calibrate.ac[CALI_CURRENT_S].x = fut.calib_var.series_array[0];
			calibrate.ac[CALI_CURRENT_S].y = fut.calib_var.series_array[1];
			calibrate_ac(CALI_CURRENT_S);
		}
		else if((fut.calib_var.test_addr >= 0x600229) && (fut.calib_var.test_addr <= 0x60022A))
		{
			calibrate.ac[CALI_CURRENT_T].x = fut.calib_var.series_array[0];
			calibrate.ac[CALI_CURRENT_T].y = fut.calib_var.series_array[1];
			calibrate_ac(CALI_CURRENT_T);
		}
		else if((fut.calib_var.test_addr >= 0x60022B) && (fut.calib_var.test_addr <= 0x60022C))
		{
#ifdef EBI_1725K
			calibrate.ac[CALI_POWER_P].x = fut.calib_var.series_array[0];
			calibrate.ac[CALI_POWER_P].y = fut.calib_var.series_array[1];
			calibrate_ac(CALI_POWER_P);
#endif
		}
		else if((fut.calib_var.test_addr >= 0x60022D) && (fut.calib_var.test_addr <= 0x60022E))
		{
#ifdef EBI_1725K
			calibrate.ac[CALI_POWER_Q].x = fut.calib_var.series_array[0];
			calibrate.ac[CALI_POWER_Q].y = fut.calib_var.series_array[1];
			calibrate_ac(CALI_POWER_Q);
#endif
		}
		else if((fut.calib_var.test_addr >= 0x60022F) && (fut.calib_var.test_addr <= 0x600230))
		{
#ifdef EBI_1725K
			calibrate.ac[CALI_POWER_S].x = fut.calib_var.series_array[0];
			calibrate.ac[CALI_POWER_S].y = fut.calib_var.series_array[1];
			calibrate_ac(CALI_POWER_S);
#endif
		}

		for(i = 0; i < 2; i++)
		{
			fut.calib_var.meter_array[i] = 0;
			fut.calib_var.sample_array[i] = 0;
			fut.calib_var.series_array[i] = 0;
		}

		fut.calib_var.input_4_cnt = 0;
		fut.calib_var.input_2_cnt = 0;
	}
}

/******************************************************************************
 * fut_telemet_upload(void).
 * Show status and sample data for calibrate. [Called by fast_task_iec104()]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void fut_telemet_upload(void)
{
	// Calibrate status and succeed or false result
	fut_integer_array[0] = csu_data.csu_heart.working_mode;
	fut_integer_array[1] = calibrate.status.half_word[0];
	fut_integer_array[2] = calibrate.status.half_word[1];

	// Sample ADC
	fut_integer_array[3] = g_dc_signal[T_AC_FUS].adc_avg;
#ifdef EBI_1725K
	fut_integer_array[4] = g_dc_signal[T_DC_FUS1].adc_avg;
	fut_integer_array[5] = g_dc_signal[T_DC_FUS2].adc_avg;
	fut_integer_array[6] = g_dc_signal[VBUS1].adc_avg;
	fut_integer_array[7] = g_dc_signal[VBUS2].adc_avg;
#endif
	// Measure value
	fut_float_array[0] = array.pcsc.pcsc_data.var.v_out_rs;
	fut_float_array[1] = array.pcsc.pcsc_data.var.v_out_st;
	fut_float_array[2] = array.pcsc.pcsc_data.var.v_out_tr;
	fut_float_array[3] = array.pcsc.pcsc_data.var.v_grd_rs;
	fut_float_array[4] = array.pcsc.pcsc_data.var.v_grd_st;
	fut_float_array[5] = array.pcsc.pcsc_data.var.v_grd_tr;
	fut_float_array[6] = array.pcsc.pcsc_data.var.i_out_r;
	fut_float_array[7] = array.pcsc.pcsc_data.var.i_out_s;
	fut_float_array[8] = array.pcsc.pcsc_data.var.i_out_t;
	fut_float_array[9] = array.pcsc.pcsc_data.var.power_s;
	fut_float_array[10] = array.pcsc.pcsc_data.var.power_p;
	fut_float_array[11] = array.pcsc.pcsc_data.var.power_q;

	// Calibrate result value
	fut_float_array[12] = calibrate.dc[CALI_AC_FUSE_TEMP].gain;
	fut_float_array[13] = calibrate.dc[CALI_AC_FUSE_TEMP].offset;
#ifdef EBI_1725K
	fut_float_array[14] = calibrate.dc[CALI_DC1_FUSE_TEMP].gain;
	fut_float_array[15] = calibrate.dc[CALI_DC1_FUSE_TEMP].offset;
	fut_float_array[16] = calibrate.dc[CALI_DC2_FUSE_TEMP].gain;
	fut_float_array[17] = calibrate.dc[CALI_DC2_FUSE_TEMP].offset;
	fut_float_array[18] = calibrate.dc[CALI_VBUS1].gain;
	fut_float_array[19] = calibrate.dc[CALI_VBUS1].offset;
	fut_float_array[20] = calibrate.dc[CALI_VBUS2].gain;
	fut_float_array[21] = calibrate.dc[CALI_VBUS2].offset;
#endif
	fut_float_array[22] = calibrate.ac[CALI_VPCS_RS].gain;
	fut_float_array[23] = calibrate.ac[CALI_VPCS_ST].gain;
	fut_float_array[24] = calibrate.ac[CALI_VPCS_TR].gain;
	fut_float_array[25] = calibrate.ac[CALI_VGRID_RS].gain;
	fut_float_array[26] = calibrate.ac[CALI_VGRID_ST].gain;
	fut_float_array[27] = calibrate.ac[CALI_VGRID_TR].gain;
	fut_float_array[28] = calibrate.ac[CALI_CURRENT_R].gain;
	fut_float_array[29] = calibrate.ac[CALI_CURRENT_S].gain;
	fut_float_array[30] = calibrate.ac[CALI_CURRENT_T].gain;
#ifdef EBI_1725K
	fut_float_array[31] = calibrate.ac[CALI_POWER_P].gain;
	fut_float_array[32] = calibrate.ac[CALI_POWER_Q].gain;
	fut_float_array[33] = calibrate.ac[CALI_POWER_S].gain;
#endif
}

/******************************************************************************
 * slow_task_fut().
 * fut handler. [Called by slow task group.]
 * fut(Board function test)
 * @param none (I)
 * @return none
 *****************************************************************************/
void slow_task_fut(void)
{

	// if(csu_data.csu_heart.working_mode == FCT_MODE)
	// {
	// 	do_test();
	// 	can_test();
	// 	uart_test();
	// 	calibration_test();
	// }

/*
	if(csu.heart1.ctl.bit.working_mode == FCT_MODE)
	{
		// test RS422
		if(csu.fut.cmd2.bit.rs422_tst)
		{
			csu.fut.comm_test_status.bit.rs422 = rs422_test();
		}
	}*/
}

/******************************************************************************
* End of module
******************************************************************************/
