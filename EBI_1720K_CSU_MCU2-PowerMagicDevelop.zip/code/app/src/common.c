/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     common.c
  * @brief    App common functional module
  * @company  SOFARSOLAR
  * @author   HH
  * @note     
  * @version  V01
  * @date     2023/02/22
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "common.h"
#include "sdk.h"
#include "sdk_core.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/******************************************************************************
 * common_init().
 * Initialized common. [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void common_init(void)
{

}

/******************************************************************************
 * clear_struct_data().
 * clear struct data. [Called by app.]
 *
 * @param ptr (I) data buffer.
 * @param size (I) Amount of data elements.
 * @return none
 *****************************************************************************/
void clear_struct_data(uint8_t *ptr, uint32_t size)
{
	// NULL pointer protection
	if(ptr == NULL)
	{
		return;
	}

	while(size > 0)
	{
		*ptr++ = 0x00;
		size--;
	}
}

/******************************************************************************
 * fill_struct_data().
 * fill struct data. [Called by app.]
 *
 * @param ptr   (I) data buffer.
 * @param value (I) data value to fill.
 * @param size  (I) Amount of data elements.
 * @return none
 *****************************************************************************/
void fill_struct_data(uint8_t *ptr, uint8_t value, uint32_t size)
{
	// NULL pointer protection
	if(ptr == NULL)
	{
		return;
	}

	while(size > 0)
	{
		*ptr++ = value;
		size--;
	}
}

/******************************************************************************
 * memory_copy().
 * copy memory data. [Called by app.]
 *
 * @param dest (O) data buffer of destination.
 * @param src (I) data buffer of source.
 * @param num (I) number of data.
 * @return none
 *****************************************************************************/
void memory_copy(void *dest, const void *src, uint32_t num)
{
	uint32_t i;
	uint8_t *dest_temp = NULL;
	uint8_t *src_temp = NULL;

	if(!src || !dest || !num)
	{
		return;
	}

	dest_temp = (uint8_t *)dest;
	src_temp = (uint8_t *)src;

	for(i = 0; i < num; i++)
	{
		dest_temp[i] = src_temp[i];
	}
}

/******************************************************************************
 * memory_copy().
 * copy memory data. [Called by app.]
 *
 * @param dest (O) data buffer of destination.
 * @param data (I) data what you what.
 * @param num (I) number you want to set.
 * @return none
 *****************************************************************************/
void memory_set(void *dest, uint8_t data, uint32_t num)
{
	uint32_t i;
	uint8_t *dest_temp = NULL;

	if(!dest || !num)
	{
		return;
	}

	dest_temp = (uint8_t *)dest;

	for(i = 0; i < num; i++)
	{
		dest_temp[i] = data;
	}
}

/******************************************************************************
 * check_uint16_validity().
 * check data range low to high . [Called by app.]
 *
 * @param data (I) data.
 * @param low (I) low value.
 * @param high (I) high value.
 * @param result (I) TRUE(valid), FALSE(invalid)
 *****************************************************************************/
inline void check_uint16_validity(uint16_t data, uint16_t low, uint16_t high, bool_t *result)
{
	if ((data >= low) && (data <= high))
	{
		*result = TRUE;
	}
	else
	{
		*result = FALSE;
	}
}

/******************************************************************************
 * check_int16_validity().
 * check data range low to high . [Called by app.]
 *
 * @param data (I) data.
 * @param low (I) low value.
 * @param high (I) high value.
 * @param result (I) TRUE(valid), FALSE(invalid)
 *****************************************************************************/
inline void check_int16_validity(int16_t data, int16_t low, int16_t high, bool_t *result)
{
	if ((data >= low) && (data <= high))
	{
		*result = TRUE;
	}
	else
	{
		*result = FALSE;
	}
}

/******************************************************************************
 * check_uint8_validity().
 * check data range low to high . [Called by app.]
 *
 * @param data (I) data.
 * @param low (I) low value.
 * @param high (I) high value.
 * @param result (I) TRUE(valid), FALSE(invalid)
 *****************************************************************************/
inline void check_uint8_validity(uint8_t data, uint8_t low, uint8_t high, bool_t *result)
{
	if ((data >= low) && (data <= high))
	{
		*result = TRUE;
	}
	else
	{
		*result = FALSE;
	}
}

/******************************************************************************
 * constrain_float_data().
 * constrain data range low to high . [Called by app.]
 *
 * @param data (I) data.
 * @param low (I) low value.
 * @param high (I) high value.
 * @return none
 *****************************************************************************/
void constrain_float_data(float32_t *data, float32_t low, float32_t high)
{
	// NULL pointer protection
	if(data == NULL)
	{
		return;
	}

	if(*data < low)
	{
		*data = low;
	}
	else if(*data > high)
	{
		*data = high;
	}
}

/******************************************************************************
 * constrain_uint16_t_data().
 * constrain data range low to high . [Called by app.]
 *
 * @param data (I) data.
 * @param low (I) low value.
 * @param high (I) high value.
 * @return none
 *****************************************************************************/
void constrain_uint16_t_data(uint16_t *data, uint16_t low, uint16_t high)
{
	// NULL pointer protection
	if(data == NULL)
	{
		return;
	}

	if(*data < low)
	{
		*data = low;
	}
	else if(*data > high)
	{
		*data = high;
	}
}

/******************************************************************************
 * constrain_int16_t_data().
 * constrain data range low to high . [Called by app.]
 *
 * @param data (I) data.
 * @param low  (I) low value.
 * @param high (I) high value.
 * @return TRUE(data在范围外) or FALSE(data在范围内)
 *****************************************************************************/
bool_t constrain_int16_t_data(int16_t *data, int16_t low, int16_t high)
{
	bool_t ret = FALSE;
	// NULL pointer protection
	if(data == NULL)
	{
		return ret;
	}

	if(*data < low)
	{
		ret = TRUE;
		*data = low;
	}
	else if(*data > high)
	{
		ret = TRUE;
		*data = high;
	}

	return ret;
}

/******************************************************************************
 * constrain_uint32_t_data().
 * constrain data range low to high . [Called by app.]
 *
 * @param data (I) data.
 * @param low (I) low value.
 * @param high (I) high value.
 * @return none
 *****************************************************************************/
void constrain_uint32_t_data(uint32_t *data, uint32_t low, uint32_t high)
{
	// NULL pointer protection
	if(data == NULL)
	{
		return;
	}

	if(*data < low)
	{
		*data = low;
	}
	else if(*data > high)
	{
		*data = high;
	}
}

/******************************************************************************
 * constrain_float32_t_data().
 * constrain data range low to high . [Called by app.]
 *
 * @param data (I) data.
 * @param low (I) low value.
 * @param high (I) high value.
 * @return none
 *****************************************************************************/
void constrain_float32_t_data(float32_t *data, float32_t low, float32_t high)
{
	// NULL pointer protection
	if(data == NULL)
	{
		return;
	}

	if(*data < low)
	{
		*data = low;
	}
	else if(*data > high)
	{
		*data = high;
	}
}

/******************************************************************************
 * bcd_to_hex().
 * bcd to hex. [Called by app.]
 *
 * @param bcd (I) input data.
 * @param hex (I) output data.
 * @return none
 *****************************************************************************/
void bcd_to_hex(uint8_t *bcd, uint8_t *hex)
{
	// NULL pointer protection
	if((!bcd) |
	   (!hex))
	{
		return;
	}

	*hex = ((*bcd >> 4) * 10) + (*bcd & 0x0F);
}

/******************************************************************************
 * hex_to_bcd().
 * hex to bcd. [Called by app.]
 *
 * @param bcd (I) input data.
 * @param hex (I) output data.
 * @return none
 *****************************************************************************/
void hex_to_bcd(uint8_t *bcd, uint8_t *hex)
{
	// NULL pointer protection
	if((!bcd) |
	   (!hex))
	{
		return;
	}

	*bcd = ((*hex / 10) <<4) + (*hex % 10);
}

/******************************************************************************
 * hysteresis_process().
 * hysteresis mode. [Called by app.]
 *
 * @param bcd (I) input data.
 * @param hex (I) output data.
 * @return none
 *****************************************************************************/
void hysteresis_process(hysteresis_t *hysteresis)
{
	// NULL pointer protection
	if(!hysteresis)
	{
		return;
	}

	if(*hysteresis->input >= hysteresis->high_limit)
	{
		*hysteresis->mode = 0x01;
	}
	else
	{
		if(*hysteresis->input <= hysteresis->low_limit)
		{
			*hysteresis->mode = 0x00;
		}
	}

	if(*hysteresis->mode)
	{
		*hysteresis->output = *hysteresis->output_high;
	}
	else
	{
		*hysteresis->output = *hysteresis->output_low;
	}
}

/******************************************************************************
 * uint32_to_float().
 * uint32_to_float. [Called by app.]
 *
 * @param bcd (I) input data.
 * @param hex (I) output data.
 * @return none
 *****************************************************************************/
float32_t uint32_to_float(uint16_t value1, uint16_t value2)
{
	float_union packet;

	packet.uint8[3] = (uint8_t)((value1 >> 8) & 0xFF);
	packet.uint8[2] = (uint8_t)((value1) & 0xFF);
	packet.uint8[1] = (uint8_t)((value2 >> 8) & 0xFF);
	packet.uint8[0] = (uint8_t)((value2) & 0xFF);

	return packet.float_value;
}

/******************************************************************************
 * uint32_to_float().
 * uint32_to_float. [Called by app.]
 *
 * @param bcd (I) input data.
 * @param hex (I) output data.
 * @return none
 *****************************************************************************/
float32_t uint32_to_float_2(uint8_t* value)
{
	float_union packet;

	packet.uint8[3] = value[0];
	packet.uint8[2] = value[1];
	packet.uint8[1] = value[2];
	packet.uint8[0] = value[3];

	return packet.float_value;
}

/******************************************************************************
 * min().
 * Computed minimum. [Called by.]
 *
 * @param value1 (I).
 * @param value2 (I).
 * @return minimum
 *****************************************************************************/
int32_t min(int32_t value1, int32_t value2)
{
	if(value1 > value2)
	{
		return value2;
	}
	else
	{
		return value1;
	}
}

/******************************************************************************
 * min_three_argu().
 * Computed minimum. [Called by.]
 *
 * @param value1 (I).
 * @param value2 (I).
 * @return minimum
 *****************************************************************************/
int32_t min_three_argu(int32_t value1, int32_t value2, int32_t value3)
{
	int32_t result = 0;

	if(value1 >= value2)
	{
		if (value2 >= value3)
		{
			result = value3;
		}
		else
		{
			result = value2;
		}
	}
	else if(value1 >= value3)
	{
		result = value3;
	}
	else
	{
		result = value1;
	}

	return result;
}

/******************************************************************************
 * max().
 * Calculate maximum. [Called by.]
 *
 * @param value1 (I).
 * @param value2 (I).
 * @return maximum
 *****************************************************************************/
int32_t max(int32_t value1, int32_t value2)
{
	if(value1 > value2)
	{
		return value1;
	}
	else
	{
		return value2;
	}
}

/******************************************************************************
 * absolute().
 * Calculate absolute. [Called by.]
 *
 * @param value1 (I).
 * @param value2 (I).
 * @return absolute
 *****************************************************************************/
float32_t absolute(float32_t value)
{
	if(value > 0.0f)
	{
		return value;
	}
	else
	{
		return -value;
	}
}

/******************************************************************************
 * abs_int2uint().
 * Calculate absolute. [Called by.]
 *
 * @param value (I).
 * @return absolute
 *****************************************************************************/
uint32_t abs_int2uint(int32_t value)
{
	uint32_t tmp;

	if(value >= 0)
	{
		tmp = (uint32_t)value;
	}
	else
	{
		tmp = (uint32_t)(-value);
	}

	return tmp;
}

/******************************************************************************
 * big2small_uint16().
 * Switch big-endian to small-endian of n uint16 type data. [Called by app.]
 *
 * @param buff (I).
 * @param len (I).
 * @return none
 *****************************************************************************/
void big2small_uint16(uint8_t *buff, uint8_t len)
{
	half_word_t tmp;
	uint8_t i;

	for(i = 0; i < len; i += 2)
	{
		tmp.bytes.high = buff[i];
		tmp.bytes.low = buff[i + 1];
		buff[i] = tmp.bytes.low;
		buff[i + 1] = tmp.bytes.high;
	}
}

/******************************************************************************
 * symbol_judgment_int16().
 * symbol judgment. [Called by app.]
 *
 * @param data (I).
 * @return 1(Postitive),-1(Negative)
 *****************************************************************************/
int8_t symbol_judgment_int16(int16_t data)
{
	if(data >= 0)
	{
		return 1;
	}
	else
	{
		return -1;
	}
}

/******************************************************************************
 * word_2_byte().
 * symbol judgment. [Called by app.]
 *
 * @param data (I).
 * @return TRUE(Postitive),FALSE(Negative)
 *****************************************************************************/
void word_2_byte(uint32_t source, uint8_t *dest, uint8_t *index)
{
	word_t tmp;
	tmp.all = source;
	dest[(*index)++] = tmp.byte[3];
	dest[(*index)++] = tmp.byte[2];
	dest[(*index)++] = tmp.byte[1];
	dest[(*index)++] = tmp.byte[0];
}

/******************************************************************************
 * byte_2_word().
 * symbol judgment. [Called by app.]
 *
 * @param data (I).
 * @return TRUE(Postitive),FALSE(Negative)
 *****************************************************************************/
void byte_2_word(uint32_t *dest, uint8_t *source, uint8_t *index)
{
	word_t tmp;

	tmp.byte[3]  = source[(*index)++];
	tmp.byte[2]  = source[(*index)++];
	tmp.byte[1]  = source[(*index)++];
	tmp.byte[0]  = source[(*index)++];
	*dest = tmp.all;
}
/******************************************************************************
 * byte_2_halfword().
 * symbol judgment. [Called by app.]
 *
 * @param data (I).
 * @return TRUE(Postitive),FALSE(Negative)
 *****************************************************************************/
void byte_2_halfword(uint16_t *dest, uint8_t *source, uint8_t *index)
{
	half_word_t tmp;

	tmp.bytes.high  = source[(*index)++];
	tmp.bytes.low  = source[(*index)++];
	*dest = tmp.all;
}
/******************************************************************************
 * halfword_2_byte().
 * symbol judgment. [Called by app.]
 *
 * @param data (I).
 * @return TRUE(Postitive),FALSE(Negative)
 *****************************************************************************/
void halfword_2_byte(uint16_t source, uint8_t *dest, uint8_t *index)
{
	half_word_t tmp;

	tmp.all = source;
	dest[(*index)++] = tmp.bytes.high;
	dest[(*index)++] = tmp.bytes.low;
}
/******************************************************************************
 * calc_vector_modulus().
 * symbol judgment. [Called by app.]
 *
 * @param data (I).
 * @return TRUE(Postitive),FALSE(Negative)
 *****************************************************************************/
float32_t calc_vector_modulus(float32_t value1, float32_t value2)
{
	float32_t ret;

	ret = sqrt((value1 * value1) + (value2 * value2));

	return ret;
}
/******************************************************************************
* End of module
******************************************************************************/
