/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     app_thread.c
  * @brief    App thread management module
  * @company  SOFARSOLAR
  * @author   HH
  * @note
  * @version  V01
  * @date     2023/02/19
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "app_thread.h"
#include "modbus_tcp.h"
#include "sci_mcu1.h"
#include "sdk.h"
#include "sdk_core.h"
#include "task_manage.h"
#include "power_manage.h"
#include "can1_bus.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
uint32_t max_thread_duty[5];
uint32_t thread_can_rev_stack[256];
uint32_t thread_10ms_stack[1024];
uint32_t thread_100ms_stack[512];
uint32_t thread_sci_stack[512];
uint32_t thread_modbus_tcp_stack[512];
uint32_t thread_rs485_stack[384];
uint32_t thread_bkgd_stack[1024];
uint32_t thread_power_control_stack[384];

sdk_os_thread_attr_tab_t thread_can_rev_attr =
{
	.thread_attr =
	{
		(const int8_t *)"can_rev",        // thread name
		0,                                // attribute bits
		NULL,                             // memory for control block
		0,                                // size of provided memory for control block
		10,                               // tick(?)
		(void *)&thread_can_rev_stack[0], // stack addr
		sizeof(thread_can_rev_stack),     // stack size
		OS_APP_PRIORITY_1,                // priority
		0                                 // reserved(must be 0)
	},
	.func = thread_can1_parse,
	.thread_id = NULL
};

sdk_os_thread_attr_tab_t thread_10ms_attr =
{
	.thread_attr =
	{
		(const int8_t *)"thread_10ms",    // thread name
		0,                                // attribute bits
		NULL,                             // memory for control block
		0,                                // size of provided memory for control block
		10,                               // tick(?)
		(void *)&thread_10ms_stack[0],    // stack addr
		sizeof(thread_10ms_stack),        // stack size
		OS_APP_PRIORITY_1,                // priority
		0                                 // reserved(must be 0)
	},
	.func = thread_10ms,
	.thread_id = NULL
};

sdk_os_thread_attr_tab_t thread_power_control_attr =
{
	.thread_attr =
	{
		(const int8_t *)"power_control_attr",       // thread name
		0,                                          // attribute bits
		NULL,                                       // memory for control block
		0,                                          // size of provided memory for control block
		10,                                         // tick(?)
		(void *)&thread_power_control_stack[0],     // stack addr
		sizeof(thread_power_control_stack),         // stack size
		OS_APP_PRIORITY_1,                          // priority
		0                                           // reserved(must be 0)
	},
	.func = thread_power_control,
	.thread_id = NULL
};

sdk_os_thread_attr_tab_t thread_100ms_attr =
{
	.thread_attr =
	{
		(const int8_t *)"thread_100ms",   // thread name
		0,                                // attribute bits
		NULL,                             // memory for control block
		0,                                // size of provided memory for control block
		10,                               // tick(?)
		(void *)&thread_100ms_stack[0],   // stack addr
		sizeof(thread_100ms_stack),       // stack size
		OS_APP_PRIORITY_2,                // priority
		0                                 // reserved(must be 0)
	},
	.func = thread_100ms,
	.thread_id = NULL
};

sdk_os_thread_attr_tab_t thread_sci_mcu1_attr =
{
	.thread_attr =
	{
		(const int8_t *)"sci_mcu1",       // thread name
		0,                                // attribute bits
		NULL,                             // memory for control block
		0,                                // size of provided memory for control block
		10,                               // tick(?)
		(void *)&thread_sci_stack[0],     // stack addr
		sizeof(thread_sci_stack),         // stack size
		OS_APP_PRIORITY_2,                // priority
		0                                 // reserved(must be 0)
	},
	.func = thread_sci_mcu1,
	.thread_id = NULL
};

sdk_os_thread_attr_tab_t thread_modbus_tcp_attr =
{
	.thread_attr =
	{
		(const int8_t *)"modbus_tcp",        // thread name
		0,                                   // attribute bits
		NULL,                                // memory for control block
		0,                                   // size of provided memory for control block
		10,                                  // tick(?)
		(void *)&thread_modbus_tcp_stack[0], // stack addr
		sizeof(thread_modbus_tcp_stack),     // stack size
		OS_APP_PRIORITY_2,                   // priority
		0                                    // reserved(must be 0)
	},
	.func = thread_modbus_tcp_parse,
	.thread_id = NULL
};

sdk_os_thread_attr_tab_t thread_485_attr =
{
	.thread_attr =
	{
		(const int8_t *)"thread_rs485",    // thread name
		0,                                // attribute bits
		NULL,                             // memory for control block
		0,                                // size of provided memory for control block
		10,                               // tick(?)
		(void *)&thread_rs485_stack[0],    // stack addr
		sizeof(thread_rs485_stack),        // stack size
		OS_APP_PRIORITY_3,                // priority
		0                                 // reserved(must be 0)
	},
	.func = thread_rs485,
	.thread_id = NULL
};

sdk_os_thread_attr_tab_t thread_bkgd_attr =
{
	.thread_attr =
	{
		(const int8_t *)"thread_bkgd",    // thread name
		0,                                // attribute bits
		NULL,                             // memory for control block
		0,                                // size of provided memory for control block
		10,                               // tick(?)
		(void *)&thread_bkgd_stack[0],    // stack addr
		sizeof(thread_bkgd_stack),        // stack size
		OS_APP_PRIORITY_4,                // priority
		0                                 // reserved(must be 0)
	},
	.func = thread_bkgd,
	.thread_id = NULL
};

sdk_os_thread_attr_tab_t *thread_array[] =
{
	&thread_can_rev_attr,
	&thread_10ms_attr,
	&thread_power_control_attr,
	&thread_100ms_attr,
	&thread_sci_mcu1_attr,
	&thread_modbus_tcp_attr,
	&thread_485_attr,
	&thread_bkgd_attr,
	NULL
};

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/******************************************************************************
 * app_thread_init().
 * Initialize app thread module. [Called by sw_init()]
 *
 * @param  none (I)
 * @param  none (O)
 * @return 0(SUCESS), -1(FAILURE)
 *****************************************************************************/
int8_t app_thread_init(void)
{
	uint8_t i = 0;
	int8_t  result = 0;

	while((thread_array[i] != NULL) && (SF_OK == result))
	{
		result = sdk_os_thread_new(1, thread_array[i++]);
	}
	if(result == 0)
	{
		clear_struct_data((uint8_t *)&max_thread_duty[0], sizeof(max_thread_duty));
	}

	return result;
}

/******************************************************************************
 * thread_10ms().
 * 10ms fast tasks group management. [Called by OS()]
 *
 * @param *argument (I)
 * @param  none     (O)
 * @return none
 *****************************************************************************/
void thread_10ms(void *argument)
{
	uint32_t entry = 0;
	uint32_t exit  = 0;
	uint32_t duty  = 0;

	while(1)
	{
		entry = sdk_tick_get();
		task_scheduler(&fast_group);
		exit = sdk_tick_get();

		if(exit >= entry)
		{
			duty = exit - entry;
		}
		else
		{
			duty = 0xFFFFFFFF - (entry - exit);
		}

		if(max_thread_duty[0] < duty)
		{
			max_thread_duty[0] = duty;
		}
		if(duty <= 10)
		{
			sdk_delay_ms(10 - duty);
		}
	}
}

/******************************************************************************
 * thread_100ms().
 * 100ms slow tasks group management. [Called by OS()]
 *
 * @param *argument (I)
 * @param  none     (O)
 * @return none
 *****************************************************************************/
void thread_100ms(void *argument)
{
	uint32_t entry = 0;
	uint32_t exit  = 0;
	uint32_t duty  = 0;

	while(1)
	{
		entry = sdk_tick_get();
		task_scheduler(&slow_group);
		exit = sdk_tick_get();

		if(exit >= entry)
		{
			duty = exit - entry;
		}
		else
		{
			duty = 0xFFFFFFFF - (entry - exit);
		}

		if(duty > max_thread_duty[1])
		{
			max_thread_duty[1] = duty;
		}

		if(duty <= 100)
		{
			sdk_delay_ms(100 - duty);
		}
	}
}

/******************************************************************************
 * thread_485().
 * rs485 tasks group management. [Called by OS()]
 *
 * @param *argument (I)
 * @param  none     (O)
 * @return none
 *****************************************************************************/
void thread_rs485(void *argument)
{
	uint32_t entry = 0;
	uint32_t exit  = 0;
	uint32_t duty  = 0;

	while(1)
	{
		entry = sdk_tick_get();
		task_scheduler(&rs485_group);
		exit = sdk_tick_get();

		if(exit >= entry)
		{
			duty = exit - entry;
		}
		else
		{
			duty = 0xFFFFFFFF - (entry - exit);
		}
		if(duty > max_thread_duty[2])
		{
			max_thread_duty[2] = duty;
		}
		sdk_delay_ms(15);
	}
}

/******************************************************************************
 * thread_bkgd().
 * background tasks group management. [Called by OS()]
 *
 * @param *argument (I)
 * @param  none     (O)
 * @return none
 *****************************************************************************/
void thread_bkgd(void *argument)
{
	uint32_t entry = 0;
	uint32_t exit  = 0;
	uint32_t duty  = 0;

	while(1)
	{
		entry = sdk_tick_get();
		task_scheduler(&bkgd_group);
		exit = sdk_tick_get();

		if(exit >= entry)
		{
			duty = exit - entry;
		}
		else
		{
			duty = 0xFFFFFFFF - (entry - exit);
		}
		if(duty > max_thread_duty[3])
		{
			max_thread_duty[3] = duty;
		}
		if(duty < 500)
		{
			sdk_delay_ms(500 - duty);
		}
	}
}

/******************************************************************************
* End of module
******************************************************************************/
