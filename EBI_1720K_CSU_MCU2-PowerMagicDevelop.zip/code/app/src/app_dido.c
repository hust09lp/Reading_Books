/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     app_dido.c
  * @brief    App DI&DO management module
  * @company  SOFARSOLAR
  * @author   HH
  * @note
  * @version  V01
  * @date     2023/03/09
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "app_dido.h"
#include "array.h"
#include "csu_data.h"
#include "pcsc_diag.h"
#include "sdk.h"
#include "sdk_core.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define     LOW_VOLTAGE                                                     (0)
#define     HIGH_VOLTAGE                                                    (1)

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
bool_t grid_tied_sw_on_cmd;
bool_t grid_tied_sw_off_cmd;
bool_t sts_sw_on_cmd;
bool_t sts_sw_off_cmd;
uint16_t *di_mask[SYS_STATE_WORD_NUM];

bool_t trigger_di;
bool_t trigger_do;
uint16_t *pwm_enable = NULL;

static sdk_pwm_config_t pwm_config = {50, 162, SDK_PWM_POLARITY_LOW};
static uint8_t grid_sw_on_cnt = 0;
static uint8_t grid_sw_off_cnt = 0;

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/******************************************************************************
 * app_dido_init().
 * Initialize app dido module. [Called by sw_init()]
 *
 * @param  none (I)
 * @param  none (O)
 * @return none
 *****************************************************************************/
void app_dido_init(void)
{
	grid_tied_sw_on_cmd  = FALSE;
	grid_tied_sw_off_cmd = FALSE;
	sts_sw_on_cmd  = FALSE;
	sts_sw_off_cmd = FALSE;
	trigger_di = FALSE;
	trigger_do = FALSE;

}

/******************************************************************************
 * pwm_init().
 * Initialize app dido module. [Called by sw_init()]
 *
 * @param  none (I)
 * @param  none (O)
 * @return none
 *****************************************************************************/
void pwm_init(void)
{
	int32_t ret;

	// init
	ret = sdk_pwm_init();
	if(ret == SF_OK)
	{
		// open
		ret = sdk_pwm_open(SDK_PWM_0);
		if(ret == SF_OK)
		{
			// config
			ret = sdk_pwm_config(SDK_PWM_0, &pwm_config);
			if(ret == SF_OK)
			{
				// start
				ret = sdk_pwm_stop(SDK_PWM_0);
				if(ret == SF_OK)
				{
					sdk_log_d("Pwm stop!\r\n");
				}
				else
				{
					sdk_log_d("Pwm stop err!\r\n");
					//	TODO log start err
				}
			}
			else
			{
				sdk_log_d("Pwm configs err!\r\n");
				//	TODO log config err
			}
		}
		else
		{
			sdk_log_d("Pwm opens err!\r\n");
			//	TODO log open err
		}
	}
	else
	{
		sdk_log_d("Pwm inits err!\r\n");
		//	TODO log init fail
	}

//	pwm_enable = &array.pcsc.pcsc_ctrl.pwm_enable;
//	*pwm_enable = ENABLE;
}

/******************************************************************************
 * slow_task_pwm_ctrl().
 * Digital inputs detection. [Called by OS()]
 *
 * @param  none  (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void slow_task_pwm_ctrl(void)
{
	int32_t ret;
	static uint8_t pwm_status = DISABLE;

	if(pwm_status != array.pcsc.pcsc_ctrl.sync_signal_enable)
	{
		if(array.pcsc.pcsc_ctrl.sync_signal_enable == ENABLE)
		{
			ret = sdk_pwm_start(SDK_PWM_0);
		}
		else
		{
			ret = sdk_pwm_stop(SDK_PWM_0);
		}
		if(ret == SF_OK)
		{
			pwm_status = array.pcsc.pcsc_ctrl.sync_signal_enable;
			sdk_log_d("slow_task_pwm_ctrl succ!\r\n");
		}
		else
		{
			sdk_log_d("slow_task_pwm_ctrl err!\r\n");
		}
	}
}
/******************************************************************************
 * slow_task_di().
 * Digital inputs detection. [Called by OS()]
 *
 * @param  none  (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void slow_task_di(void)
{
	temp_state_t state;

	state.all = array.pcsc.pcsc_data.state.state1.all;
	if(product_info.model_num == POWER_MAGIC_400V)
	{
		state.bit.dido_2  = !sdk_dido_read(DI1_WATER_IN);
		state.bit.dido_3  = !sdk_dido_read(DI2_DOOR);
		state.bit.dido_4  = sdk_dido_read(DI3_STS_SW_ON);
		state.bit.dido_5  = !sdk_dido_read(DI4_STS_SW_OFF);
		state.bit.dido_6  = !sdk_dido_read(DI5_QF3_STATUS);
		state.bit.dido_7  = sdk_dido_read(DI6_SPD1_STATUS);
		state.bit.dido_8  = !sdk_dido_read(DI7_AC_SPD);
		state.bit.dido_9  = sdk_dido_read(DI8_SPD2_STATUS);
		state.bit.dido_12 = !sdk_dido_read(DI11_FAN1_STATUS);
		state.bit.dido_13 = !sdk_dido_read(DI12_FAN2_STATUS);
	}
	else if(product_info.model_num == POWER_MAGIC_690V)
	{
		state.bit.dido_10 = !sdk_dido_read(DI9_GRID_TIED_SW_ON_QF1);  // GRID_TIED_SW_ON
		state.bit.dido_11 = sdk_dido_read(DI10_GRID_TIED_SW_OFF_QF2); // GRID_TIED_SW_OFF
		state.bit.dido_14 = sdk_dido_read(DI13_ISO_DEVICE_FAULT);
		state.bit.dido_15 = !sdk_dido_read(DI14_ISO_FAULT);
	}

	state.bit.dido_16 = sdk_dido_read(DI15_CMU_FAULT);
	state.all &= *di_mask[SYS_STATE_WORD_1];
	array.pcsc.pcsc_data.state.state1.all = state.all;

	state.all = array.pcsc.pcsc_data.state.state2.all;
	state.bit.dido_1  = sdk_dido_read(DI16_REMOTE_EPO);
	if(product_info.model_num == POWER_MAGIC_400V)
	{
		state.bit.dido_2 = !sdk_dido_read(DI9_GRID_TIED_SW_ON_QF1);   // QF1
		state.bit.dido_3 = !sdk_dido_read(DI10_GRID_TIED_SW_OFF_QF2); // QF2
		if(ONLY_COMBINER_CABINET == array.pcsc.pcsc_ctrl.scenario_setting)
		{
			state.bit.dido_4  = !sdk_dido_read(DI_QA0);
			state.bit.dido_5  = !sdk_dido_read(DI_QA1);
			state.bit.dido_6  = !sdk_dido_read(DI_QA2);
			state.bit.dido_7  = !sdk_dido_read(DI_QA3);
			state.bit.dido_8  = !sdk_dido_read(DI_QA4);
			state.bit.dido_9  = !sdk_dido_read(DI_QA5);
			state.bit.dido_10 = !sdk_dido_read(DI_QA6);
			state.bit.dido_11 = array.pcsc.pcsc_ctrl.cmd.bit.fan_ctrl; // fan ctrl
		}
	}
	state.all &= *di_mask[SYS_STATE_WORD_2];
	array.pcsc.pcsc_data.state.state2.all = state.all;

}

/******************************************************************************
 * slow_task_dO().
 * Digital outputs control. [Called by OS()]
 *
 * @param  none  (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void slow_task_do(void)
{
//	static uint8_t pwm_en_cnt = 0;
	pcsc_do_ctrl_t *do_ctrl;
	uint8_t do_grid_tied_sw_on;
	uint8_t do_grid_tied_sw_off;
	uint16_t working_mode;

	do_ctrl = &array.pcsc.pcsc_ctrl.do_ctrl;
	do_grid_tied_sw_on  = do_ctrl->bit.grid_tied_sw_qf1_on;
	do_grid_tied_sw_off = do_ctrl->bit.grid_tied_sw_qf1_off;
	working_mode = csu_data.csu_heart.working_mode;

	if (working_mode == NORMAL_MODE)
	{
		// ac on impulse
		if(do_grid_tied_sw_on)
		{
			sdk_dido_write(DO3_GRID_TIED_SW_QF1_ON, HIGH_VOLTAGE);
			do_ctrl->bit.grid_tied_sw_qf1_on = LOW_VOLTAGE;
			grid_tied_sw_on_cmd = TRUE;
			grid_tied_sw_off_cmd = FALSE;
			grid_sw_on_cnt = 0;
		}
		else
		{
			if(grid_sw_on_cnt >= 2)
			{
				sdk_dido_write(DO3_GRID_TIED_SW_QF1_ON, LOW_VOLTAGE);
				grid_sw_on_cnt = 0;
			}
			else
			{
				grid_sw_on_cnt++;
			}
		}

		// ac off impulse
		if(do_grid_tied_sw_off)
		{
			sdk_dido_write(DO4_GRID_TIED_SW_QF1_OFF, HIGH_VOLTAGE);
			do_ctrl->bit.grid_tied_sw_qf1_off = LOW_VOLTAGE;
			grid_tied_sw_on_cmd = FALSE;
			grid_tied_sw_off_cmd = TRUE;
			grid_sw_off_cnt = 0;
		}
		else
		{
			if(grid_sw_off_cnt >= 2)
			{
				sdk_dido_write(DO4_GRID_TIED_SW_QF1_OFF, LOW_VOLTAGE);
				grid_sw_off_cnt = 0;
			}
			else
			{
				grid_sw_off_cnt++;
			}
		}
	}

	sdk_dido_write(DO2_STS_SW_ON, do_ctrl->bit.sts_switch_on);
	sdk_dido_write(DO6_STS_SW_OFF, do_ctrl->bit.sts_switch_off);
	sts_sw_on_cmd = do_ctrl->bit.sts_switch_on;
	sts_sw_off_cmd = do_ctrl->bit.sts_switch_off;
}

/******************************************************************************
* End of module
******************************************************************************/
