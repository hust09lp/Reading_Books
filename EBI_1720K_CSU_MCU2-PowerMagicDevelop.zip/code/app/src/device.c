/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     device.c
  * @brief    device module
  * @company  SOFARSOLAR
  * @author   WWX
  * @note
  * @version  V02
  * @date     2023/05/03
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------
#include <stdio.h>
#include <string.h>
#include <stdint.h>

// Include project file ------------------------------------------------------
#include "array.h"
#include "csu_data.h"
#include "device.h"
#include "pcs.h"
#include "sdk.h"
#include "sdk_core.h"
#include "pcsc_diag.h"
#include "pcsc_opt_log.h"
#include "rtc.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define REFRESH_PCSM_PERIOD                                                  35
#define PCSM_HEART_GET_REF                                                    3
#define PCSM_HEART_LOST_REF                                                  35

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/

// sum device number
list_node_t list_sum_device[DEVICE_COUNT];
uint32_t heart_check_cnt[PCS_COUNT];
sdk_rtc_t last_check_time;
bool_t trigger_heart_check;
uint16_t trigger_heart_check_count;
float32_t heart_check_period;
float32_t heart_check_threshold;
// PCS
__attribute__((section (".DATA"))) device_heart_t heart_pcs[PCS_COUNT];
link_list_t list_pcs;
device_t device_pcs =
{
	DEVICE_PCS,                     			 		 // device type
	PCS_COUNT,                      			 		 // device count
	heart_pcs,                      			 		 // device heart
	&list_pcs,                      			 		 // device list
	&array.pcsc.pcsc_data.pcsm_data[0],				     // device data
	sizeof(pcsm_data_t),                  			     // device data size
	&array.array_data.variable.pcsm_total,  	 		 // device total number
	&array.array_data.variable.pcsm_online, 	 		 // device online number
	&array.array_data.variable.pcsm_run,                 // device runing number
	DISABLE_DELAY_TRIGGER						 		 //
};

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/******************************************************************************
 * device_init().
 * Initialize device module. [Called by the sw_init()]
 *
 * @param none (I)
 * @param none (O)
 * @return none
 *****************************************************************************/
void device_init(void)
{
	clear_struct_data((uint8_t *)heart_pcs, sizeof(heart_pcs));
	link_list_init(&list_pcs);
	clear_struct_data((uint8_t *)heart_check_cnt, sizeof(heart_check_cnt));
	trigger_heart_check = FALSE;
	trigger_heart_check_count = 0;
	heart_check_period = 60 * 60 * 2;
	heart_check_threshold = 0.90;
}

/******************************************************************************
 * clear_device_heart().
 * clear device heart data. [Called by app.]
 *
 * @param device_device (I) device control block pointer
 * @return none
 *****************************************************************************/
void clear_device_heart(device_t *device)
{
	uint8_t index;

	// NULL pointer protection
	if(device == NULL)
	{
		return;
	}

	for(index = 0; index < device->count; index++)
	{
		device->heart[index].got = FALSE;
	}
}

/******************************************************************************
 * check_device_refresh().
 * check device refresh status. [Called by app.]
 *
 * @param device_device (I) device control block pointer
 * @return TRUE(add/del), FALSE(keep)
 *****************************************************************************/
bool_t check_device_refresh(device_t *device)
{
	uint8_t index;
	bool_t found;
	bool_t result = FALSE;

	// NULL pointer protection
	if(device == NULL)
	{
		return FALSE;
	}

	device_heart_refresh(device);

	for(index = 0, found = FALSE; index < device->count && !found; index++)
	{
		// check refresh status
		if(device->heart[index].refresh != DEVICE_KEEP)
		{
			found = TRUE;
			result = TRUE;
		}
	}

	return result;
}

/******************************************************************************
 * device_cnt_refresh().
 * device count refresh. [Called by app.]
 * device_total/device_online/device_running
 *
 * @param device_device (I) device control block pointer
 * @return none
 *****************************************************************************/
void device_cnt_refresh(device_t *device)
{
	list_node_t *node = NULL;
	uint8_t pcsm_cnt = 0;

	// NULL pointer protection
	if(device == NULL)
	{
		return;
	}

	// device online count
	*device->online = link_list_get_size(device->list);

	// device total count
	if(*device->online > *device->total)
	{
		*device->total = *device->online;
	}

	// count running pcsm
	node = link_list_get_head(&list_pcs);
	while(node)
	{
		if(array.pcsc.pcsc_data.pcsm_data[node->id - 1].state.fsm_state == NORMAL)
		{
			pcsm_cnt++;
		}
		node = node->next;
	}
	*device->runing = pcsm_cnt;
}

/******************************************************************************
 * device_heart_refresh().
 * Refresh device heart data. [Called by app.]
 *
 * @param device_device (I) device control block pointer
 * @return none
 *****************************************************************************/
void device_heart_refresh(device_t *device)
{
	uint8_t index;
	device_heart_t *heart;

	// NULL pointer protection
	if(device == NULL)
	{
		return;
	}
	for(index = 0; index < device->count; index++)
	{
		heart = &device->heart[index];
		heart->refresh = DEVICE_KEEP;
		heart->detect_cnt++;
		if(heart->online)
		{
			if(heart->got == TRUE)
			{
				heart->got = FALSE;
				heart->lost_cnt = 0;
			}
			else
			{
				if(0 == heart->lost_cnt)
				{
					opt_log_record("lost cnt start");
					heart->detect_cnt = 0;
				}
				heart->lost_cnt++;
			}

			if(heart->detect_cnt >= REFRESH_PCSM_PERIOD)
			{
				if(heart->lost_cnt >= PCSM_HEART_LOST_REF)
				{
					heart->refresh = DEVICE_DEL;
					heart->online = FALSE;
					heart->var_got = FALSE;
				}
				heart->detect_cnt = 0;
			}
		}
		else
		{
			if(heart->got == TRUE)
			{
				heart->got = FALSE;
				if(0 == heart->got_cnt)
				{
					opt_log_record("get cnt start");
					heart->detect_cnt = 0;
				}
				heart->got_cnt++;
			}
			if(heart->got_cnt > PCSM_HEART_GET_REF)
			{
				heart->refresh = DEVICE_ADD;
				heart->online = TRUE;
				heart->detect_cnt = 0;
				heart->got_cnt = 0;
			}
			else if(heart->detect_cnt >= REFRESH_PCSM_PERIOD)
			{
				heart->detect_cnt = 0;
				heart->got_cnt = 0;
			}
			else
			{
				// do nothing
			}
		}
	}
}

/******************************************************************************
 * device_list_refresh().
 * device list add or delete according to refresh status. [Called by app.]
 *
 * @param device (I) device control block pointer
 * @param mode (I) list refresh action according to mode choice
*         mode: add, del, all(add and del)
 * @return TRUE(success), FALSE(failure)
 *****************************************************************************/
bool_t device_list_refresh(device_t *device, REFRESH_E mode)
{
	uint8_t index;
	uint8_t *base_addr;
	list_node_t *temp_node = NULL;
	LINK_LIST_ERR_E list_status = LLE_NO_ERR;
	bool_t result = FALSE;

	// NULL pointer protection
	if(device == NULL)
	{
		return FALSE;
	}

	base_addr = (uint8_t *)device->data;

	for(index = 0; index < device->count; index++)
	{
		switch(device->heart[index].refresh)
		{
			case DEVICE_ADD:
			if((mode == REFRESH_ADD) || (mode == REFRESH_ALL))
			{
				list_status = link_list_insert_node(device->list, (index + 1),
									(void *)(base_addr + device->size * index),
														(uint8_t)device->type);
				//device->delay_trigger_mark = ENABLE_DELAY_TRIGGER;

				if(list_status != LLE_NO_ERR)
				{
					result = FALSE;
				}
				else
				{
					result = TRUE;
				}
			}
			break;
			case DEVICE_KEEP:
			break;
			case DEVICE_DEL:
			if((mode == REFRESH_DEL) || (mode == REFRESH_ALL))
			{
				// first clear node data then delete node
				temp_node = link_list_find_node(device->list, (index + 1));
				if(temp_node != NULL)
				{
					// clear data
					clear_struct_data((uint8_t *)temp_node->data, device->size);
					clear_struct_data((uint8_t *)&device->heart[index], sizeof(device_heart_t));
					// delete node
					list_status = link_list_del_node(device->list, temp_node);
					device->delay_trigger_mark = DISABLE_DELAY_TRIGGER;
				}
				else
				{
					list_status = LLE_NO_DATA;
				}

				if(list_status != LLE_NO_ERR)
				{
					result = FALSE;
				}
				else
				{
					result = TRUE;
				}
			}
			break;
			default:
			break;
		}
	}

	*device->online = link_list_get_size(device->list);

	return result;
}

/******************************************************************************
 * delay_heart_check().
 * delay 10s, enable heart check. [Called by slow_task_others.]
 *
 * @param	none (I)
 * @return	none
 *****************************************************************************/
void delay_heart_check(void)
{
	static bool_t trigger = FALSE;

	if((FALSE == trigger) && (trigger_heart_check_count >= 300))
	{
		trigger_heart_check = TRUE;
		sdk_rtc_get(RTC_BIN_FORMAT, &last_check_time);
		clear_struct_data((uint8_t *)heart_check_cnt, sizeof(heart_check_cnt));
		trigger = TRUE;
	}
	else
	{
		trigger_heart_check_count++;
	}
}

/******************************************************************************
 * slow_task_heart_check().
 * Can packet loss rate check. [Called by app.]
 *
 * @param none (I)
 * @param none (I)
 * @return
 *****************************************************************************/
void slow_task_heart_check(void)
{
	uint32_t time_gap;
	uint8_t i;
	float32_t loss_rate;

	time_gap = time_difference_in_sec(&last_check_time, &array.csu.rtc);

	if(time_gap >= heart_check_period) // 10min
	{
		for(i = 0; i < PCSM_NUMS; i++)
		{
			if(trigger_comm_diag[i])
			{
				loss_rate = (float32_t)heart_check_cnt[i] / heart_check_period;
				if(loss_rate <= heart_check_threshold)
				{
					opt_log_record("period:%.2f, threshold:%.2f, heart_check_cnt[%d]:%d, rate : %0.3f", \
									heart_check_period, heart_check_threshold, i, heart_check_cnt[i], loss_rate);
				}
			}
			heart_check_cnt[i] = 0;
		}
		last_check_time = array.csu.rtc;
	}
}

/******************************************************************************
* End of module
******************************************************************************/
