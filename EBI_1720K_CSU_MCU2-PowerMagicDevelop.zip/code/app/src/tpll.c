/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     tpll.c
  * @brief    PLL module
  * @company  SOFARSOLAR
  * @author   HH
  * @note
  * @version  V01
  * @date     2023/04/09
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------
#include <math.h>

// Include project file ------------------------------------------------------
#include "common.h"
#include "measure.h"
#include "tpll.h"
#include "array.h"
#include "calibration.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
// Unit: 1Hz，10kHz
#define CONTROL_FREQ                                                    (10000)

#define PLL_MAX_GRID_FREQUENCY          (16)  //66Hz
#define PLL_MIN_GRID_FREQUENCY          (6)  //44Hz
#define THETA_STEP_50HZRATED            (50 * DOUBLE_PI / CONTROL_FREQ)
#define THETA_STEP_50HZMAX_LIMIT        (PLL_MAX_GRID_FREQUENCY * DOUBLE_PI / CONTROL_FREQ)//0.02042035
#define THETA_STEP_50HZMIN_LIMIT        (-PLL_MIN_GRID_FREQUENCY * DOUBLE_PI / CONTROL_FREQ)//0.0109956

#define PLL_VOLTAGE_POS_LIMIT           (1225.0f)
#define PLL_VOLTAGE_NEG_LIMIT           (400.0f)
#define PLL_VOLTAGE_UQ_POS_LIMIT        (50)
#define PLL_VOLTAGE_POS_SQUARE_MIN      (10000)
#define PLL_NEG_SEQ_TRIG_MIN            (30.0f)
#define PLL_NEG_SEQ_TRIG_DELAY          (100)
#define PLL_CURR_USE_THETA_COMP         (-0.0163f)
#define VOLTAGE_FEED_FORWARD_WEIGHT     (0.98f)

#define KPI_PLL             (3.385e-5f)//(1.0650044e-6f)
#define KP_PLL              (3.366e-5f)//(1.0562269e-6f)

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
tpll_obj g_tpll;
tpll_cfg g_tpll_cfg;
bool_t g_grid_trig = FALSE;
bool_t trigger_anti_island;
float32_t freq_tpll = 0;

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/******************************************************************************
 * tpll_init().
 * Initialize PLL module. [Called by sw_init()]
 *
 * @param  none (I)
 * @param  none (O)
 * @return none
 *****************************************************************************/
void tpll_init(void)
{
	g_tpll_cfg.neg_seq_enable = FALSE;
	g_tpll_cfg.theta_step_max_lmt = THETA_STEP_50HZMAX_LIMIT;
	g_tpll_cfg.theta_step_min_lmt = THETA_STEP_50HZMIN_LIMIT;
	g_tpll_cfg.rated_theta_step = THETA_STEP_50HZRATED;
	g_tpll_cfg.upos_lmt = PLL_VOLTAGE_POS_LIMIT;
	g_tpll_cfg.uneg_lmt = PLL_VOLTAGE_NEG_LIMIT;
	g_tpll_cfg.uq_pos_lmt = PLL_VOLTAGE_UQ_POS_LIMIT;
	g_tpll_cfg.upos_squre_min = PLL_VOLTAGE_POS_SQUARE_MIN;
	g_tpll_cfg.neg_trig_lmt = PLL_NEG_SEQ_TRIG_MIN;
	g_tpll_cfg.curr_theta_comp = PLL_CURR_USE_THETA_COMP;
	g_tpll_cfg.neg_trig_delay = PLL_NEG_SEQ_TRIG_DELAY;

	memset(&g_tpll, 0, sizeof(g_tpll));
}

/******************************************************************************
 * tpll_volt_rotarion().
 * Grid voltage rotarion, r-s-t -> d-q. [Called by app]
 *
 * @param  none  (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void tpll_volt_rotarion(tpll_obj *obj, float32_t ugrid_r, float32_t ugrid_s, float32_t ugrid_t)
{
	ALG_ABC2ALPHABETA(ugrid_r, ugrid_s, ugrid_t, obj->u_alpha, obj->u_beta);
	ALG_ALPHABETA2DQ(obj->u_alpha, obj->u_beta, obj->sin_theta, obj->cos_theta, obj->ud, obj->uq);
}

/******************************************************************************
 * tpll_process().
 * PLL algorithm [Called by app]
 *
 * @param  tpll_obj  (I) tpll object pointer
 * @param  tpll_cfg  (I) tpll config pointer
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void tpll_process(tpll_obj *obj, tpll_cfg *cfg)
{
	static float32_t s_pll_ualpha1 = 0;
	static float32_t s_pll_ualpha2 = 0;
	static float32_t s_pll_ubeta1 = 0;
	static float32_t s_pll_ubeta2 = 0;
	static float32_t s_pll_ualpha_p = 0;
	static float32_t s_pll_ubeta_p = 0;
	static uint16_t  count = 0;
	static float64_t freq_sum = 0;
	float32_t temp1;

	obj->omega_pll = PI * 0.01f;

	//二阶广义积分
	temp1 = (obj->u_alpha - s_pll_ualpha1) * SQRT2 - s_pll_ualpha2;
	s_pll_ualpha1 += (obj->omega_pll * temp1);
	s_pll_ualpha2 += (obj->omega_pll * s_pll_ualpha1);

	temp1 = (obj->u_beta - s_pll_ubeta1) * SQRT2 - s_pll_ubeta2;
	s_pll_ubeta1 += (obj->omega_pll * temp1);
	s_pll_ubeta2 += (obj->omega_pll * s_pll_ubeta1);

	s_pll_ualpha_p = 0.5f * (s_pll_ualpha1 - s_pll_ubeta2);
	s_pll_ubeta_p  = 0.5f * (s_pll_ubeta1 + s_pll_ualpha2);

	//获取电网正序分量
	obj->ud_pos = s_pll_ualpha_p * obj->sin_theta - s_pll_ubeta_p * obj->cos_theta;
	obj->uq_pos = s_pll_ubeta_p * obj->sin_theta + s_pll_ualpha_p * obj->cos_theta;

	constrain_float32_t_data(&obj->uq_pos, -cfg->uq_pos_lmt, cfg->uq_pos_lmt);  // 50

	obj->u_pos = (obj->ud_pos * obj->ud_pos + obj->uq_pos * obj->uq_pos);
	//obj->u_pos = float32_min(obj->u_pos, cfg->upos_squre_min); // 10000
	if(obj->u_pos < cfg->upos_squre_min)
	{
		obj->u_pos = cfg->upos_squre_min;
	}

// dqPLL PID regulator process
	obj->uq_err_old = obj->uq_err_new;
	obj->uq_err_new = obj->uq_pos;

	obj->pll_step += obj->uq_err_new * KPI_PLL - obj->uq_err_old * KP_PLL ;// todo 待该模块调试完成后需要重构

// Up Limit Staturation Control 0.015708
// Low Limit Staturation Control
	constrain_float32_t_data(&obj->pll_step, cfg->theta_step_min_lmt, cfg->theta_step_max_lmt);
	obj->theta_step = obj->pll_step + cfg->rated_theta_step;
	obj->theta +=  obj->theta_step;
	count++;
	freq_sum += (g_tpll.theta_step * CONTROL_FREQ) / DOUBLE_PI;

	if ( obj->theta >= DOUBLE_PI )
	{
		trigger_anti_island = TRUE;
		freq_tpll = (freq_sum / count); // 1Hz
		freq_sum = 0;
		count = 0;
		obj->theta = obj->theta - DOUBLE_PI;
	}

	obj->sin_theta = sin(obj->theta);
	obj->cos_theta = cos(obj->theta);

	obj->neg_seq_current_trig = 0;
	obj->ud_neg = 0;
}

/******************************************************************************
 * crtl_task_tpll().
 * PLL task. [Called by task]
 *
 * @param  none  (I)
 * @param  none  (O)
 * @return none
 *****************************************************************************/
void crtl_task_tpll(void)
{
	tpll_volt_rotarion(&g_tpll, g_ac_signal[VGRD_R].physical * calibrate.ac[CALI_VGRID_RS].gain, \
								g_ac_signal[VGRD_S].physical * calibrate.ac[CALI_VGRID_ST].gain, \
								g_ac_signal[VGRD_T].physical * calibrate.ac[CALI_VGRID_TR].gain);
	tpll_process(&g_tpll, &g_tpll_cfg);
}

/******************************************************************************
* End of module
******************************************************************************/
