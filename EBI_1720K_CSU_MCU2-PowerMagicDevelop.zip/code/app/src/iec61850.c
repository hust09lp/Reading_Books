/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     iec61850.c
  * @brief    iec61850 app module
  * @company  SOFARSOLAR
  * @author   GZQ
  * @note
  * @version  V01
  * @date     2023/09/13
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "array.h"
#include "iec61850.h"
#include "main.h"
#include "sdk.h"
#include "sdk_core.h"
#include "pcs.h"
#include "pcsc_opt_log.h"
#include "power_manage.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define IEC61850_GET_NUMS                                                     2
#define IEC61850_SET_NUMS                                                     9
#define IEC61850_ONE_W_CNT                                                  256
#define CID_FILE_MEMORAY_SIZE                                      (128 * 1024)

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
enum
{
	PHASE_INIT,
	PHASE_ERASE,
	PHASE_OPEN_FILE,
	PHASE_WRITE,
	PHASE_REBOOT
};

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
static uint32_t iec_file_write_addr = 0;
static uint32_t flash_sector_size = 0;
static uint16_t sector_num_general = 0;
static uint16_t sector_num_last = 0;
static fs_t     *file_iec61850 = NULL;
static float32_t  get_data_old[IEC61850_GET_NUMS];

bool_t trigger_iec61850_cid = FALSE;
/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/******************************************************************************
 * iec61850_init().
 * Initialize iec61850. [Called by sw_init()]
 *
 * @param  none (I)
 * @param  none (O)
 * @return none
 *****************************************************************************/
void iec61850_init(void)
{
	iec_file_write_addr = 0;
	flash_sector_size = 0;
	sector_num_general = 0;
	sector_num_last = 0;
	file_iec61850 = NULL;
    clear_struct_data((uint8_t *)&get_data_old[0], sizeof(get_data_old));

	trigger_iec61850_cid = FALSE;
}

/******************************************************************************
 * fast_task_iec61850().
 * fast task. []
 *
 * @param  none (I)
 * @param  none (O)
 * @return none
 *****************************************************************************/
void fast_task_iec61850(void)
{
	int32_t ret;
	uint8_t i;
    float32_t *temp_p = NULL;
    int16_t temp_data = 0;
    bool_t data_changed = FALSE;
	pcsm_cmd_t can_cmd_temp;
	float32_t get_data[IEC61850_GET_NUMS];
	float32_t set_data[IEC61850_SET_NUMS];

    clear_struct_data((uint8_t *)&can_cmd_temp, sizeof(pcsm_cmd_t));
    clear_struct_data((uint8_t *)&get_data[0], sizeof(get_data));
    clear_struct_data((uint8_t *)&set_data[0], sizeof(set_data));
	can_cmd_temp.dst_addr = 0;
	can_cmd_temp.fun_code = PCS_CMD_SET_PARAMETER;
	can_cmd_temp.len = 1;

	ret = sdk_iec61850_goose_data_get(get_data, IEC61850_GET_NUMS);
	if(ret >= SF_OK)
	{
		if(array.pcsc.pcsc_ctrl.power_control_source)
		{
            // Determine if the data has changed
            // resolve conflict between IEC104 ,modbus_tcp and 61850
            for(i = 0; (i < IEC61850_GET_NUMS); i++)
            {
                if(get_data_old[i] != get_data[i])
                {
                    get_data_old[i] = get_data[i];
                    data_changed = TRUE;
                }
            }
			// when flag is TRUE, That means the data has changed
            if(data_changed == TRUE)
            {
                i = 0;
                // get_data unit 1kw, temp_data unit 0.1kw
                temp_data = (int16_t)(get_data[i] * 10.0f);
                if(temp_data != array.pcsc.pcsc_ctrl.active_power_ref)
                {
					if(0 == temp_data)
					{
						opt_log_record("set power from 61850, value:%d -> %d", \
									array.pcsc.pcsc_ctrl.active_power_ref, temp_data);
						sdk_log_a("set power from 61850, value:%d -> %d\r\n", \
									array.pcsc.pcsc_ctrl.active_power_ref, temp_data);
					}
					g_active_power_send = TRUE;
                    can_cmd_temp.offset.all = ACTIVE_POWER_REF;
                    // 由fast_task_power_distribution下发功率
                    array.pcsc.pcsc_ctrl.active_power_ref = temp_data;
                }
                i++;
                temp_data = (int16_t)(get_data[i] * 10.0f);
                if(temp_data != array.pcsc.pcsc_ctrl.reactive_power_ref)
                {
					g_reactive_power_send = TRUE;
                    can_cmd_temp.offset.all = REACTIVE_POWER_REF;
                    array.pcsc.pcsc_ctrl.reactive_power_ref = temp_data;
                    // 无功只有一种分配模式，通过fifo直接下发功率
                    //fifo_can_push(&fifo_can5_cmd, &can_cmd_temp);
                }
            }
		}
	}
	else
	{
		sdk_log_e("iec61850 get data failed");
	}

	i = 0;
	set_data[i++] = ((float32_t)array.csu.csu_data.csu_const.system_rated_power) / 10.0f;
	//set_data[i++] = array.pcsc.pcsc_data.state.sys_state;
	//*(set_data + i++) = array.pcsc.pcsc_data.state.sys_state;
	temp_p = (float32_t *)&array.pcsc.pcsc_data.state.sys_state;
	set_data[i++] = *temp_p;
	set_data[i++] = ((float32_t)array.pcsc.pcsc_data.var.max_chargable_power) / 10.0f;
	set_data[i++] = ((float32_t)array.pcsc.pcsc_data.var.max_dischargable_power) / 10.0f;
	set_data[i++] = ((float32_t)array.pcsc.pcsc_data.var.soc_operation_val) * 1.0f;
	set_data[i++] = ((float32_t)array.pcsc.pcsc_data.var.power_p) / 10.0f;
	set_data[i++] = ((float32_t)array.pcsc.pcsc_data.var.power_q) / 10.0f;
	set_data[i++] = ((float32_t)array.pcsc.pcsc_data.var.increasable_reactive_power) / 10.0f;
	set_data[i++] = ((float32_t)array.pcsc.pcsc_data.var.decreasable_reactive_power) / 10.0f;
	ret = sdk_iec61850_goose_data_set(set_data, IEC61850_SET_NUMS);
	if(ret < SF_OK)
	{
		sdk_log_e("iec61850 set data failed");
	}
}

/******************************************************************************
 * iec61850_write_flash_init().
 * iec61850 write flash init. []
 *
 * @param  none (I)
 * @param  none (O)
 * @return ret(int32) (>= 0 : sucess ; < 0 fail)
 *****************************************************************************/
static int32_t iec61850_write_flash_init(void)
{
	int32_t ret = SF_OK;

	sector_num_last = 0;

	if(file_iec61850 != NULL)
	{
		sdk_fs_close(file_iec61850);
	}

	sdk_flash_ioctl(FLASH_ID_INT,FLASH_CMD_TOTAL_SIZE_GET,\
														 &iec_file_write_addr);
	sdk_flash_ioctl(FLASH_ID_INT,FLASH_CMD_SECTOR_SIZE_GET,\
														   &flash_sector_size);
	iec_file_write_addr = iec_file_write_addr - CID_FILE_MEMORAY_SIZE + \
														 BOOT_START_FLASH_ADDR;

	sdk_log_i("iec61850:init!\r\n");

	return ret;
}

/******************************************************************************
 * iec61850_write_flash_erase().
 * iec61850 write erase flash. []
 *
 * @param  none (I)
 * @param  none (O)
 * @return ret (>= 0 : sucess ; < 0 fail)
 *****************************************************************************/
static int32_t iec61850_write_flash_erase(void)
{
	int32_t ret;

	ret = sdk_flash_erase(FLASH_ID_INT, iec_file_write_addr, \
														CID_FILE_MEMORAY_SIZE);

	return ret;
}

/******************************************************************************
 * iec61850_write_flash_open().
 * iec61850 open file. []
 *
 * @param  none (I)
 * @param  none (O)
 * @return ret(int32) (>= 0 : sucess ; < 0 fail)
 *****************************************************************************/
static int32_t iec61850_write_flash_open(void)
{
	int32_t ret;
	int32_t tmp;

	file_iec61850 = sdk_fs_open((const int8_t*)IEC61850_FILE_NAME, FA_READ);
	if(file_iec61850 != NULL)
	{
		ret = SF_OK;

		tmp = sdk_fs_get_size(file_iec61850);
		sdk_log_i("iec61850:file size:%d!\r\n", tmp);
		sector_num_general = tmp / flash_sector_size;
		tmp = tmp % flash_sector_size;
		if(tmp != 0)
		{
			sector_num_general++;
		}

		sdk_log_i("iec61850:sector num:%d!\r\n", sector_num_general);
	}
	else
	{
		ret = SF_ERR_OPEN;
	}

	return ret;
}

/******************************************************************************
 * iec61850_write_flash_write().
 * iec61850 write flash. []
 *
 * @param  none (I)
 * @param  none (O)
 * @return ret(int32) (sector_num_last)
 *****************************************************************************/
int32_t iec61850_write_flash_write(void)
{
	int32_t ret;
	uint8_t finish_mark = FALSE;
	uint16_t write_bytes = 0;
	uint16_t read_bytes = 0;
	uint16_t need_write_bytes = 0;
	uint16_t tmp = 0;
	uint8_t byte[IEC61850_ONE_W_CNT];

	if(sector_num_last == (sector_num_general - 1))
	{
		tmp = sdk_fs_get_size(file_iec61850);
		need_write_bytes = tmp % flash_sector_size;
		if(need_write_bytes == 0)
		{
			need_write_bytes = flash_sector_size;
		}
	}
	else
	{
		need_write_bytes = flash_sector_size;
	}

	do
	{
		read_bytes = sdk_fs_read(file_iec61850, &byte[0], IEC61850_ONE_W_CNT);
		ret = sdk_flash_write(FLASH_ID_INT,iec_file_write_addr, \
														  read_bytes,&byte[0]);
		if(ret >= SF_OK)
		{
			write_bytes += read_bytes;
			iec_file_write_addr += read_bytes;
			sdk_log_i("iec61850:write:%d!\r\n", write_bytes);
			if(write_bytes >= need_write_bytes)
			{
				sector_num_last++;
				finish_mark = TRUE;
			}
		}
		else
		{
			iec_file_write_addr = iec_file_write_addr - \
									 (iec_file_write_addr % flash_sector_size);
			tmp = sector_num_last * flash_sector_size;
			sdk_fs_lseek(file_iec61850, tmp);
			sdk_flash_erase(FLASH_ID_INT, iec_file_write_addr, \
															flash_sector_size);
			finish_mark = TRUE;
		}
	}while(finish_mark == FALSE);

	ret = sector_num_last;
	return ret;
}

/******************************************************************************
 * slow_task_iec61850_cid().
 * Save IEC61850 CID file. [Called by task()]
 *
 * @param  none (I)
 * @param  none (O)
 * @return none
 *****************************************************************************/
void slow_task_iec61850_cid(void)
{
	static int8_t step = PHASE_INIT;
	int32_t ret;

	switch(step)
	{
		case PHASE_INIT:
			ret = iec61850_write_flash_init();
			if(ret >= SF_OK)
			{
				step = PHASE_ERASE;
			}
			break;
		case PHASE_ERASE:
			ret = iec61850_write_flash_erase();
			if(ret >= SF_OK)
			{
				sdk_log_i("iec61850: erase finsh!\r\n");
				step = PHASE_OPEN_FILE;
			}
			else
			{
				sdk_log_e("iec61850: erase flash erro!\r\n");
			}
			break;
		case PHASE_OPEN_FILE:
			ret = iec61850_write_flash_open();
			if(ret >= SF_OK)
			{
				sdk_log_i("iec61850: open file!\r\n");
				step = PHASE_WRITE;
			}
			else
			{
				sdk_log_e("iec61850: erase flash erro!\r\n");
			}
			break;
		case PHASE_WRITE:
			ret = iec61850_write_flash_write();
			if(ret == sector_num_general)
			{
				sdk_log_i("iec61850: write flash success!\r\n");
				step = PHASE_REBOOT;
			}
			break;
		case PHASE_REBOOT:
			step = PHASE_INIT;
			sdk_log_i("iec61850: reboot!\r\n");
			sdk_sys_reset();
			break;
		default:
			step = PHASE_INIT;
			break;
	}
}
