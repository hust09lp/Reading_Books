/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     rs485_hmi.c
  * @brief    HMI debug module
  * @company  SOFARSOLAR
  * @author   WWX
  * @note
  * @version  V01
  * @date     2023/03/09
  */
  /*****************************************************************************/

  /******************************************************************************
  * COMPILATION OPTION
  ******************************************************************************/

  /******************************************************************************
  * INCLUDE FILE
  ******************************************************************************/
  // Include system file -------------------------------------------------------

  // Include project file ------------------------------------------------------
#include "calibration.h"
#include "array.h"
#include "measure.h"
#include "pcs.h"
#include "rs485_hmi.h"
#include "sdk.h"
#include "sdk_core.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define REG_HOLDING_NUM                                                    1300
#define FIFO_MODS_CMD_NUM                                                    20

#define RS485_HMI                                                           (3)

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
uint16_t reg_hold_reserved;
DATA_RW_E reg_hold_buf_rw;
//uint16_t *reg_hold[REG_HOLDING_NUM] = {0};
uint16_t reg_hold_rsvd = 0;
mod_temp_t mod_temp;
mods_cmd_t mods_cmd[FIFO_MODS_CMD_NUM];
uint16_t hmi_heartbeat;
//uint16_t pcsm_id;
fifo_mods_cmd_t fifo_mods_cmd =
{
	0,                       // head
	1,                       // empty(0: not, 1: empty)
	0,                       // tail
	0,                       // full(0: not, 1: full)
	0,                       // length
	0,                       // busy(0: not, 1: busy)
	&mods_cmd[0],            // buffer pointer
	FIFO_MODS_CMD_NUM,       // buffer size
	0,                       // max_len
	0,                       // lost_cnt
};

//static uint8_t hmi_rx_buf[MOD_FRAME_MAX_NUM] = {0};

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/
void regs_hold_init(void);
void fifo_mods_cmd_init(void);
int32_t read_hold_reg(uint16_t reg_addr, uint16_t reg_num, uint8_t *p_rsp);
int32_t write_hold_reg(uint16_t reg_addr, uint16_t reg_num, const uint8_t *p_data);
int32_t mod_pcsm_set(uint16_t reg_addr, uint16_t reg_value, const uint8_t *p_data);

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/
/******************************************************************************
 * rs485_hmi_init().
 * Initialize HMI debug module. [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_hmi_init(void)
{
	int32_t result;

	result = sdk_modbus_rtu_init(RS485_HMI, 1, MODBUS_BAUD_9600);
	if(result != SF_OK)
	{
		sdk_log_d("RS485_HMI modbus init failed!\r\n");
		return;
	}

	result = sdk_modbus_connect(RS485_HMI);
	if(result != SF_OK)
	{
		sdk_log_d("RS485_HMI modbus connect failed!\r\n");
		return;
	}

	result = sdk_modbus_response_timeout_set(RS485_HMI, 10);
	if(result != SF_OK)
	{
		sdk_log_d("RS485_HMI modbus response set timeout failed!\r\n");
		return;
	}

	result = sdk_modbus_indication_timeout_set(RS485_HMI, 10);
	if(result != SF_OK)
	{
		sdk_log_d("RS485_HMI modbus indication set timeout failed!\r\n");
		return;
	}

	regs_hold_init();
	fifo_mods_cmd_init();

	reg_hold_buf_rw        = DATA_FREE;
	mod_temp.temp_data.all = 0;
	mod_temp.temp_rx_cnt   = 0;

//	clear_struct_data((uint8_t *)&hmi_rx_buf[0], sizeof(hmi_rx_buf));
}

/******************************************************************************
 * void regs_hold_init(void).
 * Initialized holding registers. [Called by modbus init funtion.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void regs_hold_init(void)
{
//	uint16_t i;
//	uint16_t j;
//	uint16_t addr;
//	uint16_t *p_data;

//	addr = TEST_START_REGS_ADDR;

//	for(i = 0; i < PCSM_NUMS; i++)
//	{
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.grid_volt_r;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.grid_volt_s;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.grid_volt_t;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.grid_volt_rs;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.grid_volt_st;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.grid_volt_tr;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.grid_freq;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.n_to_pe_volt;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.ac_current_r;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.ac_current_s;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.ac_current_t;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.dci_r;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.dci_s;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.dci_t;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.gfci;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.bus_volt_p;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.bus_volt_n;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.bus_volt_pn;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.bat_volt;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.bat_current;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.iso_resistence;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.iso_det_state;
//		reg_hold[addr++] = (uint16_t *)&reg_hold_reserved;
//		reg_hold[addr++] = (uint16_t *)&reg_hold_reserved;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.iso_volt_to_pe;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.active_power;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.reactive_power;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.apparent_power;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.igbt_temp_ra;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.igbt_temp_sa;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.igbt_temp_ta;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.igbt_temp_rb;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.igbt_temp_sb;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.igbt_temp_tb;
//		reg_hold[addr++] = (uint16_t *)&reg_hold_reserved;
////		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.igbt_temp_anti_sc;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.amb_temp;
//		reg_hold[addr++] = (uint16_t *)&reg_hold_reserved;
//		reg_hold[addr++] = (uint16_t *)&reg_hold_reserved;
//		reg_hold[addr++] = (uint16_t *)&reg_hold_reserved;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.slv_grid_volt_r;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.slv_grid_volt_s;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].var.slv_grid_volt_t;
//		reg_hold[addr++] = (uint16_t *)&reg_hold_reserved;

//		// pcsm[0]: var_reg_hold[43-49] rsvd
//		for(j = 0; j < 7; j++)
//		{
//			reg_hold[addr++] = (uint16_t *)&reg_hold_rsvd;
//		}
//	}

//	addr = PCSM_SET_START_REGS_ADDR;
//	for(i = 0; i < PCSM_NUMS; i++)
//	{
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[1].pcs_run;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[1].active_power_ref;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[1].reactive_power_ref;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[1].pcs_operation_mode;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[1].bus_volt_ref;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[1].openloop_enable;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[1].openloop_volt_set;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[1].reset_cmd;


//		// pcsm[0]: reg_hold[408-419] rsvd
//		for(j = 0; j < 12; j++)
//		{
//			reg_hold[addr++] = (uint16_t *)&reg_hold_rsvd;
//		}
//	}

//	addr = PCSM_FAULT_STATE_START_REGS_ADDR;
//	for(i = 0; i < PCSM_NUMS; i++)
//	{
//		// 0 ~ 35
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].fault.fault1;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].fault.fault2;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].fault.fault3;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].fault.fault4;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].fault.fault5;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].fault.fault6;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].fault.fault7;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].fault.fault8;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].fault.fault9;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].fault.warn1;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[0].pcs_run;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[0].active_power_ref;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[0].reactive_power_ref;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[0].pcs_operation_mode;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[0].bus_volt_ref;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[0].openloop_enable;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[0].openloop_volt_set;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[0].reset_cmd;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[0].sn1_set;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[0].sn2_set;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[0].sn3_set;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[0].sn4_set;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[0].sn5_set;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[0].sn6_set;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[0].sn7_set;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[0].sn8_set;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[0].sn9_set;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[0].sn10_set;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[0].ad_gain_bus_p_cali;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[0].ad_gain_bus_n_cali;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[0].ad_gain_iout_r_cali;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[0].ad_gain_iout_s_cali;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].set[0].ad_gain_iout_t_cali;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].state.fsm_state;
//		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].state.fault_state;
//		reg_hold[addr++] = (uint16_t *)&reg_hold_rsvd;
////		reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.pcsm_data[i].state.run_mode;

//		// pcsm[0]_fault_state : fau_sta_reg_hold[596 - 599] rsvd
//		for(j = 0; j < 4; j++)
//		{
//			reg_hold[addr++] = (uint16_t *)&reg_hold_rsvd;
//		}
//	}
//	addr = PCSC_SET_PCMD_ADDR;
//	reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_ctrl.active_power_ref;
//	reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_ctrl.pcsc_on_off;
//	reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_ctrl.pwm_enable;
//	reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_ctrl.pcs_operation_mode;
//	reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_ctrl.bus_volt_ref;
//	reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_ctrl.reset_cmd;

//	addr = PCSC_STATE_START_REGS_ADDR;
//	reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_ctrl.do_ctrl.all;
//	reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.state.state1.all;
//	reg_hold[addr++] = (uint16_t *)&array.pcsc.pcsc_data.state.state2.all;
//
//	addr = PCSM_GROUP_SET_ADDR;
//	reg_hold[addr++] = (uint16_t *)&pcsm_group[0].pcs_run;
//	reg_hold[addr++] = (uint16_t *)&pcsm_group[0].active_power_ref;
//	reg_hold[addr++] = (uint16_t *)&pcsm_group[0].reactive_power_ref;
//	reg_hold[addr++] = (uint16_t *)&pcsm_group[0].pcs_operation_mode;
//	reg_hold[addr++] = (uint16_t *)&pcsm_group[0].bus_volt_ref;
//	reg_hold[addr++] = (uint16_t *)&pcsm_group[1].pcs_run;
//	reg_hold[addr++] = (uint16_t *)&pcsm_group[1].active_power_ref;
//	reg_hold[addr++] = (uint16_t *)&pcsm_group[1].reactive_power_ref;
//	reg_hold[addr++] = (uint16_t *)&pcsm_group[1].pcs_operation_mode;
//	reg_hold[addr++] = (uint16_t *)&pcsm_group[1].bus_volt_ref;

//	addr = CSU_HMI_COMM_LED_REG_ADDR;
//	reg_hold[addr++] = (uint16_t *)&hmi_heartbeat;
//	reg_hold[addr++] = (uint16_t *)&array.array_data.variable.pcsm_online;
//	reg_hold[addr++] = (uint16_t *)&array.array_data.variable.pcsm_run;
//	reg_hold[addr++] = (uint16_t *)&array.array_data.variable.pcsm_total;

//	addr = PCS_SYS_RT_DATA_ADDR;
//	p_data = &array.pcsc.pcsc_data.var.v_grd_rs;
//	for(i = 0; i < 34; i++)
//	{
//		reg_hold[addr++] = p_data++;
//	}

//	p_data = (uint16_t *)&energy.charge_today;
//	for(i = 0; i < 8; i++)
//	{
//		reg_hold[addr++] = p_data++;
//	}

//	// Calibrate status
//	reg_hold[CALIB_STATE_ADDR] = (uint16_t *)&calibrate.status;

//	// Real time ADC
//	reg_hold[RT_ADC_T_BOARD_ADDR] = (uint16_t *)&g_dc_signal[T_BOARD].adc_avg;
//	reg_hold[RT_ADC_T_AC_FUS_ADDR] = (uint16_t *)&g_dc_signal[T_AC_FUS].adc_avg;
//	reg_hold[RT_ADC_T_DC_FUS1_ADDR] = (uint16_t *)&g_dc_signal[T_DC_FUS1].adc_avg;
//	reg_hold[RT_ADC_T_DC_FUS2_ADDR] = (uint16_t *)&g_dc_signal[T_DC_FUS2].adc_avg;
//	reg_hold[RT_ADC_V_DC1_ADDR] = (uint16_t *)&g_dc_signal[VBUS1].adc_avg;
//	reg_hold[RT_ADC_V_DC2_ADDR] = (uint16_t *)&g_dc_signal[VBUS2].adc_avg;

//	// Real time data high
//	reg_hold[RT_ADC_V_PCS_RS_ADDR] = (uint16_t *)&array.pcsc.pcsc_data.var.v_out_rs;
//	reg_hold[RT_ADC_V_PCS_RS_ADDR] = (uint16_t *)&array.pcsc.pcsc_data.var.v_out_st;
//	reg_hold[RT_ADC_V_PCS_TR_ADDR] = (uint16_t *)&array.pcsc.pcsc_data.var.v_out_tr;
//	reg_hold[RT_ADC_V_GRD_RS_ADDR] = (uint16_t *)&array.pcsc.pcsc_data.var.v_grd_rs;
//	reg_hold[RT_ADC_V_GRD_ST_ADDR] = (uint16_t *)&array.pcsc.pcsc_data.var.v_grd_st;
//	reg_hold[RT_ADC_V_GRD_TR_ADDR] = (uint16_t *)&array.pcsc.pcsc_data.var.v_grd_tr;
//	reg_hold[RT_ADC_I_OUT_R_ADDR]  = (uint16_t *)&array.pcsc.pcsc_data.var.i_out_r;
//	reg_hold[RT_ADC_I_OUT_S_ADDR]  = (uint16_t *)&array.pcsc.pcsc_data.var.i_out_s;
//	reg_hold[RT_ADC_I_OUT_T_ADDR]  = (uint16_t *)&array.pcsc.pcsc_data.var.i_out_t;
//	reg_hold[RT_ADC_POWER_P_ADDR]  = (uint16_t *)&array.pcsc.pcsc_data.var.power_p;
//	reg_hold[RT_ADC_POWER_Q_ADDR]  = (uint16_t *)&array.pcsc.pcsc_data.var.power_q;
//	reg_hold[RT_ADC_POWER_S_ADDR]  = (uint16_t *)&array.pcsc.pcsc_data.var.power_s;

//	// Real time data low
//	reg_hold[1 + RT_ADC_V_PCS_RS_ADDR] = (uint16_t *)&array.pcsc.pcsc_data.var.v_out_rs + 1;
//	reg_hold[1 + RT_ADC_V_PCS_RS_ADDR] = (uint16_t *)&array.pcsc.pcsc_data.var.v_out_st + 1;
//	reg_hold[1 + RT_ADC_V_PCS_TR_ADDR] = (uint16_t *)&array.pcsc.pcsc_data.var.v_out_tr + 1;
//	reg_hold[1 + RT_ADC_V_GRD_RS_ADDR] = (uint16_t *)&array.pcsc.pcsc_data.var.v_grd_rs + 1;
//	reg_hold[1 + RT_ADC_V_GRD_ST_ADDR] = (uint16_t *)&array.pcsc.pcsc_data.var.v_grd_st + 1;
//	reg_hold[1 + RT_ADC_V_GRD_TR_ADDR] = (uint16_t *)&array.pcsc.pcsc_data.var.v_grd_tr + 1;
//	reg_hold[1 + RT_ADC_I_OUT_R_ADDR]  = (uint16_t *)&array.pcsc.pcsc_data.var.i_out_r + 1;
//	reg_hold[1 + RT_ADC_I_OUT_S_ADDR]  = (uint16_t *)&array.pcsc.pcsc_data.var.i_out_s + 1;
//	reg_hold[1 + RT_ADC_I_OUT_T_ADDR]  = (uint16_t *)&array.pcsc.pcsc_data.var.i_out_t + 1;
//	reg_hold[1 + RT_ADC_POWER_P_ADDR]  = (uint16_t *)&array.pcsc.pcsc_data.var.power_p + 1;
//	reg_hold[1 + RT_ADC_POWER_Q_ADDR]  = (uint16_t *)&array.pcsc.pcsc_data.var.power_q + 1;
//	reg_hold[1 + RT_ADC_POWER_S_ADDR]  = (uint16_t *)&array.pcsc.pcsc_data.var.power_s + 1;

//	// Gain and Offset
//	// dc calibrate data
//	addr = GNFT_T_AC_FUSE_ADDR;
//	for(i = 0; i < CALI_AC_LEN; i++)
//	{
//		p_data = (uint16_t *)&calibrate.dc[i].gain;
//		for(j = 0; j < 4; j++)
//		{
//			reg_hold[addr++] = p_data++;
//		}
//	}

//	// ac calibrate data
//	addr = GNFT_V_PCS_RS_ADDR;
//	for(i = 0; i < CALI_AC_LEN; i++)
//	{
//		p_data = (uint16_t *)&calibrate.ac[i].gain;
//		for(j = 0; j < 2; j++)
//		{
//			reg_hold[addr++] = p_data++;
//		}
//	}

//	// input dc data
//	addr = CALIB_T_AC_FUSE_ADDR;
//	for(i = 0; i < 5; i++)
//	{
//		p_data = (uint16_t *)&calibrate.dc[i].x1;
//		for(j = 0; j < 6; j++)
//		{
//			reg_hold[addr++] = p_data++;
//		}
//	}

//	// input ac data
//	addr = CALIB_V_PCS_RS_ADDR;
//	for(i = 0; i < 5; i++)
//	{
//		p_data = (uint16_t *)&calibrate.ac[i].x;
//		for(j = 0; j < 4; j++)
//		{
//			reg_hold[addr++] = p_data++;
//		}
//	}
}

/******************************************************************************
 * fifo_mods_cmd_init().
 * Initialize mods cmd FIFO. [Called by the modbus_init()]
 *
 * @param none (I)
 * @param none (O)
 * @return none
 *****************************************************************************/
void fifo_mods_cmd_init(void)
{
	clear_struct_data((uint8_t *)&mods_cmd[0], sizeof(mods_cmd));
}

/******************************************************************************
 * fifo_mods_push()
 * Push a cmd to a cmd FIFO. [Called by the mods pcsm set function]
 *
 * @param *mods_cmd       (I) a cmd to be pushed
 * @param *fifo_mods_cmd  (O) a cmd FIFO to be pushed
 * @return TRUE(success), FALSE(failure)
 *****************************************************************************/
bool_t fifo_mods_push(fifo_mods_cmd_t *fifo_mods_cmd, mods_cmd_t *mods_cmd)
{
	bool_t result = FALSE;

	// NULL pointer protection
	if((!fifo_mods_cmd) |
	   (!mods_cmd))
	{
		return result;
	}

	// FIFO full protection
	if(fifo_mods_cmd->full)
	{
		fifo_mods_cmd->lost_cnt++;
		return result;
	}

	if(!fifo_mods_cmd->busy)
	{
		// occupy sharing resources
		fifo_mods_cmd->busy = TRUE;

		fifo_mods_cmd->buff[fifo_mods_cmd->head++] = *mods_cmd;
		if(fifo_mods_cmd->head >= fifo_mods_cmd->size)
		{
			fifo_mods_cmd->head = 0;
		}

		fifo_mods_cmd->empty = FALSE;
		fifo_mods_cmd->len++;
		if(fifo_mods_cmd->len >= fifo_mods_cmd->max_len)
		{
			fifo_mods_cmd->max_len = fifo_mods_cmd->len;
		}
		if(fifo_mods_cmd->len >= fifo_mods_cmd->size)
		{
			fifo_mods_cmd->full = TRUE;
		}

		// Release sharing resources
		fifo_mods_cmd->busy = FALSE;

		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * fifo_mods_pop()
 * Pop a cmd from a cmd FIFO. [Called by the task()]
 *
 * @param *fifo_mods_cmd (I) a mods cmd fifo to be popped
 * @param *mods_cmd      (O) a cmd to be popped
 * @return TRUE(success), FALSE(failure)
 *****************************************************************************/
bool_t fifo_mods_pop(fifo_mods_cmd_t *fifo_mods_cmd, mods_cmd_t *mods_cmd)
{
	bool_t result = FALSE;

	// NULL pointer protection
	if((!fifo_mods_cmd) |
	   (!mods_cmd))
	{
		return result;
	}

	// FIFO empty protection
	if(fifo_mods_cmd->empty)
	{
		return result;
	}

	if(!fifo_mods_cmd->busy)
	{
		// Occupy sharing resources
		fifo_mods_cmd->busy = TRUE;

		*mods_cmd = fifo_mods_cmd->buff[fifo_mods_cmd->tail++];
		if(fifo_mods_cmd->tail >= fifo_mods_cmd->size)
		{
			fifo_mods_cmd->tail = 0;
		}

		fifo_mods_cmd->full = FALSE;
		fifo_mods_cmd->len--;
		if(fifo_mods_cmd->len == 0)
		{
			fifo_mods_cmd->empty = TRUE;
		}

		// Release sharing resources
		fifo_mods_cmd->busy = FALSE;

		result = TRUE;
	}

	return result;
}

/******************************************************************************
 * user_modbus_parse()
 * modbus frame parse. [Called by slow fut task.]
 *
 * @param func      (I) function code
 * @param p_req     (I) modbus request frame
 * @param p_rsp     (I) modbus response frame
 * @param rsp_size  (I) modbus response frame size
 * @return -1 : error, >0 : lenght of sending data
 *****************************************************************************/
int32_t user_modbus_parse(uint32_t index, uint32_t func, const uint8_t *p_req,
                                              uint8_t *p_rsp, int32_t rsp_size)
{
	int32_t result = -1;
	uint16_t reg_addr;
	uint16_t reg_num;
	const uint8_t *p_data = NULL;
	half_word_t temp;

	if((p_req == NULL) || (p_rsp == NULL))
	{
		return result;
	}

	temp.bytes.high = p_req[0];
	temp.bytes.low  = p_req[1];
	reg_addr = temp.all;
	temp.bytes.high = p_req[2];
	temp.bytes.low  = p_req[3];
	reg_num  = temp.all;

	switch(func)
	{
		case MODBUS_READ_HOLDING_REGISTERS:
			result  = read_hold_reg(reg_addr, reg_num, p_rsp);
			break;
		case MODBUS_WRITE_SINGLE_REGISTER:
			reg_num = 1;
			p_data  = p_req + 2;
			result  = write_hold_reg(reg_addr, reg_num, p_data);
			// addr
			p_rsp[0] = p_req[0];
			p_rsp[1] = p_req[1];
			// num
			p_rsp[2] = p_req[2];
			p_rsp[3] = p_req[3];
			break;
		case MODBUS_WRITE_MULTIPLE_REGISTERS:
			p_data = p_req + 5;
			result = write_hold_reg(reg_addr, reg_num, p_data);
			// addr
			p_rsp[0] = p_req[0];
			p_rsp[1] = p_req[1];
			// num
			p_rsp[2] = p_req[2];
			p_rsp[3] = p_req[3];
			break;
		default:
			break;
	}

	return result;
}

/******************************************************************************
 * read_hold_reg()
 * slave read holding regs. [Called by modbus parse function.]
 *
 * @param reg_addr  (I) register start address
 * @param reg_num   (I) register numbers
 * @param p_rsp     (I) modbus response frame
 * @return -1 : error, >0 : length of sending data
 *****************************************************************************/
int32_t read_hold_reg(uint16_t reg_addr, uint16_t reg_num, uint8_t *p_rsp)
{
//	uint16_t i;
//	uint16_t addr_end;
//	uint16_t pointer = 1;
	int32_t result = -1;
//	half_word_t temp;

//	*p_rsp = reg_num * 2;
//	addr_end = reg_addr + reg_num;

//	if(reg_hold_buf_rw == DATA_FREE)
//	{
//		reg_hold_buf_rw = DATA_READING;
//		for(i = reg_addr; i < addr_end; i++)
//		{
//			if(i == CSU_HMI_COMM_LED_REG_ADDR)
//			{
//				(*reg_hold[i]) ^= 1;
//			}
//
//			temp.all = *reg_hold[i];
//			*(p_rsp + pointer++) = temp.bytes.high;
//			*(p_rsp + pointer++) = temp.bytes.low;
//		}
//		reg_hold_buf_rw = DATA_FREE;
//		result = pointer;
//	}

	return result;
}

/******************************************************************************
 * write_hold_reg()
 * slave write holding regs. [Called by modbus parse function.]
 *
 * @param reg_addr  (I) register start address
 * @param reg_num   (I) register numbers
 * @param p_data    (I) writing data
 * @return -1 : error, >0 : lenght of writing data
 *****************************************************************************/
int32_t write_hold_reg(uint16_t reg_addr, uint16_t reg_num, const uint8_t *p_data)
{
	int32_t result = -1;
	int32_t ret    = 4;
	uint16_t reg_value;
	uint8_t i;
	half_word_t temp;

	if(reg_hold_buf_rw == DATA_FREE)
	{
		reg_hold_buf_rw = DATA_WRITING;
		for(i = 0; i < reg_num; i++)
		{
			temp.bytes.high = *p_data;
			temp.bytes.low  = *(p_data + 1);
			reg_value = temp.all;
			result = mod_pcsm_set(reg_addr, reg_value, p_data);
			reg_addr++;
			p_data = p_data + 2;
			if(result == -1)
			{
				ret = -1;
			}
		}
		reg_hold_buf_rw = DATA_FREE;
	}
	else
	{
		ret = 0;
	}

	return ret;
}

/******************************************************************************
 * memory_copy_rs485().
 * copy memory data. [Called by app.]
 *
 * @param dest (O) data buffer of destination.
 * @param src (I) data buffer of source.
 * @param num (I) number of data.
 * @return none
 *****************************************************************************/
void memory_copy_rs485(void *dest, const uint8_t *src, uint32_t num)
{
	uint32_t i;
	uint8_t *dest_temp = NULL;
	uint8_t *src_temp = NULL;

	if(!src || !dest || !num)
	{
		return;
	}

	dest_temp = (uint8_t *)dest;
	src_temp = (uint8_t *)src;

	for(i = 0; i < num; i += 2)
	{
		dest_temp[i] = src_temp[i+1];
		dest_temp[i+1] = src_temp[i];
	}
}

/******************************************************************************
 * mod_pcsm_set()
 * modbus setting pcsm. [Called by write hold regs function.]
 *
 * @param reg_addr  (I) register address
 * @param reg_value (I) register value
 * @param p_data    (I) receive data array
 * @return -1 : error, >0 : lenght of writing data
 *****************************************************************************/
int32_t mod_pcsm_set(uint16_t reg_addr, uint16_t reg_value, const uint8_t *p_data)
{
	int32_t  result = 2;
	int16_t  value;
	uint16_t offset;
	uint16_t id;
	uint16_t *temp_value;
	int16_t  *temp_int_value;
	mods_cmd_t mods_cmd_temp;

	if((reg_addr >= PCSM_SET_START_REGS_ADDR) &&
	   (reg_addr <= PCSM_SET_END_REGS_ADDR))
	{
		offset = (reg_addr - PCSM_SET_START_REGS_ADDR) % PCSM_SET_CMD_NUM;
		id = (reg_addr - PCSM_SET_START_REGS_ADDR) / PCSM_SET_CMD_NUM;
		mods_cmd_temp.id = id + 1;

		switch(offset)
		{
			case HMI_PCSM_RUN:
				temp_value = &array.pcsc.pcsc_data.pcsm_data[id].set[1].pcs_run;
				if((reg_value <= 1) && (*temp_value != reg_value))
				{
					*temp_value = reg_value;
					mods_cmd_temp.cmd = HMI_PCSM_RUN;
					fifo_mods_push(&fifo_mods_cmd, &mods_cmd_temp);
				}
				break;
			case HMI_PCSM_OPT_MODE:
				temp_value = &array.pcsc.pcsc_data.pcsm_data[id].set[1].pcs_operation_mode;
				if((reg_value <= 4) && (*temp_value != reg_value))
				{
					*temp_value = reg_value;
					mods_cmd_temp.cmd = HMI_PCSM_OPT_MODE;
					fifo_mods_push(&fifo_mods_cmd, &mods_cmd_temp);
				}
				break;
			case HMI_PCSM_BUS_VOLT_REF:
				temp_value = &array.pcsc.pcsc_data.pcsm_data[id].set[1].bus_volt_ref;
				if((reg_value >= 1000) && (reg_value <= 1500) && (*temp_value != reg_value))
				{
					*temp_value = reg_value;
					mods_cmd_temp.cmd = HMI_PCSM_BUS_VOLT_REF;
					fifo_mods_push(&fifo_mods_cmd, &mods_cmd_temp);
				}
			default:
				sdk_log_d("modbus set rsvd regs!\r\n");
				break;
		}
	}
	else if(reg_addr == PCSC_SET_PCMD_ADDR)
	{
		value = (int16_t)reg_value;
		temp_int_value = &array.pcsc.pcsc_ctrl.active_power_ref;
		// 8 PCSMs, all_active_power limit: -1896kW ~ 1896kW
		if((value >= -18960) && (value <= 18960) && (*temp_int_value != value))
		{
			*temp_int_value = value;
			mods_cmd_temp.id = HMI_PCSM_BCAST_ID;
			mods_cmd_temp.cmd = HMI_PCSM_ACTIVE_POW;
			fifo_mods_push(&fifo_mods_cmd, &mods_cmd_temp);
		}
	}
	else if(reg_addr == PCSC_SET_ONOFF_ADDR)
	{
		temp_value = &array.pcsc.pcsc_ctrl.pcsc_on_off;
		if((reg_value <= 1) && (*temp_value != reg_value))
		{
			*temp_value = reg_value;
		}
	}
	else if(reg_addr == PCSC_SET_PWM_ADDR)
	{
		if(reg_value <= 1)
		{
//			array.pcsc.pcsc_ctrl.pwm_enable = reg_value;
		}
	}
	else if(reg_addr == PCSC_SET_OPT_MODE_ADDR)
	{
		temp_value = &array.pcsc.pcsc_ctrl.pcs_operation_mode;
		if((reg_value <= 4) && (*temp_value != reg_value))
		{
			*temp_value = reg_value;
			mods_cmd_temp.id = HMI_PCSM_BCAST_ID;
			mods_cmd_temp.cmd = HMI_PCSM_OPT_MODE;
			fifo_mods_push(&fifo_mods_cmd, &mods_cmd_temp);
		}
	}
	else if(reg_addr == PCSC_SET_BUS_VOLT_REF_ADDR)
	{
		temp_value = &array.pcsc.pcsc_ctrl.bus_volt_ref;
		if((reg_value >= 1000) && (reg_value <= 1500) && (*temp_value != reg_value))
		{
			*temp_value = reg_value;
			mods_cmd_temp.id = HMI_PCSM_BCAST_ID;
			mods_cmd_temp.cmd = HMI_PCSM_BUS_VOLT_REF;
			fifo_mods_push(&fifo_mods_cmd, &mods_cmd_temp);

		}
	}
	else if(reg_addr == PCSC_SET_RESET_CMD_ADDR)
	{
		temp_value = &array.pcsc.pcsc_ctrl.reset_cmd;
		if((reg_value <= 1) && (*temp_value != reg_value))
		{
			*temp_value = reg_value;
			mods_cmd_temp.id = HMI_PCSM_BCAST_ID;
			mods_cmd_temp.cmd = HMI_RESET_CMD;
			fifo_mods_push(&fifo_mods_cmd, &mods_cmd_temp);
		}
	}
	else if(reg_addr == PCSC_STATE_START_REGS_ADDR)
	{
		temp_value = &array.pcsc.pcsc_ctrl.do_ctrl.all;
		if(reg_value != *temp_value)
		{
			*temp_value = reg_value;
		}
	}
	else if((reg_addr >= PCSM_GROUP_SET_ADDR) &&
		   (reg_addr <= PCSM_GROUP_SET_ADDR + 9))
	{
		id = (reg_addr - PCSM_GROUP_SET_ADDR) / PCSM_GROUP_CMD_NUM;
		offset = (reg_addr - PCSM_GROUP_SET_ADDR) % PCSM_GROUP_CMD_NUM;
		switch(offset)
		{
			case HMI_PCSM_RUN:
				pcsm_group[id].pcs_run = reg_value;
				mods_cmd_temp.cmd = HMI_PCSM_RUN;
				break;
			case HMI_PCSM_ACTIVE_POW:
				pcsm_group[id].active_power_ref = reg_value;
				mods_cmd_temp.cmd = HMI_PCSM_ACTIVE_POW;
				break;
			default:
				break;
		}
		if(id == 0)
		{
			mods_cmd_temp.id = HMI_PCSM_GROUP1_ID;
		}
		else
		{
			mods_cmd_temp.id = HMI_PCSM_GROUP2_ID;
		}
		fifo_mods_push(&fifo_mods_cmd, &mods_cmd_temp);
	}
	else if(reg_addr == PCS_SYS_ENERGY_CLEAR_ADDR)
	{
		if(reg_value == 1)
		{
			energy_rec_clear();
		}
	}
	else if(reg_addr == CALIB_T_AC_FUSE_ADDR)
	{
		memory_copy_rs485(&calibrate.dc[CALI_AC_FUSE_TEMP].x1, p_data, CALIB_DC_DATA_LEN * 2);
		calibrate_dc(CALI_AC_FUSE_TEMP);
	}
	else if(reg_addr == CALIB_T_DC_FUS1_ADDR)
	{
		memory_copy_rs485(&calibrate.dc[CALI_DC1_FUSE_TEMP].x1, p_data, CALIB_DC_DATA_LEN * 2);
		calibrate_dc(CALI_DC1_FUSE_TEMP);
	}
	else if(reg_addr == CALIB_T_DC_FUS2_ADDR)
	{
		memory_copy_rs485(&calibrate.dc[CALI_DC2_FUSE_TEMP].x1, p_data, CALIB_DC_DATA_LEN * 2);
		calibrate_dc(CALI_DC2_FUSE_TEMP);
	}
	else if(reg_addr == CALIB_V_DC1_ADDR)
	{
		memory_copy_rs485(&calibrate.dc[CALI_VBUS1].x1, p_data, CALIB_DC_DATA_LEN * 2);
		calibrate_dc(CALI_VBUS1);
	}
	else if(reg_addr == CALIB_V_DC2_ADDR)
	{
		memory_copy_rs485(&calibrate.dc[CALI_VBUS2].x1, p_data, CALIB_DC_DATA_LEN * 2);
		calibrate_dc(CALI_VBUS2);
	}
	else if(reg_addr == CALIB_V_PCS_RS_ADDR)
	{
		memory_copy_rs485(&calibrate.ac[CALI_VGRID_RS].x, p_data, CALIB_AC_DATA_LEN * 2);
		calibrate_ac(CALI_VGRID_RS);
	}
	else if(reg_addr == CALIB_V_PCS_ST_ADDR)
	{
		memory_copy_rs485(&calibrate.ac[CALI_VGRID_ST].x, p_data, CALIB_AC_DATA_LEN * 2);
		calibrate_ac(CALI_VGRID_ST);
	}
	else if(reg_addr == CALIB_V_PCS_TR_ADDR)
	{
		memory_copy_rs485(&calibrate.ac[CALI_VGRID_TR].x, p_data, CALIB_AC_DATA_LEN * 2);
		calibrate_ac(CALI_VGRID_TR);
	}
	else if(reg_addr == CALIB_V_GRD_RS_ADDR)
	{
		memory_copy_rs485(&calibrate.ac[CALI_VPCS_RS].x, p_data, CALIB_AC_DATA_LEN * 2);
		calibrate_ac(CALI_VPCS_RS);
	}
	else if(reg_addr == CALIB_V_GRD_ST_ADDR)
	{
		memory_copy_rs485(&calibrate.ac[CALI_VPCS_ST].x, p_data, CALIB_AC_DATA_LEN * 2);
		calibrate_ac(CALI_VPCS_ST);
	}
	else if(reg_addr == CALIB_V_GRD_TR_ADDR)
	{
		memory_copy_rs485(&calibrate.ac[CALI_VPCS_TR].x, p_data, CALIB_AC_DATA_LEN * 2);
		calibrate_ac(CALI_VPCS_TR);
	}
	else if(reg_addr == CALIB_I_OUT_R_ADDR)
	{
		memory_copy_rs485(&calibrate.ac[CALI_CURRENT_R].x, p_data, CALIB_AC_DATA_LEN * 2);
		calibrate_ac(CALI_CURRENT_R);
	}
	else if(reg_addr == CALIB_I_OUT_S_ADDR)
	{
		memory_copy_rs485(&calibrate.ac[CALI_CURRENT_S].x, p_data, CALIB_AC_DATA_LEN * 2);
		calibrate_ac(CALI_CURRENT_S);
	}
	else if(reg_addr == CALIB_I_OUT_T_ADDR)
	{
		memory_copy_rs485(&calibrate.ac[CALI_CURRENT_T].x, p_data, CALIB_AC_DATA_LEN * 2);
		calibrate_ac(CALI_CURRENT_T);
	}
	else if(reg_addr == CALIB_POWER_P_ADDR)
	{
		memory_copy_rs485(&calibrate.ac[CALI_POWER_P].x, p_data, CALIB_AC_DATA_LEN * 2);
		calibrate_ac(CALI_POWER_P);
	}
	else if(reg_addr == CALIB_POWER_Q_ADDR)
	{
		memory_copy_rs485(&calibrate.ac[CALI_POWER_Q].x, p_data, CALIB_AC_DATA_LEN * 2);
		calibrate_ac(CALI_POWER_Q);
	}
	else if(reg_addr == CALIB_POWER_S_ADDR)
	{
		memory_copy_rs485(&calibrate.ac[CALI_POWER_S].x, p_data, CALIB_AC_DATA_LEN * 2);
		calibrate_ac(CALI_POWER_S);
	}
	else if((reg_addr >= CALIB_T_AC_FUSE_ADDR) &&
			(reg_addr < CALIB_POWER_S_ADDR + CALIB_AC_DATA_LEN))
	{

	}
	else
	{
		result = -1;
		sdk_log_d("modbus set pcsm wrong!\r\n");
	}

	return result;
}

/******************************************************************************
 * slow_task_rs485_hmi()
 * HMI debug module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void slow_task_rs485_hmi(void)
{
//	uint8_t p_req[MOD_FRAME_MAX_NUM] = {0};
//	int32_t data_num;
	mods_cmd_t mods_cmd_temp;
	bool_t flag;
	uint16_t id;
	uint16_t cmd_offset;

//	data_num = sdk_modbus_receive(RS485_HMI, hmi_rx_buf);
//	if(data_num > 0)
//	{
//		sdk_modbus_reply(RS485_HMI, hmi_rx_buf, data_num, user_modbus_parse);
//	}
//	//if HMI is not connected, many trash infos printed in debug serial port, better delete it
//	else if(data_num < 0)
//	{
//		sdk_log_d("modbus receive failed!\r\n");
//	}

	flag = fifo_mods_pop(&fifo_mods_cmd, &mods_cmd_temp);
	if(flag)
	{
		id = mods_cmd_temp.id;
		cmd_offset = mods_cmd_temp.cmd;
//		hmi_csu_send_cmd2pcsm(id, cmd_offset);
		csu_cmd_pcsm(id, cmd_offset);
	}
}

/******************************************************************************
* End of module
******************************************************************************/
