/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     pcsc_opt_log.c
  * @brief    pcsc opeartion or event log module
  * @company  SOFARSOLAR
  * @author   WWX
  * @note
  * @version  V01
  * @date     2023/06/19
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------
#include <stdarg.h>

// Include project file ------------------------------------------------------
#include "array.h"
#include "fifo_log.h"
#include "measure.h"
#include "pcsc_opt_log.h"
#include "pcsc_diag_log.h"
#include "pcs.h"
#include "sdk_core.h"
#include "sdk.h"
#include "can1_bus.h"
#include "rs485_meter.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/
/******************************************************************************
 * pcsc_opt_log_init().
 * Initialize pcsc operation or event log of modules. [Called by sw init function.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void pcsc_opt_log_init(void)
{
	int32_t ret;

	ret = sdk_record_init(OPAT_LOG, ONE_OPAT_LOG_SIZE, MAX_OPAT_LOG_NUMS);
	if(ret != SF_OK)
	{
		sdk_log_d("opeation or event log init error!\r\n");
	}
	else
	{
		sdk_log_d("opeation or event log init ok!\r\n");
	}

	ret = sdk_record_init(DEBUG_LOG, ONE_DEBUG_LOG_SIZE, MAX_DEBUG_LOG_NUMS);
	if(ret != SF_OK)
	{
		sdk_log_d("debug log init error!\r\n");
	}
	else
	{
		sdk_log_d("debug log init ok!\r\n");
	}
}

/******************************************************************************
 * opt_log_record().
 * write log. [Called by.]
 *
 * @param none  (I)
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void opt_log_record(const char *p_format, ...)
{
	va_list aptr;

	sdk_log_a("%s\r\n", opt_log_info);
	va_start(aptr, p_format);
	clear_struct_data(opt_log_info, ONE_OPAT_LOG_SIZE * 2);
	vsprintf((char*)opt_log_info, p_format, aptr);
	va_end(aptr);
	app_log_write(opt_log_info, OPAT_LOG);
}

/******************************************************************************
 * debug_log_record().
 * write log. [Called by.]
 *
 * @param none  (I)
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void debug_log_record(const char *p_format, ...)
{
	va_list aptr;

	va_start(aptr, p_format);
	clear_struct_data(debug_log_info, ONE_DEBUG_LOG_SIZE * 2);
	vsprintf((char*)debug_log_info, p_format, aptr);
	va_end(aptr);
	app_log_write(debug_log_info, DEBUG_LOG);
	sdk_log_a("%s\r\n", debug_log_info);
}

/******************************************************************************
* End of module
******************************************************************************/
