/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     rs485_dehumidification.c
  * @brief    Dehumidification module
  * @company  ANDEANSOLAR
  * @author   ZZJ
  * @note
  * @version  V01
  * @date     2023/09/16
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "array.h"
#include "rs485_dehumidification.h"
#include "sdk.h"
#include "sdk_core.h"
#include "pcsc_diag.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
// TODOReturn difference

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
int16_t fault_dehumidifier_cnt;
int16_t fault_dehumidifier_ref;
bool_t trigger_dehumidifier;
uint16_t dehumidifier_buff[16];
dehumidifier_data_t dehumidifier_data;
dehumidifier_set_t dehumidifier_set;
rs485_settting_parm_t rs485_dehumidification_parm;
bool_t dehunidification_set_param_flag = FALSE;
uint16_t dehunidification_model_code = 0;
/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

bool_t dehumidification_read_fun_brim(void);
bool_t dehumidification_read_fun_andean(void);
bool_t dehumidification_set_fun_brim(void);
bool_t dehumidification_set_fun_andean(void);

// Read data using
bool_t (*dehumidification_read_fun_ptr[2])(void) =
{
	dehumidification_read_fun_brim,
	dehumidification_read_fun_andean,
};
// set data using
bool_t (*dehumidification_set_fun_ptr[2])(void) =
{
	dehumidification_set_fun_brim,
	dehumidification_set_fun_andean,
};

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/
/******************************************************************************
 * rs485_dehumidification_init().
 * Initialize dehumidification debug module. [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_dehumidification_init(void)
{
	rs485_dehumidification_parm.port = RS485_DEHUM;
	rs485_dehumidification_parm.slave_addr = RS485_DEHUM_SLAVE_ADDR;
	rs485_dehumidification_parm.baud = MODBUS_BAUD_9600;
	rs485_dehumidification_parm.timeout = 300;
	modbus_init(rs485_dehumidification_parm);

	fault_dehumidifier_cnt = 0;
	fault_dehumidifier_ref = 10;
	dehunidification_set_param_flag = FALSE;
	trigger_dehumidifier = array.pcsc.pcsc_ctrl.rs485_enable.bit.dehumidifier;
	dehunidification_model_code = 0;
	clear_struct_data((uint8_t*)&dehumidifier_buff[0], sizeof(dehumidifier_buff));
	clear_struct_data((uint8_t*)&dehumidifier_data, sizeof(dehumidifier_data));
}
/******************************************************************************
 * dehumidification_read_fun_brim().
 * 读取除湿器温度湿度 [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
bool_t dehumidification_read_fun_brim(void)
{
	int16_t ret;
	bool_t return_value = FALSE;

	ret = sdk_modbus_registers_read(RS485_DEHUM, 0x0C, 2, &dehumidifier_buff[0]);
	if(ret == 2)
	{
		return_value = TRUE;
		fault_dehumidifier_cnt = 0;
		dehumidifier_data.temperature = dehumidifier_buff[0] * PARAMETER_ACCURACY_MAGNIFICATION_4;
		dehumidifier_data.humidity = dehumidifier_buff[1] * PARAMETER_ACCURACY_MAGNIFICATION_4;
	}
	return return_value;
}
/******************************************************************************
 * dehumidification_read_fun_andean().
 * 读取除湿器温度湿度 [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
bool_t dehumidification_read_fun_andean(void)
{
	int16_t ret;
	bool_t return_value = FALSE;

	ret = sdk_modbus_registers_read(RS485_DEHUM, 0x01, 2, &dehumidifier_buff[0]);
	if(ret == 2)
	{
		return_value = TRUE;
		fault_dehumidifier_cnt = 0;
		dehumidifier_data.humidity = dehumidifier_buff[0];
		dehumidifier_data.temperature = dehumidifier_buff[1] * PARAMETER_ACCURACY_MAGNIFICATION_4;
	}
	return return_value;
}
/******************************************************************************
 * dehumidification_read_fun_andean().
 * 设置除湿器工作参数 [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
bool_t dehumidification_set_fun_brim(void)
{
	int16_t ret;
	bool_t return_value = FALSE;

	ret = sdk_modbus_registers_read(RS485_DEHUM, 0x01, DEHUM_DATA_LEN_BRIM, &dehumidifier_buff[0]);
	if(ret == DEHUM_DATA_LEN_BRIM)
	{
		return_value = TRUE;
		fault_dehumidifier_cnt = 0;
		if(dehumidifier_buff[DEHUM_AUTO_MODE_ADDR_BRIM - 1] != DEHUM_AUTO_MODE_VALUE_BRIM)
		{
			sdk_modbus_register_write(RS485_DEHUM, DEHUM_AUTO_MODE_ADDR_BRIM, DEHUM_AUTO_MODE_VALUE_BRIM);
		}
		else if(dehumidifier_buff[DEHUM_RN_ADDR_BRIM - 1] != dehumidifier_set.humidity_set)
		{
			sdk_modbus_register_write(RS485_DEHUM, DEHUM_RN_ADDR_BRIM, dehumidifier_set.humidity_set);
		}
		else if(dehumidifier_buff[DEHUM_RETURN_DIFFERENCE_ADDR_BRIM - 1] != dehumidifier_set.humidity_diff_set)
		{
			sdk_modbus_register_write(RS485_DEHUM, DEHUM_RETURN_DIFFERENCE_ADDR_BRIM, dehumidifier_set.humidity_diff_set);
		}
		else
		{
			dehunidification_set_param_flag = TRUE;
		}
	}
	return return_value;
}
/******************************************************************************
 * dehumidification_read_fun_andean().
 * 设置除湿器工作参数 [Called by main initial stage.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
bool_t dehumidification_set_fun_andean(void)
{
	int16_t ret;
	bool_t return_value = FALSE;

	ret = sdk_modbus_registers_read(RS485_DEHUM, DEHUM_AUTO_MODE_ADDR_ANDEAN, DEHUM_DATA_LEN_ANDEAN, &dehumidifier_buff[0]);
	if(ret == DEHUM_DATA_LEN_ANDEAN)
	{
		return_value = TRUE;
		fault_dehumidifier_cnt = 0;
		if(dehumidifier_buff[DEHUM_AUTO_MODE_ADDR_ANDEAN - DEHUM_AUTO_MODE_ADDR_ANDEAN] != DEHUM_AUTO_MODE_VALUE_ANDEAN)
		{
			sdk_modbus_register_write(RS485_DEHUM, DEHUM_AUTO_MODE_ADDR_ANDEAN, DEHUM_AUTO_MODE_VALUE_ANDEAN);
		}
		else if(dehumidifier_buff[DEHUM_RN_ADDR_ANDEAN - DEHUM_AUTO_MODE_ADDR_ANDEAN] != dehumidifier_set.humidity_set)
		{
			sdk_modbus_register_write(RS485_DEHUM, DEHUM_RN_ADDR_ANDEAN, dehumidifier_set.humidity_set);
		}
		else if(dehumidifier_buff[DEHUM_RETURN_DIFFERENCE_ADDR_ANDEAN - DEHUM_AUTO_MODE_ADDR_ANDEAN] != dehumidifier_set.humidity_diff_set)
		{
			sdk_modbus_register_write(RS485_DEHUM, DEHUM_RETURN_DIFFERENCE_ADDR_ANDEAN, dehumidifier_set.humidity_diff_set);
		}
		else
		{
			dehunidification_set_param_flag = TRUE;
		}
	}
	return return_value;
}
/******************************************************************************
 * rs485_task_dehumidification()
 * dehumidification module. [Called by task.]
 *
 * @param none (I)
 * @return none
 *****************************************************************************/
void rs485_task_dehumidification(void)
{
	int16_t ret;

	if(FALSE == dehunidification_set_param_flag)
	{
		ret = sdk_modbus_registers_read(RS485_DEHUM, DEHUM_MODEL_READ, ONE_BYTE_LEN, &dehumidifier_buff[0]);
		if((ret == ONE_BYTE_LEN) && (dehumidifier_buff[0] == DEHUM_MODEL_READ_VALUE))
		{
			sdk_log_a("dehum = andean\n");
			dehunidification_model_code = DEHUMIDIFIERPOINT_MODEL_ANDEAN;
		}
		else
		{
			sdk_log_a("dehum = brim\n");
			dehunidification_model_code = DEHUMIDIFIERPOINT_MODEL_BRIM;
		}
		sdk_delay_ms(10);
		ret = dehumidification_set_fun_ptr[dehunidification_model_code]();
	}
	else
	{
		ret = dehumidification_read_fun_ptr[dehunidification_model_code]();
	}

	if (ret == FALSE)
	{
		sdk_modbus_flush(RS485_DEHUM);
		if(fault_dehumidifier_cnt <= fault_dehumidifier_ref)
		{
			fault_dehumidifier_cnt++;
		}
		else
		{
			dehunidification_set_param_flag = FALSE;
			clear_struct_data((uint8_t*)&dehumidifier_data, sizeof(dehumidifier_data));
		}
	}

}

/******************************************************************************
* End of module
******************************************************************************/
