/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     iec104.c
  * @brief    iec104 app module
  * @company  SOFARSOLAR
  * @author   QWB
  * @note
  * @version  V01
  * @date     2023/06/18
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "app_dido.h"
#include "array.h"
#include "calibration.h"
#include "common.h"
#include "csu_data.h"
#include "cup_sofar_can.h"
#include "device.h"
#include "iec104.h"
#include "pcs.h"
#include "pcsc_diag.h"
#include "pcsc_diag_log.h"
#include "pcsc_opt_log.h"
#include "sdk.h"
#include "sdk_core.h"
#include "sdk_iec104.h"
#include "can1_bus.h"
#include "power_manage.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
sdk_iec104_info_t sdk_iec104_info;

// Temporary variable for iec104 communication
uint8_t remote_signal_array[16];
uint16_t telemet_normal_array[30];
float32_t telemet_float_array[20];
uint16_t pcs_totle_array[6] = {0}; // setting parameter array
float32_t circ_temper_array[50]={0};

// Temporary variable for receive calibrate data
float32_t factory_test_data[10]={0};
float32_t continu_data[50]={0};
uint16_t para_intger_data[10]={0};

uint8_t remote_control[10] = {0};
uint16_t can_temp_data[32] = {0};

sdk_iec104_signal_info_t iec104_signal_info[] =
{
    {remote_signal_array, 0xD32, sizeof(remote_signal_array)},
};

sdk_iec104_dectect_info_t iec104_dectect_info[] =
{
    {telemet_normal_array, 0x14202, sizeof(telemet_normal_array) / sizeof(telemet_normal_array[1])},
//	{fut_integer_array, 0x600280, sizeof(fut_integer_array) / sizeof(fut_integer_array[1])},
};

sdk_iec104_para_info_t iec104_para_info[] =
{
	{pcs_totle_array, 0x8241, sizeof(pcs_totle_array) / sizeof(pcs_totle_array[0]), sizeof(pcs_totle_array[0])},
	{circ_temper_array, 0x600201, sizeof(circ_temper_array) / sizeof(circ_temper_array[0]), sizeof(circ_temper_array[0])},
};

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/******************************************************************************
 * @brief   para_set()
 * @param   [in] addr     value
 * @param   [in] p_value  value
 * @param   [in] len      value
 * @note    Setting of constant value parameters [Called by the core]
 * @return   0:right ;  <0:error
 *****************************************************************************/
int32_t para_set(uint32_t addr, void *p_value, uint8_t len)
{
	sdk_iec104_para_info_t *tmp = &iec104_para_info[0];
	uint16_t i = 0;
	uint16_t sizes = 0;
	pcsm_cmd_t can_cmd_temp;

    clear_struct_data((uint8_t *)&can_cmd_temp, sizeof(pcsm_cmd_t));
	can_cmd_temp.fun_code = PCS_CMD_SET_PARAMETER;
	can_cmd_temp.len = 1;
	sizes = sizeof(iec104_para_info) / sizeof(iec104_para_info[0]);
    for(i = 0; i < sizes; i++)
    {
		if((addr >= tmp->para_addr) && (addr < (tmp->para_addr + tmp->para_num)))
		{
//			if((addr >= TEST_START_ADDR) && (addr <= TEST_END_ADDR))
//			{
//				fut.calib_var.test_addr = addr;

//				// u16
//				if(((addr >=  0x600201) && (addr <=  0x600204)) || ((addr >=  0x600207) && (addr <=  0x600208)) ||
//				   ((addr >=  0x60020B) && (addr <=  0x60020C)) || ((addr >=  0x60020F) && (addr <=  0x600210)) ||
//				   ((addr >=  0x600213) && (addr <=  0x600214)) || ((addr >=  0x600217) && (addr <=  0x600218)))
//				{
//					memcpy((uint8_t*)tmp->p_para_dat + ((addr - tmp->para_addr) * len), p_value, len);
//					memcpy(&para_intger_data[0], (uint8_t*)tmp->p_para_dat + ((addr - tmp->para_addr) * len), len);
//				}

//				// float32
//				else if(((addr >=  0x600205) && (addr <=  0x600206)) || ((addr >=  0x600209) && (addr <=  0x60020A)) ||
//						((addr >=  0x60020D) && (addr <=  0x60020E)) || ((addr >=  0x600211) && (addr <=  0x600212)) ||
//						((addr >=  0x600215) && (addr <=  0x600216)))
//				{
//					memcpy((uint8_t*)tmp->p_para_dat + ((addr - tmp->para_addr) * len), p_value, len);
//					memcpy(&factory_test_data[0], (uint8_t*)tmp->p_para_dat + ((addr - tmp->para_addr) * len), len);
//				}
//				if((addr >= 0x600219) && (addr <= 0x600230))
//				{
//				    memcpy((uint8_t*)tmp->p_para_dat + ((addr - tmp->para_addr)*len), p_value, len);
//					memcpy(&continu_data[0], (uint8_t*)tmp->p_para_dat + ((addr - tmp->para_addr) * len), len);
//				}

//				if(addr == TEST_START_ADDR)
//				{
//					csu_data.csu_heart.working_mode = para_intger_data[0];
//				}
//				else if(addr == 0x600202)
//				{
//					fut.calib_var.led_state = para_intger_data[0];
//				}
//				else if(addr == 0x600203)
//				{
//					fut.calib_var.dry_contact = para_intger_data[0];

//				}else if(addr == 0x600204)
//				{
//					fut.calib_var.test_result = para_intger_data[0];
//				}

////				if(csu_data.csu_heart.working_mode == FCT_MODE)
////				{

////				    if((addr == 0x600205) || (addr == 0x600209) ||
////					   (addr == 0x60020D) || (addr == 0x600211) || (addr == 0x600215))
////					{
////						fut.calib_var.input_4_cnt++;
////						fut.calib_var.meter_array[0] = (factory_test_data[0]) * NTC_PRECISION;
////					}
////					else if((addr == 0x600206) || (addr == 0x60020A) ||
////						    (addr == 0x60020E) || (addr == 0x600212) || (addr == 0x600216))
////					{
////						fut.calib_var.input_4_cnt++;
////						fut.calib_var.meter_array[1] = (factory_test_data[0]) * NTC_PRECISION;
////					}
////					else if((addr == 0x600207) || (addr == 0x60020B) ||
////						    (addr == 0x60020F) || (addr == 0x600213) || (addr == 0x600217))
////					{
////						fut.calib_var.input_4_cnt++;
////						fut.calib_var.sample_array[0] = para_intger_data[0];
////					}
////					else if((addr == 0x600208) || (addr == 0x60020C) ||
////						    (addr == 0x600210) || (addr == 0x600214) || (addr == 0x600218))
////					{
////						fut.calib_var.input_4_cnt++;
////						fut.calib_var.sample_array[1] = para_intger_data[0];
////					}
////					else if((addr == 0x600219) || (addr == 0x60021B) || (addr == 0x60021D) || (addr == 0x60021F) ||
////					        (addr == 0x600221) || (addr == 0x600223) || (addr == 0x600225) || (addr == 0x600227) ||
////				            (addr == 0x600229) || (addr == 0x60022B) || (addr == 0x60022D) || (addr == 0x60022F))
////					{
////						fut.calib_var.series_array[0] = (continu_data[0]) * SAMPLING_PRECISION;
////						fut.calib_var.input_2_cnt++;
////					}
////				    else if((addr == 0x60021A) || (addr == 0x60021C) || (addr == 0x60021E) || (addr == 0x600220) ||
////					        (addr == 0x600222) || (addr == 0x600224) || (addr == 0x600226) || (addr == 0x600228) ||
////				            (addr == 0x60022A) || (addr == 0x60022C) || (addr == 0x60022E) || (addr == 0x600230))
////					{
////						fut.calib_var.series_array[1] = (continu_data[0]) * SAMPLING_PRECISION;
////						fut.calib_var.input_2_cnt++;
////					}
////				}
//			}
			if((addr >= 0x8241) && (addr <= 0x84C7) && (len == tmp->para_size))
			{
				memcpy((uint8_t*)tmp->p_para_dat + ((addr - tmp->para_addr)*len), p_value, len);
				memcpy(&can_temp_data[0], (uint8_t*)tmp->p_para_dat + ((addr - tmp->para_addr) * len), len);

                if(array.pcsc.pcsc_ctrl.power_control_source == CONTROL_NETWORK_MODE)
                {
                    if((addr == 0x8241) && (addr < (tmp->para_addr + tmp->para_num)))
                    {
						if(0 == can_temp_data[0])
						{
							opt_log_record("set power from 104, value:%d -> %d", \
										array.pcsc.pcsc_ctrl.active_power_ref, can_temp_data[0]);
							sdk_log_a("set power from 104, value:%d -> %d\r\n", \
										array.pcsc.pcsc_ctrl.active_power_ref, can_temp_data[0]);
						}
						g_active_power_send = TRUE;
                        can_cmd_temp.dst_addr = PCSM_BCAST_ID;
                        array.pcsc.pcsc_ctrl.active_power_ref = can_temp_data[0];
                    }
                    else if((addr == 0x8242) && (addr < (tmp->para_addr + tmp->para_num)))
                    {
						g_reactive_power_send = TRUE;
                        can_cmd_temp.dst_addr = PCSM_BCAST_ID;
                        array.pcsc.pcsc_ctrl.reactive_power_ref = can_temp_data[0];
                    }
                }
				if(addr == 0x8241)
				{
					can_cmd_temp.offset.all = ACTIVE_POWER_REF;
				}
				else if(addr == 0x8242)
				{
					can_cmd_temp.offset.all = REACTIVE_POWER_REF;
				}
				//fifo_can_push(&fifo_can5_cmd, &can_cmd_temp);
		    }
		}
        tmp++;
    }

    return 0;
}

/******************************************************************************
 * @brief   pcs_iec104_init()
 * @param   none [in]
 * @param   none [in]
 * @param   none [in]
 * @note    Initialization function   [Called by the main()]
 * @return   none (O)
 *******************************************************************************/
void pcs_iec104_init(void)
{
    sdk_iec104_info.p_sdk_iec104_signal_info = iec104_signal_info;
    sdk_iec104_info.signal_info_num = 1;

    sdk_iec104_info.p_sdk_iec104_dectect_info = iec104_dectect_info;
    sdk_iec104_info.dectect_info_num = 1;

//    sdk_iec104_info.p_sdk_iec104_dectect_float_info = iec104_dectect_float_info;
//    sdk_iec104_info.dectect_float_info_num = 0;

    sdk_iec104_info.p_sdk_iec104_para_info = iec104_para_info;
    sdk_iec104_info.para_info_num = sizeof(iec104_para_info) / sizeof(iec104_para_info[0]);

    sdk_iec104_info.para_set = para_set;

    sdk_iec104_init(sdk_iec104_info);
}

/******************************************************************************
 * @brief   fast_task_iec104()
 * @param   none [in]
 * @param   none [in]
 * @param   none [in]
 * @note    Remote signal, remote meter value upload task function
 * @return   none (O)
 *******************************************************************************/
void fast_task_iec104(void)
{
//	fut_telemet_upload();
}

/******************************************************************************
* End of module
******************************************************************************/
