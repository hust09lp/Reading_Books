/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     shell.c
  * @brief
  * @company  SOFARSOLAR
  * @author   GZQ
  * @note
  * @version  V01
  * @date     2023/12/06
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "sdk.h"
#include "sdk_core.h"
#include "shell.h"
#include "fifo_log.h"
#include "common.h"
#include "array.h"
#include "app_thread.h"
#include "device.h"
#include "product.h"
#include "app_dido.h"
#include "rs485_meter.h"
#include "pcsc_diag.h"
#include "sci_mcu1.h"
#include "task_manage.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/
struct finsh_syscall *_syscall_table_begin  = NULL;
struct finsh_syscall *_syscall_table_end    = NULL;
uint8_t shell_buffer[128];

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/
void *msh_get_cmd(char *cmd, int size);

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/
/******************************************************************************
 * function_addr_init().
 * Shell instruction address initialization. [Called by.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void function_addr_init(const void *begin, const void *end)
{
	_syscall_table_begin = (struct finsh_syscall *) begin;
	_syscall_table_end = (struct finsh_syscall *) end;
}

/******************************************************************************
 * shell_init().
 * Shell module init. [Called by.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void shell_init(void)
{
	memset(shell_buffer, 0, sizeof(shell_buffer));
	extern const int FSymTab$$Base;
	extern const int FSymTab$$Limit;
	function_addr_init(&FSymTab$$Base, &FSymTab$$Limit);
	sdk_shell_regist(&msh_get_cmd);
}

/******************************************************************************
 * msh_get_cmd().
 * Shell command registration. [Called by.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void* msh_get_cmd(char *cmd, int size)
{
	struct finsh_syscall *index;
	cmd_function_t cmd_func = NULL;

	for (index = _syscall_table_begin;
			index < _syscall_table_end;
			index++)
	{
		if (strncmp(index->name, cmd, size) == 0 &&
				index->name[size] == '\0')
		{
			cmd_func = (cmd_function_t)index->func;
			break;
		}
	}

	return cmd_func;
}

/******************************************************************************
 * app_help().
 * output command help info. [Called by.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
int app_help(int argc, char **argv)
{
	sdk_log_printf("app shell commands:\n");
	{
		struct finsh_syscall *index;

		for (index = _syscall_table_begin;
				index < _syscall_table_end;
				index++)
		{
			sdk_log_printf("%-16s - %s\n", index->name, index->desc);
		}
	}
	sdk_log_printf("\n");

	return 0;
}
MSH_CMD_EXPORT(app_help, "app shell commands");

/******************************************************************************
 * log_level().
 * set log output level. [Called by.]
 *
 * @param   (I)
 * @return none (O)
 *****************************************************************************/
int log_level(int argc, char **argv)
{
	uint8_t tmp = 0;

	if(2 == argc)
	{
		tmp = *argv[1] - '0';
		if((tmp > LOG_LVL_ALL))
		{
			sdk_log_printf("argument err\n");
		}
		else
		{
			sdk_log_set_level(tmp);
			sdk_log_printf("Log printf level:%d\n",sdk_log_get_level());
		}
	}
	sdk_log_printf("\n");
	return 0;
}
MSH_CMD_EXPORT(log_level, "set log level");

/******************************************************************************
 * log_output().
 * log output. [Called by.]
 *
 * @param param1  (I) 0:DIAG_LOG, 1:OPAT_LOG
 * @param param2  (I) start index
 * @param param3  (I) end index
 * @return none (O)
 *****************************************************************************/
int log_output(int argc, char **argv)
{
	uint8_t log_type = 0;
	uint32_t start = 0;
	uint32_t end = 0;
	uint32_t index = 0;
	uint32_t pack_num = 0;
	uint16_t log_len = 0;
	bool_t trigger_log_output = FALSE;

	if(4 == argc)
	{
		log_type = *argv[1] - '0';
		start = atoi(argv[2]);
		end = atoi(argv[3]);
		if(log_type == OPAT_LOG)
		{
			log_len = ONE_OPAT_LOG_SIZE;
			trigger_log_output = TRUE;
		}
		else if (log_type == DIAG_LOG)
		{
			log_len = ONE_DIAG_LOG_SIZE;
			trigger_log_output = TRUE;
		}
		else if (log_type == DEBUG_LOG)
		{
			log_len = ONE_DEBUG_LOG_SIZE;
			trigger_log_output = TRUE;
		}
		else
		{
			sdk_log_printf("param is invalid\n");
		}

		if(trigger_log_output)
		{
			pack_num = sdk_record_get_index(log_type);
			end = min(pack_num, end);
			start = min(end, start);
			for (index = start; index <= end; index++)
			{
				sdk_record_read(log_type, index, &shell_buffer[0], log_len);
				sdk_delay_ms(1);
				sdk_log_printf("%s", shell_buffer);
			}
		}
	}
	sdk_log_printf("\n");
	return 0;
}
MSH_CMD_EXPORT(log_output, "-- param1 0:DIAG_LOG, 1:OPAT_LOG --param2 start_index param3 end_index ");

/******************************************************************************
 * log_clear().
 * log clear. [Called by.]
 *
 * @param   (I) 
 * @return none (O)
 *****************************************************************************/
int log_clear(int argc, char **argv)
{
	uint8_t tmp = 0;

	if(2 == argc)
	{
		tmp = *argv[1] - '0';
		if(tmp == OPAT_LOG)
		{
			sdk_record_delete(tmp);
		}
		else if (tmp == DIAG_LOG)
		{
			sdk_record_delete(tmp);
		}
		else
		{
			sdk_log_printf("param is invalid\n");
		}
	}
	sdk_log_printf("\n");
	return 0;
}
MSH_CMD_EXPORT(log_clear, "--param1 0:DIAG_LOG, 1:OPAT_LOG");

/******************************************************************************
 * do_control().
 * do control. [Called by.]
 *
 * @param   (I) 
 * @param   (I) 
 * @return none (O)
 *****************************************************************************/
int do_control(int argc, char **argv)
{
	uint8_t index = 0;
	bool_t status = FALSE;

	if(3 == argc)
	{
		trigger_do = TRUE;
		index = atoi(argv[1]);
		status =  *argv[2] - '0';
		if(status == 1)
		{
			array.pcsc.pcsc_ctrl.do_ctrl.all |= (0x01 << index);
		}
		else
		{
			array.pcsc.pcsc_ctrl.do_ctrl.all &= ~(0x01 << index);
		}
	}
	sdk_log_printf("\n");
	return 0;
}
MSH_CMD_EXPORT(do_control, "--param1 port  --param2 output");

/******************************************************************************
 * di_read().
 * read di status. [Called by.]
 *
 * @param   (I) 
 * @return none (O)
 *****************************************************************************/
int di_read(int argc, char **argv)
{
	uint8_t index = 0;
	bool_t status = FALSE;

	if(2 == argc)
	{
		index = atoi(argv[1]);
		status = sdk_dido_read(index);
		sdk_log_printf("DI%d:%d\n",index,status);
	}
	sdk_log_printf("\n");
	return 0;
}
MSH_CMD_EXPORT(di_read, "--param1 port");

/******************************************************************************
 * query_mem().
 * Output data for the specified memory. [Called by.]
 *
 * @param param1  (I) addr
 * @param param2  (I) data type
 * @return none (O)
 *****************************************************************************/
void query_mem(int argc, char**argv)
{
	volatile uint32_t *dest_addr = 0;
	char* endptr;

	dest_addr = (uint32_t *)(strtol(argv[1], &endptr, 16));
	if((*endptr != '\0') || (argc != 3))
	{
		sdk_log_printf("address err or argument err!\r\n");
		return ;
	}

	if(strcmp(argv[2], "uint8_t") == 0)
	{
		uint8_t tmp = *dest_addr;
		sdk_log_printf("%s:%d\r\n",argv[2],tmp);
	}
	else if(strcmp(argv[2], "int16_t") == 0)
	{
		int16_t tmp = *dest_addr;
		sdk_log_printf("%s:%d\r\n",argv[2],tmp);
	}
	else if(strcmp(argv[2], "uint16_t") == 0)
	{
		uint16_t tmp = *dest_addr;
		sdk_log_printf("%s:%d\r\n",argv[2],tmp);
	}
	else if(strcmp(argv[2], "int32_t") == 0)
	{
		int32_t tmp = *dest_addr;
		sdk_log_printf("%s:%d\r\n",argv[2],tmp);
	}
	else if(strcmp(argv[2], "uint32_t") == 0)
	{
		int32_t tmp = *dest_addr;
		sdk_log_printf("%s:%d\r\n",argv[2],tmp);
	}
	else if(strcmp(argv[2], "float32_t") == 0)
	{
		int32_t tmp = *dest_addr;
		sdk_log_printf("%s:%d\r\n",argv[2],tmp);
	}
	else
	{
		sdk_log_printf("argument err!\r\n");
	}
}
MSH_CMD_EXPORT(query_mem, "query memory: <address & data type>");

/******************************************************************************
 * printf_array().
 * printf array. [Called by.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void printf_array(int argc, char**argv)
{
	if(1 == argc)
	{
		sdk_log_printf("pcsm_total:%d", array.array_data.variable.pcsm_total);
		sdk_log_printf("pcsm_online:%d", array.array_data.variable.pcsm_online);
		sdk_log_printf("pcsm_running:%d", array.array_data.variable.pcsm_run);
		sdk_log_printf("cmu_online:%d", array.array_data.variable.cmu_online);
		sdk_log_printf("cmu_running:%d", array.array_data.variable.cmu_running);
	}
	sdk_log_printf("\n");
}
MSH_CMD_EXPORT(printf_array, "query memory: <address & data type>");
/*
void max_duty(int argc, char**argv)
{
	if(1 == argc)
	{
		sdk_log_printf("10ms max duty:%d\n", max_thread_duty[0]);
		sdk_log_printf("100ms max duty:%d\n", max_thread_duty[1]);
		sdk_log_printf("rs485 max duty:%d\n", max_thread_duty[2]);
		sdk_log_printf("bkgd max duty:%d\n", max_thread_duty[3]);
	}
	sdk_log_printf("\n");
}
MSH_CMD_EXPORT(max_duty, "no param");

void clear_max_duty(int argc, char**argv)
{
	if(1 == argc)
	{
		clear_struct_data((uint8_t*)max_thread_duty, sizeof(max_thread_duty));
	}
	sdk_log_printf("\n");
}
MSH_CMD_EXPORT(clear_max_duty, "no param");
*/

/******************************************************************************
 * set_heart_check().
 * set heart check period, threshold. [Called by.]
 *
 * @param param1  (I) period(s)
 * @param param2  (I) threshold(%)
 * @return none (O)
 *****************************************************************************/
void set_heart_check(int argc, char**argv)
{
	float32_t period;
	float32_t threshold;
	if(3 == argc)
	{
		period = atoi(argv[1]);
		threshold = atoi(argv[2]);
		last_check_time = array.csu.rtc;
		heart_check_period = period;
		heart_check_threshold = (threshold / 100);
		clear_struct_data((uint8_t*)heart_check_cnt, sizeof(heart_check_cnt));
	}
	sdk_log_printf("\n");
}
MSH_CMD_EXPORT(set_heart_check, "--param period(s) --param2 threshold(%)");

/******************************************************************************
 * read_heart_check().
 * read heart check period, threshold. [Called by.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void read_heart_check(int argc, char**argv)
{
	uint8_t i;
	if(1 == argc)
	{
		sdk_log_printf("trigger_heart_check:%d\n", trigger_heart_check);
		sdk_log_printf("heart_check_period:%d(s)\n", (uint32_t)heart_check_period);
		sdk_log_printf("heart_check_threshold:%d(%)\n", (uint32_t)(heart_check_threshold * 100));
		for(i = 0; i < PCSM_NUMS; i++)
		{
			sdk_log_printf("heart_check_cnt[%d]:%d\n", i, heart_check_cnt[i]);
		}

	}
	sdk_log_printf("\n");
}
MSH_CMD_EXPORT(read_heart_check, "no param");

/******************************************************************************
 * prj_info().
 * output project info [Called by.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void prj_info(int argc, char**argv)
{
	if(1 == argc)
	{
		output_product_info();
	}
	sdk_log_printf("\n");
}
MSH_CMD_EXPORT(prj_info, "no param");

/******************************************************************************
 * node_info().
 * output node info [Called by.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void node_info(int argc, char**argv)
{
	list_node_t *node;
	if(1 == argc)
	{
		node = link_list_get_head(&list_pcs);
		sdk_log_printf("node printf start\n");
		while(node)
		{
			sdk_log_printf("id:%d\n", node->id);
			node = node->next;
		}
	}
	sdk_log_printf("\n");
}
MSH_CMD_EXPORT(node_info, "no param");

/******************************************************************************
 * max_duty().
 * output max duty [Called by.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void max_duty(int argc, char**argv)
{
	if(1 == argc)
	{
		sdk_log_printf("10ms max duty: %d\n", max_thread_duty[0]);
		sdk_log_printf("100ms max duty:%d\n", max_thread_duty[1]);
		sdk_log_printf("rs485 max duty:%d\n", max_thread_duty[2]);
		sdk_log_printf("bkgd max duty: %d\n", max_thread_duty[3]);
	}
	sdk_log_printf("\n");
}
MSH_CMD_EXPORT(max_duty, "no param");

/******************************************************************************
 * clear_max_duty().
 * clear max duty [Called by.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void clear_max_duty(int argc, char**argv)
{
	if(1 == argc)
	{
		clear_struct_data((uint8_t*)max_thread_duty, sizeof(max_thread_duty));
	}
	sdk_log_printf("\n");
}
MSH_CMD_EXPORT(clear_max_duty, "no param");

/******************************************************************************
 * ammeter_xiaoju().
 * output xiaoju ammeter. [Called by.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void xiaoju_output(int argc, char**argv)
{
	if(1 == argc)
	{
		sdk_log_printf("action: %d\n", xiao_ju.system_ctrl);
		sdk_log_printf("max_allow_chg_power: %d\n", xiao_ju.max_allow_chg_power);
		sdk_log_printf("max_allow_dch_power: %d\n", xiao_ju.max_allow_dch_power);
		sdk_log_printf("transformer_capacity: %d\n", xiao_ju.transformer_capacity);
		sdk_log_printf("ammeter3_num: %d\n", xiao_ju.ammeter3_num);
		sdk_log_printf("virtul_ammeter4: %d\n", (int32_t)xiaoju_ammeter.virtul_ammeter_4);
		sdk_log_printf("ammeter2: %d\n", (int32_t)xiaoju_ammeter.ammeter_2);
		sdk_log_printf("ammeter3: %d\n", (int32_t)xiaoju_ammeter.ammeter_3);
	}
}
MSH_CMD_EXPORT(xiaoju_output, "no param");

/******************************************************************************
 * ammeter_xiaoju().
 * output xiaoju ammeter. [Called by.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void xiaoju_set(int argc, char**argv)
{
	if(6 == argc)
	{
		xiao_ju.system_ctrl = atoi(argv[1]);
		xiao_ju.max_allow_chg_power = atoi(argv[2]);
		xiao_ju.max_allow_dch_power = atoi(argv[3]);
		xiao_ju.transformer_capacity = atoi(argv[4]);
		xiao_ju.ammeter3_num = atoi(argv[5]);
	}
}
MSH_CMD_EXPORT(xiaoju_set, "--param1 0:no action 1:chg 2:dch \
--param2 max_chg_power(UNIT :0.1KW) \
--param3 max_dch_power(UNIT :0.1KW) \
--param4 transformer capacity(UNIT :0.1kVA) \
--param5 ammeter3 num");

/******************************************************************************
 * backflow_data().
 * output backflow meter data [Called by.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void backflow_data(int argc, char**argv)
{
	if(1 == argc)
	{
		sdk_log_printf("meter_power:%d\r\n", (int32_t)ems.ammeter.power);
		sdk_log_printf("backflow_meter_switch:%d\r\n", (int32_t)ems.backflow_meter_switch);
		sdk_log_printf("frequency:%d\r\n", (int32_t)pcc_meter_data.frequency);
		sdk_log_printf("volt_r:%d\r\n", (int32_t)pcc_meter_data.volt_r);
		sdk_log_printf("volt_s:%d\r\n", (int32_t)pcc_meter_data.volt_s);
		sdk_log_printf("volt_t:%d\r\n", (int32_t)pcc_meter_data.volt_t);
		sdk_log_printf("forward_total_active_energy:%d\r\n", (int32_t)pcc_meter_data.forward_total_active_energy);
		sdk_log_printf("backward_total_active_energy:%d\r\n", (int32_t)pcc_meter_data.backward_total_active_energy);
		sdk_log_printf("meter voltage ratio:%d\r\n",(int32_t)ems.backflow_voltage_ratio);
		sdk_log_printf("meter current ratio:%d\r\n", (int32_t)ems.backflow_current_ratio);
		sdk_log_printf("fault backflow meter cnt:%d\r\n", (int32_t)fault_backflow_meter_cnt);
		sdk_log_printf("fault backflow meter ref:%d\r\n", (int32_t)fault_backflow_meter_ref);
		sdk_log_printf("trigger backflow meter:%d\r\n", (int32_t)trigger_backflow_meter);
		sdk_log_printf("fault backflow meter:%d\r\n", (int32_t)fault_backflow_meter);
	}
	sdk_log_printf("\n");
}
MSH_CMD_EXPORT(backflow_data, "no param");
/******************************************************************************
 * clear_meter_count().
 * output backflow meter data [Called by.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void clear_meter_count(int argc, char**argv)
{
	uint8_t index;
	if(2 == argc)
	{
		index = atoi(argv[1]);
		if(index == 1)
		{
			backflow_disconn_count = 0;
			backflow_conn_count = 0;
		}
		else if(index == 2)
		{
			meter1_disconn_count = 0;
			meter1_conn_count = 0;
		}
		else if(index == 3)
		{
			meter2_disconn_count = 0;
			meter2_conn_count = 0;
		}
		else if(index == 4)
		{
			meter3_disconn_count = 0;
			meter3_conn_count = 0;
		}
		else if(index == 5)
		{
			pv_meter_disconn_count = 0;
			pv_meter_conn_count = 0;
		}
	}
	sdk_log_printf("\n");
}
MSH_CMD_EXPORT(clear_meter_count, "--param1 1:backflow 2:meter1 3:meter2 4:meter3 5:pv");

/******************************************************************************
 * backflow_data().
 * output backflow meter data [Called by.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void meter_disconn_output(int argc, char**argv)
{
	if(1 == argc)
	{
		sdk_log_printf("backflow_disconn_count:%d\r\n", backflow_disconn_count);
		sdk_log_printf("backflow_conn_count:%d\r\n", backflow_conn_count);
		sdk_log_printf("meter1_disconn_count:%d\r\n", meter1_disconn_count);
		sdk_log_printf("meter1_conn_count:%d\r\n", meter1_conn_count);
		sdk_log_printf("meter2_disconn_count:%d\r\n", meter2_disconn_count);
		sdk_log_printf("meter2_conn_count:%d\r\n", meter2_conn_count);
		sdk_log_printf("meter3_disconn_count:%d\r\n", meter3_disconn_count);
		sdk_log_printf("meter3_conn_count:%d\r\n", meter3_conn_count);
		sdk_log_printf("pv_meter_disconn_count:%d\r\n", pv_meter_disconn_count);
		sdk_log_printf("pv_meter_conn_count:%d\r\n", pv_meter_conn_count);
	}
	sdk_log_printf("\n");
}
MSH_CMD_EXPORT(meter_disconn_output, "no param");
/******************************************************************************
 * sci_printf().
 * output backflow meter data [Called by.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void sci_printf(int argc, char**argv)
{
	bool_t switch_flag;
	if(2 == argc)
	{
		switch_flag = atoi(argv[1]);
		sci_printf_flag = switch_flag;
	}
	sdk_log_printf("\n");
}
MSH_CMD_EXPORT(sci_printf, "--param1 0:off 1:on");
/******************************************************************************
 * debug_info().
 * output backflow meter data [Called by.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void debug_info(int argc, char**argv)
{
	if(1 == argc)
	{
		slow_task_debug_record();
	}
	sdk_log_printf("\n");
}
MSH_CMD_EXPORT(debug_info, "no param");
/******************************************************************************
 * set_eth().
 * output backflow meter data [Called by.]
 *
 * @param none  (I)
 * @return none (O)
 *****************************************************************************/
void set_eth(int argc, char**argv)
{
	int32_t ret;
	uint8_t data[16];
	int32_t eth_data[4];
	uint8_t set_n[16] = {0};
	
	if(2 == argc)
	{
		sscanf(&argv[1][0], "%d.%d.%d.%d", &eth_data[0], &eth_data[1], &eth_data[2], &eth_data[3]);
		data[0] = eth_data[0];
		data[1] = eth_data[1];
		data[2] = eth_data[2];
		data[3] = eth_data[3];
		data[4] = 255;
		data[5] = 255;
		data[6] = 255;
		data[7] = 0;
		data[8] = eth_data[0];
		data[9] = eth_data[1];
		data[10] = eth_data[2];
		data[11] = 1;
		data[12] = eth_data[0];
		data[13] = eth_data[1];
		data[14] = eth_data[2];
		data[15] = 1;
		
		setting_set(SYS_PARM, EE_SYS_PARM_ENET_PARM, &data[0], SYS_PARM_ENET_PARM_LEN);
		clear_struct_data(&set_n[0], 16);
		sprintf((char *)&set_n[0], "%d.%d.%d.%d", data[0], data[1], data[2], data[3]);
		ret = sdk_net_ip_set(ETH0, &set_n[0]);
		sdk_log_printf("set ip ret:%d\n", ret);

		clear_struct_data(&set_n[0], 16);
		sprintf((char *)&set_n[0], "%d.%d.%d.%d", data[4], data[5], data[6], data[7]);
		ret = sdk_net_subnetmask_set(ETH0, &set_n[0]);
		sdk_log_printf("set mask ret:%d\n", ret);

		clear_struct_data(&set_n[0], 16);
		sprintf((char *)&set_n[0], "%d.%d.%d.%d", data[8], data[9], data[10], data[11]);
		ret = sdk_net_gateway_set(ETH0, &set_n[0]);
		sdk_log_printf("set gateway ret:%d\n", ret);

		clear_struct_data(&set_n[0], 16);
		sprintf((char *)&set_n[0], "%d.%d.%d.%d", data[12], data[13], data[14], data[15]);
		ret = sdk_net_dns_set(ETH0, &set_n[0]);
		sdk_log_printf("set dns ret:%d\n", ret);

		memory_copy((uint8_t *)&array.csu.csu_data.set.enet_set, &data[0], \
															SYS_PARM_ENET_PARM_LEN);
	}
	sdk_log_printf("\n");
}
MSH_CMD_EXPORT(set_eth, "no param");
/******************************************************************************
* End of module
******************************************************************************/
