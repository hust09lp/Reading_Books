/******************************************************************************
 * FILE IDENTIFICATION
 ******************************************************************************/
/**
 * @file     setting.c
 * @brief    parameter setting functional module
 * @company  SOFARSOLAR
 * @author   WWX
 * @note
 * @version  V01
 * @date     2023/05/22
 */
/*****************************************************************************/

/******************************************************************************
 * COMPILATION OPTION
 ******************************************************************************/

/******************************************************************************
 * INCLUDE FILE
 ******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "array.h"
#include "common.h"
#include "sdk.h"
#include "sdk_core.h"
#include "setting.h"
#include "pcs_sequence.h"
#include "sci_mcu1.h"
#include "pcsc_diag.h"
#include "pcsc_opt_log.h"
#include "rtc.h"
#include "fifo_log.h"
#include "rs485_device_manage.h"
#include "ems.h"

/******************************************************************************
 * DEFINE DESCRIPTION
 ******************************************************************************/

/******************************************************************************
 * ENUM DESCRIPTION
 ******************************************************************************/

/******************************************************************************
 * STRUCTURE DESCRIPTION
 ******************************************************************************/

/******************************************************************************
 * CONSTANT DESCRIPTION
 ******************************************************************************/

/******************************************************************************
 * VARIABLE DESCRIPTION
 ******************************************************************************/
// []: 0, 1, 2, 3
// ID: 1, 2, 5, 7
uint8_t uart_index_to_id[UART_NUMS] =
{
	1,
	2,
	5,
	7,
};

// ID:  0, 1, 2, 3, 4, 5, 6, 7
// []: -1, 0, 1,-1,-1, 2,-1, 3
uint8_t uart_id_to_index[] =
{
	255,
	0,
	1,
	255,
	255,
	2,
	255,
	3
};

const set_value_uint16_t *g_ems_set_table;
const set_value_uint16_t ems_set_table_690V[EMS_PARM_MAX_NUM] =
{
//      index                                   min                                  max               default
	{   UINT16_MAX,                EMS_PARM_MAX_NUM,                    EMS_PARM_MAX_NUM,   EMS_PARM_MAX_NUM   },  // table len
	{   EE_EMS_DEMAND_ENABLE,               DISABLE,                              ENABLE,            DISABLE   },  // demand side enable
	{   EE_EMS_DEMAND_QUANTITY,                   0,                               18000,               2150   },  // demand side demand quantity
	{   EE_EMS_DEMAND_DEADBAND,                   0,                                  10,                  1   },  // demand side demand dead band
	{   EE_EMS_ANTI_ENABLE,                 DISABLE,                              ENABLE,            DISABLE   },  // anti-backflow enable
	{   EE_EMS_ALLOW_SALE_POWER,                  0,                       MAX_SET_POWER,                  0   },  // anti-backflow dead band
	{   EE_EMS_C2D_ENABLE,                  DISABLE,                              ENABLE,            DISABLE   },  // c2d enable
	{   EE_EMS_ALLOW_PURCHASE_POWER,              0,                       MAX_SET_POWER,                  0   },  // c2d demand quantity
	{   EE_EMS_CPFV_ENABLE,                 DISABLE,                              ENABLE,            DISABLE   },  // cpfv enable
	{   EE_EMS_TIME_PERIOD,                 INVALID,                          TM_MAX_NUM,                  0   },  // cpfv time attribute
	{   EE_EMS_TIME_PERIOD_MIN,                   0,                                  60,                  0   },  // minutes
	{   EE_EMS_TIME_PERIOD_HOUR,                  0,                                  24,                  0   },  // hour
	{   EE_EMS_CHG_SOC_MAX,                       0,                                 100,                100   },  // cpfv charging soc max
	{   EE_EMS_CHG_POWER_STEP,                    0,                               18000,                500   },  // cpfv charging step
	{   EE_EMS_K1,                              100,                                 120,                105   },  // K1 (Divide by 100 when in use)
	{   EE_EMS_THEORY_MAX_CHG_POWER,              0,                               18000,               2150   },  // theoretical maximum charging power
	{   EE_EMS_DISCHG_SOC_MIN,                    0,                                 100,                 10   },  // cpfv discharging soc min
	{   EE_EMS_DISCHG_POWER_STEP,                 0,                               18000,                500   },  // cpfv discharging step
	{   EE_EMS_K2,                              100,                                 120,                105   },  // K2 (Divide by 100 when in use)
	{   EE_EMS_THEORY_MAX_DISCHG_POWER,           0,                               18000,               2150   },  // theoretical maximum discharging power
	{   EE_EMS_SOC_MAINT_ENABLE,            DISABLE,                              ENABLE,             ENABLE   },  // soc maint enable
	{   EE_EMS_SOC_MAINT_POWER,                  10,                                 100,                 50   },  // soc maint power
	{   EE_EMS_FORCE_CONTROL_ENABLE,        DISABLE,                              ENABLE,            DISABLE   },  // force control enable
	{   EE_EMS_POWER_FACTOR,                      0,                                 100,                 97   },  // force control power factor
	{   EE_EMS_POWER_Q_STEP,                      0,                               18000,                500   },  // force control step
	{   EE_EMS_RATED_CAPACITY,                  344,                               12384,                344   },  // rated battery capacity
	{   EE_EMS_EARLY_CLOSURE_PEAK,                0,                                  20,                 10   },  // early closure peak
	{   EE_EMS_EARLY_CLOSURE_TOP,                 0,                                  20,                 10   },  // early closure top
	{   EE_EMS_EARLY_CLOSURE_VALLEY,              0,                                  20,                 10   },  // early closure valley
	{   EE_EMS_STANDBY_WAIT_TIME,                 0,                                  20,                  5   },  // pcs standby wait time
	{   EE_EMS_STOP_WAIT_TIME,                    0,                                  80,                 10   },  // pcs stop wait time
	{   EE_EMS_ADVANCE_STARTUP_TIME,              3,                                  10,                  3   },  // pcs advance_startup time
	{   EE_EMS_AUTOMATIC_ENABLE,            DISABLE,                              ENABLE,            DISABLE   },  // automatic enable
	{   EE_EMS_METER_CUR_DIR,                     0,                   METER_CUR_DIR_LIM,                  0   },  // bit0：meter1 current direction
																													// bit1：meter2 current direction
																													// bit2：meter3 current direction
																													// bit3：meter4 current direction
																													// 0: positive discharge and negative charge
																													// 1: negative discharge and positive charge
	{   EE_EMS_TIME_PERIOD_POWER,                 0,                               18000,               2150   },  // 时间段定值功率
	{   EE_EMS_HOLIDAY_ENABLE,                    0,   MASK_BITS(EMS_HOLIDAY_ENABLE_NUM),                  0   },  // 节假日使能
	{   EE_EMS_HOLIDAY_TIME_PERIOD,         INVALID,                          TM_MAX_NUM,            FLAT_TM   },  // cpfv time attribute
	{   EE_EMS_HOLIDAY_TIME_PERIOD_POWER,         0,                               18000,               2150   },  // 时间段定值功率
	{   EE_EMS_HOLIDAY_TIME_PERIOD_MIN,           0,                                  60,                  0   },  // minutes
	{   EE_EMS_HOLIDAY_TIME_PERIOD_HOUR,          0,                                  24,                  0   },  // hour
	{   EE_EMS_PCC_POWER_SET,                     0,                       MAX_SET_POWER,                  0   },  // PCC并网点功率设定
	{   EE_EMS_AUTOMATIC_TIME_PERIOD_ENABLE,DISABLE,                              ENABLE,            DISABLE   },  // 自动模式分时段策略使能
};

const set_value_uint16_t ems_set_table_400V[EMS_PARM_MAX_NUM] =
{
//      index                                     min                                 max             default
	{   UINT16_MAX,                  EMS_PARM_MAX_NUM,                   EMS_PARM_MAX_NUM,   EMS_PARM_MAX_NUM   },  // table len
	{   EE_EMS_DEMAND_ENABLE,                 DISABLE,                             ENABLE,            DISABLE   },  // demand side enable
	{   EE_EMS_DEMAND_QUANTITY,                     0,                               9000,               1250   },  // demand side demand quantity
	{   EE_EMS_DEMAND_DEADBAND,                     0,                                 10,                  1   },  // demand side demand dead band
	{   EE_EMS_ANTI_ENABLE,                   DISABLE,                             ENABLE,            DISABLE   },  // anti-backflow enable
	{   EE_EMS_ALLOW_SALE_POWER,                    0,                      MAX_SET_POWER,                  0   },  // anti-backflow dead band
	{   EE_EMS_C2D_ENABLE,                    DISABLE,                             ENABLE,            DISABLE   },  // c2d enable
	{   EE_EMS_ALLOW_PURCHASE_POWER,                0,                      MAX_SET_POWER,                  0   },  // c2d demand quantity
	{   EE_EMS_CPFV_ENABLE,                   DISABLE,                             ENABLE,            DISABLE   },  // cpfv enable
	{   EE_EMS_TIME_PERIOD,                   INVALID,                         TM_MAX_NUM,                  0   },  // cpfv time attribute
	{   EE_EMS_TIME_PERIOD_MIN,                     0,                                 60,                  0   },  // minutes
	{   EE_EMS_TIME_PERIOD_HOUR,                    0,                                 24,                  0   },  // hour
	{   EE_EMS_CHG_SOC_MAX,                         0,                                100,                100   },  // cpfv charging soc max
	{   EE_EMS_CHG_POWER_STEP,                      0,                               9000,                250   },  // cpfv charging step
	{   EE_EMS_K1,                                100,                                120,                105   },  // K1 (Divide by 100 when in use)
	{   EE_EMS_THEORY_MAX_CHG_POWER,                0,                               9000,               1250   },  // theoretical maximum charging power
	{   EE_EMS_DISCHG_SOC_MIN,                      0,                                100,                 10   },  // cpfv discharging soc min
	{   EE_EMS_DISCHG_POWER_STEP,                   0,                               9000,                250   },  // cpfv discharging step
	{   EE_EMS_K2,                                100,                                120,                105   },  // K2 (Divide by 100 when in use)
	{   EE_EMS_THEORY_MAX_DISCHG_POWER,             0,                               9000,               1250   },  // theoretical maximum discharging power
	{   EE_EMS_SOC_MAINT_ENABLE,              DISABLE,                             ENABLE,             ENABLE   },  // soc maint enable
	{   EE_EMS_SOC_MAINT_POWER,                    10,                                100,                 50   },  // soc maint power
	{   EE_EMS_FORCE_CONTROL_ENABLE,          DISABLE,                             ENABLE,            DISABLE   },  // force control enable
	{   EE_EMS_POWER_FACTOR,                        0,                                100,                 97   },  // force control power factor
	{   EE_EMS_POWER_Q_STEP,                        0,                               9000,                250   },  // force control step
	{   EE_EMS_RATED_CAPACITY,                    215,                               9288,                215   },  // rated battery capacity
	{   EE_EMS_EARLY_CLOSURE_PEAK,                  0,                                 20,                 10   },  // early closure peak
	{   EE_EMS_EARLY_CLOSURE_TOP,                   0,                                 20,                 10   },  // early closure top
	{   EE_EMS_EARLY_CLOSURE_VALLEY,                0,                                 20,                 10   },  // early closure valley
	{   EE_EMS_STANDBY_WAIT_TIME,                   0,                                 20,                  5   },  // pcs standby wait time
	{   EE_EMS_STOP_WAIT_TIME,                      0,                                 80,                 10   },  // pcs stop wait time
	{   EE_EMS_ADVANCE_STARTUP_TIME,                3,                                 10,                  3   },  // pcs advance_startup time
	{   EE_EMS_AUTOMATIC_ENABLE,              DISABLE,                             ENABLE,            DISABLE   },  // automatic enable
	{   EE_EMS_METER_CUR_DIR,                       0,                  METER_CUR_DIR_LIM,                  0   },  // bit0：meter1 current direction
										      																		// bit1：meter2 current direction
										      																		// bit2：meter3 current direction
										      																		// bit3：meter4 current direction
										      																		// 0: positive discharge and negative charge
										      																		// 1: negative discharge and positive charge
	{   EE_EMS_TIME_PERIOD_POWER,                   0,                               9000,               1250   },  // 时间段定值功率
	{   EE_EMS_HOLIDAY_ENABLE,                      0,  MASK_BITS(EMS_HOLIDAY_ENABLE_NUM),                  0   },  // 节假日使能
	{   EE_EMS_HOLIDAY_TIME_PERIOD,           INVALID,                         TM_MAX_NUM,            FLAT_TM   },  // cpfv time attribute
	{   EE_EMS_HOLIDAY_TIME_PERIOD_POWER,           0,                               9000,               1250   },  // 时间段定值功率
	{   EE_EMS_HOLIDAY_TIME_PERIOD_MIN,             0,                                 60,                  0   },  // minutes
	{   EE_EMS_HOLIDAY_TIME_PERIOD_HOUR,            0,                                 24,                  0   },  // hour
	{   EE_EMS_PCC_POWER_SET,                       0,                       MAX_SET_POWER,                 0   },  // PCC并网点功率设定
	{   EE_EMS_AUTOMATIC_TIME_PERIOD_ENABLE,  DISABLE,                              ENABLE,           DISABLE   },  // 自动模式分时段策略使能
};

const set_value_uint32_t xiaoju_setting_parm[XIAOJU_PARM_MAX_NUM] =
{
//      index                                                min                         max                    default
	{   UINT16_MAX,                          XIAOJU_PARM_MAX_NUM,        XIAOJU_PARM_MAX_NUM,       XIAOJU_PARM_MAX_NUM   },  // table len
	{   XIAOJU_TRANSFORMER_CAPACITY,                           0,                      50000,                         0   },  // transformer capacity(UNIT: 0.1kVA)
	{   XIAOJU_METER3_NUM,                                     0,    METERING_METER3_MAX_NUM,                         0   },  // meter3 num
	{   XIAOJU_METER1_NUM,                                     1,                  PCSM_NUMS,                         1   },  // meter1 num
	{   XIAOJU_CTRL_SOURCE,                         XIAOJU_LOCAL,              XIAOJU_REMOTE,                         0   },  // ctrl source

};

const set_value_uint16_t mcu2_inter_conf[MCU2_INTER_CONF_MAX_NUM] =
{
//      index                                                min                         max                    default
	{   UINT16_MAX,                      MCU2_INTER_CONF_MAX_NUM,    MCU2_INTER_CONF_MAX_NUM,                      MCU2_INTER_CONF_MAX_NUM    },  // table len
	{   EE_SYS_PARM_PCSM_NUMS_SET,                             1,                  PCSM_NUMS,                                            1    },  // energy storage nums
	{   EE_SYS_PARM_RS485_ENABLE,                              0,           RS485_ENABLE_LIM,                               METERING_METER    },  // RS485 enable
	{   EE_SYS_PARM_SCENARIO_SETTING,           ONE_STORAGE_TANK,               SCENARIO_END,                             ONE_STORAGE_TANK    },  // scenario
	{   EE_SYS_PARM_PV_METER_MODEL,                       ADL400,            METER_MODEL_END,                                      DTSU666    },  // 光伏电表型号
	{   EE_SYS_PARM_PV_METER_NUM,                              0,           PV_METER_MAX_NUM,                                            0    },  // pv meter num
	{   EE_SYS_PARM_CSU_ROLE,                              SLAVE,                     MASTER,                                        SLAVE    },  // csu role
	{   EE_SYS_PARM_PRODUCT_MODEL,              POWER_MAGIC_400V,            POWER_MAGIC_END,                             POWER_MAGIC_400V    },  // 机型
	{   EE_SYS_PARM_DEHUMIDIFIER_SET,                          0,                        100,                DEHUM_RN_DEFAULT_VALUE_ANDEAN    },  // 除湿器湿度
	{   EE_SYS_PARM_DEHUMIDIFIER_DIFF_SET,                     0,                        100,       DEHUM_RETURN_DIFF_DEFAULT_VALUE_ANDEAN    },  // 除湿器湿度回差
	{   EE_SYS_PARM_PCC_METER_MODEL,                      ADL400,            METER_MODEL_END,                                      DTSU666    },  // PCC电表型号
	{   EE_SYS_PARM_SYS_SIGNAL_ENABLE,                   DISABLE,                    ENABLE,                                      DISABLE    },  // 载波同步信号使能
};

const set_value_uint8_t enet_set_table[ENET_PARM_MAX_NUM] =
{
//      index                       min                   max              default
	{   UINT16_MAX,   ENET_PARM_MAX_NUM,    ENET_PARM_MAX_NUM,   ENET_PARM_MAX_NUM   }, // table len
	{   EE_IP_1,                      1,                  248,                 192   }, // ip_1
	{   EE_IP_2,                      0,                  255,                 168   }, // ip_2
	{   EE_IP_3,                      0,                  255,                   1   }, // ip_3
	{   EE_IP_4,                      1,                  248,                 120   }, // ip_4
	{   EE_MASK_1,                    0,                  255,                 255   }, // mask_1
	{   EE_MASK_2,                    0,                  255,                 255   }, // mask_2
	{   EE_MASK_3,                    0,                  255,                 255   }, // mask_3
	{   EE_MASK_4,                    0,                  254,                   0   }, // mask_4
	{   EE_GATEWAY_1,                 1,                  248,                 192   }, // gateway_1
	{   EE_GATEWAY_2,                 0,                  255,                 168   }, // gateway_2
	{   EE_GATEWAY_3,                 0,                  255,                   1   }, // gateway_3
	{   EE_GATEWAY_4,                 1,                  248,                   1   }, // gateway_4
	{   EE_DNS_1,                     0,                  255,                   8   }, // dns_1
	{   EE_DNS_2,                     0,                  255,                   8   }, // dns_2
	{   EE_DNS_3,                     0,                  255,                   8   }, // dns_3
	{   EE_DNS_4,                     0,                  255,                   8   }, // dns_4
};

const set_value_uint32_t uart_set_table[UART_PARM_MAX_NUM] =
{
//      index                               min                   max               default
	{   UINT16_MAX,           UART_PARM_MAX_NUM,    UART_PARM_MAX_NUM,   UART_PARM_MAX_NUM   }, // table len
	{   EE_UART_BAUD_RATE,                    0,               115200,                9600   }, // baud_rate
	{   EE_UART_INDEX_1,                      0,                   10,                   1   }, // index_addr
	{   EE_UART_SLAVE_ADDR,                   0,                   20,                   1   }, // slave_addr
	{   EE_UART_DATA_BITS,                    5,                    8,                   8   }, // data_bits
	{   EE_UART_STOP_BITS,                    1,                    2,                   1   }, // stop_bits
	{   EE_UART_PARITY,                       0,                    2,                   0   }, // parity
	{   EE_UART_INDEX_2,                      0,                   10,                   2   }, // index_addr
	{   EE_UART_INDEX_5,                      0,                   10,                   5   }, // index_addrindex_addr
	{   EE_UART_INDEX_7,                      0,                   10,                   7   }, // index_addr
};

bool_t trigger_restore_factory;
uint16_t now_scenario_setting = 0;
uint16_t now_pcsm_num_setting = 0;
uint16_t pre_product_model = 0;

/******************************************************************************
 * FUNCTION PROTOTYPE
 ******************************************************************************/

/******************************************************************************
 * FUNCTION DESCRIPTION
 ******************************************************************************/

/******************************************************************************
 * setting_init().
 * Initialize parameter setting module. [Called by sw_init()]
 *
 * @param none (I)
 * @param none (O)
 * @return none
 *****************************************************************************/
void setting_init(void)
{
	int32_t ret;

	ret = sdk_para_init(FUT_SET, FUT_SET_SIZE);
	if (ret != SF_OK)
	{
		sdk_log_d("Factory settings intial error!\r\n");
	}
	else
	{
		sdk_log_d("Factory settings intial ok!\r\n");
	}

	ret = sdk_para_init(SAFE_PARM, SAFE_PARM_SIZE);
	if (ret != SF_OK)
	{
		sdk_log_d("Safty settings intial error!\r\n");
	}
	else
	{
		sdk_log_d("Safty settings intial ok!\r\n");
	}

	ret = sdk_para_init(ENER_REC, ENER_REC_SIZE);
	if (ret != SF_OK)
	{
		sdk_log_d("energy record intial error!\r\n");
	}
	else
	{
		sdk_log_d("energy record intial ok!\r\n");
	}

	ret = sdk_para_init(SYS_PARM, SYS_PARM_SIZE);
	if (ret != SF_OK)
	{
		sdk_log_d("App settings intial error!\r\n");
	}
	else
	{
		sdk_log_d("App settings intial ok!\r\n");
	}
	ret = sdk_para_init(LOCAL_EMS, LOCAL_EMS_SIZE);
	if (ret != SF_OK)
	{
		sdk_log_d("Local EMS settings intial error!\r\n");
	}
	else
	{
		sdk_log_d("Local EMS settings intial ok!\r\n");
	}

	ret = sdk_para_init(XIAOJU_PARM, XIAOJU_PARM_SIZE);
	if (ret != SF_OK)
	{
		sdk_log_d("XIAOJU PARM settings intial error!\r\n");
	}
	else
	{
		sdk_log_d("XIAOJU PARM settings intial ok!\r\n");
	}

}

/******************************************************************************
 * setting_inter_conf_init().
 * inter conf param init. [Called by task()]
 *
 * @param none
 * @return none
 *****************************************************************************/
void setting_inter_conf_init(void)
{
	bool_t cross_border_flag = FALSE;
	uint8_t inter_conf_buff[EE_SYS_PARM_SECTOR_END - EE_SYS_PARM_PCSM_NUMS_SET];
	setting_get(SYS_PARM, EE_SYS_PARM_PCSM_NUMS_SET, &inter_conf_buff[0], EE_SYS_PARM_SECTOR_END - EE_SYS_PARM_PCSM_NUMS_SET);
	array.pcsc.pcsc_ctrl.pcsm_nums_set = \
			setting_data_constrain_uint16((uint16_t*)&inter_conf_buff[EE_SYS_PARM_PCSM_NUMS_SET - EE_SYS_PARM_PCSM_NUMS_SET], \
										&mcu2_inter_conf[0], \
										EE_SYS_PARM_PCSM_NUMS_SET, \
										&cross_border_flag);
	array.pcsc.pcsc_ctrl.rs485_enable.all = \
			setting_data_constrain_uint16((uint16_t*)&inter_conf_buff[EE_SYS_PARM_RS485_ENABLE - EE_SYS_PARM_PCSM_NUMS_SET], \
										&mcu2_inter_conf[0], \
										EE_SYS_PARM_RS485_ENABLE, \
										&cross_border_flag);
	array.pcsc.pcsc_ctrl.scenario_setting = \
			setting_data_constrain_uint16((uint16_t*)&inter_conf_buff[EE_SYS_PARM_SCENARIO_SETTING - EE_SYS_PARM_PCSM_NUMS_SET], \
										&mcu2_inter_conf[0], \
										EE_SYS_PARM_SCENARIO_SETTING, \
										&cross_border_flag);
	now_scenario_setting = array.pcsc.pcsc_ctrl.scenario_setting;
	pv_meter_parm.pv_meter_model = \
			setting_data_constrain_uint16((uint16_t*)&inter_conf_buff[EE_SYS_PARM_PV_METER_MODEL - EE_SYS_PARM_PCSM_NUMS_SET], \
										&mcu2_inter_conf[0], \
										EE_SYS_PARM_PV_METER_MODEL, \
										&cross_border_flag);
	pv_meter_parm.pv_meter_num = \
			setting_data_constrain_uint16((uint16_t*)&inter_conf_buff[EE_SYS_PARM_PV_METER_NUM - EE_SYS_PARM_PCSM_NUMS_SET], \
										&mcu2_inter_conf[0], \
										EE_SYS_PARM_PV_METER_NUM, \
										&cross_border_flag);
	array.csu.csu_data.csu_heart.csu_role = \
			setting_data_constrain_uint16((uint16_t*)&inter_conf_buff[EE_SYS_PARM_CSU_ROLE - EE_SYS_PARM_PCSM_NUMS_SET], \
										&mcu2_inter_conf[0], \
										EE_SYS_PARM_CSU_ROLE, \
										&cross_border_flag);
	pre_product_model = \
			setting_data_constrain_uint16((uint16_t*)&inter_conf_buff[EE_SYS_PARM_PRODUCT_MODEL - EE_SYS_PARM_PCSM_NUMS_SET], \
										&mcu2_inter_conf[0], \
										EE_SYS_PARM_PRODUCT_MODEL, \
										&cross_border_flag);
	dehumidifier_set.humidity_set = \
			setting_data_constrain_uint16((uint16_t*)&inter_conf_buff[EE_SYS_PARM_DEHUMIDIFIER_SET - EE_SYS_PARM_PCSM_NUMS_SET], \
										&mcu2_inter_conf[0], \
										EE_SYS_PARM_DEHUMIDIFIER_SET, \
										&cross_border_flag);
	dehumidifier_set.humidity_diff_set = \
			setting_data_constrain_uint16((uint16_t*)&inter_conf_buff[EE_SYS_PARM_DEHUMIDIFIER_DIFF_SET - EE_SYS_PARM_PCSM_NUMS_SET], \
										&mcu2_inter_conf[0], \
										EE_SYS_PARM_DEHUMIDIFIER_DIFF_SET, \
										&cross_border_flag);
	ems.backflow_meter_switch = \
			setting_data_constrain_uint16((uint16_t*)&inter_conf_buff[EE_SYS_PARM_PCC_METER_MODEL - EE_SYS_PARM_PCSM_NUMS_SET], \
										&mcu2_inter_conf[0], \
										EE_SYS_PARM_PCC_METER_MODEL, \
										&cross_border_flag);
	array.pcsc.pcsc_ctrl.sync_signal_enable = \
			setting_data_constrain_uint16((uint16_t*)&inter_conf_buff[EE_SYS_PARM_SYS_SIGNAL_ENABLE - EE_SYS_PARM_PCSM_NUMS_SET], \
										&mcu2_inter_conf[0], \
										EE_SYS_PARM_SYS_SIGNAL_ENABLE, \
										&cross_border_flag);
	ems_init(pre_product_model);
	array.pcsc.pcsc_ctrl.cmd.bit.restore_factory_default = FALSE;
	trigger_restore_factory = FALSE;
	if(ONLY_COMBINER_CABINET == array.pcsc.pcsc_ctrl.scenario_setting)
	{
		trigger_pm_init = TRUE;
		product_info.model_num = POWER_MAGIC_400V;
		array.pcsc.pcsc_ctrl.rs485_enable.bit.dehumidifier = TRUE;
		array.pcsc.pcsc_ctrl.pcsm_nums_set = 0;
		array.csu.csu_data.csu_const.base_rated_power = pcs_machine_type[POWER_MAGIC_400V].rated_power;
	}
	else
	{
		array.pcsc.pcsc_ctrl.rs485_enable.bit.dehumidifier = FALSE;
	}
}

/******************************************************************************
 * setting_enet_init().
 * Read EEPROM data. [Called by task()]
 *
 * @param type  (I) Region Idex
 * @param offset(I) Offset
 * @param data  (I) read data pointer
 * @param len   (I) length of data
 * @return 0(success), <0(failure)
 *****************************************************************************/
void setting_enet_init(void)
{
	int32_t ret;
	uint8_t data[16];
	uint8_t set_n[16];
	uint8_t index = 0;
	bool_t cross_broader_flag = FALSE;

	clear_struct_data(&data[0], 16);
	ret = sdk_para_read(SYS_PARM, EE_SYS_PARM_ENET_PARM, &data[0], \
														SYS_PARM_ENET_PARM_LEN);
	if(ret < 0)
	{
		sdk_log_i("get enet parm fail!");
	}

	clear_struct_data(&set_n[0], 16);
	for(index = 0; (index < 16) && (!cross_broader_flag); index++)
	{
		data[index] = setting_data_constrain_uint8(&data[index], \
								&enet_set_table[0], index, &cross_broader_flag);
	}

	if(cross_broader_flag == TRUE)
	{
		for(index = 0; index < 16; index++)
		{
			data[index] = setting_data_restore_uint8(&enet_set_table[0], index + 1, 0);
		}
		setting_set(SYS_PARM, EE_SYS_PARM_ENET_PARM, &data[0], SYS_PARM_ENET_PARM_LEN);
	}
	sprintf((char *)&set_n[0], "%d.%d.%d.%d", data[0], data[1], data[2], data[3]);
	ret = sdk_net_ip_set(ETH0, &set_n[0]);
	if(ret != SF_OK)
	{
		sdk_log_i("set ip fail!");
	}

	clear_struct_data(&set_n[0], 16);
	sprintf((char *)&set_n[0], "%d.%d.%d.%d", data[4], data[5], data[6], data[7]);
	sdk_net_subnetmask_set(ETH0, &set_n[0]);
	if(ret != SF_OK)
	{
		sdk_log_i("set subnetmask fail!");
	}

	clear_struct_data(&set_n[0], 16);
	sprintf((char *)&set_n[0], "%d.%d.%d.%d", data[8], data[9], data[10], data[11]);
	sdk_net_gateway_set(ETH0, &set_n[0]);
	if(ret != SF_OK)
	{
		sdk_log_i("set gateway fail!");
	}

	clear_struct_data(&set_n[0], 16);
	sprintf((char *)&set_n[0], "%d.%d.%d.%d", data[12], data[13], data[14], data[15]);
	sdk_net_dns_set(ETH0, &set_n[0]);
	if(ret != SF_OK)
	{
		sdk_log_i("set dns fail!");
	}

	memory_copy((uint8_t *)&array.csu.csu_data.set.enet_set, &data[0], \
														SYS_PARM_ENET_PARM_LEN);
}

/******************************************************************************
 * reset_enet().
 * reset enet. [Called by task()]
 *
 * @param none  (I)
 * @return none
 *****************************************************************************/
void reset_enet(void)
{
	int32_t ret;
	uint8_t set_n[16];
	uint8_t data[16] = {192, 168 , 1, 120, 255, 255, 255, 0, 192, 168, 1, 1, 8, 8, 8, 8};

	sprintf((char *)&set_n[0], "%d.%d.%d.%d", data[0], data[1], data[2], data[3]);
	ret = sdk_net_ip_set(ETH0, &set_n[0]);
	if(ret != SF_OK)
	{
		sdk_log_i("set ip fail!");
	}

	sprintf((char *)&set_n[0], "%d.%d.%d.%d", data[4], data[5], data[6], data[7]);
	sdk_net_subnetmask_set(ETH0, &set_n[0]);
	if(ret != SF_OK)
	{
		sdk_log_i("set subnetmask fail!");
	}

	sprintf((char *)&set_n[0], "%d.%d.%d.%d", data[8], data[9], data[10], data[11]);
	sdk_net_gateway_set(ETH0, &set_n[0]);
	if(ret != SF_OK)
	{
		sdk_log_i("set gateway fail!");
	}

	sprintf((char *)&set_n[0], "%d.%d.%d.%d", data[12], data[13], data[14], data[15]);
	sdk_net_dns_set(ETH0, &set_n[0]);
	if(ret != SF_OK)
	{
		sdk_log_i("set dns fail!");
	}

	memory_copy((uint8_t *)&array.csu.csu_data.set.enet_set, &data[0], \
														SYS_PARM_ENET_PARM_LEN);
}

/******************************************************************************
 * setting_uart_init().
 * Read EEPROM data. [Called by task()]
 *
 * @return none
 *****************************************************************************/
void setting_uart_init(void)
{
	uint8_t i;
	uint32_t addr;
	word_t tmp;
	uint8_t uart_index;
	bool_t cross_broader_flag = FALSE;

	tmp.all = 0;
	for(i = 0; i < UART_NUMS; i++)
	{
		addr = EE_SYS_PARM_UART_PARM + (i * SYS_PARM_UART_PARM_LEN);
		setting_get(SYS_PARM, addr, &array.pcsc.pcsc_ctrl.uart_conf[i], SYS_PARM_UART_PARM_LEN);
		switch (i)
		{
			case 0:
				uart_index = EE_UART_INDEX_1;
				break;
			case 1:
				uart_index = EE_UART_INDEX_2;
				break;
			case 2:
				uart_index = EE_UART_INDEX_5;
				break;
			case 3:
				uart_index = EE_UART_INDEX_7;
				break;
			default:
				break;
		}
		array.pcsc.pcsc_ctrl.uart_conf[i].baud_rate = \
						setting_data_constrain_uint32(&array.pcsc.pcsc_ctrl.uart_conf[i].baud_rate, \
						&uart_set_table[0], EE_UART_BAUD_RATE, &cross_broader_flag);

		tmp.all = array.pcsc.pcsc_ctrl.uart_conf[i].uart_index;
		array.pcsc.pcsc_ctrl.uart_conf[i].uart_index = \
						setting_data_constrain_uint32(&tmp.all, \
						&uart_set_table[0], uart_index, &cross_broader_flag);

		tmp.all = array.pcsc.pcsc_ctrl.uart_conf[i].slave_addr;
		array.pcsc.pcsc_ctrl.uart_conf[i].slave_addr = \
						setting_data_constrain_uint32(&tmp.all, \
						&uart_set_table[0], EE_UART_SLAVE_ADDR, &cross_broader_flag);

		tmp.all = array.pcsc.pcsc_ctrl.uart_conf[i].data_bits;
		array.pcsc.pcsc_ctrl.uart_conf[i].data_bits = \
						setting_data_constrain_uint32(&tmp.all, \
						&uart_set_table[0], EE_UART_DATA_BITS, &cross_broader_flag);

		tmp.all = array.pcsc.pcsc_ctrl.uart_conf[i].stop_bits;
		array.pcsc.pcsc_ctrl.uart_conf[i].stop_bits = \
						setting_data_constrain_uint32(&tmp.all, \
						&uart_set_table[0], EE_UART_STOP_BITS, &cross_broader_flag);

		tmp.all = array.pcsc.pcsc_ctrl.uart_conf[i].parity;
		array.pcsc.pcsc_ctrl.uart_conf[i].parity = \
						setting_data_constrain_uint32(&tmp.all, \
						&uart_set_table[0], EE_UART_PARITY, &cross_broader_flag);
	}
}

/******************************************************************************
 * setting_set().
 * Write EEPROM data. [Called by task()]
 *
 * @param type  (I) Region Idex
 * @param offset(I) Offset
 * @param data  (I) write data pointer
 * @param len   (I) length of data
 * @return 0(success), <0(failure)
 *****************************************************************************/
int32_t setting_set(uint16_t type, uint16_t offset, void *data, uint16_t len)
{
	int32_t ret;
	uint32_t tmp_read = 0;
	uint32_t tmp_write = 0;

	if(len <= 4)
	{
		ret = sdk_para_read(type, offset, (uint8_t *)&tmp_read, len);
		if (ret < 0)
		{
			opt_log_record("Settings get failed, type: %d, offset: %d", type, offset);
		}
		else
		{
			memory_copy((uint8_t *)&tmp_write, (uint8_t *)data, len);
			if(tmp_read != tmp_write)
			{
				ret = sdk_para_write(type, offset, (uint8_t *)data, len);
				if (ret != SF_OK)
				{
					opt_log_record("Settings set failed, type: %d, offset: %d", type, offset);
				}
				else
				{
					opt_log_record("write eeprom,type:%d,offset:%d, value:%d -> %d", \
								type, offset, tmp_read, tmp_write);
				}
			}
			else
			{
				opt_log_record("tmp_read == tmp_write, type: %d, offset: %d, value = %d", type, offset, tmp_read);
			}

		}
	}
	else
	{
		ret = sdk_para_write(type, offset, (uint8_t *)data, len);
		if (ret != SF_OK)
		{
			opt_log_record("Settings set failed, type: %d, offset: %d, len: %d", type, offset, len);
		}
		else
		{
			opt_log_record("Settings set success, type: %d, offset: %d, len: %d", type, offset, len);
		}
	}

	return ret;
//	else
//	{
//		sdk_log_d("Settings set OK! type: %d, offset: %d\r\n", type, offset);
//	}
}

/******************************************************************************
 * setting_set().
 * Write EEPROM data. [Called by task()]
 *
 * @param type  (I) Region Idex
 * @param offset(I) Offset
 * @param data  (I) write data pointer
 * @param len   (I) length of data
 * @return 0(success), <0(failure)
 *****************************************************************************/
int32_t setting_set_without_log(uint16_t type, uint16_t offset, void *data, uint16_t len)
{
	int32_t ret;
	uint32_t tmp_read = 0;
	uint32_t tmp_write = 0;

	if(len <= 4)
	{
		ret = sdk_para_read(type, offset, (uint8_t *)&tmp_read, len);
		if (ret < 0)
		{
			sdk_log_i("Settings get failed, type: %d, offset: %d\r\n", type, offset);
		}
		else
		{
			memory_copy((uint8_t *)&tmp_write, (uint8_t *)data, len);
			if(tmp_read != tmp_write)
			{
				ret = sdk_para_write(type, offset, (uint8_t *)data, len);
				if (ret != SF_OK)
				{
					sdk_log_i("Settings set failed, type: %d, offset: %d\r\n", type, offset);
				}
				else
				{
					sdk_log_i("write eeprom,type:%d,offset:%d, value:%d -> %d\r\n", \
								type, offset, tmp_read, tmp_write);
				}
			}
			else
			{
				sdk_log_i("tmp_read == tmp_write, type: %d, offset: %d, value = %d\r\n", type, offset, tmp_read);
			}

		}
	}
	else
	{
		ret = sdk_para_write(type, offset, (uint8_t *)data, len);
		if (ret != SF_OK)
		{
			sdk_log_i("Settings set failed, type: %d, offset: %d, len: %d\r\n", type, offset, len);
		}
		else
		{
			sdk_log_i("Settings set success, type: %d, offset: %d, len: %d\r\n", type, offset, len);
		}
	}

	return ret;
//	else
//	{
//		sdk_log_d("Settings set OK! type: %d, offset: %d\r\n", type, offset);
//	}
}
/******************************************************************************
 * setting_get().
 * Read EEPROM data. [Called by task()]
 *
 * @param type  (I) Region Idex
 * @param offset(I) Offset
 * @param data  (I) read data pointer
 * @param len   (I) length of data
 * @return 0(success), <0(failure)
 *****************************************************************************/
int32_t setting_get(uint16_t type, uint16_t offset, void *data, uint16_t len)
{
	int32_t ret;

	ret = sdk_para_read(type, offset, (uint8_t *)data, len);
	if (ret < 0)
	{
		sdk_log_d("Settings get failed, type: %d, offset: %d\r\n", type, offset);
	}
//	else
//	{
//		sdk_log_d("Settings read OK! type: %d, offset: %d\r\n", type, offset);
//	}

	return ret;
}

/******************************************************************************
 * setting_data_check_uint8().
 * check eeprom data validity. [Called by app.]
 *
 * @param data (I) data.
 * @param low (I) value array.
 * @return TRUE(valid), FALSE(invalid)
 *****************************************************************************/
uint8_t setting_data_constrain_uint8(uint8_t *data, \
							const set_value_uint8_t *threshold, uint16_t index,\
													 bool_t *cross_border_flag)
{
	uint16_t i;
	uint8_t result = 0;
	bool_t ret = FALSE;
	uint16_t len;

	if(NULL == threshold)
	{
		return 0;
	}

	len = threshold[0].value;
	for (i = 0; (i < len) && (ret == FALSE); i++)
	{
		if(threshold[i].index == index)
		{
			ret = TRUE;
			if((*data >= threshold[i].min) && (*data <= threshold[i].max))
			{
				*cross_border_flag = FALSE;
				result = *data;
			}
			else
			{
				*cross_border_flag = TRUE;
				result = threshold[i].value;
			}
		}
	}

	return result;
}

/******************************************************************************
 * setting_data_constrain_uint16().
 * check eeprom data validity. [Called by app.]
 *
 * @param data (I) data.
 * @param low (I) value array.
 * @return TRUE(valid), FALSE(invalid)
 *****************************************************************************/
uint16_t setting_data_constrain_uint16(uint16_t *data, \
						const set_value_uint16_t *threshold, uint16_t index, \
													bool_t *cross_border_flag)
{
	uint16_t result = 0;
	uint16_t i;
	bool_t ret = FALSE;
	uint16_t len;

	if(NULL == threshold)
	{
		return 0;
	}
	len = threshold[0].value;

	for(i = 0;(i < len) && (ret == FALSE);i++)
	{
		if(threshold[i].index == index)
		{
			ret = TRUE;
			if((*data >= threshold[i].min) && (*data <= threshold[i].max))
			{
				*cross_border_flag = FALSE;
				result = *data;
			}
			else
			{
				*cross_border_flag = TRUE;
				result = threshold[i].value;
			}
		}
	}

	return result;
}

/******************************************************************************
 * setting_data_constrain_uint32().
 * check eeprom data validity. [Called by app.]
 *
 * @param data (I) data.
 * @param low (I) value array.
 * @return TRUE(valid), FALSE(invalid)
 *****************************************************************************/
uint32_t setting_data_constrain_uint32(uint32_t *data, \
						const set_value_uint32_t *threshold, uint16_t index, \
													bool_t *cross_border_flag)
{
	uint32_t result = 0;
	uint16_t i;
	bool_t ret = FALSE;
	uint16_t len;

	if(NULL == threshold)
	{
		return 0;
	}

	len = threshold[0].value;

	for(i = 0; (i < len) && (ret == FALSE); i++)
	{
		if(threshold[i].index == index)
		{
			ret = TRUE;
			if((*data >= threshold[i].min) && (*data <= threshold[i].max))
			{
				*cross_border_flag = FALSE;
				result = *data;
			}
			else
			{
				*cross_border_flag = TRUE;
				result = threshold[i].value;
			}
		}
	}

	return result;
}

/******************************************************************************
 * setting_data_restore_uint32().
 * restore data. [Called by app.]
 *
 * @param data (I) data.
 * @param threshold (I) parameter list.
 * @param index (I) index.
 * @param len (I) parameter list size.
 * @return none
 *****************************************************************************/
uint32_t setting_data_restore_uint32(const set_value_uint32_t *threshold, \
												uint16_t index, uint16_t len)
{
	uint16_t i;
	bool_t ret = FALSE;
	uint32_t result;

	if(NULL == threshold)
	{
		return 0;
	}

	// The location of this parameter in the list is unknown and needs to be searched
	if (len > 0)
	{
		for(i = 0;(i < len) && (ret == FALSE);i++)
		{
			if(threshold[i].index == index)
			{
				ret = TRUE;
				result = threshold[i].value;
			}
		}
	}
	// This parameter has a known position in the list and is used directly
	else
	{
		result = threshold[index].value;
	}

	return result;
}

/******************************************************************************
 * setting_data_restore_uint16().
 * restore data . [Called by app.]
 *
 * @param data (I) data.
 * @param threshold (I) parameter list.
 * @param index (I) index.
 * @param len (I) parameter list size.
 * @return none
 *****************************************************************************/
uint16_t setting_data_restore_uint16(const set_value_uint16_t *threshold, \
												uint16_t index, uint16_t len)
{
	uint16_t i;
	bool_t ret = FALSE;
	uint16_t result;

	if(NULL == threshold)
	{
		return 0;
	}

	// The location of this parameter in the list is unknown and needs to be searched
	if (len > 0)
	{
		for(i = 0;(i < len) && (ret == FALSE);i++)
		{
			if(threshold[i].index == index)
			{
				ret = TRUE;
				result = threshold[i].value;
			}
		}
	}
	// This parameter has a known position in the list and is used directly
	else
	{
		result = threshold[index].value;
	}

	return result;
}

/******************************************************************************
 * setting_data_restore_uint8().
 * restore data. [Called by app.]
 *
 * @param data (I) data.
 * @param threshold (I) parameter list.
 * @param index (I) index.
 * @param len (I) parameter list size.
 * @return none
 *****************************************************************************/
uint8_t setting_data_restore_uint8(const set_value_uint8_t *threshold, \
												uint16_t index, uint16_t len)
{
	uint16_t i;
	bool_t ret = FALSE;
	uint8_t result;

	if(NULL == threshold)
	{
		return 0;
	}

	// The location of this parameter in the list is unknown and needs to be searched
	if(len > 0)
	{
		for(i = 0;(i < len) && (ret == FALSE);i++)
		{
			if(threshold[i].index == index)
			{
				ret = TRUE;
				result = threshold[i].value;
			}
		}
	}
	// This parameter has a known position in the list and is used directly
	else
	{
		result = threshold[index].value;
	}

	return result;
}

/******************************************************************************
 * clear_eeprom().
 * clear eeprom data . [Called by app.]
 *
 * @param none.
 * @return none.
 *****************************************************************************/
void clear_eeprom(uint8_t value, uint16_t len, uint8_t sector, uint16_t offset)
{
	uint8_t buff[256] = {0};
	uint16_t length = sizeof(buff);
	if(value != 0)
	{
		fill_struct_data(&buff[0], value, length);
	}

	while(len > length)
	{
		setting_set(sector, offset, &buff[0], length);
		offset += length;
		len -= length;
	}

	setting_set(sector, offset, &buff[0], len);
}

/******************************************************************************
 * restore_ems_data().
 * reset ems data . [Called by app.]
 *
 * @param none.
 * @return none.
 *****************************************************************************/
void restore_ems_data(void)
{
	uint16_t i, j;
	uint8_t tmp;

	if(pcs_model_init_ok == TRUE)
	{
		trigger_local_ems = FALSE;
		for(i = 0; i < EMS_PARM_MAX_NUM; i++)
		{
			if(g_ems_set_table[i].index == EE_EMS_TIME_PERIOD)
			{
				for(j = 0; j < EMS_TIME_PERIOD_NUM; j++)
				{
					tmp = EE_EMS_TIME_PERIOD + j * EMS_TIME_PERIOD_LEN;
					setting_set(LOCAL_EMS, tmp, (void*)&(g_ems_set_table[i].value), HALF_WORD_LEN);
				}
			}
			else if(g_ems_set_table[i].index == EE_EMS_TIME_PERIOD_MIN)
			{
				for(j = 0; j < EMS_TIME_PERIOD_NUM; j++)
				{
					tmp = EE_EMS_TIME_PERIOD + j * EMS_TIME_PERIOD_LEN + 2;
					setting_set(LOCAL_EMS, tmp, (void*)&(g_ems_set_table[i].value), HALF_WORD_LEN);
					tmp += 2;
					setting_set(LOCAL_EMS, tmp, (void*)&(g_ems_set_table[i].value), HALF_WORD_LEN);
				}
			}
			else if(g_ems_set_table[i].index == EE_EMS_TIME_PERIOD_HOUR)
			{
				for(j = 0; j < EMS_TIME_PERIOD_NUM; j++)
				{
					tmp = EE_EMS_TIME_PERIOD + j * EMS_TIME_PERIOD_LEN + 3;
					setting_set(LOCAL_EMS, tmp, (void*)&(g_ems_set_table[i].value), HALF_WORD_LEN);
					tmp += 2;
					setting_set(LOCAL_EMS, tmp, (void*)&(g_ems_set_table[i].value), HALF_WORD_LEN);
				}
			}
			else
			{
				setting_set(LOCAL_EMS, g_ems_set_table[i].index, (void*)&(g_ems_set_table[i].value), HALF_WORD_LEN);
			}
		}
		ems_init(product_info.model_num);
	}
}

/******************************************************************************
 * reset_total_runtime().
 * reset total runtime . [Called by app.]
 *
 * @param none.
 * @return none.
 *****************************************************************************/
void reset_total_runtime(void)
{
	clear_eeprom(0xFF, EE_TOTAL_RUNTIME_LEN, SYS_PARM, EE_TOTAL_RUNTIME);
	total_time_init();
}

/******************************************************************************
 * restore_energy().
 * reset total runtime . [Called by app.]
 *
 * @param none.
 * @return none.
 *****************************************************************************/
//void restore_energy(void)
//{
//	clear_eeprom(0xFF, EE_TOTAL_ENER_LEN, ENER_REC, EE_ENER);
////	energy_meter_init();
//}

/******************************************************************************
 * reset_total_runtime().
 * reset total runtime . [Called by app.]
 *
 * @param none.
 * @return none.
 *****************************************************************************/
void reset_safe_parm(void)
{
	clear_eeprom(0x00, EE_SAFE_PARM_VER, SYS_PARM, EE_SAFE_PARM_END);
}

/******************************************************************************
 * restore_enet_parm().
 * restore enet parm . [Called by app.]
 *
 * @param none.
 * @return none.
 *****************************************************************************/
void restore_enet_parm(void)
{
	uint8_t data[16];
	uint8_t index;
	for(index = 0; index < SYS_PARM_ENET_PARM_LEN; index++)
	{
		data[index] = enet_set_table[index + 1].value;
	}
	memory_copy((uint8_t *)&array.csu.csu_data.set.enet_set, \
											&data[0], SYS_PARM_ENET_PARM_LEN);
	setting_set(SYS_PARM, EE_SYS_PARM_ENET_PARM, &data[0], \
													SYS_PARM_ENET_PARM_LEN);
	setting_enet_init();
}

/******************************************************************************
 * restore_uart_parm().
 * restore uart parm . [Called by app.]
 *
 * @param none.
 * @return none.
 *****************************************************************************/
void restore_uart_parm(void)
{
	uint8_t uart_index;
	uint8_t index;
	for(index = 0; index < UART_NUMS; index++)
	{
		switch(index)
		{
			case 0:
				uart_index = EE_UART_INDEX_1;
				break;
			case 1:
				uart_index = EE_UART_INDEX_2;
				break;
			case 2:
				uart_index = EE_UART_INDEX_5;
				break;
			case 3:
				uart_index = EE_UART_INDEX_7;
				break;
			default:
				uart_index = EE_UART_INDEX_1;
				break;
		}
		array.pcsc.pcsc_ctrl.uart_conf[index].baud_rate = \
				setting_data_restore_uint32(&uart_set_table[0], \
										EE_UART_BAUD_RATE, UART_PARM_MAX_NUM);
		array.pcsc.pcsc_ctrl.uart_conf[index].slave_addr = \
				setting_data_restore_uint32(&uart_set_table[0], \
										EE_UART_SLAVE_ADDR, UART_PARM_MAX_NUM);
		array.pcsc.pcsc_ctrl.uart_conf[index].data_bits = \
				setting_data_restore_uint32(&uart_set_table[0], \
										EE_UART_DATA_BITS, UART_PARM_MAX_NUM);
		array.pcsc.pcsc_ctrl.uart_conf[index].uart_index = \
				setting_data_restore_uint32(&uart_set_table[0], uart_index, \
															UART_PARM_MAX_NUM);
		array.pcsc.pcsc_ctrl.uart_conf[index].stop_bits = \
				setting_data_restore_uint32(&uart_set_table[0], \
										EE_UART_STOP_BITS, UART_PARM_MAX_NUM);
		array.pcsc.pcsc_ctrl.uart_conf[index].parity = \
				setting_data_restore_uint32(&uart_set_table[0], \
											EE_UART_PARITY, UART_PARM_MAX_NUM);
		setting_set(SYS_PARM, EE_SYS_PARM_ENET_PARM, \
				&array.pcsc.pcsc_ctrl.uart_conf[index], SYS_PARM_ENET_PARM_LEN);
	}
}

/******************************************************************************
 * bkgd_task_restore_factory().
 * restore factory data . [Called by app.]
 *
 * @param none.
 * @return none.
 *****************************************************************************/
void bkgd_task_restore_factory(void)
{
	static uint8_t index = 0;

	switch(index)
	{
		case 0:
			restore_ems_data();
			index++;
			break;
		case 1:
			restore_uart_parm();
			restore_enet_parm();
			index++;
			break;
		case 2:
			if(factory_parm.bits.system_test)
			{
				reset_total_runtime();
				index++;
			}
			else
			{
				index = 0xFF;
			}
			break;
		case 3:
			clear_metering_data();
			index++;
			break;
		case 4:
			clear_backflow_data();
			index++;
			break;
		case 5:
			sdk_record_delete(DIAG_LOG);
			sdk_record_delete(OPAT_LOG);
			sdk_record_delete(DEBUG_LOG);
			index++;
			break;
		default:
			trigger_restore_factory = FALSE;
			array.pcsc.pcsc_ctrl.cmd.bit.restore_factory_default = FALSE;
			factory_parm.bits.restore_data = FALSE;
			fault_reset_flag = TRUE;
			index = 0;
			break;
	}
}

/******************************************************************************
 * slow_task_set_scenario().
 * Set scenario. [Called by.]
 *
 * @param	none (I)
 * @return	none
 *****************************************************************************/
void slow_task_set_scenario(void)
{
	if(now_scenario_setting != array.pcsc.pcsc_ctrl.scenario_setting)
	{
		// clear_struct_data((uint8_t*)&trigger_diag[0], sizeof(trigger_diag));
		// rs485_device_deinit(now_scenario_setting);
		// trigger_pm_init = power_magic_init_ok;
		// fault_reset_flag = TRUE;
		// array.pcsc.pcsc_ctrl.active_power_ref = 0;
		now_scenario_setting = array.pcsc.pcsc_ctrl.scenario_setting;
		setting_set(SYS_PARM, EE_SYS_PARM_SCENARIO_SETTING, &now_scenario_setting, HALF_WORD_LEN);
		sdk_sys_reset();
		// if(ONLY_COMBINER_CABINET == array.pcsc.pcsc_ctrl.scenario_setting)
		// {
		// 	trigger_pm_init = TRUE;
		// 	array.pcsc.pcsc_ctrl.rs485_enable.bit.dehumidifier = TRUE;
		// 	product_info.model_num = POWER_MAGIC_400V;
		// 	array.pcsc.pcsc_ctrl.pcsm_nums_set = 0;
		// 	array.csu.csu_data.csu_const.base_rated_power = pcs_machine_type[POWER_MAGIC_400V].rated_power;
//		}
//		else if(COMBINER_STORAGE == array.pcsc.pcsc_ctrl.scenario_setting)
//		{
//			array.pcsc.pcsc_ctrl.rs485_enable.bit.dehumidifier = TRUE;
//		}
	}
}

/******************************************************************************
 * slow_task_set_pcsm_nums().
 * energy storage num modify. [Called by.]
 *
 * @param	none (I)
 * @return	none
 *****************************************************************************/
void slow_task_set_pcsm_nums(void)
{
	uint8_t i;

	if(now_pcsm_num_setting != array.pcsc.pcsc_ctrl.pcsm_nums_set)
	{
		clear_struct_data((uint8_t*)&trigger_comm_diag[0], sizeof(trigger_comm_diag));
		for(i = 0; (i < array.pcsc.pcsc_ctrl.pcsm_nums_set) && (i < PCSM_NUMS); i++)
		{
			trigger_comm_diag[i] = TRUE;
		}
		fault_reset_flag = TRUE;
		now_pcsm_num_setting = array.pcsc.pcsc_ctrl.pcsm_nums_set;
		setting_set(SYS_PARM, EE_SYS_PARM_PCSM_NUMS_SET, &now_pcsm_num_setting, HALF_WORD_LEN);
	}
}

int32_t file_system_init(void)
{
	int32_t ret = -1;
	fs_stat_fs p_buf;

	ret = sdk_fs_stat_fs((const int8_t*)"1:", &p_buf);
	if(SF_OK == ret)
	{
		// Check if there is enough remaining space to store tmp.bin
		if ((p_buf.f_bfree <= 200) || (p_buf.f_bfree >= 500))
		{
			sdk_fs_format((const int8_t*)"1:");
			sdk_log_a("format fatfs\r\n");
			opt_log_record("format fatfs");
			ret = -1;
		}
		else
		{
			ret = 0;
		}
	}
	else
	{
		ret = -1;
	}
	return ret;
}
/******************************************************************************
 * End of module
 ******************************************************************************/
