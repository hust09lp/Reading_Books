/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     FIFO_CAN.h
  * @brief    FIFO CAN module header file
  * @company  SOFARSOLAR
  * @author   ZZJ
  * @note
  * @version  V01
  * @date     2023/08/26
  */
/*****************************************************************************/

#ifndef __FIFO_CAN_H__
#define __FIFO_CAN_H__

 /******************************************************************************
 * INCLUDE FILE
 ******************************************************************************/
 // Include system file -------------------------------------------------------

 // Include project file ------------------------------------------------------
#include "common.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/
typedef struct
{
	uint8_t dst_addr;		// destination address
	uint8_t fun_code;		// CAN Frame function code
	uint8_t len;			// CAN Frame data length
	half_word_t offset;
}pcsm_cmd_t;

typedef struct
{
	uint16_t   head;
	bool_t     empty;
	uint16_t   tail;
	bool_t     full;
	uint16_t   len;
	bool_t     busy;
	pcsm_cmd_t *buff;
	uint16_t   size;
	uint16_t   max_len;         // Maximum numbers of reg frame in a FIFO
	uint16_t   lost_cnt;        // Numbers of lost data(push when FIFO is full)
}fifo_can_cmd_t;

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/
extern fifo_can_cmd_t fifo_can1_cmd;
extern bool_t pause_fifo_can1_pop;

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void fifo_can_init(void);
bool_t fifo_can_push(fifo_can_cmd_t *fifo_can_cmd, pcsm_cmd_t *can_cmd);
bool_t fifo_can_pop(fifo_can_cmd_t *fifo_can_cmd, pcsm_cmd_t *can_cmd);
void fast_task_can1_send(void);

#endif
/******************************************************************************
* End of module
******************************************************************************/
