/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     measure.h
  * @brief    Measure module header file
  * @company  SOFARSOLAR
  * @author   ZHH
  * @note
  * @version  V04
  * @date     2023/06/01
  */
/*****************************************************************************/

#ifndef __MEASURE_H__
#define __MEASURE_H__

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "common.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define DC_AVG_WIN_SIZES                                                     20

#define AD_CH_T_BOARD                                                         0
#define AD_CH_T_AC_FUS                                                        1
#define AD_CH_MUX_RESERVE1                                                       1
#define AD_CH_MUX_RESERVE2                                                       1
#define AD_CH_IGRD_R                                                          1
#define AD_CH_HW_VER                                                          2
#define AD_CH_IGRD_S                                                          3
#define AD_CH_IGRD_T                                                          4
#define AD_CH_VPCS_RN                                                         5
#define AD_CH_VPCS_RS                                                         6
#define AD_CH_VPCS_RT                                                         7
#define AD_CH_VGRD_RN                                                         8
#define AD_CH_VGRD_RS                                                         9
#define AD_CH_VGRD_RT                                                        10

#define TEMP_NTC_OUT_LIMIT                                                 4000

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

// AC signals channel definition
enum
{
	VPCS_R = 0,
	VPCS_S,
	VPCS_T,
	VGRD_R,
	VGRD_S,
	VGRD_T,
	VPCS_RS,
	VPCS_ST,
	VPCS_TR,
	VGRD_RS,
	VGRD_ST,
	VGRD_TR,
	IGRD_R,
	IGRD_S,
	IGRD_T,
	AC_CH_SIZES
};

// DC signals channel definition
enum
{
	T_BOARD = 0,
	T_AC_FUS,
	RESERVE_1,
	RESERVE_2,
	DC_CH_SIZES
};

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/
typedef struct
{
	int16_t vpcs_rn;
	int16_t vpcs_rs;
	int16_t vpcs_rt;
	int16_t vgrd_rn;
	int16_t vgrd_rs;
	int16_t vgrd_rt;
	int16_t vpcs_r;
	int16_t vpcs_s;
	int16_t vpcs_t;
	int16_t vpcs_st;
	int16_t vpcs_tr;
	int16_t vgrd_r;
	int16_t vgrd_s;
	int16_t vgrd_t;
	int16_t vgrd_st;
	int16_t vgrd_tr;
	int16_t igrd_r;
	int16_t igrd_s;
	int16_t igrd_t;
}ac_sample_t;

typedef struct
{
	float32_t rms;
	float32_t sum;
	float32_t win_sum;
	uint32_t  adc_win_sum;
	uint32_t  index;
	uint32_t  win_size;
	float32_t last_theta;
	int32_t   offset;
	float32_t physical;
}ac_sum_t;

typedef struct
{
	int16_t v_hwv;
	int16_t t_board;
	int16_t t_ac_fus;
	int16_t reserve_1;
	int16_t reserve_2;
}dc_sample_t;

typedef struct
{
	float32_t avg;
	int32_t sum;
	int32_t adc_avg;
	int16_t index;
	int16_t buff[DC_AVG_WIN_SIZES];
}dc_sum_t;

typedef struct
{
	float64_t charge_today;
	float64_t discharge_today;
	float64_t charge_total;
	float64_t discharge_total;
}energy_t;

typedef struct
{
    uint32_t value;
    uint16_t crc;
}runtime_t;

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/
extern ac_sample_t g_ac_sample;
extern dc_sample_t g_dc_sample;
extern ac_sum_t    g_ac_signal[AC_CH_SIZES];
extern dc_sum_t    g_dc_signal[DC_CH_SIZES];
extern energy_t    energy;

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void measure_init(void);
void energy_meter_init(void);

void energy_rec_clear(void);

void crtl_task_ac_sample(void);
void crtl_task_dc_sample(void);
void crtl_task_mux_sample(void);
void fast_task_calc(void);
void fast_task_energy_meter(void);
void fast_task_measure(void);
void slow_task_measure(void);


#endif
/******************************************************************************
* End of module
******************************************************************************/
