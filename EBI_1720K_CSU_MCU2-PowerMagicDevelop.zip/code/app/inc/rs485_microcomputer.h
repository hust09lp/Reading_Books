/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
	* @file     rs485_microcompute.h
	* @brief    MICROCOMPUTE module
	* @company  SOFARSOLAR
	* @author   ZZJ
	* @note
	* @version  V01
	* @date     2023/09/16
	*/
/*****************************************************************************/

#ifndef __RS485_MICROCOMPUTE_H__
#define __RS485_MICROCOMPUTE_H__

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "common.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define MOD_FRAME_MAX_LENGTH                                                256

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/
typedef struct
{
	// Register offset = 0
	uint8_t breaker               : 1;
	uint8_t uncharged_spring      : 1;
	uint8_t remote_control        : 1;
	uint8_t Handcart_position     : 1;
	uint8_t reserved_1            : 4;
	// Register offset = 2
	uint8_t quick_break_trip      : 1;
	uint8_t reserved_2            : 1;
	uint8_t overcurrent_tripping  : 1;
	uint8_t overload_tripping     : 1;
	uint8_t reserved_3            : 4;
	// Register offset = 3
	uint8_t reserved_4            : 1;
	uint8_t under_voltage_trip    : 1;
	uint8_t over_voltage_trip     : 1;
	uint8_t reserved_5            : 2;
	uint8_t lost_voltage_trip     : 1;
	uint8_t reserved_6            : 2;
	// Register offset = 6
	uint8_t quick_break_alarm     : 1;
	uint8_t reserved_7            : 1;
	uint8_t overcurrent_alarm     : 1;
	uint8_t overload_alarm        : 1;
	uint8_t reserved_8            : 4;
	// Register offset = 7
	uint8_t reserved_9            : 1;
	uint8_t under_voltage_alarm   : 1;
	uint8_t over_voltage_alarm    : 1;
	uint8_t reserved_10           : 2;
	uint8_t lost_voltage_alarm    : 1;
	uint8_t reserved_11           : 2;
	// Register offset = 10
	uint8_t accident_total        : 1;
	uint8_t alarm_total           : 1;
	uint8_t reserved_12           : 6;
} microcomputer_t;

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/
extern int16_t fault_microcomputer_cnt;
extern int16_t fault_microcomputer_ref;
extern bool_t trigger_microcomputer;
extern microcomputer_t microcomputer[2];

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void rs485_microcomputer_init(void);

void rs485_task_microcomputer(void);

#endif
/******************************************************************************
* End of module
******************************************************************************/
