/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     app_dido.h
  * @brief    App DI&DO management module header file
  * @company  SOFARSOLAR
  * @author   HH
  * @note
  * @version  V01
  * @date     2023/03/09
  */
/*****************************************************************************/

#ifndef __SHELL_H__
#define __SHELL_H__

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "common.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
typedef long (*syscall_func)(void);

typedef int (*cmd_function_t)(int argc, char **argv);

struct finsh_syscall
{
	const char     *name;       /* the name of system call */
	const char     *desc;       /* description of system call */
	syscall_func func;      /* the function address of system call */
};

#define RT_UNUSED(x)                   ((void)x)
#define RT_USED                     __attribute__((used))
#define RT_SECTION(x)               __attribute__((section(x)))


#define MSH_FUNCTION_EXPORT_CMD(name, cmd, desc)                      \
				const char __fsym_##cmd##_name[] RT_SECTION(".rodata.name") = #cmd;    \
				const char __fsym_##cmd##_desc[] RT_SECTION(".rodata.name") = #desc;   \
				RT_USED const struct finsh_syscall __fsym_##cmd RT_SECTION("FSymTab")= \
				{                           \
					__fsym_##cmd##_name,    \
					__fsym_##cmd##_desc,    \
					(syscall_func)&name     \
				};


/**
 * @ingroup msh
 *
 * This macro exports a command to module shell.
 *
 * @param command is the name of the command.
 * @param desc is the description of the command, which will show in help list.
 */
#define MSH_CMD_EXPORT(command, desc)   \
								MSH_FUNCTION_EXPORT_CMD(command, command, desc)


/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/


/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void shell_init(void);

#endif
/******************************************************************************
* End of module
******************************************************************************/
