/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     rs485_dehumidification.h
  * @brief    DEHUM module
  * @company  SOFARSOLAR
  * @author   ZZJ
  * @note
  * @version  V01
  * @date     2023/09/16
  */
/*****************************************************************************/

#ifndef __RS485_DEHUM_H__
#define __RS485_DEHUM_H__

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "common.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define RS485_DEHUM                                              (2)
#define RS485_DEHUM_SLAVE_ADDR                                   (1)

#define DEHUM_MODEL_READ                                 (0x104) // 除湿器机型点位
#define DEHUM_MODEL_READ_VALUE                             (0x5346) // 除湿器机型点位值

#define DEHUM_AUTO_MODE_ADDR_BRIM                             (0x0A) // 除湿器工作模式点位
#define DEHUM_AUTO_MODE_VALUE_BRIM                               (0) // 除湿器工作模式值
#define DEHUM_RN_ADDR_BRIM                                    (0x04) // 设置除湿器湿度动作点，点位
#define DEHUM_RN_DEFAULT_VALUE_BRIM                             (75) // 设置除湿器湿度动作点，值
#define DEHUM_RETURN_DIFFERENCE_ADDR_BRIM                     (0x05) // 设置除湿器湿度回差点位
#define DEHUM_RETURN_DIFF_DEFAULT_VALUE_BRIM                    (15) // 设置除湿器湿度回差 值
#define DEHUM_DATA_LEN_BRIM                                     (14) // 除湿器设定值的数据长度
#define DEHUM_TEMP_READ_ADDR_BRIM                             (0x0C) // 读取除湿器温度点位
#define DEHUM_RN_READ_ADDR_BRIM                             (0x0D) // 读取除湿器湿度点位
#define DEHUM_AUTO_MODE_ADDR_ANDEAN                          (0x0200) // 除湿器工作模式点位
#define DEHUM_AUTO_MODE_VALUE_ANDEAN                              (0) // 除湿器工作模式值
#define DEHUM_RN_ADDR_ANDEAN                                 (0x0201) // 设置除湿器湿度动作点，点位
#define DEHUM_RN_DEFAULT_VALUE_ANDEAN                            (75) // 设置除湿器湿度动作点，值
#define DEHUM_RETURN_DIFFERENCE_ADDR_ANDEAN                  (0x0202) // 设置除湿器湿度回差点位
#define DEHUM_RETURN_DIFF_DEFAULT_VALUE_ANDEAN                   (15) // 设置除湿器湿度回差 值
#define DEHUM_DATA_LEN_ANDEAN                                    (3) // 除湿器设定值的数据长度
#define DEHUM_RN_READ_ADDR_ANDEAN                               (0x01) // 读取除湿器湿度点位
#define DEHUM_TEMP_READ_ADDR_ANDEAN                             (0x02) // 读取除湿器温度点位
/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
typedef enum
{
  DEHUMIDIFIERPOINT_MODEL_BRIM = 0,
  DEHUMIDIFIERPOINT_MODEL_ANDEAN,
}dehumidifierpoint_model_code_e;

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/
typedef struct
{
  uint16_t humidity;
  uint16_t temperature;
}dehumidifier_data_t;
typedef struct
{
  uint16_t humidity_set;
  uint16_t humidity_diff_set;
}dehumidifier_set_t;

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/
extern int16_t fault_dehumidifier_cnt;
extern int16_t fault_dehumidifier_ref;
extern bool_t trigger_dehumidifier;
extern dehumidifier_data_t dehumidifier_data;
extern dehumidifier_set_t dehumidifier_set;
extern bool_t dehunidification_set_param_flag;

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void rs485_dehumidification_init(void);

void rs485_task_dehumidification(void);

#endif
/******************************************************************************
* End of module
******************************************************************************/
