/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     product.h
  * @brief    Product information header file
  * @company  SOFARSOLAR
  * @author   HH
  * @note
  * @version  V01
  * @date     2023/02/19
  */
/*****************************************************************************/
#ifndef __PRODUCT_H__
#define __PRODUCT_H__

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "common.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
// SN char numbers
#define SN_SIZE                                                              21

// product info
#define SOFTWARE_VERSION        "V1.0.38"
#define HARDWARE_VERSION        "V0.0.1"

#define PM_400V_MODEL_CODE                                                "049"
#define PM_690V_MODEL_CODE                                                "049"
#define PM_400V_POWER_LEVEL_CODE                                         "125K"
#define PM_690V_POWER_LEVEL_CODE                                         "215K"

// unit: 0.1kW
#define POWER_MAGIC_400V_POWER_RATED                                       1250
#define POWER_MAGIC_690V_POWER_RATED                                       2150

#define PM_MODEL_NUM                                                          2

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
typedef enum
{
	PL_SPECIAL = 0,
	PL_INVERTER,
	PL_LI_BATTERY,
	PL_IDC_POWER
}PDT_LINE_E;

typedef enum
{
	POWER_MAGIC_400V = 0,
	POWER_MAGIC_690V,
	POWER_MAGIC_END = POWER_MAGIC_690V,
}PRODUCT_MODEL_E;

typedef enum
{
	STANDARD_SCENARIO           = 0,
	ONE_STORAGE_TANK            = 1,
	ONE_STORAGE_TANK_XIAOJU_1_2 = 2,
	ONLY_COMBINER_CABINET       = 3,
	SCENARIO_END = ONLY_COMBINER_CABINET,
}APPLICATION_SCENARIO_E;

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/
typedef struct
{
	uint16_t low    : 8;
	uint16_t middle : 8;
	uint16_t high   : 8;
	uint16_t rvd    : 8;
}ver_bytes_t;

typedef union
{
	ver_bytes_t bytes;
	uint32_t    all;
}version_t;

typedef struct
{
	uint16_t day    : 8;
	uint16_t month  : 8;
	uint16_t year   : 8;
	uint16_t rvd    : 8;
}date_bytes_t;

typedef union
{
	date_bytes_t bytes;
	uint32_t     all;
}date_t;

typedef struct
{
	uint8_t brand;       // brand('S': SOFARSOLAR)
	uint8_t factory;     // factory point('D': Dongguan)
	uint8_t pdt_line;    // product line(?: PCS line)???
	uint8_t mcode[7];    // PCBA board material code(HVSCSU: banama system CSU)???
	uint8_t local;       // sales area('C': China)
	uint8_t year;        // factory year(23: 2023)
	uint8_t month;       // factory month(1~12)
	uint8_t day;         // factory day(1~31)
	uint16_t no;         // serial numbers(0~9999)
}sn_t;

typedef struct
{
//	half_word_t sn[16];
	half_word_t fac_name[8];    // Factory Name
	half_word_t brand_name[8];  // Brand Name
	half_word_t model_name[8];  // Model Name
	uint16_t    rating;         // Norminal Power Rating
	half_word_t fac_date[2];    // Factory Date
	half_word_t use_date[2];    // USE date
	uint8_t     model_num;      // (0: 400V, 1: 690V)
}product_info_t;

// Match key to get value
typedef struct
{
	uint16_t rated_volt;          // value, 0: 400V, 1: 690V
	uint16_t rated_power;         // value, 0: 1250, 1: 2150
	uint8_t power_level_code[4];  // key, 125K, 215K
	uint8_t model_code[3];        // key, 049
}pcs_machine_type_t;

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/
extern version_t   csu_mcu2_boot_v;
extern version_t   csu_mcu2_core_v;
extern version_t   csu_mcu2_app_v;
extern uint8_t     csu_mcu2_hw_v;
extern half_word_t csu_mcu2_can1_v;
extern half_word_t csu_mcu2_can5_v;
extern half_word_t csu_mcu2_mods_v;
extern uint8_t     sz_csu_sn[];
extern uint8_t     system_sn[];
extern sn_t        csu_sn;

extern product_info_t product_info;
extern pcs_machine_type_t pcs_machine_type[PM_MODEL_NUM];

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void product_init(void);
uint8_t get_hw_version(void);
version_t get_boot_version(void);
void output_product_info(void);

#endif
/******************************************************************************
* End of module
******************************************************************************/
