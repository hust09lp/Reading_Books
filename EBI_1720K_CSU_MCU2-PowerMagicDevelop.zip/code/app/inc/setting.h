/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     setting.h
  * @brief    parameter setting module header file
  * @company  SOFARSOLAR
  * @author   WWX
  * @note
  * @version  V01
  * @date     2023/05/22
  */
  /*****************************************************************************/

#ifndef __SETTING_H__
#define __SETTING_H__

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "common.h"
#include "measure.h"
#include "ems.h"
#include "dlt645.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define FUT_SET                                                               0
#define SAFE_PARM                                                             1
#define ENER_REC                                                              2
#define SYS_PARM                                                              3
#define LOCAL_EMS                                                             4
#define XIAOJU_PARM                                                           5

#define FUT_SET_SIZE                                                       1024
#define SAFE_PARM_SIZE                                                     3072
#define ENER_REC_SIZE                                                      2048
#define SYS_PARM_SIZE                                                      1024
#define LOCAL_EMS_SIZE                                                     1024
#define XIAOJU_PARM_SIZE                                                    128

#define SYS_PARM_ENET_PARM_LEN                                             (16)
#define SYS_PARM_UART_PARM_LEN                                              (9)
#define SYS_PARM_CTRL_PARM_LEN                                              (2)

#define CALIB_DATA_LEN                                                      (4)
#define ONE_BYTE_LEN                                                        (1)
#define HALF_WORD_LEN                                                       (2)
#define WORD_LEN                                                            (4)
#define RUNTIME_NUM                                                        (42)
#define CRC16_LEN                                                           (2)
#define RUNTIME_WORD_LEN                                 (WORD_LEN + CRC16_LEN)
#define ENERGY_DATA_LEN													   (32)
#define ENERGY_NUM														   (10)
#define ENERGY_TIME_DATA_LEN                                                (3)
#define ENERGY_TIME_DATA_LEN_TOTAL			(ENERGY_TIME_DATA_LEN * ENERGY_NUM)
#define ONE_SAFE_PARM_MAX_LEN                                             (256)
#define SN_LEN                                                             (20)

#define UART_NUMS                                                           (4)

#define UART_PARM_MAX_NUM                                                  (10)
#define ENET_PARM_MAX_NUM                                                  (17)
#define MCU2_INTER_CONF_MAX_NUM                                            (12)
#define XIAOJU_PARM_MAX_NUM                                                 (5)

#define SAFE_PARM_INFO_LEN                                                  (6)
#define SAFE_PARM_CHKSUM_LEN                                               (18)

#define METER_CUR_DIR_LIM                           (MASK_BITS(METER_PORT_NUM))
#define RS485_ENABLE_LIM                          (MASK_BITS(RS485_DEVICE_NUM))
#define MAX_SET_POWER                                         (UINT16_MAX - 10)
/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
// fut set eeprom address
enum
{
	EE_FUT1             = 0,
	EE_CALIB_RESULT     = 0x0100,
	EE_T_AC_FUSE_GAIN   = (EE_CALIB_RESULT + 4),
	EE_T_AC_FUSE_OFFSET = (EE_T_AC_FUSE_GAIN + CALIB_DATA_LEN * 1),
	EE_T_DC_FUS1_GAIN   = (EE_T_AC_FUSE_GAIN + CALIB_DATA_LEN * 2),
	EE_T_DC_FUS1_OFFSET = (EE_T_AC_FUSE_GAIN + CALIB_DATA_LEN * 3),
	EE_T_DC_FUS2_GAIN   = (EE_T_AC_FUSE_GAIN + CALIB_DATA_LEN * 4),
	EE_T_DC_FUS2_OFFSET = (EE_T_AC_FUSE_GAIN + CALIB_DATA_LEN * 5),
	EE_V_DC1_GAIN       = (EE_T_AC_FUSE_GAIN + CALIB_DATA_LEN * 6),
	EE_V_DC1_OFFSET     = (EE_T_AC_FUSE_GAIN + CALIB_DATA_LEN * 7),
	EE_V_DC2_GAIN       = (EE_T_AC_FUSE_GAIN + CALIB_DATA_LEN * 8),
	EE_V_DC2_OFFSET     = (EE_T_AC_FUSE_GAIN + CALIB_DATA_LEN * 9),
	EE_V_PCS_RS_GAIN    = (EE_T_AC_FUSE_GAIN + CALIB_DATA_LEN * 10),
	EE_V_PCS_ST_GAIN    = (EE_T_AC_FUSE_GAIN + CALIB_DATA_LEN * 11),
	EE_V_PCS_TR_GAIN    = (EE_T_AC_FUSE_GAIN + CALIB_DATA_LEN * 12),
	EE_V_GRD_RS_GAIN    = (EE_T_AC_FUSE_GAIN + CALIB_DATA_LEN * 13),
	EE_V_GRD_ST_GAIN    = (EE_T_AC_FUSE_GAIN + CALIB_DATA_LEN * 14),
	EE_V_GRD_TR_GAIN    = (EE_T_AC_FUSE_GAIN + CALIB_DATA_LEN * 15),
	EE_I_OUT_R_GAIN     = (EE_T_AC_FUSE_GAIN + CALIB_DATA_LEN * 16),
	EE_I_OUT_S_GAIN     = (EE_T_AC_FUSE_GAIN + CALIB_DATA_LEN * 17),
	EE_I_OUT_T_GAIN     = (EE_T_AC_FUSE_GAIN + CALIB_DATA_LEN * 18),
	EE_POWER_P_GAIN     = (EE_T_AC_FUSE_GAIN + CALIB_DATA_LEN * 19),
	EE_POWER_Q_GAIN     = (EE_T_AC_FUSE_GAIN + CALIB_DATA_LEN * 20),
	EE_POWER_S_GAIN     = (EE_T_AC_FUSE_GAIN + CALIB_DATA_LEN * 21),
	EE_CSU_SN           = (EE_POWER_S_GAIN + CALIB_DATA_LEN),
	EE_SYSTEM_SN        = (EE_CSU_SN + SN_LEN),
};

// safty parameters eeprom address
enum
{
	EE_SAFE_PARM_VER    = 0,
	EE_SAFE_PARM_CHKSUM = SAFE_PARM_INFO_LEN,
	EE_SAFE_PARM_GRP1   = (EE_SAFE_PARM_VER  +  ONE_SAFE_PARM_MAX_LEN),
	EE_SAFE_PARM_GRP2   = (EE_SAFE_PARM_GRP1 +  ONE_SAFE_PARM_MAX_LEN),
	EE_SAFE_PARM_GRP3   = (EE_SAFE_PARM_GRP2 +  ONE_SAFE_PARM_MAX_LEN),
	EE_SAFE_PARM_GRP4   = (EE_SAFE_PARM_GRP3 +  ONE_SAFE_PARM_MAX_LEN),
	EE_SAFE_PARM_GRP5   = (EE_SAFE_PARM_GRP4 +  ONE_SAFE_PARM_MAX_LEN),
	EE_SAFE_PARM_GRP6   = (EE_SAFE_PARM_GRP5 +  ONE_SAFE_PARM_MAX_LEN),
	EE_SAFE_PARM_GRP7   = (EE_SAFE_PARM_GRP6 +  ONE_SAFE_PARM_MAX_LEN),
	EE_SAFE_PARM_GRP8   = (EE_SAFE_PARM_GRP7 +  ONE_SAFE_PARM_MAX_LEN),
	EE_SAFE_PARM_GRP9   = (EE_SAFE_PARM_GRP8 +  ONE_SAFE_PARM_MAX_LEN),
	EE_SAFE_PARM_END    = (EE_SAFE_PARM_GRP9 +  ONE_SAFE_PARM_MAX_LEN),
};

// energy record eeprom address
enum
{
	EE_ENER 					= 0,
	EE_TOTAL_ENER_LEN			= (EE_ENER + ENERGY_DATA_LEN * ENERGY_NUM),
	EE_ENER_TIME_PARA,
    EE_ENER_TIME_PARA_LEN       = (EE_ENER_TIME_PARA + ENERGY_TIME_DATA_LEN_TOTAL),
};

// enet parm
enum
{
	EE_IP_1 = 0,
	EE_IP_2,
	EE_IP_3,
	EE_IP_4,
	EE_MASK_1,
	EE_MASK_2,
	EE_MASK_3,
	EE_MASK_4,
	EE_GATEWAY_1,
	EE_GATEWAY_2,
	EE_GATEWAY_3,
	EE_GATEWAY_4,
	EE_DNS_1,
	EE_DNS_2,
	EE_DNS_3,
	EE_DNS_4,
};

// uart parm
enum
{
	EE_UART_BAUD_RATE = 0,
	EE_UART_INDEX_1 = EE_UART_BAUD_RATE + WORD_LEN,
	EE_UART_SLAVE_ADDR,
	EE_UART_DATA_BITS,
	EE_UART_STOP_BITS,
	EE_UART_PARITY,
	EE_UART_INDEX_2 = EE_UART_INDEX_1 + WORD_LEN + 5 * ONE_BYTE_LEN,
	EE_UART_INDEX_5 = EE_UART_INDEX_2 + WORD_LEN + 5 * ONE_BYTE_LEN,
	EE_UART_INDEX_7 = EE_UART_INDEX_5 + WORD_LEN + 5 * ONE_BYTE_LEN,
};

// system parameters eeprom address
enum // SYS_PARM
{
	EE_SYS_PARM_SECTOR_START                   = 0,
	EE_TOTAL_RUNTIME          = EE_SYS_PARM_SECTOR_START,
	EE_TOTAL_RUNTIME_LEN      = (EE_TOTAL_RUNTIME + 4 * 64),
	EE_SYS_PARM_ENET_PARM,
	EE_SYS_PARM_ENET_PARM_LEN = (EE_SYS_PARM_ENET_PARM + SYS_PARM_ENET_PARM_LEN),
	EE_SYS_PARM_UART_PARM,
	EE_SYS_PARM_UART_PARM_LEN = (EE_SYS_PARM_UART_PARM + SYS_PARM_UART_PARM_LEN * UART_NUMS),
	EE_SYS_PARM_CTRL_PARM,
    EE_SYS_PARM_CTRL_PARM_LEN = (EE_SYS_PARM_CTRL_PARM + SYS_PARM_CTRL_PARM_LEN - 1),
	EE_SYS_PARM_PCSM_NUMS_SET,
	EE_SYS_PARM_PCSM_NUMS_SET_LEN = (EE_SYS_PARM_PCSM_NUMS_SET + HALF_WORD_LEN - 1),
	EE_SYS_PARM_RS485_ENABLE,
	EE_SYS_PARM_RS485_ENABLE_LEN = (EE_SYS_PARM_RS485_ENABLE + HALF_WORD_LEN - 1),
	EE_SYS_PARM_SCENARIO_SETTING,
	EE_SYS_PARM_SCENARIO_SETTING_LEN = (EE_SYS_PARM_SCENARIO_SETTING + HALF_WORD_LEN - 1),
	EE_SYS_PARM_PV_METER_MODEL,
	EE_SYS_PARM_PV_METER_MODEL_LEN = (EE_SYS_PARM_PV_METER_MODEL + HALF_WORD_LEN - 1),
	EE_SYS_PARM_PV_METER_NUM,
	EE_SYS_PARM_PV_METER_NUM_LEN = (EE_SYS_PARM_PV_METER_NUM + HALF_WORD_LEN - 1),
	EE_SYS_PARM_CSU_ROLE,
	EE_SYS_PARM_CSU_ROLE_LEN = (EE_SYS_PARM_CSU_ROLE + HALF_WORD_LEN - 1),
	EE_SYS_PARM_PRODUCT_MODEL,
	EE_SYS_PARM_PRODUCT_MODEL_LEN = (EE_SYS_PARM_PRODUCT_MODEL + HALF_WORD_LEN - 1),
	EE_SYS_PARM_DEHUMIDIFIER_SET,
	EE_SYS_PARM_DEHUMIDIFIER_SET_LEN = (EE_SYS_PARM_DEHUMIDIFIER_SET + HALF_WORD_LEN - 1),
	EE_SYS_PARM_DEHUMIDIFIER_DIFF_SET,
	EE_SYS_PARM_DEHUMIDIFIER_DIFF_SET_LEN = (EE_SYS_PARM_DEHUMIDIFIER_DIFF_SET + HALF_WORD_LEN - 1),
	EE_SYS_PARM_PCC_METER_MODEL,
	EE_SYS_PARM_PCC_METER_MODEL_LEN = (EE_SYS_PARM_PCC_METER_MODEL + HALF_WORD_LEN - 1),
	EE_SYS_PARM_SYS_SIGNAL_ENABLE,
	EE_SYS_PARM_SYS_SIGNAL_ENABLE_LEN = (EE_SYS_PARM_SYS_SIGNAL_ENABLE + HALF_WORD_LEN - 1),
	EE_SYS_PARM_SECTOR_END,
};
// local ems eeprom address
enum
{
	EE_EMS_SECTOR_START                   = 0,
	EE_EMS_DEMAND_ENABLE                  = (EE_EMS_SECTOR_START),
	EE_EMS_DEMAND_QUANTITY                = (EE_EMS_DEMAND_ENABLE + HALF_WORD_LEN),
	EE_EMS_DEMAND_DEADBAND                = (EE_EMS_DEMAND_QUANTITY + HALF_WORD_LEN),
	EE_EMS_ANTI_ENABLE                    = (EE_EMS_DEMAND_DEADBAND + HALF_WORD_LEN),
	EE_EMS_ALLOW_SALE_POWER               = (EE_EMS_ANTI_ENABLE + HALF_WORD_LEN),
	EE_EMS_C2D_ENABLE                     = (EE_EMS_ALLOW_SALE_POWER + HALF_WORD_LEN),
	EE_EMS_ALLOW_PURCHASE_POWER           = (EE_EMS_C2D_ENABLE + HALF_WORD_LEN),
	EE_EMS_CPFV_ENABLE                    = (EE_EMS_ALLOW_PURCHASE_POWER + HALF_WORD_LEN),
	EE_EMS_TIME_PERIOD                    = (EE_EMS_CPFV_ENABLE + HALF_WORD_LEN),
	EE_EMS_TIME_PERIOD_MIN                = (EE_EMS_TIME_PERIOD + HALF_WORD_LEN),
	EE_EMS_TIME_PERIOD_HOUR,
	EE_EMS_CHG_SOC_MAX                    = (EE_EMS_TIME_PERIOD + EMS_TIME_PERIOD_LEN * EMS_TIME_PERIOD_NUM), // 不使用
	EE_EMS_CHG_POWER_STEP                 = (EE_EMS_CHG_SOC_MAX + HALF_WORD_LEN), // 不使用
	EE_EMS_K1                             = (EE_EMS_CHG_POWER_STEP + HALF_WORD_LEN), // 不使用
	EE_EMS_THEORY_MAX_CHG_POWER           = (EE_EMS_K1 + HALF_WORD_LEN),
	EE_EMS_DISCHG_SOC_MIN                 = (EE_EMS_THEORY_MAX_CHG_POWER + HALF_WORD_LEN), // 不使用
	EE_EMS_DISCHG_POWER_STEP              = (EE_EMS_DISCHG_SOC_MIN + HALF_WORD_LEN), // 不使用
	EE_EMS_K2                             = (EE_EMS_DISCHG_POWER_STEP + HALF_WORD_LEN), // 不使用
	EE_EMS_THEORY_MAX_DISCHG_POWER        = (EE_EMS_K2 + HALF_WORD_LEN),
	EE_EMS_SOC_MAINT_ENABLE               = (EE_EMS_THEORY_MAX_DISCHG_POWER + HALF_WORD_LEN),
	EE_EMS_SOC_MAINT_POWER                = (EE_EMS_SOC_MAINT_ENABLE + HALF_WORD_LEN),
	EE_EMS_FORCE_CONTROL_ENABLE           = (EE_EMS_SOC_MAINT_POWER + HALF_WORD_LEN),
	EE_EMS_POWER_FACTOR                   = (EE_EMS_FORCE_CONTROL_ENABLE + HALF_WORD_LEN),
	EE_EMS_POWER_Q_STEP                   = (EE_EMS_POWER_FACTOR + HALF_WORD_LEN),
	EE_EMS_RATED_CAPACITY                 = (EE_EMS_POWER_Q_STEP + HALF_WORD_LEN),
	EE_EMS_EARLY_CLOSURE_PEAK             = (EE_EMS_RATED_CAPACITY + HALF_WORD_LEN), // 不使用
	EE_EMS_EARLY_CLOSURE_TOP              = (EE_EMS_EARLY_CLOSURE_PEAK + HALF_WORD_LEN), // 不使用
	EE_EMS_EARLY_CLOSURE_VALLEY           = (EE_EMS_EARLY_CLOSURE_TOP + HALF_WORD_LEN), // 不使用
	EE_EMS_STANDBY_WAIT_TIME              = (EE_EMS_EARLY_CLOSURE_VALLEY + HALF_WORD_LEN),
	EE_EMS_STOP_WAIT_TIME                 = (EE_EMS_STANDBY_WAIT_TIME + HALF_WORD_LEN),
	EE_EMS_ADVANCE_STARTUP_TIME           = (EE_EMS_STOP_WAIT_TIME + HALF_WORD_LEN),
	EE_EMS_AUTOMATIC_ENABLE               = (EE_EMS_ADVANCE_STARTUP_TIME + HALF_WORD_LEN),
	EE_EMS_METER_CUR_DIR                  = (EE_EMS_AUTOMATIC_ENABLE + HALF_WORD_LEN),
	EE_EMS_TIME_PERIOD_POWER              = (EE_EMS_METER_CUR_DIR + HALF_WORD_LEN),
	EE_EMS_HOLIDAY_ENABLE                 = (EE_EMS_TIME_PERIOD_POWER + (HALF_WORD_LEN * EMS_TIME_PERIOD_NUM)),
	EE_EMS_HOLIDAY_TIME_PERIOD            = (EE_EMS_HOLIDAY_ENABLE + HALF_WORD_LEN),
	EE_EMS_HOLIDAY_TIME_PERIOD_POWER      = (EE_EMS_HOLIDAY_TIME_PERIOD + HALF_WORD_LEN),
	EE_EMS_HOLIDAY_TIME_PERIOD_MIN        = (EE_EMS_HOLIDAY_TIME_PERIOD_POWER + HALF_WORD_LEN),
	EE_EMS_HOLIDAY_TIME_PERIOD_HOUR,
	EE_EMS_HOLIDAY_DATE                   = (EE_EMS_HOLIDAY_TIME_PERIOD + (EMS_HOLIDAY_TIME_PERIOD_LEN * EMS_TIME_PERIOD_NUM)),
	EE_EMS_PCC_POWER_SET                  = (EE_EMS_HOLIDAY_DATE + (HALF_WORD_LEN * EMS_HOLIDAY_DATE_NUM)),
	EE_EMS_AUTOMATIC_TIME_PERIOD_ENABLE   = (EE_EMS_PCC_POWER_SET + HALF_WORD_LEN),
	EE_EMS_PERIOD_ALLOW_SALE              = (EE_EMS_AUTOMATIC_TIME_PERIOD_ENABLE + HALF_WORD_LEN),
	EE_EMS_PERIOD_ALLOW_PURCHASE          = (EE_EMS_PERIOD_ALLOW_SALE + (HALF_WORD_LEN * TIME_PERIOD_NUM_MAX)),
	EE_EMS_HOLIDAY_PERIOD_ALLOW_SALE      = (EE_EMS_PERIOD_ALLOW_PURCHASE + (HALF_WORD_LEN * TIME_PERIOD_NUM_MAX)),
	EE_EMS_HOLIDAY_PERIOD_ALLOW_PURCHASE  = (EE_EMS_HOLIDAY_PERIOD_ALLOW_SALE + (HALF_WORD_LEN * HOLIDAY_TIME_PERIOD_NUM_MAX)),
	EE_EMS_SECTOR_END                     = (EE_EMS_HOLIDAY_PERIOD_ALLOW_PURCHASE + (HALF_WORD_LEN * HOLIDAY_TIME_PERIOD_NUM_MAX)),
};

enum
{
	XIAOJU_SECTOR_START                   = 0,
	XIAOJU_TRANSFORMER_CAPACITY = XIAOJU_SECTOR_START,
	XIAOJU_METER3_NUM = (XIAOJU_TRANSFORMER_CAPACITY + WORD_LEN),
	XIAOJU_METER1_NUM = (XIAOJU_METER3_NUM + WORD_LEN),
	XIAOJU_CTRL_SOURCE = (XIAOJU_METER1_NUM + WORD_LEN),
	XIAOJU_SECTOR_END     = (XIAOJU_CTRL_SOURCE + WORD_LEN),
};


/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/
typedef struct
{
	uint16_t index;  // array index
	uint8_t min;    // minimun value
	uint8_t max;    // maximun value
	uint8_t value;  // default value
}set_value_uint8_t;

typedef struct
{
	uint16_t index;  // array index
	uint16_t min;    // minimun value
	uint16_t max;    // maximun value
	uint16_t value;  // default value
}set_value_uint16_t;

typedef struct
{
	uint16_t index;  // array index
	uint32_t min;    // minimun value
	uint32_t max;    // maximun value
	uint32_t value;  // default value
}set_value_uint32_t;

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/
extern const set_value_uint16_t *g_ems_set_table;
extern const set_value_uint16_t ems_set_table_400V[EMS_PARM_MAX_NUM];
extern const set_value_uint16_t ems_set_table_690V[EMS_PARM_MAX_NUM];
extern const set_value_uint8_t enet_set_table[ENET_PARM_MAX_NUM];
extern const set_value_uint32_t uart_set_table[UART_PARM_MAX_NUM];
extern bool_t trigger_restore_factory;
extern const set_value_uint16_t mcu2_inter_conf[MCU2_INTER_CONF_MAX_NUM];
extern const set_value_uint32_t xiaoju_setting_parm[XIAOJU_PARM_MAX_NUM];

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/
extern uint8_t uart_index_to_id[UART_NUMS];
extern uint8_t uart_id_to_index[];
extern uint16_t pre_product_model;

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void setting_init(void);
void setting_inter_conf_init(void);
void reset_enet(void);
void setting_enet_init(void);
void setting_uart_init(void);
int32_t setting_set_without_log(uint16_t type, uint16_t offset, void *data, uint16_t len);
int32_t setting_set(uint16_t type, uint16_t offset, void *data, uint16_t len);
int32_t setting_get(uint16_t type, uint16_t offset, void *data, uint16_t len);
uint8_t setting_data_constrain_uint8(uint8_t *data, const set_value_uint8_t *threshold, uint16_t index, bool_t *cross_border_flag);
uint16_t setting_data_constrain_uint16(uint16_t *data, const set_value_uint16_t *threshold, uint16_t index, bool_t *cross_border_flag);
uint32_t setting_data_constrain_uint32(uint32_t *data, const set_value_uint32_t *threshold, uint16_t index, bool_t *cross_border_flag);
uint32_t setting_data_restore_uint32(const set_value_uint32_t *threshold, uint16_t index, uint16_t len);
uint16_t setting_data_restore_uint16(const set_value_uint16_t *threshold, uint16_t index, uint16_t len);
uint8_t setting_data_restore_uint8(const set_value_uint8_t *threshold, uint16_t index, uint16_t len);
void restore_enet_parm(void);
void restore_uart_parm(void);
void bkgd_task_restore_factory(void);
void slow_task_set_pcsm_nums(void);
void slow_task_set_scenario(void);
int32_t file_system_init(void);
#endif
/******************************************************************************
* End of module
******************************************************************************/
