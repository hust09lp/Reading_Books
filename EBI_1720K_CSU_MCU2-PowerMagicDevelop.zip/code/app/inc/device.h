/******************************************************************************
 *
 * FILE IDENTIFICATION
 * -------------------
 *
 * File Name   : device.h
 * Description : device functional module
 *
 * $RCSfile    : $
 * $Author     : $
 * $Date       : $
 * $Revision   : $
 *
 ******************************************************************************
 * Copyright (c) SOFAR SH 2021
 * All right reserved.
 *****************************************************************************/

#ifndef DEVICE_H
#define DEVICE_H

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "link_list.h"
#include "pcs.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define CSU_COUNT                                                   (uint8_t)1
#define PCS_COUNT                                           (uint8_t)PCSM_NUMS
#define DEVICE_COUNT                          (uint8_t)(PCSM_NUMS + CSU_COUNT)

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
typedef enum
{
	DEVICE_DEL = -1,
	DEVICE_KEEP,
	DEVICE_ADD,
}DEVICE_REFRESH_E;

typedef enum
{
	REFRESH_DEL = -1,
	REFRESH_ADD,
	REFRESH_ALL
}REFRESH_E;

typedef enum
{
	REQ_NO_DATA = -1,
	REQ_NOT_FINISH,
	REQ_FINISH
}REQ_STATUS_E;

typedef enum
{
	CSU_MCU1 = 0x01,
	CSU_MCU2,
}DEVICE_CSU_E;

typedef enum
{
	DEVICE_PCS = 0x01,
	DEVICE_CSU,
}DEVICE_TYPE_E;

typedef enum
{
	CSU_CAN1 = 0x00,
	CSU_CAN5 = 0x01,
}CAN_BUS_E;

typedef enum
{
	DISABLE_DELAY_TRIGGER = 0x00,
	ENABLE_DELAY_TRIGGER  = 0x01
}DEVICE_DELAY_TRIGGER_E;

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/
typedef struct
{
	uint8_t          id;         // device heart id
	bool_t           got;        // device got heart frame
	DEVICE_REFRESH_E refresh;    // device refresh action
	bool_t           online;     // device current status
	bool_t			 var_got;	 // have got device variable
	uint16_t         detect_cnt; // device heart frame detect cnt
	uint16_t         lost_cnt;   // Lost records online
	uint16_t         got_cnt;    // obtained records offline
}device_heart_t;

// node control block
typedef struct
{
	DEVICE_TYPE_E          type;                    // device type
	uint8_t                count;                   // device count
	device_heart_t         *heart;                  // device heart data
	link_list_t            *list;                   // link list
	void                   *data;                   // device data area
	uint16_t                size;                   // device data element size
	uint16_t                *total;                 // device total number
	uint16_t                *online;                // device online number
	uint16_t                *runing;                // device runing number
	DEVICE_DELAY_TRIGGER_E  delay_trigger_mark;     // device delay trigger mark
}device_t;

typedef struct
{
	DEVICE_TYPE_E  type;    // device type
	CAN_BUS_E      bus;     // can bus type
	uint8_t        index;   // data index in array
	const uint32_t *data;   // cmd data pointer
	uint8_t        cnt;     // cmd data count
}device_cmd_t;

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/

//extern device_heart_t heart_csu[CSU_COUNT];
//extern device_t device_csu;
//extern link_list_t list_csu;
extern list_node_t list_sum_device[DEVICE_COUNT];
extern device_heart_t heart_pcs[PCS_COUNT];
extern device_t device_pcs;
extern link_list_t list_pcs;
extern uint32_t heart_check_cnt[PCS_COUNT];
extern bool_t trigger_heart_check;
extern float32_t heart_check_period;
extern float32_t heart_check_threshold;
extern sdk_rtc_t last_check_time;

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void device_init(void);
void clear_device_heart(device_t *device);
bool_t check_device_refresh(device_t *device);
void device_cnt_refresh(device_t *device);
void device_heart_refresh(device_t *device);
bool_t device_list_refresh(device_t *device, REFRESH_E mode);
void delay_heart_check(void);
void slow_task_heart_check(void);
//REQ_STATUS_E send_cmd_to_device(list_node_t *node, device_cmd_t *cmd);
//void device_send_message();//???

#endif
/******************************************************************************
* End of module
******************************************************************************/
