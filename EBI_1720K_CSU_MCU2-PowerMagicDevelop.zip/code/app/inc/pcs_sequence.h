/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     pcs_sequence.h
  * @brief    pcs sequence functional module header file
  * @company  SOFARSOLAR
  * @author   WWX
  * @note     
  * @version  V02
  * @date     2023/05/31
  */
/*****************************************************************************/

#ifndef PCS_SEQUENCE_H
#define PCS_SEQUENCE_H

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
#include "common.h"
#include "device.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
// Sizes of states array and transitions array of pcs sequence state machine
#define PCS_SM_STATE_ARRAY_SIZES                                    (uint16_t)6
#define PCS_SM_TRANS_ARRAY_SIZES                                    (uint16_t)6

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
typedef enum
{
	PCS_COUNT_INIT   = 0,
	// list node refresh time period, T = (n * task_period), unit: ms
	PCS_COUNT_NORMAL = 5,
}PCS_TIMER_COUNT_E;

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/

//extern bool_t pcs_regrouping;
//extern list_node_t *node_pcs;
extern device_cmd_t const_cmd_pcs;
extern device_cmd_t var_cmd_pcs;
extern list_node_t *node_pcs;
extern list_node_t *node_pcs_for_var;
extern list_node_t *node_pcs_for_const;
extern bool_t trigger_pcs_sm;
extern bool_t pcs_model_init_ok;
extern bool_t pcs_model_refresh_ok;
extern bool_t power_magic_init_ok;
extern bool_t trigger_pm_init;

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void pcs_sm_init(void);
void fast_task_pcs_sm(void);

void st00_entry_pcs(void);
void st00_action_pcs(void);
void st00_exit_pcs(void);

void st01_entry_pcs(void);
void st01_action_pcs(void);
void st01_exit_pcs(void);

void st02_entry_pcs(void);
void st02_action_pcs(void);
void st02_exit_pcs(void);

void st03_entry_pcs(void);
void st03_action_pcs(void);
void st03_exit_pcs(void);

void st04_entry_pcs(void);
void st04_action_pcs(void);
void st04_exit_pcs(void);

void st05_entry_pcs(void);
void st05_action_pcs(void);
void st05_exit_pcs(void);

bool_t check_tr00_pcs(void);
bool_t check_tr01_pcs(void);
bool_t check_tr02_pcs(void);
bool_t check_tr03_pcs(void);
bool_t check_tr04_pcs(void);
bool_t check_tr05_pcs(void);


#endif
/******************************************************************************
* End of module
******************************************************************************/
