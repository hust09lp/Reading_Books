/******************************************************************************
 *
 * FILE IDENTIFICATION
 * -------------------
 *
 * File Name   : task_scheduler.h
 * Description : Task scheduler header file
 *
 * $RCSfile    : $
 * $Author     : HH $
 * $Date       : 2023-02-21 $
 * $Revision   : V06 $
 *
 ******************************************************************************
 * Copyright (c) SOFAR SH 2021
 * All right reserved.
 *****************************************************************************/

#ifndef TASK_SCHEDULER_H
#define TASK_SCHEDULER_H

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "common.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
typedef enum
{
	TY_PERIOD = 0,    // periodically
	TY_EV_TRG,        // event triggered, clear event flag by manual
	TY_EV_ONE         // event triggered one time, clear event flag automatically
}TASK_TYPE_E;

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/
// Pointer to function (void, void)
typedef void vFunction(void);

// task control block
typedef struct
{
	uint32_t     mask;      // task execution mask(0: disable, 1: enable)
	uint32_t     type;      // task type(period, event trigger, one-shot trigger)
	vFunction    *run;      // pointer to user task function
	bool_t       *event;    // pointer to user event
	uint32_t     phase;     // task execution phase(from 1 to period)
	uint32_t     period;    // task execution period(depend on timer ISR)
	uint32_t     mask_save; // task execution mask buffer
}task_t;

// task group control block
typedef struct
{
	uint32_t  size;         // tasks numbers within a group
	task_t    *task;        // pointer to the first task of a group
}task_group_t;

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void task_scheduler_init(void);
void task_scheduler(task_group_t *task_group);


#endif
/******************************************************************************
* End of module
******************************************************************************/
