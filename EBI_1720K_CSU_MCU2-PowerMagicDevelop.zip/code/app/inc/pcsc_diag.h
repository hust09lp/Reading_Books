/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
	* @file     pcsc_diag.c
	* @brief    pcs cabinet diagnostic module header file
	* @company  SOFARSOLAR
	* @author   WWX
	* @note
	* @version  V01
	* @date     2023/05/04
	*/
/*****************************************************************************/

#ifndef __PCSC_DIAG_H__
#define __PCSC_DIAG_H__

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "common.h"
#include "pcs.h"
#include "diag_manage.h"
#include "rs485_device_manage.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define NTC_TEMP_MIN_LIMIT                                                 -395
#define NTC_TEMP_MAX_LIMIT                                                 1245

#define AC_BREAKER_FAULT_VALUE                                              300
#define AC_BREAKER_RESTORE_VALUE                                            200
#define DC_FUSE_FAULT_VALUE                                                 300
#define DC_FUSE_RESTORE_VALUE                                               200

#define DIAG_NUM_MAX                                                        128
/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/
extern bool_t fault_csu_board_otw;
extern bool_t fault_ac_tank_otw;
extern bool_t fault_csu_board_otp;
extern bool_t fault_ac_tank_otp;
extern bool_t fault_csu_board_utw;
extern bool_t fault_ac_tank_utw;
extern bool_t fault_csu_board_ntc;
extern bool_t fault_ac_tank_ntc;

extern bool_t fault_water_leak;
extern bool_t fault_door_unlock;
extern bool_t fault_ac_spd_fail;
extern bool_t fault_grid_tied_pos;
extern bool_t fault_pcsc_fan1;
extern bool_t fault_pcsc_fan2;
extern bool_t fault_iso_dev_fault;
extern bool_t fault_iso_fault;
extern bool_t fault_remote_epo;
extern bool_t fault_cmu_fault;

extern bool_t fault_pcsm_ac_breaker[PCSM_NUMS];

extern bool_t fault_pcsm_can1[PCSM_NUMS];

extern bool_t fault_metering_meter;
extern bool_t fault_backflow_meter;
extern bool_t fault_microcomputer;
extern bool_t fault_dehumidifier;
extern bool_t fault_measure_control;
extern bool_t fault_model_read;
extern bool_t fault_anti_backflow;

extern bool_t fault_sts_sw_pos;
extern bool_t fault_bypass_fault;
extern bool_t fault_spd1_fail;
extern bool_t fault_spd2_fail;
extern bool_t fault_qf1_fail;
extern bool_t fault_meter2;
extern bool_t fault_meter3[METERING_METER3_MAX_NUM];
extern bool_t fault_pv_meter[PV_METER_MAX_NUM];

extern bool_t fault_grid_rs_ovw;
extern bool_t fault_grid_st_ovw;
extern bool_t fault_grid_tr_ovw;
extern bool_t fault_grid_rs_uvw;
extern bool_t fault_grid_st_uvw;
extern bool_t fault_grid_tr_uvw;
extern bool_t fault_grid_r_ocw;
extern bool_t fault_grid_s_ocw;
extern bool_t fault_grid_t_ocw;
extern bool_t fault_grid_ofw;
extern bool_t fault_grid_ufw;
extern bool_t fault_pcs_rs_ovw;
extern bool_t fault_pcs_st_ovw;
extern bool_t fault_pcs_tr_ovw;
extern bool_t fault_pcs_rs_uvw;
extern bool_t fault_pcs_st_uvw;

extern bool_t fault_pcs_tr_uvw;
extern bool_t fault_dc1_ovw;
extern bool_t fault_dc2_ovw;
extern bool_t fault_dc1_uvw;
extern bool_t fault_dc2_uvw;

extern bool_t trigger_diag[DIAG_NUM_MAX];
extern bool_t trigger_comm_diag[PCSM_NUMS];
extern bool_t trigger_fuse_diag[PCSM_NUMS];
extern bool_t trigger_model_read;
extern bool_t trigger_model_read_fault_diag;
extern bool_t trigger_anti_backflow_diag;
extern bool_t clear_loss_info;

extern int16_t set_otw;
extern int16_t set_otp;
extern int16_t set_utw;
extern int16_t heart_ref;

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void pcsc_diag_init(void);
void pcsc_other_diag_init(void);

bool_t ntc_fail_check(int16_t ntc_temp);
bool_t ntc_fail_reset(int16_t ntc_temp);
bool_t csu_board_ntc_check(void);
bool_t csu_board_ntc_reset(void);
bool_t ac_tank_ntc_check(void);
bool_t ac_tank_ntc_reset(void);

bool_t water_leak_check(void);
bool_t water_leak_reset(void);
bool_t door_unlock_check(void);
bool_t door_unlock_reset(void);
bool_t ac_spd_check(void);
bool_t ac_spd_reset(void);
bool_t grid_tied_pos_check(void);
bool_t grid_tied_pos_reset(void);
bool_t pcsc_fan1_check(void);
bool_t pcsc_fan1_reset(void);
bool_t pcsc_fan2_check(void);
bool_t pcsc_fan2_reset(void);
bool_t iso_dev_fail_check(void);
bool_t iso_dev_fail_reset(void);
bool_t iso_fault_check(void);
bool_t iso_fault_reset(void);
bool_t remote_epo_check(void);
bool_t remote_epo_reset(void);
bool_t cmu_fault_check(void);
bool_t cmu_fault_reset(void);

// AC fuse check/reset
bool_t pcsm1_ac_breaker_reset(void);
bool_t pcsm1_ac_breaker_check(void);
bool_t pcsm2_ac_breaker_reset(void);
bool_t pcsm2_ac_breaker_check(void);
bool_t pcsm3_ac_breaker_check(void);
bool_t pcsm3_ac_breaker_reset(void);
bool_t pcsm4_ac_breaker_check(void);
bool_t pcsm4_ac_breaker_reset(void);
bool_t pcsm5_ac_breaker_check(void);
bool_t pcsm5_ac_breaker_reset(void);
bool_t pcsm6_ac_breaker_check(void);
bool_t pcsm6_ac_breaker_reset(void);

bool_t pcsm1_can1_check(void);
bool_t pcsm1_can1_reset(void);
bool_t pcsm2_can1_check(void);
bool_t pcsm2_can1_reset(void);
bool_t pcsm3_can1_check(void);
bool_t pcsm3_can1_reset(void);
bool_t pcsm4_can1_check(void);
bool_t pcsm4_can1_reset(void);
bool_t pcsm5_can1_check(void);
bool_t pcsm5_can1_reset(void);
bool_t pcsm6_can1_check(void);
bool_t pcsm6_can1_reset(void);

bool_t model_read_check(void);
bool_t model_read_reset(void);
bool_t sts_sw_pos_check(void);
bool_t sts_sw_pos_reset(void);
bool_t bypass_fault_check(void);
bool_t bypass_fault_reset(void);
bool_t spd1_status_check(void);
bool_t spd1_status_reset(void);
bool_t spd2_status_check(void);
bool_t spd2_status_reset(void);
bool_t qf1_status_check(void);
bool_t qf1_status_reset(void);

void pcsc_fault_update(void);
void pcsc_trigger_update(void);

void slow_task_model_read(void);

#endif
/******************************************************************************
* End of module
******************************************************************************/
