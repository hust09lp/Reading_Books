/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     ems.h
  * @brief    local ems module header file
  * @company  SOFARSOLAR
  * @author   ZZJ
  * @note
  * @version  V02
  * @date     2023/07/20
  */
/*****************************************************************************/

#ifndef __EMS_H__
#define __EMS_H__

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "common.h"
#include "rtc.h"
#include "dlt645.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
// TODO:
#define SOLAR                                                               (0)
#define TIME_PERIOD_NUM_MAX                                                (10)
#define HOLIDAY_TIME_PERIOD_NUM_MAX                                        (10)
#define FORCE_CONTROL_THRESHOLD                                            (95)
#define EMS_TIME_PERIOD_NUM                                                (10)
#define EMS_TIME_PERIOD_LEN                                                 (6)
#define EMS_HOLIDAY_TIME_PERIOD_LEN                                         (8)
#define EMS_HOLIDAY_DATE_NUM                                               (40)

#define EMS_PARM_MAX_NUM                                                   (42)
#define PV_METER_MAX_NUM                                                    (3)
#define METERING_METER3_MAX_NUM                                             (5)
#define CHG_DCH_CONVERSION_EFFEICECNCY                                 (120.0f)
#define BASE_POWER_ADJUST_STEP                                            (500)
#define AUTOMATIC_ADJUST_DIFF_1                                         (0.94f)
#define AUTOMATIC_ADJUST_DIFF_2                                         (0.96f)
#define ANTI_BACK_FLOW_OFFSET                                           (10)// 1KW

#define SOC_MAINT_MIN_SOC                                                   (3)

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
enum
{
	INVALID = 0,  // 无效的
	FLAT_TM,      // 平
	VALLEY_TM,    // 谷
	PEAK_TM,      // 峰
	TOP_TM,       // 尖峰
	AUTOMATIC_TM,    // 自动模式
	TM_MAX_NUM = AUTOMATIC_TM,
};
enum
{
	FAST_EMS_PERIOD = 100, // 100 *10ms = 1s
	SLOW_EMS_PERIOD = 1000, // 1000 *10ms = 10s
};
enum
{
	MONDAY = 1, 
	TUESDAY, 
	WEDNESDAY, 
	THURSDAY, 
	FRIDAY, 
	SATURDAY,
	SUNDAY,
};
enum
{
	EMS_SATURDAY_ENABLE = 0, 
	EMS_SUNDAY_ENABLE, 
	EMS_FESTIVAL_ENABLE, 
	EMS_HOLIDAY_ENABLE_NUM,
};
/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/
typedef struct
{
	uint8_t attribute;
	uint8_t start_min;
	uint8_t start_hour;
	uint8_t end_min;
	uint8_t end_hour;
	uint8_t enable_power_set;
	int16_t power_ref;
	uint16_t allow_sale_power;
	uint16_t allow_purchase_power;
}tm_period_t;

typedef struct
{
	uint8_t enable;
	uint8_t mark;
	uint8_t upper_limit;
	uint8_t lower_limit;
	uint8_t clear_power;
	int16_t power_var;
	int16_t power_step;
	uint16_t power_maint;  // 维护功率
	int16_t target_maint_power; // 最终输出的维护功率
	bool_t  beyond_the_limit;
	bool_t  below_the_limit;
	bool_t  finish_maint;
}soc_maint_t;

typedef struct
{
	uint8_t   enable;
	uint8_t   mark;
	int16_t   power_var;
	float32_t power_factor_threshold;
}force_control_t;

typedef struct
{
	uint8_t enable;
	uint8_t mark;
	uint8_t step;
	uint16_t demand_quantity;
	uint16_t dead_band;
	int16_t power_var;
}demand_side_t;

typedef struct
{
	uint8_t enable;
	uint8_t mark;
	int16_t step;
	// uint16_t dead_band;  // 单位0.1KW
	int16_t power_var;  // 单位0.1KW
}anti_backflow_t;

typedef struct
{
	uint8_t enable;
	uint8_t mark;
	uint8_t time_period_enable;
	int16_t step;
	uint16_t dead_band;  // 单位0.1KW
	int16_t power_var;  // 单位0.1KW
}automatic_t;

typedef struct
{
	uint8_t enable;
	uint8_t mark;
	uint8_t step;
	// uint16_t dead_band;
	// uint16_t demand_quantity;
	int16_t power_var;
}c2d_t;

// Cut peaks and fill valleys
typedef struct
{
	uint8_t enable;
	uint8_t mark;

	uint8_t state_chg;     // 已经开始充电
	uint8_t state_dischg;  // 已经开始放电

	int16_t last_status;

	uint8_t soc_chg_start;    // 开始充电的soc
	uint8_t soc_dischg_start; // 开始放电的soc
	uint8_t soc_actual_last;  // --是否可设
	float32_t soc_change_dead;  // --是否可设
	float32_t soc_chg_rate;  // --是否可设
	float32_t soc_dischg_rate;  // --是否可设

	uint16_t early_closure_peak;   // 距离当前时段结束的时间死区 单位分钟
	uint16_t early_closure_top;
	uint16_t early_closure_valley;
	int16_t power_dead_band;
	uint8_t detect_count_set;
	uint8_t remain_top_soc;

	float32_t k1;        // 充电功率系数 --是否可设
	float32_t k2;        // 放电功率系数 --是否可设

	uint16_t p_chgmax_sug;
	uint16_t p_chgmax_real;

	uint16_t p_dischgmax_sug;
	uint16_t p_dischgmax_real;

	int16_t power_var;
	bool_t  skip_soc_check;

}cpfv_t;

typedef struct
{
	float32_t power;       // 总功率
	float32_t power_up;    // 上网功率
	float32_t power_down;  // 购电功率
	float32_t power_var_max;   // 功率变化量
	float32_t power_factor;   // 功率因数
	float32_t power_q;   // 无功功率
}ammeter_t;

typedef struct
{
	// 0: positive discharge and negative charge
	// 1: negative discharge and positive charge
	uint16_t meter1_cur_dir : 1;
	uint16_t meter2_cur_dir : 1;
	uint16_t meter3_cur_dir : 1;
	uint16_t meter4_cur_dir : 1;
	uint16_t recv           : 12;
}meter_cur_dir_bit_t;

typedef union
{
	meter_cur_dir_bit_t bits;
	uint16_t all;
}meter_cur_dir_t;

typedef struct
{
	int16_t  last_target_power;
	int16_t  last_target_power_q;
	uint16_t rated_capacity;// 电池容量 KWH
	// int16_t dch_exit_power; // 系统最大放电功率
	// int16_t chg_exit_power; // 系统最小充电功率
	uint16_t q_power_step;
	uint16_t p_chg_step;     // 充电功率调节步长
	uint16_t p_dischg_step;  // 放电功率调节步长
	uint8_t  power_factor;
	uint8_t soc_actual_chg; // 系统平均充电SOC
	uint8_t soh_actual_chg;
	uint8_t soc_actual_dch; // 系统平均放电SOC
	uint8_t soh_actual_dch;
	uint8_t soc_max_cmu; // 多个cmu中，soc最高的那个cmu的值
	uint8_t soh_max_cmu;
	uint8_t soc_min_cmu; // 多个cmu中，soc最低的那个cmu的值
	uint8_t soh_min_cmu;
	uint8_t soc_max;  // 设置的最大SOC
	uint8_t soc_min;  // 设置的最小SOC
	uint16_t p_chgmax_theory;  // 理论最大充电功率
	uint16_t p_dischgmax_theory;  // 理论最大放电功率
	int16_t inter_max_dch_power;  // 最大充电功率(内部使用)
	int16_t inter_max_chg_power;  // 最大放电功率(内部使用)
	int16_t inter_min_dch_power;  // 最小充电功率(内部使用)
	int16_t inter_min_chg_power;  // 最大放电功率(内部使用)

	ammeter_t       ammeter;
	demand_side_t   demand_side;
	anti_backflow_t anti_backflow;
	automatic_t	    automatic;
	soc_maint_t     soc_maint;
	force_control_t force_control;
	c2d_t           c2d;
	cpfv_t          cpfv;  // Cut peaks and fill valleys

	bool_t finish_chg;
	bool_t finish_dischg;

	tm_period_t tm_period[TIME_PERIOD_NUM_MAX];
	tm_period_t now_period;
	uint16_t pcs_standby_wait_time; // 空载转待机时长 Unit:0.1hour
	uint16_t pcs_stop_wait_time; // 空载转停机时长 Unit:0.1hour
	uint16_t pcs_advance_startup_time; // 节能降耗开机提前启动时间 Unit:1min
	meter_cur_dir_t meter_current_direction; // 电表方向
	uint16_t backflow_meter_switch; // 防逆流电表型号选择
	uint16_t backflow_voltage_ratio; // 防逆流电表电压比
	uint16_t backflow_current_ratio; // 防逆流电表电流比
	uint16_t allow_purchase_power; // 允许购电功率
	uint16_t allow_sale_power; // 允许卖电功率
	int16_t pcc_power_set; // 并网点功率控制
	uint16_t holiday_tm_enable; // 节假日时段使能
	uint16_t holiday_date[EMS_HOLIDAY_DATE_NUM]; // 节假日日期
	tm_period_t holiday_tm_period[HOLIDAY_TIME_PERIOD_NUM_MAX]; // 节假日时段
}ems_t;

typedef struct
{
	float32_t virtul_ammeter_4;
	float32_t ammeter_2;
	float32_t ammeter_3;
}xiaoju_ammeter_t;

typedef struct
{
	uint32_t system_ctrl;
	uint32_t max_allow_chg_power;
	uint32_t max_allow_dch_power;
	uint32_t transformer_capacity;
	uint32_t ammeter3_num;
	uint32_t ammeter1_num;
	uint32_t ctrl_source;
	uint32_t ammeter2_model_switch;
	uint32_t ammeter2_voltage_ratio;
	uint32_t ammeter2_current_ratio;
	uint32_t ammeter3_model_switch;
	uint32_t ammeter3_voltage_ratio[METERING_METER3_MAX_NUM];
	uint32_t ammeter3_current_ratio[METERING_METER3_MAX_NUM];
}xiaoju_t;

typedef enum
{
	XIAOJU_LOCAL = 0,
	XIAOJU_REMOTE,
}xiaoju_ctrl_u;

typedef enum
{
	XIAOJU_NO_ACTION = 0,
	XIAOJU_CHARGE,
	XIAOJU_DISCHARGE,
}xiaoju_u;

typedef enum
{
	POSITIVE_DIR = 0,  // positive discharge and negative charge
	NEGATIVE_DIR,      // negative discharge and positive charge
}current_direction_u;

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/
extern ems_t ems;
extern int16_t fault_anti_backflow_cnt;
extern int16_t fault_anti_backflow_ref;
extern bool_t trigger_local_ems;
extern bool_t trigger_xiao_ju;
extern xiaoju_t xiao_ju;
extern xiaoju_ammeter_t xiaoju_ammeter;
extern int8_t meter_cur_dir[2];
extern bool_t g_trigger_close_ems;
/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void ems_init(uint8_t product_model);
void xiaoju_init(void);

void transfer_time_format(tm_period_t* tm_period_tmp, sdk_rtc_t* rtc_tmp);
void fast_task_local_ems(void);
void fast_task_xiao_ju(void);
void slow_task_ems_close(void);
uint8_t get_time_period_attr(tm_period_t* now_period);
tm_period_t get_tm_period(void);
uint8_t get_attr_from_power(int16_t power);
bool_t check_today_date(void);
#endif
/******************************************************************************
* End of module
******************************************************************************/
