/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     rs485_meter.h
  * @brief    Meter module
  * @company  SOFARSOLAR
  * @author   ZZJ
  * @note
  * @version  V01
  * @date     2023/06/20
  */
/*****************************************************************************/

#ifndef __RS485_METER_H__
#define __RS485_METER_H__

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "common.h"
#include "pcs.h"
#include "ems.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define RS485_METERING_METER                                                (0)
#define RS485_METERING_METER_SLAVE_ADDR                                     (1)

#define RS485_BACKFLOW_METER                                                (3)
#define DLT645_BACKFLOW_METER_PORT_INDEX             (RS485_BACKFLOW_METER + 1)
#define RS485_BACKFLOW_METER_SLAVE_ADDR                                     (1)

#define RS485_METER_2                                                       (1)
#define DLT645_METERING_METER2_PORT_INDEX                   (RS485_METER_2 + 1)
#define RS485_METER_2_SLAVE_ADDR                                            (1)

#define RS485_PV_METER                                                      (1)
#define DLT645_PV_METER_PORT_INDEX                         (RS485_PV_METER + 1)
#define RS485_PV_METER_SLAVE_ADDR                                           (1)
#define PV_METER_FAULT_THRESHOLD                                           (50)

#define RS485_METER_3                                                       (2)
#define RS485_METER_3_SLAVE_ADDR                                            (1)
#define DLT645_METERING_METER3_PORT_INDEX                   (RS485_METER_3 + 1)
#define METERING_METER3_FAULT_THRESHOLD                                    (50)

#define RS485_METER_BUFF_LEN                                               (20)
#define BACKFLOW_METER_POINTS_NUM                                           (1)

#define DTSU666_UNIQUE_POINT                                           (0x2012)
#define ADL400_UNIQUE_POINT                                            (0x081A)
/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
enum
{
	ADL400 = 0,
	DTSU666,
	UMG604,
	METER_MODEL_END = UMG604,
	METER_MODEL_NUM,
};
enum
{
	METER_1 = 0,
	METER_2,
	METER_3,
	METER_4,
	METER_PORT_NUM,
};
enum
{
	ADL400_DATA_SEGMENT_0 = 0,
	ADL400_DATA_SEGMENT_1,
	ADL400_DATA_SEGMENT_2,
	ADL400_DATA_SEGMENT_3,
	ADL400_DATA_SEGMENT_4,
	ADL400_DATA_SEGMENT_5,
	ADL400_DATA_SEGMENT_6,
	ADL400_DATA_SEGMENT_7,
	ADL400_DATA_SEGMENT_NUM,
};
enum
{
	DTSU666_DATA_SEGMENT_0 = 0,
	DTSU666_DATA_SEGMENT_1,
	DTSU666_DATA_SEGMENT_2,
	DTSU666_DATA_SEGMENT_3,
	DTSU666_DATA_SEGMENT_4,
	DTSU666_DATA_SEGMENT_5,
	DTSU666_DATA_SEGMENT_6,
	DTSU666_DATA_SEGMENT_NUM,
};
enum
{
	UMG604_DATA_SEGMENT_0 = 0,
	UMG604_DATA_SEGMENT_1,
	UMG604_DATA_SEGMENT_2,
	UMG604_DATA_SEGMENT_3,
	UMG604_DATA_SEGMENT_4,
	UMG604_DATA_SEGMENT_5,
	UMG604_DATA_SEGMENT_6,
	UMG604_DATA_SEGMENT_7,
	UMG604_DATA_SEGMENT_NUM,
};

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/
typedef struct
{
	float32_t active_power_r;                         // 1kW
	float32_t active_power_s;                         // 1kW
	float32_t active_power_t;                         // 1kW
	float32_t active_power;                           // 1kW
	float32_t reactive_power_r;                       // 1kVAr
	float32_t reactive_power_s;                       // 1kVAr
	float32_t reactive_power_t;                       // 1kVAr
	float32_t reactive_power;                         // 1kVAr
	float32_t apparent_power_r;                       // 1kVA
	float32_t apparent_power_s;                       // 1kVA
	float32_t apparent_power_t;                       // 1kVA
	float32_t apparent_power;                         // 1kVA
	float32_t power_factor_r;                         // 1
	float32_t power_factor_s;                         // 1
	float32_t power_factor_t;                         // 1
	float32_t power_factor;                           // 1
	float32_t frequency;                              // 1Hz
	uint32_t  forward_total_active_energy;            // 0.1kWh
	uint32_t  forward_top_active_energy;              // 0.1kWh
	uint32_t  forward_peak_active_energy;             // 0.1kWh
	uint32_t  forward_flat_active_energy;             // 0.1kWh
	uint32_t  forward_valley_active_energy;           // 0.1kWh
	uint32_t  backward_total_active_energy;           // 0.1kWh
	uint32_t  backward_top_active_energy;             // 0.1kWh
	uint32_t  backward_peak_active_energy;            // 0.1kWh
	uint32_t  backward_flat_active_energy;            // 0.1kWh
	uint32_t  backward_valley_active_energy;          // 0.1kWh
	uint32_t  forward_total_reactive_energy;          // 0.1kWh
	uint32_t  forward_top_reactive_energy;            // 0.1kWh
	uint32_t  forward_peak_reactive_energy;           // 0.1kWh
	uint32_t  forward_flat_reactive_energy;           // 0.1kWh
	uint32_t  forward_valley_reactive_energy;         // 0.1kWh
	uint32_t  backward_total_reactive_energy;         // 0.1kWh
	uint32_t  backward_top_reactive_energy;           // 0.1kWh
	uint32_t  backward_peak_reactive_energy;          // 0.1kWh
	uint32_t  backward_flat_reactive_energy;          // 0.1kWh
	uint32_t  backward_valley_reactive_energy;        // 0.1kWh
	float32_t volt_r;                                 // 1V
	float32_t volt_s;                                 // 1V
	float32_t volt_t;                                 // 1V
	float32_t current_r;                              // 1A
	float32_t current_s;                              // 1A
	float32_t current_t;                              // 1A
}metering_meter_t;

typedef struct
{
	uint8_t meter_num     : 6;
	uint8_t meter_id      : 2;
}meter_index_bits_t;

typedef union
{
	uint8_t all;
	meter_index_bits_t bit;
}meter_index_t;

typedef struct
{
	uint16_t pv_meter_model;
	uint16_t pv_meter_num;
	uint16_t pv_meter_vol_ratio[PV_METER_MAX_NUM];
	uint16_t pv_meter_cur_ratio[PV_METER_MAX_NUM];
}pv_meter_t;

typedef struct
{
	uint16_t addr;
	uint16_t len;
}meter_point_table_t;
enum
{
	METERING_METER_1 = 0,
	METERING_METER_2,
	METERING_METER_3,
	PCC_METER,
};

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/
extern int16_t fault_backflow_meter_cnt;
extern int16_t fault_backflow_meter_ref;
extern int16_t fault_metering_meter_cnt;
extern int16_t fault_metering_meter_ref;
extern int16_t fault_meter2_cnt;
extern int16_t fault_meter2_ref;
extern int16_t fault_meter3_cnt[METERING_METER3_MAX_NUM];
extern int16_t fault_meter3_ref;
extern int16_t fault_pv_meter_cnt[PV_METER_MAX_NUM];
extern int16_t fault_pv_meter_ref;
extern bool_t trigger_metering_meter;
extern bool_t trigger_backflow_meter;
extern bool_t trigger_meter2;
extern bool_t trigger_meter3[METERING_METER3_MAX_NUM];
extern bool_t g_trigger_pv_meter[PV_METER_MAX_NUM];
extern bool_t g_trigger_pv_meter_sw;
extern metering_meter_t metering_meter[CMU_NUMS];
extern uint16_t meter1_disconnect_flag;
extern uint8_t metering_meter1_num;
// extern uint16_t g_backflow_meter_switch;
// extern uint16_t g_metering_meter2_switch;
// extern uint16_t g_metering_meter3_switch;
// extern uint16_t g_pv_meter_switch;
extern uint32_t backflow_conn_count;
extern uint32_t backflow_disconn_count;
extern uint32_t meter1_disconn_count;
extern uint32_t meter1_conn_count;
extern uint32_t meter2_disconn_count;
extern uint32_t meter2_conn_count;
extern uint32_t meter3_disconn_count;
extern uint32_t meter3_conn_count;
extern uint32_t pv_meter_disconn_count;
extern uint32_t pv_meter_conn_count;
extern metering_meter_t pcc_meter_data;
extern metering_meter_t meter2_other_data[PV_METER_MAX_NUM];
extern metering_meter_t meter3_other_data[METERING_METER3_MAX_NUM];
extern pv_meter_t pv_meter_parm;
extern float32_t meter3_power_old[METERING_METER3_MAX_NUM];
extern uint8_t g_pv_meter_num_record;

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void rs485_backflow_meter_init(void);
void rs485_metering_meter_init(void);

void clear_metering_data(void);
void clear_backflow_data(void);
void rs485_task_backflow_meter(void);
void rs485_task_metering_meter(void);
void rs485_meter2_init(void);
void rs485_meter3_init(void);
void rs485_task_meter2(void);
void rs485_task_meter2_other(void);
void rs485_task_meter3(void);
void rs485_task_meter3_other(void);
void rs485_pv_meter_init(void);
void rs485_task_pv_power(void);
void rs485_task_pv_meter(void);
void rs485_task_pcc_meter_data(void);
void rs485_task_mm_power(void);

#endif
/******************************************************************************
* End of module
******************************************************************************/
