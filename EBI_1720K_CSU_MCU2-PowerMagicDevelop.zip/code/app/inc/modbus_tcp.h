/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
	* @file     modbus_tcp.h
	* @brief    modbus_tcp header files
	* @company  SOFARSOLAR
	* @author   WWX
	* @note
	* @version  V01
	* @date     2023/07/15
	*/
/*****************************************************************************/

#ifndef __MODBUS_TCP_H__
#define __MODBUS_TCP_H__

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "common.h"

/****************s**************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define MODBUS_TCP                                                          (4)
#define SLAVE_ADDRESS                                                       (1)
#define MODBUS_TCP_PORT                                                     502

//#define OUTPUT_ACTIVE_POW_PREF                                                5
//#define INTPUT_ACTIVE_POW_PREF                                                6
//#define REACTIVE_POW_PREF                                                     7

#define REG_ADDRESS_START												  24000
#define REG_ADDRESS_END			                                          27999

#define SYSTEM_RATED_POWER_ADDR												 34
#define ACTIVE_POWER_ADDR												   1850
#define REACTIVE_POWER_ADDR												   1851
#define REMOTE_PCS_ONOFF_ADDR											   2300
#define RUNNING_STATE_ADDR												   2676
#define MAX_CHARGEABLE_P0WER_ADDR										   2725
#define MAX_DISCHARGEABLE_P0WER_ADDR									   2726
#define INCREASED_REACTIVE_POWER_ADDR									   2727
#define REDUCED_REACTIVE_POWER_ADDR										   2728
#define SOC_RUNNING_VAL_ADDR											   2729
#define REAL_TIME_ACTIVEPOWER_ADDR										   2810
#define REAL_TIME_REACTIVE_POWER_ADDR									   2811



#define SINGLE_PCSM_MAX_POWER                                               215
#define MOD_FRAME_MAX_NUM                                                   256
#define MOD_PARA_NUM													     12
/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
enum
{
	SYSTEM_RATED_POWER = 0,
	ACTIVE_POWER,
	REACTIVE_POWER,
	REMOTE_PCS_ONOFF,
	RUNNING_STATE,
	MAX_CHARGEABLE_P0WER,
	MAX_DISCHARGEABLE_P0WER,
	INCREASED_REACTIVE_POWER,
	REDUCED_REACTIVE_POWER,
	SOC_RUNNING_VAL,
	REAL_TIME_ACTIVEPOWER,
	REAL_TIME_REACTIVE_POWER,
};


/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void modbus_tcp_init(void);
void modbus_regs_hold_init(void);
void thread_modbus_tcp_parse(void *argument);

int32_t modbus_tcp_parse(uint32_t index, uint32_t func, const uint8_t *p_req,
                                              uint8_t *p_rsp, int32_t rsp_size);
int32_t modbus_tcp_read_hold_reg(uint16_t reg_addr, uint16_t reg_num, uint8_t *p_rsp);
int32_t modbus_read_hold_reg(uint16_t reg_addr, uint16_t reg_num, uint8_t *p_rsp);
int32_t modbus_tcp_write_hold_reg(uint16_t reg_addr, uint16_t reg_value, const uint8_t *p_data);
int32_t modbus_write_hold_reg(uint16_t reg_addr, uint16_t reg_value, const uint8_t *p_data);

#endif
/******************************************************************************
* End of module
******************************************************************************/
