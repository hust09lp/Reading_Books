/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     tpll.h
  * @brief    PLL module header file
  * @company  SOFARSOLAR
  * @author   HH
  * @note
  * @version  V01
  * @date     2023/04/09
  */
/*****************************************************************************/

#ifndef __TPLL_H__
#define __TPLL_H__

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "sdk.h"
#include "sdk_core.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define GET_GRID_PLL_UD_POS()             (g_tpll.ud_pos)
#define GET_GRID_PLL_UQ_POS()             (g_tpll.uq_pos)
#define GET_GRID_PLL_THETA_STEP()         (g_tpll.theta_step)
#define GET_GRID_PLL_SIN_THETA()          (g_tpll.sin_theta)
#define GET_GRID_PLL_COS_THETA()          (g_tpll.cos_theta)
#define GET_GRID_PLL_SIN_THETA_CURR()     (g_tpll.sin_theta_curr)
#define GET_GRID_PLL_COS_THETA_CURR()     (g_tpll.cos_theta_curr)
#define GET_GRID_PLL_THETA()              (g_tpll.theta)

#define GET_GRID_PLL_UD()                 (g_tpll.ud)
#define GET_GRID_PLL_UQ()                 (g_tpll.uq)
#define GET_GRID_PLL_UALPHA()             (g_tpll.u_alpha)
#define GET_GRID_PLL_UBETA()              (g_tpll.u_beta)

#define GET_GRID_PLL_NEG_SEQ_CURR_TRIG()  (g_tpll.neg_seq_current_trig)

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/
typedef struct {
	float32_t  u_alpha;         // Input: Reference input
	float32_t  u_beta;          // Input: Feedback input
	float32_t  ud;     //
	float32_t  uq;         // Parameter: Proportional gain
//    float32_t  ud_filt;      //
//    float32_t  uq_filt;          // Parameter: Proportional gain
//    float32_t  u_coeff;
	float32_t  ud_pos;
	float32_t  uq_pos;
	float32_t  ud_neg;
	float32_t  uq_neg;
	float32_t  u_pos;
	float32_t  u_neg;
	float32_t  uq_err_old;           // Variable: Error //Variable: Proportional output
	float32_t  uq_err_new;           // Variable: Error //Variable: Integral output
	float32_t  pll_step;
	float32_t  theta_step;      // Parameter: Minimum output
	float32_t  uq_err_old_neg;
	float32_t  uq_err_new_neg;
	float32_t  pll_step_neg;
	float32_t  theta_step_neg;
	float32_t  vrt_theta;      // Parameter: Minimum output
	float32_t  theta;          // (k)
	float32_t  last_theta;     // (k-1)
	float32_t  grid_theta;
	float32_t  theta_neg;
//  float32_t  f32AITheta;        // Output: PID output
//  float32_t  f32AITempTheta;        // Output: PID output
	float32_t  sin_theta;      // Variable: Saturated difference
	float32_t  cos_theta;          // Parameter: Integral gain
	float32_t  sin_theta_neg;      // Variable: Saturated difference
	float32_t  cos_theta_neg;          // Parameter: Integral gain
//  float32_t  Sin_AITheta;       // Variable: Saturated difference
//  float32_t  Cos_AITheta;           // Parameter: Integral gain
	float32_t  offgrid_theta_step_err;

	float32_t  theta_curr;         // Output: PID output
	float32_t  sin_theta_curr;     // Variable: Saturated difference
	float32_t  cos_theta_curr;         // Parameter: Integral gain
	float32_t  ai_delta_theta;          // Parameter: Integral gain
//  float32_t f32AIDeltaTanphi;
	float32_t  ai_delta_iq ;
	float32_t  omega_pll;
	uint16_t   neg_seq_current_trig; // 替换g_u16NegSeqCurrentTriggle todo
} tpll_obj;

typedef struct {
	uint16_t   neg_seq_enable;
	float32_t  theta_step_max_lmt;
	float32_t  theta_step_min_lmt;
	float32_t  rated_theta_step;
	float32_t  upos_lmt;
	float32_t  uneg_lmt;
	float32_t  uq_pos_lmt;
	float32_t  upos_squre_min;
	float32_t  neg_trig_lmt;
	float32_t  curr_theta_comp;
	uint16_t   neg_trig_delay;
} tpll_cfg;

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/
extern tpll_obj g_tpll;
extern tpll_cfg g_tpll_cfg;
extern bool_t g_grid_trig;
extern bool_t trigger_anti_island;
extern float32_t freq_tpll;

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void tpll_init(void);

void crtl_task_tpll(void);


#endif
/******************************************************************************
* End of module
******************************************************************************/
