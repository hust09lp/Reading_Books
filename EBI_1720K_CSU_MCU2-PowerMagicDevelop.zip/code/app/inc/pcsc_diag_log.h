/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
	* @file     pcsc_diag_log.h
	* @brief    pcsc diagnostic log header file
	* @company  SOFARSOLAR
	* @author   WWX
	* @note
	* @version  V02
	* @date     2023/05/31
	*/
/*****************************************************************************/

#ifndef __PCSC_DIAG_LOG_H__
#define __PCSC_DIAG_LOG_H__

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "common.h"
#include "pcs.h"
#include "diag_manage.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void pcsc_diag_log_init(void);

void log_check_csu_board_otw(void);
void log_reset_csu_board_otw(void);
void log_check_ac_tank_otw(void);
void log_reset_ac_tank_otw(void);
void log_check_csu_board_otp(void);
void log_reset_csu_board_otp(void);
void log_check_ac_tank_otp(void);
void log_reset_ac_tank_otp(void);
void log_check_csu_board_utw(void);
void log_reset_csu_board_utw(void);
void log_check_ac_tank_utw(void);
void log_reset_ac_tank_utw(void);
void log_check_csu_board_ntc(void);
void log_reset_csu_board_ntc(void);
void log_check_ac_tank_ntc(void);
void log_reset_ac_tank_ntc(void);
void log_check_water_leak(void);
void log_reset_water_leak(void);
void log_check_door_unlock(void);
void log_reset_door_unlock(void);
void log_check_grid_tied_pos(void);
void log_reset_grid_tied_pos(void);
void log_check_ac_spd(void);
void log_reset_ac_spd(void);
void log_check_pcsc_fan1(void);
void log_reset_pcsc_fan1(void);
void log_check_pcsc_fan2(void);
void log_reset_pcsc_fan2(void);
void log_check_iso_dev_fail(void);
void log_reset_iso_dev_fail(void);
void log_check_iso_fault(void);
void log_reset_iso_fault(void);
void log_check_remote_epo(void);
void log_reset_remote_epo(void);
void log_check_cmu_fault(void);
void log_reset_cmu_fault(void);

// AC fuse check/reset
void log_check_pcsm1_ac_breaker(void);
void log_reset_pcsm1_ac_breaker(void);
void log_check_pcsm2_ac_breaker(void);
void log_reset_pcsm2_ac_breaker(void);
void log_check_pcsm3_ac_breaker(void);
void log_reset_pcsm3_ac_breaker(void);
void log_check_pcsm4_ac_breaker(void);
void log_reset_pcsm4_ac_breaker(void);
void log_check_pcsm5_ac_breaker(void);
void log_reset_pcsm5_ac_breaker(void);
void log_check_pcsm6_ac_breaker(void);
void log_reset_pcsm6_ac_breaker(void);

void log_check_pcsm1_can1(void);
void log_check_pcsm2_can1(void);
void log_check_pcsm3_can1(void);
void log_check_pcsm4_can1(void);
void log_check_pcsm5_can1(void);
void log_check_pcsm6_can1(void);

void log_reset_pcsm1_can1(void);
void log_reset_pcsm2_can1(void);
void log_reset_pcsm3_can1(void);
void log_reset_pcsm4_can1(void);
void log_reset_pcsm5_can1(void);
void log_reset_pcsm6_can1(void);

void log_check_metering_meter(void);
void log_reset_metering_meter(void);
void log_check_backflow_meter(void);
void log_reset_backflow_meter(void);
void log_check_microcomputer(void);
void log_reset_microcomputer(void);
void log_check_dehumidifier(void);
void log_reset_dehumidifier(void);
void log_check_measure_control(void);
void log_reset_measure_control(void);
void log_check_model_read(void);
void log_reset_model_read(void);
void log_check_anti_backflow(void);
void log_reset_anti_backflow(void);

void log_check_sts_sw_pos(void);
void log_reset_sts_sw_pos(void);
void log_check_bypass_fault(void);
void log_reset_bypass_fault(void);
void log_check_spd1_status(void);
void log_reset_spd1_status(void);
void log_check_spd2_status(void);
void log_reset_spd2_status(void);
void log_check_qf1_status(void);
void log_reset_qf1_status(void);
void log_check_meter2(void);
void log_reset_meter2(void);
void log_check_meter3_1(void);
void log_reset_meter3_1(void);
void log_check_meter3_2(void);
void log_reset_meter3_2(void);
void log_check_meter3_3(void);
void log_reset_meter3_3(void);
void log_check_meter3_4(void);
void log_reset_meter3_4(void);
void log_check_meter3_5(void);
void log_reset_meter3_5(void);
void log_check_pv_meter_1(void);
void log_reset_pv_meter_1(void);
void log_check_pv_meter_2(void);
void log_reset_pv_meter_2(void);
void log_check_pv_meter_3(void);
void log_reset_pv_meter_3(void);

#endif
/******************************************************************************
* End of module
******************************************************************************/
