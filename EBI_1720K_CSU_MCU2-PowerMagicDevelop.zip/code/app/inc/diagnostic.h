/******************************************************************************
 *
 * FILE IDENTIFICATION
 * -------------------
 *
 * File Name   : diagnostic.h
 * Description : Diagnostic functional module header file
 *
 * $RCSfile    : $
 * $Author     : HH $
 * $Date       : 2023-02-21 $
 * $Revision   : V09 $
 *
 ******************************************************************************
 * Copyright (c) SOFAR SH 2021
 * All right reserved.
 *****************************************************************************/

#ifndef DIAGNOSTIC_H
#define DIAGNOSTIC_H

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "common.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
typedef enum
{
	DT_UPP = 0,             // Diagnostic UP threshold without upper limit(>)
	DT_UPE,                 // Diagnostic UP threshold with upper limit(>=)
	DT_DWN,                 // Diagnostic DOWN threshold without lower limit(<)
	DT_DWE,                 // Diagnostic DOWN threshold with lower limit(<=)
	DT_OTH                  // Diagnostic others self-defined condition
}DIAG_TYPE_E;

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/
// diagnostic control block
typedef struct
{
	bool_t      *fault;        // diagnostic result(0: no fault, 1: fault)
	uint32_t     type;         // diagnostic type(>, >=, <, <=, self-define)
	bool_t      *mask;         // diagnostic execution mask(0: disable, 1: enable)

	int16_t     *value;        // current value to be diagnosed(active for >, >=, <, <=)
	int16_t     *threshold;    // fault happen threshold(active for >, >=, <, <=)
	int32_t      hysteresis;   // fault restore hysteresis(active for >, >=, <, <=)

	uint32_t     phase;        // diagnostic execution phase(from 1 to period)
	uint32_t     period;       // diagnostic execution period(depend on diag group)
	uint32_t     hpn_cnt;      // fault happen counter
	uint32_t     hpn_timeout;  // fault happen timeout
	uint32_t     rst_cnt;      // fault restore counter
	uint32_t     rst_timeout;  // fault restore timeout

	bool_t   (*check)(void);   // fault check condition(active combine only)
	bool_t   (*restore)(void); // fault recovery condition(active combine only)

	void (*log_happen)(void);  // logging fault happen
	void (*log_restore)(void); // logging fault recovery
}diag_t;

// diagnostic group control block
typedef struct
{
	uint32_t  size;            // diagnostic tasks numbers within a group
	diag_t    *diag;           // pointer to the first diagnostic task of a group
}diag_group_t;

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
void diagnostic_init(void);
void diagnostic(diag_group_t *diag_group);

#endif
/******************************************************************************
* End of module
******************************************************************************/
