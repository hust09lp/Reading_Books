/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     fut_function.c
  * @brief    Factory test item function interface
  * @company  SOFARSOLAR
  * @author   ZT
  * @note
  * @version  V01
  * @date     2023/08/31
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "app_dido.h"
#include "array.h"
#include "can1_bus.h"
#include "fut_function.h"
#include "fut_rs485.h"
#include "fut_rs485_read_write.h"
#include "pcs.h"
#include "sdk_core.h"
#include "calibration.h"
#include "sdk.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/*****************************************************************************/
/**
 * @name  do_on_off.
 * @brief do_test. [Called by fut_param_parase.]
 *
 * @param value  (I)
 * @param none   (O)
 * @return none
 */
/*****************************************************************************/
void do_on_off(uint16_t value)
{
    pcsc_do_ctrl_t fut_do_ctrl;

    fut_do_ctrl.all = value;
	sdk_dido_write(DO1_RSVD, fut_do_ctrl.bit.rsvd_1);
	sdk_dido_write(DO2_STS_SW_ON, fut_do_ctrl.bit.sts_switch_on);
	sdk_dido_write(DO3_GRID_TIED_SW_QF1_ON, fut_do_ctrl.bit.grid_tied_sw_qf1_on);
	sdk_dido_write(DO4_GRID_TIED_SW_QF1_OFF, fut_do_ctrl.bit.grid_tied_sw_qf1_off);
	sdk_dido_write(DO6_STS_SW_OFF, fut_do_ctrl.bit.sts_switch_off);
    //If the temperature sampling is normal, the selected signal can be output normally
	// sdk_dido_write(DO8_SELA, do_ctrl->bit.sel_a);
	// sdk_dido_write(DO9_SELB, do_ctrl->bit.sel_b);
}

/*****************************************************************************/
/**
 * @name  di_test_result.
 * @brief di_test_result. [Called fut_param_parase.]
 *
 * @param value  (I)
 * @param none   (O)
 * @return none
 */
/*****************************************************************************/
void di_test_result(void)
{
    half_word_t di_status_word;
    di_status_word.bits.b0  = sdk_dido_read(DI1_WATER_IN);
    di_status_word.bits.b1  = sdk_dido_read(DI2_DOOR);
    di_status_word.bits.b2  = sdk_dido_read(DI3_STS_SW_ON);
    di_status_word.bits.b3  = sdk_dido_read(DI4_STS_SW_OFF);
    di_status_word.bits.b4  = sdk_dido_read(DI5_QF3_STATUS);
    di_status_word.bits.b5  = sdk_dido_read(DI6_SPD1_STATUS);
    di_status_word.bits.b6  = sdk_dido_read(DI7_AC_SPD);
    di_status_word.bits.b7  = sdk_dido_read(DI8_SPD2_STATUS);
    di_status_word.bits.b8  = sdk_dido_read(DI9_GRID_TIED_SW_ON_QF1);
    di_status_word.bits.b9  = sdk_dido_read(DI10_GRID_TIED_SW_OFF_QF2);
    di_status_word.bits.b10 = sdk_dido_read(DI11_FAN1_STATUS);
    di_status_word.bits.b11 = sdk_dido_read(DI12_FAN2_STATUS);
    di_status_word.bits.b12 = sdk_dido_read(DI13_ISO_DEVICE_FAULT);
    di_status_word.bits.b13 = sdk_dido_read(DI14_ISO_FAULT);
    di_status_word.bits.b14 = sdk_dido_read(DI15_CMU_FAULT);
    di_status_word.bits.b15 = sdk_dido_read(DI16_REMOTE_EPO);

    fut_param.test_di_result_status_word = di_status_word.all;
}

/*****************************************************************************/
/**
 * @name  rs485_can_test.
 * @brief can test. [Called fut_param_parase.]
 *
 * @param value   (I)
 * @param none   (O)
 * @return none
 */
/*****************************************************************************/
void rs485_can_test(void)
{
	bool_t result = TRUE;
	uint8_t i;
	uint8_t recv_can_port, send_can_port;
	static uint8_t flag = 0;
	sdk_can_frame_t test_can_rx_frame;
	static sdk_can_frame_t test_can_tx_frame;

    clear_struct_data((uint8_t *)&test_can_rx_frame, sizeof(sdk_can_frame_t));
    clear_struct_data((uint8_t *)&test_can_tx_frame, sizeof(sdk_can_frame_t));
	recv_can_port = CAN5_PORT;
	send_can_port = CAN1_PORT;
	if(flag == 0)
	{
		test_can_tx_frame.id = 100;
		test_can_tx_frame.len = 8;
		test_can_tx_frame.priv = 1;
		test_can_tx_frame.data[0] = 1;
		test_can_tx_frame.data[1] = 2;
		test_can_tx_frame.data[2] = 3;
		test_can_tx_frame.data[3] = 4;
		test_can_tx_frame.data[4] = 5;
		test_can_tx_frame.data[5] = 6;
		test_can_tx_frame.data[6] = 7;
		test_can_tx_frame.data[7] = 8;


		flag = 1;
		sdk_can_write(send_can_port, &test_can_tx_frame, 1);
	}
	else if(flag == 5)
	{
		sdk_can_read(recv_can_port, &test_can_rx_frame, 1, 10);
		for(i = 0; i < test_can_tx_frame.len; i++)
		{
			result &= (test_can_tx_frame.data[i] == test_can_rx_frame.data[i]);
		}
		if (result)
		{
			fut_param.com_test_result_status_word |= 1;
		}
		else
		{
			fut_param.com_test_result_status_word &= ~1;
		}
		flag = 0;
	}
	else
	{
		flag++;
	}
}

/*****************************************************************************/
/**
 * @name  dc_volt_calc.
 * @brief calc volt. [Called fut_param_parase.]
 *
 * @param none   (O)
 * @return none
 */
/*****************************************************************************/
void dc_volt_calc(void)
{
	static uint8_t count = 0;
	static float32_t volt_tmp[AD_SAMPLE_POINT_NUM];
	uint8_t sample_count = 5;
	uint8_t i;
	uint8_t index = 0;

	volt_tmp[index++] += PARAMETER_ACCURACY_MAGNIFICATION_7 * AC_VOLT_GAIN * (g_ac_sample.vpcs_rn * 0.7326f - 1500.0f);
	volt_tmp[index++] += PARAMETER_ACCURACY_MAGNIFICATION_7 * AC_VOLT_GAIN * (g_ac_sample.vpcs_rs * 0.7326f - 1500.0f);
	volt_tmp[index++] += PARAMETER_ACCURACY_MAGNIFICATION_7 * AC_VOLT_GAIN * (g_ac_sample.vpcs_rt * 0.7326f - 1500.0f);
	volt_tmp[index++] += PARAMETER_ACCURACY_MAGNIFICATION_7 * AC_VOLT_GAIN * (g_ac_sample.vgrd_rn * 0.7326f - 1500.0f);
	volt_tmp[index++] += PARAMETER_ACCURACY_MAGNIFICATION_7 * AC_VOLT_GAIN * (g_ac_sample.vgrd_rs * 0.7326f - 1500.0f);
	volt_tmp[index++] += PARAMETER_ACCURACY_MAGNIFICATION_7 * AC_VOLT_GAIN * (g_ac_sample.vgrd_rt * 0.7326f - 1500.0f);
	volt_tmp[index++] += PARAMETER_ACCURACY_MAGNIFICATION_7 * AC_CURRENT_GAIN * (g_ac_sample.igrd_r * 0.7326f - 1500.0f);
	volt_tmp[index++] += PARAMETER_ACCURACY_MAGNIFICATION_7 * AC_CURRENT_GAIN * (g_ac_sample.igrd_s * 0.7326f - 1500.0f);
	volt_tmp[index++] += PARAMETER_ACCURACY_MAGNIFICATION_7 * AC_CURRENT_GAIN * (g_ac_sample.igrd_t * 0.7326f - 1500.0f);
	volt_tmp[index++] += PARAMETER_ACCURACY_MAGNIFICATION_7 * ((g_ac_sample.igrd_s - 436.8f) * 0.446708f);
	volt_tmp[index++] += PARAMETER_ACCURACY_MAGNIFICATION_7 * ((g_ac_sample.igrd_t - 436.8f) * 0.446708f);
	count++;

	if(count >= sample_count)
	{
		for(i = 0; i < AD_SAMPLE_POINT_NUM; i++)
		{
			dc_volt[i] = volt_tmp[i] / sample_count;
			volt_tmp[i] = 0;
		}
		count = 0;
	}
}
/******************************************************************************
* End of module
******************************************************************************/

