/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     fut_rs485_read_write.h
  * @brief    Factory tests modbus read and write module header file
  * @company  SOFARSOLAR
  * @author   ZT
  * @note
  * @version  V01
  * @date     2023/08/31
  */
/*****************************************************************************/

#ifndef __FUT_RS485_READ_WRITE_H__
#define __FUT_RS485_READ_WRITE_H__

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "common.h"

/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
#define FILE_LENGTH_FUT_PARAM                                             (284)
#define REG_START_ADDR                                                  (64516)
#define REG_WRITE_START_ADDR                                            (64516)
#define REG_END_ADDR                                                    (65000)
#define REG_HOD_NUMBER                                                    (200)
#define REG_HOD_OFFSET1                                                     (0)
#define SN_WORD_LEN                                                        (10)
#define SN_START_OFFSET                                                   (110)
#define SN_END_OFFSET                                                     (119)
#define DC_CALIB_PARM_NUMS                                                  (6)
#define AC_CALIB_PARM_NUMS                                                  (4)

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/
//Offset address
typedef enum
{
	FACTORY_MODE_SETTING = 61,
	TEST_LED_CONTROL_WORD,
	TEST_DO_CONTROL_WORD,
	TEST_PWM_SYNC_CONTROL_WORD = 65,
	TEST_COM_CONTROL_WORD,
	CALIB_T_AC_CAB,
	AC_CALIB_START = 76,
	CALIB_V_PCS_RS = AC_CALIB_START,
	CALIB_V_PCS_ST = AC_CALIB_START + (1 * AC_CALIB_PARM_NUMS),
	CALIB_V_PCS_TR = AC_CALIB_START + (2 * AC_CALIB_PARM_NUMS),
	CALIB_V_GRD_RS = AC_CALIB_START + (3 * AC_CALIB_PARM_NUMS),
	CALIB_V_GRD_ST = AC_CALIB_START + (4 * AC_CALIB_PARM_NUMS),
	CALIB_V_GRD_TR = AC_CALIB_START + (5 * AC_CALIB_PARM_NUMS),
	CALIB_I_R      = AC_CALIB_START + (6 * AC_CALIB_PARM_NUMS),
	CALIB_I_S      = AC_CALIB_START + (7 * AC_CALIB_PARM_NUMS),
	CALIB_I_T      = AC_CALIB_START + (8 * AC_CALIB_PARM_NUMS),
	FACTORY_TEST_RESULT_STATUS_WORD = 109,
	SN_SERIAL_NUMBER = SN_END_OFFSET,
	COM_TEST_RESULT_STATUS_WORD = 120,
}fut_param_offset_addr_t;

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/
typedef struct
{
	uint16_t factory_mode_setting;
	uint16_t test_led_control_word;
	uint16_t test_di_result_status_word;
	uint16_t test_com_control_word;
	uint16_t factory_test_result_status_word;
	uint16_t com_test_result_status_word;
}fut_param_t;

/******************************************************************************
* EXTERN CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* EXTERN VARIABLE DESCRIPTION
******************************************************************************/
extern fut_param_t fut_param;
extern uint16_t* reg_hod[REG_HOD_NUMBER];

/******************************************************************************
* EXTERN FUNCTION PROTOTYPE
******************************************************************************/
int32_t fut_reg_read(uint16_t reg_addr, uint16_t reg_num, uint8_t *p_rsp);
int32_t fut_reg_write(uint16_t reg_addr, uint16_t reg_num, const uint8_t *p_data);
void fut_reg_init(void);

#endif
/******************************************************************************
* End of module
******************************************************************************/

