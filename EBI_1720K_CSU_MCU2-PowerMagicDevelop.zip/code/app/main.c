/******************************************************************************
 * FILE IDENTIFICATION
******************************************************************************/
/**
  * @file     main.c
  * @brief    App main entry module
  * @company  SOFARSOLAR
  * @author   HH
  * @note     
  * @version  V01
  * @date     2023/02/19
  */
/*****************************************************************************/

/******************************************************************************
* COMPILATION OPTION
******************************************************************************/

/******************************************************************************
* INCLUDE FILE
******************************************************************************/
// Include system file -------------------------------------------------------

// Include project file ------------------------------------------------------
#include "app_dido.h"
#include "app_isr.h"
#include "app_thread.h"
#include "array.h"
#include "calibration.h"
#include "can1_bus.h"
#include "csu_data.h"
#include "cup_sofar_can.h"
#include "diag_manage.h"
#include "fut.h"
#include "iec104.h"
#include "iec61850.h"
#include "iso_detect.h"
#include "main.h"
#include "measure.h"
#include "modbus_tcp.h"
#include "others.h"
#include "pcs_sequence.h"
#include "pcsc_diag.h"
#include "pcsc_diag_log.h"
#include "pcsc_opt_log.h"
#include "power_manage.h"
#include "product.h"
#include "fifo_can.h"
#include "safe_parm.h"
#include "sci_mcu1.h"
#include "sdk.h"
#include "sdk_core.h"
#include "setting.h"
#include "task_manage.h"
#include "tpll.h"
#include "upgrade.h"
#include "rtc.h"
#include "fut_rs485.h"
#include "fifo_log.h"
#include "shell.h"
#include "ems.h"
#include "rs485_device_manage.h"


/******************************************************************************
* DEFINE DESCRIPTION
******************************************************************************/
// bytes
#define VERSION_LENGTH_MAX                                                   12

/******************************************************************************
* ENUM DESCRIPTION
******************************************************************************/

/******************************************************************************
* STRUCTURE DESCRIPTION
******************************************************************************/

/******************************************************************************
* CONSTANT DESCRIPTION
******************************************************************************/

/******************************************************************************
* VARIABLE DESCRIPTION
******************************************************************************/

/******************************************************************************
* FUNCTION PROTOTYPE
******************************************************************************/
static void app_sw_init(void);

/******************************************************************************
* FUNCTION DESCRIPTION
******************************************************************************/

/*****************************************************************************/
/**
 * @name  main().
 * @brief App main entry function, after BOOT, HW init,
 *        and CORE done. [Called by OS]
 *
 * @param none   (I)
 * @param none   (O)
 * @return <0(app running failed)
 */
/*****************************************************************************/
int main(void)
{
	int32_t result;
	int8_t  sdk_ver[VERSION_LENGTH_MAX] = {0};

	// core SDK API mapping
	result = core_sdk_api_init(CORE_SDK_API_START_FLASH_ADDR);
	if(result != SF_OK)
	{
		// failed to map core SDK API
		return (-1);
	}

	// core SDK version checking
	result = sdk_version_get(SDK_VERSION_TYPE, &sdk_ver[0], VERSION_LENGTH_MAX);
	if(result < 0)
	{
		// failed to get core SDK version
		return (-2);
	}

	result = strcmp((char *)&sdk_ver[0], SDK_VERSION_INFO);
	if(result != 0)
	{
		sdk_start_upgrade((uint8_t*)APP_FILE_NAME, FIRMWARE_UPGRADE_FAIL);
		sdk_start_upgrade((uint8_t*)CORE_FILE_NAME, FIRMWARE_UPGRADE_FAIL);
		sdk_log_a("SDK version unmatched, forbidden to run App code\r\n");
		// SDK version unmatched, forbidden to run App code
		return (-3);
	}

	upgrade_init();
	upgrade_flag_check();

	// initial log
	result = sdk_log_init();
	if(result != SF_OK)
	{
		// failed to init log module
		return (-4);
	}
	sdk_log_set_level(LOG_LVL_DISABLE);

	// initial HW timer
	result = sdk_timer_init(SDK_TIMER_0, TIMER_TYPE_HARD);
	if(result != SF_OK)
	{
		// failed to init log module
		return (-5);
	}
	sdk_timer_set(SDK_TIMER_0, TIMER_TYPE_HARD, 100, timer_100us_isr);

	sdk_log_i("***********************************\r\n");
	sdk_log_i("APP project start up...\r\n");
	sdk_log_i("SDK version:%s...\r\n", sdk_ver);
	sdk_log_i("***********************************\r\n");

//    sdk_led_flash(HEART_LED, 1000, 50, LED_FLASH_CONTINUE);
	app_sw_init();
	output_product_info();

	result = app_thread_init();
	if(result != SF_OK)
	{
		// failed to init app thread
		sdk_log_e("Create app threads failed!\r\n");
		return (-6);
	}

	sdk_timer_start(SDK_TIMER_0, TIMER_TYPE_HARD);
	opt_log_record("Init done, mcu2 start\r\n");

	while(1)
	{
		// task_scheduler(&bkgd_group);
		sdk_delay_ms(1000);
	}
}

/*****************************************************************************/
/**
 * @name  app_sw_init().
 * @brief Initialize app software modules. [Called by main()]
 *
 * @param none   (I)
 * @param none   (O)
 * @return none
 */
/*****************************************************************************/
static void app_sw_init(void)
{
	fifo_log_init();
	pcsc_opt_log_init();
	file_system_init();
	setting_init();
	calibration_init();
    rtc_init();

	app_dido_init();
	can1_bus_init();
	diag_manage_init();
	fifo_can_init();
	iso_detect_init();
	measure_init();
	modbus_tcp_init();
	others_init();
	tpll_init();
	pcs_sm_init();
	power_manage_init();
	product_init();
	sci_mcu1_init();
	setting_enet_init();
	pcs_iec104_init();
	setting_uart_init();
	total_time_init();
	rs485_fut_init();
	pcs_init();
	rs485_device_init();

	setting_inter_conf_init();
	pcsc_diag_init();
	pcsc_diag_log_init();
	shell_init();
	csu_data_init();
	xiaoju_init();
	pwm_init();

	task_scheduler_init();
	task_manage_init();
}

/******************************************************************************
* End of module
******************************************************************************/
