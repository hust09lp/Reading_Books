#include "sdk_core.h"
#include "main.h"


core_sdk_interface_t *gp_core_sdk_api = NULL;

int32_t core_sdk_api_init(uint32_t sdk_api_addr)
{
    if (sdk_api_addr > APP_START_FLASH_ADDR)
    {
        return SF_ERR_PARA;
    }

    gp_core_sdk_api = (core_sdk_interface_t *)(sdk_api_addr);

    if(gp_core_sdk_api == NULL)
    {
        return SF_ERR_FNOSUPP;
    }

    return SF_OK;
}

