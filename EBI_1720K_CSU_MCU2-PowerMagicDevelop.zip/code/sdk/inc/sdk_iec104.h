/**
 * @file          sdk_iec104.h
 * @brief         iec104通讯封装
 * @details       提供iec104相关接口函数
 * @author        guanjianhe
 * @version       V0.0.1     初始版本
 * @copyright     Copyright (c) 2022 by SofarSolar, All Rights Reserved.
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author          <th>Description
 * <tr><td>2023/04/18  <td>0.0.1    <td>gjh             <td>创建初始版本
 * </table>
 *
 **********************************************************************************
 * @par 示例:
 * @code
 * 暂无
 * @endcode
 */


#ifndef __SDK_IC104_H__
#define __SDK_IC104_H__

#include "data_types.h"

typedef int32_t (*control_set_f)(uint32_t addr, uint8_t value);
typedef int32_t (*para_set_f)(uint32_t addr, void *p_value, uint8_t len);

typedef struct              // 遥信数据
{
    uint8_t *p_signal_dat;  // 数据指针
    uint32_t signal_addr;   // 实际映射起始地址
    uint32_t signal_num;    // 个数
} sdk_iec104_signal_info_t;

typedef struct
{
    uint16_t *p_detect_dat;    // 数据指针
    uint32_t detect_addr;      // 实际映射起始地址
    uint32_t detect_num;       // 个数
} sdk_iec104_dectect_info_t;

typedef struct
{
    float *p_detect_float_dat;  // 数据指针
    uint32_t detect_float_addr; // 实际映射地址
    uint32_t detect_float_num;  // 个数
} sdk_iec104_dectect_float_info_t;


typedef struct
{
    void *p_para_dat;          // 数据指针
    uint32_t para_addr;        // 实际映射起始地址
    uint32_t para_num;         // 个数
    uint8_t para_size;         // 每个参数字节大小
} sdk_iec104_para_info_t;


typedef struct
{
    sdk_iec104_signal_info_t        *p_sdk_iec104_signal_info;
    uint16_t                        signal_info_num;
    sdk_iec104_dectect_info_t       *p_sdk_iec104_dectect_info;
    uint16_t                        dectect_info_num;
    sdk_iec104_dectect_float_info_t *p_sdk_iec104_dectect_float_info;
    uint16_t                        dectect_float_info_num;
    sdk_iec104_para_info_t         *p_sdk_iec104_para_info;
    uint16_t                        para_info_num;
    control_set_f   control_set;    // 遥控参数设置
    para_set_f      para_set;       // 参数设置
} sdk_iec104_info_t;

typedef struct
{
    int16_t detect;    // 遥测值
    uint8_t qds;       // 品质描述
} sdk_iec104_detect_t;


/**
 * @brief   iec104 初始化
 * @param sdk_iec104_info
 * @return                      执行结果
 * @retval          0           执行成功
 * @retval         <0           执行失败
 */
int32_t sdk_iec104_init(sdk_iec104_info_t sdk_iec104_info);

/**
 * @brief           单点遥信突发上传
 * @param time_flg  时标标志，0不带时标，1带绝对时标
 * @param addr      地址
 * @param value     遥信值
 * @return          执行结果
 * @retval       0  执行成功
 * @retval      <0  执行失败
 */
int32_t sdk_iec104_signal_spont(uint8_t time_flg, uint32_t addr, uint8_t value);

/**
 * @brief               短浮点遥测突发上传
 * @param time_flg      时标标志，0不带时标，1带绝对时标
 * @param addr          地址
 * @param value         短浮点遥测值
 * @return              执行结果
 * @retval       0      执行成功
 * @retval      <0      执行失败
 */
int32_t sdk_iec104_detect_float_spont(uint8_t time_flg, uint32_t addr, float value);

/**
 * @brief               归一化遥测突发上传
 * @param time_flg      时标标志，0不带时标，1带绝对时标
 * @param addr          地址
 * @param detect        遥测值
 * @return              执行结果
 * @retval       0      执行成功
 * @retval      <0      执行失败
 */
int32_t sdk_iec104_detect_spont(uint8_t time_flg, uint32_t addr, sdk_iec104_detect_t detect);


#endif


