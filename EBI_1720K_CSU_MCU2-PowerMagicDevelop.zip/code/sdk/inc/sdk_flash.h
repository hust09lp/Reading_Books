/** 
 * @file          sdk_flash.h
 * @brief         flash 相关接口
 * @author        guanjianhe
 * @version       V0.0.1     初始版本
 * @date          2023/09/14 11:12:30
 * @copyright     Copyright (c) 2022 by SofarSolar, All Rights Reserved. 
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author    <th>Description
 * <tr><td>2023/09/14  <td>0.0.1    <td>guanjianhe     <td>创建初始版本
 * </table>
 *
 **********************************************************************************
 * @par 示例:
 * @code
 * 暂无
 * @endcode
 */

#ifndef __SDK_FLASH_H__
#define __SDK_FLASH_H__

#include "data_types.h"

enum
{
    FLASH_ID_INT,    ///< 内部flash
    FLASH_ID_MAX,    ///< flash总数
};

enum
{
    FLASH_CMD_TOTAL_SIZE_GET,   ///< 获取 flash 总大小
    FLASH_CMD_SECTOR_SIZE_GET,  ///< 获取 扇区 总大小
};


/** 
 * @brief        擦除flash数据
 * @param        [in] flash_id  flash的编号（索引）值
 * @param        [in] addr 起始地址
 * @param        [in] len  长度
 * @return       [int32_t] 执行结果
 * @retval       =0 成功
 * @retval       <0       失败 不同值对应不同的错误代码，参考sofar_errors.h。
 * @note         擦除是以块为单位擦除的，如果len长度小于块的大小，擦除的是整个块的大小
 * @date         2023/09/14 13:30:47
 */
int32_t sdk_flash_erase(uint32_t flash_id, uint32_t addr, uint32_t len);

/** 
 * @brief        写数据到flash
 * @param        [in] flash_id  flash的编号（索引）值
 * @param        [in] addr 写入的起始地址
 * @param        [in] len 待写入的数据长度
 * @param        [in] p_buf 数据指针
 * @return       [int32_t] 执行结果
 * @retval       =0 成功
 * @retval       <0       失败 不同值对应不同的错误代码，参考sofar_errors.h。
 * @note         
 * @date         2023/09/14 13:30:47
 */
int32_t sdk_flash_write(uint32_t flash_id, uint32_t addr, uint32_t len, uint8_t *p_buf);


/** 
 * @brief        从flash中读取数据
 * @param        [in] flash_id  flash的编号（索引）值
 * @param        [in] addr 读取的起始地址
 * @param        [in] len 待读取的数据长度
 * @param        [out] p_buf 数据指针
 * @return       [int32_t] 执行结果
 * @retval       =0 成功
 * @retval       <0       失败 不同值对应不同的错误代码，参考sofar_errors.h。
 * @note         
 * @date         2023/09/14 13:30:47
 */
int32_t sdk_flash_read(uint32_t flash_id, uint32_t addr, uint32_t len, uint8_t *p_buf);



/**
 * @brief       flash 控制
 * @param       [in] flash_id   flash的编号（索引）值
 * @param       [in] cmd        flash 操作命令
 * @param       p_arg           flash 操作命令的参数
 * @return      [int32_t]       执行结果
 * @retval      =0 成功
 * @retval      <0       失败 不同值对应不同的错误代码，参考sofar_errors.h。
 * @note         
 * @date         2023/09/14 13:30:47
 */
int32_t sdk_flash_ioctl(uint32_t flash_id, uint32_t cmd, void* p_arg);


#endif /* __SDK_FLASH_H__  */
