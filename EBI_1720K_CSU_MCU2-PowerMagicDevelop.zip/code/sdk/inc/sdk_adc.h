/** 
 * @file         sdk_adc.h
 * @brief        ADC功能定义
 * @details      主要包含了关于ADC使用的功能相关函数
 * @author       SOFAR
 * @date         2023/02/23
 * @version      V0.0.2
 * @copyright    Copyright(c) 2023 by SofarSolar, All Rights Reserved. 
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author    <th>Description
 * <tr><td>2023/02/23  <td>0.0.1    <td>apoi     <td>创建初始版本
 * <tr><td>2023/03/13  <td>0.0.2    <td>chace    <td>1.新增ADC多通道配置接口;2.增加转换完成事件通知
 * <tr><td>2023/04/11  <td>0.0.3    <td>chace    <td>1.去掉单通道接口;2.修改ADC名称，兼容单通道和多通道功能
 * </table>
 *
 **********************************************************************************
 * @par 示例:
 * @code
 * 暂无
 * @endcode
 */

#ifndef __SDK_ADC_H__
#define __SDK_ADC_H__

#include "data_types.h"


#define ADC_CHANNEL_MAX         30      ///< ADC通道最大值，实际数量与平台有关


/** 
 * @enum  sdk_adc_event_e
 * @brief ADC事件枚举值
 */
typedef enum
{
    ADC_CONVERSION_COMPLETED = 0,           ///< ADC转换完成
    ADC_CONVERSION_TIMEOUT,                 ///< ADC转换超时
    ADC_CONVERSION_FAIL,                    ///< ADC转换失败
}sdk_adc_event_e;

typedef int32_t (*f_adc_event_cb)(sdk_adc_event_e event);


/**
 * @struct  sdk_adc_channel_t
 * @brief ADC多通道结构体
 */
typedef struct
{
    uint32_t channel_id;                     ///< ADC通道序号
    uint32_t channel[ADC_CHANNEL_MAX];       ///< ADC通道数组(虚拟通道)
    uint16_t channel_num;                    ///< ADC通道个数
    uint32_t sample_period;                  ///< ADC通道采样周期
    int32_t *p_buf;                          ///< ADC通道缓存地址
    uint16_t buf_len;                        ///< ADC通道缓存长度
    f_adc_event_cb event_cb;                 ///< ADC事件回调函数
}sdk_adc_channel_t;


/** 
 * @brief     ADC通道配置
 * @param[in] p_channel ADC通道结构体参数
 * @return    返回结果
 * @retval    0  成功
 * @retval    <0 失败原因
 * @note      此函数满足了需快速同时读取多个通道值的需求，同时兼容单通道的读取
 * @attention 通道结构体中的通道数组的赋值顺序即为缓存地址存储转换结果的顺序
 */
int32_t sdk_adc_setup(sdk_adc_channel_t *p_channel);

/** 
 * @brief     ADC通道启动转换
 * @param[in] p_channel  ADC通道结构体参数
 * @return    返回结果
 * @retval    0  成功
 * @retval    <0 失败原因
 * @note      调用此函数后，ADC默认连续采样
 * @attention 执行sdk_adc_setup后执行才有效
 * @warning   采样事件为NULL时，直接读取转换结果缓存地址数据可能存在为上一次转换结果的情况
 */
int32_t sdk_adc_start(sdk_adc_channel_t *p_channel);

/** 
 * @brief     ADC通道停止转换
 * @param[in] p_channel ADC通道结构体参数
 * @return    返回结果
 * @retval    0  成功
 * @retval    <0 失败原因
 * @attention 执行sdk_adc_setup后执行才有效
 */
int32_t sdk_adc_stop(sdk_adc_channel_t *p_channel);

/** 
 * @brief     ADC通道转换结果读取
 * @param[in]  channel ADC采样通道(虚拟通道)
 * @param[out] p_value ADC转换结果
 * @return     返回结果
 * @retval     0  成功
 * @retval     <0 失败原因
 * @attention  执行sdk_adc_start后执行才有效
 */
int32_t sdk_adc_read(uint32_t channel, int32_t *p_value);

/** 
 * @brief    ADC参考电压获取
 * @param[in]  channel_id ADC采样通道(虚拟通道)
 * @return   返回结果
 * @retval   >=0 参考电压(mv)
 * @retval   <0  失败原因
 */
int32_t sdk_adc_refer_voltage_get(uint32_t channel_id);

/** 
 * @brief     ADC采样精度获取
 * @param[in] channel_id ADC采样通道(虚拟通道)
 * @return    返回位数
 * -# 8  - 8位数据
 * -# 10 - 10位数据
 * -# 12 - 12位数据
 * -# 16 - 16位数据
 * -# 24 - 24位数据
 * @retval    <0 失败原因
 */
int32_t sdk_adc_sample_bit_get(uint32_t channel_id);


#endif /* #define __SDK_ADC_H__  */
