/** 
 * @file        sdk_osif.h
 * @brief       os系统功能定义
 * @details     主要包含了关于os系统功能的相关函数
 * @author   	renwj
 * @note     	无
 * @version  	V1.0.1 初始版本
 * @date     	2022/12/30
 * @copyright   Copyright(c) 2022 by SofarSolar, All Rights Reserved. 
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author    <th>Description
 * <tr><td>2022/2/30   <td>1.0.1    <td>renwj     <td>创建初始版本
 * <tr><td>2023/5/19   <td>1.0.2    <td>hewj      <td>增加信号量和系统锁的接口
 * <tr><td>2023/6/15   <td>1.0.3    <td>hewj      <td>增加对线程操作相关接口
 * </table>
 *
 **********************************************************************************
 * @par 示例:
 * @code
 * 暂无
 * @endcode
 */
#ifndef __SDK_OSIF_H__
#define __SDK_OSIF_H__

#include "data_types.h"

#define SDK_OS_PRIORITY_MAX             20   ///< app use Priority max number

typedef void *sdk_os_sem_id_t;
typedef void *sdk_os_mutex_id_t;

/**
 * @struct os_thread_attr_t
 * @brief Attributes structure for thread.
 */
typedef struct {
    const int8_t                        *name;           ///< name of the thread
    uint32_t                            attr_bits;       ///< attribute bits
    void                                *cb_mem;         ///< memory for control block
    uint32_t                            cb_size;         ///< size of provided memory for control block
    uint32_t                            tick;
    void                                *stack_mem;      ///< memory for stack
    uint32_t                            stack_size;      ///< size of stack
    uint32_t                            priority;        ///< initial thread priority (default: OS_PRIORITY_NORMAL)
#ifdef __TZ_MODULEID_T__
    TZ_module_id_t                        tz_module;     ///< TrustZone module identifier
#endif
    uint32_t                            reserved;        ///< reserved (must be 0)
} sdk_os_thread_attr_t;


/**
 * @enum sdk_os_status_e
 * @brief Status code values returned by RTOS functions.
 */
typedef enum {
    SDK_OS_OK                           =  0,           ///< Operation completed successfully.
    SDK_OS_ERROR                        = -1,           ///< Unspecified RTOS error: run-time error but no other error message fits.
    SDK_OS_ERROR_TIMEOUT                = -2,           ///< Operation not completed within the timeout period.
    SDK_OS_ERROR_RESOURCE               = -3,           ///< Resource not available.
    SDK_OS_ERROR_PARAMETER              = -4,           ///< Parameter error.
    SDK_OS_ERROR_NO_MEMORY              = -5,           ///< System is out of memory: it was impossible to allocate or reserve memory for the operation.
    SDK_OS_ERROR_ISR                    = -6,           ///< Not allowed in ISR context: the function cannot be called from interrupt service routines.
    SDK_OS_STATUS_RESERVED              = 0x7FFFFFFF    ///< Prevents enum down-size compiler optimization.
} sdk_os_status_e;

/// \details Thread ID identifies the thread.
typedef void *sdk_os_thread_id_t;


/** Entry point of a thread. */
typedef void (*sdk_os_thread_func_t)(void *argument);


typedef struct
{
    sdk_os_thread_attr_t thread_attr;
    sdk_os_thread_func_t func;
    sdk_os_thread_id_t   thread_id;
}sdk_os_thread_attr_tab_t; ///< 后续作废

/**
 * @enum  os_thread_state_e
 * @brief Thread state.
 */
typedef enum {
    sdk_OS_THREAD_INACTIVE              = 0,            ///< Inactive.
    sdk_OS_THREAD_READY                 = 1,            ///< Ready.
    sdk_OS_THREAD_RUNNING               = 2,            ///< Running.
    sdk_OS_THREAD_BLOCKED               = 3,            ///< Blocked.
    sdk_OS_THREAD_TERMINATED            = 4,            ///< Terminated.
    sdk_OS_THREAD_ERROR                 = -1,           ///< Error.
    sdk_OS_THREAD_RESERVED              = 0x7FFFFFFF    ///< Prevents enum down-size compiler optimization.
} sdk_os_thread_state_e;

typedef struct {
    const int8_t                        *name;          ///< name of the semaphore
    uint32_t                            attr_bits;      ///< attribute bits
    void                                *cb_mem;        ///< memory for control block
    uint32_t                            cb_size;        ///< size of provided memory for control block
} sdk_os_sem_attr_t;

typedef struct {
    const int8_t                        *name;          ///< name of the mutex
    uint32_t                            attr_bits;      ///< attribute bits
    void                                *cb_mem;        ///< memory for control block
    uint32_t                            cb_size;        ///< size of provided memory for control block
} sdk_os_mutex_attr_t;

// Timeout value.
#define OS_WAIT_FOREVER                    0xFFFFFFFFU  ///< Wait forever timeout value.

/**
 * @brief        Status code values returned by RTOS functions.
 * @param        [in] ticks 延时多少ticks
 * @return       执行结果 返回状态
 */
int32_t sdk_os_delay(uint32_t ticks);

/**
 * @brief        毫秒转成tick数.
 * @param        [in] ms
 * @return        执行结果 tick
 */
uint32_t sdk_os_tick_from_millisecond(uint32_t ms);

/**
 * @brief        注册线程(批量注册)
 * @param        [in] thread_num  线程数量(thread_num>1,批量注册)
 * @param        [in] p_attr 线程属性结构指针
 * @return        执行结果
 * @retval        0  创建成功
 * @retval      其它值详情见sdk_os_status_e
 * @note         stack_size >= 128 * 4 byte，后续此接口作废
 */
int32_t sdk_os_thread_new(uint8_t thread_num, sdk_os_thread_attr_tab_t *p_attr);

/**
 * @brief        创建线程
 * @param        [in] func     线程的入口函数
 * @param        [in] argument 线程进入函数的参数
 * @param        [in] sdk_os_thread_attr_t 线程实例
 * @return       sdk_os_thread_id_t
 * @retval       非空：创建成功
 * @retval       NULL：创建失败
 * @note         stack_size >= 128 * 4 byte
 */
sdk_os_thread_id_t sdk_os_thread_create(sdk_os_thread_func_t func, void *argument, const sdk_os_thread_attr_t *attr);

/**
 * @brief        获取当前运行线程的sdk_os_thread_id_t
 * @param        void
 * @return       sdk_os_thread_id_t
 * @note         
 */
sdk_os_thread_id_t sdk_os_thread_get_id(void);

/**
 * @brief        获取线程名字
 * @param        [in] thread_id 线程ID
 * @return       字符串
 * @note         和sdk_os_thread_create配套使用，要先有创建
 */
const int8_t *sdk_os_thread_get_name(sdk_os_thread_id_t thread_id);

/**
 * @brief        获取线程状态
 * @param        [in] thread_id 线程ID
 * @return       sdk_os_thread_state_e
 * @note         和sdk_os_thread_create配套使用，要先有创建
 */
sdk_os_thread_state_e sdk_os_thread_state_get(sdk_os_thread_id_t thread_id);

/**
 * @brief        获取线程栈大小
 * @param        [in] thread_id 线程ID
 * @return       线程栈大小
 * @note         和sdk_os_thread_create配套使用，要先有创建
 */
uint32_t sdk_os_thread_stack_size_get(sdk_os_thread_id_t thread_id);

/**
 * @brief        获取线程栈剩余空间
 * @param        [in] thread_id 线程ID
 * @return       栈剩余空间
 * @note         和sdk_os_thread_create配套使用，要先有创建
 */
uint32_t sdk_os_thread_stack_space_get(sdk_os_thread_id_t thread_id);

/**
 * @brief        获取线程当前优先级
 * @param        [in] thread_id 线程ID
 * @return       线程当前优先级
 * @note         和sdk_os_thread_create配套使用，要先有创建
 */
uint32_t sdk_os_thread_priority_get(sdk_os_thread_id_t thread_id);

/**
 * @brief        让出当前运行线程运行权
 * @param        void
 * @return       sdk_os_status_e
 * @note         使当前线程从执行状态(运行状态)变为可执行态(就绪状态),
 *               让出运行权后调度程序将选择要运行的最高线程运行
 */
sdk_os_status_e sdk_os_thread_yield(void);

/**
 * @brief        线程挂起
 * @param        [in] thread_id 线程ID
 * @return       sdk_os_status_e
 * @note         和ssdk_os_thread_create配套使用，要先有创建
 */
sdk_os_status_e sdk_os_thread_suspend(sdk_os_thread_id_t thread_id);

/**
 * @brief        线程恢复
 * @param        [in] thread_id 线程ID
 * @return       sdk_os_status_e
 * @note         和sdk_os_thread_create配套使用，要先有挂起
 */
sdk_os_status_e sdk_os_thread_resume(sdk_os_thread_id_t thread_id);

/**
 * @brief        关闭线程
 * @param        [in] thread_id 线程ID
 * @return       sdk_os_status_e
 * @note         和sdk_os_thread_create配套使用，要先有创建
 */
sdk_os_status_e sdk_os_thread_terminate(sdk_os_thread_id_t thread_id);

/**
 * @brief        创建信号量
 * @param        [in] initial_value 信号量初始值
 * @param        [in] p_sem_attr sdk_os_sem_attr_t指针信息
 * @return       返回信号量
 * @retval       NULL 创建失败 
 * @retval       sdk_os_sem_id_t 创建成功
 * @note         initial_value <= 65535
 */
sdk_os_sem_id_t sdk_os_sem_new(uint32_t initial_value, sdk_os_sem_attr_t *p_sem_attr);

/**
 * @brief        获取信号量
 * @param        [in] semaphore_id 需要获取的信号量
 * @param        [in] timeout 获取信号量等待时间
 * @return       返回获取结果
 * @retval       0:SDK_OS_OK 获取成功
 * @retval       其它值获取失败，详情见sdk_os_status_e
 */
sdk_os_status_e sdk_os_sem_acquire(sdk_os_sem_id_t semaphore_id, uint32_t timeout);

/**
 * @brief        释放信号量
 * @param        [in] semaphore_id 需要释放的信号量
 * @return       返回释放结果
 * @retval       0:SDK_OS_OK 释放成功
 * @retval       其它值获取失败，详情见sdk_os_status_e
 */
sdk_os_status_e sdk_os_sem_release(sdk_os_sem_id_t semaphore_id);

/**
 * @brief        删除指定的信号量
 * @param        [in] semaphore_id 需要删除的信号量
 * @return       返回删除结果
 * @retval       0:SDK_OS_OK 删除成功
 * @retval       其它值获取失败，详情见sdk_os_status_e
 */
sdk_os_status_e sdk_os_sem_delete(sdk_os_sem_id_t semaphore_id);

/**
 * @brief        创建互斥信号量
 * @param        [in] p_mutex_attr sdk_os_mutex_attr_t指针信息
 * @return       返回互斥信号量
 * @retval       NULL 创建失败
 * @retval       sdk_os_mutex_id_t 创建成功
 */
sdk_os_mutex_id_t sdk_os_mutex_new(sdk_os_mutex_attr_t *p_mutex_attr);

/**
 * @brief        获取互斥信号量
 * @param        [in] mutex_id 需要获取的互斥信号量
 * @param        [in] timeout 获取互斥信号量等待时间
 * @return       返回获取结果
 * @retval       0:SDK_OS_OK 获取成功
 * @retval       其它值获取失败，详情见sdk_os_status_e
 */
sdk_os_status_e sdk_os_mutex_acquire(sdk_os_mutex_id_t mutex_id, uint32_t timeout);

/**
 * @brief        释放互斥信号量
 * @param        [in] mutex_id 需要释放的互斥信号量
 * @return       返回释放结果
 * @retval       0:SDK_OS_OK 释放成功
 * @retval       其它值获取失败，详情见sdk_os_status_e
 */
sdk_os_status_e sdk_os_mutex_release(sdk_os_mutex_id_t mutex_id);

/**
 * @brief        删除指定的互斥信号量
 * @param        [in] mutex_id 需要删除的互斥信号量
 * @return       返回删除结果
 * @retval       0:SDK_OS_OK 删除成功
 * @retval       其它值获取失败，详情见sdk_os_status_e
 */
sdk_os_status_e sdk_os_mutex_delete(sdk_os_mutex_id_t mutex_id);

#endif
