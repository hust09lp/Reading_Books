/**
 * @file          sdk_iec61850.h
 * @brief         iec61850通讯封装
 * @details       提供iec61850相关接口函数
 * @author        fengqiuxiong
 * @version       V0.0.1     初始版本
 * @copyright     Copyright (c) 2022 by SofarSolar, All Rights Reserved.
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author          <th>Description
 * <tr><td>2023/04/18  <td>0.0.1    <td>gjh             <td>创建初始版本
 * </table>
 *
 **********************************************************************************
 * @par 示例:
 * @code
 * 暂无
 * @endcode
 */
#include "data_types.h"

#ifndef __SDK_IEC61850_H__
#define __SDK_IEC61850_H__

/**
 * @brief   iec61850 goose订阅数据获取
 * @param[in] p_data 数据传输指针，数据类型不同时强制转成该指针类型，不影响数据内容
 * @param[in] num 所要获取数据的个数，结果顺序存于p_data指针中，数据顺序为有功功率、无功功率、开关机，
 * 个数可少于最大的个数（即可以只更新前面的某几个）
 * @return                      执行结果
 * @retval        >=0           执行成功
 * @retval         <0           执行失败
 */
int32_t sdk_iec61850_goose_data_get(float32_t *p_data, uint16_t num);

/**
 * @brief   iec61850 goose发布数据更新
 * @param[in] p_data 数据传输指针，数据类型不同时强制转成该指针类型，不影响数据内容
 * @param[in] num 所要设置数据的个数，数据内容顺序存于p_data指针中,数据顺序为额定功率，状态，
 * 最大可充电功率，最大可放电功率，电池SOC, 实时有功功率，实时无功功率，可增加无功功率，可减少无功功率， 
 * 个数可少于最大的个数（即可以只更新前面的某几个）
 * @return                      执行结果
 * @retval        >=0           执行成功
 * @retval         <0           执行失败
 */
int32_t sdk_iec61850_goose_data_set(float32_t *p_data, uint16_t num);


#endif
