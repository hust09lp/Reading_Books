/**
 * @file     	sdk_para.h
 * @brief    	参数存储功能定义
 * @details     主要包含了关于参数存储功能的相关函数
 * @author   	renwj
 * @note     	无
 * @version  	V1.0.1 初始版本
 * @date     	2022/12/30
 * @copyright   Copyright(c) 2022 by SofarSolar, All Rights Reserved. 
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author    <th>Description
 * <tr><td>2022/2/30   <td>1.0.1    <td>renwj     <td>创建初始版本
 * </table>
 *
 **********************************************************************************
 * @par 示例:
 * @code
 * 暂无
 * @endcode
 */

#ifndef __SDK_PARA_H__
#define __SDK_PARA_H__

#include "data_types.h"


#define PARA_TYPE_NUM_MAX   10     // 应用在使用时，定义的参数类型type个数不能超过PARA_TYPE_NUM


/**
 * @brief  按参数区类型挂载参数
 *         多次挂载没有副作用
 * @param  [in] type 参数区类型（枚举中定义的值）
 * @param  [in] para_size 参数区大小（不能超过物理空间）
 * @retval 0  成功
 * @retval -1 参数区不存在
 * @retval -2 参数大小非法
 * @retval -3 -4文件系统错误
 */
int32_t sdk_para_init(uint32_t type, uint32_t para_size);

/**
 * @brief  按参数区类型写内容
 * @param  [in] type 参数区类型（枚举中定义的值）
 * @param  [in] offset 参数中的位置 (offset+len < para_size)
 * @param  [in] buf 内容
 * @param  [in] len 内容长度 (offset+len < para_size)
 * @retval 0  成功
 * @retval -1 参数区不存在
 * @retval -2 参数区未挂载
 * @retval -3 写入超出长度
 * @retval -6 定位指针错误
 * @retval -8 写错误
 */
int32_t sdk_para_write(uint32_t type, uint32_t offset, uint8_t *p_buf, uint32_t len);

/**
 * @brief  按参数区类型读参数
 * @param  [in]  type 参数区类型（枚举中定义的值）
 * @param  [in]  offset 参数中的位置 (offset+len < para_size)
 * @param  [out] buf 内容
 * @param  [in]  len 内容长度 (offset+len < para_size)
 * @retval >=0  成功 值表示读出数据的长度
 * @retval -1 参数区不存在
 * @retval -2 参数区未挂载
 * @retval -3 写入超出长度
 * @retval -6 定位指针错误
 * @retval -7 读错误
 */
int32_t sdk_para_read(uint32_t type, uint32_t offset, uint8_t *p_buf, uint32_t len);

/**
 * @brief  同步参数的数据到flash(写入的数据，只有同步后才会掉电保存)
 * @param  [in] type 参数区类型（枚举中定义的值）
 * @retval 0  成功
 * @retval -1 失败
 */
int32_t sdk_para_sync(uint32_t type);


#endif /*__SDK_PARA_H__*/
