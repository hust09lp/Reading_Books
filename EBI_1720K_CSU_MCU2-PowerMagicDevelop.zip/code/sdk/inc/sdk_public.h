/**
 * @file         sdk_public.h
 * @brief        公共模块功能定义
 * @details     主要包含了关于公共模块功能的相关函数
 * @author       renwj
 * @note         无
 * @version      V1.0.1 初始版本
 * @date         2022/12/30
 * @copyright   Copyright(c) 2022 by SofarSolar, All Rights Reserved. 
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author    <th>Description
 * <tr><td>2022/2/30   <td>1.0.1    <td>renwj     <td>创建初始版本
 * </table>
 *
 **********************************************************************************
 * @par 示例:
 * @code
 * 暂无
 * @endcode
 */
 
#ifndef __SDK_PUBLIC_H__
#define __SDK_PUBLIC_H__

#include "data_types.h"


#define RTC_BIN_FORMAT                ((uint32_t)0x000000000)
#define RTC_BCD_FORMAT                ((uint32_t)0x000000001)
#define SDK_IS_RTC_FORMAT(FORMAT)     (((FORMAT) == RTC_BIN_FORMAT) || ((FORMAT) == RTC_BCD_FORMAT))


/**
  * @struct hal_rtc_time_t
  * @brief RTC时间。
  */
typedef struct  {
    uint8_t  tm_sec;     ///<  秒     0-59
    uint8_t  tm_min;     ///<  分钟    0-59 
    uint8_t  tm_hour;    ///<  小时 0-23
    uint8_t  tm_weekday; ///<  星期    1-7
    uint8_t  tm_day;     ///<  日     1-31
    uint8_t  tm_mon;     ///<  月     1-12
    uint8_t  tm_year;    ///<  年 范围00-99 自2000年至今
}sdk_rtc_t;



/**
 * @brief        延时ms
 * @param        [in] ms 需要延时的ms数
 */
void sdk_delay_ms(uint32_t ms);

/**
 * @brief        延时us
 * @param        [in] us 需要延时的us数, <1000us
 */
void sdk_delay_us(uint32_t us);

/**
 * @brief        设置RTC时间 
 * @param        [in] rtc_format 时间格式
 * -# RTC_BIN_FORMAT ((uint32_t)0x000000000)
 * -# RTC_BCD_FORMAT ((uint32_t)0x000000001)
 * @param        [in] p_time rtc时间结构体  
 * @return        执行结果
 * @retval        SF_OK 成功  
 * @retval        <0 失败，详情见 sofar_errors.h
 */
int32_t sdk_rtc_set(uint32_t rtc_format, sdk_rtc_t *p_time);


/**
 * @brief        读取RTC时间 
 * @param        [in] rtc_format 时间格式
 * -# RTC_BIN_FORMAT ((uint32_t)0x000000000)
 * -# RTC_BCD_FORMAT ((uint32_t)0x000000001)
 * @param        [out] p_time rtc时间结构体
 * @return        执行结果
 * @retval        SF_OK 成功  
 * @retval        <0 失败，详情见 sofar_errors.h   
 */
int32_t sdk_rtc_get(uint32_t rtc_format, sdk_rtc_t *p_time);


/**
 * @brief        获取当前tick
 * @return        当前tick值
 */
uint32_t sdk_tick_get(void);

/**
 * @brief        判断时间tick是否超时
 * @param        [in] start_tick 启动计时的tick  
 * @param        [in] interval 中间间隔
 * @return        是否超时 
 * @retval        true 已超时
 * @retval        false 未超时
 */
bool sdk_is_tick_over(uint32_t start_tick, uint32_t interval);

/**
 * @brief        判断rtc时间是否超时
 * @param        [in] p_start_time 启动rtc时间 
 * @param        [in] interval 中间间隔 单位S
 * @return        是否超时 
 * @retval        true 已超时
 * @retval        false 未超时
 */
bool sdk_is_time_over(sdk_rtc_t *p_start_time, uint32_t interval);

/**
 * @brief        看门狗使能
 * @param        [in] state 使能(ENABLE=1)  禁能(DISABLE=0)
 * @retval        0 成功
 * @retval        <0 失败  
 */
int32_t sdk_wdt_enable(uint8_t state);

/**
 * @brief          喂狗
 * @return        执行结果
 * @retval        0 成功
 * @retval        <0 失败  
 */
int32_t sdk_wdt_feed(void);

/**
 * @brief        系统复位
 */
void sdk_sys_reset(void);


#endif
