#ifndef __HAL_EEPROM_H__
#define __HAL_EEPROM_H__

#include "hal_types.h"
#include "hal_errors.h"




#endif
