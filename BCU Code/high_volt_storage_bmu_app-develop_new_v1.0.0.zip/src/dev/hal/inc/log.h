#ifndef __LOG_H__
#define __LOG_H__

#if 1
// 旧版core包含的头文件
#include "hal_types.h"
#include "hal_errors.h"
#else
// 新版core包含的头文件
#include"data_types.h"
#endif
#include "rtdef.h"
#include "hal_rtc.h"
#include "time.h"

#define LOG_TIME_LEN           19
#define LOG_STR_OFFSET_LEN     (LOG_TIME_LEN + 3)


typedef enum{
	LOG_LEVEL_DISABLE,                          ///< 关闭调试
	LOG_LEVEL_ASSERT,                           ///< 表明出现了不合理数据，导致系统卡死
	LOG_LEVEL_ERROR,                            ///< 表明出现了系统错误和异常，无法正常完成目标操作。
	LOG_LEVEL_WARN,                             ///< 表明系统出现轻微的不合理但不影响运行和使用；
	LOG_LEVEL_INFO,                             ///< 用于打印程序应该出现的正常状态信息， 便于追踪定位
	LOG_LEVEL_DEBUG,                            ///< 级别最低，可以随意的使用于任何觉得有利于在调试时更详细的了解系统运行状态的东东
}log_level_e;

struct log_frame
{
    /* magic word is 0x10 ('lo') */
    rt_uint32_t magic:8;
    rt_uint32_t is_raw:1;
    rt_uint32_t log_len:23;
    rt_uint32_t level;
    const char *log;
    const char *tag;
};
typedef struct log_frame *log_frame_t;

enum
{
	LOWPOWERRST = 0,
	WWDGRST = 1,
	IWDGRST = 2,
	SOFTRST = 3,
	POWERRST = 4,
	PINRST = 5,
	MMURST = 6,
};



/**
* @brief		log打印及存储
* @param		[in] log_level log打印以及存储等级
* @param		[in] p_buf 打印或存储外部缓冲区地址，若该地址为空，会在内部创建一个缓冲区
* @param		[in] buf_size 缓冲区大小
* @param		[in] p_format 可变长入参
* @pre			需先执行log_init和log_enable后执行才有效 
*/
//int32_t log_write(uint8_t log_level, uint8_t* p_buf, int32_t buf_size, const char *p_format, ...);


/**
* @brief		强制log存储
* @warning      该函数带延时阻塞，只允许在复位或进休眠关机前调用
*/
void log_force_storage(void);

/**
* @brief		硬件中断log存储
* @warning      只允许在硬件中断调用
*/
//void log_hard_fault(void);

/**
* @brief		获取log运行状态
* @return       
* -# LOG_IDLE
* -# LOG_INIT
* -# LOG_RUN
* -# LOG_ERR
*/
uint8_t log_state_get(void);


/**
* @brief		获取log错误状态
* @return       
* -# LOG_ERR_NONE
* -# LOG_INT_ERR
* -# LOG_STORAGE_ERR
*/
uint8_t log_err_get(void);


/**
* @brief		设置log运行状态
* @param		[out] sta 设置的log状态
* -# LOG_INIT 重启log任务（只有前状态是LOG_IDLE时，触发有效）
*/
void log_state_set(uint8_t sta);


/**
* @brief		log任务
* @pre			创建log任务
*/
void log_thread(void *argv);


/**
* @brief		抢占log资源
* @return       == -1 log资源被占用
* @return       == 0  log资源抢占成功
*/
int32_t log_start(void);


/**
* @brief		log删除
* @return       == -1 删除失败
* @return       >= 0 删除成功
* @pre			调用log_start抢占到log资源后使用，使用完成后调用log_end释放log资源
*/
int32_t log_delete(void);


/**
* @brief		释放log资源
*/
void log_end(void);


/**
* @brief		设置log级别 
* @param		[in] log_type log等级类型
* -# 0 log打印等级
* -# 1 log存储等级
* @param		[in] log_level LOG级别
* -# LOG_LEVEL_DISABLE 关闭调试
* -# LOG_LEVEL_ASSERT 表明出现了不合理数据，导致系统卡死
* -# LOG_LEVEL_ERROR 表明出现了系统错误和异常，无法正常完成目标操作。
* -# LOG_LEVEL_WARN 表明系统出现轻微的不合理但不影响运行和使用；
* -# LOG_LEVEL_INFO 用于打印程序应该出现的正常状态信息， 便于追踪定位
* -# LOG_LEVEL_DEBUG 级别最低，可以随意的使用于任何觉得有利于在调试时更详细的了解系统运行状态的东东  
*/
void log_level_set(uint8_t log_type, uint8_t log_level);


/**
* @brief		获取log级别 
* @param		[in] log_type log等级类型
* -# 0 log打印等级
* -# 1 log存储等级
* @return       < 0 非法log类型
* @return       >= 0
* -# LOG_LEVEL_DISABLE 关闭调试
* -# LOG_LEVEL_ASSERT 表明出现了不合理数据，导致系统卡死
* -# LOG_LEVEL_ERROR 表明出现了系统错误和异常，无法正常完成目标操作。
* -# LOG_LEVEL_WARN 表明系统出现轻微的不合理但不影响运行和使用；
* -# LOG_LEVEL_INFO 用于打印程序应该出现的正常状态信息， 便于追踪定位
* -# LOG_LEVEL_DEBUG 级别最低，可以随意的使用于任何觉得有利于在调试时更详细的了解系统运行状态的东东  
*/
int32_t log_level_get(uint8_t log_type);


/**
* @brief		输出十六进信息
* @param		[in] name log显示的标识符 
* @param		[in] width 一行显示多少个字符 
* @param		[in] buf 缓冲区指针
* @param		[in] size 缓冲区大小
* @pre			需先执行log_init和log_enable后执行才有效 
*/
void log_hexdump(const char *name, uint8_t width, uint8_t *buf, uint16_t size);


/**
 * output the log
 *
 * @param level level
 * @param tag tag
 * @param newline has newline
 * @param format output format
 * @param ... args
 */
void log_output(rt_uint32_t level, const char *tag, rt_bool_t newline, const char *format, ...);

///< CORE使用的打印以及log存储接口
#define log_a(...)  log_output(LOG_LEVEL_ASSERT, NULL, RT_FALSE, __VA_ARGS__)
#define log_e(...)  log_output(LOG_LEVEL_ERROR, NULL,RT_FALSE, __VA_ARGS__) 
#define log_w(...)  log_output(LOG_LEVEL_WARN, NULL, RT_FALSE, __VA_ARGS__)   
#define log_i(...)  log_output(LOG_LEVEL_INFO, NULL, RT_FALSE, __VA_ARGS__)  
#define log_d(...)  log_output(LOG_LEVEL_DEBUG, NULL, RT_FALSE, __VA_ARGS__)

//#define log_a(...)  rt_kprintf(__VA_ARGS__)
//#define log_e(...)  rt_kprintf(__VA_ARGS__)
//#define log_w(...)  rt_kprintf(__VA_ARGS__)
//#define log_i(...)  rt_kprintf(__VA_ARGS__) 
//#define log_d(...)  rt_kprintf(__VA_ARGS__)
#endif
