#ifndef __AFE_MANAGEMENT_H__
#define __AFE_MANAGEMENT_H__

#include <stdint.h>

/**
  * @enum afe_collect_t
  * @brief afe采集数据
  */
typedef struct
{
    uint16_t  cell_volt[16];    ///< 单节电芯电压  
    uint16_t  cell_temp[4];     ///< 电芯温度
    uint16_t  balance_temp[2];  ///< 均衡温度温度
    uint32_t  batttery_volt;    ///< 电池电压
}afe_collect_t;


/**
  * @enum afe_state_e
  * @brief afe管理状态
  */
typedef enum
{
    AFE_IDIE_STATE,             ///< 空闲状态跑空，等待用户启用afe
    AFE_WAKEUP_STATE,           ///< 唤醒afe
    AFE_PER_INIT_STATE,         ///< 配置uart   
    AFE_INIT_STATE,             ///< 初始化afe，初始化成功后进入RUN状态  
    AFE_PRE_RUN_STATE,          ///< 进入运行状态前的预处理
    AFE_RUN_STATE,              ///< 进行数据采集，均衡，afe异常检测，以及状态切换等
    AFE_PRE_SHUTDOWN_STATE,     ///< 进入关机状态前的预处理
    AFE_SHUTDOWN_STATE,         ///< afe关机状态
    AFE_ERR_STATE,              ///< afe异常状态，afe异常后的数据处理
}afe_state_e;
    

/**
  * @enum afe_abnormal_e
  * @brief afe异常
  */

typedef enum
{
    AFE_ERR_NONE = 0,               ///< 无异常
    AFE_ERR_UART_INIT,          ///< uart初始化异常       
    AFE_ERR_CONFIG,             ///< afe初始化异常                   
    AFE_ERR_COMMUNICATION ,     ///< 运行过程中通讯异常            
}afe_abnormal_e;



#ifndef SDK_API_INTERFACE_ENABLE	///< SDK接口对外声明是否打开


/**
* @brief		
* @param		 
* @return		无
* @retval		无
* @warning		无 
*/
int32_t hal_afe_init(void);


/**
* @brief		获取采集数据
* @param		[out]外部afe数据结构体指针  
* @return		无
* @retval		无
* @warning		无 
*/
void hal_afe_collect_data_get(afe_collect_t *data); 


/**
* @brief		设置均衡
* @param		[out]均衡状态,每1bit代表单节电芯的启用与否，1->启用，0->禁用（顺序按小端模式）
* @return		无
* @retval		无
* @warning		无 
*/
void hal_afe_balance_set(uint32_t enable_flag);


/**
* @brief		获取均衡状态
* @param		[out]外部afe均衡状态指针  
* @return		无
* @retval		无
* @warning		无 
*/
void hal_afe_balance_state_get(uint32_t *state);


/**
* @brief		设置afe状态
* @param		[in]将要设置的状态
* @return		无
* @retval		无
* @warning		无 
*/
void hal_afe_state_set(afe_state_e state); 


/**
* @brief		获取当前afe状态
* @param		[out]外部afe状态指针  
* @return		无
* @retval		无
* @warning		无 
*/
void hal_afe_state_get(afe_state_e *state);


/**
* @brief		判断afe是否异常
* @param		无  
* @return		afe异常标志位
* @retval		HAL_OK(0) 无异常
* @retval		HAL_EIO(<0) 异常 
* @warning		无 
*/
afe_abnormal_e hal_afe_abnormal_state_get(void);

uint16_t* hal_cell_temp_res_val_get(void);


/**
* @brief		afe休眠唤醒
* @retval		HAL_OK(0) 无异常
* @retval		HAL_EIO(<0) 异常 
* @warning		无 
*/
void hal_afe_resume(void);


/**
* @brief		afe休眠挂起
* @retval		HAL_OK(0) 无异常
* @retval		HAL_EIO(<0) 异常 
* @warning		无 
*/
void hal_afe_suspend(void);



void afe_thread(void *argv);

#endif
#endif
