#ifndef __HAL_PM_H__
#define __HAL_PM_H__

#include "hal_types.h"
#include "hal_errors.h"


/**
  * @brief 运行模式。
  */
enum
{
    HAL_PM_ENTER_SLEEP = 0,    ///< 进入休眠模式 
    HAL_PM_EXIT_SLEEP,         ///< 退出休眠模式 
};


/**
* @brief		电源管理模块加载驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_pm_init(void);

/**
* @brief		电源管理模块删除驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_pm_deinit(void);

/**
* @brief		设置运行模式
* @param		[in] run_mode 运行模式
* -# HAL_PM_ENTER_SLEEP = 进入休眠模式
* -# HAL_PM_EXIT_SLEEP = 退出休眠模式
* @pre			执行hal_pm_init后执行才有效。
*/
int32_t hal_pm_run_enter(uint8_t run_mode);




#endif
