#ifndef __HAL_UART_H__
#define __HAL_UART_H__


#include "hal_types.h"
#include "hal_errors.h"

/* 波特率 */
#define HAL_B2400    			2400
#define HAL_B4800    			4800
#define HAL_B9600    			9600
#define HAL_B19200   			19200
#define HAL_B38400   			38400
#define HAL_B57600   			57600
#define HAL_B115200  			115200
#define HAL_B230400  			230400
#define HAL_B460800  			460800
#define HAL_B921600  			921600
#define HAL_B1000000 			1000000
#define HAL_B1152000 			1152000

/* 数据位 */
#define HAL_UART_8B             8
#define HAL_UART_9B             9


/* 校验位 */
#define HAL_UART_PARNON         0
#define HAL_UART_PARODD         1
#define HAL_UART_PAREVEN        2

/* 停止位 */
#define HAL_UART_STOP1B         0
#define HAL_UART_STOP2B         1


#define HAL_UART_HWFLOW_ON      1			///< 硬件流控开
#define HAL_UART_HWFLOW_OFF     0			///< 硬件流控关

#define	HAL_UART_RB_BUFFSIZE	128

/* 默认串口配置*/
#define HAL_UART_CONFIG_DEFAULT           			\
{                                          			\
    HAL_B115200,		 		/* 115200 bits/s */ \
    HAL_UART_8B,      			/* 8 databits */    \
    HAL_UART_STOP1B,      		/* 1 stopbit */     \
    HAL_UART_PARNON,      		/* No parity  */    \
	HAL_UART_HWFLOW_OFF,		/* 硬件流控关 */	    	\
	HAL_UART_RB_BUFFSIZE,		/* BUFF缓冲区 */	    \
}

/**
  * @enum hal_uart_index_t
  * @brief UART索引编号
  */
typedef enum
{
    HAL_UART1    = 0,  
    HAL_UART2,     
	HAL_UART3,
	HAL_UART4,
	HAL_UART5,
	HAL_UART6,
	HAL_UART7,
	HAL_UART_MAX,
}hal_uart_index_e;

/**
* @struct 串口属性
* @brief 配置串口各种属性
*/
typedef struct
{
    uint32_t baud;      ///< 波特率             
    uint32_t size;      ///< 数据位         
    uint32_t stop;      ///< 停止位
    uint32_t par;       ///< 校验位
    uint32_t flow;      ///< 流控
	uint32_t buffsize;	///< 缓冲区
}hal_uart_conf_t;


/* 串口回调函数定义 */
typedef void(*irq_uart_callback)(uint32_t port, uint32_t size);

/******************** hal_uart Api ***********************/
/**
* @brief		串口加载驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_uart_init(void);

/**
* @brief		串口删除驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_uart_deinit(void);

/**
* @brief		打开串口功能 
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @默认参数
* - p_conf->baud	波特率（默认115200）
* - p_conf->size	数据位（默认8）
* - p_conf->stop	停止位（默认1）
* - p_conf->par;   	校验位（默认0）   
* - p_conf->flow;  	硬件流控（默认0）
* - p_conf->buffsize;	缓冲区/字节（默认128K）
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		<0 失败原因  
* @pre			执行hal_uart_open后执行才有效。
* @warning		按照默认115200参数进行配置
*/
int32_t hal_uart_open(uint32_t port);

/**
* @brief		关闭串口功能 
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		<0 失败原因  
* @pre			执行hal_uart_init后执行才有效。
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_uart_close(uint32_t port);

/**
* @brief		串口功能从休眠中唤醒，恢复状态
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		HAL_EIO 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_uart_resume(uint32_t port);

/**
* @brief		串口功能进入休眠模式
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		HAL_EIO 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式，功能不影响
*/
int32_t hal_uart_suspend(uint32_t port);

/**
* @brief		设置串口属性 
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @param		[out] p_conf 参数配置指针
* - p_conf->baud	波特率（默认115200）范围：0    <baud <1152000
* - p_conf->size	数据位（默认8）5 6 7 8	
* - p_conf->stop	停止位（默认1）1 2
* - p_conf->par;   	校验位（默认0）0=无校验 1=          基校验 2偶校验    
* - p_conf->flow;  	硬件流控（默认0）0=硬件流控关 1=             硬件流控
* - p_conf->buffsize;	缓冲区/字节（默认128byte）
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		<0 失败原因  
* @pre			执行hal_uart_open后执行才有效。
* @warning		配置参数非法时，按照默认参数进行配置
*/
int32_t hal_uart_setup(uint32_t port, hal_uart_conf_t *p_conf);

/**
* @brief		清空收缓冲区数据  
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @return		执行结果
* @retval		HAL_OK 成功   
* @retval		<0 失败原因  
* @pre			执行hal_uart_open后执行才有效。
*/
int32_t hal_uart_flush(uint32_t port);

/**
* @brief		串口收数据 
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @param		[in] p_buf 缓冲区指针  
* @param		[in] len 缓冲区长度   
* @return		执行结果
* @retval		>=0 接收数据长度  
* @retval		<0 失败原因  
* @pre			执行hal_uart_open后执行才有效。
*/
int32_t hal_uart_read(uint32_t port,uint8_t *p_buf, int32_t len);

/**
* @brief		串口发数据 
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @param		[in] p_buf 缓冲区指针  
* @param		[in] len 缓冲区长度   
* @return		执行结果
* @retval		>=0 发送数据长度   
* @retval		<0 失败原因  
* @pre			执行hal_uart_open后执行才有效。
*/
int32_t hal_uart_write(uint32_t port,uint8_t *p_buf, int32_t len);

/**
* @brief		配置串口中断函数  
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @param		[in] p_tx_fcallback 发送中断回调(预留,暂不支持)  
* @param		[in] p_rx_fcallback 接收中断回调    
* @return		执行结果
* @retval		HAL_OK 成功     
* @retval		HAL_EIO 失败   
* @pre			执行hal_uart_open后执行才有效。
* @warning 		不使用的外部中断可以直接填写NULL 
*/
int32_t hal_uart_set_irq(uint32_t port, irq_uart_callback p_tx_fcallback, irq_uart_callback p_rx_fcallback);

/**
* @brief		关闭串口中断
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @return		执行结果
* @retval		HAL_OK 成功     
* @retval		HAL_EIO 失败   
* @pre			执行hal_uart_open后执行才有效。
*/
int32_t hal_uart_free_irq(uint32_t port);

/**
* @brief		扩展功能（预留）
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @param		[in] cmd 控制命令  
* @param		[in] p_arg 控制参数   
* @return		执行结果
* @retval		HAL_OK 成功    
* @retval		<0 失败原因  
*/
int32_t hal_uart_ioctl(uint32_t port, uint8_t cmd, void* p_arg);




#endif
