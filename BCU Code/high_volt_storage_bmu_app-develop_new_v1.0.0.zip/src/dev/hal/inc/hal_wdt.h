#ifndef __HAL_WDT_H__
#define __HAL_WDT_H__

#include "hal_types.h"
#include "hal_errors.h"


/**
* @brief		看门狗加载驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		<0 失败 
*/
int32_t hal_wdt_init(void);


/**
* @brief		看门狗删除驱动(预留)
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		<0 失败 
*/
int32_t hal_wdt_deinit(void);


/**
* @brief		打开看门狗
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		<0 失败   
* @pre			执行hal_wdt_init后执行才有效。默认5s
*/
int32_t hal_wdt_open(void);



/**
* @brief		关闭看门狗  
* @return		执行结果
* @retval		0 成功  
* @retval		<0 失败   
* @pre			看门狗打开后就关闭不了，需等到复位。
*/
int32_t hal_wdt_close(void);

 

/**
* @brief		设置超时时间
* @param		[in] timeout_s 超时时间，秒为单位 不超过26
* @return		执行结果
* @retval		0 成功  
* @retval		<0 失败   
* @pre			init、open成功后执行才有效
*/
int32_t hal_wdt_set(uint32_t timeout_s);



/**
* @brief		获取超时时间
* @param		[out] *p_timeout 超时时间，秒为单位 
* @return		执行结果
* @retval		0 成功  
* @retval		<0 失败   
* @pre			init、open成功后执行才有效
*/
int32_t hal_wdt_get_timeout(uint32_t *p_timeout);


/**
* @brief		喂狗  
* @return		执行结果
* @retval		0 成功  
* @retval		<0 失败 
* @pre			init、open成功后执行才有效
*/
int32_t hal_wdt_feed(void);



#endif
