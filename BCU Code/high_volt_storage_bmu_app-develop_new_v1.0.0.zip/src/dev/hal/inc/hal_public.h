#ifndef __HAL_PUBLIC_H__
#define __HAL_PUBLIC_H__

#include "hal_types.h"
#include "hal_errors.h"
#include "stdbool.h"

//#define RT_USING_FINSH_DEBUG

#define TICK_1MS        os_tick_from_millisecond(1)
#define TICK_2MS        os_tick_from_millisecond(2)
#define TICK_3MS        os_tick_from_millisecond(3)
#define TICK_4MS        os_tick_from_millisecond(4)
#define TICK_5MS        os_tick_from_millisecond(5)
#define TICK_10MS       os_tick_from_millisecond(10)
#define TICK_20MS       os_tick_from_millisecond(20)
#define TICK_30MS       os_tick_from_millisecond(30)
#define TICK_40MS       os_tick_from_millisecond(40)
#define TICK_50MS       os_tick_from_millisecond(50)
#define TICK_100MS      os_tick_from_millisecond(100)
#define TICK_200MS      os_tick_from_millisecond(200)
#define TICK_300MS      os_tick_from_millisecond(300)
#define TICK_400MS      os_tick_from_millisecond(400)
#define TICK_500MS      os_tick_from_millisecond(500)
#define TICK_1S         os_tick_from_millisecond(1000)


/**
 * @brief		延时us
 * @param		[in] 需要延时的us数, <1000us
 */
void hal_delay_us(uint32_t us);
    
/**
* @brief		使能总中断
* @param		[in] level 关闭中断前的状态,参数保留未使用
* @return		无 
*/
inline void hal_enable_interrupt(int32_t level);
	
/**
* @brief		关闭总中断
* @return		中断状态
*/
inline int32_t hal_disable_interrupt(void);

/**
* @brief		获取当前tick
* @return		当前tick值
*/
uint32_t hal_tick_get(void);

/**
* @brief		判断是否时间tick超时
* @param		[in] start_tick 启动计时的tick  
* @param		[in] interval 中间间隔
* @return		是否超时 
* @retval		true 已超时
* @retval		false 未超时
*/
bool hal_is_tick_over(uint32_t start_tick, uint32_t interval);

/**
* @brief		系统复位
* @return		void
*/
void hal_system_reset(void);



#endif
