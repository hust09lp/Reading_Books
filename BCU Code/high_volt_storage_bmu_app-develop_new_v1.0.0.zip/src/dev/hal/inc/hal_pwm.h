#ifndef __HAL_PWM_H__
#define __HAL_PWM_H__

#include "hal_types.h"
#include "hal_errors.h"


/**
  * @enum  hal_pwm_tim_index_t
  * @brief PWM定时器索引编号
  */
typedef enum
{
    HAL_PWM_TIM1    = 0,  
    HAL_PWM_TIM2,
    HAL_PWM_TIM3,  
    HAL_PWM_TIM4,  
    HAL_PWM_TIM5,    
    HAL_PWM_TIM8,  
	HAL_PWM_TIM_MAX,
}hal_pwm_tim_index_e;

/**
  * @enum  hal_pwm_ch_index_t
  * @brief PWM定时器通道
  */
typedef enum
{
    HAL_PWM_CH1    = 1,  
    HAL_PWM_CH2,
    HAL_PWM_CH3,  
    HAL_PWM_CH4,  
	HAL_PWM_CH_MAX,
}hal_pwm_ch_e;


/**
  * @struct hal_pwm_config_t
  * @brief PWM属性配置。
  */
typedef struct {
    uint32_t duty_percent;    ///< PWM占空比 1-100对应1%-100%
    uint32_t period_ticks;    ///< PWM周期 ns
    uint32_t polarity;        ///< 空闲时的引脚状态
}hal_pwm_config_t;


/**
* @brief		PWM加载驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_pwm_init(void);


/**
* @brief		PWM删除驱动(预留)
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_pwm_deinit(void);


/**
* @brief		启动PWM通道  
* @param		[in] pwm_tim_no pwm定时器索引编号
* -# HAL_PWM_TIM1 - 0x00  
* -# HAL_PWM_TIM2 - 0x01
* -# HAL_PWM_TIM3 - 0x02  
* -# HAL_PWM_TIM4 - 0x03  
* -# HAL_PWM_TIM5 - 0x04    
* -# HAL_PWM_TIM8 - 0x05
* @param		[in] chan pwm通道编号
* -# HAL_PWM_CH1 - 0x00  
* -# HAL_PWM_CH2 - 0x01
* -# HAL_PWM_CH3 - 0x02  
* -# HAL_PWM_CH4 - 0x03
* @return		执行结果
* @retval		HAL_OK（0） 成功  
* @retval		HAL_EIO（<0） 失败   
*/
int32_t hal_pwm_start(uint32_t pwm_tim_no, uint32_t chan);


/**
* @brief		停止PWM通道 
* @param		[in] pwm_tim_no pwm定时器索引编号
* -# HAL_PWM_TIM1 - 0x00  
* -# HAL_PWM_TIM2 - 0x01
* -# HAL_PWM_TIM3 - 0x02  
* -# HAL_PWM_TIM4 - 0x03  
* -# HAL_PWM_TIM5 - 0x04    
* -# HAL_PWM_TIM8 - 0x05
* @param		[in] chan pwm通道编号
* -# HAL_PWM_CH1 - 0x00  
* -# HAL_PWM_CH2 - 0x01
* -# HAL_PWM_CH3 - 0x02  
* -# HAL_PWM_CH4 - 0x03
* @return		执行结果
* @retval		HAL_OK（0） 成功  
* @retval		HAL_EIO（<0） 失败   
*/
int32_t hal_pwm_stop(uint32_t pwm_tim_no, uint32_t chan);


/**
* @brief		设置PWM参数   
* @param		[in] pwm_tim_no pwm定时器索引编号
* -# HAL_PWM_TIM1 - 0x00  
* -# HAL_PWM_TIM2 - 0x01
* -# HAL_PWM_TIM3 - 0x02  
* -# HAL_PWM_TIM4 - 0x03  
* -# HAL_PWM_TIM5 - 0x04    
* -# HAL_PWM_TIM8 - 0x05
* @param		[in] chan pwm  通道编号
* -# HAL_PWM_CH1 - 0x00  
* -# HAL_PWM_CH2 - 0x01
* -# HAL_PWM_CH3 - 0x02  
* -# HAL_PWM_CH4 - 0x03
* @param		[in] p_cfg pwm配置结构体
* -# p_cfg->duty_percent - PWM占空比 1-100对应1%-100%  
* -# p_cfg->period_ticks - PWM周期 ns
* -# p_cfg->polarity - 空闲时的引脚状态
* @return		执行结果
* @retval		HAL_OK（0） 成功  
* @retval		HAL_EIO（<0） 失败   
*/
int32_t hal_pwm_config(uint32_t pwm_tim_no, uint32_t chan,hal_pwm_config_t *p_cfg);


/**
* @brief		PWM功能从休眠中唤醒，恢复状态
* @param		[in] pwm_tim_no pwm定时器索引编号
* -# HAL_PWM_TIM1 - 0x00  
* -# HAL_PWM_TIM2 - 0x01
* -# HAL_PWM_TIM3 - 0x02  
* -# HAL_PWM_TIM4 - 0x03  
* -# HAL_PWM_TIM5 - 0x04    
* -# HAL_PWM_TIM8 - 0x05
* @param		[in] chan pwm通道编号
* -# HAL_PWM_CH1 - 0x00  
* -# HAL_PWM_CH2 - 0x01
* -# HAL_PWM_CH3 - 0x02  
* -# HAL_PWM_CH4 - 0x03
* @return		执行结果
* @retval		HAL_OK（0） 成功  
* @retval		HAL_EIO（<0） 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_pwm_resume(uint32_t pwm_tim_no, uint32_t chan);

 
/**
* @brief		PWM功能进入休眠模式
* @param		[in] pwm_tim_no pwm定时器索引编号
* -# HAL_PWM_TIM1 - 0x00  
* -# HAL_PWM_TIM2 - 0x01
* -# HAL_PWM_TIM3 - 0x02  
* -# HAL_PWM_TIM4 - 0x03  
* -# HAL_PWM_TIM5 - 0x04    
* -# HAL_PWM_TIM8 - 0x05
* @param		[in] chan pwm通道编号
* -# HAL_PWM_CH1 - 0x00  
* -# HAL_PWM_CH2 - 0x01
* -# HAL_PWM_CH3 - 0x02  
* -# HAL_PWM_CH4 - 0x03
* @return		执行结果
* @retval		HAL_OK（0） 成功  
* @retval		HAL_EIO（<0） 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式，功能不影响
*/
int32_t hal_pwm_suspend(uint32_t pwm_tim_no, uint32_t chan);


/**
* @brief		扩展功能(预留)
* @param		[in] pwm_tim_no pwm定时器索引编号
* -# HAL_PWM_TIM1 - 0x00  
* -# HAL_PWM_TIM2 - 0x01
* -# HAL_PWM_TIM3 - 0x02  
* -# HAL_PWM_TIM4 - 0x03  
* -# HAL_PWM_TIM5 - 0x04    
* -# HAL_PWM_TIM8 - 0x05
* @param		[in] chan pwm通道编号
* -# HAL_PWM_CH1 - 0x00  
* -# HAL_PWM_CH2 - 0x01
* -# HAL_PWM_CH3 - 0x02  
* -# HAL_PWM_CH4 - 0x03
* @param		[in] cmd 控制命令  
* @param		[in] arg 控制参数   
* @return		执行结果
* @retval		HAL_OK 成功    
* @retval		<0 失败原因  
*/
int32_t hal_pwm_ioctl(uint32_t pwm_tim_no, uint32_t chan, uint8_t cmd, void* p_arg);



#endif
