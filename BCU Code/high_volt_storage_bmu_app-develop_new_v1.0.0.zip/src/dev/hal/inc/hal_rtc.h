#ifndef __HAL_RTC_H__
#define __HAL_RTC_H__

#include <time.h>
#include "hal_types.h"
#include "hal_errors.h"

#define HAL_WRITE_BKP_DAT1_DATA 	0xA5A5

#define HAL_RTC_FORMAT_BIN        	((uint32_t)0x000000000)
#define HAL_RTC_FORMAT_BCD        	((uint32_t)0x000000001)
#define HAL_IS_RTC_FORMAT(FORMAT)   (((FORMAT) == HAL_RTC_FORMAT_BIN) || ((FORMAT) == HAL_RTC_FORMAT_BCD))



#define HAL_ALARM_ONESHOT       	0x000  ///< only alarm onece 
#define HAL_ALARM_DAILY         	0x100  ///< alarm everyday
#define HAL_ALARM_WEEKLY        	0x200  ///< alarm weekly at Monday or Friday etc. 
#define HAL_ALARM_MONTHLY       	0x400  ///< alarm monthly at someday 
#define HAL_ALARM_YAERLY        	0x800  ///< alarm yearly at a certain date 
#define HAL_ALARM_HOUR          	0x1000 ///< alarm each hour at a certain min:second 
#define HAL_ALARM_MINUTE        	0x2000 ///< alarm each minute at a certain second 
#define HAL_ALARM_SECOND        	0x4000 ///< alarm each second 

typedef enum {
    HAL_RTC_CLK_SRC_HSE128			= 0x01,
    HAL_RTC_CLK_SRC_LSE				= 0x02,
    HAL_RTC_CLK_SRC_LSI				= 0x03,
}hal_rtc_clk_src_type_e;


typedef struct rt_alarm *hal_alarm_t;

/**
  * @struct hal_rtc_time_t
  * @brief RTC时间。
  */
typedef struct  {
    uint8_t  tm_sec;     ///<  秒 	0-59
    uint8_t  tm_min;     ///<  分钟	0-59 
    uint8_t  tm_hour;    ///<  小时 1-12
    uint8_t  tm_weekday; ///<  星期	1-7
    uint8_t  tm_day;     ///<  日 	1-31
    uint8_t  tm_mon;     ///<  月 	1-12
    uint8_t  tm_year;    ///<  年 范围00-99
}hal_rtc_t;



typedef struct  {
    uint32_t  flag;                /* alarm flag */
    hal_rtc_t wktime;              /* when will the alarm wake up user */
}hal_alarm_setup_t;


typedef void (*hal_alarm_callback_t)(hal_alarm_t alarm, time_t timestamp);


/**
* @brief		RTC加载驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_rtc_init(void);


/**
* @brief		RTC删除驱动(预留)
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_rtc_deinit(void);


/**
* @brief		设置RTC时间 
* @param		[in] rtc_format 时间格式:BCD/HEX
				[in] p_time rtc时间结构体    
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		HAL_EIO 失败   
* @pre			执行hal_rtc_init后执行才有效。
*/
int32_t hal_rtc_set(uint32_t rtc_format, hal_rtc_t *p_time);


/**
* @brief		读取RTC时间 
* @param		[in] rtc_format 时间格式:BCD/HEX
				[out] p_time rtc时间结构体   
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		HAL_EIO 失败   
* @pre			执行hal_rtc_init后执行才有效。
*/
int32_t hal_rtc_get(uint32_t rtc_format, hal_rtc_t *p_time);

/**
* @brief		读取RTC时间戳
* @param		[in] void
* @return		执行结果
* @retval		>=0 自1970年的秒数 
* @retval		-1 失败   
* @pre			执行hal_rtc_init后执行才有效。
*/
uint32_t hal_rtc_timestamp_get(void);


/**
* @brief		扩展功能(预留) 
* @param		[in] dev_no 设备端口号  
* @param		[in] cmd 控制命令  
* @param		[in] arg 控制参数   
* @return		执行结果
* @retval		HAL_OK 成功    
* @retval		<0 失败原因  
*/
int32_t hal_rtc_ioctl(int32_t dev_no, uint8_t cmd, void* p_arg);

#endif
