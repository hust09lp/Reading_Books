#ifndef __HAL_ADC_H__
#define __HAL_ADC_H__

#include <rtconfig.h>
#include "hal_types.h"
#include "hal_errors.h"

/**
  * @enum  hal_adc_dma_map_index_t
  * @brief ADC DMA数据表索引定义
  */
typedef enum
{
  ADC_IDX_IDC_VER = 0,   	        	    ///< 硬件版本识别
  ADC_IDX_24V_SAM,     					    ///< 供电电源24V采集
  ADC_IDX_5V_SAM,				            ///< 系统5V电源采集
  ADC_IDX_PCB_TEMP,						    ///< PCB温度采集
  ADC_IDX_FLAM_GAS_DECT,                	///<可燃气体检测
  ADC_IDX_5VA_SAM,				            ///< 5V电源输出采样
  ADC_IDX_MAX,
}hal_adc_dma_map_index_e;

/**
  * @enum  hal_adc_index_t
  * @brief ADC索引编号
  */
typedef enum
{
	HAL_ADC1 = 0, 							///< ADC1对应索引号
	HAL_ADC2, 								///< ADC2对应索引号
	HAL_ADC_MAX,
}hal_adc_index_e;


/**
  * @enum	hal_adc_sample_cycles_t
  * @brief  ADC采样周期
  */
typedef enum
{
	HAL_ADC_SAMP_TIME_1CYCLES5   	= 0x00,	///< 1.5周期
	HAL_ADC_SAMP_TIME_7CYCLES5,				///< 7.5周期
	HAL_ADC_SAMP_TIME_13CYCLES5,			///< 13.5周期
	HAL_ADC_SAMP_TIME_28CYCLES5,			///< 28.5周期
	HAL_ADC_SAMP_TIME_41CYCLES5,			///< 41.5周期
	HAL_ADC_SAMP_TIME_55CYCLES5,			///< 55.5周期
	HAL_ADC_SAMP_TIME_71CYCLES5,			///< 71.5周期
	HAL_ADC_SAMP_TIME_239CYCLES5,			///< 239.5周期	
}hal_adc_sample_cycles_e;


/**
  * @enum   hal_adc_sample_time_t
  * @brief  ADC转换模式
  */
typedef enum
{
	HAL_ADC_CONV_ONE_TIME_MODE   	= 0x00, ///< 单次采样
	HAL_ADC_CONV_CONTINUOUS_MODE,			///< 连续采样
}hal_adc_convert_mode_e;


/**
  * @enum   hal_adc_config_t
  * @brief  ADC配置属性
  */
typedef struct 
{
	uint32_t sampling_cycle;  				///< 采样频率
	uint32_t convert_mode;					///< 转换模式
} hal_adc_config_t;




/**
  * @enum  irq_adc_callback
  * @brief ADC中断回调函数定义
  */
typedef void(*irq_adc_callback)(uint32_t adc_no, uint32_t channel, uint32_t adc);


/**
* @brief		ADC加载驱动,根据配置加载对应的ADC驱动
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @warning		上电或系统初始化时调用一次
*/
int32_t hal_adc_init(void);

/**
* @brief		ADC删除驱动(跟据配置删除对应的驱动)
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
*/
int32_t hal_adc_deinit(void);

/**
* @brief		打开ADC 
* @param		[in] adc_no ADC虚拟编号
* -# HAL_ADC1 - 0x00
* -# HAL_ADC2 - 0x01
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @pre			执行hal_adc_init后执行才有效。
*/
int32_t hal_adc_open(uint32_t adc_no);


/**
* @brief		关闭ADC 
* @param		[in] adc_no ADC虚拟编号
* -# HAL_ADC1 - 0x00
* -# HAL_ADC2 - 0x01
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			执行hal_adc_init后执行才有效。
*/
int32_t hal_adc_close(uint32_t adc_no);


/**
* @brief		ADC功能从休眠中唤醒，恢复状态
* @param		[in] adc_no ADC虚拟编号
* -# HAL_ADC1 - 0x00
* -# HAL_ADC2 - 0x01
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @warning		本接口调用后，需要把对应管脚恢复到正常状态 
*/
int32_t hal_adc_resume(uint32_t adc_no);
 
/**
* @brief		ADC功能进入休眠模式
* @param		[in] adc_no ADC虚拟编号
* -# HAL_ADC1 - 0x00
* -# HAL_ADC2 - 0x01
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式，功能不影响
*/
int32_t hal_adc_suspend(uint32_t adc_no);


/**
* @brief		启动ADC(预留)
* @param		[in] adc_no ADC虚拟编号
* -# HAL_ADC1 - 0x00
* -# HAL_ADC2 - 0x01
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @pre			执行hal_adc_enable后执行才有效。
*/
int32_t hal_adc_start(uint32_t adc_no);


/**
* @brief		停止ADC(预留)
* @param		[in] adc_no ADC虚拟编号
* -# HAL_ADC1 - 0x00
* -# HAL_ADC2 - 0x01
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			接口未使用，默认返回HAL_OK
*/
int32_t hal_adc_stop(uint32_t adc_no);
 

/**
* @brief		设置ADC属性(预留)
* @param		[in] adc_no ADC虚拟编号
* -# HAL_ADC1 - 0x00
* -# HAL_ADC2 - 0x01
* @param		[in] p_cfg 配置属性指针
* -# p_cfg->sampling_cycle 采样频率	
* -# p_cfg->convert_mode 转换模式
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			接口未使用，默认返回HAL_OK
*/
int32_t hal_adc_setup(uint32_t adc_no, hal_adc_config_t *p_cfg);


/**
* @brief		读取ADC通道数据
* @param		[in] channel
* -# ADC_IDX_DSG_OFFSET_VOLT = 0 ///< 放电偏置电压  
* -# ADC_IDX_MOS_TEMP 		= 1   	///< Mos温度检测 需提供NTC表
* -# ADC_IDX_DSG_MAX_CURR  	= 2		///< 放电电流
* -# ADC_IDX_FILM_TEMP 		= 3		///< 加热膜温度
* -# ADC_IDX_TOTAL_VOLT 	= 4		///< 总压采样
* -# ADC_IDX_VOLT_P 		= 5		///< P+ 端口电压
* -# ADC_IDX_PCB_TEMP 		= 6		///< PCB温度采集	
* -# ADC_IDX_12V_VOLT 		= 7  	///< SIG_12V用途,BMS运行过程中自检
* -# ADC_IDX_VOLT_G 		= 8		///< P- 端口电压
* -# ADC_IDX_CHG_MAX_CURR 	= 9		///< 充电电流采集
* -# ADC_IDX_DSG_MIN_CURR   = 10    ///< 放电小电流检测
* -# ADC_IDX_CHG_MIN_CURR   = 11    ///< 充电小电流检测
* -# ADC_IDX_HW_VER 		= 11	///< 硬件版本号
* @param		[out] *p_value 读取的adc数据 
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败
* @pre			执行hal_adc_start后执行才有效。
*/
int32_t hal_adc_read(uint32_t channel, uint16_t *p_value);

/**
* @brief		ADC中断回调函数    
* @param		[in] adc_no ADC虚拟编号
* -# HAL_ADC1 - 0x00
* -# HAL_ADC2 - 0x01
* @param		[in] p_callback 回调函数  
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			接口未使用，默认返回HAL_OK
*/
int32_t hal_adc_set_irq(uint32_t adc_no, irq_adc_callback p_fcallback);

/**
* @brief		扩展功能(预留)
* @param		[in] adc_no ADC虚拟编号
* -# HAL_ADC1 - 0x00
* -# HAL_ADC2 - 0x01
* @param		[in] cmd 控制命令  
* @param		[in] arg 控制参数   
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @pre			接口未使用，默认返回HAL_OK
*/
int32_t hal_adc_ioctl(uint32_t adc_no, uint8_t cmd, void* p_arg);

/**
* @brief		adc滤波
* @return		void
*/
void hal_adc_filter_task(void);

#endif
