#ifndef __HAL_H__
#define __HAL_H__


/**
* @file 头文件
* @author chenenzhi
* @data 2021/6/12。
* <table>
* <tr><th>大版本号  <th>中版本号	<th>小版本号</tr>
* <tr><td>一般当软件整体重写，或出现不向后兼容的改变时，增加此版本号
  <td>当功能更新，出现新功能时增加
  <td>小修改，如修复bug，只要有修改就增加本版本号<td>
* </tr>
* </table>
*/

#include "hal_types.h"
#include "hal_errors.h"
#include "hal_i2c.h"
#include "hal_timer.h"
#include "hal_spi.h"
#include "hal_wdt.h"
#include "hal_uart.h"
#include "hal_rtc.h"
#include "hal_pwm.h"
#include "hal_pm.h"
#include "hal_flash.h"
#include "hal_gpio.h"
#include "hal_adc.h"
#include "hal_eeprom.h"
#include "hal_can.h"
#include "hal_public.h"
#include "hal_misc.h"


/**
* 大版本号
*/
#define HAL_D_VERSION		1		///< 当API的兼容性变化时，需递增。
/**
* 中版本号
*/
#define HAL_M_VERSION		0		///< 当增加功能时(不影响API 的兼容性)，需递增。
/**
* 小版本号
*/
#define HAL_S_VERSION		1		///< 当做Bug修复时(不影响API 的兼容性)，需递增。

#define HAL_VERSION_INFO            "V1.0.1"


#endif
