#ifndef __HAL_TYPES_H__
#define __HAL_TYPES_H__


/********************************************************************/
typedef unsigned char   uint8_t;
typedef unsigned short  uint16_t;
typedef unsigned int    uint32_t;
typedef signed char   	int8_t;
typedef signed short  	int16_t;
typedef signed int    	int32_t;


enum {SF_DISABLE = 0, SF_ENABLE = !SF_DISABLE};


#define  SF_MAX( x, y ) ( ((x) > (y)) ? (x) : (y) ) 

#define  SF_MIN( x, y ) ( ((x) < (y)) ? (x) : (y) ) 

// 得到一个field在结构体(struct)中的偏移量 
#define ST_VAR_POS( type, field ) ( (uint32_t) &(( type *) 0)-> field )

// 得到一个结构体中field所占用的字节数 
#define ST_VAR_SIZE( type, field )  sizeof( ((type *) 0)->field) 


#define SET_BIT(REG, BIT)     ((REG) |= (BIT))

#define CLEAR_BIT(REG, BIT)   ((REG) &= ~(BIT))

#define READ_BIT(REG, BIT)    ((REG) & (BIT))

#ifndef SET_BIT
#define SET_BIT(a,b)	((a) |= (b)) 		
#endif

#ifndef CLR_BIT
#define CLR_BIT(a,b)	((a) &= ~(b)) 
#endif

#ifndef GET_BIT
#define GET_BIT(a,b)	((a) & (b))
#endif


#define ITEM_NUM(items) (sizeof(items) / sizeof(items[0]))


typedef void(*irq_callback)(void);



#endif
