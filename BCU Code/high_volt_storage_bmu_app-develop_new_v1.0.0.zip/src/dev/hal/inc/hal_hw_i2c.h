#ifndef __HAL_HW_I2C_H__
#define __HAL_HW_I2C_H__

#include "data_types.h"
#include "rtconfig.h"


typedef enum
{
	I2C_100K_BAUD   = 100000, /* 100 kBit/sec */
    I2C_200K_BAUD   = 200000, /* 200 kBit/sec */
    I2C_300K_BAUD   = 300000, /* 300 kBit/sec */
    I2C_400K_BAUD   = 400000, /* 400 kBit/sec */
}hal_hw_i2c_baud;

typedef enum
{
    REG_ADDR_ONE_BYTE = 1,
    REG_ADDR_TWO_BYTE = 2,
}hal_hw_i2c_reg_len;

int32_t hal_hw_i2c_open(uint32_t i2c_no);
int32_t hal_hw_i2c_close(uint32_t i2c_no);
int32_t hal_hw_i2c_write(uint32_t i2c_no, uint16_t dev_addr, uint16_t reg_addr, uint8_t reg_len, uint8_t *buf, uint32_t buf_len);
int32_t hal_hw_i2c_read(uint32_t i2c_no, uint16_t dev_addr, uint16_t reg_addr, uint8_t reg_len, uint8_t *buf, uint32_t buf_len);



#endif
