#ifndef __HAL_FLASH_H__
#define __HAL_FLASH_H__

#include "hal_errors.h"
#include "hal_types.h"

/**
 * @struct hal_pwm_config_t
 * @brief flash信息。
 */
typedef struct {
    uint32_t total_size;  ///< Total flash size
    uint32_t page_size;   ///< Write (page) size
    uint32_t sector_size; ///< Erase (sector) size
} hal_flash_info_t;

/**
 * @struct
 * @brief FLASH类型。
 */
enum {
    HAL_FLASH_ID_INT = 0, ///< 内部flash
    HAL_FLASH_ID_EXT = 1, ///< 外部flash
    HAL_FLASH_ID_EXT2 = 2, ///< 外部flash
};

#define W25Q128_SECTOR_SIZE 4096
#define W25Q128_MAP0_ADDR 0
#define W25Q128_MAP0_SECTOR_NUM 3584 // 总大小: 4k * 3584 = 14M byte
#define W25Q128_MAP1_ADDR (W25Q128_SECTOR_SIZE * 3584)
#define W25Q128_MAP1_SECTOR_NUM 512 // 总大小: 4k * 512 = 2M byte

/******************** hal_flash Api ***********************/

/**
* @brief		FLASH加载驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_flash_init(void);

/**
* @brief		FLASH删除驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_flash_deinit(void);

/**
* @brief		获取flash信息 
* @param		[in] dev_no 设备端口号 
-# HAL_FLASH_ID_INT = 内部Flash 
-# HAL_FLASH_ID_EXT = 外部Flash  
* @param		[in] info flash信息结构体  
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		HAL_EIO 失败   
*/
int32_t hal_flash_get_info(uint32_t dev_no, hal_flash_info_t *info);

/**
* @brief		获取flash唯一ID  
* @param		[in] dev_no 设备端口号  
-# HAL_FLASH_ID_INT = 内部Flash 
-# HAL_FLASH_ID_EXT = 外部Flash  
* @param		[in] id 存储buffer   
* @param		[in] len buffer深度   
* @return		执行结果
* @retval		>=0 读取id长度  
* @retval		<0 失败原因  
*/
int32_t hal_flash_get_sn(uint32_t dev_no, uint8_t *id, uint32_t len);

/**
* @brief		写数据
* @param		[in] dev_no 设备端口号  
-# HAL_FLASH_ID_INT = 内部Flash 
-# HAL_FLASH_ID_EXT = 外部Flash  
* @param		[in] offset flash地址偏移   
* @param		[in] len buffer深度   
* @param		[in] buf 写入数据缓冲区  
* @return		执行结果
* @retval		>=0 读取id长度  
* @retval		<0 失败原因  
*/
int32_t hal_flash_write(uint32_t dev_no, uint32_t offset, uint32_t len, uint8_t *buf);

/**
* @brief		读数据
* @param		[in] dev_no 设备端口号 
-# HAL_FLASH_ID_INT = 内部Flash 
-# HAL_FLASH_ID_EXT = 外部Flash  
* @param		[in] offset flash地址偏移   
* @param		[in] len buffer深度   
* @param		[in] buf 写入数据缓冲区  
* @return		执行结果
* @retval		>=0 读取长度  
* @retval		<0 失败原因  
*/
int32_t hal_flash_read(uint32_t dev_no, uint32_t offset, uint32_t len, uint8_t *buf);

/**
* @brief		擦除 
* @param		[in] dev_no 设备端口号  
-# HAL_FLASH_ID_INT = 内部Flash 
-# HAL_FLASH_ID_EXT = 外部Flash  
* @param		[in] offset flash地址偏移    
* @param		[in] len buffer深度   
* @return		执行结果
* @retval		>=0 读取id长度  
* @retval		<0 失败原因  
*/
int32_t hal_flash_erase(uint32_t dev_no, uint32_t offset, uint32_t len);

/**
* @brief		扩展功能 
* @param		[in] dev_no 设备端口号  
* @param		[in] cmd 控制命令  
* @param		[in] arg 控制参数   
* @return		执行结果
* @retval		HAL_OK 成功    
* @retval		<0 失败原因  
*/
int32_t hal_flash_ioctl(int32_t dev_no, uint8_t cmd, void *arg);

#endif
