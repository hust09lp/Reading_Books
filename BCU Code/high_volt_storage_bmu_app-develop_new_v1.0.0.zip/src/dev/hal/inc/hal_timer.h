#ifndef __HAL_TIMER_H__
#define __HAL_TIMER_H__

#include "hal_types.h"
#include "hal_errors.h"
#include "n32g45x_tim.h"
#include "n32g45x.h"
/**
  * @enum  hal_pwm_tim_index_t
  * @brief PWM定时器索引编号
  */
typedef enum
{
    HAL_HW_TIMER1    = 0,  
    HAL_HW_TIMER2,
    HAL_HW_TIMER3,  
    HAL_HW_TIMER4,  
    HAL_HW_TIMER5,    
	HAL_HW_TIMER_MAX,
}hal_hw_timer_index_e;


typedef struct hal_hwtimer
{
    uint8_t         tim_no;
    TIM_Module     *tim_handle;
    IRQn_Type       tim_irqn;
    uint32_t        clk;
} hal_hwtimer_t;


/**
  * @enum 定时类型
  * @details 只能选择其中一个
  */
enum
{
    HAL_TIMER_ONSHOT = 1,		///< 触发一次中断
    HAL_TIMER_PERIODIC = 2,		///< 触发周期性中断
};

/**
  * @enum 定时模式
  * @details 只能选择其中一个
  */
enum
{
    HAL_TIMER_MODE_TIMER = 0,	///< 定时器
    HAL_TIMER_MODE_COUNTER = 1,	///< 计数器
};

typedef struct hal_timer_interval
{
    int32_t sec;      /* 秒 s */
    int32_t usec;     /* 微秒 us */
} hal_timerval_t;

typedef int32_t (*timer_callback)(uint32_t adc_no, uint32_t size);


/******************** hal_rtc Api ***********************/


/**
* @brief		定时器加载驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_timer_init(void);


/**
* @brief		打开定时器  
* @param		[in] tim_no 虚拟timer编号
* -# timer1 - 0x00  
* -# timer2 - 0x01
* -# timer3 - 0x02  
* -# timer4 - 0x03  
* -# timer5 - 0x04    
* -# timer6 - 0x05
* -# timer7 - 0x06  
* -# timer8 - 0x07    
* @param		[in] mode 使用模式 暂未使用
* -# HAL_TIMER_MODE_TIMER = 定时器模式
* -# HAL_TIMER_MODE_COUNTER = 计数器模式 
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		HAL_EIO 失败   
* @pre			执行hal_timer_init后执行才有效。
*/
int32_t hal_timer_open(uint32_t tim_no, uint32_t mode);


/**
* @brief		关闭定时器  
* @param		[in] tim_no 虚拟timer编号
* -# timer1 - 0x00  
* -# timer2 - 0x01
* -# timer3 - 0x02  
* -# timer4 - 0x03  
* -# timer5 - 0x04    
* -# timer6 - 0x05
* -# timer7 - 0x06  
* -# timer8 - 0x07    
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		HAL_EIO 失败   
* @pre			执行hal_timer_init后执行才有效。
*/
int32_t hal_timer_close(uint32_t tim_no);


/**
* @brief		设置定时器并启动
* @param		[in] tim_no 虚拟timer编号
* -# timer1 - 0x00  
* -# timer2 - 0x01
* -# timer3 - 0x02  
* -# timer4 - 0x03  
* -# timer5 - 0x04    
* -# timer6 - 0x05
* -# timer7 - 0x06  
* -# timer8 - 0x07    
* @param		[in] type 定时类型  
* -# HAL_TIMER_ONSHOT = 只产生一次中断
* -# HAL_TIMER_PERIODIC = 重复产生周期性中断
* @param		[in] p_timeout 定时器周期 
* @param		[in] p_fcallback 定时器中断回掉函数  
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		HAL_EIO 失败   
* @pre			执行hal_timer_init后执行才有效。
*/
int32_t hal_timer_setup(uint32_t tim_no, uint32_t type, hal_timerval_t *p_timeout, timer_callback p_fcallback);



#endif
