/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2015-07-29     Arda.Fu      first implementation
 */
#include <stdint.h>
#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>
#include "osif.h"
#include "hal.h"
#include "sdk_log.h"
#include "log.h"
#include "sdk_led.h"
#include "sdk_pm.h"
#include "main.h"
#include "n32g45x_STLparam.h"
#include "n32g45x_STLlib.h"
#include "app_thread.h"
#include "sdk_fs.h"

void cpu_reset_flag_save(void)
{
	int32_t temp = -1;
	
	temp = get_cpu_reset_flag();
	
	switch(temp)
	{
		case LOWPOWERRST:
			log_i("cpu reset by LOWPOWER\n");
			break;
		case WWDGRST:
			log_i("cpu reset by WWDG\n");
			break;
		case IWDGRST:
			log_i("cpu reset by IWDG\n");
			break;
		case SOFTRST:
			log_i("cpu reset by SOFTWARE\n");
			break;
		case POWERRST:
			log_i("cpu reset by POWER\n");
			break;
		case PINRST:
			log_i("cpu reset by PIN\n");
			break;
		case MMURST:
			log_i("cpu reset by MMU\n");
			break;
		default:
			break;
	}		
}

int start_app_task(void);
int main(void)
{    
    sdk_led_init();
    sdk_led_flash(0, 300, 50, -1);

    hal_wdt_open();
    hal_wdt_set(5); 
	// 启动adc采样
#ifdef BSP_USING_ADC1
    hal_adc_open(0);
#endif
#ifdef BSP_USING_ADC2
    hal_adc_open(1);
#endif

    os_kernel_init();	/* os内核初始化 */
    os_kernel_start();	/* os内核启动 */
    os_delay(TICK_100MS);
    
    cpu_reset_flag_save();
    /* 启动app程序运行任务 勿删除，否则app无法运行 */
    app_main();
    selftest_run_init();
//	DBG_ConfigPeriph(DBG_STOP, ENABLE);
    while (1)
    {
        hal_adc_filter_task();
    
        sdk_led_scan();
        low_power_thread();
        selftest_run_check();
        
        os_delay(TICK_10MS);
    }
}




