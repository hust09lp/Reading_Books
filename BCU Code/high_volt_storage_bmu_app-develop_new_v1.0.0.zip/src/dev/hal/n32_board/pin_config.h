#ifndef __PIN_CONFIG_H__
#define __PIN_CONFIG_H__

#include "hal_can.h"



/**
 * @brief  GPIO Pin Name
 * 
 */
#define PA_PIN    \
        PA0 = 0, PA1, PA2, PA3, PA4, PA5, PA6, PA7, PA8, PA9, PA10, PA11, PA12, PA13, PA14, PA15 
#define PB_PIN    \
        PB0, PB1, PB2, PB3, PB4, PB5, PB6, PB7, PB8, PB9, PB10, PB11, PB12, PB13, PB14, PB15

#define PC_PIN    \
        PC0, PC1, PC2, PC3, PC4, PC5, PC6, PC7, PC8, PC9, PC10, PC11, PC12, PC13, PC14, PC15
        
#define PD_PIN    \
        PD0, PD1, PD2, PD3, PD4, PD5, PD6, PD7, PD8, PD9, PD10, PD11, PD12, PD13, PD14, PD15 
        
typedef enum
{
    PA_PIN,
    PB_PIN,
    PC_PIN,
    PD_PIN,
    MAX_PIN
}pin_name_e;

#define PIN_NUM(port, no) 		(((((port) & 0xFu) << 4) | ((no) & 0xFu)))
#define PIN_PORT(pin) 			((uint8_t)(((pin) >> 4) & 0xFu))
#define PIN_NO(pin) 			((uint8_t)((pin) & 0xFu))

#define PIN_STPIN(pin) 			((uint16_t)(1u << PIN_NO(pin)))
#define PIN_STPORT(pin) 		((GPIO_Module *)(GPIOA_BASE + (0x400u * PIN_PORT(pin))))

/******************************* DEV DEVICES PIN CONFIG *************************************/
/* EEPROM I2C引脚定义 */
#define I2C_MAX               1

#define I2C2_ID                          0      //EEPROM I2C
#define M24128_I2C2_SCL_PIN        	PB10
#define M24128_I2C2_SDA_PIN        	PB11
#define M24128_I2C2_WP_PIN         	MAX_PIN


/* SPI功能相关PIN引脚定义 */
#define SPI_MAX               3

#define SPI1_ID               		0 // 菊花链SPI
#define SPI1_CLK_PIN                PA5      
#define SPI1_MISO_PIN               PA6       
#define SPI1_MOSI_PIN               PA7      
#define SPI1_CS_PIN                 PA4  

#define SPI2_ID               		1 // SPI2
#define SPI2_CLK_PIN                MAX_PIN      
#define SPI2_MISO_PIN               MAX_PIN       
#define SPI2_MOSI_PIN               MAX_PIN      
#define SPI2_CS_PIN                 MAX_PIN 

#define SPI3_ID               		2 // FLASH SPI
#define SPI3_CLK_PIN                PB3      
#define SPI3_MISO_PIN               PB4       
#define SPI3_MOSI_PIN               PB5      
#define FLASH_CS_PIN                PB6      
#define FLASH_WP_PIN                PB7    
#define FLASH_HOLD_PIN              PD2     



/* FDCAN功能相关PIN引脚定义 */
#define CAN_MAX_NUM					2

#define FDCAN1_ID					0 // BMU内部通信
#define FDCAN1_RX_PIN               PA11       
#define FDCAN1_TX_PIN               PA12   

#define FDCAN2_ID					1 // 可燃气体传感器通信
#define FDCAN2_RX_PIN               PB12      
#define FDCAN2_TX_PIN               PB13   


/* UART功能相关PIN引脚定义 */
#define UART_MAX_NUM				1

#define UART1_ID					0 // 调试串口
#define UART1_TX_PIN            	PA9     
#define UART1_RX_PIN            	PA10
	
// #define UART3_ID    				1 // 232
// #define UART3_TX_PIN            	PD8        
// #define UART3_RX_PIN            	PD9
      

/******************************* SDK LIBRARY PIN CONFIG *************************************/

/* LED功能相关PIN引脚定义 */
#define LED_ID_NUM                  1

#define LED_1_PIN                   PB9           //   单板指示灯 
#define LED_2_PIN                   MAX_PIN           //   
#define LED_3_PIN                   MAX_PIN           //   
#define LED_4_PIN                   MAX_PIN           // 
#define LED_5_PIN                   MAX_PIN           // 
#define LED_6_PIN                   MAX_PIN           // 
#define LED_7_PIN                   MAX_PIN           // 
#define LED_8_PIN                   MAX_PIN           // 
#define LED_9_PIN                   MAX_PIN           // 

/* KEY功能相关PIN引脚定义 */
#define KEY_ID_NUM                  0

#define KEY_1_PIN                   MAX_PIN          // 按键 


/* BUZZER功能相关PIN引脚定义 */
#define BUZZ_ID_NUM                 0

#define BUZZ_1_PIN                  MAX_PIN           				// 蜂鸣器 

/* 外部看门狗功能相关PIN引脚定义 */
#define EXT_WDI_ID_NUM                 1

#define EXT_WDI_1_PIN                  PB1           // 外部看门狗 

#if PACK_64S_PRJ

/* DI功能相关PIN引脚定义 */
#define DI_ID_NUM                   5

#define DI_NULL                     MAX_PIN         
#define DI_1_PIN                    PA8                 //   簇内编址IO1	
#define DI_2_PIN                    PA15                 //   簇内编址IO2
#define DI_3_PIN                    PC12                //   DI输入检测信号
#define DI_4_PIN                    PC4                 //  菊花链BQ_FAULT
#define DI_5_PIN                    PC5                 //  菊花链BQ_RDY
#define DI_6_PIN                    MAX_PIN             
#define DI_7_PIN                    MAX_PIN             
#define DI_8_PIN                    MAX_PIN             
#define DI_9_PIN                    MAX_PIN  
#define DI_10_PIN                   MAX_PIN  
#define DI_11_PIN                   MAX_PIN             
#define DI_12_PIN                   MAX_PIN         
#define DI_13_PIN                   MAX_PIN         
#define DI_14_PIN                   MAX_PIN         
#define DI_15_PIN                   MAX_PIN         
#define DI_16_PIN                   MAX_PIN         

/* DO功能相关PIN引脚定义 */
#define DO_ID_NUM                   5

#define DO_NULL                     MAX_PIN   
#define DO_1_PIN                    PA8                 //   簇内编址IO1
#define DO_2_PIN                    PA15                 //   簇内编址IO2
#define DO_3_PIN                    MAX_PIN                 //   5V电源输出控制（不需要了）
#define DO_4_PIN                    PC10                //   DO输出控制信号      
#define DO_5_PIN                    PA4         //   菊花链NSS脚
#define DO_6_PIN                    MAX_PIN      
#define DO_7_PIN                    MAX_PIN      
#define DO_8_PIN                    MAX_PIN      
#define DO_9_PIN                    MAX_PIN      
#define DO_10_PIN                   MAX_PIN      
#define DO_11_PIN                   MAX_PIN      
#define DO_12_PIN                   MAX_PIN      
#define DO_13_PIN                   MAX_PIN      
#define DO_14_PIN                   MAX_PIN      
#define DO_15_PIN                   MAX_PIN      
#define DO_16_PIN                   MAX_PIN      
#define DO_17_PIN                   MAX_PIN      
#define DO_18_PIN                   MAX_PIN      

/* 需要进行输入、输出切换的引脚 */
#define IO_CONVERT_NUM                           2

#define IO_CONVERT_NULL                     MAX_PIN
#define IO_CONVERT_1_PIN                    PA8                 //   簇内编址IO1
#define IO_CONVERT_2_PIN                    PA15                 //   簇内编址IO2
#define IO_CONVERT_3_PIN                    MAX_PIN                 //   
#define IO_CONVERT_4_PIN                    MAX_PIN                 //   
#define IO_CONVERT_5_PIN                    MAX_PIN                 //  

#else 

/* DI功能相关PIN引脚定义 */
#define DI_ID_NUM                   5

#define DI_NULL                     MAX_PIN         
#define DI_1_PIN                    PC8                 //   簇内编址IO1	
#define DI_2_PIN                    PC9                 //   簇内编址IO2
#define DI_3_PIN                    PC12                //   DI输入检测信号
#define DI_4_PIN                    PC4                 //  菊花链BQ_FAULT
#define DI_5_PIN                    PC5                 //  菊花链BQ_RDY
#define DI_6_PIN                    MAX_PIN             
#define DI_7_PIN                    MAX_PIN             
#define DI_8_PIN                    MAX_PIN             
#define DI_9_PIN                    MAX_PIN  
#define DI_10_PIN                   MAX_PIN  
#define DI_11_PIN                   MAX_PIN             
#define DI_12_PIN                   MAX_PIN         
#define DI_13_PIN                   MAX_PIN         
#define DI_14_PIN                   MAX_PIN         
#define DI_15_PIN                   MAX_PIN         
#define DI_16_PIN                   MAX_PIN         

/* DO功能相关PIN引脚定义 */
#define DO_ID_NUM                   5

#define DO_NULL                     MAX_PIN   
#define DO_1_PIN                    PC8                 //   簇内编址IO1
#define DO_2_PIN                    PC9                 //   簇内编址IO2
#define DO_3_PIN                    PA8                 //   5V电源输出控制
#define DO_4_PIN                    PA15                //   DO输出控制信号      
#define DO_5_PIN                    PA4         //   菊花链NSS脚
#define DO_6_PIN                    MAX_PIN      
#define DO_7_PIN                    MAX_PIN      
#define DO_8_PIN                    MAX_PIN      
#define DO_9_PIN                    MAX_PIN      
#define DO_10_PIN                   MAX_PIN      
#define DO_11_PIN                   MAX_PIN      
#define DO_12_PIN                   MAX_PIN      
#define DO_13_PIN                   MAX_PIN      
#define DO_14_PIN                   MAX_PIN      
#define DO_15_PIN                   MAX_PIN      
#define DO_16_PIN                   MAX_PIN      
#define DO_17_PIN                   MAX_PIN      
#define DO_18_PIN                   MAX_PIN      

/* 需要进行输入、输出切换的引脚 */
#define IO_CONVERT_NUM                           2

#define IO_CONVERT_NULL                     MAX_PIN
#define IO_CONVERT_1_PIN                    PC8                 //   簇内编址IO1
#define IO_CONVERT_2_PIN                    PC9                 //   簇内编址IO2
#define IO_CONVERT_3_PIN                    MAX_PIN                 //   
#define IO_CONVERT_4_PIN                    MAX_PIN                 //   
#define IO_CONVERT_5_PIN                    MAX_PIN                 //  

#endif

/* NC(空贴或未使用)PIN引脚定义 */
#define NC_PIN_NUM                  0

#define NC_NULL                     MAX_PIN   
#define NC_1_PIN                    MAX_PIN	
#define NC_2_PIN                    MAX_PIN 
#define NC_3_PIN                    MAX_PIN          	
#define NC_4_PIN                    MAX_PIN          
#define NC_5_PIN                    MAX_PIN   
#define NC_6_PIN                    MAX_PIN
#define NC_7_PIN                    MAX_PIN	          	
#define NC_8_PIN                    MAX_PIN
#define NC_9_PIN                    MAX_PIN	          	
#define NC_10_PIN                   MAX_PIN	          	
#define NC_11_PIN                   MAX_PIN	          	
#define NC_12_PIN                   MAX_PIN	    
 

#endif  // __PIN_CONFIG_H__

