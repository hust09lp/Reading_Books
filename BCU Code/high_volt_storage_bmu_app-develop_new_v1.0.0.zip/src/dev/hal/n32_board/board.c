/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2018-11-06     balanceTWK   first version
 */

#include <stdint.h>
#include <rthw.h>
#include <rtthread.h>

#include <board.h>
#include <drv_clk.h>

#ifdef BSP_USING_SRAM
    #include "drv_sram.h"
#endif

#include "main.h"
#include "n32g45x.h"
#include <stdio.h>
#include "hal.h"

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
void Error_Handler(void)
{
    /* USER CODE BEGIN Error_Handler */
    /* User can add his own implementation to report the HAL error return state */
    while (1)
    {
		__NVIC_SystemReset();
    }
    /* USER CODE END Error_Handler */
}

/** System Clock Configuration
*/
void SystemClock_Config(void)
{
    SysTick_Config(SystemCoreClock / RT_TICK_PER_SECOND);
    NVIC_SetPriority(SysTick_IRQn, 0);
}



/**
 * This is the timer interrupt service routine.
 *
 */
extern uint8_t g_runtime_check_init_flag;
void SysTick_Handler(void)
{
    /* enter interrupt */
    rt_interrupt_enter();

    rt_tick_increase();

    /* leave interrupt */
    rt_interrupt_leave();
    
    selftest_run_ram_check();
  
}



void nvic_Vector_Set(void)
{
    /* NVIC Configuration */
#define NVIC_VTOR_MASK              0x3FFFFF80
#ifdef  VECT_TAB_RAM
    /* Set the Vector Table base location at 0x10000000 */
    SCB->VTOR  = (0x10000000 & NVIC_VTOR_MASK);
#else  /* VECT_TAB_FLASH  */
    /* Set the Vector Table base location at 0x08000000 */
    SCB->VTOR  = (N32_FLASH_CORE_START_ADRESS & NVIC_VTOR_MASK);
#endif
}

/**
 * This function will initial N32 board.
 */
void rt_hw_board_init(void)
{
    nvic_Vector_Set();
    SystemClock_Config();

//#ifdef RT_USING_PIN
//    int n32_hw_pin_init(void);
//    n32_hw_pin_init();

//#endif
    cpu_reset_flag_set();
    n32_msp_jtag_init(RT_NULL);
    
#ifdef RT_USING_SERIAL
    int rt_hw_usart_init(void);
    rt_hw_usart_init();
#endif

#ifdef RT_USING_COMPONENTS_INIT
    rt_components_board_init();
#endif

#if defined(RT_USING_CONSOLE) && defined(RT_USING_DEVICE)
    rt_console_set_device(RT_CONSOLE_DEVICE_NAME);
#endif

#ifdef BSP_USING_SRAM
    rt_system_heap_init((void *)EXT_SRAM_BEGIN, (void *)EXT_SRAM_END);
#else
    rt_system_heap_init((void *)HEAP_BEGIN, (void *)HEAP_END);
#endif
}
