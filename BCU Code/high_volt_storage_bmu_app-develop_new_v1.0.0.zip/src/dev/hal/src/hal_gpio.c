#include <board.h>
#include <stdlib.h>
#include <rtthread.h>
#include <rtdevice.h>
#include "hal_gpio.h"
#include "string.h"
#include "log.h"



typedef struct 
{
    hal_gpio_config_t	conf;			//gpio配置参数
	uint8_t				value;			//gpio值
}gpio_conf_t;


typedef struct
{
	uint32_t			pin_index;		///< pin索引
	int16_t   			gpio_pin;		///< gpio PIN脚
	const char	   		*name;			///< gpio名称
	gpio_conf_t			sleep_conf;		///< gpio休眠配置
}board_gpio_tab_t;

struct pin_irq_t
{
	IRQn_Type irqno;
	irq_callback cb;
};

static  struct pin_irq_t pin_irq_map[] =
{
    {EXTI0_IRQn,(void*)(0)},//0
    {EXTI1_IRQn,(void*)(0)},
    {EXTI2_IRQn,(void*)(0)},
    {EXTI3_IRQn,(void*)(0)},
    {EXTI4_IRQn,(void*)(0)},
    {EXTI9_5_IRQn,(void*)(0)},
    {EXTI9_5_IRQn,(void*)(0)},
    {EXTI9_5_IRQn,(void*)(0)},
    {EXTI9_5_IRQn,(void*)(0)},
    {EXTI9_5_IRQn,(void*)(0)},
    {EXTI15_10_IRQn,(void*)(0)},
    {EXTI15_10_IRQn,(void*)(0)},
    {EXTI15_10_IRQn,(void*)(0)},
    {EXTI15_10_IRQn,(void*)(0)},
    {EXTI15_10_IRQn,(void*)(0)},
    {EXTI15_10_IRQn,(void*)(0)},

};



	
/**
* @brief         GPIO加载驱动
* @return        执行结果
* @retval          HAL_OK 成功
* @retval          HAL_EIO 失败
*/
int32_t hal_gpio_init(void)
{
//    hal_gpio_config_t gpio_config = {HAL_GPIO_OUTPUT, HAL_GPIO_NOPULL};
    
    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOA, ENABLE);
    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE);
    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOC, ENABLE);
    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOD, ENABLE);

//    hal_gpio_config(PB0, &gpio_config);      //TO DO 临时使用，后续要删除
//    hal_gpio_config(PB15, &gpio_config);  
//    hal_gpio_config(PC8, &gpio_config);
//    
//    hal_gpio_write(PB0, HAL_GPIO_LOW);        // 打开3.3V电源控制
//    hal_gpio_write(PB0, HAL_GPIO_LOW);        // 打开MOS驱动12V受控
//    hal_gpio_write(PC8, HAL_GPIO_LOW); // 打开休眠控制

    return HAL_OK;
}
INIT_DEVICE_EXPORT(hal_gpio_init);


/**
* @brief         GPIO删除驱动(预留)
* @return        执行结果
* @retval          HAL_OK 成功
* @retval          HAL_EIO 失败
*/
int32_t hal_gpio_deinit(void)
{
    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOA, DISABLE);
    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, DISABLE);
    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOC, DISABLE);
    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOD, DISABLE);
    
    return HAL_OK;
}


/**
* @brief        打开管脚功能(预留)
* @param        [in] gpio_index gpio索引号，详见hal_pin_index_e
* @return       执行结果
* @retval         HAL_OK 成功
* @retval         HAL_EIO 失败
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_open(int32_t gpio_index)
{
    return HAL_OK;
}


/**
* @brief        关闭管脚功能(预留)
* @param        [in] gpio_index gpio索引号，详见hal_gpio_index_e
* @return       执行结果
* @retval         HAL_OK 成功
* @retval         HAL_EIO 失败
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_close(int32_t gpio_index)
{
    return HAL_OK;
}


/**
* @brief        GPIO功能从休眠中唤醒，恢复状态
* @param        [in] gpio_index gpio索引号，详见hal_pin_index_e
* @return       执行结果
* @retval         HAL_OK 成功
* @retval         HAL_EIO 失败
* @warning      本接口调用后，需要把单板对应管脚设置为低功耗模式
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_resume(int32_t gpio_index)
{

    return HAL_ENOENT;
}


/**
* @brief        GPIO功能进入休眠模式
* @param        [in] gpio_index gpio索引号，详见hal_pin_index_e
* @return       执行结果
* @retval         HAL_OK 成功
* @retval         HAL_EIO 失败
* @warning      本接口调用后，需要把对应管脚也设置为低功耗模式
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息*/
int32_t hal_gpio_suspend(int32_t gpio_index)
{
    return HAL_ENOENT;
}




/**
* @brief        配置管脚属性
* @param        [in] pin_id pin虚拟编号
* @param        [in] p_conf GPIO属性
* @return       执行结果
* @retval         HAL_OK 成功
* @retval         HAL_EIO 失败
* @pre          执行hal_gpio_open后执行才有效。
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_config(int32_t pin, hal_gpio_config_t *p_conf)
{
    GPIO_InitType GPIO_InitStruct;
    

	
    if(pin >= MAX_PIN)
    {
        return HAL_EPERM;
    }
    
    if(p_conf == NULL)
    {
        return HAL_EPERM;
    }    

    if((p_conf->pull == HAL_GPIO_PULLUP) && (p_conf->direction == HAL_GPIO_INPUT))
    {
        GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
    }
    else if((p_conf->pull == HAL_GPIO_PULLDOWN) && (p_conf->direction == HAL_GPIO_INPUT))
    {
        GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPD;
    }
    else if((p_conf->pull == HAL_GPIO_NOPULL) && (p_conf->direction == HAL_GPIO_INPUT))
    {
        GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    }
    else if(p_conf->direction == HAL_GPIO_OUTPUT_OD)
    {
        GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_OD;
    }
    else    
    {
        GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
    }
    
//    if(p_conf->speed == HAL_GPIO_SPEED_LOW)
//    {
//        GPIO_InitStruct.GPIO_Speed = GPIO_Speed_2MHz;
//    }
//    else if(p_conf->speed == HAL_GPIO_SPEED_LOW)
//    {
//        GPIO_InitStruct.GPIO_Speed = GPIO_Speed_10MHz;
//    }
//    else
    {
        GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    }
    
    GPIO_InitStruct.Pin = PIN_STPIN(pin);
    
    GPIO_InitPeripheral(PIN_STPORT(pin), &GPIO_InitStruct);
    
    
    return HAL_OK;
}

/**
* @brief        控制管脚翻转
* @param        [in] pin_id pin虚拟编号
* @return       执行结果
* @retval         HAL_OK 成功
* @retval         HAL_EIO 失败
* @pre          执行hal_gpio_open后执行才有效
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_toggle(int32_t pin_id)
{
	GPIO_Module *gpio_port;
    uint16_t gpio_pin;

	if (pin_id >= MAX_PIN)
    {
        return HAL_EPERM;
    }
    
    gpio_port = PIN_STPORT(pin_id);
    gpio_pin = PIN_STPIN(pin_id);

    
    gpio_port->POD ^= gpio_pin;
    
    return HAL_OK;
}



/**
* @brief        控制管脚输出值
* @param        [in] pin_id pin虚拟编号
* @param        [in] value
                   0 = 低电平
                   1 = 高电平
* @return       执行结果
* @retval         HAL_OK 成功
* @retval         HAL_EIO 失败
* @pre          执行hal_gpio_open后执行才有效
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_write(int32_t pin_id, int32_t value)
{
	GPIO_Module *gpio_port;
    uint16_t gpio_pin;

	if (pin_id >= MAX_PIN)
    {
        return HAL_EPERM;
    }

    gpio_port = PIN_STPORT(pin_id);
    gpio_pin = PIN_STPIN(pin_id);

    GPIO_WriteBit(gpio_port, gpio_pin, (Bit_OperateType)value);

    return HAL_OK;
}


/**
* @brief        读取管脚输入值
* @param        [in] pin_id pin虚拟编号
* @return       管脚状态
* @retval         0 = 输入低
* @retval         1 = 输入高
* @retval         HAL_EIO 失败，GPIO可能未打开
* @pre          执行hal_gpio_open后执行才有效
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_read(int32_t pin_id)
{
    GPIO_Module *gpio_port;
    uint16_t gpio_pin;
    uint8_t state;
	
	if (pin_id >= MAX_PIN)
    {
        return HAL_EPERM;
    }
	
    gpio_port = PIN_STPORT(pin_id);
    gpio_pin = PIN_STPIN(pin_id);
    state = GPIO_ReadInputDataBit(gpio_port, gpio_pin);
   

    return (state == Bit_RESET) ? 0 : 1;
}


/**
* @brief        控制管脚特殊属性的函数(预留)
* @param        [in] gpio_index gpio索引号，详见hal_pin_index_e
* @param        [in] cmd 命令
* @param        [in] param 参数
* @return       返回结果，根据实际命令调整
* @retval         0 = 输入低
* @retval         1 = 输入高
* @retval         HAL_EIO 失败，GPIO可能未打开
* @pre          执行hal_gpio_open后执行才有效。
* @remarks      用于未来控制使用
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_ioctl(int32_t gpio_index, int32_t cmd, int32_t param)
{
    log_d("not support!");
    return HAL_ENOENT;
}


/**
* @brief        配置管脚为外部中断功能和设置相关属性
* @param        [in] pin_id pin虚拟编号
* @param        [in] mode 属性
* @param        [in] p_fcallback 外部中断回调函数
* @param        [in] p_args 中断参数，无传入NULL
* @return       返回结果
* @retval         HAL_OK 成功
* @retval         HAL_EIO 失败
* @pre          执行hal_gpio_open后执行才有效。
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_set_irq(int32_t pin, hal_gpio_irq_e mode, gpio_irq_callback p_fcallback, void *p_args)
{
    GPIO_InitType GPIO_InitCtlStruct;
    EXTI_InitType EXTI_InitStructure;
    NVIC_InitType NVIC_InitStructure;
    
    struct pin_irq_t *irqmap;
	
	if (pin >= MAX_PIN)
    {
        return HAL_EPERM;
    }
    
    /* Configure GPIO_InitStructure */
    GPIO_InitStruct(&GPIO_InitCtlStruct);
    GPIO_InitCtlStruct.Pin = PIN_STPIN(pin);
    GPIO_InitCtlStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitCtlStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;   
    GPIO_InitPeripheral(PIN_STPORT(pin), &GPIO_InitCtlStruct);    
	/* 中断模式 */
    switch(mode)
    {
		/* 低电平中断 */
        case HAL_GPIO_IRQ_LOW:            
            break;
		/* 高电平中断 */
        case HAL_GPIO_IRQ_HIGH:           
			break;
		/* 下降沿中断 */
        case HAL_GPIO_IRQ_FALLING:        
			EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
            break;
		/* 上降沿中断 */
        case HAL_GPIO_IRQ_RISING:         
			EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
            break;
		/* 上升沿和下降沿中断 */
        case HAL_GPIO_IRQ_RISING_FALLING: 
			EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
            break;
		
        default : return HAL_ENXIO;
    }

    /*Configure key EXTI Line to key input Pin*/
    GPIO_ConfigEXTILine(PIN_PORT(pin), PIN_NO(pin));

    /*Configure key EXTI line*/
    EXTI_InitStructure.EXTI_Line    = PIN_STPIN(pin);   //刚好和line的定义一样
    EXTI_InitStructure.EXTI_Mode    = EXTI_Mode_Interrupt;
    
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_InitPeripheral(&EXTI_InitStructure);
	irqmap = &pin_irq_map[PIN_NO(pin)];
	irqmap->cb = p_fcallback;
    NVIC_InitStructure.NVIC_IRQChannel = irqmap->irqno;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x05;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority        = 0x0F;
    NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    return HAL_OK;
}

/**
* @brief        释放GPIO外部中断
* @param        [in] gpio_index gpio索引号，详见hal_pin_index_e
* @return       返回结果
* @retval         HAL_OK 成功
* @retval         HAL_EIO 失败
* @pre          执行hal_gpio_open后执行才有效。
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_free_irq(int32_t pin)
{
    NVIC_InitType NVIC_InitStructure;    
    struct pin_irq_t *irqmap;

    irqmap = &pin_irq_map[PIN_NO(pin)];
    NVIC_InitStructure.NVIC_IRQChannel = irqmap->irqno;
    NVIC_InitStructure.NVIC_IRQChannelCmd                = DISABLE;
    NVIC_Init(&NVIC_InitStructure);
    
    return HAL_OK;
}

void EXTI0_IRQHandler(void)
{
    /* enter interrupt */
    rt_interrupt_enter();
    pin_irq_map[0].cb();
    /* leave interrupt */
    rt_interrupt_leave();
}
void EXTI1_IRQHandler(void)
{
    /* enter interrupt */
    rt_interrupt_enter();
    pin_irq_map[1].cb();
    /* leave interrupt */
    rt_interrupt_leave();
}
void EXTI2_IRQHandler(void)
{
    /* enter interrupt */
    rt_interrupt_enter();
    pin_irq_map[2].cb();
    /* leave interrupt */
    rt_interrupt_leave();
}
void EXTI3_IRQHandler(void)
{
    /* enter interrupt */
    rt_interrupt_enter();
    pin_irq_map[3].cb();
    /* leave interrupt */
    rt_interrupt_leave();
}
void EXTI4_IRQHandler(void)
{
    /* enter interrupt */
    rt_interrupt_enter();
    pin_irq_map[4].cb();
    /* leave interrupt */
    rt_interrupt_leave();
}
void EXTI9_5_IRQHandler(void)
{
    /* enter interrupt */
    rt_interrupt_enter();
    if (EXTI_GetITStatus(EXTI_LINE5) != RESET)
    {
        pin_irq_map[5].cb();
    }
    if (EXTI_GetITStatus(EXTI_LINE6) != RESET)
    {
        pin_irq_map[6].cb();
    }
    if (EXTI_GetITStatus(EXTI_LINE7) != RESET)
    {
        pin_irq_map[7].cb();
    }
    if (EXTI_GetITStatus(EXTI_LINE8) != RESET)
    {
        pin_irq_map[8].cb();
    }
    if (EXTI_GetITStatus(EXTI_LINE9) != RESET)
    {
        pin_irq_map[9].cb();
    }
    /* leave interrupt */
    rt_interrupt_leave();
}
void EXTI15_10_IRQHandler(void)
{
    /* enter interrupt */
    rt_interrupt_enter();
    if (EXTI_GetITStatus(EXTI_LINE10) != RESET)
    {
        pin_irq_map[10].cb();
    }
    if (EXTI_GetITStatus(EXTI_LINE11) != RESET)
    {
        pin_irq_map[11].cb();
    }
    if (EXTI_GetITStatus(EXTI_LINE12) != RESET)
    {
        pin_irq_map[12].cb();
    }
    if (EXTI_GetITStatus(EXTI_LINE13) != RESET)
    {
        pin_irq_map[13].cb();
    }
    if (EXTI_GetITStatus(EXTI_LINE14) != RESET)
    {
        pin_irq_map[14].cb();
    }
    if (EXTI_GetITStatus(EXTI_LINE15) != RESET)
    {
        pin_irq_map[15].cb();
    }
    /* leave interrupt */
    rt_interrupt_leave();
}




/**
* @brief        GPIO_HAL功能样例
* @param        argv 功能参数
* @return       返回结果
* @retval         HAL_OK 成功
* @retval         HAL_EIO 失败
*/
#ifdef RT_USING_FINSH
#ifdef RT_USING_FINSH_DEBUG
#if defined(BSP_USING_GPIO)

/* gpio 测试样例 中断回调函数 */
static void gpio_callback_test(void *p_args)
{
    rt_kprintf("gpio irq\n");
}

/* gpio 测试样例 */
static int hal_gpio_sample(int argc, char *p_argv[])
{
	hal_gpio_config_t gpio_config;
	int32_t  pin_value;
	char 	*pin_opt  = p_argv[1];
	char 	*pin	  = p_argv[2];
	char 	*pin_args = p_argv[3];

	/* gpio写操作 */
	if (!rt_strcmp(pin_opt, "write"))
	{
		/* set pin mode to output */
		gpio_config.direction = HAL_GPIO_OUTPUT;
    	hal_gpio_config(atoi(pin), &gpio_config);
		hal_gpio_write(atoi(pin), ((*pin_args == '1')? 1 : 0));
	}
	/* gpio读操作 */
	else if(!rt_strcmp(pin_opt, "read"))
	{
		/* set pin mode to input */
		gpio_config.direction = HAL_GPIO_INPUT;
		gpio_config.pull	  = HAL_GPIO_NOPULL;
		pin_value = hal_gpio_read(atoi(pin));
		rt_kprintf("%s value is: %d\n", pin, pin_value);
	}
	/* gpio中断配置 */
	else if(!rt_strcmp(pin_opt, "irq"))
	{
		/* 按键引脚为输入模式 */
	    gpio_config.direction = HAL_GPIO_INPUT;
		gpio_config.pull	  = HAL_GPIO_PULLUP;
		hal_gpio_config(atoi(pin), &gpio_config);
	    /* 绑定中断，下降沿模式 */
		hal_gpio_set_irq(atoi(pin), HAL_GPIO_IRQ_FALLING, gpio_callback_test, RT_NULL);
	}
	/* 其他不支持 */
	else
	{
		rt_kprintf("input '%s' is not support\n",pin_opt);
		return HAL_EPERM;
	}
	
	return HAL_OK;
}

#endif
MSH_CMD_EXPORT(hal_gpio_sample, hal_gpio_sample <write/read 1 1>);
#endif 
#endif


