#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <rtthread.h>
#include <rtdevice.h>
#include <rthw.h>
#include <sys/time.h>

#include "hal_rtc.h"
#include "log.h"
#include "back_log.h"
#include "sofar_errors.h"

#define LOG_LINE_BUF_SIZE 128
#define LOG_FRAME_MAGIC               0x10
#define LOG_ASYNC_OUTPUT_BUF_SIZE 3072
#define LOG_ASYNC_OUTPUT_THREAD_STACK 2048
#define LOG_ASYNC_OUTPUT_THREAD_PRIORITY 60
#define LOG_NEWLINE_SIGN              "\r\n"
/* the number which is max stored line logs */
#ifndef LOG_ASYNC_OUTPUT_STORE_LINES
#define LOG_ASYNC_OUTPUT_STORE_LINES  (LOG_ASYNC_OUTPUT_BUF_SIZE * 4 / 2 / LOG_LINE_BUF_SIZE)
#endif

#if LOG_LINE_BUF_SIZE < 80
#error "the log line buffer size must more than 80"
#endif



struct rt_log   /* 仿照ulog写的log发送和存储，主要是减少函数嵌套，降低代码复杂度，节省资源 */
{
    rt_bool_t init_ok;
    struct rt_mutex output_locker;
    /* all backends */
    rt_slist_t backend_list;
    /* the thread log's line buffer */
    char log_buf_th[LOG_LINE_BUF_SIZE + 1];

    rt_rbb_t async_rbb;
    rt_thread_t async_th;
    struct rt_semaphore async_notice;
};

static struct rt_log g_log = { 0 };

uint8_t g_log_enable_flg = LOG_LEVEL_DEBUG;
uint8_t temp[128] = {0};
static void do_output(rt_uint32_t level, const char *tag, rt_bool_t is_raw, const char *log_buf, rt_size_t log_len)
{
    rt_rbb_blk_t log_blk;
    log_frame_t log_frame;

    /* allocate log frame */
    log_blk = rt_rbb_blk_alloc(g_log.async_rbb, RT_ALIGN(sizeof(struct log_frame) + log_len, RT_ALIGN_SIZE));
    if (log_blk)
    {
        /* package the log frame */
        log_frame = (log_frame_t) log_blk->buf;
        log_frame->magic = LOG_FRAME_MAGIC;
        log_frame->is_raw = is_raw;
        log_frame->level = level;
        log_frame->log_len = log_len;
        log_frame->tag = tag;
        log_frame->log = (const char *)log_blk->buf + sizeof(struct log_frame);
        /* copy log data */
        rt_memcpy(log_blk->buf + sizeof(struct log_frame), log_buf, log_len);
        rt_memcpy(temp, log_buf, log_len);
        /* put the block */
        rt_rbb_blk_put(log_blk);
        /* send a notice */
        rt_sem_release(&g_log.async_notice);
    }
    else
    {
        static rt_bool_t already_output = RT_FALSE;
        if (already_output == RT_FALSE)
        {
            rt_kprintf("Warning: There is no enough buffer for saving async log,"
                    " please increase the LOG_ASYNC_OUTPUT_BUF_SIZE option.\n");
            already_output = RT_TRUE;
        }
    }

}

void log_console_backend_output( rt_uint32_t level, const char *tag, rt_bool_t is_raw,
        const char *log, size_t len)
{
    rt_device_t dev = rt_console_get_device();
//    if (level > g_log_print_levle)
//    {
//        return;
//    }
    if (dev == RT_NULL)
    {
        rt_hw_console_output(log);
    }
    else
    {
        rt_uint16_t old_flag = dev->open_flag;

        dev->open_flag |= RT_DEVICE_FLAG_STREAM;
        rt_device_write(dev, 0, log, len);
        dev->open_flag = old_flag;

    }

}

/**
 * waiting for get asynchronous output log
 *
 * @param time the waiting time
 */
rt_err_t log_async_waiting_log(rt_int32_t time)
{
//    rt_sem_control(&ulog.async_notice, RT_IPC_CMD_RESET, RT_NULL);
    rt_err_t ret = rt_sem_take(&g_log.async_notice, time);
    return ret;
}

/**
 * asynchronous output logs to all backends
 *
 * @note you must call this function when ULOG_ASYNC_OUTPUT_BY_THREAD is disable
 */
void log_async_output(void)
{
    rt_rbb_blk_t log_blk;
    log_frame_t log_frame;

    while ((log_blk = rt_rbb_blk_get(g_log.async_rbb)) != NULL)
    {
        log_frame = (log_frame_t) log_blk->buf;
        if (log_frame->magic == LOG_FRAME_MAGIC)
        {
            
            if (!g_log.init_ok)
                return;
            
            /* 输出打印 */
            log_console_backend_output(log_frame->level, log_frame->tag, log_frame->is_raw, log_frame->log,
                    log_frame->log_len);
            
            /* 存储 */
            ulog_fs_backend_output(log_frame->level, log_frame->tag, log_frame->is_raw, log_frame->log,
                    log_frame->log_len);
        }
        rt_rbb_blk_free(g_log.async_rbb, log_blk);
        rt_thread_delay(1);
    }
}

static void async_output_thread_entry(void *param)
{
    rt_err_t ret;
    while (is_ulog_fs_log_init_end() == false){}
    rt_thread_delay(100);
    while (1)
    {
        ret = log_async_waiting_log(RT_WAITING_NO);
        if (RT_EOK == ret)
        {
            log_async_output();
        }
        else
        {
            ulog_fs_backend_period_proc();
        }
        rt_thread_delay(10);
    }
}


size_t log_strcpy(size_t cur_len, char *dst, const char *src)
{
    const char *src_old = src;

    RT_ASSERT(dst);
    RT_ASSERT(src);

    while (*src != 0)
    {
        /* make sure destination has enough space */
        if (cur_len++ < LOG_LINE_BUF_SIZE)
        {
            *dst++ = *src++;
        }
        else
        {
            break;
        }
    }
    return src - src_old;
}



RT_WEAK rt_size_t log_formater(char *log_buf, rt_uint32_t level, const char *tag, rt_bool_t newline,
        const char *format, va_list args)
{
    /* the caller has locker, so it can use static variable for reduce stack usage */
    static rt_size_t log_len, newline_len;
    static int fmt_result;

    RT_ASSERT(log_buf);
    RT_ASSERT(level <= LOG_LVL_DBG);
//    RT_ASSERT(tag);
    RT_ASSERT(format);

    log_len = 0;
    newline_len = rt_strlen(LOG_NEWLINE_SIGN);

    /* add time info */
    {

        static time_t now;
        static struct tm *tm, tm_tmp;

        now = hal_rtc_timestamp_get();
        tm = gmtime_r(&now, &tm_tmp);

        rt_snprintf(log_buf + log_len, LOG_LINE_BUF_SIZE - log_len, "%02d-%02d %02d:%02d:%02d", tm->tm_mon + 1,
                tm->tm_mday, tm->tm_hour, tm->tm_min, tm->tm_sec);

        log_len += rt_strlen(log_buf + log_len);
    }


    log_len += log_strcpy(log_len, log_buf + log_len, ": ");

    fmt_result = rt_vsnprintf(log_buf + log_len, LOG_LINE_BUF_SIZE - log_len, format, args);

    /* calculate log length */
    if ((log_len + fmt_result <= LOG_LINE_BUF_SIZE) && (fmt_result > -1))
    {
        log_len += fmt_result;
    }
    else
    {
        /* using max length */
        log_len = LOG_LINE_BUF_SIZE;
    }

    if (log_len + newline_len > LOG_LINE_BUF_SIZE)
    {
        /* using max length */
        log_len = LOG_LINE_BUF_SIZE;
        /* reserve some space for newline sign */
        log_len -= newline_len;
    }

    /* package newline sign */
    if (newline)
    {
        log_len += log_strcpy(log_len, log_buf + log_len, LOG_NEWLINE_SIGN);
    }

    return log_len;
}


//static void output_lock(void)
//{
//    /* is in thread context */
//    if (rt_interrupt_get_nest() == 0)
//    {
//        rt_mutex_take(&g_log.output_locker, RT_WAITING_FOREVER);
//    }
//    else
//    {
//        ;
//    }
//}


static void output_unlock(void)
{
    /* is in thread context */
    if (rt_interrupt_get_nest() == 0)
    {
        rt_mutex_release(&g_log.output_locker);
    }

}

static void output_lock(void)
{
    /* is in thread context */
    if (rt_interrupt_get_nest() == 0)
    {
        rt_mutex_take(&g_log.output_locker, RT_WAITING_FOREVER);
    }

}

/**
 * output the log by variable argument list
 *
 * @param level level
 * @param tag tag
 * @param newline has_newline
 * @param format output format
 * @param args variable argument list
 */
void log_voutput(rt_uint32_t level, const char *tag, rt_bool_t newline, const char *format, va_list args)
{
    char *log_buf = NULL;
    rt_size_t log_len = 0;    
    
//    RT_ASSERT(tag);
    RT_ASSERT(format);

    if (!g_log.init_ok)
    {
        return;
    }
    
    /* get log buffer */
    log_buf = g_log.log_buf_th;  
    
    /* lock output */
    output_lock();
    
    log_len = log_formater(log_buf, level, tag, newline, format, args);

    /* do log output */
    do_output(level, tag, RT_FALSE, log_buf, log_len);
    
    /* unlock output */
    output_unlock();
}


/**
 * output the log
 *
 * @param level level
 * @param tag tag
 * @param newline has newline
 * @param format output format
 * @param ... args
 */
void log_output(rt_uint32_t level, const char *tag, rt_bool_t newline, const char *format, ...)
{
    va_list args;

    /* args point to the first variable parameter */
    va_start(args, format);

    log_voutput(level, tag, newline, format, args);

    va_end(args);
}


int log_init(void)
{
    if (g_log.init_ok)
        return 0;

    rt_mutex_init(&g_log.output_locker, "log lock", RT_IPC_FLAG_FIFO);
//    rt_slist_init(&ulog.backend_list);


    RT_ASSERT(LOG_ASYNC_OUTPUT_STORE_LINES >= 2);
    /* async output ring block buffer */
    g_log.async_rbb = rt_rbb_create(RT_ALIGN(LOG_ASYNC_OUTPUT_BUF_SIZE, RT_ALIGN_SIZE), LOG_ASYNC_OUTPUT_STORE_LINES);
    if (g_log.async_rbb == NULL)
    {
        rt_kprintf("Error: ulog init failed! No memory for async rbb.\n");
        rt_mutex_detach(&g_log.output_locker);
        return -RT_ENOMEM;
    }
    /* async output thread */
    g_log.async_th = rt_thread_create("log_async", async_output_thread_entry, &g_log, LOG_ASYNC_OUTPUT_THREAD_STACK,
            LOG_ASYNC_OUTPUT_THREAD_PRIORITY, 20);
    if (g_log.async_th == NULL)
    {
        rt_kprintf("Error: ulog init failed! No memory for async output thread.\n");
        rt_mutex_detach(&g_log.output_locker);
        rt_rbb_destroy(g_log.async_rbb);
        return -RT_ENOMEM;
    }

    rt_sem_init(&g_log.async_notice, "log", 0, RT_IPC_FLAG_FIFO);
    /* async output thread startup */
    rt_thread_startup(g_log.async_th);

    g_log.init_ok = RT_TRUE;

    return 0;
}
INIT_PREV_EXPORT(log_init);

/**
* @brief		LOG删除驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t log_deinit(void)
{
	return SF_OK;
}
     

/**
* @brief		设置log输出级别 
* @param		[in] log_level LOG级别
* -# LOG_LVL_ASSERT 表明出现了不合理数据，导致系统卡死                                                 
* -# LOG_LVL_ERROR  表明出现了系统错误和异常，无法正常完成目标操作。                                   
* -# LOG_LVL_WARN   表明系统出现轻微的不合理但不影响运行和使用；                                       
* -# LOG_LVL_INFO   用于打印程序应该出现的正常状态信息， 便于追踪定位                                  
* -# LOG_LVL_DEBUG  级别最低，可以随意的使用于任何觉得有利于在调试时更详细的了解系统运行状态的东东   
* -# LOG_LVL_DISABLE  关闭调试信息   
* @pre			需先执行log_init后执行才有效 
*/
void log_level_set(uint8_t log_type, uint8_t log_level)
{	
	if (log_type == 0)
    {
//        ulog_print_log_lvl_set(log_level);
        g_log_enable_flg = log_level;
	} 
    else if (log_type == 1)
    {
//        ulog_fs_log_lvl_set(log_level);
	}
}

/**
* @brief		获取log级别 
* @param		[in] log_type log等级类型
* -# 0 log打印等级
* -# 1 log存储等级
* @return       < 0 非法log类型
* @return       >= 0
* -# LOG_LEVEL_DISABLE 关闭调试
* -# LOG_LEVEL_ASSERT 表明出现了不合理数据，导致系统卡死
* -# LOG_LEVEL_ERROR 表明出现了系统错误和异常，无法正常完成目标操作。
* -# LOG_LEVEL_WARN 表明系统出现轻微的不合理但不影响运行和使用；
* -# LOG_LEVEL_INFO 用于打印程序应该出现的正常状态信息， 便于追踪定位
* -# LOG_LEVEL_DEBUG 级别最低，可以随意的使用于任何觉得有利于在调试时更详细的了解系统运行状态的东东  
*/
int32_t log_level_get(uint8_t log_type)
{	
	if (log_type == 0){
		return g_log_enable_flg;
	} else if (log_type == 1){
//		return ulog_fs_log_lvl_get();
        return 0;
	}  else {
		return -1; // 非法log类型
	}
}

/**
* @brief		输出十六进信息
* @param		[in] name log显示的标识符 
* @param		[in] width 一行显示多少个字符 
* @param		[in] buf 缓冲区指针
* @param		[in] size 缓冲区大小
* @pre			需先执行log_init和log_enable后执行才有效 
*/
void log_hexdump(const char *name, uint8_t width, uint8_t *buf, uint16_t size)
{
   int i;
  
   if ( g_log_enable_flg >= LOG_LEVEL_ASSERT && g_log_enable_flg <= LOG_LEVEL_DEBUG)
   {
       rt_kprintf("%s:",name);
       for (i = 0; i < size; i++)
       {
           if ((i % width) == 0)
           {
               rt_kprintf("\n");
           }
           rt_kprintf("%02X ",buf[i]);
       }
       rt_kprintf("\n");
   }  
}



#ifdef RT_USING_FINSH
#ifdef RT_USING_FINSH_DEBUG

void debug_level(int argc, char *argv[])
{
    int level = 0;
    
    if (argc > 1)
    {
        if (strcmp(argv[1], "set") == 0)
        {
            level = atol(argv[2]);
            if (level <= LOG_LVL_DEBUG)
            {
                g_log_level = level;
                rt_kprintf("set leve is %d ok\n",level);
            }
            else
            {
                rt_kprintf("set level is error, %d\n",level);
            }
        }
        else if (strcmp(argv[1], "get") == 0)
        {
            rt_kprintf("level is %d\n",g_log_level);
        }
    } 
}

MSH_CMD_EXPORT(debug_level, set debug level "for example:debug_level set ?/debug_level get");
#endif
#endif
