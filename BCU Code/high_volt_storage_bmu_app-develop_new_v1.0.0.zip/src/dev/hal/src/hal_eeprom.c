#include <rtthread.h>
#include <stdlib.h>
#include <string.h>
#include "hal_eeprom.h"
#include "hal_gpio.h"
#include "hal_i2c.h"
#include "osif.h"
#include "log.h"

#define EEPROM_I2C_BUS_NO			0
#define EEPROM_DEV_ADDR				0xA0
#define EEPROM_WP_PIN				(('D'-'A')*0x10+7)		// GPIOD PIN7

#define EEPROM_WP_ENABLE()			(hal_gpio_write(EEPROM_WP_PIN, HAL_GPIO_LOW))		
#define EEPROM_WP_DISABLE()			(hal_gpio_write(EEPROM_WP_PIN, HAL_GPIO_HIGH))	

enum
{
    EEPROM_INDEX = 0,
	MAX_INDEX_MAX,
};

const os_mutex_attr_t g_eeprom_mutex_attr = {"eep_mtx",0,0,0};
os_mutex_id_t g_eeprom_mutex_id = NULL;






/**
* @brief		EEPROM加载驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_eeprom_init(void)
{
	// mutex init
	g_eeprom_mutex_id = os_mutex_new(&g_eeprom_mutex_attr);
	if (g_eeprom_mutex_id == NULL)
	{
		log_e("eeprom mutex create fail\n");
	}
	return HAL_OK;
}
INIT_BOARD_EXPORT(hal_eeprom_init);

/**
* @brief		EEPROM删除驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_eeprom_deinit(void)
{
	
	return HAL_OK;
}


/**
* @brief		打开EEPROM设备
* @param		[in] dev_no 虚拟设备编号  
* @param		[in] dev_addr EEPROM的地址 
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_eeprom_open(uint32_t dev_no, uint8_t dev_addr)
{
	const hal_gpio_config_t eeprom_wp_pin_cfg = {HAL_GPIO_OUTPUT,HAL_GPIO_PULLUP};
    
	if (dev_no >= MAX_INDEX_MAX)
		return HAL_EIO;
	
	if (dev_no == EEPROM_INDEX)
	{
		hal_gpio_open(EEPROM_WP_PIN);
		hal_gpio_config(EEPROM_WP_PIN, (hal_gpio_config_t *)&eeprom_wp_pin_cfg); 
		EEPROM_WP_DISABLE();
		return hal_i2c_open(EEPROM_I2C_BUS_NO);
	}

	return HAL_EIO;
}

/**
* @brief		读EEPROM设备（按字节）
* @param		[in] dev_no 虚拟设备编号  
* @param		[in] read_addr 起始地址
* @param		[out] buf 读缓冲区
* @param		[in] len 读长度
* @return		执行结果
* @retval		>=0 读取长度  
* @retval		<0 失败原因  
*/
int32_t hal_eeprom_read(uint32_t dev_no, uint32_t read_addr, uint8_t *buf, uint16_t len)
{
    int32_t read_len = -1;
    uint8_t dev_addr_buf[2];
    
    if (dev_no >= MAX_INDEX_MAX)
		return HAL_EIO;
    
    dev_addr_buf[0] = (uint8_t)(read_addr >> 8);	
    dev_addr_buf[1] = (uint8_t)read_addr;
    os_mutex_acquire(g_eeprom_mutex_id, OS_WAIT_FOREVER);
    if (hal_i2c_write(EEPROM_INDEX, EEPROM_DEV_ADDR, dev_addr_buf, 2) != 2)
  	{
  		goto __exit;
  	}
    read_len = hal_i2c_read(EEPROM_INDEX, EEPROM_DEV_ADDR, buf, len);
__exit:
	os_mutex_release(g_eeprom_mutex_id);
	
	return read_len;
}



static int32_t eeprom_write_one_byte(uint32_t write_addr, uint8_t data)
{
    uint8_t buf[3];
   
    buf[0] = (uint8_t)(write_addr>>8);	
    buf[1] = (uint8_t)write_addr;
    buf[2] = data;
    if (hal_i2c_write(EEPROM_INDEX, EEPROM_DEV_ADDR, buf, 3) == sizeof(buf))
    	return sizeof(data);
    else
    	return -1;
}

/**
* @brief		写EEPROM设备（按字节）
* @param		[in] dev_no 虚拟设备编号  
* @param		[in] write_addr 起始地址
* @param		[in] buf 写缓冲区
* @param		[in] len 写长度
* @return		执行结果
* @retval		>=0 实际写长度  
* @retval		<0 失败原因  
*/
int32_t hal_eeprom_write(uint32_t dev_no, uint32_t write_addr, uint8_t *buf, uint16_t len)
{
    int32_t write_len = 0;
    int32_t ret;
    uint16_t i;
    
    if (dev_no >= MAX_INDEX_MAX)
		return HAL_EIO;
	EEPROM_WP_ENABLE();
    os_mutex_acquire(g_eeprom_mutex_id, OS_WAIT_FOREVER);
	for(i = 0; i < len; i++, write_len++)
    {
        ret = eeprom_write_one_byte(write_addr++, *buf++);
        if(ret < 0)
        {
            break;
        }
        /* 此处延时应大于4ms，等待芯片内部写完成 */
        os_delay(2);	// 10~20ms
    }
	os_mutex_release(g_eeprom_mutex_id);
	EEPROM_WP_DISABLE();
	
	return write_len;
}
/**
* @brief		读EEPROM设备（按页）
* @param		[in] dev_no 虚拟设备编号  
* @param		[in] read_addr 起始地址
* @param		[out] buf 读缓冲区
* @param		[in] len 读长度
* @return		执行结果
* @retval		>=0 读取长度  
* @retval		<0 失败原因  
*/
int32_t hal_eeprom_page_read(uint32_t dev_no, uint32_t read_addr, uint8_t *buf, uint16_t len)
{
	log_d("not support!");
	return HAL_ENOENT;
}

/**
* @brief		写EEPROM设备（按页）
* @param		[in] dev_no 虚拟设备编号  
* @param		[in] write_addr 起始地址
* @param		[in] buf 写缓冲区
* @param		[in] len 写长度
* @return		执行结果
* @retval		>=0 实际写长度  
* @retval		<0 失败原因  
*/
int32_t hal_eeprom_page_write(uint32_t dev_no, uint32_t write_addr, uint8_t *buf, uint16_t len)
{
	log_d("not support!");
	return HAL_ENOENT;
}


/**
* @brief		扩展功能 
* @param		[in] dev_no 设备端口号  
* @param		[in] cmd 控制命令  
* @param		[in] arg 控制参数   
* @return		执行结果
* @retval		HAL_OK 成功    
* @retval		<0 失败原因  
*/
int32_t hal_eeprom_ioctl(int32_t dev_no, uint8_t cmd, void* arg)
{
	return HAL_OK;
}

#if 0
void test_eeprom(int argc, char *argv[])
{
    int addr = 0;
    uint8_t buff[16];
    
    if (argc > 1)
    {
        hal_eeprom_open(0, 0xA0);
        if (strcmp(argv[1], "set") == 0)
        {
            addr = atol(argv[2]);
            buff[0] = atol(argv[3]);
            for (int i = 1; i < sizeof(buff); i++)
            {
            	buff[i] = buff[0] + i;
            }
            hal_eeprom_write(0, addr, buff, sizeof(buff));
        }
        else if (strcmp(argv[1], "get") == 0)
        {
            addr = atol(argv[2]);

            hal_eeprom_read(0, addr, buff , sizeof(buff));
            log_hexdump("eeprom data", 16, buff, sizeof(buff));
        }
    } 
}

MSH_CMD_EXPORT(test_eeprom, test i2c eeprom);
#endif


