#include <board.h>
#include <string.h>
#include <rtthread.h>
#include <rtdevice.h>
#include "hal_pm.h"
#include "n32g45x_pwr.h"



/**
* @brief		电源管理模块加载驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_pm_init(void)
{
    // 使能POWER时钟，低功耗配置寄存需求打开此时钟才有效
    RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_PWR, ENABLE);
    PWR_BackupAccessEnable(ENABLE); // 进入RTC和备份寄存器 使能
    RCC_EnableBackupReset(DISABLE); // 关闭备份寄存器复位
    return HAL_OK;
}
INIT_DEVICE_EXPORT(hal_pm_init);


/**
* @brief		电源管理模块删除驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_pm_deinit(void)
{
	RCC_EnableAPB1PeriphReset(RCC_APB1_PERIPH_PWR, ENABLE);
    RCC_EnableAPB1PeriphReset(RCC_APB1_PERIPH_PWR, DISABLE);
	return HAL_OK;
}


/**
* @brief		请求不进入休眠的锁    
* @warning  	
* -# hal_pm_request_lock和rt_pm_release_lock需要成对出现
* -# hal_pm_request_lock多次调用会累加，导致系统无法进入休眠模式
*/
void hal_pm_request_lock(void)
{
	return;
}



/**
* @brief		释放休眠模式    
* @warning
* -# hal_pm_request_lock和hal_pm_release_lock需要成对出现
* -# hal_pm_request_lock多次调用会累加，导致系统无法进入休眠模式
*/
void hal_pm_release_lock(void)
{
	return;
}


/**
* @brief		设置进入/退出休眠模式的回调通知
* @param		[in] notify 应用的回调函数
* @param		[in] data 私有数据 
* @pre			执行hal_pm_init后执行才有效。
*/
void hal_pm_notify_set(void (*notify)(uint8_t event, uint8_t mode, void *data), void *data)
{
	return;
}

/**
 * @brief  Configures system clock after wake-up from STOP: enable HSE, PLL
 *         and select PLL as system clock source.
 */
void SYSCLKConfig_STOP(uint32_t RCC_PLLMULL)
{
    __IO uint32_t StartUpCounter = 0, HSEStatus = 0;
    uint32_t Flash_Latency_Temp=0;
    uint32_t PLL_Temp=0;
    uint32_t System_Temp=0;	
    /* SYSCLK, HCLK, PCLK2 and PCLK1 configuration ---------------------------*/
    /* Enable HSE */
    RCC->CTRL |= ((uint32_t)RCC_CTRL_HSEEN);
    /* Wait till HSE is ready and if Time out is reached exit */
    do
    {
        HSEStatus = RCC->CTRL & RCC_CTRL_HSERDF;
        StartUpCounter++;
    } while ((HSEStatus == 0) && (StartUpCounter != HSE_STARTUP_TIMEOUT));
    if ((RCC->CTRL & RCC_CTRL_HSERDF) != RESET)
    {
       HSEStatus = (uint32_t)0x01;
    }
    else
    {
       HSEStatus = (uint32_t)0x00;
    }
    if (HSEStatus == (uint32_t)0x01)
    {
       /* Enable Prefetch Buffer */
       FLASH->AC |= FLASH_AC_PRFTBFEN;
       /* Flash 2 wait state */
       Flash_Latency_Temp = FLASH->AC;
       Flash_Latency_Temp &= (uint32_t)((uint32_t)~FLASH_AC_LATENCY);
       Flash_Latency_Temp |= (uint32_t)FLASH_AC_LATENCY_4;
       FLASH->AC = Flash_Latency_Temp;
       /* HCLK = SYSCLK */
       RCC->CFG |= (uint32_t)RCC_CFG_AHBPRES_DIV1;
       /* PCLK2 = HCLK */
       RCC->CFG |= (uint32_t)RCC_CFG_APB2PRES_DIV2; 
       /* PCLK1 = HCLK */
       RCC->CFG |= (uint32_t)RCC_CFG_APB1PRES_DIV4; 
       /*  PLL configuration: PLLCLK = HSE * 18 = 144 MHz */
       PLL_Temp = RCC->CFG;
       PLL_Temp &= (uint32_t)((uint32_t) ~(RCC_CFG_PLLSRC | RCC_CFG_PLLHSEPRES | RCC_CFG_PLLMULFCT));
       PLL_Temp |= (uint32_t)(RCC_CFG_PLLSRC_HSE | RCC_PLLMULL);
       RCC->CFG = PLL_Temp;
       /* Enable PLL */
       RCC->CTRL |= RCC_CTRL_PLLEN;
       /* Wait till PLL is ready */
       while ((RCC->CTRL & RCC_CTRL_PLLRDF) == 0)
       {
       }
       /* Select PLL as system clock source */
       System_Temp = RCC->CFG;
       System_Temp &= (uint32_t)((uint32_t) ~(RCC_CFG_SCLKSW));
       System_Temp |= (uint32_t)RCC_CFG_SCLKSW_PLL;
       RCC->CFG = System_Temp;
       /* Wait till PLL is used as system clock source */
       while ((RCC->CFG & (uint32_t)RCC_CFG_SCLKSTS) != (uint32_t)0x08)
       {
       }
    }
    else
    { 
       /* If HSE fails to start-up, the application will have wrong clock
          configuration. User can add here some code to deal with this error */
    }
}

/**
* @brief		设置运行模式
* @param		[in] run_mode 运行模式
* -# HAL_PM_ENTER_SLEEP = 进入休眠模式
* -# HAL_PM_EXIT_SLEEP = 退出休眠模式
* @pre			执行hal_pm_init后执行才有效。
*/
int32_t hal_pm_run_enter(uint8_t run_mode)
{
	/* 进入休眠 */
	if(HAL_PM_ENTER_SLEEP == run_mode)
	{	
		PWR->CTRL2 &= ~PWR_CTRL2_STOP2S; // 防止进入STOP2模式
		PWR_EnterStopState(PWR_REGULATOR_LOWPOWER, PWR_STOPENTRY_WFE);
        for (uint32_t i = 0; i < 100; i++)
        {
            __NOP();
        }
		SYSCLKConfig_STOP(RCC_CFG_PLLMULFCT12); 
	}

	/* 退出休眠 */
	else if(HAL_PM_EXIT_SLEEP == run_mode)
	{
		/* Configures system clock after wake-up from STOP: enable HSE, PLL and select
          PLL as system clock source (HSE and PLL are disabled in STOP mode) */
		SYSCLKConfig_STOP(RCC_CFG_PLLMULFCT12);		
	}
	/* 其他返回err */
	else
	{
		return HAL_EPERM;
	}
	return HAL_OK;
}


/**
* @brief		扩展功能 
* @param		[in] dev_no 设备端口号  
* @param		[in] cmd 控制命令  
* @param		[in] arg 控制参数   
* @return		执行结果
* @retval		HAL_OK 成功    
* @retval		<0 失败原因  
*/
int32_t hal_pm_ioctl(int32_t dev_no, uint8_t cmd, void* arg)
{
	return HAL_OK;
}


#ifdef RT_USING_FINSH
#ifdef RT_USING_FINSH_DEBUG

/* 唤醒中断回调函数 */
static void wakeup_callback_test(void *args)
{
    rt_kprintf("gpio irq!!! \n");
}

#include "hal_gpio.h"
#include "hal_adc.h"
#include "hal_can.h"
#include "hal_pwm.h"
#include "hal_uart.h"

/* 系统进入休眠测试样例 */
void hal_sleep_sample(void)
{
	hal_gpio_config_t gpio_config;
	
	gpio_config.direction = HAL_GPIO_INPUT;
	gpio_config.pull	  = HAL_GPIO_PULLUP;

	/* PWR时钟使能 */
	hal_pm_init();
	
	hal_gpio_config(23, &gpio_config); //开发板唤醒脚
	hal_gpio_config(GPIO_IDX17_POWER_OFF_KEY, &gpio_config);
	hal_gpio_config(GPIO_IDX20_BATTERY_PACK_IN, &gpio_config);
	
    /* 开发板中断唤醒配置，绑定中断，下降沿模式 */
	hal_gpio_set_irq(23, HAL_GPIO_IRQ_FALLING, wakeup_callback_test, NULL);
	hal_gpio_set_irq(GPIO_IDX17_POWER_OFF_KEY, HAL_GPIO_IRQ_FALLING, wakeup_callback_test, NULL);	
	hal_gpio_set_irq(GPIO_IDX20_BATTERY_PACK_IN, HAL_GPIO_IRQ_FALLING, wakeup_callback_test, NULL);

	/* 依次配置外设进入休眠低功耗状态 */
	hal_adc_suspend(HAL_ADC1);
	hal_adc_suspend(HAL_ADC2);
	hal_can_suspend(HAL_CAN1);
	hal_can_suspend(HAL_CAN2);
	hal_pwm_suspend(HAL_PWM_TIM8, HAL_PWM_CH2);
	hal_uart_suspend(HAL_UART1);
	hal_uart_suspend(HAL_UART3);
	hal_uart_suspend(HAL_UART5);
	hal_gpio_suspend(GPIO_IDX00_BOARD_ERR_LED);
	hal_gpio_suspend(GPIO_IDX01_BOARD_NOR_LED);
	hal_gpio_suspend(GPIO_IDX26_VDD_SLEEP_CTRL);
	hal_gpio_suspend(GPIO_IDX27_CHARGE_MOS);
	hal_gpio_suspend(GPIO_IDX28_CHARGER_CHECK);
	hal_gpio_suspend(GPIO_IDX29_PRE_CHARGE_MOS);
	hal_gpio_suspend(GPIO_IDX30_HEAT_ENABLE);
	hal_gpio_suspend(GPIO_IDX31_DISCHARGE_MOS);
	hal_gpio_suspend(GPIO_IDX33_SHORT_PROTECT_REMOVE);
	hal_gpio_suspend(GPIO_IDX36_AFE_LEVEL_ENABLE);
	hal_gpio_suspend(GPIO_IDX38_SPI_CS);
	
	/* 进入休眠 */
	hal_pm_run_enter(HAL_PM_ENTER_SLEEP);
	/* 休眠唤醒后，复位 */
	__NVIC_SystemReset();
}
MSH_CMD_EXPORT(hal_sleep_sample, into_sleep_sample);
#endif
#endif



