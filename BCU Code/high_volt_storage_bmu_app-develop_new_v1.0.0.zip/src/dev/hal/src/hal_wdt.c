#include <board.h>
#include <string.h>
#include <rtthread.h>
#include "hal_wdt.h"
#include "hal_gpio.h"
#include "log.h"

static uint32_t    g_wdg_init = 0;     		/* 看门狗打开状态 */
static uint32_t    g_wdg_status = 0;     		/* 看门狗打开状态 */
static uint32_t    g_wdg_tim_s = 10;    /* 看门狗超时默认时间 */

#define LSI_VALUE 40000

static uint8_t     g_ext_wdg_feed_enbale = false;     // 外部看门狗喂狗使能
/**
* @brief		外部看门狗加载驱动
* @return		执行结果
* @retval		SF_OK 成功
* @retval		<0 失败 
*/
int32_t hal_ext_wdt_init(void)
{
//    GPIO_InitType GPIO_InitStructure;
	hal_gpio_config_t gpio_config = {HAL_GPIO_OUTPUT, HAL_GPIO_NOPULL};
   
    // 初始化外部看门狗
    if(hal_gpio_config(EXT_WDI_1_PIN, &gpio_config) != HAL_OK)
	{
		return HAL_EPERM;
	}
    
//    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE);
//        GPIO_InitStructure.Pin        = GPIO_PIN_1;
//        GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
//        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//        GPIO_InitPeripheral(GPIOB, &GPIO_InitStructure);    
    
	g_ext_wdg_feed_enbale = true;
	return HAL_OK;
}
INIT_DEVICE_EXPORT(hal_ext_wdt_init);

/**
* @brief		外部看门狗卸载驱动
* @return		执行结果
* @retval		SF_OK 成功
* @retval		<0 失败 
*/
int32_t hal_ext_wdt_deinit(void)
{
//    GPIO_InitType GPIO_InitStructure;
	hal_gpio_config_t gpio_config = {HAL_GPIO_INPUT, HAL_GPIO_NOPULL};
   
    // 初始化外部看门狗
    if(hal_gpio_config(EXT_WDI_1_PIN, &gpio_config) != HAL_OK)
	{
		return HAL_EPERM;
	}
    
//    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE);
//        GPIO_InitStructure.Pin        = GPIO_PIN_1;
//        GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
//        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//        GPIO_InitPeripheral(GPIOB, &GPIO_InitStructure);    
    
	g_ext_wdg_feed_enbale = false;
	return HAL_OK;
}

// 外部看门狗喂狗
static void hal_ext_wdt_feed(void)
{
    if (!g_ext_wdg_feed_enbale)
    {
        return;
    }
    hal_gpio_toggle(EXT_WDI_1_PIN);
}

/**
* @brief		看门狗加载驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		<0 失败 
*/
int32_t hal_wdt_init(void)
{
	if(!g_wdg_init)
	{
        /* 调试时停止看门狗 */
        DBG->CTRL |= DBG_CTRL_WWDG_STOP;
        DBG->CTRL |= DBG_CTRL_IWDG_STOP;
		g_wdg_status = 0;
		g_wdg_init = 1;
	}

	return HAL_OK;
}
INIT_DEVICE_EXPORT(hal_wdt_init);

/**
* @brief		看门狗删除驱动(预留)
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		<0 失败 
*/
int32_t hal_wdt_deinit(void)
{

	return HAL_OK;
}

/**
* @brief		打开看门狗
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		<0 失败   
* @pre			执行hal_wdt_init后执行才有效。默认5s
*/
static void hal_wdg_idle_hook(void);
int32_t hal_wdt_open(void)
{
	
	if(!g_wdg_init)
	{
		return HAL_EPERM;
	}

	if(g_wdg_status)
	{
		return HAL_OK;
	}
	
    IWDG_WriteConfig(IWDG_WRITE_ENABLE);
    IWDG_SetPrescalerDiv(IWDG_PRESCALER_DIV256);
    IWDG_CntReload(g_wdg_tim_s * LSI_VALUE / 256 + 1);
    IWDG_WriteConfig(IWDG_WRITE_DISABLE);
    IWDG_Enable();

    rt_thread_idle_sethook(hal_wdg_idle_hook);
	g_wdg_status = 1;
	
	return HAL_OK;
}


/**
* @brief		关闭看门狗  
* @return		执行结果
* @retval		0 成功  
* @retval		<0 失败   
* @pre			看门狗打开后就关闭不了，需等到复位。
*/
int32_t hal_wdt_close(void)
{
	return HAL_EPERM;
}
 

/**
* @brief		设置超时时间
* @param		[in] timeout_s 超时时间，秒为单位 不超过26
* @return		执行结果
* @retval		0 成功  
* @retval		<0 失败   
* @pre			init、open成功后执行才有效
*/
int32_t hal_wdt_set(uint32_t timeout_s)
{
	/* 看门狗未启动或看门狗设备句柄未初始化，直接返回 */
	if ((!g_wdg_init) || (!g_wdg_status)  || (timeout_s > 26))
	{
		return HAL_EPERM;	
    }
	/* 设置超时时间 */
    g_wdg_tim_s = g_wdg_tim_s;
    IWDG_WriteConfig(IWDG_WRITE_ENABLE);
    IWDG_SetPrescalerDiv(IWDG_PRESCALER_DIV256);
    IWDG_CntReload(g_wdg_tim_s * LSI_VALUE / 256 + 1);
    IWDG_WriteConfig(IWDG_WRITE_DISABLE);
    IWDG_Enable();
	
	hal_wdt_feed();
    
	return HAL_OK;	
}


/**
* @brief		获取超时时间
* @param		[out] timeout_s 超时时间，秒为单位,
* @return		执行结果
* @retval		0 成功  
* @retval		<0 失败   
* @pre			init、open成功后执行才有效
*/
int32_t hal_wdt_get_timeout(uint32_t *p_timeout)
{	
	if ((!g_wdg_init) || (!g_wdg_status) )
	{
		return HAL_EPERM;	
    }
	p_timeout = &g_wdg_tim_s;
	return HAL_OK;
}


/**
* @brief		喂狗  
* @return		执行结果
* @retval		0 成功  
* @retval		<0 失败 
* @pre			init、open成功后执行才有效
*/
int32_t hal_wdt_feed(void)
{
	if ((!g_wdg_init) || (!g_wdg_status) )
	{
		return HAL_EPERM;
    }
    
	IWDG_ReloadKey();
    hal_ext_wdt_feed();
    
	return HAL_OK;
}


/**
* @brief		看门狗超时中断回调函数(预留) 
* @param		[in] cb 回调函数  
* @return		执行结果
* @retval		0 成功  
* @retval		<0 失败   
* @pre			执行hal_wdt_open后执行才有效。
* @warning  	函数使用需要在hal_wdt_start之前调用
*/
int32_t hal_wdt_set_irq(irq_callback cb)
{
	return HAL_OK;
}


static void hal_wdg_idle_hook(void)
{
    hal_wdt_feed();
}


#ifdef RT_USING_FINSH
#ifdef RT_USING_FINSH_DEBUG

#include <stdlib.h>
static int hal_wdt_sample(int argc, char *p_argv[])
{
	uint32_t timeout;
	char 	*pin_opt  = p_argv[1];
	char 	*time	  = p_argv[2];

	if (!rt_strcmp(pin_opt, "init"))
	{
		if(HAL_OK != hal_wdt_init())
		{
			log_e("hal_wdt_init err!\n");
		}
	}
	else if (!rt_strcmp(pin_opt, "deinit"))
	{
		if(HAL_OK != hal_wdt_deinit())
		{
			log_e("hal_wdt_deinit err!\n");
		}
	}
	else if (!rt_strcmp(pin_opt, "open"))
	{
		if(HAL_OK != hal_wdt_open())
		{
			log_e("hal_wdt_open err!\n");
		}
	}
	else if (!rt_strcmp(pin_opt, "close"))
	{
		if(HAL_OK != hal_wdt_close())
		{
			log_e("hal_wdt_close err!\n");
		}
	}
	else if (!rt_strcmp(pin_opt, "set"))
	{
		uint32_t timeout_s = 0;
		
		timeout = atoi(time);
		if(HAL_OK != hal_wdt_set(timeout))
		{
			log_e("hal_wdt_set err!\n");
		}
		if(HAL_OK == hal_wdt_get_timeout(&timeout_s))
		{
			rt_kprintf("get timeout: %d\n", timeout_s);
		}
	}
	else if(!rt_strcmp(pin_opt, "feed"))
	{
		if(HAL_OK != hal_wdt_feed())
		{
			log_e("hal_wdt_feed err!\n");
		}
	}
    else if (!rt_strcmp(pin_opt, "disa"))
    {
        g_ext_wdg_feed_enbale = false;
    }
	else
	{
		log_e("input '%s' is not support\n",pin_opt);
		return HAL_EPERM;
	}
	
	return HAL_OK;
}

MSH_CMD_EXPORT(hal_wdt_sample, hal_wdt_sample <start/stop>);
#endif 
#endif

