#include <board.h>
#include <rtthread.h>
#include <rtdevice.h>
#include "hal_hw_i2c.h"
#include "hal_gpio.h"
#include "string.h"
#include "stdlib.h"
#include "osif.h"
#include "log.h"


typedef struct{
	uint8_t is_init;	
	uint8_t is_open;	
}hw_i2c_status_t;

static hw_i2c_status_t g_hw_i2c_status = {0};

typedef struct
{
	I2C_Module*  module;
    uint32_t baud_rate;
	GPIO_Module* scl_gpio_port;
    const uint16_t scl_gpio_pin;
    GPIO_Module* sda_gpio_port;
    const uint16_t sda_gpio_pin;
	os_mutex_id_t mutex_id;
	const os_mutex_attr_t i2c_mutex_attr;
	void (*p_init)(void);
}hw_i2c_bus_t;


static hw_i2c_bus_t g_hw_i2c_bus[] =
{
#ifdef BSP_USING_HW_I2C2

	{
        .module = I2C2,
		.baud_rate = I2C_400K_BAUD,
		.scl_gpio_port = GPIOB,
		.scl_gpio_pin = GPIO_PIN_10,
		.sda_gpio_port = GPIOB,
		.sda_gpio_pin = GPIO_PIN_11,
		.i2c_mutex_attr = {"hw_i2c2_mtx",0,0,0},
	},
#endif

};



/**
* @brief		I2C加载驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
static int32_t hal_hw_i2c_init(void)
{
	uint8_t i;
	int32_t ret = HAL_OK;
    
	for (i = 0; i < ITEM_NUM(g_hw_i2c_bus); i++)
	{
		g_hw_i2c_bus[i].mutex_id = os_mutex_new(&(g_hw_i2c_bus[i].i2c_mutex_attr));
        if (g_hw_i2c_bus[i].mutex_id == NULL)
        {
            log_w("i2c mutex create fail\n");
            return HAL_OK;
        }        
        SF_SET_BIT(g_hw_i2c_status.is_init, (1u << i));  
	}

	return ret;
}

/**
* @brief		I2C删除驱动
* @return		执行结果
* @retval		SF_OK 成功
* @retval		SF_ERR_NO_OBJECT 失败 
*/
int32_t hal_hw_i2c_deinit(void)
{
	uint8_t i;
	int32_t ret = HAL_OK;
    
	for (i = 0; i < ITEM_NUM(g_hw_i2c_bus); i++)
	{
        if (HAL_OK != os_mutex_delete(g_hw_i2c_bus[i].mutex_id))
        {
            log_w("i2c mutex delete fail\n");
            return HAL_ERR;
        }        
        SF_SET_BIT(g_hw_i2c_status.is_init, (0u << i));  
	}

	return ret;
}


/**
* @brief		打开I2C功能  
* @param		[in] i2c_no 虚拟I2C端口号 
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		SF_ERR_NO_OBJECT 失败   
* @warning 		本接口只初始化I2C总线接口 
*/
int32_t hal_hw_i2c_open(uint32_t i2c_no)
{
    int32_t ret = HAL_ERR;
    GPIO_InitType GPIO_InitStructure;
    I2C_InitType I2C_InitStructure;

    if (i2c_no >= I2C_MAX) 
	{
		return HAL_EPERM;
	}
	if (SF_GET_BIT(g_hw_i2c_status.is_init, (1U << i2c_no)) == 0)
    {
        return HAL_ERR; // 未初始化，返回失败
    }    

	/* i2c2 */
	if (i2c_no == I2C2_ID)
	{
        RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_I2C2, ENABLE);
        RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE);

        GPIO_InitStructure.Pin = g_hw_i2c_bus[i2c_no].scl_gpio_pin | g_hw_i2c_bus[i2c_no].sda_gpio_pin;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
        GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_OD;
        GPIO_InitPeripheral(g_hw_i2c_bus[i2c_no].scl_gpio_port, &GPIO_InitStructure);

        I2C_DeInit(g_hw_i2c_bus[i2c_no].module);
        I2C_InitStructure.BusMode     = I2C_BUSMODE_I2C;
        I2C_InitStructure.FmDutyCycle = I2C_FMDUTYCYCLE_2;
        I2C_InitStructure.OwnAddr1    = 0xff;
        I2C_InitStructure.AckEnable   = I2C_ACKEN;
        I2C_InitStructure.AddrMode    = I2C_ADDR_MODE_7BIT;
        I2C_InitStructure.ClkSpeed    = I2C_400K_BAUD; // 

        I2C_Init(g_hw_i2c_bus[i2c_no].module, &I2C_InitStructure);
        I2C_Enable(g_hw_i2c_bus[i2c_no].module, ENABLE); 
        ret = HAL_OK;       
	}


     
   	return ret;
}


/**
* @brief		关闭I2C功能  
* @param		[in] i2c_no 虚拟I2C端口号 
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		SF_ERR_NO_OBJECT 失败   
* @warning 		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_hw_i2c_close(uint32_t i2c_no)
{
    int32_t ret = HAL_ERR;	
    
    if (i2c_no >= I2C_MAX) 
	{
		return HAL_EPERM;
	}
	if (SF_GET_BIT(g_hw_i2c_status.is_init, (1U << i2c_no)) == 0)
    {
        return HAL_ERR; // 未初始化，返回失败
    }     

	/* i2c2 */
	if (i2c_no == I2C2_ID)
	{
        I2C_Enable(g_hw_i2c_bus[i2c_no].module, DISABLE); 
        ret = HAL_OK;       
	}

	return ret;
}

#define I2CT_LONG_TIMEOUT 100*0x1000
/**
* @brief		I2C发数据 
* @param		[in] i2c_no 虚拟I2C端口号   
* @param		[in] dev_addr 设备地址  
* @param		[in] reg_addr 寄存器地址  
* @param		[in] reg_len 寄存器地址长度   
* @param		[in] buf 缓冲区指针  
* @param		[in] buf_len 缓冲区长度  
* @return		执行结果
* @retval		>0 发送数据长度(阻塞式)  
* @retval		=0 数据待发送(非阻塞式)，使用hal_i2c_query查询发送完成情况     
* @retval		<0 失败原因   
* @pre			执行hal_i2c_open后执行才有效 
*/
int32_t hal_hw_i2c_write(uint32_t i2c_no, uint16_t dev_addr, uint16_t reg_addr, uint8_t reg_len, uint8_t *buf, uint32_t buf_len)
{
	int32_t ret = HAL_ERR;
	hw_i2c_bus_t *i2c_bus;
    uint32_t I2CTimeout = I2CT_LONG_TIMEOUT;
    uint8_t stus = 0;    
	
    if (i2c_no >= I2C_MAX) 
	{
		return HAL_EPERM;
	}
	if (SF_GET_BIT(g_hw_i2c_status.is_init, (1U << i2c_no)) == 0)
    {
        return HAL_ERR; // 未初始化，返回失败
    }  
    
    if ((0 == buf_len)
        || (NULL == buf))
    {
        return HAL_ERR; // 入参有问题
    }

    i2c_bus = &g_hw_i2c_bus[i2c_no];

    stus++;
    I2CTimeout = I2CT_LONG_TIMEOUT;
    while (I2C_GetFlag(i2c_bus->module, I2C_FLAG_BUSY))
    {
        if ((I2CTimeout--) == 0)
        {
            //I2C_ClrFlag(i2c_bus->module, I2C_FLAG_BUSY);
            I2C_GenerateStop(i2c_bus->module, ENABLE);
            I2C_EnableSoftwareReset(i2c_bus->module, ENABLE);
            goto exit;
        }
    }

    stus++;
    I2C_GenerateStart(i2c_bus->module, ENABLE);
    I2CTimeout = I2CT_LONG_TIMEOUT;
    while (!I2C_CheckEvent(i2c_bus->module, I2C_EVT_MASTER_MODE_FLAG)) // EV5
    {
        if ((I2CTimeout--) == 0)
        {
            I2C_GenerateStop(i2c_bus->module, ENABLE);
            I2C_EnableSoftwareReset(i2c_bus->module, ENABLE);
            goto exit;
        }
    }
    
    stus++;
    I2C_SendAddr7bit(i2c_bus->module, dev_addr, I2C_DIRECTION_SEND);   
    I2CTimeout = I2CT_LONG_TIMEOUT;
    while (!I2C_CheckEvent(i2c_bus->module, I2C_EVT_MASTER_TXMODE_FLAG)) // EV6
    {
        if ((I2CTimeout--) == 0)
        {
            I2C_GenerateStop(i2c_bus->module, ENABLE);
            I2C_EnableSoftwareReset(i2c_bus->module, ENABLE);
            goto exit;
        }
    }

    /** Clear EV6 by setting again the PE bit */
    I2C_Enable(i2c_bus->module, ENABLE);
    stus++;
    /** Send the EEPROM's internal address to write to */
    if(REG_ADDR_TWO_BYTE == reg_len)
    {
        I2C_SendData(i2c_bus->module, (uint8_t)((reg_addr & 0xFF00) >> 8));  
        I2CTimeout = I2CT_LONG_TIMEOUT;
        while (!I2C_CheckEvent(i2c_bus->module, I2C_EVT_MASTER_DATA_SENDED))
        {
            if ((I2CTimeout--) == 0)
            {
                I2C_GenerateStop(i2c_bus->module, ENABLE);
                I2C_EnableSoftwareReset(i2c_bus->module, ENABLE);
                goto exit;
            }
        }
    }
    
    I2C_SendData(i2c_bus->module, (uint8_t)reg_addr);     
    I2CTimeout = I2CT_LONG_TIMEOUT;    
    while (!I2C_CheckEvent(i2c_bus->module, I2C_EVT_MASTER_DATA_SENDED))
    {
        if ((I2CTimeout--) == 0)
        {
            I2C_GenerateStop(i2c_bus->module, ENABLE);
            I2C_EnableSoftwareReset(i2c_bus->module, ENABLE);
            goto exit;
        }
    }
    
    stus++;
    // send data
    while (buf_len-- > 0)
    {
        I2C_SendData(i2c_bus->module, *buf++);
        I2CTimeout = I2CT_LONG_TIMEOUT;
        while (!I2C_CheckEvent(i2c_bus->module, I2C_EVT_MASTER_DATA_SENDED)) // EV8_2
        {
            if ((I2CTimeout--) == 0)
            {
                I2C_GenerateStop(i2c_bus->module, ENABLE);
                I2C_EnableSoftwareReset(i2c_bus->module, ENABLE);
                goto exit;
            }
        }
    }
    
    stus++;
    I2C_GenerateStop(i2c_bus->module, ENABLE);
    
    while (I2C_GetFlag(i2c_bus->module, I2C_FLAG_BUSY))
    {
        if ((I2CTimeout--) == 0)
        {
            //I2C_ClrFlag(i2c_bus->module, I2C_FLAG_BUSY);
            I2C_GenerateStop(i2c_bus->module, ENABLE);
            I2C_EnableSoftwareReset(i2c_bus->module, ENABLE);
            goto exit;
        }
    }  


    ret = HAL_OK;

    exit:


	if (HAL_OK == ret)
	{
		return HAL_OK;
	}
	else
	{
        rt_kprintf("[i2c]write reg%d,err:%d\n",reg_addr,stus);
        return ret;
	}
}

	

/**
* @brief		I2C读数据 
* @param		[in] i2c_no 虚拟I2C端口号   
* @param		[in] dev_addr 设备地址  
* @param		[in] reg_addr 寄存器地址  
* @param		[in] reg_len 寄存器地址长度   
* @param		[in] buf 缓冲区指针  
* @param		[in] buf_len 缓冲区长度  
* @return		执行结果
* @retval		>0 接收数据长度  
* @retval		=0 数据待接收(非阻塞式)，使用hal_i2c_query查询接收完成情况      
* @retval		<0 失败原因   
* @pre			执行hal_i2c_open后执行才有效 
*/
int32_t hal_hw_i2c_read(uint32_t i2c_no, uint16_t dev_addr, uint16_t reg_addr, uint8_t reg_len, uint8_t *buf, uint32_t buf_len)
{
    hw_i2c_bus_t *i2c_bus;
	int32_t ret = HAL_ERR;    
    uint32_t I2CTimeout = I2CT_LONG_TIMEOUT;
    uint8_t stus = 0;

    if (i2c_no >= I2C_MAX) 
	{
		return HAL_EPERM;
	}
	if (SF_GET_BIT(g_hw_i2c_status.is_init, (1U << i2c_no)) == 0)
    {
        return HAL_ERR; // 未初始化，返回失败
    }  

    if ((0 == buf_len)
        || (NULL == buf))
    {
        return HAL_ERR; // 入参有问题
    }
    
    i2c_bus = &g_hw_i2c_bus[i2c_no];
    
    stus++;    
    while (I2C_GetFlag(i2c_bus->module, I2C_FLAG_BUSY))
    {
        if ((I2CTimeout--) == 0)
        {
            //I2C_ClrFlag(i2c_bus->module, I2C_FLAG_BUSY);
            I2C_GenerateStop(i2c_bus->module, ENABLE);
            I2C_EnableSoftwareReset(i2c_bus->module, ENABLE);
            goto exit;
        }
    } 
    
    i2c_bus->module->CTRL1 &= ~0x0800; // clear POSEN
    I2C_ConfigAck(i2c_bus->module, ENABLE);

    // send start
    I2C_GenerateStart(i2c_bus->module, ENABLE);

    stus++;    
    I2CTimeout = I2CT_LONG_TIMEOUT;
    while (!I2C_CheckEvent(i2c_bus->module, I2C_EVT_MASTER_MODE_FLAG)) // EV5
    {
        if ((I2CTimeout--) == 0)
        {
            I2C_GenerateStop(i2c_bus->module, ENABLE);
            I2C_EnableSoftwareReset(i2c_bus->module, ENABLE);
            goto exit;
        }
    }
    
    /** Send EEPROM address for write */
    I2C_SendAddr7bit(i2c_bus->module, dev_addr, I2C_DIRECTION_SEND);
    stus++;
    /** Test on EV6 and clear it */
    I2CTimeout = I2CT_LONG_TIMEOUT;
    while (!I2C_CheckEvent(i2c_bus->module, I2C_EVT_MASTER_TXMODE_FLAG))
    {
        if ((I2CTimeout--) == 0)
        {
            I2C_GenerateStop(i2c_bus->module, ENABLE);
            I2C_EnableSoftwareReset(i2c_bus->module, ENABLE);
            goto exit;
        }
    }
    /** Clear EV6 by setting again the PE bit */
    I2C_Enable(i2c_bus->module, ENABLE);
    stus++;
    /** Send the EEPROM's internal address to write to */
    if(REG_ADDR_TWO_BYTE == reg_len)
    {
        I2C_SendData(i2c_bus->module, (uint8_t)((reg_addr & 0xFF00) >> 8));  
        I2CTimeout = I2CT_LONG_TIMEOUT;
        while (!I2C_CheckEvent(i2c_bus->module, I2C_EVT_MASTER_DATA_SENDED))
        {
            if ((I2CTimeout--) == 0)
            {
                I2C_GenerateStop(i2c_bus->module, ENABLE);
                I2C_EnableSoftwareReset(i2c_bus->module, ENABLE);
                goto exit;
            }
        }
    }
    
    I2C_SendData(i2c_bus->module, (uint8_t)reg_addr);     
    I2CTimeout = I2CT_LONG_TIMEOUT;    
    while (!I2C_CheckEvent(i2c_bus->module, I2C_EVT_MASTER_DATA_SENDED))
    {
        if ((I2CTimeout--) == 0)
        {
            I2C_GenerateStop(i2c_bus->module, ENABLE);
            I2C_EnableSoftwareReset(i2c_bus->module, ENABLE);
            goto exit;
        }
    }
    
    /** Send STRAT condition a second time */
    I2C_GenerateStart(i2c_bus->module, ENABLE);
    stus++;    
    /** Test on EV5 and clear it */
    I2CTimeout = I2CT_LONG_TIMEOUT;
    while (!I2C_CheckEvent(i2c_bus->module, I2C_EVT_MASTER_MODE_FLAG))
    {
        if ((I2CTimeout--) == 0)
        {
            I2C_GenerateStop(i2c_bus->module, ENABLE);
            I2C_EnableSoftwareReset(i2c_bus->module, ENABLE);
            goto exit;
        }
    }    
    
    
    // send addr
    I2C_SendAddr7bit(i2c_bus->module, dev_addr, I2C_DIRECTION_RECV);
    I2CTimeout = I2CT_LONG_TIMEOUT;
    stus++;    
    while (!I2C_CheckEvent(i2c_bus->module, I2C_EVT_MASTER_RXMODE_FLAG)) // EV6
    {
        if ((I2CTimeout--) == 0)
        {
            I2C_GenerateStop(i2c_bus->module, ENABLE);
            I2C_EnableSoftwareReset(i2c_bus->module, ENABLE);
            goto exit;
        }
    }
    
    stus++;    
    /** While there is data to be read */
    if (buf_len == 1)
    {
        /** Disable Acknowledgement */
        I2C_ConfigAck(i2c_bus->module, DISABLE);
        (void)(i2c_bus->module->STS1); /// clear ADDR
        (void)(i2c_bus->module->STS2);
        I2C_GenerateStop(i2c_bus->module, ENABLE);
    }
    else if (buf_len == 2)
    {
        i2c_bus->module->CTRL1 |= 0x0800; /// set POSEN
        (void)(i2c_bus->module->STS1);
        (void)(i2c_bus->module->STS2);
        I2C_ConfigAck(i2c_bus->module, DISABLE);
    }
    else
    {
        I2C_ConfigAck(i2c_bus->module, ENABLE);
        (void)(i2c_bus->module->STS1);
        (void)(i2c_bus->module->STS2);
    }
    while (buf_len)
    {
        if (buf_len <= 3)
        {
            /** One byte */
            if (buf_len == 1)
            {
                /** Wait until RXNE flag is set */
                I2CTimeout = I2CT_LONG_TIMEOUT;
                while (!I2C_GetFlag(i2c_bus->module, I2C_FLAG_RXDATNE))
                {
                    if ((I2CTimeout--) == 0)
                    {
                        I2C_GenerateStop(i2c_bus->module, ENABLE);
                        I2C_EnableSoftwareReset(i2c_bus->module, ENABLE);
                        goto exit;
                    }
                }
                /** Read data from DAT */
                /** Read a byte from the EEPROM */
                *buf = I2C_RecvData(i2c_bus->module);
                /** Point to the next location where the byte read will be saved */
                buf++;
                /** Decrement the read bytes counter */
                buf_len--;
            }
            /** Two bytes */
            else if (buf_len == 2)
            {
                /** Wait until BTF flag is set */
                I2CTimeout = I2CT_LONG_TIMEOUT;
                while (!I2C_GetFlag(i2c_bus->module, I2C_FLAG_BYTEF))
                {
                    if ((I2CTimeout--) == 0)
                    {
                        I2C_GenerateStop(i2c_bus->module, ENABLE);
                        I2C_EnableSoftwareReset(i2c_bus->module, ENABLE);
                        goto exit;
                    }
                }
                /** Send STOP Condition */
                I2C_GenerateStop(i2c_bus->module, ENABLE);

                /** Read data from DAT */
                *buf = I2C_RecvData(i2c_bus->module);
                /** Point to the next location where the byte read will be saved */
                buf++;
                /** Decrement the read bytes counter */
                buf_len--;
                /** Read data from DAT */
                *buf = I2C_RecvData(i2c_bus->module);
                /** Point to the next location where the byte read will be saved */
                buf++;
                /** Decrement the read bytes counter */
                buf_len--;
            }
            /** 3 Last bytes */
            else
            {
                I2CTimeout = I2CT_LONG_TIMEOUT;
                while (!I2C_GetFlag(i2c_bus->module, I2C_FLAG_BYTEF))
                {
                    if ((I2CTimeout--) == 0)
                    {
                        I2C_GenerateStop(i2c_bus->module, ENABLE);
                        I2C_EnableSoftwareReset(i2c_bus->module, ENABLE);
                        goto exit;
                    }
                }
                /** Disable Acknowledgement */
                I2C_ConfigAck(i2c_bus->module, DISABLE);
                /** Read data from DAT */
                *buf = I2C_RecvData(i2c_bus->module);
                /** Point to the next location where the byte read will be saved */
                buf++;
                /** Decrement the read bytes counter */
                buf_len--;

                /** Wait until BTF flag is set */
                I2CTimeout = I2CT_LONG_TIMEOUT;
                while (!I2C_GetFlag(i2c_bus->module, I2C_FLAG_BYTEF))
                {
                    if ((I2CTimeout--) == 0)
                    {
                        I2C_GenerateStop(i2c_bus->module, ENABLE);
                        I2C_EnableSoftwareReset(i2c_bus->module, ENABLE);
                        goto exit;
                    }
                }
                /** Send STOP Condition */
                I2C_GenerateStop(i2c_bus->module, ENABLE);

                /** Read data from DAT */
                *buf = I2C_RecvData(i2c_bus->module);
                /** Point to the next location where the byte read will be saved */
                buf++;
                /** Decrement the read bytes counter */
                buf_len--;

                /** Read data from DAT */
                *buf = I2C_RecvData(i2c_bus->module);
                /** Point to the next location where the byte read will be saved */
                buf++;
                /** Decrement the read bytes counter */
                buf_len--;
            }
        }
        else
        {
            /** Test on EV7 and clear it */
            I2CTimeout = I2CT_LONG_TIMEOUT;
            while (!I2C_CheckEvent(i2c_bus->module, I2C_EVT_MASTER_DATA_RECVD_FLAG))
            {
                if ((I2CTimeout--) == 0)
                {
                    I2C_GenerateStop(i2c_bus->module, ENABLE);
                    I2C_EnableSoftwareReset(i2c_bus->module, ENABLE);
                    goto exit;
                }
            }
            /** Read a byte from the EEPROM */
            *buf = I2C_RecvData(i2c_bus->module);
            /** Point to the next location where the byte read will be saved */
            buf++;
            /** Decrement the read bytes counter */
            buf_len--;
            if (I2C_GetFlag(i2c_bus->module, I2C_FLAG_BYTEF))
            {
                /** Read a byte from the EEPROM */
                *buf = I2C_RecvData(i2c_bus->module);
                /** Point to the next location where the byte read will be saved */
                buf++;
                /** Decrement the read bytes counter */
                buf_len--;
            }
        }
    }
    
    while (I2C_GetFlag(i2c_bus->module, I2C_FLAG_BUSY))
    {
        if ((I2CTimeout--) == 0)
        {
            //I2C_ClrFlag(i2c_bus->module, I2C_FLAG_BUSY);
            I2C_GenerateStop(i2c_bus->module, ENABLE);
            I2C_EnableSoftwareReset(i2c_bus->module, ENABLE);
            goto exit;
        }
    } 
    
    ret = HAL_OK;

    exit:


	if (HAL_OK == ret)
	{
		return HAL_OK;
	}
	else
	{
        rt_kprintf("[i2c]read reg:%d,err:%d\n",reg_addr,stus);
        return ret;
	}
}


#define EEPROM_ADDR 0xa0
#define EEPROM_I2C_NO 0


#define sEE_MAX_TRIALS_NUMBER 10
/**
 * @brief  Wait eeprom standby state.
 */
int32_t I2C_EE_WaitEepromStandbyState(uint32_t i2c_no, uint16_t dev_addr)
{
    __IO uint16_t tmpSR1    = 0;
    __IO uint32_t sEETrials = 0;   
    uint32_t I2CTimeout = I2CT_LONG_TIMEOUT;   
    hw_i2c_bus_t *i2c_bus;
	int32_t ret = HAL_ERR;    
    uint8_t stus = 0;

    if (i2c_no >= I2C_MAX) 
	{
		return HAL_EPERM;
	}
	if (SF_GET_BIT(g_hw_i2c_status.is_init, (1U << i2c_no)) == 0)
    {
        return HAL_ERR; // 未初始化，返回失败
    }  

    i2c_bus = &g_hw_i2c_bus[i2c_no];
    
    stus++;
    while (I2C_GetFlag(i2c_bus->module, I2C_FLAG_BUSY))
    {
        if ((I2CTimeout--) == 0)
        {
            //I2C_ClrFlag(i2c_bus->module, I2C_FLAG_BUSY);
            I2C_GenerateStop(i2c_bus->module, ENABLE);
            I2C_EnableSoftwareReset(i2c_bus->module, ENABLE);

            goto exit;
        }
    } 

    /** Keep looping till the slave acknowledge his address or maximum number
       of trials is reached (this number is defined by sEE_MAX_TRIALS_NUMBER) */
    stus++;
    while (1)
    {
        /** Send START condition */
        I2C_GenerateStart(i2c_bus->module, ENABLE);

        stus = 3;
        /** Test on EV5 and clear it */
        I2CTimeout = I2CT_LONG_TIMEOUT;
        while (!I2C_CheckEvent(i2c_bus->module, I2C_EVT_MASTER_MODE_FLAG))
        {
            if ((I2CTimeout--) == 0)
            {
                I2C_GenerateStop(i2c_bus->module, ENABLE);
                I2C_EnableSoftwareReset(i2c_bus->module, ENABLE);
                goto exit;
            }
        }

        stus = 4;
        /** Send EEPROM address for write */
        I2C_SendAddr7bit(i2c_bus->module, dev_addr, I2C_DIRECTION_SEND);
        /** Wait for ADDR flag to be set (Slave acknowledged his address) */
        I2CTimeout = I2CT_LONG_TIMEOUT;
        do
        {
            /** Get the current value of the STS1 register */
            tmpSR1 = i2c_bus->module->STS1;

            /** Update the timeout value and exit if it reach 0 */
            if ((I2CTimeout--) == 0)
            {
                I2C_GenerateStop(i2c_bus->module, ENABLE);
                I2C_EnableSoftwareReset(i2c_bus->module, ENABLE);
                goto exit;
            }
        }
        /** Keep looping till the Address is acknowledged or the AF flag is
           set (address not acknowledged at time) */

        while ((tmpSR1 & (I2C_STS1_ADDRF | I2C_STS1_ACKFAIL)) == 0);

        stus = 5;
        /** Check if the ADDR flag has been set */
        if (tmpSR1 & I2C_STS1_ADDRF)
        {
            /** Clear ADDR Flag by reading STS1 then STS2 registers (STS1 have already
               been read) */
            (void)i2c_bus->module->STS2;

            /** STOP condition */
            I2C_GenerateStop(i2c_bus->module, ENABLE);

            /** Exit the function */
            ret = HAL_OK;
            goto exit;
        }
        else
        {
            /** Clear AF flag */
            I2C_ClrFlag(i2c_bus->module, I2C_FLAG_ACKFAIL);
        }

        os_delay(1);
        
        stus = 6;
        /** Check if the maximum allowed numbe of trials has bee reached */
        if (sEETrials++ == sEE_MAX_TRIALS_NUMBER)
        {
            /** If the maximum number of trials has been reached, exit the function */
            I2C_GenerateStop(i2c_bus->module, ENABLE);
            I2C_EnableSoftwareReset(i2c_bus->module, ENABLE);
            goto exit;
        }
    }

    exit:


	if (HAL_OK == ret)
	{
		return HAL_OK;
	}
	else
	{
        rt_kprintf("[i2c]wait eeprom err:%d\n",stus);
        return ret;
	}    
}

void eeprom_write_n_byte(uint16_t reg_addr, uint8_t reg_len, uint8_t* buf, uint16_t buf_len)
{
    for(uint16_t i = 0; i < buf_len; i++)
    {
        hal_hw_i2c_write(EEPROM_I2C_NO, EEPROM_ADDR, reg_addr, reg_len, buf++, 1);
        I2C_EE_WaitEepromStandbyState(EEPROM_I2C_NO,EEPROM_ADDR);
        reg_addr++;
    }
}

void eeprom_read_n_byte(uint16_t reg_addr, uint8_t reg_len, uint8_t* buf, uint16_t buf_len)
{

    hal_hw_i2c_read(EEPROM_I2C_NO, EEPROM_ADDR, reg_addr, reg_len, buf, buf_len);

}

void test_i2c_eeprom(int argc, char *argv[])
{
    int addr,len,data = 0;
    uint8_t buff[256] = {0};
    static uint8_t init_flag = false;
    
    if(false == init_flag)
    {
        hal_hw_i2c_init();
        hal_hw_i2c_open(EEPROM_I2C_NO);
        init_flag = true;
    }
 
    if (argc > 2)
    {
		if (strcmp(argv[1], "set") == 0)
        {
            addr = atoi(argv[2]);
            len = atoi(argv[3]);
            data= atoi(argv[4]);
            buff[0] = data;
            for (int i = 1; i < sizeof(buff); i++)
            {
            	buff[i] = buff[0] + i;
            }
            eeprom_write_n_byte(addr, REG_ADDR_TWO_BYTE, buff, len);


        }
        else if (strcmp(argv[1], "get") == 0)
        {
            addr = atoi(argv[2]);
            len = atoi(argv[3]);
			eeprom_read_n_byte(addr, REG_ADDR_TWO_BYTE, buff , len);
            log_hexdump("eeprom data", 16, buff, len);
        }
	}
}

MSH_CMD_EXPORT(test_i2c_eeprom, test i2c eeprom<set 1 2 3/get 1 2>);






