#include <rtthread.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "sfud.h"
#include "log.h"
#include "hal_flash.h"

static const sfud_flash *gp_flash = NULL;

/**
* @brief		FLASH加载驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_flash_init(void)
{
    if (sfud_init() != SFUD_SUCCESS) 
    {
        return HAL_ENXIO;
    }
    
    gp_flash = sfud_get_device_table();
    
	return HAL_OK;
}
//INIT_DEVICE_EXPORT(hal_flash_init);


/**
* @brief		FLASH删除驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_flash_deinit(void)
{
 
	return HAL_OK;
}


/**
* @brief		获取flash信息 
* @param		[in] dev_no 设备端口号 
-# HAL_FLASH_ID_INT = 内部Flash 
-# HAL_FLASH_ID_EXT = 外部Flash  
* @param		[in] info flash信息结构体  
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		HAL_EIO 失败   
*/
int32_t hal_flash_get_info(uint32_t dev_no, hal_flash_info_t *info)
{
    if (gp_flash == NULL)
        return HAL_EIO;
    
    info->total_size = gp_flash->chip.capacity;
    info->sector_size = gp_flash->chip.erase_gran;
    
    return HAL_OK;
}


/**
* @brief		获取flash唯一ID  
* @param		[in] dev_no 设备端口号  
-# HAL_FLASH_ID_INT = 内部Flash 
-# HAL_FLASH_ID_EXT = 外部Flash  
* @param		[in] id 存储buffer   
* @param		[in] len buffer深度   
* @return		执行结果
* @retval		>=0 读取id长度  
* @retval		<0 失败原因  
*/
int32_t hal_flash_get_sn(uint32_t dev_no, uint8_t *id, uint32_t len)
{
    
    if (gp_flash == NULL)
        return HAL_EIO;
    
    memset(id, 0 ,len);
    
    if (len >= 1)
    {
        id[0] = gp_flash->chip.capacity_id;
    }
    
    if (len >= 2)
    {
        id[0] = gp_flash->chip.mf_id;
    }
    
    if (len >= 3)
    {
        id[0] = gp_flash->chip.type_id;
    }
    
    return HAL_OK;
}

/**
* @brief		写数据
* @param		[in] dev_no 设备端口号  
-# HAL_FLASH_ID_INT = 内部Flash 
-# HAL_FLASH_ID_EXT = 外部Flash  
* @param		[in] offset flash地址偏移   
* @param		[in] len buffer深度   
* @param		[in] buf 写入数据缓冲区  
* @return		执行结果
* @retval		>=0 读取id长度  
* @retval		<0 失败原因  
*/
int32_t hal_flash_write(uint32_t dev_no, uint32_t offset, uint32_t len, uint8_t *buf)
{
    sfud_err result;
    
    if (gp_flash == NULL)
        return HAL_EIO;
    
    result = sfud_write(gp_flash, offset, len, buf);
    
    if (result == SFUD_SUCCESS) 
    {
        return len;
    }
    else
    {
        return HAL_ERR;
    }
}

/**
* @brief		读数据
* @param		[in] dev_no 设备端口号 
-# HAL_FLASH_ID_INT = 内部Flash 
-# HAL_FLASH_ID_EXT = 外部Flash  
* @param		[in] offset flash地址偏移   
* @param		[in] len buffer深度   
* @param		[in] buf 写入数据缓冲区  
* @return		执行结果
* @retval		>=0 读取长度  
* @retval		<0 失败原因  
*/
int32_t hal_flash_read(uint32_t dev_no, uint32_t offset, uint32_t len, uint8_t *buf)
{
    sfud_err result;
    
    if (gp_flash == NULL)
        return HAL_EIO;
    
    result = sfud_read(gp_flash, offset, len, buf);
    
    if (result == SFUD_SUCCESS) 
    {
        return len;
    }
    else
    {
        return HAL_ERR;
    }
}

/**
* @brief		擦除 
* @param		[in] dev_no 设备端口号  
-# HAL_FLASH_ID_INT = 内部Flash 
-# HAL_FLASH_ID_EXT = 外部Flash  
* @param		[in] offset flash地址偏移    
* @param		[in] len buffer深度   
* @return		执行结果
* @retval		>=0 读取id长度  
* @retval		<0 失败原因  
*/
int32_t hal_flash_erase(uint32_t dev_no, uint32_t offset, uint32_t len)
{
    sfud_err result;
    
    if (gp_flash == NULL)
        return HAL_EIO;
    
    result = sfud_erase(gp_flash, offset, len);
    
    if (result == SFUD_SUCCESS) 
    {
        return len;
    }
    else
    {
        return HAL_ERR;
    }
}

/**
* @brief		扩展功能 
* @param		[in] dev_no 设备端口号  
* @param		[in] cmd 控制命令  
* @param		[in] arg 控制参数   
* @return		执行结果
* @retval		HAL_OK 成功    
* @retval		<0 失败原因  
*/
int32_t hal_flash_ioctl(int32_t dev_no, uint8_t cmd, void* arg)
{
    
    
    return HAL_ERR;
}




#if 0


static void sfud_demo(uint32_t addr, size_t size, uint8_t *data) {
    sfud_err result = SFUD_SUCCESS;
    const sfud_flash *flash = sfud_get_device_table() + 0;
    size_t i;
    /* prepare write data */
    for (i = 0; i < size; i++) {
        data[i] = i;
    }
    /* erase test */
    result = sfud_erase(flash, addr, size);
    if (result == SFUD_SUCCESS) {
        rt_kprintf("Erase the %s flash data finish. Start from 0x%08X, size is %ld.\r\n", flash->name, addr,
                size);
    } else {
        rt_kprintf("Erase the %s flash data failed.\r\n", flash->name);
        return;
    }
    /* write test */
    result = sfud_write(flash, addr, size, data);
    if (result == SFUD_SUCCESS) {
        rt_kprintf("Write the %s flash data finish. Start from 0x%08X, size is %ld.\r\n", flash->name, addr,
                size);
    } else {
        rt_kprintf("Write the %s flash data failed.\r\n", flash->name);
        return;
    }
    /* read test */
    result = sfud_read(flash, addr, size, data);
    if (result == SFUD_SUCCESS) {
        rt_kprintf("Read the %s flash data success. Start from 0x%08X, size is %ld. The data is:\r\n", flash->name, addr,
                size);
        rt_kprintf("Offset (h)\t00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F");
        for (i = 0; i < size; i++) {
            if (i % 16 == 0) {
                rt_kprintf("\r\n[%08X]\t", addr + i);
            }
            rt_kprintf("%02X ", data[i]);
//            if (((i + 1) % 16 == 0) || i == size - 1) {
//                rt_kprintf("\r\n");
//            }
        }
        rt_kprintf("\r\n");
    } else {
        rt_kprintf("Read the %s flash data failed.\r\n", flash->name);
    }
    /* data check */
    for (i = 0; i < size; i++) {
        if (data[i] != i % 256) {
            rt_kprintf("Read and check write data has an error. Write the %s flash data failed.\r\n", flash->name);
			break;
        }
    }
    if (i == size) {
        rt_kprintf("The %s flash test is success.\r\n", flash->name);
    }
}



#define SFUD_DEMO_TEST_BUFFER_SIZE                     1024

static uint8_t sfud_demo_test_buf[SFUD_DEMO_TEST_BUFFER_SIZE];


void test_flash(int argc, char *argv[])
{
    
    
    
    if (sfud_init() == SFUD_SUCCESS) {
        sfud_demo(0, sizeof(sfud_demo_test_buf), sfud_demo_test_buf);
    }
 
}

MSH_CMD_EXPORT(test_flash, test spi flash);
#endif







