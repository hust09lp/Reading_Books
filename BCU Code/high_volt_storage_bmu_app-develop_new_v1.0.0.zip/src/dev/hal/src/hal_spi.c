#include <board.h>
#include <rtthread.h>
#include <rtdevice.h>
#include "hal_spi.h"
#include "hal_gpio.h"
#include "string.h"
#include "log.h"
#include "n32g45x_spi.h"


/**
* @struct gpio管脚定义
* @brief  定义gpio对应的module和pin
*/
typedef struct 
{
    GPIO_Module* GPIOx;
    uint16_t GPIO_Pin;
}gpio_pin_t;


/**
* @struct spi数据信息结构体
* @brief  定义gpio对应的module和pin
*/
typedef struct 
{
	SPI_Module* SPIx;	
    uint8_t set_gpio_af;
    uint32_t clk;
    uint32_t mosi;
    uint32_t miso;
}spi_info_t;


/**
* @struct spi参数配置信息
* @brief  分别配置spi1/spi2/spi3对应的clk、mosi、miso
*/
const spi_info_t g_spi_info[] = 
{  
	//spi设备号		clk管脚		mosi管脚	miso管脚
	{SPI1, NULL, SPI1_CLK_PIN, SPI1_MOSI_PIN, SPI1_MISO_PIN},
	{SPI2, NULL, MAX_PIN,       MAX_PIN,        MAX_PIN},
	{SPI3, NULL, SPI3_CLK_PIN, SPI3_MOSI_PIN, SPI3_MISO_PIN},
};

// 标识SPI状态
static uint8_t g_spi_status;


/**
* @brief		spi gpio初始化
* @param		[in] *spi_info 需要初始化的gpio参数信息结构体  
* @param		[in] mode spi模式，master and slave
* @return		void
* @pre			内部函数，在n32_spi_init中调用
*/
static void spi_gpio_init(const spi_info_t *p_spi_info, uint8_t mode)
{
    
	GPIO_InitType GPIO_InitStructure;

    /* Configure SPIy pins: SCK, MISO and MOSI ---------------------------------*/
    GPIO_InitStructure.Pin        = PIN_STPIN(p_spi_info->clk) | PIN_STPIN(p_spi_info->mosi);
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

	/* master mode */
    if (mode == HAL_SPI_MASTER)
    {
        /* Configure SCK and MOSI pins as Alternate Function Push Pull */
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    }
    else
    {
        /* Configure SCK and MOSI pins as Input Floating */
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    }
    GPIO_InitPeripheral(PIN_STPORT(p_spi_info->mosi), &GPIO_InitStructure);

    GPIO_InitStructure.Pin = PIN_STPIN(p_spi_info->miso);

    if (mode == HAL_SPI_MASTER)
    {
        /* Configure MISO pin as Input Floating  */
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    }
    else
    {
        /* Configure MISO pin as Alternate Function Push Pull */
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    }
    GPIO_InitPeripheral(PIN_STPORT(p_spi_info->miso), &GPIO_InitStructure);
}



/**
* @brief		spi初始化
* @param		[in] dev_no 虚拟spi设备号  
* @param		[in] *p_cfg模式，spi初始化配置参数，详见hal_spi_config_t结构体定义
* @return		void
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
* @pre			执行hal_uart_init后执行才有效。
*/
static int32_t n32_spi_init(uint32_t dev_no, hal_spi_config_t *p_cfg)
{
    SPI_InitType SPI_InitStructure;

	
    SPI_InitStructure.DataDirection = SPI_DIR_DOUBLELINE_FULLDUPLEX;
    SPI_InitStructure.CRCPoly       = 7;
    
	/* master mode */
    if (p_cfg->work_mode == HAL_SPI_MASTER)
    {
        SPI_InitStructure.SpiMode       = SPI_MODE_MASTER;
		spi_gpio_init(&g_spi_info[dev_no], HAL_SPI_MASTER);
    }
	/* slave mode */
    else
    {
		SPI_InitStructure.SpiMode       = SPI_MODE_SLAVE;
		spi_gpio_init(&g_spi_info[dev_no], HAL_SPI_SLAVE);
    }
 
    if (p_cfg->data_width == 8)
    {
        SPI_InitStructure.DataLen       = SPI_DATA_SIZE_8BITS;
    }
    else if (p_cfg->data_width == 16)
    {
        SPI_InitStructure.DataLen       = SPI_DATA_SIZE_16BITS;
    }
    else
    {
        return HAL_EIO;
    }
    
	/* trans变化模式 */
    switch (p_cfg->trans_mode)
	{
		case HAL_SPI_MODE_0:
			SPI_InitStructure.CLKPHA        = SPI_CLKPHA_FIRST_EDGE;
			SPI_InitStructure.CLKPOL        = SPI_CLKPOL_LOW;
			break;
		case HAL_SPI_MODE_1:
			SPI_InitStructure.CLKPHA        = SPI_CLKPHA_SECOND_EDGE;
			SPI_InitStructure.CLKPOL        = SPI_CLKPOL_LOW;
			break;
		case HAL_SPI_MODE_2:
			SPI_InitStructure.CLKPHA        = SPI_CLKPHA_FIRST_EDGE;
			SPI_InitStructure.CLKPOL        = SPI_CLKPOL_HIGH;
			break;
		case HAL_SPI_MODE_3:
			SPI_InitStructure.CLKPHA        = SPI_CLKPHA_SECOND_EDGE;
			SPI_InitStructure.CLKPOL        = SPI_CLKPOL_HIGH;
			break;
		default:
			return HAL_EIO;	
	}

    uint32_t spi_apb_clock;
	RCC_ClocksType clk;
	
    RCC_GetClocksFreqValue(&clk);
	spi_apb_clock = clk.Pclk2Freq;

    if (p_cfg->max_hz >= spi_apb_clock / 2)
    {
		SPI_InitStructure.BaudRatePres  = SPI_BR_PRESCALER_2;
    }
    else if (p_cfg->max_hz >= spi_apb_clock / 4)
    {
		SPI_InitStructure.BaudRatePres  = SPI_BR_PRESCALER_4;
    }
    else if (p_cfg->max_hz >= spi_apb_clock / 8)
    {
		SPI_InitStructure.BaudRatePres  = SPI_BR_PRESCALER_8;
    }
    else if (p_cfg->max_hz >= spi_apb_clock / 16)
    {
		SPI_InitStructure.BaudRatePres  = SPI_BR_PRESCALER_16;
    }
    else if (p_cfg->max_hz >= spi_apb_clock / 32)
    {
		SPI_InitStructure.BaudRatePres  = SPI_BR_PRESCALER_32;
    }
    else if (p_cfg->max_hz >= spi_apb_clock / 64)
    {
		SPI_InitStructure.BaudRatePres  = SPI_BR_PRESCALER_64;
    }
    else if (p_cfg->max_hz >= spi_apb_clock / 128)
    {
		SPI_InitStructure.BaudRatePres  = SPI_BR_PRESCALER_128;
    }
    else
    {
        /*  min prescaler 256 */
		SPI_InitStructure.BaudRatePres  = SPI_BR_PRESCALER_256;
    }

    log_d("sys freq: %d, pclk2 freq: %d, SPI limiting freq: %d, BaudRatePrescaler: %d\r\n",
           clk.SysclkFreq,
           spi_apb_clock,
           p_cfg->max_hz,
           SPI_InitStructure.BaudRatePres);

    if (p_cfg->first_bit == HAL_SPI_FIRSTBIT_MSB)
    {
		SPI_InitStructure.FirstBit      = SPI_FB_MSB;
    }
    else
    {
		SPI_InitStructure.FirstBit      = SPI_FB_LSB;
    }

	SPI_InitStructure.NSS           = SPI_NSS_SOFT;


	SPI_Init(g_spi_info[dev_no].SPIx, &SPI_InitStructure);
	SPI_Enable(g_spi_info[dev_no].SPIx, ENABLE);
    
    return HAL_OK;
}


static uint8_t SPI_SendByte(uint32_t dev_no, uint8_t byte)
{
    /*!< Loop while DAT register in not emplty */
    while (SPI_I2S_GetStatus(g_spi_info[dev_no].SPIx, SPI_I2S_TE_FLAG) == RESET)
        ;

    /*!< Send byte through the SPI1 peripheral */
    SPI_I2S_TransmitData(g_spi_info[dev_no].SPIx, byte);

    /*!< Wait to receive a byte */
    while (SPI_I2S_GetStatus(g_spi_info[dev_no].SPIx, SPI_I2S_RNE_FLAG) == RESET)
        ;

    /*!< Return the byte read from the SPI bus */
    return SPI_I2S_ReceiveData(g_spi_info[dev_no].SPIx);
}





/**
* @brief		SPI加载驱动
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
*/
int32_t hal_spi_init(void)
{
	/* PCLK2 = HCLK/2 */
    RCC_ConfigPclk2(RCC_HCLK_DIV2);
	g_spi_status = 0;
	
	return HAL_OK;
}

INIT_BOARD_EXPORT(hal_spi_init);

/**
* @brief		SPI删除驱动
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
*/
int32_t hal_spi_deinit(void)
{
	return HAL_OK;
}

/**
* @brief		打开SPI功能 
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @warning 		本接口只初始化SPI总线接口 
*/
int32_t hal_spi_open(uint32_t dev_no)
{
	/* 虚拟设备端口号合法检查 */
	if (dev_no >= SPI_MAX) 
	{
		return HAL_EIO;
	}
	/* 设备已打开，直接返回ok,避免重复打开 */
	if (GET_BIT(g_spi_status, (1U << dev_no)) != 0)
    {
        return HAL_OK;
    }
	
	/* spi1 */
	if (dev_no == SPI1_ID)
	{
		RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOA | RCC_APB2_PERIPH_SPI1, ENABLE);
	}
	/* spi2 */
	else if(dev_no == SPI2_ID)
	{
		RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE);
		RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_SPI2, ENABLE);
	}
	/* spi3 */
	else
	{
		RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE);
		RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_SPI3, ENABLE);
	}	
	
	SET_BIT(g_spi_status, (1U << dev_no));
	return HAL_OK;
}

/**
* @brief		关闭SPI功能 
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_spi_close(uint32_t dev_no)
{
	/* 虚拟设备端口号合法检查 */
	if (dev_no >= SPI_MAX) 
	{
		return HAL_EIO;
	}
	/* 设备已关闭，直接返回ok,避免重复关闭 */
	if (GET_BIT(g_spi_status, (1u << dev_no)) == 0)
    {
        return HAL_OK;
    }
	
    SPI_I2S_DeInit(g_spi_info[dev_no].SPIx);
	
    CLR_BIT(g_spi_status, (1u << dev_no));
	return HAL_OK;
}

/**
* @brief		SPI功能从休眠中唤醒，恢复状态
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_spi_resume(uint32_t dev_no)
{
	return hal_spi_open(dev_no);
}
 
/**
* @brief		SPI功能进入休眠模式
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式，功能不影响
*/
int32_t hal_spi_suspend(uint32_t dev_no)
{
	return hal_spi_close(dev_no);
}


/**
* @brief		设置SPI属性  
* @param		[in] dev_no 设备端口号
* @param		[in] p_config SPI配置参数  
* - config->work_mode 使用模式
* -# HAL_SPI_MASTER = 主模式
* -# HAL_SPI_SLAVE = 从模式
* - config->trans_mode 使用模式
* -# HAL_SPI_MODE_0 = CPOL:0|CPHA:0
* -# HAL_SPI_MODE_1 = CPOL:0|CPHA:1
* -# HAL_SPI_MODE_2 = CPOL:1|CPHA:0
* -# HAL_SPI_MODE_3 = CPOL:1|CPHA:1 
* - config->data_width SPI发送数据位
* - config->first_bit SPI通信长度
* -# HAL_SPI_FIRSTBIT_MSB 
* -# HAL_SPI_FIRSTBIT_LSB
* - config->max_hz SPI频率
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @pre 			执行hal_spi_open后执行才有效。 
@code 
		CPOL 	CPHA
MODE0 	0 		0
MODE1 	0 		1
MODE2 	1 		0
MODE3 	1 		1
CPOL: SPI空闲时的时钟信号电平(1:高电平, 0:低电平)
CPHA: SPI在时钟第几个边沿采样(1:第二个边沿开始, 0:第一个边沿开始)
@endcode
*/
int32_t hal_spi_setup(uint32_t dev_no, hal_spi_config_t *p_config)
{
	/* 虚拟设备端口号合法检查 */
	if (dev_no >= SPI_MAX) 
	{
		return HAL_EIO;
	}
	/* 设备未打开，返回失败 */
	if (GET_BIT(g_spi_status, (1u << dev_no)) == 0)
    {
        return HAL_EPERM;
    }
    
	return n32_spi_init(dev_no, p_config);
}



/**
* @brief		SPI发数据 
* @param		[in] dev_no 设备端口号
* @param		[in] p_buf 缓冲区指针    
* @param		[in] len 缓冲区长度    
* @return		执行结果
* @retval		>0 发送数据长度(阻塞式)  
* @retval		=0 数据待发送(非阻塞式)，使用hal_spi_query查询发送完成情况  
* @retval		<0 失败原因   
* @pre 			执行hal_spi_open后执行才有效。 
*/
int32_t hal_spi_write(uint32_t dev_no, void *p_buf, uint32_t len)
{
    
	/* 虚拟设备端口号合法检查 */
	if (dev_no >= SPI_MAX) 
	{
		return HAL_EIO;
	}
	/* 设备未打开，返回失败 */
	if (GET_BIT(g_spi_status, (1u << dev_no)) == 0)
    {
        return HAL_ENXIO;
    }
    
    int i;
    uint8_t *byte = (uint8_t *) p_buf;
    for (i = 0; i < len; i++) {
        SPI_SendByte(dev_no, *byte);
        byte++;
    }
    return i;

}

/**
* @brief		SPI发数据 
* @param		[in] dev_no 设备端口号
* @param		[in] p_buf 缓冲区指针    
* @param		[in] len 缓冲区长度    
* @return		执行结果
* @retval		>0 接收数据长度
* @retval		=0 数据待接收(非阻塞式)，使用hal_spi_query查询接收完成情况 
* @retval		<0 失败原因 
* @pre 			执行hal_spi_open后执行才有效。 
*/
int32_t hal_spi_read(uint32_t dev_no, void *p_buf, uint32_t len)
{


	/* 设备未打开，返回失败 */
	if (GET_BIT(g_spi_status, (1u << dev_no)) == 0)
    {
        return HAL_ENXIO;
    }

    int      i;
    uint8_t *byte = (uint8_t *) p_buf;
    for (i = 0; i < len; i++) {
        *byte = SPI_SendByte(dev_no,0xFF);
        byte++;
    }
    return i;

}

/**
* @brief		清空收缓冲区数据（预留）
* @param		[in] dev_no 设备端口号    
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		<0 失败原因 
* @pre 			执行hal_spi_open后执行才有效。 
*/
int32_t hal_spi_flush(uint32_t dev_no)
{
	return HAL_OK;
}

/**
* @brief		查询是否发送完毕 
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @return		执行结果
* @retval		HAL_OK 成功 
* @retval		=0 发送完毕
* @retval		<0 失败原因 
* @pre 			执行hal_spi_open后执行才有效。 
*/
int32_t hal_spi_query(uint32_t dev_no)
{
	/* 虚拟设备端口号合法检查 */
	if (dev_no >= SPI_MAX) 
	{
		return HAL_EIO;
	}
	
	if (SPI_I2S_GetStatus(g_spi_info[dev_no].SPIx, SPI_I2S_TE_FLAG) == SET)
	{
		return HAL_OK;
	}
	
	return HAL_EPERM;
}

/**
* @brief		配置SPI中断函数（预留）
* @param		[in] dev_no 设备端口号 
* @param		[in] p_tx_fcallback 发送中断回调函数 
* @param		[in] p_rx_fcallback 接收中断回调函数  
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		<0 失败原因   
* @pre 			执行hal_spi_open后执行才有效。 
*/
int32_t hal_spi_set_irq(uint32_t dev_no, irq_spi_callback p_tx_fcallback, irq_spi_callback p_rx_fcallback)
{
	/* 虚拟设备端口号合法检查 */
	if (dev_no >= SPI_MAX) 
	{
		return HAL_EIO;
	}
	
	return HAL_OK;
}


/**
* @brief		关闭SPI中断（预留）
* @param		[in] dev_no 设备端口号    
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		<0 失败原因   
* @pre 			执行hal_spi_open后执行才有效。 
*/
int32_t hal_spi_free_irq(uint32_t dev_no)
{
	/* 虚拟设备端口号合法检查 */
	if (dev_no >= SPI_MAX) 
	{
		return HAL_EIO;
	}
	
	return HAL_OK;
}

/**
 * @brief		扩展功能（预留）
 * @param		[in] dev_no 设备端口号
 * @param		[in] cmd 控制命令
 * @param		[in] p_arg 控制参数
 * @return		执行结果
 * @retval		HAL_OK(0) 成功
 * @retval		<0 失败原因
 */
int32_t hal_spi_ioctl(uint32_t dev_no, uint32_t cmd, void* p_arg) 
{
    
    #define AFE_79600_MOSI_GPIO_INIT 0x1000
    #define AFE_79600_MOSI_CTRL      0x1001
	#define AFE_79600_MOSI_PIN       SPI1_MOSI_PIN
    uint32_t *argv = (uint32_t*)p_arg;
    hal_gpio_config_t gpio_config = {HAL_GPIO_OUTPUT, HAL_GPIO_NOPULL};
    
    if (dev_no >= SPI_MAX) 
	{
		return HAL_EIO;
	}
    
    if (AFE_79600_MOSI_GPIO_INIT == cmd)
    {
        hal_gpio_config(AFE_79600_MOSI_PIN, &gpio_config);
    }
    
    else if (AFE_79600_MOSI_CTRL == cmd)
    {
        if (0 == *argv)
        {
           hal_gpio_write(AFE_79600_MOSI_PIN, HAL_GPIO_LOW);         
        }
        else
        {
            hal_gpio_write(AFE_79600_MOSI_PIN, HAL_GPIO_HIGH);
        }
        
    }
    else
    {
        return HAL_EPERM;
    }

    return HAL_OK;
}

//uint8_t txTestBuf[256];
//uint8_t rxTestBuf[256];
///*test the spi function when you try to translate in a new platform*/
//uint32_t spi_test_tx(void)
//{
//    uint32_t i;
//    uint32_t txBytes=256;

//    for(i=0;i<txBytes;i++)
//    {
//        txTestBuf[i]=i;
//    }
//    
//    hal_spi_write(SPI1_ID,txTestBuf,64);
//    
//}

//uint32_t spi_test_rx(void)
//{
//    uint32_t i;
//    uint32_t rxBytes=256;

//    for(i=0;i<rxBytes;i++)
//    {
//        txTestBuf[i]=0;
//    }
//    
//    hal_spi_read(SPI1_ID,txTestBuf,64);
//    
//}

//static int hal_spi_sample(int argc, char *p_argv[])
//{
//    hal_spi_config_t config = {0};
//	char     *opt  = p_argv[1];
//	uint32_t port  = atoi(p_argv[2]);
//	uint32_t opt_cnt = atoi(p_argv[3]);
//    
//    static bool is_init = false;
//    
//    if(false == is_init)
//    {
//        if (0 != hal_spi_open(SPI1_ID))
//        {
//            log_d("spi_open error...\n");
//            return -1;
//        }

//        config.work_mode = HAL_SPI_MASTER;
//        config.trans_mode = HAL_SPI_MODE_0;
//        config.data_width = HAL_SPI_8BIT;
//        config.first_bit = HAL_SPI_FIRSTBIT_MSB;
//        config.max_hz = 3 * 1000 * 1000;

//        if (0 != hal_spi_setup(SPI1_ID, &config))
//        {
//            log_d("spi_setup error...\n");
//            return -2;
//        }     

//        is_init = true;
//    }
//    
//    if (!rt_strcmp(opt, "tx"))
//    {
//        spi_test_tx();
//        log_d("spi tx...\n");
//    }
//    else if(!rt_strcmp(opt, "rx"))
//    {
//        spi_test_rx();
//        log_d("spi rx...\n");
//    }
//    else
//    {
//        log_d("spi para error...\n");
//    }
//  
//}
//MSH_CMD_EXPORT(hal_spi_sample, hal_spi_sample <tx/rx>);


#ifdef RT_USING_FINSH
#ifdef RT_USING_FINSH_DEBUG
#if 0
#include "hal.h"

// spi flash写数据使能
static void spi_flash_write_data_enable(void) {
   uint8_t send_data = 0x06;
    hal_gpio_write(HAL_PIN_SPI_CS, 0);
    hal_spi_write(SPI3_ID, &send_data, 1);
    hal_gpio_write(HAL_PIN_SPI_CS, 1);
}

// spi flash写数据
static void spi_flash_write(uint8_t *pBuffer, uint32_t WriteAddr, uint16_t NumByteToWrite) {
   uint8_t send_data = 0x06;

    spi_flash_write_data_enable();

    hal_gpio_write(HAL_PIN_SPI_CS, 0);

    send_data = 0x02;
    hal_spi_write(SPI3_ID, &send_data, 1);

    send_data = (WriteAddr & 0xFF0000) >> 16;
    hal_spi_write(SPI3_ID, &send_data, 1);
    send_data = (WriteAddr & 0xFF00) >> 8;
    hal_spi_write(SPI3_ID, &send_data, 1);
    send_data = WriteAddr & 0xFF;
    hal_spi_write(SPI3_ID, &send_data, 1);

    hal_spi_write(SPI3_ID, &pBuffer, NumByteToWrite);

    hal_gpio_write(HAL_PIN_SPI_CS, 0);

    /*!< Wait the end of Flash writing 
    sFLASH_WaitForWriteEnd();*/
}

static void spi_example(int argc, char *argv[]) {
    switch (argv[1][0]) {
    case '0': { // 初始化 spi3
        hal_spi_config_t        conf_spi;
        const hal_gpio_config_t gpio_config = {HAL_GPIO_OUTPUT, HAL_GPIO_PULLUP};

        hal_gpio_config(HAL_PIN_SPI_CS, (hal_gpio_config_t *) &gpio_config);
		hal_gpio_write(HAL_PIN_SPI_CS, 1);
        hal_spi_open(SPI3_ID);

        /* spi congig param*/
        conf_spi.work_mode  = HAL_SPI_MASTER;
        conf_spi.data_width = HAL_SPI_8BIT;
        conf_spi.first_bit  = HAL_SPI_FIRSTBIT_MSB;
        conf_spi.max_hz     = 40 * 1000 * 1000;
        conf_spi.trans_mode = HAL_SPI_MODE_0;
        hal_spi_setup(SPI3_ID, &conf_spi);
        break;
    }
    case '1': { // 读flash id
        uint8_t  buff[32] = {0};
        uint32_t flash_id = 0;
        
        hal_gpio_write(HAL_PIN_SPI_CS, 0);/* spi_cs拉低 */

        uint8_t send_data = 0x9F;
        hal_spi_write(SPI3_ID, &send_data, 1);
        hal_spi_read(SPI3_ID, &buff[0], 1);

        send_data = 0xA5;
        hal_spi_write(SPI3_ID, &send_data, 1);
        hal_spi_read(SPI3_ID, &buff[1], 1);

        hal_spi_write(SPI3_ID, &send_data, 1);
        hal_spi_read(SPI3_ID, &buff[2], 1);

        hal_spi_write(SPI3_ID, &send_data, 1);
        hal_spi_read(SPI3_ID, &buff[3], 1);
        
        hal_gpio_write(HAL_PIN_SPI_CS, 1);/* 读完 spi_cs拉高 */

        flash_id = (buff[1] << 16) | (buff[2] << 8) | (buff[3]);
        rt_kprintf("flash_id=%06x\r\n", flash_id);
        break;
    }
    case '2': { // 读flash id
        uint8_t  buff[32] = {0};
        uint32_t flash_id = 0;
        
        hal_gpio_write(HAL_PIN_SPI_CS, 0);/* spi_cs拉低 */

        uint8_t send_data = 0x9F;
        hal_spi_write(SPI3_ID, &send_data, 1);
        hal_spi_read(SPI3_ID, &buff[0], 1);

        send_data = 0xA5;
        hal_spi_write(SPI3_ID, &send_data, 1);
        hal_spi_read(SPI3_ID, &buff[1], 1);

        hal_spi_write(SPI3_ID, &send_data, 1);
        hal_spi_read(SPI3_ID, &buff[2], 1);

        hal_spi_write(SPI3_ID, &send_data, 1);
        hal_spi_read(SPI3_ID, &buff[3], 1);
        
        hal_gpio_write(HAL_PIN_SPI_CS, 1);/* 读完 spi_cs拉高 */

        flash_id = (buff[1] << 16) | (buff[2] << 8) | (buff[3]);
        rt_kprintf("flash_id=%06x\r\n", flash_id);
        break;
    }
    case 'c': { // 读flash id
        hal_spi_close(SPI3_ID);
        break;
    }
    default:
        break;
    }
}
MSH_CMD_EXPORT(spi_example, test spi);
#endif
#endif
#endif
