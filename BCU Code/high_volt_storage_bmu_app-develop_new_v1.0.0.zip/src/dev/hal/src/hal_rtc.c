#include <board.h>
#include <stdlib.h>
#include <string.h>
#include <rtthread.h>
#include <rtdevice.h>
#include <time.h>
#include "hal_rtc.h"
#include "hal_public.h"
#include "log.h"



/**
* @brief		BCD码转byte
* @param		[in] bcd  
* @return		返回转码值 
* @retval		hex值
*/
static uint8_t hal_bcd2hex(uint8_t bcd)
{
    uint8_t tmp = 0;
    tmp = ((uint8_t)(bcd & (uint8_t)0xF0) >> (uint8_t)0x4) * 10;
    return (tmp + (bcd & (uint8_t)0x0F));
}


/**
* @brief		检查时间数据是否合法
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
static int32_t hal_is_time_ok(uint32_t rtc_format, hal_rtc_t *p_time)
{
	if (HAL_RTC_FORMAT_BIN == rtc_format)
	{
		if ((!IS_RTC_YEAR(p_time->tm_year))
	  	  ||(!IS_RTC_MONTH(p_time->tm_mon))   
	  	  ||(!IS_RTC_DATE(p_time->tm_day))    
	  	  ||(!IS_RTC_24HOUR(p_time->tm_hour))
	  	  ||(!IS_RTC_MINUTES(p_time->tm_min))
	  	  ||(!IS_RTC_SECONDS(p_time->tm_sec)))
	    {
			return HAL_EPERM;
		}	
	}
	else if(HAL_RTC_FORMAT_BCD == rtc_format)
	{
		if ((!IS_RTC_YEAR(hal_bcd2hex(p_time->tm_year)))
	  	  ||(!IS_RTC_MONTH(hal_bcd2hex(p_time->tm_mon)))   
	  	  ||(!IS_RTC_DATE(hal_bcd2hex(p_time->tm_day)))    
	  	  ||(!IS_RTC_24HOUR(hal_bcd2hex(p_time->tm_hour)))
	  	  ||(!IS_RTC_MINUTES(hal_bcd2hex(p_time->tm_min)))
	  	  ||(!IS_RTC_SECONDS(hal_bcd2hex(p_time->tm_sec))))
	    {
			return HAL_EPERM;
		}
	}
	else
	{
		return HAL_EPERM;
	}
	return HAL_OK;
}


/**
 * @brief  Configures the RTC Source Clock Type.
 * @param Clk_Src_Type specifies RTC Source Clock Type.
 *   This parameter can be on of the following values:
 *     @arg RTC_CLK_SRC_TYPE_HSE128
 *     @arg RTC_CLK_SRC_TYPE_LSE
 *     @arg RTC_CLK_SRC_TYPE_LSI
 * @param Is_First_Cfg_RCC specifies Is First Config RCC Module.
 *   This parameter can be on of the following values:
 *     @arg true
 *     @arg false
 * @param Is_Rst_Bkp specifies Whether Reset The Backup Area
 *   This parameter can be on of the following values:
 *     @arg true
 *     @arg false
 */
static void hal_rtc_clk_src_Config(hal_rtc_clk_src_type_e clk_src_type, int8_t first_cfg_flag, RTC_InitType* rtc_init_structure)
{
	switch(clk_src_type)
	{
		case HAL_RTC_CLK_SRC_HSE128:
			rt_kprintf("set rtc clk src is to HSE128\r\n");
			if (ENABLE == first_cfg_flag)
			{
				/* Enable HSE */
				RCC_EnableLsi(DISABLE);
				RCC_ConfigHse(RCC_HSE_ENABLE);
				while (RCC_WaitHseStable() == ERROR) {};
				RCC_ConfigRtcClk(RCC_RTCCLK_SRC_HSE_DIV128);
			}
			else
			{
				RCC_EnableLsi(DISABLE);
				RCC_ConfigRtcClk(RCC_RTCCLK_SRC_HSE_DIV128);
				/* Enable HSE */
				RCC_ConfigHse(RCC_HSE_ENABLE);
				while (RCC_WaitHseStable() == ERROR) {};
			}
			rtc_init_structure->RTC_SynchPrediv  = 0x1E8; // 8M/128 = 62.5KHz
			rtc_init_structure->RTC_AsynchPrediv = 0x7F;  // value range: 0-7F
			break;
		case HAL_RTC_CLK_SRC_LSE:
			rt_kprintf("set rtc clk src is to LSE\r\n");
			if (ENABLE == first_cfg_flag )
			{
				/* Enable the LSE OSC32_IN PC14 */
                // LSI is turned off here to ensure that only one clock is turned on
				//RCC_EnableLsi(DISABLE); 
				RCC_ConfigLse(RCC_LSE_ENABLE);
				while (RCC_GetFlagStatus(RCC_FLAG_LSERD) == RESET) {};
				RCC_ConfigRtcClk(RCC_RTCCLK_SRC_LSE);
			}
			else
			{
				/* Enable the LSE OSC32_IN PC14 */
				//RCC_EnableLsi(DISABLE);
				RCC_ConfigRtcClk(RCC_RTCCLK_SRC_LSE);
				RCC_ConfigLse(RCC_LSE_ENABLE);
				while (RCC_GetFlagStatus(RCC_FLAG_LSERD) == RESET) {};
			}
			rtc_init_structure->RTC_SynchPrediv  = 0xFF; // 32.768KHz
			rtc_init_structure->RTC_AsynchPrediv = 0x7F; // value range: 0-7F
			break;
		case HAL_RTC_CLK_SRC_LSI:
			rt_kprintf("set rtc clk src is to LSI\r\n");
			if (ENABLE == first_cfg_flag)
			{
				/* Enable the LSI OSC */
				RCC_EnableLsi(ENABLE);
				while (RCC_GetFlagStatus(RCC_FLAG_LSIRD) == RESET) {};
				RCC_ConfigRtcClk(RCC_RTCCLK_SRC_LSI);
			}
			else
			{
				RCC_ConfigRtcClk(RCC_RTCCLK_SRC_LSI);
				/* Enable the LSI OSC */
				RCC_EnableLsi(ENABLE);
				while (RCC_GetFlagStatus(RCC_FLAG_LSIRD) == RESET) {};
			}
			rtc_init_structure->RTC_SynchPrediv  = 0x136; // 39.64928KHz
			rtc_init_structure->RTC_AsynchPrediv = 0x7F;  // value range: 0-7F
			break;
		default:
			rt_kprintf("the rtc clk src of Value is error! \r\n");
	}

    /* Enable the RTC Clock */
    RCC_EnableRtcClk(ENABLE);
    RTC_WaitForSynchro();
}


/**
* @brief		RTC加载驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_rtc_init(void)
{
	RTC_InitType rtc_Init_structure; 
	RTC_DateType rtc_date_structure;
	RTC_TimeType rtc_time_structure;

	/* Enable the PWR clock */
    RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_PWR | RCC_APB1_PERIPH_BKP, ENABLE);
    RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_AFIO, ENABLE);
    /* Allow access to RTC */
    PWR_BackupAccessEnable(ENABLE);
    
	if (HAL_WRITE_BKP_DAT1_DATA != BKP_ReadBkpData(BKP_DAT1))
	{
	   	BKP_DeInit();
    	RCC_EnableRtcClk(DISABLE);
		RTC_StructInit(&rtc_Init_structure);
		hal_rtc_clk_src_Config(HAL_RTC_CLK_SRC_LSI, ENABLE, &rtc_Init_structure);
		/* Check on RTC init */
	    if (RTC_Init(&rtc_Init_structure) == ERROR)
	    {
	       rt_kprintf("RTC Prescaler Config failed \r\n");
	    }		
		RTC_DateStructInit(&rtc_date_structure);
		RTC_TimeStructInit(&rtc_time_structure);
		RTC_SetDate(HAL_RTC_FORMAT_BCD, &rtc_date_structure);
		RTC_ConfigTime(HAL_RTC_FORMAT_BCD, &rtc_time_structure);
		
		BKP_WriteBkpData(BKP_DAT1, HAL_WRITE_BKP_DAT1_DATA);
		rt_kprintf("RTC first configured....\r\n");
	}
    else
    {
        RCC_EnableRtcClk(DISABLE);
        RTC_StructInit(&rtc_Init_structure);
        hal_rtc_clk_src_Config(HAL_RTC_CLK_SRC_LSI, DISABLE, &rtc_Init_structure);
    }
    rt_kprintf("RTC init ok\r\n");
	return HAL_OK;
}
INIT_DEVICE_EXPORT(hal_rtc_init);

/**
* @brief		RTC删除驱动(预留)
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_rtc_deinit(void)
{
	return HAL_EPERM;
}


/**
* @brief		设置RTC时间 
* @param		[in] rtc_format 时间格式:BCD/HEX
				[in] p_time rtc时间结构体,详见hal_rtc_t定义   
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		HAL_EIO 失败   
* @pre			执行hal_rtc_init后执行才有效。
*/
int32_t hal_rtc_set(uint32_t rtc_format, hal_rtc_t *p_time)
{
	RTC_DateType rtc_date_structure;
	RTC_TimeType rtc_time_structure;
	
	/* 参数检查 */
	if ((!HAL_IS_RTC_FORMAT(rtc_format)) || (!p_time))
	{
		return HAL_EPERM;	
	}
	/* 时间数据检查 */
	if(HAL_OK != hal_is_time_ok(rtc_format, p_time))
	{
		return HAL_EPERM;	
	}
	
	/* 检查星期数据是否合法 */
	if(!IS_RTC_WEEKDAY(p_time->tm_weekday))
	{
		p_time->tm_weekday = RTC_WEEKDAY_MONDAY;	
	}
	
	rtc_date_structure.Year	   = p_time->tm_year;
	rtc_date_structure.Month   = p_time->tm_mon;
	rtc_date_structure.Date	   = p_time->tm_day;
	rtc_date_structure.WeekDay = p_time->tm_weekday;
	RTC_SetDate(rtc_format, &rtc_date_structure);
	rtc_time_structure.Hours   = p_time->tm_hour;
	rtc_time_structure.Minutes = p_time->tm_min;
	rtc_time_structure.Seconds = p_time->tm_sec;
	RTC_ConfigTime(rtc_format, &rtc_time_structure);
	
	return HAL_OK;
}


/**
* @brief		读取RTC时间 
* @param		[in] rtc_format 时间格式:BCD/HEX
				[out] p_time rtc时间结构体,详见hal_rtc_t定义
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		HAL_EIO 失败   
* @pre			执行hal_rtc_init后执行才有效。
*/
int32_t hal_rtc_get(uint32_t rtc_format, hal_rtc_t *p_time)
{
	RTC_DateType rtc_date_structure;
	RTC_TimeType rtc_time_structure;

	/* rtc时间格式检查 */
	if ((!HAL_IS_RTC_FORMAT(rtc_format)) || (!p_time))
	{
		return HAL_EPERM;	
	}
	/* 获取RTC时间 */
	RTC_GetDate(rtc_format, &rtc_date_structure);
	RTC_GetTime(rtc_format, &rtc_time_structure);

	p_time->tm_year 	= rtc_date_structure.Year;
	p_time->tm_mon		= rtc_date_structure.Month;
	p_time->tm_day		= rtc_date_structure.Date;
	p_time->tm_weekday	= rtc_date_structure.WeekDay;
	p_time->tm_hour 	= rtc_time_structure.Hours;
	p_time->tm_min		= rtc_time_structure.Minutes;
	p_time->tm_sec		= rtc_time_structure.Seconds;

	/* 检查时间数据是否合法 */
	return hal_is_time_ok(rtc_format, p_time);
}


/**
* @brief		读取RTC时间戳
* @param		[in] void
* @return		执行结果
* @retval		>=0 自1970年的秒数 
* @retval		-1 失败   
* @pre			执行hal_rtc_init后执行才有效。
*/
uint32_t hal_rtc_timestamp_get(void)
{
	struct tm time;
	RTC_DateType rtc_date_structure;
	RTC_TimeType rtc_time_structure;
	
	/* 获取RTC时间 */
	RTC_GetDate(HAL_RTC_FORMAT_BIN, &rtc_date_structure);
	RTC_GetTime(HAL_RTC_FORMAT_BIN, &rtc_time_structure);

	time.tm_year 	= (rtc_date_structure.Year + 2000) - 1900;
	time.tm_mon		= rtc_date_structure.Month - 1;
	time.tm_mday	= rtc_date_structure.Date;
	time.tm_hour 	= rtc_time_structure.Hours;
	time.tm_min		= rtc_time_structure.Minutes;
	time.tm_sec		= rtc_time_structure.Seconds;

	return mktime(&time);
}

/**
* @brief		创建闹钟
* @param		[in] val rtc闹钟时间  
* @param		[in] cb 闹钟回调函数  
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		HAL_EIO 失败   
*/
int32_t hal_rtc_creat_alarm(hal_alarm_setup_t *val, hal_alarm_callback_t cb)
{
//	struct rt_alarm_setup alarm_setup;
//    struct rt_alarm * alarm = RT_NULL;
//	
//	alarm_setup.flag = val->flag;
//	alarm_setup.wktime.tm_sec = val->wktime.tm_sec;
//	alarm_setup.wktime.tm_min = val->wktime.tm_min;
//	alarm_setup.wktime.tm_hour = val->wktime.tm_hour;
//	alarm_setup.wktime.tm_wday = val->wktime.tm_day;
//	alarm_setup.wktime.tm_mon = val->wktime.tm_mon;
//	alarm_setup.wktime.tm_year = val->wktime.tm_year;

//	alarm = rt_alarm_create(cb, &alarm_setup);

//	if(RT_NULL != alarm)
//    {
//        rt_alarm_start(alarm);
//		return HAL_OK;
//    }
	return HAL_EIO;
}

/**
* @brief		启动闹钟   
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		HAL_EIO 失败   
*/
int32_t hal_rtc_start_alarm(hal_alarm_t alarm)
{
//	rt_err_t alarm_err;

//	alarm_err = rt_alarm_start(alarm);

//	if(alarm_err != RT_NULL)
//	{
//		 return HAL_EPERM;
//	}

	return HAL_EIO;
}

/**
* @brief		停止闹钟   
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		HAL_EIO 失败   
*/
int32_t hal_rtc_stop_alarm(hal_alarm_t alarm)
{
//	rt_err_t alarm_err;

//	alarm_err = rt_alarm_stop(alarm);

//	if(alarm_err != RT_NULL)
//	{
//		 return HAL_EPERM;
//	}

	return HAL_OK;
}

/**
* @brief		取消闹钟   
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		HAL_EIO 失败   
*/
int32_t hal_rtc_clear_alarm(hal_alarm_t alarm)
{
//	uint8_t status = 0;

//	status = rt_alarm_delete(alarm);

//	if(status != 0)
//	{
//		 return HAL_EPERM;
//	}

	return HAL_EIO;
}


/**
* @brief		扩展功能 
* @param		[in] dev_no 设备端口号  
* @param		[in] cmd 控制命令  
* @param		[in] arg 控制参数   
* @return		执行结果
* @retval		HAL_OK 成功    
* @retval		<0 失败原因  
*/
int32_t hal_rtc_ioctl(int32_t dev_no, uint8_t cmd, void* p_arg)
{
	return HAL_OK;
}

/**
 * @brief  This function handles RTC WakeUp interrupt request.
 */
void RTC_WKUP_IRQHandler(void)
{
	EXTI_ClrITPendBit(EXTI_LINE20);
    if (RTC_GetITStatus(RTC_INT_WUT) != RESET)
    {
        RTC_ClrIntPendingBit(RTC_INT_WUT);
    }
}


#ifdef RT_USING_FINSH
#ifdef RT_USING_FINSH_DEBUG

/**
* @brief        GPIO_HAL功能样例
* @param        argv 功能参数
* @return       返回结果
* @retval         HAL_OK 成功
* @retval         HAL_EIO 失败
*/
static int hal_rtc_sample(int argc, char *argv[])
{
	char 	 *opt  	 = argv[1];
	char 	 *format = argv[2];
	hal_rtc_t time;
	int32_t   ret;

	//hal_rtc_init();
	if (!rt_strcmp(opt, "set"))
	{
		if (!rt_strcmp(format, "bin"))
		{
			time.tm_year = atoi(argv[3]);
			time.tm_mon  = atoi(argv[4]);
			time.tm_day  = atoi(argv[5]);
			time.tm_hour = atoi(argv[6]);
			time.tm_min  = atoi(argv[7]);
			time.tm_sec  = atoi(argv[8]);	
			ret = hal_rtc_set(HAL_RTC_FORMAT_BIN, &time);
		}
		else if(!rt_strcmp(format, "bcd"))
		{
			time.tm_year = hal_bcd2hex(atoi(argv[3]));
			time.tm_mon  = hal_bcd2hex(atoi(argv[4]));
			time.tm_day  = hal_bcd2hex(atoi(argv[5]));
			time.tm_hour = hal_bcd2hex(atoi(argv[6]));
			time.tm_min  = hal_bcd2hex(atoi(argv[7]));
			time.tm_sec  = hal_bcd2hex(atoi(argv[8]));
			ret = hal_rtc_set(HAL_RTC_FORMAT_BCD, &time);
		}
		if(HAL_OK != ret)
		{
			rt_kprintf("set RTC time failed\n");
		}
	}
	else if(!rt_strcmp(opt, "read"))
	{
		if (!rt_strcmp(format, "bin"))
		{
			ret = hal_rtc_get(HAL_RTC_FORMAT_BIN, &time);
			if(HAL_OK != ret)
			{
				rt_kprintf("get RTC time failed\n");
			}
			else
			{
				rt_kprintf("get RTC time: 20%02d-%02d-%02d %02d:%02d:%02d\n", 
							time.tm_year, time.tm_mon, time.tm_day, 
							time.tm_hour, time.tm_min, time.tm_sec);
			}
		}
		else if(!rt_strcmp(format, "bcd"))
		{
			ret = hal_rtc_get(HAL_RTC_FORMAT_BCD, &time);
			if(HAL_OK != ret)
			{
				rt_kprintf("get RTC time failed\n");
			}
			else
			{
				rt_kprintf("get RTC time: 20%02d-%02d-%02d %02d:%02d:%02d\n", 
							hal_bcd2hex(time.tm_year), hal_bcd2hex(time.tm_mon), hal_bcd2hex(time.tm_day), 
							hal_bcd2hex(time.tm_hour), hal_bcd2hex(time.tm_min), hal_bcd2hex(time.tm_sec));
			}
		}
	}
	else if(!rt_strcmp(opt, "time_stamp"))
	{
		int32_t time_stamp;
		time_stamp = hal_rtc_timestamp_get();
		rt_kprintf("get_time_stamp:%d\n", time_stamp);
	}
	else
	{
		rt_kprintf("you input '%s' is not support\n",opt);
	}
	
	return 1;
}

MSH_CMD_EXPORT(hal_rtc_sample, hal_rtc_sample <set/read bin 22 08 29 09 00 01>);
#endif 
#endif






