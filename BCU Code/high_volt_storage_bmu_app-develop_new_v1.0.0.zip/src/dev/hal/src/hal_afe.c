
#include <string.h>
#include <rtthread.h>
#include "hal_gpio.h"
#include "osif.h"
#include "hal_public.h"
#include "afe_bq79616_comm.h"
#include "afe_bq79616.h"
#include "hal_afe.h"

#define CONFIG_RETRY_NUM                3
#define READ_RETRY_NUM                  3
#define AFE_TASK_MS						10
#define AFE_COLLECT_MS                  200

#ifdef __cplusplus
extern "C" {
#endif

#if AFE_DEBUG_ENABLE
afe_state_e g_afe_state;
afe_abnormal_e g_afe_err_flag = AFE_ERR_NONE;
uint16_t g_afe_collect_ms = AFE_COLLECT_MS;
#else
static afe_state_e g_afe_state;
static afe_abnormal_e g_afe_err_flag = AFE_ERR_NONE;
#endif

/****************************SDK********************************/
void hal_afe_state_get(afe_state_e *state)
{
	 if (state == NULL)
	 {
		return;
	 }
     *state = g_afe_state;
}

void hal_afe_state_set(afe_state_e state)
{
    switch (state)
    {
        case AFE_WAKEUP_STATE:
             if (g_afe_state == AFE_IDIE_STATE)
             {
                g_afe_state = AFE_WAKEUP_STATE;
				g_afe_err_flag = AFE_ERR_NONE; // app触发启动流程，清除错误
             }
            break;
        case AFE_PRE_SHUTDOWN_STATE:
            if (g_afe_state == AFE_RUN_STATE)
            {
                g_afe_state = AFE_PRE_SHUTDOWN_STATE;
            }
            break;
        default:
            // 非法状态不做处理
            break;
    }
}

afe_abnormal_e hal_afe_abnormal_state_get(void)
{
   return g_afe_err_flag;
}


uint16_t* hal_cell_temp_res_val_get(void)
{
    return get_cell_temp_res_val();
}
/**************************************************************/

int32_t hal_afe_init(void)
{
	hal_gpio_config_t gpio_config;
	static uint8_t init_state = 0;
	
	if (0 == init_state)
	{
		// 启动afe电平转换模块
		gpio_config.direction = HAL_GPIO_OUTPUT;
		hal_gpio_config(GPIO_IDX36_AFE_LEVEL_ENABLE, &gpio_config);
		hal_gpio_write(GPIO_IDX36_AFE_LEVEL_ENABLE, HAL_GPIO_HIGH);
		
		g_afe_state = AFE_WAKEUP_STATE;
		g_afe_err_flag = AFE_ERR_NONE;
		bq79616_init();
	#if AFE_DEBUG_ENABLE
		g_afe_collect_ms = AFE_COLLECT_MS;
	#endif
		init_state = 1;
	}
    
    return HAL_OK;
}
INIT_DEVICE_EXPORT(hal_afe_init);


void afe_management(void)
{ 
	static uint32_t collect_ms = 0;
    static uint8_t cfg_retry_counter = 0;
	static uint8_t read_retry_counter = 0;
	
    switch (g_afe_state)
    {
        case AFE_IDIE_STATE:

            break;
        case AFE_WAKEUP_STATE:
            bq79616_wakeup(); // 唤醒afe
            g_afe_state = AFE_PER_INIT_STATE;
            break;
        case AFE_PER_INIT_STATE:
            if (0 == bq79616_communication_init()) // 配置通讯外设
            {
                g_afe_state = AFE_INIT_STATE;
            }
            else
            {
                g_afe_state = AFE_ERR_STATE;
                g_afe_err_flag = AFE_ERR_UART_INIT;
            }
            break;
        case AFE_INIT_STATE:
            if (0 > bq79616_config_init()) // afe初始化，内部有重试机制
            {
                g_afe_state = AFE_WAKEUP_STATE; // 初始化失败，重新激活afe
                if (++cfg_retry_counter >= CONFIG_RETRY_NUM) // 初始化失败3次，上报错误，并回到初始状态
                {
                    g_afe_state = AFE_ERR_STATE;
                    g_afe_err_flag = AFE_ERR_CONFIG;
                }
            }
            else
            {
				cfg_retry_counter = 0;
                g_afe_state = AFE_PRE_RUN_STATE;
            }
            break;
        case AFE_PRE_RUN_STATE:
			collect_ms = hal_tick_get();
            g_afe_state = AFE_RUN_STATE;
            break;
        case AFE_RUN_STATE:
#if AFE_DEBUG_ENABLE
			if (true == hal_is_tick_over(collect_ms, os_tick_from_millisecond(g_afe_collect_ms)))
#else
			if (true == hal_is_tick_over(collect_ms, os_tick_from_millisecond(AFE_COLLECT_MS)))
#endif
			{
				if (0 > bq79616_collect())
				{
					g_afe_state = AFE_WAKEUP_STATE; // 检测到通讯失败后，重新激活afe
					if (++read_retry_counter >= READ_RETRY_NUM) // 连续读取3次失败,上报错误，并回到初始状态
					{
						g_afe_state = AFE_ERR_STATE;
						g_afe_err_flag = AFE_ERR_COMMUNICATION;
					}
					return;
				}
				read_retry_counter = 0; // 读取有效，重置重试计数
				bq79616_balance_ctrl(1); // 启动均衡控制模块
				collect_ms = hal_tick_get();
			}
            break;
        case AFE_PRE_SHUTDOWN_STATE:
			read_retry_counter = 0;
            g_afe_state = AFE_SHUTDOWN_STATE;
            break;
        case AFE_SHUTDOWN_STATE:
            bq79616_shutdown(); // 重复发送5次关机指令（afe关机后所有功能关闭，此时无法读取数据，故暂不做处理）
            bq79616_init(); // 关机清除对应数据
            g_afe_state = AFE_IDIE_STATE;
            break;
        case AFE_ERR_STATE: 
			// 清除错误计数
			read_retry_counter = 0; 
			cfg_retry_counter = 0;
		
            bq79616_init();  // 检测到异常，清除对应数据
            g_afe_state = AFE_IDIE_STATE;
            break;
    }
}

void hal_afe_resume(void)
{
	hal_afe_state_set(AFE_WAKEUP_STATE);
}


void hal_afe_suspend(void)
{
	hal_afe_state_set(AFE_PRE_SHUTDOWN_STATE);
}


void afe_thread(void *argv)
{        
    while (1)
    {
		afe_management();
		os_delay(os_tick_from_millisecond(AFE_TASK_MS));
    }
}


#ifdef RT_USING_FINSH
#ifdef RT_USING_FINSH_DEBUG
#if AFE_DEBUG_ENABLE

static void afe_set_state(int argc, char**argv)
{
    if (argc != 2)
    {
        rt_kprintf("Please input'afe_set_state <wakeup|run|shutdown>'\n");
        return;
    }

    if (!rt_strcmp(argv[1], "wakeup"))
    {
        hal_afe_state_set(AFE_WAKEUP_STATE);
        rt_kprintf("afe_wakeup!\n");
    }
    else if (!rt_strcmp(argv[1], "run"))
    {
        hal_afe_state_set(AFE_PRE_RUN_STATE);
        rt_kprintf("afe_run!\n");
    }
    else if (!rt_strcmp(argv[1], "shutdown"))
    {
        hal_afe_state_set(AFE_PRE_SHUTDOWN_STATE);
        rt_kprintf("afe_shutdown!\n");
    }
    else
    {
        rt_kprintf("Please input'afe_set_state <wakeup|run|shutdown>'\n");
    }
}
MSH_CMD_EXPORT(afe_set_state, afe_set_state <wakeup|run|shutdown>);

static void afe_set_collect_time(void)
{
    static uint8_t counter = 0;
    if (++counter > 4)
    {
        counter = 1;
    }
    switch (counter)
    {
        case 1:
            g_afe_collect_ms = 10;
            break;
        case 2:
            g_afe_collect_ms = 50;
            break;
        case 3:
            g_afe_collect_ms = 100;
            break;
        case 4:
            g_afe_collect_ms = 200;
            break;
    }
    rt_kprintf("afe_collect_time is %dms!\n", g_afe_collect_ms);
}
MSH_CMD_EXPORT(afe_set_collect_time, 10ms-50ms-100ms-200ms);

static void afe_get_err_state(void)
{
	afe_abnormal_e tmp;
    tmp = hal_afe_abnormal_state_get();
	
	switch (tmp)
	{
		case AFE_ERR_NONE:
			rt_kprintf("AFE_ERR_NONE\n");
			break;
	    case AFE_ERR_UART_INIT:
			rt_kprintf("AFE_ERR_UART_INIT\n");
			break;
		case AFE_ERR_CONFIG:
			rt_kprintf("AFE_ERR_CONFIG\n");
			break;
		case AFE_ERR_COMMUNICATION:
			rt_kprintf("AFE_ERR_COMMUNICATION\n");
			break;
	}
}
MSH_CMD_EXPORT(afe_get_err_state, afe abnormal state);

#endif 
#endif
#endif

#ifdef __cplusplus
}
#endif

