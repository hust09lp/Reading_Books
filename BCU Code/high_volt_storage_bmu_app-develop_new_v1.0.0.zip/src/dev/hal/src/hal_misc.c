#include <rtthread.h>
#include <rthw.h>
#include "n32g45x.h"

#define CPU_USAGE_CALC_TICK   10
#define CPU_USAGE_LOOP        100

static rt_uint8_t  cpu_usage_major = 0, cpu_usage_minor= 0;
static rt_uint32_t total_count = 0;

static void cpu_usage_idle_hook()
{
    rt_tick_t tick;
    rt_uint32_t count;
    volatile rt_uint32_t loop;

    if (total_count == 0)
    {
        /* get total count */
        rt_enter_critical();
        tick = rt_tick_get();
        while(rt_tick_get() - tick < CPU_USAGE_CALC_TICK)
        {
            total_count ++;
            loop = 0;
            while (loop < CPU_USAGE_LOOP) loop ++;
        }
        rt_exit_critical();
    }

    count = 0;
    /* get CPU usage */
    tick = rt_tick_get();
    while (rt_tick_get() - tick < CPU_USAGE_CALC_TICK)
    {
        count ++;
        loop  = 0;
        while (loop < CPU_USAGE_LOOP) loop ++;
    }

    /* calculate major and minor */
    if (count < total_count)
    {
        count = total_count - count;
        cpu_usage_major = (count * 100) / total_count;
        cpu_usage_minor = ((count * 100) % total_count) * 100 / total_count;
    }
    else
    {
        total_count = count;

        /* no CPU usage */
        cpu_usage_major = 0;
        cpu_usage_minor = 0;
    }
}

void cpu_usage_get(uint8_t *major, uint8_t *minor)
{
    RT_ASSERT(major != RT_NULL);
    RT_ASSERT(minor != RT_NULL);

    *major = cpu_usage_major;
    *minor = cpu_usage_minor;
}


int32_t cpu_usage_init(void)
{
    /* set idle thread hook */
    return rt_thread_idle_sethook(cpu_usage_idle_hook);
}
INIT_DEVICE_EXPORT(cpu_usage_init);

static int32_t g_cpu_reset_flag = -1;

void cpu_reset_flag_set(void)
{
	if((RCC->CTRLSTS & RCC_CTRLSTS_LPWRRSTF) != RESET)
	{
		g_cpu_reset_flag = 0;
	}
	else if((RCC->CTRLSTS & RCC_CTRLSTS_WWDGRSTF) != RESET)
	{
		g_cpu_reset_flag = 1;
	}
	else if((RCC->CTRLSTS & RCC_CTRLSTS_IWDGRSTF) != RESET)
	{
		g_cpu_reset_flag = 2;
	}
	else if((RCC->CTRLSTS & RCC_CTRLSTS_SFTRSTF) != RESET)
	{
		g_cpu_reset_flag = 3;
	}
	else if((RCC->CTRLSTS & RCC_CTRLSTS_PORRSTF) != RESET)
	{
		g_cpu_reset_flag = 4;
	}
	else if((RCC->CTRLSTS & RCC_CTRLSTS_PINRSTF) != RESET)
	{
		g_cpu_reset_flag = 5;
	}	
	else if((RCC->CTRLSTS & RCC_CSR_MMURSTF) != RESET)
	{
		g_cpu_reset_flag = 6;
	}		
	else
	{
		g_cpu_reset_flag = -1;
	}
	RCC_ClrFlag();
}

int32_t get_cpu_reset_flag(void)
{
	return g_cpu_reset_flag;
}

#ifdef RT_USING_FINSH
#ifdef RT_USING_FINSH_DEBUG
#include <osif.h>
static int cpu_usage_sample(int argc, char *p_argv[])
{
	uint8_t major, minor;
    uint8_t cnt = 0;
    
    while(cnt++ < 10)
    {
        cpu_usage_get(&major, &minor);
        rt_kprintf("cpu usage: %d.%d%\n", major, minor);
        os_delay(os_tick_from_millisecond(500));
    }
	
	return 0;
}

MSH_CMD_EXPORT(cpu_usage_sample, cpu_usage);
#endif
#endif
