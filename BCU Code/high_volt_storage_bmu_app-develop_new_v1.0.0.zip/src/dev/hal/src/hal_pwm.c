#include <board.h>
#include <string.h>
#include <rtthread.h>
#include <rtdevice.h>
#include "hal_pwm.h"
#include "log.h"


// 虚拟PWM索引号对应的设备名称
static const char *gp_pwm_dev[HAL_PWM_TIM_MAX] =
{
	"tim1pwm",
	"tim2pwm",
	"tim3pwm",
	"tim4pwm",
	"tim5pwm",
	"tim8pwm",
};


// 从RTOS打开的设备类句柄
static struct rt_device_pwm  *g_pwm[HAL_PWM_TIM_MAX];

// 标识pwm状态
static uint8_t g_pwm_status;


/**
* @brief		PWM加载驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_pwm_init(void)
{
	memset((void *)g_pwm, 0, sizeof(struct rt_device_pwm)*HAL_PWM_TIM_MAX);
	g_pwm_status = 0;
	return HAL_OK;
}
INIT_BOARD_EXPORT(hal_pwm_init);


/**
* @brief		PWM删除驱动(预留)
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_pwm_deinit(void)
{
	return HAL_OK;
}


/**
* @brief		启动PWM通道  
* @param		[in] pwm_tim_no pwm定时器索引编号
* -# HAL_PWM_TIM1 - 0x00  
* -# HAL_PWM_TIM2 - 0x01
* -# HAL_PWM_TIM3 - 0x02  
* -# HAL_PWM_TIM4 - 0x03  
* -# HAL_PWM_TIM5 - 0x04    
* -# HAL_PWM_TIM8 - 0x05
* @param		[in] chan pwm  通道编号
* -# HAL_PWM_CH1 - 0x00  
* -# HAL_PWM_CH2 - 0x01
* -# HAL_PWM_CH3 - 0x02  
* -# HAL_PWM_CH4 - 0x03
* @return		执行结果
* @retval		HAL_OK（0） 成功  
* @retval		HAL_EIO（<0） 失败   
*/
int32_t hal_pwm_start(uint32_t pwm_tim_no, uint32_t chan)
{
	/* PWM定时器和对应通道范围检查 */
	if ((pwm_tim_no > HAL_PWM_TIM_MAX) || (chan >= HAL_PWM_CH_MAX))
	{
		return HAL_EIO;
	}
	/* 已启动，直接返回OK，无需重复启动 */
	if (GET_BIT(g_pwm_status, (1U << pwm_tim_no)) != 0)
    {
        return HAL_OK;
    }	
	
	/* 查找设备 */
	g_pwm[pwm_tim_no] = (struct rt_device_pwm*)rt_device_find(gp_pwm_dev[pwm_tim_no]);
    if (!g_pwm[pwm_tim_no])
    {
        log_w("find %s failed!\n", gp_pwm_dev[pwm_tim_no]);
        return HAL_EIO;
    }
	/* 使能设备 */
	if(HAL_OK != rt_pwm_enable(g_pwm[pwm_tim_no], chan))
	{
		
		return HAL_EPERM;
	}
	
	SET_BIT(g_pwm_status, (1U << pwm_tim_no));	
	return HAL_OK;
}

/**
* @brief		停止PWM通道 
* @param		[in] pwm_tim_no pwm定时器索引编号
* -# HAL_PWM_TIM1 - 0x00  
* -# HAL_PWM_TIM2 - 0x01
* -# HAL_PWM_TIM3 - 0x02  
* -# HAL_PWM_TIM4 - 0x03  
* -# HAL_PWM_TIM5 - 0x04    
* -# HAL_PWM_TIM8 - 0x05
* @param		[in] chan pwm通道编号
* -# HAL_PWM_CH1 - 0x00  
* -# HAL_PWM_CH2 - 0x01
* -# HAL_PWM_CH3 - 0x02  
* -# HAL_PWM_CH4 - 0x03
* @return		执行结果
* @retval		HAL_OK（0） 成功  
* @retval		HAL_EIO（<0） 失败   
*/
int32_t hal_pwm_stop(uint32_t pwm_tim_no, uint32_t chan)
{
	/* PWM定时器和对应通道范围检查 */
	if ((pwm_tim_no > HAL_PWM_TIM_MAX) || (chan >= HAL_PWM_CH_MAX)) 
	{
		return HAL_EIO;
	}
	/* 已停止，直接返回OK，无需重复停止 */
	if (GET_BIT(g_pwm_status, (1U << pwm_tim_no)) == 0)
    {
        return HAL_OK;
    }
    
	/* 查找设备 */
	g_pwm[pwm_tim_no] = (struct rt_device_pwm*)rt_device_find(gp_pwm_dev[pwm_tim_no]);
    if (!g_pwm[pwm_tim_no])
    {
        log_e("find %s failed!\n", gp_pwm_dev[pwm_tim_no]);
        return HAL_EIO;
    }
	/* 关闭设备 */
	if(HAL_OK != rt_pwm_disable(g_pwm[pwm_tim_no], chan))
	{
		return HAL_EPERM;		
	}
		
	CLR_BIT(g_pwm_status, (1U << pwm_tim_no));	
	return HAL_OK;
}

/**
* @brief		设置PWM参数   
* @param		[in] pwm_tim_no pwm定时器索引编号
* -# HAL_PWM_TIM1 - 0x00  
* -# HAL_PWM_TIM2 - 0x01
* -# HAL_PWM_TIM3 - 0x02  
* -# HAL_PWM_TIM4 - 0x03  
* -# HAL_PWM_TIM5 - 0x04    
* -# HAL_PWM_TIM8 - 0x05
* @param		[in] chan pwm  通道编号
* -# HAL_PWM_CH1 - 0x00  
* -# HAL_PWM_CH2 - 0x01
* -# HAL_PWM_CH3 - 0x02  
* -# HAL_PWM_CH4 - 0x03
* @param		[in] p_cfg pwm配置结构体
* -# p_cfg->duty_percent - PWM占空比 1-100对应1%-100%  
* -# p_cfg->period_ticks - PWM周期 ns
* -# p_cfg->polarity - 空闲时的引脚状态
* @return		执行结果
* @retval		HAL_OK（0） 成功  
* @retval		HAL_EIO（<0） 失败   
*/
int32_t hal_pwm_config(uint32_t pwm_tim_no, uint32_t chan,hal_pwm_config_t *p_cfg)
{
	uint32_t period; /* 周期，单位为纳秒ns */
	uint32_t pulse;	 /* PWM脉冲宽度值，单位为纳秒ns */
	uint32_t duty;	 /* PWM占空比 */
	
	/* PWM定时器和对应通道范围检查 */
	if ((pwm_tim_no > HAL_PWM_TIM_MAX) || (chan >= HAL_PWM_CH_MAX)) 
	{
		return HAL_EIO;
	}
    
	/* step1：查找设备 */
	g_pwm[pwm_tim_no] = (struct rt_device_pwm*)rt_device_find(gp_pwm_dev[pwm_tim_no]);
    if (!g_pwm[pwm_tim_no])
    {
        log_e("find %s failed!\n", gp_pwm_dev[pwm_tim_no]);
        return HAL_EIO;
    }
	
	period = p_cfg->period_ticks;
	duty   = p_cfg->duty_percent;
	pulse  = period*duty / 100;
	/* 设置PWM周期和脉冲宽度 */
	if(HAL_OK != rt_pwm_set(g_pwm[pwm_tim_no], chan, period, pulse))
	{
		return HAL_EPERM;
	}
		
	return HAL_OK;
}

/**
* @brief		PWM功能从休眠中唤醒，恢复状态
* @param		[in] pwm_tim_no pwm定时器索引编号
* -# HAL_PWM_TIM1 - 0x00  
* -# HAL_PWM_TIM2 - 0x01
* -# HAL_PWM_TIM3 - 0x02  
* -# HAL_PWM_TIM4 - 0x03  
* -# HAL_PWM_TIM5 - 0x04    
* -# HAL_PWM_TIM8 - 0x05
* @param		[in] chan pwm通道编号
* -# HAL_PWM_CH1 - 0x00  
* -# HAL_PWM_CH2 - 0x01
* -# HAL_PWM_CH3 - 0x02  
* -# HAL_PWM_CH4 - 0x03
* @return		执行结果
* @retval		HAL_OK（0） 成功  
* @retval		HAL_EIO（<0） 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_pwm_resume(uint32_t pwm_tim_no, uint32_t chan)
{
	/* PWM定时器和对应通道范围检查 */
	if ((pwm_tim_no > HAL_PWM_TIM_MAX) || (chan >= HAL_PWM_CH_MAX)) 
	{
		return HAL_EIO;
	}
	switch(pwm_tim_no)
	{
		case HAL_PWM_TIM1:
			n32_msp_tim_init(TIM1);
			break;
		case HAL_PWM_TIM2:
			n32_msp_tim_init(TIM2);
			break;
		case HAL_PWM_TIM3:
			n32_msp_tim_init(TIM3);
			break;
		case HAL_PWM_TIM4:
			n32_msp_tim_init(TIM4);
			break;
		case HAL_PWM_TIM5:
			n32_msp_tim_init(TIM5);
			break;
		case HAL_PWM_TIM8:
			n32_msp_tim_init(TIM8);
			break;
		default:
			log_e("pwm%d not support!", pwm_tim_no);
		break;	
	}
	
	return hal_pwm_start(pwm_tim_no, chan);
}
 
/**
* @brief		PWM功能进入休眠模式
* @param		[in] pwm_tim_no pwm定时器索引编号
* -# HAL_PWM_TIM1 - 0x00  
* -# HAL_PWM_TIM2 - 0x01
* -# HAL_PWM_TIM3 - 0x02  
* -# HAL_PWM_TIM4 - 0x03  
* -# HAL_PWM_TIM5 - 0x04    
* -# HAL_PWM_TIM8 - 0x05
* @param		[in] chan pwm通道编号
* -# HAL_PWM_CH1 - 0x00  
* -# HAL_PWM_CH2 - 0x01
* -# HAL_PWM_CH3 - 0x02  
* -# HAL_PWM_CH4 - 0x03
* @return		执行结果
* @retval		HAL_OK（0） 成功  
* @retval		HAL_EIO（<0） 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式，功能不影响
*/
int32_t hal_pwm_suspend(uint32_t pwm_tim_no, uint32_t chan)
{
	/* PWM定时器和对应通道范围检查 */
	if ((pwm_tim_no > HAL_PWM_TIM_MAX) || (chan >= HAL_PWM_CH_MAX))
	{
		return HAL_EIO;
	}
	/* 先停止PWM，再关闭时钟 */
	hal_pwm_stop(pwm_tim_no, chan);
	switch(pwm_tim_no)
	{
		case HAL_PWM_TIM1:
			RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_TIM1, DISABLE);
			break;
		case HAL_PWM_TIM2:
			RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_TIM2, DISABLE);
			break;
		case HAL_PWM_TIM3:
			RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_TIM3, DISABLE);
			break;
		case HAL_PWM_TIM4:
			RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_TIM4, DISABLE);
			break;
		case HAL_PWM_TIM5:
			RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_TIM5, DISABLE);
			break;
		case HAL_PWM_TIM8:
			RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_TIM8, DISABLE);
			break;
		default:
			log_e("pwm%d not support!", pwm_tim_no);
		break;	
	}
	
	return HAL_OK;
}


/**
* @brief		扩展功能(预留)
* @param		[in] pwm_tim_no pwm定时器索引编号
* -# HAL_PWM_TIM1 - 0x00  
* -# HAL_PWM_TIM2 - 0x01
* -# HAL_PWM_TIM3 - 0x02  
* -# HAL_PWM_TIM4 - 0x03  
* -# HAL_PWM_TIM5 - 0x04    
* -# HAL_PWM_TIM8 - 0x05
* @param		[in] chan pwm通道编号
* -# HAL_PWM_CH1 - 0x00  
* -# HAL_PWM_CH2 - 0x01
* -# HAL_PWM_CH3 - 0x02  
* -# HAL_PWM_CH4 - 0x03
* @param		[in] p_arg 控制参数   
* @return		执行结果
* @retval		HAL_OK 成功    
* @retval		<0 失败原因  
*/
int32_t hal_pwm_ioctl(uint32_t pwm_tim_no, uint32_t chan, uint8_t cmd, void* p_arg)
{
	return HAL_OK;
}



/**
* @brief        PWM_HAL功能样例
* @param        argv 功能参数
* @return       返回结果
* @retval         HAL_OK 成功
* @retval         HAL_EIO 失败
*/
#ifdef RT_USING_FINSH
#ifdef RT_USING_FINSH_DEBUG
#if defined(BSP_USING_PWM)

static int hal_pwm_sample(int argc, char *argv[])
{
	char 	*pwm_opt  = argv[1];
	hal_pwm_config_t pwm_config;

	if (!rt_strcmp(pwm_opt, "start"))
	{
		pwm_config.duty_percent = 50;
		pwm_config.period_ticks = 2000000;
		hal_pwm_config(HAL_PWM_TIM8, HAL_PWM_CH2, &pwm_config);
		hal_pwm_start(HAL_PWM_TIM8, HAL_PWM_CH2);
	}
	if (!rt_strcmp(pwm_opt, "stop"))
	{
		hal_pwm_stop(HAL_PWM_TIM8, HAL_PWM_CH2);
	}
	
	return HAL_OK;
}
#endif
MSH_CMD_EXPORT(hal_pwm_sample, hal_pwm_sample <start/stop>);
#endif
#endif





