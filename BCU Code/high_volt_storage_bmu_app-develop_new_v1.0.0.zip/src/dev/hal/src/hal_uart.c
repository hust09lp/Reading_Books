#include <board.h>
#include <string.h>
#include <rtthread.h>
#include <rtdevice.h>
#include "hal_uart.h"
#include "log.h"

// 串口回调函数
typedef struct{
	irq_uart_callback tx_cb;
	irq_uart_callback rx_cb;
}uart_int_cb_t;

typedef struct{
	uint32_t is_init;								// 0-未初始化 1-已初始化
	uint32_t is_open;								// 0-未打开 1-已打开
	uint32_t is_suspend;							// 0-未挂起 1-已挂起
}uart_status_t;

// 串口索引号对应的设备名称
static const char *gp_uart_dev[HAL_UART_MAX] =
{
	"uart1",
	"uart2",
	"uart3",
	"uart4",
	"uart5",
	"uart6",
	"uart7",
};

// 标识UART状态
static uart_status_t	g_uart_status = {0};

// 从RTOS打开的设备类句柄
static rt_device_t g_serial[HAL_UART_MAX];

// 收发回调函数，0=TX, 1=RX 
static uart_int_cb_t g_uart_cb[HAL_UART_MAX];



/**
* @brief		串口加载驱动
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
*/
int32_t hal_uart_init(void)
{
	if (!g_uart_status.is_init)
	{
		memset((void *)g_serial, 0, sizeof(rt_device_t)*HAL_UART_MAX);
		memset((void *)g_uart_cb, 0, sizeof(uart_int_cb_t)*HAL_UART_MAX);
		g_uart_status.is_init = 1;
	}

	return HAL_OK;
}
INIT_BOARD_EXPORT(hal_uart_init);


/**
* @brief		串口删除驱动（预留）
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
*/
int32_t hal_uart_deinit(void)
{
	if (g_uart_status.is_init)
	{
		memset((void *)&g_uart_status, 0, sizeof(uart_status_t));
	}
	
	return HAL_OK;
}


/**
* @brief		打开串口功能 
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @默认参数
* - p_conf->baud	波特率（默认115200）
* - p_conf->size	数据位（默认8）
* - p_conf->stop	停止位（默认1）
* - p_conf->par;   	校验位（默认0）   
* - p_conf->flow;  	硬件流控（默认0）
* - p_conf->buffsize;	缓冲区/字节（默认128K）
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		<0 失败原因  
* @pre			执行hal_uart_init后执行才有效。
* @warning		按照默认115200参数进行配置

*/
int32_t hal_uart_open(uint32_t port)
{	
	int32_t ret;
	
	// param check
	if (port >= HAL_UART_MAX) 
	{
		ret = HAL_EPERR;
		goto failed;
	}
	// if adc is opened, return ok
	if (GET_BIT(g_uart_status.is_open, (1U << port)))
    {
        return HAL_OK;
    } 
	// if adc is not init, return failed 
	if (!g_uart_status.is_init)
	{
		ret = HAL_EPERM;
		goto failed;
	} 	

	g_serial[port] = rt_device_find(gp_uart_dev[port]);
    if (!g_serial[port])
    {
        ret =  HAL_ENODEV;
		goto failed;
    }
	 	    
	// 以中断接收及轮询发送模式打开串口设备
    if(HAL_OK != rt_device_open(g_serial[port], RT_DEVICE_FLAG_INT_RX))
	{
		ret =  HAL_ENOPEN;
		goto failed;
	}
	/* 设置串口设备状态 */
	SET_BIT(g_uart_status.is_open, (1U << port));
	return HAL_OK;

failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;	
}

/**
* @brief		关闭串口功能 
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @pre			执行hal_uart_init后执行才有效。
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_uart_close(uint32_t port)
{
	int32_t ret;
	
	// param check
	if (port >= HAL_UART_MAX) 
	{
		ret = HAL_EPERR;
		goto failed;
	}
	// if adc is opened, return ok
	if (!GET_BIT(g_uart_status.is_open, (1U << port)))
    {
        return HAL_OK;
    } 
	
	g_serial[port] = rt_device_find(gp_uart_dev[port]);
    if (!g_serial[port])
    {
        ret =  HAL_ENODEV;
		goto failed;
    }
  
	if(HAL_OK != rt_device_close(g_serial[port]))
	{
		return HAL_EPERM;
	}
	
	/* 清除串口设备状态 */
	CLR_BIT(g_uart_status.is_open, (1u << port));
	return HAL_OK;

failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;	
}


/**
* @brief		串口功能从休眠中唤醒，恢复状态
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_uart_resume(uint32_t port)
{
	// param check
	if (port >= HAL_UART_MAX) 
	{
		return HAL_EPERR;
	}
	// if the device is not supended, return ok
	if (!GET_BIT(g_uart_status.is_suspend, (1U << port)))
    {
        return HAL_OK;
    } 	

#ifdef BSP_USING_UART1	
	if (HAL_UART1 == port)
	{
		n32_msp_usart_init(USART1);	
	}
#endif
#ifdef BSP_USING_UART2	
	if (HAL_UART2 == port)
	{
		n32_msp_usart_init(USART2);	
	}
#endif
#ifdef BSP_USING_UART3	
	if (HAL_UART3 == port)
	{
		n32_msp_usart_init(USART3);	
	}
#endif
#ifdef BSP_USING_UART4	
	if (HAL_UART4 == port)
	{
		n32_msp_usart_init(UART4);	
	}
#endif
#ifdef BSP_USING_UART5	
	if (HAL_UART5 == port)
	{
		n32_msp_usart_init(UART5);	
	}
#endif
#ifdef BSP_USING_UART6	
	if (HAL_UART6 == port)
	{
		n32_msp_usart_init(UART6);	
	}
#endif
#ifdef BSP_USING_UART7	
	if (HAL_UART7 == port)
	{
		n32_msp_usart_init(UART7);	
	}
#endif

	return HAL_OK;
}
 
/**
* @brief		串口功能进入休眠模式
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败    
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式，功能不影响
*/
int32_t hal_uart_suspend(uint32_t port)
{	
	// param check
	if (port >= HAL_UART_MAX) 
	{
		return HAL_EPERR;
	}
	// if the device is not supended, return ok
	if (GET_BIT(g_uart_status.is_suspend, (1U << port)))
    {
        return HAL_OK;
    } 	

	if(HAL_OK != hal_uart_close(port))
	{
		return HAL_EPERM;
	}
	
#ifdef BSP_USING_UART1	 
	if (HAL_UART1 == port)
	{
		RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_USART1, DISABLE);
	}
#endif
#ifdef BSP_USING_UART2	
	if (HAL_UART2 == port)
	{
		RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_USART2, DISABLE);
	}
#endif
#ifdef BSP_USING_UART3	
	if (HAL_UART3 == port)
	{
		RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_USART3, DISABLE);
	}
#endif
#ifdef BSP_USING_UART4	 
	if (HAL_UART4 == port)
	{
		RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_UART4, DISABLE);
	}
#endif
#ifdef BSP_USING_UART5	 
	if (HAL_UART5 == port)
	{
		RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_UART5, DISABLE);
	}
#endif
#ifdef BSP_USING_UART6	
	if (HAL_UART6 == port)
	{
		RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_UART6, DISABLE);
	}
#endif
#ifdef BSP_USING_UART7	
	if (HAL_UART7 == port)
	{
		RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_UART7, DISABLE);
	}
#endif

	return HAL_OK;
}

/**
* @brief		设置串口属性 
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @param		[out] p_conf 参数配置指针
* - p_conf->baud	波特率（默认115200）
* - p_conf->size	数据位（默认8）
* - p_conf->stop	停止位（默认1）
* - p_conf->par;   	校验位（默认0）    
* - p_conf->flow;  	硬件流控（默认0）
* - p_conf->buffsize;	缓冲区/字节（默认128K）
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			执行hal_uart_open后执行才有效。
* @warning		配置参数非法时，按照默认参数进行配置
*/
int32_t hal_uart_setup(uint32_t port, hal_uart_conf_t *p_conf)
{
	int32_t ret;
	struct serial_configure config = RT_SERIAL_CONFIG_DEFAULT; 

	// param check
	if ((port >= HAL_UART_MAX) || (!p_conf))
	{
		ret = HAL_EPERR;
		goto failed;
	}
	// if uart is opened, return ok
	if (!GET_BIT(g_uart_status.is_open, (1U << port)))
    {
        ret =  HAL_ENOPEN;
		goto failed;
	}

    /* 波特率 */
    if ((p_conf->baud != 0) && (p_conf->baud <= HAL_B1152000))
    {
    	config.baud_rate = p_conf->baud;
    }
    /* 数据位 */
    switch (p_conf->size)
   	{
   		case HAL_UART_8B:
   			config.data_bits = DATA_BITS_8;
   			break;
   		case HAL_UART_9B:
   			config.data_bits = DATA_BITS_9;
   			break;
   	}
   	/* 停止位 */
   	switch (p_conf->stop)
   	{
   		case HAL_UART_STOP1B:
   			config.stop_bits = STOP_BITS_1;
   			break;
   		case HAL_UART_STOP2B:
   			config.stop_bits = STOP_BITS_2;
   			break;
   	}
   	/* 校验位 */
   	switch (p_conf->par)
   	{
   		case HAL_UART_PARNON:
   			config.parity = PARITY_NONE;
   			break;
   		case HAL_UART_PARODD:
   			config.parity = PARITY_ODD;
   			break;
   		case HAL_UART_PAREVEN:
   			config.parity = PARITY_EVEN;
   			break;
   	}
	/* 缓冲区大小 */
	config.bufsz = p_conf->buffsize;           
	/* 控制串口设备。通过控制接口传入命令控制字，与控制参数 */
	return rt_device_control(g_serial[port], RT_DEVICE_CTRL_CONFIG, &config);

failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;
}

/**
* @brief		清空收缓冲区数据（预留）
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @pre			执行hal_uart_open后执行才有效。
*/
int32_t hal_uart_flush(uint32_t port)
{
	return HAL_OK;
}

/**
* @brief		串口收数据 
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @param		[in] p_buf 缓冲区指针  
* @param		[in] len 缓冲区长度   
* @return		执行结果
* @retval		>=0 接收数据长度  
* @retval		<0 失败原因  
* @pre			执行hal_uart_open后执行才有效。
*/
int32_t hal_uart_read(uint32_t port, uint8_t *p_buf, int32_t len)
{
	int32_t ret;
	int32_t read_len;
	
	// param check
	if ((port >= HAL_UART_MAX) || (NULL == p_buf)|| (len <= 0)) 
	{
		ret = HAL_EPERR;
		goto failed;
	}
	// if uart is closed, return failed
	if (!GET_BIT(g_uart_status.is_open, (1U << port)))
    {
        ret = HAL_ENOPEN;
		goto failed;
    }
    
	read_len = rt_device_read(g_serial[port], -1, p_buf, len);
	return read_len;

failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;		
}

/**
* @brief		串口发数据 
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @param		[in] buf 缓冲区指针  
* @param		[in] len 缓冲区长度   
* @return		执行结果
* @retval		>=0 发送数据长度   
* @retval		<0 失败原因  
* @pre			执行hal_uart_open后执行才有效。
*/
int32_t hal_uart_write(uint32_t port, uint8_t *p_buf, int32_t len)
{
	int32_t ret;
	int32_t send_len;
	
	// param check
	if ((port >= HAL_UART_MAX) || (NULL == p_buf)|| (len <= 0)) 
	{
		ret = HAL_EPERR;
		goto failed;
	}
	// if uart is closed, return failed
	if (!GET_BIT(g_uart_status.is_open, (1U << port)))
    {
        ret = HAL_ENOPEN;
		goto failed;
    }
    	
    if (!g_serial[port])
    {
    	log_e("%s is null!\n", gp_uart_dev[port]);
    	return HAL_EPERM;
    }
    
	send_len = rt_device_write(g_serial[port], 0, p_buf, len);
	return send_len;

failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;	
}


/**
* @brief		串口接收 内部函数 供中断使用 
* @param		[in] dev 串口操作句柄  
* @param		[in] size 接收数据大小     
* @return		执行结果
* @retval		RT_EOK 成功     
* @retval		RT_EIO 失败   
* @pre			执行hal_uart_open后执行才有效。
*/
static rt_err_t uart_rx(rt_device_t dev, rt_size_t size)
{
	int i;
	for (i = 0; i < HAL_UART_MAX; i++)
	{
		if (g_serial[i] == dev)
		{
			if (g_uart_cb[i].rx_cb)
				g_uart_cb[i].rx_cb(i, size);
		}
	}
	
    return RT_EOK;
}


/**
* @brief		串口发送 内部函数 供中断使用 
* @param		[in] dev 串口操作句柄  
* @param		[in] size 接收数据大小     
* @return		执行结果
* @retval		RT_EOK 成功     
* @retval		RT_EIO 失败   
* @pre			执行hal_uart_open后执行才有效。
*/
static rt_err_t uart_tx(rt_device_t dev, void *p_buf)
{
	int i;
	for (i = 0; i < HAL_UART_MAX; i++)
	{
		if (g_serial[i] == dev)
		{
			if (g_uart_cb[i].tx_cb)
				g_uart_cb[i].tx_cb(i, 0);
		}
	}
	
    return RT_EOK;
}



/**
* @brief		配置串口中断函数  
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @param		[in] p_tx_fcallback 发送中断回调(预留,暂不支持)
* @param		[in] p_rx_fcallback 接收中断回调    
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @pre			执行hal_uart_open后执行才有效。
* @warning 		rx_cb tx_cb至少有一个为非空 
*/
int32_t hal_uart_set_irq(uint32_t port, irq_uart_callback p_tx_fcallback, irq_uart_callback p_rx_fcallback)
{
	int32_t ret;
	
	// param check
	if ((port >= HAL_UART_MAX) || ((NULL == p_tx_fcallback) && (NULL == p_rx_fcallback))) 
	{
		ret = HAL_EPERR;
		goto failed;
	}
	// if uart is closed, return failed
	if (!GET_BIT(g_uart_status.is_open, (1U << port)))
    {
        ret = HAL_ENOPEN;
		goto failed;
    }
	
	if (p_rx_fcallback)
	{
		g_uart_cb[port].rx_cb = p_rx_fcallback;
		rt_device_set_rx_indicate(g_serial[port], uart_rx);
	}
    
	if (p_tx_fcallback)
	{
		g_uart_cb[port].tx_cb = p_tx_fcallback;
		rt_device_set_tx_complete(g_serial[port], uart_tx);
	}
	return HAL_OK;

failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;	
}

/**
* @brief		释放串口中断
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			执行hal_uart_open后执行才有效。
*/
int32_t hal_uart_free_irq(uint32_t port)
{	
	int32_t ret;

	// param check
	if (port >= HAL_UART_MAX)
	{
		ret = HAL_EPERR;
		goto failed;
	}
	// if uart is closed, return failed
	if (!GET_BIT(g_uart_status.is_open, (1U << port)))
    {
        ret = HAL_ENOPEN;
		goto failed;
    }
	
    if (!g_serial[port])
    {
    	log_e("%s is null!\n", gp_uart_dev[port]);
    	return HAL_EPERM;
    }
	
	rt_device_set_rx_indicate(g_serial[port], NULL);
	rt_device_set_tx_complete(g_serial[port], NULL);
	return HAL_OK;
failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;	
}


/**
* @brief		扩展功能 
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @param		[in] cmd 控制命令  
* @param		[in] p_arg 控制参数   
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
*/
int32_t hal_uart_ioctl(uint32_t port, uint8_t cmd, void* p_arg)
{
	
	return HAL_OK;
}

/**
* @brief        UART_HAL功能样例
* @param        argv 功能参数
* @return       返回结果
* @retval         HAL_OK 成功
* @retval         HAL_EIO 失败
*/
#ifdef RT_USING_FINSH
#ifdef RT_USING_FINSH_DEBUG
#ifdef BSP_USING_UART 
static int32_t hal_get_uart_port(const char* name)
{
	int32_t  port = -1;
		
	if(!rt_strcmp(name, "uart1"))
	{
		port = HAL_UART1;
	}
	else if(!rt_strcmp(name, "uart2"))
	{
		port = HAL_UART2;
	}
	else if(!rt_strcmp(name, "uart3"))
	{
		port = HAL_UART3;
	}
	else if(!rt_strcmp(name, "uart4"))
	{
		port = HAL_UART4;
	}
	else if(!rt_strcmp(name, "uart5"))
	{
		port = HAL_UART5;
	}
	else if(!rt_strcmp(name, "uart6"))
	{
		port = HAL_UART6;
	}
	else if(!rt_strcmp(name, "uart7"))
	{
		port = HAL_UART7;
	}
	else
	{
		rt_kprintf("the uart input is not support:%s\n",  name);
	}

	return port;
}



uint32_t g_tx_flag, g_rx_flag = false;
static void uart_rx_callback(uint32_t tim_no, uint32_t size)
{
	g_rx_flag = true;
}

#include "osif.h"
static int hal_uart_sample(int argc, char *argv[])
{
	#define  UART_BUFF_SIZE	  128
	uint8_t  uart_send_buf[] = {"ABCDEF_0123456789\r\n"};
	uint8_t  uart_rcv_buf[256]  = {0};
	char 	*uart_name = argv[1];
	int32_t  port, rcv_len;
	hal_uart_conf_t uart_config = 
	{
		.baud = 1000000,  				           
		.size = HAL_UART_8B,   	 		         
		.stop = HAL_UART_STOP1B,
		.par  = HAL_UART_PARNON,
		.flow = HAL_UART_HWFLOW_OFF,
		.buffsize = 128,
	};

	hal_uart_init();
	port = hal_get_uart_port(uart_name);
	
	if(HAL_OK != hal_uart_open(port))
	{
        return -1;
	}
	if(HAL_OK != hal_uart_setup(port, &uart_config))
	{
        return -1;
	}
	
	hal_uart_set_irq(port, NULL, uart_rx_callback);
	
	while(1)
	{
		/* 向串口写入一段固定的测试数据 */
		if(true == g_rx_flag)
		{
			g_rx_flag = false;
			memset(uart_rcv_buf, 0x00, sizeof(uart_rcv_buf));
			os_delay(os_tick_from_millisecond(1));	
			rcv_len = hal_uart_read(port, uart_rcv_buf, UART_BUFF_SIZE);
			if(0 < rcv_len)
			{
				rt_kprintf("read: '%s'\r\n", uart_rcv_buf);	
			}
			hal_uart_write(port, uart_send_buf, sizeof(uart_send_buf));	
			rt_kprintf("write:'%s'\r\n", uart_send_buf);
		}
		//rt_sem_take(&rx_sem, RT_WAITING_FOREVER);
		/* 从指定串口读取数据，最大长度UART_BUFF_SIZE */
	}
}

#endif
MSH_CMD_EXPORT(hal_uart_sample, hal_gpio_sample <uart2>);
#endif
#endif









