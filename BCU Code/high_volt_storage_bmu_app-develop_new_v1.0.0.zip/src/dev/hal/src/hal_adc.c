#include <board.h>
#include <string.h>
#include <rtthread.h>
#include <rtdevice.h>
#include "hal_adc.h"
#include "hal_gpio.h"
#include "log.h"

#define ADC_SAMPLE_TIMES    (10)                        /* ADC采样次数 */

#ifdef BSP_USING_ADC1
#define ADC1_CHNNEL_CNT		(1)						    /* ADC1通道数 */
#define ADC1_DMA_BUF_SIZE	(ADC1_CHNNEL_CNT*ADC_SAMPLE_TIMES)		/* ADC1 DMA缓冲区大小 */
static uint16_t    g_adc_dma1_buf[ADC_SAMPLE_TIMES][ADC1_CHNNEL_CNT];	/* ADC1对应DMA缓冲区 */
static uint16_t    g_adc1_result[ADC1_CHNNEL_CNT];	    /* ADC1滤波计算后结果 */
#endif

#ifdef BSP_USING_ADC2
#define ADC2_CHNNEL_CNT		(5)						    /* ADC2通道数 */
#define ADC2_DMA_BUF_SIZE	(ADC2_CHNNEL_CNT*ADC_SAMPLE_TIMES)		/* ADC2 DMA缓冲区大小 */
static uint16_t    g_adc_dma2_buf[ADC_SAMPLE_TIMES][ADC2_CHNNEL_CNT];	/* ADC2对应DMA缓冲区 */
static uint16_t    g_adc2_result[ADC2_CHNNEL_CNT];	    /* ADC2滤波计算后结果 */
#endif

static ADC_Module *g_adc_module[HAL_ADC_MAX] = {ADC1, ADC2};

typedef struct{
	uint32_t is_init;								    // 0-未初始化 1-已初始化
	uint32_t is_open;								    // 0-未打开 1-已打开
	uint32_t is_suspend;							    // 0-未挂起 1-已挂起
}adc_status_t;
static adc_status_t	g_adc_status = {0};				    /* adc状态 */



typedef struct
{
	uint8_t 	index;
	uint16_t   *result;					
}hal_adc_map_t;

/* ADC数字量和HAL层的数据映射关系 */
const static hal_adc_map_t g_adc_dma_map[ADC_IDX_MAX] =
{
	{ADC_IDX_IDC_VER,               (uint16_t*)&g_adc2_result[0]},	// 硬件版本识别
	{ADC_IDX_24V_SAM,			    (uint16_t*)&g_adc2_result[1]},	// 供电电源24V采集
	{ADC_IDX_5V_SAM, 			    (uint16_t*)&g_adc2_result[2]},	// 系统5V电源采集
	{ADC_IDX_PCB_TEMP, 		        (uint16_t*)&g_adc2_result[3]},	// 加热膜温度
	{ADC_IDX_FLAM_GAS_DECT, 		(uint16_t*)&g_adc2_result[4]},	// 可燃气体检测
    {ADC_IDX_5VA_SAM,               (uint16_t*)&g_adc1_result[0]},	// 5V电源输出采样
};

/**
* @brief		ADC加载驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
static int32_t adc_init(ADC_Module *ADCx)
{
	ADC_InitType  ADC_InitStructure;
	DMA_InitType  DMA_InitStructure;
    
    NVIC_InitType NVIC_InitStructure;

    NVIC_InitStructure.NVIC_IRQChannel                   = ADC1_2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority        = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    
#ifdef BSP_USING_ADC1      
	if (ADCx == ADC1)
	{
		n32_msp_adc_init(ADC1);
        /* 使能DMA时钟 */
	    RCC_EnableAHBPeriphClk(RCC_AHB_PERIPH_DMA1, ENABLE);
		/* DMA1_CH1 配置 */
		DMA_DeInit(DMA1_CH1);
		DMA_InitStructure.PeriphAddr     = (uint32_t)&ADC1->DAT; 	//设置外设寄存器ADC1地址
		DMA_InitStructure.MemAddr        = (uint32_t)g_adc_dma1_buf;//数据存储器的地址
		DMA_InitStructure.Direction      = DMA_DIR_PERIPH_SRC;		//传输方向 外设-内存
		DMA_InitStructure.BufSize        = ADC1_DMA_BUF_SIZE;		//存储数据大小
		DMA_InitStructure.PeriphInc      = DMA_PERIPH_INC_DISABLE;	//外设地址不增量
		DMA_InitStructure.DMA_MemoryInc  = DMA_MEM_INC_ENABLE;		//内存地址增量
		DMA_InitStructure.PeriphDataSize = DMA_PERIPH_DATA_SIZE_HALFWORD;//外设数据宽度16位
		DMA_InitStructure.MemDataSize    = DMA_MemoryDataSize_HalfWord;	 //外设和内存数据宽度一致
		DMA_InitStructure.CircularMode   = DMA_MODE_CIRCULAR;		//DMA传输模式为循环传输
		DMA_InitStructure.Priority       = DMA_PRIORITY_HIGH;		//通道优先级为高
		DMA_InitStructure.Mem2Mem        = DMA_M2M_DISABLE;			//关闭从存储器到存储器模式
		DMA_Init(DMA1_CH1, &DMA_InitStructure);	
		
		ADC_InitStruct(&ADC_InitStructure);
		ADC_InitStructure.WorkMode       = ADC_WORKMODE_INDEPENDENT;//独立工作模式
		ADC_InitStructure.MultiChEn      = ENABLE;					//使能多通道循环扫描
		ADC_InitStructure.ContinueConvEn = ENABLE;					//使能自动连续转换
		ADC_InitStructure.ExtTrigSelect  = ADC_EXT_TRIGCONV_NONE;	//转换由软件出发启动
		ADC_InitStructure.DatAlign       = ADC_DAT_ALIGN_R;			//数据选择右对齐
		ADC_InitStructure.ChsNumber      = ADC1_CHNNEL_CNT;			//转换通道数目
		ADC_Init(ADC1, &ADC_InitStructure);
		
		/* ADC1 regular channels configuration */
        ADC_ConfigRegularChannel(ADC1, ADC1_Channel_04_PA3, 1, ADC_SAMP_TIME_239CYCLES5);
    
		/* Enable ADC1 DMA */
	    ADC_EnableDMA(ADC1, ENABLE);
		/* 使能 DMA1_CH1 */
		DMA_EnableChannel(DMA1_CH1, ENABLE);
	}
#endif    
#ifdef BSP_USING_ADC2    
	else if (ADCx == ADC2)
	{
		n32_msp_adc_init(ADC2);
        /* 使能DMA时钟 */
	    RCC_EnableAHBPeriphClk(RCC_AHB_PERIPH_DMA1, ENABLE);
		/* DMA1_CH1 配置 */
		DMA_DeInit(DMA1_CH8);			
		DMA_InitStructure.PeriphAddr     = (uint32_t)&ADC2->DAT; 	//设置外设寄存器ADC1地址
		DMA_InitStructure.MemAddr        = (uint32_t)g_adc_dma2_buf;//数据存储器的地址
		DMA_InitStructure.Direction      = DMA_DIR_PERIPH_SRC;		//传输方向 外设-内存
		DMA_InitStructure.BufSize        = ADC2_DMA_BUF_SIZE;		//存储数据大小
		DMA_InitStructure.PeriphInc      = DMA_PERIPH_INC_DISABLE;	//外设地址不增量
		DMA_InitStructure.DMA_MemoryInc  = DMA_MEM_INC_ENABLE;		//内存地址增量
		DMA_InitStructure.PeriphDataSize = DMA_PERIPH_DATA_SIZE_HALFWORD;//外设数据宽度16位
		DMA_InitStructure.MemDataSize    = DMA_MemoryDataSize_HalfWord;	//外设和内存数据宽度一致
		DMA_InitStructure.CircularMode   = DMA_MODE_CIRCULAR;		//DMA传输模式为循环传输
		DMA_InitStructure.Priority       = DMA_PRIORITY_HIGH;		//通道优先级为高
		DMA_InitStructure.Mem2Mem        = DMA_M2M_DISABLE;			//关闭从存储器到存储器模式
		DMA_Init(DMA1_CH8, &DMA_InitStructure);	
		
		ADC_InitStruct(&ADC_InitStructure);
		ADC_InitStructure.WorkMode       = ADC_WORKMODE_INDEPENDENT;//独立工作模式
		ADC_InitStructure.MultiChEn      = ENABLE;					//使能多通道循环扫描
		ADC_InitStructure.ContinueConvEn = ENABLE;					//使能自动连续转换
		ADC_InitStructure.ExtTrigSelect  = ADC_EXT_TRIGCONV_NONE;	//转换由软件出发启动
		ADC_InitStructure.DatAlign       = ADC_DAT_ALIGN_R;			//数据选择右对齐
		ADC_InitStructure.ChsNumber      = ADC2_CHNNEL_CNT;			//转换通道数目
		ADC_Init(ADC2, &ADC_InitStructure);
		
		/* ADC2 regular channels configuration */
		/* TCONV = 采样时间+ 12.5 个周期 */
		ADC_ConfigRegularChannel(ADC2, ADC2_Channel_06_PC0, 1, ADC_SAMP_TIME_239CYCLES5);  
		ADC_ConfigRegularChannel(ADC2, ADC2_Channel_07_PC1, 2, ADC_SAMP_TIME_239CYCLES5);
		ADC_ConfigRegularChannel(ADC2, ADC2_Channel_08_PC2, 3, ADC_SAMP_TIME_239CYCLES5);
		ADC_ConfigRegularChannel(ADC2, ADC2_Channel_09_PC3, 4, ADC_SAMP_TIME_239CYCLES5);
		ADC_ConfigRegularChannel(ADC2, ADC2_Channel_11_PA2, 5, ADC_SAMP_TIME_239CYCLES5);
		
		/* Enable ADC1 DMA */
	    ADC_EnableDMA(ADC2, ENABLE);
		/* 使能 DMA1_CH1 */
		DMA_EnableChannel(DMA1_CH8, ENABLE);
	}
#endif
	else
	{
		return HAL_ENXIO;
	}
	
	return HAL_OK;
}


/**
* @brief		ADC加载驱动,根据配置加载对应的ADC驱动
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @warning		系统启动时默认启动
*/
int32_t hal_adc_init(void)
{    
	if (!g_adc_status.is_init)
	{
#ifdef BSP_USING_ADC1          
		memset((void *)g_adc_dma1_buf, 0, sizeof(uint16_t) * ADC1_CHNNEL_CNT*ADC_SAMPLE_TIMES);
        memset((void *)g_adc1_result, 0, sizeof(uint16_t) * ADC1_CHNNEL_CNT);
#endif
#ifdef BSP_USING_ADC2        
		memset((void *)g_adc_dma2_buf, 0, sizeof(uint16_t) * ADC2_CHNNEL_CNT*ADC_SAMPLE_TIMES);
        memset((void *)g_adc2_result, 0, sizeof(uint16_t) * ADC2_CHNNEL_CNT);
#endif
		memset((void *)&g_adc_status, 0, sizeof(adc_status_t));

	#ifdef BSP_USING_ADC1
		adc_init(ADC1);
	#endif

	#ifdef BSP_USING_ADC2
		adc_init(ADC2);
	#endif
		g_adc_status.is_init = 1;
	}
	
	return HAL_OK;
}
INIT_BOARD_EXPORT(hal_adc_init);

/**
* @brief		ADC删除驱动(跟据配置删除对应的驱动)
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
*/
int32_t hal_adc_deinit(void)
{
	if (g_adc_status.is_init)
	{
	#ifdef BSP_USING_ADC1
		ADC_Enable(ADC1, DISABLE);
		DMA_DeInit(DMA1_CH1);
		ADC_DeInit(ADC1);
	#endif
        
	#ifdef BSP_USING_ADC2
		ADC_Enable(ADC2, DISABLE);
		DMA_DeInit(DMA1_CH8);
		ADC_DeInit(ADC2);
	#endif
		memset((void *)&g_adc_status, 0, sizeof(adc_status_t));
	}
	return HAL_OK;
}


/**
* @brief		打开ADC 
* @param		[in] adc_no ADC虚拟编号 
* -# 0x00 - HAL_ADC1	
* -# 0x01 - HAL_ADC2		
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @pre			执行hal_adc_init后执行才有效。
*/
int32_t hal_adc_open(uint32_t adc_no)
{
	int32_t ret;
	ADC_Module *adc_module;

	// param check
	if (adc_no >= HAL_ADC_MAX)
	{
		ret = HAL_EPERR;
		goto failed;
	}  	
    // if adc is opened, return ok
	if (GET_BIT(g_adc_status.is_open, (1U << adc_no)))
    {
        return HAL_OK;
    } 
	// if adc is not init, return failed 
	if (!g_adc_status.is_init)
	{
		ret = HAL_EPERM;
		goto failed;
	} 	
	
	adc_module = g_adc_module[adc_no];
	/* Enable ADC1 */
	ADC_Enable(adc_module, ENABLE);
	/*Check ADC Ready*/
	while (ADC_GetFlagStatusNew(adc_module, ADC_FLAG_RDY) == RESET);

	/* Start ADCx calibration */
	ADC_StartCalibration(adc_module);
	
	/* Check the end of ADCx calibration */
	while (ADC_GetCalibrationStatus(adc_module))
		;
	/* Start ADCx Software Conversion */
    ADC_EnableSoftwareStartConv(adc_module, ENABLE);
	/* Test on DMA1 channel1 transfer complete flag */
    while (!DMA_GetFlagStatus(DMA1_FLAG_TC1, DMA1))
        ;
    /* Clear DMA1 channel1 transfer complete flag */
    DMA_ClearFlag(DMA1_FLAG_TC1, DMA1);

	SET_BIT(g_adc_status.is_open, (1U << adc_no));
	return HAL_OK;

failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;	
}


/**
* @brief		关闭ADC 
* @param		[in] adc_no ADC虚拟编号 
* -# 0x00 - HAL_ADC1	
* -# 0x01 - HAL_ADC2		
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			执行hal_adc_init后执行才有效。
*/
int32_t hal_adc_close(uint32_t adc_no)
{
	int32_t ret;
	ADC_Module *adc_module;
    
	// param check
	if (adc_no >= HAL_ADC_MAX)
	{
		ret = HAL_EPERR;
		goto failed;
	}	
	// if adc is closed, return ok
	if (!GET_BIT(g_adc_status.is_open, (1U << adc_no)))
    {
        return HAL_OK;
    } 	
 
	adc_module = g_adc_module[adc_no];
	/* Enable ADCx */
    ADC_Enable(adc_module, DISABLE);
	CLR_BIT(g_adc_status.is_open, (1U << adc_no));
	return HAL_OK;

failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;	
}


/**
* @brief		ADC功能从休眠中唤醒，恢复状态
* @param		[in] adc_no ADC虚拟编号 
* -# 0x00 - HAL_ADC1	
* -# 0x01 - HAL_ADC2		
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @warning		本接口调用后，需要把对应管脚恢复到正常状态 
*/
int32_t hal_adc_resume(uint32_t adc_no)
{
	int32_t ret;
	ADC_Module *adc_module;

    // if the device is not supended, return ok
	if (!GET_BIT(g_adc_status.is_suspend, (1U << adc_no)))
    {
        return HAL_OK;
    } 	
	// param check
	if (adc_no >= HAL_ADC_MAX)
	{
		ret = HAL_EPERR;
		goto failed;
	} 

	adc_module = g_adc_module[adc_no];
	adc_init(adc_module);
	hal_adc_open(adc_no);
    CLR_BIT(g_adc_status.is_suspend, (1U << adc_no));
	return HAL_OK;

failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;
}
 
/**
* @brief		ADC功能进入休眠模式
* @param		[in] adc_no ADC虚拟编号 
* -# 0x00 - HAL_ADC1	
* -# 0x01 - HAL_ADC2		
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式
*/
int32_t hal_adc_suspend(uint32_t adc_no)
{
	int32_t ret;
	ADC_Module *adc_module;

	// param check
	if (adc_no >= HAL_ADC_MAX)
	{
		ret = HAL_EPERR;
		goto failed;
	} 
    // if the device is supended, return ok
	if (GET_BIT(g_adc_status.is_suspend, (1U << adc_no)))
    {
        return HAL_OK;
    }    	

	adc_module = g_adc_module[adc_no];
	ADC_EnableDMA(adc_module, DISABLE);
	hal_adc_close(adc_no);
	ADC_DeInit(adc_module);
    SET_BIT(g_adc_status.is_suspend, (1U << adc_no));
	return HAL_OK;

failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;
}



/**
* @brief		启动ADC(预留)
* @param		[in] adc_no ADC虚拟编号 
* -# 0x00 - HAL_ADC1	
* -# 0x01 - HAL_ADC2		
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @pre			执行hal_adc_enable后执行才有效。
*/
int32_t hal_adc_start(uint32_t adc_no)
{
	return HAL_OK;
}


/**
* @brief		停止ADC(预留)
* @param		[in] adc_no ADC虚拟编号 
* -# 0x00 - HAL_ADC1	
* -# 0x01 - HAL_ADC2		
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			接口未使用，默认返回HAL_OK
*/
int32_t hal_adc_stop(uint32_t adc_no)
{
	return HAL_OK;
}
 

/**
* @brief		设置ADC属性(预留)
* @param		[in] adc_no ADC虚拟编号 
* -# 0x00 - HAL_ADC1	
* -# 0x01 - HAL_ADC2		
* @param		[in] p_cfg 配置属性指针
* -# p_cfg->sampling_cycle 采样频率	
* -# p_cfg->convert_mode 转换模式		
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			接口未使用，默认返回HAL_OK
*/
int32_t hal_adc_setup(uint32_t adc_no, hal_adc_config_t *p_cfg)
{
	return HAL_OK;
}


/**
* @brief		读取ADC DMA对应数据表索引通道数据
* @param		[in] channel通道
* -# ADC_IDX_DSG_OFFSET_VOLT     	= 0   	///< 开机自检电压在范围内  
* -# ADC_IDX_MOS_TEMP 		        = 1   	///< Mos温度检测 需提供NTC表
* -# ADC_IDX_DSG_MAX_CURR  		    = 2		///< 放电电流检测，偏置1000mV
* -# ADC_IDX_FILM_TEMP 		        = 3		///< 加热膜温度
* -# ADC_IDX_TOTAL_VOLT 	        = 4		///< 总压采样
* -# ADC_IDX_VOLT_P 		        = 5		///< P+ 端口电压
* -# ADC_IDX_PCB_TEMP 		        = 6		///< PCB温度采集	
* -# ADC_IDX_12V_VOLT 		        = 7  	///< SIG_12V用途,BMS运行过程中自检
* -# ADC_IDX_VOLT_G 		        = 8		///< P- 端口电压
* -# ADC_IDX_CHG_MAX_CURR 		    = 9		///< 充电电流采集
* -# ADC_IDX_DSG_MIN_CURR           = 10    ///< 放电小电流检测
* -# ADC_IDX_HW_VER 		        = 11	///< 硬件版本号
* @param		[out] *p_value 读取的adc数据 
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败
* @pre			执行hal_adc_start后执行才有效。
*/
int32_t hal_adc_read(uint32_t channel, uint16_t *p_value)
{
	int32_t ret; 

	// param check
	if ((channel >= ADC_IDX_MAX) || (!p_value))
	{
		ret = HAL_EPERR;
		goto failed;
	} 	
	// if adc is not opened, return failed
	if (
        #ifdef BSP_USING_ADC1
        !GET_BIT(g_adc_status.is_open, (1U << HAL_ADC1))
        #endif
    
        #ifdef BSP_USING_ADC2
        ||!GET_BIT(g_adc_status.is_open, (1U << HAL_ADC2))
        #endif
    )
	{
		ret = HAL_EPERM;
		goto failed;
	} 

	// 根据配置表格，完成数据映射...
	*p_value = *g_adc_dma_map[channel].result;
	return HAL_OK;

failed:
//	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;
}


/**
* @brief		ADC中断回调函数（预留）  
* @param		[in] adc_no ADC虚拟编号 
* -# 0x00 - HAL_ADC1	
* -# 0x01 - HAL_ADC2		
* @param		[in] p_fcallback 回调函数  
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			接口未使用，默认返回HAL_OK
*/
int32_t hal_adc_set_irq(uint32_t adc_no, irq_adc_callback p_fcallback)
{
	return HAL_OK;
}


/**
* @brief		扩展功能（预留） 
* @param		[in] adc_no ADC虚拟编号 
* -# 0x00 - HAL_ADC1	
* -# 0x01 - HAL_ADC2		
* @param		[in] cmd 控制命令  
* @param		[in] p_arg 控制参数   
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @pre			接口未使用，默认返回HAL_OK
*/
int32_t hal_adc_ioctl(uint32_t adc_no, uint8_t cmd, void* p_arg)
{
	return HAL_OK;
}

/**
 * @brief  This function handles ADC1 and ADC2 global interrupts requests.
 */
#define AWD_TIME    10
static uint8_t g_awd_cnt = 0;
void ADC1_2_IRQHandler(void)
{
    /* enter interrupt */
    rt_interrupt_enter();    
    /* Clear ADC1 AWD pending interrupt bit */
    if(ADC_GetIntStatus(ADC1, ADC_INT_AWD))
    {
        ADC_ClearIntPendingBit(ADC1, ADC_INT_AWD);    
        if(++g_awd_cnt >= AWD_TIME)
        {
            hal_gpio_write(DO_3_PIN,0);//TO DO 断开5V输出                
            g_awd_cnt = 0;
            ADC_ConfigInt(ADC1, ADC_INT_AWD, DISABLE);
        }

    }
    /* leave interrupt */
    rt_interrupt_leave();
}

/**
* @brief		adc滤波任务
* @return		void
*/
void hal_adc_filter_task(void)
{
    uint8_t  i, j;

#ifdef BSP_USING_ADC1    
    uint16_t adc1_value_sum[ADC1_CHNNEL_CNT] = {0};    
    for (i = 0; i < ADC1_CHNNEL_CNT; i++)
    {
        for (j = 0; j < ADC_SAMPLE_TIMES; j++)
        {
            adc1_value_sum[i] += g_adc_dma1_buf[j][i];            
        }
        g_adc1_result[i] = (adc1_value_sum[i] + ADC_SAMPLE_TIMES/2) / ADC_SAMPLE_TIMES;
    }
#endif    

#ifdef BSP_USING_ADC2  
    uint16_t adc2_value_sum[ADC2_CHNNEL_CNT] = {0};    
    for (i = 0; i < ADC2_CHNNEL_CNT; i++)
    {
        for (j = 0; j < ADC_SAMPLE_TIMES; j++)
        {
            adc2_value_sum[i] += g_adc_dma2_buf[j][i]; 
        }
        g_adc2_result[i] = (adc2_value_sum[i] + ADC_SAMPLE_TIMES/2) /ADC_SAMPLE_TIMES;
    }
#endif    
}

/**
* @brief        adc_hal功能样例
* @param        argv 功能参数
* @return       返回结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败
*/
#ifdef RT_USING_FINSH

static int hal_adc_sample(int argc, char *p_argv[])
{
	uint16_t adc_value;
    uint8_t  i, j;

	hal_adc_init();
    

#ifdef BSP_USING_ADC1
    hal_adc_open(0);
#endif
#ifdef BSP_USING_ADC2
    hal_adc_open(1);
#endif
    
    //while(1)
    {
#ifdef BSP_USING_ADC1
        for (i = 0; i < ADC1_CHNNEL_CNT; i++)
        {
            rt_kprintf("dma1_buf[%d]:",i);	
            for (j = 0; j < ADC_SAMPLE_TIMES; j++)
            {
                rt_kprintf("%d ",g_adc_dma1_buf[j][i]);	
            }
            rt_kprintf("rslt:%d\r\n",g_adc1_result[i]);
        }
#endif
        
#ifdef BSP_USING_ADC2
        for (i = 0; i < ADC2_CHNNEL_CNT; i++)
        {
            rt_kprintf("dma2_buf[%d]:",i);
            for (j = 0; j < ADC_SAMPLE_TIMES; j++)
            {
                rt_kprintf("%d ",g_adc_dma2_buf[j][i]);            
            }
            rt_kprintf("rslt:%d\r\n",g_adc2_result[i]);
        }
        rt_kprintf("\r\n");
#endif
        
        for (uint8_t index = 0; index < ADC_IDX_MAX; index++)
        {
            if(HAL_OK == hal_adc_read(index, &adc_value))
            {
                rt_kprintf("adc_index(%d): digital=%d, volt=%d.%03dv\r\n", index, adc_value, 
                            3300*adc_value/4096/1000, 3300*adc_value/4096%1000);				
            }
        }       
        rt_kprintf("\r\n");
    }
    return HAL_OK;    
}
MSH_CMD_EXPORT(hal_adc_sample, hal_adc_sample <>);

#endif


