#include <board.h>
#include <rtthread.h>
#include <rtdevice.h>
#include "hal_spi.h"
#include "string.h"
#include "log.h"
#include "n32g45x_spi.h"


/**
* @struct gpio管脚定义
* @brief  定义gpio对应的module和pin
*/
typedef struct 
{
    GPIO_Module* GPIOx;
    uint16_t GPIO_Pin;
}gpio_pin_t;


/**
* @struct spi数据信息结构体
* @brief  定义gpio对应的module和pin
*/
typedef struct 
{
	SPI_Module* SPIx;	
    uint8_t set_gpio_af;
    gpio_pin_t clk;
    gpio_pin_t mosi;
    gpio_pin_t miso;
}spi_info_t;


/**
* @struct spi参数配置信息
* @brief  分别配置spi1/spi2/spi3对应的clk、mosi、miso
*/
const spi_info_t g_spi_info[] = 
{  
	//spi设备号			clk管脚				mosi管脚			miso管脚
	{SPI1, NULL, {GPIOA, GPIO_PIN_5}, {GPIOA, GPIO_PIN_6}, {GPIOA, GPIO_PIN_7}},
	{SPI2, NULL, {GPIOB, GPIO_PIN_10},{GPIOC, GPIO_PIN_3}, {GPIOC, GPIO_PIN_2}},
	{SPI3, NULL, {GPIOB, GPIO_PIN_3}, {GPIOB, GPIO_PIN_5}, {GPIOB, GPIO_PIN_4}},
};

// 标识SPI状态
static uint8_t g_spi_status;


/**
* @brief		spi gpio初始化
* @param		[in] *spi_info 需要初始化的gpio参数信息结构体  
* @param		[in] mode spi模式，master and slave
* @return		void
* @pre			内部函数，在n32_spi_init中调用
*/
static void spi_gpio_init(const spi_info_t *p_spi_info, uint8_t mode)
{
    
	GPIO_InitType GPIO_InitStructure;

    /* Configure SPIy pins: SCK, MISO and MOSI ---------------------------------*/
    GPIO_InitStructure.Pin        = p_spi_info->clk.GPIO_Pin | p_spi_info->mosi.GPIO_Pin;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

	/* master mode */
    if (mode == HAL_SPI_MASTER)
    {
        /* Configure SCK and MOSI pins as Alternate Function Push Pull */
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    }
    else
    {
        /* Configure SCK and MOSI pins as Input Floating */
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    }
    GPIO_InitPeripheral(p_spi_info->mosi.GPIOx, &GPIO_InitStructure);

    GPIO_InitStructure.Pin = p_spi_info->miso.GPIO_Pin;

    if (mode == HAL_SPI_MASTER)
    {
        /* Configure MISO pin as Input Floating  */
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    }
    else
    {
        /* Configure MISO pin as Alternate Function Push Pull */
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    }
    GPIO_InitPeripheral(p_spi_info->miso.GPIOx, &GPIO_InitStructure);
}



/**
* @brief		spi初始化
* @param		[in] dev_no 虚拟spi设备号  
* @param		[in] *p_cfg模式，spi初始化配置参数，详见hal_spi_config_t结构体定义
* @return		void
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
* @pre			执行hal_uart_init后执行才有效。
*/
static int32_t n32_spi_init(uint32_t dev_no, hal_spi_config_t *p_cfg)
{
    SPI_InitType SPI_InitStructure;

	
    SPI_InitStructure.DataDirection = SPI_DIR_DOUBLELINE_FULLDUPLEX;
    SPI_InitStructure.CRCPoly       = 7;
    
	/* master mode */
    if (p_cfg->work_mode == HAL_SPI_MASTER)
    {
        SPI_InitStructure.SpiMode       = SPI_MODE_MASTER;
		spi_gpio_init(&g_spi_info[dev_no], HAL_SPI_MASTER);
    }
	/* slave mode */
    else
    {
		SPI_InitStructure.SpiMode       = SPI_MODE_SLAVE;
		spi_gpio_init(&g_spi_info[dev_no], HAL_SPI_SLAVE);
    }
 
    if (p_cfg->data_width == 8)
    {
        SPI_InitStructure.DataLen       = SPI_DATA_SIZE_8BITS;
    }
    else if (p_cfg->data_width == 16)
    {
        SPI_InitStructure.DataLen       = SPI_DATA_SIZE_16BITS;
    }
    else
    {
        return HAL_EIO;
    }
    
	/* trans变化模式 */
    switch (p_cfg->trans_mode)
	{
		case HAL_SPI_MODE_0:
			SPI_InitStructure.CLKPHA        = SPI_CLKPHA_FIRST_EDGE;
			SPI_InitStructure.CLKPOL        = SPI_CLKPOL_LOW;
			break;
		case HAL_SPI_MODE_1:
			SPI_InitStructure.CLKPHA        = SPI_CLKPHA_SECOND_EDGE;
			SPI_InitStructure.CLKPOL        = SPI_CLKPOL_LOW;
			break;
		case HAL_SPI_MODE_2:
			SPI_InitStructure.CLKPHA        = SPI_CLKPHA_FIRST_EDGE;
			SPI_InitStructure.CLKPOL        = SPI_CLKPOL_HIGH;
			break;
		case HAL_SPI_MODE_3:
			SPI_InitStructure.CLKPHA        = SPI_CLKPHA_SECOND_EDGE;
			SPI_InitStructure.CLKPOL        = SPI_CLKPOL_HIGH;
			break;
		default:
			return HAL_EIO;	
	}

    uint32_t spi_apb_clock;
	RCC_ClocksType clk;
	
    RCC_GetClocksFreqValue(&clk);
	spi_apb_clock = clk.Pclk2Freq;

    if (p_cfg->max_hz >= spi_apb_clock / 2)
    {
		SPI_InitStructure.BaudRatePres  = SPI_BR_PRESCALER_2;
    }
    else if (p_cfg->max_hz >= spi_apb_clock / 4)
    {
		SPI_InitStructure.BaudRatePres  = SPI_BR_PRESCALER_4;
    }
    else if (p_cfg->max_hz >= spi_apb_clock / 8)
    {
		SPI_InitStructure.BaudRatePres  = SPI_BR_PRESCALER_8;
    }
    else if (p_cfg->max_hz >= spi_apb_clock / 16)
    {
		SPI_InitStructure.BaudRatePres  = SPI_BR_PRESCALER_16;
    }
    else if (p_cfg->max_hz >= spi_apb_clock / 32)
    {
		SPI_InitStructure.BaudRatePres  = SPI_BR_PRESCALER_32;
    }
    else if (p_cfg->max_hz >= spi_apb_clock / 64)
    {
		SPI_InitStructure.BaudRatePres  = SPI_BR_PRESCALER_64;
    }
    else if (p_cfg->max_hz >= spi_apb_clock / 128)
    {
		SPI_InitStructure.BaudRatePres  = SPI_BR_PRESCALER_128;
    }
    else
    {
        /*  min prescaler 256 */
		SPI_InitStructure.BaudRatePres  = SPI_BR_PRESCALER_256;
    }

    log_d("sys freq: %d, pclk2 freq: %d, SPI limiting freq: %d, BaudRatePrescaler: %d\r\n",
          clk.SysclkFreq,
          spi_apb_clock,
          p_cfg->max_hz,
          SPI_InitStructure.BaudRatePres);

    if (p_cfg->first_bit == HAL_SPI_FIRSTBIT_MSB)
    {
		SPI_InitStructure.FirstBit      = SPI_FB_MSB;
    }
    else
    {
		SPI_InitStructure.FirstBit      = SPI_FB_LSB;
    }

	SPI_InitStructure.NSS           = SPI_NSS_SOFT;


	SPI_Init(g_spi_info[dev_no].SPIx, &SPI_InitStructure);
	SPI_Enable(g_spi_info[dev_no].SPIx, ENABLE);
    
    return HAL_OK;
}


/**
* @brief		spi数据传递
* @param		[in] dev_no 虚拟spi设备号  
* @param		[in] *p_recv 接收数据缓冲区指针
* @param		[in] *p_send 发送数据缓冲区指针
* @param		[in] 接收和发送数据缓冲区len
* @return		发送和接收的数据长度
* @pre			内部函数，供hal_spi_write和hal_spi_read调用。
*/
static uint32_t spi_xfer(uint32_t dev_no, void *p_recv, void *p_send, uint32_t len, uint8_t flags)
{
    uint32_t message_length, already_send_length;
    uint16_t send_length;
    uint8_t *recv_buf;
    const uint8_t *send_buf;
	uint32_t temp_len;

    message_length = len;
    recv_buf = p_recv;
    send_buf = p_send;
    while (message_length)
    {
        /* the HAL library use uint16 to save the data length */
        if (message_length > 65535)
        {
            send_length = 65535;
            message_length = message_length - 65535;
        }
        else
        {
            send_length = message_length;
            message_length = 0;
        }

        /* calculate the start address */
        already_send_length = len - send_length - message_length;
        send_buf = (rt_uint8_t *)p_send + already_send_length;
        recv_buf = (rt_uint8_t *)p_recv + already_send_length;
        
        /* start once data exchange in DMA mode */
        if (send_buf && recv_buf)
        {
			temp_len = 0;
			/* Wait for SPIy Tx buffer empty */
			while (SPI_I2S_GetStatus(g_spi_info[dev_no].SPIx, SPI_I2S_TE_FLAG) == RESET);
			while(temp_len < send_length)
            {
				/* Send SPIz data */
				SPI_I2S_TransmitData(g_spi_info[dev_no].SPIx, send_buf[temp_len]);
				
				/* Wait for SPIz data reception */
				while (SPI_I2S_GetStatus(g_spi_info[dev_no].SPIx, SPI_I2S_RNE_FLAG) == RESET)
					;
				/* Read SPIz received data */
				recv_buf[temp_len] = SPI_I2S_ReceiveData(g_spi_info[dev_no].SPIx);
				temp_len++;
            }
        }
        else if (send_buf)
        {
			temp_len = 0;
			/* Wait for SPIy Tx buffer empty */
			while (SPI_I2S_GetStatus(g_spi_info[dev_no].SPIx, SPI_I2S_TE_FLAG) == RESET);
			while(temp_len < send_length)
            {
				/* Send SPIz data */
				SPI_I2S_TransmitData(g_spi_info[dev_no].SPIx, send_buf[temp_len++]);
				while (SPI_I2S_GetStatus(g_spi_info[dev_no].SPIx, SPI_I2S_TE_FLAG) == RESET);
            }
        }
        else
        {
            memset((uint8_t *)recv_buf, 0xff, send_length);
			temp_len = 0;
			while(temp_len < send_length)
			{
				/* Wait for SPIz data reception */
				while (SPI_I2S_GetStatus(g_spi_info[dev_no].SPIx, SPI_I2S_RNE_FLAG) == RESET)
					;
				/* Read SPIz received data */
				recv_buf[temp_len] = SPI_I2S_ReceiveData(g_spi_info[dev_no].SPIx);
				temp_len++;
            }
        }

    }

    return len;
}



/**
* @brief		SPI加载驱动
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
*/
int32_t hal_spi_init(void)
{
	/* PCLK2 = HCLK/2 */
    RCC_ConfigPclk2(RCC_HCLK_DIV2);
	g_spi_status = 0;
	
	return HAL_OK;
}


/**
* @brief		SPI删除驱动
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
*/
int32_t hal_spi_deinit(void)
{
	return HAL_OK;
}

/**
* @brief		打开SPI功能 
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @warning 		本接口只初始化SPI总线接口 
*/
int32_t hal_spi_open(uint32_t dev_no)
{
	/* 虚拟设备端口号合法检查 */
	if (dev_no >= SPI_INDEX_MAX) 
	{
		return HAL_EIO;
	}
	/* 设备已打开，直接返回ok,避免重复打开 */
	if (GET_BIT(g_spi_status, (1U << dev_no)) != 0)
    {
        return HAL_OK;
    }
	
	/* spi1 */
	if (dev_no == SPI1_INDEX)
	{
		RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOA | RCC_APB2_PERIPH_SPI1, ENABLE);
	}
	/* spi2 */
	else if(dev_no == SPI2_INDEX)
	{
		RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE);
		RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_SPI2, ENABLE);
	}
	/* spi3 */
	else
	{
		RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, ENABLE);
		RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_SPI3, ENABLE);
	}	
	
	SET_BIT(g_spi_status, (1U << dev_no));
	return HAL_OK;
}

/**
* @brief		关闭SPI功能 
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_spi_close(uint32_t dev_no)
{
	/* 虚拟设备端口号合法检查 */
	if (dev_no >= SPI_INDEX_MAX) 
	{
		return HAL_EIO;
	}
	/* 设备已关闭，直接返回ok,避免重复关闭 */
	if (GET_BIT(g_spi_status, (1u << dev_no)) != 0)
    {
        return HAL_OK;
    }
	
	/* spi1 */
	if (dev_no == SPI1_INDEX)
	{
		//RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOA | RCC_APB2_PERIPH_SPI1, DISABLE);
		RCC_EnableAPB2PeriphReset(RCC_APB2_PERIPH_GPIOA | RCC_APB2_PERIPH_SPI1, ENABLE);
	}
	/* spi2 */
	else if(dev_no == SPI2_INDEX)
	{
		//RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, DISABLE);
		//RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_SPI2, DISABLE);
		RCC_EnableAPB2PeriphReset(RCC_APB2_PERIPH_GPIOB, ENABLE);
		RCC_EnableAPB1PeriphReset(RCC_APB1_PERIPH_SPI2, ENABLE);
	}
	/* spi3 */
	else
	{
		/* spi_cs拉低 */
    	//hal_gpio_write(HAL_PIN_SPI_CS, HAL_GPIO_LOW);  
		//RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_GPIOB, DISABLE);
		//RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_SPI3, DISABLE);
		RCC_EnableAPB2PeriphReset(RCC_APB2_PERIPH_GPIOB, ENABLE);
		RCC_EnableAPB1PeriphReset(RCC_APB1_PERIPH_SPI3, ENABLE);
	}
	
    CLR_BIT(g_spi_status, (1u << dev_no));
	return HAL_OK;
}

/**
* @brief		SPI功能从休眠中唤醒，恢复状态
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_spi_resume(uint32_t dev_no)
{
	return hal_spi_open(dev_no);
}
 
/**
* @brief		SPI功能进入休眠模式
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式，功能不影响
*/
int32_t hal_spi_suspend(uint32_t dev_no)
{
	return hal_spi_close(dev_no);
}


/**
* @brief		设置SPI属性  
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @param		[in] p_config SPI配置参数  
* - config->work_mode 使用模式
* -# HAL_SPI_MASTER = 主模式
* -# HAL_SPI_SLAVE = 从模式
* - config->trans_mode 使用模式
* -# HAL_SPI_MODE_0 = CPOL:0|CPHA:0
* -# HAL_SPI_MODE_1 = CPOL:0|CPHA:1
* -# HAL_SPI_MODE_2 = CPOL:1|CPHA:0
* -# HAL_SPI_MODE_3 = CPOL:1|CPHA:1 
* - config->data_width SPI发送数据位
* - config->first_bit SPI通信长度
* -# HAL_SPI_FIRSTBIT_MSB 
* -# HAL_SPI_FIRSTBIT_LSB
* - config->max_hz SPI频率
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @pre 			执行hal_spi_open后执行才有效。 
@code 
		CPOL 	CPHA
MODE0 	0 		0
MODE1 	0 		1
MODE2 	1 		0
MODE3 	1 		1
CPOL: SPI空闲时的时钟信号电平(1:高电平, 0:低电平)
CPHA: SPI在时钟第几个边沿采样(1:第二个边沿开始, 0:第一个边沿开始)
@endcode
*/
int32_t hal_spi_setup(uint32_t dev_no, hal_spi_config_t *p_config)
{
	/* 虚拟设备端口号合法检查 */
	if (dev_no >= SPI_INDEX_MAX) 
	{
		return HAL_EIO;
	}
	/* 设备未打开，返回失败 */
	if (GET_BIT(g_spi_status, (1u << dev_no)) == 0)
    {
        return HAL_EPERM;
    }
    
	return n32_spi_init(dev_no, p_config);
}


/**
* @brief		全双工收发数据   
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @param		[in] p_dout 发送缓冲区指针   
* @param		[out] p_din 接收缓冲区指针 
* @param		[in] len 发送和接收缓冲区长度  
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		<0 失败原因   
* @pre 			执行hal_spi_open后执行才有效。
* @warning		发送接收缓冲区必须一样大小，否则可能出现程序崩溃等异常 
*/
int32_t hal_spi_xfer(uint32_t dev_no, void *p_dout, void *p_din, uint32_t len)
{
	/* 虚拟设备端口号合法检查 */
	if (dev_no >= SPI_INDEX_MAX) 
	{
		return HAL_EIO;
	}
	/* 设备未打开，返回失败 */
	if (GET_BIT(g_spi_status, (1u << dev_no)) == 0)
    {
        return HAL_EPERM;
    }
    /* 收发数据 */
    if (spi_xfer(dev_no, p_dout, p_din, len, 0) == 0)
    {
    	return HAL_EPERM;
    }
    
	return HAL_OK;
}

/**
* @brief		SPI发数据 
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @param		[in] p_buf 缓冲区指针    
* @param		[in] len 缓冲区长度    
* @return		执行结果
* @retval		>0 发送数据长度(阻塞式)  
* @retval		=0 数据待发送(非阻塞式)，使用hal_spi_query查询发送完成情况  
* @retval		<0 失败原因   
* @pre 			执行hal_spi_open后执行才有效。 
*/
int32_t hal_spi_write(uint32_t dev_no, void *p_buf, uint32_t len)
{
    int32_t res_len;
    
	/* 虚拟设备端口号合法检查 */
	if (dev_no >= SPI_INDEX_MAX) 
	{
		return HAL_EIO;
	}
	/* 设备未打开，返回失败 */
	if (GET_BIT(g_spi_status, (1u << dev_no)) == 0)
    {
        return HAL_ENXIO;
    }
    
    res_len = spi_xfer(dev_no, NULL, p_buf, len, 0);
    
	return res_len;
}

/**
* @brief		SPI发数据 
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @param		[in] p_buf 缓冲区指针    
* @param		[in] len 缓冲区长度    
* @return		执行结果
* @retval		>0 接收数据长度
* @retval		=0 数据待接收(非阻塞式)，使用hal_spi_query查询接收完成情况 
* @retval		<0 失败原因 
* @pre 			执行hal_spi_open后执行才有效。 
*/
int32_t hal_spi_read(uint32_t dev_no, void *p_buf, uint32_t len)
{
    int32_t res_len;
    
	/* 虚拟设备端口号合法检查 */
	if (dev_no >= SPI_INDEX_MAX) 
	{
		return HAL_EIO;
	}
	/* 设备未打开，返回失败 */
	if (GET_BIT(g_spi_status, (1u << dev_no)) == 0)
    {
        return HAL_ENXIO;
    }
    
    res_len = spi_xfer(dev_no, p_buf, NULL, len, 0);

	return res_len;
}

/**
* @brief		清空收缓冲区数据（预留）
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		<0 失败原因 
* @pre 			执行hal_spi_open后执行才有效。 
*/
int32_t hal_spi_flush(uint32_t dev_no)
{
	return HAL_OK;
}

/**
* @brief		查询是否发送完毕 
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @return		执行结果
* @retval		HAL_OK 成功 
* @retval		=0 发送完毕
* @retval		<0 失败原因 
* @pre 			执行hal_spi_open后执行才有效。 
*/
int32_t hal_spi_query(uint32_t dev_no)
{
	/* 虚拟设备端口号合法检查 */
	if (dev_no >= SPI_INDEX_MAX) 
	{
		return HAL_EIO;
	}
	
	if (SPI_I2S_GetStatus(g_spi_info[dev_no].SPIx, SPI_I2S_BUSY_FLAG) == RESET)
	{
		return HAL_OK;
	}
	
	return HAL_EPERM;
}

/**
* @brief		配置SPI中断函数（预留）
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @param		[in] p_tx_fcallback 发送中断回调函数 
* @param		[in] p_rx_fcallback 接收中断回调函数  
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		<0 失败原因   
* @pre 			执行hal_spi_open后执行才有效。 
*/
int32_t hal_spi_set_irq(uint32_t dev_no, irq_spi_callback p_tx_fcallback, irq_spi_callback p_rx_fcallback)
{
	/* 虚拟设备端口号合法检查 */
	if (dev_no >= SPI_INDEX_MAX) 
	{
		return HAL_EIO;
	}
	
	return HAL_OK;
}


/**
* @brief		关闭SPI中断（预留）
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		<0 失败原因   
* @pre 			执行hal_spi_open后执行才有效。 
*/
int32_t hal_spi_free_irq(uint32_t dev_no)
{
	/* 虚拟设备端口号合法检查 */
	if (dev_no >= SPI_INDEX_MAX) 
	{
		return HAL_EIO;
	}
	
	return HAL_OK;
}


/**
* @brief		扩展功能（预留）
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @param		[in] cmd 控制命令  
* @param		[in] p_arg 控制参数   
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		<0 失败原因  
*/
int32_t hal_spi_ioctl(uint32_t dev_no, uint8_t cmd, void* p_arg)
{
	/* 虚拟设备端口号合法检查 */
	if (dev_no >= SPI_INDEX_MAX) 
	{
		return HAL_EIO;
	}
	
	return HAL_OK;
}


#ifdef RT_USING_FINSH
#include "hal.h"
static void spi_example(int argc,char *argv[])
{
    hal_spi_config_t conf_spi;
    const hal_gpio_config_t gpio_config = {HAL_GPIO_OUTPUT, HAL_GPIO_PULLUP};
    uint8_t buff[32] = {0};
    uint32_t flash_id = 0;
    
    hal_gpio_config(HAL_PIN_IDX38_SPI_CS, (hal_gpio_config_t *)&gpio_config);
    hal_spi_open(SPI3_INDEX);
    
	/* spi congig param*/
    conf_spi.work_mode = HAL_SPI_MASTER;
    conf_spi.data_width = HAL_SPI_8BIT;
    conf_spi.first_bit = HAL_SPI_FIRSTBIT_MSB;
    conf_spi.max_hz = 40*1000*1000;
    conf_spi.trans_mode = HAL_SPI_MODE_0;
    hal_spi_setup(SPI3_INDEX, &conf_spi);
    
	/* spi_cs拉低 */
    hal_gpio_write(HAL_PIN_IDX38_SPI_CS, 0);
	
	/* 读flash_id */
    uint8_t send_data = 0x9F;
    hal_spi_write(SPI3_INDEX, &send_data, 1);
	hal_spi_read(SPI3_INDEX, &buff[0], 1);
	
	send_data = 0xA5;
	hal_spi_write(SPI3_INDEX, &send_data, 1);
    hal_spi_read(SPI3_INDEX, &buff[1], 1);
	
	hal_spi_write(SPI3_INDEX, &send_data, 1);
    hal_spi_read(SPI3_INDEX, &buff[2], 1);
	
	hal_spi_write(SPI3_INDEX, &send_data, 1);
    hal_spi_read(SPI3_INDEX, &buff[3], 1);
	/* 读完 spi_cs拉高 */
    hal_gpio_write(HAL_PIN_IDX38_SPI_CS, 1);
    
    flash_id = (buff[1] << 16) | (buff[2] <<8) | (buff[3]);
    rt_kprintf("flash_id=%06x\r\n",flash_id);
    hal_spi_close(SPI3_INDEX);
    
}
MSH_CMD_EXPORT(spi_example, test spi);
#endif









