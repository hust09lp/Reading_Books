#include <board.h>
#include <string.h>
#include <rtthread.h>
#include <rtdevice.h>
#include "hal_timer.h"
#include "osif.h"
#include "log.h"

#define IS_TIMER_TYPE(TYPE)   (((TYPE) == HAL_TIMER_PERIODIC) || ((TYPE) == HAL_TIMER_ONSHOT))


// timer回调函数
static timer_callback g_timer_cb[HAL_HW_TIMER_MAX];

// 标识timer状态
static uint8_t g_timer_status;

    



static hal_hwtimer_t g_hal_timer[HAL_HW_TIMER_MAX] = {
    { 
       .tim_no        = 0,          
       .tim_handle    = TIM2,         
       .tim_irqn     = TIM2_IRQn,    
       .clk           = RCC_APB1_PERIPH_TIM2,
    },
    
    { 
       .tim_no        = 0,          
       .tim_handle    = TIM3,         
       .tim_irqn     = TIM3_IRQn,    
       .clk           = RCC_APB1_PERIPH_TIM3,
    },   

    { 
       .tim_no        = 0,          
       .tim_handle    = TIM4,         
       .tim_irqn     = TIM4_IRQn,    
       .clk           = RCC_APB1_PERIPH_TIM4,        
    },   

    { 
       .tim_no        = 0,          
       .tim_handle    = TIM6,         
       .tim_irqn     = TIM6_IRQn,   
       .clk           = RCC_APB1_PERIPH_TIM6,        
    },     

    { 
       .tim_no        = 0,          
       .tim_handle    = TIM7,         
       .tim_irqn     = TIM7_IRQn,   
       .clk           = RCC_APB1_PERIPH_TIM7,        
    }, 
};
/**
* @brief		定时器加载驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_timer_init(void)
{
	memset((void *)g_timer_cb, 0, sizeof(timer_callback)*HAL_HW_TIMER_MAX);
	g_timer_status = 0;
	return HAL_OK;
}
INIT_BOARD_EXPORT(hal_timer_init);


/**
* @brief		定时器删除驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_timer_deinit(void)
{
	return HAL_OK;
}


/**
* @brief		打开定时器  
* @param		[in] tim_no 虚拟timer编号
* -# timer1 - 0x00  
* -# timer2 - 0x01
* -# timer3 - 0x02  
* -# timer4 - 0x03  
* -# timer5 - 0x04    
* -# timer6 - 0x05
* -# timer7 - 0x06  
* -# timer8 - 0x07    
* @param		[in] mode 使用模式 暂未使用
* -# HAL_TIMER_MODE_TIMER = 定时器模式
* -# HAL_TIMER_MODE_COUNTER = 计数器模式 
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		HAL_EIO 失败   
* @pre			执行hal_timer_init后执行才有效。
*/
int32_t hal_timer_open(uint32_t tim_no, uint32_t mode)
{
	/* 虚拟设备号范围检查 */
	if (tim_no >= HAL_HW_TIMER_MAX) 
	{
		return HAL_EPERR;
	}
	
	return HAL_OK;
}


/**
* @brief		关闭定时器  
* @param		[in] tim_no 虚拟timer编号
* -# timer1 - 0x00  
* -# timer2 - 0x01
* -# timer3 - 0x02  
* -# timer4 - 0x03  
* -# timer5 - 0x04    
* -# timer6 - 0x05
* -# timer7 - 0x06  
* -# timer8 - 0x07    
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		HAL_EIO 失败   
* @pre			执行hal_timer_init后执行才有效。
*/
int32_t hal_timer_close(uint32_t tim_no)
{
	/* 虚拟设备号范围检查 */
	if (tim_no >= HAL_HW_TIMER_MAX) 
	{
		return HAL_EPERR;
	}
	/* 设备已关闭，直接返回ok,避免重复关闭 */
	if (GET_BIT(g_timer_status, (1U << tim_no)) == 0)
    {
        return HAL_OK;
    }
    
    /* TIMx enable update irq */
    TIM_ConfigInt(g_hal_timer[tim_no].tim_handle, TIM_INT_UPDATE, DISABLE);    
    
    TIM_Enable(g_hal_timer[tim_no].tim_handle, DISABLE);
    
	CLR_BIT(g_timer_status, (1U << tim_no));
	
	return HAL_OK;
}


///**
//* @brief		定时器中断回调  
//* @param		[in] dev 定时器设备句柄   
//* @return		执行结果
//* @retval		HAL_OK 成功  
//* @retval		HAL_EIO 失败   
//* @pre			内部函数。
//*/
//static rt_err_t timer_irq_cb(rt_device_t dev, rt_size_t size)
//{
//	int i;
//	for (i = 0; i < HAL_HW_TIMER_MAX; i++)
//	{
//		if (g_timer[i] == dev)
//		{
//			if (g_timer_cb[i])
//				g_timer_cb[i](i, size);
//		}
//	}
//	
//    return RT_EOK;
//}

/**
* @brief		设置定时器并启动
* @param		[in] tim_no 虚拟timer编号
* -# timer1 - 0x00  
* -# timer2 - 0x01
* -# timer3 - 0x02  
* -# timer4 - 0x03  
* -# timer5 - 0x04    
* -# timer6 - 0x05
* -# timer7 - 0x06  
* -# timer8 - 0x07    
* @param		[in] type 定时类型  
* -# HAL_TIMER_ONSHOT = 1   只产生一次中断
* -# HAL_TIMER_PERIODIC = 2 重复产生周期性中断
* @param		[in] p_timeout 定时器周期 
* @param		[in] cb 定时器中断回掉函数  
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		HAL_EIO 失败   
* @pre			执行hal_timer_init后执行才有效。
*/
int32_t hal_timer_setup(uint32_t tim_no, uint32_t type, hal_timerval_t *p_timeout, timer_callback p_fcallback)
{
    TIM_TimeBaseInitType TIM_TimeBaseStructure;
    NVIC_InitType NVIC_InitStructure;
    RCC_ClocksType  RCC_Clock;
    uint32_t freq = 0;               /* 计数频率 */
    uint32_t tim_cnt = 0;
    
	/* 参数合法性检查 */
	if ((tim_no >= HAL_HW_TIMER_MAX) 
		|| (!IS_TIMER_TYPE(type)) 
		|| (!p_timeout) 
		|| (!p_fcallback))
	{
		return HAL_EPERR;
	}
	/* 设备已打开，直接返回ok,避免重复打开 */
	if (GET_BIT(g_timer_status, (1U << tim_no)) != 0)
    {
        return HAL_OK;
    }
    
	SET_BIT(g_timer_status, (1U << tim_no));
	
	
	/* 设置超时回调函数 */		
	if(p_fcallback)
	{
		g_timer_cb[tim_no] = p_fcallback;
//		rt_device_set_rx_indicate(g_timer[tim_no], timer_irq_cb);
	}	
    
    /*## Enable peripherals and GPIO Clocks ####################################*/
    /* TIMx Peripheral clock enable */
    RCC_EnableAPB1PeriphClk(g_hal_timer[tim_no].clk,ENABLE);
    /*## Configure the NVIC for TIMx ###########################################*/
    NVIC_InitStructure.NVIC_IRQChannel = g_hal_timer[tim_no].tim_irqn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 4;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    
    RCC_GetClocksFreqValue(&RCC_Clock);
    if(p_timeout->sec > 0)
    {
        freq = 1000;    //1khz
        tim_cnt = p_timeout->sec * 1000 + p_timeout->usec / 1000;  
    }
    else
    {
        freq = 1000000; //1Mhz
        tim_cnt = p_timeout->usec;
    }
    //实际到TIM的HCLK为72MHz，而RCC_Clock.Pclk1Freq为36MHz，故计数需要*2
    tim_cnt *= 2;   
    freq = RCC_Clock.Pclk1Freq / freq - 1;

    /* Time base configuration */
    TIM_TimeBaseStructure.Period    = tim_cnt;
    TIM_TimeBaseStructure.Prescaler = 0;
    TIM_TimeBaseStructure.ClkDiv    = TIM_CLK_DIV1;
    TIM_TimeBaseStructure.CntMode   = TIM_CNT_MODE_UP;

    TIM_InitTimeBase(g_hal_timer[tim_no].tim_handle, &TIM_TimeBaseStructure);

    /* Prescaler configuration */
    TIM_ConfigPrescaler(g_hal_timer[tim_no].tim_handle, freq, TIM_PSC_RELOAD_MODE_IMMEDIATE);

    /* Selects the TIMx's One Pulse Mode */
    if(type == HAL_TIMER_ONSHOT)
    {
        TIM_SelectOnePulseMode(g_hal_timer[tim_no].tim_handle, TIM_OPMODE_SINGLE);        
    }
    else
    {
        TIM_SelectOnePulseMode(g_hal_timer[tim_no].tim_handle, TIM_OPMODE_REPET);
    }
    
    /* TIMx enable update irq */
    TIM_ConfigInt(g_hal_timer[tim_no].tim_handle, TIM_INT_UPDATE, ENABLE);   

    TIM_Enable(g_hal_timer[tim_no].tim_handle, ENABLE);
	return HAL_OK;
}

/**
* @brief		设置下次中断时间(不用每次调用setup去设置一串寄存器)
* @param		[in] tim_no 虚拟timer编号
* -# timer1 - 0x00  
* -# timer2 - 0x01
* -# timer3 - 0x02  
* -# timer4 - 0x03  
* -# timer5 - 0x04    
* -# timer6 - 0x05
* -# timer7 - 0x06  
* -# timer8 - 0x07    
* @param		[in] interval 设置下次中断时间间隔 (单位us)  
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		HAL_EIO 失败   
* @pre			需先执行hal_timer_open和hal_timer_setup后执行才有效 
*/
int32_t hal_timer_interval(uint32_t tim_no, uint32_t interval)
{
	return HAL_OK;
}

/**
* @brief		启动定时计数器 
* @param		[in] tim_no 虚拟timer编号
* -# timer1 - 0x00  
* -# timer2 - 0x01
* -# timer3 - 0x02  
* -# timer4 - 0x03  
* -# timer5 - 0x04    
* -# timer6 - 0x05
* -# timer7 - 0x06  
* -# timer8 - 0x07    
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		HAL_EIO 失败   
* @pre			需先执行hal_timer_open后执行才有效 
*/
int32_t hal_timer_start(uint32_t tim_no)
{
	return HAL_OK;
}

/**
* @brief		停止定时计数器 
* @param		[in] tim_no 虚拟timer编号
* -# timer1 - 0x00  
* -# timer2 - 0x01
* -# timer3 - 0x02  
* -# timer4 - 0x03  
* -# timer5 - 0x04    
* -# timer6 - 0x05
* -# timer7 - 0x06  
* -# timer8 - 0x07    
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		HAL_EIO 失败   
*/
int32_t hal_timer_stop(uint32_t tim_no)
{
	return HAL_OK;
}

/**
* @brief		读取定时器COUNTER值(磁头驱动会用到) 
* @param		[in] tim_no 虚拟timer编号
* -# timer1 - 0x00  
* -# timer2 - 0x01
* -# timer3 - 0x02  
* -# timer4 - 0x03  
* -# timer5 - 0x04    
* -# timer6 - 0x05
* -# timer7 - 0x06  
* -# timer8 - 0x07    
* @return		返回COUNTER计数值 
* @pre			需先执行hal_timer_open并且mode设置为HAL_TIMER_MODE_COUNTER 
*/
uint32_t hal_timer_read(uint32_t tim_no)
{
	return HAL_OK;
}

/**
* @brief		TIMER特殊命令 
* @param		[in] tim_no 虚拟timer编号
* -# timer1 - 0x00  
* -# timer2 - 0x01
* -# timer3 - 0x02  
* -# timer4 - 0x03  
* -# timer5 - 0x04    
* -# timer6 - 0x05
* -# timer7 - 0x06  
* -# timer8 - 0x07    
* @param		[in] cmd 命令字
* -# HAL_TIMER_CMD_CLK_DIV = 设置TIMER分频 
* @param		[in] param 对应cmd的参数，没有参数则为NULL
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		<0 失败原因     
* @pre			执行hal_timer_open后执行才有效 
*/
int32_t hal_timer_ioctl(uint32_t tim_no, int32_t cmd, int32_t param)
{
	return HAL_OK;
}

void TIM2_IRQHandler(void)
{
    /* enter interrupt */
    rt_interrupt_enter();

    if (TIM_GetIntStatus(TIM2, TIM_INT_UPDATE) == SET)
    {
        TIM_ClrIntPendingBit(TIM2, TIM_INT_UPDATE);
        g_timer_cb[HAL_HW_TIMER1](HAL_HW_TIMER1, 0);
    }
    /* leave interrupt */
    rt_interrupt_leave();
}

void TIM3_IRQHandler(void)
{
    /* enter interrupt */
    rt_interrupt_enter();

    if (TIM_GetIntStatus(TIM3, TIM_INT_UPDATE) == SET)
    {
        TIM_ClrIntPendingBit(TIM3, TIM_INT_UPDATE);
        g_timer_cb[HAL_HW_TIMER2](HAL_HW_TIMER2, 0);
    }
    /* leave interrupt */
    rt_interrupt_leave();
}

void TIM4_IRQHandler(void)
{
    /* enter interrupt */
    rt_interrupt_enter();

    if (TIM_GetIntStatus(TIM4, TIM_INT_UPDATE) == SET)
    {
        TIM_ClrIntPendingBit(TIM4, TIM_INT_UPDATE);
        g_timer_cb[HAL_HW_TIMER3](HAL_HW_TIMER3, 0);
    }
    /* leave interrupt */
    rt_interrupt_leave();
}

void TIM6_IRQHandler(void)
{
    /* enter interrupt */
    rt_interrupt_enter();

    if (TIM_GetIntStatus(TIM6, TIM_INT_UPDATE) == SET)
    {
        TIM_ClrIntPendingBit(TIM6, TIM_INT_UPDATE);
        g_timer_cb[HAL_HW_TIMER4](HAL_HW_TIMER4, 0);
    }
    /* leave interrupt */
    rt_interrupt_leave();
}

void TIM7_IRQHandler(void)
{
    /* enter interrupt */
    rt_interrupt_enter();

    if (TIM_GetIntStatus(TIM7, TIM_INT_UPDATE) == SET)
    {
        TIM_ClrIntPendingBit(TIM7, TIM_INT_UPDATE);
        g_timer_cb[HAL_HW_TIMER5](HAL_HW_TIMER5, 0);
    }
    /* leave interrupt */
    rt_interrupt_leave();
}

/**
* @brief        PWM_HAL功能样例
* @param        argv 功能参数
* @return       返回结果
* @retval         HAL_OK 成功
* @retval         HAL_EIO 失败
*/
//#define RT_USING_FINSH_DEBUG
#ifdef RT_USING_FINSH
#ifdef RT_USING_FINSH_DEBUG
#if defined(BSP_USING_PWM)

static int32_t timeout_cb(uint32_t tim_no, uint32_t size)
{
    rt_kprintf("%d\n", os_kernel_get_tick_count());
    return 0;
}

static int32_t timeout_cb2(uint32_t tim_no, uint32_t size)
{
    rt_kprintf("t2:%d\n", os_kernel_get_tick_count());
    return 0;
}
static int hal_timer_sample(int argc, char *argv[])
{
	char 	*pwm_opt  = argv[1];
	hal_timerval_t hwtimerval = {1, 0};
	
	if (!rt_strcmp(pwm_opt, "start"))
	{
        rt_kprintf("s:%d\n", os_kernel_get_tick_count());
		hal_timer_open(HAL_HW_TIMER3, HAL_TIMER_MODE_TIMER);
		hal_timer_setup(HAL_HW_TIMER3, HAL_TIMER_PERIODIC, &hwtimerval, timeout_cb);
		hal_timer_open(HAL_HW_TIMER2, HAL_TIMER_MODE_TIMER);
		hal_timer_setup(HAL_HW_TIMER2, HAL_TIMER_ONSHOT, &hwtimerval, timeout_cb2); 
        
	}
	if (!rt_strcmp(pwm_opt, "stop"))
	{
		hal_timer_close(HAL_HW_TIMER3);
        hal_timer_close(HAL_HW_TIMER2);
	}
	
	return HAL_OK;
}
#endif
MSH_CMD_EXPORT(hal_timer_sample, hal_timer_sample <start/stop>);
#endif
#endif






