#include <rtthread.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "sfud.h"
#include "log.h"
#include "hal_flash.h"
#include "n32g45x.h"

static const sfud_flash *gp_flash = NULL;

/**
* @brief		FLASH加载驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_flash_init(void)
{
    if (sfud_init() != SFUD_SUCCESS) 
    {
        return HAL_ENXIO;
    }
    
    gp_flash = sfud_get_device_table();
    
	return HAL_OK;
}
//INIT_DEVICE_EXPORT(hal_flash_init);


/**
* @brief		FLASH删除驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_flash_deinit(void)
{
 
	return HAL_EPERM;
}


/**
* @brief		获取flash信息 
* @param		[in] dev_no 设备端口号 
-# HAL_FLASH_ID_INT = 内部Flash 
-# HAL_FLASH_ID_EXT = 外部Flash  
* @param		[in] info flash信息结构体  
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		HAL_EIO 失败   
*/
int32_t hal_flash_get_info(uint32_t dev_no, hal_flash_info_t *info)
{
    if ((gp_flash == NULL) || (!info))
    {
        return HAL_EPERM;
    }

    if (dev_no == HAL_FLASH_ID_INT)
    {
        info->total_size = 1024 * 8;
        info->sector_size = 1024 * 2;
        return HAL_OK;
    }

    if (dev_no == HAL_FLASH_ID_EXT)
    {
        info->total_size = gp_flash->chip.capacity;
        info->sector_size = gp_flash->chip.erase_gran;
        return HAL_OK;
    }

    return HAL_EPERM;
}

/**
* @brief		获取flash唯一ID  
* @param		[in] dev_no 设备端口号  
-# HAL_FLASH_ID_INT = 内部Flash 
-# HAL_FLASH_ID_EXT = 外部Flash  
* @param		[in] id 存储buffer   
* @param		[in] len buffer深度   
* @return		执行结果
* @retval		>=0 读取id长度  
* @retval		<0 失败原因  
*/
int32_t hal_flash_get_sn(uint32_t dev_no, uint8_t *id, uint32_t len)
{ 
    if ((dev_no != HAL_FLASH_ID_EXT) || (gp_flash == NULL) || (!id))
	{
        return HAL_EPERM;	
	}
    
    memset(id, 0 ,len);
    
    if (len == 1)
    {
        id[0] = gp_flash->chip.capacity_id;
    }
    
    else if (len == 2)
    {
		id[0] = gp_flash->chip.capacity_id;
        id[1] = gp_flash->chip.mf_id;
    }
    
    else if (len == 3)
    {
		id[0] = gp_flash->chip.capacity_id;
        id[1] = gp_flash->chip.mf_id;
        id[2] = gp_flash->chip.type_id;
    }
	else
	{
		return HAL_EPERM;	
	}
    
    return HAL_OK;
}

/**
* @brief		写数据
* @param		[in] dev_no 设备端口号  
-# HAL_FLASH_ID_INT = 内部Flash 
-# HAL_FLASH_ID_EXT = 外部Flash  
* @param		[in] offset flash地址偏移   
* @param		[in] len buffer深度   
* @param		[in] buf 写入数据缓冲区  
* @return		执行结果
* @retval		>=0 成功
* @retval		<0 失败原因  
*/
int32_t hal_flash_write(uint32_t dev_no, uint32_t offset, uint32_t len, uint8_t *buf) {

    if ((len == 0) || (!buf))
	{
        return HAL_EPERM;		
	}

    if (dev_no == HAL_FLASH_ID_INT) { // 写内部flash数据
        if ((offset < 0x8009000) || (0x800C000 <= offset))
        { // 超出范围
            return HAL_EPERM;
        }
        FLASH_Unlock();
        if (offset % sizeof(uint32_t)) { // 地址需要为4字节对齐
            return HAL_EPERM;
        }
        if (len % sizeof(uint32_t)) { // 长度需要为4字节的整数倍
            return HAL_EPERM;
        }
        uint32_t *data   = (uint32_t *) buf;
        uint32_t  length = len >> 2;
        while (length--) {
            FLASH_ProgramWord(offset, *data);
            offset += 4;
            data++;
        }
        FLASH_Lock();
        return len;
    }

    if (dev_no == HAL_FLASH_ID_EXT)
    {
        sfud_err result;

        if (gp_flash == NULL)
            return HAL_EIO;

        result = sfud_write(gp_flash, offset, len, buf);

        if (result == SFUD_SUCCESS)
        {
            return len;
        }
    }

    if (dev_no == HAL_FLASH_ID_EXT2)
    {
        sfud_err result;

        if (gp_flash == NULL)
            return HAL_EIO;

        result = sfud_erase_write(gp_flash, offset, len, buf);

        if (result == SFUD_SUCCESS)
        {
            return len;
        }
    }

    return HAL_EPERM;
}

/**
* @brief		读数据
* @param		[in] dev_no 设备端口号 
-# HAL_FLASH_ID_INT = 内部Flash 
-# HAL_FLASH_ID_EXT = 外部Flash  
* @param		[in] offset flash地址偏移   
* @param		[in] len buffer深度   
* @param		[in] buf 写入数据缓冲区  
* @return		执行结果
* @retval		>=0 读取长度  
* @retval		<0 失败原因  
*/
int32_t hal_flash_read(uint32_t dev_no, uint32_t offset, uint32_t len, uint8_t *buf) {

	if ((len == 0) || (!buf))
	{
        return HAL_EPERM;		
	}
	
    if (dev_no == HAL_FLASH_ID_INT) { // 读内部flash数据
        if ((offset < 0x8009000) || (0x800C000 <= offset))
        { // 超出范围
            return HAL_EPERM;
        }
        uint8_t *data = (uint8_t *) offset;
        uint32_t i;
        for (i = 0; i < len; i++) {
            *buf = *data;
            buf++;
            data++;
        }
        return len;
    }

    if (dev_no == HAL_FLASH_ID_EXT) {
        sfud_err result;

        if (gp_flash == NULL)
            return HAL_EIO;

        result = sfud_read(gp_flash, offset, len, buf);

        if (result == SFUD_SUCCESS) {
            return len;
        }
    }
    return HAL_ERR;
}

/**
* @brief		擦除 
* @param		[in] dev_no 设备端口号  
-# HAL_FLASH_ID_INT = 内部Flash 
-# HAL_FLASH_ID_EXT = 外部Flash  
* @param		[in] offset flash地址偏移    
* @param		[in] len buffer深度   
* @return		执行结果
* @retval		>=0 成功  
* @retval		<0 失败原因  
*/
int32_t hal_flash_erase(uint32_t dev_no, uint32_t offset, uint32_t len) {

    if (dev_no == HAL_FLASH_ID_INT)
    {
        if ((offset < 0x8009000) || (0x800C000 <= offset))
        { // 超出范围
            return HAL_EPERM;
        }
        FLASH_Unlock();
        FLASH_EraseOnePage(offset);
        FLASH_Lock();
        return HAL_OK;
    }

    if (dev_no == HAL_FLASH_ID_EXT) {
        sfud_err result;

        if (gp_flash == NULL)
            return HAL_EIO;

        result = sfud_erase(gp_flash, offset, len);

        if (result == SFUD_SUCCESS) {
            return len;
        }
    }
    return HAL_EPERM;
}

/**
* @brief     整块芯片擦除 
* @param     [in] dev_no 设备端口号  
-# HAL_FLASH_ID_INT = 内部Flash 
-# HAL_FLASH_ID_EXT = 外部Flash   
* @return    执行结果
* @retval 0  成功 
* @retval <0 失败原因  
*/
int32_t hal_flash_chip_erase(uint32_t dev_no) {

	return HAL_EPERM; //不支持该接口
	
//    if (dev_no == HAL_FLASH_ID_INT) {
//        return HAL_OK;
//    }

//    if (dev_no == HAL_FLASH_ID_EXT) {
//        sfud_err result;

//        if (gp_flash == NULL)
//            return HAL_EIO;

//        result = sfud_chip_erase(gp_flash);

//        if (result == HAL_OK) {
//            return HAL_OK;
//        }
//    }

//    return HAL_ERR;
}

/**
* @brief		扩展功能 
* @param		[in] dev_no 设备端口号  
* @param		[in] cmd 控制命令  
* @param		[in] arg 控制参数   
* @return		执行结果
* @retval		HAL_OK 成功    
* @retval		<0 失败原因  
*/
int32_t hal_flash_ioctl(int32_t dev_no, uint8_t cmd, void* arg)
{
    
    
    return HAL_EPERM;
}



#ifdef RT_USING_FINSH
//#ifdef RT_USING_FINSH_DEBUG
#if 0
static void sfud_demo(uint32_t addr, size_t size, uint8_t *data) {
    sfud_err result = SFUD_SUCCESS;
    const sfud_flash *flash = sfud_get_device_table() + 0;
    size_t i;
    /* prepare write data */
    for (i = 0; i < size; i++) {
        data[i] = i;
    }
    /* erase test */
    result = sfud_erase(flash, addr, size);
    if (result == SFUD_SUCCESS) {
        rt_kprintf("Erase the %s flash data finish. Start from 0x%08X, size is %ld.\r\n", flash->name, addr,
                size);
    } else {
        rt_kprintf("Erase the %s flash data failed.\r\n", flash->name);
        return;
    }
    /* write test */
    result = sfud_write(flash, addr, size, data);
    if (result == SFUD_SUCCESS) {
        rt_kprintf("Write the %s flash data finish. Start from 0x%08X, size is %ld.\r\n", flash->name, addr,
                size);
    } else {
        rt_kprintf("Write the %s flash data failed.\r\n", flash->name);
        return;
    }
    /* read test */
    result = sfud_read(flash, addr, size, data);
    if (result == SFUD_SUCCESS) {
        rt_kprintf("Read the %s flash data success. Start from 0x%08X, size is %ld. The data is:\r\n", flash->name, addr,
                size);
        rt_kprintf("Offset (h)\t00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F");
        for (i = 0; i < size; i++) {
            if (i % 16 == 0) {
                rt_kprintf("\r\n[%08X]\t", addr + i);
            }
            rt_kprintf("%02X ", data[i]);
//            if (((i + 1) % 16 == 0) || i == size - 1) {
//                rt_kprintf("\r\n");
//            }
        }
        rt_kprintf("\r\n");
    } else {
        rt_kprintf("Read the %s flash data failed.\r\n", flash->name);
    }
    /* data check */
    for (i = 0; i < size; i++) {
        if (data[i] != i % 256) {
            rt_kprintf("Read and check write data has an error. Write the %s flash data failed.\r\n", flash->name);
			break;
        }
    }
    if (i == size) {
        rt_kprintf("The %s flash test is success.\r\n", flash->name);
    }
}



#define SFUD_DEMO_TEST_BUFFER_SIZE                     1024

static uint8_t sfud_demo_test_buf[SFUD_DEMO_TEST_BUFFER_SIZE];


void test_flash(int argc, char *argv[])
{
    
    
    
    if (sfud_init() == SFUD_SUCCESS) {
        sfud_demo(0, sizeof(sfud_demo_test_buf), sfud_demo_test_buf);
    }
 
}

MSH_CMD_EXPORT(test_flash, test spi flash);
#endif

#if 1 // 测试内部flash的读写
#include "log.h"
void mcu_flash_test(int argc, char *argv[]) {
    log_d("sdk_iap_set_flag_test\r\n");
    switch (argv[1][0]) {
    case '0': { 
        hal_flash_init();
        log_d("初始化flash\r\n");
        break;
    }
    case '1': {
        int len = hal_flash_erase(HAL_FLASH_ID_INT, 0x0800A000, 8);
        log_d("mcu flash erase1\r\n");
        break;
    }
    case '2': {
        int len = hal_flash_erase(HAL_FLASH_ID_INT, 0x0800A800, 8);
        log_d("mcu flash erase2\r\n");
        break;
    }
    case '3': {
        int len = hal_flash_write(HAL_FLASH_ID_INT, 0x0800A03c, 8, (uint8_t *) "app app ");
        log_d("mcu flash write1 len %d\r\n", len);
        break;
    }
    case '4': {
        int len = hal_flash_write(HAL_FLASH_ID_INT, 0x0800A83c, 8, (uint8_t *) "corecore");
        log_d("mcu flash write2 len %d\r\n", len);
        break;
    }
    case '5': {
        char buf[9]={0};
        int len = hal_flash_read(HAL_FLASH_ID_INT, 0x0800A03c, 8, (uint8_t *) buf);
        log_d(buf);
        break;
    }
    case '6': {
        char buf[9]={0};
        int len = hal_flash_read(HAL_FLASH_ID_INT, 0x0800A83c, 8, (uint8_t *) buf);
        log_d(buf);
        break;
    }
    default:
        break;
    }
}

MSH_CMD_EXPORT(mcu_flash_test, test);

#endif

#if 0 // 测试外部flash的读写
#include <rtthread.h>
#include "log.h"
void mcu_flash_test(int argc, char *argv[]) {
    switch (argv[1][0]) {
    case '0': { 
        hal_flash_init();
        log_d("hal_flash_init\r\n");
        break;
    }
    case '1': {
        int len = hal_flash_erase(HAL_FLASH_ID_EXT, 0, 8);
        log_d("mcu flash erase1\r\n");
        break;
    }
    case '2': {
        char buf[9]={0};
        int len = hal_flash_read(HAL_FLASH_ID_EXT, 0, 8, (uint8_t *) buf);
        log_d(buf);
        break;
    }
    case '3': {
        const char *str="appappyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy";
        int len = hal_flash_write(HAL_FLASH_ID_EXT, 0, sizeof("appappyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy"), (uint8_t *) str);
        log_d("mcu flash write1 len %d\r\n", len);
        break;
    }
    case '4': {
        hal_flash_chip_erase(HAL_FLASH_ID_EXT);
        log_d("hal_flash_chip_erase \r\n");
        break;
    }
    default:
        break;
    }
}

MSH_CMD_EXPORT(mcu_flash_test, test);

#endif
//#endif
#endif



