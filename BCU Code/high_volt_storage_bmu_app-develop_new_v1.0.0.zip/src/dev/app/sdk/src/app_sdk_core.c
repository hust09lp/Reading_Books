
#include "sdk.h"


core_interface_t *gp_sdk_core_api;


int core_app_api_init(void)
{
    gp_sdk_core_api = (core_interface_t *)(CORE_INTERFACE_API_ADDR);
    
    return 0;
}











