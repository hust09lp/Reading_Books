#ifndef __SDK_H__
#define __SDK_H__

#include "sdk_core.h"
/**
* @file 头文件
* @author chenenzhi
* @data 2021/6/12。
* <table>
* <tr><th>大版本号  <th>中版本号	<th>小版本号</tr>
* <tr><td>一般当软件整体重写，或出现不向后兼容的改变时，增加此版本号
  <td>当功能更新，出现新功能时增加
  <td>小修改，如修复bug，只要有修改就增加本版本号<td>
* </tr>
* </table>
*/

int core_app_api_init(void);

extern core_interface_t *gp_sdk_core_api;
/*********************************************************************************
***
***  redfine core_sdk api接口，app可直接调用
***
*********************************************************************************/

#define sdk_version_get                     (gp_sdk_core_api->core_sdk_version_get)
/* sdk os */			
#define os_delay                            (gp_sdk_core_api->core_sdk_os_delay)
#define os_tick_from_millisecond            (gp_sdk_core_api->core_sdk_os_tick_from_millisecond)
#define os_thread_new                       (gp_sdk_core_api->core_sdk_os_thread_new)
#define os_delay_until                      (gp_sdk_core_api->core_sdk_os_delay_until)
			
/* sdk public */	
#define sdk_delay_ms                        (gp_sdk_core_api->core_sdk_delay_ms)
#define sdk_delay_us                        (gp_sdk_core_api->core_sdk_delay_us)
#define sdk_tick_get                        (gp_sdk_core_api->core_sdk_tick_get)
#define sdk_is_tick_over                    (gp_sdk_core_api->core_sdk_is_tick_over)
#define sdk_rtc_set                         (gp_sdk_core_api->core_sdk_rtc_set)
#define sdk_rtc_get                         (gp_sdk_core_api->core_sdk_rtc_get)
#define sdk_wdt_enable                      (gp_sdk_core_api->core_sdk_wdt_enable)
#define sdk_wdt_feed                        (gp_sdk_core_api->core_sdk_wdt_feed)
#define sdk_system_reset                    (gp_sdk_core_api->core_sdk_system_reset)
				
/* sdk dido */
#define sdk_dido_write                      (gp_sdk_core_api->core_sdk_dido_write)
#define sdk_dido_read                       (gp_sdk_core_api->core_sdk_dido_read)
#define sdk_dido_set_irq                    (gp_sdk_core_api->core_sdk_dido_set_irq)
#define sdk_dido_free_irq                   (gp_sdk_core_api->core_sdk_dido_free_irq)
#define sdk_dido_config                     (gp_sdk_core_api->core_sdk_dido_config)
			
/* sdk beep */			
#define sdk_buzzer_init                     (gp_sdk_core_api->core_sdk_buzzer_init)
#define sdk_buzzer_tick                     (gp_sdk_core_api->core_sdk_buzzer_tick)
#define sdk_buzzer_on                       (gp_sdk_core_api->core_sdk_buzzer_on)
#define sdk_buzzer_off                      (gp_sdk_core_api->core_sdk_buzzer_off)
			
/* sdk led */			
#define sdk_led_init                        (gp_sdk_core_api->core_sdk_led_init)
#define sdk_led_flash                       (gp_sdk_core_api->core_sdk_led_flash)
#define sdk_led_on                          (gp_sdk_core_api->core_sdk_led_on)
#define sdk_led_off	                        (gp_sdk_core_api->core_sdk_led_off)
			
/* sdk mos */			
#define sdk_mos_init                        (gp_sdk_core_api->core_sdk_mos_init)
#define sdk_mos_write                       (gp_sdk_core_api->core_sdk_mos_write)
#define sdk_mos_read                        (gp_sdk_core_api->core_sdk_mos_read)

/* sdk can */
#define sdk_can_init                        (gp_sdk_core_api->core_sdk_can_init)
#define sdk_can_open                        (gp_sdk_core_api->core_sdk_can_open)
#define sdk_can_close                       (gp_sdk_core_api->core_sdk_can_close)
#define sdk_can_setup                       (gp_sdk_core_api->core_sdk_can_setup)
#define sdk_can_write                       (gp_sdk_core_api->core_sdk_can_write)
#define sdk_can_read                        (gp_sdk_core_api->core_sdk_can_read)
#define sdk_can_set_irq                     (gp_sdk_core_api->core_sdk_can_set_irq)
#define sdk_can_free_irq                    (gp_sdk_core_api->core_sdk_can_free_irq)

/* sdk sample */
#define sdk_sample_init                     (gp_sdk_core_api->core_sdk_sample_init)
#define sdk_sample_adjust_cali              (gp_sdk_core_api->core_sdk_sample_adjust_cali)
#define sdk_sample_adjust_set               (gp_sdk_core_api->core_sdk_sample_adjust_set)
#define sdk_sample_abnormal_get             (gp_sdk_core_api->core_sdk_sample_abnormal_get)
#define sdk_sample_data_get                 (gp_sdk_core_api->core_sdk_sample_data_get)

/* sdk balance */
#define sdk_balance_set                     (gp_sdk_core_api->core_sdk_balance_set)
#define sdk_balance_state_get               (gp_sdk_core_api->core_sdk_balance_state_get)

/* sdk low power */
#define sdk_pm_enable                       (gp_sdk_core_api->core_sdk_pm_enable)
#define sdk_pm_get_lock_id                  (gp_sdk_core_api->core_sdk_pm_get_lock_id)
#define sdk_pm_lock                         (gp_sdk_core_api->core_sdk_pm_lock)
#define sdk_pm_unlock                       (gp_sdk_core_api->core_sdk_pm_unlock)
#define sdk_pm_wakeup_source_enable         (gp_sdk_core_api->core_sdk_pm_wakeup_source_enable)
#define sdk_pm_get_wakeup_source            (gp_sdk_core_api->core_sdk_pm_get_wakeup_source)
	
/* sdk para */
#define sdk_para_init                       (gp_sdk_core_api->core_sdk_para_init)
#define sdk_para_write                      (gp_sdk_core_api->core_sdk_para_write)
#define sdk_para_read                       (gp_sdk_core_api->core_sdk_para_read)
#define sdk_para_sync                       (gp_sdk_core_api->core_sdk_para_sync)

/* sdk iap para */
#define sdk_iap_set_flag                    (gp_sdk_core_api->core_sdk_iap_set_flag)
#define sdk_iap_read_flag                   (gp_sdk_core_api->core_sdk_iap_read_flag)

/* sdk record */
#define sdk_record_init                     (gp_sdk_core_api->core_sdk_record_init)
#define sdk_record_get_max_num              (gp_sdk_core_api->core_sdk_record_get_max_num)
#define sdk_record_get_index                (gp_sdk_core_api->core_sdk_record_get_index)
#define sdk_record_write                    (gp_sdk_core_api->core_sdk_record_write)
#define sdk_record_read                     (gp_sdk_core_api->core_sdk_record_read)
#define sdk_record_sync                     (gp_sdk_core_api->core_sdk_record_sync)
#define sdk_record_delete                   (gp_sdk_core_api->core_sdk_record_delete)
	
/* sdk fs */
#define sdk_fs_open                         (gp_sdk_core_api->core_sdk_fs_open)
#define sdk_fs_close                        (gp_sdk_core_api->core_sdk_fs_close)
#define sdk_fs_read                         (gp_sdk_core_api->core_sdk_fs_read)
#define sdk_fs_write                        (gp_sdk_core_api->core_sdk_fs_write)
#define sdk_fs_lseek                        (gp_sdk_core_api->core_sdk_fs_lseek)
#define sdk_fs_get_size                     (gp_sdk_core_api->core_sdk_fs_get_size)
#define sdk_fs_file_sync                    (gp_sdk_core_api->core_sdk_fs_file_sync)
#define sdk_fs_remove                       (gp_sdk_core_api->core_sdk_fs_remove)
#define sdk_fs_rename                       (gp_sdk_core_api->core_sdk_fs_rename)
//#define sdk_fs_move                       (gp_sdk_core_api->core_sdk_fs_move)
//#define sdk_fs_mkdir                      (gp_sdk_core_api->core_sdk_fs_mkdir)
			
/* sdk log */			
#define log_init                            (gp_sdk_core_api->core_sdk_log_init)
#define log_level_set                       (gp_sdk_core_api->core_sdk_log_level_set)
#define log_level_get                       (gp_sdk_core_api->core_sdk_log_level_get)
#define log_hexdump                         (gp_sdk_core_api->core_sdk_log_hexdump)
#define log_a                               (gp_sdk_core_api->core_sdk_log_a)
#define log_e                               (gp_sdk_core_api->core_sdk_log_e)
#define log_w                               (gp_sdk_core_api->core_sdk_log_w)
#define log_i                               (gp_sdk_core_api->core_sdk_log_i)
#define log_d                               (gp_sdk_core_api->core_sdk_log_d)



#endif
