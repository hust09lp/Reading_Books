/**
 * @file         data_types.h
 * @brief        数据类型定义
 * @details      主要定义了统一的数据类型，各层都可以调用
 * @author       SOFAR
 * @date         2023/02/23
 * @version      V0.0.1
 * @copyright    Copyright(c) 2022 by SofarSolar, All Rights Reserved. 
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author    <th>Description
 * <tr><td>2023/02/23  <td>0.0.1    <td>Chace     <td>创建初始版本
 * </table>
 *
 **********************************************************************************
 */

#ifndef __DATA_TYPES_H__
#define __DATA_TYPES_H__

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>


// typedef unsigned char   uint8_t;
// typedef unsigned short  uint16_t;
// typedef unsigned int    uint32_t;
// typedef __signed char   int8_t;
// typedef __signed short  int16_t;
// typedef __signed int    int32_t;
typedef float 	        float32_t;
typedef double	        float64_t;

//#ifndef SF_MAX
//#define SF_MAX(x, y)    (((x) > (y)) ? (x) : (y)) 
//#endif

//#ifndef SF_MIN
//#define SF_MIN(x, y)    (((x) < (y)) ? (x) : (y)) 
//#endif

//#ifndef SF_NULL
//#define SF_NULL         ((void*)(0))
//#endif

#ifndef SF_SET_BIT
#define SF_SET_BIT(a,b)    ((a) |= (b))
#endif

#ifndef SF_CLR_BIT
#define SF_CLR_BIT(a,b)    ((a) &= ~(b)) 
#endif

#ifndef SF_GET_BIT
#define SF_GET_BIT(a,b)    ((a) & (b))
#endif

// 获取列表类型的元素个数
#ifndef ITEM_NUM
#define ITEM_NUM(items) (sizeof(items) / sizeof(items[0]))
#endif

    
// 得到一个field在结构体(struct)中的偏移量位置 
#ifndef ST_VAR_POS
#define ST_VAR_POS( type, field ) ( (uint32_t) &(( type *) 0)-> field )
#endif

// 得到一个结构体中field所占用的字节数 
#ifndef ST_VAR_SIZE
#define ST_VAR_SIZE( type, field )  sizeof( ((type *) 0)->field) 
#endif

#endif  /* __DATA_TYPES_H__ */
