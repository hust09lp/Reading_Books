#ifndef __SDK_PM_H__
#define __SDK_PM_H__

#include <stdint.h>


enum {
    WAKEUP_SOURCE_KEY1   = 1, ///< 开机
    WAKEUP_SOURCE_CHARGE = 2, ///< 充电
    WAKEUP_SOURCE_PCS    = 3, ///< PCS通讯(外CAN)
    WAKEUP_SOURCE_ID_IN  = 4, ///< 拼机
};


#ifndef SDK_API_INTERFACE_ENABLE	///< SDK接口对外声明是否打开

/**
 * @brief  使能休眠功能
 * @param  [in]  enter_sleep_time 多少毫秒后休眠功能生效
 * @param  [in]  level 休眠等级
 * @return 无
 */
void sdk_pm_enable(uint32_t enter_sleep_time, uint8_t level);

/**
 * @brief  获取休眠锁id
 * @retval 1~32 休眠锁id
 * @retval <0 获取失败
 */
int8_t sdk_pm_get_lock_id(void);

/**
 * @brief  锁住休眠功能
 * @param[in]  lock_id 休眠锁id，取值范围（0~31）
 * @retval 0 锁住成功
 * @retval <0 锁住失败
 */
int32_t sdk_pm_lock(uint8_t lock_id);

/**
 * @brief  解锁休眠功能
 * @param  [in]  lock_id 休眠锁id，取值范围（0~31）
 * @retval 0 解锁成功
 * @retval <0 解锁失败
 */
int32_t sdk_pm_unlock(uint8_t lock_id);

/**
 * @brief  使能换醒源
 * @note  每次只使能一个，要使能多个则需要多次调用
 * @param  [in]  wakeup_source 换醒源掩码。取值如下
 * -# WAKEUP_SOURCE_KEY1    按键开机换醒
 * -# WAKEUP_SOURCE_CHARGE  充电换醒
 * -# WAKEUP_SOURCE_PCS     PCS换醒
 * -# WAKEUP_SOURCE_ID_IN   拼机换醒
 * @retval 0 成功
 * @retval <0 失败
 */
int32_t sdk_pm_wakeup_source_enable(uint32_t wakeup_source);

/**
 * @brief  获取换醒源
 * @retval WAKEUP_SOURCE_KEY1    按键开机换醒
 * @retval WAKEUP_SOURCE_CHARGE  充电换醒
 * @retval WAKEUP_SOURCE_PCS PCS PCS换醒
 * @retval WAKEUP_SOURCE_ID_IN   拼机换醒
 * @pre 先使能sdk_pm_enable()才有效
 */
uint32_t sdk_pm_get_wakeup_source(void);

void low_power_thread(void);

#endif
#endif
