
#ifndef __SDK_MOS_H__
#define __SDK_MOS_H__

#include <stdint.h>



/**
  * @enum    mos_type_e
  * @brief   mos类型
  * @warning 后续添加新的MOS的时候，需从后面顺序添加 
  */
typedef enum
{
	SDK_CHARGE_MOS				= 0x01,	///< 充电mos定义
	SDK_PRE_CHARGE_MOS			= 0x02,	///< 预充mos定义
	SDK_DIS_CHARGE_MOS			= 0x03,	///< 放电mos定义
	SDK_DIS_CHARGE_CHECK_MOS	= 0x04,	///< 放电检测mos定义
	SDK_MOS_MAX,
}mos_type_e;


/**
  * @enum   mos_state_e
  * @brief  mos状态
***/
typedef enum
{
    MOS_OFF   = 0, 					///< 断开
    MOS_ON,  						///< 闭合
}mos_state_e;



#ifndef SDK_API_INTERFACE_ENABLE	///< SDK接口对外声明是否打开

/**
* @brief		sdk_mos初始化
* @warning		系统初次使用时需先初始化一次
*/
void sdk_mos_init(void);


/**
* @brief		mos控制
* @param		[in] mos mos类型
* -# SDK_CHARGE_MOS				0x01- 充电mos
* -# SDK_PRE_CHARGE_MOS			0x02- 预充mos
* -# SDK_DIS_CHARGE_MOS			0x03- 放电mos
* -# SDK_DIS_CHARGE_CHECK_MOS	0x04- 放电检测mos
* @param		[in] state 控制状态 
* -# MOS_OFF(0)- 断开 
* -# MOS_ON(1) - 闭合
* @return		执行结果
* @retval		0 成功
* @retval		<0 失败 
* @pre			前置条件
* @warning		警告注意说明
*/
int32_t sdk_mos_write(uint32_t mos, uint32_t state);



/**
* @brief		mos状态获取
* @param		[in] mos mos类型
* -# SDK_CHARGE_MOS				0x01- 充电mos
* -# SDK_PRE_CHARGE_MOS			0x02- 预充mos
* -# SDK_DIS_CHARGE_MOS			0x03- 放电mos
* -# SDK_DIS_CHARGE_CHECK_MOS	0x04- 放电检测mos
* @return		执行结果
* @retval		0-断开  
* @retval		1-闭合
* @retval		<0 表示获取失败
*/
int32_t sdk_mos_read(uint32_t mos);



#endif
#endif

