#ifndef __SDK_BUZZER_H__
#define __SDK_BUZZER_H__

#include <stdint.h>

/**
  * @brief 	蜂鸣器标号及数量
  */
typedef enum{
	BUZZER_POWER = 0,
	BUZZER_NUM,			///< 蜂鸣器数量
}buzzer_name_e;

/**
  * @brief 	蜂鸣器状态
  */
typedef enum
{
	BUZZER_OFF = 0,	///< 蜂鸣器灭
	BUZZER_ON,		///< 蜂鸣器响
}buzzer_state_e;

/**
  * @brief 蜂鸣器信息结构体
  */
typedef struct{
	uint32_t start_time;			///< 蜂鸣器状态开始时间
	uint32_t period;			///< 蜂鸣器闪烁周期
	uint32_t duty;				///< 蜂鸣器闪烁占空比
	int32_t times;				///< 蜂鸣器响灭次数
	buzzer_state_e status;		///< 蜂鸣器状态
}buzzer_info_t;

#ifndef SDK_API_INTERFACE_ENABLE	///< SDK接口对外声明是否打开

/**
* @brief	蜂鸣器引脚初始化，默认所有蜂鸣器灭
* @param	无
* @return	执行结果
* @retval	0  初始化成功
* @retval	-1 初始化失败
* @warning	无警告
* @date		2023/01/12
*/
int32_t sdk_buzzer_init(void);

/**
 * @brief	蜂鸣器滴答
 * @param	[in] id	蜂鸣器编号
 * @param	[in] period		蜂鸣器鸣响周期
 * -# 最小周期为任务周期或扫描周期（建议10ms）,需是任务及扫描周期的倍数
 * @param	[in] duty		蜂鸣器鸣响占空比
 * -# 0-100,表示0%-100%
 * @param	[in] times		蜂鸣器鸣响次数
 * -# -1表示持续鸣响
 * -# >=0表示实际鸣响次数
 * @return	执行结果
 * @retval	0  设置成功
 * @retval	-1 设置失败
 * @date		2023/01/12
 */
int32_t sdk_buzzer_tick(uint32_t id, uint32_t period, uint32_t duty, int32_t times);

/**
 * @brief	蜂鸣器响
 * @param	[in] id	蜂鸣器标号
 * @return	执行结果
 * @retval	0  设置成功
 * @retval	-1 设置失败
 * @warning	无警告
 */
int32_t sdk_buzzer_on(uint32_t id);

/**
 * @brief	蜂鸣器灭
 * @param	[in] id	蜂鸣器标号
 * @return	执行结果
 * @retval	0  设置成功
 * @retval	-1 设置失败
 * @warning	无警告
 * @date	2023/01/12
 */
int32_t sdk_buzzer_off(uint32_t id);

/**
* @brief	蜂鸣器轮询检测函数，更新蜂鸣器结构体数据	
* @param	无输入
* @return	执行结果
* @retval	无返回值
* @warning	无警告
*/
void sdk_buzzer_scan(void);

#endif
#endif
