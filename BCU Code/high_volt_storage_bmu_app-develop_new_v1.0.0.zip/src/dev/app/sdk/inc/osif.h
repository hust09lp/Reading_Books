
#ifndef __OS_IF_H__
#define __OS_IF_H__


/**
* 大版本号
*/
#define OSIF_D_VERSION		0		///< 当API的兼容性变化时，需递增。
/**
* 中版本号
*/
#define OSIF_M_VERSION		0		///< 当增加功能时(不影响API 的兼容性)，需递增。
/**
* 小版本号
*/
#define OSIF_S_VERSION		2		///< 当做Bug修复时(不影响API 的兼容性)，需递增。



#ifndef __NO_RETURN
#if	 defined(__CC_ARM)
#define __NO_RETURN __declspec(noreturn)
#elif defined(__ARMCC_VERSION) && (__ARMCC_VERSION >= 6010050)
#define __NO_RETURN __attribute__((__noreturn__))
#elif defined(__GNUC__)
#define __NO_RETURN __attribute__((__noreturn__))
#elif defined(__ICCARM__)
#define __NO_RETURN __noreturn
#else
#define __NO_RETURN
#endif
#endif

#include <stdint.h>
#include <stddef.h>

#ifdef	__cplusplus
extern "C"
{
#endif


//	==== Enumerations, structures, defines ====

/**
* @struct os_version_t
* @brief Version information.
*/
typedef struct {
	uint32_t					        api;	 ///< API version (major.minor.rev: mmnnnrrrr dec).
	uint32_t					        kernel;	 ///< Kernel version (major.minor.rev: mmnnnrrrr dec).
}os_version_t;


/**
* @enum os_kernel_state_e
* @brief Kernel state.
*/
typedef enum {
	OS_KERNEL_INACTIVE				    =	0,				 ///< Inactive.
	OS_KERNEL_READY					    =	1,				 ///< Ready.
	OS_KERNEL_RUNNING			        =	2,				 ///< Running.
	OS_KERNEL_LOCKED				    =	3,				 ///< Locked.
	OS_KERNEL_SUSPENDED			        =	4,				 ///< Suspended.
	OS_KERNEL_ERROR				        =   -1,				 ///< Error.
	OS_KERNEL_RESERVED				    =   0x7FFFFFFFU ///< Prevents enum down-size compiler optimization.
}os_kernel_state_e;


/**
* @enum os_thread_state_e
* @brief Thread state.
*/
typedef enum {
	OS_THREAD_INACTIVE				    =	0,				 ///< Inactive.
	OS_THREAD_READY					    =	1,				 ///< Ready.
	OS_THREAD_RUNNING				    =	2,				 ///< Running.
	OS_THREAD_BLOCKED				    =	3,				 ///< Blocked.
	OS_THREAD_TERMINATED			    =	4,				 ///< Terminated.
	OS_THREAD_ERROR					    =   -1,				 ///< Error.
	OS_THREAD_RESERVED				    = 0x7FFFFFFF	///< Prevents enum down-size compiler optimization.
} os_thread_state_e;


/**
* @enum os_priority_e
* @brief Priority values.
*/
typedef enum {
	OS_PRIORITY_NONE					= 64,				 ///< No priority (not initialized).
	OS_PRIORITY_IDLE					= 63,				 ///< Reserved for Idle thread.
	OS_PRIORITY_LOW 					= 62,				 ///< Priority: low
	OS_PRIORITY_LOW_1					= 60-1,				///< Priority: low + 1
	OS_PRIORITY_LOW_2					= 60-2,			 	///< Priority: low + 2
	OS_PRIORITY_LOW_3					= 60-3,			 	///< Priority: low + 3
	OS_PRIORITY_LOW_4					= 60-4,			 	///< Priority: low + 4
	OS_PRIORITY_LOW_5					= 60-5,			 	///< Priority: low + 5
	OS_PRIORITY_LOW_6					= 60-6,			 	///< Priority: low + 6
	OS_PRIORITY_LOW_7					= 60-7,			 	///< Priority: low + 7
	OS_PRIORITY_BELOW_NORMAL        	= 50,				///< Priority: below normal
	OS_PRIORITY_BELOW_NORMAL_1	        = 50-1,			 	///< Priority: below normal + 1
	OS_PRIORITY_BELOW_NORMAL_2	        = 50-2,			 	///< Priority: below normal + 2
	OS_PRIORITY_BELOW_NORMAL_3	        = 50-3,			 	///< Priority: below normal + 3
	OS_PRIORITY_BELOW_NORMAL_4	        = 50-4,			 	///< Priority: below normal + 4
	OS_PRIORITY_BELOW_NORMAL_5	        = 50-5,			 	///< Priority: below normal + 5
	OS_PRIORITY_BELOW_NORMAL_6	        = 50-6,			 	///< Priority: below normal + 6
	OS_PRIORITY_BELOW_NORMAL_7	        = 50-7,			 	///< Priority: below normal + 7
	OS_PRIORITY_NORMAL  				= 40,			 	///< Priority: normal
	OS_PRIORITY_NORMAL_1			    = 40-1,			 	///< Priority: normal + 1
	OS_PRIORITY_NORMAL_2			    = 40-2,			 	///< Priority: normal + 2
	OS_PRIORITY_NORMAL_3			    = 40-3,			 	///< Priority: normal + 3
	OS_PRIORITY_NORMAL_4			    = 40-4,			 	///< Priority: normal + 4
	OS_PRIORITY_NORMAL_5			    = 40-5,			 	///< Priority: normal + 5
	OS_PRIORITY_NORMAL_6			    = 40-6,			 	///< Priority: normal + 6
	OS_PRIORITY_NORMAL_7			    = 40-7,			 	///< Priority: normal + 7
	OS_PRIORITY_ABOVE_NORMAL            = 30,			 	///< Priority: above normal
	OS_PRIORITY_ABOVE_NORMAL_1	        = 30-1,			 	///< Priority: above normal + 1
	OS_PRIORITY_ABOVE_NORMAL_2	        = 30-2,			 	///< Priority: above normal + 2
	OS_PRIORITY_ABOVE_NORMAL_3	        = 30-3,			 	///< Priority: above normal + 3
	OS_PRIORITY_ABOVE_NORMAL_4	        = 30-4,			 	///< Priority: above normal + 4
	OS_PRIORITY_ABOVE_NORMAL_5	        = 30-5,			 	///< Priority: above normal + 5
	OS_PRIORITY_ABOVE_NORMAL_6	        = 30-6,			 	///< Priority: above normal + 6
	OS_PRIORITY_ABOVE_NORMAL_7	        = 30-7,			 	///< Priority: above normal + 7
	OS_PRIORITY_HIGH				    = 20,			 	///< Priority: high
	OS_PRIORITY_HIGH_1				    = 20-1,			 	///< Priority: high + 1
	OS_PRIORITY_HIGH_2				    = 20-2,			 	///< Priority: high + 2
	OS_PRIORITY_HIGH_3				    = 20-3,			 	///< Priority: high + 3
	OS_PRIORITY_HIGH_4				    = 20-4,			 	///< Priority: high + 4
	OS_PRIORITY_HIGH_5				    = 20-5,			 	///< Priority: high + 5
	OS_PRIORITY_HIGH_6				    = 20-6,			 	///< Priority: high + 6
	OS_PRIORITY_HIGH_7				    = 20-7,			 	///< Priority: high + 7
	OS_PRIORITY_REALTIME			    = 10,			 	///< Priority: realtime
	OS_PRIORITY_REALTIME_1		        = 10-1,			 	///< Priority: realtime + 1
	OS_PRIORITY_REALTIME_2		        = 10-2,			 	///< Priority: realtime + 2
	OS_PRIORITY_REALTIME_3		        = 10-3,			 	///< Priority: realtime + 3
	OS_PRIORITY_REALTIME_4		        = 10-4,			 	///< Priority: realtime + 4
	OS_PRIORITY_REALTIME_5		        = 10-5,			 	///< Priority: realtime + 5
	OS_PRIORITY_REALTIME_6		        = 10-6,			 	///< Priority: realtime + 6
	OS_PRIORITY_REALTIME_7		        = 10-7,			 	///< Priority: realtime + 7
	OS_PRIORITY_ISR					    = 2,			 	///< Reserved for ISR deferred thread.
	OS_PRIORITY_ERROR				    = -1,			 	///< System cannot determine priority or illegal priority.
	OS_PRIORITY_RESERVED			    = 0x7FFFFFFF	 	///< Prevents enum down-size compiler optimization.
} os_priority_e;



/** Entry point of a thread. */
typedef void (*os_thread_func_t) (void *argument);


/** Timer callback function. */
typedef void (*os_timer_func_t) (void *argument);

/**
* @enum os_timer_type_e
* @brief Timer type.
*/
typedef enum {
	OS_TIMER_ONCE						= 0,			    ///< One-shot timer.
	OS_TIMER_PERIODIC					= 1					///< Repeating timer.
} os_timer_type_e;

// Timeout value.
#define OS_WAIT_FOREVER				    0xFFFFFFFFU ///< Wait forever timeout value.

// Flags options (@ref os_thread_flags_wait and @ref os_event_flags_wait).
#define OS_FLAGS_WAIT_ANY				0x00000000U ///< Wait for any flag (default).
#define OS_FLAGS_WAIT_ALL				0x00000001U ///< Wait for all flags.
#define OS_FLAGS_NO_CLEAR				0x00000002U ///< Do not clear flags which have been specified to wait for.

// Flags errors (returned by OS_THREAD_FLAGS_XXXX and OS_EVENT_FLAGS_XXXX).
#define OS_FLAGS_ERROR					0x80000000U ///< Error indicator.
#define OS_FLAGS_ERROR_UNKNOWN	        0xFFFFFFFFU ///< OS_ERROR (-1).
#define OS_FLAGS_ERROR_TIMEOUT	        0xFFFFFFFEU ///< OS_ERROR_TIMEOUT (-2).
#define OS_FLAGS_ERROR_RESOURCE	        0xFFFFFFFDU ///< OS_ERROR_RESOURCE (-3).
#define OS_FLAGS_ERROR_PARAMETER        0xFFFFFFFCU ///< OS_ERROR_PARAMETER (-4).
#define OS_FLAGS_ERROR_ISR			    0xFFFFFFFAU ///< OS_ERROR_ISR (-6).

// Thread attributes (attr_bits in @ref os_thread_attr_t).
#define OS_THREAD_DETACHED			    0x00000000U ///< Thread created in detached mode (default)
#define OS_THREAD_JOINABLE			    0x00000001U ///< Thread created in joinable mode

// Mutex attributes (attr_bits in @ref os_mutex_attr_t).
#define OS_MUTEX_RECURSIVE			    0x00000001U ///< Recursive mutex.
#define OS_MUTEX_PRIO_INHERIT		    0x00000002U ///< Priority inherit protocol.
#define OS_MUTEX_ROBUST				    0x00000008U ///< Robust mutex.


/**
* @enum os_status_e
* @brief Status code values returned by RTOS functions.
*/
typedef enum {
	OS_OK								=  0,				 ///< Operation completed successfully.
	OS_ERROR							= -1,				 ///< Unspecified RTOS error: run-time error but no other error message fits.
	OS_ERROR_TIMEOUT					= -2,				 ///< Operation not completed within the timeout period.
	OS_ERROR_RESOURCE					= -3,				 ///< Resource not available.
	OS_ERROR_PARAMETER					= -4,				 ///< Parameter error.
	OS_ERROR_NO_MEMORY					= -5,				 ///< System is out of memory: it was impossible to allocate or reserve memory for the operation.
	OS_ERROR_ISR						= -6,				 ///< Not allowed in ISR context: the function cannot be called from interrupt service routines.
	OS_STATUS_RESERVED					= 0x7FFFFFFF	///< Prevents enum down-size compiler optimization.
} os_status_e;


/// \details Thread ID identifies the thread.
typedef void *os_thread_id_t;

/// \details Timer ID identifies the timer.
typedef void *os_timer_id_t;

/// \details Event Flags ID identifies the event flags.
typedef void *os_event_flags_id_t;

/// \details Mutex ID identifies the mutex.
typedef void *os_mutex_id_t;

/// \details Semaphore ID identifies the semaphore.
typedef void *os_sem_id_t;

/// \details mail box ID identifies the mail box.
typedef void *os_mail_box_id_t;

/// \details Memory Pool ID identifies the memory pool.
typedef void *os_memory_pool_id_t;

/// \details Message Queue ID identifies the message queue.
typedef void *os_message_queue_id_t;


#ifdef __TZ_MODULEID_T__
/// \details Data type that identifies secure software modules called by a process.
typedef uint32_t TZ_module_id_t;
#endif


/**
* @struct os_thread_attr_t
* @brief Attributes structure for thread.
*/
typedef struct {
	const char							*name;	        ///< name of the thread
	uint32_t							attr_bits;	    ///< attribute bits
	void								*cb_mem;		///< memory for control block
	uint32_t							cb_size;	    ///< size of provided memory for control block
	uint32_t							tick;
	void								*stack_mem;		///< memory for stack
	uint32_t							stack_size;	    ///< size of stack
	os_priority_e						priority;	    ///< initial thread priority (default: OS_PRIORITY_NORMAL)
#ifdef __TZ_MODULEID_T__
	TZ_module_id_t						tz_module;	    ///< TrustZone module identifier
#endif
	uint32_t							reserved;	    ///< reserved (must be 0)
} os_thread_attr_t;


/**
* @struct os_timer_attr_t
* @brief Attributes structure for timer.
*/
typedef struct {
	const char							*name;	        ///< name of the timer
	uint32_t							attr_bits;	    ///< attribute bits
	void								*cb_mem;	    ///< memory for control block
	uint32_t							cb_size;	    ///< size of provided memory for control block
} os_timer_attr_t;

/**
* @struct os_event_flags_attr_t
* @brief Attributes structure for event flags.
*/
typedef struct {
	const char							*name;	        ///< name of the event flags
	uint32_t							 attr_bits;	    ///< attribute bits
	void								*cb_mem;		///< memory for control block
	uint32_t							cb_size;	    ///< size of provided memory for control block
} os_event_flags_attr_t;


/**
* @struct os_mutex_attr_t
* @brief Attributes structure for mutex
*/
typedef struct {
	const char							*name;	        ///< name of the mutex
	uint32_t							attr_bits;	    ///< attribute bits
	void								*cb_mem;		///< memory for control block
	uint32_t							cb_size;	    ///< size of provided memory for control block
} os_mutex_attr_t;

/**
* @struct os_sem_attr_t
* @brief Attributes structure for semaphore.
*/
typedef struct {
	const char							*name;	        ///< name of the semaphore
	uint32_t							attr_bits;	    ///< attribute bits
	void								*cb_mem;		///< memory for control block
	uint32_t							cb_size;	    ///< size of provided memory for control block
} os_sem_attr_t;

/**
* @struct os_mail_box_attr_t
* @brief Attributes structure for mail box.
*/
typedef struct {
	const char							*name;	        ///< name of the mail box
	uint32_t							attr_bits;	    ///< attribute bits
	void								*cb_mem;		///< memory for control block
	uint32_t							cb_size;	    ///< size of provided memory for control block
	void								*mq_mem;		///< memory for data storage
	uint32_t							mq_size;	    ///< size of provided memory for data storage
} os_mail_box_attr_t;

/**
* @struct os_memory_pool_attr_t
* @brief Attributes structure for memory pool.
*/
typedef struct {
	const char							*name;	        ///< name of the memory pool
	uint32_t							attr_bits;	    ///< attribute bits
	void								*cb_mem;		///< memory for control block
	uint32_t							cb_size;	    ///< size of provided memory for control block
	void								*mp_mem;		///< memory for data storage
	uint32_t							mp_size;	    ///< size of provided memory for data storage
} os_memory_pool_attr_t;


/**
* @struct os_message_queue_attr_t
* @brief Attributes structure for message queue.
*/
typedef struct {
	const char							*name;	        ///< name of the message queue
	uint32_t							attr_bits;	    ///< attribute bits
	void								*cb_mem;		///< memory for control block
	uint32_t							cb_size;	    ///< size of provided memory for control block
	void								*mq_mem;		///< memory for data storage
	uint32_t							mq_size;	    ///< size of provided memory for data storage
} os_message_queue_attr_t;



#ifndef SDK_API_INTERFACE_ENABLE	///< SDK接口对外声明是否打开

//	==== Kernel Management Functions ====

/// Initialize the RTOS Kernel.
/// \return status code that indicates the execution status of the function.
os_status_e os_kernel_init (void);

///	Get RTOS Kernel Information.
/// \param[out]		version			 pointer to buffer for retrieving version information.
/// \param[out]		id_buf				pointer to buffer for retrieving kernel identification string.
/// \param[in]		 id_size			 size of buffer for kernel identification string.
/// \return status code that indicates the execution status of the function.
os_status_e os_kernel_get_info (os_version_t *version, char *id_buf, uint32_t id_size);

/// Get the current RTOS Kernel state.
/// \return current RTOS Kernel state.
os_kernel_state_e os_kernel_get_state (void);

/// Start the RTOS Kernel scheduler.
/// \return status code that indicates the execution status of the function.
os_status_e os_kernel_start (void);

/// Lock the RTOS Kernel scheduler.
/// \return previous lock state (1 - locked, 0 - not locked, error code if negative).
int32_t os_kernel_lock (void);

/// Unlock the RTOS Kernel scheduler.
/// \return previous lock state (1 - locked, 0 - not locked, error code if negative).
int32_t os_kernel_unlock (void);

/// Restore the RTOS Kernel scheduler lock state.
/// \param[in]		 lock					lock state obtained by @ref os_kernel_lock or @ref os_kernel_unlock.
/// \return new lock state (1 - locked, 0 - not locked, error code if negative).
int32_t os_kernel_restore_lock (int32_t lock);

/// Suspend the RTOS Kernel scheduler.
/// \return time in ticks, for how long the system can sleep or power-down.
uint32_t os_kernel_suspend (void);

/// Resume the RTOS Kernel scheduler.
/// \param[in]		 sleep_ticks	 time in ticks for how long the system was in sleep or power-down mode.
void os_kernel_resume (uint32_t sleep_ticks);

/// Get the RTOS kernel tick count.
/// \return RTOS kernel current tick count.
uint32_t os_kernel_get_tick_count (void);

/// Get the RTOS kernel tick frequency.
/// \return frequency of the kernel tick in hertz, i.e. kernel ticks per second.
uint32_t os_kernel_get_tick_freq (void);

/// Get the RTOS kernel system timer count.
/// \return RTOS kernel current system timer count as 32-bit value.
uint32_t os_kernel_get_systimer_count (void);

/// Get the RTOS kernel system timer frequency.
/// \return frequency of the system timer in hertz, i.e. timer ticks per second.
uint32_t os_kernel_get_systimer_freq (void);


//	==== Thread Management Functions ====

/// Create a thread and add it to Active Threads.
/// \param[in]		 func					thread function.
/// \param[in]		 argument			pointer that is passed to the thread function as start argument.
/// \param[in]		 attr					thread attributes; NULL: default values.
/// \return thread ID for reference by other functions or NULL in case of error.
os_thread_id_t os_thread_new (os_thread_func_t func, void *argument, const os_thread_attr_t *attr);

/**
* @brief		app创建系统线程接口
* @param		[in] func线程任务函数
* @param		[in] argument 参数
* @param		[in] *attr 线程创建属性结构指针
* @return		执行结果
* @retval		NULL=(void*)0  创建失败 
* @retval		!NULL 线程ID指针 
* @warning		仅供app层创建任务使用，CORE层和SDK禁止调用
*/
os_thread_id_t os_app_thread_new(os_thread_func_t func, void *argument, os_thread_attr_t *attr);


/// Get name of a thread.
/// \param[in]		 thread_id		 thread ID obtained by @ref os_thread_new or @ref os_thread_get_id.
/// \return name as NULL terminated string.
const char *os_thread_get_name (os_thread_id_t thread_id);

/// Return the thread ID of the current running thread.
/// \return thread ID for reference by other functions or NULL in case of error.
os_thread_id_t os_thread_get_id (void);

/// Get current thread state of a thread.
/// \param[in]		 thread_id		 thread ID obtained by @ref os_thread_new or @ref os_thread_get_id.
/// \return current thread state of the specified thread.
os_thread_state_e os_thread_get_state (os_thread_id_t thread_id);

/// Get stack size of a thread.
/// \param[in]		 thread_id		 thread ID obtained by @ref os_thread_new or @ref os_thread_get_id.
/// \return stack size in bytes.
uint32_t os_thread_get_stack_size (os_thread_id_t thread_id);

/// Get available stack space of a thread based on stack watermark recording during execution.
/// \param[in]		 thread_id		 thread ID obtained by @ref os_thread_new or @ref os_thread_get_id.
/// \return remaining stack space in bytes.
uint32_t os_thread_get_stack_space (os_thread_id_t thread_id);

/// Change priority of a thread.
/// \param[in]		 thread_id		 thread ID obtained by @ref os_thread_new or @ref os_thread_get_id.
/// \param[in]		 priority			new priority value for the thread function.
/// \return status code that indicates the execution status of the function.
os_status_e os_thread_set_priority (os_thread_id_t thread_id, os_priority_e priority);

/// Get current priority of a thread.
/// \param[in]		 thread_id		 thread ID obtained by @ref os_thread_new or @ref os_thread_get_id.
/// \return current priority value of the specified thread.
os_priority_e os_thread_get_priority (os_thread_id_t thread_id);

/// Pass control to next thread that is in state \b READY.
/// \return status code that indicates the execution status of the function.
os_status_e os_thread_yield (void);

/// Suspend execution of a thread.
/// \param[in]		 thread_id		 thread ID obtained by @ref os_thread_new or @ref os_thread_get_id.
/// \return status code that indicates the execution status of the function.
os_status_e os_thread_suspend (os_thread_id_t thread_id);

/// Resume execution of a thread.
/// \param[in]		 thread_id		 thread ID obtained by @ref os_thread_new or @ref os_thread_get_id.
/// \return status code that indicates the execution status of the function.
os_status_e os_thread_resume (os_thread_id_t thread_id);

#if 0
/// Detach a thread (thread storage can be reclaimed when thread terminates).
/// \param[in]		 thread_id		 thread ID obtained by @ref os_thread_new or @ref os_thread_get_id.
/// \return status code that indicates the execution status of the function.
os_status_e os_thread_detach (os_thread_id_t thread_id);

/// Wait for specified thread to terminate.
/// \param[in]		 thread_id		 thread ID obtained by @ref os_thread_new or @ref os_thread_get_id.
/// \return status code that indicates the execution status of the function.
os_status_e os_thread_join (os_thread_id_t thread_id);

/// Terminate execution of current running thread.
__NO_RETURN void os_thread_exit (void);
#endif
/// Terminate execution of a thread.
/// \param[in]		 thread_id		 thread ID obtained by @ref os_thread_new or @ref os_thread_get_id.
/// \return status code that indicates the execution status of the function.
os_status_e os_thread_terminate (os_thread_id_t thread_id);

#if 0
/// Get number of active threads.
/// \return number of active threads.
uint32_t os_thread_get_count (void);


/// Enumerate active threads.
/// \param[out]		thread_array	pointer to array for retrieving thread IDs.
/// \param[in]		 array_items	 maximum number of items in array for retrieving thread IDs.
/// \return number of enumerated threads.
uint32_t os_thread_enumerate (os_thread_id_t *thread_array, uint32_t array_items);


//	==== Thread Flags Functions ====

/// Set the specified Thread Flags of a thread.
/// \param[in]		 thread_id		 thread ID obtained by @ref os_thread_new or @ref os_thread_get_id.
/// \param[in]		 flags				 specifies the flags of the thread that shall be set.
/// \return thread flags after setting or error code if highest bit set.
uint32_t os_thread_flags_set (os_thread_id_t thread_id, uint32_t flags);

/// Clear the specified Thread Flags of current running thread.
/// \param[in]		 flags				 specifies the flags of the thread that shall be cleared.
/// \return thread flags before clearing or error code if highest bit set.
uint32_t os_thread_flags_clear (uint32_t flags);

/// Get the current Thread Flags of current running thread.
/// \return current thread flags.
uint32_t os_thread_flags_get (void);

/// Wait for one or more Thread Flags of the current running thread to become signaled.
/// \param[in]		 flags				 specifies the flags to wait for.
/// \param[in]		 options			 specifies flags options (osFlagsXxxx).
/// \param[in]		 timeout			 RTOS_timeout_value or 0 in case of no time-out.
/// \return thread flags before clearing or error code if highest bit set.
uint32_t os_thread_flags_wait (uint32_t flags, uint32_t options, uint32_t timeout);
#endif

//	==== Generic Wait Functions ====

/// Wait for Timeout (Time Delay).
/// \param[in]		 ticks				 RTOS_timeout_value "time ticks" value
/// \return status code that indicates the execution status of the function.
os_status_e os_delay (uint32_t ticks);


///  This function will let current thread delay until (*tick + inc_tick).
/// \param[out]		 tick				 the tick of last wakeup.
/// \param[in]		 inc_tick			 the increment tick
/// \return status code that indicates the execution status of the function.
os_status_e os_thread_delay_until (uint32_t *tick, uint32_t inc_tick) ;

/// millisecond to ticks
/// \param[in]		 ms				milli secs
/// \return ticks.
uint32_t os_tick_from_millisecond(uint32_t ms);


//	==== Timer Management Functions ====

/// Create and Initialize a timer.
/// \param[in]		 func					function pointer to callback function.
/// \param[in]		 type					@ref OS_TIMER_ONCE for one-shot or @ref OS_TIMER_PERIODIC for periodic behavior.
/// \param[in]		 argument				argument to the timer callback function.
/// \param[in]		 ticks				    RTOS_timeout_value "time ticks" value of the timer.
/// \param[in]		 attr					timer attributes; NULL: default values.
/// \return timer ID for reference by other functions or NULL in case of error.
os_timer_id_t os_timer_new (os_timer_func_t func, os_timer_type_e type, void *argument, uint32_t ticks, const os_timer_attr_t *attr);

/// Get name of a timer.
/// \param[in]		 timer_id			timer ID obtained by @ref os_timer_new.
/// \return name as NULL terminated string.
const char *os_timer_get_name (os_timer_id_t timer_id);

/// Start or restart a timer.
/// \param[in]		 timer_id			timer ID obtained by @ref os_timer_new.
/// \return status code that indicates the execution status of the function.
os_status_e os_timer_start (os_timer_id_t timer_id);

/// Stop a timer.
/// \param[in]		 timer_id			timer ID obtained by @ref os_timer_new.
/// \return status code that indicates the execution status of the function.
os_status_e os_timer_stop (os_timer_id_t timer_id);

#if 0
/// Check if a timer is running.
/// \param[in]		 timer_id			timer ID obtained by @ref os_timer_new.
/// \return 0 not running, 1 running.
uint32_t os_timer_is_running (os_timer_id_t timer_id);
#endif

/// Delete a timer.
/// \param[in]		 timer_id			timer ID obtained by @ref os_timer_new.
/// \return status code that indicates the execution status of the function.
os_status_e os_timer_delete (os_timer_id_t timer_id);


//	==== Event Flags Management Functions ====

/// Create and Initialize an Event Flags object.
/// \param[in]		 attr					event flags attributes; NULL: default values.
/// \return event flags ID for reference by other functions or NULL in case of error.
os_event_flags_id_t os_event_flags_new (const os_event_flags_attr_t *attr);

/// Get name of an Event Flags object.
/// \param[in]		 ef_id				 event flags ID obtained by @ref os_event_flags_new.
/// \return name as NULL terminated string.
const char *os_event_flags_get_name (os_event_flags_id_t ef_id);

/// Set the specified Event Flags.
/// \param[in]		 ef_id				 event flags ID obtained by @ref os_event_flags_new.
/// \param[in]		 flags				 specifies the flags that shall be set.
/// \return event flags after setting or error code if highest bit set.
uint32_t os_event_flags_set (os_event_flags_id_t ef_id, uint32_t flags);

/// Clear the specified Event Flags.
/// \param[in]		 ef_id				 event flags ID obtained by @ref os_event_flags_new.
/// \param[in]		 flags				 specifies the flags that shall be cleared.
/// \return event flags before clearing or error code if highest bit set.
uint32_t os_event_flags_clear (os_event_flags_id_t ef_id, uint32_t flags);

/// Get the current Event Flags.
/// \param[in]		 ef_id				 event flags ID obtained by @ref os_event_flags_new.
/// \return current event flags.
uint32_t os_event_flags_get (os_event_flags_id_t ef_id);

/// Wait for one or more Event Flags to become signaled.
/// \param[in]		 ef_id				 event flags ID obtained by @ref os_event_flags_new.
/// \param[in]		 flags				 specifies the flags to wait for.
/// \param[in]		 options			 specifies flags options (osFlagsXxxx).
/// \param[in]		 timeout			 RTOS_timeout_value or 0 in case of no time-out.
/// \return event flags before clearing or error code if highest bit set.
uint32_t os_event_flags_wait (os_event_flags_id_t ef_id, uint32_t flags, uint32_t options, uint32_t timeout);

/// Delete an Event Flags object.
/// \param[in]		 ef_id				 event flags ID obtained by @ref os_event_flags_new.
/// \return status code that indicates the execution status of the function.
os_status_e os_event_flags_delete (os_event_flags_id_t ef_id);


//	==== Mutex Management Functions ====

/// Create and Initialize a Mutex object.
/// \param[in]		 attr					mutex attributes; NULL: default values.
/// \return mutex ID for reference by other functions or NULL in case of error.
os_mutex_id_t os_mutex_new (const os_mutex_attr_t *attr);

/// Get name of a Mutex object.
/// \param[in]		 mutex_id			mutex ID obtained by @ref os_mutex_new.
/// \return name as NULL terminated string.
const char *os_mutex_get_name (os_mutex_id_t mutex_id);

/// Acquire a Mutex or timeout if it is locked.
/// \param[in]		 mutex_id			mutex ID obtained by @ref os_mutex_new.
/// \param[in]		 timeout			 RTOS_timeout_value or 0 in case of no time-out.
/// \return status code that indicates the execution status of the function.
os_status_e os_mutex_acquire (os_mutex_id_t mutex_id, uint32_t timeout);

/// Release a Mutex that was acquired by @ref os_mutex_acquire.
/// \param[in]		 mutex_id			mutex ID obtained by @ref os_mutex_new.
/// \return status code that indicates the execution status of the function.
os_status_e os_mutex_release (os_mutex_id_t mutex_id);

/// Get Thread which owns a Mutex object.
/// \param[in]		 mutex_id			mutex ID obtained by @ref os_mutex_new.
/// \return thread ID of owner thread or NULL when mutex was not acquired.
os_thread_id_t os_mutex_get_owner (os_mutex_id_t mutex_id);

/// Delete a Mutex object.
/// \param[in]		 mutex_id			mutex ID obtained by @ref os_mutex_new.
/// \return status code that indicates the execution status of the function.
os_status_e os_mutex_delete (os_mutex_id_t mutex_id);


//	==== Semaphore Management Functions ====

/// Create and Initialize a Semaphore object.
/// \param[in]		 max_count		 maximum number of available tokens.
/// \param[in]		 initial_count initial number of available tokens.
/// \param[in]		 attr					semaphore attributes; NULL: default values.
/// \return semaphore ID for reference by other functions or NULL in case of error.
os_sem_id_t os_sem_new (uint32_t max_count, uint32_t initial_count, const os_sem_attr_t *attr);

/// Get name of a Semaphore object.
/// \param[in]		 semaphore_id	semaphore ID obtained by @ref os_sem_new.
/// \return name as NULL terminated string.
const char *os_sem_get_name (os_sem_id_t semaphore_id);

/// Acquire a Semaphore token or timeout if no tokens are available.
/// \param[in]		 semaphore_id	semaphore ID obtained by @ref os_sem_new.
/// \param[in]		 timeout			 RTOS_timeout_value or 0 in case of no time-out.
/// \return status code that indicates the execution status of the function.
os_status_e os_sem_acquire (os_sem_id_t semaphore_id, uint32_t timeout);

/// Release a Semaphore token up to the initial maximum count.
/// \param[in]		 semaphore_id	semaphore ID obtained by @ref os_sem_new.
/// \return status code that indicates the execution status of the function.
os_status_e os_sem_release (os_sem_id_t semaphore_id);

/// Get current Semaphore token count.
/// \param[in]		 semaphore_id	semaphore ID obtained by @ref os_sem_new.
/// \return number of tokens available.
uint32_t os_sem_get_count (os_sem_id_t semaphore_id);

/// Delete a Semaphore object.
/// \param[in]		 semaphore_id	semaphore ID obtained by @ref os_sem_new.
/// \return status code that indicates the execution status of the function.
os_status_e os_sem_delete (os_sem_id_t semaphore_id);


//	==== Memory Pool Management Functions ====

/// Create and Initialize a Memory Pool object.
/// \param[in]		 block_count	 maximum number of memory blocks in memory pool.
/// \param[in]		 block_size		memory block size in bytes.
/// \param[in]		 attr					memory pool attributes; NULL: default values.
/// \return memory pool ID for reference by other functions or NULL in case of error.
os_memory_pool_id_t os_memory_pool_new (uint32_t block_count, uint32_t block_size, const os_memory_pool_attr_t *attr);

/// Get name of a Memory Pool object.
/// \param[in]		 mp_id				 memory pool ID obtained by @ref os_memory_pool_new.
/// \return name as NULL terminated string.
const char *os_memory_pool_get_name (os_memory_pool_id_t mp_id);

/// Allocate a memory block from a Memory Pool.
/// \param[in]		 mp_id				 memory pool ID obtained by @ref os_memory_pool_new.
/// \param[in]		 timeout			 RTOS_timeout_value or 0 in case of no time-out.
/// \return address of the allocated memory block or NULL in case of no memory is available.
void *os_memory_pool_alloc (os_memory_pool_id_t mp_id, uint32_t timeout);

/// Return an allocated memory block back to a Memory Pool.
/// \param[in]		 mp_id				 memory pool ID obtained by @ref os_memory_pool_new.
/// \param[in]		 block				 address of the allocated memory block to be returned to the memory pool.
/// \return status code that indicates the execution status of the function.
os_status_e os_memory_pool_free (os_memory_pool_id_t mp_id, void *block);

/// Get maximum number of memory blocks in a Memory Pool.
/// \param[in]		 mp_id				 memory pool ID obtained by @ref os_memory_pool_new.
/// \return maximum number of memory blocks.
uint32_t os_memory_pool_get_capacity (os_memory_pool_id_t mp_id);

/// Get memory block size in a Memory Pool.
/// \param[in]		 mp_id				 memory pool ID obtained by @ref os_memory_pool_new.
/// \return memory block size in bytes.
uint32_t os_memory_pool_get_block_size (os_memory_pool_id_t mp_id);

/// Get number of memory blocks used in a Memory Pool.
/// \param[in]		 mp_id				 memory pool ID obtained by @ref os_memory_pool_new.
/// \return number of memory blocks used.
uint32_t os_memory_pool_get_count (os_memory_pool_id_t mp_id);

/// Get number of memory blocks available in a Memory Pool.
/// \param[in]		 mp_id				 memory pool ID obtained by @ref os_memory_pool_new.
/// \return number of memory blocks available.
uint32_t os_memory_pool_get_space (os_memory_pool_id_t mp_id);

/// Delete a Memory Pool object.
/// \param[in]		 mp_id				 memory pool ID obtained by @ref os_memory_pool_new.
/// \return status code that indicates the execution status of the function.
os_status_e os_memory_pool_delete (os_memory_pool_id_t mp_id);



//	==== Mail Box Management Functions ====

/// Create and Initialize a Mail Box object.
/// \param[in]		 size		 		maximum number of mail box.
/// \param[in]		 attr				mail box attributes; NULL: default values.
/// \return message queue ID for reference by other functions or NULL in case of error.
os_mail_box_id_t os_mail_box_new (uint32_t size, const os_mail_box_attr_t *attr);

/// Put a Mail Box or timeout if mail box is full.
/// \param[in]		 mb_id				 message queue ID obtained by @ref os_mail_box_new.
/// \param[in]		 value			 	 send value.
/// \param[in]		 msg_prio			 message priority.
/// \param[in]		 timeout			 RTOS_timeout_value or 0 in case of no time-out.
/// \return status code that indicates the execution status of the function.
os_status_e os_mail_box_put (os_mail_box_id_t mb_id, uint32_t value, uint8_t msg_prio, uint32_t timeout);

/// Get a value from a mail box or timeout if Queue is empty.
/// \param[in]		 mq_id				message queue ID obtained by @ref os_mail_box_new.
/// \param[out]		 value				pointer to buffer for message to get from mail box.
/// \param[out]		 msg_prio			pointer to buffer for message priority or NULL.
/// \param[in]		 timeout			RTOS_timeout_value or 0 in case of no time-out.
/// \return status code that indicates the execution status of the function.
os_status_e os_mail_box_get (os_mail_box_id_t mb_id, uint32_t *value, uint8_t *msg_prio, uint32_t timeout);

/// Get maximum number of messages in mail box.
/// \param[in]		 mb_id				 mail box ID obtained by @ref os_mail_box_new.
/// \return maximum number of messages.
uint32_t os_mail_box_get_capacity (os_mail_box_id_t mb_id);

/// Get number of messages in mail box.
/// \param[in]		 mb_id				 mail box ID obtained by @ref os_mail_box_new.
/// \return number of queued messages.
uint32_t os_mail_box_get_count (os_mail_box_id_t mb_id);

/// Get number of available slots for messages in mail box.
/// \param[in]		 mb_id				 mail box ID obtained by @ref os_mail_box_new.
/// \return number of available slots for messages.
uint32_t os_mail_box_get_space (os_mail_box_id_t mb_id);

/// Reset a mail box to initial empty state.
/// \param[in]		 mb_id				 mail box ID obtained by @ref os_mail_box_new.
/// \return status code that indicates the execution status of the function.
os_status_e os_mail_box_reset (os_mail_box_id_t mb_id);

/// Delete a mail box object.
/// \param[in]		 mb_id				 mail box ID obtained by @ref os_mail_box_new.
/// \return status code that indicates the execution status of the function.
os_status_e os_mail_box_delete (os_mail_box_id_t mb_id);

//	==== Message Queue Management Functions ====

/// Create and Initialize a Message Queue object.
/// \param[in]		 msg_count		 maximum number of messages in queue.
/// \param[in]		 msg_size			maximum message size in bytes.
/// \param[in]		 attr					message queue attributes; NULL: default values.
/// \return message queue ID for reference by other functions or NULL in case of error.
os_message_queue_id_t os_message_queue_new (uint32_t msg_count, uint32_t msg_size, const os_message_queue_attr_t *attr);

/// Get name of a Message Queue object.
/// \param[in]		 mq_id				 message queue ID obtained by @ref os_message_queue_new.
/// \return name as NULL terminated string.
const char *os_message_queue_get_name (os_message_queue_id_t mq_id);

/// Put a Message into a Queue or timeout if Queue is full.
/// \param[in]		 mq_id				 message queue ID obtained by @ref os_message_queue_new.
/// \param[in]		 msg_ptr			 pointer to buffer with message to put into a queue.
/// \param[in]		 msg_size			 buffer size of message to put into a queue.
/// \param[in]		 msg_prio			 message priority.
/// \param[in]		 timeout			 RTOS_timeout_value or 0 in case of no time-out.
/// \return status code that indicates the execution status of the function.
os_status_e os_message_queue_put (os_message_queue_id_t mq_id, const void *msg_ptr, uint32_t msg_size, uint8_t msg_prio, uint32_t timeout);

/// Get a Message from a Queue or timeout if Queue is empty.
/// \param[in]		 mq_id				message queue ID obtained by @ref os_message_queue_new.
/// \param[out]		 msg_ptr			pointer to buffer for message to get from a queue.
/// \param[in]		 msg_buf_size		max buffer size of message to get into a queue.
/// \param[out]		 msg_prio			pointer to buffer for message priority or NULL.
/// \param[in]		 timeout			RTOS_timeout_value or 0 in case of no time-out.
/// \return status code that indicates the execution status of the function.
os_status_e os_message_queue_get (os_message_queue_id_t mq_id, void *msg_ptr, uint32_t msg_buf_size,  uint8_t *msg_prio, uint32_t timeout);

/// Get maximum number of messages in a Message Queue.
/// \param[in]		 mq_id				 message queue ID obtained by @ref os_message_queue_new.
/// \return maximum number of messages.
uint32_t os_message_queue_get_capacity (os_message_queue_id_t mq_id);

/// Get maximum message size in a Memory Pool.
/// \param[in]		 mq_id				 message queue ID obtained by @ref os_message_queue_new.
/// \return maximum message size in bytes.
uint32_t os_message_queue_get_msg_size (os_message_queue_id_t mq_id);

/// Get number of queued messages in a Message Queue.
/// \param[in]		 mq_id				 message queue ID obtained by @ref os_message_queue_new.
/// \return number of queued messages.
uint32_t os_message_queue_get_count (os_message_queue_id_t mq_id);

/// Get number of available slots for messages in a Message Queue.
/// \param[in]		 mq_id				 message queue ID obtained by @ref os_message_queue_new.
/// \return number of available slots for messages.
uint32_t os_message_queue_get_space (os_message_queue_id_t mq_id);

/// Reset a Message Queue to initial empty state.
/// \param[in]		 mq_id				 message queue ID obtained by @ref os_message_queue_new.
/// \return status code that indicates the execution status of the function.
os_status_e os_message_queue_reset (os_message_queue_id_t mq_id);

/// Delete a Message Queue object.
/// \param[in]		 mq_id				 message queue ID obtained by @ref os_message_queue_new.
/// \return status code that indicates the execution status of the function.
os_status_e os_message_queue_delete (os_message_queue_id_t mq_id);




#ifdef	__cplusplus
}
#endif

#endif
#endif
