#ifndef __AFE_MANAGEMENT_H__
#define __AFE_MANAGEMENT_H__

#include <stdint.h>



#ifndef SDK_API_INTERFACE_ENABLE	///< SDK接口对外声明是否打开

/**
* @brief		设置均衡
* @param		[in]均衡状态,每1bit代表单节电芯的启用与否，1->启用，0->禁用（顺序按小端模式）
* @return		无
* @retval		无
* @warning		无 
*/
void sdk_balance_set(uint32_t enable_flag);


/**
* @brief		获取均衡状态
* @param		[out]外部afe均衡状态指针  
* @return		无
* @retval		无
* @warning		无 
*/
void sdk_balance_state_get(uint32_t *state);





#endif
#endif
