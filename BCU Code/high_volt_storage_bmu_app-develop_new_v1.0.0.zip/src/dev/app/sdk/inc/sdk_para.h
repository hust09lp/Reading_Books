#ifndef __SDK_PARA_H__
#define __SDK_PARA_H__

#include <stdint.h>

enum
{
    BMS_RUNING_DATA = 0, ///< BMS运行数据。    存储空间小于3.5K
    IAP_PARA,            ///< IAP数据.        存储空间小于1.5K
    // (特别注意, 这个区在芯片内部，读写时offset与len必需是4的整数倍)
    BMS_ATTR_TAB,        ///< BMS属性表        存储空间小于1.5K
    PARA_TYPE_NUM,       ///< 参数类型总数(这个不是参数区)
};

#ifndef SDK_API_INTERFACE_ENABLE	///< SDK接口对外声明是否打开

#define SDK_PARA_DLOG(...) log_d(__VA_ARGS__)

#define BMS_RUNING_DATA_SIZE 3584 // 3.5K
#define IAP_PARA_SIZE 1536        // 1.5K
#define BMS_ATTR_TAB_SIZE 1536    // 1.5K

/**
 * @brief  按参数区类型挂载参数
 *         多次挂载没有副作用
 * @param  [in] type 参数区类型（枚举中定义的值）
 * @param  [in] para_size 参数区大小（不能超过物理空间）
 * @retval 0  成功
 * @retval -1 参数区不存在
 * @retval -2 参数大小非法
 * @retval -3 -4 -5 -6 -7 文件系统错误
 */
int32_t sdk_para_init(uint32_t type, uint32_t para_size);

/**
 * @brief  按参数区类型写内容
 * @param  [in] type 参数区类型（枚举中定义的值）
 * @param  [in] offset 参数中的位置 (offset+len < para_size)
 * @param  [in] buf 内容
 * @param  [in] len 内容长度 (offset+len < para_size)
 * @retval 0  成功
 * @retval -1 参数区不存在
 * @retval -2 参数区未挂载
 * @retval -3 写入超出长度
 * @retval -4 打开文件失败
 */
int32_t sdk_para_write(uint32_t type, uint32_t offset, uint8_t *p_buf, uint32_t len);

/**
 * @brief  按参数区类型读参数
 * @param  [in]  type 参数区类型（枚举中定义的值）
 * @param  [in]  offset 参数中的位置 (offset+len < para_size)
 * @param  [out] buf 内容
 * @param  [in]  len 内容长度 (offset+len < para_size)
 * @retval 0  成功
 * @retval -1 参数区不存在
 * @retval -2 参数区未挂载
 * @retval -3 写入超出长度
 * @retval -4 打开文件失败
 */
int32_t sdk_para_read(uint32_t type, uint32_t offset, uint8_t *p_buf, uint32_t len);

/**
 * @brief  同步参数的数据到flash(写入的数据，只有同步后才会掉电保存)
 * @param  [in] type 参数区类型（枚举中定义的值）
 * @retval 0  成功
 * @retval -1 失败
 */
int32_t sdk_para_sync(uint32_t type);

#endif
#endif
