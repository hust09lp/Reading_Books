#ifndef __SDK_MISC_H__
#define __SDK_MISC_H__

#include <stdint.h>






#ifndef SDK_API_INTERFACE_ENABLE	///< SDK接口对外声明是否打开


#endif

#endif


