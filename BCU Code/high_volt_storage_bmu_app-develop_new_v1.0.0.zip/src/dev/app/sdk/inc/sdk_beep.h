#ifndef __SDK_BEEP_H__
#define __SDK_BEEP_H__

#include <stdint.h>



#define BEEP_IO "PD.9"		///< 蜂鸣器的IO引脚
#define BEEP_PIN_NUM 56		///< 蜂鸣器的引脚编号
#define BEEP_ON 1			///< 蜂鸣器响
#define BEEP_OFF 0			///< 蜂鸣器灭


#ifndef SDK_API_INTERFACE_ENABLE	///< SDK接口对外声明是否打开

/**
* @brief		蜂鸣器引脚初始化
* @param		无
* @return		执行结果
* @retval		无返回值
* @warning		无警告
*/
void sdk_beep_init(void);

/**
* @brief	设置蜂鸣器响灭、响的持续时间
* @param	[in] 状态持续时间 time
* @param	[in] 使能与否 cmd
	* -# BEEP_OFF			蜂鸣器灭
	* -# BEEP_ON			蜂鸣器响
* @return		执行结果
* @retval		无返回值
* @warning		无警告
*/
void sdk_beep_set(uint32_t time, uint8_t cmd);

/**
* @brief		蜂鸣器状态检测
* @param		无输入
* @return		执行结果
* @retval		无返回值
* @warning		无警告
*/
void sdk_beep_scan(void);

#endif
#endif
