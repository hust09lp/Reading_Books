#ifndef __SDK_IAP_PARA_H__
#define __SDK_IAP_PARA_H__

#include <stdint.h>

enum
{
    IAP_NULL = 0,         // 未定义
    IAP_FINISH = 1,       // 升级完成
    IAP_CORE_UPGRADE = 2, // CORE升级
    IAP_APP_UPGRADE = 3,  // APP升级
    IAP_COMB_UPGRADE = 4, // core与app同时升级

    IAP_BACK_CORE = 5, // 升级流程标志 - 升级文件类型标志
    IAP_BACK_APP = 6,  // 升级流程标志 - 升级文件类型标志
    IAP_BACK_COMB = 7, // 升级流程标志 - 升级文件类型标志
    IAP_BACK_BACK = 8, // 升级流程标志 - 升级文件类型标志
};

#ifndef SDK_API_INTERFACE_ENABLE	///< SDK接口对外声明是否打开

/**
 * @brief iap设置标志
 * @param  [in] flag iap标志值
 * @retval 0  成功
 * @retval -1 失败
 */
int32_t sdk_iap_set_flag(uint8_t flag);

/**
 * @brief iap设置标志
 * @param  [in] flag iap状态值
 * @return 升级标志
 * @retval IAP_NULL 无效标志
 * @retval IAP_FINISH_FINISH
 * @retval IAP_CORE_UPGRADE
 * @retval IAP_APP_UPGRADE
 * @retval IAP_BACK_CORE
 * @retval IAP_BACK_APP
 * @retval IAP_BACK_BACK
 */
uint8_t sdk_iap_read_flag(void);

#endif
#endif
