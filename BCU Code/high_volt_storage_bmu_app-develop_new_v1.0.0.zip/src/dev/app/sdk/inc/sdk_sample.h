/**
	* @file     sdk_sample.h
	* @brief    电池数据采样文件
	* @company  sofarsolar
	* @author   骆鹏
	* @note
	* @version
	* @date     2022/10/25
*/

#ifndef __SDK_SAMPLE_H__
#define __SDK_SAMPLE_H__

#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#define TEMP_TABLE_SIZE        (sizeof(ntc_res_table)/sizeof(ntc_res_table[0])) ///< NTC电阻表格
#define REF_VOLT                3000        ///< 参考电压       单位1mV
#define SAMP_VOLT		        3000        ///< 采集电压       单位1mV  
#define BAT_TEMP_OFFSET  	    400  	    ///< 温度偏移量      单位0.1℃
#define BAT_CURR_OFFSET 	    300000  	///< 电流偏移量30000，单位1mA  
#define ADC_FILTER_NUM          12          ///< ADC滤波数量
#define MAX_CHG_CALI_GAIN_L     600       ///< 大环充电电流校准增益80%      理论值750*80% 为提高精度放大5倍
#define MAX_CHG_CALI_GAIN_H     900       ///< 大环充电电流校准增益120%       理论值750*120% 为提高精度放大5倍
#define MAX_DSG_CALI_GAIN_L     720         ///< 大环放电电流校准增益80%      理论值900*80%   为提高精度放大3倍
#define MAX_DSG_CALI_GAIN_H     1080         ///< 大环放电电流校准增益120%     理论值900*120%   为提高精度放大3倍
#define MIN_DSG_CALI_GAIN_L     117         ///< 小环放电电流校准增益80%        理论值14.7 *10 *80%  为提高精度放大10倍
#define MIN_DSG_CALI_GAIN_H     176        ///< 小环放电电流校准增益120%        理论值14.7 * 10 *120% 为提高精度放大10倍
#define MIN_CHG_CALI_GAIN_L     117         ///< 小环充电电流校准增益80%        理论值14.7 *10 *80%  为提高精度放大10倍
#define MIN_CHG_CALI_GAIN_H     176        ///< 小环充电电流校准增益120%        理论值14.7 * 10 *120% 为提高精度放大10倍
#define BAT_SUM_VOLT_CALI_L     56700      ///< 电池总压校准增益90%      理论值21*3000*90%
#define BAT_SUM_VOLT_CALI_H     69300      ///< 电池总压校准增益110%     理论值21*3000*110%
#define LOAD_VOLT_P_L           56700      ///< (P+)负载电压校准增益90%  理论值21*3000*90%
#define LOAD_VOLT_P_H           69300      ///< (P+)负载电压校准增益110% 理论值21*3000*110%
#define CELL_VOLT_NUM         		16		///< 电芯电压数量
#ifdef N32G45X
#define CELL_TEMP_NUM         		4		///< 电芯温度数量
#endif
#ifdef STM32G474
#define CELL_TEMP_NUM         		8		///< 电芯温度数量
#endif
#define BALANCE_TEMP_NUM      		2		///< 均衡温度数量
#define SAMPLE_STATE_OK				0		///< 采集状态获取成功
#define SAMPLE_STATE_EOI             1      ///< 采集状态获取失败
#define NTC_SHORT_CIRCUIT_ERR		-1		///< NTC短路
#define NTC_OPEN_CIRCUIT_ERR		-2		///< NTC开路
#define AFE_ERR						-3		///< AFE异常
#define COPPER_RES                  50      ///< 微欧


/**
  * @enum   ntc_res_type_e
  * @brief  NTC电阻类型
  */
typedef enum
{
	ENV_NTC = 0,	///< 环境NTC
	MOS_NTC,		///< MOS NTC
	HEAT_NTC,		///< 加热膜NTC
#ifdef STM32G474
	BALANCE1_NTC,	///< 均衡NTC1		//diff_modify
	BALANCE2_NTC,	///< 均衡NTC2
#endif
	CELL_NTC1,		///< 电芯NTC1
	CELL_NTC2,		///< 电芯NTC2
	CELL_NTC3,		///< 电芯NTC3
	CELL_NTC4,		///< 电芯NTC4
#ifdef STM32G474
	CELL_NTC5,		///< 电芯NTC5		//diff_modify
	CELL_NTC6,		///< 电芯NTC6
	CELL_NTC7,		///< 电芯NTC7
	CELL_NTC8,		///< 电芯NTC8
#endif
	NTC_NUM,
}ntc_type_e;

/**
  * @enum   abnormal_type_e
  * @brief  采样状态异常类型
  */
typedef enum
{	
	AFE_COMM_ERR = 0,			///< AFE异常
	ENV_NTC_ERR,        		///< 环境温度NTC异常
	MOS_NTC_ERR,            	///< MOS温度NTC异常
	HEAT_NTC_ERR,           	///< 加热膜温度NTC异常
#ifdef STM32G474
	BALANCE1_NTC_ERR,			///< 均衡NTC1异常		//diff_modify
	BALANCE2_NTC_ERR,			///< 均衡NTC2异常
#endif
	CELL1_NTC_ERR,				///< 电芯NTC1异常
	CELL2_NTC_ERR,				///< 电芯NTC2异常
	CELL3_NTC_ERR,				///< 电芯NTC3异常
	CELL4_NTC_ERR,				///< 电芯NTC4异常
#ifdef STM32G474
	CELL5_NTC_ERR,				///< 电芯NTC5异常		//diff_modify
	CELL6_NTC_ERR,				///< 电芯NTC6异常
	CELL7_NTC_ERR,				///< 电芯NTC7异常
	CELL8_NTC_ERR,				///< 电芯NTC8异常
#endif
	ERR_NUM,
}abnormal_type_e;

/**
 * @struct adjust_para_tab_t 
 * @brief 校准参数表
 */
typedef struct
{
    uint32_t bat_total_volt_gain;     ///< 电池总电压增益
    uint32_t load_volt_gain;         ///<  (P+)负载电压增益
    uint32_t max_chg_curr_gain;     ///<  大环充电电流增益
    uint32_t min_chg_curr_gain;     ///<  小环充电电流增益
    uint32_t max_dsg_curr_gain;     ///<  大环放电电流增益
    uint32_t min_dsg_curr_gain;     ///<  小环放电电流增益
} adjust_para_tab_t;

typedef struct
{
    uint32_t load_volt_n_gain;     ///< P-负载电压增益
} adjust2_para_tab_t;

/**
 * @enum adjust_para_tab_e 
 * @brief 校准参数表
 */
typedef enum
{
     BAT_TOTAL_VOLT_GAIN = 1,       ///< 电池总电压增益
     LOAD_VOLT_GAIN,                ///< (P+)负载电压增益
     MAX_CHG_CURR_GAIN,             ///< 大环充电电流增益
     MIN_CHG_CURR_GAIN,             ///< 小环充电电流增益
     MAX_DSG_CURR_GAIN,             ///< 大环放电电流增益
     MIN_DSG_CURR_GAIN,             ///< 小环放电电流增益   
	 LOAD_VOLT_N_GAIN,              ///< (P-)负载电压增益
     ADJUST_PARA_NUM,
} adjust_para_tab_e;


/**
  * @struct	bat_sample_data_t
  * @brief  电池采样数据管理
  */
#pragma pack(1)
typedef struct
{
	uint16_t   cell_volt[CELL_VOLT_NUM];		///< 单体电压		单位1mV
	int16_t    cell_temp[CELL_TEMP_NUM];		///< 单体温度		单位0.1℃
	int16_t    balance_temp[BALANCE_TEMP_NUM];	///< 均衡温度		单位0.1℃
	int32_t    sys_current;						///< 系统电流  		 1mA
	uint32_t   bat_afe_volt;					///< 采样总压AFE 单位1mV
	uint32_t   bat_mcu_volt;					///< 采集总压MCU 单位1mV
	uint32_t   bat_acc_volt;					///< 累计总压   	  单位1mV
	uint32_t   check_12v_volt;					///< 12V电压检测      单位1mV
	uint32_t   load_volt_p;						///< p+端口电压       单位1mV
	uint32_t   load_volt_n;						///< p-端口电压(检测负载移除) 单位1mV
	uint32_t   hardware_version_volt;			///< 硬件版本号识别	单位1mV 
	uint32_t   max_cell_volt;					///< 最大单体电压 1mV
	uint32_t   min_cell_volt;					///< 最小单体电压 1mV
	uint32_t   avg_cell_volt;					///< 平均电压		 1mV
	uint32_t   diff_cell_volt;					///< 压差			 1mV
	uint8_t    max_volt_num;					///< 最大单体电压序号
	uint8_t    min_volt_num;					///< 最小单体电压序号
	uint8_t    max_temp_num;					///< 最高温度序号
	uint8_t    min_temp_num;					///< 最低温度序号
	int16_t    max_cell_temp;					///< 最大单体温度 0.1℃
	int16_t    min_cell_temp;					///< 最小单体温度 0.1℃
	int16_t    avg_cell_temp;					///< 平均温度		 0.1℃
	int16_t    diff_cell_temp;					///< 温差			 0.1℃
	int16_t    mos_temp;						///< Mos温度		 0.1℃
	int16_t    env_temp;						///< 环境温度		 0.1℃
	int16_t    heat_temp;						///< 加热膜温度		 0.1℃
    uint32_t   max_ring_dsg_zero_volt;        	///< 大环放电零点电压     1mV
    uint32_t   max_ring_chg_zero_volt;          ///< 大环充电零点电压     1mV
    uint32_t   min_ring_dsg_zero_volt;          ///< 小环放电零点电压     1mV
    uint32_t   min_ring_chg_zero_volt;          ///< 小环充电零点电压     1mV
    uint32_t   dsg_curr_offset_volt;     		///< 电流偏置位电压       1mV
    uint32_t   mos_ntc_volt;					///< MOS的NTC电压 		 1mV
    uint32_t   env_ntc_volt;					///< 环境的NTC电压	     1mV
    uint32_t   heat_ntc_volt;					///< 加热膜的NTC电压	1mV
}sample_data_t;
#pragma pack()



#ifndef SDK_API_INTERFACE_ENABLE	///< SDK接口对外声明是否打开

/**
* @brief                ADC采样初始化
* @param                [in]无
* @return               返回结果
* @retval               [out]SDK_OK初始化成功
* @retval               [out]SDK_EIO初始化失败
* @warning              无
*/
int32_t sdk_sample_init(void);



/**
* @brief		校准参数计算
* @param		[in] adjust_para_tab_e adjust_para_type 校准参数类型
* @param        [in]uint32_t cali_value 校准值
* -# 电流值      单位10mA  
* -# 电压值      单位0.1V
* @param        [in]adjust_para_tab_t *adjust_para_tab 校准结果值
* @return		返回结果
* @retval	    [out] ret(0)  校准计算成功
* @retval	    [out] ret(-1) 空指针校准计算失败
* @retval	    [out] ret(1)  校准增益超出范围或校准类型无效计算失败
* @warning
*/
int32_t sdk_sample_adjust_cali(adjust_para_tab_e adjust_para_type, uint32_t cali_value, adjust_para_tab_t *adjust_para_tab);

/**
* @brief                采样校准参数设置
* @param                [in]adjust_para_tab_t *adjust_para_tab 校准参数表结构体
* @return               返回结果
* @retval               [out]ret(0)  设置成功
* @retval               [out]ret(-1) 设置失败
* @warning              无
*/
int32_t sdk_sample_adjust_set(adjust_para_tab_t *adjust_para_tab);

/**
* @brief                采样异常状态获取
* @param                [in]abnormal_type_e
* -# AFE_COMM_ERR = 0,			///< AFE异常
* -# ENV_NTC_ERR,        		///< 环境温度NTC异常
* -# MOS_NTC_ERR,            	///< MOS温度NTC异常
* -# HEAT_NTC_ERR,           	///< 加热膜温度NTC异常
* -# CELL1_NTC_ERR,				///< 电芯NTC1异常
* -# CELL2_NTC_ERR,				///< 电芯NTC2异常
* -# CELL3_NTC_ERR,				///< 电芯NTC3异常
* -# CELL4_NTC_ERR,				///< 电芯NTC4异常
* @return               返回结果
* @retval               [out]ret(SAMPLE_STATE_OK)  获取采集状态成功
* @retval               [out]ret(SAMPLE_STATE_EOI) 获取采集状态失败
* @retval               [out]ret(NTC_SHORT_CIRCUIT) NTC短路
* @retval               [out]ret(NTC_OPEN_CIRCUIT)  NTC开路
* @retval               [out]ret(AFE_ERR)           AFE异常
*/
int32_t sdk_sample_abnormal_get(abnormal_type_e type);

/**
* @brief                获取电池采样信息
* @param                [in]bat_sample_data_t *p_data 电池采样数据结构体指针
* @return               返回结果
* @retval               ret(-1)获取失败
* @retval               ret(0)获取成功
* @warning              无
*/
int32_t sdk_sample_data_get(sample_data_t *p_data);


/**
* @brief                电池采样任务
* @param                [in]void *argument
* @return               返回结果
* @retval               [out]无
* @warning              无
*/
void sdk_sample_thread(void *argument);

#endif
#endif


