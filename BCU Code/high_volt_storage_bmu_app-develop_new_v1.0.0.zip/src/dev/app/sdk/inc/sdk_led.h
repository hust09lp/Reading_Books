#ifndef __SDK_LED_H__
#define __SDK_LED_H__

#include <stdint.h>
/**
  * @brief LED灯标识
  */
typedef enum{
	BOARD_ERR_LED	= 0u,		///< 板上异常指示灯
	BOARD_NOR_LED	= 1u,		///< 板上正常指示灯
	USER_NOR_LED	= 2u, 		///< 用户正常状态灯
	USER_ERR_LED	= 3u,		///< 用户异常状态灯
	WAKEUP_LED		= 4u, 		///< 唤醒指示灯
	BATTERY_LED1	= 5u, 		///< 电量指示灯段1
	BATTERY_LED2	= 6u, 		///< 电量指示灯段2
	BATTERY_LED3	= 7u,		///< 电量指示灯段3
	BATTERY_LED4	= 8u, 		///< 电量指示灯段4
	BATTERY_LED5	= 9u, 		///< 电量指示灯段5
	BATTERY_LED6	= 10u,		///< 电量指示灯段6
	LED_NAME_MAX	= 11u,		///< LED指示灯数量
}led_name_e;

/**
  * @brief 	LED状态
  */
typedef enum
{
	LED_ON = 0,	///< LED亮
	LED_OFF,	///< LED灭
}led_state_e;

/**

  * @brief LED灯信息结构体
  */
typedef struct{
	uint32_t period;			///< LED灯闪烁周期
	uint32_t duty;				///< LED灯闪烁占空比
	uint32_t status_starttime;	///< LED状态开始时间
	uint8_t  status;			///< LED当前状态
}led_info_t;

#ifndef SDK_API_INTERFACE_ENABLE///< SDK接口对外声明是否打开

/**
* @brief	LED的IO初始化
* @param	无输入
* @return	执行结果
* @retval	0   led初始化成功
* @retval	-1  led初始化失败
* @pre 		无前置条件
* @warning	无警告
*/
int32_t sdk_led_init(void);

/**
* @brief	设置LED灯的闪烁参数
* @param	[in] led  	LED标号
* @param	[in] period LED闪烁周期
* @param	[in] duty	LED闪烁占空比
* @return	执行结果
* @retval	0   led设置成功
* @retval	-1  入参错误
* @pre 		无前置条件
* @warning	无警告
*/
int32_t sdk_led_setup(uint32_t led_no, uint32_t period, uint32_t duty);
 
/**
* @brief	设置LED灯的亮灭
* @param	[in] led  	LED标号
* @return	执行结果
* @retval	0   led设置成功
* @retval	-1  led设置失败
* @pre 		无前置条件
* @warning	无警告
*/
int32_t sdk_led_on(uint32_t led_no);

/**
* @brief	设置LED灯的亮灭
* @param	[in] led  	LED标号
* @return	执行结果
* @retval	0   led设置成功
* @retval	-1  led设置失败
* @pre 		无前置条件
* @warning	无警告
*/
int32_t sdk_led_off(uint32_t led_no);

/**
* @brief	LED信息轮训检测并更新结构体
* @param	无输入
* @retval	无返回值
* @pre 		无前置条件
* @warning	无警告
*/
void sdk_led_scan(void);

#endif
#endif
