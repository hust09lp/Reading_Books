#ifndef __SDK_KEY_H__
#define __SDK_KEY_H__
#include <stdint.h>

/**
  * @brief 	按键名字和数量
  */
typedef enum{
	KEY_POWER = 0,	///< 关机/唤醒按键
	KEY_NUM,		///< 按键数量
}key_name_e;

/**
  * @brief 	按键的键值
  */
typedef enum 
{
    KEY_NO_PRESS = 0,           ///< 无按键按下
	KEY1_SHORT_PRESS,           ///< 按键1短按
    KEY1_LONG_PRESS,            ///< 按键1长按
	KEY2_SHORT_PRESS,           ///< 按键2短按
    KEY2_LONG_PRESS,            ///< 按键2长按
    KEY3_SHORT_PRESS,           ///< 按键3短按
    KEY3_LONG_PRESS,            ///< 按键3长按
    KEY4_SHORT_PRESS,           ///< 按键4短按
    KEY4_LONG_PRESS,            ///< 按键4长按
    KEY1_2_PRESS,               ///< 组合按键,按键1和按键2同时按下
}key_val_e;

/**
  * @brief 	按键的状态
  */
typedef enum
{
	KEY_DOWN = 0, 	///< 按键处于按下状态
	KEY_UP,			///< 按键处于松开状态
}key_state_e;

/**
  * @brief 按键信息结构体
  */
typedef struct
{
	key_state_e key_state;	///< 按键状态
	uint32_t start_time;	///< 按键状态的开始时间
	uint32_t end_time;		///< 按键状态的结束时间
}key_info_t;

#ifndef SDK_API_INTERFACE_ENABLE	///< SDK接口对外声明是否打开

/**
* @brief		初始化按键的IO及按键信息结构体
* @param		无输入
* @return		执行结果
* @retval		0  初始化成功
* @retval		-1 初始化失败
* @warning		无
*/
int32_t sdk_key_init(void);

/**
* @brief			获取按键的信息
* @return			执行结果
* @retval			按键状态
* -# KEY_NO_PRESS = 0,    ///< 无按键按下
* -# KEY1_SHORT_PRESS,    ///< 按键1短按
* -# KEY1_LONG_PRESS,     ///< 按键1长按
* -# KEY2_SHORT_PRESS,    ///< 按键2短按
* -# KEY2_LONG_PRESS,     ///< 按键2长按
* -# KEY3_SHORT_PRESS,    ///< 按键3短按
* -# KEY3_LONG_PRESS,     ///< 按键3长按
* -# KEY4_SHORT_PRESS,    ///< 按键4短按
* -# KEY4_LONG_PRESS,     ///< 按键4长按
* -# KEY1_2_PRESS，       ///< 组合按键,按键1和按键2同时按下
* @warning			无
*/
key_val_e sdk_key_get(void);

/**
* @brief		按键轮询检测并更新数据结构体
* @param		无输入
* @return		执行结果
* @retval		无返回值
* @warning		无
*/
void sdk_key_scan(void);

#endif
#endif
