/**
 * @file     passive_balance.c
 * @brief    BMU 被动均衡逻辑
 * @company  sofarsolar
 * @author   骆鹏
 * @note     利用充电结束时刻数据计算理论均衡时间
 * @version  V1.0.2
 * @date     2023/08/21
 */
/*---------头文件声明----------*/
#include "sdk.h"
#include "passive_balance.h"
#include "public_flag.h"
#include "bms_state.h"
#include "fault_manage.h"
#include "bmu_data.h"
#include "app_public.h"
#include "data_store.h"
#include "afe_manage.h"
#include "ate.h"
#include "sofar_can_data.h"
#include "sox_math.h"

static uint32_t  g_init_tick =  0;

/**
  * @struct full_chg_data_t
  * @brief 充电结束时刻记录的电池数据
*/

typedef struct
{
    int32_t  chg_curr;              ///< 充电电流 单位mA
    uint16_t min_cell_vol;          ///< 最小电芯电压 单位mV
    uint16_t cell_vol[BAL_CELL_NUM];    ///< 单体电压 单位mV
    uint8_t  chg_ending_time;       ///< 充电结束时刻
}full_chg_data_t;
typedef struct
{
    uint16_t min_cell_soc;          // 最小电池SOC
    uint8_t bmu_data_ready_cnt;     // 本BMU被动均衡数据准备就绪持续发送次数
    uint8_t bmus_data_ready_wating_cnt;    // 其余BCU被动均衡数据准备就绪持续发送次数
    bool bmu_data_ready_flag;       // 本BMU被动均衡数据准备就绪标志
    bool bmus_data_ready_flag;      // 其余BCU被动均衡数据准备就绪标志
}data_status_t;

/*---------变量声明----------*/
static passive_balance_interface_remap_t g_passive_balance_if_remap = {0};           // 被动均衡定制化接口映射结构体
static balance_public_interface_remap_t  g_balance_public_if_remap =  {0};          // 均衡公共模块定制化接口映射结构体
static balance_bat_data_t                g_balance_bat_data ={0};                   // 均衡需要的电池数据
static scroll_record_data_t              g_scroll_record_data = {0};              //  滚动记录的数据:电芯电压 电流
static full_chg_data_t                   g_full_chg_data  = {0};                  //  充电结束时刻的数据
static uint8_t                           g_enter_proc_vol_index = 0;             //滑窗电压指针 1S一次 5S以后保持在SLIDING_FILTER_5S_BASED_1S
static uint8_t                           g_enter_proc_curr_index = 0;            //滑窗电流指针 1S一次 60S以后保持在SLIDING_FILTER_60S_BASED_1S
static uint8_t                           g_chg_ending_index = 0;                  //充电结束时刻
static int16_t                           g_cell_temp[BAL_CELL_NUM] = {0};             //电芯温度
static int32_t                           g_cell_soc[BAL_CELL_NUM] = {0};              //各电芯SOC
static int32_t                           g_cell_balance_time[BAL_CELL_NUM] = {0};     // 各电芯均衡时间
static bms_attr_type_t                   g_bms_attr_type     = {0};              //bms参数属性
static uint8_t                           g_full_moment_distance = 0;             // 满充时刻与当前时刻的间距

static bool g_cell_balance_init_flag = false;                                      // 电池均衡初始化标志

static uint16_t                         gp_cell_bal_pos[AFE_NUM] = {0};                 // 被动均衡位置指针

static data_status_t                     g_data_status = {
    .min_cell_soc = 0,
    .bmu_data_ready_cnt = 0,
    .bmus_data_ready_wating_cnt = 0,
    .bmu_data_ready_flag = false,
    .bmus_data_ready_flag = false,
};// BMU数据准备状态

/*---------函数声明----------*/
static bool full_chg_moment_distance_get(uint8_t *p_chg_ending_index , uint8_t *p_vol_now_index , uint8_t *p_distance);
static int8_t balance_check_tab_condition_permit(int16_t cell_avg_temp, scroll_record_data_t *p_scroll_record_data, uint8_t *p_full_moment_distance, uint8_t *p_curr_now_moment);
static int32_t passive_balance_time_calc(balance_bat_data_t *p_balance_bat_data, int32_t *p_cell_soc, int32_t *p_cell_balance_time, uint16_t cell_num,uint16_t min_check_soc);
static int32_t passive_balance_start_permit(balance_bat_data_t *p_balance_bat_data, uint16_t cell_num);
static int8_t balance_time_renew(uint16_t cell_num);
static int32_t full_chg_moment_distance_check(void);
static bool balance_time_calc_proc(void);
static int8_t balance_start_proc(void);
static void  global_var_reset(void);

/*********************表格---三维表格，通过SOC、电流、温度查阅电压*****************/
//U_table三维表长度
#define U_TABLE_DIMENSION 3		///< U_table表的维度
#define U_TABLE_CUR_LENGTH 4	///< U_table表的电流维度
#define U_TABLE_TEMP_LENGTH 4	///< U_table表的温度维度
#define U_TABLE_VOLT_LENGTH 5	///< U_table表的电压维度
#define U_TABLE_SOC_LENGTH 5	///< U_table表的SOC维度
//U_table三维表索引：SOC、电流、温度
static const int32_t utab_index_tab[U_TABLE_DIMENSION][U_TABLE_SOC_LENGTH] =
{
	{9900, 9925, 9950, 9975, 10000},  //SOC 0.01%
	{28000, 84000, 140000, 210000},   //电流 1mA, 分别对应 0.1C, 0.3C, 0.5C, 0.75C
	{150, 250, 350, 450},             //温度 0.1℃
};

//U_table三维表
static const int32_t utab_tab[U_TABLE_TEMP_LENGTH][U_TABLE_CUR_LENGTH][U_TABLE_VOLT_LENGTH] =
{
    //   99%   99.25%   99.5%   99.75%  100%
	{ //15℃
		{3486 ,	3496 ,	3509 ,	3527 ,	3550} , //0.1C
		{3530 ,	3534 ,	3539 ,	3544 ,	3550} , //0.3C
		{3538 ,	3541 ,	3544 ,	3547 ,	3550} , //0.5C
		{3542 ,	3544 ,	3546 ,	3548 ,	3550} , //0.75C
	},
	{ //25℃
        {3440 ,	3452 ,	3471 ,	3502 ,	3550} ,
		{3493 ,	3502 ,	3514 ,	3530 ,	3550} ,
		{3515 ,	3522 ,	3530 ,	3539 ,	3550} ,
		{3528 ,	3533 ,	3538 ,	3544 ,	3550} ,
	},
	{ //35℃
		{3420 ,	3435 ,	3460 ,	3499 ,	3550} ,
		{3454 ,	3464 ,	3480 ,	3505 ,	3550} ,
		{3484 ,	3494 ,	3507 ,	3524 ,	3550} ,
		{3508 ,	3515 ,	3525 ,	3535 ,	3550} ,
	},
	{ //45℃
		{3396 ,	3405 ,	3423 ,	3463 ,	3550} ,
		{3432 ,	3442 ,	3459 ,	3489 ,	3550} ,
		{3462 ,	3473 ,	3488 ,	3512 ,	3550} ,
		{3491 ,	3500 ,	3511 ,	3527 ,	3550} ,
	},
};

#ifdef CELL_DEBUG
    bool g_debug_full_chg_flag = false;

    bmu_data_t gp_debug_bmu_data = {
        .avg_cell_temp = 250,
        .cell_volt = {3481, 3482, 3483, 3484, 3485, 3486, 3487, 3488,
                    3489, 3490, 3491, 3492, 3493, 3494, 3495, 3496,},
        .cell_temp = {250, 250, 250, 250, 250, 250, 250, 250,},
        .min_cell_volt = 3481,
        .sys_current = 10000,
    };   //BMU数据

    fault_stat_data_t gp_debug_fault_data = {
        .max_charge_level = 3, //最大充电等级
        .max_discharge_level = 3, //最大放电等级
    }; //故障充放电等级

    sox_data_t gp_debug_sox_data = {
        .calc_soh = 100000, //SOH计算值，单位0.1%
    };     //SOX数据
#endif

#ifdef CELL_BALANCE_SHELL_DEBUG_TEST
static bool g_cell_balance_shell_debug_flag = false;
static uint16_t g_full_chg_cell_vol_debug[16] = {0};
static uint8_t  g_full_chg_ending_index_debug = 0;
static int32_t g_cell_balance_timer_debug[16] = {0};
static uint32_t g_cell_balance_pos_debug = 0;
#endif

#if CELL_BALANCE_SELF_CHECK_TEST
static bool g_cell_balance_self_check_flag = true;
#endif

/**
* @brief		寻找最低的电芯SOC
* @param		cell_soc_array 电芯SOC数列
* @param		cell_num  电芯数量
* @return		返回结果
* @retval		RUNNING_OK：记录成功  RUNNING_FAIL: 记录失败
* @warning
*/
uint16_t min_cell_soc_get(int32_t *cell_soc_array, uint16_t cell_num)
{
    uint16_t i = 0;
    uint16_t min_cell_soc = 0xFFFF;

    if (NULL == cell_soc_array)
    {
        return RUNNING_FAIL;
    }

    for (i = 0; i < cell_num; i++)
    {
        if (min_cell_soc >= cell_soc_array[i])
        {
            min_cell_soc = (uint16_t)cell_soc_array[i];
        }
    }

    return min_cell_soc;
}


/**
* @brief		滑窗记录最近时间内的电池数据
* @param		uint16_t cell_num 电芯数量
* @param		*p_vol_count  电压记录时刻下标
* @param		*p_curr_count 电流记录下标
* @param		scroll_record_data_t *p_scroll_record_data 滚动记录的电池数据结构体
* @param		balance_bat_data_t *p_balance_bat_data 均衡需要的电池数据
* @return		返回结果
* @retval		RUNNING_OK：记录成功  RUNNING_FAIL: 记录失败
* @warning
*/
bool sliding_filter_record_bat_data(uint16_t cell_num, uint8_t *p_vol_count,uint8_t *p_curr_count, scroll_record_data_t *p_scroll_record_data,balance_bat_data_t *p_balance_bat_data)
{
    uint8_t i =0, j = 0, m = 0;
    static uint8_t curr_count_temp,vol_count_temp = 0;

    if ((NULL == p_vol_count ) ||
        (NULL == p_curr_count) ||
        (NULL == p_scroll_record_data) ||
        (NULL == p_balance_bat_data)   ||
        (0 == cell_num))                        //入参判断
     {

         return RUNNING_FAIL;
     }

    //滚动记录电流值
     if (curr_count_temp >= SLIDING_FILTER_60S_BASED_1S)      // 满窗
    {

        for (i = 0; i < SLIDING_FILTER_60S_BASED_1S - 1; i++) //将1之后的数据移到0之后 即移除头部
        {
            p_scroll_record_data->sys_curr[i] = p_scroll_record_data->sys_curr[i + 1];
        }
        p_scroll_record_data->sys_curr[SLIDING_FILTER_60S_BASED_1S - 1] = abs(p_balance_bat_data->sys_curr); // 添加尾部 最新1S的数据放在最后

        //(*p_curr_count) = SLIDING_FILTER_60S_BASED_1S;//锁定当前时刻在尾部 下标 = 个数 -1
        curr_count_temp = SLIDING_FILTER_60S_BASED_1S;
    }
     else if (curr_count_temp < SLIDING_FILTER_60S_BASED_1S)                     // 不满窗口 先填充
    {
        p_scroll_record_data->sys_curr[curr_count_temp] = abs(p_balance_bat_data->sys_curr);
        //(*p_curr_count)++;
        curr_count_temp++; 
    }

    (*p_curr_count) = curr_count_temp - 1;      //数组下标

    //滚动记录电芯电压值
   if (vol_count_temp >= SLIDING_FILTER_5S_BASED_1S)    // 满窗
    {
        for (j = 0; j < SLIDING_FILTER_5S_BASED_1S - 1; j++) //将1之后的数据移到0之后 即移除头部
        {
            for (i = 0; i < cell_num; i++)
            {
              p_scroll_record_data->cell_vol[j][i] = p_scroll_record_data->cell_vol[j + 1][i];
            }
        }
        for (m = 0; m < cell_num; m++)                  // 添加尾部 最新1S的数据放在最后
        {
          p_scroll_record_data->cell_vol[SLIDING_FILTER_5S_BASED_1S - 1][m] =  p_balance_bat_data->cell_vol[m];
        }
        //(*p_vol_count) = SLIDING_FILTER_5S_BASED_1S; //锁定当前时刻在尾部 下标 = 个数 -1
        vol_count_temp = SLIDING_FILTER_5S_BASED_1S;
    }
   else if ((vol_count_temp) < SLIDING_FILTER_5S_BASED_1S)                    //不满窗口  先填充
    {
         for (i = 0; i < cell_num; i++)
        {
          p_scroll_record_data->cell_vol[vol_count_temp][i] =  p_balance_bat_data->cell_vol[i];
        }
        //(*p_vol_count)++;
        vol_count_temp++;
    }

    (*p_vol_count) = vol_count_temp - 1;      //数组下标

    return RUNNING_OK;
}

/**
* @brief		充电结束时刻查询
* @param		uint16_t cell_num 电芯数量
* @param		scroll_record_data_t *p_scroll_record_data 滚动记录的数据
* @param		uint8_t *p_chg_ending_index 充电结束时刻
* @return		返回结果
* @retval		RUNNING_FAIL: 查询失败  RUNNING_OK：查询成功
* @warning
*/
bool full_chg_moment_check(uint16_t cell_num, scroll_record_data_t *p_scroll_record_data, uint8_t *p_chg_ending_index)
{

    uint32_t sum_cell_vol_val[SLIDING_FILTER_5S_BASED_1S] = {0}; //存储最近5S时刻每一时刻的电芯电压和
    uint16_t avg_cell_vol_val[SLIDING_FILTER_5S_BASED_1S] = {0}; //存储最近5S时刻每一时刻的电芯电压平均值
    uint8_t i = 0, j = 0,k = 0, m = 0;
    uint16_t avg_cell_vol_max = 0;


    if ((NULL == p_scroll_record_data)||
        (NULL == p_chg_ending_index) ||
        (0 == cell_num))                 //入参判断
    {
        log_e("BalFullMomentCheckErr\n");
        return RUNNING_FAIL;
    }

    //求和
    for (j = 0; j < SLIDING_FILTER_5S_BASED_1S; j++)                    //遍历时刻
    {
        for (i = 0; i < cell_num; i++)                                 //遍历电芯数量
        {
            sum_cell_vol_val[j] += p_scroll_record_data->cell_vol[j][i];
        }
    }
    //求均值
    for (k = 0; k < SLIDING_FILTER_5S_BASED_1S; k++)
    {
        avg_cell_vol_val[k] = sum_cell_vol_val[k] / cell_num;
    }

    //找均值当中的最大值 对应的下标索引就是 充电结束时刻

    for ( m = 0; m < SLIDING_FILTER_5S_BASED_1S; m++)
    {
        if (avg_cell_vol_val[m] > avg_cell_vol_max)
        {

            avg_cell_vol_max = avg_cell_vol_val[m];
            (*p_chg_ending_index) = m;
        }
    }
    return RUNNING_OK;
}



/**
* @brief		记录充电结束时刻数据：电芯电压，电流
* @param		uint16_t cell_num 电芯数量
* @param		scroll_record_data_t *p_scroll_record_data 滚动记录的数据
* @param		full_chg_data_t *p_full_chg_data 充电结束时刻数据
* @param		uint8_t vol_chg_ending_index 电压充电结束时刻索引
* @param		uint8_t curr_chg_ending_index 电流充电结束时刻索引
* @return		返回结果
* @retval		RUNNING_FAIL: 记录失败   RUNNING_OK：记录成功
* @warning
*/
bool record_full_chg_data(uint16_t cell_num, scroll_record_data_t *p_scroll_record_data, full_chg_data_t *p_full_chg_data, uint8_t vol_chg_ending_index, uint8_t curr_chg_ending_index)
{
    uint8_t i = 0, j = 0;
    uint16_t cell_vol = 0;

    if ((NULL == p_scroll_record_data)||
        (NULL == p_full_chg_data) ||
        (0 == cell_num))                            //  入参判断
    {
        log_e("BalRecordFullErr\n");
        return RUNNING_FAIL;
    }

    uint16_t min_cell_vol_tmp = p_scroll_record_data->cell_vol[vol_chg_ending_index][0];  //最小电芯电压临时变量 假设充电结束时刻第一节电芯电压最小

    //记录充电结束时刻的数据:电流  单体电压
    p_full_chg_data->chg_curr = p_scroll_record_data->sys_curr[curr_chg_ending_index];
    for (i = 0; i < cell_num; i++)
    {
        p_full_chg_data->cell_vol[i] = p_scroll_record_data->cell_vol[vol_chg_ending_index][i];
    }
    //找出充电结束时刻的最小电芯电压
    for (j = 0;  j < cell_num; j++)
    {
        cell_vol = p_scroll_record_data->cell_vol[vol_chg_ending_index][j];
        if (cell_vol < min_cell_vol_tmp)
        {
            min_cell_vol_tmp = cell_vol;
        }
    }
    p_full_chg_data->min_cell_vol = min_cell_vol_tmp;

    //记录充电结束时刻的数据:充电结束时刻
    p_full_chg_data->chg_ending_time = (vol_chg_ending_index);

    return RUNNING_OK;
}

/**
* @brief 一维线性插值查表函数
* @param	 p_row          横坐标表地址
* @param	 p_column       纵坐标表的地址
* @param	 tab_length     表的长度（列数）
* @param	  x             要插值的横坐标
* @param	 *p_y             插值后的结果
* @return		返回结果
* @retval		插值失败:RUNNING_FAIL(0)    插值成功: RUNNING_OK(1)
* @warning		无
*/
int32_t balance_public_interp_1d(const int32_t* p_row, const int32_t* p_column, int32_t tab_length, int32_t x, int32_t *p_y)
{
    // 中间量

    int32_t i = 0;
    int32_t ratio = 0;
    int32_t col = tab_length;
    // 二分法查表中的索引
    int32_t start_index = 0;
    int32_t end_index = col - 1;
    int32_t mid_index = 0;

    if ((NULL == p_row) ||
        (NULL == p_column) ||
        (NULL ==  p_y) ||
        (0 == tab_length))           // 入参判断
    {
        log_e("bal_1d_tab_err\n");
        return RUNNING_FAIL;
    }

    // 超出边界表格处理 直接赋值为表格边界值
    if (x <= p_row[0])
    {
        (*p_y) = p_column[0];
        return RUNNING_OK;
    }
    else if (x >= p_row[col - 1])
    {
        (*p_y) = p_column[col - 1];
        return RUNNING_OK;
    }

    //表格内部查表处理
    while(start_index < end_index)
    {
        mid_index = (start_index + end_index)/2;
        //若横坐标索引在表中刚好有，则赋值相对应的数据
        if (x == p_row[mid_index])
        {
            (*p_y) = p_column[mid_index];
        }
        //若横坐标索引在两个坐标之间 插值处理
        if ((x > p_row[mid_index]) &&
            (x < p_row[mid_index + 1]))
        {
            break;
        }
        //横坐标索引在中间值左边或右边， 移动起始或终点索引 缩小范围
        if (x < p_row[mid_index])
        {
            end_index = mid_index;
        }
        else if (x > p_row[mid_index])
        {
            start_index = mid_index;
        }
        if (i++ > col)
        {
            break;
        }
    }

    /********* 除0保护*********************/
     if (0 == (p_row[mid_index + 1] - p_row[mid_index]))
     {
         return RUNNING_FAIL;
     }
     else
     {
         //插值处理是 整数类型的操作，计算时斜率会有误差，因为小数位被舍去 所以这里前面乘以1000，将斜率的精度提高到0.001
        ratio = 1000 * (p_column[mid_index + 1] - p_column[mid_index]) /
                        (p_row[mid_index + 1] - p_row[mid_index]);

        //根据斜率插值之后的结果 向下取整
        (*p_y) = ratio * (x - p_row[mid_index]) / 1000 + p_column[mid_index] ;
     }

    return RUNNING_OK;
}

/**
* @brief		三维插值(采用温度、电流和电芯电压查询电芯soc)
 * @param[in]	temp 温度 0.1℃
 * @param[in]	curr 电流 1mA
 * @param[in]	vol  电压 1mV
 * @return		retval: soc插值结果  0.01%
 * @warning		无
 * @pre
 * @note
*/
int32_t balance_interp_3d(int32_t temp, int32_t curr, int32_t vol)
{
    int8_t a = 0;  // 温度索引
    int8_t b = 0;  // 电流索引
    int32_t interp_vol[U_TABLE_SOC_LENGTH] = {0};  // 插值后的电压表
	int32_t soc_index[U_TABLE_SOC_LENGTH] = {0};   // soc索引表
    int32_t retval = 0;

    for(int8_t i = 0; i < U_TABLE_TEMP_LENGTH; i++)
    {
        if (temp < utab_index_tab[2][i])
        {
            a = i - 1;  // 找到最接近的温度范围，返回前一个索引
            if (0 > a)
            {
                a = 0;
            }
            break;
        }
        if (temp >= utab_index_tab[2][3])  // 温度超出范围取边界值
        {
            a = 3;
        }
    }
    for(int8_t j = 0; j < U_TABLE_CUR_LENGTH; j++)
    {
        if (curr < utab_index_tab[1][j])
        {
            b = j - 1;  // 找到最接近的电流范围，返回前一个索引
            if (0 > b)
            {
                b = 0;
            }
            break;
        }
        if (curr >= utab_index_tab[1][3])  // 电流超出范围取边界值
        {
            b = 3;
        }
    }

    for (int8_t i = 0; i < U_TABLE_TEMP_LENGTH + 1; i++)
    {
        if ((U_TABLE_TEMP_LENGTH - 1 == a) && (U_TABLE_CUR_LENGTH - 1 == b))
        {
            interp_vol[i] = utab_tab[a][b][i];
            continue;
        }
        if(U_TABLE_TEMP_LENGTH - 1 == a)
        {
            interp_vol[i] = utab_tab[a][b][i] + (utab_tab[a][b + 1][i] - utab_tab[a][b][i]) * (curr - utab_index_tab[1][b]) / (utab_index_tab[1][b + 1] - utab_index_tab[1][b]);
        }
        if(U_TABLE_CUR_LENGTH - 1 == b)
        {
            interp_vol[i] = utab_tab[a][b][i] + (utab_tab[a + 1][b][i] - utab_tab[a][b][i]) * (temp - utab_index_tab[2][a]) / (utab_index_tab[2][a + 1] - utab_index_tab[2][a]);
        }
        // 分别对温度和电流插值
        interp_vol[i] = utab_tab[a][b][i] +
                (utab_tab[a + 1][b][i] - utab_tab[a][b][i]) * (temp - utab_index_tab[2][a]) / (utab_index_tab[2][a + 1] - utab_index_tab[2][a]) +
                (utab_tab[a][b + 1][i] - utab_tab[a][b][i]) * (curr - utab_index_tab[1][b]) / (utab_index_tab[1][b + 1] - utab_index_tab[1][b]);
    }
	for (int8_t i = 0; i < U_TABLE_SOC_LENGTH; i++)
	{
		soc_index[i] = utab_index_tab[0][i];
	}

    retval = sox_interp_1d(interp_vol, soc_index, U_TABLE_SOC_LENGTH, vol);

    return retval;
}

/**
* @brief		均衡校准表线性插值函数
* @param		uint16_t *p_cell_vol 电芯电压 单位mV
* @param		int16_t  *p_cell_temp 电芯温度 单位0.1℃
* @param		 uint16_t cell_temp_num 电芯温度数量
* @param		*p_cell_soc 插值得到的各电芯SOC  分辨率0.01%
* @return		返回结果
* @retval		RUNNING_FAIL: 插值查表失败  RUNNING_OK： 插值查表成功
* @warning		无
*/
int32_t balance_cell_soc_tab_check(int16_t *p_cell_temp, int32_t p_cell_curr, uint16_t *p_cell_vol, uint16_t cell_volt_num, int32_t *p_cell_soc)
{
	int32_t cell_vol = 0;
    int32_t real_cell_temp = 0;

    if ((NULL ==  p_cell_temp)||
        (NULL == p_cell_vol) ||
        (NULL == p_cell_soc) ||
        (0 == cell_volt_num))           //入参判断
    {
        log_e("BalSocTabCheckErr\n");
        return RUNNING_FAIL;
    }

    // 一维查表 线性插值得到电芯SOC
	 for (uint8_t i = 0;  i < cell_volt_num; i ++)           // 遍历电芯温度数量
	 {
         cell_vol = (int32_t)p_cell_vol[i];    //注意变量类型统一 uint16_t -> int32_t
         real_cell_temp = p_cell_temp[i/2];        //注意变量类型统一  分辨率0.1℃

        p_cell_soc[i] = balance_interp_3d(real_cell_temp, p_cell_curr, cell_vol);

	 }
     return RUNNING_OK;
}

/**
* @brief		被动均衡外部定制化函数映射接口初始化
* @param		passive_balance_interface_remap_t 被动均衡接口映射结构体
* @param		 balance_public_interface_remap_t 均衡公共模块接口映射结构体
* @return		返回结果 是否初始化成功
* @retval		初始化成功：INIT_OK(1)  初始化失败： INIT_FAIL(0)
* @warning
*/
bool passive_balance_init(passive_balance_interface_remap_t *p_passive_balance_interface_remap, balance_public_interface_remap_t *p_balance_public_interface_remap)
{
    bool attr_get_flag = RUNNING_FAIL;
    bool init_flag = INIT_FAIL;

    if ( (NULL == p_passive_balance_interface_remap)||
         (NULL == p_balance_public_interface_remap))
    {
        log_e("CellBalInitErr\n");
        init_flag =  INIT_FAIL;
    }
    else
    {
        g_passive_balance_if_remap = (*p_passive_balance_interface_remap);
        g_balance_public_if_remap =  (*p_balance_public_interface_remap);
        memset(&g_balance_bat_data, 0, sizeof(g_balance_bat_data));
        memset(&g_scroll_record_data, 0, sizeof(g_scroll_record_data));
        memset(&g_full_chg_data, 0, sizeof(g_full_chg_data));
        g_enter_proc_vol_index = 0;
        g_enter_proc_curr_index = 0;
        g_chg_ending_index = 0;
        memset(&g_cell_temp, 0, sizeof(g_cell_temp));
        memset(&g_cell_soc, 0, sizeof(g_cell_soc));
        memset(&g_cell_balance_time, 0, sizeof(g_cell_balance_time));
        memset(&g_bms_attr_type, 0, sizeof(g_bms_attr_type));
        g_full_moment_distance = 0;
        memset(gp_cell_bal_pos, 0, sizeof(gp_cell_bal_pos));
        g_init_tick = sdk_tick_get();
        attr_get_flag = g_balance_public_if_remap.balance_bms_attr_get_cb(&g_bms_attr_type); // 获取BMS属性参数数据
        if (RUNNING_FAIL == attr_get_flag)
        {
            log_e("CellBalAttrErr\n");
            init_flag =  INIT_FAIL;
        }
        else
        {
            init_flag = INIT_OK;
        }
    }

    g_cell_balance_init_flag = init_flag;

    return init_flag;
}

// /**
// * @brief		滚动记录的5S电芯电压和系统电流值数据对外获取
// * @param		void
// * @return		返回结果 是否获取成功
// * @retval		scroll_record_data_t 滚动记录数据结构体
// * @warning
// */
// scroll_record_data_t* scroll_record_data_5s_data_get(void)
// {
//     scroll_record_data_t* ret = NULL;
//     ret = &g_scroll_record_data;
//     return ret;
// }

/**
* @brief		被动均衡满充时刻数据对外获取
* @param		uint16_t cell_num 电芯数量
* @param		uint16_t *p_cell_vol 要获取的电芯电压
* @param		uint8_t *p_chg_ending_index 要获取的充电结束时刻下标
* @return		返回结果 是否获取成功
* @retval		获取失败: RUNNING_FAIL(0)   获取成功: RUNNING_OK(1)
* @warning
*/
bool  passive_balance_full_chg_data_get(uint16_t cell_num, uint16_t *p_cell_vol, uint8_t *p_chg_ending_index)
{
    uint8_t i = 0;
    bool ret_flag =  RUNNING_FAIL;

    if ((NULL == p_cell_vol) ||
        (0 ==  cell_num) ||
        (NULL == p_chg_ending_index))
    {
        ret_flag =  RUNNING_FAIL;
    }
    else
    {

        for (i = 0; i < cell_num; i++)
        {
            p_cell_vol[i] = g_full_chg_data.cell_vol[i];
        }
        (*p_chg_ending_index) = g_full_chg_data.chg_ending_time;
        ret_flag = RUNNING_OK;
    }
    return ret_flag;
}

/**
* @brief		被动均衡时间对外获取
* @param		uin32_t cell_id  要获取的电芯位置 0 - 15： 表示电芯1- 电芯16
* @param		uint16_t cell_num  电芯数量
* @return		返回结果
* @retval		某单个电芯均衡时间  PARA_ERROR(-2)  入参错误 其他值：电芯均衡时间
* @warning
*/
int32_t passive_balance_time_get(uint32_t cell_id, uint16_t cell_num)
{
    int32_t ret = PARA_ERROR;

    if (cell_id >= cell_num)  // 入参判断
    {
        ret =  PARA_ERROR;
    }
    else                    //入参在范围内
    {
         ret =  g_cell_balance_time[cell_id];
    }
    return ret;
}

/**
* @brief		被动均衡位置获取
* @param		无
* @return		返回结果
* @retval		所有电芯的均衡位置
* @warning
*/
uint16_t* passive_balance_pos_get(void)
{
    return gp_cell_bal_pos;
}

/**
* @brief		电芯电压当前时刻与满充时刻的间距获取
* @param		uint8_t *p_chg_ending_index 充电结束时刻
* @param		uint8_t *p_vol_now_index    电压当前时刻
* @param		uint8_t *p_distance 间距
* @return		返回结果 是否获取成功
* @retval		获取成功：RUNNING_OK:(1)  运行失败：RUNNING_FAIL(0)
* @warning
*/
static bool full_chg_moment_distance_get(uint8_t *p_chg_ending_index , uint8_t *p_vol_now_index , uint8_t *p_distance)
{
    bool ret_flag =  RUNNING_FAIL;

   if ((NULL == p_chg_ending_index)||
       (NULL == p_distance) ||
       (NULL == p_vol_now_index) ||
       ((*p_chg_ending_index) > (*p_vol_now_index)))
   {
       log_e("CellBalFullMomentGetErr\n");
       ret_flag =  RUNNING_FAIL;
   }
   else
   {
       //(*p_distance) = ((*p_vol_now_index) - (*p_chg_ending_index) -  1);     //5S以后电压当前时刻的下标一直都是SLIDING_FILTER_5S_BASED_1S
       (*p_distance) = ((*p_vol_now_index) - (*p_chg_ending_index));     //5S以后电压当前时刻的下标一直都是SLIDING_FILTER_5S_BASED_1S
        ret_flag   =  RUNNING_OK;
   }
    return ret_flag;
}

/**
* @brief		允许查均衡校准表的条件判断
* @param		int16_t cell_avg_temp 电芯平均温度
* @param		scroll_record_data_t 滚动记录的数据值
* @param		uint8_t *p_full_moment_distance 充电结束时刻与当前时刻的间距
* @param		uint8_t *p_curr_now_index 电流当前时刻
* @return		返回结果
* @retval		运行失败 ：RUNNING_FAIL(0)  允许查表:CHECK_TAB_PERMIT(1)   禁止查表: CHECK_TAB_FORBID(-1)
* @warning
*/
static int8_t balance_check_tab_condition_permit(int16_t cell_avg_temp, scroll_record_data_t *p_scroll_record_data, uint8_t *p_full_moment_distance, uint8_t *p_curr_now_index)
{

    int8_t   ret =  CHECK_TAB_FORBID;
    uint8_t i = 0, j = 0;

    if ((NULL == p_scroll_record_data) ||
        (NULL == p_full_moment_distance)||
        (NULL == p_curr_now_index) ||
        (cell_avg_temp > PASSIVE_BALANCE_CELL_TEMP_MAX)||
        (cell_avg_temp < PASSIVE_BALANCE_CELL_TEMP_MIN) ||
        ((*p_curr_now_index) < (*p_full_moment_distance)))          // 入参判断
    {
        log_e("CellBalCheckTabConditionErr!\n");
        ret = RUNNING_FAIL;
    }
    else
    {
         // 查表条件判断： 充电结束时刻及之前的时刻电流值在[0, 0.6C]内  且 电芯平均温度 >= 10℃
        //for (i = 0; i < ((*p_curr_now_index) - (*p_full_moment_distance) + 1); i++)
        for (i = 0; i <= ((*p_curr_now_index) - (*p_full_moment_distance)); i++)
        {
            if (((p_scroll_record_data->sys_curr[i]) >= BALANCE_TAB_CURR_DOWN_LIMIT)&&
                (p_scroll_record_data->sys_curr[i] <= BALANCE_TAB_CURR_UP_LIMIT))
            {
                j++;
            }
        }
        if ((j >= ((*p_curr_now_index) - (*p_full_moment_distance) - 5)) &&
            (cell_avg_temp >= PASSIVE_BALANCE_CELL_AVG_TEMP))        //充电结束时刻之前的时刻所对应的电流值 及电芯温度  满足条件
        {
            ret =  CHECK_TAB_PERMIT;
        }
        else
        {
            ret =  CHECK_TAB_FORBID;
        }

        #ifdef PASSIVE_BAL_TIME_CALC_DEBUG
        log_e("bmu_passive_check_tab_condition_permit_data: \r\n");
        log_e("curr_now_index:%d\r\n",*p_curr_now_index);
        log_e("full_moment_distance:%d\r\n",*p_full_moment_distance);
        log_e("cell_avg_temp:%d\r\n", cell_avg_temp);
        log_e("sys_curr_count:%d\r\n", j);
        for (uint8_t i = 0; i < ((*p_curr_now_index) - (*p_full_moment_distance)); i++)
        {
            log_e("cell_sys_curr[%d]:%d\r\n",i,p_scroll_record_data->sys_curr[i]);
        }
        #endif
    }
    return ret;
}

/**
* @brief		理论被动均衡时间计算
* @param		passive_balance_bat_data_t *balance_bat_data,被动均衡计算需要的数据
* @param		int32_t *cell_soc, 各电芯查表得到的SOC
* @param		int32_t *cell_balance_time 计算出的电芯理论均衡时间
* @param		 uint16_t cell_num  电芯数量
* @return		返回结果
* @retval		运行失败:RUNNING_FAIL(0)  RUNNING_OK：运行成功(1)  参数超出正常范围:PARA_ERROR(-2)
* @warning
*/
static int32_t passive_balance_time_calc(balance_bat_data_t *p_balance_bat_data, int32_t *p_cell_soc, int32_t *p_cell_balance_time, uint16_t cell_num,uint16_t min_check_soc)
{

    //找出最小电芯SOC， 计算第N颗电芯的理论均衡时间 若均衡时间小于10分钟， 视作均衡时间为0
    uint8_t cell_soc_count = 0;
    int32_t min_cell_soc_tmp = 0;
    int32_t rate_cap = 0;  // 额定容量
    int32_t bat_soh = 0;   // SOH
    int32_t cell_balance_curr = 0; //被动均衡电流
    int32_t ret =  RUNNING_FAIL;

    if ((NULL == p_balance_bat_data ) ||          //入参判断
        (NULL == p_cell_soc) ||
        (NULL == p_cell_balance_time) ||
        (0 == cell_num))
    {
        log_e("CellBalTimeCalcErr\n");
        ret = RUNNING_FAIL;
    }
    else
    {
        //找出最小电芯SOC 分辨率0.01%
        min_cell_soc_tmp = min_check_soc;

        bat_soh =  p_balance_bat_data->bat_soh; //获取SOH  分辨率0.1%，1000  统一变量类型进行计算
        cell_balance_curr = g_bms_attr_type.cell_bal_curr; // 被动均衡电流 单位mA
        rate_cap =  (int32_t)g_bms_attr_type.rate_cap; //统一变量类型进行计算 uint16_t -> int32_t


       // 外部变量做范围判断 SOH  被动均衡电流  额定容量
       if ((bat_soh > PASSIVE_BALANCE_SOH_MAX_VAL) ||
           (bat_soh <= PASSIVE_BALANCE_SOH_MIN_VAL)||
            (rate_cap >  PASSIVE_BALANCE_RATE_CAP_MAX)        ||
            (rate_cap < PASSIVE_BALANCE_RATE_CAP_MIN)       ||
            (cell_balance_curr > PASSIVE_BALANCE_CURR_MAX)||
            (cell_balance_curr < PASSIVE_BALANCE_CURR_MIN))
       {
           ret =  PARA_ERROR;
       }
       else
       {
           // 计算所有电芯计算理论均衡时间   额定容量单位0.1AH 转换成mAS 要 *360 * 1000
            while(cell_soc_count < cell_num)
            {
                p_cell_balance_time[cell_soc_count] = (((((p_cell_soc[cell_soc_count] - min_cell_soc_tmp) * bat_soh * rate_cap / 10000) * 36)
                                                        / (10 * cell_balance_curr)) * 10  * 9 );
                // 若均衡时间小于10分钟， 视作均衡时间为0
                if ((p_cell_balance_time[cell_soc_count] <= PASSIVE_BALANCE_TIME_MIN_VAL))
                {
                    p_cell_balance_time[cell_soc_count] = 0;
                }
                cell_soc_count++;
            }
            ret = RUNNING_OK;
       }
    }
    return ret;

}

/**
* @brief		充电结束时刻的查询及当前时刻与充电结束时刻间距的计算
* @param		void
* @return		返回结果 是否运行成功
* @retval		运行失败： RUNNING_FAIL(0) 运行成功: RUNNING_OK(1)
* @warning
*/
static int32_t full_chg_moment_distance_check(void)
{
    int32_t ret =  RUNNING_FAIL;
    bool full_chg_check_flag = RUNNING_FAIL;      // 满充时刻查询标志
    bool distance_get_flag = RUNNING_FAIL;      // 满充时刻与当前时刻间距查询标志

    /**********************************充电结束时刻的查询*********************************/
        //找出充电结束时刻， 并记录充电结束时刻的数据, 进行均衡校准表查表条件判定
        full_chg_check_flag = full_chg_moment_check(g_bms_attr_type.cell_num, &g_scroll_record_data, &g_chg_ending_index);

        if (RUNNING_FAIL == full_chg_check_flag)
        {
            ret = RUNNING_FAIL;
        }
        else
        {
             // 利用电压当前时刻与满充时刻的间距 去找到电流当前时刻与满充时刻的间距。
            distance_get_flag = full_chg_moment_distance_get(&g_chg_ending_index,&g_enter_proc_vol_index,&g_full_moment_distance);

            if (RUNNING_FAIL == distance_get_flag)
            {
                ret =  RUNNING_FAIL;
            }
            else
            {
              ret =  RUNNING_OK;
            }
        }
        return ret;
}


/**
* @brief		记录充电结束时刻数据并判断查均衡校准表条件 查表计算SOC 计算理论均衡时间
* @param		void
* @return		返回结果 是否运行成功
* @retval		运行失败: RUNNING_FAIL(0)  运行成功: RUNNING_OK(1)
* @warning
*/
static bool balance_time_calc_proc(void)
{
    // 利用充电结束时刻数据 和实时电芯平均温度线性插值查表电芯SOC
       uint8_t  m = 0;
       bool record_full_data_flag = RUNNING_FAIL;
       int8_t check_tab_permit_flag = 0;
       int32_t cell_soc_tab_flag = RUNNING_FAIL;
       bool ret = RUNNING_FAIL;

       record_full_data_flag = record_full_chg_data(g_bms_attr_type.cell_num, &g_scroll_record_data,&g_full_chg_data, g_chg_ending_index, (g_enter_proc_curr_index - g_full_moment_distance));

       if (RUNNING_FAIL == record_full_data_flag)
       {

            ret =  RUNNING_FAIL;
            return ret;
       }
       else if (RUNNING_OK == record_full_data_flag)  //正常记录满充数据
       {
           //查询实时48个电芯温度
           for (m = 0; m < g_bms_attr_type.cell_num; m++)
           {
               g_cell_temp[m] = g_balance_bat_data.cell_temp[m];
           }
       }

       // 判断查表条件是否满足：充电结束时刻附近1min电流 在[0，0.6C]内，且电芯平均温度>=10℃。
       check_tab_permit_flag = balance_check_tab_condition_permit(g_balance_bat_data.cell_avg_temp, &g_scroll_record_data, &g_full_moment_distance,&g_enter_proc_curr_index);

       if (RUNNING_FAIL == check_tab_permit_flag)        //指针为空
       {
            ret =  RUNNING_FAIL;
            return ret;
       }
       else if (CHECK_TAB_PERMIT == check_tab_permit_flag)    // 允许查表
       {
           // 利用查表得到的各电芯SOC
           cell_soc_tab_flag = balance_cell_soc_tab_check(g_cell_temp, g_full_chg_data.chg_curr, g_full_chg_data.cell_vol, g_bms_attr_type.cell_vol_num , g_cell_soc);

           if (RUNNING_FAIL == cell_soc_tab_flag)
           {
               ret =  RUNNING_FAIL;
               return ret;
           }
            g_data_status.min_cell_soc = min_cell_soc_get(g_cell_soc, g_bms_attr_type.cell_num);  // 记录最小电芯SOC
            g_data_status.bmu_data_ready_flag = true;  // 均衡数据准备就绪
            g_data_status.bmu_data_ready_cnt = BMU_DATA_RDY_SEND_TIME_BASED_1S;  // BMU均衡数据准备就绪计数
            g_data_status.bmus_data_ready_wating_cnt = BMUS_DATA_WATING_TIME_BASED_1S;
			g_data_status.bmus_data_ready_flag = false;

           ret = RUNNING_OK;
       }
       else if (CHECK_TAB_FORBID == check_tab_permit_flag)  //不允许查表
       {
           log_e("CellBalForbidCheckTab!\n");
           #ifdef CELL_BAL_DEBUG
           log_e("CellAvgTemp:%d\n",g_balance_bat_data.cell_avg_temp);
           for(uint8_t i = 0; i < 60; i++)
           {
               log_e("I[%d]:%d\n",i,g_scroll_record_data.sys_curr[i]);
           }
           #endif
           ret =  RUNNING_OK;
       }

       return ret;
}
/**
* @brief		均衡开启条件判断
* @param		balance_bat_data_t *p_balance_bat_data,被动均衡计算需要的数据
* @param		uint16_t cell_num  电芯数量
* @return		返回结果 开启条件
* @retval		开启成功:PASSIVE_BAL_PERMIT(1)   开启失败:PASSIVE_BAL_FORBID(-1)   运行失败: RUNNING_FAIL(0)
* @warning
*/
static int32_t passive_balance_start_permit(balance_bat_data_t *p_balance_bat_data, uint16_t cell_num)
{
    static uint8_t time_count = 0;     // 20S 时间计数
    uint8_t i = 0;
    uint16_t balance_vol_diff = 0;    // 均衡开启压差
    int32_t ret = PASSIVE_BAL_FORBID;     // 返回标志
    bool bal_pos_all_zero = true;     // 没有需要均衡的电芯
    bool now_empty_dsg_flag = EMPTY_DSG_CLEAR;   //放空标志获取返回值

    if ((NULL == p_balance_bat_data) ||
        (0 == cell_num))
    {
        ret = RUNNING_FAIL;
        return ret;
    }
    else
    {
        // 获取均衡开启压差
        balance_vol_diff = g_bms_attr_type.balance_vol_diff;
        now_empty_dsg_flag = g_balance_public_if_remap.balance_empty_dsg_flag_get_cb();


        // 有永久性故障或充放电保护或放电电流大于1A 或最低单体电压低于3000mV 或触发被动均衡相关故障 不启动均衡  或外部给的禁止均衡指令
        if ( (fault_state_get(BOARD_BAL_TEMP_SAM_ABNORMAL_ALARM)) ||
             (fault_state_get(BOARD_BAL_TEMP_OVER_ALARM)) ||
             (p_balance_bat_data->max_chg_level < PASSIVE_BALANCE_LEVEL2) ||
             (p_balance_bat_data->max_dischg_level < PASSIVE_BALANCE_LEVEL2) ||
             (p_balance_bat_data->sys_curr < PASSIVE_BALANCE_SYS_DSG_CURR) ||
             (p_balance_bat_data->min_cell_vol < PASSIVE_BALANCE_MIN_CELL_VOL) ||
             (EMPTY_DSG_SET == now_empty_dsg_flag))
        {
            time_count = 0;

            memset(gp_cell_bal_pos,0,sizeof(gp_cell_bal_pos));
            g_passive_balance_if_remap.passive_balance_pos_set_cb(gp_cell_bal_pos);
            ret = PASSIVE_BAL_FORBID;

            // if (EMPTY_DSG_SET == now_empty_dsg_flag)
            // {
            //     memset(&g_cell_balance_time, 0, sizeof(g_cell_balance_time));
            // }
        }
        // 无保护故障和放电电流 且放电电流 >= -1A 且最低单体电压大于3000mV  且外部给的均衡禁止解除
        else if ((p_balance_bat_data->max_chg_level >= PASSIVE_BALANCE_LEVEL2) &&
                  (p_balance_bat_data->max_dischg_level >=  PASSIVE_BALANCE_LEVEL2)  &&
                  (p_balance_bat_data->sys_curr >=  PASSIVE_BALANCE_SYS_DSG_CURR) &&
                  (p_balance_bat_data->min_cell_vol >= PASSIVE_BALANCE_MIN_CELL_VOL))
        {
            // 若到20S 基于均衡开启条件计算出均衡指令(位置) 传递给AFE
            if (time_count >= BALANCE_CYCLE_20S_BASED_1S)   // 满足AFE均衡周期20S
            {
                time_count = 0;

                //判断是否满足均衡条件
                for(i = 0; i < BAL_CELL_NUM; i++)
                {
                    //满足均衡条件 均衡位置置位
                    if ((p_balance_bat_data->cell_vol[i] >= p_balance_bat_data->min_cell_vol +  balance_vol_diff) ||
                        ((g_cell_balance_time[i] >= PASSIVE_BALANCE_TIME_MIN_VAL) &&
                        (g_full_chg_data.cell_vol[i] >= g_full_chg_data.min_cell_vol) &&
                        ((true == g_data_status.bmus_data_ready_flag))))
                    {
                        gp_cell_bal_pos[i/AFE_CELL_VOLT_NUM] |= (uint32_t)(0x01 << (i%AFE_CELL_VOLT_NUM));

                    }
                    // 不满足均衡条件 均衡位置0
                    else if ((p_balance_bat_data->cell_vol[i]  <   p_balance_bat_data->min_cell_vol + balance_vol_diff) &&
                             (g_cell_balance_time[i] < PASSIVE_BALANCE_TIME_MIN_VAL))
                    {
                        gp_cell_bal_pos[i/AFE_CELL_VOLT_NUM] &= (uint32_t)(~(0x01 << (i%AFE_CELL_VOLT_NUM)));
                    }
                }

                for (i = 0; i<AFE_NUM; i++)
                {
                    if ((uint16_t)0U != gp_cell_bal_pos[i])
                    {
                        bal_pos_all_zero = false;
                        break;
                    }
                }

                // 得出均衡位置为0 则返回
                if (true == bal_pos_all_zero)
                {
                    //设置均衡位置传递给AFE
                    g_passive_balance_if_remap.passive_balance_pos_set_cb(gp_cell_bal_pos);
                   // 均衡时间清0
                    memset(&g_cell_balance_time, 0, sizeof(g_cell_balance_time));
                    ret =  PASSIVE_BAL_FORBID;

                }
                else // 均衡位置不全为0 则设置给AFE
                {
                     g_passive_balance_if_remap.passive_balance_pos_set_cb(gp_cell_bal_pos);
                     ret =  PASSIVE_BAL_PERMIT;
                }

            }
            //未到20S
            else
            {
                time_count++;
                ret =  PASSIVE_BAL_FORBID;
            }
        }
    }
    return ret;
}

// 辅助函数：调整均衡时间
static void adjust_balance_time(uint16_t index, uint16_t subtract)
{
    if (g_cell_balance_time[index] <= PASSIVE_BALANCE_TIME_MIN_VAL) {
        g_cell_balance_time[index] = 0;
    } else {
        g_cell_balance_time[index] -= subtract;
    }
}

/**
* @brief		均衡时间更新
* @param		uint16_t cell_num 电芯数量
* @return		返回结果
* @retval		RUNNING_FAIL: 运行失败  RUNNING_OK: 运行成功
* @warning
*/
static int8_t balance_time_renew(uint16_t cell_num)
{
     uint8_t odd_number_flag[AFE_NUM] = {0};      //奇数位置标志
     uint8_t even_number_flag[AFE_NUM] = {0};     //偶数位置标志

     if (0 == cell_num)
     {
         return RUNNING_FAIL;
     }


    
    for (uint8_t i = 0; i < cell_num; i++)
    {
        if (!(gp_cell_bal_pos[i/AFE_CELL_VOLT_NUM] &(1UL << (i%AFE_CELL_VOLT_NUM))))    //对未开启均衡位置进行计数
        {
            if (i % 2 == 0) // 奇数位置（索引0,2,4...）
            {
                odd_number_flag[i/AFE_CELL_VOLT_NUM]++;
            }
            else           // 偶数位置（索引1,3,5...）
            {
                even_number_flag[i/AFE_CELL_VOLT_NUM]++;
            }            
        }
    }
    
    // 计算奇偶位置总数(考虑电芯个数有可能是奇或偶，故奇数位置+1)
    uint16_t total_odd = (cell_num + 1) / 2; // 奇数位置总数
    uint16_t total_even = cell_num / 2;      // 偶数位置总数

    // 判断是否需要全奇数或全偶数处理
    uint16_t subtract_full = BALANCE_CYCLE_20S_BASED_1S;
    uint16_t subtract_half = BALANCE_CYCLE_20S_BASED_1S / 2;

    
    for (uint8_t i = 0; i < AFE_NUM; i++)   //每个afe都是独立均衡的，所以需要分别判断每个afe是否只有奇/偶/奇偶均衡
    {
        if (odd_number_flag[i] ==  total_odd / AFE_NUM)                // 奇数均衡位均为0 只有偶数位置均衡 减去偶数位置均衡时间 20S
         {
              for (uint8_t j = 1; j < AFE_CELL_VOLT_NUM; j += 2)
              {                  
                  adjust_balance_time(j + i*AFE_CELL_VOLT_NUM, subtract_full);
              }

         }
         else if (even_number_flag[i] == total_even / AFE_NUM)             // 偶数均衡位置均为0  只有奇数位置均衡 减去奇数位置均衡时间 20S
         {
             for (uint8_t j = 0; j < AFE_CELL_VOLT_NUM; j += 2)
              {                  
                  adjust_balance_time(i, subtract_full);
              }
         }
         else                                                       // 奇偶位置都有 均衡时间各减一半 10S
         {
             for (uint8_t j = 0; j < AFE_CELL_VOLT_NUM; j++)
              {
                  adjust_balance_time(j + i*AFE_CELL_VOLT_NUM, subtract_half);
              }

         }            
    }



    return RUNNING_OK;
}

/**
* @brief		均衡开启逻辑流程
* @param		void
* @return		返回结果 是否运行成功
* @retval		运行失败:RUNNING_FAIL (0)  运行成功：RUNNING_OK (1)
* @warning
*/
static int8_t balance_start_proc(void)
{
    /**********************被动均衡开启逻辑流程*********************/
   // 判断均衡开启条件
    int8_t ret = RUNNING_FAIL;
    int8_t bal_time_renew_flag =  RUNNING_FAIL;
    int8_t balance_permit_now_flag = PASSIVE_BAL_FORBID;         //当前时刻均衡允许标志位
    static int8_t balance_permit_last_flag = PASSIVE_BAL_FORBID; //上一时刻均衡允许标志位
    balance_permit_now_flag = passive_balance_start_permit(&g_balance_bat_data,g_bms_attr_type.cell_num);

    //触发流程异常打印
    if (RUNNING_FAIL == balance_permit_now_flag)
    {
        if(RUNNING_FAIL != balance_permit_last_flag)
        {
            log_e("CellBalStartProcErr!\n");
        }
        balance_permit_last_flag = balance_permit_now_flag;
        ret =  RUNNING_FAIL;
    }
    else if (PASSIVE_BAL_PERMIT == balance_permit_now_flag) /*开启被动均衡成功*/
    {
         // 刷新均衡时间
          bal_time_renew_flag = balance_time_renew(g_bms_attr_type.cell_num);
         if (RUNNING_FAIL == bal_time_renew_flag)
         {
                ret =  RUNNING_FAIL;
         }
         else
         {
              ret = RUNNING_OK;
         }

    }
    else                                              /*未开启被动均衡*/
    {
        ret = RUNNING_OK;
    }

    //恢复正常流程触发打印
    if ((RUNNING_FAIL == balance_permit_last_flag) &&
        (RUNNING_FAIL != balance_permit_now_flag))
    {
         #ifdef CELL_BAL_DEBUG
         log_e("CellBalStartProcOk!\n");
         #endif
    }
    balance_permit_last_flag = balance_permit_now_flag;
    return ret;

}

/**
* @brief		BMU满充判断
* @param		void
* @return		返回结果 是否满充
* @retval		检测到满充： true;  未检测到满充:false
* @warning
*/
bool bmu_is_full_chg_check(void)
{

    bool   now_full_chg_flag = FULL_CHG_CLEAR;          // 当前时刻满充标志
    bool   ret = false;
    static uint8_t duration_time = 0;                   // 满充持续时间
    static  bool  last_full_chg_flag =  FULL_CHG_CLEAR; // 上一时刻满充标志

    //捕捉满充标志位上升沿,  满充标志位满10S清除。
    now_full_chg_flag = g_balance_public_if_remap.balance_full_chg_flag_get_cb();

    // 捕捉到满充标志/上升沿
    if ((FULL_CHG_SET == now_full_chg_flag) &&
        (FULL_CHG_CLEAR == last_full_chg_flag))
    {
         duration_time = PASSIVE_BAL_FULL_CHG_10S;
    }
    last_full_chg_flag =  now_full_chg_flag; // 当前时刻赋值上一时刻

    if (duration_time > 0)
    {
        duration_time--;
        ret = true;
    }
    else
    {
        ret = false;
    }

    return ret;
}

/**
* @brief		全局变量重置
* @param		void
* @return		返回结果
* @retval		void
* @warning
*/
static void  global_var_reset(void)
{

    memset(&g_balance_bat_data, 0, sizeof(g_balance_bat_data)) ;                 // 均衡需要的电池数据
    memset(&g_scroll_record_data, 0, sizeof(g_scroll_record_data)) ;             //  滚动记录的数据:电芯电压 电流
    memset(&g_full_chg_data, 0, sizeof(g_full_chg_data)) ;                       //  充电结束时刻的数据
    g_enter_proc_vol_index = 0;                                                  //滑窗电压指针 1S一次 5S以后保持在SLIDING_FILTER_5S_BASED_1S
    g_enter_proc_curr_index = 0;                                                 //滑窗电流指针 1S一次 60S以后保持在SLIDING_FILTER_60S_BASED_1S
    g_chg_ending_index = 0;                                                      //充电结束时刻
    memset(g_cell_temp, 0, sizeof(g_cell_temp)) ;                                //电芯温度
    memset(g_cell_soc, 0, sizeof(g_cell_soc)) ;                                 //各电芯SOC
    memset(g_cell_balance_time, 0, sizeof(g_cell_balance_time)) ;               // 各电芯均衡时间
    g_full_moment_distance = 0;                                                // 满充时刻与当前时刻的间距
    memset(gp_cell_bal_pos,0,sizeof(gp_cell_bal_pos));                          //被动均衡位置清零                                                    // 被动均衡位置
}

/**
* @brief		获取BMU均衡数据准备状态
* @param		void
* @return		返回BMU均衡数据准备状态
* @retval		bool
* @warning
*/
bool  bmu_data_status_get(void)
{
    return g_data_status.bmu_data_ready_flag;
}

/**
* @brief		获取BMU最小电芯SOC
* @param		void
* @return		返回BMU最小电芯SOC
* @retval		int16_t
* @warning
*/
uint16_t  bmu_min_cell_soc_get(void)
{
    return g_data_status.min_cell_soc;
}

/**
* @brief		刷新BCU均衡数据准备状态
* @param		void
* @return		返回BCU均衡数据准备状态
* @retval		bool
* @warning
*/
static void bmu_data_status_refresh(void)
{
	static bool bcu_data_ready_last_flag = false;

	//如果触发所有BMU均衡数据准备就绪，就置起所有BMU数据准备就绪标志
	if ((false == bcu_data_ready_last_flag)
	&& (true ==g_passive_balance_if_remap.passive_bal_bmus_data_status_get_cb()))
	{
        g_data_status.bmus_data_ready_flag = true;
	}

	bcu_data_ready_last_flag = g_passive_balance_if_remap.passive_bal_bmus_data_status_get_cb();

    //本BMU均衡数据准备就绪计数
    if (g_data_status.bmu_data_ready_cnt > 0)
    {
        g_data_status.bmu_data_ready_cnt--;
    }
    else if (0 == g_data_status.bmu_data_ready_cnt)
    {
        g_data_status.bmu_data_ready_flag = false;
    }

    //等待BCU下发所有BMU数据准备就绪标志，等待20秒
    if (g_data_status.bmus_data_ready_wating_cnt > 0)
    {
        g_data_status.bmus_data_ready_wating_cnt--;
    }

}

/**
* @brief		被动均衡线程 每1S执行一次
* @param		无
* @return		返回结果
* @retval		无
* @warning		在均衡初始化之后调用
*/
void bmu_passive_balance_proc(void)
{
    int32_t full_chg_moment_flag = RUNNING_FAIL;      // 充电结束时刻函数返回值
    bool now_full_chg_flag = FULL_CHG_CLEAR;          //当前时刻满充标志获取返回值
    static bool last_full_chg_flag = FULL_CHG_CLEAR;  // 上一时刻满充标志获取返回值
    bool bat_data_now_flag = RUNNING_FAIL;            //当前时刻电池数据获取返回值
    static bool bat_data_last_flag = RUNNING_FAIL;    //上一时刻电池数据获取返回值
    bool scroll_record_now_flag = RUNNING_FAIL;       //当前时刻滑窗记录函数返回值
    static bool scroll_record_last_flag = RUNNING_FAIL; //上一时刻滑窗记录的返回值
    bool pass_bal_time_calc_proc_flag = RUNNING_FAIL; //被动均衡理论计算时间流程函数返回值
    bool pass_bal_start_proc_now_flag = RUNNING_FAIL;     // 当前时刻被动均衡是否开启流程函数返回值
    static bool pass_bal_start_proc_last_flag = RUNNING_FAIL; //上一时刻被动均衡是否开启流程函数返回值
    bool pass_bal_forbid_flag = false;                //被动均衡禁能标志(屏蔽均衡功能)
    uint8_t bms_sta = 0;
    uint16_t min_cell_check_soc = 0;

    /**********************被动均衡功能屏蔽(主要用于ATE测试)*********************/
    pass_bal_forbid_flag = g_passive_balance_if_remap.passive_bal_forbid_flag_get_cb();

     if(pass_bal_forbid_flag)
     {
         global_var_reset(); //全局变量重置
         g_passive_balance_if_remap.passive_balance_pos_set_cb(gp_cell_bal_pos);//关闭AFE均衡
         return;
     }

    /**********************电池数据获取*********************/
    bat_data_now_flag = g_balance_public_if_remap.balance_bat_data_get_cb(&g_balance_bat_data);
    bms_sta =  bms_state_get_sys_sta();
     //触发数据异常关闭均衡 并打印数据
    if ((RUNNING_OK == bat_data_last_flag) &&
        (RUNNING_FAIL == bat_data_now_flag) &&
        (BMS_STATE_SHUT_DOWN != bms_sta))
    {
        memset(gp_cell_bal_pos,0,sizeof(gp_cell_bal_pos));
        memset(g_cell_balance_time, 0, sizeof(g_cell_balance_time));
        g_passive_balance_if_remap.passive_balance_pos_set_cb(gp_cell_bal_pos);//关闭AFE均衡

        log_e("CellBalDataErr\n");
        log_e("Soh:%d,BcuI:%d,CellAvgTemp:%d,MaxV:%d,MinV:%d,ChgL:%d,DsgL:%d,I:%d\n",g_balance_bat_data.bat_soh,
               g_balance_bat_data.bcu_curr,g_balance_bat_data.cell_avg_temp,g_balance_bat_data.max_cell_vol,g_balance_bat_data.min_cell_vol,
               g_balance_bat_data.max_chg_level,g_balance_bat_data.max_dischg_level,g_balance_bat_data.sys_curr);

//        for(uint8_t i = 0; i < BAL_CELL_NUM; i++)
//        {
//            log_e("CellV[%d]:%d CellT[%d]:%d \n",i,g_balance_bat_data.cell_vol[i],i,g_balance_bat_data.cell_temp[i]);
//        }
    }
    //数据恢复正常触发打印
    else if ((RUNNING_FAIL == bat_data_last_flag) &&
             (RUNNING_OK == bat_data_now_flag))
    {
          #ifdef CELL_BAL_DEBUG
          log_e("CellBalDataOk!\n");
          #endif
    }
    bat_data_last_flag = bat_data_now_flag;

    if (RUNNING_FAIL == bat_data_last_flag)
    {
       return;
    }

    /**********************滑窗记录数据*********************/

    //滚动记录电芯电压和电流数据 1S线程进一次保存一组数据
    scroll_record_now_flag =  sliding_filter_record_bat_data(g_bms_attr_type.cell_num,&g_enter_proc_vol_index,&g_enter_proc_curr_index,&g_scroll_record_data,&g_balance_bat_data);

    //触发数据异常 打印数据
    if (RUNNING_FAIL == scroll_record_now_flag)
    {
        if (RUNNING_OK == scroll_record_last_flag)
        {
           log_e("CellBalSlidDataErr\n");
           for(uint8_t i = 0; i < SLIDING_FILTER_60S_BASED_1S; i++)
           {
               log_e("I[%d]:%d ",i,g_scroll_record_data.sys_curr);
           }
           for(uint8_t j = 0; j < SLIDING_FILTER_5S_BASED_1S; j++)
           {
               for(uint8_t k = 0; k < BAL_CELL_NUM; k++)
               {
                   log_e("CellV[%d][%d]:%d \n",j,k,g_scroll_record_data.cell_vol[j][k]);
               }
           }
        }
    }
    //数据恢复正常触发打印
    else if ((RUNNING_FAIL == scroll_record_last_flag) &&
        (RUNNING_OK == scroll_record_now_flag))
    {
        #ifdef CELL_BAL_DEBUG
        log_e("CellBalSlidDataOk\n");
        #endif
    }
    scroll_record_last_flag = scroll_record_now_flag;

    if (RUNNING_FAIL == scroll_record_last_flag)
    {
        return;
    }


    /*****************触发式判断是否检测到满充标志上升沿***************/
     now_full_chg_flag = g_balance_public_if_remap.balance_full_chg_flag_get_cb();

    if ((FULL_CHG_SET == now_full_chg_flag) &&
        (FULL_CHG_CLEAR == last_full_chg_flag))     // 检测到满充标志上升沿
    {
         /*****充电结束时刻的查询*****/
         full_chg_moment_flag = full_chg_moment_distance_check();

         if (RUNNING_FAIL == full_chg_moment_flag)
         {
             log_e("CellBalFullMomentErr\n");
             return;
         }
        /*****理论均衡计算时间流程*****/
         pass_bal_time_calc_proc_flag = balance_time_calc_proc();

         if (RUNNING_FAIL == pass_bal_time_calc_proc_flag)
         {
             log_e("CellBalTimeCalcErr\n");
             return;
         }
    }
    last_full_chg_flag = now_full_chg_flag; // 当前时刻满充标志赋值给上一时刻

    /**********************判断此电池簇中其余BMU的被动均衡数据准备状态*********************/
    if (g_data_status.bmus_data_ready_wating_cnt > 0)
    {
        if (true ==g_data_status.bmus_data_ready_flag)
        {
            min_cell_check_soc = g_passive_balance_if_remap.passive_bal_min_check_soc_get_cb();
            if (0xFFFF != min_cell_check_soc)
            {
                //根据查表SOC 计算理论均衡时间
                passive_balance_time_calc(&g_balance_bat_data, g_cell_soc, g_cell_balance_time, g_bms_attr_type.cell_num, min_cell_check_soc);

			    g_data_status.bmus_data_ready_wating_cnt = 0;
            }
        }
    }

    /**********************刷新BCU被动均衡数据准备状态*********************/
	bmu_data_status_refresh();

   /*****被动均衡开启逻辑流程*****/
    pass_bal_start_proc_now_flag = balance_start_proc();

    //触发数据异常打印
    if ((RUNNING_FAIL == pass_bal_start_proc_now_flag) &&
        (RUNNING_OK == pass_bal_start_proc_last_flag))
    {
            log_e("CellBalStartProcErr\n");
    }
    //恢复正常触发打印
    else if ((RUNNING_OK == pass_bal_start_proc_now_flag) &&
        (RUNNING_FAIL == pass_bal_start_proc_last_flag))
    {
        #ifdef CELL_BAL_DEBUG
        log_e("CellBalStartProcOk!\n");
        #endif
    }
    pass_bal_start_proc_last_flag =  pass_bal_start_proc_now_flag;

}

/**
 * @brief                被动均衡线程 每1S执行一次
 * @param                [in]void
 * @warning              cell_balance_init()之后调用，1S周期调用次函数
 */
void cell_balance_proc(void)
{
   if (true == sdk_is_tick_over(g_init_tick, 1000))
   {
        g_init_tick = sdk_tick_get();
        #if CELL_BALANCE_SELF_CHECK_TEST
                if (g_cell_balance_self_check_flag)
                {
                    return;
                }
        #endif

        #ifdef CELL_BALANCE_SHELL_DEBUG_TEST
                if (g_cell_balance_shell_debug_flag)
                {
                    return;
                }
        #endif
        if (special_mode_get(ATUO_TEST))
        {
            return;
        }

        if (!g_cell_balance_init_flag)
        {
            cell_balance_init();
            return;
        }

        if (fault_state_get(BOARD_BAL_TEMP_OVER_ALARM) ||
            fault_state_get(BOARD_BAL_TEMP_SAM_ABNORMAL_ALARM) ||
            BMS_STATE_RUN != bms_state_get_sys_sta())
        {
            for (int8_t i = 0; i < AFE_NUM; i++)
            {
                afe_balance_set((stack_board_name_e)i,(uint32_t)0);
            }
        }

        bmu_passive_balance_proc();
   }
}


/**
* @brief        满充时刻数据获取
* @param        [input]cell_num 电芯数量
* @param        [input]p_cell_vol电芯电压 单位mV
* @param        [input]p_chg_ending_index 充电结束时刻下标志
* @return        是否获取成功
* @retval        true:成功  false: 失败
* @warning
*/
bool cell_full_chg_data_get(uint16_t cell_num, uint16_t *p_cell_vol, uint8_t *p_chg_ending_index)
{
   #ifdef CELL_BALANCE_SHELL_DEBUG_TEST
   if (g_cell_balance_shell_debug_flag)
   {
       for (uint8_t i = 0; i < cell_num; i++)
       {
             p_cell_vol[i] = g_full_chg_cell_vol_debug[i];
       }
       (*p_chg_ending_index) = g_full_chg_ending_index_debug;
       return true;
   }
   #endif
   bool full_data_flag = false;
   bool ret = false;
   full_data_flag = passive_balance_full_chg_data_get(cell_num, p_cell_vol, p_chg_ending_index);

   if (full_data_flag == true)
   {
      ret =  true;
   }
   else
   {
      ret = false;
   }
   return ret;
}

/**
* @brief        均衡时间获取
* @param        [input]cell_id(0 ~ 电芯个数-1)
* @return        返回结果单位s
* @retval        单个电芯的均衡时间
* @warning
*/
int32_t cell_balance_time_get(uint32_t cell_id)
{
#ifdef CELL_BALANCE_SHELL_DEBUG_TEST
    if (g_cell_balance_shell_debug_flag)
    {
        return g_cell_balance_timer_debug[cell_id];
    }
#endif
    bool attr_get_flag = false;
    bms_attr_type_t bms_attr_type = {0};
    attr_get_flag = g_balance_public_if_remap.balance_bms_attr_get_cb(&g_bms_attr_type); // 获取BMS属性参数数据

    if ((false == attr_get_flag) ||
        (bms_attr_type.cell_num <= cell_id))
    {
        return 0;
    }
    return passive_balance_time_get(cell_id, bms_attr_type.cell_num);
}

/**
* @brief		均衡位置获取
* @param		无
* @return		返回结果
* @retval		所有电芯的均衡位置
* @warning
*/
uint16_t* cell_balance_pos_get(void)
{
#ifdef CELL_BALANCE_SHELL_DEBUG_TEST
    if (g_cell_balance_shell_debug_flag)
    {
        return g_cell_balance_pos_debug;
    }
#endif
    return passive_balance_pos_get();
}


/**
* @brief		BMU满充判断
* @param		void
* @return		返回结果 是否满充
* @retval		检测到满充： true;  未检测到满充:false
* @warning	   仅由SOX模块调用
*/
bool cell_bal_full_chg_check(void)
{
    bool ret = false;
    bool full_chg_flag = false;
    full_chg_flag = bmu_is_full_chg_check();

    if (true == full_chg_flag)
    {
         ret = true;
    }
    else
    {
         ret = false;
    }
    return ret;
}




















