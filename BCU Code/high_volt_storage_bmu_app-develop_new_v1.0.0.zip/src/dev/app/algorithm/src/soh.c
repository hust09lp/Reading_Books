/**
 * @file         soh_manage.c
 * @brief        电芯级别的SOH计算及校准
 * @details      电芯级别的SOH每日结算，且引入事件、异常的处理机制
 * @author       SOFAR
 * @date         2023/12/13
 * @version      V0.1.0
 * @attention 传入电压精度为--1mV
 * @attention 传入电流精度为--1mA
 * @attention 传入温度精度为--1℃
 * @attention 传入RTC精度为--1s
 * @attention 传入Tick精度为--1ms
 * @attention SOC显示值精度为1%，SOC计算值精度为0.001%
 * @copyright    Copyright(c) 2023 by SofarSolar, All Rights Reserved.
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author    <th>Description
 * <tr><td>2023/12/13  <td>0.1.0    <td>zzc       <td>持续优化，详见git上的更改点
 *
 * </table>
 *
 **********************************************************************************
 */

#include "soc.h"
#include "soh.h"
#include "sox_sample.h"
#include "sox_stats.h"
#include "sox_math.h"
#include "sox_public.h"
#include "sdk.h"
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <time.h>

/************************************************************************/
/*************************SOH内定义的数据结构******************************/
/************************************************************************/
//SOH中用到的表格
//V_target表
#define V_TARGET_LENGTH 7		///< V_target的长度

//温度倍率系数表
#define TEMP_LENGTH 4			///< 温度倍率中的温度长度
#define CUR_LENGTH 4			///< 温度倍率中的电流长度
#define TEMP_RATIO_DIMENTION	///< 温度倍率的维度

//指数表的长度
#define EXPONENT_LENGTH 22		///< 幂指数的长度

//SOH显示值保护时间
#define SOH_VAL_PROTECT_TIME (6*30*24*3600)

//SOH一阶滤波
#define SOH_FIL_COFF 0.05

//SOH允许计算
#define SOH_CALC_PERMIT_VOLT 3320
#define SOH_CALC_PERMIT_TEMP 15
#define SOH_CALC_PERMIT_FLAG_TIME 5

//SOH计算启动条件
#define SOH_CALC_START_CUR (-1000)
#define SOH_CALC_START_DURATION 5

//SOH计算退出条件
#define SOH_CALC_EXIT_CUR 200
#define SOH_CALC_EXIT_CUR_DURATION 2
#define SOH_CALC_EXIT_DURATION_HOURS 24

//SOH临时值计算的限制
#define SOH_TEMP_CALC_FIL_CUR_DIFF 10000
#define SOH_TEMP_CALC_FIL_UPPER_CUR (-0.1f*DEFAULTED_RATED_CAP*1000)
#define SOH_TEMP_CALC_FIL_LOWER_CUR (-0.6f*DEFAULTED_RATED_CAP*1000)
#define SOH_TEMP_CALC_SOC 15
#define SOH_TEMP_CALC_AVG_TEMP 15
#define SOH_TEMP_CALC_TEMP 15

//等效循环圈数获取
#define SOH_CYCLE_STATS_UPPER_CUR 200
#define SOH_CYCLE_STATS_UNDER_CUR (-200)
#define SOH_CYCLE_STATS_RATIO 50

//每日计算时间
#define SOH_DAILY_SETTLE_PERIOD_HOURS 24

//SOH显示
#define SOH_NEW_PACK_CYCLES 50
#define MAX_SOH 100
#define MIN_SOH 50

//SOH圈数计算
#define SOH_STOR_PERIOD (24 * 60 * 60)

//SOC显示上下限
#define NON_FULL_HIGHEST_SOC 99	///< 非满充状态下的最高SOC

/**
  * @enum   soh_cell_flag_u
  * @brief  CELL的SOH标志位类型
  */
typedef union
{
	uint16_t soh_all_flag;
	struct
	{
		uint16_t calc_permit : 1;		///< SOH允许计算标志位
		uint16_t calc_start : 1;		///< SOH计算开始标志位
		uint16_t calc_end : 1;			///< SOH计算结束标志位
		uint16_t first_calc_temp : 1;	///< 每次放电第一次计算SOH临时数据
		uint16_t temp_calc_exist : 1;	///< 有无临时计算结果
	}bit;
}soh_cell_flag_u;

/**
  * @enum   soh_pack_flag_u
  * @brief  PACK的SOH标志位类型
  */
typedef union
{
	uint16_t soh_all_flag;
	struct
	{
		uint16_t init : 1;				///< SOH初始化标志位
		uint16_t proc_init:1;			///< SOH进程初始化标志位
		uint16_t soh_save:1;			///< SOH保存标志位
		uint16_t cell_calc_start:1;		///< 48个电芯SOH计算开始
		uint16_t cell_calc_done:1;		///< 48个电芯SOH计算完成
		uint16_t new_cycle : 1;			///< 每日结算数据开始统计标志位
		uint16_t cycle_calc_inited : 1;	///< 每日循环数据统计标志位
		uint16_t dsg_calc_inited : 1;	///< 放电统计数据标志位
	}bit;
}soh_pack_flag_u;

/**
  * @struct   soh_val_t
  * @brief    SOH计算值、SOH临时计算值、SOH高低精度显示值
  */
typedef struct
{
	int32_t calc;			///< SOH计算值，精度：0.001%
	int32_t temp_calc;		///< SOH临时计算结果，精度：0.001%
	int32_t high_pre;		///< SOH高精度显示值，精度：0.001%
	int16_t low_pre;		///< SOH低精度显示值，精度：1%
}soh_val_t;

/**
  * @struct   soh_pack_cur_t
  * @brief    PACK级--采样数据、由采样数据衍生出的数据
  */
typedef struct
{
	cur_fl_t fl_signal;						///< 滤波后的SOX采样信号，精度：1mA
	int32_t cur_fl_array[_120S_BASE_1S];	///< 保存最近120秒的电流滤波值，精度：1mA
	int16_t cur_fl_array_index;				///< 始终指向下一个需要保存的位置
}soh_pack_cur_t;

/**
  * @struct   soh_pack_calc_para_t
  * @brief    PACK级--SOH计算相关的参数
  */
typedef struct
{
	pack_cycle_storg_stats_t cycle_storg_stats;	///< 等效循环次数计算所需要的数据
	uint32_t cur_under_minus_1A_counter;		///< 电流小于1A的持续时间
	int16_t bat_rated_cap;						///< 电池额定容量
	int16_t cell_calc_index;					///< 当前电芯计算的索引
	uint16_t soh_calc_cnt;						///< SOH计算计数
	sox_bms_status_e pack_shut_last_time;		///< 记录电池上一次的关机状态
	bool pack_shut_raiseup_flag;				///< 捕捉关机信号的上升沿
	bool enforce_refresh;						///< 强制刷新标志
}soh_pack_calc_para_t;

/**
  * @struct   soh_cell_calc_para_t
  * @brief    CELL级--SOH计算相关的参数
  */
typedef struct
{
	int16_t cycles_uncalced;			///< 未被纳入本次SOH计算的等效循环圈数
	int16_t cycles_frac_part;			///< 循环圈数中的小数部分
	uint32_t soh_calc_start_time;		///< SOH计算开始时间
	int16_t v_target_last_time;			///< SOH临时计算值的V_target
	int16_t v_target_this_time;			///< SOH临时计算值的V_target
	int16_t soh_display_upper_limit;	///< SOH最高显示上限
	uint16_t calc_valid_time;			///< 允许标志位有效期为5秒，记录准入标志位的持续时间

	int16_t avg_of_ntc;					///< NTC采样电阻最小值在放电中的平均值
	int32_t dsg_mAh_integral;			///< 放电时的安时积分量
	int32_t ntc_counter;				///< 各电芯的温度计数器
	int32_t ntc_temp_sumed;				///< 放电中各电芯的温度总和
	int32_t mAs_accum;					///< 各电芯的放电mAs积分
	int32_t mAms_accum;					///< 各电芯的放电mAms积分
	uint32_t calc_last_time;			///< 各电芯的上一次积分时间
}soh_cell_calc_para_t;

/**
  * @struct   soh_flow_flag_t
  * @brief    PACK级--记录SOH流程的结构体
  */
typedef union
{
	uint16_t all_flag;
	struct{
		uint16_t cycle_stats : 1;			//等效循环圈数计算相关数据的获取
		uint16_t val_display : 1;			//SOH显示
	}func_flow_flag;
}soh_flow_flag_u;

/************************************************************************/
/*************************PACK级别变量初始化******************************/
/************************************************************************/

/**
  * @struct   sox_sample_data_t
  * @brief    PACK级：SOX用到的采样数据
  */
static sox_sample_data_t g_sox_sample_data = {0};

/**
  * @struct   soh_pack_cur_t
  * @brief    PACK级：SOH用到的的电流采样数据及其衍生数据
  */
static soh_pack_cur_t g_pack_cur = {0};

/**
  * @struct   sox_interface_remap_t
  * @brief    PACK级：外部定制化函数
  */
static sox_interface_remap_t g_sox_interface_remap = {0};

/**
  * @struct   soh_pack_calc_para_t
  * @brief    PACK级：逻辑判断相关的参数
  */
static soh_pack_calc_para_t g_pack_calc_paras = {
	.bat_rated_cap = DEFAULTED_RATED_CAP,			///< 电池额定容量
	.cell_calc_index = 0,			///< 当前电芯计算的索引
	.soh_calc_cnt = 0,				///< SOH计算计数
	.cur_under_minus_1A_counter = 0,///< 电流小于1A的持续时间
	.cycle_storg_stats = {0},		///< 等效循环次数计算所需要的数据
	.enforce_refresh = false,		///< 强制刷新标志
};

/**
  * @struct   soh_pack_flag_u
  * @brief    PACK级：逻辑判断中的标志位
  */
static soh_pack_flag_u g_pack_flags = {
	.bit.init = false,				///< SOH初始化标志位
	.bit.proc_init = false,			///< SOH进程初始化标志位
	.bit.soh_save = false,			///< SOH保存标志位，默认为false
	.bit.cell_calc_start = false,	///< 电芯SOH计算开始标志位
	.bit.cell_calc_done = false,	///< 电芯SOH计算完成标志位
	.bit.new_cycle = false,			///< 每日结算数据开始统计标志位
	.bit.cycle_calc_inited = false,	///< 每日循环数据统计标志位
	.bit.dsg_calc_inited = false,	///< 放电统计数据标志位
};

/**
  * @struct   sox_running_data_t
  * @brief    PACK级：SOH的运行数据指针，初始化后，指向SOC的运行数据结构体
  */
static sox_running_data_t* gp_bms_running_data = NULL;

/**
  * @struct   soh_status_t
  * @brief    PACK级：SOH模块运行状态状态
  */
static soh_status_t g_running_status = {0};

/**
  * @struct   soh_val_t
  * @brief    PACK级：SOC计算值、显示值等
  */
static soh_val_t g_pack_soh_vals = {0};

/**
  * @struct   soh_flow_flag_u
  * @brief    PACK级：记录SOH流程的结构体
  */
static soh_flow_flag_u g_pack_flow_flags = {0};
/************************************************************************/
/*************************CELL级别变量初始化******************************/
/************************************************************************/

/**
  * @struct   volt_fl_t
  * @brief    CELL级：电芯电压
  */
static volt_fl_t g_cell_fl_volt[CELL_VOLT_NUM] = {0};

/**
  * @struct   soh_val_t
  * @brief    CELL级：SOH计算值、显示值等
  */
static soh_val_t g_cell_soh_vals[CELL_VOLT_NUM] = {0};

/**
  * @struct   soh_cell_calc_para_t
  * @brief    CELL级：SOH用到的逻辑判断、计算相关的参数
  */
static soh_cell_calc_para_t g_cell_calc_paras[CELL_VOLT_NUM] = {0};

/**
  * @struct   soh_cell_flag_u
  * @brief    CELL级：SOH逻辑判断中的标志位
  */
static soh_cell_flag_u g_cell_flags[CELL_VOLT_NUM] = {0};

/**
  * @enum   cell_cycle_storg_stats_t
  * @brief  CELL级：循环、存储统计数据结构体
  */
static cell_cycle_storg_stats_t g_cell_cycle_storg_stats[CELL_VOLT_NUM] = {0};

/************************************************************************/
/******************************SOH使用到的表格****************************/
/************************************************************************/

/*********************表格1---V_target表*********************************/
static const int32_t v_target_tab[V_TARGET_LENGTH] =
{
	2500, 2600, 2700, 2800, 2900, 3000, 3100,
};

/*********************表格2---温度倍率系数表******************************/
static const int32_t temp_ratio_tab[TEMP_LENGTH][CUR_LENGTH][V_TARGET_LENGTH] = {
	{
		{996 ,	994 ,	990 ,	985 ,	977 ,	965 ,	943 ,},
		{981 ,	976 ,	971 ,	963 ,	954 ,	941 ,	908 ,},
		{969 ,	963 ,	955 ,	946 ,	935 ,	919 ,	0x7FFFFFFF,},
		{956 ,	948 ,	938 ,	927 ,	914 ,	894 ,	0x7FFFFFFF,},
	},

	{
		{1008 ,	1006 ,	1003 ,	998 ,	990 ,	979 ,	961 ,},
		{1000 ,	996 ,	992 ,	986 ,	978 ,	967 ,	946 ,},
		{992 ,	987 ,	982 ,	974 ,	965 ,	952 ,	919 ,},
		{978 ,	971 ,	964 ,	954 ,	940 ,	921 ,	0x7FFFFFFF,},
	},

	{
		{1010 ,	1009 ,	1007 ,	1002 ,	995 ,	983 ,	966 ,},
		{1009 ,	1007 ,	1004 ,	999 ,	991 ,	980 ,	962 ,},
		{1008 ,	1006 ,	1002 ,	996 ,	988 ,	977 ,	958 ,},
		{1004 ,	1000 ,	995 ,	987 ,	978 ,	966 ,	939 ,},
	},

	{
		{1011 ,	1010 ,	1007 ,	1003 ,	995 ,	983 ,	964 ,},
		{1009 ,	1008 ,	1005 ,	1000 ,	992 ,	980 ,	961 ,},
		{1009 ,	1007 ,	1004 ,	999 ,	991 ,	979 ,	959 ,},
		{1009 ,	1007 ,	1004 ,	998 ,	990 ,	976 ,	954 ,},
	},
};

//温度倍率系数表格的三维索引
static const int32_t temp_ratio_index_tab[TEMP_RATIO_DIMENTION][V_TARGET_LENGTH] = {
	{2500, 2600, 2700, 2800, 2900, 3000, 3100},
	{28000, 56000, 84000, 140000},
	{15, 25, 35, 45},
};

/*************表格3---底数为2的指数表（仅为等效循环圈数计算服务）********/
static const int32_t ratix_2_tab[EXPONENT_LENGTH] = {
	105 ,	125 ,	149 ,	177 ,	210 ,
	250 ,	297 ,	354 ,	420 ,	500 ,
	595 ,	707 ,	841 ,	1000 ,	1189 ,
	1414 ,	1682 ,	2000 ,	2378 ,	2828 ,
	3364 ,	4000 ,
};

//底数为2指数表格的索引（仅为等效循环圈数计算服务）
static const int32_t index_tab[EXPONENT_LENGTH] = {
	-40 ,	-35 ,	-30 ,	-25 ,	-20 ,
	-15 ,	-1 ,	-5 ,	0 ,		5 ,
	10 ,	15 ,	20 ,	25 ,	30 ,
	35 ,	40 ,	45 ,	50 ,	55 ,
	60 ,	65 ,
};

/*********************表格4---SOH寿命预测表（SOH-圈数曲线）***********/
//电池SOH表
static const int32_t bat_soh_tab[63] = {
	100000 ,98892 ,	98202 ,	97614 ,	97082 ,
	96590 ,	96127 ,	95687 ,	95266 ,	94860 ,
	94467 ,	94086 ,	93716 ,	93354 ,	93001 ,
	92656 ,	92317 ,	91985 ,	91658 ,	91337 ,
	91021 ,	90710 ,	90403 ,	90101 ,	89802 ,
	88928 ,	88082 ,	87262 ,	86463 ,	85685 ,
	84925 ,	84180 ,	83451 ,	82735 ,	82032 ,
	81340 ,	80660 ,	79989 ,	79486 ,	78913 ,
	78327 ,	77725 ,	77105 ,	76463 ,	75797 ,
	75103 ,	74376 ,	73613 ,	72808 ,	71954 ,
	71046 ,	70076 ,	68487 ,	66707 ,	64697 ,
	62410 ,	59792 ,	56774 ,	53278 ,	49207 ,
	44448 ,	40826 ,	0,
};

//d(SOH)/d(cycle)
static const int32_t bat_slope_tab[62] = {
	-111 ,	-69 ,	-59 ,	-53 ,	-49 ,
	-46 ,	-44 ,	-42 ,	-41 ,	-39 ,
	-38 ,	-37 ,	-36 ,	-35 ,	-35 ,
	-34 ,	-33 ,	-33 ,	-32 ,	-32 ,
	-31 ,	-31 ,	-30 ,	-30 ,	-29 ,
	-28 ,	-27 ,	-27 ,	-26 ,	-25 ,
	-25 ,	-24 ,	-24 ,	-23 ,	-23 ,
	-23 ,	-22 ,	-25 ,	-29 ,	-29 ,
	-30 ,	-31 ,	-32 ,	-33 ,	-35 ,
	-36 ,	-38 ,	-40 ,	-43 ,	-45 ,
	-48 ,	-53 ,	-59 ,	-67 ,	-76 ,
	-87 ,	-101 ,	-117 ,	-136 ,	-159 ,
	-181 ,	-408,
};

/**
 * @brief		如果是上电状态，则赋予SOH初始值；如果不是上电，则跳过
 * @param[in]	无
 * @return		执行结果
 * @retval		true，初始化成功
 * @retval		false，初始化失败
 * @note
*/
static int32_t soh_init(void)
{
	int32_t retval = true;
	limit_params_t limit_params = {0};
	int32_t cell_index = 0;

	//该分支只在上电初始化时运行
	if (false == g_pack_flags.bit.init)
	{
		gp_bms_running_data = sox_running_data_addr_get();

		//如果运行数据是空指针，记录该异常
		if (NULL == gp_bms_running_data)
		{
			g_running_status.pack_events.bit.initialized = false;

			return false;
		}

		g_sox_interface_remap.sox_limit_params_get(&limit_params);

		for (cell_index = 0; cell_index < CELL_VOLT_NUM; cell_index++)
		{
			//读取E2中的SOH计算值、高精度显示值、低精度显示值
			g_cell_soh_vals[cell_index].calc = gp_bms_running_data->cell_calc_soh[cell_index];
			g_cell_soh_vals[cell_index].high_pre = gp_bms_running_data->soh_high_pre[cell_index];
			g_cell_soh_vals[cell_index].low_pre = g_cell_soh_vals[cell_index].high_pre/FRAC_PRE;

			//一阶电压滤波初值初始化
			g_cell_fl_volt[cell_index].volt_last_time = g_sox_sample_data.cell_volt[cell_index];

			//电芯SOH计算相关标志位置位
			g_cell_flags[cell_index].bit.calc_permit = false;
			g_cell_flags[cell_index].bit.calc_start = false;
			g_cell_flags[cell_index].bit.calc_end = true;
		}

		//一阶电流滤波初值初始化
		g_pack_cur.fl_signal.cur_last_time = g_sox_sample_data.sys_cur;

		//最近120秒的电流值
		g_pack_cur.cur_fl_array[g_pack_cur.cur_fl_array_index++] =
			g_pack_cur.fl_signal.cur_last_time;

		//注意，初始化之后，必须将初始化标志位置true，并记录事件
		g_pack_flags.bit.init = true;
		g_running_status.pack_events.bit.initialized = true;

		//读取E2中保存的额定容量，并做保护
		//超过范围按照默认值处理
		if (limit_params.rated_cap > RATED_CAP_UPPER_LIMIT)
		{
			g_pack_calc_paras.bat_rated_cap = DEFAULTED_RATED_CAP;
		}
		else if (limit_params.rated_cap < RATED_CAP_LOWER_LIMIT)
		{
			g_pack_calc_paras.bat_rated_cap = DEFAULTED_RATED_CAP;
		}
		else
		{
			g_pack_calc_paras.bat_rated_cap = limit_params.rated_cap;
		}
	}
	else if (true == g_pack_flags.bit.init)
	{
		;
	}

	return retval;
}

/**
 * @brief		各电芯电压、电流信号一阶滤波迭代
 * @param[in]	无
 * @return		执行结果
 * @note
*/
static void soh_first_order_filter(void)
{
	int32_t i = 0;

	#ifdef SOH_FIRST_ORDER_FILTER_DEBUG
		log_d("*****************SOH一阶滤波测试*******************\n");
		log_d("上次滤波后的电压值%d\n",g_cell_fl_volt[0].volt_last_time);
		log_d("上次滤波后的电流值%d\n",g_pack_cur.fl_signal.cur_last_time);
	#endif

	for (i = 0; i < CELL_VOLT_NUM; i++)
	{
		float filter_volt = (1- SOH_FIL_COFF) * g_cell_fl_volt[i].volt_last_time +
        	SOH_FIL_COFF * g_sox_sample_data.cell_volt[i];
		g_cell_fl_volt[i].volt_this_time = (int32_t)filter_volt;
		g_cell_fl_volt[i].volt_last_time = filter_volt;
	}

	float filter_cur = (1- SOH_FIL_COFF) * g_pack_cur.fl_signal.cur_last_time +
        SOH_FIL_COFF * g_sox_sample_data.sys_cur;

    g_pack_cur.fl_signal.cur_this_time = (int32_t)filter_cur;
	#ifdef SOH_FIRST_ORDER_FILTER_DEBUG
		log_d("最低电芯电压值%d\n",g_sox_sample_data.min_cell_volt);
		log_d("系统电流值%d\n",g_sox_sample_data.sys_cur);

		log_d("本次滤波后的电压值%d\n",g_cell_fl_volt[0].volt_this_time);
		log_d("本次滤波后的电流值%d\n\n",g_pack_cur.fl_signal.cur_this_time);
	#endif

	#ifdef SOH_CALC_TEMP_DEBUG
		//将120秒降低为10秒，这样调试更加方便
		if (g_pack_cur.cur_fl_array_index >= _10S_BASE_1S)
	#else
		if (g_pack_cur.cur_fl_array_index >= _120S_BASE_1S)
	#endif
	{
		g_pack_cur.cur_fl_array_index = 0;
	}
	g_pack_cur.cur_fl_array[g_pack_cur.cur_fl_array_index++] =
		g_pack_cur.fl_signal.cur_this_time;

	g_pack_cur.fl_signal.cur_last_time = filter_cur;
}

/**
 * @brief		SOH计算准入条件判断及处理
 * @param[in]	cell_num，电芯编号
 * @return		执行结果
 * @retval		true，SOH计算准入
 * @retval		false，不允许SOH计算准入
 * @note
*/
static bool soh_calc_permit(int32_t cell_num)
{
	bool retval = false;
	int8_t is_matching = false;
	int32_t calc_soc = 0;

	calc_soc = soc_calc_val_get((sox_cell_sel_e)cell_num);

	//允许计算的条件：
	//1、SOC计算值大于99% &&
	//2、最低电芯电压大于等于3.32V &&
	//3、电池无故障 &&
	//4、SOH计算未启动
	//5、最低电芯温度 >= 15℃
	is_matching = (g_sox_sample_data.cell_volt[cell_num] >= SOH_CALC_PERMIT_VOLT)
		&& (g_sox_sample_data.cell_temp[cell_num/CELL_TEMP_GROUP_LENGTH] >= SOH_CALC_PERMIT_TEMP)
		&& (false == g_cell_flags[cell_num].bit.calc_start)
		&& (calc_soc > NON_FULL_HIGHEST_SOC*SOC_CALC_PRE)
		&& (false == g_sox_interface_remap.sox_get_fault(THERE_IS_FAULT));

	//允许计算SOH，更新允许计算标志位的持续时间、允许计算标志位
	if (true == is_matching)
	{
		g_cell_flags[cell_num].bit.calc_permit = true;
		g_cell_calc_paras[cell_num].calc_valid_time = SOH_CALC_PERMIT_FLAG_TIME;

		g_running_status.cell_events[cell_num].bit.calc_permit = true;
	}
	else
	{
		;
	}

	retval = g_cell_flags[cell_num].bit.calc_permit;

	return retval;
}

/**
 * @brief		SOH计算启动条件判断及处理
 * @param[in]	cell_num，电芯编号
 * @return		执行结果
 * @retval		true，SOH计算启动
 * @retval		false，SOH计算不启动
 * @note
*/
static bool soh_calc_entry(int32_t cell_num)
{
	bool retval = false;
	int8_t is_matching = 0;

	//SOH计算启动的条件：
	//1、SOH允许计算 &&
	//2、电流小于-1A持续5秒 &&
	//3、SOH计算未启动
	is_matching = (true == g_cell_flags[cell_num].bit.calc_permit) &&
		(g_pack_calc_paras.cur_under_minus_1A_counter >= SOH_CALC_START_DURATION) &&
		(false == g_cell_flags[cell_num].bit.calc_start);

	if (true == is_matching)
	{
		retval = true;
		g_running_status.cell_events[cell_num].bit.calc_entry = true;
	}
	else
	{
		retval = false;
	}

	return retval;
}

/**
 * @brief		SOH计算退出条件判断及处理
 * @param[in]	cell_num，电芯编号
 * @return		执行结果
 * @retval		true，退出SOH计算
 * @retval		非0，不退出SOH计算
 * @note
*/
static bool soh_calc_exit(int32_t cell_num)
{
	bool retval = false;
	int8_t is_matching = 0;
	uint32_t current_tick = 0;

	//SOH计算结算的条件：
	//充电状态且充电电流大于0.1A的状态持续2秒以上 ||
	//本次SOH计算时间大于24小时 ||
	//触发模组欠压保护 ||
	//触发电芯欠压保护 ||
	//触发进入待机或、休眠模式的故障或保护
	current_tick = g_sox_interface_remap.sox_tick_get();

	is_matching = (SOX_OK == sox_time_is_over(current_tick,
		g_cell_calc_paras[cell_num].soh_calc_start_time,SOH_CALC_EXIT_DURATION_HOURS*3600*1000)) ||
		g_sox_interface_remap.sox_get_fault(SOX_TOTAL_VOLT_LOW_PROTECT) ||
		g_sox_interface_remap.sox_get_fault(SOX_CELL_VOLT_LOW_PROTECT) ||
		(true == g_sox_interface_remap.sox_get_fault(THERE_IS_FAULT));

	if (true == is_matching)
	{
		retval = true;
		g_running_status.cell_events[cell_num].bit.calc_exit = true;
	}
	else
	{
		retval = false;
	}

	return retval;
}

/**
 * @brief		统计放电过程中的安时、温度数据
 * @param[in]	cell_num，电芯编号
 * @return		无
 * @note
*/
static void soh_dsg_stats(int32_t cell_num)
{
	uint32_t calc_this_time = 0;
	int32_t time_diff = 0;

	//舍弃第一秒的数据，将所有数据清空进行后续计算
	if (true == g_cell_flags[cell_num].bit.first_calc_temp)
	{
		calc_this_time = g_sox_interface_remap.sox_tick_get();
		g_cell_calc_paras[cell_num].calc_last_time = calc_this_time;

		g_cell_calc_paras[cell_num].mAms_accum = 0;
		g_cell_calc_paras[cell_num].mAs_accum = 0;

		g_cell_calc_paras[cell_num].avg_of_ntc = 0;
		g_cell_calc_paras[cell_num].ntc_temp_sumed = 0;
		g_cell_calc_paras[cell_num].ntc_counter = 0;

		g_cell_calc_paras[cell_num].dsg_mAh_integral = 0;
	}
	else
	{
		//如果数据不对，就先跳过一次积分运算
		if (false == g_pack_flags.bit.dsg_calc_inited)
		{
			g_pack_flags.bit.dsg_calc_inited = true;
			g_cell_calc_paras[cell_num].calc_last_time = g_sox_interface_remap.sox_tick_get();
		}
		else if (true == g_pack_flags.bit.dsg_calc_inited)
		{
			//计算两次SOH计算之间的时间间隔，因为不是按照1秒的标准时间间隔采样的
			calc_this_time = g_sox_interface_remap.sox_tick_get();

			//准确计算两次SOH计算之间的ms，用于SOH的精确计算
			if (calc_this_time > g_cell_calc_paras[cell_num].calc_last_time)
			{
				time_diff = (int32_t)(calc_this_time - g_cell_calc_paras[cell_num].calc_last_time) - FRAC_PRE;
			}
			else if (calc_this_time < g_cell_calc_paras[cell_num].calc_last_time)
			{
				time_diff = (int32_t)(0xFFFFFFFF - g_cell_calc_paras[cell_num].calc_last_time + calc_this_time + 1) - FRAC_PRE;
			}
			else
			{
				time_diff = 0;
			}

			//这里将电流前面的符号取负号，放电情况下，放电AH会上涨；充电情况下，放电AH会下降
			//因为要退出SOH计算需要充电2秒钟，万一充1秒钟再放电，需要将这多充的1秒钟去掉
			g_cell_calc_paras[cell_num].mAms_accum += -g_sox_sample_data.sys_cur * time_diff;

			//将mAms进位到mAs
			if (abs(g_cell_calc_paras[cell_num].mAms_accum) < FRAC_PRE)
			{
				g_cell_calc_paras[cell_num].mAs_accum += -g_sox_sample_data.sys_cur;
			}
			else if (abs(g_cell_calc_paras[cell_num].mAms_accum) >= FRAC_PRE)
			{
				g_cell_calc_paras[cell_num].mAs_accum += -g_sox_sample_data.sys_cur
					+ g_cell_calc_paras[cell_num].mAms_accum/FRAC_PRE;

				g_cell_calc_paras[cell_num].mAms_accum %= FRAC_PRE;
			}

			g_cell_calc_paras[cell_num].calc_last_time = calc_this_time;
		}
	}

	//将mAs进位到mAh
	if (abs(g_cell_calc_paras[cell_num].mAs_accum) >= HOUR_TO_SEC)
	{
		g_cell_calc_paras[cell_num].dsg_mAh_integral += g_cell_calc_paras[cell_num].mAs_accum/HOUR_TO_SEC;

		g_cell_calc_paras[cell_num].mAs_accum = g_cell_calc_paras[cell_num].mAs_accum%HOUR_TO_SEC;
	}
	else
	{
		;
	}

	//记录放电时的NTC温度
	g_cell_calc_paras[cell_num].ntc_temp_sumed += g_sox_sample_data.cell_temp[cell_num/CELL_TEMP_GROUP_LENGTH];
	g_cell_calc_paras[cell_num].ntc_counter++;
	g_cell_calc_paras[cell_num].avg_of_ntc =
		g_cell_calc_paras[cell_num].ntc_temp_sumed/g_cell_calc_paras[cell_num].ntc_counter;
}

/**
* @brief		输入一个数字，查找在数组中离这个数字最近的数，向下取
 * @param[in]	array，需要查表的数组地址
 * @param[in]	array_length，数组长度
 * @param[in]	val_comp，输入的数据
 * @param[in]	index，查表后的索引位置
 * @return		执行结果
 * @retval		SOX_FAIL，无效值
 * @retval		非SOX_FAIL，离输入数字最近的数
 * @note
*/
static int32_t sox_val_nearby(int32_t* array, int32_t array_length, int32_t val_comp, int32_t* index)
{
	int32_t retval = 0;
	int32_t i = 0;

	if ((NULL == array) || (NULL == index))
	{
		return SOX_FAIL;
	}

	retval = array[0];
	*index = 0;

	for (i = array_length - 1; i >= 0; i--)
	{
		if (val_comp > array[i])
		{
			*index = i;
			retval = array[i];
			break;
		}
	}

	return retval;
}

/**
* @brief		温度倍率查表
 * @param[in]	volt，需要查表的电压
 * @param[in]	cur，需要查表的电流
 * @param[in]	temp，需要查表的温度
 * @param[in]	temp_rate，查表之后的温度倍率系数
 * @return		执行结果
 * @retval		flase，无效值
 * @retval		true，查询成功
 * @note
*/
static bool soh_check_temp_rate(int32_t volt, int32_t cur, int32_t temp, int32_t * temp_rate)
{
	bool retval = true;

	index_length_3d_t index_length_3d = {V_TARGET_LENGTH,4,4};
	coord_3d_t coord_3d = {volt,cur,temp};

	if (NULL == temp_rate)
	{
		return false;
	}

	*temp_rate = sox_interp_3d((int32_t *)temp_ratio_index_tab, (int32_t *)temp_ratio_tab, V_TARGET_LENGTH, index_length_3d, coord_3d);

	if (SOX_FAIL == *temp_rate)
	{
		retval = false;
	}

	return retval;
}

/**
* @brief		指数计算表，只用于等效循环圈数的计算
 * @param[in]	data_in，查询的温度
 * @return		执行结果
 * @retval		true，查询成功
 * @retval		false，查询失败
 * @note
*/
static int32_t soh_power_2_func(int32_t data_in)
{
	int32_t retval = true;

	retval = sox_interp_1d((int32_t*)index_tab, (int32_t*)ratix_2_tab, 22, data_in);

	//按理说，不应该这么处理，应该返回值是0x7FFFFFFF
	//把返回值交给用到的地方去处理，但是这个函数只用在循环圈数查取中，所以在这里做处理
	if (SOX_FAIL == retval)
	{
		retval = 1000;
	}

	return retval;
}

/**
 * @brief		SOH临时计算
 * @param[in]	cell_num，电芯编号
 * @return		执行结果
 * @retval		true，计算成功
 * @retval		false，计算失败
 * @note
*/
static bool soh_calc_temp(int32_t cell_num)
{
	bool retval = true;
	int8_t is_matching = 0;
	int32_t temp2 = 0;
	int32_t temp_ratio = 0;
	bool v_target_flag = false;
	int32_t v_target_index = 0;

	//如果触发SOH计算，进来SOH临时值计算的第一秒会初始化V_target
	if (true == g_cell_flags[cell_num].bit.first_calc_temp)
	{
		g_cell_calc_paras[cell_num].v_target_this_time =
			sox_val_nearby((int32_t *)v_target_tab, V_TARGET_LENGTH,
			g_cell_fl_volt[cell_num].volt_this_time, &v_target_index);

		g_cell_calc_paras[cell_num].v_target_last_time = v_target_tab[v_target_index];

		if (SOX_FAIL == g_cell_calc_paras[cell_num].v_target_this_time)
		{
			g_cell_calc_paras[cell_num].v_target_this_time = 3100;
			g_cell_calc_paras[cell_num].v_target_last_time = 3100;
		}
	}
	else
	{
		g_cell_calc_paras[cell_num].v_target_this_time =
			sox_val_nearby((int32_t *)v_target_tab,V_TARGET_LENGTH,
			g_cell_fl_volt[cell_num].volt_this_time, &v_target_index);

		if (SOX_FAIL == g_cell_calc_paras[cell_num].v_target_this_time)
		{
			g_cell_calc_paras[cell_num].v_target_this_time = 3100;
		}
	}

	//如果放电深度首次达到目标电压V_target，标志位置位
	if (g_cell_calc_paras[cell_num].v_target_this_time <
		g_cell_calc_paras[cell_num].v_target_last_time)
	{
		v_target_flag = true;

		temp2 = soh_check_temp_rate(
			g_cell_calc_paras[cell_num].v_target_last_time,
			abs(g_pack_cur.fl_signal.cur_this_time),
			g_sox_sample_data.cell_temp[cell_num/CELL_TEMP_GROUP_LENGTH], &temp_ratio);

		if (false == temp2)
		{
			temp_ratio = SOX_FAIL;
		}

		g_cell_calc_paras[cell_num].v_target_last_time =
			g_cell_calc_paras[cell_num].v_target_this_time;
	}
	else
	{
		v_target_flag = false;
	}

	//1、电芯电压滤波值首次低于最近一档V_target
	//2、电流滤波值>=0.1C
	//3、电流滤波值在过去120s中的最大值-最小值<=0.1C
	//4、当前SOC<=15%  ---屏蔽SOC条件
	//5、放电过程中平均最低温度>=15
	//6、当前最低电芯温度>=15
	is_matching = ((max_array(g_pack_cur.cur_fl_array, _120S_BASE_1S) -
			min_array(g_pack_cur.cur_fl_array, _120S_BASE_1S)) <= SOH_TEMP_CALC_FIL_CUR_DIFF)
			&& (true == v_target_flag)
			&& (g_pack_cur.fl_signal.cur_this_time <= SOH_TEMP_CALC_FIL_UPPER_CUR)
			&& (g_pack_cur.fl_signal.cur_this_time >= SOH_TEMP_CALC_FIL_LOWER_CUR)
			/* && (soc_calc <= SOH_TEMP_CALC_SOC*FRAC_PRE) */
			&& (g_cell_calc_paras[cell_num].avg_of_ntc >= SOH_TEMP_CALC_AVG_TEMP)
			&& (g_sox_sample_data.cell_temp[cell_num/CELL_TEMP_GROUP_LENGTH] >= SOH_TEMP_CALC_TEMP);

	if (true == is_matching)
	{
		if (0 == g_pack_calc_paras.bat_rated_cap)
		{
			g_pack_calc_paras.bat_rated_cap = DEFAULTED_RATED_CAP;
		}

		if (SOX_FAIL == temp_ratio)
		{
			retval = false;
		}
		else
		{
			g_cell_soh_vals[cell_num].temp_calc =
				g_cell_calc_paras[cell_num].dsg_mAh_integral * FRAC_PRE / temp_ratio
				* 100 / g_pack_calc_paras.bat_rated_cap;

			g_cell_flags[cell_num].bit.temp_calc_exist = true;
			g_running_status.cell_events[cell_num].bit.calc_exist = true;
		}
	}
	else
	{
		retval = false;
	}

	return retval;
}

/**
 * @brief		SOH存储
 * @param[in]	cell_num，电芯编号
 * @return		执行结果
 * @retval		true，处理完成
 * @retval		false，处理失败
 * @note
*/
static bool soh_save(int32_t cell_num)
{
	bool retval = true;

	//SOH计算完毕，且有结果，触发SOH保存
	if ((false == g_cell_flags[cell_num].bit.calc_start)
	&& (true == g_cell_flags[cell_num].bit.calc_end))
	{
		if (true == g_cell_flags[cell_num].bit.temp_calc_exist)
		{
			gp_bms_running_data = sox_running_data_addr_get();

            g_cell_flags[cell_num].bit.temp_calc_exist = false;
			g_running_status.cell_events[cell_num].bit.calc_exist = false;
            
            // 有一个soh计算值更新后，把每个电芯soh计算值也更新一下；
            for(uint8_t cell_no = 0; cell_no < CELL_VOLT_NUM; cell_no++)
            {
                g_cell_soh_vals[cell_num].calc = g_cell_soh_vals[cell_num].temp_calc;
                gp_bms_running_data->cell_calc_soh[cell_num] = g_cell_soh_vals[cell_num].calc;                
            }

			g_pack_flags.bit.soh_save = true;
			g_running_status.pack_events.bit.soh_save = true;
		}
		else
		{
			g_running_status.pack_events.bit.soh_save = false;
		}
	}
	else
	{
		;
	}

	return retval;
}

/**
* @brief		统计24小时以内和等效循环次数相关的数据
 * @param[in]	无
 * @return		执行结果
 * @retval		true，获取成功
 * @retval		false，获取失败
 * @note
*/
static bool soh_cycle_stats(void)
{
	int32_t retval = true;
	int32_t cell_num = 0;

	//如果是在24小时以内，那么就统计循环计算相关的数据
	//否则清空本次24小时的数据
	if (false == g_pack_flags.bit.new_cycle)
	{
		//如果采样数据不对，就会跳过此次计算过程
		if (false == g_pack_flags.bit.cycle_calc_inited)
		{
			g_pack_flags.bit.cycle_calc_inited = true;
		}
		else if (true == g_pack_flags.bit.cycle_calc_inited)
		{
			//统计24小时内的累计充放电安秒
			if (g_sox_sample_data.sys_cur > SOH_CYCLE_STATS_UPPER_CUR)
			{
				g_pack_calc_paras.cycle_storg_stats.cycle_chg_as
					+= abs(g_sox_sample_data.sys_cur)/FRAC_PRE;
			}
			else if (g_sox_sample_data.sys_cur < SOH_CYCLE_STATS_UNDER_CUR)
			{
				g_pack_calc_paras.cycle_storg_stats.cycle_dsg_as
					+= abs(g_sox_sample_data.sys_cur)/FRAC_PRE;
			}

			//保存充放电相关数据和存储状态时的相关数据
			if (abs(g_sox_sample_data.sys_cur) > SOH_CYCLE_STATS_UPPER_CUR)
			{
				//循环中的电流
				g_pack_calc_paras.cycle_storg_stats.cycle_cur
					+= abs(g_sox_sample_data.sys_cur)/FRAC_PRE;

				g_pack_calc_paras.cycle_storg_stats.cur_counter++;

				//循环中的平均电流
				g_pack_calc_paras.cycle_storg_stats.avg_cur =
					g_pack_calc_paras.cycle_storg_stats.cycle_cur /
					g_pack_calc_paras.cycle_storg_stats.cur_counter;

				for (cell_num = 0; cell_num < CELL_VOLT_NUM; cell_num++)
				{
					//循环中的温度
					g_cell_cycle_storg_stats[cell_num].cycle_temp +=
						g_sox_sample_data.cell_temp[cell_num/CELL_TEMP_GROUP_LENGTH];

					g_cell_cycle_storg_stats[cell_num].cycle_temp_counter++;

					//循环中的平均温度
					g_cell_cycle_storg_stats[cell_num].avg_cycle_temp =
						g_cell_cycle_storg_stats[cell_num].cycle_temp /
						g_cell_cycle_storg_stats[cell_num].cycle_temp_counter;
				}
			}
			else
			{
				for (cell_num = 0; cell_num < CELL_VOLT_NUM; cell_num++)
				{
					//存储中的温度
					g_cell_cycle_storg_stats[cell_num].storage_temp +=
						g_sox_sample_data.cell_temp[cell_num/CELL_TEMP_GROUP_LENGTH];

					g_cell_cycle_storg_stats[cell_num].storage_temp_counter++;

					//存储中的平均温度
					g_cell_cycle_storg_stats[cell_num].avg_storage_temp =
						g_cell_cycle_storg_stats[cell_num].storage_temp /
						g_cell_cycle_storg_stats[cell_num].storage_temp_counter;
				}
			}
		}

		//等效循环圈数计算相关数据的获取
		g_pack_flow_flags.func_flow_flag.cycle_stats = true;
	}
	else
	{
		//每日结算之后，所有循环数据及计数清零
		//循环充放电AS
		g_pack_calc_paras.cycle_storg_stats.cycle_chg_as = 0;
		g_pack_calc_paras.cycle_storg_stats.cycle_dsg_as = 0;

		//循环电流
		g_pack_calc_paras.cycle_storg_stats.cycle_cur = 0;
		g_pack_calc_paras.cycle_storg_stats.cur_counter = 0;

		//循环、静置温度
		for (cell_num = 0; cell_num < CELL_VOLT_NUM; cell_num++)
		{
			g_cell_cycle_storg_stats[cell_num].cycle_temp = 0;
			g_cell_cycle_storg_stats[cell_num].cycle_temp_counter = 0;

			g_cell_cycle_storg_stats[cell_num].storage_temp = 0;
			g_cell_cycle_storg_stats[cell_num].storage_temp_counter = 0;
		}

		//等效循环圈数计算相关数据的获取
		g_pack_flow_flags.func_flow_flag.cycle_stats = true;
	}

	return retval;
}

/**
* @brief		判断是否进行SOH每日结算
 * @param[in]	无
 * @return		true，需要每日结算，false，不需要每日结算
 * @note
*/
static bool soh_daily_settlement(void)
{
	bool retval = SOX_OK;
	sox_rtc_t current_rtc_time = {0};
	uint32_t current_time = 0;
	uint32_t record_time = 0;

	gp_bms_running_data = sox_running_data_addr_get();

	//获取当前时间和记录时间，转化为------分钟
	g_sox_interface_remap.sox_rtc_get(&current_rtc_time);

	current_time =	current_rtc_time.tm_year*365*24*60
		+ current_rtc_time.tm_mon*30*24*60
		+ current_rtc_time.tm_day*24*60
		+ current_rtc_time.tm_hour*60
		+ current_rtc_time.tm_min;

	record_time = 	gp_bms_running_data->daily_save_time.tm_year*365*24*60
		+ gp_bms_running_data->daily_save_time.tm_mon*30*24*60
		+ gp_bms_running_data->daily_save_time.tm_day*24*60
		+ gp_bms_running_data->daily_save_time.tm_hour*60
		+ gp_bms_running_data->daily_save_time.tm_min;

	//只有满足SOH计算完成且距离上一次每日结算24小时，才可以进行每日结算
	if (SOX_OK == sox_time_is_over(current_time, record_time, SOH_DAILY_SETTLE_PERIOD_HOURS*60))
	{
		#ifdef LOG_PRINT_SWITCH_ON
			//log_e("soh_daily_save\n");
		#endif

		g_pack_flags.bit.new_cycle = true;
		g_running_status.pack_events.bit.daily_settlement = true;
	}
	else
	{
		retval = SOX_FAIL;
		g_pack_flags.bit.new_cycle = false;
		g_running_status.pack_events.bit.daily_settlement = false;
	}

	return retval;
}

/**
 * @brief		SOH等效循环圈数计算
 * @param[in]	cycle，根据等效循环数据，计算现在的运行圈数
 * @param[in]	cell_num，电芯编号
 * @return		true，计算成功，false，计算失败
 * @note
*/
static bool soh_daily_cycle_get(int32_t *cycle, int32_t cell_num)
{
	bool retval = true;
	int32_t temp_acc_coeff = 0;
	int32_t ratio_acc_coeff = 0;
	int32_t chg_dsg_turns = 0;
	int32_t storage_turns = 0;
	int32_t cycle_turns = 0;

	if (NULL  == cycle)
	{
		return false;
	}

	//24小时内充放电圈数(放大1000倍)，注意防止溢出、除零
	//这里为了防止相乘溢出，chg_as和dsg_as都先做了除法
	//先将As转化成Ah，最大允许Ah：
	//1、（充放电Ah）* 1000 < 0x7FFFFFFF
	//2、（充放电Ah）* 1000 < 0x7FFFFFFF / 4000 * 100 * 2
	//也就是一天最多53 687Ah，一天五十多次完整的充放电，不可能溢出
	chg_dsg_turns = (g_pack_calc_paras.cycle_storg_stats.cycle_dsg_as/HOUR_TO_SEC +
		g_pack_calc_paras.cycle_storg_stats.cycle_chg_as/HOUR_TO_SEC)*FRAC_PRE/2/
		(g_pack_calc_paras.bat_rated_cap*g_cell_soh_vals[cell_num].high_pre/100/FRAC_PRE);

	//温度加速系数(放大了1000倍)
	temp_acc_coeff =
		max_two_nums(soh_power_2_func(g_cell_cycle_storg_stats[cell_num].avg_cycle_temp), FRAC_PRE);

	//倍率加速系数(放大了100倍)
	ratio_acc_coeff = g_pack_calc_paras.cycle_storg_stats.avg_cur + SOH_CYCLE_STATS_RATIO;

	//循环等效循环圈数(放大了1000倍)，注意防止溢出、除零
	cycle_turns = chg_dsg_turns * temp_acc_coeff/FRAC_PRE * ratio_acc_coeff/100;

	//存储等效循环圈数(放大了1000倍)
	//如果一天以内都没有进入待机状态，就采用循环时候的平均温度
	if (0 == g_cell_cycle_storg_stats[cell_num].storage_temp_counter)
	{
		storage_turns = 0;
	}
	else if (0 != g_cell_cycle_storg_stats[cell_num].storage_temp_counter)
	{
		storage_turns =
			0.3 * soh_power_2_func(g_cell_cycle_storg_stats[cell_num].avg_storage_temp)
			* g_cell_cycle_storg_stats[cell_num].storage_temp_counter / SOH_STOR_PERIOD;
	}

	//保存圈数的小叔部分
	g_cell_calc_paras[cell_num].cycles_frac_part = gp_bms_running_data->cycle_frac[cell_num];
	g_cell_calc_paras[cell_num].cycles_frac_part += (cycle_turns + storage_turns)%FRAC_PRE;

	if (g_cell_calc_paras[cell_num].cycles_frac_part >= FRAC_PRE)
	{
		//等效循环圈数
		*cycle = (cycle_turns + storage_turns)/FRAC_PRE +
			g_cell_calc_paras[cell_num].cycles_frac_part/FRAC_PRE;

		g_cell_calc_paras[cell_num].cycles_frac_part %= FRAC_PRE;
	}
	else
	{
		*cycle = (cycle_turns + storage_turns)/FRAC_PRE;
	}

	gp_bms_running_data->cycle_frac[cell_num] = g_cell_calc_paras[cell_num].cycles_frac_part;

	return retval;
}

/**
 * @brief		SOH日历衰减
 * @param[in]	att_val，SOH的衰减值
 * @param[in]	cell_num，需要计算的电芯的索引
 * @return		true，计算成功，false，计算失败
 * @note
*/
static bool soh_calendar_att(int32_t* att_val, int32_t cell_num)
{
	bool retval = true;
	int32_t cycles = 0;
	int32_t temp = 0;

	gp_bms_running_data = sox_running_data_addr_get();

	temp = soh_daily_cycle_get(&cycles, cell_num);

	if ((false == temp) || (NULL == att_val))
	{
		return false;
	}
	else
	{
		gp_bms_running_data->cycle_count[cell_num] += cycles;

		*att_val = sox_scout_val_btn((int32_t*)bat_soh_tab, (int32_t*)bat_slope_tab, 63,
			g_cell_soh_vals[cell_num].high_pre)*cycles/10;

		if (SOX_FAIL == *att_val)
		{
			*att_val = 0;
		}
	}

	return retval;
}

/**
 * @brief		SOH显示，并且执行每日衰减
 * @param[in]	无
 * @return		0，显示成功，非0，显示失败
 * @note
*/
static bool soh_display(void)
{
	bool retval = false;
	int32_t soh_att_val = 0;
	int32_t k = 0;
	int32_t temp = false;
	int32_t cell_num = 0;

	int32_t is_new_pack = false;
	sox_stats_t sox_stats = {0};

	//如果满足每日结算SOH的条件、或者说电池包关机，计算等效循环圈数，再日历衰减计算SOH
	//将更新的高精度SOH保存，显示低精度SOH；否则根据上一次的高精度SOh显示低精度SOH
	if (SOX_OK == soh_daily_settlement()
		|| (true == g_pack_calc_paras.enforce_refresh))
	{
		g_pack_flags.bit.new_cycle = true;

		gp_bms_running_data = sox_running_data_addr_get();
		g_sox_interface_remap.sox_rtc_get(&(gp_bms_running_data->daily_save_time));

		for (cell_num = 0; cell_num < CELL_VOLT_NUM; cell_num++)
		{
			temp = soh_calendar_att(&soh_att_val, cell_num);

			if (false == temp)
			{
				return retval;
			}

			g_cell_soh_vals[cell_num].calc =
				g_cell_soh_vals[cell_num].calc + soh_att_val;

			//高精度显示值的更新及存储
			if (g_cell_soh_vals[cell_num].calc >= 75*FRAC_PRE)
			{
				k = 2;
			}
			else
			{
				k = 3;
			}
			g_cell_soh_vals[cell_num].high_pre = gp_bms_running_data->soh_high_pre[cell_num];
			sox_stats_get(&sox_stats);

			is_new_pack =
				(sox_stats.sumed_dsg_ah < SOH_NEW_PACK_CYCLES*g_pack_calc_paras.bat_rated_cap)
				&& (MAX_SOH*SOH_CALC_PRE == g_cell_soh_vals[cell_num].high_pre)
				&& (gp_bms_running_data->delivery_time <= SOH_VAL_PROTECT_TIME);

			if (true == is_new_pack)
			{
				g_cell_soh_vals[cell_num].high_pre = MAX_SOH*SOH_CALC_PRE;
			}
			else
			{
				g_cell_soh_vals[cell_num].high_pre =
					min_two_nums(g_cell_soh_vals[cell_num].high_pre + soh_att_val/2,
					max_two_nums(g_cell_soh_vals[cell_num].high_pre + soh_att_val*k, g_cell_soh_vals[cell_num].calc));
			}

			//将扣减后的SOH存储至E2
			gp_bms_running_data->cell_calc_soh[cell_num] = g_cell_soh_vals[cell_num].calc;
			gp_bms_running_data->soh_high_pre[cell_num] = g_cell_soh_vals[cell_num].high_pre;

			g_pack_flags.bit.soh_save = true;
			g_running_status.pack_events.bit.daily_settlement = true;

			//低精度显示值的更新
			g_cell_soh_vals[cell_num].low_pre =
				gp_bms_running_data->soh_high_pre[cell_num]/FRAC_PRE;

			retval = true;
		}

		//SOH显示
		g_pack_flow_flags.func_flow_flag.val_display = true;
	}
	else
	{
		//如果没有达到SOH每日更新的条件，就继续读取上一次的高精度SOH，更新低精度显示值
		g_cell_soh_vals[cell_num].low_pre =g_cell_soh_vals[cell_num].high_pre/FRAC_PRE;

		//SOH显示
		g_pack_flow_flags.func_flow_flag.val_display = true;

		retval = true;
	}

	return retval;
}

/**
 * @brief		SOH流程初始化
 * @param[in]	sox_interface_remap，SOX定制化函数的地址
 * @return		无
 * @note
*/
void soh_proc_init(sox_interface_remap_t sox_interface_remap)
{
	int32_t cell_num = 0;

	if (false == g_pack_flags.bit.proc_init)
	{
		if ((NULL == sox_interface_remap.sox_bat_status_get)
		|| (NULL == sox_interface_remap.sox_bms_status_get)
		|| (NULL == sox_interface_remap.sox_get_fault)
		|| (NULL == sox_interface_remap.sox_limit_params_get)
		|| (NULL == sox_interface_remap.sox_rtc_get)
		|| (NULL == sox_interface_remap.sox_running_data_get)
		|| (NULL == sox_interface_remap.sox_tick_get)
		|| (NULL == sox_interface_remap.sox_dsg_cali_data_get))
		{
			;
		}
		else
		{
			g_sox_interface_remap = sox_interface_remap;
			g_pack_flags.bit.proc_init = true;
			g_running_status.pack_events.bit.proc_initialized = true;

			g_pack_flags.bit.cell_calc_start = false;
			g_pack_flags.bit.cell_calc_done = false;
			g_pack_calc_paras.cell_calc_index = 0;
			g_pack_calc_paras.soh_calc_cnt = 0;

			gp_bms_running_data = sox_running_data_addr_get();

			for (cell_num = 0; cell_num < CELL_VOLT_NUM; cell_num++)
			{
				//读取E2中的SOH计算值、高精度显示值、低精度显示值
				g_cell_soh_vals[cell_num].calc = gp_bms_running_data->cell_calc_soh[cell_num];
				g_cell_soh_vals[cell_num].high_pre = gp_bms_running_data->soh_high_pre[cell_num];
				g_cell_soh_vals[cell_num].low_pre = g_cell_soh_vals[cell_num].high_pre/FRAC_PRE;
			}
		}
	}
	else if (true == g_pack_flags.bit.proc_init)
	{
		g_running_status.pack_events.bit.proc_initialized = false;
	}
}

/**
 * @brief		SOH判断条件更新
 * @param[in]	无
 * @return		无
 * @note
*/
static void soh_judge_term_refresh(void)
{
	int32_t cell_num =0 ;
	limit_params_t limit_params = {0};

	//更新限制参数中的额定容量
	g_sox_interface_remap.sox_limit_params_get(&limit_params);

	if (limit_params.rated_cap > RATED_CAP_UPPER_LIMIT)
		{
			g_pack_calc_paras.bat_rated_cap = DEFAULTED_RATED_CAP;
		}
		else if (limit_params.rated_cap < RATED_CAP_LOWER_LIMIT)
		{
			g_pack_calc_paras.bat_rated_cap = DEFAULTED_RATED_CAP;
		}
		else
		{
			g_pack_calc_paras.bat_rated_cap = limit_params.rated_cap;
		}

	//电流小于负1A的持续时间
	if (g_sox_sample_data.sys_cur <= SOH_CALC_START_CUR)
	{
		g_pack_calc_paras.cur_under_minus_1A_counter++;
	}
	else
	{
		g_pack_calc_paras.cur_under_minus_1A_counter = 0;
	}

	for (cell_num = 0; cell_num < CELL_VOLT_NUM; cell_num++)
	{
		//SOH允许计算标志位保存5秒，5秒后清空
		if (g_cell_calc_paras[cell_num].calc_valid_time > 0)
		{
			g_cell_calc_paras[cell_num].calc_valid_time--;
		}
		else if (g_cell_calc_paras[cell_num].calc_valid_time <= 0)
		{
			g_cell_flags[cell_num].bit.calc_permit = false;
		}

		//更新运行数据
		gp_bms_running_data->cell_calc_soh[cell_num] = g_cell_soh_vals[cell_num].calc;
		gp_bms_running_data->soh_high_pre[cell_num] = g_cell_soh_vals[cell_num].high_pre;
	}

	//更新电池关机信息，触发式
	if ((SOX_BMS_SHUT_DOWN == g_sox_interface_remap.sox_bms_status_get())
	&& (SOX_BMS_SHUT_DOWN != g_pack_calc_paras.pack_shut_last_time))
	{
		g_pack_calc_paras.pack_shut_raiseup_flag = true;
	}
	else
	{
		g_pack_calc_paras.pack_shut_raiseup_flag = false;
	}

	g_pack_calc_paras.pack_shut_last_time = g_sox_interface_remap.sox_bms_status_get();

	gp_bms_running_data->soh_running_status = g_running_status;
}


/**
 * @brief		判断采样值是否超出边界
 * @param[in]	无
 * @return		无
 * @note
 * @pre			无
*/
static void soh_sample_over_judge(void)
{
	int32_t temp = false;

	//系统采样电流范围：[-420A，420A]
	if (g_sox_sample_data.sys_cur < SOX_SAMPLE_LOWER_CUR)
	{
		temp = true;
		g_sox_sample_data.sys_cur = SOX_SAMPLE_LOWER_CUR;
	}
	else if (g_sox_sample_data.sys_cur > SOX_SAMPLE_UPPER_CUR)
	{
		temp = true;
		g_sox_sample_data.sys_cur = SOX_SAMPLE_UPPER_CUR;
	}

	//PACK总压范围：[115.2V，192V] 根据项目来
	if (g_sox_sample_data.pack_volt < SOX_SAMPLE_LOWER_PACK_VOLT)
	{
		temp = true;
		g_sox_sample_data.pack_volt = SOX_SAMPLE_LOWER_PACK_VOLT;
	}
	else if (g_sox_sample_data.pack_volt > SOX_SAMPLE_UPPER_PACK_VOLT)
	{
		temp = true;
		g_sox_sample_data.pack_volt = SOX_SAMPLE_UPPER_PACK_VOLT;
	}

	//最小电芯电压范围：[2400mV，4000mV]
	if (g_sox_sample_data.min_cell_volt < SOX_SAMPLE_LOWER_MIN_CELL_VOLT)
	{
		temp = true;
		g_sox_sample_data.min_cell_volt = SOX_SAMPLE_LOWER_MIN_CELL_VOLT;
	}
	else if (g_sox_sample_data.min_cell_volt > SOX_SAMPLE_UPPER_MIN_CELL_VOLT)
	{
		temp = true;
		g_sox_sample_data.min_cell_volt = SOX_SAMPLE_UPPER_MIN_CELL_VOLT;
	}

	//最小电芯温度范围：[-40℃，65℃]
	if (g_sox_sample_data.min_cell_temp < SOX_SAMPLE_LOWER_MIN_CELL_TEMP)
	{
		temp = true;
		g_sox_sample_data.min_cell_temp = SOX_SAMPLE_LOWER_MIN_CELL_TEMP;
	}
	else if (g_sox_sample_data.min_cell_temp > SOX_SAMPLE_UPPER_MIN_CELL_TEMP)
	{
		temp = true;
		g_sox_sample_data.min_cell_temp = SOX_SAMPLE_UPPER_MIN_CELL_TEMP;
	}

	//最大电芯电压范围：[2400mV，4000mV]
	if (g_sox_sample_data.max_cell_volt < SOX_SAMPLE_LOWER_MAX_CELL_VOLT)
	{
		temp = true;
		g_sox_sample_data.max_cell_volt = SOX_SAMPLE_LOWER_MAX_CELL_VOLT;
	}
	else if (g_sox_sample_data.max_cell_volt > SOX_SAMPLE_UPPER_MAX_CELL_VOLT)
	{
		temp = true;
		g_sox_sample_data.max_cell_volt = SOX_SAMPLE_UPPER_MAX_CELL_VOLT;
	}

	//平均电芯电压范围：[2400mV，4000mV]
	if (g_sox_sample_data.avg_cell_volt < SOX_SAMPLE_LOWER_AVG_CELL_VOLT)
	{
		temp = true;
		g_sox_sample_data.avg_cell_volt = SOX_SAMPLE_LOWER_AVG_CELL_VOLT;
	}
	else if (g_sox_sample_data.avg_cell_volt > SOX_SAMPLE_UPPER_AVG_CELL_VOLT)
	{
		temp = true;
		g_sox_sample_data.avg_cell_volt = SOX_SAMPLE_UPPER_AVG_CELL_VOLT;
	}

	//平均电芯温度范围：[-40℃，65℃]
	if (g_sox_sample_data.avg_cell_temp < SOX_SAMPLE_LOWER_AVG_CELL_TEMP)
	{
		temp = true;
		g_sox_sample_data.avg_cell_temp = SOX_SAMPLE_LOWER_AVG_CELL_TEMP;
	}
	else if (g_sox_sample_data.avg_cell_temp > SOX_SAMPLE_UPPER_AVG_CELL_TEMP)
	{
		temp = true;
		g_sox_sample_data.avg_cell_temp = SOX_SAMPLE_UPPER_AVG_CELL_TEMP;
	}

	g_running_status.errors.bit.sample_over_limit = temp;
}

void soh_proc_ctl(void)
{
	if (false == g_pack_flags.bit.proc_init)
	{
		return;
	}
	else if ((true == g_pack_flags.bit.proc_init) && (false == g_pack_flags.bit.cell_calc_done))
	{
		g_pack_flags.bit.cell_calc_start = true;
	}

	if ((true == g_pack_flags.bit.cell_calc_start) && (false == g_pack_flags.bit.cell_calc_done))
	{
		// 计算开始
		if (0 == g_pack_calc_paras.soh_calc_cnt)
		{
			g_pack_calc_paras.cell_calc_index = 0;
			g_pack_calc_paras.soh_calc_cnt++;
		}
		// 计算未完成
		else if (g_pack_calc_paras.cell_calc_index <= (CELL_VOLT_NUM - 1))
		{
			g_pack_calc_paras.cell_calc_index++;
			g_pack_calc_paras.soh_calc_cnt++;

			//计算完成
			if (g_pack_calc_paras.cell_calc_index > (CELL_VOLT_NUM - 1))
			{
				g_pack_flags.bit.cell_calc_start = false;
				g_pack_flags.bit.cell_calc_done = true;
				g_pack_calc_paras.soh_calc_cnt++;
			}
		}
		else
		{
			g_pack_calc_paras.cell_calc_index = 0;
			g_pack_calc_paras.soh_calc_cnt = 0;
		}
	}
	else if (true == g_pack_flags.bit.cell_calc_done)
	{
		//计算时间限制，10ms线程，1s
		if (g_pack_calc_paras.soh_calc_cnt < 100)
		{
			g_pack_calc_paras.soh_calc_cnt++;
		}
		else
        {
			g_pack_calc_paras.soh_calc_cnt = 0;
			g_pack_calc_paras.cell_calc_index = 0;
			g_pack_flags.bit.cell_calc_done =false;
        }
	}
}

/**
 * @brief		SOH流程
 * @param[in]	无
 * @return		无
 * @note
*/
void soh_proc(void)
{
	int16_t cell_num = 0;
	int32_t temp = 0;

	soh_proc_ctl();

	cell_num = g_pack_calc_paras.cell_calc_index;

	//SOH结算流程
	if ((true == g_pack_flags.bit.cell_calc_start) && (0 == g_pack_calc_paras.cell_calc_index))
	{
		g_pack_flow_flags.all_flag = 0x0000;

		temp = sox_sample_data_get(&g_sox_sample_data);	//获取SOX采样数据

		if (SOX_FAIL == temp)
		{
			g_running_status.errors.bit.sample_get_failed = true;
		}
		else if (false == g_pack_flags.bit.proc_init)
		{
			g_running_status.pack_events.bit.proc_initialized = false;
		}
		else
		{
			soh_sample_over_judge();	//采样数据超范围判断
			soh_init();					//SOH初始化

			//如果采样超过范围，待会儿放电SOH校准、每日循环数据都需要重新获取一个last_time
			if (true == g_running_status.errors.bit.sample_over_limit)
			{
				g_pack_flags.bit.cycle_calc_inited = false;
				g_pack_flags.bit.dsg_calc_inited = false;
			}
			else if (false == g_running_status.errors.bit.sample_over_limit)
			{
				soh_first_order_filter();	//SOX采样数据滤波处理
				soh_judge_term_refresh();	//SOH判断条件更新
			}
		}
	}

	if (SOX_FAIL == temp)
	{
		g_running_status.errors.bit.sample_get_failed = true;
	}
	else if (false == g_pack_flags.bit.proc_init)
	{
		g_running_status.pack_events.bit.proc_initialized = false;
	}
	else if (true != g_pack_flags.bit.cell_calc_done)
	{
		if (false == g_running_status.errors.bit.sample_over_limit)
		{
			//如果处于SOH计算中,则跳过计算准入判断
			//如果不处于SOH计算中，则判断是否需要进入计算
			if ((true == g_cell_flags[cell_num].bit.calc_start)
			&& (false == g_cell_flags[cell_num].bit.calc_end))
			{
				;
			}
			else if ((false == g_cell_flags[cell_num].bit.calc_start)
			&& (true == g_cell_flags[cell_num].bit.calc_end))
			{
				if (true == soh_calc_permit(cell_num))
				{
					if (true == soh_calc_entry(cell_num))
					{
						//记录本次SOH的计算时间
						g_cell_calc_paras[cell_num].soh_calc_start_time = g_sox_interface_remap.sox_tick_get();
						g_cell_flags[cell_num].bit.calc_start = true;
						g_cell_flags[cell_num].bit.calc_end = false;
						g_cell_flags[cell_num].bit.calc_permit = false;
						g_cell_flags[cell_num].bit.first_calc_temp = true;

						g_running_status.cell_events[cell_num].bit.calc_permit = false;
						g_running_status.cell_events[cell_num].bit.calc_entry = false;
					}
				}
			}

			//如果处于计算中，判断是否满足退出计算的条件
			if ((true == g_cell_flags[cell_num].bit.calc_start)
			&& (false == g_cell_flags[cell_num].bit.calc_end))
			{
				//判断是否满足SOH计算退出条件
				if (true == soh_calc_exit(cell_num))
				{
					g_cell_flags[cell_num].bit.calc_start = false;
					g_cell_flags[cell_num].bit.calc_end = true;
					g_running_status.cell_events[cell_num].bit.calc_exit = false;
				}
				//如果不需要退出SOH计算，那么就统计放电过程中的积分量
				//并计算SOH临时计算值（利用放电Ah进行校准）
				else
				{
					//积分统计量模块，只在放电状态有效
					soh_dsg_stats(cell_num);

					//SOH临时计算模块
					soh_calc_temp(cell_num);
				}

				if (true == g_cell_flags[cell_num].bit.first_calc_temp)
				{
					//初始化之后一直要将其置低，放电退出之后，再将该标志位置高
					g_cell_flags[cell_num].bit.first_calc_temp = false;
				}
			}
			else
			{
				;
			}

			//SOH存储模块，如果计算结束且有临时计算值，那么就将临时SOh结果赋值给计算SOH，然后保存到E2
			//如果没有计算结束，就继续统计数据
			soh_save(cell_num);
		}
	}

	if ((true == g_pack_flags.bit.cell_calc_done)
	&& (0x0003 != g_pack_flow_flags.all_flag)
	&& (false == g_running_status.errors.bit.sample_get_failed))
	{
		if (false == g_pack_flow_flags.func_flow_flag.cycle_stats)
		{
			//等效循环圈数计算相关数据的获取
			soh_cycle_stats();
		}

		if (false == g_pack_flow_flags.func_flow_flag.val_display)
		{
			//SOH显示模块
			soh_display();
		}
	}
}

/**
 * @brief		SOH相关数据强制刷新
 * @param[in]	无
 * @return		true，刷新成功；fasle，刷新失败
 * @note
*/
bool soh_enforce_refresh(void)
{
	bool retval = true;

	g_pack_calc_paras.enforce_refresh = true;

	#ifdef LOG_PRINT_SWITCH_ON
		//log_e("soh_enforce_refresh\n");
	#endif

	soh_display();

	g_pack_calc_paras.enforce_refresh = false;

	return retval;
}

/**
 * @brief		SOH计算值、高低精度显示值设置
 * @param[in]	sel_cmd，设定SOH数值的命令
 * @param[in]	soh_setting_val，需要设定的SOH数值
 * @return		0，设置成功；1，设置失败
 * @note
*/
int32_t soh_calc_val_set(sox_cell_sel_e sel_cmd, int32_t soh_setting_val)
{
	int32_t retval = 0;
	int16_t cell_index = 0;

	gp_bms_running_data = sox_running_data_addr_get();

	if (PACK_IS_SELED == sel_cmd)
	{
		for (cell_index = 0; cell_index < CELL_VOLT_NUM; cell_index++)
		{
			if ((soh_setting_val <= MAX_SOH) && (soh_setting_val >= MIN_SOH))
			{
				g_cell_soh_vals[cell_index].calc = soh_setting_val*FRAC_PRE;
				g_cell_soh_vals[cell_index].high_pre = soh_setting_val*FRAC_PRE;
				g_cell_soh_vals[cell_index].low_pre = soh_setting_val;
			}
			else if (soh_setting_val > MAX_SOH)
			{
				g_cell_soh_vals[cell_index].calc = MAX_SOH*FRAC_PRE;
				g_cell_soh_vals[cell_index].high_pre = MAX_SOH*FRAC_PRE;
				g_cell_soh_vals[cell_index].low_pre = MAX_SOH;
			}
			else if (soh_setting_val < MIN_SOH)
			{
				g_cell_soh_vals[cell_index].calc = MIN_SOH*FRAC_PRE;
				g_cell_soh_vals[cell_index].high_pre = MIN_SOH*FRAC_PRE;
				g_cell_soh_vals[cell_index].low_pre = MIN_SOH;
			}
		}

		if ((soh_setting_val <= MAX_SOH) && (soh_setting_val >= MIN_SOH))
		{
			g_pack_soh_vals.calc = soh_setting_val*FRAC_PRE;
			g_pack_soh_vals.high_pre = soh_setting_val*FRAC_PRE;
			g_pack_soh_vals.low_pre = soh_setting_val;
		}
		else if (soh_setting_val > MAX_SOH)
		{
			g_pack_soh_vals.calc = MAX_SOH*FRAC_PRE;
			g_pack_soh_vals.high_pre = MAX_SOH*FRAC_PRE;
			g_pack_soh_vals.low_pre = MAX_SOH;
		}
		else if (soh_setting_val < MIN_SOH)
		{
			g_pack_soh_vals.calc = MIN_SOH*FRAC_PRE;
			g_pack_soh_vals.high_pre = MIN_SOH*FRAC_PRE;
			g_pack_soh_vals.low_pre = MIN_SOH;
		}

		g_pack_flags.bit.soh_save = true;
	}
	else
	{
		if ((soh_setting_val <= MAX_SOH) && (soh_setting_val >= MIN_SOH))
		{
			g_cell_soh_vals[sel_cmd].calc = soh_setting_val*FRAC_PRE;
			g_cell_soh_vals[sel_cmd].high_pre = soh_setting_val*FRAC_PRE;
			g_cell_soh_vals[sel_cmd].low_pre = soh_setting_val;
		}
		else if (soh_setting_val > MAX_SOH)
		{
			g_cell_soh_vals[sel_cmd].calc = MAX_SOH*FRAC_PRE;
			g_cell_soh_vals[sel_cmd].high_pre = MAX_SOH*FRAC_PRE;
			g_cell_soh_vals[sel_cmd].low_pre = MAX_SOH;
		}
		else if (soh_setting_val < MIN_SOH)
		{
			g_cell_soh_vals[sel_cmd].calc = MIN_SOH*FRAC_PRE;
			g_cell_soh_vals[sel_cmd].high_pre = MIN_SOH*FRAC_PRE;
			g_cell_soh_vals[sel_cmd].low_pre = MIN_SOH;
		}

		g_pack_flags.bit.soh_save = true;
	}

	return retval;
}

/**
 * @brief		获取整个电池包的SOH显示值
 * @param[in]	无
 * @return		电池包的SOH显示值
 * @note
*/
int32_t soh_pack_display_val_get(void)
{
	int32_t retval = 0;
	int32_t temp_array[CELL_VOLT_NUM] = {0};
	int32_t i = 0;

	for (i = 0; i < CELL_VOLT_NUM; i++)
	{
		temp_array[i] = g_cell_soh_vals[i].high_pre;
	}

	retval = (min_array(temp_array, CELL_VOLT_NUM) + THOUTHAND_ROUND_OFF)/FRAC_PRE;

	if(retval > MAX_SOH)
	{
		retval = MAX_SOH;
	}
	else if (retval < MIN_SOH)
	{
		retval = MIN_SOH;
	}
	else
	{
		;
	}

	g_pack_soh_vals.low_pre = retval;
	g_pack_soh_vals.high_pre = min_array(temp_array, CELL_VOLT_NUM);

	return g_pack_soh_vals.low_pre;
}

/**
 * @brief		获取电芯的SOH高精度计算值
 * @param[in]	sel_cmd，获取SOH计算值的命令
 * @return		SOH计算值
 * @note
*/
int32_t soh_high_pre_get(sox_cell_sel_e sel_cmd)
{
	int32_t retval = 0;
	int32_t temp_array[CELL_VOLT_NUM] = {0};
	int32_t i = 0;

	if ((sel_cmd > PACK_IS_SELED)
		|| (sel_cmd == CELL_NUM_IS_SELED))
	{
		retval = MAX_SOH * SOH_CALC_PRE;
	}
	else if (PACK_IS_SELED == sel_cmd)
	{
		for (i = 0; i < CELL_VOLT_NUM; i++)
		{
			temp_array[i] = g_cell_soh_vals[i].high_pre;
		}

		retval = min_array(temp_array, CELL_VOLT_NUM);
	}
	else if (sel_cmd < CELL_NUM_IS_SELED)
	{
		retval = g_cell_soh_vals[sel_cmd].high_pre;
	}

	return retval;
}

/**
 * @brief		获取电芯的SOH实际计算值
 * @param[in]	sel_cmd，获取SOH计算值的命令
 * @return		SOH计算值
 * @note
*/
int32_t soh_calc_val_get(sox_cell_sel_e sel_cmd)
{
	int32_t retval = 0;
	int32_t temp_array[CELL_VOLT_NUM] = {0};
	int32_t i = 0;

	if ((sel_cmd > PACK_IS_SELED)
		|| (sel_cmd == CELL_NUM_IS_SELED))
	{
		retval = MAX_SOH * SOH_CALC_PRE;
	}
	else if (PACK_IS_SELED == sel_cmd)
	{
		for (i = 0; i < CELL_VOLT_NUM; i++)
		{
			temp_array[i] = g_cell_soh_vals[i].calc;
		}

		retval = min_array(temp_array, CELL_VOLT_NUM);
	}
	else if (sel_cmd < CELL_NUM_IS_SELED)
	{
		retval = g_cell_soh_vals[sel_cmd].calc;
	}

	return retval;
}

/**
 * @brief		获取SOH保存标志位
 * @param[in]	无
 * @return		SOH保存标志位
 * @note
 * @pre			无
*/
uint16_t soh_save_flag_get(void)
{
	uint16_t retval = false;

	retval = g_pack_flags.bit.soh_save;

	return retval;
}

/**
 * @brief		重置SOH保存标志位
 * @param[in]	无
 * @return		无
 * @note
 * @pre			无
*/
void soh_save_flag_reset(void)
{
	g_pack_flags.bit.soh_save = false;
}

/**
 * @brief		获取SOH初始化标志位
 * @param[in]	无
 * @return		SOH初始化标志位
 * @note
 * @pre			无
*/
uint16_t soh_init_flag_get(void)
{
	uint16_t retval = false;

	retval = g_pack_flags.bit.init;

	return retval;
}


/**
 * @brief		重置SOH模块，除了定制化接口
 * @param[in]	无
 * @return		无
 * @note
 * @pre			无
*/
void soh_reset(void)
{
	sox_sample_data_t sample_data = {0};
	soh_pack_cur_t soh_pack_cur = {0};
	static soh_pack_calc_para_t soh_pack_calc_paras = {
	.bat_rated_cap = DEFAULTED_RATED_CAP,			///< 电池额定容量
	.cur_under_minus_1A_counter = 0,		///< 电流小于1A的持续时间
	.cycle_storg_stats = {0},		///< 等效循环次数计算所需要的数据
	};
	static soh_pack_flag_u pack_flags = {
	.bit.init = false,				///< SOH初始化标志位
	.bit.proc_init = false,			///< SOH进程初始化标志位
	.bit.soh_save = false,			///< SOH保存标志位，默认为false
	.bit.cell_calc_start = false,	///< 电池各个电芯SOH计算开始标志位
	.bit.cell_calc_done =false,		///< 电池各个电芯SOH计算结束标志位
	.bit.new_cycle = false,			///< 每日结算数据开始统计标志位
};
	sox_running_data_t sox_running_data = {0};
	soh_status_t soh_running_status = {0};
	soh_val_t pack_vals = {0};

	g_sox_sample_data = sample_data;
	g_pack_cur = soh_pack_cur;
	g_pack_calc_paras = soh_pack_calc_paras;
	g_pack_soh_vals = pack_vals;
	g_pack_flags = pack_flags;
	*gp_bms_running_data = sox_running_data;
	g_running_status = soh_running_status;

	pack_flags.bit.proc_init = true;

	memset(g_cell_cycle_storg_stats, 0, CELL_VOLT_NUM*sizeof(cell_cycle_storg_stats_t)/sizeof(int8_t));
	memset(g_cell_fl_volt, 0, CELL_VOLT_NUM*sizeof(volt_fl_t)/sizeof(int8_t));
	memset(g_cell_soh_vals, 0, CELL_VOLT_NUM*sizeof(soh_val_t)/sizeof(int8_t));
	memset(g_cell_calc_paras, 0, CELL_VOLT_NUM*sizeof(soh_cell_calc_para_t)/sizeof(int8_t));
	memset(g_cell_flags, 0, CELL_VOLT_NUM*sizeof(soh_cell_flag_u)/sizeof(int8_t));
}

static void sox_3d_calc_test(int32_t x_value, int32_t y_value, int32_t z_value)
{
	int32_t temp = 0;
	soh_check_temp_rate(x_value, y_value, z_value, &temp);
	log_d("3d_value = %d\n", temp);
}
/**
 * @brief        sox功能样例
 * @param        cmd 功能参数
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
static int soh(int argc, char *argv[])
{
	if (!strcmp(argv[1], "calc"))
	{
		uint8_t calc_mode = atoi(argv[2]); // 1:一维计算 2：二维计算 3：三位计算
		int32_t x_value = atoi(argv[3]);   // x
		int32_t y_value = atoi(argv[4]);   // y
		int32_t z_value = atoi(argv[5]);   // z

		if (calc_mode == 3)
		{
			sox_3d_calc_test(x_value, y_value, z_value);
		}
	}

	return 0;
}
MSH_CMD_EXPORT(soh, <print / calc>);
