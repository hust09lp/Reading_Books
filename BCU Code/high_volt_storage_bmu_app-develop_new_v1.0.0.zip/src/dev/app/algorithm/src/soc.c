/**
 * @file         soc.c
 * @brief        电芯级别的SOC计算及校准
 * @details      电芯级别的SOC计算及校准，引入事件、异常的处理机制，加入事件打印及打印开关
 * @author       SOFAR
 * @date         2024/11/28
 * @version      V1.1
 * @attention 传入电压精度为--1mV
 * @attention 传入电流精度为--1mA
 * @attention 传入温度精度为--1℃
 * @attention 传入RTC精度为--1s
 * @attention 传入Tick精度为--1ms
 * @attention 传出：SOC显示值精度为1%，SOC计算值精度为0.001%
 * @copyright    Copyright(c) 2024 by SofarSolar, All Rights Reserved.
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author    <th>Description
 * <tr><td>2024/11/28  <td>1.1   	 <td>zzc       <td>持续优化，详见git上的更改点
 *
 * </table>
 *
 **********************************************************************************
 */

#include "app_public.h"
#include "sdk.h"
#include "soc.h"
#include "soh.h"
#include "sox_math.h"
#include "sox_sample.h"
#include "sox_stats.h"
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

/************************************************************************/
/*****************************SOC内部数据结构*****************************/
/************************************************************************/

/*********************************************/
/****************PACK级别*********************/
/*********************************************/

/**
  * @enum   soc_pack_flag_u
  * @brief  PACK级：SOC标志位
  */
typedef union
{
	uint16_t soc_all_flag;
	struct
	{
		uint16_t params_init : 1;	///< SOC初始化标志位
		uint16_t proc_init:1;		///< SOC进程初始化标志位
		uint16_t soc_save:1;		///< SOC保存标志位
		uint16_t cell_calc_start:1;	///< 48个电芯SOC计算开始
		uint16_t cell_calc_done:1;	///< 48个电芯SOC计算完成
	}bit;
}soc_pack_flag_u;

/**
  * @union	soc_flow_flag_u
  * @brief	PACK级--记录SOC进程中某一个函数是否已经执行，防止多次进入
  */
typedef union
{
	uint32_t all_flag;
	struct{
		uint32_t over_chg : 1;			//判饱处理
		uint32_t over_dsg : 1;			//判空处理
		uint32_t calc_limit : 1;		//SOC计算值限制
		uint32_t end_refresh : 1;		//SOC显示
		uint32_t chg_dsg_record : 1;	//SOC充放电记录
	}func_flow_flag;
}soc_flow_flag_u;

/**
  * @struct   soc_pack_cur_t
  * @brief    PACK级：SOC用到的的电流采样数据及其衍生数据
  */
typedef struct
{
	cur_fl_t fl_signal;						///< 滤波后的SOX采样信号，精度：1mA
	int32_t fl_cur_array[_60S_BASE_1S];		///< 保存最近60秒滤波后的电流值，精度:1mA
	int8_t fl_cur_array_index;				///< 电流滤波值数组的索引，始终指向下一个需要保存的位置
}soc_pack_cur_t;

/**
  * @struct   soc_pack_calc_para_t
  * @brief    PACK级：SOC用到的逻辑判断、计算相关的参数
  */
typedef struct
{
	uint32_t bat_state_record_time;				///< BAT上一次状态的时间，精度：1ms
	int32_t fl_coff;							///< 电压电流一阶滤波系数，精度：0.01
	sox_bat_status_e bat_state;					///< BMS上一次的状态
	int32_t bat_rated_cap;						///< 电池的额定容量，精度：1Ah
	int32_t cur_after_loss_temp;				///< SOX损耗补偿电流，精度：1mA
	int32_t cur_standby_duration;				///< 记录电流的绝对值小于0.2A的持续时间，精度：1S
	uint8_t overvolt_alarm_lasttime;			///< 上一次过压告警的状态
	uint8_t overvolt_alarm_raiseup_flag;		///< 过压告警上升沿标志
	uint8_t local_dsg_empty_lasttime;			///< 上一次本地电池放电放空的状态
	uint8_t local_dsg_empty_raiseup_flag;		///< 本地电池放空上升沿标志
	int8_t local_soc_duration;					///< 本地上送SOC剩余时间，默认10秒
	uint8_t can_dsg_empty_lasttime;				///< 上一次从CAN接收到的电池放电放空的状态
	uint8_t can_dsg_empty_raiseup_flag;			///< 从CAN接收到的电池放空上升沿标志
	int8_t can_soc_wait_time;					///< 从CAN获取SOC等待时间，默认5秒
	uint16_t can_soc_get;						///< 从CAN获取的SOC数值
	int32_t under_volt_table_time;				///< 电压处于u_table之下（SOC==10%）的持续时间，精度：1S
	int32_t this_pack_soc_drop;					///< 本台PACK的各电芯需要下降多少SOC，精度：0.001%
	sox_scroll_record_data_t* p_cell_volt_5s_array;  ///< 指向5秒电芯数据地址的指针
	uint8_t display_time;						///< PACK的SOC显示值更新时间，精度：1S
	int16_t cell_calc_index;					///< 当前电芯计算的索引
	int16_t cell_calc_cycle;					///< 记录这是t时刻计算开始后的第几个周期
	uint16_t upload_to_other_bmu_soc;			///< 需要向其它BMU上送的SOC数值
	sox_bms_status_e pack_shut_last_time;		///< 记录电池上一次的关机状态
	bool pack_shut_raiseup_flag;				///< 捕捉关机信号的上升沿
	bool there_is_5s_volt;						///< 是否存在5秒电芯电压数据
}soc_pack_calc_para_t;

/**
  * @struct   soc_val_t
  * @brief    PACK、CELL通用--SOC计算值、显示值等
  */
typedef struct
{
	int32_t calc_val;		///< SOC计算值，精度：0.001%
	float   calc_val_last;	///< 上一次的SOC计算值
	int32_t calc_val_save;	///< 上一次保存的SOC计算值，精度：0.001%
	int32_t display_val;	///< SOC显示值，精度：1%
}soc_val_t;

static dsg_cali_data_t g_tx_dsg_cali_data = {
	.can_soc_min_to_volt = 0xFFFF,
	.can_calc_val = 0xFFFF,
	.can_min_cell_volt = 0xFFFF
};

/*********************************************/
/****************CELL级别*********************/
/*********************************************/

/**
  * @enum   soc_cell_flag_u
  * @brief  CELL的SOC标志位类型
  */
typedef union
{
	uint16_t soc_all_flag;
	struct
	{
		uint16_t overchg : 1;		///< 过充标志位
		uint16_t overdsg : 1;		///< 过放标志位
	}bit;
}soc_cell_flag_u;

/**
  * @struct   soc_cell_calc_para_t
  * @brief    CELL级：SOC用到的逻辑判断、计算相关的参数
  */
typedef struct
{
	sox_rtc_t ocv_cali_record_time;		///< 最近一次OCV静置校准的时间，精度：年月日时分秒
	int32_t overchg_duration;			///< 记录最高电芯电压大于3.6V的持续时间，精度：1S
	int32_t overdsg_duration;			///< 记录最低电芯电压<=2.8V的持续时间，精度：1S
	int32_t soc_calc_upper_limit;		///< SOC计算值上限，精度：1%
	int32_t soc_calc_lower_limit;		///< SOC计算值下限，精度：1%
	uint32_t calc_last_time;			///< 上一次安时积分的时间，用于计算两次安时积分之间的时间差，精度：1ms
	float mAs_accum;					///< 保存安时积分的mAs，精度：mAs
	int32_t mAms_accum;					///< 保存安时积分的mAms，精度：mAms
	int32_t truncation_error;			///< 计算SOC中的截断误差
	bool soc_calc_inited;				///< SOC计算的初始标志位
	uint16_t cell_max_volt_past_5s;		///< 电芯过去5秒内的最大电芯电压，精度：1mV
}soc_cell_calc_para_t;

/************************************************************************************************/
/*******************************************SOC模块需要的宏定义***********************************/
/************************************************************************************************/

//PACK_ocv_to_soc一维表长度
#define PACK_OCV_LENGTH 21		///< PACK的OCV长度
#define PACK_SOC_LENGTH 21		///< PACK的SOC长度

//U_table三维表长度
#define U_TABLE_DIMENSION 3		///< U_table表的维度
#define U_TABLE_SOC_LENGTH 13	///< U_table表的SOC维度
#define U_TABLE_CUR_LENGTH 4	///< U_table表的电流维度
#define U_TABLE_TEMP_LENGTH 4	///< U_table表的温度维度

//10A、不同温度下，SOC==99%对应的电压
#define BOUND_TEMP_LENGTH 4		///< 边界处温度的长度
#define BOUND_VOLT_LENGTH 4		///< 边界处电压的长度

//SOC显示上下限
#define FULL_HIGHEST_SOC 100	///< 满充状态下的最高SOC
#define NON_FULL_HIGHEST_SOC 99	///< 非满充状态下的最高SOC
#define EMPTY_LOWEST_SOC 0		///< 放空状态下的最低SOC
#define NON_EMPTY_LOWEST_SOC 1	///< 非放空状态下的最低SOC

//SOC初始化
#define PACK_60_SOC_TO_OCV	52816*3		///< 电池包60%SOC对应的总压
#define CELL_60_SOC_TO_OCV 3301			///< 电芯60%SOC对应的总压

//SOC一阶滤波
#define SOC_FIL_COFF 0.05		///< 一阶滤波系数,t时刻数据的占比

//长时间未使用
#define RTC_DFT_YERA    23
#define RTC_DFT_MONTH   7
#define RTC_DFT_DATE    7
#define RTC_DFT_HOUR    8
#define RTC_DFT_HOUR_SUM ((RTC_DFT_YERA*365 + RTC_DFT_MONTH*30 + RTC_DFT_DATE)*24 + RTC_DFT_HOUR)
#define LONG_TIME_NO_USE_DAYS 30		///< 30天未使用

//充放电时间记录
#define CHG_DSG_RECORD_CUR_LIMIT 1000	///< 小于1000mA，认为未进行充放电
#define CHG_DSG_RECORD_MIN 20			///< 20分钟小于1000mA，记录该时间

//判饱及判饱退出条件
#define EXIT_FULL_CUR (-500)		///< 退出判饱的电流条件
#define EXIT_FULL_VOLT 3320			///< 退出判饱的电压条件
#define EXIT_FULL_AH 1				///< 退出判饱的AH条件
#define FULL_MAINTAIN_HOURS 12

#define FULLCHG_VOLT    CELL_FULL_CHG_VOL			///< 满充电压
#define FULLCHG_DURATION_LIMIT 5	///< 超过满充电压持续时间

//判空及判空退出判断条件
#define DSGEMPTY_DURATION_LIMIT 1
#define DSGEMPTY_VOLT_LIMIT 2700

//静置校准条件
#define STANDBY_CUR_LIMIT 300
#define STANDBY_CUR_MAINTAIN_HOURS 12
#define STANDBY_MAINTAIN_HOURS 12

//损耗补偿条件
#define LOSS_CHG_STOP_CUR 0

//末端校准条件
#define CHG_CALI_CUR (0.12f*DEFAULTED_RATED_CAP*1000)
#define CHG_CALI_TEMP 10
#if PACK_64S_PRJ
#define CHG_CALI_VOLT 3550
#define CHG_CALI_U_TABLE 3550
#else
#define CHG_CALI_VOLT 3500
#define CHG_CALI_U_TABLE 3500
#endif


//放电校准条件
#define DSG_CALI_SOC 10
#define DSG_CALI_TEMP 15
#define DSG_CALI_UPPER_CUR (-0.1f*DEFAULTED_RATED_CAP*1000)
#if PACK_64S_PRJ
#define DSG_CALI_LOWER_CUR (-1.1f*DEFAULTED_RATED_CAP*1000)
#else
#define DSG_CALI_LOWER_CUR (-0.6f*DEFAULTED_RATED_CAP*1000)
#endif
#define DSG_CALI_UNDER_U_TABLE 5
#define DSG_CALI_CUR_DIFF 10000
#define DSG_CALI_CUR_2 (-0.06f*DEFAULTED_RATED_CAP*1000)
#define DSG_CALI_VOLT_2 2900

#define DSG_LOCAL_WATING_TIME 10
#define DSG_CAN_WATING_TIME 30

//充电校准上下限
#define SOC_CALC_CHG_CALI_UPPER_LIMIT 5		//注意，这里要用乘法
#define SOC_CALC_CHG_CALI_UNDER_LIMIT 2		//注意，这里要用除法

//放电校准上下限
#define SOC_CALC_DSG_CALI_UPPER_LIMIT 2		//注意，这里要用除法
#define SOC_CALC_DSG_CALI_UNDER_LIMIT 1		//注意，这里要用除法

//SOC显示值相关
#define SOC_DISPLAY_TIME_LIMIT 10
#define SOC_DISPLAY_CUR_UPPER_LIMIT 300
#define SOC_DISPLAY_CUR_UNDER_LIMIT (-150)

//SOC保存
#define SOC_SAVE_DIFF 5

//SOC5秒电芯数据获取
#define SOC_CELL_VOLT_GET_COUNT 5
#define SOC_CELL_CUR_GET_COUNT 60

//SOC状态机的状态数量
#define FSM_MAC_NUM 13

/************************************************************************************************/
/******************************SOX电芯级别计算状态机相关数据结构***********************************/
/************************************************************************************************/
/**
 * @struct sox_fsm_state_e
 * @brief SOX计算状态机--状态
 */
typedef enum
{
	CALC_INIT = 0u,		///< SOC初始化
	CALC_START = 1u,	///< t时刻的SOC计算开始
	CALC_RUNNING = 2u,	///< t时刻的SOC计算进行中
	CALC_DONE = 3U,		///< t时刻的SOC计算完成
	CALC_DELAY = 4u,	///< t时刻的SOC计算延时
}sox_fsm_state_e;

/**
 * @struct sox_fsm_event_e
 * @brief SOX计算状态机--事件
 */
typedef enum
{
	REACHED_CALC_DONE = 0u,			///< 到达t+1时刻，计算完成
	REACHED_CALC_RUNNING = 1u,		///< 到达t+1时刻，没有计算完成
	APPROCHING_CALC_DONE = 2u,		///< 没有到达t+1时刻，计算完成
	APPROCHING_CALC_RUNNING = 3u,	///< 没有到达t+1时刻，没有计算完成
	EVENTS_MAX_NUM = 4u,			///< SOX状态机事件的最大值
}sox_fsm_event_e;

typedef void(*pfeventhandler)(void);		//处理事件的函数

/**
 * @struct sox_fsm_trans_t
 * @brief SOX电芯级别计算状态机--状态转换
 */
typedef struct
{
	sox_fsm_state_e cur_state;	///< 当前状态
	sox_fsm_event_e event;		///< 事件
	sox_fsm_state_e next_state;	///< 下一个状态
	pfeventhandler handler;		///< 处理函数
}sox_fsm_trans_t;

/**
 * @struct sox_fsm_machine_t
 * @brief SOX电芯级别计算状态机--单个状态机
 */
typedef struct
{
	sox_fsm_state_e cur_state;	///< 当前状态
	int32_t transnum;			///< 状态切换的总数量
	sox_fsm_trans_t* trans;		///< 状态转换
}sox_fsm_machine_t;

/************************************************************************/
/***************************静态全局量初始化*******************************/
/************************************************************************/

/****************************PACK级别变量初始化***************************/
static sox_scroll_record_data_t          g_sox_scroll_record_data = {0};         //滚动记录的数据:电芯电压 电流
static uint8_t                           g_enter_proc_vol_index = 0;             //滑窗电压指针 1S一次 5S以后保持在_5S_BASED_1S
static uint8_t                           g_enter_proc_curr_index = 0;            //滑窗电流指针 1S一次 60S以后保持在_60S_BASED_1S

/**
  * @struct   sox_sample_data_t
  * @brief    PACK级：SOX用到的采样数据
  */
static sox_sample_data_t g_sox_sample_data = {0};

/**
  * @struct   sox_interface_remap_t
  * @brief    PACK级：外部定制化函数
  */
static sox_interface_remap_t g_sox_interface_remap = {0};

/**
  * @struct   sox_running_data_t
  * @brief    PACK级：BMS运行数据
  */
static sox_running_data_t g_bms_running_data = {0};

/**
  * @struct   soc_status_t
  * @brief    PACK级：SOC模块运行状态状态
  */
static soc_status_t g_running_status = {0};

/**
  * @struct   soc_val_t
  * @brief    PACK级：SOC计算值、显示值等
  */
static soc_val_t g_pack_soc_vals = {0};

/**
  * @struct   soc_pack_cur_t
  * @brief    PACK级：SOC用到的的电流采样数据及其衍生数据
  */
static soc_pack_cur_t g_pack_cur = {0};

/**
  * @struct   soc_pack_calc_para_t
  * @brief    PACK级：SOC用到的逻辑判断、计算相关的参数
  */
static soc_pack_calc_para_t g_pack_calc_paras = {
	.bat_state_record_time = 0,				///< BMS上一次状态的时间
	.bat_state = SOX_BAT_STANDBY,			///< BMS上一次的状态
	.fl_coff = SOC_FIL_COFF,				///< 电压电流一阶滤波系数
	.bat_rated_cap = DEFAULTED_RATED_CAP,	///< 电池额定容量
	.cur_after_loss_temp = 0,				///< SOX损耗补偿电流
	.cur_standby_duration = 0,				///< 记录电流的绝对值小于0.2A的持续时间
	.overvolt_alarm_lasttime = 0,			///< 上一次过压告警的状态
	.overvolt_alarm_raiseup_flag = false,	///< 过压告警上升沿标志
	.local_dsg_empty_lasttime = false,			///< 上一次电池放电放空的状态
	.local_dsg_empty_raiseup_flag = false,		///< 电池放空上升沿标志
	.local_soc_duration = -1,
	.can_dsg_empty_lasttime = false,
	.can_dsg_empty_raiseup_flag = false,
	.can_soc_wait_time = -1,
	.can_soc_get = 0,
	.this_pack_soc_drop = 0,				///< 本台PACK的各电芯需要下降多少SOC
	.p_cell_volt_5s_array = NULL,			///< 指向5秒电芯数据地址的指针
	.display_time = 0,						///< PACK的SOC显示值更新时间
	.cell_calc_index = 0,					///< 当前电芯计算的索引
	.cell_calc_cycle = 0,					///< 记录这是t时刻计算开始后的第几个周期
	.pack_shut_raiseup_flag = false,		///< 捕捉关机信号的上升沿
	.pack_shut_last_time = SOX_BMS_RUN,		///< 记录电池上一次的关机状态
	.there_is_5s_volt = false,				///< 存在5秒电芯电压数据
	.upload_to_other_bmu_soc = 0,
};

/**
  * @struct   soc_pack_flag_u
  * @brief    PACK级：SOC逻辑判断中的标志位
  */
static soc_pack_flag_u g_pack_flags = {
	.bit.params_init = false,
	.bit.proc_init = false,
	.bit.soc_save = false,
	.bit.cell_calc_start = true,
	.bit.cell_calc_done = false,
};

/**
  * @struct   soc_flow_flag_u
  * @brief    PACK级：记录函数执行流程
  */
static soc_flow_flag_u g_pack_flow_flags = {0};

/****************************CELL级别变量初始化***************************/
/**
  * @struct   volt_fl_t
  * @brief    CELL级：电芯电压的滤波值
  */
static volt_fl_t g_cell_fl_volt[CELL_VOLT_NUM] = {0};

/**
  * @struct   soc_val_t
  * @brief    CELL级：SOC计算值、显示值等
  */
static soc_val_t g_cell_soc_vals[CELL_VOLT_NUM] = {0};

/**
  * @struct   soc_cell_calc_para_t
  * @brief    CELL级：SOC用到的逻辑判断、计算相关的参数
  */
static soc_cell_calc_para_t g_cell_calc_paras[CELL_VOLT_NUM] = {0};

/**
  * @struct   soc_cell_flag_u
  * @brief    CELL级：SOC逻辑判断中的标志位
  */
static soc_cell_flag_u g_cell_flags[CELL_VOLT_NUM] = {0};

/************************************************************************/
/******************************SOC使用到的表格****************************/
/************************************************************************/

/*******************表格1---横坐标：CELL_OCV电压；纵坐标：SOC**************/
//PACK_OCV->SOC表的横坐标
static const int32_t cell_ocv_tab[PACK_OCV_LENGTH] =
{
	2800 ,	2923 ,	3005 ,	3065 ,	3112 ,
	3150 ,	3205 ,	3242 ,	3276 ,	3290 ,
	3291 ,	3294 ,	3330 ,	3331 ,	3332 ,	3332 ,
	3332 ,	3333 ,	3333 ,	3333 ,	3380 ,
};

//PACK_OCV->SOC表的纵坐标
//这里可能会造成BUG的一个点，如果为了节省空间用int8_t类型的数据，
//在和其它数进行比较时，会被强制转换成其它类型，比如int32_t类型的数据
//这样默认准换后，按理说高位是0，但是不同的编译器处理方式不同，可能会造成BUG
static const int32_t cell_soc_tab[PACK_SOC_LENGTH] = {
	0, 		1000, 	2000, 	3000, 	4000,
	5000, 	10000, 	20000, 	30000, 	40000,
	50000, 	60000, 	70000, 	80000, 	90000,	95000,
	96000, 	97000, 	98000, 	99000, 	100000,
};

/*********************表格2---三维表格，通过SOC、电流、温度查阅电压*****************/
//U_table三维表索引：SOC、电流、温度
static const int32_t utab_index_tab[U_TABLE_DIMENSION][U_TABLE_SOC_LENGTH] =
{
	{0, 1000, 2000, 3000, 4000, 5000, 6000,
	7000, 8000, 9000, 10000, 11000, 12000},
	{10000, 20000, 30000, 50000},
	{15, 25, 35, 45},
};

//U_table三维表
static const int32_t utab_tab[U_TABLE_TEMP_LENGTH][U_TABLE_CUR_LENGTH][U_TABLE_SOC_LENGTH] =
{
	{
	//  0%      1%      2%      3%      4%      5%      6%
	//	7%      8%      9%     10%     11%      12%
		{2700 ,	2868 ,	2964 ,	3030 ,	3078 ,	3111 ,	3130 ,
		3141 ,	3147 ,	3151 ,	3155 ,	3158 ,	3160} ,
		{2700 ,	2835 ,	2932 ,	3001 ,	3048 ,	3079 ,	3099 ,
		3112 ,	3121 ,	3127 ,	3133 ,	3137 ,	3141} ,
		{2700 ,	2810 ,	2897 ,	2965 ,	3015 ,	3049 ,	3072 ,
		3088 ,	3100 ,	3108 ,	3115 ,	3121 ,	3126} ,
		{2700 ,	2791 ,	2865 ,	2928 ,	2977 ,	3013 ,	3039 ,
		3058 ,	3071 ,	3082 ,	3090 ,	3097 ,	3103} ,
	},
	{
		{2700 ,	2877 ,	2973 ,	3040 ,	3091 ,	3130 ,	3152 ,
		3160 ,	3164 ,	3167 ,	3169 ,	3170 ,	3172} ,
		{2700 ,	2866 ,	2961 ,	3027 ,	3077 ,	3113 ,	3133 ,
		3143 ,	3148 ,	3152 ,	3155 ,	3157 ,	3159} ,
		{2700 ,	2858 ,	2952 ,	3017 ,	3065 ,	3098 ,	3117 ,
		3127 ,	3134 ,	3138 ,	3142 ,	3145 ,	3148} ,
		{2700 ,	2844 ,	2937 ,	3001 ,	3045 ,	3074 ,	3092 ,
		3103 ,	3110 ,	3116 ,	3121 ,	3125 ,	3128} ,
	},
	{
	//  0%      1%      2%      3%      4%      5%      6%
	//	7%      8%      9%     10%     11%      12%
		{2700 ,	2879 ,	2975 ,	3042 ,	3094 ,	3134 ,	3159 ,
		3167 ,	3170 ,	3173 ,	3174 ,	3176 ,	3177} ,
		{2700 ,	2873 ,	2968 ,	3034 ,	3085 ,	3125 ,	3148 ,
		3156 ,	3160 ,	3162 ,	3164 ,	3166 ,	3168} ,
		{2700 ,	2867 ,	2960 ,	3027 ,	3078 ,	3116 ,	3137 ,
		3145 ,	3149 ,	3153 ,	3155 ,	3157 ,	3159} ,
		{2700 ,	2855 ,	2947 ,	3012 ,	3061 ,	3097 ,	3116 ,
		3125 ,	3130 ,	3134 ,	3137 ,	3140 ,	3142} ,
	},
	{
		{2700 ,	2878 ,	2974 ,	3041 ,	3093 ,	3134 ,	3161 ,
		3170 ,	3173 ,	3176 ,	3177 ,	3178 ,	3180} ,
		{2700 ,	2873 ,	2969 ,	3036 ,	3087 ,	3127 ,	3153 ,
		3161 ,	3165 ,	3167 ,	3169 ,	3170 ,	3172} ,
		{2700 ,	2869 ,	2964 ,	3030 ,	3081 ,	3121 ,	3145 ,
		3153 ,	3157 ,	3159 ,	3161 ,	3163 ,	3165} ,
		{2700 ,	2861 ,	2953 ,	3018 ,	3068 ,	3107 ,	3128 ,
		3136 ,	3140 ,	3144 ,	3146 ,	3148 ,	3150} ,
	},
};

/*********************表格3---一维表格，通过温度查询边界电压*****************/
//温度索引
static const int32_t temp_index_tab[BOUND_TEMP_LENGTH] = {15, 25, 35, 45};

//SOC == 99%、充电电流 == 10A情况下，不同温度对应的单体电压一维表
static const int32_t bound_volt_tab[BOUND_VOLT_LENGTH] = {3512, 3465, 3459, 3463};


/************************************************************************/
/**************************部分需要提前声明的函数**************************/
/************************************************************************/
static int8_t soc_params_init(void);
static void soc_judge_term_refresh(void);

/**
 * @brief		SOC信号一阶滤波迭代（电压、电流）
 * @param[in]	无
 * @return		SOC_OK，执行成功，SOC_FAIL，失败
 * @note
*/
static int8_t soc_first_order_filter(void)
{
	int8_t retval = SOX_OK;
	int32_t i = 0;

	/*****************************各个电芯电压的一阶滤波****************************/
	for (i = 0; i < CELL_VOLT_NUM; i++)
	{
		float filter_volt = (1- SOC_FIL_COFF) * g_cell_fl_volt[i].volt_last_time +
			SOC_FIL_COFF * g_sox_sample_data.cell_volt[i];
		g_cell_fl_volt[i].volt_this_time = (int32_t)filter_volt;
		//更新电芯电压滤波值（t-1时刻）
		g_cell_fl_volt[i].volt_last_time = filter_volt;
	}

	/*****************************电芯电流的一阶滤波****************************/
    float filter_cur = (1- SOC_FIL_COFF) * g_pack_cur.fl_signal.cur_last_time +
        SOC_FIL_COFF * g_sox_sample_data.sys_cur;

	g_pack_cur.fl_signal.cur_this_time = (int32_t)filter_cur;
	//更新--保存最近60秒电流数据的数组
	if (g_pack_cur.fl_cur_array_index >= _60S_BASE_1S)
	{
		g_pack_cur.fl_cur_array_index = 0;
	}
	g_pack_cur.fl_cur_array[g_pack_cur.fl_cur_array_index] = g_pack_cur.fl_signal.cur_this_time;
    g_pack_cur.fl_cur_array_index++;
	//更新电流滤波值（t-1时刻）
	g_pack_cur.fl_signal.cur_last_time = filter_cur;

	return retval;
}

/**
 * @brief		SOC损耗补偿
 * @param[in]	无
 * @return		SOC_OK，需要补偿；SOC_FAIL，不需要补偿
 * @note
*/
static int8_t soc_loss_comp(void)
{
	int8_t retval = SOX_FAIL;
	int8_t is_matching = false;

	//读取充放电限流值
	limit_params_t limit_params = {0};
	g_sox_interface_remap.sox_limit_params_get(&limit_params);

	//损耗补偿的判定条件
	is_matching = ((LOSS_CHG_STOP_CUR == limit_params.chg_stop_cur)
		&& (g_sox_sample_data.sys_cur >= LOSS_CUR_UNDER_LIMIT))
		|| ((limit_params.chg_stop_cur != LOSS_CHG_STOP_CUR)
		&& (abs(g_sox_sample_data.sys_cur) <= LOSS_CUR_UPPER_LIMIT));

	if (true == is_matching)
	{
		retval = SOX_OK;
		g_pack_calc_paras.cur_after_loss_temp = LOSS_CUR;
		g_running_status.pack_events.bit.loss_temp = true;
	}
	else
	{
		retval = SOX_FAIL;
		g_pack_calc_paras.cur_after_loss_temp = g_sox_sample_data.sys_cur;
		g_running_status.pack_events.bit.loss_temp = false;
	}

	return retval;
}

/**
 * @brief		判断采样值是否超出边界
 * @param[in]	无
 * @return		无
 * @note		如果采样值超出范围，会在运行状态中记录该异常
*/
static void soc_sample_over_judge(void)
{
	int32_t temp = false;

	//系统采样电流范围：[-420A，420A]
	if (g_sox_sample_data.sys_cur < SOX_SAMPLE_LOWER_CUR)
	{
		temp = true;
		g_sox_sample_data.sys_cur = SOX_SAMPLE_LOWER_CUR;
	}
	else if (g_sox_sample_data.sys_cur > SOX_SAMPLE_UPPER_CUR)
	{
		temp = true;
		g_sox_sample_data.sys_cur = SOX_SAMPLE_UPPER_CUR;
	}

	//PACK总压范围：[115.2V，192V]
	if (g_sox_sample_data.pack_volt < SOX_SAMPLE_LOWER_PACK_VOLT)
	{
		temp = true;
		g_sox_sample_data.pack_volt = SOX_SAMPLE_LOWER_PACK_VOLT;
	}
	else if (g_sox_sample_data.pack_volt > SOX_SAMPLE_UPPER_PACK_VOLT)
	{
		temp = true;
		g_sox_sample_data.pack_volt = SOX_SAMPLE_UPPER_PACK_VOLT;
	}

	//最小电芯电压范围：[2400mV，4000mV]
	if (g_sox_sample_data.min_cell_volt < SOX_SAMPLE_LOWER_MIN_CELL_VOLT)
	{
		temp = true;
		g_sox_sample_data.min_cell_volt = SOX_SAMPLE_LOWER_MIN_CELL_VOLT;
	}
	else if (g_sox_sample_data.min_cell_volt > SOX_SAMPLE_UPPER_MIN_CELL_VOLT)
	{
		temp = true;
		g_sox_sample_data.min_cell_volt = SOX_SAMPLE_UPPER_MIN_CELL_VOLT;
	}

	//最小电芯温度范围：[-40℃，65℃]
	if (g_sox_sample_data.min_cell_temp < SOX_SAMPLE_LOWER_MIN_CELL_TEMP)
	{
		temp = true;
		g_sox_sample_data.min_cell_temp = SOX_SAMPLE_LOWER_MIN_CELL_TEMP;
	}
	else if (g_sox_sample_data.min_cell_temp > SOX_SAMPLE_UPPER_MIN_CELL_TEMP)
	{
		temp = true;
		g_sox_sample_data.min_cell_temp = SOX_SAMPLE_UPPER_MIN_CELL_TEMP;
	}

	//最大电芯电压范围：[2400mV，4000mV]
	if (g_sox_sample_data.max_cell_volt < SOX_SAMPLE_LOWER_MAX_CELL_VOLT)
	{
		temp = true;
		g_sox_sample_data.max_cell_volt = SOX_SAMPLE_LOWER_MAX_CELL_VOLT;
	}
	else if (g_sox_sample_data.max_cell_volt > SOX_SAMPLE_UPPER_MAX_CELL_VOLT)
	{
		temp = true;
		g_sox_sample_data.max_cell_volt = SOX_SAMPLE_UPPER_MAX_CELL_VOLT;
	}

	//平均电芯电压范围：[2400mV，4000mV]
	if (g_sox_sample_data.avg_cell_volt < SOX_SAMPLE_LOWER_AVG_CELL_VOLT)
	{
		temp = true;
		g_sox_sample_data.avg_cell_volt = SOX_SAMPLE_LOWER_AVG_CELL_VOLT;
	}
	else if (g_sox_sample_data.avg_cell_volt > SOX_SAMPLE_UPPER_AVG_CELL_VOLT)
	{
		temp = true;
		g_sox_sample_data.avg_cell_volt = SOX_SAMPLE_UPPER_AVG_CELL_VOLT;
	}

	//平均电芯温度范围：[-40℃，65℃]
	if (g_sox_sample_data.avg_cell_temp < SOX_SAMPLE_LOWER_AVG_CELL_TEMP)
	{
		temp = true;
		g_sox_sample_data.avg_cell_temp = SOX_SAMPLE_LOWER_AVG_CELL_TEMP;
	}
	else if (g_sox_sample_data.avg_cell_temp > SOX_SAMPLE_UPPER_AVG_CELL_TEMP)
	{
		temp = true;
		g_sox_sample_data.avg_cell_temp = SOX_SAMPLE_UPPER_AVG_CELL_TEMP;
	}

	g_running_status.errors.bit.sample_over_limit = temp;
}

/**
* @brief		SOC显示值更新
 * @param[in]	无
 * @return		true，更新成功；false，更新失败
 * @note
*/
static int8_t soc_val_display(void)
{
	int8_t retval = true;
	int32_t cell_soc_array[CELL_VOLT_NUM] = {0};
	int32_t i = 0;
	int32_t temp_min = 0;
	int32_t temp_max = 0;

	//更新PACK的SOC计算值
	for (i = 0; i < CELL_VOLT_NUM; i++)
	{
		cell_soc_array[i] = g_cell_soc_vals[i].calc_val;
	}

	temp_min = min_array(cell_soc_array,CELL_VOLT_NUM);
	temp_max = max_array(cell_soc_array,CELL_VOLT_NUM);

	//除零保护 和 负数防护
	if (0 >= 100 * FRAC_PRE - temp_max + temp_min)
	{
		g_pack_soc_vals.calc_val = temp_min;
	}
	//如果一切正常，就给PACK的SOC赋初始值，但是精度只有0.1%，产生了截断
	//该值仍然大于设计书上的对外显示精度（1%）
	else
	{
		g_pack_soc_vals.calc_val = temp_min * FRAC_PRE / (100 * FRAC_PRE - temp_max + temp_min) * 100;
	}

	//每10秒最多变化1%
	if (++g_pack_calc_paras.display_time >= SOC_DISPLAY_TIME_LIMIT)
	{
		//如果电流 > -150mA，SOC计算值可以上升，稍微下降了SOC上升的限制
		if ((g_pack_soc_vals.calc_val + THOUTHAND_ROUND_OFF)/FRAC_PRE > g_pack_soc_vals.display_val)
		{
			if (g_sox_sample_data.sys_cur >= SOC_DISPLAY_CUR_UNDER_LIMIT)
			{
				g_pack_soc_vals.display_val = g_pack_soc_vals.display_val + 1;
				g_pack_calc_paras.display_time = 0;
			}
			else
			{
				;
			}
		}
		//如果电流 < 300mA，SOC计算值就可以下降，稍微放宽了SOC下降的限制
		else if ((g_pack_soc_vals.calc_val + THOUTHAND_ROUND_OFF)/FRAC_PRE < g_pack_soc_vals.display_val)
		{
			if (g_sox_sample_data.sys_cur <= SOC_DISPLAY_CUR_UPPER_LIMIT)
			{
				if (g_pack_soc_vals.calc_val > NON_FULL_HIGHEST_SOC*SOC_CALC_PRE)
				{
					g_pack_soc_vals.display_val = FULL_HIGHEST_SOC;
					g_pack_calc_paras.display_time = 0;
				}
				else
				{
					g_pack_soc_vals.display_val = g_pack_soc_vals.display_val - 1;
					g_pack_calc_paras.display_time = 0;
				}
			}
			else
			{
				;
			}
		}
	}

	return retval;
}

/**
 * @brief		状态机：初始化到开始
 * @param[in]	无
 * @return		无
 * @note		初始化状态对应刚开机，处于初始化状态，不论什么事件，都会切换为开始状态
 * @note		开始状态会进行以下操作，部分操作会因为异常而跳过：
 * @note		1、获取SOX采样数据
 * @note		2、采样数据范围判断
 * @note		3、SOC初始化
 * @note		4、一阶滤波
 * @note		5、判断条件刷新
 * @note		6、损耗补偿
 * @note		7、SOC刷新
 * @note		8、电芯计算参数和状态的重置
*/
static void init_to_start(void)
{
	int32_t temp = 0;
	int32_t cell_index = 0;

	temp = sox_sample_data_get(&g_sox_sample_data);	//获取SOX采样数据

	//采样数据获取失败，则会置位相应的标志位
	if (SOX_FAIL == temp)
	{
		g_running_status.errors.bit.sample_get_failed = true;

		for (cell_index = 0; cell_index < CELL_VOLT_NUM; cell_index++)
		{
			g_cell_calc_paras[cell_index].soc_calc_inited = false;
		}
	}
	else if (false == g_pack_flags.bit.proc_init)
	{
		g_running_status.pack_events.bit.proc_initialized = false;

		for (cell_index = 0; cell_index < CELL_VOLT_NUM; cell_index++)
		{
			g_cell_calc_paras[cell_index].soc_calc_inited = false;
		}
	}
	else
	{
		soc_sample_over_judge();			//采样数据超范围判断
		soc_params_init();							//SOC初始化

		if (false == g_running_status.errors.bit.sample_over_limit)
		{
			soc_first_order_filter();		//SOC数据一阶滤波
			soc_judge_term_refresh();		//整个PACK的判断条件刷新
			soc_loss_comp();				//损耗补偿
		}

		soc_val_display();					//SOC显示
	}

	//如果新的电芯计算周期开始，从1号电芯开始计算
	g_pack_calc_paras.cell_calc_index = 0;
	g_pack_calc_paras.cell_calc_cycle = 0;
	memset(&g_pack_flow_flags, 0, sizeof(soc_flow_flag_u)/sizeof(int8_t));

	g_pack_flags.bit.cell_calc_start = true;	//48个电芯计算启动
	g_pack_flags.bit.cell_calc_done = false;	//48个电芯计算未完成
}

/**
 * @brief		状态机：开始到运行
 * @param[in]	无
 * @return		无
 * @note		开始到运行，会切换到下一个电芯进行计算
*/
static void start_to_running(void)
{
	g_pack_calc_paras.cell_calc_index++;
	g_pack_flags.bit.cell_calc_done = false;
}

/**
 * @brief		状态机：运行到完成
 * @param[in]	无
 * @return		无
 * @note		电芯全部计算完成，会更新电芯计算状态机的状态
*/
static void running_to_done(void)
{
	g_pack_flags.bit.cell_calc_start = false;
	g_pack_flags.bit.cell_calc_done = true;
}

/**
 * @brief		状态机：运行到运行
 * @param[in]	无
 * @return		无
 * @note		继续下一个电芯的计算
*/
static void running_to_running(void)
{
	g_pack_calc_paras.cell_calc_index++;
	g_pack_flags.bit.cell_calc_done = false;
}

/**
 * @brief		状态机：运行到延迟
 * @param[in]	无
 * @return		无
 * @note		继续下一个电芯的计算
*/
static void running_to_delay(void)
{
	g_pack_calc_paras.cell_calc_index++;
	g_pack_flags.bit.cell_calc_done = false;
}

/**
 * @brief		状态机：延迟到延迟
 * @param[in]	无
 * @return		无
 * @note		继续下一个电芯的计算
*/
static void delay_to_delay(void)
{
	g_pack_calc_paras.cell_calc_index++;
	g_pack_flags.bit.cell_calc_done = false;
}

/**
 * @brief		状态机：延迟到开始
 * @param[in]	无
 * @return		无
 * @note		开始状态会进行以下操作，部分操作会因为异常而跳过：
 * @note		1、获取SOX采样数据
 * @note		2、采样数据范围判断
 * @note		3、SOC初始化
 * @note		4、一阶滤波
 * @note		5、判断条件刷新
 * @note		6、损耗补偿
 * @note		7、SOC刷新
 * @note		8、电芯计算参数和状态的重置
*/
static void delay_to_start(void)
{
	int32_t temp = 0;
	int32_t cell_index = 0;

	temp = sox_sample_data_get(&g_sox_sample_data);	//获取SOX采样数据

	//采样数据获取失败，则会置位相应的标志位
	if (SOX_FAIL == temp)
	{
		g_running_status.errors.bit.sample_get_failed = true;

		for (cell_index = 0; cell_index < CELL_VOLT_NUM; cell_index++)
		{
			g_cell_calc_paras[cell_index].soc_calc_inited = false;
		}
	}
	else if (false == g_pack_flags.bit.proc_init)
	{
		g_running_status.pack_events.bit.proc_initialized = false;

		for (cell_index = 0; cell_index < CELL_VOLT_NUM; cell_index++)
		{
			g_cell_calc_paras[cell_index].soc_calc_inited = false;
		}
	}
	else
	{
		soc_sample_over_judge();			//采样数据超范围判断
		soc_params_init();							//SOC初始化

		if (false == g_running_status.errors.bit.sample_over_limit)
		{
			soc_first_order_filter();		//SOC数据一阶滤波
			soc_judge_term_refresh();		//整个PACK的判断条件刷新
			soc_loss_comp();				//损耗补偿
		}

		soc_val_display();					//SOC显示
	}

	//如果新的电芯计算周期开始，从1号电芯开始计算
	g_pack_calc_paras.cell_calc_index = 0;
	g_pack_calc_paras.cell_calc_cycle = 0;
	memset(&g_pack_flow_flags, 0, sizeof(soc_flow_flag_u)/sizeof(int8_t));

	g_pack_flags.bit.cell_calc_start = true;	//48个电芯计算启动
	g_pack_flags.bit.cell_calc_done = false;	//48个电芯计算未完成
}

/**
 * @brief		状态机：完成到完成
 * @param[in]	无
 * @return		无
 * @note		更新电芯计算状态机的状态
*/
static void done_to_done(void)
{
	g_pack_flags.bit.cell_calc_start = false;
	g_pack_flags.bit.cell_calc_done = true;
}

/**
 * @brief		状态机：完成到开始
 * @param[in]	无
 * @return		无
 * @note		开始状态会进行以下操作，部分操作会因为异常而跳过：
 * @note		1、获取SOX采样数据
 * @note		2、采样数据范围判断
 * @note		3、SOC初始化
 * @note		4、一阶滤波
 * @note		5、判断条件刷新
 * @note		6、损耗补偿
 * @note		7、SOC刷新
 * @note		8、电芯计算参数和状态的重置
*/
static void done_to_start(void)
{
	int32_t temp = 0;
	int32_t cell_index = 0;

	temp = sox_sample_data_get(&g_sox_sample_data);	//获取SOX采样数据

	//采样数据获取失败，则会置位相应的标志位
	if (SOX_FAIL == temp)
	{
		g_running_status.errors.bit.sample_get_failed = true;

		for (cell_index = 0; cell_index < CELL_VOLT_NUM; cell_index++)
		{
			g_cell_calc_paras[cell_index].soc_calc_inited = false;
		}
	}
	else if (false == g_pack_flags.bit.proc_init)
	{
		g_running_status.pack_events.bit.proc_initialized = false;

		for (cell_index = 0; cell_index < CELL_VOLT_NUM; cell_index++)
		{
			g_cell_calc_paras[cell_index].soc_calc_inited = false;
		}
	}
	else
	{
		soc_sample_over_judge();			//采样数据超范围判断
		soc_params_init();							//SOC初始化

		if (false == g_running_status.errors.bit.sample_over_limit)
		{
			soc_first_order_filter();		//SOC数据一阶滤波
			soc_judge_term_refresh();		//整个PACK的判断条件刷新
			soc_loss_comp();				//损耗补偿
		}

		soc_val_display();					//SOC显示
	}

	//如果新的电芯计算周期开始，从1号电芯开始计算
	g_pack_calc_paras.cell_calc_index = 0;
	g_pack_calc_paras.cell_calc_cycle = 0;
	memset(&g_pack_flow_flags, 0, sizeof(soc_flow_flag_u)/sizeof(int8_t));

	g_pack_flags.bit.cell_calc_start = true;	//48个电芯计算启动
	g_pack_flags.bit.cell_calc_done = false;	//48个电芯计算未完成
}

/**
  * @struct   sox_fsm_trans_t
  * @brief    状态机转换表
  */
static sox_fsm_trans_t g_sox_fsm_trans_tab[] =
{
	//当前状态		动作						下一个状态			执行函数
	{CALC_INIT,		REACHED_CALC_DONE, 			CALC_START, 	init_to_start},
	{CALC_INIT,		REACHED_CALC_RUNNING, 		CALC_START, 	init_to_start},
	{CALC_INIT,		APPROCHING_CALC_DONE, 		CALC_START, 	init_to_start},
	{CALC_INIT,		APPROCHING_CALC_RUNNING, 	CALC_START, 	init_to_start},
	{CALC_START, 	APPROCHING_CALC_RUNNING, 	CALC_RUNNING, 	start_to_running},
	{CALC_RUNNING, 	REACHED_CALC_DONE, 			CALC_DONE, 		running_to_done},
	{CALC_RUNNING, 	APPROCHING_CALC_DONE, 		CALC_DONE, 		running_to_done},
	{CALC_RUNNING, 	APPROCHING_CALC_RUNNING, 	CALC_RUNNING, 	running_to_running},
	{CALC_RUNNING, 	REACHED_CALC_RUNNING, 		CALC_DELAY, 	running_to_delay},
	{CALC_DELAY, 	REACHED_CALC_RUNNING, 		CALC_DELAY, 	delay_to_delay},
	{CALC_DELAY, 	REACHED_CALC_DONE, 			CALC_START, 	delay_to_start},
	{CALC_DONE, 	APPROCHING_CALC_DONE, 		CALC_DONE, 		done_to_done},
	{CALC_DONE, 	REACHED_CALC_DONE, 			CALC_START, 	done_to_start},
};

/**
  * @struct   sox_fsm_machine_t
  * @brief    当前状态机，默认初始状态为计算初始化状态
  */
static sox_fsm_machine_t g_sox_fsm_machine = {
	//初始状态		状态数量			状态转换表
	CALC_INIT, 		FSM_MAC_NUM,	g_sox_fsm_trans_tab,
};

/**
 * @brief		根据当前状态机状态和事件，遍历SOX状态机转换表，返回需要切换的状态
 * @param[in]	fsm_machine，当前状态机，sox_fsm_machine_t*类型
 * @param[in]	event，当前事件，sox_fsm_event_e类型
 * @return		sox_fsm_trans_t*，查询成功；NULL，没有符合的项
 * @note
*/
static sox_fsm_trans_t* sox_fsm_trans(sox_fsm_machine_t* fsm_machine, sox_fsm_event_e event)
{
	int32_t i;

	//入参合法性判断
	if ((event >= EVENTS_MAX_NUM)
	|| (NULL == fsm_machine))
	{
		return NULL;
	}

	for (i = 0; i < fsm_machine->transnum; i++)
	{
		if ((fsm_machine->cur_state == fsm_machine->trans[i].cur_state)
		&& (event == fsm_machine->trans[i].event))
		{
			return &(fsm_machine->trans[i]);
		}
	}

	return NULL;
}

/**
 * @brief		读取当前事件
 * @param[in]	无
 * @return		sox_fsm_event_e，当前事件
 * @note
*/
static sox_fsm_event_e read_event(void)
{
	sox_fsm_event_e retval = EVENTS_MAX_NUM;

	//电芯计算完毕
	if (CELL_VOLT_NUM-1 <= g_pack_calc_paras.cell_calc_index)
	{
		//到时间了，算完了
		if (g_pack_calc_paras.cell_calc_cycle > 99)
		{
			retval = REACHED_CALC_DONE;
		}
		//没有到时间，算完了
		else
		{
			retval = APPROCHING_CALC_DONE;
		}
	}
	//没有计算完毕
	else if (CELL_VOLT_NUM-1 > g_pack_calc_paras.cell_calc_index)
	{
		//没有到时间，没有算完
		if (g_pack_calc_paras.cell_calc_cycle <= 99)
		{
			retval = APPROCHING_CALC_RUNNING;
		}
		//到时间了，没有算完
		else
		{
			retval = REACHED_CALC_RUNNING;
		}
	}

	return retval;
}

/**
 * @brief		状态机运行函数，根据事件和当前状态，切换状态状态机状态
 * @param[in]	fsm_machine，当前状态机，sox_fsm_machine_t*类型
 * @return		SOX_OK，状态机查询成功；SOX_FAIL，状态机查询失败
 * @note
*/
static int8_t sox_calc_fsm(sox_fsm_machine_t* fsm_machine)
{
	int8_t retval = SOX_OK;
	sox_fsm_trans_t* fsm_trans;

	//t时刻后，SOC计算的次数++
	g_pack_calc_paras.cell_calc_cycle++;

	//遍历状态转化数组，找到相对应的转化结构体
	fsm_trans = sox_fsm_trans(fsm_machine, read_event());

	if (NULL == fsm_trans)
	{
		return SOX_FAIL;
	}

	fsm_machine->cur_state = fsm_trans->next_state;

	if (NULL == fsm_trans->handler)
	{
		return SOX_FAIL;
	}
	else
	{
		fsm_trans->handler();
	}

	return retval;
}

/**
 * @brief		长期未使用判断函数，超过一个月就判定为长时间未使用，否则判定为非长时间未使用
 * @param[in]	无
 * @return		SOC_OK，长时间未使用；SOC_FAIL，非长时间未使用
 * @note
*/
static int8_t soc_is_unused_longtime(void)
{
	int8_t retval = SOX_FAIL;

	//读取E2中最后一次充放电的时间，判断此次上电距离上次充放电的时间间隔
	//如果相差一个月以上，那么会判断为长时间未使用
	sox_rtc_t current_rtc_time = {0};
	uint32_t current_time = 0;
	uint32_t record_time = 0;

	//获取当前时间和充放电记录时间，转化为------小时
	g_sox_interface_remap.sox_rtc_get(&current_rtc_time);

	current_time = ((uint32_t)current_rtc_time.tm_year*365 +
					(uint32_t)current_rtc_time.tm_mon*30 +
					(uint32_t)current_rtc_time.tm_day)*24 +
					(uint32_t)current_rtc_time.tm_hour;

	record_time = ((uint32_t)g_bms_running_data.chg_dsg_record.tm_year*365 +
					(uint32_t)g_bms_running_data.chg_dsg_record.tm_mon*30 +
					(uint32_t)g_bms_running_data.chg_dsg_record.tm_day)*24 +
					(uint32_t)g_bms_running_data.chg_dsg_record.tm_hour;

	if (record_time < RTC_DFT_HOUR_SUM)
	{
		return SOX_FAIL;
	}
	/*****************************************************/
	//若充放电记录时间超过30天，则认为长时间未使用
	/*****************************************************/
	retval = sox_time_is_over(current_time, record_time, LONG_TIME_NO_USE_DAYS * 24);

	return retval;
}

/**
 * @brief		通过开路电压获得对应的SOC
 * @param[in]	ocv		输入开路电压
 * @param[in]	soc		查表后的SOC保存至该位置
 * @return		SOC_OK，查询成功；SOX_FAIL，查询异常
 * @note
*/
static int8_t cell_ocv_to_soc(int32_t ocv, int32_t* soc)
{
	int32_t retval = SOX_OK;
	int32_t length = sizeof(cell_ocv_tab)/sizeof(cell_ocv_tab[0]);

	if (NULL == soc)
	{
		return SOX_FAIL;
	}

	*soc = sox_interp_1d((int32_t*)cell_ocv_tab, (int32_t*)cell_soc_tab, length, ocv);

	if (SOX_FAIL == *soc)
	{
		return SOX_FAIL;
	}

	return retval;
}

/**
 * @brief		SOC上电初始化，完成滤波信号赋初值，并确定上电后是否启动OCV校准等操作
 * @param[in]	无
 * @return		SOC_OK，执行成功；SOC_FAIL，执行失败
 * @note		模块内调用
*/
static int8_t soc_params_init(void)
{
	int8_t retval = SOX_OK;

	limit_params_t limit_params = {0};
	int8_t temp = 0;
	int32_t temp2 = 0;
	int8_t temp_rtc_ok = 0;
	int32_t cell_index = 0;
	int32_t ocv_to_soc_temp = 0;

	int32_t cell_soc_array[CELL_VOLT_NUM] = {0};
	int32_t i = 0;
	int32_t temp_min = 0;
	int32_t temp_max = 0;

	sox_rtc_t current_rtc_time = {0};

	//获取当前时间
	g_sox_interface_remap.sox_rtc_get(&current_rtc_time);

	//该分支只在上电后第一次初始化时运行
	if (false == g_pack_flags.bit.params_init)
	{
		//从E2中读取运行数据、从外部获取限制参数
		g_sox_interface_remap.sox_running_data_get(&g_bms_running_data);
		g_sox_interface_remap.sox_limit_params_get(&limit_params);

		//是否长时间未使用
		temp = soc_is_unused_longtime();

		for (cell_index = 0; cell_index < CELL_VOLT_NUM; cell_index++)
		{
			//根据各电芯的判饱状态，确定电芯SOC的上下限，
			//在运行中，如果判饱，SOC上限会变成100%，满充标志位置true；
			//没有判饱，SOC上限也同样会变成100%，满充标志位置false；
			//但是重启后，没有判饱的，SOC上限恢复到99%，其实也没有问题，因为没有判饱的本来SOC就小于99%
			g_cell_flags[cell_index].bit.overchg =
				g_bms_running_data.cell_full_chg_flag.all_flag & (0x01<<cell_index);

			if (true == g_cell_flags[cell_index].bit.overchg)
			{
				g_cell_calc_paras[cell_index].soc_calc_upper_limit = FULL_HIGHEST_SOC;
			}
			else
			{
				g_cell_calc_paras[cell_index].soc_calc_upper_limit = NON_FULL_HIGHEST_SOC;
			}

			//读取电芯的OCV校准时间
			g_cell_calc_paras[cell_index].ocv_cali_record_time =
				g_bms_running_data.ocv_cali_time[cell_index];

			//一阶滤波初值初始化，（t-1）时刻的电压
			g_cell_fl_volt[cell_index].volt_last_time = g_sox_sample_data.cell_volt[cell_index];

			//读取E2，t时刻和（t-1）时刻的SOC
			g_cell_soc_vals[cell_index].calc_val = g_bms_running_data.cell_calc_soc[cell_index];

			//判断RTC时间是否在记录时间之前
			if ((current_rtc_time.tm_year * 12 * 30 + current_rtc_time.tm_mon * 30 + current_rtc_time.tm_day) >=
				(g_bms_running_data.chg_dsg_record.tm_year * 12 * 30 + g_bms_running_data.chg_dsg_record.tm_mon * 30
				+ g_bms_running_data.chg_dsg_record.tm_day))
			{
				temp_rtc_ok = 1;
			}

			//若长时间未使用且pack总压小于当SOC==60%时对应的OCV，如果RTC时间也正确，则进行SOC校准
			//非长时间未使用，直接读取E2的SOC
			if ((SOX_OK == temp) &&
				(g_sox_sample_data.cell_volt[cell_index] <= CELL_60_SOC_TO_OCV) &&
				(false == g_running_status.errors.bit.sample_over_limit) &&
				(!((RTC_DFT_YERA == current_rtc_time.tm_year) && (RTC_DFT_MONTH == current_rtc_time.tm_mon)
				&& (RTC_DFT_DATE == current_rtc_time.tm_day)) &&
				(1 == temp_rtc_ok)))
			{
				#ifdef LOG_PRINT_SWITCH_ON
					//log_e("soc_long_unused_cali\n");
				#endif
				//长时间未使用则读取E2，查取OCV表格，进行SOC校准
				temp2 = cell_ocv_to_soc(g_sox_sample_data.cell_volt[cell_index], &ocv_to_soc_temp);

				if (SOX_FAIL == temp2)
				{
					;
				}
				else
				{
					if (ocv_to_soc_temp < g_cell_soc_vals[cell_index].calc_val)
					{
						g_cell_soc_vals[cell_index].calc_val = ocv_to_soc_temp;

						g_bms_running_data.cell_calc_soc[cell_index] =
							g_cell_soc_vals[cell_index].calc_val;

						g_sox_interface_remap.sox_rtc_get(&g_bms_running_data.ocv_cali_time[cell_index]);

						g_pack_flags.bit.soc_save = true;
					}
				}
			}
			else
			{
				;
			}

			//赋值SOC(t-1)初始值、SOC上一次保存值
			g_cell_soc_vals[cell_index].calc_val_last = g_cell_soc_vals[cell_index].calc_val;
			g_cell_soc_vals[cell_index].calc_val_save = g_cell_soc_vals[cell_index].calc_val;
		}

		//一阶滤波初值初始化，（t-1）时刻的电流
		g_pack_cur.fl_signal.cur_last_time = g_sox_sample_data.sys_cur;

		//最近60秒滤波后的电流值数组，首位赋值
		g_pack_cur.fl_cur_array[g_pack_cur.fl_cur_array_index] =
			g_pack_cur.fl_signal.cur_last_time;
		g_pack_cur.fl_cur_array_index++;

		//读取E2中的电池额定容量，这里做了参数保护
		//超出参数范围的，统一按照默认值处理
		if (limit_params.rated_cap > RATED_CAP_UPPER_LIMIT)
		{
			g_pack_calc_paras.bat_rated_cap = DEFAULTED_RATED_CAP;
		}
		else if (limit_params.rated_cap < RATED_CAP_LOWER_LIMIT)
		{
			g_pack_calc_paras.bat_rated_cap = DEFAULTED_RATED_CAP;
		}
		else
		{
			g_pack_calc_paras.bat_rated_cap = limit_params.rated_cap;
		}

		//更新PACK的SOC计算值
		for (i = 0; i < CELL_VOLT_NUM; i++)
		{
			cell_soc_array[i] = g_cell_soc_vals[i].calc_val;
		}

		temp_min = min_array(cell_soc_array,CELL_VOLT_NUM);
		temp_max = max_array(cell_soc_array,CELL_VOLT_NUM);

		//除零保护 和 负数防护
		if (0 >= 100 * FRAC_PRE - temp_max + temp_min)
		{
			g_pack_soc_vals.calc_val = temp_min;
		}
		//如果一切正常，就给PACK的SOC赋初始值，但是精度只有0.1%，产生了截断
		//该值仍然大于设计书上的对外显示精度（1%）
		else
		{
			g_pack_soc_vals.calc_val =
				temp_min * FRAC_PRE / (100 * FRAC_PRE - temp_max + temp_min) * 100;
		}

		//这里显示值做了四舍五入处理，如果不做处理，举例：
		//计算值89900%，显示值直接除以1000，将会显示89%；
		//四舍五入，90400% / 1000 == 90%，将会显示90%
		//因为SOC显示值函数是做了四舍五入处理的，如果这里不做处理，将会产生以下现象：
		//开机显示SOC-89%-> SOC-90%，会有一个跳变的过程
		g_pack_soc_vals.display_val = (g_pack_soc_vals.calc_val + THOUTHAND_ROUND_OFF) / FRAC_PRE;
		g_pack_calc_paras.display_time = 0;

		g_pack_flags.bit.params_init = true;
		g_running_status.pack_events.bit.initialized = true;
	}
	else if (true == g_pack_flags.bit.params_init)
	{
		;
	}

	return retval;
}



/**
 * @brief		充放电时间记录，当充放电电流大于1A且距离上次保存的时间超过20min，记录
 * @param[in]	无
 * @return		SOC_OK，记录成功；SOC_FAIL，记录失败
 * @note
*/
static int8_t soc_chg_dsg_record(void)
{
	int8_t retval = SOX_OK;

	sox_rtc_t current_rtc_time = {0};
	uint32_t current_time = 0;
	uint32_t record_time = 0;

	//获取当前时间和记录时间，转化为------分钟
	g_sox_interface_remap.sox_rtc_get(&current_rtc_time);

	current_time = ((uint32_t)current_rtc_time.tm_year*365 +
				(uint32_t)current_rtc_time.tm_mon*30 +
				(uint32_t)current_rtc_time.tm_day)*24*60 +
				(uint32_t)current_rtc_time.tm_hour*60 +
				(uint32_t)current_rtc_time.tm_min;

	record_time = ((uint32_t)g_bms_running_data.chg_dsg_record.tm_year*365 +
				(uint32_t)g_bms_running_data.chg_dsg_record.tm_mon*30 +
				(uint32_t)g_bms_running_data.chg_dsg_record.tm_day)*24*60 +
				(uint32_t)g_bms_running_data.chg_dsg_record.tm_hour*60 +
				(uint32_t)g_bms_running_data.chg_dsg_record.tm_min;

	if ((abs(g_sox_sample_data.sys_cur) >= CHG_DSG_RECORD_CUR_LIMIT) &&
		(SOX_OK == sox_time_is_over(current_time, record_time, CHG_DSG_RECORD_MIN)))
	{
		g_bms_running_data.chg_dsg_record = current_rtc_time;

		g_running_status.pack_events.bit.chg_dsg_record = true;

		g_pack_flags.bit.soc_save = true;
	}
	else
	{
		g_running_status.pack_events.bit.chg_dsg_record = false;
	}

	g_pack_flow_flags.func_flow_flag.chg_dsg_record = true;

	return retval;
}

/**
 * @brief		采用soc、电流和温度查询开路电压ocv
 * @param[in]	soc		查询需要的SOC
 * @param[in]	cur		查询需要的电流
 * @param[in]	temp	查询需要的温度
 * @param[in]	ocv		查询后输出的开路电压ocv
 * @return		SOC_OK，查询成功；SOX_FAIL，查询失败
 * @note
*/
static int8_t soc_to_ocv(int32_t soc, int32_t cur, int32_t temp, int32_t* ocv)
{
	int8_t retval = SOX_OK;
	index_length_3d_t index_length_3d = {U_TABLE_SOC_LENGTH,U_TABLE_CUR_LENGTH,U_TABLE_TEMP_LENGTH};
	coord_3d_t coord_3d = {soc,abs(cur),temp};

	if (NULL == ocv)
	{
		return SOX_FAIL;
	}

	*ocv = sox_interp_3d((int32_t*)utab_index_tab, (int32_t*)utab_tab, U_TABLE_SOC_LENGTH, index_length_3d, coord_3d);

	if (SOX_FAIL == *ocv)
	{
		return SOX_FAIL;
	}

	return retval;
}

/**
 * @brief		获取不同温度下，99%的SOC对应的电压边界值
 * @param[in]	temp	查询需要的温度
 * @return		电压边界值，查询成功；SOX_FAIL，查询失败
 * @note
*/
static int32_t bound_volt_check(int32_t temp)
{
	int32_t retval = 0;

	retval = sox_interp_1d((int32_t *)temp_index_tab, (int32_t *)bound_volt_tab, BOUND_TEMP_LENGTH, temp);

	return retval;
}

/**
 * @brief		过去60秒内未发生充电/放电/放置状态的切换
 * @param[in]	无
 * @return		SOC_OK，状态发生切换；SOC_FAIL，状态未发生切换
 * @note
*/
static int8_t soc_bms_state_is_changed(void)
{
	int8_t retval = SOX_FAIL;

	sox_bat_status_e battery_state;
	// battery_state = sox_bat_state_get();
	battery_state = g_sox_interface_remap.sox_bat_status_get();

	//1、当前状态改变-->状态发生改变
	if (battery_state != g_pack_calc_paras.bat_state)
	{
		g_pack_calc_paras.bat_state_record_time =
			g_sox_interface_remap.sox_tick_get();
		g_pack_calc_paras.bat_state = battery_state;
		retval = SOX_OK;
	}
	//2、当前状态未改变，但是距上次状态改变没有超过1min-->状态发生改变
	else if ((battery_state == g_pack_calc_paras.bat_state) &&
			(SOX_FAIL == sox_time_is_over(g_sox_interface_remap.sox_tick_get(),
					g_pack_calc_paras.bat_state_record_time,_60S_BASE_1MS)))
	{
		retval = SOX_OK;
	}
	//3、当前状态未改变，距上次状态改变超过1min-->状态没有发生改变
	else if ((battery_state == g_pack_calc_paras.bat_state) &&
		(SOX_OK == sox_time_is_over(g_sox_interface_remap.sox_tick_get(),
					g_pack_calc_paras.bat_state_record_time,_60S_BASE_1MS)))
	{
		;
	}

	return retval;
}

/**
 * @brief		处理SOC判饱及判饱退出
 * @param[in]	无
 * @return		SOC_OK，处理成功；SOC_FAIL，处理失败
 * @note
*/
static int8_t soc_overchg_manage(void)
{
	int8_t retval = SOX_OK;

	int32_t cell_index = 0;

	bool start_is_matching = false;						//充电判饱进入满足
	bool exit_is_matching = false;						//充电判饱退出满足
	bool temp_exit_ret = false;							//临时存储充电判饱和退出结果

	sox_stats_t sox_stats_temp = {0};					//临时获取累计数据

	//判断为饱和后，记录对应的累计充放电容量
	sox_stats_t sox_stats_sentinel = {0};

	//判断为饱和后，记录时间
	sox_rtc_t sentinel_overchg_time = {0};

	//true表示饱和状态维持了48h以上
	bool overchg_remain_flag = false;

	sox_rtc_t current_rtc_time = {0};
	uint32_t current_time = 0;
	uint32_t record_time = 0;

	uint16_t cell_max_volt_past_5s = 0;

	//获取当前时间和记录时间，转化为------分钟
	g_sox_interface_remap.sox_rtc_get(&current_rtc_time);

	current_time = ((uint32_t)current_rtc_time.tm_year*365
		+ (uint32_t)current_rtc_time.tm_mon*30
		+ (uint32_t)current_rtc_time.tm_day)*24*60
		+ (uint32_t)current_rtc_time.tm_hour*60
		+ (uint32_t)current_rtc_time.tm_min;

	for (cell_index = 0; cell_index < CELL_VOLT_NUM; cell_index++)
	{
		//判断是否处于判饱退出条件，必须先是饱和的，才能进入判饱退出条件的判断
		if (true == g_cell_flags[cell_index].bit.overchg)
		{
			record_time = ((uint32_t)g_bms_running_data.full_chg_time[cell_index].tm_year*365
				+ (uint32_t)g_bms_running_data.full_chg_time[cell_index].tm_mon*30
				+ (uint32_t)g_bms_running_data.full_chg_time[cell_index].tm_day)*24*60
				+ (uint32_t)g_bms_running_data.full_chg_time[cell_index].tm_hour*60
				+ (uint32_t)g_bms_running_data.full_chg_time[cell_index].tm_min;

			//判饱后维持在100%且自然时间>=12h，才会将该条件置true
			if ((FULL_HIGHEST_SOC*SOC_CALC_PRE == g_cell_soc_vals[cell_index].calc_val) &&
				(SOX_OK == sox_time_is_over(current_time * 60 + (uint32_t)current_rtc_time.tm_sec,
				record_time * 60 + (uint32_t)g_bms_running_data.full_chg_time[cell_index].tm_sec,
				FULL_MAINTAIN_HOURS*HOUR_TO_SEC)))
			{
				overchg_remain_flag = true;
			}
			else
			{
				overchg_remain_flag = false;
			}

			sox_stats_get(&sox_stats_temp);

			//判饱退出条件
			//1、最低电芯电压 <= 3.32V && 电流 >= -0.5A ||
			//2、判饱后累计容量 >= 1%*额定容量 ||
			//3、判饱后维持在100%且自然时间 >= 12h ||
			//4、处于判饱，如果有一个电芯没有充满，刚充满也会马上退出判饱状态
			temp_exit_ret = ((g_sox_sample_data.sys_cur >= EXIT_FULL_CUR)
				&& (g_sox_sample_data.min_cell_volt <= EXIT_FULL_VOLT))
				|| ((sox_stats_temp.sumed_dsg_ah - g_bms_running_data.full_chg_dsg_ah[cell_index]) > EXIT_FULL_AH)
				|| (true == overchg_remain_flag)
				|| (g_cell_soc_vals[cell_index].calc_val <= NON_FULL_HIGHEST_SOC*SOC_CALC_PRE);

			if (true == temp_exit_ret)
			{
				exit_is_matching = true;
			}
			else
			{
				;
			}
		}
	}

	//只要电池包有一个电芯退出饱和，整个电池包就会退出判饱状态
	//所有电芯的SOC上限更改为99%
	if (true == exit_is_matching)
	{
		for (cell_index = 0; cell_index < CELL_VOLT_NUM; cell_index++)
		{
			if (g_cell_soc_vals[cell_index].calc_val > NON_FULL_HIGHEST_SOC*SOC_CALC_PRE)
			{
				g_cell_soc_vals[cell_index].calc_val = NON_FULL_HIGHEST_SOC*SOC_CALC_PRE;
				g_cell_soc_vals[cell_index].calc_val_last = NON_FULL_HIGHEST_SOC*SOC_CALC_PRE;
			}
			else if (g_cell_soc_vals[cell_index].calc_val <= NON_FULL_HIGHEST_SOC*SOC_CALC_PRE)
			{
				;
			}

			g_cell_calc_paras[cell_index].soc_calc_upper_limit = NON_FULL_HIGHEST_SOC;

			//清除满充标志位，满充事件置false
			g_cell_flags[cell_index].bit.overchg = false;
			g_bms_running_data.cell_full_chg_flag.all_flag &= ~(0x01 <<cell_index);
			g_running_status.cell_events[cell_index].bit.overchg = false;

			g_pack_flags.bit.soc_save = true;
		}
	}

	//如果收到满充事件（触发式）、或者电芯大于3600mV超过5秒
	//则触发所有电芯的SOC，这个过压触发在逻辑数据刷新函数中，每秒刷新一次
	start_is_matching = (true == g_pack_calc_paras.overvolt_alarm_raiseup_flag);

	if (true == start_is_matching)
	{
		#ifdef LOG_PRINT_SWITCH_ON
			//log_e("soc_full\n");
		#endif

		for (cell_index = 0; cell_index < CELL_VOLT_NUM; cell_index++)
		{
			if (false == g_pack_calc_paras.there_is_5s_volt)
			{
				cell_max_volt_past_5s = g_sox_sample_data.cell_volt[cell_index];
			}
			else if (true == g_pack_calc_paras.there_is_5s_volt)
			{
				cell_max_volt_past_5s = g_cell_calc_paras[cell_index].cell_max_volt_past_5s;
			}

			//触发饱和时，从BMU的主动均衡模块中获取最近
			if (cell_max_volt_past_5s <
				bound_volt_check(g_sox_sample_data.cell_temp[cell_index/CELL_TEMP_GROUP_LENGTH]))
			{
				g_cell_soc_vals[cell_index].calc_val = NON_FULL_HIGHEST_SOC * SOC_CALC_PRE;
				g_cell_soc_vals[cell_index].calc_val_last = NON_FULL_HIGHEST_SOC * SOC_CALC_PRE;

				g_cell_calc_paras[cell_index].soc_calc_upper_limit = NON_FULL_HIGHEST_SOC;
			}
			else
			{
				g_cell_soc_vals[cell_index].calc_val = FULL_HIGHEST_SOC * SOC_CALC_PRE;
				g_cell_soc_vals[cell_index].calc_val_last = FULL_HIGHEST_SOC * SOC_CALC_PRE;

				g_cell_calc_paras[cell_index].soc_calc_upper_limit = FULL_HIGHEST_SOC;

				g_pack_flags.bit.soc_save = true;

				//记录满充标志位
				g_cell_flags[cell_index].bit.overchg = true;
				g_bms_running_data.cell_full_chg_flag.all_flag |= (0x01 <<cell_index);
				g_running_status.cell_events[cell_index].bit.overchg = true;

				//获取、记录累计充放电容量和满充时间
				sox_stats_get(&sox_stats_sentinel);
				g_sox_interface_remap.sox_rtc_get(&sentinel_overchg_time);

				g_bms_running_data.full_chg_dsg_ah[cell_index] = sox_stats_sentinel.sumed_dsg_ah;
				g_bms_running_data.full_chg_time[cell_index] = sentinel_overchg_time;
			}

		}
	}

	g_pack_flow_flags.func_flow_flag.over_chg = true;

	return retval;
}

/**
 * @brief		SOC判空及处理函数
 * @param[in]	无
 * @return		SOC_OK，处理成功；SOC_FAIL，处理失败
 * @note
*/
static int8_t soc_overdsg_manage(void)
{
	int8_t retval = SOX_OK;

	int32_t cell_index = 0;
	bool local_is_matching = false;

	int32_t min_cell_num = 0;
	int32_t cell_volt_array[CELL_VOLT_NUM] = {0};

	//先找到SOC最小的电芯编号
	for (cell_index = 0; cell_index < CELL_VOLT_NUM; cell_index++)
	{
		cell_volt_array[cell_index] = g_sox_sample_data.cell_volt[cell_index];
	}

	min_array_and_index(cell_volt_array, CELL_VOLT_NUM, &min_cell_num);

	//判断本PACK是否有电芯触发放空，如果有电芯触发判空
	//找出SOC最低的那一个电芯，将其SOC下降至0，其余电芯下降同样的数值
	for (cell_index = 0; cell_index < CELL_VOLT_NUM; cell_index++)
	{
		//判空强制校准
		//1、触发放空保护
		//2、最低电芯电压<=2.8V且持续1秒
		local_is_matching =
			((true == g_pack_calc_paras.local_dsg_empty_raiseup_flag)
			|| (g_cell_calc_paras[cell_index].overdsg_duration >= DSGEMPTY_DURATION_LIMIT));

		if (true == local_is_matching)
		{
			g_pack_calc_paras.this_pack_soc_drop = g_cell_soc_vals[min_cell_num].calc_val;

			//位数限制，传递给其它BMU的SOC精度为1%
			g_pack_calc_paras.upload_to_other_bmu_soc =
				(g_pack_calc_paras.this_pack_soc_drop + THOUTHAND_ROUND_OFF) / SOC_CALC_PRE;

			g_pack_calc_paras.local_soc_duration = DSG_LOCAL_WATING_TIME - 1;
			break;
		}
		else
		{
			;
		}
	}

	//出现本地判空后，最小的电芯SOC大于0，所有电芯SOC下降最小电芯的SOC值
	//否则，所有电芯SOC不变
	if ((g_pack_calc_paras.this_pack_soc_drop > 0)
		&& (true == local_is_matching))
	{
		#ifdef LOG_PRINT_SWITCH_ON
			//log_d("\nsoc_empty\n");
		#endif

		for (cell_index = 0; cell_index < CELL_VOLT_NUM; cell_index++)
		{
			//更新判空标志位、SOC计算值上限
			g_cell_flags[cell_index].bit.overdsg = true;
			g_running_status.cell_events[cell_index].bit.overdsg = true;
			g_cell_calc_paras[cell_index].soc_calc_lower_limit = EMPTY_LOWEST_SOC;

			g_cell_soc_vals[cell_index].calc_val -= g_pack_calc_paras.this_pack_soc_drop;
			g_cell_soc_vals[cell_index].calc_val_last -= g_pack_calc_paras.this_pack_soc_drop;

			if (g_cell_soc_vals[cell_index].calc_val < 0)
			{
				g_cell_soc_vals[cell_index].calc_val = 0;
			}

			if (g_cell_soc_vals[cell_index].calc_val_last < 0)
			{
				g_cell_soc_vals[cell_index].calc_val_last = 0;
			}
		}

		g_pack_calc_paras.this_pack_soc_drop = 0;
	}

	//如果出现本地判空，就设置需要上传至其它BMU的SOC，保持10秒钟，10秒钟之后，清零。
	if (g_pack_calc_paras.local_soc_duration >= 0)
	{
		g_pack_calc_paras.local_soc_duration--;
	}
	else if (g_pack_calc_paras.local_soc_duration < 0)
	{
		g_pack_calc_paras.upload_to_other_bmu_soc = 0;
	}

	//先判断本地判空，再处理CAN发送的电池簇出现判空
	if (true == g_pack_calc_paras.can_dsg_empty_raiseup_flag)
	{
		//如果本地被判空，则不做处理
		if (true == local_is_matching)
		{
			return retval;
		}
		//如果本地没有判空，在进行处理；
		//而且本地判空之后的下一秒，CAN判空上升沿会被清除；
		else if (false == local_is_matching)
		{
			g_pack_calc_paras.can_soc_wait_time = DSG_CAN_WATING_TIME;
		}
	}

	if (g_pack_calc_paras.can_soc_wait_time >= 0)
	{
		g_pack_calc_paras.can_soc_wait_time--;
	}
	else if(g_pack_calc_paras.can_soc_wait_time < 0)
	{
		g_pack_calc_paras.can_soc_get = 0;
	}

	//当存在本地判空时，屏蔽CAN接收到的判空事件
	//等待数据，只要数据在等待期间大于0，就直接处理；
	//否则接着等待数据接收
	if ((g_pack_calc_paras.can_soc_wait_time >= 0)
	&& (g_pack_calc_paras.local_soc_duration < 0))
	{
		if (g_pack_calc_paras.can_soc_get > 0)
		{
			for (cell_index = 0; cell_index < CELL_VOLT_NUM; cell_index++)
			{
				//更新判空标志位、SOC计算值上限
				g_cell_flags[cell_index].bit.overdsg = true;
				g_running_status.cell_events[cell_index].bit.overdsg = true;
				g_cell_calc_paras[cell_index].soc_calc_lower_limit = EMPTY_LOWEST_SOC;

				g_cell_soc_vals[cell_index].calc_val -= g_pack_calc_paras.can_soc_get * SOC_CALC_PRE;
				g_cell_soc_vals[cell_index].calc_val_last -= g_pack_calc_paras.can_soc_get * SOC_CALC_PRE;

				if (g_cell_soc_vals[cell_index].calc_val < 0)
				{
					g_cell_soc_vals[cell_index].calc_val = 0;
				}

				if (g_cell_soc_vals[cell_index].calc_val_last < 0)
				{
					g_cell_soc_vals[cell_index].calc_val_last = 0;
				}
			}

			g_pack_calc_paras.can_soc_wait_time = -1;
			g_pack_calc_paras.can_soc_get = 0;
		}
	}

	g_pack_flow_flags.func_flow_flag.over_dsg = true;

	return retval;
}

/**
 * @brief		SOC静置判断及校准
 * @param[in]	cell_index，电芯索引
 * @return		SOC_OK，处理成功；SOC_FAIL，处理失败
 * @note
*/
static int8_t soc_standby_manage(int32_t cell_num)
{
	int8_t retval = SOX_OK;

	bool is_matching = 0;
	int32_t cell_volt_to_soc = 0;
	sox_rtc_t current_rtc_time = {0};
	uint32_t current_time = 0;
	uint32_t record_time = 0;
	int32_t temp = 0;

	temp = cell_ocv_to_soc(g_sox_sample_data.cell_volt[cell_num], &cell_volt_to_soc);

	//获取当前时间和记录时间，转化为------分钟
	g_sox_interface_remap.sox_rtc_get(&current_rtc_time);

	current_time = ((uint32_t)current_rtc_time.tm_year*365
				+ (uint32_t)current_rtc_time.tm_mon*30
				+ (uint32_t)current_rtc_time.tm_day)*24*60
				+ (uint32_t)current_rtc_time.tm_hour*60
				+ (uint32_t)current_rtc_time.tm_min;

	record_time = ((uint32_t)g_cell_calc_paras[cell_num].ocv_cali_record_time.tm_year*365
				+ (uint32_t)g_cell_calc_paras[cell_num].ocv_cali_record_time.tm_mon*30
				+ (uint32_t)g_cell_calc_paras[cell_num].ocv_cali_record_time.tm_day)*24*60
				+ (uint32_t)g_cell_calc_paras[cell_num].ocv_cali_record_time.tm_hour*60
				+ (uint32_t)g_cell_calc_paras[cell_num].ocv_cali_record_time.tm_min;

	//静置校准执行的条件
	//1、电流绝对值小于0.3A且持续24h &&
	//2、pack总压<=OCV(SOC=60%) &&
	//3、距离上次OCV校准时间>=12h
	is_matching =
			(g_pack_calc_paras.cur_standby_duration >= STANDBY_CUR_MAINTAIN_HOURS*HOUR_TO_SEC)
			&& (SOX_OK == sox_time_is_over(current_time*60 + (uint32_t)current_rtc_time.tm_sec,
			record_time*60 + (uint32_t)g_cell_calc_paras[cell_num].ocv_cali_record_time.tm_sec,
			STANDBY_MAINTAIN_HOURS * HOUR_TO_SEC))
			&& (g_sox_sample_data.cell_volt[cell_num] <= CELL_60_SOC_TO_OCV);

	if (true == is_matching)
	{
		#ifdef LOG_PRINT_SWITCH_ON
			//log_e("soc_standby_cali\n");
		#endif

		if (SOX_FAIL == temp)
		{
			g_running_status.cell_events[cell_num].bit.standby = false;
		}
		else
		{
			if (cell_volt_to_soc < g_cell_soc_vals[cell_num].calc_val)
			{
				g_cell_soc_vals[cell_num].calc_val =
					max_two_nums(g_cell_soc_vals[cell_num].calc_val - 1000, cell_volt_to_soc);

				g_cell_soc_vals[cell_num].calc_val_last = g_cell_soc_vals[cell_num].calc_val;
			}

			g_sox_interface_remap.sox_rtc_get(&g_cell_calc_paras[cell_num].ocv_cali_record_time);
			g_bms_running_data.ocv_cali_time[cell_num] = g_cell_calc_paras[cell_num].ocv_cali_record_time;
			g_bms_running_data.cell_calc_soc[cell_num] = g_cell_soc_vals[cell_num].calc_val;

			g_running_status.cell_events[cell_num].bit.standby = true;
			g_pack_flags.bit.soc_save = true;
		}
	}
	else
	{
		g_running_status.cell_events[cell_num].bit.standby = false;
	}

	return retval;
}

/**
 * @brief		SOC充电末端校准
 * @param[in]	p_terminal_cali，SOC需要校准的大小
 * @param[in]	cell_num，需要进行校准的电芯
 * @return		true，触发校准，fail，没有触发校准
 * @note
*/
static int8_t soc_chg_cali(float* p_terminal_cali, int32_t cell_num)
{
	int8_t retval = false;
	int8_t is_matching = false;

	if (NULL == p_terminal_cali)
	{
		return false;
	}

	//充电末端校准判定条件
	//1、150mA < 充电电流 <= 0.12C &&
	//2、最高电芯电压>=3550mV(2.0加50mV)
	is_matching = (g_sox_sample_data.sys_cur <= CHG_CALI_CUR)
		&& (g_sox_sample_data.sys_cur > LOSS_CUR_UPPER_LIMIT)
		&& (g_sox_sample_data.cell_volt[cell_num] >= CHG_CALI_VOLT);

	if (true == is_matching)
	{
		*p_terminal_cali = 5 * (g_sox_sample_data.cell_volt[cell_num] - CHG_CALI_U_TABLE);  // K为校准系数，与收敛速度有关，取5.0/s, 即5000/ms;

		retval = true;
	}
	else
	{
		retval = false;
	}

	return retval;
}

/**
 * @brief		SOC放电末端校准
 * @param[in]	p_terminal_cali，SOC需要校准的大小
 * @return		true，触发校准，fail，没有触发校准
 * @note
*/
static int8_t soc_dsg_cali(float* p_terminal_cali, int32_t cell_num)
{
	int8_t retval = false;
	int8_t is_matching = 0;

	int32_t  soc_10_to_volt = 0;
	int32_t soc_this_to_volt  = 0;
	int32_t soc_min_to_volt  = 0;

	int32_t min_cell_volt = 0xFFFF;
	int32_t min_cell_volt_num = 0;
	int8_t i = 0;

	bool according_to_bcu_flag = false;

	if (NULL == p_terminal_cali)
	{
		return false;
	}

	dsg_cali_data_t rx_dsg_cali_data = {0};
	g_sox_interface_remap.sox_dsg_cali_data_get(&rx_dsg_cali_data);

	//获取最小的电芯电压
	for (i = 0; i < CELL_VOLT_NUM; i++)
	{
		if (min_cell_volt > g_cell_fl_volt[i].volt_this_time)
		{
			min_cell_volt = g_cell_fl_volt[i].volt_this_time;
			min_cell_volt_num = i;
		}
	}

	//末端放电校准条件，两个大条件，满足一个即可：
	//1、(-300mA > 放电电流 >= -0.06C && 最低电芯电压 <= 2.9V) ||
	//2、(过去60秒内未发生充电/放电/静置状态的切换 && 过去60秒内电流滤波值的最大最小值差异小于0.1C
	//&& 电芯温度最小值>=15 && -0.6C <= 电流滤波值 <= -0.1C && (SOC<=10% || Umin <= Utab(SOC=10%)))
	is_matching = ((SOX_FAIL == soc_bms_state_is_changed())
		&& (max_array(g_pack_cur.fl_cur_array,_60S_BASE_1S) -
		min_array(g_pack_cur.fl_cur_array, _60S_BASE_1S) <= DSG_CALI_CUR_DIFF)
		&& (g_sox_sample_data.min_cell_temp >= DSG_CALI_TEMP)
		&& (g_pack_cur.fl_signal.cur_this_time <= DSG_CALI_UPPER_CUR)
		&& (g_pack_cur.fl_signal.cur_this_time >= DSG_CALI_LOWER_CUR)
		&& ((g_cell_soc_vals[cell_num].calc_val <= DSG_CALI_SOC*SOC_CALC_PRE)
		|| (g_pack_calc_paras.under_volt_table_time >= DSG_CALI_UNDER_U_TABLE)))
		|| ((g_sox_sample_data.sys_cur >= DSG_CALI_CUR_2)
		&& (g_sox_sample_data.sys_cur < LOSS_CUR_WITH_INV_UNDER_LIMIT)
		&& (g_sox_sample_data.min_cell_volt <= DSG_CALI_VOLT_2));

	if (true == is_matching)
	{
		//查表获取SOC=10%时对应的OCV
		int32_t temp_10 = soc_to_ocv(DSG_CALI_SOC*SOC_CALC_PRE, g_pack_cur.fl_signal.cur_this_time,
			g_sox_sample_data.min_cell_temp, &soc_10_to_volt);

		//查表获取当前电芯SOC对应的OCV
		int32_t temp_this = soc_to_ocv(g_cell_soc_vals[cell_num].calc_val, g_pack_cur.fl_signal.cur_this_time,
			g_sox_sample_data.cell_temp[cell_num/CELL_TEMP_GROUP_LENGTH], &soc_this_to_volt);

		//查表获取最小电芯电压的U,table
		int32_t temp_min = soc_to_ocv(g_cell_soc_vals[min_cell_volt_num].calc_val, g_pack_cur.fl_signal.cur_this_time,
			g_sox_sample_data.min_cell_temp, &soc_min_to_volt);

		//上报给BCU
		g_tx_dsg_cali_data.can_calc_val = g_cell_soc_vals[min_cell_volt_num].calc_val;
		g_tx_dsg_cali_data.can_soc_min_to_volt = soc_min_to_volt;
		g_tx_dsg_cali_data.can_min_cell_volt = min_cell_volt;

		//如果接收到BCU下发的最低电芯电压和SOC，根据BCU下发的数据设置最低电芯电压和相应的SOC
		if ((0 != rx_dsg_cali_data.can_soc_min_to_volt) && (0 != rx_dsg_cali_data.can_calc_val)
			&& (0 != rx_dsg_cali_data.can_min_cell_volt))
		{
			if (rx_dsg_cali_data.can_min_cell_volt < soc_min_to_volt)
			{
				according_to_bcu_flag = true;
			}
		}

		//第一种情况，n号电芯的SOC < 最小电芯一阶滤波电压对应的SOC
		if ((g_cell_soc_vals[cell_num].calc_val < g_cell_soc_vals[min_cell_volt_num].calc_val)
			&& (false == according_to_bcu_flag))
		{
			*p_terminal_cali = 0;
		}
		else if ((g_cell_soc_vals[cell_num].calc_val < rx_dsg_cali_data.can_calc_val)
			&& (true == according_to_bcu_flag))
		{
			*p_terminal_cali = 0;
		}
		//第二种情况，n号电芯SOC >= 最小电芯一阶滤波电压对应的SOC；且本电芯电压 > Utable(SOC = 10%)
		//这时候，最小的SOC的电芯校准多少，其它电芯校准多少
		else if ((g_cell_soc_vals[cell_num].calc_val >= g_cell_soc_vals[min_cell_volt_num].calc_val)
		&& (g_cell_fl_volt[cell_num].volt_this_time > soc_10_to_volt)
		&& (false == according_to_bcu_flag))
		{
			if ((SOX_FAIL == temp_min)
			|| (SOX_FAIL == temp_10))
			{
				retval = false;
			}
			else
			{
				*p_terminal_cali = 5 * (min_cell_volt - soc_min_to_volt);
				retval = true;
			}
		}
		else if ((g_cell_soc_vals[cell_num].calc_val >= rx_dsg_cali_data.can_calc_val)
		&& (g_cell_fl_volt[cell_num].volt_this_time > soc_10_to_volt)
		&& (true == according_to_bcu_flag))
		{
			if ((SOX_FAIL == temp_min)
			|| (SOX_FAIL == temp_10))
			{
				retval = false;
			}
			else
			{
				*p_terminal_cali = 5 * (rx_dsg_cali_data.can_min_cell_volt - rx_dsg_cali_data.can_soc_min_to_volt);
				retval = true;
			}
		}
		//第三种情况，n号电芯SOC >= 最小电芯一阶滤波电压对应的SOC；且本电芯电压 <= Utable(SOC = 10%)
		//这种情况，该电芯自己进入校准区间，可以按照自己的实际情况进行校准
		else if ((g_cell_soc_vals[cell_num].calc_val >= g_cell_soc_vals[min_cell_volt_num].calc_val)
		&& (g_cell_fl_volt[cell_num].volt_this_time <= soc_10_to_volt)
		&& (false == according_to_bcu_flag))
		{
			if ((SOX_FAIL == temp_this)
			|| (SOX_FAIL == temp_10))
			{
				retval = false;
			}
			else
			{
				*p_terminal_cali = 5 * (g_cell_fl_volt[cell_num].volt_this_time - soc_this_to_volt);
				retval = true;
			}
		}
		else if ((g_cell_soc_vals[cell_num].calc_val >= rx_dsg_cali_data.can_calc_val)
		&& (g_cell_fl_volt[cell_num].volt_this_time <= soc_10_to_volt)
		&& (true == according_to_bcu_flag))
		{
			if ((SOX_FAIL == temp_this)
			|| (SOX_FAIL == temp_10))
			{
				retval = false;
			}
			else
			{
				*p_terminal_cali = 5 * (g_cell_fl_volt[cell_num].volt_this_time - soc_this_to_volt);
				retval = true;
			}
		}
	}
	else
	{
		g_tx_dsg_cali_data.can_calc_val = 0xFFFF;
		g_tx_dsg_cali_data.can_soc_min_to_volt = 0xFFFF;
		g_tx_dsg_cali_data.can_min_cell_volt = 0xFFFF;

		if ((0 != rx_dsg_cali_data.can_soc_min_to_volt) && (0 != rx_dsg_cali_data.can_calc_val)
			&& (0 != rx_dsg_cali_data.can_min_cell_volt))
		{
			//查表获取SOC=10%时对应的OCV
			int32_t temp_10 = soc_to_ocv(DSG_CALI_SOC*SOC_CALC_PRE, g_pack_cur.fl_signal.cur_this_time,
				g_sox_sample_data.min_cell_temp, &soc_10_to_volt);

			//查表获取当前电芯SOC对应的OCV
			int32_t temp_this = soc_to_ocv(g_cell_soc_vals[cell_num].calc_val, g_pack_cur.fl_signal.cur_this_time,
				g_sox_sample_data.cell_temp[cell_num/CELL_TEMP_GROUP_LENGTH], &soc_this_to_volt);

			//第一种情况，n号电芯的SOC < 最小电芯一阶滤波电压对应的SOC
			if (g_cell_soc_vals[cell_num].calc_val < rx_dsg_cali_data.can_calc_val)
			{
				*p_terminal_cali = 0;
			}
			//第二种情况，n号电芯SOC >= 最小电芯一阶滤波电压对应的SOC；且本电芯电压 > Utable(SOC = 10%)
			//这时候，最小的SOC的电芯校准多少，其它电芯校准多少
			else if ((g_cell_soc_vals[cell_num].calc_val >= rx_dsg_cali_data.can_calc_val)
			&& (g_cell_fl_volt[cell_num].volt_this_time > soc_10_to_volt))
			{
				if (SOX_FAIL == temp_10)
				{
					retval = false;
				}
				else
				{
					*p_terminal_cali = 5 * (rx_dsg_cali_data.can_min_cell_volt - rx_dsg_cali_data.can_soc_min_to_volt);
					retval = true;
				}
			}
			//第三种情况，n号电芯SOC >= 最小电芯一阶滤波电压对应的SOC；且本电芯电压 <= Utable(SOC = 10%)
			//这种情况，该电芯自己进入校准区间，可以按照自己的实际情况进行校准
			else if ((g_cell_soc_vals[cell_num].calc_val >= rx_dsg_cali_data.can_calc_val)
			&& (g_cell_fl_volt[cell_num].volt_this_time <= soc_10_to_volt))
			{
				if ((SOX_FAIL == temp_this)
				|| (SOX_FAIL == temp_10))
				{
					retval = false;
				}
				else
				{
					*p_terminal_cali = 5 * (g_cell_fl_volt[cell_num].volt_this_time - soc_this_to_volt);
					retval = true;
				}
			}
			else
			{
				retval = false;
			}
		}
	}
	return retval;
}

/**
 * @brief		获取SOC放电末端校准数据
 * @param[in]	p_out，数据结构体，保存获取到的SOC放电末端校准数据，dsg_cali_data_t* 类型
 * @return		0，执行成功，非0，执行失败
 * @note
*/
int32_t soc_dsg_cali_data_get(dsg_cali_data_t* p_out)
{
	if (NULL == p_out)
	{
		return SOX_FAIL;
	}

	p_out->can_calc_val = g_tx_dsg_cali_data.can_calc_val;
	p_out->can_soc_min_to_volt = g_tx_dsg_cali_data.can_soc_min_to_volt;
	p_out->can_min_cell_volt = g_tx_dsg_cali_data.can_min_cell_volt;

	return 0;
}

/**
 * @brief		SOC计算及计算值限制
 * @param[in]	cell_num，此次计算的电芯的编号
 * @return		true，计算成功；false，计算失败
 * @note
*/
static int8_t soc_val_calc(int32_t cell_num)
{
	int8_t retval = true;

	float terminal_cali_val = 0;
	float soh_val = 0;
	uint32_t calc_this_time = 0;
	int32_t time_diff = 0; //ms

	if (false == g_cell_calc_paras[cell_num].soc_calc_inited)
	{
		//初次计算SOC，更新计算时间
		//现在该部分还有一个功能，当出现跳过SOC计算的情况时，重置计算时间
		g_cell_calc_paras[cell_num].mAms_accum = g_pack_calc_paras.cur_after_loss_temp * 1000;

		g_cell_calc_paras[cell_num].soc_calc_inited = true;
		calc_this_time = g_sox_interface_remap.sox_tick_get();
		g_cell_calc_paras[cell_num].calc_last_time = calc_this_time;
	}
	else if (true == g_cell_calc_paras[cell_num].soc_calc_inited)
	{
		//消除线程延时对SOC计算的影响，考虑ms级的时间误差
		//但是同时也需要考虑到，计算时间溢出的问题，需要特殊处理
		calc_this_time = g_sox_interface_remap.sox_tick_get();

		if (calc_this_time >= g_cell_calc_paras[cell_num].calc_last_time)
		{
			time_diff = (int32_t)(calc_this_time - g_cell_calc_paras[cell_num].calc_last_time);
		}
		else if (calc_this_time < g_cell_calc_paras[cell_num].calc_last_time)
		{
			time_diff = (int32_t)(0xFFFFFFFF - g_cell_calc_paras[cell_num].calc_last_time + calc_this_time + 1);
		}
		// else
		// {
		// 	time_diff = 0;
		// }

		g_cell_calc_paras[cell_num].mAms_accum = g_pack_calc_paras.cur_after_loss_temp * time_diff;

		g_cell_calc_paras[cell_num].calc_last_time = calc_this_time;

	}

	soh_val = (float)soh_calc_val_get(PACK_IS_SELED);   // 统一采用pack里最低的计算值

	//计算参数保护，因为涉及到除法
	//除法溢出会造成严重后果
	if (0 == soh_val)
	{
		soh_val = 100 * SOH_CALC_PRE;
	}

	if (0 == g_pack_calc_paras.bat_rated_cap)
	{
		g_pack_calc_paras.bat_rated_cap = DEFAULTED_RATED_CAP;
	}

	float bat_cap = soh_val * g_pack_calc_paras.bat_rated_cap / SOH_CALC_PRE / 100;
	g_cell_calc_paras[cell_num].mAs_accum = g_cell_calc_paras[cell_num].mAms_accum / 1000;
	float soc_accum = g_cell_calc_paras[cell_num].mAs_accum * 100 / HOUR_TO_SEC / bat_cap;

	//控制了充放电校准的速度，毕竟充放电校准这里采用的是开环校准，所以加入了限制器进行校准限制
	//因为最低充放电电流为10A，所以如果计算出来校准值，至少是1
	if (true == soc_chg_cali(&terminal_cali_val, cell_num))
	{
		//充电校准值控制在[-0.5, +5]*本次充电毫安时
		if ((terminal_cali_val > 0) &&
			(terminal_cali_val > fabs(soc_accum * SOC_CALC_CHG_CALI_UPPER_LIMIT)))
		{
			terminal_cali_val = fabs(soc_accum * SOC_CALC_CHG_CALI_UPPER_LIMIT);
		}
		else if ((terminal_cali_val < 0) &&
				(terminal_cali_val < -1 * fabs(soc_accum / SOC_CALC_CHG_CALI_UNDER_LIMIT)))
		{
			terminal_cali_val = -1 * fabs(soc_accum / SOC_CALC_CHG_CALI_UNDER_LIMIT);
		}
	}
	else if (true == soc_dsg_cali(&terminal_cali_val, cell_num))
	{
		//放电校准值控制在[-1, +0.5]*本次放电毫安时
		if ((terminal_cali_val > 0) &&
			(terminal_cali_val > fabs(soc_accum / SOC_CALC_DSG_CALI_UPPER_LIMIT)))
		{
			terminal_cali_val = fabs(soc_accum / SOC_CALC_DSG_CALI_UPPER_LIMIT);
		}
		else if ((terminal_cali_val < 0) &&
				 (terminal_cali_val < -1 * fabs(soc_accum)))
		{
			terminal_cali_val = -1 * fabs(soc_accum);
		}
	}

	float soc_calc = g_cell_soc_vals[cell_num].calc_val_last + soc_accum + terminal_cali_val;
	//当SOC计算值变化大于0.001%时更新
	g_cell_soc_vals[cell_num].calc_val = (int32_t)soc_calc;
	//更新SOC计算值（t-1）
	g_cell_soc_vals[cell_num].calc_val_last = soc_calc;

	return retval;

}

/**
* @brief		SOC存储
 * @param[in]	无
 * @return		true，保存成功；false，保存失败
 * @note
*/
static int8_t soc_save(int32_t cell_num)
{
	int8_t retval = true;
	int8_t is_matching = 0;

	//如果SOC计算值变化超过5%，或者进入休眠状态，存储SOC计算值
	is_matching =
		(abs(g_cell_soc_vals[cell_num].calc_val - g_cell_soc_vals[cell_num].calc_val_save) > SOC_SAVE_DIFF*FRAC_PRE)
		|| (true == g_pack_calc_paras.pack_shut_raiseup_flag);

	if (true == is_matching)
	{
		g_pack_flags.bit.soc_save = true;
		g_running_status.pack_events.bit.soc_save = true;

		g_bms_running_data.cell_calc_soc[cell_num] = g_cell_soc_vals[cell_num].calc_val;
		g_cell_soc_vals[cell_num].calc_val_save = g_cell_soc_vals[cell_num].calc_val;	//更新保存的SOC数值
	}
	else
	{
		g_running_status.pack_events.bit.soc_save = false;
	}

	return retval;
}

/**
 * @brief		SOC流程初始化
 * @param[in]	sox_interface_remap，定制化函数结构体的地址
 * @return		执行结果
 * @note
*/
void soc_proc_init(sox_interface_remap_t sox_interface_remap)
{
	int32_t cell_index = 0;

	if (false == g_pack_flags.bit.proc_init)
	{
		if ((NULL == sox_interface_remap.sox_bat_status_get)
		|| (NULL == sox_interface_remap.sox_bms_status_get)
		|| (NULL == sox_interface_remap.sox_get_fault)
		|| (NULL == sox_interface_remap.sox_limit_params_get)
		|| (NULL == sox_interface_remap.sox_rtc_get)
		|| (NULL == sox_interface_remap.sox_running_data_get)
		|| (NULL == sox_interface_remap.sox_tick_get)
		|| (NULL == sox_interface_remap.sox_dsg_cali_data_get))
		{
			g_pack_flags.bit.proc_init = false;
			g_running_status.pack_events.bit.proc_initialized = false;
		}
		else
		{
			g_sox_interface_remap = sox_interface_remap;

			g_pack_flags.bit.proc_init = true;
			g_running_status.pack_events.bit.proc_initialized = true;

			g_sox_interface_remap.sox_running_data_get(&g_bms_running_data);

			for (cell_index = 0; cell_index < CELL_VOLT_NUM; cell_index++)
			{
				g_cell_flags[cell_index].bit.overchg =
					g_bms_running_data.cell_full_chg_flag.all_flag & (0x01<<cell_index);

				//读取电芯的OCV校准时间
				g_cell_calc_paras[cell_index].ocv_cali_record_time =
					g_bms_running_data.ocv_cali_time[cell_index];

				//赋值SOC显示值、赋值（t）时刻和（t-1）时刻的SOC、SOC上一次保存值
				g_cell_soc_vals[cell_index].calc_val = g_bms_running_data.cell_calc_soc[cell_index];
				g_cell_soc_vals[cell_index].calc_val_last = g_cell_soc_vals[cell_index].calc_val;
				g_cell_soc_vals[cell_index].calc_val_save = g_bms_running_data.cell_calc_soc[cell_index];
			}
		}
	}
	else if (true == g_pack_flags.bit.proc_init)
	{
		g_running_status.pack_events.bit.proc_initialized = true;
	}
}

/**
 * @brief		SOC计算结束时，刷新数据
 * @param[in]	无
 * @return		无
 * @note		目前只有刷新电芯计算SOC下限
 * @pre			无
*/
static void soc_end_refresh(void)
{
	int32_t i = 0;

	for(i = 0; i < CELL_VOLT_NUM; i++)
	{
		//更新SOC计算值的下限
		if (g_cell_soc_vals[i].calc_val > 1 * SOC_CALC_PRE)
		{
			g_cell_calc_paras[i].soc_calc_lower_limit = NON_EMPTY_LOWEST_SOC;
			g_running_status.cell_events[i].bit.overdsg = false;
		}
		else if (g_cell_soc_vals[i].calc_val < 1 * SOC_CALC_PRE)
		{
			g_cell_calc_paras[i].soc_calc_lower_limit = EMPTY_LOWEST_SOC;
		}

		//更新运行数据
		g_bms_running_data.cell_calc_soc[i] = g_cell_soc_vals[i].calc_val;
	}

	g_bms_running_data.pack_calc_soc = g_pack_soc_vals.calc_val;

	g_pack_flow_flags.func_flow_flag.end_refresh = true;
}

/**
 * @brief		更新SOC判定的各个条件，更新一次最少需要一秒
 * @param[in]	无
 * @return		无
 * @note
 * @pre			无
*/
static void soc_judge_term_refresh(void)
{
	int32_t cell_volt_fl_this_time[CELL_VOLT_NUM] = {0};
	int32_t soc_10_to_volt = 0;
	int32_t temp = 0;
	int32_t i = 0;
	int32_t j = 0;
	limit_params_t limit_params = {0};
	int32_t _5s_cell_volt[5] = {0};

	//更新距离第一次上电启动的时间
	g_bms_running_data.delivery_time++;

	//SOX限制参数的刷新
	g_sox_interface_remap.sox_limit_params_get(&limit_params);
	g_pack_calc_paras.bat_rated_cap = limit_params.rated_cap;

	//获取BCU下发的放电校准数据
	dsg_cali_data_t rx_dsg_cali_data = {0};
	g_sox_interface_remap.sox_dsg_cali_data_get(&rx_dsg_cali_data);

	//更新60秒内BMS状态是否发生变化
	soc_bms_state_is_changed();

	/*******************更新电芯相关的逻辑判断条件*************************/
	//更新电芯电压 超过 满充电压的持续时间
	for (i = 0; i < CELL_VOLT_NUM; i++)
	{
		if (g_sox_sample_data.cell_volt[i] >= FULLCHG_VOLT)
		{
			g_cell_calc_paras[i].overchg_duration++;
		}
		else
		{
			g_cell_calc_paras[i].overchg_duration = 0;
		}
	}

	//捕捉满充事件上升沿
	if ((false == g_pack_calc_paras.overvolt_alarm_lasttime)
	&& (true == g_sox_interface_remap.sox_get_fault(SOX_BAT_CHG_FULL)))
	{
		g_pack_calc_paras.overvolt_alarm_lasttime =
			g_sox_interface_remap.sox_get_fault(SOX_BAT_CHG_FULL);

		g_pack_calc_paras.overvolt_alarm_raiseup_flag = true;
	}
	else
	{
		g_pack_calc_paras.overvolt_alarm_lasttime
			= g_sox_interface_remap.sox_get_fault(SOX_BAT_CHG_FULL);

		g_pack_calc_paras.overvolt_alarm_raiseup_flag = false;
	}

	//为了防止单体过压告警不产生，当某个电芯电压超过3600mV时，也会产生过压上升沿
	//这个判断的刷新需要放在捕捉满充事件上升沿后面，是为了兜底没有满充事件，但是依然充电直到电芯达到3600mV的情况
	for (i = 0; i < CELL_VOLT_NUM; i++)
	{
		if (g_cell_calc_paras[i].overchg_duration >= FULLCHG_DURATION_LIMIT)
		{
			g_pack_calc_paras.overvolt_alarm_raiseup_flag = true;
		}
		else
		{
			;
		}
	}

	//捕捉本地电池放空上升沿
	if ((false == g_pack_calc_paras.local_dsg_empty_lasttime)
	&& (true == g_sox_interface_remap.sox_get_fault(SOX_BAT_DSG_EMPTY)))
	{
		g_pack_calc_paras.local_dsg_empty_lasttime =
			g_sox_interface_remap.sox_get_fault(SOX_BAT_DSG_EMPTY);

		g_pack_calc_paras.local_dsg_empty_raiseup_flag = true;
	}
	else
	{
		g_pack_calc_paras.local_dsg_empty_lasttime
			= g_sox_interface_remap.sox_get_fault(SOX_BAT_DSG_EMPTY);

		g_pack_calc_paras.local_dsg_empty_raiseup_flag = false;
	}

	//捕捉从CAN接收到的电池放空上升沿
	if ((false == g_pack_calc_paras.can_dsg_empty_lasttime)
	&& (true == g_sox_interface_remap.sox_get_fault(SOX_CAN_RECV_EMPTY)))
	{
		g_pack_calc_paras.can_dsg_empty_lasttime =
			g_sox_interface_remap.sox_get_fault(SOX_CAN_RECV_EMPTY);

		g_pack_calc_paras.can_dsg_empty_raiseup_flag = true;
	}
	else
	{
		g_pack_calc_paras.can_dsg_empty_lasttime
			= g_sox_interface_remap.sox_get_fault(SOX_CAN_RECV_EMPTY);

		g_pack_calc_paras.can_dsg_empty_raiseup_flag = false;
	}

	//更新电芯电压 小于 欠压告警电压的持续时间
	for (i = 0; i < CELL_VOLT_NUM; i++)
	{
		if (g_sox_sample_data.cell_volt[i] <= DSGEMPTY_VOLT_LIMIT)
		{
			g_cell_calc_paras[i].overdsg_duration++;
		}
		else
		{
			g_cell_calc_paras[i].overdsg_duration = 0;
		}
	}

	//记录电流小于静置校准电流的持续时间
	if (abs(g_sox_sample_data.sys_cur) <= STANDBY_CUR_LIMIT)
	{
		g_pack_calc_paras.cur_standby_duration += 1;
	}
	else
	{
		g_pack_calc_paras.cur_standby_duration = 0;
	}

	//更新Ut,min小于OCV（SOC = 10%）的持续时间
	//查表获取SOC=10%时对应的OCV
	temp = soc_to_ocv(DSG_CALI_SOC * SOC_CALC_PRE, g_pack_cur.fl_signal.cur_this_time,
			g_sox_sample_data.min_cell_temp, &soc_10_to_volt);

	for (i = 0; i < CELL_VOLT_NUM; i++)
	{
		cell_volt_fl_this_time[i] = g_cell_fl_volt[i].volt_this_time;
	}

	if (SOX_FAIL == temp)
	{
		g_pack_calc_paras.under_volt_table_time = 0;
	}
	else
	{
		if ((soc_10_to_volt >= min_array(cell_volt_fl_this_time,CELL_VOLT_NUM))
		|| (soc_10_to_volt >= rx_dsg_cali_data.can_soc_min_to_volt))
		{
			g_pack_calc_paras.under_volt_table_time += 1;
		}
		else
		{
			g_pack_calc_paras.under_volt_table_time = 0;
		}
	}

	//更新电池关机信息，触发式
	if ((SOX_BMS_SHUT_DOWN == g_sox_interface_remap.sox_bms_status_get())
	&& (SOX_BMS_SHUT_DOWN != g_pack_calc_paras.pack_shut_last_time))
	{
		g_pack_calc_paras.pack_shut_raiseup_flag = true;
	}
	else
	{
		g_pack_calc_paras.pack_shut_raiseup_flag = false;
	}

	g_pack_calc_paras.pack_shut_last_time = g_sox_interface_remap.sox_bms_status_get();

	if (true == g_pack_calc_paras.there_is_5s_volt)
	{
		for(i = 0; i < CELL_VOLT_NUM; i++)
		{
			for(j = 0; j < SOC_CELL_VOLT_GET_COUNT; j++)
			{
				_5s_cell_volt[j] = g_pack_calc_paras.p_cell_volt_5s_array->cell_vol[j][i];
			}

			g_cell_calc_paras[i].cell_max_volt_past_5s = max_array((int32_t *)_5s_cell_volt, SOC_CELL_VOLT_GET_COUNT);
		}
	}
}

/**
 * @brief		SOC计算值限制
 * @param[in]	无
 * @return		无
 * @note
*/
static void soc_calc_val_limit(void)
{
	int32_t i = 0;

	for (i = 0; i < CELL_VOLT_NUM; i++)
	{
		//SOC计算值限制，如果SOC突破了设置的上下限，就直接强制设置到上下限数值
		//一般最高上限在99%，判饱后最高上限设置在100%
		if (g_cell_soc_vals[i].calc_val > g_cell_calc_paras[i].soc_calc_upper_limit*SOC_CALC_PRE)
		{
			g_cell_soc_vals[i].calc_val = g_cell_calc_paras[i].soc_calc_upper_limit*SOC_CALC_PRE;
			g_cell_soc_vals[i].calc_val_last = g_cell_calc_paras[i].soc_calc_upper_limit*SOC_CALC_PRE;
		}

		//一般最高下限在1%，判饱后最低下限设置在0%
		if (g_cell_soc_vals[i].calc_val < g_cell_calc_paras[i].soc_calc_lower_limit*SOC_CALC_PRE)
		{
			g_cell_soc_vals[i].calc_val = g_cell_calc_paras[i].soc_calc_lower_limit*SOC_CALC_PRE;
			g_cell_soc_vals[i].calc_val_last = g_cell_calc_paras[i].soc_calc_lower_limit*SOC_CALC_PRE;
		}
	}

	g_pack_flow_flags.func_flow_flag.calc_limit = true;
}

/**
* @brief		滑窗记录最近时间内的电池数据
* @param		uint16_t cell_num 电芯数量
* @param		*p_vol_count  电压记录时刻下标
* @param		*p_curr_count 电流记录下标
* @param		sox_scroll_record_data_t *p_scroll_record_data 滚动记录的电池数据结构体
* @param		balance_bat_data_t *p_balance_bat_data 均衡需要的电池数据
* @return		RUNNING_OK：记录成功  RUNNING_FAIL: 记录失败
 * @note
*/
static bool sox_sliding_filter_record_bat_data(uint8_t *p_vol_count,uint8_t *p_curr_count,sox_scroll_record_data_t *p_scroll_record_data,sox_sample_data_t *p_sox_sample_data)
{
    uint8_t i =0, j = 0, m = 0;

    if ((NULL == p_vol_count ) ||
        (NULL == p_curr_count) ||
        (NULL == p_scroll_record_data) ||
        (NULL == p_sox_sample_data))       //入参判断
     {

         return RUNNING_FAIL;
     }

    //滚动记录电流值
     if ((*p_curr_count) >= _60S_BASED_1S)      // 满窗
    {

        for (i = 0; i < _60S_BASED_1S - 1; i++) //将1之后的数据移到0之后 即移除头部
        {
            p_scroll_record_data->sys_curr[i] = p_scroll_record_data->sys_curr[i + 1];
        }
        p_scroll_record_data->sys_curr[_60S_BASED_1S - 1] = p_sox_sample_data->sys_cur; // 添加尾部 最新1S的数据放在最后

        (*p_curr_count) = _60S_BASED_1S;//锁定当前时刻在尾部 下标 = 个数 -1
    }
     else if ((*p_curr_count) < _60S_BASED_1S)                     // 不满窗口 先填充
    {
        p_scroll_record_data->sys_curr[*p_curr_count] = p_sox_sample_data->sys_cur;
        (*p_curr_count)++;
    }

    //滚动记录电芯电压值
   if ((*p_vol_count) >= _5S_BASED_1S)    // 满窗
    {
        for (j = 0; j < _5S_BASED_1S - 1; j++) //将1之后的数据移到0之后 即移除头部
        {
            for (i = 0; i < CELL_VOLT_NUM; i++)
            {
              p_scroll_record_data->cell_vol[j][i] = p_scroll_record_data->cell_vol[j + 1][i];
            }
        }
        for (m = 0; m < CELL_VOLT_NUM; m++)                  // 添加尾部 最新1S的数据放在最后
        {
          p_scroll_record_data->cell_vol[_5S_BASED_1S - 1][m] =  p_sox_sample_data->cell_volt[m];
        }
        (*p_vol_count) = _5S_BASED_1S; //锁定当前时刻在尾部 下标 = 个数 -1
    }
   else if ((*p_vol_count) < _5S_BASED_1S)                    //不满窗口  先填充
    {
         for (i = 0; i < CELL_VOLT_NUM; i++)
        {
          p_scroll_record_data->cell_vol[*p_vol_count][i] =  p_sox_sample_data->cell_volt[i];
        }
        (*p_vol_count)++;
    }

    return RUNNING_OK;
}

/**
* @brief		滑窗记录电池数据
* @param		无
* @return		RUNNING_OK：记录成功  RUNNING_FAIL: 记录失败
* @note
*/
static void sox_sliding_filter_record_proc(void)
{
	bool scroll_record_now_flag = false;         //当前时刻滑窗记录函数返回值
	static bool scroll_record_last_flag = false; //上一时刻滑窗记录的返回值

	//滚动记录电芯电压和电流数据 1S线程进一次保存一组数据
	scroll_record_now_flag = sox_sliding_filter_record_bat_data(&g_enter_proc_vol_index, &g_enter_proc_curr_index, &g_sox_scroll_record_data, &g_sox_sample_data);

	//触发数据异常 打印数据
	if (RUNNING_FAIL == scroll_record_now_flag)
	{
		if (RUNNING_OK == scroll_record_last_flag)
		{
		//log_e("SOCSlidDataErr\n");
		for(uint8_t i = 0; i < _60S_BASED_1S; i++)
		{
			//log_e("I[%d]:%d ",i,g_sox_scroll_record_data.sys_curr);
		}
		for(uint8_t j = 0; j < _5S_BASED_1S; j++)
		{
			for(uint8_t k = 0; k < CELL_VOLT_NUM; k++)
			{
				//log_e("CellV[%d][%d]:%d \n",j,k,g_sox_scroll_record_data.cell_vol[j][k]);
			}
		}
		}
	}
	//数据恢复正常触发打印
	else if ((RUNNING_FAIL == scroll_record_last_flag) &&
		(RUNNING_OK == scroll_record_now_flag))
	{
		#ifdef CELL_BAL_DEBUG
		//log_e("CellBalSlidDataOk\n");
		#endif
	}
	scroll_record_last_flag = scroll_record_now_flag;

	if (RUNNING_FAIL == scroll_record_last_flag)
	{
		return;
	}
}

/**
 * @brief		SOC流程
 * @param[in]	无
 * @return		无
 * @note
*/
void soc_proc(void)
{
	int32_t fsm_ret = true;
	static int8_t scroll_record_cnt = 0;

	//SOC计算状态机，判断当前SOX计算到哪个电芯、执行完成与否
	//并执行相应的处理函数
	fsm_ret =  sox_calc_fsm(&g_sox_fsm_machine);

	//采样数据没拿到或者SOC计算状态机返回异常，跳过此次SOC计算
	if ((true == g_running_status.errors.bit.sample_get_failed)
	|| (SOX_FAIL == fsm_ret))
	{
		;
	}
	//SOC模块没有初始化，跳过此次SOC计算
	else if (false == g_pack_flags.bit.proc_init)
	{
		g_running_status.pack_events.bit.proc_initialized = false;
	}
	//t+1时刻未到，电芯SOC计算完成，跳过此次SOC计算
	//进行SOC的结算，加入了流程执行标志，防止反复结算
	else if (true == g_pack_flags.bit.cell_calc_done)
	{
		if (((CELL_VOLT_NUM - 1) == g_pack_calc_paras.cell_calc_index)
			&& (0x1F != g_pack_flow_flags.all_flag)
			&& (false == g_running_status.errors.bit.sample_over_limit))
		{
			if (false == g_pack_flow_flags.func_flow_flag.over_chg)
			{
				soc_overchg_manage();		//判饱处理
			}

			if (false == g_pack_flow_flags.func_flow_flag.over_dsg)
			{
				soc_overdsg_manage();		//判空处理
			}

			if (false == g_pack_flow_flags.func_flow_flag.calc_limit)
			{
				soc_calc_val_limit();		//SOC计算值限制
			}

			if (false == g_pack_flow_flags.func_flow_flag.chg_dsg_record)
			{
				soc_chg_dsg_record();		//SOC充放电记录
			}

			if (false == g_pack_flow_flags.func_flow_flag.end_refresh)
			{
				soc_end_refresh();			//刷新SOC数据及上下限
			}
		}
	}
	else if (true != g_pack_flags.bit.cell_calc_done)
	{
		if (false == g_running_status.errors.bit.sample_over_limit)
		{
			soc_val_calc(g_pack_calc_paras.cell_calc_index);			//SOC计算及计算值限制
			soc_standby_manage(g_pack_calc_paras.cell_calc_index);		//静置处理
			soc_save(g_pack_calc_paras.cell_calc_index);				//SOC存储
		}

		g_bms_running_data.soc_running_status = g_running_status;
	}

	//滑窗记录数据，1S一次
	if (--scroll_record_cnt <= 0)
    {
        scroll_record_cnt = 100;
        sox_sliding_filter_record_proc();
    }
}

/**
* @brief		滚动记录的5S电芯电压和系统电流值数据对外获取
* @param		void
* @return		sox_scroll_record_data_t 滚动记录数据结构体
* @note
*/
sox_scroll_record_data_t* sox_scroll_record_data_5s_data_get(void)
{
    sox_scroll_record_data_t* ret = NULL;
    ret = &g_sox_scroll_record_data;
    return ret;
}

/**
 * @brief		获取PACK的SOC显示值
 * @param[in]	无
 * @return		PACK的SOC显示值
 * @note
*/
int32_t soc_pack_display_val_get(void)
{
	int32_t retval = 0;

	retval = g_pack_soc_vals.display_val;

	return retval;
}

/**
 * @brief		获取SOC计算值
 * @param[in]	sel_cmd，命令，选择获取电芯还是PACK
 * @return		获取指定的电芯或者PACK的SOC计算值
 * @note
*/
int32_t soc_calc_val_get(sox_cell_sel_e sel_cmd)
{
	int32_t retval = 0;

	if (PACK_IS_SELED == sel_cmd)
	{
		retval = g_pack_soc_vals.calc_val;
		return retval;
	}
	else
	{
		retval = g_cell_soc_vals[sel_cmd].calc_val;
		return retval;
	}
}

/**
 * @brief		设置SOC计算值
 * @param[in]	sel_cmd，命令，选择设置电芯还是PACK
 * @param[in]	soc_val_temp，需要设置的SOC数值（0~100，整数）
 * @return		0，处理成功；非0，处理失败
 * @note
*/
int32_t soc_calc_val_set(sox_cell_sel_e sel_cmd, int32_t soc_val_temp)
{
	int32_t retval = 0;
	int16_t cell_index = 0;

	if (PACK_IS_SELED == sel_cmd)
	{
		for (cell_index = 0; cell_index < CELL_VOLT_NUM; cell_index++)
		{
			if ((soc_val_temp <= FULL_HIGHEST_SOC) && (soc_val_temp >= EMPTY_LOWEST_SOC))
			{
				g_cell_soc_vals[cell_index].calc_val = soc_val_temp*SOC_CALC_PRE;
			}
			else if (soc_val_temp > FULL_HIGHEST_SOC)
			{
				g_cell_soc_vals[cell_index].calc_val = FULL_HIGHEST_SOC*SOC_CALC_PRE;
			}
			else if (soc_val_temp < EMPTY_LOWEST_SOC)
			{
				g_cell_soc_vals[cell_index].calc_val = EMPTY_LOWEST_SOC;
			}

			g_cell_soc_vals[cell_index].calc_val_last = g_cell_soc_vals[cell_index].calc_val;

			g_bms_running_data.cell_calc_soc[cell_index] = g_cell_soc_vals[cell_index].calc_val;
		}

		if ((soc_val_temp <= FULL_HIGHEST_SOC) && (soc_val_temp >= EMPTY_LOWEST_SOC))
		{
			g_pack_soc_vals.calc_val = soc_val_temp*SOC_CALC_PRE;
		}
		else if (soc_val_temp > FULL_HIGHEST_SOC)
		{
			g_pack_soc_vals.calc_val = FULL_HIGHEST_SOC*SOC_CALC_PRE;
		}
		else if (soc_val_temp < EMPTY_LOWEST_SOC)
		{
			g_pack_soc_vals.calc_val = EMPTY_LOWEST_SOC;
		}

		//因为显示值的变化速度有限制，所以这里也要直接给显示值赋值
		g_pack_soc_vals.display_val =
			(g_pack_soc_vals.calc_val + THOUTHAND_ROUND_OFF)/SOC_CALC_PRE;
		g_pack_soc_vals.calc_val_last = g_pack_soc_vals.calc_val;

		g_bms_running_data.pack_calc_soc = g_pack_soc_vals.calc_val;
	}
	else
	{
		if ((soc_val_temp <= FULL_HIGHEST_SOC) && (soc_val_temp >= EMPTY_LOWEST_SOC))
		{
			g_cell_soc_vals[sel_cmd].calc_val = soc_val_temp*SOC_CALC_PRE;
		}
		else if (soc_val_temp > FULL_HIGHEST_SOC)
		{
			g_cell_soc_vals[sel_cmd].calc_val = FULL_HIGHEST_SOC*SOC_CALC_PRE;
		}
		else if (soc_val_temp < EMPTY_LOWEST_SOC)
		{
			g_cell_soc_vals[sel_cmd].calc_val = EMPTY_LOWEST_SOC;
		}

		g_cell_soc_vals[sel_cmd].calc_val_last = g_cell_soc_vals[sel_cmd].calc_val;
		g_bms_running_data.cell_calc_soc[sel_cmd] = g_cell_soc_vals[sel_cmd].calc_val;
	}

	g_pack_flags.bit.soc_save = true;

	return retval;
}

/**
 * @brief		获取SOC保存标志位
 * @param[in]	无
 * @return		SOC保存标志位
 * @note
*/
uint16_t soc_save_flag_get(void)
{
	uint16_t retval = false;

	retval = g_pack_flags.bit.soc_save;

	return retval;
}

/**
 * @brief		重置SOC保存标志位
 * @param[in]	无
 * @return		无
 * @note
*/
void soc_save_flag_reset(void)
{
	g_pack_flags.bit.soc_save = false;
}

/**
 * @brief		获取SOC初始化标志位
 * @param[in]	无
 * @return		SOC初始化标志位
 * @retval		SOC初始化标志位
 * @note
 * @pre			无
*/
uint16_t soc_init_flag_get(void)
{
	uint16_t retval = false;

	retval = g_pack_flags.bit.params_init;

	return retval;
}

/**
 * @brief		获取SOX运行数据的地址，用于SOX模块内部
 * @param[in]	无
 * @return		返回sox_running_data_t*，全局运行数据的指针
 * @note
*/
sox_running_data_t* sox_running_data_addr_inf(void)
{
	sox_running_data_t* retval = NULL;

	retval = &g_bms_running_data;

	return retval;
}

/**
 * @brief		设置SOX运行数据
 * @param[in]	sox_running_data，需要设置的SOX运行数据的地址
 * @return		true，获取成功；false，获取失败
 * @note
*/
int32_t sox_running_data_set(sox_running_data_t* sox_running_data)
{
	int32_t retval = true;

	if (NULL == sox_running_data)
	{
		retval = false;
		return retval;
	}

	g_bms_running_data = *sox_running_data;

	return retval;
}

/**
* @brief		获取从CAN读取到的BMU-SOC
* @param		data_in，从CAN读取到的BMU-SOC
* @return		返回int16_t，读取到的BMU-SOC数值
* @note
*/
void sox_get_bmu_soc(uint16_t data_in)
{
	if (data_in > 0)
	{
		if (g_pack_calc_paras.can_soc_get > 0)
		{
			;
		}
		else if (0 == g_pack_calc_paras.can_soc_get)
		{
			g_pack_calc_paras.can_soc_get = data_in;
		}
	}
	else if (data_in <= 0)
	{
		;
	}
}

/**
* @brief		发送本地需要向其它BMU传递的BMU-SOC
* @param		无
* @return		返回结果 需要设置的BMU-SOC数值
* @note
*/
uint16_t sox_set_bmu_soc(void)
{
	return g_pack_calc_paras.upload_to_other_bmu_soc;
}

/**
* @brief		获取滚动记录的5S电芯电压
* @param		void
* @return		无
* @note
*/
void cell_volt_5s_get(sox_scroll_record_data_t* p_in)
{
    if (NULL == p_in)
	{
		g_pack_calc_paras.there_is_5s_volt = false;
	}
	else
	{
		g_pack_calc_paras.there_is_5s_volt = true;
		g_pack_calc_paras.p_cell_volt_5s_array = p_in;

	}
}

/**
 * @brief		重置SOC模块，除了定制化接口
 * @param[in]	无
 * @return		无
 * @note
*/
void soc_reset(void)
{
	sox_sample_data_t sample_data = {0};
	soc_pack_cur_t soc_pack_cur = {0};
	soc_val_t soc_val = {0};
	soc_pack_calc_para_t soc_pack_calc_para = {
		.bat_state_record_time = 0,					///< BMS上一次状态的时间
		.bat_state = SOX_BAT_STANDBY,				///< BMS上一次的状态
		.fl_coff = SOC_FIL_COFF,				///< 电压电流一阶滤波系数
		.bat_rated_cap = 100,						///< 电池额定容量
		.cur_after_loss_temp = 0,					///< SOX损耗补偿电流
		.cur_standby_duration = 0,					///< 记录电流的绝对值小于0.2A的持续时间
		.overvolt_alarm_lasttime = 0,				///< 上一次过压告警的状态
		.overvolt_alarm_raiseup_flag = false,		///< 过压告警上升沿标志
		.local_dsg_empty_lasttime = false,
		.local_dsg_empty_raiseup_flag = false,
		.can_dsg_empty_lasttime = false,
		.can_dsg_empty_raiseup_flag = false,
		.upload_to_other_bmu_soc = 0,
		.display_time = 0,							///< PACK的SOC显示值更新时间
	};

	soc_pack_flag_u soc_pack_flag = {
		.bit.params_init = false,
		.bit.proc_init = false,
		.bit.soc_save = false,
		.bit.cell_calc_start = true,
		.bit.cell_calc_done = false,
	};
	sox_running_data_t sox_running_data = {0};
	soc_status_t soc_running_status = {0};

	g_tx_dsg_cali_data.can_calc_val = 0xFFFF;
	g_tx_dsg_cali_data.can_soc_min_to_volt = 0xFFFF;
	g_tx_dsg_cali_data.can_min_cell_volt = 0xFFFF;

	g_pack_calc_paras.cell_calc_index = 0;
	g_pack_calc_paras.cell_calc_cycle = 0;

	g_sox_sample_data = sample_data;
	g_pack_cur = soc_pack_cur;
	g_pack_soc_vals = soc_val;
	g_pack_calc_paras = soc_pack_calc_para;
	g_pack_flags = soc_pack_flag;

	g_bms_running_data = sox_running_data;
	g_running_status = soc_running_status;
	g_pack_soc_vals = soc_val;

	g_pack_flags.bit.proc_init = true;

	g_sox_fsm_machine.cur_state = CALC_INIT;
	g_sox_fsm_machine.transnum = 13;
	g_sox_fsm_machine.trans = g_sox_fsm_trans_tab;

	memset(g_cell_fl_volt, 0, CELL_VOLT_NUM*sizeof(volt_fl_t)/sizeof(int8_t));
	memset(g_cell_soc_vals, 0,  CELL_VOLT_NUM*sizeof(soc_val_t)/sizeof(int8_t));
	memset(g_cell_calc_paras, 0,  CELL_VOLT_NUM*sizeof(soc_cell_calc_para_t)/sizeof(int8_t));
	memset(g_cell_flags, 0,  CELL_VOLT_NUM*sizeof(soc_cell_flag_u)/sizeof(int8_t));
}

static void sox_3d_calc_test(int32_t x_value, int32_t y_value, int32_t z_value)
{
	int32_t temp = 0;
	soc_to_ocv(x_value, y_value, z_value, &temp);
	log_d("3d_value = %d\n", temp);
}
/**
 * @brief        sox功能样例
 * @param        cmd 功能参数
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
static int soc(int argc, char *argv[])
{
	if (!strcmp(argv[1], "calc"))
	{
		uint8_t calc_mode = atoi(argv[2]); // 1:一维计算 2：二维计算 3：三位计算
		int32_t x_value = atoi(argv[3]);   // x
		int32_t y_value = atoi(argv[4]);   // y
		int32_t z_value = atoi(argv[5]);   // z

		if (calc_mode == 3)
		{
			sox_3d_calc_test(x_value, y_value, z_value);
		}
	}

	return 0;
}
MSH_CMD_EXPORT(soc, <print / calc>);
