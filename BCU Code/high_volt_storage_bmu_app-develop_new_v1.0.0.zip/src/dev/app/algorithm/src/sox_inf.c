/**
 * @file     sox_public_inf.c
 * @brief    sox算法外部输入接口
 * @company  sofarsolar
 * @author
 * @date
 */

#include <string.h>
#include <stdlib.h>
#include "soc.h"
#include "soh.h"
#include "soe.h"
#include "sop.h"
#include "sox_sample.h"
#include "sox_stats.h"
#include "sox_public.h"
#include "sdk.h"
#include "fault_manage.h"
#include "bms_state.h"
#include "bmu_data.h"
#include "app_public.h"
#include "data_store.h"
#include "public_flag.h"
#include "sofar_can_data.h"
#include "passive_balance.h"
#include "ate.h"
#include "afe_bq79600.h"


#ifdef SOX_SHELL_DEBUG_TEST
static bool g_sox_shell_debug_flag = false;
#endif

// #define SOX_DEBUG

#ifdef SOX_DEBUG
	static int32_t g_sox_debug_sys_cur = 0;
    static int32_t g_sox_debug_pack_volt = 158400;
    static int32_t g_sox_debug_min_volt = 3300;
    static int32_t g_sox_debug_max_volt = 3300;
    static int16_t g_sox_debug_max_temp = 25;
    static int16_t g_sox_debug_min_temp = 25;
    static int32_t g_sox_debug_avg_volt = 3300;
    static int16_t g_sox_debug_avg_temp = 25;

    static uint16_t g_sox_debug_soc = 0;

    static uint16_t g_sox_debug_chg_level = 3;
    static uint16_t g_sox_debug_dsg_level = 3;

    static int32_t g_sox_debug_cell_volt = 3300;
    static int16_t g_sox_debug_cell_temp = 25;
	static sox_bat_status_e g_sox_debug_bat_status = SOX_BAT_STANDBY;
#endif

#define TEN_TIMES (10)
#define SOX_TIME_BASE    (10)                      // 一个周期为100ms
#define SOX_ONE_SEC_BASE  (1000 / SOX_TIME_BASE)    // 一秒周期时间的次数
#define SOX_RUN_SAVE_TIMER (1800 * SOX_ONE_SEC_BASE)   // 半个小时检测是否要存储
#define SOX_SET_DATE_TIME_OVER (4 * SOX_ONE_SEC_BASE)  // 4s，由于bcu上电第一分钟每2s同步一次时间，

static sox_data_t g_sox_data = {0};
static dsg_cali_data_t g_rx_dsg_cali_data = {0};
static volt_diff_pas_bal_data_t g_rx_volt_diff_pas_bal_data = {0};
static uint32_t g_sox_run_timer_b10ms = SOX_RUN_SAVE_TIMER / 2;  // 第一次提前15min
static uint8_t g_sox_init_finish_flag = true;                         // sox初始化完成
static uint16_t g_wait_bcu_set_date_over_cnt = SOX_SET_DATE_TIME_OVER;   // 等待bcu同步时间超时
static uint32_t g_last_soc_event_status = 0;  // 参考:soc_event_u
static uint32_t g_last_soh_event_status = 0;  // 参考:soh_event_u
static uint32_t g_last_soc_error_status = 0;  // 参考:soc_errors
static uint32_t g_last_soh_error_status = 0;  // 参考:soh_errors

static bool g_disable_cell_balance_flag = false;  // 屏蔽电芯均衡功能，true:屏蔽， false:正常均衡


/*************************************************************************************************/
/****************************** SOX(SOC、SOH)调试、打印或外部调用**********************************/
/************************************************************************************************/

/**
 * @brief    获取SOX数据
 * @param[in] 无
 * @return   const sox_data_t*
 * @note
 */
const sox_data_t* sox_data_get_deal(void)
{
    if (!g_sox_init_finish_flag)
    {
        return NULL;
    }
    soc_pack_event_u soc_evt = {0};
    soc_evt.bytes = g_last_soc_event_status;
    if (0 == soc_evt.bit.initialized)
    {
        return NULL;
    }
    return (const sox_data_t*)(&g_sox_data);
}

/**
 * @brief    设置SOX数据debug
 * @param[in] debug_flag
 * @param[in] val_type
 * @param[in] val
 * @return   无
 * @note
 */
void sox_data_set_debug(bool debug_flag, int32_t val_type, int32_t val)
{
    g_sox_shell_debug_flag = debug_flag;
    if (!debug_flag)
    {
        return;
    }
    switch (val_type)
    {
        case DISPLAY_SOC_SET:
            g_sox_data.calc_soc = val * 1000;
            g_sox_data.display_soc = val;
            break;
        case DISPLAY_SOH_SET:
            g_sox_data.calc_soh = val * 1000;
            g_sox_data.display_soh = val;
            break;
        case TOTAL_CHG_AH_SET:
            g_sox_data.total_chg_ah = val;
            break;
        case TOTAL_DSG_AH_SET:
            g_sox_data.total_dsg_ah = val;
            break;
        case TOTAL_CHG_WH_SET:
            g_sox_data.total_chg_wh = val;
            break;
        case TOTAL_DSG_WH_SET:
            g_sox_data.total_dsg_wh = val;
            break;
        default:
            break;
    }
}

/**
 * @brief                sox状态变更或故障触发消除打印
 * @param[in]             无
 * @return               无
 * @note                 无
 */
static void sox_status_or_err_print(void)
{
    sox_running_data_t* sox_runing_data = NULL;
    sox_runing_data = sox_running_data_addr_get();

    if (NULL == sox_runing_data)
    {
        return;
    }
    // 屏蔽保存标志和充放电记录时间
    if ((sox_runing_data->soc_running_status.pack_events.bytes & 0xFFFFFF21) != (g_last_soc_event_status & 0xFFFFFF21))
    {
        log_e("socEvt:last%lx,now%lx\n", g_last_soc_event_status, sox_runing_data->soc_running_status.pack_events.bytes);
    }
    if (sox_runing_data->soc_running_status.errors.bytes != g_last_soc_error_status)
    {
        log_e("socErr:last%lx,now:%lx\n", g_last_soc_error_status, sox_runing_data->soc_running_status.errors.bytes);
    }
    if (sox_runing_data->soh_running_status.pack_events.bytes != g_last_soh_event_status)
    {
        log_e("sohEvt:last%lx,now:%lx\n", g_last_soh_event_status, sox_runing_data->soh_running_status.pack_events.bytes);
    }
    if (sox_runing_data->soh_running_status.errors.bytes != g_last_soh_error_status)
    {
        log_e("sohErr:last%lx,now:%lx\n", g_last_soh_error_status, sox_runing_data->soh_running_status.errors.bytes);
    }
    g_last_soc_event_status = sox_runing_data->soc_running_status.pack_events.bytes;
    g_last_soc_error_status = sox_runing_data->soc_running_status.errors.bytes;
    g_last_soh_event_status = sox_runing_data->soh_running_status.pack_events.bytes;
    g_last_soh_error_status = sox_runing_data->soh_running_status.errors.bytes;
}


/**
 * @brief                接收SOX放电校准数据
 * @param[in]           val_type
 * @param[in]           val
 * @return               int32_t
 * @note                无
 */
int32_t sox_dsg_cali_data_set(uint8_t val_type, uint16_t val)
{
    switch (val_type)
    {
        case RX_SOC_MIN_TO_VOLT_SET:
            g_rx_dsg_cali_data.can_soc_min_to_volt = (int32_t)val;
            break;
        case RX_CALC_VAL_SET:
            g_rx_dsg_cali_data.can_calc_val = (int32_t)val;
            break;
		case RX_MIN_CELL_VOLT:
			g_rx_dsg_cali_data.can_min_cell_volt = (int32_t)val;
        default:
            break;
    }
    return 0;
}

/**
 * @brief                接收压差被动均衡所需数据
 * @param[in]           val_type
 * @param[in]           val
 * @return               int32_t
 * @note                无
 */
int32_t volt_diff_pas_bal_data_set(uint8_t val_type, uint16_t val)
{
    switch (val_type)
    {
        case RX_CLU_MIN_VOLT_SET:
            g_rx_volt_diff_pas_bal_data.clu_min_cell_volt = val;
            break;

        default:
            break;
    }
    return 0;
}

/**
 * @brief                存储SOX的运行数据
 * @param                void
 * @return               无
* @note               10ms任务
 */
static void sox_running_data_cycle_save_deal(void)
{

    uint8_t save_data_flag = 0;
    uint8_t temp = 0;

    if (g_sox_run_timer_b10ms > 0)
    {
        g_sox_run_timer_b10ms--;
        return;
    }

    g_sox_run_timer_b10ms = SOX_RUN_SAVE_TIMER;
    temp = sox_stats_save_flag_get() | soc_save_flag_get() | soh_save_flag_get();
    if (true == temp)
    {
        save_data_flag = true;
        soh_save_flag_reset();
        soc_save_flag_reset();
        sox_stats_save_flag_reset();
    }
    else
    {
        return;
    }
    if (save_data_flag)
    {
        sox_running_data_t sox_running_data = *sox_running_data_addr_get();
        bms_sox_runing_data_save(sox_running_data);
    }
}

/**
 * @brief		获取SOX模块计算的数据
 * @param[in]	p_out，数据结构体，保存获取到的SOX模块数据，sox_data_t* 类型
 * @return		0，执行成功，非0，执行失败
 * @note
*/
int32_t sox_data_get(sox_data_t* p_out)
{
	int32_t retval = true;
	sox_stats_t sox_stats = {0};
	int32_t temp = 0;
	int8_t cell_counter = 0;

	if (NULL  == p_out)
	{
		return SOX_FAIL;
	}

	temp = sox_stats_get(&sox_stats);

	if (SOX_FAIL == temp)
	{
		return SOX_FAIL;
	}
	else
	{
		for (cell_counter = 0; cell_counter < CELL_VOLT_NUM; cell_counter++)
		{
			p_out->cell_display_soc[cell_counter] =
				(soc_calc_val_get((sox_cell_sel_e)cell_counter) + THOUTHAND_ROUND_OFF) / FRAC_PRE;
			p_out->cell_display_soh[cell_counter] =
				(soh_high_pre_get((sox_cell_sel_e)cell_counter) + THOUTHAND_ROUND_OFF) / FRAC_PRE;
		}

		p_out->calc_soc = soc_calc_val_get(PACK_IS_SELED);
		p_out->calc_soh = soh_high_pre_get(PACK_IS_SELED);
		p_out->display_soc = soc_pack_display_val_get();
		p_out->display_soh = soh_pack_display_val_get();

		p_out->total_chg_ah = sox_stats.sumed_chg_ah;
		p_out->total_dsg_ah = sox_stats.sumed_dsg_ah;
		p_out->total_chg_wh = sox_stats.sumed_chg_wh;
		p_out->total_dsg_wh = sox_stats.sumed_dsg_wh;

		p_out->remained_cap = sox_stats_remained_cap_get();
		p_out->real_cap = sox_stats_real_cap_get();

		p_out->cycle_count = sox_stats.sumed_display_cycle;
	}

	return retval;
}

/**
* @brief		设置SOX模块指定数据  // todo  暂时不删，因为打印有用到
 * @param[in]	sox_data_cmd，指定数据对应的命令，sox_data_cmd_e类型
 * @param[in]	data_in，需要设置的数据，uint32_t类型
 * @return		0，执行成功，非0，执行失败
 * @warning		无
 * @note
*/
int32_t sox_data_set(sox_data_cmd_e sox_data_cmd, uint32_t data_in)
{
	int32_t retval = true;

	switch (sox_data_cmd)
	{
		case DISPLAY_SOC_SET:
		{
			soc_calc_val_set(PACK_IS_SELED,data_in);
			break;
		}
		case DISPLAY_SOH_SET:
		{
			soh_calc_val_set(PACK_IS_SELED, data_in);
			break;
		}
		case TOTAL_CHG_AH_SET:
		{
			sox_stats_chg_ah_set(data_in);
			break;
		}
		case TOTAL_DSG_AH_SET:
		{
			sox_stats_dsg_ah_set(data_in);
			break;
		}
		case TOTAL_CHG_WH_SET:
		{
			sox_stats_chg_wh_set(data_in);
			break;
		}
		case TOTAL_DSG_WH_SET:
		{
			sox_stats_dsg_wh_set(data_in);
			break;
		}
	}

	return retval;
}

/*************************************************************************************************/
/********************************************* 填充SOX接口函数*************************************/
/************************************************************************************************/

/**
 * @brief                获取FLASH中的SOX运行数据
 * @param[in]             sox_runing_data指针
 * @return               返回结果 无
 * @note                 无
 */
static void sox_running_data_get_deal(sox_running_data_t *p_sox_runing_data)
{
    if (NULL == p_sox_runing_data)
    {
        return;
    }
    const sox_running_data_t *p_bms_run_data = NULL;
    p_bms_run_data = &(get_bms_runing_data()->sox_running_data);
    if (NULL != p_bms_run_data)
    {
        memcpy(p_sox_runing_data, p_bms_run_data, sizeof(sox_running_data_t));
    }
    else
    {
        memset(p_sox_runing_data, 0, sizeof(sox_running_data_t));
    }
}

// /**
//  * @brief                获取FLASH中的SOX运行数据的指针
//  * @param[in]             无
//  * @return               返回sox_running_data_t*，全局运行数据的指针
//  * @note                 无
//  */
// static sox_running_data_t * sox_running_data_addr_get_deal(void)
// {
//     return (sox_running_data_t *)&(get_bms_runing_data()->sox_running_data);
// }

/**
 * @brief		获取SOX模块内部的SOX运行数据地址
 * @param[in]	无
 * @return		返回sox_running_data_t*，全局运行数据的指针
 * @note
*/
sox_running_data_t* sox_running_data_addr_get(void)
{
    sox_running_data_t* sox_runing_data = NULL;
    sox_runing_data = sox_running_data_addr_inf();

    if (NULL == sox_runing_data)
    {
        return NULL;
    }
	return sox_runing_data;
}

/**
 * @brief                获取RTC时间
 * @param[in]             sox_rtc_t指针
 * @return               无
 * @note                 无
 */
static void sox_rtc_get_deal(sox_rtc_t *p_sox_rtc)
{
    if (NULL == p_sox_rtc)
    {
        return;
    }

    sdk_rtc_t sdk_rtc = {0};
    sdk_rtc_get(RTC_BIN_FORMAT, &sdk_rtc);

    (*p_sox_rtc).tm_year = sdk_rtc.tm_year;
    (*p_sox_rtc).tm_mon = sdk_rtc.tm_mon;
    (*p_sox_rtc).tm_weekday = sdk_rtc.tm_weekday;
    (*p_sox_rtc).tm_day = sdk_rtc.tm_day;
    (*p_sox_rtc).tm_hour = sdk_rtc.tm_hour;
    (*p_sox_rtc).tm_min = sdk_rtc.tm_min;
    (*p_sox_rtc).tm_sec = sdk_rtc.tm_sec;
}

/**
 * @brief                获取系统tick
 * @param[in]             void
 * @return               uint32_t
 * @note                无
 */
static uint32_t sox_tick_get_deal(void)
{
    uint32_t retval = 0;
    retval = sdk_tick_get();
    return retval;
}

/**
 * @brief                获取SOX限制参数
 * @param[in]             limit_params_t *，限制参数指针
 * @return               无
 * @note                无
 */
static void sox_limit_params_get_deal(limit_params_t *limit_params)
{
    if (NULL == limit_params)
    {
        return;
    }
    limit_params_t bms_limit_params = {CELL_VOLT_NUM, CELL_VOLT_NUM, DEFAULTED_RATED_CAP, PACK_FULL_CHG_VOL / 1000, CHG_STOP_CUR};
    const bms_attr_t *p_bms_attr = get_bms_attr();
    if (NULL != p_bms_attr)
    {
        bms_limit_params.chg_stop_cur = p_bms_attr->chg_stop_cur / 1000; // mA转换为A
        bms_limit_params.chg_stop_vol = p_bms_attr->chg_stop_vol / 1000; // mV转换为V
        bms_limit_params.cell_num = p_bms_attr->mono_vol_num;
        bms_limit_params.cell_temp_num = p_bms_attr->mono_vol_num;
        bms_limit_params.rated_cap = p_bms_attr->rate_cap / 10;          // 0.1Ah转换为Ah
    }
    *limit_params = bms_limit_params;
}

/**
 * @brief                SOX获取故障状态
 * @param[in]             sox_fault_e
 * @return               int32_t
 * @note                 无
 */
static int32_t sox_fault_get_deal(sox_fault_e sox_fault)
{
    int32_t retval = 0;

    if (SOX_CELL_VOLT_HIGH_ALARM == sox_fault)
    {
        retval = fault_state_get(BAT_CELL_VOLT_HIGH_ALARM);
    }
    else if ((SOX_TOTAL_VOLT_LOW_ALARM == sox_fault) ||
        (SOX_CELL_VOLT_LOW_ALARM == sox_fault))
    {
        retval = fault_state_get(BAT_TOTAL_VOLT_LOW_ALARM)
            | fault_state_get(BAT_CELL_VOLT_LOW_ALARM);
    }
    else if ((SOX_TOTAL_VOLT_LOW_PROTECT == sox_fault) ||
        (SOX_CELL_VOLT_LOW_PROTECT == sox_fault))
    {
        retval = fault_state_get(BAT_TOTAL_VOLT_LOW_PROTECT)
            | fault_state_get(BAT_CELL_VOLT_LOW_PROTECT);
    }
    else if (THERE_IS_FAULT == sox_fault)
    {
        const fault_stat_data_t *p_fault_stat_data = fault_chg_dsg_level_get();
        if (NULL != p_fault_stat_data)
        {
            retval = (LEVEL0 == p_fault_stat_data->max_charge_level || LEVEL0 == p_fault_stat_data->max_discharge_level);
        }
    }
    else if (SOX_BAT_DSG_EMPTY == sox_fault)
    {
        retval = public_flag_state_get(DISCHG_EMPTY_FLAG);
    }
	else if (SOX_CAN_RECV_EMPTY == sox_fault)
	{
		retval = public_flag_state_get(RECV_DISCHG_EMPTY_FLAG);
	}
    else if (SOX_BAT_CHG_FULL == sox_fault)
    {
        retval = bmu_is_full_chg_check();
    }
    return retval;
}

/**
 * @brief                SOX获取电池包状态
 * @param[in]             void
 * @return               返回结果 sox_bat_status_e
 * @note                 返回电池包的充放电待机状态
 */
static sox_bat_status_e sox_bat_status_get_deal(void)
{
    sox_bat_status_e sox_bat_status = SOX_BAT_STANDBY;
    battery_state_e bat_state = bms_state_get_bat_sta();

    switch ((uint16_t) bat_state)
    {
        case BMS_STANDY_MODE:
            sox_bat_status = SOX_BAT_STANDBY;
            break;
        case BMS_CHARGE_MODE:
            sox_bat_status = SOX_BAT_CHARGE;
            break;
        case BMS_DISCHARGE_MODE:
            sox_bat_status = SOX_BAT_DISCHARGE;
            break;
        default:
            break;
    }

	#ifdef SOX_DEBUG
		return g_sox_debug_bat_status;
	#endif

    return sox_bat_status;
}

/**
 * @brief                SOX获取电池包系统状态
 * @param[in]             void
 * @return               返回结果 sox_bat_status_e
 * @note                 返回电池包系统状态
 */
static sox_bms_status_e sox_sys_status_get_deal(void)
{
    sox_bms_status_e sox_sys_status = SOX_BMS_RUN;
    bms_system_state_e bat_sys_state = bms_state_get_sys_sta();

    switch ((uint16_t) bat_sys_state)
    {
        case BMS_STATE_SELF_CHECK:
            sox_sys_status = SOX_BMS_SELF_CHECK;
            break;
        case BMS_STATE_RUN:
            sox_sys_status = SOX_BMS_RUN;
            break;
        case BMS_STATE_PF_ERROR:
            sox_sys_status = SOX_BMS_PF_ERROR;
            break;
        case BMS_STATE_UPGRADE:
            sox_sys_status = SOX_BMS_UPGRADE;
            break;
        case BMS_STATE_SHUT_DOWN:
            sox_sys_status = SOX_BMS_SHUT_DOWN;
            break;
        default:
            break;
    }
    return sox_sys_status;
}

/**
 * @brief                SOX获取外部放电校准数据
 * @param[in]             dsg_cali_data_t *
 * @return               void
 * @note                 无
 */
static void sox_dsg_cali_data_get_deal(dsg_cali_data_t *dsg_cali_data)
{
    if (NULL == dsg_cali_data)
    {
        return;
    }
    dsg_cali_data_t bms_dsg_cali_data = {0};

    bms_dsg_cali_data.can_soc_min_to_volt = g_rx_dsg_cali_data.can_soc_min_to_volt;
    bms_dsg_cali_data.can_calc_val = g_rx_dsg_cali_data.can_calc_val;
	bms_dsg_cali_data.can_min_cell_volt = g_rx_dsg_cali_data.can_min_cell_volt;
    *dsg_cali_data = bms_dsg_cali_data;
}

/**
 * @brief		保存SOE的比例系数
 * @param[in]	soe_prop
 * @return		无
 * @note
*/
void soe_save_deal(float soe_prop)
{
    ;
}

/**
 * @brief		SOH获取SOC模块的PACK的SOC计算值
 * @param[in]	无
 * @return		获取指定的SOC计算值
 * @note
*/
int32_t pack_soc_calc_val_get_deal(void)
{
    int32_t retval = 0;

    retval = soc_calc_val_get(PACK_IS_SELED);

    return retval;
}

/**
 * @brief                SOX初始化
 * @param[in]	         无
 * @return		         无
 * @note                用于初始化SOX模块
 */
void sox_init(void)
{
    log_d("sox_init ok\r\n");

    sox_sample_deal_init_ex();

    sox_interface_remap_t sox_interface_remap = {0};

    sox_interface_remap.sox_running_data_get = sox_running_data_get_deal;
	sox_interface_remap.sox_running_data_addr_get = sox_running_data_addr_get;
    sox_interface_remap.sox_rtc_get = sox_rtc_get_deal;
    sox_interface_remap.sox_tick_get = sox_tick_get_deal;
    sox_interface_remap.sox_limit_params_get = sox_limit_params_get_deal;
    sox_interface_remap.sox_get_fault = sox_fault_get_deal;
    sox_interface_remap.sox_bat_status_get = sox_bat_status_get_deal;
    sox_interface_remap.sox_bms_status_get = sox_sys_status_get_deal;
    sox_interface_remap.sox_dsg_cali_data_get = sox_dsg_cali_data_get_deal;
	sox_interface_remap.soe_save = soe_save_deal;
	sox_interface_remap.calc_soc_get = pack_soc_calc_val_get_deal;

    soc_proc_init(sox_interface_remap);
	soh_proc_init(sox_interface_remap);
    soe_proc_init(sox_interface_remap);
    sox_stats_proc_init(sox_interface_remap);

    // 数据初始化
    g_sox_run_timer_b10ms = SOX_RUN_SAVE_TIMER / 2;        // 第一次提前15min
    g_sox_init_finish_flag = true;                         // sox初始化完成
    g_wait_bcu_set_date_over_cnt = SOX_SET_DATE_TIME_OVER; // 等待bcu同步时间超时
}


#define AFE_CAL_WAIT_TIME   200
/**
 * @brief    SOX计算处理函数
 * @param[in] void
 * @return   无
 * @note     必须sox_init()之后调用，10ms周期调用次函数
 */
void sox_proc(void)
{
    if (special_mode_get(ATUO_TEST))
    {
        return;
    }

#ifdef SOX_SHELL_DEBUG_TEST
    if (g_sox_shell_debug_flag)
    {
        return;
    }
#endif


#ifdef SOX_STATS_DEBUG
    // 判断bcu是否同步时间
    if (g_wait_bcu_set_date_over_cnt > 0)
    {
        g_wait_bcu_set_date_over_cnt--;
        sdk_rtc_t sdk_rtc = {0};
        sdk_rtc_get(RTC_BIN_FORMAT, &sdk_rtc);
        return;
    }
#endif
    
    static uint8_t afe_cal_10ms_cnt = 0;
    // afe初始化完成后，延时2s让其采集数据再进入sox计算
    if (afe_state_get() < AFE_RUN_STATE)
    {
        return;
    }
    else if (afe_cal_10ms_cnt < AFE_CAL_WAIT_TIME)
    {
        afe_cal_10ms_cnt++;
        return;
    }
    else
    {
        ;
    }

    static int32_t counter_sox_samp = 0;
    static int32_t counter_sox_stats = 0;
    int32_t sam_ok = 1;
    sox_scroll_record_data_t* cell_volt_5s = NULL;

    if (--counter_sox_samp <= 0)
    {
        counter_sox_samp = 10;
        sam_ok = sox_sample_data_proc();
    }
    if (sam_ok)
    {
        soc_proc();
        soh_proc();
        soe_proc();
        if (counter_sox_stats++ >= 99)
        {
            sox_stats_proc();
//            inner_can_send_msg_ready(MAS_OTHER_DATA_INFO);
            counter_sox_stats = 0;
        }
    }

	cell_volt_5s = sox_scroll_record_data_5s_data_get();
    cell_volt_5s_get(cell_volt_5s);
    (void)sox_data_get(&g_sox_data);

    //检测是否要存储
    sox_running_data_cycle_save_deal();

    // 状态变化/故障异常打印
    sox_status_or_err_print();
}

/*************************************************************************************************/
/****************************************** sox_sample接口函数填充**********************************/
/************************************************************************************************/

/**
 * @brief               电池采样数据获取
 * @param[in]	         sox_sample_data_t *
 * @return		         true:读取成功, false:读取失败
 * @note
 */
static bool sox_sample_data_get_cb(sox_sample_data_t *p_sox_sample_data)
{
    int32_t cell_index = 0;
    int8_t  skipped = 0;       // 跳过的索引计数
    int32_t target_index = 0;  // 目标索引

    const bmu_data_t* p_bmu_data = bmu_data_p_get();
    if (NULL == p_bmu_data)
    {
        return false;
    }

    #ifdef SOX_DEBUG
        p_sox_sample_data->sys_cur       = g_sox_debug_sys_cur;
        p_sox_sample_data->pack_volt     = g_sox_debug_pack_volt;
        p_sox_sample_data->min_cell_volt = g_sox_debug_min_volt;
        p_sox_sample_data->min_cell_temp = g_sox_debug_min_temp;
        p_sox_sample_data->max_cell_volt = g_sox_debug_max_volt;
        p_sox_sample_data->avg_cell_volt = g_sox_debug_avg_volt;
        p_sox_sample_data->avg_cell_temp = g_sox_debug_avg_temp;

        for (cell_index = 0; cell_index < CELL_VOLT_NUM; cell_index++)
        {
            p_sox_sample_data->cell_volt[cell_index] = g_sox_debug_cell_volt;
        }

        for (cell_index = 0; cell_index < CELL_TEMP_NUM; cell_index++)
        {
            // 取AFE的温度索引：0-5，7-12，14-19，21-26
            if (6 ==cell_index || 13 ==cell_index || 20 == cell_index || 27 == cell_index)
            {
                skipped++;
                continue;
            }

            target_index = cell_index - skipped;    // 计算目标索引：cell_index - 已跳过的索引数量

            p_sox_sample_data->cell_temp[target_index] = g_sox_debug_cell_temp;
        }
    #else
        p_sox_sample_data->sys_cur       = p_bmu_data->sys_current;
        p_sox_sample_data->pack_volt     = p_bmu_data->bat_acc_volt;
        p_sox_sample_data->min_cell_volt = p_bmu_data->min_cell_volt;
        p_sox_sample_data->min_cell_temp = (I16_INVALID_VALUE == p_bmu_data->min_cell_temp) ?  I8_INVALID_VALUE : p_bmu_data->min_cell_temp / TEN_TIMES;// 把0.1℃单位转换成1℃
        p_sox_sample_data->max_cell_volt = p_bmu_data->max_cell_volt;
        p_sox_sample_data->avg_cell_volt = p_bmu_data->avg_cell_volt;
        p_sox_sample_data->avg_cell_temp = (I16_INVALID_VALUE == p_bmu_data->avg_cell_temp) ?  I8_INVALID_VALUE : p_bmu_data->avg_cell_temp / TEN_TIMES;// 把0.1℃单位转换成1℃

        for (cell_index = 0; cell_index < CELL_VOLT_NUM; cell_index++)
        {
            if (U16_INVALID_VALUE == p_bmu_data->cell_volt[cell_index])
            {
                return false;
            }
            p_sox_sample_data->cell_volt[cell_index] = p_bmu_data->cell_volt[cell_index];
        }

        for (cell_index = 0; cell_index < CELL_TEMP_NUM; cell_index++)
        {
            // 取AFE的温度索引：0-5，7-12，14-19，21-26
            if (6 ==cell_index || 13 ==cell_index || 20 == cell_index || 27 == cell_index)
            {
                skipped++;
                continue;
            }

            target_index = cell_index - skipped;    // 计算目标索引：cell_index - 已跳过的索引数量

            p_sox_sample_data->cell_temp[target_index] = p_bmu_data->cell_temp[cell_index] / TEN_TIMES;
        }
    #endif

    return true;

}

/**
 * @brief               电池采样数据初始化
 * @param[in]	         void
 * @return		         true:初始化成功, false:初始化失败
 * @note
 */
uint8_t sox_sample_deal_init_ex(void)
{
    sox_sample_deal_remap_t sox_sample_deal_remap = {
        .sox_sample_data_get_cb = sox_sample_data_get_cb,   ///< 电池数据获取
    };

    uint8_t ret = sox_sample_deal_init(&sox_sample_deal_remap);
    return ret;
}


/*************************************************************************************************/
/****************************************** sop 外部接口 *****************************************/
/************************************************************************************************/

/**
 * @brief                获取电池包充放电状态
 * @param[in]            void
 * @return               电池状态 (0 待机 1 充电  2 放电)
 * @note
 */
static uint32_t sop_bat_state_get(void)
{
    uint32_t sop_bat_state = 0; // 默认待机
    battery_state_e bat_state = bms_state_get_bat_sta();

    switch ((uint16_t) bat_state)
    {
        case BMS_STANDY_MODE:
            sop_bat_state = 0;
            break;
        case BMS_CHARGE_MODE:
            sop_bat_state = 1;
            break;
        case BMS_DISCHARGE_MODE:
            sop_bat_state = 2;
            break;
        default:
            break;
    }

	#ifdef SOX_DEBUG
		return g_sox_debug_bat_status;
	#endif

    return sop_bat_state;
}

/**
 * @brief                获取电池包充饱放亏标志
 * @param                [in]void
 * @return               电池状态 (0 不充满不放空 1 充满  2 放空)
 * @note
 */
static uint32_t sop_public_state_get(void)
{
    uint32_t sop_public_state = 0;
//    battery_state_e bat_state = bms_state_get_bat_sta();

    if ((true == public_flag_state_get(CHG_FULL_FLAG)) ||
        (public_flag_state_get(RECV_CHG_FULL_FLAG)))
    {
        sop_public_state = 1; // 充满
    }
    else if ((true == public_flag_state_get(DISCHG_EMPTY_FLAG)) ||
             (public_flag_state_get(RECV_DISCHG_EMPTY_FLAG)))
    {
        sop_public_state = 2; // 放空
    }
    return sop_public_state;
}

/**
 * @brief                填充SOP输入参数
 * @param[in]            sop_bat_data_t *
 * @return               true ：成功；false ：失败
 * @note
 */
static bool sop_input_data_fill(sop_bat_data_t *p_sop_bat_data)
{
    if (NULL == p_sop_bat_data)
    {
        return false;
    }
    const bmu_data_t* p_bmu_data = bmu_data_p_get();
    const fault_stat_data_t* p_fault_data = fault_chg_dsg_level_get();
    const sox_data_t *p_sox_data = sox_data_get_deal();
    if (NULL == p_fault_data)
    {
        return false;
    }
    if(NULL == p_bmu_data)
    {
        return false;
    }
    if (NULL == p_sox_data)
    {
        return false;
    }

	#ifdef SOX_DEBUG
		// 获取电池SOC
		p_sop_bat_data->sys_soc = g_sox_debug_soc;  // 转换成单位0.1%，(sox_data.calc_soc单位为0.001%)
		// 获取电池状态
		p_sop_bat_data->bat_state = g_sox_debug_bat_status;
		// 获取电池数据
		p_sop_bat_data->max_cell_temp = g_sox_debug_max_temp;
		p_sop_bat_data->min_cell_temp = g_sox_debug_min_temp;
		p_sop_bat_data->max_cell_vol  = g_sox_debug_max_volt;
		p_sop_bat_data->min_cell_vol  = g_sox_debug_min_volt;
		p_sop_bat_data->sys_curr      = g_sox_debug_sys_cur;
		// 获取充放电等级
		p_sop_bat_data->max_chg_level = g_sox_debug_chg_level;
		p_sop_bat_data->max_dischg_level = g_sox_debug_dsg_level;
	#else
		// 获取电池SOC
		p_sop_bat_data->sys_soc = p_sox_data->calc_soc / 100;  // 转换成单位0.1%，(sox_data.calc_soc单位为0.001%)
		// 获取电池状态
		p_sop_bat_data->bat_state =  sop_bat_state_get();
		// 获取电池数据
		p_sop_bat_data->max_cell_temp = p_bmu_data->max_cell_temp;
		p_sop_bat_data->min_cell_temp = p_bmu_data->min_cell_temp;
		p_sop_bat_data->max_cell_vol  = p_bmu_data->max_cell_volt;
		p_sop_bat_data->min_cell_vol  = p_bmu_data->min_cell_volt;
		p_sop_bat_data->sys_curr      = p_bmu_data->sys_current;
		// 获取充放电等级
		p_sop_bat_data->max_chg_level = p_fault_data->max_charge_level;
		p_sop_bat_data->max_dischg_level = p_fault_data->max_discharge_level;
	#endif


    //数据做有效范围判断
    /*  系统计算SOC值(分辨率0.1%) [0, 1000]
        电池充放电状态(0：待机， 1：充电 2： 放电) [0, 2]
        最大电芯温度(分辨率：0.1℃) [-400, 650]
        最低电芯温度(分辨率：0.1℃) [-400, 650]
        最大电芯电压(1mV)          [2000, 4000]
        最小电芯电压(1mV)          [2000, 4000]
        系统电流(1mA)              [-150000, 150000]
        最大充电等级               [0, 3]
        最大放电等级               [0, 3]
    */
    if ((p_sop_bat_data->sys_soc > SOP_CALC_SOC_UPLIMIT) ||
        (p_sop_bat_data->bat_state > SOP_CHG_DSG_STATUS_UPLIMT) ||
        (p_sop_bat_data->max_cell_temp > SOP_CELL_TEMP_UPLIMIT) ||
        (p_sop_bat_data->max_cell_temp < SOP_CELL_TEMP_DOWNLIMIT)||
        (p_sop_bat_data->min_cell_temp > SOP_CELL_TEMP_UPLIMIT) ||
        (p_sop_bat_data->min_cell_temp < SOP_CELL_TEMP_DOWNLIMIT) ||
        (p_sop_bat_data->max_cell_vol > SOP_CELL_VOL_UPLIMIT) ||
        (p_sop_bat_data->max_cell_vol < SOP_CELL_VOL_DOWNLIMIT) ||
        (p_sop_bat_data->min_cell_vol > SOP_CELL_VOL_UPLIMIT) ||
        (p_sop_bat_data->min_cell_vol < SOP_CELL_VOL_DOWNLIMIT) ||
        (p_sop_bat_data->sys_curr > SOP_SYS_CURR_UPLIMIT) ||
        (p_sop_bat_data->sys_curr < SOP_SYS_CURR_DOWNLIMIT) ||
        (p_sop_bat_data->max_chg_level > SOP_CHG_DSG_LEVEL_UPLIMIT) ||
        (p_sop_bat_data->max_dischg_level > SOP_CHG_DSG_LEVEL_UPLIMIT))
    {
           return false;
    }
    return true;
}

/**
 * @brief                获取SOP输入参数
 * @param                [in]p_sop_bat_data指针
 * @return               true ：成功；false ：失败
 * @note
 */
static bool sop_bat_data_get(sop_bat_data_t *p_sop_bat_data)
{
    if (NULL == p_sop_bat_data)
    {
        return false;
    }
    bool ret = sop_input_data_fill(p_sop_bat_data);
    return ret;
}

/**
 * @brief                sop获取系统tick
 * @param[in]            void
 * @return               系统tick
 * @note
 */
static uint32_t sop_tick_get(void)
{
    return sdk_tick_get();
}

/**
 * @brief                tick间隔满足要求
 * @param[in]            time_start 开始时间
 * @param[in]            time_length 间隔时间
 * @return               true, 间隔满足要求；false, 间隔不满足要求
 * @note
 */
static bool sop_tick_over(uint32_t time_start, uint32_t time_length)
{
    return sdk_is_tick_over(time_start, time_length);
}

/**
 * @brief                SOP初始化函数
 * @param[in]            void
 * @return               uint8_t, 0:初始化成功；其他:初始化失败
 * @note
 */
uint8_t sop_init_deal(void)
{
#ifdef SOP_SELF_CHECK_DEBUG_TEST
    if (g_sop_self_check_debug_flag)
    {
        sop_self_check_test();
        return;
    }
#endif
    sop_interface_remap_t sop_init_remap = {0};
    sop_init_remap.sop_bat_data_get_cb = sop_bat_data_get;
    sop_init_remap.sop_bat_state_get_cb = sop_public_state_get;
    sop_init_remap.sop_is_tick_over_cb = sop_tick_over;
    sop_init_remap.sop_tick_get_cb = sop_tick_get;

    uint8_t ret = sop_init(&sop_init_remap);
    return ret;
}

/*************************************************************************************************/
/************************************** passive_balance 外部接口 *********************************/
/************************************************************************************************/

/**
* @brief                获取BMU均衡数据准备状态
* @param                void
* @return                返回BMU均衡数据准备状态
* @retval                bool
* @warning      给BCU
*/
bool cell_balance_status_get(void)
{
    return bmu_data_status_get();
}

/**
* @brief                获取BMU的最小电芯SOC
* @param                void
* @return                返回BMU的最小电芯SOC
* @retval                bool
* @warning      给BCU
*/
uint16_t cell_balance_min_cell_soc_get(void)
{
    return bmu_min_cell_soc_get();
}

/**
* @brief        cell balance逻辑禁止/使能控制
* @param        [in] disable_flag     true:屏蔽cell balance逻辑/false:cell balance逻辑正常
* @return       void
* @note       一般只有ate测试才会调用，其他模块慎用
*/
void cell_balance_display_func_disable(bool disable_flag)
{
    if (true != disable_flag && false != disable_flag)
    {
        return;
    }
    g_disable_cell_balance_flag = disable_flag;
}

/**
* @brief        cell balance逻辑屏蔽标志获取
* @param        void
* @return        true: 屏蔽cell balance逻辑，false:正常使用cell balance逻辑
* @note
*/
bool cell_balance_disable_flag_get(void)
{
    return g_disable_cell_balance_flag;
}

/**
 * @brief       电芯均衡位置设置到AFE
 */

/**
* @brief        电芯均衡位置设置到AFE
* @param[in]    balance_pos     电芯均衡位置
* @return       void
* @note
*/
static void balance_pos_set_interface(uint16_t balance_pos[])
{
    #ifdef CELL_BALANCE_SHELL_DEBUG_TEST
        if (g_cell_balance_shell_debug_flag)
        {
            return;
        }
    #endif
    if (g_disable_cell_balance_flag)
    {
        return;
    }
    for (int8_t i = 0; i < AFE_NUM; i++)
    {
        afe_balance_set(i,(uint32_t)balance_pos[i]);
    }
}

/**
* @brief        屏蔽电芯均衡标志获取
* @param        void
* @return        true: 屏蔽电芯均衡，false:正常使用电芯均衡
* @note
*/
static bool cell_bal_forbid_flag_get_if(void)
{
    bool   ret = false; //默认false
    //填充禁止电芯均衡的条件 并将返回标志置位true
    if (true == g_disable_cell_balance_flag)
    {
        ret = true;
    }
    return ret;
}

/**
* @brief        bmu数据状态
* @param        void
* @return        bmu数据状态
* @note
*/
static bool bmus_data_status_get_if(void)
{
    bool status = false;

    status = bmu_active_bal_data_get(CAN_BMU_BAL_STATUS);

    return status;
}

/**
* @brief        bcu最小电芯SOC获取
* @param        void
* @return        bcu最小电芯SOC
* @note
*/
static uint16_t bcu_min_cell_soc_get_if(void)
{
    uint16_t min_cell_soc = 0;

    min_cell_soc = bmu_active_bal_data_get(CAN_BAL_MIN_CELL_SOC);

    return min_cell_soc;
}

/**
 * @brief                获取电池包参数属性
 * @param                [in]bms_attr_type_t
* @return                [out]RUNNING_FAIL:获取失败(0)  RUNNING_OK： 获取成功(1)
* @note
 */
static bool cell_balance_bms_attr_get(bms_attr_type_t *p_bms_attr_type)
{
    if (NULL == p_bms_attr_type)
    {
        return RUNNING_FAIL;
    }
    const bms_attr_t *bms_attr = get_bms_attr();

    if (NULL == bms_attr)
    {
        return RUNNING_FAIL;
    }
    else
    {
        if ((bms_attr->rate_cap == 0) ||
            (bms_attr->cell_num == 0) ||
            (bms_attr->mono_tem_num == 0) ||
            (bms_attr->mono_vol_num == 0) ||
            (bms_attr->bal_vol_diff == 0))
        {
            p_bms_attr_type->rate_cap =  DEFAULTED_RATED_CAP*10;    // 额定容量 分辨率0.1Ah
            p_bms_attr_type->cell_num =  CELL_VOLT_NUM;      // 电芯数量 
            p_bms_attr_type->cell_temp_num = CELL_VOLT_NUM;  //电芯温度数量(主要是给sox使用，sox代码里温度是按1:1)
            p_bms_attr_type->cell_vol_num = CELL_VOLT_NUM;   //电芯电压数量  
            p_bms_attr_type->balance_vol_diff = BAL_VOLT_DIFF; // 均衡开启压差 默认策略要求是20mV
            p_bms_attr_type->cell_bal_curr = BAL_CURR;   // 电芯均衡电流 默认150mA   因为其实均衡电流不是固定的，是阻值固定为10+10+2.4+线损Ω ，这里写大了后，均衡时间就会算少，最终就不会导致电压震荡；
//            p_bms_attr_type->over_chg_curr_alarm = 230000; //过充电流告警值 默认230A
//            p_bms_attr_type->over_dsg_curr_alarm = 230000; //过放电流告警值 默认230A
        }
        else
        {
            p_bms_attr_type->rate_cap = bms_attr->rate_cap; // 额定容量
            p_bms_attr_type->cell_num = bms_attr->cell_num; // 电芯数量
            p_bms_attr_type->cell_temp_num = bms_attr->mono_vol_num; //电芯温度数量(主要是给sox使用，sox代码里温度是按1:1)
            p_bms_attr_type->cell_vol_num = bms_attr->mono_vol_num;//电芯电压数量
            p_bms_attr_type->balance_vol_diff = bms_attr->bal_vol_diff; // 均衡开启压差
            p_bms_attr_type->cell_bal_curr =  bms_attr->bal_cur;  //电芯均衡电流
//            p_bms_attr_type->over_chg_curr_alarm = bms_attr->safety.chg_over_cur_alarm.appear_value; //过充电流告警值  单位mA
//            p_bms_attr_type->over_dsg_curr_alarm = bms_attr->safety.dchg_over_cur_alarm.appear_value; //过放电流告警值  单位mA

        }
        return RUNNING_OK;
    }

}

/**
 * @brief                填充电池包数据
 * @param                [in]balance_bat_data_t*
 * @return               true ：成功；false ：失败
 * @note
 */
static bool cell_balance_bat_data_fill(balance_bat_data_t *p_balance_bat_data)
{
    if (NULL == p_balance_bat_data)
    {
        return false;
    }
    const bmu_data_t* p_bmu_data = bmu_data_p_get();
    bms_attr_type_t bms_attr_type = {0};
    bool attr_get_flag = false;
    uint8_t i = 0;
    uint16_t min_cell_volt = 0;
    attr_get_flag = cell_balance_bms_attr_get(&bms_attr_type); //参数属性
    const fault_stat_data_t* p_fault_data = fault_chg_dsg_level_get(); //故障充放电等级
    const sox_data_t *p_sox_data = sox_data_get_deal();     //SOX数据

    #ifdef CELL_DEBUG
        // 获取电池数据
        p_balance_bat_data->bat_soh = gp_debug_sox_data.calc_soh / 100; // SOH转换成单位0.1%，(sox_data.calc_soc单位为0.001%)
        p_balance_bat_data->cell_avg_temp = gp_debug_bmu_data.avg_cell_temp; //电芯平均温度0.1℃

        for( i = 0; i < bms_attr_type.cell_vol_num; i++)           //电芯电压mV
        {
            p_balance_bat_data->cell_vol[i] = gp_debug_bmu_data.cell_volt[i];
        }

        for(i = 0; i < bms_attr_type.cell_temp_num; i++)           //电芯温度0.1℃
        {
            p_balance_bat_data->cell_temp[i] = gp_debug_bmu_data.cell_temp[i / 2];  // 8路ntc映射16电芯温度
        }
        p_balance_bat_data->min_cell_vol   = gp_debug_bmu_data.min_cell_volt;     //最低电芯电压mV
        p_balance_bat_data->max_chg_level  = gp_debug_fault_data.max_charge_level;   //最大充电等级
        p_balance_bat_data->max_dischg_level = gp_debug_fault_data.max_discharge_level; //最大放电等级
        p_balance_bat_data->sys_curr  = gp_debug_bmu_data.sys_current;                     //系统电流mA

    #else
		if ((NULL == p_fault_data) ||
			(false == attr_get_flag)||
			(NULL == p_bmu_data)||
			(NULL == p_sox_data))
		{
			return false;
		}

		// 获取电池数据
        p_balance_bat_data->bat_soh = p_sox_data->calc_soh / 100; // SOH转换成单位0.1%，(sox_data.calc_soc单位为0.001%)
        p_balance_bat_data->cell_avg_temp = p_bmu_data->avg_cell_temp; //电芯平均温度0.1℃

        for( i = 0; i < bms_attr_type.cell_vol_num; i++)           //电芯电压mV
        {
            p_balance_bat_data->cell_vol[i] = p_bmu_data->cell_volt[i];
        }

        for(i = 0; i < bms_attr_type.cell_temp_num; i++)           //电芯温度0.1℃
        {
            p_balance_bat_data->cell_temp[i] = p_bmu_data->cell_temp[i / 2];  // 24路ntc映射48电芯温度
        }
        
        min_cell_volt = p_bmu_data->min_cell_volt;
        if((g_rx_volt_diff_pas_bal_data.clu_min_cell_volt != 0) &&
            (g_rx_volt_diff_pas_bal_data.clu_min_cell_volt < min_cell_volt)
            )
        {
            min_cell_volt = g_rx_volt_diff_pas_bal_data.clu_min_cell_volt;
        }

        p_balance_bat_data->min_cell_vol   = min_cell_volt;     //最低电芯电压mV
        p_balance_bat_data->max_chg_level  = p_fault_data->max_charge_level;   //最大充电等级
        p_balance_bat_data->max_dischg_level = p_fault_data->max_discharge_level; //最大放电等级
        p_balance_bat_data->sys_curr  = p_bmu_data->sys_current;                     //系统电流mA
    #endif


    //数据做有效范围判断
    /* 1. 电池包SOH(分辨率0.1%)             [0, 1000]
       2. 电芯平均温度(分辨率0.1%)          [-400,650]
       3. 电芯电压mV                        [2400, 4000]
       4. 电芯温度(分辨率0.1%)              [-400, 650]
       5. 最低电芯电压mV                    [2400, 4000]
       6. 最大充电等级                      [0, 3]
       7. 最大放电等级                      [0, 3]
       8. 系统电流mA                        [-420000, 420000]
    */

    if ((p_balance_bat_data->bat_soh < CELL_BAL_CALC_SOH_DOWNLIMIT) ||
        (p_balance_bat_data->bat_soh > CELL_BAL_CALC_SOH_UPLIMIT) ||
        (p_balance_bat_data->cell_avg_temp < CELL_BAL_CELL_AVG_TEMP_DOWNLIMIT) ||
        (p_balance_bat_data->cell_avg_temp > CELL_BAL_CELL_AVG_TEMP_UPLIMIT) ||
        (p_balance_bat_data->min_cell_vol < CELL_BAL_MIN_CELL_VOL_DOWNLIMIT) ||
        (p_balance_bat_data->min_cell_vol > CELL_BAL_MIN_CELL_VOL_UPLIMIT) ||
        (p_balance_bat_data->max_chg_level > CELL_BAL_MAX_CHG_DSG_LEVEL_UPLIMT) ||
        (p_balance_bat_data->max_dischg_level > CELL_BAL_MAX_CHG_DSG_LEVEL_UPLIMT) ||
        (p_balance_bat_data->sys_curr < CELL_BAL_SYS_CURR_DOWNLIMIT) ||
        (p_balance_bat_data->sys_curr > CELL_BAL_SYS_CURR_UPLIMIT))
    {
        return false;
    }
    //电芯电压， 电芯温度无效值判断
    for (i = 0; i < bms_attr_type.cell_vol_num; i++)   //电芯电压无效
    {
       if ((p_balance_bat_data->cell_vol[i] > CELL_BAL_CELL_VOL_UPLIMIT) ||
            (p_balance_bat_data->cell_vol[i] < CELL_BAL_CELL_VOL_DOWNLIMIT))

        {
           return false;
        }
    }
    for (i = 0; i < bms_attr_type.cell_temp_num; i++)  // 电芯温度无效
    {
       if ((p_balance_bat_data->cell_temp[i] > CELL_BAL_CELL_TEMP_UPLIMIT)||
           (p_balance_bat_data->cell_temp[i] < CELL_BAL_CELL_TEMP_DOWNLIMIT))

        {
            return false;
        }
    }
    return true;
}

/**
 * @brief                获取电池包数据
 * @param                [in]balance_bat_data_t*
 * @return               true ：成功；false ：失败
 * @note
 */
static bool balance_bat_data_get_deal(balance_bat_data_t *p_balance_bat_data)
{
    if (NULL == p_balance_bat_data)
    {
        return false;
    }
    bool ret = cell_balance_bat_data_fill(p_balance_bat_data);
    return ret;
}

/**
 * @brief                获取系统tick
 * @param                void
 * @return               系统tick
 * @note
 */
static uint32_t balance_tick_get_interface(void)
{
    return sdk_tick_get();
}

/**
 * @brief                满充状态检测
 * @param                void
 * @return               返回满充标志
 * @note
 */
static bool  balance_public_full_flag_get_if(void)
{

    bool ret = false;

    if ((public_flag_state_get(CHG_FULL_FLAG)) ||           //满充标志置位
        (public_flag_state_get(RECV_CHG_FULL_FLAG)))        //满充事件置位
    {
        ret  = true;
    }

    #ifdef CELL_DEBUG
        return g_debug_full_chg_flag;
    #endif

    return ret;
}

/**
 * @brief                放空状态检测
 * @param                void
 * @return               返回放空标志
 * @note
 */
static bool  balance_public_empty_flag_get_if(void)
{

    bool ret = false;

    if ((public_flag_state_get(DISCHG_EMPTY_FLAG)))
    {
        ret  = true;
    }

    return ret;
}



/**
 * @brief                电芯均衡逻辑初始化
 * @param                [in]void
 * return               void
 * @note              用于初始化电芯间均衡模块
 */
void cell_balance_init(void)
{
#if CELL_BALANCE_SELF_CHECK_TEST
    if (g_cell_balance_self_check_flag)
    {
        cell_balance_self_check_test();
        return;
    }
#endif
     passive_balance_interface_remap_t passive_bal_if_remap = {0};
     balance_public_interface_remap_t  bal_public_if_remap = {0};

    bal_public_if_remap.balance_bms_attr_get_cb = cell_balance_bms_attr_get;
    bal_public_if_remap.balance_bat_data_get_cb = balance_bat_data_get_deal;
    bal_public_if_remap.balance_tick_get_cb =  balance_tick_get_interface;
    bal_public_if_remap.balance_full_chg_flag_get_cb = balance_public_full_flag_get_if;
    bal_public_if_remap.balance_empty_dsg_flag_get_cb = balance_public_empty_flag_get_if;

    passive_bal_if_remap.passive_balance_pos_set_cb = balance_pos_set_interface;
    passive_bal_if_remap.passive_bal_forbid_flag_get_cb = cell_bal_forbid_flag_get_if;
    passive_bal_if_remap.passive_bal_bmus_data_status_get_cb = bmus_data_status_get_if;
    passive_bal_if_remap.passive_bal_min_check_soc_get_cb = bcu_min_cell_soc_get_if;

    passive_balance_init(&passive_bal_if_remap,&bal_public_if_remap); //被动均衡初始化
}



/*************************************************************************************************/
/******************************************** SOX 调试打印 ***************************************/
/************************************************************************************************/
/**
 * @brief                电池簇SOX结果打印
 * @param                [in]void
 */
void sox_printf(void)
{
    sox_data_t sox_data = {0};

    int32_t ret = sox_data_get(&sox_data);
    if (0 == ret)
    {
        log_d("soxPrintfErr=%d\n", ret);
    }
    log_d("calcSoc=%d(0.001%)\n", g_sox_data.calc_soc);
    log_d("calcSoh=%d(0.001%)\n", g_sox_data.calc_soh);
    log_d("dispSoc=%d(1%)\n", g_sox_data.display_soc);
    log_d("dispSoh=%d(1%)\n", g_sox_data.display_soh);
    log_d("talChgAh=%d\n", g_sox_data.total_chg_ah);
    log_d("talDsgAh=%d\n", g_sox_data.total_dsg_ah);
    log_d("talChgWh=%d\n", g_sox_data.total_chg_wh);
    log_d("talDsgWh=%d\n", g_sox_data.total_dsg_wh);
    log_d("remainedCap=%d(Ah)\n", g_sox_data.remained_cap);
    log_d("waitBcuSetDateOverCnt=%d\n", g_wait_bcu_set_date_over_cnt);
    log_d("soxInitFinish=%d\n", g_sox_init_finish_flag);

    log_d("limitParamData:\n");
    limit_params_t limit_param_data = {0};
    sox_limit_params_get_deal(&limit_param_data);
    log_d("cellTempNum=%d\n", limit_param_data.cell_temp_num);
    log_d("chgStopCur=%d\n", limit_param_data.chg_stop_cur);
    log_d("chgStopVol=%d\n", limit_param_data.chg_stop_vol);
    log_d("ratedCap=%d\n", limit_param_data.rated_cap);
    log_d("cellNum=%d\n", limit_param_data.cell_num);

    const bmu_data_t* p_bmu_data = bmu_data_p_get();
    if (NULL != p_bmu_data)
    {
        log_d("bmuData:\n");
        log_d("sysCur=%d(mA)\n",  p_bmu_data->sys_current              );
        log_d("batAfeV=%d(mV)\n",  p_bmu_data->bat_afe_volt             );
        log_d("minCelV=%d(mV)\n",  p_bmu_data->min_cell_volt            );
        log_d("minCelTem=%d(1du)\n", p_bmu_data->min_cell_temp / TEN_TIMES);
        log_d("maxCelV=%d(mV)\n",  p_bmu_data->max_cell_volt            );
        log_d("avgCelV=%d(mV)\n",  p_bmu_data->avg_cell_volt            );
        log_d("avgCelTem=%d(1du)\n", p_bmu_data->avg_cell_temp / TEN_TIMES);
    }

    log_d("rtc:\n");
    sdk_rtc_t sdk_rtc = {0};
    sdk_rtc_get(RTC_BIN_FORMAT, &sdk_rtc);
    log_d("year=%d\n", sdk_rtc.tm_year   );
    log_d("mon=%d\n", sdk_rtc.tm_mon    );
    log_d("weekday=%d\n", sdk_rtc.tm_weekday);
    log_d("day=%d\n", sdk_rtc.tm_day    );
    log_d("hour=%d\n", sdk_rtc.tm_hour   );
    log_d("min=%d\n", sdk_rtc.tm_min    );
    log_d("sec=%d\n", sdk_rtc.tm_sec    );
}

/**
 * @brief                sox运行数据打印
 * @param                [in]void
 */
void sox_run_data_printf(void)
{
    sox_running_data_t* sox_run_data = NULL;
    sox_run_data = sox_running_data_addr_get();
	int8_t cell_index = 0;

    if (NULL == sox_run_data)
    {
        log_e("soxRunDataErr=%d\n");
        return;
    }

	log_d("\ncalcSoc\t");
	log_d("calcSoh\t");
	log_d("sohHighPre\t");
	log_d("cycleCount\t");
	log_d("cycleFrac\n");

	for (cell_index = 0; cell_index < CELL_VOLT_NUM; cell_index++)
	{
		log_d("%d:", cell_index);
		log_d("%d\t\t",sox_run_data->cell_calc_soc[cell_index]);
		log_d("%d\t\t",sox_run_data->cell_calc_soh[cell_index]);
		log_d("%d\t\t",sox_run_data->soh_high_pre[cell_index]);
		log_d("%d\t\t",sox_run_data->cycle_count[cell_index]);
		log_d("%d\n",sox_run_data->cycle_frac[cell_index]);
	}

	log_d("displaycycleturns=%d(0.01)\n",    sox_run_data->display_cycle_turns        );
//	log_d("remain_cap = %d(AH)\n",    sox_run_data.remain_cap        );
//	log_d("real_cap = %d(AH)\n",    sox_run_data.real_cap          );
//	log_d("delivery_time = %ld(s)\n",    sox_run_data.delivery_time     );
	log_d("talChgAh=%ld(AH)\n",    sox_run_data->total_chg_ah      );
	log_d("talDsgAh=%ld(AH)\n",    sox_run_data->total_dsg_ah      );
//	log_d("tal_chg_mA_s = %lld(mAs)\n",   sox_run_data.total_chg_mA_s    );
//	log_d("tal_dsg_mA_s = %lld(mAs)\n",   sox_run_data.total_dsg_mA_s    );
//	log_d("tal_chg_wh = %ld()\n",      sox_run_data.total_chg_wh      );
//	log_d("tal_dsg_wh = %ld()\n",      sox_run_data.total_dsg_wh      );
//	log_d("tal_chg_mW_s = %lld()\n",      sox_run_data.total_chg_mW_s    );
//	log_d("tal_dsg_mW_s = %ld()\n",      sox_run_data.total_dsg_mW_s    );
	log_d("fullChgDsgAh[0]=%ld()\n",      sox_run_data->full_chg_dsg_ah[0]   );
//	log_d("soc_run_sta = 0x%lx()\n",      sox_run_data.soc_running_status);
//	log_d("soh_run_sta = 0x%lx()\n",      sox_run_data.soh_running_status);
//	log_d("ver = %d()\n",      sox_run_data.version           );
	log_d("socStaEvt=x%lx()\n",   sox_run_data->soc_running_status.pack_events.bytes);
	log_d("socStaErr=x%lx()\n",   sox_run_data->soc_running_status.errors.bytes);
	log_d("sohStaEvt=x%lx()\n",   sox_run_data->soh_running_status.pack_events.bytes);
	log_d("sohStaErr=x%lx()\n",   sox_run_data->soh_running_status.errors.bytes);

//    log_("crc = 0x%x()\n",    sox_run_data.crc    );

//   log_d("\nchg_dsg time:\n");
//   log_d("year = %d\n", sox_run_data.chg_dsg_record.tm_year);
//   log_d("mon = %d\n",  sox_run_data.chg_dsg_record.tm_mon );
//   log_d("day = %d\n",  sox_run_data.chg_dsg_record.tm_day );
//   log_d("hour = %d\n", sox_run_data.chg_dsg_record.tm_hour);
//   log_d("min = %d\n",  sox_run_data.chg_dsg_record.tm_min );
//   log_d("sec = %d\n",  sox_run_data.chg_dsg_record.tm_sec );

//   log_d("\nocv_cali_time:\n");
//   log_d("year = %d\n", sox_run_data.ocv_cali_time[0].tm_year);
//   log_d("mon = %d\n",  sox_run_data.ocv_cali_time[0].tm_mon );
//   log_d("day = %d\n",  sox_run_data.ocv_cali_time[0].tm_day );
//   log_d("hour = %d\n", sox_run_data.ocv_cali_time[0].tm_hour);
//   log_d("min = %d\n",  sox_run_data.ocv_cali_time[0].tm_min );
//   log_d("sec = %d\n",  sox_run_data.ocv_cali_time[0].tm_sec );

//    log_d("\ndaily_save_time:\n");
//    log_d("year = %d\n", sox_run_data.daily_save_time.tm_year);
//    log_d("mon = %d\n",  sox_run_data.daily_save_time.tm_mon );
//    log_d("day = %d\n",  sox_run_data.daily_save_time.tm_day );
//    log_d("hour = %d\n", sox_run_data.daily_save_time.tm_hour);
//    log_d("min = %d\n",  sox_run_data.daily_save_time.tm_min );
//    log_d("sec = %d\n",  sox_run_data.daily_save_time.tm_sec );

    log_d("fullChgTime:%d-%d-%d %d:%d:%d\n", sox_run_data->full_chg_time[0].tm_year, sox_run_data->full_chg_time[0].tm_mon,
        sox_run_data->full_chg_time[0].tm_day, sox_run_data->full_chg_time[0].tm_hour, sox_run_data->full_chg_time[0].tm_min,
        sox_run_data->full_chg_time[0].tm_sec);
}

/**
 * @brief                电池簇SOX错误打印
 * @param                [in]void
 */
void sox_debug_err_printf(void)
{
//    log_e("sox param err\r\n");
//    log_e("sox print :printf data\r\n");
//    log_e("sox help :printf help data\r\n");
//    log_e("sox save :save sox run data\r\n");
//    log_e("sox runp :print sox run data\r\n");
//    log_e("sox reset :reset woxrun data\r\n");
//    log_e("sox val val_id(0~%d) val:set analog data\r\n", TOTAL_DSG_WH_SET);
//    log_e("sox debug debugflag(0/1) val_id(0~%d) val: set analog data\r\n", TOTAL_DSG_WH_SET);
}

/**
 * @brief                电池簇SOX打印提示
 * @param                [in]void
 */
void sox_debug_help_printf(void)
{
//    log_e("val_id:\n");
//    log_e("DISPLAY_SOC = %d\n", DISPLAY_SOC_SET );
//    log_e("DISPLAY_SOH = %d\n", DISPLAY_SOH_SET );
//    log_e("TAL_CHG_AH = %d\n", TOTAL_CHG_AH_SET);
//    log_e("TAL_DSG_AH = %d\n", TOTAL_DSG_AH_SET);
//    log_e("TAL_CHG_WH = %d\n", TOTAL_CHG_WH_SET);
//    log_e("TAL_DSG_WH = %d\n", TOTAL_DSG_WH_SET);
}

/**
 * @brief                sox运行数据清空
 * @param                [in]void
 * @warnning              触发休眠后会被覆盖
 */
void sox_running_data_reset(void)
{
    sox_running_data_t bms_running_data = {0};
//    bms_running_data.calc_soc = 40000;
//    bms_running_data.calc_soh = 102000;
//    bms_running_data.cycle_count = 0;
    bms_running_data.remain_cap = 40;
    bms_running_data.real_cap = 102;
    bms_running_data.total_chg_mA_s = 0;
    bms_running_data.total_chg_mW_s = 0;
    bms_running_data.total_chg_ah = 0;
    bms_running_data.total_chg_wh = 0;
    bms_running_data.total_dsg_mA_s = 0;
    bms_running_data.total_dsg_mW_s = 0;
    bms_running_data.total_dsg_ah = 0;
    bms_running_data.total_dsg_wh = 0;
//    bms_running_data.full_chg_flag = false;
//    bms_running_data.full_chg_dsg_ah = 0;
//    bms_running_data.soh_high_pre = 100000;
//    bms_running_data.soh_low_pre = 100;
    bms_sox_runing_data_save(bms_running_data);
}

/**
 * @brief                电池簇SOX结果打印
 * @param                [in]type_id      参考sox_data_cmd_e
 * @param                [in]set_data     设置SOX值
 */
void sox_debug_set(uint8_t type_id, uint32_t set_data)
{
    int32_t ret = sox_data_set((sox_data_cmd_e)type_id, set_data);
    log_e("sox_data_set %d, ret = %d\n", type_id, ret);
}

/**
 * @brief        sox功能样例
 * @param        cmd 功能参数
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
static int sox(int argc, char *argv[])
{
	if (argc < 2)
	{
		log_d("%s para err\n", argv[0]);		//打印命令名称
	}
    else
    {
        if (!strcmp(argv[1], "print"))
        {
            sox_printf();
        }
        else if (!strcmp(argv[1], "val"))
        {
            if(argc < 4)
            {
                log_d("%s %s para err\n",argv[0],argv[1]);
                return -1;
            }
            uint32_t val_id = atoi(argv[2]);      // 参数1: 模拟量sox_data_cmd_e
            uint32_t value = atoi(argv[3]);        // 参数2：value值
            sox_debug_set( val_id, value);
        }
        else if (!strcmp(argv[1], "bug"))
        {
            if(argc < 5)
            {
                log_d("%s %s para err\n",argv[0],argv[1]);
                return -1;
            }
            uint32_t debug = atoi(argv[2]);      // 参数1: debug标志
            int32_t val_id = atoi(argv[3]);      // 参数2: 模拟量sox_data_cmd_e
            int32_t value = atoi(argv[4]);        // 参数3：value值
            sox_data_set_debug(debug, val_id, value);
        }
        else if (!strcmp(argv[1], "help"))
        {
            sox_debug_help_printf();
        }
        else if (!strcmp(argv[1], "save"))
        {
            g_sox_run_timer_b10ms = 0;
        }
        else if (!strcmp(argv[1], "runp"))
        {
            sox_run_data_printf();
        }
        else if (!strcmp(argv[1], "reset"))
        {
            sox_running_data_reset();
        }
        else
        {
            sox_debug_err_printf();
            return -1;
        }
    }

    return 0;
}
MSH_CMD_EXPORT(sox, <print/val id value/bug debug(0-1) id value/save/runp/reset>);


