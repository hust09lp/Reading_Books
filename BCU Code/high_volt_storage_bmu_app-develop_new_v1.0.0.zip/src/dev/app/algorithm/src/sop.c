/**
 * @file     sop_calc.c
 * @brief    sop限流控制逻辑
 * @company  sofarsolar
 * @author   骆鹏
 * @note     1.引入放电阶梯限流策略  2.引入电流值500ms滤波
 * @note     3.加入一次充放电状态累计1Ah安时限流回差策略 4.根据亿纬电芯手册刷新的最新SOP表格 5. 修复边界处理及高温升温定点值处理
 * @note     6.修复放电阶梯限流换挡时间计数清0 BUG 7. 根据项目修改放电电流上限为60A      8.增加定位问题日志 9.优化满充后只要不放电，充电限流值最多维持10A  10.增加策略过压告警后防止充电限流值不能退出。
 * @note     11. 增加待机60mA累计1Ah刷新一次最大单体电压。
 * @version  V1.0.7
 * @date     2023/08/25
 */

/*头文件包含*/
#include "bms_state.h"
#include "fault_manage.h"
#include "bmu_data.h"
#include "app_public.h"
#include "public_flag.h"
#include "sofar_can_data.h"
#include "ate.h"
#include "sop.h"
#include <string.h>
#include <stdlib.h>
#include "sdk.h"
#include "shell.h"

#define SOP_SHELL_DEBUG_TEST        // shell debug
#define SOP_CYCLE_RUN_TIME_B10MS    (10)   // 100ms周期运行

#ifdef SOP_SELF_CHECK_DEBUG_TEST
static uint8_t g_sop_self_check_debug_flag = true;
#endif

#ifdef SOP_SHELL_DEBUG_TEST
static power_limit_t g_power_limit_shell_debug = {0};
static bool g_sop_shell_debug_flag = false;
#endif

// #define SOX_SOP_DEBUG

/**
  * @struct sop_last_moment_limit_val_t
  * @brief 记录上一时刻的充放电限流值
*/
typedef struct
{
    int32_t chg_curr_val;
    int32_t dsg_curr_val;
}sop_last_moment_limit_val_t;

/*静态全局变量初始化*/
static power_limit_t                g_power_limit = {0};           // 充放电电压电流限制值
static sop_interface_remap_t        g_sop_interface_remap = {0};  // 外部定制化函数
static sop_bat_data_t               g_sop_bat_data = {0};        // SOP估算需要的电池数据
static uint8_t                      g_bat_last_state;            // 用来保存上一次本PACK的状态
static bool                         g_power_limit_zero_flag = false; // SOP限流值为0标志位
static bool                         g_dsg_limit_enter_flag = false; // 放电阶梯限流模式进入标志
static bool                         g_dsg_limit_exit_flag = false;  // 放电阶梯限流模式退出标志
static bool                         g_min_cell_volt_flag = false;    // 最低单体电压首次≤2810mV 标志位
static int32_t                      g_filter_curr_val = 0;            // 500ms电流滤波值
static int32_t                      g_acc_chg_cap_mah = 0;             //一次充电状态下的累计容量mA.H
static int32_t                      g_acc_dischg_mah  = 0;             //一次放电状态下的累计容量mA.H
static int32_t                      g_acc_standby_mah = 0;           //一次待机状态下的累计容量mA.H
static uint32_t                     g_max_cell_vol = 0;              // 最大单体电压
static uint32_t                     g_min_cell_vol = 0;              // 最小单体电压
static uint8_t                      g_chg_vol_index = 0;             // 充电电压索引
static uint8_t                      g_dsg_vol_index = 0;             // 放电电压索引
static uint8_t                      g_real_temp_index = 0;           // 真实温度索引
static uint8_t                      g_back_temp_index = 0;           // 回差温度索引
static uint8_t                      g_last_temp_index = 0;           // 上一次温度索引
static int16_t                      g_cell_temp       = 0;           // 电芯温度
static uint8_t                      g_limit_curr_index = 0;          // 限流表索引
static uint8_t                      g_first_enter_flag = 0;           //第一次换挡标志
static bool                         g_empty_flag = false;            //放空标志
static sop_last_moment_limit_val_t  g_last_moment_sop = {0};         // 上一时刻充放电限流值

// static uint8_t g_sop_init_success_flag = false;
static uint8_t g_sop_zero_limit_flag = false;

/*表格初始化*/
// 放电电流表(电芯温度、soc) 单位A
const float g_sop_dsg_curr_tab[ARRAY_VOLT_CNT][ARRAY_TEMP_CNT] = {
//  -20℃  -10℃   0℃  10℃  20℃  45℃  55℃  60℃  70℃
    {0,    0,    0,    0,    0,    0,     0,    0,    0}, // 0    -  2400mV
	{0,    0.2,  0.5,  0.5,  0.5,  0.5,   0.5,  0.5,  0}, // 2400 - 3600mV
	{0,    0.2,  0.5,  0.5,  0.5,  0.5,   0.5,  0.5,  0}, // 3600mV - 3800mV - 无穷大
};

// 充电电流表(电芯温度、soc) 单位A
const float g_sop_chg_curr_tab[ARRAY_VOLT_CNT][ARRAY_TEMP_CNT] = {
//  -20℃ -10℃  0℃   10℃   20℃   45℃   55℃  60℃  70℃
    {0,   0,    0,   0.12,   0.5,  0.5,   0.5,   0.25,    0,},  // 0     -   2400mV
	{0,   0,    0,   0.12,   0.5,  0.5,   0.5,   0.25,    0,},  // 2400   -  3650mV
    {0,   0,    0,   0,      0,    0,     0,     0,       0,},  // 3650mV  - 3800mV - 无穷大
};

// 放电截止电压(电芯温度、soc) 单位V
const float g_sop_dsg_vol_tab[ARRAY_VOLT_CNT][ARRAY_TEMP_CNT] = {
//  -20℃ -10℃ 0℃ 10℃ 20℃ 45℃ 55℃ 60℃  70℃
    {448, 448, 448, 448, 448, 448, 448, 448,  448,}, // 0 ~ 2400mV
    {448, 448, 448, 448, 448, 448, 448, 448,  448,}, // 2400 - 3600mV
	{448, 448, 448, 448, 448, 448, 448, 448,  448,}, // 3600mV - 3800mV - 无穷大
};

// 充电电压表(电芯温度、soc) 单位V
const float g_sop_chg_vol_tab[ARRAY_VOLT_CNT][ARRAY_TEMP_CNT] = {
//  -20℃   -10℃  0℃  10℃   20℃ 45℃   55℃  60℃   70℃
    {568,   568,   568,  577,  577, 577,  577,   577,   577,},  // 0     -   2400mV
    {568,   568,   568,  577,  577, 577,  577,   577,   577},  // 2400   -  3650mV
	{568,   568,   568,  577,  577, 577,  577,   577,   577},  // 3650mV  - 3800mV - 无穷大
};
const uint16_t chg_volt_index_tab[ARRAY_VOLT_CNT] = {2400, 3650, 3800}; // 充电单体电压查表 单位mV
const uint16_t dsg_volt_index_tab[ARRAY_VOLT_CNT] = {2400, 3600, 3800}; // 放电单体电压查表 单位mV

const int16_t temp_index_tab[ARRAY_TEMP_CNT]      = {-200, -100, 0, 100, 200, 450, 550, 600,700}; // 温度查表     单位0.1℃
const int16_t temp_back_index_tab[ARRAY_TEMP_CNT] =  {-180, -80, 20, 120, 220, 400,500,550,700};    // 温度回差查表 单位0.1℃
const float dsg_ladder_limit_tab[DSG_LADDER_CURR_NUM] = {0.05, 0.1, 0.2, 0.3};                //放电阶梯限流表  单位1C

static dsg_ladder_paras_t g_dsg_ladder_paras = {
	.startup_flag = true,
	.sop_dsg_cur_be_larger = false,
	.dsg_ladder_change_waiting_cnt = 0,
	.sop_dsg_cur_old = 0,
};

/*模块函数声明*/
static void sop_chg_dsg_volt_get(uint8_t bat_state, uint32_t max_cell_vol, uint32_t min_cell_vol);
static void sop_vol_index_get(void);
static void sop_temp_index_get(int16_t max_cell_temp, int16_t min_cell_temp);
static void sop_vol_temp_index_check(sop_bat_data_t *sop_bat_data);
static bool sop_dsg_ladder_min_cell(uint32_t min_cell_volt);
static bool sop_dsg_ladder_limit_exit(uint8_t bat_state);
static bool sop_dsg_ladder_limit_enter(uint8_t bat_state,uint16_t soc,int16_t min_cell_temp);
static void sop_dsg_ladder_limit_mode(int32_t sys_curr);
static void sop_dsg_ladder_limit_proc(sop_bat_data_t *sop_bat_data);
static void sop_bat_full_empty_check(sop_bat_data_t *sop_bat_data);
static void curr_sliding_filter(int32_t *curr_filter_val);
static uint32_t tick_diff_calc(uint32_t init_tick, uint32_t now_tick);
static void sop_acc_cap_calc(uint8_t bat_state, int32_t sys_curr);

/**
* @brief		SOP外部定制化函数映射接口初始化
* @param		*sop_interface_remap sop接口映射结构体
* @return		g_sop_init_flag
* @retval		true初始化成功  false: 初始化失败
* @warning
*/
bool sop_init(sop_interface_remap_t *sop_interface_remap)
{

    if (NULL == sop_interface_remap)
    {
        log_e("SopInitErr!\n");
        memset(&g_power_limit,0,sizeof(power_limit_t));
        return false;
    }
    else
    {

        memset(&g_power_limit, 0, sizeof(g_power_limit));                   // 充放电电压电流限制值
        g_sop_interface_remap = (*sop_interface_remap);                    //映射外部接口到内部
        memset(&g_sop_bat_data, 0, sizeof(g_sop_bat_data));               // SOP估算需要的电池数据
        g_bat_last_state = 0;                                            // 用来保存上一次本PACK的状态
        g_power_limit_zero_flag = false;                               // SOP限流值为0标志位
        g_dsg_limit_enter_flag = false;                               // 放电阶梯限流模式进入标志
        g_dsg_limit_exit_flag = false;                               // 放电阶梯限流模式退出标志
        g_min_cell_volt_flag = false;                               // 最低单体电压首次≤2810mV 标志位
        g_max_cell_vol = 0;                                         // 最大单体电压
        g_min_cell_vol = 0;                                         // 最小单体电压
        g_chg_vol_index = 0;                                        // 充电电压索引
        g_dsg_vol_index = 0;                                        // 放电电压索引
        g_real_temp_index = 0;                                      // 真实温度索引
        g_back_temp_index = 0;                                      // 回差温度索引
        g_last_temp_index = 0;                                      // 上一次温度
        g_cell_temp       = 0;                                      // 电芯温度
        g_limit_curr_index = 0;                                     // 限流表索引
        g_first_enter_flag = 0;                                     //第一次换挡标志
        g_filter_curr_val = 0;                                      // 500ms电流滤波值
        g_acc_chg_cap_mah = 0;                                       //一次充电状态下的累计容量mA.H
        g_acc_dischg_mah  = 0;                                       //一次放电状态下的累计容量mA.H
		g_acc_standby_mah = 0;                                      //一次待机状态下的累计容量mA.H
        g_empty_flag = false;                                        //放空标志
        memset(&g_last_moment_sop, 0, sizeof(g_last_moment_sop));    // 上一时刻充放电限流值
        return  true;
    }

}
/**
* @brief		获取电池充放电限制值
* @param		无
* @return		返回结果
* @retval		g_power_limit 充放电限流值，限压值
* @warning		无
*/
power_limit_t sop_limit_value_get(void)
{   if(true == g_power_limit_zero_flag)
    {
//        memset(&g_power_limit,  0, sizeof(power_limit_t));
		g_power_limit.chg_curr_limit = 0;
		g_power_limit.dsg_curr_limit = 0;
    }
    return g_power_limit;
}

/**
* @brief		sop电流电压值强制为0标志位
* @param		sop_limit_zero_flag SOP 限制为0标志
* @return		返回结果
* @retval		无
* @warning		无
*/
void sop_power_limit_zero(bool sop_limit_zero_flag)
{
    if (true == sop_limit_zero_flag)
    {
       g_power_limit_zero_flag = true;
    }
    else
    {
        g_power_limit_zero_flag = false;
    }
}


/**
* @brief		电流值做500ms滤波
* @param		int32_t *curr_filter_val 电流滤波值
* @return		返回结果
* @retval		void
* @warning		无
*/
static void curr_sliding_filter(int32_t *curr_filter_val)
{
    static uint8_t sliding_counter = 0;
    static int32_t sliding_filter_curr[FILTER_500MS_BASED_100MS] = {0};
    static uint8_t start_index = 0; // 环形缓冲区起始索引

    if ((NULL == curr_filter_val) || (sliding_counter > FILTER_500MS_BASED_100MS))
    {
        return;
    }
    // 更新缓冲区
    if (sliding_counter == FILTER_500MS_BASED_100MS)
    {   // 满窗，覆盖最旧数据
        sliding_filter_curr[start_index] = g_sop_bat_data.sys_curr;
        start_index = (start_index + 1) % FILTER_500MS_BASED_100MS;
    }
    else
    {    // 填充未满窗
        sliding_filter_curr[sliding_counter] = g_sop_bat_data.sys_curr;
        sliding_counter++;
    }
    // 计算总和
    int32_t curr_sum = 0;
    for (uint8_t i = 0; i < sliding_counter; i++)
    {
        curr_sum += sliding_filter_curr[i];
    }

    *curr_filter_val = curr_sum / sliding_counter;
}

/**
* @brief		放电阶梯限流的判断条件刷新
* @param		无
* @return		无
* @retval		无
* @warning		无
*/
static void sop_dsg_ladder_judge_refresh(uint16_t sop_dsg_cur)
{

    //如果恢复SOP，置起SOP恢复标志位
    //设置进入阶梯限流的等待时间为5秒
    if (g_dsg_ladder_paras.sop_dsg_cur_old < sop_dsg_cur)
    {
        g_dsg_ladder_paras.dsg_ladder_change_waiting_cnt = DSG_LADDER_CHANGE_WAITING_CNT_BASED_100MS;
        g_dsg_ladder_paras.sop_dsg_cur_be_larger = true;
    }
    else
    {
        g_dsg_ladder_paras.sop_dsg_cur_be_larger = false;
    }

    g_dsg_ladder_paras.sop_dsg_cur_old = sop_dsg_cur;

    if (g_dsg_ladder_paras.dsg_ladder_change_waiting_cnt > 0)
    {
        g_dsg_ladder_paras.dsg_ladder_change_waiting_cnt--;
    }
    else
    {
        g_dsg_ladder_paras.dsg_ladder_change_waiting_cnt = 0;
    }
}

/**
* @brief		放电阶梯限流的最低单体电压条件判断
* @param		min_cell_volt 最小单体电压
* @return		返回结果
* @retval		g_min_cell_volt_flag 条件判断标志位
* @warning		无
*/
static bool sop_dsg_ladder_min_cell(uint32_t min_cell_volt)
{
    static uint32_t time_start = 0;
    static uint8_t init_flag = 0;
    if ( 0 == init_flag )
    {
        time_start = g_sop_interface_remap.sop_tick_get_cb();
        init_flag++;
    }


    // 满足最低单体电压 ≤ 2850mV 且持续250ms
    if ( min_cell_volt <= DSG_LADDER_LIMIT_MIN_CELL &&
        (true == g_sop_interface_remap.sop_is_tick_over_cb(time_start, SOP_TICK_250MS)))
       {
            time_start = g_sop_interface_remap.sop_tick_get_cb(); //超时250ms，刷新一次。
            g_min_cell_volt_flag = true;
       }
   else if (min_cell_volt > DSG_LADDER_LIMIT_MIN_CELL)// 不满足
       {
           time_start = g_sop_interface_remap.sop_tick_get_cb();
           g_min_cell_volt_flag = false;
       }

       return g_min_cell_volt_flag;
}

/**
* @brief		放电阶梯限流模式进入条件判断
* @param		bat_state  电池状态 充电/放电/待机
* @param		soc         系统真实SOC
* @param		min_cell_temp 最低电芯温度
* @return		返回结果
* @retval		g_dsg_ladder_limit_flag 放电阶梯限流模式标志
* @warning		无
*/
static bool sop_dsg_ladder_limit_enter(uint8_t bat_state,uint16_t soc, int16_t min_cell_temp)
{
    bool  min_volt_flag = false;
    static uint32_t first_min_vol_count = 0;  // 放电过程中首次最低单体小于放空阈值标志

    // 满足放电阶梯限流进入条件 判断放电状态  再判断最低单体电压 记录第一次单体电压小于2850mV
    if (SOP_DISCHARGE_MODE == bat_state)
    {
        min_volt_flag = sop_dsg_ladder_min_cell(g_sop_bat_data.min_cell_vol);

        if (true == min_volt_flag)  // 满足单体电压<= 2850mV持续250ms
        {
            first_min_vol_count++;
            if (((soc >= DSG_LADDER_LIMIT_SOC) ||
                (min_cell_temp  <= DSG_LADDER_LIMIT_CELL_TEMP))  // 满足SOC > =5% 或电芯温度<= 15℃条件
				&& (0 == g_dsg_ladder_paras.dsg_ladder_change_waiting_cnt))
            {
                if (DSG_MIN_VOL_COUNT == first_min_vol_count)
                {
                    // 放电阶梯限流模式进入标志位置位
                    g_dsg_limit_enter_flag = true;
                }
                else
                {
                    first_min_vol_count = 0;
                }
            }

        }
    }
    else // 不满足放电阶梯限流条件
    {
        g_dsg_limit_enter_flag = false;

        first_min_vol_count = 0;

    }
    return g_dsg_limit_enter_flag;
}
/**
* @brief		放电阶梯限流模式退出条件判断
* @param		bat_state  电池状态 充电/放电/待机
* @return		返回结果
* @retval		g_dsg_ladder_limit_flag 放电阶梯限流模式标志
* @warning		无
*/
static bool sop_dsg_ladder_limit_exit(uint8_t bat_state)
{
    static uint32_t time_start = 0;
    static uint8_t init_flag = 0;
    if(0 == init_flag)
    {
        time_start = g_sop_interface_remap.sop_tick_get_cb(); //记录的tick
        init_flag++;
    }
    // 电池退出放电状态(待机或充电)持续1S   退出放电阶梯限流模式
    if ((SOP_DISCHARGE_MODE != bat_state &&
         (true == g_sop_interface_remap.sop_is_tick_over_cb(time_start,SOP_TICK_1S)))
		|| (true == g_dsg_ladder_paras.sop_dsg_cur_be_larger))
    {
        time_start = g_sop_interface_remap.sop_tick_get_cb();    //超时1S 清空一次。
        g_dsg_limit_exit_flag = true;   // 阶梯限流模式退出标志位置位
    }
    else if (SOP_DISCHARGE_MODE == bat_state)
    {
        time_start = g_sop_interface_remap.sop_tick_get_cb();
        g_dsg_limit_exit_flag = false;
    }

    return g_dsg_limit_exit_flag;
}


/**
* @brief		放电阶梯限流模式 变更放电限流值
* @param		sys_curr 系统电流
* @return		返回结果
* @retval		无
* @warning
*/
static void sop_dsg_ladder_limit_mode(int32_t sys_curr)
{
    uint8_t dsg_limit_index = 0;
    static int32_t last_sys_curr = 0;
    // 基于500ms滤波的电流值 将放电限流值 变更为当前电流(放电电流为负) +5 A 下方 的[0.3C, 0.2C, 0.1C, 0.05C]最近一档， 但不大于系统规定的原有限流值。 单位1mA
    // 考虑电流突变的风险，增加滤波及范围判断。
    sys_curr = sys_curr / 1000  + SOP_LADDER_BACKLASH_CURR;  // 变更单位为A去查表
    if (sys_curr < DSG_LADDER_CURR_MAX_VAL)
    {
        if (last_sys_curr > DSG_LADDER_CURR_MAX_VAL)

        {
             log_e("SopLadderLimCurrErr!\n");
        }
        last_sys_curr = sys_curr;
        return;
    }
    if ((last_sys_curr < DSG_LADDER_CURR_MAX_VAL) &&
        (sys_curr > DSG_LADDER_CURR_MAX_VAL))
    {
        log_e("SopLadderLimCurrOk!\n");
    }
    last_sys_curr = sys_curr;

    //边界处理
    if (abs(sys_curr) <= (uint16_t)(dsg_ladder_limit_tab[0]*DEFAULTED_RATED_CAP))
    {
        g_limit_curr_index = 0;
    }
    else if (abs(sys_curr) >= (uint16_t)(dsg_ladder_limit_tab[DSG_LADDER_LIMIT_TAB_LENGTH - 1]*DEFAULTED_RATED_CAP))
    {
        g_limit_curr_index = DSG_LADDER_LIMIT_TAB_LENGTH - 1;
    }
    else // 内部处理
    {
        // 查放电阶梯限流表 得到放电阶梯限流表索引
        for (dsg_limit_index = 0; dsg_limit_index < DSG_LADDER_CURR_NUM; dsg_limit_index++)
        {
            if ((abs(sys_curr) >= (uint16_t)(dsg_ladder_limit_tab[dsg_limit_index]*DEFAULTED_RATED_CAP)) &&
                ((abs(sys_curr) < (uint16_t)(dsg_ladder_limit_tab[dsg_limit_index + 1]*DEFAULTED_RATED_CAP))))
            {

                break;
            }
        }
        g_limit_curr_index = dsg_limit_index;
    }
       //  不大于系统规定的原有限流值 赋放电阶梯限流表中的值
    if (dsg_ladder_limit_tab[g_limit_curr_index] <= g_sop_dsg_curr_tab[g_dsg_vol_index][g_last_temp_index])
    {
        g_power_limit.dsg_curr_limit = (uint16_t)(dsg_ladder_limit_tab[g_limit_curr_index]*DEFAULTED_RATED_CAP);
    }
    else // 否则赋系统原有的限流值
    {
        g_power_limit.dsg_curr_limit = (uint16_t)(g_sop_dsg_curr_tab[g_dsg_vol_index][g_last_temp_index]*DEFAULTED_RATED_CAP);
    }
}


/**
* @brief		获取电池状态切换时的最大最小单体电压
* @param		无
* @return		返回结果
* @retval
* @warning		无
*/
static void sop_chg_dsg_volt_get(uint8_t bat_state,uint32_t max_cell_vol, uint32_t min_cell_vol)
{
    static uint8_t standy_init = 0;
    static bool over_vol_flag = false;

    // 判断本PACK充放电状态 刷新单体电压
    switch (bat_state)
    {
        case SOP_STANDY_MODE:
              if (standy_init == 0)           // 刚上电时有效，经过充放电后就只会在充放电时才能改变
              {
                g_max_cell_vol = max_cell_vol;
                g_min_cell_vol = min_cell_vol;
              }
              if (g_bat_last_state != bat_state)
              {
                  g_bat_last_state = bat_state;
              }

              if (abs(g_acc_standby_mah) >= SOP_STANDBY_CAP_REFRESH_VAL)    //待机累计1Ah
              {
                  g_max_cell_vol = max_cell_vol;
                  g_min_cell_vol = min_cell_vol;
                  g_acc_standby_mah = 0;
              }
              break;

        case SOP_CHARGE_MODE:
              standy_init =1;
              if (g_acc_chg_cap_mah >= SOP_CHG_ACC_CAP_LIMIT)  // 累计充电1Ah   刷新最低单体 即放电上限
              {
                g_min_cell_vol = min_cell_vol;
              }

              //产生过压告警后记录标志
              if (max_cell_vol >= SOP_OVER_VOL_VAL)
              {
                  over_vol_flag = true;
              }

              if (g_bat_last_state != bat_state)             //PACK状态切换后刷新最高单体
              {
                g_bat_last_state = bat_state;
                // g_max_cell_vol = max_cell_vol;
                g_acc_dischg_mah = 0;                        //启动一个放电积分器A 并初始化为0

              }

              if (g_max_cell_vol < max_cell_vol)            // 最高单体有新高刷新
              {
                  g_max_cell_vol = max_cell_vol;
                  g_acc_dischg_mah = 0;                      //启动一个放电积分器A 并初始化为0
              }
              break;

        case SOP_DISCHARGE_MODE:
             standy_init =1;
             if (g_acc_dischg_mah <= SOP_DISCHG_CAP_LIMIT)   // 累计放电1Ah  刷新最高单体  即充电电流上限
             {
                g_max_cell_vol = max_cell_vol;
             }

             if (g_bat_last_state != bat_state)             //PACK状态切换后刷新最低单体
             {
                g_bat_last_state = bat_state;
                // g_min_cell_vol = min_cell_vol;
                g_acc_chg_cap_mah = 0;                        // 启动一个充电积分器B, 并初始化为0
             }

             if (g_min_cell_vol > min_cell_vol)
             {
                g_min_cell_vol = min_cell_vol;
                g_acc_chg_cap_mah = 0;                       // 启动一个充电积分器B  并初始化为0
             }
             break;

        default:
            break;
    }

    //产生过压告警后刷新最大单体 防止充电限流值限死为0
    if ((true == over_vol_flag) &&
         (max_cell_vol <= SOP_OVER_VOL_CANCEL_VAL))
     {
          g_max_cell_vol =  max_cell_vol;
          over_vol_flag = false;
     }
}

/**
* @brief		获取充放电查表所使用的电压索引
* @param		无
* @return		返回结果
* @retval
* @warning		无
*/

static void sop_vol_index_get(void)
{
    uint8_t chg_volt_index = 0;
    uint8_t dsg_volt_index = 0;

    //遍历充电单体电压表 获取充电电压索引
    for (chg_volt_index = 0; chg_volt_index < ARRAY_VOLT_CNT; chg_volt_index++)
    {
        if (g_max_cell_vol <= chg_volt_index_tab[chg_volt_index])
        {
            break;
        }
    }
    if (chg_volt_index >= ARRAY_VOLT_CNT)  // 若充电单体电压索引 超出 充电单体电压表中电压数量
    {
        chg_volt_index--;
    }
    g_chg_vol_index = chg_volt_index;

    // 遍历放电单体电压表  获取放电电压索引
    for (dsg_volt_index = 0; dsg_volt_index < ARRAY_VOLT_CNT;  dsg_volt_index++)
    {
        if (g_min_cell_vol <= dsg_volt_index_tab[dsg_volt_index])
        {
            break;
        }
    }
    if (dsg_volt_index >= ARRAY_VOLT_CNT) // 若放电单体电压索引 超出 放电单体电压表中电压数量
    {
        dsg_volt_index--;
    }
    g_dsg_vol_index = dsg_volt_index;
}
/**
* @brief		获取充放电查表所使用的温度索引
* @param		无
* @return		返回结果
* @retval
* @warning		无
*/
static void  sop_temp_index_get(int16_t max_cell_temp, int16_t min_cell_temp)
{
    uint8_t real_temp_index = 0; //真实温度索引
    uint8_t back_temp_index = 0; //回差温度索引

    //默认用最低单体温度查表
    g_cell_temp = min_cell_temp;
    if (max_cell_temp > HIGH_LOW_TEMP_BOUNDARY)      // 当最高电芯温度超过26℃，用最高温度查表
    {
        g_cell_temp = max_cell_temp;
    }

    // 查真实温度表
    for (real_temp_index = 0; real_temp_index < ARRAY_TEMP_CNT; real_temp_index++)
    {
        if (g_cell_temp >= SOP_REAL_TEMP_TRANS_UPPER)    // 温度≥45℃ 取高温右边区间
        {
            if (g_cell_temp < temp_index_tab[real_temp_index])
            {
                break;
            }
        }
        else                                             //温度＜45℃，取等低温左边区间
        {
            if (g_cell_temp <= temp_index_tab[real_temp_index])
            {
                break;
            }
        }

    }
    if (real_temp_index >= ARRAY_TEMP_CNT)
    {
        real_temp_index--;
    }
    g_real_temp_index = real_temp_index;

    // 查回差温度表
    for (back_temp_index = 0; back_temp_index < ARRAY_TEMP_CNT; back_temp_index++)
    {

        if (g_cell_temp >= SOP_BACK_TEMP_TRANS_UPPER)
        {
            if (g_cell_temp <= temp_back_index_tab[back_temp_index])  //回差<=40℃， 取等低温左边区间
            {
                break;
            }
        }
        else
        {
            if (g_cell_temp < temp_back_index_tab[back_temp_index])   // 回差>40℃， 取高温右边边区间
            {
                break;
            }
        }

    }
    if (back_temp_index >= ARRAY_TEMP_CNT)
    {
        back_temp_index--;
    }
     g_back_temp_index = back_temp_index;

    //当真实温度索引和回差温度索引一致时， 直接赋值真实温度索引值， 当不一致时，再判断上次温度索引与真实，回差温度索引都不一致，才用真实温度索引更新上次温度索引


       if (g_real_temp_index != g_back_temp_index)
       {
            if ((g_real_temp_index != g_last_temp_index) &&(g_back_temp_index != g_last_temp_index))
            {
                 g_last_temp_index =  g_real_temp_index;
            }
       }
       else
       {
            g_last_temp_index =  g_real_temp_index;
       }


}

/**
* @brief		更新单体电压值并查表获取充放电单体电压索引和温度索引
* @param		无
* @return		返回结果
* @retval		无
* @warning		无
*/
static void sop_vol_temp_index_check(sop_bat_data_t *sop_bat_data)
{
      if (NULL == sop_bat_data)
      {
          return;
      }
    /* ----------------------
       充放电电压表索引获取
     ---------------------- */
        sop_vol_index_get();
     /* ------------------ */
    // 充放电温度索引获取
    /* ------------------ */
      sop_temp_index_get(sop_bat_data->max_cell_temp, sop_bat_data->min_cell_temp);
}

/**
* @brief		放电阶梯限流策略处理流程
* @param		无
* @return		返回结果
* @retval		无
* @warning		无
*/

static void sop_dsg_ladder_limit_proc(sop_bat_data_t *sop_bat_data)
{
     static uint8_t shift_range_count = 0; // 换挡时间计数10S
     bool dsg_limit_enter_flag = false;
     bool min_volt_flag;


     if (NULL == sop_bat_data)
      {
          return;
      }
    /* --------------------
       非放电阶梯限流模式条件判断
     ----------------------*/
    if (true == sop_dsg_ladder_limit_exit(sop_bat_data->bat_state))  //非放电状态
    {
        g_dsg_limit_exit_flag = false;
		g_dsg_limit_enter_flag = false;
        shift_range_count = 0;
        g_first_enter_flag = 0;
        g_power_limit.dsg_curr_limit = (uint16_t)(g_sop_dsg_curr_tab[g_dsg_vol_index][g_last_temp_index]*DEFAULTED_RATED_CAP);
    }
    else // 放电状态
    {
        /* --------------------
       放电阶梯限流模式条件判断
       ----------------------*/
        if (g_first_enter_flag == 0)    // 换挡标志
        {
             dsg_limit_enter_flag = sop_dsg_ladder_limit_enter(sop_bat_data->bat_state,sop_bat_data->sys_soc,sop_bat_data->min_cell_temp);
            // 满足放电阶梯限流模式进入条件
            if (true == dsg_limit_enter_flag)  //第一次进阶梯限流模式

            {
                // 第一次满足换挡条件    在此之前未做换挡动作不需要做限流时间间隔的判断
                g_first_enter_flag = LIMIT_MODE_ENTER_COUNT;
                sop_dsg_ladder_limit_mode(g_filter_curr_val);
                log_e("SopFirstLadder: LimI = %d!\n",g_power_limit.dsg_curr_limit);
           }
           else if (false == dsg_limit_enter_flag)// 不满足放电阶梯限流进入条件
           {
                g_first_enter_flag = 0;
                shift_range_count = 0;
                g_power_limit.dsg_curr_limit = (uint16_t)(g_sop_dsg_curr_tab[g_dsg_vol_index][g_last_temp_index]*DEFAULTED_RATED_CAP);
           }
        }
        else if (g_first_enter_flag >= LIMIT_MODE_ENTER_COUNT) //第二次换挡
        {

                min_volt_flag = sop_dsg_ladder_min_cell(sop_bat_data->min_cell_vol);

              // 未到调整限流时间10S
                if ( (shift_range_count <  LIMIT_TIME_INTERVEL))
                {
                     shift_range_count++;
                }
                //到调整限流时间10S
                else if ((shift_range_count >= LIMIT_TIME_INTERVEL) &&
                    ((true == min_volt_flag)))
                {
                     shift_range_count = 0;
                     sop_dsg_ladder_limit_mode(g_filter_curr_val);

                    if (g_power_limit.dsg_curr_limit != g_last_moment_sop.dsg_curr_val)
                    {
                        log_e("SopLadder: LimI = %d!\n",g_power_limit.dsg_curr_limit);
                    }

                }

        }

    }

}

/**
* @brief		电池满充放空检查
* @param		无
* @return		返回结果
* @retval		无
* @warning		无
*/
static void sop_bat_full_empty_check(sop_bat_data_t *sop_bat_data)
{
      if (NULL == sop_bat_data)
      {
          return;
      }
      //放空判断
      if (SOP_EMPTY_START == g_sop_interface_remap.sop_bat_state_get_cb())
      {
         g_empty_flag = true;
      }

    // 满充 放空判断  满充 充电电流上限为0， 放空判断放电电流上限为0
    if (( SOP_FULL_CHG_START == g_sop_interface_remap.sop_bat_state_get_cb()) ||   // 电池充满
        (SOP_LEVEL2 >= sop_bat_data->max_chg_level))                             // 电池异常模块不允许充电
    {
        g_power_limit.chg_curr_limit = 0;
    }

    if ((SOP_EMPTY_START == g_sop_interface_remap.sop_bat_state_get_cb()) ||    // 放电放空
        ((SOP_LEVEL2 >= sop_bat_data->max_dischg_level))  ||                    // 电池异常模块不允许放电
        ((true == g_empty_flag) && (g_acc_chg_cap_mah < SOP_EMPTY_LIMIT)))      // 放空后需累积充电0.5Ah才允许恢复放电限流值
    {
        g_power_limit.dsg_curr_limit = 0;

    }
    //清除放空标志
    if ((true == g_empty_flag) && (g_acc_chg_cap_mah >= SOP_EMPTY_LIMIT))
    {
         g_empty_flag = false;
    }
}

/**
* @brief		tick差值计算
* @param		init_tick 初始tick
* @param		now_tick  当前tick
* @return		返回结果tick_distance
* @retval		tick差值
* @warning
*/
static uint32_t tick_diff_calc(uint32_t init_tick, uint32_t now_tick)
{
    uint32_t tick_distance = 0;

    if (now_tick >= init_tick)
    {
          tick_distance = now_tick - init_tick;
    }
    else
    {
          tick_distance = (0xffffffff - init_tick + now_tick + 1);
    }
    return   tick_distance;
}

/**
* @brief		SOP累计Ah容量计算
* @param		bat_state 电池状态
* @param		sys_curr  系统电流
* @return		返回结果
* @retval		无
* @warning		无
*/
static void sop_acc_cap_calc(uint8_t bat_state, int32_t sys_curr)
{
    static bool  chg_tick_init_flag = false;
    static bool  dischg_tick_init_flag = false;
    static bool  standby_tick_init_flag = false;
    static uint32_t chg_init_tick = 0;
    static uint32_t dischg_init_tick = 0;
    static uint32_t standby_init_tick = 0;
    static int32_t  acc_chg_cap_ma_ms = 0;  // 累计充电容量mA.mS
    static int32_t  acc_chg_cap_ma_s = 0;   // 累计充电容量mA.S
    static int32_t  acc_chg_cap_ma_h = 0;   // 累计充电容量mA.H
    static int32_t  acc_dischg_cap_ma_ms = 0;  // 累计放电电容量mA.mS
    static int32_t  acc_dischg_cap_ma_s = 0;   // 累计放电容量mA.S
    static int32_t  acc_dischg_cap_ma_h = 0;   // 累计放电容量mA.H
    static int32_t  acc_standby_cap_ma_ms = 0; //累计待机损耗容量mA.mS
    static int32_t  acc_standby_cap_ma_s = 0;  //累计待机损耗容量mA.S
    static int32_t  acc_standby_cap_ma_h = 0;  //累计待机损耗容量mA.H
    uint32_t chg_now_tick = 0;
    uint32_t dischg_now_tick = 0;
    uint32_t standby_now_tick = 0;
    uint32_t tick_distance = 0;
    int32_t  curr_val = 0;

    /******判断充电积分器/放电积分器是否启动， 启动则开始积分累计容量。******/

    // 充电状态 积分充电电流
    if (SOP_CHARGE_MODE == bat_state)              //充电电流>= 150mA  认为正常充电 采样值积分
    {
        //清0 放电积分器相关变量
        acc_dischg_cap_ma_ms = 0;
        acc_dischg_cap_ma_s = 0;
        acc_dischg_cap_ma_h = 0;
        g_acc_dischg_mah = 0;
        dischg_tick_init_flag = false;

        //清0 待机积分器相关变量
        acc_standby_cap_ma_ms = 0;
        acc_standby_cap_ma_s = 0;
        acc_standby_cap_ma_h = 0;
        g_acc_standby_mah = 0;                      //一次待机状态下的累计容量mA.H
        standby_tick_init_flag = false;

        dischg_init_tick = g_sop_interface_remap.sop_tick_get_cb();
        standby_init_tick = g_sop_interface_remap.sop_tick_get_cb();

        //判断电流值
        if (sys_curr >= SOP_CHG_CURR_LIMIT)
        {
           curr_val =  sys_curr;
        }
        else                                       //否则 使用损耗补偿值-60mA 积分
        {
            curr_val =   SOP_TYPICAL_LOSS_CURR;
        }

        // 开始充电积分
        if (false == chg_tick_init_flag)
         {
            chg_tick_init_flag = true;
            chg_init_tick = g_sop_interface_remap.sop_tick_get_cb();
         }
         else
         {
            chg_now_tick = g_sop_interface_remap.sop_tick_get_cb();
            tick_distance = tick_diff_calc(chg_init_tick, chg_now_tick);
            // 开始积分
            acc_chg_cap_ma_ms += curr_val * tick_distance;     //累计容量mA.mS

             // 积分器单位进位判断
            if (acc_chg_cap_ma_ms >= SOP_MS_TO_SECOND)                       // mA.mS 大于1000 转换到 mA.S
            {
                   acc_chg_cap_ma_s  +=  acc_chg_cap_ma_ms / SOP_MS_TO_SECOND ;
                   acc_chg_cap_ma_ms %=  SOP_MS_TO_SECOND;

            }
            else if (acc_chg_cap_ma_ms < SOP_MS_TO_SECOND)                  // mA.mS 小于1000 不用转换
            {
                ;
            }

            if (acc_chg_cap_ma_s >= SOP_SECOND_TO_HOUR)                     // mA.S 大于3600 转换到mA.H
            {
                    acc_chg_cap_ma_h +=   acc_chg_cap_ma_s / SOP_SECOND_TO_HOUR;
                    acc_chg_cap_ma_s  %=  SOP_SECOND_TO_HOUR;
            }
            else                                                          // mA.S 小于3600 不用转换
            {
                ;
            }
            g_acc_chg_cap_mah = acc_chg_cap_ma_h;
            // 刷新当前tick为上一时刻tick
            chg_init_tick = chg_now_tick;
         }
    }

    // 放电状态  积分放电电流
    if(SOP_DISCHARGE_MODE == bat_state)
    {
         //清0 充电积分器相关变量
         acc_chg_cap_ma_ms = 0;
         acc_chg_cap_ma_s = 0;
         acc_chg_cap_ma_h = 0;
         g_acc_chg_cap_mah = 0;
         chg_tick_init_flag = false;

        //清0 待机积分器相关变量
        acc_standby_cap_ma_ms = 0;
        acc_standby_cap_ma_s = 0;
        acc_standby_cap_ma_h = 0;
        g_acc_standby_mah = 0;                      //一次待机状态下的累计容量mA.H
        standby_tick_init_flag = false;

        chg_init_tick = g_sop_interface_remap.sop_tick_get_cb();
        standby_init_tick = g_sop_interface_remap.sop_tick_get_cb();

         // 判断电流值
         if (sys_curr <=  SOP_DISCHG_CURR_LIMIT)       //放电电流 <= -150mA 认为正常放电
         {
             curr_val =  sys_curr;
         }
         else                                         // 否则 使用损耗补偿值-60mA 积分
         {
             curr_val =   SOP_TYPICAL_LOSS_CURR;
         }

         //开始放电积分
         if (false == dischg_tick_init_flag)
         {
             dischg_init_tick = g_sop_interface_remap.sop_tick_get_cb();
             dischg_tick_init_flag = true;
         }
         else
         {
             dischg_now_tick = g_sop_interface_remap.sop_tick_get_cb();
             tick_distance = tick_diff_calc(dischg_init_tick, dischg_now_tick);
             // 开始积分
             acc_dischg_cap_ma_ms +=  curr_val * tick_distance;
             // 积分器单位进位判断
             if (abs(acc_dischg_cap_ma_ms) >= SOP_MS_TO_SECOND)     // mA.mS 大于1000 转换到  mA.S
             {
                 acc_dischg_cap_ma_s +=  acc_dischg_cap_ma_ms / SOP_MS_TO_SECOND;
                 acc_dischg_cap_ma_ms %= SOP_MS_TO_SECOND;
             }
             else                                                  // mA.mS 小于1000 不用转换
             {
                  ;
             }
             if (abs(acc_dischg_cap_ma_s) >= SOP_SECOND_TO_HOUR)   // mA.S 大于3600 转换到mA.H
             {
                   acc_dischg_cap_ma_h += acc_dischg_cap_ma_s / SOP_SECOND_TO_HOUR;
                   acc_dischg_cap_ma_s %= SOP_SECOND_TO_HOUR;
             }
             else                                                 // mA.S 小于3600 不用转换
             {
                 ;
             }
             g_acc_dischg_mah = acc_dischg_cap_ma_h;
             //刷新当前tick为上一时刻tick
             dischg_init_tick = dischg_now_tick;
         }
   }
   // 待机状态
   if (SOP_STANDY_MODE == bat_state)
   {
        chg_init_tick = g_sop_interface_remap.sop_tick_get_cb();
        // //清0 充电积分器相关变量
        // acc_chg_cap_ma_ms = 0;
        // acc_chg_cap_ma_s = 0;
        // acc_chg_cap_ma_h = 0;
        // g_acc_chg_cap_mah = 0;
        // chg_tick_init_flag = false;
    //    //清0 放电积分器相关变量
    //     acc_dischg_cap_ma_ms = 0;
    //     acc_dischg_cap_ma_s = 0;
    //     acc_dischg_cap_ma_h = 0;
    //     g_acc_dischg_mah = 0;
    //     dischg_tick_init_flag = false;

        //进行待机损耗计算
       if (false == standby_tick_init_flag )
       {
           standby_init_tick = g_sop_interface_remap.sop_tick_get_cb();
           standby_tick_init_flag = true;
       }
       else
       {
             standby_now_tick = g_sop_interface_remap.sop_tick_get_cb();
             tick_distance = tick_diff_calc(standby_init_tick, standby_now_tick);
             // 开始积分
             acc_standby_cap_ma_ms +=  (SOP_TYPICAL_LOSS_CURR * (int32_t)tick_distance);
             // 积分器单位进位判断
             if (abs(acc_standby_cap_ma_ms) >= SOP_MS_TO_SECOND)     // mA.mS 大于1000 转换到  mA.S
             {
                 acc_standby_cap_ma_s +=  acc_standby_cap_ma_ms / SOP_MS_TO_SECOND;
                 acc_standby_cap_ma_ms %= SOP_MS_TO_SECOND;
             }
             else                                                  // mA.mS 小于1000 不用转换
             {
                  ;
             }
             if (abs(acc_standby_cap_ma_s) >= SOP_SECOND_TO_HOUR)   // mA.S 大于3600 转换到mA.H
             {
                   acc_standby_cap_ma_h += acc_standby_cap_ma_s / SOP_SECOND_TO_HOUR;
                   acc_standby_cap_ma_s %= SOP_SECOND_TO_HOUR;
             }
             else                                                 // mA.S 小于3600 不用转换
             {
                 ;
             }
             g_acc_standby_mah = acc_standby_cap_ma_h;
             //刷新当前tick为上一时刻tick
             standby_init_tick = standby_now_tick;
       }

       //开始放电积分
         if (false == dischg_tick_init_flag)
         {
             dischg_init_tick = g_sop_interface_remap.sop_tick_get_cb();
             dischg_tick_init_flag = true;
         }
         else
         {
             dischg_now_tick = g_sop_interface_remap.sop_tick_get_cb();
             tick_distance = tick_diff_calc(dischg_init_tick, dischg_now_tick);
             // 开始积分
             acc_dischg_cap_ma_ms +=  (int32_t)(SOP_TYPICAL_LOSS_CURR * (int32_t)tick_distance);
             // 积分器单位进位判断
             if (abs(acc_dischg_cap_ma_ms) >= SOP_MS_TO_SECOND)     // mA.mS 大于1000 转换到  mA.S
             {
                 acc_dischg_cap_ma_s +=  acc_dischg_cap_ma_ms / SOP_MS_TO_SECOND;
                 acc_dischg_cap_ma_ms %= SOP_MS_TO_SECOND;
             }
             else                                                  // mA.mS 小于1000 不用转换
             {
                  ;
             }
             if (abs(acc_dischg_cap_ma_s) >= SOP_SECOND_TO_HOUR)   // mA.S 大于3600 转换到mA.H
             {
                   acc_dischg_cap_ma_h += acc_dischg_cap_ma_s / SOP_SECOND_TO_HOUR;
                   acc_dischg_cap_ma_s %= SOP_SECOND_TO_HOUR;
             }
             else                                                 // mA.S 小于3600 不用转换
             {
                 ;
             }
             g_acc_dischg_mah = acc_dischg_cap_ma_h;
             //刷新当前tick为上一时刻tick
             dischg_init_tick = dischg_now_tick;
         }
   }
}

/**
* @brief		sop 线程 每100ms运行一次
* @param		无
* @return		返回结果
* @retval		无
* @warning		在sop初始化以后调用
*/
void sop_thread(void)
{
     bool bat_data_now_flag = false;//当前时刻获取电池数据标志
     static bool bat_data_last_flag = false;//上一时刻获取电池数据标志
     uint8_t bms_sta = 0;
    /**************获取电池数据******************/
    bat_data_now_flag = g_sop_interface_remap.sop_bat_data_get_cb(&g_sop_bat_data);
	#ifdef SOX_SOP_DEBUG
		bms_sta = BMS_STATE_RUN;
	#else
		bms_sta = bms_state_get_sys_sta(); //获取系统状态
	#endif
    //触发数据异常限流为0 并打印数据
    if ((true == bat_data_last_flag) &&
        (false == bat_data_now_flag) &&
        (BMS_STATE_SHUT_DOWN != bms_sta)) // 若电池数据获取失败 则返回,限流为0。
    {
       memset(&g_power_limit,0,sizeof(power_limit_t));

    //    log_e("SopBatDataErr!\n");
    //    log_e("Sta:%d,MaxT:%d,MinT:%d,MaxV:%d,MinV:%d,SOC:%d,I:%d,ChgL:%d,DsgL:%d\n",g_sop_bat_data.bat_state,g_sop_bat_data.max_cell_temp,g_sop_bat_data.min_cell_temp,
    //           g_sop_bat_data.max_cell_vol,g_sop_bat_data.min_cell_vol,g_sop_bat_data.sys_soc,g_sop_bat_data.sys_curr,
    //           g_sop_bat_data.max_chg_level,g_sop_bat_data.max_dischg_level);
    }
    //数据恢复正常触发打印
    else if ((false == bat_data_last_flag) &&
             (true == bat_data_now_flag))
    {
        #ifdef SOP_CALC_DEBUG
        log_e("SopBatDataOk!\n");
        #endif
    }
    bat_data_last_flag =  bat_data_now_flag;

    if (false == bat_data_last_flag)
    {
       return;
    }

    /*********************电流500ms滤波*************************/
    curr_sliding_filter(&g_filter_curr_val);   // 电流500ms滤波值

    /***********一次充放电过程中累计容量计算*****************/
    sop_acc_cap_calc(g_sop_bat_data.bat_state, g_sop_bat_data.sys_curr);

    /******************更新单体电压*****************************/
    /* --------------------------
       电池状态切换时更新最大最小单体电压
     ---------------------------- */
     sop_chg_dsg_volt_get( g_sop_bat_data.bat_state,g_sop_bat_data.max_cell_vol, g_sop_bat_data.min_cell_vol);

    /************查SOP表获取索引***************/
    sop_vol_temp_index_check(&g_sop_bat_data);

	/*********刷新SOP放电阶梯限流相关判断条件**************/
	//第一次开机给相关参数赋值初始值
    if (true == g_dsg_ladder_paras.startup_flag)
    {
        g_dsg_ladder_paras.sop_dsg_cur_old = (uint16_t)(g_sop_dsg_curr_tab[g_dsg_vol_index][g_last_temp_index]*DEFAULTED_RATED_CAP);
        g_dsg_ladder_paras.startup_flag = false;
    }

	sop_dsg_ladder_judge_refresh((uint16_t)(g_sop_dsg_curr_tab[g_dsg_vol_index][g_last_temp_index]*DEFAULTED_RATED_CAP));

   /************放电阶梯限流策略处理流程*********************/
    sop_dsg_ladder_limit_proc(&g_sop_bat_data);

   /***********************赋值SOP 限制值************************/

    g_power_limit.chg_curr_limit = (uint16_t)(g_sop_chg_curr_tab[g_chg_vol_index][g_last_temp_index]*DEFAULTED_RATED_CAP);
    g_power_limit.chg_volt_limit = g_sop_chg_vol_tab[g_chg_vol_index][g_last_temp_index];
    g_power_limit.dsg_volt_limit = g_sop_dsg_vol_tab[g_dsg_vol_index][g_last_temp_index];
     /**********************电池满充放空判断**********************/
    sop_bat_full_empty_check(&g_sop_bat_data);

    //限流值发生变化则日志打印
    if ((g_power_limit.chg_curr_limit != g_last_moment_sop.chg_curr_val) ||
        (g_power_limit.dsg_curr_limit != g_last_moment_sop.dsg_curr_val))
    {
        #ifdef SOP_CALC_DEBUG
        log_e("sop val is changed!\n");
        log_e("last_sta:%d, this:%d",g_bat_last_state,g_sop_bat_data.bat_state);
        log_e("last_chg: %d,now_chg:%d,last_dsg:%d,now_dsg:%d, MaxT:%d,MinT:%d,MaxV:%d,MinV:%d,I:%d!\n",g_last_moment_sop.chg_curr_val,g_power_limit.chg_curr_limit,
              g_last_moment_sop.dsg_curr_val,g_power_limit.dsg_curr_limit,g_sop_bat_data.max_cell_temp,g_sop_bat_data.min_cell_temp,
              g_max_cell_vol,g_min_cell_vol,g_sop_bat_data.sys_curr);
       #endif
    }
    //当前时刻值赋值给上一时刻
    g_last_moment_sop.chg_curr_val =  g_power_limit.chg_curr_limit;
    g_last_moment_sop.dsg_curr_val =  g_power_limit.dsg_curr_limit;

}

/**
* @brief        sop线程 每100ms执行一次
* @param        SOP接口映射
* @return        返回结果
* @retval       无
* @warning      sop_init_deal()必须先初始化
*/
void sop_proc_deal(void)
{
    if (special_mode_get(ATUO_TEST))
    {
        return;
    }
#ifdef SOP_SELF_CHECK_DEBUG_TEST
    if (g_sop_self_check_debug_flag)
    {
        return;
    }
#endif
    static uint8_t delay = SOP_CYCLE_RUN_TIME_B10MS;
    if ((--delay) > 0)
    {
        return;
    }
    delay = SOP_CYCLE_RUN_TIME_B10MS;
    // if (!g_sop_init_success_flag)
    // {
    //     sop_init_deal();
    //     return;
    // }
    sop_thread();

    // SOP变化成0，需要主动上报一次遥信数据
    static power_limit_t last_power_limit_data = {0};
    power_limit_t curr_power_limit_data = sop_limit_value_get_deal();
    if ((0 != last_power_limit_data.chg_curr_limit && 0 == curr_power_limit_data.chg_curr_limit) ||
        (0 != last_power_limit_data.dsg_curr_limit && 0 == curr_power_limit_data.dsg_curr_limit))
    {
        inner_can_send_msg_ready(BMS_REMOTE_SIGNAL_INFO1);
        inner_can_send_msg_ready(BMS_REMOTE_SIGNAL_INFO2);
    }
    last_power_limit_data = curr_power_limit_data;
}

/**
* @brief		充放电电压电流限制值获取
* @param		无
* @return		返回结果
* @retval		充放电限流值、限压值
* @warning
*/
power_limit_t sop_limit_value_get_deal(void)
{
#ifdef SOP_SHELL_DEBUG_TEST
    if (g_sop_shell_debug_flag)
    {
        return g_power_limit_shell_debug;
    }
#endif
    return sop_limit_value_get();
}

/**
 * @brief                设置sop限流为0
 * @param                [in]bool 设置标志，true为限流，false为取消限流
 * @return
 */
void sop_curr_limit_set(bool set_flag)
{
#ifdef SOP_SELF_CHECK_DEBUG_TEST
    if (g_sop_self_check_debug_flag)
    {
        return;
    }
#endif

#ifdef SOP_SHELL_DEBUG_TEST
    if (g_sop_shell_debug_flag)
    {
        return;
    }
#endif
    sop_power_limit_zero(set_flag);
    if (g_sop_zero_limit_flag != set_flag)
    {
        log_d("sop_curr_limit_set %d\n", (uint8_t)set_flag);
    }
    g_sop_zero_limit_flag = set_flag;
}

/**************************************SOP_SHELL_DEBUG_TEST***********************************************/
#ifdef SOP_SHELL_DEBUG_TEST
typedef enum
{
    DEBUG_VAL_LIMIT_DSG_CURR = 0,                // 综合放电上限，单位1A, 无效值位0xFFFF
    DEBUG_VAL_LIMIT_CHG_CURR,                    // 综合充电上限，单位1A, 无效值位0xFFFF
    DEBUG_VAL_LIMIT_DSG_VOLT,                    // 综合充电上限，单位0.1V, 无效值位0xFFFF
    DEBUG_VAL_LIMIT_CHG_VOLT,                    // 综合充电上限，单位0.1V, 无效值位0xFFFF
    DEBUG_VAL_ZERO_FLAG,
    DEBUG_VAL_NUM,
} sop_debug_e;

/**
 * @brief                电池簇SOP结果打印
 * @param                [in]void
 */
void sop_printf(void)
{
    power_limit_t print_data = {0};
    if (g_sop_shell_debug_flag)
    {
        print_data = g_power_limit_shell_debug;
    }
    else
    {
        print_data = sop_limit_value_get();
    }
    log_d("chgClim=%d(A)\n", print_data.chg_curr_limit);
    log_d("dsgClim=%d(A)\n", print_data.dsg_curr_limit);
    log_d("chgVlim=%d(0.1V)\n", print_data.chg_volt_limit);
    log_d("dsgVlim=%d(0.1V)\n", print_data.dsg_volt_limit);
    log_d("sopZeroLim=%d\n", g_sop_zero_limit_flag);
    log_d("MaxT: %d, MinT: %d\n", g_sop_bat_data.max_cell_temp, g_sop_bat_data.min_cell_temp);
    log_d("MaxV: %d, MinV: %d\n", g_sop_bat_data.max_cell_vol, g_sop_bat_data.min_cell_vol);
    log_d("chg_v_index = %d, dsg_v_index = %d, temp_index = %d\n", g_chg_vol_index, g_dsg_vol_index, g_last_temp_index);
}

/**
 * @brief                电池簇SOX错误打印
 * @param                [in]void
 */
void sop_debug_err_printf(void)
{
    log_d(" sop_t param err\r\n");
    log_d(" sop_t print : printf data\r\n");
    log_d(" sop_t help : printf hlep data\r\n");
    log_d(" sop_t val debug(0/1) val_id(0~%d) val: set analog data\r\n", DEBUG_VAL_NUM - 1);
}

/**
 * @brief                电池簇SOP打印提示
 * @param                [in]void
 */
void sop_debug_help_printf(void)
{
    log_d("val_id:\n");
    log_d("DEBUG_VAL_LIMIT_DSG_CURR = %d\n", DEBUG_VAL_LIMIT_DSG_CURR);
    log_d("DEBUG_VAL_LIMIT_CHG_CURR = %d\n", DEBUG_VAL_LIMIT_CHG_CURR);
    log_d("DEBUG_VAL_LIMIT_DSG_VOLT = %d\n", DEBUG_VAL_LIMIT_DSG_VOLT);
    log_d("DEBUG_VAL_LIMIT_CHG_VOLT = %d\n", DEBUG_VAL_LIMIT_CHG_VOLT);
    log_d("DEBUG_VAL_ZERO_FLAG      = %d\n", DEBUG_VAL_ZERO_FLAG);
}

/**
 * @brief                电池簇SOP结果打印
 * @param                [in]debug_flag   设置参数标志0：不调，1：调试
 * @param                [in]type_id      参考sop_debug_e
 * @param                [in]set_data     设置SOP值
 */
void sop_shell_debug_set(bool debug_flag, uint8_t type_id, uint16_t set_data)
{
    g_sop_shell_debug_flag = debug_flag;
    if (!g_sop_shell_debug_flag)
    {
        return;
    }
    switch (type_id)
    {
        case DEBUG_VAL_LIMIT_DSG_CURR:
            g_power_limit_shell_debug.dsg_curr_limit = set_data;
            break;
        case DEBUG_VAL_LIMIT_CHG_CURR:
            g_power_limit_shell_debug.chg_curr_limit = set_data;
            break;
        case DEBUG_VAL_LIMIT_DSG_VOLT:
            g_power_limit_shell_debug.dsg_volt_limit = set_data;
            break;
        case DEBUG_VAL_LIMIT_CHG_VOLT:
            g_power_limit_shell_debug.chg_volt_limit = set_data;
            break;
        case DEBUG_VAL_ZERO_FLAG: 
            g_sop_zero_limit_flag = set_data;
            break;
        default:
            break;
    }
}

/**
 * @brief        sop功能样例
 * @param        cmd 功能参数
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
static int sop(int argc, char *argv[])
{
    if (argc < 2)
    {
        log_d("%s para err\n",argv[0]);
    }
    else
    {
        if (!strcmp(argv[1], "print"))
        {
            sop_printf();
        }
        else if (!strcmp(argv[1], "val"))
        {
            if(argc < 5)
            {
                log_d("%s %s para err\n",argv[0],argv[1]);
                return -1;
            }
            uint32_t debug_flag = atoi(argv[2]);  // 设置参数1：debug标志（1使能，0取消）
            uint32_t val_id = atoi(argv[3]);      // 参数2: 模拟量sop_debug_e
            uint16_t value = atoi(argv[4]);        // 参数3：value值
            sop_shell_debug_set(debug_flag, val_id, value);
        }
        else if (!strcmp(argv[1], "help"))
        {
            sop_debug_help_printf();
        }
        else
        {
            sop_debug_err_printf();
        }
    }

    return 0; 
}
MSH_CMD_EXPORT(sop, <print/val id value>);
#endif
