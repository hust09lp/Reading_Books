/**
 * @file         soe.c
 * @brief        电池包级别的SOE计算
 * @details      电池包级别的SOE计算
 * @author       zhangzhichao
 * @date         2024/11/06
 * @version      V0.0.1
 * @attention 传入：SOC精度为--0.001%
 * @attention 传入：电流精度为--1mA
 * @attention 传入：温度精度为--1℃
 * @attention 传入：Tick精度为--1ms
 * @attention 传出：SOE显示值精度为1%，SOE计算值精度为0.001%
 * @copyright    Copyright(c) 2024 by SofarSolar, All Rights Reserved.
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author              <th>Description
 * <tr><td>2024/11/06  <td>0.0.1    <td>zhangzhichao       <td>优化内容，详见git上的更改点
 *
 * </table>
 *
 **********************************************************************************
 */

#include "soe.h"
#include <stdlib.h>
#include "sdk.h"
/************************************************************************/
/*************************SOE内部定义的数据结构****************************/
/************************************************************************/

/**
  * @struct   soe_val_t
  * @brief    SOE计算值、保存值、显示值
  */
 typedef struct
{
    float soe_calc;			///< SOE计算值，精度：0.001%
    float soe_save;			///< SOE保存值，精度：0.001%
    uint8_t soe_display;	///< SOE显示值，精度：1%
}soe_val_t;

/**
  * @struct   soe_calc_para_t
  * @brief    SOE计算相关的参数
  */
typedef struct
{
	float soe_prop;			///< SOE比例系数，精度：0.001
    uint8_t display_cnt;	///< 显示计数器，每1s加1
}soe_calc_para_t;

/**
  * @struct   soe_input_data_t
  * @brief    SOE计算所需要的输入数据
  */
typedef struct
{
    int32_t sys_cur;			///< 系统电流，精度：1mA
    float sys_cur_fil;			///< 系统电流滤波后的值，精度：1mA
    int32_t pack_soc;			///< 电池包SOC，精度：0.001%
    int16_t avg_cell_temp;		///< 平均电芯温度，精度：1℃
}soe_input_data_t;

/**
  * @struct   soe_flag_t
  * @brief    SOE线程中的标志位
  */
typedef struct
{
	bool proc_init;		//进程初始化
	bool params_init;	//进程参数初始化
}soe_flag_t;

/************************************************************************/
/*************************SOE模块内部使用的宏定义***************************/
/************************************************************************/

//SOE滤波系数
#define SOE_FIL_COFF (0.95f)

//SOE显示时间限制、电流限制
#define SOE_DISPLAY_TIME_LIMIT 10
#define SOE_DISPLAY_CUR_UNDER_LIMIT (-150)
#define SOE_DISPLAY_CUR_UPPER_LIMIT 300

//SOE数据表格维度
#define SOE_PROP_TAB_DIM 3
#define SOE_PROP_TAB_TEMP_LENGTH 4
#define SOE_PROP_TAB_CUR_LENGTH 4
#define SOE_PROP_TAB_SOC_LENGTH 21

/************************************************************************/
/***************************静态全局量初始化*******************************/
/************************************************************************/

//SOE计算值、保存值、显示值
static soe_val_t g_soe_val = {0};

//SOE计算过程中的参数
static soe_calc_para_t g_soe_calc_para = {
	.display_cnt = 0,
	.soe_prop = 1.000,
};

//SOE计算所需要的输入数据
static soe_input_data_t g_soe_input_data = {
	.avg_cell_temp = 0,
	.pack_soc = 0,
	.sys_cur = 0,
	.sys_cur_fil = 0,
};

//SOE线程中的标志位
static soe_flag_t g_soe_flags = {
	.proc_init = false,
	.params_init = false,
};

//SOX运行数据指针
static sox_running_data_t* gp_sox_running_data = NULL;

//SOX通用滤波后的采样数据
static sox_sample_data_t g_sox_sample_data = {0};

//SOE需要的接口函数地址
static sox_interface_remap_t g_soe_inf = {0};


/*********************表格1---三维表格，通过SOC、电流、温度查阅SOE比例系数***********************/
//SOE比例系数三维表索引：SOC、电流、温度
static const int32_t soe_k_index_tab[SOE_PROP_TAB_DIM][SOE_PROP_TAB_SOC_LENGTH] =
{
	{1000, 5000, 10000, 15000, 20000, 25000, 30000,
	35000, 40000, 45000, 50000, 55000, 60000, 65000,
	70000, 75000, 80000, 85000, 90000, 95000, 100000},
	{10000, 20000, 30000, 50000},
	{15, 25, 35, 45},
};

//SOE比例系数三维表
static const int32_t soe_k_data_tab[SOE_PROP_TAB_TEMP_LENGTH][SOE_PROP_TAB_CUR_LENGTH][SOE_PROP_TAB_SOC_LENGTH] =
{
	{
	//	1%		5%		10%		15%		20%		25%		30%		35%		40%		45%		50%
	//	55%		60%		65%		70%		75%		80%		85%		90%		95%		100%
		{864 ,	919 ,	945 ,	956 ,	963 ,	969 ,	974 ,	978 ,	981 ,	983 ,	985 ,
		987 ,	989 ,	991 ,	992 ,	994 ,	995 ,	997 ,	998 ,	999 ,	1000},
		{863 ,	916 ,	942 ,	954 ,	962 ,	968 ,	973 ,	977 ,	980 ,	983 ,	985 ,
		987 ,	989 ,	990 ,	992 ,	994 ,	995 ,	996 ,	998 ,	999 ,	1000},
		{863 ,	911 ,	939 ,	952 ,	961 ,	967 ,	972 ,	976 ,	979 ,	982 ,	985 ,
		987 ,	989 ,	990 ,	992 ,	994 ,	995 ,	996 ,	998 ,	999 ,	1000},
		{867 ,	910 ,	937 ,	951 ,	960 ,	967 ,	972 ,	976 ,	979 ,	982 ,	985 ,
		987 ,	989 ,	991 ,	992 ,	994 ,	995 ,	997 ,	998 ,	999 ,	1000},
	},

	{
		{863 ,	919 ,	946 ,	956 ,	964 ,	969 ,	974 ,	978 ,	981 ,	983 ,	986 ,
		987 ,	989 ,	991 ,	992 ,	994 ,	995 ,	997 ,	998 ,	999 ,	1000} ,
		{864 ,	919 ,	945 ,	956 ,	964 ,	969 ,	974 ,	978 ,	981 ,	983 ,	986 ,
		987 ,	989 ,	991 ,	992 ,	994 ,	995 ,	997 ,	998 ,	999 ,	1000} ,
		{866 ,	919 ,	945 ,	956 ,	963 ,	969 ,	974 ,	977 ,	981 ,	983 ,	985 ,
		987 ,	989 ,	991 ,	992 ,	994 ,	995 ,	997 ,	998 ,	999 ,	1000} ,
		{868 ,	920 ,	945 ,	956 ,	963 ,	969 ,	974 ,	977 ,	980 ,	983 ,	985 ,
		987 ,	989 ,	991 ,	992 ,	994 ,	995 ,	997 ,	998 ,	999 ,	1000} ,
	},

	{
		//	1%		5%		10%		15%		20%		25%		30%		35%		40%		45%		50%
		//	55%		60%		65%		70%		75%		80%		85%		90%		95%		100%
		{862 ,	918 ,	945 ,	956 ,	963 ,	969 ,	974 ,	978 ,	981 ,	984 ,	986 ,
		987 ,	989 ,	991 ,	992 ,	994 ,	995 ,	997 ,	998 ,	999 ,	1000} ,
		{863 ,	918 ,	946 ,	956 ,	964 ,	969 ,	974 ,	978 ,	981 ,	983 ,	986 ,
		988 ,	989 ,	991 ,	992 ,	994 ,	995 ,	997 ,	998 ,	999 ,	1000} ,
		{865 ,	919 ,	946 ,	956 ,	964 ,	969 ,	974 ,	978 ,	981 ,	983 ,	986 ,
		987 ,	989 ,	991 ,	992 ,	994 ,	995 ,	997 ,	998 ,	999 ,	1000} ,
		{867 ,	920 ,	946 ,	956 ,	964 ,	969 ,	974 ,	977 ,	981 ,	983 ,	985 ,
		987 ,	989 ,	991 ,	992 ,	994 ,	995 ,	997 ,	998 ,	999 ,	1000} ,
	},

	{
		{861 ,	917 ,	945 ,	956 ,	963 ,	969 ,	973 ,	978 ,	981 ,	984 ,	986 ,
		988 ,	989 ,	991 ,	992 ,	994 ,	995 ,	997 ,	998 ,	999 ,	1000} ,
		{862 ,	918 ,	945 ,	956 ,	963 ,	969 ,	974 ,	978 ,	981 ,	984 ,	986 ,
		988 ,	989 ,	991 ,	992 ,	994 ,	995 ,	997 ,	998 ,	999 ,	1000} ,
		{863 ,	918 ,	945 ,	956 ,	964 ,	969 ,	974 ,	978 ,	981 ,	983 ,	986 ,
		988 ,	989 ,	991 ,	992 ,	994 ,	995 ,	997 ,	998 ,	999 ,	1000} ,
		{865 ,	919 ,	946 ,	956 ,	964 ,	969 ,	974 ,	978 ,	981 ,	983 ,	986 ,
		987 ,	989 ,	991 ,	992 ,	994 ,	995 ,	997 ,	998 ,	999 ,	1000} ,
	},
};


/*****************************************************************************/
/*****************************SOE模块--函数实现********************************/
/*****************************************************************************/


/**
* @brief		SOE进程初始化，在进程执行前调用，完成接口的初始化
 * @param[in]	sox_interface_remap，SOE接口函数的地址
 * @return		SOX_OK，进程初始化成功；SOX_FAIL，进程初始化失败
 * @note
*/
int8_t soe_proc_init(sox_interface_remap_t sox_interface_remap)
{
	int8_t ret = SOX_OK;

	if (false == g_soe_flags.proc_init)
	{
		if ((NULL == sox_interface_remap.calc_soc_get)
		|| (NULL == sox_interface_remap.sox_running_data_addr_get)
		|| (NULL == sox_interface_remap.soe_save)
		|| (NULL == sox_interface_remap.sox_limit_params_get))
		{
			g_soe_flags.proc_init = false;
			ret = SOX_FAIL;
		}
		else
		{
			g_soe_inf = sox_interface_remap;
			gp_sox_running_data = g_soe_inf.sox_running_data_addr_get();

			g_soe_flags.proc_init = true;
			ret = SOX_OK;
		}
	}
	else if (true == g_soe_flags.proc_init)
	{
		g_soe_flags.proc_init = true;
		ret = SOX_OK;
	}

	return ret;
}


/**
* @brief		SOE模块数据初始化，完成SOE进程中参数的初始化
 * @param[in]	无
 * @return		SOX_OK，初始化成功；SOX_FAIL，初始化失败
 * @note
*/
static int8_t soe_params_init(void)
{
	int8_t ret = SOX_OK;

    //加入初始化判断，防止重复初始化
    if (false == g_soe_flags.params_init)
    {
        //从FLASH中读取SOE比例系数
		gp_sox_running_data = g_soe_inf.sox_running_data_addr_get();
        g_soe_calc_para.soe_prop = gp_sox_running_data->soe_prop;

		if (SOC_UPPER_LIMIT < g_soe_input_data.pack_soc)
		{
			g_soe_input_data.pack_soc = SOC_UPPER_LIMIT;
		}
		else if (SOC_LOWER_LIMIT > g_soe_input_data.pack_soc)
		{
			g_soe_input_data.pack_soc = SOC_LOWER_LIMIT;
		}

        //初始化：SOE计算值、显示值、保存值、SOE比例系数
        g_soe_val.soe_calc = g_soe_calc_para.soe_prop * g_soe_input_data.pack_soc;

        g_soe_val.soe_save = g_soe_val.soe_calc;

        g_soe_val.soe_display = (uint8_t)((g_soe_val.soe_calc + THOUTHAND_ROUND_OFF) / SOE_CALC_PRE);

        g_soe_flags.params_init = true;

		ret = SOX_OK;
    }

	return ret;
}

/**
* @brief		SOE比例系数搜索
 * @param[in]	soc，当前电池包的SOC值
 * @param[in]	current，当前电池包的电流值
 * @param[in]	temp，当前电池包的平均温度
 * @return		搜索成功，SOE的比例系数；搜索失败，SOX_FAIL
 * @note
*/
static float soe_prop_search(int32_t soc, int32_t current, int16_t temp)
{
    float k = 0.0;

	index_length_3d_t index_length_3d =
		{SOE_PROP_TAB_SOC_LENGTH,SOE_PROP_TAB_CUR_LENGTH,SOE_PROP_TAB_TEMP_LENGTH};

	coord_3d_t coord_3d = {soc,abs(current),temp};

	k = (float)(sox_interp_3d((int32_t *)soe_k_index_tab, (int32_t *)soe_k_data_tab, SOE_PROP_TAB_SOC_LENGTH, index_length_3d, coord_3d)) / SOE_CALC_PRE;

	if (SOX_FAIL == k)
	{
        return SOX_FAIL;
	}
	else
	{
		return k;
	}
}

/**
* @brief		计算SOE计算值
 * @param[in]	无
 * @return		计算成功，SOE的比例系数；计算失败，SOX_FAIL
 * @note
*/
static int8_t soe_calc(void)
{
    g_soe_calc_para.soe_prop = soe_prop_search(g_soe_input_data.pack_soc,
		g_soe_input_data.sys_cur_fil,g_soe_input_data.avg_cell_temp);

    if (SOX_FAIL == g_soe_calc_para.soe_prop)
    {
        g_soe_val.soe_calc = g_soe_val.soe_calc;
        return SOX_FAIL;
    }
    else
    {
        g_soe_val.soe_calc = g_soe_calc_para.soe_prop * g_soe_input_data.pack_soc;
        return SOX_OK;
    }
}

/**
* @brief		电流一阶滤波
 * @param[in]	无
 * @return		无
 * @note
*/
static void cur_first_filter(void)
{
    g_soe_input_data.sys_cur_fil = g_soe_input_data.sys_cur_fil * SOE_FIL_COFF
		+ (float)(g_soe_input_data.sys_cur * (1-SOE_FIL_COFF));
}

/**
* @brief		更新SOE显示值
 * @param[in]	无
 * @return		无
 * @note
*/
static void soe_disp_update(void)
{
	//每10秒最多变化1%
	if (++g_soe_calc_para.display_cnt >= SOE_DISPLAY_TIME_LIMIT)
	{
		//如果电流 > -150mA，SOC计算值可以上升，稍微下降了SOC上升的限制
		if ((g_soe_val.soe_calc +THOUTHAND_ROUND_OFF)/FRAC_PRE > g_soe_val.soe_display)
		{
			if (g_soe_input_data.sys_cur >= SOE_DISPLAY_CUR_UNDER_LIMIT)
			{
				g_soe_val.soe_display = g_soe_val.soe_display + 1;
				g_soe_calc_para.display_cnt = 0;
			}
		}
		//如果电流 < 300mA，SOC计算值就可以下降，稍微放宽了SOC下降的限制
		else if ((g_soe_val.soe_calc + THOUTHAND_ROUND_OFF)/FRAC_PRE < g_soe_val.soe_display)
		{
			if (g_soe_input_data.sys_cur <= SOE_DISPLAY_CUR_UPPER_LIMIT)
			{
				g_soe_val.soe_display = g_soe_val.soe_display - 1;
				g_soe_calc_para.display_cnt = 0;
			}
		}
	}
}

/**
* @brief		SOE计算所需要的数据、判断条件刷新
 * @param[in]	无
 * @return		无
 * @note
*/
static void soe_calc_input_refresh(void)
{
	//获取采样数据
	sox_sample_data_get(&g_sox_sample_data);

    //更新SOE输入数据
    //电流精度：0.001mA
    //温度精度：1℃
    //SOC精度：0.001%
    g_soe_input_data.sys_cur = g_sox_sample_data.sys_cur;
    g_soe_input_data.avg_cell_temp = g_sox_sample_data.avg_cell_temp;
    g_soe_input_data.pack_soc = g_soe_inf.calc_soc_get();
}

/**
* @brief		SOE比例系数保存
 * @param[in]	无
 * @return		无
 * @note
*/
static void soe_save(void)
{
	//如果SOE变化超过5%，则保存SOE比例系数
	//保存SOE没有用，因为SOE只是一个乘积结果
	if (((g_soe_val.soe_calc - g_soe_val.soe_save) > 5000)
	|| ((g_soe_val.soe_save - g_soe_val.soe_calc) > 5000))
	{
		gp_sox_running_data = g_soe_inf.sox_running_data_addr_get();
		gp_sox_running_data->soe_prop = g_soe_calc_para.soe_prop;

		g_soe_val.soe_save = g_soe_val.soe_calc;
		g_soe_inf.soe_save(g_soe_calc_para.soe_prop);
	}
}

/**
* @brief		SOE线程
 * @param[in]	无
 * @return		执行成功，SOX_OK；执行失败，SOX_FAIL
 * @note
*/
int8_t soe_proc(void)
{
	int8_t ret = SOX_OK;

	//SOE条件刷新，温度、电流、SOC
    soe_calc_input_refresh();

    //初始化SOE系数，只会进行一次初始化
    soe_params_init();

    //SOE电流滤波
    cur_first_filter();

    //SOE计算
    soe_calc();

    //SOE显示值更新
    soe_disp_update();

	soe_save();

	return ret;
}

/**
 * @brief		SOE静态变量重置
 * @param[in]	无
 * @return		无
 * @note
*/
void soe_reset(void)
{
	memset(&g_soe_val,0,sizeof(soe_val_t));
	memset(&g_soe_calc_para,0,sizeof(soe_calc_para_t));
	memset(&g_soe_input_data,0,sizeof(soe_input_data_t));

	gp_sox_running_data = NULL;

	memset(&g_soe_flags,0,sizeof(soe_flag_t));
	memset(&g_sox_sample_data,0,sizeof(sox_sample_data_t));
}

static void sox_3d_calc_test(int32_t x_value, int32_t y_value, int32_t z_value)
{
	float temp = 0;
	temp = soe_prop_search(x_value, y_value, z_value);
	log_d("3d_value = %.3f...\n", temp);
}
/**
 * @brief        sox功能样例
 * @param        cmd 功能参数
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
static int soe(int argc, char *argv[])
{
	if (!strcmp(argv[1], "calc"))
	{
		uint8_t calc_mode = atoi(argv[2]); // 1:一维计算 2：二维计算 3：三位计算
		int32_t x_value = atoi(argv[3]);   // x
		int32_t y_value = atoi(argv[4]);   // y
		int32_t z_value = atoi(argv[5]);   // z

		if (calc_mode == 3)
		{
			sox_3d_calc_test(x_value, y_value, z_value);
		}
	}

	return 0;
}
MSH_CMD_EXPORT(soe, <print / calc>);
