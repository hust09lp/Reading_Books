#include "sox_math.h"
#include "sox_public.h"
#include <stdbool.h>
#include <stdlib.h>

/**
 * @brief		返回数组的最大值
 * @param[in]	p_array，要判断的数组
 * @param[in]	length，数组的长度
 * @return		返回最大值
 * @warning		无
 * @pre
 * @note
*/
int32_t max_array(int32_t * p_array, int32_t length)
{
	int32_t retval = 0;
	int32_t temp_max = 0;

	if (NULL == p_array)
	{
		return SOX_FAIL;
	}

	temp_max = p_array[0];
	for (int32_t i = 0; i < length; i++)
	{
		if (temp_max >= p_array[i])
		{
			;
		}
		else
		{
			temp_max = p_array[i];
		}
	}

	retval = temp_max;
	return retval;
}

/**
 * @brief		返回数组的最小值
 * @param[in]	p_array，要判断的数组
 * @param[in]	length，数组的长度
 * @return		返回最小值
 * @warning		无
 * @pre
 * @note
*/
int32_t min_array(int32_t * p_array, int32_t length)
{
	int32_t retval = 0;
	int32_t temp_min = 0;

	if (NULL == p_array)
	{
		return SOX_FAIL;
	}

	temp_min = p_array[0];
	for (int32_t i = 0; i < length; i++)
	{
		if (temp_min <= p_array[i])
		{
			;
		}
		else
		{
			temp_min = p_array[i];
		}
	}

	retval = temp_min;
	return retval;
}

/**
 * @brief		返回数组的最大值及索引
 * @param[in]	p_array，要判断的数组
 * @param[in]	length，数组的长度
 * @param[in]	p_index，最大值的索引
 * @return		返回最大值
 * @warning		无
 * @pre
 * @note
*/
int32_t max_array_and_index(int32_t * p_array, int32_t length, int32_t* p_index)
{
	int32_t retval = 0;
	int32_t temp_max = 0;
	*p_index = 0;

	if (NULL == p_array)
	{
		return SOX_FAIL;
	}

	temp_max = p_array[0];
	for (int32_t i = 0; i < length; i++)
	{
		if (temp_max >= p_array[i])
		{
			;
		}
		else
		{
			temp_max = p_array[i];
			*p_index = i;
		}
	}

	retval = temp_max;
	return retval;
}

/**
 * @brief		返回数组的最小值及索引
 * @param[in]	p_array，要判断的数组
 * @param[in]	length，数组的长度
 * @param[in]	p_index，最小值的索引
 * @return		返回最小值
 * @warning		无
 * @pre
 * @note
*/
int32_t min_array_and_index(int32_t * p_array, int32_t length, int32_t* p_index)
{
	int32_t retval = 0;
	int32_t temp_min = 0;
	*p_index = 0;

	if (NULL == p_array)
	{
		return SOX_FAIL;
	}

	temp_min = p_array[0];
	for (int32_t i = 0; i < length; i++)
	{
		if (temp_min <= p_array[i])
		{
			;
		}
		else
		{
			temp_min = p_array[i];
			*p_index = i;
		}
	}

	retval = temp_min;
	return retval;
}

/**
 * @brief		返回两个数中的最大值
 * @param[in]	num_1 第一个数
 * @param[in]	num_2 第二个数
 * @return		返回两个数中的最大值
 * @warning		无
 * @pre
 * @note
*/
int32_t max_two_nums(int32_t num_1, int32_t num_2)
{
	int32_t retval = 0;

	if (num_1 > num_2)
	{
		retval = num_1;
	}
	else
	{
		retval = num_2;
	}

	return retval;
}

/**
 * @brief		返回两个数中的最小值
 * @param[in]	num_1 第一个数
 * @param[in]	num_2 第二个数
 * @return		返回两个数中的最小值
 * @warning		无
 * @pre
 * @note
*/
int32_t min_two_nums(int32_t num_1, int32_t num_2)
{
	int32_t retval = 0;

	if (num_1 < num_2)
	{
		retval = num_1;
	}
	else
	{
		retval = num_2;
	}

	return retval;
}
// 二分查找
int32_t binary_search(int32_t *p_index_tab, int32_t index_length, int32_t x)
{
	int32_t left = 0;
	int32_t right = index_length - 1;

	while (left <= right)
	{
		int32_t mid = left + (right - left) / 2;

		if (p_index_tab[mid] == x)
		{
			return mid;
		}
		else if (p_index_tab[mid] < x)
		{
			left = mid + 1;
		}
		else
		{
			right = mid - 1;
		}
	}

	return left > 0 ? left - 1 : 0;
}
// 插值计算
int32_t interpolate(int32_t *p_index_tab, int32_t *p_data_tab, int32_t index, int32_t x)
{
	int32_t diff_data = p_data_tab[index + 1] - p_data_tab[index];
	int32_t diff_index = p_index_tab[index + 1] - p_index_tab[index];
	uint32_t abs_diff_data = (uint32_t)abs(diff_data);
	int32_t ratio;

	if (abs_diff_data > (uint32_t)(0x7FFFFFFF / 1000))
	{
		return 0x7FFFFFFF;
	}

	if (abs_diff_data <= (uint32_t)(0x7FFFFFFF / 1000000))
	{
		ratio = 1000 * 1000 * diff_data / diff_index;
		return (p_data_tab[index] * 1000 + ratio * (x - p_index_tab[index]) / 1000) / 1000;
	}
	else
	{
		ratio = 1000 * diff_data / diff_index;
		return p_data_tab[index] + ratio * (x - p_index_tab[index]) / 1000;
	}
}
// 一维插值
int32_t sox_interp_1d(int32_t *p_index_tab, int32_t *p_data_tab, int32_t index_length, int32_t x)
{
	if (p_index_tab == NULL || p_data_tab == NULL)
	{
		return 0x7FFFFFFF;
	}

	if (x <= p_index_tab[0])
	{
		return p_data_tab[0];
	}
	if (x >= p_index_tab[index_length - 1])
	{
		return p_data_tab[index_length - 1];
	}

	int32_t index = binary_search(p_index_tab, index_length, x);
	if (p_index_tab[index] == x)
	{
		return p_data_tab[index];
	}

	return interpolate(p_index_tab, p_data_tab, index, x);
}

/**
* @brief		二维插值
 * @param[in]	p_index_tab 索引表地址
 * @param[in]	p_data_tab 数据表地址
 * @param[in]	index_length 各维长度
 * @param[in]	coord_2d 插值的坐标
 * @return		插值结果
 * @warning		无
 * @pre
 * @note
*/
int32_t sox_interp_2d(int32_t* p_index_tab, int32_t* p_data_tab, uint8_t index_table_col, index_length_2d_t index_length, coord_2d_t coord_2d)
{
    int32_t retval = 0;
    int32_t interp_val_1d[INTERP_AXIS_MAX_LEN];
    int32_t i = 0;

    if ((NULL == p_index_tab) || (NULL == p_data_tab))
    {
        return SOX_FAIL;
    }

    //根据二维表的横坐标，对每一行进行查表插值，得到插值后的一维数组
    for (i = 0; i < index_length.y; i++)
    {
        interp_val_1d[i] = sox_interp_1d((int32_t *)(p_index_tab + 0),
                            (int32_t *)(p_data_tab + i*index_length.x), index_length.x, coord_2d.x);
    }

    //根据二维表的纵坐标，对插值后得到的一维数据进行插值，得到目标数值
    retval = sox_interp_1d((int32_t *)(p_index_tab + index_table_col), interp_val_1d, index_length.y, coord_2d.y);
    return retval;
}

/**
* @brief		三维插值
 * @param[in]	p_index_tab 索引表地址
 * @param[in]	p_data_tab 数据表地址
 * @param[in]	index_length 各维长度
 * @param[in]	coord_3d 插值的坐标
 * @return		插值结果
 * @warning		无
 * @pre
 * @note
*/
int32_t sox_interp_3d(int32_t* p_index_tab, int32_t* p_data_tab, uint8_t index_table_col, index_length_3d_t index_length, coord_3d_t coord_3d)
{
    int32_t retval = 0;
    int32_t interp_val_2d[INTERP_AXIS_MAX_LEN];
    index_length_2d_t index_length_2d = {index_length.x, index_length.y};
    coord_2d_t coord_2d = {coord_3d.x, coord_3d.y};
    int32_t i = 0;

    if ((NULL == p_index_tab) || (NULL == p_data_tab) || (index_length.z > INTERP_AXIS_MAX_LEN))
    {
        return SOX_FAIL;
    }

    for (i = 0; i < index_length.z; i++)
    {
        interp_val_2d[i] = sox_interp_2d(p_index_tab, p_data_tab + i * (index_length.y * index_length.x), index_table_col, index_length_2d, coord_2d);
    }

    retval = sox_interp_1d((int32_t *)(p_index_tab + 2 * index_table_col), interp_val_2d, index_length.z, coord_3d.z);

    return retval;
}

/**
* @brief		超时判断
 * @param[in]	current_time 当前时间
 * @param[in]	record_time 记录时间
 * @param[in]	diff 判断为超时的时间间隔
 * @return		SOC_OK，超时，SOC_FAIL，没有超时
 * @note
*/
int32_t sox_time_is_over(uint32_t current_time, uint32_t record_time, uint32_t diff)
{
	int32_t retval = SOX_OK;
	uint32_t current_interval = 0;

	if (current_time >= record_time)
	{
		current_interval = current_time - record_time;
	}
	else
	{
		current_interval = 0xFFFFFFFF - record_time + current_time + 1;
	}

	if (current_interval >= diff)
	{
		retval = SOX_OK;
	}
	else
	{
		retval = SOX_FAIL;
	}

	return retval;
}

/**
* @brief		搜索数组中两个索引之间的数值，btn->between two numbers
 * @param[in]	current_time 当前时间
 * @param[in]	record_time 记录时间
* @param[in]	diff 判断为超时的时间间隔
 * @return		SOC_OK，超时，SOC_FAIL，没有超时
 * @retval		SOC_OK，超时
 * @retval		SOC_FAIL，没有超时
 * @warning		无
 * @pre
 * @note		表的索引顺序从大到小，表的长度要大于等于2
*/
int32_t sox_scout_val_btn(int32_t* p_index, int32_t* p_data, int32_t length, int32_t x)
{
	int32_t retval = 0;
	int32_t i = 0;

	if ((NULL == p_index) || (NULL == p_data))
	{
		return SOX_FAIL;
	}

	if (x >= p_index[0])
	{
		retval = p_data[0];
		return retval;
	}
	else if (x <= p_index[length - 1])
	{
		retval = p_data[length - 2];
		return retval;
	}

	for (i = 1; i < length; i++)
	{
		if ((x >= p_index[i]) && (x <= p_index[i - 1]))
		{
			retval = p_data[i - 1];
			return retval;
		}
		else
		{
			;
		}
	}

	return retval;
}
