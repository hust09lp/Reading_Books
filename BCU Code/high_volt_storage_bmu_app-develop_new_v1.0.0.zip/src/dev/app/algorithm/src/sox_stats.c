/**
 * @file         sox_stats.c
 * @brief        电池包级别的SOX统计数据计算
 * @details      电池包级别的SOX统计数据计算
 * @author       zhangzhichao
 * @date         2024/11/06
 * @version      V0.0.1
 * @attention 传入电流精度为--1mA
 * @attention 传入模组总压精度为--1mV
 * @attention 传入Tick精度为--1ms
 * @attention 传出充电Ah、mAs、Wh、mWs，精度为--1Ah、1mAs、1Wh、1mWs
 * @copyright    Copyright(c) 2024 by SofarSolar, All Rights Reserved.
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author              <th>Description
 * <tr><td>2024/11/06  <td>0.0.1    <td>zhangzhichao       <td>优化内容，详见git上的更改点
 *
 * </table>
 *
 **********************************************************************************
 */

#include "sox_stats.h"
#include "soc.h"
#include "soh.h"
#include "sox_sample.h"


/*****************************************************************************/
/*************************SOX统计数据模块--结构体定义***************************/
/*****************************************************************************/

/**
  * @enum   sox_stats_flag_u
  * @brief  SOX统计模块--标志位定义
  */
typedef union
{
	uint16_t sox_stats_all_flags;
	struct
	{
		uint16_t proc_init : 1;			///< 进程初始化
		uint16_t data_init : 1;			///< 数据初始化
		uint16_t calc_irupt : 1;		///< 计算中出现问题，停止计算
		uint16_t sample_over_limit : 1;	///< 采样数据超出范围
		uint16_t save : 1;				///< 保存
	}bit;
}sox_stats_flag_u;


/*****************************************************************************/
/********************SOX统计数据模块--全局变量定义及初始化***********************/
/*****************************************************************************/

//SOX统计模块--标志位
static sox_stats_flag_u g_sox_stats_flag = {
	.bit.proc_init = false,				//进程初始化，默认为false
	.bit.data_init = false,				//数据初始化，默认为false
	.bit.calc_irupt = true,				//计算中出现问题，停止计算，默认为true，即默认上电时的数据不可信
	.bit.sample_over_limit = false,		//采样数据超出范围，默认为false
	.bit.save = false,					//保存，默认为false
};

//累计充放电mAs、mWs
static uint64_t g_total_chg_mA_s = 0;
static uint64_t g_total_chg_mW_s = 0;
static uint64_t g_total_dsg_mA_s = 0;
static uint64_t g_total_dsg_mW_s = 0;

//累计充放电Ah、Wh
static uint32_t g_total_dsg_ah_last = 0;
static uint32_t g_total_chg_ah_last = 0;

static uint32_t g_total_dsg_ah = 0;
static uint32_t g_total_chg_ah = 0;
static uint32_t g_total_dsg_wh = 0;
static uint32_t g_total_chg_wh = 0;
static uint32_t g_total_display_cycle = 0;  //精度：0.01圈


//上一次计算统计数据时的系统tick
static uint32_t g_last_calc_tick = 0;

//SOX运行数据
static sox_running_data_t* gp_sox_running_data = NULL;

//SOX统计数据接口
static sox_interface_remap_t g_sox_interface_remap = {0};




/*****************************************************************************/
/*************************SOX统计数据模块--函数实现*****************************/
/*****************************************************************************/


/**
 * @brief		sox统计数据--线程初始化
 * @param[in]	sox_interface_remap，SOX统计数据接口，方向为：外部向统计模块传输
 * @return		SOX_OK，执行成功；SOX_FAIL，失败
 * @note		如果接口传输失败，SOX统计模块将无法正常工作
*/
int8_t sox_stats_proc_init(sox_interface_remap_t sox_interface_remap)
{
	if (false == g_sox_stats_flag.bit.proc_init)
	{
		//SOX统计模块只需要获取系统参数、系统tick
		if ((NULL == sox_interface_remap.sox_limit_params_get)
			|| (NULL == sox_interface_remap.sox_tick_get)
			|| (NULL == sox_interface_remap.sox_running_data_addr_get))
		{
			g_sox_stats_flag.bit.proc_init = false;
			return SOX_FAIL;
		}
		else
		{
			g_sox_interface_remap = sox_interface_remap;
			g_sox_stats_flag.bit.proc_init = true;
			return SOX_OK;
		}
	}

	return SOX_OK;
}

/**
 * @brief		SOX统计数据--模块数据初始化
 * @param[in]	无
 * @return		SOX_OK，执行成功，SOX_FAIL，失败
 * @note
*/
static int8_t sox_stats_data_init(void)
{
	int8_t ret = SOX_OK;

    if ((false == g_sox_stats_flag.bit.data_init)
	&& (true == g_sox_stats_flag.bit.proc_init))
    {
        //这里注意：所有SOX共用运行SOC里面的运行数据
        gp_sox_running_data = g_sox_interface_remap.sox_running_data_addr_get();

        //读取累计充放电Ah
        g_total_dsg_ah = gp_sox_running_data->total_dsg_ah;
        g_total_chg_ah = gp_sox_running_data->total_chg_ah;

        g_total_dsg_ah_last = gp_sox_running_data->total_dsg_ah;
        g_total_chg_ah_last = gp_sox_running_data->total_chg_ah;

        //读取累计充放电Wh
        g_total_dsg_wh = gp_sox_running_data->total_dsg_wh;
        g_total_chg_wh = gp_sox_running_data->total_chg_wh;

        //读取累计充放电mAs、mWs
        g_total_dsg_mA_s = gp_sox_running_data->total_dsg_mA_s;
        g_total_chg_mA_s = gp_sox_running_data->total_chg_mA_s;

		g_total_dsg_mW_s = gp_sox_running_data->total_dsg_mW_s;
		g_total_chg_mW_s = gp_sox_running_data->total_chg_mW_s;
        
        g_total_display_cycle = gp_sox_running_data->display_cycle_turns;

        //SOX统计数据初始化完成
		g_last_calc_tick = g_sox_interface_remap.sox_tick_get();
        g_sox_stats_flag.bit.data_init = true;

		ret = SOX_OK;
    }
	else if(false == g_sox_stats_flag.bit.proc_init)
    {
        ret = SOX_FAIL;
    }

	return ret;
}

/**
 * @brief		判断采样值是否超出边界
 * @param[in]	sample_data，传入的采样数据；
 * @return		SOX_OK，不超出边界；SOX_FAIL，超出边界
 * @note
*/
static int8_t sox_stats_sample_over_judge(sox_sample_data_t sample_data)
{
	int8_t temp = SOX_OK;

	//系统采样电流范围：[-420A，420A]
	if (sample_data.sys_cur < SOX_SAMPLE_LOWER_CUR)
	{
		temp = SOX_FAIL;
		sample_data.sys_cur = SOX_SAMPLE_LOWER_CUR;
	}
	else if (sample_data.sys_cur > SOX_SAMPLE_UPPER_CUR)
	{
		temp = SOX_FAIL;
		sample_data.sys_cur = SOX_SAMPLE_UPPER_CUR;
	}

	//PACK总压范围：[115.2V，192V]
	if (sample_data.pack_volt < SOX_SAMPLE_LOWER_PACK_VOLT)
	{
		temp = SOX_FAIL;
		sample_data.pack_volt = SOX_SAMPLE_LOWER_PACK_VOLT;
	}
	else if (sample_data.pack_volt > SOX_SAMPLE_UPPER_PACK_VOLT)
	{
		temp = SOX_FAIL;
		sample_data.pack_volt = SOX_SAMPLE_UPPER_PACK_VOLT;
	}

	//最小电芯电压范围：[2400mV，4000mV]
	if (sample_data.min_cell_volt < SOX_SAMPLE_LOWER_MIN_CELL_VOLT)
	{
		temp = SOX_FAIL;
		sample_data.min_cell_volt = SOX_SAMPLE_LOWER_MIN_CELL_VOLT;
	}
	else if (sample_data.min_cell_volt > SOX_SAMPLE_UPPER_MIN_CELL_VOLT)
	{
		temp = SOX_FAIL;
		sample_data.min_cell_volt = SOX_SAMPLE_UPPER_MIN_CELL_VOLT;
	}

	//最小电芯温度范围：[-40℃，65℃]
	if (sample_data.min_cell_temp < SOX_SAMPLE_LOWER_MIN_CELL_TEMP)
	{
		temp = SOX_FAIL;
		sample_data.min_cell_temp = SOX_SAMPLE_LOWER_MIN_CELL_TEMP;
	}
	else if (sample_data.min_cell_temp > SOX_SAMPLE_UPPER_MIN_CELL_TEMP)
	{
		temp = SOX_FAIL;
		sample_data.min_cell_temp = SOX_SAMPLE_UPPER_MIN_CELL_TEMP;
	}

	//最大电芯电压范围：[2400mV，4000mV]
	if (sample_data.max_cell_volt < SOX_SAMPLE_LOWER_MAX_CELL_VOLT)
	{
		temp = SOX_FAIL;
		sample_data.max_cell_volt = SOX_SAMPLE_LOWER_MAX_CELL_VOLT;
	}
	else if (sample_data.max_cell_volt > SOX_SAMPLE_UPPER_MAX_CELL_VOLT)
	{
		temp = SOX_FAIL;
		sample_data.max_cell_volt = SOX_SAMPLE_UPPER_MAX_CELL_VOLT;
	}

	//平均电芯电压范围：[2400mV，4000mV]
	if (sample_data.avg_cell_volt < SOX_SAMPLE_LOWER_AVG_CELL_VOLT)
	{
		temp = SOX_FAIL;
		sample_data.avg_cell_volt = SOX_SAMPLE_LOWER_AVG_CELL_VOLT;
	}
	else if (sample_data.avg_cell_volt > SOX_SAMPLE_UPPER_AVG_CELL_VOLT)
	{
		temp = SOX_FAIL;
		sample_data.avg_cell_volt = SOX_SAMPLE_UPPER_AVG_CELL_VOLT;
	}

	//平均电芯温度范围：[-40℃，65℃]
	if (sample_data.avg_cell_temp < SOX_SAMPLE_LOWER_AVG_CELL_TEMP)
	{
		temp = SOX_FAIL;
		sample_data.avg_cell_temp = SOX_SAMPLE_LOWER_AVG_CELL_TEMP;
	}
	else if (sample_data.avg_cell_temp > SOX_SAMPLE_UPPER_AVG_CELL_TEMP)
	{
		temp = SOX_FAIL;
		sample_data.avg_cell_temp = SOX_SAMPLE_UPPER_AVG_CELL_TEMP;
	}

	return temp;
}

/**
 * @brief		SOX统计数据模块--SOX统计数据保存判断
 * @param[in]	无
 * @return		SOX_OK，执行成功；SOX_FAIL，失败
 * @note
*/
static int8_t sox_save(void)
{
	int8_t ret = SOX_OK;

	//更新累计充放电Ah、Wh，该数据提供给其它模块使用
	//12000 * 100Ah = 12000 * 100 * 1000 * 3600 mAs
	//先除3600 ，12000圈的mAh变为12000 * 100 *1000 = 4786 8C00，不会溢出
	g_total_chg_ah = (uint32_t)((g_total_chg_mA_s/HOUR_TO_SEC + THOUTHAND_ROUND_OFF)/FRAC_PRE);
	g_total_chg_wh = (uint32_t)((g_total_chg_mW_s/HOUR_TO_SEC + THOUTHAND_ROUND_OFF)/FRAC_PRE);

	g_total_dsg_ah = (uint32_t)((g_total_dsg_mA_s/HOUR_TO_SEC + THOUTHAND_ROUND_OFF)/FRAC_PRE);
	g_total_dsg_wh = (uint32_t)((g_total_dsg_mW_s/HOUR_TO_SEC + THOUTHAND_ROUND_OFF)/FRAC_PRE);
    
    g_total_display_cycle = g_total_chg_ah * 100 / DEFAULTED_RATED_CAP; //精度：0.01圈

    //更新运行数据
    gp_sox_running_data->total_chg_ah = g_total_chg_ah;
    gp_sox_running_data->total_chg_wh = g_total_chg_wh;

    gp_sox_running_data->total_dsg_ah = g_total_dsg_ah;
    gp_sox_running_data->total_dsg_wh = g_total_dsg_wh;

    gp_sox_running_data->total_chg_mA_s = g_total_chg_mA_s;
    gp_sox_running_data->total_chg_mW_s = g_total_chg_mW_s;

    gp_sox_running_data->total_dsg_mA_s = g_total_dsg_mA_s;
    gp_sox_running_data->total_dsg_mW_s = g_total_dsg_mW_s;

	//累计充、放电Ah超过5Ah，就会保存一次
    if (g_total_chg_ah - g_total_chg_ah_last> AH_REFRESH)
    {
        gp_sox_running_data->total_chg_ah = g_total_chg_ah;
        gp_sox_running_data->total_chg_wh = g_total_chg_wh;

        gp_sox_running_data->total_chg_mA_s = g_total_chg_mA_s;
        gp_sox_running_data->total_chg_mW_s = g_total_chg_mW_s;

        g_total_chg_ah_last = g_total_chg_ah;
        g_sox_stats_flag.bit.save = true;
    }

    if (g_total_dsg_ah - g_total_dsg_ah_last > AH_REFRESH)
    {
        gp_sox_running_data->total_dsg_ah = g_total_dsg_ah;
        gp_sox_running_data->total_dsg_wh = g_total_dsg_wh;

        gp_sox_running_data->total_dsg_mA_s = g_total_dsg_mA_s;
        gp_sox_running_data->total_dsg_mW_s = g_total_dsg_mW_s;

        g_total_dsg_ah_last = g_total_dsg_ah;
        g_sox_stats_flag.bit.save = true;
    }

	return ret;
}

/**
 * @brief		SOX统计数据模块--主线程
 * @param[in]	无
 * @return		SOX_OK，执行成功；SOX_FAIL，失败
 * @note
*/
int8_t sox_stats_proc(void)
{
    int8_t retval = SOX_OK;

	//采样数据用，判断采样数据是否超范围、采样数据是否获取到
    int8_t sample_over_judge = SOX_FAIL;
	int8_t temp = SOX_FAIL;
	sox_sample_data_t sox_sample_data = {0};

	//计算Ah、Wh用，采用局部量，防止代码过长
    int32_t cur = 0;
	uint32_t pack_volt_mV = 0;

    //两次统计值之间的时间间隔
	uint32_t current_calc_tick = 0;

	//获取SOX采样数据，如果获取失败，函数直接结束，不进行SOX统计数据的计算
	temp = sox_sample_data_get(&sox_sample_data);

	if (SOX_FAIL == temp)
	{
		retval = SOX_FAIL;
		g_sox_stats_flag.bit.calc_irupt = true;
		return retval;
	}

	//判断采样值是否超出边界，如果超出边界，则直接结束，不进行SOX统计数据的计算
	sample_over_judge = sox_stats_sample_over_judge(sox_sample_data);

	if(SOX_FAIL == sample_over_judge)
	{
		retval = SOX_FAIL;
		g_sox_stats_flag.bit.calc_irupt = true;
		return retval;
	}

    //如果SOX采样数据获取成功且数据没有超出边界，则进行SOX统计数据的计算
	current_calc_tick = g_sox_interface_remap.sox_tick_get();
    cur = sox_sample_data.sys_cur;
    pack_volt_mV = (uint32_t)sox_sample_data.pack_volt;

	//如果SOX统计数据没有初始化、或者采样数据存在问题，均不进行统计数据计算
    if (false == g_sox_stats_flag.bit.data_init)
    {
        sox_stats_data_init();
    }
    else if (true == g_sox_stats_flag.bit.calc_irupt)
    {
		g_last_calc_tick = current_calc_tick;
        g_sox_stats_flag.bit.calc_irupt = false;
	}
	else
	{
		//电池电流在损耗电流以内，按照产品标准损耗电流来计算
		if (abs(cur) <= LOSS_CUR_UPPER_LIMIT)
		{
			cur = LOSS_CUR;
		}

		if (cur > 0)
		{
			if (current_calc_tick > g_last_calc_tick)
			{
				//注意这个地方会产生BUG，mAs保存的数值非常大，接近类型保存上限
				//所以不能先乘，要先除，才能之后赋值给Ah
				g_total_chg_mA_s += (uint64_t)abs(cur)*(uint64_t)(current_calc_tick - g_last_calc_tick)/FRAC_PRE;

				g_total_chg_mW_s +=
					(uint64_t)abs(cur)*(uint64_t)pack_volt_mV*(uint64_t)(current_calc_tick - g_last_calc_tick)/FRAC_PRE/FRAC_PRE;
			}
			else if (current_calc_tick < g_last_calc_tick)
			{
				g_total_chg_mA_s += (uint64_t)(abs(cur)*(0xFFFFFFFF - g_last_calc_tick + current_calc_tick + 1))/FRAC_PRE;

				g_total_chg_mW_s +=
					(uint64_t)(abs(cur)*pack_volt_mV*(0xFFFFFFFF - g_last_calc_tick + current_calc_tick + 1))/FRAC_PRE/FRAC_PRE;
			}
		}
		else if (cur < 0)
		{
			if (current_calc_tick > g_last_calc_tick)
			{
				g_total_dsg_mA_s += (uint64_t)abs(cur)*(uint64_t)(current_calc_tick - g_last_calc_tick)/FRAC_PRE;

				g_total_dsg_mW_s +=
					(uint64_t)abs(cur)*(uint64_t)pack_volt_mV*(uint64_t)(current_calc_tick - g_last_calc_tick)/FRAC_PRE/FRAC_PRE;
			}
			else if (current_calc_tick < g_last_calc_tick)
			{
				g_total_dsg_mA_s += (uint64_t)abs(cur)*(uint64_t)(0xFFFFFFFF - g_last_calc_tick + current_calc_tick + 1)/FRAC_PRE;

				g_total_dsg_mW_s +=
					(uint64_t)abs(cur)*(uint64_t)pack_volt_mV*(uint64_t)(0xFFFFFFFF - g_last_calc_tick + current_calc_tick + 1)/FRAC_PRE/FRAC_PRE;
			}
		}

		g_last_calc_tick = current_calc_tick;
	}

	//判断是否需要保存运行数据
	sox_save();

    return retval;
}


/**
 * @brief		获取累计充放电容量
 * @param[in]	p_dout，该入参指针用于获取SOX统计数据
 * @return		SOX_OK，执行成功；SOX_FAIL，失败
 * @note
*/
int8_t sox_stats_get(sox_stats_t* p_dout)
{
	int8_t retval = SOX_OK;

	if (NULL == p_dout)
	{
		return SOX_FAIL;
	}

	p_dout->sumed_chg_ah = g_total_chg_ah;
	p_dout->sumed_dsg_ah = g_total_dsg_ah;

	p_dout->sumed_chg_wh = g_total_chg_wh;
	p_dout->sumed_dsg_wh = g_total_dsg_wh;

	p_dout->sumed_chg_mA_s = g_total_chg_mA_s;
	p_dout->sumed_dsg_mA_s = g_total_dsg_mA_s;

	p_dout->sumed_chg_mW_s = g_total_chg_mW_s;
	p_dout->sumed_dsg_mW_s = g_total_dsg_mW_s;
    
    p_dout->sumed_display_cycle = g_total_display_cycle;

	return retval;
}

/**
 * @brief		设置累计充电Ah
 * @param[in]	d_in，需要设置的累计充电容量
 * @return		SOX_OK，执行成功；SOX_FAIL，失败
 * @note
*/
int8_t sox_stats_chg_ah_set(int32_t d_in)
{
	int8_t retval = SOX_OK;

    gp_sox_running_data = g_sox_interface_remap.sox_running_data_addr_get();

	if (d_in >= 0)
	{
		g_total_chg_ah = d_in;
		g_total_chg_mA_s = (uint64_t)d_in * HOUR_TO_SEC * FRAC_PRE;
	}
	else
	{
		g_total_chg_ah = 0;
		g_total_chg_mA_s = (uint64_t)d_in * HOUR_TO_SEC * FRAC_PRE;
	}

    gp_sox_running_data->total_chg_ah = g_total_chg_ah;
    gp_sox_running_data->total_chg_mA_s = g_total_chg_mA_s;

	//在设置Ah时，Wh也需要保持一致
	g_total_chg_wh = g_total_chg_ah * RATED_PACK_VOLT / FRAC_PRE;
	g_total_chg_mW_s = (uint64_t)g_total_chg_wh * HOUR_TO_SEC * FRAC_PRE;

    gp_sox_running_data->total_chg_wh = g_total_chg_wh;
    gp_sox_running_data->total_chg_mW_s = g_total_chg_mW_s;

	return retval;
}

/**
* @brief		设置累计放电Ah
 * @param[in]	d_in，需要设置的累计放电容量
 * @return		SOX_OK，执行成功；SOX_FAIL，失败
 * @note
*/
int8_t sox_stats_dsg_ah_set(int32_t d_in)
{
	int8_t retval = SOX_OK;

    gp_sox_running_data = g_sox_interface_remap.sox_running_data_addr_get();

	if (d_in >= 0)
	{
		g_total_dsg_ah = d_in;
		g_total_dsg_mA_s = (uint64_t)d_in * HOUR_TO_SEC * FRAC_PRE;
	}
	else
	{
		g_total_dsg_ah = 0;
		g_total_dsg_mA_s = (uint64_t)d_in * HOUR_TO_SEC * FRAC_PRE;
	}

    gp_sox_running_data->total_dsg_ah = g_total_dsg_ah;
    gp_sox_running_data->total_dsg_mA_s = g_total_dsg_mA_s;

	//在设置放电Ah时，放电Wh也需要保持一致
	g_total_dsg_wh = g_total_dsg_ah * RATED_PACK_VOLT / FRAC_PRE;
	g_total_dsg_mW_s = (uint64_t)g_total_dsg_wh * HOUR_TO_SEC * FRAC_PRE;

    gp_sox_running_data->total_dsg_wh = g_total_dsg_wh;
    gp_sox_running_data->total_dsg_mW_s = g_total_dsg_mW_s;

	return retval;
}

/**
 * @brief		设置累计充电Wh
 * @param[in]	d_in，需要设置的累计充电Wh
 * @return		SOX_OK，执行成功；SOX_FAIL，失败
 * @note
*/
int8_t sox_stats_chg_wh_set(int32_t d_in)
{
	int8_t retval = SOX_OK;

    gp_sox_running_data = g_sox_interface_remap.sox_running_data_addr_get();

	if (d_in >= 0)
	{
		g_total_chg_wh = d_in;
		g_total_chg_mW_s = (uint64_t)d_in * HOUR_TO_SEC * FRAC_PRE;
	}
	else
	{
		g_total_chg_wh = 0;
		g_total_chg_mW_s = (uint64_t)d_in * HOUR_TO_SEC * FRAC_PRE;
	}

    gp_sox_running_data->total_chg_wh = g_total_chg_wh;
    gp_sox_running_data->total_chg_mW_s = g_total_chg_mW_s;

	return retval;
}

/**
* @brief		设置累计放电Wh
 * @param[in]	d_in，需要设置的累计放电Wh
 * @return		SOX_OK，执行成功；SOX_FAIL，失败
 * @note
*/
int8_t sox_stats_dsg_wh_set(int32_t d_in)
{
	int8_t retval = SOX_OK;

    gp_sox_running_data = g_sox_interface_remap.sox_running_data_addr_get();

	if (d_in >= 0)
	{
		g_total_dsg_wh = d_in;		//设置放电Wh
		g_total_dsg_mW_s = (uint64_t)d_in * HOUR_TO_SEC * FRAC_PRE;
	}
	else
	{
		g_total_dsg_wh = 0;
		g_total_dsg_mW_s = (uint64_t)d_in * HOUR_TO_SEC * FRAC_PRE;
	}

    gp_sox_running_data->total_dsg_wh = g_total_dsg_wh;
    gp_sox_running_data->total_dsg_mW_s = g_total_dsg_mW_s;

	return retval;
}

/**
* @brief		获取真实Ah
 * @param[in]	无
 * @return		电池当前满充容量，单位Ah
 * @note
*/
int32_t sox_stats_real_cap_get(void)
{
	int32_t retval = 0;

	int32_t soh_temp = 0;
	limit_params_t limit_params = {0};
	g_sox_interface_remap.sox_limit_params_get(&limit_params);

	soh_temp = soh_pack_display_val_get();

	retval = limit_params.rated_cap * soh_temp/100;

	return retval;
}

/**
* @brief		获取剩余Ah
 * @param[in]	无
 * @return		剩余容量，单位Ah
 * @note
*/
int32_t sox_stats_remained_cap_get(void)
{
	int32_t retval = 0;

	int32_t soc_temp = 0;
	int32_t fullchg_cap_temp = 0;

	soc_temp = soc_pack_display_val_get();
	fullchg_cap_temp = sox_stats_real_cap_get();

	retval = fullchg_cap_temp * soc_temp/100;

	return retval;
}

/**
 * @brief		获取SOX统计数据保存标志位
 * @param[in]	无
 * @return		true，需要保存；false，不需要保存
 * @note
*/
uint16_t sox_stats_save_flag_get(void)
{
	uint16_t retval = false;

	retval = g_sox_stats_flag.bit.save;

	return retval;
}

/**
 * @brief		重置SOX统计数据保存标志位
 * @param[in]	无
 * @return		无
 * @note
*/
void sox_stats_save_flag_reset(void)
{
	g_sox_stats_flag.bit.save = false;
}

/**
 * @brief		获取SOX统计数据初始化标志位
 * @param[in]	无
 * @return		true，SOX统计数据完成初始化；false，SOX统计数据未完成初始化
 * @note
*/
uint16_t sox_stats_init_flag_get(void)
{
	uint16_t retval = false;

	retval = g_sox_stats_flag.bit.data_init;

	return retval;
}

/**
 * @brief		重置SOX_stats模块，除了定制化接口
 * @param[in]	无
 * @return		无
 * @note
*/
void sox_stats_reset(void)
{
	sox_stats_flag_u sox_stats_flag = {
		.bit.save = false,		//SOX统计数据保存标志位，默认为false
		.bit.data_init = false,		//SOX统计数据初始化标志位，默认为false
		.bit.calc_irupt = true,
		.bit.proc_init = true,
		.bit.sample_over_limit = false,
	};

	g_last_calc_tick = 0;

	g_sox_stats_flag = sox_stats_flag;

    gp_sox_running_data = NULL;

	g_total_dsg_ah_last = 0;
	g_total_chg_ah_last = 0;
	g_total_dsg_ah = 0;
	g_total_chg_ah = 0;

	g_total_dsg_wh = 0;
	g_total_chg_wh = 0;

	g_total_dsg_mW_s = 0;
	g_total_chg_mW_s = 0;
	g_total_dsg_mA_s = 0;
	g_total_chg_mA_s = 0;


}


