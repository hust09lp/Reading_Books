/**@file	sox_sample_deal.c
* @brief	项目模块文件
* @details	统计最近十次的采样数据，将平均值给SOX计算模块调用
* @author	张智超
* @date		2023-4-17
*/
#include "sox_sample.h"
#include "sox_public.h"
// #include "sdk.h"
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

static bool g_init_flag = false;			//上电后第一次获取采样数据
static const int8_t record_times = 10;  	//SOX数据的记录次数

//SOX采集数据数组，保存最近10次的采集数据
static sox_sample_data_t g_sample_stats[10] = {0};
static int32_t g_sample_stats_index = 0;			//SOX数据数组当前指向索引
static int16_t valid_data_length = 0;				//有效采样数据的长度

//外部函数调用sox_sample_data_set设置采样值，供SOX采样模块调用
static sox_sample_data_t g_sample_data_set = {0};

static sox_sample_deal_remap_t    g_sox_sample_deal_remap = {0}; // 外部定制化函数

static int32_t sox_sample_data_fill(sox_sample_data_t sample_data_temp, int32_t index);
static int32_t sox_sample_data_avg(sox_sample_data_t* sox_sample_data);


/**
 * @brief		判断采样值是否超出边界
 * @param[in]	sample_data，采样数据
 * @return		执行结果
 * @retval		true，采样数据超范围
 * @retval		false，采样数据没有超范围
 * @warning		无
 * @note
 * @pre			无
*/
static int32_t sox_sample_sample_over_judge(sox_sample_data_t sample_data)
{
	int32_t retval = false;

	//系统采样电流范围：[-420A，420A]
	if (sample_data.sys_cur < SOX_SAMPLE_LOWER_CUR)
	{
		retval = true;
		sample_data.sys_cur = SOX_SAMPLE_LOWER_CUR;
	}
	else if (sample_data.sys_cur > SOX_SAMPLE_UPPER_CUR)
	{
		retval = true;
		sample_data.sys_cur = SOX_SAMPLE_UPPER_CUR;
	}

	//PACK总压范围：[115.2V，192V]
	if (sample_data.pack_volt < SOX_SAMPLE_LOWER_PACK_VOLT)
	{
		retval = true;
		sample_data.pack_volt = SOX_SAMPLE_LOWER_PACK_VOLT;
	}
	else if (sample_data.pack_volt > SOX_SAMPLE_UPPER_PACK_VOLT)
	{
		retval = true;
		sample_data.pack_volt = SOX_SAMPLE_UPPER_PACK_VOLT;
	}

	//最小电芯电压范围：[2400mV，4000mV]
	if (sample_data.min_cell_volt < SOX_SAMPLE_LOWER_MIN_CELL_VOLT)
	{
		retval = true;
		sample_data.min_cell_volt = SOX_SAMPLE_LOWER_MIN_CELL_VOLT;
	}
	else if (sample_data.min_cell_volt > SOX_SAMPLE_UPPER_MIN_CELL_VOLT)
	{
		retval = true;
		sample_data.min_cell_volt = SOX_SAMPLE_UPPER_MIN_CELL_VOLT;
	}

	//最小电芯温度范围：[-40℃，65℃]
	if (sample_data.min_cell_temp < SOX_SAMPLE_LOWER_MIN_CELL_TEMP)
	{
		retval = true;
		sample_data.min_cell_temp = SOX_SAMPLE_LOWER_MIN_CELL_TEMP;
	}
	else if (sample_data.min_cell_temp > SOX_SAMPLE_UPPER_MIN_CELL_TEMP)
	{
		retval = true;
		sample_data.min_cell_temp = SOX_SAMPLE_UPPER_MIN_CELL_TEMP;
	}

	//最大电芯电压范围：[2400mV，4000mV]
	if (sample_data.max_cell_volt < SOX_SAMPLE_LOWER_MAX_CELL_VOLT)
	{
		retval = true;
		sample_data.max_cell_volt = SOX_SAMPLE_LOWER_MAX_CELL_VOLT;
	}
	else if (sample_data.max_cell_volt > SOX_SAMPLE_UPPER_MAX_CELL_VOLT)
	{
		retval = true;
		sample_data.max_cell_volt = SOX_SAMPLE_UPPER_MAX_CELL_VOLT;
	}

	//平均电芯电压范围：[2400mV，4000mV]
	if (sample_data.avg_cell_volt < SOX_SAMPLE_LOWER_AVG_CELL_VOLT)
	{
		retval = true;
		sample_data.avg_cell_volt = SOX_SAMPLE_LOWER_AVG_CELL_VOLT;
	}
	else if (sample_data.avg_cell_volt > SOX_SAMPLE_UPPER_AVG_CELL_VOLT)
	{
		retval = true;
		sample_data.avg_cell_volt = SOX_SAMPLE_UPPER_AVG_CELL_VOLT;
	}

	//平均电芯温度范围：[-40℃，65℃]
	if (sample_data.avg_cell_temp < SOX_SAMPLE_LOWER_AVG_CELL_TEMP)
	{
		retval = true;
		sample_data.avg_cell_temp = SOX_SAMPLE_LOWER_AVG_CELL_TEMP;
	}
	else if (sample_data.avg_cell_temp > SOX_SAMPLE_UPPER_AVG_CELL_TEMP)
	{
		retval = true;
		sample_data.avg_cell_temp = SOX_SAMPLE_UPPER_AVG_CELL_TEMP;
	}

	return retval;
}


/**
 * @brief		更新计算SOX要用的采样数据，保存最近十次的数据
 * @param[in]	无
 * @return		1，执行成功，0，失败
 * @retval		1,采样数据处理成功
 * @retval		0,采样数据处理失败
 * @warning		无
 * @pre			需要在线程中主动调用，才能更新采样数据
 * @note
*/
int32_t sox_sample_data_proc(void)
{
	//中间值
	int32_t retval = true;
//	int32_t counter = 0;

	#ifdef SOX_SAMPLE_TEST
		int32_t test_counter = 0;
	#endif

	// //第一次初始化会将第一次采样数据填充到整个数组
	// //此处也可以采用另外一种处理方式，只填充第一个元素，各有侧重和考虑
	// if (true == g_init_flag)
	// {
	// 	g_sample_stats_index = 0;
	// 	retval = sox_sample_data_fill(g_sample_data_set, g_sample_stats_index);

	// 	for (counter = 1; counter < record_times; counter++)
	// 	{
	// 		retval = sox_sample_data_fill(g_sample_data_set, counter);
	// 	}

	//刚上电，初始化有效值的长度和当前指针的指向位置，并置位初始化标志位
	 if (false == g_init_flag)
	 {
		//log_d("sox_sample_data_deal init none\n");
		return false;
	 }
	 if (false == g_sox_sample_deal_remap.sox_sample_data_get_cb(&g_sample_data_set))
	 {
		// log_d("g_sample_data_get false\n");
		return false;
	 }

//	if (false == g_init_flag)
//	{
//		valid_data_length = 0;
//		g_sample_stats_index = 0;
//		g_init_flag = true;
//	}

	//如果数据异常，本次采样值获取跳过; 如果数据正常，填充到采样数组中
	if (false == sox_sample_sample_over_judge(g_sample_data_set))
	{
		retval = sox_sample_data_fill(g_sample_data_set, g_sample_stats_index);

		//采样数组指针位置循环
		if (++g_sample_stats_index >= record_times)
		{
			g_sample_stats_index = 0;
		}

		if (valid_data_length < record_times)
		{
			valid_data_length++;
		}
	}

	return retval;
}

/**
 * @brief		在指定位置处填充采样数组
 * @param[in]	sample_data_temp，采样数据
 * @param[in]	index，保存到数组指定位置
 * @return		1，执行成功，0，失败
 * @retval		1,采样数据填充成功
 * @retval		0,采样数据填充失败
 * @warning		无
 * @pre
 * @note
*/
static int32_t sox_sample_data_fill(sox_sample_data_t sample_data_temp, int32_t index)
{
	int32_t retval = 1;
	int32_t i = 0;

	if ((index >= SOX_SAMPLE_FILTER_NUM) || (index < 0))
	{
		retval = 0;
		return retval;
	}

	g_sample_stats[index].sys_cur = sample_data_temp.sys_cur;
	g_sample_stats[index].pack_volt = sample_data_temp.pack_volt;
	g_sample_stats[index].min_cell_volt = sample_data_temp.min_cell_volt;
	g_sample_stats[index].min_cell_temp = sample_data_temp.min_cell_temp;
	g_sample_stats[index].max_cell_volt = sample_data_temp.max_cell_volt;
	g_sample_stats[index].avg_cell_temp = sample_data_temp.avg_cell_temp;
	g_sample_stats[index].avg_cell_volt = sample_data_temp.avg_cell_volt;

	for (i = 0; i < CELL_VOLT_NUM; i++)
	{
		g_sample_stats[index].cell_volt[i] = sample_data_temp.cell_volt[i];
	}

	for (i = 0; i < CELL_TEMP_NUM; i++)
	{
		g_sample_stats[index].cell_temp[i] = sample_data_temp.cell_temp[i];
	}

	return retval;
}

/**
 * @brief		SOX采样数据均值滤波处理
 * @param[in]	sox_sample_data，需要加入处理的采样数据
 * @return		true，执行成功，SOX_FAIL，失败
 * @retval		true,采样数据处理成功
 * @retval		SOX_FAIL,采样数据处理失败
 * @warning		无
 * @pre
 * @note		此处的均值处理就是平均10次的采样数据
*/
static int32_t sox_sample_data_avg(sox_sample_data_t* sox_sample_data)
{
	//中间值
	int32_t retval = true;
	int8_t i = 0;
	int32_t j = 0;

	if (NULL == sox_sample_data)
	{
		return SOX_FAIL;
	}

	if (0 == valid_data_length)
	{
		sox_sample_data->sys_cur = 0;
		sox_sample_data->pack_volt = 0;
		sox_sample_data->min_cell_volt = 0;
		sox_sample_data->min_cell_temp = 0;
		sox_sample_data->max_cell_volt = 0;
		sox_sample_data->avg_cell_temp = 0;
		sox_sample_data->avg_cell_volt = 0;

		for (j = 0; j < CELL_VOLT_NUM; j++)
		{
			sox_sample_data->cell_volt[j] = 0;
		}

		for (j = 0; j < CELL_TEMP_NUM; j++)
		{
			sox_sample_data->cell_temp[j] = 0;
		}
	}
	else if ((valid_data_length > 0) && (valid_data_length < 10))
	{
		for (i = 0; i< valid_data_length; i++)
		{
			sox_sample_data->sys_cur += g_sample_stats[i].sys_cur;
			sox_sample_data->pack_volt += g_sample_stats[i].pack_volt;
			sox_sample_data->min_cell_volt += g_sample_stats[i].min_cell_volt;
			sox_sample_data->min_cell_temp += g_sample_stats[i].min_cell_temp;
			sox_sample_data->max_cell_volt += g_sample_stats[i].max_cell_volt;
			sox_sample_data->avg_cell_temp += g_sample_stats[i].avg_cell_temp;
			sox_sample_data->avg_cell_volt += g_sample_stats[i].avg_cell_volt;

			for (j = 0; j < CELL_VOLT_NUM; j++)
			{
				sox_sample_data->cell_volt[j] += g_sample_stats[i].cell_volt[j];
			}

			for (j = 0; j < CELL_TEMP_NUM; j++)
			{
				sox_sample_data->cell_temp[j] += g_sample_stats[i].cell_temp[j];
			}
		}

		//做均值处理，取最近数据的平均值
		sox_sample_data->sys_cur = sox_sample_data->sys_cur/valid_data_length;
		sox_sample_data->pack_volt = sox_sample_data->pack_volt/valid_data_length;
		sox_sample_data->min_cell_volt = sox_sample_data->min_cell_volt/valid_data_length;
		sox_sample_data->min_cell_temp = sox_sample_data->min_cell_temp/valid_data_length;
		sox_sample_data->max_cell_volt = sox_sample_data->max_cell_volt/valid_data_length;
		sox_sample_data->avg_cell_temp = sox_sample_data->avg_cell_temp/valid_data_length;
		sox_sample_data->avg_cell_volt = sox_sample_data->avg_cell_volt/valid_data_length;

		for (j = 0; j < CELL_VOLT_NUM; j++)
		{
			sox_sample_data->cell_volt[j] = sox_sample_data->cell_volt[j]/valid_data_length;
		}

		for (j = 0; j < CELL_TEMP_NUM; j++)
		{
			sox_sample_data->cell_temp[j] = sox_sample_data->cell_temp[j]/valid_data_length;
		}
	}
	else if (valid_data_length >= 10)
	{
		for (i = 0; i< SOX_SAMPLE_FILTER_NUM; i++)
		{
			sox_sample_data->sys_cur += g_sample_stats[i].sys_cur;
			sox_sample_data->pack_volt += g_sample_stats[i].pack_volt;
			sox_sample_data->min_cell_volt += g_sample_stats[i].min_cell_volt;
			sox_sample_data->min_cell_temp += g_sample_stats[i].min_cell_temp;
			sox_sample_data->max_cell_volt += g_sample_stats[i].max_cell_volt;
			sox_sample_data->avg_cell_temp += g_sample_stats[i].avg_cell_temp;
			sox_sample_data->avg_cell_volt += g_sample_stats[i].avg_cell_volt;

			for (j = 0; j < CELL_VOLT_NUM; j++)
			{
				sox_sample_data->cell_volt[j] += g_sample_stats[i].cell_volt[j];
			}

			for (j = 0; j < CELL_TEMP_NUM; j++)
			{
				sox_sample_data->cell_temp[j] += g_sample_stats[i].cell_temp[j];
			}
		}

		//做均值处理，取最近数据的平均值
		sox_sample_data->sys_cur = sox_sample_data->sys_cur/SOX_SAMPLE_FILTER_NUM;
		sox_sample_data->pack_volt = sox_sample_data->pack_volt/SOX_SAMPLE_FILTER_NUM;
		sox_sample_data->min_cell_volt = sox_sample_data->min_cell_volt/SOX_SAMPLE_FILTER_NUM;
		sox_sample_data->min_cell_temp = sox_sample_data->min_cell_temp/SOX_SAMPLE_FILTER_NUM;
		sox_sample_data->max_cell_volt = sox_sample_data->max_cell_volt/SOX_SAMPLE_FILTER_NUM;
		sox_sample_data->avg_cell_temp = sox_sample_data->avg_cell_temp/SOX_SAMPLE_FILTER_NUM;
		sox_sample_data->avg_cell_volt = sox_sample_data->avg_cell_volt/SOX_SAMPLE_FILTER_NUM;

		for (j = 0; j < CELL_VOLT_NUM; j++)
		{
			sox_sample_data->cell_volt[j] = sox_sample_data->cell_volt[j]/SOX_SAMPLE_FILTER_NUM;
		}

		for (j = 0; j < CELL_TEMP_NUM; j++)
		{
			sox_sample_data->cell_temp[j] = sox_sample_data->cell_temp[j]/SOX_SAMPLE_FILTER_NUM;
		}
	}

	return retval;
}

/**
 * @brief		获取计算SOX要用的采样数据
 * @param[in]	p_dout，该入参指针用于获取采样数据
 * @return		SOX_OK，执行成功；SOX_FAIL，失败
 * @note
*/
int32_t sox_sample_data_get(sox_sample_data_t* p_dout)
{
	int32_t retval = SOX_OK;
	sox_sample_data_t sox_sample_avg = {0};

	if (NULL == p_dout)
	{
		return SOX_FAIL;
	}

	retval = sox_sample_data_avg(&sox_sample_avg);

	if (SOX_FAIL == retval)
	{
		return SOX_FAIL;
	}
	else
	{
		memcpy(p_dout,&sox_sample_avg,sizeof(sox_sample_data_t));
	}

	return retval;
}

/**
 * @brief		设置计算SOX要用的采样数据
 * @param[in]	p_dout，该入参指针用于获取采样数据
 * @return		0，执行成功，非0，失败
 * @retval		0，采样数据设置成功
 * @retval		1，采样数据设置失败
 * @warning		无
 * @pre
 * @note
*/
int32_t sox_sample_data_set(sox_sample_data_t* p_dout)
{
	int32_t retval = 0;
	int32_t i = 0;

	if (NULL == p_dout)
	{
		retval = SOX_FAIL;
		return retval;
	}

	g_sample_data_set.avg_cell_volt = p_dout->avg_cell_volt;
	g_sample_data_set.avg_cell_temp = p_dout->avg_cell_temp;
	g_sample_data_set.max_cell_volt = p_dout->max_cell_volt;
	g_sample_data_set.min_cell_temp = p_dout->min_cell_temp;
	g_sample_data_set.min_cell_volt = p_dout->min_cell_volt;
	g_sample_data_set.pack_volt = p_dout->pack_volt;
	g_sample_data_set.sys_cur = p_dout->sys_cur;

	for (i = 0; i < CELL_VOLT_NUM; i++)
	{
		g_sample_data_set.cell_volt[i] = p_dout->cell_volt[i];
	}

	for (i = 0; i < CELL_TEMP_NUM; i++)
	{
		g_sample_data_set.cell_temp[i] = p_dout->cell_temp[i];
	}

	valid_data_length = record_times;

	return retval;
}

/**
 * @brief		设置SOX采样数组
 * @param[in]	p_dout，该入参指针用于获取采样数据
 * @return		0，执行成功，非0，失败
 * @retval		0，采样数据设置成功
 * @retval		1，采样数据设置失败
 * @warning		无
 * @pre
 * @note
*/
void sox_sample_array_set(sox_sample_data_t* p_dout)
{
	int8_t i = 0;
	int32_t j = 0;

	for (i = 0; i< record_times; i++)
	{
		g_sample_stats[i].sys_cur = p_dout->sys_cur;
		g_sample_stats[i].pack_volt = p_dout->pack_volt;
		g_sample_stats[i].min_cell_volt = p_dout->min_cell_volt;
		g_sample_stats[i].min_cell_temp = p_dout->min_cell_temp;
		g_sample_stats[i].max_cell_volt = p_dout->max_cell_volt;
		g_sample_stats[i].avg_cell_temp = p_dout->avg_cell_temp;
		g_sample_stats[i].avg_cell_volt = p_dout->avg_cell_volt;

		for (j = 0; j < CELL_VOLT_NUM; j++)
		{
			g_sample_stats[i].cell_volt[j] = p_dout->cell_volt[j];
		}

		for (j = 0; j < CELL_TEMP_NUM; j++)
		{
			g_sample_stats[i].cell_temp[j] = p_dout->cell_temp[j];
		}
	}
}

/**
 * @brief		清空SOX的采样数据
 * @param[in]	p_dout，该入参指针用于获取采样数据
 * @return		无
 * @warning		无
 * @pre
 * @note
*/
void sox_sample_reset(void)
{
	g_sample_data_set.sys_cur = 0;
	g_sample_data_set.pack_volt = 0;
	g_sample_data_set.min_cell_volt = 0;
	g_sample_data_set.min_cell_temp = 0;
	g_sample_data_set.max_cell_volt = 0;
	g_sample_data_set.avg_cell_temp = 0;
	g_sample_data_set.avg_cell_volt = 0;

	memset(g_sample_stats, 0, 10*sizeof(sox_sample_data_t)/sizeof(int8_t));
	g_sample_stats_index = 0;
	valid_data_length = 0;
}

/**
* @brief		SOX采样数据外部定制化函数映射接口初始化
* @param		*balance_interface_remap 被动均衡接口映射结构体
* @return		返回结果
* @retval		true初始化成功  false: 初始化失败
* @warning
*/
bool sox_sample_deal_init(sox_sample_deal_remap_t *sox_sample_deal_remap)
{

   if (NULL == sox_sample_deal_remap)
   {
       return  false;
   }
   else
   {
        g_sox_sample_deal_remap = *sox_sample_deal_remap;
        valid_data_length = 0;
        g_sample_stats_index = 0;
        g_init_flag = true;
        return  true;
   }

}
