/**
 * @file     sop_calc.c
 * @brief    sop限流控制逻辑
 * @company  sofarsolar
 * @author   骆鹏
 * @note     1.引入放电阶梯限流策略  2.引入电流值500ms滤波
 * @note     3.加入一次充放电状态累计1Ah安时限流回差策略 4.根据亿纬电芯手册刷新的最新SOP表格 5. 修复边界处理及高温升温定点值处理
 * @note     6.修复放电阶梯限流换挡时间计数清0 BUG 7. 根据项目修改放电电流上限为60A  8. 增加放空后需累积充电0.5Ah才能恢复放电电流上限
 * @version  V1.0.8
 * @date     2023/08/25
 */
#ifndef SOP_H_
#define SOP_H_
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include "sox_public.h"

/*内部变量宏定义*/
#define HIGH_LOW_TEMP_BOUNDARY      (260)     // 高低温临界点 分辨率0.1℃
#define ARRAY_VOLT_CNT              (3)       // SOP查表用的单体电压数量
#define ARRAY_TEMP_CNT              (9)       // SOP查表用的真实电芯温度数量
#define DSG_LADDER_LIMIT_SOC        (50)      // 进入放电阶梯模式的SOC条件 分辨率0.1%
#define DSG_MIN_VOL_COUNT           (1)       // 首次最低单体电压小于2850mV的计数标志
#define DSG_LADDER_LIMIT_MIN_CELL   (2850)    // 进入放电阶梯模式最低单体电压的条件 单位mV
#define DSG_LADDER_CURR_NUM         (4)       // 放电阶梯电流表大小
#define LIMIT_TIME_INTERVEL         (100)     // 10S 基于100ms的任务
#define SOP_TICK_250MS              (250)     // 250ms
#define SOP_TICK_1S                 (1000)    // 1S

#define DSG_LADDER_LIMIT_CELL_TEMP  (150)     // 放电阶梯模式的最低电芯温度条件 单位0.1℃
#define DSG_LADDER_CURR_MAX_VAL     (-DEFAULTED_RATED_CAP*11/10)   // 放电阶梯限流模式 换挡电流限制条件 -1.1C

#define FILTER_500MS_BASED_100MS     (5)         // 滑窗记录电流深度 单位MS
#define DSG_LADDER_LIMIT_TAB_LENGTH  (4)         // 阶梯限流表长度
#define SOP_STANDY_MODE              (0u)     //  BMS待机模式
#define SOP_CHARGE_MODE              (1u)     //  BMS充电模式
#define SOP_DISCHARGE_MODE           (2u)     //  BMS放电模式
#define SOP_FULL_CHG_START           (1u)     //  满充开始
#define SOP_EMPTY_START              (2u)     //  放空开始
#define SOP_LEVEL2                   (2u)     //  充放电等级
#define LIMIT_MODE_ENTER_COUNT       (1u)     // 阶梯限流换挡动作进入次数计数
#define SOP_CHG_ACC_CAP_LIMIT       (1000)   // 一次充电状态下的累计容量 1000mAh = 1Ah
#define SOP_DISCHG_CAP_LIMIT        (-1000) //  一次放电状态下的累计容量 1000mAh = 1Ah
#define SOP_EMPTY_LIMIT             (500)  // 放空后放电限流恢复需要的累计充电容量 单位mAh
#define SOP_MS_TO_SECOND            (1000)  //  毫秒-秒单位转换
#define SOP_SECOND_TO_HOUR          (3600)  //  秒-时单位转换
#define SOP_CHG_CURR_LIMIT          (150)   //  充电电流限制  单位mA
#define SOP_DISCHG_CURR_LIMIT       (-150)  //  放电电流限制  单位mA
#define SOP_TYPICAL_LOSS_CURR       (-60)   // 经典补偿损耗电流值 单位mA
#define SOP_REAL_TEMP_TRANS_UPPER   (450)    //真实温度转折点上限 单位0.1℃
#define SOP_BACK_TEMP_TRANS_UPPER   (400)    //回差温度转折点上限  单位0.1℃
#define SOP_CELL_TEMP_MAX           (600)    //最大电芯温度上限 单位0.1℃
#define SOP_PACK_BAL_DSG            (0x01)   //主动均衡状态: 放电
#define SOP_PACK_BAL_CHG            (0x02)   //主动均衡状态: 充电
#define SOP_CALC_SOC_LIMIT          (980)    //计算值SOC上限耦合主动均衡状态限制充电电流为0
#define SOP_LADDER_BACKLASH_CURR    (5)      //阶梯限流查表电流值回差指标
#define SOP_OVER_VOL_VAL            (3600)   //过压最大单体电压告警值
#define SOP_OVER_VOL_CANCEL_VAL     (3500)   //过压最大单体告警解除值
#define SOP_STANDBY_CAP_REFRESH_VAL (1000)   //待机累计1Ah 单位mAh
#define DSG_LADDER_CHANGE_WAITING_CNT_BASED_100MS 50


#define SOP_CALC_SOC_UPLIMIT        (1000) // 计算SOC上限(分辨率0.1)
#define SOP_CHG_DSG_STATUS_UPLIMT   (2)    // 充放电状态上限(0: 待机  1: 充电 2： 放电)
#define SOP_CELL_TEMP_UPLIMIT       (650)  // 电芯温度上限 65℃(分辨率0.1)
#define SOP_CELL_TEMP_DOWNLIMIT     (-400) // 电芯温度下限 -40℃(分辨率0.1)
#define SOP_CELL_VOL_UPLIMIT        (4000) // 电芯电压上限4000mV
#define SOP_CELL_VOL_DOWNLIMIT      (2000) // 电芯电压下限2400mV
#define SOP_SYS_CURR_UPLIMIT        (2.1f*DEFAULTED_RATED_CAP*1000) //系统电流上限2.1C
#define SOP_SYS_CURR_DOWNLIMIT      (-2.1f*DEFAULTED_RATED_CAP*1000) //系统电流下限-2.1C
#define SOP_CHG_DSG_LEVEL_UPLIMIT   (3)       // 充放电等级上限

/**
  * @struct sop_bat_data_t
  * @brief SOP估算需要的电池数据
  */

typedef struct
{
	uint32_t max_cell_vol;		        ///< 最大单体电压 单位mV
	uint32_t min_cell_vol;		        ///< 最小单体电压 单位mV
    int32_t  sys_curr;              ///< 系统电流 单位mA
    uint16_t max_chg_level;         ///< 最大充电等级
    uint16_t max_dischg_level;      ///< 最大放电等级
    uint16_t sys_soc;               ///< 系统SOC 范围0 - 1000，分辨率为0.1%, 1000对应100%
	int16_t  max_cell_temp;           ///< 最高电芯温度 单位0.1℃
	int16_t  min_cell_temp;	          ///< 最低电芯温度 单位0.1℃
    uint8_t  bat_state;             ///< 电池状态 (0:待机 1 ： 充电 2： 放电)
}sop_bat_data_t;

typedef struct
{
	bool startup_flag;
	bool sop_dsg_cur_be_larger;
	uint8_t dsg_ladder_change_waiting_cnt;
	uint16_t sop_dsg_cur_old;
}dsg_ladder_paras_t;

/**
  * @struct sop_interface_remap_t
  * @brief SOP接口映射
  */
typedef struct
{
    bool (*sop_bat_data_get_cb)(sop_bat_data_t *sop_bat_data);  ///< 本PACK数据获取
    uint32_t (*sop_tick_get_cb)(void);                          ///< 当前tick获取
    bool  (*sop_is_tick_over_cb)(uint32_t time_start, uint32_t time_length); ///< tick超时判断
    uint32_t (* sop_bat_state_get_cb)(void);                    ///< 本PACK满充放空状态获取
}sop_interface_remap_t;

/**
  * @struct power_limit_t
  * @brief 充放电电压电流限制值
  */
typedef struct
{
	uint16_t chg_curr_limit;		///< 充电电流上限 单位1A
	uint16_t dsg_curr_limit;		///< 放电电流上限制 单位1A
	uint16_t chg_volt_limit;		///< 充电电压上限 单位0.1V
	uint16_t dsg_volt_limit;		///< 放电电压上限 单位0.1V
}power_limit_t;

/**
* @brief		充放电电压电流限制值获取
* @param		无
* @return		power_limit_t
* @retval		充放电限流值、限压值
* @warning
*/
power_limit_t sop_limit_value_get(void);

/**
* @brief		SOP值限制为0开关
 * @param		sop_limit_zero_flag SOP强制限制为0标志: true 限制为0  false:解除限制为0
 * @return		无
 */
void sop_power_limit_zero(bool sop_limit_zero_flag);

/**
* @brief		充放电电压电流限制值获取
* @param		无
* @return		返回结果
* @retval		充放电限流值、限压值
* @warning
*/
power_limit_t sop_limit_value_get_deal(void);

/**
 * @brief                设置sop限流为0
 * @param                [in]bool 设置标志，true为限流，false为取消限流
 * @return
 */
void sop_curr_limit_set(bool set_flag);

/**
* @brief		SOP外部定制化函数映射接口初始化
* @param		*sop_interface_remap sop接口映射结构体
* @return		g_sop_init_flag
* @retval		true初始化成功  false: 初始化失败
* @warning
*/
bool sop_init(sop_interface_remap_t *sop_interface_remap);

/**
 * @brief                SOP初始化函数
 * @param                [in]void
 * @return               [out]void
 */
uint8_t sop_init_deal(void);

/**
* @brief        sop线程 每100ms执行一次
* @param        SOP接口映射
* @return        返回结果
* @retval       无
* @warning      sop_init_deal()必须先初始化
*/
void sop_proc_deal(void);

/**
* @brief		sop线程 每100ms执行一次
* @param		无
* @return		返回结果
* @retval		无
* @warning	   在sop初始化以后调用
*/
void sop_thread(void);

/**
 * @brief               电池采样数据初始化
 * @param[in]	         void
 * @return		         true:初始化成功, false:初始化失败
 * @note
 */
uint8_t sox_sample_deal_init_ex(void);

#endif

