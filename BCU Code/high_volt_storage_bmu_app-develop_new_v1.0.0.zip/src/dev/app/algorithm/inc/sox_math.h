#ifndef SOX_MATH_H_
#define SOX_MATH_H_

#include <stdint.h>

#define INTERP_AXIS_MAX_LEN     20

/**
  * @enum   coord_3d_t
  * @brief  3D坐标结构体
  */
typedef struct{
	int32_t x;
	int32_t y;
	int32_t z;
}coord_3d_t;

/**
  * @enum   coord_2d_t
  * @brief  2D坐标结构体
  */
typedef struct{
	int32_t x;
	int32_t y;
}coord_2d_t;

/**
  * @enum   index_length_3d_t
  * @brief  3D坐标长度结构体
  */
typedef struct{
	int32_t x;
	int32_t y;
	int32_t z;
}index_length_3d_t;

/**
  * @enum   index_length_2d_t
  * @brief  2D坐标长度结构体
  */
typedef struct{
	int32_t x;
	int32_t y;
}index_length_2d_t;

/**
 * @brief		返回数组的最大值
 * @param[in]	p_array，要判断的数组
 * @param[in]	length，数组的长度
 * @return		返回最大值
 * @warning		无
 * @pre
 * @note
*/
int32_t max_array(int32_t * p_array, int32_t length);

/**
 * @brief		返回数组的最小值
 * @param[in]	p_array，要判断的数组
 * @param[in]	length，数组的长度
 * @return		返回最小值
 * @warning		无
 * @pre
 * @note
*/
int32_t min_array(int32_t * p_array, int32_t length);

/**
 * @brief		返回数组的最大值及索引
 * @param[in]	p_array，要判断的数组
 * @param[in]	length，数组的长度
 * @param[in]	p_index，最大值的索引
 * @return		返回最大值
 * @warning		无
 * @pre
 * @note
*/
int32_t max_array_and_index(int32_t * p_array, int32_t length, int32_t* p_index);

/**
 * @brief		返回数组的最小值及索引
 * @param[in]	p_array，要判断的数组
 * @param[in]	length，数组的长度
 * @param[in]	p_index，最小值的索引
 * @return		返回最小值
 * @warning		无
 * @pre
 * @note
*/
int32_t min_array_and_index(int32_t * p_array, int32_t length, int32_t* p_index);

/**
 * @brief		返回两个数中的最大值
 * @param[in]	num_1 第一个数
 * @param[in]	num_2 第二个数
 * @return		返回两个数中的最大值
 * @warning		无
 * @pre
 * @note
*/
int32_t max_two_nums(int32_t num_1, int32_t num_2);

/**
 * @brief		返回两个数中的最小值
 * @param[in]	num_1 第一个数
 * @param[in]	num_2 第二个数
 * @return		返回两个数中的最小值
 * @warning		无
 * @pre
 * @note
*/
int32_t min_two_nums(int32_t num_1, int32_t num_2);

/**
* @brief		一维插值
 * @param[in]	p_index_tab 索引表地址
 * @param[in]	p_data_tab 数据表地址
 * @param[in]	index_length 各维长度
 * @param[in]	x 插值的坐标
 * @return		插值结果
 * @warning		无
 * @pre
 * @note
*/
int32_t sox_interp_1d(int32_t* p_index_tab, int32_t* p_data_tab, int32_t index_length, int32_t x);

/**
* @brief		二维插值
 * @param[in]	p_index_tab 索引表地址
 * @param[in]	p_data_tab 数据表地址
 * @param[in]	index_length 各维长度
 * @param[in]	coord_2d 插值的坐标
 * @return		插值结果
 * @warning		无
 * @pre
 * @note
*/
int32_t sox_interp_2d(int32_t* p_index_tab, int32_t* p_data_tab, uint8_t index_table_col, index_length_2d_t index_length, coord_2d_t coord_2d);

/**
* @brief		三维插值
 * @param[in]	p_index_tab 索引表地址
 * @param[in]	p_data_tab 数据表地址
 * @param[in]	index_length 各维长度
 * @param[in]	coord_3d 插值的坐标
 * @return		插值结果
 * @warning		无
 * @pre
 * @note
*/
int32_t sox_interp_3d(int32_t* p_index_tab, int32_t* p_data_tab, uint8_t index_table_col, index_length_3d_t index_length, coord_3d_t coord_3d);

/**
* @brief		超时判断
 * @param[in]	current_time 当前时间
 * @param[in]	record_time 记录时间
 * @param[in]	diff 判断为超时的时间间隔
 * @return		SOC_OK，超时，SOC_FAIL，没有超时
 * @note
*/
int32_t sox_time_is_over(uint32_t current_time, uint32_t record_time, uint32_t diff);

/**
* @brief		搜索数组中两个索引之间的数值，btn->between two numbers
 * @param[in]	current_time 当前时间
 * @param[in]	record_time 记录时间
* @param[in]	diff 判断为超时的时间间隔
 * @return		SOC_OK，超时，SOC_FAIL，没有超时
 * @retval		SOC_OK，超时
 * @retval		SOC_FAIL，没有超时
 * @warning		无
 * @pre
 * @note		表的索引顺序从小到大，表的长度要大于等于2
*/
int32_t sox_scout_val_btn(int32_t* p_index, int32_t* p_data, int32_t length, int32_t x);

#endif
