#ifndef SOE_H
#define SOE_H

#include "sox_public.h"
#include "sox_math.h"
#include "sox_sample.h"
#include <stdint.h>

/**
* @brief		SOE进程初始化，在进程执行前调用，完成接口的初始化
 * @param[in]	sox_interface_remap，SOE接口函数的地址
 * @return		SOX_OK，进程初始化成功；SOX_FAIL，进程初始化失败
 * @note
*/
int8_t soe_proc_init(sox_interface_remap_t sox_interface_remap);

/**
* @brief		SOE线程
 * @param[in]	无
 * @return		执行成功，SOX_OK；执行失败，SOX_FAIL
 * @note
*/
int8_t soe_proc(void);

/**
 * @brief		SOE自动化测试
 * @param[in]	step，测试步骤
 * @return		无
 * @note
*/
bool soe_proc_test(int32_t step);

/**
 * @brief		SOE静态变量重置
 * @param[in]	无
 * @return		无
 * @note
*/
void soe_reset(void);

#endif // SOE_H
