#ifndef SOX_STATS_H
#define SOX_STATS_H
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include "sox_public.h"

/**
  * @enum   sox_stats_t
  * @brief  sox所有统计数据
  */
typedef struct{
    uint64_t sumed_dsg_mA_s;	///< 累计放电mAs，精度：1mAs
    uint64_t sumed_chg_mA_s;	///< 累计充电mAs，精度：1mAs
    uint64_t sumed_dsg_mW_s;	///< 累计放电mWs，精度：1mWs
    uint64_t sumed_chg_mW_s;	///< 累计充电mWs，精度：1mWs

    uint32_t sumed_dsg_ah;		///< 累计放电AH，精度：1Ah
    uint32_t sumed_chg_ah;		///< 累计充电AH，精度：1Ah
	  uint32_t sumed_chg_wh;		///< 累计充电WH，精度：1Wh
	  uint32_t sumed_dsg_wh;		///< 累计放电WH，精度：1Wh
    
    uint32_t sumed_display_cycle; ///< 对外显示累计循环圈数，精度0.01圈
}sox_stats_t;


/**
 * @brief		sox统计数据--线程初始化
 * @param[in]	sox_interface_remap，SOX统计数据接口，方向为：外部向统计模块传输
 * @return		SOX_OK，执行成功；SOX_FAIL，失败
 * @note		如果接口传输失败，SOX统计模块将无法正常工作
*/
int8_t sox_stats_proc_init(sox_interface_remap_t sox_interface_remap);

/**
 * @brief		SOX统计数据--主线程
 * @param[in]	无
 * @return		SOX_OK，执行成功；SOX_FAIL，失败
 * @note
*/
int8_t sox_stats_proc(void);

/**
 * @brief		获取累计充放电容量
 * @param[in]	p_dout，该入参指针用于获取SOX统计数据
 * @return		SOX_OK，执行成功；SOX_FAIL，失败
 * @note
*/
int8_t sox_stats_get(sox_stats_t* p_dout);

/**
 * @brief		设置累计充电Ah
 * @param[in]	d_in，需要设置的累计充电容量
 * @return		SOX_OK，执行成功；SOX_FAIL，失败
 * @note
*/
int8_t sox_stats_chg_ah_set(int32_t d_in);

/**
* @brief		设置累计放电Ah
 * @param[in]	d_in，需要设置的累计放电容量
 * @return		SOX_OK，执行成功；SOX_FAIL，失败
 * @note
*/
int8_t sox_stats_dsg_ah_set(int32_t d_in);

/**
 * @brief		设置累计充电Wh
 * @param[in]	d_in，需要设置的累计充电Wh
 * @return		SOX_OK，执行成功；SOX_FAIL，失败
 * @note
*/
int8_t sox_stats_chg_wh_set(int32_t d_in);

/**
* @brief		设置累计放电Wh
 * @param[in]	d_in，需要设置的累计放电Wh
 * @return		SOX_OK，执行成功；SOX_FAIL，失败
 * @note
*/
int8_t sox_stats_dsg_wh_set(int32_t d_in);

/**
* @brief		获取真实Ah
 * @param[in]	无
 * @return		电池当前满充容量，单位Ah
 * @note
*/
int32_t sox_stats_real_cap_get(void);

/**
* @brief		获取剩余Ah
 * @param[in]	无
 * @return		剩余容量，单位Ah
 * @note
*/
int32_t sox_stats_remained_cap_get(void);

/**
 * @brief		获取SOX统计数据保存标志位
 * @param[in]	无
 * @return		true，需要保存；false，不需要保存
 * @note
*/
uint16_t sox_stats_save_flag_get(void);

/**
 * @brief		重置SOX统计数据保存标志位
 * @param[in]	无
 * @return		无
 * @note
*/
void sox_stats_save_flag_reset(void);

/**
 * @brief		获取SOX统计数据初始化标志位
 * @param[in]	无
 * @return		true，SOX统计数据完成初始化；false，SOX统计数据未完成初始化
 * @note
*/
uint16_t sox_stats_init_flag_get(void);

/**
 * @brief		重置SOX_stats模块，除了定制化接口
 * @param[in]	无
 * @return		无
 * @note
*/
void sox_stats_reset(void);

/**
 * @brief		SOX统计数据模块级自动化测试
 * @param[in]	无
 * @return		无
 * @note
*/
bool sox_stats_proc_test(int32_t step);

#endif // SOX_STATS_H
