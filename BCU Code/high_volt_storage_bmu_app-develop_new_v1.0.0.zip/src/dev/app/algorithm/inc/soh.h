#ifndef	SOH_MANAGE_H_
#define	SOH_MANAGE_H_

#include <stdint.h>
#include <stdbool.h>
#include "sox_public.h"

/**
  * @enum   pack_cycle_storg_stats_t
  * @brief  循环、存储统计数据结构体
  */
typedef struct{
    int32_t cycle_chg_as;   	///< 循环中的充电安秒积分
    int32_t cycle_dsg_as;   	///< 循环中的放电安秒积分
    int32_t cycle_cur;      	///< 循环中的电流积累量
    int32_t avg_cur;        	///< 循环中的平均电流
    int32_t cur_counter;	    ///< 循环状态下，统计的电流数量
}pack_cycle_storg_stats_t;

/**
  * @enum   pack_cycle_storg_stats_t
  * @brief  循环、存储统计数据结构体
  */
typedef struct{
    int32_t cycle_temp;     	        ///< 循环中的温度积累量
    int32_t storage_temp;   	        ///< 存储中的温度积累量
    int32_t avg_cycle_temp; 	        ///< 循环中的平均温度
    int32_t avg_storage_temp;	        ///< 存储中的平均温度
    int32_t cycle_temp_counter;				///< 循环状态下，统计的温度数量
	  int32_t storage_temp_counter;			///< 静置状态下，统计的温度数量
}cell_cycle_storg_stats_t;

/**
 * @brief		SOH流程初始化
 * @param[in]	sox_interface_remap，SOX定制化函数的地址
 * @return		无
 * @note
*/
void soh_proc_init(sox_interface_remap_t sox_interface_remap);

/**
 * @brief		SOH流程
 * @param[in]	无
 * @return		无
 * @note
*/
void soh_proc(void);

/**
 * @brief		SOH相关数据强制刷新
 * @param[in]	无
 * @return		true，刷新成功；fasle，刷新失败
 * @note
*/
bool soh_enforce_refresh(void);

/**
 * @brief		SOH计算值、高低精度显示值设置
 * @param[in]	sel_cmd，设定SOH数值的命令
 * @param[in]	soh_setting_val，需要设定的SOH数值
 * @return		0，设置成功；1，设置失败
 * @note
*/
int32_t soh_calc_val_set(sox_cell_sel_e sel_cmd, int32_t soh_setting_val);

/**
 * @brief		获取整个电池包的SOH显示值
 * @param[in]	无
 * @return		电池包的SOH显示值
 * @note
*/
int32_t soh_pack_display_val_get(void);

/**
 * @brief		获取电芯的SOH高精度计算值
 * @param[in]	sel_cmd，获取SOH计算值的命令
 * @return		SOH计算值
 * @note
*/
int32_t soh_high_pre_get(sox_cell_sel_e sel_cmd);

/**
 * @brief		获取电芯的SOH实际计算值
 * @param[in]	sel_cmd，获取SOH计算值的命令
 * @return		SOH计算值
 * @note
*/
int32_t soh_calc_val_get(sox_cell_sel_e sel_cmd);

/**
 * @brief		获取SOH保存标志位
 * @param[in]	无
 * @return		SOH保存标志位
 * @note
*/
uint16_t soh_save_flag_get(void);

/**
 * @brief		重置SOH保存标志位
 * @param[in]	无
 * @return		无
 * @note
*/
void soh_save_flag_reset(void);


/**
 * @brief		获取SOH初始化标志位
 * @param[in]	无
 * @return		SOH初始化标志位
 * @note
*/
uint16_t soh_init_flag_get(void);


/**
 * @brief		重置SOH模块，除了定制化接口
 * @param[in]	无
 * @return		无
 * @note
*/
void soh_reset(void);

/**
 * @brief		SOH模块级自动化测试
 * @param[in]	step，SOH测试步骤序号
 * @return		测试用例通过还是失败，true 或者 false
 * @note
*/
uint64_t soh_proc_test(int32_t step);

#endif
