/**
 * @file     bmu_passive_balance.h
 * @brief    BMU 被动均衡逻辑对应的头文件
 * @company  sofarsolar
 * @author   骆鹏
 * @note     利用充电结束时刻数据计算理论均衡时间
 * @version  V1.0.2
 * @date     2023/08/21
 */

#ifndef __BMU_PASSIVE_BALANCE_H__
#define __BMU_PASSIVE_BALANCE_H__

#include "app_public.h"
#include "sox_public.h"

/*---------宏定义声明-----------*/
#define  INIT_OK                        (true)               ///< 初始化OK
#define  INIT_FAIL                      (false)              ///< 初始化失败
#define  RUNNING_OK                     (true)               ///< 运行OK
#define  RUNNING_FAIL                   (false)              ///< 运行失败
#define  PARA_ERROR                     (-2)                 ///< 参数错误 超出正常范围
#define  REC_OK                         (1u)                 ///< 接受成功
#define  REC_FAIL                       (-1)                 ///< 接受失败
#define  SEND_OK                        (1u)                 ///< 发送成功
#define  SEND_FAIL                      (-1)                 ///< 发送失败
#define  FULL_CHG_SET                   (1u)                 ///< 满充标志位置位
#define  FULL_CHG_CLEAR                 (0)                  ///< 满充标志位清0
#define  EMPTY_DSG_SET                   (1u)                ///< 放空标志位置位
#define  EMPTY_DSG_CLEAR                 (0)                 ///< 放空标志位清0
#define  CHECK_TAB_PERMIT               (1u)                 ///< 允许查表
#define  CHECK_TAB_FORBID               (-1)                 ///< 不允许查表

#define  ARRAY_VOL_NUM                  (5)                  ///<  均衡校准表的电压长度
#define  ARRAY_TEMP_NUM                 (4)                  ///<  均衡校准表的温度长度
#define  SLIDING_FILTER_5S_BASED_1S     (5)                  ///< 滑窗记录电芯电压深度 单位S
#define  SLIDING_FILTER_60S_BASED_1S    (60)                 ///< 滑窗记录系统电流深度 单位S
#define  BAL_CELL_NUM                   (CELL_VOLT_NUM)      ///< 电芯数量
#define  BALANCE_TAB_CURR_DOWN_LIMIT    (0)                               ///< 允许查均衡校准表电流下限0C

#if PACK_64S_PRJ
#define  BALANCE_TAB_CURR_UP_LIMIT      (1.1f*DEFAULTED_RATED_CAP*1000)   ///< 允许查均衡校准表电流上限1.1C
#else 
#define  BALANCE_TAB_CURR_UP_LIMIT      (0.6f*DEFAULTED_RATED_CAP*1000)   ///< 允许查均衡校准表电流上限0.6C
#endif

#define PASSIVE_BALANCE_TIME_MIN_VAL    (600)   // 被动均衡时间最小阈值600S
#define PASSIVE_BALANCE_SOH_MAX_VAL     (1000)  // SOH最大上限  分辨率0.1
#define PASSIVE_BALANCE_SOH_MIN_VAL      (0)    // SOH最小上限  分辨率0.1
#define PASSIVE_BALANCE_RATE_CAP_MAX     (RATED_CAP_UPPER_LIMIT * 10)  // 额定容量阈值上限 400Ah 单位0.1Ah
#define PASSIVE_BALANCE_RATE_CAP_MIN     (RATED_CAP_LOWER_LIMIT * 10)  //额定容量阈值下限  50Ah  单位0.1Ah
#define PASSIVE_BALANCE_CURR_MAX         (225)  // 被动均衡电流阈值上限 150mA正常值+50% 225mA
#define PASSIVE_BALANCE_CURR_MIN         (75)   // 被动均衡电流阈值下限 150mA正常值-50% 75mA
#define PASSIVE_BALANCE_LEVEL2           (0x02)  // 最大充放电等级
#define PASSIVE_BALANCE_SYS_DSG_CURR     (-3000) // 系统放电电流 -3A 单位mA
#define PASSIVE_BALANCE_MIN_CELL_VOL     (3000)  // 最小电芯电压 单位mV
#define BALANCE_CYCLE_20S_BASED_1S       (20)    // AFE均衡周期20S 单位S
#define PASSIVE_BALANCE_CELL_AVG_TEMP    (100)   // 电芯平均温度 单位0.1℃
#define PASSIVE_BALANCE_CELL_TEMP_MAX    (1000)  // 电芯温度上限 100℃ 单位0.1℃
#define PASSIVE_BALANCE_CELL_TEMP_MIN    (-600)  // 电芯温度下限 -60℃ 单位0.1℃
#define PASSIVE_BAL_PERMIT               (1u)    ///< 被动均衡允许
#define PASSIVE_BAL_FORBID               (-1)    ///< 被动均衡禁止
#define PASSIVE_BAL_FULL_CHG_10S         (10u)   ///< 满充标志上升沿持续10S

#define BMU_DATA_RDY_SEND_TIME_BASED_1S (5u)   // BMU数据就绪状态发送时间5秒 单位秒
#define BMUS_DATA_WATING_TIME_BASED_1S (20u)   // BMU数据准备发送时间3秒 单位秒

#define CELL_BAL_CALC_SOH_UPLIMIT             (1000)
#define CELL_BAL_CALC_SOH_DOWNLIMIT           ( 0 )
#define CELL_BAL_CELL_VOL_UPLIMIT             (4000)
#define CELL_BAL_CELL_VOL_DOWNLIMIT           (2400)
#define CELL_BAL_MAX_CELL_VOL_UPLIMIT         (4000)
#define CELL_BAL_MAX_CELL_VOL_DOWNLIMIT       (2400)
#define CELL_BAL_MIN_CELL_VOL_UPLIMIT         (4000)
#define CELL_BAL_MIN_CELL_VOL_DOWNLIMIT       (2400)
#define CELL_BAL_CELL_TEMP_UPLIMIT            (650)
#define CELL_BAL_CELL_TEMP_DOWNLIMIT          (-400)
#define CELL_BAL_CELL_AVG_TEMP_UPLIMIT        (650)
#define CELL_BAL_CELL_AVG_TEMP_DOWNLIMIT      (-400)
#define CELL_BAL_MAX_CHG_DSG_LEVEL_UPLIMT     (3)
#define CELL_BAL_SYS_CURR_UPLIMIT             (1.5f*DEFAULTED_RATED_CAP*1000)
#define CELL_BAL_SYS_CURR_DOWNLIMIT           (-1.5f*DEFAULTED_RATED_CAP*1000)

/**
  * @struct  bms_attr_type_t
  * @brief   bms参数属性类型结构体
*/
typedef struct
{
//    int32_t  over_chg_curr_alarm;   ///< 过充电流 单位mA
//    int32_t  over_dsg_curr_alarm;   ///< 过放电流 单位mA
    uint16_t rate_cap;              ///< 额定容量 单位0.1Ah
    uint16_t cell_num;				///< 电芯数量
    uint16_t cell_vol_num;          ///< 单体电压数量
    uint16_t cell_temp_num;         ///< 单体温度数量
    uint16_t balance_vol_diff;      ///< 被动均衡开启压差 单位mV
    uint16_t cell_bal_curr;         ///< 被动均衡电流 单位mA

}bms_attr_type_t;

/**
  * @struct balance_bat_data_t
  * @brief  均衡需要的电池数据结构体
*/
typedef struct
{
    int32_t  sys_curr;              ///< 系统电流(bcu+均衡电流) 单位mA
    int32_t  bcu_curr;              ///< BCU系统电流 单位mA
    int32_t  bat_soh;               ///< 电池SOH 范围0 - 1000，分辨率为0.1%, 1000对应100%
    int16_t  cell_temp[BAL_CELL_NUM];   ///< 电芯温度 单位0.1℃
    uint16_t cell_vol[BAL_CELL_NUM];    ///< 单体电压  单位mV
    uint16_t max_cell_vol;          ///< 最大单体 单位mV
    int16_t  cell_avg_temp;         ///< 电芯平均温度 单位0.1℃
    uint16_t max_chg_level;         ///< 最大充电等级
    uint16_t max_dischg_level;      ///< 最大放电等级
    uint16_t min_cell_vol;          ///< 最小电芯电压  单位mV
}balance_bat_data_t;

/**
  * @struct scroll_record_data_t
  * @brief  滑窗记录的电池数据结构体
*/
typedef struct
{
    int32_t  sys_curr[SLIDING_FILTER_60S_BASED_1S];                ///< 系统电流  单位mA
    uint16_t cell_vol[SLIDING_FILTER_5S_BASED_1S][BAL_CELL_NUM];      ///< 单体电压  单位mV
}scroll_record_data_t;

/**
  * @struct passive_balance_interface_remap_t
  * @brief 被动均衡接口映射
  */
typedef struct
{
    void (*passive_balance_pos_set_cb)(uint16_t balance_pos[]);    ///<  被动均衡位置设置
    bool (*passive_bal_forbid_flag_get_cb)(void);                ///<  被动均衡禁能标志获取
    bool (*passive_bal_bmus_data_status_get_cb)(void);           ///<  BCU被动均衡数据状态获取
    uint16_t (*passive_bal_min_check_soc_get_cb)(void);          ///<  本簇最小电芯电压查表SOC获取
}passive_balance_interface_remap_t;

/**
  * @struct balance_public_interface_remap_t
  * @brief  均衡公共外部定制函数结构体
  */
typedef struct
{
  uint32_t (*balance_tick_get_cb)(void);                                           ///<  当前tick获取
  bool (*balance_bms_attr_get_cb)(bms_attr_type_t *p_bms_attr_type);               ///<  默认属性参数获取
  bool (*balance_bat_data_get_cb)(balance_bat_data_t *p_balance_bat_data);         ///< 电池数据获取
  bool (*balance_full_chg_flag_get_cb)(void);                                      ///< 满充标志位获取
  bool (*balance_empty_dsg_flag_get_cb)(void);                                      ///< 放空标志位获取
}balance_public_interface_remap_t;

/**
 * @brief                电芯均衡逻辑初始化
 * @param                [in]void
 * @warning              用于初始化电芯间均衡模块
 */
void cell_balance_init(void);

/**
 * @brief                被动均衡线程 每1S执行一次
 * @param                [in]void
 * @warning              cell_balance_init()之后调用，1S周期调用次函数
 */
void cell_balance_proc(void);

/**
* @brief		被动均衡外部定制化函数映射接口初始化
* @param		passive_balance_interface_remap_t 被动均衡接口映射结构体
* @param		 balance_public_interface_remap_t 均衡公共模块接口映射结构体
* @return		返回结果 是否初始化成功
* @retval		初始化成功：INIT_OK(1)  初始化失败： INIT_FAIL(0)
* @warning
*/
bool passive_balance_init(passive_balance_interface_remap_t *p_passive_balance_interface_remap,  balance_public_interface_remap_t *p_balance_public_interface_remap);


// /**
// * @brief		滚动记录的5S电芯电压和系统电流值数据对外获取
// * @param		void
// * @return		返回结果 是否获取成功
// * @retval		scroll_record_data_t 滚动记录数据结构体
// * @warning
// */
// scroll_record_data_t *scroll_record_data_5s_data_get(void);

/**
* @brief		被动均衡满充时刻数据对外获取
* @param		uint16_t cell_num 电芯数量
* @param		uint16_t *p_cell_vol 要获取的电芯电压 单位mV
* @param		uint8_t *p_chg_ending_index 要获取的充电结束时刻下标
* @return		返回结果 是否获取成功
* @retval		获取失败: RUNNING_FAIL(0)   获取成功: RUNNING_OK(1)
* @warning
*/
bool  passive_balance_full_chg_data_get(uint16_t cell_num, uint16_t *p_cell_vol, uint8_t *p_chg_ending_index);

/**
* @brief		被动均衡时间对外获取
* @param		uin32_t cell_id  要获取的电芯位置 0 - 15： 表示电芯1- 电芯16
* @param		uint16_t cell_num  电芯数量
* @return		返回结果
* @retval		某单个电芯均衡时间  PARA_ERROR(-2)  入参错误 其他值：电芯均衡时间
* @warning
*/
int32_t passive_balance_time_get(uint32_t cell_id, uint16_t cell_num);

/**
* @brief		被动均衡位置获取
* @param		无
* @return		返回结果
* @retval		所有电芯的均衡位置
* @warning
*/
uint16_t* passive_balance_pos_get(void);

/**
* @brief		均衡位置获取
* @param		无
* @return		返回结果
* @retval		所有电芯的均衡位置
* @warning
*/
uint16_t* cell_balance_pos_get(void);


/**
* @brief		BMU满充判断
* @param		void
* @return		返回结果 是否满充
* @retval		检测到满充： true;  未检测到满充:false
* @warning
*/
bool bmu_is_full_chg_check(void);

/**
* @brief        cell balance逻辑禁止/使能控制
* @param        [in] disable_flag     true:屏蔽cell balance逻辑/false:cell balance逻辑正常
* @warning       一般只有ate测试才会调用，其他模块慎用
*/
void cell_balance_display_func_disable(bool disable_flag);

/**
* @brief        cell balance逻辑屏蔽标志获取
* @param        void
* @return        执行结果
* @retval        true: 屏蔽cell balance逻辑，false:正常使用cell balance逻辑
*/
bool cell_balance_disable_flag_get(void);


/**
* @brief		被动均衡线程 每1S执行一次
* @param		无
* @return		返回结果
* @retval		无
* @warning		在均衡初始化之后调用
*/
void bmu_passive_balance_proc(void);

/**
* @brief		获取BMU均衡数据准备状态
* @param		void
* @return		返回BMU均衡数据准备状态
* @retval		bool
* @warning  给BCU
*/
bool  bmu_data_status_get(void);

/**
* @brief		获取BMU最小电芯SOC
* @param		void
* @return		返回BMU最小电芯SOC
* @retval		int16_t
* @warning
*/
uint16_t  bmu_min_cell_soc_get(void);

/**
* @brief                获取BMU均衡数据准备状态
* @param                void
* @return                返回BMU均衡数据准备状态
* @retval                bool
* @warning      给BCU
*/
bool cell_balance_status_get(void);

/**
* @brief                获取BMU的最小电芯SOC
* @param                void
* @return                返回BMU的最小电芯SOC
* @retval                bool
* @warning      给BCU
*/
uint16_t cell_balance_min_cell_soc_get(void);

/**
 * @brief                接收压差被动均衡所需数据
 * @param[in]           val_type
 * @param[in]           val
 * @return               int32_t
 * @note                无
 */
int32_t volt_diff_pas_bal_data_set(uint8_t val_type, uint16_t val);

#endif
