/**
 * @file     sox_public.h
 * @brief    电池包SOX算法的头文件
 * @company  sofarsolar
 * @author
 * @note
 * @version
 * @date
 * @attention 传入--电压精度为mV
 * @attention 传入--电流精度为mA
 * @attention 传入--温度精度为℃
 * @attention 传入--RTC精度为s
 * @attention 传入--Tick精度为ms
 * @attention 传出--SOC、SOH精度为1%
 * @attention 内部--SOC、SOH计算值精度为0.001%
 */

#ifndef __SOX_PUBLIC_H__
#define __SOX_PUBLIC_H__

#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include "app_public.h"

/*************************************************************************************************/
/*************************************************宏定义******************************************/
/************************************************************************************************/

#define SOX_SHELL_DEBUG_TEST
#define LOG_PRINT_SWITCH_ON 1      ///< SOX模块功能开关

//电芯、温度传感器数量
#define CELL_TEMP_GROUP_LENGTH  2	///< 电芯温度传感器组元素个数

//SOC计算值上下限
#define SOC_UPPER_LIMIT (100*SOC_CALC_PRE)
#define SOC_LOWER_LIMIT 0

//SOX返回值类型
#define SOX_OK	0				///< SOX模块处理正常、或者条件满足
#define SOX_FAIL	-1			///< SOX模块处理失败、或者条件不满足
#define RUNNING_OK        (true)            ///< 运行OK
#define RUNNING_FAIL      (false)           ///< 运行失败

//SOX计算值各类放大倍数
#define SOC_CALC_PRE 1000		///< SOC计算值放大倍数
#define SOH_CALC_PRE 1000		///< SOH计算值放大倍数
#define SOC_DISPLAY_PRE 100		///< SOC显示值放大倍数
#define SOH_DISPLAY_PRE 100		///< SOH显示值放大倍数
#define FRAC_PRE 1000			///< 计算中的小数部分放大倍数
#define DISPLAY_CYCLE_PRE 100	///< 显示循环圈数的精度

#define SOE_CALC_PRE 1000
#define SOE_TABLE_PRE 1000

#define THOUTHAND_ROUND_OFF 500	///< 一千的四舍五入

//安时和瓦时更新
#define AH_REFRESH 		 5			///< 5安时
#define CYCLE_REFRESH 1800		///< 1800s

//损耗电流
#define LOSS_CUR_UPPER_LIMIT 150
#define LOSS_CUR_UNDER_LIMIT (-150)
#define LOSS_CUR (-60)
#define LOSS_CUR_WITH_INV_UPPER_LIMIT 300
#define LOSS_CUR_WITH_INV_UNDER_LIMIT (-300)

//时间相关
#define _10S_BASE_1S	10		///< 10s
#define _60S_BASE_1S	60		///< 60s
#define _60S_BASE_1MS	60000	///< 60s
#define _120S_BASE_1S	120		///< 120s
#define _500MS_BASE_10MS 50		///< 0.5s
#define HOUR_TO_SEC 3600		///< 小时转换为秒
#define  _5S_BASED_1S     (5)   ///< 5s
#define  _60S_BASED_1S    (60)  ///< 60s

/*************************************************************************************************/
/**************************************************枚举*******************************************/
/************************************************************************************************/

/**
  * @enum   sox_cell_sel_e
  * @brief  SOX电芯及PACK设置命令
  */
typedef enum
{
	CELL1_IS_SELED = 0u,	///< 选择CELL--1
	CELL2_IS_SELED = 1u,	///< 选择CELL--2
	CELL3_IS_SELED = 2u,	///< 选择CELL--3
	CELL4_IS_SELED = 3u,	///< 选择CELL--4
	CELL5_IS_SELED = 4u,	///< 选择CELL--5
	CELL6_IS_SELED = 5u,	///< 选择CELL--6
	CELL7_IS_SELED = 6u,	///< 选择CELL--7
	CELL8_IS_SELED = 7u,	///< 选择CELL--8
	CELL9_IS_SELED = 8u,	///< 选择CELL--9
	CELL10_IS_SELED = 9u,	///< 选择CELL--10
	CELL11_IS_SELED = 10u,	///< 选择CELL--11
	CELL12_IS_SELED = 11u,	///< 选择CELL--12
	CELL13_IS_SELED = 12u,	///< 选择CELL--13
	CELL14_IS_SELED = 13u,	///< 选择CELL--14
	CELL15_IS_SELED = 14u,	///< 选择CELL--15
	CELL16_IS_SELED = 15u,	///< 选择CELL--16
	CELL17_IS_SELED = 16u,	///< 选择CELL--17
	CELL18_IS_SELED = 17u,	///< 选择CELL--18
	CELL19_IS_SELED = 18u,	///< 选择CELL--19
	CELL20_IS_SELED = 19u,	///< 选择CELL--20
	CELL21_IS_SELED = 20u,	///< 选择CELL--21
	CELL22_IS_SELED = 21u,	///< 选择CELL--22
	CELL23_IS_SELED = 22u,	///< 选择CELL--23
	CELL24_IS_SELED = 23u,	///< 选择CELL--24
	CELL25_IS_SELED = 24u,	///< 选择CELL--25
	CELL26_IS_SELED = 25u,	///< 选择CELL--26
	CELL27_IS_SELED = 26u,	///< 选择CELL--27
	CELL28_IS_SELED = 27u,	///< 选择CELL--28
	CELL29_IS_SELED = 28u,	///< 选择CELL--29
	CELL30_IS_SELED = 29u,	///< 选择CELL--30
	CELL31_IS_SELED = 30u,	///< 选择CELL--31
	CELL32_IS_SELED = 31u,	///< 选择CELL--32
	CELL33_IS_SELED = 32u,	///< 选择CELL--33
	CELL34_IS_SELED = 33u,	///< 选择CELL--34
	CELL35_IS_SELED = 34u,	///< 选择CELL--35
	CELL36_IS_SELED = 35u,	///< 选择CELL--36
	CELL37_IS_SELED = 36u,	///< 选择CELL--37
	CELL38_IS_SELED = 37u,	///< 选择CELL--38
	CELL39_IS_SELED = 38u,	///< 选择CELL--39
	CELL40_IS_SELED = 39u,	///< 选择CELL--40
	CELL41_IS_SELED = 40u,	///< 选择CELL--41
	CELL42_IS_SELED = 41u,	///< 选择CELL--42
	CELL43_IS_SELED = 42u,	///< 选择CELL--43
	CELL44_IS_SELED = 43u,	///< 选择CELL--44
	CELL45_IS_SELED = 44u,	///< 选择CELL--45
	CELL46_IS_SELED = 45u,	///< 选择CELL--46
	CELL47_IS_SELED = 46u,	///< 选择CELL--47
	CELL48_IS_SELED = 47u,	///< 选择CELL--48
#if PACK_64S_PRJ
	CELL49_IS_SELED = 48u,	///< 选择CELL--49
	CELL50_IS_SELED = 49u,	///< 选择CELL--50
	CELL51_IS_SELED = 50u,	///< 选择CELL--51
	CELL52_IS_SELED = 51u,	///< 选择CELL--52
	CELL53_IS_SELED = 52u,	///< 选择CELL--53
	CELL54_IS_SELED = 53u,	///< 选择CELL--54
	CELL55_IS_SELED = 54u,	///< 选择CELL--55
	CELL56_IS_SELED = 55u,	///< 选择CELL--56
	CELL57_IS_SELED = 56u,	///< 选择CELL--57
	CELL58_IS_SELED = 57u,	///< 选择CELL--58
	CELL59_IS_SELED = 58u,	///< 选择CELL--59
	CELL60_IS_SELED = 59u,	///< 选择CELL--60
	CELL61_IS_SELED = 60u,	///< 选择CELL--61
	CELL62_IS_SELED = 61u,	///< 选择CELL--62
	CELL63_IS_SELED = 62u,	///< 选择CELL--63
#endif
	CELL_NUM_IS_SELED,
	PACK_IS_SELED,	///< 选择整个PACK
}sox_cell_sel_e;

/**
  * @struct sox_fault_e
  * @brief 各种故障及保护类参数
 */
typedef enum
{
	SOX_CELL_VOLT_HIGH_ALARM = 0u,	///< 电芯过压告警
	SOX_TOTAL_VOLT_LOW_ALARM = 1u,	///< PACK欠压告警
	SOX_CELL_VOLT_LOW_ALARM = 2u,	///< 电芯欠压告警

	SOX_TOTAL_VOLT_LOW_PROTECT = 3u,///< PACK欠压保护
	SOX_CELL_VOLT_LOW_PROTECT = 4u,	///< 电芯欠压保护

	SOX_BAT_DSG_EMPTY = 5u,			///< 电池放空标志

	THERE_IS_FAULT = 6u,			///< 存在故障
	SOX_BAT_CHG_FULL = 7u,			///< 电池满充标志

	SOX_CAN_RECV_EMPTY = 8u,		///< 从CAN接收到的其它BMU判空
}sox_fault_e;

/**
  * @struct sox_bat_status_e
  * @brief 电池状态相关的定义
 */
typedef enum
{
	SOX_BAT_STANDBY = 0u,		///< 电池待机
	SOX_BAT_CHARGE = 1u,		///< 电池充电
	SOX_BAT_DISCHARGE = 2u,		///< 电池放电
}sox_bat_status_e;

/**
  * @struct sox_bms_status_e
  * @brief BMS状态相关的定义
 */
typedef enum
{
	SOX_BMS_SELF_CHECK = 0u,	///< 开机自检
	SOX_BMS_RUN = 1u,			///< 运行
	SOX_BMS_PF_ERROR = 2u,		///< 永久性故障
	SOX_BMS_UPGRADE = 3u,		///< 升级过程
	SOX_BMS_SHUT_DOWN = 4u,		///< 关机
}sox_bms_status_e;

/**
  * @struct sox_ctrl_cmd_e
  * @brief SOX设置命令
 */
typedef enum
{
	SOX_NEED_SAVE = 0u,					///< SOX是否需要保存
	SOX_RUNNING_DATA_GET = 1u,			///< 获取SOX运行数据
	SOX_INIT_STATUS_GET = 2u,			///< 获取SOX初始化状态
	SOC_INIT_STATUS_GET = 3u,			///< 获取SOC初始化状态
	SOH_INIT_STATUS_GET = 4u,			///< 获取SOH初始化状态
	SOX_STATICS_INIT_STATUS_GET = 5u,	///< 获取SOX运行数据初始化状态
	SOX_RESET = 6u,						///< 复位SOX模块
	SOX_RUNNING_DATA_SET = 7u,			///< 设置SOX运行数据
	SOX_SAMPLE_DATA_SET = 8u,			///< 设置SOX采样数组
	SOX_ENFORCE_SAVE = 9u,				///< 强制刷新SOX数据
	SOX_GET_5S_CELL_VOLT = 10u,			///< 获取5秒电芯电压数据
}sox_ctrl_cmd_e;

/**
  * @struct sox_data_cmd_e
  * @brief SOX数据设置命令
 */
typedef enum
{
	DISPLAY_SOC_SET = 0u,	///< 设置SOC显示值，设置精度：1%
	DISPLAY_SOH_SET = 1u,	///< 设置SOH显示值，设置精度：1%

	TOTAL_CHG_AH_SET = 2u,	///< 设置累计充电容量，1Ah
	TOTAL_DSG_AH_SET = 3u,	///< 设置放电累计容量，1Ah
	TOTAL_CHG_WH_SET = 4u,	///< 设置充电累计瓦时，1Wh
	TOTAL_DSG_WH_SET = 5u,	///< 设置放电累计瓦时，1Wh
}sox_data_cmd_e;

/**
  * @struct sox_cali_cmd_e
  * @brief SOX校准设置命令
 */
typedef enum
{
	RX_SOC_MIN_TO_VOLT_SET = 0u,	///< 设置最小电芯电压的Utable，设置精度：mV
	RX_CALC_VAL_SET = 1u,			///< 设置Utable的查表SOC，设置精度：0.001%
	RX_MIN_CELL_VOLT = 2u,			///< 设置整簇最小的电芯电压，设置精度：1mV
}sox_cali_cmd_e;

/**
  * @struct volt_diff_pas_bal_cmd_e
  * @brief SOX校准设置命令
 */
typedef enum
{
	RX_CLU_MIN_VOLT_SET = 0u,	///< 设置最小电芯电压的Utable，设置精度：mV

}volt_diff_pas_bal_cmd_e;
/*************************************************************************************************/
/*************************************************结构体******************************************/
/************************************************************************************************/

/**
 * @struct volt_fl_t
 * @brief 一阶滤波后的电压信号
 */
typedef struct
{
	float   volt_last_time;		///< 上次电压滤波值，mA
	int32_t volt_this_time;		///< 本次电压滤波值，mA
}volt_fl_t;

/**
 * @struct cur_fl_t
 * @brief 一阶滤波后的电流信号
 */
typedef struct
{
	float   cur_last_time;		///< (t - 1)时刻的电流滤波值，mA
	int32_t cur_this_time;		///< t时刻的电流滤波值，mA
}cur_fl_t;

/**
 * @struct dsg_cali_data_t
 * @brief SOC放电末端校准数据
 */
typedef struct
{
	// uint8_t soc_cali_flag;			///< 放电末端校准标志
	int32_t can_soc_min_to_volt;		///< 最小电芯电压的Utable
	int32_t can_calc_val;				///< 对应查表SOC
	int32_t can_min_cell_volt;			///< BCU下发最小电芯电压
}dsg_cali_data_t;

/**
 * @struct volt_diff_pas_bal_data_t
 * @brief SOC放电末端校准数据
 */
typedef struct
{
	uint16_t clu_min_cell_volt;			///< BCU下发簇内最小电芯电压
}volt_diff_pas_bal_data_t;

/***********************定义的SOC事件记录结构体***************************/

/**
  * @enum   soc_pack_event_u
  * @brief  PACK级SOC运行事件记录
  */
typedef union
{
	uint8_t bytes;
	struct
	{
		uint8_t initialized : 1;		///< SOC初始化，开机时置false，初始化之后置true(一次性)
		uint8_t longtime_unused:1;		///< 长时间未使用，开机时置false，触发校准，置true(一次性)
		uint8_t loss_temp : 1;			///< 触发损耗补偿，满足时置true，不满足时置false
		uint8_t soc_save:1;				///< 触发SOC保存，置true；不满足条件置false
		uint8_t chg_dsg_record:1;		///< 充放电时间记录，置true；不满足条件置false
		uint8_t proc_initialized:1;		///< SOC模块进程初始化，开机时置false，初始化之后置true(一次性)
	}bit;
}soc_pack_event_u;

/**
  * @enum   soc_cell_event_u
  * @brief  CELL级SOC运行事件记录
  */
typedef union
{
	uint8_t bytes;
	struct
	{
		uint8_t overchg : 1;		///< 触发判饱，置true；判饱退出，置false
		uint8_t overdsg : 1;		///< 触发判空，置true；SOC大于1%时，置false
		uint8_t standby :1;			///< 触发静置校准，置true；不满足条件置false
	}bit;
}soc_cell_event_u;

/**
  * @enum   soc_error_u
  * @brief  SOC运行异常记录
  */
typedef union
{
	uint8_t bytes;
	struct
	{
		uint8_t sample_over_limit:1;	///< 采样值超出限制，置true；指定范围内，置false
		uint8_t sample_get_failed:1;	///< 采样数据获取失败，置true；获取成功，置false
	}bit;
}soc_error_u;

/**
  * @enum   soc_status_t
  * @brief  SOC运行状态
  */
typedef struct
{
	soc_pack_event_u pack_events;
	soc_cell_event_u cell_events[CELL_VOLT_NUM];
	soc_error_u errors;
}soc_status_t;

/***********************定义的SOH事件记录结构体***************************/

/**
  * @enum   soh_pack_event_u
  * @brief  PACK级SOH运行事件
  */
typedef union
{
	uint8_t bytes;
	struct
	{
		uint8_t initialized : 1;		///< SOH初始化，开机时置false，初始化之后置true(一次性)
		uint8_t daily_settlement:1;		///< 每日SOH计算，满足条件置true，不满足置false
		uint8_t soh_save :1;			///< 触发SOH保存，满足条件置true，不满足置false
		uint8_t proc_initialized:1;		///< 模块进程初始化，置true；否则置false
	}bit;
}soh_pack_event_u;

/**
  * @enum   soh_cell_event_u
  * @brief  CELL级SOH运行事件记录
  */
typedef union
{
	uint8_t bytes;
	struct
	{
		uint8_t calc_permit : 1;	///< SOH计算准入，满足条件置true，进入计算后置false
		uint8_t calc_entry : 1;		///< SOH准入启动，满足条件置true，进入计算后置false
		uint8_t calc_exit : 1;		///< SOH计算结束，满足条件置true，计算退出后置false
		uint8_t calc_exist:1;		///< 存在SOH临时计算值，计算出SOH临时计算值后置true，保存SOH临时计算值后置false
	}bit;
}soh_cell_event_u;

/**
  * @enum   soh_error_u
  * @brief  SOH运行异常记录
  */
typedef union
{
	uint8_t bytes;
	struct
	{
		uint8_t sample_over_limit:1;	///< 采样值超出限制，置true，指定范围内置false
		uint8_t sample_get_failed:1;	///< 采样数据获取失败，置true，获取成功置false
	}bit;
}soh_error_u;

/**
  * @enum   soh_status_t
  * @brief  SOH运行状态
  */
typedef struct
{
	soh_pack_event_u pack_events;
	soh_cell_event_u cell_events[CELL_VOLT_NUM];
	soh_error_u errors;
}soh_status_t;


/***********************SOX接口用到的结构体***************************/
/**
  * @struct sox_sample_data_t
  * @brief SOX计算需要使用的采样数据
  */
typedef struct
{
	int32_t sys_cur;		///< 系统电流--mA
	int32_t pack_volt;		///< PACK总压--mV
	int32_t min_cell_volt;	///< 最小电芯电压--mV
	int32_t cell_volt[CELL_VOLT_NUM];	///< 电芯电压--mV
	int32_t max_cell_volt;	///< 最大电芯电压--mV
	int32_t avg_cell_volt;	///< 平均电芯电压--mV
	int16_t cell_temp[CELL_TEMP_NUM];	///< 电芯温度--℃
	int16_t min_cell_temp;	///< 最小电芯温度--℃
	int16_t avg_cell_temp;	///< 平均电芯温度--℃
}sox_sample_data_t;

/**
  * @struct sox_rtc_t
  * @brief RTC时间
  */
typedef struct  {
    uint8_t  tm_sec;     ///<  秒 	0-59
    uint8_t  tm_min;     ///<  分钟	0-59
    uint8_t  tm_hour;    ///<  小时 1-12
    uint8_t  tm_weekday; ///<  星期	1-7
    uint8_t  tm_day;     ///<  日 	1-31
    uint8_t  tm_mon;     ///<  月 	1-12
    uint8_t  tm_year;    ///<  年 范围00-99
}sox_rtc_t;

/**
  * @struct sox_cell_full_chg_flag_t
  * @brief 电芯满充标志位
  */
typedef union {
	uint64_t all_flag;
	struct
	{
		uint64_t cell_1 : 1;		/// 1号电芯
		uint64_t cell_2 : 1;		/// 2号电芯
		uint64_t cell_3 : 1;		/// 3号电芯
		uint64_t cell_4 : 1;		/// 4号电芯
		uint64_t cell_5 : 1;		/// 5号电芯
		uint64_t cell_6 : 1;		/// 6号电芯
		uint64_t cell_7 : 1;		/// 7号电芯
		uint64_t cell_8 : 1;		/// 8号电芯
		uint64_t cell_9 : 1;		/// 9号电芯
		uint64_t cell_10 : 1;		/// 10号电芯
		uint64_t cell_11 : 1;		/// 11号电芯
		uint64_t cell_12 : 1;		/// 12号电芯
		uint64_t cell_13 : 1;		/// 13号电芯
		uint64_t cell_14 : 1;		/// 14号电芯
		uint64_t cell_15 : 1;		/// 15号电芯
		uint64_t cell_16 : 1;		/// 16号电芯
		uint64_t cell_17 : 1;		/// 17号电芯
		uint64_t cell_18 : 1;		/// 18号电芯
		uint64_t cell_19 : 1;		/// 19号电芯
		uint64_t cell_20 : 1;		/// 20号电芯
		uint64_t cell_21 : 1;		/// 21号电芯
		uint64_t cell_22 : 1;		/// 22号电芯
		uint64_t cell_23 : 1;		/// 23号电芯
		uint64_t cell_24 : 1;		/// 24号电芯
		uint64_t cell_25 : 1;		/// 25号电芯
		uint64_t cell_26 : 1;		/// 26号电芯
		uint64_t cell_27 : 1;		/// 27号电芯
		uint64_t cell_28 : 1;		/// 28号电芯
		uint64_t cell_29 : 1;		/// 29号电芯
		uint64_t cell_30 : 1;		/// 30号电芯
		uint64_t cell_31 : 1;		/// 31号电芯
		uint64_t cell_32 : 1;		/// 32号电芯
		uint64_t cell_33 : 1;		/// 33号电芯
		uint64_t cell_34 : 1;		/// 34号电芯
		uint64_t cell_35 : 1;		/// 35号电芯
		uint64_t cell_36 : 1;		/// 36号电芯
		uint64_t cell_37 : 1;		/// 37号电芯
		uint64_t cell_38 : 1;		/// 38号电芯
		uint64_t cell_39 : 1;		/// 39号电芯
		uint64_t cell_40 : 1;		/// 40号电芯
		uint64_t cell_41 : 1;		/// 41号电芯
		uint64_t cell_42 : 1;		/// 42号电芯
		uint64_t cell_43 : 1;		/// 43号电芯
		uint64_t cell_44 : 1;		/// 44号电芯
		uint64_t cell_45 : 1;		/// 45号电芯
		uint64_t cell_46 : 1;		/// 46号电芯
		uint64_t cell_47 : 1;		/// 47号电芯
		uint64_t cell_48 : 1;		/// 48号电芯
#if PACK_64S_PRJ
		uint64_t cell_49 : 1;		/// 49号电芯
		uint64_t cell_50 : 1;		/// 50号电芯
		uint64_t cell_51 : 1;		/// 51号电芯
		uint64_t cell_52 : 1;		/// 52号电芯
		uint64_t cell_53 : 1;		/// 53号电芯
		uint64_t cell_54 : 1;		/// 54号电芯
		uint64_t cell_55 : 1;		/// 55号电芯
		uint64_t cell_56 : 1;		/// 56号电芯
		uint64_t cell_57 : 1;		/// 57号电芯
		uint64_t cell_58 : 1;		/// 58号电芯
		uint64_t cell_59 : 1;		/// 59号电芯
		uint64_t cell_60 : 1;		/// 60号电芯
		uint64_t cell_61 : 1;		/// 61号电芯
		uint64_t cell_62 : 1;		/// 62号电芯
		uint64_t cell_63 : 1;		/// 63号电芯
		uint64_t cell_64 : 1;		/// 64号电芯
#endif
	}bit;
}sox_cell_full_chg_flag_t;

/**
  * @struct sox_running_data_t
  * @brief BMS运行实时数据，需要掉电保存
 */
#pragma pack(4)
typedef struct
{
    int32_t cell_calc_soc[CELL_VOLT_NUM];	///< SOC计算值，精度：0.001%
    int32_t cell_calc_soh[CELL_VOLT_NUM];	///< SOH计算值，精度：0.001%

	int32_t pack_calc_soc;		///< PACK的计算SOC，精度：0.001%
	int32_t soh_high_pre[CELL_VOLT_NUM];	///< 高精度SOH，精度：0.001%

	uint16_t cycle_frac[CELL_VOLT_NUM];	///< 圈数的小数部分
    uint16_t cycle_count[CELL_VOLT_NUM];	///< 循环次数
    uint16_t remain_cap;     	///< 剩余容量 精度：1AH
    uint16_t real_cap;       	///< 实际容量 精度：1AH

    sox_rtc_t chg_dsg_record;	///< 充电电时间记录，保存到 sec
	sox_rtc_t ocv_cali_time[CELL_VOLT_NUM];///< OCV校准时间，保存到 sec
    sox_rtc_t daily_save_time;	///< 上次每日保存的时间，保存到 sec
	int32_t delivery_time;		///< 距离第一次上电的时间，sec

	 uint32_t total_chg_ah; 		///< 累计充电容量 精度：1AH
	 uint32_t total_dsg_ah; 		///< 累计放电容量 精度：1AH

	 uint64_t total_chg_mA_s;	///< 高精度累计充电容量 mAs
	 uint64_t total_dsg_mA_s;	///< 高精度累计放电容量 mAs

	 uint32_t total_chg_wh;  	///< 累计充电瓦时 精度：1WH
	 uint32_t total_dsg_wh;  	///< 累计放电瓦时 精度：1WH

	 uint64_t total_chg_mW_s;	///< 高精度累计充电瓦时 mWs
	 uint64_t total_dsg_mW_s;	///< 高精度累计放电瓦时 mWs

    sox_rtc_t full_chg_time[CELL_VOLT_NUM]; 	///< SOC判饱退出，电芯的满充时间，年月日时分秒；仅作SOX模块内部记录用
	uint32_t full_chg_dsg_ah[CELL_VOLT_NUM]; 	///< SOC判饱退出，电芯的满充放电容量；仅作SOX模块内部记录用

	soc_status_t soc_running_status;	///< SOC运行状态
	soh_status_t soh_running_status;	///< SOH运行状态

	bool sox_not_first_start_flag;	///< SOX初次启动

	sox_cell_full_chg_flag_t cell_full_chg_flag;	///< 电芯的满充标志位

	uint32_t display_cycle_turns;	///< 对外显示循环圈数，精度：0.01圈
	float soe_prop;					///< SOE比例系数，精度：0.001

	uint32_t reserved[9];		///< 预留10个字节
	uint32_t version;			///< 版本
	uint32_t crc;				///< SOX运行数据的CRC
}sox_running_data_t;
#pragma pack()

/**
  * @struct limit_params_t
  * @brief SOX用到的各种限制类参数
 */
typedef struct
{
	int32_t cell_num;			///< 电芯数量，个
	int32_t cell_temp_num;		///< 电芯温度传感器数量，个
	int32_t rated_cap;			///< 额定容量，Ah,
	uint16_t chg_stop_vol;		///< 充电截止电压,V
    uint16_t chg_stop_cur;		///< 充电截止电流,A
}limit_params_t;

/**
  * @struct sox_data_t
  * @brief SOX计算出来的数据
 */
typedef struct
{
	int32_t calc_soc;		///< PACK的SOC计算值，精度：0.001%
	int32_t calc_soh;		///< PACK的SOH计算值，精度：0.001%
	int32_t display_soc;	///< PACK的SOC显示值，精度：1%
	int32_t display_soh;	///< PACK的SOH显示值，精度：1%

	int32_t cell_display_soc[CELL_VOLT_NUM];	///< 电芯的SOC显示值，精度：1%
	int32_t cell_display_soh[CELL_VOLT_NUM];	///< 电芯的SOH显示值，精度：1%

	int32_t total_chg_ah;	///< PACK的累计充电容量，精度：1Ah
	int32_t total_dsg_ah;	///< PACK的累计放电容量，精度：1Ah
	int32_t total_chg_wh;	///< PACK的累计充电瓦时，精度：1Wh
	int32_t total_dsg_wh;	///< PACK的累计放电瓦时，精度：1Wh

	int32_t remained_cap;	///< PACK的剩余容量，精度：1Ah
	int32_t real_cap;		///< PACK的实际容量，精度：1Ah

	uint32_t cycle_count;	///< PACK的对外显示循环次数，精度：0.01圈
}sox_data_t;


/**
  * @struct sox_interface_remap_t
  * @brief SOX算法需要用到的函数类型
 */
typedef struct
{
	void (*sox_running_data_get)(sox_running_data_t *sox_runing_data);		///< 获取SOX的运行数据
	sox_running_data_t * (*sox_running_data_addr_get)(void);				///< 获取SOX运行数据的地址
	void (*sox_rtc_get)(sox_rtc_t *sox_rtc);								///< 获取RTC时间
	uint32_t (*sox_tick_get)(void);											///< 获取系统tick
	void (*sox_limit_params_get)(limit_params_t *limit_params);				///< 获取电池的限制参数
	int32_t (*sox_get_fault)(sox_fault_e sox_fault);						///< 获取系统的故障、告警
	sox_bat_status_e (*sox_bat_status_get)(void);							///< 获取电池状态
	sox_bms_status_e (*sox_bms_status_get)(void);							///< 获取系统状态
	void (*sox_dsg_cali_data_get)(dsg_cali_data_t *dsg_cali_data);			///< 获取放电末端校准数据
	int32_t (*calc_soc_get)(void);											///< 获取SOC计算值
	void (*soe_save)(float soe_prop);									///< 保存SOE比例系数
}sox_interface_remap_t;

/**
  * @struct sox_scroll_record_data_t
  * @brief  滑窗记录的电池数据结构体
*/
typedef struct
{
    int32_t  sys_curr[_60S_BASED_1S];                  ///< 系统电流  单位mA
    uint16_t cell_vol[_5S_BASED_1S][CELL_VOLT_NUM];    ///< 单体电压  单位mV
}sox_scroll_record_data_t;

/*************************************************************************************************/
/**********************************************函数声明*******************************************/
/************************************************************************************************/

/**
 * @brief                SOX初始化
 * @param                [in]void
 * @warning              用于初始化SOX模块
 */
void sox_init(void);

/**
 * @brief                SOX计算处理函数
 * @param                [in]void
 * @warning              必须sox_init()之后调用，10ms周期调用次函数
 */
void sox_proc(void);

/**
 * @brief    获取SOX数据
 * @param    [in]void
 * @param    [out]sox_data_t*
 * @note     (供外部调用)
 * @warning  必须要判断无效值NULL
 */
const sox_data_t* sox_data_get_deal(void);

/**
* @brief		设置SOX模块指定数据  // todo  暂时不删，因为打印有用到
 * @param[in]	sox_data_cmd，指定数据对应的命令，sox_data_cmd_e类型
 * @param[in]	data_in，需要设置的数据，uint32_t类型
 * @return		0，执行成功，非0，执行失败
 * @warning		无
 * @note
*/
int32_t sox_data_set(sox_data_cmd_e sox_data_cmd, uint32_t data_in);

/**
 * @brief		获取SOX运行数据的地址，用于SOX模块内部
 * @param[in]	无
 * @return		返回全局运行数据的指针
 * @retval		sox_running_data_t*，全局运行数据的指针
 * @note
 * @pre			无
*/
sox_running_data_t* sox_running_data_addr_get(void);

/**
* @brief		SOX拓展控制接口
 * @param[in]	sox_ctrl_cmd
  * -# 		SOX_NEED_SAVE，判断SOX是否需要保存的命令
  * -# 		SOX_RUNNING_DATA_GET，获取SOX运行数据
  * -# 		SOX_INIT_STATUS_GET，获取SOX初始化完成与否的命令
  * -# 		SOC_INIT_STATUS_GET，获取SOC初始化完成与否的命令
  * -# 		SOH_INIT_STATUS_GET，获取SOH初始化完成与否的命令
  * -# 		SOX_STATICS_INIT_STATUS_GET，获取SOX统计数据初始化完成与否的命令
  * -#		SOX_RESET命令下，直接重置SOX所有参数
 * @param[in]	p_out
  * -# 		SOX_NEED_SAVE命令下，输入：uint8_t * 类型，true，需要保存
  * -# 		SOX_RUNNING_DATA_GET命令下，输入：sox_running_data_t * 类型
  * -# 		SOX_INIT_STATUS_GET命令下，输入：uint8_t * 类型，true，初始化完成
  * -# 		SOC_INIT_STATUS_GET命令下，输入：uint8_t * 类型，true，初始化完成
  * -# 		SOH_INIT_STATUS_GET命令下，输入：uint8_t * 类型，true，初始化完成
  * -# 		SOX_STATICS_INIT_STATUS_GET命令下，输入：uint8_t * 类型，true，初始化完成
  * -# 		SOX_RESET命令下，输入：无类型
 * @return
 * @warning		无
 * @note
*/
int32_t sox_ctrl(sox_ctrl_cmd_e sox_ctrl_cmd, void *p_out);

#endif

