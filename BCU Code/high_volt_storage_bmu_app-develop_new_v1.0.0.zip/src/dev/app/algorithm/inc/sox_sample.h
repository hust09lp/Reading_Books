#ifndef SOX_SAMPLE_DEAL_H_
#define SOX_SAMPLE_DEAL_H_
#include <stdint.h>
#include "sox_public.h"

#define SOX_SAMPLE_FILTER_NUM    10 // SOX采样值滤波次数,1s滤波基于100ms

//SOX采样值保护范围
#define SOX_SAMPLE_UPPER_CUR (DEFAULTED_RATED_CAP*1000*15/10)			//采样电流上限 1.5C mA
#define SOX_SAMPLE_LOWER_CUR (-DEFAULTED_RATED_CAP*1000*15/10)			//采样电流下限 -1.5C

#define SOX_SAMPLE_UPPER_PACK_VOLT (4000*CELL_VOLT_NUM)		//PACK总压上限 N * 4V
#define SOX_SAMPLE_LOWER_PACK_VOLT (2400*CELL_VOLT_NUM)		//PACK总压下限 N * 2.4V

#define SOX_SAMPLE_UPPER_MIN_CELL_VOLT (4000)	//最小电芯电压上限4000mV
#define SOX_SAMPLE_LOWER_MIN_CELL_VOLT (2400)	//最小电芯电压上限2400mV

#define SOX_SAMPLE_UPPER_MIN_CELL_TEMP (65)		//最小电芯温度上限65℃
#define SOX_SAMPLE_LOWER_MIN_CELL_TEMP (-40)	//最小电芯温度下限-40℃

#define SOX_SAMPLE_UPPER_MAX_CELL_VOLT (4000)	//最大电芯电压上限4000mV
#define SOX_SAMPLE_LOWER_MAX_CELL_VOLT (2400)	//最大电芯电压上限2400mV

#define SOX_SAMPLE_UPPER_AVG_CELL_VOLT (4000)	//平均电芯电压上限4000mV
#define SOX_SAMPLE_LOWER_AVG_CELL_VOLT (2400)	//平均电芯电压上限2400mV

#define SOX_SAMPLE_UPPER_AVG_CELL_TEMP (65)		//平均电芯温度上限65℃
#define SOX_SAMPLE_LOWER_AVG_CELL_TEMP (-40)	//平均电芯温度下限-40℃


//*进入或退出充放电模式的电流，需根据实际项目待机功耗电流调整*/
#define  SOX_ENTER_CHARGE_CURR		500		///< 进入充电模式电流500mA
#define  SOX_EXIT_CHARGE_CURR		100		///< 退出充电模式电流100mA
#define  SOX_ENTER_DISCHARGE_CURR	(-500)	///< 进入放电模式电流-500mA
#define  SOX_EXIT_DISCHARGE_CURR	(-100)	///< 退出放电模式电流-100mA

/**
  * @struct sop_interface_remap_t
  * @brief SOP接口映射
  */
typedef struct
{
    bool (*sox_sample_data_get_cb)(sox_sample_data_t *sample_data);  ///< 本PACK数据获取
}sox_sample_deal_remap_t;

/**
 * @brief		更新计算SOX要用的采样数据，保存最近十次的数据
 * @param[in]	无
 * @return		1，执行成功，0，失败
 * @retval		1,采样数据处理成功
 * @retval		0,采样数据处理失败
 * @warning		无
 * @pre			需要在线程中主动调用，才能更新采样数据
 * @note
*/
int32_t sox_sample_data_proc(void);

/**
 * @brief		设置计算SOX要用的采样数据
 * @param[in]	p_dout，该入参指针用于获取采样数据
 * @return		0，执行成功，非0，失败
 * @retval		0，采样数据设置成功
 * @retval		1，采样数据设置失败
 * @warning		无
 * @pre
 * @note
*/
int32_t sox_sample_data_set(sox_sample_data_t* p_dout);

/**
 * @brief		获取计算SOX要用的采样数据
 * @param[in]	p_dout，该入参指针用于获取采样数据
 * @return		SOX_OK，执行成功；SOX_FAIL，失败
 * @note
*/
int32_t sox_sample_data_get(sox_sample_data_t* p_dout);

/**
 * @brief		设置SOX采样数组
 * @param[in]	p_dout，该入参指针用于获取采样数据
 * @return		0，执行成功，非0，失败
 * @retval		0，采样数据设置成功
 * @retval		1，采样数据设置失败
 * @warning		无
 * @pre
 * @note
*/
void sox_sample_array_set(sox_sample_data_t* p_dout);

/**
* @brief		获取电池状态
* @param		无
* @return		无
* @retval		SOX_BAT_STANDBY：待机状态（0）
* @retval		SOX_BAT_CHARGE：充电状态（1）
* @retval		SOX_BAT_DISCHARGE：放电状态（2）
* @warning		无
*/
sox_bat_status_e sox_bat_state_get(void);

/**
* @brief		设置电池状态
* @param		sox_bat_statu，需要设置的电池的状态
* @return		无
* @warning		无
*/
void sox_bat_state_set(sox_bat_status_e sox_bat_status);

bool sox_sample_deal_init(sox_sample_deal_remap_t *sox_sample_deal_remap);

#endif
