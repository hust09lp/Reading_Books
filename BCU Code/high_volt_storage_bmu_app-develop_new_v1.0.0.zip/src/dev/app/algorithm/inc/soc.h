#ifndef	SOC_H_
#define	SOC_H_
#include <stdint.h>
#include <stdbool.h>
#include "sox_public.h"

/**
 * @brief		SOC流程初始化
 * @param[in]	sox_interface_remap，定制化函数结构体的地址
 * @return		执行结果
 * @note
*/
void soc_proc_init(sox_interface_remap_t sox_interface_remap);

/**
 * @brief		SOC流程
 * @param[in]	无
 * @return		无
 * @note
*/
void soc_proc(void);

/**
 * @brief		获取PACK的SOC显示值
 * @param[in]	无
 * @return		PACK的SOC显示值
 * @note
*/
int32_t soc_pack_display_val_get(void);

/**
 * @brief		获取SOC计算值
 * @param[in]	sel_cmd，命令，选择获取电芯还是PACK
 * @return		获取指定的电芯或者PACK的SOC计算值
 * @note
*/
int32_t soc_calc_val_get(sox_cell_sel_e sel_cmd);

/**
 * @brief		设置SOC计算值
 * @param[in]	sel_cmd，命令，选择设置电芯还是PACK
 * @param[in]	soc_val_temp，需要设置的SOC数值（0~100，整数）
 * @return		0，处理成功；非0，处理失败
 * @note
*/
int32_t soc_calc_val_set(sox_cell_sel_e sel_cmd, int32_t soc_val_temp);

/**
* @brief		滚动记录的5S电芯电压和系统电流值数据对外获取
* @param		void
* @return		sox_scroll_record_data_t 滚动记录数据结构体
* @note
*/
sox_scroll_record_data_t* sox_scroll_record_data_5s_data_get(void);

/**
 * @brief		获取SOC保存标志位
 * @param[in]	无
 * @return		SOC保存标志位
 * @note
*/
uint16_t soc_save_flag_get(void);

/**
* @brief		获取滚动记录的5S电芯电压
* @param		void
* @return		无
* @note
*/
void cell_volt_5s_get(sox_scroll_record_data_t* p_in);

/**
* @brief		获取从CAN读取到的BMU-SOC
* @param		data_in，从CAN读取到的BMU-SOC
* @return		返回int16_t，读取到的BMU-SOC数值
* @note
*/
void sox_get_bmu_soc(uint16_t data_in);


/**
* @brief		发送本地需要向其它BMU传递的BMU-SOC
* @param		无
* @return		返回结果 需要设置的BMU-SOC数值
* @note
*/
uint16_t sox_set_bmu_soc(void);

/**
 * @brief		重置SOC保存标志位
 * @param[in]	无
 * @return		无
 * @note
*/
void soc_save_flag_reset(void);

/**
 * @brief		获取SOC初始化标志位
 * @param[in]	无
 * @return		SOC初始化标志位
 * @retval		SOC初始化标志位
 * @note
 * @pre			无
*/
uint16_t soc_init_flag_get(void);

/**
 * @brief		设置SOX运行数据
 * @param[in]	sox_running_data，需要设置的SOX运行数据的地址
 * @return		true，获取成功；false，获取失败
 * @note
*/
int32_t sox_running_data_set(sox_running_data_t* sox_running_data);

/**
 * @brief		获取SOX运行数据的地址，用于SOX模块内部
 * @param[in]	无
 * @return		返回sox_running_data_t*，全局运行数据的指针
 * @note
*/
sox_running_data_t* sox_running_data_addr_inf(void);

/**
 * @brief		获取本地SOC放电末端校准数据
 * @param[in]	p_out，数据结构体，保存获取到的SOC放电末端校准数据，dsg_cali_data_t* 类型
 * @return		0，执行成功，非0，执行失败
 * @note
*/
int32_t soc_dsg_cali_data_get(dsg_cali_data_t* p_out);

/**
 * @brief       接收BCU下发的SOX放电校准数据
 * @param       [in]void
 * @return      返回结果 uint32_t
 * @warning     无
 */
int32_t sox_dsg_cali_data_set(uint8_t val_type, uint16_t val);

/**
 * @brief		重置SOC模块，除了定制化接口
 * @param[in]	无
 * @return		无
 * @note
*/
void soc_reset(void);

/**
 * @brief		SOC模块级自动化测试
 * @param[in]	step，测试步骤
 * @return		无
 * @note
*/
uint64_t soc_proc_test(int32_t step);

#endif
