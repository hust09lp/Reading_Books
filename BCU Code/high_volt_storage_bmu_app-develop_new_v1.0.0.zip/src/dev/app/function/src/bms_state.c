#include <stdlib.h>
#include "sdk.h"
#include "sdk_public.h"
#include "bms_state.h"
#include "fault_manage.h"
#include "upgrade.h"
#include "auto_addressing.h"
#include "sofar_can_data.h"
#include "bmu_data.h"
#include "public_flag.h"
#include "data_store.h"
#include "sox_public.h"
#include "sop.h"
#include "soh.h"
#include "soc.h"
#include "afe_manage.h"
#include "file_read.h"
#include "ate.h"
#include "state_machine.h"

/******************************interface************************************************/
//todo接口需要完善
#define LIMIT_SOP_ZERO_ENABLE()      sop_curr_limit_set(true) // 充放电限流使能
#define LIMIT_SOP_ZERO_DISABLE()     sop_curr_limit_set(false)  // 充放电限流失能
#define SHUT_DOWN_SAVE_REAL_SOC()    // 休眠存储真实SOC
#define SHUT_DOWN_SAVE_REAL_SOH()    // 休眠存储真实SOH
#define BMU_ACTIVE_BALANCE_DISABLE()   // 屏蔽主动均衡功能
#define BMU_ACTIVE_BALANCE_ENABLE()    // 使能主动均衡功能
#define BMU_PASSIVE_BALANCE_DISABLE()  // 屏蔽被动均衡功能
#define BMU_PASSIVE_BALANCE_ENABLE()   // 使能被动均衡功能
/******************************end******************************************************/

#define BMS_STATE_LOGD(...) 	log_d(__VA_ARGS__)
#define BMS_STATE_LOGE(...) 	log_e(__VA_ARGS__)

#define BMS_WAKE_UP_CAN_STOP_BIT		(0x01 << 0)
#define BMS_UPG_CAN_STOP_BIT			(0x01 << 1)
#define BMS_OTHER_CAN_STOP_BIT 			(0x01 << 3)

static uint8_t g_bmu_state_shell_debug_flag = 0; // 进入boot升级

static uint8_t stop_send_inter_can_flag = BMS_WAKE_UP_CAN_STOP_BIT; // stop_send_inter_can_flag不为0时，CAN不能自动发送

static fault_stat_data_t g_fault_data = {0};

static uint8_t g_bat_mode = BMS_STANDY_MODE;       // 电池状态
static uint8_t g_sys_step = BMS_START_UP;          // BMS系统运行步骤
static uint8_t g_sys_state = BMS_STATE_SELF_CHECK; // BMS系统运行状态

static uint8_t simulate_test_bmu_state_flag = 0;
/********************************BCU系统状态机处理函数声明****************************************/
static uint8_t sta_bms_start_up_entry(void);
static uint8_t sta_bms_start_up_run(void);
static uint8_t sta_bms_self_check_entry(void);
static uint8_t sta_bms_self_check_run(void);
static uint8_t sta_bms_normal_entry(void);
static uint8_t sta_bms_normal_run(void);
static uint8_t sta_bms_pf_error_entry(void);
static uint8_t sta_bms_pf_error_run(void);
static uint8_t sta_bms_upgrade_entry(void);
static uint8_t sta_bms_upgrade_run(void);
static uint8_t sta_bms_shut_down_entry(void);
static uint8_t sta_bms_shut_down_run(void);

/********************************预充状态机使用变量定义****************************************/
static fsm_action_map_t g_bms_sta_act_map[BMS_STA_NUM] = 
{
    [BMS_START_UP]          = {sta_bms_start_up_entry, sta_bms_start_up_run},           // 系统开机
    [BMS_SELF_CHECK]        = {sta_bms_self_check_entry, sta_bms_self_check_run},       // 系统开机自检
    [BMS_NORMAL]            = {sta_bms_normal_entry, sta_bms_normal_run},               // 系统正常运行
    [BMS_PF_ERROR]          = {sta_bms_pf_error_entry, sta_bms_pf_error_run},           // 系统故障
    [BMS_UPGRADE]           = {sta_bms_upgrade_entry, sta_bms_upgrade_run},             // 系统升级过程
    [BMS_SHUT_DOWN]         = {sta_bms_shut_down_entry, sta_bms_shut_down_run},         // 系统关机（复位）过程    
};

static uint8_t g_bms_sta_evt_map[BMS_STA_NUM][EVT_BMS_STA_NUM] = 
{                           // EVT_BMS_START_UP   EVT_BMS_NORMAL    EVT_BMS_PF_ERROR   EVT_BMS_UPGRADE     EVT_BMS_SHUT_DOWN
    [BMS_START_UP]          = {BMS_SELF_CHECK,    STA_NULL,         STA_NULL,          STA_NULL,            BMS_SHUT_DOWN,},
    [BMS_SELF_CHECK]        = {STA_NULL,          BMS_NORMAL,       BMS_PF_ERROR,      BMS_UPGRADE,         BMS_SHUT_DOWN,},
    [BMS_NORMAL]            = {STA_NULL,          STA_NULL,         BMS_PF_ERROR,      BMS_UPGRADE,         BMS_SHUT_DOWN,},
    [BMS_PF_ERROR]          = {STA_NULL,          BMS_NORMAL,       STA_NULL,          BMS_UPGRADE,         BMS_SHUT_DOWN,},
    [BMS_UPGRADE]           = {BMS_SELF_CHECK,    BMS_NORMAL,       BMS_PF_ERROR,      STA_NULL,            BMS_SHUT_DOWN,},
    [BMS_SHUT_DOWN]         = {STA_NULL,          STA_NULL,         STA_NULL,          STA_NULL,            STA_NULL,},    
};

static state_machine_t g_bms_sys_sta_fsm = {0};
static const char *bms_state_fsm_name = "bms_state";
static uint32_t g_start_up_delay_tick = 0;      // 开机tick
static uint32_t g_reset_delay_tick = 0;         // 准备复位tick
static bool g_self_check_finished_flag = false; // bms自检完成标志
static uint8_t g_boot_upgarde_flag = 0;         // 1: 一键进入boot  否则:不进入
static uint8_t g_bmu_shut_down_set = false;		//BCU设置BMU休眠
/**
 * @brief                BMU状态设置
 * @param                [in]state
 * @return               返回结果空
 * @retval               [out]0 成功
 * @warning              仅由sofar_can_data.c调用，用于BCU传输电池状态给BMU使用
 */
int8_t bmu_bat_state_set(uint8_t no, uint16_t state)
{
    if (0xAA != simulate_test_bmu_state_flag)
    {
        g_bat_mode = (uint8_t)state;
    }
    
    return 0;
}

/**
* @brief                BMU关机设置
 * @param                [in]state
 * @return               返回结果空
 * @retval               [out]0 成功
 * @warning              仅由sofar_can_data.c调用，用于BCU传输电池状态给BMU使用
 */
int8_t bmu_shut_down_set(uint16_t state)
{
    if(0xAA == state)
    {
        g_bmu_shut_down_set = true;
    }
    else if (0x55 == state)
    {
        g_bmu_shut_down_set = false;
    }

    return 0;
}

/**
 * @brief		更新电池数据
 * @param		无
 * @return		无
 * @retval		无
 * @warning		无
 */
void bms_state_data_sync(void)
{
    fault_stat_data_t *p_fault_stat_data = (fault_stat_data_t *)fault_chg_dsg_level_get();
    g_fault_data = *p_fault_stat_data;
}

/**
 * @brief		故障检测
 * @param		无
 * @return		返回结果
 * @retval		[out]出现故障：true,  无故障：false
 * @warning		无
 */
uint8_t pf_error_check(void)
{
    uint8_t ret = false;

    if (g_fault_data.max_charge_level <= LEVEL1
        || g_fault_data.max_discharge_level <= LEVEL1)
    {
        ret = true;
    }

    return ret;
}

// 系统开机
static uint8_t sta_bms_start_up_entry(void)
{
    g_sys_step = BMS_START_UP;
    g_sys_state = BMS_STATE_SELF_CHECK;
    // 开机运行前初始化
    auto_addressing_enable(); // 启动自动编址
    g_start_up_delay_tick = sdk_tick_get();

    return EVT_NULL;
}

static uint8_t sta_bms_start_up_run(void)
{
    uint8_t event = EVT_NULL;
    // 等待数据稳定等待1s
    if (true == sdk_is_tick_over(g_start_up_delay_tick, os_tick_from_millisecond(500)))
    {
        fault_diag_enable();                                   // 故障诊断使能
        public_flag_check_on();                                // 开启满充，放空，继电器请求等标志
        stop_send_inter_can_flag &= ~BMS_WAKE_UP_CAN_STOP_BIT; // 使能自动发送CAN
        g_start_up_delay_tick = sdk_tick_get();
        event = EVT_BMS_START_UP;
        BMS_STATE_LOGE("[STA]start2self\n");
    }

    return event;
}

// 系统自检
static uint8_t sta_bms_self_check_entry(void)
{
    g_sys_step = BMS_SELF_CHECK;
    g_sys_state = BMS_STATE_SELF_CHECK;
    g_self_check_finished_flag = false;

    return EVT_NULL;
}

static uint8_t sta_bms_self_check_run(void)
{
    uint8_t event = EVT_NULL;

    // 等待开机自检完成
    if (fault_diag_step_get() > POWER_ON_SELF_TEST)
    {
        g_self_check_finished_flag = true;
        if (false == pf_error_check())
        {
            event = EVT_BMS_NORMAL;
            BMS_STATE_LOGE("[STA]self2run\n");
        }
        else
        {
            BMS_STATE_LOGE("[STA]self2err\n");
            event = EVT_BMS_PF_ERROR;
        }
    }

    if ((UPG_IDLE != upgrade_state_get()) || (g_boot_upgarde_flag)) // 自检过程预留升级接口
    {
        BMS_STATE_LOGE("[STA]self2upg=%d\n", upgrade_state_get());
        event = EVT_BMS_UPGRADE;
    }
    
    if (g_bmu_shut_down_set)
    {
        event = EVT_BMS_SHUT_DOWN;
        BMS_STATE_LOGE("[STA]self2shut\n");
    }    

    return event;
}

static uint8_t sta_bms_normal_entry(void)
{
    g_sys_step = BMS_NORMAL;
    g_sys_state = BMS_STATE_RUN;
    LIMIT_SOP_ZERO_DISABLE();     // 恢复充放电电流
    BMU_ACTIVE_BALANCE_ENABLE();  // 主动均衡使能
    BMU_PASSIVE_BALANCE_ENABLE(); // 被动均衡使能

    return EVT_NULL;
}

static uint8_t sta_bms_normal_run(void)
{
    uint8_t event = EVT_NULL;

    if ((UPG_IDLE != upgrade_state_get()) || (g_boot_upgarde_flag))
    {
        BMS_STATE_LOGE("[STA]run2upg=%d\n", upgrade_state_get());
        event = EVT_BMS_UPGRADE;
    }
    else if (true == pf_error_check())
    {
        BMS_STATE_LOGE("[STA]run2err=%d\n", pf_error_check());
        event = EVT_BMS_PF_ERROR;
    }
    else if (g_bmu_shut_down_set)
    {
        event = EVT_BMS_SHUT_DOWN;
        BMS_STATE_LOGE("[STA]run2shut\n");
    }      

    return event;
}

static uint8_t sta_bms_pf_error_entry(void)
{
    g_sys_step = BMS_PF_ERROR;
    g_sys_state = BMS_STATE_PF_ERROR;
    LIMIT_SOP_ZERO_ENABLE();       // 限流为0状态
    BMU_ACTIVE_BALANCE_DISABLE();  // 主动均衡禁能
    BMU_PASSIVE_BALANCE_DISABLE(); // 被动均衡禁能

    return EVT_NULL;
}

static uint8_t sta_bms_pf_error_run(void)
{
    uint8_t event = EVT_NULL;

    if ((UPG_IDLE != upgrade_state_get()) || (g_boot_upgarde_flag))
    {
        BMS_STATE_LOGE("[STA]err2upg=%d\n", pf_error_check());
        event = EVT_BMS_UPGRADE;
    }
    else if (false == pf_error_check())
    {
        BMS_STATE_LOGE("[STA]err2run=%d\n", pf_error_check());
        event = EVT_BMS_NORMAL;
    }
    else if (g_bmu_shut_down_set)
    {
        event = EVT_BMS_SHUT_DOWN;
        BMS_STATE_LOGE("[STA]err2shut\n");
    }      

    return event;
}

static uint8_t sta_bms_upgrade_entry(void)
{
    g_sys_step = BMS_UPGRADE;
    g_sys_state = BMS_STATE_UPGRADE;
    BMU_ACTIVE_BALANCE_DISABLE();  // 主动均衡禁能
    BMU_PASSIVE_BALANCE_DISABLE(); // 被动均衡禁能
    LIMIT_SOP_ZERO_ENABLE();       // 强制限制电流为0

    return EVT_NULL;
}

static uint8_t sta_bms_upgrade_run(void)
{
    uint8_t event = EVT_NULL;

    if ((UPG_RESET == upgrade_state_get()) || (g_boot_upgarde_flag)) // 升级完成重启
    {
        event = EVT_BMS_SHUT_DOWN;
        BMS_STATE_LOGE("[STA]upg2res\n");
    }
    else if (UPG_IDLE == upgrade_state_get())
    {
        if (pf_error_check())
        {
            BMS_STATE_LOGE("[STA]upg2err\n");
            event = EVT_BMS_PF_ERROR;
        }
        else
        {
            if (g_self_check_finished_flag)
            {
                event = EVT_BMS_NORMAL;
                BMS_STATE_LOGE("[STA]upg2run\n");
            }
            else
            {
                event = EVT_BMS_START_UP;
                BMS_STATE_LOGE("[STA]upg2self\n");
            }
        }
    }
    else
    {
        g_reset_delay_tick = sdk_tick_get();
    }
    
    if (g_bmu_shut_down_set)
    {
        event = EVT_BMS_SHUT_DOWN;
        BMS_STATE_LOGE("[STA]upg2shut\n");
    }    
    
    // 升级状态退出后，重新使能自动编址功能
    if (EVT_NULL != event)
    {
        auto_addressing_enable();
        stop_send_inter_can_flag &= ~BMS_UPG_CAN_STOP_BIT; // 恢复can其他内容数据发送
        BMS_STATE_LOGE("[STA]upg ok,add en\n");
    }

    return event;
}

static uint8_t sta_bms_shut_down_entry(void)
{
//    g_sys_step = BMS_SHUT_DOWN;
//    g_sys_state = BMS_STATE_SHUT_DOWN;
    g_reset_delay_tick = sdk_tick_get();

    return EVT_NULL;
}

static uint8_t sta_bms_shut_down_run(void)
{
    uint8_t event = EVT_NULL;
    static bool first_flag = true;

    if ((true == sdk_is_tick_over(g_reset_delay_tick, os_tick_from_millisecond(500))) && (true == first_flag))
    {
        first_flag = false;
        soh_enforce_refresh();
        sox_running_data_t sox_running_data = *sox_running_data_addr_get();
        bms_sox_runing_data_save(sox_running_data);            
        afe_state_set(AFE_SHUTDOWN_STATE); // afe进入休眠
        fault_manage_init();               // 故障管理初始化
        public_flag_init();                // 公共标志管理初始化
        stop_send_inter_can_flag |= BMS_UPG_CAN_STOP_BIT;
        g_sys_step = BMS_SHUT_DOWN;
        g_sys_state = BMS_STATE_SHUT_DOWN;            
    }
    // 复位
    if (true == sdk_is_tick_over(g_reset_delay_tick, os_tick_from_millisecond(3500)))
    {
        g_reset_delay_tick = sdk_tick_get();	
        sdk_system_reset();
    }


    return event;
}


/**
 * @brief   bcu系统状态机总处理函数
 * @param   无
 * @return  void
 * @warning    无
 */
static void bms_state_switch_sys_sta_proc(void)
{
// todo
#ifdef SINGAL_TEST
    if ((BMS_UPGRADE_PREPARE != g_sys_step) &&
        (BMS_UPGRADE != g_sys_step))
    {
        auto_send_can_sofar_enable_set(true);
    }
#else
    if ((0 == stop_send_inter_can_flag) &&
        (ADDRESSING_FINISH == auto_addressing_get_state()))
    {
        auto_send_can_sofar_enable_set(true);
    }
    else
    {
        auto_send_can_sofar_enable_set(false);
    }
#endif

    // 系统状态切换
    uint8_t event = state_machine_proc(&g_bms_sys_sta_fsm);
    fsm_state_trans(&g_bms_sys_sta_fsm, event);
    // 状态更新发送遥测1数据上报
    static uint8_t last_sys_state = BMS_STATE_NUM;
    if (last_sys_state != g_sys_state)
    {
        // 发送遥信2帧，包含电池包信息
        inner_can_send_msg_ready(BMS_REMOTE_SIGNAL_INFO2);
        last_sys_state = g_sys_state;
    }
}

/**
 * @brief		获取电池状态
 * @param		无
 * @return		电池充放电状态
 * @retval		待机:BMS_STANDY_MODE
 * @retval		充电:BMS_CHARGE_MODE
 * @retval		放电:BMS_DISCHARGE_MODE
 * @warning		无
 */
battery_state_e bms_state_get_bat_sta(void)
{
    return (battery_state_e)g_bat_mode;
}

/**
 * @brief		获取系统状态
 * @param		无
 * @return		系统状态
 * @retval		开机		:BMS_STATE_SELF_CHECK
 * @retval		正常运行		:BMS_STATE_RUN
 * @retval		永久性故障	:BMS_STATE_PF_ERROR
 * @retval		升级		:BMS_STATE_UPGRADE
 * @retval		关机		:BMS_STATE_SHUT_DOWN
 * @warning		无
 */
bms_system_state_e bms_state_get_sys_sta(void)
{
    return (bms_system_state_e)g_sys_state;
}

/**
 * @brief		获取系统状态工步
 * @param		无
 * @return		系统状态
 * @warning		无
 */
bms_system_step_e bms_state_get_sys_sta_step(void)
{
    return (bms_system_step_e)g_sys_step;
}

/**
 * @brief		BMS状态流程
 * @param		无
 * @return		无
 * @retval		无
 * @warning		无
 */
void bms_state_init(void)
{
    g_bat_mode = BMS_STANDY_MODE;
    state_machine_init(&g_bms_sys_sta_fsm, bms_state_fsm_name, g_bms_sta_act_map, (uint8_t *)g_bms_sta_evt_map, EVT_BMS_STA_NUM, BMS_STA_NUM, BMS_START_UP);
}

/**
 * @brief		BMS状态流程
 * @param		无
 * @return		无
 * @retval		无
 * @warning		无
 */
void bms_state_proc(void)
{
    if (special_mode_get(ATUO_TEST))
    {
        return;
    }
    // 一键进入boot标志和获取预充标志
    if (!g_bmu_state_shell_debug_flag)
    {
        g_boot_upgarde_flag = boot_upgrade_flag_get();
    }

    // 更新电池数据
    bms_state_data_sync();
    // BMS状态切换
    bms_state_switch_sys_sta_proc();
}

/********************************************调试代码********************************************************/
/**
 * @brief                BMU运行状态设置
 * @param                [in]state
 * @return               返回结果空
 * @retval               [out]0 成功
 * @warning
 */
int8_t bmu_state_step_set(uint8_t state)
{
    if (0xAA == simulate_test_bmu_state_flag)
    {
        g_sys_step = state;
    }

    return 0;
}

/**
 * @brief                调试打印接口
 * @return               返回结果空
 * @warning              测试调试使用
 */
void bms_state_print_shell_debug(void)
{
    BMS_STATE_LOGD("selfCheck=%d\n", g_self_check_finished_flag);
    BMS_STATE_LOGD("batMode=%d\n", g_bat_mode);
    BMS_STATE_LOGD("sysStep=%d\n", g_sys_step);
    BMS_STATE_LOGD("sysSta=%d\n", g_sys_state);
    BMS_STATE_LOGD("bootUpg=%d\n", g_boot_upgarde_flag);
    BMS_STATE_LOGD("addrId=d\n", auto_addressing_get_address());
    BMS_STATE_LOGD("addrSta=%d\n", auto_addressing_get_state());
    BMS_STATE_LOGD("addrFault=%d\n", auto_addressing_fault_get());
    BMS_STATE_LOGD("size=%d\n", sizeof(bms_record_data_t));
}

/**
 * @brief                调试help打印接口
 * @return               返回结果空
 * @warning              测试调试使用
 */
void bms_state_help_print_shell_debug(void)
{
    //    BMS_STATE_LOGD("state <set> <bat> <val> , val 0:standby 1:charge 2:discharge\n");
    //    BMS_STATE_LOGD("state <set> <bmu> <val>\n");
    //    BMS_STATE_LOGD("0: BMS_START_UP    \n");
    //    BMS_STATE_LOGD("1: BMS_SELF_CHECK\n");
    //    BMS_STATE_LOGD("2: BMS_NORMAL    \n");
    //    BMS_STATE_LOGD("3: BMS_PF_ERROR    \n");
    //    BMS_STATE_LOGD("4: BMS_UPGRADE_PREPARE\n");
    //    BMS_STATE_LOGD("5: BMS_UPGRADE    \n");
    //    BMS_STATE_LOGD("6: BMS_SUPPLE_CHG\n");
    //    BMS_STATE_LOGD("7: BMS_SHUT_DOWN_PREPARE\n");
    //    BMS_STATE_LOGD("8: BMS_SHUT_DOWN\n");
    //
    //    BMS_STATE_LOGD("\ng_sys_state\n");
    //    BMS_STATE_LOGD("BMS_STATE_SELF_CHECK =%d\n", BMS_STATE_SELF_CHECK);
    //    BMS_STATE_LOGD("BMS_STATE_RUN        =%d\n", BMS_STATE_RUN       );
    //    BMS_STATE_LOGD("BMS_STATE_PF_ERROR   =%d\n", BMS_STATE_PF_ERROR  );
    //    BMS_STATE_LOGD("BMS_STATE_UPGRADE    =%d\n", BMS_STATE_UPGRADE   );
    //    BMS_STATE_LOGD("BMS_STATE_SHUT_DOWN  =%d\n", BMS_STATE_SHUT_DOWN );
    //
    //    BMS_STATE_LOGD("\ng_shut_down_type\n");
    //    BMS_STATE_LOGD("BMS_NON_SHUT_DOWN                  = %d\n", BMS_NON_SHUT_DOWN                 );
    //    BMS_STATE_LOGD("BMS_UNDER_VOLT_PRO_REQ_SHUT_DOWN       = %d\n", BMS_UNDER_VOLT_PRO_REQ_SHUT_DOWN      );
    //    BMS_STATE_LOGD("BMS_STANDY_LOW_CELL_VOLT_REQ_SHUT_DOWN = %d\n", BMS_STANDY_LOW_CELL_VOLT_REQ_SHUT_DOWN);

    //    BMS_STATE_LOGD("\nset val type\n");
    //    BMS_STATE_LOGD("BCU_SHUT_DOWN_FLAG     = 1\n");
    //    BMS_STATE_LOGD("BOOT_UPGARDE_FLAG      = 2\n");
    //    BMS_STATE_LOGD("SUPPLE_CHG             = 3\n");
}

/**
 * @brief                调测接口
 * @return               返回结果空
 * @warning              测试调试使用
 */
void bms_state_set_val_shell_debug(uint16_t type, uint32_t val)
{
    if (1 == type)
    {
        g_bmu_state_shell_debug_flag = 1;
        sdk_iap_set_flag(IAP_BACK_BACK);
        g_boot_upgarde_flag = (1 == val) ? 1 : 0;
    }
}

/**
 * @brief                设置BMU状态
 * @return               返回结果空
 * @warning              测试调试使用
 */
void shell_set_bmu_state_proc(char *para2, char *para3)
{
    uint8_t state_index = 0;

    if (NULL != para2 &&
        NULL != para3)
    {
        state_index = atoi(para3);
        if ((!strcmp(para2, "bat")))
        {
            g_bat_mode = state_index;
        }
        else if (!strcmp(para2, "bmu"))
        {
            bmu_state_step_set(state_index);
        }
        else
        {
            BMS_STATE_LOGD("staSetParaErr\n");
        }
    }
    else
    {
        BMS_STATE_LOGD("staSetParaErr\n");
    }
}

int32_t state(int argc, char *argv[])
{
    if (argc < 2)
    {
        BMS_STATE_LOGD("%s para err\n", argv[0]); // 打印命令名称
    }
    else
    {
        if (!strcmp(argv[1], "on")) // 启动控制
        {
            simulate_test_bmu_state_flag = 0xAA;

            BMS_STATE_LOGD("faultTestOnOk\n");
        }
        else if (!strcmp(argv[1], "off")) // 关闭控制
        {
            simulate_test_bmu_state_flag = 0x55;

            BMS_STATE_LOGD("faultTestOffOk\n");
        }
        else if (!strcmp(argv[1], "set"))
        {
            if (0xAA == simulate_test_bmu_state_flag)
            {
                shell_set_bmu_state_proc(argv[2], argv[3]);
            }
            else
            {
                BMS_STATE_LOGD("didNotOpenStaTestMode\n");
            }
        }
        else if (!strcmp(argv[1], "com"))
        {
            if (argc < 3)
            {
                log_d("%s %s para err\n", argv[0], argv[1]);
                return -1;
            }

            if (!strcmp(argv[2], "on"))
            {
                stop_send_inter_can_flag &= ~BMS_WAKE_UP_CAN_STOP_BIT;
                BMS_STATE_LOGD("bmuStateComOn\n");
            }
            else if (!strcmp(argv[2], "off"))
            {
                stop_send_inter_can_flag |= BMS_WAKE_UP_CAN_STOP_BIT;
                BMS_STATE_LOGD("staComOff\n");
            }
            else
            {
                BMS_STATE_LOGD("staTestOperaErr\n");
            }
        }
        else if (!strcmp(argv[1], "print"))
        {
            bms_state_print_shell_debug();
        }
        else if (!strcmp(argv[1], "bug"))
        {
            if (argc < 4)
            {
                log_d("%s %s para err\n", argv[0], argv[1]);
                return -1;
            }

            uint16_t type = atoi(argv[2]); // 参数1：类型给，
            uint32_t val = atoi(argv[3]);  // 参数2：数据
            bms_state_set_val_shell_debug(type, val);
        }
        else if (!strcmp(argv[1], "help"))
        {
            bms_state_help_print_shell_debug();
        }
        else
        {
            BMS_STATE_LOGD("StateTestOperatorErr\n");
        }
    }
    return 0;
}
MSH_CMD_EXPORT(state, <on / off / set type id value / com on(off) / print / bug type value>);
