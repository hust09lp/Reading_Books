#include "sofar_can_manage.h"
#include <stdio.h>
#include <string.h>
#include "sdk.h"
#include "sdk_core.h"
#include "sdk_can.h"
#include "auto_addressing.h"
#include "file_read.h"
#include "app_public.h"

//sdk接口函数的can端口号
#define RCV_SHORT_LEN 	24			//接收buff大小
#define RCV_LONG_LEN     SOFAR_CAN_TRS_BUF_NUMS
#define RCV_FILE_LEN     SOFAR_CAN_FILE_BUF_NUMS
#define MAX_GENERAL_REC_NUM		64		//普通处理的CANID缓冲区大小

static int32_t can_sofar_rcv_frame_proc(void);
static int32_t inner_can_sofar_parse_short_frame(can_frame_data_t  *p_can_frame);
static int32_t rsv_can_sofar_parse_short_frame(can_frame_data_t  *p_can_frame );

typedef struct
{
	can_sofar_rcv_reg_t reg_buff[MAX_GENERAL_REC_NUM];		//普通处理的CANID
	uint16_t reg_cnt;									//记录当前注册的普通处理can数据
}rcv_register_info_t;	//注册接收函数

static rcv_register_info_t g_inner_rcv_reg_info = {0};
static rcv_register_info_t g_rsv_rcv_reg_info = {0};

//static int8_t g_debug_flag = 0;

/** 
 * @brief        打印信息设置函数
 * @param        [in] flag 打印信息设置函数，0不打印，1打印
 * @return       [int32_t] 执行结果
 * @retval       =0  设置成功 
 * @retval       < 0 失败原因
 */
int32_t can_sofar_debug_set(int8_t flag)
{
//    g_debug_flag = flag;

    return (0);
}


#if 0

/**
 * @brief   打印数据
 * @param   [in] p_data  需要打印的数据
 * @param   [in] len  需要打印的数据长度
 * @note    
 * @return  返回执行结果 空
 */
static void data_print(uint8_t *p_data, int32_t len)
{
    if (g_debug_flag == 1)
    {
        log_d("\nCanStart\n");
        for (uint8_t i = 0; i < len; i++)
        {
            log_d("pData=%d\n",p_data[i]);
        }
        log_d("\nCanEnd\n");
    }
}
static void rcv_data_print(uint8_t *p_data, int32_t len)
{
    if (len > CAN_SOFAR_FILE_DATA_MAXNUMS) {
        log_d("errLen=%d\n",len);
        return;
    }
    if (g_debug_flag == 1)
    {
        log_d("\nRcvStart\n");
        for (uint8_t i = 0; i < len; i++)
        {
            log_d("pData=%d\n",p_data[i]);
        }
        log_d("\nRcvEnd\n");
    }
}

/**
 * @brief   计算一包数据可以分成几帧数据
 * @param   [in] pack_len 需要分包数据的长度
 * @param   [in] frame_len 一帧数据的长度
 * @note    
 * @return  返回执行结果 0:正常，可以分帧数量；<0:异常
 */
static uint8_t get_frame_num(uint16_t pack_len, uint16_t frame_len)
{
    uint8_t frame_num = 0;

    frame_num = pack_len / frame_len;
    if((pack_len % frame_len) != 0)
    {
        frame_num++;
    }

    return(frame_num);
}
#endif

/**
 * @brief   发送CAN数据打包发送
 * @param   [in] index  CAN 口编号
 * @param   [in] can_id  CAN ID信息
 * @param   [in] p_data  需要发送的数据
 * @param   [in] len  需要发送的数据长度
 * @note    调用此函数之前需要APP层自己调用打开CAN的SDK接口
 * @return  返回执行结果 0:正常；<0:异常
 * @warn    允许多帧数据发送
 */
int32_t can_sofar_send_frame(uint32_t index, uint32_t can_id, uint8_t *p_data, int32_t len)
{     
    if ((p_data == NULL) || (len < 0))
    {
        return (CAN_RET_PARA_ERR);
    }

    if (len > CAN_SOFAR_DATA_MAXNUMS)
    {
        return (CAN_RET_PARA_ERR);
    }
    can_frame_id_u can_frame_id = { 0 };
    sdk_can_frame_t txframe = {0};

    can_frame_id.id_val = can_id;
    txframe.id = (can_frame_id.id_val & 0x1fffffff); 

    txframe.ide = 1;    // 拓展帧
    txframe.hdr = -1;
    
    // 单帧发送
    if (len <= CAN_MAX_DATA_LEN_ONE_FRAME)
    {
        memcpy(&(txframe.data[0]), p_data, len);
        txframe.len = len;
        sdk_can_write(index, &txframe, 1);
    }
    else // 多帧发送，主要用于文件上传
    {
        uint8_t frame_max_cnt = (len + CAN_MAX_DATA_LEN_ONE_FRAME - 1) / CAN_MAX_DATA_LEN_ONE_FRAME;
        uint8_t frame_len = 0;
        for (uint8_t frame_cnt = 0; frame_cnt < frame_max_cnt; frame_cnt++)
        {
            // 最后一帧处理
            if (frame_cnt == (frame_max_cnt - 1))
            {
                // 计算最后一帧的长度
                frame_len = ((len % CAN_MAX_DATA_LEN_ONE_FRAME) == 0) ? CAN_MAX_DATA_LEN_ONE_FRAME : len % CAN_MAX_DATA_LEN_ONE_FRAME;
            }
            else
            {
                frame_len = CAN_MAX_DATA_LEN_ONE_FRAME; // 默认长度
            }
            // 复制需要发送的数据
            memcpy(&(txframe.data[0]), &p_data[frame_cnt * CAN_MAX_DATA_LEN_ONE_FRAME], frame_len);
            txframe.len = frame_len;
            // data_print(txframe.data, frame_len);   //打印数据
            sdk_can_write(index, &txframe, 1);
        }
    }

    return (0);
}

/**
* @brief		初始化can管理
* @param		无
* @return		返回结果
* @retval		0：成功    < 0: 失败
* @warning		无 
*/
int32_t can_sofar_manage_init(void)
{
	//初始化CAN
	sdk_can_cfg_t can_cfg = 
	{
		.baud = SDK_CAN_BAUD_250K,
		.mode = SDK_CAN_MODE_NORMAL,
	};
	
	sdk_can_init();
    sdk_can_open(SDK_INTERNAL_CAN_PORT);
    sdk_can_setup(SDK_INTERNAL_CAN_PORT, &can_cfg);
    sdk_can_open(SDK_RSV_CAN_PORT);
    sdk_can_setup(SDK_RSV_CAN_PORT, &can_cfg);    
	
	//初始化所有全局变量
	memset(&g_inner_rcv_reg_info,	0, sizeof(rcv_register_info_t));
    memset(&g_rsv_rcv_reg_info,	0, sizeof(rcv_register_info_t));
	can_sofar_debug_set(false);
	return 0;
}

/**
* @brief		can管理流程
* @param		无 
* @return		无
* @retval		无
* @warning		无
*/
void can_sofar_manage_proc(void)
{
	can_sofar_rcv_frame_proc();
}

/**
* @brief		读取can硬件缓冲区数据，1ms周期轮询
* @param		无
* @return		返回结果
* @retval		0：添加成功    < 0: 添加失败
* @warning		无 
*/
static int32_t can_sofar_rcv_frame_proc(void)
{
	sdk_can_frame_t can_msg_data = {0};
    can_frame_data_t can_short;
    can_frame_id_u can_frame_id;
	int32_t ret = 0;
	int32_t len = 0;

	/************************************内CAN*************************************************/
	// hdr 值为 - 1，表示直接从 uselist 链表读取数据 
	
	for(uint8_t i = 0; i < CAN_SOFAR_RCV_DATA_MAX_NUM_ONE_TIME; i++)
	{
		can_msg_data.hdr = -1;  // hdr 值为 - 1，表示直接从 uselist 链表读取数据 
//		len = sdk_can_read( SDK_INTERNAL_CAN_PORT,  &can_msg_data, sizeof(can_msg_data), 0 );	
		len = sdk_can_read( SDK_INTERNAL_CAN_PORT,  &can_msg_data, 1, 0 );	
		if(len <= 0)
		{
			break;
		}
		//log_d("%x,%x,%x,%x,%x,%x,%x,%x,%x\n",can_msg_data.id,can_msg_data.data[0],can_msg_data.data[1],can_msg_data.data[2],can_msg_data.data[3],can_msg_data.data[4],can_msg_data.data[5],can_msg_data.data[6],can_msg_data.data[7]);
        can_frame_id.id_val = can_msg_data.id; 

        // 过滤除相同地址心跳帧的bmu帧或者目标地址非广播且不符合板号的报文
        if (((DEV_BMU == can_frame_id.bit.src_type)&&((FUNC_HEART_BEAT_CMD != can_frame_id.bit.fun_code) ||(FUNC_HEART_BEAT_CMD == can_frame_id.bit.fun_code && can_frame_id.bit.src_addr != auto_addressing_get_address())))
            || ((can_frame_id.bit.dst_addr != BROADCAST_DEVICE_ADDRESS)&&(can_frame_id.bit.dst_addr != auto_addressing_get_address())))
        {
            continue;
        }
        can_short.id = can_msg_data.id;
        can_short.data_len = can_msg_data.len;
        memcpy(can_short.data, &(can_msg_data.data[0]), can_msg_data.len);
        inner_can_sofar_parse_short_frame(&can_short);
    }

	for(uint8_t i = 0; i < CAN_SOFAR_RCV_DATA_MAX_NUM_ONE_TIME; i++)
	{
		can_msg_data.hdr = -1;  // hdr 值为 - 1，表示直接从 uselist 链表读取数据 
//		len = sdk_can_read( SDK_INTERNAL_CAN_PORT,  &can_msg_data, sizeof(can_msg_data), 0 );	
		len = sdk_can_read( SDK_RSV_CAN_PORT,  &can_msg_data, 1, 0 );	
		if(len <= 0)
		{
			break;
		}
		//log_d("%x,%x,%x,%x,%x,%x,%x,%x,%x\n",can_msg_data.id,can_msg_data.data[0],can_msg_data.data[1],can_msg_data.data[2],can_msg_data.data[3],can_msg_data.data[4],can_msg_data.data[5],can_msg_data.data[6],can_msg_data.data[7]);
        can_frame_id.id_val = can_msg_data.id; 
        can_short.id = can_msg_data.id;
        can_short.data_len = can_msg_data.len;
        memcpy(can_short.data, &(can_msg_data.data[0]), can_msg_data.len);
        rsv_can_sofar_parse_short_frame(&can_short);
    }    
	return ret;
}

/**
* @brief		判断接收的ID的目标地址是否为电池,源地址是否为指定设备
* @param		[in]接收到的ID
* @param		[in]注册ID的掩码
* @return		返回结果
* @retval		0：成功    < 0: 失败
* @warning		无
*/

#define NO_FLITER_MASK		0xFF	//掩码为0xFF，即收到id的目标地址与预设id的目标地址不一致
#define NO_ADDR_MASK		0x1F	//掩码为0x1F，即收到id的目标地址与预设id的目标地址不一致,设备类型一致
#define FLITER_MASK			0x00	//掩码为0x00，即收到id的目标地址必须与预设的id目标地址完全一致
//static int32_t check_pack_address(uint32_t target_id, uint32_t mask_id)
//{
//	int32_t res = 0;
//    uint8_t id_tag = 0;
//	uint8_t id_dev_type = 0;
//    uint8_t id_dev_addr = 0;
//	uint8_t mask_id_tag = 0;
//	uint8_t pack_addr = auto_addressing_get_address();

//	id_tag = (uint8_t)(target_id >> 8);
//	id_dev_type = (uint8_t)((id_tag >> 5) & 0x7);
//	id_dev_addr = (uint8_t)(id_tag & 0x1F);
//	mask_id_tag = (uint8_t)(mask_id >> 8);
//	
//	//如果id的目标地址掩码为0xFF,则默认只允许 0x00，0x80等广播类型和本机pack的id:81
//    //如果id的目标地址掩码为0x1F,则默认只允许 0x80广播类型和本机pack的id:81 
//	if (((NO_FLITER_MASK == mask_id_tag) && (BROADCAST_DEVICE_TYPE_ADDRESS == id_tag || (DEV_BMU == id_dev_type && ((pack_addr == id_dev_addr) || (BROADCAST_DEVICE_ADDRESS == id_dev_addr)))))
//        || ((NO_ADDR_MASK == mask_id_tag) && ((pack_addr == id_dev_addr) || (BROADCAST_DEVICE_ADDRESS == id_dev_addr)))
//        || ((FLITER_MASK == mask_id_tag) ))
//	{
//		res = 0;
//	}
//	else
//	{
//		res = -1;
//	}

//	return res;
//}
/**
* @brief		对比接收的ID是否和注册的ID一致
* @param		[in]接收到的ID
* @param		[in]注册的ID
* @param		[in]注册ID的掩码
* @return		返回结果
* @retval		0：成功    < 0: 失败
* @warning		无
*/
#ifndef CAN_GET_BIT
#define CAN_GET_BIT( data, offset )	( ((uint32_t)data >> offset )  & 0x00000001)
#endif
static int32_t compare_id(uint32_t target_id, uint32_t reg_id, uint32_t id_mask)
{
	int32_t res = 0;
	uint8_t i = 0;
	
	for(i = 0; i < 32; i++)
	{
		if( 0 == CAN_GET_BIT(id_mask , i) )		//掩码位置为1时，不做对比
		{
			if( CAN_GET_BIT( reg_id, i ) == CAN_GET_BIT( target_id, i ) )
			{
				continue;
			}
			else
			{
				res = -1;
				break;
			}
		}
		else
		{
			continue;
		}
	}
	
	return res;
}
/**
* @brief		处理已注册进来的CAN帧，跳转到各自注册的回调函数中
* @param		[in] CAN端口	外部CAN：EXTERNAL_CAN  /  内部CAN：INTERNAL_CAN  
* @param		[in] 数据帧内容
* @return		返回结果
* @retval		0：成功    < 0: 失败
* @warning		无
*/
static int32_t inner_can_sofar_parse_short_frame(can_frame_data_t  *p_can_frame )
{
	uint16_t i = 0;
	
	if(NULL == p_can_frame)
	{
		return -1;
	}

    for(i = 0; i < g_inner_rcv_reg_info.reg_cnt && i < MAX_GENERAL_REC_NUM; i++)
    {
        //1、判断是已注册的id
        //2、判断接收的id是否为广播地址或本机pack地址
        if( (0 == compare_id(p_can_frame->id , g_inner_rcv_reg_info.reg_buff[i].id, g_inner_rcv_reg_info.reg_buff[i].id_mask)) 
            /*&& (0 == check_pack_address(p_can_frame->id, g_inner_rcv_reg_info.reg_buff[i].id_mask)) */)                    //  此判断由硬件过滤完成
        {
            if(NULL != g_inner_rcv_reg_info.reg_buff[i].p_can_cb)
            {
                g_inner_rcv_reg_info.reg_buff[i].p_can_cb(p_can_frame);
                break;
            }
        }
        else
        {
            continue;
        }
    }
    return 0;
}


/**
* @brief		处理已注册进来的CAN帧，跳转到各自注册的回调函数中
* @param		[in] CAN端口	外部CAN：EXTERNAL_CAN  /  内部CAN：INTERNAL_CAN  
* @param		[in] 数据帧内容
* @return		返回结果
* @retval		0：成功    < 0: 失败
* @warning		无
*/
static int32_t rsv_can_sofar_parse_short_frame(can_frame_data_t  *p_can_frame )
{
	uint16_t i = 0;
	
	if(NULL == p_can_frame)
	{
		return -1;
	}

    for(i = 0; i < g_rsv_rcv_reg_info.reg_cnt && i < MAX_GENERAL_REC_NUM; i++)
    {
        //1、判断是已注册的id
        //2、判断接收的id是否为广播地址或本机pack地址
        if( (0 == compare_id(p_can_frame->id , g_rsv_rcv_reg_info.reg_buff[i].id, g_rsv_rcv_reg_info.reg_buff[i].id_mask)) 
            /*&& (0 == check_pack_address(p_can_frame->id, g_inner_rcv_reg_info.reg_buff[i].id_mask)) */)                    //  此判断由硬件过滤完成
        {
            if(NULL != g_rsv_rcv_reg_info.reg_buff[i].p_can_cb)
            {
                g_rsv_rcv_reg_info.reg_buff[i].p_can_cb(p_can_frame);
                break;
            }
        }
        else
        {
            continue;
        }
    }
    return 0;
}

/**
* @brief		注册can接收回调函数
* @param		[in] port：	外部CAN：EXTERNAL_CAN  /  内部CAN：INTERNAL_CAN  
* @param		[in] urgent_flag:紧急处理标志  GENERAL_FRAME:接收到数据正常响应速度10ms ，URGENT_FRAME:接收数据快速响应1ms
* @param		[in] p_can_rec_reg ：
* @param		[in] id：can帧id 
* @param		[in] id：id_mask：过滤不需要接收的位(标准帧的掩码mask固定为0x00000000,拓展帧的掩码mask目标地址设置为FF代表能接收0xFF,0x1F,pack_addr三种类型地址)
* @param		[in] id：can_cb：回调解析函数 
* @param		[in] reg_cnt：注册的数量 
* @return		返回结果
* @retval		0：注册成功    < 0: 注册失败
* @warning		禁止重复注册同一个ID
* @warning		标准帧注册掩码必须为0x00000000
* @warning		掩码不可为0xFFFFFFFF
*/
int32_t inner_can_sofar_register_receive_frame(can_sofar_rcv_reg_t * p_can_rec_reg, uint16_t reg_cnt)
{
    if (NULL == p_can_rec_reg)
    {
        return -1;		//输入参数有误，返回失败
    }   
	if((0 == p_can_rec_reg->id )			||
		(0xFFFFFFFF == p_can_rec_reg->id_mask)	||
		(NULL == p_can_rec_reg->p_can_cb))
	{
		return -1;		//输入参数有误，返回失败
	}
    int32_t ret = 0;

	for(uint16_t i = 0; i < reg_cnt; i++)
	{
		if( g_inner_rcv_reg_info.reg_cnt < MAX_GENERAL_REC_NUM)		//判断已经注册数量是否大于最大允许注册的数量
		{
			memcpy(g_inner_rcv_reg_info.reg_buff + g_inner_rcv_reg_info.reg_cnt, p_can_rec_reg + i , sizeof(can_sofar_rcv_reg_t));
		}
		else
		{
			ret = -2;
			return ret;	//注册数量大于总数，则返回失败	
		}
		
		g_inner_rcv_reg_info.reg_cnt++;	//已经注册的数量计数			
	}

	return ret;
}


/**
* @brief		注册can接收回调函数
* @param		[in] port：	外部CAN：EXTERNAL_CAN  /  内部CAN：INTERNAL_CAN  
* @param		[in] urgent_flag:紧急处理标志  GENERAL_FRAME:接收到数据正常响应速度10ms ，URGENT_FRAME:接收数据快速响应1ms
* @param		[in] p_can_rec_reg ：
* @param		[in] id：can帧id 
* @param		[in] id：id_mask：过滤不需要接收的位(标准帧的掩码mask固定为0x00000000,拓展帧的掩码mask目标地址设置为FF代表能接收0xFF,0x1F,pack_addr三种类型地址)
* @param		[in] id：can_cb：回调解析函数 
* @param		[in] reg_cnt：注册的数量 
* @return		返回结果
* @retval		0：注册成功    < 0: 注册失败
* @warning		禁止重复注册同一个ID
* @warning		标准帧注册掩码必须为0x00000000
* @warning		掩码不可为0xFFFFFFFF
*/
int32_t rsv_can_sofar_register_receive_frame(can_sofar_rcv_reg_t * p_can_rec_reg, uint16_t reg_cnt)
{
    if (NULL == p_can_rec_reg)
    {
        return -1;		//输入参数有误，返回失败
    }   
	if((0 == p_can_rec_reg->id )			||
		(0xFFFFFFFF == p_can_rec_reg->id_mask)	||
		(NULL == p_can_rec_reg->p_can_cb))
	{
		return -1;		//输入参数有误，返回失败
	}
    int32_t ret = 0;

	for(uint16_t i = 0; i < reg_cnt; i++)
	{
		if( g_rsv_rcv_reg_info.reg_cnt < MAX_GENERAL_REC_NUM)		//判断已经注册数量是否大于最大允许注册的数量
		{
			memcpy(g_rsv_rcv_reg_info.reg_buff + g_rsv_rcv_reg_info.reg_cnt, p_can_rec_reg + i , sizeof(can_sofar_rcv_reg_t));
		}
		else
		{
			ret = -2;
			return ret;	//注册数量大于总数，则返回失败	
		}
		
		g_rsv_rcv_reg_info.reg_cnt++;	//已经注册的数量计数			
	}

	return ret;
}


/**
* @brief		can过滤器设置
* @param		无  
* @return		无
* @retval		无
* @warning		无
*/
void can_set_filter(uint8_t addr)
{
    sdk_can_filter_item_t items[3] =
    {   
        CAN_FILTER_ITEM_INIT(0x00000000, 1, 0, 0, 0x0000FF00), // ext_msg、data_msg、mask_method    目标地址为该设备
        CAN_FILTER_ITEM_INIT(0x0000FF00, 1, 0, 0, 0x0000FF00), // ext_msg、data_msg、mask_method    目标地址为所有设备广播
        CAN_FILTER_ITEM_INIT(0x00000000, 1, 0, 0, 0x0000FF00), // ext_msg、data_msg、mask_method    目标地址为BMU类设备广播
    };
    sdk_can_filter_t cfg = {3, 1, items}; // 一共有 3 个过滤表 
    // 过滤除相同地址心跳帧的bmu帧或者目标地址非广播且不符合板号的报文
    items[0].id |= (uint32_t)(DEV_BMU << 5 | addr) << 8;
    items[2].id |= (uint32_t)(DEV_BMU << 5 | BROADCAST_DEVICE_ADDRESS) << 8;
    log_d("filter:%d\n",sdk_can_set_filter(SDK_INTERNAL_CAN_PORT,&cfg));
}
