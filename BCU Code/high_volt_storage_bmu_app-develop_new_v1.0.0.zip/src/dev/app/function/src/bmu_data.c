/**
 * @file     bmu_data.c
 * @brief    bmu数据采样文件
 * @company  sofarsolar
 * @author   
 * @note     综合所有采样模拟量
 * @version
 * @date     2023/4/27 初稿
 */
 
#include <string.h>
#include <stdlib.h>
#include "sofar_errors.h"
#include "sample.h"
#include "afe_manage.h"
#include "sdk.h"
#include "sofar_errors.h"
#include "bmu_data.h"
#include "app_public.h"
#include "fault_manage.h"
#include "passive_balance.h" 

#ifdef SIMULATION_DATA_TEST
static uint8_t simulate_test_flag = 0;				//模拟测试标志
#endif

#define RECORD_HISTORY_TEMP_NUM  12         // 12个点，60s
#define CELLP_TEMP_RISE_ABNORMAL_VAL  (100) // 10℃

static bmu_data_t g_bmu_data = { 0 };              // 电池采样数据
static uint8_t g_cell_temp_rise_abnormal_flag = false;            ///< 电芯温度升温异常标志 1：异常，0：正常
static int16_t g_max_temp_list[RECORD_HISTORY_TEMP_NUM] = {0x7FFF};

/**
* @brief                获取升温异常标志
* @param                [in]无
* @return               1：异常，0：正常
* @warning              
*/
uint8_t cell_temp_rise_abnormal_get(void)
{
    return g_cell_temp_rise_abnormal_flag;
}

/**
* @brief                计算数组的最小
* @param                [in]数据buff
* @param                [in]实际数据长度len
* @param                [in]最大数据长度max_len
* @return               >=0最大差值 , <0:异常
* @warning              
*/
int16_t calc_max_min_val_in_array(int16_t *buff, uint8_t len, uint8_t max_len)
{
    if (NULL == buff || len > max_len)
    {
        return I16_INVALID_VALUE;
    }
    int16_t min_val = I16_INVALID_VALUE;
    for (uint8_t i = 0; i < len; i++)
    {
        if (I16_INVALID_VALUE == buff[i])
        {
            continue;
        }
        if (I16_INVALID_VALUE == min_val)
        {
            min_val = buff[i];
        }
        else
        {

            if (min_val > buff[i])
            {
                min_val = buff[i];
            }
        }
    }
    return (min_val);
}

/**
* @brief                判断是否升温异常处理
* @param                [in]无
* @return               无返回结果
* @warning              10ms任务
*/
void cell_temp_rise_abnormal_judge(void)
{
    static uint16_t five_sec_timer = 0;
    five_sec_timer++;
    if (five_sec_timer < 500)
    {
        return;
    }
    five_sec_timer = 0;
    // 5s取一个点
    static uint32_t record_num = 0;
    uint8_t oldest_index = (record_num) % RECORD_HISTORY_TEMP_NUM;
    g_max_temp_list[oldest_index] = g_bmu_data.max_cell_temp;
    record_num++;
    if (record_num > 1)  // 去掉第一个点，防止温度数据还没赋值
    {
        // 1min内温度上升大于10℃
        int16_t history_min_temp = calc_max_min_val_in_array(g_max_temp_list, ITEM_NUM(g_max_temp_list), RECORD_HISTORY_TEMP_NUM);
        if (history_min_temp == I16_INVALID_VALUE || g_bmu_data.max_cell_temp == I16_INVALID_VALUE)
        {
            return;
        }
        int16_t diff_temp = g_bmu_data.max_cell_temp - history_min_temp;
        if (diff_temp > CELLP_TEMP_RISE_ABNORMAL_VAL)
        {
            g_cell_temp_rise_abnormal_flag = 1;
        }
        else
        {
            g_cell_temp_rise_abnormal_flag = 0;
        }
    }
}

/**
* @brief		获取单体电压最大最小值
* @param		[in] 无
* @return		[out]无
* @retval		 无
*/
static void cell_volt_extremum_get(void)
{
    uint8_t    i;
    uint8_t    valid_num = 0;
    uint8_t    min_cell_volt_num = 0;
    uint8_t    max_cell_volt_num = 0;
    uint16_t   min_cell_volt_tmp = U16_INVALID_VALUE;
    uint16_t   max_cell_volt_tmp = U16_INVALID_VALUE;
    uint16_t   cell_volt = 0;
    uint32_t   cell_volt_sum = 0;
    
    for (i = 0; i < CELL_VOLT_NUM; i++)
    {
        cell_volt = g_bmu_data.cell_volt[i];  // AFE采集到的单体电压
        if (U16_INVALID_VALUE == cell_volt)
        {
            continue;
        }
        valid_num++;
        if (1 == valid_num)
        {
            max_cell_volt_tmp = cell_volt;
            max_cell_volt_num = i + 1;
            min_cell_volt_tmp = cell_volt;
            min_cell_volt_num = i + 1;
        }
        else
        {
            if (cell_volt > max_cell_volt_tmp) //获取最大单体电压
            {
                max_cell_volt_tmp = cell_volt;
                max_cell_volt_num = i + 1;
            }
            if (cell_volt < min_cell_volt_tmp)//获取最小单体电压
            {
                min_cell_volt_tmp = cell_volt;
                min_cell_volt_num = i + 1;
            }
        }
        cell_volt_sum += cell_volt;        //48节电芯总压
    }
    g_bmu_data.max_cell_volt = max_cell_volt_tmp;                   //最大单体电压
    g_bmu_data.min_cell_volt = min_cell_volt_tmp;                   //最小单体电压
    g_bmu_data.diff_cell_volt = max_cell_volt_tmp - min_cell_volt_tmp;  //最大单体电压与最小单体电压之间的压差
    if (0 != valid_num)
    {
        g_bmu_data.avg_cell_volt = (uint16_t)(cell_volt_sum / valid_num); //单体平均电压
        g_bmu_data.bat_acc_volt = cell_volt_sum;  //电池累计电压
    }
    else
    {
        g_bmu_data.avg_cell_volt = U32_INVALID_VALUE;
        g_bmu_data.bat_acc_volt = U32_INVALID_VALUE;
    }
    g_bmu_data.max_volt_num = max_cell_volt_num;                         //最大单体电压序号
    g_bmu_data.min_volt_num = min_cell_volt_num;                         //最小单体电压序号

    for(int i = 0; i < CELL_VOLT_NUM; i ++)
    {
        g_bmu_data.bal_stus[i / 16] |= ((cell_balance_pos_get()[i / AFE_CELL_VOLT_NUM] >> (i % AFE_CELL_VOLT_NUM)) & 0x01) << (i % 16); 
    }
}


/**
* @brief		获取单体温度最大最小值
* @param		[in] 无
* @return		[out]无
* @retval		 无
*/
static void cell_temp_extremum_get(void)
{
    uint8_t i;
    uint8_t valid_num = 0;
    uint8_t max_cell_temp_num = 0;
    uint8_t min_cell_temp_num = 0;
    int16_t max_cell_temp_tmp = I16_INVALID_VALUE;
    int16_t min_cell_temp_tmp = I16_INVALID_VALUE;
    int32_t cell_temp_sum = 0;
    int16_t cell_temperature = 0;
    
    for (i = 0; i < CELL_TEMP_NUM; i++)
    {
        cell_temperature = g_bmu_data.cell_temp[i];  // AFE采集到的单体温度
        if (I16_INVALID_VALUE == cell_temperature)
        {
            continue;
        }
        valid_num++;
        if (1 == valid_num)
        {
            max_cell_temp_tmp = cell_temperature;
            min_cell_temp_tmp = cell_temperature;
            max_cell_temp_num = i + 1;
            min_cell_temp_num = i + 1;
        }
        else
        {
            if(cell_temperature > max_cell_temp_tmp)				// 获取最大单体温度
            {
                max_cell_temp_tmp = cell_temperature;
                max_cell_temp_num = i + 1;
            }
            if(cell_temperature < min_cell_temp_tmp)				//获取最小单体温度
            {
                min_cell_temp_tmp = cell_temperature;
                min_cell_temp_num = i + 1;
            }
        }
        cell_temp_sum += cell_temperature;// 48节电芯总温度 
    }
    g_bmu_data.min_cell_temp = min_cell_temp_tmp;
    g_bmu_data.max_cell_temp = max_cell_temp_tmp;
    g_bmu_data.max_temp_num  = max_cell_temp_num;
    g_bmu_data.min_temp_num  = min_cell_temp_num;
    g_bmu_data.diff_cell_temp = max_cell_temp_tmp - min_cell_temp_tmp;
    if (0 != valid_num)
    {
        g_bmu_data.avg_cell_temp = cell_temp_sum / valid_num;
    }
    cell_temp_rise_abnormal_judge();
}

/**
* @brief                BMS信息数据初始化
* @param                [in]无
* @return               无返回结果
* @warning              无
*/
void bmu_data_init(void)
{
    uint8_t i = 0;
    g_bmu_data.sys_current                         = 0;
    g_bmu_data.bcu_current                         = 0;
    for (i = 0; i < CELL_VOLT_NUM; i++)
    {
        g_bmu_data.cell_volt[i]            = U16_INVALID_VALUE;
    }
    for (i = 0; i < CELL_TEMP_NUM; i++)
    {
        g_bmu_data.cell_temp[i]            = I16_INVALID_VALUE;
    }
    g_bmu_data.bat_afe_volt                        = U32_INVALID_VALUE;
    g_bmu_data.bat_acc_volt                        = U32_INVALID_VALUE;
    g_bmu_data.max_cell_volt                       = U32_INVALID_VALUE;
    g_bmu_data.min_cell_volt                       = U32_INVALID_VALUE;
    g_bmu_data.avg_cell_volt                       = U32_INVALID_VALUE;
    g_bmu_data.diff_cell_volt                      = U32_INVALID_VALUE;
    g_bmu_data.max_volt_num                        = 0;
    g_bmu_data.min_volt_num                        = 0;
    g_bmu_data.max_temp_num                        = 0;
    g_bmu_data.min_temp_num                        = 0;
    g_bmu_data.max_cell_temp                       = I16_INVALID_VALUE;
    g_bmu_data.min_cell_temp                       = I16_INVALID_VALUE;
    g_bmu_data.avg_cell_temp                       = I16_INVALID_VALUE;
    g_bmu_data.diff_cell_temp                      = I16_INVALID_VALUE;
    for (i = 0; i < OTHER_NTC_NUM; i++)
    {
        g_bmu_data.adc_sample_other_temp[i]= I16_INVALID_VALUE;
    }
    g_bmu_data.check_5v_volt                       = U32_INVALID_VALUE;
    g_bmu_data.check_24v_volt                      = U32_INVALID_VALUE;
    g_bmu_data.hardware_version_volt               = U32_INVALID_VALUE;
    for (i = 0; i < RECORD_HISTORY_TEMP_NUM; i++)
    {
        g_max_temp_list[i] = I16_INVALID_VALUE;
    }
}

/**
* @brief                获取BMS数据信息
* @param                [in]无
* @return               返回结果 bmu_data_t*
* @retval               ret(!=NULL)获取成功
* @retval               ret(NULL)获取失败
* @warning              必须判断返回指针
*/
const bmu_data_t* bmu_data_p_get(void)
{
    return &g_bmu_data;
}

/**
* @brief		获取AFE采集的数据
* @param		[in] 无
* @return		[out]无
* @retval		 无
*/
#define DEFAULT_FILTER_NUM (10)
#define DEFAULT_FILTER_MAX_NUM (100)
#define AFE_POS(num) (i*(num) + j)	//单体数据在包内位置
static void afe_data_get(void)
{
    uint8_t  i = 0;
//    static int32_t filter_cell_temp_sum[CELL_TEMP_NUM] = {0};
//    static uint8_t filter_cell_temp_cnt[CELL_TEMP_NUM] = {0};
    static uint32_t temp_get_tick = 0;
    const afe_collect_t *p_afe_collect = NULL; // 这里修改为指针获取方式
    p_afe_collect = p_afe_collect_data_get();
    if (NULL == p_afe_collect)
    {
        return;
    }
    uint16_t cell_id = 0;
    uint32_t acc_volt_temp = 0;
    for(i = 0; i < AFE_NUM; i++)
    {
        for(uint8_t j = 0; j < AFE_CELL_VOLT_NUM; j++)		//AFE单体电压
        {
            cell_id = AFE_POS(AFE_CELL_VOLT_NUM);
            // afe电芯电压采样可能采样为负值，并且默认值为0x8000
            // afe电压采样不增加一阶滤波，原因原本采样周期都要200ms，告警保护需要及时响应
            if (p_afe_collect[i].cell_volt[j] != I16_INVALID_VALUE)
            {
                g_bmu_data.cell_volt[cell_id] = (p_afe_collect[i].cell_volt[j] > 0) ? (uint16_t)p_afe_collect[i].cell_volt[j] : 0;
            }
            else
            {
                g_bmu_data.cell_volt[cell_id] = U16_INVALID_VALUE;
            }
        }
        acc_volt_temp += p_afe_collect[i].battery_volt; //AFE总压
    }
    
    if(0 != acc_volt_temp)
    {
        g_bmu_data.bat_afe_volt = acc_volt_temp;        
    }

    // afe温度采样100ms获取一次
    if (false == sdk_is_tick_over(temp_get_tick, os_tick_from_millisecond(100)))
    {
        return;
    }
    temp_get_tick = sdk_tick_get();
    
    for(i = 0; i < AFE_NUM;i++)
    {
        for(uint8_t j = 0; j < AFE_CELL_TEMP_NUM; j++)	    //AFE单体温度
        {
            cell_id = AFE_POS(AFE_CELL_TEMP_NUM);
            if (I16_INVALID_VALUE != p_afe_collect[i].cell_temp[j])
            {
//                if (I16_INVALID_VALUE == g_bmu_data.cell_temp[cell_id])
                {
                    uint8_t cell_temp_wire_err_no = get_cell_temp_wire_err_no();    //判断温度采集线是否有异常
                    if((cell_temp_wire_err_no != U8_INVALID_VALUE)      
                        && (cell_temp_wire_err_no == cell_id)
                        && (FAULT_STOP == fault_state_get(BOARD_CELL_TEMP_SAM_FAULT))
                        )                    
                    {
                        g_bmu_data.cell_temp[cell_id] = g_bmu_data.avg_cell_temp;
                    }
                    else
                    {
                        g_bmu_data.cell_temp[cell_id] = p_afe_collect[i].cell_temp[j];  // 第一次计算，直接赋值                        
                    }

//                    filter_cell_temp_sum[cell_id] = g_bmu_data.cell_temp[cell_id] * DEFAULT_FILTER_NUM;
//                    filter_cell_temp_cnt[cell_id] = DEFAULT_FILTER_NUM;
                }
//                else
//                {
//                    filter_cell_temp_sum[cell_id] += p_afe_collect[i].cell_temp[j];
//                    filter_cell_temp_cnt[cell_id]++;
//                    if (filter_cell_temp_cnt[cell_id] >= DEFAULT_FILTER_MAX_NUM)
//                    {
//                        filter_cell_temp_sum[cell_id] = filter_cell_temp_sum[i] * DEFAULT_FILTER_NUM / filter_cell_temp_cnt[i];
//                        filter_cell_temp_cnt[cell_id] = DEFAULT_FILTER_NUM;
//                    }
//                    g_bmu_data.cell_temp[cell_id] = (filter_cell_temp_sum[cell_id] + filter_cell_temp_cnt[cell_id] / 2 - 1) / filter_cell_temp_cnt[cell_id];
//                }
            }
            else
            {
                g_bmu_data.cell_temp[cell_id] = I16_INVALID_VALUE;
            }
        }
        // 增加的其他温度采样
        // 均衡温度
        for(uint8_t j = 0;j < AFE_BALANCE_TEMP_NUM;j++)
        {
            cell_id = AFE_POS(AFE_BALANCE_TEMP_NUM);
            if (I16_INVALID_VALUE != p_afe_collect[i].balance_temp[j])
            {
                g_bmu_data.adc_sample_other_temp[OTHER_BAL_RES_NTC1+cell_id] = p_afe_collect[i].balance_temp[j];
            }
            else
            {
                g_bmu_data.adc_sample_other_temp[OTHER_BAL_RES_NTC1+cell_id] = I16_INVALID_VALUE;
            }
        }
        
        g_bmu_data.adc_sample_other_temp[OTHER_POWER_NTC1] = p_afe_collect[0].pwr_temp[0];  //固定第1个afe和第4个afe去采
        g_bmu_data.adc_sample_other_temp[OTHER_POWER_NTC2] = p_afe_collect[3].pwr_temp[0];

        
        // 保留温度，暂时不采不赋值
//        for(uint8_t j = 0;j < AFE_CHANNEL1_OTHER_TEMP_NUM;j++)
//        {
//            if (I16_INVALID_VALUE != p_afe_collect[i].channel1_other_temp[j])
//            {
//                g_bmu_data.adc_sample_other_temp[OTHER_RES_NTC1 + i*AFE_NUM] = p_afe_collect->channel1_other_temp[j];
//            }
//            else
//            {
//                g_bmu_data.adc_sample_other_temp[OTHER_RES_NTC1 + i*AFE_NUM] = I16_INVALID_VALUE;
//            }
//        }
//        
//        for(uint8_t j = 0;j < AFE_CHANNEL2_OTHER_TEMP_NUM;j++)
//        {
//            if (I16_INVALID_VALUE != p_afe_collect[i].channel2_other_temp[j])
//            {
//                g_bmu_data.adc_sample_other_temp[OTHER_RES_NTC2 + i*AFE_NUM] = p_afe_collect->channel2_other_temp[j];
//            }
//            else
//            {
//                g_bmu_data.adc_sample_other_temp[OTHER_RES_NTC2 + i*AFE_NUM] = I16_INVALID_VALUE;
//            }
//        }
    }
}

/**
* @brief		获取MCU采集的数据
* @param		[in] 无
* @return		[out]无
* @retval		 无
*/
static void mcu_sample_data_get(void)
{
	const sample_data_t *mcu_sample_data = NULL;
	mcu_sample_data = sample_data_p_get();
    if (NULL == mcu_sample_data)
    {
        return;
    }
    g_bmu_data.adc_sample_other_temp[OTHER_ENV_NTC] = mcu_sample_data->adc_sample_other_temp[MCU_PCB_TEMP_NTC];
    g_bmu_data.check_5v_volt 			= mcu_sample_data->check_5v_volt;
	g_bmu_data.check_24v_volt 			= mcu_sample_data->check_24v_volt;
	g_bmu_data.hardware_version_volt 	= mcu_sample_data->hardware_version_volt;
    g_bmu_data.sys_current = g_bmu_data.bcu_current;
    g_bmu_data.electrolyte_strength = mcu_sample_data->electrolyte_sensor_data.electrolyte_stren;
}

/**
 * @brief                BMS信息数据任务
 * @param                [in]void
 * @return               返回结果空
 * @retval               [out]无
 * @warning              放在10ms任务，必须要调用bms_data_init()后使用
 */
void bmu_data_proc(void)
{
	#ifndef SIMULATION_DATA_TEST
	//MCU采样数据获取
	mcu_sample_data_get();
	
	//AFE数据获取
	afe_data_get();

	//单体电压极值获取
	cell_volt_extremum_get();

	//单体温度极值获取
	cell_temp_extremum_get();
	
	#else
	
	if(0xAA != simulate_test_flag)	//测试模式下不更新
	{
		//MCU采样数据获取
		mcu_sample_data_get();
		
		//AFE数据获取
		afe_data_get();
	}
	//单体电压极值获取
	cell_volt_extremum_get();

	//单体温度极值获取
	cell_temp_extremum_get();
	
	#endif
}

/**
 * @brief                BMU电流数据设置
 * @param                [in]current_value
 * @return               返回结果空
 * @retval               [out]0 成功
 * @warning              仅由sofar_can_data.c调用，用于BCU传输电流数据给BMU使用
 */
int8_t bmu_sys_current_data_set(uint8_t no,int16_t current)
{
	#ifndef SIMULATION_DATA_TEST
		g_bmu_data.sys_current = (int16_t)current * 10;    // 协议下发的单位10mA 转换成1mA
	#else
	if(0xAA != simulate_test_flag)
	{
        g_bmu_data.bcu_current = (int32_t)current * 10;  // 协议下发的单位10mA 转换成1mA
	}		
	#endif
	
	return 0;
}

/**
 * @brief                BMU电流数据返回
 * @param                [in]no
 * @return               返回结果空
 * @retval               [out]0 成功
 * @warning              仅由sofar_can_data.c调用，用于BMU传输电流数据给BCU使用
 */
uint16_t bmu_sys_current_data_get(uint8_t no)
{
	#ifndef SIMULATION_DATA_TEST
		g_bmu_data.sys_current = (int16_t)current * 10;    // 协议下发的单位10mA 转换成1mA
	#else
	if(0xAA != simulate_test_flag)
	{
        return (int16_t)(g_bmu_data.bcu_current/10);
	}		
	#endif

	return 0;
}

/**
 * @brief      采样异常状态获取
 * @param      [in]other_ntc_type_e（只能查询片内）
 * @return     返回结果
 * @retval     [out]ret(SAMPLE_STATE_OK)  获取采集状态成功
 * @retval     [out]ret(SAMPLE_STATE_EOI) 获取采集状态失败
 * @retval     [out]ret(NTC_SHORT_CIRCUIT) NTC短路
 * @retval     [out]ret(NTC_OPEN_CIRCUIT)  NTC开路
 * @warning    在采集任务开始以后调用
 */
int32_t sample_abnormal_get(other_ntc_type_e type)
{
    int32_t ret = SAMPLE_STATE_OK;

    switch(type)
    {
        case OTHER_ENV_NTC:
        default:
            ret = SAMPLE_STATE_EOI;
            break;
    }
    return ret;
}


/********************************************调试代码********************************************************/

#ifdef SIMULATION_DATA_TEST

/**
 * @brief                bmu数据设置
 * @return               返回结果空
 * @warning              测试调试使用
 */
void set_bmu_data_test(bmu_data_t bmu_data)
{
	if(0xAA == simulate_test_flag)
	{
		memcpy(&g_bmu_data , &bmu_data , sizeof(bmu_data_t));
	}
}

/**
 * @brief                BMU数据打印
 * @return               返回结果空
 * @warning              测试调试使用
 */
void bmu_data_printf(void)
{
    log_d("bcuCur=%.2fA\n",	(float)g_bmu_data.bcu_current/1000							);
	log_d("sysCur=%.2fA\n",	(float)g_bmu_data.sys_current/1000							);
	log_d("envTmp=%.1fC\n", (float)g_bmu_data.adc_sample_other_temp[OTHER_ENV_NTC]/10 	);
	// log_e("dcdc_tmp1=%.1fC\n", (float)g_bmu_data.adc_sample_other_temp[OTHER_DCDC_NTC1]/10 	);
	log_d("balTmp1=%.1fC\n", (float)g_bmu_data.adc_sample_other_temp[OTHER_BAL_RES_NTC1]/10 	);
	log_d("balTmp2=%.1fC\n", (float)g_bmu_data.adc_sample_other_temp[OTHER_BAL_RES_NTC2]/10 	);
	log_d("balTmp3=%.1fC\n", (float)g_bmu_data.adc_sample_other_temp[OTHER_BAL_RES_NTC3]/10 	);
	log_d("balTmp4=%.1fC\n", (float)g_bmu_data.adc_sample_other_temp[OTHER_BAL_RES_NTC4]/10 	);
	log_d("balTmp5=%.1fC\n", (float)g_bmu_data.adc_sample_other_temp[OTHER_BAL_RES_NTC5]/10 	);
	log_d("balTmp6=%.1fC\n", (float)g_bmu_data.adc_sample_other_temp[OTHER_BAL_RES_NTC6]/10 	);
	log_d("balTmp7=%.1fC\n", (float)g_bmu_data.adc_sample_other_temp[OTHER_BAL_RES_NTC7]/10 	);
	log_d("balTmp8=%.1fC\n", (float)g_bmu_data.adc_sample_other_temp[OTHER_BAL_RES_NTC8]/10 	);    
    log_d("powTmp1=%.1fC\n", (float)g_bmu_data.adc_sample_other_temp[OTHER_POWER_NTC1]/10 	);
    log_d("powTmp2=%.1fC\n", (float)g_bmu_data.adc_sample_other_temp[OTHER_POWER_NTC2]/10 	);
    log_d("5v=%ldmV\n", g_bmu_data.check_5v_volt                  		);
	log_d("24v=%ldmV\n", g_bmu_data.check_24v_volt                  		); 
	log_d("hwVerV=%ldmV, hwVer=%d\n", g_bmu_data.hardware_version_volt, hardware_ver_get());
	log_d("cellTmpRiseAb=%ld\n", g_cell_temp_rise_abnormal_flag        	);
}

void cell_data_print(void)
{
    log_d("afeV=%.2fV\n",	(float)g_bmu_data.bat_afe_volt/1000            				);
    log_d("batAccV=%.2fV\n",	(float)g_bmu_data.bat_acc_volt/1000            				);
    log_d("maxCellV=%ldmV\n",	g_bmu_data.max_cell_volt           				);
    log_d("minCellV=%ldmV\n",	g_bmu_data.min_cell_volt           				);
    log_d("avgCellV=%ldmV\n",	g_bmu_data.avg_cell_volt           				);
    log_d("diffCellV=%ldmV\n",	g_bmu_data.diff_cell_volt          				);
    log_d("maxVid=%ld\n", 	g_bmu_data.max_volt_num            				);
	log_d("minVid=%ld\n", 	g_bmu_data.min_volt_num                    		);
	log_d("maxTmpId=%ld\n", 	g_bmu_data.max_temp_num                    		);
	log_d("minTmpId=%ld\n", 	g_bmu_data.min_temp_num                    		);
	log_d("maxCellTmp=%.1fC\n", (float)g_bmu_data.max_cell_temp/10                   	);
	log_d("minCellTmp=%.1fC\n", (float)g_bmu_data.min_cell_temp/10                   		);
	log_d("avgCellTTmp=%.1fC\n", (float)g_bmu_data.avg_cell_temp/10                  	    );
	log_d("diffCellTmp=%.1fC\n", (float)g_bmu_data.diff_cell_temp/10                   		);
    log_d("\ncell_v:\n");
    const afe_collect_t *p_afe_collect = NULL; // 这里修改为指针获取方式
    p_afe_collect = p_afe_collect_data_get();
    if (NULL == p_afe_collect)
    {
        return;
    }
    
    uint8_t i,cell_id;
    for(i = 0; i < AFE_NUM; i++)
    {
        for(uint8_t j = 0; j < AFE_CELL_VOLT_NUM; j++)		//AFE单体电压
        {
            cell_id = AFE_POS(AFE_CELL_VOLT_NUM);         
            log_d("V%d=%ldmV,%ldmV\n", cell_id+1, g_bmu_data.cell_volt[cell_id],p_afe_collect[i].cell_volt[j]);
            os_delay(2);
        }
    }    
    log_d("\ncell_tmp:\n");
	for(i = 0; i < AFE_NUM; i++)
	{
        for(uint8_t j = 0; j < AFE_CELL_TEMP_NUM; j++)		//AFE单体温度
        {
            cell_id = AFE_POS(AFE_CELL_TEMP_NUM); 
            log_d("T%d=%.1fC\n", cell_id+1 , (float)g_bmu_data.cell_temp[cell_id]/10				);
            os_delay(2);            
        }

	}
}

/**
 * @brief                数据读取
 * @return               返回结果空
 * @warning              测试调试使用
 */
//atoi(para1_char);
//if(!strcmp(para1_char1, "read_data"))
int32_t bmu_print(int argc, char *argv[])
{
	if (argc < 2)
	{
        log_d("%s para err\n", argv[0]);		//打印命令名称
	}	
    else
    {
        if (!strcmp(argv[1], "cell"))
        {
            cell_data_print();
        }
        else if (!strcmp(argv[1], "other"))
        {
            bmu_data_printf();
        }
    }

    return 0;
}
MSH_CMD_EXPORT(bmu_print, <cell/other>);

void shell_set_bmu_data_proc(char *para2, char *para3, char *para4)
{
	uint8_t i = 0;
	uint8_t para_index = 0;
	uint8_t num = 0;
	int32_t data = 0;

	if (NULL != para2 &&
		NULL != para3 &&
		NULL != para4)
	{
		para_index = atoi(para2);
		num = atoi(para3);
		data = atoi(para4);
		
		switch(para_index)
		{
			case 0:		//单体电压
			{	
				if(0 == num)	//写入所有电压值
				{
					for(i = 0;i < CELL_VOLT_NUM;i++)
					{
						g_bmu_data.cell_volt[i] = (uint16_t)data;
					}
				}
				else if(num > 0 && num <= CELL_VOLT_NUM)	//写入单个电压值
				{
					g_bmu_data.cell_volt[num-1] = (uint16_t)data;
				}
				else
				{
					log_d("bmu_data set para error \n");
				}
				
				g_bmu_data.bat_afe_volt = g_bmu_data.bat_acc_volt;
				cell_data_print();
				break;
			}
			case 1:		//单体温度
			{
				if(0 == num || num > CELL_TEMP_NUM)
				{
					for(i = 0;i < CELL_TEMP_NUM;i++)
					{
						g_bmu_data.cell_temp[i] = (int16_t)data*10;
					}
				}
				else if(num > 0 && num <= CELL_TEMP_NUM)	//写入单个温度值
				{
					g_bmu_data.cell_temp[num-1] = (int16_t)data*10;
				}
				else
				{
					log_d("bmu_data set para error \n");
				}
				
				cell_data_print();
				break;

			}
			case 2:		//BMU电流
			{
				g_bmu_data.sys_current = (int32_t)data;
				bmu_data_printf();
				break;
			}
			case 3:		//主动均衡电流
			{
				bmu_data_printf();
				break;
			}
			case 4:		//均衡温度
			{
				if(0 == num || num > BALANCE_TEMP_NUM)
				{
					for(i = 0;i < BALANCE_TEMP_NUM;i++)
					{
						g_bmu_data.adc_sample_other_temp[OTHER_BAL_RES_NTC1+i] = (int16_t)data*10;
					}
				}
				else if(num > 0 && num <= BALANCE_TEMP_NUM)	//写入单个温度值
				{
					g_bmu_data.adc_sample_other_temp[OTHER_BAL_RES_NTC1+num-1] = (int16_t)data*10;
				}
				else
				{
					log_d("bmu_data set para error \n");
				}
				
				bmu_data_printf();
				break;

			}
			case 5:		//端子温度
			{
				if(0 == num || num > OTHER_NTC_NUM)
				{
					for(i = 0;i < 2;i++)
					{
						g_bmu_data.adc_sample_other_temp[MCU_OTHER_TEMP_START+i] = (int16_t)data*10;
					}
				}
				else if(num > 0 && num <= OTHER_NTC_NUM)	//写入单个温度值
				{
					g_bmu_data.adc_sample_other_temp[MCU_OTHER_TEMP_START+num-1] = (int16_t)data*10;
				}
				else
				{
					log_d("bmu_data set para error \n");
				}
				
				bmu_data_printf();
				break;

			}
			case 6:		// bcu下发电流
			{
				g_bmu_data.bcu_current = (int32_t)data;
				bmu_data_printf();
				break;
			}
            case 7:		// 直采电压
			{
				g_bmu_data.bat_afe_volt = (int32_t)data;
				cell_data_print();
				break;
			}
			case 8:
			{
				for(i = 0;i < CELL_TEMP_NUM;i++)
				{
					g_bmu_data.cell_temp[i] = (int16_t)25*10;
				}
				
				for(i = 0;i < CELL_VOLT_NUM;i++)
				{
					g_bmu_data.cell_volt[i] = (uint16_t)3567;
				}
				
				g_bmu_data.bcu_current = (int32_t)10000;
				
				break;
			}
			default: 
				break;
		}
	}
	else
	{
		log_d("bmu_data set para error \n");
	}
}

/**
 * @brief                进入BMU测试模式
 * @return               返回结果空
 * @warning              测试调试使用
 */
//atoi(para1_char);
//if(!strcmp(para1_char1, "read_data"))
int32_t bmu_test(int argc, char *argv[])
{
	
	log_d("%s start\n", argv[0]);		//打印命令名称
	
	if (argc < 2)
	{
		log_d("bmudata debug para err\n");
	}
    else
	{
		if(!strcmp(argv[1], "on"))		//启动控制
		{
			simulate_test_flag = 0xAA;
			
			log_d("sim_test on OK\n");
		}
		else if(!strcmp(argv[1], "off"))	//关闭控制
		{
			simulate_test_flag = 0x55;
			
			log_d("sim_test off OK\n");
		}
		else if(!strcmp(argv[1], "set"))
		{
			if(0xAA == simulate_test_flag)
			{
				shell_set_bmu_data_proc(argv[2], argv[3], argv[4]);
			}
			else
			{
				log_d("did not open sim_test mode \n");
			}
		}
		else
		{
			log_d("sim_test operator ERROR \n");
		}
	}
	
	
	
    return 0;
}
MSH_CMD_EXPORT(bmu_test, <on/off/set type id value>);
#endif
