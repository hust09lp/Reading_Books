#include <string.h>
#include "sdk.h"
#include "afe_bq79600_comm.h"
#include "afe_bq79600.h"
/**
 * @note 宏定义
 */
#define AFE_COM_LOGD(...) log_d(__VA_ARGS__)
#define AFE_COM_LOGE(...) log_e(__VA_ARGS__)
#define AFE_COM_LOGW(...) log_w(__VA_ARGS__)
#define AFE_SPI_PORT SPI1_ID // 虚拟接口，由core提供
#define AFE_79600_MOSI_IO_INIT 0x1000
#define AFE_79600_MOSI_IO_CTRL 0x1001
#define MOSI_LOW 0
#define MOSI_HIGH 1
#define SPI_NSS_LOW() sdk_dido_write(DO_5_BQ79600_SPI_NSS, false)
#define SPI_NSS_HIGH() sdk_dido_write(DO_5_BQ79600_SPI_NSS, true)
#define SPI_RDY_READ() sdk_dido_read(DI_5_BQ79600_SPI_RDY)

#define WRITE_DATA(buf, len) sdk_spi_write(AFE_SPI_PORT, (buf), (len))
#define READ_DATA(buf, len) sdk_spi_read(AFE_SPI_PORT, (buf), (len))

#define WRITE_DELAY_MS 1 // ms
#define DELAY_MS(ms) os_delay(os_tick_from_millisecond(ms))

#define READ_MAX_BYTE 128
#define WRITE_MAX_BYTE 8
#define WRITE_BUFF_LEN 20							  // 8 + 6 = 14
#define READ_BACK_LEN (WRITE_BUFF_LEN * TOTAL_BOARDS) // 写入后回读判断数据是否写入成功
#define BUF_SIZE 132								  // 128byts data + 2bytes CRC + 1byte Finit + 1res
/**
 * @note 全局变量定义
 */
const uint16_t crc16_table[256] = {0x0000, 0xC0C1, 0xC181, 0x0140, 0xC301,
								   0x03C0, 0x0280, 0xC241, 0xC601, 0x06C0, 0x0780, 0xC741, 0x0500, 0xC5C1,
								   0xC481, 0x0440, 0xCC01, 0x0CC0, 0x0D80, 0xCD41, 0x0F00, 0xCFC1, 0xCE81,
								   0x0E40, 0x0A00, 0xCAC1, 0xCB81, 0x0B40, 0xC901, 0x09C0, 0x0880, 0xC841,
								   0xD801, 0x18C0, 0x1980, 0xD941, 0x1B00, 0xDBC1, 0xDA81, 0x1A40, 0x1E00,
								   0xDEC1, 0xDF81, 0x1F40, 0xDD01, 0x1DC0, 0x1C80, 0xDC41, 0x1400, 0xD4C1,
								   0xD581, 0x1540, 0xD701, 0x17C0, 0x1680, 0xD641, 0xD201, 0x12C0, 0x1380,
								   0xD341, 0x1100, 0xD1C1, 0xD081, 0x1040, 0xF001, 0x30C0, 0x3180, 0xF141,
								   0x3300, 0xF3C1, 0xF281, 0x3240, 0x3600, 0xF6C1, 0xF781, 0x3740, 0xF501,
								   0x35C0, 0x3480, 0xF441, 0x3C00, 0xFCC1, 0xFD81, 0x3D40, 0xFF01, 0x3FC0,
								   0x3E80, 0xFE41, 0xFA01, 0x3AC0, 0x3B80, 0xFB41, 0x3900, 0xF9C1, 0xF881,
								   0x3840, 0x2800, 0xE8C1, 0xE981, 0x2940, 0xEB01, 0x2BC0, 0x2A80, 0xEA41,
								   0xEE01, 0x2EC0, 0x2F80, 0xEF41, 0x2D00, 0xEDC1, 0xEC81, 0x2C40, 0xE401,
								   0x24C0, 0x2580, 0xE541, 0x2700, 0xE7C1, 0xE681, 0x2640, 0x2200, 0xE2C1,
								   0xE381, 0x2340, 0xE101, 0x21C0, 0x2080, 0xE041, 0xA001, 0x60C0, 0x6180,
								   0xA141, 0x6300, 0xA3C1, 0xA281, 0x6240, 0x6600, 0xA6C1, 0xA781, 0x6740,
								   0xA501, 0x65C0, 0x6480, 0xA441, 0x6C00, 0xACC1, 0xAD81, 0x6D40, 0xAF01,
								   0x6FC0, 0x6E80, 0xAE41, 0xAA01, 0x6AC0, 0x6B80, 0xAB41, 0x6900, 0xA9C1,
								   0xA881, 0x6840, 0x7800, 0xB8C1, 0xB981, 0x7940, 0xBB01, 0x7BC0, 0x7A80,
								   0xBA41, 0xBE01, 0x7EC0, 0x7F80, 0xBF41, 0x7D00, 0xBDC1, 0xBC81, 0x7C40,
								   0xB401, 0x74C0, 0x7580, 0xB541, 0x7700, 0xB7C1, 0xB681, 0x7640, 0x7200,
								   0xB2C1, 0xB381, 0x7340, 0xB101, 0x71C0, 0x7080, 0xB041, 0x5000, 0x90C1,
								   0x9181, 0x5140, 0x9301, 0x53C0, 0x5280, 0x9241, 0x9601, 0x56C0, 0x5780,
								   0x9741, 0x5500, 0x95C1, 0x9481, 0x5440, 0x9C01, 0x5CC0, 0x5D80, 0x9D41,
								   0x5F00, 0x9FC1, 0x9E81, 0x5E40, 0x5A00, 0x9AC1, 0x9B81, 0x5B40, 0x9901,
								   0x59C0, 0x5880, 0x9841, 0x8801, 0x48C0, 0x4980, 0x8941, 0x4B00, 0x8BC1,
								   0x8A81, 0x4A40, 0x4E00, 0x8EC1, 0x8F81, 0x4F40, 0x8D01, 0x4DC0, 0x4C80,
								   0x8C41, 0x4400, 0x84C1, 0x8581, 0x4540, 0x8701, 0x47C0, 0x4680, 0x8641,
								   0x8201, 0x42C0, 0x4380, 0x8341, 0x4100, 0x81C1, 0x8081, 0x4040};

/**
 * @note 全局变量初始化
 */
uint8_t g_frame[BUF_SIZE];
/**
 * @note 函数声明
 */
static uint16_t calc_crc16(uint8_t *buf, int32_t len);
/**
 * @note 内部函数定义
 */
int32_t mosi_io_init(void)
{
	uint8_t parma = 0xFF;

	sdk_spi_ioctl(AFE_SPI_PORT, AFE_79600_MOSI_IO_INIT, &parma); // 初始化MOSI为普通IO口

	return 0;
}

int32_t mosi_io_ctrl(uint8_t flag)
{
	uint8_t parma = 0xFF;

	if (MOSI_HIGH == flag)
	{
		parma = 1;
		sdk_spi_ioctl(AFE_SPI_PORT, AFE_79600_MOSI_IO_CTRL, &parma);
	}
	else if (MOSI_LOW == flag)
	{
		parma = 0;
		sdk_spi_ioctl(AFE_SPI_PORT, AFE_79600_MOSI_IO_CTRL, &parma);
	}
	else
	{
		return -1;
	}

	return 0;
}

int32_t is_spi_rdy_pin_ready(void)
{
	static uint32_t delay_tick = 0;
	int32_t read_spi_rdy_pin = 0;

	read_spi_rdy_pin = SPI_RDY_READ();
	delay_tick = sdk_tick_get();
	while (0 == read_spi_rdy_pin)
	{
		if ((true == sdk_is_tick_over(delay_tick, os_tick_from_millisecond(200))))
		{
			AFE_COM_LOGD("[AFE_COMM]:spi_rdy_pin_ready error\n");
			return -1;
		}
		DELAY_MS(1);
		read_spi_rdy_pin = SPI_RDY_READ();
	}

	return 0;
}

void bq79600_wakeup(void)
{
	sdk_spi_close(AFE_SPI_PORT);	//先把spi外设关闭

	mosi_io_init();

	for (uint8_t i = 0; i < 2; i++) // 重复执行2次
	{
		DELAY_MS(2);

		sdk_dido_write(DO_5_BQ79600_SPI_NSS, 0);
		sdk_delay_us(1);

		mosi_io_ctrl(MOSI_LOW); // MOSI 低电平持续2.7-3ms，唤醒
		DELAY_MS(2);
		sdk_delay_us(250);
		sdk_delay_us(250);
		sdk_delay_us(250);
		mosi_io_ctrl(MOSI_HIGH);

		sdk_delay_us(2);
		sdk_dido_write(DO_5_BQ79600_SPI_NSS, 1);
	}
}

// 通讯外设初始化
int32_t bq79600_communication_init(void)
{
	sdk_spi_config_t config = {0};

	if (0 != sdk_spi_open(AFE_SPI_PORT))
	{
		AFE_COM_LOGW("[AFE_COMM]afe_spi_open error\n");
		return -1;
	}

	config.work_mode = SPI_MASTER;
	config.trans_mode = SPI_MODE_0;
	config.data_width = SPI_8BIT;
	config.first_bit = SPI_FIRSTBIT_MSB;
	config.max_hz = 5 * 1000 * 1000;

	if (0 != sdk_spi_setup(AFE_SPI_PORT, &config))
	{
		AFE_COM_LOGW("[AFE_COMM]afe_spi_setup error\n");
		return -2;
	}

	return 0;
}

void bq79600_comm_clear(void)
{
	uint8_t i = 0;
    WRITE_DATA(&i, 1);
	AFE_COM_LOGW("[AFE]:comm clear\n");
}

static int32_t write_frame(uint8_t dev_id, uint16_t addr, uint8_t *buf, uint8_t write_len, uint8_t operate_type)
{
	int32_t len = 0;
	int32_t ret = 0;
	uint16_t crc_ret;
	uint8_t *temp_buf = g_frame;

	memset(g_frame, 0x7F, sizeof(g_frame));
	*temp_buf++ = 0x80 | (operate_type) | ((operate_type & 0x10) ? write_len - 0x01 : 0x00); // read type(1byte)
	if (operate_type == FRMWRT_SGL_R || operate_type == FRMWRT_SGL_W)
	{
		*temp_buf++ = (dev_id & 0x00FF); // ID(1byte)
	}
	*temp_buf++ = (addr & 0xFF00) >> 8; // address(2byte)
	*temp_buf++ = addr & 0x00FF;

	while (write_len--) // data
	{
		*temp_buf++ = *buf++;
	}

	len = temp_buf - g_frame;
	crc_ret = calc_crc16(g_frame, len); // CRC(2byte)
	*temp_buf++ = crc_ret & 0x00FF;
	*temp_buf++ = (crc_ret & 0xFF00) >> 8;
	len += 2;

	ret = WRITE_DATA(g_frame, (uint32_t)len);

	return ret;
}

int32_t write_reg(uint8_t dev_id, uint16_t addr, uint64_t val, uint64_t target_val, uint8_t write_len, uint8_t operate_type)
{
	uint16_t read_board_index = 0;
	uint8_t temp_buf[WRITE_BUFF_LEN] = {0};
	uint8_t res_buf[READ_BACK_LEN] = {0};
	uint8_t read_board_count = 0;
	uint8_t i = 0;

	if ((write_len > WRITE_MAX_BYTE) || (write_len <= 0))
	{
		AFE_COM_LOGW("[AFE_COMM]:write_reg error %d\n", 1);
		return -1;
	}
	// MCU以及BQ79616均为小端模式，暂不考虑大小端处理，后续需要再增加
	memcpy(temp_buf, &val, write_len);
	if (0 > write_frame(dev_id, addr, temp_buf, write_len, operate_type))
	{
		AFE_COM_LOGW("[AFE_COMM]:write_reg error %d\n", 2);
		return -2;
	}
	if (target_val == NOT_NEED_CHECK)
	{
		return 0;
	}

	DELAY_MS(1);

	// 回读数据是否一致，判断是否已经写进去
	if (0 > read_reg(dev_id, addr, res_buf, write_len, (operate_type - 0x10), WRITE_DELAY_MS))
	{
		AFE_COM_LOGW("[AFE_COMM]:write_reg error %d\n", 3);
		return -3;
	}
	// read type (single, broadcast, stack)
	if ((operate_type - 0x10) == FRMWRT_SGL_R)
	{
		read_board_count = 1;
	}
	else if ((operate_type - 0x10) == FRMWRT_STK_R)
	{
		read_board_count = current_stack_boards_get();
	}
	else if ((operate_type - 0x10) == FRMWRT_ALL_R)
	{
		read_board_count = current_stack_boards_get() + 1;
	}
	else
	{
		AFE_COM_LOGW("[AFE_COMM]:write_reg error %d\n", 4);
		read_board_count = 0;
		return -4;
	}

	memcpy(temp_buf, &target_val, write_len);
	for (i = 0; i < read_board_count; i++)
	{
		read_board_index = (write_len + READ_DATA_INDEX + CRC_DATA_COUNT) * i;
		if (0 != memcmp(temp_buf, &res_buf[READ_DATA_INDEX + read_board_index], write_len))
		{
			AFE_COM_LOGW("[AFE_COMM]:write_reg error %d!!!\n", 5);
			return -5;
		}
	}

	return 0;
}

static int32_t read_data(uint8_t *buf, uint32_t read_len)
{
	int32_t ret = 0;

	SPI_NSS_LOW();
	ret = READ_DATA(buf, read_len);
	SPI_NSS_HIGH();

	return ret;
}

static int32_t read_frame(uint8_t dev_id, uint16_t addr, uint8_t read_len, uint8_t operate_type)
{
	uint8_t len = 0;

	if (read_len > READ_MAX_BYTE)
	{
		AFE_COM_LOGW("[AFE_COMM]:read_frame error %d\n", 1);

		return -1;
	}
	len = read_len - 1;

	return write_frame(dev_id, addr, &len, 1, operate_type);
}

int32_t read_reg(uint8_t dev_id, uint16_t addr, uint8_t *buf, uint8_t read_len, uint8_t operate_type, uint32_t delay_ms)
{
	int32_t ret = 0;
	uint16_t crc = 0;
	uint16_t address = 0;
	uint16_t len_index = 0;
	uint16_t real_len = 0; // 实际一次读取数据长度
	uint16_t total_len = 0;
	uint16_t total_len_quotient = 0;			// 商数
	uint16_t total_len_remain = 0;				// 余数
	uint16_t crc_index = 0, crc_calc_index = 0; // crc校验的索引值
	uint8_t read_board_count = 0;
	uint8_t i = 0;
	// 防止设备编号不是0,并且不是单个读取,因为正常不会这样查询并且难处理，暂时先默认异常
	if (0 != dev_id && FRMWRT_SGL_R != operate_type)
	{
		AFE_COM_LOGW("[AFE_COMM]:read_reg error %d\n", 1);
		return -1;
	}

	// 判断设备ID合法性
	if (dev_id >= TOTAL_BOARDS)
	{
		AFE_COM_LOGW("[AFE_COMM]:read_reg error %d\n", 1);
		return -1;
	}

	ret = read_frame(dev_id, addr, read_len, operate_type);
	if (0 > ret)
	{
		AFE_COM_LOGW("[AFE_COMM]:read_reg error %d\n", 2);
		AFE_COM_LOGW("[AFE_COMM]:read_frame error = %d\n", ret);
		return -2;
	}

	// 判断SPI_RDY是ready状态
	if (0 != is_spi_rdy_pin_ready())
	{
		AFE_COM_LOGW("[AFE_COMM]:read_reg %x error %d\n", addr, 3);
		return -3;
	}
	// read type (single, broadcast, stack)
	if (operate_type == FRMWRT_SGL_R)
	{
		total_len = (read_len + 6);
		read_board_count = 1;
	}
	else if (operate_type == FRMWRT_STK_R)
	{
		total_len = (read_len + 6) * (current_stack_boards_get());
		read_board_count = (current_stack_boards_get());
	}
	else if (operate_type == FRMWRT_ALL_R)
	{
		total_len = (read_len + 6) * (current_stack_boards_get() + 1);
		read_board_count = current_stack_boards_get() + 1;
	}
	else
	{
		total_len = 0;
		read_board_count = 0;

		AFE_COM_LOGW("[AFE_COMM]:read_reg error %d\n", 4);
		return -4;
	}

	// wait BQ79600 ack
	// DELAY_MS(delay_ms); // 等待SPI_RDY即可

	// 总的数据以128字节分批处理（79600双缓冲区，一个缓冲区128字节）
	total_len_quotient = total_len / 128;
	total_len_remain = total_len % 128;
	while (len_index <= total_len_quotient)
	{
		// 判断SPI_RDY是ready状态
		if (0 != is_spi_rdy_pin_ready())
		{
			AFE_COM_LOGW("[AFE_COMM]:read_reg error %d\n", 5);
			return -5;
		}
		if (len_index < total_len_quotient)
		{
			real_len = 128;
		}
		else
		{
			real_len = total_len_remain;
		}
		if (real_len != read_data(buf + len_index * 128, (uint32_t)real_len))
		{
			AFE_COM_LOGW("[AFE_COMM]:read_reg error %d\n", 6);
			return -6;
		}
		len_index++;
	}

	for (i = 0; i < read_board_count; i++)
	{
		// CRC check
		crc_index = (read_len + READ_DATA_INDEX) * (i + 1) + CRC_DATA_COUNT * i;
		crc_calc_index = (read_len + READ_DATA_INDEX + CRC_DATA_COUNT) * i;
		memcpy(&crc, &buf[crc_index], sizeof(uint16_t));
		if (crc != calc_crc16(buf + crc_calc_index, (read_len + READ_DATA_INDEX)))
		{
			AFE_COM_LOGW("[AFE_COMM]:read_reg %x error %d\n", addr, 7);
			return -7;
		}

		// addr_check
		address = (buf[2 + crc_calc_index] << 8) | buf[3 + crc_calc_index];
		if (0 != memcmp(&addr, &address, sizeof(uint16_t)))
		{
			AFE_COM_LOGW("[AFE_COMM]:read_reg error %d\n", 8);
			return -8;
		}
	}

	return 0;
}

// CRC check
static uint16_t calc_crc16(uint8_t *buf, int32_t len)
{
	uint16_t crc_ret = 0xFFFF;
	int32_t i;

	for (i = 0; i < len; i++)
	{
		crc_ret ^= (*buf++) & 0x00FF;
		crc_ret = crc16_table[crc_ret & 0x00FF] ^ (crc_ret >> 8);
	}
	return crc_ret;
}
