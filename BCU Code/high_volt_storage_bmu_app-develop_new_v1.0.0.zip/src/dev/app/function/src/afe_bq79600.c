#include <string.h>
#include "sdk.h"
#include "sdk_osif.h"
#include "afe_bq79600.h"
#include "sample.h"
#include "ate.h"
/**
 * @note 宏定义
 */
#define APP_AFE_TEST   // shell debug
#define AFE_LOGD(...) log_d(__VA_ARGS__)
#define AFE_LOGE(...) log_e(__VA_ARGS__)
#define AFE_LOGW(...) log_w(__VA_ARGS__)

#define BQ79600_ADDR 0
#define RETRY_NUM 3
#define BQ79600_READ_MS 1
#define AFE_VC_TIME_OUT_CNT 3
#define AFE_REQ_VC_WITE_OPEN_CHECK_TIME (1000 / 10 * 86400) // 一天
#define TOGGLE_DIRECTION_TIME (5 * 60 * 1000)

#define BQ79600_SAMP_VOLT 5000
#define BQ79600_REF_VOLT 5000
#define BQ79600_TEMP_SAMPLE_RES 10
#define AFE_TEMP_OFFSET 400 // 温度偏移量 单位0.1℃

#define TEMP_SET_REG 4
#define MULTIPLEXER_CHAN 8

#define MAX_BUF_LEN 256
#define AUTO_ADDR_READ_BUF_LEN ((1 + 6) * 2 * TOTAL_BOARDS)
#define CELL_READ_BUF_LEN (AFE_CELL_VOLT_NUM * 2 + 6)
#define BAT_READ_BUF_LEN (2 + 6)
#define TEMP_READ_BUF_LEN (2 + 6)
#define BQ79600_READ_MAX_DAT_LEN (AFE_CELL_VOLT_NUM * 2 + 6)
#define BQ79600_READ_BUF_LEN (BQ79600_READ_MAX_DAT_LEN * TOTAL_BOARDS)

#define CONFIG_TAB_LEN (sizeof(g_config_buf) / sizeof(bq79600_config_reg_t))
#define FORWARD_ADDR_TAB_LEN (sizeof(g_forward_adrr_config_buf) / sizeof(bq79600_config_reg_t))
#define REVERSE_ADDR_TAB_LEN (sizeof(g_reverse_adrr_config_buf) / sizeof(bq79600_config_reg_t))
#define AFE_TEMP_TABLE_SIZE (sizeof(g_afe_ntc_res_tab) / sizeof(uint16_t))
#define BQ79600_REG_CONFIG(dev_id, addr, val, target_val, len, type)        {				\
																		   (val),       	\
																		   (target_val),	\
																		   (addr),      	\
																		   (dev_id),    	\
																		   (len),       	\
																		   (type)			\
																			}

                                                                            
#ifdef APP_AFE_TEST
    bool g_app_afe_bala_debug_flag = false;
#endif

/**
 * @note 全局变量定义
 */
typedef struct
{
    uint64_t val;           // 寄存器写入值
    uint64_t target_val;    // 写入后目标值，用于反读判断写入成功与否
    uint16_t addr;          // 寄存器地址
    uint8_t dev_id;         // 设备ID
    uint8_t write_len;      // 写入长度
    uint8_t operate_type;   // 操作类型
}bq79600_config_reg_t;

static bq79600_config_reg_t g_config_buf[] = 
{
    BQ79600_REG_CONFIG(BQ79600_ADDR,	FAULT_MSK2,     	0x40,    0x40,    1,	FRMWRT_STK_W), // MASK CUST_CRC SO CONFIG CHANGES DON'T FLAG A FAULT
	BQ79600_REG_CONFIG(BQ79600_ADDR,	COMM_TIMEOUT_CONF,  0x0B,    0x0B,    1,	FRMWRT_STK_W), // 10S无通信后进入shutdown 0x0F:1H
    BQ79600_REG_CONFIG(BQ79600_ADDR,	FAULT_RST1,     	0xFFFF,  0x0000,  2,	FRMWRT_STK_W), // CLEAR ALL FAULTS
	BQ79600_REG_CONFIG(BQ79600_ADDR,	FAULT_RST2,     	0xFFFF,  0x0000,  2,	FRMWRT_STK_W), // CLEAR ALL FAULTS
 

    BQ79600_REG_CONFIG(BQ79600_ADDR,	GPIO_CONF1,     	0x2A,    0x2A,    1,	FRMWRT_STK_W), // 设置GPIO1 为 ADC only input,GPIO2 As output low
    BQ79600_REG_CONFIG(BQ79600_ADDR,	GPIO_CONF2,     	0x2D,    0x2D,    1,	FRMWRT_STK_W), // 设置GPIO3,GPIO4 As output low    
    BQ79600_REG_CONFIG(BQ79600_ADDR,	GPIO_CONF3,     	0x2A,    0x2A,    1,	FRMWRT_STK_W), // 设置GPIO5 为 ADC only input,GPIO6 As output low
    BQ79600_REG_CONFIG(BQ79600_ADDR,	GPIO_CONF4,     	0x2D,    0x2D,    1,	FRMWRT_STK_W), // 设置GPIO7,GPIO8 As output low 

    #if PACK_64S_PRJ
    BQ79600_REG_CONFIG(BQ79600_ADDR,	ACTIVE_CELL,    	0x0A,    0x0A,    1,	FRMWRT_STK_W), // 有效电芯设置成16串// Mmodify    
    #else
    BQ79600_REG_CONFIG(BQ79600_ADDR,	ACTIVE_CELL,    	0x06,    0x06,    1,	FRMWRT_STK_W), // 有效电芯设置成12串// Mmodify    
    #endif
    BQ79600_REG_CONFIG(BQ79600_ADDR,	ADC_CONF1,      	0x04,    0x04,    1,	FRMWRT_STK_W), // 111Hz LPF_Vcell (9ms average)
    BQ79600_REG_CONFIG(BQ79600_ADDR,	ADC_CTRL1,      	0x0E,    0x0A,    1,	FRMWRT_STK_W), // continuous run, LPF enabled and MAIN_GO
    BQ79600_REG_CONFIG(BQ79600_ADDR,	ADC_CTRL3,      	0x06,    0x02,    1,	FRMWRT_STK_W), // continuous run, AUX_GO
	BQ79600_REG_CONFIG(BQ79600_ADDR,	CB_CELL16_CTRL, 	0x00,    0x00,    8,	FRMWRT_STK_W), // 9-16节电芯停止均衡// Mmodify
	BQ79600_REG_CONFIG(BQ79600_ADDR,	CB_CELL8_CTRL,  	0x00,    0x00,    8,	FRMWRT_STK_W), // 1-8节电芯停止均衡	
	BQ79600_REG_CONFIG(BQ79600_ADDR,	BAL_CTRL1,      	0x00,    0x00,    1,	FRMWRT_STK_W), // 奇偶转换时间 10s
	BQ79600_REG_CONFIG(BQ79600_ADDR,	BAL_CTRL2,      	0x43,    0x41,    1,	FRMWRT_STK_W), // 设置自动均衡且暂停均衡
    BQ79600_REG_CONFIG(BQ79600_ADDR,	DIAG_COMP_CTRL2,    0x01,    0x01,    1,	FRMWRT_STK_W), // 设置CV开路比较阈值 500mV-5V，300mV为步进，0x01表示800mV
    BQ79600_REG_CONFIG(BQ79600_ADDR,	DIAG_COMP_CTRL3,    0x00,    0x00,    1,	FRMWRT_STK_W), // 设置CV开路检测配置

    BQ79600_REG_CONFIG(BQ79600_ADDR,	CONTROL2,       	0x01,    0x01,    1,	FRMWRT_STK_W), // 设置温度采集用参考电压TSREF
};

static bq79600_config_reg_t g_forward_adrr_config_buf[] = 
{
	BQ79600_REG_CONFIG(BQ79600_ADDR,	OTP_ECC_DATAIN1,	0x00,	NOT_NEED_CHECK,	1,	FRMWRT_STK_W),//DUMMY WRITE TO SNCHRONIZE ALL DAISY CHAIN DEVICES DLL (IF A DEVICE RESET OCCURED PRIOR TO THIS)
	BQ79600_REG_CONFIG(BQ79600_ADDR,	OTP_ECC_DATAIN2,	0x00,	NOT_NEED_CHECK,	1,	FRMWRT_STK_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	OTP_ECC_DATAIN3,	0x00,	NOT_NEED_CHECK,	1,	FRMWRT_STK_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	OTP_ECC_DATAIN4,	0x00,	NOT_NEED_CHECK,	1,	FRMWRT_STK_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	OTP_ECC_DATAIN5,	0x00,	NOT_NEED_CHECK,	1,	FRMWRT_STK_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	OTP_ECC_DATAIN6,	0x00,	NOT_NEED_CHECK,	1,	FRMWRT_STK_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	OTP_ECC_DATAIN7,	0x00,	NOT_NEED_CHECK,	1,	FRMWRT_STK_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	OTP_ECC_DATAIN8,	0x00,	NOT_NEED_CHECK,	1,	FRMWRT_STK_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	CONTROL1,			0X01,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),//ENABLE AUTO ADDRESSING MODE
	#if		(2 == TOTAL_BOARDS)
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR0_ADDR,			0X00,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),//SET ADDRESSES FOR EVERY BOARD
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR0_ADDR,			0X01,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),//SET ADDRESSES FOR EVERY BOARD
	#elif	(3 == TOTAL_BOARDS)
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR0_ADDR,			0X00,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR0_ADDR,			0X01,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR0_ADDR,			0X02,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	#elif	(4 == TOTAL_BOARDS)
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR0_ADDR,			0X00,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR0_ADDR,			0X01,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR0_ADDR,			0X02,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR0_ADDR,			0X03,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	#elif	(5 == TOTAL_BOARDS)
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR0_ADDR,			0X00,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR0_ADDR,			0X01,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR0_ADDR,			0X02,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR0_ADDR,			0X03,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR0_ADDR,			0X04,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	#else
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR0_ADDR,			0X01,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	#endif
	BQ79600_REG_CONFIG(BQ79600_ADDR,	COMM_CTRL,			0x02,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),//BROADCAST WRITE TO SET ALL DEVICES AS STACK DEVICE
	BQ79600_REG_CONFIG(BQ79600_ADDR,	COMM_CTRL,			0x00,	NOT_NEED_CHECK,	1,	FRMWRT_SGL_W),
	BQ79600_REG_CONFIG(TOTAL_BOARDS-1,	COMM_CTRL,			0x03,	NOT_NEED_CHECK,	1,	FRMWRT_SGL_W),
};

#if ((1 == REVERSE_ADDR_ENABLE) && (0 == FORWARD_ADDR_ENABLE))
static bq79600_config_reg_t g_reverse_adrr_config_buf[] = 
{
	BQ79600_REG_CONFIG(BQ79600_ADDR,	OTP_ECC_DATAIN1,	0x00,	NOT_NEED_CHECK,	1,	FRMWRT_STK_W),//DUMMY WRITE TO SNCHRONIZE ALL DAISY CHAIN DEVICES DLL (IF A DEVICE RESET OCCURED PRIOR TO THIS)
	BQ79600_REG_CONFIG(BQ79600_ADDR,	OTP_ECC_DATAIN2,	0x00,	NOT_NEED_CHECK,	1,	FRMWRT_STK_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	OTP_ECC_DATAIN3,	0x00,	NOT_NEED_CHECK,	1,	FRMWRT_STK_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	OTP_ECC_DATAIN4,	0x00,	NOT_NEED_CHECK,	1,	FRMWRT_STK_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	OTP_ECC_DATAIN5,	0x00,	NOT_NEED_CHECK,	1,	FRMWRT_STK_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	OTP_ECC_DATAIN6,	0x00,	NOT_NEED_CHECK,	1,	FRMWRT_STK_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	OTP_ECC_DATAIN7,	0x00,	NOT_NEED_CHECK,	1,	FRMWRT_STK_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	OTP_ECC_DATAIN8,	0x00,	NOT_NEED_CHECK,	1,	FRMWRT_STK_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	CONTROL1,			0X80,	NOT_NEED_CHECK,	1,	FRMWRT_REV_ALL_W),//ENABLE AUTO ADDRESSING MODE
  	BQ79600_REG_CONFIG(BQ79600_ADDR,	COMM_CTRL,	        0x02,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
 	BQ79600_REG_CONFIG(BQ79600_ADDR,	CONTROL1,	        0x81,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	#if		(2 == TOTAL_BOARDS)
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X00,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),//SET ADDRESSES FOR EVERY BOARD
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X01,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),//SET ADDRESSES FOR EVERY BOARD
	#elif	(3 == TOTAL_BOARDS)
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X00,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X01,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X02,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	#elif	(4 == TOTAL_BOARDS)
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X00,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X01,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X02,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X03,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	#elif	(5 == TOTAL_BOARDS)
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X00,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X01,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X02,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X03,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X04,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	#else
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR0_ADDR,			0X01,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	#endif
	BQ79600_REG_CONFIG(BQ79600_ADDR,	COMM_CTRL,			0x02,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),//BROADCAST WRITE TO SET ALL DEVICES AS STACK DEVICE
	BQ79600_REG_CONFIG(BQ79600_ADDR,	COMM_CTRL,			0x00,	NOT_NEED_CHECK,	1,	FRMWRT_SGL_W),
	BQ79600_REG_CONFIG(TOTAL_BOARDS-1,	COMM_CTRL,			0x03,	NOT_NEED_CHECK,	1,	FRMWRT_SGL_W),
};
#else
static bq79600_config_reg_t g_reverse_adrr_config_buf[] = 
{
	// BQ79600_REG_CONFIG(BQ79600_ADDR,	OTP_ECC_DATAIN1,	0x00,	NOT_NEED_CHECK,	1,	FRMWRT_STK_W),//DUMMY WRITE TO SNCHRONIZE ALL DAISY CHAIN DEVICES DLL (IF A DEVICE RESET OCCURED PRIOR TO THIS)
	// BQ79600_REG_CONFIG(BQ79600_ADDR,	OTP_ECC_DATAIN2,	0x00,	NOT_NEED_CHECK,	1,	FRMWRT_STK_W),
	// BQ79600_REG_CONFIG(BQ79600_ADDR,	OTP_ECC_DATAIN3,	0x00,	NOT_NEED_CHECK,	1,	FRMWRT_STK_W),
	// BQ79600_REG_CONFIG(BQ79600_ADDR,	OTP_ECC_DATAIN4,	0x00,	NOT_NEED_CHECK,	1,	FRMWRT_STK_W),
	// BQ79600_REG_CONFIG(BQ79600_ADDR,	OTP_ECC_DATAIN5,	0x00,	NOT_NEED_CHECK,	1,	FRMWRT_STK_W),
	// BQ79600_REG_CONFIG(BQ79600_ADDR,	OTP_ECC_DATAIN6,	0x00,	NOT_NEED_CHECK,	1,	FRMWRT_STK_W),
	// BQ79600_REG_CONFIG(BQ79600_ADDR,	OTP_ECC_DATAIN7,	0x00,	NOT_NEED_CHECK,	1,	FRMWRT_STK_W),
	// BQ79600_REG_CONFIG(BQ79600_ADDR,	OTP_ECC_DATAIN8,	0x00,	NOT_NEED_CHECK,	1,	FRMWRT_STK_W),
	// BQ79600_REG_CONFIG(BQ79600_ADDR,	CONTROL1,			0X80,	NOT_NEED_CHECK,	1,	FRMWRT_REV_ALL_W),//ENABLE AUTO ADDRESSING MODE
	BQ79600_REG_CONFIG(BQ79600_ADDR,	CONTROL1,	        0x80,	NOT_NEED_CHECK,	1,	FRMWRT_SGL_W),
 	BQ79600_REG_CONFIG(BQ79600_ADDR,	CONTROL1,	        0x80,	NOT_NEED_CHECK,	1,	FRMWRT_REV_ALL_W),
  	BQ79600_REG_CONFIG(BQ79600_ADDR,	COMM_CTRL,	        0x02,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
 	BQ79600_REG_CONFIG(BQ79600_ADDR,	CONTROL1,	        0x81,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	#if		(2 == TOTAL_BOARDS)
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X00,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),//SET ADDRESSES FOR EVERY BOARD
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X01,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),//SET ADDRESSES FOR EVERY BOARD
	#elif	(3 == TOTAL_BOARDS)
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X00,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X01,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X02,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	#elif	(4 == TOTAL_BOARDS)
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X00,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X01,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X02,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X03,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	#elif	(5 == TOTAL_BOARDS)
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X00,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X01,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X02,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X03,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR1_ADDR,			0X04,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	#else
	BQ79600_REG_CONFIG(BQ79600_ADDR,	DIR0_ADDR,			0X01,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),
	#endif
	BQ79600_REG_CONFIG(BQ79600_ADDR,	COMM_CTRL,			0x02,	NOT_NEED_CHECK,	1,	FRMWRT_ALL_W),//BROADCAST WRITE TO SET ALL DEVICES AS STACK DEVICE
	BQ79600_REG_CONFIG(BQ79600_ADDR,	COMM_CTRL,			0x00,	NOT_NEED_CHECK,	1,	FRMWRT_SGL_W),
	BQ79600_REG_CONFIG(TOTAL_BOARDS-1,	COMM_CTRL,			0x03,	NOT_NEED_CHECK,	1,	FRMWRT_SGL_W),
};
#endif



const uint16_t  g_afe_ntc_res_tab[] =
{
    21794,	20553,	19403,	18331,	17327,	16385,	15499,	14666,	13880,	13139,	12441,           //-40 ~ -30
    11784,	11163,	10579,	10028,	9509,	9020,	8559,	8124,	7714,	7328,                    //-29 ~ -20
    6963,	6619,	6294,	5987,	5698,	5424,	5165,	4920,	4688,	4469,                    //-19 ~ -10
    4261,	4064,	3878,	3701,	3533,	3374,	3223,	3079,	2943,	2814,                    //- 9 ~ 0
    2691,	2574,	2463,	2357,	2257,	2161,	2070,	1984,	1901,	1823,                    //  1 ~ 10
    1748,	1677,	1609,	1544,	1482,	1423,	1367,	1314,	1262,	1214,                    // 11 ~ 20
    1167,	1122,	1080,	1039,	1000,	963,	927,	893,	860,	829,                     // 21 ~ 30
    799,	771,	743,	717,	692,	668,	644,	622,	601,	580,                     // 31 ~ 40
    560,	542,	523,	506,	489,	473,	457,	442,	428,	414,                     // 41 ~ 50
    401,	388,	376,	364,	352,	341,	331,	320,	311,	301,                     // 51 ~ 60
    292,	283,	274,	266,	258,	250,	243,	236,	229,	222,                     // 61 ~ 70
    216,	210,	204,	198,	192,	187,	181,	176,	171,	167,                     // 71 ~ 80
    162,	158,	153,	149,	145,	141,	137,	134,	130,	127,                     // 81 ~ 90
    124,	120,	117,	114,	111,	108,	106,	103,	100,	98,                      // 91 ~ 100
    96,	    93,	    91,	    89,	    87,	    84,	    82,	    81,	    79,	    77,                      //101 ~ 110
    75,	    73,	    71,	    70,	    68,	    67,	    65,	    64,	    62,	    61,                      //111 ~ 120  
    59,	    58,	    57,	    55,	    54,	                                                             //121 ~ 125     
};
/**
 * @note 全局变量初始化
 */
afe_collect_t g_afe_data[STACK_BOARDS] = {0};
balance_data_t g_balance_data[STACK_BOARDS] = {0};
temp_res_data_t temp_res_data[STACK_BOARDS] = {0};
daisy_chain_data_t daisy_chain_data =
    {
        .chain_break_flag = CHAIN_UNBREAK,
        .chain_break_forward_pos = STACK_BOARDS,
        .chain_break_reverse_pos = STACK_BOARDS,
        .direction_flag = FORWARD_DIRECTION,
        .current_stack_boards = STACK_BOARDS,
};

uint8_t response_frame[MAX_BUF_LEN] = {0};
static int16_t g_cell_tmp[STACK_BOARDS][AFE_CELL_VOLT_NUM] = {0};
// 温度采集相关
static uint8_t g_temp_sam_channel = 0;   // 当前38译码器采集通道
static uint8_t g_temp_forward_index = 0; // 正向温度通道转换索引
static uint8_t g_temp_reverse_index = 0; // 反向向温度通道转换索引
static uint8_t g_temp_convert_channel_result = true;

// 断线检测相关
static uint32_t vc_wire_open_check_one_day_cnt = 0;
typedef enum
{
    AFE_VC_WO_CHECK_IDLE = 0, // 检测空闲
    AFE_VC_WO_CHECK_INIT,     // 判断是否启动断线检测
    AFE_VC_WO_START_CHECK,    // 启动断线检测
    AFE_VC_WO_GET_RESULT,     // 获取断线结果
    AFE_VC_WO_FINISHED,       // 断线检测结束
} afe_cell_volt_wire_open_state;

typedef struct
{
    uint8_t state;                    // 参考afe_cell_volt_wire_open_state
//    uint8_t over_time_cnt;            // 超时次数
    uint8_t err_cnt;                  // 读写次数
    uint8_t start_flag;               // 启动标志, 用于启动断线检测
    uint32_t open_bits[STACK_BOARDS]; // bit1-16表示B1-B16，bit0表示B0
    uint32_t over_timer;              // 超时定时器
    uint8_t check_err_cnt;            // 连续断线检测异常次数
    uint8_t check_suc_cnt;            // 连续成功的次数
    uint8_t max_check_cnt;            // 最大连续检测次数
} afe_wire_open_st;
static afe_wire_open_result g_afe_vc_wo_result = AFE_WO_CHECK_INIT;
static uint8_t g_cell_volt_change_req_vc_wo_check = 0;
static afe_wire_open_st g_vc_wire_open_param =
    {
        .state = AFE_VC_WO_CHECK_INIT,
//        .over_time_cnt = 0,
        .err_cnt = 0,
        .start_flag = 1,
        .open_bits = {0},
        .over_timer = 0,
        .check_err_cnt = 0,
        .check_suc_cnt = 0,
        .max_check_cnt = 0,
};
/**
 * @note 函数声明
 */
static int32_t bq79600_write_data(bq79600_config_reg_t *val);
static int32_t bq79600_read_data(uint8_t dev_id, uint16_t addr, uint8_t *buf, uint8_t read_len, uint8_t operate_type, uint32_t delay_ms);
static int32_t toggle_comm_dir(uint8_t direction);
/**
 * @note AFE对外数据接口
 */
const afe_collect_t *p_afe_collect_data_get(void)
{
    return (const afe_collect_t *)g_afe_data;
}

uint8_t current_stack_boards_get(void) // AFE堆栈设备数量修改 
{
    return daisy_chain_data.current_stack_boards;
}

void afe_balance_state_get(stack_board_name_e name, uint32_t *state)
{
    if (name >= STACK_BOARDS)
    {
        return;
    }
    *state = g_balance_data[name].balance_ctrl_flag;
}

void afe_balance_set(stack_board_name_e name, uint32_t enable_flag)
{
    if(g_app_afe_bala_debug_flag)
    {
        return;
    }
    if (name >= STACK_BOARDS)
    {
        return;
    }
    g_balance_data[name].balance_ctrl_flag = (enable_flag & 0x0000FFFF);
}
/**
 * @note 内部函数定义
 */
void bq79600_data_init(void)
{
    for (uint8_t i = S1; i < STACK_BOARDS; i++)
    {
        for (uint8_t j = 0; j < AFE_CELL_VOLT_NUM; j++)
        {
            g_afe_data[i].cell_volt[j] = I16_INVALID_VALUE;
        }
        for (uint8_t j = 0; j < AFE_CELL_TEMP_NUM; j++)
        {
            g_afe_data[i].cell_temp[j] = I16_INVALID_VALUE;
        }
//        for (uint8_t j = 0; j < AFE_CHANNEL1_OTHER_TEMP_NUM; j++)
//        {
//            g_afe_data[i].channel1_other_temp[j] = I16_INVALID_VALUE;
//        }
        for (uint8_t j = 0; j < AFE_BALANCE_TEMP_NUM; j++)
        {
            g_afe_data[i].balance_temp[j] = I16_INVALID_VALUE;
        }
        for (uint8_t j = 0; j < AFE_POWER_TEMP_NUM; j++)
        {
            g_afe_data[i].pwr_temp[j] = I16_INVALID_VALUE;
        }
//        for (uint8_t j = 0; j < AFE_CHANNEL2_OTHER_TEMP_NUM; j++)
//        {
//            g_afe_data[i].channel2_other_temp[j] = I16_INVALID_VALUE;
//        }
        for (uint8_t j = 0; j < AFE_CHANNEL1_TEMP_TOTAL_NUM; j++)
        {
            temp_res_data[i].afe_chan1_temp_res_buf[j] = U16_INVALID_VALUE;
        }
        for (uint8_t j = 0; j < AFE_CHANNEL2_TEMP_TOTAL_NUM; j++)
        {
            temp_res_data[i].afe_chan2_temp_res_buf[j] = U16_INVALID_VALUE;
        }

        g_afe_data[i].battery_volt = U32_INVALID_VALUE;

        g_balance_data[i].balance_ctrl_flag = 0;
        g_balance_data[i].balance_state = 0;
    }
}

static void critical_variable_init(void)
{
    g_temp_sam_channel = 0;   // 初始化温度切换通道
    g_temp_forward_index = 0; // 正向温度通道转换索引初始化
    g_temp_reverse_index = 0; // 反向温度通道转换索引初始化
    g_temp_convert_channel_result = true;
    for (uint8_t i = 0; i < STACK_BOARDS; i++)
    {
        g_balance_data[i].balance_state = 0; // 更新balance_state
    }
}

static int32_t config_init_write(void)
{
    int32_t ret = 0;

    for (uint8_t i = 0; i < CONFIG_TAB_LEN; i++)
    {
        ret = bq79600_write_data(&g_config_buf[i]);
        if (0 > ret)
        {
            AFE_LOGW("[AFE]1.config reg %x error: %d\n", g_config_buf[i].addr, ret);
            break;
        }
    }

    return ret;
}

int32_t bq79600_config_init(void)
{
    int32_t ret = 0;

    critical_variable_init();

    ret = config_init_write();
    if (0 > ret)
    {
        return ret;
    }

    if (CHAIN_BREAK == daisy_chain_data.chain_break_flag)
    {
        toggle_comm_dir(!daisy_chain_data.direction_flag);

        ret = config_init_write();
        if (0 > ret)
        {
            return ret;
        }
    }

    return ret;
}

/**
 * @brief		正向编址流程
 * @param		无
 * @return		执行结果
 * @retval		0 	成功
 * @retval		-1	失败
 */
int32_t bq79600_forward_address(void)
{
    int32_t ret = 0;
    uint8_t read_valid_data = 0;
    uint8_t current_board = 0;
    memset(response_frame, 0, sizeof(response_frame));

    bq79600_config_reg_t temp_config_buf[] = {
        BQ79600_REG_CONFIG(BQ79600_ADDR, COMM_CTRL, 0x03, NOT_NEED_CHECK, 1, FRMWRT_SGL_W),
    };

    for (uint8_t i = 0; i < FORWARD_ADDR_TAB_LEN; i++)
    {
        ret = bq79600_write_data(&g_forward_adrr_config_buf[i]);
        if (0 > ret)
        {
            AFE_LOGW("[AFE]1.forward_address %d error: %d\n", i + 1, ret);
            return ret;
        }
    }

    for (current_board = 1; current_board < TOTAL_BOARDS; current_board++)
    {
        bq79600_read_data(current_board, DIR0_ADDR, response_frame, 1, FRMWRT_SGL_R, BQ79600_READ_MS);

        read_valid_data = response_frame[READ_DATA_INDEX];

        if (current_board != read_valid_data)
        {
            daisy_chain_data.chain_break_forward_pos = current_board - 1;
            daisy_chain_data.current_stack_boards = current_board - 1;
            temp_config_buf[0].dev_id = daisy_chain_data.chain_break_forward_pos;
            AFE_LOGW("[AFE]3.forward_address chain_break_forward_pos:%d\n", daisy_chain_data.chain_break_forward_pos);
            ret = bq79600_write_data(&temp_config_buf[0]);
            if (0 > ret)
            {
                AFE_LOGW("[AFE]4.forward_address error: %d\n", ret);
                return ret;
            }

            break;
        }
    }

    ret |= bq79600_read_data(BQ79600_ADDR, OTP_ECC_DATAIN1, response_frame, 1, FRMWRT_STK_R, BQ79600_READ_MS);
    ret |= bq79600_read_data(BQ79600_ADDR, OTP_ECC_DATAIN2, response_frame, 1, FRMWRT_STK_R, BQ79600_READ_MS);
    ret |= bq79600_read_data(BQ79600_ADDR, OTP_ECC_DATAIN3, response_frame, 1, FRMWRT_STK_R, BQ79600_READ_MS);
    ret |= bq79600_read_data(BQ79600_ADDR, OTP_ECC_DATAIN4, response_frame, 1, FRMWRT_STK_R, BQ79600_READ_MS);
    ret |= bq79600_read_data(BQ79600_ADDR, OTP_ECC_DATAIN5, response_frame, 1, FRMWRT_STK_R, BQ79600_READ_MS);
    ret |= bq79600_read_data(BQ79600_ADDR, OTP_ECC_DATAIN6, response_frame, 1, FRMWRT_STK_R, BQ79600_READ_MS);
    ret |= bq79600_read_data(BQ79600_ADDR, OTP_ECC_DATAIN7, response_frame, 1, FRMWRT_STK_R, BQ79600_READ_MS);
    ret |= bq79600_read_data(BQ79600_ADDR, OTP_ECC_DATAIN8, response_frame, 1, FRMWRT_STK_R, BQ79600_READ_MS);
    if (0 > ret)
    {
        AFE_LOGW("[AFE]2.forward_address error: %d\n", ret);
        return ret;
    }

    ret = bq79600_read_data(BQ79600_ADDR, Bridge_DEV_CONF1, response_frame, 1, FRMWRT_SGL_R, BQ79600_READ_MS);
    if (0 > ret)
    {
        AFE_LOGW("[AFE]5.forward_address error: %d\n", ret);
        return ret;
    }
    read_valid_data = response_frame[READ_DATA_INDEX];
    if (0x14 != read_valid_data)
    {
        AFE_LOGW("[AFE]6.forward_address read_valid_data error: %d\n", read_valid_data);
        ret = -1;
    }

    daisy_chain_data.direction_flag = FORWARD_DIRECTION;

    return ret;
}

/**
 * @brief		反向编址流程
 * @param		无
 * @return		执行结果
 * @retval		0 	成功
 * @retval		-1	失败
 */
int32_t bq79600_reverse_address(void)
{
    int32_t ret = 0;
    uint8_t read_valid_data = 0;
    uint8_t current_board = 0;
    memset(response_frame, 0, sizeof(response_frame));

    bq79600_config_reg_t temp_config_buf[] = {
        BQ79600_REG_CONFIG(BQ79600_ADDR, COMM_CTRL, 0x03, NOT_NEED_CHECK, 1, FRMWRT_SGL_W),
    };

    for (uint8_t i = 0; i < REVERSE_ADDR_TAB_LEN; i++)
    {
        ret = bq79600_write_data(&g_reverse_adrr_config_buf[i]);
        if (0 > ret)
        {
            AFE_LOGW("[AFE]1.reverse_address %d error: %d\n", i + 1, ret);
            return ret;
        }
    }
    
    for (current_board = 1; current_board < TOTAL_BOARDS; current_board++)
    {
        bq79600_read_data(current_board, DIR1_ADDR, response_frame, 1, FRMWRT_SGL_R, BQ79600_READ_MS);

        read_valid_data = response_frame[READ_DATA_INDEX];

        if (current_board != read_valid_data)
        {
            daisy_chain_data.chain_break_reverse_pos = current_board - 1;
            daisy_chain_data.current_stack_boards = current_board - 1;
            temp_config_buf[0].dev_id = daisy_chain_data.chain_break_reverse_pos;
            AFE_LOGW("[AFE]2.reverse_address chain_break_reverse_pos: %d\n", daisy_chain_data.chain_break_reverse_pos);
            ret = bq79600_write_data(&temp_config_buf[0]);
            if (0 > ret)
            {
                AFE_LOGW("[AFE]3.reverse_address error: %d\n", ret);
                return ret;
            }

            break;
        }
    }

#if ((1 == REVERSE_ADDR_ENABLE) && (0 == FORWARD_ADDR_ENABLE)) // 断链后可不用此操作
    ret |= bq79600_read_data(BQ79600_ADDR, OTP_ECC_DATAIN1, response_frame, 1, FRMWRT_STK_R, BQ79600_READ_MS);
    ret |= bq79600_read_data(BQ79600_ADDR, OTP_ECC_DATAIN2, response_frame, 1, FRMWRT_STK_R, BQ79600_READ_MS);
    ret |= bq79600_read_data(BQ79600_ADDR, OTP_ECC_DATAIN3, response_frame, 1, FRMWRT_STK_R, BQ79600_READ_MS);
    ret |= bq79600_read_data(BQ79600_ADDR, OTP_ECC_DATAIN4, response_frame, 1, FRMWRT_STK_R, BQ79600_READ_MS);
    ret |= bq79600_read_data(BQ79600_ADDR, OTP_ECC_DATAIN5, response_frame, 1, FRMWRT_STK_R, BQ79600_READ_MS);
    ret |= bq79600_read_data(BQ79600_ADDR, OTP_ECC_DATAIN6, response_frame, 1, FRMWRT_STK_R, BQ79600_READ_MS);
    ret |= bq79600_read_data(BQ79600_ADDR, OTP_ECC_DATAIN7, response_frame, 1, FRMWRT_STK_R, BQ79600_READ_MS);
    ret |= bq79600_read_data(BQ79600_ADDR, OTP_ECC_DATAIN8, response_frame, 1, FRMWRT_STK_R, BQ79600_READ_MS);
    if (0 > ret)
    {
        AFE_LOGW("[AFE]22.reverse_address error: %d\n", ret);
        return ret;
    }
#endif

    ret = bq79600_read_data(BQ79600_ADDR, Bridge_DEV_CONF1, response_frame, 1, FRMWRT_SGL_R, BQ79600_READ_MS);
    if (0 > ret)
    {
        AFE_LOGW("[AFE]4.reverse_address error: %d\n", ret);
        return ret;
    }
    read_valid_data = response_frame[READ_DATA_INDEX];
    if (0x14 != read_valid_data)
    {
        AFE_LOGW("[AFE]5.reverse_address read_valid_data error: %d\n", read_valid_data);
        ret = -1;
    }

    daisy_chain_data.direction_flag = REVERSE_DIRECTION;

    return ret;
}

int32_t bq79600_auto_address(void)
{
    int32_t ret = 0;

#if (1 == FORWARD_ADDR_ENABLE)
    ret = bq79600_forward_address();
    if (0 > ret)
    {
        AFE_LOGW("[AFE]1.forward auto_address error: %d\n", ret);
        return ret;
    }
#endif

#if (1 == REVERSE_ADDR_ENABLE)
    ret = bq79600_reverse_address();
    if (0 > ret)
    {
        AFE_LOGW("[AFE]2.reverse auto_address error: %d\n", ret);
        return ret;
    }
#endif

#if ((1 == FORWARD_ADDR_ENABLE) && (1 == REVERSE_ADDR_ENABLE))
    if ((STACK_BOARDS == daisy_chain_data.chain_break_forward_pos) &&
        (STACK_BOARDS == daisy_chain_data.chain_break_reverse_pos))
    {
        daisy_chain_data.chain_break_flag = CHAIN_UNBREAK;
        ret = CHAIN_UNBREAK;
    }
    else if (STACK_BOARDS == (daisy_chain_data.chain_break_forward_pos + daisy_chain_data.chain_break_reverse_pos))
    {
        AFE_LOGW("[AFE]3.auto_address chain_break\n");
        daisy_chain_data.chain_break_flag = CHAIN_BREAK;
        ret = CHAIN_BREAK;
    }
    else
    {
        AFE_LOGW("[AFE]4.auto_address error, forward_pos = %d, reverse_pos = %d\n", daisy_chain_data.chain_break_forward_pos, daisy_chain_data.chain_break_reverse_pos);
        daisy_chain_data.chain_break_flag = CHAIN_BREAK_MULTIPLE;
        ret = CHAIN_BREAK_MULTIPLE;
    }
#elif (1 == FORWARD_ADDR_ENABLE)
    if (STACK_BOARDS == daisy_chain_data.chain_break_forward_pos)
    {
        daisy_chain_data.chain_break_flag = CHAIN_UNBREAK;
        ret = 0;
    }
    else
    {
        AFE_LOGW("[AFE]5.forward auto_address chain_break\n");
        ret = 0;
    }
#elif (1 == REVERSE_ADDR_ENABLE)
    if (STACK_BOARDS == daisy_chain_data.chain_break_reverse_pos)
    {
        daisy_chain_data.chain_break_flag = CHAIN_UNBREAK;
        ret = 0;
    }
    else
    {
        AFE_LOGW("[AFE]6.reverse auto_address chain_break\n");
        ret = 0;
    }
#endif

    return ret;
}

static void current_total_board_check(void)
{
    if (CHAIN_UNBREAK == daisy_chain_data.chain_break_flag)
    {
        daisy_chain_data.current_stack_boards = STACK_BOARDS;
    }
    else
    {
        if (FORWARD_DIRECTION == daisy_chain_data.direction_flag)
        {
            daisy_chain_data.current_stack_boards = daisy_chain_data.chain_break_forward_pos;
        }
        else
        {
            daisy_chain_data.current_stack_boards = daisy_chain_data.chain_break_reverse_pos;
        }
    }
}

static int32_t toggle_comm_dir(uint8_t direction)
{
    int32_t ret = 0;

    if (direction > 1)
    {
        ret = -1;
        AFE_LOGW("[AFE]1.toggle_dir error: %d\n", ret);
        return ret;
    }

    bq79600_config_reg_t temp_config_buf[] = {
        BQ79600_REG_CONFIG(BQ79600_ADDR, CONTROL1, 0x00, NOT_NEED_CHECK, 1, FRMWRT_SGL_W),
        BQ79600_REG_CONFIG(BQ79600_ADDR, CONTROL1, 0x00, NOT_NEED_CHECK, 1, FRMWRT_REV_ALL_W),
        BQ79600_REG_CONFIG(BQ79600_ADDR, COMM_CTRL, 0x02, NOT_NEED_CHECK, 1, FRMWRT_ALL_W),
        BQ79600_REG_CONFIG(TOTAL_BOARDS - 1, COMM_CTRL, 0x03, NOT_NEED_CHECK, 1, FRMWRT_SGL_W),
    };

    if (direction == FORWARD_DIRECTION)
    {
        if (FORWARD_DIRECTION == daisy_chain_data.direction_flag)
        {
            ret = 0;
            return ret;
        }

        temp_config_buf[0].val = 0x00;
        temp_config_buf[1].val = 0x00;
        temp_config_buf[3].dev_id = daisy_chain_data.chain_break_forward_pos;
        daisy_chain_data.direction_flag = FORWARD_DIRECTION;
    }
    if (direction == REVERSE_DIRECTION)
    {
        if (REVERSE_DIRECTION == daisy_chain_data.direction_flag)
        {
            ret = 0;
            return ret;
        }
        
        temp_config_buf[0].val = 0x80;
        temp_config_buf[1].val = 0x80;
        temp_config_buf[3].dev_id = daisy_chain_data.chain_break_reverse_pos;
        daisy_chain_data.direction_flag = REVERSE_DIRECTION;
    }

    for (uint8_t i = 0; i < (sizeof(temp_config_buf) / sizeof(bq79600_config_reg_t)); i++)
    {
        ret = bq79600_write_data(&temp_config_buf[i]);
        if (0 > ret)
        {
            AFE_LOGW("[AFE]2.toggle_dir write %d error: %d\n", i, ret);
            return ret;
        }
    }

    current_total_board_check();

    return ret;
}

int32_t daisy_chain_break_check(void)
{
    int32_t ret = CHAIN_UNBREAK;

    memset(response_frame, 0, sizeof(response_frame));
#if (1 == FORWARD_ADDR_ENABLE)
    toggle_comm_dir(0);
    for (uint8_t current_board = 1; current_board < TOTAL_BOARDS; current_board++)
    {
        ret = bq79600_read_data(current_board, DIR0_ADDR, response_frame, 1, FRMWRT_SGL_R, BQ79600_READ_MS);

        if ((0 > ret) && (current_board != response_frame[READ_DATA_INDEX]))
        {
            daisy_chain_data.chain_break_forward_pos = current_board - 1;
            break;
        }
    }
#endif

#if (1 == REVERSE_ADDR_ENABLE)
    toggle_comm_dir(1);
    for (uint8_t current_board = 1; current_board < TOTAL_BOARDS; current_board++)
    {
        ret = bq79600_read_data(current_board, DIR1_ADDR, response_frame, 1, FRMWRT_SGL_R, BQ79600_READ_MS);

        if ((0 > ret) && (current_board != response_frame[READ_DATA_INDEX]))
        {
            daisy_chain_data.chain_break_reverse_pos = current_board - 1;
            break;
        }
    }
#endif

#if (1 == FORWARD_ADDR_ENABLE) && (1 == REVERSE_ADDR_ENABLE)
    if (STACK_BOARDS == (daisy_chain_data.chain_break_forward_pos + daisy_chain_data.chain_break_reverse_pos))
    {
        ret = CHAIN_BREAK; // 跳转到重新编址
        AFE_LOGW("[AFE]1.chain_break_check error: %d\n", ret);
        daisy_chain_data.chain_break_flag = CHAIN_BREAK;
        toggle_comm_dir(0);
    }
    else if ((STACK_BOARDS == daisy_chain_data.chain_break_forward_pos) &&
             (STACK_BOARDS == daisy_chain_data.chain_break_reverse_pos))
    {
        ret = CHAIN_UNBREAK;
        daisy_chain_data.chain_break_flag = CHAIN_UNBREAK;
    }
    else
    {
        ret = CHAIN_BREAK_MULTIPLE; // 多处断
        AFE_LOGW("[AFE]2.chain_break_check error: %d\n", ret);
        daisy_chain_data.chain_break_flag = CHAIN_BREAK_MULTIPLE;
    }
#elif (1 == FORWARD_ADDR_ENABLE)
    if (STACK_BOARDS == daisy_chain_data.chain_break_forward_pos)
    {
        daisy_chain_data.chain_break_flag = CHAIN_UNBREAK;
        ret = CHAIN_UNBREAK;
    }
    else
    {
        AFE_LOGW("[AFE]3.forward chain_break_check chain_break\n");
        ret = CHAIN_BREAK;
    }
#elif (1 == REVERSE_ADDR_ENABLE)
    if (STACK_BOARDS == daisy_chain_data.chain_break_reverse_pos)
    {
        daisy_chain_data.chain_break_flag = CHAIN_UNBREAK;
        ret = CHAIN_UNBREAK;
    }
    else
    {
        AFE_LOGW("[AFE]4.reverse chain_break_check chain_break\n");
        ret = CHAIN_BREAK;
    }
#endif
    AFE_LOGD("[AFE]5.chain_break_check over: %d\n", ret);

    return ret;
}

int32_t bq79600_toggle_comm_dir(void)
{
    static uint8_t init_flag = false;
    static uint32_t delay_tick = 0;
    static uint8_t temp_toggle_dir = 1;

    if (CHAIN_UNBREAK == daisy_chain_data.chain_break_flag)
    {
        if (false == init_flag)
        {
            init_flag = true;
            delay_tick = sdk_tick_get();
        }

        if ((true == sdk_is_tick_over(delay_tick, os_tick_from_millisecond(TOGGLE_DIRECTION_TIME))) &&
            (0 == g_temp_sam_channel))

        {
            temp_toggle_dir = (temp_toggle_dir + 1) % 2;
            toggle_comm_dir(temp_toggle_dir);
            delay_tick = sdk_tick_get();
            // AFE_LOGD("[AFE]5min_toggle_dir: %d...\n", temp_toggle_dir);
        }
    }
    
    return 0;
}

static int32_t collect_cell_volt(void)
{
    int32_t ret = 0;
    uint8_t cell_cnt = 0;
    int16_t temp_data;
    int16_t cell_data = 0;
    uint8_t buff_index = 0;
    
#if !PACK_64S_PRJ
    uint8_t cell_compensate[STACK_BOARDS][AFE_CELL_VOLT_NUM] = {{3,0,0,0,0,0,0,0,0,0,0,9},
                                                                {9,0,0,0,0,0,0,0,0,0,0,3},
                                                                {3,0,0,0,0,0,0,0,0,0,0,9},
                                                                {9,0,0,0,0,0,0,0,0,0,0,3}}; //电芯电压由于采样线过长，需要对部分电芯电压做补偿
    
    uint8_t ate_cell_compensate[STACK_BOARDS][AFE_CELL_VOLT_NUM] = {{5,0,0,0,0,0,0,0,0,0,0,5},
                                                                {5,0,0,0,0,0,0,0,0,0,0,5},
                                                                {5,0,0,0,0,0,0,0,0,0,0,5},
                                                                {5,0,0,0,0,0,0,0,0,0,0,5}}; //单板测试根据实际的采样线做的补偿                                                                
#endif
    
    memset(response_frame, 0, sizeof(response_frame));

    for (uint8_t i = S1; i < daisy_chain_data.current_stack_boards; i++)
    {
#if PACK_64S_PRJ     
        ret = bq79600_read_data(i + 1, VCELL16_HI, response_frame, AFE_CELL_VOLT_NUM * 2, FRMWRT_SGL_R, BQ79600_READ_MS);
#else
        ret = bq79600_read_data(i + 1, VCELL12_HI, response_frame, AFE_CELL_VOLT_NUM * 2, FRMWRT_SGL_R, BQ79600_READ_MS);
#endif        

        if (0 == ret)
        {
            if (response_frame[DEV_ID_INDEX] == (i + 1))
            {
                if (FORWARD_DIRECTION == daisy_chain_data.direction_flag)
                {
                    buff_index = i;
                }
                else
                {
                    buff_index = STACK_BOARDS - i - 1;
                }

                for (uint8_t j = 0; j < AFE_CELL_VOLT_NUM * 2; j += 2)
                {
                    temp_data = (response_frame[j + READ_DATA_INDEX] << 8) | response_frame[j + READ_DATA_INDEX + 1];
                    cell_cnt = j / 2;
                    if (cell_cnt < AFE_CELL_VOLT_NUM)
                    {
                        g_afe_data[buff_index].cell_volt[AFE_CELL_VOLT_NUM - cell_cnt - 1] = temp_data * 19073 / 100000;
                        
#if !PACK_64S_PRJ
                        /*电压补偿*/
                        if (special_mode_get(ATUO_TEST))
                        {
                            g_afe_data[buff_index].cell_volt[AFE_CELL_VOLT_NUM - cell_cnt - 1] +=  ate_cell_compensate[buff_index][AFE_CELL_VOLT_NUM - cell_cnt - 1];
                        }
                        else
                        {
                            g_afe_data[buff_index].cell_volt[AFE_CELL_VOLT_NUM - cell_cnt - 1] +=  cell_compensate[buff_index][AFE_CELL_VOLT_NUM - cell_cnt - 1];                            
                        }
#endif                        
                        /******test测试一次跳变超过100mV的值*****/
                        cell_data = temp_data * 19073 / 100000; //
                        if ((abs((int32_t)g_cell_tmp[buff_index][AFE_CELL_VOLT_NUM - cell_cnt - 1] - (int32_t)cell_data)) > 100 && (0 != g_cell_tmp[buff_index][AFE_CELL_VOLT_NUM - cell_cnt - 1]))
                        {
                            // 请求检测断线检测
                            g_cell_volt_change_req_vc_wo_check = 1;
                            AFE_LOGD("[warn]:afeid:%d,preV[%d]:%dmV;nowV[%d]:%dmV\n",j, AFE_CELL_VOLT_NUM - cell_cnt - 1, g_cell_tmp[buff_index][AFE_CELL_VOLT_NUM - cell_cnt - 1], AFE_CELL_VOLT_NUM - cell_cnt - 1, cell_data);
                        }
                        g_cell_tmp[buff_index][AFE_CELL_VOLT_NUM - cell_cnt - 1] = cell_data;
                        /******test***************************/
                    }
                }
            }
            else
            {
                ret = -1;
                AFE_LOGW("[AFE]1.collect_cell_volt Id %d %d error: %d\n", response_frame[DEV_ID_INDEX], i + 1, ret);
                break;
            }
        }
        else
        {
            AFE_LOGW("[AFE]2.collect_cell_volt read %d error: %d\n", i + 1, ret);
            break;
        }
    }

    return ret;
}

static int32_t collect_temp(void)
{
    int32_t ret = 0;
    uint16_t temp_data_16 = 0;
    uint32_t res_val = 0;
    int16_t temperature = 0;
    uint32_t temp_data_32[2];
    uint8_t buff_index = 0;

    memset(response_frame, 0, sizeof(response_frame));

    if (false == g_temp_convert_channel_result) // 如果存在通道切换失败，跳过该次读取
    {
        return ret;
    }

    ret = bq79600_read_data(BQ79600_ADDR, GPIO1_HI, response_frame, 2, FRMWRT_STK_R, BQ79600_READ_MS);
    if (0 == ret) // 38译码器预留GPIO1做adc采集，GPIO2-4做通道切换
    {
        for (uint8_t i = S1; i < daisy_chain_data.current_stack_boards; i++)
        {
            if (response_frame[DEV_ID_INDEX + i * TEMP_READ_BUF_LEN] == (daisy_chain_data.current_stack_boards - i))
            {
                if (FORWARD_DIRECTION == daisy_chain_data.direction_flag)
                {
                    buff_index = daisy_chain_data.current_stack_boards - i - 1;
                }
                else
                {
                    buff_index = i + STACK_BOARDS - daisy_chain_data.current_stack_boards;
                }
                temp_data_16 = (response_frame[READ_DATA_INDEX + i * TEMP_READ_BUF_LEN] << 8) | response_frame[(READ_DATA_INDEX + 1) + i * TEMP_READ_BUF_LEN];

                temp_data_32[0] = (uint32_t)32768 * BQ79600_SAMP_VOLT / 100 - (uint32_t)temp_data_16 * BQ79600_REF_VOLT / 100;
                temp_data_32[1] = (uint32_t)temp_data_16 * BQ79600_REF_VOLT / 100 * BQ79600_TEMP_SAMPLE_RES;

                if (0 != temp_data_32[0])
                {
                    res_val = temp_data_32[1] * 100 / temp_data_32[0];

                    if (res_val >= U16_INVALID_VALUE)
                    {
                        res_val = U16_INVALID_VALUE - 1; // 防止被误认为转换成无效值
                    }
                }
                else
                {
                    res_val = 0;
                }
                temperature = res_to_temp((uint16_t)res_val, g_afe_ntc_res_tab, AFE_TEMP_TABLE_SIZE, AFE_TEMP_OFFSET);
                // AFE_LOGD("channel:%d, %d temp1 data: %x %x %d...\n", g_temp_sam_channel, i, response_frame[(READ_DATA_INDEX + 1) + i * TEMP_READ_BUF_LEN], response_frame[READ_DATA_INDEX + i * TEMP_READ_BUF_LEN], temperature);
                if (g_temp_sam_channel < AFE_CHANNEL1_CELL_TEMP_NUM)
                {
                    g_afe_data[buff_index].cell_temp[g_temp_sam_channel] = temperature;
                    temp_res_data[buff_index].afe_chan1_temp_res_buf[g_temp_sam_channel] = res_val;
                }
            }
            else
            {
                ret = -1;
                AFE_LOGW("[AFE]1.collect_temp read ID %d %d error, %d\n", response_frame[DEV_ID_INDEX + i * TEMP_READ_BUF_LEN], daisy_chain_data.current_stack_boards - i, ret);
                return ret;
            }
        }
    }
    else
    {
        AFE_LOGW("[AFE]2.collect_temp read GPIO1_HI error: %d\n", ret);
        return ret;
    }

    ret = bq79600_read_data(BQ79600_ADDR, GPIO5_HI, response_frame, 2, FRMWRT_STK_R, BQ79600_READ_MS);
    if (0 == ret) // 38译码器预留GPIO5做adc采集，GPIO6-8做通道切换
    {
        for (uint8_t i = S1; i < daisy_chain_data.current_stack_boards; i++)
        {
            if (response_frame[DEV_ID_INDEX + i * TEMP_READ_BUF_LEN] == (daisy_chain_data.current_stack_boards - i))
            {
                if (FORWARD_DIRECTION == daisy_chain_data.direction_flag)
                {
                    buff_index = daisy_chain_data.current_stack_boards - i - 1;
                }
                else
                {
                    buff_index = i + STACK_BOARDS - daisy_chain_data.current_stack_boards;
                }
                temp_data_16 = (response_frame[READ_DATA_INDEX + i * TEMP_READ_BUF_LEN] << 8) | response_frame[(READ_DATA_INDEX + 1) + i * TEMP_READ_BUF_LEN];

                temp_data_32[0] = (uint32_t)32768 * BQ79600_SAMP_VOLT / 100 - (uint32_t)temp_data_16 * BQ79600_REF_VOLT / 100;
                temp_data_32[1] = (uint32_t)temp_data_16 * BQ79600_REF_VOLT / 100 * BQ79600_TEMP_SAMPLE_RES;

                if (0 != temp_data_32[0])
                {
                    res_val = temp_data_32[1] * 100 / temp_data_32[0];

                    if (res_val >= U16_INVALID_VALUE)
                    {
                        res_val = U16_INVALID_VALUE - 1; // 防止被误认为转换成无效值
                    }
                }
                else
                {
                    res_val = 0;
                }
                temperature = res_to_temp((uint16_t)res_val, g_afe_ntc_res_tab, AFE_TEMP_TABLE_SIZE, AFE_TEMP_OFFSET);
                // AFE_LOGD("channel:%d, %d temp2 data: %x %x %d...\n", g_temp_sam_channel, i, response_frame[(READ_DATA_INDEX + 1) + i * TEMP_READ_BUF_LEN], response_frame[READ_DATA_INDEX + i * TEMP_READ_BUF_LEN], temperature);
                if (g_temp_sam_channel == PWR_TEMP_POS)
                {
                    g_afe_data[buff_index].pwr_temp[g_temp_sam_channel - PWR_TEMP_POS] = temperature;
                    temp_res_data[buff_index].afe_chan2_temp_res_buf[g_temp_sam_channel] = res_val;
                }
                else if ((g_temp_sam_channel == BALANCE_TEMP1_POS) || (g_temp_sam_channel == BALANCE_TEMP2_POS) )
                {
                    g_afe_data[buff_index].balance_temp[g_temp_sam_channel - BALANCE_TEMP1_POS] = temperature;
                    temp_res_data[buff_index].afe_chan2_temp_res_buf[g_temp_sam_channel] = res_val;
                }
#if PACK_64S_PRJ
                else if (g_temp_sam_channel == CELL_TEMP_POS)
                {
                    g_afe_data[buff_index].cell_temp[g_temp_sam_channel + AFE_CHANNEL1_CELL_TEMP_NUM] = temperature;    //afe的通道2电芯温度接着通道1之后
                    temp_res_data[buff_index].afe_chan2_temp_res_buf[g_temp_sam_channel] = res_val;                
                }
#endif                
                else
                {
                    ;
                }
            }
            else
            {
                ret = -2;
                AFE_LOGW("[AFE]3.collect_temp read ID %d %d error, %d\n", response_frame[DEV_ID_INDEX + i * TEMP_READ_BUF_LEN], daisy_chain_data.current_stack_boards - i, ret);
                return ret;
            }
        }
    }
    else
    {
        AFE_LOGW("[AFE]4.collect_temp read GPIO5_HI error: %d\n", ret);
        return ret;
    }

    return ret;
}

static int32_t convert_temp_channel(void)
{
    int32_t ret = 0;

    // 切换不同通道对应的寄存器值
    bq79600_config_reg_t temp_config_buf[] = {
        // 通道0
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF1, 0x2A, 0x2A, 1, FRMWRT_STK_W), // 设置GPIO1 为 ADC only input,GPIO2 As output low
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF2, 0x2D, 0x2D, 1, FRMWRT_STK_W), // 设置GPIO3,GPIO4 As output low
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF3, 0x2A, 0x2A, 1, FRMWRT_STK_W), // 设置GPIO5 为 ADC only input,GPIO6 As output low
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF4, 0x2D, 0x2D, 1, FRMWRT_STK_W), // 设置GPIO7,GPIO8 As output low
        // 通道1
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF1, 0x22, 0x22, 1, FRMWRT_STK_W), // 设置GPIO1 为 ADC only input,GPIO2 As output high
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF2, 0x2D, 0x2D, 1, FRMWRT_STK_W), // 设置GPIO3,GPIO4 As output low
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF3, 0x22, 0x22, 1, FRMWRT_STK_W), // 设置GPIO5 为 ADC only input,GPIO6 As output high
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF4, 0x2D, 0x2D, 1, FRMWRT_STK_W), // 设置GPIO7,GPIO8 As output low
        // 通道2
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF1, 0x2A, 0x2A, 1, FRMWRT_STK_W), // 设置GPIO1 为 ADC only input,GPIO2 As output low
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF2, 0x2C, 0x2C, 1, FRMWRT_STK_W), // 设置GPIO3As output high,GPIO4 As output low
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF3, 0x2A, 0x2A, 1, FRMWRT_STK_W), // 设置GPIO5 为 ADC only input,GPIO6 As output low
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF4, 0x2C, 0x2C, 1, FRMWRT_STK_W), // 设置GPIO7As output high,GPIO8 As output low
        // 通道3
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF1, 0x22, 0x22, 1, FRMWRT_STK_W), // 设置GPIO1 为 ADC only input,GPIO2 As output high
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF2, 0x2C, 0x2C, 1, FRMWRT_STK_W), // 设置GPIO3As output high,GPIO4 As output low
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF3, 0x22, 0x22, 1, FRMWRT_STK_W), // 设置GPIO5 为 ADC only input,GPIO6 As output high
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF4, 0x2C, 0x2C, 1, FRMWRT_STK_W), // 设置GPIO7As output high,GPIO8 As output low
        // 通道4
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF1, 0x2A, 0x2A, 1, FRMWRT_STK_W), // 设置GPIO1 为 ADC only input,GPIO2 As output low
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF2, 0x25, 0x25, 1, FRMWRT_STK_W), // 设置GPIO3As output low,GPIO4 As output high
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF3, 0x2A, 0x2A, 1, FRMWRT_STK_W), // 设置GPIO5 为 ADC only input,GPIO6 As output low
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF4, 0x25, 0x25, 1, FRMWRT_STK_W), // 设置GPIO7As output low,GPIO8 As output high
        // 通道5
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF1, 0x22, 0x22, 1, FRMWRT_STK_W), // 设置GPIO1 为 ADC only input,GPIO2 As output high
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF2, 0x25, 0x25, 1, FRMWRT_STK_W), // 设置GPIO3As output low,GPIO4 As output high
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF3, 0x22, 0x22, 1, FRMWRT_STK_W), // 设置GPIO5 为 ADC only input,GPIO6 As output high
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF4, 0x25, 0x25, 1, FRMWRT_STK_W), // 设置GPIO7As output low,GPIO8 As output high
        // 通道6
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF1, 0x2A, 0x2A, 1, FRMWRT_STK_W), // 设置GPIO1 为 ADC only input,GPIO2 As output low
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF2, 0x24, 0x24, 1, FRMWRT_STK_W), // 设置GPIO3,GPIO4 As output high
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF3, 0x2A, 0x2A, 1, FRMWRT_STK_W), // 设置GPIO5 为 ADC only input,GPIO6 As output low
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF4, 0x24, 0x24, 1, FRMWRT_STK_W), // 设置GPIO7,GPIO8 As output high
        // 通道7
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF1, 0x22, 0x22, 1, FRMWRT_STK_W), // 设置GPIO1 为 ADC only input,GPIO2 As output high
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF2, 0x24, 0x24, 1, FRMWRT_STK_W), // 设置GPIO3,GPIO4 As output high
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF3, 0x22, 0x22, 1, FRMWRT_STK_W), // 设置GPIO5 为 ADC only input,GPIO6 As output high
        BQ79600_REG_CONFIG(BQ79600_ADDR, GPIO_CONF4, 0x24, 0x24, 1, FRMWRT_STK_W), // 设置GPIO7,GPIO8 As output high

    };
    // 通道转换
    if (CHAIN_BREAK == daisy_chain_data.chain_break_flag)
    {
        if (FORWARD_DIRECTION == daisy_chain_data.direction_flag)
        {
            g_temp_forward_index = (g_temp_forward_index + 1) % MULTIPLEXER_CHAN;
            g_temp_sam_channel = g_temp_forward_index;
        }
        else
        {
            g_temp_reverse_index = (g_temp_reverse_index + 1) % MULTIPLEXER_CHAN;
            g_temp_sam_channel = g_temp_reverse_index;
        }
    }
    else
    {
        g_temp_sam_channel = (g_temp_sam_channel + 1) % MULTIPLEXER_CHAN;
    }
    // 切换通道
    for (uint8_t i = g_temp_sam_channel * TEMP_SET_REG, j = 0; (i < (sizeof(temp_config_buf) / sizeof(bq79600_config_reg_t))) && (j < TEMP_SET_REG); i++, j++)
    {
        ret = bq79600_write_data(&temp_config_buf[i]);
        if (0 > ret)
        {
            (g_temp_sam_channel) ? (g_temp_sam_channel--) : (g_temp_sam_channel = (MULTIPLEXER_CHAN - 1)); // 下次继续转换成该通道，并且在下次成功切通道前，不读温度值；
            g_temp_convert_channel_result = false;
            AFE_LOGW("[AFE]1.convert_temp_channel %d error: %d\n", g_temp_sam_channel, ret);
            return ret;
        }
        else
        {
            g_temp_convert_channel_result = true;
        }
    }

    return ret;
}

static int32_t collect_bat_vol(void)
{
    int32_t ret = 0;
    uint16_t temp_data;
    uint8_t buff_index = 0;

    memset(response_frame, 0, sizeof(response_frame));

    ret = bq79600_read_data(BQ79600_ADDR, AUX_BAT_HI, response_frame, 2, FRMWRT_STK_R, BQ79600_READ_MS);
    if (0 == ret)
    {
        for (uint8_t i = S1; i < daisy_chain_data.current_stack_boards; i++)
        {
            if (response_frame[DEV_ID_INDEX + i * BAT_READ_BUF_LEN] == (daisy_chain_data.current_stack_boards - i))
            {
                if (FORWARD_DIRECTION == daisy_chain_data.direction_flag)
                {
                    buff_index = daisy_chain_data.current_stack_boards - i - 1;
                }
                else
                {
                    buff_index = i + STACK_BOARDS - daisy_chain_data.current_stack_boards;
                }
                temp_data = (response_frame[READ_DATA_INDEX + i * BAT_READ_BUF_LEN] << 8) | response_frame[(READ_DATA_INDEX + 1) + i * BAT_READ_BUF_LEN];

                g_afe_data[buff_index].battery_volt = temp_data * 305 / 100; // 0.001V
                // AFE_LOGD("%d BATVOLT data: %x %x %d...\n", i, response_frame[(READ_DATA_INDEX + 1) + i * BAT_READ_BUF_LEN], response_frame[READ_DATA_INDEX + i * BAT_READ_BUF_LEN], g_afe_data[buff_index].battery_volt);
            }
            else
            {
                ret = -1;
                AFE_LOGW("[AFE]1.collect_temp read ID %d %d error, %d\n", response_frame[DEV_ID_INDEX + i * BAT_READ_BUF_LEN], daisy_chain_data.current_stack_boards - i, ret);
                return ret;
            }
        }
    }
    else
    {
        AFE_LOGW("[AFE]2.collect_bat_vol error: %d\n", ret);
        return ret;
    }

    return ret;
}

// 返回值： 小于0表示读取值失败，=0表示成功
static int32_t bq79600_afe_vc_wire_open_start(void)
{
    int32_t ret = 0;
    bq79600_config_reg_t temp = BQ79600_REG_CONFIG(BQ79600_ADDR, DIAG_COMP_CTRL2, 0x01, 0x01, 1, FRMWRT_STK_W);  // 设置CV开路比较阈值 500mV-5V，300mV为步进，0x01表示800mV
    bq79600_config_reg_t temp1 = BQ79600_REG_CONFIG(BQ79600_ADDR, DIAG_COMP_CTRL3, 0x15, 0x14, 1, FRMWRT_STK_W); // 设置CV开路检测配置
    bq79600_config_reg_t temp2 = BQ79600_REG_CONFIG(BQ79600_ADDR, FAULT_RST1, 0x4, 0x0, 1, FRMWRT_STK_W);        // CLEAR  FAULT_COMP_* registers to 0x00

    ret = bq79600_write_data(&temp2);
    if (0 > ret)
    {
        AFE_LOGW("[AFE]ClrFaultErr\n");
        return ret;
    }
    ret = bq79600_write_data(&temp);
    if (0 > ret)
    {
        AFE_LOGW("[AFE]SetVCValErr\n");
        return ret;
    }
    ret = bq79600_write_data(&temp1);
    if (0 > ret)
    {
        AFE_LOGW("[AFE]SetVCStartErr\n");
        return ret;
    }
    return 0;
}

// 返回值： 小于0表示读取值失败，=0数据获取完成，1：数据还没ok
static int32_t bq79600_afe_vc_wire_open_result_get(void)
{
    uint8_t state[STACK_BOARDS] = {0};
    uint8_t buff_index = 0;

    memset(response_frame, 0, sizeof(response_frame));

    if (0 == bq79600_read_data(BQ79600_ADDR, ADC_STAT2, response_frame, 1, FRMWRT_STK_R, BQ79600_READ_MS))
    {
        for (uint8_t i = S1; i < daisy_chain_data.current_stack_boards; i++)
        {
            if (response_frame[DEV_ID_INDEX + i * 7] == (daisy_chain_data.current_stack_boards - i))
            {
                state[i] = response_frame[READ_DATA_INDEX + i * 7];

                if ((state[i] & 0x08) == 0)
                {
                    return AFE_VC_CHECKING; // 表示没有检测完成
                }
            }
            else
            {
            }
        }
    }
    else
    {
        return AFE_VC_READ_REG_ERR;
    }

    // 获取断线寄存器结果
    uint8_t err_flag = 0;    
    uint32_t open_bits[STACK_BOARDS] = {0};
    memset(response_frame, 0, sizeof(response_frame));
    if (0 == bq79600_read_data(BQ79600_ADDR, FAULT_COMP_VCOW1, response_frame, 2, FRMWRT_STK_R, BQ79600_READ_MS))
    {
        for (uint8_t i = 0; i < daisy_chain_data.current_stack_boards; i++)
        {
            if (response_frame[DEV_ID_INDEX + i * 8] == (daisy_chain_data.current_stack_boards - i))
            {
                if (FORWARD_DIRECTION == daisy_chain_data.direction_flag)
                {
                    buff_index = daisy_chain_data.current_stack_boards - i - 1;
                }
                else
                {
                    buff_index = i + STACK_BOARDS - daisy_chain_data.current_stack_boards;
                }
                open_bits[buff_index] = ((response_frame[READ_DATA_INDEX + i * 8] << 8) | response_frame[(READ_DATA_INDEX + 1) + i * 8]);
                g_vc_wire_open_param.open_bits[buff_index] = open_bits[buff_index];
                AFE_LOGE("[AFE]AFE id: %d, VCBits#%lx\n", buff_index + 1, g_vc_wire_open_param.open_bits[buff_index]);
                if (g_vc_wire_open_param.open_bits[buff_index] != 0)
                {
                    err_flag = 1;
                }
            }
            else
            {
                ;
            }
        }
    }
    else
    {
        return AFE_VC_READ_REG_ERR;
    }

    if (err_flag)
    {
        g_vc_wire_open_param.check_suc_cnt = 0;
        g_vc_wire_open_param.max_check_cnt++;
        if (++g_vc_wire_open_param.check_err_cnt >= 3)
        {
            g_afe_vc_wo_result = AFE_WO_ABNORMAL;
        }
        else
        {
            if (g_vc_wire_open_param.max_check_cnt > 10)
            {
                g_afe_vc_wo_result = AFE_WO_NORMAL;
            }
            else
            {
                return AFE_VC_RECHECK; // 需要重新检测
            }
        }
    }
    else
    {
        g_vc_wire_open_param.check_err_cnt = 0;
        g_vc_wire_open_param.max_check_cnt++;
        if (++g_vc_wire_open_param.check_suc_cnt >= 3 || g_vc_wire_open_param.max_check_cnt > 10)
        {
            g_afe_vc_wo_result = AFE_WO_NORMAL;
        }
        else
        {
            return AFE_VC_RECHECK; // 需要重新检测
        }
    }
    return AFE_VC_CHECK_FINISH;
}

// 返回值： 小于0表示读取值失败，=0数据获取完成
static int32_t bq79600_afe_vc_wire_open_finish(void)
{
    bq79600_config_reg_t temp = BQ79600_REG_CONFIG(BQ79600_ADDR, DIAG_COMP_CTRL3, 0x00, 0x00, 1, FRMWRT_STK_W); // 设置CV开路检测配置 关闭下拉电流
    return bq79600_write_data(&temp);
}

// 启动开路检测
int32_t bq79600_afe_cell_volt_wire_open_check(void)
{
    if (g_vc_wire_open_param.state == AFE_VC_WO_CHECK_IDLE)
    {
        if (g_afe_vc_wo_result == AFE_WO_ABNORMAL)
        {
            return AFE_CELL_RESULT_WIRE_OPEN;
        }
        else
        {
            return AFE_CELL_RESULT_END;
        }
    }
    int32_t result = AFE_CELL_RESULT_CHECKING;  //返回值
    int32_t ret = 0;    //内部使用
    switch (g_vc_wire_open_param.state)
    {
    case AFE_VC_WO_CHECK_INIT:
        g_afe_vc_wo_result = AFE_WO_CHECK_INIT;
        if (g_vc_wire_open_param.start_flag)
        {
            g_vc_wire_open_param.state = AFE_VC_WO_START_CHECK;
//            g_vc_wire_open_param.over_time_cnt = 0;
            g_vc_wire_open_param.err_cnt = 0;
            g_vc_wire_open_param.over_timer = sdk_tick_get();
        }
        else
        {
            g_vc_wire_open_param.state = AFE_VC_WO_FINISHED;
            AFE_LOGD("[AFE]NoStartVC\n");
        }
        break;
    case AFE_VC_WO_START_CHECK:
        g_afe_vc_wo_result = AFE_WO_CHECKING;
        if (0 == bq79600_afe_vc_wire_open_start())
        {
            g_vc_wire_open_param.state = AFE_VC_WO_GET_RESULT;
        }
        else
        {
            g_vc_wire_open_param.err_cnt++;
            if (g_vc_wire_open_param.err_cnt >= AFE_VC_TIME_OUT_CNT)
            {
                g_vc_wire_open_param.state = AFE_VC_WO_FINISHED;
                g_afe_vc_wo_result = AFE_WO_OVER_ERR;
                AFE_LOGW("[AFE]VCcfgErr\n");
            }
            result = AFE_CELL_RESULT_ERR;
        }
        break;
    case AFE_VC_WO_GET_RESULT:
        ret = bq79600_afe_vc_wire_open_result_get();
        if (ret < 0)
        {
            g_vc_wire_open_param.err_cnt++;
            if (g_vc_wire_open_param.err_cnt >= AFE_VC_TIME_OUT_CNT)
            {
                g_vc_wire_open_param.state = AFE_VC_WO_FINISHED;
                g_afe_vc_wo_result = AFE_WO_OVER_ERR;
                AFE_LOGW("[AFE]VCRltErr%d\n", ret);
            }
            result = AFE_CELL_RESULT_ERR;
        }
        else if (ret == AFE_VC_CHECK_FINISH)
        {
            g_vc_wire_open_param.state = AFE_VC_WO_FINISHED;
        }
        else if (ret == AFE_VC_RECHECK)
        {
            g_vc_wire_open_param.start_flag = 1;
            g_vc_wire_open_param.state = AFE_VC_WO_CHECK_INIT;
        }
        break;
    case AFE_VC_WO_FINISHED:
        if (0 == bq79600_afe_vc_wire_open_finish())
        {
            if (g_vc_wire_open_param.max_check_cnt != 0)
            {
                if (g_vc_wire_open_param.max_check_cnt > 10)
                {
                    AFE_LOGW("[AFE]VCmaxChk\n");
                }
                g_vc_wire_open_param.max_check_cnt = 0;
            }
            g_vc_wire_open_param.start_flag = 0;
            g_vc_wire_open_param.state = AFE_VC_WO_CHECK_IDLE;
        }
        else
        {
            result = AFE_CELL_RESULT_ERR;
        }
        break;
    default:
        g_vc_wire_open_param.state = AFE_VC_WO_START_CHECK;
        break;
    }
    // 超时处理
    if (true == sdk_is_tick_over(g_vc_wire_open_param.over_timer, os_tick_from_millisecond(1000)))
    {
        g_vc_wire_open_param.over_timer = sdk_tick_get();
//        g_vc_wire_open_param.over_time_cnt++;
//        if (g_vc_wire_open_param.over_time_cnt >= AFE_VC_TIME_OUT_CNT)
        {
            g_vc_wire_open_param.state = AFE_VC_WO_FINISHED;
            g_afe_vc_wo_result = AFE_WO_OVER_TIME;
            result = AFE_CELL_RESULT_ERR;
            AFE_LOGW("[AFE]VCTimeO\n");
        }
    }
    return result;
}

// 检测电芯电压异常启动断线检测
int32_t cell_volt_abnormal_wo_check_req(void)
{
    if (g_cell_volt_change_req_vc_wo_check)
    {
        g_cell_volt_change_req_vc_wo_check = 0;
        return true;
    }
    for (uint8_t i = S1; i < daisy_chain_data.current_stack_boards; i++)
    {
        for (uint8_t cell_id = 0; cell_id < AFE_CELL_VOLT_NUM; cell_id++)
        {
            if (g_afe_data[i].cell_volt[cell_id] == I16_INVALID_VALUE)
            {
                continue;
            }
            if (g_afe_data[i].cell_volt[cell_id] < 850 || g_afe_data[i].cell_volt[cell_id] > 4000) // 电芯电压采样小于850mV 或者大于4V，认为可能断线
            {
                return true;
            }
            if (cell_id == 0)
            {
                continue;
            }
            if (I16_INVALID_VALUE == g_afe_data[i].cell_volt[cell_id - 1])
            {
                continue;
            }
            if (g_afe_data[i].cell_volt[cell_id] - g_afe_data[i].cell_volt[cell_id - 1] > 4000) // 电芯n电压-电芯n-1电压 大于 4V，认为可能断线
            {
                return true;
            }
        }
    }

    return false;
}

// 请求启动断线检测
void bq79600_afe_vc_wire_open_check_req(void)
{
    if (g_afe_vc_wo_result == AFE_WO_ABNORMAL)
    {
        return;
    }
    g_vc_wire_open_param.start_flag = 1;
    g_vc_wire_open_param.state = AFE_VC_WO_CHECK_INIT;
    g_afe_vc_wo_result = AFE_WO_CHECK_INIT;
    g_vc_wire_open_param.err_cnt = 0;
    memset(g_vc_wire_open_param.open_bits, 0, sizeof(g_vc_wire_open_param.open_bits));
    g_vc_wire_open_param.check_err_cnt = 0;
    g_vc_wire_open_param.check_suc_cnt = 0;
    g_vc_wire_open_param.max_check_cnt = 0;    
    g_afe_vc_wo_result = AFE_WO_CHECK_INIT;    
}

int32_t bq79600_collect_bat_volt(void)
{
    int ret = 0;

    ret = collect_bat_vol();

    return ret;
}

int32_t bq79600_collect_cell_volt(void)
{
    int ret = 0;

    os_delay(os_tick_from_millisecond(10)); // 关闭均衡后延时一段时间待电压稳定再读取,考虑到之前的温度获取自带时间

    ret = collect_cell_volt();

    return ret;
}

// val: 0->暂停全通道均衡， 1->解除暂停全通道均衡， 2->解除暂停全通道均衡且更新均衡计时
static int32_t start_stop_balance(stack_board_name_e name, uint8_t val)
{
    int32_t ret = 0;
    bq79600_config_reg_t temp_config_buf = BQ79600_REG_CONFIG(name + 1, BAL_CTRL2, 0x00, NOT_NEED_CHECK, 1, FRMWRT_SGL_W);

    if (val == 0)
    {
        temp_config_buf.val = 0x41;
    }

    if (0 != val)
    {
        temp_config_buf.val = 0x01;
        temp_config_buf.target_val = 0x01; // Mmodify 需要回应

        if (2 == val)
        {
            temp_config_buf.val = 0x03;
        }
    }

    ret = bq79600_write_data(&temp_config_buf);

    return ret;
}

#define BALANCE_OVER_TIME 0x05ull // 硬件均衡时间： 10min
static void set_balance_bit(stack_board_name_e name, uint64_t *val_high, uint64_t *val_low)
{
    if (name >= STACK_BOARDS)
    {
        return;
    }

    for (uint8_t i = 0; i < AFE_CELL_VOLT_NUM; i++)
    {
        if (g_balance_data[name].balance_ctrl_flag & (1UL << i))
        {
            if (i < 8)
            {
                *val_low |= (BALANCE_OVER_TIME << ((7 - i) * 8)); // 1 - 8节电芯均衡
            }
            else if (i < AFE_CELL_VOLT_NUM)
            {
                *val_high |= (BALANCE_OVER_TIME << ((15 - i) * 8)); // 9 - 16节电芯均衡
            }
        }
    }
}

#define UPDATA_BALANCE_MS (10 * 60 * 1000)
// ctrl:  0->禁用均衡，1->启动均衡
int32_t bq79600_balance_ctrl(uint8_t ctrl)
{
    int32_t ret = 0;
    uint8_t buff_index = 0;
    static uint32_t updata_balance_tick[STACK_BOARDS] = {0};

    for (uint8_t i = S1; i < daisy_chain_data.current_stack_boards; i++)
    {
        if (FORWARD_DIRECTION == daisy_chain_data.direction_flag)
        {
            buff_index = i;
        }
        else
        {
            buff_index = STACK_BOARDS - i - 1;
        }
        bq79600_config_reg_t temp_config_buf[] =
            {
                BQ79600_REG_CONFIG(i + 1, CB_CELL16_CTRL, 0x00, NOT_NEED_CHECK, 8, FRMWRT_SGL_W),
                BQ79600_REG_CONFIG(i + 1, CB_CELL8_CTRL, 0x00, NOT_NEED_CHECK, 8, FRMWRT_SGL_W),
            };
        if ((0 == ctrl) || (0 == g_balance_data[buff_index].balance_ctrl_flag))
        {
            ret = start_stop_balance((stack_board_name_e)i, 0);
            if (0 > ret)
            {
                AFE_LOGW("[AFE]1.bq79600_balance_ctrl: %d error: %d\n", i + 1, ret);
            }

            if (0 == g_balance_data[buff_index].balance_ctrl_flag)
            {
                g_balance_data[buff_index].balance_state = 0; // 更新balance_state
            }
        }
        else
        {
            // 周期10min更新配置均衡相关的寄存器
            if ((true == sdk_is_tick_over(updata_balance_tick[buff_index], os_tick_from_millisecond(UPDATA_BALANCE_MS))) || (g_balance_data[buff_index].balance_state != g_balance_data[buff_index].balance_ctrl_flag))
            {
                updata_balance_tick[buff_index] = sdk_tick_get();
                g_balance_data[buff_index].balance_state = g_balance_data[buff_index].balance_ctrl_flag;
                set_balance_bit((stack_board_name_e)buff_index, &temp_config_buf[0].val, &temp_config_buf[1].val); // 更新寄存器值

                for (uint8_t j = 0; j < (sizeof(temp_config_buf) / sizeof(bq79600_config_reg_t)); j++)
                {
                    ret = bq79600_write_data(&temp_config_buf[j]);
                    if (0 > ret)
                    {
                        AFE_LOGW("[AFE]2.bq79600_balance_ctrl: %d config error: %d\n", j + 1, ret);
                    }
                }

                ret = start_stop_balance((stack_board_name_e)i, 2);
                if (0 > ret)
                {
                    AFE_LOGW("[AFE]3.bq79600_balance_ctrl: %d error: %d\n", i + 1, ret);
                }
            }
            else
            {
                ret = start_stop_balance((stack_board_name_e)i, 1);
                if (0 > ret)
                {
                    AFE_LOGW("[AFE]4.bq79600_balance_ctrl: %d error: %d\n", i + 1, ret);
                }
            }
        }
    }

    return ret;
}

int32_t bq79616_wakeup(void)
{
    int32_t ret = 0;

    bq79600_config_reg_t temp_forward_config_buf[] = {
        BQ79600_REG_CONFIG(BQ79600_ADDR, CONTROL1, 0x00, NOT_NEED_CHECK, 1, FRMWRT_SGL_W),
        BQ79600_REG_CONFIG(BQ79600_ADDR, CONTROL1, 0x00, NOT_NEED_CHECK, 1, FRMWRT_REV_ALL_W),
        BQ79600_REG_CONFIG(BQ79600_ADDR, CONTROL1, 0x20, NOT_NEED_CHECK, 1, FRMWRT_SGL_W),
    };
    bq79600_config_reg_t temp_reverse_config_buf[] = {
        BQ79600_REG_CONFIG(BQ79600_ADDR, CONTROL1, 0xA0, NOT_NEED_CHECK, 1, FRMWRT_SGL_W),
    };

#if (1 == REVERSE_ADDR_ENABLE)
    for (uint8_t i = 0; i < (sizeof(temp_reverse_config_buf) / sizeof(bq79600_config_reg_t)); i++)
    {
        ret = bq79600_write_data(&temp_reverse_config_buf[i]);
        if (0 > ret)
        {
            AFE_LOGW("[AFE]1.bq79616_wakeup write %d error: %d\n", i, ret);
            return ret;
        }
    }
#endif
#if (1 == FORWARD_ADDR_ENABLE)
    for (uint8_t i = 0; i < (sizeof(temp_forward_config_buf) / sizeof(bq79600_config_reg_t)); i++)
    {
        ret = bq79600_write_data(&temp_forward_config_buf[i]);
        if (0 > ret)
        {
            AFE_LOGW("[AFE]2.bq79616_wakeup write %d error: %d\n", i, ret);
            return ret;
        }
    }
#endif

    return ret;
}

int32_t bq79616_shutdown(void)
{
    bq79600_config_reg_t temp = BQ79600_REG_CONFIG(BQ79600_ADDR, CONTROL1, 0x40, NOT_NEED_CHECK, 1, FRMWRT_SGL_W); // 79600发SEND_SHUTDOWN指令给79616
    if (0 == bq79600_write_data(&temp))
    {
        os_delay(TICK_1MS);
        return 0;
    }
    os_delay(TICK_1MS);

    return -1;
}

int32_t bq79600_shutdown(void)
{
    int32_t ret = 0;
    bq79600_config_reg_t temp_config_buf1 = BQ79600_REG_CONFIG(BQ79600_ADDR, CONTROL1, 0x08, NOT_NEED_CHECK, 1, FRMWRT_STK_W);
    bq79600_config_reg_t temp_config_buf2 = BQ79600_REG_CONFIG(BQ79600_ADDR, CONTROL1, 0x08, NOT_NEED_CHECK, 1, FRMWRT_ALL_W);

    if (CHAIN_UNBREAK == daisy_chain_data.chain_break_flag)
    {
        ret = bq79600_write_data(&temp_config_buf2);
    }
    else
    {
        ret = bq79600_write_data(&temp_config_buf1);
        if (0 == ret)
        {
            toggle_comm_dir(!daisy_chain_data.direction_flag);
            ret = bq79600_write_data(&temp_config_buf2);
        }
    }

   os_delay(TICK_1MS);

    return ret;
}

static int32_t bq79600_write_data(bq79600_config_reg_t *val)
{
    int32_t ret = 0;

    for (uint8_t i = 0; i < RETRY_NUM; i++)
    {
        ret = write_reg(val->dev_id, val->addr, val->val, val->target_val, val->write_len, val->operate_type);
        if (0 == ret)
        {
            if (NOT_NEED_CHECK == val->target_val)
            {
                os_delay(TICK_1MS);
            }

            return ret;
        }
        os_delay(TICK_1MS);
    }

    return ret;
}

/**
 * @brief		读取bq79600通信数据
 * @param		[in] dev_id			设备号
 * @param		[in] addr			读取的地址
 * @param		[in] buf			读取数据Buf
 * @param		[in] read_len		读取长度
 * @param		[in] operate_type	读取类型（单个读取/广播读取）
 * @param		[in] delay_ms		等待IC回复时间
 * @return		执行结果
 * @retval		0 成功
 * @retval		-1 失败
 */
static int32_t bq79600_read_data(uint8_t dev_id, uint16_t addr, uint8_t *buf, uint8_t read_len, uint8_t operate_type, uint32_t delay_ms)
{
    int32_t ret = 0;

    for (uint8_t i = 0; i < RETRY_NUM; i++)
    {
        ret = read_reg(dev_id, addr, buf, read_len, operate_type, delay_ms);
        if (0 == ret)
        {
            return ret;
        }
        bq79600_comm_clear();
        os_delay(TICK_1MS);
    }

    return ret;
}

/**
 * @brief      afe电芯温度采样异常状态获取
 * @param      [in]other_ntc_type_e（只能查询片内）
 * @return     返回结果
 * @retval     [out]ret(SAMPLE_STATE_OK)  获取采集状态成功
 * @retval     [out]ret(SAMPLE_STATE_EOI) 获取采集状态失败
 * @retval     [out]ret(NTC_SHORT_CIRCUIT) NTC短路
 * @retval     [out]ret(NTC_OPEN_CIRCUIT)  NTC开路
 * @warning    在采集任务开始以后调用
 */
int32_t afe_cell_temp_sample_abnormal_get(stack_board_name_e name, uint8_t type)
{
    int32_t ret = 0;

    if (name >= STACK_BOARDS)
    {
        ret = -3;
        return ret;
    }

    if ((type < AFE_CHANNEL1_TEMP_TOTAL_NUM) && (temp_res_data[name].afe_chan1_temp_res_buf[type] != U16_INVALID_VALUE)) // 有转换到值
    {
        ret = sample_res_ntc_abnormal_judge(temp_res_data[name].afe_chan1_temp_res_buf[type], g_afe_ntc_res_tab, AFE_TEMP_TABLE_SIZE);
    }
#if PACK_64S_PRJ    
    else if((type == AFE_CHANNEL1_TEMP_TOTAL_NUM) && (temp_res_data[name].afe_chan2_temp_res_buf[CELL_TEMP_POS] != U16_INVALID_VALUE)) // afe channel2的第一个温度
    {
        ret = sample_res_ntc_abnormal_judge(temp_res_data[name].afe_chan2_temp_res_buf[CELL_TEMP_POS], g_afe_ntc_res_tab, AFE_TEMP_TABLE_SIZE);
    }    
#endif    
    return ret;
}

/**
 * @brief      afe其他温度采样异常状态获取
 * @param      [in]other_ntc_type_e（只能查询片内）
 * @return     返回结果
 * @retval     [out]ret(SAMPLE_STATE_OK)  获取采集状态成功
 * @retval     [out]ret(SAMPLE_STATE_EOI) 获取采集状态失败
 * @retval     [out]ret(NTC_SHORT_CIRCUIT) NTC短路
 * @retval     [out]ret(NTC_OPEN_CIRCUIT)  NTC开路
 * @warning    在采集任务开始以后调用
 */
int32_t afe_other_temp_sample_abnormal_get(stack_board_name_e name, uint8_t type)
{
    int32_t ret = 0;

    if (name >= STACK_BOARDS)
    {
        ret = -3;
        return ret;
    }

    if ((type < AFE_CHANNEL2_TEMP_TOTAL_NUM) && (temp_res_data[name].afe_chan2_temp_res_buf[type] != U16_INVALID_VALUE))
    {
        ret = sample_res_ntc_abnormal_judge(temp_res_data[name].afe_chan2_temp_res_buf[type], g_afe_ntc_res_tab, AFE_TEMP_TABLE_SIZE);
    }

    return ret;
}

static int32_t sample_data_100ms(void)
{
    int32_t ret = 0;

    ret = bq79600_balance_ctrl(0); // 关闭均衡控制模块
    if (0 > ret)
    {
        return ret;
    }

    ret = bq79600_collect_cell_volt();
    if (0 > ret)
    {
        return ret;
    }

    ret = bq79600_collect_bat_volt();
    if (0 > ret)
    {
        return ret;
    }

    ret = collect_temp();
    if (0 > ret)
    {
        return ret;
    }

    ret = convert_temp_channel();
    if (0 > ret)
    {
        return ret;
    }

    // 电芯电压断线故障触发不再请求断线检测
    if ((g_afe_vc_wo_result != AFE_WO_ABNORMAL) &&
        (cell_volt_abnormal_wo_check_req() || vc_wire_open_check_one_day_cnt >= AFE_REQ_VC_WITE_OPEN_CHECK_TIME))
    {
        if (vc_wire_open_check_one_day_cnt >= AFE_REQ_VC_WITE_OPEN_CHECK_TIME)
        {
            vc_wire_open_check_one_day_cnt = 0;
        }
        bq79600_afe_vc_wire_open_check_req();
        ret = 1;
        return ret;
    }

    ret = bq79600_balance_ctrl(1); // 启动均衡控制模块
    if (0 > ret)
    {
        return ret;
    }

    return ret;
}

int32_t bq79600_sample_100ms(void)
{
    int32_t ret = 0;
    static uint32_t delay_tick = 0;
    vc_wire_open_check_one_day_cnt++;

    if (true == sdk_is_tick_over(delay_tick, TICK_100MS))
    {
        ret = sample_data_100ms();
        if (0 != ret)
        {
            return ret;
        }

        if (CHAIN_BREAK == daisy_chain_data.chain_break_flag)
        {
            toggle_comm_dir(!daisy_chain_data.direction_flag);

            (g_temp_sam_channel) ? (g_temp_sam_channel--) : (g_temp_sam_channel = (MULTIPLEXER_CHAN - 1));

            ret = sample_data_100ms();
            if (0 != ret)
            {
                return ret;
            }
        }

        delay_tick = sdk_tick_get();
    }

    return ret;
}

void temp_data_print(uint8_t name)
{
    AFE_LOGD("AFE chip << %d >>:\n", name);
    AFE_LOGD("\n");
    for (uint8_t j = 0; j < AFE_CELL_VOLT_NUM; j++)
    {
        AFE_LOGD("cell Volt %2d = %d...\n", j + 1, g_afe_data[name - 1].cell_volt[j]);
    }
    AFE_LOGD("\n");
    for (uint8_t j = 0; j < AFE_CELL_TEMP_NUM; j++)
    {
        AFE_LOGD("cell temp %d = %d...\n", j + 1, g_afe_data[name - 1].cell_temp[j]);
    }
    AFE_LOGD("\n");
    for (uint8_t j = 0; j < AFE_POWER_TEMP_NUM; j++)
    {
        AFE_LOGD("pwr temp %d = %d...\n", j + 1, g_afe_data[name - 1].pwr_temp[j]);
    }
    AFE_LOGD("\n");
    for (uint8_t j = 0; j < AFE_BALANCE_TEMP_NUM; j++)
    {
        AFE_LOGD("balance temp %d = %d...\n", j + 1, g_afe_data[name - 1].balance_temp[j]);
    }
    AFE_LOGD("\n");
    AFE_LOGD("bat volt = %d...\n", g_afe_data[name - 1].battery_volt);
    AFE_LOGD("\n");
    for (uint8_t j = 0; j < AFE_CHANNEL1_TEMP_TOTAL_NUM; j++)
    {
        AFE_LOGD("channel1 res %d = %d...\n", j + 1, temp_res_data[name - 1].afe_chan1_temp_res_buf[j]);
    }
    AFE_LOGD("\n");
    for (uint8_t j = 0; j < AFE_CHANNEL2_TEMP_TOTAL_NUM; j++)
    {
        AFE_LOGD("channel2 res %d = %d...\n", j + 1, temp_res_data[name - 1].afe_chan2_temp_res_buf[j]);
    }
}

void pos_data_print(void)
{
    AFE_LOGD("[AFE]break_flag = %d, dir = %d, forward_pos = %d, reverse_pos = %d...\n", daisy_chain_data.chain_break_flag, daisy_chain_data.direction_flag, daisy_chain_data.chain_break_forward_pos, daisy_chain_data.chain_break_reverse_pos);
}

void volt_comp_data_print(void)
{
    uint32_t cell_volt_sum = 0;
    uint32_t bat_volt_sum = 0;

    for (uint8_t i = S1; i < STACK_BOARDS; i++)
    {
        for (uint8_t j = 0; j < AFE_CELL_VOLT_NUM; j++)
        {
            cell_volt_sum += g_afe_data[i].cell_volt[j];
        }
    }

    for (uint8_t i = S1; i < STACK_BOARDS; i++)
    {
        bat_volt_sum += g_afe_data[i].battery_volt;
    }

    AFE_LOGD("bat_volt_sum = %d  cell_volt_sum = %d  diff = %d...\n", bat_volt_sum, cell_volt_sum, bat_volt_sum - cell_volt_sum);
}

void afe_help_print(void)
{
    AFE_LOGD("afe_data print value<1 - 4>...\n");
    AFE_LOGD("afe_data daisy_chain_info...\n");
    AFE_LOGD("afe_data volt_comp...\n");
}

/**
 * @brief                数据读取
 * @return               返回结果空
 * @warning              测试调试使用
 */
int32_t afe_data(int argc, char *argv[])
{
    uint8_t chip_name = 0;

    if (argc < 2)
    {
        log_d("%s para err\n", argv[0]); // 打印命令名称
    }
    else
    {
        if (!strcmp(argv[1], "print"))
        {
            chip_name = atoi(argv[2]);
            if ((S1 < chip_name) && (STACK_BOARDS >= chip_name))
            {
                temp_data_print(chip_name);
            }
        }
        else if (!strcmp(argv[1], "daisy_chain_info"))
        {
            pos_data_print();
        }
        else if (!strcmp(argv[1], "volt_comp"))
        {
            volt_comp_data_print();
        }
        else if (!strcmp(argv[1], "help"))
        {
            afe_help_print();
        }
    }

    return 0;
}
MSH_CMD_EXPORT(afe_data, <help>);

void test_afe_balance_set(stack_board_name_e name, uint32_t enable_flag)
{
    if(0 == g_app_afe_bala_debug_flag)
    {
        return;
    }
    if (name >= STACK_BOARDS)
    {
        return;
    }
    g_balance_data[name].balance_ctrl_flag = (enable_flag & 0x00000FFF);
}

void balance_test_proc(uint8_t para2, uint8_t para3, uint8_t para4, uint8_t para5)
{

	uint32_t balance_pos = 0;
	uint8_t	debug_able = para2;
	uint8_t	chip_name = para3;
	uint8_t	index = para4;
	uint8_t	operation = para5;
	if(0 == debug_able)
	{
        return;
	}
//	afe_balance_state_get((stack_board_name_e)(chip_name - 1), &balance_pos);

	if (1 == operation)
	{
		if (0 == index) // 均衡序号为0，则操作所有
		{
			balance_pos |= 0x0000FFFF;
		}
		else if (index <= 12)
		{
			balance_pos |= (0x00000001 << (index - 1));
		}
		else
		{
			AFE_LOGD("balance set para error...\n");
			return;
		}

		test_afe_balance_set((stack_board_name_e)(chip_name - 1), balance_pos);
		AFE_LOGD("balance set OK, balance pos %x...\n", (uint16_t)balance_pos);
	}
	else if (0 == operation)
	{
		if (0 == index) // 均衡序号为0，则操作所有
		{
			balance_pos &= ~0x0000FFFF;
		}
		else if (index <= 12)
		{
			balance_pos &= ~(0x00000001 << (index - 1));
		}
		else
		{
			AFE_LOGD("balance set para error \n");
			return;
		}

		test_afe_balance_set((stack_board_name_e)(chip_name - 1), balance_pos);
		AFE_LOGD("balance set OK, balance pos %x...\n", (uint16_t)balance_pos);
	}
	else
	{
		AFE_LOGD("balance set para error...\n");
	}
}


#ifdef APP_AFE_TEST
/**
 * @brief                进入AFE测试模式
 * @return               返回结果空
 * @warning              测试调试使用
 */
int32_t afe_test(int argc, char *argv[])
{
	AFE_LOGD("%s start\n", argv[0]); // 打印命令名称

	if (argc < 3)
	{
		AFE_LOGD("%s para error...\n", argv[0]);
		return -1;
	}
	else
	{
		if (!strcmp(argv[1], "bala")) // 均衡
		{
			bool debug_flag = atoi(argv[2]);  // 设置参数1：debug标志（1使能，0取消）
			uint8_t chip_name = atoi(argv[3]);		  // 芯片名称
            uint8_t index = atoi(argv[4]);      // 位置
            uint8_t operation = atoi(argv[5]);        // 均衡开关

			g_app_afe_bala_debug_flag = debug_flag;
			balance_test_proc(debug_flag, chip_name, index, operation); // 芯片名称 位置 均衡开关
		}
        else if (!strcmp(argv[1], "init")) // 
        {
            afe_init();            
        }
		else
		{
			AFE_LOGD("afe_test operator error...\n");
		}
	}

	return 0;
}
#endif
MSH_CMD_EXPORT(afe_test, afe debug test);
