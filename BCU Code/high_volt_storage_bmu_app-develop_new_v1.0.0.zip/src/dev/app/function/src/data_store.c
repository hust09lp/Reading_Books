/**
 * @file     data_store.c
 * @brief    数据存储处理
 * @company  sofarsolar
 * @author   刘吕从，刘炜全
 * @note     
 * @version
 * @date     2023/5/25 V1.0.1
 */
 
#include "sdk.h" 
#include <string.h>
#include <stdlib.h>
#include "data_store.h"
#include "sdk_para.h"
#include "sdk_record.h"
#include "fault_manage.h"
#include "auto_addressing.h"
#include "bms_state.h"
#include "bmu_data.h"
#include "app_config.h"
#include "sox_public.h"
#include "sop.h"
#include "public_flag.h"
#include "fault_manage.h"
#include "passive_balance.h"
#include "sofar_can_data.h"
#include "sofar_errors.h"

//Mtest
const bms_attr_t bms_attr_init = {
    .version = 0xA0000001,
	//注意：目前BMU告警阈值，BCU每次上电会下发，因为高特上位机的阈值只从外can发送，所以BCU收到需要转发给到BMU
    .safety = {  // 保护产生阈值 保护解除阈值 告警产生阈值 告警解除阈值        
#if PACK_64S_PRJ
        .cell_over_vol_protect  = { (3650+50), (3550+50), }, // 单体过压保护 单位0.001V
        .cell_over_vol_alarm   	= { (3550+50), (3450+50), }, // 单体过压报警 单位0.001V
        .cell_over_vol_tip      = { (3500+50), (3400+50), }, // 单体过压提示 单位0.001V

        .chg_under_temp_protect = { -200 , -150 ,}, // 充电温度过低保护 单位0.1℃
        .chg_under_temp_alarm  	= { 0    , 20 , }, // 充电温度过低报警 单位0.1℃
        .chg_under_temp_tip  	= { 20   , 50 , }, // 充电温度过低提示 单位0.1℃
        
        .total_under_vol_protect= { (2500+50)*CELL_VOLT_NUM, (2600+50)*CELL_VOLT_NUM,}, // 总压欠压保护 单位0.001V
        .total_under_vol_alarm 	= { (2700+50)*CELL_VOLT_NUM, (2800+50)*CELL_VOLT_NUM,}, // 总压欠压报警 单位0.001V
        .total_under_vol_tip 	= { (2800+50)*CELL_VOLT_NUM, (2900+50)*CELL_VOLT_NUM,}, // 总压欠压提示 单位0.001V
        
        .cell_volt_diff_protect = { 800,  750,  }, //单体压差过大保护 单位0.001V
#else
        .cell_over_vol_protect  = { 3650, 3550, }, // 单体过压保护 单位0.001V
        .cell_over_vol_alarm   	= { 3550, 3450, }, // 单体过压报警 单位0.001V
        .cell_over_vol_tip      = { 3500, 3400, }, // 单体过压提示 单位0.001V

        .chg_under_temp_protect = { -200 , -150 ,}, // 充电温度过低保护 单位0.1℃
        .chg_under_temp_alarm  	= { -100 , -50 , }, // 充电温度过低报警 单位0.1℃
        .chg_under_temp_tip  	= { 0 ,     50 , }, // 充电温度过低提示 单位0.1℃     
        
        .total_under_vol_protect= { 2500*CELL_VOLT_NUM, 2600*CELL_VOLT_NUM,}, // 总压欠压保护 单位0.001V
        .total_under_vol_alarm 	= { 2700*CELL_VOLT_NUM, 2800*CELL_VOLT_NUM,}, // 总压欠压报警 单位0.001V
        .total_under_vol_tip 	= { 2800*CELL_VOLT_NUM, 2900*CELL_VOLT_NUM,}, // 总压欠压提示 单位0.001V
        
        .cell_volt_diff_protect = { 1000, 950,  }, //单体压差过大保护 单位0.001V
#endif        
        
        .cell_volt_diff_alarm   = { 600,  550,  }, //单体压差过大告警 单位0.001V
        .cell_volt_diff_tip     = { 400,  350,  }, //单体压差过大提示 单位0.001V  
        
        .cell_under_vol_protect = { 2500, 2600, }, // 单体欠压保护 单位0.001V
        .cell_under_vol_alarm  	= { 2700, 2800, }, // 单体欠压报警 单位0.001V
        .cell_under_vol_tip  	= { 2800, 2900, }, // 单体欠压提示 单位0.001V

        .total_over_vol_protect = { 3650*CELL_VOLT_NUM, 3550*CELL_VOLT_NUM,}, // 总压过压保护 单位0.001V        
        .total_over_vol_alarm  	= { 3550*CELL_VOLT_NUM, 3450*CELL_VOLT_NUM,}, // 总压过压报警 单位0.001V
        .total_over_vol_tip  	= { 3500*CELL_VOLT_NUM, 3400*CELL_VOLT_NUM,}, // 总压过压提示 单位0.001V      


        .cell_temp_diff_protect = { 300,  250,  }, //单体温差过大保护 单位0.1℃
        .cell_temp_diff_alarm   = { 200,  150,  }, //单体温差过大告警 单位0.1℃
        .cell_temp_diff_tip     = { 150,  100,  }, //单体温差过大提示 单位0.1℃
        
        .chg_over_temp_protect  = { 600 , 550 , }, // 充电温度过高保护 单位0.1℃    
        .chg_over_temp_alarm   	= { 550 , 500 , }, // 充电温度过高报警 单位0.1℃
        .chg_over_temp_tip   	= { 500 , 450 , }, // 充电温度过高提示 单位0.1℃

        .dchg_over_temp_protect = { 600,  550 , }, // 放电温度过高保护 单位0.1℃        
        .dchg_over_temp_alarm  	= { 550 , 500 , }, // 放电温度过高报警 单位0.1℃
        .dchg_over_temp_tip  	= { 500 , 450 , }, // 放电温度过高提示 单位0.1℃

        .dchg_under_temp_protect= { -200 , -150 ,}, // 放电温度过低保护 单位0.1℃
        .dchg_under_temp_alarm 	= { -100 , -50 , }, // 放电温度过低报警 单位0.1℃
        .dchg_under_temp_tip 	= { 0 ,     50 , }, // 放电温度过低提示 单位0.1℃

        .soc_under_protect  	= { 5000  , 3000 , },  // SOC过低保护  分辨率0.001%
        .soc_under_alarm  		= { 10000 , 8000 , }, // SOC过低报警  分辨率0.001%
        .soc_under_tip  		= { 15000 , 13000 ,},// SOC过低提示  分辨率0.001%
        
        .cell_over_vol_seriou   = { 4000 , 3800, },     // 单体超限
        .cell_under_vol_seriou  = { 2000 , 2200, },     // 单体超低
        .ent_over_temp_alarm    = { 750  , 700,  },     // 环境温度过高报警 单位0.1℃
        .ent_under_temp_alarm   = { -200 , -150, },     // 环境温度过低报警 单位0.1℃
    },
    .bal_vol = BAL_START_VOLT,         // 均衡电压	 1mV（当前实际没有作用，后续可以改名字用来做别的作用）
    .bal_vol_diff = BAL_VOLT_DIFF,      // 压差		 1mV
    .bal_cur = BAL_CURR,          // 被动均衡电流 1mA
    .full_chg_vol = CELL_FULL_CHG_VOL,    // 单体满充电压	 1mV
    .chg_stop_vol = PACK_FULL_CHG_VOL,  // 充电停止电压  1mV
    .chg_stop_cur = DEFAULTED_RATED_CAP * 1000,  // 充电截止电流  1mA   1C

    .rate_cap = DEFAULTED_RATED_CAP*10,      // 额定容量 单位0.1Ah   
    .mono_vol_num = CELL_VOLT_NUM,    //< 单体电压个数
    .mono_tem_num = CELL_TEMP_NUM,    //< 单体温度个数
    .cell_num = CELL_VOLT_NUM,        // 电芯数量 
    .addr = BMU_ADDR_DEFAULT,        // 地址
        
    .pack_sn = {                                   // PACK条形码
                '0', '1', '2', '3', '4', '5', '6', //
                '0', '1', '2'                   },

    .board_sn = {                                   // BOARD条形码
                 '0', '1', '2', '3', '4', '5', '6', //
                 '0', '1', '2'                    },
    .app_ver =  {"V000000"},
    .check = 0,
};

const bms_runing_data_t g_bms_runing_init = 
{
    .version = 0xA0000001,
    /*SOX 相关数据*/
    .sox_running_data.cell_calc_soc[0] = 40000,
    .sox_running_data.cell_calc_soc[1] = 40000,
    .sox_running_data.cell_calc_soc[2] = 40000,
    .sox_running_data.cell_calc_soc[3] = 40000,
    .sox_running_data.cell_calc_soc[4] = 40000,
    .sox_running_data.cell_calc_soc[5] = 40000,
    .sox_running_data.cell_calc_soc[6] = 40000,
    .sox_running_data.cell_calc_soc[7] = 40000,
    .sox_running_data.cell_calc_soc[8] = 40000,
    .sox_running_data.cell_calc_soc[9] = 40000,
    .sox_running_data.cell_calc_soc[10] = 40000,
    .sox_running_data.cell_calc_soc[11] = 40000,
    .sox_running_data.cell_calc_soc[12] = 40000,
    .sox_running_data.cell_calc_soc[13] = 40000,
    .sox_running_data.cell_calc_soc[14] = 40000,
    .sox_running_data.cell_calc_soc[15] = 40000,  
    .sox_running_data.cell_calc_soc[16] = 40000,
    .sox_running_data.cell_calc_soc[17] = 40000,
    .sox_running_data.cell_calc_soc[18] = 40000,
    .sox_running_data.cell_calc_soc[19] = 40000,
    .sox_running_data.cell_calc_soc[20] = 40000,
    .sox_running_data.cell_calc_soc[21] = 40000,
    .sox_running_data.cell_calc_soc[22] = 40000,
    .sox_running_data.cell_calc_soc[23] = 40000,
    .sox_running_data.cell_calc_soc[24] = 40000,
    .sox_running_data.cell_calc_soc[25] = 40000,
    .sox_running_data.cell_calc_soc[26] = 40000,
    .sox_running_data.cell_calc_soc[27] = 40000,
    .sox_running_data.cell_calc_soc[28] = 40000,
    .sox_running_data.cell_calc_soc[29] = 40000,
    .sox_running_data.cell_calc_soc[30] = 40000,
    .sox_running_data.cell_calc_soc[31] = 40000,
    .sox_running_data.cell_calc_soc[32] = 40000,
    .sox_running_data.cell_calc_soc[33] = 40000,
    .sox_running_data.cell_calc_soc[34] = 40000,
    .sox_running_data.cell_calc_soc[35] = 40000,
    .sox_running_data.cell_calc_soc[36] = 40000,
    .sox_running_data.cell_calc_soc[37] = 40000,
    .sox_running_data.cell_calc_soc[38] = 40000,
    .sox_running_data.cell_calc_soc[39] = 40000,
    .sox_running_data.cell_calc_soc[40] = 40000,
    .sox_running_data.cell_calc_soc[41] = 40000,
    .sox_running_data.cell_calc_soc[42] = 40000,
    .sox_running_data.cell_calc_soc[43] = 40000,
    .sox_running_data.cell_calc_soc[44] = 40000,
    .sox_running_data.cell_calc_soc[45] = 40000,
    .sox_running_data.cell_calc_soc[46] = 40000,
    .sox_running_data.cell_calc_soc[47] = 40000,	
#if PACK_64S_PRJ
    .sox_running_data.cell_calc_soc[48] = 40000,
    .sox_running_data.cell_calc_soc[49] = 40000,
    .sox_running_data.cell_calc_soc[50] = 40000,
    .sox_running_data.cell_calc_soc[51] = 40000,
    .sox_running_data.cell_calc_soc[52] = 40000,
    .sox_running_data.cell_calc_soc[53] = 40000,
    .sox_running_data.cell_calc_soc[54] = 40000,
    .sox_running_data.cell_calc_soc[55] = 40000,
    .sox_running_data.cell_calc_soc[56] = 40000,
    .sox_running_data.cell_calc_soc[57] = 40000,
    .sox_running_data.cell_calc_soc[58] = 40000,
    .sox_running_data.cell_calc_soc[59] = 40000,
    .sox_running_data.cell_calc_soc[60] = 40000,
    .sox_running_data.cell_calc_soc[61] = 40000,
    .sox_running_data.cell_calc_soc[62] = 40000,
    .sox_running_data.cell_calc_soc[63] = 40000,  
#endif
    .sox_running_data.cell_calc_soh[0] = 102000,
    .sox_running_data.cell_calc_soh[1] = 102000,
    .sox_running_data.cell_calc_soh[2] = 102000,
    .sox_running_data.cell_calc_soh[3] = 102000,
    .sox_running_data.cell_calc_soh[4] = 102000,
    .sox_running_data.cell_calc_soh[5] = 102000,
    .sox_running_data.cell_calc_soh[6] = 102000,
    .sox_running_data.cell_calc_soh[7] = 102000,
    .sox_running_data.cell_calc_soh[8] = 102000,
    .sox_running_data.cell_calc_soh[9] = 102000,
    .sox_running_data.cell_calc_soh[10] = 102000,
    .sox_running_data.cell_calc_soh[11] = 102000,
    .sox_running_data.cell_calc_soh[12] = 102000,
    .sox_running_data.cell_calc_soh[13] = 102000,
    .sox_running_data.cell_calc_soh[14] = 102000,
    .sox_running_data.cell_calc_soh[15] = 102000,   
    .sox_running_data.cell_calc_soh[16] = 102000,
    .sox_running_data.cell_calc_soh[17] = 102000,
    .sox_running_data.cell_calc_soh[18] = 102000,
    .sox_running_data.cell_calc_soh[19] = 102000,
    .sox_running_data.cell_calc_soh[20] = 102000,
    .sox_running_data.cell_calc_soh[21] = 102000,
    .sox_running_data.cell_calc_soh[22] = 102000,
    .sox_running_data.cell_calc_soh[23] = 102000,
    .sox_running_data.cell_calc_soh[24] = 102000,
    .sox_running_data.cell_calc_soh[25] = 102000,
    .sox_running_data.cell_calc_soh[26] = 102000,
    .sox_running_data.cell_calc_soh[27] = 102000,
    .sox_running_data.cell_calc_soh[28] = 102000,
    .sox_running_data.cell_calc_soh[29] = 102000,
    .sox_running_data.cell_calc_soh[30] = 102000,
    .sox_running_data.cell_calc_soh[31] = 102000,
    .sox_running_data.cell_calc_soh[32] = 102000,
    .sox_running_data.cell_calc_soh[33] = 102000,
    .sox_running_data.cell_calc_soh[34] = 102000,
    .sox_running_data.cell_calc_soh[35] = 102000,
    .sox_running_data.cell_calc_soh[36] = 102000,
    .sox_running_data.cell_calc_soh[37] = 102000,
    .sox_running_data.cell_calc_soh[38] = 102000,
    .sox_running_data.cell_calc_soh[39] = 102000,
    .sox_running_data.cell_calc_soh[40] = 102000,
    .sox_running_data.cell_calc_soh[41] = 102000,
    .sox_running_data.cell_calc_soh[42] = 102000,
    .sox_running_data.cell_calc_soh[43] = 102000,
    .sox_running_data.cell_calc_soh[44] = 102000,
    .sox_running_data.cell_calc_soh[45] = 102000,
    .sox_running_data.cell_calc_soh[46] = 102000,
    .sox_running_data.cell_calc_soh[47] = 102000,
#if PACK_64S_PRJ
    .sox_running_data.cell_calc_soh[48] = 102000,
    .sox_running_data.cell_calc_soh[49] = 102000,
    .sox_running_data.cell_calc_soh[50] = 102000,
    .sox_running_data.cell_calc_soh[51] = 102000,
    .sox_running_data.cell_calc_soh[52] = 102000,
    .sox_running_data.cell_calc_soh[53] = 102000,
    .sox_running_data.cell_calc_soh[54] = 102000,
    .sox_running_data.cell_calc_soh[55] = 102000,
    .sox_running_data.cell_calc_soh[56] = 102000,
    .sox_running_data.cell_calc_soh[57] = 102000,
    .sox_running_data.cell_calc_soh[58] = 102000,
    .sox_running_data.cell_calc_soh[59] = 102000,
    .sox_running_data.cell_calc_soh[60] = 102000,
    .sox_running_data.cell_calc_soh[61] = 102000,
    .sox_running_data.cell_calc_soh[62] = 102000,
    .sox_running_data.cell_calc_soh[63] = 102000,  
    
#endif
    .sox_running_data.soh_high_pre[0] = 100000,
    .sox_running_data.soh_high_pre[1] = 100000,
    .sox_running_data.soh_high_pre[2] = 100000,
    .sox_running_data.soh_high_pre[3] = 100000,
    .sox_running_data.soh_high_pre[4] = 100000,
    .sox_running_data.soh_high_pre[5] = 100000,
    .sox_running_data.soh_high_pre[6] = 100000,
    .sox_running_data.soh_high_pre[7] = 100000,
    .sox_running_data.soh_high_pre[8] = 100000,
    .sox_running_data.soh_high_pre[9] = 100000,
    .sox_running_data.soh_high_pre[10] = 100000,
    .sox_running_data.soh_high_pre[11] = 100000,
    .sox_running_data.soh_high_pre[12] = 100000,
    .sox_running_data.soh_high_pre[13] = 100000,
    .sox_running_data.soh_high_pre[14] = 100000,
    .sox_running_data.soh_high_pre[15] = 100000,  
    .sox_running_data.soh_high_pre[16] = 100000,
    .sox_running_data.soh_high_pre[17] = 100000,
    .sox_running_data.soh_high_pre[18] = 100000,
    .sox_running_data.soh_high_pre[19] = 100000,
    .sox_running_data.soh_high_pre[20] = 100000,
    .sox_running_data.soh_high_pre[21] = 100000,
    .sox_running_data.soh_high_pre[22] = 100000,
    .sox_running_data.soh_high_pre[23] = 100000,
    .sox_running_data.soh_high_pre[24] = 100000,
    .sox_running_data.soh_high_pre[25] = 100000,
    .sox_running_data.soh_high_pre[26] = 100000,
    .sox_running_data.soh_high_pre[27] = 100000,
    .sox_running_data.soh_high_pre[28] = 100000,
    .sox_running_data.soh_high_pre[29] = 100000,
    .sox_running_data.soh_high_pre[30] = 100000,
    .sox_running_data.soh_high_pre[31] = 100000,
    .sox_running_data.soh_high_pre[32] = 100000,
    .sox_running_data.soh_high_pre[33] = 100000,
    .sox_running_data.soh_high_pre[34] = 100000,
    .sox_running_data.soh_high_pre[35] = 100000,
    .sox_running_data.soh_high_pre[36] = 100000,
    .sox_running_data.soh_high_pre[37] = 100000,
    .sox_running_data.soh_high_pre[38] = 100000,
    .sox_running_data.soh_high_pre[39] = 100000,
    .sox_running_data.soh_high_pre[40] = 100000,
    .sox_running_data.soh_high_pre[41] = 100000,
    .sox_running_data.soh_high_pre[42] = 100000,
    .sox_running_data.soh_high_pre[43] = 100000,
    .sox_running_data.soh_high_pre[44] = 100000,
    .sox_running_data.soh_high_pre[45] = 100000,
    .sox_running_data.soh_high_pre[46] = 100000,
    .sox_running_data.soh_high_pre[47] = 100000,	
#if PACK_64S_PRJ
    .sox_running_data.soh_high_pre[48] = 100000,
    .sox_running_data.soh_high_pre[49] = 100000,
    .sox_running_data.soh_high_pre[50] = 100000,
    .sox_running_data.soh_high_pre[51] = 100000,
    .sox_running_data.soh_high_pre[52] = 100000,
    .sox_running_data.soh_high_pre[53] = 100000,
    .sox_running_data.soh_high_pre[54] = 100000,
    .sox_running_data.soh_high_pre[55] = 100000,
    .sox_running_data.soh_high_pre[56] = 100000,
    .sox_running_data.soh_high_pre[57] = 100000,
    .sox_running_data.soh_high_pre[58] = 100000,
    .sox_running_data.soh_high_pre[59] = 100000,
    .sox_running_data.soh_high_pre[60] = 100000,
    .sox_running_data.soh_high_pre[61] = 100000,
    .sox_running_data.soh_high_pre[62] = 100000,
    .sox_running_data.soh_high_pre[63] = 100000,  
#endif

    .sox_running_data.cycle_count[0] = 0,
    .sox_running_data.cycle_count[1] = 0,
    .sox_running_data.cycle_count[2] = 0,
    .sox_running_data.cycle_count[3] = 0,
    .sox_running_data.cycle_count[4] = 0,
    .sox_running_data.cycle_count[5] = 0,
    .sox_running_data.cycle_count[6] = 0,
    .sox_running_data.cycle_count[7] = 0,
    .sox_running_data.cycle_count[8] = 0,
    .sox_running_data.cycle_count[9] = 0,
    .sox_running_data.cycle_count[10] = 0,
    .sox_running_data.cycle_count[11] = 0,
    .sox_running_data.cycle_count[12] = 0,
    .sox_running_data.cycle_count[13] = 0,
    .sox_running_data.cycle_count[14] = 0,
    .sox_running_data.cycle_count[15] = 0,
    .sox_running_data.cycle_count[16] = 0,
    .sox_running_data.cycle_count[17] = 0,
    .sox_running_data.cycle_count[18] = 0,
    .sox_running_data.cycle_count[19] = 0,
    .sox_running_data.cycle_count[20] = 0,
    .sox_running_data.cycle_count[21] = 0,
    .sox_running_data.cycle_count[22] = 0,
    .sox_running_data.cycle_count[23] = 0,
    .sox_running_data.cycle_count[24] = 0,
    .sox_running_data.cycle_count[25] = 0,
    .sox_running_data.cycle_count[26] = 0,
    .sox_running_data.cycle_count[27] = 0,
    .sox_running_data.cycle_count[28] = 0,
    .sox_running_data.cycle_count[29] = 0,
    .sox_running_data.cycle_count[30] = 0,
    .sox_running_data.cycle_count[31] = 0,
    .sox_running_data.cycle_count[32] = 0,
    .sox_running_data.cycle_count[33] = 0,
    .sox_running_data.cycle_count[34] = 0,
    .sox_running_data.cycle_count[35] = 0,
    .sox_running_data.cycle_count[36] = 0,
    .sox_running_data.cycle_count[37] = 0,
    .sox_running_data.cycle_count[38] = 0,
    .sox_running_data.cycle_count[39] = 0,
    .sox_running_data.cycle_count[40] = 0,
    .sox_running_data.cycle_count[41] = 0,
    .sox_running_data.cycle_count[42] = 0,
    .sox_running_data.cycle_count[43] = 0,
    .sox_running_data.cycle_count[44] = 0,
    .sox_running_data.cycle_count[45] = 0,
    .sox_running_data.cycle_count[46] = 0,
    .sox_running_data.cycle_count[47] = 0,	
#if PACK_64S_PRJ
    .sox_running_data.cycle_count[48] = 0,
    .sox_running_data.cycle_count[49] = 0,
    .sox_running_data.cycle_count[50] = 0,
    .sox_running_data.cycle_count[51] = 0,
    .sox_running_data.cycle_count[52] = 0,
    .sox_running_data.cycle_count[53] = 0,
    .sox_running_data.cycle_count[54] = 0,
    .sox_running_data.cycle_count[55] = 0,
    .sox_running_data.cycle_count[56] = 0,
    .sox_running_data.cycle_count[57] = 0,
    .sox_running_data.cycle_count[58] = 0,
    .sox_running_data.cycle_count[59] = 0,
    .sox_running_data.cycle_count[60] = 0,
    .sox_running_data.cycle_count[61] = 0,
    .sox_running_data.cycle_count[62] = 0,
    .sox_running_data.cycle_count[63] = 0,
#endif

    .sox_running_data.cycle_frac[0] = 0,
    .sox_running_data.cycle_frac[1] = 0,
    .sox_running_data.cycle_frac[2] = 0,
    .sox_running_data.cycle_frac[3] = 0,
    .sox_running_data.cycle_frac[4] = 0,
    .sox_running_data.cycle_frac[5] = 0,
    .sox_running_data.cycle_frac[6] = 0,
    .sox_running_data.cycle_frac[7] = 0,
    .sox_running_data.cycle_frac[8] = 0,
    .sox_running_data.cycle_frac[9] = 0,
    .sox_running_data.cycle_frac[10] = 0,
    .sox_running_data.cycle_frac[11] = 0,
    .sox_running_data.cycle_frac[12] = 0,
    .sox_running_data.cycle_frac[13] = 0,
    .sox_running_data.cycle_frac[14] = 0,
    .sox_running_data.cycle_frac[15] = 0,
    .sox_running_data.cycle_frac[16] = 0,
    .sox_running_data.cycle_frac[17] = 0,
    .sox_running_data.cycle_frac[18] = 0,
    .sox_running_data.cycle_frac[19] = 0,
    .sox_running_data.cycle_frac[20] = 0,
    .sox_running_data.cycle_frac[21] = 0,
    .sox_running_data.cycle_frac[22] = 0,
    .sox_running_data.cycle_frac[23] = 0,
    .sox_running_data.cycle_frac[24] = 0,
    .sox_running_data.cycle_frac[25] = 0,
    .sox_running_data.cycle_frac[26] = 0,
    .sox_running_data.cycle_frac[27] = 0,
    .sox_running_data.cycle_frac[28] = 0,
    .sox_running_data.cycle_frac[29] = 0,
    .sox_running_data.cycle_frac[30] = 0,
    .sox_running_data.cycle_frac[31] = 0,
    .sox_running_data.cycle_frac[32] = 0,
    .sox_running_data.cycle_frac[33] = 0,
    .sox_running_data.cycle_frac[34] = 0,
    .sox_running_data.cycle_frac[35] = 0,
    .sox_running_data.cycle_frac[36] = 0,
    .sox_running_data.cycle_frac[37] = 0,
    .sox_running_data.cycle_frac[38] = 0,
    .sox_running_data.cycle_frac[39] = 0,
    .sox_running_data.cycle_frac[40] = 0,
    .sox_running_data.cycle_frac[41] = 0,
    .sox_running_data.cycle_frac[42] = 0,
    .sox_running_data.cycle_frac[43] = 0,
    .sox_running_data.cycle_frac[44] = 0,
    .sox_running_data.cycle_frac[45] = 0,
    .sox_running_data.cycle_frac[46] = 0,
    .sox_running_data.cycle_frac[47] = 0,	
    #if PACK_64S_PRJ
    .sox_running_data.cycle_frac[48] = 0,
    .sox_running_data.cycle_frac[49] = 0,
    .sox_running_data.cycle_frac[50] = 0,
    .sox_running_data.cycle_frac[51] = 0,
    .sox_running_data.cycle_frac[52] = 0,
    .sox_running_data.cycle_frac[53] = 0,
    .sox_running_data.cycle_frac[54] = 0,
    .sox_running_data.cycle_frac[55] = 0,
    .sox_running_data.cycle_frac[56] = 0,
    .sox_running_data.cycle_frac[57] = 0,
    .sox_running_data.cycle_frac[58] = 0,
    .sox_running_data.cycle_frac[59] = 0,
    .sox_running_data.cycle_frac[60] = 0,
    .sox_running_data.cycle_frac[61] = 0,
    .sox_running_data.cycle_frac[62] = 0,
    .sox_running_data.cycle_frac[63] = 0,
    #endif

    .sox_running_data.display_cycle_turns = 0,
    .sox_running_data.pack_calc_soc = 40000,
    .sox_running_data.remain_cap = DEFAULTED_RATED_CAP*10/25,   //40%容量
    .sox_running_data.real_cap = DEFAULTED_RATED_CAP,
    .sox_running_data.total_chg_mA_s = 0,       //目前两个mAs和两个mWs决定ah和wh；并且循环圈数也是由累计充电量决定
    .sox_running_data.total_chg_mW_s = 0,
    .sox_running_data.total_chg_ah = 0,
    .sox_running_data.total_chg_wh = 0,
    .sox_running_data.total_dsg_mA_s = 0,
    .sox_running_data.total_dsg_mW_s = 0,
    .sox_running_data.total_dsg_ah = 0,
    .sox_running_data.total_dsg_wh = 0,
};



// 该表中故障类型的顺序需要与联合体 fault_cnt_stu_u 中 bit 位的顺序保持一致，修改时需要同步修改
// 另外该表中故障的数量不能超过 fault_cnt_stu_u 中定义的 bit 的位数，当前是32位
static fault_cnt_map_t g_fault_map[FAULT_CNT_MAX_NUMS]=
{
    {CELL_VOLT_OVER_PROTECT_CNT,        BAT_CELL_VOLT_HIGH_PROTECT},
    {TOTAL_VOLT_OVER_PROTECT_CNT,       BAT_TOTAL_VOLT_HIGH_PROTECT},
    {CELL_VOLT_LOW_PROTECT_CNT,         BAT_CELL_VOLT_LOW_PROTECT},
    {TOTAL_VOLT_LOW_PROTECT_CNT,        BAT_TOTAL_VOLT_LOW_PROTECT},
    {CELL_VOLT_DIFF_OVER_PROTECT_CNT,   BAT_CELL_VOLT_DIFF_OVER_PROTECT},
    {CELL_LIMIT_FAULT_CNT,              BAT_CELL_LIMIT_FAULT},
    {PACK_VOLT_DIFF_OVER_FAULT_CNT,     BAT_TOTAL_VOLT_DIFF_OVER_FAULT},
    {CHG_TEMP_OVER_PROTECT_CNT,         BAT_CELL_CHG_TEMP_OVER_PROTECT},
    {CHG_TEMP_LOW_PROTECT_CNT,          BAT_CELL_DISCHG_TEMP_OVER_PROTECT},
    {DSG_TEMP_OVER_PROTECT_CNT,         BAT_CELL_CHG_TEMP_LOW_PROTECT},
    {DSG_TEMP_LOW_PROTECT_CNT,          BAT_CELL_DISCHG_TEMP_LOW_PROTECT},
    {CELL_TEMP_DIFF_OVER_PROTECT_CNT,   BAT_CELL_TEMP_DIFF_OVER_PROTECT},
    {CELL_TEMP_RISE_OVER_FAULT_CNT,     BAT_CELL_TEMP_RISE_OVER_FAULT},
    {VOLT_24V_ABNORMAL_FAULT_CNT,       BOARD_24V_ABNORMAL_FAULT},
    {FLASH_INVALID_FAULT_CNT,           BOARD_FLASH_INVALID_FAULT},
    {AFE_ABNORMAL_FAULT_CNT,            BOARD_AFE_ABNORMAL_FAULT},
    {CELL_VOLT_SAM_FAULT_CNT,           BOARD_CELL_VOLT_WIRE_ABNORMAL_FAULT},
    {CELL_TEMP_SAM_FAULT_CNT,           BOARD_CELL_TEMP_SAM_FAULT},
    {POWER_TERMINAL_TEMP_SAM_FAULT_CNT, BOARD_POWER_TERMINAL_TEMP_SAM_FAULT},
    {TERMINAL_TEMP_OVER_PROTECT_CNT,    BOARD_POWER_TERMINAL_TEMP_OVER_PROTECT},
};

static bms_attr_t g_bms_attr = {0};
static data_store_flag_t  g_data_store_flag = {0};
static bms_runing_data_t g_bms_runing_data = {0};
static fault_record_buff_info_t g_fault_record_buff_info = {0};
// static uint8_t sleep_lock_id = 0;

const fault_record_buff_info_t *get_fault_record_buff(void)
{
    return &g_fault_record_buff_info;
}

const bms_attr_t *get_bms_attr(void)
{
    return &g_bms_attr;
}

const bms_runing_data_t *get_bms_runing_data(void)
{
    return &g_bms_runing_data;
}

static uint16_t check_crc(uint8_t *pData, uint32_t plen) {
    uint16_t siRet  = 0;
    uint16_t u16CRC = 0xFFFF;
    for (int i = 0; i < plen; i++) {
        u16CRC ^= (uint16_t)(pData[i]);
        for (int j = 0; j <= 7; j++) {
            if (u16CRC & 0x0001) {
                u16CRC = (u16CRC >> 1) ^ 0xA001;
            } else {
                u16CRC = u16CRC >> 1;
            }
        }
    }
    siRet = (u16CRC & 0x00FF) << 8;
    siRet |= u16CRC >> 8;
    return siRet;
}


int32_t data_store_fault_get(data_store_fault_e fault_type)
{
    int32_t res = 0;
    switch (fault_type)
    {
    case DATA_STORE_BMS_ATTR:
        res = g_data_store_flag.para_err;
        break;
    case DATA_STOR_RUNNING_DATA:
        res = g_data_store_flag.runing_data_err;
        break;
    case DATA_STORE_RECORD:
        res = g_data_store_flag.record_err;
        break;
    case DATA_STORE_FAULT_RECORD:
        res = g_data_store_flag.fault_record_err;
        break;              
    default:
        break;
    }
    return res;
}


int32_t data_store_toatal_fault_get(void)
{
    for(uint8_t i = DATA_STORE_BMS_ATTR; i < DATA_STORE_FAULT_NUM; i++)
    {
        if(INVRLID == data_store_fault_get((data_store_fault_e)i))
        {
            return i;
        }
    }

    return -1;
}


static void data_store_fault_set(data_store_fault_e fault_type, uint8_t value)
{
    switch (fault_type)
    {
    case DATA_STORE_BMS_ATTR:
        g_data_store_flag.para_err = value;
        break;
    case DATA_STOR_RUNNING_DATA:
        g_data_store_flag.runing_data_err = value;
        break;
    case DATA_STORE_RECORD:
        g_data_store_flag.record_err = value;
        break;
    case DATA_STORE_FAULT_RECORD:
        g_data_store_flag.fault_record_err = value;
        break;
    default:
        break;
    }
}

/**
 * @brief 属性表初始化
 *
 */
static void attr_data_init(void)
{
    uint32_t check_crc_result;

    /* --------------------------------------------------------------------------------------------------*/
    // bms属性表
    /* --------------------------------------------------------------------------------------------------*/
    g_data_store_flag.bms_attr_file_open = sdk_para_init(BMS_ATTR_TAB, sizeof(bms_attr_t));
	
    if (g_data_store_flag.bms_attr_file_open == 0)
    {
        sdk_para_read(BMS_ATTR_TAB, 0, (uint8_t *)&g_bms_attr, sizeof(bms_attr_t)); // 获取属性表
        // 校验g_bms_attr的数据是否可用,否则赋默认值
        check_crc_result = (uint32_t)check_crc((uint8_t *)&g_bms_attr, sizeof(bms_attr_t) - 4);
        if ((g_bms_attr.version != bms_attr_init.version) // 属性表版本号不对, 首次初始化
            || (g_bms_attr.check != check_crc_result))
        {
            log_i("[store]nowVer!=InitVer %x %x\n\r", g_bms_attr.version, bms_attr_init.version);

            g_bms_attr = bms_attr_init;
            g_bms_attr.check = (uint32_t)check_crc((uint8_t *)&g_bms_attr, sizeof(bms_attr_t) - 4);

            sdk_para_write(BMS_ATTR_TAB, 0, (uint8_t *)&g_bms_attr, sizeof(bms_attr_t));
            sdk_para_sync(BMS_ATTR_TAB);
        }
        else
        {
            log_i("[store]AttrDataInitSucc\n\r");
        }
    }
    else
    {
        data_store_fault_set(DATA_STORE_BMS_ATTR, INVRLID);
    }

}


/**
 * @brief 运行数据初始化
 *
 */
static void running_data_init(void)
{
    uint32_t check_crc_result;
    sdk_rtc_t rtc_time = {0};

    /* --------------------------------------------------------------------------------------------------*/
    // 打开运行数据保存文件
    /* --------------------------------------------------------------------------------------------------*/
    g_data_store_flag.runing_data_file_open = sdk_para_init(BMS_RUNING_DATA, sizeof(bms_runing_data_t));
    if (g_data_store_flag.runing_data_file_open == 0)
    {
        sdk_para_read(BMS_RUNING_DATA, 0, (uint8_t *)&g_bms_runing_data, sizeof(bms_runing_data_t));
        check_crc_result = (uint32_t)check_crc((uint8_t *)&g_bms_runing_data, sizeof(bms_runing_data_t) - 4);
        if (check_crc_result != g_bms_runing_data.check || g_bms_runing_data.version != g_bms_runing_init.version)
        {
            memcpy(&g_bms_runing_data, &g_bms_runing_init, sizeof(bms_runing_data_t));
            g_bms_runing_data.check = (uint32_t)check_crc((uint8_t *)&g_bms_runing_data, sizeof(bms_runing_data_t) - 4);
            sdk_para_write(BMS_RUNING_DATA, 0, (uint8_t *)&g_bms_runing_data, sizeof(bms_runing_data_t));
            sdk_para_sync(BMS_RUNING_DATA);    
            log_i("[store]RunDataInit,store crc:%d,calc crc:%d,store ver:%d,init ver:%d\n\r",g_bms_runing_data.check,check_crc_result,g_bms_runing_data.version,g_bms_runing_init.version);
        }
        else
        {
            rtc_time.tm_year = g_bms_runing_data.rtc_data[0];
            rtc_time.tm_mon = g_bms_runing_data.rtc_data[1];  
            rtc_time.tm_day = g_bms_runing_data.rtc_data[2];
            rtc_time.tm_hour = g_bms_runing_data.rtc_data[3];         
            rtc_time.tm_min = g_bms_runing_data.rtc_data[4];
            rtc_time.tm_sec = g_bms_runing_data.rtc_data[5];                       
            sdk_rtc_set(RTC_BIN_FORMAT, &rtc_time);
            log_i("[store]RunDataCrcSuc\n\r");

        }

#if THIS_FILE_DEBUG
		// 打印: 掉电保存的运行数据
        log_d("read renew_cap_flag %d !! \n\r", g_bms_runing_data.renew_cap_flag);
#endif
    }
    else
    {
        data_store_fault_set(DATA_STOR_RUNNING_DATA, INVRLID);
    }
}


/**
 * @brief 日志初始化
 *
 */
static void record_data_init(void)
{
    g_data_store_flag.record_file_open = sdk_record_init(NORMAL_RECORD, sizeof(bms_record_data_t), RECORD_RUNING_DOG_DEPTH);
    if (g_data_store_flag.record_file_open != 0)
    {
        data_store_fault_set(DATA_STORE_RECORD, INVRLID);
        log_w("[store]RecordDataInitFail\n");
    }
}



/**
 * @brief
 *
 */
void data_store_init(void)
{
    // sleep_lock_id = sdk_pm_get_lock_id();
    // sdk_pm_lock(sleep_lock_id);

    attr_data_init();

    running_data_init();

    record_data_init();      

    // sdk_pm_unlock(sleep_lock_id);
}



/**
 * @brief 保存BMS属性表中某个元素
 * @param offset 偏移量
 * @param data 数据内容
 * @param len 数据长度
 * @return int32_t
 * @retval 0 成功
 * @retval -1 失败
 */
int32_t data_store_save_bms_attr(uint32_t offset, uint8_t *data, uint32_t len)
{
    if (memcmp((uint8_t *)&g_bms_attr + offset, data, len) != 0) // 如果数据相同，则不用保存
    {
        g_data_store_flag.bms_attr_save_flag = 1;
        // sdk_pm_lock(sleep_lock_id);
        memcpy((uint8_t *)&g_bms_attr + offset, data, len);
    }
    return 0;
}


/**
 * @brief
 * @return 无
 */
int32_t data_store_save_adjust_para(adjust_para_tab_t *adjust_para_tab)
{
    if (memcmp(&g_bms_attr.adjust, adjust_para_tab, sizeof(adjust_para_tab_t)) != 0) // 如果数据相同，则不用保存
    {
        g_data_store_flag.bms_attr_save_flag = 1;
        // sdk_pm_lock(sleep_lock_id);
        memcpy(&g_bms_attr.adjust, adjust_para_tab, sizeof(adjust_para_tab_t));
    }
    return 0;
}

/**
 * @brief 保存BMSrunningdata中某个元素
 * @param flag: ture为存储；false为只赋值
 * @return int32_t
 * @retval 0 成功
 * @retval -1 失败
 */
int32_t bms_runing_data_deal(bms_runing_data_t bms_runing_data, uint8_t flag)
{
    if (memcmp(&g_bms_runing_data, &bms_runing_data, sizeof(bms_runing_data_t)) != 0) // 如果数据相同，则不用保存
    {
        if(true == flag)
        {
            g_data_store_flag.bms_runing_data_save_flag = 1;            
        }

        // sdk_pm_lock(sleep_lock_id);
        g_bms_runing_data = bms_runing_data;
    }

    return 0;
}

/**
 * @brief 保存BMSsox_runningdata中某个元素
 * @return int32_t
 * @retval 0 成功
 * @retval -1 失败
 */
int32_t bms_sox_runing_data_save(sox_running_data_t sox_running_data)
{
    sdk_rtc_t rtc_time = {0};
    sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
    g_bms_runing_data.rtc_data[0] = rtc_time.tm_year;
    g_bms_runing_data.rtc_data[1] = rtc_time.tm_mon;
    g_bms_runing_data.rtc_data[2] = rtc_time.tm_day;
    g_bms_runing_data.rtc_data[3] = rtc_time.tm_hour;
    g_bms_runing_data.rtc_data[4] = rtc_time.tm_min;
    g_bms_runing_data.rtc_data[5] = rtc_time.tm_sec;


    if (memcmp(&g_bms_runing_data.sox_running_data, &sox_running_data, sizeof(sox_running_data_t)) != 0) // 如果数据相同，则不用保存
    {
        g_data_store_flag.bms_runing_data_save_flag = 1;
        // sdk_pm_lock(sleep_lock_id);
        g_bms_runing_data.sox_running_data = sox_running_data;
    }

    return 0;
}


/**
 * @brief 属性保存函数
 *
 */
static void bms_attr_data_save(void)
{
    bms_attr_t tmp_bms_attr,tmp_bms_attr2;
    /* --------------------------------------------------------------------------------------- */
    // 执行保存BMS属性
    /* --------------------------------------------------------------------------------------- */
    if (g_data_store_flag.bms_attr_save_flag)
    {

        if (g_data_store_flag.bms_attr_file_open == 0)
        {

            // 写入数据完整性信息
            g_bms_attr.check = (uint32_t)check_crc((uint8_t *)&g_bms_attr, sizeof(bms_attr_t) - 4);
            memcpy(&tmp_bms_attr2, &g_bms_attr, sizeof(bms_attr_t));    //防止g_bms_attr在存储过程中被篡改导致存储的数据和crc对应不上
            sdk_para_write(BMS_ATTR_TAB, 0, (uint8_t *)&tmp_bms_attr2, sizeof(bms_attr_t));
            sdk_para_sync(BMS_ATTR_TAB);
            sdk_para_read(BMS_ATTR_TAB, 0, (uint8_t *)&tmp_bms_attr, sizeof(bms_attr_t));
            if (memcmp(&tmp_bms_attr2, &tmp_bms_attr, sizeof(bms_attr_t)) == 0)
            {
                g_data_store_flag.bms_attr_save_flag = 0;
                g_data_store_flag.bms_attr_file_err_cnt = 0;
            }
            else
            {
                if (++g_data_store_flag.bms_attr_file_err_cnt >= 3) // 保存3次不成功，则报错
                {
                    g_data_store_flag.bms_attr_file_err_cnt = 3;
                    g_data_store_flag.bms_attr_save_flag = 0;
                    data_store_fault_set(DATA_STORE_BMS_ATTR, INVRLID);
                }
            }
        }
        else
        {
            g_data_store_flag.bms_attr_save_flag = 0;   //防止文件打开失败后，无法进入休眠             
        }
    }

}

/**
 * @brief 保护越限次数保存
 *
 */
void bms_protect_cnt_save(void)
{
    static fault_cnt_stu_u last_fault_stu = {0};
    static fault_cnt_stu_u current_fault_stu = {0};
	fault_type_e temp_map;

    for(uint8_t i = 0; i < FAULT_CNT_MAX_NUMS; i++)
    {
		temp_map = g_fault_map[i].fault_cnt_map;
        if(fault_state_get(temp_map) < FAULT_STOP)
        {
            continue;
        }
        else if(fault_state_get(temp_map) == FAULT_START)
        {
			current_fault_stu.stu_val |= 1 << i;
            if((last_fault_stu.stu_val & (1 << i)) != (current_fault_stu.stu_val & (1 << i)))
            {
                g_bms_runing_data.fault_cnt[i]++;
                last_fault_stu.stu_val |= 1 << i;
            }
        }
        else
        {
			current_fault_stu.stu_val &= ~(1 << i);
            if((last_fault_stu.stu_val & (1 << i)) != (current_fault_stu.stu_val & (1 << i)))
            {
                last_fault_stu.stu_val &= ~(1 << i);
            }
        }
    }
}

/**
 * @brief 保护越限次数清除
 *
 */
void bms_protect_cnt_clear(void)
{
    for(uint8_t i = 0; i < FAULT_CNT_MAX_NUMS; i++)
    {
        g_bms_runing_data.fault_cnt[i] = 0;
    }

    return;
}

/**
 * @brief 运行数据保存函数
 *
 */
static void bms_running_data_save(void)
{
    bms_runing_data_t tmp_bms_runing_data,tmp_bms_runing_data2;    
    
	bms_protect_cnt_save();
    /* --------------------------------------------------------------------------------------- */
    // 执行保存运行数
    /* --------------------------------------------------------------------------------------- */
    if (g_data_store_flag.bms_runing_data_save_flag)
    {

        if (g_data_store_flag.runing_data_file_open == 0)
        {
            // 写入数据完整性信息
            g_bms_runing_data.check = (uint32_t)check_crc((uint8_t *)&g_bms_runing_data, sizeof(bms_runing_data_t) - 4);

    #if THIS_FILE_DEBUG
            log_d("save soc %d !! \n\r", g_bms_runing_data.soc);
    #endif

            // 保存数据到flash
            memcpy(&tmp_bms_runing_data2, &g_bms_runing_data, sizeof(bms_runing_data_t));   //防止g_bms_runing_data在存储过程中被篡改导致存储的数据和crc对应不上
            sdk_para_write(BMS_RUNING_DATA, 0, (uint8_t *)&tmp_bms_runing_data2, sizeof(bms_runing_data_t));
            sdk_para_sync(BMS_RUNING_DATA);
            sdk_para_read(BMS_RUNING_DATA, 0, (uint8_t *)&tmp_bms_runing_data, sizeof(bms_runing_data_t));
            if (memcmp(&tmp_bms_runing_data2, &tmp_bms_runing_data, sizeof(bms_runing_data_t)) == 0)
            {
                g_data_store_flag.bms_runing_data_save_flag = 0;
                g_data_store_flag.runing_data_file_err_cnt = 0;
            }
            else
            {
                if (++g_data_store_flag.runing_data_file_err_cnt >= 3) // 保存3次不成功，则报错
                {
                    g_data_store_flag.runing_data_file_err_cnt = 3;
                    g_data_store_flag.bms_runing_data_save_flag = 0;
                    data_store_fault_set(DATA_STOR_RUNNING_DATA, INVRLID);
                }
            }
        }
        else
        {
            g_data_store_flag.bms_runing_data_save_flag = 0;   //防止文件打开失败后，无法进入休眠             
        }

    }

}

//填充需要记录的数据
static bms_record_data_t record_data_fill(void)
{
    bms_record_data_t  record_data = {0};
    sdk_rtc_t rtc_time = {0};
    uint8_t i = 0;
    power_limit_t sop_limit_data = {0};
    const sox_data_t* sox_data = sox_data_get_deal();
    const bmu_data_t* p_bmu_data = bmu_data_p_get();

    if (NULL != sox_data)
    {
        record_data.soc = sox_data->display_soc;
        record_data.soh = sox_data->display_soh;
        record_data.soc_cal = sox_data->calc_soc;
        record_data.soh_cal = sox_data->calc_soh;
        record_data.dsg_ah = sox_data->total_dsg_ah;
        record_data.chrg_ah = sox_data->total_chg_ah;
        record_data.dsg_wh = sox_data->total_dsg_wh;
        record_data.chrg_wh = sox_data->total_chg_wh;        
    }

       
    sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
    record_data.year_month = (((uint16_t)rtc_time.tm_mon)<<8)+rtc_time.tm_year;
    record_data.day_hour = (((uint16_t)rtc_time.tm_hour)<<8)+rtc_time.tm_day;     
    record_data.min_sec = (((uint16_t)rtc_time.tm_sec)<<8)+rtc_time.tm_min; 

    if (NULL != p_bmu_data)
    {
        record_data.bat_afe_volt = p_bmu_data->bat_afe_volt / 100;
        record_data.bat_acc_volt = p_bmu_data->bat_acc_volt / 100;
        record_data.current = p_bmu_data->sys_current / 10;
        record_data.max_volt = (uint16_t)p_bmu_data->max_cell_volt;
        record_data.min_volt = (uint16_t)p_bmu_data->min_cell_volt;
        record_data.max_volt_no = p_bmu_data->max_volt_num;
        record_data.min_volt_no = p_bmu_data->min_volt_num;    
        record_data.max_temp = p_bmu_data->max_cell_temp / 10;
        record_data.min_temp = p_bmu_data->min_cell_temp / 10;
        record_data.max_temp_no = p_bmu_data->max_temp_num;
        record_data.min_temp_no = p_bmu_data->min_temp_num; 
        record_data.supply_volt = p_bmu_data->check_24v_volt; 
        for(i = 0;i < OTHER_NTC_NUM;i++)
        {
            record_data.other_temp[i] = p_bmu_data->adc_sample_other_temp[i] / 10;
        }    
        for(i = 0;i < CELL_VOLT_NUM;i++)
        {
            record_data.cell_volt[i] = p_bmu_data->cell_volt[i];
        }
        for(i = 0;i < CELL_TEMP_NUM;i++)
        {
            record_data.cell_temp[i] = p_bmu_data->cell_temp[i] / 10 ;
        }
    }
   
	record_data.fault_msg[0] = get_fault_info()->fault_info1.byte0.byte;    //只存BMU有的故障告警
    record_data.fault_msg[1] = get_fault_info()->fault_info1.byte1.byte;
    record_data.fault_msg[2] = get_fault_info()->fault_info1.byte2.byte; 
	record_data.fault_msg[3] = get_fault_info()->fault_info1.byte3.byte; 
    record_data.fault_msg[4] = get_fault_info()->fault_info1.byte4.byte;  
	record_data.fault_msg[5] = get_fault_info()->fault_info1.byte5.byte;  
    record_data.fault_msg[6] = get_fault_info()->fault_info1.byte6.byte;
    record_data.fault_msg[7] = get_fault_info()->fault_info1.byte7.byte;

    record_data.fault_msg[8] = get_fault_info()->fault_info2.byte2.byte;
    record_data.fault_msg[9] = get_fault_info()->fault_info2.byte3.byte; 
    record_data.fault_msg[10] = get_fault_info()->fault_info2.byte4.byte;
    record_data.fault_msg[11] = get_fault_info()->fault_info2.byte5.byte;
    record_data.fault_msg[12] = get_fault_info()->fault_info3.byte0.byte; 
    record_data.fault_msg[13] = get_fault_info()->fault_info3.byte1.byte;
    record_data.fault_msg[14] = get_fault_info()->fault_info3.byte2.byte; 
    record_data.fault_msg[15] = get_fault_info()->fault_info3.byte4.byte; 

    for(uint8_t i = 0; i < CELL_VOLT_NUM/16; i++)
    {
        record_data.bal_stus[i] = p_bmu_data->bal_stus[i];        
    }

    sop_limit_data = sop_limit_value_get_deal();
    record_data.chrg_cur_lim = sop_limit_data.chg_curr_limit * 10;
    record_data.dischrg_cur_lim = sop_limit_data.dsg_curr_limit * 10;
    
    record_data.sys_status = bms_state_get_sys_sta();
    record_data.other_status = get_bmu_yx_req_data()->req.byte;
    record_data.fault_id = 0xff;    //无效故障id，用于正常的存储
	return record_data;
    
}

static void bms_record_data_save(void)
{
    bms_record_data_t  record_data = {0};
    static uint32_t data_store_tick = 0;   

    //常规5分钟保存一次数据
    if (true == sdk_is_tick_over(data_store_tick, os_tick_from_millisecond(RECORD_SAVE_PERIOD2)))
    {

        if ((0 == g_data_store_flag.record_file_open)
            && (0 == g_data_store_flag.bms_record_read_flag))
        {
            g_data_store_flag.bms_record_save_flag = 1;
            //record_data = record_data_fill();
            record_data = g_fault_record_buff_info.fault_record_buff[g_fault_record_buff_info.fault_buff_fill_cnt]; //目前故障录波和日志的存储内容一致，故这里可以不需要跑record_data_fill
            if(0 == sdk_record_write(NORMAL_RECORD, 0, (uint8_t *)&record_data, sizeof(bms_record_data_t)))
            {
                g_data_store_flag.record_file_err_cnt = 0;
                g_data_store_flag.bms_record_save_flag = 0;
            }
            else
            {
                if(++g_data_store_flag.record_file_err_cnt >= 3)
                {
                    g_data_store_flag.record_file_err_cnt = 3;
                    g_data_store_flag.bms_record_save_flag = 0;
                    data_store_fault_set(DATA_STORE_RECORD, INVRLID);
                }
            }
        }

        
        data_store_tick = sdk_tick_get();

    }    
}

int8_t attr_data_resume_default_data(void)
{
    return data_store_save_bms_attr(ST_VAR_POS(bms_attr_t,safety), (uint8_t *)(&bms_attr_init.safety),ST_VAR_SIZE( bms_attr_t, safety ) );
}





int8_t bms_record_data_read(uint16_t read_num, bms_record_data_t *p_data)
{
    uint16_t record_max_num = 0;
    int8_t ret = 0; 

    record_max_num = sdk_record_get_index(NORMAL_RECORD);
    if(read_num >= record_max_num)
    {
        ret = -1;
    }
    else
    {
        ret = sdk_record_read(NORMAL_RECORD, read_num, (uint8_t *)p_data, sizeof(bms_record_data_t));
    }

    return ret;

}


//删除日志记录
static int8_t bms_record_data_delte(void)
{
    return sdk_record_delete(NORMAL_RECORD);
}


/**
 * @brief BMS数据管理线程(100ms调用一次)
 *
 */
void data_store_thread(void)
{
    static uint8_t store_cnt = 3;
    //进入关机状态，确保保存3次（兼容保存失败的3次计数）
    if(BMS_STATE_SHUT_DOWN == bms_state_get_sys_sta())
    {
        if(store_cnt > 0)   
        {
            store_cnt--;
        }
        else
        {
            return;            
        }

    }

    //属性保存函数
    bms_attr_data_save();

    //运行数据保存函数
    bms_running_data_save();
	
	//日志保存
	bms_record_data_save();

    /* --------------------------------------------------------------------------------------- */
    //
    /* --------------------------------------------------------------------------------------- */
    // if ((g_data_store_flag.bms_attr_save_flag == 0)           //
    //     && (g_data_store_flag.bms_runing_data_save_flag == 0) 
    //     && (g_data_store_flag.bms_record_save_flag == 0)
    //     )
    // { // 当没有数所保存时，解除休眠锁
    //     sdk_pm_unlock(sleep_lock_id);
    // }
}

//删除故障录波文件
int8_t bms_fault_record_file_delte(void)
{
    g_data_store_flag.fault_record_file_open = -1;  //关闭文件
    return sdk_record_delete(FAULT_DATA_RECORD);
}

 static int8_t fault_record_data_store(void)
 {
     int8_t ret = 0;

     uint16_t buf_num = 0;
     int16_t tmp_buf = 0;
  
     // 数据写入
     if(g_fault_record_buff_info.buff_full_flag)
     {
         buf_num = g_fault_record_buff_info.fault_buff_fill_cnt;
         for(uint8_t i = 0; i < WINDOW_SIZE - g_fault_record_buff_info.fault_buff_fill_cnt; i++)
         {
             tmp_buf = sdk_record_write(FAULT_DATA_RECORD, 0, (uint8_t *)&g_fault_record_buff_info.fault_record_buff[buf_num + i], sizeof(bms_record_data_t));
             if(tmp_buf != 0)
             {
                 ret = -2;
                 goto err_exit;
             }
         }
         for(uint8_t i = 0; i < g_fault_record_buff_info.fault_buff_fill_cnt; i++)
         {
             tmp_buf = sdk_record_write(FAULT_DATA_RECORD, 0, (uint8_t *)&g_fault_record_buff_info.fault_record_buff[i], sizeof(bms_record_data_t));
             if(tmp_buf != 0)
             {
                 ret = -3;
                 goto err_exit;
             } 
         }
     }
     else
     {
         for(uint8_t i = 0;i <= g_fault_record_buff_info.fault_buff_fill_cnt;i++)
         {
             tmp_buf = sdk_record_write(FAULT_DATA_RECORD, 0, (uint8_t *)&g_fault_record_buff_info.fault_record_buff[i], sizeof(bms_record_data_t));
             if(tmp_buf != 0)
             {
                 ret = -4;
                 goto err_exit;
             }
         }
     }
     log_d("[record]StoringSuccess: %d\n",sdk_record_get_index(FAULT_DATA_RECORD));
     return ret;  

 err_exit:
     log_w("[record]StoringFailed:%d\n",ret);

     return ret;
 }


/**
* @brief 故障录波线程(1000ms调用一次)
*
*/
void fault_recording_proc(void)
{
    //    uint8_t i,j;
    static uint8_t cnt = 0;
    static uint32_t temp_time = 0;
    static uint8_t first_half_record_save_flag = 1;    // 故障录波前半段5s数据保存标志
    uint8_t fault_id = 0xff;    //0xff为无效故障id
    if (true == sdk_is_tick_over(temp_time, 1000))
    {   
        temp_time = sdk_tick_get();

        if(g_fault_record_buff_info.fault_buff_fill_cnt + 1 == WINDOW_SIZE) //当前已经存满
        {
            g_fault_record_buff_info.buff_full_flag = true;
        }
        g_fault_record_buff_info.fault_record_buff[g_fault_record_buff_info.fault_buff_fill_cnt] = record_data_fill();    //TO DO

        // log_d("[fault_record]: fault_buff_fill_cnt = %d  \r \n", g_fault_record_buff_info.fault_buff_fill_cnt);

        //进入关机状态或读取过程中不保存
        // if (data_store_enable_flag == false)
        // {
        //     return;
        // }

        if(fault_state_change(&fault_id))
        {
            g_fault_record_buff_info.fault_record_buff[g_fault_record_buff_info.fault_buff_fill_cnt].fault_id = fault_id;
            if(first_half_record_save_flag)
            {
                first_half_record_save_flag = 0;
                if(0 != fault_record_data_store())
                {
                    ++cnt;
                }
                else
                {
                    cnt = 0;
                }
            }
            else
            {
                g_fault_record_buff_info.fault_record_cnt++;
                //每5条存一次
                if(0 == g_fault_record_buff_info.fault_record_cnt % WINDOW_SIZE)
                {
                    if(0 != fault_record_data_store())
                    {
                        ++cnt;
                    }
                    else
                    {
                        cnt = 0;
                    }
                }
            }
        }
        else
        {
            g_fault_record_buff_info.fault_record_cnt = 0;
            first_half_record_save_flag = 1;
        }

        g_fault_record_buff_info.fault_buff_fill_cnt = (g_fault_record_buff_info.fault_buff_fill_cnt + 1) % WINDOW_SIZE;//挪到下面主要是因为故障id需要填充  

        if(cnt >= 5)
        {
            data_store_fault_set(DATA_STORE_FAULT_RECORD, INVRLID);
        }

    }

}

void fault_recording_init(void)
{
    g_fault_record_buff_info.fault_record_cnt = 0; //

    g_data_store_flag.fault_record_file_open = sdk_record_init(FAULT_DATA_RECORD, sizeof(bms_record_data_t), FAULT_RECORD_DOG_DEPTH);
    if (g_data_store_flag.fault_record_file_open != 0)
    {
        data_store_fault_set(DATA_STORE_FAULT_RECORD, INVRLID);
        log_w("[store]FaultRecordDataInitFail\n");
    }    
 
}


void set_bms_record_read_flag(uint8_t flag)
{
    g_data_store_flag.bms_record_read_flag = flag;
}

void set_fault_record_read_flag(uint8_t flag)
{
    g_data_store_flag.fault_record_read_flag = flag;
}

void set_his_event_read_flag(uint8_t flag)
{
    g_data_store_flag.his_event_read_flag = flag;
}

/********************************************调试代码********************************************************/
void run_data_print(bms_record_data_t *p_data)
{
    log_d("year_month=%#x\n",p_data->year_month);
    log_d("day_hour=%#x\n",p_data->day_hour);
    log_d("min_sec=%#x\n",p_data->min_sec);
    log_d("bat_afe_volt=%d\n",p_data->bat_afe_volt);
    log_d("soc=%d\n",p_data->soc);
    log_d("soh=%d\n",p_data->soh);
    log_d("max_volt=%d\n",p_data->max_volt);
    log_d("max_volt_no=%d\n",p_data->max_volt_no);
    log_d("max_temp=%d\n",p_data->max_temp_no);
    log_d("sys_status=%#x\n",p_data->sys_status);
    log_d("fault_msg=%#x\n",p_data->fault_msg[0]);
    log_d("supply_volt=%d\n",p_data->supply_volt);
    log_d("other_temp=%d\n",p_data->other_temp[0]);
    log_d("cell_volt=%d\n",p_data->cell_volt[0]);
    log_d("cell_temp=%d\n",p_data->cell_temp[0]);
}




/**
 * @brief                故障调试接口
 * @return               返回结果空
 * @warning              测试调试使用
 */
int32_t run_data(int argc, char *argv[])
{
    if (argc < 2)
    {
        log_d("runDataErr\n");
        return SF_ERR_PARA;
    }
    bms_record_data_t bms_record_data = {0};
    uint16_t operation = 0;

    log_d("%s start\n", argv[0]);		//打印命令名称


	if(!strcmp(argv[1], "write"))		//写一条日志
	{
        bms_record_data = record_data_fill();
        if(0 == sdk_record_write(NORMAL_RECORD, 0, (uint8_t *)&bms_record_data, sizeof(bms_record_data_t)))
        {
            log_d("record_test write succ\n");
        }
        else
        {
            log_d("record_test write err\n");
        }
	}
    else if(!strcmp(argv[1], "read"))	//读日志
    {
        if (argc < 3)
        {
            log_d("runDataReadErr\n");
            return SF_ERR_PARA;
        }
        operation = atoi(argv[2]);
        if(-1 == bms_record_data_read(operation, &bms_record_data))
        {
            log_d("record_test read err\n");
        }
        else
        {
            run_data_print(&bms_record_data);
        }
        
    }
    else if(!strcmp(argv[1], "delete"))
    {
        if(0 == bms_record_data_delte())
        {
            log_d("record_test delete succ\n");
        }
        else
        {
            log_d("record_test delete err\n");
        }
    }
    else if(!strcmp(argv[1], "fault_set"))
    {
        data_store_fault_set(DATA_STORE_RECORD, INVRLID);
        log_d("record_test fault set succ\n\r");
    }


    return 0;
}
MSH_CMD_EXPORT(run_data, <write/read/delete/fault_set>);





//bms_runing_data_t bms_data_2 = {0};
///**
// * @brief                故障调试接口
// * @return               返回结果空
// * @warning              测试调试使用
// */
//int32_t running_data_record(int argc, char *argv[])
//{
//    if (argc < 2)
//    {
//        log_d("running_dataParaErr\n");
//        return SF_ERR_PARA;
//    }
//    uint16_t operation = 0;    
//    int16_t ret = 0; 

//    
//    bms_data_2 = *get_bms_runing_data();    
//    if(!strcmp(argv[1], "store"))    
//    {
//        operation = atoi(argv[2]);
//        bms_data_2.reserve[0] = operation;
//        bms_runing_data_deal(bms_data_2, true);
//        
//    }
//    
//    return 0;
//}
//MSH_CMD_EXPORT(running_data_record, <>);


#if BMS_ATTR_PRINT_FLAG
/**
 * @brief                bms_attr数据打印
 * @return               返回结果空
 * @warning              测试调试使用
 */
void bms_attr_data_debug_printf(void)
{
    const bms_attr_t *p_bms_attr = get_bms_attr();
    log_d("cell_over_vol_protect    APP=%d, Canc=%d\n", p_bms_attr->safety.cell_over_vol_protect.appear_value   , p_bms_attr->safety.cell_over_vol_protect.cancel_value    );    ///< 单体过压保护    
    log_d("cell_over_vol_alarm      APP=%d, Canc=%d\n", p_bms_attr->safety.cell_over_vol_alarm.appear_value     , p_bms_attr->safety.cell_over_vol_alarm.cancel_value      );    ///< 单体过压告警
    log_d("cell_over_vol_tip        APP=%d, Canc=%d\n", p_bms_attr->safety.cell_over_vol_tip.appear_value       , p_bms_attr->safety.cell_over_vol_tip.cancel_value        );    ///< 单体过压提示
    log_d("cell_under_vol_protect   APP=%d, Canc=%d\n", p_bms_attr->safety.cell_under_vol_protect.appear_value  , p_bms_attr->safety.cell_under_vol_protect.cancel_value   );    ///< 单体欠压保护    
    log_d("cell_under_vol_alarm     APP=%d, Canc=%d\n", p_bms_attr->safety.cell_under_vol_alarm.appear_value    , p_bms_attr->safety.cell_under_vol_alarm.cancel_value     );    ///< 单体欠压告警
    log_d("cell_under_vol_tip       APP=%d, Canc=%d\n", p_bms_attr->safety.cell_under_vol_tip.appear_value      , p_bms_attr->safety.cell_under_vol_tip.cancel_value       );    ///< 单体欠压提示
    log_d("cell_volt_diff_protect   APP=%d, Canc=%d\n", p_bms_attr->safety.cell_volt_diff_protect.appear_value  , p_bms_attr->safety.cell_volt_diff_protect.cancel_value   );    ///< 单体压差过大保护    
    log_d("cell_volt_diff_alarm     APP=%d, Canc=%d\n", p_bms_attr->safety.cell_volt_diff_alarm.appear_value    , p_bms_attr->safety.cell_volt_diff_alarm.cancel_value     );    ///< 单体压差过大告警
    log_d("cell_volt_diff_tip       APP=%d, Canc=%d\n", p_bms_attr->safety.cell_volt_diff_tip.appear_value      , p_bms_attr->safety.cell_volt_diff_tip.cancel_value       );    ///< 单体压差过大提示
    log_d("cell_temp_diff_protect   APP=%d, Canc=%d\n", p_bms_attr->safety.cell_temp_diff_protect.appear_value  , p_bms_attr->safety.cell_temp_diff_protect.cancel_value   );    ///< 单体温差过大保护    
    log_d("cell_temp_diff_alarm     APP=%d, Canc=%d\n", p_bms_attr->safety.cell_temp_diff_alarm.appear_value    , p_bms_attr->safety.cell_temp_diff_alarm.cancel_value     );    ///< 单体温差过大告警
    log_d("cell_temp_diff_tip       APP=%d, Canc=%d\n", p_bms_attr->safety.cell_temp_diff_tip.appear_value      , p_bms_attr->safety.cell_temp_diff_tip.cancel_value       );    ///< 单体温差过大提示      
    log_d("total_over_vol_protect   APP=%d, Canc=%d\n", p_bms_attr->safety.total_over_vol_protect.appear_value  , p_bms_attr->safety.total_over_vol_protect.cancel_value   );    ///< 总压过压保护    
    log_d("total_over_vol_alarm     APP=%d, Canc=%d\n", p_bms_attr->safety.total_over_vol_alarm.appear_value    , p_bms_attr->safety.total_over_vol_alarm.cancel_value     );    ///< 总压过压告警
    log_d("total_over_vol_tip       APP=%d, Canc=%d\n", p_bms_attr->safety.total_over_vol_tip.appear_value      , p_bms_attr->safety.total_over_vol_tip.cancel_value       );    ///< 总压过压提示
    log_d("total_under_vol_protect  APP=%d, Canc=%d\n", p_bms_attr->safety.total_under_vol_protect.appear_value , p_bms_attr->safety.total_under_vol_protect.cancel_value  );    ///< 总压欠压保护
    log_d("total_under_vol_alarm    APP=%d, Canc=%d\n", p_bms_attr->safety.total_under_vol_alarm.appear_value   , p_bms_attr->safety.total_under_vol_alarm.cancel_value    );    ///< 总压欠压告警
    log_d("total_under_vol_tip      APP=%d, Canc=%d\n", p_bms_attr->safety.total_under_vol_tip.appear_value     , p_bms_attr->safety.total_under_vol_tip.cancel_value      );    ///< 总压欠压提示
    log_d("chg_over_cur_protect     APP=%d, Canc=%d\n", p_bms_attr->safety.chg_over_cur_protect.appear_value    , p_bms_attr->safety.chg_over_cur_protect.cancel_value     );    ///< 充电过流保护 单位：0.01A 无偏移量    
    log_d("chg_over_cur_alarm       APP=%d, Canc=%d\n", p_bms_attr->safety.chg_over_cur_alarm.appear_value      , p_bms_attr->safety.chg_over_cur_alarm.cancel_value       );    ///< 充电过流告警 单位：0.01A 无偏移量
    log_d("chg_over_cur_tip         APP=%d, Canc=%d\n", p_bms_attr->safety.chg_over_cur_tip.appear_value        , p_bms_attr->safety.chg_over_cur_tip.cancel_value         );    ///< 充电过流提示 单位：0.01A 无偏移量
    log_d("dchg_over_cur_protect    APP=%d, Canc=%d\n", p_bms_attr->safety.dchg_over_cur_protect.appear_value   , p_bms_attr->safety.dchg_over_cur_protect.cancel_value    );    ///< 放电过流保护2 单位：0.01A 无偏移量    
    log_d("dchg_over_cur_alarm      APP=%d, Canc=%d\n", p_bms_attr->safety.dchg_over_cur_alarm.appear_value     , p_bms_attr->safety.dchg_over_cur_alarm.cancel_value      );    ///< 放电过流保护1 单位：0.01A 无偏移量    
    log_d("dchg_over_cur_tip        APP=%d, Canc=%d\n", p_bms_attr->safety.dchg_over_cur_tip.appear_value       , p_bms_attr->safety.dchg_over_cur_tip.cancel_value        );    ///< 放电过流提示 单位：0.01A 无偏移量
}

void bms_attr_data_debug_printf2(void)
{
    const bms_attr_t *p_bms_attr = get_bms_attr();
    log_d("chg_over_temp_protect    APP=%d, Canc=%d\n", p_bms_attr->safety.chg_over_temp_protect.appear_value   , p_bms_attr->safety.chg_over_temp_protect.cancel_value    );    ///< 充电温度过高保护    
    log_d("chg_over_temp_alarm      APP=%d, Canc=%d\n", p_bms_attr->safety.chg_over_temp_alarm.appear_value     , p_bms_attr->safety.chg_over_temp_alarm.cancel_value      );    ///< 充电温度过高告警
    log_d("chg_over_temp_tip        APP=%d, Canc=%d\n", p_bms_attr->safety.chg_over_temp_tip.appear_value       , p_bms_attr->safety.chg_over_temp_tip.cancel_value        );    ///< 充电温度过高提示
    log_d("dchg_over_temp_protect   APP=%d, Canc=%d\n", p_bms_attr->safety.dchg_over_temp_protect.appear_value  , p_bms_attr->safety.dchg_over_temp_protect.cancel_value   );    ///< 放电温度过高保护    
    log_d("dchg_over_temp_alarm     APP=%d, Canc=%d\n", p_bms_attr->safety.dchg_over_temp_alarm.appear_value    , p_bms_attr->safety.dchg_over_temp_alarm.cancel_value     );    ///< 放电温度过高告警
    log_d("dchg_over_temp_tip       APP=%d, Canc=%d\n", p_bms_attr->safety.dchg_over_temp_tip.appear_value      , p_bms_attr->safety.dchg_over_temp_tip.cancel_value       );    ///< 放电温度过高提示
    log_d("chg_under_temp_protect   APP=%d, Canc=%d\n", p_bms_attr->safety.chg_under_temp_protect.appear_value  , p_bms_attr->safety.chg_under_temp_protect.cancel_value   );    ///< 充电温度过低保护
    log_d("chg_under_temp_alarm     APP=%d, Canc=%d\n", p_bms_attr->safety.chg_under_temp_alarm.appear_value    , p_bms_attr->safety.chg_under_temp_alarm.cancel_value     );    ///< 充电温度过低告警
    log_d("chg_under_temp_tip       APP=%d, Canc=%d\n", p_bms_attr->safety.chg_under_temp_tip.appear_value      , p_bms_attr->safety.chg_under_temp_tip.cancel_value       );    ///< 充电温度过低提示
    log_d("dchg_under_temp_protect  APP=%d, Canc=%d\n", p_bms_attr->safety.dchg_under_temp_protect.appear_value , p_bms_attr->safety.dchg_under_temp_protect.cancel_value  );    ///< 放电温度过低保护    
    log_d("dchg_under_temp_alarm    APP=%d, Canc=%d\n", p_bms_attr->safety.dchg_under_temp_alarm.appear_value   , p_bms_attr->safety.dchg_under_temp_alarm.cancel_value    );    ///< 放电温度过低告警
    log_d("dchg_under_temp_tip      APP=%d, Canc=%d\n", p_bms_attr->safety.dchg_under_temp_tip.appear_value     , p_bms_attr->safety.dchg_under_temp_tip.cancel_value      );    ///< 放电温度过低提示
    log_d("soc_under_protect        APP=%d, Canc=%d\n", p_bms_attr->safety.soc_under_protect.appear_value       , p_bms_attr->safety.soc_under_protect.cancel_value        );    ///< soc过低告警
    log_d("soc_under_alarm          APP=%d, Canc=%d\n", p_bms_attr->safety.soc_under_alarm.appear_value         , p_bms_attr->safety.soc_under_alarm.cancel_value          );    ///< soc过低告警
    log_d("soc_under_tip            APP=%d, Canc=%d\n", p_bms_attr->safety.soc_under_tip.appear_value           , p_bms_attr->safety.soc_under_tip.cancel_value            );    ///< soc过低提示
    log_d("cell_over_vol_seriou     APP=%d, Canc=%d\n", p_bms_attr->safety.cell_over_vol_seriou.appear_value    , p_bms_attr->safety.cell_over_vol_seriou.cancel_value     );    ///< 单体超限    
    log_d("cell_under_vol_seriou    APP=%d, Canc=%d\n", p_bms_attr->safety.cell_under_vol_seriou.appear_value   , p_bms_attr->safety.cell_under_vol_seriou.cancel_value    );    ///< 单体超低  
    log_d("ent_over_temp_alarm      APP=%d, Canc=%d\n", p_bms_attr->safety.ent_over_temp_alarm.appear_value     , p_bms_attr->safety.ent_over_temp_alarm.cancel_value      );    ///< 环境温度过高报警
    log_d("ent_under_temp_alarm     APP=%d, Canc=%d\n", p_bms_attr->safety.ent_under_temp_alarm.appear_value    , p_bms_attr->safety.ent_under_temp_alarm.cancel_value     );    ///< 环境温度过低报警
}

void bms_attr_data_debug_printf3(void)
{
    const bms_attr_t *p_bms_attr = get_bms_attr();
    log_d("bal_vol      =%d\n",  p_bms_attr->bal_vol       );       ///< 均衡开启电压
    log_d("bal_vol_diff =%d\n",  p_bms_attr->bal_vol_diff  );       ///< 均衡开启压差
    log_d("full_chg_vol =%d\n",  p_bms_attr->full_chg_vol  );       ///< 满充电压
    log_d("chg_stop_cur =%d\n",  p_bms_attr->chg_stop_cur  );       ///< 充电截止电流
    log_d("chg_stop_vol =%d\n",  p_bms_attr->chg_stop_vol  );       ///< 充电截止电压  
    log_d("rate_cap     =%d\n",  p_bms_attr->rate_cap      );       ///< 额定容量
    log_d("mono_vol_num =%d\n",  p_bms_attr->mono_vol_num  );       ///< 单体电压个数
    log_d("mono_tem_num =%d\n",  p_bms_attr->mono_tem_num  );       ///< 单体温度个数 
    log_d("cell_num     =%d\n",  p_bms_attr->cell_num      );       ///< 电芯数量      
}

/**
 * @brief                故障调试接口
 * @return               返回结果空
 * @warning              测试调试使用
 */
int32_t store(int argc, char *argv[])
{
    if (argc < 2)
    {
        log_d("storeErr\n");
        return SF_ERR_PARA;
    }

    if (!strcmp(argv[1], "print"))
    {
        uint32_t id = atoi(argv[2]);
        if (id == 1)
        {
            bms_attr_data_debug_printf2();
        }
        else if (id == 2)
        {
            bms_attr_data_debug_printf3();
        }
        else
        {
            bms_attr_data_debug_printf();
        }
    }
    return 0;
}

MSH_CMD_EXPORT(store, <help/print 0-2>);
#endif
