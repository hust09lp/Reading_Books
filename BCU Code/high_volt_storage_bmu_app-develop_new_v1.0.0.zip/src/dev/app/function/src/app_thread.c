#include "app_thread.h"
#include "sdk.h"
#include "sdk_osif.h"
#include "sdk_core.h"
#include "data_types.h"
#include "app_public.h"
#include "auto_addressing.h"
#include "sofar_can_manage.h"
#include "sofar_can_data.h"
#include "bms_state.h"
#include "fault_manage.h"
#include "public_flag.h"
#include "sample.h"
#include "afe_manage.h"
#include "bmu_data.h"
#include "sox_public.h"
#include "sop.h"
#include "passive_balance.h"
#include "upgrade.h"
#include "data_store.h"
#include "led.h"
#include "ate.h"
#include "file_read.h"

/* 线程参数结构定义 */
uint32_t g_5ms_thread_stack[8192/4];		// 5ms任务堆栈大小   优先级46
uint32_t g_10ms_thread_stack[8192/4];     	// 10ms任务堆栈大小  优先级45
uint32_t g_afe_thread_stack[2048/4];		// afe管理任务堆栈大小 优先级43
#if PACK_64S_PRJ
uint32_t g_100ms_thread_stack[9216/4];	// 数据保存任务堆栈大小 优先级47
#else 
uint32_t g_100ms_thread_stack[8192/4];	// 数据保存任务堆栈大小 优先级47
#endif

static void app_afe_thread(void *argument);
static void app_10ms_thread(void *argument);
static void app_5ms_thread(void *argument);
static void app_100ms_thread(void *argument);

/* app线程定义 */
static sdk_os_thread_attr_tab_t g_thread_attr_tab[] =
{
	{{"app_manage", 0, NULL,  0, 10, (void *)g_afe_thread_stack, sizeof(g_afe_thread_stack), OS_APP_PRIORITY_1, 0}, 
	   app_afe_thread , NULL},

	{{"app_10ms",  0, NULL,  0, 10, (void *)g_10ms_thread_stack , sizeof(g_10ms_thread_stack) , OS_APP_PRIORITY_3, 0}, 
	   app_10ms_thread , NULL},

	{{"app_5ms",   0, NULL,  0, 10, (void *)g_5ms_thread_stack  , sizeof(g_5ms_thread_stack)  , OS_APP_PRIORITY_4, 0}, 
	   app_5ms_thread , NULL},

    {{"app_100ms",   0, NULL,  0, 10, (void *)g_100ms_thread_stack  , sizeof(g_100ms_thread_stack)  , OS_APP_PRIORITY_5, 0}, 
       app_100ms_thread , NULL},


};

//// 任务属性
//static sdk_os_thread_attr_tab_t g_100ms_thread_attr = {
//	"app_100ms",
//	0,
//	NULL,
//	0,
//	20,
//	NULL,
//	2048,
//	OS_APP_PRIORITY_2,
//	0,
//};

static uint8_t app_success_flag = 0;

/**
* @brief        APP运行成功标志设置
* @param        flag 成功标志
* @return       void
*/
void app_run_success_flag_set(uint8_t flag)
{
    app_success_flag = flag;
}

/**
* @brief        APP运行成功标志获取，判断是否升级成功
* @param        void
* @return       flag 成功标志
*/
uint8_t app_run_success_flag_get(void)
{
    return app_success_flag;
}

/**
* @brief        100ms任务，任务内部不允许阻塞延时
* @param        void
* @return       执行结果
*/
static void app_100ms_thread(void *argument)
{	
    ate_mode_init();
	while(1)
	{	
		data_store_thread();
        ate_mode_proc();
		os_delay(TICK_100MS);
	}
}


/**
* @brief        5ms任务，任务内部不允许阻塞延时
* @param        void
* @return       执行结果
*/
static void app_5ms_thread(void *argument)
{	
	upgrade_init();
	fault_recording_init();
	while(1)
	{	
		upgrade_task_proc();
        fault_recording_proc();
		os_delay(TICK_5MS);
	}
}


/**
* @brief        10ms任务，任务内部不允许阻塞延时
* @param        void
* @return       执行结果
*/
static void app_10ms_thread(void *argument)
{	
	static uint32_t timestamp = 0;
	timestamp = sdk_tick_get();    
	bmu_data_init();
	can_sofar_manage_init();
	can_sofar_data_init();
	inner_auto_addr_init();
	fault_manage_init();
	bms_state_init();
	public_flag_init();
    sample_init();
    cell_balance_init();
    bat_led_init();
	file_read_init();
    sox_init();
    sop_init_deal();
	while(1)
	{       
		// 模拟量采样
        sample_proc();
		bmu_data_proc();
		// 自动编址(10ms)
		inner_auto_addressing_proc();
        // 故障诊断(10ms)
		fault_manage_task(); 
		// bms状态管理(10ms)
		bms_state_proc();
        // led 控制管理
        bat_led_display_proc();
		// 公共标志模块(10ms)
		public_flag_task();
        // 电芯均衡
        cell_balance_proc();
        // CAN管理(10ms)
        can_sofar_manage_proc();
        can_sofar_data_send_proc(); 
        // sox计算
        sox_proc();
        // sop计算
        sop_proc_deal();
		file_read_proc();
		os_delay_until(&timestamp,TICK_10MS);
	}
}

/**
* @brief        AFE管理任务，仅用于AFE管理
* @param        void
* @return       执行结果
*/
static void app_afe_thread(void *argument)
{       
	afe_init();
    bq79600_data_init();
    while (1)
    {
		afe_management();
		os_delay(os_tick_from_millisecond(AFE_TASK_MS));
    }
}

/**
* @brief        App主函数入口, 本身属于core层创建的一个供app独立使用的线程
* @param        void
* @return       执行结果
*/
int32_t app_thread_creat(void)
{	  
    int32_t result;
    
    result = os_thread_new(ITEM_NUM(g_thread_attr_tab), g_thread_attr_tab);
    if (-1 == result) 
	{
		log_e("app thread creat failed!\n");
	}
	else
	{	
		log_i("app thread creat sucess!\n");
	}
    
    return result;
}

/**
* @brief        app的main函数，这里只有是在app和core合并的时候才需要调用该函数
* @param        void
* @return       执行结果
*/
int32_t app_main(void)
{
    char  sdk_version_buff[16];
    //sdk_shell_regist(app_msh_get_cmd);
    core_app_api_init();
    //打印boot版本
    memset(sdk_version_buff, 0x00, sizeof(sdk_version_buff));
    sdk_version_get(BOOT_VERSION_TYPE, (int8_t *)sdk_version_buff, sizeof(sdk_version_buff));
    log_i("\nbootVer: %s\n", sdk_version_buff);    
    
    //打印core版本
    memset(sdk_version_buff, 0x00, sizeof(sdk_version_buff));
    sdk_version_get(SDK_VERSION_TYPE, (int8_t *)sdk_version_buff, sizeof(sdk_version_buff));
    log_i("coreSdkVer:%s,appVer: %s\n", sdk_version_buff, SOFTWARE_VERSION);
    app_run_success_flag_set(1);
    data_store_init();
    app_thread_creat();
    
    return true;
}








