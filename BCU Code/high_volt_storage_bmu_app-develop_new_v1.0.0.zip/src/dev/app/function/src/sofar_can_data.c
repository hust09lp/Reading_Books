#include "sofar_can_data.h"
#include "sofar_can_manage.h"
#include "sdk.h"
#include "sdk_core.h"
#include "auto_addressing.h"
#include "bmu_data.h"
#include "fault_manage.h"
#include "public_flag.h"
#include "bms_state.h"
#include "data_store.h"
#include "file_read.h"
#include "app_public.h"
#include "ate.h"
#include "afe_manage.h"
#include "data_store.h"
#include "soc.h"
#include "soh.h"
#include "sop.h"
#include "sox_stats.h"
#include "sox_public.h"
#include "passive_balance.h"


#define UINT16_BIT_NUM (16)
#define CAN_SEND_READY_FLAG_NUM ((INNER_MSG_CNT + UINT16_BIT_NUM - 1) / UINT16_BIT_NUM)

// warn 顺序必须与bms_attr_t的一一对应
typedef enum
{
    SET_THRE_CELL_OVER_VOLT_PROT      = 0,  // 单体过充保护阈值
    SET_THRE_CELL_OVER_VOLT_PROT_DIS     ,  // 单体过充保护消失阈值
    SET_THRE_CELL_OVER_VOLT_ALRM         ,  // 单体过充告警阈值
    SET_THRE_CELL_OVER_VOLT_ALRM_DIS     ,  // 单体过充告警消失阈值
    SET_THRE_CELL_OVER_VOLT_TIP          ,  // 单体过充提示阈值
    SET_THRE_CELL_OVER_VOLT_TIP_DIS      ,  // 单体过充提示消失阈值
    SET_THRE_CELL_UNDER_VOLT_PROT        ,  // 单体欠压保护阈值
    SET_THRE_CELL_UNDER_VOLT_PROT_DIS    ,  // 单体欠压保护消失阈值
    SET_THRE_CELL_UNDER_VOLT_ALRM        ,  // 单体欠压告警阈值
    SET_THRE_CELL_UNDER_VOLT_ALRM_DIS    ,  // 单体欠压告警消失阈值
    SET_THRE_CELL_UNDER_VOLT_TIP         ,  // 单体欠压提示阈值
    SET_THRE_CELL_UNDER_VOLT_TIP_DIS     ,  // 单体欠压提示消失阈值
    SET_THRE_CELL_VOLT_DIFF_PROT        ,  // 单体压差过大保护阈值
    SET_THRE_CELL_VOLT_DIFF_PROT_DIS    ,  // 单体压差过大保护消失阈值
    SET_THRE_CELL_VOLT_DIFF_ALRM        ,  // 单体压差过大告警阈值
    SET_THRE_CELL_VOLT_DIFF_ALRM_DIS    ,  // 单体压差过大告警消失阈值
    SET_THRE_CELL_VOLT_DIFF_TIP         ,  // 单体压差过大提示阈值
    SET_THRE_CELL_VOLT_DIFF_TIP_DIS     ,  // 单体压差过大提示消失阈值
    SET_THRE_CELL_TEMP_DIFF_PROT        ,  // 单体温差过大保护阈值
    SET_THRE_CELL_TEMP_DIFF_PROT_DIS    ,  // 单体温差过大保护消失阈值
    SET_THRE_CELL_TEMP_DIFF_ALRM        ,  // 单体温差过大告警阈值
    SET_THRE_CELL_TEMP_DIFF_ALRM_DIS    ,  // 单体温差过大告警消失阈值
    SET_THRE_CELL_TEMP_DIFF_TIP         ,  // 单体温差过大提示阈值
    SET_THRE_CELL_TEMP_DIFF_TIP_DIS     ,  // 单体温差过大提示消失阈值
    SET_THRE_TOTAL_OVER_VOLT_PROT        ,  // 总压过充保护阈值
    SET_THRE_TOTAL_OVER_VOLT_PROT_DIS    ,  // 总压过充保护消失阈值
    SET_THRE_TOTAL_OVER_VOLT_ALRM        ,  // 总压过充告警阈值
    SET_THRE_TOTAL_OVER_VOLT_ALRM_DIS    ,  // 总压过充告警消失阈值
    SET_THRE_TOTAL_OVER_VOLT_TIP         ,  // 总压过充提示阈值
    SET_THRE_TOTAL_OVER_VOLT_TIP_DIS     ,  // 总压过充提示消失阈值
    SET_THRE_TOTAL_UNDER_VOLT_PROT       ,  // 总压欠压保护阈值
    SET_THRE_TOTAL_UNDER_VOLT_PROT_DIS   ,  // 总压欠压保护消失阈值
    SET_THRE_TOTAL_UNDER_VOLT_ALRM       ,  // 总压欠压告警阈值
    SET_THRE_TOTAL_UNDER_VOLT_ALRM_DIS   ,  // 总压欠压告警消失阈值
    SET_THRE_TOTAL_UNDER_VOLT_TIP        ,  // 总压欠压提示阈值
    SET_THRE_TOTAL_UNDER_VOLT_TIP_DIS    ,  // 总压欠压提示消失阈值
    SET_THRE_CHG_OVER_CUR_PROT           ,  // 充电过流保护阈值
    SET_THRE_CHG_OVER_CUR_PROT_DIS       ,  // 充电过流保护消失阈值
    SET_THRE_CHG_OVER_CUR_ALRM           ,  // 充电过流告警阈值
    SET_THRE_CHG_OVER_CUR_ALRM_DIS       ,  // 充电过流告警消失阈值
    SET_THRE_CHG_OVER_CUR_TIP            ,  // 充电过流提示阈值
    SET_THRE_CHG_OVER_CUR_TIP_DIS        ,  // 充电过流提示消失阈值
    SET_THRE_DCHG_OVER_CUR_PROT1         ,  // 放电过流1保护阈值
    SET_THRE_DCHG_OVER_CUR_PROT1_DIS     ,  // 放电过流1保护消失阈值
    SET_THRE_DCHG_OVER_CUR_ALRM          ,   // 放电过流告警阈值
    SET_THRE_DCHG_OVER_CUR_ALRM_DIS      ,   // 放电过流告警消失阈值
    SET_THRE_DCHG_OVER_CUR_TIP           ,   // 放电过流提示阈值
    SET_THRE_DCHG_OVER_CUR_TIP_DIS       ,   // 放电过流提示消失阈值
    SET_THRE_CHG_OVER_TEMP_PROT          ,   // 充电高温保护阈值
    SET_THRE_CHG_OVER_TEMP_PROT_DIS      ,   // 充电高温保护消失阈值
    SET_THRE_CHG_OVER_TEMP_ALRM          ,   // 充电高温告警阈值
    SET_THRE_CHG_OVER_TEMP_ALRM_DIS      ,   // 充电高温告警消失阈值
    SET_THRE_CHG_OVER_TEMP_TIP           ,   // 充电高温提示阈值
    SET_THRE_CHG_OVER_TEMP_TIP_DIS       ,   // 充电高温提示消失阈值
    SET_THRE_DCHG_OVER_TEMP_PROT         ,   // 放电高温保护阈值
    SET_THRE_DCHG_OVER_TEMP_PROT_DIS     ,   // 放电高温保护消失阈值
    SET_THRE_DCHG_OVER_TEMP_ALRM         ,   // 放电高温告警阈值
    SET_THRE_DCHG_OVER_TEMP_ALRM_DIS     ,   // 放电高温告警消失阈值
    SET_THRE_DCHG_OVER_TEMP_TIP          ,   // 放电高温提示阈值
    SET_THRE_DCHG_OVER_TEMP_TIP_DIS      ,   // 放电高温提示消失阈值
    SET_THRE_CHG_UNDER_TEMP_PROT         ,   // 充电低温保护阈值
    SET_THRE_CHG_UNDER_TEMP_PROT_DIS     ,   // 充电低温保护消失阈值
    SET_THRE_CHG_UNDER_TEMP_ALRM         ,   // 充电低温告警阈值
    SET_THRE_CHG_UNDER_TEMP_ALRM_DIS     ,   // 充电低温告警消失阈值
    SET_THRE_CHG_UNDER_TEMP_TIP          ,   // 充电低温提示阈值
    SET_THRE_CHG_UNDER_TEMP_TIP_DIS      ,   // 充电低温提示消失阈值
    SET_THRE_DCHG_UNDER_TEMP_PROT        ,   // 放电低温保护阈值
    SET_THRE_DCHG_UNDER_TEMP_PROT_DIS    ,   // 放电低温保护消失阈值
    SET_THRE_DCHG_UNDER_TEMP_ALRM        ,   // 放电低温告警阈值
    SET_THRE_DCHG_UNDER_TEMP_ALRM_DIS    ,   // 放电低温告警消失阈值
    SET_THRE_DCHG_UNDER_TEMP_TIP         ,   // 放电低温提示阈值
    SET_THRE_DCHG_UNDER_TEMP_TIP_DIS     ,   // 放电低温提示消失阈值
    SET_THRE_SOC_UNDER_PRO               ,   // 低SOC保护
    SET_THRE_SOC_UNDER_PRO_DIS           ,   // 低SOC保护消失阈值
    SET_THRE_SOC_UNDER_ALRM              ,   // 低SOC告警
    SET_THRE_SOC_UNDER_ALRM_DIS          ,   // 低SOC告警消失阈值
    SET_THRE_SOC_UNDER_TIP               ,   // 低SOC提示
    SET_THRE_SOC_UNDER_TIP_DIS           ,   // 低SOC提示消失阈值
    SET_THRE_CELL_VOLT_OVER_SERIOUS      ,   // 单体超限产生阈值
    SET_THRE_CELL_VOLT_OVER_SERIOUS_DIS  ,   // 单体超限解除阈值
    SET_THRE_CELL_VOLT_UNDER_SERIOUS     ,   // 单体超低产生阈值
    SET_THRE_CELL_VOLT_UNDER_SERIOUS_DIS ,   // 单体超低解除阈值
    SET_THRE_ENV_TEMP_OVER_ALRM          ,   // 环境温度过高告警
    SET_THRE_ENV_TEMP_OVER_ALRM_DIS      ,   // 环境温度过高告警消失阈值
    SET_THRE_ENV_TEMP_UNDER_ALRM         ,   // 环境温度过低告警
    SET_THRE_ENV_TEMP_UNDER_ALRM_DIS     ,   // 环境温度过低告警消失阈值
    SET_THRE_ALM_VAL_END,
    SET_THRE_BAL_VOL                     = SET_THRE_ALM_VAL_END,   // 均衡开启电压
    SET_THRE_BAL_VOL_DIFF                ,   // 均衡开启压差
    SET_THRE_FULL_CHG_VOL                ,   // 满充电压
    SET_THRE_CHG_STOP_CUR                ,   // 电池包截止电流
    SET_THRE_CHG_STOP_VOL                ,   // 电池包截止电压
    SET_THRE_RATE_CAP                    ,   // 额定容量
    SET_THRE_MONO_VOL_NUM                ,   // 单体电压个数
    SET_THRE_MONO_TEMP_NUM               ,   // 单体温度个数
    SET_THRE_CELL_NUM                    ,   // 电芯个数
    SET_THRE_OTHER_VAL_END,
    SET_THRE_ADD_CAP_CHG                 = SET_THRE_OTHER_VAL_END,   // 累计充电容量
    SET_THRE_ADD_CAP_DCHG                ,   // 累计放电容量
    SET_THRE_SOC                         ,   // SOC
    SET_THRE_SOH                         ,   // SOH
    SET_THRE_CNT,
} set_thre_id_e;

typedef enum
{
    CYCLE_MSG_YX_ID = 0,
    CYCLE_MSG_CELL_VOLT_ID,
    CYCLE_MSG_DEV_ID,
    CYCLE_MSG_YC1_ID,
    CYCLE_MSG_YC2_ID,
    CYCLE_PACK_SN_ID,
    CYCLE_BOARD_SN_ID,
    CYCLE_MSG_CNT,
} frame_cycle_id_e;

typedef enum
{
    CALI_PACK_VOLT_TYPE = 0x01,
    CALI_LOAD_VOLT_TYPE = 0x02,
    CALI_CHG_BIG_CURR_TYPE = 0x03,
    CALI_CHG_SMALL_CURR_TYPE = 0x04,
    CALI_DSG_BIG_CURR_TYPE = 0x05,
    CALI_DSG_SMALL_CURR_TYPE = 0x06,
} can_cali_data_type_e;

typedef enum
{
    ATE_CALI_NON = 0,
    ATE_CALI_READ_OK_RLT = 0x01,     // 0x01:读取成功
    ATE_CALI_READ_ERR_RLT = 0x02,    // 0x02:读取失败
    ATE_CALI_RECOVER_OK_RLT = 0xAA,  // 0xAA:恢复成功
    ATE_CALI_RECOVER_ERR_RLT = 0x55, // 0x55:恢复异常
} cali_para_query_e;

//CAN id msg
typedef union{
    uint8_t all;
    struct{
        uint8_t bat_sta:         2;    // 0x0：待机状态  0x1：充电状态  0x2：放电状态
        uint8_t full_chg_sta:    1;    // 1:充满  0:正常
        uint8_t empty_sta:       1;    // 1:放亏 0:正常
        uint8_t shut_down_sta:   1;    // 1:关机 0:正常
        uint8_t bal_recharge:    1;    // 1:清除 0:正常
        uint8_t pack_recover:    1;    // 1:复归处理
        uint8_t res:             1;    // < Reserved.
    }bit;
}can_bat_status_u;

typedef struct
{
    // 上层下发设置参数
    int16_t set_curr; // 单位0.01A，bcu设置电流
    uint16_t set_bal_status; //本簇所有BMU均衡状态
    uint16_t set_bal_min_cell_soc; // 单位0.01%
    can_bat_status_u set_bat_sta;
    uint8_t set_sync_fall_soc;  // 单位%
    uint8_t set_act_bal_ctl;  // 0：禁止；1：充电；2：放电；无效:0xff
    // ate数据由ate模块处理
} set_bmu_data;

typedef struct
{
    uint16_t id;         // 此id用于快速定位数组
    uint16_t func_code;
    bool (*p_func_send_deal_cb)(can_frame_data_t *can_data, uint16_t func_code);
    bool (*p_func_recv_deal_cb)(can_frame_data_t *can_data, uint16_t func_code);
} can_msg_tcb_t;

typedef struct
{
    uint8_t cycle_send_data_id;
    uint8_t module_groub_id;  // 参考 module_request_send_group_e
    uint16_t first_delay;
    uint16_t send_period;
    int16_t send_cnt;        // 发送次数，小于0:一直发送
} can_cycle_send_tcb_t;

// 发送处理函数
static bool inner_can_reply_msg_slaver_ctl(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_master_curr_set_cmd(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_master_bal_set_cmd(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_heart_beat_cmd(can_frame_data_t *can_data, uint16_t func_code);

static bool inner_can_tx_msg_bms_inter_info2(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_bms_inter_info3(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_bms_inter_info4(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_bms_inter_info5(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_bms_fault_info1(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_power_mos_temp_info(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_bms_cell_other_info1(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_bms_inter_info6(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_bms_inter_info7(can_frame_data_t *can_data, uint16_t func_code);
//static bool inner_can_tx_msg_bal_temp_info1(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_bms_fault_info2(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_bms_remote_signal_info1(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_bms_remote_signal_info2(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_act_bal_info1(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_act_bal_info2(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_soft_ver_info1(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_soft_ver_info2(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_soft_ver_info3(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_bms_remote_signal_info3(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_cell_volt_overflow(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_cell_temp_overflow(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_cell_pass_bal_state_overflow(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_cell_bal_temp_overflow(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_bmu_soc_info(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_bmu_soh_info(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_bms_alarm_tips_info(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_mas_other_data_info(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_tx_msg_ate_test_result_info(can_frame_data_t *can_data, uint16_t func_code);


// ate 告警设置
static bool inner_can_reply_msg_ate_cell_volt_over_alm_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_bat_volt_over_alm_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_cell_volt_under_alm_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_bat_volt_under_alm_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_chg_curr_over_alm_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_dchg_curr_over_alm_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_cell_temp_over_alm_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_cell_temp_under_alm_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_soc_low_alm_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_bat_curr_over_alm_2_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_cell_volt_err_alm_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_cell_volt_tip_set(can_frame_data_t *can_data, uint16_t func_code);   
static bool inner_can_reply_msg_ate_cell_volt_diff_1_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_cell_volt_diff_2_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_cell_temp_tip_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_cell_temp_diff_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_batt_volt_tip_set(can_frame_data_t *can_data, uint16_t func_code);
// ate 其他设置
static bool inner_can_reply_msg_ate_flash_test(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_set_old_mode(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_bal_heat_param_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_cell_volt_curr_limit_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_cell_num_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_chg_dsg_cap_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_sox_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_sys_time_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_pack_sn_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_board_sn_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_cell_info_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_cali_param_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_bmu_func_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_monitor_data_read(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_clr_history_data(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_read_set_data(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_force_ctl_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_reply_msg_ate_force_ctl_set_2(can_frame_data_t *can_data, uint16_t func_code);


// can接受处理函数
static bool inner_can_rx_master_ctl_cmd(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_master_curr_set_cmd(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_master_bal_set_cmd(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_heart_beat_cmd(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_master_pass_bal_set_cmd(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_mas_other_data_set_cmd(can_frame_data_t *can_data, uint16_t func_code);

static bool inner_can_rx_ate_cell_volt_over_alm_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_bat_volt_over_alm_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_cell_volt_under_alm_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_bat_volt_under_alm_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_chg_curr_over_alm_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_dchg_curr_over_alm_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_cell_temp_over_alm_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_cell_temp_under_alm_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_soc_low_alm_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_bat_curr_over_alm_2_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_cell_volt_err_alm_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_ate_cell_volt_tip_set(can_frame_data_t *can_data, uint16_t func_code);   
static bool inner_can_rx_msg_ate_cell_volt_diff_1_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_ate_cell_volt_diff_2_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_ate_cell_temp_tip_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_ate_cell_temp_diff_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_ate_batt_volt_tip_set(can_frame_data_t *can_data, uint16_t func_code);

static bool inner_can_rx_ate_flash_test(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_set_old_mode(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_bal_heat_param_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_cell_volt_curr_limit_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_cell_num_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_chg_dsg_cap_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_sox_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_sys_time_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_pack_sn_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_board_sn_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_cell_info_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_cali_param_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_bmu_func_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_monitor_data_read(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_clr_history_data(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_read_set_data(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_force_ctl_set(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_ate_force_ctl_set_2(can_frame_data_t *can_data, uint16_t func_code);

// 设置命令
//static uint16_t g_bmu_act_ctrl_set = 0xFFFF;        //BCU设置BMU主动均衡，默认无效值
static int8_t aging_mode_request(uint16_t  value);
static int8_t cali_mode_request(uint16_t  value);
static int8_t ate_mode_request(uint16_t  value);
static int8_t force_ctrl_mode_request(uint16_t  value);
static int8_t cali_resume_default(uint16_t  value);
static int8_t set_bmu_addr(uint16_t  value);

const can_msg_tcb_t g_can_msg_list[] =
{
    // bcu设置
    { MASTER_CTL_CMD               ,  FUNC_MASTER_CTL_CMD                 ,  NULL,                                      inner_can_rx_master_ctl_cmd         },    // BMS控制信息1  ，由于bmu没有主机所以没有发送
    { MASTER_CURR_SET_CMD          ,  FUNC_MASTER_CURR_SET_CMD            ,  inner_can_reply_msg_master_curr_set_cmd ,  inner_can_rx_master_curr_set_cmd    },     // BMS控制信息3-设置状态参数/电流
    { MASTER_BAL_SET_CMD           ,  FUNC_MASTER_BAL_SET_CMD             ,  inner_can_reply_msg_master_bal_set_cmd  ,  inner_can_rx_master_bal_set_cmd     },     // BMS控制信息4-均衡设置
    { HEART_BEAT_CMD               ,  FUNC_HEART_BEAT_CMD                 ,  inner_can_reply_msg_heart_beat_cmd      ,  inner_can_rx_msg_heart_beat_cmd     },     // 心跳帧
    { MASTER_PASS_BAL_SET_CMD      ,  FUNC_MASTER_PASS_BAL_SET_CMD        ,  NULL                                    ,  inner_can_rx_msg_master_pass_bal_set_cmd     },     // BMS设置被动均衡
    { MAS_OTHER_DATA_SET_CMD       ,  FUNC_MAS_OTHER_DATA_SET_CMD         ,  NULL                                    ,  inner_can_rx_msg_mas_other_data_set_cmd     },     // 主机其他信息设置，包括SOC放电末端校准使用，一般配合0x04C使用
    // ate设置告警
    { ATE_CELL_VOLT_OVER_ALM_SET   ,  FUNC_ATE_CELL_VOLT_OVER_ALM_SET     ,  inner_can_reply_msg_ate_cell_volt_over_alm_set   , inner_can_rx_ate_cell_volt_over_alm_set   },     // 单体过充故障参数标定
    { ATE_BAT_VOLT_OVER_ALM_SET    ,  FUNC_ATE_BAT_VOLT_OVER_ALM_SET      ,  inner_can_reply_msg_ate_bat_volt_over_alm_set    , inner_can_rx_ate_bat_volt_over_alm_set    },     // 总体过充故障参数标定
    { ATE_CELL_VOLT_UNDER_ALM_SET  ,  FUNC_ATE_CELL_VOLT_UNDER_ALM_SET    ,  inner_can_reply_msg_ate_cell_volt_under_alm_set  , inner_can_rx_ate_cell_volt_under_alm_set  },     // 单体过放故障参数标定
    { ATE_BAT_VOLT_UNDER_ALM_SET   ,  FUNC_ATE_BAT_VOLT_UNDER_ALM_SET     ,  inner_can_reply_msg_ate_bat_volt_under_alm_set   , inner_can_rx_ate_bat_volt_under_alm_set   },     // 总体过放故障参数标定
    { ATE_CHG_CURR_OVER_ALM_SET    ,  FUNC_ATE_CHG_CURR_OVER_ALM_SET      ,  inner_can_reply_msg_ate_chg_curr_over_alm_set    , inner_can_rx_ate_chg_curr_over_alm_set    },     // 充电过流故障参数标定
    { ATE_DCHG_CURR_OVER_ALM_SET   ,  FUNC_ATE_DCHG_CURR_OVER_ALM_SET     ,  inner_can_reply_msg_ate_dchg_curr_over_alm_set   , inner_can_rx_ate_dchg_curr_over_alm_set   },     // 放电过流故障参数标定
    { ATE_CELL_TEMP_OVER_ALM_SET   ,  FUNC_ATE_CELL_TEMP_OVER_ALM_SET     ,  inner_can_reply_msg_ate_cell_temp_over_alm_set   , inner_can_rx_ate_cell_temp_over_alm_set   },     // 充电高温故障参数标定
    { ATE_CELL_TEMP_UNDER_ALM_SET  ,  FUNC_ATE_CELL_TEMP_UNDER_ALM_SET    ,  inner_can_reply_msg_ate_cell_temp_under_alm_set  , inner_can_rx_ate_cell_temp_under_alm_set  },     // 放电高温故障参数标定
    { ATE_SOC_LOW_ALM_SET          ,  FUNC_ATE_SOC_LOW_ALM_SET            ,  inner_can_reply_msg_ate_soc_low_alm_set          , inner_can_rx_ate_soc_low_alm_set          },     // 低电量故障参数标定
    { ATE_BAT_CURR_OVER_ALM_2_SET  ,  FUNC_ATE_BAT_CURR_OVER_ALM_2_SET    ,  inner_can_reply_msg_ate_bat_curr_over_alm_2_set  , inner_can_rx_ate_bat_curr_over_alm_2_set  },     // 充放电二级故障参数标定
    { ATE_CELL_VOLT_ERR_ALM_SET    ,  FUNC_ATE_CELL_VOLT_ERR_ALM_SET      ,  inner_can_reply_msg_ate_cell_volt_err_alm_set    , inner_can_rx_ate_cell_volt_err_alm_set    },     // 单体超限超低故障参数标定
    { ATE_CELL_VOLT_TIP_SET        ,  FUNC_ATE_CELL_VOLT_TIP_SET          ,  inner_can_reply_msg_ate_cell_volt_tip_set        , inner_can_rx_msg_ate_cell_volt_tip_set    },     // 单体电压过充、过放提示标定
    { ATE_CELL_VOLT_DIFF_1_SET     ,  FUNC_ATE_CELL_VOLT_DIFF_1_SET       ,  inner_can_reply_msg_ate_cell_volt_diff_1_set     , inner_can_rx_msg_ate_cell_volt_diff_1_set },     // 单体电压压差过大提示、告警标定
    { ATE_CELL_VOLT_DIFF_2_SET     ,  FUNC_ATE_CELL_VOLT_DIFF_2_SET       ,  inner_can_reply_msg_ate_cell_volt_diff_2_set     , inner_can_rx_msg_ate_cell_volt_diff_2_set },     // 单体电压压差过大故障标定
    { ATE_CELL_TEMP_TIP_SET        ,  FUNC_ATE_CELL_TEMP_TIP_SET          ,  inner_can_reply_msg_ate_cell_temp_tip_set        , inner_can_rx_msg_ate_cell_temp_tip_set    },     // 电芯温度充放电高低温提示标定
    { ATE_CELL_TEMP_DIFF_SET       ,  FUNC_ATE_CELL_TEMP_DIFF_SET         ,  inner_can_reply_msg_ate_cell_temp_diff_set       , inner_can_rx_msg_ate_cell_temp_diff_set   },     // 电芯温差过大提示，告警、保护标定
    { ATE_BATT_VOLT_TIP_SET        ,  FUNC_ATE_BATT_VOLT_TIP_SET          ,  inner_can_reply_msg_ate_batt_volt_tip_set        , inner_can_rx_msg_ate_batt_volt_tip_set    },     // 总压过压欠压提示标定
    // ate设置其他控制和标定
    { ATE_FLASH_TEST               ,  FUNC_ATE_FLASH_TEST                 ,  inner_can_reply_msg_ate_flash_test               , inner_can_rx_ate_flash_test               },     // ATE_FLASH测试
    { ATE_SET_OLD_MODE             ,  FUNC_ATE_SET_OLD_MODE               ,  inner_can_reply_msg_ate_set_old_mode             , inner_can_rx_ate_set_old_mode             },     // 上位机控制老化状态
    { ATE_BAL_HEAT_PARAM_SET       ,  FUNC_ATE_BAL_HEAT_PARAM_SET         ,  inner_can_reply_msg_ate_bal_heat_param_set       , inner_can_rx_ate_bal_heat_param_set       },     // 均衡加热膜参数标定
    { ATE_CELL_VOLT_CURR_LIMIT_SET ,  FUNC_ATE_CELL_VOLT_CURR_LIMIT_SET   ,  inner_can_reply_msg_ate_cell_volt_curr_limit_set , inner_can_rx_ate_cell_volt_curr_limit_set },     // 截至电压电流参数标定
    { ATE_CELL_NUM_SET             ,  FUNC_ATE_CELL_NUM_SET               ,  inner_can_reply_msg_ate_cell_num_set             , inner_can_rx_ate_cell_num_set             },     // 额定容量电芯个数参数标定
    { ATE_CHG_DSG_CAP_SET          ,  FUNC_ATE_CHG_DSG_CAP_SET            ,  inner_can_reply_msg_ate_chg_dsg_cap_set          , inner_can_rx_ate_chg_dsg_cap_set          },     // 累计充放电电量参数标
    { ATE_SOX_SET                  ,  FUNC_ATE_SOX_SET                    ,  inner_can_reply_msg_ate_sox_set                  , inner_can_rx_ate_sox_set                  },     // SOX参数标
    { ATE_SYS_TIME_SET             ,  FUNC_ATE_SYS_TIME_SET               ,  inner_can_reply_msg_ate_sys_time_set             , inner_can_rx_ate_sys_time_set             },     // 时间标定
    { ATE_PACK_SN_SET              ,  FUNC_ATE_PACK_SN_SET                ,  inner_can_reply_msg_ate_pack_sn_set              , inner_can_rx_ate_pack_sn_set              },     // PACK_SN标定
    { ATE_BOARD_SN_SET             ,  FUNC_ATE_BOARD_SN_SET               ,  inner_can_reply_msg_ate_board_sn_set             , inner_can_rx_ate_board_sn_set             },     // BOARD_SN标定
    { ATE_CELL_INFO_SET            ,  FUNC_ATE_CELL_INFO_SET              ,  inner_can_reply_msg_ate_cell_info_set            , inner_can_rx_ate_cell_info_set            },     // 设置电池信息
    { ATE_CALI_PARAM_SET           ,  FUNC_ATE_CALI_PARAM_SET             ,  inner_can_reply_msg_ate_cali_param_set           , inner_can_rx_ate_cali_param_set           },     // 校准系数标定
    { ATE_BMU_FUNC_SET             ,  FUNC_ATE_BMU_FUNC_SET               ,  inner_can_reply_msg_ate_bmu_func_set             , inner_can_rx_ate_bmu_func_set             },     // BMU功能开关
    { ATE_MONITOR_DATA_READ        ,  FUNC_ATE_MONITOR_DATA_READ          ,  inner_can_reply_msg_ate_monitor_data_read        , inner_can_rx_ate_monitor_data_read        },     // 上位机监控读取
    { ATE_CLR_HISTORY_DATA         ,  FUNC_ATE_CLR_HISTORY_DATA           ,  inner_can_reply_msg_ate_clr_history_data         , inner_can_rx_ate_clr_history_data         },     // 一键清除历史故障
    { ATE_READ_SET_DATA            ,  FUNC_ATE_READ_SET_DATA              ,  inner_can_reply_msg_ate_read_set_data            , inner_can_rx_ate_read_set_data            },     // 一键操作标定参数
    { ATE_FORCE_CTL_SET            ,  FUNC_ATE_FORCE_CTL_SET              ,  inner_can_reply_msg_ate_force_ctl_set            , inner_can_rx_ate_force_ctl_set            },     // ATE强制控制指令
    { ATE_FORCE_CTL_SET_2          ,  FUNC_ATE_FORCE_CTL_SET_2            ,  inner_can_reply_msg_ate_force_ctl_set_2          , inner_can_rx_ate_force_ctl_set_2          },     // ATE强制控制指令2
    // 只有发送没有接收
    // 回复主机
    { SLAVER_CTL_REPLY             ,  FUNC_SLAVER_CTL_REPLY               ,  inner_can_reply_msg_slaver_ctl          ,  NULL                                },     // BMS回复信息2
    // bmu数据上报
    { BMS_INTER_INFO2              ,  FUNC_BMS_INTER_INFO2                ,  inner_can_tx_msg_bms_inter_info2        ,  NULL },     // BMS发送电池信息2
    { BMS_INTER_INFO3              ,  FUNC_BMS_INTER_INFO3                ,  inner_can_tx_msg_bms_inter_info3        ,  NULL },     // BMS发送电池信息3
    { BMS_INTER_INFO4              ,  FUNC_BMS_INTER_INFO4                ,  inner_can_tx_msg_bms_inter_info4        ,  NULL },     // BMS发送电池信息4
    { BMS_INTER_INFO5              ,  FUNC_BMS_INTER_INFO5                ,  inner_can_tx_msg_bms_inter_info5        ,  NULL },     // BMS发送电池信息5
    { BMS_FAULT_INFO1              ,  FUNC_BMS_FAULT_INFO1                ,  inner_can_tx_msg_bms_fault_info1        ,  NULL },     // BMS发送内部电池故障信息1
    { BMS_CELL_OTHER_INFO1         ,  FUNC_BMS_CELL_OTHER_INFO1           ,  inner_can_tx_msg_bms_cell_other_info1   ,  NULL },     // 其他信息
    { BMS_INTER_INFO6              ,  FUNC_BMS_INTER_INFO6                ,  inner_can_tx_msg_bms_inter_info6        ,  NULL },     // BMS发送电池信息6
    { BMS_INTER_INFO7              ,  FUNC_BMS_INTER_INFO7                ,  inner_can_tx_msg_bms_inter_info7        ,  NULL },     // BMS发送电池信息7
//    { BAL_TEMP_INFO1               ,  FUNC_BAL_TEMP_INFO1                 ,  inner_can_tx_msg_bal_temp_info1         ,  NULL },     // BMS均衡温度1-2
    { POWER_MOS_TEMP_INFO          ,  FUNC_POWER_MOS_TEMP_INFO            ,  inner_can_tx_msg_power_mos_temp_info    ,  NULL },     // BMS功率端子温度
    { BMS_FAULT_INFO2              ,  FUNC_BMS_FAULT_INFO2                ,  inner_can_tx_msg_bms_fault_info2        ,  NULL },     // BMS发送内部电池故障信息2
    { BMS_REMOTE_SIGNAL_INFO1      ,  FUNC_BMS_REMOTE_SIGNAL_INFO1        ,  inner_can_tx_msg_bms_remote_signal_info1,  NULL },     // 遥信数据上报1
    { BMS_REMOTE_SIGNAL_INFO2      ,  FUNC_BMS_REMOTE_SIGNAL_INFO2        ,  inner_can_tx_msg_bms_remote_signal_info2,  NULL },     // 遥信数据上报2
    { ACT_BAL_INFO1                ,  FUNC_ACT_BAL_INFO1                  ,  inner_can_tx_msg_act_bal_info1          ,  NULL },     // 主动均衡数据上报1
    { ACT_BAL_INFO2                ,  FUNC_ACT_BAL_INFO2                  ,  inner_can_tx_msg_act_bal_info2          ,  NULL },     // 主动均衡数据上报2
    { SOFT_VER_INFO1               ,  FUNC_SOFT_VER_INFO1                 ,  inner_can_tx_msg_soft_ver_info1         ,  NULL },     // 设备软件版信息1
    { SOFT_VER_INFO2               ,  FUNC_SOFT_VER_INFO2                 ,  inner_can_tx_msg_soft_ver_info2         ,  NULL },     // 设备软件版信息2
    { SOFT_VER_INFO3               ,  FUNC_SOFT_VER_INFO3                 ,  inner_can_tx_msg_soft_ver_info3         ,  NULL },     // 设备软件版信息3
    { BMS_REMOTE_SIGNAL_INFO3      ,  FUNC_BMS_REMOTE_SIGNAL_INFO3        ,  inner_can_tx_msg_bms_remote_signal_info3,  NULL },     // 其他数据上报
    { CELL_VOLT_OVERFLOW           ,  FUNC_CELL_VOLT_OVERFLOW             ,  inner_can_tx_msg_cell_volt_overflow     ,  NULL },     // 电芯电压
    { CELL_TEMP_OVERFLOW           ,  FUNC_CELL_TEMP_OVERFLOW             ,  inner_can_tx_msg_cell_temp_overflow     ,  NULL },     // 电芯温度
    { CELL_PASS_BAL_STATE_OVERFLOW ,  FUNC_CELL_PASS_BAL_STATE_OVERFLOW   ,  inner_can_tx_msg_cell_pass_bal_state_overflow,  NULL },     // 被动均衡状态
    { CELL_BAL_TEMP_OVERFLOW       ,  FUNC_CELL_BAL_TEMP_OVERFLOW         ,  inner_can_tx_msg_cell_bal_temp_overflow ,  NULL },     // 被动均衡温度
    { CELL_SOC_INFO                ,  FUNC_CELL_SOC_INFO                  ,  inner_can_tx_msg_bmu_soc_info           ,  NULL },     // 单电芯SOC
    { CELL_SOH_INFO                ,  FUNC_CELL_SOH_INFO                  ,  inner_can_tx_msg_bmu_soh_info           ,  NULL },     // 单电芯SOH
    { BMS_ALARM_TIPS_INFO3         ,  FUNC_BMS_ALARM_TIPS_INFO            ,  inner_can_tx_msg_bms_alarm_tips_info    ,  NULL },     // BMS发送内部电池故障信息3
    { MAS_OTHER_DATA_INFO          ,  FUNC_BMS_OTHER_DATA_INFO            ,  inner_can_tx_msg_mas_other_data_info    ,  NULL },     // 主机其他信息上报，包括SOC放电末端校准数据
    { ATE_TEST_INFO                ,  FUNC_ATE_TEST_INFO                  ,  inner_can_tx_msg_ate_test_result_info   ,  inner_can_tx_msg_ate_test_result_info },     // ATE测试结果上报，

};

const can_cycle_send_tcb_t g_can_msg_cycle_send_list[] =
{
    { CYCLE_MSG_YX_ID        ,PACK_REMOTE_COMM_DATA_SEND_REQ    , 10 , 50  , -1  },
    { CYCLE_MSG_CELL_VOLT_ID ,CELL_VOLT_MODULE_SEND_REQ         , 90 , 100 , -1  },
    { CYCLE_MSG_DEV_ID       ,DEV_INFO_MODULE_SEND_REQ          , 250 , 500 ,200 },
//    { CYCLE_MSG_YC1_ID       ,PACK_REMOTE_COLLECT_DATA1_SEND_REQ, 60 , 100 , -1  },
//    { CYCLE_MSG_YC2_ID       ,PACK_REMOTE_COLLECT_DATA2_SEND_REQ, 30 , 100 , -1  },
    { CYCLE_PACK_SN_ID       ,PACK_SN_DATA_SEND_REQ             , 20 , 500 , 200 },
    { CYCLE_BOARD_SN_ID      ,BOARD_SN_DATA_SEND_REQ             , 30 , 500 , 200 },
};



// can接受发数据
static uint8_t g_can_msg_list_len = sizeof(g_can_msg_list) / sizeof(g_can_msg_list[0]);
static uint8_t g_can_msg_cycle_send_list_len = sizeof(g_can_msg_cycle_send_list) / sizeof(g_can_msg_cycle_send_list[0]);
static uint16_t g_can_msg_cycle_cnt[CYCLE_MSG_CNT] = {0};
static uint16_t g_can_msg_cycle_first_flag[CYCLE_MSG_CNT] = {0};
static uint16_t g_can_msg_cycle_max_cnt[CYCLE_MSG_CNT] = {0};

static set_bmu_data g_set_bmu_data = {0};
static uint16_t g_can_send_ready_flag[CAN_SEND_READY_FLAG_NUM] = {0};
static uint16_t g_can_send_ate_ready_flag[CAN_SEND_READY_FLAG_NUM] = {0}; // 发送ate数据
// 全局标志
static uint8_t g_auto_send_data_enable = false;        //CAN网使能标志位
static cali_para_query_e g_cali_para_result = ATE_CALI_NON;
static uint8_t g_cali_data_type = 0;
static uint8_t g_cali_data_result = 0;

static electrolyte_sensor_info_t g_electrolyte_sensor_data = {0};

static bmu_yx_req_data_t  g_req_data = {0};

// bmu告警阈值同步参数
typedef enum
{
    BMU_THRE_SYNC_CELL_OVER_VOLT_ALM = 0,
    BMU_THRE_SYNC_BAT_OVER_VOLT_ALM,
    BMU_THRE_SYNC_CELL_UNDER_VOLT_ALM,
    BMU_THRE_SYNC_BAT_UNDER_VOLT_ALM,
    BMU_THRE_SYNC_CELL_TEMP_OVER_ALM,
    BMU_THRE_SYNC_CELL_TEMP_UNDER_ALM,
    BMU_THRE_SYNC_CELL_VOLT_TIP,
    BMU_THRE_SYNC_CELL_VOLT_DIFF1,
    BMU_THRE_SYNC_CELL_VOLT_DIFF2,
    BMU_THRE_SYNC_CELL_TEMP_TIP,
    BMU_THRE_SYNC_CELL_TEMP_DIFF,
    BMU_THRE_SYNC_BAT_VOLT_TIP,
    BMU_THRE_SYNC_ID_NUM,
}bmu_thre_sync_id_e;
static uint16_t g_bmu_thre_val_sync_flag = 0;

/**
* @brief                获取bmu遥信相关信息
* @param                [in]无
* @return               bmu_yx_req_data_t
* @retval               NULL获取失败
* @retval               ret(!NULL)获取成功
* @warning              无
*/
bmu_yx_req_data_t *get_bmu_yx_req_data(void)
{
    return &g_req_data;
}

// ate设置标定数据
static int8_t data_store_save_bms_attr_thre_val(set_thre_id_e thre_id, int32_t set_value)
{
    int8_t ret = -1;
    if (thre_id >= SET_THRE_CNT)
    {
        return ret;
    }
    uint16_t off_set = 0;
    if (thre_id < SET_THRE_ALM_VAL_END)
    {
        off_set = thre_id - SET_THRE_CELL_OVER_VOLT_PROT;
        off_set *= 4; // sizeof(int32_t)
        ret = data_store_save_bms_attr(ST_VAR_POS(bms_attr_t,safety) + off_set, (uint8_t *)(&set_value),ST_VAR_SIZE( safety_param_t, appear_value ) );
    }
    else if (thre_id < SET_THRE_OTHER_VAL_END)
    {
        uint16_t u16_set_value = set_value;
        off_set = thre_id - SET_THRE_BAL_VOL;
        off_set *= 2; // sizeof(int16_t)
        ret = data_store_save_bms_attr(ST_VAR_POS(bms_attr_t,bal_vol) + off_set, (uint8_t *)(&u16_set_value),ST_VAR_SIZE( bms_attr_t, bal_vol ) );
    }
    else
    {
        uint16_t u16_set_value = set_value;
        switch (thre_id)
        {
            case SET_THRE_ADD_CAP_CHG:
                ret = sox_stats_chg_ah_set(u16_set_value);
                break;
            case SET_THRE_ADD_CAP_DCHG:
                ret = sox_stats_dsg_ah_set(u16_set_value);
                break;
            case SET_THRE_SOC:
                ret = soc_calc_val_set(PACK_IS_SELED, u16_set_value);
                break;
            case SET_THRE_SOH:
                ret = soh_calc_val_set(PACK_IS_SELED, u16_set_value);
                break;
            default:
                break;
        }
    }
    return ret;
}

/*******************************************************************************
* Function Name  : Crc8_8210_nBytesCalculate
* Description    : CRC校验,多项式为0x2F
* Input          :
* Output         : None
* Return         : None
*******************************************************************************/
uint8_t crc8_8210_nbytes_calculate(uint8_t *p_buff , uint8_t len , uint8_t crs_mask)
{
    uint8_t i;
    for ( ; len > 0 ; len--)
    {
        for (i = 0x80 ; i > 0 ; i >>= 1)
        {
            if(0 != (crs_mask & 0x80))
            {
                crs_mask <<= 1;
                crs_mask ^= 0x2F;
            }
            else
            {
                crs_mask <<= 1;
            }
            if(0 != (*p_buff & i))
            {
                crs_mask ^= 0x2F;
            }
        }
        p_buff ++;
    }
    return crs_mask;
}

// 计算canId以及data0-6的数据crc8
uint8_t can_single_frame_crc8_calc(can_frame_data_t *can_data, uint8_t crs_mask)
{
#define SINGLE_CAN_FRAME_CRC_DATA_LEN  (11)
    uint8_t crc_data[SINGLE_CAN_FRAME_CRC_DATA_LEN] = {0};  // canid + data0-6 共11个字节
    crc_data[0] = can_data->id & 0xFF;
    crc_data[1] = (can_data->id >> 8) & 0xFF;
    crc_data[2] = (can_data->id >> 16) & 0xFF;
    crc_data[3] = (can_data->id >> 24) & 0xFF;
    crc_data[4] = can_data->data[0];
    crc_data[5] = can_data->data[1];
    crc_data[6] = can_data->data[2];
    crc_data[7] = can_data->data[3];
    crc_data[8] = can_data->data[4];
    crc_data[9] = can_data->data[5];
    crc_data[10] = can_data->data[6];
    return crc8_8210_nbytes_calculate(crc_data, SINGLE_CAN_FRAME_CRC_DATA_LEN, crs_mask);
}

// 立即发送
bool inner_can_send_msg_no_ready(can_frame_data_t *can_data, frame_data_id_e id)
{
    if (g_can_msg_list_len <= id || NULL == can_data)
    {
        return false;
    }
    uint8_t list_id = g_can_msg_list_len;
    if (g_can_msg_list[id].id == id)
    {
        list_id = id;
    }
    else
    {
        for (uint8_t list_cnt = 0; list_cnt < g_can_msg_list_len; list_cnt++)
        {
            if (g_can_msg_list[list_cnt].id == id)
            {
                list_id = list_cnt;
                log_e("[can]Err Cnt%d,id%d\n", list_cnt, id);
                break;
            }
        }
    }
    // 无法匹配id，退出
    if (list_id == g_can_msg_list_len)
    {
        return false;
    }
    if (NULL != g_can_msg_list[id].p_func_send_deal_cb)
    {
        g_can_msg_list[id].p_func_send_deal_cb(can_data, g_can_msg_list[id].func_code);
    }
    else // 无发送任务，报出异常
    {
        log_e("list%d cb_null\n",id);
    }
    return true;
}

// 请求发送can数据帧
// 由于是延迟处理，无法知道是主机还是上位机发送，
// 所以只用于循环发送，和外部模块请求发送,默认BCU，0x01为目的地址
void inner_can_send_msg_ready(frame_data_id_e send_id)
{
    if (send_id >= INNER_MSG_CNT)
    {
        return;
    }
    uint8_t ready_flag_group_id = send_id / UINT16_BIT_NUM;
    uint8_t ready_flag_id = send_id % UINT16_BIT_NUM;
    g_can_send_ready_flag[ready_flag_group_id] |= (1 << ready_flag_id);
}

// 请求发送can数据帧
// 由于是延迟处理，无法知道是主机还是上位机发送，
// 所以只用于循环发送，和外部模块请求发送,默认上位机，0xE0为目的地址
void inner_can_send_ate_msg_ready(frame_data_id_e send_id)
{
    if (send_id >= INNER_MSG_CNT)
    {
        return;
    }
    uint8_t ready_flag_group_id = send_id / UINT16_BIT_NUM;
    uint8_t ready_flag_id = send_id % UINT16_BIT_NUM;
    g_can_send_ate_ready_flag[ready_flag_group_id] |= (1 << ready_flag_id);
}

/**
* @brief    发送can帧数据
* @param    [in]can_data        使用数据的源类型，源地址，用于发送的目的地址和类型
* @param    [in]id              用于寻找id，填充数据内用
* @param    [in]is_ready_flag   true：延迟发送，默认目的地址BCU，地址为0x01    false: 立即发送
* @warning  无
*/
void inner_can_send_msg(can_frame_data_t *can_data, frame_data_id_e id, bool is_ready_flag)
{
    if (is_ready_flag)
    {
        can_frame_id_u frame_rx_id = {can_data->id};
        if (frame_rx_id.bit.src_type == DEV_BROADCAST && frame_rx_id.bit.src_addr == 0)
        {
            inner_can_send_ate_msg_ready(id);
        }
        else
        {
            inner_can_send_msg_ready(id);
        }
    }
    else
    {
        inner_can_send_msg_no_ready(can_data, id);
    }
}

/**
* @brief    根据模块划分发送数据
* @param    [in]can_data        使用数据的源类型，源地址，用于发送的目的地址和类型
* @param    [in]id              用于寻找id，填充数据内用
* @param    [in]is_ready_flag   true：延迟发送，默认目的地址BCU，地址为0x01    false: 立即发送
* @warning  无
*/
void module_inner_can_send_msg(can_frame_data_t *can_data, module_request_send_group_e group_id, bool is_ready_flag)
{
    if (NO_MODULE_SEND_REQ == group_id || group_id >= MODULE_REQ_SEND_REQ_NUM ||
        NULL == can_data)
    {
        return;
    }

    if (PACK_REMOTE_COMM_DATA_SEND_REQ == group_id)           // 发送频繁放在第一位
    {
        inner_can_send_msg(can_data, BMS_FAULT_INFO1, is_ready_flag);
        inner_can_send_msg(can_data, BMS_FAULT_INFO2, is_ready_flag);
        inner_can_send_msg(can_data, BMS_ALARM_TIPS_INFO3, is_ready_flag);
        inner_can_send_msg(can_data, BMS_REMOTE_SIGNAL_INFO1, is_ready_flag);
        inner_can_send_msg(can_data, BMS_REMOTE_SIGNAL_INFO2, is_ready_flag);    
        inner_can_send_msg(can_data, MAS_OTHER_DATA_INFO, is_ready_flag);        
    }
    else if (PACK_REMOTE_COLLECT_DATA1_SEND_REQ == group_id)
    {
        inner_can_send_msg(can_data, BMS_INTER_INFO2, is_ready_flag);
        inner_can_send_msg(can_data, BMS_INTER_INFO3, is_ready_flag);
        inner_can_send_msg(can_data, BMS_INTER_INFO4, is_ready_flag);
        inner_can_send_msg(can_data, BMS_INTER_INFO5, is_ready_flag);
    }
    else if (PACK_REMOTE_COLLECT_DATA2_SEND_REQ == group_id)
    {
        inner_can_send_msg(can_data, BMS_CELL_OTHER_INFO1, is_ready_flag);
        inner_can_send_msg(can_data, BMS_INTER_INFO6, is_ready_flag);
        inner_can_send_msg(can_data, BMS_INTER_INFO7, is_ready_flag);
        inner_can_send_msg(can_data, POWER_MOS_TEMP_INFO, is_ready_flag);
        inner_can_send_msg(can_data, CELL_PASS_BAL_STATE_OVERFLOW, is_ready_flag);
    }
    else if (CELL_VOLT_MODULE_SEND_REQ == group_id)
    {
        inner_can_send_msg(can_data, CELL_VOLT_OVERFLOW, is_ready_flag);
    }
    else if (CELL_TEMP_MODULE_SEND_REQ == group_id)
    {
        inner_can_send_msg(can_data, CELL_TEMP_OVERFLOW, is_ready_flag);
    }
    else if (CELL_SOC_MODULE_SEND_REQ == group_id)
    {
        inner_can_send_msg(can_data, CELL_SOC_INFO, is_ready_flag);
    }
    else if (BAL_MODULE_DATA_SEND_REQ == group_id)
    {
        inner_can_send_msg(can_data, CELL_BAL_TEMP_OVERFLOW, is_ready_flag);
        inner_can_send_msg(can_data, ACT_BAL_INFO1, is_ready_flag);
        inner_can_send_msg(can_data, ACT_BAL_INFO2, is_ready_flag);
    }
    else if (CELL_SOH_MODULE_SEND_REQ == group_id)
    {
        inner_can_send_msg(can_data, CELL_SOH_INFO, is_ready_flag);
    }
    else if (DEV_INFO_MODULE_SEND_REQ == group_id)
    {
        inner_can_send_msg(can_data, SOFT_VER_INFO1, is_ready_flag);
        inner_can_send_msg(can_data, SOFT_VER_INFO2, is_ready_flag);
        inner_can_send_msg(can_data, SOFT_VER_INFO3, is_ready_flag);
    }
    else if (PACK_SN_DATA_SEND_REQ == group_id)
    {
        inner_can_send_msg(can_data, ATE_PACK_SN_SET, is_ready_flag);
    }
    else if (BOARD_SN_DATA_SEND_REQ == group_id)
    {
        inner_can_send_msg(can_data, ATE_BOARD_SN_SET, is_ready_flag);
    }
    else if (ATE_MODULE_DATA_SEND_REQ == group_id)
    {
        inner_can_send_msg(can_data, BMS_REMOTE_SIGNAL_INFO3, is_ready_flag);
    }
}

/**
* @brief    根据功能码请求发送数据
* @param    [in]can_data       使用数据的源类型，源地址，用于发送的目的地址和类型
* @param    [in]func_code      设置的功能码
* @warning  无
*/
void func_inner_can_send_msg(can_frame_data_t *can_data, uint8_t func_code)
{
    can_frame_id_u can_id = {0};
    if (can_data == NULL)
    {
        return ;
    }
    if (0x01 == func_code) // 发送全部
    {
        for(uint8_t i = BMS_INTER_INFO2; i <= MAS_OTHER_DATA_INFO; i++) //其实这里i和下面的g_can_msg_list[i].id是同样的定义
        {
            inner_can_send_ate_msg_ready((frame_data_id_e)g_can_msg_list[i].id);            
        }
        return;
    }
    // 根据功能码发送
    for (uint8_t i = 0; i < g_can_msg_list_len; i++)
    {
        if (g_can_msg_list[i].func_code == func_code)
        {
            can_id.id_val = can_data->id;
            if(can_id.bit.src_type == DEV_BROADCAST)
            {
                inner_can_send_ate_msg_ready((frame_data_id_e)g_can_msg_list[i].id);                
            }
            else
            {
                inner_can_send_msg_ready((frame_data_id_e)g_can_msg_list[i].id);                
            }

            break;
        }
    }
}

/**
* @brief        canid数据转换
* @param        *tx_id：需要发送的canid，需要填充
* @param        rx_id：接收的canid
* @param        func_code：发送的功能码
* @return       执行结果
*/
static void can_id_dst_addr_fill(can_frame_id_u *tx_id, can_frame_id_u rx_id, uint16_t func_code)
{
    if (tx_id == NULL)
    {
        return;
    }
    tx_id->bit.src_addr = auto_addressing_get_address();
    tx_id->bit.src_type = DEV_BMU;
    tx_id->bit.dst_addr = rx_id.bit.src_addr;
    tx_id->bit.dst_type = rx_id.bit.src_type;
//    tx_id->bit.dst_addr = 0x1F;  Test
//    tx_id->bit.dst_type = 0x7;
    tx_id->bit.fun_code = func_code;
    tx_id->bit.prio = SOFAR_CAN_PRI_LOW_H;
}

// 填充发送数据
// 使用注意，不要越界，fill_data + fill_len 不能超过数组长度
static void fill_can_data_buff(uint32_t fill_data, uint8_t *fill_buff, uint8_t fill_len)
{
    if (NULL == fill_buff ||  (2 != fill_len && 4 != fill_len)) // 不是两个字节&&不是4个字节，认为异常
    {
        return ;
    }
    for (uint8_t i = 0; i < fill_len; i++)
    {
        fill_buff[i] = (uint8_t)(fill_data >> (i * 8));
    }
}

// 0x002:BMS回复信息2
static bool inner_can_reply_msg_slaver_ctl(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    data[0] = (uint8_t)(auto_addressing_get_address());
    data[1] = slave_addr_proc_state_get();
    data[2] = 0;  //  休眠请求，(CBS5K无此功能)
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x060:BMS控制信息3-回复状态参数/电流
static bool inner_can_reply_msg_master_curr_set_cmd(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    fill_can_data_buff(g_set_bmu_data.set_curr, &data[0], WORD_SIZE);
    can_bat_status_u bat_sta = g_set_bmu_data.set_bat_sta;
    bat_sta.bit.bat_sta = bms_state_get_bat_sta();
    bat_sta.bit.shut_down_sta = bmu_shut_down_get(0);
    data[2] = bat_sta.all;
    data[3] = g_set_bmu_data.set_sync_fall_soc;
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x061:BMS控制信息4-回复均衡设置
static bool inner_can_reply_msg_master_bal_set_cmd(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    data[0] = g_set_bmu_data.set_act_bal_ctl;
    fill_can_data_buff(g_set_bmu_data.set_bal_status, &data[1], WORD_SIZE);
    fill_can_data_buff(g_set_bmu_data.set_bal_min_cell_soc, &data[3], WORD_SIZE);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}
// 0x062: 心跳帧发送
static bool  inner_can_reply_msg_heart_beat_cmd(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u tx_can_frame = {0};
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};

    tx_can_frame.bit.src_type = DEV_BMU;
    tx_can_frame.bit.src_addr = auto_addressing_get_address();
    tx_can_frame.bit.dst_type = DEV_BROADCAST;
    tx_can_frame.bit.dst_addr = BROADCAST_DEVICE_ADDRESS;
    tx_can_frame.bit.fun_code = func_code;
    tx_can_frame.bit.prio     = SOFAR_CAN_PRI_LOW_H;
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}
// 0x004:BMS发送电池信息2
static bool inner_can_tx_msg_bms_inter_info2(can_frame_data_t *can_data, uint16_t func_code)
{
    const bmu_data_t* p_bmu_data = bmu_data_p_get();
    const sox_data_t* sox_data = sox_data_get_deal();
    if (NULL == p_bmu_data)
    {
        return 0;
    }
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    uint16_t data_tmp = 0;

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    data_tmp = (U32_INVALID_VALUE == p_bmu_data->bat_acc_volt) ? (U16_INVALID_VALUE) : (p_bmu_data->bat_acc_volt / 100);
    fill_can_data_buff(data_tmp, &data[0], WORD_SIZE);  // 单位0.1V

    data[2] = 0; // 无负载电压
    data[3] = 0; // 无负载电压
    fill_can_data_buff(p_bmu_data->sys_current / 10, &data[4], WORD_SIZE);  // 单位0.1V
    if (NULL != sox_data)
    {
        data_tmp = sox_data->display_soc * 10;
    }
    else
    {
        data_tmp = U16_INVALID_DATA;
    }
    fill_can_data_buff(data_tmp, &data[6], WORD_SIZE);  // 单位 0.1%
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x005:BMS发送电池信息3
static bool inner_can_tx_msg_bms_inter_info3(can_frame_data_t *can_data, uint16_t func_code)
{
    const bmu_data_t* p_bmu_data = bmu_data_p_get();
    if (NULL == p_bmu_data)
    {
        return 0;
    }
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    fill_can_data_buff(p_bmu_data->max_cell_volt, &data[0], WORD_SIZE);  // 单位mV
    data[2] = p_bmu_data->max_volt_num;
    fill_can_data_buff(p_bmu_data->min_cell_volt, &data[3], WORD_SIZE);  // 单位mV
    data[5] = p_bmu_data->min_volt_num;
    fill_can_data_buff(p_bmu_data->avg_cell_volt, &data[6], WORD_SIZE);  // 单位mV
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x006:BMS发送电池信息4
static bool inner_can_tx_msg_bms_inter_info4(can_frame_data_t *can_data, uint16_t func_code)
{
    const bmu_data_t* p_bmu_data = bmu_data_p_get();
    if (NULL == p_bmu_data)
    {
        return 0;
    }
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    fill_can_data_buff(p_bmu_data->max_cell_temp, &data[0], WORD_SIZE);  //  单位0.1℃
    data[2] = p_bmu_data->max_temp_num;
    fill_can_data_buff(p_bmu_data->min_cell_temp, &data[3], WORD_SIZE);  //  单位0.1℃
    data[5] = p_bmu_data->min_temp_num;
    fill_can_data_buff(p_bmu_data->avg_cell_temp, &data[6], WORD_SIZE);  //  单位0.1℃   
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x007:BMS发送电池信息5
static bool inner_can_tx_msg_bms_inter_info5(can_frame_data_t *can_data, uint16_t func_code)
{
    const sox_data_t* sox_data = sox_data_get_deal();

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0x00};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);
    if (NULL != sox_data)
    {
        fill_can_data_buff(sox_data->total_chg_ah * 1000, &data[0], DWORD_SIZE);  //  单位1Ah转化为0.001Ah
        fill_can_data_buff(sox_data->total_dsg_ah * 1000, &data[4], DWORD_SIZE);  //  单位1Ah转化为0.001Ah
    }
    else
    {
        fill_can_data_buff(U32_INVALID_VALUE, &data[0], DWORD_SIZE);  //  单位Ah
        fill_can_data_buff(U32_INVALID_VALUE, &data[4], DWORD_SIZE);  //  单位Ah
    }
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x008:BMS发送内部电池故障信息1
static bool inner_can_tx_msg_bms_fault_info1(can_frame_data_t *can_data, uint16_t func_code)
{
    const fault_info_t *p_fault_info = get_fault_info();
    if (NULL == p_fault_info)
    {
        return 0;
    }
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    data[0] = p_fault_info->fault_info1.byte0.byte;
    data[1] = p_fault_info->fault_info1.byte1.byte;
    data[2] = p_fault_info->fault_info1.byte2.byte;
    data[3] = p_fault_info->fault_info1.byte3.byte;
    data[4] = p_fault_info->fault_info1.byte4.byte;
    data[5] = p_fault_info->fault_info1.byte5.byte;
    data[6] = p_fault_info->fault_info1.byte6.byte;
    data[7] = p_fault_info->fault_info1.byte7.byte;
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x00E：其他信息
static bool inner_can_tx_msg_bms_cell_other_info1(can_frame_data_t *can_data, uint16_t func_code)
{
    const bmu_data_t* p_bmu_data = bmu_data_p_get();
    const sox_data_t* sox_data = sox_data_get_deal();
    if (NULL == p_bmu_data)
    {
        return 0;
    }
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    uint16_t data_tmp = 0;

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    fill_can_data_buff(p_bmu_data->adc_sample_other_temp[OTHER_ENV_NTC], &data[2], WORD_SIZE);  // pcb温度 单位0.1°
    if (NULL != sox_data)
    {
        data_tmp = (uint16_t)sox_data->display_soh*10; // 此处上报的显示值，云平台要求0.1的精度
    }
    else
    {
        data_tmp = U16_INVALID_DATA;
    }
    fill_can_data_buff(data_tmp, &data[4], WORD_SIZE);  //  SOH 单位0.1%
//    data_tmp = cell_balance_pos_get();
//    fill_can_data_buff(data_tmp, &data[6], WORD_SIZE);  //  被动均衡状态
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x00F：BMS发送电池信息6
static bool inner_can_tx_msg_bms_inter_info6(can_frame_data_t *can_data, uint16_t func_code)
{
    const sox_data_t* sox_data = sox_data_get_deal();

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0x00};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    uint16_t data_tmp = 0;

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);
    if (NULL != sox_data)
    {
        data_tmp = sox_data->remained_cap * 10; //   单位0.1AH
        fill_can_data_buff(data_tmp, &data[0], WORD_SIZE);
        data_tmp = sox_data->real_cap * 10; //   单位0.1AH
        fill_can_data_buff(data_tmp, &data[2], WORD_SIZE);
        data_tmp = sox_data->cycle_count / 100; //   单位1圈
        fill_can_data_buff(data_tmp, &data[4], WORD_SIZE);
    }
    else
    {
        fill_can_data_buff(U16_INVALID_VALUE, &data[0], WORD_SIZE);
        fill_can_data_buff(U16_INVALID_VALUE, &data[2], WORD_SIZE);
        fill_can_data_buff(U16_INVALID_VALUE, &data[4], WORD_SIZE);

    }
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x040：BMS发送电池信息7
static bool inner_can_tx_msg_bms_inter_info7(can_frame_data_t *can_data, uint16_t func_code)
{
    const sox_data_t* sox_data = sox_data_get_deal();
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0x00};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);
    if (NULL != sox_data)
    {
        fill_can_data_buff(sox_data->total_dsg_wh, &data[0], DWORD_SIZE); //  单位wh
        fill_can_data_buff(sox_data->total_chg_wh, &data[4], DWORD_SIZE); //  单位wh
    }
    else
    {
        fill_can_data_buff(U32_INVALID_VALUE, &data[0], DWORD_SIZE); //  单位wh
        fill_can_data_buff(U32_INVALID_VALUE, &data[4], DWORD_SIZE); //  单位wh
    }
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x041：BMS均衡温度1-2
//static bool inner_can_tx_msg_bal_temp_info1(can_frame_data_t *can_data, uint16_t func_code)
//{
//    const bmu_data_t* p_bmu_data = bmu_data_p_get();
//    if (NULL == p_bmu_data)
//    {
//        return 0;
//    }
//    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
//    can_frame_id_u rx_can_frame = {can_data->id};
//    can_frame_id_u tx_can_frame = {0};

//    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);
//    fill_can_data_buff(p_bmu_data->adc_sample_other_temp[OTHER_BAL_RES_NTC1], &data[0], WORD_SIZE); //  被动均衡温度1 单位0.1°
//    fill_can_data_buff(p_bmu_data->adc_sample_other_temp[OTHER_BAL_RES_NTC2], &data[2], WORD_SIZE); //  被动均衡温度2 单位0.1°
//    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
//    return 0;
//}

// 0x04A：BMS功率端子温度
static bool inner_can_tx_msg_power_mos_temp_info(can_frame_data_t *can_data, uint16_t func_code)
{
    const bmu_data_t* p_bmu_data = bmu_data_p_get();
    if (NULL == p_bmu_data)
    {
        return 0;
    }
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);
    fill_can_data_buff(p_bmu_data->adc_sample_other_temp[OTHER_POWER_NTC1], &data[0], WORD_SIZE); //  功率温度1 单位0.1°
    fill_can_data_buff(p_bmu_data->adc_sample_other_temp[OTHER_POWER_NTC2], &data[2], WORD_SIZE); //  功率温度2 单位0.1°
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x045:BMS发送内部电池故障信息2
static bool inner_can_tx_msg_bms_fault_info2(can_frame_data_t *can_data, uint16_t func_code)
{
    const fault_info_t *p_fault_info = get_fault_info();
    if (NULL == p_fault_info)
    {
        return 0;
    }
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    data[0] = p_fault_info->fault_info2.byte0.byte;
    data[1] = p_fault_info->fault_info2.byte1.byte;
    data[2] = p_fault_info->fault_info2.byte2.byte;
    data[3] = p_fault_info->fault_info2.byte3.byte;
    data[4] = p_fault_info->fault_info2.byte4.byte;
    data[5] = p_fault_info->fault_info2.byte5.byte;
    data[6] = p_fault_info->fault_info2.byte6.byte;
    data[7] = p_fault_info->fault_info2.byte7.byte;
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

#define THRE_VAL_SYNC_FLAG  0x0fff  //和需要接收的阈值，后续如果扩展了，这里也要改
#define THRE_VAL_SYNC_FLAG_CLR_CNT  30 //15S清空一次阈值同步标志，500mS发一次数据
// 0x046：遥信数据上报1
static bool inner_can_tx_msg_bms_remote_signal_info1(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_frame_data_t tx_frame_data = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    static uint8_t thre_val_sync_flag_clr = 0;
    // charge enable
    if (false == fault_protect_action_get(LIMIT_CHARGE_CURRENT) &&
        false == public_flag_state_get(CHG_FULL_FLAG))
    {
        g_req_data.req.bits.chg_enale = 1;
    }
    else
    {
        g_req_data.req.bits.chg_enale = 0;
    }
    // discharge enable
    if (false == fault_protect_action_get(LIMIT_DISCHARGE_CURRENT) &&
        false == public_flag_state_get(DISCHG_EMPTY_FLAG))
    {
        g_req_data.req.bits.dsg_enale = 1;
    }
    else
    {

        g_req_data.req.bits.dsg_enale = 0;
    }
    //bmu cut off request
    if (bmu_cut_off_request_get())
    {
        g_req_data.req.bits.bmu_cut_off_req = 1;
    }
    else
    {
        g_req_data.req.bits.bmu_cut_off_req = 0;
    }
    //bmu pow off request
    if (bmu_pow_off_request_get())
    {
        g_req_data.req.bits.bmu_pow_off_req = 1;
    }
    else
    {
        g_req_data.req.bits.bmu_pow_off_req = 0;
    }
    //bmu force request 强充请求
    if (public_flag_state_get(FORCE_CHG_FLAG))
    {
        g_req_data.req.bits.force_chg_req = 1;
    }
    else
    {
        g_req_data.req.bits.force_chg_req = 0;
    }
    
    // bmu 告警阈值接收完成
    if (g_bmu_thre_val_sync_flag == THRE_VAL_SYNC_FLAG)
    {
        g_req_data.req.bits.thre_val_sync_finish = 1; //接收完成(15S后清空标志)
    }
    else
    {
        g_req_data.req.bits.thre_val_sync_finish = 0; //接收未完成/未启动
    }
    
    if(g_bmu_thre_val_sync_flag != 0)   //有接收到阈值变更报文
    {
        if(++thre_val_sync_flag_clr >= THRE_VAL_SYNC_FLAG_CLR_CNT)
        {
            thre_val_sync_flag_clr = 0;
            g_bmu_thre_val_sync_flag = 0;
        }        
    }

    

    // 满充标志
    if(true == public_flag_state_get(CHG_FULL_FLAG))
    {
        g_req_data.state.bits.full_chg = 1;
    }
    else
    {
        g_req_data.state.bits.full_chg = 0;
    }
    // 放亏标志
    if(true == public_flag_state_get(DISCHG_EMPTY_FLAG))
    {
        g_req_data.state.bits.empty_dsg = 1;
    }
    else
    {
        g_req_data.state.bits.empty_dsg = 0;
    }
    tx_frame_data.id = tx_can_frame.id_val;
    tx_frame_data.data[0] = g_req_data.req.byte;
    tx_frame_data.data[1] = g_req_data.req2.byte;
    tx_frame_data.data[2] = g_req_data.state.byte;

    
    tx_frame_data.data[6] = bmu_di_state_get();  //  di状态，兼容默认5V输出的编址方式，当已编址为1，则把addr_di反馈为低，让bcu能接着往下编址；
    if (1 == auto_addressing_get_address())
    {
        tx_frame_data.data[6] &= 0xfe;
    }
    
    // 填充crc
    tx_frame_data.data_len = CAN_MAX_DATA_LEN_ONE_FRAME;
    tx_frame_data.data[7] = can_single_frame_crc8_calc(&tx_frame_data, MASTER_CTL_SET_CRC8_MASK);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_frame_data.id, tx_frame_data.data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x047：遥信数据上报2
static bool inner_can_tx_msg_bms_remote_signal_info2(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    uint16_t data_tmp = 0;

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    // 同步下降soc
    // 需要做获取同步下降SOC的接口，注意该接口中需要将默认（无效）值设置为0，以和BCU相匹配
    data[0] = sox_set_bmu_soc();

    data[1] = bms_state_get_sys_sta(); // bmu状态
    //电池包主动均衡状态
    data[3] = 0; // 加热请求 无
    power_limit_t sop_limit_data = sop_limit_value_get_deal();
    //电池包充电电流上限
    data_tmp = sop_limit_data.chg_curr_limit * 100;  // 单位A转换为10mA
    fill_can_data_buff(data_tmp, &data[4], WORD_SIZE);
    //电池包放电电流上限
    data_tmp = sop_limit_data.dsg_curr_limit * 100;  // 单位A转换为10mA
    fill_can_data_buff(data_tmp, &data[6], WORD_SIZE);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x048：主动均衡数据上报1
static bool inner_can_tx_msg_act_bal_info1(can_frame_data_t *can_data, uint16_t func_code)
{

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
//    uint16_t data_tmp = 0;

//    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

//    fill_can_data_buff(data_tmp, &data[0], WORD_SIZE);

//    fill_can_data_buff(data_tmp, &data[2], WORD_SIZE);

//    fill_can_data_buff(data_tmp, &data[4], WORD_SIZE);

//    fill_can_data_buff(data_tmp, &data[6], WORD_SIZE);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x049：主动均衡数据上报2
static bool inner_can_tx_msg_act_bal_info2(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x06A：设备软件版信息1
#define AsciiToInt 0x30
static bool inner_can_tx_msg_soft_ver_info1(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    uint16_t data_tmp = 0;
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    data[0] = SOFTWARE_VERSION[0]; // V/T
    data[1] = ((uint8_t)(SOFTWARE_VERSION[1] - AsciiToInt)*10) + (SOFTWARE_VERSION[2] - AsciiToInt);// *10转成十位数
    data[2] = ((uint8_t)(SOFTWARE_VERSION[3] - AsciiToInt)*10) + (SOFTWARE_VERSION[4] - AsciiToInt);
    data[3] = ((uint8_t)(SOFTWARE_VERSION[5] - AsciiToInt)*10) + (SOFTWARE_VERSION[6] - AsciiToInt);
    data[4] = (uint8_t)(hardware_ver_get());
    data_tmp = ((uint16_t)(CAN_VERSION[1]) << 8) + CAN_VERSION[0];
    fill_can_data_buff(data_tmp, &data[5], WORD_SIZE);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x06B：设备软件版信息3
static bool inner_can_tx_msg_soft_ver_info2(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    uint16_t data_tmp = 0;
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    data_tmp = get_bms_attr()->rate_cap;
    fill_can_data_buff(data_tmp, &data[0], WORD_SIZE);
    data_tmp = 0; // AMASS
    fill_can_data_buff(data_tmp, &data[2], WORD_SIZE);
    data_tmp = 0; // 0-磷酸铁锂
    fill_can_data_buff(data_tmp, &data[4], WORD_SIZE);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x06C：设备软件版信息4
static bool inner_can_tx_msg_soft_ver_info3(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    uint16_t data_tmp = 0;
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    char manu_name[8] = {"SOFAR"};
    data_tmp = ((uint16_t)(manu_name[1]) << 8) + manu_name[0];
    fill_can_data_buff(data_tmp, &data[0], WORD_SIZE);
    data_tmp = ((uint16_t)(manu_name[3]) << 8) + manu_name[2];
    fill_can_data_buff(data_tmp, &data[2], WORD_SIZE);
    data_tmp = ((uint16_t)(manu_name[5]) << 8) + manu_name[4];
    fill_can_data_buff(data_tmp, &data[4], WORD_SIZE);
    data_tmp = ((uint16_t)(manu_name[7]) << 8) + manu_name[6];
    fill_can_data_buff(data_tmp, &data[6], WORD_SIZE);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x06D：其他数据上报
static bool inner_can_tx_msg_bms_remote_signal_info3(can_frame_data_t *can_data, uint16_t func_code)
{
    const bmu_data_t* p_bmu_data = bmu_data_p_get();
    if (NULL == p_bmu_data)
    {
        return 0;
    }
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    fill_can_data_buff(p_bmu_data->check_24v_volt, &data[0], WORD_SIZE);
    data[6] = sdk_cpu_reset_flag_get();
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x1070:电芯的电芯电压new
#define ONE_FRAME_CELL_VOLT_NUM_OVERFLOW 3
#define ONE_PACKAGE_CELL_VOLT_NUM        64
#define ONE_PACKAGE_FRAME_NUM            22
static bool inner_can_tx_msg_cell_volt_overflow(can_frame_data_t *can_data, uint16_t func_code)
{
    const bmu_data_t* p_bmu_data = bmu_data_p_get();
    if (NULL == p_bmu_data)
    {
        return 0;
    }
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    uint8_t package_no = 1;
    uint16_t cell_id = (package_no - 1) * ONE_PACKAGE_CELL_VOLT_NUM;
    uint8_t send_frame_num = 0;
    
    data[1] = package_no;
    uint8_t send_num = 0;
    uint16_t cluster_max_temp_sub_frame = CELL_VOLT_NUM - ONE_FRAME_CELL_VOLT_NUM_OVERFLOW;
    while (send_frame_num < ONE_PACKAGE_FRAME_NUM)
    {
        send_frame_num++;
        data[0] = send_frame_num;
        if (cell_id <= cluster_max_temp_sub_frame)
        {
            send_num = ONE_FRAME_CELL_VOLT_NUM_OVERFLOW;
        }
        else
        {
            memset(&data[2], 0xFF, 6);
            if (cell_id >= CELL_VOLT_NUM)
            {
                send_num = 0;
                break;
            }
            else
            {
                send_num = CELL_VOLT_NUM % ONE_FRAME_CELL_VOLT_NUM_OVERFLOW;
            }
        }
        for (uint8_t i = 0; i < send_num; i++)
        {
            data[2 + i * 2] = LOW_BYTE(p_bmu_data->cell_volt[cell_id + i]);
            data[3 + i * 2] = HIGH_BYTE(p_bmu_data->cell_volt[cell_id + i]);
        }
        can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
        cell_id += ONE_FRAME_CELL_VOLT_NUM_OVERFLOW;
    }
    return 0;
}

// 0x1071:电芯的电芯温度
#define ONE_FRAME_CELL_TEMP_NUM_OVERFLOW 3
#define ONE_PACKAGE_CELL_TEMP_NUM       36
#define ONE_PACKAGE_FRAME_CELL_TEMP_NUM 12
static bool inner_can_tx_msg_cell_temp_overflow(can_frame_data_t *can_data, uint16_t func_code)
{
    const bmu_data_t* p_bmu_data = bmu_data_p_get();
    if (NULL == p_bmu_data)
    {
        return 0;
    }
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    uint8_t package_no = 1;
    uint16_t cell_id = (package_no - 1) * ONE_PACKAGE_CELL_TEMP_NUM;
    uint8_t send_frame_num = 0;
    
    data[1] = package_no;
    uint8_t send_num = 0;
    uint16_t cluster_max_temp_sub_frame = CELL_TEMP_NUM - ONE_FRAME_CELL_TEMP_NUM_OVERFLOW;
    while (send_frame_num < ONE_PACKAGE_FRAME_CELL_TEMP_NUM)
    {
        send_frame_num++;
        data[0] = send_frame_num;
        if (cell_id <= cluster_max_temp_sub_frame)
        {
            send_num = ONE_FRAME_CELL_TEMP_NUM_OVERFLOW;
        }
        else
        {
            memset(&data[2], 0xFF, 6);
            if (cell_id >= CELL_TEMP_NUM)
            {
                send_num = 0;
                break;
            }
            else
            {
                send_num = CELL_TEMP_NUM % ONE_FRAME_CELL_TEMP_NUM_OVERFLOW;
            }
        }
        for (uint8_t i = 0; i< send_num; i++)
        {
            data[2 + i * 2] = LOW_BYTE(p_bmu_data->cell_temp[cell_id + i]);
            data[3 + i * 2] = HIGH_BYTE(p_bmu_data->cell_temp[cell_id + i]);
        }
        can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
        cell_id += ONE_FRAME_CELL_TEMP_NUM_OVERFLOW;
    }
    return 0;
}

// 0x1072:电芯被动均衡状态
static bool inner_can_tx_msg_cell_pass_bal_state_overflow(can_frame_data_t *can_data, uint16_t func_code)
{
    const bmu_data_t* p_bmu_data = bmu_data_p_get();
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0x00};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);
    
    data[0] = 0x01;
#if PACK_64S_PRJ
    data[1] = LOW_BYTE(p_bmu_data->bal_stus[0]);
    data[2] = HIGH_BYTE(p_bmu_data->bal_stus[0]);
    data[3] = LOW_BYTE(p_bmu_data->bal_stus[1]);
    data[4] = HIGH_BYTE(p_bmu_data->bal_stus[1]);
    data[5] = LOW_BYTE(p_bmu_data->bal_stus[2]);
    data[6] = HIGH_BYTE(p_bmu_data->bal_stus[2]);
    data[7] = LOW_BYTE(p_bmu_data->bal_stus[3]);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);    
    
    data[0] = 0x02;
    memset(&data[1], 0, 7);
    data[1] = HIGH_BYTE(p_bmu_data->bal_stus[3]);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);  
#else    
    data[1] = LOW_BYTE(p_bmu_data->bal_stus[0]);
    data[2] = HIGH_BYTE(p_bmu_data->bal_stus[0]);
    data[3] = LOW_BYTE(p_bmu_data->bal_stus[1]);
    data[4] = HIGH_BYTE(p_bmu_data->bal_stus[1]);
    data[5] = LOW_BYTE(p_bmu_data->bal_stus[2]);
    data[6] = HIGH_BYTE(p_bmu_data->bal_stus[2]);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);    
#endif    

    return 0;
}

// 0x1073:电芯被动均衡电阻温度
// 0x1071:电芯的电芯温度
#define ONE_FRAME_CELL_BAL_TEMP_NUM_OVERFLOW 3
#define ONE_PACKAGE_CELL_BAL_TEMP_NUM       30
#define ONE_PACKAGE_FRAME_CELL_BAL_TEMP_NUM 10
static bool inner_can_tx_msg_cell_bal_temp_overflow(can_frame_data_t *can_data, uint16_t func_code)
{
    const bmu_data_t* p_bmu_data = bmu_data_p_get();
    if (NULL == p_bmu_data)
    {
        return 0;
    }
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    uint8_t package_no = 1;
    uint16_t cell_id = (package_no - 1) * ONE_PACKAGE_CELL_BAL_TEMP_NUM;
    uint8_t send_frame_num = 0;
    
    data[1] = package_no;
    uint8_t send_num = 0;
    uint16_t cluster_max_temp_sub_frame = BALANCE_TEMP_NUM - ONE_FRAME_CELL_BAL_TEMP_NUM_OVERFLOW;
    //单次发送三个温度，总共发送9个均衡，均衡温度有8个，会有一个溢出
    while (send_frame_num < ONE_PACKAGE_FRAME_CELL_BAL_TEMP_NUM)
    {
        send_frame_num++;
        data[0] = send_frame_num;
        if (cell_id <= cluster_max_temp_sub_frame)
        {
            send_num = ONE_FRAME_CELL_BAL_TEMP_NUM_OVERFLOW;
        }
        else
        {
            memset(&data[2], 0xFF, 6);
            if (cell_id >= BALANCE_TEMP_NUM)
            {
                send_num = 0;
                break;
            }
            else
            {
                send_num = BALANCE_TEMP_NUM % ONE_FRAME_CELL_BAL_TEMP_NUM_OVERFLOW;
            }
        }
        for (uint8_t i = 0; i< send_num; i++)
        {
            if(cell_id + i <= BALANCE_TEMP_NUM)
            {
                data[2 + i * 2] = LOW_BYTE(p_bmu_data->adc_sample_other_temp[cell_id + i + 1]); //+1是因为第二个温度点才是均衡温度
                data[3 + i * 2] = HIGH_BYTE(p_bmu_data->adc_sample_other_temp[cell_id + i + 1]);
            }
        }
        can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
        cell_id += ONE_FRAME_CELL_BAL_TEMP_NUM_OVERFLOW;
        
    }
    return 0;
}

// 0x0A0：BMS电池SOC
#define SOX_INFO_ONE_GROUP_NUM (7)
static bool inner_can_tx_msg_bmu_soc_info(can_frame_data_t *can_data, uint16_t func_code)
{
    const sox_data_t* sox_data = sox_data_get_deal();
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0x00};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    uint8_t send_frame_cnt = (CELL_VOLT_NUM + SOX_INFO_ONE_GROUP_NUM - 1) / SOX_INFO_ONE_GROUP_NUM;
    uint8_t last_frame_num = (CELL_VOLT_NUM % SOX_INFO_ONE_GROUP_NUM == 0) ? SOX_INFO_ONE_GROUP_NUM : CELL_VOLT_NUM % SOX_INFO_ONE_GROUP_NUM;

    if (NULL == sox_data)
    {
        memset(data, 0xFF, CAN_MAX_DATA_LEN_ONE_FRAME);
        for (uint8_t i = 0; i < send_frame_cnt; i++)
        {
            data[0] = i;
            can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
        }
    }
    else
    {
        uint8_t send_data_num = SOX_INFO_ONE_GROUP_NUM;
        for (uint8_t i = 0; i < send_frame_cnt; i++)
        {
            if (i == send_frame_cnt - 1)
            {
                memset(data, 0xFF, CAN_MAX_DATA_LEN_ONE_FRAME);
                send_data_num = last_frame_num;
            }
            data[0] = i;
            for (uint8_t j = 0; j < send_data_num; j++)
            {
                 data[j + 1] = sox_data->cell_display_soc[i * SOX_INFO_ONE_GROUP_NUM + j];
            }
            can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
        }
    }
    return 0;
}

// 0x0A1：BMS电池SOH
static bool inner_can_tx_msg_bmu_soh_info(can_frame_data_t *can_data, uint16_t func_code)
{
    const sox_data_t* sox_data = sox_data_get_deal();

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0x00};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    uint8_t send_frame_cnt = (CELL_VOLT_NUM + SOX_INFO_ONE_GROUP_NUM - 1) / SOX_INFO_ONE_GROUP_NUM;
    uint8_t last_frame_num = (CELL_VOLT_NUM % SOX_INFO_ONE_GROUP_NUM == 0) ? SOX_INFO_ONE_GROUP_NUM : CELL_VOLT_NUM % SOX_INFO_ONE_GROUP_NUM;

    if (NULL == sox_data)
    {
        memset(data, 0xFF, CAN_MAX_DATA_LEN_ONE_FRAME);
        for (uint8_t i = 0; i < send_frame_cnt; i++)
        {
            data[0] = i;
            can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
        }
    }
    else
    {
        uint8_t send_data_num = SOX_INFO_ONE_GROUP_NUM;
        for (uint8_t i = 0; i < send_frame_cnt; i++)
        {
            if (i == send_frame_cnt - 1)
            {
                memset(data, 0xFF, CAN_MAX_DATA_LEN_ONE_FRAME);
                send_data_num = last_frame_num;
            }
            data[0] = i;
            for (uint8_t j = 0; j < send_data_num; j++)
            {
                 data[j + 1] = sox_data->cell_display_soh[i * SOX_INFO_ONE_GROUP_NUM + j];
            }
            can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
        }
    }
    return 0;
}

// 0x04B :BMS新增提示，告警 3
static bool inner_can_tx_msg_bms_alarm_tips_info(can_frame_data_t *can_data, uint16_t func_code)
{
    const fault_info_t *p_fault_info = get_fault_info();
    if (NULL == p_fault_info)
    {
        return 0;
    }
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    data[0] = p_fault_info->fault_info3.byte0.byte;
    data[1] = p_fault_info->fault_info3.byte1.byte;
    data[2] = p_fault_info->fault_info3.byte2.byte;
    data[4] = p_fault_info->fault_info3.byte4.byte;
    
    data[7] = fault_chg_dsg_level_get()->fault_level;
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x04C :其他信息上报，包括SOC放电末端校准数据、被动均衡状态（在sox_inf.c里控制1S发送一次）
#define SLA_REPLY_DSG_END_SOC_DATA  1
#define SLA_REPLY_PASS_BAL_DATA     2
#define SLA_REPLY_ELECTROLYTE_DATA  3
static bool inner_can_tx_msg_mas_other_data_info(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    uint16_t data_tmp = 0;  
    
    const bmu_data_t* p_bmu_data = bmu_data_p_get();
    if (NULL == p_bmu_data)
    {
        return 0;
    } 
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);
    
    data[0] = SLA_REPLY_ELECTROLYTE_DATA;
    data_tmp = p_bmu_data->electrolyte_strength;
    fill_can_data_buff(data_tmp, &data[1], WORD_SIZE);    
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    
    dsg_cali_data_t tx_dsg_cali_data = {0};
    int8_t ret = soc_dsg_cali_data_get(&tx_dsg_cali_data);    
    if (0 > ret)
    {
        return 0;
    }

    memset(&data[1], 0, (CAN_MAX_DATA_LEN_ONE_FRAME - 1));
    data[0] = SLA_REPLY_DSG_END_SOC_DATA;
    data[1] = (uint8_t)(tx_dsg_cali_data.can_soc_min_to_volt & 0xFF);
    data[2] = (uint8_t)((tx_dsg_cali_data.can_soc_min_to_volt >> 8) & 0xFF);
    data[3] = (uint8_t)(tx_dsg_cali_data.can_calc_val & 0xFF);
    data[4] = (uint8_t)((tx_dsg_cali_data.can_calc_val >> 8) & 0xFF);
	data[5] = (uint8_t)(tx_dsg_cali_data.can_min_cell_volt & 0xFF);
    data[6] = (uint8_t)((tx_dsg_cali_data.can_min_cell_volt >> 8) & 0xFF);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);

    memset(&data[1], 0, (CAN_MAX_DATA_LEN_ONE_FRAME - 1));  
    data[0] = SLA_REPLY_PASS_BAL_DATA;
    data_tmp = cell_balance_status_get();         //  BMU均衡状态
    fill_can_data_buff(data_tmp, &data[1], WORD_SIZE);
    data_tmp = cell_balance_min_cell_soc_get();         //  BMU最小电芯电压对应的SOC值
    fill_can_data_buff(data_tmp, &data[3], WORD_SIZE);    
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);

    
    return 0;
}

// 0x030 :ATE测试结果
static bool inner_can_tx_msg_ate_test_result_info(can_frame_data_t *can_data, uint16_t func_code)
{
    const bmu_data_t* p_bmu_data = bmu_data_p_get();
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};    
    uint16_t tmp = 0;
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    data[0] = 0x01; //固定
    data[1] = get_ate_test_func_result(ATE_FLASH_FORMAT_TEST_RESULT); //Flash格式化结果
    data[2] = get_ate_test_func_result(ATE_CAN0_TEST_RESULT); //CAN0测试结果
    data[3] = get_ate_test_func_result(ATE_CAN1_TEST_RESULT); //CAN1测试结果
    data[4] = get_ate_test_func_result(ATE_EXT_WDT_TEST_RESULT); //外部看门狗测试结果    
    data[5] = get_ate_test_func_result(ATE_INNER_ADDR_IO_TEST_RESULT); //簇内编址io测试结果
    data[6] = get_ate_test_func_result(ATE_DIDO_TEST_RESULT); //dido测试结果
    
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);

    if (NULL == p_bmu_data)
    {
        return 0;
    }

    data[0] = 0x03; //固定
    
    data[1] = LOW_BYTE(p_bmu_data->check_5v_volt); //
    data[2] = HIGH_BYTE(p_bmu_data->check_5v_volt); //
    tmp = p_bmu_data->bat_afe_volt / 4 / 100; //单个的值
    data[3] = LOW_BYTE(tmp) ; //
    data[4] = HIGH_BYTE(tmp); 
    data[5] = LOW_BYTE(p_bmu_data->check_24v_volt) ; //
    data[6] = HIGH_BYTE(p_bmu_data->check_24v_volt); 
    
    
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    
    return 0;
}



// 故障参数标定回复0x1010E0XX
static bool inner_can_reply_msg_ate_cell_volt_over_alm_set(can_frame_data_t *can_data, uint16_t func_code)
{
    bms_attr_t bms_attr_data = {0};
    bms_attr_data = *get_bms_attr();

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    fill_can_data_buff(bms_attr_data.safety.cell_over_vol_protect.appear_value, &data[0], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.cell_over_vol_protect.cancel_value, &data[2], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.cell_over_vol_alarm.appear_value, &data[4], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.cell_over_vol_alarm.cancel_value, &data[6], WORD_SIZE);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 故障参数标定回复0x1011E0XX
static bool inner_can_reply_msg_ate_bat_volt_over_alm_set(can_frame_data_t *can_data, uint16_t func_code)
{
    bms_attr_t bms_attr_data = {0};
    bms_attr_data = *get_bms_attr();

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    fill_can_data_buff(bms_attr_data.safety.total_over_vol_protect.appear_value / 100, &data[0], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.total_over_vol_protect.cancel_value / 100, &data[2], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.total_over_vol_alarm.appear_value / 100, &data[4], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.total_over_vol_alarm.cancel_value / 100, &data[6], WORD_SIZE);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 故障参数标定回复0x1012E0XX
static bool inner_can_reply_msg_ate_cell_volt_under_alm_set(can_frame_data_t *can_data, uint16_t func_code)
{
    bms_attr_t bms_attr_data = {0};
    bms_attr_data = *get_bms_attr();

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    fill_can_data_buff(bms_attr_data.safety.cell_under_vol_protect.appear_value, &data[0], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.cell_under_vol_protect.cancel_value, &data[2], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.cell_under_vol_alarm.appear_value, &data[4], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.cell_under_vol_alarm.cancel_value, &data[6], WORD_SIZE);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 故障参数标定回复0x1013E0XX
static bool inner_can_reply_msg_ate_bat_volt_under_alm_set(can_frame_data_t *can_data, uint16_t func_code)
{
    bms_attr_t bms_attr_data = {0};
    bms_attr_data = *get_bms_attr();

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    fill_can_data_buff(bms_attr_data.safety.total_under_vol_protect.appear_value / 100, &data[0], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.total_under_vol_protect.cancel_value / 100, &data[2], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.total_under_vol_alarm.appear_value / 100, &data[4], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.total_under_vol_alarm.cancel_value / 100, &data[6], WORD_SIZE);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 故障参数标定回复0x1014E0XX
static bool inner_can_reply_msg_ate_chg_curr_over_alm_set(can_frame_data_t *can_data, uint16_t func_code)
{
//    bms_attr_t bms_attr_data = {0};
//    bms_attr_data = *get_bms_attr();

//    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
//    can_frame_id_u rx_can_frame = {can_data->id};
//    can_frame_id_u tx_can_frame = {0};
//    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

//    fill_can_data_buff(bms_attr_data.safety.chg_over_cur_protect.appear_value / 10, &data[0], WORD_SIZE);
//    fill_can_data_buff(bms_attr_data.safety.chg_over_cur_protect.cancel_value / 10, &data[2], WORD_SIZE);
//    fill_can_data_buff(bms_attr_data.safety.chg_over_cur_alarm.appear_value / 10, &data[4], WORD_SIZE);
//    fill_can_data_buff(bms_attr_data.safety.chg_over_cur_alarm.cancel_value / 10, &data[6], WORD_SIZE);
//    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 故障参数标定回复0x1015E0XX
static bool inner_can_reply_msg_ate_dchg_curr_over_alm_set(can_frame_data_t *can_data, uint16_t func_code)
{
//    bms_attr_t bms_attr_data = {0};
//    bms_attr_data = *get_bms_attr();

//    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
//    can_frame_id_u rx_can_frame = {can_data->id};
//    can_frame_id_u tx_can_frame = {0};
//    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

//    fill_can_data_buff(bms_attr_data.safety.dchg_over_cur_alarm.appear_value / 10, &data[0], WORD_SIZE);
//    fill_can_data_buff(bms_attr_data.safety.dchg_over_cur_alarm.cancel_value / 10, &data[2], WORD_SIZE);
//    fill_can_data_buff(bms_attr_data.safety.dchg_over_cur_tip.appear_value / 10, &data[4], WORD_SIZE);
//    fill_can_data_buff(bms_attr_data.safety.dchg_over_cur_tip.cancel_value / 10, &data[6], WORD_SIZE);
//    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 故障参数标定回复0x1016E0XX
#define DEFAULT_TEMP_VAL_OFFSET (400)
static bool inner_can_reply_msg_ate_cell_temp_over_alm_set(can_frame_data_t *can_data, uint16_t func_code)
{
    bms_attr_t bms_attr_data = {0};
    bms_attr_data = *get_bms_attr();

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    data[0] = (bms_attr_data.safety.chg_over_temp_protect.appear_value + DEFAULT_TEMP_VAL_OFFSET) / 10;
    data[1] = (bms_attr_data.safety.chg_over_temp_protect.cancel_value + DEFAULT_TEMP_VAL_OFFSET) / 10;
    data[2] = (bms_attr_data.safety.chg_over_temp_alarm.appear_value + DEFAULT_TEMP_VAL_OFFSET) / 10;
    data[3] = (bms_attr_data.safety.chg_over_temp_alarm.cancel_value + DEFAULT_TEMP_VAL_OFFSET) / 10;
    data[4] = (bms_attr_data.safety.dchg_over_temp_protect.appear_value + DEFAULT_TEMP_VAL_OFFSET) / 10;
    data[5] = (bms_attr_data.safety.dchg_over_temp_protect.cancel_value + DEFAULT_TEMP_VAL_OFFSET) / 10;
    data[6] = (bms_attr_data.safety.dchg_over_temp_alarm.appear_value + DEFAULT_TEMP_VAL_OFFSET) / 10;
    data[7] = (bms_attr_data.safety.dchg_over_temp_alarm.cancel_value + DEFAULT_TEMP_VAL_OFFSET) / 10;
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 故障参数标定回复0x1017E0XX
static bool inner_can_reply_msg_ate_cell_temp_under_alm_set(can_frame_data_t *can_data, uint16_t func_code)
{
    bms_attr_t bms_attr_data = {0};
    bms_attr_data = *get_bms_attr();

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    data[0] = (bms_attr_data.safety.chg_under_temp_protect.appear_value + DEFAULT_TEMP_VAL_OFFSET) / 10;
    data[1] = (bms_attr_data.safety.chg_under_temp_protect.cancel_value + DEFAULT_TEMP_VAL_OFFSET) / 10;
    data[2] = (bms_attr_data.safety.chg_under_temp_alarm.appear_value + DEFAULT_TEMP_VAL_OFFSET) / 10;
    data[3] = (bms_attr_data.safety.chg_under_temp_alarm.cancel_value + DEFAULT_TEMP_VAL_OFFSET) / 10;
    data[4] = (bms_attr_data.safety.dchg_under_temp_protect.appear_value + DEFAULT_TEMP_VAL_OFFSET) / 10;
    data[5] = (bms_attr_data.safety.dchg_under_temp_protect.cancel_value + DEFAULT_TEMP_VAL_OFFSET) / 10;
    data[6] = (bms_attr_data.safety.dchg_under_temp_alarm.appear_value + DEFAULT_TEMP_VAL_OFFSET) / 10;
    data[7] = (bms_attr_data.safety.dchg_under_temp_alarm.cancel_value + DEFAULT_TEMP_VAL_OFFSET) / 10;
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 故障参数标定回复0x1019E0XX
static bool inner_can_reply_msg_ate_soc_low_alm_set(can_frame_data_t *can_data, uint16_t func_code)
{
    bms_attr_t bms_attr_data = {0};
    bms_attr_data = *get_bms_attr();

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    // 无低SOC保护
    fill_can_data_buff(bms_attr_data.safety.soc_under_alarm.appear_value / 1000, &data[4], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.soc_under_alarm.cancel_value / 1000, &data[6], WORD_SIZE);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 故障参数标定回复0x101BE0XX
static bool inner_can_reply_msg_ate_bat_curr_over_alm_2_set(can_frame_data_t *can_data, uint16_t func_code)
{
//    bms_attr_t bms_attr_data = {0};
//    bms_attr_data = *get_bms_attr();

//    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
//    can_frame_id_u rx_can_frame = {can_data->id};
//    can_frame_id_u tx_can_frame = {0};
//    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

//    fill_can_data_buff(bms_attr_data.safety.dchg_over_cur_protect.appear_value / 10, &data[4], WORD_SIZE);
//    fill_can_data_buff(bms_attr_data.safety.dchg_over_cur_protect.cancel_value / 10, &data[6], WORD_SIZE);
//    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 故障参数标定回复0x101CE0XX
static bool inner_can_reply_msg_ate_cell_volt_err_alm_set(can_frame_data_t *can_data, uint16_t func_code)
{
    bms_attr_t bms_attr_data = {0};
    bms_attr_data = *get_bms_attr();

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    fill_can_data_buff(bms_attr_data.safety.cell_over_vol_seriou.appear_value, &data[0], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.cell_over_vol_seriou.cancel_value, &data[2], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.cell_under_vol_seriou.appear_value, &data[4], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.cell_under_vol_seriou.cancel_value, &data[6], WORD_SIZE);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x1080E0XX 单体电压过充、过放提示标定
static bool inner_can_reply_msg_ate_cell_volt_tip_set(can_frame_data_t *can_data, uint16_t func_code)
{
    bms_attr_t bms_attr_data = {0};
    bms_attr_data = *get_bms_attr();

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    fill_can_data_buff(bms_attr_data.safety.cell_over_vol_tip.appear_value, &data[0], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.cell_over_vol_tip.cancel_value, &data[2], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.cell_under_vol_tip.appear_value, &data[4], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.cell_under_vol_tip.cancel_value, &data[6], WORD_SIZE);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x1081E0XX单体电压压差过大提示、告警标定
static bool inner_can_reply_msg_ate_cell_volt_diff_1_set(can_frame_data_t *can_data, uint16_t func_code)
{
    bms_attr_t bms_attr_data = {0};
    bms_attr_data = *get_bms_attr();

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    fill_can_data_buff(bms_attr_data.safety.cell_volt_diff_tip.appear_value, &data[0], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.cell_volt_diff_tip.cancel_value, &data[2], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.cell_volt_diff_alarm.appear_value, &data[4], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.cell_volt_diff_alarm.cancel_value, &data[6], WORD_SIZE);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x1082E0XX单体电压压差过大故障标定
static bool inner_can_reply_msg_ate_cell_volt_diff_2_set(can_frame_data_t *can_data, uint16_t func_code)
{
    bms_attr_t bms_attr_data = {0};
    bms_attr_data = *get_bms_attr();

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    fill_can_data_buff(bms_attr_data.safety.cell_volt_diff_protect.appear_value, &data[0], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.cell_volt_diff_protect.cancel_value, &data[2], WORD_SIZE);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x1083E0XX电芯温度充放电高低温提示标定
static bool inner_can_reply_msg_ate_cell_temp_tip_set(can_frame_data_t *can_data, uint16_t func_code)
{
    bms_attr_t bms_attr_data = {0};
    bms_attr_data = *get_bms_attr();

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    data[0] = (bms_attr_data.safety.chg_over_temp_tip.appear_value + DEFAULT_TEMP_VAL_OFFSET) / 10;
    data[1] = (bms_attr_data.safety.chg_over_temp_tip.cancel_value + DEFAULT_TEMP_VAL_OFFSET) / 10;
    data[2] = (bms_attr_data.safety.chg_under_temp_tip.appear_value + DEFAULT_TEMP_VAL_OFFSET) / 10;
    data[3] = (bms_attr_data.safety.chg_under_temp_tip.cancel_value + DEFAULT_TEMP_VAL_OFFSET) / 10;
    data[4] = (bms_attr_data.safety.dchg_over_temp_tip.appear_value + DEFAULT_TEMP_VAL_OFFSET) / 10;
    data[5] = (bms_attr_data.safety.dchg_over_temp_tip.cancel_value + DEFAULT_TEMP_VAL_OFFSET) / 10;
    data[6] = (bms_attr_data.safety.dchg_under_temp_tip.appear_value + DEFAULT_TEMP_VAL_OFFSET) / 10;
    data[7] = (bms_attr_data.safety.dchg_under_temp_tip.cancel_value + DEFAULT_TEMP_VAL_OFFSET) / 10;
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x1084E0XX电芯温差过大提示，告警、保护标定
static bool inner_can_reply_msg_ate_cell_temp_diff_set(can_frame_data_t *can_data, uint16_t func_code)
{
    bms_attr_t bms_attr_data = {0};
    bms_attr_data = *get_bms_attr();

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    data[0] = (bms_attr_data.safety.cell_temp_diff_tip.appear_value) / 10;
    data[1] = (bms_attr_data.safety.cell_temp_diff_tip.cancel_value) / 10;
    data[2] = (bms_attr_data.safety.cell_temp_diff_alarm.appear_value) / 10;
    data[3] = (bms_attr_data.safety.cell_temp_diff_alarm.cancel_value) / 10;
    data[4] = (bms_attr_data.safety.cell_temp_diff_protect.appear_value ) / 10;
    data[5] = (bms_attr_data.safety.cell_temp_diff_protect.cancel_value) / 10;
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}
// 0x1085E0XX 总压过压欠压提示标定
static bool inner_can_reply_msg_ate_batt_volt_tip_set(can_frame_data_t *can_data, uint16_t func_code)
{
    bms_attr_t bms_attr_data = {0};
    bms_attr_data = *get_bms_attr();

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    fill_can_data_buff(bms_attr_data.safety.total_over_vol_tip.appear_value / 100, &data[0], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.total_over_vol_tip.cancel_value / 100, &data[2], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.total_under_vol_tip.appear_value / 100, &data[4], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.safety.total_under_vol_tip.cancel_value / 100, &data[6], WORD_SIZE);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x01F: ATE Flash测试：0x101FE0XX
static bool inner_can_reply_msg_ate_flash_test(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_runing_data_t *bms_data = get_bms_runing_data();
    if (NULL == bms_data)
    {
        return 0;
    }

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    for (uint8_t i = 1; i < CAN_MAX_DATA_LEN_ONE_FRAME; i++)
    {
        data[i] = bms_data->flash_data[i - 1];
    }
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x020:上位机控制回复0x1020YYXX  / 0x1020YYXX  (YY为上位机设备或者PCS ：0xE0 或 0x41等)
static bool inner_can_reply_msg_ate_set_old_mode(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    data[0] = special_mode_get(AGING_MODE) ? OPEN_MODE : RELEASE_MODE;
    data[1] = special_mode_get(CALI_PARM) ? OPEN_MODE : RELEASE_MODE;
    data[2] = special_mode_get(ATUO_TEST) ? OPEN_MODE : RELEASE_MODE;
    // 无PCU老化模式
    data[4] = special_mode_get(FORCE_CTL_MODE) ? OPEN_MODE : RELEASE_MODE;
    data[5] = 0; // 标定数据初始化，默认0
    data[6] = auto_addressing_get_address();
    data[7] = get_bms_runing_data()->ate_step;
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 参数标定回复0x1021E0XX
static bool inner_can_reply_msg_ate_bal_heat_param_set(can_frame_data_t *can_data, uint16_t func_code)
{
    bms_attr_t bms_attr_data = {0};
    bms_attr_data = *get_bms_attr();

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    fill_can_data_buff(bms_attr_data.bal_vol, &data[0], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.bal_vol_diff, &data[2], WORD_SIZE);
    fill_can_data_buff(bms_attr_data.full_chg_vol, &data[4], WORD_SIZE);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 参数标定回复0x1022E0XX
static bool inner_can_reply_msg_ate_cell_volt_curr_limit_set(can_frame_data_t *can_data, uint16_t func_code)
{
    bms_attr_t bms_attr_data = {0};
    bms_attr_data = *get_bms_attr();

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    fill_can_data_buff(bms_attr_data.chg_stop_vol/100, &data[0], WORD_SIZE); // 单位0.1V
    fill_can_data_buff(bms_attr_data.chg_stop_cur/10, &data[2], WORD_SIZE); // 单位100mA

    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 参数标定回复0x1023E0XX
static bool inner_can_reply_msg_ate_cell_num_set(can_frame_data_t *can_data, uint16_t func_code)
{
    bms_attr_t bms_attr_data = {0};
    bms_attr_data = *get_bms_attr();

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    fill_can_data_buff(bms_attr_data.rate_cap, &data[0], WORD_SIZE);      // 单位0.1Ah
    fill_can_data_buff(bms_attr_data.mono_vol_num, &data[2], WORD_SIZE); // 电芯个数
    fill_can_data_buff(bms_attr_data.mono_tem_num, &data[4], WORD_SIZE); // 温度个数

    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 参数标定回复0x1024E0XX
static bool inner_can_reply_msg_ate_chg_dsg_cap_set(can_frame_data_t *can_data, uint16_t func_code)
{
    const sox_data_t* sox_data = sox_data_get_deal();
    if (NULL == sox_data)
    {
        return 0;
    }
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    fill_can_data_buff(sox_data->total_chg_ah * 1000, &data[0], DWORD_SIZE);      // 单位mAh
    fill_can_data_buff(sox_data->total_dsg_ah * 1000, &data[4], DWORD_SIZE);      // 单位mAh
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 参数标定回复0x1025E0XX
static bool inner_can_reply_msg_ate_sox_set(can_frame_data_t *can_data, uint16_t func_code)
{
    const sox_data_t* sox_data = sox_data_get_deal();
    if (NULL == sox_data)
    {
        return 0;
    }
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    fill_can_data_buff(sox_data->display_soc * 10, &data[0], WORD_SIZE);      // 单位0.1%
    fill_can_data_buff(sox_data->real_cap * 10, &data[2], WORD_SIZE);         // 单位0.1Ah
    fill_can_data_buff(sox_data->remained_cap * 10, &data[4], WORD_SIZE);     // 单位0.1Ah
    fill_can_data_buff(sox_data->display_soh * 10, &data[6], WORD_SIZE);      // 单位0.1%
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 时间标定回复0x1026E0XX
static bool inner_can_reply_msg_ate_sys_time_set(can_frame_data_t *can_data, uint16_t func_code)
{
    sdk_rtc_t rtc_time = {0};
    sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    data[0] = rtc_time.tm_year;
    data[1] = rtc_time.tm_mon;
    data[2] = rtc_time.tm_day;
    data[3] = rtc_time.tm_hour;
    data[4] = rtc_time.tm_min;
    data[5] = rtc_time.tm_sec;
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// PACK_SN标定回复0x1027E0XX
static bool inner_can_reply_msg_ate_pack_sn_set(can_frame_data_t *can_data, uint16_t func_code)
{
    #define PACK_SN_IN_FRAME_LEN 7
    const bms_attr_t* bms_attr_data = get_bms_attr();
    if (NULL == bms_attr_data)
    {
        return 0;
    }

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    uint8_t sn_len = sizeof(bms_attr_data->pack_sn); // pack_sn后面需要修改uint8_t
    uint8_t sn_cnt = (sn_len + PACK_SN_IN_FRAME_LEN - 1) / PACK_SN_IN_FRAME_LEN;
    uint8_t frame_len = PACK_SN_IN_FRAME_LEN;
    for (uint8_t i = 0; i < sn_cnt; i++)
    {
        data[0] = i;
        if (i + 1 == sn_cnt)
        {
            frame_len = ((sn_len % PACK_SN_IN_FRAME_LEN) == 0) ? PACK_SN_IN_FRAME_LEN : sn_len % PACK_SN_IN_FRAME_LEN;
        }
        else
        {
            frame_len = PACK_SN_IN_FRAME_LEN;
        }
        for (uint8_t j = 0; j < frame_len; j++)
        {
            data[1 + j] = bms_attr_data->pack_sn[PACK_SN_IN_FRAME_LEN * i + j];
        }
        can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
        memset(data, 0x0, sizeof(data));
    }
    return 0;
}

// BOARD_SN标定回复0x1028E0XX
static bool inner_can_reply_msg_ate_board_sn_set(can_frame_data_t *can_data, uint16_t func_code)
{
    #define BOARD_SN_IN_FRAME_LEN 7
    const bms_attr_t* bms_attr_data = get_bms_attr();
    if (NULL == bms_attr_data)
    {
        return 0;
    }

    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    uint8_t sn_len = sizeof(bms_attr_data->board_sn); // pack_sn后面需要修改uint8_t
    uint8_t sn_cnt = (sn_len + BOARD_SN_IN_FRAME_LEN - 1) / BOARD_SN_IN_FRAME_LEN;
    uint8_t frame_len = BOARD_SN_IN_FRAME_LEN;
    for (uint8_t i = 0; i < sn_cnt; i++)
    {
        data[0] = i;
        if (i + 1 == sn_cnt)
        {
            frame_len = ((sn_len % BOARD_SN_IN_FRAME_LEN) == 0) ? BOARD_SN_IN_FRAME_LEN : sn_len % BOARD_SN_IN_FRAME_LEN;
        }
        else
        {
            frame_len = BOARD_SN_IN_FRAME_LEN;
        }
        for (uint8_t j = 0; j < frame_len; j++)
        {
            data[1 + j] = bms_attr_data->board_sn[BOARD_SN_IN_FRAME_LEN * i + j];
        }
        can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
        memset(data, 0x0, sizeof(data));
    }
    return 0;
}

// 设置电池信息标定回复0x1029E0XX
static bool inner_can_reply_msg_ate_cell_info_set(can_frame_data_t *can_data, uint16_t func_code)
{
    // 当前CBS5000没有
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    data[0] = 0; // TODO 电芯品牌
    data[1] = 0; // TODO 电芯型号编码
    data[2] = 0; // TODO flash标志
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 校准系数标定回复0x102AE0XX
static bool inner_can_reply_msg_ate_cali_param_set(can_frame_data_t *can_data, uint16_t func_code)
{
    // 当前CBS5000没有
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    data[0] = g_cali_data_type;
    data[1] = g_cali_data_result;
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x02B:BMS功能开关回复0x102BE0XX
static bool inner_can_reply_msg_ate_bmu_func_set(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    data[0] = ate_ctl_can_get(ATE_FUNC_SW_CTL_1); // 
    data[1] = ate_ctl_can_get(ATE_FUNC_SW_CTL_2); // 
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x02C:上位机监控读取0x102CXXE0
static bool inner_can_reply_msg_ate_monitor_data_read(can_frame_data_t *can_data, uint16_t func_code)
{
    // 无需回复
    return 0;
}

// 0x102DE0XX一键读取历史故障回复
static bool inner_can_reply_msg_ate_clr_history_data(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    data[0] = 0; // TODO 完成 0xAA； 0x55未完成
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x02E:一键读取标定参数回复0x102EE0XX
static bool inner_can_reply_msg_ate_read_set_data(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    uint16_t data_tmp = 0;
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    data[0] = (uint8_t)g_cali_para_result; // 读取或者操作结果
    data[1] = SOFTWARE_VERSION[0]; // V/T
    data[2] = ((uint8_t)(SOFTWARE_VERSION[1] - AsciiToInt)*10) + (SOFTWARE_VERSION[2] - AsciiToInt);// *10转成十位数
    data[3] = ((uint8_t)(SOFTWARE_VERSION[3] - AsciiToInt)*10) + (SOFTWARE_VERSION[4] - AsciiToInt);
    data[4] = ((uint8_t)(SOFTWARE_VERSION[5] - AsciiToInt)*10) + (SOFTWARE_VERSION[6] - AsciiToInt);
    data_tmp = hardware_ver_get();
    fill_can_data_buff(data_tmp, &data[5], WORD_SIZE);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x02F:ATE控制参数回复0x102FE0XX
static bool inner_can_reply_msg_ate_force_ctl_set(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);
    data[0] = ate_ctl_can_get(ATE_CTL_ITEM_1); // 
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

// 0x01E:ATE控制参数回复0x101EE0XX
static bool inner_can_reply_msg_ate_force_ctl_set_2(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_MAX_DATA_LEN_ONE_FRAME] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

//    data[0] = ate_ctl_can_get(ATE_FUNC_CTL2);; // llc强制放电，llc强制充电，LED灯控制，硬件看门狗控制
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_MAX_DATA_LEN_ONE_FRAME);
    return 0;
}

/*******************************************************接收处理函数************************************************************/
// 0x001:BMS控制信息1
static bool inner_can_rx_master_ctl_cmd(can_frame_data_t *can_data, uint16_t func_code)
{
    if (can_data == NULL)
    {
        return 0;
    }
    return inner_addr_rcv_callback(can_data->id, can_data->data, can_data->data_len);
}

// 0x060:BMS控制信息3-设置状态参数/电流
static bool inner_can_rx_master_curr_set_cmd(can_frame_data_t *can_data, uint16_t func_code)
{
    static uint8_t pre_pack_recov_stus = false;
    uint8_t crc_check = can_single_frame_crc8_calc(can_data, MASTER_CTL_SET_CRC8_MASK);
    if (crc_check != can_data->data[7])
    {
        return 0;
    }
    g_set_bmu_data.set_bat_sta.all = can_data->data[2];
    bmu_bat_state_set(0, g_set_bmu_data.set_bat_sta.bit.bat_sta);
    if (g_set_bmu_data.set_bat_sta.bit.shut_down_sta)
    {
//        bmu_shut_down_set(OPEN_MODE);
    }
    else
    {
//        bmu_shut_down_set(RELEASE_MODE);
    }

    if ((pre_pack_recov_stus == true)
        && (g_set_bmu_data.set_bat_sta.bit.pack_recover == false))
    {
        if((fault_state_get(BOARD_FLASH_INVALID_FAULT))
            || (fault_state_get(BOARD_AFE_ABNORMAL_FAULT)))
        {
            bmu_shut_down_set(OPEN_MODE);
        }
        else
        {
            // 清除所有告警   
            fault_manage_init();
            fault_diag_enable();
            afe_init();  
//            bmu_data_init();
        }


    }
    pre_pack_recov_stus = g_set_bmu_data.set_bat_sta.bit.pack_recover;


    g_set_bmu_data.set_curr = MAKE_WORD(can_data->data[0], can_data->data[1]);
    bmu_sys_current_data_set(0, g_set_bmu_data.set_curr);
    g_set_bmu_data.set_sync_fall_soc = can_data->data[3];
    sox_get_bmu_soc(g_set_bmu_data.set_sync_fall_soc);
    return 0;
}

// 0x061:BMS控制信息4-均衡设置
static bool inner_can_rx_master_bal_set_cmd(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t crc_check = can_single_frame_crc8_calc(can_data, MASTER_CTL_SET_CRC8_MASK);
    if (crc_check != can_data->data[7])
    {
        return 0;
    }

//    g_set_bmu_data.set_bal_status = MAKE_WORD(can_data->data[1], can_data->data[2]);      //主动均衡相关
//    g_set_bmu_data.set_bal_min_cell_soc = MAKE_WORD(can_data->data[3], can_data->data[4]);
    return 0;
}

// 0x062:心跳接收处理
static bool inner_can_rx_msg_heart_beat_cmd(can_frame_data_t *can_data, uint16_t func_code)
{
    return inner_addr_rcv_callback(can_data->id, can_data->data, can_data->data_len);
}

// 0x063:BMS设置被动均衡
static bool inner_can_rx_msg_master_pass_bal_set_cmd(can_frame_data_t *can_data, uint16_t func_code)
{
    uint32_t pass_bal_set = 0;
    if (can_data->data[1] > 0x01)
    {
        return 0;
    }
    if (can_data->data[0] == 0x01)  // 0x01:被动均衡主从控制模式 00:自管理模式
    {
        cell_balance_display_func_disable(true);
    }
    else
    {
        cell_balance_display_func_disable(false);
        return 0;
    }
    pass_bal_set = (can_data->data[3] & 0xF) << 8 | can_data->data[2];
    afe_balance_set(S1, pass_bal_set);
    pass_bal_set = (can_data->data[3] ) >> 4 |  can_data->data[4] << 4;
    afe_balance_set(S2, pass_bal_set);
    pass_bal_set = (can_data->data[6] & 0xF) << 8 | can_data->data[5];
    afe_balance_set(S3, pass_bal_set);
    pass_bal_set = (can_data->data[6]) >> 4 |  can_data->data[7] << 4;
    afe_balance_set(S4, pass_bal_set);
    return 0;
}

// 0x064:主机其他信息设置，包括SOC放电末端校准使用，一般配合0x04C使用
#define MAS_SET_DSG_END_SOC_DATA 1
#define MAS_SET_PASS_BAL_DATA    2
#define MAS_SET_CLU_LOW_VOLT    3
static bool inner_can_rx_msg_mas_other_data_set_cmd(can_frame_data_t *can_data, uint16_t func_code)
{
    uint16_t tmp1 = 0;
    uint16_t tmp2 = 0;
	uint16_t tmp3 = 0;
    // 放电末端校准设置
    if (can_data->data[0] == MAS_SET_DSG_END_SOC_DATA)
    {
        tmp1 = MAKE_WORD(can_data->data[1], can_data->data[2]);
        tmp2 = MAKE_WORD(can_data->data[3], can_data->data[4]);
		tmp3 = MAKE_WORD(can_data->data[5], can_data->data[6]);
        // TODO 增加设置接口
        sox_dsg_cali_data_set(RX_SOC_MIN_TO_VOLT_SET, tmp1);
        sox_dsg_cali_data_set(RX_CALC_VAL_SET, tmp2);
		sox_dsg_cali_data_set(RX_MIN_CELL_VOLT,tmp3);
    }
    // 被动均衡设置
    else if (can_data->data[0] == MAS_SET_PASS_BAL_DATA)
    {
        tmp1 = MAKE_WORD(can_data->data[1], can_data->data[2]);
        tmp2 = MAKE_WORD(can_data->data[3], can_data->data[4]);
        // TODO 增加设置接口
        g_set_bmu_data.set_bal_status = tmp1;
        g_set_bmu_data.set_bal_min_cell_soc = tmp2;
    }
    else if (can_data->data[0] == MAS_SET_CLU_LOW_VOLT)
    {
        tmp1 = MAKE_WORD(can_data->data[1], can_data->data[2]);
        volt_diff_pas_bal_data_set(RX_CLU_MIN_VOLT_SET, tmp1);
    }
    return 0;
}



// 故障参数标定0x1010XXE0
static bool inner_can_rx_ate_cell_volt_over_alm_set(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *p_bms_attr = get_bms_attr();

    int32_t tmp = (MAKE_WORD(can_data->data[0], can_data->data[1]));
    if (tmp != p_bms_attr->safety.cell_over_vol_protect.appear_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_CELL_OVER_VOLT_PROT, tmp);
         
    }
    
    tmp = (MAKE_WORD(can_data->data[2], can_data->data[3]));
    if (tmp != p_bms_attr->safety.cell_over_vol_protect.cancel_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_CELL_OVER_VOLT_PROT_DIS, tmp);
        
    }
    
    tmp = (MAKE_WORD(can_data->data[4], can_data->data[5]));
    if (tmp != p_bms_attr->safety.cell_over_vol_alarm.appear_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_CELL_OVER_VOLT_ALRM, tmp);
        
    }
    
    tmp = (MAKE_WORD(can_data->data[6], can_data->data[7]));
    if (tmp != p_bms_attr->safety.cell_over_vol_alarm.cancel_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_CELL_OVER_VOLT_ALRM_DIS, tmp);
        
    }

    SET_BIT(g_bmu_thre_val_sync_flag, 1 << BMU_THRE_SYNC_CELL_OVER_VOLT_ALM);

    inner_can_reply_msg_ate_cell_volt_over_alm_set(can_data, func_code);
    return 0;
}

// 故障参数标定0x1011XXE0
static bool inner_can_rx_ate_bat_volt_over_alm_set(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *p_bms_attr = get_bms_attr();

    int32_t tmp = (MAKE_WORD(can_data->data[0], can_data->data[1])) * 100;
    if (tmp != p_bms_attr->safety.total_over_vol_protect.appear_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_TOTAL_OVER_VOLT_PROT, tmp);
        
    }
    
    tmp = (MAKE_WORD(can_data->data[2], can_data->data[3])) * 100;
    if (tmp != p_bms_attr->safety.total_over_vol_protect.cancel_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_TOTAL_OVER_VOLT_PROT_DIS, tmp);
        
    }
    
    tmp = (MAKE_WORD(can_data->data[4], can_data->data[5])) * 100;
    if (tmp != p_bms_attr->safety.total_over_vol_alarm.appear_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_TOTAL_OVER_VOLT_ALRM, tmp);
       
    }

    tmp = (MAKE_WORD(can_data->data[6], can_data->data[7])) * 100;
    if (tmp != p_bms_attr->safety.total_over_vol_alarm.cancel_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_TOTAL_OVER_VOLT_ALRM_DIS, tmp);
        
    }

    SET_BIT(g_bmu_thre_val_sync_flag, 1 << BMU_THRE_SYNC_BAT_OVER_VOLT_ALM);

    inner_can_reply_msg_ate_bat_volt_over_alm_set(can_data, func_code);
    return 0;
}

// 故障参数标定0x1012XXE0
static bool inner_can_rx_ate_cell_volt_under_alm_set(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *p_bms_attr = get_bms_attr();

    int32_t tmp = (MAKE_WORD(can_data->data[0], can_data->data[1]));
    if (tmp != p_bms_attr->safety.cell_under_vol_protect.appear_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_CELL_UNDER_VOLT_PROT, tmp);
     
    }
    
    tmp = (MAKE_WORD(can_data->data[2], can_data->data[3]));
    if (tmp != p_bms_attr->safety.cell_under_vol_protect.cancel_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_CELL_UNDER_VOLT_PROT_DIS, tmp);
 
    }
    
    tmp = (MAKE_WORD(can_data->data[4], can_data->data[5]));
    if (tmp != p_bms_attr->safety.cell_under_vol_alarm.appear_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_CELL_UNDER_VOLT_ALRM, tmp);
   
    }
    
    tmp = (MAKE_WORD(can_data->data[6], can_data->data[7]));
    if (tmp != p_bms_attr->safety.cell_under_vol_alarm.cancel_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_CELL_UNDER_VOLT_ALRM_DIS, tmp);
      
    }

    SET_BIT(g_bmu_thre_val_sync_flag, 1 << BMU_THRE_SYNC_CELL_UNDER_VOLT_ALM);


    inner_can_reply_msg_ate_cell_volt_under_alm_set(can_data, func_code);
    return 0;
}

// 故障参数标定0x1013XXE0
static bool inner_can_rx_ate_bat_volt_under_alm_set(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *p_bms_attr = get_bms_attr();

    int32_t tmp = (MAKE_WORD(can_data->data[0], can_data->data[1])) * 100;
    if (tmp != p_bms_attr->safety.total_under_vol_protect.appear_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_TOTAL_UNDER_VOLT_PROT, tmp);
   
    }
    
    tmp = (MAKE_WORD(can_data->data[2], can_data->data[3])) * 100;
    if (tmp != p_bms_attr->safety.total_under_vol_protect.cancel_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_TOTAL_UNDER_VOLT_PROT_DIS, tmp);
    
    }
    
    tmp = (MAKE_WORD(can_data->data[4], can_data->data[5])) * 100;
    if (tmp != p_bms_attr->safety.total_under_vol_alarm.appear_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_TOTAL_UNDER_VOLT_ALRM, tmp);
  
    }

    tmp = (MAKE_WORD(can_data->data[6], can_data->data[7])) * 100;
    if (tmp != p_bms_attr->safety.total_under_vol_alarm.cancel_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_TOTAL_UNDER_VOLT_ALRM_DIS, tmp);
   
    }

    SET_BIT(g_bmu_thre_val_sync_flag, 1 << BMU_THRE_SYNC_BAT_UNDER_VOLT_ALM);


    inner_can_reply_msg_ate_bat_volt_under_alm_set(can_data, func_code);
    return 0;
}

// 故障参数标定0x1014XXE0
static bool inner_can_rx_ate_chg_curr_over_alm_set(can_frame_data_t *can_data, uint16_t func_code)
{
//    data_store_save_bms_attr_thre_val(SET_THRE_CHG_OVER_CUR_PROT, (int32_t)(MAKE_WORD(can_data->data[0], can_data->data[1])) * 10);
//    data_store_save_bms_attr_thre_val(SET_THRE_CHG_OVER_CUR_PROT_DIS, (int32_t)(MAKE_WORD(can_data->data[2], can_data->data[3])) * 10);
//    data_store_save_bms_attr_thre_val(SET_THRE_CHG_OVER_CUR_ALRM, (int32_t)(MAKE_WORD(can_data->data[4], can_data->data[5])) * 10);
//    data_store_save_bms_attr_thre_val(SET_THRE_CHG_OVER_CUR_ALRM_DIS, (int32_t)(MAKE_WORD(can_data->data[6], can_data->data[7])) * 10);
//    inner_can_reply_msg_ate_chg_curr_over_alm_set(can_data, func_code);
    return 0;
}

// 故障参数标定0x1015XXE0
static bool inner_can_rx_ate_dchg_curr_over_alm_set(can_frame_data_t *can_data, uint16_t func_code)
{
//    data_store_save_bms_attr_thre_val(SET_THRE_DCHG_OVER_CUR_PROT1, (int32_t)(MAKE_WORD(can_data->data[0], can_data->data[1])) * 10);
//    data_store_save_bms_attr_thre_val(SET_THRE_DCHG_OVER_CUR_PROT1_DIS, (int32_t)(MAKE_WORD(can_data->data[2], can_data->data[3])) * 10);
//    data_store_save_bms_attr_thre_val(SET_THRE_DCHG_OVER_CUR_ALRM, (int32_t)(MAKE_WORD(can_data->data[4], can_data->data[5])) * 10);
//    data_store_save_bms_attr_thre_val(SET_THRE_DCHG_OVER_CUR_ALRM_DIS, (int32_t)(MAKE_WORD(can_data->data[6], can_data->data[7])) * 10);
//    inner_can_reply_msg_ate_dchg_curr_over_alm_set(can_data, func_code);
    return 0;
}

// 故障参数标定0x1016XXE0
#define ATE_SET_CELL_TEMP_MIN_VAL  (0)
#define ATE_SET_CELL_TEMP_MAX_VAL  (165)
static bool inner_can_rx_ate_cell_temp_over_alm_set(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *p_bms_attr = get_bms_attr();

    int32_t tmp = 0;
    
    if (can_data->data[0] <= ATE_SET_CELL_TEMP_MAX_VAL)
    {
        tmp = (int32_t)((int8_t)can_data->data[0]) * 10 - DEFAULT_TEMP_VAL_OFFSET;
        if (tmp != p_bms_attr->safety.chg_over_temp_protect.appear_value)
        {
            data_store_save_bms_attr_thre_val(SET_THRE_CHG_OVER_TEMP_PROT, tmp);

        }
    }
    
    if (can_data->data[1] <= ATE_SET_CELL_TEMP_MAX_VAL)
    {
        tmp = (int32_t)((int8_t)can_data->data[1]) * 10 - DEFAULT_TEMP_VAL_OFFSET;
        if (tmp != p_bms_attr->safety.chg_over_temp_protect.cancel_value)
        {
            data_store_save_bms_attr_thre_val(SET_THRE_CHG_OVER_TEMP_PROT_DIS, tmp);

        }
    }

    if (can_data->data[2] <= ATE_SET_CELL_TEMP_MAX_VAL)
    {
        tmp = (int32_t)((int8_t)can_data->data[2]) * 10 - DEFAULT_TEMP_VAL_OFFSET;
        if (tmp != p_bms_attr->safety.chg_over_temp_alarm.appear_value)
        {
            data_store_save_bms_attr_thre_val(SET_THRE_CHG_OVER_TEMP_ALRM, tmp);

        }
    }
    if (can_data->data[3] <= ATE_SET_CELL_TEMP_MAX_VAL)
    {
        tmp = (int32_t)((int8_t)can_data->data[3]) * 10 - DEFAULT_TEMP_VAL_OFFSET;
        if (tmp != p_bms_attr->safety.chg_over_temp_alarm.cancel_value)
        {
            data_store_save_bms_attr_thre_val(SET_THRE_CHG_OVER_TEMP_ALRM_DIS, tmp);

        }
    }
    
    if (can_data->data[4] <= ATE_SET_CELL_TEMP_MAX_VAL)
    {
        tmp = (int32_t)((int8_t)can_data->data[4]) * 10 - DEFAULT_TEMP_VAL_OFFSET;
        if (tmp != p_bms_attr->safety.dchg_over_temp_protect.appear_value)
        {
            data_store_save_bms_attr_thre_val(SET_THRE_DCHG_OVER_TEMP_PROT, tmp);

        }
    }

    if (can_data->data[5] <= ATE_SET_CELL_TEMP_MAX_VAL)
    {
        tmp = (int32_t)((int8_t)can_data->data[5]) * 10 - DEFAULT_TEMP_VAL_OFFSET;
        if (tmp != p_bms_attr->safety.dchg_over_temp_protect.cancel_value)
        {
            data_store_save_bms_attr_thre_val(SET_THRE_DCHG_OVER_TEMP_PROT_DIS, tmp);

        }
    }
    
    if (can_data->data[6] <= ATE_SET_CELL_TEMP_MAX_VAL)
    {
        tmp = (int32_t)((int8_t)can_data->data[6]) * 10 - DEFAULT_TEMP_VAL_OFFSET;
        if (tmp != p_bms_attr->safety.dchg_over_temp_alarm.appear_value)
        {
            data_store_save_bms_attr_thre_val(SET_THRE_DCHG_OVER_TEMP_ALRM, tmp);

        }
    }

    if (can_data->data[7] <= ATE_SET_CELL_TEMP_MAX_VAL)
    {
        tmp = (int32_t)((int8_t)can_data->data[7]) * 10 - DEFAULT_TEMP_VAL_OFFSET;
        if (tmp != p_bms_attr->safety.dchg_over_temp_alarm.cancel_value)
        {
            data_store_save_bms_attr_thre_val(SET_THRE_DCHG_OVER_TEMP_ALRM_DIS, tmp);

        }
    }

    SET_BIT(g_bmu_thre_val_sync_flag, 1 << BMU_THRE_SYNC_CELL_TEMP_OVER_ALM);

    inner_can_reply_msg_ate_cell_temp_over_alm_set(can_data, func_code);
    return 0;
}

// 故障参数标定0x1017XXE0
static bool inner_can_rx_ate_cell_temp_under_alm_set(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *p_bms_attr = get_bms_attr();
    int32_t tmp = 0;
    
    if (can_data->data[0] <= ATE_SET_CELL_TEMP_MAX_VAL)
    {
        tmp = (int32_t)((int8_t)can_data->data[0]) * 10 - DEFAULT_TEMP_VAL_OFFSET;
        if (tmp != p_bms_attr->safety.chg_under_temp_protect.appear_value)
        {
            data_store_save_bms_attr_thre_val(SET_THRE_CHG_UNDER_TEMP_PROT, tmp);

        }
    }
    
    if (can_data->data[1] <= ATE_SET_CELL_TEMP_MAX_VAL)
    {
        tmp = (int32_t)((int8_t)can_data->data[1]) * 10 - DEFAULT_TEMP_VAL_OFFSET;
        if (tmp != p_bms_attr->safety.chg_under_temp_protect.cancel_value)
        {
            data_store_save_bms_attr_thre_val(SET_THRE_CHG_UNDER_TEMP_PROT_DIS, tmp);

        }
    }

    if (can_data->data[2] <= ATE_SET_CELL_TEMP_MAX_VAL)
    {
        tmp = (int32_t)((int8_t)can_data->data[2]) * 10 - DEFAULT_TEMP_VAL_OFFSET;
        if (tmp != p_bms_attr->safety.chg_under_temp_alarm.appear_value)
        {
            data_store_save_bms_attr_thre_val(SET_THRE_CHG_UNDER_TEMP_ALRM, tmp);

        }
    }
    if (can_data->data[3] <= ATE_SET_CELL_TEMP_MAX_VAL)
    {
        tmp = (int32_t)((int8_t)can_data->data[3]) * 10 - DEFAULT_TEMP_VAL_OFFSET;
        if (tmp != p_bms_attr->safety.chg_under_temp_alarm.cancel_value)
        {
            data_store_save_bms_attr_thre_val(SET_THRE_CHG_UNDER_TEMP_ALRM_DIS, tmp);

        }
    }
    
    if (can_data->data[4] <= ATE_SET_CELL_TEMP_MAX_VAL)
    {
        tmp = (int32_t)((int8_t)can_data->data[4]) * 10 - DEFAULT_TEMP_VAL_OFFSET;
        if (tmp != p_bms_attr->safety.dchg_under_temp_protect.appear_value)
        {
            data_store_save_bms_attr_thre_val(SET_THRE_DCHG_UNDER_TEMP_PROT, tmp);

        }
    }

    if (can_data->data[5] <= ATE_SET_CELL_TEMP_MAX_VAL)
    {
        tmp = (int32_t)((int8_t)can_data->data[5]) * 10 - DEFAULT_TEMP_VAL_OFFSET;
        if (tmp != p_bms_attr->safety.dchg_under_temp_protect.cancel_value)
        {
            data_store_save_bms_attr_thre_val(SET_THRE_DCHG_UNDER_TEMP_PROT_DIS, tmp);

        }
    }
    
    if (can_data->data[6] <= ATE_SET_CELL_TEMP_MAX_VAL)
    {
        tmp = (int32_t)((int8_t)can_data->data[6]) * 10 - DEFAULT_TEMP_VAL_OFFSET;
        if (tmp != p_bms_attr->safety.dchg_under_temp_alarm.appear_value)
        {
            data_store_save_bms_attr_thre_val(SET_THRE_DCHG_UNDER_TEMP_ALRM, tmp);

        }
    }

    if (can_data->data[7] <= ATE_SET_CELL_TEMP_MAX_VAL)
    {
        tmp = (int32_t)((int8_t)can_data->data[7]) * 10 - DEFAULT_TEMP_VAL_OFFSET;
        if (tmp != p_bms_attr->safety.dchg_under_temp_alarm.cancel_value)
        {
            data_store_save_bms_attr_thre_val(SET_THRE_DCHG_UNDER_TEMP_ALRM_DIS, tmp);

        }
    }
    

    SET_BIT(g_bmu_thre_val_sync_flag, 1 << BMU_THRE_SYNC_CELL_TEMP_UNDER_ALM);


    inner_can_reply_msg_ate_cell_temp_under_alm_set(can_data, func_code);
    return 0;
}

// 故障参数标定0x1019XXE0
static bool inner_can_rx_ate_soc_low_alm_set(can_frame_data_t *can_data, uint16_t func_code)
{
    data_store_save_bms_attr_thre_val(SET_THRE_SOC_UNDER_ALRM, (int32_t)(MAKE_WORD(can_data->data[4], can_data->data[5])) * 1000);
    data_store_save_bms_attr_thre_val(SET_THRE_SOC_UNDER_ALRM_DIS, (int32_t)(MAKE_WORD(can_data->data[6], can_data->data[7])) * 1000);
    inner_can_reply_msg_ate_soc_low_alm_set(can_data, func_code);
    return 0;
}

static bool inner_can_rx_ate_bat_curr_over_alm_2_set(can_frame_data_t *can_data, uint16_t func_code)
{
//    data_store_save_bms_attr_thre_val(SET_THRE_DCHG_OVER_CUR_PROT2, (int32_t)(MAKE_WORD(can_data->data[4], can_data->data[5])) * 10);
//    data_store_save_bms_attr_thre_val(SET_THRE_DCHG_OVER_CUR_PROT2_DIS, (int32_t)(MAKE_WORD(can_data->data[6], can_data->data[7])) * 10);
//    inner_can_reply_msg_ate_bat_curr_over_alm_2_set(can_data, func_code);
    return 0;
}

// 故障参数标定0x101CXXE0 单体超限产生阈值
static bool inner_can_rx_ate_cell_volt_err_alm_set(can_frame_data_t *can_data, uint16_t func_code)
{
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_VOLT_OVER_SERIOUS, (int32_t)(MAKE_WORD(can_data->data[0], can_data->data[1])));
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_VOLT_OVER_SERIOUS_DIS, (int32_t)(MAKE_WORD(can_data->data[2], can_data->data[3])));
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_VOLT_UNDER_SERIOUS, (int32_t)(MAKE_WORD(can_data->data[4], can_data->data[5])));
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_VOLT_UNDER_SERIOUS_DIS, (int32_t)(MAKE_WORD(can_data->data[6], can_data->data[7])));
    inner_can_reply_msg_ate_cell_volt_err_alm_set(can_data, func_code);
    return 0;
}

// 故障参数标定0x1080XXE0 单体过充/过放提示
static bool inner_can_rx_msg_ate_cell_volt_tip_set(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *p_bms_attr = get_bms_attr();

    int32_t tmp = (MAKE_WORD(can_data->data[0], can_data->data[1]));
    if (tmp != p_bms_attr->safety.cell_over_vol_tip.appear_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_CELL_OVER_VOLT_TIP, tmp);

    }
    
    tmp = (MAKE_WORD(can_data->data[2], can_data->data[3]));
    if (tmp != p_bms_attr->safety.cell_over_vol_tip.cancel_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_CELL_OVER_VOLT_TIP_DIS, tmp);

    }
    
    tmp = (MAKE_WORD(can_data->data[4], can_data->data[5]));
    if (tmp != p_bms_attr->safety.cell_under_vol_tip.appear_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_CELL_UNDER_VOLT_TIP, tmp);
 
    }
    
    tmp = (MAKE_WORD(can_data->data[6], can_data->data[7]));
    if (tmp != p_bms_attr->safety.cell_under_vol_tip.cancel_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_CELL_UNDER_VOLT_TIP_DIS, tmp);

    }

    SET_BIT(g_bmu_thre_val_sync_flag, 1 << BMU_THRE_SYNC_CELL_VOLT_TIP);



    inner_can_reply_msg_ate_cell_volt_tip_set(can_data, func_code);
    return 0;
}

// 故障参数标定0x1081XXE0 单体压差过大阈值1
static bool inner_can_rx_msg_ate_cell_volt_diff_1_set(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *p_bms_attr = get_bms_attr();

    int32_t tmp = (MAKE_WORD(can_data->data[0], can_data->data[1]));
    if (tmp != p_bms_attr->safety.cell_volt_diff_tip.appear_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_CELL_VOLT_DIFF_TIP, tmp);

    }
    
    tmp = (MAKE_WORD(can_data->data[2], can_data->data[3]));
    if (tmp != p_bms_attr->safety.cell_volt_diff_tip.cancel_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_CELL_VOLT_DIFF_TIP_DIS, tmp);

    }
    
    tmp = (MAKE_WORD(can_data->data[4], can_data->data[5]));
    if (tmp != p_bms_attr->safety.cell_volt_diff_alarm.appear_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_CELL_VOLT_DIFF_ALRM, tmp);

    }
    
    tmp = (MAKE_WORD(can_data->data[6], can_data->data[7]));
    if (tmp != p_bms_attr->safety.cell_volt_diff_alarm.cancel_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_CELL_VOLT_DIFF_ALRM_DIS, tmp);

    }

    SET_BIT(g_bmu_thre_val_sync_flag, 1 << BMU_THRE_SYNC_CELL_VOLT_DIFF1);

    
    inner_can_reply_msg_ate_cell_volt_diff_1_set(can_data, func_code);
    return 0;
}

// 故障参数标定0x1082XXE0 单体压差过大阈值2
static bool inner_can_rx_msg_ate_cell_volt_diff_2_set(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *p_bms_attr = get_bms_attr();

    int32_t tmp = (MAKE_WORD(can_data->data[0], can_data->data[1]));
    if (tmp != p_bms_attr->safety.cell_volt_diff_protect.appear_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_CELL_VOLT_DIFF_PROT, tmp);

    }
    
    tmp = (MAKE_WORD(can_data->data[2], can_data->data[3]));
    if (tmp != p_bms_attr->safety.cell_volt_diff_protect.cancel_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_CELL_VOLT_DIFF_PROT_DIS, tmp);

    }
    

    SET_BIT(g_bmu_thre_val_sync_flag, 1 << BMU_THRE_SYNC_CELL_VOLT_DIFF2);
    


    inner_can_reply_msg_ate_cell_volt_diff_2_set(can_data, func_code);
    return 0;
}

// 故障参数标定0x1083XXE0 充放电高低温提示
static bool inner_can_rx_msg_ate_cell_temp_tip_set(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *p_bms_attr = get_bms_attr();

    int32_t tmp = 0;
    
    if (can_data->data[0] <= ATE_SET_CELL_TEMP_MAX_VAL)
    {
        tmp = (int32_t)((int8_t)can_data->data[0]) * 10 - DEFAULT_TEMP_VAL_OFFSET;
        if (tmp != p_bms_attr->safety.chg_over_temp_tip.appear_value)
        {
            data_store_save_bms_attr_thre_val(SET_THRE_CHG_OVER_TEMP_TIP, tmp);

        }
    }
    
    if (can_data->data[1] <= ATE_SET_CELL_TEMP_MAX_VAL)
    {
        tmp = (int32_t)((int8_t)can_data->data[1]) * 10 - DEFAULT_TEMP_VAL_OFFSET;
        if (tmp != p_bms_attr->safety.chg_over_temp_tip.cancel_value)
        {
            data_store_save_bms_attr_thre_val(SET_THRE_CHG_OVER_TEMP_TIP_DIS, tmp);

        }
    }
    
    if (can_data->data[2] <= ATE_SET_CELL_TEMP_MAX_VAL)
    {
        tmp = (int32_t)((int8_t)can_data->data[2]) * 10 - DEFAULT_TEMP_VAL_OFFSET;
        if (tmp != p_bms_attr->safety.chg_under_temp_tip.appear_value)
        {
            data_store_save_bms_attr_thre_val(SET_THRE_CHG_UNDER_TEMP_TIP, tmp);

        }
    }
    
    if (can_data->data[3] <= ATE_SET_CELL_TEMP_MAX_VAL)
    {
        tmp = (int32_t)((int8_t)can_data->data[3]) * 10 - DEFAULT_TEMP_VAL_OFFSET;
        if (tmp != p_bms_attr->safety.chg_under_temp_tip.cancel_value)
        {
            data_store_save_bms_attr_thre_val(SET_THRE_CHG_UNDER_TEMP_TIP_DIS, tmp);
    
        }
    }
    
    if (can_data->data[4] <= ATE_SET_CELL_TEMP_MAX_VAL)
    {
        tmp = (int32_t)((int8_t)can_data->data[4]) * 10 - DEFAULT_TEMP_VAL_OFFSET;
        if (tmp != p_bms_attr->safety.dchg_over_temp_tip.appear_value)
        {
            data_store_save_bms_attr_thre_val(SET_THRE_DCHG_OVER_TEMP_TIP, tmp);
     
        }
    }
    if (can_data->data[5] <= ATE_SET_CELL_TEMP_MAX_VAL)
    {
        tmp = (int32_t)((int8_t)can_data->data[5]) * 10 - DEFAULT_TEMP_VAL_OFFSET;
        if (tmp != p_bms_attr->safety.dchg_over_temp_tip.cancel_value)
        {
            data_store_save_bms_attr_thre_val(SET_THRE_DCHG_OVER_TEMP_TIP_DIS, tmp);
        
        }
    }
    
    if (can_data->data[6] <= ATE_SET_CELL_TEMP_MAX_VAL)
    {
        tmp = (int32_t)((int8_t)can_data->data[6]) * 10 - DEFAULT_TEMP_VAL_OFFSET;
        if (tmp != p_bms_attr->safety.dchg_under_temp_tip.appear_value)
        {
            data_store_save_bms_attr_thre_val(SET_THRE_DCHG_UNDER_TEMP_TIP, tmp);
       
        }
    }
    if (can_data->data[7] <= ATE_SET_CELL_TEMP_MAX_VAL)
    {
        tmp = (int32_t)((int8_t)can_data->data[7]) * 10 - DEFAULT_TEMP_VAL_OFFSET;
        if (tmp != p_bms_attr->safety.dchg_under_temp_tip.cancel_value)
        {
            data_store_save_bms_attr_thre_val(SET_THRE_DCHG_UNDER_TEMP_TIP_DIS, tmp);
         
        }
    }

    SET_BIT(g_bmu_thre_val_sync_flag, 1 << BMU_THRE_SYNC_CELL_TEMP_TIP);

    inner_can_reply_msg_ate_cell_temp_tip_set(can_data, func_code);
    return 0;
}

// 故障参数标定0x1084XXE0 电芯温差大提示告警保护
static bool inner_can_rx_msg_ate_cell_temp_diff_set(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *p_bms_attr = get_bms_attr();

    int32_t tmp = 0;
    
    tmp = (int32_t)((int8_t)can_data->data[0]) * 10;
    if (tmp != p_bms_attr->safety.cell_temp_diff_tip.appear_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_CELL_TEMP_DIFF_TIP, tmp);
  
    }

    tmp = (int32_t)((int8_t)can_data->data[1]) * 10;
    if (tmp != p_bms_attr->safety.cell_temp_diff_tip.cancel_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_CELL_TEMP_DIFF_TIP_DIS, tmp);
  
    }
    
    tmp = (int32_t)((int8_t)can_data->data[2]) * 10;
    if (tmp != p_bms_attr->safety.cell_temp_diff_alarm.appear_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_CELL_TEMP_DIFF_ALRM, tmp);
   
    }
    
    tmp = (int32_t)((int8_t)can_data->data[3]) * 10;
    if (tmp != p_bms_attr->safety.cell_temp_diff_alarm.cancel_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_CELL_TEMP_DIFF_ALRM_DIS, tmp);
    
    }

    tmp = (int32_t)((int8_t)can_data->data[4]) * 10;
    if (tmp != p_bms_attr->safety.cell_temp_diff_protect.appear_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_CELL_TEMP_DIFF_PROT, tmp);
    
    }
    
    tmp = (int32_t)((int8_t)can_data->data[5]) * 10;
    if (tmp != p_bms_attr->safety.cell_temp_diff_protect.cancel_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_CELL_TEMP_DIFF_PROT_DIS, tmp);
      
    }

    SET_BIT(g_bmu_thre_val_sync_flag, 1 << BMU_THRE_SYNC_CELL_TEMP_DIFF);

    inner_can_reply_msg_ate_cell_temp_diff_set(can_data, func_code);
    return 0;
}

// 故障参数标定0x1085XXE0 总压过充过放提示
static bool inner_can_rx_msg_ate_batt_volt_tip_set(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *p_bms_attr = get_bms_attr();

    int32_t tmp = (MAKE_WORD(can_data->data[0], can_data->data[1])) * 100;
    if (tmp != p_bms_attr->safety.total_over_vol_tip.appear_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_TOTAL_OVER_VOLT_TIP, tmp);
      
    }
    
    tmp = (MAKE_WORD(can_data->data[2], can_data->data[3])) * 100;
    if (tmp != p_bms_attr->safety.total_over_vol_tip.cancel_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_TOTAL_OVER_VOLT_TIP_DIS, tmp);
      
    }
    
    tmp = (MAKE_WORD(can_data->data[4], can_data->data[5])) * 100;
    if (tmp != p_bms_attr->safety.total_under_vol_tip.appear_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_TOTAL_UNDER_VOLT_TIP, tmp);
      
    }

    tmp = (MAKE_WORD(can_data->data[6], can_data->data[7])) * 100;
    if (tmp != p_bms_attr->safety.total_under_vol_tip.cancel_value)
    {
        data_store_save_bms_attr_thre_val(SET_THRE_TOTAL_UNDER_VOLT_TIP_DIS, tmp);
       
    }

    SET_BIT(g_bmu_thre_val_sync_flag, 1 << BMU_THRE_SYNC_BAT_VOLT_TIP);

    inner_can_reply_msg_ate_batt_volt_tip_set(can_data, func_code);
    return 0;
}

// 0x01F: ATE Flash测试：0x101FXXE0
static bool inner_can_rx_ate_flash_test(can_frame_data_t *can_data, uint16_t func_code)
{
    if (can_data->data[0] == 0) // 读取
    {
        inner_can_reply_msg_ate_flash_test(can_data, func_code);
    }
    else if (can_data->data[0] == 1) // 写入
    {
        if (!special_mode_get(ATUO_TEST))
        {
            return 0;
        }
        if (can_data->data_len != CAN_MAX_DATA_LEN_ONE_FRAME)
        {
            return 0;
        }
        bms_runing_data_t bms_data = *get_bms_runing_data();
        for (uint8_t i = 1; i < CAN_MAX_DATA_LEN_ONE_FRAME; i++)
        {
            bms_data.flash_data[i - 1] = can_data->data[i];
        }
        bms_runing_data_deal(bms_data,true);
    }
    return 0;
}

// 0x020:上位机控制0x1020XXYY  / 0x1020XXYY  (YY为上位机设备或者PCS ：0xE0 或 0x41等)
static bool inner_can_rx_ate_set_old_mode(can_frame_data_t *can_data, uint16_t func_code)
{
//    uint8_t check_sum = 0;
//    uint8_t data_id[4] = {0};
//    data_id[0] = can_data->id & 0xFF;
//    data_id[1] = (can_data->id >> 8) & 0xFF ;
//    data_id[2] = (can_data->id >> 16) & 0xFF;
//    data_id[3] = (can_data->id >> 24) & 0xFF;
//    check_sum += data_id[0] + data_id[1] + data_id[2] + data_id[3];
//    for (uint8_t i = 0; i < 7; i++)
//    {
//        check_sum += can_data->data[i];
//    }
//    if (check_sum != can_data->data[7])
//    {
//        return 0;
//    }
    aging_mode_request(can_data->data[0]);
    cali_mode_request(can_data->data[1]);
    ate_mode_request(can_data->data[2]);
    force_ctrl_mode_request(can_data->data[4]);
    cali_resume_default(can_data->data[5]);
//    set_bmu_addr(can_data->data[7];);

    
    // 存储产测进行步骤
    if (special_mode_get(ATUO_TEST))
    {
        bms_runing_data_t bms_data = *get_bms_runing_data();
        bms_data.ate_step = can_data->data[7];
        bms_runing_data_deal(bms_data,true);            
    }

    inner_can_reply_msg_ate_set_old_mode(can_data, func_code);
    
    return 0;
}

// 参数标定0x1021XXE0
static bool inner_can_rx_ate_bal_heat_param_set(can_frame_data_t *can_data, uint16_t func_code)
{
    // if (!special_mode_get(CALI_PARM))
    // {
    //     return 0;
    // }
    data_store_save_bms_attr_thre_val(SET_THRE_BAL_VOL, (int32_t)(MAKE_WORD(can_data->data[0], can_data->data[1])));
    data_store_save_bms_attr_thre_val(SET_THRE_BAL_VOL_DIFF, (int32_t)(MAKE_WORD(can_data->data[2], can_data->data[3])));
    data_store_save_bms_attr_thre_val(SET_THRE_FULL_CHG_VOL, (int32_t)(MAKE_WORD(can_data->data[4], can_data->data[5])));
//    data_store_save_bms_attr_thre_val(SET_THRE_HEAT_OPEN_TEMP, (int32_t)(can_data->data[6]) * 10 - DEFAULT_TEMP_VAL_OFFSET);
//    data_store_save_bms_attr_thre_val(SET_THRE_HEAT_CLOSE_TEMP, (int32_t)(can_data->data[7]) * 10 - DEFAULT_TEMP_VAL_OFFSET);
    inner_can_reply_msg_ate_bal_heat_param_set(can_data, func_code);
    return 0;
}

// 参数标定0x1022XXE0
static bool inner_can_rx_ate_cell_volt_curr_limit_set(can_frame_data_t *can_data, uint16_t func_code)
{
    // if (!special_mode_get(CALI_PARM))
    // {
    //     return 0;
    // }
    data_store_save_bms_attr_thre_val(SET_THRE_CHG_STOP_VOL, (int32_t)(MAKE_WORD(can_data->data[0], can_data->data[1]) * 100));
    data_store_save_bms_attr_thre_val(SET_THRE_CHG_STOP_CUR, (int32_t)(MAKE_WORD(can_data->data[2], can_data->data[3]) * 10));
    inner_can_reply_msg_ate_cell_volt_curr_limit_set(can_data, func_code);
    return 0;
}

// 参数标定0x1023XXE0
static bool inner_can_rx_ate_cell_num_set(can_frame_data_t *can_data, uint16_t func_code)
{
    // if (!special_mode_get(CALI_PARM))
    // {
    //     return 0;
    // }
    data_store_save_bms_attr_thre_val(SET_THRE_RATE_CAP, (int32_t)(MAKE_WORD(can_data->data[0], can_data->data[1])));
    data_store_save_bms_attr_thre_val(SET_THRE_MONO_VOL_NUM, (int32_t)(MAKE_WORD(can_data->data[2], can_data->data[3])));
    data_store_save_bms_attr_thre_val(SET_THRE_MONO_TEMP_NUM, (int32_t)(MAKE_WORD(can_data->data[4], can_data->data[5])));
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_NUM, (int32_t)(MAKE_WORD(can_data->data[2], can_data->data[3]))); // 当前协议不加，与电芯电压个数是一样的
    inner_can_reply_msg_ate_cell_num_set(can_data, func_code);
    return 0;
}

// 参数标定0x1024XXE0
static bool inner_can_rx_ate_chg_dsg_cap_set(can_frame_data_t *can_data, uint16_t func_code)
{
    // if (!special_mode_get(CALI_PARM))
    // {
    //     return 0;
    // }
    uint32_t data_tmp = 0;
    data_tmp = can_data->data[0] | can_data->data[1] << 8 | can_data->data[2] << 16 | can_data->data[3] << 24;
    data_store_save_bms_attr_thre_val(SET_THRE_ADD_CAP_CHG, (int32_t)(data_tmp / 1000));
    data_tmp = can_data->data[4] | can_data->data[5] << 8 | can_data->data[6] << 16 | can_data->data[7] << 24;
    data_store_save_bms_attr_thre_val(SET_THRE_ADD_CAP_DCHG, (int32_t)(data_tmp / 1000));
    inner_can_reply_msg_ate_chg_dsg_cap_set(can_data, func_code);
    return 0;
}

// 参数标定0x1025XXE0
static bool inner_can_rx_ate_sox_set(can_frame_data_t *can_data, uint16_t func_code)
{
    // if (!special_mode_get(CALI_PARM))
    // {
    //     return 0;
    // }
    data_store_save_bms_attr_thre_val(SET_THRE_SOC, (int32_t)(MAKE_WORD(can_data->data[0], can_data->data[1])));
    data_store_save_bms_attr_thre_val(SET_THRE_SOH, (int32_t)can_data->data[6]);
    // 剩余容量, 满充容量 无需设置
    inner_can_reply_msg_ate_sox_set(can_data, func_code);
    return 0;
}

// 时间标定0x1026FFE0
static bool inner_can_rx_ate_sys_time_set(can_frame_data_t *can_data, uint16_t func_code)
{
    sdk_rtc_t rtc_time = {0};
    bms_runing_data_t bms_data = {0};

    rtc_time.tm_year = can_data->data[0];
    rtc_time.tm_mon  = can_data->data[1];
    rtc_time.tm_day  = can_data->data[2];
    rtc_time.tm_hour = can_data->data[3];
    rtc_time.tm_min  = can_data->data[4];
    rtc_time.tm_sec  = can_data->data[5];
    sdk_rtc_set(RTC_BIN_FORMAT, &rtc_time);
    {
        bms_data = *get_bms_runing_data();
        bms_data.rtc_data[0] = rtc_time.tm_year;
        bms_data.rtc_data[1] = rtc_time.tm_mon;
        bms_data.rtc_data[2] = rtc_time.tm_day;
        bms_data.rtc_data[3] = rtc_time.tm_hour;
        bms_data.rtc_data[4] = rtc_time.tm_min;
        bms_data.rtc_data[5] = rtc_time.tm_sec;
        bms_runing_data_deal(bms_data,false);
    }
    inner_can_reply_msg_ate_sys_time_set(can_data, func_code);
    return 0;
}

// PACK_SN标定0x1027FFE0
static bool inner_can_rx_ate_pack_sn_set(can_frame_data_t *can_data, uint16_t func_code)
{
    // if (!special_mode_get(CALI_PARM))
    // {
    //     return 0;
    // }
    uint8_t sn_len = sizeof(get_bms_attr()->pack_sn); // pack_sn后面需要修改uint8_t
    uint8_t sn_cnt = (sn_len + PACK_SN_IN_FRAME_LEN - 1) / PACK_SN_IN_FRAME_LEN;
    uint8_t frame_len = 0;
    if (can_data->data[0] + 1 == sn_cnt)
    {
        frame_len = ((sn_len % PACK_SN_IN_FRAME_LEN) == 0) ? PACK_SN_IN_FRAME_LEN : sn_len % PACK_SN_IN_FRAME_LEN;
    }
    else if (can_data->data[0] < sn_cnt)
    {
        frame_len = PACK_SN_IN_FRAME_LEN;
    }
    else
    {
        return 0;
    }
    bms_attr_t bms_attr_data = {0};
    bms_attr_data = *get_bms_attr();

    for (uint8_t i = 0; i < frame_len; i++)
    {
        bms_attr_data.pack_sn[can_data->data[0] * PACK_SN_IN_FRAME_LEN + i] = can_data->data[i + 1];
    }

    data_store_save_bms_attr(ST_VAR_POS(bms_attr_t,pack_sn), (uint8_t *)(bms_attr_data.pack_sn), ST_VAR_SIZE( bms_attr_t, pack_sn ) );

    if (can_data->data[0] + 1 == sn_cnt)
    {
        inner_can_reply_msg_ate_pack_sn_set(can_data, func_code);
    }
    return 0;
}

// BOARD_SN标定0x1028FFE0
static bool inner_can_rx_ate_board_sn_set(can_frame_data_t *can_data, uint16_t func_code)
{
    // if (!special_mode_get(CALI_PARM))
    // {
    //     return 0;
    // }
    uint8_t sn_len = sizeof(get_bms_attr()->board_sn); // board_sn后面需要修改uint8_t
    uint8_t sn_cnt = (sn_len + BOARD_SN_IN_FRAME_LEN - 1) / BOARD_SN_IN_FRAME_LEN;
    uint8_t frame_len = 0;
    if (can_data->data[0] + 1 == sn_cnt)
    {
        frame_len = ((sn_len % BOARD_SN_IN_FRAME_LEN) == 0) ? BOARD_SN_IN_FRAME_LEN : sn_len % BOARD_SN_IN_FRAME_LEN;
    }
    else if (can_data->data[0] < sn_cnt)
    {
        frame_len = BOARD_SN_IN_FRAME_LEN;
    }
    else
    {
        return 0;
    }
    bms_attr_t bms_attr_data = {0};
    bms_attr_data = *get_bms_attr();

    for (uint8_t i = 0; i < frame_len; i++)
    {
        bms_attr_data.board_sn[can_data->data[0] * BOARD_SN_IN_FRAME_LEN + i] = can_data->data[i + 1];
    }
    data_store_save_bms_attr(ST_VAR_POS(bms_attr_t,board_sn), (uint8_t *)(bms_attr_data.board_sn), ST_VAR_SIZE( bms_attr_t, board_sn ) );
    if (can_data->data[0] + 1 == sn_cnt)
    {
        inner_can_reply_msg_ate_board_sn_set(can_data, func_code);
    }
    return 0;
}

// 设置电池信息0x1029FFE0
static bool inner_can_rx_ate_cell_info_set(can_frame_data_t *can_data, uint16_t func_code)
{
    // cbs5000不使用
    return 0;
}

// 校准系数标定0x102AXXE0
static bool inner_can_rx_ate_cali_param_set(can_frame_data_t *can_data, uint16_t func_code)
{
    // if (!special_mode_get(CALI_PARM))
    // {
    //     return 0;
    // }
    uint16_t cali_id = can_data->data[0];
    uint16_t cali_value = MAKE_WORD(can_data->data[1], can_data->data[2]);
    adjust_para_tab_e adjust_id = ADJUST_PARA_NUM;
    if (1 == cali_id)
    {
        adjust_id = BALANCE_VOLT_GAIN;
    }
    else if (3 == cali_id)
    {
        adjust_id = CHG_CURR_GAIN;
    }
    else if (5 == cali_id)
    {
        adjust_id = DSG_CURR_GAIN;
    }
    else
    {
        return 0;
    }
    g_cali_data_type = cali_id;
    g_cali_data_result = 0x55;
    adjust_para_tab_t adjust_para_tab ={0};    //BMU安全参数表的复制体
    memcpy(&adjust_para_tab, &get_bms_attr()->adjust, sizeof(adjust_para_tab_t));
    int ret = sample_adjust_cali_deal((adjust_para_tab_e)adjust_id, cali_value, &adjust_para_tab); // 电流单位10mA。电压单位0.1V
    if(0 == ret)
    {
        ret = sample_adjust_set(&adjust_para_tab);
        if(0 == ret)
        {
            data_store_save_adjust_para(&adjust_para_tab);
            g_cali_data_result = 0xAA;
        }
    }
    inner_can_reply_msg_ate_cali_param_set(can_data, func_code);
    return 0;
}

// 0x02B:BMS功能开关0x102BXXE0
static bool inner_can_rx_ate_bmu_func_set(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t crc_check = can_single_frame_crc8_calc(can_data, ATE_CONTROL_CRC8_MASK);
    if (crc_check != can_data->data[7])
    {
        return 0;
    }
//    uint8_t force_ctl = can_data->data[6];
    if (can_data->data[0] != 0)
    {
        ate_ctl_can_set(ATE_FUNC_SW_CTL_1, can_data->data[0]);  // 
    }
    
    if (can_data->data[1] != 0)
    {
        ate_ctl_can_set(ATE_FUNC_SW_CTL_2, can_data->data[1]);  // 
    }

    inner_can_reply_msg_ate_bmu_func_set(can_data, func_code);
    return 0;
}

// 0x02C:上位机监控读取0x102CXXE0
static bool inner_can_rx_ate_monitor_data_read(can_frame_data_t *can_data, uint16_t func_code)
{
    if (can_data->data[0] == 0)
    {
        module_inner_can_send_msg(can_data, (module_request_send_group_e)can_data->data[1], false);
    }
    else
    {
        func_inner_can_send_msg(can_data, can_data->data[0]);
    }
    return 0;
}

// 0x02D:一键读取历史故障0x102DXXE0
static bool inner_can_rx_ate_clr_history_data(can_frame_data_t *can_data, uint16_t func_code)
{
    if (can_data->data[0] == 0xAA) // 清空历史故障
    {
        sdk_record_delete(NORMAL_RECORD);
        // 运行日志当前不删除（接口在core）
    }
    return 0;
}

// 0x02E:一键操作标定参数0x102EXXE0
static bool inner_can_rx_ate_read_set_data(can_frame_data_t *can_data, uint16_t func_code)
{
    #define DEFAULT_OFFSET_TO_FRAME_ID (3)
    const uint8_t ate_map_frame_id[] =
    {
        ATE_CELL_VOLT_OVER_ALM_SET  ,
        ATE_BAT_VOLT_OVER_ALM_SET   ,
        ATE_CELL_VOLT_UNDER_ALM_SET ,
        ATE_BAT_VOLT_UNDER_ALM_SET  ,
        ATE_CHG_CURR_OVER_ALM_SET   ,
        ATE_DCHG_CURR_OVER_ALM_SET  ,
        ATE_CELL_TEMP_OVER_ALM_SET  ,
        ATE_CELL_TEMP_UNDER_ALM_SET ,
        INNER_MSG_CNT,  // 不处理
        ATE_SOC_LOW_ALM_SET         ,
        INNER_MSG_CNT,  // 不处理
        ATE_BAL_HEAT_PARAM_SET      ,
        ATE_CELL_VOLT_CURR_LIMIT_SET,
        ATE_CELL_NUM_SET            ,
        ATE_CHG_DSG_CAP_SET         ,
        ATE_SOX_SET                 ,
        ATE_SYS_TIME_SET            ,
        ATE_PACK_SN_SET             ,
        ATE_BOARD_SN_SET            ,
        ATE_READ_SET_DATA           ,
        ATE_CELL_INFO_SET           ,
        ATE_BAT_CURR_OVER_ALM_2_SET ,
        ATE_CELL_VOLT_ERR_ALM_SET   ,
        ATE_FLASH_TEST              ,
        ATE_SET_OLD_MODE            ,
        ATE_BMU_FUNC_SET            ,
        ATE_FORCE_CTL_SET           ,
        ATE_FORCE_CTL_SET_2         ,
        ATE_CELL_VOLT_TIP_SET        ,  // 单体电压过充、过放提示标定
        ATE_CELL_VOLT_DIFF_1_SET     ,  // 单体电压压差过大提示、告警标定
        ATE_CELL_VOLT_DIFF_2_SET     ,  // 单体电压压差过大故障标定
        ATE_CELL_TEMP_TIP_SET        ,  // 电芯温度充放电高低温提示标定
        ATE_CELL_TEMP_DIFF_SET       ,  // 电芯温差过大提示，告警、保护标定
        ATE_BATT_VOLT_TIP_SET        ,  // 总压过压欠压提示标定
    };

    uint8_t len = sizeof(ate_map_frame_id) / sizeof(ate_map_frame_id[0]);
    if (can_data->data[0] == 0x01) // 读所有数据
    {
        g_cali_para_result = ATE_CALI_READ_OK_RLT;
        for (uint8_t i = 0; i < len; i++)
        {
            inner_can_send_msg(can_data, (frame_data_id_e)ate_map_frame_id[i], true);
        }
        inner_can_send_msg(can_data, ATE_READ_SET_DATA, false);
    }
    else if (can_data->data[0] == 0x02) // 恢复所有数据
    {
        if (attr_data_resume_default_data() == 0)
        {
            g_cali_para_result = ATE_CALI_RECOVER_OK_RLT;
        }
        else
        {
            g_cali_para_result = ATE_CALI_RECOVER_ERR_RLT;
        }
        inner_can_send_msg(can_data, ATE_READ_SET_DATA, false);
    }
    else if (can_data->data[0] >= DEFAULT_OFFSET_TO_FRAME_ID)
    {
        uint8_t send_id = can_data->data[0] - DEFAULT_OFFSET_TO_FRAME_ID;
        if (send_id < len)
        {
            inner_can_send_msg(can_data, (frame_data_id_e)ate_map_frame_id[send_id], false);
        }
    }
    return 0;
}

// 0x02F:ATE强制控制指令0x102FXXE0
static bool inner_can_rx_ate_force_ctl_set(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t crc_check = can_single_frame_crc8_calc(can_data, ATE_CONTROL_CRC8_MASK);
    if (crc_check != can_data->data[7])
    {
        return 0;
    }


    if (can_data->data[0] != 0)
    {
        ate_ctl_can_set(ATE_CTL_ITEM_1, can_data->data[0]);   // 5v输出
    }
    else
    {
        inner_can_reply_msg_ate_force_ctl_set(can_data, func_code);
    }
    return 0;
}

// 0x01E:ATE强制控制指令0x101EXXE0
static bool inner_can_rx_ate_force_ctl_set_2(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t crc_check = can_single_frame_crc8_calc(can_data, ATE_CONTROL_CRC8_MASK);
    if (crc_check != can_data->data[7])
    {
        return 0;
    }

//    uint8_t force_ctl = can_data->data[6];
//    if (force_ctl == 0xAA)
//    {
//        ate_ctl_can_set(ATE_FUNC_CTL2, can_data->data[0]);
//    }
//    else
//    {
//        inner_can_reply_msg_ate_force_ctl_set_2(can_data, func_code);
//    }
    return 0;
}

// 请求发送帧
static void request_can_send_frame(can_frame_data_t frame_data, frame_data_id_e id, uint16_t *ready_flag_buff)
{
    if (id >= INNER_MSG_CNT || ready_flag_buff == NULL)
    {
        return;
    }
    uint8_t ready_flag_group_id = id / UINT16_BIT_NUM;
    uint8_t ready_flag_id = id % UINT16_BIT_NUM;
    if (ready_flag_buff[ready_flag_group_id] & (1 << ready_flag_id))
    {
        inner_can_send_msg_no_ready(&frame_data, id);
        // 由于外部请求发送，一般都是回复主机，所以目的地址默认为BCU，地址0x1F
        ready_flag_buff[ready_flag_group_id] &= ~(1 << ready_flag_id); // 清零
    }
}

// 请求发送处理任务,由于此函数10ms调用一次，每次检查5帧，防止一次性发送多帧
#define INNER_SEND_FRAME_NUM_ONE_CYCLE           5
void request_can_send_frame_proc(void)
{
    static uint8_t send_frame_id_start = 0;
    can_frame_data_t frame_data = {0x81, 0};
    uint8_t send_frame_id_end =
        ((send_frame_id_start + INNER_SEND_FRAME_NUM_ONE_CYCLE) > INNER_MSG_CNT) ? (INNER_MSG_CNT) : (send_frame_id_start + INNER_SEND_FRAME_NUM_ONE_CYCLE);

    // bcu请求，完整遍历
    for (uint8_t i = 0; i < INNER_MSG_CNT; i++)
    {
        request_can_send_frame(frame_data, (frame_data_id_e)i, g_can_send_ready_flag);
    }

    // ate请求，分段遍历
    frame_data.id = DEV_BROADCAST << 5; // 上位机地址0xE0
    for (uint8_t i = send_frame_id_start; i < send_frame_id_end; i++)
    {
        request_can_send_frame(frame_data, (frame_data_id_e)i, g_can_send_ate_ready_flag);
    }
    send_frame_id_start = (send_frame_id_end >= INNER_MSG_CNT) ? 0 : send_frame_id_end;
}

// 接收任务处理接口
int32_t can_sofar_frame_parse_deal(can_frame_data_t *p_can_data)
{
    if (p_can_data == NULL || FUNC_CAN_ONLY_SEND_ID > g_can_msg_list_len)
    {
        return 0;
    }
    can_frame_id_u frame_id = {p_can_data->id};
    for (uint8_t i = 0; i < g_can_msg_list_len; i++)
    {
        if (g_can_msg_list[i].func_code == frame_id.bit.fun_code)
        {
            if (g_can_msg_list[i].p_func_recv_deal_cb != NULL)
            {
                g_can_msg_list[i].p_func_recv_deal_cb(p_can_data, frame_id.bit.fun_code);
            }
        }
    }
    return 0;
}

// 0x0601: 电解液泄露传感器器件信息
static int32_t rsv_can_rx_sensor_info(can_frame_data_t *can_data)
{
    uint8_t crc = 0;
    for(uint8_t i = 0; i < 7; i++)  //crc是累加和
    {
        crc += can_data->data[i];
    }
    
    if(crc != can_data->data[7])
    {
        return -1;
    }
    
    g_electrolyte_sensor_data.crc = can_data->data[7];
    g_electrolyte_sensor_data.error = can_data->data[2];
    g_electrolyte_sensor_data.tick = can_data->data[6];
    g_electrolyte_sensor_data.electrolyte_stren = MAKE_WORD(can_data->data[1],can_data->data[0]);
    
    g_electrolyte_sensor_data.cnt = 0;
    
    return 0;
}


/**
* @brief                获取烟雾传感器相关信息
* @param                [in]无
* @return               const sample_data_t *
* @retval               NULL获取失败
* @retval               ret(!NULL)获取成功
* @warning              无
*/
electrolyte_sensor_info_t electrolyte_sensor_data_get(void)
{
    return g_electrolyte_sensor_data;
}



/**
* @brief        从数据层中更新数据到参数点表
* @param        无
* @return        无
* @retval        无
* @warning        无
*/
static void update_para(void)
{

}
/**
* @brief        从数据层中更新数据到定值点表
* @param        无
* @return        无
* @retval        无
* @warning        无
*/
static void update_threshold(void)
{

}

/**
* @brief        can初始化，并注册内网CAN ID，注册一下rvs can id
* @param        无
* @return        无
* @retval        无
* @warning        无
*/

void can_sofar_data_init(void)
{
    uint16_t rec_msg_amount = 0;
    can_frame_id_u frame_id[] =
    {
        // res     prio(优先级)      type(帧类型)  flag（1:连续，0:非）, fun_code,    dst_type dst_addr, src_type, src_addr
        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_LOW_H,  .bit.fun_code= FUNC_MASTER_CTL_CMD,
            .bit.dst_type= DEV_BMU, .bit.dst_addr= 0, .bit.src_type= DEV_BCU, .bit.src_addr =0},
    };
    can_sofar_rcv_reg_t can_rxmsg_tab[] = // 接收上位机或BCU的数据
    {
        {frame_id[0].id_val, 0x07FFFFFF, can_sofar_frame_parse_deal,},  //
    };

    // 注册接收的数据
    rec_msg_amount = sizeof(can_rxmsg_tab)/sizeof(can_sofar_rcv_reg_t);
    inner_can_sofar_register_receive_frame(can_rxmsg_tab, rec_msg_amount);
    // 用于提示开发人员表格没有一一对应
    for (uint8_t list_cnt = 0; list_cnt < g_can_msg_list_len; list_cnt++)
    {
        if (g_can_msg_list[list_cnt].id != list_cnt)
        {
            log_e("canList%d Err%d,0x%x\n", list_cnt, g_can_msg_list[list_cnt].id, g_can_msg_list[list_cnt].func_code);
            break;
        }
    }
    
    can_frame_id_u rsv_frame_id[] =
    {
        // res     prio(优先级)      type(帧类型)  flag（1:连续，0:非）, fun_code,    dst_type dst_addr, src_type, src_addr
        {.id_val = 0x601}, //电解液漏液监测传感器id
    };
    can_sofar_rcv_reg_t rsv_can_rxmsg_tab[] = // 接收上位机或BCU的数据
    {
        {rsv_frame_id[0].id_val, 0x00000000, rsv_can_rx_sensor_info,},  //
    };
    // 注册接收的数据
    rec_msg_amount = sizeof(rsv_can_rxmsg_tab)/sizeof(can_sofar_rcv_reg_t);
    rsv_can_sofar_register_receive_frame(rsv_can_rxmsg_tab, rec_msg_amount);    

    // 初始化定值、参数点表
    update_para();
    update_threshold();
    // 数据初始化
    memset(g_can_msg_cycle_first_flag, 0, sizeof(g_can_msg_cycle_first_flag));
    memset(g_can_msg_cycle_cnt, 0, sizeof(g_can_msg_cycle_cnt));
    memset(g_can_msg_cycle_max_cnt, 0, sizeof(g_can_msg_cycle_max_cnt));
    auto_send_can_sofar_enable_set(false); // 启动自动发送内网数据（暂时放这，后续在BMU处于开机状态时打开）
}

void cycle_send_sofar_data_proc(void)
{
    if (false == g_auto_send_data_enable)
    {
        memset(g_can_msg_cycle_first_flag, 0, sizeof(g_can_msg_cycle_first_flag));
        memset(g_can_msg_cycle_cnt, 0, sizeof(g_can_msg_cycle_cnt));
        return;
    }

    bool send_flag = 0;
    uint8_t cycle_id = 0;
    can_frame_data_t frame_data = {0};
    for (uint8_t i = 0; i < g_can_msg_cycle_send_list_len; i++)
    {
        cycle_id = g_can_msg_cycle_send_list[i].cycle_send_data_id;

        if (cycle_id >= CYCLE_MSG_CNT)
        {
            continue;
        }
        // 发送次数清空后，不在发送
        if ((g_can_msg_cycle_send_list[i].send_cnt != -1) && (g_can_msg_cycle_max_cnt[cycle_id] >= g_can_msg_cycle_send_list[i].send_cnt))
        {
            continue;
        }
        send_flag = false;
        g_can_msg_cycle_cnt[cycle_id]++;
        if (g_can_msg_cycle_first_flag[cycle_id] == 0)
        {
            if (g_can_msg_cycle_cnt[cycle_id] >= g_can_msg_cycle_send_list[i].first_delay)
            {
                g_can_msg_cycle_first_flag[cycle_id] = 1;
                send_flag = true;
            }
        }
        else
        {
            if (g_can_msg_cycle_cnt[cycle_id] >= g_can_msg_cycle_send_list[i].send_period)
            {
                send_flag = true;
            }
        }
        if (send_flag == true)
        {
            g_can_msg_cycle_cnt[cycle_id] = 0;
            module_inner_can_send_msg(&frame_data, (module_request_send_group_e)g_can_msg_cycle_send_list[i].module_groub_id, true);
            g_can_msg_cycle_max_cnt[cycle_id]++;
        }
    }
}

// 发送任务
void can_sofar_data_send_proc(void)
{
    // 周期发送数据请求
    cycle_send_sofar_data_proc();
    // 外部发送和本模块异步发送
    request_can_send_frame_proc();
}

/**
* @brief        自动发送内网数据使能接口
* @param        [in]enable：  false：不使能    true：使能
* @return        返回结果
* @retval        0：操作成功    < 0: 操作失败
* @warning        无
*/
int32_t auto_send_can_sofar_enable_set(uint8_t enable)
{
    int32_t ret = 0;

    if(false == enable)
    {
        g_auto_send_data_enable = false;
    }
    else if(true == enable)
    {
        g_auto_send_data_enable = true;
    }
    else
    {
        ret = -1;
    }

    return ret;
}

/**
* @brief        老化模式请求
* @param        [value]：模式开启
* @return        返回结果
* @retval        0：操作成功    < 0: 操作失败
* @warning        无
*/
static int8_t aging_mode_request(uint16_t value)
{
    if(OPEN_MODE == value)
    {
        special_mode_set(AGING_MODE, ATE_SET);
        return 0;
    }
    else if (RELEASE_MODE == value)
    {
        special_mode_set(AGING_MODE, ATE_CLR);
        return 0;
    }

    return -1;

}

/**
* @brief        标定模式请求
* @param        [value]：模式开启
* @return        返回结果
* @retval        0：操作成功    < 0: 操作失败
* @warning        无
*/
static int8_t cali_mode_request(uint16_t  value)
{
    if(OPEN_MODE == value)
    {
        special_mode_set(CALI_PARM, ATE_SET);
        return 0;
    }
    else if (RELEASE_MODE == value)
    {
        special_mode_set(CALI_PARM, ATE_CLR);
        return 0;
    }
    return -1;
}


/**
* @brief        ate模式请求
* @param        [value]：模式开启
* @return        返回结果
* @retval        0：操作成功    < 0: 操作失败
* @warning        无
*/
static int8_t ate_mode_request(uint16_t  value)
{
    if(OPEN_MODE == value)
    {
        special_mode_set(ATUO_TEST, ATE_SET);
        return 0;
    }
    else if (RELEASE_MODE == value)
    {
        special_mode_set(ATUO_TEST, ATE_CLR);
        return 0;
    }

    return -1;

}

/**
* @brief        强控请求
* @param        [value]：模式开启
* @return        返回结果
* @retval        0：操作成功    < 0: 操作失败
* @warning        无
*/
static int8_t force_ctrl_mode_request(uint16_t  value)
{
    if(OPEN_MODE == value)
    {
        special_mode_set(FORCE_CTL_MODE, ATE_SET);
        return 0;
    }
    else if (RELEASE_MODE == value)
    {
        special_mode_set(FORCE_CTL_MODE, ATE_CLR);
        return 0;
    }

    return -1;

}

/**
* @brief        标定参数恢复
* @param        [in]no : 校的位置   ；[value]：模式开启
* @return        返回结果
* @retval        0：操作成功    < 0: 操作失败
* @warning        无
*/
static int8_t cali_resume_default(uint16_t  value)
{
    // if (!special_mode_get(CALI_PARM))
    // {
    //     return -2;
    // }
    if(OPEN_MODE == value)
    {
        log_d("attr data resume fault\n");
        return attr_data_resume_default_data();
    }
    else if (RELEASE_MODE == value)
    {
        return 0;
    }

    return -1;

}


/**
* @brief        设置BMU地址
* @param        [in]no : 校的位置   ；[value]：模式开启
* @return        返回结果
* @retval        0：操作成功    < 0: 操作失败
* @warning        无
*/
static int8_t set_bmu_addr(uint16_t value)
{
    if (special_mode_get(CALI_PARM) || special_mode_get(AGING_MODE) || special_mode_get(ATUO_TEST))
    {
        if ((value >= 1) && (value <= 10))
        {
            inner_address_set(value);
            log_d("setBmuAddr%d\n", value);
            return 0;
        }
        else
        {
            log_d("setBmuErr\n");
            return -1;
        }
    }
    return -2;
}


/**
 * @brief                获取主动均衡参数
 * @param                [in] 参数类型， type 参考(can_active_bal_type_e)
 * @return               返回结果：对应类型数据
 * @warning              调用此函数必须小于CAN_ACT_BAL_TYPE_NUM
 */
uint16_t bmu_active_bal_data_get(uint8_t bal_type_id)
{
    if (bal_type_id >= CAN_ACT_BAL_TYPE_NUM)
    {
        return 0;
    }
    uint16_t dat = 0;
    switch(bal_type_id)
    {
        case CAN_BMU_BAL_STATUS:
            dat = g_set_bmu_data.set_bal_status;
            break;
        case CAN_BAL_MIN_CELL_SOC:
            dat = g_set_bmu_data.set_bal_min_cell_soc;
            break;
        case CAN_ACT_BAL_EMPTY_FULL_TYPE:
            if (g_set_bmu_data.set_bat_sta.bit.full_chg_sta)
            {
                dat |= 0xAA;
            }
            else
            {
                dat |= 0x55;
            }
            if (g_set_bmu_data.set_bat_sta.bit.empty_sta)
            {
                dat |= 0xAA << 8;
            }
            else
            {
                dat |= 0x55 << 8;
            }
            break;
        case CAN_ACT_BAL_CMD_TYPE:
            dat = g_set_bmu_data.set_act_bal_ctl;
            break;
        case CAN_ACT_BAL_CLR_FULL_TYPE:
            dat = g_set_bmu_data.set_bat_sta.bit.bal_recharge;
            break;
        default:
            break;
    }
    return dat;
}

// 使能周期上报
void shell_data_cycle_send_set(uint32_t enable)
{

}


/**
 * @brief                can调试接口
 * @return               返回结果空
 * @warning              测试调试使用
 */
int32_t can(int argc, char *argv[])
{
	if (argc < 2)
    {
        log_d("can para err\n");
    }
    else
    {
        if(!strcmp(argv[1], "en"))        //启动控制
        {
            shell_data_cycle_send_set(true);
        }
        else if(!strcmp(argv[1], "dis"))
        {
            shell_data_cycle_send_set(false);
        }
        else
        {
            log_d("addrTestErr\n");
        }
    }

    return 0;
}
//MSH_CMD_EXPORT(can, <en/dis>);
