/*!*************************************************************
* @file			state_machine.c
* @brief		fsm状态机模块源文件
* @details 		该文件包含fsm状态机实现算法
* @date 		2024-05-10
* @copyright	liuyao
***************************************************************/
#include "state_machine.h"
#include <stdio.h>
#include <stdbool.h>
#include "sdk.h"
//---------------------------------------------------------------------------
// Function Definition
//---------------------------------------------------------------------------
/**
 * @brief   状态切换初始化
 * @param   [in] 状态机名、状态动作表、状态跳转表、事件数、状态数、初始状态
 * @return  无
 * @warning    无
 */
void state_machine_init(state_machine_t* p_fsm, const char* name, fsm_action_map_t* p_action_map, uint8_t* p_event_map,
    uint8_t event_num, uint8_t state_num, uint8_t init_state)
{
    p_fsm->name = name;
    p_fsm->flag = false;
    p_fsm->next_state = STA_NULL;
    p_fsm->p_action_map = p_action_map;
    p_fsm->p_event_map = p_event_map;
    p_fsm->state_num = state_num;
    p_fsm->event_num = event_num;
    if (init_state < state_num)
    {
        p_fsm->cur_state = init_state;
    }
    if (p_fsm->p_action_map[p_fsm->cur_state].enter_act != NULL)
    {
        p_fsm->p_action_map[p_fsm->cur_state].enter_act();
    }
}
/**
 * @brief   状态切换
* @param   [in] 状态机, 事件
 * @return  无
 * @warning    无
 */
void fsm_state_trans(state_machine_t* p_fsm, uint8_t event)
{
    if ((p_fsm->cur_state < p_fsm->state_num) && (event < p_fsm->event_num))
    {
        p_fsm->next_state = *(p_fsm->p_event_map + p_fsm->cur_state * p_fsm->event_num + event);
        if (p_fsm->next_state != STA_NULL)
        {
            p_fsm->flag = true;
        }
    }    
}
/**
 * @brief   状态机执行
 * @param   [in] 状态机
 * @return  返回执行结果 0:正常；<0:异常
 * @warning    无
 */
uint8_t state_machine_proc(state_machine_t* p_fsm)
{
    uint8_t cur_state_id = STA_NULL;
    uint8_t next_state_id = STA_NULL;
    uint8_t event = EVT_NULL;
    if(false != p_fsm->flag) /* 标志位不为0表示要进行状态切换 */
    {
        cur_state_id = p_fsm->cur_state;
        next_state_id = p_fsm->next_state;
        
        if ((cur_state_id < p_fsm->state_num) && (next_state_id < p_fsm->state_num))
        {
            if (p_fsm->p_action_map[next_state_id].enter_act != NULL)
            {
                event = p_fsm->p_action_map[next_state_id].enter_act(); /* 执行下一个状态的进入动作 */                
            }
            if ((p_fsm->p_action_map[next_state_id].running_act != NULL) && (EVT_NULL == event))
            {
                event = p_fsm->p_action_map[next_state_id].running_act(); /* 标志位为0不进行状态切换，执行当前状态的do动作 */
            }
            p_fsm->cur_state = p_fsm->next_state; /* 当前状态切换 */
            p_fsm->next_state = 0xFF; // 无效状态
            p_fsm->flag = false;    /* 清标志位 */
        }
        else
        {
            p_fsm->flag = 0; /* 清标志位 */
            log_w("%s StateTransFailed!Cur=%d,next=%d\n" ,p_fsm->name ,p_fsm->cur_state ,p_fsm->next_state);
        }
    }
    else
    {
        cur_state_id = p_fsm->cur_state;
        if (cur_state_id < p_fsm->state_num)
        {
            if (p_fsm->p_action_map[cur_state_id].running_act != NULL)
            {
                event = p_fsm->p_action_map[cur_state_id].running_act(); /* 标志位为0不进行状态切换，执行当前状态的do动作 */
            }
        }
        else
        {
            log_w("%s StateRunnigErr!Cur=%d\n" ,p_fsm->name, p_fsm->cur_state);
        } 
    }
    return event;    
}
