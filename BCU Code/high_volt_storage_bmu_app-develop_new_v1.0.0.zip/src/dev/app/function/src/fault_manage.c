#include "sdk_core.h"
#include "fault_manage.h"
#include "bmu_data.h"
#include "sdk.h"
#include "app_public.h"
#include "data_store.h"
#include "auto_addressing.h"
#include "bms_state.h"
#include "afe_manage.h"
#include "sox_public.h"
#include "ate.h"
#include "afe_bq79600.h"

#define FAULT_MANAGE_LOGD(...) log_d(__VA_ARGS__)
#define FAULT_MANAGE_LOGE(...) log_e(__VA_ARGS__)

#define OVER_CURR_LOCK_TIMES	10						// 过流锁死持续次数
#define BAL_OVER_CURR_LOCK_TIMES	10					// 均衡过流锁死持续次数
#define CELL_VOLT_INVALID_MAX	4000					// 电芯失效最高电压 0.001V
#define CELL_VOLT_INVALID_MIN	2000					// 电芯失效最低电压 0.001V
#define CELL_VOLT_INVALID_DIFF	1000					// 电芯失效压差 0.001V
#define CHARGER_ACCESS_STATUS   0
#define POWER_TERMINAL_TEMP_OVER_LOCK_TIMES    8		// 过流锁死持续次数
#define OVER_VOLT_LOCK_TIMES	3						// 过压锁死持续次数
#define LOW_VOLT_LOCK_TIMES		3						// 欠压锁死持续次数
#define OVER_TEMP_LOCK_TIMES	8						// 过温锁死持续次数
#define LOW_TEMP_LOCK_TIMES		8						// 低温锁死持续次数
#define HIGH_LOW_TEMP_PRO_TIMES (10)                    // 高低温保护次数（在触发高低温告警过程中）

#define TIME_10S_BASE_10MS      1000                    //10S
#define FAULT_GROUP_SIZE        (32)
#define FAULT_GROUP_NUM         ((FAULT_MAX + FAULT_GROUP_SIZE - 1)/ FAULT_GROUP_SIZE)


static uint8_t 					g_limit_chg = false;	// 限充
static uint8_t 					g_limit_dsg = false;	// 限放
static uint8_t 					g_cut_off_relay = false;// 切断继电器
static uint8_t                  g_fault_enable;         // 故障诊断使能
static uint32_t                 g_fault_state[FAULT_GROUP_NUM] = {0}; // 故障状态，位操作， bit=0(无故障) bit=1(有故障),
static fault_diag_step_e	    g_fault_diag_step;		// 故障诊断步骤
static bmu_data_t*	        	gp_bmu_data = NULL;				// bms实时数据指针 用来做故障判断
static fault_lock_data_t		g_fault_lock_data;		// 故障锁死数据
static const safety_para_tab_t* gp_fault_para;	    	// 故障参数，每个故障对应1个产生阈值和1个消失阈值
static fault_id_t g_fault_id = {0};
static fault_stat_data_t g_fault_stat_data = {0, LEVEL3, LEVEL3};
static fault_info_t g_fault_info = {0};					//BMS故障信息


#ifdef SIMULATION_FAULT_TEST
static uint8_t simulate_test_fault_flag = false;			//模拟测试故障标志
#endif



#define ALARM_APPEAR  1
#define ALARM_RECOVER  0

typedef bool(*alarm_deal_callback)(fault_type_e, bool);
typedef void (*alarm_print_callback)(fault_type_e, bool);
static uint16_t g_alarm_cnt[FAULT_MAX] = {0};


static uint8_t g_hard_self_det_abn_flag = 0;                // 硬件自检异常标志
static uint8_t g_cell_temp_wire_err_no = U8_INVALID_VALUE;                 //确认哪个电芯采集线异常，用于给afe逻辑做排异

/**
  * @struct   fault_para_tab_t
  * @brief  故障参数表结构定义
  */
typedef struct 
{
    fault_type_e         fault_type;              ///< 故障类型
    uint8_t              fault_decore_enable;     ///< 录波使能
    uint16_t             appear_cnt;              ///< 故障出现持续的次数
    uint16_t             cancel_cnt;              ///< 故障消失持续的次数
    uint8_t              charge_level;            ///< 充电等级
    uint8_t              discharge_level;         ///< 放电等级
    alarm_deal_callback  p_alarm_cb;              ///< 注册的回调函数
    alarm_print_callback p_alarm_print_cb;        ///< 注册的告警打印回调函数
} fault_para_tab_t;

// 回调函数声明
// 自检和运行都需要判断
static bool fault_flash_invalid_check(fault_type_e fault_id, bool is_appear);
static bool fault_24V_abnormal_check(fault_type_e fault_id, bool is_appear);
static bool fault_afe_abnormal_check(fault_type_e fault_id, bool is_appear);
static bool cell_limit_fault_check(fault_type_e fault_id, bool is_appear);
static bool fault_cell_volt_wire_abnormal_check(fault_type_e fault_id, bool is_appear);
static bool fault_cell_temp_sam_abnormal_check(fault_type_e fault_id, bool is_appear);
static bool alarm_bal_temp_sam_abnormal_check(fault_type_e fault_id, bool is_appear);
static bool fault_power_terminal_temp_sam_abnormal_check(fault_type_e fault_id, bool is_appear);
static bool alarm_env_temp_sam_abnormal_check(fault_type_e fault_id, bool is_appear);
static bool alarm_can_comm_invalid_check(fault_type_e fault_id, bool is_appear);
static bool alarm_can_id_conflict_check(fault_type_e fault_id, bool is_appear);
static bool cell_volt_over_tips_check(fault_type_e fault_id, bool is_appear);
static bool cell_volt_over_alarm_check(fault_type_e fault_id, bool is_appear);
static bool cell_volt_over_pro_check(fault_type_e fault_id, bool is_appear);
static bool cell_under_volt_tips_check(fault_type_e fault_id, bool is_appear);
static bool cell_under_volt_alarm_check(fault_type_e fault_id, bool is_appear);
static bool cell_under_volt_pro_check(fault_type_e fault_id, bool is_appear);
static bool cell_volt_diff_over_tips_check(fault_type_e fault_id, bool is_appear);
static bool cell_volt_diff_over_alarm_check(fault_type_e fault_id, bool is_appear);
static bool cell_volt_diff_over_protect_check(fault_type_e fault_id, bool is_appear);
static bool bat_over_volt_tips_check(fault_type_e fault_id, bool is_appear);
static bool bat_over_volt_alarm_check(fault_type_e fault_id, bool is_appear);
static bool bat_over_volt_pro_check(fault_type_e fault_id, bool is_appear);
static bool bat_under_volt_tips_check(fault_type_e fault_id, bool is_appear);
static bool bat_under_volt_alarm_check(fault_type_e fault_id, bool is_appear);
static bool bat_under_volt_pro_check(fault_type_e fault_id, bool is_appear);
static bool chg_cell_temp_high_tips_check(fault_type_e fault_id, bool is_appear);
static bool chg_cell_temp_high_alarm_check(fault_type_e fault_id, bool is_appear);
static bool chg_cell_temp_high_pro_check(fault_type_e fault_id, bool is_appear);
static bool chg_cell_temp_low_tips_check(fault_type_e fault_id, bool is_appear);
static bool chg_cell_temp_low_alarm_check(fault_type_e fault_id, bool is_appear);
static bool chg_cell_temp_low_pro_check(fault_type_e fault_id, bool is_appear);
static bool dchg_cell_temp_high_tips_check(fault_type_e fault_id, bool is_appear);
static bool dchg_cell_temp_high_alarm_check(fault_type_e fault_id, bool is_appear);
static bool dchg_cell_temp_high_pro_check(fault_type_e fault_id, bool is_appear);
static bool dchg_cell_temp_low_tips_check(fault_type_e fault_id, bool is_appear);
static bool dchg_cell_temp_low_alarm_check(fault_type_e fault_id, bool is_appear);
static bool dchg_cell_temp_low_pro_check(fault_type_e fault_id, bool is_appear);
static bool cell_temp_diff_over_tips_check(fault_type_e fault_id, bool is_appear);
static bool cell_temp_diff_over_alarm_check(fault_type_e fault_id, bool is_appear);
static bool cell_temp_diff_over_protect_check(fault_type_e fault_id, bool is_appear);
static bool alarm_cell_balance_temp_over_check(fault_type_e fault_id, bool is_appear);
static bool cell_temp_rise_diff_over_fault_check(fault_type_e fault_id, bool is_appear);
static bool bat_volt_diff_fault_check(fault_type_e fault_id, bool is_appear);
static bool pro_power_terminal_temp_over_check(fault_type_e fault_id, bool is_appear);
static bool alarm_env_temp_high_check(fault_type_e fault_id, bool is_appear);
static bool alarm_env_temp_low_check(fault_type_e fault_id, bool is_appear);
static bool fault_hard_self_det_check(fault_type_e fault_id, bool is_appear);
static bool alarm_afe_chain_break_check(fault_type_e fault_id, bool is_appear);
static bool alarm_electrolyte_sensor_err_check(fault_type_e fault_id, bool is_appear);
static bool volt_over_disable_check(fault_type_e fault_id, bool is_appear);
static bool volt_under_disable_check(fault_type_e fault_id, bool is_appear);
static bool cell_temp_over_or_low_disable_fault_check(fault_type_e fault_id, bool is_appear);
static bool cell_volt_over_serious_lock_fault_check(fault_type_e fault_id, bool is_appear);
static void fill_fault_msg(fault_info_t *p_fault_info);

// 告警打印函数声明
// 开机自检
static void fault_flash_invalid_print(fault_type_e fault_id, bool is_appear);
static void fault_24V_abnormal_print(fault_type_e fault_id, bool is_appear);
static void fault_afe_abnormal_print(fault_type_e fault_id, bool is_appear);
static void fault_cell_temp_sam_abnormal_print(fault_type_e fault_id, bool is_appear);
static void alarm_bal_temp_sam_abnormal_print(fault_type_e fault_id, bool is_appear);
static void fault_power_terminal_temp_sam_abnormal_print(fault_type_e fault_id, bool is_appear);
static void alarm_env_temp_sam_abnormal_print(fault_type_e fault_id, bool is_appear);
static void cell_limit_fault_print(fault_type_e fault_id, bool is_appear);
static void alarm_can_comm_invalid_print(fault_type_e fault_id, bool is_appear);
static void cell_volt_over_tips_print(fault_type_e fault_id, bool is_appear);
static void cell_volt_over_alarm_print(fault_type_e fault_id, bool is_appear);
static void cell_volt_over_pro_print(fault_type_e fault_id, bool is_appear);
static void cell_under_volt_tips_print(fault_type_e fault_id, bool is_appear);
static void cell_under_volt_alarm_print(fault_type_e fault_id, bool is_appear);
static void cell_under_volt_pro_print(fault_type_e fault_id, bool is_appear);
static void cell_volt_diff_over_tips_print(fault_type_e fault_id, bool is_appear);
static void cell_volt_diff_over_alarm_print(fault_type_e fault_id, bool is_appear);
static void cell_volt_diff_over_protect_print(fault_type_e fault_id, bool is_appear);
static void bat_over_volt_tips_print(fault_type_e fault_id, bool is_appear);
static void bat_over_volt_alarm_print(fault_type_e fault_id, bool is_appear);
static void bat_over_volt_pro_print(fault_type_e fault_id, bool is_appear);
static void bat_under_volt_tips_print(fault_type_e fault_id, bool is_appear);
static void bat_under_volt_alarm_print(fault_type_e fault_id, bool is_appear);
static void bat_under_volt_pro_print(fault_type_e fault_id, bool is_appear);
static void chg_cell_temp_high_tips_print(fault_type_e fault_id, bool is_appear);
static void chg_cell_temp_high_alarm_print(fault_type_e fault_id, bool is_appear);
static void chg_cell_temp_high_pro_print(fault_type_e fault_id, bool is_appear);
static void chg_cell_temp_low_tips_print(fault_type_e fault_id, bool is_appear);
static void chg_cell_temp_low_alarm_print(fault_type_e fault_id, bool is_appear);
static void chg_cell_temp_low_pro_print(fault_type_e fault_id, bool is_appear);
static void dchg_cell_temp_high_tips_print(fault_type_e fault_id, bool is_appear);
static void dchg_cell_temp_high_alarm_print(fault_type_e fault_id, bool is_appear);
static void dchg_cell_temp_high_pro_print(fault_type_e fault_id, bool is_appear);
static void dchg_cell_temp_low_tips_print(fault_type_e fault_id, bool is_appear);
static void dchg_cell_temp_low_alarm_print(fault_type_e fault_id, bool is_appear);
static void dchg_cell_temp_low_pro_print(fault_type_e fault_id, bool is_appear);
static void cell_temp_diff_over_tips_print(fault_type_e fault_id, bool is_appear);
static void cell_temp_diff_over_alarm_print(fault_type_e fault_id, bool is_appear);
static void cell_temp_diff_over_protect_print(fault_type_e fault_id, bool is_appear);
static void alarm_cell_balance_temp_over_print(fault_type_e fault_id, bool is_appear);
static void bat_volt_diff_fault_print(fault_type_e fault_id, bool is_appear);
static void pro_power_terminal_temp_over_print(fault_type_e fault_id, bool is_appear);
static void alarm_env_temp_print(fault_type_e fault_id, bool is_appear);
static void fault_hard_self_det_print(fault_type_e fault_id, bool is_appear);
static void alarm_electrolyte_sensor_err_print(fault_type_e fault_id, bool is_appear);
static void volt_over_disable_print(fault_type_e fault_id, bool is_appear);
static void volt_under_disable_print(fault_type_e fault_id, bool is_appear);
static void cell_temp_over_or_low_disable_fault_print(fault_type_e fault_id, bool is_appear);
static void cell_volt_over_serious_lock_fault_print(fault_type_e fault_id, bool is_appear);
void fault_name_print_deal(fault_type_e fault_id, bool is_appear);

/**
  * @struct   g_fault_param_tab
  * @brief    故障参数表
  */
const static fault_para_tab_t g_fault_para_tab[] =
{
	// 故障类型						   	-故障录波使能    	产生时间 --- 消失时间 ----充电等级 ---- 放电等级   -- 回调函数
	//                                                  （n*扫描周期10ms)
	{BOARD_24V_ABNORMAL_FAULT,			        DISABLE,      30,		 30,	    LEVEL3,		 LEVEL3,  fault_24V_abnormal_check                     , fault_24V_abnormal_print                     },
	{BOARD_FLASH_INVALID_FAULT,					DISABLE,      10,		 10,	    LEVEL0,		 LEVEL0,  fault_flash_invalid_check                    , fault_flash_invalid_print                    },
	{BOARD_AFE_ABNORMAL_FAULT,				    DISABLE,      100,		 100,		LEVEL0,		 LEVEL0,  fault_afe_abnormal_check                     , fault_afe_abnormal_print                     },
	{BOARD_CAN_COMM_ABNORMAL_ALARM,				DISABLE,     500,		 100,		LEVEL2,		 LEVEL2,  alarm_can_comm_invalid_check                 , alarm_can_comm_invalid_print                 },
	{BOARD_CANID_CONFLICT_ALARM,				DISABLE,     100,		 100,		LEVEL2,		 LEVEL2,  alarm_can_id_conflict_check                  , fault_name_print_deal                        },
    {BOARD_CELL_VOLT_WIRE_ABNORMAL_FAULT,		DISABLE,      1,		 100,       LEVEL0,		 LEVEL0,  fault_cell_volt_wire_abnormal_check          , fault_name_print_deal                        },
    {BOARD_CELL_TEMP_SAM_FAULT,		            DISABLE,      300,		 30,        LEVEL0,		 LEVEL0,  fault_cell_temp_sam_abnormal_check           , fault_cell_temp_sam_abnormal_print           },
    {BOARD_BAL_TEMP_OVER_ALARM,				    DISABLE,     100,		 100,		LEVEL3,		 LEVEL3,  alarm_cell_balance_temp_over_check           , alarm_cell_balance_temp_over_print           },
    {BOARD_BAL_TEMP_SAM_ABNORMAL_ALARM,		    DISABLE,     300,		 30,        LEVEL3,		 LEVEL3,  alarm_bal_temp_sam_abnormal_check            , alarm_bal_temp_sam_abnormal_print            },
    {BOARD_POWER_TERMINAL_TEMP_SAM_FAULT,		DISABLE,     300,		 30,        LEVEL0,		 LEVEL0,  fault_power_terminal_temp_sam_abnormal_check , fault_power_terminal_temp_sam_abnormal_print },
	{BOARD_POWER_TERMINAL_TEMP_OVER_PROTECT,	DISABLE ,    300,		 300,		LEVEL1,		 LEVEL1,  pro_power_terminal_temp_over_check           , pro_power_terminal_temp_over_print           },
    {BOARD_ENV_TEMP_SAM_ABNORMAL_ALARM,		    DISABLE,     300,		 30,        LEVEL3,		 LEVEL3,  alarm_env_temp_sam_abnormal_check            , alarm_env_temp_sam_abnormal_print            },
    {BOARD_ENV_TEMP_HIGH_ALARM,  				DISABLE,     300,		 300,		LEVEL3,		 LEVEL3,  alarm_env_temp_high_check                    , alarm_env_temp_print                         },
    {BOARD_ENV_TEMP_LOW_ALARM,  			    DISABLE,     300,		 300,		LEVEL3,		 LEVEL3,  alarm_env_temp_low_check                     , alarm_env_temp_print                         },
    {BOARD_HARD_SELF_DET_FAULT,			        DISABLE,     10,		 10,		LEVEL3,		 LEVEL3,  fault_hard_self_det_check                    , fault_hard_self_det_print                    },
    {BOARD_AFE_CHAIN_BREAK_FAULT,			    DISABLE,     300,		 300,		LEVEL3,		 LEVEL3,  alarm_afe_chain_break_check                  , fault_name_print_deal                        },
    {BOARD_ELECTROLYTE_SEN_ABNORMAL_ALARM,	    DISABLE,     300,		 300,	    LEVEL3,		 LEVEL3,  alarm_electrolyte_sensor_err_check           , alarm_electrolyte_sensor_err_print                        },
    {BOARD_CELL_TEMP_SAM_TIP,	                DISABLE,     300,		 300,	    LEVEL3,		 LEVEL3,  fault_cell_temp_sam_abnormal_check           , fault_cell_temp_sam_abnormal_print                        },
    
    {BAT_CELL_VOLT_HIGH_TIPS,					DISABLE,     300,		 300,		LEVEL3, 	 LEVEL3,  cell_volt_over_tips_check                    , cell_volt_over_tips_print                    },                    								     
	{BAT_CELL_VOLT_HIGH_ALARM,					DISABLE,     300,		 300,		LEVEL2, 	 LEVEL3,  cell_volt_over_alarm_check                   , cell_volt_over_alarm_print                   },
	{BAT_CELL_VOLT_HIGH_PROTECT,				DISABLE ,     300,		 300,		LEVEL1, 	 LEVEL3,  cell_volt_over_pro_check                     , cell_volt_over_pro_print                     },
    {BAT_CELL_VOLT_LOW_TIPS,					DISABLE,     300,		 300,		LEVEL3,		 LEVEL3,  cell_under_volt_tips_check                   , cell_under_volt_tips_print                   },
	{BAT_CELL_VOLT_LOW_ALARM,					DISABLE,     300,		 300,		LEVEL3,		 LEVEL2,  cell_under_volt_alarm_check                  , cell_under_volt_alarm_print                  },
	{BAT_CELL_VOLT_LOW_PROTECT,					DISABLE ,     300,		 300,		LEVEL3,		 LEVEL1,  cell_under_volt_pro_check                    , cell_under_volt_pro_print                    },
    {BAT_CELL_VOLT_DIFF_OVER_TIPS,				DISABLE ,    300,		 300,		LEVEL3,		 LEVEL3,  cell_volt_diff_over_tips_check               , cell_volt_diff_over_tips_print               },
    {BAT_CELL_VOLT_DIFF_OVER_ALARM,				DISABLE ,    300,		 300,		LEVEL2,		 LEVEL2,  cell_volt_diff_over_alarm_check              , cell_volt_diff_over_alarm_print              },
    {BAT_CELL_VOLT_DIFF_OVER_PROTECT,			DISABLE ,     300,		 300,		LEVEL1,		 LEVEL1,  cell_volt_diff_over_protect_check            , cell_volt_diff_over_protect_print            },
    {BAT_TOTAL_VOLT_HIGH_TIPS,					DISABLE,     300,		 300,		LEVEL3,		 LEVEL3,  bat_over_volt_tips_check                     , bat_over_volt_tips_print                     },
	{BAT_TOTAL_VOLT_HIGH_ALARM,					DISABLE,     300,		 300,		LEVEL2,		 LEVEL3,  bat_over_volt_alarm_check                    , bat_over_volt_alarm_print                    },
	{BAT_TOTAL_VOLT_HIGH_PROTECT,				DISABLE ,     300,		 300,		LEVEL1,		 LEVEL3,  bat_over_volt_pro_check                      , bat_over_volt_pro_print                      },
    {BAT_TOTAL_VOLT_LOW_TIPS,					DISABLE,     300,		 300,		LEVEL3,		 LEVEL3,  bat_under_volt_tips_check                    , bat_under_volt_tips_print                    },
	{BAT_TOTAL_VOLT_LOW_ALARM,					DISABLE,     300,		 300,		LEVEL3,		 LEVEL2,  bat_under_volt_alarm_check                   , bat_under_volt_alarm_print                   },
	{BAT_TOTAL_VOLT_LOW_PROTECT,				DISABLE ,     300,		 300,		LEVEL3,		 LEVEL1,  bat_under_volt_pro_check                     , bat_under_volt_pro_print                     },
    {BAT_TOTAL_VOLT_DIFF_OVER_FAULT,			DISABLE ,     1000,		 10,		LEVEL0,		 LEVEL0,  bat_volt_diff_fault_check                    , bat_volt_diff_fault_print                    },
    {BAT_CELL_CHG_TEMP_OVER_TIPS,				DISABLE,     300,		 300,		LEVEL3,	 	 LEVEL3,  chg_cell_temp_high_tips_check                , chg_cell_temp_high_tips_print                },
    {BAT_CELL_CHG_TEMP_OVER_ALARM,				DISABLE ,    300,		 300,		LEVEL2,		 LEVEL3,  chg_cell_temp_high_alarm_check               , chg_cell_temp_high_alarm_print               },
    {BAT_CELL_CHG_TEMP_OVER_PROTECT,			DISABLE ,     300,		 300,		LEVEL1,		 LEVEL3,  chg_cell_temp_high_pro_check                 , chg_cell_temp_high_pro_print                 },
    {BAT_CELL_CHG_TEMP_LOW_TIPS,  				DISABLE,     300,		 300,		LEVEL3,		 LEVEL3,  chg_cell_temp_low_tips_check                 , chg_cell_temp_low_tips_print                 },
    {BAT_CELL_CHG_TEMP_LOW_ALARM,  				DISABLE ,    300,		 300,		LEVEL2,		 LEVEL3,  chg_cell_temp_low_alarm_check                , chg_cell_temp_low_alarm_print                },
	{BAT_CELL_CHG_TEMP_LOW_PROTECT,  			DISABLE ,     300,		 300,		LEVEL1,		 LEVEL3,  chg_cell_temp_low_pro_check                  , chg_cell_temp_low_pro_print                  },
	{BAT_CELL_DISCHG_TEMP_OVER_TIPS, 			DISABLE,     300,		 300,		LEVEL3,		 LEVEL3,  dchg_cell_temp_high_tips_check               , dchg_cell_temp_high_tips_print               },
    {BAT_CELL_DISCHG_TEMP_OVER_ALARM, 			DISABLE,     300,		 300,		LEVEL3,		 LEVEL2,  dchg_cell_temp_high_alarm_check              , dchg_cell_temp_high_alarm_print              },
	{BAT_CELL_DISCHG_TEMP_OVER_PROTECT,  		DISABLE ,     300,		 300,		LEVEL3,		 LEVEL1,  dchg_cell_temp_high_pro_check                , dchg_cell_temp_high_pro_print                },
	{BAT_CELL_DISCHG_TEMP_LOW_TIPS,  			DISABLE,     300,		 300,		LEVEL3,		 LEVEL3,  dchg_cell_temp_low_tips_check                , dchg_cell_temp_low_tips_print                },
    {BAT_CELL_DISCHG_TEMP_LOW_ALARM,  			DISABLE,     300,		 300,		LEVEL3,		 LEVEL2,  dchg_cell_temp_low_alarm_check               , dchg_cell_temp_low_alarm_print               },
	{BAT_CELL_DISCHG_TEMP_LOW_PROTECT,  		DISABLE ,     300,		 300,		LEVEL3,		 LEVEL1,  dchg_cell_temp_low_pro_check                 , dchg_cell_temp_low_pro_print                 },
    {BAT_CELL_TEMP_DIFF_OVER_TIPS,			    DISABLE ,    300,		 300,		LEVEL3,		 LEVEL3,  cell_temp_diff_over_tips_check               , cell_temp_diff_over_tips_print               },
    {BAT_CELL_TEMP_DIFF_OVER_ALARM,			    DISABLE ,    300,		 300,		LEVEL2,		 LEVEL2,  cell_temp_diff_over_alarm_check              , cell_temp_diff_over_alarm_print              },
    {BAT_CELL_TEMP_DIFF_OVER_PROTECT,			DISABLE ,     300,		 300,		LEVEL1,		 LEVEL1,  cell_temp_diff_over_protect_check            , cell_temp_diff_over_protect_print            },
    {BAT_CELL_TEMP_RISE_OVER_FAULT,				DISABLE ,     300,		 10,		LEVEL0,		 LEVEL0,  cell_temp_rise_diff_over_fault_check         , fault_name_print_deal                        },
    {BAT_CELL_LIMIT_FAULT,                      DISABLE,      600,		 100,		LEVEL0,		 LEVEL0,  cell_limit_fault_check                       , cell_limit_fault_print                       },
    {BAT_VOLT_HIGH_DISABLE,                     DISABLE,      1,		 1,		    LEVEL1,		 LEVEL1,  volt_over_disable_check                      , volt_over_disable_print                      },
    {BAT_VOLT_LOW_DISABLE,                      DISABLE,      1,		 1,		    LEVEL1,		 LEVEL1,  volt_under_disable_check                     , volt_under_disable_print                     },
    {BAT_CELL_TEMP_OVER_OR_LOW_DISABLE,         DISABLE,      1,		 1,		    LEVEL1,		 LEVEL1,  cell_temp_over_or_low_disable_fault_check    , cell_temp_over_or_low_disable_fault_print    },
    {BAT_CELL_VOLT_HIGH_SERIOUS_LOCK,           DISABLE,      1000,		 100,		LEVEL0,		 LEVEL0,  cell_volt_over_serious_lock_fault_check      , cell_volt_over_serious_lock_fault_print      },
};

const fault_id_t *get_fault_id(void)
{
    return &g_fault_id;
}

/**
* @brief        故障变化标志
* @param        [in] uint8_t *fault_id
* @return        [out]bool  0:无需存储；1：需要存储
* @retval         无
*/
bool fault_state_change(uint8_t *fault_id)
{
    static int8_t cnt = 0;
    static uint32_t fault_state_mask[FAULT_GROUP_NUM] = {0};
    static uint32_t record_fault_state[FAULT_GROUP_NUM] = {0};
    static uint32_t record_fault_last_state[FAULT_GROUP_NUM] = {0};
    static uint8_t init_flag = 0;
    uint8_t store_flag = false;

    if(0 == init_flag)
    {
        init_flag++;
        for(uint16_t i = 0;i < FAULT_MAX;i++)
        {
            if(g_fault_para_tab[i].charge_level < LEVEL2 || g_fault_para_tab[i].discharge_level < LEVEL2)
            {
                uint32_t fault_group_id = i / FAULT_GROUP_SIZE;
                uint32_t fault_offset = i % FAULT_GROUP_SIZE;
                SET_BIT(fault_state_mask[fault_group_id], (1ULL << fault_offset));
            }
        }
    }

    // if((g_fault_stat_data.max_charge_level > LEVEL1) && (g_fault_stat_data.max_discharge_level > LEVEL1))
    // {
    //     return false;
    // }
    
    for(uint16_t i = 0;i < FAULT_GROUP_NUM;i++)
    {
        record_fault_state[i] = g_fault_state[i] & fault_state_mask[i];
    }

    for(uint16_t i = 0;i < FAULT_GROUP_NUM;i++) //确认有0变1的，才需要记录
    {
        for(uint8_t j = 0;j < FAULT_GROUP_SIZE;j++)
        {
            if ((0 == GET_BIT(record_fault_last_state[i], (1ULL << j)))
                && (GET_BIT(record_fault_state[i], (1ULL << j))))
            {
                *fault_id = i * FAULT_GROUP_SIZE + j;   //故障id
                store_flag = true;
                break;
            }
        }
    }    

    memcpy(record_fault_last_state, record_fault_state ,FAULT_GROUP_NUM * sizeof(g_fault_state[FAULT_GROUP_NUM]));    

//    if(0 != memcmp(record_fault_state, record_fault_last_state, FAULT_GROUP_NUM * sizeof(g_fault_state[FAULT_GROUP_NUM])))
    if (true == store_flag)
    {
        // memcpy(record_fault_last_state, record_fault_state ,FAULT_GROUP_NUM * sizeof(g_fault_state[FAULT_GROUP_NUM]));
        if(cnt == 0)
        {
            cnt = WINDOW_SIZE;//故障状态发生变化，充值
        }
        else if (cnt < WINDOW_SIZE)
        {
            cnt += WINDOW_SIZE;
        }
    }
    else
    {
        cnt--;
    }

    if(cnt >= 0)
    {
        return true;
    }
    else
    {
        cnt = 0;
    }

    return false;
}
void fault_id_delete(void)
{
//    while (g_fault_id.fault_cnt > FAULT_RECORD_FILE_NUMS) //TO DO
    {
        log_d("[fault]delete id = %x, fault_cnt = %d\n",g_fault_id.fault_id[0],g_fault_id.fault_cnt);
        g_fault_id.fault_cnt--;
        memmove(&g_fault_id.fault_id[0], &g_fault_id.fault_id[1], (FAULT_MAX - 1) * sizeof(uint8_t)); //将1之后的数据移到0之后，即移除头部
        memmove(&g_fault_id.fault_record_flag[0], &g_fault_id.fault_record_flag[1], (FAULT_MAX - 1) * sizeof(uint8_t)); //将1之后的数据移到0之后，即移除头部
    }

}

void clean_fault_record_flag(uint8_t num)
{
    if(num < FAULT_MAX)
    {
        g_fault_id.fault_record_flag[num] = DISABLE;
    }
    else
    {
        log_d("[fault]record_flag clean err\r \n");
    }

}

// 通过faultID获取故障信息
const fault_para_tab_t *fault_data_info_get(fault_type_e fault_type)
{
    if (fault_type >= FAULT_MAX)
    {
        return NULL;
    }
    // 加快检索
    if (fault_type < ITEM_NUM(g_fault_para_tab))
    {
        if (g_fault_para_tab[fault_type].fault_type == fault_type)
        {
            return &g_fault_para_tab[fault_type];
        }
    }

    uint16_t index = 0;
    for (index = 0; index < ITEM_NUM(g_fault_para_tab); index++)
    {
        if (g_fault_para_tab[index].fault_type == fault_type)
        {
            return &g_fault_para_tab[index];
        }
    }
    return NULL;
}

/**
 * @brief		故障设置
 * @param		[in] fault_type 故障类型
 * @param		[in] cmd 设置命令
 * -# 0x00 - FAULT_STOP
 * -# 0x01 - FAULT_START
 * @retval		0 成功
 * @retval		-1 失败
 * @pre			执行hal_adc_start后执行才有效。
 */
static int32_t fault_state_set(fault_type_e fault_type, uint8_t cmd)
{
    if ((FAULT_MAX <= fault_type) || ((FAULT_START != cmd) && (FAULT_STOP != cmd)))
    {
        FAULT_MANAGE_LOGE("[%s]inputParaErr!\r\n", __FUNCTION__);
        return -1;
    }
    uint32_t fault_group_id = fault_type / FAULT_GROUP_SIZE; 
    uint32_t fault_offset = fault_type % FAULT_GROUP_SIZE;
    if (FAULT_START == cmd)
    {
        const fault_para_tab_t* p_fault_index = fault_data_info_get(fault_type);
        if((NULL != p_fault_index)&&(ENABLE == p_fault_index->fault_decore_enable))
        {
            g_fault_id.fault_record_flag[g_fault_id.fault_cnt] = ENABLE;
            g_fault_id.fault_id[g_fault_id.fault_cnt] = fault_type;
            g_fault_id.fault_cnt++;
        }
        SET_BIT(g_fault_state[fault_group_id], (1ULL << fault_offset));
    }
    else
    {
        CLR_BIT(g_fault_state[fault_group_id], (1ULL << fault_offset));
    }

    return 0;
}

/**
 * @brief       滑窗判断保护次数是否锁死
 * @param       [in]record_tick_buff  触发故障之后记录的tick时间数组
 * @param       [in]lock_times        数组长度/连续锁死次数
 * @param       [in]pro_times         一共保护次数
 * @param       [in]over_time_b1ms     滑窗时间ms单位
 * @return       true: 连续保护锁死故障，false: 无连续保护锁死
 */
bool continuous_pro_lock_judge_deal(uint32_t *record_tick_buff, const uint16_t lock_times, uint16_t *pro_times, const uint32_t over_time_b1ms)
{
    if (NULL == record_tick_buff || 0 == over_time_b1ms || 0 == lock_times || NULL == pro_times)
    {
        return false;
    }
    if ((*pro_times) >= lock_times)
    {
        uint16_t newest_index = ((*pro_times) - 1) % lock_times;
        uint16_t oldest_index = ((*pro_times) - lock_times) % lock_times;
        uint32_t need_interval = 0;
        if (record_tick_buff[newest_index] >= record_tick_buff[oldest_index])
        {
            need_interval = record_tick_buff[newest_index] - record_tick_buff[oldest_index];
        }
        else
        {
            need_interval = 0xFFFFFFFF - record_tick_buff[oldest_index] + record_tick_buff[newest_index];
        }
        if (need_interval <= over_time_b1ms)
        {
            return true;
        }
    }
    // 如果最新一次保护的时间与当前时间超过over_time，清楚保护次数
    if ((*pro_times) > 0)
    {
        uint16_t newest_index = ((*pro_times) - 1) % lock_times;
        uint32_t curr_tick = sdk_tick_get();
        uint32_t curr_interval = 0;
        if (curr_tick >= record_tick_buff[newest_index])
        {
            curr_interval = curr_tick - record_tick_buff[newest_index];
        }
        else
        {
            curr_interval = 0xFFFFFFFF - record_tick_buff[newest_index] + curr_tick;
        }
        if (curr_interval > over_time_b1ms)
        {
            *pro_times = 0;
        }
    }
    return false;
}

// 打印故障标识
void fault_name_print_deal(fault_type_e fault_id, bool is_appear)
{
    FAULT_MANAGE_LOGE("[ALM]%#x %d\n", fault_id, (is_appear) ? ALARM_APPEAR : ALARM_RECOVER);
}

// 打印触发参数
void fault_appear_value_print_deal(int32_t birth_data)
{
    FAULT_MANAGE_LOGE("bth:%d\n", birth_data);
}

// 打印消除参数
void fault_cancel_value_print_deal(int32_t cancel_data)
{
    FAULT_MANAGE_LOGE("clr:%d\n", cancel_data);
}

/**
 * @brief		24V辅源电压异常
 */
static bool fault_24V_abnormal_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    const sample_data_t *sample_data = sample_data_p_get();

    if (sample_data == NULL)
    {
        return false;
    }
    
    uint32_t aux24v = sample_data->check_24v_volt;

    if (U32_INVALID_VALUE == aux24v)
    {
        return false;
    }
    /* 24V电压不在标准范围(17100mV,33600mV)内（(18V, 32V)上下5%），连续300ms(硬件提供) */
    
    if (ALARM_APPEAR == is_appear)
    {
        if((17100 > aux24v) || (aux24v > 33600))
        {
            result = true;
        }
    }
    else
    {
        if((18000 < aux24v) && (aux24v < 32000))
        {
            result = true;
        }
        
    }
    return result; 
}

/**
 * @brief		24V辅源电压异常打印函数
 */
static void fault_24V_abnormal_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (is_appear)
    {
        FAULT_MANAGE_LOGE("24v=%dmV\n", sample_data_p_get()->check_24v_volt);
        FAULT_MANAGE_LOGE("24vC=%d\n", sample_data_code_get(1)); // 1：24V的对应的码值编号
    }
}

/**
* @brief		flash存储失效检测
*/
static bool fault_flash_invalid_check(fault_type_e fault_id, bool is_appear)
{
#if 1
    bool result = false;

    /* 存储故障连续100ms */
    result = (bool)(-1 != data_store_toatal_fault_get());
    if (ALARM_APPEAR == is_appear)
    {
        return result;
    }
    else
    {
        return false; // 不恢复
    }
#else
    (void)fault_id;
    (void)is_appear;
    return false;
#endif
}

/**
 * @brief		flash存储失效检测打印函数
 */
static void fault_flash_invalid_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (is_appear)
    {
        FAULT_MANAGE_LOGE("flaErr=%d\n", data_store_toatal_fault_get());
    }
}

/**
 * @brief		afe异常
 */
static bool fault_afe_abnormal_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    if (ALARM_APPEAR == is_appear)
    {
        /* MCU串口uart初始化异常；或AFE初始化配置异常；或运行过程中AFE通信异常（连续3次读取失败），持续1s */
        if (AFE_ERR_STATE == afe_state_get())
        {
            result = true;
        }
    }
    else
    {
        if (AFE_ERR_STATE != afe_state_get())
        {
            result = true;
        }
    }

    return result;
}

/**
 * @brief		afe异常打印函数
 */
static void fault_afe_abnormal_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (is_appear)
    {
        FAULT_MANAGE_LOGE("afeErr=%d\n", afe_abnormal_state_get());
    }
}

/**
 * @brief		can通讯失败检测
 */
static bool alarm_can_comm_invalid_check(fault_type_e fault_id, bool is_appear)
{
    bool result = (bool)(auto_addressing_fault_get() == AUTO_ADDRESSING_COMM_FAIL || ADDRESSING_FINISH != auto_addressing_get_state());  // 编址时间过长
    if (ALARM_APPEAR == is_appear)
    {
        if (auto_addressing_fault_get() == AUTO_ADDRESSING_COMM_FAIL)   // 通讯超时
        {
            fault_state_set(BOARD_CAN_COMM_ABNORMAL_ALARM, FAULT_START);
            alarm_can_comm_invalid_print(fault_id, true);
        }
        return result;
    }
    else
    {
        return !result;
    }
}

/**
 * @brief		can通讯失败检测打印函数
 */
static void alarm_can_comm_invalid_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (is_appear)
    {
        FAULT_MANAGE_LOGE("addErr=%d,addSta=%d\n", auto_addressing_fault_get(), auto_addressing_get_state());
    }
}

/**
 * @brief		canid冲突检测
 */
static bool alarm_can_id_conflict_check(fault_type_e fault_id, bool is_appear)
{
    bool result = (bool)(auto_addressing_fault_get() == AUTO_ADDRESSING_ID_CONFLICT);
    if (ALARM_APPEAR == is_appear)
    {
        return result;
    }
    else
    {
        return !result;
    }
}

/**
 * @brief       单体电压过压提示检测
 */
static bool cell_volt_over_tips_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || U16_INVALID_VALUE == gp_bmu_data->max_cell_volt ||
        fault_state_get(BOARD_CELL_VOLT_WIRE_ABNORMAL_FAULT))
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 保护：最高电芯电压>3500mV(2.0+50mV)，持续3s */
        if (gp_bmu_data->max_cell_volt > gp_fault_para->cell_over_vol_tip.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 保护解除：最高电芯电压<3400mV(2.0+50mV),持续3s */
        if ((gp_bmu_data->max_cell_volt < gp_fault_para->cell_over_vol_tip.cancel_value) &&
            (gp_bmu_data->max_cell_volt <= gp_fault_para->cell_over_vol_tip.appear_value))
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief		单体电压过压提示打印函数
 */
static void cell_volt_over_tips_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("hCellV=%dmV\n", gp_bmu_data->max_cell_volt);
    fault_appear_value_print_deal(gp_fault_para->cell_over_vol_tip.appear_value);
    if (!is_appear)
    {
        fault_cancel_value_print_deal(gp_fault_para->cell_over_vol_tip.cancel_value);
    }
}

/**
 * @brief       单体电压过压告警检测
 */
static bool cell_volt_over_alarm_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || U16_INVALID_VALUE == gp_bmu_data->max_cell_volt || 
        fault_state_get(BOARD_CELL_VOLT_WIRE_ABNORMAL_FAULT))
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 告警：最高电芯电压>3550mV(2.0+50mV)，持续3s */
        if (gp_bmu_data->max_cell_volt > gp_fault_para->cell_over_vol_alarm.appear_value)
        {
            result = true;
        }
    }
    else
    {
        const sox_data_t *sox_data = sox_data_get_deal();
        /* 告警解除：最高电芯电压<3450mV(2.0+50mV),持续3s */
        if ((gp_bmu_data->max_cell_volt < gp_fault_para->cell_over_vol_alarm.cancel_value) &&
            (gp_bmu_data->max_cell_volt <= gp_fault_para->cell_over_vol_alarm.appear_value))
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief		单体电压过压告警打印函数
 */
static void cell_volt_over_alarm_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("hCellV=%dmV\n", gp_bmu_data->max_cell_volt);
    fault_appear_value_print_deal(gp_fault_para->cell_over_vol_alarm.appear_value);
    if (!is_appear)
    {
        FAULT_MANAGE_LOGE("cur=%dmA\n", gp_bmu_data->sys_current);
        fault_cancel_value_print_deal(gp_fault_para->cell_over_vol_alarm.cancel_value);
        const sox_data_t *sox_data = sox_data_get_deal();
        if (NULL != sox_data)
        {
            FAULT_MANAGE_LOGE("calcSoc=%d\n", sox_data->calc_soc);
        }
    }
}

/**
 * @brief       单体电压过压保护检测
 */
static bool cell_volt_over_pro_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || U16_INVALID_VALUE == gp_bmu_data->max_cell_volt ||
        fault_state_get(BOARD_CELL_VOLT_WIRE_ABNORMAL_FAULT))
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 保护：最高电芯电压>3650mV(2.0+50mV)，持续3s */
        if (gp_bmu_data->max_cell_volt > gp_fault_para->cell_over_vol_protect.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 保护解除：最高电芯电压<3550mV(2.0+50mV),持续3s */
        if ((gp_bmu_data->max_cell_volt < gp_fault_para->cell_over_vol_protect.cancel_value) &&
            (gp_bmu_data->max_cell_volt <= gp_fault_para->cell_over_vol_protect.appear_value))
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief		单体电压过压保护打印函数
 */
static void cell_volt_over_pro_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("hCellV=%dmV\n", gp_bmu_data->max_cell_volt);
    fault_appear_value_print_deal(gp_fault_para->cell_over_vol_protect.appear_value);
    if (!is_appear)
    {
        fault_cancel_value_print_deal(gp_fault_para->cell_over_vol_protect.cancel_value);
    }
}

/**
 * @brief       单体电压低压提示检测
 */
static bool cell_under_volt_tips_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || U16_INVALID_VALUE == gp_bmu_data->min_cell_volt ||
        fault_state_get(BOARD_CELL_VOLT_WIRE_ABNORMAL_FAULT))
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 提示：最低电芯电压<2800mV，持续3s */
        if (gp_bmu_data->min_cell_volt < gp_fault_para->cell_under_vol_tip.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 提示解除：最低电芯电压>2900mV，持续3s */
        if ((gp_bmu_data->min_cell_volt > gp_fault_para->cell_under_vol_tip.cancel_value) &&
            (gp_bmu_data->min_cell_volt >= gp_fault_para->cell_under_vol_tip.appear_value))
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief		单体电压低压提示打印函数
 */
static void cell_under_volt_tips_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("lCellV=%dmV\n", gp_bmu_data->min_cell_volt);
    fault_appear_value_print_deal(gp_fault_para->cell_under_vol_tip.appear_value);
    if (!is_appear)
    {
        fault_cancel_value_print_deal(gp_fault_para->cell_under_vol_tip.cancel_value);
    }
}

/**
 * @brief       单体电压低压告警检测
 */
static bool cell_under_volt_alarm_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || U16_INVALID_VALUE == gp_bmu_data->min_cell_volt ||
        fault_state_get(BOARD_CELL_VOLT_WIRE_ABNORMAL_FAULT))
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 告警：最低电芯电压<2700mV，持续3s */
        if (gp_bmu_data->min_cell_volt < gp_fault_para->cell_under_vol_alarm.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 告警解除：最低电芯电压>2800mV，持续3s */
        if ((gp_bmu_data->min_cell_volt > gp_fault_para->cell_under_vol_alarm.cancel_value) &&
            (gp_bmu_data->min_cell_volt >= gp_fault_para->cell_under_vol_alarm.appear_value))
        {
            result = true;
        }
    }
    return result;
}

/**
 * @brief		单体电压低压告警打印函数
 */
static void cell_under_volt_alarm_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("lCellV=%dmV\n", gp_bmu_data->min_cell_volt);
    fault_appear_value_print_deal(gp_fault_para->cell_under_vol_alarm.appear_value);
    if (!is_appear)
    {
        FAULT_MANAGE_LOGE("cur=%dmA\n", gp_bmu_data->sys_current);
        fault_cancel_value_print_deal(gp_fault_para->cell_under_vol_alarm.cancel_value);
    }
}

/**
 * @brief       单体电压低压保护检测
 */
static bool cell_under_volt_pro_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || U16_INVALID_VALUE == gp_bmu_data->min_cell_volt ||
        fault_state_get(BOARD_CELL_VOLT_WIRE_ABNORMAL_FAULT))
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 保护：最低电芯电压<2500mV，持续3s */
        if (gp_bmu_data->min_cell_volt < gp_fault_para->cell_under_vol_protect.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 保护解除：最低电芯电压>2600mV，持续3s */
        if ((gp_bmu_data->min_cell_volt > gp_fault_para->cell_under_vol_protect.cancel_value) &&
            (gp_bmu_data->min_cell_volt >= gp_fault_para->cell_under_vol_protect.appear_value))
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief		单体电压低压保护打印函数
 */
static void cell_under_volt_pro_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("lCellV=%dmV\n", gp_bmu_data->min_cell_volt);
    fault_appear_value_print_deal(gp_fault_para->cell_under_vol_protect.appear_value);
    if (!is_appear)
    {
        fault_cancel_value_print_deal(gp_fault_para->cell_under_vol_protect.cancel_value);
    }
}

/**
 * @brief   单体电芯压差过大提示检测
 */
static bool cell_volt_diff_over_tips_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || U16_INVALID_VALUE == gp_bmu_data->diff_cell_volt || fault_state_get(BOARD_CELL_VOLT_WIRE_ABNORMAL_FAULT))
    {
        return false;
    }

    if (ALARM_APPEAR == is_appear)
    {
        /* 提示：单体压差 > 400mV，持续3s */
        if (gp_bmu_data->diff_cell_volt > gp_fault_para->cell_volt_diff_tip.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 提示解除：单体压差 < 350mV,持续3s */
        if (gp_bmu_data->diff_cell_volt < gp_fault_para->cell_volt_diff_tip.cancel_value)
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief 单体压差过大提示打印函数
 */
static void cell_volt_diff_over_tips_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("CellVdiff=%dmV\n", gp_bmu_data->diff_cell_volt);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->cell_volt_diff_tip.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->cell_volt_diff_tip.cancel_value);
    }
}

/**
 * @brief   单体电芯压差过大告警检测
 */
static bool cell_volt_diff_over_alarm_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || U16_INVALID_VALUE == gp_bmu_data->diff_cell_volt || fault_state_get(BOARD_CELL_VOLT_WIRE_ABNORMAL_FAULT))
    {
        return false;
    }

    if (ALARM_APPEAR == is_appear)
    {
        /* 告警：单体压差 > 600mV，持续3s */
        if (gp_bmu_data->diff_cell_volt > gp_fault_para->cell_volt_diff_alarm.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 告警解除：单体压差 < 550mV,持续3s */
        if (gp_bmu_data->diff_cell_volt < gp_fault_para->cell_volt_diff_alarm.cancel_value)
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief   单体电芯压差过大告警打印函数
 */
static void cell_volt_diff_over_alarm_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("CellVdiff=%dmV\n", gp_bmu_data->diff_cell_volt);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->cell_volt_diff_alarm.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->cell_volt_diff_alarm.cancel_value);
    }
}

/**
 * @brief   单体电芯压差过大保护检测
 */
static bool cell_volt_diff_over_protect_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || U16_INVALID_VALUE == gp_bmu_data->diff_cell_volt || fault_state_get(BOARD_CELL_VOLT_WIRE_ABNORMAL_FAULT))
    {
        return false;
    }

    if (ALARM_APPEAR == is_appear)
    {
        /* 保护：单体压差 > 1000mV，持续3s */
        if (gp_bmu_data->diff_cell_volt > gp_fault_para->cell_volt_diff_protect.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 保护解除：单体压差 < 950mV,持续3s */
        if (gp_bmu_data->diff_cell_volt < gp_fault_para->cell_volt_diff_protect.cancel_value)
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief   单体电芯压差过大保护打印函数
 */
static void cell_volt_diff_over_protect_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("CellVdiff=%dmV\n", gp_bmu_data->diff_cell_volt);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->cell_volt_diff_protect.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->cell_volt_diff_protect.cancel_value);
    }
}

/**
 * @brief       总压电压过压提示检测
 */
static bool bat_over_volt_tips_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || U32_INVALID_VALUE == gp_bmu_data->bat_acc_volt ||
        fault_state_get(BOARD_CELL_VOLT_WIRE_ABNORMAL_FAULT))
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 提示：电池包电压 > 168V，持续3s */
        if (gp_bmu_data->bat_acc_volt > gp_fault_para->total_over_vol_tip.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 提示消除：电池包电压<163V,持续3s */
        if ((gp_bmu_data->bat_acc_volt < gp_fault_para->total_over_vol_tip.cancel_value) &&
            (gp_bmu_data->bat_acc_volt <= gp_fault_para->total_over_vol_tip.appear_value))   //防止达到保护电压时，同时满足解除条件，而不断保护解除
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief		总压电压过压提示打印函数
 */
static void bat_over_volt_tips_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("batV=%dmV\n", gp_bmu_data->bat_acc_volt);
    fault_appear_value_print_deal(gp_fault_para->total_over_vol_tip.appear_value);
    if (!is_appear)
    {
        FAULT_MANAGE_LOGE("cur=%dmA\n", gp_bmu_data->sys_current);
        fault_cancel_value_print_deal(gp_fault_para->total_over_vol_tip.cancel_value);
        const sox_data_t *sox_data = sox_data_get_deal();
        if (NULL != sox_data)
        {
            FAULT_MANAGE_LOGE("soc=%d\n", sox_data->calc_soc);
        }
    }
}

/**
 * @brief       总压电压过压告警检测
 */
static bool bat_over_volt_alarm_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || U32_INVALID_VALUE == gp_bmu_data->bat_acc_volt ||
        fault_state_get(BOARD_CELL_VOLT_WIRE_ABNORMAL_FAULT))
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 告警：电池包电压 > 170.4V，持续3s */
        if (gp_bmu_data->bat_acc_volt > gp_fault_para->total_over_vol_alarm.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 告警消除：电池包电压<165.4V,持续3s */
        if ((gp_bmu_data->bat_acc_volt < gp_fault_para->total_over_vol_alarm.cancel_value) &&
            (gp_bmu_data->bat_acc_volt <= gp_fault_para->total_over_vol_alarm.appear_value))    //防止达到保护电压时，同时满足解除条件，而不断保护解除
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief		总压电压过压告警打印函数
 */
static void bat_over_volt_alarm_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("batV=%dmV\n", gp_bmu_data->bat_acc_volt);
    fault_appear_value_print_deal(gp_fault_para->total_over_vol_alarm.appear_value);
    if (!is_appear)
    {
        FAULT_MANAGE_LOGE("cur=%dmA\n", gp_bmu_data->sys_current);
        fault_cancel_value_print_deal(gp_fault_para->total_over_vol_alarm.cancel_value);
        const sox_data_t *sox_data = sox_data_get_deal();
        if (NULL != sox_data)
        {
            FAULT_MANAGE_LOGE("soc=%d\n", sox_data->calc_soc);
        }
    }
}

/**
 * @brief       总压电压过压保护检测
 */
static bool bat_over_volt_pro_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || U32_INVALID_VALUE == gp_bmu_data->bat_acc_volt ||
        fault_state_get(BOARD_CELL_VOLT_WIRE_ABNORMAL_FAULT))
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 保护：电池包电压 > 175.2V，持续3s */
        if (gp_bmu_data->bat_acc_volt > gp_fault_para->total_over_vol_protect.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 保护消除：电池包电压<170.2V,持续3s */
        if ((gp_bmu_data->bat_acc_volt < gp_fault_para->total_over_vol_protect.cancel_value) && 
            (gp_bmu_data->bat_acc_volt <= gp_fault_para->total_over_vol_protect.appear_value))
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief		总压电压过压保护打印函数
 */
static void bat_over_volt_pro_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("batV=%dmV\n", gp_bmu_data->bat_acc_volt);
    fault_appear_value_print_deal(gp_fault_para->total_over_vol_protect.appear_value);
    if (!is_appear)
    {
        fault_cancel_value_print_deal(gp_fault_para->total_over_vol_protect.cancel_value);
    }
}

/**
 * @brief       总压电压低压提示检测
 */
static bool bat_under_volt_tips_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || U32_INVALID_VALUE == gp_bmu_data->bat_acc_volt ||
        fault_state_get(BOARD_CELL_VOLT_WIRE_ABNORMAL_FAULT))
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 提示：电池包电压 < 134.4V，持续3s */
        if (gp_bmu_data->bat_acc_volt < gp_fault_para->total_under_vol_tip.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 提示解除：电池包电压 > 139.4V,持续3s */
        if ((gp_bmu_data->bat_acc_volt > gp_fault_para->total_under_vol_tip.cancel_value)&&
            (gp_bmu_data->bat_acc_volt >= gp_fault_para->total_under_vol_tip.appear_value))
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief		总压电压低压提示打印函数
 */
static void bat_under_volt_tips_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("batV=%dmV\n", gp_bmu_data->bat_acc_volt);
    fault_appear_value_print_deal(gp_fault_para->total_under_vol_tip.appear_value);
    if (!is_appear)
    {
        FAULT_MANAGE_LOGE("cur=%dmA\n", gp_bmu_data->sys_current);
        fault_cancel_value_print_deal(gp_fault_para->total_under_vol_tip.cancel_value);
    }
}

/**
 * @brief       总压电压低压告警检测
 */
static bool bat_under_volt_alarm_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || U32_INVALID_VALUE == gp_bmu_data->bat_acc_volt ||
        fault_state_get(BOARD_CELL_VOLT_WIRE_ABNORMAL_FAULT))
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 告警：电池包电压 < 129.6V，持续3s */
        if (gp_bmu_data->bat_acc_volt < gp_fault_para->total_under_vol_alarm.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 告警解除：电池包电压 > 134.6V,持续3s */
        if ((gp_bmu_data->bat_acc_volt > gp_fault_para->total_under_vol_alarm.cancel_value)&&
            (gp_bmu_data->bat_acc_volt >= gp_fault_para->total_under_vol_alarm.appear_value))
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief		总压电压低压告警打印函数
 */
static void bat_under_volt_alarm_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("batV=%dmV\n", gp_bmu_data->bat_acc_volt);
    fault_appear_value_print_deal(gp_fault_para->total_under_vol_alarm.appear_value);
    if (!is_appear)
    {
        FAULT_MANAGE_LOGE("cur=%dmA\n", gp_bmu_data->sys_current);
        fault_cancel_value_print_deal(gp_fault_para->total_under_vol_alarm.cancel_value);
    }
}

/**
 * @brief       总压电压低压保护检测
 */
static bool bat_under_volt_pro_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || U32_INVALID_VALUE == gp_bmu_data->bat_acc_volt ||
        fault_state_get(BOARD_CELL_VOLT_WIRE_ABNORMAL_FAULT))
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 保护：电池包电压 < 120V，持续3s */
        if (gp_bmu_data->bat_acc_volt < gp_fault_para->total_under_vol_protect.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 保护解除：电池包电压 > 125V,持续3s */
        if ((gp_bmu_data->bat_acc_volt > gp_fault_para->total_under_vol_protect.cancel_value) && 
            (gp_bmu_data->bat_acc_volt >= gp_fault_para->total_under_vol_protect.appear_value))
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief		总压电压低压保护打印函数
 */
static void bat_under_volt_pro_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("batV=%dmV\n", gp_bmu_data->bat_acc_volt);
    fault_appear_value_print_deal(gp_fault_para->total_under_vol_protect.appear_value);
    if (!is_appear)
    {
        fault_cancel_value_print_deal(gp_fault_para->total_under_vol_protect.cancel_value);
    }
}

/**
* @brief       电芯充电温度过高提示检测
 */
static bool chg_cell_temp_high_tips_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || I16_INVALID_VALUE == gp_bmu_data->max_cell_temp || fault_state_get(BOARD_CELL_TEMP_SAM_FAULT))
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 提示：非放电时，最高电芯温度>50℃，持续3s */
        if ((gp_bmu_data->max_cell_temp > gp_fault_para->chg_over_temp_tip.appear_value) &&
            (BMS_DISCHARGE_MODE != bms_state_get_bat_sta()))
        {
            result = true;
        }
    }
    else
    {
        /* 提示解除：最高电芯温度<45℃，持续3s */
        if ((gp_bmu_data->max_cell_temp < gp_fault_para->chg_over_temp_tip.cancel_value))
        {
             result = true;
        }
    }
    return result;
}

/**
* @brief		电芯充电温度过高提示打印函数
 */
static void chg_cell_temp_high_tips_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("hCellTemp=%d\n", gp_bmu_data->max_cell_temp);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->chg_over_temp_tip.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->chg_over_temp_tip.cancel_value);
    }
}

/**
 * @brief       电芯充电温度过高告警检测
 */
static bool chg_cell_temp_high_alarm_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || I16_INVALID_VALUE == gp_bmu_data->max_cell_temp || fault_state_get(BOARD_CELL_TEMP_SAM_FAULT))
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 告警：非放电时，最高电芯温度>55℃，持续3s */
        if ((gp_bmu_data->max_cell_temp > gp_fault_para->chg_over_temp_alarm.appear_value) &&
            (BMS_DISCHARGE_MODE != bms_state_get_bat_sta()))
        {
            result = true;
        }
    }
    else
    {
        /* 告警解除：最高电芯温度<50℃，持续3s */
        if (gp_bmu_data->max_cell_temp < gp_fault_para->chg_over_temp_alarm.cancel_value)
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief		电芯充电温度过高告警打印函数
 */
static void chg_cell_temp_high_alarm_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("hCellTemp=%d\n", gp_bmu_data->max_cell_temp);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->chg_over_temp_alarm.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->chg_over_temp_alarm.cancel_value);
    }
}

/**
 * @brief       电芯充电温度过高保护检测
 */
static bool chg_cell_temp_high_pro_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || I16_INVALID_VALUE == gp_bmu_data->max_cell_temp || fault_state_get(BOARD_CELL_TEMP_SAM_FAULT))
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 保护：非放电时，最高电芯温度>60℃，持续3s */
        if ((gp_bmu_data->max_cell_temp > gp_fault_para->chg_over_temp_protect.appear_value) &&
            (BMS_DISCHARGE_MODE != bms_state_get_bat_sta()))
        {
            result = true;
        }
    }
    else
    {
        /* 保护解除：最高电芯温度<55℃，持续3s */
        if (gp_bmu_data->max_cell_temp < gp_fault_para->chg_over_temp_protect.cancel_value)
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief		电芯充电温度过高保护打印函数
 */
static void chg_cell_temp_high_pro_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("hCellTemp=%d\n", gp_bmu_data->max_cell_temp);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->chg_over_temp_protect.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->chg_over_temp_protect.cancel_value);
    }
}

/**
* @brief       电芯充电低温提示检测
 */
static bool chg_cell_temp_low_tips_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || I16_INVALID_VALUE == gp_bmu_data->min_cell_temp || fault_state_get(BOARD_CELL_TEMP_SAM_FAULT))
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 提示：非放电时，最低电芯温度<0℃，持续3s */
        if ((gp_bmu_data->min_cell_temp < gp_fault_para->chg_under_temp_tip.appear_value) &&
        (BMS_DISCHARGE_MODE != bms_state_get_bat_sta()))
        {
            result = true;
        }
    }
    else
    {
        /* 提示解除：最低电芯温度>5℃，持续3s */
        if ((gp_bmu_data->min_cell_temp > gp_fault_para->chg_under_temp_tip.cancel_value))
        {
             result = true;
        }
    }
    return result;
}

/**
* @brief		电芯充电低温提示打印函数
 */
static void chg_cell_temp_low_tips_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("lCellTemp=%d\n", gp_bmu_data->min_cell_temp);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->chg_under_temp_tip.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->chg_under_temp_tip.cancel_value);
    }
}

/**
 * @brief       电芯充电低温告警检测
 */
static bool chg_cell_temp_low_alarm_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || I16_INVALID_VALUE == gp_bmu_data->min_cell_temp || fault_state_get(BOARD_CELL_TEMP_SAM_FAULT))
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 告警：非放电时，最低电芯温度<-10℃，持续3s */
        if ((gp_bmu_data->min_cell_temp < gp_fault_para->chg_under_temp_alarm.appear_value) &&
            (BMS_DISCHARGE_MODE != bms_state_get_bat_sta()))
        {
            result = true;
        }
    }
    else
    {
        /* 告警解除：最低电芯温度>-5℃，持续3s */
        if (gp_bmu_data->min_cell_temp > gp_fault_para->chg_under_temp_alarm.cancel_value)
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief		电芯充电低温告警打印函数
 */
static void chg_cell_temp_low_alarm_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("lCellTemp=%d\n", gp_bmu_data->min_cell_temp);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->chg_under_temp_alarm.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->chg_under_temp_alarm.cancel_value);
    }
}

/**
 * @brief       电芯充电低温保护检测
 */
static bool chg_cell_temp_low_pro_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || I16_INVALID_VALUE == gp_bmu_data->min_cell_temp || fault_state_get(BOARD_CELL_TEMP_SAM_FAULT))
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 保护：非放电时，最低电芯温度<-20℃，持续3s */
        if ((gp_bmu_data->min_cell_temp < gp_fault_para->chg_under_temp_protect.appear_value) &&
            (BMS_DISCHARGE_MODE != bms_state_get_bat_sta()))
        {
            result = true;
        }
    }
    else
    {
        /* 保护解除：最低电芯温度>-15℃，持续3s */
        if (gp_bmu_data->min_cell_temp > gp_fault_para->chg_under_temp_protect.cancel_value)
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief		电芯充电低温保护打印函数
 */
static void chg_cell_temp_low_pro_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("lCellTemp=%d\n", gp_bmu_data->min_cell_temp);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->chg_under_temp_protect.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->chg_under_temp_protect.cancel_value);
    }
}

/**
* @brief       电芯放电过温提示检测
 */
static bool dchg_cell_temp_high_tips_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || I16_INVALID_VALUE == gp_bmu_data->max_cell_temp || fault_state_get(BOARD_CELL_TEMP_SAM_FAULT))
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 提示：非充电时，最高电芯温度>50℃，持续3s */
        if ((gp_bmu_data->max_cell_temp > gp_fault_para->dchg_over_temp_tip.appear_value) &&
            (BMS_CHARGE_MODE != bms_state_get_bat_sta()))
        {
            result = true;
        }
    }
    else
    {
        /* 提示解除：最高电芯温度<45℃，持续3s */
        if (gp_bmu_data->max_cell_temp < gp_fault_para->dchg_over_temp_tip.cancel_value)
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief		电芯放电过温提示打印函数
 */
static void dchg_cell_temp_high_tips_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("hCellTemp=%d\n", gp_bmu_data->max_cell_temp);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->dchg_over_temp_tip.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->dchg_over_temp_tip.cancel_value);
    }
}

/**
* @brief       电芯放电过温告警检测
 */
static bool dchg_cell_temp_high_alarm_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || I16_INVALID_VALUE == gp_bmu_data->max_cell_temp || fault_state_get(BOARD_CELL_TEMP_SAM_FAULT))
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 告警：非充电时，最高电芯温度>55℃，持续3s */
        if ((gp_bmu_data->max_cell_temp > gp_fault_para->dchg_over_temp_alarm.appear_value) &&
            (BMS_CHARGE_MODE != bms_state_get_bat_sta()))
        {
            result = true;
        }
    }
    else
    {
        /* 告警解除：最高电芯温度<50℃，持续3s */
        if (gp_bmu_data->max_cell_temp < gp_fault_para->dchg_over_temp_alarm.cancel_value)
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief		电芯放电过温告警打印函数
 */
static void dchg_cell_temp_high_alarm_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("hCellTemp=%d\n", gp_bmu_data->max_cell_temp);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->dchg_over_temp_alarm.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->dchg_over_temp_alarm.cancel_value);
    }
}

/**
 * @brief       电芯放电过温保护检测
 */
static bool dchg_cell_temp_high_pro_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || I16_INVALID_VALUE == gp_bmu_data->max_cell_temp || fault_state_get(BOARD_CELL_TEMP_SAM_FAULT)
        )
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 保护：非充电时，最高电芯温度>60℃，持续3s */
        if ((gp_bmu_data->max_cell_temp > gp_fault_para->dchg_over_temp_protect.appear_value) &&
            (BMS_CHARGE_MODE != bms_state_get_bat_sta()))
        {
            result = true;
        }
    }
    else
    {
        /* 保护解除：最高电芯温度<55℃，持续3s */
        if (gp_bmu_data->max_cell_temp < gp_fault_para->dchg_over_temp_protect.cancel_value)
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief		电芯放电过温保护打印函数
 */
static void dchg_cell_temp_high_pro_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("hCellTemp=%d\n", gp_bmu_data->max_cell_temp);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->dchg_over_temp_protect.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->dchg_over_temp_protect.cancel_value);
    }
}

/**
 * @brief       电芯放电低温提示检测
 */
static bool dchg_cell_temp_low_tips_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || I16_INVALID_VALUE == gp_bmu_data->min_cell_temp || fault_state_get(BOARD_CELL_TEMP_SAM_FAULT))
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 提示：非充电时，最高电芯温度<0℃，持续3s */
        if ((gp_bmu_data->min_cell_temp < gp_fault_para->dchg_under_temp_tip.appear_value) &&
            (BMS_CHARGE_MODE != bms_state_get_bat_sta()))
        {
            result = true;
        }
    }
    else
    {
        /* 提示解除：最高电芯温度>5℃，持续3s */
        if (gp_bmu_data->min_cell_temp > gp_fault_para->dchg_under_temp_tip.cancel_value)
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief		电芯放电低温提示打印函数
 */
static void dchg_cell_temp_low_tips_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("lCellTemp=%d\n", gp_bmu_data->min_cell_temp);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->dchg_under_temp_tip.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->dchg_under_temp_tip.cancel_value);
    }
}

/**
 * @brief       电芯放电低温告警检测
 */
static bool dchg_cell_temp_low_alarm_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || I16_INVALID_VALUE == gp_bmu_data->min_cell_temp || fault_state_get(BOARD_CELL_TEMP_SAM_FAULT))
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 告警：非充电时，最高电芯温度<-10℃，持续3s */
        if ((gp_bmu_data->min_cell_temp < gp_fault_para->dchg_under_temp_alarm.appear_value) &&
            (BMS_CHARGE_MODE != bms_state_get_bat_sta()))
        {
            result = true;
        }
    }
    else
    {
        /* 告警解除：最高电芯温度>-5℃，持续3s */
        if (gp_bmu_data->min_cell_temp > gp_fault_para->dchg_under_temp_alarm.cancel_value)
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief		电芯放电低温告警打印函数
 */
static void dchg_cell_temp_low_alarm_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("lCellTemp=%d\n", gp_bmu_data->min_cell_temp);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->dchg_under_temp_alarm.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->dchg_under_temp_alarm.cancel_value);
    }
}

/**
 * @brief       电芯放电低温保护检测
 */
static bool dchg_cell_temp_low_pro_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || I16_INVALID_VALUE == gp_bmu_data->min_cell_temp || fault_state_get(BOARD_CELL_TEMP_SAM_FAULT))
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 保护：非充电时，最高电芯温度<-20℃，持续3s */
        if ((gp_bmu_data->min_cell_temp < gp_fault_para->dchg_under_temp_protect.appear_value) &&
            (BMS_CHARGE_MODE != bms_state_get_bat_sta()))
        {
            result = true;
        }
    }
    else
    {
        /* 保护解除：最高电芯温度>-15℃，持续3s */
        if (gp_bmu_data->min_cell_temp > gp_fault_para->dchg_under_temp_protect.cancel_value)
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief		电芯放电低温保护打印函数
 */
static void dchg_cell_temp_low_pro_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("lCellTemp=%d\n", gp_bmu_data->min_cell_temp);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->dchg_under_temp_protect.appear_value);
    }
    else
    {
       fault_cancel_value_print_deal(gp_fault_para->dchg_under_temp_protect.cancel_value);
    }
}

/**
 * @brief   电芯温差过大提示检测
 */
static bool cell_temp_diff_over_tips_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || U16_INVALID_VALUE == gp_bmu_data->diff_cell_temp || fault_state_get(BOARD_CELL_TEMP_SAM_FAULT))
    {
        return false;
    }

    if (ALARM_APPEAR == is_appear)
    {
        /* 提示：单体温差 > 15℃，持续3s */
        if (gp_bmu_data->diff_cell_temp > gp_fault_para->cell_temp_diff_tip.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 提示解除：单体温差 < 10℃,持续3s */
        if (gp_bmu_data->diff_cell_temp < gp_fault_para->cell_temp_diff_tip.cancel_value)
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief 单体温差过大提示打印函数
 */
static void cell_temp_diff_over_tips_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("CellTdiff=%d\n", gp_bmu_data->diff_cell_temp);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->cell_temp_diff_tip.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->cell_temp_diff_tip.cancel_value);
    }
}

/**
 * @brief   电芯温差过大告警检测
 */
static bool cell_temp_diff_over_alarm_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || U16_INVALID_VALUE == gp_bmu_data->diff_cell_temp || fault_state_get(BOARD_CELL_TEMP_SAM_FAULT))
    {
        return false;
    }

    if (ALARM_APPEAR == is_appear)
    {
        /* 提示：单体温差 > 20℃，持续3s */
        if (gp_bmu_data->diff_cell_temp > gp_fault_para->cell_temp_diff_alarm.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 提示解除：单体温差 < 15℃,持续3s */
        if (gp_bmu_data->diff_cell_temp < gp_fault_para->cell_temp_diff_alarm.cancel_value)
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief 单体温差过大告警打印函数
 */
static void cell_temp_diff_over_alarm_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("CellTdiff=%d\n", gp_bmu_data->diff_cell_temp);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->cell_temp_diff_alarm.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->cell_temp_diff_alarm.cancel_value);
    }
}

/**
 * @brief   电芯温差过大保护检测
 */
static bool cell_temp_diff_over_protect_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || U16_INVALID_VALUE == gp_bmu_data->diff_cell_temp || fault_state_get(BOARD_CELL_TEMP_SAM_FAULT))
    {
        return false;
    }

    if (ALARM_APPEAR == is_appear)
    {
        /* 提示：单体温差 > 30℃，持续3s */
        if (gp_bmu_data->diff_cell_temp > gp_fault_para->cell_temp_diff_protect.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 提示解除：单体温差 < 25℃,持续3s */
        if (gp_bmu_data->diff_cell_temp < gp_fault_para->cell_temp_diff_protect.cancel_value)
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief 单体温差过大保护打印函数
 */
static void cell_temp_diff_over_protect_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("CellTdiff=%d\n", gp_bmu_data->diff_cell_temp);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->cell_temp_diff_protect.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->cell_temp_diff_protect.cancel_value);
    }
}

/**
 * @brief       被动均衡温度检测告警
 */
static bool alarm_cell_balance_temp_over_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (I16_INVALID_VALUE == gp_bmu_data->adc_sample_other_temp[OTHER_BAL_RES_NTC1] ||
        I16_INVALID_VALUE == gp_bmu_data->adc_sample_other_temp[OTHER_BAL_RES_NTC2])
    {
        return false;
    }


    int16_t high_temp = gp_bmu_data->adc_sample_other_temp[OTHER_BAL_RES_NTC1];
    for(int i = OTHER_BAL_RES_NTC1; i <=OTHER_BAL_RES_NTC8; i ++)
    {
        if(gp_bmu_data->adc_sample_other_temp[i] > high_temp)
        {
            high_temp = gp_bmu_data->adc_sample_other_temp[i];
        }
    }

    if (ALARM_APPEAR == is_appear)
    {
        /* 告警：均衡电阻最高温度≥90℃，持续5s */
        if (high_temp >= 900)
        {
            result = true;
        }
    }
    else
    {
        /* 告警解除：均衡电阻温度<80℃，持续5s */
        if (high_temp < 800)
        {
             result = true;
        }
    }
    return result;
}

/**
 * @brief		均衡温度检测告警打印函数
 */
static void alarm_cell_balance_temp_over_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (is_appear)
    {
        FAULT_MANAGE_LOGE("balResNtc1=%d\n", gp_bmu_data->adc_sample_other_temp[OTHER_BAL_RES_NTC1]);
        FAULT_MANAGE_LOGE("balResNtc2=%d\n", gp_bmu_data->adc_sample_other_temp[OTHER_BAL_RES_NTC2]);
    }
}

/**
 * @brief   电芯极限故障检测
 */
static bool cell_limit_fault_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    int32_t diff_volt1 = 0;
    int32_t diff_volt2 = 0;
    int32_t diff_volt3 = 0;

    diff_volt1 = gp_bmu_data->max_cell_volt - gp_bmu_data->avg_cell_volt;
    diff_volt2 = gp_bmu_data->max_cell_volt - gp_bmu_data->min_cell_volt;
    diff_volt3 = gp_bmu_data->avg_cell_volt - gp_bmu_data->min_cell_volt;

    if (is_appear == ALARM_APPEAR)
    {
        if (
            gp_bmu_data->max_cell_volt > 4000      ||
            gp_bmu_data->min_cell_volt < 2000      ||
            gp_bmu_data->max_cell_temp > 900       ||
            (((abs(diff_volt1) > 500) || (abs(diff_volt3) > 500)) && (abs(diff_volt2) > 1000))
            )
        {
            result = true; 
        }
    }
    else
    {
        result = false;     // 不恢复
    }

    return result;
}

/**
 * @brief	电芯极限故障打印函数
 */
static void cell_limit_fault_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (is_appear)
    {
        FAULT_MANAGE_LOGE("hCellV=%dmV,lCellV=%dmV,aCellV=%dmV,hCellTemp=%d\n", gp_bmu_data->max_cell_volt, gp_bmu_data->min_cell_volt, gp_bmu_data->avg_cell_volt, gp_bmu_data->max_cell_temp);
    }
}

/**
 * @brief       温升过大（不恢复）
 */
static bool cell_temp_rise_diff_over_fault_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    if (ALARM_APPEAR == is_appear)
    {
        /* 1min内温度上升大于10且无触发电芯温度采样故障 */
        if (cell_temp_rise_abnormal_get() && false == fault_state_get(BOARD_CELL_TEMP_SAM_FAULT))
        {
            result = true;
        }
    }
    return result;
}

/**
 * @brief       电芯电压采样线异常（不可恢复）
 */
static bool fault_cell_volt_wire_abnormal_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    result = (AFE_ERR_WIRE_OPEN == afe_abnormal_state_get());
    if (ALARM_APPEAR == is_appear)
    {
        return result;
    }
    else
    {
        return false;
    }
}

/**
 * @brief   电芯温度采集异常检测
 */
static bool fault_cell_temp_sam_abnormal_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    uint8_t temp_err_cnt = 0;

    for (stack_board_name_e i = S1; i < STACK_BOARDS; i++)
    {
        for(uint8_t j = 0;j < AFE_CELL_TEMP_NUM;j++)
	    {
		    if (NTC_OPEN_CIRCUIT_ERR == afe_cell_temp_sample_abnormal_get(i,j) ||
                NTC_SHORT_CIRCUIT_ERR == afe_cell_temp_sample_abnormal_get(i,j))
		    {
                temp_err_cnt++;
                g_cell_temp_wire_err_no = i*AFE_CELL_TEMP_NUM + j;
		    }
	    }
    }
    
    if(BOARD_CELL_TEMP_SAM_FAULT == fault_id)   //故障要大于1，提示的话有1个异常就可以
    {
        if(temp_err_cnt > 1)
        {
            result = true;
        }
    }
    else
    {
        if(temp_err_cnt != 0)
        {
            result = true;
        }        
    }
    
    if (is_appear == ALARM_APPEAR)
    {
        return result;
    }
    else
    {
        return false;   // 不恢复
    }
}

/**
 * @brief	电芯温度采样异常打印函数
 */
static void fault_cell_temp_sam_abnormal_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (!is_appear)
    {
        return;
    }
    
	for(stack_board_name_e i = S1; i < STACK_BOARDS; i++)
	{
		for (uint8_t j = 0; j < AFE_CELL_TEMP_NUM; j++)
		{
			if (NTC_OPEN_CIRCUIT_ERR == afe_cell_temp_sample_abnormal_get(i,j))
			{
				FAULT_MANAGE_LOGE("CELL_NTC[%d]openErr\n", i*AFE_CELL_TEMP_NUM + j);
			}

            if (NTC_SHORT_CIRCUIT_ERR == afe_cell_temp_sample_abnormal_get(i,j))
			{
				FAULT_MANAGE_LOGE("CELL_NTC[%d]shortErr\n", i*AFE_CELL_TEMP_NUM + j);
			}
		}  
	}		
}

/**
 * @brief   均衡温度采集异常检测
 */
static bool alarm_bal_temp_sam_abnormal_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    for (stack_board_name_e i = S1; i < STACK_BOARDS; i++)
    {
		for (uint8_t j = BALANCE_TEMP1_POS; j <= BALANCE_TEMP2_POS; j++)
		{
			if (NTC_OPEN_CIRCUIT_ERR == afe_other_temp_sample_abnormal_get(i,j) ||
                NTC_SHORT_CIRCUIT_ERR == afe_other_temp_sample_abnormal_get(i,j))
			{
				result = true;
				break;
			}
		}

        if (result == true)
        {
            break;
        }
	}
    
    if (is_appear == ALARM_APPEAR)
    {
        return result;
    }
    else
    {
        return false;   // 不恢复
    }
}

/**
 * @brief	均衡温度采样异常打印函数
 */
static void alarm_bal_temp_sam_abnormal_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (!is_appear)
    {
        return;
    }
    
	for(stack_board_name_e i = S1; i < STACK_BOARDS; i++)
	{
		for (uint8_t j = BALANCE_TEMP1_POS; j <= BALANCE_TEMP2_POS; j++)
		{
			if (NTC_OPEN_CIRCUIT_ERR == afe_other_temp_sample_abnormal_get(i,j))
			{
				FAULT_MANAGE_LOGE("BAL_NTC[%d]openErr\n", i*AFE_BALANCE_TEMP_NUM + j - BALANCE_TEMP1_POS);
			}

            if (NTC_SHORT_CIRCUIT_ERR == afe_other_temp_sample_abnormal_get(i,j))
			{
				FAULT_MANAGE_LOGE("BAL_NTC[%d]shortErr\n", i*AFE_BALANCE_TEMP_NUM + j - BALANCE_TEMP1_POS);
			}
		}  
	}		
}

/**
 * @brief   环境温度采集异常检测
 */
static bool alarm_env_temp_sam_abnormal_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    for (uint8_t i = 0; i < MCU_OTHER_TEMP_END; i++)
    {
        if (NTC_OPEN_CIRCUIT_ERR ==mcu_sample_abnormal_get((other_ntc_type_e)i) ||
            NTC_SHORT_CIRCUIT_ERR == mcu_sample_abnormal_get((other_ntc_type_e)i))
        {
            result = true;
            break;
        }
    }
    
    if (is_appear == ALARM_APPEAR)
    {
        return result;
    }
    else
    {
        return false;   // 不恢复
    }
}

/**
 * @brief	环境温度采样异常打印函数
 */
static void alarm_env_temp_sam_abnormal_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (!is_appear)
    {
        return;
    }
    
	for (uint8_t i = 0; i < MCU_OTHER_TEMP_END; i++)
    {
        if (NTC_OPEN_CIRCUIT_ERR == mcu_sample_abnormal_get((other_ntc_type_e)i))
        {
            FAULT_MANAGE_LOGE("ENV_NTC[%d]openErr\n", i);
        }

        if (NTC_SHORT_CIRCUIT_ERR == mcu_sample_abnormal_get((other_ntc_type_e)i))
        {
            FAULT_MANAGE_LOGE("ENV_NTC[%d]shortErr\n", i);
        }
    }		
}

/**
 * @brief   功率端子温度采集异常检测
 */
static bool fault_power_terminal_temp_sam_abnormal_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    if((NTC_OPEN_CIRCUIT_ERR == afe_other_temp_sample_abnormal_get(S1,PWR_TEMP_POS))  || 
       (NTC_SHORT_CIRCUIT_ERR == afe_other_temp_sample_abnormal_get(S1,PWR_TEMP_POS)) ||
       (NTC_OPEN_CIRCUIT_ERR == afe_other_temp_sample_abnormal_get(S4,PWR_TEMP_POS))  ||
       (NTC_SHORT_CIRCUIT_ERR == afe_other_temp_sample_abnormal_get(S4,PWR_TEMP_POS)))
    {
        result = true; 
    }
    
    if (is_appear == ALARM_APPEAR)
    {
        return result;
    }
    else
    {
        return false;   // 不恢复
    }
}

/**
 * @brief	功率端子温度采样异常打印函数
 */
static void fault_power_terminal_temp_sam_abnormal_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (!is_appear)
    {
        return;
    }
    
	if(NTC_OPEN_CIRCUIT_ERR == afe_other_temp_sample_abnormal_get(S1,PWR_TEMP_POS))
    {
        FAULT_MANAGE_LOGE("POWER_NTC[1]openErr\n");
    }

    if(NTC_OPEN_CIRCUIT_ERR == afe_other_temp_sample_abnormal_get(S4,PWR_TEMP_POS))
    {
        FAULT_MANAGE_LOGE("POWER_NTC[2]openErr\n");
    }

    if(NTC_SHORT_CIRCUIT_ERR == afe_other_temp_sample_abnormal_get(S1,PWR_TEMP_POS))
    {
        FAULT_MANAGE_LOGE("POWER_NTC[1]shortErr\n");
    }

    if(NTC_SHORT_CIRCUIT_ERR == afe_other_temp_sample_abnormal_get(S4,PWR_TEMP_POS))
    {
        FAULT_MANAGE_LOGE("POWER_NTC[2]shortErr\n");
    }
}

/**
 * @brief    功率端子过温检测
 */
static bool pro_power_terminal_temp_over_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    if (gp_bmu_data->adc_sample_other_temp[OTHER_POWER_NTC1] == I16_INVALID_VALUE ||
        gp_bmu_data->adc_sample_other_temp[OTHER_POWER_NTC2] == I16_INVALID_VALUE)
    {
        return result;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 保护：B+或B-功率端子温度>100℃，持续3s */
        if ((gp_bmu_data->adc_sample_other_temp[OTHER_POWER_NTC1] > 1000) ||
            (gp_bmu_data->adc_sample_other_temp[OTHER_POWER_NTC2] > 1000))
        {
            result = true;
        }
    }
    else
    {
        /* 保护解除：B+且B-功率端子温度<95℃，持续3s */
        if ((gp_bmu_data->adc_sample_other_temp[OTHER_POWER_NTC1] < 950) &&
            (gp_bmu_data->adc_sample_other_temp[OTHER_POWER_NTC2] < 950))
        {
            result = true; 
        }
    }
    return result;
}

/**
 * @brief		功率端子过温打印函数
 */
static void pro_power_terminal_temp_over_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (is_appear)
    {
        FAULT_MANAGE_LOGE("B+tmp=%d\n", gp_bmu_data->adc_sample_other_temp[OTHER_POWER_NTC1]);
        FAULT_MANAGE_LOGE("B-tmp=%d\n", gp_bmu_data->adc_sample_other_temp[OTHER_POWER_NTC2]);
    }
}

/**
 * @brief       电池包电压压差过大异常（不可恢复）
 */
static bool bat_volt_diff_fault_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (U32_INVALID_VALUE == gp_bmu_data->bat_afe_volt ||
        U32_INVALID_VALUE == gp_bmu_data->bat_acc_volt)
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        // 故障触发：|Σcells电压-电池包电压| > 9.6 V，连续 10 s
        int32_t diff_volt = gp_bmu_data->bat_afe_volt - gp_bmu_data->bat_acc_volt;
        if ((abs(diff_volt)) > 9600)
        {
            result = true;
        }
    }
    return result;
}

/**
 * @brief		电池包电压压差过大异常打印函数
 */
static void bat_volt_diff_fault_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (is_appear)
    {
        FAULT_MANAGE_LOGE("afeV=%d,accV=%d\n", gp_bmu_data->bat_afe_volt, gp_bmu_data->bat_acc_volt);
    }
}

/**
 * @brief       环境温度过高告警
 */
static bool alarm_env_temp_high_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || I16_INVALID_VALUE == gp_bmu_data->adc_sample_other_temp[OTHER_ENV_NTC])
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 告警：环境温度>75℃，持续1s */
        if (gp_bmu_data->adc_sample_other_temp[OTHER_ENV_NTC] > gp_fault_para->ent_over_temp_alarm.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 告警解除：环境温度<70℃，持续1s */
        if (gp_bmu_data->adc_sample_other_temp[OTHER_ENV_NTC] < gp_fault_para->ent_over_temp_alarm.cancel_value)
        {
            result = true;
        }
    }
    return result;
}

/**
 * @brief       环境温度告警打印函数
 */
static void alarm_env_temp_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);

    if (gp_fault_para == NULL)
    {
        return;
    }
    
    if (is_appear)
    {
        FAULT_MANAGE_LOGE("EnvTmp=%d\n", gp_bmu_data->adc_sample_other_temp[OTHER_ENV_NTC]);

        if (fault_id == BOARD_ENV_TEMP_HIGH_ALARM)
        {
            fault_appear_value_print_deal(gp_fault_para->ent_over_temp_alarm.appear_value);
        }
        else if (fault_id == BOARD_ENV_TEMP_LOW_ALARM)
        {
            fault_appear_value_print_deal(gp_fault_para->ent_under_temp_alarm.appear_value);
        }
    }
    else
    {
        FAULT_MANAGE_LOGE("EnvTmp=%d\n", gp_bmu_data->adc_sample_other_temp[OTHER_ENV_NTC]);

        if (fault_id == BOARD_ENV_TEMP_HIGH_ALARM)
        {
            fault_cancel_value_print_deal(gp_fault_para->ent_over_temp_alarm.cancel_value);
        }
        else if (fault_id == BOARD_ENV_TEMP_LOW_ALARM)
        {
            fault_cancel_value_print_deal(gp_fault_para->ent_under_temp_alarm.cancel_value);
        }
    }
}

/**
 * @brief       环境温度过低告警
 */
static bool alarm_env_temp_low_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    if (NULL == gp_fault_para || I16_INVALID_VALUE == gp_bmu_data->adc_sample_other_temp[OTHER_ENV_NTC])
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        /* 告警：环境温度<-20℃，持续1s */
        if (gp_bmu_data->adc_sample_other_temp[OTHER_ENV_NTC] < gp_fault_para->ent_under_temp_alarm.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 告警解除：环境温度>-15℃，持续1s */
        if (gp_bmu_data->adc_sample_other_temp[OTHER_ENV_NTC] > gp_fault_para->ent_under_temp_alarm.cancel_value)
        {
            result = true;
        }
    }
    return result;
}

/**
 * @brief       硬件自检故障
 */
static bool fault_hard_self_det_check(fault_type_e fault_id, bool is_appear)
{
    uint8_t result = false;

    if (DIAG_ON_RUNNING == g_fault_diag_step)
    {
        return false;
    }

    const sample_data_t *sample_data = sample_data_p_get();

    if (sample_data == NULL)
    {
        return false;
    }

    if (sample_data->check_24v_volt > 33600 || 
        sample_data->check_24v_volt < 17100)
    {
        SET_BIT(g_hard_self_det_abn_flag, POWER_24V_ABN);
    }
    else if (sample_data->check_24v_volt > 18000 && 
             sample_data->check_24v_volt < 32000)
    {
        CLR_BIT(g_hard_self_det_abn_flag, POWER_24V_ABN);
    }

    if (sample_data->check_5v_volt < 4750 || sample_data->check_5v_volt > 5250)
    {
        SET_BIT(g_hard_self_det_abn_flag, HALL_5V_ABN);
    }
    else
    {
        CLR_BIT(g_hard_self_det_abn_flag, HALL_5V_ABN);
    }

    if (g_hard_self_det_abn_flag)
    {
        result = true;
    }
    else
    {
        result = false;
    }

    if (is_appear)
    {
        return result;
    }
    else
    {
        return !result;
    }
}

/**
 * @brief   硬件自检异常打印
 */
static void fault_hard_self_det_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    
    if (is_appear)
    {
        log_e("hs_abn_flag=%#x\n", g_hard_self_det_abn_flag);
    }
}


/**
 * @brief       afe断单链告警
 */
static bool alarm_afe_chain_break_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    if (ALARM_APPEAR == is_appear)
    {

        if(AFE_ERR_CHAIN_BREAK == afe_abnormal_state_get())
        {
            result = true;
        }
    }
    else
    {
        if (AFE_ERR_CHAIN_BREAK != afe_abnormal_state_get())
        {
            result = true;
        }
    }

    return result;
    
}


/**
 * @brief       电解液漏液传感器触发告警
 */
static bool alarm_electrolyte_sensor_err_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    const sample_data_t *sample_data = sample_data_p_get();

    if (sample_data == NULL)
    {
        return false;
    }
    
    if (ALARM_APPEAR == is_appear)
    {
        if ((sample_data->electrolyte_sensor_data.error != 0)
            || (sample_data->electrolyte_sensor_data.com_abnor_flag == true)  //在sample.c里做了10S计数
           )
        {
            result = true;
        }
    }
    else
    {
        if ((sample_data->electrolyte_sensor_data.error == 0)
            && (sample_data->electrolyte_sensor_data.com_abnor_flag == false))
        {
            result = false;
        }
    }

    return result;
    
}

/**
 * @brief   电解液漏液传感器触发告警打印
 */
static void alarm_electrolyte_sensor_err_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);

    const sample_data_t *sample_data = sample_data_p_get();

    if (sample_data == NULL)
    {
        return ;
    }
    
    if (is_appear)
    {
        log_e("electrolyte sen errcode=%d,com fail:%d\n", sample_data->electrolyte_sensor_data.error,sample_data->electrolyte_sensor_data.com_abnor_flag);
    }
}

/**
 * @brief       单体电压过压锁死检测
 */
static void cell_volt_over_disable_deal(void)
{
    static int32_t last_cell_volt_over_pro_flag = FAULT_STOP;
    static uint32_t cell_volt_over_cnt[OVER_VOLT_LOCK_TIMES] = {0};
    static uint16_t cell_volt_over_pro_times = 0;
    if (FAULT_START == fault_state_get(BAT_VOLT_HIGH_DISABLE))
    {
        last_cell_volt_over_pro_flag = FAULT_STOP;
        cell_volt_over_pro_times = 0;
        return;
    }
    bool result = false;
    // 单电芯过压保护锁死判断
    int32_t curr_cell_volt_over_pro_flag = fault_state_get(BAT_CELL_VOLT_HIGH_PROTECT);
    // 触发单电芯过压记录tick以及更新次数
    if ((last_cell_volt_over_pro_flag == FAULT_STOP) &&
        (curr_cell_volt_over_pro_flag == FAULT_START))
    {
        cell_volt_over_cnt[cell_volt_over_pro_times % OVER_VOLT_LOCK_TIMES] = sdk_tick_get();
        cell_volt_over_pro_times++;
    }
    last_cell_volt_over_pro_flag = curr_cell_volt_over_pro_flag;
    result = continuous_pro_lock_judge_deal(cell_volt_over_cnt, OVER_VOLT_LOCK_TIMES, &cell_volt_over_pro_times, 2400000);  //40 mins
    
    if (result)
    {
        g_fault_lock_data.cell_volt_over_protect_times = OVER_VOLT_LOCK_TIMES;
    }
    else
    {
        g_fault_lock_data.cell_volt_over_protect_times = (cell_volt_over_pro_times < OVER_VOLT_LOCK_TIMES) ? cell_volt_over_pro_times : (OVER_VOLT_LOCK_TIMES - 1);
    }
}

/**
 * @brief       总压电压过压保护失能检测
 */
static void bat_volt_over_disable_deal(void)
{
    static int32_t last_bat_volt_over_pro_flag = FAULT_STOP;
    static uint32_t bat_volt_over_cnt[OVER_VOLT_LOCK_TIMES] = {0};
    static uint16_t bat_volt_over_pro_times = 0;
    if (FAULT_START == fault_state_get(BAT_VOLT_HIGH_DISABLE))
    {
        last_bat_volt_over_pro_flag = FAULT_STOP;
        bat_volt_over_pro_times = 0;
        return;
    }
    bool result = false;
    // 总压过压保护锁死判断
    int32_t curr_bat_volt_over_pro_flag = fault_state_get(BAT_TOTAL_VOLT_HIGH_PROTECT);
    // 触发单电芯过压记录tick以及更新次数
    if ((last_bat_volt_over_pro_flag == FAULT_STOP) &&
        (curr_bat_volt_over_pro_flag == FAULT_START))
    {
        bat_volt_over_cnt[bat_volt_over_pro_times % OVER_VOLT_LOCK_TIMES] = sdk_tick_get();
        bat_volt_over_pro_times++;
    }
    last_bat_volt_over_pro_flag = curr_bat_volt_over_pro_flag;
    result = continuous_pro_lock_judge_deal(bat_volt_over_cnt, OVER_VOLT_LOCK_TIMES, &bat_volt_over_pro_times, 2400000);    //40 mins
    
    if (result)
    {
        g_fault_lock_data.total_volt_over_protect_times = OVER_VOLT_LOCK_TIMES;
    }
    else
    {
        g_fault_lock_data.total_volt_over_protect_times = (bat_volt_over_pro_times < OVER_VOLT_LOCK_TIMES) ? bat_volt_over_pro_times : (OVER_VOLT_LOCK_TIMES - 1);
    }
}

/**
 * @brief       电压过压保护失能检测
 */
static bool volt_over_disable_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    static uint32_t curr_tick = 0;
    cell_volt_over_disable_deal();
    bat_volt_over_disable_deal();

    if (ALARM_APPEAR == is_appear)
    {
        result = (bool)(OVER_VOLT_LOCK_TIMES <= g_fault_lock_data.cell_volt_over_protect_times ||
            OVER_VOLT_LOCK_TIMES <= g_fault_lock_data.total_volt_over_protect_times);
        curr_tick = sdk_tick_get();
    }
    else
    {
        //过压相关保护消失且持续2小时
        if((FAULT_STOP == fault_state_get(BAT_TOTAL_VOLT_HIGH_PROTECT))
            && (FAULT_STOP == fault_state_get(BAT_CELL_VOLT_HIGH_PROTECT))
            && (true == sdk_is_tick_over(curr_tick, 2*60*60*1000))
                )
        {
             result = true;
             g_fault_lock_data.cell_volt_over_protect_times = 0;
             g_fault_lock_data.total_volt_over_protect_times = 0;          
        }
        else
        {
            curr_tick = sdk_tick_get();
        }
    }
    return result;
}

/**
 * @brief        电压过压保护失能测打印函数
 */
static void volt_over_disable_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (is_appear)
    {
        FAULT_MANAGE_LOGE("cellOvCnt=%d(%d)\n", g_fault_lock_data.cell_volt_over_protect_times, OVER_VOLT_LOCK_TIMES);
        FAULT_MANAGE_LOGE("batOvCnt=%d\n", g_fault_lock_data.total_volt_over_protect_times);
    }
}

/**
 * @brief       单体电压低压锁死检测
 */
static void cell_under_volt_disable_deal(void)
{
    static int32_t last_cell_under_volt_pro_flag = FAULT_STOP;
    static uint32_t cell_under_volt_cnt[LOW_VOLT_LOCK_TIMES] = {0};
    static uint16_t cell_under_volt_pro_times = 0;
    if (FAULT_START == fault_state_get(BAT_VOLT_LOW_DISABLE))
    {
        last_cell_under_volt_pro_flag = FAULT_STOP;
        cell_under_volt_pro_times = 0;
        return;
    }
    bool result = false;
    // 单电芯过压保护锁死判断
    int32_t curr_cell_under_volt_pro_flag = fault_state_get(BAT_CELL_VOLT_LOW_PROTECT);
    // 触发单电芯过压记录tick以及更新次数
    if ((last_cell_under_volt_pro_flag == FAULT_STOP) &&
        (curr_cell_under_volt_pro_flag == FAULT_START))
    {
        cell_under_volt_cnt[cell_under_volt_pro_times % LOW_VOLT_LOCK_TIMES] = sdk_tick_get();
        cell_under_volt_pro_times++;
    }
    last_cell_under_volt_pro_flag = curr_cell_under_volt_pro_flag;
    result = continuous_pro_lock_judge_deal(cell_under_volt_cnt, LOW_VOLT_LOCK_TIMES, &cell_under_volt_pro_times, 600000);  //10 mins 
    
    if (result)
    {
        g_fault_lock_data.cell_volt_low_protect_times = LOW_VOLT_LOCK_TIMES;
    }
    else
    {
        g_fault_lock_data.cell_volt_low_protect_times = (cell_under_volt_pro_times < LOW_VOLT_LOCK_TIMES) ? cell_under_volt_pro_times : (LOW_VOLT_LOCK_TIMES - 1);
    }
}

/**
 * @brief       总压电压低压保护失能检测
 */
static void bat_under_volt_disable_deal(void)
{
    static int32_t last_bat_under_volt_pro_flag = FAULT_STOP;
    static uint32_t bat_under_volt_cnt[LOW_VOLT_LOCK_TIMES] = {0};
    static uint16_t bat_under_volt_pro_times = 0;
    if (FAULT_START == fault_state_get(BAT_VOLT_LOW_DISABLE))
    {
        last_bat_under_volt_pro_flag = FAULT_STOP;
        bat_under_volt_pro_times = 0;
        return;
    }
    bool result = false;
    // 总压过压保护锁死判断
    int32_t curr_bat_under_volt_pro_flag = fault_state_get(BAT_TOTAL_VOLT_LOW_PROTECT);
    // 触发单电芯过压记录tick以及更新次数
    if ((last_bat_under_volt_pro_flag == FAULT_STOP) &&
        (curr_bat_under_volt_pro_flag == FAULT_START))
    {
        bat_under_volt_cnt[bat_under_volt_pro_times % LOW_VOLT_LOCK_TIMES] = sdk_tick_get();
        bat_under_volt_pro_times++;
    }
    last_bat_under_volt_pro_flag = curr_bat_under_volt_pro_flag;
    result = continuous_pro_lock_judge_deal(bat_under_volt_cnt, LOW_VOLT_LOCK_TIMES, &bat_under_volt_pro_times, 600000);    //10 mins 
    
    if (result)
    {
        g_fault_lock_data.total_volt_low_protect_times = LOW_VOLT_LOCK_TIMES;
    }
    else
    {
        g_fault_lock_data.total_volt_low_protect_times = (bat_under_volt_pro_times < LOW_VOLT_LOCK_TIMES) ? bat_under_volt_pro_times : (LOW_VOLT_LOCK_TIMES - 1);
    }
}

/**
 * @brief       电压低压保护失能检测
 */
static bool volt_under_disable_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    static uint32_t curr_tick = 0;        
    cell_under_volt_disable_deal();
    bat_under_volt_disable_deal();

    if (ALARM_APPEAR == is_appear)
    {
        result = (bool)(OVER_VOLT_LOCK_TIMES <= g_fault_lock_data.cell_volt_low_protect_times ||
            OVER_VOLT_LOCK_TIMES <= g_fault_lock_data.total_volt_low_protect_times);
        curr_tick = sdk_tick_get();
    }
    else
    {
        //欠压压相关保护消失且持续2小时
        if((FAULT_STOP == fault_state_get(BAT_TOTAL_VOLT_LOW_PROTECT))
            && (FAULT_STOP == fault_state_get(BAT_CELL_VOLT_LOW_PROTECT))
            && (true == sdk_is_tick_over(curr_tick, 2*60*60*1000))
                )
        {
             result = true;
             g_fault_lock_data.cell_volt_low_protect_times = 0;
             g_fault_lock_data.total_volt_low_protect_times = 0;          
        }
        else
        {
            curr_tick = sdk_tick_get();
        }
    }
    return result;
}

/**
 * @brief        电压低压保护失能打印函数
 */
static void volt_under_disable_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (is_appear)
    {
        FAULT_MANAGE_LOGE("[ALM]cellUvCnt=%d(%d)\n", g_fault_lock_data.cell_volt_low_protect_times, LOW_VOLT_LOCK_TIMES);
        FAULT_MANAGE_LOGE("[ALM]batUvCnt=%d\n", g_fault_lock_data.total_volt_low_protect_times);
    }
}


/**
 * @brief       电芯放电低温保护失能检测
 */
static void discharge_cell_temp_low_disable_deal(void)
{
    static int32_t last_dchg_cell_temp_low_pro_flag = FAULT_STOP;
    static uint32_t dchg_cell_temp_low_cnt[LOW_TEMP_LOCK_TIMES] = {0};
    static uint16_t dchg_cell_temp_low_pro_times = 0;
    if (FAULT_START == fault_state_get(BAT_CELL_TEMP_OVER_OR_LOW_DISABLE))
    {
        last_dchg_cell_temp_low_pro_flag = FAULT_STOP;
        dchg_cell_temp_low_pro_times = 0;
        return;
    }
    bool result = false;
    // 放电电芯低温保护失能判断
    int32_t dchg_cell_temp_low_pro_flag = fault_state_get(BAT_CELL_DISCHG_TEMP_LOW_PROTECT);
    // 放电电芯低温保护记录tick以及更新次数
    if ((last_dchg_cell_temp_low_pro_flag == FAULT_STOP) &&
        (dchg_cell_temp_low_pro_flag == FAULT_START))
    {
        dchg_cell_temp_low_cnt[dchg_cell_temp_low_pro_times % LOW_TEMP_LOCK_TIMES] = sdk_tick_get();
        dchg_cell_temp_low_pro_times++;
    }
    last_dchg_cell_temp_low_pro_flag = dchg_cell_temp_low_pro_flag;
    result = continuous_pro_lock_judge_deal(dchg_cell_temp_low_cnt, LOW_TEMP_LOCK_TIMES, &dchg_cell_temp_low_pro_times, 3600000);
    
    if (result)
    {
        g_fault_lock_data.dsg_temp_low_protect_times = LOW_TEMP_LOCK_TIMES;
    }
    else
    {
        g_fault_lock_data.dsg_temp_low_protect_times = (dchg_cell_temp_low_pro_times < LOW_TEMP_LOCK_TIMES) ? dchg_cell_temp_low_pro_times : (LOW_TEMP_LOCK_TIMES - 1);
    }
}

/**
 * @brief       电芯放电过温保护失能检测
 */
static void discharge_cell_temp_high_disable_deal(void)
{
    static int32_t last_dchg_cell_temp_high_pro_flag = FAULT_STOP;
    static uint32_t dchg_cell_temp_high_cnt[OVER_TEMP_LOCK_TIMES] = {0};
    static uint16_t dchg_cell_temp_high_pro_times = 0;
    if (FAULT_START == fault_state_get(BAT_CELL_TEMP_OVER_OR_LOW_DISABLE))
    {
        last_dchg_cell_temp_high_pro_flag = FAULT_STOP;
        dchg_cell_temp_high_pro_times = 0;
        return;
    }
    bool result = false;
    // 放电电芯过温保护失能判断
    int32_t dchg_cell_temp_high_pro_flag = fault_state_get(BAT_CELL_DISCHG_TEMP_OVER_PROTECT);
    // 放电电芯过温保护记录tick以及更新次数
    if ((last_dchg_cell_temp_high_pro_flag == FAULT_STOP) &&
        (dchg_cell_temp_high_pro_flag == FAULT_START))
    {
        dchg_cell_temp_high_cnt[dchg_cell_temp_high_pro_times % OVER_TEMP_LOCK_TIMES] = sdk_tick_get();
        dchg_cell_temp_high_pro_times++;
    }
    last_dchg_cell_temp_high_pro_flag = dchg_cell_temp_high_pro_flag;
    result = continuous_pro_lock_judge_deal(dchg_cell_temp_high_cnt, OVER_TEMP_LOCK_TIMES, &dchg_cell_temp_high_pro_times, 3600000);
    
    if (result)
    {
        g_fault_lock_data.dsg_temp_over_protect_times = OVER_TEMP_LOCK_TIMES;
    }
    else
    {
        g_fault_lock_data.dsg_temp_over_protect_times = (dchg_cell_temp_high_pro_times < OVER_TEMP_LOCK_TIMES) ? dchg_cell_temp_high_pro_times : (OVER_TEMP_LOCK_TIMES - 1);
    }
}

/**
 * @brief       充电电芯低温保护失能检测
 */
static void charge_cell_temp_low_disable_deal(void)
{
    static int32_t last_chg_cell_temp_low_pro_flag = FAULT_STOP;
    static uint32_t chg_cell_temp_low_cnt[LOW_TEMP_LOCK_TIMES] = {0};
    static uint16_t chg_cell_temp_low_pro_times = 0;
    if (FAULT_START == fault_state_get(BAT_CELL_TEMP_OVER_OR_LOW_DISABLE))
    {
        last_chg_cell_temp_low_pro_flag = FAULT_STOP;
        chg_cell_temp_low_pro_times = 0;
        return;
    }
    bool result = false;
    // 充电电芯低温保护失能判断;
    int32_t chg_cell_temp_low_pro_flag = fault_state_get(BAT_CELL_CHG_TEMP_LOW_PROTECT);
    // 充电电芯低温保护记录tick以及更新次数
    if ((last_chg_cell_temp_low_pro_flag == FAULT_STOP) &&
        (chg_cell_temp_low_pro_flag == FAULT_START))
    {
        chg_cell_temp_low_cnt[chg_cell_temp_low_pro_times % LOW_TEMP_LOCK_TIMES] = sdk_tick_get();
        chg_cell_temp_low_pro_times++;
    }
    last_chg_cell_temp_low_pro_flag = chg_cell_temp_low_pro_flag;
    result = continuous_pro_lock_judge_deal(chg_cell_temp_low_cnt, LOW_TEMP_LOCK_TIMES, &chg_cell_temp_low_pro_times, 3600000);
    
    if (result)
    {
        g_fault_lock_data.chg_temp_low_protect_times = LOW_TEMP_LOCK_TIMES;
    }
    else
    {
        g_fault_lock_data.chg_temp_low_protect_times = (chg_cell_temp_low_pro_times < LOW_TEMP_LOCK_TIMES) ? chg_cell_temp_low_pro_times : (LOW_TEMP_LOCK_TIMES - 1);
    }
}

/**
 * @brief       充电电芯过温保护失能检测
 */
static void charge_cell_temp_high_disable_deal(void)
{
    static int32_t last_chg_cell_temp_high_pro_flag = FAULT_STOP;
    static uint32_t chg_cell_temp_high_cnt[OVER_TEMP_LOCK_TIMES] = {0};
    static uint16_t chg_cell_temp_high_pro_times = 0;
    if (FAULT_START == fault_state_get(BAT_CELL_TEMP_OVER_OR_LOW_DISABLE))
    {
        last_chg_cell_temp_high_pro_flag = FAULT_STOP;
        chg_cell_temp_high_pro_times = 0;
        return;
    }
    bool result = false;
    // 充电电芯过温保护失能判断
    int32_t chg_cell_temp_high_pro_flag = fault_state_get(BAT_CELL_CHG_TEMP_OVER_PROTECT);
    // 触发单电芯过压记录tick以及更新次数
    if ((last_chg_cell_temp_high_pro_flag == FAULT_STOP) &&
        (chg_cell_temp_high_pro_flag == FAULT_START))
    {
        chg_cell_temp_high_cnt[chg_cell_temp_high_pro_times % OVER_TEMP_LOCK_TIMES] = sdk_tick_get();
        chg_cell_temp_high_pro_times++;
    }
    last_chg_cell_temp_high_pro_flag = chg_cell_temp_high_pro_flag;
    result = continuous_pro_lock_judge_deal(chg_cell_temp_high_cnt, OVER_TEMP_LOCK_TIMES, &chg_cell_temp_high_pro_times, 3600000);
    
    if (result)
    {
        g_fault_lock_data.chg_temp_over_protect_times = OVER_TEMP_LOCK_TIMES;
    }
    else
    {
        g_fault_lock_data.chg_temp_over_protect_times = (chg_cell_temp_high_pro_times < OVER_TEMP_LOCK_TIMES) ? chg_cell_temp_high_pro_times : (OVER_TEMP_LOCK_TIMES - 1);
    }
}
/**
 * @brief       电芯高低温保护失能检查
 */
static bool cell_temp_over_or_low_disable_fault_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    static uint32_t curr_tick = 0;    
    discharge_cell_temp_low_disable_deal();
    discharge_cell_temp_high_disable_deal();
    charge_cell_temp_low_disable_deal();
    charge_cell_temp_high_disable_deal();
    if (ALARM_APPEAR == is_appear)
    {
        result = (bool)(g_fault_lock_data.dsg_temp_low_protect_times >= LOW_TEMP_LOCK_TIMES ||
                        g_fault_lock_data.dsg_temp_over_protect_times >= OVER_TEMP_LOCK_TIMES ||
                        g_fault_lock_data.chg_temp_low_protect_times >= LOW_TEMP_LOCK_TIMES ||
                        g_fault_lock_data.chg_temp_over_protect_times >= OVER_TEMP_LOCK_TIMES);
        curr_tick = sdk_tick_get();
    }
    else
    {
                //温度相关保护消失且持续2小时
        if((FAULT_STOP == fault_state_get(BAT_CELL_CHG_TEMP_LOW_PROTECT))
            && (FAULT_STOP == fault_state_get(BAT_CELL_CHG_TEMP_OVER_PROTECT))
            && (FAULT_STOP == fault_state_get(BAT_CELL_DISCHG_TEMP_LOW_PROTECT))
            && (FAULT_STOP == fault_state_get(BAT_CELL_DISCHG_TEMP_OVER_PROTECT))
            && (true == sdk_is_tick_over(curr_tick, 2*60*60*1000))
                )
        {
             result = true;
             g_fault_lock_data.dsg_temp_low_protect_times = 0;
             g_fault_lock_data.dsg_temp_over_protect_times = 0;
             g_fault_lock_data.chg_temp_low_protect_times = 0;
             g_fault_lock_data.chg_temp_over_protect_times = 0;            
        }
        else
        {
            curr_tick = sdk_tick_get();
        }
    }
    return result;
}

/**
 * @brief        电芯高低温保护失能打印函数
 */
static void cell_temp_over_or_low_disable_fault_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (is_appear)
    {
        FAULT_MANAGE_LOGE("dsgTmpUCnt=%d(%d)\n", g_fault_lock_data.dsg_temp_low_protect_times, LOW_TEMP_LOCK_TIMES);
        FAULT_MANAGE_LOGE("dsgTmpOcnt=%d\n", g_fault_lock_data.dsg_temp_over_protect_times);
        FAULT_MANAGE_LOGE("chgTmpUcnt=%d\n", g_fault_lock_data.chg_temp_low_protect_times);
        FAULT_MANAGE_LOGE("chgTmpOcnt=%d\n", g_fault_lock_data.chg_temp_over_protect_times);
    }
}

/**
 * @brief       电芯严重过压锁死故障检测
 */
static bool cell_volt_over_serious_lock_fault_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    if (NULL == gp_fault_para || U16_INVALID_VALUE == gp_bmu_data->max_cell_volt ||
        fault_state_get(BOARD_CELL_VOLT_WIRE_ABNORMAL_FAULT))
    {
        return false;
    }

    if (ALARM_APPEAR == is_appear)
    {
        /* 最高电芯电压＞4V，持续10s */
        if (gp_bmu_data->max_cell_volt > gp_fault_para->cell_over_vol_seriou.appear_value)
        {
            result = true;
        }
    }
    else
    {
        result = false;     //不恢复
    }
    
    return result;
}

/**
 * @brief        电芯过压严重打印函数
 */
static void cell_volt_over_serious_lock_fault_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    if (is_appear)
    {
        FAULT_MANAGE_LOGE("hCellV=%dmV\n", gp_bmu_data->max_cell_volt);
    }
}

/**
 * @brief		故障管理初始化
 * @param		void
 * @param		void
 * @pre			系统启动时执行一次。
 */
void fault_manage_init(void)
{
    g_fault_enable = false;
    memset(g_fault_state, 0, sizeof(g_fault_state));
    g_fault_diag_step = DIAG_NONE;
    memset(&g_fault_lock_data, 0, sizeof(g_fault_lock_data));
    gp_fault_para = &(get_bms_attr()->safety); // 获取故障安全参数
    g_fault_stat_data.fault_num = 0;
    g_fault_stat_data.max_charge_level = LEVEL3;
    g_fault_stat_data.max_discharge_level = LEVEL3;
    
    g_cell_temp_wire_err_no = U8_INVALID_VALUE;
}

/**
 * @brief		故障诊断功能使能
 * @param		void
 * @param		void
 * @pre			系统启动时执行一次。
 */
void fault_diag_enable(void)
{
    if (true != g_fault_enable)
    {
        g_fault_enable = true;
		log_d("[INFO] fault diag enable\n");
    }
}

/**
 * @brief		故障运行步骤获取
 */
fault_diag_step_e fault_diag_step_get(void)
{
    return (fault_diag_step_e)g_fault_diag_step;
}

/**
 * @brief		故障状态
 * @param		[in] fault_type 故障类型
 * @param		[in] cmd 设置命令
 * @retval		1 有故障
 * @retval		0 无故障
 * @retval		-1 查询失败
 * @pre			执行hal_adc_start后执行才有效。
 */
int32_t fault_state_get(fault_type_e fault_type)
{
    if (FAULT_MAX <= fault_type)
    {
        FAULT_MANAGE_LOGE("[%s] input para err!\r\n", __FUNCTION__);
        return -1;
    }
    uint32_t fault_group_id = fault_type / FAULT_GROUP_SIZE;
    uint32_t fault_offset = fault_type % FAULT_GROUP_SIZE;
    if (0 == GET_BIT(g_fault_state[fault_group_id], (1ULL << fault_offset)))
    {
        return FAULT_STOP;
    }
    else
    {
        return FAULT_START;
    }
}

/**
 * @brief		获单个故障信息
 * @param		[in] fault_type 需要查询的故障类型
 * @param		[out] *p_dout 存放获取的故障数据指针,为空无法获取数据
 * @return		执行结果
 * @retval		0  获取成功
 * @retval		-1 获取失败
 */
int32_t fault_data_get(fault_type_e fault_type, fault_data_t *p_dout)
{
    if ((FAULT_MAX <= fault_type) || (NULL == p_dout))
    {
        FAULT_MANAGE_LOGE("[%s] input para err!\r\n", __FUNCTION__);
        return -1;
    }
    const fault_para_tab_t* fault_info = fault_data_info_get(fault_type);
    if (NULL == fault_info)
    {
        return -1;
    }
    
    p_dout->fault_type = fault_info->fault_type;
    p_dout->fault_status = fault_state_get(fault_info->fault_type);
    p_dout->fault_code = 0;
    p_dout->charge_level = fault_info->charge_level;
    p_dout->discharge_level = fault_info->discharge_level;
    return 0;
}

/**
 * @brief		获取故障统计数据
 * @param		[out] *p_dout 存放获取的故障统计数据指针，为空无法获取数据
 * @return		执行结果
 * @retval		>=0 故障数量
 * @retval		-1  获取失败
 */
#define FAULT_MIN_LEVEL(a, b)  (((a) > (b)) ? (b) : (a))
int32_t fault_stat_data_get(fault_stat_data_t *p_dout)
{
    if (NULL == p_dout)
    {
        FAULT_MANAGE_LOGE("[%s]inputParaErr\n", __FUNCTION__);
        return -1;
    }
    uint16_t fault_num = 0;          // fault number
    uint16_t max_chg_level = LEVEL3; // default level 3 (the lowest)
    uint16_t max_dsg_level = LEVEL3; // default level 3 (the lowest)
    uint8_t  fault_level = 0;

    for (uint16_t index = 0; index < ITEM_NUM(g_fault_para_tab); index++)
    {
        if (FAULT_START ==  fault_state_get(g_fault_para_tab[index].fault_type))
        {
            max_chg_level = FAULT_MIN_LEVEL(g_fault_para_tab[index].charge_level, max_chg_level);
            max_dsg_level = FAULT_MIN_LEVEL(g_fault_para_tab[index].discharge_level, max_dsg_level);
            
            if (g_fault_para_tab[index].charge_level < g_fault_para_tab[index].discharge_level)
            {
                fault_level |=  (0x01 << g_fault_para_tab[index].charge_level);                
            }
            else
            {
                fault_level |=  (0x01 << g_fault_para_tab[index].discharge_level);   
            }

            fault_num++;
        }
    }
    p_dout->fault_num = fault_num;
    p_dout->max_charge_level = max_chg_level;
    p_dout->max_discharge_level = max_dsg_level;
    p_dout->fault_level = fault_level;
    return (int32_t)fault_num;
}

/**
 * @brief		获取充放电故障等级
 * @return		执行结果
 * @retval		>=0 故障数量
 * @retval		-1  获取失败
 */
const fault_stat_data_t* fault_chg_dsg_level_get(void)
{
     return (const fault_stat_data_t*)&g_fault_stat_data;
}

/**
 * @brief		执行保护动作
 * @param		[in] *p_fault_sta 存放获取的故障统计数据指针，为空无法获取数据
 * @return		执行结果
 */
static int32_t fault_protect_action(fault_stat_data_t *p_fault_sta)
{
    if (NULL == p_fault_sta)
    {
        FAULT_MANAGE_LOGE("[%s] input para err!\r\n", __FUNCTION__);
        return -1;
    }

    if ((p_fault_sta->max_charge_level == LEVEL0) || (p_fault_sta->max_discharge_level == LEVEL0) || 
		(p_fault_sta->max_charge_level == LEVEL1) || (p_fault_sta->max_discharge_level == LEVEL1))
    {
        g_cut_off_relay = true;
    }
    else
    {
        g_cut_off_relay = false;
    }

    if ((p_fault_sta->max_charge_level == LEVEL0) || 
		(p_fault_sta->max_charge_level == LEVEL1) ||
		(p_fault_sta->max_charge_level == LEVEL2))
    {
        g_limit_chg = true;
    }
    else
    {
        g_limit_chg = false;
    }

    if ((p_fault_sta->max_discharge_level == LEVEL0) || 
		(p_fault_sta->max_discharge_level == LEVEL1) ||
		(p_fault_sta->max_discharge_level == LEVEL2))
    {
        g_limit_dsg = true;
    }
    else
    {
        g_limit_dsg = false;
    }

    return true;
}
/**
 * @brief		获取保护动作
 * @param		[in] type 故障动作类型
 * @return		执行结果
 */
int32_t fault_protect_action_get(fault_protect_action_e type)
{
    uint8_t temp_flag = 0XFF;

    if (type >= PROTECT_ACTION_NUM_END)
    {
        FAULT_MANAGE_LOGE("[%s]InputParaErr\n", __FUNCTION__);
        return -1;
    }

    switch (type)
    {
    case LIMIT_CHARGE_CURRENT:
    {
        temp_flag = g_limit_chg;

        break;
    }
    case LIMIT_DISCHARGE_CURRENT:
    {
        temp_flag = g_limit_dsg;

        break;
    }
    case CUT_OFF_RELAY:
    {
        temp_flag = g_cut_off_relay;

        break;
    }
    default:
        break;
    }

    return temp_flag;
}

// 触发打印故障
void fault_change_print_deal(void)
{
    static uint32_t last_fault[FAULT_GROUP_NUM] = {0};
    uint8_t group_num = 0;
    uint8_t group_max_num = FAULT_GROUP_NUM;
    for (group_num = 0; group_num < group_max_num; group_num++)
    {
        if (last_fault[group_num] != g_fault_state[group_num])
        {
            break;
        }
    }
    if (group_num == group_max_num)
    {
        return;
    }
    inner_can_send_msg_ready(BMS_FAULT_INFO2);
    inner_can_send_msg_ready(BMS_FAULT_INFO1);
    inner_can_send_msg_ready(BMS_ALARM_TIPS_INFO3);
    fill_fault_msg(&g_fault_info);  //故障位有变化则填充一次故障信息
    
//    uint8_t last_fault_id_flag = 0;
//    uint8_t cur_fault_id_flag = 0;
//    log_e("fault change:\n");
//    for (uint8_t fault_id = 0; fault_id < FAULT_MAX; fault_id++)
//    {
//        last_fault_id_flag = ((last_fault >> fault_id) & ((uint64_t)1));
//        cur_fault_id_flag = ((g_fault_state >> fault_id) & ((uint64_t)1));
//        if (last_fault_id_flag != cur_fault_id_flag)
//        {
//            log_e("fault 0x%x is %s\n", fault_id, (cur_fault_id_flag) ? "START" : "STOP"); 
//        }
//    }
    memcpy(last_fault, g_fault_state, sizeof(g_fault_state));
}

// 判断故障管理函数
void alarm_manage_deal(const fault_para_tab_t *fault_para_tab, uint16_t max_len)
{
    if (NULL == fault_para_tab || 0 == max_len || max_len > FAULT_MAX)
    {
        return;
    }
    for (uint16_t arr_index = 0; arr_index < max_len; arr_index++)
    {
        // 故障没产生
        if (!fault_state_get(fault_para_tab[arr_index].fault_type))
        {
            // 判断是否满足故障触发条件
            if (fault_para_tab[arr_index].p_alarm_cb(fault_para_tab[arr_index].fault_type, ALARM_APPEAR))
            {
                g_alarm_cnt[(uint16_t)fault_para_tab[arr_index].fault_type] += 1;
            }
            else
            {
                g_alarm_cnt[(uint16_t)fault_para_tab[arr_index].fault_type] = 0;
            }
            if (g_alarm_cnt[(uint16_t)fault_para_tab[arr_index].fault_type] > fault_para_tab[arr_index].appear_cnt)
            {
                fault_state_set(fault_para_tab[arr_index].fault_type, FAULT_START);
                g_alarm_cnt[(uint16_t)fault_para_tab[arr_index].fault_type] = 0;
                if (NULL != fault_para_tab[arr_index].p_alarm_print_cb)
                {
                    fault_para_tab[arr_index].p_alarm_print_cb(fault_para_tab[arr_index].fault_type, ALARM_APPEAR);
                }
            }
        }
        else // 故障产生
        {
            // 判断是否满足恢复条件
            if (fault_para_tab[arr_index].p_alarm_cb(fault_para_tab[arr_index].fault_type, ALARM_RECOVER))
            {
                g_alarm_cnt[(uint16_t)fault_para_tab[arr_index].fault_type] += 1;
            }
            else
            {
                g_alarm_cnt[(uint16_t)fault_para_tab[arr_index].fault_type] = 0;
            }
            if (g_alarm_cnt[(uint16_t)fault_para_tab[arr_index].fault_type] > fault_para_tab[arr_index].cancel_cnt)
            {
                fault_state_set(fault_para_tab[arr_index].fault_type, FAULT_STOP);
                g_alarm_cnt[(uint16_t)fault_para_tab[arr_index].fault_type] = 0;
                if (NULL != fault_para_tab[arr_index].p_alarm_print_cb)
                {
                    fault_para_tab[arr_index].p_alarm_print_cb(fault_para_tab[arr_index].fault_type, ALARM_RECOVER);
                }
            }
        }
    }
    fault_change_print_deal();
}

// 运行自检告警
static void fault_self_check(void)
{
    alarm_manage_deal(g_fault_para_tab, ITEM_NUM(g_fault_para_tab));
}

/**
 * @brief		故障诊断任务 周期100ms
 * @param		void
 * @param		void
 * @return		void
 */
int32_t fault_manage_task(void)
{
    static uint32_t start_tick;
    if (special_mode_get(ATUO_TEST))
    {
        return 0;
    }
	#ifdef SIMULATION_FAULT_TEST
	//研发测试模式下
	if(0xAA == simulate_test_fault_flag)
	{
		fault_stat_data_get(&g_fault_stat_data);
        fault_protect_action(&g_fault_stat_data);
        fault_change_print_deal();
		return 0;
	}
	#endif

    // 故障使能判断,是否开启
    if (true != g_fault_enable)
    {
        return 0;
    }
    if (gp_bmu_data == NULL)
    {
        gp_bmu_data = (bmu_data_t*)bmu_data_p_get();
        if (gp_bmu_data == NULL)
        {
            return -1;
        }
    }
    
    switch (g_fault_diag_step)
    {
        // 上电默认空闲状态
		case DIAG_NONE:
			start_tick = sdk_tick_get();
			g_fault_diag_step = POWER_ON_SELF_TEST;	//500ms等待数据采样稳定由状态管理模块等待
			break;
		// 开机自检，持续检测300ms，有永久性故障则退出，不再诊断，应用逻辑会进入休眠。
		case POWER_ON_SELF_TEST:
			fault_self_check();
			if (true == sdk_is_tick_over(start_tick, TICK_300MS))
			{
				fault_stat_data_get(&g_fault_stat_data);
				fault_protect_action(&g_fault_stat_data);
				g_fault_diag_step = DIAG_ON_RUNNING;
			}
			break;

			// 运行中诊断
		case DIAG_ON_RUNNING:
			fault_self_check();
			fault_stat_data_get(&g_fault_stat_data);
			fault_protect_action(&g_fault_stat_data);
			break;
		default:
			break;
	}

    return 0;
}

static void fill_fault_msg(fault_info_t *p_fault_info)
{
    if (NULL == p_fault_info)
    {
        return;
    }
    memset(&p_fault_info->fault_info1, 0, sizeof(p_fault_info->fault_info1));
    memset(&p_fault_info->fault_info2, 0, sizeof(p_fault_info->fault_info2));
    memset(&p_fault_info->fault_info3, 0, sizeof(p_fault_info->fault_info3));
    // info1 byte0
    p_fault_info->fault_info1.byte0.bits.cell_v_h_pro   = fault_state_get(BAT_CELL_VOLT_HIGH_PROTECT);
    p_fault_info->fault_info1.byte0.bits.cell_v_h_alm   = fault_state_get(BAT_CELL_VOLT_HIGH_ALARM);
    p_fault_info->fault_info1.byte0.bits.cell_v_l_pro   = fault_state_get(BAT_CELL_VOLT_LOW_PROTECT);
    p_fault_info->fault_info1.byte0.bits.cell_v_l_alm   = fault_state_get(BAT_CELL_VOLT_LOW_ALARM);
    p_fault_info->fault_info1.byte0.bits.total_v_h_pro  = fault_state_get(BAT_TOTAL_VOLT_HIGH_PROTECT);
    p_fault_info->fault_info1.byte0.bits.total_v_h_alm  = fault_state_get(BAT_TOTAL_VOLT_HIGH_ALARM);
    p_fault_info->fault_info1.byte0.bits.total_v_l_pro  = fault_state_get(BAT_TOTAL_VOLT_LOW_PROTECT);
    p_fault_info->fault_info1.byte0.bits.total_v_l_alm  = fault_state_get(BAT_TOTAL_VOLT_LOW_ALARM);
    // info1 byte1
    p_fault_info->fault_info1.byte1.bits.chg_temp_h_pro = fault_state_get(BAT_CELL_CHG_TEMP_OVER_PROTECT);
    p_fault_info->fault_info1.byte1.bits.chg_temp_h_alm = fault_state_get(BAT_CELL_CHG_TEMP_OVER_ALARM);
    p_fault_info->fault_info1.byte1.bits.chg_temp_l_pro = fault_state_get(BAT_CELL_CHG_TEMP_LOW_PROTECT);
    p_fault_info->fault_info1.byte1.bits.chg_temp_l_alm = fault_state_get(BAT_CELL_CHG_TEMP_LOW_ALARM);
    p_fault_info->fault_info1.byte1.bits.dis_temp_h_pro = fault_state_get(BAT_CELL_DISCHG_TEMP_OVER_PROTECT);
    p_fault_info->fault_info1.byte1.bits.dis_temp_h_alm = fault_state_get(BAT_CELL_DISCHG_TEMP_OVER_ALARM);
    p_fault_info->fault_info1.byte1.bits.dis_temp_l_pro = fault_state_get(BAT_CELL_DISCHG_TEMP_LOW_PROTECT);
    p_fault_info->fault_info1.byte1.bits.dis_temp_l_alm = fault_state_get(BAT_CELL_DISCHG_TEMP_LOW_ALARM);

    // info1 byte2
    p_fault_info->fault_info1.byte2.bits.chg_curr_h_pro = 0;
    p_fault_info->fault_info1.byte2.bits.dsg_curr_h_pro = 0;
    p_fault_info->fault_info1.byte2.bits.en_temp_h_alm  = fault_state_get(BOARD_ENV_TEMP_HIGH_ALARM);
    p_fault_info->fault_info1.byte2.bits.en_temp_l_alm  = fault_state_get(BOARD_ENV_TEMP_LOW_ALARM);

    // info1 byte3
    p_fault_info->fault_info1.byte3.bits.mos_temp_h_alm = 0;
    p_fault_info->fault_info1.byte3.bits.soc_l_alm = 0;
    p_fault_info->fault_info1.byte3.bits.total_v_err = fault_state_get(BAT_TOTAL_VOLT_DIFF_OVER_FAULT);

    // info1 byte4
    p_fault_info->fault_info1.byte4.bits.ntc_invalid = fault_state_get(BOARD_ENV_TEMP_SAM_ABNORMAL_ALARM);
    p_fault_info->fault_info1.byte4.bits.samp_invalid = fault_state_get(BOARD_AFE_ABNORMAL_FAULT);
    
    // info1 byte5
    p_fault_info->fault_info1.byte5.bits.can_com_fail = fault_state_get(BOARD_CAN_COMM_ABNORMAL_ALARM);
    p_fault_info->fault_info1.byte5.bits.canid_conflict = fault_state_get(BOARD_CANID_CONFLICT_ALARM);

    // info1 byte6
    p_fault_info->fault_info1.byte6.bits.aux_power_err = fault_state_get(BOARD_24V_ABNORMAL_FAULT);
    p_fault_info->fault_info1.byte6.bits.serious_cell_v_h = 0;
    p_fault_info->fault_info1.byte6.bits.serious_cell_v_l = 0;
    
    // info1 byte7
    p_fault_info->fault_info1.byte7.bits.cell_temp_diff_err = fault_state_get(BAT_CELL_TEMP_DIFF_OVER_PROTECT);

//    // info2 byte0
//    p_fault_info->fault_info2.byte0.bits.act_bal_invalid = 0;
//    p_fault_info->fault_info2.byte0.bits.act_bal_cur_diff = 0;
//    p_fault_info->fault_info2.byte0.bits.act_bal_pri_dsg_curr_slow_h = 0;
//    p_fault_info->fault_info2.byte0.bits.act_bal_pri_chg_curr_slow_h = 0;
//    p_fault_info->fault_info2.byte0.bits.act_bal_hard_curr_h = 0;
//    p_fault_info->fault_info2.byte0.bits.act_bal_curr_lock = 0;
//    p_fault_info->fault_info2.byte0.bits.act_bal_pri_volt_slow_h = 0;
//    p_fault_info->fault_info2.byte0.bits.act_bal_sec_volt_slow_h = 0;

//    // info2 byte1
//    p_fault_info->fault_info2.byte1.bits.act_bal_sec_volt_slow_l = 0;
//    p_fault_info->fault_info2.byte1.bits.act_bal_pri_volt_fast_h = 0;
//    p_fault_info->fault_info2.byte1.bits.act_bal_sec_volt_fast_h = 0;
//    p_fault_info->fault_info2.byte1.bits.act_bal_pri_dsg_curr_fast_h = 0;
//    p_fault_info->fault_info2.byte1.bits.act_bal_pri_chg_curr_fast_h = 0;
//    p_fault_info->fault_info2.byte1.bits.act_bal_hard_volt_h = 0;
//    p_fault_info->fault_info2.byte1.bits.act_bal_power_h = 0;
//    p_fault_info->fault_info2.byte1.bits.act_curr_ring_badness_err = 0;

    // info2 byte2
    p_fault_info->fault_info2.byte2.bits.pass_bal_temp_h = fault_state_get(BOARD_BAL_TEMP_OVER_ALARM);
    p_fault_info->fault_info2.byte2.bits.cell_v_serious_diff_err = fault_state_get(BAT_CELL_VOLT_DIFF_OVER_PROTECT);
    p_fault_info->fault_info2.byte2.bits.cell_temp_h_err = 0;
    p_fault_info->fault_info2.byte2.bits.curr_lock_h = 0;
    p_fault_info->fault_info2.byte2.bits.cell_v_lock_h = fault_state_get(BAT_VOLT_HIGH_DISABLE);;
    p_fault_info->fault_info2.byte2.bits.cell_v_lock_l = fault_state_get(BAT_VOLT_LOW_DISABLE);;

    // info2 byte3
    p_fault_info->fault_info2.byte3.bits.cell_temp_lock_hl = fault_state_get(BAT_CELL_TEMP_OVER_OR_LOW_DISABLE);
    p_fault_info->fault_info2.byte3.bits.cell_temp_rise_err = fault_state_get(BAT_CELL_TEMP_RISE_OVER_FAULT);
    p_fault_info->fault_info2.byte3.bits.dsg_curr_h_pro2 = 0;
    p_fault_info->fault_info2.byte3.bits.dsg_temp_tip_h = fault_state_get(BAT_CELL_DISCHG_TEMP_OVER_TIPS);
    p_fault_info->fault_info2.byte3.bits.dsg_temp_tip_l = fault_state_get(BAT_CELL_DISCHG_TEMP_LOW_TIPS);
    p_fault_info->fault_info2.byte3.bits.chg_temp_tip_h = fault_state_get(BAT_CELL_CHG_TEMP_OVER_TIPS);
    p_fault_info->fault_info2.byte3.bits.chg_temp_tip_l = fault_state_get(BAT_CELL_CHG_TEMP_LOW_TIPS);

    // info2 byte4
    p_fault_info->fault_info2.byte4.bits.flash_err = fault_state_get(BOARD_FLASH_INVALID_FAULT);
    p_fault_info->fault_info2.byte4.bits.power_temp_lock_h = 0;
    p_fault_info->fault_info2.byte4.bits.mos_temp_lock_h = 0;
    p_fault_info->fault_info2.byte4.bits.cell_v_lock_h_err2 = fault_state_get(BAT_CELL_VOLT_HIGH_SERIOUS_LOCK);
    p_fault_info->fault_info2.byte4.bits.cell_v_line_err = fault_state_get(BOARD_CELL_VOLT_WIRE_ABNORMAL_FAULT);
    p_fault_info->fault_info2.byte4.bits.cell_temp_line_err = fault_state_get(BOARD_CELL_TEMP_SAM_FAULT);
    p_fault_info->fault_info2.byte4.bits.pass_bal_temp_line_err = fault_state_get(BOARD_BAL_TEMP_SAM_ABNORMAL_ALARM);
    p_fault_info->fault_info2.byte4.bits.power_temp_line_err = fault_state_get(BOARD_POWER_TERMINAL_TEMP_SAM_FAULT);
    // info2 byte5
    p_fault_info->fault_info2.byte5.bits.power_temp_pro_h = fault_state_get(BOARD_POWER_TERMINAL_TEMP_OVER_PROTECT);

    // info3 byte0
    p_fault_info->fault_info3.byte0.bits.board_temp_tip = 0;
    p_fault_info->fault_info3.byte0.bits.cell_over_volt_tip = fault_state_get(BAT_CELL_VOLT_HIGH_TIPS);
    p_fault_info->fault_info3.byte0.bits.cell_under_volt_tip = fault_state_get(BAT_CELL_VOLT_LOW_TIPS);
    p_fault_info->fault_info3.byte0.bits.cell_volt_diff_over_tip = fault_state_get(BAT_CELL_VOLT_DIFF_OVER_TIPS);
    p_fault_info->fault_info3.byte0.bits.cell_temp_diff_over_tip = fault_state_get(BAT_CELL_TEMP_DIFF_OVER_TIPS);
    p_fault_info->fault_info3.byte0.bits.bat_over_volt_tip = fault_state_get(BAT_TOTAL_VOLT_HIGH_TIPS);
    p_fault_info->fault_info3.byte0.bits.bat_under_volt_tip = fault_state_get(BAT_TOTAL_VOLT_LOW_TIPS);

    // info3 byte1
    p_fault_info->fault_info3.byte1.bits.afe_chain_break_tip = fault_state_get(BOARD_AFE_CHAIN_BREAK_FAULT);
    p_fault_info->fault_info3.byte1.bits.electrolyte_sen_tip = fault_state_get(BOARD_ELECTROLYTE_SEN_ABNORMAL_ALARM);    
    p_fault_info->fault_info3.byte1.bits.cell_temp_line_tip = fault_state_get(BOARD_CELL_TEMP_SAM_TIP);      
    // info3 byte2
    p_fault_info->fault_info3.byte2.bits.cell_volt_diff_over_alm = fault_state_get(BAT_CELL_VOLT_DIFF_OVER_ALARM);
    p_fault_info->fault_info3.byte2.bits.cell_temp_diff_over_alm = fault_state_get(BAT_CELL_TEMP_DIFF_OVER_ALARM);

    // info3 byte4
    p_fault_info->fault_info3.byte4.bits.cell_limit_err = fault_state_get(BAT_CELL_LIMIT_FAULT);
}

const fault_info_t *get_fault_info(void)
{
    return &g_fault_info;
}

/**
* @brief        bmu故障格式
* @param        [in] 无
* @return        [out]无
* @retval         无
*/
void bmu_inner_fault_change(fault_info_t *inner_fault, bmu_fault_info_t *bmu_fault)
{
    if (NULL == inner_fault || NULL == bmu_fault)
    {
        return;
    }
    // protect_doublebyte1
    bmu_fault->protect_doublebyte1.bit.cell_volt_high_prot   = inner_fault->fault_info1.byte0.bits.cell_v_h_pro;
    bmu_fault->protect_doublebyte1.bit.cell_volt_low_prot    = inner_fault->fault_info1.byte0.bits.cell_v_l_pro;
    bmu_fault->protect_doublebyte1.bit.total_volt_high_prot  = inner_fault->fault_info1.byte0.bits.total_v_h_pro;
    bmu_fault->protect_doublebyte1.bit.total_volt_low_prot   = inner_fault->fault_info1.byte0.bits.total_v_l_pro;
    bmu_fault->protect_doublebyte1.bit.chg_cur_over_prot     = inner_fault->fault_info1.byte2.bits.chg_curr_h_pro;
    bmu_fault->protect_doublebyte1.bit.dischg_cur_over_prot  = inner_fault->fault_info1.byte2.bits.dsg_curr_h_pro | inner_fault->fault_info2.byte3.bits.dsg_curr_h_pro2;
    bmu_fault->protect_doublebyte1.bit.cell_temp_high_prot    = inner_fault->fault_info1.byte1.bits.chg_temp_h_pro | inner_fault->fault_info1.byte1.bits.dis_temp_h_pro;
    bmu_fault->protect_doublebyte1.bit.cell_temp_low_prot     = inner_fault->fault_info1.byte1.bits.chg_temp_l_pro | inner_fault->fault_info1.byte1.bits.dis_temp_l_pro;

    // protect_doublebyte2
    bmu_fault->protect_doublebyte2.bit.can_com_err           = inner_fault->fault_info1.byte5.bits.can_com_fail;
    bmu_fault->protect_doublebyte2.bit.canid_conflict        = inner_fault->fault_info1.byte5.bits.canid_conflict;

    bmu_fault->protect_doublebyte2.bit.power_temp_high_prot  = inner_fault->fault_info2.byte5.bits.power_temp_pro_h;
    
    // alarm_doublebyte1
    bmu_fault->alarm_doublebyte1.bit.cell_volt_high_alarm   = inner_fault->fault_info1.byte0.bits.cell_v_h_alm;
    bmu_fault->alarm_doublebyte1.bit.cell_volt_low_alarm    = inner_fault->fault_info1.byte0.bits.cell_v_l_alm;
    bmu_fault->alarm_doublebyte1.bit.total_volt_high_alarm  = inner_fault->fault_info1.byte0.bits.total_v_h_alm;
    bmu_fault->alarm_doublebyte1.bit.total_volt_low_alarm   = inner_fault->fault_info1.byte0.bits.total_v_l_alm;
    bmu_fault->alarm_doublebyte1.bit.cell_temp_high_alarm   = inner_fault->fault_info1.byte1.bits.chg_temp_h_alm | inner_fault->fault_info1.byte1.bits.dis_temp_h_alm;
    bmu_fault->alarm_doublebyte1.bit.cell_temp_low_alarm    = inner_fault->fault_info1.byte1.bits.chg_temp_l_alm | inner_fault->fault_info1.byte1.bits.dis_temp_l_alm;
    bmu_fault->alarm_doublebyte1.bit.en_temp_h_alm          = inner_fault->fault_info1.byte2.bits.en_temp_h_alm;
    bmu_fault->alarm_doublebyte1.bit.en_temp_l_alm          = inner_fault->fault_info1.byte2.bits.en_temp_l_alm;
    bmu_fault->alarm_doublebyte1.bit.soc_low_alarm          = inner_fault->fault_info1.byte3.bits.soc_l_alm;
    bmu_fault->alarm_doublebyte1.bit.cell_volt_diff_over_alarm = inner_fault->fault_info3.byte2.bits.cell_volt_diff_over_alm;
    bmu_fault->alarm_doublebyte1.bit.cell_temp_diff_over_alarm = inner_fault->fault_info3.byte2.bits.cell_temp_diff_over_alm;

    // alarm_doublebyte2
    bmu_fault->alarm_doublebyte2.bit.pass_bal_invalid       = inner_fault->fault_info2.byte2.bits.pass_bal_temp_h | inner_fault->fault_info2.byte4.bits.pass_bal_temp_line_err;
    bmu_fault->alarm_doublebyte2.bit.act_bal_dev_alarm     = inner_fault->fault_info2.byte0.bits.act_bal_invalid | 
                                                              inner_fault->fault_info2.byte0.bits.act_bal_cur_diff |
                                                              inner_fault->fault_info2.byte1.bits.act_curr_ring_badness_err;
    bmu_fault->alarm_doublebyte2.bit.act_bal_alarm          = inner_fault->fault_info2.byte0.bits.act_bal_pri_dsg_curr_slow_h|
                                                              inner_fault->fault_info2.byte0.bits.act_bal_pri_chg_curr_slow_h|
                                                              inner_fault->fault_info2.byte0.bits.act_bal_hard_curr_h        |
                                                              inner_fault->fault_info2.byte0.bits.act_bal_curr_lock          |
                                                              inner_fault->fault_info2.byte0.bits.act_bal_pri_volt_slow_h    |
                                                              inner_fault->fault_info2.byte0.bits.act_bal_sec_volt_slow_h    |
                                                              inner_fault->fault_info2.byte1.bits.act_bal_sec_volt_slow_l    |
                                                              inner_fault->fault_info2.byte1.bits.act_bal_pri_volt_fast_h    |
                                                              inner_fault->fault_info2.byte1.bits.act_bal_sec_volt_fast_h    |
                                                              inner_fault->fault_info2.byte1.bits.act_bal_pri_dsg_curr_fast_h|
                                                              inner_fault->fault_info2.byte1.bits.act_bal_pri_chg_curr_fast_h|
                                                              inner_fault->fault_info2.byte1.bits.act_bal_hard_volt_h        |
                                                              inner_fault->fault_info2.byte1.bits.act_bal_power_h            |
                                                              inner_fault->fault_info1.byte3.bits.mos_temp_h_alm             |
                                                              inner_fault->fault_info2.byte4.bits.mos_temp_lock_h;
    bmu_fault->alarm_doublebyte2.bit.sample_wire_alarm      = inner_fault->fault_info2.byte4.bits.pass_bal_temp_line_err;
    bmu_fault->alarm_doublebyte2.bit.cell_temp_high_tips    = inner_fault->fault_info2.byte3.bits.chg_temp_tip_h | inner_fault->fault_info2.byte3.bits.dsg_temp_tip_h;
    bmu_fault->alarm_doublebyte2.bit.cell_temp_low_tips     = inner_fault->fault_info2.byte3.bits.chg_temp_tip_l | inner_fault->fault_info2.byte3.bits.dsg_temp_tip_l;

    
    // fault_doublebyte1
    bmu_fault->fault_doublebyte1.bit.ntc_fault              = inner_fault->fault_info1.byte4.bits.ntc_invalid;
    bmu_fault->fault_doublebyte1.bit.volt_9v_err            = inner_fault->fault_info1.byte6.bits.aux_power_err;
    bmu_fault->fault_doublebyte1.bit.cell_volt_fault        = inner_fault->fault_info1.byte6.bits.serious_cell_v_h |
                                                             inner_fault->fault_info1.byte6.bits.serious_cell_v_l |
                                                             inner_fault->fault_info1.byte3.bits.total_v_err |
                                                             inner_fault->fault_info2.byte2.bits.cell_v_serious_diff_err;
    bmu_fault->fault_doublebyte1.bit.sample_err              = inner_fault->fault_info1.byte4.bits.samp_invalid;
    bmu_fault->fault_doublebyte1.bit.cell_volt_over_lock     = inner_fault->fault_info2.byte4.bits.cell_v_lock_h_err2;
    bmu_fault->fault_doublebyte1.bit.cell_temp_fault         = inner_fault->fault_info2.byte2.bits.cell_temp_h_err |
                                                              inner_fault->fault_info2.byte3.bits.cell_temp_rise_err;
    bmu_fault->fault_doublebyte1.bit.sample_wire_fault       = inner_fault->fault_info2.byte4.bits.cell_temp_line_err |
                                                              inner_fault->fault_info2.byte4.bits.cell_v_line_err    |
                                                              inner_fault->fault_info2.byte4.bits.power_temp_line_err;
    bmu_fault->fault_doublebyte1.bit.cell_disable            = inner_fault->fault_info2.byte2.bits.curr_lock_h |
                                                               inner_fault->fault_info2.byte2.bits.cell_v_lock_h |
                                                               inner_fault->fault_info2.byte2.bits.cell_v_lock_l |
                                                               inner_fault->fault_info2.byte3.bits.cell_temp_lock_hl;

    // fault_doublebyte2
    bmu_fault->fault_doublebyte2.bit.power_temp_over_disable = inner_fault->fault_info2.byte4.bits.power_temp_lock_h;
    bmu_fault->fault_doublebyte2.bit.save_data_err           = inner_fault->fault_info2.byte4.bits.flash_err;
}

/**
* @brief        电芯温度断线位
* @param        无
* @return       [out]uint8_t  具体断线位置    0xff是无效值
* @retval       无
*/
uint8_t get_cell_temp_wire_err_no(void)
{
    return g_cell_temp_wire_err_no;
}

#ifdef SIMULATION_FAULT_TEST
/********************************************调试代码********************************************************/
/**
 * @brief                故障信息打印
 * @return               返回结果空
 * @warning              测试调试使用
 */
void fault_printf(void)
{
    fault_type_e fault_index = BOARD_FAULT_INDEX;
    log_d("faultStep=%d\n", g_fault_diag_step);
    log_d("limChg=%d\n", g_limit_chg);
    log_d("limDsg=%d\n", g_limit_dsg);
    log_d("cutOffRly=%d\n", g_cut_off_relay);
    log_d("faultEn=%d\n", g_fault_enable);
    fault_stat_data_t *p_fault_stat_data = (fault_stat_data_t*)fault_chg_dsg_level_get();
    fault_stat_data_t fault_data;
    fault_data = *p_fault_stat_data;
    log_d("faultNum=%d\n", fault_data.fault_num);
    log_d("maxChgLv=%d\n", fault_data.max_charge_level);
    log_d("maxDsgLv=%d\n", fault_data.max_discharge_level);
    log_d("sysSta=%d\n", bms_state_get_sys_sta());
    log_d("batSta=%d\n", bms_state_get_bat_sta());
    log_d("suppleSta=%d\n", bms_supple_chg_state_get());

    
	for(fault_index = BOARD_FAULT_INDEX;fault_index < FAULT_MAX;fault_index++)
	{
		if(FAULT_START == fault_state_get(fault_index))
		{
			log_d("[err]%#x\n", fault_index);
		}
        os_delay(2);
	}
}


/**
 * @brief                故障强制注入
 * @return               返回结果空
 * @warning              测试调试使用
 */
void shell_set_fault_proc(char *para2, char *para3)
{
	uint16_t fault_id = 0;
	uint8_t operation = 0;

	if (NULL != para2 &&
		NULL != para3)
	{
		fault_id = strtol(para2, &para2,16); 
		operation = atoi(para3);
		if(fault_id >= FAULT_MAX)
		{
			log_d("canNotFind %#x\n", fault_id);
		}
        else
        {
			if(1 == operation)
			{
				fault_state_set( (fault_type_e)fault_id , FAULT_START);
				log_d("faultTestSet %#x OnOk\n", fault_id);
			}
			else if(0 == operation)
			{
				fault_state_set( (fault_type_e)fault_id , FAULT_STOP);
				log_d("faultTestSet %#x OffOk\n", fault_id);
			}
			else
			{
				log_d("faultTestSetParaErr\n");
			}
        }
	}
	else
	{
		log_d("faultTestSetParaErr\n");
	}
}

// 打印故障锁死累计次数
void fault_lock_time_print(void)
{
    log_d("fatLockCnt:\n");
    log_d("chgAlm=%d\n", g_fault_lock_data.chg_alarm_times);
    log_d("chgPro=%d\n", g_fault_lock_data.chg_protect_times);
    log_d("dsgAlm=%d\n", g_fault_lock_data.dsg_alarm_times          );
    log_d("dsgPro1=%d\n", g_fault_lock_data.dsg_protect1_times        );
    log_d("dsgPro2=%d\n", g_fault_lock_data.dsg_protect2_times        );
    log_d("powerTer=%d\n", g_fault_lock_data.power_terminal_protect_times );
    log_d("cellOv=%d\n", g_fault_lock_data.cell_volt_over_protect_times );
    log_d("battOv=%d\n", g_fault_lock_data.total_volt_over_protect_times);
    log_d("cellUv=%d\n", g_fault_lock_data.cell_volt_low_protect_times  );
    log_d("battUv=%d\n", g_fault_lock_data.total_volt_low_protect_times );
    log_d("chgTemOver=%d\n", g_fault_lock_data.chg_temp_over_protect_times  );
    log_d("chgTemLow=%d\n", g_fault_lock_data.chg_temp_low_protect_times   );
    log_d("dsgTemOver=%d\n", g_fault_lock_data.dsg_temp_over_protect_times  );
    log_d("dsgTemLow=%d\n", g_fault_lock_data.dsg_temp_low_protect_times   );
    log_d("balChgOc=%d\n", g_fault_lock_data.bal_chg_over_curr_times   );
    log_d("balDsgOc=%d\n", g_fault_lock_data.bal_dsg_over_curr_times   );
    log_d("balHardOc=%d\n", g_fault_lock_data.bal_hardware_over_curr_times   );
}

/**
 * @brief                故障调试接口
 * @return               返回结果空
 * @warning              测试调试使用
 */
int32_t fault(int argc, char *argv[])
{
	if (argc < 2)
	{
		fault_printf();
	}
    else
    {
		if(!strcmp(argv[1], "on"))		//启动控制
		{
			simulate_test_fault_flag = 0xAA;
			
			log_d("faultTestOnOk\n");
		}
		else if(!strcmp(argv[1], "off"))	//关闭控制
		{
			simulate_test_fault_flag = 0x55;
			
			log_d("faultTestOffOk\n");
		}
		else if(!strcmp(argv[1], "set"))
		{
			if(0xAA == simulate_test_fault_flag)
			{
				shell_set_fault_proc(argv[2], argv[3]);
			}
			else
			{
				log_d("didNotOpenFaultTestMode\n");
			}
		}
        else if(!strcmp(argv[1], "all"))
        {
            if(0xAA == simulate_test_fault_flag)
            {
                //一次性强制注入所有故障
                char hexString[3];
                for(uint8_t i = 0; i < FAULT_MAX; i++)
                {
                    sprintf(hexString, "%X", i);
                    shell_set_fault_proc(hexString, "1");
                    os_delay(2);
                }
            }
        }
        else if (!strcmp(argv[1], "clr"))
        {
            memset(g_fault_state, 0, sizeof(g_fault_state));
            log_d("clearAllFault\n");
        }
        else if (!strcmp(argv[1], "init"))
        {
            fault_manage_init();
            g_fault_enable = true;
            log_d("initFault,FaultEn\n");
        }
        else if (!strcmp(argv[1], "lock"))
        {
            fault_lock_time_print();
        }
        else if (!strcmp(argv[1], "cnt"))
        {
            bms_runing_data_t bms_running_data = {0};
            if (get_bms_runing_data() != NULL)
            {
                bms_running_data = *get_bms_runing_data();
            }
            else
            {
                log_d("FaultCntGetFail\n");
                return 0;
            }

            if (!strcmp(argv[2], "clr"))
            {
                bms_protect_cnt_clear();
                log_d("FaultCntClearSuc\n");
            }
            else if (!strcmp(argv[2], "get"))
            {
                for (uint8_t i = 0; i < ITEM_NUM(bms_running_data.fault_cnt); i++)
                {
                    log_d("fault_cnt[%d] = %d\n", i, bms_running_data.fault_cnt[i]);
                    os_delay(2);
                }
            }
            else
            {
                log_d("ParaErr\n");
            }
        }
		else
		{
			log_d("simTestOperatorErr\n");
		}
    }    

    return 0;
}
MSH_CMD_EXPORT(fault, <on/off/set id 0-1/clr/init/lock>);
#endif
