#include <string.h>
#include "sdk.h"
#include "afe_manage.h"
#include "state_machine.h"
/**
 * @note 宏定义
 */
#define AFE_MANAGE_LOGD(...) log_d(__VA_ARGS__)
#define AFE_MANAGE_LOGE(...) log_e(__VA_ARGS__)
#define AFE_MANAGE_LOGW(...) log_w(__VA_ARGS__)
#define RETRY_NUM 3


/**
 * @note 函数声明
 */
static uint8_t sta_idle_entry(void);
static uint8_t sta_idle_run(void);
static uint8_t sta_wakeup_entry(void);
static uint8_t sta_wakeup_run(void);
static uint8_t sta_init_entry(void);
static uint8_t sta_init_run(void);
static uint8_t sta_normal_entry(void);
static uint8_t sta_normal_run(void);
static uint8_t sta_wire_open_check_entry(void);
static uint8_t sta_wire_open_check_run(void);
static uint8_t sta_chain_break_check_entry(void);
static uint8_t sta_chain_break_check_run(void);
static uint8_t sta_error_entry(void);
static uint8_t sta_error_run(void);
static uint8_t sta_shutdown_entry(void);
static uint8_t sta_shutdown_run(void);

static uint8_t state_change_condition_check(void);
/**
 * @note 全局变量定义
 */



static fsm_action_map_t g_afe_sta_act_map[STATE_AFE_NUM] =
{
	[STATE_AFE_IDIE] 		= {sta_idle_entry, 				sta_idle_run},
	[STATE_AFE_WAKEUP] 		= {sta_wakeup_entry, 			sta_wakeup_run},
	[STATE_AFE_INIT] 		= {sta_init_entry, 				sta_init_run},
	[STATE_AFE_NORMAL] 		= {sta_normal_entry, 			sta_normal_run},
	[STATE_AFE_WIRE_OPEN] 	= {sta_wire_open_check_entry, 	sta_wire_open_check_run},
	[STATE_AFE_CHAIN_BREAK] = {sta_chain_break_check_entry, sta_chain_break_check_run},
	[STATE_AFE_ERR] 		= {sta_error_entry, 			sta_error_run},
	[STATE_AFE_SHUTDOWN] 	= {sta_shutdown_entry, 			sta_shutdown_run},
};

static uint8_t g_afe_sta_evt_map[STATE_AFE_NUM][EVT_AFE_NUM] = 
{                           // STA_CPL_SUS   	WIRE_OPEN_CHECK     CHAIN_BREAK_CHECK          TIMEOUT_OR_ERR        WAKEUP             SHUTDOWN
    [STATE_AFE_IDIE]        = {STA_NULL,          STA_NULL,             STA_NULL,          		STA_NULL,       STATE_AFE_WAKEUP,  STATE_AFE_SHUTDOWN,},
    [STATE_AFE_WAKEUP]  	= {STATE_AFE_INIT,    STA_NULL,       		STA_NULL,      			STATE_AFE_ERR,  STA_NULL,  		   STA_NULL,		  },
    [STATE_AFE_INIT]        = {STATE_AFE_WIRE_OPEN,STA_NULL,         	STA_NULL,               STATE_AFE_ERR,  STATE_AFE_WAKEUP,  STA_NULL,		  },
    [STATE_AFE_NORMAL]	    = {STA_NULL,          STATE_AFE_WIRE_OPEN,	STATE_AFE_CHAIN_BREAK,  STATE_AFE_ERR,  STATE_AFE_WAKEUP,  STATE_AFE_SHUTDOWN,},
    [STATE_AFE_WIRE_OPEN]   = {STATE_AFE_NORMAL,  STA_NULL,         	STA_NULL,               STATE_AFE_ERR,  STATE_AFE_WAKEUP,  STATE_AFE_SHUTDOWN,},
    [STATE_AFE_CHAIN_BREAK] = {STATE_AFE_NORMAL,  STA_NULL,       		STA_NULL,               STATE_AFE_ERR,  STATE_AFE_WAKEUP,  STATE_AFE_SHUTDOWN,},
    [STATE_AFE_ERR]         = {STATE_AFE_IDIE,    STA_NULL,       		STA_NULL,      			STA_NULL,       STATE_AFE_WAKEUP,  STATE_AFE_SHUTDOWN,},
    [STATE_AFE_SHUTDOWN]    = {STATE_AFE_IDIE,    STA_NULL,         	STA_NULL,          		STA_NULL,       STA_NULL,          STA_NULL,		  },
};
/**
 * @note 全局变量初始化
 */
afe_state_e g_afe_state = AFE_IDIE_STATE;
afe_abnormal_e g_afe_err_flag = AFE_ERR_NONE;
static state_machine_t g_afe_fsm = {0};
static const char *afe_fsm_name = "afe";
afe_fsm_para_t g_afe_fsm_para = {0};
/**
 * @note AFE对外数据接口
 */
afe_state_e afe_state_get(void)
{
    return g_afe_state;
}

void afe_state_set(afe_state_e state)
{
	switch (state)
	{
	case AFE_WAKEUP_BRI_STATE:
		if (AFE_WAKEUP_BRI_STATE != g_afe_state)
		{
			g_afe_fsm_para.afe_wakeup_flag = true;
		}

		break;
	case AFE_SHUTDOWN_STATE:
		if (AFE_SHUTDOWN_STATE != g_afe_state)
		{
			g_afe_fsm_para.afe_shutdown_flag = true;
		}

		break;
	default:
		break;
	}
}

afe_abnormal_e afe_abnormal_state_get(void)
{
	return g_afe_err_flag;
}

void afe_init(void)
{
	g_afe_state = AFE_IDIE_STATE;
	g_afe_err_flag = AFE_ERR_NONE;
	g_afe_fsm_para.afe_wakeup_flag = true;
	g_afe_fsm_para.addr_retry_counter = 0;
	g_afe_fsm_para.wakeup_retry_counter = 0;
	g_afe_fsm_para.cfg_retry_counter = 0;
	g_afe_fsm_para.read_retry_counter = 0;
	g_afe_fsm_para.wire_open_check_fail_counter = 0;  
	g_afe_fsm_para.chain_break_mulit_retry_counter = 0;	
	state_machine_init(&g_afe_fsm, afe_fsm_name, g_afe_sta_act_map, (uint8_t *)g_afe_sta_evt_map, EVT_AFE_NUM, STATE_AFE_NUM, STATE_AFE_IDIE);
}

void afe_management(void)
{
	uint8_t event;
	event = state_change_condition_check();
	fsm_state_trans(&g_afe_fsm, event);
	event = state_machine_proc(&g_afe_fsm);
	fsm_state_trans(&g_afe_fsm, event);
}
/**
 * @note 内部函数定义
 */
static uint8_t state_change_condition_check(void)
{
	uint8_t event = EVT_NULL;

	if (true == g_afe_fsm_para.afe_wakeup_flag)
	{
		g_afe_fsm_para.afe_wakeup_flag = false;
		event = EVT_AFE_WAKEUP;
		AFE_MANAGE_LOGE("[AFE_MGE]state_change_condition_check wakeup...\n");
	}

	if (true == g_afe_fsm_para.afe_shutdown_flag)
	{
		g_afe_fsm_para.afe_shutdown_flag = false;
		event = EVT_AFE_SHUTDOWN;
		AFE_MANAGE_LOGE("[AFE_MGE]state_change_condition_check shutdown...\n");
	}

	return event;
}

static uint8_t sta_idle_entry(void)
{
	uint8_t event = EVT_NULL;

	g_afe_state = AFE_IDIE_STATE;
	g_afe_fsm_para.idle_print_first_flag = true;
	AFE_MANAGE_LOGD("[AFE_MGE]sta_idle_entry...\n");

	return event;
}

static uint8_t sta_idle_run(void)
{
	uint8_t event = EVT_NULL;

	if (true == g_afe_fsm_para.idle_print_first_flag)
	{
		g_afe_fsm_para.idle_print_first_flag = false;
		AFE_MANAGE_LOGE("[AFE_MGE]sta_idle_run...\n");
	}

	return event;
}

static uint8_t sta_wakeup_entry(void)
{
	int32_t ret = 0;
	uint8_t event = EVT_NULL;

	g_afe_state = AFE_WAKEUP_BRI_STATE;
	g_afe_err_flag = AFE_ERR_NONE;		//重新唤醒时先默认无故障

	bq79600_wakeup();

	ret = bq79600_communication_init();
	if (0 > ret)
	{
		g_afe_err_flag = AFE_ERR_COMM_INIT;
		event = EVT_AFE_TIMEOUT_OR_ERR;
	}
	os_delay(TICK_10MS);
	AFE_MANAGE_LOGD("[AFE_MGE]sta_wakeup_entry...\n");

	return event;
}

static uint8_t sta_wakeup_run(void)
{
	int32_t ret = 0;
	uint8_t event = EVT_NULL;

	g_afe_state = AFE_WAKEUP_AFE_STATE;

	ret = bq79616_wakeup();
	if (0 > ret)
	{
		if (++g_afe_fsm_para.wakeup_retry_counter >= RETRY_NUM)
		{
			g_afe_err_flag = AFE_ERR_WAKEUP;
			event = EVT_AFE_TIMEOUT_OR_ERR;
			AFE_MANAGE_LOGW("[AFE_MGE]wakeup error...\n");
		}
	}
	else
	{
		g_afe_fsm_para.wakeup_retry_counter = 0;
		event = EVT_AFE_STA_CPL_SUS;
		os_delay(os_tick_from_millisecond(12 * TOTAL_BOARDS));
		AFE_MANAGE_LOGE("[AFE_MGE]wakeup success...\n");
	}

	return event;
}

static uint8_t sta_init_entry(void)
{
	int32_t ret = 0;
	uint8_t event = EVT_NULL;

	g_afe_state = AFE_AUTO_ADRESS_STATE;

	ret = bq79600_auto_address();
	if (0 > ret)
	{
		event = EVT_AFE_WAKEUP;
		if (++g_afe_fsm_para.addr_retry_counter >= RETRY_NUM)
		{
			g_afe_err_flag = AFE_ERR_AUTO_ADDR;
			event = EVT_AFE_TIMEOUT_OR_ERR;
			AFE_MANAGE_LOGW("[AFE_MGE]auto_address error...\n");
		}
	}
	else if (CHAIN_BREAK_MULTIPLE == ret)
	{
		event = EVT_AFE_WAKEUP;
		if (++g_afe_fsm_para.addr_retry_counter >= RETRY_NUM)
		{
			g_afe_err_flag = AFE_ERR_CHAIN_BREAK_MULTIPLE;
			event = EVT_AFE_TIMEOUT_OR_ERR;
			AFE_MANAGE_LOGW("[AFE_MGE]auto_address error: chain break multiple...\n");
		}
	}
	else if (CHAIN_BREAK == ret)
	{
		g_afe_err_flag = AFE_ERR_CHAIN_BREAK;
		g_afe_fsm_para.addr_retry_counter = 0;
		AFE_MANAGE_LOGW("[AFE_MGE]auto_address success: chain break...\n");
	}
	else
	{
		g_afe_fsm_para.addr_retry_counter = 0;
		AFE_MANAGE_LOGE("[AFE_MGE]auto_address success...\n");
	}

	return event;
}

static uint8_t sta_init_run(void)
{
	int32_t ret = 0;
	uint8_t event = EVT_NULL;

	g_afe_state = AFE_INIT_STATE;

	ret = bq79600_config_init();
	if (0 > ret)
	{
		event = EVT_AFE_WAKEUP;
		if (++g_afe_fsm_para.cfg_retry_counter >= RETRY_NUM)
		{
			g_afe_err_flag = AFE_ERR_CONFIG;
			event = EVT_AFE_TIMEOUT_OR_ERR;
			AFE_MANAGE_LOGW("[AFE_MGE]config_init error...\n");
		}
	}
	else
	{
		g_afe_fsm_para.cfg_retry_counter = 0;
		event = EVT_AFE_STA_CPL_SUS;
		AFE_MANAGE_LOGE("[AFE_MGE]config_init success...\n");
	}
	return event;
}

static uint8_t sta_normal_entry(void)
{
	uint8_t event = EVT_NULL;

	g_afe_state = AFE_RUN_STATE;

	os_delay(TICK_100MS);
	AFE_MANAGE_LOGE("[AFE_MGE]sta_normal_entry...\n");

	return event;
}

static uint8_t sta_normal_run(void)
{
	int32_t ret = 0;
	uint8_t event = EVT_NULL;

#if ((1 == REVERSE_ADDR_ENABLE) && (1 == FORWARD_ADDR_ENABLE))
	bq79600_toggle_comm_dir();
#endif

	ret = bq79600_sample_100ms();
	if (0 > ret)
	{
		++g_afe_fsm_para.read_retry_counter;
	}
	else if (0 == ret)
	{
		// if (g_afe_fsm_para.read_retry_counter > 0)
		// {
			g_afe_fsm_para.read_retry_counter = 0;
		// }
	}
	else if (1 == ret)
	{
		event = EVT_AFE_WIRE_OPEN_CHECK;
	}

	// if (g_afe_fsm_para.read_retry_counter == (RETRY_NUM / 3))
	// {
	// 	event = EVT_AFE_CHAIN_BREAK_CHECK;
	// }

	// if (g_afe_fsm_para.read_retry_counter >= RETRY_NUM)
	// {
	// 	g_afe_err_flag = AFE_ERR_COMMUNICATION;
	// 	event = EVT_AFE_TIMEOUT_OR_ERR;
	// }


	if (g_afe_fsm_para.read_retry_counter >= RETRY_NUM)	
	{
		g_afe_err_flag = AFE_ERR_COMMUNICATION;
		event = EVT_AFE_TIMEOUT_OR_ERR;		
	}
	else if (g_afe_fsm_para.read_retry_counter > 0)	
	{
        event = EVT_AFE_CHAIN_BREAK_CHECK;			
	}

	return event;
}

static uint8_t sta_wire_open_check_entry(void)
{
	uint8_t event = EVT_NULL;

	g_afe_state = AFE_WIRE_OPEN_CHECK_STATE;
	AFE_MANAGE_LOGD("[AFE_MGE]sta_wire_open_check_entry...\n");

	return event;
}

static uint8_t sta_wire_open_check_run(void)
{
	int32_t ret = 0;
	uint8_t event = EVT_NULL;
    static int8_t last_wire_open_flag = AFE_CELL_RESULT_END;    //
    
	ret = bq79600_afe_cell_volt_wire_open_check();
	if (AFE_CELL_RESULT_END == ret)
	{
		event = EVT_AFE_STA_CPL_SUS;
	}
	else if(AFE_CELL_RESULT_WIRE_OPEN == ret)
	{
		g_afe_err_flag = AFE_ERR_WIRE_OPEN;
		event = EVT_AFE_STA_CPL_SUS;
	}
	else if (AFE_CELL_RESULT_ERR == ret)
	{
        if (++g_afe_fsm_para.wire_open_check_fail_counter >= RETRY_NUM)
        {
            g_afe_err_flag = AFE_ERR_COMMUNICATION;     
            event = EVT_AFE_TIMEOUT_OR_ERR;            
        }
        else
        {
            event = EVT_AFE_WAKEUP;
        }

	}
    
    if ((last_wire_open_flag == AFE_CELL_RESULT_CHECKING) &&    //如果从检测中跳到结束或者断线，说明检测成功了。
         ((ret == AFE_CELL_RESULT_END) || (ret == AFE_CELL_RESULT_WIRE_OPEN)))
    {
        g_afe_fsm_para.wire_open_check_fail_counter = 0;
    }
    
    last_wire_open_flag = ret;

	return event;
}

static uint8_t sta_chain_break_check_entry(void)
{
	uint8_t event = EVT_NULL;

	g_afe_state = AFE_CHAIN_BREAK_CHECK_STATE;
	AFE_MANAGE_LOGE("[AFE_MGE]sta_chain_break_check_entry...\n");

	return event;
}

static uint8_t sta_chain_break_check_run(void)
{
	int32_t ret = 0;
	uint8_t event = EVT_NULL;

	ret = daisy_chain_break_check();
	if (CHAIN_BREAK_MULTIPLE == ret)
	{
		g_afe_err_flag = AFE_ERR_CHAIN_BREAK_MULTIPLE;
		if (++g_afe_fsm_para.chain_break_mulit_retry_counter >= RETRY_NUM)
		{
			event = EVT_AFE_TIMEOUT_OR_ERR;
		}
		else
		{
			event = EVT_AFE_WAKEUP;
		}

	}
	else if (CHAIN_BREAK == ret)
	{
		g_afe_err_flag = AFE_ERR_CHAIN_BREAK;
        g_afe_fsm_para.chain_break_mulit_retry_counter = 0;
		event = EVT_AFE_WAKEUP;
	}
	else
	{
        g_afe_fsm_para.chain_break_mulit_retry_counter = 0;        
		event = EVT_AFE_STA_CPL_SUS;
	}

	return event;
}

static uint8_t sta_error_entry(void)
{
	uint8_t event = EVT_NULL;

	g_afe_state = AFE_ERR_STATE;
//    g_afe_fsm_para.err_print_first_flag = true;
    AFE_MANAGE_LOGE("[AFE_MGE]sta_error_entry...\n");     
	return event;
}

static uint8_t sta_error_run(void)
{
	uint8_t event = EVT_NULL;

    // if (true == g_afe_fsm_para.err_print_first_flag)
    // {
    //     g_afe_fsm_para.err_print_first_flag = false;
   
    // }


	return event;
}

static uint8_t sta_shutdown_entry(void)
{
	uint8_t event = EVT_NULL;

	g_afe_state = AFE_SHUTDOWN_STATE;
	AFE_MANAGE_LOGE("[AFE_MGE]sta_shutdown_entry...\n");

	return event;
}

static uint8_t sta_shutdown_run(void)
{
	uint8_t event = EVT_NULL;

	g_afe_fsm_para.read_retry_counter = 0;
	bq79600_shutdown();
	bq79600_data_init();
	event = EVT_AFE_STA_CPL_SUS;
	AFE_MANAGE_LOGD("[AFE_MGE]sta_shutdown_run...\n");

	return event;
}

