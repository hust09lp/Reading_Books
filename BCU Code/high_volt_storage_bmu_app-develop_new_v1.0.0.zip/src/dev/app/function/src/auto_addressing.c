/**********************************************************************************
 * 创建时间: 2022-10-13 14:41:55
 * 邮箱: yuanzhihua@sofarsolar.com
 * 版本: V1.0
 * 描述:
 * 修改:
 *
 **********************************************************************************/

#include "auto_addressing.h"
#include "sdk.h"
#include "sdk_dido.h"
#include "app_config.h"
#include "app_public.h"
#include "ate.h"
#include "data_store.h"
#include "public_flag.h"
#include "upgrade.h"
#include "sofar_can_data.h"
#include "sofar_can_manage.h"
#include "state_machine.h"


#if AUTO_ADDR_SHELL_DEBUG
static uint8_t g_auto_addressing_debug_flag = false;
#endif

#define IN_ADDR_DEBUG_ENABLE 0									///< 0禁止打印信息 1使能打印信息
#define THIS_LOGA(...) log_d(__VA_ARGS__)
#define THIS_LOGE(...) log_d(__VA_ARGS__)
#define THIS_LOGW(...) log_d(__VA_ARGS__)
#define THIS_LOGI(...) if (IN_ADDR_DEBUG_ENABLE) log_d(__VA_ARGS__)
#define THIS_LOGD(...) if (IN_ADDR_DEBUG_ENABLE) log_d(__VA_ARGS__)

// 编址任务执行周期
#define ADDRESS_DEAL_CYCLE_BASE_TIME_MS   (10)      // 10ms定时任务
#define ADDRESS_DEAL_30MS_CNT            (30 / ADDRESS_DEAL_CYCLE_BASE_TIME_MS)  // 30ms对应次数
/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
//                                          变量声明
/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
typedef enum
{
    NON_CAN_ADDR_SET_CMD = 0,        // 0x00:无操作
    CAN_ADDR_SET_IO_HIGH_CMD = 0x01, // 0x01:拉高ID_OUT
    CAN_ADDR_SET_IO_LOW_CMD = 0x02,  // 0x02:下拉ID_OUT
    CAN_SET_ADDR_CMD  = 0x03,        // 0x03:主机设置地址/ 从机编址完成
    CAN_ADDR_CONFLICT_CMD = 0x7C,    // 0x7C从机地址冲突
    CAN_ADDR_STORE_CMD = 0x7D,       // 0x7D存储自身地址
    CAN_SET_START_ADDR_CMD = 0x7E,   // 0x7E： 主机设置重新编址/从机请求编址
} can_addr_set_cmd_u;

enum // 通讯命令字定义
{
    CMD_START_ADDRESSING = 1, // 开始自动编址
    CMD_SET_OUTPUT,           // 设置从机输出口电平
    CMD_SET_SLAVE_ADDR,       // 设置从机地址
    CMD_CHECK_SLAVE_ADDR,     // 验证从机地址
    CMD_REQUEST,              // 请求编址
    CMD_HEARTBEAT,            // 地址心跳包
    CMD_CONFLICT,        // 地址冲突命令
    CMD_DI_STATUS_GET,      // 发送di状态
    CMD_ADDR_STORE,      // 存储地址
    CMD_OFF,                  // 关机
};

// 通讯信息数据结构
typedef struct
{
    uint8_t dst_type;
    uint8_t dst_addr; // 目标地址
    uint8_t src_type;
    uint8_t src_addr; // 源地址
    uint16_t cmd;      // 命令
    uint16_t sleep_cmd; // 休眠请求
    uint16_t data;     // 数据
} msg_t;

/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
//                                          函数声明
/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
static void send_cmd_request_addressing(void);

void send_heartbeat(void);
static void check_pack_comm_status(void);
static int32_t send_addr_msg_reply(msg_t *msg);
static int32_t can_convert_to_addr_msg(uint32_t can_id, uint8_t *p_data, msg_t* addr_msg, uint8_t len);
static void inner_addr_rcv_msg(msg_t *p_rcv_msg);

static uint8_t sta_addr_init_run(void);
static uint8_t sta_addr_slave_entry(void);
static uint8_t sta_addr_slave_run(void);

/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
//                                          变量定义
/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
static fsm_action_map_t g_addr_act_map[ADDR_STA_NUM] = 
{
    [STA_ADDR_INIT]           = {NULL, sta_addr_init_run},
    [STA_ADDR_SLAVE]          = {sta_addr_slave_entry, sta_addr_slave_run},
};

static uint8_t g_addr_evt_sta_map[ADDR_STA_NUM][ADDR_EVT_NUM] = 
{                          // EVT_ADDR_PREPARED 
    [STA_ADDR_INIT]        = {STA_ADDR_SLAVE},
    [STA_ADDR_SLAVE]       = {STA_NULL},

};

static state_machine_t g_auto_addr_fsm = {0};
static const char* auto_addr_fsm_name = "addr";
static uint8_t g_addr_out_put_pin = DO_0_NULL;     //两个编址IO，默认都做输入，当某一个引脚检测到高电平，则另一个引脚设置成输出


static slave_addr_para g_slave_addr_para =
{
    .addr_state = ADDRESSING_DISENABLE,
    .dev_addr = BMU_ADDR_DEFAULT,
    .auto_addressing_enable = 0,
    .fault_pack_unlink = 0,
    .unlink_time_cnt = ADDRESSING_DISENABLE,
};
static can_addr_set_cmd_u g_slave_addr_proc_state = NON_CAN_ADDR_SET_CMD;
// static uint8_t g_version[4] = {0};
/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
//                                         硬件接口适配
/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
// 编址电平配置，0:低电平，1:高电平 ,需要同步修改public_flag_init的初始引脚配置
#define ADDRESSING_PIN_STATUS    (1)
// // 设置输出PIN脚为高
// #define OUTPUT_PIN_SET_HIGH() 	sdk_dido_write(DO_1_BAT_PACK_OUT1, 1)
// // 设置输出PIN脚为低
// #define OUTPUT_PIN_SET_LOW() 	sdk_dido_write(DO_1_BAT_PACK_OUT1, 0)
// // 设置地址电平控制
// #define OUTPUT_PIN_SET_ADDRESSING() (sdk_dido_write(DO_1_BAT_PACK_OUT1, ADDRESSING_PIN_STATUS))
// // 默认电平控制
// #define OUTPUT_PIN_SET_DEFAULT()   (sdk_dido_write(DO_1_BAT_PACK_OUT1, !ADDRESSING_PIN_STATUS))

/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
//                                        函数实现
/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */

/**
 * @brief   内网CAN(bmu/bcu)，自动编址初始化状态进入处理
 * @param   无
 * @return  返回执行结果 0Xff,无事件
 * @warning	无
 */
static uint8_t sta_addr_init_run(void)
{
//    g_version[0] = SOFTWARE_VERSION[1];
//    g_version[1] = ((SOFTWARE_VERSION[2] - '0') * 10) + (SOFTWARE_VERSION[3] - '0');
//    g_version[2] = ((SOFTWARE_VERSION[4] - '0') * 10) + (SOFTWARE_VERSION[5] - '0');
//    g_version[3] = ((SOFTWARE_VERSION[6] - '0') * 10) + (SOFTWARE_VERSION[7] - '0');
	//log_e("[ADD]IamSla,%d\n", ADDRESSING_PIN_STATUS); // 打印信息：我是从机
    // 禁用充放电 todo
    sdk_dido_config(IO_1_BAT_PACK_OUT1,SDK_GPIO_INPUT);
    sdk_dido_config(IO_2_BAT_PACK_OUT2,SDK_GPIO_INPUT); 
    g_addr_out_put_pin = DO_0_NULL; 
    //DI、DO共用，上电的时候先设置成DI  
    g_slave_addr_para.dev_addr = get_bms_attr()->addr;
    
    return EVT_ADDR_PREPARED;
}

/**
 * @brief   内网CAN(bmu/bcu)，未使能自动编状态进入处理
 * @param   无
 * @return  返回执行结果 0Xff,无事件
 * @warning	无
 */
static uint8_t sta_addr_slave_entry(void)
{
    log_e("[ADD]IamSla,%d\n", ADDRESSING_PIN_STATUS); // 打印信息：我是从机
    return EVT_NULL;
}

/**
 * @brief   内网CAN(bmu/bcu)，未使能自动编状态运行处理
 * @param   无
 * @return  返回执行结果 0:初始化完成事件
 * @warning	无
 */
static uint8_t sta_addr_slave_run(void)
{
    if (g_slave_addr_para.dev_addr == BMU_ADDR_DEFAULT)
    {
        send_cmd_request_addressing();
        g_slave_addr_para.addr_state = ADDRESSING_ING; // 编址中
        g_slave_addr_para.first_recv_master_heat_flag = 0;
    }
    else
    {
        send_heartbeat();   // 定时发送心跳
        check_pack_comm_status(); // 检测从机通信状态

        if (g_slave_addr_para.fault_pack_unlink) // 主机编址成功后才会发心跳报文，因此可以通过从机与主机的通信状态判断编址状态
        {
            g_slave_addr_para.addr_state = ADDRESSING_ING; // 编址中
        }
        else
        {
            g_slave_addr_para.addr_state = ADDRESSING_FINISH; // 编址完成
        }
    }
    return EVT_NULL;
}

static void inner_auto_addr_can_register(void)
{
//	uint16_t rec_msg_amount = 0;
//    can_frame_id_u frame_id[] = 
//    {
//        // res     prio(优先级)      type(帧类型)  flag（1:连续，0:非）, fun_code,    dst_type dst_addr, src_type, src_addr
//        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_LOW_H, .bit.fun_code= FUNC_HEART_BEAT_CMD,
//         .bit.dst_type= 0, .bit.dst_addr= 0, .bit.src_type= DEV_BCU, .bit.src_addr =0},
//    };
//	can_sofar_rcv_reg_t can_rxmsg_tab[] = // 接收上位机或BCU的数据
//	{
//        {frame_id[0].id_val, 0x0000FFFF, inner_addr_rcv_callback},  // 0x197F0080 BMU上送心跳数据处理,广播所有设备，A0：源设备类型，设备地址1~10
//	};	
//	// 注册接收的数据
//	rec_msg_amount = sizeof(can_rxmsg_tab)/sizeof(can_sofar_rcv_reg_t);
//	inner_can_sofar_register_receive_frame(can_rxmsg_tab, rec_msg_amount);
}


/**
 * @brief  获取编址内部进程状态
 * @input   
 * @retval 
 */
uint8_t slave_addr_proc_state_get(void)
{
    return (uint8_t)g_slave_addr_proc_state;
}

/**
 * @brief 判断接收到应答消息
 * @param 无
 * @param 无
 * @return 无
 */
static void send_cmd_request_addressing(void)
{
    static uint32_t timestamp = 0;
    if (sdk_is_tick_over(timestamp, os_tick_from_millisecond(1000 * 3))) // 每20秒请求一次编址
    {
        timestamp = sdk_tick_get();
        msg_t send_msg = {0};
        send_msg.cmd = CMD_REQUEST;
        send_addr_msg_reply(&send_msg);
        THIS_LOGI("[ADD]slave\n"); // 打印信息：从机请求编址
    }
}

static int32_t can_convert_to_addr_msg(uint32_t can_id, uint8_t *p_data, msg_t* addr_msg, uint8_t len)
{
    if ((p_data == NULL) || (NULL == addr_msg))
    {
        return -1;
    }
    can_frame_id_u can_frame_id = {can_id};
    addr_msg->src_addr = can_frame_id.bit.src_addr;
    addr_msg->dst_addr = can_frame_id.bit.dst_addr;
    addr_msg->src_type = can_frame_id.bit.src_type;
    addr_msg->dst_type = can_frame_id.bit.dst_type;
    if (can_frame_id.bit.fun_code == FUNC_HEART_BEAT_CMD)
    {
        addr_msg->cmd = CMD_HEARTBEAT;
    }
    else if (can_frame_id.bit.fun_code == FUNC_MASTER_CTL_CMD)
    {
        if (len < 3)    // 控制帧有3个数据
        {
            return -1;
        }
        addr_msg->sleep_cmd = p_data[2]; // 休眠请求
        switch (p_data[1])
        {
            case CAN_ADDR_SET_IO_HIGH_CMD:
                addr_msg->cmd = CMD_SET_OUTPUT;
                addr_msg->data = 1; // 设置高电平
                break;
            case CAN_ADDR_SET_IO_LOW_CMD:
                addr_msg->cmd = CMD_SET_OUTPUT;
                addr_msg->data = 0; // 设置低电平
                break;
            case CAN_SET_ADDR_CMD:
                addr_msg->cmd = CMD_SET_SLAVE_ADDR;
                addr_msg->data = p_data[0]; // 设置地址
                break;
            case CAN_SET_START_ADDR_CMD:
                addr_msg->cmd = CMD_START_ADDRESSING;
                addr_msg->data = 1; // 重新编址
                break;
            case CAN_ADDR_STORE_CMD:
                addr_msg->cmd = CMD_ADDR_STORE;
                addr_msg->data = 1; // 存储地址
                break;            
            default:
                THIS_LOGI("[ADD]para err\n"); // 打印信息：从机请求编址
                break;
        }
    }
    else
    {
        return -1;
    }
    return 0;  
}

static void inner_can_heartbeat_proc(msg_t *p_rcv_msg)
{
    if (special_mode_get(ATUO_TEST))
    {
        set_can1_tx_result_result(true);
    }
    
    if ((p_rcv_msg->src_addr == g_slave_addr_para.dev_addr) && (p_rcv_msg->src_type == DEV_BMU)) // 发现地址冲突
    {
//        THIS_LOGE("[ADD]flict%d\n", g_slave_addr_para.dev_addr);
        g_slave_addr_para.address_conflict_flag = 1;
    }
    if (p_rcv_msg->src_type == DEV_BCU)
    {
        // 从机有接到主机的心跳
        if (p_rcv_msg->src_addr == BCU_INNER_CAN_ADDR)
        {
            g_slave_addr_para.unlink_time_cnt = 0;
            g_slave_addr_para.first_recv_master_heat_flag = 1;
        }
    }
}

static void slave_addr_start_proc(msg_t *p_rcv_msg)
{
    if (p_rcv_msg->data == 1)
    {
        THIS_LOGE("[ADD]Start\n");
        g_slave_addr_para.address_conflict_flag = 0;
        g_slave_addr_para.dev_addr = BMU_ADDR_DEFAULT;
        g_slave_addr_para.addr_state = ADDRESSING_ING;
        g_slave_addr_proc_state = CAN_SET_START_ADDR_CMD;
        sdk_dido_config(IO_1_BAT_PACK_OUT1,SDK_GPIO_INPUT);
        sdk_dido_config(IO_2_BAT_PACK_OUT2,SDK_GPIO_INPUT); 
        g_addr_out_put_pin = DO_0_NULL;         
    }
}

/**
 * @brief  
 * @param  mode: true:输出高；false：输出低
 */
static void out_pin_set(uint8_t mode)
{
    sdk_dido_write(g_addr_out_put_pin,mode);
}

static void slave_output_set_proc(msg_t *p_rcv_msg)
{
    if ((p_rcv_msg->dst_addr == g_slave_addr_para.dev_addr) && (p_rcv_msg->dst_type == DEV_BMU))// 判断是否为本机地址
    {
        THIS_LOGE("[ADD]SetPin%d\n",p_rcv_msg->data);
        if (p_rcv_msg->data)
        {
            
            out_pin_set(true);
            g_slave_addr_proc_state = CAN_ADDR_SET_IO_HIGH_CMD;
        }
        else
        {
            out_pin_set(false);
            g_slave_addr_proc_state = CAN_ADDR_SET_IO_LOW_CMD;
        }
    }
}
static void slave_addr_set_proc(msg_t *p_rcv_msg)
{
    uint8_t di_flag = false;
    
    if ((p_rcv_msg->src_addr == BCU_INNER_CAN_ADDR) && (p_rcv_msg->src_type == DEV_BCU))// 判断是否为主机地址
    {
        if(DO_0_NULL == g_addr_out_put_pin) //如果还没确认用哪个脚做OUT_PUT脚则跑这里
        {
            if ((ADDRESSING_PIN_STATUS == di_state_get(DI1_ADDR_PACK_IN))
                || (ADDRESSING_PIN_STATUS == di_state_get(DI2_ADDR_PACK_IN))
                )
            {
                di_flag = true;
                if(ADDRESSING_PIN_STATUS == di_state_get(DI1_ADDR_PACK_IN)) //收到DI1为高，说明DI2需要改成DO
                {
                    g_addr_out_put_pin = DO_2_BAT_PACK_OUT2;
                    sdk_dido_config(IO_2_BAT_PACK_OUT2,SDK_GPIO_OUTPUT);
                }
                else 
                {
                    g_addr_out_put_pin = DO_1_BAT_PACK_OUT1;
                    sdk_dido_config(IO_1_BAT_PACK_OUT1,SDK_GPIO_OUTPUT);
                }
                
                log_e("[ADD]io%d set output\n", g_addr_out_put_pin);
            }
        }
        else if(DO_2_BAT_PACK_OUT2 == g_addr_out_put_pin)
        {
            if(ADDRESSING_PIN_STATUS == di_state_get(DI1_ADDR_PACK_IN))
            {
                di_flag = true;
            }
        }
        else
        {
            if(ADDRESSING_PIN_STATUS == di_state_get(DI2_ADDR_PACK_IN))
            {
                di_flag = true;
            }            
        }
        
        
        if((true == di_flag)
            && (g_slave_addr_para.dev_addr != 1))   //兼容5V稳定输出的高压箱，当被编成过1号后，不再编自己，直到重新启动编址
        {
            g_slave_addr_para.dev_addr = p_rcv_msg->data;
            g_slave_addr_para.address_conflict_flag = 0;
            can_set_filter(g_slave_addr_para.dev_addr);
            THIS_LOGE("[ADD]addr%d\n", g_slave_addr_para.dev_addr);
            msg_t send_msg = {0};
            send_msg.cmd = CMD_SET_SLAVE_ADDR;
            send_addr_msg_reply(&send_msg);
        }

    }
}

static void slave_addr_store_proc(msg_t *p_rcv_msg)
{
    bms_attr_t bms_attr_data = {0};
    bms_attr_data = *get_bms_attr();
        
    if (g_slave_addr_para.addr_state == ADDRESSING_FINISH)// 判断是否为本机地址
    {
        THIS_LOGE("[ADD]store addr:%d\n",g_slave_addr_para.dev_addr);
        bms_attr_data.addr = g_slave_addr_para.dev_addr;
        data_store_save_bms_attr(ST_VAR_POS(bms_attr_t,addr), (uint8_t *)(&bms_attr_data.addr), ST_VAR_SIZE( bms_attr_t, addr ) );
    }
}

/**
 * @brief   内网CAN(bmu/bcu)，从机自动编址回复消息处理函数
 * @param   无
 * @return  无
 * @warning	无
 */
static void inner_addr_rcv_msg(msg_t *p_rcv_msg)
{
    if (p_rcv_msg == NULL)
    {
        return;
    }
    
    switch (p_rcv_msg->cmd)
    {
        case CMD_START_ADDRESSING:
            slave_addr_start_proc(p_rcv_msg);
            break;
        case CMD_SET_OUTPUT:
            slave_output_set_proc(p_rcv_msg);
            break;
        case CMD_SET_SLAVE_ADDR:
            slave_addr_set_proc(p_rcv_msg);
            break;
        case CMD_HEARTBEAT:
            inner_can_heartbeat_proc(p_rcv_msg);
            break;
        case CMD_ADDR_STORE:
            slave_addr_store_proc(p_rcv_msg);
            break;        
        default:
            break;
    }
    if (p_rcv_msg->sleep_cmd == 0xAA)
    {
        // 主机控制bmu休眠，当前cbs5000没有
    }        

}

/**
 * @brief   内网CAN(bmu/bcu)，定时广播心跳包，用于检测地址冲突与从机失联
 * @param   无
 * @return  无
 * @warning	无
 */
void send_heartbeat(void)
{
    static uint32_t timestamp = 0;
    if (sdk_is_tick_over(timestamp, os_tick_from_millisecond(1000)))
    {
        // 广播心跳包
        timestamp = sdk_tick_get();

        uint8_t data[8] = {0};
        can_frame_id_u tx_frame_id = {0};
        tx_frame_id.bit.src_addr = g_slave_addr_para.dev_addr;
        tx_frame_id.bit.src_type = DEV_BMU;
        tx_frame_id.bit.dst_addr = BROADCAST_DEVICE_ADDRESS;
        tx_frame_id.bit.dst_type = DEV_BROADCAST;
        tx_frame_id.bit.fun_code = FUNC_HEART_BEAT_CMD;
        tx_frame_id.bit.prio = SOFAR_CAN_PRI_LOW_H;
        can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_frame_id.id_val, data, 8);
    }
}

/**
 * 定时广播地址冲突
 */
static void send_address_conflict(void)
{
    static uint32_t timestamp = 0;
    if (g_slave_addr_para.address_conflict_flag)
    {
        if (sdk_is_tick_over(timestamp, os_tick_from_millisecond(1000)))
        { // 广播心跳包
            timestamp = sdk_tick_get();
            msg_t send_msg = {0};
            send_msg.cmd = CMD_CONFLICT;
            send_addr_msg_reply(&send_msg);
        }
    }
    else
    {
        timestamp = 0;
    }
}

/**
 * 编址输入电平变化上报状态
 */
static void send_bmu_di_status(void)
{
    static uint8_t last_di = 0xFF;
    static uint16_t send_time = 0;
    static uint8_t cycle_send_cnt = 0;
    static uint8_t start_flag = 0;
    static uint8_t last_slave_addr_proc_state = NON_CAN_ADDR_SET_CMD;
    uint8_t di = false;
    
    if(DO_0_NULL == g_addr_out_put_pin) //如果还没确认用哪个脚做OUT_PUT脚则跑这里
    {
        di = di_state_get(DI1_ADDR_PACK_IN)|di_state_get(DI2_ADDR_PACK_IN);
    }
    else if(DO_2_BAT_PACK_OUT2 == g_addr_out_put_pin)
    {
        di = di_state_get(DI1_ADDR_PACK_IN);
    }
    else
    {
        di = di_state_get(DI2_ADDR_PACK_IN);
    }
    
    if (1 == g_slave_addr_para.dev_addr)   //兼容默认5V输出的编址方式，当地址为1时则默认di为低，方便接着往下编址
    {
        di = false;
    }
    
    if (last_di != di)
    {
        send_time = 3; // 每10ms发送一次，发送3次
        log_e("[ADD]lastDi=%d,di=%d\n", last_di, di);
        last_di = di;
    }
    if (g_slave_addr_proc_state == CAN_SET_START_ADDR_CMD &&
        last_slave_addr_proc_state != CAN_SET_START_ADDR_CMD)
    {
        // 发12s的数据
        send_time = 400;
        start_flag = 1;
    }
    last_slave_addr_proc_state = g_slave_addr_proc_state;
    if (start_flag == 0)
    {
        return;
    }
    if ((send_time > 0 || BMU_ADDR_DEFAULT == g_slave_addr_para.dev_addr) && 
        (UPG_ING != upgrade_state_get()))
    {
        if (++cycle_send_cnt >= ADDRESS_DEAL_30MS_CNT)
        {
            // 发送io状态
            inner_can_send_msg_ready(BMS_REMOTE_SIGNAL_INFO1);
            if (send_time > 0)
            {
                send_time--;
            }
            cycle_send_cnt = 0;
        }
    }
}

/**
 * @brief   内网CAN(bmu/bcu)，发送自动编址控制指令
 * @param   无
 * @return  0:发送成功，-1：发送失败
 * @warning	无
 */
static int32_t send_addr_msg_reply(msg_t *msg)
{
    uint8_t data[8] = {0};
    can_frame_id_u tx_frame_id = {0};
    uint8_t master_state = NON_CAN_ADDR_SET_CMD;

    THIS_LOGD("send addr msg cmd=%d, src=%d, dst=%d, data=%d\n", msg->cmd, msg->src_addr, msg->dst_addr, msg->data);
    switch (msg->cmd)
    {
        case CMD_SET_OUTPUT:
            if (msg->data)
            {
                master_state = CAN_ADDR_SET_IO_HIGH_CMD;
            }
            else
            {
                master_state = CAN_ADDR_SET_IO_LOW_CMD;
            }
            break;
        case CMD_REQUEST:
            master_state = CAN_SET_START_ADDR_CMD;
            break;
        case CMD_SET_SLAVE_ADDR:
            master_state = CAN_SET_ADDR_CMD;
            break;
        case CMD_CONFLICT:
            master_state = CAN_ADDR_CONFLICT_CMD;
            break;
        case CMD_ADDR_STORE:
            master_state = CAN_ADDR_STORE_CMD;
            break;        
        default:
            return -1;
    }
    tx_frame_id.bit.src_addr = g_slave_addr_para.dev_addr;
    tx_frame_id.bit.src_type = DEV_BMU;
    tx_frame_id.bit.dst_addr = BCU_INNER_CAN_ADDR;
    tx_frame_id.bit.dst_type = DEV_BCU;
    tx_frame_id.bit.fun_code = FUNC_SLAVER_CTL_REPLY;
    tx_frame_id.bit.prio = SOFAR_CAN_PRI_LOW_H;

    data[0] = g_slave_addr_para.dev_addr; // 设置地址
    data[1] = master_state; // 设置从机状态
    data[2] = 0;
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_frame_id.id_val, data, 3);
    return 0;
}

/**
 * @brief   内网CAN(bmu/bcu)，定时广播心跳包，用于检测从机通信超时
 * @param   无
 * @return  无
 * @warning	无
 */
static void check_pack_comm_status(void)
{
    if (g_slave_addr_para.first_recv_master_heat_flag == 0)
    {
        g_slave_addr_para.unlink_time_cnt = 0;
        return;
    }
    if (++g_slave_addr_para.unlink_time_cnt >= 500)
    {
        if (g_slave_addr_para.fault_pack_unlink == 0)
        {
            THIS_LOGE("fault pack unlink!\n");
        }
        g_slave_addr_para.fault_pack_unlink = 1;
    }
    else
    {
        if (g_slave_addr_para.fault_pack_unlink == 1)
        {
            THIS_LOGE("fault pack link!\n");
        }
        g_slave_addr_para.fault_pack_unlink = 0;
    }
}

/**
 * @brief  获取自动编址状态
 * @return 自动编址状态
 */
auto_addressing_state_e auto_addressing_get_state(void)
{
    return g_slave_addr_para.addr_state;
}

/**
 * @brief  获取自动编址故障
 * @return AUTO_ADDRESSING_NO_FAULT     没故障
 * @return AUTO_ADDRESSING_ID_CONFLICT  通讯ID冲突
 * @return AUTO_ADDRESSING_COMM_FAIL    通讯故障
 */
uint8_t auto_addressing_fault_get(void)
{
    uint8_t error = AUTO_ADDRESSING_NO_FAULT;
    // 通讯故障
    if (g_slave_addr_para.fault_pack_unlink)         // 电池包与主机失联
    {
        error = AUTO_ADDRESSING_COMM_FAIL;
    }
        // 地址冲突
    if (g_slave_addr_para.address_conflict_flag)
    {
        error = AUTO_ADDRESSING_ID_CONFLICT;
    }
    return error;
}

/**
 * @brief  获取编址地址
 * @retval =0     未完成编址
 * @retval 1~0x0F 有效地址
 */
uint8_t auto_addressing_get_address(void)
{
    return g_slave_addr_para.dev_addr;
}

/**
 * @brief  使能自动编址，自动编址完成后再使能，会重新自动编址
 * @return 无
 */
void auto_addressing_enable(void)
{
    g_slave_addr_para.auto_addressing_enable = 1;
}

/**
 * @brief  禁止自动编址
 * @return 无
 */
void auto_addressing_disable(void)
{
    g_slave_addr_para.auto_addressing_enable = 0;
}

/**
 * @brief  获取自动编址使能标志
 * @return 无
 */
uint8_t auto_addressing_enable_flag(void)
{
    return g_slave_addr_para.auto_addressing_enable;
}

/**
 * @brief   内网CAN(bmu/bcu)，自动编址初始化
 * @param   无
 * @return  返回执行结果 0:正常；<0:异常
 * @warning	无
 */
void inner_auto_addr_init(void)
{
    state_machine_init(&g_auto_addr_fsm, auto_addr_fsm_name, g_addr_act_map, (uint8_t *)g_addr_evt_sta_map,
        ADDR_EVT_NUM, ADDR_STA_NUM, STA_ADDR_INIT);
    inner_auto_addr_can_register();
    auto_addressing_disable();
}

/**
 * @brief   内网CAN(bmu/bcu)，自动编址处理函数 10ms调用一次
 * @param   无
 * @return  无
 * @warning	无
 */
void inner_auto_addressing_proc(void)
{
#if AUTO_ADDR_SHELL_DEBUG
    if (true == g_auto_addressing_debug_flag)
    {
        send_heartbeat();
        return;
    }
#endif
    if (special_mode_get(ATUO_TEST))
    {
        return;
    }
    if (!g_slave_addr_para.auto_addressing_enable)  // 屏蔽自动编址
    {
        return;
    }

    send_address_conflict();
    send_bmu_di_status();
    uint8_t event = state_machine_proc(&g_auto_addr_fsm);
    fsm_state_trans(&g_auto_addr_fsm, event);
}    

/**
 * @brief   内网CAN(bmu/bcu)，从机自动编址回复CAN消息处理回调函数
 * @param   无
 * @return  无
 * @warning	无
 */
int32_t inner_addr_rcv_callback(uint32_t can_id, uint8_t *p_data, int32_t len)
{
    if (NULL == p_data || len < 3)
    {
        return -1;
    }
    msg_t addr_msg;
    int32_t ret = can_convert_to_addr_msg(can_id, p_data, &addr_msg, len);
    // THIS_LOGD("rcv addr msg cmd=%d, data=%d,sleC=%d\n", addr_msg.cmd, addr_msg.data, addr_msg.sleep_cmd);
    if (ret == 0)
    {
        inner_addr_rcv_msg(&addr_msg);
    }
    return ret;
}

uint8_t auto_addressing_pack_num_get(void)
{
    return 1;
}


/**
 * @brief  设置编址地址
 * @input   addr 地址
 * @retval 0有效，-1无效
 */
int8_t inner_address_set(uint8_t addr)
{
    int8_t ret = 0;

    if((addr >= 1) && (addr <= 8) &&(addr != g_slave_addr_para.dev_addr))
    {
        g_slave_addr_para.addr_state = ADDRESSING_FINISH;
        g_slave_addr_para.dev_addr = addr;
        auto_addressing_disable();
        shell_data_cycle_send_set(true);
        g_auto_addressing_debug_flag = true;
        can_set_filter(g_slave_addr_para.dev_addr);
        log_e("set address=%d\r\n", addr);
    }
    else
    {
        ret = -1;
    }

    return ret;
}

#if AUTO_ADDR_SHELL_DEBUG
/**
 * @brief                编址调试接口
 * @return               返回结果空
 * @warning              测试调试使用
 */
int32_t addr(int argc, char *argv[])
{

    uint8_t operation = 0;
    log_d("%s start\n", argv[0]);        //打印命令名称
    
    if(argc < 2)
    {
        log_d("addr para err \r\n");
    }
    else
    {
        if(!strcmp(argv[1], "set"))        //启动控制
        {
            if(argc < 3)
            {
                log_d("%s %s para err\n",argv[0],argv[1]);
                return -1;
            }
            operation = atoi(argv[2]);
            if (operation <= 10 && operation > 0)
            {
                g_slave_addr_para.addr_state = ADDRESSING_FINISH;
                g_slave_addr_para.dev_addr = operation;
                g_auto_addressing_debug_flag = true;
                auto_addressing_disable();
                can_set_filter(g_slave_addr_para.dev_addr);
                log_e("addr set suc,addr:%d \r\n",operation);
            }
            else
            {
                g_auto_addressing_debug_flag = false;
                log_d("addr set err \r\n");
            }
        }
        else if(!strcmp(argv[1], "get"))
        {
            operation = auto_addressing_get_address();
            log_d("addr:%d \r\n",operation);
        }
        else
        {
            log_d("addr test err \r\n");
        }
    }

    
    return 0;
}
MSH_CMD_EXPORT(addr, <get/set value(1-10)>);
#endif
    

