#include "led.h"
#include "bms_state.h"
#include "upgrade.h"
#include "fault_manage.h"
#include "ate.h"

#if LED_CTL_SHELL_DEBUG_FALG
static bool g_led_ctl_shell_debug_flag = false;
#endif

static bool g_led_ctrl_disable_flag = false; // 默认led控制禁能失效

/**
* @brief        ate LED逻辑禁止/使能控制
* @param        [in] disable_flag     true:屏蔽LED逻辑/false:LED逻辑正常
* @warning       一般只有ate测试才会调用，其他模块慎用
*/
void led_display_func_disable(bool disable_flag)
{
    if (true != disable_flag && false != disable_flag)
    {
        return;
    }
    g_led_ctrl_disable_flag = disable_flag;
}

/**
* @brief        LED逻辑屏蔽标志获取
* @param        void
* @return        执行结果
* @retval        true: 屏蔽led逻辑，false:正常使用led逻辑
*/
bool led_display_func_disable_flag_get(void)
{
    return g_led_ctrl_disable_flag;
}

/**
* @brief        开机时LED的闪烁设置， RUN亮，ALM灭，SOC流水灯闪烁
* @return        执行结果
* @retval        无返回值
* @pre            无前置条件
* @warning        无警告
*/
void led_display_mode(uint8_t led_type, uint8_t display_mode_type)
{
    switch (display_mode_type)
    {
    case LED_DISPLAY_MODE_1:
    {
        sdk_led_flash(led_type, 4000, 95, -1);

        break;
    }
    case LED_DISPLAY_MODE_2:
    {
        sdk_led_flash(led_type, 1000, 50, -1);

        break;
    }
    case LED_DISPLAY_MODE_3:
    {
        sdk_led_flash(led_type, 2000, 75, -1);

        break;
    }
    case LED_DISPLAY_MODE_4:
    {
        sdk_led_flash(led_type, 400, 50, -1);

        break;
    }
    case LED_DISPLAY_MODE_ALWAYS_ON:
    {
        sdk_led_flash(led_type, 1000, 0, -1);

        break;
    }
    case LED_DISPLAY_MODE_ALWAYS_CLOSE:
    {
        sdk_led_flash(led_type, 1000, 100, -1);

        break;
    }
    default:
        break;
    }


}

/**
* @brief        待机时的LED设置
  * -#             待机正常状态时，RUN闪1、ALM灭，SOC按照电量显示
  * -#             待机保护状态时，RUN灭、ALM亮，SOC全灭
* @param        [in] command                给LED灯的命令
  * -#             LED_STANDBY_NOAMAL            待机正常
  * -#             LED_STANDBY_PROTECT            待机保护
  * @param        [in] soc                    电池电量
* @return        执行结果
* @retval        无返回值
* @pre            无前置条件
* @warning        无警告
*/
void led_display_state(uint8_t command)
{
    switch (command)
    {
    case LED_STATE_FAULT:
    {
        led_display_mode(USER_NOR_LED, LED_DISPLAY_MODE_1);
        led_display_mode(USER_ERR_LED, LED_DISPLAY_MODE_ALWAYS_ON);

        break;
    }
    case LED_STATE_PROTECT:
    {
        led_display_mode(USER_NOR_LED, LED_DISPLAY_MODE_1);
        led_display_mode(USER_ERR_LED, LED_DISPLAY_MODE_4);

        break;
    }
    case LED_STATE_ALARM:
    {
        led_display_mode(USER_NOR_LED, LED_DISPLAY_MODE_1);
        led_display_mode(USER_ERR_LED, LED_DISPLAY_MODE_3);

        break;
    }    
    case LED_STATE_STADNY_NOMAL:
    {
        led_display_mode(USER_NOR_LED, LED_DISPLAY_MODE_1);
        led_display_mode(USER_ERR_LED, LED_DISPLAY_MODE_ALWAYS_CLOSE);

        break;
    }
    case LED_STATE_CHARGE_NOMAL:
    {
        led_display_mode(USER_NOR_LED, LED_DISPLAY_MODE_3);
        led_display_mode(USER_ERR_LED, LED_DISPLAY_MODE_ALWAYS_CLOSE);

        break;
    }
     case LED_STATE_DISCHARGE_NOMAL:
    {
        led_display_mode(USER_NOR_LED, LED_DISPLAY_MODE_3);
        led_display_mode(USER_ERR_LED, LED_DISPLAY_MODE_ALWAYS_CLOSE);

        break;
    }
    case LED_STATE_UPGRADE:
    {
        led_display_mode(USER_NOR_LED, LED_DISPLAY_MODE_4);
        led_display_mode(USER_ERR_LED, LED_DISPLAY_MODE_ALWAYS_CLOSE);

        break;
    }
    case LED_STATE_RECHARGE:
    {
        led_display_mode(USER_NOR_LED, LED_DISPLAY_MODE_2);
        led_display_mode(USER_ERR_LED, LED_DISPLAY_MODE_2);

        break;
    }
    case LED_STATE_POWER_OFF:
    {
        led_display_mode(USER_NOR_LED, LED_DISPLAY_MODE_ALWAYS_CLOSE);
        led_display_mode(USER_ERR_LED, LED_DISPLAY_MODE_ALWAYS_CLOSE);

        break;
    }
    default:
        break;
    }
}

/**
* @brief         led初始化
* @return        执行结果
* @retval        无返回值
*/
void bat_led_init(void)
{
    g_led_ctrl_disable_flag = false; // 默认led逻辑正常
}

/**
* @brief         系统状态led控制
* @return        执行结果
* @retval        无返回值
* @warning       放在bms_state_proc()任务后面
*/
void bat_led_display_proc(void)
{
    static uint8_t pre_led_state = LED_INIT_STATE;
    uint8_t led_state = LED_INIT_STATE;
    bms_system_state_e bat_sys_state = bms_state_get_sys_sta();
#if LED_CTL_SHELL_DEBUG_FALG
    if (g_led_ctl_shell_debug_flag)
    {
        pre_led_state = LED_INIT_STATE;
        return;
    }
#endif
    if (special_mode_get(ATUO_TEST))
    {
        return;
    }
    if (g_led_ctrl_disable_flag) // 屏蔽led功能退出
    {
        pre_led_state = LED_INIT_STATE;
        return;
    }
//    battery_state_e bat_chg_dsg_state = bms_state_get_bat_sta();
    const fault_stat_data_t* p_fault_data = fault_chg_dsg_level_get();
    if (NULL == p_fault_data)
    {
        return;
    }
    battery_state_e chg_dsg_state = bms_state_get_bat_sta();
    if (BMS_STATE_SHUT_DOWN == bat_sys_state)
    {
        led_state = LED_STATE_POWER_OFF;
    }
    else if (upgrade_state_get() == UPG_ING || BMS_STATE_UPGRADE == bat_sys_state)
    {
        led_state = LED_STATE_UPGRADE;
    }
    else if (BMS_STATE_PF_ERROR == bat_sys_state)
    {
        led_state = LED_STATE_FAULT;
    }    
    else if (true == bms_supple_chg_state_get())
    {
        led_state = LED_STATE_RECHARGE;
    }
    else if (LEVEL1 == p_fault_data->max_discharge_level || // 保护
        LEVEL1 == p_fault_data->max_charge_level)
    {
        led_state = LED_STATE_PROTECT;
    }
    else if (LEVEL2 == p_fault_data->max_discharge_level || // 告警
        LEVEL2 == p_fault_data->max_charge_level)
    {
        led_state = LED_STATE_ALARM;
    }    
    else if (BMS_STANDY_MODE == chg_dsg_state)
    {
        led_state = LED_STATE_STADNY_NOMAL;
    }
    else if (BMS_CHARGE_MODE == chg_dsg_state)
    {
        led_state = LED_STATE_CHARGE_NOMAL;
    }
    else if (BMS_DISCHARGE_MODE == chg_dsg_state)
    {
        led_state = LED_STATE_DISCHARGE_NOMAL;
    }
    else
    {
        led_state = LED_STATE_STADNY_NOMAL;
    }

    if (pre_led_state != led_state)
    {
        led_display_state(led_state);
    }

    pre_led_state = led_state;
}

/***********************************LED shell debug************************************************/
#if LED_CTL_SHELL_DEBUG_FALG


typedef enum
{
    DEBUG_VAL_LED_DISABLE_FLAG = 0,     ///< LED 屏蔽标志
    DEBUG_VAL_NUM,
} led_value_debug_e;

/**
 * @brief        设置模拟量debug
 * @param        [in] debug_flag 模拟量debug标志， 1：debug 0:normal
 * @param        [in] data_type 模拟量debug标志， 1：debug 0:normal
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
void led_value_set_debug(uint8_t data_type, int32_t value)
{
    switch (data_type)
    {
        case DEBUG_VAL_LED_DISABLE_FLAG:
            g_led_ctrl_disable_flag = value;
            break;
        default:
            log_e(" led val val_id over err\r\n");
            break;
    }
}

// 打印
void led_debug_printf(void)
{
    log_e("g_led_ctl_shell_debug_flag = %ld\n", g_led_ctl_shell_debug_flag);
    log_e("g_led_ctrl_disable_flag    = %ld\n", g_led_ctrl_disable_flag);
}

void led_debug_err_printf(void)
{
    log_e(" led param err\r\n");
    log_e(" led print : printf data\r\n");
    log_e(" led debug 0/1: debug start/close\r\n");
    log_e(" led set led_id(0~%d) state(0~%d): set led work\r\n", USER_LED_NUM - 1, LED_DISPLAY_MODE_NUM - 1);
    log_e(" led val val_id(0~%d) value(0~%d): set val \r\n", USER_LED_NUM - 1, LED_DISPLAY_MODE_NUM - 1);
    log_e(" led sta sta_id(0~%d) : set display state \r\n", LED_DISPLAY_STATE_NUM - 1);
}

void led_debug_help_printf(void)
{
    log_e("led_id:\n");
    log_e("USER_BOARD_LED      = %d\n", USER_BOARD_LED   ); 
    log_e("USER_NOR_LED        = %d\n", USER_NOR_LED     ); 
    log_e("USER_ERR_LED        = %d\n", USER_ERR_LED     ); 

    log_e("state type:\n");
    log_e("LED_DISPLAY_MODE_1            = %d\n", LED_DISPLAY_MODE_1           );
    log_e("LED_DISPLAY_MODE_2            = %d\n", LED_DISPLAY_MODE_2           );
    log_e("LED_DISPLAY_MODE_3            = %d\n", LED_DISPLAY_MODE_3           );
    log_e("LED_DISPLAY_MODE_ALWAYS_ON    = %d\n",  LED_DISPLAY_MODE_ALWAYS_ON  );
    log_e("LED_DISPLAY_MODE_ALWAYS_CLOSE = %d\n", LED_DISPLAY_MODE_ALWAYS_CLOSE);
    
    log_e("val_id:\n");
    log_e("DEBUG_VAL_LED_DISABLE_FLAG  = %d\n", DEBUG_VAL_LED_DISABLE_FLAG    );
 
    log_e("display state type:\n");
    log_e("LED_INIT_STATE            = %d\n", LED_INIT_STATE           );
    log_e("LED_STATE_FAULT           = %d\n", LED_STATE_FAULT          );
    log_e("LED_STATE_PROTECT         = %d\n", LED_STATE_PROTECT        );
    log_e("LED_STATE_STADNY_NOMAL    = %d\n", LED_STATE_STADNY_NOMAL   );
    log_e("LED_STATE_CHARGE_NOMAL    = %d\n", LED_STATE_CHARGE_NOMAL   );
    log_e("LED_STATE_DISCHARGE_NOMAL = %d\n", LED_STATE_DISCHARGE_NOMAL);
    log_e("LED_STATE_UPGRADE         = %d\n", LED_STATE_UPGRADE        );
    log_e("LED_STATE_RECHARGE        = %d\n", LED_STATE_RECHARGE       );
    log_e("LED_STATE_POWER_OFF       = %d\n", LED_STATE_POWER_OFF      );
}

/**
 * @brief        led功能样例
 * @param        argv 功能参数
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
static int led(int argc, char *argv[])
{

	if (argc < 2)
	{
		log_d("led para err\n");
	}
    else
    {
        if (!strcmp(argv[1], "print"))
        {
            led_debug_printf();
        }
        else if (!strcmp(argv[1], "debug"))
        {
            if(argc < 3)
            {
                log_d("%s %s para err\n",argv[0],argv[1]);
                return -1;
            }
            uint32_t flag = atoi(argv[2]); //解析第2个参数名称
            if (flag > true)
            {
                log_e(" led_debug flag: err\r\n");
                return -1;
            }
            g_led_ctl_shell_debug_flag = flag;
        }
        else if (!strcmp(argv[1], "set"))
        {  
            if(argc < 4)
            {
                log_d("%s %s para err\n",argv[0],argv[1]);
                return -1;
            }
            if (!g_led_ctl_shell_debug_flag)
            {
                log_e("no set led_ctl_shell_debug_flag\n");
                return -1;
            }
            uint32_t led_id = atoi(argv[2]);          // 参数1: 模拟量sample_value_debug_e
            int32_t led_state = atoi(argv[3]);        // 参数2：value值
            led_display_mode(led_id, led_state);
        }
        else if (!strcmp(argv[1], "val"))
        {
            if(argc < 4)
            {
                log_d("%s %s para err\n",argv[0],argv[1]);
                return -1;
            }        
            if (!g_led_ctl_shell_debug_flag)
            {
                log_e("no set led_ctl_shell_debug_flag\n");
                return -1;
            }
            uint32_t val_id = atoi(argv[2]);          // 参数1: 模拟量sample_value_debug_e
            int32_t val = atoi(argv[3]);              // 参数2：value值
            led_value_set_debug(val_id, val);
        }
        else if (!strcmp(argv[1], "sta"))
        {
            if(argc < 3)
            {
                log_d("%s %s para err\n",argv[0],argv[1]);
                return -1;
            }        
            if (!g_led_ctl_shell_debug_flag)
            {
                log_e("no set led_ctl_shell_debug_flag\n");
                return -1;
            }
            uint32_t sta_id = atoi(argv[2]);          // 参数1: 模拟量led_display_state_e
            led_display_state(sta_id);
        }
        else if (!strcmp(argv[1], "help"))
        {
            led_debug_help_printf();
        }
        else
        {
            led_debug_err_printf();
        }
    }

    return 0;
}

MSH_CMD_EXPORT(led, <print/debug 0-1/set id value/val valId value/sta id>);
#endif



