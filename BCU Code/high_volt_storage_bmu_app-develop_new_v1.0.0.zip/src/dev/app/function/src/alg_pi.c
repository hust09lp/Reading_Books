/*!*************************************************************
* @file			PI_I_CTRL_F.c
* @brief		增量式PI比例积分算法模块。
* @details 		该文件包含增量式PI算法。
* @date 		2022-09-01
* @copyright	SofarSolar。
***************************************************************/
#include "alg_pi.h"
//---------------------------------------------------------------------------
// Function Definition
//---------------------------------------------------------------------------
/**
 * @brief				初始化增量式PI比例积分模块
 * @param	v			增量式PI比例积分结构指针
 * @param	kp			增量式PI控制比例系数
 * @param	ki			增量式PI控制积分系数
 * @param	out_max		增量式PI控制输出最大限幅
 * @param	out_min		增量式PI控制输出最小限幅 
 * @return	None
 */
void alg_pi_ctrl_init(alg_pi_ctrl_t *v, float kp, float ki, float out_max, float out_min)
{
	/* Initialize variables */
	v->ref = 0;
	v->fbk = 0;
	v->out = 0;
	v->kp = kp;
	v->ki = ki;
	v->out_max = out_max;
	v->out_min = out_min;
	v->errn = 0;
	v->errn1 = 0;
}

/**
 * @brief				增量式PI比例积分计算
 * @param	v			增量式PI比例积分结构指针
 * @param	ref			增量式PI控制输入参考值
 * @param	fbk			增量式PI控制采样反馈值
 * @return	增量式PI比例积分输出值
 */
float algo_pi_ctrl_calc(alg_pi_ctrl_t *v, float ref, float fbk)
{
	v->ref = ref;
	v->fbk = fbk;
	/* Calculate error */
	v->errn = v->ref - v->fbk;	
	
	v->out += v->kp * (v->errn - v->errn1) + v->ki * v->errn;
	
	/* Update error */
	v->errn1 = v->errn;
	/* control output */
	v->out = (v->out > v->out_max)?(v->out_max) : v->out;
	v->out = (v->out < v->out_min)?(v->out_min) : v->out;
	
	return v->out;
}

/**
 * @brief				
 * @param	
 * @param	
 * @param	
 * @return	
 */
float algo_dchg_pwm_pi_ctrl_calc(alg_pi_ctrl_t *v, float ref, float fbk)
{
	v->ref = ref;
	v->fbk = fbk;
	/* Calculate error */
	v->errn = v->ref - v->fbk;	
	
	v->out = v->kp * (v->errn - v->errn1) + v->ki * v->errn;
	
	/* Update error */
	v->errn1 = v->errn;
	/* control output */
	v->out = (v->out > v->out_max)?(v->out_max) : v->out;
	v->out = (v->out < v->out_min)?(v->out_min) : v->out;
	
	return v->out;
}

/**
 * @brief				增量式PI比例积分清除
 * @param	v			增量式PI比例积分结构指针
 * @return	None
 */
void algo_pi_ctrl_clr(alg_pi_ctrl_t *v)
{
	v->out = 0;
	v->errn = 0;
	v->errn1 = 0;
}


