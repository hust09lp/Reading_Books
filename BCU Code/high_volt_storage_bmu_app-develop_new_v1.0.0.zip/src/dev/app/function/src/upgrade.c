#include "upgrade.h"
#include <string.h>
#include "sofar_can_manage.h"
#include "auto_addressing.h"
#include "sdk.h"
#include "sdk_para.h"
#include "sdk_iap_para.h"
#include "app_public.h"
#include "sdk_public.h"
#include "app_config.h"
#include "data_store.h"
#include "sdk_core.h"
#include "bms_state.h"
#include "state_machine.h"

#define UPGRADE_DEBUG_ENABLE 1                                    ///< 0禁止打印信息 1使能打印信息
#define FLASH_WRITE_FAIL_TIME 3
/* 函数声明 */
static uint8_t upgrade_enable_state_get(void);
static uint32_t calc_file_check_sum(uint32_t block_len);
static int32_t upgrade_check_upgrde_file_type(void);
static uint32_t pack_firmware_check(uint8_t type, int32_t length);
static int32_t create_bak_file(uint8_t bak_file_type);
static int32_t upgrade_read_upgrde_ver_same_flag(void);

#ifdef UPD_3PH_FLAG
static int32_t reply_file_info(void);
static int32_t reply_block_start(uint32_t relpy_flag);
static int32_t reply_file_check(uint8_t *tans_fail);
static int32_t reply_file_end(void);

static int32_t upgrade_timing_time_ext_master(can_frame_data_t *frame_data);
static int32_t upgrade_file_info_ext_master(can_frame_data_t *frame_data);
static int32_t upgrade_block_data_start_ext_master(can_frame_data_t *frame_data);
static int32_t upgrade_block_data_ext_master(can_frame_data_t *frame_data);
static int32_t upgrade_file_check_ext_master(can_frame_data_t *frame_data);
static int32_t upgrade_file_end_ext_master(can_frame_data_t *frame_data);

/* 数据校验相关函数 */
static void invert_uint8(uint8_t* p_dst_buf, uint8_t* p_src_buf);
static void invert_uint16(uint16_t* p_dst_buf, uint16_t* p_src_buf);
uint16_t crc16_ccitt(uint8_t* p_src_data, uint32_t src_data_size);

#endif

/********************************升级状态机处理函数声明****************************************/
static uint8_t sta_upgrade_wait_start_entry(void);
static uint8_t sta_upgrade_wait_start_run(void);
static uint8_t sta_upgrade_file_info_entry(void);
static uint8_t sta_upgrade_file_info_run(void);
static uint8_t sta_upgrade_block_data_entry(void);
static uint8_t sta_upgrade_block_data_run(void);
static uint8_t sta_upgrade_file_check_entry(void);
static uint8_t sta_upgrade_file_check_run(void);
static uint8_t sta_upgrade_file_end_entry(void);
static uint8_t sta_upgrade_file_end_run(void);
static uint8_t sta_upgrade_finish_run(void);
static uint8_t sta_upgrade_error_entry(void);
static uint8_t sta_upgrade_error_run(void);
/********************************升级状态机使用变量定义****************************************/
static fsm_action_map_t g_upgrade_act_map[UPG_STA_NUM] = 
{
    [UPG_WAIT_START]           = {sta_upgrade_wait_start_entry, sta_upgrade_wait_start_run},
    [UPG_FILE_INFO]            = {sta_upgrade_file_info_entry, sta_upgrade_file_info_run},
    [UPG_BLOCK_DATA]           = {sta_upgrade_block_data_entry, sta_upgrade_block_data_run},
    [UPG_FILE_CHECK]           = {sta_upgrade_file_check_entry, sta_upgrade_file_check_run},
    [UPG_FILE_END]             = {sta_upgrade_file_end_entry, sta_upgrade_file_end_run},
    [UPG_UPDATE_ERROR]         = {sta_upgrade_error_entry, sta_upgrade_error_run},
    [UPG_UPDATE_FINISH]        = {NULL, sta_upgrade_finish_run},                                                                                                                                                                                                                                                 
};

static uint8_t g_upgrade_evt_sta_map[UPG_STA_NUM][UPG_EVT_NUM] = 
{                    // EVT_UPG_STA_CPL_SUS  EVT_UPG_OPERATE_FAIL   EVT_UPG_TIMEOUT_OR_ERR  EVT_UPG_TEMPORARY EVT_UPG_START  EVT_UPG_BLOCK EVT_UPG_CHECK
    [UPG_WAIT_START]           = {STA_NULL,           STA_NULL,           STA_NULL,           STA_NULL,       UPG_FILE_INFO,      STA_NULL,        STA_NULL},
    [UPG_FILE_INFO]            = {UPG_BLOCK_DATA,     UPG_WAIT_START,     UPG_UPDATE_ERROR,   STA_NULL,       STA_NULL,           STA_NULL,        STA_NULL},
    [UPG_BLOCK_DATA]           = {UPG_FILE_CHECK,     STA_NULL,           UPG_UPDATE_ERROR,   STA_NULL,       UPG_FILE_INFO,      STA_NULL,        STA_NULL},
    [UPG_FILE_CHECK]           = {UPG_FILE_END,       UPG_BLOCK_DATA,     UPG_UPDATE_ERROR,   STA_NULL,       UPG_FILE_INFO,      STA_NULL,        STA_NULL},
    [UPG_FILE_END]             = {UPG_UPDATE_FINISH,  UPG_WAIT_START,     UPG_UPDATE_ERROR,   UPG_WAIT_START, UPG_FILE_INFO,      STA_NULL,        STA_NULL},
    [UPG_UPDATE_ERROR]         = {UPG_UPDATE_FINISH,  STA_NULL,           STA_NULL,           UPG_FILE_END,   UPG_FILE_INFO,      UPG_BLOCK_DATA,  UPG_FILE_CHECK},
    [UPG_UPDATE_FINISH]        = {UPG_WAIT_START,     STA_NULL,           STA_NULL,           STA_NULL,       UPG_FILE_INFO,      STA_NULL,        STA_NULL},    
};
/* 全局变量初始化 */
static uint8_t g_upgrade_enable_flag = 0;                            // 0禁止升级 1使能升级
static state_machine_t g_upgrade_fsm = {0};
static const char* upgrade_fsm_name = "upgrade";
static upgrade_fsm_para_t g_upgrade_fsm_para = {0};
static uint8_t g_boot_upgrade_flag = 0;                            // 0禁止升级 1使能升级
static uint8_t g_upgrade_state = UPG_IDLE;                      // 升级状态：0未升级 1升级中    2升级完成  3升级失败
static upgrade_proc_para_t g_upg_proc_para = {0};
static upgrade_data_info_t upgrade_data_info = {0};
static upgrade_data_info_t upgrade_data_info_tmp = {0};
static upgrade_flash_para_t upgrade_flash_para = { 0 };
static uint32_t g_check_fw_file_size = 0;
static uint32_t g_transmit_bit_mask[TRANSMIT_GROUP] = { 0 };            //传输标志位：每24个一组，总共 256K / 1024(块) / 24 = 11
static uint32_t g_crc32 = 0xFFFFFFFF;
static uint8_t g_flash_write_fail_cnt = 0;
static uint8_t g_tmp_buf_1[BLOCK_MAX_DATA_SIZE] = { 0 };
static uint8_t g_tmp_buf_2[BLOCK_MAX_DATA_SIZE] = { 0 };
static fs_t* gp_fs = NULL;
static fs_t* gp_bak_temp_fs = NULL;

static const uint32_t crc32_table[] = {
    0x00000000, 0x77073096, 0xee0e612c, 0x990951ba, 0x076dc419, 0x706af48f,
    0xe963a535, 0x9e6495a3, 0x0edb8832, 0x79dcb8a4, 0xe0d5e91e, 0x97d2d988,
    0x09b64c2b, 0x7eb17cbd, 0xe7b82d07, 0x90bf1d91, 0x1db71064, 0x6ab020f2,
    0xf3b97148, 0x84be41de, 0x1adad47d, 0x6ddde4eb, 0xf4d4b551, 0x83d385c7,
    0x136c9856, 0x646ba8c0, 0xfd62f97a, 0x8a65c9ec, 0x14015c4f, 0x63066cd9,
    0xfa0f3d63, 0x8d080df5, 0x3b6e20c8, 0x4c69105e, 0xd56041e4, 0xa2677172,
    0x3c03e4d1, 0x4b04d447, 0xd20d85fd, 0xa50ab56b, 0x35b5a8fa, 0x42b2986c,
    0xdbbbc9d6, 0xacbcf940, 0x32d86ce3, 0x45df5c75, 0xdcd60dcf, 0xabd13d59,
    0x26d930ac, 0x51de003a, 0xc8d75180, 0xbfd06116, 0x21b4f4b5, 0x56b3c423,
    0xcfba9599, 0xb8bda50f, 0x2802b89e, 0x5f058808, 0xc60cd9b2, 0xb10be924,
    0x2f6f7c87, 0x58684c11, 0xc1611dab, 0xb6662d3d, 0x76dc4190, 0x01db7106,
    0x98d220bc, 0xefd5102a, 0x71b18589, 0x06b6b51f, 0x9fbfe4a5, 0xe8b8d433,
    0x7807c9a2, 0x0f00f934, 0x9609a88e, 0xe10e9818, 0x7f6a0dbb, 0x086d3d2d,
    0x91646c97, 0xe6635c01, 0x6b6b51f4, 0x1c6c6162, 0x856530d8, 0xf262004e,
    0x6c0695ed, 0x1b01a57b, 0x8208f4c1, 0xf50fc457, 0x65b0d9c6, 0x12b7e950,
    0x8bbeb8ea, 0xfcb9887c, 0x62dd1ddf, 0x15da2d49, 0x8cd37cf3, 0xfbd44c65,
    0x4db26158, 0x3ab551ce, 0xa3bc0074, 0xd4bb30e2, 0x4adfa541, 0x3dd895d7,
    0xa4d1c46d, 0xd3d6f4fb, 0x4369e96a, 0x346ed9fc, 0xad678846, 0xda60b8d0,
    0x44042d73, 0x33031de5, 0xaa0a4c5f, 0xdd0d7cc9, 0x5005713c, 0x270241aa,
    0xbe0b1010, 0xc90c2086, 0x5768b525, 0x206f85b3, 0xb966d409, 0xce61e49f,
    0x5edef90e, 0x29d9c998, 0xb0d09822, 0xc7d7a8b4, 0x59b33d17, 0x2eb40d81,
    0xb7bd5c3b, 0xc0ba6cad, 0xedb88320, 0x9abfb3b6, 0x03b6e20c, 0x74b1d29a,
    0xead54739, 0x9dd277af, 0x04db2615, 0x73dc1683, 0xe3630b12, 0x94643b84,
    0x0d6d6a3e, 0x7a6a5aa8, 0xe40ecf0b, 0x9309ff9d, 0x0a00ae27, 0x7d079eb1,
    0xf00f9344, 0x8708a3d2, 0x1e01f268, 0x6906c2fe, 0xf762575d, 0x806567cb,
    0x196c3671, 0x6e6b06e7, 0xfed41b76, 0x89d32be0, 0x10da7a5a, 0x67dd4acc,
    0xf9b9df6f, 0x8ebeeff9, 0x17b7be43, 0x60b08ed5, 0xd6d6a3e8, 0xa1d1937e,
    0x38d8c2c4, 0x4fdff252, 0xd1bb67f1, 0xa6bc5767, 0x3fb506dd, 0x48b2364b,
    0xd80d2bda, 0xaf0a1b4c, 0x36034af6, 0x41047a60, 0xdf60efc3, 0xa867df55,
    0x316e8eef, 0x4669be79, 0xcb61b38c, 0xbc66831a, 0x256fd2a0, 0x5268e236,
    0xcc0c7795, 0xbb0b4703, 0x220216b9, 0x5505262f, 0xc5ba3bbe, 0xb2bd0b28,
    0x2bb45a92, 0x5cb36a04, 0xc2d7ffa7, 0xb5d0cf31, 0x2cd99e8b, 0x5bdeae1d,
    0x9b64c2b0, 0xec63f226, 0x756aa39c, 0x026d930a, 0x9c0906a9, 0xeb0e363f,
    0x72076785, 0x05005713, 0x95bf4a82, 0xe2b87a14, 0x7bb12bae, 0x0cb61b38,
    0x92d28e9b, 0xe5d5be0d, 0x7cdcefb7, 0x0bdbdf21, 0x86d3d2d4, 0xf1d4e242,
    0x68ddb3f8, 0x1fda836e, 0x81be16cd, 0xf6b9265b, 0x6fb077e1, 0x18b74777,
    0x88085ae6, 0xff0f6a70, 0x66063bca, 0x11010b5c, 0x8f659eff, 0xf862ae69,
    0x616bffd3, 0x166ccf45, 0xa00ae278, 0xd70dd2ee, 0x4e048354, 0x3903b3c2,
    0xa7672661, 0xd06016f7, 0x4969474d, 0x3e6e77db, 0xaed16a4a, 0xd9d65adc,
    0x40df0b66, 0x37d83bf0, 0xa9bcae53, 0xdebb9ec5, 0x47b2cf7f, 0x30b5ffe9,
    0xbdbdf21c, 0xcabac28a, 0x53b39330, 0x24b4a3a6, 0xbad03605, 0xcdd70693,
    0x54de5729, 0x23d967bf, 0xb3667a2e, 0xc4614ab8, 0x5d681b02, 0x2a6f2b94,
    0xb40bbe37, 0xc30c8ea1, 0x5a05df1b, 0x2d02ef8d };

/*************************************公共接口函数*************************************************/
/**
* @brief        存放传输标志位
* @param        无
* @return        无
* @retval        无
* @pre            无
*/
static void transmit_success_bit_mask(uint16_t block_cnt, uint8_t flag)
{
    uint8_t remainder = 0;    // 余数
    uint8_t quotient = 0;    // 商

    quotient = block_cnt / 24;
    remainder = block_cnt % 24;

    if (quotient >= TRANSMIT_GROUP)
    {
        return;
    }

    if (flag)
    {
        g_transmit_bit_mask[quotient] |= (1 << remainder);
    }
    else
    {
        g_transmit_bit_mask[quotient] &= ~(1 << remainder);
    }
}
/**
* @brief        检测传输标志位
* @param        无
* @return        执行结果
* @retval        0：未完成
* @retval        1：完成
* @pre            无
*/
static uint8_t check_transmit_success_bit_mask(uint16_t block_cnt)
{
    uint8_t remainder = 0;    // 余数
    uint8_t quotient = 0;    // 商

    quotient = block_cnt / 24;
    remainder = block_cnt % 24;

    if (quotient >= TRANSMIT_GROUP)
    {
        return 0;        // 未成功
    }

    if ((g_transmit_bit_mask[quotient] >> remainder) & 0x00000001)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
/**
* @brief        清除传输标志位
* @param        无
* @return        无
* @retval        无
* @pre            无
*/
static void clear_all_transmit_success_bit_mask(uint32_t block_cnt)
{
    uint32_t i = 0;
    uint8_t    group_num = 0, group_cnt = 0;
    uint8_t    finally_group_block = 0;

    if (0 == block_cnt)
    {
        for (i = 0; i < TRANSMIT_GROUP; i++)
        {
            g_transmit_bit_mask[i] = 0;
        }

        return;
    }

    for (i = 0; i < TRANSMIT_GROUP; i++)
    {
        g_transmit_bit_mask[i] = 0xFFFFFFFF;
    }

    group_num = (block_cnt - 1) / BLOCK_PER_GROUP;
    finally_group_block = block_cnt % BLOCK_PER_GROUP;

    for (group_cnt = 0; group_cnt < group_num + 1; group_cnt++)
    {
        if (0 != finally_group_block && group_cnt == group_num)// 判断为最后一个组，需判断不满24块
        {
            for (i = 0; i < finally_group_block; i++)
            {
                g_transmit_bit_mask[group_cnt] &= ~(0x00000001 << i);
            }
        }
        else
        {
            for (i = 0; i < BLOCK_PER_GROUP; i++)
            {
                g_transmit_bit_mask[group_cnt] &= ~(0x00000001 << i);
            }
        }
    }
}
static int32_t upgrade_file_write_to_fs(void)
{
    // crc校验
    uint16_t calc_crc = crc16_ccitt(upgrade_data_info_tmp.block_upgrade_data, upgrade_data_info_tmp.block_data_len);
    if (upgrade_data_info_tmp.block_crc == calc_crc)
    {
        //log_d("[upg]block rcv suc\n");
        if (g_upg_proc_para.write_block_state == UPG_WRITE_BLOCK_DATA_START)
        {
            g_upg_proc_para.write_block_state = UPG_WRITE_BLOCK_DATA_IDLE;
            log_i("[upg]Block%dNoReady\n", upgrade_data_info_tmp.block_send_cnt);
            return 0;
        }
        else if (g_upg_proc_para.write_block_state == UPG_WRITE_BLOCK_DATA_IDLE)
        {
            log_i("[upg]b%dIDLE\n", upgrade_data_info_tmp.block_send_cnt);
            return 0;
        }
    }
    else
    {
        // 如果crc校验失败需要立即舍弃此帧，并且写状态设置为空闲
        g_upg_proc_para.write_block_state = UPG_WRITE_BLOCK_DATA_IDLE;
        log_d("[upg]block%d bCrc%x,Ccrc%x\n", upgrade_data_info_tmp.block_send_cnt ,upgrade_data_info_tmp.block_crc, calc_crc);
        return 0;
    }
    // 判断是否重复帧，不是正常copy
    if((upgrade_data_info_tmp.block_send_cnt != upgrade_data_info.block_send_cnt) ||    // 正常进入
        (0 == upgrade_data_info.block_data_len))   // 首次进入
    {
        g_upg_proc_para.write_block_state = UPG_WRITE_BLOCK_DATA_IDLE;
        g_upgrade_fsm_para.stat_cnt_time = sdk_tick_get();
        //将接收报文里的临时数据复制进来
        memcpy(upgrade_data_info.block_upgrade_data, upgrade_data_info_tmp.block_upgrade_data, upgrade_data_info_tmp.block_data_len);
        upgrade_data_info.block_send_cnt = upgrade_data_info_tmp.block_send_cnt;
        upgrade_data_info.block_data_len = upgrade_data_info_tmp.block_data_len;
    }
    else
    {
        log_i("[upg]Sameblock%dDataNoNeed\n", upgrade_data_info_tmp.block_send_cnt);
        // log_d("[upgrade] rcv block repeat tmp block :%d , now blokc :%d \r\n", upgrade_data_info_tmp.block_send_cnt,upgrade_data_info.block_send_cnt);
        return 0;
    }
    // 获取最后一包数据量，计算总数据量
    if ((0 != upgrade_data_info.block_total_num) &&
        (upgrade_data_info.block_send_cnt == upgrade_data_info.block_total_num - 1))
    {
        g_check_fw_file_size = (upgrade_data_info.block_total_num - 1) * upgrade_data_info.block_size + upgrade_data_info.block_data_len;
        log_i("[upg]fileSize=%d\n", g_check_fw_file_size);
    }
    if ((false == check_transmit_success_bit_mask(upgrade_data_info.block_send_cnt)) &&
        (0 != upgrade_data_info.block_data_len)) // 未写入过的block
    {
        // 文件偏移
        int16_t ret = sdk_fs_lseek(gp_fs, upgrade_data_info.block_send_cnt * upgrade_data_info.block_size);
        if (ret != 0)
        {
            log_w("[upg]%dwriteDataLseekFailed:%d\n", upgrade_data_info.block_send_cnt, ret);
            return -2;
        }

        // 写1k数据到文件系统
        int16_t write_result = sdk_fs_write(gp_fs, upgrade_data_info.block_upgrade_data, upgrade_data_info.block_data_len);
        if (write_result < 0)
        {
            log_w("[upg]%dwriteDataFailed:%d\n", upgrade_data_info.block_send_cnt, write_result);
            return -1;
        }
        else
        {
            log_d("file save index = %d suc \r\n", upgrade_data_info.block_send_cnt);
            // 当前位置写成功标志
            transmit_success_bit_mask(upgrade_data_info.block_send_cnt, true);
            upgrade_data_info.file_check_sum += calc_file_check_sum(upgrade_data_info.block_data_len);
            upgrade_data_info.file_size += upgrade_data_info.block_data_len;
        }
    }
    else
    {
        log_i("[upg]BlockLen:%d or SaveBlockRcv:%d\n" , upgrade_data_info.block_data_len,upgrade_data_info.block_send_cnt);
    }
    return 0;
}

/**
* @brief        回复id:07FAXXXX报文
* @param        [in] p_file_data:CAN报文
* @return        执行结果
* @retval        无
* @pre            无
*/
//static int32_t reply_system_reset(int32_t para)
//{
//    int32_t ret = 0;
//    can_msg_t can_msg = {0};
//    uint8_t data[8] = {0};

//    can_msg.src_addr = auto_addressing_get_address(); // TODO
//    can_msg.src_type = DEV_BMU;
//    can_msg.dst_addr = g_upg_proc_para.src_addr;
//    can_msg.dst_type = g_upg_proc_para.src_dev_type;
//    can_msg.fun_code = FUN_UPG_TIMER;
//    can_msg.type = SOFAR_CAN_REPLAY;
//    can_msg.prio = SOFAR_CAN_PRI_REPLAY;
//    if (0 == para)
//    {
//        data[0] = 0x02;// 进入boot升级流程成功
//    }

//    ret = can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, &can_msg, data, 8);

//    return ret;
//}

static uint32_t calc_file_check_sum(uint32_t block_len)
{
    uint32_t i = 0;
    uint32_t sum_check = 0;

    if (block_len > BLOCK_MAX_DATA_SIZE)
    {
        return 0;
    }

    for (i = 0; i < block_len; i++)
    {
        sum_check += upgrade_data_info.block_upgrade_data[i];
    }

    return sum_check;
}
static void check_crc32(uint8_t* buf, int32_t len)
{
    uint8_t* p = NULL;

    for (p = buf; len > 0; ++p, --len)
    {
        g_crc32 = (uint32_t)(crc32_table[(g_crc32 ^ *p) & 0xFF] ^ (g_crc32 >> 8));
    }
}

static uint32_t crc32_cal_compare(uint8_t* buf, int32_t len)
{
    uint8_t* p = NULL;
    uint32_t crc32_t = 0xFFFFFFFF;

    for (p = buf; len > 0; ++p, --len)
    {
        crc32_t = (uint32_t)(crc32_table[(crc32_t ^ *p) & 0xFF] ^ (crc32_t >> 8));
    }
    crc32_t = ~crc32_t;

    return crc32_t;
}

static uint8_t crc8_ccitt(uint8_t* ptr, uint8_t len)
{

    uint8_t crc;
    uint8_t i;
    crc = 0;
    while (len--)
    {
        crc ^= *ptr++;
        for (i = 0; i < 8; i++)
        {
            if (crc & 0x80)
            {
                crc = (crc << 1) ^ 0x07;
            }
            else crc <<= 1;
        }
    }
    return crc;
}
/**
* @brief        对合并固件包进行CRC32校验
* @param        合并固件包长度
* @return        执行结果
* @retval        校验值
* @pre            无
*/
static uint32_t pack_firmware_check(uint8_t type, int32_t length)
{
    g_crc32 = 0xFFFFFFFF;
    uint32_t i = 0;
    uint32_t check_value;
    int32_t ret = 0;
    fs_t* temp_fs = NULL;
    
    if (type == UPGRADE_PACK)
    {
        temp_fs = gp_fs;    
    }
    else if (type == BAK_PACK)
    {
        temp_fs = gp_bak_temp_fs; 
    }
    
    ret = sdk_fs_lseek(temp_fs, 0);
    if (ret != 0)
    {

        log_w("[upg]SdkFsLseekFailed=%d\n", ret);

        goto err_exit;
    }
    for (i = 0; i < (length >> 10) + 1; i++)
    {
        memset(g_tmp_buf_2, 0, sizeof(g_tmp_buf_2));

        if (type == UPGRADE_PACK)
        {
            if (i == (length >> 10))
            {
                ret = sdk_fs_read(temp_fs, g_tmp_buf_2, length % BLOCK_MAX_DATA_SIZE);
                if (ret != (length % BLOCK_MAX_DATA_SIZE))
                {
                    goto err_exit;
                }
                check_crc32(g_tmp_buf_2, length % BLOCK_MAX_DATA_SIZE); // 减去签名信息中CRC32字段
            }
            else
            {
                ret = sdk_fs_read(temp_fs, g_tmp_buf_2, BLOCK_MAX_DATA_SIZE);
                if (ret != BLOCK_MAX_DATA_SIZE)
                {
                    goto err_exit;
                }
                check_crc32(g_tmp_buf_2, BLOCK_MAX_DATA_SIZE);
            }   
        }
        else if (type == BAK_PACK)
        {
            ret = sdk_fs_read(temp_fs, g_tmp_buf_2, BLOCK_MAX_DATA_SIZE);
            if (ret != BLOCK_MAX_DATA_SIZE)
            {
                goto err_exit;
            }
            check_crc32(g_tmp_buf_2, BLOCK_MAX_DATA_SIZE);
        }

    }
    check_value = ~g_crc32;

    log_i("[upg]CalCrc=%x\n", check_value);    //计算出来的CRC
    return check_value;
err_exit:
    sdk_fs_close(temp_fs);
    temp_fs = NULL;
    sdk_fs_remove(NEW_UPG_FILE);

    return ret;
}

static uint8_t upgrade_cmd(void)
{
    uint8_t event = EVT_NULL;
    if (UPG_FUN_START == g_upg_proc_para.function_code_flag)// 启动升级
    {
        upgrade_flash_para.save_fw_file_flag = 0;
        event = EVT_UPG_STA_CPL_SUS;
        g_upgrade_state = UPG_ING;
    }
    else if (UPG_FUN_TEMP_STORAGE == g_upg_proc_para.function_code_flag)// 暂存升级
    {
        upgrade_flash_para.save_fw_file_flag = 1;
        event = EVT_UPG_TEMPORARY;
        g_upgrade_state = UPG_IDLE;
    }
    else
    {
        upgrade_flash_para.save_fw_file_flag = 0;
        event = EVT_UPG_STA_CPL_SUS;
        g_upgrade_state = UPG_ING;
    }
//    g_upg_proc_para.upgrade_success_flag = UPG_ING_MASK;
    // reply_file_end();

    sdk_para_write(IAP_PARA, ST_VAR_POS(upgrade_flash_para_t, save_fw_file_flag),
        &upgrade_flash_para.save_fw_file_flag, ST_VAR_SIZE(upgrade_flash_para_t, save_fw_file_flag));
    sdk_para_sync(IAP_PARA);

    log_i("[upg]upgFileType:%d\n", g_upg_proc_para.upgrade_file_type_flag);
    uint32_t bms_para = 0;
    sdk_para_read(IAP_PARA, ST_VAR_POS(upgrade_flash_para_t, save_fw_file_flag),
        (uint8_t*)&bms_para, ST_VAR_SIZE(upgrade_flash_para_t, save_fw_file_flag));
    log_i("bmsPara :%d\n", bms_para);
    log_i("checkSuccess,funCodeFlag:%d\n", g_upg_proc_para.function_code_flag);

    return event;
}

/**
* @brief        读取内部flash
* @param        无
* @return        执行结果
* @retval        无
* @pre            无
*/
void drv_mcu_flash_read_sector(uint32_t flash_addr, uint32_t read_length, uint32_t *read_data)
{
    uint32_t i = 0;
    
    for(i = 0;i < (read_length / sizeof(uint32_t)); i ++)
    {
        ((uint32_t *)read_data)[i] = ((uint32_t *)flash_addr)[i];
    }
}
/**
* @brief        检测是否存在备份文件
* @param        无
* @return        执行结果
* @retval        无
* @pre            无
*/
void check_bak_file(void)
{
    // 打开core备份文件
    gp_fs = sdk_fs_open(CORE_BACKUP_FILE, FS_READ);// 防止掉电后文件损坏
    if (gp_fs == NULL)
    {
        sdk_fs_close(gp_fs);
        gp_fs = NULL;
        create_bak_file(FILE_TYPE_CORE);
    }
    else
    {
        sdk_fs_close(gp_fs);    
        gp_fs = NULL;
    }

    // 打开core备份文件
    gp_fs = sdk_fs_open(APP_BACKUP_FILE, FS_READ);// 防止掉电后文件损坏
    if (gp_fs == NULL)
    {
        sdk_fs_close(gp_fs);
        gp_fs = NULL;
        create_bak_file(FILE_TYPE_APP);
    }
    else
    {
        sdk_fs_close(gp_fs);    
        gp_fs = NULL;
    }
}

/**
* @brief        创建备份文件
* @param        文件类型
* @return        执行结果
* @retval        无
* @pre            无
*/
int32_t create_bak_file(uint8_t bak_file_type)
{
    int32_t ret = 0;
    uint32_t write_addr = 0;
    uint32_t data_remain = 0;
    uint32_t read_bytes = 0;
    uint32_t external_calc_crc = 0;
    uint32_t inside_calc_crc = 0;
    uint32_t pre_data_remain = 0;
    g_crc32 = 0xFFFFFFFF;
    int32_t count = 0;
    int32_t back_size = 0;
    
    gp_bak_temp_fs = sdk_fs_open(TEMP_BACKUP_FILE, FS_OPEN_ALWAYS | FS_WRITE | FS_READ);
    if (gp_bak_temp_fs == NULL)
    {
        ret = -1;
        goto err_exit;
    }
    
    if (bak_file_type == FILE_TYPE_CORE)
    {
        write_addr = CORE_START_ADDR;
        data_remain = CORE_SIZE;
        log_i("[upg]CreatCoreBakFile\n");
    }
    else if (bak_file_type == FILE_TYPE_APP)
    {
        write_addr = APP_START_ADDR;
        data_remain = APP_SIZE;
        log_i("[upg]CreatAppBakFile\n");
    }
    else
    {
        ret = -2;
        log_w("[upg]BakFileTypeFailed\n");
        goto err_exit;
    }

    pre_data_remain = data_remain;
    while (data_remain)
    { 
        memset(g_tmp_buf_2, 0, BLOCK_MAX_DATA_SIZE);      
        log_d("creatFrame=%d\n", count++);
         if (data_remain < BLOCK_MAX_DATA_SIZE)
        {
            read_bytes = data_remain;
        }
        else
        {
            read_bytes = BLOCK_MAX_DATA_SIZE;
        }
        
        
        // drv_mcu_flash_read_sector(write_addr, read_bytes, (uint32_t *)g_app_file_buffer);
        // ram不够，将g_app_file_buffer替换成g_tmp_buf_2
        drv_mcu_flash_read_sector(write_addr, read_bytes, (uint32_t *)g_tmp_buf_2);

        //如果读到的数据为全0或全F，说明读取完成；
        if((CRC_CHECK_SUM_F == crc32_cal_compare(g_tmp_buf_2, read_bytes))
            ||(CRC_CHECK_SUM_0 == crc32_cal_compare(g_tmp_buf_2, read_bytes)))
        {
            log_i("[upg]creatFileSuc\n");
            break;
        }

        check_crc32(g_tmp_buf_2, read_bytes);
        
        ret = sdk_fs_write(gp_bak_temp_fs, g_tmp_buf_2, BLOCK_MAX_DATA_SIZE);
        if (ret != BLOCK_MAX_DATA_SIZE)
        {
            goto err_exit;
        }
        else
        {
            ret = 0;
        }        
        
         data_remain -= read_bytes;
        write_addr += read_bytes; 
    }
    inside_calc_crc = ~g_crc32;
    log_i("[upg]insideCalcCrc:%x\n", inside_calc_crc);

    //实际写入长度，因为pack_firmware_check的循环+1了，故这里需要减1
    if(pre_data_remain >= (data_remain+BLOCK_MAX_DATA_SIZE))
    {
        pre_data_remain = pre_data_remain - data_remain - BLOCK_MAX_DATA_SIZE;
        log_i("[upg]actBakFileSize:%d\n", pre_data_remain / BLOCK_MAX_DATA_SIZE);
        external_calc_crc = pack_firmware_check(BAK_PACK, pre_data_remain);
    }
    sdk_fs_close(gp_bak_temp_fs);
    gp_bak_temp_fs = NULL;
    
    if (inside_calc_crc != external_calc_crc)
    {
        ret = -1;
    }
    else
    {
        if (bak_file_type == FILE_TYPE_CORE)
        {
            
            sdk_fs_rename(TEMP_BACKUP_FILE, CORE_BACKUP_FILE);
            log_d("[upg]CreatCoreBackSuccess\n");
            gp_bak_temp_fs = sdk_fs_open(CORE_BACKUP_FILE, FS_READ);
            back_size = sdk_fs_get_size(gp_bak_temp_fs);
            sdk_fs_close(gp_bak_temp_fs);
            gp_bak_temp_fs = NULL;
            log_i("[upg]coreBackSize=%d\n",back_size / 1024);
        }
        else if (bak_file_type == FILE_TYPE_APP)
        {
            sdk_fs_rename(TEMP_BACKUP_FILE, APP_BACKUP_FILE);
            log_d("creatAppBackSuccess\n");
            gp_bak_temp_fs = sdk_fs_open(APP_BACKUP_FILE, FS_READ);
            back_size = sdk_fs_get_size(gp_bak_temp_fs);
            sdk_fs_close(gp_bak_temp_fs);
            gp_bak_temp_fs = NULL;
            log_i("[upg]appBackSize=%d\n",back_size / 1024);
        }    
    }
    
    return ret;
err_exit:
    sdk_fs_close(gp_bak_temp_fs);
    gp_bak_temp_fs = NULL;
    return ret;
}

/**********************************************3ph升级任务start*************************************************************/

#ifdef UPD_3PH_FLAG
/*************************************接收3PH升级报文校验相关函数*************************************************/
/**
* @brief        校验函数
* @param        无
* @return        无
* @retval        无
* @pre            无
*/
static void invert_uint8(uint8_t* p_dst_buf, uint8_t* p_src_buf)
{
    uint32_t i;
    uint8_t     temp = 0;

    for (i = 0; i < 8; i++)
    {
        if (p_src_buf[0] & (1 << i))
        {
            temp |= 1 << (7 - i);
        }
    }
    p_dst_buf[0] = temp;
}
static void invert_uint16(uint16_t* p_dst_buf, uint16_t* p_src_buf)
{
    uint32_t i;
    uint16_t temp = 0;

    for (i = 0; i < 16; i++)
    {
        if (p_src_buf[0] & (1 << i))
        {
            temp |= 1 << (15 - i);
        }
    }
    p_dst_buf[0] = temp;
}

uint16_t crc16_ccitt(uint8_t* p_src_data, uint32_t src_data_size)
{
    uint16_t w_crc_in = 0x0000;
    uint16_t w_crc_poly = 0x1021;
    uint8_t  w_char = 0;

    while (src_data_size--)
    {
        w_char = *(p_src_data++);
        invert_uint8(&w_char, &w_char);
        w_crc_in ^= (w_char << 8);

        for (int i = 0; i < 8; i++)
        {
            if (w_crc_in & 0x8000)
            {
                w_crc_in = (w_crc_in << 1) ^ w_crc_poly;
            }
            else
            {
                w_crc_in = w_crc_in << 1;
            }
        }
    }
    invert_uint16(&w_crc_in, &w_crc_in);

    return (w_crc_in);
}

/*************************************接收3PH升级报文相关处理函数*************************************************/

/**
* @brief        回复id:07FBXXXX报文
* @param        [in] p_file_data:CAN报文
* @return        执行结果
* @retval        无
* @pre            无
*/
static int32_t reply_file_info(void)
{
    int32_t ret = 0;

    can_frame_id_u fram_id_t = {0};
    sdk_can_frame_t txframe_t = {0};

    fram_id_t.bit.src_addr = auto_addressing_get_address() - ADDR_CONVERT;
    fram_id_t.bit.src_type = DEV_BMU; 
    fram_id_t.bit.dst_addr = g_upg_proc_para.src_addr;
    fram_id_t.bit.dst_type = g_upg_proc_para.src_dev_type;
    fram_id_t.bit.prio = SOFAR_CAN_PRI_HIGH_H;
    fram_id_t.bit.fun_code = FUNC_DOWN_FILE_START;
    
    txframe_t.ide = 1;
    txframe_t.len = 8;
    txframe_t.id = fram_id_t.id_val;
    txframe_t.data[0] = 0x01;// 应答回复
    txframe_t.data[1] = 0x01;// 准备就绪
    txframe_t.data[6] = (uint8_t)upgrade_data_info.block_size;
    txframe_t.data[7] = (uint8_t)(upgrade_data_info.block_size>>8);    
    txframe_t.id = fram_id_t.id_val;
    log_d("[upg]file info reply,id:%x\n",txframe_t.id);
    ret = sdk_can_write(SDK_INTERNAL_CAN_PORT , &txframe_t, 1);    
    
    return ret;

}

/**
* @brief        回复id:07FCXXXX报文
* @param        [in] p_file_data:CAN报文
* @return        执行结果
* @retval        无
* @pre            无
*/
static int32_t reply_block_start(uint32_t relpy_flag)
{
    int32_t ret = 0;
    can_frame_id_u fram_id_t = {0};
    sdk_can_frame_t txframe_t = {0};

    fram_id_t.bit.src_addr = auto_addressing_get_address() - ADDR_CONVERT;
    fram_id_t.bit.src_type = DEV_BMU; 
    fram_id_t.bit.dst_addr = g_upg_proc_para.src_addr;
    fram_id_t.bit.dst_type = g_upg_proc_para.src_dev_type;
    fram_id_t.bit.prio = SOFAR_CAN_PRI_HIGH_H;
    fram_id_t.bit.fun_code = FUNC_DOWN_FILE_DATA_BLOCK_START;

    txframe_t.ide = 1;
    txframe_t.len = 8;
    txframe_t.id = fram_id_t.id_val;
    txframe_t.data[0] = 0x01;// 应答回复
    txframe_t.data[1] = relpy_flag;// 准备就绪
    //log_d("[upg]block start reply,id:%x\n",txframe_t.id);
    ret = sdk_can_write(SDK_INTERNAL_CAN_PORT , &txframe_t, 1);        
    return ret;
}

/**
* @brief        回复id:07FEXXXX报文
* @param        [in] p_file_data:CAN报文
* @return        执行结果
* @retval        无
* @pre            无
*/
static int32_t reply_file_check(uint8_t *tans_fail)
{
    uint8_t group_cnt = 0;
    uint8_t transmit_fail = false;
    int32_t ret = 0;
    can_frame_id_u fram_id_t = {0};
    sdk_can_frame_t txframe_t = {0};

    fram_id_t.bit.src_addr = auto_addressing_get_address() - ADDR_CONVERT;
    fram_id_t.bit.src_type = DEV_BMU; 
    fram_id_t.bit.dst_addr = g_upg_proc_para.src_addr;
    fram_id_t.bit.dst_type = g_upg_proc_para.src_dev_type;
    fram_id_t.bit.prio = SOFAR_CAN_PRI_HIGH_H;
    fram_id_t.bit.fun_code = FUNC_DOWN_FILE_RESULT_CHECK;

    txframe_t.ide = 1;
    txframe_t.len = 8;
    txframe_t.id = fram_id_t.id_val;

    for (group_cnt = 0; group_cnt < TRANSMIT_GROUP; group_cnt++)// 回复需要补包的位置
    {
        if (0 != (~g_transmit_bit_mask[group_cnt]))
        {
            transmit_fail = true;
            break;
        }
    }

    txframe_t.data[0] = 0x01;
#ifdef UPG_TT
    txframe_t.data[2] = T_CHIP_MODEL_0;
    txframe_t.data[3] = T_CHIP_MODEL_1;
#else
    txframe_t.data[2] = CHIP_MODEL_0;
    txframe_t.data[3] = CHIP_MODEL_1;
#endif


    if (true == transmit_fail)
    {
        txframe_t.data[1] = 1;// 需要补包
        txframe_t.data[4] = group_cnt;
        txframe_t.data[5] = (uint8_t)~(g_transmit_bit_mask[group_cnt] >> 0);
        txframe_t.data[6] = (uint8_t)~(g_transmit_bit_mask[group_cnt] >> 8);
        txframe_t.data[7] = (uint8_t)~(g_transmit_bit_mask[group_cnt] >> 16);
    }
    else
    {
        txframe_t.data[1] = 0;// 接收成功
        txframe_t.data[4] = 0;
        txframe_t.data[5] = 0;
        txframe_t.data[6] = 0;
        txframe_t.data[7] = 0;
    }

    *tans_fail = transmit_fail;
    ret = sdk_can_write(SDK_INTERNAL_CAN_PORT , &txframe_t, 1);
    log_d("[upg]file check reply:%d,id:%x,data:%x,%x,%x,%x,%x,%x,%x,%x\n",transmit_fail,txframe_t.id,txframe_t.data[0],txframe_t.data[1],txframe_t.data[2],txframe_t.data[3],txframe_t.data[4],txframe_t.data[5],txframe_t.data[6],txframe_t.data[7]);
    return ret;
}

/**
* @brief        回复id:07FFXXXX报文
* @param        [in] p_file_data:CAN报文
* @return        执行结果
* @retval        无
* @pre            无
*/
static int32_t reply_file_end(void)
{
    int32_t ret = 0;
    can_frame_id_u fram_id_t = {0};
    sdk_can_frame_t txframe_t = {0};
    static uint8_t pre_stus = UPG_INVALID_MASK,predata = 0;

    fram_id_t.bit.src_addr = auto_addressing_get_address() - ADDR_CONVERT;
    fram_id_t.bit.src_type = DEV_BMU;
    if(g_upg_proc_para.src_addr != 0)
    {
        fram_id_t.bit.dst_addr = g_upg_proc_para.src_addr;
    }
    else
    {
        fram_id_t.bit.dst_addr = BCU_INNER_CAN_ADDR;
    }
    
    if(g_upg_proc_para.src_dev_type != 0)
    {
        fram_id_t.bit.dst_type = g_upg_proc_para.src_dev_type;        
    }
    else
    {
        fram_id_t.bit.dst_type = DEV_BCU;
    }
    
    fram_id_t.bit.prio = SOFAR_CAN_PRI_HIGH_H;
    fram_id_t.bit.fun_code = FUNC_DOWN_FILE_FINISH_QUERY;

    txframe_t.ide = 1;
    txframe_t.len = 8;
    txframe_t.id = fram_id_t.id_val;
    txframe_t.data[0] = 0x01;    //应答回复
    txframe_t.data[1] = g_upg_proc_para.upgrade_success_flag; //0:成功, 1:文件校验失败, 2: 其他原因  
    txframe_t.data[2] = upgrade_flash_para.save_fw_file_flag;
    ret = sdk_can_write(SDK_INTERNAL_CAN_PORT , &txframe_t, 1);

    if((pre_stus != g_upg_proc_para.upgrade_success_flag)
        || predata != txframe_t.data[1])
    {
        pre_stus = g_upg_proc_para.upgrade_success_flag;
        predata = txframe_t.data[1];
        log_i("[upg]reply_file_end,flag:%d,[1]:%d\r\n",g_upg_proc_para.upgrade_success_flag,txframe_t.data[1]);
    }

    return ret;
}

static int32_t upgrade_timing_time_ext_master(can_frame_data_t *frame_data)
{
    if (frame_data == NULL)
    {
        return -1;
    }
    if (frame_data->data_len < 8)
    {
        return -2;
    }
    can_frame_id_u frame_rx_id = {.id_val = frame_data->id};
    log_i("[upg]upd timing dst=%d, type=%d\r\n", frame_rx_id.bit.dst_addr, frame_rx_id.bit.dst_type);
    if ((g_upg_proc_para.src_addr != frame_rx_id.bit.src_addr) || (g_upg_proc_para.src_dev_type != frame_rx_id.bit.src_type))
    {
        return -1;
    }
    uint8_t crc_value = 0;
    int32_t ret = 0;
    uint8_t temp_buff[11] = { 0 };
#if UPGRADE_DEBUG_ENABLE    
    sdk_rtc_t test = { 0 };
#endif
    temp_buff[0] = (uint8_t)(frame_rx_id.id_val >> 24);
    temp_buff[1] = (uint8_t)(frame_rx_id.id_val >> 16);
    temp_buff[2] = (uint8_t)(frame_rx_id.id_val >> 8);
    temp_buff[3] = (uint8_t)(frame_rx_id.id_val >> 0);

    for (int i = 0; i < 7; i++)
    {
        temp_buff[4 + i] = frame_data->data[i];
    }
    crc_value = crc8_ccitt(temp_buff, sizeof(temp_buff));
    if ((crc_value == frame_data->data[7])
        && (0xAA == frame_data->data[6]))
    {
        // ret = sdk_iap_set_flag(IAP_BACK_BACK);

        // reply_system_reset(ret);
        // if (0 == ret)
        // {
        //     g_boot_upgrade_flag = 1;// boot升级标志成功                
        // }
        // else
        // {
        //     g_boot_upgrade_flag = 0;// boot升级标志失败
        // }
        log_i("g_boot_upgrade_flag : %d \r\n", g_boot_upgrade_flag);
    }
    else
    {
        upgrade_flash_para.count_down_time.tm_year = frame_data->data[0];
        upgrade_flash_para.count_down_time.tm_mon = frame_data->data[1];
        upgrade_flash_para.count_down_time.tm_day = frame_data->data[2];
        upgrade_flash_para.count_down_time.tm_hour = frame_data->data[3];
        upgrade_flash_para.count_down_time.tm_min = frame_data->data[4];
        upgrade_flash_para.count_down_time.tm_sec = frame_data->data[5];
        upgrade_flash_para.count_down_time.tm_weekday = 0x00;
        //定时时间
        ret = sdk_para_write(IAP_PARA, ST_VAR_POS(upgrade_flash_para_t, count_down_time),
            (uint8_t*)&upgrade_flash_para.count_down_time, ST_VAR_SIZE(upgrade_flash_para_t, count_down_time));
        if (0 == ret)
        {
            sdk_para_sync(IAP_PARA);
#if UPGRADE_DEBUG_ENABLE
            sdk_para_read(IAP_PARA, ST_VAR_POS(upgrade_flash_para_t, count_down_time),
                (uint8_t*)&test, ST_VAR_SIZE(upgrade_flash_para_t, count_down_time));
            log_i("[upg]hour:%d min:%d sec:%d\n", test.tm_hour, test.tm_min, test.tm_sec);
#endif
            // reply_timing_time();
        }
    }

    return ret;
}

#define rcv_7fb_suc        6
static int32_t upgrade_file_info_ext_master(can_frame_data_t *frame_data)
{
    if (NULL == frame_data)
    {
        return -1;
    }
    if (frame_data->data_len < 8)
    {
        return -2;
    }
    if (frame_data->data[0] != 0) // 不为请求帧退出
    {
        return -3;
    }
    can_frame_id_u frame_rx_id = {.id_val = frame_data->id};
    log_i("[upg]start msg src=%d,type=%d,dst=%#x\n", frame_rx_id.bit.src_addr, frame_rx_id.bit.src_type, frame_data->data[1]);
#ifdef UPG_TT
    frame_data->data[1] = CHIP_ROLE_BMS_APP;
    frame_data->data[2] = CHIP_MODEL_0;
    frame_data->data[3] = CHIP_MODEL_1;
#endif
    // 升级启动防呆校验通，Byte0:发送请求帧，Byte1:芯片角色 0x24为BMS，Byte2\3：芯片型号编码 E0，Byte4\5:文件数据块总数，Byte6\7:数据块总大小
    if ((CHIP_ROLE_BMS_APP == frame_data->data[1])
        && CHIP_MODEL_0 == frame_data->data[2] && CHIP_MODEL_1 == frame_data->data[3])
    {
        // 主要为了解决在升级启动状态下反复收到升级启动帧，导致清除数据，升级异常问题
        if (g_upgrade_fsm.cur_state != UPG_FILE_INFO)
        {
            memset(&upgrade_data_info, 0, sizeof(upgrade_data_info));
            memset(&upgrade_data_info_tmp, 0, sizeof(upgrade_data_info));
            upgrade_data_info.block_upgrade_data = g_tmp_buf_1;
            upgrade_data_info_tmp.block_upgrade_data = g_tmp_buf_2;
            memset(&g_upg_proc_para, 0, sizeof(g_upg_proc_para));
            //if(++g_rcv_7fb_cnt >= rcv_7fb_suc)
            {
//                g_rcv_7fb_cnt = 0;
                g_upg_proc_para.start_flag = true;
            }
        }
        g_upg_proc_para.upg_start_flag = true;
        g_upg_proc_para.src_addr = frame_rx_id.bit.src_addr;
        g_upg_proc_para.src_dev_type = frame_rx_id.bit.src_type;
        g_upg_proc_para.chip_role = frame_data->data[1];
        upgrade_data_info.block_size = ((uint16_t)frame_data->data[6] | (uint16_t)frame_data->data[7] << 8);
#ifdef UPG_TT
        upgrade_data_info.block_total_num = ((uint16_t)frame_data->data[4] | (uint16_t)frame_data->data[5] << 8) + 1;
#else
        upgrade_data_info.block_total_num = ((uint16_t)frame_data->data[4] | (uint16_t)frame_data->data[5] << 8);  // 为了适配bts5k的升级数据，为最大帧块id(从0开始)
#endif
        if (g_upg_proc_para.first_reply_start_flag)
        {
            reply_file_info();
        }
    }
    log_d("[upg]chip role:%X, CHIP_MODEL_0:%x, CHIP_MODEL_1:%x, block size:%d, total num:%d\n", frame_data->data[1], frame_data->data[2], frame_data->data[3],upgrade_data_info.block_size,upgrade_data_info.block_total_num);
    return 0;
}

static int32_t upgrade_block_data_start_ext_master(can_frame_data_t *frame_data)
{
    if (NULL == frame_data)
    {
        return -1;
    }
    if (frame_data->data_len < 8)
    {
        return -2;
    }
//    can_frame_id_u frame_rx_id = {.id_val = frame_data->id};
//    log_d("canid=x%lx\n", frame_rx_id.id_val);
//    log_d("DD[0]=%x,%x,%x,%x\n", frame_data->data[0], frame_data->data[1],frame_data->data[2],frame_data->data[3]);
//    log_d("DD[1]=%x,%x,%x,%x\n", frame_data->data[4], frame_data->data[5],frame_data->data[6],frame_data->data[7]);
    // Byte0:发送请求帧，Byte2\3:当前的数据块序号，Byte4\5:数据块大小，Byte6\7:数据块CRC
    if (0x00 == frame_data->data[0])
    {
        // 在复制数据完成前，不要更新数据
        if (g_upg_proc_para.write_block_state != UPG_WRITE_BLOCK_DATA_RECV_FINISH)
        {
            g_upg_proc_para.write_block_state = UPG_WRITE_BLOCK_DATA_START;
            upgrade_data_info_tmp.block_send_cnt = ((uint16_t)frame_data->data[2] | (uint16_t)frame_data->data[3] << 8);
            upgrade_data_info_tmp.block_data_len = ((uint16_t)frame_data->data[4] | (uint16_t)frame_data->data[5] << 8);
            upgrade_data_info_tmp.block_crc = ((uint16_t)frame_data->data[6] | (uint16_t)frame_data->data[7] << 8);
            upgrade_data_info_tmp.block_data_index = 0;
            g_upg_proc_para.block_data_info = true;
//            log_d("sta%d\n", upgrade_data_info_tmp.block_send_cnt);
        }
        else
        {
            log_i("[upd_bmu]Nosta%d\n", ((uint16_t)frame_data->data[2] | (uint16_t)frame_data->data[3] << 8));
        }
        reply_block_start(true);
    }
    else
    {
        upgrade_data_info_tmp.block_send_cnt = 0;
        upgrade_data_info_tmp.block_data_len = 0;
        upgrade_data_info_tmp.block_crc = 0;
        upgrade_data_info_tmp.block_data_index = 0;
    }
    //log_d("[upg]req:%d, block no:%d, size:%d, crc:%x\n",frame_data->data[0],upgrade_data_info_tmp.block_send_cnt,upgrade_data_info_tmp.block_data_len,upgrade_data_info_tmp.block_crc);    
    return 0;
}

static int32_t upgrade_block_data_ext_master(can_frame_data_t *frame_data)
{
    if (NULL == frame_data)
    {
        return -1;
    }
    can_frame_id_u frame_rx_id = {.id_val = frame_data->id};
    if ((g_upg_proc_para.src_addr != frame_rx_id.bit.src_addr) || (g_upg_proc_para.src_dev_type != frame_rx_id.bit.src_type))
    {
        return -1;
    }
    for (uint8_t i = 0; i < frame_data->data_len; i++)
    {
        if ((upgrade_data_info_tmp.block_data_index < BLOCK_MAX_DATA_SIZE) &&
            (upgrade_data_info_tmp.block_data_index < upgrade_data_info_tmp.block_data_len))
        {
            upgrade_data_info_tmp.block_upgrade_data[upgrade_data_info_tmp.block_data_index++] = frame_data->data[i];
        }
    }
    //说明接收完一个数据块的最后一帧且校验通过
    if (upgrade_data_info_tmp.block_data_len == upgrade_data_info_tmp.block_data_index &&
        g_upg_proc_para.block_data_info == true)
    {
        g_upg_proc_para.block_data_info = false;
        g_upg_proc_para.block_data_flag++;
        if (g_upg_proc_para.write_block_state == UPG_WRITE_BLOCK_DATA_START)
        {
            g_upg_proc_para.write_block_state = UPG_WRITE_BLOCK_DATA_RECV_FINISH;
        }
        else
        {
            log_i("Blk%dNoWriteOK%d\n", upgrade_data_info_tmp.block_send_cnt, g_upg_proc_para.write_block_state);
        }
    }
    return 0;
}
static int32_t upgrade_file_check_ext_master(can_frame_data_t *frame_data)
{
    //uint8_t tans_fail = false;
    
    if (NULL == frame_data)
    {
        return -1;
    }
    if (frame_data->data_len < 4)
    {
        return -2;
    }
    can_frame_id_u frame_rx_id = {.id_val = frame_data->id};
    log_i("[upg]check msg src=%d, type=%d\n", frame_rx_id.bit.src_addr, frame_rx_id.bit.src_type);
#ifdef UPG_TT
    frame_data->data[1] = CHIP_ROLE_BMS_APP;
    frame_data->data[2] = CHIP_MODEL_0;
    frame_data->data[3] = CHIP_MODEL_1;
#endif
    if ((g_upg_proc_para.src_addr != frame_rx_id.bit.src_addr) || (g_upg_proc_para.src_dev_type != frame_rx_id.bit.src_type))
    {
        return -1;
    }
    // Byte0:发送请求帧，Byte1:芯片角色 0x24为BMS，Byte2\3:芯片型号编码：E0，Byte4\5:文件数据块总数，Byte6\7:数据块大小
    if ((g_upg_proc_para.chip_role == frame_data->data[1]) && CHIP_MODEL_0 == frame_data->data[2] && CHIP_MODEL_1 == frame_data->data[3])
    {
        log_d("[upg]check start\n");    
        g_upg_proc_para.check_flag = true;
        uint8_t tail = 0;
        reply_file_check(&tail);
    }
    return 0;
}
static int32_t upgrade_file_end_ext_master(can_frame_data_t *frame_data)
{
    if (NULL == frame_data)
    {
        return -1;
    }
    if (frame_data->data_len < 6)
    {
        return -2;
    }
    can_frame_id_u frame_rx_id = {.id_val = frame_data->id};
    log_i("[upg]end msg src=%d, type=%d\n", frame_rx_id.bit.src_addr, frame_rx_id.bit.src_type);
    log_d("[upg]mode:%d,file type:%d\n", frame_data->data[4], frame_data->data[5]); // 没有此数据
    if (((g_upg_proc_para.src_addr != frame_rx_id.bit.src_addr) || (g_upg_proc_para.src_dev_type != frame_rx_id.bit.src_type))
        && (UPG_INVALID_MASK == g_upg_proc_para.upgrade_success_flag))
    {
        return -1;
    }
#ifdef UPG_TT
    frame_data->data[1] = CHIP_ROLE_BMS_APP;
    frame_data->data[2] = CHIP_MODEL_0;
    frame_data->data[3] = CHIP_MODEL_1;
#endif
    g_upg_proc_para.function_code_flag = UPG_FUN_QUERY;
    // Byte0:发送请求帧，Byte1:芯片角色 0x24为BMS，Byte2\3:芯片型号编码：E0，Byte4\5:文件数据块总数，Byte6\7:数据块大小
    if (((g_upg_proc_para.chip_role == frame_data->data[1]) && CHIP_MODEL_0 == frame_data->data[2] && CHIP_MODEL_1 == frame_data->data[3])
        || (UPG_INVALID_MASK != g_upg_proc_para.upgrade_success_flag)    //针对BCU升级成功重启后
        )        
    {
        g_upg_proc_para.function_code_flag = frame_data->data[4]; // 功能码
        
        g_upg_proc_para.upgrade_file_type_flag = frame_data->data[5]; // 接收文件类型编码
        //01 升级状态查询 02 启动升级 03 暂存升级 04 查询文件传输进度
        reply_file_end();
        g_upg_proc_para.end_flag = true;
    }
    return 0;
}
#endif

/**********************************************3ph升级任务end***************************************************************/
/******************************************预充状态机相关处理函数*******************************************************/
static uint8_t sta_upgrade_wait_start_entry(void)
{
    //g_upgrade_state = UPG_IDLE;
    g_upgrade_fsm_para.stat_cnt_time = sdk_tick_get();
    g_upg_proc_para.upd_type = UPD_TYPE_NONE;    //升级完成后这个需要重置
    g_flash_write_fail_cnt = 0;    //写flash失败计数
    return EVT_NULL;
}

static uint8_t sta_upgrade_wait_start_run(void)    //标志延时清除，用于给状态机复位以及回复逆变器升级成功/失败标志
{
    if (true == sdk_is_tick_over(g_upgrade_fsm_para.stat_cnt_time, os_tick_from_millisecond(15000)))
    {
	    if (g_upgrade_state != UPG_IDLE)
		{
            log_e("[upg]ClrFlag,L%d\n", g_upgrade_state);
		}
        g_upgrade_fsm_para.stat_cnt_time = sdk_tick_get();
        g_upgrade_state = UPG_IDLE;
        g_upg_proc_para.upgrade_success_flag = UPG_INVALID_MASK;    //因为0为升级完成，所以用FF作为无效值
    }
    
    return EVT_NULL;
}

static uint8_t sta_upgrade_file_info_entry(void)
{
    uint8_t event = EVT_NULL;

    log_i("[upg]Starting\n");
    g_upgrade_fsm_para.stat_cnt_time = sdk_tick_get();
    g_upgrade_fsm_para.stat_delay_cnt = 0;
    g_check_fw_file_size = 0;
    g_upgrade_state = UPG_ING;
	g_upg_proc_para.upgrade_success_flag = UPG_ING_MASK;	
	g_upg_proc_para.function_code_flag = UPG_FUN_QUERY; 

    memset(&upgrade_flash_para, 0, sizeof(upgrade_flash_para));
    sdk_para_write(IAP_PARA, 0, (uint8_t*)&upgrade_flash_para, sizeof(upgrade_flash_para));
    sdk_para_sync(IAP_PARA);

    // 清空传输成功的位置
    clear_all_transmit_success_bit_mask(upgrade_data_info.block_total_num);
    g_upg_proc_para.sure_clear_tarnsmit_bit_mask_flag = 1;
    sdk_fs_close(gp_fs);
    gp_fs = NULL;
    sdk_fs_remove(NEW_UPG_FILE);
    // 打开文件
    gp_fs = sdk_fs_open(NEW_UPG_FILE, FS_OPEN_ALWAYS | FS_WRITE | FS_READ);
    if (gp_fs == NULL)
    {
        log_i("[upg]OpenNewUpgradeFileFail\n"); 
        event = EVT_UPG_OPERATE_FAIL;
    }
    else
    {
        log_i("[upg]OpenNewUpgradeFileSuc\n");
    }

    g_upg_proc_para.first_reply_start_flag = true;
    reply_file_info();
    return event;
}
static uint8_t sta_upgrade_file_info_run(void)
{
    uint8_t event = EVT_NULL;
    if (g_upg_proc_para.upg_start_flag == true)
    {
        g_upgrade_fsm_para.stat_cnt_time = sdk_tick_get();
        if (++g_upgrade_fsm_para.stat_delay_cnt > 20)
        {
            log_i("[upg]WaitFirstBlockTimeOut\n");
            g_upgrade_fsm_para.stat_delay_cnt = 0;
            event = EVT_UPG_TIMEOUT_OR_ERR;
        }
        g_upg_proc_para.upg_start_flag = false;
    }
    if (true == sdk_is_tick_over(g_upgrade_fsm_para.stat_cnt_time, os_tick_from_millisecond(10000)))
    {
        g_upgrade_fsm_para.stat_cnt_time = sdk_tick_get();
        log_i("[upg]WaitFirstBlockTimeOut2\n");
        event = EVT_UPG_TIMEOUT_OR_ERR;
    }
    if ((g_upg_proc_para.first_reply_start_flag == true) && 
        ((g_upg_proc_para.block_data_flag > BLOCK_NULL) || (g_upg_proc_para.block_data_info == true)))
    {
        // upgrade_file_write_to_fs();
        // g_upg_proc_para.block_data_flag = false;
        // log_d("[upgrade] rcv first block suc\n");
        event = EVT_UPG_STA_CPL_SUS;
    }
    return event;
}
static uint8_t sta_upgrade_block_data_entry(void)
{
    log_i("[upg]RcvBlockStart\n");
    g_upgrade_fsm_para.stat_cnt_time = sdk_tick_get();
    return EVT_NULL;
}

static uint8_t sta_upgrade_block_data_run(void)
{
    uint8_t event = EVT_NULL;
    if (true == sdk_is_tick_over(g_upgrade_fsm_para.stat_cnt_time, os_tick_from_millisecond(10000)))
    {
        log_e("[upg]WaitNextBlockTimeout\n");
        g_upg_proc_para.block_data_flag = BLOCK_NULL;
        g_upg_proc_para.write_block_state = UPG_WRITE_BLOCK_DATA_IDLE;
        event = EVT_UPG_TIMEOUT_OR_ERR;
    }

    if (g_upg_proc_para.block_data_flag > BLOCK_NULL)
    {
        if (g_upg_proc_para.block_data_flag > BLOCK_TWO)    //当block计数大于2，说明block为2的数据已经丢了
        {
            log_w("[upg]lostBlock%dNum%d\n", upgrade_data_info_tmp.block_send_cnt, g_upg_proc_para.block_data_flag);
        }

        if(0 != upgrade_file_write_to_fs())
        {
            if(++g_flash_write_fail_cnt >= FLASH_WRITE_FAIL_TIME)
            {
                log_w("[upg]flashWriteErr,block%d\n", upgrade_data_info.block_send_cnt);
                g_flash_write_fail_cnt = FLASH_WRITE_FAIL_TIME;
                event = EVT_UPG_TIMEOUT_OR_ERR;
            }
        }
        else
        {
            g_flash_write_fail_cnt = 0;
        }

        g_upg_proc_para.block_data_flag--;
    }
    if (g_upg_proc_para.check_flag == true && g_upg_proc_para.write_block_state == UPG_WRITE_BLOCK_DATA_IDLE)
    {
        log_i("[upg]RcvFileCheckSuc\n");
        g_upg_proc_para.check_flag = false;
        event = EVT_UPG_STA_CPL_SUS;
    }
    return event;
}

static uint8_t sta_upgrade_file_check_entry(void)
{
    log_i("[upg]fileCheckStart\n");
    g_upgrade_fsm_para.stat_cnt_time = sdk_tick_get();
    g_upgrade_fsm_para.stat_delay_cnt = 0;
    return EVT_NULL;
}

static uint8_t sta_upgrade_file_check_run(void)
{
    uint8_t event = EVT_NULL;
    uint8_t tans_fail = false;
    if (g_upg_proc_para.check_flag == true)
    {
        g_upg_proc_para.check_flag = false;
        g_upgrade_fsm_para.stat_cnt_time = sdk_tick_get();
        if (++g_upgrade_fsm_para.stat_delay_cnt > 20)
        {
            g_upgrade_fsm_para.stat_delay_cnt = 0;
            log_e("[upg]CheckFileTimeout1\n");
            event = EVT_UPG_TIMEOUT_OR_ERR;
        }
        
    }
    if (true == sdk_is_tick_over(g_upgrade_fsm_para.stat_cnt_time, os_tick_from_millisecond(10000)))
    {
        g_upgrade_fsm_para.stat_cnt_time = sdk_tick_get();
        log_e("[upg]CheckFileTimeout2\n");
        event = EVT_UPG_TIMEOUT_OR_ERR;
    }
    //3ph同时回一帧
    for (uint8_t group_cnt = 0; group_cnt < TRANSMIT_GROUP; group_cnt++)// 回复需要补包的位置
    {
        if (0 != (~g_transmit_bit_mask[group_cnt]))
        {
            tans_fail = true;
            break;
        }
    }
    
    if (tans_fail == true)
    {
        log_e("[upgrade] file check fail\n");
        event =  EVT_UPG_OPERATE_FAIL;
    }
    else if (g_upg_proc_para.end_flag == true)
    {
        g_upg_proc_para.end_flag = false;
        log_i("[upg]fileCheckSuc\n");
        event =  EVT_UPG_STA_CPL_SUS;
    }
    
    return event;
}

static uint8_t sta_upgrade_file_end_entry(void)
{
    log_i("[upg]FileEndStart\n");
    g_upgrade_fsm_para.stat_cnt_time = sdk_tick_get();
    return EVT_NULL;
}

static uint8_t sta_upgrade_file_end_run(void)
{
    uint8_t event = EVT_NULL;
    uint8_t group_cnt;
    int32_t upg_same_ver_flag = 0;
    if ((UPG_FUN_START == g_upg_proc_para.function_code_flag) || (UPG_FUN_TEMP_STORAGE == g_upg_proc_para.function_code_flag))
    {
        if (1 == g_upg_proc_para.sure_clear_tarnsmit_bit_mask_flag)// 需要判断是否所有数据接收完成
        {
            for (group_cnt = 0; group_cnt < TRANSMIT_GROUP; group_cnt++)
            {
                if (0 != (~g_transmit_bit_mask[group_cnt]))
                {
                    g_upg_proc_para.upgrade_success_flag = UPG_OTHER_REASON_FAIL_MASK;
                    break;
                }
            }
        }
        // 文件校验
        if (upgrade_data_info.file_size == g_check_fw_file_size)
        {
            // 同版本抑制
            upg_same_ver_flag = upgrade_read_upgrde_ver_same_flag();
            if (upg_same_ver_flag == 1) // 相同版本
            {
                g_upg_proc_para.upgrade_success_flag = UPG_SUCCESS_MASK;
                log_i("[upg]VerSame\n");
                event = EVT_UPG_OPERATE_FAIL;
            }
            else if ((upg_same_ver_flag == 0) && (upgrade_check_upgrde_file_type() == 0)) // 不一样版本&&文件类型一致
            {
                sdk_fs_close(gp_fs);
                gp_fs = NULL;
                sdk_fs_remove(UPG_FILE_TYPE_APP_FLAG);
                sdk_fs_rename(NEW_UPG_FILE, UPG_FILE_TYPE_APP_FLAG);
                event = upgrade_cmd();
            }
            else
            {
                event = EVT_UPG_OPERATE_FAIL;
                sdk_fs_close(gp_fs);
                gp_fs = NULL;
                g_upg_proc_para.upgrade_success_flag = UPG_OTHER_REASON_FAIL_MASK;
            }
            log_i("[upg]BinFileEndCheckResEvt=%d\n", event);
        }
        else// 文件校验失败
        {
            sdk_fs_close(gp_fs);
            gp_fs = NULL;
            g_upg_proc_para.upgrade_success_flag = UPG_FILE_CRC_FAIL_MASK;
            event = EVT_UPG_TIMEOUT_OR_ERR;
            // reply_file_end();
            log_i("[upg]OtherFileEndCheckResEvt=%d\n", event);
        }
    }

    //此时自己已经接收完成了，可能有别的设备在补包，避免进入超时
    if (g_upg_proc_para.block_data_flag > BLOCK_NULL)    
    {
        g_upg_proc_para.block_data_flag = BLOCK_NULL;
        g_upg_proc_para.write_block_state = UPG_WRITE_BLOCK_DATA_IDLE;
        g_upgrade_fsm_para.stat_cnt_time = sdk_tick_get();
        log_i("[upg]OtherDevicesAreReceivingBlocks\n");
    }
    // 一切正常等待15s,进入升级结束状态，防止从机发送的回复报文，主机由于升级重启无法上送，CBS5000主机不转发从机升级报文，所以删除
    // 15S未收到升级完成状态查询帧，超时,因为存在其他包仍在补包而我已经进入这里
    if (true == sdk_is_tick_over(g_upgrade_fsm_para.stat_cnt_time, os_tick_from_millisecond(15000)))
    {
        log_w("[upg]FileEndCheckTimeOut\n");
        event = EVT_UPG_TIMEOUT_OR_ERR;
    }
    return event;
}
static uint8_t sta_upgrade_finish_run(void)
{
    log_i("[upg]Finish...\n");
    if (UPG_ERR == g_upgrade_state)
    {
        g_upgrade_state = UPG_IDLE;

        if (gp_fs != NULL)
        {
            sdk_fs_close(gp_fs);
            gp_fs = NULL;
            sdk_fs_remove(NEW_UPG_FILE);
        }
    }
    else
    {
        g_upgrade_state = UPG_FINISH;
    }
    g_upg_proc_para.sure_clear_tarnsmit_bit_mask_flag = 0;

    return EVT_UPG_STA_CPL_SUS;
}
static uint8_t sta_upgrade_error_entry(void)
{
    log_w("[upg]FailedStarting...\n");
    g_upgrade_fsm_para.stat_cnt_time = sdk_tick_get();
    return EVT_NULL;
}
static uint8_t sta_upgrade_error_run(void)
{
    uint8_t event = EVT_NULL;
    if (true == sdk_is_tick_over(g_upgrade_fsm_para.stat_cnt_time, os_tick_from_millisecond(20000)))
    {
        g_upgrade_state = UPG_ERR;
        event = EVT_UPG_STA_CPL_SUS;
    }
    if ((g_upg_proc_para.block_data_flag > BLOCK_NULL)
        && (g_flash_write_fail_cnt < FLASH_WRITE_FAIL_TIME))
    {
        event = EVT_UPG_BLOCK;
    }
    if (g_upg_proc_para.check_flag == true)
    {
        g_upg_proc_para.check_flag = false;
        event = EVT_UPG_CHECK;
    }
    if (g_upg_proc_para.end_flag == true)
    {
        g_upg_proc_para.end_flag = false;
        event = EVT_UPG_TEMPORARY;
    }
    return event;
}


/**
* @brief        外can升级相关函数注册
* @param        无
* @return        执行结果
* @retval        0： 注册成功
* @retval        -1：注册失败
* @pre            无
*/
static int32_t upgrade_external_can_register(void)
{
    int32_t ret = 0;
    uint16_t rcv_msg_amount = 0;
    can_frame_id_u frame_id[] = 
    {
        // res     prio(优先级), fun_code,    dst_type dst_addr, src_type, src_addr
        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_HIGH_H, .bit.fun_code= FUNC_DOWN_FILE_TIME,
         .bit.dst_type= DEV_BMU, .bit.dst_addr= 0, .bit.src_type= 0, .bit.src_addr =0}, // 0x7FA0000
        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_HIGH_H, .bit.fun_code= FUNC_DOWN_FILE_START,
         .bit.dst_type= DEV_BMU, .bit.dst_addr= 0, .bit.src_type= 0, .bit.src_addr =0}, // 0x7FB0000
        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_HIGH_H, .bit.fun_code= FUNC_DOWN_FILE_DATA_BLOCK_START,
         .bit.dst_type= DEV_BMU, .bit.dst_addr= 0, .bit.src_type= 0, .bit.src_addr =0}, // 0x7FC0000
        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_HIGH_H, .bit.fun_code= FUNC_DOWN_FILE_DATA_TRAN,
         .bit.dst_type= DEV_BMU, .bit.dst_addr= 0, .bit.src_type= 0, .bit.src_addr =0}, // 0x7FD0000
        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_HIGH_H, .bit.fun_code= FUNC_DOWN_FILE_RESULT_CHECK,
         .bit.dst_type= DEV_BMU, .bit.dst_addr= 0, .bit.src_type= 0, .bit.src_addr =0}, // 0x7FE0000
        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_HIGH_H, .bit.fun_code= FUNC_DOWN_FILE_FINISH_QUERY,
         .bit.dst_type= DEV_BMU, .bit.dst_addr= 0, .bit.src_type= 0, .bit.src_addr =0}, // 0x7FF0000
    };
    can_sofar_rcv_reg_t can_rxmsg_tab[] = // BCU接收上位机或PCS的数据
    {
        {.id = frame_id[0].id_val, .id_mask = 0x00001FFF, .p_can_cb = upgrade_timing_time_ext_master},   // 0x7FA0000
        {.id = frame_id[1].id_val, .id_mask = 0x00001FFF, .p_can_cb = upgrade_file_info_ext_master}, // 0x7FB0000
        {.id = frame_id[2].id_val, .id_mask = 0x00001FFF, .p_can_cb = upgrade_block_data_start_ext_master},  // 0x7FC0000
        {.id = frame_id[3].id_val, .id_mask = 0x00001FFF, .p_can_cb = upgrade_block_data_ext_master},    // 0x7FD0000
        {.id = frame_id[4].id_val, .id_mask = 0x00001FFF, .p_can_cb = upgrade_file_check_ext_master}, // 0x7FE0000
        {.id = frame_id[5].id_val, .id_mask = 0x00001FFF, .p_can_cb = upgrade_file_end_ext_master}, // 0x7FF0000
    };

    // 注册接收的数据
    rcv_msg_amount = sizeof(can_rxmsg_tab)/sizeof(can_sofar_rcv_reg_t);
    ret = inner_can_sofar_register_receive_frame(can_rxmsg_tab, rcv_msg_amount);

    return ret;
}
static uint8_t upgrade_state_chg_condition_check(void)
{
    uint8_t event = EVT_NULL;
    if (g_upg_proc_para.start_flag == true)
    {
        g_upg_proc_para.start_flag = false;
        event = EVT_UPG_START;
    }
    return event;   
}
/**
* @brief        升级流程
* @param        无
* @return        无
* @retval        无
* @pre            无
*/
static void upgrade_process(void)
{
    uint8_t event;
    event = upgrade_state_chg_condition_check();
    fsm_state_trans(&g_upgrade_fsm, event);
    event = state_machine_proc(&g_upgrade_fsm);
    fsm_state_trans(&g_upgrade_fsm, event);
}
/**
* @brief        软件复位
* @param        无
* @return        无
* @retval        无
* @pre            无
*/
static void upgrade_system_reset(void)
{
    log_i("[upg]Reset\n");
    g_upgrade_state = UPG_RESET;
}

/**
* @brief        读取固件签名信息中的升级文件版本号与当前版本是否一致
* @param        无
* @return        执行结果
* @retval        0： 不一致
* @retval        1： 一致
* @retval        -1：读失败
* @pre            无
*/
static int32_t upgrade_read_upgrde_ver_same_flag(void)
{
    int32_t fw_size = 0;// 升级固件文件大小
    int32_t fw_Point = 0;// 升级固件签名信息起始地址
    int32_t ret = 0;
    char str[FW_UPG_FILE_VER_LEN] = {0};
    int32_t same_flag = 0;

    // 获取文件大小
    fw_size = sdk_fs_get_size(gp_fs);
    if (fw_size < 0)
    {
        goto err_exit;
    }
    
    // 计算文件地址 最后一节1K是文件签名信息
    fw_Point = fw_size - 1024 * 1 + FW_UPG_FILE_VER_OFFSET_ADDR; // 版本号偏移地址
    // 移动文件读写地址
    ret = sdk_fs_lseek(gp_fs, fw_Point);
    if (ret != 0)
    {
#if UPGRADE_DEBUG_ENABLE
        log_w("[upg]fileVerSeekFai=%d...\n", ret);
#endif
        goto err_exit;
    }

    ret = sdk_fs_read(gp_fs, (uint8_t*)str, FW_UPG_FILE_VER_LEN);
    if (ret != FW_UPG_FILE_VER_LEN)
    {
#if UPGRADE_DEBUG_ENABLE
    log_i("[upg]fwUpgReadFileVerFail=%d\n", ret);
#endif    
        goto err_exit;
    }
    else
    {
        ret = 0;
    }
    if (memcmp(str, SOFTWARE_VERSION, strlen(SOFTWARE_VERSION)) == 0)
    {
        same_flag = 1;
    }
    else
    {
        bms_attr_t bms_data = {0};
        bms_data = *get_bms_attr();  
        memcpy(&bms_data.app_ver, str, sizeof(SOFTWARE_VERSION));
        data_store_save_bms_attr(ST_VAR_POS(bms_attr_t,app_ver), (uint8_t *)(bms_data.app_ver),ST_VAR_SIZE(bms_attr_t,app_ver) );
    }

#if UPGRADE_DEBUG_ENABLE
    log_i("[upg]fwUpgFileVerSame=%d %d\n", same_flag, ret);
#endif    
//    sdk_fs_close(gp_fs);
//    gp_fs = NULL;

    return same_flag;
err_exit:
    same_flag = -1;
    sdk_fs_close(gp_fs);
    gp_fs = NULL;
    sdk_fs_remove(NEW_UPG_FILE);
    log_d("[upg]fwUpgFileVerSame=%d %d,%s.%s\n", same_flag, ret, str, SOFTWARE_VERSION);
    return same_flag;
}

/**
* @brief        读取固件签名信息中的升级文件类型标志
* @param        无
* @return        执行结果
* @retval        0： 设置成功
* @retval        -1：设置失败
* @pre            无
*/
static int32_t upgrade_read_upgrde_file_type(void)
{
    int32_t fw_size = 0;// 升级固件文件大小
    int32_t fw_Point = 0;// 升级固件签名信息起始地址
    int32_t ret = 0;

    // 获取文件大小
    fw_size = sdk_fs_get_size(gp_fs);
    if (fw_size < 0)
    {
        goto err_exit;
    }
#if UPGRADE_DEBUG_ENABLE
    log_i("[upg]fw_size=%d...\n", fw_size);
#endif
    // 计算文件地址 最后一节1K是文件签名信息
    fw_Point = fw_size - 1024 * 1 + FW_UPG_FILE_TYPE_OFFSET_ADDR;
    // 移动文件读写地址
    ret = sdk_fs_lseek(gp_fs, fw_Point);
    if (ret != 0)
    {
#if UPGRADE_DEBUG_ENABLE
        log_w("[upg]sdk_fs_lseek failed=%d...\n", ret);
#endif
        goto err_exit;
    }
#if UPGRADE_DEBUG_ENABLE
    log_i("[upg]fwPoint=%d...\n", fw_Point);
#endif
    // 读取升级文件类型 
    ret = sdk_fs_read(gp_fs, (uint8_t*)&g_upg_proc_para.fw_upgrde_file_type_flag, sizeof(g_upg_proc_para.fw_upgrde_file_type_flag));
    if (ret != sizeof(g_upg_proc_para.fw_upgrde_file_type_flag))
    {
        goto err_exit;
    }
    else
    {
        ret = 0;
    }
#if UPGRADE_DEBUG_ENABLE
    log_i("[upg]fwUpgFileTypeFlag=%d...\n", g_upg_proc_para.fw_upgrde_file_type_flag);
#endif    
    sdk_fs_close(gp_fs);
    gp_fs = NULL;

    return ret;
err_exit:
    sdk_fs_close(gp_fs);
    gp_fs = NULL;
    sdk_fs_remove(NEW_UPG_FILE);

    return ret;
}
/**
* @brief        校验升级文件类型标志
* @param        无
* @return        执行结果
* @retval        0： 设置成功
* @retval        -1：设置失败
* @pre            无
*/
static int32_t upgrade_check_upgrde_file_type(void)
{
    int32_t ret = 0;
    // 读取固件签名信息中的升级文件类型标志
    ret = upgrade_read_upgrde_file_type();
    if (0 != ret)
    {
        return ret;
    }
    // 与上位机或逆变器发来的升级文件类型标志进行比较
    if (g_upg_proc_para.fw_upgrde_file_type_flag == g_upg_proc_para.upgrade_file_type_flag)
    {
        ret = 0;
    }
    else
    {
        ret = -1;
    }

    return ret;
}
/**
* @brief        接收固件完成后写升级文件类型标志
* @param        无
* @return        执行结果
* @retval        0： 设置成功
* @retval        -1：设置失败
* @pre            无
*/
static int32_t upgrade_write_file_type(void)
{
    int32_t ret = 0;
    static sdk_rtc_t current_rtc_time = { 0 };
    static uint8_t init_flag = 0;
    static uint32_t count_ms = 0;
#if UPGRADE_DEBUG_ENABLE
    uint8_t set_flag = 0xFF;
    int32_t fw_size = 0;
#endif
    if (0 == init_flag)
    {
        count_ms = sdk_tick_get();
        init_flag++;
    }
    // 启用定时器升级
    if (1 == upgrade_flash_para.timing_flag)
    {
        if (true == sdk_is_tick_over(count_ms, os_tick_from_millisecond(1000)))//每1s获取rtc
        {
            count_ms = sdk_tick_get();

            sdk_rtc_get(RTC_BIN_FORMAT, &current_rtc_time);

            if ((current_rtc_time.tm_year >= upgrade_flash_para.count_down_time.tm_year)
                && (current_rtc_time.tm_mon >= upgrade_flash_para.count_down_time.tm_mon)
                && (current_rtc_time.tm_day >= upgrade_flash_para.count_down_time.tm_day)
                && (current_rtc_time.tm_hour >= upgrade_flash_para.count_down_time.tm_hour)
                && (current_rtc_time.tm_min >= upgrade_flash_para.count_down_time.tm_min)
                && (current_rtc_time.tm_sec >= upgrade_flash_para.count_down_time.tm_sec))// 与定时器时间进行比较
            {

                memset(&upgrade_flash_para, 0, sizeof(upgrade_flash_para));
                sdk_para_write(IAP_PARA, 0, (uint8_t*)&upgrade_flash_para, sizeof(upgrade_flash_para));
                sdk_para_sync(IAP_PARA);
                g_upgrade_state = UPG_FINISH;
            }
        }
    }

    if (UPG_FINISH == g_upgrade_state)// 升级结束状态
    {
        // 打开App文件
        gp_fs = sdk_fs_open(UPG_FILE_TYPE_APP_FLAG, FS_READ);// 防止掉电后文件损坏
        if (gp_fs != NULL)
        {
#if UPGRADE_DEBUG_ENABLE
            log_d("[upg]OpenAppFileSuccess...\n");
            // 获取文件大小
            fw_size = sdk_fs_get_size(gp_fs);
            if (fw_size < 0)
            {
                log_w("[upg]AppFwSizeGetFailed...\n");

            }
            log_i("[upg]AppFwSize=%d...\n", fw_size);
#endif
            sdk_fs_close(gp_fs);
            gp_fs = NULL;
        }
        g_upg_proc_para.upd_type = UPD_TYPE_NONE;    //标志重置
        sdk_fs_remove(NEW_UPG_FILE);

        ret = sdk_iap_set_flag(IAP_APP_UPGRADE);
        if (0 == ret)
        {
#if UPGRADE_DEBUG_ENABLE                    
            set_flag = sdk_iap_read_flag();
            if (set_flag == IAP_APP_UPGRADE)
            {
                log_i("[upg]SetUpgFlag=App\n");
                log_d("upgAppStart...\n");
            }
#endif
            //    重新启动
            upgrade_system_reset();
        }
        else
        {
            return ret;
        }
    }
    else
    {
        //未进行升级
    }
    return ret;
}
/**
* @brief        app运行成功后设置升级成功标志和备份文件
* @param        无
* @return        执行结果
* @retval        0： 设置成功
* @retval        -1：设置失败
* @pre            无
*/
static int32_t upgrade_app_run_success(void)
{
    int32_t ret = 0;

    if (IAP_FINISH == sdk_iap_read_flag())// 未升级状态下正常运行app后，仅执行该语句
    {
#if UPGRADE_DEBUG_ENABLE
        log_i("[upg]appVer:%s startSucWithoutUpgrading\r\n", &SOFTWARE_VERSION[0]);
#endif
    }

    else
    {
        bms_attr_t bms_data = {0};
        bms_data = *get_bms_attr();

        if (IAP_BACK_APP == sdk_iap_read_flag())// 成功同时升级core、app文件
        {
            ret = sdk_iap_set_flag(IAP_FINISH);

            if (0 == ret)
            {
                if ((0 == memcmp(&bms_data.app_ver, &SOFTWARE_VERSION, sizeof(SOFTWARE_VERSION))))
                {
                    g_upg_proc_para.upgrade_success_flag = UPG_SUCCESS_MASK;
                    // bms_runing_data_deal(bms_data,true);
                    // reply_file_end();
                    sdk_fs_remove(APP_BACKUP_FILE);
                    sdk_fs_rename(UPG_FILE_TYPE_APP_FLAG, APP_BACKUP_FILE); // 保存comb备份文件
                    log_i("[upg]AppUpgSuc!!\n");
                }
                else
                {
                    sdk_fs_remove(APP_BACKUP_FILE);
                    g_upg_proc_para.upgrade_success_flag = UPG_OTHER_REASON_FAIL_MASK;
                    log_i("[upg]AppUpgFail\n");
                }

#if UPGRADE_DEBUG_ENABLE
                log_i("[upg]UpgAppRunSuccess-AppSuccess...!!!\n");
                log_d("id: %d...\n", auto_addressing_get_address());
#endif
            }
            else
            {
                return ret;
            }

        }
        else if (IAP_BACK_BACK == sdk_iap_read_flag())// 成功升级备份文件
        {
            ret = sdk_iap_set_flag(IAP_FINISH);

            if (0 == ret)
            {
#if UPGRADE_DEBUG_ENABLE
                log_i("[upg]UpgAppRunSuccess-BakSuccess...!!!\n");
                log_d("id: %d...\n", auto_addressing_get_address());
#endif
            }
            else
            {
                return ret;
            }
        }
        else
        {// boot校验升级文件信息失败或首次上电
            sdk_iap_set_flag(IAP_FINISH);
            sdk_fs_remove(UPG_FILE_TYPE_APP_FLAG);
        }
    }

    return ret;
}
/**
* @brief        升级模块参数初始化
* @param        无
* @return        无
* @retval        无
* @pre            无
*/
void upgrade_init(void)
{
    g_check_fw_file_size = 0;
    memset(g_transmit_bit_mask, 0, sizeof(g_transmit_bit_mask));
    memset(&g_upg_proc_para, 0, sizeof(g_upg_proc_para));
    memset(&upgrade_data_info, 0, sizeof(upgrade_data_info));
    memset(&upgrade_data_info_tmp, 0, sizeof(upgrade_data_info));
    upgrade_data_info.block_upgrade_data = g_tmp_buf_1;
    upgrade_data_info_tmp.block_upgrade_data = g_tmp_buf_2;    
    g_upg_proc_para.upgrade_success_flag = UPG_INVALID_MASK;    //因为0为升级完成，所以用FF作为无效值
    state_machine_init(&g_upgrade_fsm, upgrade_fsm_name, g_upgrade_act_map, (uint8_t *)g_upgrade_evt_sta_map,
        UPG_EVT_NUM, UPG_STA_NUM, UPG_WAIT_START);
    upgrade_external_can_register();
    sdk_para_init(IAP_PARA, sizeof(upgrade_flash_para));// 开机读取flash的升级参数数据
    sdk_para_read(IAP_PARA, 0, (uint8_t*)&upgrade_flash_para, sizeof(upgrade_flash_para));
    upgrade_enable_state_set(true);
}

/**
* @brief        升级任务
* @param        无
* @return        无
* @retval        无
* @pre            无
*/
void upgrade_task_proc(void)
{
    static uint8_t g_use_once_flag = 0;
    if (upgrade_enable_state_get())    // 判断是否允许升级
    {
        upgrade_process();            // 升级流程
        upgrade_write_file_type();    // 升级流程完成后写升级文件类型标志
        if (app_run_success_flag_get() && (0 == g_use_once_flag))
        {
            upgrade_app_run_success();    // app运行成功后写升级成功标志，仅需执行一次
            g_use_once_flag++;
        }
    }
}
/**
* @brief        获取升级状态
* @param        无
* @return        执行结果
* @retval        升级状态
* @pre            无
*/
uint8_t upgrade_state_get(void)
{
    return g_upgrade_state;
}
/**
* @brief        获取boot升级标志
* @param        无
* @return        执行结果
* @retval        boot升级标志
* @pre            无
*/
uint8_t boot_upgrade_flag_get(void)
{
    return g_boot_upgrade_flag;
}
/**
* @brief        设置使能升级标志
* @param        [in]使能标志： 0：不使能    1：使能  
* @return        无
* @retval        0：操作成功    < 0: 操作失败
* @pre            无
*/
int32_t upgrade_enable_state_set(uint8_t flag)
{
    int32_t ret = 0;

    if(false == flag)
    {
        g_upgrade_enable_flag = false;
    }
    else if(true == flag)
    {
        g_upgrade_enable_flag = true;
    }
    else
    {
        ret = -1;
    }
    return ret;
}

/**
* @brief        获取使能升级标志
* @param        无
* @return        执行结果
* @retval        使能升级标志
* @pre            无
*/
static uint8_t upgrade_enable_state_get(void)
{
    return g_upgrade_enable_flag;
}
