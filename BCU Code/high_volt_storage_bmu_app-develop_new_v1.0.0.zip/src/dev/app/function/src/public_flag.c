#include "public_flag.h"
#include "sdk.h"
#include "fault_manage.h"
#include "bmu_data.h"
#include "sox_public.h"
#include "bms_state.h"
#include "sofar_can_data.h"
#include "data_store.h"
#include "ate.h"

#define PUBLIC_FLAG_LOGD(...)	log_d(__VA_ARGS__)

#if PUBLIC_FLAG_SHELL_DEBUG_FLAG
static uint8_t g_public_flag_shell_debug_flag = false;
#endif

static uint64_t 		        g_public_flag_state = 0;			// 标志状态，位操作， bit=0(未置位) bit=1(置位)
static bmu_data_t*	        	gp_bmu_data = NULL;					// bms实时数据指针 用来做数据判断
static uint8_t 					g_bmu_flag_check_enable = false;
static uint8_t					g_bmu_cut_off_request = false;
static uint8_t 					g_bmu_pow_off_request = false;

typedef bool(*public_flag_callback)(public_flag_type_e, bool);
static uint16_t g_public_flag_cnt[PUBLIC_FLAG_NUM_MAX] = {0};

/**
 * @struct   fault_para_tab_t
 * @brief  故障参数表结构定义
 */
typedef struct 
{
    public_flag_type_e   public_type;             ///< 公用标志类型
    uint16_t             appear_cnt;              ///< 公用标志出现持续的次数
    uint16_t             cancel_cnt;              ///< 公用标志消失持续的次数
    public_flag_callback  p_public_flag_cb;       ///< 注册的回调函数
} public_flag_tab_t;

// 公用标志回调函数
static bool public_flag_charge_full_check(public_flag_type_e type, bool is_birth);
static bool public_flag_discharge_empty_check(public_flag_type_e type, bool is_birth);
static bool public_flag_force_charge_check(public_flag_type_e type, bool is_birth);
static bool public_flag_recv_charge_full_check(public_flag_type_e type, bool is_birth);
static bool public_flag_recv_discharge_empty_check(public_flag_type_e type, bool is_birth);

/**
  * @struct   g_public_flag_tab
  * @brief    公用标志表
  */
const static public_flag_tab_t g_public_flag_tab[] =
{
    // 公用标志类型     -----产生时间 -------- 消失时间      -- 回调函数
    //                        （n*扫描周期10ms)
   {CHG_FULL_FLAG,            100,             500,          public_flag_charge_full_check           },
   {DISCHG_EMPTY_FLAG,        100,             100,          public_flag_discharge_empty_check       },
   {FORCE_CHG_FLAG,           1000,            100,          public_flag_force_charge_check          },
   {RECV_CHG_FULL_FLAG,       50,              50,           public_flag_recv_charge_full_check      },
   {RECV_DISCHG_EMPTY_FLAG,   50,              50,           public_flag_recv_discharge_empty_check  },
};

/**
* @brief        标志置位
* @param        [in] flag_type 标志类型
* @param        [in] cmd 设置命令
* -# 0x00 - false
* -# 0x01 - true
* @retval        0 成功a
* @retval        -1 失败
*/
static int32_t public_flag_state_set(public_flag_type_e flag_type, uint8_t cmd)
{
    if ((PUBLIC_FLAG_NUM_MAX <= flag_type) || ((true != cmd) && (false != cmd)))
    {
        PUBLIC_FLAG_LOGD("[%s] input para err!\r\n", __FUNCTION__);
        return -1;
    }

    if (true == cmd)
    {
        SET_BIT(g_public_flag_state, (1ULL << flag_type));
    }
    else
    {
        CLR_BIT(g_public_flag_state, (1ULL << flag_type));
    }
    return 0;
}

/**
* @brief        相关标志状态获取
* @param        [in] flag_type 故障类型
* @retval        true  置位
* @retval        false 未置位
* @retval        -1 查询失败
*/
int32_t public_flag_state_get(public_flag_type_e flag_type)
{
    if (PUBLIC_FLAG_NUM_MAX <= flag_type)
    {
        PUBLIC_FLAG_LOGD("[%s] input para err!\r\n", __FUNCTION__);
        return -1;
    }

    if (0 == GET_BIT(g_public_flag_state, (1ULL << flag_type)))
    {
        return false;
    }
    else
    {
        return true;
    }
}

/**
 * @brief        满充标志判断
 */
static bool public_flag_charge_full_check(public_flag_type_e type, bool is_birth)
{
    bool result = false;
    if (U16_INVALID_VALUE == gp_bmu_data->max_cell_volt ||
        fault_state_get(BOARD_CELL_VOLT_WIRE_ABNORMAL_FAULT))
    {
        return false;
    }
    if (is_birth)
    {
        /* 标志触发:满冲标志产生：最大单体电压 >= 3.55V(2.0加50mV) */
        if (gp_bmu_data->max_cell_volt >= CELL_FULL_CHG_VOL)
        {
            result = true;
        }
    }
    else
    {
        const sox_data_t* sox_data = sox_data_get_deal();
        /* 满充标志消失：最大单体电压 < 3.38V 或 (soc < 99.6% 且 最大单体电压 < 3.55V(2.0加50mV)) */
        if (((gp_bmu_data->max_cell_volt < 3380) ||
            ((NULL != sox_data) && (sox_data->calc_soc < 99600) && (gp_bmu_data->max_cell_volt < CELL_FULL_CHG_VOL))))
        {
            result = true;
        }
    }
    return result;
}

/**
 * @brief        放亏标志判断
 */
static bool public_flag_discharge_empty_check(public_flag_type_e type, bool is_birth)
{
    bool result = false;
    if (U16_INVALID_VALUE == gp_bmu_data->min_cell_volt ||
        fault_state_get(BOARD_CELL_VOLT_WIRE_ABNORMAL_FAULT))
    {
        return false;
    }
    if (is_birth)
    {
        /* 放空标志产生：最小单体电压 <= 2.7V */
        if (gp_bmu_data->min_cell_volt <= 2700)
        {
            result = true;
        }
    }
    else
    {
        /* 放空标志消失：最小单体电压 >= 2.8V */
        if (gp_bmu_data->min_cell_volt >= 2800)
        {
            result = true;
        }
    }
    return result;
}

/**
* @brief        强制充电标志判断
 */
static bool public_flag_force_charge_check(public_flag_type_e type, bool is_birth)
{
    static uint8_t discharge_time = 0;
    bool result = false;
    const fault_stat_data_t *p_fault_chg_dsg_level = fault_chg_dsg_level_get();
    if (NULL == p_fault_chg_dsg_level)
    {
        return result;
    }
    if (is_birth)
    {
        discharge_time = 0;
        /* 强充标志产生：没有充电保护 && 触发欠压保护 */
        if ((p_fault_chg_dsg_level->max_charge_level > LEVEL1) &&
            ((FAULT_START == fault_state_get(BAT_CELL_VOLT_LOW_PROTECT))||(FAULT_START == fault_state_get(BAT_TOTAL_VOLT_LOW_PROTECT))))
        {
            result = true;
        }
    }
    else
    {
        /* 强充标志消失：欠压保护消失或者有充电保护 */
        if (((FAULT_STOP == fault_state_get(BAT_CELL_VOLT_LOW_PROTECT))&&(FAULT_STOP == fault_state_get(BAT_TOTAL_VOLT_LOW_PROTECT))) ||
            (p_fault_chg_dsg_level->max_charge_level <= LEVEL1))
        {
            result = true;
        }
        if (-(gp_bmu_data->sys_current) > 1000)  // 强充标志消失2：放电电流小于1A, 持续1s
        {
            discharge_time++;
            if (discharge_time >= 100)
            {
                public_flag_state_set(FORCE_CHG_FLAG, PUBLIC_FLAG_CLR);
            }
        }
        else
        {
            discharge_time = 0;
        }
    }
    return result;
}

/**
 * @brief        接收放亏标志判断
 */
static bool public_flag_recv_discharge_empty_check(public_flag_type_e type, bool is_birth)
{
    bool result = false;
    result = (bool)((bmu_active_bal_data_get(CAN_ACT_BAL_EMPTY_FULL_TYPE) & 0xFF00) == 0xAA00);
    if (is_birth)
    {
        return result;
    }
    else
    {
        return !result;
    }
}

/**
 * @brief        接收满充标志判断
 */
static bool public_flag_recv_charge_full_check(public_flag_type_e type, bool is_birth)
{
    bool result = false;
    result = (bool)((bmu_active_bal_data_get(CAN_ACT_BAL_EMPTY_FULL_TYPE) & 0x00FF) == 0x00AA);
    if (is_birth)
    {
        return result;
    }
    else
    {
        return !result;
    }
}

// 触发打印公用标志变化
void public_flag_change_print_deal(void)
{
    static uint64_t last_public_flag = 0;
    if (last_public_flag == g_public_flag_state)
    {
        return;
    }
    
    uint8_t last_public_id_flag = 0;
    uint8_t cur_public_id_flag = 0;
    for (uint8_t public_flag_id = 0; public_flag_id < PUBLIC_FLAG_NUM_MAX; public_flag_id++)
    {
        last_public_id_flag = ((last_public_flag >> public_flag_id) & ((uint64_t)1));
        cur_public_id_flag = ((g_public_flag_state >> public_flag_id) & ((uint64_t)1));
        if (last_public_id_flag != cur_public_id_flag)
        {
            log_e("[PUB]%#x %d\n", public_flag_id, (cur_public_id_flag) ? 1 : 0); 
        }
    }
    last_public_flag = g_public_flag_state;
}

// 判断公共管理函数（10ms任务）
void public_flag_manage_deal(const public_flag_tab_t *p_public_flag_tab, uint16_t max_len)
{
    if (NULL == p_public_flag_tab || 0 == max_len)
    {
        return;
    }
    for (uint16_t arr_index = 0; arr_index < max_len; arr_index++)
    {
        if (!public_flag_state_get(p_public_flag_tab[arr_index].public_type))
        {
            if (p_public_flag_tab[arr_index].p_public_flag_cb(p_public_flag_tab[arr_index].public_type, true))
            {
                g_public_flag_cnt[(uint16_t)p_public_flag_tab[arr_index].public_type] += 1;
            }
            else
            {
                g_public_flag_cnt[(uint16_t)p_public_flag_tab[arr_index].public_type] = 0;
            }
            if (g_public_flag_cnt[(uint16_t)p_public_flag_tab[arr_index].public_type] > p_public_flag_tab[arr_index].appear_cnt)
            {
                public_flag_state_set(p_public_flag_tab[arr_index].public_type, PUBLIC_FLAG_SET);
                g_public_flag_cnt[(uint16_t)p_public_flag_tab[arr_index].public_type] = 0;
            }
        }
        else
        {
            if (p_public_flag_tab[arr_index].p_public_flag_cb(p_public_flag_tab[arr_index].public_type, false))
            {
                g_public_flag_cnt[(uint16_t)p_public_flag_tab[arr_index].public_type] += 1;
            }
            else
            {
                g_public_flag_cnt[(uint16_t)p_public_flag_tab[arr_index].public_type] = 0;
            }
            if (g_public_flag_cnt[(uint16_t)p_public_flag_tab[arr_index].public_type] > p_public_flag_tab[arr_index].cancel_cnt)
            {
                public_flag_state_set(p_public_flag_tab[arr_index].public_type, PUBLIC_FLAG_CLR);
                g_public_flag_cnt[(uint16_t)p_public_flag_tab[arr_index].public_type] = 0;
            }
        }
    }
}

// 公用标志管理任务10ms
static void public_flag_manage_task(void)
{
    public_flag_manage_deal(g_public_flag_tab, ITEM_NUM(g_public_flag_tab));
    public_flag_change_print_deal();
}

/****************************************di 滤波结构参数***************************************************************/
/**
  * @enum   bmu di电平结构体
  * @brief  公共标志类型
  */

typedef union
{
    uint16_t id_status;
    struct 
    {
        uint16_t addr_di_sta   : 1;      
        uint16_t res : 14;
        uint16_t send_flag : 1;
    } bit;
}bmu_di_status_u;

static uint16_t g_bmu_input_state = 0; // 标志状态，位操作， bit=0(未置位) bit=1(置位)
static uint16_t g_di_event_flag_cnt[GPIO_INPUT_NUM_MAX] = {0};
typedef bool(*di_check_callback)(gpio_input_type_e, bool);
/**
 * @struct   fault_para_tab_t
 * @brief  故障参数表结构定义
 */
typedef struct 
{
    gpio_input_type_e       di_type;                 ///< di标志类型
    uint16_t                appear_cnt;              ///< di标志出现持续的次数
    uint16_t                cancel_cnt;              ///< di标志消失持续的次数
    di_check_callback       p_di_check_cb;           ///< 注册的回调函数
} bms_di_tab_t;

// 公用标志回调函数
static bool bms_inner_can_address_di1_check(gpio_input_type_e type, bool is_birth);
static bool bms_inner_can_address_di2_check(gpio_input_type_e type, bool is_birth);
/**
  * @struct   g_input_flag_tab
  * @brief    gpio输入滤波标志表
  */
const static bms_di_tab_t g_input_flag_tab[] =
{
    // di标志类型     -----产生时间 -------- 消失时间      -- 回调函数
    //                        （n*扫描周期10ms)
   {DI1_ADDR_PACK_IN,          3,              3,           bms_inner_can_address_di1_check           },
   {DI2_ADDR_PACK_IN,          3,              3,           bms_inner_can_address_di2_check           },   
};

/**
* @brief        di标志置位
* @param        [in] flag_type 标志类型
* @param        [in] cmd 设置命令
* -# 0x00 - false
* -# 0x01 - true
* @retval        0 成功a
* @retval        -1 失败
*/
static int32_t di_state_set(gpio_input_type_e flag_type, uint8_t cmd)
{
    if ((GPIO_INPUT_NUM_MAX <= flag_type) || ((true != cmd) && (false != cmd)))
    {
        PUBLIC_FLAG_LOGD("[%s] input para err!\r\n", __FUNCTION__);
        return -1;
    }

    if (true == cmd)
    {
        SET_BIT(g_bmu_input_state, (1ULL << flag_type));
    }
    else
    {
        CLR_BIT(g_bmu_input_state, (1ULL << flag_type));
    }
    return 0;
}

/**
* @brief        di相关标志状态获取
* @param        [in] flag_type 故障类型
* @retval        true  置位
* @retval        false 未置位
* @retval        -1 查询失败
*/
int32_t di_state_get(gpio_input_type_e flag_type)
{
    if (GPIO_INPUT_NUM_MAX <= flag_type)
    {
        PUBLIC_FLAG_LOGD("[%s] input para err!\r\n", __FUNCTION__);
        return -1;
    }

    if (0 == GET_BIT(g_bmu_input_state, (1ULL << flag_type)))
    {
        return false;
    }
    else
    {
        return true;
    }
}

/**
 * @brief        编址输入io状态判断
 */
static bool bms_inner_can_address_di1_check(gpio_input_type_e type, bool is_birth)
{
    bool result = false;
    if (is_birth)
    {
        /* 编址输入io高电平：100ms*/
        if (1 == sdk_dido_read(DI_1_BAT_PACK_IN1))
        {
            result = true;
        }
    }
    else
    {
        /* 编址输入io低电平：100ms*/
        if (0 == sdk_dido_read(DI_1_BAT_PACK_IN1))
        {
            result = true;
        }
    }
    return result;
}

/**
 * @brief        编址输入io状态判断
 */
static bool bms_inner_can_address_di2_check(gpio_input_type_e type, bool is_birth)
{
    bool result = false;
    if (is_birth)
    {
        /* 编址输入io高电平：100ms*/
        if (1 == sdk_dido_read(DI_2_BAT_PACK_IN2))
        {
            result = true;
        }
    }
    else
    {
        /* 编址输入io低电平：100ms*/
        if (0 == sdk_dido_read(DI_2_BAT_PACK_IN2))
        {
            result = true;
        }
    }
    return result;
}

// 判断公共管理函数（10ms任务）
void bms_di_state_manage_deal(const bms_di_tab_t *p_di_state_tab, uint16_t max_len)
{
    if (NULL == p_di_state_tab || 0 == max_len)
    {
        return;
    }
    for (uint16_t arr_index = 0; arr_index < max_len; arr_index++)
    {
        if (!di_state_get(p_di_state_tab[arr_index].di_type))
        {
            if (p_di_state_tab[arr_index].p_di_check_cb(p_di_state_tab[arr_index].di_type, true))
            {
                g_di_event_flag_cnt[(uint16_t)p_di_state_tab[arr_index].di_type] += 1;
            }
            else
            {
                g_di_event_flag_cnt[(uint16_t)p_di_state_tab[arr_index].di_type] = 0;
            }
            if (g_di_event_flag_cnt[(uint16_t)p_di_state_tab[arr_index].di_type] >= p_di_state_tab[arr_index].appear_cnt)
            {
                di_state_set(p_di_state_tab[arr_index].di_type, PUBLIC_FLAG_SET);
                g_di_event_flag_cnt[(uint16_t)p_di_state_tab[arr_index].di_type] = 0;
            }
        }
        else
        {
            if (p_di_state_tab[arr_index].p_di_check_cb(p_di_state_tab[arr_index].di_type, false))
            {
                g_di_event_flag_cnt[(uint16_t)p_di_state_tab[arr_index].di_type] += 1;
            }
            else
            {
                g_di_event_flag_cnt[(uint16_t)p_di_state_tab[arr_index].di_type] = 0;
            }
            if (g_di_event_flag_cnt[(uint16_t)p_di_state_tab[arr_index].di_type] >= p_di_state_tab[arr_index].cancel_cnt)
            {
                di_state_set(p_di_state_tab[arr_index].di_type, PUBLIC_FLAG_CLR);
                g_di_event_flag_cnt[(uint16_t)p_di_state_tab[arr_index].di_type] = 0;
            }
        }
    }
}

// 公用标志管理任务10ms
static void di_state_manage_task(void)
{
    bms_di_state_manage_deal(g_input_flag_tab, ITEM_NUM(g_input_flag_tab));
}
/*******************************************************************************************************/

/**
* @brief		请求切断检测
* @param		void
* @return		void
*/
static void bmu_cut_off_request_check(void)
{
	uint8_t cut_off_flag = false;

	if(true == fault_protect_action_get(CUT_OFF_RELAY))
	{
		cut_off_flag = true;
	}
	
	if(true == cut_off_flag)
	{
		if(false == g_bmu_cut_off_request)
		{
            //设置遥信事件
            inner_can_send_msg_ready(BMS_REMOTE_SIGNAL_INFO1);
		}
		g_bmu_cut_off_request = true;
	}
	else
	{
		g_bmu_cut_off_request = false;
	}
}

/**
* @brief		请求关机检测
* @param		void
* @return		void
*/
static void bmu_pow_off_request_check(void)
{
	uint8_t pow_off_flag = false;

	if(true == bmu_active_shut_down_sta())
	{
		pow_off_flag = true;
	}
	
	if(true == pow_off_flag)
	{
		if(false == g_bmu_pow_off_request)
		{
            inner_can_send_msg_ready(BMS_REMOTE_SIGNAL_INFO1);
		}
		g_bmu_pow_off_request = true;
	}
	else
	{
		g_bmu_pow_off_request = false;
	}
}

/**
* @brief        公共标志检测
* @param        void
* @return       void
*/
static void public_flag_check(void)
{
    if(true == g_bmu_flag_check_enable)
    {
        public_flag_manage_task();
        bmu_cut_off_request_check();
        bmu_pow_off_request_check();
    }
}

/**
* @brief		公共标志模块状态判断使能
* @param		void
* @param		void
* @pre	
*/
void public_flag_check_on(void)
{
	g_bmu_flag_check_enable = true;
	
	log_d("[PUB] flag check enable\n");
}

/**
* @brief		公共标志模块初始化
* @param		void
* @param		void
* @pre			系统启动时执行一次。
*/
void public_flag_init(void)
{
	g_public_flag_state = 0;
	
	g_bmu_flag_check_enable = false;
    // 由于上电之后默认不可编址状态，di应该为0（1:为可编址状态 ADDRESSING_PIN_STATUS）
    di_state_set(DI1_ADDR_PACK_IN, PUBLIC_FLAG_CLR);
    di_state_set(DI2_ADDR_PACK_IN, PUBLIC_FLAG_CLR);
}

/**
* @brief		公共标志模块检测任务 周期10ms
* @param		void
* @return		void
*/
int32_t public_flag_task(void)
{
    if (special_mode_get(ATUO_TEST))
    {
        return 0;
    }
#if PUBLIC_FLAG_SHELL_DEBUG_FLAG
    if (g_public_flag_shell_debug_flag)
    {
        return 0;
    }
#endif
    if (gp_bmu_data == NULL)
    {
        gp_bmu_data = (bmu_data_t*)bmu_data_p_get();
        if (gp_bmu_data == NULL)
        {
            return -1;
        }
    }
	public_flag_check();
    di_state_manage_task();
	return 0;
}

/**
* @brief		请求切断标志
* @param		void
* @return		0：不请求切断， 1：请求切断
*/
uint8_t bmu_cut_off_request_get(void)
{
	return g_bmu_cut_off_request;
}

/**
* @brief		请求关机标志
* @param		void
* @return		0：不请求关机， 1：请求关机
*/
uint8_t bmu_pow_off_request_get(void)
{
	return g_bmu_pow_off_request;
}

/**
* @brief		bmu di状态获取
* @param		无
* @return		bit0：编址di
*/
uint16_t bmu_di_state_get(void)
{
    bmu_di_status_u di_status = {0};
    di_status.bit.addr_di_sta = di_state_get(DI1_ADDR_PACK_IN) | di_state_get(DI2_ADDR_PACK_IN);
    di_status.bit.send_flag = 1; // 默认1，表示发送数据
    return di_status.id_status;
}

/***********************************public flag shell debug************************************************/
#if PUBLIC_FLAG_SHELL_DEBUG_FLAG

typedef enum
{
    DEBUG_VAL_BMU_CUT_OFF_REQ = 0,
    DEBUG_VAL_POWER_OFF_REQ,
    DEBUG_VAL_NUM,
} public_flag_value_debug_e;

/**
 * @brief        设置debug
 * @param        [in] data_type 模拟量debug标志， 1：debug 0:normal
 * @param        [in] value 模拟量debug标志， 1：debug 0:normal
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
void public_flag_value_set_debug(uint8_t data_type, int32_t value)
{
    switch (data_type)
    {
        case DEBUG_VAL_BMU_CUT_OFF_REQ:
            g_bmu_cut_off_request = value;
            break;
        case DEBUG_VAL_POWER_OFF_REQ:
            g_bmu_pow_off_request = value;
            break;
        default:
            log_e(" pub val val_id type over err\r\n");
            break;
    }
}
// public flag 打印
void public_flag_debug_printf(void)
{
    log_e("CHG_FULL = %d\n", public_flag_state_get(CHG_FULL_FLAG));
    log_e("DISCHG_EMPTY = %d\n", public_flag_state_get(DISCHG_EMPTY_FLAG));
    log_e("FORCE_CHG = %d\n", public_flag_state_get(FORCE_CHG_FLAG));
    log_e("public_shell_debug = %d\n", g_public_flag_shell_debug_flag);
    log_e("flag_check_en= %d\n", g_bmu_flag_check_enable);
    log_e("cut_off_req = %d\n", g_bmu_cut_off_request);
    log_e("pow_off_req = %d\n", g_bmu_pow_off_request);
    log_e("di_state = %x\n", bmu_di_state_get());
    log_e("DI1_ADDR_PACK_IN = %d\n", di_state_get(DI1_ADDR_PACK_IN));
    log_e("DI2_ADDR_PACK_IN = %d\n", di_state_get(DI2_ADDR_PACK_IN));    
    log_e("RECV_CHG_FULL = %d\n",public_flag_state_get(RECV_CHG_FULL_FLAG));
    log_e("RECV_DCHG_EMPTY = %d\n",public_flag_state_get(RECV_DISCHG_EMPTY_FLAG));
}

void public_flag_debug_err_printf(void)
{
    log_e(" pub param err\r\n");
//    log_e(" pub print : printf data\r\n");
//    log_e(" pub enable : enable data\r\n");
//    log_e(" pub debug 0/1: debug start/close\r\n");
//    log_e(" pub set pub_id(0~%d) value(0/1): set pub_id \r\n", PUBLIC_FLAG_NUM_MAX - 1);
//    log_e(" pub val val_id(0~%d) data(0/1): set pub_id \r\n", DEBUG_VAL_NUM - 1);
}

void public_flag_debug_help_printf(void)
{
//    log_e("val_id:\n");
//    log_e("DEBUG_VAL_BMU_CUT_OFF_REQ       = %d\n", DEBUG_VAL_BMU_CUT_OFF_REQ);
//    log_e("DEBUG_VAL_POWER_OFF_REQ         = %d\n", DEBUG_VAL_POWER_OFF_REQ  );
//    
//    log_e("pub_id:\n");
//    log_e("CHG_FULL_FLAG             = %d\n", CHG_FULL_FLAG      );
//    log_e("DISCHG_EMPTY_FLAG         = %d\n", DISCHG_EMPTY_FLAG  );
//    log_e("FORCE_CHG_FLAG            = %d\n", FORCE_CHG_FLAG     );
//    log_e("RECV_CHG_FULL_FLAG        = %d\n", RECV_CHG_FULL_FLAG);
//    log_e("RECV_DISCHG_EMPTY_FLAG    = %d\n", RECV_DISCHG_EMPTY_FLAG);
}

/**
 * @brief        public_flag功能样例
 * @param        argv 功能参数
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 * @warnning  只有不用can设置时生效
 */
static int pub_flag(int argc, char *argv[])
{
	if (argc < 2)
	{
		log_d("public flag debug para err");
	}
    else
    {
        if (!strcmp(argv[1], "print"))
        {
            public_flag_debug_printf();
        }
        else if (!strcmp(argv[1], "debug"))
        {
            if(argc < 3)
            {
                log_d("%s %s para err\n",argv[0],argv[1]);
                return -1;
            }
            uint32_t flag = atoi(argv[2]); // 解析第2个参数名称
            if (flag > true)
            {
                log_e(" public_debug err\r\n");
                return -1;
            }
            g_public_flag_shell_debug_flag = flag;
        }
        else if (!strcmp(argv[1], "enable"))
        {
            if(argc < 3)
            {
                log_d("%s %s para err\n",argv[0],argv[1]);
                return -1;
            }
            uint32_t flag = atoi(argv[2]); // 解析第2个参数名称
            if (flag > true)
            {
                log_e(" public_debug err\n");
                return -1;
            }
            g_bmu_flag_check_enable = flag;
        }
        else if (!strcmp(argv[1], "set"))
        {            
            if(argc < 4)
            {
                log_d("%s %s para err\n",argv[0],argv[1]);
                return -1;
            }
            if (!g_public_flag_shell_debug_flag)
            {
                log_e("no set public_shell_debug\n");
                return -1;
            }
            uint32_t pub_id = atoi(argv[2]);          // 参数1: 
            int32_t pub_val = atoi(argv[3]);              // 参数2：value值
            public_flag_state_set((public_flag_type_e)pub_id, pub_val);
        }
        else if (!strcmp(argv[1], "val"))
        {
            if(argc < 4)
            {
                log_d("%s %s para err\n",argv[0],argv[1]);
                return -1;
            }
            
            if (!g_public_flag_shell_debug_flag)
            {
                log_e("no set public_shell_debug\n");
                return -1;
            }
            uint32_t val_id = atoi(argv[2]);          // 参数1: 
            int32_t val = atoi(argv[3]);              // 参数2：value值
            public_flag_value_set_debug((public_flag_value_debug_e)val_id, val);
        }
        else if (!strcmp(argv[1], "help"))
        {
            public_flag_debug_help_printf();
        }
        else
        {
            public_flag_debug_err_printf();
        }
    }

    return 0;
}
MSH_CMD_EXPORT(pub_flag, <print/debug 0-1/enable 0-1/set id value/val id value>);
#endif

