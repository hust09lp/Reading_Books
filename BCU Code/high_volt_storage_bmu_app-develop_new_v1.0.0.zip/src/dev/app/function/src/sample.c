/**
 * @file     sample.c
 * @brief    电池数据采样文件
 * @company  sofarsolar
 * @author   刘吕从
 * @note     综合所有底层采样模拟量
 * @version
 * @date     2023/4/27 初稿
 */
 
#include <string.h>
#include <stdlib.h>
#include "sofar_errors.h"
#include "sample.h"
#include "data_store.h"
#include "sdk_para.h"
#include "sdk.h"
#include "sdk_adc.h"
#include "sofar_errors.h"
#include "ate.h"
#include "sofar_can_data.h"

// 宏定义
#define NTC_OMEGA_10K  (10000)
#define NTC_OMEGA_4K7  (4700)
#define NTC_OMEGA_NULL (0)
#define ADC_CODE_VAL_INVAILD (0xFFFF)
#define INNER_ADC_RESOLUTION (4096)

#define SAMPLE_OK (0)
#define SAMPLE_P_NULL_ERR (-1)
#define SAMPLE_OVER_PARA_ERR (-2)
#define SAMPLE_ADC_INVAILD_ERR (-3)
#define SAMPLE_NO_CALI_MODE_ERR (-4)

#define SAMPLE_BASE                          (10)                    // 10ms定时任务, 根据实际改动
#define SAMPLE_30MS_TIME                     (30 / SAMPLE_BASE)      // 30ms定时任务

#define HW_VER_CD_VOLT      2200    //硬件版本电压表不规则段临界电压
#define HW_VER_CAL_VOLT      200    //硬件版本电压表校偏电压
#ifdef APP_SAMPLE_TEST
static bool g_app_sample_code_debug_flag = false;
static bool g_app_sample_value_debug_flag = false;
#endif

/**
 * @enum  sample_adc_id
 * @brief ADC 数据表索引定义
 */
typedef enum
{
    SAMPLE_INIT = 0,          ///< 采样数据初始化
    SAMPLE_ZERO_OFFSET,       ///< 获取adc偏移值
    SAMPLE_IN_WROKING,        ///< 正常采样
    SAMPLE_PROC_STATE_NUM,
} sample_process_state;

// 参数校准数据
typedef struct
{
    uint16_t adc_value;
    uint32_t max_cali_value;
    uint32_t min_cali_value;
    uint32_t gain_value;
    uint32_t offset_adc_value;
    uint32_t divisor_value;
} adc_sample_cali_para_t;

// 全局变量
static sample_data_t g_sample_data = { 0 };              // 电池采样数据
static uint16_t      g_ntc_res[MCU_NTC_NUM] = { 0 };                 // NTC电阻
static uint16_t      g_adc_code_buff[SAMPLE_IDX_MAX] = {0};      // 统计adc的码值
static sample_process_state g_sample_process = SAMPLE_INIT;    // 默认空闲状态
static bool g_sample_enable_flag = true;

static adjust_para_tab_t g_adjust_para_tab = { 0 };                       // 校准参数表赋初始值


const uint16_t  g_ntc_res_table[] =                                   // NTC阻值表
{
    21794,	20553,	19403,	18331,	17327,	16385,	15499,	14666,	13880,	13139,	12441,           //-40 ~ -30
    11784,	11163,	10579,	10028,	9509,	9020,	8559,	8124,	7714,	7328,                    //-29 ~ -20
    6963,	6619,	6294,	5987,	5698,	5424,	5165,	4920,	4688,	4469,                    //-19 ~ -10
    4261,	4064,	3878,	3701,	3533,	3374,	3223,	3079,	2943,	2814,                    //- 9 ~ 0
    2691,	2574,	2463,	2357,	2257,	2161,	2070,	1984,	1901,	1823,                    //  1 ~ 10
    1748,	1677,	1609,	1544,	1482,	1423,	1367,	1314,	1262,	1214,                    // 11 ~ 20
    1167,	1122,	1080,	1039,	1000,	963,	927,	893,	860,	829,                     // 21 ~ 30
    799,	771,	743,	717,	692,	668,	644,	622,	601,	580,                     // 31 ~ 40
    560,	542,	523,	506,	489,	473,	457,	442,	428,	414,                     // 41 ~ 50
    401,	388,	376,	364,	352,	341,	331,	320,	311,	301,                     // 51 ~ 60
    292,	283,	274,	266,	258,	250,	243,	236,	229,	222,                     // 61 ~ 70
    216,	210,	204,	198,	192,	187,	181,	176,	171,	167,                     // 71 ~ 80
    162,	158,	153,	149,	145,	141,	137,	134,	130,	127,                     // 81 ~ 90
    124,	120,	117,	114,	111,	108,	106,	103,	100,	98,                      // 91 ~ 100
    96,	    93,	    91,	    89,	    87,	    84,	    82,	    81,	    79,	    77,                      //101 ~ 110
    75,	    73,	    71,	    70,	    68,	    67,	    65,	    64,	    62,	    61,                      //111 ~ 120   
};


/**
 * @brief                设置采样进程
 * @param                [in]sample_process_state 需要设置的采样状态
 * @return               返回结果 无
 * @warning              无
 */
void sample_process_state_set(sample_process_state state)
{
    if (state >= SAMPLE_PROC_STATE_NUM)
    {
        return;
    }
    g_sample_process = state;
}

/**
* @brief                采样初始化
* @param                [in]无
* @return               返回结果void
* @warning              无
*/
void sample_init(void)
{
    for (int8_t adc_index = 0; adc_index < SAMPLE_IDX_MAX; adc_index++)
    {
        g_adc_code_buff[adc_index] = ADC_CODE_VAL_INVAILD;
    }
    g_sample_process = SAMPLE_INIT;
    g_sample_enable_flag = true;
    for (uint8_t other_id = 0; other_id < MCU_NTC_NUM; other_id++)
    {
        g_sample_data.adc_sample_other_temp[other_id] = I16_INVALID_VALUE;
    }
    g_sample_data.check_24v_volt                       = U32_INVALID_VALUE;
    g_sample_data.check_5v_volt                        = U32_INVALID_VALUE;
    g_sample_data.hardware_version_volt                = U32_INVALID_VALUE;
    g_sample_data.flam_smoke_dect_volt                   = U32_INVALID_VALUE;
    g_sample_data.check_5v_out_volt                    = U32_INVALID_VALUE;
    memcpy(&g_adjust_para_tab, &get_bms_attr()->adjust, sizeof(adjust_para_tab_t)); //校准参数获取
}


/**
 * @brief      遍历所有adc通道，并且记录码值和电压值
 * @param      [in]无
 * @return     返回结果
 * @retval     [out]无
 * @warning    周期调用
 */
void adc_code_traversal_get(void)
{
#ifdef APP_SAMPLE_TEST
    if (g_app_sample_code_debug_flag)
    {
        return;
    }
#endif
    int32_t adc_value;
    int32_t ret;
    static uint8_t err_print_flag = 0;
    for (int8_t adc_index = SAMPLE_IDX_HW_VER; adc_index < SAMPLE_IDX_MAX; adc_index++)
    {
        adc_value = 0;
        ret = sdk_adc_read(adc_index, &adc_value);
        if (0 == ret)
        {
            g_adc_code_buff[adc_index] = adc_value;
        }
        else
        {
            if (0 == err_print_flag)
            {
                log_e("in_adc_self_check %d err%d\n", adc_index, ret);
            }
            err_print_flag++;
        }
    }
}

/**
 * @brief     计算res值
 * @param    [in]adc码值
 * @param    [in]上电阻值 单位Ω
 * @param    [in]下电阻值 单位Ω
 * @return   返回结果
 * @retval   [out]返回ntc阻值 单位0.01kΩ
 * @warning  (默认参考电压为3000mv，采集电压3000mv, 分辨率INNER_ADC_RESOLUTION)
 * @warning  只有温度采样电路才适用, 注意防止数据翻转
 */
static uint16_t sdk_calc_ntc_res(uint16_t adc_code, uint32_t up_res, uint32_t down_res)
{
    if (ADC_CODE_VAL_INVAILD == adc_code)
    {
        log_e("adc_code invaild\r\n");
        return 0xffff;
    }
    // 如果上电阻为0,则无法使用该函数
    if (0 == up_res)
    {
        return 0xffff;
    }
    uint32_t de_tmp = ((uint32_t)SAMP_VOLT * 1000 - (uint32_t)REF_VOLT * adc_code / INNER_ADC_RESOLUTION * 1000) / up_res; // 分母 电流值
    if (0 == de_tmp)
    {
        return 0xffff;
    }
    int32_t nu_tmp = (REF_VOLT * (up_res + down_res) / up_res * adc_code / INNER_ADC_RESOLUTION - SAMP_VOLT * down_res / up_res);     // 分子，ntc电压值
    if (nu_tmp < 0) 
    {
        nu_tmp = 0;
    }
    return (uint16_t)(nu_tmp * 100 / de_tmp);
}

/**
 * @brief                其他ntc ID转换采样adc ID
 * @param                [in] NTC ID
 * @return               返回结果
 * @retval               [out] 片内ADC ID
 * @warning              无
 */
static adc_sample_index_e other_ntc_id_to_adc_id(mcu_temp_ntc_e ntc_id)
{
    adc_sample_index_e adc_id = SAMPLE_IDX_MAX;
    switch (ntc_id)
    {
        case MCU_PCB_TEMP_NTC:
            adc_id = SAMPLE_IDX_PCB_TEMP;
            break;
        default:
            adc_id = SAMPLE_IDX_MAX;
            break;
    }
    return adc_id;
}

/**
* @brief                查表计算得到温度（无偏移）
* @param                [in]uint16_t res_data        电阻值
* @param                [in]uint16_t *ntc_res_table  NTC阻值表
* @param                [in]uint16_t temp_table_size 阻值表大小
* @param                [in]uint16_t temp_offset     温度偏移量
* @return               返回温度值
* @retval               [out]
* @warning              无
*/
int16_t res_to_temp(uint16_t res_data, const uint16_t *ntc_res_table, uint16_t temp_table_size, uint16_t temp_offset)
{
    int16_t left = 0;
    int16_t mid = 0;
    int16_t right = (temp_table_size - 1);
    int16_t res_tmp;
    while (left <= right)//二分法查表确定传入的电阻值在表格中的位置
    {
        mid = (left + right) / 2;
        if (mid < 0)
        {
            return 0;
        }
        if (ntc_res_table[mid] == res_data)//传入阻值为表格中的值
        {
            mid *= 10;
            return (mid - temp_offset);
        }
        else if (ntc_res_table[mid] > res_data) //中间值偏大 初端右移
        {
            left = mid + 1;
        }
        else //中间值偏小  终端左移
        {
            right = mid - 1;
        }
    }

    if (res_data >= ntc_res_table[left] && (left >= 1))
    {
        res_tmp = (res_data - ntc_res_table[left]) * 10 / (ntc_res_table[left - 1] - ntc_res_table[left]);
        (res_tmp < 10) ? (left = 10 * left - res_tmp) : (left *= 10);
    }
    else
    {
        left *= 10; //0.1℃
    }
    return  (left - temp_offset);
}

/**
 * @brief                非电芯温度采集
 * @param                [in]无
 * @return               返回结果空
 * @retval               [out]无
 * @warning              无
 */
static void other_temp_sample(void)
{
    uint8_t adc_index;
    // 上阻值/下阻值不一致，可以考虑用表驱动; 当前一致，所以用for循环遍历
    for (uint8_t other_ntc_id = MCU_PCB_TEMP_NTC; other_ntc_id < MCU_NTC_NUM; other_ntc_id++)
    {
        adc_index = other_ntc_id_to_adc_id((mcu_temp_ntc_e)other_ntc_id);
        if (SAMPLE_IDX_MAX <= adc_index)
        {
            continue;
        }
        if (ADC_CODE_VAL_INVAILD == g_adc_code_buff[adc_index])
        {
            continue;
        }
        g_ntc_res[other_ntc_id] = sdk_calc_ntc_res(g_adc_code_buff[adc_index], NTC_OMEGA_10K, NTC_OMEGA_NULL);
        g_sample_data.adc_sample_other_temp[other_ntc_id] = res_to_temp(g_ntc_res[other_ntc_id], g_ntc_res_table, TEMP_TABLE_SIZE, BAT_TEMP_OFFSET);
    }
}

/**
 * @brief       获取校准参数
 * @param       [in] adjust_para_tab_e adjust_para_type 校准参数类型
 * @param       [in]adc_sample_cali_para_t * p_cali_para 用指针接取数据
 * @return      返回结果
 * @retval      [out] ret(0)  校准获取参数成功
 * @retval      [out] ret(-1) 空指针校准计算失败
 * @retval      [out] ret(-2)  校准增益超出范围或校准类型无效计算失败
 * @warning     数据太多可以使用表驱动
 */
int32_t sample_adjust_cali_para_get(adjust_para_tab_e adjust_para_type, adc_sample_cali_para_t *p_cali_para)
{
    if (adjust_para_type >= ADJUST_PARA_NUM || NULL == p_cali_para)
    {
        return SAMPLE_P_NULL_ERR;
    }
    switch ((uint16_t)adjust_para_type)
    {
        default:
            ;
    }
    return SAMPLE_OK;
}

/**
 * @brief    校准参数计算
 * @param        [in] adjust_para_tab_e adjust_para_type 校准参数类型
 * @param        [in]uint32_t cali_value 校准值
 * -# 电流值      单位10mA  
 * -# 电压值      单位0.1V
 * @param        [in]adjust_para_tab_t *adjust_para_tab 校准结果值为校准参数结构体中的一个成员变量
 * @return    返回结果
 * @retval      [out] ret(0)  校准计算成功
 * @retval      [out] ret(-1) 空指针校准计算失败
 * @retval      [out] ret(-2)  校准增益超出范围或校准类型无效计算失败
 * @retval      [out] ret(-3)  adc采样无效计算失败
 * @warning
 */
static int32_t sample_adjust_cali(adjust_para_tab_e adjust_para_type,uint32_t cali_value, adjust_para_tab_t *p_adjust_para_tab) 
{
    if (NULL == p_adjust_para_tab || ADJUST_PARA_NUM <= adjust_para_type)        // 指针为空 返回设置失败
    {
        return SAMPLE_P_NULL_ERR;
    }

    for(uint8_t i = 0; i < ADC_FILTER_NUM; i++)
    {
        // 保证adc已经采样ok，时间有待确认
        adc_code_traversal_get();
    }
    uint32_t *p_gain_addr = &p_adjust_para_tab->adjust_para_gain[adjust_para_type];
    adc_sample_cali_para_t cali_para = {
        .adc_value = ADC_CODE_VAL_INVAILD,
        .offset_adc_value = ADC_CODE_VAL_INVAILD
    };
    int32_t ret = sample_adjust_cali_para_get(adjust_para_type, &cali_para);
    if (ret != SAMPLE_OK)
    {
        return ret;
    }
    if (ADC_CODE_VAL_INVAILD == cali_para.adc_value || ADC_CODE_VAL_INVAILD == cali_para.offset_adc_value ||
        cali_para.adc_value == cali_para.offset_adc_value || 0 == cali_para.divisor_value)
    {
        return SAMPLE_ADC_INVAILD_ERR;
    }
    // 注意:cali_value * cali_para.gain_value 这个值必须控制不能越界，否则会异常
    uint32_t real_gain_value = cali_value * cali_para.gain_value / cali_para.divisor_value / (cali_para.adc_value - cali_para.offset_adc_value);
    if (real_gain_value < cali_para.min_cali_value || real_gain_value > cali_para.max_cali_value)
    {
        log_e("%dgainValErr=%d\n", adjust_para_type, real_gain_value);
        return SAMPLE_OVER_PARA_ERR;
    }
    *p_gain_addr = real_gain_value;
    return SAMPLE_OK;
}

/**
* @brief    校准参数计算
* @param    [in] adjust_para_tab_e adjust_para_type 校准参数类型
* @param        [in]uint32_t cali_value 校准值
* -# 电流值      单位10mA  
* -# 电压值      单位0.1V
* @param        [in]adjust_para_tab_t *adjust_para_tab 校准结果值为校准参数结构体中的一个成员变量
* @return    返回结果
* @retval      [out] ret(0)  校准计算成功
* @retval      [out] ret(-1) 空指针校准计算失败
* @retval      [out] ret(-2)  校准增益超出范围或校准类型无效计算失败
* @retval      [out] ret(-3)  adc采样无效计算失败
* @retval      [out] ret(-4)  没有进入标定模式
* @warning
*/
int32_t sample_adjust_cali_deal(adjust_para_tab_e adjust_para_type,uint32_t cali_value, adjust_para_tab_t *p_adjust_para_tab)
{
    if (!special_mode_get(CALI_PARM))
    {
        return SAMPLE_NO_CALI_MODE_ERR;
    }
    
    return sample_adjust_cali(adjust_para_type, cali_value, p_adjust_para_tab);
}

/**
 * @brief                采样校准参数设置
 * @param                [in]adjust_para_tab_t *p_adjust_para_tab 校准参数表结构体
 * @return               返回结果
 * @retval               [out]ret(0)  设置成功
 * @retval               [out]ret(-1) 设置失败
 * @warning              无
 */
int32_t sample_adjust_set(adjust_para_tab_t *p_adjust_para_tab)
{
    int32_t ret = 0;
    if(NULL == p_adjust_para_tab)        // 指针为空 返回设置失败
    {
        ret = -1;
        return ret;
    }
    adc_sample_cali_para_t cali_para = {0};
    for (uint16_t gain_para_index = 0; gain_para_index < ADJUST_PARA_NUM; gain_para_index++)
    {
         ret = sample_adjust_cali_para_get((adjust_para_tab_e)gain_para_index, &cali_para);
         if (SAMPLE_OK != ret)
         {
             ret = -1;
             break;
         }
         if (p_adjust_para_tab->adjust_para_gain[gain_para_index] < cali_para.min_cali_value ||
             p_adjust_para_tab->adjust_para_gain[gain_para_index] > cali_para.max_cali_value)
         {
             ret = -1;  // 若有增益超出范围 则返回设置失败
             break;
         }
    }
    if (0 == ret)
    {
         memcpy(&g_adjust_para_tab, p_adjust_para_tab, sizeof(adjust_para_tab_t));  // 设置校准参数
    }
     return ret;
}

/**
 * @brief                ntc异常判断
 * @param                [in]res_value        需要判断的电阻值
 * @param                [in]res_temp_table   需要查的表格
 * @param                [in]table_size       表格元素个数
 * @return               返回结果
 * @retval               [out]ret(SAMPLE_STATE_OK)  获取采集状态成功
 * @retval               [out]ret(SAMPLE_STATE_EOI) 获取采集状态失败
 * @retval               [out]ret(NTC_SHORT_CIRCUIT) NTC短路
 * @retval               [out]ret(NTC_OPEN_CIRCUIT)  NTC开路
 * @retval               [out]ret(AFE_ERR)           AFE异常
 * @warning              在采集任务开始以后调用
 */
int32_t sample_res_ntc_abnormal_judge(uint16_t res_value, const uint16_t *p_res_temp_table, uint16_t table_size)
{
    if (NULL == p_res_temp_table || 0 == table_size)
    {
        log_e("sam table err\n");
        return SAMPLE_STATE_EOI;
    }
    int ret = SAMPLE_STATE_OK;
    if(res_value > p_res_temp_table[0])  //开路
    {
        ret = NTC_OPEN_CIRCUIT_ERR;
    }
    else if(res_value < p_res_temp_table[table_size -1]) //短路
    {
        ret = NTC_SHORT_CIRCUIT_ERR;
    }
    return ret;
}

/**
 * @brief      采样异常状态获取
 * @param      [in]other_ntc_type_e（只能查询片内）
 * @return     返回结果
 * @retval     [out]ret(SAMPLE_STATE_OK)  获取采集状态成功
 * @retval     [out]ret(SAMPLE_STATE_EOI) 获取采集状态失败
 * @retval     [out]ret(NTC_SHORT_CIRCUIT) NTC短路
 * @retval     [out]ret(NTC_OPEN_CIRCUIT)  NTC开路
 * @warning    在采集任务开始以后调用
 */
int32_t mcu_sample_abnormal_get(other_ntc_type_e type)
{
    int32_t ret = SAMPLE_STATE_OK;

    switch(type)
    {
        case OTHER_ENV_NTC:
            ret = sample_res_ntc_abnormal_judge(g_ntc_res[MCU_PCB_TEMP_NTC], g_ntc_res_table, TEMP_TABLE_SIZE);
            break;
        default:
            ret = SAMPLE_STATE_EOI;
            break;
    }
    return ret;
}

/**
 * @brief                电压采集
 * @param                [in]无
 * @return               返回结果空
 * @retval               [out]无
 * @warning              无
 */
static void volt_sample(void)
{
    if (ADC_CODE_VAL_INVAILD != g_adc_code_buff[SAMPLE_IDX_5V_VOLT])
    {
        g_sample_data.check_5v_volt = 
            (uint32_t)((uint64_t)g_adc_code_buff[SAMPLE_IDX_5V_VOLT] * REF_VOLT * 291 / 91 / INNER_ADC_RESOLUTION); // 得到SIG_5V BMS运行过程中自检 放大倍数为6.5,单位1mV
    }

    if(ADC_CODE_VAL_INVAILD != g_adc_code_buff[SAMPLE_IDX_24V_VOLT])
    {
        g_sample_data.check_24v_volt = 
            (uint32_t)((uint64_t)g_adc_code_buff[SAMPLE_IDX_24V_VOLT] * REF_VOLT * 1091 / 91 / INNER_ADC_RESOLUTION); // 得到SIG_24V BMS运行过程中自检 放大倍数为6.5,单位1mV
    }

    if(ADC_CODE_VAL_INVAILD != g_adc_code_buff[SAMPLE_IDX_FLAM_GAS])
    {
        g_sample_data.flam_smoke_dect_volt = 
            (uint32_t)((uint64_t)g_adc_code_buff[SAMPLE_IDX_FLAM_GAS] * REF_VOLT / INNER_ADC_RESOLUTION); // flam_smoke_dect_volt BMS运行过程中自检 放大倍数为6.5,单位1mV
    }
    
    if (ADC_CODE_VAL_INVAILD != g_adc_code_buff[SAMPLE_IDX_5V_OUT_VOLT])
    {
        g_sample_data.check_5v_out_volt = 
            (uint32_t)((uint64_t)g_adc_code_buff[SAMPLE_IDX_5V_OUT_VOLT] * REF_VOLT * 291 / 91 / INNER_ADC_RESOLUTION); // 得到SIG_5V_OUT BMS运行过程中自检 放大倍数为3.2,单位1mV
    }
}

/**
* @brief                硬件版本识别
* @param                [in]无
* @return               返回结果空
* @retval               [out]无
* @warning              无
*/
static void hardware_version_sample(void)
{
    static int16_t last_ver = -1;
    if (ADC_CODE_VAL_INVAILD != g_adc_code_buff[SAMPLE_IDX_HW_VER])
    {
        g_sample_data.hardware_version_volt = ((uint32_t)g_adc_code_buff[SAMPLE_IDX_HW_VER] * REF_VOLT / INNER_ADC_RESOLUTION);
        if (last_ver == -1)
        {
            last_ver = hardware_ver_get();
            //log_e("[VER]hard v%d,%d\n",g_sample_data.hardware_version_volt, last_ver);
        }
    }
}

/**
* @brief                电解液漏液传感器数据处理
* @param                [in]无
* @return               返回结果空
* @retval               [out]无
* @warning              无
*/
#define COM_ABNOR_10MS_CNT  1000    //10S
static void electrolyte_sensor_data_deal(void)
{
    electrolyte_sensor_info_t tmp = {0};
    tmp = electrolyte_sensor_data_get();
    
    if(tmp.tick != g_sample_data.electrolyte_sensor_data.tick)
    {
        g_sample_data.electrolyte_sensor_data = electrolyte_sensor_data_get();    // 电解液漏液传感器赋值        
        g_sample_data.electrolyte_sensor_data.cnt = 0;
        g_sample_data.electrolyte_sensor_data.com_abnor_flag = false;
    }
    else
    {
        if (++g_sample_data.electrolyte_sensor_data.cnt >= COM_ABNOR_10MS_CNT)
        {
            g_sample_data.electrolyte_sensor_data.cnt = COM_ABNOR_10MS_CNT;
            g_sample_data.electrolyte_sensor_data.com_abnor_flag = true;
        }
    }

    
}

/**
 * @brief      更新所有模拟量
 * @warning    
 */
void sample_value_traversal_get(void)
{
#ifdef APP_SAMPLE_TEST
    if (g_app_sample_value_debug_flag)
    {
        return;
    }
#endif
    other_temp_sample();        // 计算其他温度值
    volt_sample();              // 换算电压值
    hardware_version_sample();  // 硬件版本号识别
    electrolyte_sensor_data_deal();
    
}

/**
 * @brief                电池采样任务
 * @param                [in]void
 * @return               返回结果空
 * @retval               [out]无
 * @warning              放在10ms任务，必须要调用sample_data_init()后使用
 */
void sample_proc(void)
{
    int32_t ret = SAMPLE_OK;
    switch ((uint16_t)g_sample_process)
    {
        case SAMPLE_INIT:
            if (g_sample_enable_flag)
            {
                sample_process_state_set(SAMPLE_ZERO_OFFSET);
            }
            break;
        case SAMPLE_ZERO_OFFSET: // 上电获取大环/小环电流零点初始AD值
//            ret = zero_offset_adc_get();
            if (SAMPLE_OK == ret)
            {
                sample_process_state_set(SAMPLE_IN_WROKING);
            }
            break;
        case SAMPLE_IN_WROKING:
            adc_code_traversal_get();
            sample_value_traversal_get();
            break;
        default:
            sample_process_state_set(SAMPLE_INIT);
            break;
    }
}

/**
* @brief                获取电池采样信息
* @param                [in]bat_sample_data_t *p_data 电池采样数据结构体指针
* @return               返回结果
* @retval               ret(-1)获取失败
* @retval               ret(0)获取成功
* @warning              无
*/
int32_t sample_data_get(sample_data_t *p_data)
{
    int32_t ret = 0;
    if (NULL == p_data)         //  指针为空 获取失败
    {   
        ret = -1;
        
    }
    else                        //指针不为空 获取电池采样信息
    {
        memcpy(p_data, &g_sample_data, sizeof(sample_data_t));
    }
    
    return ret;
}

/**
* @brief                获取电池采样信息
* @param                [in]无
* @return               const sample_data_t *
* @retval               NULL获取失败
* @retval               ret(!NULL)获取成功
* @warning              无
*/
const sample_data_t *sample_data_p_get(void)
{
    return (const sample_data_t *)&g_sample_data;
}

/**
* @brief                获取采样码值
* @param                SAMPLE_IDX_HW_VER = 0,                            ///< 机型识别
* @param                SAMPLE_IDX_24V_VOLT,                              ///< 24V供电电压检测
* @param                SAMPLE_IDX_5V_VOLT,                               ///< 5V辅助电压检测
* @param                SAMPLE_IDX_PCB_TEMP,                              ///< PCB温度采集
* @param                SAMPLE_IDX_FLAM_GAS,                              ///< 可燃气体检测
* @param                SAMPLE_IDX_5V_OUT_VOLT,                           ///< 5V输出电压采集
* @return               返回结果
* @retval               ret(-1)获取失败
* @retval               ret(0)获取成功
* @warning              无
*/
uint16_t sample_data_code_get(uint8_t code_type)
{
    if (SAMPLE_IDX_MAX <= code_type)         //  指针为空 获取失败
    {   
        return 0;
        
    }
    return g_adc_code_buff[code_type];
}

/**
 * @brief                获取硬件版本号
 * @param                [in]无
 * @return               [out] void
 * @warning              必须确保片内adc已经完成采样
 */
int16_t hardware_ver_get(void)
{
    int16_t ver = 0;
    if (0 == g_sample_data.hardware_version_volt)
    {
        return -1;
    }
    if(g_sample_data.hardware_version_volt < HW_VER_CD_VOLT)
    {
        ver = g_sample_data.hardware_version_volt / 300;
    }
    else
    {
        ver = (g_sample_data.hardware_version_volt + HW_VER_CAL_VOLT) / 300;
    }
    return ver;
}

#ifdef APP_SAMPLE_TEST

typedef enum
{
    DEBUG_VAL_ENV_TEMP = 0,     ///< PCB TEMP   ,单位0.1℃
    DEBUG_VAL_5V_VOLT,          ///< 5V电压检测      单位1mV
    DEBUG_VAL_VER_VOLT,         ///< 硬件版本号识别  单位1mV 
    DEBUG_VAL_24_VOLT,
    DEBUG_VAL_GAS_VOLT,
    DEBUG_VAL_5V_OUT_VOLT,
    DEBUG_VAL_NUM,
} sample_value_debug_e;

/**
 * @brief        设置模拟量debug
 * @param        [in] debug_flag 模拟量debug标志， 1：debug 0:normal
 * @param        [in] data_type 模拟量debug标志， 1：debug 0:normal
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
void sample_value_set_debug(uint32_t debug_flag, uint8_t data_type, int32_t value)
{
    if (!debug_flag)
    {
        return;
    }
    switch (data_type)
    {
        case DEBUG_VAL_ENV_TEMP:
            g_sample_data.adc_sample_other_temp[MCU_PCB_TEMP_NTC] = value;
            break;
        case DEBUG_VAL_5V_VOLT:
            g_sample_data.check_5v_volt = value;
            break;
        case DEBUG_VAL_VER_VOLT:
            g_sample_data.hardware_version_volt = value;
            break;
        case DEBUG_VAL_24_VOLT:
            g_sample_data.check_24v_volt = value;
            break;
        case DEBUG_VAL_GAS_VOLT:
            g_sample_data.flam_smoke_dect_volt = value;
            break;
        case DEBUG_VAL_5V_OUT_VOLT:
            g_sample_data.check_5v_out_volt = value; 
            break;   
        default:
            log_e(" sam_t set val type over err\r\n");
            break;
    }
}

// sam_t打印
void sample_debug_printf(void)
{
    log_d("encNtc:tem=%d(0.1'),res=%ld(0.01kΩ),c= %d\n", g_sample_data.adc_sample_other_temp[MCU_PCB_TEMP_NTC], g_ntc_res[MCU_PCB_TEMP_NTC], g_adc_code_buff[SAMPLE_IDX_PCB_TEMP]);
    // log_d("DCDC_NTC1:tem = %d, res = %ld\n", g_sample_data.adc_sample_other_temp[OTHER_DCDC_NTC1], g_ntc_res[OTHER_DCDC_NTC1]);
    log_d("5v=%ldmV,c=%d\n", g_sample_data.check_5v_volt, g_adc_code_buff[SAMPLE_IDX_5V_VOLT]);
    log_d("24v=%ldmV,c=%d\n", g_sample_data.check_24v_volt, g_adc_code_buff[SAMPLE_IDX_24V_VOLT]);
    log_d("hwVerV=%dmV,c=%d\n", g_sample_data.hardware_version_volt, g_adc_code_buff[SAMPLE_IDX_HW_VER]);
    log_d("5v_out=%ldmV,c=%d\n", g_sample_data.check_5v_out_volt, g_adc_code_buff[SAMPLE_IDX_5V_OUT_VOLT]);
    log_d("samProc=%d\n", (uint16_t)g_sample_process);
    log_d("samEn=%ld\n", g_sample_enable_flag);
    log_d("samCodeDebug=%ld\n", g_app_sample_code_debug_flag);
    log_d("samValDebug=%ld\n", g_app_sample_value_debug_flag);
}

void sample_debug_err_printf(void)
{
    log_d("sam param err\n");
//    log_e("sam print\n");
//    log_e("sam eget type(0~%d) val\n", ERR_NUM - 1);
//    log_e("sam cali type(0~%d) val\n", ADJUST_PARA_NUM - 1);
//    log_e("sam code bug(0/1) code_id(0~%d) val\n", SAMPLE_IDX_MAX - 1);
//    log_e("sam val bug(0/1) val_id(0~%d) val\n", DEBUG_VAL_NUM - 1);
}

void sample_debug_help_printf(void)
{
    log_e("code_id:\n");
    log_e("5V_VOLT = %d\n", SAMPLE_IDX_5V_VOLT       ); 
    log_e("24V_VOLT = %d\n", SAMPLE_IDX_24V_VOLT      ); 
    log_e("HW_VER = %d\n", SAMPLE_IDX_HW_VER        ); 
    log_e("PCB_TEMP = %d\n", SAMPLE_IDX_PCB_TEMP      ); 
    log_e("5V_OUT = %d\n", SAMPLE_IDX_5V_OUT_VOLT       ); 
    log_e("val_id:\n");
    log_e("DENV_TEMP = %d\n", DEBUG_VAL_ENV_TEMP    );
    log_e("D_5V = %d\n", DEBUG_VAL_5V_VOLT     );
    log_e("D_VER_V = %d\n", DEBUG_VAL_VER_VOLT    );
    log_e("D_24V = %d\n", DEBUG_VAL_24_VOLT    );
    log_e("D_5V_OUT = %d\n",  DEBUG_VAL_5V_OUT_VOLT     );
//    log_e("cali type:\n");
//    log_e("err type:\n");
}

/**
 * @brief        hal_sample功能样例
 * @param        argv 功能参数
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
static int sample(int argc, char *argv[])
{
	if (argc < 2)
	{
		log_d("sample debug para err\n");
	}
    else
    {
        if (!strcmp(argv[1], "print"))
        {
            sample_debug_printf();
        }
        else if (!strcmp(argv[1], "eget"))
        {
            if(argc < 3)
            {
                log_d("sam eget para err\n");
                return -1;
            }
            uint32_t type = atoi(argv[2]); //解析第2个参数名称
            if (type >= MCU_OTHER_TEMP_END)
            {
                log_e("sam_debugTypeerr\n");
                return SF_ERR_PARA;
            }
            log_e("samAbGet[%ld]=%ld\n",type, mcu_sample_abnormal_get((other_ntc_type_e)type));
        
        }
        else if (!strcmp(argv[1], "cali"))
        {
            if(argc < 4)
            {
                log_d("sam cali para err\n");
                return -1;
            }
            uint32_t type = atoi(argv[2]);  // 解析第2个参数名称, 校准类型， 
            uint32_t val = atoi(argv[3]);   // 解析第3个参数名称,校准数值（电流值      单位10mA  ；电压值      单位0.1V）
            if (type >= ADJUST_PARA_NUM)
            {
                log_e("sdkSamDebug adtype(0~%d) val: ad_type over\n", ADJUST_PARA_NUM - 1);
                return SF_ERR_PARA;
            }
            int ret = sample_adjust_cali((adjust_para_tab_e)type, val, &g_adjust_para_tab);
            if(SAMPLE_OK == ret)
            {
                ret = sample_adjust_set(&g_adjust_para_tab);
                if(SAMPLE_OK == ret)
                {
                    data_store_save_adjust_para(&g_adjust_para_tab);
                }
            }
            log_e("sdk_sam_ab_get ret=%ld\n",ret);
        }
        else if (!strcmp(argv[1], "code"))
        {
            if(argc < 5)
            {
                log_d("sam code para err\n");
                return -1;
            }
            uint32_t debug_flag = atoi(argv[2]); // 参数1：debug标志（1使能，0取消），
            uint32_t adc_id = atoi(argv[3]);     // 参数2：码值(adc_sample_index_e)
            int32_t value = atoi(argv[4]);       // 参数3：code值
            g_app_sample_code_debug_flag = debug_flag;
            if (adc_id >= SAMPLE_IDX_MAX)
            {
                log_e("sam_deb deFlag(0~1) adc_id(1~%d) val: de_type over\n", SAMPLE_IDX_MAX - 1);
                return SF_ERR_PARA;
            }
            g_adc_code_buff[adc_id] = (uint16_t)value;
        }
        else if (!strcmp(argv[1], "val"))
        {
            if(argc < 5)
            {
                log_d("sam val para err\n");
                return -1;
            }
            uint32_t debug_flag = atoi(argv[2]);  // 设置参数1：debug标志（1使能，0取消）
            uint32_t val_id = atoi(argv[3]);      // 参数2: 模拟量sample_value_debug_e
            int32_t value = atoi(argv[4]);        // 参数3：value值
            g_app_sample_value_debug_flag = debug_flag;
            sample_value_set_debug(debug_flag, val_id, value);
        }
        else if (!strcmp(argv[1], "help"))
        {
            sample_debug_help_printf();
        }
        else
        {
            sample_debug_err_printf();
            return SF_ERR_PARA;
        }
    }
 
    return SF_OK;
}
MSH_CMD_EXPORT(sample, <print/eget type/cali type val/val(code) debug(0-1) id value>);
#endif

