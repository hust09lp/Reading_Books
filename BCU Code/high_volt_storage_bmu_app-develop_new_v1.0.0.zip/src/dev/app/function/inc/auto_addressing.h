#ifndef __AUTO_ADDRESSING_H__
#define __AUTO_ADDRESSING_H__

#include <stdint.h>
#include <stddef.h>
#include "sofar_can_data.h"
#include "sofar_can_manage.h"

#define AUTO_ADDR_SHELL_DEBUG 1

/**
 * @brief 自动编址状态
 */
typedef enum
{
    ADDRESSING_DISENABLE = 0, ///< 未使能自动编址
    ADDRESSING_ING,           ///< 编址中
    ADDRESSING_FINISH,        ///< 编址完成
} auto_addressing_state_e;

#define AUTO_ADDRESSING_NO_FAULT 0    // 没故障
#define AUTO_ADDRESSING_ID_CONFLICT 1 // 通讯ID冲突
#define AUTO_ADDRESSING_COMM_FAIL   2 // 通讯故障
#define BMU_ADDR_DEFAULT            0x1F  // 未编址前的默认地址
#define BCU_INNER_CAN_ADDR      0x01
// 自动编址状态机相关
typedef enum{
    EVT_ADDR_PREPARED    = 0,    //
    ADDR_EVT_NUM,
}addr_fsm_event_e;
typedef enum{
    STA_ADDR_INIT = 0,       ///< 状态机初始化
    STA_ADDR_SLAVE,         ///< 从机
    ADDR_STA_NUM,
}addr_fsm_state_e;

typedef struct
{
    uint8_t comm_state;
    uint16_t unlink_time_cnt;
}pack_comm_status;

typedef struct
{
    uint16_t   auto_addressing_enable;    // 使能自动编址
    auto_addressing_state_e addr_state;   // 编址状态
    uint8_t    dev_addr;              // 从机地址
    uint8_t    address_conflict_flag;
    uint16_t    unlink_time_cnt;
    uint8_t    fault_pack_unlink;    // 电池包失联
    uint8_t    first_recv_master_heat_flag; // 首次接收到主机心跳
}slave_addr_para; /* 动作action表描述 */

/**
 * @brief  获取自动编址状态
 * @return 自动编址状态
 */
auto_addressing_state_e auto_addressing_get_state(void);

/**
 * @brief  获取自动编址故障
 * @return AUTO_ADDRESSING_NO_FAULT     没故障
 * @return AUTO_ADDRESSING_ID_CONFLICT  通讯ID冲突
 * @return AUTO_ADDRESSING_COMM_FAIL    通讯故障
 */
uint8_t auto_addressing_fault_get(void);

/**
 * @brief  获取编址地址
 * @retval =0     未完成编址
 * @retval 1~0x0F 有效地址
 */
uint8_t auto_addressing_get_address(void);

/**
 * @brief  使能自动编址，自动编址完成后再使能，会重新自动编址
 * @return 无
 */
void auto_addressing_enable(void);

/**
 * @brief  禁止自动编址
 * @return 无
 */
void auto_addressing_disable(void);

/**
 * @brief  获取自动编址使能标志
 * @return 无
 */
uint8_t auto_addressing_enable_flag(void);

/**
 * @brief   内网CAN(bmu/bcu)，自动编址初始化
 * @param   无
 * @return  返回执行结果 0:正常；<0:异常
 * @warning	无
 */
void inner_auto_addr_init(void);

/**
 * 自动别编址状态机，10ms调用一次
 */
void inner_auto_addressing_proc(void);
/**
 * @brief   内网CAN(bmu/bcu)，自动编址初始化
 * @param   无
 * @return  返回执行结果 0:正常；<0:异常
 * @warning	无
 */
void inner_auto_addr_init(void);
/**
 * @brief  自动编址can报文接收回调函数
 */
int32_t inner_addr_rcv_callback(uint32_t can_id, uint8_t *p_data, int32_t len);

uint8_t auto_addressing_pack_num_get(void);

/**
 * @brief  设置编址地址
 * @input   addr 地址
 * @retval 0有效，-1无效
 */
int8_t inner_address_set(uint8_t addr);

/**
 * @brief  获取编址内部进程状态
 * @input   
 * @retval 
 */
uint8_t slave_addr_proc_state_get(void);

/**
 * @brief   内网CAN(bmu/bcu)，定时广播心跳包，用于检测地址冲突与从机失联
 * @param   无
 * @return  无
 * @warning	无
 */
void send_heartbeat(void);
    
#endif
