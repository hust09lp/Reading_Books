#ifndef __APP_PUBLIC_H__
#define __APP_PUBLIC_H__
#include <stdint.h>
#include <stddef.h>
#include "msh.h"
#include "pin_config.h"
/**
* 软件版本号
*/
#define SOFTWARE_VERSION		"T010003" 
#define HARDWARE_VERSION		"V000001"
/*测试标志*/
#define SIMULATION_DATA_TEST				//数据模拟测试标志 正式代码发布时，要屏蔽此测试标志
#define SIMULATION_FAULT_TEST				//故障模拟测试标志 正式代码发布时，要屏蔽此测试标志

//#define SINGAL_TEST							//单机测试时候，没有自动编址， 正式代码发布时，要屏蔽此测试标志

// #define UPG_TT 1

#if PACK_64S_PRJ
/* AFE模块 */
#define AFE_CELL_VOLT_NUM                 16     ///< 电芯电压数量
#define AFE_CELL_TEMP_NUM                 9      ///< 电芯温度数量
// 选通通道1
#define AFE_CHANNEL1_CELL_TEMP_NUM        8      ///< 通道1电芯温度数量
#define AFE_CHANNEL1_OTHER_TEMP_NUM       0      ///< 通道1其他温度数量
#define AFE_CHANNEL1_TEMP_TOTAL_NUM       (AFE_CELL_TEMP_NUM + AFE_CHANNEL1_OTHER_TEMP_NUM)
// 选通通道2
#define AFE_CHANNEL2_CELL_TEMP_NUM        1      ///< 通道2电芯温度数量 (64S项目特有)
#define AFE_BALANCE_TEMP_NUM              2      ///< 均衡温度数量
#define AFE_POWER_TEMP_NUM                1      ///< 功率端子温度数量
#define AFE_CHANNEL2_OTHER_TEMP_NUM       4      ///< 通道2其他温度数量
#define AFE_CHANNEL2_TEMP_TOTAL_NUM       (AFE_BALANCE_TEMP_NUM + AFE_POWER_TEMP_NUM + AFE_CHANNEL2_OTHER_TEMP_NUM + AFE_CHANNEL2_CELL_TEMP_NUM)

#define DEFAULTED_RATED_CAP 120                 //额定容量

#else

/* AFE模块 */
#define AFE_CELL_VOLT_NUM                 12     ///< 电芯电压数量
#define AFE_CELL_TEMP_NUM                 7      ///< 电芯温度数量
// 选通通道1
#define AFE_CHANNEL1_CELL_TEMP_NUM        7      ///< 通道1电芯温度数量
#define AFE_CHANNEL1_OTHER_TEMP_NUM       1      ///< 通道1其他温度数量
#define AFE_CHANNEL1_TEMP_TOTAL_NUM       (AFE_CELL_TEMP_NUM + AFE_CHANNEL1_OTHER_TEMP_NUM)
// 选通通道2
#define AFE_BALANCE_TEMP_NUM              2      ///< 均衡温度数量
#define AFE_POWER_TEMP_NUM                1      ///< 功率端子温度数量
#define AFE_CHANNEL2_OTHER_TEMP_NUM       5      ///< 通道2其他温度数量
#define AFE_CHANNEL2_TEMP_TOTAL_NUM       (AFE_BALANCE_TEMP_NUM + AFE_POWER_TEMP_NUM + AFE_CHANNEL2_OTHER_TEMP_NUM)

#define DEFAULTED_RATED_CAP 280                 //额定容量

#endif

/* sample模块 */
#define AFE_NUM 			4
#define CELL_VOLT_NUM                 (AFE_NUM*AFE_CELL_VOLT_NUM)     ///< 电芯电压数量
#define CELL_TEMP_NUM                 (AFE_NUM*AFE_CELL_TEMP_NUM)      ///< 电芯温度数量
#define BALANCE_TEMP_NUM              (AFE_NUM*AFE_BALANCE_TEMP_NUM)      ///< 均衡温度数量
#define POWER_TEMP_NUM                2 //(AFE_NUM*AFE_POWER_TEMP_NUM)      ///< 功率端子温度数量
//#define CHANNEL1_OTHER_TEMP_NUM       (AFE_NUM*AFE_CHANNEL1_OTHER_TEMP_NUM)      ///< 通道1其他温度数量
//#define CHANNEL2_OTHER_TEMP_NUM       (AFE_NUM*AFE_CHANNEL2_OTHER_TEMP_NUM)      ///< 通道2其他温度数量


#define RATED_PACK_VOLT  3200*CELL_VOLT_NUM		///< PACK的额定电压，N * 3200mV 
#if PACK_64S_PRJ
#define CELL_FULL_CHG_VOL 3600                  //单体满充电压
#else
#define CELL_FULL_CHG_VOL 3550                  //单体满充电压
#endif

#define PACK_FULL_CHG_VOL CELL_FULL_CHG_VOL*CELL_VOLT_NUM  //电池包满充电压
#define CHG_STOP_CUR    DEFAULTED_RATED_CAP/2   //0.5C

//被动均衡相关
#define BAL_CURR    150     //均衡电流 mA/bit
#define BAL_VOLT_DIFF   20  //均衡压差 mV/bit
#define BAL_START_VOLT   3400  //均衡启动 mV/bit

//容量限制
#define RATED_CAP_UPPER_LIMIT 400
#define RATED_CAP_LOWER_LIMIT 50

/*采样异常码定义*/
#define NTC_SHORT_CIRCUIT_ERR       (-1)    ///< NTC短路
#define NTC_OPEN_CIRCUIT_ERR        (-2)    ///< NTC开路
#define AFE_ERR                     (-3)    ///< AFE异常

// 字节偏移宏
#define LOW_BYTE(word) ((uint8_t)((uint16_t)(word) & 0xFF))
#define HIGH_BYTE(word) ((uint8_t)(((uint16_t)(word) >> 8) & 0xFF))
#define MAKE_WORD(low, high) ((uint16_t)((uint16_t)(low) | (uint16_t)((high) << 8)))

#define MASTER_CTL_SET_CRC8_MASK    0x00    // 主机/上位机控制CRC
#define ATE_CONTROL_CRC8_MASK       0x00    // ATE控制CRC

#define UPD_3PH_FLAG

// can过滤宏定义
#define CAN_FILTER_ITEM_INIT(id,ide,rtr,mode,mask) \
     {(id), (ide), (rtr), (mode), (mask), -1, }	///< 不指定过滤号的硬件过滤表
     
/**********************************************************/


/**
  * @enum      ntc_res_type_e
  * @brief     NTC电阻类型
  * @warninig  OTHER_NTC_NUM必须排在前面，电芯温度归一列，否则会影响sdk_sample_abnormal_get
  */
typedef enum
{
    MCU_OTHER_TEMP_START = 0,
    OTHER_ENV_NTC = MCU_OTHER_TEMP_START,            ///< 环境NTC/PCB NTC
    MCU_OTHER_TEMP_END,
    AFE_OTHER_TEMP_START = MCU_OTHER_TEMP_END,
    OTHER_BAL_RES_NTC1 = AFE_OTHER_TEMP_START,       ///< 均衡电阻1温度
    OTHER_BAL_RES_NTC2,                              ///< 均衡电阻2温度
    OTHER_BAL_RES_NTC3,       						 ///< 均衡电阻3温度
    OTHER_BAL_RES_NTC4,                              ///< 均衡电阻4温度
    OTHER_BAL_RES_NTC5,       						 ///< 均衡电阻5温度
    OTHER_BAL_RES_NTC6,                              ///< 均衡电阻6温度
    OTHER_BAL_RES_NTC7,       						 ///< 均衡电阻7温度
    OTHER_BAL_RES_NTC8,                              ///< 均衡电阻8温度	
    OTHER_POWER_NTC1,                                ///< 功率端子1温度
    OTHER_POWER_NTC2,                                ///< 功率端子2温度
    AFE_OTHER_TEMP_END,
    OTHER_NTC_NUM = AFE_OTHER_TEMP_END,
} other_ntc_type_e;

typedef enum
{
    PRODUCT_NON_BIG_TYPE = 0,
    PRODUCT_INV_BIG_TYPE,   // 并网逆变器
    PRODUCT_HYD_BIG_TYPE,       // 储能逆变器
    PRODUCT_ESS_BIG_TYPE,       // 集储
    PRODUCT_MR_BIG_TYPE,        // 微逆
    PRODUCT_IOT_BIG_TYPE,       // 物联网
    PRODUCT_BAT_BIG_TYPE,       // 电池包
    PRODUCT_ACCESSOR_BIG_TYPE,  // 配套件
    PRODUCT_CONVERTER_BIG_TYPE, // 变换器
    PRODUCT_BIG_TYPE_NUM,
} product_big_type_e;

typedef enum
{
    BAT_PRODUCT_NON = 0,
    BAT_PRODUCT_GTX5KS,
    BAT_PRODUCT_CBS5K_BCU,
    BAT_PRODUCT_BTS5K,
    BAT_PRODUCT_CBS5K_BOT,
    BAT_PRODUCT_CBS5K_BMU,
    BAT_PRODUCT_TYPE_NUM,
} product_bat_type_e;

/**
 * @brief 协议类型 Extended frames and standard frames
 * @warnning 参考 《电池协议类型编码》
 */
typedef enum
{
    NON_CAN_PROTOCOL = 0,  // 默认无协议
    EXT_PACE_HIGH_VOLT_PROTOCOL,    // 首航储能逆变器 高压BMS通用CAN协议(沛城扩展帧)
    STA_PACE_LOW_VOLT_PROTOCOL,     // 首航储能逆变器 低压BMS通用CAN协议(沛城标准帧)
    EXT_SOFAR_LOW_VOLT_PROTOCOL,    // 首航储能逆变器 低压BMS通用CAN协议(扩展帧)
    STA_SOFAR_LOW_VOLT_PROTOCOL,    // 首航储能逆变器 低压BMS通用CAN协议(标准帧)
    EXT_SOFAR_HIGH_VOLT_STACK_PROTOCOL,  // 首航通用标准CAN协议1.6 高压堆叠BMS通用CAN协议 125kw+CBS5000
    EXT_SOFAR_HIGH_VOLT_PROTOCOL,  // 首航储能逆变器 高压BMS通用CAN协议(扩展帧) 3ph+CBS5000
    BMS_CAN_PROTOCOL_NUM,
} bms_can_protocol_type_e;


/**************************************/

/**
 * @enum  adc_sample_index_e
 * @brief ADC 数据表索引定义
 * @warning adc_sample_index_e 必须要与底层实验要一致
 */
typedef enum
{
    SAMPLE_IDX_HW_VER = 0,                                ///< 机型识别
    SAMPLE_IDX_24V_VOLT,                              ///< 24V供电电压检测
    SAMPLE_IDX_5V_VOLT,                               ///< 5V辅助电压检测
    SAMPLE_IDX_PCB_TEMP,                              ///< PCB温度采集
    SAMPLE_IDX_FLAM_GAS,                              ///< 可燃气体检测
    SAMPLE_IDX_5V_OUT_VOLT,                           ///< 5V输出电压采集
    SAMPLE_IDX_END,
    SAMPLE_IDX_MAX = SAMPLE_IDX_END,
} adc_sample_index_e;

#ifndef SET_BIT
#define SET_BIT(a,b)	((a) |= (b)) 		
#endif

#ifndef CLR_BIT
#define CLR_BIT(a,b)	((a) &= ~(b)) 
#endif

#ifndef GET_BIT
#define GET_BIT(a,b)	((a) & (b))
#endif

#ifndef ITEM_NUM
#define ITEM_NUM(items) sizeof(items) / sizeof(items[0])
#endif

#ifndef TICK_1MS
#define TICK_1MS	os_tick_from_millisecond(1)
#endif

#ifndef TICK_5MS
#define TICK_5MS	os_tick_from_millisecond(5)
#endif

#ifndef TICK_10MS
#define TICK_10MS	os_tick_from_millisecond(10)
#endif

#ifndef TICK_100MS
#define TICK_100MS	os_tick_from_millisecond(100)
#endif

#ifndef TICK_300MS
#define TICK_300MS	os_tick_from_millisecond(300)
#endif

#ifndef TICK_500MS
#define TICK_500MS	os_tick_from_millisecond(500)
#endif

#ifndef TICK_1S
#define TICK_1S		os_tick_from_millisecond(1000)
#endif

#ifndef TICK_3S
#define TICK_3S		os_tick_from_millisecond(3000)
#endif

#define EVT_NULL              0xFF
#define STA_NULL              0xFF

// 无效值定义
#define U32_INVALID_VALUE    (0xFFFFFFFF)
#define I32_INVALID_VALUE    (0x80000000)
#define U16_INVALID_VALUE    (0xFFFF)
#define I16_INVALID_VALUE    (0x8000)   //-32768
#define U8_INVALID_VALUE     (0xFF)
#define I8_INVALID_VALUE     (0x80)

uint8_t app_run_success_flag_get(void);

#endif

