#ifndef __UPG_H__
#define __UPG_H__
#include <stdint.h>
#include <stddef.h>
#include "sdk_public.h"
#include "app_public.h"

/* 升级流程中使用的相关宏 */
#define BLOCK_MAX_DATA_SIZE 1024                                                   ///< 单个数据块大小为1K
#define BLOCK_TOTAL_MAX_NUM 1792                                                   ///< 数据块最大总数量为(128+64+256)K，单数据块最新256BYTE，最大适配到1024BYTE
#define BLOCK_PER_GROUP 24                                                         ///< 每24个数据块为一组
#define TRANSMIT_GROUP ((BLOCK_TOTAL_MAX_NUM + BLOCK_PER_GROUP) / BLOCK_PER_GROUP) ///< 传输组数，进1

#define BLOCK_NULL  0
#define BLOCK_ONE   1
#define BLOCK_TWO   2

#if 0
#define CHIP_MODEL_0 '3'       ///< 芯片型号编码 X0
#define CHIP_MODEL_1 'S'       ///< 芯片型号编码 X0
#define CHIP_ROLE_BMS_APP 0x2D ///< 0:ARM 1:DSPM 2:DSPS 3:BMS
#else
#define CHIP_MODEL_0 '0'       ///< 芯片型号编码 X0
#define CHIP_MODEL_1 'E'       ///< 芯片型号编码 X0
#define CHIP_ROLE_BMS_APP 0x2D ///< 0:ARM 1:DSPM 2:DSPS 3:BMS
#endif

#define CHIP_MODEL_ADDR	    126	///< 芯片编码地址


#define FILE_TYPE_APP 0     ///< 从bin签名信息获取 0:APP
#define FILE_TYPE_CORE 1    ///< 从bin签名信息获取 1:CORE
#define FILE_TYPE_PACK 0x80 ///< 从bin签名信息获取 0x80:PACK
#define BAK_PACK 								0x01
#define UPGRADE_PACK 							0x02

#define CORE_SIZE								0x00040000
#define APP_SIZE								0x00020000
/* 判断升级core或app的相关宏 */
#define NEW_UPG_FILE "1:new_file" ///< 初始定义的文件名称，后续数据存到该文件中
#define TEMP_BACKUP_FILE "1:temp_bak"   ///< 在没有备份文件时候的临时备份文件
// #define NEW_UPG_FILE	"app"
#define UPG_NONE_PROCESS_FLAG "pass"  ///< 当前升级流程标志:成功
#define UPG_CORE_PROCESS_FLAG "core"  ///< 当前升级流程标志:core
#define UPG_APP_PROCESS_FLAG "app"    ///< 当前升级流程标志:app
#define UPG_BACKUP_PROCESS_FLAG "bak" ///< 当前升级流程标志:备份文件

#define UPG_FILE_TYPE_NONE_FLAG "pass"   ///< 当前升级文件类型标志:成功
#define UPG_FILE_TYPE_CORE_FLAG "1:core" ///< 当前升级文件类型标志:core
#define UPG_FILE_TYPE_APP_FLAG "1:app"   ///< 当前升级文件类型标志:app
#define UPG_FILE_TYPE_BACKUP_FLAG "bak"  ///< 当前升级文件类型标志:备份文件

#define CORE_BACKUP_FILE "1:core_bak" ///< core备份文件
#define APP_BACKUP_FILE "1:app_bak"   ///< app备份文件
/* 数据区相关宏 */
#define UPG_PROCESS_FLAG_OFFSET_ADDR 0x3C   ///< 当前升级流程标志偏移地址
#define UPG_FILE_TYPE_FLAG_OFFSET_ADDR 0x40 ///< 当前升级文件类型标志偏移地址

/* 固件签名信息相关宏 */
#define FW_UPG_FILE_TYPE_OFFSET_ADDR 0x80 ///< 固件最后1K数据中 升级文件类型地址的偏移地址
#define FW_UPG_FILE_VER_OFFSET_ADDR 0x27 ///< 固件最后1K数据中 升级文件版本的偏移地址
#define FW_UPG_FILE_VER_LEN 20           ///< 固件最后1K数据中 升级文件版本字节大小

#define CRC_CHECK_SUM_F   0xB83AFFF4  //1k数据全为FF算出来的CRC32
#define CRC_CHECK_SUM_0   0xEFB5AF2E  //1k数据全为00算出来的CRC32

#define UPD_TYPE_NONE   0
#define UPD_TYPE_APP    1
#define UPD_TYPE_CORE   2
#define UPD_TYPE_COMB   3

typedef enum
{
    UPG_SUCCESS_MASK = 0x00,          ///< 升级成功
    UPG_FILE_CRC_FAIL_MASK = 0x01,    ///< 文件校验失败
    UPG_OTHER_REASON_FAIL_MASK = 0x02, ///< 其他原因失败
    UPG_ING_MASK = 0x03,                 ///< 升级中
    UPG_FINISH_MASK = 0x04,                 ///< 升级完成    
    UPG_INVALID_MASK = 0xFF,            //自己定义的无效值，与协议无关
} upgrade_end_result_e;
typedef enum
{
    UPG_FUN_QUERY	 = 0x01,    ///< 查询升级状态
    UPG_FUN_START = 0x02,    ///< 启动升级
    UPG_FUN_TEMP_STORAGE	 = 0x03,    ///< 暂存升级
    UPG_FUN_PROGRESS_BAR	 = 0x04,    ///< 文件传输进度
}upgrade_fun_e;

typedef enum
{
    UPG_IDLE = 0x00,    ///< 升级状态:未升级
    UPG_ING	 = 0x01,    ///< 升级状态:升级中
    UPG_FINISH = 0x02,    ///< 升级状态:升级结束
    UPG_ERR	 = 0x03,    ///< 升级状态:升级错误
    UPG_RESET = 0x04,    ///< 升级状态:升级完成重启
}upgrade_status_e;

typedef enum
{
    UPG_WRITE_BLOCK_DATA_IDLE = 0x00,    ///< 写升级块数据：空闲
    UPG_WRITE_BLOCK_DATA_START,          ///< 写升级块数据：开始接收
    UPG_WRITE_BLOCK_DATA_RECV_FINISH,    ///< 写升级块数据：数据接收完成
} upgrade_write_block_data_status_e;
/*******************************预充状态机相关start***********************************/
typedef enum
{
    EVT_UPG_STA_CPL_SUS,
    EVT_UPG_OPERATE_FAIL,
    EVT_UPG_TIMEOUT_OR_ERR,
    EVT_UPG_TEMPORARY,        // 暂存升级
    EVT_UPG_START,        // 升级开始
    EVT_UPG_BLOCK,        // 升级块数据
    EVT_UPG_CHECK,        // 升级结果校验
    UPG_EVT_NUM = 7,
}upgrade_fsm_event_e;

typedef enum
{
    UPG_WAIT_START = 0,       // 步骤0：未进行升级,等待升级中
    UPG_FILE_INFO,            // 步骤1：进入升级状态，关闭CAN发送，回复升级准备就绪指令
    UPG_BLOCK_DATA,           // 步骤3：接收当前数据块数据报文
    UPG_FILE_CHECK,           // 步骤4：回复接收成功与失败
    UPG_FILE_END,             // 步骤5：判断接收是否完成
    UPG_UPDATE_ERROR,         // 步骤6：升级异常
    UPG_UPDATE_FINISH,        // 步骤7：升级结束
    UPG_STA_NUM
}upgrade_fsm_state_e;

typedef struct
{
    uint32_t stat_cnt_time;  // 状态计时
    uint8_t stat_delay_cnt; // 升级状态等待计数
}upgrade_fsm_para_t; /* 升级状态机控制结构 */
/*******************************预充状态机相关end***********************************/
typedef struct
{
    uint8_t src_dev_type;   // 升级源设备类型
    uint8_t src_addr;      // 升级源地址
    uint8_t start_flag;   // 文件开始传输帧接收标志
    uint8_t block_data_flag;  // 接收到数据块标志
    uint8_t check_flag;   // 文件结果查询标志位
    uint8_t first_reply_start_flag;    // 首次回复升级开始传输帧标志
    uint8_t function_code_flag;                // 7FF Byte4功能码标志 01:查询 02:启动升级 03:暂存升级
    uint8_t upgrade_file_type_flag;            // 从上位机或PCS获取的升级文件类型标志
    uint8_t fw_upgrde_file_type_flag;          // BMS从固件签名信息获取的升级文件类型标志
    uint8_t query_flag;                        // 上位机或PCS查询固件的查询标志
    uint8_t upgrade_success_flag;              // 升级成功标志 00:成功 01:文件校验失败 02:其他原因失败
    uint8_t sure_clear_tarnsmit_bit_mask_flag; // 确认清除掩码标志
    uint8_t chip_role;                         // 确认为谁升级
    uint8_t upd_type;                           // 升级APP/CORE/APP AND CORE
    uint8_t upg_start_flag;                     // 接收升级启动帧，用于计数超时
    uint8_t block_data_info;                    // 接收到数据块信息头标志
    uint8_t end_flag;                           // 接收结束帧
    uint8_t write_block_state;                  // 写数据块状态
}upgrade_proc_para_t; /*升级过程接收到的CAN消息*/

typedef struct
{
	uint32_t file_size;											// 文件大小
	uint32_t file_check_sum;									// 文件校验和
	uint16_t block_total_num;									// 数据块总数量
	uint16_t block_size;										// 数据块总大小
	uint16_t block_send_cnt;									// 当前传输序号(0,1,2,3,4,5...)
	uint16_t block_data_len;									// 当前块大小
    #ifdef UPD_3PH_FLAG
    uint16_t block_data_index;                                  // 数据传输byte索引
    uint16_t block_crc;                                         // 当前块Crc校验值
    #endif
	uint8_t	 *block_upgrade_data;							// 当前块升级数据
}upgrade_data_info_t;


// firmware_msg_t 各固件信息
#pragma pack(push,1)
typedef struct
{
	uint8_t file_type;						// 文件类型
	uint8_t chip_role;						// 芯片角色
	uint8_t name[56];						// 固件包名称
	uint8_t addr[4];						// 起始偏移地址
	uint8_t length[4];						// 长度
	uint8_t version[20];					// 版本号
	uint8_t reserved[18];					// 预留
} firmware_msg_t;
/**
  * @enum   package_signing_msg_t
  * @brief  打包2K签名信息
  */
typedef struct
{
	uint8_t protocol_version;				// 协议版本号
	uint8_t company[16];					// 公司名称
	uint8_t product_line_code;				// 产品线编码
	uint8_t product_type_code[2];			// 产品型号编码
	uint8_t package_name[52];				// 固件包名称
	uint8_t release_time[6];				// 固件包打包日期
	uint8_t module_total;					// 固件模块数量
	uint8_t reserved1[58];					// 预留
	firmware_msg_t firmware_msg[18];		// 各固件信息
	uint8_t reserved2[31];					// 预留
	uint8_t package_length[4];				// 固件包总长
	uint32_t package_crc32;					// CRC32
} package_signing_msg_t;
#pragma pack(pop)

typedef struct
{
    uint8_t save_fw_file_flag; // 暂存固件的标志 00:无固件 01:存在固件
    uint8_t timing_flag;       // 定时器标志
    sdk_rtc_t count_down_time; // 定时器时间
}upgrade_flash_para_t;

/**
* @brief		升级模块参数初始化
* @param		无
* @return		无
* @retval		无
* @pre			无
*/
void upgrade_init(void);
/**
* @brief		升级任务处理
* @param		无
* @return		无
* @retval		无
* @pre			无
*/
void upgrade_task_proc(void);
/**
* @brief		设置使能升级标志
* @param		[in]使能标志： 0：不使能    1：使能  
* @return		无
* @retval		0：操作成功    < 0: 操作失败
* @pre			无
*/
int32_t upgrade_enable_state_set(uint8_t flag);
/**
* @brief		获取当前升级状态
* @param		无
* @return		执行结果
* @retval		0：未升级
* @retval		1：升级中
* @retval		2：升级完成 
* @retval		3：升级错误
* @pre			无
*/
uint8_t upgrade_state_get(void);
/**
* @brief		获取boot升级标志
* @param		无
* @return		执行结果
* @retval		boot升级标志
* @pre			无
*/
uint8_t boot_upgrade_flag_get(void);


uint16_t crc16_ccitt(uint8_t* p_src_data, uint32_t src_data_size);
#endif

