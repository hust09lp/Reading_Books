/**
 * @file     cup_sofar_can.h
 * @brief    公司自定义CAN协议拓展帧SDK接口
 * @author   duyumeng
 * @note     无
 * @version  V1.0
 * @date     2023/2/3
 */
#ifndef __SOFAR_CAN_MANAGE_H__
#define __SOFAR_CAN_MANAGE_H__

#include <stdint.h>
#include "app_public.h"

#define SDK_INTERNAL_CAN_PORT	0
#define SDK_RSV_CAN_PORT	1       //在2.0系统里用作与电解液漏液传感器通讯
#define SOFAR_CAN_TRS_BUF_NUMS	  8		// 接收缓冲区个数
#define SOFAR_CAN_FILE_BUF_NUMS	  2		// 文件接收缓冲区个数
#define CAN_MAX_DATA_LEN_ONE_FRAME   8     // can一帧最大数据长度
#define BROADCAST_DEVICE_ADDRESS    0x1F
#define BROADCAST_DEVICE_TYPE_ADDRESS    0xFF

//canbus通讯结果
#define SOFAR_CAN_RET_EMPTY       0       // 无发送数据
#define SOFAR_CAN_RET_WAIT        1       // 等待发送,任务调用发送时填入
#define SOFAR_CAN_RET_COMPILE	  2
/***********  需要应用按实际情况修改的内容 start  ***********/
#define BROADCAST_DEVICE_ADDRESS    0x1F

// frame priority
typedef enum {
    SOFAR_CAN_PRI_HIGH_H = 0,   // 最高优先级
	SOFAR_CAN_PRI_HIGH_L,       // 次高优先级
	SOFAR_CAN_PRI_LOW_H,        // 次低优先级
	SOFAR_CAN_PRI_LOW_L,        // 最低优先级
} frame_pri_e;

// device type  example
typedef enum {
    DEV_BMU = 0,       // BMU类型
    DEV_PCU = 1,       // PCU类型
    DEV_PCS = 2,       // PCS类型
    DEV_BCU = 4,       // BCU类型
    DEV_BDU = 5,       // BDU类型
    DEV_BROADCAST = 7, // 上位机/广播类型
} device_type_e;

#ifdef UPD_3PH_FLAG
#define ADDR_CONVERT	0	//用于将我们自身地址，转换成逆变器要求的地址(3PH)
#endif

/***********  需要应用按实际情况修改的内容  end  ***********/

//函数运行结果
#define CAN_RET_TURE				 1      //函数正确执行无错误，但数据没有接受完毕
#define CAN_DATA_COMPILE			 0		//函数正确执行完,数据接受完毕
#define CAN_RET_NUMERR				-1		//发送数据长度越限
#define CAN_RET_TRSERR				-2		//发送出错
#define CAN_RET_RECERR				-3		//接收出错
#define CAN_RET_TIMEOUT				-4		//超时未收到数据
#define CAN_RET_CRC_ERR				-5		//CRC校验错误
#define CAN_RET_PARA_ERR			-10		//入参异常

#define CAN_SOFAR_DATA_MAXNUMS		(1024)	//CAN数据最大长度,发送长度不能超过此数，升级文件小于1K
#define CAN_SOFAR_SEND_MAXNUMS		(100)		//CAN最长发送长度，不考虑升级，最多一次发送50个数据
#define CAN_SOFAR_FILE_DATA_MAXNUMS		(1024+8)		//CAN文件要考虑数据最大为1024，还需要带crc
#define CAN_SOFAR_LONG_POINT_DATA_RCV_MAX_TIME    (10)    // 10MS定时任务中运行，100ms超时
#define CAN_SOFAR_LONG_FILE_DATA_RCV_MAX_TIME    (100)    // 10MS定时任务中运行，1000ms超时
#define CAN_SOFAR_RCV_DATA_MAX_NUM_ONE_TIME       (20)   // 一次接收处理最多20帧报文

// frame func
typedef enum {
    // bcu设置以及bmu回复
    FUNC_MASTER_CTL_CMD               = 0x001,  // BMS控制信息1 
    FUNC_SLAVER_CTL_REPLY             = 0x002,  // BMS回复信息2 
    FUNC_MASTER_CURR_SET_CMD          = 0x060,  // BMS控制信息3-设置状态参数/电流
    FUNC_MASTER_BAL_SET_CMD           = 0x061,  // BMS控制信息4-均衡设置
    FUNC_HEART_BEAT_CMD               = 0x062,  // 心跳帧
    FUNC_MASTER_PASS_BAL_SET_CMD      = 0x063,  // BMS设置被动均衡
    FUNC_MAS_OTHER_DATA_SET_CMD       = 0x064,  // 主机其他信息设置，包括SOC放电末端校准使用，一般配合0x04C使用

    // bmu数据上报
    FUNC_BMS_INTER_INFO2              = 0x004,  // BMS发送电池信息2
    FUNC_BMS_INTER_INFO3              = 0x005,  // BMS发送电池信息3
    FUNC_BMS_INTER_INFO4              = 0x006,  // BMS发送电池信息4
    FUNC_BMS_INTER_INFO5              = 0x007,  // BMS发送电池信息5
    FUNC_BMS_FAULT_INFO1              = 0x008,  // BMS发送内部电池故障信息1
    FUNC_BMS_CELL_OTHER_INFO1         = 0x00E,  // 其他信息
    FUNC_BMS_INTER_INFO6              = 0x00F,  // BMS发送电池信息6
    FUNC_BMS_INTER_INFO7              = 0x040,  // BMS发送电池信息7
    //    FUNC_BAL_TEMP_INFO1               = 0x041,  // BMS均衡温度1-2         --均衡温度不再用该功能码
    FUNC_POWER_MOS_TEMP_INFO          = 0x04A,  // BMS功率端子温度
    FUNC_BMS_ALARM_TIPS_INFO          = 0x04B,  // BMS新增提示，告警
    FUNC_BMS_OTHER_DATA_INFO          = 0x04C,  // BMS其他信息上报，包括SOC放电末端校准信息
    FUNC_BMS_FAULT_INFO2              = 0x045,  // BMS发送内部电池故障信息2
    FUNC_BMS_REMOTE_SIGNAL_INFO1      = 0x046,  // 遥信数据上报1
    FUNC_BMS_REMOTE_SIGNAL_INFO2      = 0x047,  // 遥信数据上报2
    FUNC_ACT_BAL_INFO1                = 0x048,  // 主动均衡数据上报1
    FUNC_ACT_BAL_INFO2                = 0x049,  // 主动均衡数据上报2
    FUNC_SOFT_VER_INFO1               = 0x06A,  // 设备软件版信息1
    FUNC_SOFT_VER_INFO2               = 0x06B,  // 设备软件版信息2
    FUNC_SOFT_VER_INFO3               = 0x06C,  // 设备软件版信息3
    FUNC_BMS_REMOTE_SIGNAL_INFO3      = 0x06D,  // 其他数据上报
    FUNC_CELL_VOLT_OVERFLOW           = 0x070,  // 电芯电压
    FUNC_CELL_TEMP_OVERFLOW           = 0x071,  // 电芯温度
    FUNC_CELL_PASS_BAL_STATE_OVERFLOW = 0x072,  // 电芯被动均衡状态
    FUNC_CELL_BAL_TEMP_OVERFLOW       = 0x073,  // 被动均衡电阻温度
    FUNC_CELL_SOC_INFO                = 0x0A0,  // 单个电芯SOC
    FUNC_CELL_SOH_INFO                = 0x0A1,  // 单个电芯SOH
    // ate设置告警
    FUNC_ATE_CELL_VOLT_OVER_ALM_SET   = 0x010,  // 单体过充故障参数设置    
    FUNC_ATE_BAT_VOLT_OVER_ALM_SET    = 0x011,  // 总体过充故障参数设置    
    FUNC_ATE_CELL_VOLT_UNDER_ALM_SET  = 0x012,  // 单体过放故障参数设置    
    FUNC_ATE_BAT_VOLT_UNDER_ALM_SET   = 0x013,  // 总体过放故障参数设置    
    FUNC_ATE_CHG_CURR_OVER_ALM_SET    = 0x014,  // 充电过流故障参数设置    
    FUNC_ATE_DCHG_CURR_OVER_ALM_SET   = 0x015,  // 放电过流故障参数设置    
    FUNC_ATE_CELL_TEMP_OVER_ALM_SET   = 0x016,  // 电芯高温故障参数设置    
    FUNC_ATE_CELL_TEMP_UNDER_ALM_SET  = 0x017,  // 电芯低温故障参数设置    
    FUNC_ATE_SOC_LOW_ALM_SET          = 0x019,  // 低电量故障参数设置      
    FUNC_ATE_BAT_CURR_OVER_ALM_2_SET  = 0x01B,  // 充放电二级故障参数设置
    FUNC_ATE_CELL_VOLT_ERR_ALM_SET    = 0x01C,  // 单体超限超低故障参数设置
    FUNC_ATE_OTHER_CELL_ALM_SET       = 0x01D,  // 其他电芯告警参数设置
    FUNC_ATE_CELL_VOLT_TIP_SET        = 0x080,  // 单体电压过充、过放提示标定
    FUNC_ATE_CELL_VOLT_DIFF_1_SET     = 0x081,  // 单体电压压差过大提示、告警标定
    FUNC_ATE_CELL_VOLT_DIFF_2_SET     = 0x082,  // 单体电压压差过大故障标定
    FUNC_ATE_CELL_TEMP_TIP_SET        = 0x083,  // 电芯温度充放电高低温提示标定
    FUNC_ATE_CELL_TEMP_DIFF_SET       = 0x084,  // 电芯温差过大提示，告警、保护标定
    FUNC_ATE_BATT_VOLT_TIP_SET        = 0x085,  // 总压过压欠压提示标定

    // ate设置其他控制和标定
    FUNC_ATE_FLASH_TEST               = 0x01F,  // ATE_FLASH测试           
    FUNC_ATE_SET_OLD_MODE             = 0x020,  // 上位机控制老化状态
    FUNC_ATE_BAL_HEAT_PARAM_SET       = 0x021,  // 均衡加热膜参数标定      
    FUNC_ATE_CELL_VOLT_CURR_LIMIT_SET = 0x022,  // 截至电压电流参数标定    
    FUNC_ATE_CELL_NUM_SET             = 0x023,  // 额定容量电芯个数参数标定
    FUNC_ATE_CHG_DSG_CAP_SET          = 0x024,  // 累计充放电电量参数标    
    FUNC_ATE_SOX_SET                  = 0x025,  // SOX参数标               
    FUNC_ATE_SYS_TIME_SET             = 0x026,  // 时间标定                
    FUNC_ATE_PACK_SN_SET              = 0x027,  // PACK_SN标定             
    FUNC_ATE_BOARD_SN_SET             = 0x028,  // BOARD_SN标定            
    FUNC_ATE_CELL_INFO_SET            = 0x029,  // 设置电池信息            
    FUNC_ATE_CALI_PARAM_SET           = 0x02A,  // 校准系数标定            
    FUNC_ATE_BMU_FUNC_SET             = 0x02B,  // BMU功能开关             
    FUNC_ATE_MONITOR_DATA_READ        = 0x02C,  // 上位机监控读取    
    FUNC_ATE_CLR_HISTORY_DATA         = 0x02D,  // 一键清除历史故障            
    FUNC_ATE_READ_SET_DATA            = 0x02E,  // 一键操作标定参数        
    FUNC_ATE_FORCE_CTL_SET            = 0x02F,  // ATE强制控制指令         
    FUNC_ATE_FORCE_CTL_SET_2          = 0x01E,  // ATE强制控制指令2
    FUNC_ATE_TEST_INFO                = 0x030,  // ATE测试结果    

    // 文件读取
    FUNC_UP_FILE_START                 = 0x7F0, // 读取文件传输开始帧
    FUNC_UP_FILE_DATA_BLOCK_START      = 0x7F1, // 读取数据块开始帧
    FUNC_UP_FILE_DATA_TRAN             = 0x7F2, // 读取数据块数据帧
    FUNC_UP_FILE_DATA_BLOCK_CRC        = 0x7F3, // 读取文件接收结果查询帧
    FUNC_UP_FILE_FINISH_QUERY          = 0x7F4,  //读取文件完成状态查询帧
    // 升级信息
    FUNC_DOWN_FILE_TIME                 = 0x7FA, // 升级文件定时升级
    FUNC_DOWN_FILE_START                = 0x7FB, // 升级文件传输开始帧
    FUNC_DOWN_FILE_DATA_BLOCK_START     = 0x7FC, // 升级数据块开始帧
    FUNC_DOWN_FILE_DATA_TRAN            = 0x7FD, // 升级数据块数据帧
    FUNC_DOWN_FILE_RESULT_CHECK         = 0x7FE, // 升级文件接收结果查询帧
    FUNC_DOWN_FILE_FINISH_QUERY         = 0x7FF, // 升级完成状态查询帧
    
} frame_func_e;

//CAN id msg
typedef struct 
{
	uint8_t src_addr;		// source address
	uint8_t src_type;		// source device type
	uint8_t dst_addr;		// destination address
	uint8_t dst_type;		// destination device type	
	uint8_t fun_code;		// CAN Frame function code
	uint8_t prio;			// CAN Frame fun_code priority	
}can_msg_t;

//CAN id msg
typedef union{
	uint32_t id_val;
	struct{
		uint32_t src_addr:	5;	// source address
		uint32_t src_type:	3;	// source device type
		uint32_t dst_addr:	5;	// destination address
		uint32_t dst_type:	3;	// destination device type
		uint32_t fun_code:	11;	// < CAN Frame function code
		uint32_t prio:		2;	// < CAN Frame fun_code priority
		uint32_t res: 		3;	// < Reserved. 
	}bit;
}can_frame_id_u;

typedef struct
{
	uint32_t 			id;             ///< id
	uint8_t 			data_len;		///< 数据长度
    uint8_t 			data[8];		///< 数据						
}can_frame_data_t;

typedef int32_t(*can_sofar_parse_callback)(can_frame_data_t *frame_data);

/**
  * @struct can_rec_reg_t
  * @brief can接收注册
  */
typedef struct
{
    uint32_t 			id;             ///< id
    uint32_t 			id_mask;		///< id掩码						
    can_sofar_parse_callback  p_can_cb;		///< 注册的回调函数
}can_sofar_rcv_reg_t;

/**
* @brief		初始化can管理
* @param		无
* @return		返回结果
* @retval		0：成功    < 0: 失败
* @warning		无 
*/
int32_t can_sofar_manage_init(void);

/**
 * @brief   发送CAN数据打包发送
 * @param   [in] index  CAN 口编号
 * @param   [in] can_msg  CAN ID信息
 * @param   [in] p_data  需要发送的数据
 * @param   [in] len  需要发送的数据长度
 * @note    调用此函数之前需要APP层自己调用打开CAN的SDK接口
 * @return  返回执行结果 0:正常；<0:异常
 * @warn    允许多帧数据发送
 */
int32_t can_sofar_send_frame(uint32_t index, uint32_t can_id, uint8_t *p_data, int32_t len);

/**
 * @brief   发送CAN数据接收
 * @param   [in] index  CAN 口编号
 * @param   [in] timeout_ms  读取超时时间设置
 * @param   [out] can_id_msg  接收数据的CAN ID信息
 * @param   [out] p_data  接收的数据
 * @param   [out] len  接收数据的长度
 * @note    调用此函数之前需要APP层自己调用打开CAN的SDK接口，收到完整数据包之后将数据返回
 * 			返回的数据根据不同的功能码有以下不同的情况（只有数据包时的数据帧p_data才仅是真正的数据）
 * 			p_data:数据帧时对应的是解析组包之后的数据；请求和应答帧时是应答和请求的帧数据内容
 * @return  返回执行结果 0:正常；<0:异常
 */
void can_sofar_manage_proc(void);

/**
* @brief		注册can接收回调函数
* @param		[in] port：	外部CAN：EXTERNAL_CAN  /  内部CAN：INTERNAL_CAN  
* @param		[in] urgent_flag:紧急处理标志  GENERAL_FRAME:接收到数据正常响应速度10ms ，URGENT_FRAME:接收数据快速响应1ms
* @param		[in] p_can_rec_reg ：
* @param		[in] id：can帧id 
* @param		[in] id：id_mask：过滤不需要接收的位(标准帧的掩码mask固定为0x00000000,拓展帧的掩码mask目标地址设置为FF代表能接收0xFF,0x1F,pack_addr三种类型地址)
* @param		[in] id：can_cb：回调解析函数 
* @param		[in] reg_cnt：注册的数量 
* @return		返回结果
* @retval		0：注册成功    < 0: 注册失败
* @warning		禁止重复注册同一个ID
* @warning		标准帧注册掩码必须为0x00000000
* @warning		掩码不可为0xFFFFFFFF
*/
int32_t inner_can_sofar_register_receive_frame(can_sofar_rcv_reg_t * p_can_rec_reg, uint16_t reg_cnt);

/**
* @brief		注册can接收回调函数
* @param		[in] port：	外部CAN：EXTERNAL_CAN  /  内部CAN：INTERNAL_CAN  
* @param		[in] urgent_flag:紧急处理标志  GENERAL_FRAME:接收到数据正常响应速度10ms ，URGENT_FRAME:接收数据快速响应1ms
* @param		[in] p_can_rec_reg ：
* @param		[in] id：can帧id 
* @param		[in] id：id_mask：过滤不需要接收的位(标准帧的掩码mask固定为0x00000000,拓展帧的掩码mask目标地址设置为FF代表能接收0xFF,0x1F,pack_addr三种类型地址)
* @param		[in] id：can_cb：回调解析函数 
* @param		[in] reg_cnt：注册的数量 
* @return		返回结果
* @retval		0：注册成功    < 0: 注册失败
* @warning		禁止重复注册同一个ID
* @warning		标准帧注册掩码必须为0x00000000
* @warning		掩码不可为0xFFFFFFFF
*/
int32_t rsv_can_sofar_register_receive_frame(can_sofar_rcv_reg_t * p_can_rec_reg, uint16_t reg_cnt);

/**
* @brief		can过滤器设置
* @param		无  
* @return		无
* @retval		无
* @warning		无
*/
void can_set_filter(uint8_t addr);

/** 
 * @brief        打印信息设置函数
 * @param        [in] flag 打印信息设置函数，0不打印，1打印
 * @return       [int32_t] 执行结果
 * @retval       =0  设置成功 
 * @retval       < 0 失败原因
 */
int32_t can_sofar_debug_set(int8_t flag);
#endif
