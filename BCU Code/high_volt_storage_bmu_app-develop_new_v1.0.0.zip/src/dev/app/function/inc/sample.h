/**
    * @file     sample.h
    * @brief    电池数据采样文件
    * @company  sofarsolar
    * @author   刘吕从
    * @note
    * @version
    * @date     2023/4/24
*/

#ifndef __SAMPLE_H__
#define __SAMPLE_H__

#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include "app_public.h"

#define APP_SAMPLE_TEST   // shell debug

#define TEMP_TABLE_SIZE        (sizeof(g_ntc_res_table) / sizeof(g_ntc_res_table[0])) ///< NTC电阻表格
#define REF_VOLT                3300        ///< 参考电压       单位1mV
#define SAMP_VOLT               3300        ///< 采集电压       单位1mV  
#define BAT_TEMP_OFFSET         400         ///< 温度偏移量      单位0.1℃
#define BAT_CURR_OFFSET         300000      ///< 电流偏移量30000，单位1mA  
#define ADC_FILTER_NUM          12          ///< ADC滤波数量
// 充放电电流校准参数
#define BAL_CURR_M_RES_BIG_TIME   (10)
#define BAL_CURR_M_RES            (25)        ///< 单位0.1毫欧
#define BAL_CURR_BIG_TIME         (1000)      ///< 100KΩ 运算放大倍率, 当前单位为0.1KΩ，必须与 BAL_CURR_BIG_DIV_TIME 单位一致
#define BAL_CURR_BIG_DIV_TIME     (33)        ///< 3.3kΩ 运算放大倍率，, 当前单位为0.1KΩ，必须与 BAL_CURR_BIG_TIME 单位一致
#define BAL_CURR_SOFTWARE_GAIN    (20)       ///< 电流软件放大倍数：4294967296(2的32次方)/分辨率(max:4096)/REF_VOLT(参考电压3000mV)/(BAL_VOLT_HARDWARE_GAIN*1000)/1.2 ≈22(仅在计算电压使用，校准不使用)
#define BAL_CURR_HARDWARE_GAIN    BAL_CURR_BIG_DIV_TIME * BAL_CURR_M_RES_BIG_TIME / BAL_CURR_M_RES / BAL_CURR_BIG_TIME   ///< 单位1/mΩ, 只能乘不能被除， 不能加括号
#define BAL_CURR_GAIN           (BAL_CURR_SOFTWARE_GAIN * REF_VOLT * BAL_CURR_HARDWARE_GAIN )
#define CHG_CALI_GAIN_L         (BAL_CURR_GAIN * 8 / 10)       ///< 充电电流校准增益80%      理论值750*80% 为提高精度放大30倍
#define CHG_CALI_GAIN_H         (BAL_CURR_GAIN * 12 / 10)      ///< 充电电流校准增益120%     理论值750*120% 为提高精度放大30倍
#define DSG_CALI_GAIN_L         (BAL_CURR_GAIN * 8 / 10)       ///< 放电电流校准增益80%      理论值750*80%   为提高精度放大30倍
#define DSG_CALI_GAIN_H         (BAL_CURR_GAIN * 12 / 10)      ///< 放电电流校准增益120%     理论值750*120%   为提高精度放大30倍
// 均衡电压校准参数
#define BAL_VOLT_SOFTWARE_GAIN    (10)       ///< 电压软件放大倍数：4294967296(2的32次方)/分辨率(max:4096)/REF_VOLT(参考电压3000mV)/BAL_VOLT_HARDWARE_GAIN/1.2 ≈10(仅在计算电压使用，校准不使用)
#define BAL_VOLT_HARDWARE_GAIN    (1076) / (56)       ///< 510+510+56/56 = 19.2, 只能乘不能被除
#define BAL_VOLT_GAIN            (REF_VOLT * BAL_VOLT_SOFTWARE_GAIN * BAL_VOLT_HARDWARE_GAIN)
#define BAL_VOLT_CALI_GAIN_L     (BAL_VOLT_GAIN * 8 / 10)        ///< 放电电流校准增益80%      理论值33600*80%   为提高精度放大30倍
#define BAL_VOLT_CALI_GAIN_H     (BAL_VOLT_GAIN * 12 / 10)       ///< 放电电流校准增益120%     理论值33600*120%   为提高精度放大30倍
// 24V供电电压硬件放大倍率
#define BAT_24V_VOLT_HARDWARE_GAIN (1076) / (56)  // （510+510+56)/56  只能乘,不能被除

#define SAMPLE_STATE_OK               0      ///< 采集状态获取成功
#define SAMPLE_STATE_EOI              1      ///< 采集状态获取失败
#define COPPER_RES                    50      ///< 微欧
//#define BALANCE_TEMP_NUM              2      ///< 均衡温度数量

/**
 * @enum adjust_para_tab_e 
 * @brief 校准参数表
 */
typedef enum
{
    CHG_CURR_GAIN = 0,         ///< 充电电流增益
    DSG_CURR_GAIN,             ///< 放电电流增益  
    BALANCE_VOLT_GAIN,         ///< 均衡母线电压增益 
    ADJUST_PARA_NUM,
    ADJUST_ACT_PARA_NUM = 8,   ///< 预留8个位置用于后续增加校准参数
} adjust_para_tab_e;

/**
 * @enum mcu_temp_ntc_e 
 * @brief mcu直采温度枚举
 */
typedef enum
{
    MCU_PCB_TEMP_NTC = 0,         ///< 板子温度
    MCU_NTC_NUM ,                 ///< mcu直采温度个数
} mcu_temp_ntc_e;

/**
 * @struct adjust_para_tab_t 
 * @brief 校准参数表
 */
typedef struct
{
    uint32_t adjust_para_gain[ADJUST_ACT_PARA_NUM];     ///<  增益
} adjust_para_tab_t;

//电解液传感器解析报文
typedef struct
{
    uint16_t electrolyte_stren;             // 浓度
    uint8_t error;  // 0:正常 非0:故障
    uint8_t tick;         // 传感器自带的计数
    uint8_t crc;
    
    uint16_t cnt;   //用于做通讯失联计数
    uint8_t com_abnor_flag; //
}electrolyte_sensor_info_t;

/**
  * @struct    bat_sample_data_t
  * @brief  电池采样数据管理
  */
#pragma pack(1)
typedef struct
{
    int16_t    adc_sample_other_temp[MCU_NTC_NUM];        /// mcu 直采温度，单位0.1℃
    uint32_t   check_5v_volt;                             ///< 5V电压检测      单位1mV
    uint32_t   check_24v_volt;                            ///< 24V电压检测    单位1mv
    uint32_t   hardware_version_volt;                     ///< 硬件版本号识别  单位1mV 
    uint32_t   flam_smoke_dect_volt;                        ///< 可燃气体电压    单位1mv
    uint32_t   check_5v_out_volt;                            ///< 5V输出电压检测    单位1mv
    electrolyte_sensor_info_t electrolyte_sensor_data;                  ///< 烟雾传感器相关数据
}sample_data_t;
#pragma pack()

/**
* @brief                ADC采样初始化
* @param                [in]无
* @return               无返回结果
* @warning              无
*/
void sample_init(void);

/**
* @brief        校准参数计算
* @param        [in] adjust_para_tab_e adjust_para_type 校准参数类型
* @param        [in]uint32_t cali_value 校准值
* -# 电流值      单位10mA  
* -# 电压值      单位0.1V
* @param        [in]adjust_para_tab_t *adjust_para_tab 校准结果值
* @return        返回结果
* @retval        [out] ret(0)  校准计算成功
* @retval        [out] ret(-1) 空指针校准计算失败
* @retval        [out] ret(1)  校准增益超出范围或校准类型无效计算失败
* @warning
*/
int32_t sample_adjust_cali_deal(adjust_para_tab_e adjust_para_type,uint32_t cali_value, adjust_para_tab_t *p_adjust_para_tab);

/**
* @brief                采样校准参数设置
* @param                [in]adjust_para_tab_t *adjust_para_tab 校准参数表结构体
* @return               返回结果
* @retval               [out]ret(0)  设置成功
* @retval               [out]ret(-1) 设置失败
* @warning              无
*/
int32_t sample_adjust_set(adjust_para_tab_t *adjust_para_tab);

/**
 * @brief      采样异常状态获取
 * @param      [in]abnormal_type_e
 * @return     返回结果
 * @retval     [out]ret(SAMPLE_STATE_OK)  获取采集状态成功
 * @retval     [out]ret(SAMPLE_STATE_EOI) 获取采集状态失败
 * @retval     [out]ret(NTC_SHORT_CIRCUIT) NTC短路
 * @retval     [out]ret(NTC_OPEN_CIRCUIT)  NTC开路
 * @warning    在采集任务开始以后调用
 */
int32_t mcu_sample_abnormal_get(other_ntc_type_e type);

/**
* @brief                获取电池采样信息
* @param                [in]bat_sample_data_t *p_data 电池采样数据结构体指针
* @return               返回结果
* @retval               ret(-1)获取失败
* @retval               ret(0)获取成功
* @warning              无
*/
int32_t sample_data_get(sample_data_t *p_data);

/**
* @brief                获取电池采样信息
* @param                [in]无
* @return               const sample_data_t *
* @retval               NULL获取失败
* @retval               ret(!NULL)获取成功
* @warning              无
*/
const sample_data_t *sample_data_p_get(void);

/**
 * @brief                电池采样任务
 * @param                [in]void
 * @return               返回结果空
 * @retval               [out]无
 * @warning              放在10ms任务，必须要调用sample_data_init()后使用
 */
void sample_proc(void);

/**
* @brief                查表计算得到温度（无偏移）
* @param                [in]uint16_t res_data        电阻值
* @param                [in]uint16_t *ntc_res_table  NTC阻值表
* @param                [in]uint16_t temp_table_size 阻值表大小
* @param                [in]uint16_t temp_offset     温度偏移量
* @return               返回温度值
* @retval               [out]
* @warning              无
*/
int16_t res_to_temp(uint16_t res_data, const uint16_t *ntc_res_table, uint16_t temp_table_size, uint16_t temp_offset);

/**
* @brief                获取采样码值
* @param                SAMPLE_NON_IDX = 0,                               ///< 此通道空
* @param                SAMPLE_IDX_24V_POWER,                             ///< 24V供电
* @param                SAMPLE_IDX_9V_VOLT,                               ///< 9V辅助电压检测
* @param                SAMPLE_IDX_24V_VOLT,                              ///< 24V辅助电压检测/均衡母线电压
* @param                SAMPLE_IDX_BAL_RES_TEMP_1,                        ///< 均衡电阻温度1,需提供NTC表 
* @param                SAMPLE_IDX_HW_VER,                                ///< 机型识别
* @param                SAMPLE_IDX_PCB_TEMP,                              ///< PCB温度采集
* @param                SAMPLE_IDX_BAL_RES_TEMP_2,                        ///< 均衡电阻温度2,需提供NTC表
* @param                SAMPLE_IDX_3V_VOLT,                               ///< 3V采样
* @return               返回结果
* @retval               ret(-1)获取失败
* @retval               ret(0)获取成功
* @warning              无
*/
uint16_t sample_data_code_get(uint8_t code_type);


/**
 * @brief                获取硬件版本号
 * @param                [in]无
 * @return               [out] void
 * @warning              必须确保片内adc已经完成采样
 */
int16_t hardware_ver_get(void);

/**
* @brief                获取主动均衡瞬时值参数
* @param                [in]p_balance_volt 输出均衡电压指针
* @param                [in]p_balance_curr 输出均衡电流指针
* @return               返回结果
* @retval               ret(-1)获取失败
* @retval               ret(0)获取成功
* @warning              无
*/
int32_t instant_balance_data_get(uint32_t *p_balance_volt, int32_t *p_balance_curr);

/**
 * @brief                ntc异常判断
 * @param                [in]res_value        需要判断的电阻值
 * @param                [in]res_temp_table   需要查的表格
 * @param                [in]table_size       表格元素个数
 * @return               返回结果
 * @retval               [out]ret(SAMPLE_STATE_OK)  获取采集状态成功
 * @retval               [out]ret(SAMPLE_STATE_EOI) 获取采集状态失败
 * @retval               [out]ret(NTC_SHORT_CIRCUIT) NTC短路
 * @retval               [out]ret(NTC_OPEN_CIRCUIT)  NTC开路
 * @retval               [out]ret(AFE_ERR)           AFE异常
 * @warning              在采集任务开始以后调用
 */
int32_t sample_res_ntc_abnormal_judge(uint16_t res_value, const uint16_t *p_res_temp_table, uint16_t table_size);
#endif

