#ifndef __AFE_MANAGEMENT_H__
#define __AFE_MANAGEMENT_H__

#include <stdint.h>
#include "afe_bq79616.h"
#include "afe_bq79600.h"
#include "app_public.h"

#define AFE_TASK_MS 10

/**
 * @enum afe_collect_t
 * @brief afe采集数据
 */
typedef struct
{
	int16_t cell_volt[AFE_CELL_VOLT_NUM];					  ///< 单节电芯电压
	int16_t cell_temp[AFE_CELL_TEMP_NUM];					  ///< 电芯温度
    //	int16_t channel1_other_temp[AFE_CHANNEL1_OTHER_TEMP_NUM]; ///< 电芯温度 //预留温度没有实际使用，故不管
//	int16_t channel2_other_temp[AFE_CHANNEL2_OTHER_TEMP_NUM]; ///< 其他温度     //预留温度没有实际使用，故不管
	int16_t balance_temp[AFE_BALANCE_TEMP_NUM];				  ///< 均衡温度温度
	int16_t pwr_temp[AFE_POWER_TEMP_NUM];					  ///< 功率端子温度
	uint32_t battery_volt;									  ///< 电池电压
} afe_collect_t;

typedef enum
{
    #if PACK_64S_PRJ
    CELL_TEMP_POS = 0,  //64S 项目里afe的channle2还需要采一个温度点
    #endif
    PWR_TEMP_POS = 2,
    BALANCE_TEMP1_POS = 4,
    BALANCE_TEMP2_POS = 5,
} select_channel2;

/**
 * @enum balance_data_t
 * @brief 均衡数据
 */
typedef struct
{
	uint32_t balance_state;
	uint32_t balance_ctrl_flag;
} balance_data_t;

/**
 * @enum temp_res_data_t
 * @brief 温度数据
 */
typedef struct
{
	uint16_t afe_chan1_temp_res_buf[AFE_CHANNEL1_TEMP_TOTAL_NUM];
	uint16_t afe_chan2_temp_res_buf[AFE_CHANNEL2_TEMP_TOTAL_NUM];
} temp_res_data_t;

/**
 * @enum daisy_chain_data_t
 * @brief 菊花链数据
 */
typedef struct
{
	uint8_t chain_break_flag;
	uint8_t chain_break_forward_pos;
	uint8_t chain_break_reverse_pos;
	uint8_t direction_flag;
	uint8_t current_stack_boards;
	uint8_t reserve;
} daisy_chain_data_t;

typedef enum
{
    EVT_AFE_STA_CPL_SUS,
	EVT_AFE_WIRE_OPEN_CHECK,
	EVT_AFE_CHAIN_BREAK_CHECK,	
    EVT_AFE_TIMEOUT_OR_ERR,//ERR
	EVT_AFE_WAKEUP,
	EVT_AFE_SHUTDOWN,
    EVT_AFE_NUM,
}afe_fsm_event_e;

typedef enum
{
	STATE_AFE_IDIE,		   ///< 空闲状态跑空，等待用户启用afe
	STATE_AFE_WAKEUP,	   ///< 唤醒afe
	STATE_AFE_INIT,		   ///< 初始化afe
	STATE_AFE_NORMAL,	   ///< 进行数据采集，均衡，afe异常检测，以及状态切换等
	STATE_AFE_WIRE_OPEN,   ///< 断线检测状态
	STATE_AFE_CHAIN_BREAK, ///< 断链检测状态
	STATE_AFE_ERR,		   ///< afe异常状态，afe异常后的数据处理
	STATE_AFE_SHUTDOWN,	   ///< afe关机状态
	STATE_AFE_NUM,
} afe_fsm_state_e;

typedef struct
{
	uint8_t afe_wakeup_flag;
    uint8_t afe_shutdown_flag;

    uint8_t idle_print_first_flag;
    uint8_t err_print_first_flag;

	uint8_t addr_retry_counter;
	uint8_t wakeup_retry_counter;
	uint8_t cfg_retry_counter;
	uint8_t read_retry_counter;
	uint8_t wire_open_check_fail_counter;  //断线检测失败
	uint8_t chain_break_mulit_retry_counter;	

}afe_fsm_para_t;

typedef enum
{
	AFE_IDIE_STATE,				 ///< 空闲状态跑空，等待用户启用afe
	AFE_WAKEUP_BRI_STATE,		 ///< 唤醒桥接芯片
	AFE_WAKEUP_AFE_STATE,		 ///< 唤醒afe
	AFE_AUTO_ADRESS_STATE,		 ///< 自动编址
	AFE_INIT_STATE,				 ///< 初始化afe
	AFE_ERR_STATE,				 ///< afe异常状态，afe异常后的数据处理    
	AFE_RUN_STATE,				 ///< 进行数据采集，均衡，afe异常检测，以及状态切换等
	AFE_SHUTDOWN_STATE,			 ///< afe关机状态
	AFE_WIRE_OPEN_CHECK_STATE,	 ///< 断线检测状态
	AFE_CHAIN_BREAK_CHECK_STATE, ///< 断链检测状态
	AFE_STA_NUM,
} afe_state_e;

/**
 * @enum afe_abnormal_e
 * @brief afe异常
 */
typedef enum
{
	AFE_ERR_NONE = 0,			  // 无异常
	AFE_ERR_WAKEUP,				  // 唤醒异常
	AFE_ERR_AUTO_ADDR,			  // 自动编址异常
	AFE_ERR_COMM_INIT,			  // 通信接口初始化异常
	AFE_ERR_CONFIG,				  // afe初始化异常
	AFE_ERR_COMMUNICATION,		  // 运行过程中通讯异常
	AFE_ERR_WIRE_OPEN,			  // 断线
	AFE_ERR_CHAIN_BREAK,		  // 断链
	AFE_ERR_CHAIN_BREAK_MULTIPLE, // 多处断链
} afe_abnormal_e;

/**
 * @brief		获取afe初始化
 * @param		无
 * @return		无
 * @retval		无
 * @warning		无
 */
void afe_init(void);

/**
 * @brief		afe管理
 * @retval		无
 * @retval		无
 * @warning		无
 */
void afe_management(void);

/**
 * @brief		获取采集数据
 * @param		无
 * @return		无
 * @retval		无
 * @warning		需要判断NULL
 */
const afe_collect_t *p_afe_collect_data_get(void);

/**
 * @brief		设置afe状态
 * @param		[in]将要设置的状态
 * @return		无
 * @retval		无
 * @warning		无
 */
void afe_state_set(afe_state_e state);

/**
 * @brief		获取当前afe状态
 * @param		[out]外部afe状态指针
 * @return		无
 * @retval		无
 * @warning		无
 */
afe_state_e afe_state_get(void);

/**
 * @brief		判断afe是否异常
 * @param		无
 * @return		afe异常标志位
 * @retval		HAL_OK(0) 无异常
 * @retval		HAL_EIO(<0) 异常
 * @warning		无
 */
afe_abnormal_e afe_abnormal_state_get(void);

/**
 * @brief                进入afe测试模式
 * @return               返回结果空
 * @warning              测试调试使用
 */
int32_t shell_in_afe_proc(char *cmd, uint8_t len);

#endif
