#ifndef __BQ79600_H__
#define __BQ79600_H__

#include <stdint.h>
#include "afe_manage.h"
#include "afe_bq79600_comm.h"

typedef enum
{
    TEMP_CELL_WIRE =    0x00,
    TEMP_BAL_WIRE  =    0x01,
    TEMP_PWR_WIRE  =    0x02,
    TEMP_OTH_WIRE  =    0x03,
    TEMP_TOTAL_TYPE=    0x04,
} afe_temp_wire_type;

typedef enum
{
	AFE_WO_CHECK_INIT = 0, // 判断是否启动断线检测
	AFE_WO_CHECKING,	   // 启动断线检测
	AFE_WO_OVER_TIME,	   // 获取断线结果
	AFE_WO_OVER_ERR,	   // 断线检测结束
	AFE_WO_NORMAL,
	AFE_WO_ABNORMAL,
} afe_wire_open_result;

#define AFE_VC_READ_REG_ERR (-1)
#define AFE_VC_CHECK_FINISH  (0)
#define AFE_VC_CHECKING      (1)
#define AFE_VC_RECHECK       (2)

//BQ79600-Q1 REGISTER DEFINES
#define Bridge_DIAG_CTRL               0x2000
#define Bridge_DEV_CONF1               0X2001
#define Bridge_DEV_CONF2               0X2002
#define Bridge_TX_HOLD_OFF             0X2003
#define Bridge_SLP_TIMEOUT             0X2004
#define Bridge_COMM_TIMEOUT            0X2005
#define Bridge_SPI_FIFO_UNLOCK         0X2010
#define Bridge_FAULT_MSK               0X2020
#define Bridge_FAULT_RST               0X2030
#define Bridge_FAULT_SUMMARY           0X2100
#define Bridge_FAULT_REG               0X2101
#define Bridge_FAULT_SYS               0X2102
#define Bridge_FAULT_PWR               0X2103
#define Bridge_FAULT_COMM1             0X2104
#define Bridge_FAULT_COMM2             0X2105
#define Bridge_DEV_DIAG_STAT           0X2110
#define Bridge_PARTID                  0X2120
#define Bridge_DIE_ID1                 0X2121
#define Bridge_DIE_ID2                 0X2122
#define Bridge_DIE_ID3                 0X2123
#define Bridge_DIE_ID4                 0X2124
#define Bridge_DIE_ID5                 0X2125
#define Bridge_DIE_ID6                 0X2126
#define Bridge_DIE_ID7                 0X2127
#define Bridge_DIE_ID8                 0X2128
#define Bridge_DIE_ID9                 0X2129
#define Bridge_DEBUG_CTRL_UNLOCK       0X2200
#define Bridge_DEBUG_COMM_CTRL         0X2201
#define Bridge_DEBUG_COMM_STAT         0X2300
#define Bridge_DEBUG_SPI_PHY           0X2301
#define Bridge_DEBUG_SPI_FRAME         0X2302
#define Bridge_DEBUG_UART_FRAME        0X2303
#define Bridge_DEBUG_COMH_PHY          0X2304
#define Bridge_DEBUG_COMH_FRAME        0X2305
#define Bridge_DEBUG_COML_PHY          0X2306
#define Bridge_DEBUG_COML_FRAME        0X2307

void bq79600_data_init(void);
int32_t bq79600_config_init(void);
int32_t bq79600_auto_address(void);
int32_t bq79600_collect_cell_volt(void);
int32_t bq79600_balance_ctrl(uint8_t ctrl);
int32_t bq79600_shutdown(void);
int32_t bq79616_wakeup(void);
int32_t bq79600_collect_bat_volt(void);
int32_t bq79600_afe_cell_volt_wire_open_check(void);
int32_t cell_volt_abnormal_wo_check_req(void);
void bq79600_afe_vc_wire_open_check_req(void);
uint8_t current_stack_boards_get(void);
int32_t bq79600_sample_50ms(void);
int32_t bq79600_sample_100ms(void);
int32_t afe_cell_temp_sample_abnormal_get(stack_board_name_e name, uint8_t type);
int32_t afe_other_temp_sample_abnormal_get(stack_board_name_e name, uint8_t type);
int32_t bq79600_toggle_comm_dir(void);
int32_t daisy_chain_break_check(void);
void afe_balance_set(stack_board_name_e name, uint32_t enable_flag);
void afe_balance_state_get(stack_board_name_e name, uint32_t *state);
#endif
