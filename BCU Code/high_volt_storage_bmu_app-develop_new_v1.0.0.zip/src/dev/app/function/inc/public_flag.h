#ifndef __PUBLIC_FLAG_H__
#define __PUBLIC_FLAG_H__

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#define PUBLIC_FLAG_SHELL_DEBUG_FLAG 1

#define PUBLIC_FLAG_SET  1
#define PUBLIC_FLAG_CLR  0

// 无效值定义
#define U16_INVALID_DATA (0xFFFF)
#define I16_INVALID_DATA (0x7FFF)
#define U32_INVALID_DATA (0xFFFFFFFF)
#define I32_INVALID_DATA (0x7FFFFFFF)
/**
  * @enum   public_flag_type_e
  * @brief  公共标志类型
  */
typedef enum
{
	CHG_FULL_FLAG = 0,								///< 满充
	DISCHG_EMPTY_FLAG,								///< 放空
  	FORCE_CHG_FLAG,								    ///< 强充
    RECV_CHG_FULL_FLAG,                             // 收到BCU下发的满充标志
    RECV_DISCHG_EMPTY_FLAG,                         // 收到BCU下发的放亏标志
	PUBLIC_FLAG_NUM_MAX,
}public_flag_type_e;

/**
  * @enum   gpio_input_type_e
  * @brief  公共标志类型
  */
typedef enum
{
    DI1_ADDR_PACK_IN = 0,    ///< 内can编址输入1
    DI2_ADDR_PACK_IN = 1,    ///< 内can编址输入2
    GPIO_INPUT_NUM_MAX,
} gpio_input_type_e;

/**
* @brief		公共标志模块初始化
* @param		void
* @param		void
* @pre			系统启动时执行一次。
*/
void public_flag_init(void);
/**
* @brief		相关标志状态获取
* @param		[in] flag_type 故障类型
* @retval		true  置位
* @retval		false 未置位
* @retval		-1 查询失败
*/
int32_t public_flag_state_get(public_flag_type_e flag_type);
/**
* @brief		公共标志模块检测任务 周期10ms
* @param		void
* @return		void
*/
int32_t public_flag_task(void);

/**
* @brief		公共标志模块状态判断使能
* @param		void
* @param		void
* @pre	
*/
void public_flag_check_on(void);

/**
* @brief		请求切断标志
* @param		void
* @return		0：不请求切断， 1：请求切断
*/
uint8_t bmu_cut_off_request_get(void);

/**
* @brief		请求关机标志
* @param		void
* @return		0：不请求关机， 1：请求关机
*/
uint8_t bmu_pow_off_request_get(void);

/**
* @brief		bmu di状态获取
* @param		无
* @return		bit0：编址di
*/
uint16_t bmu_di_state_get(void);

/**
* @brief        di相关标志状态获取
* @param        [in] flag_type 故障类型
* @retval        true  置位
* @retval        false 未置位
* @retval        -1 查询失败
*/
int32_t di_state_get(gpio_input_type_e flag_type);


#endif
