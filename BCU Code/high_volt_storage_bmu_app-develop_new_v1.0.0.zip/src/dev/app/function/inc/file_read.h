#ifndef __FILE_READ_H__
#define __FILE_READ_H__
#include <stdint.h>
#include <stddef.h>
#include "sdk_public.h"

#define FILE_SEND_MAX_DATA_SIZE 280                                ///< 单个数据块大小为256
#define FILE_SEND_CRC_SIZE 2                                ///< 数据块CRC大小

#define FIVE_MINS_RECORD_MSG_SIZE   280   




#define HIS_EVENT_STRUCT_SIZE 8

typedef enum
{
    FILE_RD_ALL = 0,    // 读取全部
    FILE_RD_PART = 1    // 选择部分读取
}file_rd_mode_e;

typedef enum
{
    FILE_RD_FAULT_RCD = 0,    // 故障录波
    FILE_RD_RESERVE1 = 1,
    FILE_RD_RESERVE2 = 2,
    FILE_RD_FAULT_NUM = 3,
    FILE_RD_NORMAL_RCD = 3,    // 5MIN一条特性数据  //这里前四个文件顺序和文件系统里文件顺序保持一致
    FILE_RD_RUNNING_LOG = 4,    // 运行日志     
    FILE_RD_TYPE_MAX_NUM = 5     
}file_rd_file_type_e;   

typedef struct
{
    uint8_t src_dev_type;   // 升级源设备类型
    uint8_t src_addr;      // 升级源地址
    uint8_t dst_dev_type;   // 文件读取目标设备类型
    uint8_t dst_addr;      // 文件读取目标地址
    uint8_t slave_dev;      // 文件读取目标地址的子设备       
    uint8_t start_flag;   // 文件开始传输帧接收标志
    uint8_t block_data_flag;  // 接收到数据块标志
    uint8_t file_rd_mode;  // 文件读取模式，0 全部， 1 部分
    uint8_t file_type;     // 读取文件类型
    uint8_t file_size_get_flag;  // 文件大小获取标志 0 失败， 1 成功 
    uint8_t file_size_get_failed_cnt;   // 文件大小获取失败次数
    uint32_t stat_cnt_time;  // 状态计时
    uint8_t stat_delay_cnt; // 状态等待计数
    uint8_t finish_flag; // 读文件完成标志
}file_rd_proc_para_t; /*文件读取过程接收到的CAN消息*/

typedef struct
{
	uint32_t file_size;											// 文件大小
    uint32_t file_rd_len;                                       // 读取文件数据长度
    uint32_t file_offset_pos;                                   // 读取文件偏移位置
	uint16_t block_total_num;									// 数据块总数量
	uint16_t block_send_cnt;									// 当前传输序号(0,1,2,3,4,5...)
	uint16_t block_data_len;									// 当前块大小
    uint8_t  send_complete_flag;                                // 发送完成标志
	uint8_t	 block_data[FILE_SEND_MAX_DATA_SIZE+FILE_SEND_CRC_SIZE];			    // 当前块升级数据
}file_send_data_info_t;

typedef enum
{
    FILE_READ_WAIT	 = 0x00,    ///< 文件读取等待中
    FILE_READ_ING	 = 0x01,    ///< 文件读取进行中    
    FILE_READ_FINISH = 0x02,    ///< 文件读取完成
    FILE_READ_ERR    = 0x03,    ///< 文件读取错误       

}file_read_fun_e;

/**
* @brief		文件读取模块初始化
* @param		无
* @return		无
* @retval		无
* @pre			无
*/
void file_read_init(void);

/**
* @brief		文件读取任务
* @param		无
* @return		无
* @retval		无
* @pre			无
*/
void file_read_proc(void);

//获取文件读取状态
uint8_t get_file_read_wait_stus(void);


const file_rd_proc_para_t *get_file_rd_proc_info(void);

#endif

