#ifndef __BMS_STATE_MANAGE_H__
#define __BMS_STATE_MANAGE_H__

#include <stdint.h>
#include <stddef.h>

/*进入或退出充放电模式的电流，需根据实际项目待机功耗电流调整*/
#define  ENTER_CHARGE_CURR                500              //进入充电模式电流500mA		
#define  EXIT_CHARGE_CURR                 100              //退出充电模式电流100mA

#define  ENTER_DISCHARGE_CURR             -500              //进入放电模式电流-500mA		
#define  EXIT_DISCHARGE_CURR              -100              //退出放电模式电流-100mA


#define bms_supple_chg_state_get() 0
#define bmu_active_shut_down_sta() 0
#define bmu_shut_down_get(no) 0
/**
  * @enum battery_state_e
  * @brief 电池充放电状态
  */
typedef enum
{
	BMS_STANDY_MODE	= 0,	///< 待机
	BMS_CHARGE_MODE,		///< 充电
	BMS_DISCHARGE_MODE,		///< 放电
	
}battery_state_e;


/**
* @brief		电池充放电状态下的显示灯
* @param		无  
* @return		无
* @warning		无 
*/
typedef enum
{
	INIT_STATE		= 0,
	NORMAL_STANDBY	,
	NORMAL_CHARGE	,	
	NORMAL_DISCHARGE,	
	ERROR_STANDBY	,	
	ERROR_CHARGE	,	
	ERROR_DISCHARGE	,	
	OVER_CHARGE		,	
	OVER_DISCHARGE	,	
}bat_state_led_display_t;


/**
  * @enum bms_system_step_e
  * @brief 电池管理系统状态
  */
typedef enum
{
	BMS_START_UP = 0,			///< 开机
	BMS_SELF_CHECK,				///< 开机自检
	BMS_NORMAL,					///< 正常运行
	BMS_PF_ERROR,				///< 故障
	BMS_UPGRADE,				///< 升级过程
    BMS_SHUT_DOWN,              ///< 关机   
    BMS_STA_NUM,
}bms_system_step_e;

/**
 * @enum bms_system_step_e
 * @brief 电池管理系统状态
 */
typedef enum
{
    EVT_BMS_START_UP,    ///< 开机
    EVT_BMS_NORMAL,      ///< 正常运行
    EVT_BMS_PF_ERROR,    ///< 故障
    EVT_BMS_UPGRADE,     ///< 升级
	EVT_BMS_SHUT_DOWN,   ///< 关机
    EVT_BMS_STA_NUM,     ///< 事件综合个数
}evt_bms_system_step_e;

/**
  * @enum bms_system_step_e
  * @brief 电池管理系统状态
  */
typedef enum
{
	BMS_STATE_SELF_CHECK = 0,	///< 开机自检
	BMS_STATE_RUN,				///< 运行
	BMS_STATE_PF_ERROR,			///< 故障
	BMS_STATE_UPGRADE,			///< 升级过程
    BMS_STATE_SHUT_DOWN,        ///< 关机
	BMS_STATE_NUM,
}bms_system_state_e;

/**
* @brief		获取电池状态
* @param		无  
* @return		电池充放电状态
* @retval		待机:BMS_STANDY_MODE
* @retval		充电:BMS_CHARGE_MODE
* @retval		放电:BMS_DISCHARGE_MODE
* @warning		无
*/
battery_state_e bms_state_get_bat_sta(void);

/**
* @brief                BMU关机设置
 * @param                [in]state
 * @return               返回结果空
 * @retval               [out]0 成功
 * @warning              仅由sofar_can_data.c调用，用于BCU传输电池状态给BMU使用
 */
int8_t bmu_shut_down_set(uint16_t state);

/**
* @brief		获取系统状态
* @param		无  
* @return		系统状态
* @retval		开机		:BMS_STATE_SELF_CHECK
* @retval		正常运行		:BMS_STATE_RUN
* @retval		永久性故障	:BMS_STATE_PF_ERROR
* @retval		升级		:BMS_STATE_UPGRADE
* @retval		关机		:BMS_STATE_SHUT_DOWN
* @warning		无 
*/
bms_system_state_e bms_state_get_sys_sta(void);

/**
* @brief		获取系统状态工步
* @param		无
* @return		系统状态
* @warning		无
*/
bms_system_step_e bms_state_get_sys_sta_step(void);

/**
* @brief		初始化
* @param		无  
* @return		无
* @retval		无
* @warning		无
*/
void bms_state_init(void);

/**
* @brief		BMS状态流程
* @param		无  
* @return		无
* @retval		无
* @warning		无
*/
void bms_state_proc(void);

/**
 * @brief                BMU状态设置
 * @param                [in]state
 * @return               返回结果空
 * @retval               [out]0 成功
 * @warning              仅由sofar_can_data.c调用，用于BCU传输电池状态给BMU使用
 */
int8_t bmu_bat_state_set(uint8_t no,uint16_t state);

/* * @param                [in]state
 * @return               返回结果空
 * @retval               [out]0 成功
 * @warning              仅由sofar_can_data.c调用，用于BMU传输电池状态给BCU使用
 */

int32_t shell_in_bmu_state_proc(char *cmd, uint8_t len);


#endif
