/**
 * @file     data_store.h
 * @brief    数据存储
 * @company  sofarsolar
 * @author   刘吕从，刘炜全
 * @note
 * @version
 * @date     2023/5/17
 */

#ifndef __DATA_STORE_H__
#define __DATA_STORE_H__


#include <stdint.h>
#include <stddef.h>
#include "sample.h"
#include "sox_public.h"
#include "fault_manage.h"

#define BMS_ATTR_PRINT_FLAG 0
#define FAULT_MSG_TAB   20

#define RECORD_RUNING_DOG_DEPTH 8000 // 记录存储条数

//故障录波缓存
#define WINDOW_SIZE 5   //缓存条数
#define FAULT_RECORD_DOG_DEPTH 60 // 故障录波记录存储条数


#define RECORD_SAVE_PERIOD1 (1000 * 60 * 1) ///< 有故障时1分钟保存一次记录
#define RECORD_SAVE_PERIOD2 (1000 * 60 * 5) // 正常5分钟一条
#define FAULT_DATA_RECORD_TIME 1000
#define SAVE_TIME1  30
#define SAVE_TIME2  50  


/**
 * @brief 安全参数类型
 */
typedef struct
{
    int32_t appear_value;            ///< 产生阈值
    int32_t cancel_value;             ///< 取消阈值
} safety_param_t;

/**
 * @brief 安全参数表---
 */
typedef struct
{
    safety_param_t cell_over_vol_protect;     ///< 单体过压保护    
    safety_param_t cell_over_vol_alarm;       ///< 单体过压告警
    safety_param_t cell_over_vol_tip;         ///< 单体过压提示
    safety_param_t cell_under_vol_protect;    ///< 单体欠压保护    
    safety_param_t cell_under_vol_alarm;      ///< 单体欠压告警
    safety_param_t cell_under_vol_tip;        ///< 单体欠压提示
    safety_param_t cell_volt_diff_protect;    ///< 单体压差过大保护    
    safety_param_t cell_volt_diff_alarm;      ///< 单体压差过大告警
    safety_param_t cell_volt_diff_tip;        ///< 单体压差过大提示
    safety_param_t cell_temp_diff_protect;    ///< 单体温差过大保护    
    safety_param_t cell_temp_diff_alarm;      ///< 单体温差过大告警
    safety_param_t cell_temp_diff_tip;        ///< 单体温差过大提示      
    safety_param_t total_over_vol_protect;    ///< 总压过压保护    
    safety_param_t total_over_vol_alarm;      ///< 总压过压告警
    safety_param_t total_over_vol_tip;        ///< 总压过压提示
    safety_param_t total_under_vol_protect;   ///< 总压欠压保护
    safety_param_t total_under_vol_alarm;     ///< 总压欠压告警
    safety_param_t total_under_vol_tip;       ///< 总压欠压提示
    safety_param_t chg_over_temp_protect;     ///< 充电温度过高保护    
    safety_param_t chg_over_temp_alarm;       ///< 充电温度过高告警
    safety_param_t chg_over_temp_tip;         ///< 充电温度过高提示
    safety_param_t dchg_over_temp_protect;    ///< 放电温度过高保护    
    safety_param_t dchg_over_temp_alarm;      ///< 放电温度过高告警
    safety_param_t dchg_over_temp_tip;        ///< 放电温度过高提示
    safety_param_t chg_under_temp_protect;    ///< 充电温度过低保护
    safety_param_t chg_under_temp_alarm;      ///< 充电温度过低告警
    safety_param_t chg_under_temp_tip;        ///< 充电温度过低提示
    safety_param_t dchg_under_temp_protect;   ///< 放电温度过低保护    
    safety_param_t dchg_under_temp_alarm;     ///< 放电温度过低告警
    safety_param_t dchg_under_temp_tip;       ///< 放电温度过低提示
    safety_param_t soc_under_protect;         ///< soc过低告警
    safety_param_t soc_under_alarm;           ///< soc过低告警
    safety_param_t soc_under_tip;             ///< soc过低提示
    safety_param_t cell_over_vol_seriou;      ///< 单体超限    
    safety_param_t cell_under_vol_seriou;     ///< 单体超低  
    safety_param_t ent_over_temp_alarm;       ///< 环境温度过高报警
    safety_param_t ent_under_temp_alarm;      ///< 环境温度过低报警
    safety_param_t rsv[14];                    ///< 预留8个故障用于后续增加    
} safety_para_tab_t;

typedef enum{
    FAULT_RECORD_EMPTY  = 0,    // 未记录
    FAULT_RECORD_ING    = 1,    // 正在记录
    FAULT_RECORD_FULL   = 2     // 记录满

}fault_record_store_stus_t;


/**
 * @brief 故障录波记录数据
 */
typedef struct
{
    // uint16_t year_month;
    // uint16_t day_hour;
    // uint16_t min_sec;        
    // uint16_t fault_id;
    int16_t  current;   
    uint16_t maxvolt;
    uint16_t minvolt;
    int8_t maxtemp;
    int8_t mintemp;    

}fault_record_data_t;


typedef struct
{
    uint8_t file_no;
    char file_name[15];
}fault_record_file_t;

/**
  * @struct   fault_cnt_data_t
  * @brief	保护越限次数
  */
typedef struct
{
	uint8_t 	chg_protect_times;				///< 充电过流保护次数
	uint8_t 	dsg_protect2_times;				///< 放电过流保护2次数
	uint8_t 	cell_volt_over_protect_times;	///< 单体过压保护次数
	uint8_t 	total_volt_over_protect_times;	///< 总体过压保护次数
	uint8_t 	cell_volt_low_protect_times;	///< 单体欠压保护次数
	uint8_t 	total_volt_low_protect_times;	///< 总体欠压保护次数
	uint8_t 	chg_temp_over_protect_times;	///< 充电温度过高保护次数
	uint8_t 	chg_temp_low_protect_times;		///< 充电温度过低保护次数
	uint8_t 	dsg_temp_over_protect_times;	///< 放电温度过高保护次数
	uint8_t 	dsg_temp_low_protect_times;		///< 放电温度过低保护次数
} fault_cnt_data_t;

typedef enum{
    CELL_VOLT_OVER_PROTECT_CNT = 0,
    TOTAL_VOLT_OVER_PROTECT_CNT,
    CELL_VOLT_LOW_PROTECT_CNT,
    TOTAL_VOLT_LOW_PROTECT_CNT,
    CELL_VOLT_DIFF_OVER_PROTECT_CNT,
    CELL_LIMIT_FAULT_CNT,
    PACK_VOLT_DIFF_OVER_FAULT_CNT,
    CHG_TEMP_OVER_PROTECT_CNT,
    CHG_TEMP_LOW_PROTECT_CNT,
    DSG_TEMP_OVER_PROTECT_CNT,
    DSG_TEMP_LOW_PROTECT_CNT,
    CELL_TEMP_DIFF_OVER_PROTECT_CNT,
    CELL_TEMP_RISE_OVER_FAULT_CNT,
    VOLT_24V_ABNORMAL_FAULT_CNT,
    FLASH_INVALID_FAULT_CNT,
    AFE_ABNORMAL_FAULT_CNT,
    CELL_VOLT_SAM_FAULT_CNT,
    CELL_TEMP_SAM_FAULT_CNT,
    POWER_TERMINAL_TEMP_SAM_FAULT_CNT,
    TERMINAL_TEMP_OVER_PROTECT_CNT,
    FAULT_CNT_MAX_NUMS,
}fault_cnt_num_t;

typedef union
{
	uint32_t stu_val;
	struct
	{
		uint8_t 	cell_volt_over_protect_stu :1;	            ///< 单体过压保护状态
		uint8_t 	total_volt_over_protect_stu :1;	            ///< 总体过压保护状态
		uint8_t 	cell_volt_low_protect_stu :1;	            ///< 单体欠压保护状态
		uint8_t 	total_volt_low_protect_stu :1;	            ///< 总体欠压保护状态
        uint8_t 	cell_volt_diff_over_protect_stu :1;	        ///< 单体压差过大保护状态
        uint8_t     cell_limit_fault_stu : 1;                   ///< 单体电芯极限故障状态
        uint8_t     total_volt_diff_over_protect_stu :1;        ///< 总压压差过大保护状态
		uint8_t 	chg_temp_over_protect_stu :1;	            ///< 充电温度过高保护状态
        uint8_t 	dsg_temp_over_protect_stu :1;	            ///< 放电温度过高保护状态
		uint8_t 	chg_temp_low_protect_stu :1;	            ///< 充电温度过低保护状态
		uint8_t 	dsg_temp_low_protect_stu :1;	            ///< 放电温度过低保护状态
        uint8_t 	cell_temp_diff_over_protect_stu :1;	        ///< 单体温差过大保护状态
        uint8_t     cell_temp_rise_over_fault_stu :1;           ///< 单体温升过大故障状态
        uint8_t 	volt_24v_err_stu :1;	                    ///< 辅源异常保护状态
        uint8_t 	flash_invalid_stu :1;	                    ///< flash无效保护状态
        uint8_t 	afe_err_stu :1;	                            ///< afe异常保护状态
        uint8_t 	cell_volt_wire_abnormal_stu :1;	            ///< 单体电压线束异常保护状态
        uint8_t 	cell_temp_sam_fault_stu :1;	                ///< 单体温度采样故障状态
        uint8_t     power_terminal_temp_sam_fault_stu :1;       ///< 功率端子温度采样故障状态
        uint8_t 	power_terminal_temp_over_protect_stu :1;    ///< 功率端子温度过高保护状态
	}bits;
} fault_cnt_stu_u;

typedef struct
{
    uint16_t fault_cnt_num;
    fault_type_e fault_cnt_map;
}fault_cnt_map_t;

/**
 * @brief BMS属性数据表，注意：新增的数据只能在后面添加不能中间插入
 */
typedef struct
{
    uint32_t version;         ///< bms属性数据表版本
    safety_para_tab_t safety; ///< 安全参数表
    uint16_t bal_vol;         ///< 均衡开启电压
    uint16_t bal_vol_diff;    ///< 均衡开启压差
    uint16_t full_chg_vol;    ///< 满充电压
    uint32_t chg_stop_cur;    ///< 充电截止电流
    uint32_t chg_stop_vol;    ///< 充电截止电压  
    uint16_t rate_cap;        ///< 额定容量
    uint16_t mono_vol_num;    ///< 单体电压个数
    uint16_t mono_tem_num;    ///< 单体温度个数 
    uint16_t cell_num;        ///< 电芯数量            
    uint8_t addr;            ///< 地址
    adjust_para_tab_t adjust; ///< 校准参数表    
    uint8_t pack_sn[21];      ///< Pack SN：条形码
    uint8_t board_sn[21];     ///< Board SN：单板条形码                
    uint8_t u8_reserve[3];      ///< 预留  
    uint16_t bal_cur;         ///< 被动均衡电流     
    uint8_t app_ver[8];        ///< APP版本号
    uint16_t u16_reserve[1];      ///< 预留  
    uint32_t u32_reserve[7];      ///< 预留      
    uint32_t check;           ///< crc    
} bms_attr_t;

/**
 * @brief BMS运行实时数据，需要掉电保存，注意：新增的数据只能在后面添加不能中间插入
 */
#pragma pack(4)
typedef struct
{
    sox_running_data_t sox_running_data;
    uint8_t ate_step;
    uint8_t u8reserve[4];
    uint8_t rtc_data[6];
    uint16_t u16reserve;    ///< 预留
    uint8_t flash_data[8]; ///< flash test
    uint16_t fault_cnt[FAULT_CNT_MAX_NUMS];
    uint32_t reserve[26];    ///< 预留
    uint32_t version;        ///< 预留
    uint32_t check;          ///< 预留
} bms_runing_data_t;
#pragma pack()

/**
 * @brief BMS记录数据，注意：新增的数据只能在后面添加不能中间插入
 */
#pragma pack(1)
typedef struct
{
    uint8_t fault_id;       //0xff为无效id，主要是故障录波的存储会用到这个
    uint16_t year_month;
    uint16_t day_hour;
    uint16_t min_sec;
    uint16_t bat_afe_volt;  //电池采集电压  0.1V
    uint16_t bat_acc_volt;  //电池累计电压  0.1V
    uint8_t soc;            //SOC显示值     1%
    uint8_t soh;            //SOH显示值     1%
    uint32_t soc_cal;       //SOC计算值     0.001%
    uint32_t soh_cal;       //SOH计算值     0.001%
    int16_t  current;       //电池电流      0.01A
    uint16_t max_volt;      //最高单体电压  1mV
    uint16_t min_volt;      //最小单体电压  1mV
    uint8_t max_volt_no;    //最高单体电压序号
    uint8_t min_volt_no;    //最小单体电压序号
    int8_t max_temp;       //最高单体温度  1℃
    int8_t min_temp;       //最小单体温度  1℃
    uint8_t max_temp_no;    //最高单体温度序号
    uint8_t min_temp_no;    //最小单体温度序号
    uint16_t chrg_cur_lim;      //电池包充电电流上限    0.1A 
    uint16_t dischrg_cur_lim;   //电池包放电电流上限    0.1A    
    uint8_t sys_status;     //系统状态
    uint8_t other_status;    //其他状态   
    uint8_t fault_level;    //故障等级
    uint8_t fault_msg[FAULT_MSG_TAB];
    uint16_t supply_volt;   //辅助供电电压  0.1V
    uint32_t dsg_ah;        //累计放电安时  1AH
    uint32_t chrg_ah;       //累计充电安时  1AH
    uint32_t dsg_wh;        //累计放电瓦时  1Wh
    uint32_t chrg_wh;       //累计充电瓦时  1Wh
    int8_t other_temp[OTHER_NTC_NUM];  //1℃
    uint16_t bal_stus[CELL_VOLT_NUM/16];
    uint16_t cell_volt[CELL_VOLT_NUM];  //1mv
    int8_t cell_temp[CELL_TEMP_NUM];    //1℃
    uint32_t u32rsv[4];
    uint8_t u8rsv[3];

} bms_record_data_t;	//64S项目时280个字节
#pragma pack()

typedef struct
{
    bms_record_data_t fault_record_buff[WINDOW_SIZE]; //扫窗存储BUFF
    uint16_t fault_buff_fill_cnt;   //buff计数
    uint8_t buff_full_flag;
    uint16_t fault_record_cnt;  //剩余存储数

}fault_record_buff_info_t;


/**
 * @brief 数据保存相关标志
 */
typedef struct
{
    uint8_t bms_record_save_flag;      //运行日志记录标志
    uint8_t bms_runing_data_save_flag; //运行数据保存标志
    uint8_t bms_attr_save_flag;        //属性数据保存标志

    int8_t runing_data_file_open;      //四种数据文件打开标志
    int8_t bms_attr_file_open;
    int8_t record_file_open;
    int8_t fault_record_file_open;

    uint8_t para_err;
    uint8_t runing_data_err;
    uint8_t record_err;    
    uint8_t fault_record_err; 

    uint8_t bms_record_read_flag;
    uint8_t fault_record_read_flag;
    uint8_t his_event_read_flag;

    uint8_t runing_data_file_err_cnt;      //失败计数
    uint8_t bms_attr_file_err_cnt;
    uint8_t record_file_err_cnt;
    uint8_t his_event_file_err_cnt;    
}data_store_flag_t;


/**
 * @enum   data_store_fault_e
 * @brief  故障类型
 */
typedef enum
{
    DATA_STORE_BMS_ATTR     = 0,        ///< 保存数据故障 - 参数区
    DATA_STOR_RUNNING_DATA  = 1,         ///< 保存数据故障 - 运行数据
    DATA_STORE_RECORD       = 2,              ///< 保存数据故障 - 5分钟日志数据
    DATA_STORE_FAULT_RECORD = 3,        ///< 保存数据故障 - 故障录波数据
	DATA_STORE_FAULT_NUM	= 4,		//数据保存总数
} data_store_fault_e;


/**
 * @brief 保存BMS属性表中某个元素
 * @param offset 偏移量
 * @param data 数据内容
 * @param len 数据长度
 * @return int32_t
 * @retval 0 成功
 * @retval -1 失败
 */
int32_t data_store_save_bms_attr(uint32_t offset, uint8_t *data, uint32_t len);

/**
 * @brief 保存BMS属性表中的校准参数
 * @param offset 偏移量
 * @param data 数据内容
 * @param len 数据长度
 * @return int32_t
 * @retval 0 成功
 * @retval -1 失败
 */
int32_t data_store_save_adjust_para(adjust_para_tab_t *adjust_para_tab);


/**
 * @brief 保存BMSrunningdata中某个元素
 * @param flag: ture为存储；false为只赋值
 * @return int32_t
 * @retval 0 成功
 * @retval -1 失败
 */
int32_t bms_runing_data_deal(bms_runing_data_t bms_runing_data, uint8_t flag);

/**
 * @brief 保存BMSsox_runningdata中某个元素
 * @return int32_t
 * @retval 0 成功
 * @retval -1 失败
 */
int32_t bms_sox_runing_data_save(sox_running_data_t sox_running_data);

/**
* @brief        获取bms存储数据
* @param        [out]bms_attr_t*
* @param        void
*/
const bms_attr_t *get_bms_attr(void);


/**
* @brief        获取bms运行数据
* @param        [out]bms_runing_data_t*
* @param        void
*/
const bms_runing_data_t *get_bms_runing_data(void);

/**
 * @brief 保护越限次数清除
 *
 */
void bms_protect_cnt_clear(void);

/**
 * @brief   初始化数据存储模块
 * @param   none
 * @param   void
 */
void data_store_init(void);

/**
 * @brief 保存数据线程，100ms调用一次
 * @return 无
 */
void data_store_thread(void);

/**
 * @brief 故障录波初始化
 * @return 无
 */
void fault_recording_init(void);

/**
 * @brief 故障录波线程(1000ms调用一次)
 *
 */
void fault_recording_proc(void);

/**
 * @brief 存储故障标志获取
 *
 */
int32_t data_store_toatal_fault_get(void);


/**
 * @brief 五分钟日志读标志
 * @return 无
 */
void set_bms_record_read_flag(uint8_t flag);

/**
 * @brief 故障录波读标志
 * @return 无
 */
void set_fault_record_read_flag(uint8_t flag);

/**
 * @brief 历史事件读标志
 * @return 无
 */
void set_his_event_read_flag(uint8_t flag);

/**
 * @brief 阈值参数恢复默认
 * @return 无
 */
int8_t attr_data_resume_default_data(void);

//删除故障录波文件
int8_t bms_fault_record_file_delte(void);

// 读取某一帧的历史数据
int8_t bms_record_data_read(uint16_t read_num, bms_record_data_t *p_data);

/**
 * @brief shell命令record记录读取
 * @return 无
 */
int32_t shell_in_rundata_proc(char *cmd, uint8_t len);

int32_t shell_in_record_proc(char *cmd, uint8_t len);

int32_t shell_in_his_event_proc(char *cmd, uint8_t len);

#endif

