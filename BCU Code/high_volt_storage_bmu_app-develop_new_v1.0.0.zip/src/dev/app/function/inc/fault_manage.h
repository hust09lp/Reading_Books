#ifndef __FAULT_MANAGE_H__
#define __FAULT_MANAGE_H__

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#define FAULT_START				(0x01)		///< 故障启动
#define	FAULT_STOP				(0x00)		///< 故障停止

#define ENABLE					(0x01)		///< 故障使能
#define	DISABLE					(0x00)		///< 故障禁止

#define LEVEL0					(0x00)		///< 充放电等级零 故障：限流，关断MOS，无法恢复
#define LEVEL1					(0x01)		///< 充放电等级一 保护：限流，关断MOS，可恢复
#define	LEVEL2					(0x02)		///< 充放电等级二 告警：限流，不关断MOS，可恢复
#define	LEVEL3					(0x03)		///< 充放电等级三 提示

#define AUTO_CLR				(0x00)  	///< 自动清除
#define	MANUAL_CLR				(0x01)  	///< 手动清除
#define	POFF_CLR				(0x02)  	///< 下电清除

#define VRLID					(0x00)  	///< 有效
#define INVRLID					(0x01)  	///< 失效
/**
  * @enum   fault_type_e
  * @brief  故障类型
  */
typedef enum
{
	DIAG_NONE = 0,							///< 空闲
	POWER_ON_SELF_TEST,					    ///< 开机自检
	DIAG_ON_RUNNING,						///< 运行中诊断
}fault_diag_step_e;

/**
  * @enum   fault_type_e
  * @brief  故障类型
  */
typedef enum
{
	ACTION_NONE = 0,						///< 故障保护动作：无动作
	LIMIT_CHARGE_CURRENT,					///< 故障保护动作：限充
	LIMIT_DISCHARGE_CURRENT,				///< 故障保护动作：限放
	CUT_OFF_RELAY,						    ///< 故障保护动作：切断继电器					
	PROTECT_ACTION_NUM_END,                 ///< 故障保护动作
}fault_protect_action_e;

/**
 * @enum   hard_self_det_abn_e
 */
typedef enum
{
    POWER_24V_ABN = 0,                      ///< 24V供电异常
    HALL_5V_ABN,                            ///<  5V供电异常
    RELAY_ABN,                              ///< 继电器异常
} hard_self_det_abn_e;

/**
 * @enum   fault_type_e
 * @brief  故障类型
 * @warning 告警每次更新都要检查是否需要刷新:g_dsg_level1_alarm_list[]
 */
typedef enum
{
	// 单板故障
	BOARD_FAULT_INDEX = 0,						     ///< 单板故障类索引                                   Hex
	BOARD_24V_ABNORMAL_FAULT = BOARD_FAULT_INDEX,    ///< 单板：24V辅源电压异常                             00
	BOARD_FLASH_INVALID_FAULT,						 ///< 单板：flash错误                                   01
	BOARD_AFE_ABNORMAL_FAULT,					     ///< 单板：AFE异常                                     02
	BOARD_CAN_COMM_ABNORMAL_ALARM,					 ///< 单板：CAN通讯异常                                 03
	BOARD_CANID_CONFLICT_ALARM,						 ///< 单板：CAN地址冲突                                 04
	BOARD_CELL_VOLT_WIRE_ABNORMAL_FAULT,             ///< 单板：电芯电压采样线异常                          05
	BOARD_CELL_TEMP_SAM_FAULT,                       ///< 单板：电芯温度采样异常故障                        06
    BOARD_BAL_TEMP_OVER_ALARM,					     ///< 电池：均衡温度过高告警                            07
    BOARD_BAL_TEMP_SAM_ABNORMAL_ALARM,               ///< 单板：均衡温度采样异常                            08
    BOARD_POWER_TERMINAL_TEMP_SAM_FAULT,             ///< 单板：功率端子温度采样异常                        09
    BOARD_POWER_TERMINAL_TEMP_OVER_PROTECT,          ///< 单板：功率端子过温保护                            0A
    BOARD_ENV_TEMP_SAM_ABNORMAL_ALARM,               ///< 单板：环境温度采样异常                            0B
    BOARD_ENV_TEMP_HIGH_ALARM,						 ///< 电池：环境温度过高告警                            0C
	BOARD_ENV_TEMP_LOW_ALARM,						 ///< 电池：环境温度过低告警                            0D
    BOARD_HARD_SELF_DET_FAULT,                       ///< 单板：硬件自检故障                                0E
    BOARD_AFE_CHAIN_BREAK_FAULT,                     ///< 单板：afe断单链告警                               0F    
    BOARD_ELECTROLYTE_SEN_ABNORMAL_ALARM,            ///< 单板：电解液漏液检测传感器异常                    10    
    BOARD_CELL_TEMP_SAM_TIP,                         ///< 单板：电芯温度采样异常提示                        11    
    
	// 电池故障
	BAT_FAULT_INDEX,								 ///< 电池故障类索引
    BAT_CELL_VOLT_HIGH_TIPS = BAT_FAULT_INDEX,       ///< 电池：单体电压过高提示                            12             
	BAT_CELL_VOLT_HIGH_ALARM,		                 ///< 电池：单体电压过高告警                            13           
	BAT_CELL_VOLT_HIGH_PROTECT,						 ///< 电池：单体电压过高保护                            14             
    BAT_CELL_VOLT_LOW_TIPS,						     ///< 电池：单体电压过低提示                            15             
	BAT_CELL_VOLT_LOW_ALARM,						 ///< 电池：单体电压过低告警                            16             
	BAT_CELL_VOLT_LOW_PROTECT,						 ///< 电池：单体电压过低保护                            17             
    BAT_CELL_VOLT_DIFF_OVER_TIPS,					 ///< 电池：单体压差过大提示                            18             
    BAT_CELL_VOLT_DIFF_OVER_ALARM,					 ///< 电池：单体压差过大告警                            19             
    BAT_CELL_VOLT_DIFF_OVER_PROTECT,				 ///< 电池：单体压差过大保护                            1A             
    BAT_TOTAL_VOLT_HIGH_TIPS,						 ///< 电池：总压过高提示                                1B             
	BAT_TOTAL_VOLT_HIGH_ALARM,						 ///< 电池：总压过高告警                                1C             
	BAT_TOTAL_VOLT_HIGH_PROTECT,					 ///< 电池：总压过高保护                                1D             
    BAT_TOTAL_VOLT_LOW_TIPS,						 ///< 电池：总压过低提示                                1E             
	BAT_TOTAL_VOLT_LOW_ALARM,						 ///< 电池：总压过低告警                                1F             
	BAT_TOTAL_VOLT_LOW_PROTECT,						 ///< 电池：总压过低保护                                20            
    BAT_TOTAL_VOLT_DIFF_OVER_FAULT,					 ///< 电池：总压压差过大故障                            21            
    BAT_CELL_CHG_TEMP_OVER_TIPS,				     ///< 电池：单体充电温度过高提示                        22            
	BAT_CELL_CHG_TEMP_OVER_ALARM,					 ///< 电池：单体充电温度过高告警                        23            
	BAT_CELL_CHG_TEMP_OVER_PROTECT,					 ///< 电池：单体充电温度过高保护                        24            
    BAT_CELL_CHG_TEMP_LOW_TIPS,						 ///< 电池：单体充电温度过低提示                        25            
	BAT_CELL_CHG_TEMP_LOW_ALARM,					 ///< 电池：单体充电温度过低告警                        26            
	BAT_CELL_CHG_TEMP_LOW_PROTECT,					 ///< 电池：单体充电温度过低保护                        27            
	BAT_CELL_DISCHG_TEMP_OVER_TIPS,					 ///< 电池：单体放电温度过高提示                        28            
    BAT_CELL_DISCHG_TEMP_OVER_ALARM,				 ///< 电池：单体放电温度过高告警                        29            
	BAT_CELL_DISCHG_TEMP_OVER_PROTECT,				 ///< 电池：单体放电温度过高保护                        2A            
	BAT_CELL_DISCHG_TEMP_LOW_TIPS,					 ///< 电池：单体放电温度过低提示                        2B            
    BAT_CELL_DISCHG_TEMP_LOW_ALARM,					 ///< 电池：单体放电温度过低告警                        2C            
	BAT_CELL_DISCHG_TEMP_LOW_PROTECT,				 ///< 电池：单体放电温度过低保护                        2D            
    BAT_CELL_TEMP_DIFF_OVER_TIPS,					 ///< 电池：单体温差过大提示                            2E            
    BAT_CELL_TEMP_DIFF_OVER_ALARM,					 ///< 电池：单体温差过大告警                            2F            
    BAT_CELL_TEMP_DIFF_OVER_PROTECT,				 ///< 电池：单体温差过大保护                            30            
    BAT_CELL_TEMP_RISE_OVER_FAULT,					 ///< 电池：电芯温升过大故障                            31             
    BAT_CELL_LIMIT_FAULT,                            ///< 电池：电芯极限故障                                32     
    BAT_VOLT_HIGH_DISABLE,                           ///< 电池：电池过压保护失能                            33
    BAT_VOLT_LOW_DISABLE,                            ///< 电池：电池欠压保护失能                            34
    BAT_CELL_TEMP_OVER_OR_LOW_DISABLE,               ///< 电池：电池高低温保护失能                          35         
    BAT_CELL_VOLT_HIGH_SERIOUS_LOCK,                 ///< 电池：电芯严重过压锁死故障                        36    
	// 故障总数                                                                                             
	FAULT_MAX,                                                                                              
}fault_type_e;

/* can回调函数定义 */
typedef void(*fault_check_f)(void);


/**
  * @struct   fault_data_t
  * @brief  单个故障数据结构
  */
typedef struct
{
	fault_type_e 	fault_type;  			///< 故障类型
	uint16_t 		fault_code;				///< 故障编码
	uint16_t		fault_status;			///< 故障状态
	uint8_t			charge_level;			///< 充电等级
	uint8_t			discharge_level;		///< 放电等级
} fault_data_t;


/**
  * @struct   fault_stat_data_t
  * @brief  故障统计数据结构
  */
typedef struct
{
	uint16_t    	fault_num;  			///< 故障数量
	uint8_t 		max_charge_level;		///< 最高充电等级
	uint8_t 		max_discharge_level;	///< 最高放电等级
    uint8_t         fault_level;            ///< 按bit来代表是否触发某个等级，主要是给传给BCU后给外can发送使用    
} fault_stat_data_t;


/**
  * @struct   fault_lock_data_t
  * @brief	故障锁死数据
  */
typedef struct
{
	uint8_t    	chg_alarm_times;  				///< 充电过流告警次数
	uint8_t 	chg_protect_times;				///< 充电过流保护次数
	uint8_t 	dsg_alarm_times;				///< 放电过流告警次数
	uint8_t 	dsg_protect1_times;				///< 放电过流保护1次数
	uint8_t 	dsg_protect2_times;				///< 放电过流保护2次数
	uint8_t		llc_terminal_protect_times;	///< llc mos过温次数
	uint8_t 	cell_volt_over_protect_times;	///< 单体过压保护次数
	uint8_t 	total_volt_over_protect_times;	///< 总体过压保护次数
	uint8_t 	cell_volt_low_protect_times;	///< 单体欠压保护次数
	uint8_t 	total_volt_low_protect_times;	///< 总体欠压保护次数
	uint8_t 	chg_temp_over_protect_times;	///< 充电温度过高保护次数
	uint8_t 	chg_temp_low_protect_times;		///< 充电温度过低保护次数
	uint8_t 	dsg_temp_over_protect_times;	///< 放电温度过高保护次数
	uint8_t 	dsg_temp_low_protect_times;		///< 放电温度过低保护次数
    uint8_t     bal_chg_over_curr_times;        ///< 主动均衡充电过流次数
    uint8_t     bal_dsg_over_curr_times;        ///< 主动均衡放电过流次数
    uint8_t     bal_hardware_over_curr_times;   ///< 主动均衡硬件过流次数
	uint8_t		power_terminal_protect_times;	///< 功率端子过温次数    
} fault_lock_data_t;

/**
  * @struct   fault_record_data_t
  * @brief	故障录波数据
  */
typedef struct
{
	uint8_t fault_id[FAULT_MAX];
	uint8_t fault_record_flag[FAULT_MAX];	//故障是否已经开始写入标志
	uint8_t fault_cnt;
} fault_id_t;

// BMU内can的故障信息1
typedef struct
{
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t cell_v_h_pro : 1;
            uint8_t cell_v_h_alm : 1;
            uint8_t cell_v_l_pro : 1;
            uint8_t cell_v_l_alm : 1;
            uint8_t total_v_h_pro : 1;
            uint8_t total_v_h_alm : 1;
            uint8_t total_v_l_pro : 1;
            uint8_t total_v_l_alm : 1;
        } bits;
    } byte0;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t chg_temp_h_pro : 1;
            uint8_t chg_temp_h_alm : 1;
            uint8_t chg_temp_l_pro : 1;
            uint8_t chg_temp_l_alm : 1;
            uint8_t dis_temp_h_pro : 1;
            uint8_t dis_temp_h_alm : 1; // CBS5000无次告警，不使用
            uint8_t dis_temp_l_pro : 1;
            uint8_t dis_temp_l_alm : 1; // CBS5000无次告警，不使用
        } bits;
    } byte1;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t chg_curr_h_pro : 1;
            uint8_t chg_curr_h_alm : 1;  // CBS5000无次告警，不使用
            uint8_t dsg_curr_h_pro : 1; 
            uint8_t dsg_curr_h_alm : 1;  // CBS5000无次告警，不使用
            uint8_t en_temp_h_pro : 1;  // CBS5000无次告警，不使用
            uint8_t en_temp_h_alm : 1;
            uint8_t en_temp_l_pro : 1;  // CBS5000无次告警，不使用
            uint8_t en_temp_l_alm : 1;
        } bits;
    } byte2;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t mos_temp_h_pro : 1;   // CBS5000无次告警，不使用
            uint8_t mos_temp_h_alm : 1;   // llc
            uint8_t soc_l_pro : 1;    // CBS5000无次告警，不使用
            uint8_t soc_l_alm : 1;
            uint8_t total_v_err : 1;
            uint8_t total_v_h0 : 1;    // 总压过大硬件保护(BTS-5K专用)   // CBS5000无此告警，不使用
            uint8_t chg_curr_h0 : 1;   // 充电过流硬件保护(BTS-5K专用)   // CBS5000无此告警，不使用
            uint8_t dsg_curr_h0 : 1;   // 防电过流硬件保护(BTS-5K专用)   // CBS5000无此告警，不使用
        } bits;
    } byte3;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t chg_full : 1;          // CBS5000无此告警，不使用
            uint8_t short_circuit : 1;     // CBS5000无此告警，不使用
            uint8_t eerom_error : 1;       // CBS5000无此告警，不使用
            uint8_t cell_volt_fault : 1;   // CBS5000无此告警，不使用
            uint8_t ntc_invalid : 1;
            uint8_t chg_mos_invalid : 1;   // CBS5000无此告警，不使用
            uint8_t dsg_mos_invalid : 1;   // CBS5000无此告警，不使用
            uint8_t samp_invalid : 1;
        } bits;
    } byte4;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t limit_invalid : 1;   // CBS5000无此告警，不使用
            uint8_t chg_reversed : 1;    // CBS5000无此告警，不使用
            uint8_t can_com_fail : 1;
            uint8_t canid_conflict : 1;
            uint8_t dischg_empty : 1;  // CBS5000无此告警，不使用
            uint8_t pcu_invalid : 1;   // CBS5000无此告警，不使用
            uint8_t rechg_err : 1;     // CBS5000无此告警，不使用
            uint8_t soft_error : 1;    // CBS5000无此告警，不使用
        } bits;
    } byte5;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t chg_big_curr_zero_err: 1;     // CBS5000无此告警，不使用
            uint8_t chg_samll_curr_zero_err : 1;  // CBS5000无此告警，不使用
            uint8_t curr_offset_err : 1;          // CBS5000无此告警，不使用
            uint8_t master_fuse_err : 1;          // CBS5000无此告警，不使用
            uint8_t latch_err : 1;                // CBS5000无此告警，不使用
            uint8_t aux_power_err : 1;
            uint8_t serious_cell_v_h : 1;
            uint8_t serious_cell_v_l : 1;
        } bits;
    } byte6;
	
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t dsg_big_curr_zero_err : 1;    // CBS5000无此告警，不使用
            uint8_t dsg_samll_curr_zero_err: 1;   // CBS5000无此告警，不使用
            uint8_t cell_temp_diff_err : 1;       // CBS5000无此告警，不使用
            uint8_t insulation_ab : 1;            // CBS5000无此告警，不使用
            uint8_t res1 : 1;
            uint8_t res2 : 1;
            uint8_t res3 : 1;
            uint8_t res4 : 1;
        } bits;
    } byte7;
} inner_can_fault_info1_t;

// 内can故障信息2
typedef struct
{
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t act_bal_invalid : 1;
            uint8_t act_bal_cur_diff : 1;
            uint8_t act_bal_pri_dsg_curr_slow_h : 1;
            uint8_t act_bal_pri_chg_curr_slow_h : 1;
            uint8_t act_bal_hard_curr_h : 1;
            uint8_t act_bal_curr_lock : 1;
            uint8_t act_bal_pri_volt_slow_h : 1;
            uint8_t act_bal_sec_volt_slow_h : 1;
        } bits;
    } byte0;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t act_bal_sec_volt_slow_l : 1;
            uint8_t act_bal_pri_volt_fast_h : 1;
            uint8_t act_bal_sec_volt_fast_h : 1;
            uint8_t act_bal_pri_dsg_curr_fast_h : 1;
            uint8_t act_bal_pri_chg_curr_fast_h : 1;
            uint8_t act_bal_hard_volt_h : 1;
            uint8_t act_bal_power_h : 1;
            uint8_t act_curr_ring_badness_err : 1;
        } bits;
    } byte1;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t res1 : 1;
            uint8_t res2 : 1;
            uint8_t pass_bal_temp_h : 1;
            uint8_t cell_v_serious_diff_err : 1;
            uint8_t cell_temp_h_err : 1;
            uint8_t curr_lock_h : 1;
            uint8_t cell_v_lock_h : 1;
            uint8_t cell_v_lock_l : 1;
        } bits;
    } byte2;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t cell_temp_lock_hl : 1;
            uint8_t cell_temp_rise_err : 1;
            uint8_t res1 : 1;
            uint8_t dsg_curr_h_pro2 : 1;
            uint8_t chg_temp_tip_h : 1;
            uint8_t chg_temp_tip_l : 1;   
            uint8_t dsg_temp_tip_h : 1;  
            uint8_t dsg_temp_tip_l : 1; 
        } bits;
    } byte3;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t flash_err : 1;
            uint8_t power_temp_lock_h : 1;
            uint8_t mos_temp_lock_h : 1;    // llc
            uint8_t cell_v_lock_h_err2 : 1;
            uint8_t cell_v_line_err : 1;
            uint8_t cell_temp_line_err : 1;
            uint8_t pass_bal_temp_line_err : 1;
            uint8_t power_temp_line_err : 1;
        } bits;
    } byte4;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t power_temp_pro_h : 1;
            uint8_t heat_err : 1;               // CBS5000无此告警，不使用
            uint8_t heat_relay_short_err : 1;   // CBS5000无此告警，不使用
            uint8_t heat_relay_open_err : 1;    // CBS5000无此告警，不使用
            uint8_t res5 : 1;
            uint8_t res6 : 1;
            uint8_t res7 : 1;
            uint8_t res8 : 1;
        } bits;
    } byte5;
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t chg_oc_lock_h_err2 : 1;    // CBS5000无此告警，不使用
            uint8_t dchg_oc_lock_h_err2 : 1;   // CBS5000无此告警，不使用
            uint8_t heat_loop_ctl_err : 1;     // CBS5000无此告警，不使用
            uint8_t res4 : 1;
            uint8_t res5 : 1;
            uint8_t res6 : 1;
            uint8_t res7 : 1;
            uint8_t res8 : 1;
        } bits;
    } byte6;
    
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t res1 : 1;
            uint8_t res2 : 1;
            uint8_t res3 : 1;
            uint8_t res4 : 1;
            uint8_t res5 : 1;
            uint8_t res6 : 1;
            uint8_t res7 : 1;
            uint8_t res8 : 1;
        } bits;
    } byte7;
} inner_can_fault_info2_t;

// 内can故障信息3
typedef struct
{
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t board_temp_tip : 1;
            uint8_t cell_over_volt_tip : 1;
            uint8_t cell_under_volt_tip : 1;
            uint8_t cell_volt_diff_over_tip : 1;
            uint8_t cell_temp_diff_over_tip : 1;
            uint8_t bat_over_volt_tip : 1;
            uint8_t bat_under_volt_tip : 1;
            uint8_t soc_l_tip : 1;  //soc过低做在了bcu
        } bits;
    } byte0;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t dsg_cur_over_tip : 1;
            uint8_t chg_cur_over_tip : 1;
            uint8_t afe_chain_break_tip : 1;            
            uint8_t electrolyte_sen_tip : 1;
            uint8_t cell_temp_line_tip : 1;
            uint8_t res6 : 1;
            uint8_t res7 : 1;
            uint8_t res8 : 1;
        } bits;
    } byte1;
    
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t cell_volt_diff_over_alm : 1;
            uint8_t cell_temp_diff_over_alm : 1;
            uint8_t res3 : 1;
            uint8_t res4 : 1;
            uint8_t res5 : 1;
            uint8_t res6 : 1;
            uint8_t res7 : 1;
            uint8_t res8 : 1;
        } bits;
    } byte2;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t res1 : 1;
            uint8_t res2 : 1;
            uint8_t res3 : 1;
            uint8_t res4 : 1;
            uint8_t res5 : 1;
            uint8_t res6 : 1;
            uint8_t res7 : 1;
            uint8_t res8 : 1;
        } bits;
    } byte3;
    
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t cell_limit_err : 1;
            uint8_t res2 : 1;
            uint8_t res3 : 1;
            uint8_t res4 : 1;
            uint8_t res5 : 1;
            uint8_t res6 : 1;
            uint8_t res7 : 1;
            uint8_t res8 : 1;
        } bits;
    } byte4;
} inner_can_fault_info3_t;

typedef struct
{
    inner_can_fault_info1_t fault_info1;
    inner_can_fault_info2_t fault_info2;
    inner_can_fault_info3_t fault_info3;
}fault_info_t;

typedef struct
{
	union
	{
		uint16_t doublebyte;
		struct
		{
			uint16_t cell_volt_high_prot			:1;
			uint16_t cell_volt_low_prot				:1;
			uint16_t total_volt_high_prot			:1;
			uint16_t total_volt_low_prot			:1;
			uint16_t chg_cur_over_prot				:1;
			uint16_t dischg_cur_over_prot			:1;    // 包括放电过流保护1，2
			uint16_t used6                          :1;    // 此位已被占用(短路)
			uint16_t rsv_7							:1; 

			uint16_t cell_temp_high_prot            :1;
			uint16_t used9                          :1;     // 此位已被占用(放电高温保护（电芯）)
			uint16_t cell_temp_low_prot				:1;
			uint16_t used11                         :1;     // 此位已被占用(放电低温保护（电芯）)
			uint16_t used12							:1;     // 此位已被占用(MOS高温保护)
			uint16_t used13							:1;     // 此位已被占用(环境高温保护)
			uint16_t used14							:1;     // 此位已被占用(环境低温保护)
			uint16_t used15							:1;     // 此位已被占用(满充)
		}bit;
	}protect_doublebyte1;
	
	union
	{
		uint16_t doublebyte;
		struct
		{
			uint16_t can_com_err					:1; 
			uint16_t canid_conflict					:1;
			uint16_t rsv_2							:1;
			uint16_t rsv_3                          :1;
			uint16_t rsv_4							:1;
			uint16_t rsv_5							:1; 
			uint16_t rsv_6							:1; 
			uint16_t rsv_7							:1; 

			uint16_t power_temp_high_prot           :1;
			uint16_t rsv_9							:1; 
			uint16_t rsv_10							:1;
			uint16_t rsv_11							:1;
			uint16_t rsv_12							:1; 
			uint16_t rsv_13							:1; 
			uint16_t rsv_14							:1;
			uint16_t rsv_15							:1;
		}bit;
	}protect_doublebyte2;
	
	union
	{
		uint16_t doublebyte;
		struct
		{
			uint16_t cell_volt_high_alarm			:1;
			uint16_t cell_volt_low_alarm			:1; 
			uint16_t total_volt_high_alarm			:1;
			uint16_t total_volt_low_alarm			:1;
			uint16_t uesd4                          :1;    // 此位已被占用(充电过流告警)
			uint16_t uesd5							:1;    // 此位已被占用(放电过流告警)
			uint16_t cell_volt_diff_over_alarm		:1; 
			uint16_t cell_temp_diff_over_alarm		:1;

			uint16_t cell_temp_high_alarm			:1;    // 包括电芯充放电高温告警
			uint16_t uesd9                          :1;    // 此位已被占用(电芯放电过温告警)
			uint16_t cell_temp_low_alarm            :1;    // 包括电芯充放电低温告警
			uint16_t uesd11                         :1;    // 此位已被占用(电芯放电低温告警)
			uint16_t en_temp_h_alm                  :1;
			uint16_t en_temp_l_alm                  :1;
			uint16_t mos_temp_high_alarm            :1;    // 不使用此位
			uint16_t soc_low_alarm                  :1;
		}bit;
	}alarm_doublebyte1;

	union
	{
		uint16_t doublebyte;
		struct
		{
			uint16_t pass_bal_invalid               :1;
			uint16_t act_bal_dev_alarm				:1;
			uint16_t act_bal_alarm                  :1; 
			uint16_t heat_device_alarm              :1;   // 不使用此位
			uint16_t sample_wire_alarm              :1;
			uint16_t heat_func_alarm                :1;   // 不使用此位
			uint16_t rsv_6                          :1;  
			uint16_t rsv_7                          :1;

			uint16_t cell_temp_high_tips            :1;
			uint16_t cell_temp_low_tips             :1;
			uint16_t rsv_10                         :1;
			uint16_t rsv_11                         :1;
			uint16_t rsv_12                         :1; 
			uint16_t rsv_13                         :1; 
			uint16_t rsv_14                         :1;
			uint16_t rsv_15                         :1;
		}bit;
	}alarm_doublebyte2;
	
	union
	{
		uint16_t doublebyte;
		struct
		{
			uint16_t used0							:1;    // 此位已被占用(放电MOS故障)
			uint16_t used1							:1;    // 此位已被占用(充电MOS故障)
			uint16_t ntc_fault                      :1;
			uint16_t volt_9v_err					:1; 
			uint16_t cell_volt_fault                :1;
			uint16_t sample_err						:1; 
			uint16_t used6							:1;    // 此位已被占用(限流板故障)
			uint16_t used7							:1;    // 此位已被占用(加热膜故障)

			uint16_t chg_curr_over_lock             :1;    //  CBS5000不使用
			uint16_t dsg_curr_over_lock             :1;    //  CBS5000不使用
			uint16_t cell_volt_over_lock            :1;
			uint16_t rsv_11                         :1;
			uint16_t cell_temp_fault                :1;
			uint16_t sample_wire_fault              :1; 
			uint16_t rsv_14                         :1;
			uint16_t cell_disable                   :1; 
		}bit;
	}fault_doublebyte1;
	
	union
	{
		uint16_t doublebyte;
		struct
		{
			uint16_t power_temp_over_disable        :1;
			uint16_t save_data_err                  :1;
			uint16_t sample_curr_zero_err           :1;   //  CBS5000不使用
			uint16_t mos_temp_over_disable          :1;   //  CBS5000不使用
			uint16_t insulation_res_err             :1;   //  CBS5000不使用
			uint16_t pre_chg_err                    :1;   //  CBS5000不使用
			uint16_t rsv_6                          :1;  
			uint16_t rsv_7                          :1;
						
			uint16_t rsv_8                          :1; 
			uint16_t rsv_9                          :1;
			uint16_t rsv_10                         :1;
			uint16_t rsv_11                         :1; 
			uint16_t rsv_12							:1;
			uint16_t rsv_13							:1; 
			uint16_t rsv_14							:1;
			uint16_t rsv_15							:1;
		}bit;
	}fault_doublebyte2;
	
}bmu_fault_info_t;

typedef void (*fault_check_opt_f)(void);

/**
* @brief		故障管理初始化
* @param		void
* @param		void
* @pre			系统启动时执行一次。
*/
void fault_manage_init(void);


/**
* @brief		故障诊断功能使能
* @param		void
* @param		void
* @pre			系统启动时执行一次。
*/
void fault_diag_enable(void);


/**
* @brief		故障运行步骤获取
*/
fault_diag_step_e fault_diag_step_get(void);


/**
* @brief		故障状态
* @param		[in] fault_type 故障类型
* @retval		1 有故障
* @retval		0 无故障
* @retval		-1 查询失败
*/
int32_t fault_state_get(fault_type_e fault_type);
/**
* @brief		获取保护动作
* @param		[in] type 故障动作类型
* @return		执行结果
*/
int32_t fault_protect_action_get(fault_protect_action_e type);

/**
 * @brief		获取充放电故障等级
 * @return		执行结果
 * @retval		>=0 故障数量
 * @retval		-1  获取失败
 */
const fault_stat_data_t* fault_chg_dsg_level_get(void);

/**
* @brief		故障诊断 执行周期100ms 应用调用
* @param		void
* @param		void
* @return		void
*/
int32_t fault_manage_task(void);

/**
 * @brief                故障读取
 * @return               返回结果空
 * @warning              测试调试使用
 */
int32_t shell_in_fault_proc(char *cmd, uint8_t len);

/**
 * @brief                需要录波故障ID读取
 * @return               返回结构体
 * @warning              
 */
const fault_id_t *get_fault_id(void);

/**
 * @brief                保持最新fault_id记录
 * @return               返回结构体
 * @warning              
 */
void fault_id_delete(void);

/**
 * @brief                故障开始记录后需要清除标志，防止重复记录
 * @return               返回结构体
 * @warning              
 */
void clean_fault_record_flag(uint8_t num);

/**
 * @brief                故障信息反馈
 * @return               返回结构体
 * @warning              
 */
const fault_info_t *get_fault_info(void);

/**
* @brief        bmu故障格式
* @param        [in] 无
* @return        [out]无
* @retval         无
*/
void bmu_inner_fault_change(fault_info_t *inner_fault, bmu_fault_info_t *bmu_fault);

/**
* @brief        故障变化标志
* @param        [in] uint8_t *fault_id
* @return        [out]bool  0:无需存储；1：需要存储
* @retval         无
*/
bool fault_state_change(uint8_t *fault_id);

/**
* @brief        电芯温度断线位
* @param        无
* @return       [out]uint8_t  具体断线位置    0xff是无效值
* @retval       无
*/
uint8_t get_cell_temp_wire_err_no(void);
#endif


