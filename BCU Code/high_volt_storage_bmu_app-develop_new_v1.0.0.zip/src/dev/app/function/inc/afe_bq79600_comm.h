#ifndef __BQ79600_COMMUNICATION_H__
#define __BQ79600_COMMUNICATION_H__

#include <stdint.h>
#include "app_public.h"

#define FRMWRT_SGL_R 		  0x00 // single device READ
#define FRMWRT_SGL_W 		  0x10 // single device WRITE
#define FRMWRT_STK_R 		  0x20 // stack READ
#define FRMWRT_STK_W 		  0x30 // stack WRITE
#define FRMWRT_ALL_R 		  0x40 // broadcast READ
#define FRMWRT_ALL_W 		  0x50 // broadcast WRITE
#define FRMWRT_REV_ALL_W 	  0x60 // broadcast WRITE reverse direction

#define NOT_NEED_CHECK 0xFFFFFFFFFFFFFFFF

#define DEV_ID_INDEX 1
#define READ_DATA_INDEX 4
#define CRC_DATA_COUNT 2
// 断线检测相关信息
#define AFE_CELL_RESULT_ERR (-1)      // 断线检测失败
#define AFE_CELL_RESULT_END (0)       // 短线检测结束
#define AFE_CELL_RESULT_CHECKING (1)  // 断线检测中
#define AFE_CELL_RESULT_WIRE_OPEN (2) // 断线
// 菊花链相关信息
#define CHAIN_UNBREAK 0        // 未断链
#define CHAIN_BREAK 1          // 断链
#define CHAIN_BREAK_MULTIPLE 2 // 多处断链
#define FORWARD_DIRECTION 0    // 菊花链正向
#define REVERSE_DIRECTION 1    // 菊花链反向
// 菊花链正/反向使能
#define FORWARD_ADDR_ENABLE 1
#define REVERSE_ADDR_ENABLE 1
// AFE堆栈设备数量修改
#define TOTAL_BOARDS 5
// afe设备名称
#if (2 == TOTAL_BOARDS)
typedef enum
{
    S1 = 0,
    STACK_BOARDS,
} stack_board_name_e;
#elif (3 == TOTAL_BOARDS)
typedef enum
{
    S1 = 0,
    S2,
    STACK_BOARDS,
} stack_board_name_e;
#elif (4 == TOTAL_BOARDS)
typedef enum
{
    S1 = 0,
    S2,
    S3,
    STACK_BOARDS,
} stack_board_name_e;
#elif (5 == TOTAL_BOARDS)
typedef enum
{
    S1 = 0,
    S2,
    S3,
    S4,
    STACK_BOARDS,
} stack_board_name_e;
#else
typedef enum
{
    S1 = 0,

    STACK_BOARDS = TOTAL_BOARDS - 1,
} stack_board_name_e;
#endif

void bq79600_wakeup(void);
void bq79600_comm_clear(void);
int32_t bq79600_communication_init(void);
int32_t write_reg(uint8_t dev_id, uint16_t addr, uint64_t val, uint64_t target_val, uint8_t write_len, uint8_t operate_type);
int32_t read_reg(uint8_t dev_id, uint16_t addr, uint8_t *buf, uint8_t read_len, uint8_t operate_type, uint32_t delay_ms);

#endif
