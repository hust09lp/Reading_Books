#ifndef __SOFAR_CAN_DATA_H__
#define __SOFAR_CAN_DATA_H__

#include <stdint.h>
#include <stddef.h>
#include "sample.h"

#define	CAN_MSG_EVENT_TYPE  	((uint8_t)0x01)
#define	CAN_MSG_CYCLE_TYPE  	((uint8_t)0x02)

#define WORD_SIZE              (2)
#define DWORD_SIZE             (4)

#define CYCLE_BASE_TIME_MS      10
#define	CYCLE_SEND_500MS		(500 / CYCLE_BASE_TIME_MS)
#define	CYCLE_SEND_100MS		(100 / CYCLE_BASE_TIME_MS)
#define	CYCLE_SEND_10MS		    (10 / CYCLE_BASE_TIME_MS)
#define	CYCLE_SEND_1000MS		(1000 / CYCLE_BASE_TIME_MS)
#define	CYCLE_SEND_2000MS		(2000 / CYCLE_BASE_TIME_MS)
#define	CYCLE_SEND_10000MS		(10000 / CYCLE_BASE_TIME_MS)
#define	CYCLE_SEND_60000MS		(60 * 1000 / CYCLE_BASE_TIME_MS)
#define	CYCLE_SEND_10MIN		(600 * 1000 / CYCLE_BASE_TIME_MS)

#define SHIFT_RIGHT(A)			(A>>8)

#define SEND_TIME 200

#define CAN_VERSION		"08" 	//和点表保持一致

typedef struct
{
	uint8_t flag;		// 更新标志
	uint16_t value;
}set_data_t;


typedef struct
{
	uint8_t No;		// 点表位置
	int8_t (*setfun)(uint8_t No, uint16_t value);
	uint16_t (*getfun)(uint8_t No);

}para_or_threhold_func_t;

typedef enum{
	NORMAL				=	0,
	OPEN				=	1,
	CLOSE				=	2,
	RELEASE_MODE		=	0X55,
	OPEN_MODE			=	0XAA

}mode_e;
/***********  设置参数点表  ***********/
// frame data id
// 注意1:必须与g_can_msg_list[] 顺序一一对应，(出现此打印，表示异常canList%d Err%d,0x%x\n)
// 注意2:需要解析放在FUNC_CAN_RECV_ID后面，只有发送而且不需要解析集中放在FUNC_CAN_ONLY_SEND_ID后面
typedef enum {
    // 有发送有接收，或者只有接收起始id
    FUNC_CAN_RECV_ID = 0,
    // bcu设置
    MASTER_CTL_CMD            = FUNC_CAN_RECV_ID,
    MASTER_CURR_SET_CMD          ,  // BMS控制信息3-设置状态参数/电流
    MASTER_BAL_SET_CMD           ,  // BMS控制信息4-均衡设置
    HEART_BEAT_CMD               ,  // 心跳帧
    MASTER_PASS_BAL_SET_CMD      ,  // BMS设置被动均衡
    MAS_OTHER_DATA_SET_CMD       ,  // 主机其他信息设置，包括SOC放电末端校准使用，一般配合0x04C使用

    // ate设置告警
    ATE_CELL_VOLT_OVER_ALM_SET   ,  // 单体过充故障参数标定
    ATE_BAT_VOLT_OVER_ALM_SET    ,  // 总体过充故障参数标定
    ATE_CELL_VOLT_UNDER_ALM_SET  ,  // 单体过放故障参数标定
    ATE_BAT_VOLT_UNDER_ALM_SET   ,  // 总体过放故障参数标定
    ATE_CHG_CURR_OVER_ALM_SET    ,  // 充电过流故障参数标定
    ATE_DCHG_CURR_OVER_ALM_SET   ,  // 放电过流故障参数标定
    ATE_CELL_TEMP_OVER_ALM_SET   ,  // 电芯高温故障参数标定
    ATE_CELL_TEMP_UNDER_ALM_SET  ,  // 电芯低温故障参数标定
    ATE_SOC_LOW_ALM_SET          ,  // 低电量故障参数标定
    ATE_BAT_CURR_OVER_ALM_2_SET  ,  // 充放电二级故障参数标定
    ATE_CELL_VOLT_ERR_ALM_SET    ,  // 单体超限超低故障参数标定
    ATE_CELL_VOLT_TIP_SET        ,  // 单体电压过充、过放提示标定
    ATE_CELL_VOLT_DIFF_1_SET     ,  // 单体电压压差过大提示、告警标定
    ATE_CELL_VOLT_DIFF_2_SET     ,  // 单体电压压差过大故障标定
    ATE_CELL_TEMP_TIP_SET        ,  // 电芯温度充放电高低温提示标定
    ATE_CELL_TEMP_DIFF_SET       ,  // 电芯温差过大提示，告警、保护标定
    ATE_BATT_VOLT_TIP_SET        ,  // 总压过压欠压提示标定
    // ate设置其他控制和标定
    ATE_FLASH_TEST               ,  // ATE_FLASH测试
    ATE_SET_OLD_MODE             ,  // 上位机控制老化状态
    ATE_BAL_HEAT_PARAM_SET       ,  // 均衡加热膜参数标定
    ATE_CELL_VOLT_CURR_LIMIT_SET ,  // 截至电压电流参数标定
    ATE_CELL_NUM_SET             ,  // 额定容量电芯个数参数标定
    ATE_CHG_DSG_CAP_SET          ,  // 累计充放电电量参数标
    ATE_SOX_SET                  ,  // SOX参数标
    ATE_SYS_TIME_SET             ,  // 时间标定
    ATE_PACK_SN_SET              ,  // PACK_SN标定
    ATE_BOARD_SN_SET             ,  // BOARD_SN标定
    ATE_CELL_INFO_SET            ,  // 设置电池信息
    ATE_CALI_PARAM_SET           ,  // 校准系数标定
    ATE_BMU_FUNC_SET             ,  // BMU功能开关
    ATE_MONITOR_DATA_READ        ,  // 上位机监控读取
    ATE_CLR_HISTORY_DATA         ,  // 一键清除历史故障
    ATE_READ_SET_DATA            ,  // 一键操作标定参数
    ATE_FORCE_CTL_SET            ,  // ATE强制控制指令
    ATE_FORCE_CTL_SET_2          ,  // ATE强制控制指令2

    // 只发送不解析的功能码对应id
    FUNC_CAN_ONLY_SEND_ID,
    // 回复主机
    SLAVER_CTL_REPLY             = FUNC_CAN_ONLY_SEND_ID,  // BMS回复信息2
    // bmu数据上报
    BMS_INTER_INFO2              ,  // BMS发送电池信息2
    BMS_INTER_INFO3              ,  // BMS发送电池信息3
    BMS_INTER_INFO4              ,  // BMS发送电池信息4
    BMS_INTER_INFO5              ,  // BMS发送电池信息5
    BMS_FAULT_INFO1              ,  // BMS发送内部电池故障信息1
    BMS_CELL_OTHER_INFO1         ,  // 其他信息
    BMS_INTER_INFO6              ,  // BMS发送电池信息6
    BMS_INTER_INFO7              ,  // BMS发送电池信息7
    //    BAL_TEMP_INFO1               ,  // BMS均衡温度1-2     --均衡温度不用该功能码
    POWER_MOS_TEMP_INFO          ,  // BMS功率端子温度
    BMS_FAULT_INFO2              ,  // BMS发送内部电池故障信息2
    BMS_REMOTE_SIGNAL_INFO1      ,  // 遥信数据上报1
    BMS_REMOTE_SIGNAL_INFO2      ,  // 遥信数据上报2
    ACT_BAL_INFO1                ,  // 主动均衡数据上报1
    ACT_BAL_INFO2                ,  // 主动均衡数据上报2
    SOFT_VER_INFO1               ,  // 设备软件版信息1
    SOFT_VER_INFO2               ,  // 设备软件版信息2
    SOFT_VER_INFO3               ,  // 设备软件版信息3
    BMS_REMOTE_SIGNAL_INFO3      ,  // 其他数据上报
    CELL_VOLT_OVERFLOW           ,  // 电芯电压
    CELL_TEMP_OVERFLOW           ,  // 电芯温度
    CELL_PASS_BAL_STATE_OVERFLOW ,  // 电芯被动均衡状态
    CELL_BAL_TEMP_OVERFLOW       ,  // 被动均衡电阻温度
    CELL_SOC_INFO                ,  // 单个电芯SOC
    CELL_SOH_INFO                ,  // 单个电芯SOH
    BMS_ALARM_TIPS_INFO3         ,  // BMS发送内部电池故障信息3
    MAS_OTHER_DATA_INFO          ,  // 主机其他信息,包括SOC放电末端校准数据
    ATE_TEST_INFO                ,  // ATE测试结果

    INNER_MSG_CNT,
} frame_data_id_e;

typedef enum
{
    NO_MODULE_SEND_REQ = 0,
    CELL_VOLT_MODULE_SEND_REQ,
    CELL_TEMP_MODULE_SEND_REQ,
    CELL_SOC_MODULE_SEND_REQ,
    CELL_SOH_MODULE_SEND_REQ,
    DEV_INFO_MODULE_SEND_REQ,
    PACK_REMOTE_COMM_DATA_SEND_REQ,
    PACK_REMOTE_COLLECT_DATA1_SEND_REQ,
    PACK_REMOTE_COLLECT_DATA2_SEND_REQ,
    BAL_MODULE_DATA_SEND_REQ,
    ATE_MODULE_DATA_SEND_REQ,
    PACK_SN_DATA_SEND_REQ,
    BOARD_SN_DATA_SEND_REQ,
    MODULE_REQ_SEND_REQ_NUM,
} module_request_send_group_e;

// 主动均衡模块使用
typedef enum
{
    CAN_BMU_BAL_STATUS = 0,
    CAN_BAL_MIN_CELL_SOC,
    CAN_ACT_BAL_EMPTY_FULL_TYPE,
    CAN_ACT_BAL_CMD_TYPE,
    CAN_ACT_BAL_CLR_FULL_TYPE,
    CAN_ACT_BAL_TYPE_NUM,
} can_active_balance_type_list_e;

// 发送bmu遥信数据请求数据
typedef struct
{
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t chg_enale : 1;
            uint8_t dsg_enale : 1;
            uint8_t bmu_cut_off_req : 1;
            uint8_t bmu_pow_off_req : 1;
            uint8_t force_chg_req : 1;
            uint8_t thre_val_sync_finish :1;
            uint8_t res1 : 2;
        } bits;
    } req;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t heat_req : 2;
            uint8_t res1 : 6;
        } bits;
    } req2;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t full_chg : 1;
            uint8_t empty_dsg : 1;
            uint8_t res1 : 6;
        } bits;
    } state;
} bmu_yx_req_data_t;

/**
* @brief		内网初始化
* @param		无
* @return		无
* @retval		无
* @warning		无
*/
void can_sofar_data_init(void);

// /**
// * @brief		自动发送内网数据
// * @param		[in]base_time 任务周期时间 ms
// * @return		返回结果
// * @retval		无
// * @warning		无
// */
void can_sofar_data_send_proc(void);

// /**
// * @brief		自动发送内网数据使能接口
// * @param		[in]使能标志： 0：不使能    1：使能
// * @return		返回结果
// * @retval		0：操作成功    < 0: 操作失败
// * @warning		无
// */
int32_t auto_send_can_sofar_enable_set(uint8_t enable);

/**
* @brief		请求发送can数据帧
* @param		无
* @return		返回结果
* @retval		无
* @warning		无
*/
void inner_can_send_msg_ready(frame_data_id_e send_id);

/**
 * @brief                获取主动均衡参数
 * @param                [in] 参数类型， type 参考(can_active_bal_type_e)
 * @return               返回结果：对应类型数据
 * @warning              调用此函数必须小于CAN_ACT_BAL_TYPE_NUM
 */

// 使能周期上报
void shell_data_cycle_send_set(uint32_t enable);

uint16_t bmu_active_bal_data_get(uint8_t bal_type_id);

/**
* @brief                获取烟雾传感器相关信息
* @param                [in]无
* @return               electrolyte_sensor_info_t
* @retval               NULL获取失败
* @retval               ret(!NULL)获取成功
* @warning              无
*/
electrolyte_sensor_info_t electrolyte_sensor_data_get(void);

/**
* @brief                获取bmu遥信相关信息
* @param                [in]无
* @return               bmu_yx_req_data_t
* @retval               NULL获取失败
* @retval               ret(!NULL)获取成功
* @warning              无
*/
bmu_yx_req_data_t *get_bmu_yx_req_data(void);

#endif
