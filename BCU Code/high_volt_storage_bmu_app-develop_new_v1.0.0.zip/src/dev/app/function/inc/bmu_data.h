/**
    * @file     sample.h
    * @brief    BMS信息数据文件
    * @company  sofarsolar
    * @author   
    * @note
    * @version
    * @date     2023/4/24
*/

#ifndef __BMU_DATA_H__
#define __BMU_DATA_H__

#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include "app_public.h"



/**
  * @struct    bat_sample_data_t
  * @brief  电池采样数据管理
  */
#pragma pack(1)
typedef struct
{
    int32_t    sys_current;                             ///< bcu+均衡系统电流           1mA
    int32_t    bcu_current;                             ///< bcu系统电流          1mA
    uint16_t   cell_volt[CELL_VOLT_NUM];        		///< 单体电压        单位1mV  
    int16_t    cell_temp[CELL_TEMP_NUM];        		///< 单体温度        单位0.1℃ 
    uint32_t   bat_afe_volt;                    		///< 采样总压AFE 单位1mV      
    uint32_t   bat_acc_volt;                    		///< 累计总压         单位1mV 
    uint32_t   max_cell_volt;                   		///< 最大单体电压 1mV         
    uint32_t   min_cell_volt;                   		///< 最小单体电压 1mV         
    uint32_t   avg_cell_volt;                   		///< 平均电压         1mV     
    uint32_t   diff_cell_volt;                  		///< 压差             1mV     
    uint8_t    max_volt_num;                    		///< 最大单体电压序号         
    uint8_t    min_volt_num;                    		///< 最小单体电压序号         
    uint8_t    max_temp_num;                    		///< 最高温度序号             
    uint8_t    min_temp_num;                    		///< 最低温度序号             
    int16_t    max_cell_temp;                   		///< 最大单体温度 0.1℃        
    int16_t    min_cell_temp;                   		///< 最小单体温度 0.1℃        
    int16_t    avg_cell_temp;                   		///< 平均温度         0.1℃    
    int16_t    diff_cell_temp;                  		///< 温差             0.1℃    
    int16_t    adc_sample_other_temp[OTHER_NTC_NUM];    ///< 除电芯温度的其他温度,单位0.1℃
    uint32_t   check_5v_volt;                           ///< 5V电压检测      单位1mV
    uint32_t   check_24v_volt;                          ///< 24V电压检测     单位1mV
    uint32_t   hardware_version_volt;                   ///< 硬件版本号识别  单位1mV 
    uint16_t   bal_stus[CELL_VOLT_NUM/16];              ///< 均衡位置
    uint16_t   electrolyte_strength;                    ///< 电解液漏液浓度
}bmu_data_t;
#pragma pack()

/**
* @brief                BMS信息数据初始化
* @param                [in]无
* @return               无返回结果
* @warning              无
*/
void bmu_data_init(void);

/**
* @brief                获取BMS数据信息
* @param                [in]无
* @return               返回结果 bmu_data_t*
* @retval               ret(!=NULL)获取成功
* @retval               ret(NULL)获取失败
* @warning              必须判断返回指针
*/
const bmu_data_t* bmu_data_p_get(void);

/**
 * @brief                BMS信息数据任务
 * @param                [in]void
 * @return               返回结果空
 * @retval               [out]无
 * @warning              放在10ms任务，必须要调用bms_data_init()后使用
 */
void bmu_data_proc(void);

/**
 * @brief      采样异常状态获取
 * @param      [in]abnormal_type_e
 * @return     返回结果
 * @retval     [out]ret(SAMPLE_STATE_OK)  获取采集状态成功
 * @retval     [out]ret(SAMPLE_STATE_EOI) 获取采集状态失败
 * @retval     [out]ret(NTC_SHORT_CIRCUIT) NTC短路
 * @retval     [out]ret(NTC_OPEN_CIRCUIT)  NTC开路
 * @warning    在采集任务开始以后调用
 */
int32_t sample_abnormal_get(other_ntc_type_e type);


/**
 * @brief                BMU电流数据设置
 * @param                [in]current_value
 * @return               返回结果
 * @retval               [out]0 成功
 * @warning              仅由sofar_can_data.c调用，用于BCU传输电流数据给BMU使用
 */
int8_t bmu_sys_current_data_set(uint8_t no,int16_t current);

/**
 * @brief                BMU电流数据返回
 * @param                [in]no
 * @return               返回结果空
 * @retval               [out]0 成功
 * @warning              仅由sofar_can_data.c调用，用于BMU传输电流数据给BCU使用
 */
uint16_t bmu_sys_current_data_get(uint8_t no);

/**
* @brief                获取升温异常标志
* @param                [in]无
* @return               1：异常，0：正常
* @warning              
*/
uint8_t cell_temp_rise_abnormal_get(void);

#ifdef SIMULATION_DATA_TEST
/**
 * @brief                数据读取
 * @return               返回结果空
 * @warning              测试调试使用
 */
int32_t shell_in_bmu_data_proc(char *cmd, uint8_t len);

/**
 * @brief                进入BMU测试模式
 * @return               返回结果空
 * @warning              测试调试使用
 */
int32_t shell_in_set_bmudata_proc(char *cmd, uint8_t len);

/**
 * @brief                bmu数据设置
 * @return               返回结果空
 * @warning              测试调试使用
 */
void set_bmu_data_test(bmu_data_t bmu_data);
#endif

#endif

