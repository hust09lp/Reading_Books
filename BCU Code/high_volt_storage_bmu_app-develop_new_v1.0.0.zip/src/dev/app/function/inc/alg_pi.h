/*!*************************************************************
* @file			PI_I_CTRL_F.h
* @brief		增量式PI比例积分算法模块头文件。
* @details 		该文件包含数据类型定义、通用算法中用到的结构定义。
* @attention 	请勿修改本文件中的内容！
* @date 		2022-09-01
* @copyright	SofarSolar。
***************************************************************/
#ifndef __ALG_PI_H__
#define __ALG_PI_H__

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdint.h>
//---------------------------------------------------------------------------
// Structure Definition
//---------------------------------------------------------------------------
/**
  * @brief 	增量式PI比例积分模块数据结构
  */
typedef struct {
	float ref; // Input: reference set-point
	float fbk; // Input: feedback
	float out; // Output: controller output
	float kp; // Parameter: proportional loop gain
	float ki; // Parameter: integral gain
	float out_max; // Parameter: upper saturation limit
	float out_min; // Parameter: lower saturation limit
	float errn; // Data: error e(n)
	float errn1; // Data: last error e(n-1)
} alg_pi_ctrl_t;

//---------------------------------------------------------------------------
// Function Declarations
//---------------------------------------------------------------------------
void alg_pi_ctrl_init(alg_pi_ctrl_t *v, float kp, float ki, float out_max, float out_min);
float algo_pi_ctrl_calc(alg_pi_ctrl_t *v, float ref, float fbk);
void algo_pi_ctrl_clr(alg_pi_ctrl_t *v);
	
float algo_dchg_pwm_pi_ctrl_calc(alg_pi_ctrl_t *v, float ref, float fbk);
	
#ifdef __cplusplus
}
#endif	

#endif /* PI_I_CTRL_F_H_ */
