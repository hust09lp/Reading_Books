/*****************************************************************************
 * Copyright (c) 2019, Nations Technologies Inc.
 *
 * All rights reserved.
 * ****************************************************************************
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the disclaimer below.
 *
 * Nations' name may not be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * DISCLAIMER: THIS SOFTWARE IS PROVIDED BY NATIONS "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * DISCLAIMED. IN NO EVENT SHALL NATIONS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ****************************************************************************/


/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "osif.h"
#include "n32g45x_STLparam.h"
#include "n32g45x_STLclassBvar.h"
#include "n32g45x_STLlib.h"

uint32_t g_runtime_check_init_flag = 0X00;
volatile static uint16_t tmpCC4_last;	/* keep last TIM5/Chn4 captured value */

/** @addtogroup N32G45xSelfTestLib_src
  * @{
  */ 

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
ErrorStatus STL_CheckStack(void);

/**
  * @brief  Initializes the Class B variables and their inverted
  *   redundant counterparts. Init also the Systick and RTC timer
  *   for clock frequency monitoring.
  * @param :  None
  * @retval : None
  */
void selftest_run_init(void)
{
    uint32_t tout;
    
    /* Init Class B variables required in main routine and SysTick interrupt
    service routine for timing purposes */
    STL_TranspMarchInit();
    
    TickCounter = 0uL;
    TickCounterInv = 0xFFFFFFFFuL;
    
    TimeBaseFlag = 0uL;
    TimeBaseFlagInv = 0xFFFFFFFFuL;
    
    LastCtrlFlowCnt = 0uL;
    LastCtrlFlowCntInv = 0xFFFFFFFFuL;
    
    /* Initialize variables for SysTick interrupt routine control flow monitoring */
    ISRCtrlFlowCnt = 0uL;
    ISRCtrlFlowCntInv = 0xFFFFFFFFuL;
    
    /* Initialize variables for run time invariable memory check */  
    STL_FlashCrc32Init();
    
    /* wait till HSE measurement is completed & check timer system */
    tout = os_kernel_get_tick_count() + 5u;
    LSIPeriodFlag = 0u;
    
    /* MISRA violation of rule 12.4, 12.5 - "&&" operand can't contain side effects 
      and shall be primary expressions  */
#ifdef __IAR_SYSTEMS_ICC__  /* IAR Compiler */
    #pragma diag_suppress= Pm026,Pm027              
#endif
    while ( LSIPeriodFlag == 0u  &&  os_kernel_get_tick_count() < tout )  { }
    LSIPeriodFlag = 0u;
    while ( LSIPeriodFlag == 0u  &&  os_kernel_get_tick_count() < tout )  { }
#ifdef __IAR_SYSTEMS_ICC__  /* IAR Compiler */
    #pragma diag_default= Pm026,Pm027
#endif 
    
    if(os_kernel_get_tick_count() >= tout)
    {
        #ifdef STL_VERBOSE
        printf("Run time clock measurement failure\r\n");
        #endif /* SELFTEST_VERBOSE_POR */
        FailSafePOR();
    }
    /* Initialize variables for main routine control flow monitoring */
    CtrlFlowCnt = 0uL;
    CtrlFlowCntInv = 0xFFFFFFFFuL;
    
    g_runtime_check_init_flag = 0xAA;
}
        
void selftest_run_ram_check(void)
{
    if(g_runtime_check_init_flag != 0xAA)
    {
        return;
    }
    /* Verify TickCounter integrity */
    if ((TickCounter ^ TickCounterInv) == 0xFFFFFFFFuL)
    {
        TickCounter++;
        TickCounterInv = ~TickCounter;
    
        if (TickCounter >= SYSTICK_20ms_TB)
        {
            uint32_t RamTestResult;
            
            /* Reset timebase counter */
            TickCounter = 0u;
            TickCounterInv = 0xFFFFFFFF;
            
            /* Set Flag read in main loop */
            TimeBaseFlag = 0xAAAAAAAAuL;
            TimeBaseFlagInv = 0x55555555uL;
                           
            /*----------------------------------------------------------------------*/
            /*------------------     RAM test(in interrupt)  -----------------------*/
            /*----------------------------------------------------------------------*/
            ISRCtrlFlowCnt += RAM_MARCHC_ISR_CALLER;
            __disable_irq();
            RamTestResult = STL_TranspMarch();
            __enable_irq();
            ISRCtrlFlowCntInv -= RAM_MARCHC_ISR_CALLER; 
            switch ( RamTestResult )
            {
                case TEST_RUNNING:
                    break;
                case TEST_OK:
                    break;
                case TEST_FAILURE:
                case CLASS_B_DATA_FAIL:
                default:
                  #ifdef STL_VERBOSE
                    printf("\n\rRAM Error (March C- Run-time check)\n\r");
                  #endif  /* STL_VERBOSE */
                  FailSafePOR();
                  break;
            } /* End of the switch */
            
            /* Do we reached the end of RAM test? */
            /* Verify 1st ISRCtrlFlowCnt integrity */
            if ((ISRCtrlFlowCnt ^ ISRCtrlFlowCntInv) == 0xFFFFFFFFuL)
            {
              if (RamTestResult == TEST_OK)
              {
                if (ISRCtrlFlowCnt != RAM_TEST_COMPLETED)
                {
                  #ifdef STL_VERBOSE
                    printf("\n\r Control Flow error (RAM test) \n\r");
                  #endif  /* STL_VERBOSE */
                    FailSafePOR();
                }
                else  /* Full RAM was scanned */
                {
                   ISRCtrlFlowCnt = 0u;
                   ISRCtrlFlowCntInv = 0xFFFFFFFFuL;
                }
              } /* End of RAM completed if*/
            } /* End of control flow monitoring */
            else
            {
              #ifdef STL_VERBOSE
                printf("\n\r Control Flow error in ISR \n\r");
              #endif  /* STL_VERBOSE */
                FailSafePOR();
            }         
       
        } /* End of the 20 ms timebase interrupt */
    }
}
/* ---------------------------------------------------------------------------*/
/**
  * @brief  Provide a short description of the function
  * @param :  None
  * @retval : None
  */
uint32_t debugtemp = 0;
void selftest_run_check(void)
{
    /* Is the time base duration elapsed? */
    if (TimeBaseFlag == 0xAAAAAAAAuL)
    {
        uint32_t TmpFlag = TimeBaseFlagInv;
    
        /* Verify its integrity (class B variable) */
        if ((TimeBaseFlag ^ TmpFlag) == 0xFFFFFFFFuL)
        {
            uint32_t RomTest;
            
            /* Reset Flag (no need to reset the redundant: it is not tested if
            TimeBaseFlag != 0xAAAAAAAA, it means that 100ms elapsed */
            TimeBaseFlag = 0uL;
            
            /*----------------------------------------------------------------------*/
            /*---------------------------- CPU registers ----------------------------*/
            /*----------------------------------------------------------------------*/
            CtrlFlowCnt += CPU_TEST_CALLER;
            if (STL_RunTimeCPUTest() != CPUTEST_SUCCESS)
            {
              #ifdef STL_VERBOSE
                printf("Run-time CPU Test Failure\n\r");
              #endif /* STL_VERBOSE */
                FailSafePOR();
            }
            else
            {
                CtrlFlowCntInv -= CPU_TEST_CALLER;
            }
            
            /*----------------------------------------------------------------------*/
            /*------------------------- Stack overflow -----------------------------*/
            /*----------------------------------------------------------------------*/
            CtrlFlowCnt += STACK_OVERFLOW_TEST;
            if (STL_CheckStack() != SUCCESS)
            {
              #ifdef STL_VERBOSE
                printf("Stack overflow\n\r");
              #endif /* STL_VERBOSE */
                FailSafePOR();
            }
            else
            {
                CtrlFlowCntInv -= STACK_OVERFLOW_TEST;
            }
            
            /*----------------------------------------------------------------------*/
            /*------------------------- Clock monitoring ---------------------------*/
            /*----------------------------------------------------------------------*/
            CtrlFlowCnt += CLOCK_TEST_CALLER;
            
            switch ( SelfTest_MainClockTest() )
            {
                case FREQ_OK:
                    control_flow_resume(CLOCK_TEST_CALLER);
                    break;
                
                case EXT_SOURCE_FAIL:
                  #ifdef SELFTEST_VERBOSE_MAIN
                    /* finish communication flow prior system clock change */
                    while(USART_GetFlagStatus(USARTx,USART_FLAG_TRAC)==RESET){ }
                    USART_Reconfiguration();
                    printf("Clock Source failure (Run-time)\r\n");
                  #endif /* SELFTEST_VERBOSE_MAIN */
                    FailSafePOR();
                    break;
                
                case CLASS_B_VAR_FAIL:
                  #ifdef SELFTEST_VERBOSE_MAIN
                    printf("Class B variable error (clock test)\r\n");
                  #endif /* SELFTEST_VERBOSE_MAIN */
                    FailSafePOR();
                    break;
                
                case LSI_START_FAIL:
                case HSE_START_FAIL:
                case HSI_HSE_SWITCH_FAIL:
                case TEST_ONGOING:
                case CTRL_FLOW_ERROR:
                default:
                  #ifdef SELFTEST_VERBOSE_MAIN
                    printf("Abnormal Clock Test routine termination\r\n");
                  #endif  /* SELFTEST_VERBOSE_MAIN */
                    FailSafePOR();
                    break;
            }
            
            /*----------------------------------------------------------------------*/
            /*------------------ Invariable memory CRC check -----------------------*/
            /*----------------------------------------------------------------------*/
            CtrlFlowCnt += FLASH_TEST_CALLER;
            
            RomTest = STL_crc32Run();
            
            switch ( RomTest )
            {
                case TEST_RUNNING:
                    CtrlFlowCntInv -= FLASH_TEST_CALLER;
                  break;
                
                case TEST_OK:
                  #ifdef STL_VERBOSE
                    //printf("FLASH test OK\n\r");      /* FLASH test OK mark */
                  #endif  /* STL_VERBOSE */
                    CtrlFlowCntInv -= FLASH_TEST_CALLER;
                  break;
                
                case TEST_FAILURE:
                case CLASS_B_DATA_FAIL:
                default:
                  #ifdef STL_VERBOSE
                    printf("\n\r Run-time FLASH CRC Error\n\r");
                  #endif  /* STL_VERBOSE */
                    FailSafePOR();
                  break;
            }
                 
            if (((CtrlFlowCnt ^ CtrlFlowCntInv) == 0xFFFFFFFFuL)
              &&((LastCtrlFlowCnt ^ LastCtrlFlowCntInv) == 0xFFFFFFFFuL))
            {
                if (RomTest == TEST_OK)
                {
                    debugtemp = CORE_ROM_SIZE;
                  #ifdef __IAR_SYSTEMS_ICC__  /* IAR Compiler */
                    /* ==============================================================================*/
                    /*   MISRA violation of rule 17.4 - pointer arithmetic is used for Control flow calculation */
	                #pragma diag_suppress=Pm088
                  #endif   /* IAR Compiler */
                    if ((CtrlFlowCnt == FULL_FLASH_CHECKED)\
                    && ((CtrlFlowCnt - LastCtrlFlowCnt) == (LAST_DELTA_MAIN)))
                  #ifdef __IAR_SYSTEMS_ICC__  /* IAR Compiler */
	                #pragma diag_default=Pm088
                    /* ==============================================================================*/
                  #endif   /* IAR Compiler */
                    {
                        CtrlFlowCnt = 0uL;
                        CtrlFlowCntInv = 0xFFFFFFFFuL;
                    }
                    else  /* Return value form crc check was corrupted */
                    {
                      #ifdef STL_VERBOSE
                        printf("Control Flow Error (main loop, Flash CRC)\n\r");
                      #endif  /* STL_VERBOSE */
                        FailSafePOR();
                    }
                }
                else  /* Flash test not completed yet */
                {
                    if ((CtrlFlowCnt - LastCtrlFlowCnt) != DELTA_MAIN)
                    {
                      #ifdef STL_VERBOSE
                        printf("Control Flow Error (main loop, Flash CRC on-going)\n\r");
                      #endif  /* STL_VERBOSE */
                        FailSafePOR();
                    }
                }           
                LastCtrlFlowCnt = CtrlFlowCnt;
                LastCtrlFlowCntInv = CtrlFlowCntInv;
            }
            else
            {
                #ifdef STL_VERBOSE
                  printf("Control Flow Error (main loop)\n\r");
                #endif  /* STL_VERBOSE */
                FailSafePOR();
            }
              
        } /* End of periodic Self-test routine */
        else  /* Class B variable error (can be Systick interrupt lost) */
        {
          #ifdef STL_VERBOSE
            printf("\n\r Class B variable error (clock test)\n\r");
          #endif  /* STL_VERBOSE */
            FailSafePOR();
        }
    } /* End of periodic Self-test routine */
    TimeBaseFlag= 0;
    TimeBaseFlagInv= ~TimeBaseFlag;
}



/* ---------------------------------------------------------------------------*/
/**
  * @brief  This function verifies that Stack didn't overflow
  * @param :  None
  * @retval : ErrorStatus = (ERROR, SUCCESS)
  */
ErrorStatus STL_CheckStack(void)
{
    ErrorStatus Result = ERROR;

    CtrlFlowCnt += STACK_OVERFLOW_CALLEE;
    
    if (aStackOverFlowPtrn[0] != 0xAAAAAAAAuL)
    {
        Result = ERROR;
    }
    else /* aStackOverFlowPtrn[0] == 0xAAAAAAAA */
    {
        if (aStackOverFlowPtrn[1] != 0xBBBBBBBBuL)
        {
            Result = ERROR;
        }
        else /* aStackOverFlowPtrn[1] == 0xBBBBBBBB */
        {
            if (aStackOverFlowPtrn[2] != 0xCCCCCCCCuL)
            {
                Result = ERROR;
            }
            else /* aStackOverFlowPtrn[2] == 0xCCCCCCCC */
            {
                if (aStackOverFlowPtrn[3] != 0xDDDDDDDDuL)
                {
                    Result = ERROR;
                }
                else
                {
                    Result = SUCCESS;
                }
            }
        }
    }

    CtrlFlowCntInv -= STACK_OVERFLOW_CALLEE;

    return (Result);
}

/* ---------------------------------------------------------------------------*/
/**
  * @brief  This function initialize both independent & window system watch dogs
  * @param :  None
  * @retval None
  */
void initialize_system_wdogs(void)
{
  #ifdef USE_INDEPENDENT_WDOG
    /* Ebnable LSI clcok to feed IWDG & wait until clock are ready */
    RCC_EnableLsi(ENABLE);
    while (RCC_GetFlagStatus(RCC_FLAG_LSIRD)!= SET)
    { }
       
    /* Enable write access to IWDG_PR and IWDG_RLR registers */
    IWDG_WriteConfig(IWDG_WRITE_ENABLE);
    /* IWDG clock: 40KHz(LSI) / 4 = 10KHz */
    IWDG_SetPrescalerDiv(IWDG_PRESCALER_DIV4);;
    /* Set counter reload value to 1/10k*250=25ms */
    IWDG_CntReload(250u);
    /* Reload IWDG counter */
    IWDG_ReloadKey();
    /* Enable IWDG */
    IWDG_Enable();
    
  #endif  /* USE_INDEPENDENT_WDOG */
      
  #ifdef USE_WINDOW_WDOG
    /* enable clock for WWDG */
    RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_WWDG, ENABLE);
     /* WWDG clock counter = (PCLK1(36M)/4096)/8 = 1098 Hz  */
    WWDG_SetPrescalerDiv(WWDG_PRESCALER_DIV8);
    /* set window value above 0x44 with some reserve */
    WWDG_SetWValue(0x7Fu);
    WWDG_Enable(0x7Fu); // when wwdg cnt < 0x40,wwdg reset:1/1098*0x40=58ms
  #endif  /* USE_WINDOW_WDOG */
}

/******************************************************************************/
/**
  * @brief  This function handles TIM5 global interrupt request.
  * @param  : None
  * @retval : None
  */
void TIM5_IRQHandler(void)
{
  uint16_t tmpCC4_last_cpy;
	
  if ((TIM5->STS & TIM_STS_CC4ITF) != 0u )
  {
    /* store previous captured value */
    tmpCC4_last_cpy = tmpCC4_last; 
    /* get currently captured value */
    tmpCC4_last = (uint16_t)(TIM5->CCDAT4);
    /* The CC4IF flag is already cleared here be reading CCR4 register */

    /* overight results only in case the data is required */
    if (LSIPeriodFlag == 0u)
    {
      /* take correct measurement only */
      if ((TIM5->STS & TIM_STS_CC4OCF) == 0u)
      {
        /* Compute period length */
        PeriodValue = ((uint32_t)(tmpCC4_last) - (uint32_t)(tmpCC4_last_cpy))& 0xFFFFuL;      
        PeriodValueInv = ~PeriodValue;
      
        /* Set Flag tested at main loop */
        LSIPeriodFlag = 0xAAAAAAAAuL;
        LSIPeriodFlagInv = 0x55555555uL;
      }
      else
      {
        /* ignore computation in case of IC overflow */
        TIM5->STS &= (~TIM_STS_CC4OCF);
      }
    }
    /* ignore computation in case data is not required */
  }
}

/******************************************************************************/
/**
  * @brief Configure TIM5 to measure LSI period
  * @param  : None
  * @retval : ErrorStatus = (ERROR, SUCCESS)
  */
ErrorStatus SelfTest_InitClock_Xcross_Measurement(void)
{
  ErrorStatus result = SUCCESS;

  TIM_TimeBaseInitType TIM_BaseStructure;
  TIM_ICInitType TIM_ICStructure;
  NVIC_InitType NVIC_InitStructure; 
 
  /*## Enable peripherals and GPIO Clocks ####################################*/
  /* TIMx Peripheral clock enable */
  RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_TIM5,ENABLE);
  /*## Configure the NVIC for TIMx ###########################################*/
  NVIC_InitStructure.NVIC_IRQChannel = TIM5_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 4;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
 
  /* TIM5 configuration: Input Capture mode ---------------------
  The LSI oscillator is connected to TIM5 CH4.
  The Rising edge is used as active edge, input divided by 8
  The TIM5 CC4 is used to compute the frequency value. 
  ------------------------------------------------------------ */
  TIM_BaseStructure.Prescaler = 0;
  TIM_BaseStructure.CntMode = TIM_CNT_MODE_UP;  
  TIM_BaseStructure.Period = 0xFFFF;  
  TIM_BaseStructure.ClkDiv = 0;
  TIM_BaseStructure.RepetCnt = 0;
  TIM_InitTimeBase(TIM5, &TIM_BaseStructure);

  /* Connect internally the TIM5_CH4 Input Capture to the LSI clock output */
  RCC_EnableAPB2PeriphClk(RCC_APB2_PERIPH_AFIO,ENABLE);
  GPIO_ConfigPinRemap(GPIO_RMP_TIM5CH4,ENABLE);
  
  /* Configure the TIM5 Input Capture of channel 4 */
  TIM_ICStructure.Channel = TIM_CH_4;
  TIM_ICStructure.IcPolarity = TIM_IC_POLARITY_RISING;
  TIM_ICStructure.IcSelection = TIM_IC_SELECTION_DIRECTTI;
  TIM_ICStructure.IcPrescaler = TIM_IC_PSC_DIV8; // IcPrescaler = TIM_IC_PSC_DIV8,limit should * 8
  TIM_ICStructure.IcFilter = 0x00;
  TIM_ICInit(TIM5,&TIM_ICStructure);
  /* Reset the flags */
  LSIPeriodFlag = 0u;
  /* Start the TIM Input Capture measurement in interrupt mode */
  TIM_ConfigInt(TIM5, TIM_INT_CC4, ENABLE);
  TIM_Enable(TIM5, ENABLE);
  return(result);
}

/**
  * @}
  */

/******************* (C)  *****END OF FILE****/
