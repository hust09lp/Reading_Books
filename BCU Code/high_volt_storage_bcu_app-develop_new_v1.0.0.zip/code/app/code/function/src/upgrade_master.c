#include "upgrade_master.h"
#include "upgrade.h"
#include <string.h>
#include "sofar_can_manage.h"
#include "auto_addressing.h"
#include "sdk.h"
#include "sdk_para.h"
#include "sdk_iap_para.h"
#include "app_public.h"
#include "sdk_public.h"
#include "app_config.h"
#include "data_store.h"
#include "state_machine.h"
#include "fault_manage.h"

#define UPGRADE_MASTER_DEBUG_ENABLE 1									///< 0禁止打印信息 1使能打印信息
#define BMU_ADDR_DEFAULT            0x1F  // 未编址前的默认地址

static uint16_t valid_bmu_num(void);

/* 接收BMU升级报文相关处理函数 */
static int32_t upgrade_master_timing_time_int_master(can_frame_data_t *frame_data);
static int32_t upgrade_master_file_info_int_master(can_frame_data_t *frame_data);
static int32_t upgrade_master_file_check_int_master(can_frame_data_t *frame_data);
static int32_t upgrade_master_file_end_int_master(can_frame_data_t *frame_data);
static int32_t upgrade_master_file_block_start(can_frame_data_t *frame_data);

/********************************bcu升级bmu状态机处理函数声明****************************************/
static uint8_t sta_upgrade_master_wait_start_entry(void);
static uint8_t sta_upgrade_master_wait_start_run(void);
static uint8_t sta_upgrade_master_file_info_entry(void);
static uint8_t sta_upgrade_master_file_info_run(void);
static uint8_t sta_upgrade_master_block_info_entry(void);
static uint8_t sta_upgrade_master_block_info_run(void);
static uint8_t sta_upgrade_master_block_data_entry(void);
static uint8_t sta_upgrade_master_block_data_run(void);
static uint8_t sta_upgrade_master_file_check_entry(void);
static uint8_t sta_upgrade_master_file_check_run(void);
static uint8_t sta_upgrade_master_finish_entry(void);
static uint8_t sta_upgrade_master_finish_run(void);
static uint8_t sta_upgrade_master_error_entry(void);
static uint8_t sta_upgrade_master_error_run(void);

/********************************bcu升级bmu状态机使用变量定义****************************************/
static fsm_action_map_t g_upgrade_master_act_map[UPG_MASTER_STA_NUM] = 
{
    [UPG_MASTER_WAIT_START]           = {sta_upgrade_master_wait_start_entry, sta_upgrade_master_wait_start_run},
    [UPG_MASTER_FILE_INFO]            = {sta_upgrade_master_file_info_entry, sta_upgrade_master_file_info_run},
    [UPG_MASTER_BLOCK_INFO]           = {sta_upgrade_master_block_info_entry, sta_upgrade_master_block_info_run},
    [UPG_MASTER_BLOCK_DATA]           = {sta_upgrade_master_block_data_entry, sta_upgrade_master_block_data_run},
    [UPG_MASTER_FILE_CHECK]           = {sta_upgrade_master_file_check_entry, sta_upgrade_master_file_check_run},
    [UPG_MASTER_UPDATE_FINISH]        = {sta_upgrade_master_finish_entry, sta_upgrade_master_finish_run},   
    [UPG_MASTER_UPDATE_ERROR]         = {sta_upgrade_master_error_entry, sta_upgrade_master_error_run},
                                                                                                                                                                                                                                              
};

static uint8_t g_upgrade_master_evt_sta_map[UPG_MASTER_STA_NUM][UPG_MASTER_EVT_NUM] = 
{                    // EVT_UPG_MASTER_STA_CPL_SUS  		EVT_UPG_MASTER_OPERATE_FAIL   	EVT_UPG_MASTER_TIMEOUT_OR_ERR  EVT_UPG_MASTER_START  EVT_UPG_MASTER_BLOCK EVT_UPG_MASTER_CHECK
    [UPG_MASTER_WAIT_START]           = {STA_NULL,           		STA_NULL,           	STA_NULL,           			UPG_MASTER_FILE_INFO,   STA_NULL,        		STA_NULL},
    [UPG_MASTER_FILE_INFO]            = {UPG_MASTER_BLOCK_INFO,     STA_NULL,               UPG_MASTER_UPDATE_ERROR,   		STA_NULL,           	STA_NULL,        		STA_NULL},
    [UPG_MASTER_BLOCK_INFO]           = {UPG_MASTER_BLOCK_DATA,     STA_NULL,           	UPG_MASTER_UPDATE_ERROR,   		UPG_MASTER_FILE_INFO,   STA_NULL,        		STA_NULL},
    [UPG_MASTER_BLOCK_DATA]           = {UPG_MASTER_FILE_CHECK,     STA_NULL,           	UPG_MASTER_UPDATE_ERROR,   		UPG_MASTER_FILE_INFO,   UPG_MASTER_BLOCK_INFO,  STA_NULL},
    [UPG_MASTER_FILE_CHECK]           = {UPG_MASTER_UPDATE_FINISH,  UPG_MASTER_BLOCK_INFO,  UPG_MASTER_UPDATE_ERROR,        UPG_MASTER_FILE_INFO,   STA_NULL,        		STA_NULL},
    [UPG_MASTER_UPDATE_FINISH]        = {UPG_MASTER_WAIT_START,     STA_NULL,           	UPG_MASTER_UPDATE_ERROR,        UPG_MASTER_FILE_INFO,   STA_NULL,        		STA_NULL},    
    [UPG_MASTER_UPDATE_ERROR]         = {UPG_MASTER_UPDATE_FINISH,  STA_NULL,           	UPG_MASTER_WAIT_START,          UPG_MASTER_FILE_INFO,   STA_NULL,               UPG_MASTER_FILE_CHECK},
};

/* 全局变量初始化 */
static state_machine_t g_upgrade_master_fsm = {0};
static const char* g_upgrade_master_fsm_name = "upgMaster";
static upgrade_master_fsm_para_t g_upgrade_master_fsm_para = {0};
static uint8_t g_upgrade_master_state = UPG_MASTER_IDLE;                      // 升级状态：0未升级 1升级中	2升级完成  3升级失败
static upgrade_data_info_t g_upgrade_master_data_info = {0};
static upgrade_master_proc_para_t g_upg_master_proc_para = {0};
static fs_t* gp_fs = NULL;
static uint8_t g_try_restart_flag = false;

/******************************************升级相关发送报文函数*******************************************************/
/**
* @brief		发送升级启动报文
* @param		无
* @return		执行结果
* @retval		无
* @pre			无
*/
static int32_t send_upgrade_req_info(void)
{
    int32_t ret = 0;
    uint8_t data[8] = {0};
    can_frame_id_u frame_tx_id = {0};
    frame_tx_id.bit.src_addr = BCU_INNER_CAN_ADDR; // TODO
    frame_tx_id.bit.src_type = DEV_BCU;
    frame_tx_id.bit.dst_addr = BROCAST_DEVICE_ADDRESS;   //广播升级
    frame_tx_id.bit.dst_type = DEV_BMU;
    frame_tx_id.bit.fun_code = FUNC_DOWN_FILE_START;
    frame_tx_id.bit.prio = SOFAR_CAN_PRI_HIGH_H;

    data[0] = 0; // 请求
    data[1] = UPD_MASTER_BMU_CHIP_ROLE;
    data[2] = BMU_CHIP_MODEL_0; 
    data[3] = BMU_CHIP_MODEL_1;
    // 此处的块数由于bts5k理解成块id号，导致从0开始计算，比真正的块数少一
//    uint16_t block_max_id = g_upgrade_master_data_info.block_total_num;
//    if (block_max_id > 0)
//    {
//        block_max_id = block_max_id - 1;
//    }
    data[4] = (uint8_t)(g_upgrade_master_data_info.block_total_num >> 0); // 文件数据块总数
    data[5] = (uint8_t)(g_upgrade_master_data_info.block_total_num >> 8);
    data[6] = (uint8_t)(g_upgrade_master_data_info.block_size >> 0); // 数据块大小
    data[7] = (uint8_t)(g_upgrade_master_data_info.block_size >> 8);
    ret = can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_tx_id.id_val, data, 8);
    log_d("[upd bmu]send file property\r\n");
    return ret;
}

/**
* @brief		发送升级启动报文
* @param		无
* @return		执行结果
* @retval		无
* @pre			无
*/
static int32_t send_block_data_crc_info(uint16_t block_cnt, uint16_t block_crc)
{
    int32_t ret = 0;
    uint8_t data[8] = {0};
    can_frame_id_u frame_tx_id = {0};
    frame_tx_id.bit.src_addr = BCU_INNER_CAN_ADDR; // TODO
    frame_tx_id.bit.src_type = DEV_BCU;
    frame_tx_id.bit.dst_addr = BROCAST_DEVICE_ADDRESS;   //广播升级
    frame_tx_id.bit.dst_type = DEV_BMU;
    frame_tx_id.bit.fun_code = FUNC_DOWN_FILE_DATA_BLOCK_START;
    frame_tx_id.bit.prio = SOFAR_CAN_PRI_HIGH_H;

    data[0] = 0; // 请求
    data[1] = 0; // 预留
    data[2] = (uint8_t)(block_cnt >> 0); // block_cnt
    data[3] = (uint8_t)(block_cnt >> 8);
    data[4] = (uint8_t)(g_upgrade_master_data_info.block_size >> 0); // block_szie
    data[5] = (uint8_t)(g_upgrade_master_data_info.block_size >> 8);
    data[6] = (uint8_t)(block_crc >> 0); // crc
    data[7] = (uint8_t)(block_crc >> 8);
    ret = can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_tx_id.id_val, data, 8);
//    log_d("[upd bmu]block:%d,crc:%x\n",block_cnt, block_crc);
    return ret;
}
/**
* @brief		数据传输报文
* @param		无
* @return		执行结果
* @retval		无
* @pre			无
*/
static int32_t send_data_block_info(uint8_t *p_data, uint16_t len)
{
    int32_t ret = 0;
    can_frame_id_u frame_tx_id = {0};

    frame_tx_id.bit.src_addr = BCU_INNER_CAN_ADDR; // TODO
    frame_tx_id.bit.src_type = DEV_BCU;
    frame_tx_id.bit.dst_addr = BROCAST_DEVICE_ADDRESS;   //广播升级
    frame_tx_id.bit.dst_type = DEV_BMU;
    frame_tx_id.bit.fun_code = FUNC_DOWN_FILE_DATA_TRAN;
    frame_tx_id.bit.prio = SOFAR_CAN_PRI_HIGH_H;
    

    ret = can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_tx_id.id_val, p_data, len);

    return ret;
}

/**
* @brief		文件完整性请求报文
* @param		无
* @return		执行结果
* @retval		无
* @pre			无
*/
static int32_t send_file_integrity_req_info(void)
{
    int32_t ret = 0;
    can_frame_id_u frame_tx_id = {0};
    uint8_t data[8] = {0};

    frame_tx_id.bit.src_addr = BCU_INNER_CAN_ADDR; // TODO
    frame_tx_id.bit.src_type = DEV_BCU;
    frame_tx_id.bit.dst_addr = BROCAST_DEVICE_ADDRESS;   //广播升级
    frame_tx_id.bit.dst_type = DEV_BMU;
    frame_tx_id.bit.fun_code = FUNC_DOWN_FILE_RESULT_CHECK;
    frame_tx_id.bit.prio = SOFAR_CAN_PRI_HIGH_H;

    data[0] = 0; // 请求
    data[1] = UPD_MASTER_BMU_CHIP_ROLE;
    data[2] = BMU_CHIP_MODEL_0;
    data[3] = BMU_CHIP_MODEL_1;
    ret = can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_tx_id.id_val, data, 8);
    log_d("[upd bmu]file integrity req \r\n");
    return ret;
}

/**
* @brief		升级完成查询请求报文
* @param		无
* @return		执行结果
* @retval		无
* @pre			无
*/
static int32_t send_upgrade_end_req_info(void)
{
    int32_t ret = 0;
    can_frame_id_u frame_tx_id = {0};
    uint8_t data[8] = {0};

    frame_tx_id.bit.src_addr = BCU_INNER_CAN_ADDR; // TODO
    frame_tx_id.bit.src_type = DEV_BCU;
    frame_tx_id.bit.dst_addr = BROCAST_DEVICE_ADDRESS;   //广播升级
    frame_tx_id.bit.dst_type = DEV_BMU;
    frame_tx_id.bit.fun_code = FUNC_DOWN_FILE_FINISH_QUERY;
    frame_tx_id.bit.prio = SOFAR_CAN_PRI_HIGH_H;

    data[0] = 0; // 请求
    data[1] = UPD_MASTER_BMU_CHIP_ROLE;
    data[2] = BMU_CHIP_MODEL_0;
    data[3] = BMU_CHIP_MODEL_1;
    data[4] = UPG_FUN_START;
    data[5] = FILE_TYPE_APP;    //当前只有app文件类型
    ret = can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_tx_id.id_val, data, 8);
    log_d("[upd bmu]upgrade end req \r\n");
    return ret;
}



/******************************************预充状态机相关处理函数*******************************************************/
static uint8_t sta_upgrade_master_wait_start_entry(void)
{
    uint8_t event = EVT_NULL;

    memset(&g_upgrade_master_data_info, 0, sizeof(g_upgrade_master_data_info));
    memset(&g_upg_master_proc_para, 0, sizeof(g_upg_master_proc_para));
    sdk_fs_close(gp_fs);    //不管是正常结束到这里还是异常结束到这里，都先关闭一次文件
    gp_fs = NULL;
    g_upgrade_master_fsm_para.stat_cnt_time = sdk_tick_get();
    log_d("[upd bmu]Waiting\n");

    return event;
}

static uint8_t sta_upgrade_master_wait_start_run(void)
{
    uint8_t event = EVT_NULL;

    //1分钟清除BMU升级
    if (true == sdk_is_tick_over(g_upgrade_master_fsm_para.stat_cnt_time, os_tick_from_millisecond(60000)))
    {
        if (g_upgrade_master_state != UPG_MASTER_IDLE)
        {
            log_e("[updBmu]ClrMsterSta!L%d\n",g_upgrade_master_state);
        }
        g_upgrade_master_state = UPG_MASTER_IDLE; 
        g_upgrade_master_fsm_para.stat_cnt_time = sdk_tick_get(); 
    }
	
    

    return event;
}

static uint8_t sta_upgrade_master_file_info_entry(void)
{
    uint8_t event = EVT_NULL;
    log_i("[upd bmu]Starting\n");
    g_upgrade_master_state = UPG_MASTER_ING;
    memset(&g_upgrade_master_data_info, 0, sizeof(g_upgrade_master_data_info));
    memset(&g_upg_master_proc_para, 0, sizeof(g_upg_master_proc_para));
    g_upg_master_proc_para.file_check_over_time_get_flag = true;
	gp_fs = sdk_fs_open(NEW_UPG_BMU_FILE, FS_READ);
	if (gp_fs != NULL)
	{
        int32_t file_size_tmp = 0;
        file_size_tmp = sdk_fs_get_size(gp_fs);
        if(file_size_tmp < 0)
        {
            #if UPGRADE_MASTER_DEBUG_ENABLE
            log_w("[upd bmu]file_size get err \r\n");
            #endif
            event = EVT_UPG_MASTER_TIMEOUT_OR_ERR;
        }
        else
        {
            int8_t ret = 0;
            ret = sdk_fs_lseek(gp_fs, 0);
            if (ret != 0)
            {
                log_w("[upd bmu]sdk_fs_lseek failed = %d\n", ret);
                event = EVT_UPG_MASTER_TIMEOUT_OR_ERR;
            }
            else
            {
                g_upgrade_master_data_info.file_size = file_size_tmp;
                g_upgrade_master_data_info.block_size = BLOCK_SEND_DATA_SIZE;
                g_upgrade_master_data_info.block_total_num = g_upgrade_master_data_info.file_size / BLOCK_SEND_DATA_SIZE;
                if(0 != g_upgrade_master_data_info.file_size % BLOCK_SEND_DATA_SIZE)
                {
                    g_upgrade_master_data_info.block_total_num += 1;
                }
                #if UPGRADE_MASTER_DEBUG_ENABLE
                log_d("[upd bmu]open bmu file success...\r\n");
                log_i("[upd bmu]file_size = %d , block_size = %d, block_total_num = %d \r\n",g_upgrade_master_data_info.file_size,g_upgrade_master_data_info.block_size,g_upgrade_master_data_info.block_total_num);
                #endif
            }

        }

	}
	else
	{
		event = EVT_UPG_MASTER_TIMEOUT_OR_ERR;
        #if UPGRADE_MASTER_DEBUG_ENABLE
		log_w("[upd bmu]open bmu file failed\r\n");
        #endif
	}
    g_upgrade_master_fsm_para.stat_cnt_time = sdk_tick_get();
    g_upgrade_master_fsm_para.stat_delay_cnt = 0;    

    return event;
}
static uint8_t sta_upgrade_master_file_info_run(void)
{
    uint8_t event = EVT_NULL;

    if ((valid_bmu_num() > 0)&&(valid_bmu_num() == g_upg_master_proc_para.first_reply_start_flag))
    {
        g_upg_master_proc_para.first_reply_start_flag = 0;
        log_e("[upd bmu]data transfer ready\r\n");
        event = EVT_UPG_MASTER_STA_CPL_SUS;
    }
	else if (true == sdk_is_tick_over(g_upgrade_master_fsm_para.stat_cnt_time, os_tick_from_millisecond(2500)))
	{
		send_upgrade_req_info();
        if (g_upgrade_master_fsm_para.stat_delay_cnt < 5)
        {
            g_upgrade_master_fsm_para.stat_delay_cnt++;
        }
        else if ((0 != g_upg_master_proc_para.first_reply_start_flag) || 
                (true == g_upg_master_proc_para.default_addr_reply_flag))
        {
            log_e("[upd bmu]data transfer part ready,bmu:%x,exist default addr bmu:%d,\n",g_upg_master_proc_para.first_reply_start_flag,g_upg_master_proc_para.default_addr_reply_flag);
            event = EVT_UPG_MASTER_STA_CPL_SUS;
        }
        else
        {
            log_e("[upd bmu]upd req response time out\r\n");
            event = EVT_UPG_MASTER_TIMEOUT_OR_ERR;
        }
        g_upgrade_master_fsm_para.stat_cnt_time = sdk_tick_get();
	}

    return event;
}
uint8_t g_tmp_buff[BLOCK_SEND_DATA_SIZE] = {0};
// 用于补包
static uint8_t supplementary_package_info_deal(void)
{
    uint8_t event = EVT_NULL;
    int16_t ret = 0;
    uint32_t tmp_bit_mask = 0;
    uint16_t crc = 0;

    while(g_upg_master_proc_para.transmit_index < BLOCK_PER_GROUP)
    {
        tmp_bit_mask = g_upg_master_proc_para.transmit_bit_mask;
        tmp_bit_mask = tmp_bit_mask >> g_upg_master_proc_para.transmit_index;
        if (0x01 != (tmp_bit_mask & 0x01))
        {
            g_upg_master_proc_para.transmit_index++;
            continue;
        }
        // 需要补包
        tmp_bit_mask = g_upg_master_proc_para.transmit_block_num * BLOCK_PER_GROUP + g_upg_master_proc_para.transmit_index;
        // 1.偏移数据位置
        ret = sdk_fs_lseek(gp_fs, tmp_bit_mask*BLOCK_SEND_DATA_SIZE);
        if (ret != 0)
        {
            log_w("[upd bmu]sdk_fs_lseek 2 failed = %d...\n", ret);
            event = EVT_UPG_MASTER_TIMEOUT_OR_ERR;
            break;
        }
        // 2.读此帧的数据，计算此帧的数据的crc
        memset(g_tmp_buff, 0xFF, sizeof(g_tmp_buff));
        ret = sdk_fs_read(gp_fs, g_tmp_buff, BLOCK_SEND_DATA_SIZE);
        if (ret != BLOCK_SEND_DATA_SIZE)
        {
            log_w("[upd bmu]sdk_fs_read 2 failed = %d...\n", ret);
            event = EVT_UPG_MASTER_TIMEOUT_OR_ERR;
            break;
        }
        // 3.计算此帧的数据的crc
        else
        {
            crc = crc16_ccitt(g_tmp_buff, BLOCK_SEND_DATA_SIZE);
            send_block_data_crc_info(tmp_bit_mask, crc);
            g_upg_master_proc_para.send_block_data_flag = true;
            event = EVT_UPG_MASTER_STA_CPL_SUS;
            log_w("[upd bmu]send tblock info\n");
        }
        // log_d("[upd bmu]transmit_index = %d...\n", g_upg_master_proc_para.transmit_index);
        g_upg_master_proc_para.transmit_index++;
        break;
    }
    if(g_upg_master_proc_para.transmit_index >= BLOCK_PER_GROUP)   //轮询完成，再去查询
    {
        event = EVT_UPG_MASTER_STA_CPL_SUS;
    }
    return event;
}

static uint8_t sta_upgrade_master_block_info_entry(void)
{
    uint8_t event = EVT_NULL;
    g_upgrade_master_fsm_para.stat_cnt_time = sdk_tick_get();
    return event;
}

static uint8_t sta_upgrade_master_block_info_run(void)
{
    uint8_t event = EVT_NULL;
    
    if(0 != g_upg_master_proc_para.transmit_bit_mask)    //需要补包
    {
        if (true == sdk_is_tick_over(g_upgrade_master_fsm_para.stat_cnt_time, os_tick_from_millisecond(150)))
        {
            event = supplementary_package_info_deal();
            g_upgrade_master_fsm_para.stat_cnt_time = sdk_tick_get(); 
        }
    }
    else if (true == sdk_is_tick_over(g_upgrade_master_fsm_para.stat_cnt_time, os_tick_from_millisecond(150)))
    {
        // 在打开文件的时候已经把文件偏移到头部了，这里只需要按长度就能顺序读取
        memset(g_tmp_buff, 0xFF, sizeof(g_tmp_buff));
        
        int16_t ret = sdk_fs_read(gp_fs, g_tmp_buff, BLOCK_SEND_DATA_SIZE);
        if (ret != BLOCK_SEND_DATA_SIZE)
        {
            event = EVT_UPG_MASTER_TIMEOUT_OR_ERR;
        }
        else
        {
            uint16_t crc = crc16_ccitt(g_tmp_buff, BLOCK_SEND_DATA_SIZE);
            send_block_data_crc_info(g_upgrade_master_data_info.block_send_cnt, crc);
            g_upg_master_proc_para.send_block_data_flag = true;
            if(g_upgrade_master_data_info.block_send_cnt < g_upgrade_master_data_info.block_total_num)
            {
                g_upgrade_master_data_info.block_send_cnt++;
            }
            event = EVT_UPG_MASTER_STA_CPL_SUS;
//            log_w("[upd bmu]send block info\n");
        }
        g_upgrade_master_fsm_para.stat_cnt_time = sdk_tick_get();    
    }
    return event;
}

static uint8_t sta_upgrade_master_block_data_entry(void)
{
    uint8_t event = EVT_NULL;
    g_upgrade_master_fsm_para.stat_cnt_time = sdk_tick_get();
    return event;
}

static uint8_t sta_upgrade_master_block_data_run(void)
{
    uint8_t event = EVT_NULL;

    if (true == sdk_is_tick_over(g_upgrade_master_fsm_para.stat_cnt_time, os_tick_from_millisecond(2000)))
    {
        // 连续5帧都回复，或者已经读到最后一帧
        g_upgrade_master_fsm_para.stat_delay_cnt++;
        if (g_upgrade_master_fsm_para.stat_delay_cnt > 4 || 
            g_upgrade_master_data_info.block_send_cnt >= g_upgrade_master_data_info.block_total_num)
        {
            event = EVT_UPG_MASTER_TIMEOUT_OR_ERR;
        }
        else
        {
            g_upg_master_proc_para.send_block_data_flag = false;
            g_upg_master_proc_para.block_reply_start_flag = 0;
            event = EVT_UPG_MASTER_BLOCK;
        }
        log_w("[upd bmu]blk%dDataOt,%lx,%d\n", g_upgrade_master_data_info.block_send_cnt, g_upg_master_proc_para.block_reply_start_flag, g_upgrade_master_fsm_para.stat_delay_cnt);
        g_upgrade_master_fsm_para.stat_cnt_time = sdk_tick_get();
    }
    
    if(0 != g_upg_master_proc_para.transmit_bit_mask)    //需要补包
    {
        if (g_upg_master_proc_para.send_block_data_flag == true && 
            (((valid_bmu_num() > 0) && (valid_bmu_num() == g_upg_master_proc_para.block_reply_start_flag)) || (true == g_upg_master_proc_para.default_addr_reply_flag))
            )
        {
            g_upg_master_proc_para.block_reply_start_flag = 0;
            log_e("[upd bmu]tblock%d transfer ok\r\n", g_upg_master_proc_para.transmit_block_num * BLOCK_PER_GROUP + g_upg_master_proc_para.transmit_index - 1);
            send_data_block_info(g_tmp_buff, BLOCK_SEND_DATA_SIZE);
            g_upg_master_proc_para.send_block_data_flag = false;
            if (g_upg_master_proc_para.transmit_index < BLOCK_PER_GROUP)
            {
                event = EVT_UPG_MASTER_BLOCK;
            }
            g_upgrade_master_fsm_para.stat_delay_cnt = 0;
            g_upgrade_master_fsm_para.stat_cnt_time = sdk_tick_get();
        }
        if(g_upg_master_proc_para.send_block_data_flag == false &&
           g_upg_master_proc_para.transmit_index >= BLOCK_PER_GROUP)   // 轮询完成，再去查询
        {
            event = EVT_UPG_MASTER_STA_CPL_SUS;
            log_i("[upd bmu]resendLostDataCompletedToCheck\n");
        }
    }
    else if(g_upg_master_proc_para.send_block_data_flag == false &&
            g_upgrade_master_data_info.block_send_cnt >= g_upgrade_master_data_info.block_total_num)//传输完成
    {
        event = EVT_UPG_MASTER_STA_CPL_SUS;
    }
    else
    {
        if (g_upg_master_proc_para.send_block_data_flag == true && 
            (((valid_bmu_num() > 0) && (valid_bmu_num() == g_upg_master_proc_para.block_reply_start_flag)) || (true == g_upg_master_proc_para.default_addr_reply_flag))
            )
        {
            send_data_block_info(g_tmp_buff, BLOCK_SEND_DATA_SIZE);
            g_upg_master_proc_para.send_block_data_flag = false;
            g_upg_master_proc_para.block_reply_start_flag = 0;
            log_e("[upd bmu]block%d transfer ok\r\n", g_upgrade_master_data_info.block_send_cnt - 1);
            // 返回下一帧
            if (g_upgrade_master_data_info.block_send_cnt < g_upgrade_master_data_info.block_total_num)
            {
                event = EVT_UPG_MASTER_BLOCK;
            }
            g_upgrade_master_fsm_para.stat_delay_cnt = 0;
            g_upgrade_master_fsm_para.stat_cnt_time = sdk_tick_get();
        }
    }
    return event;
}

static uint8_t sta_upgrade_master_file_check_entry(void)
{
    uint8_t event = EVT_NULL;
    g_upgrade_master_fsm_para.stat_cnt_time = sdk_tick_get();    
    g_upgrade_master_fsm_para.stat_delay_cnt = 0;
    g_upg_master_proc_para.transmit_block_num = 0;
    g_upg_master_proc_para.transmit_index = 0;
    g_upg_master_proc_para.transmit_bit_mask = 0;
    g_upg_master_proc_para.file_check_fail_flag = false;
    if(true == g_upg_master_proc_para.file_check_over_time_get_flag)    //每次升级只获取一次
    {
        g_upg_master_proc_para.file_check_over_time_get_flag = false;
        g_upg_master_proc_para.file_check_over_time_cnt = sdk_tick_get(); 
        g_upg_master_proc_para.file_integrity_flag = 0;
        g_upg_master_proc_para.default_addr_upd_time_cnt = sdk_tick_get(); //这里在file check需要在这里更新一次，后续是在报文里更新
    }

    return event;
}

static uint8_t sta_upgrade_master_file_check_run(void)
{
    uint8_t event = EVT_NULL;

    if (true == sdk_is_tick_over(g_upgrade_master_fsm_para.stat_cnt_time, os_tick_from_millisecond(1000)))
    {
        send_file_integrity_req_info();
        if (g_upgrade_master_fsm_para.stat_delay_cnt < 20)
        {
            g_upgrade_master_fsm_para.stat_delay_cnt++;
        }
        else
        {
            event = EVT_UPG_MASTER_TIMEOUT_OR_ERR;
        }   
        g_upgrade_master_fsm_para.stat_cnt_time = sdk_tick_get();     
    }
    else if(true == g_upg_master_proc_para.file_check_fail_flag)    //有丢包则进回补包动作
    {
        g_upg_master_proc_para.file_check_fail_flag = false;
        g_upgrade_master_fsm_para.stat_delay_cnt = 0;
        event = EVT_UPG_MASTER_OPERATE_FAIL;
    }

    
    if (true == sdk_is_tick_over(g_upg_master_proc_para.file_check_over_time_cnt, os_tick_from_millisecond(1000*60*2)))//补包时间超过2分钟判断为失败
    {
        log_e("[upd bmu]replenish block time out,bmu no:%x\r\n",g_upg_master_proc_para.file_integrity_flag);
        event = EVT_UPG_MASTER_TIMEOUT_OR_ERR;
        sdk_fs_close(gp_fs);
        gp_fs = NULL;
        if(0 != sdk_fs_remove(NEW_UPG_BMU_FILE))
        {
            log_e("[upd bmu]remove file err 2\n");
        } 
    }   
    /*如果是处于该状态，不确定有多少个包未编址，所以数据发送完成标志采用10S超时来判断*/
    else if(true == g_upg_master_proc_para.default_addr_reply_flag)
    {
        if(true == sdk_is_tick_over(g_upg_master_proc_para.default_addr_upd_time_cnt, os_tick_from_millisecond(1000*10)))
        {
            log_e("[upd bmu]boot data transfer complete\r\n");
            event = EVT_UPG_MASTER_STA_CPL_SUS;
        }
    }
    /* 正常升级是当有效电池包与回复一致则判断成功*/
    else if ((valid_bmu_num() > 0)&&(valid_bmu_num() == g_upg_master_proc_para.file_integrity_flag))
    {
        log_e("[upd bmu]data transfer complete\r\n");
        sdk_fs_close(gp_fs);
        gp_fs = NULL;
        if(0 != sdk_fs_remove(NEW_UPG_BMU_FILE))
        {
            log_e("[upd bmu]remove file err 1\n");
        }
        event = EVT_UPG_MASTER_STA_CPL_SUS;
    }

    return event;
}

static uint8_t sta_upgrade_master_finish_entry(void)
{
    uint8_t event = EVT_NULL;
    log_i("[upd bmu]finish_entry !! \r\n");
    g_upgrade_master_state = UPG_MASTER_WAIT_RESPOND;
    g_upgrade_master_fsm_para.stat_cnt_time = sdk_tick_get();    
    g_upgrade_master_fsm_para.stat_delay_cnt = 0;
    return event;
}
static uint8_t sta_upgrade_master_finish_run(void)
{
    uint8_t event = EVT_NULL;
    if ((valid_bmu_num() > 0)&&(valid_bmu_num() == g_upg_master_proc_para.upgrade_finish_flag))
    {
        log_i("[upd bmu]Upgrade all suc!! \r\n");
        g_upgrade_master_state = UPG_MASTER_ALL_FINISH;
        event = EVT_UPG_MASTER_STA_CPL_SUS;
    }
    else if (true == sdk_is_tick_over(g_upgrade_master_fsm_para.stat_cnt_time, os_tick_from_millisecond(3000)))
    {
        send_upgrade_end_req_info();
        if (g_upgrade_master_fsm_para.stat_delay_cnt < 25)  //相当于1分15秒
        {
            g_upgrade_master_fsm_para.stat_delay_cnt++;
        }
        else if(g_upg_master_proc_para.upgrade_finish_flag != 0)    //说明部分成功
        {
            log_i("[upd bmu]Upgrade part suc:%x \r\n",g_upg_master_proc_para.upgrade_finish_flag);
            g_upgrade_master_state = UPG_MASTER_PART_FINISH;
            event = EVT_UPG_MASTER_STA_CPL_SUS;
        }
        else
        {
            log_w("[upd bmu]Upgrade fail \r\n");
            event = EVT_UPG_MASTER_TIMEOUT_OR_ERR;
        } 
        g_upgrade_master_fsm_para.stat_cnt_time = sdk_tick_get();
    }


    return event;
}
static uint8_t sta_upgrade_master_error_entry(void)
{
    uint8_t event = EVT_NULL;
    g_upgrade_master_fsm_para.stat_cnt_time = sdk_tick_get();
    return event;
}
static uint8_t sta_upgrade_master_error_run(void)
{
    uint8_t event = EVT_NULL;

    log_w("[upd bmu]Error to stop upgrade...\r\n");
    sdk_fs_close(gp_fs);
    gp_fs = NULL;
    if(0 != sdk_fs_remove(NEW_UPG_BMU_FILE))
    {
        log_e("[upd bmu]remove file err 3\n");
    }
    g_upgrade_master_state = UPG_MASTER_ERR;
    event = EVT_UPG_MASTER_TIMEOUT_OR_ERR;

    return event;
}

static void upgrade_master_fsm_init(void)
{
    state_machine_init(&g_upgrade_master_fsm, g_upgrade_master_fsm_name, g_upgrade_master_act_map, (uint8_t *)g_upgrade_master_evt_sta_map,
        UPG_MASTER_EVT_NUM, UPG_MASTER_STA_NUM, UPG_MASTER_WAIT_START);
}

static uint8_t upgrade_master_state_chg_condition_check(void)
{
    uint8_t event = EVT_NULL;
    if (get_bmu_upgrade_flg() == true || g_try_restart_flag == true)
    {
        set_bmu_upgrade_flg(false);
        g_try_restart_flag = false;
        event = EVT_UPG_MASTER_START;
    }
    return event;   
}

/**
* @brief		外can升级相关函数注册
* @param		无
* @return		执行结果
* @retval		0： 注册成功
* @retval		-1：注册失败
* @pre			无
*/
static int32_t upgrade_master_internal_can_register(void)
{
    int32_t ret = 0;
    uint16_t rcv_msg_amount = 0;
    can_frame_id_u frame_id[] = 
    {
        // res     prio(优先级)      type(帧类型)  flag（1:连续，0:非）, fun_code,    dst_type dst_addr, src_type, src_addr
        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_HIGH_H, .bit.fun_code= FUNC_DOWN_FILE_START,
         .bit.dst_type= DEV_BCU, .bit.dst_addr= 0, .bit.src_type= DEV_BMU, .bit.src_addr =0}, // 0x7FB0000
        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_HIGH_H,  .bit.fun_code= FUNC_DOWN_FILE_RESULT_CHECK,
         .bit.dst_type= DEV_BCU, .bit.dst_addr= 0, .bit.src_type= DEV_BMU, .bit.src_addr =0}, // 0x7FE0000
        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_HIGH_H, .bit.fun_code= FUNC_DOWN_FILE_FINISH_QUERY,
         .bit.dst_type= DEV_BCU, .bit.dst_addr= 0, .bit.src_type= DEV_BMU, .bit.src_addr =0}, // 0x7FF0000
        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_HIGH_H, .bit.fun_code= FUNC_DOWN_FILE_TIME,
         .bit.dst_type= DEV_BCU, .bit.dst_addr= 0, .bit.src_type= DEV_BMU, .bit.src_addr =0}, // 0x7FA0000
        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_HIGH_H, .bit.fun_code= FUNC_DOWN_FILE_DATA_BLOCK_START,
         .bit.dst_type= DEV_BCU, .bit.dst_addr= 0, .bit.src_type= DEV_BMU, .bit.src_addr =0}, // 0x7FB0000
    };
    can_sofar_rcv_reg_t can_rxmsg_tab[] = // BCU接收上位机或PCS的数据
    {
        {.id = frame_id[0].id_val, .id_mask = 0x00001FFF, .p_can_cb = upgrade_master_file_info_int_master},   // 0x7FB0000
        {.id = frame_id[1].id_val, .id_mask = 0x00001FFF, .p_can_cb = upgrade_master_file_check_int_master},  // 0x7FE0000
        {.id = frame_id[2].id_val, .id_mask = 0x00001FFF, .p_can_cb = upgrade_master_file_end_int_master},    // 0x7FF0000
        {.id = frame_id[3].id_val, .id_mask = 0x00001FFF, .p_can_cb = upgrade_master_timing_time_int_master}, // 0x7FB0000
        {.id = frame_id[4].id_val, .id_mask = 0x00001FFF, .p_can_cb = upgrade_master_file_block_start}, // 0x7FB0000
    };

    // 注册接收的数据
    rcv_msg_amount = sizeof(can_rxmsg_tab)/sizeof(can_sofar_rcv_reg_t);
    ret = inner_can_sofar_register_receive_frame(can_rxmsg_tab, rcv_msg_amount);

    return ret;
}

static int32_t upgrade_master_file_info_int_master(can_frame_data_t *frame_data)
{
    if (frame_data == NULL)
    {
        return -1;
    }
    if (frame_data->data_len < 8)
    {
        return -2;
    }
    if (frame_data->data[0] != 1) // 应答帧
    {
        return -3;
    }
    can_frame_id_u frame_rx_id = {frame_data->id};
    g_upg_master_proc_para.rcv_block_size = ((uint16_t)frame_data->data[6] | (uint16_t)frame_data->data[7] << 8);
    if((1 == frame_data->data[1])
        && (BLOCK_SEND_DATA_SIZE == g_upg_master_proc_para.rcv_block_size))
    {
        if(BMU_ADDR_DEFAULT == frame_rx_id.bit.src_addr)
        {
            g_upg_master_proc_para.default_addr_reply_flag = true;
        }
        if(frame_rx_id.bit.src_addr > 0)
        {
            g_upg_master_proc_para.first_reply_start_flag |= (0x01 << (frame_rx_id.bit.src_addr - 1)); //按bit填充
        }

        log_d("[upd bmu]rcv bmu%d first reply ! \r\n", frame_rx_id.bit.src_addr);
        
    }
    return 0;
}

static int32_t upgrade_master_file_check_int_master(can_frame_data_t *frame_data)
{
    if (frame_data == NULL)
    {
        return -1;
    }
    if (frame_data->data_len < 8)
    {
        return -2;
    }
    if (frame_data->data[0] != 1) // 应答帧
    {
        return -3;
    }
    can_frame_id_u frame_rx_id = {frame_data->id};
    if((0 == frame_data->data[1])&&(0 == frame_data->data[4])&&(0 == frame_data->data[5])&&(0 == frame_data->data[6])&&
        (0 == frame_data->data[7])&&(BMU_CHIP_MODEL_0 == frame_data->data[2])&&(BMU_CHIP_MODEL_1 == frame_data->data[3]))
    {
        if((frame_rx_id.bit.src_addr) > 0 && (frame_rx_id.bit.src_addr != BMU_ADDR_DEFAULT))
        {
            g_upg_master_proc_para.file_integrity_flag |= (0x01 << (frame_rx_id.bit.src_addr - 1)); //按bit填充
        }
        log_d("[upd bmu]bmu%d rcv file complete ! file_integrity_flag : %x \r\n",frame_rx_id.bit.src_addr,g_upg_master_proc_para.file_integrity_flag);
    }
    else
    {   
        g_upg_master_proc_para.file_check_fail_flag = true;
        g_upg_master_proc_para.transmit_block_num = frame_data->data[4];
        g_upg_master_proc_para.transmit_bit_mask = ((uint32_t)frame_data->data[5] | (uint32_t)frame_data->data[6] << 8 | (uint32_t)frame_data->data[7] << 16);
        g_upg_master_proc_para.default_addr_upd_time_cnt = sdk_tick_get();  //存在电池包未编址升级需要
        // log_d("[upd bmu]bmu rcv file miss , transmit_block_num : %d , transmit_bit_mask : %x ! \r\n",g_upg_master_proc_para.transmit_block_num,g_upg_master_proc_para.transmit_bit_mask);
    }
    return 0;
}

static int32_t upgrade_master_file_end_int_master(can_frame_data_t *frame_data)
{
    if (frame_data == NULL)
    {
        return -1;
    }
    if (frame_data->data_len < 3)
    {
        return -2;
    }
    if (frame_data->data[0] != 1) // 应答帧
    {
        return -3;
    }
    can_frame_id_u frame_rx_id = {frame_data->id};
    if(0 == frame_data->data[1])
    {
        if((frame_rx_id.bit.src_addr) > 0 && (frame_rx_id.bit.src_addr != BMU_ADDR_DEFAULT))
        {
            g_upg_master_proc_para.upgrade_finish_flag |= (0x01 << (frame_rx_id.bit.src_addr - 1)); //按bit填充
        }

        log_d("[upd bmu]rcv bmu%d file end suc! upgrade_finish_flag : %x \r\n",frame_rx_id.bit.src_addr,g_upg_master_proc_para.upgrade_finish_flag);
    }
    // log_d("[upd bmu]rcv bmu file end msg : %d  ! \r\n",p_data[0]);
    return 0;
}

static int32_t upgrade_master_timing_time_int_master(can_frame_data_t *frame_data)
{
    if (frame_data == NULL)
    {
        return -1;
    }
    if (frame_data->data_len < 2)
    {
        return -2;
    }
    if (frame_data->data[0] != 1) // 应答帧
    {
        return -3;
    }
    return 0;
}

static int32_t upgrade_master_file_block_start(can_frame_data_t *frame_data)
{
    if (frame_data == NULL)
    {
        return -1;
    }
    if (frame_data->data_len < 2)
    {
        return -2;
    }
    if (frame_data->data[0] != 1) // 应答帧
    {
        return -3;
    }
    can_frame_id_u frame_rx_id = {frame_data->id};
    if(1 == frame_data->data[1])
    {
        if((frame_rx_id.bit.src_addr > 0) && (frame_rx_id.bit.src_addr != BMU_ADDR_DEFAULT))
        {
            g_upg_master_proc_para.block_reply_start_flag |= (0x01 << (frame_rx_id.bit.src_addr - 1)); //按bit填充
        }

//        log_d("[upd bmu]rcv bmu%d first reply ! \r\n", frame_rx_id.bit.src_addr);
    }
    return 0;
}

/**
* @brief		返回bmu数目，按bit填充
* @param		无
* @return		valid_value ： 按bit填充bmu数目
* @retval		无
* @pre			无
*/
static uint16_t valid_bmu_num(void)
{
    uint16_t valid_value = 0;
    uint8_t i = 0;

    while ((auto_addressing_pack_num_get() > 0) && (i < auto_addressing_pack_num_get()))
    {
        valid_value |= (0x01 << i);
        i++;
    }
    
    return valid_value;
}

/**
* @brief		升级流程
* @param		无
* @return		无
* @retval		无
* @pre			无
*/
static void upgrade_master_process(void)
{
    uint8_t event;
    event = upgrade_master_state_chg_condition_check();
    fsm_state_trans(&g_upgrade_master_fsm, event);
    event = state_machine_proc(&g_upgrade_master_fsm);
    fsm_state_trans(&g_upgrade_master_fsm, event);
}


/**
* @brief		升级模块参数初始化
* @param		无
* @return		无
* @retval		无
* @pre			无
*/
void upgrade_master_init(void)
{
    memset(&g_upgrade_master_data_info, 0, sizeof(g_upgrade_master_data_info));
    memset(&g_upg_master_proc_para, 0, sizeof(g_upg_master_proc_para));
    g_upgrade_master_state = UPG_MASTER_IDLE;
    upgrade_master_fsm_init();
	upgrade_master_internal_can_register();
    set_bmu_upgrade_flg(false);
    g_try_restart_flag = false;
    // upgrade_master_enable_state_set(true);
}

/**
* @brief		bcu升级bmu任务
* @param		无
* @return		无
* @retval		无
* @pre			无
*/
void upgrade_master_task_proc(void)
{
    static uint8_t last_upg_state = 0xFF;
    uint8_t now_upg_state = upgrade_state_get();
    // 外can升级需要打断bmu升级
    if (now_upg_state == UPG_ING && last_upg_state != UPG_ING)
    {
        // g_try_restart_flag = true;  // 如果开启此功能，，同时如果再次升级Bmu需要清除
        memset(&g_upgrade_master_data_info, 0, sizeof(g_upgrade_master_data_info));
        memset(&g_upg_master_proc_para, 0, sizeof(g_upg_master_proc_para));
        g_upgrade_master_state = UPG_MASTER_IDLE;
        upgrade_master_fsm_init();
        sdk_fs_close(gp_fs);    //不管是正常结束到这里还是异常结束到这里，都先关闭一次文件
        gp_fs = NULL;
        log_e("[upgbmu]UpgStop\n");
    }
        
    if (UPG_ING != now_upg_state)    // 如果upd出在升级中，不跑主升从，否则会有影响
    {
        upgrade_master_process();            // 升级流程
    }
    last_upg_state = now_upg_state;
}

/**
* @brief        清除主从升级bmu的尝试再升级标志
* @param        无
* @return        执行结果
* @pre            无
*/
void bmu_upgrade_try_restart_flag_clr(void)
{
    g_try_restart_flag = false;
}

/**
* @brief		获取bcu升级bmu状态
* @param		无
* @return		执行结果
* @retval		升级状态
* @pre			无
*/
uint8_t upgrade_master_state_get(void)
{
	return g_upgrade_master_state;
}

// uint8_t upgrade_master_reply_get(void)
// {
//     if((UPG_MASTER_ING == g_upgrade_master_state)
//         || (UPG_MASTER_FINISH == g_upgrade_master_state))
//     {
//         return true;
//     }
//     else
//     {
//         return false;
//     }
    
// }

/**
* @brief		获取bcu升级bmu进度
* @param		无
* @return		执行结果
* @retval		升级进度
* @pre			无
*/
uint32_t upgrade_master_progress_get(void)
{
    uint32_t percent = 100;
    
    //为0只有是还没跑到BMU升级流程，这里做一个防除0保护
    if(0 == g_upgrade_master_data_info.block_total_num)
    {
        percent = 0;
    }
    else
    {
        percent = percent * g_upgrade_master_data_info.block_send_cnt / g_upgrade_master_data_info.block_total_num;
    }
	return percent;
}

/**
* @brief		获取bmu升级完成状态
* @param		无
* @return		执行结果
* @retval		升级状态，每一个bit代表一个bmu
* @pre			无
*/
uint16_t upgrade_master_bmu_stus_get(void)
{
    return g_upg_master_proc_para.upgrade_finish_flag;
}

/**
 * @brief        调试接口
 * @param        [in] cmd
 * @param        [in] len
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
int32_t upg_master(int argc, char *argv[])
{  
    if (argc < 2)
    {
        log_d("upgMasterParaErr\n");
        return SF_ERR_PARA;
    }
    if (NULL != argv[1])
    {
        if(!strcmp(argv[1], "true"))
        {
            set_bmu_upgrade_flg(true);
        }
    }

    return 0;
}
// MSH_CMD_EXPORT(upg_master, <true>);



