#include "sofar_can_manage_public.h"
#include "sofar_cluster_can_manage.h"
#include <stdio.h>
#include <string.h>
#include "sdk.h"

//sdk接口函数的can端口号
static int32_t cluster_can_sofar_prase_short_frame(can_frame_data_t  *p_can_frame );

static rcv_register_info_t g_cluster_rcv_reg_info = {0};

/**
* @brief		初始化can管理
* @param		无
* @return		返回结果
* @retval		0：成功    < 0: 失败
* @warning		无 
*/
int32_t cluster_can_sofar_manage_init(void)
{
    //初始化CAN
    sdk_can_cfg_t can_cfg = 
    {
        .baud = SDK_CAN_BAUD_250K,
        .mode = SDK_CAN_MODE_NORMAL,
    };
    
    sdk_can_init();
    sdk_can_open(SDK_CLUSTER_CAN_PORT);
    sdk_can_setup(SDK_CLUSTER_CAN_PORT, &can_cfg);
    return 0;
}

/**
* @brief		读取簇间can硬件缓冲区数据，1ms周期轮询
* @param		无
* @return		返回结果
* @retval		0：添加成功    < 0: 添加失败
* @warning		无 
*/
int32_t cluster_can_sofar_rcv_frame_proc(void)
{
    sdk_can_frame_t can_msg_data = {0};
    can_frame_data_t can_short = {0};
    int32_t len = 0;

    /************************************内CAN*************************************************/
    // hdr 值为 - 1，表示直接从 uselist 链表读取数据 
    
    for(uint8_t i = 0; i < CAN_SOFAR_RCV_DATA_MAX_NUM_ONE_TIME; i++)
    {
        can_msg_data.hdr = -1;  // hdr 值为 - 1，表示直接从 uselist 链表读取数据 
        len = sdk_can_read(SDK_CLUSTER_CAN_PORT,  &can_msg_data, 1, 0 );        
        if(len > 0)
        {
            can_short.id = can_msg_data.id;
            can_short.ide = can_msg_data.ide;

            can_short.data_len = can_msg_data.len;
            memcpy(can_short.data, &(can_msg_data.data[0]), 8);            
            cluster_can_sofar_prase_short_frame(&can_short);

        }
        else
        {    
            break;
        }
        
    }
    return 0;
}

/**
* @brief		处理已注册进来的CAN帧，跳转到各自注册的回调函数中
* @param		[in] CAN端口	外部CAN：EXTERNAL_CAN  /  内部CAN：INTERNAL_CAN  
* @param		[in] 数据帧内容
* @return		返回结果
* @retval		0：成功    < 0: 失败
* @warning		无
*/
static int32_t cluster_can_sofar_prase_short_frame(can_frame_data_t  *p_can_frame )
{
    int32_t ret = 0;
    uint16_t i = 0;
    
    if(NULL == p_can_frame)
    {
        return -1;
    }

    for(i = 0; i < g_cluster_rcv_reg_info.reg_cnt && i < MAX_GENERAL_REC_NUM; i++)
    {
        //1、判断是已注册的id
        //2、判断接收的id是否为广播地址或本机pack地址
        if(0 == can_compare_id(p_can_frame->id , g_cluster_rcv_reg_info.reg_buff[i].id, g_cluster_rcv_reg_info.reg_buff[i].id_mask))
        {
            if(NULL != g_cluster_rcv_reg_info.reg_buff[i].p_can_cb)
            {
                g_cluster_rcv_reg_info.reg_buff[i].p_can_cb(p_can_frame);
                break;
            }
        }
    }
    return ret;
}



/**
* @brief		注册can接收回调函数
* @param		[in] port：	外部CAN：EXTERNAL_CAN  /  内部CAN：INTERNAL_CAN  
* @param		[in] urgent_flag:紧急处理标志  GENERAL_FRAME:接收到数据正常响应速度10ms ，URGENT_FRAME:接收数据快速响应1ms
* @param		[in] p_can_rec_reg ：
* @param		[in] id：can帧id 
* @param		[in] id：id_mask：过滤不需要接收的位(标准帧的掩码mask固定为0x00000000,拓展帧的掩码mask目标地址设置为FF代表能接收0xFF,0x1F,pack_addr三种类型地址)
* @param		[in] id：can_cb：回调解析函数 
* @param		[in] reg_cnt：注册的数量 
* @return		返回结果
* @retval		0：注册成功    < 0: 注册失败
* @warning		禁止重复注册同一个ID
* @warning		标准帧注册掩码必须为0x00000000
* @warning		掩码不可为0xFFFFFFFF
*/
int32_t cluster_can_sofar_register_receive_frame(can_sofar_rcv_reg_t *p_can_rec_reg, uint16_t reg_cnt)
{
    int32_t ret = 0;
    uint16_t i = 0;

    if ((NULL == p_can_rec_reg) ||
        (0 == p_can_rec_reg->id) ||
        (0xFFFFFFFF == p_can_rec_reg->id_mask) ||
        (NULL == p_can_rec_reg->p_can_cb))
    {
        return -1; // 输入参数有误，返回失败
    }
    for (i = 0; i < reg_cnt; i++)
    {
        if (g_cluster_rcv_reg_info.reg_cnt < MAX_GENERAL_REC_NUM) // 判断已经注册数量是否大于最大允许注册的数量
        {
            memcpy(g_cluster_rcv_reg_info.reg_buff + g_cluster_rcv_reg_info.reg_cnt, p_can_rec_reg + i, sizeof(can_sofar_rcv_reg_t));
        }
        else
        {
            ret = -2;
            break; // 注册数量大于总数，则返回失败
        }
    
        g_cluster_rcv_reg_info.reg_cnt++; // 已经注册的数量计数
    }
    return ret;
}
