/**
 * @file     insulation_impedance_calc.c
 * @brief    绝缘阻抗检测实现
 * @author   liulvcong
 * @note     无
 * @version  V1.0
 * @date     2023/5/4
 */
 
#include "insulation_impedance_calc.h"
#include <stdio.h>
#include <string.h>
#include "sdk.h"
#include "sdk_core.h"
#include "sdk_dido.h"
#include "sample.h"
#include "ate.h"
#include "app_public.h"
#include "bms_state.h"
#include "relay_manage.h"

#define SIR_DISABLE_MIN_BUS_VOLT (10000)
#define SIR_DELAY_SEC_B100MS (30)      // 延迟3s, 实际电压稳定是在2S左右，故等其稳定后再做检测
#define SIR_FILITER_B100MS   (5)        // 滤波5次
#define SIR_MIN_BUS_VOLT_SUB (-20000)   // -20000mV， TODO:找硬件确认范围
#define SIR_MAX_BUS_VOLT_SUB (20000)    // 20000mV，TODO:找硬件确认范围
#define SIR_CALC_FILITER_TIME (3)       // 滤波次数
#define SIR_OVER_TIME_B100MS  (360)    // 超时时间36s 根据一次正常测试时间*3
#define SIR_SUCCESS_INVALID_TIME_B100MS  (3000)    // 绝缘阻抗检测成功超时时间100ms    这里的超时是用来做当上一次绝缘检测完后，如果需要启动下一次绝缘检测，在超时时间内不启动；
#define SIR_ABNORMAL_K_VAL    (100)      // 异常绝缘阻抗阈值(100k)
#define SIR_SW1_PIN   (DO_1_ISO_DET_RELAY2)              // 绝缘阻抗检测继电器2控制
#define SIR_SW2_PIN   (DO_15_ISO_DET_RELAY1)              // 绝缘阻抗检测继电器1控制
#define SIR_PE_PIN    (DO_14_ISO_PE_RELAY)                // 绝缘阻抗检测继电器PE控制
#define SIR_RES1_K_OMIGA ((int64_t)5988)
#define SIR_RES2_K_OMIGA ((int64_t)5988)
#define SIR_RES3_K_OMIGA ((int64_t)6487)
#define SIR_RES4_K_OMIGA ((int64_t)6487)
#define SIR_LIMIT_MAX(input, max)   ((input) = ((input) > (max) ? (max) : (input)))
// 阻抗=a*(V1-V2)/(b*V1+c*V2+d*Vbus), 
// V1:闭合SW1，断开SW2，采集的电压INS电压，V2:闭合SW2，断开SW1，采集的电压INS电压；Vbus电压为母线电压
// a = R1*R2*(R1+R4)*(R2+R3)
// b = -(R1*R2*R2 + R1*R2*R3 + R2*R2*R4 + R2*R3*R4 + R1*R1*R2 + R1*R2*R4)
// c = (R1*R2*R2 + R1*R2*R3 + R1*R1*R2 + R1*R1*R3 + R1*R2*R4 + R1*R3*R4)
// d = R2*R2*R4 + R2*R3*R4
// 由于R1==R2, R3==R4优化逻辑为：
// 阻抗= (R1+R3)*(R1+R3) / ((R3+ R3*R3/R1)*Vbus/(V1-V2) - (2*R1 + 3*R3 + R3*R3/R1))
// 阻抗= R1*(R1+R3)*(R1+R3)*(V1-V2) / ((R1*R3+ R3*R3)*Vbus - (2*R1*R1 + 3*R3*R1 + R3*R3)(V1-V2))
#define SIR_SQUARE(x)   ((x) * (x))
#define SIR_DIVIDEND_A   (SIR_RES1_K_OMIGA * (SIR_RES1_K_OMIGA + SIR_RES3_K_OMIGA))
#define SIR_DIVISIOR_B   ((SIR_RES3_K_OMIGA))
#define SIR_DIVISIOR_C   (-(2 * SIR_RES1_K_OMIGA +  SIR_RES3_K_OMIGA))
#define SIR_DIVISIOR(vbus, v1_sub_v2)  ((SIR_DIVISIOR_B * (vbus) + SIR_DIVISIOR_C * (v1_sub_v2)))

typedef enum
{
    RES_COMM_INVALID = 0,
    RES_COMM_ENABLE,
    RES_COMM_DISABLE,
} insulation_command_e;

typedef enum
{
    SIR_CALC_IDLE = 0,
    SIR_CALC_START,         // 启动绝缘阻抗计算，需要外部调用/初始化，当前定义接口启动
    SIR_CALC_COLSE_SW1,     // 对应控制接口闭合INS_RLY2，放开INS_RLY1
    SIR_CALC_DELAY1,        // 10s延迟，记录SW1电压
    SIR_CALC_COLSE_SW2,     // 对应控制接口闭合INS_RLY1，放开INS_RLY2
    SIR_CALC_DELAY2,        // 10s延迟，记录SW2电压
    SIR_CALC_RESULT,        // 计算出绝缘阻抗，如果分母异常则重新计算,并且放开INS_RLY1，INS_RLY2
    SIR_CALC_END,           // 计算出绝缘阻抗
} insulation_impedance_state_e;

typedef struct
{
    uint32_t impedance_value;                 // 计算的阻抗值，单位kΩ：,SIR_INVALID 为无效值
    uint32_t bus_volt_close_sw1;              // 闭合SW1，放开SW2时的母排电压，单位：mv,SIR_INVALID 为无效值
    uint32_t sir_volt_close_sw1;              // 闭合SW1，放开SW2时的阻抗电压，单位：mv,SIR_INVALID 为无效值
    uint32_t bus_volt_close_sw2;              // 闭合SW2，放开SW1时的母排电压，单位：mv,SIR_INVALID 为无效值
    uint32_t sir_volt_close_sw2;              // 闭合SW2，放开SW1时的阻抗电压，单位：mv,SIR_INVALID 为无效值
    uint16_t delay_s_times;                   // 延迟秒数，单位：/0.1s
    uint16_t err_times;                       // 错误次数
    uint16_t success_times;                   // 成功次数
    uint16_t over_timer;                      // 超时定时器，单位：/0.1s
    uint16_t success_keep_timer;              // 绝缘阻抗测试成功后保持时间，单位：/0.1s
    insulation_impedance_state_e state;       // 阻抗检测状态 参考insulation_impedance_state_e
    insulation_impedance_check_result_e result; // 对外的检测结果
    uint8_t ins_func_enable_flag;               // 1:开启绝缘检测，2：关闭绝缘检测
} insulation_impedance_para_t;

typedef struct
{
    bool debug_flag;                          // 调试标志，false：关闭， true：启动
    uint32_t bus_volt;                        // 设置bus_volt
    uint32_t sir_volt;                        // 设置sir_volt
} insulation_impedance_input_para_t;

static insulation_impedance_input_para_t g_insulation_impedance_input_para = {0};
static insulation_impedance_para_t g_insulation_impedance_para = {0};

/** 
 * @brief        打印信息
 * @param        [in] void
 * @return       void 
 */
void insulation_impedance_calc_print(void)
{
    log_d("insVal=%ld\n", g_insulation_impedance_para.impedance_value);
    log_d("busVSw1=%ld\n", g_insulation_impedance_para.bus_volt_close_sw1);
    log_d("sirVSw1=%ld\n", g_insulation_impedance_para.sir_volt_close_sw1);
    log_d("busVSw2=%ld\n", g_insulation_impedance_para.bus_volt_close_sw2);
    log_d("sirVSw2=%ld\n", g_insulation_impedance_para.sir_volt_close_sw2);
    log_d("sta=%d\n", g_insulation_impedance_para.state);
    log_d("delaySCnt=%d\n", g_insulation_impedance_para.delay_s_times);
    log_d("errCnt=%d\n", g_insulation_impedance_para.err_times);
    log_d("succTime=%d\n", g_insulation_impedance_para.success_times);
    log_d("succKeepTimer=%d\n", g_insulation_impedance_para.success_keep_timer);
    log_d("overTimer=%d\n", g_insulation_impedance_para.over_timer);
    log_d("result=%d\n", g_insulation_impedance_para.result);

    log_d("debugFlag=%ld\n", g_insulation_impedance_input_para.debug_flag);
    log_d("busV=%ld\n", g_insulation_impedance_input_para.bus_volt);
    log_d("sirV=%ld\n", g_insulation_impedance_input_para.sir_volt);
}

/** 
 * @brief        打印信息设置函数
 * @param        [in] flag 打印信息设置函数，0不打印，1打印
 * @return       [int32_t] 执行结果
 * @retval       =0  设置成功 
 * @retval       < 0 失败原因
 */
int32_t insulation_impedance_calc_debug_set(int8_t flag)
{
    g_insulation_impedance_input_para.debug_flag = flag;

    return SIR_OK;
}

/** 
 * @brief        设置绝缘阻抗检测功能
 * @param        [in]insulation_func_enable_state_e  1：启动，2：关闭
 * @return       [int32_t] 执行结果
 * @retval       =0  设置成功 
 * @retval       < 0 失败原因
 */
int32_t insulation_impedance_func_enable_set(uint8_t flag)
{
    if (flag > FUNC_DISABLE)
    {
       return SIR_INVALID;
    }
    g_insulation_impedance_para.ins_func_enable_flag = flag;

    return SIR_OK;
}

/** 
 * @brief        获取绝缘阻抗检测功能标志
 * @return       [uint8_t] 执行结果
 */
uint8_t insulation_impedance_func_enable_get(void)
{
    return g_insulation_impedance_para.ins_func_enable_flag;
}

/**
 * @brief    获取输入数据
 * @param    [in] void
 * @return   执行结果(void)
 * @pre      不可重入函数
 */
void insulation_impedance_calc_input_para_get(void)
{
    if (!g_insulation_impedance_input_para.debug_flag)
    {
        const sample_data_t* p_sam_data = p_sample_data_get();
        if (p_sam_data != NULL)
        {
            g_insulation_impedance_input_para.bus_volt = p_sam_data->bus_volt;
            g_insulation_impedance_input_para.sir_volt = p_sam_data->insulation_res_volt;
        }
    }
}

/**
 * @brief    设置绝缘阻抗检测状态
 * @param    [in] state 设置状态，参数参考hal_ext_ads_collect_stage_e
 * @return   执行结果(void)
 * @pre      不可重入函数
 */
void insulation_impedance_calc_state_set(insulation_impedance_state_e state)
{
    if (state > SIR_CALC_END)
    {
        return;
    }
    g_insulation_impedance_para.state = state;
}

/**
 * @brief       绝缘阻抗检测初始化
 * @param       无
 * @return      返回结果
 * @warning     GPIO一定要初始化 
 */
void insulation_impedance_calc_init(void)
{
    g_insulation_impedance_input_para.debug_flag = false;
    g_insulation_impedance_input_para.bus_volt = SIR_INVALID;
    g_insulation_impedance_input_para.sir_volt = SIR_INVALID;
 
    g_insulation_impedance_para.impedance_value = SIR_INVALID;
    g_insulation_impedance_para.bus_volt_close_sw1 = SIR_INVALID;
    g_insulation_impedance_para.sir_volt_close_sw1 = SIR_INVALID;
    g_insulation_impedance_para.bus_volt_close_sw2 = SIR_INVALID;
    g_insulation_impedance_para.sir_volt_close_sw2 = SIR_INVALID;
    g_insulation_impedance_para.state = SIR_CALC_IDLE;
    g_insulation_impedance_para.delay_s_times = 0;
    g_insulation_impedance_para.err_times = 0;
    g_insulation_impedance_para.success_keep_timer = 0;
    g_insulation_impedance_para.success_times = 0;
    g_insulation_impedance_para.over_timer = 0;
    g_insulation_impedance_para.result = INSULATION_IMPEDANCE_IDLE;
	
	(void)sdk_dido_write(SIR_SW2_PIN, false);
	(void)sdk_dido_write(SIR_SW1_PIN, false);
    (void)sdk_dido_write(SIR_PE_PIN, false);// 断开PE
}

/**
 * @brief   绝缘阻抗检测结果
 * @param   [in] void
 * @note    调用此函数之前需要已经完成初始化
 * @return  返回执行结果 0:正常；<0:异常
 */
int32_t insulation_impedance_check_result_get(void)
{
    return g_insulation_impedance_para.result;
}

/**
 * @brief   启动绝缘阻抗检测
 * @param   [in] void
 * @note    调用此函数之前需要已经完成初始化
 * @return  返回执行结果 0:正常；<0:异常
 */
int32_t insulation_impedance_calc_start(void)
{
    if (g_insulation_impedance_input_para.debug_flag)
    {
        return SIR_OK;
    }
    const sample_data_t* p_sam_data = p_sample_data_get();
    if (p_sam_data != NULL)
    {
        if (p_sam_data->bus_volt < SIR_DISABLE_MIN_BUS_VOLT)
        {
            return SIR_OK;
        }
    }
//    if (get_relay_contrl_state(POS_RELAY))   //主正接触器吸合时，说明系统与pcs连接了，即便发来了绝缘检测start也不执行
//    {
//        return SIR_OK;
//    }
    
    if (INSULATION_IMPEDANCE_CHECKING != g_insulation_impedance_para.result)
    {
        g_insulation_impedance_para.state = SIR_CALC_START;
        // g_insulation_impedance_para.impedance_value = SIR_INVALID;   //重新启动绝缘检测时，绝缘阻抗值应该保持上一时刻的值
        g_insulation_impedance_para.delay_s_times = 0;
        g_insulation_impedance_para.err_times = 0;
        g_insulation_impedance_para.success_times = 0;
        g_insulation_impedance_para.over_timer = 0;
        g_insulation_impedance_para.success_keep_timer = 0;
        g_insulation_impedance_para.result = INSULATION_IMPEDANCE_CHECKING;
    }
    return SIR_OK;
}

/**
 * @brief   绝缘阻抗计算处理
 * @param   [in] void
 * @param   [out] void
 */
void insulation_impedance_calc_deal(void)
{
    int64_t v1_sub_v2 = 0;  //差值
    int32_t bus_volt_sub = g_insulation_impedance_para.bus_volt_close_sw1 - g_insulation_impedance_para.bus_volt_close_sw2;
    // 考虑母线电压波动导致绝缘阻抗算不准，当前暂定±20V
    if (bus_volt_sub < SIR_MIN_BUS_VOLT_SUB || bus_volt_sub > SIR_MAX_BUS_VOLT_SUB )
    {
        g_insulation_impedance_para.impedance_value = SIR_INVALID;
        return;
    }
    
    if (g_insulation_impedance_para.sir_volt_close_sw1 > g_insulation_impedance_para.sir_volt_close_sw2)
    {
        v1_sub_v2 = g_insulation_impedance_para.sir_volt_close_sw1 - (int64_t)g_insulation_impedance_para.sir_volt_close_sw2;   //否则当差值为0去算
    }

    int64_t bus_volt = (g_insulation_impedance_para.bus_volt_close_sw1 + g_insulation_impedance_para.bus_volt_close_sw2) / 2;

    int64_t tmp = SIR_DIVISIOR(bus_volt, v1_sub_v2);
    if (tmp != 0)
    {
        g_insulation_impedance_para.impedance_value = (uint32_t)(SIR_DIVIDEND_A * v1_sub_v2 / tmp);
    }
    else
    {
        g_insulation_impedance_para.impedance_value = SIR_INVALID;
    }
    log_d("[SIR]bus_volt:%d, v1_sub_v2:%d, tmp:%d, impedance_value:%d\n",(int32_t)bus_volt, (int32_t)v1_sub_v2, (int32_t)tmp, g_insulation_impedance_para.impedance_value);
}

/** 
 * @brief        绝缘阻抗检测记录结果
 * @retval       无
 */
void insulation_impedance_record_data(void)
{
    if (SIR_INVALID != g_insulation_impedance_para.impedance_value)
    {
//        if (g_insulation_impedance_para.impedance_value <= SIR_ABNORMAL_K_VAL)
//        {
//            g_insulation_impedance_para.err_times++;
//            g_insulation_impedance_para.success_times = 0;
//        }
//        else
        {
            g_insulation_impedance_para.success_times++;
            g_insulation_impedance_para.err_times = 0;
        }
    }
    else
    {
        g_insulation_impedance_para.err_times++;
        g_insulation_impedance_para.success_times = 0;
    }
}

/** 
 * @brief        绝缘阻抗检测结果更新
 * @param        [out] 绝缘阻抗结果
 * @return       [int32_t] 执行结果
 * @retval       >=  0 实际计算结果
 * @retval       < 0 无效值
 */
void insulation_impedance_check_result_update(void)
{
    g_insulation_impedance_para.over_timer++;
    if (g_insulation_impedance_para.success_times >= SIR_CALC_FILITER_TIME) // 连续3次判断ok
    {
        g_insulation_impedance_para.success_keep_timer++;
        // 成功标志超时判断
//        if (g_insulation_impedance_para.success_keep_timer >= SIR_SUCCESS_INVALID_TIME_B100MS)
//        {
//            g_insulation_impedance_para.result = INSULATION_IMPEDANCE_NORMAL_OVERTIME;
//        }
//        else
        {
            g_insulation_impedance_para.result = INSULATION_IMPEDANCE_NORMAL;
        }
        SIR_LIMIT_MAX(g_insulation_impedance_para.success_times, SIR_CALC_FILITER_TIME); // 防止越界
        SIR_LIMIT_MAX(g_insulation_impedance_para.success_keep_timer, SIR_SUCCESS_INVALID_TIME_B100MS);   // 防止越界
    }
    else if (g_insulation_impedance_para.err_times >= SIR_CALC_FILITER_TIME)       // 连续3次判断失败
    {
        g_insulation_impedance_para.success_keep_timer = 0;
        g_insulation_impedance_para.result = INSULATION_IMPEDANCE_ABNORMAL;
        SIR_LIMIT_MAX(g_insulation_impedance_para.err_times, SIR_CALC_FILITER_TIME); // 防止越界
    }
    else if (g_insulation_impedance_para.over_timer >= SIR_OVER_TIME_B100MS)    // 3min超时
    {
        g_insulation_impedance_para.success_keep_timer = 0;
        g_insulation_impedance_para.result = INSULATION_IMPEDANCE_OVERTIME;
    }
    else
    {
         g_insulation_impedance_para.success_keep_timer = 0;
    }
    SIR_LIMIT_MAX(g_insulation_impedance_para.over_timer, SIR_OVER_TIME_B100MS);   // 防止越界
}

/** 
 * @brief        获取绝缘阻抗阻值(单位kΩ)
 * @param        [out] 绝缘阻抗结果
 * @return       [int32_t] 执行结果
 * @retval       >=  0 实际计算结果
 * @retval       < 0 无效值
 */
uint32_t insulation_impedance_value_get(void)
{
    return g_insulation_impedance_para.impedance_value;
}

/** 
 * @brief        绝缘阻抗检测屏蔽处理
 * @param        [int] void
 * @return       [out] true：屏蔽，false:正常运行
 * @retval       周期1s任务
 */
bool insulation_impedance_disable_check(void)
{
    static uint8_t sir_disable_cnt = 0;

    // 检测B±电压小于10V,认为空开断开或者没有接电池包，无法启动绝缘阻抗检测
    if (g_insulation_impedance_input_para.bus_volt == SIR_INVALID ||
        g_insulation_impedance_input_para.bus_volt < SIR_DISABLE_MIN_BUS_VOLT)
    {
        if (++sir_disable_cnt >= 30) // 3s滤波
        {
            // 异常打印和处理
            sir_disable_cnt = 30;
            if (g_insulation_impedance_para.result != INSULATION_IMPEDANCE_DISABLE)
            {
                log_e("[ISO]Dis\n");
            }
            g_insulation_impedance_para.result = INSULATION_IMPEDANCE_DISABLE;
            (void)sdk_dido_write(SIR_SW2_PIN, false);
            (void)sdk_dido_write(SIR_SW1_PIN, false);
            (void)sdk_dido_write(SIR_PE_PIN, false);// 断开PE接触器
        }
        return true;
    }
    else  //中途B端电压没了，但是恢复了，也不会做检测，需要CMU控制
    {
//        if (sir_disable_cnt)
//        {
//			if (bms_state_get_sys_step() != BMS_WAKE_CHECK)
//			{
//                insulation_impedance_calc_start();
//				log_e("[ISO]En,cnt:%d,volt:%d\n", sir_disable_cnt,g_insulation_impedance_input_para.bus_volt);
//			}
//            
//            sir_disable_cnt = 0;
//        }
        return false;
    }
}

/** 
 * @brief        绝缘阻抗检测管理
 * @param        [int] void
 * @return       [out] void
 * @retval       周期1s任务
 */
void insulation_impedance_calc_proc(void)
{

//    if (special_mode_get(ATUO_TEST))
//    {
//        return;
//    }
    if (g_insulation_impedance_input_para.debug_flag)
    {
        return;
    }
    insulation_impedance_calc_input_para_get(); // 必须每次都要获取数据
    if (insulation_impedance_disable_check())
    {
        return;
    }
//    if ((INSULATION_FUNC_DISABLE == g_insulation_impedance_para.ins_func_enable_flag) &&
//         (g_insulation_impedance_para.result > INSULATION_IMPEDANCE_CHECKING))  //确保绝缘检测跑完
//    {
//        return;
//    }
    int32_t ret = SIR_OK;
    switch ((uint16_t)g_insulation_impedance_para.state)
    {
        case SIR_CALC_IDLE:
            g_insulation_impedance_para.over_timer = 0;   // 清除超时计数
            break;
        case SIR_CALC_START:
            g_insulation_impedance_para.delay_s_times = 0;
            (void)sdk_dido_write(SIR_PE_PIN, true);// 闭合PE
            insulation_impedance_calc_state_set(SIR_CALC_COLSE_SW1);
            break;
        case SIR_CALC_COLSE_SW1:
            ret |= sdk_dido_write(SIR_SW1_PIN, true);
            ret |= sdk_dido_write(SIR_SW2_PIN, false);
            if (ret == 0)
            {
                insulation_impedance_calc_state_set(SIR_CALC_DELAY1);
            }
            else
            {
                log_e("[SIR]SW1 err\n");
            }
            break;
        case SIR_CALC_DELAY1:
            g_insulation_impedance_para.delay_s_times++;
            if (g_insulation_impedance_para.delay_s_times == SIR_DELAY_SEC_B100MS)
            {
                g_insulation_impedance_para.bus_volt_close_sw1 = g_insulation_impedance_input_para.bus_volt;
                g_insulation_impedance_para.sir_volt_close_sw1 = g_insulation_impedance_input_para.sir_volt;
            }
            else if (g_insulation_impedance_para.delay_s_times > SIR_DELAY_SEC_B100MS)
            {
                g_insulation_impedance_para.bus_volt_close_sw1 = (g_insulation_impedance_input_para.bus_volt + g_insulation_impedance_para.bus_volt_close_sw1) / 2;
                g_insulation_impedance_para.sir_volt_close_sw1 = (g_insulation_impedance_input_para.sir_volt + g_insulation_impedance_para.sir_volt_close_sw1) / 2;
                if (g_insulation_impedance_para.delay_s_times >= (SIR_DELAY_SEC_B100MS + SIR_FILITER_B100MS))
                {
                    insulation_impedance_calc_state_set(SIR_CALC_COLSE_SW2);
                    g_insulation_impedance_para.delay_s_times = 0;
                }
            }
            break;
        case SIR_CALC_COLSE_SW2:
            ret |= sdk_dido_write(SIR_SW2_PIN, true);
            ret |= sdk_dido_write(SIR_SW1_PIN, false);
            if (ret == 0)
            {
                insulation_impedance_calc_state_set(SIR_CALC_DELAY2);
            }
            else
            {
                log_e("[SIR]SW2 err\n");
            }
            break;
        case SIR_CALC_DELAY2:
            g_insulation_impedance_para.delay_s_times++;
            if (g_insulation_impedance_para.delay_s_times == SIR_DELAY_SEC_B100MS)
            {
                g_insulation_impedance_para.bus_volt_close_sw2 = g_insulation_impedance_input_para.bus_volt;
                g_insulation_impedance_para.sir_volt_close_sw2 = g_insulation_impedance_input_para.sir_volt;
            }
            else if (g_insulation_impedance_para.delay_s_times > SIR_DELAY_SEC_B100MS)
            {
                g_insulation_impedance_para.bus_volt_close_sw2 = (g_insulation_impedance_input_para.bus_volt + g_insulation_impedance_para.bus_volt_close_sw2) / 2;
                g_insulation_impedance_para.sir_volt_close_sw2 = (g_insulation_impedance_input_para.sir_volt + g_insulation_impedance_para.sir_volt_close_sw2) / 2;
                if (g_insulation_impedance_para.delay_s_times >= (SIR_DELAY_SEC_B100MS + SIR_FILITER_B100MS))
                {
                    insulation_impedance_calc_state_set(SIR_CALC_RESULT);
                    g_insulation_impedance_para.delay_s_times = 0;
                }
            } 
            break;
        case SIR_CALC_RESULT:
            insulation_impedance_calc_deal();
            (void)sdk_dido_write(SIR_SW2_PIN, false);
            (void)sdk_dido_write(SIR_SW1_PIN, false);
            insulation_impedance_calc_state_set(SIR_CALC_END);
            insulation_impedance_record_data();
            log_d("[SIR]iso suc times:%d, err times:%d, finished result:%d\n",g_insulation_impedance_para.success_times, g_insulation_impedance_para.err_times, g_insulation_impedance_para.result);
            break;
        case SIR_CALC_END: // 绝缘阻抗检测结束
            if (INSULATION_IMPEDANCE_CHECKING == g_insulation_impedance_para.result)
            {
                insulation_impedance_calc_state_set(SIR_CALC_START);
            }
            else if(g_insulation_impedance_para.result > INSULATION_IMPEDANCE_CHECKING) //TO DO说明检测完成了（不管是正常还是异常）
            {
                (void)sdk_dido_write(SIR_PE_PIN, false);//断开PE
            }
            break;
        default:
            insulation_impedance_calc_state_set(SIR_CALC_START);
            break;
    }
    insulation_impedance_check_result_update();
}


#ifdef APP_BCU_SIP_TEST
static int32_t insulation_impedance_debug_check(void)
{
    if (!g_insulation_impedance_input_para.debug_flag)
    {
        log_d("No debug\n");
        return 0;
    }
    // V1:45691 V2:45597 Vbus:180094  res:2.7k
    g_insulation_impedance_para.bus_volt_close_sw1 = 180094;
    g_insulation_impedance_para.bus_volt_close_sw2 = 180094;
    g_insulation_impedance_para.sir_volt_close_sw1 = 45691;
    g_insulation_impedance_para.sir_volt_close_sw2 = 45597;
    insulation_impedance_calc_deal();
    if (g_insulation_impedance_para.impedance_value == 2)
    {
        log_d("sipCheck1Ok\n");
    }
    // V1:45291 V2:30597 Vbus:180094  res:510.24k
    g_insulation_impedance_para.bus_volt_close_sw1 = 180094;
    g_insulation_impedance_para.bus_volt_close_sw2 = 180094;
    g_insulation_impedance_para.sir_volt_close_sw1 = 45291;
    g_insulation_impedance_para.sir_volt_close_sw2 = 30597;
    insulation_impedance_calc_deal();
    if (g_insulation_impedance_para.impedance_value == 510)
    {
        log_d("sipCheck2Ok\n");
    }
    // V1:88652 V2:30527 Vbus:179968  res:4985.88k
    g_insulation_impedance_para.bus_volt_close_sw1 = 179968;
    g_insulation_impedance_para.bus_volt_close_sw2 = 179968;
    g_insulation_impedance_para.sir_volt_close_sw1 = 88652;
    g_insulation_impedance_para.sir_volt_close_sw2 = 30527;
    insulation_impedance_calc_deal();
    if (g_insulation_impedance_para.impedance_value == 4985)
    {
        log_d("sipCheck3Ok\n");
    }
    return 0;
}

/**
 * @brief        绝缘检测功能样例
 * @param        argv 功能参数
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
static int iso(int argc, char *argv[])
{
    char *para1 = strtok(NULL, " "); //解析第一个参数名称
    if (argc < 2)
    {
        log_d("IsoErr\n");
        return SF_ERR_PARA;
    }
    if (!strcmp(argv[1], "print"))
    {
        insulation_impedance_calc_print();
    }
    else if (!strcmp(argv[1], "start"))
    {
        if (g_insulation_impedance_input_para.debug_flag)
        {
            log_d("Is debug statu, can't start\n");
        }
        insulation_impedance_calc_start();
    }
    else if (!strcmp(argv[1], "debug"))
    {
        if (argc < 3)
        {
            log_d("IsoDebugErr\n");
            return SF_ERR_PARA;
        }
        uint32_t debug_flag = atoi(argv[2]); // 参数1：debug标志（1使能，0取消），
        insulation_impedance_calc_debug_set(debug_flag);
    }
    else if (!strcmp(argv[1], "setdo"))
    {
        if (argc < 4)
        {
            log_d("IsoSetDoErr\n");
            return SF_ERR_PARA;
        }
        if (!g_insulation_impedance_input_para.debug_flag)
        {
            log_d("NoDebugStatu\n");
            return 0;
        }
        int32_t sw1 = atoi(argv[2]);         // 参数1：设置sw1高低电平(0/1)
        int32_t sw2 = atoi(argv[3]);         // 参数2：设置sw2高低电平(0/1)
        (void)sdk_dido_write(SIR_SW2_PIN, sw2);
        (void)sdk_dido_write(SIR_SW1_PIN, sw1);
    }
    else if (!strcmp(argv[1], "set_res"))
    {
        if (argc < 3)
        {
            log_d("IsoSetResErr\n");
            return SF_ERR_PARA;
        }
        if (!g_insulation_impedance_input_para.debug_flag)
        {
            log_d("NoDebugStatu\n");
            return 0;
        }
        int32_t res_val = atoi(argv[2]);         // 参数1：设置绝缘阻抗大小单位kΩ
        g_insulation_impedance_para.impedance_value = res_val;
    }
    else if (!strcmp(para1, "set_result"))
    {
        if (argc < 3)
        {
            log_d("IsoSetResultErr\n");
            return SF_ERR_PARA;
        }
        if (!g_insulation_impedance_input_para.debug_flag)
        {
            log_d("NoDebugStatu\n");
            return 0;
        }
        int32_t result = atoi(argv[2]);         // 参数1：设置检测结果（insulation_impedance_check_result_e）
        if (result > INSULATION_IMPEDANCE_OVERTIME)
        {
            log_d("result type over(0~%d)\n", INSULATION_IMPEDANCE_OVERTIME);
            return -1;
        }
        g_insulation_impedance_para.result = (insulation_impedance_check_result_e)result;
    }
    else if (!strcmp(para1, "check"))
    {
        insulation_impedance_debug_check();
    }
    else
    {
//        log_d("sip_t param err\r\n");
//        log_d("sip_t print : printf data\r\n");
//        log_d("sip_t start : start insulation_impedance\r\n");
//        log_d("sip_t debug flag(0/1): on/off debug\r\n");
//        log_d("sip_t setdo sw1(0/1) sw(0/1): set sw1 sw2 pin\r\n");
//        log_d("sip_t set_res  val: set res data\r\n");
//        log_d("sip_t set_result  val: set_result flag\r\n");
//        log_d("sip_t check: check flag\r\n");
        return -1;
    }
    return 0;
}
MSH_CMD_EXPORT(iso, <print/debug 0-1/setdo sw1 sw2/set_res value/set_result result/check>);
#endif

