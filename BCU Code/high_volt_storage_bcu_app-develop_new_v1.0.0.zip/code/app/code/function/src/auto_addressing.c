/**********************************************************************************
 * 创建时间: 2022-10-13 14:41:55
 * 邮箱: yuanzhihua@sofarsolar.com
 * 版本: V1.0
 * 描述:
 * 修改:
 *
 **********************************************************************************/
 
#include "auto_addressing.h"
#include "sdk.h"
#include "sdk_dido.h"
#include "app_config.h"
#include "app_public.h"
#include "bmu_data.h"
#include "state_machine.h"
#include "upgrade_master.h"
#include "data_store.h"

#define IN_ADDR_DEBUG_ENABLE 1									///< 0禁止打印信息 1使能打印信息
#define THIS_LOGA(...) log_d(__VA_ARGS__)
#define THIS_LOGE(...) if (IN_ADDR_DEBUG_ENABLE) log_e(__VA_ARGS__)
#define THIS_LOGW(...) log_d(__VA_ARGS__)
#define THIS_LOGI(...) if (IN_ADDR_DEBUG_ENABLE) log_d(__VA_ARGS__)
#define THIS_LOGD(...) if (IN_ADDR_DEBUG_ENABLE) log_d(__VA_ARGS__)
    
#define AUTO_ADDR_TIME_B10MS         (10)    // 10ms任务
#define AUTO_ADDR_ONE_SEC_TIME_CNT  (1000 / AUTO_ADDR_TIME_B10MS) // 1s的运行次数
#define AUTO_ADDR_1S_TIMER          (1 * AUTO_ADDR_ONE_SEC_TIME_CNT)
#define AUTO_ADDR_200MS_BASE_CNT    (200 / AUTO_ADDR_TIME_B10MS)  // 200ms对应的运行次数
#define AUTO_ADDR_150MS_BASE_CNT    (150 / AUTO_ADDR_TIME_B10MS)  // 150ms对应的运行次数
#define AUTO_ADDR_100MS_BASE_CNT    (100 / AUTO_ADDR_TIME_B10MS)  // 100ms对应的运行次数
/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
//                                          变量声明
/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
typedef enum
{
    NON_CAN_ADDR_SET_CMD = 0,        // 0x00:无操作
    CAN_ADDR_SET_IO_HIGH_CMD = 0x01, // 0x01:拉高ID_OUT
    CAN_ADDR_SET_IO_LOW_CMD = 0x02,  // 0x02:下拉ID_OUT
    CAN_SET_ADDR_CMD  = 0x03,        // 0x03:主机设置地址
    CAN_SET_ADDR_STORE_CMD = 0x7D,   // 0x7D:存储自身地址
    CAN_SET_START_ADDR_CMD = 0x7E,   // 0x7E： 主机设置重新编址/从机请求编址
} can_addr_set_cmd_u;

typedef enum
{
    NON_CAN_RX_SLA_ADDR_SET_CMD = 0,        // 0x00:无操作
    CAN_RX_SLA_ADDR_SET_IO_HIGH_CMD = 0x01, // 0x01:拉高ID_OUT
    CAN_RX_SLA_ADDR_SET_IO_LOW_CMD = 0x02,  // 0x02:下拉ID_OUT
    CAN_RX_SLA_SET_ADDR_CMD  = 0x03,        // 0x03:主机设置地址/ 从机编址完成
    CAN_RX_SLA_ADDR_CONFLICT_CMD = 0x7C,    // 从机地址冲突
    CAN_RX_SLA_SET_START_ADDR_CMD = 0x7E,   // 0x7E： 主机设置重新编址/从机请求编址
} can_recv_sla_addr_cmd_u;

enum // 通讯命令字定义
{
    CMD_START_ADDRESSING = 1, // 开始自动编址
    CMD_SET_OUTPUT,           // 设置从机输出口电平
    CMD_SET_SLAVE_ADDR,       // 设置从机地址
    CMD_CHECK_SLAVE_ADDR,     // 验证从机地址
    CMD_REQUEST,              // 请求编址
    CMD_HEARTBEAT,            // 地址心跳包
    CMD_CONFLICT,        // 地址冲突命令
    CMD_DI_CHECK,        // 编址电平检测
    CMD_OFF,                  // 关机
};

// 通讯信息数据结构
typedef struct
{
    uint8_t dst_type;
    uint8_t dst_addr; // 目标地址
    uint8_t src_type;
    uint8_t src_addr; // 源地址
    uint16_t cmd;      // 命令
    uint16_t sleep_cmd; // 休眠请求
    uint16_t data;     // 数据
} msg_t;

// 等待通信回复结构
typedef struct
{
    msg_t expect_rcv_msg;    // 编址命令下发后，期待收到的回复消息
    uint8_t cmd_reply_state;      // 等待的应答状态，1：接收到、0：未接收
    uint8_t need_reply_flag;   // 需要应答标志位，1：需要，0：不需要
    uint32_t reply_over_time_cnt;   // 应答接收超时计数
} reply_msg_state_t;

// 等待pin校验结构
typedef struct
{
    uint32_t check_pin_over_timer;     // pin脚检测超时计数
    uint8_t check_pin_start_flag;      // 启动pin脚校验标志状态，1：完成、0：未完成
    uint8_t check_pin_over_time_cnt;   // 应答接收超时计数
    uint8_t check_success_cnt;         // 接收ok连续次数
    uint8_t check_pin_err_cnt;         // 电平引脚异常次数
    uint8_t start_pin_err_cnt;         // 上电初始编址电平异常
} check_pin_state_t;
/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
//                                          函数声明
/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */

static int32_t send_addr_msg(msg_t *msg);                           //
static int32_t addr_cmd_reply_check(uint32_t over_time); //
static void send_heartbeat(void);
static void check_pack_comm_status(void);
static void can_convert_to_addr_msg(uint32_t can_id, uint8_t *p_data, msg_t* addr_msg, uint8_t len);
static void inner_addr_rcv_msg(msg_t *p_rcv_msg);
static uint8_t sta_addr_init_run(void);
static uint8_t sta_addr_disen_entry(void);
static uint8_t sta_addr_disen_run(void);
static uint8_t sta_set_addr_pin_entry(void);
static uint8_t sta_set_addr_pin_run(void);
static uint8_t sta_set_slave_addr_run(void);
static uint8_t sta_wait_slave_reply_run(void);
static uint8_t sta_check_addr_pin_entry(void);
static uint8_t sta_check_addr_pin_run(void);
static uint8_t sta_master_addr_suc_entry(void);
static uint8_t sta_master_addr_suc_run(void);
static uint8_t sta_master_addr_store_entry(void);
static uint8_t sta_master_addr_store_run(void);
static uint8_t sta_master_addr_failed_run(void);


/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
//                                          变量定义
/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
static fsm_action_map_t g_addr_act_map[ADDR_STA_NUM] = 
{
    [STA_ADDR_INIT]           = {NULL, sta_addr_init_run},
    [STA_ADDR_DISEN]          = {sta_addr_disen_entry, sta_addr_disen_run},
    [STA_SET_ADDR_PIN]        = {sta_set_addr_pin_entry, sta_set_addr_pin_run},
    [STA_SET_SLAVE_ADDR]      = {NULL, sta_set_slave_addr_run},
    [STA_WAIT_SLAVE_REPLY]    = {NULL, sta_wait_slave_reply_run},
    [STA_CHECK_CTL_PIN_STA]   = {sta_check_addr_pin_entry , sta_check_addr_pin_run},
    [STA_MAS_ADDR_SUC]        = {sta_master_addr_suc_entry, sta_master_addr_suc_run},
    [STA_MAS_ADDR_STORE]      = {sta_master_addr_store_entry, sta_master_addr_store_run},
    [STA_MAS_ADDR_FAIL]       = {NULL, sta_master_addr_failed_run},
};

static uint8_t g_addr_evt_sta_map[ADDR_STA_NUM][ADDR_EVT_NUM] = 
{                          // EVT_ADDR_STA_CPL_SUC     EVT_ADDR_CONT_START  EVT_ADDR_FAULT
    [STA_ADDR_INIT]         = {STA_ADDR_DISEN,          STA_NULL,             STA_NULL},
    [STA_ADDR_DISEN]        = {STA_SET_ADDR_PIN,        STA_NULL,             STA_NULL},
    [STA_SET_ADDR_PIN]      = {STA_SET_SLAVE_ADDR,      STA_NULL,             STA_NULL},
    [STA_SET_SLAVE_ADDR]    = {STA_WAIT_SLAVE_REPLY,    STA_NULL,             STA_NULL},
    [STA_WAIT_SLAVE_REPLY]  = {STA_CHECK_CTL_PIN_STA,   STA_SET_ADDR_PIN,     STA_NULL},
    [STA_CHECK_CTL_PIN_STA] = {STA_MAS_ADDR_SUC,        STA_SET_ADDR_PIN,     STA_NULL},
    [STA_MAS_ADDR_SUC]      = {STA_MAS_ADDR_STORE,      STA_NULL,             STA_MAS_ADDR_FAIL},
    [STA_MAS_ADDR_STORE]    = {STA_ADDR_INIT,           STA_NULL,             STA_NULL},    
    [STA_MAS_ADDR_FAIL]     = {STA_ADDR_DISEN,          STA_NULL,             STA_ADDR_INIT},    
};

static state_machine_t g_auto_addr_fsm = {0};
static const char* g_auto_addr_fsm_name = "innerAddr";
static uint16_t g_fsm_time_cnt = 0; // 状态机，状态时间计数
static uint16_t g_master_addressing_step; // 主机编址步骤(0x01~0xA),最多10台BMU设备
static reply_msg_state_t g_reply_msg_state = {0};  // 应答接收状态
static check_pin_state_t g_check_pin_state = {0};  // 应答接收状态
static master_addr_para g_inn_addr_para =
{
    .auto_addressing_enable = ADDRESSING_DISENABLE,    // 使能自动编址
    .addr_state = ADDRESSING_DISENABLE,   // 编址状态
    .pack_num = 0,       // 电池包数量
    .master_addr_failed_cnt = 0, // 主机编址失败次数
    .addr_abnormal_cnt = 0,
    .have_pack_on_addressing = 0, // 存在未编址电池包
    .address_conflict_flag = 0,
    .fault_id_conflict = 0,    // 编址ID冲突
    .fault_pack_unlink = 0,    // 电池包失联
    .fault_pack_on_addressing = 0, // 电池包未被编址
    .fault_pack_num_mismatch = 0, // 编址后电池包数量与预设电池包个数不匹配	
    .fault_time_stamp = 0,  // 编址异常判断时间戳
};
static pack_comm_status g_pack_comm_status[PACK_MAX_NUM] = {0};
//static uint8_t g_version[4] = {0};
static uint8_t g_pack_addr_pin_state_flag = false;  // 检测到电池包有处于编址电平标志
static uint8_t g_pack_addr_default_pin_timer_cnt = 0;  // 检测所有pack为默认电平周期
/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
//                                         硬件接口适配
/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */

// 编址电平配置，0:低电平，1:高电平
#define ADDRESSING_PIN_STATUS    (1)
// 设置输出PIN脚为高
#define OUTPUT_PIN_SET_HIGH() 	sdk_dido_write(DO_4_INNER_ADDR_1, 1);sdk_dido_write(DO_5_INNER_ADDR_2, 1)
// 设置输出PIN脚为低
#define OUTPUT_PIN_SET_LOW() 	sdk_dido_write(DO_4_INNER_ADDR_1, 0);sdk_dido_write(DO_5_INNER_ADDR_2, 0)
// 设置地址电平控制
#define OUTPUT_PIN_SET_ADDRESSING() (sdk_dido_write(DO_4_INNER_ADDR_1, ADDRESSING_PIN_STATUS));(sdk_dido_write(DO_5_INNER_ADDR_2, ADDRESSING_PIN_STATUS))
// 默认电平控制
#define OUTPUT_PIN_SET_DEFAULT()   (sdk_dido_write(DO_4_INNER_ADDR_1, !ADDRESSING_PIN_STATUS));(sdk_dido_write(DO_5_INNER_ADDR_2, !ADDRESSING_PIN_STATUS))

#define ADDR_PIN_CHECK_ERR_TIME  (5)
/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
//                                        函数实现
/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
/**
 * @brief   检测所有pack编址电平为默认电平
 * @param   无
 * @return  无
 * @warning	 10ms任务
 */
static void pack_addr_di_default_pin_check(void)
{
    if (++g_pack_addr_default_pin_timer_cnt >= AUTO_ADDR_150MS_BASE_CNT)
    {
        g_pack_addr_pin_state_flag = false;
        g_pack_addr_default_pin_timer_cnt = 0;
    }
}

/**
 * @brief   内网CAN(bmu/bcu)，自动编址初始化状态进入处理
 * @param   无
 * @return  返回执行结果 0Xff,无事件
 * @warning	无
 */
static uint8_t sta_addr_init_run(void)
{
    uint8_t event = EVT_NULL;
//    g_version[0] = SOFTWARE_VERSION[1];
//    g_version[1] = ((SOFTWARE_VERSION[2] - '0') * 10) + (SOFTWARE_VERSION[3] - '0');
//    g_version[2] = ((SOFTWARE_VERSION[4] - '0') * 10) + (SOFTWARE_VERSION[5] - '0');
//    g_version[3] = ((SOFTWARE_VERSION[6] - '0') * 10) + (SOFTWARE_VERSION[7] - '0');
//    

    
    if(g_inn_addr_para.auto_addressing_enable)
    {
        g_inn_addr_para.addr_state = ADDRESSING_DISENABLE; // 未使能自动编址
        g_inn_addr_para.addr_abnormal_cnt = 0;  // 主机编址异常连续统计次数
        event = EVT_ADDR_STA_CPL_SUC;
    }
    else
    {
        g_inn_addr_para.addr_state = ADDRESSING_FINISH; // 使用存储地址
        g_inn_addr_para.pack_num = get_bms_attr()->clu_pack_num;
        // 电池包地址冲突
        if (g_inn_addr_para.address_conflict_flag)
        {
            g_inn_addr_para.fault_id_conflict = 1;
        }

        // 存在未被编址的电池包
        if (g_inn_addr_para.have_pack_on_addressing)
        {
            g_inn_addr_para.fault_pack_on_addressing = 1;
        }
        
        // 编址后电池包数量与预设电池包个数不匹配	
        if (g_inn_addr_para.pack_num != get_bms_attr()->clu_pack_num)
        {
            g_inn_addr_para.fault_pack_num_mismatch = true;
        }
             
        send_heartbeat();   // 定时发送心跳
        check_pack_comm_status(); // 检测从机通信状态
    }
    return event;
}

/**
 * @brief   内网CAN(bmu/bcu)，未使能自动编状态进入处理
 * @param   无
 * @return  返回执行结果 0Xff,无事件
 * @warning	无
 */
static uint8_t sta_addr_disen_entry(void)
{
    g_fsm_time_cnt = 0;
    // 相关参数初始化
    g_inn_addr_para.pack_num = 0;   // 编址完成后电池包数量	
    g_inn_addr_para.master_addr_failed_cnt = 0; // 主机编址失败次数
    g_inn_addr_para.have_pack_on_addressing = 0; // 存在未编址电池包
    g_inn_addr_para.address_conflict_flag = 0;
    g_inn_addr_para.fault_id_conflict = 0;    // 编址ID冲突
    g_inn_addr_para.fault_pack_unlink = 0;    // 电池包失联
    g_inn_addr_para.fault_pack_on_addressing = 0; // 电池包未被编址
    g_inn_addr_para.fault_pack_num_mismatch = 0; // 编址后电池包数量与预设电池包个数不匹配	
    g_inn_addr_para.fault_time_stamp = 0;  // 编址异常判断时间戳
    return EVT_NULL;
}
#define INNER_ADDR_WAIT_BMU_START_TIME 120    // 10MS任务中运行，延时1200ms
#define INNER_ADDR_WAIT_BMU_RESTART_TIME 20  // 200ms
#define INNER_ADDR_START_DELAY_TIME 5   // 10MS任务中运行，延时50ms

/**
 * @brief   内网CAN(bmu/bcu)，未使能自动编状态运行处理
 * @param   无
 * @return  返回执行结果 0:初始化完成事件
 * @warning	无
 */
static uint8_t sta_addr_disen_run(void)
{
    static uint8_t first_flag = 0;
    uint8_t event = EVT_NULL;
    if (g_inn_addr_para.auto_addressing_enable) // 使能开始主机编址状态
    {
        OUTPUT_PIN_SET_DEFAULT(); // 激活下一个电池(上电后马上拉低"本机编址输出口")
        // 主机等待BMU上电启动时间1200ms再编址,确保电池包都上电,Idout拉低(否则会出现多次编址)
        if (first_flag == 0)
        {
            if (++g_fsm_time_cnt <= INNER_ADDR_WAIT_BMU_START_TIME)
            {
                return event;
            }
            g_fsm_time_cnt = 0;
            first_flag = 1;
        }
        if ((g_fsm_time_cnt % INNER_ADDR_WAIT_BMU_RESTART_TIME)== 0)
        {
            msg_t send_msg;
            send_msg.src_addr = BCU_INNER_CAN_ADDR;
            send_msg.dst_addr = BROCAST_DEVICE_ADDRESS;
            send_msg.cmd = CMD_START_ADDRESSING;
            send_addr_msg(&send_msg);
        }
        if ((g_fsm_time_cnt % AUTO_ADDR_100MS_BASE_CNT) == 0)
        {
            // 每100ms确定电平状态
            if (g_pack_addr_pin_state_flag)
            {
                g_fsm_time_cnt = 0;
                g_check_pin_state.start_pin_err_cnt++;
            }
            else
            {
                g_check_pin_state.start_pin_err_cnt = 0;
            }
        }
         // 主机发送启动编址后延时200ms再编址
        if (++g_fsm_time_cnt <= INNER_ADDR_WAIT_BMU_RESTART_TIME || true == g_pack_addr_pin_state_flag)
        {
            return event;
        }       
        g_master_addressing_step = 1;
        THIS_LOGE("[ADD]BCU,addr\n");
        g_inn_addr_para.master_addr_failed_cnt = 0;
        event = EVT_ADDR_STA_CPL_SUC;
    }
    return event;
}

/**
 * @brief   内网CAN(bmu/bcu)，未使能自动编状态进入处理
 * @param   无
 * @return  返回执行结果 0Xff,无事件
 * @warning	无
 */
static uint8_t sta_set_addr_pin_entry(void)
{
    g_fsm_time_cnt = 0;
    if (g_master_addressing_step == 1)
    {
        OUTPUT_PIN_SET_ADDRESSING();
    }
    else    // 发送编址输出引脚，输出设置命令
    {
        msg_t send_msg;
        send_msg.src_addr = BCU_INNER_CAN_ADDR;
        send_msg.dst_addr = g_master_addressing_step - 1;   //这里-1是为了我要给g_master_addressing_step这个BMU编址，但是需要控制上一个BMU的控制引脚
        send_msg.cmd = CMD_SET_OUTPUT;
        send_msg.data = ADDRESSING_PIN_STATUS;
        send_addr_msg(&send_msg);
    }
    return EVT_NULL;
}

/**
 * @brief   内网CAN(bmu/bcu)，未使能自动编状态运行处理
 * @param   无
 * @return  返回执行结果 0:初始化完成事件
 * @warning	无
 */
static uint8_t sta_set_addr_pin_run(void)
{
    uint8_t event = EVT_NULL;
    g_inn_addr_para.addr_state = ADDRESSING_ING;  // 正在编址
    if (++g_fsm_time_cnt > 15)                    // 延时150ms
    {
        THIS_LOGD("[ADD]set pack%d out_pin:%d ...\n", g_master_addressing_step - 1, ADDRESSING_PIN_STATUS);
        event = EVT_ADDR_STA_CPL_SUC;
    }
    return event;
}
/**
 * @brief   内网CAN(bmu/bcu)，未使能自动编状态进入处理
 * @param   无
 * @return  返回执行结果 0:正常；<0:异常
 * @warning	无
 */
static uint8_t sta_set_slave_addr_run(void)
{
    msg_t send_msg;
    send_msg.cmd = CMD_SET_SLAVE_ADDR;
    send_msg.src_addr = BCU_INNER_CAN_ADDR;
    send_msg.dst_addr = BROCAST_DEVICE_ADDRESS;
    send_msg.data = g_master_addressing_step;
    send_addr_msg(&send_msg);
    THIS_LOGE("[ADD]set pack%d addr..\n", g_master_addressing_step - 1);
    int16_t di_status = 0;
    for (uint8_t pack_id = 1; pack_id < g_master_addressing_step; pack_id++)
    {
        di_status = bmu_di_status_get(pack_id, BMS_DI_DI_INPUT_TYPE);
        if ((ADDRESSING_PIN_STATUS) == di_status)
        {
            THIS_LOGE("[ADD]oth pack%d di_pi_%d\n", pack_id - 1, ADDRESSING_PIN_STATUS);
        }
    }
    g_reply_msg_state.reply_over_time_cnt = 0;    // 发送完地址设置消息后，立即给预期接收消息赋值
    g_reply_msg_state.cmd_reply_state = 0;
    g_reply_msg_state.need_reply_flag = 1;
    g_reply_msg_state.expect_rcv_msg.src_addr = g_master_addressing_step;
    g_reply_msg_state.expect_rcv_msg.dst_addr = BCU_INNER_CAN_ADDR;
    g_reply_msg_state.expect_rcv_msg.cmd = CMD_SET_SLAVE_ADDR;
    g_reply_msg_state.expect_rcv_msg.data = g_master_addressing_step;
    g_check_pin_state.check_pin_over_timer = 0;
    g_check_pin_state.check_pin_over_time_cnt = 0;
    g_check_pin_state.check_pin_start_flag = 0;
    return EVT_ADDR_STA_CPL_SUC;
}

/**
 * @brief   内网CAN(bmu/bcu)，未使能自动编址状态运行处理
 * @param   无
 * @return  返回执行结果 0:初始化完成事件
 * @warning	无
 */
static uint8_t sta_wait_slave_reply_run(void)
{
    uint8_t event = EVT_NULL;
    int32_t res = addr_cmd_reply_check(20); // 200ms超时
    if (res == 1)
    {
        g_check_pin_state.check_pin_start_flag = true;
        THIS_LOGE("[ADD]pack%d reply ok\n", g_master_addressing_step - 1);
        event = EVT_ADDR_STA_CPL_SUC; // 应答结束

    }
    else if (res == -1)
    {
        if (++g_inn_addr_para.master_addr_failed_cnt >= 3)
        { // 编址从机3次没有回复视为编址完成。
            g_check_pin_state.check_pin_start_flag = false; // 最后一个电池包无需校验pin
            event = EVT_ADDR_STA_CPL_SUC; // 应答结束
        }
        else
        {
            event = EVT_ADDR_CONT_START; // 给从机重发编址
        }
        THIS_LOGE("[ADD]pack%d reply cnt = %d\n", g_master_addressing_step - 1, g_inn_addr_para.master_addr_failed_cnt);
    }
    return event;
}

/**
 * @brief   内网CAN(bmu/bcu)，设置上一个pack默认电平
 * @param   无
 * @return  无返回执行结果
 * @warning	无
 */
static void last_pack_do_pin_default_set(void)
{
    msg_t send_msg;
    send_msg.src_addr = BCU_INNER_CAN_ADDR;
    send_msg.cmd = CMD_SET_OUTPUT;
    send_msg.dst_addr = g_master_addressing_step - 1;
    send_msg.data = !ADDRESSING_PIN_STATUS;
    if (send_msg.dst_addr == 0)    // BCU主机控制BMU从机编址输入电平拉低
    {
        OUTPUT_PIN_SET_DEFAULT();
    }
    else
    {
        send_addr_msg(&send_msg);
    }
}

/**
 * @brief   内网CAN(bmu/bcu)，检测电池包pin脚控制状态进入任务
 * @param   无
 * @return  返回执行结果 0:正常；<0:异常
 * @warning	无 g_check_pin_state
 */
static uint8_t sta_check_addr_pin_entry(void)
{
    uint8_t event = EVT_NULL;
    g_check_pin_state.check_pin_over_timer = 0;
    g_check_pin_state.check_pin_over_time_cnt = 0;
    g_check_pin_state.check_success_cnt = 0;
    // 进入检测函数，先调用io控制
    last_pack_do_pin_default_set();
    return event;
}

/**
 * @brief   内网CAN(bmu/bcu)，检测电池包pin脚控制状态处理任务
 * @param   无
 * @return  返回执行结果 0:正常；<0:异常
 * @warning	无
 */
static uint8_t sta_check_addr_pin_run(void)
{
    uint8_t event = EVT_NULL;
    // 无需检测
    if ((!g_check_pin_state.check_pin_start_flag))
    {
        event = EVT_ADDR_STA_CPL_SUC;
        return event;
    }
    uint8_t default_level_flag = false;
    for (uint8_t i = 1; i <= g_master_addressing_step; i++)
    {
        if ((ADDRESSING_PIN_STATUS) == bmu_di_status_get(i, BMS_DI_DI_INPUT_TYPE))
        {
            default_level_flag = true;
        }
    }
    if (false == g_pack_addr_pin_state_flag && false == default_level_flag)
    {
        g_check_pin_state.check_success_cnt++;
    }
    else
    {
        g_check_pin_state.check_success_cnt = 0;
    }
    
    g_check_pin_state.check_pin_over_timer++;
    if (g_check_pin_state.check_pin_over_timer >= AUTO_ADDR_1S_TIMER)
    {
        last_pack_do_pin_default_set();
        g_check_pin_state.check_pin_over_time_cnt++;
        g_check_pin_state.check_pin_over_timer = 0;
        if (g_check_pin_state.check_pin_over_time_cnt >= 3)
        {
            g_check_pin_state.check_pin_err_cnt++;
            event = EVT_ADDR_STA_CPL_SUC;
        }
        THIS_LOGE("[ADD]check_o_tim%d\n", g_check_pin_state.check_pin_over_time_cnt);
        THIS_LOGE("[ADD]lv = %d,pin_sta= %d\n", default_level_flag, g_pack_addr_pin_state_flag);
    }
    
    if (g_check_pin_state.check_success_cnt > 3) // 连续校验3次
    {
        THIS_LOGE("[ADD]pack%d di_sta:%d\n", g_master_addressing_step - 1, !ADDRESSING_PIN_STATUS);
        g_master_addressing_step++;
        g_check_pin_state.check_pin_err_cnt = 0;
        if (g_master_addressing_step <= PACK_MAX_NUM)
        {
            event = EVT_ADDR_CONT_START; // 给下一个从机编址
            g_inn_addr_para.master_addr_failed_cnt = 0;
            g_check_pin_state.check_pin_over_time_cnt = 0;
        }
        else
        {
            event = EVT_ADDR_STA_CPL_SUC; // 编址结束
        }
    }
    return event;
}

/**
 * @brief   内网CAN(bmu/bcu)，自动编址完成状态进入处理
 * @param   无
 * @return  返回执行结果 0:正常；<0:异常
 * @warning	无
 */
static uint8_t sta_master_addr_suc_entry(void)
{
    g_inn_addr_para.pack_num = g_master_addressing_step - 1;
    THIS_LOGE("[ADD]succeed.packnum %d!\n", g_inn_addr_para.pack_num);
    memset(g_pack_comm_status, 0, sizeof(g_pack_comm_status));
    g_inn_addr_para.have_pack_on_addressing = 0;
    g_inn_addr_para.address_conflict_flag = 0;
    g_inn_addr_para.fault_time_stamp = sdk_tick_get();
    return EVT_NULL;
}

/**
 * @brief   内网CAN(bmu/bcu)，，自动编址完成状态运行处理
 * @param   无
 * @return  返回执行结果 0:初始化完成事件
 * @warning	无
 */
static uint8_t sta_master_addr_suc_run(void)
{
    uint8_t event = EVT_NULL;
    send_heartbeat();   // 定时发送心跳
    check_pack_comm_status(); // 检测从机通信状态

    // 重新编址后，1.5秒没有地址冲突、未被编址的电池包
    if (sdk_is_tick_over(g_inn_addr_para.fault_time_stamp, os_tick_from_millisecond(1500)))
    {
        g_inn_addr_para.fault_time_stamp = sdk_tick_get();
        g_inn_addr_para.fault_id_conflict = 0;
        g_inn_addr_para.fault_pack_on_addressing = 0;
        g_inn_addr_para.addr_state = ADDRESSING_FINISH; // 编址完成
        g_inn_addr_para.addr_abnormal_cnt = 0;
        g_check_pin_state.check_pin_err_cnt = 0;
        g_check_pin_state.start_pin_err_cnt = 0;
        g_inn_addr_para.fault_pack_num_mismatch = 0;
        event = EVT_ADDR_STA_CPL_SUC;
    }

    // 电池包地址冲突
    if (g_inn_addr_para.address_conflict_flag)
    {
        THIS_LOGE("[ADD]id cft\n");
        g_inn_addr_para.fault_id_conflict = 1;
        event = EVT_ADDR_FAULT;
    }

    // 存在未被编址的电池包
    if (g_inn_addr_para.have_pack_on_addressing)
    {
        THIS_LOGE("[ADD]pack on add\n");
        g_inn_addr_para.fault_pack_on_addressing = 1;
        event = EVT_ADDR_FAULT;
    }
    
    // 编址后电池包数量与预设电池包个数不匹配	
    if (g_inn_addr_para.pack_num != get_bms_attr()->clu_pack_num)
    {
        g_inn_addr_para.fault_pack_num_mismatch = true;
        THIS_LOGE("[ADD]pack %d mismatch %d\n",g_inn_addr_para.pack_num, get_bms_attr()->clu_pack_num);
        event = EVT_ADDR_FAULT;
    }
  

    if (g_check_pin_state.check_pin_err_cnt != 0 ||
        g_check_pin_state.start_pin_err_cnt != 0)
    {
        event = EVT_ADDR_FAULT;
        THIS_LOGE("[ADD]low lv err\n");
    }
    return event;
}

/**
 * @brief   内网CAN(bmu/bcu)，告诉bmu存储地址进入状态
 * @param   无
 * @return  返回执行结果 0:正常；<0:异常
 * @warning	无
 */
static uint8_t sta_master_addr_store_entry(void)
{
    THIS_LOGE("[ADD]store.packnum %d!\n", g_inn_addr_para.pack_num);
    g_inn_addr_para.addr_store_send_cnt = 0;
    return EVT_NULL;
}


/**
 * @brief   内网CAN(bmu/bcu)，，告诉bmu存储地址运行处理
 * @param   无
 * @return  返回执行结果 0:初始化完成事件
 * @warning	无
 */
#define STORE_TIME  5
static uint8_t sta_master_addr_store_run(void)
{
    uint8_t event = EVT_NULL;
    can_frame_id_u tx_frame_id = {0};
    uint8_t data[8] = {0};

    send_heartbeat();   // 定时发送心跳
    check_pack_comm_status(); // 检测从机通信状态
    
    // 500mS广播一次地址存储
    if ((sdk_is_tick_over(g_inn_addr_para.fault_time_stamp, os_tick_from_millisecond(500)))
        && (g_inn_addr_para.addr_store_send_cnt <= STORE_TIME))
    {
        g_inn_addr_para.addr_store_send_cnt++;
        g_inn_addr_para.fault_time_stamp = sdk_tick_get();
        
        tx_frame_id.bit.src_addr = BCU_INNER_CAN_ADDR;
        tx_frame_id.bit.src_type = DEV_BCU;
        tx_frame_id.bit.dst_addr = BROCAST_DEVICE_ADDRESS;
        tx_frame_id.bit.dst_type = DEV_BMU;
        tx_frame_id.bit.fun_code = FUNC_MASTER_CTL_CMD;
        tx_frame_id.bit.prio = SOFAR_CAN_PRI_LOW_H;

        data[0] = BROCAST_DEVICE_ADDRESS; // 广播
        data[1] = CAN_SET_ADDR_STORE_CMD; // 设置从机状态
        data[2] = 0;
        can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_frame_id.id_val, data, 3);
        log_d("[ADD]store msg cnt:%d\n",g_inn_addr_para.addr_store_send_cnt);
    }

    if (g_inn_addr_para.addr_store_send_cnt > STORE_TIME)
    {
        auto_addressing_disable();
        event = EVT_ADDR_STA_CPL_SUC;
    }
    
    return event;
}

/**
 * @brief   外网CAN(bcu)，自动编址完成状态进入处理
 * @param   无
 * @return  返回执行结果 0:正常；<0:异常
 * @warning	无
 */
static uint8_t sta_master_addr_failed_run(void)
{
    uint8_t event = EVT_ADDR_STA_CPL_SUC;
    g_inn_addr_para.pack_num = 0;
    g_inn_addr_para.addr_abnormal_cnt++;
    g_inn_addr_para.addr_state = ADDRESSING_ING; // 编址中 
    
    if(g_inn_addr_para.addr_abnormal_cnt > AUTO_ADDR_ABNORMAL_MAX_NUM)  //连续编址失败大于5次，则等待下一次重新启动编址
    {
        auto_addressing_disable();     
        g_inn_addr_para.addr_state = ADDRESSING_DISENABLE; //        
        log_e("inner addr failed time:%d\r\n",g_inn_addr_para.addr_abnormal_cnt);
        event = EVT_ADDR_FAULT;
    }

    return event;
}

static void inner_auto_addr_can_register(void)
{
//	uint16_t rec_msg_amount = 0;
//    can_frame_id_u frame_id[] = 
//    {
//        // res     prio(优先级)      type(帧类型)  flag（1:连续，0:非）, fun_code,    dst_type dst_addr, src_type, src_addr
//        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_HEAT, .bit.type= SOFAR_CAN_DATA,   .bit.flag= 0, .bit.fun_code= FUN_HEAT_BEAT,
//         .bit.dst_type= 0, .bit.dst_addr= 0, .bit.src_type= DEV_BMU, .bit.src_addr =0}, // 0x197f00a0
//    };
//	can_sofar_rcv_reg_t can_rxmsg_tab[] = // 接收上位机或BCU的数据
//	{
//        {frame_id[0].id_val, 0x0000FFFF, inner_addr_rcv_callback},  // 0x197f00a0 BMU上送心跳数据处理,广播所有设备，A0：源设备类型，设备地址1~10
//	};	
//	// 注册接收的数据
//	rec_msg_amount = sizeof(can_rxmsg_tab)/sizeof(can_sofar_rcv_reg_t);
//	can_sofar_register_receive_frame(SDK_INTERNAL_CAN_PORT, can_rxmsg_tab, rec_msg_amount);
}

/**
 * @brief   内网CAN(bmu/bcu)，发送自动编址控制指令
 * @param   无
 * @return  0:发送成功，-1：发送失败
 * @warning	无
 */
static int32_t send_addr_msg(msg_t *msg)
{
    uint8_t data[8] = {0};
    can_frame_id_u tx_frame_id = {0};
    uint8_t master_state = NON_CAN_ADDR_SET_CMD;
    uint8_t set_addr = BROCAST_DEVICE_ADDRESS;
    // THIS_LOGD("send addr msg cmd=%d, src=%d, dst=%d, data=%d\n", msg->cmd, msg->src_addr, msg->dst_addr, msg->data);
    switch (msg->cmd)
    {
        case CMD_START_ADDRESSING:
            master_state = CAN_SET_START_ADDR_CMD;
            break;
        case CMD_SET_OUTPUT:
            if (msg->data)
            {
                master_state = CAN_ADDR_SET_IO_HIGH_CMD;
            }
            else
            {
                master_state = CAN_ADDR_SET_IO_LOW_CMD;
            }
            break;
        case CMD_SET_SLAVE_ADDR:
            master_state = CAN_SET_ADDR_CMD;
            set_addr = msg->data;
            break;
        default:
            return -1;
    }
    tx_frame_id.bit.src_addr = msg->src_addr;
    tx_frame_id.bit.src_type = DEV_BCU;
    tx_frame_id.bit.dst_addr = msg->dst_addr;
    tx_frame_id.bit.dst_type = DEV_BMU;
    tx_frame_id.bit.fun_code = FUNC_MASTER_CTL_CMD;
    tx_frame_id.bit.prio = SOFAR_CAN_PRI_LOW_H;

    data[0] = set_addr; // 设置地址
    data[1] = master_state; // 设置从机状态
    data[2] = 0;
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_frame_id.id_val, data, 3);
    return 0;
}

/**
 * @brief 判断接收到应答消息
 * @param recv_msg 期望接收到的信息
 * @param over_time 超时时间
 * @return -1超时、0未接收到消息、1接收到正确消息
 */
static int32_t addr_cmd_reply_check(uint32_t over_time)
{
    if (g_reply_msg_state.cmd_reply_state)
    {
        memset(&g_reply_msg_state, 0, sizeof(reply_msg_state_t)); // 判断完成后，清空接收判断变量
        return 1;
    }
    else
    {
        g_reply_msg_state.reply_over_time_cnt++;
        if (g_reply_msg_state.reply_over_time_cnt >= over_time)
        {
            memset(&g_reply_msg_state, 0, sizeof(reply_msg_state_t));
            return -1;
        }
    }
    return 0;
}

static void can_convert_to_addr_msg(uint32_t can_id, uint8_t *p_data, msg_t* addr_msg, uint8_t len)
{
    if ((addr_msg == NULL) && (p_data == NULL))
    {
        return;
    }
    can_frame_id_u can_frame_id = {can_id};
    addr_msg->src_addr = can_frame_id.bit.src_addr;
    addr_msg->dst_addr = can_frame_id.bit.dst_addr;
    addr_msg->src_type = can_frame_id.bit.src_type;
    addr_msg->dst_type = can_frame_id.bit.dst_type;
    if (can_frame_id.bit.fun_code == FUNC_SLAVER_CTL_REPLY)
    {
//        if (len < 3)    // 控制帧有3个数据
//        {
//            return;
//        }
        addr_msg->sleep_cmd = p_data[2]; // bmu休眠请求,当前不使用
        switch (p_data[1])
        {
            case CAN_RX_SLA_SET_START_ADDR_CMD:
                addr_msg->cmd = CMD_REQUEST;
                addr_msg->data = 1;
                break;
            case CAN_RX_SLA_SET_ADDR_CMD:
                addr_msg->cmd = CMD_SET_SLAVE_ADDR;
                addr_msg->data = p_data[0];   // 设置完成地址
                break;
            case CAN_RX_SLA_ADDR_SET_IO_HIGH_CMD:
                addr_msg->data = 1;  // 高电平
                addr_msg->cmd = CMD_SET_OUTPUT;
                break;
            case CAN_RX_SLA_ADDR_SET_IO_LOW_CMD :
                addr_msg->data = 0;  // 低电平
                addr_msg->cmd = CMD_SET_OUTPUT;
                break;
            case CAN_RX_SLA_ADDR_CONFLICT_CMD:
                addr_msg->cmd = CMD_CONFLICT;
                break;
            default:
                break;
        }
    }
    else if (can_frame_id.bit.fun_code == FUNC_HEART_BEAT_CMD)
    {
        addr_msg->cmd = CMD_HEARTBEAT;
    }
    else if (can_frame_id.bit.fun_code == FUNC_BMS_REMOTE_SIGNAL_INFO1)
    {
        addr_msg->cmd = CMD_DI_CHECK;
        addr_msg->data = p_data[6];
    }  
}

static void if_rcv_addr_cmd_reply(msg_t *p_rcv_msg)
{
    if(g_reply_msg_state.need_reply_flag == 1)
    {
        if ((g_reply_msg_state.expect_rcv_msg.src_addr == p_rcv_msg->src_addr) &&
            (g_reply_msg_state.expect_rcv_msg.dst_addr == p_rcv_msg->dst_addr) &&
            (g_reply_msg_state.expect_rcv_msg.cmd == p_rcv_msg->cmd) &&
            (g_reply_msg_state.expect_rcv_msg.data == p_rcv_msg->data))    // 回复data为结果描述符，设置地址与是否一致
        {
            g_reply_msg_state.cmd_reply_state = 1;
        }
    }

}

static void inner_can_heartbeat_proc(msg_t *p_rcv_msg)
{
    if ((p_rcv_msg->src_addr == BCU_INNER_CAN_ADDR) && (p_rcv_msg->src_type == DEV_BCU)) // 发现地址冲突
    {
        g_inn_addr_para.address_conflict_flag = 1;
        THIS_LOGE("[ADD]bcuAddrCft\n");
    }
    if (p_rcv_msg->src_type == DEV_BMU)    // BMU的心跳报文才判断
    {
        if (p_rcv_msg->src_addr > g_inn_addr_para.pack_num)
        {
            g_inn_addr_para.have_pack_on_addressing = 1;
        }
        // 主机有接到从机的心跳
        if ((1 <= p_rcv_msg->src_addr) && (p_rcv_msg->src_addr <= g_inn_addr_para.pack_num))
        {
            g_pack_comm_status[p_rcv_msg->src_addr - 1].unlink_time_cnt = 0;
        }
    }
}

static void inner_can_conflict_proc(msg_t *p_rcv_msg)
{
    static uint8_t last_id = 0;
    if ((p_rcv_msg->dst_addr == BCU_INNER_CAN_ADDR) && (p_rcv_msg->dst_type == DEV_BCU)) // 从机报告地址冲突
    {
        g_inn_addr_para.address_conflict_flag = 1;
        if(last_id != p_rcv_msg->src_addr)
        {
            THIS_LOGE("[ADD]bmuAddr:%d Cft\n",p_rcv_msg->src_addr);   
            last_id = p_rcv_msg->src_addr;    
        }

    }
}

// 检测编址io电平是否ok
static void inner_can_addr_pin_check_proc(msg_t *p_rcv_msg)
{
    if ((p_rcv_msg->dst_addr == BCU_INNER_CAN_ADDR) && (p_rcv_msg->dst_type == DEV_BCU))
    {
        uint16_t pin_status = (p_rcv_msg->data) & (0x0001);
        if ((ADDRESSING_PIN_STATUS) == pin_status)
        {
            g_pack_addr_pin_state_flag = true;
            g_pack_addr_default_pin_timer_cnt = 0;
        }
    }
}

static void slave_addr_request_proc(msg_t *p_rcv_msg)
{
    if ((p_rcv_msg->dst_addr == BCU_INNER_CAN_ADDR) && (p_rcv_msg->dst_type == DEV_BCU))
    {
        if ((g_inn_addr_para.addr_state == ADDRESSING_FINISH) && (p_rcv_msg->data == 1))
        {
            g_inn_addr_para.have_pack_on_addressing = 1;
            THIS_LOGD("[ADD]packOnAddrSet\n");
        }
    }
}

/**
 * @brief   内网CAN(bmu/bcu)，从机自动编址回复消息处理函数
 * @param   无
 * @return  无
 * @warning	无
 */
static void inner_addr_rcv_msg(msg_t *p_rcv_msg)
{
    if (p_rcv_msg == NULL)
    {
        return;
    }
    if_rcv_addr_cmd_reply(p_rcv_msg);

    switch (p_rcv_msg->cmd)
    {
        case CMD_REQUEST:
            slave_addr_request_proc(p_rcv_msg);
            break;
        case CMD_HEARTBEAT:
            inner_can_heartbeat_proc(p_rcv_msg);
            break;
        case CMD_CONFLICT:
            inner_can_conflict_proc(p_rcv_msg);
            break;
        case CMD_DI_CHECK:
            inner_can_addr_pin_check_proc(p_rcv_msg);
            break;
        default:
            break;
    }
}

/**
 * @brief   内网CAN(bmu/bcu)，定时广播心跳包，用于检测地址冲突与从机失联
 * @param   无
 * @return  无
 * @warning	无
 */
static void send_heartbeat(void)
{
    can_frame_id_u tx_frame_id = {0};
    uint8_t data[8] = {0};
    static uint32_t timestamp = 0;
    if (sdk_is_tick_over(timestamp, os_tick_from_millisecond(1000)))
    { // 广播心跳包
        timestamp = sdk_tick_get();
        tx_frame_id.bit.src_addr = BCU_INNER_CAN_ADDR;
        tx_frame_id.bit.src_type = DEV_BCU;
        tx_frame_id.bit.dst_addr = BROCAST_DEVICE_ADDRESS;
        tx_frame_id.bit.dst_type = DEV_BROADCAST;
        tx_frame_id.bit.fun_code = FUNC_HEART_BEAT_CMD;
        tx_frame_id.bit.prio = SOFAR_CAN_PRI_LOW_H;
        // 心跳内容
//        data[0] = PRODUCT_BAT_BIG_TYPE;
//        data[1] = LOW_BYTE(BAT_PRODUCT_CBS5K_BCU);
//        data[2] = HIGH_BYTE(BAT_PRODUCT_CBS5K_BCU);
//        data[3] = EXT_SOFAR_HIGH_VOLT_STACK_PROTOCOL;
        //THIS_LOGD("send heartbeat\n");
        can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, tx_frame_id.id_val, data, 4);
    }
}

/**
 * @brief   内网CAN(bmu/bcu)，定时广播心跳包，用于检测从机通信超时
 * @param   无
 * @return  无
 * @warning	无
 */
static void check_pack_comm_status(void)
{
    if (g_inn_addr_para.addr_state == ADDRESSING_FINISH && 
        (UPG_MASTER_IDLE == upgrade_master_state_get() || UPG_MASTER_ING == upgrade_master_state_get()))
    {
        for (int i = 0; i < g_inn_addr_para.pack_num; i++)
        {
            if (++g_pack_comm_status[i].unlink_time_cnt >= 500) //持续5S通讯失联，则置位
            {
                if (g_inn_addr_para.fault_pack_unlink == 0)
                {
                    log_e("[ADD]P%dUnlin\n", i);
                }
                g_inn_addr_para.fault_pack_unlink = 1;
                return;
            }
        }
        if (g_inn_addr_para.fault_pack_unlink)
        {
            log_e("[ADD]link\n");
        }
        g_inn_addr_para.fault_pack_unlink = 0;
    }
}

/**
 * @brief  获取自动编址状态
 * @return 自动编址状态
 */
auto_addressing_state_e auto_addressing_get_state(void)
{
    return g_inn_addr_para.addr_state;
}

/**
 * @brief  获取自动编址故障
 * @return AUTO_ADDRESSING_NO_FAULT     没故障
 * @return AUTO_ADDRESSING_ID_CONFLICT  通讯ID冲突
 * @return AUTO_ADDRESSING_COMM_FAIL    通讯故障
 */
uint8_t auto_addressing_fault_get(void)
{
    uint8_t error = AUTO_ADDRESSING_NO_FAULT;
    static uint8_t last_err_flag = AUTO_ADDRESSING_NO_FAULT;
    // 通讯故障
    if (g_inn_addr_para.fault_pack_num_mismatch        // 电池包编址数目与预设数量不匹配
        || g_inn_addr_para.fault_pack_unlink         // 有电池包失联
        || g_inn_addr_para.fault_pack_on_addressing) // 有电池包没有被编址
    {
        error = AUTO_ADDRESSING_COMM_FAIL;
    }
    // 地址冲突
    if (g_inn_addr_para.fault_id_conflict)
    {
        error = AUTO_ADDRESSING_ID_CONFLICT;
    }
    // 内can编址异常
    if (g_inn_addr_para.addr_abnormal_cnt > AUTO_ADDR_ABNORMAL_MAX_NUM)
    {
        g_inn_addr_para.addr_abnormal_cnt = AUTO_ADDR_ABNORMAL_MAX_NUM + 1;  // 防止越界
        error = AUTO_ADDRESSING_ABNORMAL_FAIL;
    }
    // 电平控制异常
    if (g_check_pin_state.start_pin_err_cnt >= ADDR_PIN_CHECK_ERR_TIME)
    {
        g_check_pin_state.start_pin_err_cnt = ADDR_PIN_CHECK_ERR_TIME + 1;  // 防止越界
        error = AUTO_ADDRESSING_PIN_FAIL;
    }
    if (last_err_flag != error)
    {
        THIS_LOGE("[ADD]errTy=%d\n", error);
    }
    last_err_flag = error;
    return error;
}

/**
 * @brief  获取编址地址
 * @retval =0     未完成编址
 * @retval 1~0x0F 有效地址
 */
uint8_t auto_addressing_get_address(void)
{
    return BCU_INNER_CAN_ADDR;
}

/**
 * @brief  获取PACK数量
 * @retval 1~N 有效的PACK数量
 * @retval 0 获取失败
 * @pre    只有编址完成后，才能正确获取PACK数量
 */
uint8_t auto_addressing_pack_num_get(void)
{
    if (g_inn_addr_para.addr_state == ADDRESSING_FINISH)
    {
        return g_inn_addr_para.pack_num;
    }
    else
    {
        return 0;
    }    
}

/**
 * @brief  电池包数目异常标志
 * @retval true 数量异常
 * @retval false 无异常
 * @pre    只有编址完成后，才能判断电池包数量
 */
uint32_t addressing_pack_num_abnormal_get(void)
{
    if (g_inn_addr_para.addr_state != ADDRESSING_FINISH)
    {
        return false;
    }
    if (g_inn_addr_para.pack_num < PACK_MIN_NUM || g_inn_addr_para.pack_num > PACK_MAX_NUM)
    {
        return true;
    }
    return false; 
}

/**
 * @brief  使能自动编址，自动编址完成后再使能，会重新自动编址
 * @return 无
 */
void auto_addressing_enable(void)
{
    g_inn_addr_para.auto_addressing_enable = 1;
}

/**
 * @brief  失能自动编址
 * @return 无
 */
void auto_addressing_disable(void)
{
    g_inn_addr_para.auto_addressing_enable = 0;
}

/**
 * @brief   内网CAN(bmu/bcu)，自动编址初始化
 * @param   无
 * @return  返回执行结果 0:正常；<0:异常
 * @warning	无
 */
void inner_auto_addr_init(void)
{
    auto_addressing_disable();
    g_inn_addr_para.addr_state = ADDRESSING_DISENABLE; // 未使能自动编址
    state_machine_init(&g_auto_addr_fsm, g_auto_addr_fsm_name, g_addr_act_map, (uint8_t *)g_addr_evt_sta_map,
        ADDR_EVT_NUM, ADDR_STA_NUM, STA_ADDR_INIT);
    inner_auto_addr_can_register();
    g_check_pin_state.check_pin_err_cnt = 0;
    g_check_pin_state.start_pin_err_cnt = 0;
//    auto_addressing_enable();    // 启动自动编址（暂时放这，后续在BMU处于开机状态时打开）
}

/**
 * @brief   内网CAN(bmu/bcu)，自动编址处理函数 10ms调用一次
 * @param   无
 * @return  无
 * @warning	无
 */
void inner_auto_addressing_proc(void)
{
    uint8_t event;
    event = state_machine_proc(&g_auto_addr_fsm);
    fsm_state_trans(&g_auto_addr_fsm, event);
    pack_addr_di_default_pin_check();
}

/**
 * @brief   内网CAN(bmu/bcu)，从机自动编址回复CAN消息处理回调函数
 * @param   无
 * @return  无
 * @warning	无
 */
bool inner_addr_rcv_callback(can_frame_data_t *can_data, uint16_t func_code)
{
    if (can_data == NULL)
    {
        return -1;
    }
    msg_t addr_msg;
    can_convert_to_addr_msg(can_data->id, can_data->data, &addr_msg, can_data->data_len);
    // THIS_LOGD("rcv addr msg cmd=%d, data=%x\n", addr_msg.cmd, addr_msg.data);
    inner_addr_rcv_msg(&addr_msg);
    return 0;
}

/**
 * @brief                内网编址调试接口
 * @return               返回结果空
 * @warning              测试调试使用
 */
int32_t inner_addr(int argc, char *argv[])
{
    if (argc < 2)
    {
        log_d("innerAddrErr\n");
        return SF_ERR_PARA;
    }
    if (!strcmp(argv[1], "print"))
    {
        log_d("[ADDR]enable:%d,state:%d,pack_num:%d,set_num:%d\n",g_inn_addr_para.auto_addressing_enable, 
              g_inn_addr_para.addr_state,g_inn_addr_para.pack_num,get_bms_attr()->clu_pack_num);
        log_d("[ADDR]fault: id_conflict:%d,pack_unlink:%d,pack_on_addressing:%d,pack_num_mismatch:%d\n", 
              g_inn_addr_para.fault_id_conflict,g_inn_addr_para.fault_pack_unlink, 
              g_inn_addr_para.fault_pack_on_addressing,g_inn_addr_para.fault_pack_num_mismatch);
    }
    else if (!strcmp(argv[1], "start"))
    {
        auto_addressing_enable();
    }
    else
    {
        return -1;
    }
    return 0;
}

MSH_CMD_EXPORT(inner_addr, <print/start>);
