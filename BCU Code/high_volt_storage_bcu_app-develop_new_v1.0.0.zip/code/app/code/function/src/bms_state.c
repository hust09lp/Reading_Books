#include <stdlib.h>
#include "sdk.h"
#include "sdk_key.h"
//#include "sdk_buzzer.h"
#include "sdk_public.h"
#include "bms_state.h"
#include "fault_manage.h"
#include "relay_manage.h"
#include "upgrade.h"
#include "auto_addressing.h"
//#include "soc_estimation.h"
//#include "soh_estimation.h"
#include "sop.h"
#include "data_store.h"
#include "led.h"
//#include "ate.h"
//#include "beep.h"
#include "inner_can_data.h"
#include "external_can_data.h"
#include "insulation_impedance_calc.h"
#include "sample.h"
#include "app_public.h"
#include "sox.h"
#include "data_store.h"
#include "ate.h"
#include "bmu_data.h"
#include "upgrade_master.h"
#include "file_read.h"
#include "state_machine.h"

#define BMS_STATE_LOGD(...) sdk_log_d(__VA_ARGS__)

#define DELAY_30S_BASE_10MS  	3000
#define DELAY_1S_BASE_10MS  	100
#define DELAY_500MS_BASE_10MS  	50

#define KEY_3S_BASE_100MS  		30
#define KEY_500MS_BASE_100MS  	5
#define BEEP_3S_BASE_100MS  	30
#define BEEP_1S_BASE_100MS  	10
#define BEEP_500MS_BASE_100MS  	5
#define BEEP_100MS_BASE_100MS  	1

#ifdef BMS_STATE_SHELL_DEBUG_TEST
static bool g_bms_state_shell_debug = false;
static bms_system_state_e g_bms_sys_display_state_debug = BCU_STATE_INIT; // 外部bcu系统状态， BMS系统运行状态
static uint8_t g_force_open_bmu_power_debug_flag = false;                 // 强制bmu开机
#endif

static fault_stat_data_t g_fault_data = {0};
static sample_data_t g_sys_sample_data = {0};

static uint8_t g_bat_mode = BMS_STANDY_MODE;             // 电池状态
static uint8_t g_bms_sys_step_state = BMS_WAKE_CHECK;    // 内部bcu系统状态， BMS系统运行步骤
static uint8_t g_bms_sys_display_state = BCU_STATE_INIT; // 外部bcu系统状态， BMS系统运行状态

#define BMU_POW_ON() sdk_dido_write(DO_4_BMU_POWER, 1)                  // 高电平关断BMU
#define BMU_POW_OFF() sdk_dido_write(DO_4_BMU_POWER, 0)                 // 低电平关断BMU
#define BCU_WAKEUP_CHARGE() (sdk_dido_read(DI_15_CHG_WAKE_IN) == 0)     // 充电唤醒，低电平有效
#define BCU_WAKEUP_ADDR() (sdk_dido_read(DI_13_CLUSTER_IN) == 0)        // 编址唤醒，低电平有效
#define BCU_WAKEUP_DRY_POINT() (sdk_dido_read(DI_10_DRY_CONTACT1) == 0) // 干结点唤醒，低电平有效

#define AIR_SW_OPEN() sdk_dido_write(DO_9_TRIP_CTRL, 1) // 高电平断开空开

/********************************BCU系统状态机处理函数声明****************************************/
static uint8_t sta_bms_start_up_entry(void);
static uint8_t sta_bms_start_up_run(void);
static uint8_t sta_bms_self_check_entry(void);
static uint8_t sta_bms_self_check_run(void);
static uint8_t sta_bms_normal_entry(void);
static uint8_t sta_bms_normal_run(void);
static uint8_t sta_bms_pf_error_entry(void);
static uint8_t sta_bms_pf_error_run(void);
static uint8_t sta_bms_upgrade_entry(void);
static uint8_t sta_bms_upgrade_run(void);
// 初始化接口声明
static void bms_sys_step_state_init(void);

/********************************预充状态机使用变量定义****************************************/
static fsm_action_map_t g_bms_sta_act_map[BMS_STA_NUM] = 
{
    [BMS_START_UP]          = {sta_bms_start_up_entry, sta_bms_start_up_run},           // 系统开机
    [BMS_SELF_CHECK]        = {sta_bms_self_check_entry, sta_bms_self_check_run},       // 系统开机自检
    [BMS_NORMAL]            = {sta_bms_normal_entry, sta_bms_normal_run},               // 系统正常运行
    [BMS_PF_ERROR]          = {sta_bms_pf_error_entry, sta_bms_pf_error_run},           // 系统故障
    [BMS_UPGRADE]           = {sta_bms_upgrade_entry, sta_bms_upgrade_run},             // 系统升级过程
};

static uint8_t g_bms_sta_evt_map[BMS_STA_NUM][EVT_BMS_STA_NUM] = 
{                           // EVT_BMS_START_UP   EVT_BMS_NORMAL    EVT_BMS_PF_ERROR   EVT_BMS_UPGRADE
    [BMS_START_UP]          = {BMS_SELF_CHECK,    STA_NULL,         STA_NULL,          STA_NULL,      },
    [BMS_SELF_CHECK]        = {STA_NULL,          BMS_NORMAL,       BMS_PF_ERROR,      BMS_UPGRADE,   },
    [BMS_NORMAL]            = {STA_NULL,          STA_NULL,         BMS_PF_ERROR,      BMS_UPGRADE,   },
    [BMS_PF_ERROR]          = {STA_NULL,          BMS_NORMAL,       STA_NULL,          BMS_UPGRADE,   },
    [BMS_UPGRADE]           = {BMS_SELF_CHECK,    BMS_NORMAL,       BMS_PF_ERROR,      STA_NULL,      },
};

static state_machine_t g_bms_sys_sta_fsm = {0};
static const char *g_bms_sys_sta_fsm_name = "bcuState";
static uint32_t g_start_up_delay_tick = 0;      // 开机tick
static uint32_t g_self_check_tick = 0;          // 自检tick
static uint32_t g_reset_delay_tick = 0;         // 复位tick
static bool g_dcdc_exit_flag = false;           // 默认dcdc不存在
static bool g_self_check_finished_flag = false; // bms自检完成标志
//static uint8_t g_sleep_lock_id = 0;
/**
 * @brief		can自动发送处理
 * @param		无
 * @return		无
 * @retval		状态切换函数后条用
 */
void can_auto_send_ctrl(void)
{
    bms_system_step_e sys_step = bms_state_get_sys_step();
    if (BMS_SELF_CHECK > sys_step)
    {
        auto_send_can_ext_func_set(EXT_AUTO_SEND_FORBID_TYPE);   // 关闭外CAN自动发送
        auto_send_can_inner_func_set(INN_AUTO_SEND_FORBID_TYPE); // 关闭内CAN自动发送
        return;
    }
    uint8_t upgare_flag = (sys_step == BMS_UPGRADE);
    // 自检过程，运行过程，故障过程使能外can自动发送
    if (upgare_flag)
    {
        auto_send_can_ext_func_set(EXT_AUTO_SEND_SLOW_TYPE); // 缓慢外CAN自动发送
    }
    else
    {
        auto_send_can_ext_func_set(EXT_AUTO_SEND_NORMAL_TYPE);
    }

    if (ADDRESSING_FINISH != auto_addressing_get_state() || upgare_flag)
    {
        auto_send_can_inner_func_set(INN_AUTO_SEND_SLOW_TYPE); // 缓慢内CAN自动发送
    }
    else
    {
        auto_send_can_inner_func_set(INN_AUTO_SEND_NORMAL_TYPE);
    }
}
/**
 * @brief		初始化
 * @param		无
 * @return		无
 * @retval		无
 * @warning		无
 */
void bms_state_init(void)
{
    g_bat_mode = BMS_STANDY_MODE;

    // 配置应用休眠设置
//    sdk_pm_enable(100, 0);
//    g_sleep_lock_id = sdk_pm_get_lock_id();
//    sdk_pm_lock(g_sleep_lock_id);

    // 系统状态流程初始化
    bms_sys_step_state_init();
}

/**
 * @brief		更新电池数据
 * @param		无
 * @return		无
 * @retval		无
 * @warning		无
 */
void bms_state_data_sync(void)
{
    const fault_stat_data_t *p_fault_data = NULL;
    p_fault_data = fault_chg_dsg_level_get();
    g_fault_data = *p_fault_data;
    g_sys_sample_data = *p_sample_data_get();
}

/**
 * @brief		永久性故障检测
 * @param		无
 * @return		返回结果
 * @retval		[out]出现永久性故障：true,  无永久性故障：false
 * @warning		无
 */
uint8_t pf_error_check(void)
{
    uint8_t ret = false;

    if (g_fault_data.max_charge_level <= LEVEL1
        || g_fault_data.max_discharge_level <= LEVEL1)
    {
        ret = true;
    }
    else
    {
        ret = false;
    }

    return ret;
}

/**
 * @brief		电池模式切换流程
 * @param		[in] 输入系统电流值单位mA
 * @return		无
 * @retval		无
 * @warning		无
 */
void bms_state_switch_bat_mode_proc(int32_t sys_current)
{
    static uint8_t charge_duration_cnt = 0;    // 充电持续时间
    static uint8_t discharge_duration_cnt = 0; // 放电持续时间
    static uint8_t standby_duration_cnt = 0;   // 待机持续时间

    switch (g_bat_mode)
    {
    case BMS_STANDY_MODE:
    {
        if (sys_current > ENTER_CHARGE_CURR) // 电流值 > 进入充电模式电流
        {
            (discharge_duration_cnt > 0) ? (discharge_duration_cnt--) : (discharge_duration_cnt = 0);

            if (++charge_duration_cnt > DELAY_500MS_BASE_10MS)
            {
                charge_duration_cnt = DELAY_500MS_BASE_10MS;
                g_bat_mode = BMS_CHARGE_MODE;
            }
        }
        else if (sys_current < ENTER_DISCHARGE_CURR) // 电流值  < 进入放电模式电流
        {
            (charge_duration_cnt > 0) ? (charge_duration_cnt--) : (charge_duration_cnt = 0);

            if (++discharge_duration_cnt > DELAY_500MS_BASE_10MS)
            {
                discharge_duration_cnt = DELAY_500MS_BASE_10MS;
                g_bat_mode = BMS_DISCHARGE_MODE;
            }
        }
        else
        {
            (charge_duration_cnt > 0) ? (charge_duration_cnt--) : (charge_duration_cnt = 0);
            (discharge_duration_cnt > 0) ? (discharge_duration_cnt--) : (discharge_duration_cnt = 0);
        }
        standby_duration_cnt = 0;

        break;
    }
    case BMS_CHARGE_MODE:
    {
        if (sys_current < ENTER_DISCHARGE_CURR)
        {
            (standby_duration_cnt > 0) ? (standby_duration_cnt--) : (standby_duration_cnt = 0);

            if (++discharge_duration_cnt > DELAY_500MS_BASE_10MS)
            {
                discharge_duration_cnt = DELAY_500MS_BASE_10MS;
                g_bat_mode = BMS_DISCHARGE_MODE;
            }
        }
        else if (sys_current < EXIT_CHARGE_CURR)
        {
            (discharge_duration_cnt > 0) ? (discharge_duration_cnt--) : (discharge_duration_cnt = 0);
            if (++standby_duration_cnt > DELAY_500MS_BASE_10MS)
            {
                standby_duration_cnt = DELAY_500MS_BASE_10MS;
                g_bat_mode = BMS_STANDY_MODE;
            }
        }
        else
        {
            (standby_duration_cnt > 0) ? (standby_duration_cnt--) : (standby_duration_cnt = 0);
            (discharge_duration_cnt > 0) ? (discharge_duration_cnt--) : (discharge_duration_cnt = 0);
        }
        charge_duration_cnt = 0;

        break;
    }
    case BMS_DISCHARGE_MODE:
    {
        if (sys_current > ENTER_CHARGE_CURR)
        {
            (standby_duration_cnt > 0) ? (standby_duration_cnt--) : (standby_duration_cnt = 0);
            if (++charge_duration_cnt > DELAY_500MS_BASE_10MS)
            {
                charge_duration_cnt = DELAY_500MS_BASE_10MS;
                g_bat_mode = BMS_CHARGE_MODE;
            }
        }
        else if (sys_current > EXIT_DISCHARGE_CURR)
        {
            (charge_duration_cnt > 0) ? (charge_duration_cnt--) : (charge_duration_cnt = 0);

            if (++standby_duration_cnt > DELAY_500MS_BASE_10MS)
            {
                standby_duration_cnt = DELAY_500MS_BASE_10MS;
                g_bat_mode = BMS_STANDY_MODE;
            }
        }
        else
        {
            (standby_duration_cnt > 0) ? (standby_duration_cnt--) : (standby_duration_cnt = 0);
            (charge_duration_cnt > 0) ? (charge_duration_cnt--) : (charge_duration_cnt = 0);
        }
        discharge_duration_cnt = 0;
        break;
    }
    default:
    {
        g_bat_mode = BMS_STANDY_MODE;
        standby_duration_cnt = 0;
        charge_duration_cnt = 0;
        discharge_duration_cnt = 0;
        break;
    }
    }
}

/**
 * @brief		获取电池状态
 * @param		无
 * @return		电池充放电状态
 * @retval		待机:BMS_STANDY_MODE
 * @retval		充电:BMS_CHARGE_MODE
 * @retval		放电:BMS_DISCHARGE_MODE
 * @warning		无
 */
battery_state_e bms_state_get_bat_sta(void)
{
    return (battery_state_e)g_bat_mode;
}

/**
 * @brief		升级状态检测
 * @param		无
 * @return		sys_shut_down_type
 * @retval		按键关机优先级最高，最后置位
 * @warning		无
 */
static bool check_sys_upgrade_flag(void)
{
    uint16_t bmu_upgrage_flag = 0;
    const bmu_data_unify_t *p_bmu_data_unify = bmu_data_unify_get();

    if (p_bmu_data_unify != NULL)
    {
        bmu_upgrage_flag = p_bmu_data_unify->bmu_upg_sta;
    }

    if ((UPG_IDLE != upgrade_state_get()) || 0 != bmu_upgrage_flag || (UPG_MASTER_IDLE != upgrade_master_state_get()))
    {
        return true;
    }
    else
    {
        return false;
    }
}



// 系统开机
static uint8_t sta_bms_start_up_entry(void)
{
    g_bms_sys_display_state = BCU_STATE_SELF_CHECK;
    g_bms_sys_step_state = BMS_START_UP;

    // 故障检测使能
    fault_diag_enable();
    // 绝缘阻抗检测初始化和启动
    insulation_impedance_calc_init();

    // 开机运行前初始化
//    auto_addressing_enable(); // 启动自动编址 TODO BCU编址启动后续添加
    g_start_up_delay_tick = sdk_tick_get();
    led_display_func_disable(false); // 放开led灯控制

    return EVT_NULL;
}

static uint8_t sta_bms_start_up_run(void)
{
    uint8_t event = EVT_NULL;
    // 等待数据稳定等待1s
    if (true == sdk_is_tick_over(g_start_up_delay_tick, os_tick_from_millisecond(1000)))
    {
        g_start_up_delay_tick = sdk_tick_get();
        insulation_impedance_calc_start();  //等待有电压后启动绝缘检测
        event = EVT_BMS_START_UP;
        BMS_STATE_LOGD("[STA]start2self\n");
    }

    return event;
}

// 系统自检
static uint8_t sta_bms_self_check_entry(void)
{
    g_bms_sys_display_state = BCU_STATE_SELF_CHECK;
    g_bms_sys_step_state = BMS_SELF_CHECK;
    upgrade_enable_state_set(true); // bcu使能升级
    g_self_check_tick = sdk_tick_get();
    g_self_check_finished_flag = false;

    return EVT_NULL;
}

static uint8_t sta_bms_self_check_run(void)
{
    auto_addressing_state_e auto_addr_state = auto_addressing_get_state();
    fault_diag_step_e fault_diag_step = fault_diag_step_get();
    uint8_t event = EVT_NULL;

    if (ADDRESSING_FINISH == auto_addr_state) // 内can编址完成
    {
        uint16_t bmu_pf_error_flag = 0;
        const bmu_data_unify_t *p_bmu_data_unify = bmu_data_unify_get();
        if (p_bmu_data_unify != NULL)
        {
            bmu_pf_error_flag = p_bmu_data_unify->bmu_err_sta;
        }
        if ((POWER_ON_SELF_TEST < fault_diag_step) &&
            (insulation_impedance_check_result_get() > INSULATION_IMPEDANCE_CHECKING) &&
            (0 != bmu_pf_error_flag || true == sdk_is_tick_over(g_self_check_tick, os_tick_from_millisecond(2000)))) // 等待开机自检完成和编址完成，并且BMU自检完成或者超时2s，
        {
            g_self_check_finished_flag = true;
            if (bmu_pf_error_flag)
            {
                event = EVT_BMS_PF_ERROR;
                BMS_STATE_LOGD("[STA]self2err\n");
            }
            else if (false == pf_error_check())
            {
                event = EVT_BMS_NORMAL;
                BMS_STATE_LOGD("[STA]self2run\n");
            }
        }
    }
    else
    {
        g_self_check_tick = sdk_tick_get();
    }
    // 防止编址一直无法成功，无法跳转状态
    if (check_sys_upgrade_flag()) // 自检过程预留升级接口
    {
        event = EVT_BMS_UPGRADE;
        BMS_STATE_LOGD("[STA]self2upg\n");
    }
    else if (pf_error_check()) // 判断出现故障，则进入BMS_ERR，等待系统关机
    {
        event = EVT_BMS_PF_ERROR;
        BMS_STATE_LOGD("[STA]self2err\n");
    }

    return event;
}

static uint8_t sta_bms_normal_entry(void)
{
    g_bms_sys_display_state = BCU_STATE_RUN;
    g_bms_sys_step_state = BMS_NORMAL;
    relay_manage_enable_set(true); // 恢复继电器控制

    return EVT_NULL;
}

static uint8_t sta_bms_normal_run(void)
{
    uint8_t event = EVT_NULL;
    uint16_t bmu_pf_error_flag = 0;
    uint16_t bmu_pf_upg_flag = 0xFFFF;
    const bmu_data_unify_t *p_bmu_data_unify = bmu_data_unify_get();
    if (p_bmu_data_unify != NULL)
    {
        bmu_pf_error_flag = p_bmu_data_unify->bmu_err_sta;
        bmu_pf_upg_flag = p_bmu_data_unify->bmu_upg_sta;
    }

    if (true == pf_error_check() || 0 != bmu_pf_error_flag)
    {
        BMS_STATE_LOGD("[STA]run2err, bmu = %#x, bcu = %d...\n", bmu_pf_error_flag, pf_error_check());
        event = EVT_BMS_PF_ERROR;
    }
    //  检测到BCU升级或者bmu进入升级状态
    else if (check_sys_upgrade_flag())
    {
        BMS_STATE_LOGD("[STA]run2upg, %d, %x, %d...\n", upgrade_state_get(), bmu_pf_upg_flag, upgrade_master_state_get());
        event = EVT_BMS_UPGRADE;
    }

    return event;
}

static uint8_t sta_bms_pf_error_entry(void)
{
    g_bms_sys_display_state = BCU_STATE_PF_ERROR;
    g_bms_sys_step_state = BMS_PF_ERROR;

//    relay_manage_enable_set(false); // 停止继电器管理流程，切断充放电mos

    return EVT_NULL;
}

static uint8_t sta_bms_pf_error_run(void)
{
    uint8_t event = EVT_NULL;
    uint16_t bmu_pf_error_flag = 0;
    uint16_t bmu_pf_upg_flag = 0xFFFF;
    const bmu_data_unify_t *p_bmu_data_unify = bmu_data_unify_get();
    if (p_bmu_data_unify != NULL)
    {
        bmu_pf_error_flag = p_bmu_data_unify->bmu_err_sta;
        bmu_pf_upg_flag = p_bmu_data_unify->bmu_upg_sta;
    }

    if ((false == pf_error_check()) && (0 == bmu_pf_error_flag))
    {
        BMS_STATE_LOGD("[STA]err2run, bmu=%#x, bcu=%d...\n", bmu_pf_error_flag, pf_error_check());
        //insulation_impedance_calc_start();    //待定，如果恢复故障后，电池自己重新吸合接触器，则这里重新
        event = EVT_BMS_NORMAL;
    }
    //  检测到BCU升级或者bmu进入升级状态
    else if (check_sys_upgrade_flag())
    {
        BMS_STATE_LOGD("[STA]err2upg, %d, %x, %d...\n", upgrade_state_get(), bmu_pf_upg_flag, upgrade_master_state_get());
        event = EVT_BMS_UPGRADE;
    }

    return event;
}

static uint8_t sta_bms_upgrade_entry(void)
{
    g_bms_sys_display_state = BCU_STATE_UPGRADE;
    g_bms_sys_step_state = BMS_UPGRADE;

    auto_addressing_disable(); // 升级过程自动编址关闭
    g_dcdc_exit_flag = false;  // dcdc存在标志更新 todo
    g_reset_delay_tick = sdk_tick_get();

    return EVT_NULL;
}

static uint8_t sta_bms_upgrade_run(void)
{
    uint8_t event = EVT_NULL;
    uint8_t upgrade_state = upgrade_state_get();
    uint16_t bmu_upgrage_flag = 0;
    uint16_t bmu_pf_error_flag = 0;
    static bool first_flag = true;
    const bmu_data_unify_t *p_bmu_data_unify = bmu_data_unify_get();
    if (p_bmu_data_unify != NULL)
    {
        bmu_upgrage_flag = p_bmu_data_unify->bmu_upg_sta;
        bmu_pf_error_flag = p_bmu_data_unify->bmu_err_sta;
    }

    if ((UPG_RESET == upgrade_state_get()) || (boot_upgrade_flag_get()))
    {
        if ((true == sdk_is_tick_over(g_reset_delay_tick, os_tick_from_millisecond(500))) && (true == first_flag))
        {
            first_flag = false;
            if (!g_dcdc_exit_flag)
            {
                relay_manage_enable_set(false); // 切断继电器
            }
            bms_runing_data_save_all();          // 参数保存,SOC\SOH\累积充放电量\电池地址
            relay_manage_enable_set(false); // 停止继电器管理流程，切断充放电mos
            inner_auto_addr_init(); // 将can初始化放在空开控制之后以防止关机类型数据被清除
            can_ext_data_init();
            inner_can_sofar_manage_init();
            ext_can_sofar_manage_init();
            cluster_can_sofar_manage_init();
            fault_manage_init();
            insulation_impedance_calc_init();
            g_bms_sys_display_state = BCU_STATE_SHUT_DOWN;
            g_bms_sys_step_state = BMS_SHUT_DOWN;                 
        }
        // 升级复位
        if (true == sdk_is_tick_over(g_reset_delay_tick, os_tick_from_millisecond(3500)))
        {
            BMS_STATE_LOGD("[STA]upg2res\n");
            g_reset_delay_tick = sdk_tick_get();
            sdk_system_reset();
        }
    }
    else if (UPG_IDLE == upgrade_state && UPG_MASTER_IDLE == upgrade_master_state_get() && (0 == bmu_upgrage_flag))
    {
        if (0 != bmu_pf_error_flag || pf_error_check())
        {
            BMS_STATE_LOGD("[STA]upg2err, bmu = %#x, bcu = %d...\n", bmu_pf_error_flag, pf_error_check());
            event = EVT_BMS_PF_ERROR;
        }
        else if (false == pf_error_check())
        {
            if (g_self_check_finished_flag)
            {
                event = EVT_BMS_NORMAL;
                BMS_STATE_LOGD("[STA]upg2run\n");
            }
            else
            {
                event = EVT_BMS_START_UP;
                // 绝缘阻抗检测初始化和启动 后续需要移到继电器管理
                insulation_impedance_calc_init();
                insulation_impedance_calc_start();
                BMS_STATE_LOGD("[STA]upg2self\n");
            }
        }
    }
    else
    {
        g_reset_delay_tick = sdk_tick_get();
    }

    // 升级状态退出后，重新使能自动编址功能(编址当前只能通过命令使能)
    if (EVT_NULL != event ||
        UPG_MASTER_WAIT_RESPOND == upgrade_master_state_get() ||
        UPG_MASTER_ALL_FINISH == upgrade_master_state_get() ||
        UPG_MASTER_PART_FINISH == upgrade_master_state_get())
    {
//        auto_addressing_enable();
        ;
    }

    return event;
}

/**
 * @brief   bcu系统状态初始化
 * @param   [in] 事件
 * @return  无
 * @warning	无
 */
static void bms_sys_step_state_init(void)
{
    g_bms_sys_step_state = BMS_START_UP;      // 内部bcu系统状态
    g_bms_sys_display_state = BCU_STATE_INIT; // 外部bcu系统状态
    state_machine_init(&g_bms_sys_sta_fsm, g_bms_sys_sta_fsm_name, g_bms_sta_act_map, (uint8_t *)g_bms_sta_evt_map, EVT_BMS_STA_NUM, BMS_STA_NUM, BMS_START_UP);
}

/**
 * @brief   bcu系统状态机总处理函数
 * @param   无
 * @return  void
 * @warning	无
 */
static void bms_sys_state_proc(void)
{
    uint8_t event = state_machine_proc(&g_bms_sys_sta_fsm);
    fsm_state_trans(&g_bms_sys_sta_fsm, event);
}

/**
 * @brief		获取系统状态
 * @param		无
 * @return		系统状态
 * @retval		开机		:BCU_STATE_SELF_CHECK
 * @retval		正常运行		:BCU_STATE_RUN
 * @retval		永久性故障	:BCU_STATE_PF_ERROR
 * @retval		升级		:BCU_STATE_UPGRADE
 * @retval		关机		:BCU_STATE_SHUT_DOWN
 * @warning		无
 */
bms_system_state_e bms_state_get_sys_sta(void)
{
#ifdef BMS_STATE_SHELL_DEBUG_TEST
    if (g_bms_state_shell_debug)
    {
        return g_bms_sys_display_state_debug;
    }
#endif
    return (bms_system_state_e)g_bms_sys_display_state;
}

/**
 * @brief    获取系统步骤状态
 * @param    无
 * @return   系统步骤状态
 * @retval   唤醒检测       BMS_WAKE_CHECK = 0,
 * @retval   开机           BMS_START_UP,
 * @retval   开机自检       BMS_SELF_CHECK,
 * @retval   正常运行       BMS_NORMAL,
 * @retval   故障           BMS_PF_ERROR,
 * @retval   升级准备阶段   BMS_UPGRADE_PREPARE,
 * @retval   升级过程       BMS_UPGRADE,
 * @retval   关机           BMS_SHUT_DOWN_PREPARE,
 * @warning  无
 */
bms_system_step_e bms_state_get_sys_step(void)
{
    return (bms_system_step_e)g_bms_sys_step_state;
}

// 触发打印关键数据,用于日志分析
void bms_state_key_data_print(void)
{
    static uint8_t last_file_read = true;
    uint8_t file_read = get_file_read_wait_stus();
    if (file_read != last_file_read)
    {
        log_e("[STA]fileRead%d\n", file_read);
        last_file_read = file_read;
    }
}

/**
 * @brief		BMS状态流程
 * @param		无
 * @return		无
 * @retval		无
 * @warning		无
 */
void bms_state_proc(void)
{
    // if (special_mode_get(ATUO_TEST))
    // {
    //     return;
    // }
#ifdef BMS_STATE_SHELL_DEBUG_TEST
    if (g_bms_state_shell_debug)
    {
        return;
    }
#endif
    // 更新电池数据
    bms_state_data_sync();
    // BMS状态切换
    bms_sys_state_proc();
    // 电池状态判断
    bms_state_switch_bat_mode_proc(g_sys_sample_data.sys_current);
    // 控制can主动发送
    can_auto_send_ctrl();
    // 关键信息打印
    bms_state_key_data_print();
    // ATE模式
    //  ate_mode();
}

#ifdef BMS_STATE_SHELL_DEBUG_TEST

typedef enum
{
    DEBUG_VAL_DISPLAY_BCU_STATE = 0, // 对外显示状态
    DEBUG_VAL_BMU_POWER_CTRL,        // BMU供电控制
    DEBUG_VAL_NUM,
} sox_debug_e;

/**
 * @brief        打印BMU的返回信息
 * @param        [in]  需要查找的数据类型 bmu_data_type
 * @param        [in]  需要查找的数据编号
 * @return        无
 * @warning        无
 */
static void synthesis_bmu_data_print(pack_info_type_e data_type, uint16_t data_id)
{
    uint8_t pack_num = auto_addressing_pack_num_get();
    if (pack_num == 0)
    {
        log_e("noPack\n");
        return;
    }
    if (data_type >= PACK_INFO_TYPE_NUM)
    {
        log_e("dataTypeOver\n");
        return;
    }
    const uint8_t max_len_list[] = {BMU_DEV_NUM, YX_BMU_BYTE_NUM, YC1_BYTE_NUM, YC2_WORD_NUM, YC3_DWORD_NUM};
    if (data_id >= max_len_list[data_type])
    {
        log_e("maxLenListOver\n");
        return;
    }
    pack_info_t *bmu_data = NULL;
    uint32_t value = 0;
    log_e("DATA_TYPE=%d,data_id=%d\n", data_type, data_id);
    for (uint8_t i = 0; i < pack_num; i++)
    {
        bmu_data = get_bmu_info(i);
        if (NULL == bmu_data)
        {
            log_e("bmuDataNull\n");
            return;
        }
        switch ((uint8_t)data_type)
        {
        case PACK_INFO_DEV_TYPE:
            value = bmu_data->dev[data_id];
            break;
        case PACK_INFO_YX_TYPE:
            value = bmu_data->yx[data_id];
            break;
        case PACK_INFO_YC1_TYPE:
            value = bmu_data->yc1[data_id];
            break;
        case PACK_INFO_YC2_TYPE:
            value = bmu_data->yc2[data_id];
            break;
        case PACK_INFO_YC3_TYPE:
            value = bmu_data->yc3[data_id];
            break;
        default:
            return;
        }
        log_e("pack[%d]=#%lx\n", i, value);
    }
    return;
}

/**
 * @brief                bcu状态结果打印
 * @param                [in]void
 */
void bcu_state_shell_printf(void)
{
    const bmu_data_unify_t *bmu_data_info = bmu_data_unify_get();
    log_d("bmsStaShell=%ld\n", g_bms_state_shell_debug);
    log_d("forceOpenBmuPow=%d\n", g_force_open_bmu_power_debug_flag);
    log_d("autoAddSta=%d\n", auto_addressing_get_state());
    log_d("packNum=%d\n", auto_addressing_pack_num_get());
    log_d("bmsSysDisplayStaDebug=%ld\n", g_bms_sys_display_state_debug);
    log_d("batMode=%ld\n", g_bat_mode);
    log_d("bmsSysStepSta=%ld\n", g_bms_sys_step_state);
    log_d("bmsSysDisplayState=%ld\n", g_bms_sys_display_state);
    log_d("bmuReqShut=%x\n", bmu_data_info->bmu_shut_sta);
    log_d("bmuReqMosoff=%x\n", bmu_data_info->req_cutoff_flag);
    log_d("bmuUpgrage=%d\n", bmu_data_info->bmu_upg_sta);
    log_d("bmuAllShut=%d\n", bmu_data_info->bmu_shut_sta);
    log_d("updStus=%d,bmuUpdStus=%d,bmuStus=%d\n", upgrade_state_get(), upgrade_master_state_get(), bmu_data_info->bmu_upg_sta);
    log_d("fileRdWaitStus:%d\n", get_file_read_wait_stus());
    log_d("preChgSta= %d\n", get_pre_charge_state());
    log_d("chgMos=%d\n", get_relay_contrl_state(POS_RELAY));
    log_d("negMos=%d\n", get_relay_contrl_state(NEG_RELAY));
    log_d("preMos=%d\n", get_relay_contrl_state(PRE_RELAY));
}

/**
 * @brief                bcu状态错误打印
 * @param                [in]void
 */
void bcu_state_shell_err_printf(void)
{
    //    log_d(" sox_t param err\r\n");
    //    log_d(" sox_t print : printf data\r\n");
    //    log_d(" sox_t help : printf hlep data\r\n");
    //    log_d(" sox_t val debug(0/1) val_id(0~%d) val: set analog data\r\n", DEBUG_VAL_NUM - 1);
    //    log_d(" sox_t dat data_type(0~%d) data_id(0~x): print can data\r\n", BMS_DATA_TYPE_NUM - 1);
}

/**
 * @brief                bcu状态打印提示
 * @param                [in]void
 */
void bcu_state_shell_help_printf(void)
{
    //    log_d("g_bms_sys_step_state:\n");
    //    log_d("BMS_WAKE_CHECK        = %d\n", BMS_WAKE_CHECK);
    //    log_d("BMS_START_UP          = %d\n", BMS_START_UP);
    //    log_d("BMS_SELF_CHECK        = %d\n", BMS_SELF_CHECK);
    //    log_d("BMS_NORMAL            = %d\n", BMS_NORMAL);
    //    log_d("BMS_PF_ERROR          = %d\n", BMS_PF_ERROR);
    //    log_d("BMS_UPGRADE_PREPARE   = %d\n", BMS_UPGRADE_PREPARE);
    //    log_d("BMS_UPGRADE           = %d\n", BMS_UPGRADE);
    //    log_d("BMS_SHUT_DOWN_PREPARE = %d\n", BMS_SHUT_DOWN_PREPARE);
    //    log_d("BMS_SHUT_DOWN         = %d\n", BMS_SHUT_DOWN);

    //    log_d("g_bms_sys_display_state/ g_bms_sys_display_state_debug:\n");
    //    log_d("BCU_STATE_SELF_CHECK  = %d\n", BCU_STATE_SELF_CHECK);
    //    log_d("BCU_STATE_RUN         = %d\n", BCU_STATE_RUN);
    //    log_d("BCU_STATE_PF_ERROR    = %d\n", BCU_STATE_PF_ERROR);
    //    log_d("BCU_STATE_UPGRADE     = %d\n", BCU_STATE_UPGRADE);
    //    log_d("BCU_STATE_SHUT_DOWN   = %d\n", BCU_STATE_SHUT_DOWN);

    //    log_d("set val\n");
    //    log_d("DEBUG_VAL_DISPLAY_BCU_STATE = %d\n", DEBUG_VAL_DISPLAY_BCU_STATE);
    //    log_d("DEBUG_VAL_BMU_POWER_CTRL    = %d\n", DEBUG_VAL_BMU_POWER_CTRL);

    //    log_d("sys_shut_down_type\n");
    //    log_d("SYS_NON_SHUT_DOWN               = %d\n", SYS_NON_SHUT_DOWN    );
    //    log_d("SYS_KEY_PRESS_SHUT_DOWN        = %d\n", SYS_KEY_PRESS_SHUT_DOWN       );
    //    log_d("SYS_BMU_REQUEST_SHUT_DOWN      = %d\n", SYS_BMU_REQUEST_SHUT_DOWN     );
    //    log_d("SYS_EXT_CAN_COMM_ERR_SHUT_DOWN = %d\n", SYS_EXT_CAN_COMM_ERR_SHUT_DOWN);
    //    log_d("SYS_BOOT_UPGRADE_SHUT_DOWN     = %d\n", SYS_BOOT_UPGRADE_SHUT_DOWN    );
}

/**
 * @brief                bcu状态打印
 * @param                [in]debug_flag   设置参数标志0：不调，1：调试
 * @param                [in]type_id      参考sox_debug_e
 * @param                [in]set_data     设置SOX值
 */
void bcu_state_shell_set(uint8_t type_id, uint16_t set_data)
{
    if (!g_bms_state_shell_debug)
    {
        return;
    }
    switch (type_id)
    {
    case DEBUG_VAL_DISPLAY_BCU_STATE:
        g_bms_sys_display_state_debug = (bms_system_state_e)set_data;
        break;
    case DEBUG_VAL_BMU_POWER_CTRL: // 设置 1：强制给BMU供电  0:如果处于关机就设置bmu关机
        g_force_open_bmu_power_debug_flag = set_data;
        if (g_force_open_bmu_power_debug_flag)
        {
            ;
            //                BMU_POW_ON();
        }
        else if (BMU_STATE_SHUT_DOWN == g_bms_sys_display_state)
        {
            ;
            //                BMU_POW_OFF();
        }
        break;
    default:
        break;
    }
}

/**
 * @brief        bcu状态样例
 * @param        cmd 功能参数
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
static int state(int argc, char *argv[])
{
    if (argc < 2)
    {
        log_d("bcuStatuParaErr\n");
        return SF_ERR_PARA;
    }

    if (!strcmp(argv[1], "print"))
    {
        bcu_state_shell_printf();
    }
    else if (!strcmp(argv[1], "val"))
    {
        if (argc < 4)
        {
            log_d("bcuValErr\n");
            return SF_ERR_PARA;
        }
        uint32_t val_id = atoi(argv[2]); // 参数2: 模拟量sox_debug_e
        uint16_t value = atoi(argv[3]);  // 参数3：value值
        bcu_state_shell_set(val_id, value);
    }
    else if (!strcmp(argv[1], "debug"))
    {
        if (argc < 3)
        {
            log_d("bcuDebugErr\n");
            return SF_ERR_PARA;
        }
        uint32_t debug_flag = atoi(argv[2]); // 设置参数1：debug标志（1使能，0取消）
        g_bms_state_shell_debug = debug_flag;
    }
    else if (!strcmp(argv[1], "help"))
    {
        bcu_state_shell_help_printf();
    }
    else if (!strcmp(argv[1], "dat"))
    {
        if (argc < 4)
        {
            log_d("bcuDatErr\n");
            return SF_ERR_PARA;
        }
        uint16_t data_type = atoi(argv[2]); // 参数1: can的数据类型
        uint32_t data_id = atoi(argv[3]);   // 参数2：数据id
        synthesis_bmu_data_print((pack_info_type_e)data_type, data_id);
    }
    return 0;
}
MSH_CMD_EXPORT(state, <print / debug 0 - 1 / val valId value / dat type id>);
#endif
