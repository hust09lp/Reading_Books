#include "inner_can_data.h"
#include "sofar_can_manage.h"
#include "sdk.h"
#include "sdk_core.h"
#include "auto_addressing.h"
#include "fault_manage.h"
#include "bms_state.h"
#include "sample.h"
#include "ate.h"
#include "app_public.h"
#include "bmu_data.h"
#include "upgrade_master.h"
#include "data_store.h"
#include "bcu_data.h"
#include "addressing_common.h"
#include "cell_balance.h"

// static bool g_debug_bal_bmu_ready = false; //debug

/**************************************bcu轮询请求遥测数据*******************************************************/
#define INNER_BCU_REQ_FRAME_LEN (8)
#define INNER_BCU_REQ_TIME_BASE  (10)
#define INNER_BCU_REQ_INIT_DELAY (50 / INNER_BCU_REQ_TIME_BASE)
#define INNER_BCU_REQ_PACK_DELAY (20 / INNER_BCU_REQ_TIME_BASE) // 在一个时间片周期内，pack最大数为10个，根据最长帧数（暂时最大4帧）以及发送接收时间差(10ms周期)，发送帧间隔(1ms)， 最大25ms，最小14ms
#define INNER_BCU_REQ_CYCLE (250 / INNER_BCU_REQ_TIME_BASE)   // 当前以250ms为时间片，作为遍历所有电池包的周期

typedef struct
{
    uint8_t                 req_type;      // 请求类型inner_can_bcu_req_event_type
    uint8_t                 start_time;    // 启动时间间隔 单位：INNER_BCU_REQ_CYCLE
    uint16_t                 cycle_time;    // 循环周期  单位：INNER_BCU_REQ_CYCLE
    uint16_t                 timer;         // 时间计数器
    uint16_t                time_out_bit;  // 每个pack对应的超时位
    int16_t                 cnt;           // 请求的次数，-1则一直请求
}requset_data_msg_info_t;

// 0x02C 上位机监控读取的byte[1] 模块读取参数
typedef enum
{
    NO_MODULE_SEND_REQ = 0,
    CELL_VOLT_MODULE_SEND_REQ,  // BMU自动发送
    CELL_TEMP_MODULE_SEND_REQ,  // BCU被动查询
    CELL_SOC_MODULE_SEND_REQ,   // BCU被动查询
    CELL_SOH_MODULE_SEND_REQ,   // BCU被动查询
    DEV_INFO_MODULE_SEND_REQ,   // BMU自动发送
    PACK_REMOTE_COMM_DATA_SEND_REQ,   // BMU自动发送
    PACK_REMOTE_COLLECT_DATA1_SEND_REQ,  // BCU被动查询
    PACK_REMOTE_COLLECT_DATA2_SEND_REQ,  // BCU被动查询
    BAL_MODULE_DATA_SEND_REQ, // BCU被动查询
    ATE_MODULE_DATA_SEND_REQ, // ate查询
    PACK_SN_DATA_SEND_REQ,    // BMU自动发送
    BOARD_SN_DATA_SEND_REQ,   // BMU自动发送    
    MODULE_REQ_SEND_REQ_NUM,
} module_request_send_group_e;

// 触发式发送BMU枚举 （必须与g_can_inner_req_txmsg_tab 一一对应）
typedef enum
{
    INNER_BCU_REQ_BMU_SAM_MSG = 0,
    INNER_BCU_REQ_BMU_BAL_MSG,
    INNER_BCU_REQ_BMU_CELL_TEMP_MSG,
    INNER_BCU_REQ_BMU_CELL_SOC_MSG,
    INNER_BCU_REQ_BMU_CELL_SOH_MSG,
    INNER_BCU_REQ_BMU_PACK_CAP_MSG,
    INNER_BCU_REQ_BMU_VER_MSG,
    INNER_BCU_REQ_BMU_TYPE_NUM,
    INNER_BCU_REQ_BMU_INVALID_TYPE = 0xFF,
} inner_can_bcu_req_type;

// 请求bmu发送数据，必须与 inner_can_bcu_req_event_type/get_need_req_data()一一对应
static requset_data_msg_info_t g_can_inner_req_txmsg_tab[] =
{
    {INNER_BCU_REQ_BMU_SAM_MSG,       0, 10,  0, 0, -1}, // 2.5s
    {INNER_BCU_REQ_BMU_BAL_MSG,       8, 20,  0, 0, -1},     // 5s
    {INNER_BCU_REQ_BMU_CELL_TEMP_MSG,12, 20,  0, 0, -1},      // 5s
    {INNER_BCU_REQ_BMU_CELL_SOC_MSG, 21, 60, 0, 0, -1},     // 15s
    {INNER_BCU_REQ_BMU_CELL_SOH_MSG, 25, 960, 0, 0, -1},     // 240s
    {INNER_BCU_REQ_BMU_PACK_CAP_MSG, 29, 240, 0, 0, -1},     // 60s
    {INNER_BCU_REQ_BMU_VER_MSG,      40, 6,   0, 0, 20}, // 1.5s
};

static const uint8_t g_req_msg_amount = sizeof(g_can_inner_req_txmsg_tab) / sizeof(requset_data_msg_info_t);
static uint8_t g_req_msg_time_out[PACK_MAX_NUM] = {0};
static uint8_t g_req_msg_pack_addr = 0;
static uint8_t g_need_req_type = INNER_BCU_REQ_BMU_INVALID_TYPE;
/*******************************************************************************************************/
// 发送周期任务数组定义
// 默认源地址bcu 0x1，目的地址广播 bmu 0x1F
typedef struct
{
    uint8_t send_id;
    can_frame_id_u frame_id;
    uint16_t send_period;
    int16_t send_cnt;        // 发送次数，小于0:一直发送
    uint16_t period_cnt;
    bool (*p_func_recv_deal_cb)(uint32_t frame_id);
} tx_inner_can_msg_tcb_t;

// BMU 状态
typedef union{
    uint8_t all;
    struct{
        uint8_t bat_sta:         2;    // 0x0：待机状态  0x1：充电状态  0x2：放电状态
        uint8_t full_chg_sta:    1;    // 1:充满  0:正常
        uint8_t empty_sta:       1;    // 1:放亏 0:正常
        uint8_t shut_down_sta:   1;    // 1:关机 0:正常
        uint8_t bal_recharge:    1;    // 1:清除 0:正常
        uint8_t pack_recover:    1;    // 1:复归处理
        uint8_t res:             1;    // < Reserved.
    }bit;
}can_bat_status_u;

static void bmu_bcu_comm_fault_check(uint8_t pack_id);

// 接收处理函数
static bool inner_can_rx_bmu_time(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_cell_volt_overflow(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_cell_temp_overflow(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_cell_pass_bal_state_overflow(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_bms_inter_info2(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_bms_inter_info3(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_bms_inter_info4(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_bms_inter_info5(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_bms_fault_info1(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_bms_cell_other_info1(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_bms_inter_info6(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_bms_inter_info7(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_bal_temp_info1(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_power_mos_temp_info(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_bms_fault_info2(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_bms_fault_info3(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_bms_dsg_cali_info(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_bms_remote_signal_info1(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_bms_remote_signal_info2(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_act_bal_info1(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_act_bal_info2(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_soft_ver_info1(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_soft_ver_info2(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_soft_ver_info3(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_bms_remote_signal_info3(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_bmu_soc_info(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_bmu_soh_info(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_bmu_pack_sn_info(can_frame_data_t *can_data, uint16_t func_code);
static bool inner_can_rx_msg_bmu_board_sn_info(can_frame_data_t *can_data, uint16_t func_code);

static int32_t inner_can_rx_hall_info(can_frame_data_t *can_data);

// 发送函数
static bool inner_can_tx_master_curr_set_cmd(uint32_t frame_id);
static bool inner_can_tx_time_set(uint32_t frame_id);

const can_msg_tcb_t g_inner_rx_can_msg_list[] =
{
    { RX_INNER_SLAVER_CTL_REPLY       ,   FUNC_SLAVER_CTL_REPLY        ,  inner_addr_rcv_callback               },  // BMS回复信息2
    { RX_INNER_HEART_BEAT             ,   FUNC_HEART_BEAT_CMD          ,  inner_addr_rcv_callback                   },  // 心跳帧处理
    { RX_INNER_BMU_TIME               ,   FUNC_ATE_SYS_TIME_SET        ,  inner_can_rx_bmu_time                     },  // bmu时间
    // bmu数据上报
    { CELL_VOLT_OVERFLOW              ,  FUNC_CELL_VOLT_OVERFLOW           ,  inner_can_rx_msg_cell_volt_overflow },     // 电芯电压
    { CELL_TEMP_OVERFLOW              ,  FUNC_CELL_TEMP_OVERFLOW           ,  inner_can_rx_msg_cell_temp_overflow },     // 电芯温度
    { CELL_PASS_BAL_STATE_OVERFLOW    ,  FUNC_CELL_PASS_BAL_STATE_OVERFLOW ,  inner_can_rx_msg_cell_pass_bal_state_overflow },     // 被动均衡状态
    { RX_INNER_BMS_INTER_INFO2        ,   FUNC_BMS_INTER_INFO2         ,  inner_can_rx_msg_bms_inter_info2         },  // BMS发送电池信息2
    { RX_INNER_BMS_INTER_INFO3        ,   FUNC_BMS_INTER_INFO3         ,  inner_can_rx_msg_bms_inter_info3         },  // BMS发送电池信息3
    { RX_INNER_BMS_INTER_INFO4        ,   FUNC_BMS_INTER_INFO4         ,  inner_can_rx_msg_bms_inter_info4         },  // BMS发送电池信息4
    { RX_INNER_BMS_INTER_INFO5        ,   FUNC_BMS_INTER_INFO5         ,  inner_can_rx_msg_bms_inter_info5         },  // BMS发送电池信息5
    { RX_INNER_BMS_FAULT_INFO1        ,   FUNC_BMS_FAULT_INFO1         ,  inner_can_rx_msg_bms_fault_info1         },  // BMS发送内部电池故障信息1
    { RX_INNER_BMS_CELL_OTHER_INFO1   ,   FUNC_BMS_CELL_OTHER_INFO1    ,  inner_can_rx_msg_bms_cell_other_info1    },  // 其他信息
    { RX_INNER_BMS_INTER_INFO6        ,   FUNC_BMS_INTER_INFO6         ,  inner_can_rx_msg_bms_inter_info6         },  // BMS发送电池信息6
    { RX_INNER_BMS_INTER_INFO7        ,   FUNC_BMS_INTER_INFO7         ,  inner_can_rx_msg_bms_inter_info7         },  // BMS发送电池信息7
    { RX_INNER_BAL_TEMP_INFO1         ,   FUNC_BAL_TEMP_INFO1          ,  inner_can_rx_msg_bal_temp_info1          },  // BMS均衡温度1-2
    { RX_INNER_POWER_MOS_TEMP_INFO    ,   FUNC_POWER_MOS_TEMP_INFO     ,  inner_can_rx_msg_power_mos_temp_info     },  // BMS功率端子温度
    { RX_INNER_BMS_FAULT_INFO2        ,   FUNC_BMS_FAULT_INFO2         ,  inner_can_rx_msg_bms_fault_info2         },  // BMS发送内部电池故障信息2
    { RX_INNER_BMS_FAULT_INFO3        ,   FUNC_BMS_FAULT_INFO3         ,  inner_can_rx_msg_bms_fault_info3         },  // BMS发送内部电池故障信息3
    { RX_INNER_BMS_DSG_CALI_INFO      ,   FUNC_BMS_DSG_CALI_INFO       ,  inner_can_rx_msg_bms_dsg_cali_info       },  // BMS发送放电末端校准信息
    { RX_INNER_BMS_REMOTE_SIGNAL_INFO1,   FUNC_BMS_REMOTE_SIGNAL_INFO1 ,  inner_can_rx_msg_bms_remote_signal_info1 },  // 遥信数据上报1
    { RX_INNER_BMS_REMOTE_SIGNAL_INFO2,   FUNC_BMS_REMOTE_SIGNAL_INFO2 ,  inner_can_rx_msg_bms_remote_signal_info2 },  // 遥信数据上报2
    { RX_INNER_ACT_BAL_INFO1          ,   FUNC_ACT_BAL_INFO1           ,  inner_can_rx_msg_act_bal_info1           },  // 主动均衡数据上报1
    { RX_INNER_ACT_BAL_INFO2          ,   FUNC_ACT_BAL_INFO2           ,  inner_can_rx_msg_act_bal_info2           },  // 主动均衡数据上报2
    { RX_INNER_SOFT_VER_INFO1         ,   FUNC_SOFT_VER_INFO1          ,  inner_can_rx_msg_soft_ver_info1          },  // 设备软件版信息1
    { RX_INNER_SOFT_VER_INFO2         ,   FUNC_SOFT_VER_INFO2          ,  inner_can_rx_msg_soft_ver_info2          },  // 设备软件版信息2
    { RX_INNER_SOFT_VER_INFO3         ,   FUNC_SOFT_VER_INFO3          ,  inner_can_rx_msg_soft_ver_info3          },  // 设备软件版信息3
    { RX_INNER_BMS_REMOTE_SIGNAL_INFO3,   FUNC_BMS_REMOTE_SIGNAL_INFO3 ,  inner_can_rx_msg_bms_remote_signal_info3 },  // 其他数据上报
    { RX_INNER_CELL_SOC_INFO          ,   FUNC_CELL_SOC_INFO           ,  inner_can_rx_msg_bmu_soc_info            },  // 单个电芯SOC
    { RX_INNER_CELL_SOH_INFO          ,   FUNC_CELL_SOH_INFO           ,  inner_can_rx_msg_bmu_soh_info            },  // 单个电芯SOH
    { RX_INNER_BMU_PACK_SN            ,   FUNC_ATE_PACK_SN_SET         ,  inner_can_rx_msg_bmu_pack_sn_info        },  // bmu  pack sn
    { RX_INNER_BMU_BOARD_SN           ,   FUNC_ATE_BOARD_SN_SET        ,  inner_can_rx_msg_bmu_board_sn_info       },  // bmu  board sn
};

// 需要更新 can_inner_auto_send_cycle_update()
static tx_inner_can_msg_tcb_t g_inner_tx_can_msg_list[] =
{
    {INNER_BCU_SET_PARA_MSG, {.bit.src_addr = BCU_INNER_CAN_ADDR, .bit.src_type = DEV_BCU, .bit.dst_addr = BROCAST_DEVICE_ADDRESS,.bit.dst_type = DEV_BMU,
        .bit.fun_code = FUNC_MASTER_CURR_SET_CMD, .bit.prio = SOFAR_CAN_PRI_LOW_H, .bit.res = 0}, CYCLE_SEND_500MS, -1, 0, inner_can_tx_master_curr_set_cmd}, // 设置电流
    {INNER_BCU_SET_TIME_MSG, {.bit.src_addr = BCU_INNER_CAN_ADDR, .bit.src_type = DEV_BCU, .bit.dst_addr = BROCAST_DEVICE_ADDRESS,.bit.dst_type = DEV_BMU,
        .bit.fun_code = FUNC_ATE_SYS_TIME_SET, .bit.prio = SOFAR_CAN_PRI_LOW_H, .bit.res = 0}, CYCLE_SEND_10MIN, -1, 0, inner_can_tx_time_set},  // 设置时间
};

static uint8_t g_inner_rx_can_msg_list_len = sizeof(g_inner_rx_can_msg_list) / sizeof(g_inner_rx_can_msg_list[0]);
static uint8_t g_inner_tx_can_msg_list_len = sizeof(g_inner_tx_can_msg_list) / sizeof(g_inner_tx_can_msg_list[0]);

static pack_info_t g_pack_data[PACK_MAX_NUM] = {0};
static pack_cell_info_t g_pack_cell_data = {0};
static pack_other_device_info_t g_pack_other_device_info = {0}; // 其他设备数据
static uint8_t g_inner_send_data_enable = INN_AUTO_SEND_FORBID_TYPE;		//CAN网使能标志位

uint32_t g_req_test_time = 0;
uint16_t g_bmu_com_mask = 0;
uint8_t g_bmu_com_fault_time[PACK_MAX_NUM] = {0};

// 同步bmu告警阈值
static uint8_t g_bmu_alm_thre_val_sync_state = SYNC_THRE_VAL_INIT;
static uint8_t g_bmu_alarm_thre_val_check_flag = false;     // 1: check
static uint8_t g_bmu_alarm_thre_val_check_err_time = 0;

// 10ms任务判断，如果超过10s没有接收数据，认为通讯失败
void singal_bmu_bcu_com_fault_check(void)
{
#define BMU_COMM_FAULT_CHECK_CYCLE_B10MS 50
#define BMU_COMM_FAULT_CNT_B500MS 20     // 10s
    const bms_attr_t *bms_attr = get_bms_attr();
    if (auto_addressing_get_state() != ADDRESSING_FINISH)
    {
        return;
    }
    static uint8_t delay_ms = BMU_COMM_FAULT_CHECK_CYCLE_B10MS;
    if (--delay_ms > 0)
    {
        return;
    }
    delay_ms = BMU_COMM_FAULT_CHECK_CYCLE_B10MS;
    for (uint8_t i = 0; i < bms_attr->clu_pack_num; i++)
    {
        if(++g_bmu_com_fault_time[i] > BMU_COMM_FAULT_CNT_B500MS)
        {
            g_bmu_com_mask &= ~(1 << i);
        }
    }
}

// 获取每个电池包的通讯失败标志，0:失败 1:成功
uint16_t singal_bmu_bcu_com_fault_flag_get(void)
{
    return g_bmu_com_mask;
}

static void bmu_bcu_comm_fault_check(uint8_t pack_id)
{
    static uint16_t com_mask = 0;
    uint8_t com_check = 0;
    uint8_t pack_num = auto_addressing_pack_num_get();

    com_mask |= (1 << pack_id);
    g_bmu_com_mask |= (1 << pack_id);
    g_bmu_com_fault_time[pack_id] = 0;
    if ((ADDRESSING_FINISH == auto_addressing_get_state()) &&
        (0 != pack_num))
    {
        for(uint8_t i = 0; i < pack_num; i++)
        {
            com_check |= (1 << i);
        }

        if(com_mask == com_check)
        {
            com_mask = 0;
            fault_bcu_inter_com_count_clear();
        }
    }
    else
    {
        com_mask = 0;
    }

}

// 填充发送数据
// 使用注意，不要越界，fill_data + fill_len 不能超过数组长度
static void fill_can_data_buff(uint32_t fill_data, uint8_t *fill_buff, uint8_t fill_len)
{
    if (NULL == fill_buff ||  (2 != fill_len && 4 != fill_len)) // 不是两个字节&&不是4个字节，认为异常
    {
        return ;
    }
    for (uint8_t i = 0; i < fill_len; i++)
    {
        fill_buff[i] = (uint8_t)(fill_data >> (i * 8));
    }
}

// bcu请求数据超时计时
void judge_bcu_req_data_time_over(uint8_t req_type)
{
    for (uint8_t i = 0; i < auto_addressing_pack_num_get(); i++)
    {
        if (g_req_msg_time_out[i] == 0)
        {
            continue;
        }
        g_req_msg_time_out[i]++;
        if (req_type < g_req_msg_amount && g_req_msg_time_out[i] >= 5)
        {
            g_can_inner_req_txmsg_tab[req_type].time_out_bit |= 1 << i;
            //if (g_req_msg_time_out[i] > 5)
            //{
            //    log_d("[req]ty%d, P%d, C%d, T%ld\n", req_type, i, g_req_msg_time_out[i], g_req_test_time);
            //}
        }
    }
}

// bcu请求数据超时计时
// [in]pack_id 0：表示所有pack 1-10:表示对应pack地址
void clear_bcu_req_data_over_time_cnt(uint8_t pack_id)
{
    if (0 == pack_id)
    {
        for (uint8_t i = 0; i < auto_addressing_pack_num_get(); i++)
        {
            g_req_msg_time_out[i] = 0;
        }
    }
    else if (pack_id <= PACK_MAX_NUM)
    {
        g_req_msg_time_out[pack_id - 1] = 0;
    }
}

// bcu请求数据正常接收后，清除计数
// [in] pack_id :1~10
void bcu_req_data_recv_ok_deal(uint8_t pack_id, inner_can_bcu_req_type type)
{
    if (INNER_BCU_REQ_BMU_INVALID_TYPE == g_need_req_type || g_need_req_type > g_req_msg_amount)
    {
        return;
    }
    requset_data_msg_info_t *p_req_data_info = &g_can_inner_req_txmsg_tab[g_need_req_type];

    if (p_req_data_info->req_type == type)
    {
        clear_bcu_req_data_over_time_cnt(pack_id);
    }
}

// 获取请求数据超时的第一个电池包编号
uint8_t get_req_over_time_first_pack_num(uint16_t time_bit)
{
    uint8_t pack_num = auto_addressing_pack_num_get();
    if (!time_bit)
    {
        return pack_num;
    }
    for (uint8_t i = 0; i < pack_num; i++)
    {
        if (time_bit & (0x0001 << i))
        {
            return i;
        }
    }
    return pack_num;
}

// 获取需要请求数据类型 250ms运行一次
inner_can_bcu_req_type get_need_req_data(void)
{
    // 轮询表格查询
    inner_can_bcu_req_type req_type = INNER_BCU_REQ_BMU_INVALID_TYPE;
    for (uint8_t i = 0; i < INNER_BCU_REQ_BMU_TYPE_NUM; i++)
    {

        if (g_can_inner_req_txmsg_tab[i].timer > 0)
        {
            g_can_inner_req_txmsg_tab[i].timer--;
        }
        else
        {
            if((g_can_inner_req_txmsg_tab[i].cnt != -1) && (g_can_inner_req_txmsg_tab[i].cnt > 0))
            {
                g_can_inner_req_txmsg_tab[i].cnt--;
            }
            else if(0 == g_can_inner_req_txmsg_tab[i].cnt)  
            {
                continue;
            }
            
            if (INNER_BCU_REQ_BMU_INVALID_TYPE == req_type)
            {
                req_type = (inner_can_bcu_req_type)i;
                g_can_inner_req_txmsg_tab[i].timer = g_can_inner_req_txmsg_tab[i].cycle_time;
            }
            else
            {
            }
        }
    }
    if (INNER_BCU_REQ_BMU_INVALID_TYPE != req_type)
    {
        return req_type;
    }

    // 超时重新调用
    requset_data_msg_info_t *p_req_info = NULL;
    for (uint8_t i = 0; i < g_req_msg_amount; i++)
    {
        p_req_info = NULL;
        p_req_info = &g_can_inner_req_txmsg_tab[i];
        if (NULL == p_req_info)
        {
            continue;
        }
        if (p_req_info->time_out_bit)
        {
            g_req_msg_pack_addr = get_req_over_time_first_pack_num(p_req_info->time_out_bit);
            req_type = (inner_can_bcu_req_type)p_req_info->req_type;
//            log_d("[req]tim ov,%d %#x,p:%d\n", req_type, p_req_info->time_out_bit, g_req_msg_pack_addr);
            p_req_info->time_out_bit = 0;
            break;
        }
    }
    return req_type;
}

// 请求帧轮询逻辑
inner_can_bcu_req_type can_inner_req_data_polling_ctrl(void)
{
    static int8_t req_delay = INNER_BCU_REQ_PACK_DELAY; // 上电50ms延迟
    static uint8_t cylce_time = 0;
    static inner_can_bcu_req_type need_send_type = INNER_BCU_REQ_BMU_INVALID_TYPE;
    uint8_t pack_num = auto_addressing_pack_num_get();
    judge_bcu_req_data_time_over(need_send_type);
    if ((++cylce_time) >= INNER_BCU_REQ_CYCLE)
    {
        cylce_time = 0;
        req_delay = 0;
        clear_bcu_req_data_over_time_cnt(0);
        need_send_type = get_need_req_data();
        g_need_req_type = need_send_type;
        //log_d("[req]ned T%ld\n", g_req_test_time);
    }

    if ((req_delay) > 1)
    {
        req_delay--;
        return INNER_BCU_REQ_BMU_INVALID_TYPE;
    }
    if (INNER_BCU_REQ_BMU_INVALID_TYPE == need_send_type)
    {
        return INNER_BCU_REQ_BMU_INVALID_TYPE;
    }
    // 请求的pack地址
    g_req_msg_pack_addr++;
    if (pack_num >= g_req_msg_pack_addr)
    {
        req_delay = INNER_BCU_REQ_PACK_DELAY; // 每个电池包的发送间隔
    }
    else
    {
        req_delay = INNER_BCU_REQ_INIT_DELAY - INNER_BCU_REQ_PACK_DELAY; // 最后一个pack延迟
        g_req_msg_pack_addr = 0;
        need_send_type = INNER_BCU_REQ_BMU_INVALID_TYPE;
    }
    return need_send_type;
}

// 请求bmu数据的枚举对应的0x02C命令模块数据读取type对应
static module_request_send_group_e bcu_req_module_data_type_get(inner_can_bcu_req_type req_type)
{
    module_request_send_group_e module_type = NO_MODULE_SEND_REQ;
    switch ((uint8_t)req_type)
    {
        case INNER_BCU_REQ_BMU_SAM_MSG:
            module_type = PACK_REMOTE_COLLECT_DATA1_SEND_REQ;
            break;
        case INNER_BCU_REQ_BMU_BAL_MSG:
            module_type = BAL_MODULE_DATA_SEND_REQ;
            break;
        case INNER_BCU_REQ_BMU_CELL_TEMP_MSG:
            module_type = CELL_TEMP_MODULE_SEND_REQ;
            break;
        case INNER_BCU_REQ_BMU_CELL_SOC_MSG:
            module_type = CELL_SOC_MODULE_SEND_REQ;
            break;
        case INNER_BCU_REQ_BMU_CELL_SOH_MSG:
            module_type = CELL_SOH_MODULE_SEND_REQ;
            break;
        case INNER_BCU_REQ_BMU_PACK_CAP_MSG:
            module_type = PACK_REMOTE_COLLECT_DATA2_SEND_REQ;
            break;
        case INNER_BCU_REQ_BMU_VER_MSG:
            module_type = DEV_INFO_MODULE_SEND_REQ;
            break;            
        default:
            module_type = NO_MODULE_SEND_REQ;
            break;
    }
    return module_type;
}

// 请求bmu数据处理函数 10ms任务
void can_inner_req_data_proc(void)
{
    singal_bmu_bcu_com_fault_check();
    if (special_mode_get(ATUO_TEST) || INN_AUTO_SEND_NORMAL_TYPE != g_inner_send_data_enable ||
        0 == auto_addressing_pack_num_get())
    {
        return;
    }
    g_req_test_time++;
    // 判断是否需要发送数据
    uint8_t req_type = can_inner_req_data_polling_ctrl();
    if (req_type >= g_req_msg_amount)
    {
        if (INNER_BCU_REQ_BMU_INVALID_TYPE != req_type)
        {
            log_d("req_t up%d\n", req_type);
        }
        return;
    }
    if (0 == g_req_msg_pack_addr)
    {
        log_d("[req]pack add err\n");
        return;
    }
    // 填充帧id
    can_frame_id_u frame_val = {0};
    frame_val.bit.dst_addr = g_req_msg_pack_addr;
    frame_val.bit.dst_type = DEV_BMU;
    frame_val.bit.src_addr = BCU_INNER_CAN_ADDR;
    frame_val.bit.src_type = DEV_BCU;
    frame_val.bit.prio = SOFAR_CAN_PRI_LOW_H;
    frame_val.bit.fun_code = FUNC_ATE_MONITOR_DATA_READ;
    // 获取对应请求帧的数据
    requset_data_msg_info_t *req_msg_info = NULL;
    req_msg_info = &g_can_inner_req_txmsg_tab[req_type];

    // 填充数据
    uint8_t req_data[INNER_BCU_REQ_FRAME_LEN] = {0}; // 一组数据帧
    // 填充寄存器起始地址
    req_data[0] = 0;
    req_data[1] = (uint8_t)bcu_req_module_data_type_get((inner_can_bcu_req_type)req_msg_info->req_type);

    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_val.id_val, req_data, INNER_BCU_REQ_FRAME_LEN);
    //log_d("[req]send %d, P:%d, T:%ld\n", req_type, g_req_msg_pack_addr, g_req_test_time);
    if (UPG_MASTER_IDLE == upgrade_master_state_get())
    {
        g_req_msg_time_out[g_req_msg_pack_addr - 1] = 1; // 启动定时器计时
    }
    else
    {
        g_req_msg_time_out[g_req_msg_pack_addr - 1] = 0; // close定时器计时
    }
}



#define send_time2 10
#define  MAS_SET_DSG_END_SOC_DATA 1
#define  MAS_SET_PASS_BAL_DATA    2
#define  MAS_SET_CLU_LOW_VOLT    3
void send_bmu_dsg_cali_ctrl(void)
{
    can_frame_id_u frame_val = {0};
    static int8_t send_count = send_time2;
    pack_info_t* pack_info = NULL;
    uint16_t temp = 0;

    uint16_t bmu_dsg_cali_utable = 0;
    uint16_t bmu_dsg_cali_soc = 0;
    uint16_t bmu_dsg_cali_min_cell_volt = 0;

    uint16_t bmu_dsg_cali_utable_min = 0;
    uint16_t bmu_dsg_cali_soc_min = 0;
    uint16_t bmu_dsg_cali_min_cell_volt_min = 0;

    can_frame_data_t dsg_cali_ctl_frame = {0};
    static uint32_t timestamp = 0;
    bool get_first_flag = false;

    if (sdk_is_tick_over(timestamp, os_tick_from_millisecond(1000)))
    {
        timestamp = sdk_tick_get();
        if ((INN_AUTO_SEND_NORMAL_TYPE != g_inner_send_data_enable) &&
        (INN_AUTO_SEND_SLOW_TYPE != g_inner_send_data_enable))
        {
            return;
        }
        for(uint8_t i = 0; i < auto_addressing_pack_num_get(); i++)
        {
            pack_info = get_bmu_info(i);
            if(NULL == pack_info)
            {
                continue;
            }
            temp = MAKE_WORD(pack_info->yx[YX_BMU_DSG_CALI_UTABLE_1], pack_info->yx[YX_BMU_DSG_CALI_UTABLE_2]);
            if(0xFFFF != temp)
            {
                send_count = 0;
                break;
            }
        }
        
        // id 填充
        frame_val.bit.dst_type = DEV_BMU;
        frame_val.bit.src_addr = BCU_INNER_CAN_ADDR;
        frame_val.bit.src_type = DEV_BCU;
        frame_val.bit.prio = SOFAR_CAN_PRI_LOW_H;
        frame_val.bit.fun_code = FUNC_MASTER_DSG_CALI_SET_CMD;
        dsg_cali_ctl_frame.data_len = CAN_SIGNAL_FRA_MAX_NUMS;        

        // 发送压差被动均衡所需数据
        frame_val.bit.dst_addr = BROCAST_DEVICE_ADDRESS; //广播
        dsg_cali_ctl_frame.id = frame_val.id_val;
        dsg_cali_ctl_frame.data[0] = MAS_SET_CLU_LOW_VOLT;
        fill_can_data_buff(get_cluster_bcu_data(ext_addressing_manage_addr_get() - GOLD_MIN_EX_CAN_NO_TYPE_ADDR)->clu_min_cell_volt, &dsg_cali_ctl_frame.data[1], WORD_SIZE);
        can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, dsg_cali_ctl_frame.id, dsg_cali_ctl_frame.data, dsg_cali_ctl_frame.data_len);     
        
        if(send_count < send_time2)
        {
            for (uint8_t i = 0; i < auto_addressing_pack_num_get(); i++)
            {
                pack_info = get_bmu_info(i);
                if(NULL == pack_info)
                {
                    continue;
                }

                bmu_dsg_cali_utable = MAKE_WORD(pack_info->yx[YX_BMU_DSG_CALI_UTABLE_1], pack_info->yx[YX_BMU_DSG_CALI_UTABLE_2]);
                bmu_dsg_cali_soc  = MAKE_WORD(pack_info->yx[YX_BMU_DSG_CALI_SOC_1], pack_info->yx[YX_BMU_DSG_CALI_SOC_2]);
                bmu_dsg_cali_min_cell_volt  = MAKE_WORD(pack_info->yx[YX_BMU_DSG_CALI_MIN_CELL_VOL_1], pack_info->yx[YX_BMU_DSG_CALI_MIN_CELL_VOL_2]);

                if (!get_first_flag)
                {
                    bmu_dsg_cali_utable_min = bmu_dsg_cali_utable;
                    bmu_dsg_cali_soc_min  = bmu_dsg_cali_soc;
                    bmu_dsg_cali_min_cell_volt_min = bmu_dsg_cali_min_cell_volt;
                    get_first_flag = true;
                    continue;
                }
                if (bmu_dsg_cali_min_cell_volt_min > bmu_dsg_cali_min_cell_volt)
                {
                    bmu_dsg_cali_utable_min = bmu_dsg_cali_utable;
                    bmu_dsg_cali_soc_min  = bmu_dsg_cali_soc;
                    bmu_dsg_cali_min_cell_volt_min = bmu_dsg_cali_min_cell_volt;
                }
            }
            for (uint8_t i = 0; i < auto_addressing_pack_num_get(); i++)
            {
                frame_val.bit.dst_addr = i + 1; //电池包ID从1开始
                dsg_cali_ctl_frame.id = frame_val.id_val;
                dsg_cali_ctl_frame.data[0] = MAS_SET_DSG_END_SOC_DATA;
                fill_can_data_buff(bmu_dsg_cali_utable_min, &dsg_cali_ctl_frame.data[1], WORD_SIZE);
                fill_can_data_buff(bmu_dsg_cali_soc_min, &dsg_cali_ctl_frame.data[3], WORD_SIZE);
                fill_can_data_buff(bmu_dsg_cali_min_cell_volt_min, &dsg_cali_ctl_frame.data[5], WORD_SIZE);
                // dsg_cali_ctl_frame.data[7] = can_single_frame_crc8_calc(&dsg_cali_ctl_frame, MASTER_CTL_SET_CRC8_MASK);
                can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, dsg_cali_ctl_frame.id, dsg_cali_ctl_frame.data, dsg_cali_ctl_frame.data_len);
            }
//            log_d("[dsg cali]cali_volt[%d],cali_soc:%d\r\n", bmu_dsg_cali_utable_min, bmu_dsg_cali_soc_min);
            send_count++;
        }
           
    }
}

void send_bmu_act_bal_ctrl(void)
{
    can_frame_id_u frame_val = {0};
    can_frame_data_t bal_ctl_frame = {0};
    static uint32_t timestamp = 0;

    if (sdk_is_tick_over(timestamp, os_tick_from_millisecond(1000)))
    {
        timestamp = sdk_tick_get();
        if ((INN_AUTO_SEND_NORMAL_TYPE != g_inner_send_data_enable) &&
        (INN_AUTO_SEND_SLOW_TYPE != g_inner_send_data_enable))
        {
            return;
        }

		// id 填充
		frame_val.bit.dst_type = DEV_BMU;
        frame_val.bit.dst_addr = BROCAST_DEVICE_ADDRESS;
		frame_val.bit.src_addr = BCU_INNER_CAN_ADDR;
		frame_val.bit.src_type = DEV_BCU;
		frame_val.bit.prio = SOFAR_CAN_PRI_LOW_H;
		frame_val.bit.fun_code = FUNC_MASTER_DSG_CALI_SET_CMD;
		bal_ctl_frame.data_len = CAN_SIGNAL_FRA_MAX_NUMS;

//		for (uint8_t i = 0; i < auto_addressing_pack_num_get(); i++)
//		{
//			frame_val.bit.dst_addr = i + 1; //电池包ID从1开始
			bal_ctl_frame.id = frame_val.id_val;

            //发均衡状态和最小soc改用广播方式
            bal_ctl_frame.data[0] = MAS_SET_PASS_BAL_DATA;
			fill_can_data_buff(cluster_passive_data_status_get(), &bal_ctl_frame.data[1], WORD_SIZE);
			fill_can_data_buff(cluster_min_cell_soc_get(), &bal_ctl_frame.data[3], WORD_SIZE);
//			bal_ctl_frame.data[7] = can_single_frame_crc8_calc(&bal_ctl_frame, MASTER_CTL_SET_CRC8_MASK);
			can_sofar_send_frame(SDK_INTERNAL_CAN_PORT,bal_ctl_frame.id, bal_ctl_frame.data, bal_ctl_frame.data_len);
//		}
    }
}

// index 范围 0~PACK_MAX_NUM-1
pack_info_t* get_bmu_info(uint8_t index)
{
    if (index < PACK_MAX_NUM)
    {
        return &g_pack_data[index];
    }
    return NULL;
}

const pack_cell_info_t* get_bmu_cell_info(void)
{
    return &g_pack_cell_data;
}

const pack_other_device_info_t* get_other_device_info(void)
{
    return &g_pack_other_device_info;
}
// 接收任务处理接口
int32_t inner_can_sofar_frame_parse_deal(can_frame_data_t *p_can_data)
{
    if (p_can_data == NULL || INNER_RX_MSG_CNT > g_inner_rx_can_msg_list_len)
    {
        return 0;
    }
    can_frame_id_u frame_id = {p_can_data->id};
    for (uint8_t i = 0; i < g_inner_rx_can_msg_list_len; i++)
    {
        if (g_inner_rx_can_msg_list[i].func_code == frame_id.bit.fun_code)
        {
            if (g_inner_rx_can_msg_list[i].p_func_recv_deal_cb != NULL)
            {
                g_inner_rx_can_msg_list[i].p_func_recv_deal_cb(p_can_data, frame_id.bit.fun_code);
            }
        }
    }
    return 0;
}

/**
* @brief		内网初始化，并注册内网CAN ID
* @param		无
* @return		无
* @retval		无
* @warning		无
*/
void can_inner_data_init(void)
{
    uint16_t rec_msg_amount = 0;
    can_frame_id_u frame_id[] =
    {
       // res     prio(优先级)      type(帧类型)  flag（1:连续，0:非）, fun_code,    dst_type dst_addr, src_type, src_addr
        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_LOW_H,  .bit.fun_code= FUNC_MASTER_CTL_CMD,
            .bit.dst_type= DEV_BCU, .bit.dst_addr= 0, .bit.src_type= DEV_BMU, .bit.src_addr =0},
        {0x3c2}, // 霍尔器件信息
    };
    can_sofar_rcv_reg_t can_rxmsg_tab[] = // 接收上位机或BCU的数据
    {
        {frame_id[0].id_val, 0x07FFFF1F, inner_can_sofar_frame_parse_deal,},  //
        {frame_id[1].id_val, 0x00000000, inner_can_rx_hall_info,},  // 霍尔器件信息
    };

    // 注册接收的数据
    rec_msg_amount = sizeof(can_rxmsg_tab)/sizeof(can_sofar_rcv_reg_t);
    inner_can_sofar_register_receive_frame(can_rxmsg_tab, rec_msg_amount);
    // 初始化bmu遥测遥信点表
    pack_data_init();

    // 用于提示开发人员表格没有一一对应
    for (uint8_t list_cnt = 0; list_cnt < g_inner_rx_can_msg_list_len; list_cnt++)
    {
        if (g_inner_rx_can_msg_list[list_cnt].id != list_cnt)
        {
            log_e("canList%d Err%d,0x%x\n", list_cnt, g_inner_rx_can_msg_list[list_cnt].id, g_inner_rx_can_msg_list[list_cnt].func_code);
            break;
        }
    }
    // todo
    auto_send_can_inner_func_set(INN_AUTO_SEND_NORMAL_TYPE); // 启动自动发送内网数据（暂时放这，后续在BMU处于开机状态时打开）
}
/**
* @brief		内网数据初始化
* @param		无
* @return		无
* @retval		无
* @warning		无
*/
void pack_data_init(void)
{
    memset(g_pack_data, 0, sizeof(g_pack_data));
    memset(&g_pack_cell_data.cell_volt[0], 0xFF, sizeof(g_pack_cell_data.cell_volt));
    memset(&g_pack_cell_data.cell_temp[0], 0xFF, sizeof(g_pack_cell_data.cell_temp));
    memset(&g_pack_cell_data.cell_soc[0], 0, sizeof(g_pack_cell_data.cell_soc));
    memset(&g_pack_cell_data.cell_soh[0], 0, sizeof(g_pack_cell_data.cell_soh));    
    
//    for(uint16_t i = 0; i < get_bms_attr()->clu_pack_num * get_bms_attr()->pack_cell_num; i++ )
//    {
//        g_pack_cell_data.cell_volt[i] = 3300 + i;
//        g_pack_cell_data.cell_soc[i] = 0 + i % 100;
//        g_pack_cell_data.cell_soh[i] = 0 + i % 100;
//    }
//    
//    for(uint16_t i = 0; i < get_bms_attr()->clu_pack_num * get_bms_attr()->pack_temp_num; i++ )
//    {
//        g_pack_cell_data.cell_temp[i] = -40 + i % 100;
//    }    
}


/******************************************接收帧处理任务start******************************************************************/
// 接收bmu时间0x1026
static bool inner_can_rx_bmu_time(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }
    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;
    for (uint8_t i = 0; i < (YC1_UNS_TIME_END - YC1_UNS_TIME_START); i++)
    {
        g_pack_data[pack_id].yc1[YC1_UNS_TIME_START + i] = can_data->data[i];
    }
    return 0;
}

// 0x1070 电芯电压
#define RX_CELL_VOLT_ONE_PACKAGE_NUM  (30)
#define RX_CELL_VOLT_ONE_FRAME_NUM  (3)
static bool inner_can_rx_msg_cell_volt_overflow(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }

    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;
    uint8_t pack_frame_num = can_data->data[0];
    uint8_t package_num = can_data->data[1];
    uint8_t data_num = 0;
    if (pack_frame_num == 0 || package_num == 0)
    {
        return 0;
    }
    uint16_t one_cell_id = (package_num - 1) * RX_CELL_VOLT_ONE_PACKAGE_NUM + (pack_frame_num - 1) * RX_CELL_VOLT_ONE_FRAME_NUM;
    // 确认有效长度
    if (one_cell_id <= (get_bms_attr()->pack_cell_num - RX_CELL_VOLT_ONE_FRAME_NUM))
    {
        data_num = RX_CELL_VOLT_ONE_FRAME_NUM;
    }
    else
    {
        data_num = get_bms_attr()->pack_cell_num % RX_CELL_VOLT_ONE_FRAME_NUM;
    }
    // 判断数据是否异常
    if (data_num == 0)
    {
        return 0;
    }
    // 填充数据
    uint16_t start_sub_num = pack_id * get_bms_attr()->pack_cell_num + one_cell_id;
    for (uint8_t i = 0; i < data_num; i++)
    {
        g_pack_cell_data.cell_volt[start_sub_num + i] = MAKE_WORD(can_data->data[2 + 2 * i], can_data->data[3 + 2 * i]);
    }
    //log_d("pack_id = %d package_num = %d pack_frame_num = %d, one_cell_id = %d\n",pack_id, package_num, pack_frame_num,one_cell_id);

    return 0;
}

// 0x1071 电芯温度
#define RX_CELL_TEMP_ONE_PACKAGE_NUM  (30)
#define RX_CELL_TEMP_ONE_FRAME_NUM  (3)
static bool inner_can_rx_msg_cell_temp_overflow(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }

    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;
    uint8_t pack_frame_num = can_data->data[0];
    uint8_t package_num = can_data->data[1];
    uint8_t data_num = 0;
    if (pack_frame_num == 0 ||  package_num == 0)
    {
        return 0;
    }
    uint16_t one_cell_id = (package_num - 1) * RX_CELL_TEMP_ONE_PACKAGE_NUM + (pack_frame_num - 1) * RX_CELL_TEMP_ONE_FRAME_NUM;
    // 确认有效长度
    if (one_cell_id <= (get_bms_attr()->pack_temp_num - RX_CELL_TEMP_ONE_FRAME_NUM))
    {
        data_num = RX_CELL_TEMP_ONE_FRAME_NUM;
    }
    else
    {
        data_num = get_bms_attr()->pack_temp_num % RX_CELL_TEMP_ONE_FRAME_NUM;
    }
    // 判断数据是否异常
    if (data_num == 0)
    {
        return 0;
    }
    // 填充数据
    uint16_t start_sub_num = pack_id * get_bms_attr()->pack_temp_num + one_cell_id;
    for (uint8_t i = 0; i < data_num; i++)
    {
        if ((can_data->data[2 + 2 * i] != 0XFF) || (can_data->data[3 + 2 * i] != 0XFF))
        {
            g_pack_cell_data.cell_temp[start_sub_num + i] = ((int16_t)MAKE_WORD(can_data->data[2 + 2 * i], can_data->data[3 + 2 * i]) / 10);
        }
    }
    bcu_req_data_recv_ok_deal(rx_can_frame.bit.src_addr, INNER_BCU_REQ_BMU_CELL_TEMP_MSG);
    return 0;
}

// 0x1072 电芯被动均衡状态
static bool inner_can_rx_msg_cell_pass_bal_state_overflow(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }

    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;
    uint8_t pack_frame_num = can_data->data[0];
    uint64_t bal_stus = 0;
    
    if (pack_frame_num > 0x02)  //64S会发1/2，48S只会发1
    {
        return 0;
    }
    
    if(0x01 == pack_frame_num)  //每16S做一个高低位反转，方便外can发送
    {
        g_pack_cell_data.pass_bal_state[pack_id][1] = can_data->data[1];
        g_pack_cell_data.pass_bal_state[pack_id][0] = can_data->data[2];
        g_pack_cell_data.pass_bal_state[pack_id][3] = can_data->data[3];
        g_pack_cell_data.pass_bal_state[pack_id][2] = can_data->data[4];
        g_pack_cell_data.pass_bal_state[pack_id][5] = can_data->data[5];
        g_pack_cell_data.pass_bal_state[pack_id][4] = can_data->data[6];
        g_pack_cell_data.pass_bal_state[pack_id][7] = can_data->data[7];        
    }
    else if(0x02 == pack_frame_num)
    {
        g_pack_cell_data.pass_bal_state[pack_id][6] = can_data->data[1];
    }

    return 0;
}

// 0x004:BMS发送电池信息2
static bool inner_can_rx_msg_bms_inter_info2(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }

    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;
    g_pack_data[pack_id].yc2[YC2_UNS_PACK_VOLT] = MAKE_WORD(can_data->data[0], can_data->data[1]);
    g_pack_data[pack_id].yc2[YC2_UNS_LOAD_VOLT] = MAKE_WORD(can_data->data[2], can_data->data[3]);
    g_pack_data[pack_id].yc2[YC2_SGN_PACK_CURR] = MAKE_WORD(can_data->data[4], can_data->data[5]);
    g_pack_data[pack_id].yc2[YC2_UNS_PACK_SOC] = MAKE_WORD(can_data->data[6], can_data->data[7]);
    bcu_req_data_recv_ok_deal(rx_can_frame.bit.src_addr, INNER_BCU_REQ_BMU_SAM_MSG);
    return 0;
}

// 0x005:BMS发送电池信息3
static bool inner_can_rx_msg_bms_inter_info3(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }

    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;
    g_pack_data[pack_id].yc2[YC2_UNS_MAX_CELL_VOLT] = MAKE_WORD(can_data->data[0], can_data->data[1]);
    g_pack_data[pack_id].yc1[YC1_UNS_MAX_CELL_V_ID] = can_data->data[2];
    g_pack_data[pack_id].yc2[YC2_UNS_MIN_CELL_VOLT] = MAKE_WORD(can_data->data[3], can_data->data[4]);
    g_pack_data[pack_id].yc1[YC1_UNS_MIN_CELL_V_ID] = can_data->data[5];
    g_pack_data[pack_id].yc2[YC2_UNS_AVG_CELL_VOLT] = MAKE_WORD(can_data->data[6], can_data->data[7]);    
	return 0;
}

// 0x006:BMS发送电池信息4
static bool inner_can_rx_msg_bms_inter_info4(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }

    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;
    g_pack_data[pack_id].yc2[YC2_SGN_MAX_CELL_TEMP] = MAKE_WORD(can_data->data[0], can_data->data[1]);
    g_pack_data[pack_id].yc1[YC1_UNS_MAX_CELL_T_ID] = can_data->data[2];
    g_pack_data[pack_id].yc2[YC2_SGN_MIN_CELL_TEMP] = MAKE_WORD(can_data->data[3], can_data->data[4]);
    g_pack_data[pack_id].yc1[YC1_UNS_MIN_CELL_T_ID] = can_data->data[5];
    g_pack_data[pack_id].yc2[YC2_SGN_AVG_CELL_TEMP] = MAKE_WORD(can_data->data[6], can_data->data[7]);        
    return 0;
}

// 0x007:BMS发送电池信息5
static bool inner_can_rx_msg_bms_inter_info5(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }
    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;
    uint32_t data_tmp = 0;
    data_tmp = can_data->data[0] | can_data->data[1] << 8 | can_data->data[2] << 16 | can_data->data[3] << 24;
    g_pack_data[pack_id].yc3[YC3_UNS_TOTAL_CHG_CAP_AH] = data_tmp;
    data_tmp = can_data->data[4] | can_data->data[5] << 8 | can_data->data[6] << 16 | can_data->data[7] << 24;
    g_pack_data[pack_id].yc3[YC3_UNS_TOTAL_DSG_CAP_AH] = data_tmp;
    return 0;
}

// 0x008:BMS发送内部电池故障信息1
static bool inner_can_rx_msg_bms_fault_info1(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }
    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;
    g_pack_data[pack_id].yx[YX_BMU_PACK_CELL_VOLT_FAULT]     = can_data->data[0];
    g_pack_data[pack_id].yx[YX_BMU_CELL_TEMP_FAULT]          = can_data->data[1];
    g_pack_data[pack_id].yx[YX_BMU_CURR_TEMP_FAULT]          = can_data->data[2];
    g_pack_data[pack_id].yx[YX_BMU_SOC_SAM_FAULT]            = can_data->data[3];
    g_pack_data[pack_id].yx[YX_BMU_MOS_FAULT]                = can_data->data[4];
    g_pack_data[pack_id].yx[YX_BMU_CAN_FAULT]                = can_data->data[5];
    g_pack_data[pack_id].yx[YX_BMU_CHG_CURR_ZERO_VOLT_FAULT] = can_data->data[6];
    g_pack_data[pack_id].yx[YX_BMU_DSG_CURR_ZERO_VOLT_FAULT] = can_data->data[7];
    return 0;
}

// 0x00E：其他信息
static bool inner_can_rx_msg_bms_cell_other_info1(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }
    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;

    g_pack_data[pack_id].yc2[YC2_SGN_MOS_TEMP] = MAKE_WORD(can_data->data[0], can_data->data[1]);
    g_pack_data[pack_id].yc2[YC2_SGN_ENV_TEMP] = MAKE_WORD(can_data->data[2], can_data->data[3]);
    g_pack_data[pack_id].yc2[YC2_UNS_PACK_SOH] = MAKE_WORD(can_data->data[4], can_data->data[5]);
    bcu_req_data_recv_ok_deal(rx_can_frame.bit.src_addr, INNER_BCU_REQ_BMU_PACK_CAP_MSG);
    return 0;
}

// 0x00F：BMS发送电池信息6
static bool inner_can_rx_msg_bms_inter_info6(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }
    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;

    g_pack_data[pack_id].yc2[YC2_UNS_REMAIN_CAP_AH] = MAKE_WORD(can_data->data[0], can_data->data[1]);
    g_pack_data[pack_id].yc2[YC2_UNS_FULL_CAP_AH] = MAKE_WORD(can_data->data[2], can_data->data[3]);
    g_pack_data[pack_id].yc2[YC2_UNS_CYCLE_TIME] = MAKE_WORD(can_data->data[4], can_data->data[5]);

    return 0;
}

// 0x040：BMS发送电池信息7
static bool inner_can_rx_msg_bms_inter_info7(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }
    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;
    uint32_t data_tmp = 0;
    data_tmp = can_data->data[0] | can_data->data[1] << 8 | can_data->data[2] << 16 | can_data->data[3] << 24;
    g_pack_data[pack_id].yc3[YC3_UNS_TOTAL_CHG_CAP_WH] = data_tmp;
    data_tmp = can_data->data[4] | can_data->data[5] << 8 | can_data->data[6] << 16 | can_data->data[7] << 24;
    g_pack_data[pack_id].yc3[YC3_UNS_TOTAL_DSG_CAP_WH] = data_tmp;
    return 0;
}

// 0x041：BMS均衡温度1-2
static bool inner_can_rx_msg_bal_temp_info1(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }
    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;

    g_pack_data[pack_id].yc2[YC2_SGN_PASS_BAL_TEMP1] = MAKE_WORD(can_data->data[0], can_data->data[1]);
    g_pack_data[pack_id].yc2[YC2_SGN_PASS_BAL_TEMP2] = MAKE_WORD(can_data->data[2], can_data->data[3]);
    g_pack_data[pack_id].yc2[YC2_SGN_DCDC_TEMP1] = MAKE_WORD(can_data->data[4], can_data->data[5]);
    g_pack_data[pack_id].yc2[YC2_SGN_DCDC_TEMP2] = MAKE_WORD(can_data->data[6], can_data->data[7]);
    bcu_req_data_recv_ok_deal(rx_can_frame.bit.src_addr, INNER_BCU_REQ_BMU_BAL_MSG);
    return 0;
}

// 0x04A：BMS功率端子温度
static bool inner_can_rx_msg_power_mos_temp_info(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }
    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;

    g_pack_data[pack_id].yc2[YC2_SGN_POWER_TEMP1] = MAKE_WORD(can_data->data[0], can_data->data[1]);
    g_pack_data[pack_id].yc2[YC2_SGN_POWER_TEMP2] = MAKE_WORD(can_data->data[2], can_data->data[3]);
    return 0;
}

// 0x045:BMS发送内部电池故障信息2
static bool inner_can_rx_msg_bms_fault_info2(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }
    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;
    g_pack_data[pack_id].yx[YX_BMU_ACT_BAL_FAULT1]       = can_data->data[0];
    g_pack_data[pack_id].yx[YX_BMU_ACT_BAL_FAULT2]       = can_data->data[1];
    g_pack_data[pack_id].yx[YX_BMU_CELL_VOLT_LOCK_FAULT] = can_data->data[2];
    g_pack_data[pack_id].yx[YX_BMU_CELL_TEMP_LOCK_FAULT] = can_data->data[3];
    g_pack_data[pack_id].yx[YX_BMU_SAM_LINE_FAULT]       = can_data->data[4];
    g_pack_data[pack_id].yx[YX_BMU_HEAT_ALARM]           = can_data->data[5];
    g_pack_data[pack_id].yx[YX_BMU_OTHER_FAULT]          = can_data->data[6];
    g_pack_data[pack_id].yx[YX_BMU_RES3_FAULT]           = can_data->data[7];
    return 0;
}

// 0x04B:BMS发送内部电池故障信息3
static bool inner_can_rx_msg_bms_fault_info3(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }
    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;
    g_pack_data[pack_id].yx[YX_BMU_CELL_TIP1]       = can_data->data[0];
    g_pack_data[pack_id].yx[YX_BMU_CELL_TIP2]       = can_data->data[1];    
    g_pack_data[pack_id].yx[YX_BMU_CELL_ALARM]      = can_data->data[2];
    g_pack_data[pack_id].yx[YX_BMU_CELL_FAULT]      = can_data->data[4];
    g_pack_data[pack_id].yx[YX_BMU_FAULT_LEVEL]     = can_data->data[7];
    return 0;
}

// 0x04C:BMS发送放电末端校准信息
#define SLA_REPLY_DSG_END_SOC_DATA  1
#define SLA_REPLY_PASS_BAL_DATA     2
#define SLA_REPLY_ELECTROLYTE_DATA  3
static bool inner_can_rx_msg_bms_dsg_cali_info(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }

    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;
    if (can_data->data[0] == SLA_REPLY_DSG_END_SOC_DATA)
    {
        g_pack_data[pack_id].yx[YX_BMU_DSG_CALI_UTABLE_1]  = can_data->data[1];
        g_pack_data[pack_id].yx[YX_BMU_DSG_CALI_UTABLE_2]  = can_data->data[2];
        g_pack_data[pack_id].yx[YX_BMU_DSG_CALI_SOC_1]  = can_data->data[3];
        g_pack_data[pack_id].yx[YX_BMU_DSG_CALI_SOC_2]  = can_data->data[4];
        g_pack_data[pack_id].yx[YX_BMU_DSG_CALI_MIN_CELL_VOL_1]  = can_data->data[5];
        g_pack_data[pack_id].yx[YX_BMU_DSG_CALI_MIN_CELL_VOL_2]  = can_data->data[6];
    }
    else if (can_data->data[0] == SLA_REPLY_PASS_BAL_DATA)
    {
        g_pack_data[pack_id].yc2[YC2_BMU_BAL_STATE] = MAKE_WORD(can_data->data[1], can_data->data[2]);
        g_pack_data[pack_id].yc2[YC2_MIN_CELL_SOC] = MAKE_WORD(can_data->data[3], can_data->data[4]);
    }
    else if (can_data->data[0] == SLA_REPLY_ELECTROLYTE_DATA)
    {
        g_pack_data[pack_id].yc2[YC2_ELECTROLYTE_STREN] = MAKE_WORD(can_data->data[1], can_data->data[2]);
    }    
    return 0;
}

// 0x046：遥信数据上报1
static bool inner_can_rx_msg_bms_remote_signal_info1(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t crc_check = can_single_frame_crc8_calc(can_data, MASTER_CTL_SET_CRC8_MASK);
    if (crc_check != can_data->data[7])
    {
        return 0;
    }
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }
    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;
    g_pack_data[pack_id].yx[YX_BMU_REQ_ENABLE_1]  = can_data->data[0];
    g_pack_data[pack_id].yx[YX_BMU_REQ_ENABLE_2]  = can_data->data[1];
    g_pack_data[pack_id].yx[YX_BMU_CHG_DSG_STATE] = can_data->data[2];
    g_pack_data[pack_id].yx[YX_BMU_DI_STATE] = can_data->data[6];

    bmu_bcu_comm_fault_check(pack_id);
    if (ADDRESSING_FINISH != auto_addressing_get_state())
    {
        inner_addr_rcv_callback(can_data, func_code);
    }
    return 0;
}

// 0x047：遥信数据上报2
static bool inner_can_rx_msg_bms_remote_signal_info2(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }
    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;
    g_pack_data[pack_id].yx[YX_BMU_SYNC_FALL_SOC]  = can_data->data[0];
    g_pack_data[pack_id].yx[YX_BMU_SYS_STATE]  = can_data->data[1];
    g_pack_data[pack_id].yx[YX_BMU_ACT_BAL_STATE] = can_data->data[2];
    g_pack_data[pack_id].yx[YX_BMU_CHG_CURR_LIMIT_L] = can_data->data[4];
    g_pack_data[pack_id].yx[YX_BMU_CHG_CURR_LIMIT_H] = can_data->data[5];
    g_pack_data[pack_id].yx[YX_BMU_DSG_CURR_LIMIT_L] = can_data->data[6];
    g_pack_data[pack_id].yx[YX_BMU_DSG_CURR_LIMIT_H] = can_data->data[7];
    return 0;
}

// 0x048：主动均衡数据上报1
static bool inner_can_rx_msg_act_bal_info1(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }
    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;

    g_pack_data[pack_id].yc2[YC2_UNS_ACT_BAL_PRI_VOLT] = MAKE_WORD(can_data->data[0], can_data->data[1]);
    g_pack_data[pack_id].yc2[YC2_SGN_ACT_BAL_PRI_CURR] = MAKE_WORD(can_data->data[2], can_data->data[3]);
    g_pack_data[pack_id].yc2[YC2_UNS_ACT_BAL_MAX_CELL_VOLT] = MAKE_WORD(can_data->data[4], can_data->data[5]);

    return 0;
}

// 0x049：主动均衡数据上报2
static bool inner_can_rx_msg_act_bal_info2(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }
    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;
    g_pack_data[pack_id].yc2[YC2_UNS_ACT_BAL_CELL_SOC] = MAKE_WORD(can_data->data[0], can_data->data[1]);
    g_pack_data[pack_id].yc2[YC2_UNS_ACT_BAL_ACC_CAP] = MAKE_WORD(can_data->data[2], can_data->data[3]);
    g_pack_data[pack_id].yc2[YC2_UNS_ACT_BAL_REMAIN_CAP] = MAKE_WORD(can_data->data[4], can_data->data[5]);
    return 0;
}

// 0x06A：设备软件版信息1
static bool inner_can_rx_msg_soft_ver_info1(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }
    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;
    g_pack_data[pack_id].dev[BMU_DEV_SW_VT_VER]  = can_data->data[0];
    g_pack_data[pack_id].dev[BMU_DEV_SW_BIG_VER]  = can_data->data[1];
    g_pack_data[pack_id].dev[BMU_DEV_SW_MIDDLE_VER] = can_data->data[2];
    g_pack_data[pack_id].dev[BMU_DEV_SW_SAMLL_VER] = can_data->data[3];
    g_pack_data[pack_id].dev[BMU_DEV_HW_VER] = can_data->data[4];
    g_pack_data[pack_id].dev[BMU_DEV_CAN_VER_L] = can_data->data[5];
    g_pack_data[pack_id].dev[BMU_DEV_CAN_VER_H] = can_data->data[6];

    return 0;
}

// 0x06B：设备软件版信息3
static bool inner_can_rx_msg_soft_ver_info2(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }
    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;
    g_pack_data[pack_id].dev[BMU_DEV_SYS_CAP_L]  = can_data->data[0];
    g_pack_data[pack_id].dev[BMU_DEV_SYS_CAP_H]  = can_data->data[1];
    g_pack_data[pack_id].dev[BMU_DEV_MANU_REG_ID_L] = can_data->data[2];
    g_pack_data[pack_id].dev[BMU_DEV_MANU_REG_ID_H] = can_data->data[3];
    g_pack_data[pack_id].dev[BMU_DEV_BAT_TYPE_L] = can_data->data[4];
    g_pack_data[pack_id].dev[BMU_DEV_BAT_TYPE_H] = can_data->data[5];

    return 0;
}

// 0x06C：设备软件版信息4
static bool inner_can_rx_msg_soft_ver_info3(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }

    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;
    g_pack_data[pack_id].dev[BMU_DEV_MANU_NAME1_L] = can_data->data[0];
    g_pack_data[pack_id].dev[BMU_DEV_MANU_NAME1_H] = can_data->data[1];
    g_pack_data[pack_id].dev[BMU_DEV_MANU_NAME2_L] = can_data->data[2];
    g_pack_data[pack_id].dev[BMU_DEV_MANU_NAME2_H] = can_data->data[3];
    g_pack_data[pack_id].dev[BMU_DEV_MANU_NAME3_L] = can_data->data[4];
    g_pack_data[pack_id].dev[BMU_DEV_MANU_NAME3_H] = can_data->data[5];
    g_pack_data[pack_id].dev[BMU_DEV_MANU_NAME4_L] = can_data->data[6];
    g_pack_data[pack_id].dev[BMU_DEV_MANU_NAME4_H] = can_data->data[7];
    return 0;
}

// 0x06D：其他数据上报
static bool inner_can_rx_msg_bms_remote_signal_info3(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }
    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;
    g_pack_data[pack_id].yc2[YC2_UNS_AUX_VOLT] = MAKE_WORD(can_data->data[0], can_data->data[1]);
    g_pack_data[pack_id].yc2[YC2_UNS_CHG_CURR_ZERO_VOLT] = MAKE_WORD(can_data->data[2], can_data->data[3]);
    g_pack_data[pack_id].yc2[YC2_UNS_DSG_CURR_ZERO_VOLT] = MAKE_WORD(can_data->data[4], can_data->data[5]);
    g_pack_data[pack_id].yc1[YC1_UNS_BMU_RESET_TYPE] = can_data->data[6];
    return 0;
}

// 0x0A0：BMS电池SOC
#define SOX_INFO_ONE_GROUP_NUM (7)
static bool inner_can_rx_msg_bmu_soc_info(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }

    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;
    uint8_t pack_group_num = can_data->data[0];
    uint8_t data_num = 0;
    // 清除SOC数据接收计时器
    if (pack_group_num == 0)
    {
        bcu_req_data_recv_ok_deal(rx_can_frame.bit.src_addr, INNER_BCU_REQ_BMU_CELL_SOC_MSG);
    }
    // 确认有效长度
    if (pack_group_num < PACK_CELL_GROUP_NUM)
    {
        data_num = SOX_INFO_ONE_GROUP_NUM;
    }
    else if (pack_group_num == PACK_CELL_GROUP_NUM)
    {
        data_num = (get_bms_attr()->pack_cell_num % SOX_INFO_ONE_GROUP_NUM == 0)? SOX_INFO_ONE_GROUP_NUM : (get_bms_attr()->pack_cell_num % SOX_INFO_ONE_GROUP_NUM);
    }
    // 判断数据是否异常
    if (data_num == 0)
    {
        return 0;
    }
    // 填充数据
    uint16_t start_sub_num = pack_id * get_bms_attr()->pack_cell_num + pack_group_num * SOX_INFO_ONE_GROUP_NUM;
    for (uint8_t i = 0; i < data_num; i++)
    {
        g_pack_cell_data.cell_soc[start_sub_num + i] = can_data->data[1 + i];
    }
    return 0;
}

// 0x0A1：BMS电池SOH
static bool inner_can_rx_msg_bmu_soh_info(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }
    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;
    uint8_t pack_group_num = can_data->data[0];
    uint8_t data_num = 0;
    // 清除SOH数据接收计时器
    if (pack_group_num == 0)
    {
        bcu_req_data_recv_ok_deal(rx_can_frame.bit.src_addr, INNER_BCU_REQ_BMU_CELL_SOH_MSG);
    }
    // 确认有效长度
    if (pack_group_num < PACK_CELL_GROUP_NUM)
    {
        data_num = SOX_INFO_ONE_GROUP_NUM;
    }
    else if (pack_group_num == PACK_CELL_GROUP_NUM)
    {
        data_num = (get_bms_attr()->pack_cell_num % SOX_INFO_ONE_GROUP_NUM == 0)? SOX_INFO_ONE_GROUP_NUM : (get_bms_attr()->pack_cell_num % SOX_INFO_ONE_GROUP_NUM);
    }
    // 判断数据是否异常
    if (data_num == 0)
    {
        return 0;
    }
    // 填充数据
    uint16_t start_sub_num = pack_id * get_bms_attr()->pack_cell_num + pack_group_num * SOX_INFO_ONE_GROUP_NUM;
    for (uint8_t i = 0; i < data_num; i++)
    {
        g_pack_cell_data.cell_soh[start_sub_num + i] = can_data->data[1 + i];
    }
    return 0;
}

// 解析PACK_SN标定回复0x1027E0XX
static bool inner_can_rx_msg_bmu_pack_sn_info(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }
    if (can_data->data[0] > 2) // 大于21个数异常，不处理
    {
        return 0;
    }
    uint16_t time = can_data->data[0];
    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;
    g_pack_data[pack_id].dev[BMU_DEV_PACK_SN1 + time * 7]  = can_data->data[1];
    g_pack_data[pack_id].dev[BMU_DEV_PACK_SN2 + time * 7]  = can_data->data[2];
    g_pack_data[pack_id].dev[BMU_DEV_PACK_SN3 + time * 7]  = can_data->data[3];
    g_pack_data[pack_id].dev[BMU_DEV_PACK_SN4 + time * 7]  = can_data->data[4];
    g_pack_data[pack_id].dev[BMU_DEV_PACK_SN5 + time * 7]  = can_data->data[5];
    g_pack_data[pack_id].dev[BMU_DEV_PACK_SN6 + time * 7]  = can_data->data[6];
    g_pack_data[pack_id].dev[BMU_DEV_PACK_SN7 + time * 7]  = can_data->data[7];
    return 0;
}

// BOARD_SN标定回复0x1028E0XX
static bool inner_can_rx_msg_bmu_board_sn_info(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u rx_can_frame = {can_data->id};
    if (rx_can_frame.bit.src_addr <= 0 || rx_can_frame.bit.src_addr > PACK_MAX_NUM)
    {
        return 0;
    }
    if (can_data->data[0] > 2) // 大于21个数异常，不处理
    {
        return 0;
    }
    uint16_t time = can_data->data[0];
    uint8_t pack_id = rx_can_frame.bit.src_addr - 1;
    g_pack_data[pack_id].dev[BMU_DEV_BOARD_SN1 + time * 7]  = can_data->data[1];
    g_pack_data[pack_id].dev[BMU_DEV_BOARD_SN2 + time * 7]  = can_data->data[2];
    g_pack_data[pack_id].dev[BMU_DEV_BOARD_SN3 + time * 7]  = can_data->data[3];
    g_pack_data[pack_id].dev[BMU_DEV_BOARD_SN4 + time * 7]  = can_data->data[4];
    g_pack_data[pack_id].dev[BMU_DEV_BOARD_SN5 + time * 7]  = can_data->data[5];
    g_pack_data[pack_id].dev[BMU_DEV_BOARD_SN6 + time * 7]  = can_data->data[6];
    g_pack_data[pack_id].dev[BMU_DEV_BOARD_SN7 + time * 7]  = can_data->data[7];
    return 0;
}

// 0x03C2: 霍尔器件信息
static int32_t inner_can_rx_hall_info(can_frame_data_t *can_data)
{
    g_pack_other_device_info.called = 1;
    g_pack_other_device_info.error_information = can_data->data[4] & 0x01;
    g_pack_other_device_info.rx_quality = (can_data->data[4] >> 1) & 0x7F;
    g_pack_other_device_info.hall_data[0] = can_data->data[0];
    g_pack_other_device_info.hall_data[1] = can_data->data[1];
    g_pack_other_device_info.hall_data[2] = can_data->data[2];
    g_pack_other_device_info.hall_data[3] = can_data->data[3];

    g_pack_other_device_info.hall_data_deal = g_pack_other_device_info.hall_data[3] | (g_pack_other_device_info.hall_data[2] << 8) |
                                    (g_pack_other_device_info.hall_data[1] << 16) | (g_pack_other_device_info.hall_data[0] << 24) - (uint32_t)0x80000000;

    can_hall_sensor_comm_err_cnt_clr();

    return 0;
}

/******************************************接收任务end**************************************************************************/

/******************************************发送任务start**************************************************************************/
// 0x060:BMS控制信息3-设置状态参数/电流
static bool inner_can_tx_master_curr_set_cmd(uint32_t frame_id)
{
    const sample_data_t* p_sample_data = p_sample_data_get();
    const bmu_data_unify_t *p_bmu_data_unify = bmu_data_unify_get();
    static uint8_t send_cnt = 0;
    if (NULL == p_sample_data || NULL == p_bmu_data_unify)
    {
        return 0;
    }
    can_bat_status_u  bat_data = {0};
    can_frame_data_t frame_data = {0};
    bat_data.bit.bat_sta = bms_state_get_bat_sta();
    if (control_bmu_shut_down_flag_get() == 0xAA)
    {
        bat_data.bit.shut_down_sta = 1;
    }
    if (control_bmu_shut_down_flag_get() == 0xAA)
    {
        bat_data.bit.shut_down_sta = 1;
    }
    if (p_bmu_data_unify->empty_full_flag & 0xAA)
    {
        bat_data.bit.full_chg_sta = 1;
    }
    if (p_bmu_data_unify->empty_full_flag & 0xAA00)
    {
        bat_data.bit.empty_sta = 1;
    }
    
    if(get_gobal_bcu_info()->set_fault_recover_flag)
    {
        bat_data.bit.pack_recover = 1;
        if(++send_cnt >= 6)    //给下面的BMU下发6次故障复归，这里发6次的原因是BMU出现严重问题需要复位时，从接收到命令到复位需要3.5S，防止复位后仍收到该命令后再做一次复归
        {
            send_cnt = 0;
            bat_data.bit.pack_recover = 0;
            cluster_bcu_fault_recover_set(false);
            // BCU故障初始化
            fault_manage_init();
            fault_diag_enable();
        }
    }

    frame_data.id = frame_id;
    frame_data.data_len = CAN_SIGNAL_FRA_MAX_NUMS;
    fill_can_data_buff(p_sample_data->sys_current / 10, &frame_data.data[0], WORD_SIZE); //  系统电流 单位0.01A
    frame_data.data[2] = bat_data.all;
    frame_data.data[3] = p_bmu_data_unify->max_sync_fall_soc;
    frame_data.data[7] = can_single_frame_crc8_calc(&frame_data, MASTER_CTL_SET_CRC8_MASK);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_id, frame_data.data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 设置被动均衡状态0x101EFFE0
bool inner_can_tx_pass_bal_set(can_frame_data_t *can_data, uint16_t func_code)
{
    can_frame_id_u frame_val = {0};
    frame_val.bit.dst_type = DEV_BMU;
    frame_val.bit.src_addr = BCU_INNER_CAN_ADDR;
    frame_val.bit.src_type = DEV_BCU;
    frame_val.bit.prio = SOFAR_CAN_PRI_LOW_H;
    frame_val.bit.fun_code = FUNC_ATE_PASS_BAL_CMD;

    if (PACK_CELL_NUM_48 == get_bms_attr()->pack_cell_num)
    {
        frame_val.bit.dst_addr = can_data->data[1];
    }
    else if (PACK_CELL_NUM_64 == get_bms_attr()->pack_cell_num)
    {
        frame_val.bit.dst_addr = (can_data->data[1] + 1) / 2;
    }
    
    return can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_val.id_val, can_data->data, CAN_SIGNAL_FRA_MAX_NUMS);;
}

// 时间标定0x1026FFE0
static bool inner_can_tx_time_set(uint32_t frame_id)
{
    sdk_rtc_t rtc_time = {0};
    sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
    can_frame_data_t frame_data = {0};

    frame_data.id = frame_id;
    frame_data.data_len = 6;
    frame_data.data[0] = rtc_time.tm_year;
    frame_data.data[1] = rtc_time.tm_mon;
    frame_data.data[2] = rtc_time.tm_day;
    frame_data.data[3] = rtc_time.tm_hour;
    frame_data.data[4] = rtc_time.tm_min;
    frame_data.data[5] = rtc_time.tm_sec;
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_id, frame_data.data, 6);
    return 0;
}

// bmu告警阈值标定
static bool inner_can_tx_bmu_alm_thre_val_set(void)
{
    const bms_attr_t *p_bms_attr = get_bms_attr();
    if (p_bms_attr == NULL)
    {
        return 0;
    }
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u frame_val = {0};
    frame_val.bit.dst_addr = BROCAST_DEVICE_ADDRESS;
    frame_val.bit.dst_type = DEV_BMU;
    frame_val.bit.src_addr = BCU_INNER_CAN_ADDR;
    frame_val.bit.src_type = DEV_BCU;
    frame_val.bit.prio = SOFAR_CAN_PRI_LOW_H;

    // 0x1010 单体过充故障参数设置
    frame_val.bit.fun_code = FUNC_CELL_VOLT_OVER_ALM_SET;
    data[0] = LOW_BYTE(p_bms_attr->safety.cell_over_vol_protect.appear_value);
    data[1] = HIGH_BYTE(p_bms_attr->safety.cell_over_vol_protect.appear_value);
    data[2] = LOW_BYTE(p_bms_attr->safety.cell_over_vol_protect.cancel_value);
    data[3] = HIGH_BYTE(p_bms_attr->safety.cell_over_vol_protect.cancel_value);
    data[4] = LOW_BYTE(p_bms_attr->safety.cell_over_vol_alarm.appear_value);
    data[5] = HIGH_BYTE(p_bms_attr->safety.cell_over_vol_alarm.appear_value);
    data[6] = LOW_BYTE(p_bms_attr->safety.cell_over_vol_alarm.cancel_value);
    data[7] = HIGH_BYTE(p_bms_attr->safety.cell_over_vol_alarm.cancel_value);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_val.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

    // 0x011,  // 总体过充故障参数设置
    frame_val.bit.fun_code = FUNC_BAT_VOLT_OVER_ALM_SET;
    data[0] = LOW_BYTE(p_bms_attr->safety.bat_over_vol_protect.appear_value);
    data[1] = HIGH_BYTE(p_bms_attr->safety.bat_over_vol_protect.appear_value);
    data[2] = LOW_BYTE(p_bms_attr->safety.bat_over_vol_protect.cancel_value);
    data[3] = HIGH_BYTE(p_bms_attr->safety.bat_over_vol_protect.cancel_value);
    data[4] = LOW_BYTE(p_bms_attr->safety.bat_over_vol_alarm.appear_value);
    data[5] = HIGH_BYTE(p_bms_attr->safety.bat_over_vol_alarm.appear_value);
    data[6] = LOW_BYTE(p_bms_attr->safety.bat_over_vol_alarm.cancel_value);
    data[7] = HIGH_BYTE(p_bms_attr->safety.bat_over_vol_alarm.cancel_value);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_val.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

    // 0x012,  // 单体过放故障参数设置
    frame_val.bit.fun_code = FUNC_CELL_VOLT_UNDER_ALM_SET;
    data[0] = LOW_BYTE(p_bms_attr->safety.cell_under_vol_protect.appear_value);
    data[1] = HIGH_BYTE(p_bms_attr->safety.cell_under_vol_protect.appear_value);
    data[2] = LOW_BYTE(p_bms_attr->safety.cell_under_vol_protect.cancel_value);
    data[3] = HIGH_BYTE(p_bms_attr->safety.cell_under_vol_protect.cancel_value);
    data[4] = LOW_BYTE(p_bms_attr->safety.cell_under_vol_alarm.appear_value);
    data[5] = HIGH_BYTE(p_bms_attr->safety.cell_under_vol_alarm.appear_value);
    data[6] = LOW_BYTE(p_bms_attr->safety.cell_under_vol_alarm.cancel_value);
    data[7] = HIGH_BYTE(p_bms_attr->safety.cell_under_vol_alarm.cancel_value);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_val.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

    // 0x013,  // 总体过放故障参数设置
    frame_val.bit.fun_code = FUNC_BAT_VOLT_UNDER_ALM_SET;
    data[0] = LOW_BYTE(p_bms_attr->safety.bat_under_vol_protect.appear_value);
    data[1] = HIGH_BYTE(p_bms_attr->safety.bat_under_vol_protect.appear_value);
    data[2] = LOW_BYTE(p_bms_attr->safety.bat_under_vol_protect.cancel_value);
    data[3] = HIGH_BYTE(p_bms_attr->safety.bat_under_vol_protect.cancel_value);
    data[4] = LOW_BYTE(p_bms_attr->safety.bat_under_vol_alarm.appear_value);
    data[5] = HIGH_BYTE(p_bms_attr->safety.bat_under_vol_alarm.appear_value);
    data[6] = LOW_BYTE(p_bms_attr->safety.bat_under_vol_alarm.cancel_value);
    data[7] = HIGH_BYTE(p_bms_attr->safety.bat_under_vol_alarm.cancel_value);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_val.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

    // 0x016,  // 电芯高温故障参数设置
    frame_val.bit.fun_code = FUNC_CELL_TEMP_OVER_ALM_SET;
    data[0] = (p_bms_attr->safety.chg_over_cell_temp_protect.appear_value / 10 + 40);
    data[1] = (p_bms_attr->safety.chg_over_cell_temp_protect.cancel_value / 10 + 40);
    data[2] = (p_bms_attr->safety.chg_over_cell_temp_alarm.appear_value / 10 + 40);
    data[3] = (p_bms_attr->safety.chg_over_cell_temp_alarm.cancel_value / 10 + 40);
    data[4] = (p_bms_attr->safety.dchg_over_cell_temp_protect.appear_value / 10 + 40);
    data[5] = (p_bms_attr->safety.dchg_over_cell_temp_protect.cancel_value / 10 + 40);
    data[6] = (p_bms_attr->safety.dchg_over_cell_temp_alarm.appear_value / 10 + 40);
    data[7] = (p_bms_attr->safety.dchg_over_cell_temp_alarm.cancel_value / 10 + 40);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_val.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

    // 0x017,  // 电芯低温故障参数设置
    frame_val.bit.fun_code = FUNC_CELL_TEMP_UNDER_ALM_SET;
    data[0] = (p_bms_attr->safety.chg_under_cell_temp_protect.appear_value / 10 + 40);
    data[1] = (p_bms_attr->safety.chg_under_cell_temp_protect.cancel_value / 10 + 40);
    data[2] = (p_bms_attr->safety.chg_under_cell_temp_alarm.appear_value / 10 + 40);
    data[3] = (p_bms_attr->safety.chg_under_cell_temp_alarm.cancel_value / 10 + 40);
    data[4] = (p_bms_attr->safety.dchg_under_cell_temp_protect.appear_value / 10 + 40);
    data[5] = (p_bms_attr->safety.dchg_under_cell_temp_protect.cancel_value / 10 + 40);
    data[6] = (p_bms_attr->safety.dchg_under_cell_temp_alarm.appear_value / 10 + 40);
    data[7] = (p_bms_attr->safety.dchg_under_cell_temp_alarm.cancel_value / 10 + 40);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_val.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

    // 0x080,  // 单体电压过充、过放提示标定
    frame_val.bit.fun_code = FUNC_CELL_VOLT_TIP_SET;
    data[0] = LOW_BYTE(p_bms_attr->safety.cell_over_vol_tip.appear_value);
    data[1] = HIGH_BYTE(p_bms_attr->safety.cell_over_vol_tip.appear_value);
    data[2] = LOW_BYTE(p_bms_attr->safety.cell_over_vol_tip.cancel_value);
    data[3] = HIGH_BYTE(p_bms_attr->safety.cell_over_vol_tip.cancel_value);
    data[4] = LOW_BYTE(p_bms_attr->safety.cell_under_vol_tip.appear_value);
    data[5] = HIGH_BYTE(p_bms_attr->safety.cell_under_vol_tip.appear_value);
    data[6] = LOW_BYTE(p_bms_attr->safety.cell_under_vol_tip.cancel_value);
    data[7] = HIGH_BYTE(p_bms_attr->safety.cell_under_vol_tip.cancel_value);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_val.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

    // 0x081,  // 单体电压压差过大提示、告警标定
    frame_val.bit.fun_code = FUNC_CELL_VOLT_DIFF_1_SET;
    data[0] = LOW_BYTE(p_bms_attr->safety.cell_vol_diff_tip.appear_value);
    data[1] = HIGH_BYTE(p_bms_attr->safety.cell_vol_diff_tip.appear_value);
    data[2] = LOW_BYTE(p_bms_attr->safety.cell_vol_diff_tip.cancel_value);
    data[3] = HIGH_BYTE(p_bms_attr->safety.cell_vol_diff_tip.cancel_value);
    data[4] = LOW_BYTE(p_bms_attr->safety.cell_vol_diff_alarm.appear_value);
    data[5] = HIGH_BYTE(p_bms_attr->safety.cell_vol_diff_alarm.appear_value);
    data[6] = LOW_BYTE(p_bms_attr->safety.cell_vol_diff_alarm.cancel_value);
    data[7] = HIGH_BYTE(p_bms_attr->safety.cell_vol_diff_alarm.cancel_value);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_val.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

    // 0x082,  // 单体电压压差过大故障标定
    frame_val.bit.fun_code = FUNC_CELL_VOLT_DIFF_2_SET;
    data[0] = LOW_BYTE(p_bms_attr->safety.cell_vol_diff_protect.appear_value);
    data[1] = HIGH_BYTE(p_bms_attr->safety.cell_vol_diff_protect.appear_value);
    data[2] = LOW_BYTE(p_bms_attr->safety.cell_vol_diff_protect.cancel_value);
    data[3] = HIGH_BYTE(p_bms_attr->safety.cell_vol_diff_protect.cancel_value);
    data[4] = 0;
    data[5] = 0;
    data[6] = 0;
    data[7] = 0;
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_val.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

    // 0x083,  // 电芯温度充放电高低温提示标定
    frame_val.bit.fun_code = FUNC_CELL_TEMP_TIP_SET;
    data[0] = (p_bms_attr->safety.chg_over_cell_temp_tip.appear_value / 10 + 40);
    data[1] = (p_bms_attr->safety.chg_over_cell_temp_tip.cancel_value / 10 + 40);
    data[2] = (p_bms_attr->safety.chg_under_cell_temp_tip.appear_value / 10 + 40);
    data[3] = (p_bms_attr->safety.chg_under_cell_temp_tip.cancel_value / 10 + 40);
    data[4] = (p_bms_attr->safety.dchg_over_cell_temp_tip.appear_value / 10 + 40);
    data[5] = (p_bms_attr->safety.dchg_over_cell_temp_tip.cancel_value / 10 + 40);
    data[6] = (p_bms_attr->safety.dchg_under_cell_temp_tip.appear_value / 10 + 40);
    data[7] = (p_bms_attr->safety.dchg_under_cell_temp_tip.cancel_value / 10 + 40);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_val.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

    // 0x084,  // 电芯温差过大提示，告警、保护标定
    frame_val.bit.fun_code = FUNC_CELL_TEMP_DIFF_SET;
    data[0] = (p_bms_attr->safety.cell_temp_diff_tip.appear_value / 10);
    data[1] = (p_bms_attr->safety.cell_temp_diff_tip.cancel_value / 10);
    data[2] = (p_bms_attr->safety.cell_temp_diff_alarm.appear_value / 10);
    data[3] = (p_bms_attr->safety.cell_temp_diff_alarm.cancel_value / 10);
    data[4] = (p_bms_attr->safety.cell_temp_diff_protect.appear_value / 10);
    data[5] = (p_bms_attr->safety.cell_temp_diff_protect.cancel_value / 10);
    data[6] = 0;
    data[7] = 0;
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_val.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

    // 0x085,  // 总压过压欠压提示标定
    frame_val.bit.fun_code = FUNC_BATT_VOLT_TIP_SET;
    data[0] = LOW_BYTE(p_bms_attr->safety.bat_over_vol_tip.appear_value);
    data[1] = HIGH_BYTE(p_bms_attr->safety.bat_over_vol_tip.appear_value);
    data[2] = LOW_BYTE(p_bms_attr->safety.bat_over_vol_tip.cancel_value);
    data[3] = HIGH_BYTE(p_bms_attr->safety.bat_over_vol_tip.cancel_value);
    data[4] = LOW_BYTE(p_bms_attr->safety.bat_under_vol_tip.appear_value);
    data[5] = HIGH_BYTE(p_bms_attr->safety.bat_under_vol_tip.appear_value);
    data[6] = LOW_BYTE(p_bms_attr->safety.bat_under_vol_tip.cancel_value);
    data[7] = HIGH_BYTE(p_bms_attr->safety.bat_under_vol_tip.cancel_value);
    can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_val.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}
// bmu告警阈值处理 10ms任务
#define BMU_THRE_ALARM_VAL_GET_CYCLE_B10MS 50
#define BMU_THRE_ALARM_ERR_MAX_TIME        10
void bmu_alarm_thre_val_deal(void)
{
    static uint16_t tick = 0;
    static uint8_t last_pack_num = 0;
    uint8_t pack_num = auto_addressing_pack_num_get();
    uint8_t i = 0;
    uint8_t thre_val_sync_suc_pack_no = 0;
    // 启动检测
    if (last_pack_num == 0 && pack_num != 0)
    {
        g_bmu_alarm_thre_val_check_flag = true;
        g_bmu_alm_thre_val_sync_state = SYNC_THRE_VAL_INIT;
    }
    last_pack_num = pack_num;

    // 进入条件过滤
    if (g_bmu_alarm_thre_val_check_flag == false ||
        pack_num == 0)
    {
        return;
    }

    // 500ms 执行一次
    if (++tick < BMU_THRE_ALARM_VAL_GET_CYCLE_B10MS)
    {
        return;
    }
    tick = 0;

    switch (g_bmu_alm_thre_val_sync_state)
    {
        case SYNC_THRE_VAL_INIT:
            // 广播同步告警阈值
            inner_can_tx_bmu_alm_thre_val_set();
            g_bmu_alm_thre_val_sync_state = SYNC_THRE_VAL_CHECK;
            break;
        case SYNC_THRE_VAL_CHECK:
            
            g_bmu_alarm_thre_val_check_err_time++;
            if (g_bmu_alarm_thre_val_check_err_time >= BMU_THRE_ALARM_ERR_MAX_TIME)
            {
                g_bmu_alm_thre_val_sync_state = SYNC_THRE_VAL_ERR;
            }
            else
            {
                g_bmu_alm_thre_val_sync_state = SYNC_THRE_VAL_INIT;
            }
            
            // 判断bmu是否已经接收完成
            for (i = 0; i < pack_num; i++)
            {
                if (g_pack_data[i].yx[YX_BMU_REQ_ENABLE_1] & 0x20) // 对应上报bmu请求阈值信号
                {
                    thre_val_sync_suc_pack_no++;
                }
            }
            if (thre_val_sync_suc_pack_no == pack_num)
            {
                g_bmu_alm_thre_val_sync_state = SYNC_THRE_VAL_SUCC;
            }
            break;
        case SYNC_THRE_VAL_SUCC:
        case SYNC_THRE_VAL_ERR:
            // 结束本次检测
            g_bmu_alarm_thre_val_check_err_time = 0;
            g_bmu_alarm_thre_val_check_flag = false;
            log_e("bmu_alarm_thre_sync stus:%d\r\n",g_bmu_alm_thre_val_sync_state);
            break;
        default:
            break;
    }
}

// 获取参数异常标志
// 更新发送周期时间
// 发送数据周期更新
void can_inner_auto_send_cycle_update(void)
{
#define SLOW_TIME  10
    static uint8_t last_ext_send_data_type = INN_AUTO_SEND_DATA_TYPE_NUM;
    if (g_inner_send_data_enable == last_ext_send_data_type)
    {
        return;
    }
    if (INN_AUTO_SEND_NORMAL_TYPE == g_inner_send_data_enable)
    {
        g_inner_tx_can_msg_list[0].send_period = CYCLE_SEND_500MS;
    }
    else if (INN_AUTO_SEND_SLOW_TYPE == g_inner_send_data_enable)
    {
        g_inner_tx_can_msg_list[0].send_period = CYCLE_SEND_500MS * SLOW_TIME;
    }
    last_ext_send_data_type = g_inner_send_data_enable;
}

// 内can循环发送任务
void can_inner_data_send_proc(void)
{
    tx_inner_can_msg_tcb_t *msg_info = NULL;
    uint16_t i = 0;
    uint8_t send_ready = false;
    if (special_mode_get(ATUO_TEST))
    {
        return;
    }
    bmu_alarm_thre_val_deal();
    event_send_adjust_time();   //上电时刻1S校时一次，校时20次，后续10分钟校时一次
    if (INN_AUTO_SEND_FORBID_TYPE == g_inner_send_data_enable)
    {
        return;
    }
    can_inner_auto_send_cycle_update();
    for( i = 0; i < g_inner_tx_can_msg_list_len; i++)
    {
        msg_info = &g_inner_tx_can_msg_list[i];
        msg_info->period_cnt++;
        //根据不同的发送周期判断是否达到发送时间
        if (msg_info->period_cnt >= msg_info->send_period)
        {
            msg_info->period_cnt = 0;
            send_ready = true;
        }
        if(true == send_ready)
        {
            msg_info->p_func_recv_deal_cb(msg_info->frame_id.id_val);
        }
        send_ready = false;
    }
}

// 触发发送
void event_send_inner_data(send_inner_can_event_type type)
{
    for (uint8_t i =0 ; i < g_inner_tx_can_msg_list_len; i++)
    {
        if (g_inner_tx_can_msg_list[i].send_id == type)
        {
            g_inner_tx_can_msg_list[i].p_func_recv_deal_cb(g_inner_tx_can_msg_list[i].frame_id.id_val);
            break;
        }
    }
}

/******************************************发送任务end**************************************************************************/
/**
* @brief		产生dev_msg发送事件
* @param		无
* @return		返回结果
* @retval		无
* @warning		无
*/
void event_send_adjust_time(void)
{
    static uint8_t cnt = 0;
    static uint32_t timestamp = 0;

    if (sdk_is_tick_over(timestamp, os_tick_from_millisecond(1000)))
    {
        timestamp = sdk_tick_get();
        if(cnt <= SEND_TIME2)
        {
            cnt++;
            event_send_inner_data(INNER_BCU_SET_TIME_MSG);
        }
    }
}

/**
* @brief		自动发送内网数据使能接口
* @param		[in]enable：  false：不使能    true：使能
* @return		返回结果
* @retval		0：操作成功    < 0: 操作失败
* @warning		无
*/
int32_t auto_send_can_inner_func_set(uint8_t type)
{
    if (type >= INN_AUTO_SEND_DATA_TYPE_NUM)
    {
        return -1;
    }
    g_inner_send_data_enable = type;
    return 0;
}


/**
* @brief        启动bmu阈值检测
* @warning      无
*/
void bmu_alarm_thre_val_check_start(void)
{
    if (g_bmu_alm_thre_val_sync_state == SYNC_THRE_VAL_SUCC ||
        g_bmu_alm_thre_val_sync_state == SYNC_THRE_VAL_ERR)
    {
        g_bmu_alarm_thre_val_check_flag = true;
        g_bmu_alm_thre_val_sync_state = SYNC_THRE_VAL_INIT;
        g_bmu_alarm_thre_val_check_err_time = 0;
    }

}

/**
* @brief        清除bmu阈值异常错误
* @warning      无
*/
void bmu_alarm_thre_val_check_err_clear(void)
{
    g_bmu_alarm_thre_val_check_err_time = 0;
}

/**
* @brief        获取bmu阈值检测状态
* @return       1： err  0：normal
*/
uint8_t bmu_alarm_thre_val_check_state_get(void)
{
    return g_bmu_alm_thre_val_sync_state;
}
