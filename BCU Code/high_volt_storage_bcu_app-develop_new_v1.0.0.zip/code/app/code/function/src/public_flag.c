#include "public_flag.h"
#include "fault_manage.h"
#include "relay_manage.h"
#include "fan_ctrl.h"
#include "led.h"
#include "sdk.h"
#include "bcu_data.h"

static uint16_t g_di_event_flag_cnt[DI_16] = {0};
static uint32_t g_bcu_input_state = 0;
static di_do_info_t g_bcu_di_do_stus = {0};
/**
 * @struct   fault_para_tab_t
 * @brief  故障参数表结构定义
 */
typedef struct 
{
    uint8_t                 di_type;                 ///< di标志类型
    uint16_t                appear_cnt;              ///< di标志出现持续的次数
    uint16_t                cancel_cnt;              ///< di标志消失持续的次数
} bms_di_tab_t;

/**
  * @struct   g_input_flag_tab
  * @brief    gpio输入滤波标志表
  */
const static bms_di_tab_t g_input_flag_tab[] =
{
    // di标志类型     -----产生时间 -------- 消失时间   
    //                        （n*扫描周期10ms)
   {0,                          50,              50,                           },   //0这里是为了和sdk层的空对应
   {DI_1_ADS_ALARM,             50,              50,                           },
   {DI_2_CLUSTER_ADDR,          50,              50,                           },
   {DI_3_EXT_WDT,               50,              50,                           },
   {DI_4_POS_RELAY,             50,              50,                           },
   {DI_5_AUXILIARY_POWER_SWITCH,50,              50,                           },
   {DI_6_NEG_RELAY,             50,              50,                           },
   {DI_7_EMERGENCY_STOP,        50,              50,                           },
   {DI_8_CMU_FAULT,             50,              50,                           },
   {DI_9_VOLT_ISOLATOR,         50,              50,                           },   

};

/**
* @brief        di标志置位
* @param        [in] flag_type 标志类型
* @param        [in] cmd 设置命令
* -# 0x00 - false
* -# 0x01 - true
* @retval        0 成功a
* @retval        -1 失败
*/
static int32_t di_state_set(uint8_t flag_type, uint8_t cmd)
{
    if ((DI_16 <= flag_type) || ((true != cmd) && (false != cmd)))
    {
        log_d("[%s] input para err!\r\n", __FUNCTION__);
        return -1;
    }

    if (true == cmd)
    {
        SET_BIT(g_bcu_input_state, (1ULL << flag_type));
    }
    else
    {
        CLR_BIT(g_bcu_input_state, (1ULL << flag_type));
    }
    return 0;
}

/**
* @brief        di相关标志状态获取
* @param        [in] flag_type 故障类型
* @retval        true  置位
* @retval        false 未置位
* @retval        -1 查询失败
*/
bool di_state_get(uint8_t flag_type)
{
    if (DI_16 <= flag_type)
    {
        log_d("[%s] input para err!\r\n", __FUNCTION__);
        return -1;
    }

    if (0 == GET_BIT(g_bcu_input_state, (1ULL << flag_type)))
    {
        return false;
    }
    else
    {
        return true;
    }
}



// 判断公共管理函数（10ms任务）
void bms_di_state_manage_deal(const bms_di_tab_t *p_di_state_tab, uint16_t max_len)
{
    if (NULL == p_di_state_tab || 0 == max_len)
    {
        return;
    }
    for (uint16_t arr_index = 0; arr_index < max_len; arr_index++)
    {
        if (!di_state_get(p_di_state_tab[arr_index].di_type))
        {
            if(true == sdk_dido_read(p_di_state_tab[arr_index].di_type))
            {
                g_di_event_flag_cnt[(uint16_t)p_di_state_tab[arr_index].di_type] += 1;
            }
            else
            {
                g_di_event_flag_cnt[(uint16_t)p_di_state_tab[arr_index].di_type] = 0;
            }
            if (g_di_event_flag_cnt[(uint16_t)p_di_state_tab[arr_index].di_type] >= p_di_state_tab[arr_index].appear_cnt)
            {
                di_state_set(p_di_state_tab[arr_index].di_type, true);
                g_di_event_flag_cnt[(uint16_t)p_di_state_tab[arr_index].di_type] = 0;
            }
        }
        else
        {
            if(false == sdk_dido_read(p_di_state_tab[arr_index].di_type))
            {
                g_di_event_flag_cnt[(uint16_t)p_di_state_tab[arr_index].di_type] += 1;
            }
            else
            {
                g_di_event_flag_cnt[(uint16_t)p_di_state_tab[arr_index].di_type] = 0;
            }
            if (g_di_event_flag_cnt[(uint16_t)p_di_state_tab[arr_index].di_type] >= p_di_state_tab[arr_index].cancel_cnt)
            {
                di_state_set(p_di_state_tab[arr_index].di_type, false);
                g_di_event_flag_cnt[(uint16_t)p_di_state_tab[arr_index].di_type] = 0;
            }
        }
    }
}

static void bcu_di_do_stus_deal(void)
{

    g_bcu_di_do_stus.di_state.bit.di1 = di_state_get(DI_4_POS_RELAY);
    g_bcu_di_do_stus.di_state.bit.di2 = ~di_state_get(DI_5_AUXILIARY_POWER_SWITCH);
    g_bcu_di_do_stus.di_state.bit.di3 = di_state_get(DI_6_NEG_RELAY);
    g_bcu_di_do_stus.di_state.bit.di4 = ~di_state_get(DI_7_EMERGENCY_STOP);
    g_bcu_di_do_stus.di_state.bit.di5 = di_state_get(DI_8_CMU_FAULT);
    g_bcu_di_do_stus.di_state.bit.di6 = ~di_state_get(DI_9_VOLT_ISOLATOR);
    g_bcu_di_do_stus.di_state.bit.di7 = di_state_get(DI_10_RSV);
    g_bcu_di_do_stus.di_state.bit.di8 = di_state_get(DI_11_RSV);
    
    g_bcu_di_do_stus.do_state.bit.do1 = get_relay_contrl_state(POS_RELAY);
    g_bcu_di_do_stus.do_state.bit.do2 = get_relay_contrl_state(PRE_RELAY);
    g_bcu_di_do_stus.do_state.bit.do3 = get_relay_contrl_state(NEG_RELAY);
    g_bcu_di_do_stus.do_state.bit.do4 = 0;
    
    if((get_led_display_mode() == LED_INIT_STATE)
        || (get_led_display_mode() == LED_STATE_FAULT))
    {
        g_bcu_di_do_stus.do_state.bit.do5 = 0;
    }
    else
    {
        g_bcu_di_do_stus.do_state.bit.do5 = 1;
    }
    
    if(get_led_display_mode() == LED_STATE_FAULT)
    {
        g_bcu_di_do_stus.do_state.bit.do6 = 1;        
    }
    else
    {
        g_bcu_di_do_stus.do_state.bit.do6 = 0;
    }

    g_bcu_di_do_stus.do_state.bit.do7 = 1;
    g_bcu_di_do_stus.do_state.bit.do8 = get_fan_flag();    
    if(true == (get_gobal_bcu_info()->set_clu_sw))
    {
        g_bcu_di_do_stus.do_state.byte = get_gobal_bcu_info()->set_clu_do;
    }
}



/**
 * @brief                bcu di do反馈
 * @return               返回结构体
 * @warning              
 */
const di_do_info_t *bcu_dido_info_get(void)
{
    return &g_bcu_di_do_stus;
}

// 公用标志管理任务10ms
void public_flag_task(void)
{
    bms_di_state_manage_deal(g_input_flag_tab, ITEM_NUM(g_input_flag_tab));
    bcu_di_do_stus_deal();
}


