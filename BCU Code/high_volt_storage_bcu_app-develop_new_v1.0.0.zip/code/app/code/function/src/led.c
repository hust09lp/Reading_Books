#include "led.h"
#include "sox.h"
#include "bms_state.h"
#include "fault_manage.h"
#include "ate.h"
#include "bmu_data.h"
#include "sdk_dido.h"
#include "public_flag.h"
#include "parallel_manage.h"
#include "bcu_data.h"

#if LED_CTL_SHELL_DEBUG_FALG
static bool g_led_ctl_shell_debug_flag = false;
#endif

static bool g_led_ctrl_disable_flag = true; // 默认led控制禁能失效
static uint8_t g_pre_led_state = LED_STATE_STATE_TYPE_NUM; // 默认初始值

/**
* @brief        ate LED逻辑禁止/使能控制
* @param        [in] disable_flag     true:屏蔽LED逻辑/false:LED逻辑正常
* @warning       一般只有ate测试才会调用，其他模块慎用
*/
void led_display_func_disable(bool disable_flag)
{
    if (true != disable_flag && false != disable_flag)
    {
        return;
    }
    g_led_ctrl_disable_flag = disable_flag;
}

/**
* @brief        LED逻辑屏蔽标志获取
* @param        void
* @return        执行结果
* @retval        true: 屏蔽led逻辑，false:正常使用led逻辑
*/
bool led_display_func_disable_flag_get(void)
{
    return g_led_ctrl_disable_flag;
}

/**
* @brief        开机时LED的闪烁设置， RUN亮，ALM灭，SOC流水灯闪烁
* @return       执行结果
* @retval       无返回值
* @pre          无前置条件
* @warning      无警告
*/
void led_display_mode(uint8_t led_type, uint8_t display_mode_type)
{
    switch (display_mode_type)
    {
    case LED_DISPLAY_MODE_1:
    {
        sdk_led_flash(led_type, 4000, 95, -1);

        break;
    }
    case LED_DISPLAY_MODE_2:
    {
        sdk_led_flash(led_type, 1000, 50, -1);

        break;
    }
    case LED_DISPLAY_MODE_3:
    {
        sdk_led_flash(led_type, 2000, 50, -1);

        break;
    }
    case LED_DISPLAY_MODE_4:
    {
        sdk_led_flash(led_type, 400, 50, -1);

        break;
    }
    case LED_DISPLAY_MODE_ALWAYS_ON:
    {
        sdk_led_flash(led_type, 1000, 0, -1);

        break;
    }
    case LED_DISPLAY_MODE_ALWAYS_CLOSE:
    {
        sdk_led_flash(led_type, 1000, 100, -1);

        break;
    }
    default:
        break;
    }
}

/**
* @brief         待机时的LED设置
* -#             待机正常状态时，RUN闪1、ALM灭，SOC按照电量显示
* -#             待机保护状态时，RUN灭、ALM亮，SOC全灭
* @param         [in] command                 给LED灯的命令
* -#             LED_STANDBY_NOAMAL           待机正常
* -#             LED_STANDBY_PROTECT          待机保护
* @param         [in] soc                     电池电量
* @param         [in] soc_led_command         在非关机和开机态，按照充放电状态决定SOC灯是否闪烁
* @return        执行结果
* @retval        无返回值
* @pre           无前置条件
* @warning       无警告
*/
void led_display_state(uint8_t command)
{
    switch (command)
    {
        case LED_INIT_STATE:
        {
            led_display_mode(USER_NOR_LED, LED_DISPLAY_MODE_ALWAYS_CLOSE);
            led_display_mode(USER_ERR_LED, LED_DISPLAY_MODE_ALWAYS_CLOSE);
            break;            
        }
        case LED_STATE_FAULT:
        {
            led_display_mode(USER_NOR_LED, LED_DISPLAY_MODE_ALWAYS_CLOSE);
            led_display_mode(USER_ERR_LED, LED_DISPLAY_MODE_ALWAYS_ON);
            break;
        }        
        case LED_STATE_DI_1:
        {
            led_display_mode(USER_NOR_LED, LED_DISPLAY_MODE_3);
            led_display_mode(USER_ERR_LED, LED_DISPLAY_MODE_ALWAYS_CLOSE);
            break;
        }
        case LED_STATE_DI_2:
        {
            led_display_mode(USER_NOR_LED, LED_DISPLAY_MODE_2);
            led_display_mode(USER_ERR_LED, LED_DISPLAY_MODE_ALWAYS_CLOSE);
            break;
        }
        case LED_STATE_DI_3:
        {
            led_display_mode(USER_NOR_LED, LED_DISPLAY_MODE_ALWAYS_ON);
            led_display_mode(USER_ERR_LED, LED_DISPLAY_MODE_ALWAYS_CLOSE);
            break;
        }
        default:
            break;
        }
}

/**
* @brief         led灯管理函数
* @param         [in] curr_display_soc         SOC显示值，单位1%
* @param         [in] max_discharge_level      放电故障等级，LEVEL0为故障
* @param         [in] max_charge_level         充电故障等级，LEVEL0为故障
* @pre           无前置条件
* @warning       无警告
*/
void led_display_proc(uint8_t max_discharge_level, uint8_t max_charge_level)
{
    uint8_t led_state = LED_INIT_STATE;
    uint8_t bms_sys_step = bms_state_get_sys_step();

    if((CMU_ERR_CUT_OFF == get_parallel_state(PARALLEL_ERR)) || (BAT_ERR == get_parallel_state(PARALLEL_ERR)))
    {
        led_state = LED_STATE_FAULT;
    } 
    else if ((true == di_state_get(DI_4_POS_RELAY)) && (0 == di_state_get(DI_5_AUXILIARY_POWER_SWITCH)))
    {
        led_state = LED_STATE_DI_2;
    }
    else if ((true == di_state_get(DI_4_POS_RELAY)) && (1 == di_state_get(DI_5_AUXILIARY_POWER_SWITCH)))   //DI_5_AUXILIARY_POWER_SWITCH 断开为1
    {
        led_state = LED_STATE_DI_3;
    }
    else    //pos反馈1是吸合，0是断开
    {
        led_state = LED_STATE_DI_1;
    }

    if ((g_pre_led_state != led_state))
    {
        g_pre_led_state = led_state;
        led_display_state(led_state);
    }
}

uint8_t get_led_display_mode(void)
{
    return g_pre_led_state;
}

// led灯管理函数
void led_init(void)
{
    g_led_ctrl_disable_flag = true;
}

/**
* @brief		DO控制模式
* @param		无  
* @return		无
* @retval		无
* @warning		无 
*/
static void led_do_ctrl()
{
    static uint8_t called = 0;
    static uint8_t last_bcu_info = 0;
        if((0 == called ) || (last_bcu_info != get_gobal_bcu_info()->set_clu_do))
        {
            called = 1;
            last_bcu_info = get_gobal_bcu_info()->set_clu_do;
        }
        else
        {
            return;
        }
        
        if((get_gobal_bcu_info()->set_clu_do & (0x01 << DO5))
            && (get_gobal_bcu_info()->set_clu_do & (0x01 << DO6)))
        {
            log_d("USER_NOR_LED,USER_ERR_LED get_gobal_bcu_info()->set_clu_do = %d\n", get_gobal_bcu_info()->set_clu_do);
            led_display_mode(USER_NOR_LED, LED_DISPLAY_MODE_ALWAYS_ON);
            led_display_mode(USER_ERR_LED, LED_DISPLAY_MODE_ALWAYS_ON);            
        }
        else if(get_gobal_bcu_info()->set_clu_do & (0x01 << DO5))
        {
            log_d("USER_NOR_LED,get_gobal_bcu_info()->set_clu_do = %d\n", get_gobal_bcu_info()->set_clu_do);
            led_display_mode(USER_NOR_LED, LED_DISPLAY_MODE_ALWAYS_ON);
            led_display_mode(USER_ERR_LED, LED_DISPLAY_MODE_ALWAYS_CLOSE);
        }
        else if(get_gobal_bcu_info()->set_clu_do & (0x01 << DO6))
        {
            log_d("USER_ERR_LED,get_gobal_bcu_info()->set_clu_do = %d\n", get_gobal_bcu_info()->set_clu_do);
            led_display_mode(USER_NOR_LED, LED_DISPLAY_MODE_ALWAYS_CLOSE);
            led_display_mode(USER_ERR_LED, LED_DISPLAY_MODE_ALWAYS_ON);
        }
        else
        {
            log_d("get_gobal_bcu_info()->set_clu_do = %d\n", get_gobal_bcu_info()->set_clu_do);
            led_display_mode(USER_NOR_LED, LED_DISPLAY_MODE_ALWAYS_CLOSE);
            led_display_mode(USER_ERR_LED, LED_DISPLAY_MODE_ALWAYS_CLOSE);
        }
}

// led灯管理函数
void led_manage(void)
{
#if LED_CTL_SHELL_DEBUG_FALG
    if (g_led_ctl_shell_debug_flag)
    {
        return;
    }
#endif
    if (g_led_ctrl_disable_flag) // 屏蔽led功能退出
    {
        return;
    }
    if (special_mode_get(ATUO_TEST))
    {
		return;
	}

    if(get_gobal_bcu_info()->set_clu_sw)
    {
        led_do_ctrl();
        return;
    }

    const fault_stat_data_t *p_fault_data = NULL;

    p_fault_data = fault_chg_dsg_level_get();

    // 运行和故障过程led控制
    led_display_proc(p_fault_data->max_discharge_level, p_fault_data->max_charge_level);
}


/***********************************LED shell debug************************************************/
#if LED_CTL_SHELL_DEBUG_FALG


typedef enum
{
    DEBUG_VAL_LED_DISABLE_FLAG = 0,     ///< LED 屏蔽标志
    DEBUG_VAL_NUM,
} led_value_debug_e;

/**
 * @brief        设置模拟量debug
 * @param        [in] debug_flag 模拟量debug标志， 1：debug 0:normal
 * @param        [in] data_type 模拟量debug标志， 1：debug 0:normal
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
void led_value_set_debug(uint8_t data_type, int32_t value)
{
    switch (data_type)
    {
        case DEBUG_VAL_LED_DISABLE_FLAG:
            g_led_ctrl_disable_flag = value;
            break;
        default:
            log_d("ledValIdOverErr\n");
            break;
    }
}

// 打印
void led_debug_printf(void)
{
    log_d("ledDebug=%ld\n", g_led_ctl_shell_debug_flag);
    log_d("ledCtrlDisable=%ld\n", g_led_ctrl_disable_flag);
    
}

void led_debug_err_printf(void)
{
//    log_d(" led param err\r\n");
//    log_d(" led print : printf data\r\n");
//    log_d(" led debug 0/1: debug start/close\r\n");
//    log_d(" led set led_id(0~%d) state(0~%d): set led work\r\n", LED_NUM - 1, LED_DISPLAY_MODE_TYPE - 1);
//    log_d(" led val val_id(0~%d) value(xxx): set val \r\n", DEBUG_VAL_NUM - 1);
//    log_d(" led mode mode_id(0~%d) soc(0-100%) : set val \r\n", LED_STATE_STATE_TYPE_NUM - 1);
}

void led_debug_help_printf(void)
{
//    log_d("led_id:\n");
//    log_d("POWER_ON_LED        = %d\n", POWER_ON_LED   ); 
//    log_d("USER_NOR_LED        = %d\n", USER_NOR_LED     ); 
//    log_d("USER_ERR_LED        = %d\n", USER_ERR_LED     ); 
//    log_d("SOC_LED1            = %d\n", SOC_LED1     ); 
//    log_d("SOC_LED2            = %d\n", SOC_LED2     ); 
//    log_d("SOC_LED3            = %d\n", SOC_LED3     ); 
//    log_d("SOC_LED4            = %d\n", SOC_LED4     ); 
//    log_d("SOC_LED5            = %d\n", SOC_LED5     ); 
//    log_d("SOC_LED6            = %d\n", SOC_LED6     ); 

//    log_e("\nstate type:\n");
//    log_e("LED_DISPLAY_MODE_1            = %d\n", LED_DISPLAY_MODE_1           );
//    log_e("LED_DISPLAY_MODE_2            = %d\n", LED_DISPLAY_MODE_2           );
//    log_e("LED_DISPLAY_MODE_3            = %d\n", LED_DISPLAY_MODE_3           );
//    log_e("LED_DISPLAY_MODE_ALWAYS_ON    = %d\n", LED_DISPLAY_MODE_ALWAYS_ON   );
//    log_e("LED_DISPLAY_MODE_ALWAYS_CLOSE = %d\n", LED_DISPLAY_MODE_ALWAYS_CLOSE);
//    log_e("LED_DISPLAY_MODE_WATER_FALL   = %d\n", LED_DISPLAY_MODE_WATER_FALL  );
//    
//    log_e("\nval_id:\n");
//    log_e("DEBUG_VAL_LED_DISABLE_FLAG  = %d\n", DEBUG_VAL_LED_DISABLE_FLAG    );

//    log_e("\nled mode id:\n");
//    log_e("LED_INIT_STATE             = %d\n", LED_INIT_STATE          ); 
//    log_e("LED_STATE_POWER_OFF        = %d\n", LED_STATE_POWER_OFF       ); 
//    log_e("LED_STATE_POWER_ON         = %d\n", LED_STATE_POWER_ON   ); 
//    log_e("LED_STATE_UPGARDE          = %d\n", LED_STATE_UPGARDE); 
//    log_e("LED_STATE_FAULT            = %d\n", LED_STATE_FAULT         ); 
//    log_e("LED_STATE_PROTECT          = %d\n", LED_STATE_PROTECT  ); 
//    log_e("LED_STATE_NORMAL           = %d\n", LED_STATE_NORMAL); 
//    log_e("LED_STATE_POWER_OFF_PRE    = %d\n", LED_STATE_POWER_OFF_PRE      ); 
}

/**
 * @brief        led功能样例
 * @param        argv 功能参数
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
static int led(int argc, char *argv[])
{
    if (argc < 2)
    {
        log_d("ledParaErr\n");
        return SF_ERR_PARA;
    }

    if (!strcmp(argv[1], "print"))
    {
        led_debug_printf();
    }
    else if (!strcmp(argv[1], "debug"))
    {
        if (argc < 3)
        {
            log_d("ledDebugErr\n");
            return SF_ERR_PARA;
        }
        uint32_t flag = atoi(argv[2]); //解析第2个参数名称
        if (flag > true)
        {
             log_d("ledDebugFlagErr\n");
             return -1;
        }
        g_led_ctl_shell_debug_flag = flag;
    }
    else if (!strcmp(argv[1], "set"))
    {
        if (argc < 4)
        {
            log_d("ledSetErr\n");
            return SF_ERR_PARA;
        }
        if (!g_led_ctl_shell_debug_flag)
        {
            log_d("noSeLedDdebugFlag\n");
            return -1;
        }
        uint32_t led_id = atoi(argv[2]);          // 参数1: 模拟量sample_value_debug_e
        int32_t led_state = atoi(argv[3]);        // 参数2：value值
        led_display_mode(led_id, led_state);
    }
    else if (!strcmp(argv[1], "val"))
    {
        if (argc < 4)
        {
            log_d("ledSetErr\n");
            return SF_ERR_PARA;
        }
        if (!g_led_ctl_shell_debug_flag)
        {
            log_d("noSeLedDdebugFlag\n");
            return -1;
        }
        uint32_t val_id = atoi(argv[2]);          // 参数1: 模拟量sample_value_debug_e
        int32_t val = atoi(argv[3]);              // 参数2：value值
        led_value_set_debug(val_id, val);
    }
    else if (!strcmp(argv[1], "mode"))
    {
        if (argc < 5)
        {
            log_d("ledModeErr\n");
            return SF_ERR_PARA;
        }
        if (!g_led_ctl_shell_debug_flag)
        {
            log_d("noSeLedDdebugFlag\n");
            return -1;
        }
        uint32_t mode_id = atoi(argv[2]);          // 参数1: 模拟量
        int32_t soc = atoi(argv[3]);               // 参数2：value值
        uint32_t soc_mode_id = atoi(argv[4]);      // 参数2：模拟量
        led_display_state(mode_id);
    }
    else if (!strcmp(argv[1], "help"))
    {
        led_debug_help_printf();
    }
    return 0;
}
MSH_CMD_EXPORT(led, <print/debug 0-1/set ledId state/val valId value/mode modeId soc>);

#endif

