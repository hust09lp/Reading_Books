#include "sdk.h"
#include "sdk_core.h"
#include "app_public.h"
#include "relay_manage.h"
#include "inner_can_data.h"
#include "auto_addressing.h"
#include "sample.h"
#include "fault_manage.h"
#include "ate.h"
#include "insulation_impedance_calc.h"
#include "bms_state.h"
#include "bmu_data.h"
#include "state_machine.h"
#include "parallel_manage.h"
#include "bcu_data.h"
#include "data_store.h"

#define DELAY_10S_BASE_10MS  1000
#define DELAY_5S_BASE_10MS  500
#define DELAY_3S_BASE_10MS  300
#define DELAY_1S_BASE_10MS  100
#define DELAY_100MS_BASE_10MS  10
#define DELAY_300MS_BASE_10MS  30

#define BUS_LOAD_VOLT_DIFF_ABNORMAL_VAL (150000)
/********************************预充状态机处理函数声明****************************************/
static uint8_t sta_pre_chg_init_entry(void);
static uint8_t sta_pre_chg_init_run(void);
static uint8_t sta_pre_chg_start_entry(void);
static uint8_t sta_pre_chg_start_run(void);
static uint8_t sta_pre_chg_stage1_entry(void);
static uint8_t sta_pre_chg_stage1_run(void);
static uint8_t sta_pre_chg_stage2_entry(void);
static uint8_t sta_pre_chg_stage2_run(void);
static uint8_t sta_pre_chg_again_entry(void);
static uint8_t sta_pre_chg_again_run(void);
static uint8_t sta_pre_chg_finish_run(void);
static uint8_t sta_pre_chg_error_run(void);
/********************************预充状态机使用变量定义****************************************/
static fsm_action_map_t g_pre_chg_act_map[PRE_CHG_STA_NUM] = 
{
    [PRE_CHG_INIT]           = {sta_pre_chg_init_entry, sta_pre_chg_init_run}, // 预充初始化
    [PRE_CHG_START]          = {sta_pre_chg_start_entry, sta_pre_chg_start_run}, // 预充开始，闭合预充继电器
    [PRE_CHG_STAGE1]         = {sta_pre_chg_stage1_entry, sta_pre_chg_stage1_run}, // 预充进行阶段1，闭合正继电器
    [PRE_CHG_STAGE2]         = {sta_pre_chg_stage2_entry, sta_pre_chg_stage2_run}, // 预充进行阶段2，断开预充继电器
    [PRE_CHG_AGAIN]          = {sta_pre_chg_again_entry, sta_pre_chg_again_run}, // 预充重新进行，连续进行3次则预充失败
    [PRE_CHG_FINISH]         = {NULL, sta_pre_chg_finish_run}, // 预充完成
    [PRE_CHG_ERROR]          = {NULL, sta_pre_chg_error_run}, // 预充失败
};

static uint8_t g_pre_chg_evt_sta_map[PRE_CHG_STA_NUM][PRE_CHG_EVT_NUM] = 
{                // EVT_PRE_CUT_OFF   EVT_PRE_STAT_CPL_SUC    EVT_PRE_AGAIN       EVT_PRE_START_ERR
    [PRE_CHG_INIT]   = {STA_NULL,       PRE_CHG_START,        STA_NULL,              STA_NULL     },
    [PRE_CHG_START]  = {PRE_CHG_INIT,   PRE_CHG_STAGE1,       PRE_CHG_AGAIN,         PRE_CHG_ERROR},
    [PRE_CHG_STAGE1] = {PRE_CHG_INIT,   PRE_CHG_STAGE2,       STA_NULL,              STA_NULL     },
    [PRE_CHG_STAGE2] = {PRE_CHG_INIT,   PRE_CHG_FINISH,       STA_NULL,              STA_NULL     },
    [PRE_CHG_AGAIN]  = {PRE_CHG_INIT,   PRE_CHG_START,        STA_NULL,              STA_NULL     },
    [PRE_CHG_FINISH] = {PRE_CHG_INIT,   STA_NULL,             STA_NULL,              STA_NULL     },
    [PRE_CHG_ERROR]  = {PRE_CHG_INIT,   STA_NULL,             STA_NULL,              STA_NULL     },    
};

static state_machine_t g_pre_chg_fsm = {0};
static const char* g_pre_chg_fsm_name = "preChg";
static uint8_t g_pre_chg_state = PRE_INIT;
static uint16_t g_pre_chg_fail_cnt = 0;  // 预充失败，累计时间计数
static uint16_t g_pre_chg_fail_continue_cnt = 0;  // 预充失败，连续时间计数
static uint16_t g_pos_relay_close_delay_cnt = 0; // 满足正继电器闭合条件，持续时间计数
static uint16_t g_re_pre_chg_delay_cnt = 0;	// 重新预充计时
static uint16_t g_pre_relay_off_delay_cnt = 0; // 预充继电器断开延时
static uint8_t  g_pre_chg_abnormal_cnt = 0;	//预充异常次数
static uint8_t g_relay_manage_enable = false;
static relay_ctrl_cmd_u g_relay_ctrl_cmd;  // 继电器控制命令
static uint8_t g_power_relay_on_flag = 0;		//允许闭合功率继电器标志 0允许闭合，1切断,无并机调试时默认给0
static uint8_t g_force_ch_relay_on_flag = 0xAA;    //强充允许闭合功率继电器标志 0xAA允许闭合，0x55切断,
static uint8_t g_exp_ins_cutoff_relay_flag = false; // 除了继电器外的断开继电器标志
static uint8_t g_load_cut_off_flag = false;
static uint8_t g_aux_relay_set_flag = true;

/********************************其他不需要预充状态机处理函数声明****************************************/
static uint8_t sta_chg_init_entry(void);
static uint8_t sta_chg_start_entry(void);
static uint8_t sta_chg_start_run(void);
static uint8_t sta_chg_finish_run(void);
static uint8_t sta_chg_error_run(void);
/********************************其他不需要预充状态机使用变量定义****************************************/
#define CHG_TIME_5000MS     5000
#define CHG_TIME_ERR_10000MS 10000

static fsm_action_map_t g_chg_act_map[CHG_STA_NUM] = 
{
    [CHG_INIT]           = {sta_chg_init_entry,  NULL}, // 上电初始化
    [CHG_START]          = {sta_chg_start_entry, sta_chg_start_run}, // 开始上电  
    [CHG_FINISH]         = {NULL, sta_chg_finish_run}, // 上电完成
    [CHG_ERROR]          = {NULL, sta_chg_error_run}, // 上电异常
};

static uint8_t g_chg_evt_sta_map[CHG_STA_NUM][CHG_EVT_NUM] = 
{                // EVT_CHG_CUT_OFF   EVT_CHG_STAT_CPL_SUC           EVT_CHG_START_ERR
    [CHG_INIT]   = {STA_NULL,       CHG_START,                      STA_NULL     },
    [CHG_START]  = {CHG_INIT,       CHG_FINISH,                     CHG_ERROR},
    [CHG_FINISH] = {CHG_INIT,       STA_NULL,                       STA_NULL     },
    [CHG_ERROR]  = {CHG_INIT,       STA_NULL,                       STA_NULL     },    
};

static state_machine_t g_chg_fsm = {0};
static const char* g_chg_fsm_name = "Chg";
static uint32_t g_chg_close_tick = 0;

/********************************继电器控制状态机处理函数声明****************************************/
static uint8_t sta_relay_idle_entry(void);
static uint8_t sta_relay_idle_run(void);
static uint8_t sta_relay_wait_open_entry(void);
static uint8_t sta_relay_wait_open_run(void);
static uint8_t sta_relay_start_open_run(void);
static uint8_t sta_relay_open_result_run(void);
static uint8_t sta_relay_start_close_entry(void);
static uint8_t sta_relay_start_close_run(void);
static uint8_t sta_relay_close_result_run(void);
static uint8_t sta_relay_close_low_power_entry(void);
static uint8_t sta_relay_close_low_power_run(void);
static uint8_t sta_relay_error_entry(void);
/********************************继电器控制状态机使用变量定义****************************************/
static fsm_action_map_t g_relay_act_map[RELAY_CTRL_STA_NUM] = 
{
    [RELAY_IDLE]           = {sta_relay_idle_entry, sta_relay_idle_run},
    [RELAY_WAIT_OPEN]      = {sta_relay_wait_open_entry, sta_relay_wait_open_run},
    [RELAY_START_OPEN]     = {NULL, sta_relay_start_open_run},
    [RELAY_OPEN_RES]       = {NULL, sta_relay_open_result_run},
    [RELAY_START_CLOSE]    = {sta_relay_start_close_entry, sta_relay_start_close_run},
    [RELAY_CLOSE_RES]      = {NULL, sta_relay_close_result_run},
    [RELAY_CLOSE_LOW_POW]  = {sta_relay_close_low_power_entry, sta_relay_close_low_power_run},
    [RELAY_ERROR]          = {sta_relay_error_entry, NULL},
};

static uint8_t g_relay_evt_sta_map[RELAY_CTRL_STA_NUM][RELAY_CTRL_EVT_NUM] = 
{                      // EVT_RELAY_CLOSE   EVT_RELAY_OPEN   EVT_RELAY_CPL_SUC    EVT_RELAY_REOPERATE  EVT_RELAY_ERR
    [RELAY_IDLE]          = {RELAY_START_CLOSE, RELAY_WAIT_OPEN, STA_NULL,           STA_NULL,             STA_NULL},
    [RELAY_WAIT_OPEN]     = {STA_NULL,          STA_NULL,        RELAY_START_OPEN,   STA_NULL,             STA_NULL},
    [RELAY_START_OPEN]    = {STA_NULL,          STA_NULL,        RELAY_OPEN_RES,     STA_NULL,             STA_NULL},
    [RELAY_OPEN_RES]      = {STA_NULL,          STA_NULL,        RELAY_IDLE,         RELAY_START_OPEN,     RELAY_ERROR},
    [RELAY_START_CLOSE]   = {STA_NULL,          STA_NULL,        RELAY_CLOSE_RES,    STA_NULL,             STA_NULL},
    [RELAY_CLOSE_RES]     = {STA_NULL,          STA_NULL,        RELAY_IDLE,RELAY_START_CLOSE,             RELAY_ERROR},    //当前继电器不存在低功耗功能，故吸合后直接跳到空闲
    [RELAY_CLOSE_LOW_POW] = {STA_NULL,          STA_NULL,        RELAY_IDLE,         STA_NULL,             STA_NULL},
    [RELAY_ERROR]         = {STA_NULL,          STA_NULL,        RELAY_IDLE,           STA_NULL,             STA_NULL},    
};

static relay_para_t g_relay_para[POWER_RELAY_NUM] =
{
    [POS_RELAY] = {POS_RELAY_OPEN_MAX_CUR, RELAY_OPEN_MAX_TICK_30MS, RELAY_CLOSE_MAX_TICK_30MS, RELAY_CLOSE_LOW_POWER_MAX_TICK_60S, RELAY_WAIT_CUR_TICK_500MS, RELAY_OPEN_LOAD_MAX_TICK_15000MS},
    [NEG_RELAY] = {NEG_RELAY_OPEN_MAX_CUR, RELAY_OPEN_MAX_TICK_30MS, RELAY_CLOSE_MAX_TICK_30MS, RELAY_CLOSE_LOW_POWER_MAX_TICK_60S, RELAY_WAIT_CUR_TICK_500MS, RELAY_OPEN_LOAD_MAX_TICK_15000MS},
    [PRE_RELAY] = {PRE_RELAY_OPEN_MAX_CUR, RELAY_OPEN_MAX_TICK_30MS, RELAY_CLOSE_MAX_TICK_30MS, RELAY_CLOSE_LOW_POWER_MAX_TICK_60S, RELAY_WAIT_CUR_TICK_500MS, RELAY_OPEN_LOAD_MAX_TICK_15000MS},
};

static relay_type_e g_relay_type = POWER_RELAY_NUM;
static state_machine_t g_relay_fsm[POWER_RELAY_NUM] = {0};
static const char* g_relay_fsm_name[POWER_RELAY_NUM] = {"posRly", "negRly", "preRly"};
static uint8_t g_relay_state[POWER_RELAY_NUM] = {RELAY_OPEN, RELAY_OPEN, RELAY_OPEN};
static relay_ctrl_cmd_u g_relay_last_cmd;  // 上次继电器控制命令
static uint8_t g_relay_ctrl_fisrt_flag[POWER_RELAY_NUM] = {0};  // 继电器首次控制标志位, 0:初次，非0：非初次
static uint32_t g_relay_wait_open_load_time_stamp[POWER_RELAY_NUM] = {0}; 
static uint32_t g_relay_wait_open_low_curr_time_stamp[POWER_RELAY_NUM] = {0}; 
static uint32_t g_relay_operate_cpl_time_stamp[POWER_RELAY_NUM] = {0};
static uint32_t g_relay_operate_low_pow_time[POWER_RELAY_NUM] = {0};
static uint8_t g_relay_open_err_cnt[POWER_RELAY_NUM] = {0};
static uint8_t g_relay_close_step[POWER_RELAY_NUM] = {0};
static uint8_t g_relay_close_err_cnt[POWER_RELAY_NUM] = {0};
static uint8_t g_relay_abnormal_flag[POWER_RELAY_NUM] = {0}; // 1:异常， 0：正常
/******************************************预充状态机相关处理函数*******************************************************/
static uint8_t sta_pre_chg_init_entry(void)
{
    return EVT_NULL;
}

static uint8_t sta_pre_chg_init_run(void)
{
    uint8_t event = EVT_NULL;
    g_pre_chg_fail_cnt = 0;
    g_pre_chg_fail_continue_cnt = 0;
    g_pos_relay_close_delay_cnt = 0;
    g_re_pre_chg_delay_cnt = 0;
    g_pre_relay_off_delay_cnt = 0;
    g_pre_chg_abnormal_cnt = 0;

    g_pre_chg_state = PRE_INIT;
    REQ_NEG_RELAY_ON();
    if (get_relay_real_state(NEG_RELAY) == RELAY_CLOSE)
    {
        log_d("[RLY]PRE_CHG_INIT time:%d\n", sdk_tick_get());
        event = EVT_PRE_STAT_CPL_SUC;
    }
    return event;
}

static uint8_t sta_pre_chg_start_entry(void)
{
    g_pre_chg_state = PRE_ONGOING;
    REQ_POS_RELAY_OFF();
    REQ_PRE_RELAY_ON();
    return EVT_NULL;
}

static uint8_t sta_pre_chg_start_run(void)
{
    const sample_data_t bat_data = *p_sample_data_get();
    uint8_t event = EVT_NULL;
    uint8_t pack_num = get_bms_attr()->clu_pack_num;
    if ((get_relay_real_state(POS_RELAY) != RELAY_OPEN) && (get_relay_real_state(PRE_RELAY) != RELAY_CLOSE))
    {
        return event;
    }

    // 正继电器闭合条件：电池簇电压 > 40V*N && (|电池簇电压 - 负载电压|)<= 电池簇电压*0.1  N:电池簇内串联电池包数
    if ((bat_data.bus_volt > PRE_PACK_VOLT_THRESHOLD * pack_num) &&
       (abs((int32_t)bat_data.bus_volt - (int32_t)bat_data.load_volt) <= (bat_data.bus_volt / 20)))
    {
        if((++g_pos_relay_close_delay_cnt > DELAY_1S_BASE_10MS))
        {
            g_pos_relay_close_delay_cnt = 0;
            event = EVT_PRE_STAT_CPL_SUC;
            log_d("[RLY]pre chg start suc\n");
        }
        g_pre_chg_fail_continue_cnt = 0;
    }
    else
    {
        g_pos_relay_close_delay_cnt = 0;
        g_pre_chg_fail_cnt++;
        // 反接电压差异会等于200V,然后当前留余量所以判断值为150V
        if ((int32_t)bat_data.load_volt - (int32_t)bat_data.bus_volt > BUS_LOAD_VOLT_DIFF_ABNORMAL_VAL)
        {
            g_pre_chg_fail_continue_cnt++;
        }
        else
        {
            g_pre_chg_fail_continue_cnt = 0;
        }
    }

    if( g_pre_chg_fail_cnt > DELAY_3S_BASE_10MS || g_pre_chg_fail_continue_cnt > DELAY_100MS_BASE_10MS)
    {
        g_pos_relay_close_delay_cnt = 0;
        g_pre_chg_fail_continue_cnt = 0;
        g_pre_chg_fail_cnt = 0;
        g_pre_chg_abnormal_cnt++;
        log_e("[RLY]busV=%d,loadV=%d,pack=%d err\n", bat_data.bus_volt, bat_data.load_volt, pack_num);
        if( g_pre_chg_abnormal_cnt > PRE_CHG_MAX_NUM )	//连续预充3次，则进入预充错误处理
        {
            g_pre_chg_abnormal_cnt = PRE_CHG_MAX_NUM;
            event = EVT_PRE_START_ERR;
            log_d("[RLY]preChgStartErr\n");
        }
        else
        {
            event = EVT_PRE_AGAIN;
            log_e("[RLY]preChgRestart\n");
        }
    }
    return event;
}
// 预充进行阶段1，闭合正继电器
static uint8_t sta_pre_chg_stage1_entry(void)
{
    REQ_POS_RELAY_ON();	//闭合正继电器
    return EVT_NULL;
}
static uint8_t sta_pre_chg_stage1_run(void)
{
    uint8_t event = EVT_NULL;
    if (get_relay_real_state(POS_RELAY) != RELAY_CLOSE)
    {
        return event;
    }
    if(++g_pre_relay_off_delay_cnt > DELAY_100MS_BASE_10MS)
    {
        g_pre_relay_off_delay_cnt = 0;
        event = EVT_PRE_STAT_CPL_SUC;
    }
    return event;    
}
// 预充进行阶段2，断开预充继电器
static uint8_t sta_pre_chg_stage2_entry(void)
{
    REQ_PRE_RELAY_OFF();
    REQ_POS_RELAY_ON();
    return EVT_NULL;
}

static uint8_t sta_pre_chg_stage2_run(void)
{
    if (get_relay_real_state(PRE_RELAY) == RELAY_OPEN)
    {
        log_d("[RLY]preChgFinished\n");
        return EVT_PRE_STAT_CPL_SUC;
    }
    return EVT_NULL;
}

static uint8_t sta_pre_chg_again_entry(void)
{
    g_pre_chg_fail_cnt = 0;
    g_pre_chg_fail_continue_cnt = 0;
    g_pos_relay_close_delay_cnt = 0;
    g_pre_relay_off_delay_cnt = 0;

    REQ_POS_RELAY_OFF();
    REQ_PRE_RELAY_OFF();
    return EVT_NULL;
}

static uint8_t sta_pre_chg_again_run(void)
{
    uint8_t event = EVT_NULL;
    if ((get_relay_real_state(POS_RELAY) != RELAY_OPEN) && (get_relay_real_state(PRE_RELAY) != RELAY_OPEN))
    {
        return EVT_NULL;
    }
    if( ++g_re_pre_chg_delay_cnt > DELAY_5S_BASE_10MS )	//关掉预充，延时5s后重新预充
    {
        g_re_pre_chg_delay_cnt = 0;
        event = EVT_PRE_STAT_CPL_SUC;
    }
    return event;
}

static uint8_t sta_pre_chg_finish_run(void)
{
    g_pre_chg_state = PRE_SUCCESS;
    REQ_PRE_RELAY_OFF();
    REQ_POS_RELAY_ON();
    return EVT_NULL;
}
static uint8_t sta_pre_chg_error_run(void)
{
    REQ_PRE_RELAY_OFF();
    g_pre_chg_state = PRE_FAIL;
    return EVT_NULL;
}


static void pre_chg_fsm_init(void)
{
    state_machine_init(&g_pre_chg_fsm, g_pre_chg_fsm_name, g_pre_chg_act_map, (uint8_t *)g_pre_chg_evt_sta_map,
        PRE_CHG_EVT_NUM, PRE_CHG_STA_NUM, PRE_CHG_INIT);
}

/******************************************不需要预充控制状态机相关处理函数*******************************************************/
static uint8_t sta_chg_init_entry(void)
{
    g_chg_close_tick = 0;
    return EVT_CHG_STAT_CPL_SUC;
}

static uint8_t sta_chg_start_entry(void)
{
    g_chg_close_tick = sdk_tick_get();
    REQ_NEG_RELAY_ON();
    REQ_PRE_RELAY_ON();
    
    return EVT_NULL;
}

static uint8_t sta_chg_start_run(void)  
{
    uint8_t event = EVT_NULL;
    
    if (sdk_is_tick_over(g_chg_close_tick, CHG_TIME_5000MS)) //延时一段时间就吸合主正
    {
        REQ_POS_RELAY_ON();
    }
    
//    if (true == POS_RELAY_STATUS_READ())
//    {
//        REQ_PRE_RELAY_OFF();
//        event = EVT_CHG_STAT_CPL_SUC;
//    }
//    else if (sdk_is_tick_over(g_chg_close_tick, CHG_TIME_ERR_10000MS))
//    {
//        event = EVT_CHG_START_ERR;
//    }
//    else
//    {
//        ;
//    }
    
    return event;
}

static uint8_t sta_chg_finish_run(void)
{
    log_e("[RLY]pos close finsih\n");
    
    return EVT_NULL;
}        

static uint8_t sta_chg_error_run(void)
{
    log_e("[RLY]pos close err\n");
//    REQ_PRE_RELAY_OFF();
//    REQ_POS_RELAY_OFF();
//    REQ_NEG_RELAY_OFF();
    
    return EVT_NULL;
}

static void chg_fsm_init(void)
{
    state_machine_init(&g_chg_fsm, g_chg_fsm_name, g_chg_act_map, (uint8_t *)g_chg_evt_sta_map,
        CHG_EVT_NUM, CHG_STA_NUM, CHG_INIT);
}

/******************************************继电器安全控制状态机相关处理函数*******************************************************/
static uint8_t sta_relay_idle_entry(void)
{
    uint8_t type = g_relay_type;
    if (type >= POWER_RELAY_NUM)
    {
        return EVT_NULL;
    }
    g_relay_wait_open_load_time_stamp[type] = 0; 
    g_relay_wait_open_low_curr_time_stamp[type] = 0;
    g_relay_operate_cpl_time_stamp[type] = 0;
    g_relay_open_err_cnt[type] = 0;
    g_relay_close_step[type] = 0;
    return EVT_NULL;
}
static uint8_t sta_relay_idle_run(void)
{
    uint8_t event = EVT_NULL;
    uint8_t relay_cur_cmd, relay_last_cmd;
    uint8_t type = g_relay_type;
    if (type >= POWER_RELAY_NUM)
    {
        return event;
    }

    switch (type)
    {
        case POS_RELAY:
        {
            relay_cur_cmd = g_relay_ctrl_cmd.bit_t.pos_relay;
            relay_last_cmd = g_relay_last_cmd.bit_t.pos_relay;
            break;
        }
        case NEG_RELAY:
        {
            relay_cur_cmd = g_relay_ctrl_cmd.bit_t.neg_relay;
            relay_last_cmd = g_relay_last_cmd.bit_t.neg_relay;
            break;
        }
        case PRE_RELAY:
        {
            relay_cur_cmd = g_relay_ctrl_cmd.bit_t.pre_relay;
            relay_last_cmd = g_relay_last_cmd.bit_t.pre_relay;
            break;
        }
        default:
            break;
    }
    if ((relay_cur_cmd != relay_last_cmd) || (g_relay_ctrl_fisrt_flag[type] == 0))
    {
        if (relay_cur_cmd == 1)
        {
            event = EVT_RELAY_CLOSE;
        }
        else
        {
            event = EVT_RELAY_OPEN;
        }
        g_relay_ctrl_fisrt_flag[type] = 1;
        log_e("[RLY]relay%d,cur=%d,last=%d,fst=%d\n", type, relay_cur_cmd, relay_last_cmd, g_relay_ctrl_fisrt_flag[type]);
    }
    return event;
}
static uint8_t sta_relay_wait_open_entry(void)
{
    uint8_t type = g_relay_type;
    if (type >= POWER_RELAY_NUM)
    {
        return EVT_NULL;
    }
    g_relay_wait_open_load_time_stamp[type] = sdk_tick_get();
    g_relay_wait_open_low_curr_time_stamp[type] = sdk_tick_get();
//    log_d("relay%d open start time,load:%d,lowcur:%d\r\n",type,g_relay_wait_open_load_time_stamp[type],g_relay_wait_open_low_curr_time_stamp[type]);
    return EVT_NULL;
}
static uint8_t sta_relay_wait_open_run(void)
{
    uint8_t type = g_relay_type;
    uint8_t event = EVT_NULL;
    const sample_data_t* p_sample_data = p_sample_data_get();
    
    if (type >= POWER_RELAY_NUM)
    {
        return EVT_NULL;
    }

    // 判断|电池簇电流|<小电流断开阈值10A，持续500ms
    if (abs(p_sample_data->sys_current) <= g_relay_para[type].open_max_cur) // 
    {
        if (sdk_is_tick_over(g_relay_wait_open_low_curr_time_stamp[type], g_relay_para[type].open_low_current_continuous_time))   //小电流持续时间
        {
            g_relay_open_err_cnt[type] = 0;
            event = EVT_RELAY_CPL_SUC;
//            log_d("relay%d open low cur time:%d,cur:%d\r\n",type,sdk_tick_get(),p_sample_data->sys_current);
        }

    }
    else
    {
        g_relay_wait_open_low_curr_time_stamp[type] = sdk_tick_get();
    }

    //带载切断最大等待时间
    if (sdk_is_tick_over(g_relay_wait_open_load_time_stamp[type], g_relay_para[type].open_load_max_time))   
    {
//        if((abs(bat_data.sys_current) > g_relay_para[type].open_max_cur))   //准备带载切断
        {
            g_load_cut_off_flag = true;            
        }  
        g_relay_open_err_cnt[type] = 0;
        log_w("relay%d load open time:%d,cur:%d\r\n",type,sdk_tick_get(),p_sample_data->sys_current);
        event = EVT_RELAY_CPL_SUC;
    }
    return event;
}

static uint8_t sta_relay_start_open_run(void)
{
    uint8_t type = g_relay_type;
    if (type >= POWER_RELAY_NUM)
    {
        return EVT_NULL;
    }

    switch (type)
    {
        case POS_RELAY:
        {
            POS_RELAY_NEG_OFF();
            POS_RELAY_POS_OFF();
//            log_d("pos open time:%d\r\n",sdk_tick_get());
            break;
        }
        case NEG_RELAY:
        {
            NEG_RELAY_NEG_OFF();
            NEG_RELAY_POS_OFF();
//            log_d("neg open time:%d\r\n",sdk_tick_get());
            break;
        }
        case PRE_RELAY:
        {
            PRE_CHG_RELAY_OFF();
            break;
        }
        default:
            break;
    }
    g_relay_state[type] = RELAY_DOING;
    g_relay_operate_cpl_time_stamp[type] = sdk_tick_get();

    return EVT_RELAY_CPL_SUC;

}

static uint8_t sta_relay_open_result_run(void)
{
    uint8_t type = g_relay_type;
    uint8_t event = EVT_NULL;
//    int32_t res;
    if (type >= POWER_RELAY_NUM)
    {
        return EVT_NULL;
    }
    if (sdk_is_tick_over(g_relay_operate_cpl_time_stamp[type], os_tick_from_millisecond(g_relay_para[type].open_max_time)))
    {
        switch (type)
        {
            case POS_RELAY:
            {
                if(false == POS_RELAY_STATUS_READ()) 
                {
                    g_relay_state[POS_RELAY] = false;                    
                }
                g_relay_last_cmd.bit_t.pos_relay = 0;
                break;
            }
            case NEG_RELAY:
            {
                if(false == NEG_RELAY_STATUS_READ()) 
                {
                    g_relay_state[NEG_RELAY] = false;                    
                }
                g_relay_last_cmd.bit_t.neg_relay = 0;
                break;
            }            
            case PRE_RELAY:
            {
                g_relay_state[PRE_RELAY] = RELAY_OPEN;
                g_relay_last_cmd.bit_t.pre_relay = 0;
                break;
            }           
            default:
                break;
        }
        // g_relay_state[type] = RELAY_OPEN;
        if (g_relay_state[type] == RELAY_OPEN)
        {
            event = EVT_RELAY_CPL_SUC;
        }
        else
        {
            g_relay_open_err_cnt[type]++;
            if (g_relay_open_err_cnt[type] >= RELAY_OPERATE_ERR_MAX_CONT_NUM)
            {
                event = EVT_RELAY_ERR;
            }
            else
            {
                event = EVT_RELAY_REOPERATE;
            }
        }   
    }
    return event;
}

static uint8_t sta_relay_start_close_entry(void)
{
    uint8_t type = g_relay_type;
    if (type >= POWER_RELAY_NUM)
    {
        return EVT_NULL;
    }
    g_relay_close_step[type] = 0;
    return EVT_NULL;
}
static uint8_t sta_relay_start_close_run(void)
{
    uint8_t type = g_relay_type;
    uint8_t event = EVT_NULL;

    if (type >= POWER_RELAY_NUM)
    {
        return EVT_NULL;
    }

    switch (type)
    {
        case POS_RELAY:
        {
            if (g_relay_close_step[POS_RELAY] == 0)
            {
                POS_RELAY_POS_ON();
                g_relay_close_step[POS_RELAY] = 1;
            }
            else
            {
                POS_RELAY_NEG_ON();
                event = EVT_RELAY_CPL_SUC;
            }
            g_relay_last_cmd.bit_t.pos_relay = 1;
            break;
        }
        case NEG_RELAY:
        {
            if (g_relay_close_step[NEG_RELAY] == 0)
            {
                NEG_RELAY_POS_ON();
                g_relay_close_step[NEG_RELAY] = 1;
            }
            else
            {
                NEG_RELAY_NEG_ON();
                event = EVT_RELAY_CPL_SUC;
            }
            g_relay_last_cmd.bit_t.neg_relay = 1;
            break;
        }
        case PRE_RELAY:
        {
            PRE_CHG_RELAY_ON();
            g_relay_last_cmd.bit_t.pre_relay = 1;
            event = EVT_RELAY_CPL_SUC;
            break;
        }
        default:
            break;
    }
    if (event == EVT_RELAY_CPL_SUC)
    {
        g_relay_state[type] = RELAY_DOING;
        g_relay_operate_cpl_time_stamp[type] = sdk_tick_get();
    }
    return event;
}
static uint8_t sta_relay_close_result_run(void)
{
    uint8_t type = g_relay_type;
    uint8_t event = EVT_NULL;
//    int32_t res;
    if (type >= POWER_RELAY_NUM)
    {
        return EVT_NULL;
    }
    if (sdk_is_tick_over(g_relay_operate_cpl_time_stamp[type], os_tick_from_millisecond(g_relay_para[type].close_max_time)))
    {
        switch (type)
        {
            case POS_RELAY:
            {
                if(true == POS_RELAY_STATUS_READ())
                {
                    g_relay_state[POS_RELAY] = true;                    
                }
                
                break;
            }
            case NEG_RELAY:
            {
                if(true == NEG_RELAY_STATUS_READ()) 
                {
                    g_relay_state[NEG_RELAY] = true;                    
                }
                break;
            }            
            case PRE_RELAY:
            {
                g_relay_state[PRE_RELAY] = RELAY_CLOSE;
                break;
            }           
            default:
                break;
        }
        if (g_relay_state[type] == RELAY_CLOSE)
        {
            event = EVT_RELAY_CPL_SUC;
            g_relay_close_err_cnt[type] = 0;
        }
        else
        {
            g_relay_close_err_cnt[type]++;
            if (g_relay_close_err_cnt[type] >= RELAY_OPERATE_ERR_MAX_CONT_NUM)
            {
                event = EVT_RELAY_ERR;
            }
            else
            {
                event = EVT_RELAY_REOPERATE;
            }
        }        
    }
    return event;
}

static uint8_t sta_relay_close_low_power_entry(void)
{
    uint8_t type = g_relay_type;
    if (type < POWER_RELAY_NUM)
    {
        g_relay_operate_low_pow_time[type] = sdk_tick_get();
    }
    return EVT_NULL;
}

static uint8_t sta_relay_close_low_power_run(void)
{
    uint8_t type = g_relay_type;
    uint8_t event = EVT_NULL;
    uint8_t relay_cur_cmd = 0; // 默认断开

    if (type >= POWER_RELAY_NUM)
    {
        return event;
    }

    switch (type)
    {
        case POS_RELAY:
        {
            relay_cur_cmd = g_relay_ctrl_cmd.bit_t.pos_relay;
            break;
        }
        case NEG_RELAY:
        {
            relay_cur_cmd = g_relay_ctrl_cmd.bit_t.neg_relay;
            break;
        }
        case PRE_RELAY:
        {
            event = EVT_RELAY_CPL_SUC; // 预充不存在低功耗，直接跳转
            break;
        }
        default:
            break;
    }
    // 判断是否断开
    if (0 == relay_cur_cmd)
    {
        event = EVT_RELAY_CPL_SUC;
    }
    if (sdk_is_tick_over(g_relay_operate_low_pow_time[type], os_tick_from_millisecond(g_relay_para[type].low_pow_max_time)))
    {
        switch (type)
        {
            case POS_RELAY:
            {
                POS_RELAY_POS_OFF();
                break;
            }
            case NEG_RELAY:
            {
                NEG_RELAY_POS_OFF();
                break;
            }
            default:
                break;
        }
        log_e("[RLY]rlyType=%d,lowPow\n", type);
        event = EVT_RELAY_CPL_SUC;
    }
    return event;
}

static uint8_t sta_relay_error_entry(void)
{
    uint8_t type = g_relay_type;
    if (type >= POWER_RELAY_NUM)
    {
        return EVT_NULL;
    }
    g_relay_abnormal_flag[type] = 1;
    log_e("[RLY]rlyAbType=%d,opr=%x,stat=%d\n", type, g_relay_ctrl_cmd.val, g_relay_state[type]);
    return EVT_RELAY_CPL_SUC;
}

static void relay_ctrl_fsm_init(void)
{
    for (uint8_t i = 0; i < POWER_RELAY_NUM; i++)
    {
        g_relay_type = (relay_type_e)i;
        state_machine_init(&g_relay_fsm[g_relay_type], g_relay_fsm_name[g_relay_type], g_relay_act_map, (uint8_t *)g_relay_evt_sta_map,
            RELAY_CTRL_EVT_NUM, RELAY_CTRL_STA_NUM, RELAY_IDLE);
    }
}

/******************************************继电器安全控制状态机相关处理函数结束*******************************************************/
/**
* @brief		绝缘阻抗检测启动处理
* @param		[in]预充切断标志（除了绝缘阻抗检测结果外的切断综合）， true:切断，false:闭合
* @return		绝缘阻抗关断标志
* @retval		无
* @warning		无
*/
//static void ins_restart_deal(uint8_t relay_cutoff_flag)
//{
//    static uint8_t last_relay_cutoff_flag = false;
//    int32_t ins_check_result = insulation_impedance_check_result_get();
//    static uint8_t delay_start_ins_time = 0;
//    // 判断是否需要启动绝缘阻抗
//    if (true == last_relay_cutoff_flag && false == relay_cutoff_flag)
//    {
//        // 关断标志消失，立即启动绝缘阻抗检测
//        delay_start_ins_time = 1;
//    }
//    else if (false == last_relay_cutoff_flag && true == relay_cutoff_flag)
//    {
//        // 关断标志置位，延迟2.5s(考虑到bmu通讯时间的问题)后如果属于故障状态或者关机状态就不需要启动
//        delay_start_ins_time = 250;
//    }
//    if (delay_start_ins_time > 0)
//    {
//        delay_start_ins_time--;
//        if ((0 == delay_start_ins_time) &&
//            (BCU_STATE_PF_ERROR != bms_state_get_sys_sta()) &&
//            (BCU_STATE_SHUT_DOWN != bms_state_get_sys_sta()) &&
//            (INSULATION_IMPEDANCE_NORMAL != ins_check_result))
//        {
//            log_e("[RLY]insStart\n");
//            insulation_impedance_calc_start();
//        }
//    }
//}

/**
* @brief		绝缘阻抗断开继电器处理
* @param		[in]预充切断标志（除了绝缘阻抗检测结果外的切断综合）， true:切断，false:闭合
* @return		绝缘阻抗关断标志
* @retval		true:满足切断条件    false:不满足
* @warning		无
*/
static uint8_t ins_cutoff_relay_deal(uint8_t relay_cutoff_flag)
{
    int32_t ins_check_result = insulation_impedance_check_result_get();
    // 判断是否需要等待绝缘阻抗检测完成后闭合继电器
    uint8_t cutoff_flag = false;
    uint8_t ins_cutoff_flag = !((INSULATION_IMPEDANCE_NORMAL == ins_check_result)
        /* || (INSULATION_IMPEDANCE_NORMAL_OVERTIME == ins_check_result && PRE_ONGOING == get_pre_charge_state())*/);
    static uint8_t last_ins_cutoff_flag = false;
    if (PRE_FAIL == get_pre_charge_state() || PRE_SUCCESS == get_pre_charge_state() || (false == ins_cutoff_flag))
    {
        cutoff_flag = relay_cutoff_flag;
    }
    else // 如果绝缘阻抗未完成或者失败，不能闭合继电器；否则保持原先的控制状态
    {
        cutoff_flag = true;
        if (false == last_ins_cutoff_flag && true == ins_cutoff_flag)
        {
            log_e("[RLY]insCutoff=%d\n", ins_cutoff_flag);
        }
    }
    last_ins_cutoff_flag = ins_cutoff_flag;
    return cutoff_flag;
}

/**
* @brief		切断充放电继电器条件
* @param		无
* @return		无
* @retval		true:满足切断条件    false:不满足
* @warning		无
*/
uint8_t relay_cutoff_condition(void)
{
    uint8_t cutoff_flag = true;

    const bmu_data_unify_t *p_bmu_data_unify = bmu_data_unify_get();
    uint8_t pack_num = auto_addressing_pack_num_get();

    if (p_bmu_data_unify == NULL)
    {
        return true;
    }
    
    if (pack_num < PACK_MIN_NUM || pack_num > PACK_MAX_NUM)
    {
        return true;
    }
    

    if(INSULATION_IMPEDANCE_NORMAL != insulation_impedance_check_result_get())
    {
        return true;
    }    

    if(CMU_ERR_CUT_OFF == get_parallel_state(PARALLEL_ERR))
    {
        for(uint8_t i = 0; i < POWER_RELAY_NUM; i++)
        {
            g_relay_para[i].open_load_max_time = RELAY_OPEN_LOAD_MAX_TICK_0MS;
        }
    }
    else if(BAT_ERR == get_parallel_state(PARALLEL_ERR))
    {
        for(uint8_t i = 0; i < POWER_RELAY_NUM; i++)
        {
            g_relay_para[i].open_load_max_time = RELAY_OPEN_LOAD_MAX_TICK_6000MS;
        }        
    }
    else if(CMU_NOR_CUT_OFF == get_parallel_state(PARALLEL_ERR))
    {
        for(uint8_t i = 0; i < POWER_RELAY_NUM; i++)
        {
            g_relay_para[i].open_load_max_time = RELAY_OPEN_LOAD_MAX_TICK_15000MS;
        }         
    }
    else
    {
        cutoff_flag = false;
        for(uint8_t i = 0; i < POWER_RELAY_NUM; i++)
        {
            g_relay_para[i].open_load_max_time = RELAY_OPEN_LOAD_MAX_TICK_15000MS;
        }                 
    }


    return cutoff_flag;

}
/**
* @brief		预充处理
* @param		无
* @return		无
* @retval		无
* @warning		无
*/
static void pre_charge(void)
{
    uint8_t event;
    if(true == get_parallel_state(PARALLEL_FIRST_MACH))
    {
        if (false == relay_cutoff_condition())
        {
            event = state_machine_proc(&g_pre_chg_fsm);
            fsm_state_trans(&g_pre_chg_fsm, event);

        }
        else 
        {
            event = EVT_PRE_CUT_OFF;
            fsm_state_trans(&g_pre_chg_fsm, event);
            g_pre_chg_state = PRE_INIT;
        }        
    }
    else if (true == get_parallel_state(PARALLEL_CON))  //其他不需要预充的
    {
        if (false == relay_cutoff_condition())
        {
            event = state_machine_proc(&g_chg_fsm);
            fsm_state_trans(&g_chg_fsm, event);
            
        }
        else
        {
            event = EVT_CHG_CUT_OFF;
            fsm_state_trans(&g_chg_fsm, event);           
        }
        
  
    }
    else
    {
        ;
    }

}



/**
* @brief		安全控制流程
* @param		无  
* @return		无
* @retval		无
* @warning		无 
*/
static void bat_security(void)
{
    if (true == relay_cutoff_condition())
    {
        REQ_PRE_RELAY_OFF();    
        if(BMS_CHARGE_MODE == bms_state_get_bat_sta())  //充电模式下先断开主正
        {
            REQ_POS_RELAY_OFF();             
        }
        else if(BMS_DISCHARGE_MODE == bms_state_get_bat_sta())  //放电模式下先断开主负
        {
            REQ_NEG_RELAY_OFF();            
        }
        else    //断开其中一个后，系统进入待机，把剩余的继电器断开；
        {
            REQ_POS_RELAY_OFF();  
            REQ_NEG_RELAY_OFF();  
        }
        

    }
}

/**
* @brief		辅电继电器设置
* @param		uint8_t ctrl     0：断开；1：吸合  
* @return		无
* @retval		无
* @warning		无 
*/
void aux_relay_set(uint8_t ctrl)
{
    if((ctrl == true) || (ctrl == false))
    {
        g_aux_relay_set_flag = ctrl;
    }
}



static void aux_relay_ctrl(void)
{
    static uint8_t pre_aux_relay_stus = true;   //默认就是吸合
    // 在sdk_dido_init时已经默认将其吸合
    
    //上位机强控，优先级高
    if(1 == (get_gobal_bcu_info()->set_clu_sw))
    {
        if(get_gobal_bcu_info()->set_clu_do & (0x01 << DO7))
        {
//            pre_aux_relay_stus = true;
//            g_aux_relay_set_flag = true;
            sdk_dido_write(DO_10_AUXILIARY_POWER_SWITCH,1);

        }
        else
        {
//            pre_aux_relay_stus = false;
//            g_aux_relay_set_flag = false;            
            sdk_dido_write(DO_10_AUXILIARY_POWER_SWITCH,0);

        }
        
        return;
    }     
    
    if(pre_aux_relay_stus != g_aux_relay_set_flag)
    {
        pre_aux_relay_stus = g_aux_relay_set_flag;
        
        if(g_aux_relay_set_flag == true)
        {
            sdk_dido_write(DO_10_AUXILIARY_POWER_SWITCH,1);

        }
        else
        {
            sdk_dido_write(DO_10_AUXILIARY_POWER_SWITCH,0);

        }        
    }

    
}


/**
* @brief		功率继电器安全控制
* @param		无  
* @return		无
* @retval		无
* @warning		无 
*/
static void relay_safety_ctrl(void)
{
    for (uint8_t i = 0; i < POWER_RELAY_NUM; i++)
    {
        uint8_t event;
        g_relay_type = (relay_type_e)i;
        event = state_machine_proc(&g_relay_fsm[g_relay_type]);
        fsm_state_trans(&g_relay_fsm[g_relay_type], event);
    }
    
    aux_relay_ctrl();
}

/**
* @brief		DO控制模式
* @param		无  
* @return		无
* @retval		无
* @warning		无 
*/
static void relay_do_ctrl()
{
    
    if(1 == (get_gobal_bcu_info()->set_clu_sw))
    {
        if(get_gobal_bcu_info()->set_clu_do & (0x01 << DO1))
        {
            REQ_POS_RELAY_ON();       
        }
        else
        {
            REQ_POS_RELAY_OFF();
        }
        if(get_gobal_bcu_info()->set_clu_do & (0x01 << DO2))
        {
            REQ_PRE_RELAY_ON();       
        }
        else
        {
            REQ_PRE_RELAY_OFF();
        }

        if(get_gobal_bcu_info()->set_clu_do & (0x01 << DO3))
        {
            REQ_NEG_RELAY_ON();
        }
        else
        {
            REQ_NEG_RELAY_OFF();
        }
    } 
}


/**
* @brief		系统继电器管理流程
* @param		无
* @return		无
* @retval		无
* @warning		无
*/
void relay_manage_proc(void)
{
    if (special_mode_get(ATUO_TEST))
    {
        relay_safety_ctrl();
        return;
    }
    if(get_gobal_bcu_info()->set_clu_sw)
    {
        relay_do_ctrl();
        relay_safety_ctrl();
        return;
    }
    
    
//    ins_restart_deal(g_exp_ins_cutoff_relay_flag);
    if(true == g_relay_manage_enable)
    {
       pre_charge();
       bat_security();	
    }
    else
    {
        REQ_POS_RELAY_OFF();
        REQ_NEG_RELAY_OFF();
        REQ_PRE_RELAY_OFF();
        fsm_state_trans(&g_pre_chg_fsm, EVT_PRE_CUT_OFF);
        g_pre_chg_state = PRE_INIT;
//        g_exp_ins_cutoff_relay_flag = true;
    }
    relay_safety_ctrl();
}

/**
* @brief		mos管理初始化
* @param		无  
* @return		无
* @retval		无
* @warning		无 
*/
void relay_manage_init(void)
{
	/*全局变量初始化*/
	g_relay_manage_enable = false;
    g_relay_ctrl_cmd.val = 0;
    pre_chg_fsm_init(); // 预充状态机初始化
    chg_fsm_init(); // 非预充状态初始化
    relay_ctrl_fsm_init(); // 继电器控制初始化	
}

/**
* @brief		系统继电器管理使能接口
* @param		[in]使能标志： 0：不使能    1：使能  
* @return		返回结果
* @retval		0：操作成功    < 0: 操作失败
* @warning		无 
*/
int32_t relay_manage_enable_set(uint8_t enable)
{
    int32_t ret = 0;

    if(false == enable)
    {
        g_relay_manage_enable = false;
    }
    else if(true == enable)
    {
        g_relay_manage_enable = true;
    }
    else
    {
        ret = -1;
    }
    return ret;
}

/**
* @brief		获取继电器实际状态
* @param		[in] relay_type 充电mos，放电mos，预充mos状态
* @return		执行结果
* @retval		0：断开， 1: 闭合， 2:操作中, -1:输入参数异常
* @warning		无 
*/
int32_t get_relay_real_state(uint8_t relay_type)
{
    if (relay_type >= POWER_RELAY_NUM)
    {
        return -1;
    }
    return g_relay_state[relay_type];
}
/**
* @brief		获取继电器异常标志
* @param		[in] relay_type 充电mos，放电mos，预充mos状态
* @return		执行结果
* @retval		0：断开， 1: 闭合， 2:操作中
* @warning		无 
*/
int32_t get_relay_abnormal_flag(uint8_t relay_type)
{
    if (relay_type >= POWER_RELAY_NUM)
    {
        return -1;
    }
    return g_relay_abnormal_flag[relay_type];
}
/**
* @brief		继电器切断指令
* @param		[in] cmd  0：允许闭合mos， 1： 切断mos 
* @return		无
* @retval		无
* @warning		无 
*/
int32_t relay_cutoff_cmd(uint8_t cmd)
{
	if(cmd > 1)
	{
		return -1;
	}
	
	g_power_relay_on_flag = cmd;
	
	return 0;   
}


/**
* @brief		强充继电器控制指令
* @param		[in] cmd  0xAA：允许闭合， 0x55： 切断mos 
* @return		无
* @retval		无
* @warning		无 
*/
int32_t force_chrg_relay_ctrl_cmd(uint8_t cmd)
{	
	g_force_ch_relay_on_flag = cmd;
	
	return 0;   
}


/**
* @brief		获取预充状态
* @param		无
* @return		执行结果
* @retval		预充初始化	PRE_INIT
* @retval		预充进行中	PRE_ONGOING
* @retval		预充成功		PRE_SUCCESS
* @retval		预充失败 	PRE_FAIL
* @warning		无 
*/
pre_charge_state_e get_pre_charge_state(void)
{
    return (pre_charge_state_e)g_pre_chg_state;
}

/**
* @brief		获取继电器控制状态
* @param		[in] relay_type 充电mos，放电mos，预充mos状态
* @return		执行结果
* @retval		0：断开， 1: 闭合
* @warning		无
*/
int32_t get_relay_contrl_state(uint8_t relay_type)
{
    int32_t status = -1;
    switch (relay_type)
    {
        case POS_RELAY:
            status = g_relay_ctrl_cmd.bit_t.pos_relay;
            break;
        case NEG_RELAY:
            status = g_relay_ctrl_cmd.bit_t.neg_relay;
            break;
        case PRE_RELAY:
            status = g_relay_ctrl_cmd.bit_t.pre_relay;
            break;
        default:
            break;
    }
    return status;
}

/**
* @brief		设置继电器控制状态
* @param		[in] relay_type 充电mos，放电mos，预充mos状态
* @param		[in] set_flag     true：闭合  false: 断开
* @warning		ate模式调用
*/
void relay_contrl_state_set(uint8_t relay_type, uint32_t set_flag)
{
    switch (relay_type)
    {
        case POS_RELAY:
            g_relay_ctrl_cmd.bit_t.pos_relay = set_flag;
            break;
        case NEG_RELAY:
            g_relay_ctrl_cmd.bit_t.neg_relay = set_flag;
            break;
        case PRE_RELAY:
            g_relay_ctrl_cmd.bit_t.pre_relay = set_flag;
            break;
        default:
            break;
    }
}

/**
* @brief		获取继电器上次控制状态（这里和实际di状态置位在同一个地方，时序比较合适加该函数给继电器粘连判断使用）
* @param		[in] relay_type 充电mos，放电mos，预充mos状态
* @return		执行结果
* @retval		0：断开， 1: 闭合
* @warning		无
*/
int32_t get_relay_contrl_last_state(uint8_t relay_type)
{
    int32_t status = -1;
    switch (relay_type)
    {
        case POS_RELAY:
            status = g_relay_last_cmd.bit_t.pos_relay;
            break;
        case NEG_RELAY:
            status = g_relay_last_cmd.bit_t.neg_relay;
            break;
        case PRE_RELAY:
            status = g_relay_last_cmd.bit_t.pre_relay;
            break;
        default:
            break;
    }
    return status;
}

/**
 * @brief  Get the load cut off flag object 
 * @return uint8_t: true:带载切断；false：非戴载切断
 */
uint8_t get_load_cut_off_flag(void)
{
    uint8_t flag = false;

    flag = g_load_cut_off_flag;

    if(true == g_load_cut_off_flag) //统计完后清除此次标志
    {
        g_load_cut_off_flag = false;
    }

    return flag;
}

/***********************************RELAY_MANAGE_DEBUG shell debug************************************************/
#if RELAY_MANAGE_DEBUG_SHELL_FLAG

// 打印
void relay_debug_printf(void)
{
    log_d("\nforceChRlyOn=%#x\n", g_force_ch_relay_on_flag);
    log_d("powerRlyOn=%#x\n", g_power_relay_on_flag);
    log_d("rlyManageEn=%#x\n", g_relay_manage_enable);
    log_d("preChgSta=%#x\n", g_pre_chg_state);
    log_d("POS=%d\n", get_relay_contrl_state(POS_RELAY));
    log_d("NEG=%d\n", get_relay_contrl_state(NEG_RELAY));
    log_d("PRE=%d\n", get_relay_contrl_state(PRE_RELAY));
}

void relay_debug_err_printf(void)
{
//    log_d("\n rly param err\n");
//    log_d(" rly print : printf data\r\n");
//    log_d(" rly help 0/1: printf data\r\n");
}

void relay_debug_help_printf(void)
{
//    log_d("\npre_charge_state:\n");
//    log_d("PRE_INIT            = %d\n", PRE_INIT       ); 
//    log_d("PRE_ONGOING         = %d\n", PRE_ONGOING    ); 
//    log_d("PRE_SUCCESS         = %d\n", PRE_SUCCESS    ); 
//    log_d("PRE_FAIL            = %d\n", PRE_FAIL       );

//    log_d("\nrelay_type_e:\n");
//    log_d("POS_RELAY            = %d\n", POS_RELAY           );
//    log_d("NEG_RELAY            = %d\n", NEG_RELAY           );
//    log_d("PRE_RELAY            = %d\n", PRE_RELAY           );
//    
//    log_d("\npre_chg_fsm_state_e:\n");
//    log_d("PRE_CHG_INIT         = %d\n",     PRE_CHG_INIT    );
//    log_d("PRE_CHG_START        = %d\n",     PRE_CHG_START    );
//    log_d("PRE_CHG_STAGE1       = %d\n",     PRE_CHG_STAGE1    );
//    log_d("PRE_CHG_STAGE2       = %d\n",     PRE_CHG_STAGE2    );
//    log_d("PRE_CHG_AGAIN        = %d\n",     PRE_CHG_AGAIN    );
//    log_d("PRE_CHG_FINISH       = %d\n",     PRE_CHG_FINISH    );
//    log_d("PRE_CHG_ERROR        = %d\n",     PRE_CHG_ERROR    );
}

/**
 * @brief        relay功能样例
 * @param        argv 功能参数
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
static int relay(int argc, char *argv[])
{
    if (argc < 2)
    {
        log_d("relayParaErr\n");
        return SF_ERR_PARA;
    }
    if (!strcmp(argv[1], "print"))
    {
        relay_debug_printf();
    }
    else if (!strcmp(argv[1], "help"))
    {
        relay_debug_help_printf();
    }

    return 0;
}

MSH_CMD_EXPORT(relay, <print>);
#endif

