#include "fault_manage.h"
#include "sample.h"
#include "data_store.h"
#include "sdk.h"
#include "sdk_core.h"
#include "app_public.h"
#include "auto_addressing.h"
#include "bms_state.h"
#include "insulation_impedance_calc.h"
#include "bmu_data.h"
#include "bcu_data.h"
#include "sox.h"
#include "sop.h"
#include "addressing_common.h"
#include "relay_manage.h"
#include "data_store.h"
#include "external_can_data.h"
#include "public_flag.h"
#include "parallel_manage.h"

#define FAULT_MANAGE_LOGD(...) log_d(__VA_ARGS__)
#define FAULT_MANAGE_LOGE(...) log_e(__VA_ARGS__)

#define OVER_CURR_LOCK_TIMES    5						// 过流锁死持续次数
#define CELL_VOLT_INVALID_MAX	4000					// 电芯失效最高电压 0.001V
#define CELL_VOLT_INVALID_MIN	1000					// 电芯失效最低电压 0.001V
#define CELL_VOLT_INVALID_DIFF	1000					// 电芯失效压差 0.001V
#define CHARGER_ACCESS_STATUS   0
#define POWER_TERMINAL_TEMP_OVER_LOCK_TIMES    8        // 功率端子过温保护次数
#define INNER_CAN_ADDR_OVER_LOCK_TIMES         15       // 内can编址异常锁死次数, 一次编址约10s，5min计数15次，约2.5min
#define Comm_Cnt                5
#define RUNNING_DATA_SAVE_PERIOD (1000 * 60 * 30)       // 30分钟保存一次运行数据
#define FAULT_GROUP_SIZE        32
#define FAULT_GROUP_NUM         ((FAULT_MAX + FAULT_GROUP_SIZE - 1) / FAULT_GROUP_SIZE)

static uint8_t                  g_fault_enable;                         // 故障诊断使能
static uint32_t 		        g_fault_state[FAULT_GROUP_NUM];			// 故障状态，位操作， bit=0(无故障) bit=1(有故障)
static fault_diag_step_e	    g_fault_diag_step;		                // 故障诊断步骤
static sample_data_t	        g_sample_data;			                // bcu实时采集数据 用来做故障判断
static bmu_data_unify_t*        gp_bmu_data_unify = NULL;               // bmu实时汇总数据 用来做故障判断
static fault_lock_data_t		g_fault_lock_data;		                // 故障锁死数据
static const safety_para_tab_t* gp_fault_para;	    	                // 故障参数，每个故障对应1个产生阈值和1个消失阈值
static uint8_t                  g_time2scnt = 0;                        // BMU与BCU通讯超时滤波计数
static fault_id_t               g_fault_id = {0};
static uint8_t                  g_pack_num = 0;
static fault_stat_data_t g_fault_stat_data = {0, LEVEL3, LEVEL3};



// BCU回复的报警信息
static gold_warn_msg_t g_warn_msg_reply = {0};

static uint16_t g_can_hall_sensor_comm_err_cnt = 0;    // CAN霍尔传感器通讯故障计数器
static uint16_t g_bcu_pcs_comm_err_cnt = 0;            // BCU-PCS通讯故障计数器

#define ALARM_APPEAR  1
#define ALARM_RECOVER  0

typedef bool(*alarm_deal_callback)(fault_type_e, bool);
typedef void (*alarm_print_callback)(fault_type_e, bool);
static uint16_t g_alarm_cnt[FAULT_MAX] = {0};

// 硬件自检异常标志
static uint8_t g_hard_self_det_abn_flag = 0;

/**
  * @struct   fault_para_tab_t
  * @brief  故障参数表结构定义
  */
typedef struct 
{
    fault_type_e         fault_type;              ///< 故障类型
    uint16_t             appear_cnt;              ///< 故障出现持续的次数
    uint16_t             cancel_cnt;              ///< 故障消失持续的次数
    uint8_t             charge_level;             ///< 充电等级
    uint8_t             discharge_level;          ///< 放电等级
    uint8_t             fault_decore_enable;      ///< 录波使能
    alarm_deal_callback  p_alarm_cb;              ///< 注册的回调函数
    alarm_print_callback p_alarm_print_cb;        ///< 注册的告警打印回调函数
} fault_para_tab_t;

// 告警回调函数
static bool fault_power_terminal_temp_sam_abnormal_check(fault_type_e fault_id, bool is_appear);
static bool alarm_env_temp_sam_abnormal_check(fault_type_e fault_id, bool is_appear);
static bool fault_flash_invalid_check(fault_type_e fault_id, bool is_appear);
static bool fault_inner_can_comm_invalid_check(fault_type_e fault_id, bool is_appear);
static bool fault_bcu_pcs_can_comm_invalid_check(fault_type_e fault_id, bool is_appear);
static bool alarm_bcu_bcu_can_id_conflict_check(fault_type_e fault_id, bool is_appear);
static bool tip_power_terminal_temp_over_check(fault_type_e fault_id, bool is_appear);
static bool alarm_power_terminal_temp_over_check(fault_type_e fault_id, bool is_appear);
static bool pro_power_terminal_temp_over_check(fault_type_e fault_id, bool is_appear);
static bool fault_positive_relay_adhesion_check(fault_type_e fault_id, bool is_appear);
static bool fault_negative_relay_adhesion_check(fault_type_e fault_id, bool is_appear);
static bool fault_auxiliary_relay_adhesion_check(fault_type_e fault_id, bool is_appear);
static bool tip_ins_val_low_check(fault_type_e fault_id, bool is_appear);
static bool alarm_ins_val_low_check(fault_type_e fault_id, bool is_appear);
static bool pro_ins_val_low_check(fault_type_e fault_id, bool is_appear);
static bool fault_ext_adc_abnormal_check(fault_type_e fault_id, bool is_appear);
static bool fault_inner_can_addr_repeat_check(fault_type_e fault_id, bool is_appear);
static bool fault_pre_charge_check(fault_type_e fault_id, bool is_appear);
static bool tip_env_temp_high_check(fault_type_e fault_id, bool is_appear);
static bool alarm_env_temp_high_check(fault_type_e fault_id, bool is_appear);
static bool pro_env_temp_high_check(fault_type_e fault_id, bool is_appear);
static bool tip_power_volt_over_check(fault_type_e fault_id, bool is_appear);
static bool tip_power_volt_under_check(fault_type_e fault_id, bool is_appear);
static bool fault_trip_check(fault_type_e fault_id, bool is_appear);
static bool fault_can_hall_sensor_check(fault_type_e fault_id, bool is_appear);
static bool fault_can_hall_sensor_comm_check(fault_type_e fault_id, bool is_appear);
static bool fault_hard_self_det_check(fault_type_e fault_id, bool is_appear);
static bool fault_power_off_err_check(fault_type_e fault_id, bool is_appear);
static bool fault_all_cluster_power_off_err_check(fault_type_e fault_id, bool is_appear);
static bool fault_hall_curr_diff_over_check(fault_type_e fault_id, bool is_appear);

static bool bat_cluster_volt_over_tip_check(fault_type_e fault_id, bool is_appear);
static bool bat_cluster_volt_over_alarm_check(fault_type_e fault_id, bool is_appear);
static bool bat_cluster_volt_over_pro_check(fault_type_e fault_id, bool is_appear);
static bool bat_cluster_under_volt_tip_check(fault_type_e fault_id, bool is_appear);
static bool bat_cluster_under_volt_alarm_check(fault_type_e fault_id, bool is_appear);
static bool bat_cluster_under_volt_pro_check(fault_type_e fault_id, bool is_appear);
static bool bat_cluster_volt_diff_over_fault_check(fault_type_e fault_id, bool is_appear);
static bool bat_inter_clu_volt_diff_over_fault_check(fault_type_e fault_id, bool is_appear);
static bool charge_overcurrent_limit_alarm_check(fault_type_e fault_id, bool is_appear);
static bool charge_overcurrent_limit_protect_check(fault_type_e fault_id, bool is_appear);
static bool charge_over_current_tip_check(fault_type_e fault_id, bool is_appear);
static bool charge_over_current_alarm_check(fault_type_e fault_id, bool is_appear);
static bool charge_over_current_pro_check(fault_type_e fault_id, bool is_appear);
static bool dischg_overcurrent_limit_alarm_check(fault_type_e fault_id, bool is_appear);
static bool dischg_overcurrent_limit_protect_check(fault_type_e fault_id, bool is_appear);
static bool discharge_over_current_tip_check(fault_type_e fault_id, bool is_appear);
static bool discharge_over_current_alarm_check(fault_type_e fault_id, bool is_appear);
static bool discharge_over_current_pro_check(fault_type_e fault_id, bool is_appear);
static bool chg_dchg_overcurrent_disable_check(fault_type_e fault_id, bool is_appear);
static bool overcurrent_deadlock_check(fault_type_e fault_id, bool is_appear);
static bool inter_clu_cur_diff_high_alarm_check(fault_type_e fault_id, bool is_appear);
static bool bat_soc_low_tip_check(fault_type_e fault_id, bool is_appear);
static bool bat_soc_low_alm_check(fault_type_e fault_id, bool is_appear);
static bool bat_soc_low_pro_check(fault_type_e fault_id, bool is_appear);
static void fill_warn_msg(gold_warn_msg_t *p_warn_msg);
static void fault_change_check_deal(void);

// 打印函数
static void fault_power_terminal_temp_sam_abnormal_print(fault_type_e fault_id, bool is_appear);
static void alarm_env_temp_sam_abnormal_print(fault_type_e fault_id, bool is_appear);
static void bat_cluster_volt_diff_over_fault_print(fault_type_e fault_id, bool is_appear);
static void fault_inner_can_comm_invalid_print(fault_type_e fault_id, bool is_appear);
static void tip_power_terminal_temp_over_print(fault_type_e fault_id, bool is_appear);
static void alarm_power_terminal_temp_over_print(fault_type_e fault_id, bool is_appear);
static void pro_power_terminal_temp_over_print(fault_type_e fault_id, bool is_appear);
static void fault_positive_relay_adhesion_print(fault_type_e fault_id, bool is_appear);
static void fault_negative_relay_adhesion_print(fault_type_e fault_id, bool is_appear);
static void tip_ins_val_low_print(fault_type_e fault_id, bool is_appear);
static void alarm_ins_val_low_print(fault_type_e fault_id, bool is_appear);
static void pro_ins_val_low_print(fault_type_e fault_id, bool is_appear);
static void tip_env_temp_high_print(fault_type_e fault_id, bool is_appear);
static void alarm_env_temp_high_print(fault_type_e fault_id, bool is_appear);
static void pro_env_temp_high_print(fault_type_e fault_id, bool is_appear);
static void tip_power_volt_over_print(fault_type_e fault_id, bool is_appear);
static void tip_power_volt_under_print(fault_type_e fault_id, bool is_appear);
static void fault_hard_self_det_print(fault_type_e fault_id, bool is_appear);
static void fault_power_off_err_print(fault_type_e fault_id, bool is_appear);
static void fault_hall_curr_diff_over_print(fault_type_e fault_id, bool is_appear);

static void bat_cluster_volt_over_tip_print(fault_type_e fault_id, bool is_appear);
static void bat_cluster_volt_over_alarm_print(fault_type_e fault_id, bool is_appear);
static void bat_cluster_volt_over_pro_print(fault_type_e fault_id, bool is_appear);
static void bat_cluster_under_volt_tip_print(fault_type_e fault_id, bool is_appear);
static void bat_cluster_under_volt_alarm_print(fault_type_e fault_id, bool is_appear);
static void bat_cluster_under_volt_pro_print(fault_type_e fault_id, bool is_appear);
static void charge_over_current_tip_print(fault_type_e fault_id, bool is_appear);
static void charge_over_current_alarm_print(fault_type_e fault_id, bool is_appear);
static void charge_over_current_pro_print(fault_type_e fault_id, bool is_appear);
static void discharge_over_current_tip_print(fault_type_e fault_id, bool is_appear);
static void discharge_over_current_alarm_print(fault_type_e fault_id, bool is_appear);
static void discharge_over_current_pro_print(fault_type_e fault_id, bool is_appear);
static void chg_dchg_overcurrent_disable_print(fault_type_e fault_id, bool is_appear);
static void overcurrent_deadlock_print(fault_type_e fault_id, bool is_appear);
static void bat_soc_low_tip_print(fault_type_e fault_id, bool is_appear);
static void bat_soc_low_alm_print(fault_type_e fault_id, bool is_appear);
static void bat_soc_low_pro_print(fault_type_e fault_id, bool is_appear);
void fault_name_print_deal(fault_type_e fault_id, bool is_appear);

/**
  * @struct   g_fault_param_tab
  * @brief    故障参数表
  */
const static fault_para_tab_t g_fault_para_tab[] =
{
	// 故障类型	 -/-	       				--- 产生时间 --- 消失时间 - 充电等级 -- 放电等级  --  -- 录波使能-- --故障告警回调函数
	//                                             （n*扫描周期10ms)
	{BOARD_POWER_TERMINAL_TEMP_SAM_FAULT,		 30,		 30,	    LEVEL0,		 LEVEL0,		DISABLE,  fault_power_terminal_temp_sam_abnormal_check  , fault_power_terminal_temp_sam_abnormal_print              }, 
	{BOARD_ENV_TEMP_SAM_ABNORMAL_ALARM,			 30,		 30,	    LEVEL3,		 LEVEL3,		DISABLE,  alarm_env_temp_sam_abnormal_check             , alarm_env_temp_sam_abnormal_print             },  
	{BOARD_FLASH_INVALID_FAULT,					 10,		 10,	    LEVEL0,		 LEVEL0,		DISABLE,  fault_flash_invalid_check                 , fault_name_print_deal                     },  
	{BOARD_INNER_CAN_COMM_FAULT,				 100,		 10,		LEVEL0,		 LEVEL0,		DISABLE,  fault_inner_can_comm_invalid_check        , fault_inner_can_comm_invalid_print        },
    {BOARD_INNER_CAN_ADDR_REPEAT_FAULT,			 100,		 100,		LEVEL0,		 LEVEL0,		DISABLE,  fault_inner_can_addr_repeat_check         , fault_name_print_deal                     },  
	{BOARD_BCU_PCS_CAN_COMM_ABNORMAL_FAULT,		 0,		     1000,		LEVEL0,		 LEVEL0,		DISABLE,  fault_bcu_pcs_can_comm_invalid_check      , fault_name_print_deal                     },
	{BOARD_BCU_BCU_CANID_CONFLICT_ALARM,		 1,		     1,		    LEVEL2,		 LEVEL2,		DISABLE,  alarm_bcu_bcu_can_id_conflict_check       , fault_name_print_deal                     },  
    {BOARD_POWER_TERMINAL_TEMP_OVER_TIPS,	     300,		 300,		LEVEL3,		 LEVEL3,		DISABLE,  tip_power_terminal_temp_over_check        , tip_power_terminal_temp_over_print        },
    {BOARD_POWER_TERMINAL_TEMP_OVER_ALARM,	     300,		 300,		LEVEL2,		 LEVEL2,		DISABLE,  alarm_power_terminal_temp_over_check      , alarm_power_terminal_temp_over_print      },
	{BOARD_POWER_TERMINAL_TEMP_OVER_PROTECT,	 300,		 300,		LEVEL1,		 LEVEL1,		DISABLE,  pro_power_terminal_temp_over_check        , pro_power_terminal_temp_over_print        },
	{BOARD_POSITIVE_RELAY_ADHESION_FAULT,		 300,		 300,		LEVEL0,		 LEVEL0,		DISABLE,  fault_positive_relay_adhesion_check       , fault_positive_relay_adhesion_print       },  
	{BOARD_NEGATIVE_RELAY_ADHESION_FAULT,		 300,		 300,		LEVEL0,		 LEVEL0,		DISABLE,  fault_negative_relay_adhesion_check       , fault_negative_relay_adhesion_print       },  
    {BOARD_AUX_RELAY_ADHESION_FAULT,			 300,		 300,		LEVEL0,		 LEVEL0,		DISABLE,  fault_auxiliary_relay_adhesion_check      , fault_name_print_deal                     },  
	{BOARD_INS_RES_VAL_LOW_TIPS,				 1000,		 1000,		LEVEL3,		 LEVEL3,		DISABLE,  tip_ins_val_low_check                     , tip_ins_val_low_print                     },
    {BOARD_INS_RES_VAL_LOW_ALARM,				 1000,		 1000,		LEVEL2,		 LEVEL2,		DISABLE,  alarm_ins_val_low_check                   , alarm_ins_val_low_print                   },
    {BOARD_INS_RES_VAL_LOW_PROTECT,				 1000,		 1000,		LEVEL1,		 LEVEL1,		DISABLE,  pro_ins_val_low_check                     , pro_ins_val_low_print                     },
    {BOARD_EXT_ADC_FAULT,				         100,		 100,		LEVEL0,		 LEVEL0,		DISABLE,  fault_ext_adc_abnormal_check              , fault_name_print_deal                     },  
    {BOARD_PRE_CHARGE_FAULT,			         100,		 100,		LEVEL0,		 LEVEL0,		DISABLE,  fault_pre_charge_check                    , fault_name_print_deal                     },
    {BOARD_ENV_TEMP_HIGH_TIPS,				     100,		 100,		LEVEL3,		 LEVEL3,		DISABLE,  tip_env_temp_high_check                   , tip_env_temp_high_print                   },  
	{BOARD_ENV_TEMP_HIGH_ALARM,				     100,		 100,		LEVEL3,		 LEVEL3,		DISABLE,  alarm_env_temp_high_check                 , alarm_env_temp_high_print                 },
    {BOARD_ENV_TEMP_HIGH_PROTECT,				 100,		 100,		LEVEL3,		 LEVEL3,		DISABLE,  pro_env_temp_high_check                   , pro_env_temp_high_print                   },
	{BOARD_POWER_VOLT_OVER_TIPS,				 100,		 100,		LEVEL3,		 LEVEL3,		DISABLE,  tip_power_volt_over_check                 , tip_power_volt_over_print                 },  
    {BOARD_POWER_VOLT_UNDER_TIPS,				 100,		 100,		LEVEL3,		 LEVEL3,		DISABLE,  tip_power_volt_under_check                , tip_power_volt_under_print                },
    {BOARD_TRIP_FAULT,				             0,		     0,		    LEVEL3,		 LEVEL3,		DISABLE,  fault_trip_check                          , fault_name_print_deal                     },
    {BOARD_CAN_HALL_SENSOR_FAULT,				 100,		 100,		LEVEL0,		 LEVEL0,		DISABLE,  fault_can_hall_sensor_check               , fault_name_print_deal                     },
    {BOARD_CAN_HALL_SENSOR_COMM_FAULT,			 0,		     300,		LEVEL0,		 LEVEL0,		DISABLE,  fault_can_hall_sensor_comm_check          , fault_name_print_deal                     },
    {BOARD_HARD_SELF_DET_FAULT,			         10,		 10,		LEVEL3,		 LEVEL3,		DISABLE,  fault_hard_self_det_check                 , fault_hard_self_det_print                 },
    {BOARD_POWER_OFF_FAULT,			             0,		     10,		LEVEL0,		 LEVEL0,		DISABLE,  fault_power_off_err_check                 , fault_power_off_err_print                 },
    {BOARD_ALL_CLUSTER_POWER_OFF_FAULT,			 100,		 100,		LEVEL0,		 LEVEL0,		DISABLE,  fault_all_cluster_power_off_err_check     , fault_name_print_deal                     },
    {BOARD_INTER_CLU_CUR_DIFF_OVER_ALARM,		 1000,		 1000,		LEVEL3,		 LEVEL3,		DISABLE,  inter_clu_cur_diff_high_alarm_check       , fault_name_print_deal                     },
    {BOARD_HALL_CURR_DIFF_OVER_ALARM,            100,        100,       LEVEL3,      LEVEL3,        DISABLE,  fault_hall_curr_diff_over_check           , fault_hall_curr_diff_over_print           },  

	{BAT_CLUSTER_TOTAL_VOLT_HIGH_TIPS,			 500,		 500,		LEVEL3,		 LEVEL3,		DISABLE,  bat_cluster_volt_over_tip_check           , bat_cluster_volt_over_tip_print           },
    {BAT_CLUSTER_TOTAL_VOLT_HIGH_ALARM,			 500,		 500,		LEVEL2,		 LEVEL3,		DISABLE,  bat_cluster_volt_over_alarm_check         , bat_cluster_volt_over_alarm_print         },
	{BAT_CLUSTER_TOTAL_VOLT_HIGH_PROTECT,		 500,		 500,		LEVEL1,		 LEVEL3,		DISABLE,  bat_cluster_volt_over_pro_check           , bat_cluster_volt_over_pro_print           },
    {BAT_CLUSTER_TOTAL_VOLT_LOW_TIPS,			 500,		 500,		LEVEL3,		 LEVEL3,		DISABLE,  bat_cluster_under_volt_tip_check          , bat_cluster_under_volt_tip_print          },
	{BAT_CLUSTER_TOTAL_VOLT_LOW_ALARM,			 500,		 500,		LEVEL3,		 LEVEL2,		DISABLE,  bat_cluster_under_volt_alarm_check        , bat_cluster_under_volt_alarm_print        },
	{BAT_CLUSTER_TOTAL_VOLT_LOW_PROTECT,		 500,		 500,		LEVEL3,		 LEVEL1,		DISABLE,  bat_cluster_under_volt_pro_check          , bat_cluster_under_volt_pro_print          },
    {BAT_CLUSTER_TOTAL_VOLT_DIFF_OVER_FAULT,	 500,	 	 500,		LEVEL0,		 LEVEL0,		DISABLE,  bat_cluster_volt_diff_over_fault_check    , bat_cluster_volt_diff_over_fault_print    },  
    {BAT_INTER_CLU_VOLT_DIFF_OVER_FAULT,	     300,	 	 300,		LEVEL0,		 LEVEL0,		DISABLE,  bat_inter_clu_volt_diff_over_fault_check  , fault_name_print_deal                     },
    {BAT_CHARGE_CURR_OVER_LIMIT_ALARM,           3000,       3000,      LEVEL2,      LEVEL3,        DISABLE,  charge_overcurrent_limit_alarm_check      , fault_name_print_deal                     },
    {BAT_CHARGE_CURR_OVER_LIMIT_PROTECT,         1000,       3000,      LEVEL1,      LEVEL1,        DISABLE,  charge_overcurrent_limit_protect_check    , fault_name_print_deal                     },
    {BAT_DISCHG_CURR_OVER_LIMIT_ALARM,           6000,       3000,      LEVEL3,      LEVEL2,        DISABLE,  dischg_overcurrent_limit_alarm_check      , fault_name_print_deal                     },
    {BAT_DISCHG_CURR_OVER_LIMIT_PROTECT,         1000,       3000,      LEVEL1,      LEVEL1,        DISABLE,  dischg_overcurrent_limit_protect_check    , fault_name_print_deal                     },
    {BAT_CHARGE_CURR_HIGH_TIPS,				     300,	 	 300,	    LEVEL3,		 LEVEL3,		DISABLE,  charge_over_current_tip_check             , charge_over_current_tip_print             },
	{BAT_CHARGE_CURR_HIGH_ALARM,				 300,	 	 300,	    LEVEL2,		 LEVEL3,		DISABLE,  charge_over_current_alarm_check           , charge_over_current_alarm_print           },
	{BAT_CHARGE_CURR_HIGH_PROTECT,				 300,	 	 300,		LEVEL1,		 LEVEL3,		DISABLE,  charge_over_current_pro_check             , charge_over_current_pro_print             },
    {BAT_DISCHG_CURR_OVER_TIPS,				     300,	 	 300,		LEVEL3,		 LEVEL3,		DISABLE,  discharge_over_current_tip_check          , discharge_over_current_tip_print          },
	{BAT_DISCHG_CURR_OVER_ALARM,				 300,	 	 300,		LEVEL3,		 LEVEL2,		DISABLE,  discharge_over_current_alarm_check        , discharge_over_current_alarm_print        },
	{BAT_DISCHG_CURR_OVER_PROTECT,				 300,	 	 300,		LEVEL3,		 LEVEL1,		DISABLE,  discharge_over_current_pro_check          , discharge_over_current_pro_print          },
	{BAT_CURR_OVER_PROTECT_DISABLE,				 0,	 	     0,		    LEVEL1,		 LEVEL1,		DISABLE,  chg_dchg_overcurrent_disable_check        , chg_dchg_overcurrent_disable_print        },
	{BAT_CURR_OVER_SERIOUS_LOCK,				 3500,	 	 0,		    LEVEL0,		 LEVEL0,		DISABLE,  overcurrent_deadlock_check                , overcurrent_deadlock_print                },
    {BAT_SOC_LOW_TIPS,							 300,		 300,		LEVEL3,		 LEVEL3,		DISABLE,  bat_soc_low_tip_check                     , bat_soc_low_tip_print                     },
	{BAT_SOC_LOW_ALARM,							 300,		 300,		LEVEL3,		 LEVEL3,		DISABLE,  bat_soc_low_alm_check                     , bat_soc_low_alm_print                     },
    {BAT_SOC_LOW_PROTECT,					     300,		 300,		LEVEL3,		 LEVEL3,		DISABLE,  bat_soc_low_pro_check                     , bat_soc_low_pro_print                     },
};

const fault_id_t *get_fault_id(void)
{
    return &g_fault_id;
}

/**
* @brief        故障变化标志
* @param        [in] uint8_t *fault_id
* @return        [out]bool  0:无需存储；1：需要存储
* @retval         无
*/
bool fault_state_change(uint8_t *fault_id)
{
    static int8_t cnt = 0;
    static uint32_t fault_state_mask[FAULT_GROUP_NUM] = {0};
    static uint32_t record_fault_state[FAULT_GROUP_NUM] = {0};
    static uint32_t record_fault_last_state[FAULT_GROUP_NUM] = {0};
    static uint8_t init_flag = 0;
    uint8_t store_flag = false;

    if(0 == init_flag)
    {
        init_flag++;
        for(uint16_t i = 0;i < FAULT_MAX;i++)
        {
            if(g_fault_para_tab[i].charge_level < LEVEL2 || g_fault_para_tab[i].discharge_level < LEVEL2)
            {
                uint32_t fault_group_id = i / FAULT_GROUP_SIZE;
                uint32_t fault_offset = i % FAULT_GROUP_SIZE;
                SET_BIT(fault_state_mask[fault_group_id], (1ULL << fault_offset));
            }
        }
    }

    // if((g_fault_stat_data.max_charge_level > LEVEL1) && (g_fault_stat_data.max_discharge_level > LEVEL1))
    // {
    //     return false;
    // }
    
    for(uint16_t i = 0;i < FAULT_GROUP_NUM;i++)
    {
        record_fault_state[i] = g_fault_state[i] & fault_state_mask[i];
    }

    for(uint16_t i = 0;i < FAULT_GROUP_NUM;i++) //确认有0变1的，才需要记录
    {
        for(uint8_t j = 0;j < FAULT_GROUP_SIZE;j++)
        {
            if ((0 == GET_BIT(record_fault_last_state[i], (1ULL << j)))
                && (GET_BIT(record_fault_state[i], (1ULL << j))))
            {
                *fault_id = i * FAULT_GROUP_SIZE + j;   //故障id
                store_flag = true;
                break;
            }
        }
    }    

    memcpy(record_fault_last_state, record_fault_state ,FAULT_GROUP_NUM * sizeof(g_fault_state[FAULT_GROUP_NUM]));    

//    if(0 != memcmp(record_fault_state, record_fault_last_state, FAULT_GROUP_NUM * sizeof(g_fault_state[FAULT_GROUP_NUM])))
    if (true == store_flag)
    {
        // memcpy(record_fault_last_state, record_fault_state ,FAULT_GROUP_NUM * sizeof(g_fault_state[FAULT_GROUP_NUM]));
        if(cnt == 0)
        {
            cnt = WINDOW_SIZE;//故障状态发生变化，充值
        }
        else if (cnt < WINDOW_SIZE)
        {
            cnt += WINDOW_SIZE;
        }
    }
    else
    {
        cnt--;
    }

    if(cnt >= 0)
    {
        return true;
    }
    else
    {
        cnt = 0;
    }

    return false;
}
void fault_id_delete(void)
{
//    while (g_fault_id.fault_cnt > FAULT_RECORD_FILE_NUMS) //TO DO
    {
        log_d("[fault]delete id = %x, fault_cnt = %d\n",g_fault_id.fault_id[0],g_fault_id.fault_cnt);
        g_fault_id.fault_cnt--;
        memmove(&g_fault_id.fault_id[0], &g_fault_id.fault_id[1], (FAULT_MAX - 1) * sizeof(uint8_t)); //将1之后的数据移到0之后，即移除头部
        memmove(&g_fault_id.fault_record_flag[0], &g_fault_id.fault_record_flag[1], (FAULT_MAX - 1) * sizeof(uint8_t)); //将1之后的数据移到0之后，即移除头部
    }

}

void clean_fault_record_flag(uint8_t num)
{
    if(num < FAULT_MAX)
    {
        g_fault_id.fault_record_flag[num] = DISABLE;
        log_d("[record]flagCleanSuc,id:%x\n",num);
    }
    else
    {
        log_d("[record]flagCleanErr\n");
    }
}

// 通过faultID获取故障信息
const fault_para_tab_t *fault_data_info_get(fault_type_e fault_type)
{
    if (fault_type >= FAULT_MAX)
    {
        return NULL;
    }
    // 加快检索
    if (fault_type < ITEM_NUM(g_fault_para_tab))
    {
        if (g_fault_para_tab[fault_type].fault_type == fault_type)
        {
            return &g_fault_para_tab[fault_type];
        }
    }
    uint16_t index = 0;
    for (index = 0; index < ITEM_NUM(g_fault_para_tab); index++)
    {
        if (g_fault_para_tab[index].fault_type == fault_type)
        {
            return &g_fault_para_tab[index];
        }
    }
    return NULL;
}

/**
 * @brief       滑窗判断保护次数是否锁死
 * @param       [in]record_tick_buff  触发故障之后记录的tick时间数组
 * @param       [in]lock_times        数组长度/连续锁死次数
 * @param       [in]pro_times         一共保护次数
 * @param       [in]over_time_b1ms     滑窗时间ms单位
 * @retrun       true: 连续保护锁死故障，false: 无连续保护锁死
 */
bool continuous_pro_lock_judge_deal(uint32_t *record_tick_buff, const uint16_t lock_times, uint16_t *pro_times, const uint32_t over_time_b1ms)
{
    if (NULL == record_tick_buff || 0 == over_time_b1ms || 0 == lock_times || NULL == pro_times)
    {
        return false;
    }
    if ((*pro_times) >= lock_times)
    {
        uint16_t newest_index = ((*pro_times) - 1) % lock_times;
        uint16_t oldest_index = ((*pro_times) - lock_times) % lock_times;
        uint32_t need_interval = 0;
        if (record_tick_buff[newest_index] >= record_tick_buff[oldest_index])
        {
            need_interval = record_tick_buff[newest_index] - record_tick_buff[oldest_index];
        }
        else
        {
            need_interval = 0xFFFFFFFF - record_tick_buff[oldest_index] + record_tick_buff[newest_index];
        }
        if (need_interval <= over_time_b1ms)
        {
            return true;
        }
    }
    // 如果最新一次保护的时间与当前时间超过over_time，清楚保护次数
    if ((*pro_times) > 0)
    {
        uint16_t newest_index = ((*pro_times) - 1) % lock_times;
        uint32_t curr_tick = sdk_tick_get();
        uint32_t curr_interval = 0;
        if (curr_tick >= record_tick_buff[newest_index])
        {
            curr_interval = curr_tick - record_tick_buff[newest_index];
        }
        else
        {
            curr_interval = 0xFFFFFFFF - record_tick_buff[newest_index] + curr_tick;
        }
        if (curr_interval > over_time_b1ms)
        {
            *pro_times = 0;
        }
    }
    return false;
}

/**
 * @brief		通信计数清空
 * @param		void
 * @param		void
 * @return		void
 */
static uint32_t g_bmu2bcu_com_tick = 0;
static uint8_t g_inner_com_error_flag = false;
/**
 * @brief		通信异常计数清空
 * @param		void
 * @param		void
 * @return		void
 */
void fault_bcu_inter_com_count_clear(void)
{
    g_time2scnt = 0;
}

static void fault_bcu_com_check_init(void)
{
    g_bmu2bcu_com_tick = sdk_tick_get();
}

/**
 * @brief		通信异常检测
 * @param		void
 * @param		void
 * @return		void
 */
static void check_inter_com_error(void)
{
    // 升级过程计数清除 或者 没有编址完成，不报错误
    if (ADDRESSING_FINISH != auto_addressing_get_state() || BCU_STATE_UPGRADE == bms_state_get_sys_sta())
    {
        g_bmu2bcu_com_tick = sdk_tick_get();
        return;
    }
    // 故障消除判断
    if (g_inner_com_error_flag)
    {
        if (true == sdk_is_tick_over(g_bmu2bcu_com_tick, TICK_1S))
        {
            if (g_time2scnt < Comm_Cnt)
            {
                g_inner_com_error_flag = false;
            }
            g_bmu2bcu_com_tick = sdk_tick_get();
        }
    }
    else  // 通讯故障置位判断
    {
        if (true == sdk_is_tick_over(g_bmu2bcu_com_tick, TICK_2S))
        {
            g_bmu2bcu_com_tick = sdk_tick_get();
            if(g_time2scnt++ >= Comm_Cnt)
            {
                g_time2scnt = Comm_Cnt;
                g_inner_com_error_flag = true;
            }
        }
    }
}

/**
 * @brief		故障管理初始化
 * @param		void
 * @param		void
 * @pre			系统启动时执行一次。
 */
void fault_manage_init(void)
{
    g_fault_enable = false;
    memset(g_fault_state, 0, sizeof(g_fault_state));
    g_fault_diag_step = DIAG_NONE;
    memset(&g_fault_lock_data, 0, sizeof(g_fault_lock_data));
    g_fault_stat_data.fault_num = 0;
    g_fault_stat_data.max_charge_level = LEVEL3;
    g_fault_stat_data.max_discharge_level = LEVEL3;
    g_fault_stat_data.fault_level = 0;
    gp_fault_para = &(get_bms_attr()->safety); // 获取故障安全参数
}

/**
 * @brief		故障诊断功能使能
 * @param		void
 * @param		void
 * @pre			系统启动时执行一次。
 */
void fault_diag_enable(void)
{
    if (true != g_fault_enable)
    {
        g_fault_enable = true;
        FAULT_MANAGE_LOGE("[ALM]faultModeEnable\n");
    }
}

/**
 * @brief		故障运行步骤获取
 */
fault_diag_step_e fault_diag_step_get(void)
{
    return (fault_diag_step_e)g_fault_diag_step;
}

/**
 * @brief		故障设置
 * @param		[in] fault_type 故障类型
 * @param		[in] cmd 设置命令
 * -# 0x00 - FAULT_STOP
 * -# 0x01 - FAULT_START
 * @retval		0 成功
 * @retval		-1 失败
 * @pre			执行hal_adc_start后执行才有效。
 */
static int32_t fault_state_set(fault_type_e fault_type, uint8_t cmd)
{
    if ((FAULT_MAX < fault_type) || ((FAULT_START != cmd) && (FAULT_STOP != cmd)))
    {
        FAULT_MANAGE_LOGE("[%s]inputParaErr\n", __FUNCTION__);
        return -1;
    }

    uint32_t fault_group_id = fault_type / FAULT_GROUP_SIZE;
    uint32_t fault_offset = fault_type % FAULT_GROUP_SIZE;

    if (FAULT_START == cmd)
    {
        const fault_para_tab_t* p_fault_index = fault_data_info_get(fault_type);
        if ((NULL != p_fault_index)&&(ENABLE == p_fault_index->fault_decore_enable))
        {
            g_fault_id.fault_record_flag[g_fault_id.fault_cnt] = ENABLE;
            g_fault_id.fault_id[g_fault_id.fault_cnt] = p_fault_index->fault_type;
            g_fault_id.fault_cnt++;   
        }
        SET_BIT(g_fault_state[fault_group_id], (1ULL << fault_offset));
    }
    else
    {
        CLR_BIT(g_fault_state[fault_group_id], (1ULL << fault_offset));
    }

    return 0;
}

/**
 * @brief		故障状态
 * @param		[in] fault_type 故障类型
 * @param		[in] cmd 设置命令
 * @retval		1 有故障
 * @retval		0 无故障
 * @retval		-1 查询失败
 * @pre			执行hal_adc_start后执行才有效。
 */
int32_t fault_state_get(fault_type_e fault_type)
{
    if (FAULT_MAX < fault_type)
    {
        FAULT_MANAGE_LOGE("[%s]inputParaErr\n", __FUNCTION__);
        return -1;
    }

    uint32_t fault_group_id = fault_type / FAULT_GROUP_SIZE;
    uint32_t fault_offset = fault_type % FAULT_GROUP_SIZE;

    if (0 == GET_BIT(g_fault_state[fault_group_id], (1ULL << fault_offset)))
    {
        return FAULT_STOP;
    }
    else
    {
        return FAULT_START;
    }
}

/**
 * @brief		获单个故障信息
 * @param		[in] fault_type 需要查询的故障类型
 * @param		[out] *p_dout 存放获取的故障数据指针,为空无法获取数据
 * @return		执行结果
 * @retval		0  获取成功
 * @retval		-1 获取失败
 */
int32_t fault_data_get(fault_type_e fault_type, fault_data_t *p_dout)
{
    if ((FAULT_MAX < fault_type) || (!p_dout))
    {
        FAULT_MANAGE_LOGE("[%s]inputParaErr\n", __FUNCTION__);
        return -1;
    }

    const fault_para_tab_t* fault_info = fault_data_info_get(fault_type);
    if (NULL == fault_info)
    {
        return -1;
    }

    p_dout->fault_type = fault_info->fault_type;
    p_dout->fault_status = fault_state_get(fault_info->fault_type);
    p_dout->fault_code = 0;
    p_dout->charge_level = fault_info->charge_level;
    p_dout->discharge_level = fault_info->discharge_level;
    return 0;
}

/**
 * @brief		获取故障统计数据
 * @param		[out] *p_dout 存放获取的故障统计数据指针，为空无法获取数据
 * @return		执行结果
 * @retval		>=0 故障数量
 * @retval		-1  获取失败
 */
#define FAULT_MIN_LEVEL(a, b)  (((a) > (b)) ? (b) : (a))
int32_t fault_stat_data_get(fault_stat_data_t *p_dout)
{
    if (NULL == p_dout)
    {
        FAULT_MANAGE_LOGE("[%s]inputParaErr\n", __FUNCTION__);
        return -1;
    }
    uint16_t fault_num = 0;          // fault number
    uint16_t max_chg_level = LEVEL3; // default level 3 (the lowest)
    uint16_t max_dsg_level = LEVEL3; // default level 3 (the lowest)
    uint8_t  fault_level = 0;

    for (uint16_t index = 0; index < ITEM_NUM(g_fault_para_tab); index++)
    {
        if (FAULT_START ==  fault_state_get(g_fault_para_tab[index].fault_type))
        {
            max_chg_level = FAULT_MIN_LEVEL(g_fault_para_tab[index].charge_level, max_chg_level);
            max_dsg_level = FAULT_MIN_LEVEL(g_fault_para_tab[index].discharge_level, max_dsg_level);
            
            if (g_fault_para_tab[index].charge_level < g_fault_para_tab[index].discharge_level)
            {
                fault_level |=  (0x01 << g_fault_para_tab[index].charge_level);                
            }
            else
            {
                fault_level |=  (0x01 << g_fault_para_tab[index].discharge_level);   
            }

            fault_num++;
        }
    }
    p_dout->fault_num = fault_num;
    p_dout->max_charge_level = max_chg_level;
    p_dout->max_discharge_level = max_dsg_level;
    p_dout->fault_level = fault_level;
    return (int32_t)fault_num;
}

/**
 * @brief		获取充放电故障等级
 * @return		执行结果
 * @retval		>=0 故障数量
 * @retval		-1  获取失败
 */
const fault_stat_data_t* fault_chg_dsg_level_get(void)
{
     return (const fault_stat_data_t*)&g_fault_stat_data;
}

// 打印故障标识
void fault_name_print_deal(fault_type_e fault_id, bool is_appear)
{
    FAULT_MANAGE_LOGE("[ALM]%#x %d\n", fault_id, (is_appear) ? 1 : 0);
}

// 打印触发参数
void fault_appear_value_print_deal(int32_t birth_data)
{
    FAULT_MANAGE_LOGE("bth%d\n", birth_data);
}

// 打印消除参数
void fault_cancel_value_print_deal(int32_t cancel_data)
{
    FAULT_MANAGE_LOGE("clr%d\n", cancel_data);
}

// 故障告警回调函数--start


/**
 * @brief   功率端子温度采集异常检测
 */
static bool fault_power_terminal_temp_sam_abnormal_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    
    for (uint8_t i = 0; i <= BAT_N_NTC_ERR; i++)
    {
        if ((NTC_OPEN_CIRCUIT_ERR == sample_abnormal_get((abnormal_type_e)i))
            || (NTC_SHORT_CIRCUIT_ERR == sample_abnormal_get((abnormal_type_e)i)))
        {
            result = true;  
            break;
        }
    }
    if (ALARM_APPEAR == is_appear)
    {
        return result;
    }
    else
    {
        return false; // 不恢复
    }
}

/**
 * @brief	功率端子温度采样异常打印函数
 */
static void fault_power_terminal_temp_sam_abnormal_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (!is_appear)
    {
        return;
    }
    for (uint8_t i = 0; i <= BAT_N_NTC_ERR; i++)
    {
        if ((NTC_OPEN_CIRCUIT_ERR == sample_abnormal_get((abnormal_type_e)i))
            || (NTC_SHORT_CIRCUIT_ERR == sample_abnormal_get((abnormal_type_e)i)))
        {
            FAULT_MANAGE_LOGE("PWR NTC%d Err\n", i);
        }
    }
}

/**
 * @brief   环境温度采集异常检测
 */
static bool alarm_env_temp_sam_abnormal_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    

    if ((NTC_OPEN_CIRCUIT_ERR == sample_abnormal_get((abnormal_type_e)PCB_NTC_ERR))
        || (NTC_SHORT_CIRCUIT_ERR == sample_abnormal_get((abnormal_type_e)PCB_NTC_ERR)))
    {
        result = true;  
    }
    
    if (ALARM_APPEAR == is_appear)
    {
        return result;
    }
    else
    {
        return false; // 不恢复
    }
}

/**
 * @brief	环境温度采样异常打印函数
 */
static void alarm_env_temp_sam_abnormal_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (!is_appear)
    {
        return;
    }
    if ((NTC_OPEN_CIRCUIT_ERR == sample_abnormal_get((abnormal_type_e)PCB_NTC_ERR))
        || (NTC_SHORT_CIRCUIT_ERR == sample_abnormal_get((abnormal_type_e)PCB_NTC_ERR)))
    {
        FAULT_MANAGE_LOGE("ENV NTC Err\n");
    }

}

/**
 * @brief		flash存储失效检测
 */
static bool fault_flash_invalid_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    /* 存储故障连续100ms */
    result = (bool)(-1 != data_store_toatal_fault_get());
    if (ALARM_APPEAR == is_appear)
    {
        return result;
    }
    else
    {
        return false; // 不恢复
    }
}

/**
 * @brief    BCU与BMU之间can失效通讯失败检测
 */
static bool fault_inner_can_comm_invalid_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    
    // 自动编址故障号：0 没故障，1 ID冲突，2 通讯故障，3 编址异常，4 编址电平异常
    uint8_t auto_addr_fault_no = auto_addressing_fault_get();

    if ((auto_addr_fault_no > 0) || (true == g_inner_com_error_flag))
    {
        result = true;
    }
    else
    {
        result = false;
    }

    if (ALARM_APPEAR == is_appear)
    {
        return result;
    }
    else
    {
        return !result;
    }
}

/**
 * @brief		BCU与BMU之间can失效通讯失败打印函数
 */
static void fault_inner_can_comm_invalid_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (is_appear)
    {
        FAULT_MANAGE_LOGE("addErr=%d,comErr=%d\n", auto_addressing_fault_get(), g_inner_com_error_flag);
    }
}

/**
 * @brief    BCU与PCS之间can失效通讯失败检测
 */
static bool fault_bcu_pcs_can_comm_invalid_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    if (is_appear == ALARM_APPEAR)
    {
        if (++g_bcu_pcs_comm_err_cnt > 1000)
        {
            g_bcu_pcs_comm_err_cnt = 1000;
            fault_state_set(BOARD_BCU_PCS_CAN_COMM_ABNORMAL_FAULT, FAULT_START);
            fault_name_print_deal(fault_id, is_appear);
        }
    }
    else
    {
        if (!g_bcu_pcs_comm_err_cnt)
        {
            result = true;
        }
    }

    return result;
}

/**
 * @brief    BCU与BCU之间canId冲突检测
 */
static bool alarm_bcu_bcu_can_id_conflict_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    
    /* can通信失效 */
    result = (bool)get_bcu_info()->confilct_id_flag;
    if (ALARM_APPEAR == is_appear)
    {
        return result;
    }
    else
    {
        return !result;
    }
}

/**
 * @brief    功率端子过温提示检测
 */
static bool tip_power_terminal_temp_over_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    
    if (ALARM_APPEAR == is_appear)
    {
        /* 提示：B+-或P+-功率端子温度>90℃，持续3s */
        if ((g_sample_data.adc_sample_other_temp[BAT_P_TEMP] > gp_fault_para->power_terminal_temp_over_tip.appear_value) ||
            (g_sample_data.adc_sample_other_temp[BAT_N_TEMP] > gp_fault_para->power_terminal_temp_over_tip.appear_value) ||
            (g_sample_data.adc_sample_other_temp[LOAD_P_TEMP] > gp_fault_para->power_terminal_temp_over_tip.appear_value) ||
            (g_sample_data.adc_sample_other_temp[LOAD_N_TEMP] > gp_fault_para->power_terminal_temp_over_tip.appear_value))
        {
            result = true;
        }
    }
    else
    {
        /* 提示解除：B+-且P+-功率端子温度<85℃，持续3s */
        if ((g_sample_data.adc_sample_other_temp[BAT_P_TEMP] < gp_fault_para->power_terminal_temp_over_tip.cancel_value) &&
            (g_sample_data.adc_sample_other_temp[BAT_N_TEMP] < gp_fault_para->power_terminal_temp_over_tip.cancel_value) &&
            (g_sample_data.adc_sample_other_temp[LOAD_P_TEMP] < gp_fault_para->power_terminal_temp_over_tip.cancel_value) &&
            (g_sample_data.adc_sample_other_temp[LOAD_N_TEMP] < gp_fault_para->power_terminal_temp_over_tip.cancel_value))
        {
            result = true; 
        }
    }
    return result;
}

/**
 * @brief		功率端子过温提示打印函数
 */
static void tip_power_terminal_temp_over_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    FAULT_MANAGE_LOGE("BusPtmp=%d,N=%d\n", g_sample_data.adc_sample_other_temp[BAT_P_TEMP], g_sample_data.adc_sample_other_temp[BAT_N_TEMP]);
    FAULT_MANAGE_LOGE("LoadNtmp=%d,P=%d\n", g_sample_data.adc_sample_other_temp[LOAD_N_TEMP], g_sample_data.adc_sample_other_temp[LOAD_P_TEMP]);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->power_terminal_temp_over_tip.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->power_terminal_temp_over_tip.cancel_value);
    }
}

/**
 * @brief    功率端子过温告警检测
 */
static bool alarm_power_terminal_temp_over_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    
    if (ALARM_APPEAR == is_appear)
    {
        /* 提示：B+-或P+-功率端子温度>90℃，持续3s */
        if ((g_sample_data.adc_sample_other_temp[BAT_P_TEMP] > gp_fault_para->power_terminal_temp_over_alarm.appear_value) ||
            (g_sample_data.adc_sample_other_temp[BAT_N_TEMP] > gp_fault_para->power_terminal_temp_over_alarm.appear_value) ||
            (g_sample_data.adc_sample_other_temp[LOAD_P_TEMP] > gp_fault_para->power_terminal_temp_over_alarm.appear_value) ||
            (g_sample_data.adc_sample_other_temp[LOAD_N_TEMP] > gp_fault_para->power_terminal_temp_over_alarm.appear_value))
        {
            result = true;
        }
    }
    else
    {
        /* 提示解除：B+-且P+-功率端子温度<85℃，持续3s */
        if ((g_sample_data.adc_sample_other_temp[BAT_P_TEMP] < gp_fault_para->power_terminal_temp_over_alarm.cancel_value) &&
            (g_sample_data.adc_sample_other_temp[BAT_N_TEMP] < gp_fault_para->power_terminal_temp_over_alarm.cancel_value) &&
            (g_sample_data.adc_sample_other_temp[LOAD_P_TEMP] < gp_fault_para->power_terminal_temp_over_alarm.cancel_value) &&
            (g_sample_data.adc_sample_other_temp[LOAD_N_TEMP] < gp_fault_para->power_terminal_temp_over_alarm.cancel_value))
        {
            result = true; 
        }
    }
    return result;
}

/**
 * @brief		功率端子过温告警打印函数
 */
static void alarm_power_terminal_temp_over_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    FAULT_MANAGE_LOGE("BusPtmp=%d,N=%d\n", g_sample_data.adc_sample_other_temp[BAT_P_TEMP], g_sample_data.adc_sample_other_temp[BAT_N_TEMP]);
    FAULT_MANAGE_LOGE("LoadNtmp=%d,P=%d\n", g_sample_data.adc_sample_other_temp[LOAD_N_TEMP], g_sample_data.adc_sample_other_temp[LOAD_P_TEMP]);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->power_terminal_temp_over_alarm.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->power_terminal_temp_over_alarm.cancel_value);
    }
}

/**
 * @brief    功率端子过温保护检测
 */
static bool pro_power_terminal_temp_over_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    
    if (ALARM_APPEAR == is_appear)
    {
        /* 提示：B+-或P+-功率端子温度>90℃，持续3s */
        if ((g_sample_data.adc_sample_other_temp[BAT_P_TEMP] > gp_fault_para->power_terminal_temp_over_protect.appear_value) ||
            (g_sample_data.adc_sample_other_temp[BAT_N_TEMP] > gp_fault_para->power_terminal_temp_over_protect.appear_value) ||
            (g_sample_data.adc_sample_other_temp[LOAD_P_TEMP] > gp_fault_para->power_terminal_temp_over_protect.appear_value) ||
            (g_sample_data.adc_sample_other_temp[LOAD_N_TEMP] > gp_fault_para->power_terminal_temp_over_protect.appear_value))
        {
            result = true;
        }
    }
    else
    {
        /* 提示解除：B+-且P+-功率端子温度<85℃，持续3s */
        if ((g_sample_data.adc_sample_other_temp[BAT_P_TEMP] < gp_fault_para->power_terminal_temp_over_protect.cancel_value) &&
            (g_sample_data.adc_sample_other_temp[BAT_N_TEMP] < gp_fault_para->power_terminal_temp_over_protect.cancel_value) &&
            (g_sample_data.adc_sample_other_temp[LOAD_P_TEMP] < gp_fault_para->power_terminal_temp_over_protect.cancel_value) &&
            (g_sample_data.adc_sample_other_temp[LOAD_N_TEMP] < gp_fault_para->power_terminal_temp_over_protect.cancel_value))
        {
            result = true; 
        }
    }
    return result;
}

/**
 * @brief	功率端子过温保护打印函数
 */
static void pro_power_terminal_temp_over_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    FAULT_MANAGE_LOGE("BusPtmp=%d,N=%d\n", g_sample_data.adc_sample_other_temp[BAT_P_TEMP], g_sample_data.adc_sample_other_temp[BAT_N_TEMP]);
    FAULT_MANAGE_LOGE("LoadNtmp=%d,P=%d\n", g_sample_data.adc_sample_other_temp[LOAD_N_TEMP], g_sample_data.adc_sample_other_temp[LOAD_P_TEMP]);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->power_terminal_temp_over_protect.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->power_terminal_temp_over_protect.cancel_value);
    }
}

/**
 * @brief    正继电器粘连检测
 */
static bool fault_positive_relay_adhesion_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    
    if (ALARM_APPEAR == is_appear)
    {
        /* 正继电器断开和闭合，连续三次都无法正常断开或闭合 */
        if (get_relay_abnormal_flag(POS_RELAY)
            || ((false == get_relay_contrl_last_state(POS_RELAY)) && (true == di_state_get(DI_4_POS_RELAY))  )
                )
        {
            result = true;
        }
    }
    else
    {
        result = false; // 不恢复
    }
    return result;
}

/**
 * @brief	正继电器粘连检测打印函数
 */
static void fault_positive_relay_adhesion_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    FAULT_MANAGE_LOGE("pos abnormal flag:%d,state:%d,di:%d\r\n", get_relay_abnormal_flag(POS_RELAY),get_relay_contrl_last_state(POS_RELAY),di_state_get(DI_4_POS_RELAY)); 

}
    
/**
 * @brief    负继电器粘连检测
 */
static bool fault_negative_relay_adhesion_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    
    if (ALARM_APPEAR == is_appear)
    {
        /* 负继电器断开和闭合，连续三次都无法正常断开或闭合 */
        if (get_relay_abnormal_flag(NEG_RELAY)
            || ((false == get_relay_contrl_last_state(NEG_RELAY)) && (true == di_state_get(DI_6_NEG_RELAY)))
            )
        {
            result = true;
        }
    }
    else
    {
        result = false; // 不恢复
    }
    return result;
}

/**
 * @brief	主负电器粘连检测打印函数
 */
static void fault_negative_relay_adhesion_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    FAULT_MANAGE_LOGE("neg abnormal flag:%d,state:%d,di:%d\r\n", get_relay_abnormal_flag(NEG_RELAY),get_relay_contrl_last_state(NEG_RELAY),bcu_dido_info_get()->di_state.bit.di3); 

}

/**
 * @brief    辅电继电器粘连检测
 */
static bool fault_auxiliary_relay_adhesion_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    
//    if (ALARM_APPEAR == is_appear)
//    {
//        /* 辅电继电器无法正常断开或闭合 */
//        if (!di_state_get(DI_5_AUXILIARY_POWER_SWITCH))
//        {
//            result = true;
//        }
//    }
//    else
//    {
//        result = false; // 不恢复
//    }
    return result;
}

/**
 * @brief 绝缘阻抗过低提示检测
 */
static bool tip_ins_val_low_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    if (gp_fault_para == NULL)
    {
        return false;
    }
    
    
    if (ALARM_APPEAR == is_appear)
    {
        if (insulation_impedance_value_get() < gp_fault_para->ins_val_under_tip.appear_value)
        {
            result = true;
        }
    }
    else
    {
        if (insulation_impedance_value_get() > gp_fault_para->ins_val_under_tip.cancel_value)
        {
            result = true;
        }
    }
    return result;
}

/**
 * @brief 绝缘阻抗过低提示打印
 */
static void tip_ins_val_low_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    FAULT_MANAGE_LOGE("insRes=%ukΩ\n", insulation_impedance_value_get());

    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->ins_val_under_tip.appear_value);
    }
    else
    {
        fault_appear_value_print_deal(gp_fault_para->ins_val_under_tip.cancel_value);
    }
    
}

/**
 * @brief 绝缘阻抗过低告警检测
 */
static bool alarm_ins_val_low_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    if (gp_fault_para == NULL)
    {
        return false;
    }
    
    
    if (ALARM_APPEAR == is_appear)
    {
        if (insulation_impedance_value_get() < gp_fault_para->ins_val_under_tip.appear_value)
        {
            result = true;
        }
    }
    else
    {
        if (insulation_impedance_value_get() > gp_fault_para->ins_val_under_tip.cancel_value)
        {
            result = true;
        }
    }
    return result;
}

/**
 * @brief 绝缘阻抗过低告警打印
 */
static void alarm_ins_val_low_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    FAULT_MANAGE_LOGE("insRes=%ukΩ\n", insulation_impedance_value_get());

    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->ins_val_under_alarm.appear_value);
    }
    else
    {
        fault_appear_value_print_deal(gp_fault_para->ins_val_under_alarm.cancel_value);
    }
    
}

/**
 * @brief 绝缘阻抗过低保护检测
 */
static bool pro_ins_val_low_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    if (gp_fault_para == NULL)
    {
        return false;
    }
    
    
    if (ALARM_APPEAR == is_appear)
    {
        if ((insulation_impedance_value_get() < gp_fault_para->ins_val_under_protect.appear_value) ||
            (insulation_impedance_check_result_get() == INSULATION_IMPEDANCE_ABNORMAL) ||
            (insulation_impedance_check_result_get() == INSULATION_IMPEDANCE_OVERTIME))
        {
            result = true;
        }
    }
    else
    {
        if ((insulation_impedance_value_get() != SIR_INVALID) &&
            (insulation_impedance_value_get() > gp_fault_para->ins_val_under_protect.cancel_value))
        {
            result = true;
        }
    }
    return result;
}

/**
 * @brief 绝缘阻抗过低保护打印
 */
static void pro_ins_val_low_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    FAULT_MANAGE_LOGE("insRes=%ukΩ，state=%d\n", insulation_impedance_value_get(),insulation_impedance_check_result_get());

    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->ins_val_under_protect.appear_value);
    }
    else
    {
        fault_appear_value_print_deal(gp_fault_para->ins_val_under_protect.cancel_value);
    }
    
}

/**
 * @brief    内can反复编址异常故障
 */
static bool fault_inner_can_addr_repeat_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    static auto_addressing_state_e last_addr_state = ADDRESSING_FINISH;
    static uint32_t fault_start_tick = 0; /* 故障启动tick */
    auto_addressing_state_e cur_addr_state  = auto_addressing_get_state();

    if (last_addr_state == ADDRESSING_FINISH && cur_addr_state != ADDRESSING_FINISH)
    {
        // 距离上一次故障消失不超过5min，判断为连续故障，否则清空连续计数
        if ((true == sdk_is_tick_over(fault_start_tick, 300000)) && (FAULT_STOP == fault_state_get(fault_id)))
        {
            g_fault_lock_data.inner_can_addr_fault_times = 1;
        }
        else
        {
            g_fault_lock_data.inner_can_addr_fault_times++;
        }
    }
    else if (last_addr_state != ADDRESSING_FINISH && cur_addr_state == ADDRESSING_FINISH)
    {
        fault_start_tick = sdk_tick_get();
    }
    last_addr_state = cur_addr_state;

    if (ALARM_APPEAR == is_appear)
    {
        if (INNER_CAN_ADDR_OVER_LOCK_TIMES <= g_fault_lock_data.inner_can_addr_fault_times)
        {
            result = true;
        }
    }
    else
    {
        result = false; // 不恢复
    }
    return result;
}

/**
 * @brief    预充失败故障
 */
static bool fault_pre_charge_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    
    result = (bool)(PRE_FAIL == get_pre_charge_state());
    if (ALARM_APPEAR == is_appear)
    {
        return result;
    }
    else
    {
        return false;  // 不恢复
    }
}

/**
 * @brief    片外adc采样异常
 */
static bool fault_ext_adc_abnormal_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    if (ALARM_APPEAR == is_appear)
    {
        if (di_state_get(DI_1_ADS_ALARM) == true)
        {
            result = true;
        }
    }
    else
    {
        result = false;  // 不恢复
    }

    return result;
}

/**
 * @brief    环境温度过高提示检测
 */
static bool tip_env_temp_high_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    if (gp_fault_para == NULL)
    {
        return false;
    }
    
    if (ALARM_APPEAR == is_appear)
    {
        /* 提示：PCB板温温度>65℃，持续1s */
        if (g_sample_data.adc_sample_other_temp[PCB_TEMP] > gp_fault_para->mod_temp_over_tip.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 提示：PCB板温温度<60℃，持续1s */
        if (g_sample_data.adc_sample_other_temp[PCB_TEMP] < gp_fault_para->mod_temp_over_tip.cancel_value)
        {
            result = true; 
        }
    }

    return result;
}

/**
 * @brief		环境温度过高提示打印函数
 */
static void tip_env_temp_high_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);

    FAULT_MANAGE_LOGE("PCBtmp=%d\n", g_sample_data.adc_sample_other_temp[PCB_TEMP]);
    
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->mod_temp_over_tip.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->mod_temp_over_tip.cancel_value);
    }
}

/**
 * @brief    环境温度过高告警检测
 */
static bool alarm_env_temp_high_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    if (gp_fault_para == NULL)
    {
        return false;
    }
    
    if (ALARM_APPEAR == is_appear)
    {
        /* 告警：PCB板温温度>85℃，持续1s */
        if (g_sample_data.adc_sample_other_temp[PCB_TEMP] > gp_fault_para->mod_temp_over_alarm.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 告警：PCB板温温度<80℃，持续1s */
        if (g_sample_data.adc_sample_other_temp[PCB_TEMP] < gp_fault_para->mod_temp_over_alarm.cancel_value)
        {
            result = true; 
        }
    }

    return result;
}

/**
 * @brief		环境温度过高告警打印函数
 */
static void alarm_env_temp_high_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);

    FAULT_MANAGE_LOGE("PCBtmp=%d\n", g_sample_data.adc_sample_other_temp[PCB_TEMP]);
    
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->mod_temp_over_alarm.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->mod_temp_over_alarm.cancel_value);
    }
}

/**
 * @brief    环境温度过高保护检测
 */
static bool pro_env_temp_high_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    if (gp_fault_para == NULL)
    {
        return false;
    }
    
    if (ALARM_APPEAR == is_appear)
    {
        /* 保护：PCB板温温度>100℃，持续1s */
        if (g_sample_data.adc_sample_other_temp[PCB_TEMP] > gp_fault_para->mod_temp_over_protect.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 保护：PCB板温温度<95℃，持续1s */
        if (g_sample_data.adc_sample_other_temp[PCB_TEMP] < gp_fault_para->mod_temp_over_protect.cancel_value)
        {
            result = true; 
        }
    }

    return result;
}

/**
 * @brief	环境温度过高保护打印函数
 */
static void pro_env_temp_high_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);

    FAULT_MANAGE_LOGE("PCBtmp=%d\n", g_sample_data.adc_sample_other_temp[PCB_TEMP]);
    
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->mod_temp_over_protect.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->mod_temp_over_protect.cancel_value);
    }
}

/**
 * @brief 供电电压过压告警检测
 */
static bool tip_power_volt_over_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    if (gp_fault_para == NULL)
    {
        return false;
    }

    if (is_appear)
    {
        if ( g_sample_data.power_24v_volt > gp_fault_para->power_volt_over_alarm.appear_value * 100 )
        {
            result = true;
        }
    }
    else
    {
        if ( g_sample_data.power_24v_volt < gp_fault_para->power_volt_over_alarm.cancel_value * 100 )
        {
            result = true;
        }
    }

    return result;
}

/**
 * @brief 供电电压过压告警打印
 */
static void tip_power_volt_over_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);

    if (gp_fault_para == NULL)
    {
        return;
    }

    FAULT_MANAGE_LOGE("PowerV=%d\n", g_sample_data.power_24v_volt);

    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->power_volt_over_alarm.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->power_volt_over_alarm.cancel_value);
    }
    
}

/**
 * @brief 供电电压欠压告警检测
 */
static bool tip_power_volt_under_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    if (gp_fault_para == NULL)
    {
        return false;
    }

    if (is_appear)
    {
        if ( g_sample_data.power_24v_volt < gp_fault_para->power_volt_under_alarm.appear_value * 100 )
        {
            result = true;
        }
    }
    else
    {
        if ( g_sample_data.power_24v_volt > gp_fault_para->power_volt_under_alarm.cancel_value * 100 )
        {
            result = true;
        }
    }

    return result;
}

/**
 * @brief 供电电压欠压告警打印
 */
static void tip_power_volt_under_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);

    if (gp_fault_para == NULL)
    {
        return;
    }

    FAULT_MANAGE_LOGE("PowerV=%d\n", g_sample_data.power_24v_volt);

    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->power_volt_under_alarm.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->power_volt_under_alarm.cancel_value);
    }
}

/**
 * @brief   跳机故障检测
 */
static bool fault_trip_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    result = (bool)(LEVEL0 == g_fault_stat_data.max_charge_level || LEVEL0 == g_fault_stat_data.max_discharge_level || 
                    LEVEL1 == g_fault_stat_data.max_charge_level || LEVEL1 == g_fault_stat_data.max_discharge_level);

    if (is_appear == ALARM_APPEAR)
    {
        return result;
    }
    else
    {
        return !result;
    }
}

/**
 * @brief   CAN霍尔传感器故障检测
 */
static bool fault_can_hall_sensor_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    bool error_sta = (bool)(get_other_device_info()->error_information);

    if (error_sta)
    {
        result = true;
    }
    else
    {
        result = false;
    }

    if (ALARM_APPEAR == is_appear)
    {
        return result;
    }
    else
    {
        return !result;
    }
}

/**
 * @brief   CAN霍尔传感器通讯故障
 */
static bool fault_can_hall_sensor_comm_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    if (is_appear == ALARM_APPEAR)
    {
        if (++g_can_hall_sensor_comm_err_cnt > 1000)
        {
            g_can_hall_sensor_comm_err_cnt = 1000;
            fault_state_set(BOARD_CAN_HALL_SENSOR_COMM_FAULT, FAULT_START);
            fault_name_print_deal(fault_id, is_appear);
        }
    }
    else
    {
        if (!g_can_hall_sensor_comm_err_cnt)
        {
            result = true;
        }
    }

    return result;
}

/**
 * @brief   硬件自检异常检测
 */
static bool fault_hard_self_det_check(fault_type_e fault_id, bool is_appear)
{
    uint8_t result = false;

    if (DIAG_ON_RUNNING == g_fault_diag_step)
    {
        return false;
    }

    if (gp_fault_para == NULL)
    {
        return false;
    }

    if ((g_sample_data.power_24v_volt > gp_fault_para->power_volt_over_alarm.appear_value * 100) || 
        (g_sample_data.power_24v_volt < gp_fault_para->power_volt_under_alarm.appear_value * 100))
    {
        SET_BIT(g_hard_self_det_abn_flag, POWER_24V_ABN);
    }
    else if ((g_sample_data.power_24v_volt < gp_fault_para->power_volt_over_alarm.cancel_value * 100) && 
             (g_sample_data.power_24v_volt > gp_fault_para->power_volt_under_alarm.cancel_value * 100))
    {
        CLR_BIT(g_hard_self_det_abn_flag, POWER_24V_ABN);
    }

    if (g_sample_data.hall_5v_volt < 4750 || g_sample_data.hall_5v_volt > 5250)
    {
        SET_BIT(g_hard_self_det_abn_flag, HALL_5V_ABN);
    }
    else
    {
        CLR_BIT(g_hard_self_det_abn_flag, HALL_5V_ABN);
    }

    if (get_relay_abnormal_flag(POS_RELAY) || get_relay_abnormal_flag(NEG_RELAY))
    {
        SET_BIT(g_hard_self_det_abn_flag, RELAY_ABN);
    }
    else
    {
        CLR_BIT(g_hard_self_det_abn_flag, RELAY_ABN);
    }

    if (g_hard_self_det_abn_flag)
    {
        result = true;
    }
    else
    {
        result = false;
    }

    if (is_appear)
    {
        return result;
    }
    else
    {
        return !result;
    }
}

/**
 * @brief   硬件自检异常打印
 */
static void fault_hard_self_det_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    
    if (is_appear)
    {
        log_e("hs_abn_flag=%#x\n", g_hard_self_det_abn_flag);
    }
}

/**
 * @brief   正常下电失败检测
 */
static bool fault_power_off_err_check(fault_type_e fault_id, bool is_appear)
{
    static uint16_t fault_time = 0;     // 故障持续时间
    static uint16_t fault_cnt = 0;      // 故障持续次数
    bool result = false;

    if (cmu_power_ctrl_type_get() == 2)     // CLU_POWER_OFF_CMD       2
    {
        if (abs(g_sample_data.sys_current) > 10000)
        {
            fault_time++;
            if (fault_time > 500)
            {
                fault_time = 0;
                fault_cnt++;
            }
        }
        else
        {
            fault_time = 0;
            fault_cnt = 0;
        }
    }

    // 接收到CMU下发的正常下电命令后，|簇电流| > 10A 持续5s，连续3次
    if ((fault_cnt == 3) && (fault_state_get(BOARD_POWER_OFF_FAULT) == FAULT_STOP))
    {
        fault_cnt = 0;
        result = true;
    }
    
    if (ALARM_APPEAR == is_appear)
    {
        return result;
    }
    else
    {
        return false;   // 不恢复
    }
}

static void fault_power_off_err_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    
    if (is_appear)
    {
        log_e("curr=%d\n", g_sample_data.sys_current);
    }    
}

    
/**
 * @brief   所有簇故障下电检测
 */
static bool fault_all_cluster_power_off_err_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    result = (bool)(3 == cmu_power_ctrl_type_get());    // CLU_FAULTPOWER_OFF_CMD  3

    if (ALARM_APPEAR == is_appear)
    {
        return result;
    }
    else
    {
        return false;   // 不恢复
    }
}

/**
 * @brief   霍尔电流差异过大检测
 */
static bool fault_hall_curr_diff_over_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    pack_other_device_info_t g_pack_other_device_info = *get_other_device_info();
    int32_t tmp1 = g_pack_other_device_info.hall_data_deal;
    int32_t tmp2 = g_sample_data.hall_cur;
    int32_t curr_diff = abs(tmp1 - tmp2);

    if (ALARM_APPEAR == is_appear)
    {
        /* 告警：电流差>10A，持续1s */
        if (g_pack_other_device_info.called && (!g_pack_other_device_info.error_information) && (curr_diff > 10000)) // 转换单位为 1mA
        {
            result = true;
        }
    }
    else
    {
        /* 告警：电流差<2A,持续1s */
        if ((!g_pack_other_device_info.called) || (g_pack_other_device_info.error_information) || curr_diff <= 2000)
        {
            result = true; 
        }
    }
    return result;
}

/**
 * @brief		电流差异过大打印函数
 */
static void fault_hall_curr_diff_over_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    pack_other_device_info_t g_pack_other_device_info = *get_other_device_info();
    FAULT_MANAGE_LOGE("can_cur = %d, ad_cur = %d\n", g_pack_other_device_info.hall_data_deal, g_sample_data.hall_cur);
}

/**
 * @brief    电池簇过压提示检测
 */
static bool bat_cluster_volt_over_tip_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    if (NULL == gp_fault_para)
    {
        return result;
    }

    uint32_t bus_volt = g_sample_data.bus_volt;

    if (NULL != gp_bmu_data_unify)
    {
        bus_volt = gp_bmu_data_unify->all_pack_acc_volt * 100; // 转换单位为1mv
    }

    if (ALARM_APPEAR == is_appear)
    {
        /* 提示：电池簇电压>1344V，持续1s */
        if (bus_volt > gp_fault_para->total_over_vol_tip.appear_value * 100) // 转换单位为 1mV
        {
            result = true;
        }
    }
    else
    {
        /* 提示解除：电池簇电压<1334V,持续1s */
        if (bus_volt < gp_fault_para->total_over_vol_tip.cancel_value * 100)
        {
            result = true; 
        }
    }
    return result;
}

/**
 * @brief		电池簇过压提示打印函数
 */
static void bat_cluster_volt_over_tip_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("busV=%dmV,packNum=%d\n", g_sample_data.bus_volt, g_pack_num);
    if (NULL != gp_bmu_data_unify)
    {
        FAULT_MANAGE_LOGE("accV=%dmV\n", gp_bmu_data_unify->all_pack_acc_volt * 100);
    }
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->total_over_vol_tip.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->total_over_vol_tip.cancel_value);
    }
}

/**
 * @brief    电池簇过压告警检测
 */
static bool bat_cluster_volt_over_alarm_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    if (NULL == gp_fault_para)
    {
        return result;
    }

    uint32_t bus_volt = g_sample_data.bus_volt;

    if (NULL != gp_bmu_data_unify)
    {
        bus_volt = gp_bmu_data_unify->all_pack_acc_volt * 100; // 转换单位为1mv
    }

    if (ALARM_APPEAR == is_appear)
    {
        /* 告警：电池簇电压>1363.2V，持续1s */
        if (bus_volt > gp_fault_para->total_over_vol_alarm.appear_value * 100) // 转换单位为 1mV
        {
            result = true;
        }
    }
    else
    {
        /* 告警解除：电池簇电压<1353.2V */
        if (bus_volt < gp_fault_para->total_over_vol_alarm.cancel_value * 100)
        {
            result = true; 
        }
    }
    return result;
}

/**
 * @brief		电池簇过压告警打印函数
 */
static void bat_cluster_volt_over_alarm_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("busV=%dmV,packNum=%d\n", g_sample_data.bus_volt, g_pack_num);
    if (NULL != gp_bmu_data_unify)
    {
        FAULT_MANAGE_LOGE("accV=%dmV\n", gp_bmu_data_unify->all_pack_acc_volt * 100);
    }
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->total_over_vol_alarm.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->total_over_vol_alarm.cancel_value);
    }
}

/**
 * @brief    电池簇过压保护检测
 */
static bool bat_cluster_volt_over_pro_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    if (NULL == gp_fault_para)
    {
        return result;
    }
    uint32_t bus_volt = g_sample_data.bus_volt;

    if (NULL != gp_bmu_data_unify)
    {
        bus_volt = gp_bmu_data_unify->all_pack_acc_volt * 100; // 转换单位为1mv
    }

    if (ALARM_APPEAR == is_appear)
    {
        /* 保护：电池包电压>1401.6V，持续1s */
        if (bus_volt > gp_fault_para->total_over_vol_protect.appear_value * 100) // 转换单位为 1mV
        {
            result = true;
        }
    }
    else
    {
        /* 保护解除：电池簇电压<1391.6V,持续1s */
        if (bus_volt < gp_fault_para->total_over_vol_protect.cancel_value * 100)
        {
            result = true; 
        }
    }
    return result;
}

/**
 * @brief		电池簇过压保护打印函数
 */
static void bat_cluster_volt_over_pro_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("busV=%dmV,packNum=%d\n", g_sample_data.bus_volt, g_pack_num);
    if (NULL != gp_bmu_data_unify)
    {
        FAULT_MANAGE_LOGE("accV=%dmV\n", gp_bmu_data_unify->all_pack_acc_volt * 100);
    }
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->total_over_vol_protect.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->total_over_vol_protect.cancel_value);
    }
}

/**
 * @brief    电池簇欠压提示检测
 */
static bool bat_cluster_under_volt_tip_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    if (NULL == gp_fault_para)
    {
        return result;
    }

    uint32_t bus_volt = g_sample_data.bus_volt;

    if (NULL != gp_bmu_data_unify)
    {
        bus_volt = gp_bmu_data_unify->all_pack_acc_volt * 100; // 转换单位为1mv
    }

    if (ALARM_APPEAR == is_appear)
    {
        /* 提示：电池簇电压<1075.2V，持续1s */
        if (bus_volt < gp_fault_para->total_under_vol_tip.appear_value * 100) // 转换单位为 1mV
        {
            result = true;
        }
    }
    else
    {
        /* 提示解除：电池簇电压>1085.2V,持续1s */
        if (bus_volt > gp_fault_para->total_under_vol_tip.cancel_value * 100)
        {
            result = true; 
        }
    }
    return result;
}

/**
 * @brief		电池簇欠压提示打印函数
 */
static void bat_cluster_under_volt_tip_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("busV=%dmV,packNum=%d\n", g_sample_data.bus_volt, g_pack_num);
    if (NULL != gp_bmu_data_unify)
    {
        FAULT_MANAGE_LOGE("accV=%dmV\n", gp_bmu_data_unify->all_pack_acc_volt * 100);
    }
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->total_under_vol_tip.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->total_under_vol_tip.cancel_value);
    }
}

/**
 * @brief    电池簇欠压告警检测
 */
static bool bat_cluster_under_volt_alarm_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    if (NULL == gp_fault_para)
    {
        return result;
    }

    uint32_t bus_volt = g_sample_data.bus_volt;

    if (NULL != gp_bmu_data_unify)
    {
        bus_volt = gp_bmu_data_unify->all_pack_acc_volt * 100; // 转换单位为1mv
    }

    if (ALARM_APPEAR == is_appear)
    {
        /* 告警：电池簇电压<1036.8V，持续1s */
        if (bus_volt < gp_fault_para->total_under_vol_alarm.appear_value * 100) // 转换单位为 1mV
        {
            result = true;
        }
    }
    else
    {
        /* 告警解除：电池簇电压>1046.8V */
        if (bus_volt > gp_fault_para->total_under_vol_alarm.cancel_value * 100)
        {
            result = true; 
        }
    }
    return result;
}

/**
 * @brief		电池簇欠压告警打印函数
 */
static void bat_cluster_under_volt_alarm_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("busV=%dmV,packNum=%d\n", g_sample_data.bus_volt, g_pack_num);

    if (NULL != gp_bmu_data_unify)
    {
        FAULT_MANAGE_LOGE("accV=%dmV\n", gp_bmu_data_unify->all_pack_acc_volt * 100);
    }
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->total_under_vol_alarm.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->total_under_vol_alarm.cancel_value);
    }
}

/**
 * @brief    电池簇欠压保护检测
 */
static bool bat_cluster_under_volt_pro_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    if (NULL == gp_fault_para)
    {
        return result;
    }
    uint32_t bus_volt = g_sample_data.bus_volt;


    if (NULL != gp_bmu_data_unify)
    {
        bus_volt = gp_bmu_data_unify->all_pack_acc_volt * 100; // 转换单位为1mv
    }

    if (ALARM_APPEAR == is_appear)
    {
        /* 保护：电池包电压<960V，持续1s */
        if (bus_volt < gp_fault_para->total_under_vol_protect.appear_value * 100) // 转换单位为 1mV
        {
            result = true;
        }
    }
    else
    {
        /* 保护解除：电池簇电压>970V,持续1s */
        if (bus_volt > gp_fault_para->total_under_vol_protect.cancel_value * 100)
        {
            result = true; 
        }
    }
    return result;
}

/**
 * @brief		电池簇欠压保护打印函数
 */
static void bat_cluster_under_volt_pro_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("busV=%dmV,packNum=%d\n", g_sample_data.bus_volt, g_pack_num);

    if (NULL != gp_bmu_data_unify)
    {
        FAULT_MANAGE_LOGE("accV=%dmV\n", gp_bmu_data_unify->all_pack_acc_volt * 100);
    }
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->total_under_vol_protect.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->total_under_vol_protect.cancel_value);
    }
}

/**
 * @brief		总压压差过大
 */
static bool bat_cluster_volt_diff_over_fault_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    

    if (NULL == gp_bmu_data_unify || 0 == g_pack_num)
    {
        return false;
    }
    // 由于bmu上报的电压值精度为0.1V,g_sample_data.bus_volt精度为1mV, 转换一样的单位
    int32_t diff_volt_mv = gp_bmu_data_unify->all_pack_acc_volt * 100 - g_sample_data.bus_volt;
    /* |Σ电池包电压-电池簇电压|>12V*N(簇内电池包数量)，连续3s */
    result = (bool)(abs(diff_volt_mv) > (1200 * g_pack_num));
    if (ALARM_APPEAR == is_appear)
    {
        return result;
    }
    else
    {
        return false; // 不恢复
    }
}

/**
 * @brief		总压压差过大打印函数
 */
static void bat_cluster_volt_diff_over_fault_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (is_appear)
    {

        if (NULL == gp_bmu_data_unify || 0 == g_pack_num)
        {
            return;
        }
        FAULT_MANAGE_LOGE("accV=%dmV,busV=%d,diffV=%d(%d)\n", gp_bmu_data_unify->all_pack_acc_volt * 100, g_sample_data.bus_volt,((gp_bmu_data_unify->all_pack_acc_volt * 100 - g_sample_data.bus_volt)), 3200 * g_pack_num);
    }
}

/**
 * @brief    簇间压差过大故障检测
 */
static bool bat_inter_clu_volt_diff_over_fault_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    result = (bool)(get_parallel_state(PARALLEL_ERR) == BAT_VOLT_DIFF_ERR);

    if (is_appear == ALARM_APPEAR)
    {
        return result;
    }
    else
    {
        return !result;
    }
}


/**
 * @brief    充电电流超限告警
 */
static bool charge_overcurrent_limit_alarm_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    int32_t chg_curr_limit;
    int32_t max_curr_limit;
    chg_curr_limit = sop_data_get()->batt_clu_limit_chg_curr * 100;
    max_curr_limit = (chg_curr_limit + 5000) > (chg_curr_limit * 1.2) ? (chg_curr_limit + 5000) : (chg_curr_limit * 1.2);
    
    if (ALARM_APPEAR == is_appear){
        // BCU非禁充状态下&&BCU上报充电限流值不为0&&实际充电电流>MAX(充电限流值+5A，充电限流值*1.2)，持续30s
        if ((chg_curr_limit != 0) && (g_sample_data.sys_current > max_curr_limit)){
            result = true;
        }
    }
    else{
        // 电流＜1A持续30s（充电为正）
        if (g_sample_data.sys_current < 1000){
            result = true;
        }
    }

    return result;
}

/**
 * @brief    充电电流超限保护
 */
static bool charge_overcurrent_limit_protect_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    int32_t chg_curr_limit;

    chg_curr_limit = sop_data_get()->batt_clu_limit_chg_curr * 100;

    if (ALARM_APPEAR == is_appear){
        // (BCU禁充状态||BCU上报充电限流值为0)&&(充电电流≥0.5A），持续10s)
        if ((chg_curr_limit == 0) && (g_sample_data.sys_current > 500)){
            result = true;
        }
    }
    else{
        // 电流＜0.2A持续30s（充电为正）
        if (g_sample_data.sys_current < 200){
            result = true;
        }
    }

    return result;
}

/**
 * @brief    放电电流超限告警
 */
static bool dischg_overcurrent_limit_alarm_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    int32_t dsg_curr_limit;
    int32_t max_curr_limit;

    dsg_curr_limit = -(sop_data_get()->batt_clu_limit_dsg_curr * 100);
    max_curr_limit = (dsg_curr_limit - 5000) < (dsg_curr_limit * 1.2) ? (dsg_curr_limit - 5000) : (dsg_curr_limit * 1.2);
    if (ALARM_APPEAR == is_appear){
        // BCU非禁放状态下&&BCU上报放电限流值不为0&&实际放电电流>MAX(放电限流值+5A，放电限流值*1.2)，持续60s
        if ((dsg_curr_limit != 0) && (g_sample_data.sys_current < max_curr_limit)){
            result = true;
        }
    }
    else{
        // 电流>-1A持续30s（放电为负）
        if (g_sample_data.sys_current > -1000){
            result = true;
        }
    }
    
    return result;
}

/**
 * @brief    放电电流超限保护
 */
static bool dischg_overcurrent_limit_protect_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    int32_t dsg_curr_limit;

    dsg_curr_limit = sop_data_get()->batt_clu_limit_chg_curr * 100;

    if (ALARM_APPEAR == is_appear){
        // (BCU禁放状态||BCU上报放电限流值为0)&&(放电电流≥1A），持续10s)
        if ((dsg_curr_limit == 0) &&
            (g_sample_data.sys_current < -1000)){
            result = true;
        }
    }
    else{
        // 电流＜0.5A持续30s（放电为负）
        if (g_sample_data.sys_current < 500){
            result = true;
        }
    }

    return result;
}


/**
 * @brief    充电过流提示检测
 */
static bool charge_over_current_tip_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    static uint16_t auto_cancel_cnt = 0;
    if (NULL == gp_fault_para)
    {
        return false;
    }
    
    if (ALARM_APPEAR == is_appear)
    {
        auto_cancel_cnt = 0;
        /* 提示：簇电流>215A，持续3s */
        if (g_sample_data.sys_current > gp_fault_para->chg_over_cur_tip.appear_value * 100) // 转换单位为 1mA
        {
            result = true;
        }
    }
    else
    {
        /* 提示恢复:簇充电电流<205A，持续3s||簇放电电流>1A 1S*/
        if (g_sample_data.sys_current < gp_fault_para->chg_over_cur_tip.cancel_value * 100)
        {
            result = true;
        }
        if (g_sample_data.sys_current < -1000)
        {
            auto_cancel_cnt++;
            if (auto_cancel_cnt > 100)
            {
                auto_cancel_cnt = 100;
                fault_state_set(fault_id, FAULT_STOP);
                FAULT_MANAGE_LOGE("curr = %dmA\n", g_sample_data.sys_current);
                fault_name_print_deal(fault_id, false);
            }
        }
        else
        {
            auto_cancel_cnt = 0;
        }
    }
    return result;
}

/**
 * @brief		充电过流提示打印函数
 */
static void charge_over_current_tip_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("curr = %dmA\n", g_sample_data.sys_current);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->chg_over_cur_tip.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->chg_over_cur_tip.cancel_value);
    }
}

/**
 * @brief    充电过流告警检测
 */
static bool charge_over_current_alarm_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    static uint16_t auto_cancel_cnt = 0;
    if (NULL == gp_fault_para)
    {
        return false;
    }
    
    if (ALARM_APPEAR == is_appear)
    {
        auto_cancel_cnt = 0;
        /* 告警：簇电流>230A，持续3s */
        if (g_sample_data.sys_current > gp_fault_para->chg_over_cur_alarm.appear_value * 100)   // 转换单位为 1mA
        {
            result = true;
        }
    }
    else
    {
        /* 告警恢复:簇充电电流<220A，持续3s||簇放电电流>1A 1S*/
        if (g_sample_data.sys_current < gp_fault_para->chg_over_cur_alarm.cancel_value * 100)
        {
            result = true;
        }
        if (g_sample_data.sys_current < -1000)
        {
            auto_cancel_cnt++;
            if (auto_cancel_cnt > 100)
            {
                auto_cancel_cnt = 100;
                fault_state_set(fault_id, FAULT_STOP);
                FAULT_MANAGE_LOGE("curr = %dmA\n", g_sample_data.sys_current);
                fault_name_print_deal(fault_id, false);
            }
        }
        else
        {
            auto_cancel_cnt = 0;
        }
    }
    return result;
}

/**
 * @brief		充电过流告警打印函数
 */
static void charge_over_current_alarm_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("curr = %dmA\n", g_sample_data.sys_current);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->chg_over_cur_alarm.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->chg_over_cur_alarm.cancel_value);
    }
}

/**
 * @brief    充电过流保护检测
 */
static bool charge_over_current_pro_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    static uint16_t auto_cancel_cnt = 0;
    if (NULL == gp_fault_para)
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        auto_cancel_cnt = 0;
        /* 保护：簇电流>250A，持续3s */
        if (g_sample_data.sys_current > gp_fault_para->chg_over_cur_protect.appear_value * 100) // 转换单位为 1mA
        {
            result = true;
        }
    }
    else
    {
        /* 保护恢复:簇充电电流<240A，持续3s||簇放电电流>1A 1S*/
        if (g_sample_data.sys_current < gp_fault_para->chg_over_cur_protect.cancel_value * 100)
        {
            result = true;
        }
        if (g_sample_data.sys_current < -1000)
        {
            auto_cancel_cnt++;
            if (auto_cancel_cnt > 100)
            {
                auto_cancel_cnt = 100;
                fault_state_set(fault_id, FAULT_STOP);
            }
        }
        else
        {
            auto_cancel_cnt = 0;
        }
    }
    return result;
}

/**
 * @brief		充电过流保护打印函数
 */
static void charge_over_current_pro_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("curr=%dmA\n", g_sample_data.sys_current);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->chg_over_cur_protect.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->chg_over_cur_protect.cancel_value);
    }
}

/**
 * @brief    放电过流提示检测
 */
static bool discharge_over_current_tip_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    static uint16_t auto_cancel_cnt = 0;
    if (NULL == gp_fault_para)
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        auto_cancel_cnt = 0;
        /* 提示：簇放电电流>215A，持续3s */
        if ((g_sample_data.sys_current < 0) &&
            ((-g_sample_data.sys_current) > gp_fault_para->dchg_over_cur_tip.appear_value * 100))   // 转换单位为 1mV
        {
            result = true;
        }
    }
    else
    {
        /* 提示恢复:簇放电电流<205A，持续3s||簇放电电流>1A 1S*/
        if ((-g_sample_data.sys_current) < gp_fault_para->dchg_over_cur_tip.cancel_value * 100)
        {
            result = true;
        }
        if (g_sample_data.sys_current > 1000)
        {
            auto_cancel_cnt++;
            if (auto_cancel_cnt > 100)
            {
                auto_cancel_cnt = 100;
                fault_state_set(fault_id, FAULT_STOP);
                FAULT_MANAGE_LOGE("curr=%dmA\n", g_sample_data.sys_current);
                fault_name_print_deal(fault_id, is_appear);
            }
        }
        else
        {
            auto_cancel_cnt = 0;
        }
    }
    return result;
}

/**
 * @brief		放电过流提示打印函数
 */
static void discharge_over_current_tip_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("curr=%dmA\n", g_sample_data.sys_current);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->dchg_over_cur_tip.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->dchg_over_cur_tip.cancel_value);
    }
}

/**
 * @brief    放电过流告警检测
 */
static bool discharge_over_current_alarm_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    static uint16_t auto_cancel_cnt = 0;
    if (NULL == gp_fault_para)
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        auto_cancel_cnt = 0;
        /* 告警：簇放电电流>230A，持续3s */
        if ((g_sample_data.sys_current < 0) &&
            ((-g_sample_data.sys_current) > gp_fault_para->dchg_over_cur_alarm.appear_value * 100)) // 转换单位为 1mV
        {
            result = true;
        }
    }
    else
    {
        /* 告警恢复:簇放电电流<220A，持续3s||簇放电电流>1A 1S*/
        if ((-g_sample_data.sys_current) < gp_fault_para->dchg_over_cur_alarm.cancel_value * 100)
        {
            result = true;
        }
        if (g_sample_data.sys_current > 1000)
        {
            auto_cancel_cnt++;
            if (auto_cancel_cnt > 100)
            {
                auto_cancel_cnt = 100;
                fault_state_set(fault_id, FAULT_STOP);
                FAULT_MANAGE_LOGE("curr=%dmA\n", g_sample_data.sys_current);
                fault_name_print_deal(fault_id, is_appear);
            }
        }
        else
        {
            auto_cancel_cnt = 0;
        }
    }
    return result;
}

/**
 * @brief		放电过流告警打印函数
 */
static void discharge_over_current_alarm_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("curr=%dmA\n", g_sample_data.sys_current);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->dchg_over_cur_alarm.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->dchg_over_cur_alarm.cancel_value);
    }
}

/**
 * @brief    放电过流保护检测
 */
static bool discharge_over_current_pro_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    static uint16_t auto_cancel_cnt = 0;
    if (NULL == gp_fault_para)
    {
        return false;
    }
    if (ALARM_APPEAR == is_appear)
    {
        auto_cancel_cnt = 0;
        /* 保护：簇电流>250A，持续3s */
        if ((g_sample_data.sys_current < 0) &&
            ((-g_sample_data.sys_current) > gp_fault_para->dchg_over_cur_protect.appear_value * 100))   // 转换单位为 1mV
        {
            result = true;
        }
    }
    else
    {
        /* 保护恢复:簇放电电流<240A，持续3s||簇放电电流>1A 1S*/
        if ((-g_sample_data.sys_current) < gp_fault_para->dchg_over_cur_protect.cancel_value * 100)
        {
            result = true;
        }
        if (g_sample_data.sys_current > 1000)
        {
            auto_cancel_cnt++;
            if (auto_cancel_cnt > 100)
            {
                auto_cancel_cnt = 100;
                fault_state_set(fault_id, FAULT_STOP);
                FAULT_MANAGE_LOGE("curr=%dmA\n", g_sample_data.sys_current);
                fault_name_print_deal(fault_id, is_appear);
            }
        }
        else
        {
            auto_cancel_cnt = 0;
        }
    }
    return result;
}

/**
 * @brief		放电过流保护打印函数
 */
static void discharge_over_current_pro_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("curr=%dmA\n", g_sample_data.sys_current);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->dchg_over_cur_protect.appear_value);
    }
    else
    {
        fault_appear_value_print_deal(gp_fault_para->dchg_over_cur_protect.cancel_value);
    }
}

/**
 * @brief   簇间电流差异大告警（一级）
 */
static bool inter_clu_cur_diff_high_alarm_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    uint8_t zero_cur_clu_num = 0;
    uint32_t clu_cur_sum = 0;
    uint32_t other_clu_avg_cur = 0;
    uint8_t fault_flag = 0;
    
    const gold_bcu_integration_data *inter_clu_data = get_gobal_bcu_info();

    for (uint8_t i = 0; i < inter_clu_data->clu_bcu_num; i++)
    {
        if (get_cluster_bcu_data(i)->clu_curr == 0)
        {
            zero_cur_clu_num++;
        }

        clu_cur_sum += get_cluster_bcu_data(i)->clu_curr;
    }

    if (zero_cur_clu_num == 1)
    {
        other_clu_avg_cur = clu_cur_sum / (inter_clu_data->clu_bcu_num - 1);

        if (other_clu_avg_cur > (0.2 * get_bms_attr()->bat_cap * 1000))
        {
            fault_flag = 1;
        }
    }
    
    // 若仅有一簇电流为0，并且其余簇的平均电流＞0.2C，持续10s
    if (is_appear == ALARM_APPEAR)
    {
        if (fault_flag)
        {
            result = true;
        }
    }
    else
    {
        if (!fault_flag)
        {
            result = true;
        }
    }

    return result;
}

/**
 * @brief       soc过低提示
 */
static bool bat_soc_low_tip_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    const batt_clu_sox* sox_data = sox_data_get();
    if (NULL == sox_data)
    {
        return result;
    }
    if (SOX_INVALID_VAL == sox_data->batt_clu_display_soc)  // 无效值不判断
    {
        return result;
    }
    int32_t dispaly_soc = (int32_t)sox_data->batt_clu_display_soc * 10;  // 转成成0.1%
    if (ALARM_APPEAR == is_appear)
    {
        /* 告警：电池簇SOC<15%，持续3s */
        if (dispaly_soc < gp_fault_para->bat_soc_under_tip.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 解除：电池包SOC>17%，持续3s */
        if (dispaly_soc > gp_fault_para->bat_soc_under_tip.cancel_value)
        {
            result = true;
        }
    }
    return result;
}

/**
 * @brief		soc过低提示打印
 */
static void bat_soc_low_tip_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    const batt_clu_sox* sox_data = sox_data_get();
    if (NULL == sox_data || NULL == gp_fault_para)
    {
        return ;
    }
    FAULT_MANAGE_LOGE("soc=%d\n", sox_data->batt_clu_display_soc);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->bat_soc_under_tip.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->bat_soc_under_tip.cancel_value);
    }
}

/**
 * @brief       soc过低告警
 */
static bool bat_soc_low_alm_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    const batt_clu_sox* sox_data = sox_data_get();
    if (NULL == sox_data)
    {
        return result;
    }
    if (SOX_INVALID_VAL == sox_data->batt_clu_display_soc)  // 无效值不判断
    {
        return result;
    }
    int32_t dispaly_soc = (int32_t)sox_data->batt_clu_display_soc * 10;  // 转成成0.1%
    if (ALARM_APPEAR == is_appear)
    {
        /* 告警：电池簇SOC<10%，持续3s */
        if (dispaly_soc < gp_fault_para->bat_soc_under_alarm.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 解除：电池包SOC>12%，持续3s */
        if (dispaly_soc > gp_fault_para->bat_soc_under_alarm.cancel_value)
        {
            result = true;
        }
    }
    return result;
}

/**
 * @brief		soc过低告警打印
 */
static void bat_soc_low_alm_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    const batt_clu_sox* sox_data = sox_data_get();
    if (NULL == sox_data || NULL == gp_fault_para)
    {
        return ;
    }
    FAULT_MANAGE_LOGE("soc=%d\n", sox_data->batt_clu_display_soc);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->bat_soc_under_alarm.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->bat_soc_under_alarm.cancel_value);
    }
}

/**
 * @brief       soc过低保护
 */
static bool bat_soc_low_pro_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    const batt_clu_sox* sox_data = sox_data_get();
    if (NULL == sox_data)
    {
        return result;
    }
    if (SOX_INVALID_VAL == sox_data->batt_clu_display_soc)  // 无效值不判断
    {
        return result;
    }
    int32_t dispaly_soc = (int32_t)sox_data->batt_clu_display_soc * 10;  // 转成成0.1%
    if (ALARM_APPEAR == is_appear)
    {
        /* 告警：电池簇SOC<5%，持续3s */
        if (dispaly_soc < gp_fault_para->bat_soc_under_protect.appear_value)
        {
            result = true;
        }
    }
    else
    {
        /* 解除：电池包SOC>7%，持续3s */
        if (dispaly_soc > gp_fault_para->bat_soc_under_protect.cancel_value)
        {
            result = true;
        }
    }
    return result;
}

/**
 * @brief		soc过低保护打印
 */
static void bat_soc_low_pro_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    const batt_clu_sox* sox_data = sox_data_get();
    if (NULL == sox_data || NULL == gp_fault_para)
    {
        return ;
    }
    FAULT_MANAGE_LOGE("soc=%d\n", sox_data->batt_clu_display_soc);
    if (is_appear)
    {
        fault_appear_value_print_deal(gp_fault_para->bat_soc_under_protect.appear_value);
    }
    else
    {
        fault_cancel_value_print_deal(gp_fault_para->bat_soc_under_protect.cancel_value);
    }
}

/**
 * @brief       充电过流保护失能检测
 */
static void charge_over_curr_pro_disable_deal(void)
{
    static int32_t last_chg_over_curr_pro_flag = FAULT_STOP;
    static uint16_t chg_over_curr_pro_times = 0;
    static uint32_t chg_over_curr_cnt[OVER_CURR_LOCK_TIMES] = {0};
    if (FAULT_START == fault_state_get(BAT_CURR_OVER_PROTECT_DISABLE))
    {
        last_chg_over_curr_pro_flag = FAULT_STOP;
        chg_over_curr_pro_times = 0;
        return;
    }
    bool result = false;
    // 充电过流锁死判断
    int32_t curr_chg_over_curr_pro_flag = fault_state_get(BAT_CHARGE_CURR_HIGH_PROTECT);
    // 触发单电芯过压记录tick以及更新次数
    if ((last_chg_over_curr_pro_flag == FAULT_STOP) &&
        (curr_chg_over_curr_pro_flag == FAULT_START))
    {
        chg_over_curr_cnt[chg_over_curr_pro_times % OVER_CURR_LOCK_TIMES] = sdk_tick_get();
        chg_over_curr_pro_times++;
    }
    last_chg_over_curr_pro_flag = curr_chg_over_curr_pro_flag;
    result = continuous_pro_lock_judge_deal(chg_over_curr_cnt, OVER_CURR_LOCK_TIMES, &chg_over_curr_pro_times, 1200000);  // 20min内触发10次 20*60*1000=1200000
    
    if (result)
    {
        g_fault_lock_data.chg_curr_protect_times = OVER_CURR_LOCK_TIMES;
    }
    else
    {
        g_fault_lock_data.chg_curr_protect_times = (chg_over_curr_pro_times < OVER_CURR_LOCK_TIMES) ? chg_over_curr_pro_times : (OVER_CURR_LOCK_TIMES - 1);
    }
}

/**
 * @brief       放电过流保护失能检测
 */
static void discharge_over_curr_pro_disable_deal(void)
{
    static int32_t last_dchg_over_curr_pro_flag = FAULT_STOP;
    static uint32_t dchg_over_curr_cnt[OVER_CURR_LOCK_TIMES] = {0};
    static uint16_t dchg_over_curr_pro_times = 0;
    if (FAULT_START == fault_state_get(BAT_CURR_OVER_PROTECT_DISABLE))
    {
        last_dchg_over_curr_pro_flag = FAULT_STOP;
        dchg_over_curr_pro_times = 0;
        return;
    }
    bool result = false;
    // 过流保护锁死判断
    int32_t curr_dchg_over_curr_pro_flag = fault_state_get(BAT_DISCHG_CURR_OVER_PROTECT);
    // 触发单电芯过压记录tick以及更新次数
    if ((last_dchg_over_curr_pro_flag == FAULT_STOP) &&
        (curr_dchg_over_curr_pro_flag == FAULT_START))
    {
        dchg_over_curr_cnt[dchg_over_curr_pro_times % OVER_CURR_LOCK_TIMES] = sdk_tick_get();
        dchg_over_curr_pro_times++;
    }
    last_dchg_over_curr_pro_flag = curr_dchg_over_curr_pro_flag;
    result = continuous_pro_lock_judge_deal(dchg_over_curr_cnt, OVER_CURR_LOCK_TIMES, &dchg_over_curr_pro_times, 1200000); // 20min内触发10次 20*60*1000=1200000
    
    if (result)
    {
        g_fault_lock_data.dsg_curr_protect_times = OVER_CURR_LOCK_TIMES;
    }
    else
    {
        g_fault_lock_data.dsg_curr_protect_times = (dchg_over_curr_pro_times < OVER_CURR_LOCK_TIMES) ? dchg_over_curr_pro_times : (OVER_CURR_LOCK_TIMES - 1);
    }
}

/**
 * @brief       过流保护失能检测
 */
static bool chg_dchg_overcurrent_disable_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;
    static uint32_t curr_tick = 0;
    charge_over_curr_pro_disable_deal();
    discharge_over_curr_pro_disable_deal();

    if (ALARM_APPEAR == is_appear)
    {
        result = (bool)(OVER_CURR_LOCK_TIMES <= g_fault_lock_data.chg_curr_protect_times ||
                        OVER_CURR_LOCK_TIMES <= g_fault_lock_data.dsg_curr_protect_times);
        curr_tick = sdk_tick_get();
    }
    else
    {
        //电流保护消失且持续2小时
        if((FAULT_STOP == fault_state_get(BAT_DISCHG_CURR_OVER_PROTECT))
            && (FAULT_STOP == fault_state_get(BAT_CHARGE_CURR_HIGH_PROTECT))
            && (true == sdk_is_tick_over(curr_tick, 2*60*60*1000))
                )
        {
             result = true;
             g_fault_lock_data.chg_curr_protect_times = 0;
             g_fault_lock_data.dsg_curr_protect_times = 0;
        }
        else
        {
            curr_tick = sdk_tick_get();
        }
    }
    return result;
}

/**
 * @brief       过流保护失能打印
 */
static void chg_dchg_overcurrent_disable_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    FAULT_MANAGE_LOGE("chg_curr_pro_times=%d,dsg_curr_pro_times=%d\n", g_fault_lock_data.chg_curr_protect_times,g_fault_lock_data.dsg_curr_protect_times);
}

/**
 * @brief    严重过流锁死检测
 */
static bool overcurrent_deadlock_check(fault_type_e fault_id, bool is_appear)
{
    bool result = false;

    if (NULL == gp_fault_para)
    {
        return false;
    }

    if (ALARM_APPEAR == is_appear)
    {

        /* 锁死：簇放电电流>250A || 充电电流>220A，持续35s */
        if ((-g_sample_data.sys_current > 250000)
                || (g_sample_data.sys_current > 220000))
        {
            result = true;
        }
    }
    else
    {
        result = false; //不恢复
    }

    return result;
}

/**
 * @brief        严重过流锁死打印函数
 */
static void overcurrent_deadlock_print(fault_type_e fault_id, bool is_appear)
{
    fault_name_print_deal(fault_id, is_appear);
    if (NULL == gp_fault_para)
    {
        return;
    }
    FAULT_MANAGE_LOGE("curr=%dmA\n", g_sample_data.sys_current);
}



// 判断故障管理函数
void alarm_manage_deal(const fault_para_tab_t *fault_para_tab, uint16_t max_len)
{
    if (NULL == fault_para_tab || 0 == max_len || max_len > FAULT_MAX)
    {
        return;
    }
    for (uint16_t arr_index = 0; arr_index < max_len; arr_index++)
    {
        // 故障没有触发
        if (!fault_state_get(fault_para_tab[arr_index].fault_type))
        {
            // 判断是否满足触发条件
            if (fault_para_tab[arr_index].p_alarm_cb(fault_para_tab[arr_index].fault_type, ALARM_APPEAR))
            {
                g_alarm_cnt[(uint16_t)fault_para_tab[arr_index].fault_type] += 1;
            }
            else
            {
                g_alarm_cnt[(uint16_t)fault_para_tab[arr_index].fault_type] = 0;
            }
            if (g_alarm_cnt[(uint16_t)fault_para_tab[arr_index].fault_type] > fault_para_tab[arr_index].appear_cnt)
            {
                fault_state_set(fault_para_tab[arr_index].fault_type, FAULT_START);
                g_alarm_cnt[(uint16_t)fault_para_tab[arr_index].fault_type] = 0;
                if (NULL != fault_para_tab[arr_index].p_alarm_print_cb)
                {
                    fault_para_tab[arr_index].p_alarm_print_cb(fault_para_tab[arr_index].fault_type, ALARM_APPEAR);
                }
            }
        }
        else  // 故障触发
        {
            // 判断是否满足恢复条件
            if (fault_para_tab[arr_index].p_alarm_cb(fault_para_tab[arr_index].fault_type, ALARM_RECOVER))
            {
                g_alarm_cnt[(uint16_t)fault_para_tab[arr_index].fault_type] += 1;
            }
            else
            {
                g_alarm_cnt[(uint16_t)fault_para_tab[arr_index].fault_type] = 0;
            }
            if (g_alarm_cnt[(uint16_t)fault_para_tab[arr_index].fault_type] > fault_para_tab[arr_index].cancel_cnt)
            {
                fault_state_set(fault_para_tab[arr_index].fault_type, FAULT_STOP);
                g_alarm_cnt[(uint16_t)fault_para_tab[arr_index].fault_type] = 0;
                if (NULL != fault_para_tab[arr_index].p_alarm_print_cb)
                {
                    fault_para_tab[arr_index].p_alarm_print_cb(fault_para_tab[arr_index].fault_type, ALARM_RECOVER);
                }
            }
        }
    }
    // fault_change_print_deal();
}


static void fault_self_check(void)
{
    alarm_manage_deal(g_fault_para_tab, ITEM_NUM(g_fault_para_tab));
}

#ifdef SIMULATION_FAULT_TEST
static uint8_t simulate_test_fault_flag = false;			//模拟测试故障标志
static uint8_t g_run_fault_debeug_flag = false;			// 故障运行调测标志
#endif

static uint8_t fault_mudule_pack_num_get(void)
{
    #ifdef SIMULATION_FAULT_TEST
    //研发测试模式下
    if(true == g_run_fault_debeug_flag)
    {
        return g_pack_num;
    }
    #endif
    return auto_addressing_pack_num_get();
}

/**
 * @brief		故障诊断任务 周期10ms
 * @param		void
 * @param		void
 * @return		void
 */
int32_t fault_manage_task(void)
{
    static uint32_t start_tick;

    #ifdef SIMULATION_FAULT_TEST
    //研发测试模式下
    if(0xAA == simulate_test_fault_flag)
    {
        fault_stat_data_get(&g_fault_stat_data);
        fault_change_check_deal();
        return 0;
    }
    #endif

    // 故障使能判断,是否开启
    if (true != g_fault_enable)
    {
        return 0;
    }
    
    if (gp_bmu_data_unify == NULL)
    {
        gp_bmu_data_unify = (bmu_data_unify_t*)bmu_data_unify_get();
        if (gp_bmu_data_unify == NULL)
        {
            return -1;
        }
    }
    
    g_sample_data = *p_sample_data_get();
    g_pack_num = fault_mudule_pack_num_get();
    switch (g_fault_diag_step)
    {
        // 上电默认空闲状态
    case DIAG_NONE:
        fault_bcu_com_check_init();
        start_tick = sdk_tick_get();
        g_fault_diag_step = POWER_ON_SELF_TEST;
        break;
        // 开机自检，持续检测300ms，有永久性故障则退出，不再诊断，应用逻辑会进入休眠。
    case POWER_ON_SELF_TEST:
        fault_self_check();
        if (true == sdk_is_tick_over(start_tick, TICK_300MS))
        {
            g_fault_diag_step = DIAG_ON_RUNNING;
        }
        break;

        // 运行中诊断
    case DIAG_ON_RUNNING:
        check_inter_com_error();
        fault_self_check();
        break;
    default:
        break;
    }
    fault_stat_data_get(&g_fault_stat_data);
    fault_change_check_deal();
    return 0;
}

/**
* @brief		故障总状态信息，位操作， bit=0(无故障) bit=1(有故障)
* @param		[in] void
* @retval		1 有故障
* @retval		0 无故障
* @pre			
*/
const uint32_t *fault_total_state_get(void)
{
	return g_fault_state;
}

// 填充bcu报警消息位
static void fill_warn_msg(gold_warn_msg_t *p_warn_msg)
{
    inner_fault_info_t inner_bmu_fault_info = {0};
    const fault_stat_data_t* p_fault_info = fault_chg_dsg_level_get();

    if (gp_bmu_data_unify != NULL)
    {
        inner_bmu_fault_info = gp_bmu_data_unify->all_pack_inner_fault;
    }

    // 基本报警：保护
    p_warn_msg->base_warn[0].warn_byte0.bits.power_volt_under         = 0;  // bit0
    p_warn_msg->base_warn[0].warn_byte0.bits.power_volt_over          = 0;  // bit1
    p_warn_msg->base_warn[0].warn_byte0.bits.mod_temp_over            = fault_state_get(BOARD_ENV_TEMP_HIGH_PROTECT);             // bit2
    p_warn_msg->base_warn[0].warn_byte0.bits.clu_volt_under           = fault_state_get(BAT_CLUSTER_TOTAL_VOLT_LOW_PROTECT);      // bit3
    p_warn_msg->base_warn[0].warn_byte0.bits.clu_volt_over            = fault_state_get(BAT_CLUSTER_TOTAL_VOLT_HIGH_PROTECT);     // bit4
    p_warn_msg->base_warn[0].warn_byte0.bits.fast_chg_curr_over       = fault_state_get(BAT_CHARGE_CURR_HIGH_PROTECT);            // bit5
    p_warn_msg->base_warn[0].warn_byte0.bits.power_terminal_temp_over = fault_state_get(BOARD_POWER_TERMINAL_TEMP_OVER_PROTECT) 
                                                                        | inner_bmu_fault_info.fault_info1.byte0.bits.cell_v_h_pro;  // bit6
    p_warn_msg->base_warn[0].warn_byte0.bits.feed_curr_over           = 0;  // bit7
    
    p_warn_msg->base_warn[0].warn_byte1.bits.dsg_curr_over      = fault_state_get(BAT_DISCHG_CURR_OVER_PROTECT);   // bit0
    p_warn_msg->base_warn[0].warn_byte1.bits.ins_val_low        = fault_state_get(BOARD_INS_RES_VAL_LOW_PROTECT);  // bit1
    p_warn_msg->base_warn[0].warn_byte1.bits.soc_low            = fault_state_get(BAT_SOC_LOW_PROTECT);            // bit2
    p_warn_msg->base_warn[0].warn_byte1.bits.soc_high           = 0;  // bit3
    p_warn_msg->base_warn[0].warn_byte1.bits.cell_volt_over     = inner_bmu_fault_info.fault_info1.byte0.bits.cell_v_h_pro;  // bit4
    p_warn_msg->base_warn[0].warn_byte1.bits.cell_volt_under    = inner_bmu_fault_info.fault_info1.byte0.bits.cell_v_l_pro;  // bit5
    p_warn_msg->base_warn[0].warn_byte1.bits.cell_volt_diff     = inner_bmu_fault_info.fault_info2.byte2.bits.cell_v_serious_diff_err;  // bit6
    p_warn_msg->base_warn[0].warn_byte1.bits.chg_cell_temp_high = inner_bmu_fault_info.fault_info1.byte1.bits.chg_temp_h_pro;  // bit7
    
    p_warn_msg->base_warn[0].warn_byte2.bits.chg_cell_temp_low   = inner_bmu_fault_info.fault_info1.byte1.bits.chg_temp_l_pro;  // bit0
    p_warn_msg->base_warn[0].warn_byte2.bits.dsg_cell_temp_over  = inner_bmu_fault_info.fault_info1.byte1.bits.dis_temp_h_pro;  // bit1
    p_warn_msg->base_warn[0].warn_byte2.bits.dsg_cell_temp_low   = inner_bmu_fault_info.fault_info1.byte1.bits.dis_temp_l_pro;  // bit2
    p_warn_msg->base_warn[0].warn_byte2.bits.cell_temp_diff_over = inner_bmu_fault_info.fault_info1.byte7.bits.cell_temp_diff_err;  // bit3
    p_warn_msg->base_warn[0].warn_byte2.bits.soc_diff_over       = 0;  // bit4
    p_warn_msg->base_warn[0].warn_byte2.bits.cell_temp_rise_fast = inner_bmu_fault_info.fault_info2.byte3.bits.cell_temp_rise_err;  // bit5
    p_warn_msg->base_warn[0].warn_byte2.bits.bat_volt_over       = inner_bmu_fault_info.fault_info1.byte0.bits.total_v_h_pro;  // bit6
    p_warn_msg->base_warn[0].warn_byte2.bits.bat_volt_under      = inner_bmu_fault_info.fault_info1.byte0.bits.total_v_l_pro;  // bit7

    // 基本报警：告警
    p_warn_msg->base_warn[1].warn_byte0.bits.power_volt_under         = 0;  // bit0
    p_warn_msg->base_warn[1].warn_byte0.bits.power_volt_over          = 0;  // bit1
    p_warn_msg->base_warn[1].warn_byte0.bits.mod_temp_over            = fault_state_get(BOARD_ENV_TEMP_HIGH_ALARM);             // bit2
    p_warn_msg->base_warn[1].warn_byte0.bits.clu_volt_under           = fault_state_get(BAT_CLUSTER_TOTAL_VOLT_LOW_ALARM);      // bit3
    p_warn_msg->base_warn[1].warn_byte0.bits.clu_volt_over            = fault_state_get(BAT_CLUSTER_TOTAL_VOLT_HIGH_ALARM);     // bit4
    p_warn_msg->base_warn[1].warn_byte0.bits.fast_chg_curr_over       = fault_state_get(BAT_CHARGE_CURR_HIGH_ALARM);            // bit5
    p_warn_msg->base_warn[1].warn_byte0.bits.power_terminal_temp_over = fault_state_get(BOARD_POWER_TERMINAL_TEMP_OVER_ALARM);  // bit6
    p_warn_msg->base_warn[1].warn_byte0.bits.feed_curr_over           = 0;  // bit7
    
    p_warn_msg->base_warn[1].warn_byte1.bits.dsg_curr_over      = fault_state_get(BAT_DISCHG_CURR_OVER_ALARM);   // bit0
    p_warn_msg->base_warn[1].warn_byte1.bits.ins_val_low        = fault_state_get(BOARD_INS_RES_VAL_LOW_ALARM);  // bit1
    p_warn_msg->base_warn[1].warn_byte1.bits.soc_low            = fault_state_get(BAT_SOC_LOW_ALARM);            // bit2
    p_warn_msg->base_warn[1].warn_byte1.bits.soc_high           = 0;  // bit3
    p_warn_msg->base_warn[1].warn_byte1.bits.cell_volt_over     = inner_bmu_fault_info.fault_info1.byte0.bits.cell_v_h_alm;  // bit4
    p_warn_msg->base_warn[1].warn_byte1.bits.cell_volt_under    = inner_bmu_fault_info.fault_info1.byte0.bits.cell_v_l_alm;  // bit5
    p_warn_msg->base_warn[1].warn_byte1.bits.cell_volt_diff     = inner_bmu_fault_info.fault_info3.byte2.bits.cell_volt_diff_over_alm;  // bit6
    p_warn_msg->base_warn[1].warn_byte1.bits.chg_cell_temp_high = inner_bmu_fault_info.fault_info1.byte1.bits.chg_temp_h_alm;  // bit7
    
    p_warn_msg->base_warn[1].warn_byte2.bits.chg_cell_temp_low   = inner_bmu_fault_info.fault_info1.byte1.bits.chg_temp_l_alm;  // bit0
    p_warn_msg->base_warn[1].warn_byte2.bits.dsg_cell_temp_over  = inner_bmu_fault_info.fault_info1.byte1.bits.dis_temp_h_alm;  // bit1
    p_warn_msg->base_warn[1].warn_byte2.bits.dsg_cell_temp_low   = inner_bmu_fault_info.fault_info1.byte1.bits.dis_temp_l_alm;  // bit2
    p_warn_msg->base_warn[1].warn_byte2.bits.cell_temp_diff_over = inner_bmu_fault_info.fault_info3.byte2.bits.cell_temp_diff_over_alm;  // bit3
    p_warn_msg->base_warn[1].warn_byte2.bits.soc_diff_over       = 0;  // bit4
    p_warn_msg->base_warn[1].warn_byte2.bits.cell_temp_rise_fast = inner_bmu_fault_info.fault_info2.byte3.bits.cell_temp_rise_err;  ;  // bit5
    p_warn_msg->base_warn[1].warn_byte2.bits.bat_volt_over       = inner_bmu_fault_info.fault_info1.byte0.bits.total_v_h_alm;  // bit6
    p_warn_msg->base_warn[1].warn_byte2.bits.bat_volt_under      = inner_bmu_fault_info.fault_info1.byte0.bits.total_v_l_alm;  // bit7

    // 基本报警：提示
    p_warn_msg->base_warn[2].warn_byte0.bits.power_volt_under         = fault_state_get(BOARD_POWER_VOLT_UNDER_TIPS) | inner_bmu_fault_info.fault_info1.byte6.bits.aux_power_err;          // bit0
    p_warn_msg->base_warn[2].warn_byte0.bits.power_volt_over          = fault_state_get(BOARD_POWER_VOLT_OVER_TIPS) | inner_bmu_fault_info.fault_info1.byte6.bits.aux_power_err;           // bit1
    p_warn_msg->base_warn[2].warn_byte0.bits.mod_temp_over            = fault_state_get(BOARD_ENV_TEMP_HIGH_TIPS) | inner_bmu_fault_info.fault_info1.byte2.bits.en_temp_h_alm;               // bit2
    p_warn_msg->base_warn[2].warn_byte0.bits.clu_volt_under           = fault_state_get(BAT_CLUSTER_TOTAL_VOLT_LOW_TIPS);       // bit3
    p_warn_msg->base_warn[2].warn_byte0.bits.clu_volt_over            = fault_state_get(BAT_CLUSTER_TOTAL_VOLT_HIGH_TIPS);      // bit4
    p_warn_msg->base_warn[2].warn_byte0.bits.fast_chg_curr_over       = fault_state_get(BAT_CHARGE_CURR_HIGH_TIPS);             // bit5
    p_warn_msg->base_warn[2].warn_byte0.bits.power_terminal_temp_over = fault_state_get(BOARD_POWER_TERMINAL_TEMP_OVER_TIPS);   // bit6
    p_warn_msg->base_warn[2].warn_byte0.bits.feed_curr_over           = 0;  // bit7
    
    p_warn_msg->base_warn[2].warn_byte1.bits.dsg_curr_over      = fault_state_get(BAT_DISCHG_CURR_OVER_TIPS);    // bit0
    p_warn_msg->base_warn[2].warn_byte1.bits.ins_val_low        = fault_state_get(BOARD_INS_RES_VAL_LOW_TIPS);   // bit1
    p_warn_msg->base_warn[2].warn_byte1.bits.soc_low            = fault_state_get(BAT_SOC_LOW_TIPS);             // bit2
    p_warn_msg->base_warn[2].warn_byte1.bits.soc_high           = 0;  // bit3
    p_warn_msg->base_warn[2].warn_byte1.bits.cell_volt_over     = inner_bmu_fault_info.fault_info3.byte0.bits.cell_over_volt_tip;  // bit4
    p_warn_msg->base_warn[2].warn_byte1.bits.cell_volt_under    = inner_bmu_fault_info.fault_info3.byte0.bits.cell_under_volt_tip;  // bit5
    p_warn_msg->base_warn[2].warn_byte1.bits.cell_volt_diff     = inner_bmu_fault_info.fault_info3.byte0.bits.cell_volt_diff_over_tip;  // bit6
    p_warn_msg->base_warn[2].warn_byte1.bits.chg_cell_temp_high = inner_bmu_fault_info.fault_info2.byte3.bits.chg_temp_tip_h;  // bit7
    
    p_warn_msg->base_warn[2].warn_byte2.bits.chg_cell_temp_low   = inner_bmu_fault_info.fault_info2.byte3.bits.chg_temp_tip_l;  // bit0
    p_warn_msg->base_warn[2].warn_byte2.bits.dsg_cell_temp_over  = inner_bmu_fault_info.fault_info2.byte3.bits.dsg_temp_tip_h;  // bit1
    p_warn_msg->base_warn[2].warn_byte2.bits.dsg_cell_temp_low   = inner_bmu_fault_info.fault_info2.byte3.bits.dsg_temp_tip_l;  // bit2
    p_warn_msg->base_warn[2].warn_byte2.bits.cell_temp_diff_over = inner_bmu_fault_info.fault_info3.byte0.bits.cell_temp_diff_over_tip;  // bit3
    p_warn_msg->base_warn[2].warn_byte2.bits.soc_diff_over       = 0;  // bit4
    p_warn_msg->base_warn[2].warn_byte2.bits.cell_temp_rise_fast = 0;  // bit5
    p_warn_msg->base_warn[2].warn_byte2.bits.bat_volt_over       = inner_bmu_fault_info.fault_info3.byte0.bits.bat_over_volt_tip;  // bit6
    p_warn_msg->base_warn[2].warn_byte2.bits.bat_volt_under      = inner_bmu_fault_info.fault_info3.byte0.bits.bat_under_volt_tip;  // bit7

    // 设备故障报警
    p_warn_msg->dev_warn.warn_byte0.bits.di1_err = fault_state_get(BOARD_POSITIVE_RELAY_ADHESION_FAULT);  // bit0;//di_state_get(DI_1_ADS_ALARM);                // bit0
    p_warn_msg->dev_warn.warn_byte0.bits.di2_err = 0;//di_state_get(DI_2_CLUSTER_ADDR);             // bit1
    p_warn_msg->dev_warn.warn_byte0.bits.di3_err = fault_state_get(BOARD_NEGATIVE_RELAY_ADHESION_FAULT);;//di_state_get(DI_3_EXT_WDT);                  // bit2
    p_warn_msg->dev_warn.warn_byte0.bits.di4_err = 0;//di_state_get(DI_4_POS_RELAY);                // bit3
    p_warn_msg->dev_warn.warn_byte0.bits.di5_err = 0;//di_state_get(DI_5_AUXILIARY_POWER_SWITCH);   // bit4
    p_warn_msg->dev_warn.warn_byte0.bits.di6_err = 0;//di_state_get(DI_6_NEG_RELAY);                // bit5
    p_warn_msg->dev_warn.warn_byte0.bits.di7_err = 0;//di_state_get(DI_7_EMERGENCY_STOP);           // bit6
    p_warn_msg->dev_warn.warn_byte0.bits.di8_err = 0;//di_state_get(DI_8_CMU_FAULT);                // bit7

    p_warn_msg->dev_warn.warn_byte1.bits.inner_comm_err           = fault_state_get(BOARD_INNER_CAN_COMM_FAULT);  // bit0
    p_warn_msg->dev_warn.warn_byte1.bits.cell_volt_sample_err     = inner_bmu_fault_info.fault_info2.byte4.bits.cell_v_line_err;  // bit1
    p_warn_msg->dev_warn.warn_byte1.bits.cell_temp_sample_err     = inner_bmu_fault_info.fault_info2.byte4.bits.cell_temp_line_err;  // bit2
    p_warn_msg->dev_warn.warn_byte1.bits.pc_err                   = 0;  // bit3
    p_warn_msg->dev_warn.warn_byte1.bits.inter_clu_volt_diff_over = fault_state_get(BAT_INTER_CLU_VOLT_DIFF_OVER_FAULT);  // bit4
    p_warn_msg->dev_warn.warn_byte1.bits.trip_err                 = fault_state_get(BOARD_TRIP_FAULT);  // bit5
    p_warn_msg->dev_warn.warn_byte1.bits.dodi_err                 = 0;  // bit6
    p_warn_msg->dev_warn.warn_byte1.bits.cell_limit_err           = inner_bmu_fault_info.fault_info3.byte4.bits.cell_limit_err;  // bit7

    p_warn_msg->dev_warn.warn_byte2.bits.code_param_err    = 0;         // bit0
    p_warn_msg->dev_warn.warn_byte2.bits.pcs_comm_err      = fault_state_get(BOARD_BCU_PCS_CAN_COMM_ABNORMAL_FAULT);   // bit1
    p_warn_msg->dev_warn.warn_byte2.bits.pc_ctl_mode       = get_gobal_bcu_info()->set_clu_sw;         // bit2
    p_warn_msg->dev_warn.warn_byte2.bits.hall_dev_err      = fault_state_get(BOARD_CAN_HALL_SENSOR_FAULT);             // bit3
    p_warn_msg->dev_warn.warn_byte2.bits.hall_comm_err     = fault_state_get(BOARD_CAN_HALL_SENSOR_COMM_FAULT);        // bit4
    p_warn_msg->dev_warn.warn_byte2.bits.hard_self_err     = fault_state_get(BOARD_HARD_SELF_DET_FAULT);               // bit5
    p_warn_msg->dev_warn.warn_byte2.bits.pole_temp_sam_err = fault_state_get(BOARD_POWER_TERMINAL_TEMP_SAM_FAULT)
                                                             | inner_bmu_fault_info.fault_info2.byte4.bits.power_temp_line_err;      // bit6
    p_warn_msg->dev_warn.warn_byte2.bits.bal_err           = inner_bmu_fault_info.fault_info2.byte2.bits.pass_bal_temp_h |
                                                             inner_bmu_fault_info.fault_info2.byte4.bits.pass_bal_temp_line_err;   // bit7

    // bit0 和 bit2 预留
    p_warn_msg->dev_warn.warn_byte3.bits.cur_diff_h_alm         = fault_state_get(BOARD_INTER_CLU_CUR_DIFF_OVER_ALARM);  // bit1
    p_warn_msg->dev_warn.warn_byte3.bits.pre_chg_overtime       = fault_state_get(BOARD_PRE_CHARGE_FAULT);   // bit3
    p_warn_msg->dev_warn.warn_byte3.bits.fan_closed_before_trip = 0;    // bit4
    p_warn_msg->dev_warn.warn_byte3.bits.dbc_en_opened          = 0;    // bit5
    p_warn_msg->dev_warn.warn_byte3.bits.power_off_err          = fault_state_get(BOARD_POWER_OFF_FAULT);    // bit6
    p_warn_msg->dev_warn.warn_byte3.bits.all_clu_err_power_off  = fault_state_get(BOARD_ALL_CLUSTER_POWER_OFF_FAULT);    // bit7
    
    
    // 新增的告警信息
    p_warn_msg->add_warn.dev_byte0.bits.hv_sam_err              = fault_state_get(BOARD_EXT_ADC_FAULT);    //
    p_warn_msg->add_warn.dev_byte0.bits.afe_err                 = inner_bmu_fault_info.fault_info1.byte4.bits.samp_invalid; //bmu的采集异常其实就afe异常
    p_warn_msg->add_warn.dev_byte0.bits.inner_addr_err        = fault_state_get(BOARD_INNER_CAN_ADDR_REPEAT_FAULT);  //    
    p_warn_msg->add_warn.dev_byte0.bits.serious_ov_curr_lock        = fault_state_get(BAT_CURR_OVER_SERIOUS_LOCK);  //   
    p_warn_msg->add_warn.dev_byte0.bits.serious_h_volt_lock        = inner_bmu_fault_info.fault_info2.byte4.bits.cell_v_lock_h_err2;  

    p_warn_msg->add_warn.protect_byte0.bits.clu_volt_diff       = fault_state_get(BAT_CLUSTER_TOTAL_VOLT_DIFF_OVER_FAULT) | inner_bmu_fault_info.fault_info1.byte3.bits.total_v_err;    //
    p_warn_msg->add_warn.protect_byte0.bits.bat_dischg_curr_over_limit_protect = fault_state_get(BAT_DISCHG_CURR_OVER_LIMIT_PROTECT);      //
    p_warn_msg->add_warn.protect_byte0.bits.bat_charge_curr_over_limit_protect = fault_state_get(BAT_CHARGE_CURR_OVER_LIMIT_PROTECT);      //
    p_warn_msg->add_warn.protect_byte0.bits.bat_curr_protect_disable = fault_state_get(BAT_CURR_OVER_PROTECT_DISABLE);      //
    p_warn_msg->add_warn.protect_byte0.bits.bat_volt_high_protect_disable = inner_bmu_fault_info.fault_info2.byte2.bits.cell_v_lock_h;      //
    p_warn_msg->add_warn.protect_byte0.bits.bat_volt_low_protect_disable = inner_bmu_fault_info.fault_info2.byte2.bits.cell_v_lock_l;      //
    p_warn_msg->add_warn.protect_byte0.bits.bat_cell_temp_high_or_low_protect_disable = inner_bmu_fault_info.fault_info2.byte3.bits.cell_temp_lock_hl;      //    
    

    p_warn_msg->add_warn.alarm_byte0.bits.addr_conflict         = fault_state_get(BOARD_BCU_BCU_CANID_CONFLICT_ALARM) | inner_bmu_fault_info.fault_info1.byte5.bits.canid_conflict;      //
    p_warn_msg->add_warn.alarm_byte0.bits.bat_dischg_curr_over_limit_alarm = fault_state_get(BAT_DISCHG_CURR_OVER_LIMIT_ALARM);      //
    p_warn_msg->add_warn.alarm_byte0.bits.bat_charge_curr_over_limit_alarm = fault_state_get(BAT_CHARGE_CURR_OVER_LIMIT_ALARM);      //

    p_warn_msg->add_warn.tip_byte0.bits.afe_chain_break         = inner_bmu_fault_info.fault_info3.byte1.bits.afe_chain_break_tip;
    p_warn_msg->add_warn.tip_byte0.bits.hall_curr_diff          = fault_state_get(BOARD_HALL_CURR_DIFF_OVER_ALARM); 
    p_warn_msg->add_warn.tip_byte0.bits.env_temp_sam            = fault_state_get(BOARD_ENV_TEMP_SAM_ABNORMAL_ALARM) | inner_bmu_fault_info.fault_info1.byte4.bits.ntc_invalid;    //    
    p_warn_msg->add_warn.tip_byte0.bits.electrolyte_sen         = inner_bmu_fault_info.fault_info3.byte1.bits.electrolyte_sen_tip;   
    p_warn_msg->add_warn.tip_byte0.bits.cell_temp_sam           = inner_bmu_fault_info.fault_info3.byte1.bits.cell_temp_line_tip;   
    
    for(uint8_t i = 0; i < DEV_NUM; i++)
    {
        if (0 == i)     // bcu赋到数组0
        {
            p_warn_msg->alarm_no[i] = p_fault_info->fault_level;            
        }
        else
        {
            p_warn_msg->alarm_no[i] = gp_bmu_data_unify->fault_level[i - 1];            
        }

    }
    
    
}

// 故障变化上报处理
static void fault_change_check_deal(void)
{
    static inner_fault_info_t last_bmu_inner_fault_info = {0};
    inner_fault_info_t cur_bmu_inner_fault_info = gp_bmu_data_unify->all_pack_inner_fault;
    static uint32_t bcu_last_fault_state[FAULT_GROUP_NUM] = {0};
    static uint32_t fill_fault_tick = 0;  
    static uint32_t running_data_save_tick = 0;        
    uint8_t fill_flag = 0;
    uint8_t group_id = 0;
    
    // bcu故障变化
    for (group_id = 0; group_id < FAULT_GROUP_NUM; group_id++)
    {
        if (g_fault_state[group_id] != bcu_last_fault_state[group_id])
        {
            fill_flag = 1;
            break;
        }
    }

    if (group_id == FAULT_GROUP_NUM)
    {
        // bmu故障变化
        if (memcmp(&last_bmu_inner_fault_info, &cur_bmu_inner_fault_info, sizeof(inner_fault_info_t)) != 0)
        {
            fill_flag = 1;
        }
    }
    
    // 故障数据填充，和请求发送
    if (fill_flag)
    {
        bms_runing_data_save_all();
        fill_warn_msg(&g_warn_msg_reply);
        ext_can_send_msg_ready(EX_TX_GOLD_ALARM_DATA_ACK);
        ext_can_send_msg_ready(EX_TX_GOLD_FAULT_DATA_ACK);                
        fill_fault_tick = sdk_tick_get();
        running_data_save_tick = sdk_tick_get();
        // 更新上一时刻值
        memcpy(bcu_last_fault_state, g_fault_state, sizeof(g_fault_state));
        last_bmu_inner_fault_info = cur_bmu_inner_fault_info;
    }
    else
    {
        // 没有变化时每5s填充一次
        if (true == sdk_is_tick_over(fill_fault_tick, os_tick_from_millisecond(5000)))
        {
            fill_warn_msg(&g_warn_msg_reply);
            fill_fault_tick = sdk_tick_get();
        }
        // 没有变化时每30min填充一次
        if (true == sdk_is_tick_over(running_data_save_tick, os_tick_from_millisecond(RUNNING_DATA_SAVE_PERIOD)))
        {

            bms_runing_data_save_all();
            running_data_save_tick = sdk_tick_get();
        }
    }
}

/**
 * @brief   获取应答回复的告警信息
 */
const gold_warn_msg_t *warn_msg_reply_get(void)
{
    return &g_warn_msg_reply;
}

/**
 * @brief 清除CAN霍尔传感器通讯故障计数值
 */
void can_hall_sensor_comm_err_cnt_clr(void)
{
    g_can_hall_sensor_comm_err_cnt = 0;
}

/**
 * @brief 清除BCU-PCS通讯故障计数值
 */
void bcu_pcs_comm_err_cnt_clr(void)
{
    g_bcu_pcs_comm_err_cnt = 0;
}

#ifdef SIMULATION_FAULT_TEST
/********************************************调试代码********************************************************/
/**
 * @brief                故障信息打印
 * @return               返回结果空
 * @warning              测试调试使用
 */
void fault_printf(void)
{
    fault_type_e fault_index = BOARD_FAULT_INDEX;
    log_d("faultStep=%d\n", g_fault_diag_step);
    log_d("faultEn=%d\n", g_fault_enable);
    fault_stat_data_t *p_fault_stat_data = (fault_stat_data_t*)fault_chg_dsg_level_get();
    log_d("faultNum=%d\n", p_fault_stat_data->fault_num);
    log_d("faultchrglev=%d\n", p_fault_stat_data->max_charge_level);
    log_d("faultdischrglev=%d\n", p_fault_stat_data->max_discharge_level);
    log_d("runFaultDebeug=%d\n", g_run_fault_debeug_flag);
    log_d("simTestFault=%#x\n", simulate_test_fault_flag);
    log_d("packNum=%#x\n", g_pack_num);
    log_d("comErr=%#x\n", g_inner_com_error_flag);
    log_d("autoAddrFault=%d\n", auto_addressing_fault_get());
    log_d("time2scnt=%ld,autoAddrSta=%d\n", g_time2scnt, auto_addressing_get_state());
    for(fault_index = BOARD_FAULT_INDEX;fault_index < FAULT_MAX;fault_index++)
    {
        if(FAULT_START == fault_state_get(fault_index))
        {
            log_d("[ALM]%#x\n", fault_index);
        }
        os_delay(2);
    }
}


/**
 * @brief                故障强制注入
 * @return               返回结果空
 * @warning              测试调试使用
 */
void shell_set_fault_proc(char *para2, char *para3)
{
    uint16_t fault_id = 0;
    uint8_t operation = 0;

    if (NULL != para2 &&
        NULL != para3)
    {
        fault_id = strtol(para2, &para2,16); 
        operation = atoi(para3);

        if(fault_id >= FAULT_MAX)
        {
            log_d("canNotFind%#x\n", fault_id);
        }
        else
        {
            if(1 == operation)
            {
                fault_state_set( (fault_type_e)fault_id , FAULT_START);
                log_d("faultTestSet%#x onOK\n", fault_id);
            }
            else if(0 == operation)
            {
                fault_state_set( (fault_type_e)fault_id , FAULT_STOP);
                log_d("faultTestSet %#x offOK\n", fault_id);
            }
            else
            {
                log_d("faultTestSetParaErr\n");
            }
        }
    }
    else
    {
        log_d("faultTestSetParaErr\n");
    }
}

// 打印故障锁死累计次数
void fault_lock_time_print(void)
{
    log_d("chgProCnt=%d\n", g_fault_lock_data.chg_curr_protect_times);
    log_d("dsgProCnt=%d\n", g_fault_lock_data.dsg_curr_protect_times);
    log_d("poweTerminalProCnt=%d\n", g_fault_lock_data.power_terminal_protect_times );
    log_d("cellVoltOverProCnt=%d\n", g_fault_lock_data.cell_volt_over_protect_times );
    log_d("totalVoltOverProCnt=%d\n", g_fault_lock_data.total_volt_over_protect_times);
    log_d("cellVoltLowProCnt=%d\n", g_fault_lock_data.cell_volt_low_protect_times  );
    log_d("totalVoltLowProCnt=%d\n", g_fault_lock_data.total_volt_low_protect_times );
    log_d("chgTempOverProCnt= %d\n", g_fault_lock_data.chg_temp_over_protect_times  );
    log_d("chgTempLowProCnt=%d\n", g_fault_lock_data.chg_temp_low_protect_times   );
    log_d("dsgTempOverProCnt=%d\n", g_fault_lock_data.dsg_temp_over_protect_times  );
    log_d("dsgTempLowProCnt=%d\n", g_fault_lock_data.dsg_temp_low_protect_times   );
    log_d("innerCanAddFaultCn=d\n", g_fault_lock_data.inner_can_addr_fault_times   );
}

#endif

#ifdef SIMULATION_FAULT_TEST
/**
 * @brief                故障调试接口
 * @return               返回结果空
 * @warning              测试调试使用
 */
int32_t fault(int argc, char *argv[])
{

	if (argc < 2)
	{
		fault_printf();
	}
    else
	{
		if(!strcmp(argv[1], "on"))		//启动控制
		{
			simulate_test_fault_flag = 0xAA;
			
			log_d("fault_test on OK\n");
		}
		else if(!strcmp(argv[1], "off"))	//关闭控制
		{
			simulate_test_fault_flag = 0x55;
			
			log_d("fault_test off OK\n");
		}
		else if(!strcmp(argv[1], "set"))
		{
            if (argc < 4)
            {
                log_d("fault set x x err\n");
                return SF_ERR_PARA;
            }
			if(0xAA == simulate_test_fault_flag)
			{
				shell_set_fault_proc(argv[2], argv[3]);
			}
			else
			{
				log_d("did not open fault_test mode \n");
			}
		}
        else if(!strcmp(argv[1], "all"))
        {
            if(0xAA == simulate_test_fault_flag)
            {
                //一次性强制注入所有故障
                char hexString[3];
                for(uint8_t i = 0; i < FAULT_MAX; i++)
                {
                    sprintf(hexString, "%X", i);
                    shell_set_fault_proc(hexString, "1");
                    os_delay(2);
                }
            }
        }
        else if (!strcmp(argv[1], "clr"))
        {
            memset(g_fault_state, 0, sizeof(g_fault_state));
            log_d("clear all fault \n");
        }
        else if (!strcmp(argv[1], "init"))
        {
            fault_manage_init();
            g_fault_enable = true;
            log_d("init fault, fault_enable\n");
        }
        else if (!strcmp(argv[1], "lockp"))
        {
            fault_lock_time_print();
        }
        else if (!strcmp(argv[1], "packnum"))
        {
            if (argc < 3)
            {
                log_d("fault packnum x err\n");
                return SF_ERR_PARA;
            }
            uint8_t pack_num = atoi(argv[2]);
            g_pack_num = pack_num;
            g_run_fault_debeug_flag = true;
        }
        else if (!strcmp(argv[1], "cnt"))
        {
            bms_runing_data_t bms_running_data = {0};
            if (get_bms_runing_data() != NULL)
            {
                bms_running_data = *get_bms_runing_data();
            }
            else
            {
                log_d("FaultCntGetFail\n");
                return 0;
            }

            if (!strcmp(argv[2], "clr"))
            {
                bms_protect_cnt_clear();
                log_d("FaultCntClearSuc\n");
            }
            else if (!strcmp(argv[2], "get"))
            {
                for (uint8_t i = 0; i < ITEM_NUM(bms_running_data.fault_cnt); i++)
                {
                    log_d("fault_cnt[%d] = %d\n", i, bms_running_data.fault_cnt[i]);
                    os_delay(2);
                }
            }
            else
            {
                log_d("ParaErr\n");
            }
        }
		else
		{
			log_d("sim_test operator ERROR \n");
		}
	}

    return 0;
}
MSH_CMD_EXPORT(fault, <on/off/set id 0-1/all/clr/lock_clr/init/lockp/packnum>);
#endif
