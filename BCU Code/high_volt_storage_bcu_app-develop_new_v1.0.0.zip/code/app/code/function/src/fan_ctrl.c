#include "fan_ctrl.h"
#include "sdk.h"
#include "app_config.h"
#include "app_public.h"
#include "sample.h"
#include "data_store.h"
#include "auto_addressing.h"
#include "ate.h"
#include "bcu_data.h"

static uint8_t g_fan_debug_flag = 0;
static uint8_t g_fan_flag = 0;

/***************************风扇模块对外接口***************************************/
/**
* @brief		风扇控制初始化函数
* @param		无  
* @return		返回结果
* @retval		0：正常  <0:异常
* @warning		无
*/
int32_t fan_ctrl_init(void)
{
    return 0;
}
/**
* @brief		风扇控制函数处理
* @param		无  
* @return		无
* @warning		无
*/
void fan_ctrl_proc(void)
{
    static uint16_t fan_open_cnt,fan_close_cnt = 0;
    sample_data_t sample_data = {0}; 
    
    sample_data = *p_sample_data_get();
    if (special_mode_get(ATUO_TEST))
    {
        return;
    }

    if(true == g_fan_debug_flag)
    {
        return;
    }

    if(true == (get_gobal_bcu_info()->set_clu_sw))
    {
        static uint8_t temp = 0;
        if(temp == get_gobal_bcu_info()->set_clu_do)
        {
            return ;
        }
        temp = get_gobal_bcu_info()->set_clu_do;
        if((get_gobal_bcu_info()->set_clu_do >> DO8) & 0x01)
        {
            FAN_ON();//打开风扇    
            log_d("open");
        }
        else
        {
            FAN_OFF();//关闭风扇
            log_d("close");
        }
        return;
    }
    
    if( (sample_data.adc_sample_other_temp[BAT_P_TEMP] > get_bms_attr()->fan_open_temp) ||
        (sample_data.adc_sample_other_temp[BAT_N_TEMP] > get_bms_attr()->fan_open_temp) ||
        (sample_data.adc_sample_other_temp[LOAD_P_TEMP] > get_bms_attr()->fan_open_temp) ||
        (sample_data.adc_sample_other_temp[LOAD_N_TEMP] > get_bms_attr()->fan_open_temp))
    {
        if(++fan_open_cnt >= FAN_CTRL_TIME_5S)
        {
            fan_open_cnt = FAN_CTRL_TIME_5S;
            fan_close_cnt = 0;
            FAN_ON();//打开风扇
            g_fan_flag = true;            
        }

    }
    else if((sample_data.adc_sample_other_temp[BAT_P_TEMP] < get_bms_attr()->fan_close_temp) ||
        (sample_data.adc_sample_other_temp[BAT_N_TEMP] < get_bms_attr()->fan_close_temp) ||
        (sample_data.adc_sample_other_temp[LOAD_P_TEMP] < get_bms_attr()->fan_close_temp) ||
        (sample_data.adc_sample_other_temp[LOAD_N_TEMP] < get_bms_attr()->fan_close_temp))
    {
        if(++fan_close_cnt >= FAN_CTRL_TIME_5S)
        {
            fan_close_cnt = FAN_CTRL_TIME_5S;
            fan_open_cnt = 0;
            FAN_OFF();//关闭风扇
            g_fan_flag = false;            
        }            

    }
    else
    {
        ;       
    }

}

uint8_t get_fan_flag(void)
{
    return g_fan_flag;
}

/**
 * @brief        风扇调试接口
 * @param        [in] cmd
 * @param        [in] len
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
int32_t fan(char *cmd, uint8_t len)
{
   if (cmd == NULL || len == 0)
   {
       return -1;
   }
   char *para1 = strtok(NULL, " "); //解析第一个参数名称
   int32_t para2;
   char *para2_char = strtok(NULL, " ");
   if (NULL != para2_char)
   {
       para2 = atoi(para2_char);
   }
   else
   {
       return -1;
   }
   if (!strcmp(para1, "debug"))
   {
       if (1 == para2)
       {
           g_fan_debug_flag = true;
       }
       else
       {
           g_fan_debug_flag = false;
       }

   }
   else if (!strcmp(para1, "open"))
   {
       FAN_ON();//打开风扇
   }
   else if (!strcmp(para1, "close"))
   {
       FAN_OFF();//TO DO 关闭风扇
   }    
   
   return 0;

}
MSH_CMD_EXPORT(fan, <debug 0 1/open/close>);

