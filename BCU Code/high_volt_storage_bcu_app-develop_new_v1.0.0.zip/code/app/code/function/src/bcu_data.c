/**
 * @file     bcu_data.c
 * @brief    综合处理bmu采样数据
 * @company  sofarsolar
 * @author   
 * @note     综合所有采样模拟量
 * @version
 * @date     2023/4/27 初稿
 */
#include <stdlib.h>
#include "sdk.h"
#include "app_public.h"
#include "bcu_data.h"
#include "addressing_common.h"
#include "bmu_data.h"
#include "fault_manage.h"
#include "bms_state.h"
#include "relay_manage.h"
#include "data_store.h"
#include "sox.h"
#include "insulation_impedance_calc.h"
#include "public_flag.h"

#define NEG_POS_RELAY_DI_OK   (0x03)   // 根据实际di状态排序来调整TODO
static other_clu_data g_other_clu_data[MAX_CLU_NUM] = {0};
static gold_bcu_integration_data g_clu_integration = {0};
static bcu_data_unify_t g_bcu_data_info = {0};

/**
 * @brief                bcu簇间数据获取
 * @param                [in]bcu_num 0~9
 * @return               返回结果空
 * @retval               [out]const other_clu_data*
 */
const other_clu_data* get_cluster_bcu_data(uint8_t bcu_num)
{
    if (bcu_num >= MAX_CLU_NUM)
    {
        return NULL;
    }
    return (const other_clu_data*)&g_other_clu_data[bcu_num];
}

/**
 * @brief                本bcu数据 
 * @return               返回结果空
 * @retval               [out]const bcu_data_unify_t*
 */
const bcu_data_unify_t* get_bcu_info(void)
{
    return (const bcu_data_unify_t*)&g_bcu_data_info;
}

/**
 * @brief                簇间汇总数据 
 * @return               返回结果空
 * @retval               [out]const bcu_data_unify_t*
 */
const gold_bcu_integration_data* get_gobal_bcu_info(void)
{
    return (const gold_bcu_integration_data*)&g_clu_integration;
}

/**
 * @brief                bcu簇间数据设置
 * @param                [in]can_frame_data_t *
 * @return               返回结果空
 */
void cluster_bcu_data_set(can_frame_data_t *can_data)
{
    static uint32_t count_ms = 0;
    
    if (can_data == NULL)
    {
        return;
    }
    can_frame_id_u rx_frame_data = {can_data->id};
    if (rx_frame_data.bit.src_type != DEV_BROADCAST)
    {
        return;
    }
    
    if (rx_frame_data.bit.src_addr == ext_addressing_manage_addr_get()) //接收到相同地址的说明地址冲突
    {
        g_bcu_data_info.confilct_id_flag = true;
        count_ms = sdk_tick_get();
    }
    
    if(true == g_bcu_data_info.confilct_id_flag)    //恢复条件：连续5S没有接收到地址冲突
    {
        if (true == sdk_is_tick_over(count_ms, os_tick_from_millisecond(5000)))//
        {
            g_bcu_data_info.confilct_id_flag = false;
        }
    }
    
    uint8_t buff_id = rx_frame_data.bit.src_addr - GOLD_MIN_EX_CAN_NO_TYPE_ADDR;
    if (buff_id >= MAX_CLU_NUM)
    {
        return;
    }
    if (g_other_clu_data[buff_id].exist == 0)
    {
        g_other_clu_data[buff_id].exist = 1;
        g_clu_integration.clu_bcu_num++;
    }
    if (rx_frame_data.bit.fun_code == GOLD_FUNC_CLU_SUMMARY_CMD)
    {
        g_other_clu_data[buff_id].clu_volt = MAKE_WORD(can_data->data[0], can_data->data[1]);
        g_other_clu_data[buff_id].clu_curr = (int16_t)MAKE_WORD(can_data->data[2], can_data->data[3]) - 16000; // 偏移-1600A
        g_other_clu_data[buff_id].clu_soc = can_data->data[4];
        g_other_clu_data[buff_id].clu_soh = can_data->data[5];
        g_other_clu_data[buff_id].clu_di_stus = can_data->data[6];
        g_other_clu_data[buff_id].clu_do_stus = can_data->data[7];    
    }
    else if (rx_frame_data.bit.fun_code == GOLD_FUNC_CLU_CELL_SUMMARY_CMD)
    {
        g_other_clu_data[buff_id].clu_max_cell_volt = MAKE_WORD(can_data->data[0], can_data->data[1]);
        g_other_clu_data[buff_id].clu_max_cell_temp = (int8_t)can_data->data[2] - 40; // 偏移-40℃
        g_other_clu_data[buff_id].clu_max_cell_soc = can_data->data[3];
        g_other_clu_data[buff_id].clu_min_cell_volt = MAKE_WORD(can_data->data[4], can_data->data[5]);
        g_other_clu_data[buff_id].clu_min_cell_temp = (int8_t)can_data->data[6] - 40; // 偏移-40℃
        g_other_clu_data[buff_id].clu_min_cell_soc = can_data->data[7];
    }
    else if (rx_frame_data.bit.fun_code == GOLD_FUNC_CLU_ALM_SUMMARY_CMD)
    {
        if (can_data->data[0] == GOLD_SERIOUS_ALM_TYPE)
        {
            g_other_clu_data[buff_id].pro_warn[0] = can_data->data[1];
            g_other_clu_data[buff_id].pro_warn[1] = can_data->data[2];
            g_other_clu_data[buff_id].pro_warn[2] = can_data->data[3];
            g_other_clu_data[buff_id].pro_fault_deal = MAKE_WORD(can_data->data[5], can_data->data[4]);
            g_other_clu_data[buff_id].pro_fault_num = MAKE_WORD(can_data->data[7], can_data->data[6]);
        }
        else if(can_data->data[0] == GOLD_DEV_HARD_ALM_TYPE)
        {
            g_other_clu_data[buff_id].dev_fault[0] = can_data->data[1];
            g_other_clu_data[buff_id].dev_fault[1] = can_data->data[2];
            g_other_clu_data[buff_id].dev_fault[2] = can_data->data[3];
            g_other_clu_data[buff_id].dev_fault_deal = MAKE_WORD(can_data->data[5], can_data->data[4]);
            g_other_clu_data[buff_id].dev_fault_num = MAKE_WORD(can_data->data[7], can_data->data[6]);
        }
        // 剩下的轻微告警和一般告警就不记录了
    }
    else if (rx_frame_data.bit.fun_code == GOLD_FUNC_MAINTENANCE_CMD)
    {
        g_other_clu_data[buff_id].clu_maintenance_stus = can_data->data[0];
        g_other_clu_data[buff_id].clu_out_stus = can_data->data[1];
    }
}

/**
 * @brief                bcu 主控设置参数
 * @param                [in]can_frame_data_t *
 * @return               返回结果空
 */
void master_ctl_bcu_data_set(can_frame_data_t *can_data)
{
    if (can_data == NULL)
    {
        return;
    }
    can_frame_id_u rx_frame_data = {can_data->id};
    if (rx_frame_data.bit.src_type != DEV_BROADCAST || rx_frame_data.bit.src_addr == ext_addressing_manage_addr_get())
    {
        return;
    }
    if (rx_frame_data.bit.fun_code == GOLD_FUNC_MAS_CLU_CTL_CMD)
    {
        g_clu_integration.set_clu_volt_diff_state = can_data->data[0];
        g_clu_integration.set_clu_state = can_data->data[1];
        g_clu_integration.set_maintenance_state[0] = can_data->data[2];
        g_clu_integration.set_maintenance_state[1] = can_data->data[3];
        g_clu_integration.set_ins_state[0] = can_data->data[5];
        g_clu_integration.set_ins_state[1] = can_data->data[6];
    }
    else if (rx_frame_data.bit.fun_code == GOLD_FUNC_OUT_CLU_CTL_CMD)
    {
        g_clu_integration.set_out_clu_state = can_data->data[0];
        g_clu_integration.set_out_clu[0] = can_data->data[1];
        g_clu_integration.set_out_clu[1] = can_data->data[2];
        g_clu_integration.set_out_clu[2] = can_data->data[3];
        g_clu_integration.set_run_clu[0] = can_data->data[4];
        g_clu_integration.set_run_clu[1] = can_data->data[5];
        g_clu_integration.set_run_clu[2] = can_data->data[6];
    }
    else if (rx_frame_data.bit.fun_code == GOLD_FUNC_TEST_FORCE_DO_CMD)
    {
        g_clu_integration.set_clu_sw = 1;
        g_clu_integration.set_clu_do = can_data->data[0];
        sdk_dido_write(DO_9_RSV,(g_clu_integration.set_clu_do >> DO4) & 0x01);
    }
}

/**
 * @brief                bcu本簇数据填充
 * @return               返回结果空
 * @retval               [out]无
 * @warning              放在100ms任务，必须要调用后使用
 */
void cluster_bcu_data_fill(void)
{
    uint8_t bcu_mac_id = ext_addressing_manage_addr_get() - GOLD_MIN_EX_CAN_NO_TYPE_ADDR;

    if (bcu_mac_id >= MAX_CLU_NUM)
    {
        return;
    }
    const sample_data_t* p_bcu_sample_data = p_sample_data_get();
    const batt_clu_sox *p_sox_data = sox_data_get();
    const bmu_data_unify_t* p_bmu_data_unify = bmu_data_unify_get();
    const bcu_data_unify_t* p_bcu_info = get_bcu_info();

    const gold_warn_msg_t *warn_msg_reply = warn_msg_reply_get();
    gold_dev_warn_t dev_warn = warn_msg_reply->dev_warn;
    const gold_base_warn_t *base_warn = warn_msg_reply->base_warn;

    g_other_clu_data[bcu_mac_id].clu_volt               = p_bcu_sample_data->bus_volt / 100;
    g_other_clu_data[bcu_mac_id].clu_curr               = p_bcu_sample_data->sys_current / 100;
    g_other_clu_data[bcu_mac_id].clu_soc                = p_sox_data->batt_clu_display_soc;
    g_other_clu_data[bcu_mac_id].clu_soh                = p_sox_data->batt_clu_display_soh;
    g_other_clu_data[bcu_mac_id].clu_di_stus            = bcu_dido_info_get()->di_state.byte;
    g_other_clu_data[bcu_mac_id].clu_do_stus            = bcu_dido_info_get()->do_state.byte;
    g_other_clu_data[bcu_mac_id].clu_max_cell_volt      = p_bmu_data_unify->batmaxcellvolt;
    g_other_clu_data[bcu_mac_id].clu_max_cell_temp      = p_bmu_data_unify->batmaxcelltemp / 10;
    g_other_clu_data[bcu_mac_id].clu_max_cell_soc       = p_bmu_data_unify->bmu_cell_info.max_cell_soc[0];
    g_other_clu_data[bcu_mac_id].clu_min_cell_volt      = p_bmu_data_unify->batmincellvolt;
    g_other_clu_data[bcu_mac_id].clu_min_cell_temp      = p_bmu_data_unify->batmincelltemp / 10;
    g_other_clu_data[bcu_mac_id].clu_min_cell_soc       = p_bmu_data_unify->bmu_cell_info.min_cell_soc[0];
    g_other_clu_data[bcu_mac_id].pro_warn[0]            = base_warn[0].warn_byte0.byte;
    g_other_clu_data[bcu_mac_id].pro_warn[1]            = base_warn[0].warn_byte1.byte;
    g_other_clu_data[bcu_mac_id].pro_warn[2]            = base_warn[0].warn_byte2.byte;
    g_other_clu_data[bcu_mac_id].alm_warn[0]            = base_warn[1].warn_byte0.byte;
    g_other_clu_data[bcu_mac_id].alm_warn[1]            = base_warn[1].warn_byte1.byte;
    g_other_clu_data[bcu_mac_id].alm_warn[2]            = base_warn[1].warn_byte2.byte;
    g_other_clu_data[bcu_mac_id].tip_warn[0]            = base_warn[2].warn_byte0.byte;
    g_other_clu_data[bcu_mac_id].tip_warn[1]            = base_warn[2].warn_byte1.byte;
    g_other_clu_data[bcu_mac_id].tip_warn[2]            = base_warn[2].warn_byte2.byte;
    g_other_clu_data[bcu_mac_id].dev_fault[0]           = dev_warn.warn_byte0.byte;
    g_other_clu_data[bcu_mac_id].dev_fault[1]           = dev_warn.warn_byte1.byte;
    g_other_clu_data[bcu_mac_id].dev_fault[2]           = dev_warn.warn_byte2.byte;
    g_other_clu_data[bcu_mac_id].pro_fault_deal         = 0;
    g_other_clu_data[bcu_mac_id].pro_fault_num          = 0;
    g_other_clu_data[bcu_mac_id].dev_fault_deal         = 0;
    g_other_clu_data[bcu_mac_id].dev_fault_num          = 0;
    g_other_clu_data[bcu_mac_id].clu_maintenance_stus   = p_bcu_info->clu_bcu_maintenance_state;;
    g_other_clu_data[bcu_mac_id].clu_out_stus           = p_bcu_info->out_clu_state;
    g_other_clu_data[bcu_mac_id].exist                  = 1;
}

/**
 * @brief                bcu簇间综合数据
 * @return               返回结果空
 * @retval               [out]无
 * @warning              放在100ms任务，
 */
void cluster_bcu_data_proc(void)
{
    uint8_t start_flag = 0;
    cluster_bcu_data_fill();
    g_clu_integration.heap_curr = 0;
    
    for (uint8_t i = 0; i < MAX_CLU_NUM; i++)
    {
        if (g_other_clu_data[i].exist == 0)
        {
            continue;
        }
        if (start_flag == 0)
        {
            g_clu_integration.max_clu_volt = g_other_clu_data[i].clu_volt;
            g_clu_integration.min_clu_volt = g_other_clu_data[i].clu_volt;
            g_clu_integration.max_clu_curr = g_other_clu_data[i].clu_curr;
            g_clu_integration.min_clu_curr = g_other_clu_data[i].clu_curr;
            g_clu_integration.heap_curr = 0;
            g_clu_integration.parallel_state = 0;
            start_flag = 1;
        }

        g_clu_integration.heap_curr += g_other_clu_data[i].clu_curr;
        if ((g_other_clu_data[i].clu_di_stus & NEG_POS_RELAY_DI_OK) == NEG_POS_RELAY_DI_OK)
        {
            g_clu_integration.parallel_clu_volt = g_other_clu_data[i].clu_volt;
            g_clu_integration.parallel_state |= (1 << i);
        }
        if (g_other_clu_data[i].clu_volt > g_clu_integration.max_clu_volt)
        {
            g_clu_integration.max_clu_volt = g_other_clu_data[i].clu_volt;
        }
        if (g_other_clu_data[i].clu_volt < g_clu_integration.min_clu_volt)
        {
            g_clu_integration.min_clu_volt = g_other_clu_data[i].clu_volt;
        }
        if (g_other_clu_data[i].clu_curr > g_clu_integration.max_clu_curr)
        {
            g_clu_integration.max_clu_curr = g_other_clu_data[i].clu_curr;
        }
        if (g_other_clu_data[i].clu_curr < g_clu_integration.min_clu_curr)
        {
            g_clu_integration.min_clu_curr = g_other_clu_data[i].clu_curr;
        }
    }
    g_clu_integration.max_clu_volt_diff = g_clu_integration.max_clu_volt - g_clu_integration.min_clu_volt;
    g_clu_integration.max_clu_curr_diff = g_clu_integration.max_clu_curr - g_clu_integration.min_clu_curr;
}


/**
 * @brief                本bcu簇综合数据
 * @return               返回结果空
 * @retval               [out]无
 * @warning              放在100ms任务，
 */
void bcu_data_info_proc(void)
{
    uint8_t now_chg_enable = 0;
    uint8_t now_dsg_enable = 0;
    uint8_t now_fault_state = 0;
    
    const bmu_data_unify_t* p_bmu_data_unify =  bmu_data_unify_get();
    const fault_stat_data_t *p_fault_data = fault_chg_dsg_level_get();

    if(NULL == p_bmu_data_unify || p_fault_data == NULL)
    {
        g_bcu_data_info.chg_enable = 0;
        g_bcu_data_info.dsg_enable = 0;
        g_bcu_data_info.fault_state = 1;

        return ;
    }
    // 充放电使能
    if (PRE_SUCCESS != get_pre_charge_state() || BCU_STATE_RUN != bms_state_get_sys_sta())
    {
        now_chg_enable = 0;
        now_dsg_enable = 0;
    }
    else
    {
        if ((p_fault_data->max_charge_level > LEVEL2) && 
            ((p_bmu_data_unify->chg_disg_enable & 0xFF) == 0xAA))
        {
            now_chg_enable = 1;
        }
        if ((p_fault_data->max_discharge_level > LEVEL2) && 
            ((p_bmu_data_unify->chg_disg_enable & 0xFF00) == 0xAA00))
        {
            now_dsg_enable = 1;
        }
    }
    

    
    if((bms_state_get_sys_sta() == BCU_STATE_PF_ERROR)
        || (p_bmu_data_unify->req_cutoff_flag != 0)
        || (p_fault_data->max_charge_level <= LEVEL1)
        || (p_fault_data->max_discharge_level <= LEVEL1)
        )
    {
        now_fault_state = 1;
        now_chg_enable = 0;
        now_dsg_enable = 0;        
    }
    else
    {
        now_fault_state = 0;
    }
    //上位机控制继电器断开，禁止充放电使能
    if( (g_clu_integration.set_clu_sw) && 
    !((((g_clu_integration.set_clu_do >> DO1) & 0x01)) || ((g_clu_integration.set_clu_do >> DO3) & 0x01 )))
    {
        now_chg_enable = 0;
        now_dsg_enable = 0;
    }

    // 更新
    g_bcu_data_info.chg_enable = now_chg_enable;
    g_bcu_data_info.dsg_enable = now_dsg_enable;    
    g_bcu_data_info.fault_state = now_fault_state;
    
}

/**
 * @brief                bcu簇间综合数据初始化
 * @return               返回结果空
 * @retval               [out]无
 * @warning              放在100ms任务，
 */
void cluster_bcu_data_init(void)
{
    memset(&g_clu_integration, 0, sizeof(g_clu_integration));
    g_clu_integration.clu_bcu_num = 1;
    memset(g_other_clu_data, 0, sizeof(g_other_clu_data));  
    
    g_bcu_data_info.clu_mode = CLU_SINGLE;
}

/**
 * @brief                bcu数据更新
 * @return               返回结果空
 * @retval               [out]无
 * @warning              放在100ms任务，
 */
void bcu_data_proc(void)
{
    cluster_bcu_data_proc();
    bcu_data_info_proc();
}

/**
 * @brief                设置上下电状态
 * @param                [in]power_state_u 
 * @retval               [out]无
 */
void cluster_bcu_power_state_set(power_state_e state)
{
    static power_state_e last_state = CLU_POWER_INIT_STATE;
    g_clu_integration.set_power_state = state;
    if((last_state != state))
    {
        last_state = state;
        if((last_state == CLU_POWER_ON_SIGNAL)
            || (last_state == CLU_POWER_ON_ALL))
        {
            insulation_impedance_calc_start();
        }
        log_d("pwr state:%d\n",last_state);
    }
}

/**
 * @brief                 设置故障复归标志
* @param                  [in]flag 1 有效， 0：无效
 * @retval                [out]无
 */
void cluster_bcu_fault_recover_set(bool flag)
{
    g_clu_integration.set_fault_recover_flag = (uint8_t)flag;
}

/********************************************调试代码********************************************************/

//#define BCU_DATA_TEST 1 
//#if BCU_DATA_TEST


/**
 * @brief                Bcu 簇间数据汇总打印
 * @return               返回结果空
 * @warning              测试调试使用
 */
void bcu_data_summary_debug_printf(void)
{
    log_d("heapCurr= %d\n", g_clu_integration.heap_curr);          // 0.1A
    log_d("paraCluVolt= %d\n", g_clu_integration.parallel_clu_volt);          // 0.1V
    log_d("maxCluVolt_diff= %d\n", g_clu_integration.max_clu_volt_diff);          // 0.1V
    log_d("maxCluVolt= %d\n", g_clu_integration.max_clu_volt);          // 0.1V
    log_d("minCluVolt= %d\n", g_clu_integration.min_clu_volt);          // 0.1V
    log_d("maxCluCurr= %d\n", g_clu_integration.max_clu_curr);          // 0.1A, 偏差-1600A
    log_d("minCluCurr= %d\n", g_clu_integration.min_clu_curr);          // 0.1A, 偏差-1600A
    log_d("maxCluCurrDiff= %d\n", g_clu_integration.max_clu_curr_diff);          // 0.1A
    log_d("parallelSta= %x\n", g_clu_integration.parallel_state);          // bit0~bit9:表示并入情况， 1并入，0断开
    log_d("cluBcuNum= %d\n", g_clu_integration.clu_bcu_num);          // bcu的个数
    log_d("setPowerSta= %x\n", g_clu_integration.set_power_state);          // cmu设置上下电状态 
    log_d("setFaultRecover= %x\n", g_clu_integration.set_fault_recover_flag);          // 0x55 表示故障复归有效（在主控正常下电成功/正常下电失败/故障下电后，可通过此指令进行尝试重新上高压）
    log_d("setCluVoltDiffSta= %x\n", g_clu_integration.set_clu_volt_diff_state);           // 0：默认状态 1：10V 以下  2：10V~20V  3：20V 以上  4：上电完成（所有簇主控上传上电完成后为 4）故障复归时清除
    log_d("setCluSta= %x\n", g_clu_integration.set_clu_state);          
    log_d("setMaintenanceSta[2]= %x %x\n", g_clu_integration.set_maintenance_state[0], g_clu_integration.set_maintenance_state[1]);           
    log_d("setInsSta[2]= %x,%x\n", g_clu_integration.set_ins_state[0], g_clu_integration.set_ins_state[1]);          
    log_d("setOutCluSta= %x\n", g_clu_integration.set_out_clu_state);           // 0:无操作  1:允许退簇  2:禁止退簇 3:允许并簇  4:禁止并簇  5:故障下电
    log_d("setOutClu[3]= %d,%d,%d\n", g_clu_integration.set_out_clu[0], g_clu_integration.set_out_clu[1], g_clu_integration.set_out_clu[2]);           // [0]Bit0~7：BCM#1~#8  [1]Bit0~7：BCM#9~#16  （1：退簇 0：不操作）
    log_d("setRunClu[3]= %d,%d,%d\n", g_clu_integration.set_run_clu[0], g_clu_integration.set_run_clu[1], g_clu_integration.set_run_clu[2]);           // [0]Bit0~7：BCM#1~#8  [1]Bit0~7：BCM#9~#16  （1：使能 0：不使能）
    log_d("setCluSw= %d\n", g_clu_integration.set_clu_sw);
    log_d("setCluDo= %d\n", g_clu_integration.set_clu_do);
    log_d("setCluClock= %d\n", g_clu_integration.set_clu_clock);
    log_d("bcu_info: chg_en:%d\tdsg_en:%d\tfault_state:%d\n",g_bcu_data_info.chg_enable,g_bcu_data_info.dsg_enable,g_bcu_data_info.fault_state);
}

/**
 * @brief                Bcu 簇间数据打印
 * @return               返回结果空
 * @warning              测试调试使用
 */
void bcu_data_debug_printf(uint8_t i)
{
    log_d("selfno:%d\n",ext_addressing_manage_addr_get() - GOLD_MIN_EX_CAN_NO_TYPE_ADDR);
    log_d("read bcuno:%d\n",i);
    log_d("volt:%d\n",g_other_clu_data[i].clu_volt);// 0.1V
    log_d("curr:%d\n",g_other_clu_data[i].clu_curr);// 0.1A
    log_d("soc:%d\n",g_other_clu_data[i].clu_soc);
    log_d("soh:%d\n",g_other_clu_data[i].clu_soh);
    log_d("di:%d\n",g_other_clu_data[i].clu_di_stus);
    log_d("do:%d\n",g_other_clu_data[i].clu_do_stus);
    log_d("max_cell_volt:%d\n",g_other_clu_data[i].clu_max_cell_volt);
    log_d("max_cell_temp:%d\n",g_other_clu_data[i].clu_max_cell_temp);
    log_d("max_cell_soc:%d\n",g_other_clu_data[i].clu_max_cell_soc);
    log_d("min_cell_volt:%d\n",g_other_clu_data[i].clu_min_cell_volt);
    log_d("min_cell_temp:%d\n",g_other_clu_data[i].clu_min_cell_temp);
    log_d("min_cell_soc:%d\n",g_other_clu_data[i].clu_min_cell_soc);
    log_d("pro_warn[0]:%d\n",g_other_clu_data[i].pro_warn[0]);
    log_d("pro_warn[1]:%d\n",g_other_clu_data[i].pro_warn[1]);
    log_d("pro_warn[2]:%d\n",g_other_clu_data[i].pro_warn[2]);
    log_d("dev_fault[0]:%d\n",g_other_clu_data[i].dev_fault[0]);
    log_d("dev_fault[1]:%d\n",g_other_clu_data[i].dev_fault[1]);
    log_d("dev_fault[2]:%d\n",g_other_clu_data[i].dev_fault[2]);
    log_d("pro_fault_deal:%d\n",g_other_clu_data[i].pro_fault_deal);
    log_d("pro_fault_num:%d\n",g_other_clu_data[i].pro_fault_num);
    log_d("dev_fault_deal:%d\n",g_other_clu_data[i].dev_fault_deal);
    log_d("dev_fault_num:%d\n",g_other_clu_data[i].dev_fault_num);
    log_d("clu_maintenance_stus:%d\n",g_other_clu_data[i].clu_maintenance_stus);
    log_d("clu_out_stus:%d\n",g_other_clu_data[i].clu_out_stus);
    log_d("exist:%d\n",g_other_clu_data[i].exist);
    
}

/**
 * @brief        sample_debug功能样例
 * @param        cmd 功能参数
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
static int clu_data(int argc, char *argv[])
{
    if (argc < 2)
    {
        log_d("cluBcuParaErr\n");
        return SF_ERR_PARA;
    }

    if (!strcmp(argv[1], "sum"))    //发送汇总后的数据
    {
        bcu_data_summary_debug_printf();
    }
    else if (!strcmp(argv[1], "print"))    //发送收集到的信息
    {
        uint8_t operation = strtol(argv[2], NULL,16); 
        
        if(operation >= MAX_CLU_NUM)
        {
            log_d("cluBcuNumErr\n");
        }
        else
        {
            bcu_data_debug_printf(operation);
        }
    }
    
    return SF_OK; 
}
MSH_CMD_EXPORT(clu_data, <sum/print 0-9>);
//#endif

