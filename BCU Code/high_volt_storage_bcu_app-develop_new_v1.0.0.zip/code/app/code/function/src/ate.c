/**
 * @file     ate.c
 * @brief    生产装备ate测试流程源文件
 * @company  sofarsolar
 * @author   刘吕从
 * @note     
 * @version
 * @date     2023/7/1 初稿
 */
 
#include "ate.h"
#include <string.h>
#include "sdk.h"

#include "app_public.h"

#include "auto_addressing.h"
#include "led.h"
#include "public_flag.h"
#include "fault_manage.h"
#include "hal_can.h"
#include "sdk_can.h"
#include "sdk_dido.h"

#include "data_store.h"
#include "insulation_impedance_calc.h"

#if ATE_SHELL_DEBUG_FALG
static uint8_t g_ate_shell_debug_flag = ATE_CLR;
#endif

#define ATE_DELAY_TIME 600 //60s 基于100ms任务
#define ATE_SINGLE_CONTROL_DWORD_LEN  (((ATE_SINGLE_CTL_NUM - ATE_SINGLE_CTL_START) * 2 + 31) / 32)
#define ATE_MULTIPLE_DWORD_LEN  (ATE_CTL_TYPE_NUM - ATE_MUL_CTL_START)

#define ID_OUT_VALID()      sdk_dido_write(DO_3_POWER_5V_OUT, 1)
#define ID_OUT_INVALID()    sdk_dido_write(DO_3_POWER_5V_OUT, 0)

// 控制处理函数
typedef bool(*ctl_deal_callback)(void);

typedef struct
{
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t func_flash_format_test : 2;    // flash格式化请求
            uint8_t func_force_sleep_test : 2;     // 休眠请求
            uint8_t func_iso_test : 2;             // 绝缘检测测试请求
            uint8_t func_ext_wdt_disable_test : 2; // 外部看门狗失能请求
        } bits;
    } setbyte0;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t func_inner_addr_io_test : 2; // 簇内编址IO测试请求
            uint8_t func_can_com_test : 2;       // can通讯测试请求
            uint8_t func_485_com_test : 2;       // 485通讯测试请求
            uint8_t func_do_ctl_test : 2;        // DO控制测试请求
        } bits;
    } setbyte1;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t func_clu_addr_io_test : 2; // 簇间编址IO测试请求
            uint8_t rsv2 : 2;
            uint8_t rsv3 : 2;
            uint8_t rsv4 : 2;
        } bits;
    } setbyte2;
} func_item_t;

typedef struct
{
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t do1 : 2;
            uint8_t do2 : 2;
            uint8_t do3 : 2;
            uint8_t do4 : 2;
        } bits;
    } setbyte0;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t do5 : 2;
            uint8_t do6 : 2;
            uint8_t do7 : 2;
            uint8_t do8 : 2;
        } bits;
    } setbyte1;
    
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t pwr_5v_out : 2;
            uint8_t pwr_12v_out : 2;
            uint8_t idm_op : 2;
            uint8_t rsv3 : 2;
        } bits;
    } setbyte2;
    
} ate_ctl_t;

typedef struct
{
    ate_ctl_t ate_ctl;
    func_item_t  func_sw;
} ate_control_t;

typedef union
{
    uint8_t set_byte;
    struct
    {
        uint8_t ageing_mode : 1;    // 老化模式
        uint8_t cali_parm_mode : 1; // 参数设置模式
        uint8_t auto_test_mode : 1; // ATE测试
        uint8_t force_ctl_mode : 1; // 强制控制模式
        uint8_t res : 4;
    } set_bit;
} special_mode_u;

typedef union
{
    uint8_t set_byte;
    struct
    {
        uint8_t test1_finish : 1;    // T1完成标志
        uint8_t aging_finish : 1;    // 老化完成标志
        uint8_t test2_finish : 1;    // T2完成标志
        uint8_t package_test_finish : 1; // 包装测试完成标志
        uint8_t res : 4;            // 保留位
    } set_bit;
} production_step_flag_u;

static ate_control_t g_ate_control = { 0 };// 控制ATE指令
static production_step_flag_u g_product_finish_flag = { 0 };// 产测完成标志
static special_mode_u g_special_mode = { 0 };// ATE模式状态
static special_mode_u g_last_special_mode = { 0 };// 上一次ATE模式状态
static uint16_t g_mode_over_timer[SPECIAL_MODE_NUM] = {0};
static uint8_t g_ate_test_result[ATE_TEST_RESULT_NUM] = {0};



/**
* @brief        ate 设置(can命令设置)
* @param        [in]ate_ctl_type_e
* @param        [in]ate_ctl_state_e
* @warning      无
*/
void ate_ctl_can_set(ate_ctl_type_e type, uint8_t ctl_val)
{
    if ((0 == g_special_mode.set_bit.auto_test_mode) ||
        (type >= ATE_CTL_TYPE_NUM))
    {
        return; 
    }
    switch ((uint8_t)type)
    {
        case ATE_FUNC_SW_CTL_1:
            g_ate_control.func_sw.setbyte0.byte = ctl_val;
            break;
        case ATE_FUNC_SW_CTL_2:
            g_ate_control.func_sw.setbyte1.byte = ctl_val;
            break;
        case ATE_FUNC_SW_CTL_3:
            g_ate_control.func_sw.setbyte2.byte = ctl_val;
            break;
        case ATE_CTL_ITEM_1:
            g_ate_control.ate_ctl.setbyte0.byte = ctl_val;
            break;
        case ATE_CTL_ITEM_2:
            g_ate_control.ate_ctl.setbyte1.byte = ctl_val;
            break;
        case ATE_CTL_ITEM_3:
            g_ate_control.ate_ctl.setbyte2.byte = ctl_val;
            break;
        default:
            break;
    }
}

/**
* @brief        ate 获取DO设置(can命令设置)
* @param        [in]ate_ctl_type_e
* @param        [in]ate_ctl_state_e
* @warning      无
*/
uint8_t ate_ctl_can_get(ate_ctl_type_e type)
{
    if (type >= ATE_CTL_TYPE_NUM)
    {
        return ATE_NO_CTL_STATE; 
    }
    uint8_t data = ATE_NO_CTL_STATE;
    switch ((uint8_t)type)
    {
        case ATE_FUNC_SW_CTL_1:
            data = g_ate_control.func_sw.setbyte0.byte;
            break;
        case ATE_FUNC_SW_CTL_2:
            data = g_ate_control.func_sw.setbyte1.byte;
            break;
        case ATE_FUNC_SW_CTL_3:
            data = g_ate_control.func_sw.setbyte2.byte;
            break;
        case ATE_CTL_ITEM_1:
            data = g_ate_control.ate_ctl.setbyte0.byte;
            break;
        case ATE_CTL_ITEM_2:
            data = g_ate_control.ate_ctl.setbyte1.byte;
            break;
        case ATE_CTL_ITEM_3:
            data = g_ate_control.ate_ctl.setbyte2.byte;
            break;
        default:
            break;
    }
    return data;
}

/**
* @brief        返回测试结果
* @param        [in]func_id
* @warning      无
*/
uint8_t get_ate_test_func_result(uint8_t func_id)
{
    if(func_id >= ATE_TEST_RESULT_NUM)
    {
        return ATE_CLOSE_CTL_STATE;
    }
    
    if(true == g_ate_test_result[func_id])
    {
        return ATE_OPEN_CTL_STATE;
    }

    return ATE_CLOSE_CTL_STATE;
}

/**
 * @brief        can测试
 * @param
 * @param
 * @warning      无
 */
#define RSV_CAN 1
#define TEST_CAN0_ID 0x1062ff01
#define TEST_CAN1_ID 0x1063ff02
void ate_can_com_test(void)
{
    static uint8_t step = 0; // 测试步骤
    static uint8_t can1_tx_result, can1_rx_result = 0;
    sdk_can_cfg_t can_cfg =
        {
            .baud = SDK_CAN_BAUD_250K,
            .mode = SDK_CAN_MODE_NORMAL,
        };

    sdk_can_frame_t txmsg = {0};
    sdk_can_frame_t rxmsg = {0};
    txmsg.hdr = -1;
    txmsg.ide = HAL_CAN_EXTID;
    txmsg.rtr = HAL_CAN_DTR;   // 数据帧
    txmsg.len = 8;             // 数据长度为 8

    // ate测试将两路can接在一起
    switch (step)
    {
        case 0:
            sdk_can_open(RSV_CAN); // 打开预留的can
            sdk_can_setup(RSV_CAN, &can_cfg);

            step++;
            break;

        case 1:
            for (uint8_t i = 0; i < 5; i++)
            {
                txmsg.id = TEST_CAN1_ID;
                sdk_can_write(RSV_CAN, &txmsg, 1);
                txmsg.id = TEST_CAN0_ID;
                sdk_can_write(SDK_INTERNAL_CAN_PORT, &txmsg, 1);
                os_delay(TICK_1MS);
                if (0 < sdk_can_read(RSV_CAN, &rxmsg, 1, 0))
                {
                    if ((rxmsg.id & 0xffffff00) == (TEST_CAN0_ID & 0xffffff00))
                    {
                        can1_rx_result = true;
                    }
                    memset(&rxmsg, 0, sizeof(sdk_can_frame_t));
                }
                if (0 < sdk_can_read(SDK_INTERNAL_CAN_PORT, &rxmsg, 1, 0))
                {
                    if ((rxmsg.id & 0xffffff00) == (TEST_CAN1_ID & 0xffffff00))
                    {
                        can1_tx_result = true;
                    }
                    memset(&rxmsg, 0, sizeof(sdk_can_frame_t));
                }

                if ((true == can1_rx_result) && (true == can1_tx_result))
                {
                    step++;
                    break;
                }
            }
            
            break;

        case 2:
            step = 0;
            g_ate_control.func_sw.setbyte1.bits.func_can_com_test = ATE_DEFAULT_CLOSE_STATE;
            g_ate_test_result[ATE_CAN0_TEST_RESULT] = true;
            g_ate_test_result[ATE_CAN1_TEST_RESULT] = true;
            // log_e("[ate]can test success...\n");
            break;

        default:
            break;
    }
}

/*
**
* @brief        do/di组1测试
* @param        
* @param        
* @warning      无
*/
#define FAILED_TIME   5
void ate_dido_group_1_test(void)
{
    static uint8_t step = 0;    //测试步骤  
    static uint8_t fail_cnt = 0; //重试次数    
    
    // ate测试将相关的di2、do1连接在一起
    switch(step)
    {
        case 0: 
            sdk_dido_write(DO_6_POS_RELAY, 0);
            step++;
            break;
        
        case 1: 
            if(true == sdk_dido_read(DI_5_AUXILIARY_POWER_SWITCH))
            {
                step++;
                sdk_dido_write(DO_6_POS_RELAY, 1);
            }    
            else
            {
                step = 0;
                if(++fail_cnt > FAILED_TIME)
                {
                    step = 3;  
                }                
            }
            
            break;
        
        case 2: 
            if(false == sdk_dido_read(DI_5_AUXILIARY_POWER_SWITCH))
            {
                step++;
            }        
            else
            {
                step = 0;
                if(++fail_cnt > FAILED_TIME)
                {
                    step = 3;  
                }                  
            }
            break;
            
        case 3:
            if(fail_cnt  <= FAILED_TIME)
            {
                g_ate_test_result[ATE_DO1_TEST_RESULT] = true;
            }
            else
            {
                fail_cnt = 0;
                step = 0;
                g_ate_test_result[ATE_DO1_TEST_RESULT] = false;
            }            
            
            break;   
            
        default:
            break;
    }
}

/*
**
* @brief        do/di组2测试
* @param        
* @param        
* @warning      无
*/
void ate_dido_group_2_test(void)
{
    static uint8_t step = 0;    //测试步骤  
    static uint8_t fail_cnt = 0; //重试次数    
    
    // ate测试将相关的di4、do2连接在一起
    switch(step)
    {
        case 0: 
            sdk_dido_write(DO_7_PRE_RELAY, 0);
            step++;
            break;
        
        case 1: 
            if(true == sdk_dido_read(DI_7_EMERGENCY_STOP))
            {
                step++;
                sdk_dido_write(DO_7_PRE_RELAY, 1);
            }    
            else
            {
                step = 0;
                if(++fail_cnt > FAILED_TIME)
                {
                    step = 3;  
                }                
            }
            
            break;
        
        case 2: 
            if(false == sdk_dido_read(DI_7_EMERGENCY_STOP))
            {
                step++;
            }        
            else
            {
                step = 0;
                if(++fail_cnt > FAILED_TIME)
                {
                    step = 3;  
                }                  
            }
            break;
            
        case 3:

            
            if(fail_cnt  <= FAILED_TIME)
            {
                g_ate_test_result[ATE_DO2_TEST_RESULT] = true;
            }
            else
            {
                fail_cnt = 0;
                step = 0;
                g_ate_test_result[ATE_DO2_TEST_RESULT] = false;
            }            
            
            break;        

        default:
            break;
    }
}

/*
**
* @brief        do/di组3测试
* @param        
* @param        
* @warning      无
*/
void ate_dido_group_3_test(void)
{
    static uint8_t step = 0;    //测试步骤  
    static uint8_t fail_cnt = 0; //重试次数    
    
    // ate测试将相关的di6、do3连接在一起
    switch(step)
    {
        case 0: 
            sdk_dido_write(DO_8_NEG_RELAY, 0);
            step++;
            break;
        
        case 1: 
            if(true == sdk_dido_read(DI_9_VOLT_ISOLATOR))
            {
                step++;
                sdk_dido_write(DO_8_NEG_RELAY, 1);
            }    
            else
            {
                step = 0;
                if(++fail_cnt > FAILED_TIME)
                {
                    step = 3;  
                }                
            }
            
            break;
        
        case 2: 
            if(false == sdk_dido_read(DI_9_VOLT_ISOLATOR))
            {
                step++;
            }        
            else
            {
                step = 0;
                if(++fail_cnt > FAILED_TIME)
                {
                    step = 3;  
                }                  
            }
            break;
            
        case 3:
            
            if(fail_cnt  <= FAILED_TIME)
            {
                g_ate_test_result[ATE_DO3_TEST_RESULT] = true;
            }
            else
            {
                fail_cnt = 0;
                step = 0;
                g_ate_test_result[ATE_DO3_TEST_RESULT] = false;
            }            
            
            break;
                
        default:
            break;
    }
}

/*
**
* @brief        do/di组4测试
* @param        
* @param        
* @warning      无
*/
void ate_dido_group_4_test(void)
{
    static uint8_t step = 0;    //测试步骤  
    static uint8_t fail_cnt = 0; //重试次数    
    
    // ate测试将相关的di1、do4连接在一起
    switch(step)
    {
        case 0: 
            sdk_dido_write(DO_9_RSV, 0);
            step++;
            break;
        
        case 1: 
            if(false == sdk_dido_read(DI_4_POS_RELAY))
            {
                step++;
                sdk_dido_write(DO_9_RSV, 1);
            }    
            else
            {
                step = 0;
                if(++fail_cnt > FAILED_TIME)
                {
                    step = 3;  
                }                
            }
            
            break;
        
        case 2: 
            if(true == sdk_dido_read(DI_4_POS_RELAY))
            {
                step++;
            }        
            else
            {
                step = 0;
                if(++fail_cnt > FAILED_TIME)
                {
                    step = 3;  
                }                  
            }
            break;
            
        case 3:

            
            if(fail_cnt  <= FAILED_TIME)
            {
                g_ate_test_result[ATE_DO4_TEST_RESULT] = true;
            }
            else
            {
                fail_cnt = 0;
                step = 0;
                g_ate_test_result[ATE_DO4_TEST_RESULT] = false;
            }            
            
            break;        

        default:
            break;
    }
}

/*
**
* @brief        do/di组5测试
* @param        
* @param        
* @warning      无
*/
void ate_dido_group_5_test(void)
{
    static uint8_t step = 0;    //测试步骤  
    static uint8_t fail_cnt = 0; //重试次数    
    
    // ate测试将相关的di3、do5连接在一起
    switch(step)
    {
        case 0: 
            led_display_mode(USER_NOR_LED, LED_DISPLAY_MODE_ALWAYS_CLOSE);
            step++;
            break;
        
        case 1: 
            if(false == sdk_dido_read(DI_6_NEG_RELAY))
            {
                step++;
                led_display_mode(USER_NOR_LED, LED_DISPLAY_MODE_ALWAYS_ON);
            }    
            else
            {
                step = 0;
                if(++fail_cnt > FAILED_TIME)
                {
                    step = 3;  
                }                
            }
            
            break;
        
        case 2: 
            if(true == sdk_dido_read(DI_6_NEG_RELAY))
            {
                step++;
            }        
            else
            {
                step = 0;
                if(++fail_cnt > FAILED_TIME)
                {
                    step = 3;  
                }                  
            }
            break;
            
        case 3:

            
            if(fail_cnt  <= FAILED_TIME)
            {
                g_ate_test_result[ATE_DO5_TEST_RESULT] = true;
            }
            else
            {
                fail_cnt = 0;
                step = 0;
                g_ate_test_result[ATE_DO5_TEST_RESULT] = false;
            }            
            
            break;        

        default:
            break;
    }
}


/*
**
* @brief        do/di组6测试
* @param        
* @param        
* @warning      无
*/
void ate_dido_group_6_test(void)
{
    static uint8_t step = 0;    //测试步骤  
    static uint8_t fail_cnt = 0; //重试次数    
    
    // ate测试将相关的di5、do6连接在一起
    switch(step)
    {
        case 0: 
            led_display_mode(USER_ERR_LED, LED_DISPLAY_MODE_ALWAYS_CLOSE);
            step++;
            break;
        
        case 1: 
            if(false == sdk_dido_read(DI_8_CMU_FAULT))
            {
                step++;
                led_display_mode(USER_ERR_LED, LED_DISPLAY_MODE_ALWAYS_ON);
            }    
            else
            {
                step = 0;
                if(++fail_cnt > FAILED_TIME)
                {
                    step = 3;  
                }                
            }
            
            break;
        
        case 2: 
            if(true == sdk_dido_read(DI_8_CMU_FAULT))
            {
                step++;
            }        
            else
            {
                step = 0;
                if(++fail_cnt > FAILED_TIME)
                {
                    step = 3;  
                }                  
            }
            break;
            
        case 3:

            
            if(fail_cnt  <= FAILED_TIME)
            {
                g_ate_test_result[ATE_DO6_TEST_RESULT] = true;
            }
            else
            {
                fail_cnt = 0;
                step = 0;
                g_ate_test_result[ATE_DO6_TEST_RESULT] = false;
            }            
            
            break;        

        default:
            break;
    }
}

/*
**
* @brief        do/di组7测试
* @param        
* @param        
* @warning      无
*/
void ate_dido_group_7_test(void)
{
    static uint8_t step = 0;    //测试步骤  
    static uint8_t fail_cnt = 0; //重试次数    
    
    // ate测试将相关的di7、do7连接在一起
    switch(step)
    {
        case 0: 
            sdk_dido_write(DO_10_AUXILIARY_POWER_SWITCH,0);
            step++;
            break;
        
        case 1: 
            if(true == sdk_dido_read(DI_10_RSV))
            {
                step++;
                sdk_dido_write(DO_10_AUXILIARY_POWER_SWITCH,1);
            }    
            else
            {
                step = 0;
                if(++fail_cnt > FAILED_TIME)
                {
                    step = 3;  
                }                
            }
            
            break;
        
        case 2: 
            if(false == sdk_dido_read(DI_10_RSV))
            {
                step++;
            }        
            else
            {
                step = 0;
                if(++fail_cnt > FAILED_TIME)
                {
                    step = 3;  
                }                  
            }
            break;
            
        case 3:

            
            if(fail_cnt  <= FAILED_TIME)
            {
                g_ate_test_result[ATE_DO7_TEST_RESULT] = true;
            }
            else
            {
                fail_cnt = 0;
                step = 0;
                g_ate_test_result[ATE_DO7_TEST_RESULT] = false;
            }            
            
            break;        

        default:
            break;
    }
}


/*
**
* @brief        do/di组8测试
* @param        
* @param        
* @warning      无
*/
void ate_dido_group_8_test(void)
{
    static uint8_t step = 0;    //测试步骤  
    static uint8_t fail_cnt = 0; //重试次数    
    
    // ate测试将相关的di8、do8连接在一起
    switch(step)
    {
        case 0: 
            sdk_dido_write(DO_11_FAN_CTRL,0);
            step++;
            break;
        
        case 1: 
            if(true == sdk_dido_read(DI_11_RSV))
            {
                step++;
                sdk_dido_write(DO_11_FAN_CTRL,1);
            }    
            else
            {
                step = 0;
                if(++fail_cnt > FAILED_TIME)
                {
                    step = 3;  
                }                
            }
            
            break;
        
        case 2: 
            if(false == sdk_dido_read(DI_11_RSV))
            {
                step++;
            }        
            else
            {
                step = 0;
                if(++fail_cnt > FAILED_TIME)
                {
                    step = 3;  
                }                  
            }
            break;
            
        case 3:

            
            if(fail_cnt  <= FAILED_TIME)
            {
                g_ate_test_result[ATE_DO8_TEST_RESULT] = true;
            }
            else
            {
                fail_cnt = 0;
                step = 0;
                g_ate_test_result[ATE_DO8_TEST_RESULT] = false;
            }            
            
            break;        

        default:
            break;
    }
}


/*
**
* @brief        簇间编址io测试
* @param        
* @param        
* @warning      无
*/
void ate_clu_addr_io_test(void)
{
    static uint8_t step = 0;    //测试步骤  
    static uint8_t fail_cnt = 0; //重试次数    
    
    // ate测试将相关的di6、do3连接在一起
    switch(step)
    {
        case 0: 
            sdk_dido_write(DO_3_CLUSTER_ADDR, 0);
            step++;
            break;
        
        case 1: 
            if(false == sdk_dido_read(DI_2_CLUSTER_ADDR))
            {
                step++;
                sdk_dido_write(DO_3_CLUSTER_ADDR, 1);
            }    
            else
            {
                step = 0;
                if(++fail_cnt > FAILED_TIME)
                {
                    step = 3;  
                }                
            }
            
            break;
        
        case 2: 
            if(true == sdk_dido_read(DI_2_CLUSTER_ADDR))
            {
                step++;
            }        
            else
            {
                step = 0;
                if(++fail_cnt > FAILED_TIME)
                {
                    step = 3;  
                }                  
            }
            break;
            
        case 3:
            
            if(fail_cnt  <= FAILED_TIME)
            {
                g_ate_test_result[ATE_CLU_ADDR_IO_TEST_RESULT] = true;
            }
            else
            {
                fail_cnt = 0;
                step = 0;
                g_ate_test_result[ATE_CLU_ADDR_IO_TEST_RESULT] = false;
            }
            
            break;

        default:
            break;
    }    
}

/**
* @brief        测试编址io功能
* @param        
* @param        
* @warning      无
*/
void addr_io_test(void)
{
    static uint8_t step = 0;    //测试步骤
    static uint8_t fail_cnt = 0; //重试次数
    
    //产测的时候编址io对接，分别把io设成输入/输出，拉高/拉低然后检测电平状态是否正常
    switch(step)
    {
        case 0:
            sdk_dido_config(IO_1_BAT_PACK_OUT1,SDK_GPIO_INPUT);
            sdk_dido_config(IO_2_BAT_PACK_OUT2,SDK_GPIO_OUTPUT);
            sdk_dido_write(DO_5_INNER_ADDR_2,1);
            step++;
            break;

        case 1:
            if(true == sdk_dido_read(DI_12))
            {
                step++;                
                sdk_dido_write(DO_5_INNER_ADDR_2,0);
            }
            else
            {
                step= 0;
                if(++fail_cnt > FAILED_TIME)
                {
                    step = 5;  
                }
                
            }
            break;
        
        case 2:
            if(false == sdk_dido_read(DI_12))
            {
                step++;                
                sdk_dido_config(IO_2_BAT_PACK_OUT2,SDK_GPIO_INPUT);
                sdk_dido_config(IO_1_BAT_PACK_OUT1,SDK_GPIO_OUTPUT);
                sdk_dido_write(DO_4_INNER_ADDR_1,1);
            }
            else
            {
                step= 0;
                if(++fail_cnt > FAILED_TIME)
                {
                    step = 5;  
                }
                
            }    
            break;
            
        case 3:
            if(true == sdk_dido_read(DI_13))
            {
                step++;                
                sdk_dido_write(DO_4_INNER_ADDR_1,0);
            }
            else
            {
                step= 0;
                if(++fail_cnt > FAILED_TIME)
                {
                    step = 5;  
                }
                
            }    
            break;
       
        case 4:
            if(false == sdk_dido_read(DI_13))
            {
                step++;                
                g_ate_test_result[ATE_INNER_ADDR_IO_TEST_RESULT] = true;
            }
            else
            {
                step= 0;
                if(++fail_cnt > FAILED_TIME)
                {
                    step = 5;  
                }
                
            }    
            break;
            
        case 5:
            step = 0;  
            fail_cnt = 0;
            g_ate_control.func_sw.setbyte1.bits.func_inner_addr_io_test = ATE_DEFAULT_CLOSE_STATE;
            
            break;
        
        default:            
            break;
    }

}

/**
 * @brief        功能开关1任务处理
 * @param
 * @return
 */
static bool ate_func_sw1_control_deal(void)
{
    if (g_ate_control.func_sw.setbyte0.bits.func_flash_format_test == ATE_CTL_START_STATE) // flash格式化请求
    {
        g_ate_test_result[ATE_FLASH_FORMAT_TEST_RESULT] = true;
    }

    if (g_ate_control.func_sw.setbyte0.bits.func_iso_test == ATE_CTL_START_STATE) // 绝缘检测测试请求
    {
        insulation_impedance_calc_start();
        g_ate_control.func_sw.setbyte0.bits.func_iso_test = ATE_DEFAULT_CLOSE_STATE;
    }

    if (g_ate_control.func_sw.setbyte0.bits.func_ext_wdt_disable_test == ATE_CTL_START_STATE) // 外部看门狗失能请求
    {
        g_ate_test_result[ATE_EXT_WDT_TEST_RESULT] = true;
    }

    return true;
}

/**
 * @brief        功能开关2任务处理
 * @param
 * @return
 */
static bool ate_func_sw2_control_deal(void)
{
    if (g_ate_control.func_sw.setbyte1.bits.func_inner_addr_io_test == ATE_CTL_START_STATE) // 簇内编址io请求
    {
        addr_io_test();
    }

    if (g_ate_control.func_sw.setbyte1.bits.func_can_com_test == ATE_CTL_START_STATE) // can通讯测试请求
    {
        g_ate_test_result[ATE_CAN2_TEST_RESULT] = true;
        ate_can_com_test();
    }

    if (g_ate_control.func_sw.setbyte1.bits.func_485_com_test == ATE_CTL_START_STATE) // 485通讯测试请求
    {
        g_ate_test_result[ATE_485_TEST_RESULT] = true;
    }
    
    if (g_ate_control.func_sw.setbyte1.bits.func_do_ctl_test == ATE_CTL_START_STATE)
    {
        ate_dido_group_1_test();
        ate_dido_group_2_test();
        ate_dido_group_3_test();
        ate_dido_group_4_test();
        ate_dido_group_5_test();
        ate_dido_group_6_test();
        ate_dido_group_7_test();
        ate_dido_group_8_test();     
    }
    
    return true;
}

/**
 * @brief        功能开关2任务处理
 * @param
 * @return
 */
static bool ate_func_sw3_control_deal(void)
{
    if (g_ate_control.func_sw.setbyte2.bits.func_clu_addr_io_test == ATE_CTL_START_STATE) // 簇间编址IO测试请求
    {
        ate_clu_addr_io_test();
    }
    
    return true;
}




/**
 * @brief        dido控制任务处理
 * @param        [in]ate_ctl_type_e
 * @return
 */
static bool ate_dido1_control_deal(void)
{

    return true;
}

/**
 * @brief        dido控制任务处理
 * @param        [in]ate_ctl_type_e
 * @return
 */
static bool ate_dido2_control_deal(void)
{

    return true;
}

/**
 * @brief        dido控制任务处理
 * @param        [in]ate_ctl_type_e
 * @return
 */
static bool ate_dido3_control_deal(void)
{

    return true;
}

/**
* @brief        ATE 总任务控制
* @param        无
* @return       无
* @retval       需要屏蔽正常启动关机均衡的逻辑
* @warning      无
*/
static bool ate_ctl_deal_proc(ate_ctl_type_e type)
{
    const ctl_deal_callback ctl_deal[] = 
    {
        ate_func_sw1_control_deal,
        ate_func_sw2_control_deal,
        ate_func_sw3_control_deal,
        ate_dido1_control_deal,
        ate_dido2_control_deal,
        ate_dido3_control_deal,
    };
    uint8_t len = ITEM_NUM(ctl_deal);
    if (type >= len)
    {
        return false;
    }
    return ctl_deal[type]();
}



/**
* @brief        ATE模式设置
* @param        [in] special_mode     special_mode_list_e枚举
* @param        [in] set_flag         ATE_SET(置位)/ATE_CLR(清除)
* @return       执行结果
* @retval       ATE_ERR：设置失败
* @retval       ATE_OK： 设置成功
* @warning      无
*/
int32_t special_mode_set(special_mode_list_e special_mode, uint8_t set_flag)
{
    if (special_mode >= SPECIAL_MODE_NUM || set_flag > ATE_SET)
    {
        return ATE_ERR;
    }
    switch ((uint8_t)special_mode)
    {
        case AGING_MODE:
            g_special_mode.set_bit.ageing_mode = set_flag;
            break;
        case CALI_PARM:
            g_special_mode.set_bit.cali_parm_mode = set_flag;
            break;
        case ATUO_TEST:
            g_special_mode.set_bit.auto_test_mode = set_flag;
            break;
        case FORCE_CTL_MODE:
            g_special_mode.set_bit.force_ctl_mode = set_flag;
        default:
            break;
    }
    g_mode_over_timer[special_mode] = 0;
    return ATE_OK;
}
/**
* @brief        ATE模式获取
* @param        [in] special_mode     special_mode_list_e枚举
* @return       执行结果
* @retval       ATE_ERR：获取失败
* @retval       ATE_SET： 状态置位
* @retval       ATE_CLR： 状态退出
* @warning      无
*/
int32_t special_mode_get(special_mode_list_e special_mode)
{
    if (special_mode >= SPECIAL_MODE_NUM)
    {
        return ATE_CLR;
    }
    int32_t state_flag = ATE_CLR;
    switch ((uint8_t)special_mode)
    {
        case AGING_MODE:
            state_flag = g_special_mode.set_bit.ageing_mode;
            break;
        case CALI_PARM:
            state_flag = g_special_mode.set_bit.cali_parm_mode;
            break;
        case ATUO_TEST:
            state_flag = g_special_mode.set_bit.auto_test_mode;
            break;
        case FORCE_CTL_MODE:
            state_flag = g_special_mode.set_bit.force_ctl_mode;
            break;
        default:
            return ATE_CLR;
    }
    return state_flag;
}
/**
* @brief        产测完成标志设置
* @param        [in] set_flag         参考production_step_flag_u
* @return       执行结果
* @warning      无
*/
int32_t product_finish_flag_set(uint8_t set_flag)
{
    if (g_product_finish_flag.set_byte != set_flag)
    {
        g_product_finish_flag.set_byte = set_flag;
        bms_runing_data_t bms_data = *get_bms_runing_data();
        bms_data.product_finish_flag = g_product_finish_flag.set_byte;
        bms_runing_data_save(bms_data);
    }
    
    return ATE_OK;
}
/**
* @brief        产测完成标志获取
* @param        [in] 无
* @return       执行结果，返回g_product_finish_flag.set_byte
* @warning      无
*/
int32_t product_finish_flag_get(void)
{
    return g_product_finish_flag.set_byte;
}
/**
* @brief        模式超时恢复
* @param        无   
* @return       无
* @retval       无
* @warning      无
*/
void recover_special_mode_cmd(void)
{
#if ATE_SHELL_DEBUG_FALG
    if (g_ate_shell_debug_flag)
    {
        return;
    }
#endif
    for (uint8_t i = 0; i < SPECIAL_MODE_NUM; i++)
    {
        if (special_mode_get((special_mode_list_e)i))
        {
            if (++g_mode_over_timer[i] > ATE_DELAY_TIME)// 60s超时时间 
            {
                log_e("[ATE]%d timO\n", i);
                g_mode_over_timer[i] = 0;
                special_mode_set((special_mode_list_e)i, ATE_CLR);
            }
        }
        else
        {
            g_mode_over_timer[i] = 0;
        }
    }
}

/**
* @brief        判断工作模式是否发生改动,并且更新上次模式
* @param        无   
* @return       无
* @retval       无
* @warning      无
*/
void special_mode_change_deal(void)
{
    if (g_special_mode.set_byte == g_last_special_mode.set_byte)
    {
        return;
    }
    if (g_special_mode.set_bit.auto_test_mode != g_last_special_mode.set_bit.auto_test_mode)
    {
        log_e("[ATE]autoIs%s\n", (g_special_mode.set_bit.auto_test_mode) ? ("T") : ("F"));
        // 清除设置数据
        if (ATE_CLR == g_special_mode.set_bit.auto_test_mode)
        {
            memset(&g_ate_control, 0, sizeof(ate_control_t));
        }
    }
    if (g_special_mode.set_bit.ageing_mode != g_last_special_mode.set_bit.ageing_mode)
    {
        log_e("[ATE]ageIs%s\n", (g_special_mode.set_bit.ageing_mode) ? ("T") : ("F"));
    }
    if (g_special_mode.set_bit.cali_parm_mode != g_last_special_mode.set_bit.cali_parm_mode)
    {
        log_e("[ATE]caliIs%s\n", (g_special_mode.set_bit.cali_parm_mode) ? ("T") : ("F"));
    }
    if (g_special_mode.set_bit.force_ctl_mode != g_last_special_mode.set_bit.force_ctl_mode)
    {
        log_e("[ATE]forIs%s\n", (g_special_mode.set_bit.force_ctl_mode) ? ("T") : ("F"));
    }
    g_last_special_mode.set_byte = g_special_mode.set_byte;
}


/**
* @brief        ATE 设置处理函数
* @param        无   
* @return       无
* @retval       无
* @warning      100ms任务
*/
static void ate_ctl_deal(void)
{
    for(uint8_t ctl_id = 0; ctl_id < ATE_CTL_TYPE_NUM; ctl_id++)
    {
        ate_ctl_deal_proc((ate_ctl_type_e)ctl_id);
    }
}

/**
* @brief        ATE模式init
* @param        无   
* @return       无
* @retval       无
* @warning      无
*/
void ate_mode_init(void)
{
    memset(&g_ate_control, 0, sizeof(ate_control_t));
    memset(&g_special_mode, 0, sizeof(special_mode_u));
    memset(&g_last_special_mode, 0, sizeof(special_mode_u));
    memset(&g_mode_over_timer, 0, sizeof(g_mode_over_timer));

    const bms_runing_data_t *p_bms_data = get_bms_runing_data();
    g_product_finish_flag.set_byte = p_bms_data->product_finish_flag;
}

/**
* @brief        ATE模式
* @param        无   
* @return       无
* @retval       无
* @warning      100ms任务
*/
#define TIM1S   10
void ate_mode_proc(void)
{
//    static uint8_t send_cnt = 0;
    // ATE控制
    if (ATE_SET == g_special_mode.set_bit.auto_test_mode 
        /*&& ATE_SET == g_special_mode.set_bit.force_ctl_mode*/)
    {
        ate_ctl_deal();
//        if(0 == (send_cnt++ % TIM1S))
//        {
//            inner_can_send_msg_ready(ATE_TEST_INFO);
//        }
        
    }
    else
    {
//        g_ate_control.set_flag = 0;
    }
    if (ATE_SET == g_special_mode.set_bit.ageing_mode)
    {
        //inner_address_set(1);
    }
    // 模式超时恢复
    // recover_special_mode_cmd();
    // 特殊模式变化处理
    special_mode_change_deal();
}

/***********************************ate shell debug************************************************/
#if ATE_SHELL_DEBUG_FALG

// ate 打印
void ate_debug_printf(void)
{
    log_d("AGING=%d,CALI=%d,ATUO=%d,force%d\n", special_mode_get(AGING_MODE), special_mode_get(CALI_PARM), special_mode_get(ATUO_TEST), special_mode_get(FORCE_CTL_MODE));
    log_d("ateDebug=%d\n", g_ate_shell_debug_flag);
    log_d("allMode=%x\n", g_special_mode.set_byte);
    for (uint8_t i = 0; i < ATE_CTL_TYPE_NUM; i++)
    {
        log_d("Ctl[%d]=x%x\n", i, ate_ctl_can_get((ate_ctl_type_e)i));
    }
    uint32_t bal_pos = 0;
//    afe_balance_state_get(&bal_pos);
//    log_d("idIn=%d,supIn=%d\n", sdk_dido_read(DI_1_BAT_PACK_IN1), sdk_dido_read(DI_4_SUPPLE_CHG_ID));
    log_d("bal_pos=#%lx,reset%d\n", bal_pos, sdk_cpu_reset_flag_get());
    const bms_runing_data_t *bms_data = get_bms_runing_data();
    if (NULL != bms_data)
    {
        log_d("fla%#x %#x %#x %#x\n", bms_data->flash_data[0], bms_data->flash_data[1], bms_data->flash_data[2], bms_data->flash_data[3]);
    }
//    for (uint8_t j = 0; j < SPECIAL_MODE_NUM; j++)
//    {
//        log_e("%d,", g_mode_over_timer[j]);
//    }
}

// ate 状态打印
void ate_debug_state_print(void)
{
//    log_d("\nATE_ID_IN_STATE_TYPE           = %d\n", ate_state_get(ATE_ID_IN_STATE_TYPE));
//    log_d("ATE_ID_SUPPLE_CHG_TYPE         = %x\n", ate_state_get(ATE_ID_SUPPLE_CHG_TYPE));
//    log_d("ATE_BAL1_16_STATE_TYPE         = 0x%x\n", ate_state_get(ATE_BAL1_16_STATE_TYPE));
}

void ate_debug_err_printf(void)
{
//    log_d(" ate param err\r\n");
//    log_d(" ate print : printf data\r\n");
//    log_d(" ate debug 0/1: debug start/close\r\n");
//    log_d(" ate mode mode_id(0~%d) state(0/1): set ate mode\r\n", SPECIAL_MODE_NUM - 1);
//    log_d(" ate val val_id(0~%d) value(0~xxx): set val \r\n", ATE_CTL_TYPE_NUM - 1);
}

void ate_debug_help_printf(void)
{
//    log_d("mode_id:\n");
//    log_d("AGING_MODE       = %d\n", AGING_MODE); 
//    log_d("CALI_PARM        = %d\n", CALI_PARM ); 
//    log_d("ATUO_TEST        = %d\n", ATUO_TEST ); 

//    log_d("\nval_id:\n");
//    log_d("ATE_BOARD_LED_CTL_TYPE            = %d\n", ATE_BOARD_LED_CTL_TYPE           );
//    log_d("ATE_RUN_LED_CTL_TYPE              = %d\n", ATE_RUN_LED_CTL_TYPE             );
//    log_d("ATE_FAULT_LED_CTL_TYPE            = %d\n", ATE_FAULT_LED_CTL_TYPE           );
//    log_d("ATE_ACT_BAL_CHG_CTL_TYPE          = %d\n", ATE_ACT_BAL_CHG_CTL_TYPE         );
//    log_d("ATE_ACT_BAL_DCHG_CTL_TYPE         = %d\n", ATE_ACT_BAL_DCHG_CTL_TYPE        );
//    log_d("ATE_ID_OP_CTL_TYPE                = %d\n", ATE_ID_OP_CTL_TYPE               );
//    log_d("ATE_BAL1_16_CTL_TYPE              = %d\n", ATE_BAL1_16_CTL_TYPE             );
}

/**
 * @brief        ate功能样例
 * @param        argv 功能参数
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 * @warnning  只有不用can设置时生效
 */
static int ate(int argc, char *argv[])
{

    if (!strcmp(argv[1], "print"))
    {
        if(argc < 3)
        {
            log_d("%s %s para err\n",argv[0],argv[1]);
            return -1;
        }
        uint32_t flag = atoi(argv[2]); // 解析第2个参数名称
        if (flag)
        {
            ate_debug_state_print();
        }
        else
        {
            ate_debug_printf();
        }
    }
    else if (!strcmp(argv[1], "debug"))
    {
        if(argc < 3)
        {
            log_d("%s %s para err\n",argv[0],argv[1]);
            return -1;
        }
        uint32_t flag = atoi(argv[2]); // 解析第2个参数名称
        if (flag > true)
        {
             log_d(" ate_debug flag: err\r\n");
             return -1;
        }
        g_ate_shell_debug_flag = flag;
    }
    else if (!strcmp(argv[1], "mode"))
    {
        if(argc < 4)
        {
            log_d("%s %s para err\n",argv[0],argv[1]);
            return -1;
        }
        if (!g_ate_shell_debug_flag)
        {
            log_d("no set g_ate_shell_debug_flag\n");
            return -1;
        }
        uint32_t mode_id = atoi(argv[2]);          // 参数1: 模拟量special_mode_list_e
        int32_t set_flag = atoi(argv[3]);          // 参数2：value值
        special_mode_set((special_mode_list_e)mode_id, set_flag);
    }
    else if (!strcmp(argv[1], "val"))
    {
        if(argc < 4)
        {
            log_d("%s %s para err\n",argv[0],argv[1]);
            return -1;
        }        
        if (!g_ate_shell_debug_flag)
        {
            log_d("no set g_ate_shell_debug_flag\n");
            return -1;
        }
        uint32_t val_id = atoi(argv[2]);          // 参数1: 模拟量ate_ctl_type_e
        int32_t val = atoi(argv[3]);              // 参数2：value值
        ate_ctl_can_set((ate_ctl_type_e)val_id, val);
    }
    else if (!strcmp(argv[1], "help"))
    {
        ate_debug_help_printf();
    }
    else
    {
        ate_debug_err_printf();
        return -1;
    }
    return 0;
}
MSH_CMD_EXPORT(ate, <pirnt 0-1/debug 0-1/mode id vaule/val id vaule>);
#endif

