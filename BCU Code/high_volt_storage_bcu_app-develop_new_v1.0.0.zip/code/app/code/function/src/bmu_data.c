/**
 * @file     bmu_data.c
 * @brief    综合处理bmu采样数据
 * @company  sofarsolar
 * @author   
 * @note     综合所有采样模拟量
 * @version
 * @date     2023/4/27 初稿
 */
 
#include <string.h>
#include <stdlib.h>
#include "sofar_errors.h"
#include "sdk.h"
#include "bmu_data.h"
#include "auto_addressing.h"
#include "fault_manage.h"
#include "bms_state.h"
#include "data_store.h"

#ifdef SIMULATION_DATA_TEST
static uint8_t g_simulate_test_flag = 0;    //模拟测试标志 1: 调测模式   0:正常模式
#endif

#if RECV_BMU_CAN_DATA
static recv_bmu_data_t g_recv_bmu_data[PACK_MAX_NUM] = { 0 };  // 接收can数据
#endif

#define MAX_TEMP 1200
#define MIN_TEMP -400
#define MAX_VOLT 4300
#define MIN_VOLT 1500

static bmu_data_unify_t g_bmu_data_unify = { 0 };              // 电池综合数据

typedef struct
{
    int16_t max_val[3];
    int16_t min_val[3];
    uint16_t max_id;
    uint16_t min_id;
    int16_t avg_val;
}max_min_third_t;

/**
* @brief                BMS信息数据初始化
* @param                [in]无
* @return               无返回结果
* @warning              无
*/
void bmu_data_init(void)
{
    memset(&g_bmu_data_unify, 0, sizeof(bmu_data_unify_t));
}

/**
* @brief                获取BMS数据信息
* @param                [in]bmu_data_t *p_data 电池采样数据结构体指针
* @return               返回bmu_data_t *p_data 电池采样数据结构体指针
* @retval               NULL 获取失败
* @retval               非NULL获取成功
* @warning              必须不为NULL，才可以使用
*/
const bmu_data_unify_t* bmu_data_unify_get(void)
{
    #ifndef SIMULATION_DATA_TEST
    if (0 == auto_addressing_pack_num_get())
    {
        return NULL;
    }
    #else
    if (0 == g_simulate_test_flag && 0 == auto_addressing_pack_num_get())
    {
        return NULL;
    }
    #endif
    return (const bmu_data_unify_t*)&g_bmu_data_unify;
}



/**
* @brief        bmu数据综合
* @param        [in] 无
* @return        [out]无
* @retval         无
*/
static void bmu_data_unify_deal(void)
{
    uint8_t pack_num = auto_addressing_pack_num_get();
    if (0 == pack_num)
    {
        g_bmu_data_unify.all_pack_acc_volt = 0;
        g_bmu_data_unify.max_cycle_time = 0;
        g_bmu_data_unify.chg_disg_enable = 0;
        g_bmu_data_unify.empty_full_flag = 0;
        g_bmu_data_unify.bat_ave_temp = 0x7f;
        g_bmu_data_unify.remain_cap = 0;
        g_bmu_data_unify.bal_status = 0;
        g_bmu_data_unify.batmaxcellvolt = 0;
        g_bmu_data_unify.batmaxcellvoltpack = 0;
        g_bmu_data_unify.batmaxcellvoltnum = 0;
        g_bmu_data_unify.batmincellvolt = 0;
        g_bmu_data_unify.batmincellvoltpack = 0;
        g_bmu_data_unify.batmincellvoltnum = 0;
        g_bmu_data_unify.batmaxcelltemp = 0x7f;
        g_bmu_data_unify.batmaxcelltemppack = 0;
        g_bmu_data_unify.batmaxcelltempnum = 0;
        g_bmu_data_unify.batmincelltemp = 0x7f;
        g_bmu_data_unify.batmincelltemppack = 0;
        g_bmu_data_unify.batmincelltempnum = 0;     
        return;
    }
    uint8_t init_bmu_data_flag = false;
    //uint16_t data_tmp = 0; 
    uint32_t all_pack_acc_volt_sum = 0;
    uint16_t max_cycle_time = 0;
    uint16_t chg_disg_enable = 0xAAAA;
    uint16_t empty_full_flag = 0;
    int16_t bat_ave_temp = 0;
    uint16_t remain_cap = 0xFFFF;
    uint16_t bal_status = 0;
//    uint16_t dsg_bal_status = 0;
//    uint16_t chg_bal_status = 0;
    uint16_t batmaxcellvolt = MIN_VOLT;
    uint16_t batmaxcellvoltpack = 0;
    uint16_t batmaxcellvoltnum = 0;
    uint16_t batmincellvolt = MAX_VOLT;
    uint16_t batmincellvoltpack = 0;
    uint16_t batmincellvoltnum = 0; 
    int16_t batmaxcelltemp = MIN_TEMP;
    uint16_t batmaxcelltemppack = 0;
    uint16_t batmaxcelltempnum = 0;
    int16_t batmincelltemp = MAX_TEMP;
    uint16_t batmincelltemppack = 0;
    uint16_t batmincelltempnum = 0;

    uint16_t chg_en_flag = 0;
    uint16_t dsg_en_flag = 0;
    uint16_t chg_full_flag = 0;
    uint16_t dsg_empty_flag = 0;
    uint16_t req_cutoff_flag = 0;
    uint16_t req_powoff_flag = 0;
    uint16_t bmu_err_sta = 0;
    uint16_t bmu_upg_sta = 0;
    uint16_t bmu_shut_sta = 0;
    uint8_t force_chg_flag = false;
    uint16_t max_sync_fall_soc = 0;

    static uint16_t last_chg_en_flag = 0;
    static uint16_t last_dsg_en_flag = 0;
    static uint16_t last_chg_full_flag = 0;
    static uint16_t last_dsg_empty_flag = 0;
    static uint16_t last_req_cutoff_flag = 0;
    static uint16_t last_req_powoff_flag = 0;

    uint32_t packvoltmax = 0;
    uint16_t packvoltmaxid = 0;
    uint32_t packvoltmin = 0xFFFFFFFF;
    uint16_t packvoltminid = 0;    
    // uint16_t packcellvoltdiffmax = 0;
    // uint16_t packcellvoltdiffmaxid = 0;
    // uint16_t packcellvoltdiffmin = 0xFFFF;
    // uint16_t packcellvoltdiffminid = 0;  
    // uint16_t packcelltempdiffmax = 0;
    // uint16_t packcelltempdiffmaxid = 0;
    // uint16_t packcelltempdiffmin = 0xFFFF;
    // uint16_t packcelltempdiffminid = 0;

    inner_fault_info_t inner_bmu_fault_info = {0};

#if 1
    pack_info_t *bmu_data = NULL;
    bmu_yx_req_data yx_req_data = {0};
    for(uint8_t i = 0; i < pack_num; i++)
    {
        bmu_data = NULL;
        bmu_data = get_bmu_info(i);
        if (NULL == bmu_data)
        {
            continue;
        }
        if (0xFFFF != bmu_data->yc2[YC2_UNS_PACK_VOLT])
        {
            if(bmu_data->yc2[YC2_UNS_PACK_VOLT] > packvoltmax)
            {
                packvoltmax = bmu_data->yc2[YC2_UNS_PACK_VOLT];
                packvoltmaxid = i + 1;
            }

            if(bmu_data->yc2[YC2_UNS_PACK_VOLT] < packvoltmin)
            {
                packvoltmin = bmu_data->yc2[YC2_UNS_PACK_VOLT];
                packvoltminid = i + 1;
            }
            all_pack_acc_volt_sum += bmu_data->yc2[YC2_UNS_PACK_VOLT];
        }
        max_cycle_time = (bmu_data->yc2[YC2_UNS_CYCLE_TIME] > max_cycle_time) ? bmu_data->yc2[YC2_UNS_CYCLE_TIME] : max_cycle_time;

        // 统计bmu的状态
        if (bmu_data->yx[YX_BMU_SYS_STATE] == BMU_STATE_PF_ERROR)
        {
            bmu_err_sta |= (0x1 << i);
        }
        else if (bmu_data->yx[YX_BMU_SYS_STATE] == BMU_STATE_UPGRADE)
        {
            bmu_upg_sta |= (0x1 << i);
        }
        else if (bmu_data->yx[YX_BMU_SYS_STATE] == BMU_STATE_SHUT_DOWN)
        {
            bmu_shut_sta |= (0x1 << i);
        }

        yx_req_data.req.byte = bmu_data->yx[YX_BMU_REQ_ENABLE_1];
        yx_req_data.req2.byte = bmu_data->yx[YX_BMU_REQ_ENABLE_2];
        yx_req_data.state.byte = bmu_data->yx[YX_BMU_CHG_DSG_STATE];
        //充放电使能
        if (!(yx_req_data.req.bits.chg_enale)) //先判断充电标志
        {
            chg_disg_enable &= 0xFF00;
        }
        else
        {
            chg_en_flag |= (0x1 << i);
        }
        if (!(yx_req_data.req.bits.dsg_enale)) //先判断充电标志
        {
            chg_disg_enable &= 0xFF;
        }
        else
        {
            dsg_en_flag |= (0x1 << i);
        }

        //充满放空标志
        if (yx_req_data.state.bits.full_chg)
        {
            empty_full_flag |= 0xAA;
            chg_full_flag |= (0x1 << i);
        }
        if (yx_req_data.state.bits.empty_dsg)
        {
            empty_full_flag |= 0xAA00;
            dsg_empty_flag |= (0x1 << i);
        }

        // 请求切断继电器标志
        if (yx_req_data.req.bits.bmu_cut_off_req)
        {
            req_cutoff_flag |= (0x1 << i);
        }

        // 请求休眠标志
        if (yx_req_data.req.bits.bmu_pow_off_req)
        {
            req_powoff_flag |= (0x1 << i);
        }

        // 强充请求标志
        if (yx_req_data.req.bits.force_chg_req)
        {
            force_chg_flag = true;
        }

        // 电池包最大同步下降SOC
        if (i == 0)
        {
            max_sync_fall_soc = bmu_data->yx[YX_BMU_SYNC_FALL_SOC];
        }
        else
        {
            if (bmu_data->yx[YX_BMU_SYNC_FALL_SOC] > max_sync_fall_soc)
            {
                max_sync_fall_soc = bmu_data->yx[YX_BMU_SYNC_FALL_SOC];
            }
        }
        
        //电芯温度总和
        bat_ave_temp += bmu_data->yc2[YC2_SGN_AVG_CELL_TEMP];

        //实时剩余总容量
        if(remain_cap > bmu_data->yc2[YC2_UNS_REMAIN_CAP_AH])
        {
            remain_cap = bmu_data->yc2[YC2_UNS_REMAIN_CAP_AH];
        }

        // //找最大电压差包
        // if(bmu_data->yc2[] >= packcellvoltdiffmax)
        // {
        //    packcellvoltdiffmax = bmu_data->yc2[];
        //    packcellvoltdiffmaxid = i + 1;
        // }

        // //找最小电压差包
        // if(bmu_data->yc2[] <= packcellvoltdiffmin)
        // {
        //    packcellvoltdiffmin = bmu_data->yc2[];
        //    packcellvoltdiffminid = i + 1;
        // }

        // //找最大温差包
        // if(bmu_data->yc2[] >= packcelltempdiffmax)
        // {
        //    packcelltempdiffmax = bmu_data->yc2[];
        //    packcelltempdiffmaxid = i + 1;
        // }

        // //找最小温差包
        // if(bmu_data->yc2[] <= packcelltempdiffmin)
        // {
        //    packcelltempdiffmin = bmu_data->yc2[];
        //    packcelltempdiffminid = i + 1;
        // }

        //电池包均衡状态
        if(0 != bmu_data->yx[YX_BMU_ACT_BAL_STATE])
        {
            bal_status |= 0x01<<i;
        }

        if (!init_bmu_data_flag) // 初始化第一次数据
        {
            init_bmu_data_flag = true;
            batmaxcellvolt = bmu_data->yc2[YC2_UNS_MAX_CELL_VOLT];
            batmincellvolt = bmu_data->yc2[YC2_UNS_MIN_CELL_VOLT];
            batmaxcelltemp = bmu_data->yc2[YC2_SGN_MAX_CELL_TEMP];
            batmincelltemp = bmu_data->yc2[YC2_SGN_MIN_CELL_TEMP];
        }
        //找最大电压
        if(bmu_data->yc2[YC2_UNS_MAX_CELL_VOLT] >= batmaxcellvolt)
        {
           batmaxcellvolt = bmu_data->yc2[YC2_UNS_MAX_CELL_VOLT];
           batmaxcellvoltpack = i + 1;
           batmaxcellvoltnum = bmu_data->yc1[YC1_UNS_MAX_CELL_V_ID];
        }

        //找最小电压
        if(bmu_data->yc2[YC2_UNS_MIN_CELL_VOLT] <= batmincellvolt)
        {
           batmincellvolt = bmu_data->yc2[YC2_UNS_MIN_CELL_VOLT];
           batmincellvoltpack = i + 1;
           batmincellvoltnum = bmu_data->yc1[YC1_UNS_MIN_CELL_V_ID];
        }      

        //找最高温度  
        if(bmu_data->yc2[YC2_SGN_MAX_CELL_TEMP] >= batmaxcelltemp)
        {
           batmaxcelltemp = bmu_data->yc2[YC2_SGN_MAX_CELL_TEMP];
           batmaxcelltemppack = i + 1;
           batmaxcelltempnum = bmu_data->yc1[YC1_UNS_MAX_CELL_T_ID];
        }   

        //找最低温度  
        if(bmu_data->yc2[YC2_SGN_MIN_CELL_TEMP] <= batmincelltemp)
        {
           batmincelltemp = bmu_data->yc2[YC2_SGN_MIN_CELL_TEMP];
           batmincelltemppack = i + 1;
           batmincelltempnum = bmu_data->yc1[YC1_UNS_MIN_CELL_T_ID];
        }

        //BMU故障位信息
        inner_bmu_fault_info.fault_info1.byte0.byte |= bmu_data->yx[YX_BMU_PACK_CELL_VOLT_FAULT];
        inner_bmu_fault_info.fault_info1.byte1.byte |= bmu_data->yx[YX_BMU_CELL_TEMP_FAULT];
        inner_bmu_fault_info.fault_info1.byte2.byte |= bmu_data->yx[YX_BMU_CURR_TEMP_FAULT];
        inner_bmu_fault_info.fault_info1.byte3.byte |= bmu_data->yx[YX_BMU_SOC_SAM_FAULT];
        inner_bmu_fault_info.fault_info1.byte4.byte |= bmu_data->yx[YX_BMU_MOS_FAULT];
        inner_bmu_fault_info.fault_info1.byte5.byte |= bmu_data->yx[YX_BMU_CAN_FAULT];
        inner_bmu_fault_info.fault_info1.byte6.byte |= bmu_data->yx[YX_BMU_CHG_CURR_ZERO_VOLT_FAULT];
        inner_bmu_fault_info.fault_info1.byte7.byte |= bmu_data->yx[YX_BMU_DSG_CURR_ZERO_VOLT_FAULT];

        inner_bmu_fault_info.fault_info2.byte0.byte |= bmu_data->yx[YX_BMU_ACT_BAL_FAULT1];
        inner_bmu_fault_info.fault_info2.byte1.byte |= bmu_data->yx[YX_BMU_ACT_BAL_FAULT2];
        inner_bmu_fault_info.fault_info2.byte2.byte |= bmu_data->yx[YX_BMU_CELL_VOLT_LOCK_FAULT];
        inner_bmu_fault_info.fault_info2.byte3.byte |= bmu_data->yx[YX_BMU_CELL_TEMP_LOCK_FAULT];
        inner_bmu_fault_info.fault_info2.byte4.byte |= bmu_data->yx[YX_BMU_SAM_LINE_FAULT];
        inner_bmu_fault_info.fault_info2.byte5.byte |= bmu_data->yx[YX_BMU_HEAT_ALARM];
        inner_bmu_fault_info.fault_info2.byte6.byte |= bmu_data->yx[YX_BMU_OTHER_FAULT];
        inner_bmu_fault_info.fault_info2.byte7.byte |= bmu_data->yx[YX_BMU_RES3_FAULT];

        inner_bmu_fault_info.fault_info3.byte0.byte |= bmu_data->yx[YX_BMU_CELL_TIP1];
        inner_bmu_fault_info.fault_info3.byte1.byte |= bmu_data->yx[YX_BMU_CELL_TIP2];        
        inner_bmu_fault_info.fault_info3.byte2.byte |= bmu_data->yx[YX_BMU_CELL_ALARM];
        inner_bmu_fault_info.fault_info3.byte4.byte |= bmu_data->yx[YX_BMU_CELL_FAULT];
        
        g_bmu_data_unify.fault_level[i] = bmu_data->yx[YX_BMU_FAULT_LEVEL];
    }

    if (chg_en_flag != last_chg_en_flag)
    {
        log_e("[BMU]chgEn=%#x\n", chg_en_flag);
    }

    if (dsg_en_flag != last_dsg_en_flag)
    {
        log_e("[BMU]dsgEn=%#x\n", dsg_en_flag);
    }

    if (chg_full_flag != last_chg_full_flag)
    {
        log_e("[BMU]chgFull=%#x\n", chg_full_flag);
    }

    if (dsg_empty_flag != last_dsg_empty_flag)
    {
        log_e("[BMU]dsgEmpty=%#x\n", dsg_empty_flag);
    }

    if (req_cutoff_flag != last_req_cutoff_flag)
    {
        log_e("[BMU]reqCutoff=%#x\n", req_cutoff_flag);
    }

    if (req_powoff_flag != last_req_powoff_flag)
    {
        log_e("[BMU]reqPowoff=%#x\n", req_powoff_flag);
    }
    
    last_chg_en_flag = chg_en_flag;
    last_dsg_en_flag = dsg_en_flag;
    last_chg_full_flag = chg_full_flag;
    last_dsg_empty_flag = dsg_empty_flag;
    last_req_cutoff_flag = req_cutoff_flag;
    last_req_powoff_flag = req_powoff_flag;

    //电芯平均温度
    bat_ave_temp /= pack_num;

    g_bmu_data_unify.all_pack_inner_fault = inner_bmu_fault_info;

#else
    for(uint8_t i = 0; i < pack_num; i++)
    {
        all_pack_acc_volt_sum += g_recv_bmu_data[i].yc1_unsgn_data.yc1_data.pack_volt;
    }
#endif
    g_bmu_data_unify.all_pack_acc_volt = all_pack_acc_volt_sum;
    g_bmu_data_unify.max_cycle_time = max_cycle_time;
    g_bmu_data_unify.chg_disg_enable = chg_disg_enable;
    g_bmu_data_unify.chg_en_flag = chg_en_flag;
    g_bmu_data_unify.empty_full_flag = empty_full_flag;
    g_bmu_data_unify.bat_ave_temp = bat_ave_temp;
    g_bmu_data_unify.remain_cap = remain_cap;
    g_bmu_data_unify.bal_status = bal_status;
    g_bmu_data_unify.batmaxcellvolt = batmaxcellvolt;
    g_bmu_data_unify.batmaxcellvoltpack = batmaxcellvoltpack;
    g_bmu_data_unify.batmaxcellvoltnum = batmaxcellvoltnum;
    g_bmu_data_unify.batmincellvolt = batmincellvolt;
    g_bmu_data_unify.batmincellvoltpack = batmincellvoltpack;
    g_bmu_data_unify.batmincellvoltnum = batmincellvoltnum;
    g_bmu_data_unify.batmaxcelltemp = batmaxcelltemp;
    g_bmu_data_unify.batmaxcelltemppack = batmaxcelltemppack;
    g_bmu_data_unify.batmaxcelltempnum = batmaxcelltempnum;
    g_bmu_data_unify.batmincelltemp = batmincelltemp;
    g_bmu_data_unify.batmincelltemppack = batmincelltemppack;
    g_bmu_data_unify.batmincelltempnum = batmincelltempnum;
    g_bmu_data_unify.req_cutoff_flag = req_cutoff_flag;
    g_bmu_data_unify.req_powoff_flag = req_powoff_flag;
    g_bmu_data_unify.force_chg_flag = force_chg_flag;
    g_bmu_data_unify.max_sync_fall_soc = max_sync_fall_soc;
    g_bmu_data_unify.bmu_err_sta = bmu_err_sta;
    g_bmu_data_unify.bmu_upg_sta = bmu_upg_sta;
    g_bmu_data_unify.bmu_shut_sta = bmu_shut_sta;
    g_bmu_data_unify.packvolt_max = packvoltmax;
    g_bmu_data_unify.packvolt_max_id = packvoltmaxid;
    g_bmu_data_unify.packvolt_min = packvoltmin;
    g_bmu_data_unify.packvolt_min_id = packvoltminid;    
    g_bmu_data_unify.packvolt_diff_max = packvoltmax - packvoltmin;
    // g_bmu_data_unify.pack_cellvolt_diff_max = packcellvoltdiffmax;
    // g_bmu_data_unify.pack_cellvolt_diff_max_id = packcellvoltdiffmaxid;
    // g_bmu_data_unify.pack_cellvolt_diff_min = packcellvoltdiffmin;
    // g_bmu_data_unify.pack_cellvolt_diff_min_id = packcellvoltdiffminid;
    // g_bmu_data_unify.pack_celltemp_diff_max = packcelltempdiffmax;
    // g_bmu_data_unify.pack_celltemp_diff_max_id = packcelltempdiffmaxid;
    // g_bmu_data_unify.pack_celltemp_diff_min = packcelltempdiffmin;
    // g_bmu_data_unify.pack_celltemp_diff_min_id = packcelltempdiffminid;
}

/**
 * @brief                获取bmu pin脚信息
 * @param                [in]pack num (1-PACK_MAX_NUM)
 * @param                [in]io id  bmu_di_data_type
 * @return               返回结果空
 * @retval               [out]-1:输入参数异常， -2：数据没有获取, 0:低电平， 1:高电平
 * @warning              放在10ms任务，必须要调用bms_data_init()后使用
 */
int8_t bmu_di_status_get(uint8_t pack_num, bmu_di_data_type di_type)
{
    if (pack_num > PACK_MAX_NUM || pack_num == 0 || di_type >= BMS_DI_TYPE_NUM)
    {
        return -1; // 错误
    }
    pack_info_t *p_bmu_data = get_bmu_info(pack_num - 1);
    if (NULL == p_bmu_data)
    {
        return -2;
    }
    uint16_t di_data = p_bmu_data->yx[YX_BMU_DI_STATE] & 0x00FF;
    
    return (di_data & (0x0001 << di_type)) ? 1 : 0;
}


// u16类型查找最高最低3个数据
void check_max_min_third_u16data(uint16_t arr[], uint16_t size, max_min_third_t *out)
{
    if (out == NULL || arr == NULL || size == 0)
    {
        return;
    }
    uint16_t largest[3] = {0, 0, 0};
    uint16_t smallest[3] = {0xFFFF, 0xFFFF, 0xFFFF};
    uint16_t max_id = 0;
    uint16_t min_id = 0;
    uint32_t sum = 0;
    uint16_t sum_cnt = 0;
    for (uint16_t i = 0; i < size; i++)
    {
        if (arr[i] == 0xFFFF)
        {
            continue;
        }
        for (int j = 0; j < 3; j++) 
        {
            if (arr[i] > largest[j]) 
            {
                for (int k = 2; k > j; k--)
                {
                    largest[k] = largest[k - 1];
                }
                largest[j] = arr[i];
                max_id = i + 1; //因为序号从1开始
                break;
            }
        }

        for (int j = 0; j < 3; j++)
        {
            if (arr[i] < smallest[j])
            {
                for (int k = 2; k > j; k--)
                {
                    smallest[k] = smallest[k - 1];
                }
                smallest[j] = arr[i];
                min_id = i + 1; //因为序号从1开始
                break;
            }
        }
        sum += arr[i];
        sum_cnt++;
    }
    out->max_id = max_id;
    out->min_id = min_id;
    out->max_val[0] = largest[0];
    out->max_val[1] = largest[1];
    out->max_val[2] = largest[2];
    out->min_val[0] = smallest[0];
    out->min_val[1] = smallest[1];
    out->min_val[2] = smallest[2];
    out->avg_val = sum / sum_cnt;
}

// u8类型查找最高最低3个数据
void check_max_min_third_u8data(int8_t arr[], uint16_t size, max_min_third_t *out, uint8_t is_temp_type)
{
    if (out == NULL || arr == NULL || size == 0)
    {
        return;
    }
    int8_t largest[3] = {0, 0, 0};
    int8_t smallest[3] = {0x7F, 0x7F, 0x7F};
    uint16_t max_id = 0;
    uint16_t min_id = 0;
    int32_t sum = 0;
    uint16_t sum_cnt = 0;
    uint16_t mod = 0;
    for (uint16_t i = 0; i < size; i++)
    {
         // 由于一个电池包温度由24个电芯温度+4个铜排温度，所以要特殊处理
        if (is_temp_type)
        {
            mod = i % get_bms_attr()->pack_temp_num;
            if (mod >= 24 && mod <= 27)
            {
                continue;
            }
        }
        if (arr[i] == -1)
        {
            continue;
        }
        for (int j = 0; j < 3; j++) 
        {
            if (arr[i] > largest[j]) 
            {
                for (int k = 2; k > j; k--)
                {
                    largest[k] = largest[k - 1];
                }
                largest[j] = arr[i];
                max_id = i + 1; //因为序号从1开始
                break;
            }
        }

        for (int j = 0; j < 3; j++)
        {
            if (arr[i] < smallest[j])
            {
                for (int k = 2; k > j; k--)
                {
                    smallest[k] = smallest[k - 1];
                }
                smallest[j] = arr[i];
                min_id = i + 1; //因为序号从1开始
                break;
            }
        }
        sum += arr[i];
        sum_cnt++;
    }
    out->max_id = max_id;
    out->min_id = min_id;
    out->max_val[0] = largest[0];
    out->max_val[1] = largest[1];
    out->max_val[2] = largest[2];
    out->min_val[0] = smallest[0];
    out->min_val[1] = smallest[1];
    out->min_val[2] = smallest[2];
    out->avg_val = sum / sum_cnt;
}

// 电芯电压、温度、soc、soh数据整理
void bmu_cell_info_arrange(void)
{
    uint8_t pack_num = auto_addressing_pack_num_get();
    
    const pack_cell_info_t* p_bmu_cell_info = get_bmu_cell_info();
    max_min_third_t out_data = {0};
    
    // 电芯电压数据
    check_max_min_third_u16data((uint16_t*)p_bmu_cell_info->cell_volt, pack_num * get_bms_attr()->pack_cell_num, &out_data);
    g_bmu_data_unify.bmu_cell_info.max_cell_volt[0] = out_data.max_val[0];
    g_bmu_data_unify.bmu_cell_info.max_cell_volt[1] = out_data.max_val[1];
    g_bmu_data_unify.bmu_cell_info.max_cell_volt[2] = out_data.max_val[2];
    g_bmu_data_unify.bmu_cell_info.min_cell_volt[0] = out_data.min_val[0];
    g_bmu_data_unify.bmu_cell_info.min_cell_volt[1] = out_data.min_val[1];
    g_bmu_data_unify.bmu_cell_info.min_cell_volt[2] = out_data.min_val[2];
    g_bmu_data_unify.bmu_cell_info.max_cell_volt_id = out_data.max_id;
    g_bmu_data_unify.bmu_cell_info.min_cell_volt_id = out_data.min_id;
    g_bmu_data_unify.bmu_cell_info.avg_cell_volt = out_data.avg_val;
    g_bmu_data_unify.bmu_cell_info.max_cell_volt_diff = g_bmu_data_unify.bmu_cell_info.max_cell_volt[0] - g_bmu_data_unify.bmu_cell_info.min_cell_volt[0];

    // 电芯soc数据
    check_max_min_third_u8data((int8_t*)p_bmu_cell_info->cell_soc, pack_num * get_bms_attr()->pack_cell_num, &out_data, 0);
    g_bmu_data_unify.bmu_cell_info.max_cell_soc[0] = out_data.max_val[0];
    g_bmu_data_unify.bmu_cell_info.max_cell_soc[1] = out_data.max_val[1];
    g_bmu_data_unify.bmu_cell_info.max_cell_soc[2] = out_data.max_val[2];
    g_bmu_data_unify.bmu_cell_info.min_cell_soc[0] = out_data.min_val[0];
    g_bmu_data_unify.bmu_cell_info.min_cell_soc[1] = out_data.min_val[1];
    g_bmu_data_unify.bmu_cell_info.min_cell_soc[2] = out_data.min_val[2];
    g_bmu_data_unify.bmu_cell_info.max_cell_soc_id = out_data.max_id;
    g_bmu_data_unify.bmu_cell_info.min_cell_soc_id = out_data.min_id;
    g_bmu_data_unify.bmu_cell_info.avg_cell_soc = out_data.avg_val;
    g_bmu_data_unify.bmu_cell_info.max_cell_soc_diff = g_bmu_data_unify.bmu_cell_info.max_cell_soc[0] - g_bmu_data_unify.bmu_cell_info.min_cell_soc[0];
  
    // 电芯soh数据
    check_max_min_third_u8data((int8_t*)p_bmu_cell_info->cell_soh, pack_num * get_bms_attr()->pack_cell_num, &out_data, 0);
    g_bmu_data_unify.bmu_cell_info.max_cell_soh[0] = out_data.max_val[0];
    g_bmu_data_unify.bmu_cell_info.max_cell_soh[1] = out_data.max_val[1];
    g_bmu_data_unify.bmu_cell_info.max_cell_soh[2] = out_data.max_val[2];
    g_bmu_data_unify.bmu_cell_info.min_cell_soh[0] = out_data.min_val[0];
    g_bmu_data_unify.bmu_cell_info.min_cell_soh[1] = out_data.min_val[1];
    g_bmu_data_unify.bmu_cell_info.min_cell_soh[2] = out_data.min_val[2];
    g_bmu_data_unify.bmu_cell_info.max_cell_soh_id = out_data.max_id;
    g_bmu_data_unify.bmu_cell_info.min_cell_soh_id = out_data.min_id;
    g_bmu_data_unify.bmu_cell_info.avg_cell_soh = out_data.avg_val;
    g_bmu_data_unify.bmu_cell_info.max_cell_soh_diff = g_bmu_data_unify.bmu_cell_info.max_cell_soh[0] - g_bmu_data_unify.bmu_cell_info.min_cell_soh[0];
    
    // 由于一个电池包温度由24个电芯温度+4个铜排温度，所以要特殊处理
    check_max_min_third_u8data((int8_t*)p_bmu_cell_info->cell_temp, pack_num * get_bms_attr()->pack_temp_num, &out_data, 0);
    g_bmu_data_unify.bmu_cell_info.max_cell_temp[0] = out_data.max_val[0];
    g_bmu_data_unify.bmu_cell_info.max_cell_temp[1] = out_data.max_val[1];
    g_bmu_data_unify.bmu_cell_info.max_cell_temp[2] = out_data.max_val[2];
    g_bmu_data_unify.bmu_cell_info.min_cell_temp[0] = out_data.min_val[0];
    g_bmu_data_unify.bmu_cell_info.min_cell_temp[1] = out_data.min_val[1];
    g_bmu_data_unify.bmu_cell_info.min_cell_temp[2] = out_data.min_val[2];
    g_bmu_data_unify.bmu_cell_info.max_cell_temp_id = out_data.max_id;
    g_bmu_data_unify.bmu_cell_info.min_cell_temp_id = out_data.min_id;
    g_bmu_data_unify.bmu_cell_info.avg_cell_temp = out_data.avg_val;
    g_bmu_data_unify.bmu_cell_info.max_cell_temp_diff = g_bmu_data_unify.bmu_cell_info.max_cell_temp[0] - g_bmu_data_unify.bmu_cell_info.min_cell_temp[0];
}

/**
 * @brief                BMS信息数据任务
 * @param                [in]void
 * @return               返回结果空
 * @retval               [out]无
 * @warning              放在10ms任务，必须要调用bms_data_init()后使用
 */
void bmu_data_proc(void)
{
    #ifndef SIMULATION_DATA_TEST
    //MCU采样数据获取
    bmu_data_unify_deal();
    #else
    if(!g_simulate_test_flag)    //测试模式下不更新
    {
        //MCU采样数据获取
        bmu_data_unify_deal();
        bmu_cell_info_arrange();
    }
    #endif
}

/********************************************调试代码********************************************************/

#ifdef SIMULATION_DATA_TEST

typedef enum
{
    DEBUG_ACC_PACK_VOLT = 0,                          ///< 综合电池包电压   单位 0.1V
    DEBUG_VAL_NUM,
} sample_value_debug_e;

/**
 * @brief        设置模拟量debug
 * @param        [in] debug_flag 模拟量debug标志， 1：debug 0:normal
 * @param        [in] data_type 模拟量debug标志， 1：debug 0:normal
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
void bmu_data_value_set_debug(uint32_t debug_flag, uint8_t data_type, int32_t value)
{
    if (!debug_flag)
    {
        return;
    }
    switch (data_type)
    {
        case DEBUG_ACC_PACK_VOLT:
            g_bmu_data_unify.all_pack_acc_volt = value;
            break;
        default:
            log_d("bmuSetValTypeOverErr\n");
            break;
    }
}

/**
 * @brief                BMU数据打印
 * @return               返回结果空
 * @warning              测试调试使用
 */
void bmu_data_debug_printf(void)
{
    log_d("testFlag=%d\n", g_simulate_test_flag);
    log_d("AccV=%ld(0.1V)\n", g_bmu_data_unify.all_pack_acc_volt);
    log_d("maxCellV=%d,packId%d,cellId%d\n", g_bmu_data_unify.batmaxcellvolt,g_bmu_data_unify.batmaxcellvoltpack, g_bmu_data_unify.batmaxcellvoltnum);
    log_d("minCellV=%d,packId%d,cellId%d\n", g_bmu_data_unify.batmincellvolt,g_bmu_data_unify.batmincellvoltpack, g_bmu_data_unify.batmincellvoltnum);
    log_d("maxTempV=%d,packId%d,cellId%d\n", g_bmu_data_unify.batmaxcelltemp,g_bmu_data_unify.batmaxcelltemppack, g_bmu_data_unify.batmaxcelltempnum);
    log_d("minTempV=%d,packId%d,cellId%d\n", g_bmu_data_unify.batmincelltemp,g_bmu_data_unify.batmincelltemppack, g_bmu_data_unify.batmincelltempnum);
    log_d("maxT:%d,%d,%d;minT:%d,%d,%d;AveT:%d,DiffT:%d\n",g_bmu_data_unify.bmu_cell_info.max_cell_temp[0],g_bmu_data_unify.bmu_cell_info.max_cell_temp[1],g_bmu_data_unify.bmu_cell_info.max_cell_temp[2],g_bmu_data_unify.bmu_cell_info.min_cell_temp[0],g_bmu_data_unify.bmu_cell_info.min_cell_temp[1],g_bmu_data_unify.bmu_cell_info.min_cell_temp[2],g_bmu_data_unify.bmu_cell_info.avg_cell_temp,g_bmu_data_unify.bmu_cell_info.max_cell_temp_diff);
    log_d("maxCycle=%d\n", g_bmu_data_unify.max_cycle_time);
    log_d("bmuLink:%x\n",singal_bmu_bcu_com_fault_flag_get());
//    log_d("bmsRecordSize=%d\n", sizeof(bms_record_data_t));
//    
//    log_d("bmuFault1_0=%x\n", g_bmu_data_unify.all_pack_inner_fault.fault_info1.byte0.byte);
//    log_d("bmuFault1_1=%x\n", g_bmu_data_unify.all_pack_inner_fault.fault_info1.byte1.byte);
//    log_d("bmuFault1_2=%x\n", g_bmu_data_unify.all_pack_inner_fault.fault_info1.byte2.byte);
//    log_d("bmuFault1_3=%x\n", g_bmu_data_unify.all_pack_inner_fault.fault_info1.byte3.byte);
//    log_d("bmuFault1_4=%x\n", g_bmu_data_unify.all_pack_inner_fault.fault_info1.byte4.byte);
//    log_d("bmuFault1_5=%x\n", g_bmu_data_unify.all_pack_inner_fault.fault_info1.byte5.byte);
//    log_d("bmuFault1_6=%x\n", g_bmu_data_unify.all_pack_inner_fault.fault_info1.byte6.byte);
//    log_d("bmuFault1_7=%x\n", g_bmu_data_unify.all_pack_inner_fault.fault_info1.byte7.byte);

//    log_d("bmuFault2_0=%x\n", g_bmu_data_unify.all_pack_inner_fault.fault_info2.byte0.byte);
//    log_d("bmuFault2_1=%x\n", g_bmu_data_unify.all_pack_inner_fault.fault_info2.byte1.byte);
//    log_d("bmuFault2_2=%x\n", g_bmu_data_unify.all_pack_inner_fault.fault_info2.byte2.byte);
//    log_d("bmuFault2_3=%x\n", g_bmu_data_unify.all_pack_inner_fault.fault_info2.byte3.byte);
//    log_d("bmuFault2_4=%x\n", g_bmu_data_unify.all_pack_inner_fault.fault_info2.byte4.byte);
//    log_d("bmuFault2_5=%x\n", g_bmu_data_unify.all_pack_inner_fault.fault_info2.byte5.byte);
//    log_d("bmuFault2_6=%x\n", g_bmu_data_unify.all_pack_inner_fault.fault_info2.byte6.byte);
//    log_d("bmuFault2_7=%x\n", g_bmu_data_unify.all_pack_inner_fault.fault_info2.byte7.byte);
    
}

void bmu_data_debug_err_printf(void)
{
//    log_d(" bmu param err\r\n");
//    log_d(" bmu print : printf data\r\n");
//    log_d(" bmu id pack_id(1-%d) di_id(0~%d): printf di status\r\n", PACK_MAX_NUM, BMS_DI_TYPE_NUM - 1);
//    log_d(" bmu help : printf hlep data\r\n");
//    log_d(" bmu val debug(0/1) data_id(0~%d) val: set analog data\r\n", DEBUG_VAL_NUM - 1);
}

/**
 * @brief                BMU help打印
 * @return               返回结果空
 * @warning              测试调试使用
 */
void bmu_data_debug_help_printf(void)
{
//    log_e("val_id:\n");
//    log_e("DEBUG_ACC_PACK_VOLT          = %d\n", DEBUG_ACC_PACK_VOLT         );
}

/**
 * @brief        sample_debug功能样例
 * @param        cmd 功能参数
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
static int bmu_data(int argc, char *argv[])
{
    if (argc < 2)
    {
        log_d("bmuParaErr\n");
        return SF_ERR_PARA;
    }

    if (!strcmp(argv[1], "print"))
    {
        bmu_data_debug_printf();
    }
    else if (!strcmp(argv[1], "di"))
    {
        if (argc < 4)
        {
            log_d("bmuDiErr\n");
            return SF_ERR_PARA;
        }
        uint32_t pack_id = atoi(argv[2]);      // 参数1: 
        int32_t di_id = atoi(argv[3]);        // 参数2：value值
        int8_t di_status = bmu_di_status_get(pack_id, (bmu_di_data_type)di_id);
        log_e("[pack%d]diStatus[%d]=%d\n", pack_id, di_id, di_status);
    }
    else if (!strcmp(argv[1], "val"))
    {
        if (argc < 5)
        {
            log_d("bmuValErr\n");
            return SF_ERR_PARA;
        }
        uint32_t debug_flag = atoi(argv[2]);  // 设置参数1：debug标志（1使能，0取消）
        uint32_t val_id = atoi(argv[3]);      // 参数2: 模拟量sample_value_debug_e
        int32_t value = atoi(argv[4]);        // 参数3：value值
        g_simulate_test_flag = debug_flag;
        bmu_data_value_set_debug(debug_flag, val_id, value);
    }
    else if (!strcmp(argv[1], "help"))
    {
        bmu_data_debug_help_printf();
    }
    else
    {
        bmu_data_debug_err_printf();
        return SF_ERR_PARA;
    }
    return SF_OK; 
}
MSH_CMD_EXPORT(bmu_data, <print/di packId diId stu/val debugFlag valId vaule>);
#endif

