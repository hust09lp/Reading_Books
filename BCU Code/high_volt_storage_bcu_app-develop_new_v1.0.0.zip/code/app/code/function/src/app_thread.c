#include "app_thread.h"
#include "sdk.h"
#include "sdk_osif.h"
#include "sdk_core.h"
#include "data_types.h"
#include "app_public.h"
#include "relay_manage.h"
#include "auto_addressing.h"
#include "sofar_can_manage.h"
#include "inner_can_data.h"
#include "external_can_data.h"
#include "bms_state.h"
#include "fault_manage.h"
#include "insulation_impedance_calc.h"
#include "sample.h"
#include "upgrade.h"
#include "upgrade_master.h"
#include "cell_balance.h"
#include "sox.h"
#include "sop.h"
#include "data_store.h"
#include "addressing_common.h"
#include "file_read.h"
#include "fan_ctrl.h"
#include "data_store.h"
#include "bmu_data.h"
#include "led.h"
#include "ate.h"
#include "parallel_manage.h"
#include "bcu_data.h"
#include "public_flag.h"

/* 线程参数结构定义 */
uint32_t g_data_store_thread_stack[4096/4];	// 数据保存任务堆栈大小 优先级47
uint32_t g_5ms_thread_stack[4096/4];		// 5ms任务堆栈大小   优先级46
uint32_t g_10ms_thread_stack[4096/4];     	// 10ms任务堆栈大小  优先级45
uint32_t g_100ms_thread_stack[2048/4];		// 100ms任务堆栈大小 优先级44

static void app_100ms_thread(void *argument);
static void app_10ms_thread(void *argument);
static void app_5ms_thread(void *argument);
static void app_data_store_thread(void *argument);

/* app线程定义 */
static sdk_os_thread_attr_tab_t g_thread_attr_tab[] =
{
	{{"app_100ms", 0, NULL,  0, 10, (void *)g_100ms_thread_stack, sizeof(g_100ms_thread_stack), OS_APP_PRIORITY_1, 0},
	   app_100ms_thread , NULL},

	{{"app_10ms",  0, NULL,  0, 10, (void *)g_10ms_thread_stack , sizeof(g_10ms_thread_stack) , OS_APP_PRIORITY_2, 0},
	   app_10ms_thread , NULL},

	{{"app_5ms",   0, NULL,  0, 10, (void *)g_5ms_thread_stack  , sizeof(g_5ms_thread_stack)  , OS_APP_PRIORITY_3, 0},
	   app_5ms_thread , NULL},

	{{"app_data_store",   0, NULL,  0, 10, (void *)g_data_store_thread_stack  , sizeof(g_data_store_thread_stack)  , OS_APP_PRIORITY_4, 0},
	   app_data_store_thread , NULL},

};

/**
* @brief        数据保存任务，任务内部不允许阻塞延时
* @param        void
* @return       执行结果
*/
static void app_data_store_thread(void *argument)
{
	static uint32_t timestamp = 0;
	timestamp = sdk_tick_get();
	while(1)
	{
		data_store_thread();
		os_delay_until(&timestamp,TICK_10MS);
	}
}

/**
* @brief        5ms任务，任务内部不允许阻塞延时
* @param        void
* @return       执行结果
*/
static void app_5ms_thread(void *argument)
{
	static uint32_t timestamp = 0;
	upgrade_init();
	upgrade_master_init();
	fault_recording_init();
	timestamp = sdk_tick_get();
	while(1)
	{
		upgrade_task_proc();
		upgrade_master_task_proc();
		fault_recording_proc();
		os_delay_until(&timestamp,TICK_5MS);
	}
}


/**
* @brief        10ms任务，任务内部不允许阻塞延时
* @param        void
* @return       执行结果
*/
static void app_10ms_thread(void *argument)
{
	static uint32_t timestamp = 0;
	relay_manage_init();
	inner_can_sofar_manage_init();
	ext_can_sofar_manage_init();
	cluster_can_sofar_manage_init();
	can_inner_data_init();
	can_ext_data_init();
	inner_auto_addr_init();
	fault_manage_init();
    sample_init();
    ex_addressing_manage_init();
    bms_state_init();
	file_read_init();
    bmu_data_init();
    cluster_bcu_data_init();
	timestamp = sdk_tick_get();
	while(1)
	{
		// 采样
        sample_proc();
        // bmu数据综合
        bmu_data_proc();
        // 故障诊断(10ms)
		fault_manage_task();
		// 继电器管理
		relay_manage_proc();
        // bcu数据统计
        bcu_data_proc();
        // CAN管理(10ms)
        inner_can_sofar_rcv_frame_proc();
        ext_can_sofar_rcv_frame_proc();
        cluster_can_sofar_rcv_frame_proc();
		can_inner_data_send_proc();
        can_inner_req_data_proc();
		can_ext_data_send_proc();
		// event_send_dev_msg();
		send_bmu_act_bal_ctrl();
		send_bmu_dsg_cali_ctrl();
		// 自动编址(10ms)
		inner_auto_addressing_proc();
        ex_addressing_manage_proc();
        // bms状态管理(10ms)
		bms_state_proc();
        led_manage();
		file_read_proc();
		//被动均衡管理
		cluster_passive_proc();
        // sop置0事件处理
        sop_zero_event_send_deal();
        // 并机管理模块
        parallel_manage_proc();
        // 风扇控制模块        
        fan_ctrl_proc();
        // 公共标志打印
        public_flag_task();

		os_delay_until(&timestamp,TICK_10MS);
	}
}

/**
* @brief        100ms任务，任务内部不允许阻塞延时
* @param        void
* @return       执行结果
*/
static void app_100ms_thread(void *argument)
{
	static uint32_t timestamp = 0;
    sox_init();
    sop_init();
	// fan_ctrl_init();
    ate_mode_init();
	timestamp = sdk_tick_get();
    while(1)
    {
        insulation_impedance_calc_proc();
        sox_proc_deal();
        sop_proc_deal();
        ate_mode_proc();
        os_delay_until(&timestamp,TICK_100MS);
    }
}


/**
* @brief        App主函数入口, 本身属于core层创建的一个供app独立使用的线程
* @param        void
* @return       执行结果
*/
int32_t app_thread_creat(void)
{
    int32_t result;
    result = os_thread_new(ITEM_NUM(g_thread_attr_tab), g_thread_attr_tab);
    if (-1 == result)
	{
		log_e("app thread creat failed!\n");
	}
	else
	{
		log_i("app thread creat sucess!\n");
	}

    return result;
}

/**
* @brief        app的main函数，这里只有是在app和core合并的时候才需要调用该函数
* @param        void
* @return       执行结果
*/
int32_t app_main(void)
{
    char  sdk_version_buff[16];
    //sdk_shell_regist(app_msh_get_cmd);
    core_app_api_init();
    //打印boot版本
    memset(sdk_version_buff, 0x00, sizeof(sdk_version_buff));
    sdk_version_get(BOOT_VERSION_TYPE, (int8_t *)sdk_version_buff, sizeof(sdk_version_buff));
    log_i("\nboot version: %s\r\n", sdk_version_buff);

    //打印core版本
    memset(sdk_version_buff, 0x00, sizeof(sdk_version_buff));
    sdk_version_get(SDK_VERSION_TYPE, (int8_t *)sdk_version_buff, sizeof(sdk_version_buff));
    log_i("\ncore sdk version: %s\r\n", sdk_version_buff);
	log_i("\napp version: %s\r\n", SOFTWARE_VERSION);

    //打印复位原因
    log_d("cpuResetFlag: %d\n", sdk_cpu_reset_flag_get());

    data_store_init();
    app_thread_creat();

    return true;
}








