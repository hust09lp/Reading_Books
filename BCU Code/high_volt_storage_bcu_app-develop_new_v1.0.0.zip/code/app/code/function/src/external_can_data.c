#include "external_can_data.h"
#include "sofar_can_manage.h"
#include "sdk.h"
#include "sdk_core.h"
#include "auto_addressing.h"
#include "sdk_public.h"
#include "data_store.h"
#include "fault_manage.h"
#include "relay_manage.h"
#include "sop.h"
#include "sox.h"
#include "ate.h"
#include "addressing_common.h"
#include "bmu_data.h"
#include "app_public.h"
#include "bms_state.h"
#include "insulation_impedance_calc.h"
#include "ate.h"
#include "led.h"
#include "ext_auto_addressing.h"
#include "data_store.h"
#include "bcu_data.h"
#include "relay_manage.h"
#include "public_flag.h"
#include "inner_can_data.h"
#include "sox_stats.h"

#define UINT16_BIT_NUM (16)
#define CAN_SEND_READY_FLAG_NUM ((EX_CAN_TX_FRAME_NUM + UINT16_BIT_NUM - 1) / UINT16_BIT_NUM)
#define PACK_SN_IN_FRAME_LEN 7
#define BOARD_SN_IN_FRAME_LEN 7
#define CELL_TEMP_NUM 8
#define RATE_POWER_W  2524
#define PACK_ID_OFFSET  (1)

// 接收处理任务数组定义
typedef struct 
{
    uint16_t func_code;
    bool (*p_func_recv_deal_cb)(can_frame_data_t *can_data, uint16_t func_code);
} ex_can_rx_msg_tcb_t;

// 接收处理任务数组定义
typedef struct 
{
    uint8_t id;
    bool (*p_func_recv_deal_cb)(can_frame_data_t *can_data, uint16_t func_code);
} ex_can_tx_msg_tcb_t;

typedef bool(*ex_can_sofar_tx_callback)(can_frame_data_t *can_data, uint16_t func_code);


/************************************* 参数读取函数原型 BEGIN *************************************/

//static uint16_t upper_sys_can_send_flag_get(void);

/************************************* 参数读取函数原型 END ***************************************/


/************************************* 参数设置函数原型 BEGIN *************************************/

//static int8_t aging_mode_request(uint16_t value);
//static int8_t cali_mode_request(uint16_t value);
//static int8_t ate_mode_request(uint16_t value);
//static int8_t upper_sys_can_send_flag_set(uint16_t value);
//static int8_t force_ctrl_mode_request(uint16_t value);
//static int8_t cali_resume_default(uint16_t value);

/************************************* 参数设置函数原型 END ***************************************/


/************************************* 外can接收任务函数原型 BEGIN *************************************/
static bool ex_rx_gold_project_info_req(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_sensor_data_req(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_clu_volt_over_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_clu_volt_down_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_chg_curr_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_dsg_curr_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_chg_cell_temp_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_cell_temp_dis_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_soc_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_inv_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_cell_volt_over_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_cell_volt_down_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_cell_volt_dis_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_mode_temp_over_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_sys_rtc_data(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_sys_arch_para(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_cell_main_para(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_set_sox_para(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_dsg_cell_temp_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_cfg_table_req(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_cmu_set_addr(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_pack_volt_over_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_pack_volt_down_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_cell_data_req(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_ver_data_req(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_set_pass_bal_state_req(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_test_force_bal(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_test_force_do(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_inner_address(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_cmu_power_ctl(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_cmu_ins_ctl(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_clu_summary(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_clu_cell_summary(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_clu_alm_summary(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_mas_clu_ctl(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_maintenance(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_rx_gold_out_clu_ctl(can_frame_data_t *can_data, uint16_t func_code);

static bool ext_can_rx_ate_flash_test(can_frame_data_t *can_data, uint16_t func_code);
static bool ext_can_rx_ate_mode_ctl(can_frame_data_t *can_data, uint16_t func_code);
static bool ext_can_rx_ate_cali_time(can_frame_data_t *can_data, uint16_t func_code);
static bool ext_can_rx_ate_set_pack_sn(can_frame_data_t *can_data, uint16_t func_code);
static bool ext_can_rx_ate_set_board_sn(can_frame_data_t *can_data, uint16_t func_code);
static bool ext_can_rx_ate_bcu_func_sw_ctl(can_frame_data_t *can_data, uint16_t func_code);
static bool ext_can_rx_ate_monitor_rd(can_frame_data_t *can_data, uint16_t func_code);
static bool ext_can_rx_ate_cali_para_ctl(can_frame_data_t *can_data, uint16_t func_code);
static bool ext_can_rx_ate_force_ctl(can_frame_data_t *can_data, uint16_t func_code);
/************************************* 外can接收任务函数原型 END *************************************/


/************************************* 外can发送任务函数原型 BEGIN *************************************/
static bool ex_tx_gold_project_info_req(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_sensor_data_req(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_clu_volt_over_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_clu_volt_down_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_chg_curr_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_dsg_curr_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_chg_cell_temp_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_cell_temp_dis_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_soc_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_inv_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_cell_volt_over_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_cell_volt_down_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_cell_volt_dis_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_mode_temp_over_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_sys_rtc_data(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_sys_arch_data(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_cell_main_para(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_set_sox_para(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_dsg_cell_temp_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_pack_volt_over_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_pack_volt_down_alm(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_cell_volt_ack(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_cell_temp_ack(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_power_terminal_tmep_ack(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_cell_soc_ack(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_cell_soh_ack(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_sample_ack(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_sys_summary_ack(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_pack_num_data_ack(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_warn_data_ack(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_dido_data_ack(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_temp_num_data_ack(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_pack_bal_data_ack(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_sla_unlink_ack(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_wire_open_ack(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_fault_data_ack(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_ver_data_ack(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_cmu_ins_ctl(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_clu_summary(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_clu_cell_summary(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_clu_alm_summary(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_mas_clu_ctl(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_alm_reason(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_maintenance(can_frame_data_t *can_data, uint16_t func_code);
static bool ex_tx_gold_out_clu_ctl(can_frame_data_t *can_data, uint16_t func_code);

/*****************************************ATE相关************************************************************************/
static bool ext_can_tx_ate_flash_test(can_frame_data_t *can_data, uint16_t func_code);
static bool ext_can_tx_ate_mode_ctl(can_frame_data_t *can_data, uint16_t func_code);
static bool ext_can_tx_ate_cali_time(can_frame_data_t *can_data, uint16_t func_code);
static bool ext_can_tx_ate_set_pack_sn(can_frame_data_t *can_data, uint16_t func_code);
static bool ext_can_tx_ate_set_board_sn(can_frame_data_t *can_data, uint16_t func_code);
static bool ext_can_tx_ate_bcu_func_sw_ctl(can_frame_data_t *can_data, uint16_t func_code);
static bool ext_can_tx_ate_cali_para_ctl(can_frame_data_t *can_data, uint16_t func_code);
static bool ext_can_tx_ate_force_ctl(can_frame_data_t *can_data, uint16_t func_code);
static bool ext_can_tx_bcu_self_state(can_frame_data_t *can_data, uint16_t func_code);
static bool ext_can_tx_bcu_self_temp(can_frame_data_t *can_data, uint16_t func_code);
static bool ext_can_tx_bcu_self_volt1(can_frame_data_t *can_data, uint16_t func_code);
static bool ext_can_tx_bcu_self_curr(can_frame_data_t *can_data, uint16_t func_code);
static bool ext_can_tx_bcu_self_ver(can_frame_data_t *can_data, uint16_t func_code);
static bool ext_can_tx_bcu_self_time(can_frame_data_t *can_data, uint16_t func_code);
static bool ext_can_tx_bcu_other_data(can_frame_data_t *can_data, uint16_t func_code);
static bool ext_can_tx_bcu_self_val_result(can_frame_data_t *can_data, uint16_t func_code);




    
/************************************* 外can发送任务函数原型 END *************************************/
// 注意点：添加新协议时，要先确定优先级来在填充，
// 比如要加一个优先级为0x03，在EX_RX_GOLD_CMU_POWER_CTL前添加;  要加优先级0x01，在EX_RX_GOLD_PC_CTL_CLU之后添加
// 当前不打算增加新的优先级协议帧
// funcode 必须从小到大排序
const ex_can_rx_msg_tcb_t g_ext_rx_can_msg_prio_0x11_list[] = 
{
    // 优先级为0x03
    // 配置表类 
    { GOLD_FUNC_PROJECT_INFO_REQ_CMD  ,  ex_rx_gold_project_info_req   },   //项目（硬件）信息
    { GOLD_FUNC_SENSOR_DATA_REQ_CMD   ,  ex_rx_gold_sensor_data_req    },  // 传感器报文
    { GOLD_FUNC_CLU_VOLT_OVER_ALM_CMD ,  ex_rx_gold_clu_volt_over_alm  },  // 组端总电压上限报警值
    { GOLD_FUNC_CLU_VOLT_DOWN_ALM_CMD ,  ex_rx_gold_clu_volt_down_alm  },  // 组端总电压下限报警值
    { GOLD_FUNC_CHG_CURR_ALM_CMD      ,  ex_rx_gold_chg_curr_alm       },  // 充电电流报警值
    { GOLD_FUNC_DSG_CURR_ALM_CMD      ,  ex_rx_gold_dsg_curr_alm       },  // 放电电流报警值
    { GOLD_FUNC_CHG_CELL_TEMP_ALM_CMD ,  ex_rx_gold_chg_cell_temp_alm  },  // 充电单体电池温度报警值
    { GOLD_FUNC_CELL_TEMP_DIS_ALM_CMD ,  ex_rx_gold_cell_temp_dis_alm  },  // 单体电池温差报警值
    { GOLD_FUNC_SOC_ALM_CMD           ,  ex_rx_gold_soc_alm            },  //  SOC 报警值
    { GOLD_FUNC_INV_ALM_CMD           ,  ex_rx_gold_inv_alm            },  // 绝缘电阻报警值
    { GOLD_FUNC_CELL_VOLT_OVER_ALM_CMD,  ex_rx_gold_cell_volt_over_alm },  // 电池单体电压上限报警值
    { GOLD_FUNC_CELL_VOLT_DOWN_ALM_CMD,  ex_rx_gold_cell_volt_down_alm },  // 电池单体电压下限报警值
    { GOLD_FUNC_CELL_VOLT_DIS_ALM_CMD ,  ex_rx_gold_cell_volt_dis_alm  },  // 电池单体电压压差报警值
    { GOLD_FUNC_MODE_TEMP_OVER_ALM_CMD,  ex_rx_gold_mode_temp_over_alm },  // 模块温度上限报警值
    { GOLD_FUNC_SYS_RTC_DATA_CMD      ,  ex_rx_gold_sys_rtc_data       },  // RTC 数据
    { GOLD_FUNC_SYS_ARCH_CMD          ,  ex_rx_gold_sys_arch_para      },  // 从控模块基本参数    
    { GOLD_FUNC_CELL_MAIN_PARA_CMD    ,  ex_rx_gold_cell_main_para     },  // 电池主参数
    { GOLD_FUNC_SET_SOX_PARA_CMD      ,  ex_rx_gold_set_sox_para       },  // 设置 SOC 参数
    { GOLD_FUNC_DSG_CELL_TEMP_ALM_CMD ,  ex_rx_gold_dsg_cell_temp_alm  },  // 放电单体电池温度报警值
    { GOLD_FUNC_CFG_TABLE_REQ_CMD     ,  ex_rx_gold_cfg_table_req      },  // 后台软件下发查询配置表消息 命令码 0x02，BYTE2 为模块地址命令码, 0x06 BYTE2 充电类型命令码, 0x1B BYTE2 充放电标志
    { GOLD_FUNC_CMU_SET_ADDR_CMD      ,  ex_rx_gold_cmu_set_addr       },  // 主控地址设置命令码
    { GOLD_FUNC_PACK_VOLT_OVER_ALM_CMD,  ex_rx_gold_pack_volt_over_alm },  // 电池模组电压上限报警值
    { GOLD_FUNC_PACK_VOLT_DOWN_ALM_CMD,  ex_rx_gold_pack_volt_down_alm },  // 电池模组电压下限报警值
    // 电池信息数据类                                                                                             
    { GOLD_FUNC_CELL_DATA_REQ_CMD     ,  ex_rx_gold_cell_data_req      },  // 请求电池采集消息
    // 版本控制类                                                                                                 
    { GOLD_FUNC_VER_DATA_REQ_CMD      ,  ex_rx_gold_ver_data_req       },  // PC 请求查询版本号消息
    // 设置被动均衡
    { GOLD_FUNC_SET_PASS_BAL_STATE_CMD,  ex_rx_gold_set_pass_bal_state_req},  // PC 请求查询版本号消息
    // 测试类                                                                                                     
    { GOLD_FUNC_TEST_FORCE_BAL_CMD    ,  ex_rx_gold_test_force_bal     },  // 发送强制均衡命令-主动均衡
    { GOLD_FUNC_TEST_FORCE_DO_CMD     ,  ex_rx_gold_test_force_do      },  // PC 发送设置 EVBCM 模块 DO 输出命令
    // 编址类
    { GOLD_FUNC_INNER_ADDRESS_CMD     ,  ex_rx_gold_inner_address      },  // 发送内部编址
    // 簇间通讯功能码                                                                                             
    { GOLD_FUNC_CLU_SUMMARY_CMD       ,  ex_rx_gold_clu_summary        },  // 组端概要信息
    { GOLD_FUNC_CLU_CELL_SUMMARY_CMD  ,  ex_rx_gold_clu_cell_summary   },  // 单体概要信息
    { GOLD_FUNC_CLU_ALM_SUMMARY_CMD   ,  ex_rx_gold_clu_alm_summary    },  // 告警信息
    { GOLD_FUNC_MAINTENANCE_CMD       ,  ex_rx_gold_maintenance        },  //  8133维护信息
};

const ex_can_rx_msg_tcb_t g_ext_rx_can_msg_prio_0x01_list[] = 
{
    // 优先级为0x1
    // 主控控制类                                                                                                 
    { GOLD_FUNC_CMU_POWER_CTL_CMD     ,  ex_rx_gold_cmu_power_ctl },  // 控制主控上下电指令
    { GOLD_FUNC_CMU_INS_CTL_CMD       ,  ex_rx_gold_cmu_ins_ctl   },   // 控制主控绝缘检测功能指令
    // 簇间通讯功能码 
    { GOLD_FUNC_MAS_CLU_CTL_CMD       ,  ex_rx_gold_mas_clu_ctl        },  // 主 8133 控制命令
    { GOLD_FUNC_OUT_CLU_CTL_CMD       ,  ex_rx_gold_out_clu_ctl        },  // 退簇信息
};

// 必须与ext_tx_frame_data_id_e 顺序一致
const ex_can_tx_msg_tcb_t g_ext_tx_can_msg_list[] =
{
    // 查询类
    { EX_TX_GOLD_ALARM_DATA_ACK   , ex_tx_gold_warn_data_ack       },
    { EX_TX_GOLD_DIDO_DATA_ACK    , ex_tx_gold_dido_data_ack       },
    { EX_TX_GOLD_FAULT_DATA_ACK   , ex_tx_gold_fault_data_ack      },
    // 主控控制类                      
    { EX_TX_GOLD_CMU_INS_CTL      , ex_tx_gold_cmu_ins_ctl         },  // 控制主控绝缘检测功能指令 0x81
    // 簇间通讯功能码
    { EX_TX_GOLD_CLU_SUMMARY      , ex_tx_gold_clu_summary         },  // 组端概要信息 0x90
    { EX_TX_GOLD_CLU_CELL_SUMMARY , ex_tx_gold_clu_cell_summary    },  // 单体概要信息 0x91
    { EX_TX_GOLD_CLU_ALM_SUMMARY  , ex_tx_gold_clu_alm_summary     },  // 告警信息     0x92
    { EX_TX_GOLD_MAS_CLU_CTL      , ex_tx_gold_mas_clu_ctl         },  // 主 8133 控制命令  0x493
    { EX_TX_GOLD_ALM_REASON       , ex_tx_gold_alm_reason          },  // 禁充禁放告警原因信息 0x494
    { EX_TX_GOLD_MAINTENANCE      , ex_tx_gold_maintenance         },  //  8133维护信息  0x95
};

const can_cycle_send_tcb_t g_can_msg_cycle_send_list[] =
{
    { CYCLE_MSG_CLU_DATA1_ID  , CLU_INFO_DATA_SEND_REQ  , 0  ,  CYCLE_SEND_1200MS , -1  },
    { CYCLE_MSG_CLU_DATA2_ID  , CLU_INFO_DATA2_SEND_REQ , 10  , CYCLE_SEND_2000MS , -1  },
    { CYCLE_MSG_INS_DATA_ID   , INS_ENBAL_DATA_SEND_REQ , 20  , CYCLE_SEND_1000MS , -1  },
    { CYCLE_MSG_YX_DATA_ID    , CLU_YX_DATA_SEND_REQ    , 30  , CYCLE_SEND_500MS  , -1  },
};

const ex_can_rx_msg_tcb_t g_ex_can_rx_ate_msg_list[] =
{
   // ate设置其他控制和标定（外can）
   {FUNC_ATE_FLASH_TEST              ,  ext_can_rx_ate_flash_test              }, // ATE_FLASH测试
   {FUNC_ATE_MODE_CTL                ,  ext_can_rx_ate_mode_ctl                }, // 上位机控制老化状态
   {FUNC_ATE_CALI_TIME               ,  ext_can_rx_ate_cali_time               }, // 时间标定
   {FUNC_ATE_SET_PACK_SN             ,  ext_can_rx_ate_set_pack_sn             }, // PACK_SN标定
   {FUNC_ATE_SET_BOARD_SN            ,  ext_can_rx_ate_set_board_sn            }, // BOARD_SN标定
   {FUNC_ATE_BCU_FUNC_SW_CTL         ,  ext_can_rx_ate_bcu_func_sw_ctl         }, // BCU功能开关
   {FUNC_ATE_MONITOR_RD              ,  ext_can_rx_ate_monitor_rd              }, // 上位机监控读取
   {FUNC_ATE_CALI_PARA_CTL           ,  ext_can_rx_ate_cali_para_ctl           }, // 一键操作标定参数
   {FUNC_ATE_FORCE_CTL               ,  ext_can_rx_ate_force_ctl               }, // ATE强制控制指令
};

// 必须与ate_data_id_e 顺序一致
const can_msg_tcb_t g_ex_can_tx_ate_msg_list[] =
{   
    // ate设置其他控制和标定（外can） 
    { EXT_CAN_TX_ATE_FLASH_TEST                , FUNC_ATE_FLASH_TEST              ,  ext_can_tx_ate_flash_test              },  // ATE_FLASH测试           
    { EXT_CAN_TX_ATE_MODE_CTL                  , FUNC_ATE_MODE_CTL                ,  ext_can_tx_ate_mode_ctl                },  // 上位机控制老化状态   
    { EXT_CAN_TX_ATE_CALI_TIME                 , FUNC_ATE_CALI_TIME               ,  ext_can_tx_ate_cali_time               },  // 时间标定                
    { EXT_CAN_TX_ATE_SET_PACK_SN               , FUNC_ATE_SET_PACK_SN             ,  ext_can_tx_ate_set_pack_sn             },  // PACK_SN标定             
    { EXT_CAN_TX_ATE_SET_BOARD_SN              , FUNC_ATE_SET_BOARD_SN            ,  ext_can_tx_ate_set_board_sn            },  // BOARD_SN标定            
    { EXT_CAN_TX_ATE_BCU_FUNC_SW_CTL           , FUNC_ATE_BCU_FUNC_SW_CTL         ,  ext_can_tx_ate_bcu_func_sw_ctl         },  // BCU功能开关      
    { EXT_CAN_TX_ATE_CALI_PARA_CTL             , FUNC_ATE_CALI_PARA_CTL           ,  ext_can_tx_ate_cali_para_ctl           },  // 一键操作标定参数        
    { EXT_CAN_TX_ATE_FORCE_CTL                 , FUNC_ATE_FORCE_CTL               ,  ext_can_tx_ate_force_ctl               },  // ATE强制控制指令
    // 数据查询（外can） 
    { EXT_CAN_TX_BCU_SELF_STATE                , FUNC_BCU_SELF_STATE              ,  ext_can_tx_bcu_self_state              }, // 0x0B6:BCU遥信数据上报1--状态
    { EXT_CAN_TX_BCU_SELF_TEMP                 , FUNC_BCU_SELF_TEMP               ,  ext_can_tx_bcu_self_temp               }, // 0x0B7:BCU遥测数据上报1--温度采样数据
    { EXT_CAN_TX_BCU_SELF_VOLT1                , FUNC_BCU_SELF_VOLT1              ,  ext_can_tx_bcu_self_volt1              }, // 0x0B8:BCU遥测数据上报2--电压采样
    { EXT_CAN_TX_BCU_SELF_CURR                 , FUNC_BCU_SELF_CURR               ,  ext_can_tx_bcu_self_curr               }, // 0x0B9:BCU遥测数据上报3---电流采样
    { EXT_CAN_TX_BCU_SELF_VER                  , FUNC_BCU_SELF_VER                ,  ext_can_tx_bcu_self_ver                }, // 0x0BD:BCU版本号信息
    { EXT_CAN_TX_BCU_SELF_TIME                 , FUNC_BCU_SELF_TIME               ,  ext_can_tx_bcu_self_time               }, // 0x0C0:BCU系统时间
    { EXT_CAN_TX_BCU_SELF_OTHER_DATA           , FUNC_BCU_SELF_OTHER_DATA         ,  ext_can_tx_bcu_other_data              }, // 0x0C1:BCU其他数据--绝缘阻抗等
    { EXT_CAN_TX_BCU_SELF_VAL_RESULT           , FUNC_BCU_SELF_VAL_RESULT         ,  ext_can_tx_bcu_self_val_result         }, // 0x0C2:测试结果/其他参数(一般用于ate测试)
};

// 0x0F7:上位机监控读取0x10F7XXE0
const uint8_t g_bcu_monitor_data_list[] = 
{
    EXT_CAN_TX_BCU_SELF_STATE               , //0  0x0B6:BCU遥信数据上报1--状态
    EXT_CAN_TX_BCU_SELF_TEMP                , //1  0x0B7:BCU遥测数据上报1--温度采样数据
    EXT_CAN_TX_BCU_SELF_VOLT1               , //2  0x0B8:BCU遥测数据上报2--电压采样
    EXT_CAN_TX_BCU_SELF_CURR                , //3  0x0B9:BCU遥测数据上报3---相关电流采样
    EXT_CAN_TX_BCU_SELF_VER                 , //7  0x0BD:BCU版本号信息
    EXT_CAN_TX_BCU_SELF_TIME                , //10 0x0C0:BCU系统时间
    EXT_CAN_TX_BCU_SELF_OTHER_DATA          , //11 0x0C1:BCU其他数据，例如绝缘阻抗等
    EXT_CAN_TX_BCU_SELF_VAL_RESULT          , //12 0x0C2:测试结果/其他参数(一般用于ate测试)
};
static uint8_t g_can_msg_cycle_send_list_len = sizeof(g_can_msg_cycle_send_list) / sizeof(g_can_msg_cycle_send_list[0]);
static uint16_t g_can_msg_cycle_cnt[CYCLE_MSG_CNT] = {0};
static uint16_t g_can_msg_cycle_first_flag[CYCLE_MSG_CNT] = {0};
static uint16_t g_can_msg_cycle_max_cnt[CYCLE_MSG_CNT] = {0};

const uint8_t g_ext_rx_can_msg_prio_0x11_list_len = sizeof(g_ext_rx_can_msg_prio_0x11_list) / sizeof(g_ext_rx_can_msg_prio_0x11_list[0]);
const uint8_t g_ext_rx_can_msg_prio_0x01_list_len = sizeof(g_ext_rx_can_msg_prio_0x01_list) / sizeof(g_ext_rx_can_msg_prio_0x01_list[0]);
const uint8_t g_ext_tx_can_msg_list_len = sizeof(g_ext_tx_can_msg_list) / sizeof(g_ext_tx_can_msg_list[0]);

const uint8_t g_bcu_monitor_data_list_len = sizeof(g_bcu_monitor_data_list) / sizeof(g_bcu_monitor_data_list[0]);
const uint8_t g_ext_rx_can_ate_msg_list_len = sizeof(g_ex_can_rx_ate_msg_list) / sizeof(g_ex_can_rx_ate_msg_list[0]);
const uint8_t g_ext_tx_can_ate_msg_list_len = sizeof(g_ex_can_tx_ate_msg_list) / sizeof(g_ex_can_tx_ate_msg_list[0]);

static uint16_t g_can_send_ready_flag[CAN_SEND_READY_FLAG_NUM] = {0};
static cali_para_query_e g_cali_para_result = ATE_CALI_NON;

static uint8_t g_ext_send_data_type = EXT_AUTO_SEND_FORBID_TYPE;		//CAN网使能标志位
static uint8_t g_upper_sys_con_flag = false;                            //上位机使能can发送接口

static uint8_t g_cmu_power_ctrl_type = 0;


/***************************************************************外can发送接收预处理函数start*********************************************/
// 填充发送数据
// 使用注意，不要越界，fill_data + fill_len 不能超过数组长度
static void fill_can_data_buff(uint32_t fill_data, uint8_t *fill_buff, uint8_t fill_len)
{
    if (NULL == fill_buff ||  (2 != fill_len && 4 != fill_len)) // 不是两个字节&&不是4个字节，认为异常
    {
        return ;
    }
    for (uint8_t i = 0; i < fill_len; i++)
    {
        fill_buff[i] = (uint8_t)(fill_data >> (i * 8));
    }
}

// 立即发送
bool ext_can_send_msg_no_ready(ext_tx_frame_data_id_e id)
{
    if (g_ext_tx_can_msg_list_len <= id)
    {
        return false;
    }
    uint8_t list_id = g_ext_tx_can_msg_list_len;
    if (g_ext_tx_can_msg_list[id].id == id)
    {
        list_id = id;
    }
    else
    {
        uint8_t list_cnt = 0;
        for (list_cnt = 0; list_cnt < g_ext_tx_can_msg_list_len; list_cnt++)
        {
            if (g_ext_tx_can_msg_list[list_cnt].id == id)
            {
                list_id = list_cnt;
                break;
            }
        }
        if (list_cnt == g_ext_tx_can_msg_list_len)
        {
            list_id = g_ext_tx_can_msg_list_len;
        }
    }
    // 无法匹配id，退出
    if (list_id == g_ext_tx_can_msg_list_len)
    {
        return false; 
    }
    if (NULL != g_ext_tx_can_msg_list[list_id].p_func_recv_deal_cb)
    {
        g_ext_tx_can_msg_list[id].p_func_recv_deal_cb(NULL, 0);
    }
    else // 无发送任务，报出异常
    {
        log_e("list%d cb_null\n",id);
    }
    return true;
}

// 请求发送can数据帧
// 由于是延迟处理，无法知道是主机还是上位机发送，
void ext_can_send_msg_ready(ext_tx_frame_data_id_e send_id)
{
    if (send_id >= EX_CAN_TX_FRAME_NUM)
    {
        return;
    }
    uint8_t ready_flag_group_id = send_id / UINT16_BIT_NUM;
    uint8_t ready_flag_id = send_id % UINT16_BIT_NUM;
    g_can_send_ready_flag[ready_flag_group_id] |= (1 << ready_flag_id);
}

/**
* @brief        canid数据转换
* @param        *tx_id：需要发送的canid，需要填充
* @param        rx_id：接收的canid
* @param        func_code：发送的功能码
* @return       执行结果
*/
static void can_id_dst_addr_fill(can_frame_id_u *tx_id, can_frame_id_u rx_id, uint16_t func_code)
{
    if (tx_id == NULL)
    {
        return;
    }
    tx_id->bit.src_addr = ext_addressing_manage_addr_get();
    tx_id->bit.src_type = DEV_BROADCAST;
    tx_id->bit.dst_addr = rx_id.bit.src_addr;
    tx_id->bit.dst_type = rx_id.bit.src_type;
    tx_id->bit.fun_code = func_code;
    tx_id->bit.prio = rx_id.bit.prio;
}

// 请求发送处理任务
void request_can_send_frame_deal(void)
{
    ext_tx_frame_data_id_e id = EX_CAN_TX_FRAME_NUM;
    for (uint8_t i = 0; i < CAN_SEND_READY_FLAG_NUM; i++)
    {
        for (uint8_t j = 0; j < UINT16_BIT_NUM; j++)
        {
            if (g_can_send_ready_flag[i] & (1 << j))
            {
                id = (ext_tx_frame_data_id_e)(i * UINT16_BIT_NUM + j);  // 找出对应发送id
                // 由于外部请求发送，一般都是回复主机，所以目的地址默认为BCU，地址0x1F
                ext_can_send_msg_no_ready(id);
                g_can_send_ready_flag[i] &= ~(1 << j); // 清零
            }
        }
    }
}

/**
* @brief    根据模块划分发送数据 
* @param    [in]can_data        使用数据的源类型，源地址，用于发送的目的地址和类型
* @param    [in]id              用于寻找id，填充数据内用
* @param    [in]is_ready_flag   true：延迟发送，false: 立即发送
* @warning  无 
*/
void module_ext_can_send_msg(uint8_t group_id)
{
    if (NO_MODULE_SEND_REQ == group_id || group_id >= EX_REQ_SEND_REQ_NUM)
    {
        return;
    }

    if (CLU_INFO_DATA_SEND_REQ == group_id)
    {
        ext_can_send_msg_no_ready(EX_TX_GOLD_CLU_SUMMARY);
        ext_can_send_msg_no_ready(EX_TX_GOLD_CLU_CELL_SUMMARY);
        ext_can_send_msg_no_ready(EX_TX_GOLD_MAINTENANCE);
    }
    else if(CLU_INFO_DATA2_SEND_REQ == group_id)
    {
        // ext_can_send_msg_no_ready(EX_TX_GOLD_CLU_ALM_SUMMARY); TODO 暂时屏蔽，后续需要放开
        ext_can_send_msg_no_ready(EX_TX_GOLD_ALM_REASON);
    }
    else if(INS_ENBAL_DATA_SEND_REQ == group_id)
    {
        ext_can_send_msg_no_ready(EX_TX_GOLD_CMU_INS_CTL);
    }
    else if(CLU_YX_DATA_SEND_REQ == group_id)
    {
        ext_can_send_msg_no_ready(EX_TX_GOLD_DIDO_DATA_ACK);
    }
}

void cycle_send_sofar_data_proc(void)
{
    if ((g_ext_send_data_type == EXT_AUTO_SEND_FORBID_TYPE) && 
        (g_upper_sys_con_flag == false))
    {
        memset(g_can_msg_cycle_first_flag, 0, sizeof(g_can_msg_cycle_first_flag));
        memset(g_can_msg_cycle_cnt, 0, sizeof(g_can_msg_cycle_cnt));
        return;
    }
    bool send_flag = 0;
    uint8_t cycle_id = 0;
    for (uint8_t i = 0; i < g_can_msg_cycle_send_list_len; i++)
    {
        cycle_id = g_can_msg_cycle_send_list[i].cycle_send_data_id;
        // 发送次数清空后，不再发送
        if (((g_can_msg_cycle_send_list[cycle_id].send_cnt != -1) && (g_can_msg_cycle_max_cnt[cycle_id] >= g_can_msg_cycle_send_list[cycle_id].send_cnt))|| 
            cycle_id >= CYCLE_MSG_CNT)
        {
            continue;
        }
        send_flag = false;
        g_can_msg_cycle_cnt[cycle_id]++;
        if (g_can_msg_cycle_first_flag[cycle_id] == 0)
        {
            if (g_can_msg_cycle_cnt[cycle_id] >= g_can_msg_cycle_send_list[cycle_id].first_delay)
            {
                g_can_msg_cycle_first_flag[cycle_id] = 1;
                send_flag = true;
            }
        }
        else
        {
            if (g_can_msg_cycle_cnt[cycle_id] >= g_can_msg_cycle_send_list[cycle_id].send_period)
            {
                send_flag = true;
            }
        }
        if (send_flag == true)
        {
            g_can_msg_cycle_cnt[cycle_id] = 0;
            module_ext_can_send_msg(g_can_msg_cycle_send_list[cycle_id].module_group_id);
            g_can_msg_cycle_max_cnt[cycle_id]++;
        }
    }
}

// 接收任务处理接口
int32_t ext_can_sofar_frame_parse_deal(can_frame_data_t *p_can_data)
{
    if (p_can_data == NULL)
    {
        return 0;
    }
    can_frame_id_u frame_id = {p_can_data->id};
    uint8_t left = 0;
    uint8_t right = 0;
    uint8_t mid = 0;
    if (frame_id.bit.prio == SOFAR_CAN_PRI_LOW_L)
    {
        right = g_ext_rx_can_msg_prio_0x11_list_len - 1;
        while(left <= right)
        {
            mid = left + (right - left) / 2; // 避免溢出
            
            if (g_ext_rx_can_msg_prio_0x11_list[mid].func_code == frame_id.bit.fun_code)
            {
                if (g_ext_rx_can_msg_prio_0x11_list[mid].func_code == frame_id.bit.fun_code)
                {
                    if (g_ext_rx_can_msg_prio_0x11_list[mid].p_func_recv_deal_cb != NULL)
                    {
                        g_ext_rx_can_msg_prio_0x11_list[mid].p_func_recv_deal_cb(p_can_data, frame_id.bit.fun_code);
                    }
                }
                break;
            }
            else if (g_ext_rx_can_msg_prio_0x11_list[mid].func_code < frame_id.bit.fun_code)
            {
                left = mid + 1;
            }
            else
            {
                right = mid - 1;
            }
        }
    }
    else if (frame_id.bit.prio == SOFAR_CAN_PRI_HIGH_L)
    {
        right = g_ext_rx_can_msg_prio_0x01_list_len - 1;
        while(left <= right)
        {
            mid = left + (right - left) / 2; // 避免溢出
            
            if (g_ext_rx_can_msg_prio_0x01_list[mid].func_code == frame_id.bit.fun_code)
            {
                if (g_ext_rx_can_msg_prio_0x01_list[mid].func_code == frame_id.bit.fun_code)
                {
                    if (g_ext_rx_can_msg_prio_0x01_list[mid].p_func_recv_deal_cb != NULL)
                    {
                        g_ext_rx_can_msg_prio_0x01_list[mid].p_func_recv_deal_cb(p_can_data, frame_id.bit.fun_code);
                    }
                }
                break;
            }
            else if (g_ext_rx_can_msg_prio_0x01_list[mid].func_code < frame_id.bit.fun_code)
            {
                left = mid + 1;
            }
            else
            {
                right = mid - 1;
            }
        }
    }
    else if (frame_id.bit.prio == SOFAR_CAN_PRI_LOW_H)
    {
        right = g_ext_rx_can_ate_msg_list_len - 1;
        while(left <= right)
        {
            mid = left + (right - left) / 2; // 避免溢出
            
            if (g_ex_can_rx_ate_msg_list[mid].func_code == frame_id.bit.fun_code)
            {
                if (g_ex_can_rx_ate_msg_list[mid].func_code == frame_id.bit.fun_code)
                {
                    if (g_ex_can_rx_ate_msg_list[mid].p_func_recv_deal_cb != NULL)
                    {
                        g_ex_can_rx_ate_msg_list[mid].p_func_recv_deal_cb(p_can_data, frame_id.bit.fun_code);
                    }
                }
                break;
            }
            else if (g_ex_can_rx_ate_msg_list[mid].func_code < frame_id.bit.fun_code)
            {
                left = mid + 1;
            }
            else
            {
                right = mid - 1;
            }
        }
    }

    return 0;
}

/***************************************************************外can发送接收预处理函数end*********************************************/

// 0x1E 回复帧处理
/**
 * @brief   0x1E 回复帧处理
 * @param   [in] can_frame_data_t *  接收到的配置帧
 * @param   [in] uint8_t 失败标志  1：失败； 0：成功
 * @param   [in] uint8_t err_code  0:无异常
 */
#define GOLD_CFG_TABLE_FAIL_FLAG  1
#define GOLD_CFG_TABLE_SUCC_FLAG  0
#define GOLD_CFG_TABLE_NO_ERR     0
#define GOLD_CFG_TABLE_PARA_ERR   1
static void ex_tx_gold_cfg_table_ack(can_frame_data_t *rx_can_data, uint8_t fail_flag, uint8_t err_code)
{
    if (rx_can_data == NULL)
    {
        return;
    }
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    memset(data, 0xFF, CAN_SIGNAL_FRA_MAX_NUMS);
    can_frame_id_u rx_can_frame = {rx_can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_CFG_TABLE_ACK_CMD);

    data[0] = (rx_can_frame.bit.fun_code & 0xFF);
    data[1] = fail_flag;
    data[2] = err_code;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return;
}

/***************************************************************外can发送接收预处理函数end*********************************************/

/***************************************************************外can接收处理函数start*********************************************/
// 高特功能码0x00: 项目（硬件）信息报文
static bool ex_rx_gold_project_info_req(can_frame_data_t *can_data, uint16_t func_code)
{
    bms_attr_t bms_attr_data = {0};
    bms_attr_data = *get_bms_attr();
    
    if (can_data->data[0] != 0x04) // 第4包用作项目（硬件）信息
    {
        ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_FAIL_FLAG, GOLD_CFG_TABLE_PARA_ERR);
        return 0;
    }
    // 根据写入的项目名称来写入对应信息，当然默认是按2.0项目来
    if ((can_data->data[1] == PROJECT_VER_2_0_H) && (can_data->data[2] == PROJECT_VER_2_0_L))
    {
        bms_attr_data.project_ver[0] = PROJECT_VER_2_0_H;
        bms_attr_data.project_ver[1] = PROJECT_VER_2_0_L;        
        data_store_save_bms_attr(ST_VAR_POS(bms_attr_t,project_ver), (uint8_t *)(bms_attr_data.project_ver),ST_VAR_SIZE(bms_attr_t,project_ver) );
        ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);
        data_store_save_bms_attr_thre_val(SET_THRE_PACK_CELL_NUM, PACK_CELL_NUM_64);
        data_store_save_bms_attr_thre_val(SET_THRE_PACK_TEMP_NUM, PACK_CELL_TEMP_NUM_36);  
        data_store_save_bms_attr_thre_val(SET_THRE_CLU_PACK_NUM,  PACK_MIN_NUM);  
        data_store_save_bms_attr_thre_val(SET_THRE_BATT_CAP, PACK_POWER_CAP_120);
        data_store_save_bms_attr(ST_VAR_POS(bms_attr_t, safety), (uint8_t *)(&get_bms_attr_init()->safety),ST_VAR_SIZE(bms_attr_t, safety));  
        bmu_alarm_thre_val_check_start();
        pack_data_init();
    }
    else if ((can_data->data[1] == PROJECT_VER_1_0_H) && (can_data->data[2] == PROJECT_VER_1_0_L))
    {
        bms_attr_data.project_ver[0] = PROJECT_VER_1_0_H;
        bms_attr_data.project_ver[1] = PROJECT_VER_1_0_L;            
        data_store_save_bms_attr(ST_VAR_POS(bms_attr_t,project_ver), (uint8_t *)(bms_attr_data.project_ver),ST_VAR_SIZE(bms_attr_t,project_ver) );
        ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);  
        data_store_save_bms_attr_thre_val(SET_THRE_PACK_CELL_NUM, PACK_CELL_NUM_48);
        data_store_save_bms_attr_thre_val(SET_THRE_PACK_TEMP_NUM, PACK_CELL_TEMP_NUM_28);  
        data_store_save_bms_attr_thre_val(SET_THRE_CLU_PACK_NUM,  PACK_MAX_NUM);  
        data_store_save_bms_attr_thre_val(SET_THRE_BATT_CAP, PACK_POWER_CAP_280);
        
        //项目工程里默认保存着2.0的阈值，故这里需要补充一份1.0的故障阈值供切换项目类型时使用
        safety_para_tab_t  project_1_0_safety =     //注意这里是int16_t
        {  // 保护产生阈值 保护解除阈值 告警产生阈值 告警解除阈值
        .total_over_vol_tip               = {13440, 13340},               ///< 总压过压提示 分辨率为0.1V/bit，偏移量为0
        .total_over_vol_alarm             = {13632, 13532},               ///< 总压过压告警 分辨率为0.1V/bit，偏移量为0  
        .total_over_vol_protect           = {14016, 13916},               ///< 总压过压保护 分辨率为0.1V/bit，偏移量为0
        .total_under_vol_tip              = {10752, 10852},               ///<总压欠压提示  分辨率为0.1V/bit，偏移量为0
        .total_under_vol_alarm            = {10368, 10468},               ///<总压欠压告警  分辨率为0.1V/bit，偏移量为0
        .total_under_vol_protect          = {9600,  9700},               ///< 总压欠压保护 分辨率为0.1V/bit，偏移量为0
        .bat_over_vol_tip                 = {1680,  1630},              ///< 电池模组过压提示, 分辨率：0.1V/bit  偏移量 0
        .bat_over_vol_alarm               = {1704,  1654},              ///< 电池模组过压告警, 分辨率：0.1V/bit  偏移量 0
        .bat_over_vol_protect             = {1752,  1702},              ///< 电池模组过压保护, 分辨率：0.1V/bit 偏移量 0
        .bat_under_vol_tip                = {1344,  1394},               ///< 电池模组过低提示, 分辨率：0.1V/bit  偏移量 0
        .bat_under_vol_alarm              = {1296,  1346},               ///< 电池模组过低告警, 分辨率：0.1V/bit  偏移量 0
        .bat_under_vol_protect            = {1200,  1250},               ///< 电池模组过低保护, 分辨率：0.1V/bit 偏移量 0        
        .cell_over_vol_tip                = {3500, 3400},               ///< 单体过压提示, 分辨率：0.001V/bit  偏移量 0
        .cell_over_vol_alarm              = {3550, 3450},               ///< 单体过压告警, 分辨率：0.001V/bit  偏移量 0
        .cell_over_vol_protect            = {3650, 3550},               ///< 单体过压保护, 分辨率：0.001V/bit 偏移量 0
        .cell_under_vol_tip               = {2800, 2900},                ///< 单体过低提示, 分辨率：0.001V/bit  偏移量 0
        .cell_under_vol_alarm             = {2700, 2800},                ///< 单体过低告警, 分辨率：0.001V/bit  偏移量 0
        .cell_under_vol_protect           = {2500, 2600},                ///< 单体过低保护, 分辨率：0.001V/bit 偏移量 0        
        .chg_over_cur_tip                 = {2150, 2050 },               ///< 充电过流提示 分辨率：0.1A 无偏移量
        .chg_over_cur_alarm               = {2300, 2200},               ///< 充电过流告警 分辨率：0.1A 无偏移量
        .chg_over_cur_protect             = {2500, 2400},               ///< 充电过流保护 分辨率：0.1A 无偏移量
        .dchg_over_cur_tip                = {2150, 2050},              ///< 放电过流提示 分辨率：0.1A 无偏移量
        .dchg_over_cur_alarm              = {2300, 2200},              ///< 放电过流告警 分辨率：0.1A 无偏移量
        .dchg_over_cur_protect            = {2500, 2400},              ///< 放电过流保护 分辨率：0.1A 无偏移量
        .chg_over_cell_temp_tip           = {500,   450},              ///< 单体充电温度过高提示, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .chg_over_cell_temp_alarm         = {550,   500},              ///< 单体充电温度过高告警, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .chg_over_cell_temp_protect       = {600,   550},              ///< 单体充电温度过高保护, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .chg_under_cell_temp_tip          = {0   ,   50},               ///< 单体充电温度过低提示, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .chg_under_cell_temp_alarm        = {-100, -50 },               ///< 单体充电温度过低告警, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .chg_under_cell_temp_protect      = {-200, -150},               ///< 单体充电温度过低保护, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .dchg_over_cell_temp_tip          = {500,   450  },               ///< 单体放电温度过高提示, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .dchg_over_cell_temp_alarm        = {550,   500  },               ///< 单体放电温度过高告警, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .dchg_over_cell_temp_protect      = {600,   550  },               ///< 单体放电温度过高保护, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .dchg_under_cell_temp_tip         = {0   ,   50  },                ///< 单体放电温度过低提示, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .dchg_under_cell_temp_alarm       = {-100, -50   },                ///< 单体放电温度过低告警, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .dchg_under_cell_temp_protect     = {-200, -150  },                ///< 单体放电温度过低保护, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .cell_temp_diff_tip               = {150,  100},                ///< 单体温度差值过大提示, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .cell_temp_diff_alarm             = {200,  150},                ///< 单体温度差值过大告警, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .cell_temp_diff_protect           = {300,  250},                ///< 单体温度差值过大保护, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .bat_soc_over_tip                 = {1010, 990},              ///< SOC过大提示, 分辨率：0.1%/bit 偏移量 0
        .bat_soc_over_alarm               = {1010, 990},              ///< SOC过大告警, 分辨率：0.1%/bit 偏移量 0
        .bat_soc_over_protect             = {1010, 990},              ///< SOC过大保护, 分辨率：0.1%/bit 偏移量 0
        .bat_soc_under_tip                = {150,  170},               ///< SOC过低提示, 分辨率：0.1%/bit 偏移量 0
        .bat_soc_under_alarm              = {100,  120},               ///< SOC过低告警, 分辨率：0.1%/bit 偏移量 0
        .bat_soc_under_protect            = {50,  70},               ///< SOC过低保护, 分辨率：0.1%/bit 偏移量 0
        .bat_soc_diff_tip                 = {1000,  980},              ///< SOC差值过大提示, 分辨率：0.1%/bit 偏移量 0
        .bat_soc_diff_alarm               = {1000,  980},              ///< SOC差值过大告警, 分辨率：0.1%/bit 偏移量 0
        .bat_soc_diff_protect             = {1000,  980},              ///< SOC差值过大保护, 分辨率：0.1%/bit 偏移量 0
        .ins_val_under_tip                = {1000, 1010 },              ///< 绝缘阻抗过低提示, 分辨率：1KΩ/bit  偏移量 0
        .ins_val_under_alarm              = {500 , 510 },               ///< 绝缘阻抗过低告警, 分辨率：1KΩ/bit  偏移量 0
        .ins_val_under_protect            = {100 , 110 },               ///< 绝缘阻抗过低保护, 分辨率：1KΩ/bit  偏移量 0
        .cell_vol_diff_tip                = {400 , 350},               ///< 单体压差过大提示, 分辨率：0.001V/bit  偏移量 0
        .cell_vol_diff_alarm              = {600 , 550},               ///< 单体压差过大告警, 分辨率：0.001V/bit  偏移量 0
        .cell_vol_diff_protect            = {1000, 950},               ///< 单体压差过大保护, 分辨率：0.001V/bit 偏移量 0
        .mod_temp_over_tip                = {650,  600},               ///< 模块温度过高提示, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .mod_temp_over_alarm              = {850,  800},               ///< 模块温度过高告警, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .mod_temp_over_protect            = {1000, 950},               ///< 模块温度过高保护, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .power_terminal_temp_over_tip     = {900,  850},        ///< 功率端子温度过高提示, 分辨率：0.1℃/bit 
        .power_terminal_temp_over_alarm   = {950,  900},        ///< 功率端子温度过高告警, 分辨率：0.1℃/bit 
        .power_terminal_temp_over_protect = {1000,  950},       ///< 功率端子温度过高保护, 分辨率：0.1℃/bit 
        .power_volt_over_alarm            = {336,  320},        ///< 供电电压过高告警, 分辨率：0.1V/bit 
        .power_volt_under_alarm           = {171,  180},        ///< 供电电压欠压告警, 分辨率：0.1V/bit 
        };
        data_store_save_bms_attr(ST_VAR_POS(bms_attr_t,safety), (uint8_t *)(&project_1_0_safety),ST_VAR_SIZE(bms_attr_t,safety) );
        bmu_alarm_thre_val_check_start();
        pack_data_init();
    }
    else
    {
        ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_FAIL_FLAG, GOLD_CFG_TABLE_PARA_ERR);
    }

    return 0;
}

// 高特功能码0x03: 传感器报文
static bool ex_rx_gold_sensor_data_req(can_frame_data_t *can_data, uint16_t func_code)
{
    if (can_data->data[0] != 0x01) // 包序号（1~0xFE，0xFF 表示最后一包）
    {
        ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_FAIL_FLAG, GOLD_CFG_TABLE_PARA_ERR);
        return 0;
    }
    // CMU/上位机下发电流量程分辨率1A/bit
    data_store_save_bms_attr_thre_val(SET_THRE_HALL_ENABLE, can_data->data[1]);
    data_store_save_bms_attr_thre_val(SET_THRE_HALL_RANGE_1, (MAKE_WORD(can_data->data[3], can_data->data[2])));
    data_store_save_bms_attr_thre_val(SET_THRE_HALL_RANGE_2, (MAKE_WORD(can_data->data[5], can_data->data[4])));
    data_store_save_bms_attr_thre_val(SET_THRE_HALL_RANGE_3, (MAKE_WORD(can_data->data[7], can_data->data[6])));
    ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);
    return 0;
}

// 高特功能码0x04: 组端总电压上限报警值
static bool ex_rx_gold_clu_volt_over_alm(can_frame_data_t *can_data, uint16_t func_code)
{ 
    uint16_t set_val = 0;
    uint16_t set_diff_val = can_data->data[6];

    // CMU/上位机下发量程分辨率0.1V/bit
    set_val = MAKE_WORD(can_data->data[1], can_data->data[0]);
    data_store_save_bms_attr_thre_val(SET_THRE_CLU_OVER_VOLT_TIP, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_CLU_OVER_VOLT_TIP_DIS, (set_val - set_diff_val));
    
    set_val = MAKE_WORD(can_data->data[3], can_data->data[2]);
    data_store_save_bms_attr_thre_val(SET_THRE_CLU_OVER_VOLT_ALM, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_CLU_OVER_VOLT_ALM_DIS, (set_val - set_diff_val));
    
    set_val = MAKE_WORD(can_data->data[5], can_data->data[4]);
    data_store_save_bms_attr_thre_val(SET_THRE_CLU_OVER_VOLT_PRO, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_CLU_OVER_VOLT_PRO_DIS, (set_val - set_diff_val));
    ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);
    return 0;
}

// 高特功能码0x05:  组端总电压下限报警值
static bool ex_rx_gold_clu_volt_down_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    uint16_t set_val = 0;
    uint16_t set_diff_val = can_data->data[6];

    // CMU/上位机下发量程分辨率0.1V/bit
    set_val = MAKE_WORD(can_data->data[1], can_data->data[0]);
    data_store_save_bms_attr_thre_val(SET_THRE_CLU_UNDER_VOLT_TIP, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_CLU_UNDER_VOLT_TIP_DIS, (set_val + set_diff_val));
    
    set_val = MAKE_WORD(can_data->data[3], can_data->data[2]);
    data_store_save_bms_attr_thre_val(SET_THRE_CLU_UNDER_VOLT_ALM, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_CLU_UNDER_VOLT_ALM_DIS, (set_val + set_diff_val));
    
    set_val = MAKE_WORD(can_data->data[5], can_data->data[4]);
    data_store_save_bms_attr_thre_val(SET_THRE_CLU_UNDER_VOLT_PRO, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_CLU_UNDER_VOLT_PRO_DIS, (set_val + set_diff_val));
    ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);
    return 0;
}

// 高特功能码0x06:  充电电流报警值
#define FAST_CHG_TYPE 1
#define POWER_TERMINAL_TEMP_TYPE 2
#define FEED_CHG_TYPE 3
static bool ex_rx_gold_chg_curr_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    uint16_t set_val = 0;
    uint16_t set_diff_val = can_data->data[7];

    // 充电类型 1：快充   2：慢充/极柱过温  3：馈电
    if (can_data->data[0] == FAST_CHG_TYPE)
    {
        // CMU/上位机下发量程分辨率0.1A/bit
        set_val = MAKE_WORD(can_data->data[2], can_data->data[1]);
        data_store_save_bms_attr_thre_val(SET_THRE_CHG_OVER_CURR_TIP, set_val);
        data_store_save_bms_attr_thre_val(SET_THRE_CHG_OVER_CURR_TIP_DIS, (set_val - set_diff_val));
        
        set_val = MAKE_WORD(can_data->data[4], can_data->data[3]);
        data_store_save_bms_attr_thre_val(SET_THRE_CHG_OVER_CURR_ALM, set_val);
        data_store_save_bms_attr_thre_val(SET_THRE_CHG_OVER_CURR_ALM_DIS, (set_val - set_diff_val));
        
        set_val = MAKE_WORD(can_data->data[6], can_data->data[5]);
        data_store_save_bms_attr_thre_val(SET_THRE_CHG_OVER_CURR_PRO, set_val);
        data_store_save_bms_attr_thre_val(SET_THRE_CHG_OVER_CURR_PRO_DIS, (set_val - set_diff_val));
        ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);
    }
    else if (can_data->data[0] == POWER_TERMINAL_TEMP_TYPE)
    {
        // CMU/上位机下发量程分辨率0.1℃/bit，无偏移
        set_val = MAKE_WORD(can_data->data[2], can_data->data[1]);
        data_store_save_bms_attr_thre_val(SET_THRE_POWER_TERMINAL_TEMP_HIGH_TIP, set_val);
        data_store_save_bms_attr_thre_val(SET_THRE_POWER_TERMINAL_TEMP_HIGH_TIP_DIS, (set_val - set_diff_val));
        
        set_val = MAKE_WORD(can_data->data[4], can_data->data[3]);
        data_store_save_bms_attr_thre_val(SET_THRE_POWER_TERMINAL_TEMP_HIGH_ALM, set_val);
        data_store_save_bms_attr_thre_val(SET_THRE_POWER_TERMINAL_TEMP_HIGH_ALM_DIS, (set_val - set_diff_val));
        
        set_val = MAKE_WORD(can_data->data[6], can_data->data[5]);
        data_store_save_bms_attr_thre_val(SET_THRE_POWER_TERMINAL_TEMP_HIGH_PROT, set_val);
        data_store_save_bms_attr_thre_val(SET_THRE_POWER_TERMINAL_TEMP_HIGH_PROT_DIS, (set_val - set_diff_val));
        ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);
    }
    return 0;
}

// 高特功能码0x07:  放电电流报警值
static bool ex_rx_gold_dsg_curr_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    uint16_t set_val = 0;
    uint16_t set_diff_val = can_data->data[6];

    // CMU/上位机下发量程分辨率0.1A/bit
    set_val = MAKE_WORD(can_data->data[1], can_data->data[0]);
    data_store_save_bms_attr_thre_val(SET_THRE_DSG_OVER_CURR_TIP, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_DSG_OVER_CURR_TIP_DIS, (set_val - set_diff_val));
    
    set_val = MAKE_WORD(can_data->data[3], can_data->data[2]);
    data_store_save_bms_attr_thre_val(SET_THRE_DSG_OVER_CURR_ALM, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_DSG_OVER_CURR_ALM_DIS, (set_val - set_diff_val));
    
    set_val = MAKE_WORD(can_data->data[5], can_data->data[4]);
    data_store_save_bms_attr_thre_val(SET_THRE_DSG_OVER_CURR_PRO, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_DSG_OVER_CURR_PRO_DIS, (set_val - set_diff_val));
    ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);
    return 0;
}

// 高特功能码0x08:  充电单体电池温度报警值
#define GOLD_TEMP_SET_OFFSET_VAL_0P1  (-400) // 偏移-40℃
static bool ex_rx_gold_chg_cell_temp_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    // CMU/上位机下发量程分辨率1℃/bit,偏移-40℃
    int16_t set_temp_diff = (int8_t)can_data->data[3];
    int16_t set_temp = (int8_t)can_data->data[0];
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_CHG_HIGH_TEMP_TIP, (uint16_t)((set_temp * 10) + GOLD_TEMP_SET_OFFSET_VAL_0P1));                        // 存储按照0.1℃/bit
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_CHG_HIGH_TEMP_TIP_DIS, (uint16_t)((set_temp - set_temp_diff) * 10 + GOLD_TEMP_SET_OFFSET_VAL_0P1));    // 存储按照0.1℃/bit
    
    set_temp = (int8_t)can_data->data[1];
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_CHG_HIGH_TEMP_ALRM, (uint16_t)((set_temp * 10) + GOLD_TEMP_SET_OFFSET_VAL_0P1));                        // 存储按照0.1℃/bit
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_CHG_HIGH_TEMP_ALRM_DIS, (uint16_t)((set_temp - set_temp_diff) * 10 + GOLD_TEMP_SET_OFFSET_VAL_0P1));    // 存储按照0.1℃/bit
    
    set_temp = (int8_t)can_data->data[2];
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_CHG_HIGH_TEMP_PROT, (uint16_t)((set_temp * 10) + GOLD_TEMP_SET_OFFSET_VAL_0P1));                        // 存储按照0.1℃/bit
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_CHG_HIGH_TEMP_PROT_DIS, (uint16_t)((set_temp - set_temp_diff) * 10 + GOLD_TEMP_SET_OFFSET_VAL_0P1));    // 存储按照0.1℃/bit
    
    set_temp_diff = (int8_t)can_data->data[7];
    set_temp = (int8_t)can_data->data[4];
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_CHG_LOW_TEMP_TIP, (uint16_t)((set_temp * 10) + GOLD_TEMP_SET_OFFSET_VAL_0P1));                    // 存储按照0.1℃/bit
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_CHG_LOW_TEMP_TIP_DIS, (uint16_t)((set_temp + set_temp_diff) * 10 + GOLD_TEMP_SET_OFFSET_VAL_0P1)); // 存储按照0.1℃/bit
    
    set_temp = (int8_t)can_data->data[5];
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_CHG_LOW_TEMP_ALRM, (uint16_t)((set_temp * 10) + GOLD_TEMP_SET_OFFSET_VAL_0P1));                       // 存储按照0.1℃/bit
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_CHG_LOW_TEMP_ALRM_DIS, (uint16_t)((set_temp + set_temp_diff) * 10 + GOLD_TEMP_SET_OFFSET_VAL_0P1));   // 存储按照0.1℃/bit
    
    set_temp = (int8_t)can_data->data[6];
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_CHG_LOW_TEMP_PROT, (uint16_t)((set_temp * 10) + GOLD_TEMP_SET_OFFSET_VAL_0P1));                       // 存储按照0.1℃/bit
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_CHG_LOW_TEMP_PROT_DIS, (uint16_t)((set_temp + set_temp_diff) * 10 + GOLD_TEMP_SET_OFFSET_VAL_0P1));   // 存储按照0.1℃/bit
    
    ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);
    bmu_alarm_thre_val_check_start();
    return 0;
}
 
// 高特功能码0x09:  单体电池温差报警值
static bool ex_rx_gold_cell_temp_dis_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    // CMU/上位机下发量程分辨率1℃/bit
    // 存储按照0.1℃/bit
    uint16_t set_temp_diff = can_data->data[3];
    uint16_t set_temp = can_data->data[0];
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_TEMP_DIFF_TIP, ((set_temp * 10)));
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_TEMP_DIFF_TIP_DIS, ((set_temp - set_temp_diff) * 10));
    
    set_temp = can_data->data[1];
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_TEMP_DIFF_ALRM, ((set_temp * 10)));
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_TEMP_DIFF_ALRM_DIS, ((set_temp - set_temp_diff) * 10));
    
    set_temp = can_data->data[2];
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_TEMP_DIFF_PROT, ((set_temp * 10)));
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_TEMP_DIFF_PROT_DIS, ((set_temp - set_temp_diff) * 10));
    
    ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);
    bmu_alarm_thre_val_check_start();
    return 0;
}

// 高特功能码0xA:  SOC 报警值
#define SET_CFG_SOC_UNDER_LIMIT_TYPE 1
#define SET_CFG_SOC_OVER_LIMIT_TYPE  2
#define SET_CFG_SOC_DIFF_LIMIT_TYPE  3
static bool ex_rx_gold_soc_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    uint16_t set_temp_diff = can_data->data[4];
    uint16_t set_temp = 0xFFFF;
    if (can_data->data[0] == SET_CFG_SOC_UNDER_LIMIT_TYPE)
    {
        set_temp = can_data->data[1];
        data_store_save_bms_attr_thre_val(SET_THRE_SOC_LOW_TIP, (uint16_t)((set_temp * 10)));
        data_store_save_bms_attr_thre_val(SET_THRE_SOC_LOW_TIP_DIS, (uint16_t)((set_temp + set_temp_diff) * 10));
        set_temp = can_data->data[2];
        data_store_save_bms_attr_thre_val(SET_THRE_SOC_LOW_ALRM, (uint16_t)((set_temp * 10)));
        data_store_save_bms_attr_thre_val(SET_THRE_SOC_LOW_ALRM_DIS, (uint16_t)((set_temp + set_temp_diff) * 10));
        set_temp = can_data->data[3];
        data_store_save_bms_attr_thre_val(SET_THRE_SOC_LOW_PRO, (uint16_t)((set_temp * 10)));
        data_store_save_bms_attr_thre_val(SET_THRE_SOC_LOW_PRO_DIS, (uint16_t)((set_temp + set_temp_diff) * 10));
    }
    else if (can_data->data[0] == SET_CFG_SOC_OVER_LIMIT_TYPE)
    {
        set_temp = can_data->data[1];
        data_store_save_bms_attr_thre_val(SET_THRE_SOC_HIGH_TIP, (uint16_t)((set_temp * 10)));
        data_store_save_bms_attr_thre_val(SET_THRE_SOC_HIGH_TIP_DIS, (uint16_t)((set_temp - set_temp_diff) * 10));
        set_temp = can_data->data[2];
        data_store_save_bms_attr_thre_val(SET_THRE_SOC_HIGH_ALRM, (uint16_t)((set_temp * 10)));
        data_store_save_bms_attr_thre_val(SET_THRE_SOC_HIGH_ALRM_DIS, (uint16_t)((set_temp - set_temp_diff) * 10));
        set_temp = can_data->data[3];
        data_store_save_bms_attr_thre_val(SET_THRE_SOC_HIGH_PRO, (uint16_t)((set_temp * 10)));
        data_store_save_bms_attr_thre_val(SET_THRE_SOC_HIGH_PRO_DIS, (uint16_t)((set_temp - set_temp_diff) * 10));
    }
    else if (can_data->data[0] == SET_CFG_SOC_DIFF_LIMIT_TYPE)
    {
        set_temp = can_data->data[1];
        data_store_save_bms_attr_thre_val(SET_THRE_SOC_DIFF_TIP, (uint16_t)((set_temp * 10)));
        data_store_save_bms_attr_thre_val(SET_THRE_SOC_DIFF_TIP_DIS, (uint16_t)((set_temp - set_temp_diff) * 10));
        set_temp = can_data->data[2];
        data_store_save_bms_attr_thre_val(SET_THRE_SOC_DIFF_ALRM, (uint16_t)((set_temp * 10)));
        data_store_save_bms_attr_thre_val(SET_THRE_SOC_DIFF_ALRM_DIS, (uint16_t)((set_temp - set_temp_diff) * 10));
        set_temp = can_data->data[3];
        data_store_save_bms_attr_thre_val(SET_THRE_SOC_DIFF_PRO, (uint16_t)((set_temp * 10)));
        data_store_save_bms_attr_thre_val(SET_THRE_SOC_DIFF_PRO_DIS, (uint16_t)((set_temp - set_temp_diff) * 10));
    }
    else
    {
        ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_FAIL_FLAG, GOLD_CFG_TABLE_PARA_ERR);
        return 0;
    }
    ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);
    return 0;
}

// 高特功能码0xB: 绝缘电阻报警值
static bool ex_rx_gold_inv_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    uint16_t set_val = 0;
    uint16_t set_diff_val = can_data->data[6];

    // CMU/上位机下发量程分辨率1KΩ/bit
    set_val = MAKE_WORD(can_data->data[1], can_data->data[0]);
    data_store_save_bms_attr_thre_val(SET_THRE_INS_VAL_TIP, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_INS_VAL_TIP_DIS, (set_val + set_diff_val));
    
    set_val = MAKE_WORD(can_data->data[3], can_data->data[2]);
    data_store_save_bms_attr_thre_val(SET_THRE_INS_VAL_ALRM, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_INS_VAL_ALRM_DIS, (set_val + set_diff_val));
    
    set_val = MAKE_WORD(can_data->data[5], can_data->data[4]);
    data_store_save_bms_attr_thre_val(SET_THRE_INS_VAL_PRO, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_INS_VAL_PRO_DIS, (set_val + set_diff_val));
    ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);
    return 0;
}

// 高特功能码0xC: 电池单体电压上限报警值
static bool ex_rx_gold_cell_volt_over_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    uint16_t set_val = 0;
    uint16_t set_diff_val = can_data->data[6];

    // CMU/上位机下发量程分辨率0.001V/bit
    set_val = MAKE_WORD(can_data->data[1], can_data->data[0]);
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_OVER_VOLT_TIP, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_OVER_VOLT_TIP_DIS, (set_val - set_diff_val));
    
    set_val = MAKE_WORD(can_data->data[3], can_data->data[2]);
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_OVER_VOLT_ALM, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_OVER_VOLT_ALM_DIS, (set_val - set_diff_val));
    
    set_val = MAKE_WORD(can_data->data[5], can_data->data[4]);
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_OVER_VOLT_PROT, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_OVER_VOLT_PROT_DIS, (set_val - set_diff_val));
    ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);
    bmu_alarm_thre_val_check_start();
    return 0;
}

// 高特功能码0xD: 电池单体电压下限报警值
static bool ex_rx_gold_cell_volt_down_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    uint16_t set_val = 0;
    uint16_t set_diff_val = can_data->data[6];

    // CMU/上位机下发量程分辨率0.001V/bit
    set_val = MAKE_WORD(can_data->data[1], can_data->data[0]);
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_UNDER_VOLT_TIP, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_UNDER_VOLT_TIP_DIS, (set_val + set_diff_val));
    
    set_val = MAKE_WORD(can_data->data[3], can_data->data[2]);
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_UNDER_VOLT_ALM, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_UNDER_VOLT_ALM_DIS, (set_val + set_diff_val));
    
    set_val = MAKE_WORD(can_data->data[5], can_data->data[4]);
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_UNDER_VOLT_PROT, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_UNDER_VOLT_PROT_DIS, (set_val + set_diff_val));
    ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);
    bmu_alarm_thre_val_check_start();
    return 0;
}

// 高特功能码0xE: 电池单体电压压差报警值
static bool ex_rx_gold_cell_volt_dis_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    uint16_t set_val = 0;
    uint16_t set_diff_val = can_data->data[6];

    // CMU/上位机下发量程分辨率0.001V/bit
    set_val = MAKE_WORD(can_data->data[1], can_data->data[0]);
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_VOLT_DIFF_TIP, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_VOLT_DIFF_TIP_DIS, (set_val - set_diff_val));
    
    set_val = MAKE_WORD(can_data->data[3], can_data->data[2]);
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_VOLT_DIFF_ALM, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_VOLT_DIFF_ALM_DIS, (set_val - set_diff_val));
    
    set_val = MAKE_WORD(can_data->data[5], can_data->data[4]);
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_VOLT_DIFF_PROT, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_VOLT_DIFF_PROT_DIS, (set_val - set_diff_val));
    ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);
    bmu_alarm_thre_val_check_start();
    return 0;

}

// 高特功能码0xF: 模块温度上限报警值
static bool ex_rx_gold_mode_temp_over_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    // CMU/上位机下发量程分辨率1℃/bit,偏移-40
    // 存储按照0.1℃/bit
    uint16_t set_temp_diff = can_data->data[3] & 0x00FF;
    uint16_t set_temp = can_data->data[0] & 0x00FF;
    data_store_save_bms_attr_thre_val(SET_THRE_MOD_TEMP_HIGH_TIP, ((set_temp * 10) + GOLD_TEMP_SET_OFFSET_VAL_0P1));
    data_store_save_bms_attr_thre_val(SET_THRE_MOD_TEMP_HIGH_TIP_DIS, ((set_temp - set_temp_diff) * 10 + GOLD_TEMP_SET_OFFSET_VAL_0P1));
    set_temp = can_data->data[1];
    data_store_save_bms_attr_thre_val(SET_THRE_MOD_TEMP_HIGH_ALM, ((set_temp * 10) + GOLD_TEMP_SET_OFFSET_VAL_0P1));
    data_store_save_bms_attr_thre_val(SET_THRE_MOD_TEMP_HIGH_ALM_DIS, ((set_temp - set_temp_diff) * 10 + GOLD_TEMP_SET_OFFSET_VAL_0P1));
    set_temp = can_data->data[2];
    data_store_save_bms_attr_thre_val(SET_THRE_MOD_TEMP_HIGH_PROT, ((set_temp * 10) + GOLD_TEMP_SET_OFFSET_VAL_0P1));
    data_store_save_bms_attr_thre_val(SET_THRE_MOD_TEMP_HIGH_PROT_DIS, ((set_temp - set_temp_diff) * 10 + GOLD_TEMP_SET_OFFSET_VAL_0P1));
    ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);
    return 0;
}

// 高特功能码0x12: RTC 数据
static bool ex_rx_gold_sys_rtc_data(can_frame_data_t *can_data, uint16_t func_code)
{
    sdk_rtc_t rtc_time = {0};
    rtc_time.tm_year = (uint8_t)(MAKE_WORD(can_data->data[1], can_data->data[0]) - 2000);
    rtc_time.tm_mon  = can_data->data[2];
    rtc_time.tm_day  = can_data->data[3];
    rtc_time.tm_hour = can_data->data[4];
    rtc_time.tm_min  = can_data->data[5];
    rtc_time.tm_sec  = can_data->data[6];
    sdk_rtc_set(RTC_BIN_FORMAT, &rtc_time);
    ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);
    return 0;
}

// 高特功能码0x14: 从控模块基本参数
static bool ex_rx_gold_sys_arch_para(can_frame_data_t *can_data, uint16_t func_code)
{
//    uint8_t pack_cell_num = 0;
//    uint8_t pack_temp_num = 0;
//    static uint8_t last_pack_cell_num = 0;
//    static uint8_t last_pack_temp_num = 0;

//    last_pack_cell_num = get_bms_attr()->pack_cell_num;
//    last_pack_temp_num = get_bms_attr()->pack_temp_num;

    // 目前只有1.0项目需要配置电池包个数
    if((can_data->data[1] >= PACK_MIN_NUM)
        && (can_data->data[1] <= PACK_MAX_NUM)
        && ((get_bms_attr()->project_ver[0] == PROJECT_VER_1_0_H) && (get_bms_attr()->project_ver[1] == PROJECT_VER_1_0_L))
    )
    {
        
        // CMU/上位机下发量程分辨率0.1V/bit
        data_store_save_bms_attr_thre_val(SET_THRE_CLU_OVER_VOLT_TIP, 1680 * can_data->data[1]);
        data_store_save_bms_attr_thre_val(SET_THRE_CLU_OVER_VOLT_TIP_DIS, (1680 * can_data->data[1] - 100));
        
        data_store_save_bms_attr_thre_val(SET_THRE_CLU_OVER_VOLT_ALM, 1704 * can_data->data[1]);
        data_store_save_bms_attr_thre_val(SET_THRE_CLU_OVER_VOLT_ALM_DIS, (1704 * can_data->data[1] - 100));
        
        data_store_save_bms_attr_thre_val(SET_THRE_CLU_OVER_VOLT_PRO, 1752 * can_data->data[1]);
        data_store_save_bms_attr_thre_val(SET_THRE_CLU_OVER_VOLT_PRO_DIS, (1752 * can_data->data[1] - 100));
        
        data_store_save_bms_attr_thre_val(SET_THRE_CLU_UNDER_VOLT_TIP, 1344 * can_data->data[1]);
        data_store_save_bms_attr_thre_val(SET_THRE_CLU_UNDER_VOLT_TIP_DIS, (1344 * can_data->data[1] + 100));
        
        data_store_save_bms_attr_thre_val(SET_THRE_CLU_UNDER_VOLT_ALM, 1296 * can_data->data[1]);
        data_store_save_bms_attr_thre_val(SET_THRE_CLU_UNDER_VOLT_ALM_DIS, (1296 * can_data->data[1] + 100));
        
        data_store_save_bms_attr_thre_val(SET_THRE_CLU_UNDER_VOLT_PRO, 1200 * can_data->data[1]);
        data_store_save_bms_attr_thre_val(SET_THRE_CLU_UNDER_VOLT_PRO_DIS, (1200 * can_data->data[1] + 100));

        
        data_store_save_bms_attr_thre_val(SET_THRE_CLU_PACK_NUM, (uint16_t)(can_data->data[1]));  
        ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);        
    }
    else
    {
        ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_FAIL_FLAG, GOLD_CFG_TABLE_PARA_ERR);        
    }


    //协议支持该功能，但是目前希望是通过改项目名称后把cell个数、temp个数适配，故暂时把该设置屏蔽，以免误发
//    pack_cell_num = MAKE_WORD(can_data->data[3], can_data->data[2]) / can_data->data[1];
//    pack_temp_num = MAKE_WORD(can_data->data[5], can_data->data[4]) / can_data->data[1];
//    if (((pack_cell_num == PACK_CELL_NUM_64) && (pack_temp_num == PACK_CELL_TEMP_NUM_36)) ||
//        ((pack_cell_num == PACK_CELL_NUM_48) && (pack_temp_num == PACK_CELL_TEMP_NUM_28)))
//    {
//        data_store_save_bms_attr_thre_val(SET_THRE_PACK_CELL_NUM, pack_cell_num);
//        data_store_save_bms_attr_thre_val(SET_THRE_PACK_TEMP_NUM, pack_temp_num);
//        
//        if ((last_pack_cell_num != pack_cell_num) && (last_pack_temp_num != pack_temp_num))
//        {
//            pack_data_init();
//        }
//        ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);
//    }
//    else
//    {
//        ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_FAIL_FLAG, GOLD_CFG_TABLE_PARA_ERR);
//    }

    
    return 0;
}

// 高特功能码0x16: 电池主参数
static bool ex_rx_gold_cell_main_para(can_frame_data_t *can_data, uint16_t func_code)
{
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_TYPE, can_data->data[0]);
    data_store_save_bms_attr_thre_val(SET_THRE_BATT_CAP, (MAKE_WORD(can_data->data[2], can_data->data[1])));
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_MODEL, can_data->data[3]);
    data_store_save_bms_attr_thre_val(SET_THRE_MANUFACTOR, (uint16_t)(can_data->data[4]));
    ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);
    return 0;
}

// 高特功能码0x1A: 设置 SOX 参数
#define SET_BATT_SOC_TYPE  0
#define SET_BATT_SOH_TYPE  1
static bool ex_rx_gold_set_sox_para(can_frame_data_t *can_data, uint16_t func_code)
{
    uint16_t tx_pack_id = 0;
    tx_pack_id = (MAKE_WORD(can_data->data[2], can_data->data[1]));  // 设置的电池包ID

    if (can_data->data[0] == SET_BATT_SOC_TYPE)
    {
        // 设置电池包的SOC值, 单位1%
        uint8_t tx_data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
        can_frame_id_u frame_val = {0};

        tx_data[0] = can_data->data[4];  // SOC值低字节 
        tx_data[1] = can_data->data[3];  // SOC值高字节
        tx_data[2] = 0xFF;
        tx_data[3] = 0xFF;
        tx_data[4] = 0xFF;
        tx_data[5] = 0xFF;
        tx_data[6] = 0xFF;
        tx_data[7] = 0xFF;

        // 发送给BMU
        frame_val.bit.dst_addr = tx_pack_id;
        frame_val.bit.dst_type = DEV_BMU;
        frame_val.bit.src_addr = BCU_INNER_CAN_ADDR;
        frame_val.bit.src_type = DEV_BROADCAST;
        frame_val.bit.fun_code = FUNC_ATE_SOX_SET;
        frame_val.bit.prio = SOFAR_CAN_PRI_LOW_H;
        log_d("tx_data:%x,%x, bmu_id:%d\n", tx_data[0], tx_data[1], tx_pack_id);
        can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_val.id_val, tx_data, CAN_SIGNAL_FRA_MAX_NUMS);
    }
    else if(can_data->data[0] == SET_BATT_SOH_TYPE)
    {
        // 设置电池包的SOH值, 单位1%
        uint8_t tx_data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
        can_frame_id_u frame_val = {0};

        tx_data[0] = 0xFF;
        tx_data[1] = 0xFF;
        tx_data[2] = 0xFF;
        tx_data[3] = 0xFF;
        tx_data[4] = 0xFF;
        tx_data[5] = 0xFF;
        tx_data[6] = can_data->data[3];  // SOH值
        tx_data[7] = 0xFF;

        // 发送给BMU
        frame_val.bit.dst_addr = tx_pack_id;
        frame_val.bit.dst_type = DEV_BMU;
        frame_val.bit.src_addr = BCU_INNER_CAN_ADDR;
        frame_val.bit.src_type = DEV_BROADCAST;
        frame_val.bit.fun_code = FUNC_ATE_SOX_SET;
        frame_val.bit.prio = SOFAR_CAN_PRI_LOW_H;
        log_d("tx_data:%x, bmu_id:%d\n", tx_data[6], tx_pack_id);
        can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_val.id_val, tx_data, CAN_SIGNAL_FRA_MAX_NUMS);
    }
    else
    {
        ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_FAIL_FLAG, GOLD_CFG_TABLE_PARA_ERR);
        return 0;
    }
    ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);
    return 0;
}

// 高特功能码0x1C: 放电单体电池温度报警值
static bool ex_rx_gold_dsg_cell_temp_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    // CMU/上位机下发量程分辨率1℃/bit,偏移-40℃
    int16_t set_temp_diff = (int8_t)can_data->data[3];
    int16_t set_temp = (int8_t)can_data->data[0];
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_DSG_HIGH_TEMP_TIP, (uint16_t)((set_temp * 10) + GOLD_TEMP_SET_OFFSET_VAL_0P1));                        // 存储按照0.1℃/bit
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_DSG_HIGH_TEMP_TIP_DIS, (uint16_t)((set_temp - set_temp_diff) * 10 + GOLD_TEMP_SET_OFFSET_VAL_0P1));    // 存储按照0.1℃/bit
    set_temp = (int8_t)can_data->data[1];
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_DSG_HIGH_TEMP_ALRM, (uint16_t)((set_temp * 10) + GOLD_TEMP_SET_OFFSET_VAL_0P1));                        // 存储按照0.1℃/bit
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_DSG_HIGH_TEMP_ALRM_DIS, (uint16_t)((set_temp - set_temp_diff) * 10 + GOLD_TEMP_SET_OFFSET_VAL_0P1));    // 存储按照0.1℃/bit
    set_temp = (int8_t)can_data->data[2];
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_DSG_HIGH_TEMP_PROT, (uint16_t)((set_temp * 10) + GOLD_TEMP_SET_OFFSET_VAL_0P1));                        // 存储按照0.1℃/bit
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_DSG_HIGH_TEMP_PROT_DIS, (uint16_t)((set_temp - set_temp_diff) * 10 + GOLD_TEMP_SET_OFFSET_VAL_0P1));    // 存储按照0.1℃/bit

    set_temp_diff = (int8_t)can_data->data[7];
    set_temp = (int8_t)can_data->data[4];
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_DSG_LOW_TEMP_TIP, (uint16_t)((set_temp * 10) + GOLD_TEMP_SET_OFFSET_VAL_0P1));                    // 存储按照0.1℃/bit
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_DSG_LOW_TEMP_TIP_DIS, (uint16_t)((set_temp + set_temp_diff) * 10 + GOLD_TEMP_SET_OFFSET_VAL_0P1)); // 存储按照0.1℃/bit
    set_temp = (int8_t)can_data->data[5];
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_DSG_LOW_TEMP_ALRM, (uint16_t)((set_temp * 10) + GOLD_TEMP_SET_OFFSET_VAL_0P1));                       // 存储按照0.1℃/bit
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_DSG_LOW_TEMP_ALRM_DIS, (uint16_t)((set_temp + set_temp_diff) * 10 + GOLD_TEMP_SET_OFFSET_VAL_0P1));   // 存储按照0.1℃/bit
    set_temp = (int8_t)can_data->data[6];
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_DSG_LOW_TEMP_PROT, (uint16_t)((set_temp * 10) + GOLD_TEMP_SET_OFFSET_VAL_0P1));                       // 存储按照0.1℃/bit
    data_store_save_bms_attr_thre_val(SET_THRE_CELL_DSG_LOW_TEMP_PROT_DIS, (uint16_t)((set_temp + set_temp_diff) * 10 + GOLD_TEMP_SET_OFFSET_VAL_0P1));   // 存储按照0.1℃/bit
    
    ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);
    bmu_alarm_thre_val_check_start();
    return 0;
}

// 高特功能码0x1F: 后台软件下发查询配置表消息
static bool ex_rx_gold_cfg_table_req(can_frame_data_t *can_data, uint16_t func_code)
{
    const ex_can_tx_msg_tcb_t deal_func[] =
    {
        {GOLD_FUNC_PROJECT_INFO_REQ_CMD     ,    ex_tx_gold_project_info_req},       // 0x00
        {GOLD_FUNC_SENSOR_DATA_REQ_CMD      ,    ex_tx_gold_sensor_data_req},       // 0x03
        {GOLD_FUNC_CLU_VOLT_OVER_ALM_CMD    ,    ex_tx_gold_clu_volt_over_alm},     // 0x04
        {GOLD_FUNC_CLU_VOLT_DOWN_ALM_CMD    ,    ex_tx_gold_clu_volt_down_alm},     // 0x05
        {GOLD_FUNC_CHG_CURR_ALM_CMD         ,    ex_tx_gold_chg_curr_alm},          // 0x06
        {GOLD_FUNC_DSG_CURR_ALM_CMD         ,    ex_tx_gold_dsg_curr_alm},          // 0x07
        {GOLD_FUNC_CHG_CELL_TEMP_ALM_CMD    ,    ex_tx_gold_chg_cell_temp_alm},     // 0x08
        {GOLD_FUNC_CELL_TEMP_DIS_ALM_CMD    ,    ex_tx_gold_cell_temp_dis_alm},     // 0x09
        {GOLD_FUNC_SOC_ALM_CMD              ,    ex_tx_gold_soc_alm},               // 0x0A
        {GOLD_FUNC_INV_ALM_CMD              ,    ex_tx_gold_inv_alm},               // 0x0B
        {GOLD_FUNC_CELL_VOLT_OVER_ALM_CMD   ,    ex_tx_gold_cell_volt_over_alm},    // 0x0C
        {GOLD_FUNC_CELL_VOLT_DOWN_ALM_CMD   ,    ex_tx_gold_cell_volt_down_alm},    // 0x0D
        {GOLD_FUNC_CELL_VOLT_DIS_ALM_CMD    ,    ex_tx_gold_cell_volt_dis_alm},     // 0x0E
        {GOLD_FUNC_MODE_TEMP_OVER_ALM_CMD   ,    ex_tx_gold_mode_temp_over_alm},    // 0x0F
        {GOLD_FUNC_SYS_RTC_DATA_CMD         ,    ex_tx_gold_sys_rtc_data},          // 0x12
        {GOLD_FUNC_SYS_ARCH_CMD             ,    ex_tx_gold_sys_arch_data},         // 0x14
        {GOLD_FUNC_CELL_MAIN_PARA_CMD       ,    ex_tx_gold_cell_main_para},        // 0x16
        {GOLD_FUNC_SET_SOX_PARA_CMD         ,    ex_tx_gold_set_sox_para},          // 0x1A
        {GOLD_FUNC_DSG_CELL_TEMP_ALM_CMD    ,    ex_tx_gold_dsg_cell_temp_alm},     // 0x1C
        {GOLD_FUNC_PACK_VOLT_OVER_ALM_CMD   ,    ex_tx_gold_pack_volt_over_alm},    // 0x2B
        {GOLD_FUNC_PACK_VOLT_DOWN_ALM_CMD   ,    ex_tx_gold_pack_volt_down_alm},    // 0x2C
        
    };
    uint8_t deal_id = can_data->data[0];
    
    for(uint8_t i = 0; i < sizeof(deal_func) / sizeof(ex_can_tx_msg_tcb_t); i++)
    {
        if(deal_id == deal_func[i].id)
        {
            deal_func[i].p_func_recv_deal_cb(can_data, func_code);
            break;
        }
    }
    return 0;
}

// 高特功能码0x2A: 主控地址设置命令码
static bool ex_rx_gold_cmu_set_addr(can_frame_data_t *can_data, uint16_t func_code)
{
    if (can_data->data[0] < GOLD_MIN_EX_CAN_ADDR || can_data->data[0] > GOLD_MAX_EX_CAN_ADDR)
    {
        return 0;
    }
    cluster_bcu_data_init();    //赋予新地址之后重新初始化簇间数据
    ext_addressing_manage_addr_set(can_data->data[0]);
    return 0;
}

// 高特功能码0x2B: 电池模组电压上限报警值
static bool ex_rx_gold_pack_volt_over_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    uint16_t set_val = 0;
    uint16_t set_diff_val = can_data->data[6];

    // CMU/上位机下发量程分辨率0.1V/bit
    set_val = MAKE_WORD(can_data->data[1], can_data->data[0]);
    data_store_save_bms_attr_thre_val(SET_THRE_BAT_OVER_VOLT_TIP, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_BAT_OVER_VOLT_TIP_DIS, (set_val - set_diff_val));
    
    set_val = MAKE_WORD(can_data->data[3], can_data->data[2]);
    data_store_save_bms_attr_thre_val(SET_THRE_BAT_OVER_VOLT_ALM, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_BAT_OVER_VOLT_ALM_DIS, (set_val - set_diff_val));
    
    set_val = MAKE_WORD(can_data->data[5], can_data->data[4]);
    data_store_save_bms_attr_thre_val(SET_THRE_BAT_OVER_VOLT_PROT, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_BAT_OVER_VOLT_PROT_DIS, (set_val - set_diff_val));
    ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);
    bmu_alarm_thre_val_check_start();
    return 0;
}

// 高特功能码0x2C: 电池模组电压下限报警值
static bool ex_rx_gold_pack_volt_down_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    uint16_t set_val = 0;
    uint16_t set_diff_val = can_data->data[6];

    // CMU/上位机下发量程分辨率0.1V/bit
    set_val = MAKE_WORD(can_data->data[1], can_data->data[0]);
    data_store_save_bms_attr_thre_val(SET_THRE_BAT_UNDER_VOLT_TIP, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_BAT_UNDER_VOLT_TIP_DIS, (set_val + set_diff_val));
    
    set_val = MAKE_WORD(can_data->data[3], can_data->data[2]);
    data_store_save_bms_attr_thre_val(SET_THRE_BAT_UNDER_VOLT_ALM, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_BAT_UNDER_VOLT_ALM_DIS, (set_val + set_diff_val));
    
    set_val = MAKE_WORD(can_data->data[5], can_data->data[4]);
    data_store_save_bms_attr_thre_val(SET_THRE_BAT_UNDER_VOLT_PROT, set_val);
    data_store_save_bms_attr_thre_val(SET_THRE_BAT_UNDER_VOLT_PROT_DIS, (set_val + set_diff_val));
    
    ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);
    bmu_alarm_thre_val_check_start();
    return 0;
}

// 高特功能码0x30: PC 请求电池采集消息
static bool ex_rx_gold_cell_data_req(can_frame_data_t *can_data, uint16_t func_code)
{
    const ex_can_sofar_tx_callback deal_func[] =
    {
        ex_tx_gold_cell_volt_ack,      // 0x31
        ex_tx_gold_cell_temp_ack,      // 0x32
        ex_tx_gold_cell_soc_ack,       // 0x33
        ex_tx_gold_cell_soh_ack,       // 0x34
        ex_tx_gold_sample_ack,         // 0x35
        ex_tx_gold_sys_summary_ack,    // 0x36
        ex_tx_gold_pack_num_data_ack,  // 0x37
        ex_tx_gold_warn_data_ack,      // 0x38
        ex_tx_gold_dido_data_ack,      // 0x39
        ex_tx_gold_temp_num_data_ack,  // 0x3A
        ex_tx_gold_pack_bal_data_ack,  // 0x3B
        ex_tx_gold_sla_unlink_ack,     // 0x3C
        ex_tx_gold_wire_open_ack,      // 0x3D
        ex_tx_gold_fault_data_ack,     // 0x3E
    };

    bcu_pcs_comm_err_cnt_clr();

    uint8_t deal_id = can_data->data[0];
    if (deal_id > 0x0E || deal_id == 0)
    {
        return 0;
    }
    deal_func[deal_id - 1](can_data, func_code);
    return 0;
}

// 高特功能码0x40: PC 请求查询版本号消息
static bool ex_rx_gold_ver_data_req(can_frame_data_t *can_data, uint16_t func_code)
{
    return ex_tx_gold_ver_data_ack(can_data, func_code);
}

// 高特功能码0x42: PC 请求设置被动均衡
static bool ex_rx_gold_set_pass_bal_state_req(can_frame_data_t *can_data, uint16_t func_code)
{
    bool ret = false;

    ret = inner_can_tx_pass_bal_set(can_data, func_code);

    if (ret == true)
    {
        ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_SUCC_FLAG, GOLD_CFG_TABLE_NO_ERR);
    }
    else
    {
        ex_tx_gold_cfg_table_ack(can_data, GOLD_CFG_TABLE_FAIL_FLAG, GOLD_CFG_TABLE_PARA_ERR);
    }
    
    return ret;
}

// 高特功能码0x52: 发送强制均衡命令-主动均衡
static bool ex_rx_gold_test_force_bal(can_frame_data_t *can_data, uint16_t func_code)
{
    //控制通道的主动均衡
    // TODO
    return 0;
}

// 高特功能码0x57: PC 发送设置 EVBCM 模块 DO 输出命令
static bool ex_rx_gold_test_force_do(can_frame_data_t *can_data, uint16_t func_code)
{
    master_ctl_bcu_data_set(can_data);
    return 0;
}

// 高特功能码0x67: 发送内部编址命令
static bool ex_rx_gold_inner_address(can_frame_data_t *can_data, uint16_t func_code)
{
    //启动内部编址
    if(get_bms_attr()->clu_pack_num == can_data->data[2])
    {
        auto_addressing_enable();        
    }
    return 0;
}

// 高特功能码0x80: 控制主控上下电指令
#define CLU_POWER_ON_CMD        1
#define CLU_POWER_OFF_CMD       2
#define CLU_FAULTPOWER_OFF_CMD  3
static bool ex_rx_gold_cmu_power_ctl(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t power_ctl_type = can_data->data[0];
    uint8_t clu_num = can_data->data[1];
    uint8_t clear_fault_flag = can_data->data[2];
    // 设置上下电状态
    if (power_ctl_type == CLU_FAULTPOWER_OFF_CMD)
    {
        cluster_bcu_power_state_set(CLU_POWER_FAULT_OFF_ALL);
    }
    else if (power_ctl_type == CLU_POWER_ON_CMD || power_ctl_type == CLU_POWER_OFF_CMD)
    {
        // 0:堆控制
        if (clu_num == 0)
        {
            cluster_bcu_power_state_set((power_state_e)(power_ctl_type + 3));
        }
        // 1-20:簇控制
        else if (clu_num == (ext_addressing_manage_addr_get() - (GOLD_MIN_EX_CAN_NO_TYPE_ADDR) + 1))
        {
           cluster_bcu_power_state_set((power_state_e)power_ctl_type);
        }
    }
    
    // 0x55：故障复归有效（在主控正常下电成功/正常下电失败/故障下电后，可通过此指令进行尝试重新上高压
    if (clear_fault_flag == 0x55)
    {
        cluster_bcu_fault_recover_set(true);
    }

    g_cmu_power_ctrl_type = power_ctl_type;

    return 0;
}

// 高特功能码0x81: 控制主控绝缘检测功能指令
// （电池簇主控高压上电之后听从 EMS 指令控制)
static bool ex_rx_gold_cmu_ins_ctl(can_frame_data_t *can_data, uint16_t func_code)
{
    if (can_data->data[0] == FUNC_ENABLE || can_data->data[0] == FUNC_DISABLE)
    {
        insulation_impedance_func_enable_set(can_data->data[0]);
    }
    
    if (can_data->data[1] == FUNC_ENABLE)   //辅电接触器由CMU控制
    {
        aux_relay_set(true);
    }    
    else if (can_data->data[1] == FUNC_DISABLE)
    {
        aux_relay_set(false);
    }
    
    return 0;
}

// 高特功能码0x90: 组端概要信息
static bool ex_rx_gold_clu_summary(can_frame_data_t *can_data, uint16_t func_code)
{
    cluster_bcu_data_set(can_data);
    return 0;
}

// 高特功能码0x91: 单体概要信息
static bool ex_rx_gold_clu_cell_summary(can_frame_data_t *can_data, uint16_t func_code)
{
    cluster_bcu_data_set(can_data);
    return 0;
}

// 高特功能码0x92: 8133 告警信息
static bool ex_rx_gold_clu_alm_summary(can_frame_data_t *can_data, uint16_t func_code)
{
    cluster_bcu_data_set(can_data);
    return 0;
}

// 高特功能码0x493: 主 8133 控制命令
static bool ex_rx_gold_mas_clu_ctl(can_frame_data_t *can_data, uint16_t func_code)
{
    master_ctl_bcu_data_set(can_data);
    return 0;
}

// 高特功能码0x95: 维护信息
static bool ex_rx_gold_maintenance(can_frame_data_t *can_data, uint16_t func_code)
{
    cluster_bcu_data_set(can_data);
    return 0;
}

// 高特功能码0x495(0x0C95XXF4): 退簇信息
static bool ex_rx_gold_out_clu_ctl(can_frame_data_t *can_data, uint16_t func_code)
{
    master_ctl_bcu_data_set(can_data);
    ex_tx_gold_out_clu_ctl(can_data, func_code);
    return 0;
}

// 0x10EF: ATE Flash测试：0x10EFXXE0
static bool ext_can_rx_ate_flash_test(can_frame_data_t *can_data, uint16_t func_code)
{
    if (can_data->data[0] == 1) // 写入
    {
        if (!special_mode_get(ATUO_TEST))
        {
            return 0;
        }
        if (can_data->data_len != CAN_SIGNAL_FRA_MAX_NUMS)
        {
            return 0;
        }
        bms_runing_data_t bms_data = *get_bms_runing_data();
        for (uint8_t i = 1; i < CAN_SIGNAL_FRA_MAX_NUMS; i++)
        {
            bms_data.flash_data[i - 1] = can_data->data[i];
        }
        bms_runing_data_save(bms_data);
    }
    
    ext_can_tx_ate_flash_test(can_data, func_code);
    return 0;
}

static bool ext_can_rx_ate_mode_ctl(can_frame_data_t *can_data, uint16_t func_code)
{
//    uint8_t check_sum = 0;
//    uint8_t data_id[4] = {0};
//    data_id[0] = can_data->id & 0xFF;
//    data_id[1] = (can_data->id >> 8) & 0xFF ;
//    data_id[2] = (can_data->id >> 16) & 0xFF;
//    data_id[3] = (can_data->id >> 24) & 0xFF;
//    check_sum += data_id[0] + data_id[1] + data_id[2] + data_id[3];
//    for (uint8_t i = 0; i < 7; i++)
//    {
//        check_sum += can_data->data[i];
//    }
//    // 校验和检测
//    if (check_sum != can_data->data[7])
//    {
//        return 0;
//    }
    
    // 老化模式设置
    if(OPEN_MODE == can_data->data[0])
    {
        special_mode_set(AGING_MODE,ATE_SET);
    }
    else if (RELEASE_MODE == can_data->data[0])
    {
        special_mode_set(AGING_MODE,ATE_CLR);
    }
    
    // 标定模式设置
    if(OPEN_MODE == can_data->data[1])
    {
        special_mode_set(CALI_PARM,ATE_SET);
    }
    else if (RELEASE_MODE == can_data->data[1])
    {
        special_mode_set(CALI_PARM,ATE_CLR);
    }
    
    // ate模式设置
    if(OPEN_MODE == can_data->data[2])
    {
        special_mode_set(ATUO_TEST,ATE_SET);
    }
    else if (RELEASE_MODE == can_data->data[2])
    {
        special_mode_set(ATUO_TEST,ATE_CLR);
    }
    
    // 强控模式设置
    if(OPEN_MODE == can_data->data[4])
    {
        special_mode_set(FORCE_CTL_MODE,ATE_SET);
    }
    else if (RELEASE_MODE == can_data->data[4])
    {
        special_mode_set(FORCE_CTL_MODE,ATE_CLR);
    }

    if(special_mode_get(ATUO_TEST))
    {
        // 产测步骤设置
        product_finish_flag_set(can_data->data[6]);        
    }

    
    ext_can_tx_ate_mode_ctl(can_data, func_code);
    return 0;

}

// 时间标定0x10F2FFE0
static bool ext_can_rx_ate_cali_time(can_frame_data_t *can_data, uint16_t func_code)
{
    sdk_rtc_t rtc_time = {0};
    rtc_time.tm_year = can_data->data[0];
    rtc_time.tm_mon  = can_data->data[1];
    rtc_time.tm_day  = can_data->data[2];
    rtc_time.tm_hour = can_data->data[3];
    rtc_time.tm_min  = can_data->data[4];
    rtc_time.tm_sec  = can_data->data[5];
    sdk_rtc_set(RTC_BIN_FORMAT, &rtc_time);
    ext_can_tx_ate_cali_time(can_data, func_code);
    return 0;
}

// PACK_SN标定0x10F3FFE0
static bool ext_can_rx_ate_set_pack_sn(can_frame_data_t *can_data, uint16_t func_code)
{
    if (!special_mode_get(CALI_PARM))
    {
        return 0;
    }
    uint8_t sn_len = sizeof(get_bms_attr()->pack_sn); // pack_sn后面需要修改uint8_t
    uint8_t sn_cnt = (sn_len + PACK_SN_IN_FRAME_LEN - 1) / PACK_SN_IN_FRAME_LEN;
    uint8_t frame_len = 0;
    if (can_data->data[0] + 1 == sn_cnt)
    {
        frame_len = ((sn_len % PACK_SN_IN_FRAME_LEN) == 0) ? PACK_SN_IN_FRAME_LEN : sn_len % PACK_SN_IN_FRAME_LEN;
    }
    else if (can_data->data[0] < sn_cnt)
    {
        frame_len = PACK_SN_IN_FRAME_LEN;
    }
    else
    {
        return 0;
    }
    bms_attr_t bms_attr_data = {0};
    bms_attr_data = *get_bms_attr();

    for (uint8_t i = 0; i < frame_len; i++)
    {
        bms_attr_data.pack_sn[can_data->data[0] * PACK_SN_IN_FRAME_LEN + i] = can_data->data[i + 1];
    }

    data_store_save_bms_attr(ST_VAR_POS(bms_attr_t,pack_sn), (uint8_t *)(bms_attr_data.pack_sn), ST_VAR_SIZE( bms_attr_t, pack_sn ) );
    
    if (can_data->data[0] + 1 == sn_cnt)
    {
        
        ext_can_tx_ate_set_pack_sn(can_data, func_code);
    }
    return 0;
}

// BOARD_SN标定0x10F4FFE0
static bool ext_can_rx_ate_set_board_sn(can_frame_data_t *can_data, uint16_t func_code)
{
 if (!special_mode_get(CALI_PARM))
    {
        return 0;
    }
    uint8_t sn_len = sizeof(get_bms_attr()->board_sn); // board_sn后面需要修改uint8_t
    uint8_t sn_cnt = (sn_len + BOARD_SN_IN_FRAME_LEN - 1) / BOARD_SN_IN_FRAME_LEN;
    uint8_t frame_len = 0;
    if (can_data->data[0] + 1 == sn_cnt)
    {
        frame_len = ((sn_len % BOARD_SN_IN_FRAME_LEN) == 0) ? BOARD_SN_IN_FRAME_LEN : sn_len % BOARD_SN_IN_FRAME_LEN;
    }
    else if (can_data->data[0] < sn_cnt)
    {
        frame_len = BOARD_SN_IN_FRAME_LEN;
    }
    else
    {
        return 0;
    }
    bms_attr_t bms_attr_data = {0};
    bms_attr_data = *get_bms_attr();

    for (uint8_t i = 0; i < frame_len; i++)
    {
        bms_attr_data.board_sn[can_data->data[0] * BOARD_SN_IN_FRAME_LEN + i] = can_data->data[i + 1];
    }
    data_store_save_bms_attr(ST_VAR_POS(bms_attr_t,board_sn), (uint8_t *)(bms_attr_data.board_sn), ST_VAR_SIZE( bms_attr_t, board_sn ) );
    if (can_data->data[0] + 1 == sn_cnt)
    {
        ext_can_tx_ate_set_board_sn(can_data, func_code);
    }
    return 0;
}

// 0x0F6:BMS功能开关0x10F6XXE0
static bool ext_can_rx_ate_bcu_func_sw_ctl(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t crc_check = can_single_frame_crc8_calc(can_data, MASTER_CTL_SET_CRC8_MASK);
    if (crc_check != can_data->data[7])
    {
        return 0;
    }
    
    ate_ctl_can_set(ATE_FUNC_SW_CTL_1, can_data->data[0]);
    ate_ctl_can_set(ATE_FUNC_SW_CTL_2, can_data->data[1]);
    ate_ctl_can_set(ATE_FUNC_SW_CTL_3, can_data->data[2]);

    ext_can_tx_ate_bcu_func_sw_ctl(can_data, func_code);
    return 0;
}

// 0x0F7:上位机监控读取0x102CXXE0
static bool ext_can_rx_ate_monitor_rd(can_frame_data_t *can_data, uint16_t func_code)
{
    if (0x01 == can_data->data[0]) // 发送全部
    {
        for (uint8_t i = 0; i < g_bcu_monitor_data_list_len; i++)
        {
            g_ex_can_tx_ate_msg_list[g_bcu_monitor_data_list[i]].p_func_recv_deal_cb(can_data, g_ex_can_tx_ate_msg_list[g_bcu_monitor_data_list[i]].func_code);
        }
    }
    else
    {
        // 根据功能码发送
        for (uint8_t i = 0; i < g_bcu_monitor_data_list_len; i++)
        {
            if (g_ex_can_tx_ate_msg_list[g_bcu_monitor_data_list[i]].func_code == can_data->data[0])
            {
                g_ex_can_tx_ate_msg_list[g_bcu_monitor_data_list[i]].p_func_recv_deal_cb(can_data, g_ex_can_tx_ate_msg_list[g_bcu_monitor_data_list[i]].func_code);
                
                break;
            }
        }
    }
    return 0;
}

// 0x0F9:一键操作标定参数0x10E9XXE0
static bool ext_can_rx_ate_cali_para_ctl(can_frame_data_t *can_data, uint16_t func_code)
{
    #define DEFAULT_OFFSET_TO_FRAME_ID (9)
    #define REVERSE_POS (2) // ate_map_frame_id数组下标值
    const uint8_t ate_map_frame_id[] =
    {   
        EXT_CAN_TX_ATE_FLASH_TEST               ,  // ATE_FLASH测试           
        EXT_CAN_TX_ATE_MODE_CTL                 ,  // 上位机控制老化状态  
        REVERSE_POS,   
        EXT_CAN_TX_ATE_CALI_TIME                ,  // 时间标定                
        EXT_CAN_TX_ATE_SET_PACK_SN              ,  // PACK_SN标定             
        EXT_CAN_TX_ATE_SET_BOARD_SN             ,  // BOARD_SN标定         
        EXT_CAN_TX_ATE_BCU_FUNC_SW_CTL          ,  // BCU功能开关             
        EXT_CAN_TX_ATE_FORCE_CTL                ,  // ATE强制控制指令   
    };

    uint8_t len = sizeof(ate_map_frame_id) / sizeof(ate_map_frame_id[0]);
    if (can_data->data[0] == 0x01) // 读所有数据
    {
        g_cali_para_result = ATE_CALI_READ_OK_RLT;
        for (uint8_t i = 0; i < len; i++)
        {
            if (i == REVERSE_POS)
            {
                continue;
            }
            
            g_ex_can_tx_ate_msg_list[ate_map_frame_id[i]].p_func_recv_deal_cb(can_data, g_ex_can_tx_ate_msg_list[ate_map_frame_id[i]].func_code);
        }
        g_ex_can_tx_ate_msg_list[EXT_CAN_TX_ATE_CALI_PARA_CTL].p_func_recv_deal_cb(can_data, g_ex_can_tx_ate_msg_list[EXT_CAN_TX_ATE_CALI_PARA_CTL].func_code);
    }
    else if (can_data->data[0] == 0x02)
    {
        if (attr_data_resume_default_data() == 0)
        {
            g_cali_para_result = ATE_CALI_RECOVER_OK_RLT;
        }
        else
        {
            g_cali_para_result = ATE_CALI_RECOVER_ERR_RLT;
        }
        g_ex_can_tx_ate_msg_list[EXT_CAN_TX_ATE_CALI_PARA_CTL].p_func_recv_deal_cb(can_data, g_ex_can_tx_ate_msg_list[EXT_CAN_TX_ATE_CALI_PARA_CTL].func_code);
    }
    else if (can_data->data[0] >= DEFAULT_OFFSET_TO_FRAME_ID)
    {
        uint8_t send_id = can_data->data[0] - DEFAULT_OFFSET_TO_FRAME_ID;
        if ((send_id < len) && (send_id != REVERSE_POS))
        {
            g_ex_can_tx_ate_msg_list[ate_map_frame_id[send_id]].p_func_recv_deal_cb(can_data, g_ex_can_tx_ate_msg_list[ate_map_frame_id[send_id]].func_code);
        }
    }
    return 0;
}

// 0x0FA:ATE强制控制指令0x10FAXXE0
static bool ext_can_rx_ate_force_ctl(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t crc_check = can_single_frame_crc8_calc(can_data, ATE_CONTROL_CRC8_MASK);
    if (crc_check != can_data->data[7])
    {
        return 0;
    }
    ate_ctl_can_set(ATE_CTL_ITEM_1, can_data->data[0]);
    ate_ctl_can_set(ATE_CTL_ITEM_2, can_data->data[1]);
    ate_ctl_can_set(ATE_CTL_ITEM_3, can_data->data[2]);

    ext_can_tx_ate_force_ctl(can_data, func_code);
    return 0;
}
/***************************************************************外can接收处理函数end***********************************************/

/***************************************************************外can发送处理函数start***********************************************/
// EVBMM 模块硬件信息报文（命令码 0x02）
//#define GOLD_PRODUCT_SERIAL_NUMBER "S161014A0000" 
//#define GOLD_HW_VER_NUMBER  "V7.0.1" 
//#define GOLD_PRODUCT_NAME  "ESBMM-4812" 
//static bool ex_tx_gold_mod_hw_data_req(can_frame_data_t *can_data, uint16_t func_code)
//{
//    const bms_attr_t *bms_attr = get_bms_attr();
//    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
//    can_frame_id_u rx_can_frame = {can_data->id};
//    can_frame_id_u tx_can_frame = {0};
//    if (can_data->data[1] > PACK_MAX_NUM)
//    {
//        return 0;
//    }
//    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_MODL_HW_DATA_REQ_CMD);
//    pack_info_t* p_bmu_info = get_bmu_info(can_data->data[1] - 1);
//    // 固定模块地址
//    data[1] = can_data->data[1];
//    
//    // 默认包序号0x01 
//    data[0] = 0x01;
//    // 产品序号12-7
//    data[2] = GOLD_PRODUCT_SERIAL_NUMBER[0];
//    data[3] = GOLD_PRODUCT_SERIAL_NUMBER[1];
//    data[4] = GOLD_PRODUCT_SERIAL_NUMBER[2];
//    data[5] = GOLD_PRODUCT_SERIAL_NUMBER[3];
//    data[6] = GOLD_PRODUCT_SERIAL_NUMBER[4];
//    data[7] = GOLD_PRODUCT_SERIAL_NUMBER[5];
//    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
//    
//    // 默认包序号0x02 
//    data[0] = 0x02;
//    // 产品序号6-1
//    data[2] = GOLD_PRODUCT_SERIAL_NUMBER[6];
//    data[3] = GOLD_PRODUCT_SERIAL_NUMBER[7];
//    data[4] = GOLD_PRODUCT_SERIAL_NUMBER[8];
//    data[5] = GOLD_PRODUCT_SERIAL_NUMBER[9];
//    data[6] = GOLD_PRODUCT_SERIAL_NUMBER[10];
//    data[7] = GOLD_PRODUCT_SERIAL_NUMBER[11] + can_data->data[1];
//    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
//    
//    // 默认包序号0x03
//    data[0] = 0x03;
//    // 硬件版本号1-6
//    data[2] = GOLD_HW_VER_NUMBER[0];
//    data[3] = GOLD_HW_VER_NUMBER[1];
//    data[4] = GOLD_HW_VER_NUMBER[2];
//    data[5] = GOLD_HW_VER_NUMBER[3];
//    data[6] = GOLD_HW_VER_NUMBER[4];
//    data[7] = GOLD_HW_VER_NUMBER[5];
//    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
//    
//    // 默认包序号0x04
//    data[0] = 0x04;
//    // 硬件版本号7，产品名称1-5
//    data[2] = 0;
//    data[3] = GOLD_PRODUCT_NAME[0];
//    data[4] = GOLD_PRODUCT_NAME[1];
//    data[5] = GOLD_PRODUCT_NAME[2];
//    data[6] = GOLD_PRODUCT_NAME[3];
//    data[7] = GOLD_PRODUCT_NAME[4];
//    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
//    
//    // 默认包序号0x05
//    data[0] = 0x05;
//    // 电芯节数，电芯个数,1-32节电芯电压线束连线信息
//    data[2] = PACK_CELL_NUM_64;
//    data[3] = PACK_CELL_TEMP_NUM_36;
//    data[4] = 0xFF;
//    data[5] = 0xFF;
//    data[6] = 0xFF;
//    data[7] = 0xFF;
//    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

//    // 默认包序号0x06
//    data[0] = 0x06;
//    // 33-64节电芯电压线束连线信息，1-16电芯温度
//    data[2] = 0xFF;
//    data[3] = 0xFF;
//    data[4] = 0;
//    data[5] = 0;
//    data[6] = 0xFF;
//    data[7] = 0xFF;
//    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
//    
//    // 默认包序号0x07
//    data[0] = 0x07;
//    // 17-64电芯温度
//    data[2] = 0xFF;
//    data[3] = 0x0F;
//    data[4] = 0;
//    data[5] = 0;
//    data[6] = 0;
//    data[7] = 0;
//    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
//    
//    // 默认包序号0xFF
//    data[0] = 0xFF;
//    // 17-64电芯温度
//    data[2] = 0xFF;
//    data[3] = 0x0F;
//    data[4] = 0xFF;
//    data[5] = 0xFF;
//    data[6] = 0xFF;
//    data[7] = 0xFF;
//    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
//    return 0;
//}

// 高特 项目（硬件）信息报文（命令码 0x00）
static bool ex_tx_gold_project_info_req(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *bms_attr = get_bms_attr();
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_PROJECT_INFO_REQ_CMD);
    data[0] = 0x04;  // 产品名称
    // 项目名称
    data[1] = bms_attr->project_ver[0];    //
    data[2] = bms_attr->project_ver[1];

    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

    return 0;
}

// 高特 传感器报文（命令码 0x03）
static bool ex_tx_gold_sensor_data_req(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *bms_attr = get_bms_attr();
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_SENSOR_DATA_REQ_CMD);
    data[0] = 0x01;  // 默认包序号0x01
    // 电流传感器类型
    data[1] = bms_attr->hall_enable;    //remote_cmd_get();
    // 霍尔 1 电流传感器量程
    data[2] = HIGH_BYTE(bms_attr->hall_range[0]);
    data[3] = LOW_BYTE(bms_attr->hall_range[0]);
    // 霍尔 2 电流传感器量程
    data[4] = HIGH_BYTE(bms_attr->hall_range[1]);
    data[5] = LOW_BYTE(bms_attr->hall_range[1]);
    // 霍尔 3 电流传感器量程
    data[6] = HIGH_BYTE(bms_attr->hall_range[2]);
    data[7] = LOW_BYTE(bms_attr->hall_range[2]);
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

    return 0;
}

// 组端总电压上限报警值（命令码 0x04）
static bool ex_tx_gold_clu_volt_over_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *bms_attr = get_bms_attr();
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    memset(data, 0xFF, sizeof(data));
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_CLU_VOLT_OVER_ALM_CMD);
    
    uint16_t tmp = 0;
    // 组端总电压轻微报警上限值
    tmp = bms_attr->safety.total_over_vol_tip.appear_value;
    data[0] = HIGH_BYTE(tmp);
    data[1] = LOW_BYTE(tmp);
    
    // 组端总电压一般报警上限值
    tmp = bms_attr->safety.total_over_vol_alarm.appear_value;
    data[2] = HIGH_BYTE(tmp);
    data[3] = LOW_BYTE(tmp);
    // 组端总电压严重报警上限值
    tmp = bms_attr->safety.total_over_vol_protect.appear_value;
    data[4] = HIGH_BYTE(tmp);
    data[5] = LOW_BYTE(tmp);
    // 组端总电压报警上限回差
    data[6] = bms_attr->safety.total_over_vol_protect.appear_value - bms_attr->safety.total_over_vol_protect.cancel_value;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 组端总电压下限报警值（命令码 0x05）
static bool ex_tx_gold_clu_volt_down_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *bms_attr = get_bms_attr();
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    memset(data, 0xFF, sizeof(data));
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_CLU_VOLT_DOWN_ALM_CMD);

    uint16_t tmp = 0;
    // 组端总电压轻微报警上限值
    tmp = bms_attr->safety.total_under_vol_tip.appear_value;
    data[0] = HIGH_BYTE(tmp);
    data[1] = LOW_BYTE(tmp);
    
    // 组端总电压一般报警上限值
    tmp = bms_attr->safety.total_under_vol_alarm.appear_value;
    data[2] = HIGH_BYTE(tmp);
    data[3] = LOW_BYTE(tmp);
    // 组端总电压严重报警上限值
    tmp = bms_attr->safety.total_under_vol_protect.appear_value;
    data[4] = HIGH_BYTE(tmp);
    data[5] = LOW_BYTE(tmp);
    // 组端总电压报警上限回差
    data[6] = bms_attr->safety.total_under_vol_protect.cancel_value - bms_attr->safety.total_under_vol_protect.appear_value;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 充电电流报警值（命令码 0x06）
static bool ex_tx_gold_chg_curr_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *bms_attr = get_bms_attr();
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_CHG_CURR_ALM_CMD);

    // 充电类型 1：快充  2：慢充/极柱过温  3：馈电，当前只有一种，但是不知道是那种TODO
    // 由于解析的是功能码是0x1F帧
    data[0] = can_data->data[1];

    uint16_t tmp = 0;
    if (data[0] == FAST_CHG_TYPE)
    {
        // 充电电流过流轻微报警值
        tmp = bms_attr->safety.chg_over_cur_tip.appear_value;
        data[1] = HIGH_BYTE(tmp);
        data[2] = LOW_BYTE(tmp);
        
        // 充电电流过流一般报警值
        tmp = bms_attr->safety.chg_over_cur_alarm.appear_value;
        data[3] = HIGH_BYTE(tmp);
        data[4] = LOW_BYTE(tmp);
        // 充电电流过流严重报警上限值
        tmp = bms_attr->safety.chg_over_cur_protect.appear_value;
        data[5] = HIGH_BYTE(tmp);
        data[6] = LOW_BYTE(tmp);
        // 充电电流过流报警上限回差
        data[7] = bms_attr->safety.chg_over_cur_protect.appear_value - bms_attr->safety.chg_over_cur_protect.cancel_value;
    }
    else if (data[0] == POWER_TERMINAL_TEMP_TYPE)
    {
        // 功率端子温度过高轻微报警值
        tmp = bms_attr->safety.power_terminal_temp_over_tip.appear_value;
        data[1] = HIGH_BYTE(tmp);
        data[2] = LOW_BYTE(tmp);
        
        // 功率端子温度过高一般报警值
        tmp = bms_attr->safety.power_terminal_temp_over_alarm.appear_value;
        data[3] = HIGH_BYTE(tmp);
        data[4] = LOW_BYTE(tmp);
        // 功率端子温度过高严重报警上限值
        tmp = bms_attr->safety.power_terminal_temp_over_protect.appear_value;
        data[5] = HIGH_BYTE(tmp);
        data[6] = LOW_BYTE(tmp);
        // 功率端子温度过高报警上限回差
        data[7] = bms_attr->safety.power_terminal_temp_over_protect.appear_value - bms_attr->safety.power_terminal_temp_over_protect.cancel_value;
    }
    else
    {
        return 0;
    }
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 放电电流报警值（命令码 0x07）
static bool ex_tx_gold_dsg_curr_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *bms_attr = get_bms_attr();
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    memset(data, 0xFF, sizeof(data));
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_DSG_CURR_ALM_CMD);

    uint16_t tmp = 0;

    // 放电电流过流轻微报警上限值
    tmp = bms_attr->safety.dchg_over_cur_tip.appear_value;
    data[0] = HIGH_BYTE(tmp);
    data[1] = LOW_BYTE(tmp);
    
    // 放电电流过流一般报警上限值
    tmp = bms_attr->safety.dchg_over_cur_alarm.appear_value;
    data[2] = HIGH_BYTE(tmp);
    data[3] = LOW_BYTE(tmp);
    // 放电电流过流严重报警上限值
    tmp = bms_attr->safety.dchg_over_cur_protect.appear_value;
    data[4] = HIGH_BYTE(tmp);
    data[5] = LOW_BYTE(tmp);
    // 放电电流过流报警上限回差
    data[6] = bms_attr->safety.dchg_over_cur_protect.appear_value - bms_attr->safety.dchg_over_cur_protect.cancel_value;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 充电单体电池温度报警值（命令码 0x08）
static bool ex_tx_gold_chg_cell_temp_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *bms_attr = get_bms_attr();
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_CHG_CELL_TEMP_ALM_CMD);

    // 充电单体电池温度轻微报警上限值
    data[0] = (bms_attr->safety.chg_over_cell_temp_tip.appear_value - GOLD_TEMP_SET_OFFSET_VAL_0P1) / 10;
    // 充电单体电池温度一般报警上限值
    data[1] = (bms_attr->safety.chg_over_cell_temp_alarm.appear_value - GOLD_TEMP_SET_OFFSET_VAL_0P1) / 10;
    // 充电单体电池温度严重报警上限值
    data[2] = (bms_attr->safety.chg_over_cell_temp_protect.appear_value - GOLD_TEMP_SET_OFFSET_VAL_0P1) / 10;
    // 充电单体电池温度上限报警回差值
    data[3] = (bms_attr->safety.chg_over_cell_temp_protect.appear_value - bms_attr->safety.chg_over_cell_temp_protect.cancel_value) / 10;

    // 充电单体电池温度轻微报警下限值
    data[4] = ((int16_t)bms_attr->safety.chg_under_cell_temp_tip.appear_value - GOLD_TEMP_SET_OFFSET_VAL_0P1) / 10;
    // 充电单体电池温度一般报警下限值
    data[5] = ((int16_t)bms_attr->safety.chg_under_cell_temp_alarm.appear_value - GOLD_TEMP_SET_OFFSET_VAL_0P1) / 10;
    // 充电单体电池温度严重报警下限值
    data[6] = ((int16_t)bms_attr->safety.chg_under_cell_temp_protect.appear_value - GOLD_TEMP_SET_OFFSET_VAL_0P1) / 10;
    // 充电单体电池温度上限报警回差值
    data[7] = abs(bms_attr->safety.chg_under_cell_temp_protect.appear_value - bms_attr->safety.chg_under_cell_temp_protect.cancel_value) / 10;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 单体电池温差报警值（命令码 0x09）
static bool ex_tx_gold_cell_temp_dis_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *bms_attr = get_bms_attr();
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    memset(data, 0xFF, sizeof(data));
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_CELL_TEMP_DIS_ALM_CMD);

    // 单体电池温差轻微报警门限值
    data[0] = ((int16_t)bms_attr->safety.cell_temp_diff_tip.appear_value) / 10;
    // 单体电池温差一般报警门限值
    data[1] = ((int16_t)bms_attr->safety.cell_temp_diff_alarm.appear_value) / 10;
    // 单体电池温差严重报警门限值
    data[2] = ((int16_t)bms_attr->safety.cell_temp_diff_protect.appear_value) / 10;
    // 单体电池温差严重报警回差值
    data[3] = (bms_attr->safety.cell_temp_diff_protect.appear_value - bms_attr->safety.cell_temp_diff_protect.cancel_value) / 10;

    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// SOC 报警值（命令码 0x0A）
static bool ex_tx_gold_soc_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *bms_attr = get_bms_attr();
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    memset(data, 0xFF, sizeof(data));
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_SOC_ALM_CMD);

    memset(data, 0xFF, sizeof(data));
    data[0] = SET_CFG_SOC_UNDER_LIMIT_TYPE; // 下限值
    // SOC 轻微报警值
    data[1] = bms_attr->safety.bat_soc_under_tip.appear_value / 10;
    // SOC 一般报警值
    data[2] = bms_attr->safety.bat_soc_under_alarm.appear_value / 10;
    // SOC 严重报警值
    data[3] = bms_attr->safety.bat_soc_under_protect.appear_value / 10;
    // SOC 报警回差值
    data[4] = (bms_attr->safety.bat_soc_under_protect.cancel_value - bms_attr->safety.bat_soc_under_protect.appear_value) / 10;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    
    data[0] = SET_CFG_SOC_OVER_LIMIT_TYPE; //  上限值
    // SOC 轻微报警值
    data[1] = bms_attr->safety.bat_soc_over_tip.appear_value / 10;
    // SOC 一般报警值
    data[2] = bms_attr->safety.bat_soc_over_alarm.appear_value / 10;
    // SOC 严重报警值
    data[3] = bms_attr->safety.bat_soc_over_protect.appear_value / 10;
    // SOC 报警回差值
    data[4] = (bms_attr->safety.bat_soc_over_protect.appear_value - bms_attr->safety.bat_soc_over_protect.cancel_value) / 10;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
   
    data[0] = SET_CFG_SOC_DIFF_LIMIT_TYPE; //  差异值
    // SOC 轻微报警值
    data[1] = bms_attr->safety.bat_soc_diff_tip.appear_value / 10;
    // SOC 一般报警值
    data[2] = bms_attr->safety.bat_soc_diff_alarm.appear_value / 10;
    // SOC 严重报警值
    data[3] = bms_attr->safety.bat_soc_diff_protect.appear_value / 10;
    // SOC 报警回差值
    data[4] = (bms_attr->safety.bat_soc_diff_protect.appear_value - bms_attr->safety.bat_soc_diff_protect.cancel_value) / 10;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 绝缘电阻报警值（命令码 0x0B）
static bool ex_tx_gold_inv_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *bms_attr = get_bms_attr();
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_INV_ALM_CMD);

    uint16_t tmp = 0;

    // 绝缘电阻正负对地电阻轻微报警值
    tmp = bms_attr->safety.ins_val_under_tip.appear_value;
    data[0] = HIGH_BYTE(tmp);
    data[1] = LOW_BYTE(tmp);
    
    // 绝缘电阻正负对地电阻一般报警上限值
    tmp = bms_attr->safety.ins_val_under_alarm.appear_value;
    data[2] = HIGH_BYTE(tmp);
    data[3] = LOW_BYTE(tmp);
    // 绝缘电阻正负对地电阻严重报警上限值
    tmp = bms_attr->safety.ins_val_under_protect.appear_value;
    data[4] = HIGH_BYTE(tmp);
    data[5] = LOW_BYTE(tmp);
    // 绝缘电阻正负对地电阻报警上限回差
    data[6] = bms_attr->safety.ins_val_under_protect.cancel_value - bms_attr->safety.ins_val_under_protect.appear_value;
    data[7] = 0xFF; // 预留无效值
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 电池单体电压上限报警值（命令码 0x0C）
static bool ex_tx_gold_cell_volt_over_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *bms_attr = get_bms_attr();
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_CELL_VOLT_OVER_ALM_CMD);

    uint16_t tmp = 0;

    // 电池单体电压上限轻微报警值
    tmp = bms_attr->safety.cell_over_vol_tip.appear_value;
    data[0] = HIGH_BYTE(tmp);
    data[1] = LOW_BYTE(tmp);
    
    // 电池单体电压上限一般报警上限值
    tmp = bms_attr->safety.cell_over_vol_alarm.appear_value;
    data[2] = HIGH_BYTE(tmp);
    data[3] = LOW_BYTE(tmp);
    // 电池单体电压上限严重报警上限值
    tmp = bms_attr->safety.cell_over_vol_protect.appear_value;
    data[4] = HIGH_BYTE(tmp);
    data[5] = LOW_BYTE(tmp);
    // 电池单体电压上限报警上限回差
    data[6] = bms_attr->safety.cell_over_vol_protect.appear_value - bms_attr->safety.cell_over_vol_protect.cancel_value;
    data[7] = 0xFF; // 预留无效值
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 电池单体电压下限报警值（命令码 0x0D）
static bool ex_tx_gold_cell_volt_down_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *bms_attr = get_bms_attr();
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_CELL_VOLT_DOWN_ALM_CMD);

    uint16_t tmp = 0;

    // 电池单体电压下限轻微报警值
    tmp = bms_attr->safety.cell_under_vol_tip.appear_value;
    data[0] = HIGH_BYTE(tmp);
    data[1] = LOW_BYTE(tmp);
    
    // 电池单体电压下限一般报警上限值
    tmp = bms_attr->safety.cell_under_vol_alarm.appear_value;
    data[2] = HIGH_BYTE(tmp);
    data[3] = LOW_BYTE(tmp);
    // 电池单体电压下限严重报警上限值
    tmp = bms_attr->safety.cell_under_vol_protect.appear_value;
    data[4] = HIGH_BYTE(tmp);
    data[5] = LOW_BYTE(tmp);
    // 电池单体电压下限报警上限回差
    data[6] = bms_attr->safety.cell_under_vol_protect.cancel_value - bms_attr->safety.cell_under_vol_protect.appear_value;
    data[7] = 0xFF; // 预留无效值
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 电池单体电压压差报警值（命令码 0x0E）
static bool ex_tx_gold_cell_volt_dis_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *bms_attr = get_bms_attr();
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_CELL_VOLT_DIS_ALM_CMD);

    uint16_t tmp = 0;

    // 电池单体电压下限轻微报警值
    tmp = bms_attr->safety.cell_vol_diff_tip.appear_value;
    data[0] = HIGH_BYTE(tmp);
    data[1] = LOW_BYTE(tmp);
    
    // 电池单体电压下限一般报警上限值
    tmp = bms_attr->safety.cell_vol_diff_alarm.appear_value;
    data[2] = HIGH_BYTE(tmp);
    data[3] = LOW_BYTE(tmp);
    // 电池单体电压下限严重报警上限值
    tmp = bms_attr->safety.cell_vol_diff_protect.appear_value;
    data[4] = HIGH_BYTE(tmp);
    data[5] = LOW_BYTE(tmp);
    // 电池单体电压下限报警上限回差
    data[6] = bms_attr->safety.cell_vol_diff_protect.appear_value - bms_attr->safety.cell_vol_diff_protect.cancel_value;
    data[7] = 0xFF; // 预留无效值
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 模块温度上限报警值（命令码 0x0F）
static bool ex_tx_gold_mode_temp_over_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *bms_attr = get_bms_attr();
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    memset(data, 0xFF, sizeof(data));
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_MODE_TEMP_OVER_ALM_CMD);

    // 模块温差轻微报警上限值
    data[0] = (bms_attr->safety.mod_temp_over_tip.appear_value - GOLD_TEMP_SET_OFFSET_VAL_0P1) / 10;
    // 模块温差一般报警上限值
    data[1] = (bms_attr->safety.mod_temp_over_alarm.appear_value - GOLD_TEMP_SET_OFFSET_VAL_0P1) / 10;
    // 模块温差严重报警上限值
    data[2] = (bms_attr->safety.mod_temp_over_protect.appear_value - GOLD_TEMP_SET_OFFSET_VAL_0P1) / 10;
    // 模块温差报警回差值
    data[3] = (bms_attr->safety.mod_temp_over_protect.appear_value - bms_attr->safety.mod_temp_over_protect.cancel_value) / 10;

    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// RTC 数据（命令码 0x12）
static bool ex_tx_gold_sys_rtc_data(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_SYS_RTC_DATA_CMD);

    sdk_rtc_t rtc_time = {0};
    sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);

    uint16_t year_val = 2000 + rtc_time.tm_year;
    data[0] = HIGH_BYTE(year_val);
    data[1] = LOW_BYTE(year_val);
    data[2] = rtc_time.tm_mon;
    data[3] = rtc_time.tm_day;
    data[4] = rtc_time.tm_hour;
    data[5] = rtc_time.tm_min;
    data[6] = rtc_time.tm_sec;
    data[7] = 0xFF; //保留
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 从控模块基本参数（命令码 0x14）
static bool ex_tx_gold_sys_arch_data(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *bms_attr = get_bms_attr();
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    memset(data, 0xFF, sizeof(data));
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_SYS_ARCH_CMD);

    data[0] = 1; //包序号
    data[1] = bms_attr->clu_pack_num; //系统总模块数
    uint16_t tmp = bms_attr->pack_cell_num * bms_attr->clu_pack_num;
    data[2] = HIGH_BYTE(tmp);   //系统总电池节数
    data[3] = LOW_BYTE(tmp);
    tmp = bms_attr->pack_temp_num * bms_attr->clu_pack_num;
    data[4] = HIGH_BYTE(tmp);   //系统总温度个数
    data[5] = LOW_BYTE(tmp);    
    
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 电池主参数（命令码 0x16）
static bool ex_tx_gold_cell_main_para(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *bms_attr = get_bms_attr();
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    memset(data, 0xFF, sizeof(data));
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_CELL_MAIN_PARA_CMD);

    // 电池类型
    data[0] = bms_attr->cell_type;
    // 电池容量
    data[1] = HIGH_BYTE(bms_attr->bat_cap);
    data[2] = LOW_BYTE(bms_attr->bat_cap);
    // 电池型号
    data[3] = bms_attr->cell_model;
    // 厂家
    data[4] = bms_attr->manufactor;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 设置 SOC 参数（命令码 0x1A）
static bool ex_tx_gold_set_sox_para(can_frame_data_t *can_data, uint16_t func_code)
{
    // 读取逻辑不清晰 TODO
    return 0;
}

// 放电单体电池温度报警值（命令码 0x1C）
static bool ex_tx_gold_dsg_cell_temp_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *bms_attr = get_bms_attr();
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_DSG_CELL_TEMP_ALM_CMD);

    // 放电单体电池温度轻微报警上限值
    data[0] = (bms_attr->safety.dchg_over_cell_temp_tip.appear_value - GOLD_TEMP_SET_OFFSET_VAL_0P1) / 10;
    // 放电单体电池温度一般报警上限值
    data[1] = (bms_attr->safety.dchg_over_cell_temp_alarm.appear_value - GOLD_TEMP_SET_OFFSET_VAL_0P1) / 10;
    // 放电单体电池温度严重报警上限值
    data[2] = (bms_attr->safety.dchg_over_cell_temp_protect.appear_value - GOLD_TEMP_SET_OFFSET_VAL_0P1) / 10;
    // 放电单体电池温度上限报警回差值
    data[3] = (bms_attr->safety.dchg_over_cell_temp_protect.appear_value - bms_attr->safety.dchg_over_cell_temp_protect.cancel_value) / 10;

    // 放电单体电池温度轻微报警下限值
    data[4] = ((int16_t)bms_attr->safety.dchg_under_cell_temp_tip.appear_value - GOLD_TEMP_SET_OFFSET_VAL_0P1) / 10;
    // 放电单体电池温度一般报警下限值
    data[5] = ((int16_t)bms_attr->safety.dchg_under_cell_temp_alarm.appear_value - GOLD_TEMP_SET_OFFSET_VAL_0P1) / 10;
    // 放电单体电池温度严重报警下限值
    data[6] = ((int16_t)bms_attr->safety.dchg_under_cell_temp_protect.appear_value - GOLD_TEMP_SET_OFFSET_VAL_0P1) / 10;
    // 放电单体电池温度下限报警回差值
    data[7] = (bms_attr->safety.dchg_under_cell_temp_protect.cancel_value - bms_attr->safety.dchg_under_cell_temp_protect.appear_value) / 10;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 电池模组电压上限报警值（命令码 0x2B）
static bool ex_tx_gold_pack_volt_over_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *bms_attr = get_bms_attr();
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_PACK_VOLT_OVER_ALM_CMD);

    uint16_t tmp = 0;

    // 电池模组电压上限轻微报警值
    tmp = bms_attr->safety.bat_over_vol_tip.appear_value;
    data[0] = HIGH_BYTE(tmp);
    data[1] = LOW_BYTE(tmp);
    
    // 电池模组电压上限一般报警上限值
    tmp = bms_attr->safety.bat_over_vol_alarm.appear_value;
    data[2] = HIGH_BYTE(tmp);
    data[3] = LOW_BYTE(tmp);
    // 电池模组电压上限严重报警上限值
    tmp = bms_attr->safety.bat_over_vol_protect.appear_value;
    data[4] = HIGH_BYTE(tmp);
    data[5] = LOW_BYTE(tmp);
    // 电池模组电压上限报警上限回差
    data[6] = bms_attr->safety.bat_over_vol_protect.appear_value - bms_attr->safety.bat_over_vol_protect.cancel_value;
    data[7] = 0xFF; // 预留无效值
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 电池模组电压下限报警值（命令码 0x2C）
static bool ex_tx_gold_pack_volt_down_alm(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *bms_attr = get_bms_attr();
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_PACK_VOLT_DOWN_ALM_CMD);

    uint16_t tmp = 0;

    // 电池模组电压轻微报警下限值
    tmp = bms_attr->safety.bat_under_vol_tip.appear_value;
    data[0] = HIGH_BYTE(tmp);
    data[1] = LOW_BYTE(tmp);
    
    // 电池模组电压上限一般报警下限值
    tmp = bms_attr->safety.bat_under_vol_alarm.appear_value;
    data[2] = HIGH_BYTE(tmp);
    data[3] = LOW_BYTE(tmp);
    // 电池模组电压上限严重报警下限值
    tmp = bms_attr->safety.bat_under_vol_protect.appear_value;
    data[4] = HIGH_BYTE(tmp);
    data[5] = LOW_BYTE(tmp);
    // 电池模组电压上限报警下限回差
    data[6] = bms_attr->safety.bat_under_vol_protect.cancel_value - bms_attr->safety.bat_under_vol_protect.appear_value;
    data[7] = 0xFF; // 预留无效值
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// EVBCM 应答 PC 请求电池单体电压消息（命令码 0x31）
#define ONE_PACKAGE_CELL_VOLT_NUM       60
#define ONE_PACKAGE_FRAME_CELL_VOLT_NUM 20
#define ONE_FRAME_CELL_VOLT_NUM         3
static bool ex_tx_gold_cell_volt_ack(can_frame_data_t *can_data, uint16_t func_code)
{
    // 接收到0x30的包序号
    const bms_attr_t *bms_attr = get_bms_attr();    
    uint8_t package_no = can_data->data[1]; // 1-7
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_CELL_VOLT_ACK_CMD);

    uint8_t send_frame_num = 0;
    uint16_t cell_id = (package_no - 1) * ONE_PACKAGE_CELL_VOLT_NUM;
    const pack_cell_info_t* p_cell_info = get_bmu_cell_info();

    if (p_cell_info == NULL)
    {
        return 0;
    }
    data[1] = package_no;

    uint8_t send_num = 0;
    // 先确认一共有多少个数据
    uint16_t cluster_max_data_frame = bms_attr->clu_pack_num * bms_attr->pack_cell_num ;
    while (send_frame_num < ONE_PACKAGE_FRAME_CELL_VOLT_NUM)    
    {
        send_frame_num++;
        data[0] = send_frame_num;
        // 主要是确认每帧数据能否发齐；
        if (cell_id <= (cluster_max_data_frame - ONE_FRAME_CELL_VOLT_NUM) )
        {
            send_num = ONE_FRAME_CELL_VOLT_NUM;
        }
        else
        {
            memset(&data[2], 0xFF, 6);  //剩余6个字节需要赋值
            if (cell_id >= cluster_max_data_frame)
            {
                send_num = 0;
                break;
            }
            else
            {
                send_num = cluster_max_data_frame % ONE_FRAME_CELL_VOLT_NUM;
            }
        }
        for (uint8_t i = 0; i< send_num; i++)
        {
            data[2 + 2 * i] = HIGH_BYTE(p_cell_info->cell_volt[cell_id + i]);   //分高低位发送
            data[2 + 2 * i + 1] = LOW_BYTE(p_cell_info->cell_volt[cell_id + i]);
        }
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
        cell_id += ONE_FRAME_CELL_VOLT_NUM;
    }    
    return 0;
}

// EVBCM 应答 PC 请求电池单体温度消息（命令码 0x32）
#define ONE_PACKAGE_CELL_TEMP_NUM       120
#define ONE_PACKAGE_FRAME_CELL_TEMP_NUM 20
#define ONE_FRAME_CELL_TEMP_NUM         6
#define CELL_TEMP_OFFSET                40  // 单位℃
static bool ex_tx_gold_cell_temp_ack(can_frame_data_t *can_data, uint16_t func_code)
{
    // 接收到0x32的包序号
    const bms_attr_t *bms_attr = get_bms_attr();
    uint8_t package_no = can_data->data[1]; // 1-9
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_CELL_TEMP_ACK_CMD);

    uint8_t send_frame_num = 0;
    uint16_t cell_id = (package_no - 1) * ONE_PACKAGE_CELL_TEMP_NUM;
    const pack_cell_info_t* p_cell_info = get_bmu_cell_info();

    if (p_cell_info == NULL)
    {
        return 0;
    }
    data[1] = package_no;
    uint8_t send_num = 0;
    // 先确认一共有多少个数据
    uint16_t cluster_max_data_frame = bms_attr->clu_pack_num * bms_attr->pack_temp_num ;
    while (send_frame_num < ONE_PACKAGE_FRAME_CELL_TEMP_NUM)
    {
        send_frame_num++;
        data[0] = send_frame_num;
        // 主要是确认每帧数据能否发齐；
        if (cell_id <= (cluster_max_data_frame - ONE_FRAME_CELL_TEMP_NUM) )
        {
            send_num = ONE_FRAME_CELL_TEMP_NUM;
        }
        else
        {
            memset(&data[2], 0xFF, ONE_FRAME_CELL_TEMP_NUM);
            if (cell_id >= cluster_max_data_frame)
            {
                send_num = 0;
                break;
            }
            else
            {
                send_num = cluster_max_data_frame % ONE_FRAME_CELL_TEMP_NUM;
            }
        }
        for (uint8_t i = 0; i< send_num; i++)
        {
            data[2 + i] = (int16_t)p_cell_info->cell_temp[cell_id + i] + CELL_TEMP_OFFSET;
        }
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
        cell_id += ONE_FRAME_CELL_TEMP_NUM;
    }
    return 0;
}

// EVBCM 应答 PC 请求极柱温度消息（命令码（ 0x32+0x80）） 与0x35一起回复 0x18B2
static bool ex_tx_gold_power_terminal_tmep_ack(can_frame_data_t *can_data, uint16_t func_code)
{
        // 接收到0x30的包序号
    const bms_attr_t *p_bmu_attr = get_bms_attr();
    uint8_t pack_num = p_bmu_attr->clu_pack_num;//auto_addressing_pack_num_get()
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_OTHER_TMEP_ACK_CMD);
    pack_info_t* p_bmu_info = NULL;
    data[1] = PACK_POWER_TERMINAL_TEMP_NUM;
    for (uint8_t i = 0; i < pack_num; i++)
    {
        data[0] = i + 1;
        p_bmu_info = get_bmu_info(i);
        if (p_bmu_info == NULL)
        {
            continue;
        }
        data[2] = (int16_t)p_bmu_info->yc2[YC2_SGN_POWER_TEMP1] / 10 + 40;
        data[3] = (int16_t)p_bmu_info->yc2[YC2_SGN_POWER_TEMP2] / 10 + 40;
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
        p_bmu_info = NULL;
    }
   
    return 0;
}

// EVBCM 应答 PC 请求电池单体 SOC 消息（命令码 0x33）
#define ONE_PACKAGE_CELL_SOX_NUM       120
#define ONE_PACKAGE_FRAME_CELL_SOX_NUM 20
#define ONE_FRAME_CELL_SOX_NUM         6
static bool ex_tx_gold_cell_soc_ack(can_frame_data_t *can_data, uint16_t func_code)
{
    // 接收到0x33的包序号
    const bms_attr_t *bms_attr = get_bms_attr();
    uint8_t package_no = can_data->data[1]; // 1-4
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_CELL_SOC_ACK_CMD);

    uint8_t send_frame_num = 0;
    const pack_cell_info_t* p_cell_info = get_bmu_cell_info();

    if (p_cell_info == NULL)
    {
        return 0;
    }
    data[1] = package_no;
    
    if(5 == package_no) //包5专门用来请求累计充放电量
    {
        sox_stats_t sox_stats = {0};
        sox_stats_get(&sox_stats);        
        data[0] = 1;        
        fill_can_data_buff(sox_stats.sumed_chg_ah * 10, &data[2], DWORD_SIZE); //  单位0.1Ah
        fill_can_data_buff(sox_stats.sumed_display_cycle / 10, &data[6], DWORD_SIZE); //  单位0.1次
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);        
        
        data[0] = 2;        
        memset(&data[2], 0, ONE_FRAME_CELL_SOX_NUM);
        fill_can_data_buff(sox_stats.sumed_dsg_ah * 10, &data[2], DWORD_SIZE); //  单位0.1Ah
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);           
        
        data[0] = 3;        
        memset(&data[2], 0, ONE_FRAME_CELL_SOX_NUM);
        fill_can_data_buff(sox_stats.sumed_chg_wh / 10, &data[2], DWORD_SIZE); //  单位0.01Kwh
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);           

        data[0] = 4;        
        memset(&data[2], 0, ONE_FRAME_CELL_SOX_NUM);
        fill_can_data_buff(sox_stats.sumed_dsg_wh / 10, &data[2], DWORD_SIZE); //  单位0.01Kwh
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);           
        return 0;
    }
    
    uint16_t cell_id = (package_no - 1) * ONE_PACKAGE_CELL_SOX_NUM;
    uint8_t send_num = 0;
    // 先确认一共有多少个数据
    uint16_t cluster_max_data_frame = bms_attr->clu_pack_num * bms_attr->pack_cell_num ;
    while (send_frame_num < ONE_PACKAGE_FRAME_CELL_SOX_NUM)
    {
        send_frame_num++;
        data[0] = send_frame_num;
        // 主要是确认每帧数据能否发齐；
        if (cell_id <= (cluster_max_data_frame - ONE_FRAME_CELL_SOX_NUM) )
        {
            send_num = ONE_FRAME_CELL_SOX_NUM;
        }
        else
        {
            memset(&data[2], 0, ONE_FRAME_CELL_SOX_NUM);
            if (cell_id >= cluster_max_data_frame)
            {
                send_num = 0;
                break;
            }
            else
            {
                send_num = cluster_max_data_frame % ONE_FRAME_CELL_SOX_NUM;
            }
        }
        for (uint8_t i = 0; i< send_num; i++)
        {
            data[2 + i] = (int16_t)p_cell_info->cell_soc[cell_id + i];  //data[2]开始才是数据位
        }
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
        cell_id += ONE_FRAME_CELL_SOX_NUM;
    }    
    return 0;
}

// EVBCM 应答 PC 请求电池单体 SOH 消息（命令码 0x34）
static bool ex_tx_gold_cell_soh_ack(can_frame_data_t *can_data, uint16_t func_code)
{
    // 接收到0x30的包序号
    const bms_attr_t *bms_attr = get_bms_attr();
    uint8_t package_no = can_data->data[1]; // 1-9
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_CELL_SOH_ACK_CMD);

    uint8_t send_frame_num = 0;
    uint16_t cell_id = (package_no - 1) * ONE_PACKAGE_CELL_SOX_NUM;
    const pack_cell_info_t* p_cell_info = get_bmu_cell_info();

    if (p_cell_info == NULL)
    {
        return 0;
    }
    data[1] = package_no;
    
    uint8_t send_num = 0;
    // 先确认一共有多少个数据
    uint16_t cluster_max_data_frame = bms_attr->clu_pack_num * bms_attr->pack_cell_num ;
    while (send_frame_num < ONE_PACKAGE_FRAME_CELL_SOX_NUM)
    {
        send_frame_num++;
        data[0] = send_frame_num;
        // 主要是确认每帧数据能否发齐；
        if (cell_id <= (cluster_max_data_frame - ONE_FRAME_CELL_SOX_NUM) )
        {
            send_num = ONE_FRAME_CELL_SOX_NUM;
        }
        else
        {
            memset(&data[2], 0, ONE_FRAME_CELL_SOX_NUM);
            if (cell_id >= cluster_max_data_frame)
            {
                send_num = 0;
                break;
            }
            else
            {
                send_num = cluster_max_data_frame % ONE_FRAME_CELL_SOX_NUM;
            }
        }
        for (uint8_t i = 0; i< send_num; i++)
        {
            data[2 + i] = (int16_t)p_cell_info->cell_soh[cell_id + i];  //data[2]开始才是数据位
        }
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
        cell_id += ONE_FRAME_CELL_SOX_NUM;
    }        
    return 0;
}

// EVBCM 应答 PC 请求主控采集信息消息（命令码 0x35）
static bool ex_tx_gold_sample_ack(can_frame_data_t *can_data, uint16_t func_code)
{
    // 接收到0x30的包序号
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_SAMPLE_ACK_CMD);
    const sample_data_t* p_sample_data = p_sample_data_get();
    if (p_sample_data == NULL)
    {
        return 0;
    }
    uint16_t tmp = 0;
    // 包序号0x1
    data[0] = 0x01;
    // 模块温度
    data[1] = (int8_t)(p_sample_data->adc_sample_other_temp[PCB_TEMP] / 10) + 40;
    // 组端电压, 单位0.1V/bit
    tmp = p_sample_data->bus_volt / 100;
    data[2] = HIGH_BYTE(tmp);
    data[3] = LOW_BYTE(tmp);
     //  0.1A/bit 偏移量：-1600A
    tmp = (int16_t)(p_sample_data->sys_current / 100 + 16000);
    data[4] = HIGH_BYTE(tmp);
    data[5] = LOW_BYTE(tmp);
    // 绝缘阻抗R+
    tmp = insulation_impedance_value_get();
    data[6] = HIGH_BYTE(tmp);
    data[7] = LOW_BYTE(tmp);
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    
    // 包序号0x2
    const batt_clu_sox* p_sox_data = sox_data_get();
    data[0] = 0x02;
    // 绝缘阻抗R-
    tmp = insulation_impedance_value_get();
    data[1] = HIGH_BYTE(tmp);
    data[2] = LOW_BYTE(tmp);
    // 组端 SOC
    data[3] = p_sox_data->batt_clu_display_soc;
    // 供电电压 单位0.1V/bit
    tmp = p_sample_data->power_24v_volt / 100;
    data[4] = HIGH_BYTE(tmp);
    data[5] = LOW_BYTE(tmp);
    // 预充电压 单位0.1V/bit TODO
    tmp = p_sample_data->load_volt / 100;
    data[6] = HIGH_BYTE(tmp);
    data[7] = LOW_BYTE(tmp);
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    
    // 包序号0x3
    //data[0] = 0x03;
    memset(&data[1], 0xFF, 7);
    //can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    
    // 包序号0x4
    data[0] = 0x04;
    // 组端温度 1-4, 顺序需要根据实际调整TODO
    data[3] = (int8_t)(p_sample_data->adc_sample_other_temp[LOAD_N_TEMP] / 10 + 40);
    data[4] = (int8_t)(p_sample_data->adc_sample_other_temp[BAT_N_TEMP]  / 10 + 40);
    data[5] = (int8_t)(p_sample_data->adc_sample_other_temp[LOAD_P_TEMP] / 10 + 40);
    data[6] = (int8_t)(p_sample_data->adc_sample_other_temp[BAT_P_TEMP]  / 10 + 40);
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    
    // 包序号0x5
    data[0] = 0x05;
    // 组端电流 2  用Can霍尔电流 
    pack_other_device_info_t g_pack_other_device_info = *get_other_device_info();
    tmp = (int16_t)(g_pack_other_device_info.hall_data_deal / 100 + 16000);
    data[1] = HIGH_BYTE(tmp);
    data[2] = LOW_BYTE(tmp);
    // 组端电流 3  用AD霍尔电流 
    tmp = (int16_t)(p_sample_data->hall_cur / 100 + 16000);
    data[3] = HIGH_BYTE(tmp);
    data[4] = LOW_BYTE(tmp);
    //保留
    data[5] = 0xFF;
    data[6] = 0xFF;
    data[7] = 0xFF;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    
    // 极柱温度
    ex_tx_gold_power_terminal_tmep_ack(can_data, func_code);
    return 0;
}

// EVBCM 应答 PC 请求系统概要信息消息（命令码 0x36）
static bool ex_tx_gold_sys_summary_ack(can_frame_data_t *can_data, uint16_t func_code)
{
    // 接收到0x30的包序号
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_SYS_SUMMARY_ACK_CMD);
    
    const bmu_data_unify_t* bmu_data_unify = bmu_data_unify_get();
    if (bmu_data_unify == NULL)
    {
        return 0;
    }
    
    // 包序号0x1
    data[0] = 0x01;
    data[1] = 0xFF; // 保留
    // 电芯电压最大值前三
    data[2] = HIGH_BYTE(bmu_data_unify->bmu_cell_info.max_cell_volt[0]);
    data[3] = LOW_BYTE(bmu_data_unify->bmu_cell_info.max_cell_volt[0]);
    data[4] = HIGH_BYTE(bmu_data_unify->bmu_cell_info.max_cell_volt[1]);
    data[5] = LOW_BYTE(bmu_data_unify->bmu_cell_info.max_cell_volt[1]);
    data[6] = HIGH_BYTE(bmu_data_unify->bmu_cell_info.max_cell_volt[2]);
    data[7] = LOW_BYTE(bmu_data_unify->bmu_cell_info.max_cell_volt[2]);
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    
    // 包序号0x2
    data[0] = 0x02;
    data[1] = 0xFF; // 保留
    // 电芯电压最小值前三
    data[2] = HIGH_BYTE(bmu_data_unify->bmu_cell_info.min_cell_volt[0]);
    data[3] = LOW_BYTE(bmu_data_unify->bmu_cell_info.min_cell_volt[0]);
    data[4] = HIGH_BYTE(bmu_data_unify->bmu_cell_info.min_cell_volt[1]);
    data[5] = LOW_BYTE(bmu_data_unify->bmu_cell_info.min_cell_volt[1]);
    data[6] = HIGH_BYTE(bmu_data_unify->bmu_cell_info.min_cell_volt[2]);
    data[7] = LOW_BYTE(bmu_data_unify->bmu_cell_info.min_cell_volt[2]);
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    
    // 包序号0x3
    data[0] = 0x03;
    data[1] = 0xFF; // 保留
    // 电芯电压的平均值、最大差值；电芯温度最大值
    data[2] = HIGH_BYTE(bmu_data_unify->bmu_cell_info.avg_cell_volt);
    data[3] = LOW_BYTE(bmu_data_unify->bmu_cell_info.avg_cell_volt);
    data[4] = HIGH_BYTE(bmu_data_unify->bmu_cell_info.max_cell_volt_diff);
    data[5] = LOW_BYTE(bmu_data_unify->bmu_cell_info.max_cell_volt_diff);
    data[6] = (int16_t)bmu_data_unify->bmu_cell_info.max_cell_temp[0] + 40;
    data[7] = (int16_t)bmu_data_unify->bmu_cell_info.max_cell_temp[1] + 40;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    
    // 包序号0x4
    data[0] = 0x04;
    // 电芯温度的平均值、最大差值；电芯SOC最大值
    data[1] = (int16_t)bmu_data_unify->bmu_cell_info.max_cell_temp[2] + 40;
    data[2] = (int16_t)bmu_data_unify->bmu_cell_info.min_cell_temp[0] + 40;
    data[3] = (int16_t)bmu_data_unify->bmu_cell_info.min_cell_temp[1] + 40;
    data[4] = (int16_t)bmu_data_unify->bmu_cell_info.min_cell_temp[2] + 40;
    data[5] = (int16_t)bmu_data_unify->bmu_cell_info.avg_cell_temp + 40;
    data[6] = bmu_data_unify->bmu_cell_info.max_cell_temp_diff;
    data[7] = bmu_data_unify->bmu_cell_info.max_cell_soc[0];
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    
    // 包序号0x5
    data[0] = 0x05;
    // SOC的平均值、最大差值
    data[1] = bmu_data_unify->bmu_cell_info.max_cell_soc[1];
    data[2] = bmu_data_unify->bmu_cell_info.max_cell_soc[2];
    data[3] = bmu_data_unify->bmu_cell_info.min_cell_soc[0];
    data[4] = bmu_data_unify->bmu_cell_info.min_cell_soc[1];
    data[5] = bmu_data_unify->bmu_cell_info.min_cell_soc[2];
    data[6] = bmu_data_unify->bmu_cell_info.avg_cell_soc;
    data[7] = bmu_data_unify->bmu_cell_info.max_cell_soc_diff;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    
    // 包序号0x6
    data[0] = 0x06;
    // SOh的平均值、最大差值
    data[1] = bmu_data_unify->bmu_cell_info.max_cell_soh[0];
    data[2] = bmu_data_unify->bmu_cell_info.max_cell_soh[1];
    data[3] = bmu_data_unify->bmu_cell_info.max_cell_soh[2];
    data[4] = bmu_data_unify->bmu_cell_info.min_cell_soh[0];
    data[5] = bmu_data_unify->bmu_cell_info.min_cell_soh[1];
    data[6] = bmu_data_unify->bmu_cell_info.min_cell_soh[2];
    data[7] = bmu_data_unify->bmu_cell_info.avg_cell_soh;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    
    // 包序号0x7
    data[0] = 0x07;
    // SOh最大差值
    data[1] = bmu_data_unify->bmu_cell_info.max_cell_soh_diff;
    data[2] = 0xFF;
    data[3] = 0xFF;
    data[4] = 0xFF;
    data[5] = 0xFF;
    data[6] = 0xFF;
    data[7] = 0xFF;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    
    // 包序号0x28
    data[0] = 0x28;
    data[1] = 0xFF;
    data[2] = HIGH_BYTE(bmu_data_unify->bmu_cell_info.max_cell_volt_id);
    data[3] = LOW_BYTE(bmu_data_unify->bmu_cell_info.max_cell_volt_id);
    data[4] = HIGH_BYTE(bmu_data_unify->bmu_cell_info.min_cell_volt_id);
    data[5] = LOW_BYTE(bmu_data_unify->bmu_cell_info.min_cell_volt_id);
    data[6] = HIGH_BYTE(bmu_data_unify->bmu_cell_info.max_cell_temp_id);
    data[7] = LOW_BYTE(bmu_data_unify->bmu_cell_info.max_cell_temp_id);
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    
    // 包序号0x29
    data[0] = 0x29;
    data[1] = 0xFF;
    data[2] = HIGH_BYTE(bmu_data_unify->bmu_cell_info.min_cell_temp_id);
    data[3] = LOW_BYTE(bmu_data_unify->bmu_cell_info.min_cell_temp_id);
    data[4] = HIGH_BYTE(bmu_data_unify->bmu_cell_info.max_cell_soc_id);
    data[5] = LOW_BYTE(bmu_data_unify->bmu_cell_info.max_cell_soc_id);
    data[6] = HIGH_BYTE(bmu_data_unify->bmu_cell_info.min_cell_soc_id);
    data[7] = LOW_BYTE(bmu_data_unify->bmu_cell_info.min_cell_soc_id);
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    
    // 包序号0x2A
    data[0] = 0x2A;
    data[1] = 0xFF;
    data[2] = HIGH_BYTE(bmu_data_unify->bmu_cell_info.max_cell_soh_id);
    data[3] = LOW_BYTE(bmu_data_unify->bmu_cell_info.max_cell_soh_id);
    data[4] = HIGH_BYTE(bmu_data_unify->bmu_cell_info.min_cell_soh_id);
    data[5] = LOW_BYTE(bmu_data_unify->bmu_cell_info.min_cell_soh_id);
    data[6] = 0xFF;
    data[7] = 0xFF;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// EVBCM 应答 PC 请求模块电池节数信息消息（命令码 0x37）
static bool ex_tx_gold_pack_num_data_ack(can_frame_data_t *can_data, uint16_t func_code)
{
    // 接收到0x30的包序号
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_PACK_NUM_DATA_ACK_CMD);
    uint16_t tmp = 0;
    const bms_attr_t *p_bmu_attr = get_bms_attr();
    uint8_t pack_num = p_bmu_attr->clu_pack_num; //auto_addressing_pack_num_get()
    // 包序号0x00
    data[0] = 0x00;
    data[1] = pack_num;
    tmp = pack_num * get_bms_attr()->pack_cell_num;
    data[2] = HIGH_BYTE(tmp);
    data[3] = LOW_BYTE(tmp);
    data[4] = 0;
    data[5] = 0;
    data[6] = 0;
    data[7] = 0;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
  
#define ONER_0x37FRAME_FILL_DATA_NUM 7
    uint8_t send_frame_num = (pack_num + ONER_0x37FRAME_FILL_DATA_NUM - 1) / ONER_0x37FRAME_FILL_DATA_NUM;
    uint8_t  send_frame_mod = pack_num % ONER_0x37FRAME_FILL_DATA_NUM;
    for (uint8_t i = 0; i < send_frame_num; i++)
    {
        memset(&data[1], 0xFF, CAN_SIGNAL_FRA_MAX_NUMS - 1);
        data[0] = i + 1;
        if (i == send_frame_num - 1 && send_frame_mod != 0)
        {
            for (uint8_t j = 0; j < send_frame_mod; j++)
            {
                data[1 + j] = get_bms_attr()->pack_cell_num;
            }
        }
        else
        {
            for (uint8_t j = 0; j < ONER_0x37FRAME_FILL_DATA_NUM; j++)
            {
                data[1 + j] = get_bms_attr()->pack_cell_num;
            }
        }
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    }
    return 0;
}


// EVBCM 应答 PC 请求报警信息应答消息（命令码 0x38）
static bool ex_tx_gold_warn_data_ack(can_frame_data_t *can_data, uint16_t func_code)
{
    // 接收到0x30的包序号
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u tx_can_frame = {0};
    
    tx_can_frame.bit.src_addr = ext_addressing_manage_addr_get();
    tx_can_frame.bit.src_type = DEV_BROADCAST;
    tx_can_frame.bit.dst_addr = GOLD_PC_EX_CAN_NO_TYPE_ADDR;
    tx_can_frame.bit.dst_type = DEV_BROADCAST;
    tx_can_frame.bit.fun_code = GOLD_FUNC_ALARM_DATA_ACK_CMD;
    tx_can_frame.bit.prio = SOFAR_CAN_PRI_LOW_L;

    const gold_warn_msg_t *warn_msg_reply = warn_msg_reply_get();
    gold_dev_warn_t dev_warn = warn_msg_reply->dev_warn;
    const gold_base_warn_t *base_warn = warn_msg_reply->base_warn;


    if ((0 == base_warn[0].warn_byte0.byte)
        &&(0 == base_warn[0].warn_byte1.byte)
        &&(0 == base_warn[0].warn_byte2.byte)
        &&(0 == base_warn[1].warn_byte0.byte)
        &&(0 == base_warn[1].warn_byte1.byte)
        &&(0 == base_warn[1].warn_byte2.byte)
        &&(0 == base_warn[2].warn_byte0.byte)
        &&(0 == base_warn[2].warn_byte1.byte)
        &&(0 == base_warn[2].warn_byte2.byte)   
        )
    {
        // 无报警 0x00
        data[0] = 0x00;
        data[1] = 0x00;
        data[2] = 0x00;
        data[3] = 0x00;
        data[4] = 0xFF;
        data[5] = 0xFF;
        data[6] = 0xFF;
        data[7] = 0xFF;
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);        
    }
    else
    {
        // 严重故障 0x01， TODO 动作参数补充
        data[0] = 0x01;
        data[1] = base_warn[0].warn_byte0.byte;
        data[2] = base_warn[0].warn_byte1.byte;
        data[3] = base_warn[0].warn_byte2.byte;
        data[4] = 0xFF;
        data[5] = 0xFF;
        data[6] = 0xFF;
        data[7] = 0xFF;
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
        
        // 一般故障 0x02， TODO 动作参数补充
        data[0] = 0x02;
        data[1] = base_warn[1].warn_byte0.byte;
        data[2] = base_warn[1].warn_byte1.byte;
        data[3] = base_warn[1].warn_byte2.byte;
        data[4] = 0xFF;
        data[5] = 0xFF;
        data[6] = 0xFF;
        data[7] = 0xFF;
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
        
        // 轻微故障 0x03， TODO 动作参数补充
        data[0] = 0x03;
        data[1] = base_warn[2].warn_byte0.byte;
        data[2] = base_warn[2].warn_byte1.byte;
        data[3] = base_warn[2].warn_byte2.byte;
        data[4] = 0xFF;
        data[5] = 0xFF;
        data[6] = 0xFF;
        data[7] = 0xFF;
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    }
    
    // 设备故障 0x04， TODO 动作参数补充
    data[0] = 0x04;
    data[1] = dev_warn.warn_byte0.byte;
    data[2] = dev_warn.warn_byte1.byte;
    data[3] = dev_warn.warn_byte2.byte;
    data[4] = dev_warn.warn_byte3.byte;
    data[5] = 0xFF;
    data[6] = 0xFF;
    data[7] = 0xFF;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

uint8_t sys_stus_get(void)
{

    bcu_req_ctl_state_t state = {0};
    const bcu_data_unify_t* p_bcu_info = get_bcu_info();

    if(p_bcu_info->clu_mode == CLU_SINGLE)
    {
        state.sys_stus.bit.parallel_mode = 0;
        state.sys_stus.bit.single_mode = 1;     //保持单簇模式        
    }
    else
    {
        state.sys_stus.bit.parallel_mode = 1;
        state.sys_stus.bit.single_mode = 0;     //保持多簇模式                
    }
    
    state.sys_stus.bit.chg_forbid = !p_bcu_info->chg_enable;
    state.sys_stus.bit.dsg_forbid = !p_bcu_info->dsg_enable;
    state.sys_stus.bit.fault = p_bcu_info->fault_state;
    
    return state.sys_stus.byte;
}

// EVBCM 应答 PC 请求 DI/DO 信息应答消息（命令码 0x39）
static bool ex_tx_gold_dido_data_ack(can_frame_data_t *can_data, uint16_t func_code)
{
    // 接收到0x30的包序号
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u tx_can_frame = {0};
    
    tx_can_frame.bit.src_addr = ext_addressing_manage_addr_get();
    tx_can_frame.bit.src_type = DEV_BROADCAST;
    tx_can_frame.bit.dst_addr = GOLD_PC_EX_CAN_NO_TYPE_ADDR;
    tx_can_frame.bit.dst_type = DEV_BROADCAST;
    tx_can_frame.bit.fun_code = GOLD_FUNC_DIDO_DATA_ACK_CMD;
    tx_can_frame.bit.prio = SOFAR_CAN_PRI_LOW_L;
    
    
    // 序号0x00 bcu di状态
    data[0] = 0x00;
    data[1] = bcu_dido_info_get()->di_state.byte;
    data[2] = 0x00;
    data[3] = 0xFF;
    data[4] = 0xFF;
    data[5] = 0xFF;
    data[6] = 0xFF;
    data[7] = 0xFF;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    
    // 序号0x01 bcu do状态
    data[0] = 0x01;
    data[1] = bcu_dido_info_get()->do_state.byte;
    data[2] = sys_stus_get();  // 禁止充电放电标志
    data[3] = 0xFF;
    data[4] = 0xFF;
    data[5] = 0xFF;
    data[6] = 0xFF;
    data[7] = 0xFF;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// EVBCM 应答 PC 请求模块温度个数信息消息（命令码 0x3A）
static bool ex_tx_gold_temp_num_data_ack(can_frame_data_t *can_data, uint16_t func_code)
{
    // 接收到0x30的包序号
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_TEMP_NUM_DATA_ACK_CMD);
    const bms_attr_t *p_bmu_attr = get_bms_attr();
    uint16_t tmp = 0;
    uint8_t pack_num = p_bmu_attr->clu_pack_num;//auto_addressing_pack_num_get();
    // 包序号0x00
    data[0] = 0x00;
    data[1] = pack_num;
    tmp = pack_num * get_bms_attr()->pack_temp_num;
    data[2] = HIGH_BYTE(tmp);
    data[3] = LOW_BYTE(tmp);
    data[4] = 0;
    data[5] = 0;
    data[6] = 0;
    data[7] = 0;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
  
#define ONER_0x37FRAME_FILL_DATA_NUM 7
    uint8_t send_frame_num = (pack_num + ONER_0x37FRAME_FILL_DATA_NUM - 1) / ONER_0x37FRAME_FILL_DATA_NUM;
    uint8_t  send_frame_mod = pack_num % ONER_0x37FRAME_FILL_DATA_NUM;
    for (uint8_t i = 0; i < send_frame_num; i++)
    {
        memset(&data[1], 0xFF, CAN_SIGNAL_FRA_MAX_NUMS - 1);
        data[0] = i + 1;
        if (i == send_frame_num - 1 && send_frame_mod != 0)
        {
            for (uint8_t j = 0; j < send_frame_mod; j++)
            {
                data[1 + j] = get_bms_attr()->pack_temp_num;
            }
        }
        else
        {
            for (uint8_t j = 0; j < ONER_0x37FRAME_FILL_DATA_NUM; j++)
            {
                data[1 + j] = get_bms_attr()->pack_temp_num;
            }
        }
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    }
    return 0;
}

// EVBCM 应答 PC 请求模块均衡状态信息消息（命令码 0x3B）
static bool ex_tx_gold_pack_bal_data_ack(can_frame_data_t *can_data, uint16_t func_code)
{
#define ONE_FRAME_SEND_PASS_BAL_STATE_NUM 6
    // 接收到0x30的包序号
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_PACK_BAL_DATA_ACK_CMD);
    const bms_attr_t *p_bmu_attr = get_bms_attr();
    const pack_cell_info_t* p_bmu_cell_info = get_bmu_cell_info();
    uint8_t pack_num = p_bmu_attr->clu_pack_num;//auto_addressing_pack_num_get()
    uint8_t one_mode_send_frame = (PACK_PASS_BAL_NUM + ONE_FRAME_SEND_PASS_BAL_STATE_NUM - 1) / ONE_FRAME_SEND_PASS_BAL_STATE_NUM;
    uint8_t one_mode_send_frame_mod = PACK_PASS_BAL_NUM % ONE_FRAME_SEND_PASS_BAL_STATE_NUM;
    uint16_t num = 0;
    uint8_t send_k = 0;
     // 默认被动均衡状态
    for (uint8_t i = 0; i < pack_num; i++)
    {
        data[0] = (i + 1) << 2;
        for (uint16_t j = 0; j < one_mode_send_frame; j++)
        {
            data[1] = j + 1;
            memset(&data[2], 0, CAN_SIGNAL_FRA_MAX_NUMS - 2);
            num = j * ONE_FRAME_SEND_PASS_BAL_STATE_NUM;
            if (j == one_mode_send_frame - 1 && one_mode_send_frame_mod != 0)
            {
                send_k = one_mode_send_frame_mod;
            }
            else
            {
                send_k = ONE_FRAME_SEND_PASS_BAL_STATE_NUM;
            }
            for (uint8_t k = 0; k < send_k; k++)
            {
                data[2 + k] = p_bmu_cell_info->pass_bal_state[i][num + k];
            }
            can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
        }
    }
    return 0;
}

// EVBCM 应答 PC 请求从控模块失联状态信息消息（命令码 0x3C）
static bool ex_tx_gold_sla_unlink_ack(can_frame_data_t *can_data, uint16_t func_code)
{
    // 接收到0x30的包序号
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_SLA_UNLINK_ACK_CMD);
    
    // TODO 调试过程，发送0xFF
    uint16_t tmp = singal_bmu_bcu_com_fault_flag_get();
    data[0] = LOW_BYTE(tmp);
    data[1] = HIGH_BYTE(tmp);

    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// EVBCM 应答 PC 请求掉线状态信息消息（命令码 0x3D）
static bool ex_tx_gold_wire_open_ack(can_frame_data_t *can_data, uint16_t func_code)
{
    // 接收到0x30的包序号
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_WIRE_OPEN_ACK_CMD);
    // TODO 是否要填充 cmu没有使用
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// EVBCM 应答 PC 请求新增报警信息应答消息（命令码 0x3E）
static bool ex_tx_gold_fault_data_ack(can_frame_data_t *can_data, uint16_t func_code)
{
    // 接收到0x30的包序号
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u tx_can_frame = {0};
    
    tx_can_frame.bit.src_addr = ext_addressing_manage_addr_get();
    tx_can_frame.bit.src_type = DEV_BROADCAST;
    tx_can_frame.bit.dst_addr = GOLD_PC_EX_CAN_NO_TYPE_ADDR;
    tx_can_frame.bit.dst_type = DEV_BROADCAST;
    tx_can_frame.bit.fun_code = GOLD_FUNC_FAULT_DATA_ACK_CMD;
    tx_can_frame.bit.prio = SOFAR_CAN_PRI_LOW_L;

    const gold_warn_msg_t *warn_msg_reply = warn_msg_reply_get();
    gold_add_warn_t add_warn = warn_msg_reply->add_warn;
    const uint8_t *alarm_no = warn_msg_reply->alarm_no;     
    
    uint8_t dev_level_cnt = 0;
    uint8_t protect_level_cnt = 0;
    uint8_t alarm_level_cnt = 0;
    uint8_t tip_level_cnt = 0;
    uint8_t dev_num[DEV_NUM] = {0}; 
    uint8_t protect_num[DEV_NUM] = {0}; 
    uint8_t alarm_num[DEV_NUM] = {0};
    uint8_t tip_num[DEV_NUM] = {0};    //发送具体故障设备地址
    
    static uint8_t last_dev_level_cnt = 0;
    static uint8_t last_protect_level_cnt = 0;
    static uint8_t last_alarm_level_cnt = 0;
    static uint8_t last_tip_level_cnt = 0;
    
    static uint8_t dev_level_send = 0;
    static uint8_t protect_level_send = 0;
    static uint8_t alarm_level_send = 0;
    static uint8_t tip_level_send = 0; //轮到发送具体哪个
    // 设备故障 0x04， 
    data[0] = 0x04;
    data[1] = add_warn.dev_byte0.byte;
    data[2] = 0;
    data[3] = 0;
    data[4] = 0;    
    data[5] = 0;
    data[6] = 0; 
    for(uint8_t i = 0; i < DEV_NUM; i++)
    {
        if(alarm_no[i] & DEVICE_ERR_LEVEL)
        {
            if(i == 0)
            {
                dev_num[dev_level_cnt] = 0x0f;  //BCU的设备地址定义成0xf           
            }
            else
            {
                dev_num[dev_level_cnt] = i;  //BMU的设备地址1-8
            }
            dev_level_cnt++;    //有多少个设备有故障    
        }
        

    }
    if (last_dev_level_cnt != dev_level_cnt)
    {
        last_dev_level_cnt = dev_level_cnt;
        dev_level_send = 0; //有变化则重头开始发送
    }
    data[7] = dev_num[dev_level_send];      //轮询发送
    if(++dev_level_send >= last_dev_level_cnt)
    {
        dev_level_send = 0;
    }


    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    
    data[0] = 0x01;
    data[1] = add_warn.protect_byte0.byte;
    data[2] = 0;
    data[3] = 0;
    data[4] = 0;    
    data[5] = 0;
    data[6] = 0;
    for(uint8_t i = 0; i < DEV_NUM; i++)
    {
        if(alarm_no[i] & PROTECT_LEVEL)
        {
            if(i == 0)
            {
                protect_num[protect_level_cnt] = 0x0f;  //BCU的设备地址定义成0xf           
            }
            else
            {
                protect_num[protect_level_cnt] = i;  //BMU的设备地址1-8
            }
            protect_level_cnt++;    //有多少个设备有故障    
        }
        

    }
    if (last_protect_level_cnt != protect_level_cnt)
    {
        last_protect_level_cnt = protect_level_cnt;
        protect_level_send = 0; //有变化则重头开始发送
    }
    data[7] = protect_num[protect_level_send];      //轮询发送
    if(++protect_level_send >= last_protect_level_cnt)
    {
        protect_level_send = 0;
    }
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);    
    
    data[0] = 0x02;
    data[1] = add_warn.alarm_byte0.byte;
    data[2] = 0;
    data[3] = 0;
    data[4] = 0;    
    data[5] = 0;
    data[6] = 0;
    for(uint8_t i = 0; i < DEV_NUM; i++)
    {
        if(alarm_no[i] & ALARM_LEVEL)
        {
            if(i == 0)
            {
               alarm_num[alarm_level_cnt] = 0x0f;  //BCU的设备地址定义成0xf           
            }
            else
            {
                alarm_num[alarm_level_cnt] = i;  //BMU的设备地址1-8
            }
            alarm_level_cnt++;    //有多少个设备有故障    
        }
        

    }
    if (last_alarm_level_cnt != alarm_level_cnt)
    {
        last_alarm_level_cnt = alarm_level_cnt;
        alarm_level_send = 0; //有变化则重头开始发送
    }
    data[7] = alarm_num[alarm_level_send];      //轮询发送
    if(++alarm_level_send >= last_alarm_level_cnt)
    {
        alarm_level_send = 0;
    }
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);        
    
    data[0] = 0x03;
    data[1] = add_warn.tip_byte0.byte;
    data[2] = 0;
    data[3] = 0;
    data[4] = 0;    
    data[5] = 0;
    data[6] = 0;
    for(uint8_t i = 0; i < DEV_NUM; i++)
    {
        if(alarm_no[i] & TIP_LEVEL)
        {
            if(i == 0)
            {
               tip_num[tip_level_cnt] = 0x0f;  //BCU的设备地址定义成0xf           
            }
            else
            {
                tip_num[tip_level_cnt] = i;  //BMU的设备地址1-8
            }
            tip_level_cnt++;    //有多少个设备有故障    
        }
        

    }
    if (last_tip_level_cnt != tip_level_cnt)
    {
        last_tip_level_cnt = tip_level_cnt;
        tip_level_send = 0; //有变化则重头开始发送
    }
    data[7] = tip_num[tip_level_send];      //轮询发送
    if(++tip_level_send >= last_tip_level_cnt)
    {
        tip_level_send = 0;
    }
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);      

    uint16_t data_temp = 0;
    data[0] = 0x05;
    memset(&data[1], 0, (CAN_SIGNAL_FRA_MAX_NUMS - 1));   
    data_temp = get_bmu_info(0)->yc2[YC2_ELECTROLYTE_STREN];  
    data[1] = HIGH_BYTE(data_temp);
    data[2] = LOW_BYTE(data_temp);
    data_temp = get_bmu_info(1)->yc2[YC2_ELECTROLYTE_STREN];  
    data[3] = HIGH_BYTE(data_temp);
    data[4] = LOW_BYTE(data_temp); 
    data_temp = get_bmu_info(2)->yc2[YC2_ELECTROLYTE_STREN];      
    data[5] = HIGH_BYTE(data_temp);
    data[6] = LOW_BYTE(data_temp);  
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);  
    
    data[0] = 0x06;
    memset(&data[1], 0, (CAN_SIGNAL_FRA_MAX_NUMS - 1));
    data_temp = get_bmu_info(3)->yc2[YC2_ELECTROLYTE_STREN];  
    data[1] = HIGH_BYTE(data_temp);
    data[2] = LOW_BYTE(data_temp); 
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);      
    return 0;
}

// 返回版本号消息（命令码 0x41）
#define SOFT_VER_MAS_TYPE 1
#define SOFT_VER_SLA_TYPE 2
static bool ex_tx_gold_ver_data_ack(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, GOLD_FUNC_VER_DATA_ACK_CMD);
    if (can_data->data[0] == SOFT_VER_SLA_TYPE)
    {
        uint8_t slave_id = can_data->data[1];
        pack_info_t* p_bmu_info = get_bmu_info(slave_id - 1);
        if (p_bmu_info == NULL)
        {
            return 0;
        }
        data[0] = 0x03;
        data[1] = slave_id;
        data[2] = p_bmu_info->dev[BMU_DEV_SW_VT_VER];
        data[3] = p_bmu_info->dev[BMU_DEV_SW_BIG_VER];      // 软件大版本号
        data[4] = p_bmu_info->dev[BMU_DEV_SW_MIDDLE_VER];   // 软件非标版本号
        data[5] = p_bmu_info->dev[BMU_DEV_SW_SAMLL_VER];    // 软件小版本号
        
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
        
        memset(data, 0, CAN_SIGNAL_FRA_MAX_NUMS);
        data[0] = 0x04;
        data[1] = slave_id;
        data[2] = 'H'; //  
        data[3] = 'V'; //  
        data[4] = p_bmu_info->dev[BMU_DEV_HW_VER];          //  硬件版本号      
        data[6] = p_bmu_info->dev[BMU_DEV_CAN_VER_H];
        data[7] = p_bmu_info->dev[BMU_DEV_CAN_VER_L];
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
        
        // memset(data, 0, CAN_SIGNAL_FRA_MAX_NUMS);
        // data[0] = 0x05;
        // data[1] = 24;
        // can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    }
    else
    {
        data[0] = 0x01;
        data[1] = 0x00;
        data[2] = SOFTWARE_VERSION[0];
        data[3] = ((uint8_t)(SOFTWARE_VERSION[1]-AsciiToInt)*10) + (SOFTWARE_VERSION[2]-AsciiToInt);    // 软件大版本号
        data[4] = ((uint8_t)(SOFTWARE_VERSION[3]-AsciiToInt)*10) + (SOFTWARE_VERSION[4]-AsciiToInt);    // 软件非标版本号
        data[5] = ((uint8_t)(SOFTWARE_VERSION[5]-AsciiToInt)*10) + (SOFTWARE_VERSION[6]-AsciiToInt);    // 软件小版本号
        
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
        
        memset(data, 0, CAN_SIGNAL_FRA_MAX_NUMS);
        data[0] = 0x02;
        data[2] = 'H'; //  
        data[3] = 'V'; //  
        data[4] = hardware_ver_get(); //  硬件版本号
        data[6] = HIGH_BYTE(CAN_VERSION);
        data[7] = LOW_BYTE(CAN_VERSION);
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
        
        // memset(data, 0, CAN_SIGNAL_FRA_MAX_NUMS);
        // data[0] = 0x05;
        // data[1] = 24;
        // can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    }
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 控制主控绝缘检测功能指令 EVBCM → PC/显控 ID: 0x0881F4XX (XX:0xE8~0xFB)
static bool ex_tx_gold_cmu_ins_ctl(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u tx_can_frame = {0};
    
    memset(data, 0xFF, CAN_SIGNAL_FRA_MAX_NUMS);
    tx_can_frame.bit.src_addr = ext_addressing_manage_addr_get();
    tx_can_frame.bit.src_type = DEV_BROADCAST;
    tx_can_frame.bit.dst_addr = GOLD_PC_EX_CAN_NO_TYPE_ADDR;
    tx_can_frame.bit.dst_type = DEV_BROADCAST;
    tx_can_frame.bit.fun_code = GOLD_FUNC_CMU_INS_CTL_CMD;
    tx_can_frame.bit.prio = SOFAR_CAN_PRI_HIGH_L;
    data[0] = insulation_impedance_func_enable_get();
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 8133 组端概要信息 ID：1890FF00+addr
static bool ex_tx_gold_clu_summary(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u tx_can_frame = {0};

    tx_can_frame.bit.src_addr = ext_addressing_manage_addr_get();
    tx_can_frame.bit.src_type = DEV_BROADCAST;
    tx_can_frame.bit.dst_addr = BROCAST_DEVICE_ADDRESS;
    tx_can_frame.bit.dst_type = DEV_BROADCAST;
    tx_can_frame.bit.fun_code = GOLD_FUNC_CLU_SUMMARY_CMD;
    tx_can_frame.bit.prio = SOFAR_CAN_PRI_LOW_L;
    
    const other_clu_data *other_clu_data = get_cluster_bcu_data(tx_can_frame.bit.src_addr - GOLD_MIN_EX_CAN_NO_TYPE_ADDR);

    uint16_t tmp = 0;
    tmp = other_clu_data->clu_volt; // 0.1V/bit
    data[0] = LOW_BYTE(tmp);
    data[1] = HIGH_BYTE(tmp);
    tmp = other_clu_data->clu_curr + 16000; // 0.1A,偏移-1600A
    data[2] = LOW_BYTE(tmp);
    data[3] = HIGH_BYTE(tmp);
    data[4] = other_clu_data->clu_soc;
    data[5] = other_clu_data->clu_soh;
    uint8_t di1 = GET_BIT(other_clu_data->clu_di_stus, 0x01);
    uint8_t di3 = GET_BIT(other_clu_data->clu_di_stus, 0x04);
    uint8_t di5 = GET_BIT(other_clu_data->clu_di_stus, 0x10);
    uint8_t di7 = GET_BIT(other_clu_data->clu_di_stus, 0x40);
    uint8_t di8 = GET_BIT(other_clu_data->clu_di_stus, 0x80);
    uint8_t iso_flag = 0;
    if(INSULATION_IMPEDANCE_NORMAL == insulation_impedance_check_result_get())
    {
        iso_flag = true;
    }
    data[6] = di1 | (di3 << 1) | (di5 << 2) | (di7 << 3) | (di8 << 4) | (iso_flag << 7); // di状态，待填充TODO
    data[7] = other_clu_data->clu_do_stus; // 

    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 8133 单体概要信息 ID:1891FF00+addr
static bool ex_tx_gold_clu_cell_summary(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u tx_can_frame = {0};

    tx_can_frame.bit.src_addr = ext_addressing_manage_addr_get();
    tx_can_frame.bit.src_type = DEV_BROADCAST;
    tx_can_frame.bit.dst_addr = BROCAST_DEVICE_ADDRESS;
    tx_can_frame.bit.dst_type = DEV_BROADCAST;
    tx_can_frame.bit.fun_code = GOLD_FUNC_CLU_CELL_SUMMARY_CMD;
    tx_can_frame.bit.prio = SOFAR_CAN_PRI_LOW_L;

    const other_clu_data *other_clu_data = get_cluster_bcu_data(tx_can_frame.bit.src_addr - GOLD_MIN_EX_CAN_NO_TYPE_ADDR);
    
    data[0] = LOW_BYTE(other_clu_data->clu_max_cell_volt);
    data[1] = HIGH_BYTE(other_clu_data->clu_max_cell_volt);
    data[2] = LOW_BYTE(other_clu_data->clu_max_cell_temp  + 40);
    data[3] = LOW_BYTE(other_clu_data->clu_max_cell_soc);
    
    data[4] = LOW_BYTE(other_clu_data->clu_min_cell_volt);
    data[5] = HIGH_BYTE(other_clu_data->clu_min_cell_volt);
    data[6] = LOW_BYTE(other_clu_data->clu_min_cell_temp  + 40);
    data[7] = LOW_BYTE(other_clu_data->clu_min_cell_soc);
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 8133 告警信息 ID:1892FF00+addr
static bool ex_tx_gold_clu_alm_summary(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u tx_can_frame = {0};

    tx_can_frame.bit.src_addr = ext_addressing_manage_addr_get();
    tx_can_frame.bit.src_type = DEV_BROADCAST;
    tx_can_frame.bit.dst_addr = BROCAST_DEVICE_ADDRESS;
    tx_can_frame.bit.dst_type = DEV_BROADCAST;
    tx_can_frame.bit.fun_code = GOLD_FUNC_CLU_ALM_SUMMARY_CMD;
    tx_can_frame.bit.prio = SOFAR_CAN_PRI_LOW_L;
    
    const other_clu_data *other_clu_data = get_cluster_bcu_data(tx_can_frame.bit.src_addr - GOLD_MIN_EX_CAN_NO_TYPE_ADDR);

    data[0] = 0x01;
    data[1] = other_clu_data->pro_warn[0];  
    data[2] = other_clu_data->pro_warn[1];
    data[3] = other_clu_data->pro_warn[2];
    data[4] = 0;
    data[5] = 0;
    data[6] = 0;
    data[7] = 0;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    
    data[0] = 0x02;
    data[1] = other_clu_data->alm_warn[0];  
    data[2] = other_clu_data->alm_warn[1];
    data[3] = other_clu_data->alm_warn[2];
    data[4] = 0;
    data[5] = 0;
    data[6] = 0;
    data[7] = 0;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    
    data[0] = 0x03;
    data[1] = other_clu_data->tip_warn[0];  
    data[2] = other_clu_data->tip_warn[1];
    data[3] = other_clu_data->tip_warn[2];
    data[4] = 0;
    data[5] = 0;
    data[6] = 0;
    data[7] = 0;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    
    data[0] = 0x04;
    data[1] = other_clu_data->dev_fault[0];  
    data[2] = other_clu_data->dev_fault[1];
    data[3] = other_clu_data->dev_fault[2];
    data[4] = 0;
    data[5] = 0;
    data[6] = 0;
    data[7] = 0;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 主 8133 控制命令 0x0C93F400+Addr
static bool ex_tx_gold_mas_clu_ctl(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u tx_can_frame = {0};
    const bmu_data_unify_t* p_bmu_data_unify = bmu_data_unify_get();

    tx_can_frame.bit.src_addr = ext_addressing_manage_addr_get();
    tx_can_frame.bit.src_type = DEV_BROADCAST;
    tx_can_frame.bit.dst_addr = GOLD_PC_EX_CAN_NO_TYPE_ADDR;
    tx_can_frame.bit.dst_type = DEV_BROADCAST;
    tx_can_frame.bit.fun_code = GOLD_FUNC_MAS_CLU_CTL_CMD;
    tx_can_frame.bit.prio = SOFAR_CAN_PRI_HIGH_L;
    //TODO
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 禁充禁放告警原因信息 0x0C94F400+Addr 2000ms周期发送
static bool ex_tx_gold_alm_reason(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u tx_can_frame = {0};
    const bcu_data_unify_t* p_bcu_info = get_bcu_info();
    
    memset(data, 0xFF, CAN_SIGNAL_FRA_MAX_NUMS);

    tx_can_frame.bit.src_addr = ext_addressing_manage_addr_get();
    tx_can_frame.bit.src_type = DEV_BROADCAST;
    tx_can_frame.bit.dst_addr = GOLD_PC_EX_CAN_NO_TYPE_ADDR;
    tx_can_frame.bit.dst_type = DEV_BROADCAST;
    tx_can_frame.bit.fun_code = GOLD_FUNC_ALM_REASON_CMD;
    tx_can_frame.bit.prio = SOFAR_CAN_PRI_HIGH_L;
    //充放电使能
    if(p_bcu_info == NULL)
    {
        data[0] = 0x07;
    }
    else
    {
        if (!p_bcu_info->chg_enable)
        {
            data[0] = 0x1;
        }
        if (!p_bcu_info->dsg_enable)
        {
            data[0] |= 0x2;
        }
        
        if (p_bcu_info->fault_state)
        {
            data[0] |= 0x4;
        }
    }

    
    data[1] = 0;  // TODO, 故障码，是否按照高特实现
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 8133 维护信息 ID:1895FF00+addr
static bool ex_tx_gold_maintenance(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};

    can_frame_id_u tx_can_frame = {0};

    tx_can_frame.bit.src_addr = ext_addressing_manage_addr_get();
    tx_can_frame.bit.src_type = DEV_BROADCAST;
    tx_can_frame.bit.dst_addr = BROCAST_DEVICE_ADDRESS;
    tx_can_frame.bit.dst_type = DEV_BROADCAST;
    tx_can_frame.bit.fun_code = GOLD_FUNC_MAINTENANCE_CMD;
    tx_can_frame.bit.prio = SOFAR_CAN_PRI_LOW_L;

    const other_clu_data *other_clu_data = get_cluster_bcu_data(tx_can_frame.bit.src_addr - GOLD_MIN_EX_CAN_NO_TYPE_ADDR);
    
    data[0] = other_clu_data->clu_maintenance_stus;  // 簇维护状态（ 0 ：不维护   1 ：正在维护   2：维护结束）
    data[1] = other_clu_data->clu_out_stus;  // 退簇状态（0：正常 1：退簇完成）
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 退簇信息 0x0c95F400+Addr
static bool ex_tx_gold_out_clu_ctl(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u tx_can_frame = {0};
    const bcu_data_unify_t* p_bcu_info = get_bcu_info();
    
    tx_can_frame.bit.src_addr = ext_addressing_manage_addr_get();
    tx_can_frame.bit.src_type = DEV_BROADCAST;
    tx_can_frame.bit.dst_addr = GOLD_PC_EX_CAN_NO_TYPE_ADDR;
    tx_can_frame.bit.dst_type = DEV_BROADCAST;
    tx_can_frame.bit.fun_code = GOLD_FUNC_OUT_CLU_CTL_CMD;
    tx_can_frame.bit.prio = SOFAR_CAN_PRI_HIGH_L;

    data[0] = p_bcu_info->out_clu_process;  // 0:无操作  1:允许退簇  2:禁止退簇  3:允许并簇  4:禁止并簇  5:故障下电
    data[1] = can_data->data[1];
    data[2] = can_data->data[2]; 
    data[3] = can_data->data[3]; 
    data[4] = can_data->data[4]; 
    data[5] = can_data->data[5]; 
    data[6] = can_data->data[6]; 
    data[7] = can_data->data[7]; 
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

/*****************************************************ATE相关************************************************************************************************/

// 0x0EF
static bool ext_can_tx_ate_flash_test(can_frame_data_t *can_data, uint16_t func_code)
{   
    const bms_runing_data_t *bms_data = get_bms_runing_data();

    if (bms_data == NULL)
    {
        return 0;
    }

    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    // 控制状态
    data[0] = 0;

    for (uint8_t i = 1; i < 8; i++)
    {
        data[i] = bms_data->flash_data[i-1];
    }
    
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT,tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

    return 0;
}

// 0x0F0
static bool ext_can_tx_ate_mode_ctl(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    // 老化控制回复, 标定模式回复, ATE测试模式回复
    data[0] = special_mode_get(AGING_MODE) ? OPEN_MODE : RELEASE_MODE;
    data[1] = special_mode_get(CALI_PARM) ? OPEN_MODE : RELEASE_MODE;
    data[2] = special_mode_get(ATUO_TEST) ? OPEN_MODE : RELEASE_MODE;
    // 强制控制开关
    data[4] = special_mode_get(FORCE_CTL_MODE) ? OPEN_MODE : RELEASE_MODE;
    // 产测步骤设置
    data[6] = product_finish_flag_get();
    // 校验
    data[7] = 0;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT,tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    return 0;
}

// 0x0F2
static bool ext_can_tx_ate_cali_time(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    sdk_rtc_t rtc_time = {0};
    sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);

    data[0] = rtc_time.tm_year;
    data[1] = rtc_time.tm_mon;
    data[2] = rtc_time.tm_day;
    data[3] = rtc_time.tm_hour;
    data[4] = rtc_time.tm_min;
    data[5] = rtc_time.tm_sec;

    // data[6]~data[7]保留

    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT,tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

    return 0;
}

// 0x0F3
static bool ext_can_tx_ate_set_pack_sn(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *p_bms_attr_data = get_bms_attr();
    if (NULL == p_bms_attr_data)
    {
        return 0;
    }

    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    uint8_t sn_len = sizeof(p_bms_attr_data->pack_sn); // pack_sn后面需要修改uint8_t
    uint8_t sn_cnt = (sn_len + PACK_SN_IN_FRAME_LEN - 1) / PACK_SN_IN_FRAME_LEN;      // 组数
    uint8_t frame_len = PACK_SN_IN_FRAME_LEN;

    for (uint8_t i = 0; i < sn_cnt; i++)
    {
        // 条形码组号n， n = 0, 1, 2, ...
        data[0] = i;

        if (i + 1 == sn_cnt)
        {
            frame_len = ((sn_len % PACK_SN_IN_FRAME_LEN) == 0) ? PACK_SN_IN_FRAME_LEN : sn_len % PACK_SN_IN_FRAME_LEN;
        }
        else
        {
            frame_len = PACK_SN_IN_FRAME_LEN;
        }

        for (uint8_t j = 0; j < frame_len; j++)
        {
            data[j + 1] = p_bms_attr_data->pack_sn[i * PACK_SN_IN_FRAME_LEN + j];
        }

        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT,tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

        memset(data, 0x0, sizeof(data));
    }

    return 0;
}

// 0x0F4
static bool ext_can_tx_ate_set_board_sn(can_frame_data_t *can_data, uint16_t func_code)
{
    const bms_attr_t *p_bms_attr_data = get_bms_attr();
    if (NULL == p_bms_attr_data)
    {
        return 0;
    }

    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    uint8_t sn_len = sizeof(p_bms_attr_data->board_sn); // pack_sn后面需要修改uint8_t
    uint8_t sn_cnt = (sn_len + BOARD_SN_IN_FRAME_LEN - 1) / BOARD_SN_IN_FRAME_LEN;      // 组数
    uint8_t frame_len = BOARD_SN_IN_FRAME_LEN;

    for (uint8_t i = 0; i < sn_cnt; i++)
    {
        // 条形码组号n， n = 0, 1, 2, ...
        data[0] = i;

        if (i + 1 == sn_cnt)
        {
            frame_len = ((sn_len % BOARD_SN_IN_FRAME_LEN) == 0) ? BOARD_SN_IN_FRAME_LEN : sn_len % BOARD_SN_IN_FRAME_LEN;
        }
        else
        {
            frame_len = BOARD_SN_IN_FRAME_LEN;
        }

        for (uint8_t j = 0; j < frame_len; j++)
        {
            data[j + 1] = p_bms_attr_data->board_sn[i * BOARD_SN_IN_FRAME_LEN + j];
        }

        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT,tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

        memset(data, 0x0, sizeof(data));
    }

    return 0;
}

// 0x0F6
static bool ext_can_tx_ate_bcu_func_sw_ctl(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    // ATE控制
    data[0] = ate_ctl_can_get(ATE_FUNC_SW_CTL_1);
    data[1] = ate_ctl_can_get(ATE_FUNC_SW_CTL_2);
    data[2] = ate_ctl_can_get(ATE_FUNC_SW_CTL_3);

//    // crc校验
    data[7] = can_single_frame_crc8_calc(can_data, MASTER_CTL_SET_CRC8_MASK);
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT,tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

    return 0;
}

// 0x0F9
static bool ext_can_tx_ate_cali_para_ctl(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    uint16_t hw_ver = hardware_ver_get();

    // 回复信息 0x01: 读取成功  0x02: 读取失败  0xAA: 恢复成功  0x55: 恢复异常  
    data[0] = (uint8_t)g_cali_para_result;

    // 软件版本号
    data[1] = SOFTWARE_VERSION[0];    // 软件版本说明: 'V'：正式版,'T'：测试版
    data[2] = ((uint8_t)(SOFTWARE_VERSION[1]-AsciiToInt)*10) + (SOFTWARE_VERSION[2]-AsciiToInt);    // 软件大版本号
    data[3] = ((uint8_t)(SOFTWARE_VERSION[3]-AsciiToInt)*10) + (SOFTWARE_VERSION[4]-AsciiToInt);    // 软件非标版本号
    data[4] = ((uint8_t)(SOFTWARE_VERSION[5]-AsciiToInt)*10) + (SOFTWARE_VERSION[6]-AsciiToInt);    // 软件小版本号

    // 硬件版本号
    fill_can_data_buff(hw_ver, data + 5, WORD_SIZE);

    // data[7]保留

    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT,tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

    return 0;
}

// 0x0FA
static bool ext_can_tx_ate_force_ctl(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    data[0] = ate_ctl_can_get(ATE_CTL_ITEM_1);
    data[1] = ate_ctl_can_get(ATE_CTL_ITEM_2);
    data[2] = ate_ctl_can_get(ATE_CTL_ITEM_3);
    // data[5] ~ data[6]保留

    // crc校验
    data[7] = can_single_frame_crc8_calc(can_data, ATE_CONTROL_CRC8_MASK);

    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT,tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

    return 0;
}

// 0x0B6 BCU遥信数据上报1
#define REMOTE_SIGNALING_DI_DATA           0x01
#define REMOTE_SIGNALING_RELAY_DATA        0x02
#define REMOTE_SIGNALING_CHG_DSG_DATA      0x03
#define REMOTE_SIGNALING_ACT_BAL_CHG_DATA  0x04
#define REMOTE_SIGNALING_ACT_BAL_DSG_DATA  0x05
static bool ext_can_tx_bcu_self_state(can_frame_data_t *can_data, uint16_t func_code)
{
    const bmu_data_unify_t *p_bmu_data_unify = bmu_data_unify_get();
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    uint16_t data_tmp = 0; 
    // 发送DI值状态
    memset(data, 0, sizeof(data));
    data[0] = REMOTE_SIGNALING_DI_DATA;
    data[1] = 0;
    data[2] = 0;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    
    // 继电器类型
    memset(data, 0, sizeof(data));
    data[0] = REMOTE_SIGNALING_RELAY_DATA;
    data[1] = 0;
    data[2] = 0;
    data[3] = 0;
    data[4] = 0;
    data[5] = 0;
    data[6] = 0;
    data[7] = 0;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

    // 发送充放电状态
    /* bit0:充电允许,bit1:放电允许,bit2:强制充电使能,bit3:满充,bit4:放空*/
    memset(data, 0, sizeof(data));
    data[0] = REMOTE_SIGNALING_CHG_DSG_DATA;
    uint8_t chg_enable = 0;
    uint8_t dsg_enable = 0;
    //sys_chg_dsg_enable_flag_get(&chg_enable, &dsg_enable);
    data[1] = 0;
    if (chg_enable)
    {
        SET_BIT(data[1], (uint8_t)1 << 0);
    }
    if (dsg_enable)
    {
        SET_BIT(data[1], (uint8_t)1 << 1);
    }
    if (NULL != p_bmu_data_unify)
    {
        SET_BIT(data[1], p_bmu_data_unify->force_chg_flag << 2);  //强充请求
    }

    if (NULL != p_bmu_data_unify)
    {
        data_tmp = p_bmu_data_unify->empty_full_flag;
    }
    else
    {
        data_tmp = 0xFFFF;
    }
    
    if ((data_tmp & 0xFF) == 0xAA)    // 充满
    {
        SET_BIT(data[1], (uint8_t)1 << 3);
    }

    if ((data_tmp & 0xFF00) == 0xAA00)    // 放空
    {
        SET_BIT(data[1], (uint8_t)1 << 4);
    }
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    
    // 发送主动均衡状态
    if (p_bmu_data_unify != NULL)
    {
        // 主动均衡充电类型
        memset(data, 0, sizeof(data));
        data[0] = REMOTE_SIGNALING_ACT_BAL_CHG_DATA;
        // data[1] = (uint8_t)p_bmu_data_unify->chg_bal_status & 0xFF;
        // data[2] = (uint8_t)(p_bmu_data_unify->chg_bal_status >> 8 & 0xFF);
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
        
        // 主动均衡放电类型
        memset(data, 0, sizeof(data));
        data[0] = REMOTE_SIGNALING_ACT_BAL_DSG_DATA;
        // data[1] = (uint8_t)p_bmu_data_unify->dsg_bal_status & 0xFF;
        // data[2] = (uint8_t)(p_bmu_data_unify->dsg_bal_status >> 8 & 0xFF);
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    }
    else
    {
        // 主动均衡充电类型
        memset(data, 0, sizeof(data));
        data[0] = REMOTE_SIGNALING_ACT_BAL_CHG_DATA;
        data[1] = 0;
        data[2] = 0;
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
        
        // 主动均衡放电类型
        memset(data, 0, sizeof(data));
        data[0] = REMOTE_SIGNALING_ACT_BAL_DSG_DATA;
        data[1] = 0;
        data[2] = 0;
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    }
    return 0;
}

// 0x0B7 BCU遥测数据上报1--温度采样数据
#define BCU_TERMINAL_TEMP 0x01
#define BCU_SPECIAL_TEMP 0xF0
static bool ext_can_tx_bcu_self_temp(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};
    
    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);
    const sample_data_t* p_sample_data = p_sample_data_get();
    
    memset(data, I8_INVALID_VALUE, sizeof(data));
    data[0] = BCU_TERMINAL_TEMP;
    if (p_sample_data != NULL)
    {
        data[1] = (p_sample_data->adc_sample_other_temp[LOAD_P_TEMP]) / 10 + 40;
        data[2] = (p_sample_data->adc_sample_other_temp[LOAD_N_TEMP]) / 10 + 40;
        data[3] = (p_sample_data->adc_sample_other_temp[BAT_P_TEMP]) / 10 + 40;
        data[4] = (p_sample_data->adc_sample_other_temp[BAT_N_TEMP]) / 10 + 40;
        data[5] = (p_sample_data->adc_sample_other_temp[PCB_TEMP]) / 10 + 40;
    }
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    
    memset(data, I8_INVALID_VALUE, sizeof(data));
    data[0] = BCU_SPECIAL_TEMP;
    if (p_sample_data != NULL)
    {
        data[1] = (p_sample_data->adc_sample_other_temp[TEMP_RSV_1]) / 10 + 40;
        data[2] = (p_sample_data->adc_sample_other_temp[TEMP_RSV_2]) / 10 + 40;
    }
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);    
    
    return 0;
}

// 0x0B8:BCU遥测数据上报2--电压采样
#define CLU_BAT_VOLT_TYPE 0x01
#define AUX_VOLT_TYPE     0x04
#define SPECIAL_VOLT1_TYPE 0xF0
#define SPECIAL_VOLT2_TYPE 0xF1
static bool ext_can_tx_bcu_self_volt1(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);
    const sample_data_t* p_sample_data = p_sample_data_get();
    
    if (p_sample_data == NULL)
    {
        memset(data, 0, sizeof(data));
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT,tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
        return 0;
    }
    // 发送电池电压，P端电压
    memset(data, 0, sizeof(data));
    data[0] = CLU_BAT_VOLT_TYPE;
    fill_can_data_buff(p_sample_data->bus_volt / 100, data + 1, WORD_SIZE);
    fill_can_data_buff(p_sample_data->load_volt / 100, data + 3, WORD_SIZE);
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT,tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

    // 发送辅源电压
    memset(data, 0, sizeof(data));
    data[0] = AUX_VOLT_TYPE;
    fill_can_data_buff(p_sample_data->power_24v_volt, data + 1, WORD_SIZE);
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);
    
    // 发送其他相关电压1
    memset(data, 0, sizeof(data));
    data[0] = SPECIAL_VOLT1_TYPE;
    fill_can_data_buff(p_sample_data->power_12v_volt , data + 1, WORD_SIZE);
    fill_can_data_buff(p_sample_data->hall_5v_volt , data + 3, WORD_SIZE);
    fill_can_data_buff(p_sample_data->hall_large_volt , data + 5, WORD_SIZE);
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);    
    
    // 发送其他相关电压2
    memset(data, 0, sizeof(data));
    data[0] = SPECIAL_VOLT2_TYPE;
    fill_can_data_buff(p_sample_data->hall_small_volt , data + 1, WORD_SIZE);
    fill_can_data_buff(p_sample_data->out3_volt, data + 3, WORD_SIZE);
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);       
    return 0;    
}

// 0x0B9 BCU遥测数据上报3---电流数据
#define SYS_CURR_TYPE 0x01
static bool ext_can_tx_bcu_self_curr(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);
    
    // 发送系电流值
    const sample_data_t* p_sample_data = p_sample_data_get();
    if (p_sample_data != NULL)
    {
        data[0] = SYS_CURR_TYPE;
        fill_can_data_buff(p_sample_data->sys_current / 100, data + 1, WORD_SIZE);
        fill_can_data_buff(I16_INVALID_VALUE, data + 3, WORD_SIZE);
        fill_can_data_buff(I16_INVALID_VALUE, data + 5, WORD_SIZE);
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);   
    }
    return 0;
}

// 0x0BD-BCU设备版本信息
static bool ext_can_tx_bcu_self_ver(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);
    
    // 发送BCU_COM的版本信息
    data[0] = SOFTWARE_VERSION[0];    // 软件版本说明: 'V'：正式版,'T'：测试版
    data[1] = ((uint8_t)(SOFTWARE_VERSION[1]-AsciiToInt)*10) + (SOFTWARE_VERSION[2]-AsciiToInt);    // 软件大版本号
    data[2] = ((uint8_t)(SOFTWARE_VERSION[3]-AsciiToInt)*10) + (SOFTWARE_VERSION[4]-AsciiToInt);    // 软件非标版本号
    data[3] = ((uint8_t)(SOFTWARE_VERSION[5]-AsciiToInt)*10) + (SOFTWARE_VERSION[6]-AsciiToInt);    // 软件小版本号
    data[4] = hardware_ver_get();
    fill_can_data_buff((uint16_t)CAN_VERSION, data + 5, WORD_SIZE);          // 协议版本号
    data[7] = 0xFF;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);   
    
    return 0;
}

// 0x0C0-:BCU系统时间
static bool ext_can_tx_bcu_self_time(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);

    sdk_rtc_t rtc_time = {0};
    sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);

    data[0] = rtc_time.tm_year;
    data[1] = rtc_time.tm_mon;
    data[2] = rtc_time.tm_day;
    data[3] = rtc_time.tm_hour;
    data[4] = rtc_time.tm_min;
    data[5] = rtc_time.tm_sec;

    // data[6]~data[7]保留

    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS); 

    return 0;
}

// 0x0C1 BCU遥测数据上报3---其他数据
#define ISO_RES_TYPE 0x01
static bool ext_can_tx_bcu_other_data(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);
    memset(data, 0xFF, sizeof(data));
    // 发送绝缘阻抗
    data[0] = ISO_RES_TYPE;
    fill_can_data_buff(insulation_impedance_value_get(), data + 1, WORD_SIZE);
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS); 
    return 0;
}

// 0x0C2-测试结果/其他参数(一般用于ate测试)
#define ATE_TEST_RESULT1_TYPE 0x01
#define ATE_TEST_RESULT2_TYPE 0x02
#define ATE_TEST_RESULT3_TYPE 0x03
#define TIMING_INTERVAL_TYPE 0x10
static bool ext_can_tx_bcu_self_val_result(can_frame_data_t *can_data, uint16_t func_code)
{
    uint8_t data[CAN_SIGNAL_FRA_MAX_NUMS] = {0};
    can_frame_id_u rx_can_frame = {can_data->id};
    can_frame_id_u tx_can_frame = {0};

    can_id_dst_addr_fill(&tx_can_frame, rx_can_frame, func_code);
    
    // 发送测试结果
    memset(data, 0xFF, sizeof(data));
    data[0] = ATE_TEST_RESULT1_TYPE;
    data[1] = get_ate_test_func_result(ATE_CAN0_TEST_RESULT);
    data[2] = get_ate_test_func_result(ATE_CAN1_TEST_RESULT);
    data[3] = get_ate_test_func_result(ATE_485_TEST_RESULT);
    data[4] = get_ate_test_func_result(ATE_INNER_ADDR_IO_TEST_RESULT);
    data[5] = get_ate_test_func_result(ATE_EXT_WDT_TEST_RESULT);
    data[6] = get_ate_test_func_result(ATE_FLASH_FORMAT_TEST_RESULT);
    data[7] = get_ate_test_func_result(ATE_CAN2_TEST_RESULT);
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

    // 发送测试结果
    memset(data, 0xFF, sizeof(data));
    data[0] = ATE_TEST_RESULT2_TYPE;
    data[1] = get_ate_test_func_result(ATE_DO1_TEST_RESULT);
    data[2] = get_ate_test_func_result(ATE_DO2_TEST_RESULT);
    data[3] = get_ate_test_func_result(ATE_DO3_TEST_RESULT);
    data[4] = get_ate_test_func_result(ATE_CLU_ADDR_IO_TEST_RESULT);
    data[5] = get_ate_test_func_result(ATE_DO4_TEST_RESULT);
    data[6] = get_ate_test_func_result(ATE_DO5_TEST_RESULT);
    data[7] = get_ate_test_func_result(ATE_DO6_TEST_RESULT);
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

    // 发送测试结果
    memset(data, 0xFF, sizeof(data));
    data[0] = ATE_TEST_RESULT3_TYPE;
    data[1] = get_ate_test_func_result(ATE_DO7_TEST_RESULT);
    data[2] = get_ate_test_func_result(ATE_DO8_TEST_RESULT);
    data[3] = 0;
    data[4] = 0;
    data[5] = 0;
    data[6] = 0;
    data[7] = 0;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

    // 发送测试结果
    memset(data, 0xFF, sizeof(data));
    data[0] = TIMING_INTERVAL_TYPE;
    data[1] = 0;
    data[2] = 0;
    data[3] = 0;
    data[4] = 0;
    data[5] = 0;
    data[6] = 0;
    data[7] = 0;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_can_frame.id_val, data, CAN_SIGNAL_FRA_MAX_NUMS);

    return 0;
}

/***************************************************************外can发送处理函数end***********************************************/

/**
* @brief		内网初始化，并注册内网CAN ID
* @param		无
* @return		无
* @retval		无
* @warning		无 
*/
void can_ext_data_init(void)
{
    uint16_t rec_msg_amount = 0;
    can_frame_id_u frame_id[] = 
    {
        // res     prio(优先级)      fun_code,    dst_type dst_addr, src_type, src_addr
        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_LOW_L,  .bit.fun_code= GOLD_FUNC_CELL_DATA_REQ_CMD, 
            .bit.dst_type= DEV_BROADCAST, .bit.dst_addr= 0, .bit.src_type= DEV_BROADCAST, .bit.src_addr =0},
        // res     prio(优先级)      fun_code,    dst_type dst_addr, src_type, src_addr
        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_HIGH_L,  .bit.fun_code= GOLD_FUNC_CELL_DATA_REQ_CMD, 
            .bit.dst_type= DEV_BROADCAST, .bit.dst_addr= 0, .bit.src_type= DEV_BROADCAST, .bit.src_addr =0},
        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_LOW_H,  .bit.fun_code= GOLD_FUNC_CELL_DATA_REQ_CMD, 
            .bit.dst_type= DEV_BROADCAST, .bit.dst_addr= 0, .bit.src_type= DEV_BROADCAST, .bit.src_addr =0},
    };
    can_sofar_rcv_reg_t can_rxmsg_tab[] = // BCU接收上位机或PCS的数据
    {
        {frame_id[0].id_val, 0x07FFFFFF, ext_can_sofar_frame_parse_deal,},  // 优先级为0x03帧
        {frame_id[1].id_val, 0x07FFFFFF, ext_can_sofar_frame_parse_deal,},  // 优先级为0x01帧
        {frame_id[2].id_val, 0x07FFFFFF, ext_can_sofar_frame_parse_deal,},  // 优先级为0x02帧    
    };
        
    // 注册接收的数据
    rec_msg_amount = sizeof(can_rxmsg_tab)/sizeof(can_sofar_rcv_reg_t);
    ext_can_sofar_register_receive_frame(can_rxmsg_tab, rec_msg_amount);
    // 用于提示开发人员表格没有从小到大排序
    for (uint8_t list_cnt = 0; list_cnt < g_ext_rx_can_msg_prio_0x11_list_len - 1; list_cnt++)
    {
        if (g_ext_rx_can_msg_prio_0x11_list[list_cnt].func_code > g_ext_rx_can_msg_prio_0x11_list[list_cnt + 1].func_code)
        {
            log_d("extRx1canList%d 0x%x,0x%x\n", list_cnt, g_ext_rx_can_msg_prio_0x11_list[list_cnt].func_code, g_ext_rx_can_msg_prio_0x11_list[list_cnt + 1].func_code);
            break;
        }
    }
    for (uint8_t list_cnt = 0; list_cnt < g_ext_rx_can_msg_prio_0x01_list_len - 1; list_cnt++)
    {
        if (g_ext_rx_can_msg_prio_0x01_list[list_cnt].func_code > g_ext_rx_can_msg_prio_0x01_list[list_cnt + 1].func_code)
        {
            log_d("extRx2canList%d 0x%x,0x%x\n", list_cnt, g_ext_rx_can_msg_prio_0x01_list[list_cnt].func_code, g_ext_rx_can_msg_prio_0x01_list[list_cnt + 1].func_code);
            break;
        }
    }
    for (uint8_t list_cnt = 0; list_cnt < g_ext_tx_can_msg_list_len; list_cnt++)
    {
        if (g_ext_tx_can_msg_list[list_cnt].id != list_cnt)
        {
            log_e("extTxcanList%d Err%d,0x%x\n", list_cnt, g_ext_tx_can_msg_list[list_cnt].id);
            break;
        }
    }
    // 初始化定值、参数点表
    // update_para();
    // update_threshold();
    auto_send_can_ext_func_set(EXT_AUTO_SEND_FORBID_TYPE); // 启动自动发送内网数据（暂时放这，后续在BMU处于开机状态时打开）
}


// 发送任务
void can_ext_data_send_proc(void)
{
    // 周期发送数据请求
    cycle_send_sofar_data_proc();
    // 外部发送和本模块异步发送
    request_can_send_frame_deal();
}

uint8_t cmu_power_ctrl_type_get(void)
{
    return g_cmu_power_ctrl_type;
}

/************************************* 参数读取函数定义 BEGIN *************************************/

/**
* @brief		上位机使能can发送接口
* @param		[in]auto_send_data_type
* @return		返回结果
* @retval		0：操作成功    < 0: 操作失败
* @warning		无 
*/
//static uint16_t upper_sys_can_send_flag_get(void)
//{
//    return  g_upper_sys_con_flag;
//}

/************************************* 参数读取函数定义 END ***************************************/


/************************************* 参数设置函数定义 BEGIN *************************************/


///**
//* @brief		老化模式请求
//* @param		[in]no : 校的位置   ；[value]：模式开启  
//* @return		返回结果
//* @retval		0：操作成功    < 0: 操作失败
//* @warning		无 
//*/
//static int8_t aging_mode_request(uint16_t value)
//{
//    if(OPEN_MODE == value)
//    {
//        special_mode_set(AGING_MODE,ATE_SET);
//        return 0;
//    }
//    else if (RELEASE_MODE == value)
//    {
//        special_mode_set(AGING_MODE,ATE_CLR);
//        return 0;
//    }

//    return -1;
//    
//}

///**
//* @brief		标定模式请求
//* @param		[in]no : 校的位置   ；[value]：模式开启  
//* @return		返回结果
//* @retval		0：操作成功    < 0: 操作失败
//* @warning		无 
//*/
//static int8_t cali_mode_request(uint16_t value)
//{
//    if(OPEN_MODE == value)
//    {
//        special_mode_set(CALI_PARM,ATE_SET);
//        return 0;
//    }
//    else if (RELEASE_MODE == value)
//    {
//        special_mode_set(CALI_PARM,ATE_CLR);
//        return 0;
//    }

//    return -1;
//}

///**
//* @brief		ate模式请求
//* @param		[in]no : 校的位置   ；[value]：模式开启  
//* @return		返回结果
//* @retval		0：操作成功    < 0: 操作失败
//* @warning		无 
//*/
//static int8_t ate_mode_request(uint16_t value)
//{
//    if(OPEN_MODE == value)
//    {
//        special_mode_set(ATUO_TEST,ATE_SET);
//        return 0;
//    }
//    else if (RELEASE_MODE == value)
//    {
//        special_mode_set(ATUO_TEST,ATE_CLR);
//        return 0;
//    }

//    return -1;
//}

///**
//* @brief		上位机使能can发送接口
//* @param		[in]auto_send_data_type
//* @return		返回结果
//* @retval		0：操作成功    < 0: 操作失败
//* @warning		无 
//*/
//static int8_t upper_sys_can_send_flag_set(uint16_t value)
//{
//    if(OPEN_MODE == value)
//    {
//        g_upper_sys_con_flag = true;
//        return 0;
//    }
//    else if (RELEASE_MODE == value)
//    {
//        g_upper_sys_con_flag = false;
//        return 0;
//    }
//    return -1;
//}

///**
//* @brief		强控请求
//* @param		[in]no : 校的位置   ；[value]：模式开启  
//* @return		返回结果
//* @retval		0：操作成功    < 0: 操作失败
//* @warning		无 
//*/
//static int8_t force_ctrl_mode_request(uint16_t value)
//{
//    if(OPEN_MODE == value)
//    {
//        special_mode_set(FORCE_CTL,ATE_SET);
//        return 0;
//    }
//    else if (RELEASE_MODE == value)
//    {
//        special_mode_set(FORCE_CTL,ATE_CLR);
//        return 0;
//    }

//    return -1;
//}

///**
//* @brief		标定参数恢复
//* @param		[in]no : 校的位置   ；[value]：模式开启  
//* @return		返回结果
//* @retval		0：操作成功    < 0: 操作失败
//* @warning		无 
//*/
//static int8_t cali_resume_default(uint16_t value)
//{
//    if((0xAA == value)
//        && (special_mode_get(CALI_PARM)))
//    {
//        return attr_data_resume_default_data();
//    }
//    
//    return -1;
//}

/**
* @brief		自动发送外网数据使能接口
* @param		[in]auto_send_data_type
* @return		返回结果
* @retval		0：操作成功    < 0: 操作失败
* @warning		无 
*/
int32_t auto_send_can_ext_func_set(uint8_t type)
{
    if (type >= EXT_AUTO_SEND_DATA_TYPE_NUM)
    {
        return -1;
    }
    g_ext_send_data_type = type;

    return 0;
}

/************************************* 参数设置函数定义 END ***************************************/
