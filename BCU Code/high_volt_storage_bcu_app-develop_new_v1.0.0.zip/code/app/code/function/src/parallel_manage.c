#include "sdk.h"
#include "sdk_core.h"
#include "parallel_manage.h"
#include "bcu_data.h"
#include "sample.h"
#include "external_can_data.h"
#include "data_types.h"
#include "bmu_data.h"
#include "insulation_impedance_calc.h"
#include "public_flag.h"
#include "relay_manage.h"

static uint8_t g_parallel_debug = false;
static parallel_flag_t g_parallel_flag = {0};
static uint8_t g_first_machine_ins_en_flag = true; //第一簇并机完成绝缘检测使能

// static uint32_t g_parallel_tick = 0;

/**
* @brief  parallel_data_init 并机数据初始化
 * @param  
 * @return  
 */
void parallel_data_init(void)
{
    g_parallel_flag.con_manchine = false;
    g_parallel_flag.first_manchine = false;   
    g_parallel_flag.last_manchine = false;
    g_first_machine_ins_en_flag = true; 
    // g_parallel_tick = sdk_tick_get();
}

/**
* @brief  parallel_machine_sort_proc 并机排序处理
 * @param  
 * @return  
 */
static void parallel_machine_sort_proc(void)    //TO DO 当前复杂程度不高，暂时没有写成状态机形式，如果按状态机形式的话就分成初始化（过程中去判断条件），并入，不并入
{
    sample_data_t bat_data = {0};
    const bmu_data_unify_t *p_bmu_data_unify = bmu_data_unify_get();
    static uint8_t pre_err_stus = NO_ERR;
    uint16_t volt_suit_flag = 0;
    uint8_t last_mach_flag = 0;


//    sample_data_get(&bat_data);
    
    if(true == g_parallel_debug)    //手动控制并机
    {
        return;
    }
    
    for(uint8_t i = 0; i < MAX_CLU_NUM; i++) /*统计V本簇和V并入电压条件是否满足*/
    {
        if((0x01 & (get_gobal_bcu_info()->parallel_state >> i))
            && abs((int32_t)get_cluster_bcu_data(i)->clu_volt - (int32_t)bat_data.bus_volt <= PARALLEL_VOLT)) 
        {
            volt_suit_flag |= (0x01 << i);
            last_mach_flag++;
        }
    }


    if((CLU_POWER_FAULT_OFF_SIGNAL == get_gobal_bcu_info()->set_power_state) /* */
        || (CLU_POWER_FAULT_OFF_ALL == get_gobal_bcu_info()->set_power_state)
        || (false == di_state_get(DI_7_EMERGENCY_STOP))
        || (true == di_state_get(DI_8_CMU_FAULT))
        )  
    {
        g_parallel_flag.con_err = CMU_ERR_CUT_OFF;

        if(get_relay_real_state(POS_RELAY) == RELAY_OPEN)   //确保继电器断开需要重新并机才重新初始化对应变量
        {
            parallel_data_init();
        }
    }
    else if(get_bcu_info()->fault_state)
    {
        g_parallel_flag.con_err = BAT_ERR;

        if(get_relay_real_state(POS_RELAY) == RELAY_OPEN)   //确保继电器断开需要重新并机才重新初始化对应变量
        {
            parallel_data_init();
        }        
    }    
    else if((CLU_POWER_OFF_SIGNAL == get_gobal_bcu_info()->set_power_state)
        || (CLU_POWER_OFF_ALL == get_gobal_bcu_info()->set_power_state))
    {
        g_parallel_flag.con_err = CMU_NOR_CUT_OFF;

        if(get_relay_real_state(POS_RELAY) == RELAY_OPEN)   //确保继电器断开需要重新并机才重新初始化对应变量
        {
            parallel_data_init();
        }        
    }
    else if(((0 == get_gobal_bcu_info()->parallel_state) && (CLU_POWER_ON_SIGNAL == get_gobal_bcu_info()->set_power_state))
            || (true == g_parallel_flag.first_manchine))
    {
        g_parallel_flag.con_manchine = true;
        g_parallel_flag.first_manchine = true;
        g_parallel_flag.con_err = NO_ERR;

        if((get_gobal_bcu_info()->clu_bcu_num == last_mach_flag) //都并入后，第一簇并入的启动一次绝缘检测；
            && (true == g_first_machine_ins_en_flag))
        {
            g_first_machine_ins_en_flag = false;
            insulation_impedance_calc_start();
        }
    }
    else if((0 != get_gobal_bcu_info()->parallel_state)    
                && (CLU_POWER_ON_SIGNAL == get_gobal_bcu_info()->set_power_state))
    {
        
        if(abs(get_gobal_bcu_info()->heap_curr) < PARALLEL_HEAP_CUR)
        {
            if(volt_suit_flag == get_gobal_bcu_info()->parallel_state)  //当已并进去的都满足压差范围并且堆电流满足
            {

                {
                    g_parallel_flag.con_err = NO_ERR;

                    g_parallel_flag.con_manchine = true;
                    if(get_gobal_bcu_info()->clu_bcu_num == (last_mach_flag - 1))   //除自身外都并入了，说明是最后一簇
                    {
                        g_parallel_flag.last_manchine = true;
                    }                
                }


            }
            else
            {
                g_parallel_flag.con_err = BAT_VOLT_DIFF_ERR;
            }            
        }
        else
        {
            ;   //TO DO并机前堆电流过大，当前没有这个故障上报
        }

        
    }
    else    //无上电标志和其他未考虑到的状态时；
    {
        parallel_data_init();
        g_parallel_flag.con_err = NO_ERR;
    }

    if(pre_err_stus != g_parallel_flag.con_err)
    {
        pre_err_stus = g_parallel_flag.con_err;
        log_e("[parallel]con err:%d\n",g_parallel_flag.con_err);
    }

}

/**
* @brief  parallel_manage_proc 并机管理
 * @param  
 * @return 
 */
void parallel_manage_proc(void)
{
    parallel_machine_sort_proc();
}

/**
 * @brief  Get the parallel stus object 返回并机状态
 * @param  i: 
 * @return uint8_t: 
 */
uint8_t get_parallel_state(parallel_data_e i)
{
    uint8_t stus = 0;

    switch (i)
    {
        case PARALLEL_FIRST_MACH:
            stus = g_parallel_flag.first_manchine;
            break;

        case PARALLEL_LAST_MACH:
            stus = g_parallel_flag.last_manchine;
            break;

        case PARALLEL_CON:
            stus = g_parallel_flag.con_manchine;
            break;

        case PARALLEL_ERR:
            stus = g_parallel_flag.con_err;
            break;
        default:
            break;
    }

    return stus;
}


static int parallel(int argc, char *argv[])
{
    if (argc < 2)
    {
        log_d("parallel para err,<debug 0-1/init/first/last/con/err>\n");
        return SF_ERR_PARA;
    }
    
    if (!strcmp(argv[1], "debug"))
    {
        int32_t flag = atoi(argv[2]); //使能或失能手动控制
        
        if(true == flag)
        {
            g_parallel_debug = true;
        }
        else
        {
            g_parallel_debug = false;
        }
    }
    else if(!strcmp(argv[1], "init"))   //参数初始化
    {
        parallel_data_init();
        g_parallel_flag.con_err = NO_ERR;
    }
    else if(!strcmp(argv[1], "first"))   //第一簇并机
    {
        g_parallel_flag.first_manchine = true;
        g_parallel_flag.con_manchine = true;
    }
    else if(!strcmp(argv[1], "last"))   //最后一簇并机
    {
        g_parallel_flag.last_manchine = true;
        g_parallel_flag.con_manchine = true;        
    }
    else if(!strcmp(argv[1], "other"))   //其他并机标志
    {
        g_parallel_flag.con_manchine = true;        
    }
    else
    {
        log_d("[parallel]first_manch:%d,last_manch:%d,con_manch:%d,con_err:%d\n",g_parallel_flag.first_manchine,g_parallel_flag.last_manchine,g_parallel_flag.con_manchine,g_parallel_flag.con_err);
    }
    
    return SF_OK;
}
MSH_CMD_EXPORT(parallel, <debug/init/first/last/con/err>);





