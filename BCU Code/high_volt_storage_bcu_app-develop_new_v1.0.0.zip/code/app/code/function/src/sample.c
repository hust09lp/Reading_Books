/**
 * @file     sample.c
 * @brief    电池数据采样文件
 * @company  sofarsolar
 * @author   刘吕从
 * @note     综合所有底层采样模拟量
 * @version
 * @date     2023/4/27 初稿
 */
#include <string.h>
#include <stdlib.h>
#include "sofar_errors.h"
#include "sdk_para.h"
#include "sofar_errors.h"
#include "sdk.h"
#include "sdk_adc.h"
#include "sample.h"
#include "data_store.h"
#include "ate.h"
#include "app_public.h"
#include "inner_can_data.h"

#define SAMPLE_LOGD(...) log_d(__VA_ARGS__)
#define NTC_OMEGA_10K (10000)
#define NTC_OMEGA_1K (1000)
#define NTC_OMEGA_4K7 (4700)
#define NTC_OMEGA_NULL (0)
#define ADC_CODE_VAL_INVAILD (0x80000000)

#define EXT_CURR_FIRST_FILTER_K_B10 (1)  // 片外电流采样一阶滤波系数
#define EXT_CURR_FIRST_FILTER_MAX_K (10) // 片外电流采样一阶滤波分母

#define SAMPLE_OK (0)
#define SAMPLE_P_NULL_ERR (-1)
#define SAMPLE_OVER_PARA_ERR (-2)
#define SAMPLE_ADC_INVAILD_ERR (-3)
#define SAMPLE_NO_CALI_MODE_ERR (-4)

#define SAMPLE_BASE (10)                    // 10ms定时任务, 根据实际改动
#define SAMPLE_1000MS_TIME (1000 / SAMPLE_BASE) // 1000ms定时任务

#define HW_VER_CD_VOLT 2200 // 硬件版本电压表不规则段临界电压
#define HW_VER_CAL_VOLT 200 // 硬件版本电压表校偏电压

#define LARGE_CUR_RANGE 31000  // 大电流量程
#define LITTLE_CUR_RANGE 29000 // 小电流量程
#define CUR_RANGE 33000  // 电流切换量程

#ifdef APP_BCU_SAMPLE_TEST
static bool g_app_sample_code_debug_flag = false;
static bool g_app_sample_value_debug_flag = false;
#endif

/**
 * @enum  sample_adc_id
 * @brief ADC 数据表索引定义
 */
typedef enum
{
    SAMPLE_INIT = 0,    ///< 采样数据初始化
    SAMPLE_ZERO_OFFSET, ///< 获取adc偏移值
    SAMPLE_IN_WROKING,  ///< 正常采样
    SAMPLE_PROC_STATE_NUM,
} sample_process_state;

// 参数校准数据
typedef struct
{
    int32_t adc_value;
    uint32_t max_cali_value;
    uint32_t min_cali_value;
    uint32_t gain_value;
    int32_t offset_adc_value;
    uint32_t divisor_value;
} adc_sample_cali_para_t;

static sample_data_t g_sample_data = {0};                       // 电池采样数据
static uint16_t g_ntc_res[OTHER_NTC_NUM] = {0};                 // NTC电阻
static int32_t g_adc_code_buff[SDK_ADC_MAX] = {0};               // 获取片内adc的码值
static sample_process_state g_sample_process = SAMPLE_INIT;     // 默认空闲状态
static adjust_para_tab_t g_adjust_para_tab = {0};               // 校准参数表赋初始值
static pack_other_device_info_t g_pack_other_device_info = {0}; // 其他设备数据
static bool g_sample_enable_flag = true;

const uint16_t  ntc_res_table[] =                                   // NTC阻值表
{
    21794,	20553,	19403,	18331,	17327,	16385,	15499,	14666,	13880,	13139,	12441,           //-40 ~ -30
    11784,	11163,	10579,	10028,	9509,	9020,	8559,	8124,	7714,	7328,                    //-29 ~ -20
    6963,	6619,	6294,	5987,	5698,	5424,	5165,	4920,	4688,	4469,                    //-19 ~ -10
    4261,	4064,	3878,	3701,	3533,	3374,	3223,	3079,	2943,	2814,                    //- 9 ~ 0
    2691,	2574,	2463,	2357,	2257,	2161,	2070,	1984,	1901,	1823,                    //  1 ~ 10
    1748,	1677,	1609,	1544,	1482,	1423,	1367,	1314,	1262,	1214,                    // 11 ~ 20
    1167,	1122,	1080,	1039,	1000,	963,	927,	893,	860,	829,                     // 21 ~ 30
    799,	771,	743,	717,	692,	668,	644,	622,	601,	580,                     // 31 ~ 40
    560,	542,	523,	506,	489,	473,	457,	442,	428,	414,                     // 41 ~ 50
    401,	388,	376,	364,	352,	341,	331,	320,	311,	301,                     // 51 ~ 60
    292,	283,	274,	266,	258,	250,	243,	236,	229,	222,                     // 61 ~ 70
    216,	210,	204,	198,	192,	187,	181,	176,	171,	167,                     // 71 ~ 80
    162,	158,	153,	149,	145,	141,	137,	134,	130,	127,                     // 81 ~ 90
    124,	120,	117,	114,	111,	108,	106,	103,	100,	98,                      // 91 ~ 100
    96,	    93,	    91,	    89,	    87,	    84,	    82,	    81,	    79,	    77,                      //101 ~ 110
    75,	    73,	    71,	    70,	    68,	    67,	    65,	    64,	    62,	    61,                      //111 ~ 120
    59,	    58,	    57,	    55,	    54,	                                                             //121 ~ 125   
};

/**
 * @brief                设置采样进程
 * @param                [in]sample_process_state 需要设置的采样状态
 * @return               返回结果 无
 * @warning              无
 */
void sample_process_state_set(sample_process_state state)
{
    if (state >= SAMPLE_PROC_STATE_NUM)
    {
        return;
    }
    g_sample_process = state;
}

/**
* @brief                采样初始化
* @param                [in]无
* @return               返回结果void
* @warning              无
*/
void sample_init(void)
{
    memset(&g_sample_data, 0, sizeof(sample_data_t));
    for (int8_t adc_index = SDK_ADC_START; adc_index < SDK_ADC_MAX; adc_index++)
    {
        g_adc_code_buff[adc_index] = ADC_CODE_VAL_INVAILD;
    }
    g_sample_process = SAMPLE_INIT;
    g_sample_enable_flag = true;

    memcpy(&g_adjust_para_tab, &get_bms_attr()->adjust, sizeof(adjust_para_tab_t)); //校准参数获取   
}

/**
 * @brief      遍历所有片内片外adc通道，并且记录码值和电压值
 * @warning    由于获取电压的在片内片外adc电压公式都是固定的，可以使用for循环
 */
void adc_code_traversal_get(void)
{
#ifdef APP_BCU_SAMPLE_TEST
    if (g_app_sample_code_debug_flag)
    {
        return;
    }
#endif

    for (int8_t adc_index = SDK_ADC_START; adc_index < SDK_ADC_MAX; adc_index++)
    {
        sdk_adc_read(adc_index, &g_adc_code_buff[adc_index]);
    }
}
/**
 * @brief                 计算res值
 * @param                [in]adc码值
 * @param                [in]上电阻值 单位Ω
 * @param                [in]下电阻值 单位Ω
 * @return               返回结果
 * @retval               [out]返回ntc阻值 单位0.01kΩ
 * @warning              (默认参考电压为3000mv，采集电压3000mv, 分辨率INNER_ADC_RESOLUTION)
 * @warning              只有温度采样电路才适用, 注意防止数据翻转
 */
static uint16_t sdk_calc_ntc_res(int32_t adc_code, uint32_t up_res, uint32_t down_res)
{
    if (ADC_CODE_VAL_INVAILD == adc_code)
    {
        SAMPLE_LOGD("[SAMPLE]ntc adc_code invaild...\n");
        return 0xffff;
    }
    // 如果上电阻为0,则无法使用该函数
    if (0 == up_res)
    {
        return 0xffff;
    }
    uint32_t de_tmp = (((uint32_t)SAMP_VOLT * 1000 - (uint32_t)REF_VOLT * adc_code / INNER_ADC_RESOLUTION * 1000)) / up_res; // 分母 电流值
    if (0 == de_tmp)
    {
        return 0xffff;
    }
    int32_t nu_tmp = (REF_VOLT * (up_res + down_res) / up_res * adc_code / INNER_ADC_RESOLUTION - SAMP_VOLT * down_res / up_res); // 分子，ntc电压值
    if (nu_tmp < 0) 
    {
        nu_tmp = 0;
    }

    return (uint16_t)(nu_tmp * 100 / de_tmp);
}
/**
 * @brief                其他ntc ID转换采样adc ID
 * @param                [in] NTC ID
 * @return               返回结果
 * @retval               [out] 片内ADC ID
 * @warning              无
 */
static sdk_adc_sample_index_e sdk_other_ntc_id_to_adc_id(ntc_type_e ntc_id)
{
    sdk_adc_sample_index_e adc_id = SDK_ADC_MAX;
    switch (ntc_id)
    {
    case LOAD_P_TEMP:
        adc_id = SDK_ADC_LOAD_P_TEMP;
        break;
    case LOAD_N_TEMP:
        adc_id = SDK_ADC_LOAD_N_TEMP;
        break;
    case BAT_P_TEMP:
        adc_id = SDK_ADC_BAT_P_TEMP;
        break;
    case BAT_N_TEMP:
        adc_id = SDK_ADC_BAT_N_TEMP;
        break;
    case TEMP_RSV_1:
        adc_id = SDK_ADC_TEMP_RSV_1;
        break;        
    case TEMP_RSV_2:
        adc_id = SDK_ADC_TEMP_RSV_2;
        break;          
    case PCB_TEMP:
        adc_id = SDK_ADC_PCB_TEMP;
        break;
    default:
        adc_id = SDK_ADC_START;
        break;
    }
    return adc_id;
}

/**
* @brief                查表计算得到温度（无偏移）
* @param                [in]uint16_t res_data 电阻值
* @return               返回温度值
* @retval               [out]
* @warning              无
*/
static int16_t res_to_temp(uint16_t res_data)
{
    int16_t left = 0;
    int16_t mid = 0;
    int16_t right = (TEMP_TABLE_SIZE - 1);
    int16_t res_tmp;
    while (left <= right)//二分法查表确定传入的电阻值在表格中的位置
    {
        mid = (left + right) / 2;
        if (mid < 0)
        {
            return 0;
        }
        if (ntc_res_table[mid] == res_data)//传入阻值为表格中的值
        {
            mid *= 10;
            return (mid - BAT_TEMP_OFFSET);
        }
        else if (ntc_res_table[mid] > res_data) //中间值偏大 初端右移
        {
            left = mid + 1;
        }
        else //中间值偏小  终端左移
        {
            right = mid - 1;
        }
    }

    if (res_data >= ntc_res_table[left] && (left >= 1))
    {
        res_tmp = (res_data - ntc_res_table[left]) * 10 / (ntc_res_table[left - 1] - ntc_res_table[left]);
        (res_tmp < 10) ? (left = 10 * left - res_tmp) : (left *= 10);
    }
    else
    {
        left *= 10; //0.1℃
    }
    return  (left - BAT_TEMP_OFFSET);
}

/**
 * @brief                非电芯温度采集
 * @param                [in]无
 * @return               返回结果空
 * @retval               [out]无
 * @warning              无
 */
static void other_temp_sample(void)
{
    uint8_t adc_index;
    // 上阻值/下阻值不一致，可以考虑用表驱动; 当前一致，所以用for循环遍历
    for (uint8_t other_ntc_id = 0; other_ntc_id < OTHER_NTC_NUM; other_ntc_id++)
    {
        adc_index = sdk_other_ntc_id_to_adc_id((ntc_type_e)other_ntc_id);
        if (SDK_ADC_MAX <= adc_index)
        {
            continue;
        }
        if (ADC_CODE_VAL_INVAILD == g_adc_code_buff[adc_index])
        {
            continue;
        }
        if (other_ntc_id == PCB_TEMP)
        {
            g_ntc_res[other_ntc_id] = sdk_calc_ntc_res(g_adc_code_buff[adc_index], NTC_OMEGA_10K, 0);
        }
        else
        {
            g_ntc_res[other_ntc_id] = sdk_calc_ntc_res(g_adc_code_buff[adc_index], NTC_OMEGA_10K, NTC_OMEGA_1K);
        }
        g_sample_data.adc_sample_other_temp[other_ntc_id] = res_to_temp(g_ntc_res[other_ntc_id]);
    }   
}

/**
 * @brief                其他设备采集
 * @param                [in]无
 * @return               返回结果空
 * @retval               [out]无
 * @warning              无
 */
static void other_device_sample(void)
{
    g_pack_other_device_info = *get_other_device_info();
}

/**
 * @brief    获取校准参数
 * @param        [in] adjust_para_tab_e adjust_para_type 校准参数类型
 * @param        [in]adc_sample_cali_para_t * p_cali_para 用指针接取数据
 * @return      返回结果
 * @retval      [out] ret(0)  校准获取参数成功
 * @retval      [out] ret(-1) 空指针校准计算失败
 * @retval      [out] ret(-2)  校准增益超出范围或校准类型无效计算失败
 * @warning     数据太多可以使用表驱动
 */
int32_t sample_adjust_cali_para_get(adjust_para_tab_e adjust_para_type, adc_sample_cali_para_t *p_cali_para)
{
    if (adjust_para_type >= ADJUST_PARA_NUM || NULL == p_cali_para)
    {
        return SAMPLE_P_NULL_ERR;
    }

    switch ((uint16_t)adjust_para_type)
    {
         case BUS_VOLT_GAIN:
            p_cali_para->adc_value = g_adc_code_buff[SDK_ADC_BAT_VOLT];
            p_cali_para->max_cali_value = BUS_VOLT_GAIN_H;
            p_cali_para->min_cali_value = BUS_VOLT_GAIN_L;
            p_cali_para->gain_value = EXT_ADC_RESOLUTION * 100;         // 100:把单位100mV转换成1mV
            p_cali_para->divisor_value = 1;                             // 1:表示无需除
            p_cali_para->offset_adc_value = 0;
            break;
        case LOAD_VOLT_GAIN:
            p_cali_para->adc_value = g_adc_code_buff[SDK_ADC_LOAD_VOLT];
            p_cali_para->max_cali_value = LOAD_VOLT_GAIN_H;
            p_cali_para->min_cali_value = LOAD_VOLT_GAIN_L;
            p_cali_para->gain_value = EXT_ADC_RESOLUTION * 100;         // 100:把单位100mV转换成1mV
            p_cali_para->divisor_value = 1;                             // 1:表示无需除
            p_cali_para->offset_adc_value = 0;
            break;
        default:
            return SAMPLE_OVER_PARA_ERR;
    }
    return SAMPLE_OK;
}

/**
* @brief    校准参数计算
* @param    [in] adjust_para_tab_e adjust_para_type 校准参数类型
* @param        [in]uint32_t cali_value 校准值
* -# 电流值      单位10mA  
* -# 电压值      单位0.1V
* @param        [in]adjust_para_tab_t *adjust_para_tab 校准结果值为校准参数结构体中的一个成员变量
* @return    返回结果
* @retval      [out] ret(0)  校准计算成功
* @retval      [out] ret(-1) 空指针校准计算失败
* @retval      [out] ret(-2)  校准增益超出范围或校准类型无效计算失败
* @retval      [out] ret(-3)  adc采样无效计算失败
* @warning
*/
static int32_t sample_adjust_cali(adjust_para_tab_e adjust_para_type,uint32_t cali_value, adjust_para_tab_t *p_adjust_para_tab) 
{
    if (NULL == p_adjust_para_tab || ADJUST_PARA_NUM <= adjust_para_type)        // 指针为空 返回设置失败
    {
        return SAMPLE_P_NULL_ERR;
    }

    for(uint8_t i = 0; i < ADC_FILTER_NUM; i++)
    {
        // 保证adc已经采样ok
        adc_code_traversal_get();
    }
    uint32_t *p_gain_addr = &p_adjust_para_tab->adjust_para_gain[adjust_para_type];
    adc_sample_cali_para_t cali_para = {
        .adc_value = ADC_CODE_VAL_INVAILD,
        .offset_adc_value = ADC_CODE_VAL_INVAILD
    };
    int32_t ret = sample_adjust_cali_para_get(adjust_para_type, &cali_para);
    if (ret != SAMPLE_OK)
    {
        return ret;
    }
    if (ADC_CODE_VAL_INVAILD == cali_para.adc_value || ADC_CODE_VAL_INVAILD == cali_para.offset_adc_value ||
        cali_para.adc_value == cali_para.offset_adc_value)
    {
        return SAMPLE_ADC_INVAILD_ERR;
    }
    uint64_t cali_mul_gain_value = (uint64_t)cali_value * (uint64_t)cali_para.gain_value;
    uint32_t real_gain_value = (uint32_t)(cali_mul_gain_value / cali_para.divisor_value / (cali_para.adc_value - cali_para.offset_adc_value));
    if (real_gain_value < cali_para.min_cali_value || real_gain_value > cali_para.max_cali_value)
    {
        log_e("[SAM]cali=%ld,gain=%d\n", cali_value, cali_para.gain_value);
        log_e("[SAM]divisor=%ld,adc=%d,offAdc=%d\n", cali_para.divisor_value, cali_para.adc_value, cali_para.offset_adc_value);
        log_e("[SAM]realGa=%ld,minCali=%d,maxCali=%d\n", real_gain_value, cali_para.min_cali_value, cali_para.max_cali_value);
        return SAMPLE_OVER_PARA_ERR;
    }
    *p_gain_addr = real_gain_value;
    return SAMPLE_OK;
}

/**
* @brief    校准参数计算
* @param    [in] adjust_para_tab_e adjust_para_type 校准参数类型
* @param        [in]uint32_t cali_value 校准值
* -# 电流值      单位10mA  
* -# 电压值      单位0.1V
* @param        [in]adjust_para_tab_t *adjust_para_tab 校准结果值为校准参数结构体中的一个成员变量
* @return    返回结果
* @retval      [out] ret(0)  校准计算成功
* @retval      [out] ret(-1) 空指针校准计算失败
* @retval      [out] ret(-2)  校准增益超出范围或校准类型无效计算失败
* @retval      [out] ret(-3)  adc采样无效计算失败
* @retval      [out] ret(-4)  没有进入标定模式
* @warning
*/
int32_t sample_adjust_cali_deal(adjust_para_tab_e adjust_para_type,uint32_t cali_value, adjust_para_tab_t *p_adjust_para_tab)
{
    if (!special_mode_get(CALI_PARM))
    {
        return SAMPLE_NO_CALI_MODE_ERR;
    }
    
    return sample_adjust_cali(adjust_para_type, cali_value, p_adjust_para_tab);
}
/**
* @brief                采样校准参数设置
* @param                [in]adjust_para_tab_t *p_adjust_para_tab 校准参数表结构体
* @return               返回结果
* @retval               [out]ret(0)  设置成功
* @retval               [out]ret(-1) 设置失败
* @warning              无
*/
int32_t sample_adjust_set(adjust_para_tab_t *p_adjust_para_tab)
{
    int32_t ret = 0;
    if(NULL == p_adjust_para_tab)        // 指针为空 返回设置失败
    {
        ret = -1;
        return ret;
    }
    adc_sample_cali_para_t cali_para = {0};
    for (uint16_t gain_para_index = 0; gain_para_index < ADJUST_PARA_NUM; gain_para_index++)
    {
         ret = sample_adjust_cali_para_get((adjust_para_tab_e)gain_para_index, &cali_para);
         if (SAMPLE_OK != ret)
         {
             ret = -1;
             break;
         }
         if (p_adjust_para_tab->adjust_para_gain[gain_para_index] < cali_para.min_cali_value ||
             p_adjust_para_tab->adjust_para_gain[gain_para_index] > cali_para.max_cali_value)
         {
             ret = -1;  // 若有增益超出范围 则返回设置失败
             break;
         }
    }
    if (0 == ret)
    {
         memcpy(&g_adjust_para_tab, p_adjust_para_tab, sizeof(adjust_para_tab_t));  // 设置校准参数
    }
     return ret;
}

/**
 * @brief                ntc异常判断
 * @param                [in]res_value        需要判断的电阻值
 * @param                [in]res_temp_table   需要查的表格
 * @param                [in]table_size       表格元素个数
 * @return               返回结果
 * @retval               [out]ret(SAMPLE_STATE_OK)  获取采集状态成功
 * @retval               [out]ret(SAMPLE_STATE_EOI) 获取采集状态失败
 * @retval               [out]ret(NTC_SHORT_CIRCUIT) NTC短路
 * @retval               [out]ret(NTC_OPEN_CIRCUIT)  NTC开路
 * @retval               [out]ret(AFE_ERR)           AFE异常
 * @warning              在采集任务开始以后调用
 */
int32_t sample_res_ntc_abnormal_judge(uint16_t res_value, const uint16_t *p_res_temp_table, uint16_t table_size)
{
    if (NULL == p_res_temp_table || 0 == table_size)
    {
        log_e("samTableErr\n");
        return SAMPLE_STATE_EOI;
    }
    int ret = SAMPLE_STATE_OK;
    if(res_value > p_res_temp_table[0])  //开路
    {
        ret = NTC_OPEN_CIRCUIT_ERR;
    }
    else if(res_value < p_res_temp_table[table_size - 1]) //短路
    {
        ret = NTC_SHORT_CIRCUIT_ERR;
    }
    return ret;
}

/**
 * @brief                采样异常状态获取
 * @param                [in]abnormal_type_e
 * @return     返回结果
 * @retval     [out]ret(SAMPLE_STATE_OK)  获取采集状态成功
 * @retval     [out]ret(SAMPLE_STATE_EOI) 获取采集状态失败
 * @retval     [out]ret(NTC_SHORT_CIRCUIT) NTC短路
 * @retval     [out]ret(NTC_OPEN_CIRCUIT)  NTC开路
 * @retval     [out]ret(AFE_ERR)           AFE异常
 * @warning    在采集任务开始以后调用
 */
int32_t sample_abnormal_get(abnormal_type_e type)
{
    int32_t ret = SAMPLE_STATE_OK;

    switch(type)
    {
        case LOAD_P_NTC_ERR:
            ret = sample_res_ntc_abnormal_judge(g_ntc_res[LOAD_P_TEMP], ntc_res_table, TEMP_TABLE_SIZE);
            break;
        case LOAD_N_NTC_ERR:
            ret = sample_res_ntc_abnormal_judge(g_ntc_res[LOAD_N_TEMP], ntc_res_table, TEMP_TABLE_SIZE);
            break;
        case BAT_P_NTC_ERR:
            ret = sample_res_ntc_abnormal_judge(g_ntc_res[BAT_P_TEMP], ntc_res_table, TEMP_TABLE_SIZE);
            break;
        case BAT_N_NTC_ERR:
            ret = sample_res_ntc_abnormal_judge(g_ntc_res[BAT_N_TEMP], ntc_res_table, TEMP_TABLE_SIZE);
            break;
        case PCB_NTC_ERR:
            ret = sample_res_ntc_abnormal_judge(g_ntc_res[PCB_TEMP], ntc_res_table, TEMP_TABLE_SIZE);
            break;
        default:
            ret = SAMPLE_STATE_EOI;
            break;
    }
    return ret;
}

//static void current_sample(void)
//{
//    int32_t curr = 0;
//    static uint8_t first_flag = true; // 默认置位
//    
//    if ((REF_VOLT_5V_DOWN_LIMIT > g_sample_data.hall_5v_volt) || (REF_VOLT_5V_UP_LIMIT < g_sample_data.hall_5v_volt))
//    {
//        //TO DO 补充逻辑收到can报文则用can霍尔电流，否则继续用ad霍尔，报出故障
//        g_sample_data.sys_current = g_pack_other_device_info.hall_data[0] | (g_pack_other_device_info.hall_data[0] << 8) |
//                                    (g_pack_other_device_info.hall_data[0] << 16) | (g_pack_other_device_info.hall_data[0] << 24); // Mmodify

//        return;
//    }
//    
//    if (ADC_CODE_VAL_INVAILD != g_adc_code_buff[SDK_ADC_HALL_IN1])
//    {
//        g_sample_data.hall_large_cur = g_adjust_para_tab.adjust_para_gain[CURR_LARGE_GAIN]*(g_adc_code_buff[SDK_ADC_HALL_IN1] - g_sample_data.hall_large_offset)/SAMPLE_CURR_MAGNIFICATION ;
//    }
//    if (ADC_CODE_VAL_INVAILD != g_adc_code_buff[SDK_ADC_HALL_IN2])
//    {
//        g_sample_data.hall_small_cur = g_adjust_para_tab.adjust_para_gain[CURR_SMALL_GAIN]*(g_adc_code_buff[SDK_ADC_HALL_IN2] - g_sample_data.hall_small_offset)/SAMPLE_CURR_MAGNIFICATION ;
//    }    
//    
//    if(abs(g_sample_data.hall_large_cur) > LARGE_CUR_RANGE)
//    {
//        curr = g_sample_data.hall_large_cur;
//    }
//    else if(abs(g_sample_data.hall_small_cur) < LITTLE_CUR_RANGE)
//    {
//        curr = g_sample_data.hall_small_cur;
//    }
//    else
//    {
//        curr = (g_sample_data.hall_small_cur + g_sample_data.hall_large_cur) / 2;   //取平均值
//    }
//    
////    g_sample_data.sys_current = curr;
//    // 一阶滤波处理
//    if (first_flag)
//    {
//        first_flag = false;               // 清除标志
//        g_sample_data.sys_current = curr; // 第一次计算，直接赋值
//    }
//    else
//    {
//        // 一阶滤波，刷新电流值
//        g_sample_data.sys_current = ((EXT_CURR_FIRST_FILTER_MAX_K - EXT_CURR_FIRST_FILTER_K_B10) * g_sample_data.sys_current +
//                                     EXT_CURR_FIRST_FILTER_K_B10 * (curr)) / EXT_CURR_FIRST_FILTER_MAX_K + EXT_CURR_FIRST_FILTER_K_B10;
//    }


//}


// 函数：计算平均滤波后的值
static int32_t average_filter(int32_t data[], int32_t size) {
    int32_t sum = 0;
    for (int32_t i = 0; i < size; i++) {
        sum += data[i];
    }
    return (int32_t)sum / size;
}

/**
* @brief                电流计算
* @param                [in]无
* @return               返回结果空
* @retval               [out]无
* @warning              无
*/
#define AVE_CNT     50
static void current_sample(void)
{
    int32_t curr = 0;
    static uint8_t first_flag = true; // 默认置位
    static int32_t hall_5v_buf[AVE_CNT] = {0};
    static int32_t hall_cur_buf[AVE_CNT] = {0};
    static uint16_t ring_buf_cnt = 0;
    
    // 产测过程只算电压
    if (special_mode_get(ATUO_TEST))
    {
        g_sample_data.hall_large_volt = (uint32_t)((uint64_t)g_adc_code_buff[SDK_ADC_HALL_IN1]  * REF_VOLT * 2 / INNER_ADC_RESOLUTION);
        g_sample_data.hall_small_volt = (uint32_t)((uint64_t)g_adc_code_buff[SDK_ADC_HALL_IN2]  * REF_VOLT * 2 / INNER_ADC_RESOLUTION);
        return;
    }
                            
    if (ADC_CODE_VAL_INVAILD != g_adc_code_buff[SDK_ADC_HALL_IN1])
    {
        g_sample_data.hall_large_volt = (g_adc_code_buff[SDK_ADC_HALL_IN1] - g_sample_data.hall_large_offset) * REF_VOLT * 2 / INNER_ADC_RESOLUTION;
    }
    if (ADC_CODE_VAL_INVAILD != g_adc_code_buff[SDK_ADC_HALL_IN2])
    {
        g_sample_data.hall_small_volt = (g_adc_code_buff[SDK_ADC_HALL_IN2] - g_sample_data.hall_small_offset) * REF_VOLT * 2 / INNER_ADC_RESOLUTION;
    }
    
        // Vo(2.5) + I * S = 5 / Vc(5.0) * Vout;
    g_sample_data.hall_large_cur = (int64_t)(HALL_REF_VOLT * g_sample_data.hall_large_volt - HALL_REF_VOLT / 2 * g_sample_data.hall_5v_volt_avg) * 1000 * 100 / get_bms_attr()->adjust.adjust_para_gain[CURR_LARGE_GAIN] / g_sample_data.hall_5v_volt_avg;
    g_sample_data.hall_small_cur = (int64_t)(HALL_REF_VOLT * g_sample_data.hall_small_volt - HALL_REF_VOLT / 2 * g_sample_data.hall_5v_volt_avg) * 1000 * 100 / get_bms_attr()->adjust.adjust_para_gain[CURR_SMALL_GAIN] / g_sample_data.hall_5v_volt_avg;

//    if(abs(g_sample_data.hall_large_cur) > LARGE_CUR_RANGE)
//    {
//        curr = g_sample_data.hall_large_cur;
//    }
//    else if(abs(g_sample_data.hall_small_cur) < LITTLE_CUR_RANGE)
//    {
//        curr = g_sample_data.hall_small_cur;
//    }
//    else
//    {
//        curr = (g_sample_data.hall_small_cur + g_sample_data.hall_large_cur) / 2;   //取平均值
//    }
    
   if(((abs(g_sample_data.hall_small_cur) > CUR_RANGE) || (abs(g_sample_data.hall_large_cur) > CUR_RANGE))
       && (abs(g_sample_data.hall_large_cur) > abs(g_sample_data.hall_small_cur)))
   {
       g_sample_data.hall_cur = g_sample_data.hall_large_cur;
   }
   else
   {
       g_sample_data.hall_cur = g_sample_data.hall_small_cur;
   }
    
    
    
    // if (ADC_CODE_VAL_INVAILD != g_adc_code_buff[SDK_ADC_HALL_IN1])
    // {
    //     g_sample_data.hall_large_volt = (g_adc_code_buff[SDK_ADC_HALL_IN1] - g_sample_data.hall_large_offset) * REF_VOLT * 2 / INNER_ADC_RESOLUTION;
    // }
    // g_sample_data.hall_large_cur = (int64_t)(HALL_REF_VOLT * g_sample_data.hall_large_volt - HALL_REF_VOLT / 2 * g_sample_data.hall_5v_volt_avg) * 1000 * 3 / 4 / g_sample_data.hall_5v_volt_avg ;
    //g_sample_data.hall_cur =   g_sample_data.hall_large_cur;
    if (g_pack_other_device_info.called && (!g_pack_other_device_info.error_information) && (FAULT_STOP == fault_state_get(BOARD_CAN_HALL_SENSOR_COMM_FAULT)))
    {
        curr = g_pack_other_device_info.hall_data_deal; 
    }
    else
    {
        curr = g_sample_data.hall_cur;
    }
    
    
     

    // 一阶滤波处理
    if (first_flag)
    {
        first_flag = false;               // 清除标志
        g_sample_data.sys_current = curr; // 第一次计算，直接赋值
        g_sample_data.hall_5v_volt_avg = g_sample_data.hall_5v_volt;
        memset(hall_5v_buf, g_sample_data.hall_5v_volt_avg, sizeof(hall_5v_buf));
        memset(hall_cur_buf, g_sample_data.sys_current, sizeof(hall_cur_buf));
    }
    else
    {
//        hall_5v_avg = ((EXT_CURR_FIRST_FILTER_MAX_K - EXT_CURR_FIRST_FILTER_K_B10) * hall_5v_avg +
//                                     EXT_CURR_FIRST_FILTER_K_B10 * (g_sample_data.hall_5v_volt)) / EXT_CURR_FIRST_FILTER_MAX_K + EXT_CURR_FIRST_FILTER_K_B10;

//        // 一阶滤波，刷新电流值
//        g_sample_data.sys_current = ((EXT_CURR_FIRST_FILTER_MAX_K - EXT_CURR_FIRST_FILTER_K_B10) * g_sample_data.sys_current +
//                                     EXT_CURR_FIRST_FILTER_K_B10 * (curr)) / EXT_CURR_FIRST_FILTER_MAX_K + EXT_CURR_FIRST_FILTER_K_B10;
        
        hall_5v_buf[ring_buf_cnt] = g_sample_data.hall_5v_volt;
        hall_cur_buf[ring_buf_cnt] = curr;
        if(++ring_buf_cnt >= AVE_CNT)
        {
            ring_buf_cnt = 0;
        }

        g_sample_data.hall_5v_volt_avg = average_filter(hall_5v_buf,AVE_CNT);
        g_sample_data.sys_current = average_filter(hall_cur_buf,AVE_CNT);
    }
}

/**
* @brief                电压采集
* @param                [in]无
* @return               返回结果空
* @retval               [out]无
* @warning              无
*/
static void volt_sample(void)
{
    // 注意：不要越界
    // 母线总压
    if (ADC_CODE_VAL_INVAILD != g_adc_code_buff[SDK_ADC_BAT_VOLT])
    {
        if (0 > g_adc_code_buff[SDK_ADC_BAT_VOLT])
        {
            g_adc_code_buff[SDK_ADC_BAT_VOLT] = 0;
        }
        g_sample_data.bus_volt = (uint32_t)((uint64_t)g_adjust_para_tab.adjust_para_gain[BUS_VOLT_GAIN] * SAMPLE_VOLT_SOFEWARE_GAIN /
                                            EXT_ADC_RESOLUTION * g_adc_code_buff[SDK_ADC_BAT_VOLT] / SAMPLE_VOLT_SOFEWARE_GAIN);
    }

    // 负载总压
    if (ADC_CODE_VAL_INVAILD != g_adc_code_buff[SDK_ADC_LOAD_VOLT])
    {
        if (0 > g_adc_code_buff[SDK_ADC_LOAD_VOLT])
        {
            g_adc_code_buff[SDK_ADC_LOAD_VOLT] = 0;
        }
        g_sample_data.load_volt = (uint32_t)((uint64_t)g_adjust_para_tab.adjust_para_gain[LOAD_VOLT_GAIN] * SAMPLE_VOLT_SOFEWARE_GAIN /
                                             EXT_ADC_RESOLUTION * g_adc_code_buff[SDK_ADC_LOAD_VOLT] / SAMPLE_VOLT_SOFEWARE_GAIN);
    }

    // 绝缘阻抗电压
    if (ADC_CODE_VAL_INVAILD != g_adc_code_buff[SDK_ADC_ISO_VOLT])
    {
        if (0 > g_adc_code_buff[SDK_ADC_ISO_VOLT])
        {
            g_adc_code_buff[SDK_ADC_ISO_VOLT] = 0;
        }
        g_sample_data.insulation_res_volt = (uint32_t)((uint64_t)g_adc_code_buff[SDK_ADC_ISO_VOLT] * EXT_ADS_REF_VOLT * 50000 / 150 / EXT_ADC_RESOLUTION);
    }

    // 供电电源24V采集
    if (ADC_CODE_VAL_INVAILD != g_adc_code_buff[SDK_ADC_24V_SUP])
    {
        if (0 > g_adc_code_buff[SDK_ADC_24V_SUP])
        {
            g_adc_code_buff[SDK_ADC_24V_SUP] = 0;
        }
        g_sample_data.power_24v_volt = (uint32_t)((uint64_t)g_adc_code_buff[SDK_ADC_24V_SUP] * REF_VOLT * 1091 / 91 / INNER_ADC_RESOLUTION);
    }

    // 系统5V电源采集(霍尔)
    if (ADC_CODE_VAL_INVAILD != g_adc_code_buff[SDK_ADC_5V_SUP])
    {
        if (0 > g_adc_code_buff[SDK_ADC_5V_SUP])
        {
            g_adc_code_buff[SDK_ADC_5V_SUP] = 0;
        }
        g_sample_data.hall_5v_volt = (uint32_t)((uint64_t)g_adc_code_buff[SDK_ADC_5V_SUP] * REF_VOLT * 20 / 10 / INNER_ADC_RESOLUTION);
    }
    
    // 输出12V电源采集
    if (ADC_CODE_VAL_INVAILD != g_adc_code_buff[SDK_ADC_12V_SUP])
    {
        if (0 > g_adc_code_buff[SDK_ADC_12V_SUP])
        {
            g_adc_code_buff[SDK_ADC_12V_SUP] = 0;
        }
        g_sample_data.power_12v_volt = (uint32_t)((uint64_t)g_adc_code_buff[SDK_ADC_12V_SUP] * REF_VOLT * 43 / 10 / INNER_ADC_RESOLUTION);
    }  

    // out3电压采集
    if (ADC_CODE_VAL_INVAILD != g_adc_code_buff[SDK_ADC_HALL_IN3])
    {
        if (0 > g_adc_code_buff[SDK_ADC_HALL_IN3])
        {
            g_adc_code_buff[SDK_ADC_HALL_IN3] = 0;
        }
        g_sample_data.out3_volt = (uint32_t)((uint64_t)g_adc_code_buff[SDK_ADC_HALL_IN3]  * REF_VOLT * 2 / INNER_ADC_RESOLUTION);
    }     
}
/**
 * @brief                硬件版本识别
 * @param                [in]无
 * @return               返回结果空
 * @retval               [out]无
 * @warning              无
 */
static void hardware_version_sample(void)
{
    static int16_t last_ver = -1;
    // 版本电压
    if (ADC_CODE_VAL_INVAILD != g_adc_code_buff[SDK_ADC_HW_VER])
    {
        g_sample_data.hardware_version_volt = (uint32_t)(g_adc_code_buff[SDK_ADC_HW_VER] * REF_VOLT / INNER_ADC_RESOLUTION); // 单位1mv
        if (last_ver == -1)
        {
            last_ver = hardware_ver_get();
        }
    }
}

/**
 * @brief                上电待机获取电流零点初始AD值
 * @param                [in]无
 * @return               [out] 返回结果
 * @retval               = 0 成功
 * @retval               < 0 失败
 * @warning              必须确保片内adc已经完成采样
 */
static int32_t zero_offset_adc_get(void)
{
    int32_t ret = SAMPLE_OK;
    static uint16_t filter_timer = 0;
    static int32_t hall_adj = 0;

    if (filter_timer < SAMPLE_1000MS_TIME)
    {
        ret = SAMPLE_ADC_INVAILD_ERR;
        adc_code_traversal_get();
        if ((ADC_CODE_VAL_INVAILD != g_adc_code_buff[SDK_ADC_HALL_IN1])
            && (ADC_CODE_VAL_INVAILD != g_adc_code_buff[SDK_ADC_HALL_IN2]))
        {
            g_sample_data.hall_large_offset += g_adc_code_buff[SDK_ADC_HALL_IN1];   
            g_sample_data.hall_small_offset += g_adc_code_buff[SDK_ADC_HALL_IN2];
            hall_adj += g_adc_code_buff[SDK_ADC_5V_SUP];
            filter_timer++;            
        }

    }
    else
    {
        g_sample_data.hall_large_offset /= SAMPLE_1000MS_TIME;
        g_sample_data.hall_small_offset /= SAMPLE_1000MS_TIME;
        hall_adj = hall_adj / SAMPLE_1000MS_TIME / 2;
        
        g_sample_data.hall_large_offset -= hall_adj;
        g_sample_data.hall_small_offset -= hall_adj;
    }
    

    return ret;
}

/**
 * @brief      更新所有模拟量
 * @warning    
 */
void sample_value_traversal_get(void)
{
#ifdef APP_BCU_SAMPLE_TEST
    if (g_app_sample_value_debug_flag)
    {
        return;
    }
#endif
    other_device_sample();      // 其他设备数据采集
    other_temp_sample();        // 计算其他温度值
    current_sample();           // 换算电流值
    volt_sample();              // 换算电压值
    hardware_version_sample();  // 硬件版本号识别
}

/**
 * @brief                电池采样任务
 * @param                [in]void
 * @return               返回结果空
 * @retval               [out]无
 * @warning              放在10ms任务，必须要调用sample_data_init()后使用
 */
void sample_proc(void)
{
    int32_t ret = SAMPLE_OK;
    
    switch ((uint16_t)g_sample_process)
    {
        case SAMPLE_INIT:
            if (g_sample_enable_flag)
            {
                sample_process_state_set(SAMPLE_ZERO_OFFSET);
            }
            break;
        case SAMPLE_ZERO_OFFSET: // 上电获取大/小电流零点初始AD值
            ret = zero_offset_adc_get();
            sample_value_traversal_get();
            if (SAMPLE_OK == ret)
            {
                sample_process_state_set(SAMPLE_IN_WROKING);
            }
            break;
        case SAMPLE_IN_WROKING:
            adc_code_traversal_get();
            sample_value_traversal_get();
            break;
        default:
            sample_process_state_set(SAMPLE_INIT);
            break;
    }
}

/**
* @brief                获取电池采样信息指针
* @param                [in]bat_sample_data_t *p_data 电池采样数据结构体指针
* @return               返回结果
* @retval               ret(-1)获取失败
* @retval               ret(0)获取成功
* @warning              无
*/
const sample_data_t* p_sample_data_get(void)
{
    return (const sample_data_t*)&g_sample_data;
}

/**
 * @brief                获取硬件版本号
 * @param                [in]无
 * @return               [out] void
 * @warning              必须确保片内adc已经完成采样
 */
int16_t hardware_ver_get(void)
{
    int16_t ver = 0;
    int16_t temp_ver = 0;

    if (0 == g_sample_data.hardware_version_volt)
    {
        return -1;
    }
    if (g_sample_data.hardware_version_volt < HW_VER_CD_VOLT)
    {
        ver = g_sample_data.hardware_version_volt / 300;
    }
    else
    {
        ver = (g_sample_data.hardware_version_volt + HW_VER_CAL_VOLT) / 300;
    }

    if (temp_ver != ver)
    {
        temp_ver = ver;
        SAMPLE_LOGD("[HW_VER]: %d...\n", ver);
    }

    return ver;
}

#ifdef APP_BCU_SAMPLE_TEST

typedef enum
{
    DEBUG_VAL_CURR = 0,    ///< 系统电流 1mA
    DEBUG_VAL_BAT_P_TEMP,  ///< 母线正极温度,需提供NTC表 单位0.1℃
    DEBUG_VAL_BAT_N_TEMP,  ///< 母线负极温度,需提供NTC表 单位0.1℃
    DEBUG_VAL_LOAD_P_TEMP, ///< 负载正极温度,需提供NTC表 单位0.1℃
    DEBUG_VAL_LOAD_N_TEMP, ///< 负载负极温度,需提供NTC表 单位0.1℃
    DEBUG_VAL_PCB_TEMP,    ///< PCB温度采集
    DEBUG_VAL_24V_VOLT,    ///< 24V电压检测 单位1mV
    DEBUG_VAL_5V_VOLT,     ///< 5V电压检测 单位1mV
    DEBUG_VAL_VER_VOLT,    ///< 硬件版本号识别 单位1mV
    DEBUG_VAL_BUS_VOLT,    ///< 母线总压  单位1mV
    DEBUG_VAL_LOAD_VOLT,   ///< 负载  单位1mV
    DEBUG_VAL_RES_VOLT,    ///< 绝缘电阻电压  单位1mV
    DEBUG_VAL_NUM,
} sample_value_debug_e;

/**
 * @brief        设置模拟量debug
 * @param        [in] debug_flag 模拟量debug标志， 1：debug 0:normal
 * @param        [in] data_type 模拟量debug标志， 1：debug 0:normal
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
void sample_value_set_debug(uint32_t debug_flag, uint8_t data_type, int32_t value)
{
    if (!debug_flag)
    {
        return;
    }
    switch (data_type)
    {
    case DEBUG_VAL_CURR:
        g_sample_data.sys_current = value;
        break;
    case DEBUG_VAL_BAT_P_TEMP:
        g_sample_data.adc_sample_other_temp[BAT_P_TEMP] = value;
        break;
    case DEBUG_VAL_BAT_N_TEMP:
        g_sample_data.adc_sample_other_temp[BAT_N_TEMP] = value;
        break;
    case DEBUG_VAL_LOAD_P_TEMP:
        g_sample_data.adc_sample_other_temp[LOAD_P_TEMP] = value;
    case DEBUG_VAL_LOAD_N_TEMP:
        g_sample_data.adc_sample_other_temp[LOAD_N_TEMP] = value;
        break;
    case DEBUG_VAL_PCB_TEMP:
        g_sample_data.adc_sample_other_temp[PCB_TEMP] = value;
        break;
    case DEBUG_VAL_24V_VOLT:
        g_sample_data.power_24v_volt = value;
    case DEBUG_VAL_5V_VOLT:
        g_sample_data.hall_5v_volt = value;
        break;
    case DEBUG_VAL_VER_VOLT:
        g_sample_data.hardware_version_volt = value;
        break;
    case DEBUG_VAL_BUS_VOLT:
        g_sample_data.bus_volt = value;
        break;
    case DEBUG_VAL_LOAD_VOLT:
        g_sample_data.load_volt = value;
        break;
    case DEBUG_VAL_RES_VOLT:
        g_sample_data.insulation_res_volt = value;
        break;
    default:
        SAMPLE_LOGD("sam_t set val type over err\r\n");
        break;
    }
}

// 打印模拟量和码值，校准参数
void sample_debug_printf(void)
{
    SAMPLE_LOGD("sys_cur: %d\n", g_sample_data.sys_current);
    SAMPLE_LOGD("can_hall cur: %d\n", g_pack_other_device_info.hall_data_deal);
    SAMPLE_LOGD("bat_volt: %d\tad: %d...\n", g_sample_data.bus_volt,g_adc_code_buff[SDK_ADC_BAT_VOLT]);
    SAMPLE_LOGD("load_volt: %d\tad: %d...\n", g_sample_data.load_volt,g_adc_code_buff[SDK_ADC_LOAD_VOLT]);
    SAMPLE_LOGD("iso_volt: %d\tad: %d...\n", g_sample_data.insulation_res_volt,g_adc_code_buff[SDK_ADC_ISO_VOLT]);
    SAMPLE_LOGD("24_volt: %d\tad: %d...\n", g_sample_data.power_24v_volt, g_adc_code_buff[SDK_ADC_24V_SUP]);
    SAMPLE_LOGD("5_volt: %d\tad: %d\tavg:%d...\n", g_sample_data.hall_5v_volt, g_adc_code_buff[SDK_ADC_5V_SUP],g_sample_data.hall_5v_volt_avg);
    SAMPLE_LOGD("12_volt: %d\tad: %d...\n", g_sample_data.power_12v_volt, g_adc_code_buff[SDK_ADC_12V_SUP]);
    SAMPLE_LOGD("hw_volt: %d\tad: %d...\n", g_sample_data.hardware_version_volt, g_adc_code_buff[SDK_ADC_HW_VER]);
    SAMPLE_LOGD("LOAD_P_TEMP: %d\tad: %d...\n", g_sample_data.adc_sample_other_temp[LOAD_P_TEMP], g_adc_code_buff[SDK_ADC_LOAD_P_TEMP]);
    SAMPLE_LOGD("LOAD_N_TEMP: %d\tad: %d...\n", g_sample_data.adc_sample_other_temp[LOAD_N_TEMP], g_adc_code_buff[SDK_ADC_LOAD_N_TEMP]);
    SAMPLE_LOGD("BAT_P_TEMP: %d\tad: %d...\n", g_sample_data.adc_sample_other_temp[BAT_P_TEMP], g_adc_code_buff[SDK_ADC_BAT_P_TEMP]);
    SAMPLE_LOGD("BAT_N_TEMP: %d\tad: %d...\n", g_sample_data.adc_sample_other_temp[BAT_N_TEMP], g_adc_code_buff[SDK_ADC_BAT_N_TEMP]);
    SAMPLE_LOGD("RSV_1_TEMP: %d\tad: %d...\n", g_sample_data.adc_sample_other_temp[TEMP_RSV_1], g_adc_code_buff[SDK_ADC_TEMP_RSV_1]);    
    SAMPLE_LOGD("RSV_2_TEMP: %d\tad: %d...\n", g_sample_data.adc_sample_other_temp[TEMP_RSV_2], g_adc_code_buff[SDK_ADC_TEMP_RSV_2]);       
    SAMPLE_LOGD("pcb_temp: %d\t  ad: %d...\n", g_sample_data.adc_sample_other_temp[PCB_TEMP], g_adc_code_buff[SDK_ADC_PCB_TEMP]);
    SAMPLE_LOGD("hall large volt :%d  cur:%d  ad:%d\n", g_sample_data.hall_large_volt,g_sample_data.hall_large_cur,g_adc_code_buff[SDK_ADC_HALL_IN1]);
    SAMPLE_LOGD("hall small volt :%d  cur:%d  ad:%d\n", g_sample_data.hall_small_volt,g_sample_data.hall_small_cur,g_adc_code_buff[SDK_ADC_HALL_IN2]);
    SAMPLE_LOGD("l_cur_offset:%d,s_cur_offset:%d,l_cur_k:%d,s_cur_k:%d\n",g_sample_data.hall_large_offset,g_sample_data.hall_small_offset,g_adjust_para_tab.adjust_para_gain[CURR_LARGE_GAIN],g_adjust_para_tab.adjust_para_gain[CURR_SMALL_GAIN]);

}

void sample_debug_help_printf(void)
{
    SAMPLE_LOGD("sample print...\n");
    SAMPLE_LOGD("sample val debug_flag val_id value...\n");
}

/**
 * @brief        sample_debug功能样例
 * @param        cmd 功能参数
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
static int sample(int argc, char *argv[])
{
    if (argc < 2)
    {
        log_d("samParaErr\n");
        return SF_ERR_PARA;
    }
    if (!strcmp(argv[1], "print"))
    {
        sample_debug_printf();
    }
    else if (!strcmp(argv[1], "init"))
    {

    }
    else if (!strcmp(argv[1], "eget"))
    {
        if (argc < 3)
        {
            log_d("samErrGetParaErr\n");
            return SF_ERR_PARA;
        }
        uint32_t type = atoi(argv[2]); //解析第2个参数名称
        if (type >= OTHER_NTC_ERR_NUM)
        {
            log_d("samErrGetTypeOverErr\n");
            return SF_ERR_PARA;
        }
        log_d("samAbGet[%ld]=%ld\n",type, sample_abnormal_get((abnormal_type_e)type));    
    }
    else if (!strcmp(argv[1], "cali"))
    {
        if (argc < 4)
        {
            log_d("samCaliParaErr\n");
            return SF_ERR_PARA;
        }        
        uint32_t type = atoi(argv[2]);  // 解析第2个参数名称, 校准类型， 
        uint32_t val = atoi(argv[3]);   // 解析第3个参数名称,校准数值（电流值      单位10mA  ；电压值      单位0.1V）
        int ret = sample_adjust_cali((adjust_para_tab_e)type, val, &g_adjust_para_tab);
        if(SAMPLE_OK == ret)
        {
            //ret = sample_adjust_set(&g_adjust_para_tab);
            if(SAMPLE_OK == ret)
            {
                data_store_save_adjust_para(&g_adjust_para_tab);
            }
        }        
        log_d("samAdjustCaliRet=%ld\n",ret);
    }
    else if (!strcmp(argv[1], "code"))
    {
        if (argc < 5)
        {
            log_d("samCodeParaErr\n");
            return SF_ERR_PARA;
        }
        uint32_t debug_flag = atoi(argv[2]); // 参数1：debug标志（1使能，0取消），
        uint32_t adc_id = atoi(argv[3]);     // 参数2：码值(sdk_adc_sample_index_e)
        int32_t value = atoi(argv[4]);       // 参数3：code值
        g_app_sample_code_debug_flag = debug_flag;
        if (adc_id >= SDK_ADC_MAX)
        {
             log_d("samDebugFlag(0~1) AdcIdVal:adjustTypeOver\n");
             return SF_ERR_PARA;
        }
        g_adc_code_buff[adc_id] = (uint16_t)value;
    }
    else if (!strcmp(argv[1], "val"))
    {
        if (argc < 5)
        {
            log_d("samValParaErr\n");
            return SF_ERR_PARA;
        }
        uint32_t debug_flag = atoi(argv[2]);  // 设置参数1：debug标志（1使能，0取消）
        uint32_t val_id = atoi(argv[3]);      // 参数2: 模拟量sample_value_debug_e
        int32_t value = atoi(argv[4]);        // 参数3：value值
        g_app_sample_value_debug_flag = debug_flag;
        sample_value_set_debug(debug_flag, val_id, value);
    }
    else if (!strcmp(argv[1], "help"))
    {
        sample_debug_help_printf();
    }
    else
    {
        return SF_ERR_PARA;
    }
    return SF_OK; 
}

MSH_CMD_EXPORT(sample, <print/init/eget type/cali type value/val(code) debug(0-1) id value>);

/**
 * @brief        curr_adj
 * @param        cmd 功能参数
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
#define TIME_CNT 50
static int curr_adj(int argc, char *argv[])
{
    static uint32_t timestamp = 0;
    static int32_t large_adj_temp = 0;
    static int32_t small_adj_temp = 0;
    int32_t curr_k = 0;
    uint8_t cnt = 0;
    int32_t tmp = 0;
	timestamp = sdk_tick_get();
    
    if (argc < 3)
    {
        log_d("cur_adj para err\n");
        return SF_ERR_PARA;
    }
    if (!strcmp(argv[1], "small"))
    {
        int32_t cur = atoi(argv[2]); //解析第2个参数名称,mA/bit
        small_adj_temp = 0;
        os_delay(TICK_1S);  //先等待电流稳定

        while(cnt < TIME_CNT || sdk_is_tick_over(timestamp, os_tick_from_millisecond(10*1000))) // 次数累加够50次，或者10S超时
        {
            if (ADC_CODE_VAL_INVAILD != g_adc_code_buff[SDK_ADC_HALL_IN2])
            {
                tmp = g_adc_code_buff[SDK_ADC_HALL_IN2] - g_sample_data.hall_small_offset;
                small_adj_temp += tmp;     
                cnt++;
            }
            os_delay(TICK_100MS);            
        }

        if(cnt == TIME_CNT) //取50次有效的结果做平均
        {
            small_adj_temp /= TIME_CNT;
            curr_k = (int64_t)(HALL_REF_VOLT * (small_adj_temp - g_sample_data.hall_small_offset) - HALL_REF_VOLT / 2 * g_sample_data.hall_5v_volt_avg) * 1000 * 100 / g_sample_data.hall_5v_volt_avg / cur;
            g_adjust_para_tab.adjust_para_gain[CURR_SMALL_GAIN] = curr_k;
            data_store_save_adjust_para(&g_adjust_para_tab);
            log_d("curr adj small k:%d,tmp:%d,cur:%d\n",curr_k,small_adj_temp,cur);
        }
        else
        {
            log_d("curr adj time out\n");            
        }

    }
    else if (!strcmp(argv[1], "large"))
    {
        int32_t cur = atoi(argv[2]); //解析第2个参数名称,mA/bit
        large_adj_temp = 0;
        os_delay(TICK_1S);  //先等待电流稳定

        while(cnt < TIME_CNT || sdk_is_tick_over(timestamp, os_tick_from_millisecond(10*1000))) // 次数累加够50次，或者10S超时
        {
            if (ADC_CODE_VAL_INVAILD != g_adc_code_buff[SDK_ADC_HALL_IN1])
            {
                tmp = g_adc_code_buff[SDK_ADC_HALL_IN1] - g_sample_data.hall_large_offset;
                large_adj_temp += tmp;     
                cnt++;
            }
            os_delay(TICK_100MS);            
        }

        if(cnt == TIME_CNT) //取50次有效的结果做平均
        {
            large_adj_temp /= TIME_CNT;
            curr_k = (int64_t)(HALL_REF_VOLT * (large_adj_temp - g_sample_data.hall_large_offset) - HALL_REF_VOLT / 2 * g_sample_data.hall_5v_volt_avg) * 1000 * 100 / g_sample_data.hall_5v_volt_avg / cur;
            g_adjust_para_tab.adjust_para_gain[CURR_LARGE_GAIN] = curr_k;
            data_store_save_adjust_para(&g_adjust_para_tab);
            log_d("curr adj large k:%d,tmp:%d,cur:%d\n",curr_k,large_adj_temp,cur);
        }
        else
        {
            log_d("curr adj time out\n");            
        }

    }
    return SF_OK; 
  
}
MSH_CMD_EXPORT(curr_adj, <small/large>);
#endif

