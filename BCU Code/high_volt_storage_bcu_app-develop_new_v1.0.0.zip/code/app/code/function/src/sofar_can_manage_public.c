#include "sofar_can_manage_public.h"
#include <stdio.h>
#include <string.h>
#include "sdk.h"


/*******************************************************************************
* Function Name  : Crc8_8210_nBytesCalculate
* Description    : CRC校验,多项式为0x2F
* Input          : 
* Output         : None
* Return         : None
*******************************************************************************/
static uint8_t crc8_8210_nbytes_calculate(uint8_t *p_buff , uint8_t len , uint8_t crs_mask)
{
    uint8_t i;
    for ( ; len > 0 ; len--)
    {
        for (i = 0x80 ; i > 0 ; i >>= 1)
        {
            if(0 != (crs_mask & 0x80))
            {
                crs_mask <<= 1;
                crs_mask ^= 0x2F;
            } 
            else
            {
                crs_mask <<= 1;
            }
            if(0 != (*p_buff & i))
            {
                crs_mask ^= 0x2F;
            }
        }
        p_buff ++;   
    }
    return crs_mask;
}

// 计算canId以及data0-6的数据crc8
uint8_t can_single_frame_crc8_calc(can_frame_data_t *can_data, uint8_t crs_mask)
{
#define SINGLE_CAN_FRAME_CRC_DATA_LEN  (11)
    uint8_t crc_data[SINGLE_CAN_FRAME_CRC_DATA_LEN] = {0};  // canid + data0-6 共11个字节
    crc_data[0] = can_data->id & 0xFF;
    crc_data[1] = (can_data->id >> 8) & 0xFF;
    crc_data[2] = (can_data->id >> 16) & 0xFF;
    crc_data[3] = (can_data->id >> 24) & 0xFF;
    crc_data[4] = can_data->data[0];
    crc_data[5] = can_data->data[1];
    crc_data[6] = can_data->data[2];
    crc_data[7] = can_data->data[3];
    crc_data[8] = can_data->data[4];
    crc_data[9] = can_data->data[5];
    crc_data[10] = can_data->data[6];
    return crc8_8210_nbytes_calculate(crc_data, SINGLE_CAN_FRAME_CRC_DATA_LEN, crs_mask);
}

/**
 * @brief   发送CAN数据打包发送
 * @param   [in] index  CAN 口编号
 * @param   [in] can_msg  CAN ID信息
 * @param   [in] p_data  需要发送的数据
 * @param   [in] len  需要发送的数据长度
 * @note    调用此函数之前需要APP层自己调用打开CAN的SDK接口
 * @return  返回执行结果 0:正常；<0:异常
 */
int32_t can_sofar_send_frame(uint32_t index, uint32_t can_id, uint8_t *p_data, int32_t len)
{
    if ((p_data == NULL) || (len < 0))
    {
        return (CAN_RET_PARA_ERR);
    }

    if (len > CAN_SOFAR_DATA_MAXNUMS)
    {
        return (CAN_RET_PARA_ERR);
    }
    can_frame_id_u can_frame_id = { 0 };
    sdk_can_frame_t txframe = {0};

    can_frame_id.id_val = can_id;
    txframe.id = (can_frame_id.id_val & 0x1fffffff); 

    txframe.ide = 1;    // 拓展帧
    txframe.hdr = -1;
    int32_t ret = SF_OK;
    // 单帧发送
    if (len <= CAN_SIGNAL_FRA_MAX_NUMS)
    {
        memcpy(&(txframe.data[0]), p_data, len);
        txframe.len = len;
        ret = sdk_can_write(index, &txframe, 1);
    }
    else // 多帧发送，主要用于文件上传
    {
        uint8_t frame_max_cnt = (len + CAN_SIGNAL_FRA_MAX_NUMS - 1) / CAN_SIGNAL_FRA_MAX_NUMS;
        uint8_t frame_len = 0;
        for (uint8_t frame_cnt = 0; frame_cnt < frame_max_cnt; frame_cnt++)
        {
            // 最后一帧处理
            if (frame_cnt == (frame_max_cnt - 1))
            {
                // 计算最后一帧的长度
                frame_len = ((len % CAN_SIGNAL_FRA_MAX_NUMS) == 0) ? CAN_SIGNAL_FRA_MAX_NUMS : len % CAN_SIGNAL_FRA_MAX_NUMS;
            }
            else
            {
                frame_len = CAN_SIGNAL_FRA_MAX_NUMS; // 默认长度
            }
            // 复制需要发送的数据
            memcpy(&(txframe.data[0]), &p_data[frame_cnt * CAN_SIGNAL_FRA_MAX_NUMS], frame_len);
            txframe.len = frame_len;
            // data_print(txframe.data, frame_len);   //打印数据
            ret = sdk_can_write(index, &txframe, 1);
            if (ret != SF_OK)
            {
                break;
            }
        }
    }
//    if (ret != SF_OK)
//    {
//        log_e("[can%d]txErr%d\n", index, ret);
//    }
    return (ret);
}

/**
* @brief		对比接收的ID是否和注册的ID一致
* @param		[in]接收到的ID
* @param		[in]注册的ID
* @param		[in]注册ID的掩码
* @return		返回结果
* @retval		0：成功    < 0: 失败
* @warning		无
*/
#ifndef CAN_GET_BIT
#define CAN_GET_BIT( data, offset )	( ((uint32_t)data >> offset )  & 0x00000001)
#endif
int32_t can_compare_id(uint32_t target_id, uint32_t reg_id, uint32_t id_mask)
{
    int32_t res = 0;
    uint8_t i = 0;
    
    for(i = 0; i < 32; i++)
    {
        if( 0 == CAN_GET_BIT(id_mask , i) )		//掩码位置为1时，不做对比
        {
            if( CAN_GET_BIT( reg_id, i ) == CAN_GET_BIT( target_id, i ) )
            {
                continue;
            }
            else
            {
                res = -1;
                break;
            }
        }
        else
        {
            continue;
        }
    }
    
    return res;
}
