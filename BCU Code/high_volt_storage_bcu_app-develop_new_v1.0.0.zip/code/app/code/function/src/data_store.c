/**
 * @file     data_store.c
 * @brief    数据存储处理
 * @company  sofarsolar
 * @author   刘炜全
 * @note     
 * @version
 * @date     2023/5/31 V1.0.1
 */
 
#include "sdk.h" 
#include <string.h>
#include <stdlib.h>
#include "data_store.h"
#include "sdk_para.h"
#include "sdk_record.h"
#include "fault_manage.h"
#include "auto_addressing.h"
#include "bms_state.h"
#include "app_config.h"
#include "sample.h"
#include "sox.h"
#include "sop.h"
#include "external_can_data.h"
#include "relay_manage.h"
#include "bms_state.h"
#include "bmu_data.h"
#include "insulation_impedance_calc.h"
#include "bcu_data.h"
#include "public_flag.h"
#include "sox_stats.h"
//Mtest
const bms_attr_t bms_attr_init = {
    .version = 0xA003,
    .safety = {  // 保护产生阈值 保护解除阈值 告警产生阈值 告警解除阈值      //注意这里是int16_t
        .total_over_vol_tip               = {8960, 8880},               ///< 总压过压提示 分辨率为0.1V/bit，偏移量为0
        .total_over_vol_alarm             = {9088, 9008},               ///< 总压过压告警 分辨率为0.1V/bit，偏移量为0  
        .total_over_vol_protect           = {9344, 9264},               ///< 总压过压保护 分辨率为0.1V/bit，偏移量为0
        .total_under_vol_tip              = {(7168+128), (7248+128)},               ///<总压欠压提示  分辨率为0.1V/bit，偏移量为0
        .total_under_vol_alarm            = {(6912+128), (6992+128)},               ///<总压欠压告警  分辨率为0.1V/bit，偏移量为0
        .total_under_vol_protect          = {(6400+128), (6480+128)},               ///< 总压欠压保护 分辨率为0.1V/bit，偏移量为0
        .bat_over_vol_tip                 = {2240,  2170},              ///< 电池模组过压提示, 分辨率：0.1V/bit  偏移量 0
        .bat_over_vol_alarm               = {2272,  2202},              ///< 电池模组过压告警, 分辨率：0.1V/bit  偏移量 0
        .bat_over_vol_protect             = {2336,  2266},              ///< 电池模组过压保护, 分辨率：0.1V/bit 偏移量 0
        .bat_under_vol_tip                = {(1792+32),  (1862+32)},               ///< 电池模组过低提示, 分辨率：0.1V/bit  偏移量 0
        .bat_under_vol_alarm              = {(1728+32),  (1798+32)},               ///< 电池模组过低告警, 分辨率：0.1V/bit  偏移量 0
        .bat_under_vol_protect            = {(1600+32),  (1670+32)},               ///< 电池模组过低保护, 分辨率：0.1V/bit 偏移量 0        
        .cell_over_vol_tip                = {(3500+50), (3400+50)},               ///< 单体过压提示, 分辨率：0.001V/bit  偏移量 0
        .cell_over_vol_alarm              = {(3550+50), (3450+50)},               ///< 单体过压告警, 分辨率：0.001V/bit  偏移量 0
        .cell_over_vol_protect            = {(3650+50), (3550+50)},               ///< 单体过压保护, 分辨率：0.001V/bit 偏移量 0
        .cell_under_vol_tip               = {2800, 2900},                ///< 单体过低提示, 分辨率：0.001V/bit  偏移量 0
        .cell_under_vol_alarm             = {2700, 2800},                ///< 单体过低告警, 分辨率：0.001V/bit  偏移量 0
        .cell_under_vol_protect           = {2500, 2600},                ///< 单体过低保护, 分辨率：0.001V/bit 偏移量 0        
        .chg_over_cur_tip                 = {1500, 1380 },               ///< 充电过流提示 分辨率：0.1A 无偏移量
        .chg_over_cur_alarm               = {1800, 1680},               ///< 充电过流告警 分辨率：0.1A 无偏移量
        .chg_over_cur_protect             = {2100, 2020},               ///< 充电过流保护 分辨率：0.1A 无偏移量
        .dchg_over_cur_tip                = {1800, 1680},              ///< 放电过流提示 分辨率：0.1A 无偏移量
        .dchg_over_cur_alarm              = {2280, 2160},              ///< 放电过流告警 分辨率：0.1A 无偏移量
        .dchg_over_cur_protect            = {2400, 2280},              ///< 放电过流保护 分辨率：0.1A 无偏移量
        .chg_over_cell_temp_tip           = {500,   450},              ///< 单体充电温度过高提示, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .chg_over_cell_temp_alarm         = {550,   500},              ///< 单体充电温度过高告警, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .chg_over_cell_temp_protect       = {600,   550},              ///< 单体充电温度过高保护, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .chg_under_cell_temp_tip          = {20   , 50},               ///< 单体充电温度过低提示, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .chg_under_cell_temp_alarm        = {0,     20 },               ///< 单体充电温度过低告警, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .chg_under_cell_temp_protect      = {-200, -150},               ///< 单体充电温度过低保护, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .dchg_over_cell_temp_tip          = {500,   450  },               ///< 单体放电温度过高提示, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .dchg_over_cell_temp_alarm        = {550,   500  },               ///< 单体放电温度过高告警, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .dchg_over_cell_temp_protect      = {600,   550  },               ///< 单体放电温度过高保护, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .dchg_under_cell_temp_tip         = {0   ,   50  },                ///< 单体放电温度过低提示, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .dchg_under_cell_temp_alarm       = {-100, -50   },                ///< 单体放电温度过低告警, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .dchg_under_cell_temp_protect     = {-200, -150  },                ///< 单体放电温度过低保护, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .cell_temp_diff_tip               = {150,  100},                ///< 单体温度差值过大提示, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .cell_temp_diff_alarm             = {200,  150},                ///< 单体温度差值过大告警, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .cell_temp_diff_protect           = {300,  250},                ///< 单体温度差值过大保护, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .bat_soc_over_tip                 = {1010, 990},              ///< SOC过大提示, 分辨率：0.1%/bit 偏移量 0
        .bat_soc_over_alarm               = {1010, 990},              ///< SOC过大告警, 分辨率：0.1%/bit 偏移量 0
        .bat_soc_over_protect             = {1010, 990},              ///< SOC过大保护, 分辨率：0.1%/bit 偏移量 0
        .bat_soc_under_tip                = {150,  170},               ///< SOC过低提示, 分辨率：0.1%/bit 偏移量 0
        .bat_soc_under_alarm              = {100,  120},               ///< SOC过低告警, 分辨率：0.1%/bit 偏移量 0
        .bat_soc_under_protect            = {50,  70},               ///< SOC过低保护, 分辨率：0.1%/bit 偏移量 0
        .bat_soc_diff_tip                 = {1000,  980},              ///< SOC差值过大提示, 分辨率：0.1%/bit 偏移量 0
        .bat_soc_diff_alarm               = {1000,  980},              ///< SOC差值过大告警, 分辨率：0.1%/bit 偏移量 0
        .bat_soc_diff_protect             = {1000,  980},              ///< SOC差值过大保护, 分辨率：0.1%/bit 偏移量 0
        .ins_val_under_tip                = {1000, 1010 },              ///< 绝缘阻抗过低提示, 分辨率：1KΩ/bit  偏移量 0
        .ins_val_under_alarm              = {500 , 510 },               ///< 绝缘阻抗过低告警, 分辨率：1KΩ/bit  偏移量 0
        .ins_val_under_protect            = {100 , 110 },               ///< 绝缘阻抗过低保护, 分辨率：1KΩ/bit  偏移量 0
        .cell_vol_diff_tip                = {400 , 350},               ///< 单体压差过大提示, 分辨率：0.001V/bit  偏移量 0
        .cell_vol_diff_alarm              = {600 , 550},               ///< 单体压差过大告警, 分辨率：0.001V/bit  偏移量 0
        .cell_vol_diff_protect            = {800,  750},               ///< 单体压差过大保护, 分辨率：0.001V/bit 偏移量 0
        .mod_temp_over_tip                = {700,  650},               ///< 模块温度过高提示, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .mod_temp_over_alarm              = {900,  850},               ///< 模块温度过高告警, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .mod_temp_over_protect            = {1050, 1000},               ///< 模块温度过高保护, 分辨率：0.1℃/bit 偏移量 -40.0℃
        .power_terminal_temp_over_tip     = {900,  850},        ///< 功率端子温度过高提示, 分辨率：0.1℃/bit 
        .power_terminal_temp_over_alarm   = {950,  900},        ///< 功率端子温度过高告警, 分辨率：0.1℃/bit 
        .power_terminal_temp_over_protect = {1000,  950},       ///< 功率端子温度过高保护, 分辨率：0.1℃/bit 
        .power_volt_over_alarm            = {336,  320},        ///< 供电电压过高告警, 分辨率：0.1V/bit 
        .power_volt_under_alarm           = {171,  180},        ///< 供电电压欠压告警, 分辨率：0.1V/bit 
    },
    .hall_enable = 0x01, // 使能霍尔1(bit0)
    .ex_addr = GOLD_MIN_EX_CAN_ADDR,
    .clu_pack_num = PACK_MIN_NUM,
    .hall_range = {500, 500, 500},
    .pack_cell_num = PACK_CELL_NUM_64,
    .pack_temp_num = PACK_CELL_TEMP_NUM_36,
    .cell_type =  PACK_CELL_TYPE, // 电池类型 1 表示 L--磷酸铁锂电池,2 表示 N—钛酸锂电池,3 表示 T—锰酸锂电池,4 表示 S--三元锂电池,
    .bat_cap = PACK_POWER_CAP_120,
    .cell_model = PACK_CELL_MODEL,
    .manufactor = PACK_CELL_MANUFACTOR,
    .fan_open_temp = 850, // 风扇开启温度	℃
    .fan_close_temp = 750,  // 风扇关闭温度	℃
    .full_chg_vol = 3550,  // 满充电压	1mV     //目前没有使用到，1.0项目是3.55，2.0项目是3.6
    .empty_dchg_vol = 2700,// 截至电压	1mV
    .adjust = 
    {
        HALL_CAHNNEL1_SEN,   ///< 大电流增益
        HALL_CAHNNEL2_SEN,   ///< 小电流增益
        SAMPLE_VOLT_GAIN,   ///< 母线总压增益
        SAMPLE_VOLT_GAIN,   ///< 负载总压增益
        SAMPLE_VOLT_GAIN,   ///< 保险丝母线总压增益
    },   
    .pack_sn = {                                   // PACK条形码
                '0', '1', '2', '3', '4', '5', '6', //
                '0', '1', '2'                   },

    .board_sn = {                                   // BOARD条形码
                 '0', '1', '2', '3', '4', '5', '6', //
                 '0', '1', '2'                    },

    .app_ver =  {"V000000"}, 
    .project_ver = {PROJECT_VER_2_0_H,PROJECT_VER_2_0_L},
    .check = 0,
};


const bms_runing_data_t g_bms_runing_init = 
{
    .version = 0xA0000001,
    .soc = 40,
    .soh = 100,
    .cycle_count = 0,
    .remain_cap = 40,
    .real_cap = 102,
    .bat_pack_id= 0,
    .add_up_ah_chg = 0,
    .add_up_ah_dsg = 0,
    .add_up_wh_chg = 0,
    .add_up_wh_dsg = 0,
    .add_up_mas_chg = 0,
    .add_up_mas_dsg = 0,
    .add_up_mws_chg = 0,
    .add_up_mws_dsg = 0,
    .time = {0, 0, 0, 0, 0, 0},
    .today_wh_chg = 0,
    .today_wh_dsg = 0,
};



static bms_attr_t g_bms_attr = {0};
static fault_record_buff_info_t g_fault_record_buff_info = {0};
static data_store_flag_t  g_data_store_flag = {0};
static sum_fault_data_t sum_fault_data = {0};


static bms_runing_data_t g_bms_runing_data = {0};

static uint8_t sleep_lock_id = 0;

const fault_record_buff_info_t *get_fault_record_buff(void)
{
    return &g_fault_record_buff_info;
}

const bms_attr_t *get_bms_attr(void)
{
    return &g_bms_attr;
}

const bms_runing_data_t *get_bms_runing_data(void)
{
    return &g_bms_runing_data;
}

//返回attr初始参数
const bms_attr_t *get_bms_attr_init(void)
{
    return &bms_attr_init;
}

// 设置存储数据
int8_t data_store_save_bms_attr_thre_val(set_thre_id_e thre_id, uint16_t set_value) // 此函数后续不在使用 25/03/20
{
    int8_t ret = -1;
    if (thre_id >= SET_THRE_CNT)
    {
        return ret;
    }
    uint16_t off_set = 0;
    if (thre_id < SET_THRE_ALM_END)
    {
        off_set = thre_id - SET_THRE_CLU_OVER_VOLT_TIP;
        off_set *= 2; // sizeof(int32_t)
        ret = data_store_save_bms_attr(ST_VAR_POS(bms_attr_t,safety) + off_set, (uint8_t *)(&set_value),ST_VAR_SIZE( safety_param_t, appear_value ) );
    }
    else if (thre_id <= SET_THRE_RES)
    {
        uint8_t set_u8_val = set_value & 0x00FF;
        off_set = thre_id - SET_THRE_HALL_ENABLE;
        off_set *= 1; // sizeof(int32_t)
        ret = data_store_save_bms_attr(ST_VAR_POS(bms_attr_t,hall_enable) + off_set, (uint8_t *)(&set_u8_val),ST_VAR_SIZE( bms_attr_t, hall_enable ) );
    }
    else if (thre_id <= SET_THRE_EMPTY_DCHG_VOL)
    {
        uint16_t u16_set_value = set_value;
        off_set = thre_id - SET_THRE_HALL_RANGE_1;
        off_set *= 2; // sizeof(int16_t)
        ret = data_store_save_bms_attr(ST_VAR_POS(bms_attr_t,hall_range[0]) + off_set, (uint8_t *)(&u16_set_value),ST_VAR_SIZE(bms_attr_t,hall_range[0]) );
    }
    else
    {
        // TODO 待添加设置电池包的SOX
    }
    return ret;
}

// 读取存储数据
int8_t data_store_bms_attr_thre_val_get(set_thre_id_e thre_id, uint16_t *get_value)
{
    int8_t ret = -1;
    if (thre_id >= SET_THRE_CNT)
    {
        return ret;
    }
    if (thre_id < SET_THRE_ALM_END)
    {
        uint16_t off_set = (thre_id - SET_THRE_CLU_OVER_VOLT_TIP) * 2;
        uint16_t val = 0;
        val = *(uint16_t *)((uint8_t *)&g_bms_attr + (ST_VAR_POS(bms_attr_t,safety)+off_set));
        *get_value = val;
    }
    return 0;
}

static uint16_t check_crc(uint8_t *pData, uint32_t plen) {
    uint16_t siRet  = 0;
    uint16_t u16CRC = 0xFFFF;
    for (int i = 0; i < plen; i++) {
        u16CRC ^= (uint16_t)(pData[i]);
        for (int j = 0; j <= 7; j++) {
            if (u16CRC & 0x0001) {
                u16CRC = (u16CRC >> 1) ^ 0xA001;
            } else {
                u16CRC = u16CRC >> 1;
            }
        }
    }
    siRet = (u16CRC & 0x00FF) << 8;
    siRet |= u16CRC >> 8;
    return siRet;
}



int32_t data_store_fault_get(data_store_fault_e fault_type)
{
    int32_t res = 0;
    switch (fault_type)
    {
    case DATA_STORE_BMS_ATTR:
        res = g_data_store_flag.para_err;
        break;
    case DATA_STOR_RUNNING_DATA:
        res = g_data_store_flag.runing_data_err;
        break;
    case DATA_STORE_RECORD:
        res = g_data_store_flag.record_err;
        break;
    case DATA_STORE_FAULT_RECORD:
        res = g_data_store_flag.fault_record_err;
        break;           
    default:
        break;
    }
    return res;

}

int32_t data_store_toatal_fault_get(void)
{
    for(uint8_t i = DATA_STORE_BMS_ATTR; i < DATA_STORE_FAULT_NUM; i++)
    {
        if(INVRLID == data_store_fault_get((data_store_fault_e)i))
        {
            return i;
        }
    }

    return -1;
}



static void data_store_fault_set(data_store_fault_e fault_type, uint8_t value)
{
    switch (fault_type)
    {
    case DATA_STORE_BMS_ATTR:
        g_data_store_flag.para_err = value;
        break;
    case DATA_STOR_RUNNING_DATA:
        g_data_store_flag.runing_data_err = value;
        break;
    case DATA_STORE_RECORD:
        g_data_store_flag.record_err = value;
        break;
    case DATA_STORE_FAULT_RECORD:
        g_data_store_flag.fault_record_err = value;
        break;
    default:
        break;
    }
}


/**
 * @brief 属性表初始化
 *
 */
static void attr_data_init(void)
{
    uint32_t check_crc_result;

    /* --------------------------------------------------------------------------------------------------*/
    // bms属性表
    /* --------------------------------------------------------------------------------------------------*/
    g_data_store_flag.bms_attr_file_open = sdk_para_init(BMS_ATTR_TAB, sizeof(bms_attr_t));
    if (g_data_store_flag.bms_attr_file_open == 0)
    {
        sdk_para_read(BMS_ATTR_TAB, 0, (uint8_t *)&g_bms_attr, sizeof(bms_attr_t)); // 获取属性表
        // 校验g_bms_attr的数据是否可用,否则赋默认值
        check_crc_result = (uint32_t)check_crc((uint8_t *)&g_bms_attr, sizeof(bms_attr_t) - 4);
        if ((g_bms_attr.version != bms_attr_init.version) // 属性表版本号不对, 首次初始化
            || (g_bms_attr.check != check_crc_result))
        {
            log_i("[store]nowVer!=InitVer %x %x\n\r", g_bms_attr.version, bms_attr_init.version);

            g_bms_attr = bms_attr_init;
            g_bms_attr.check = (uint32_t)check_crc((uint8_t *)&g_bms_attr, sizeof(bms_attr_t) - 4);

            sdk_para_write(BMS_ATTR_TAB, 0, (uint8_t *)&g_bms_attr, sizeof(bms_attr_t));
            sdk_para_sync(BMS_ATTR_TAB);
        }
        else
        {
            log_i("[store]AttrDataInitSucc\n\r");
        }
    }
    else
    {
        data_store_fault_set(DATA_STORE_BMS_ATTR, INVRLID);
    }

}


/**
 * @brief 运行数据初始化
 *
 */
static void running_data_init(void)
{
    uint32_t check_crc_result;

    /* --------------------------------------------------------------------------------------------------*/
    // 打开运行数据保存文件
    /* --------------------------------------------------------------------------------------------------*/
    g_data_store_flag.runing_data_file_open = sdk_para_init(BMS_RUNING_DATA, sizeof(bms_runing_data_t));
    if (g_data_store_flag.runing_data_file_open == 0)
    {
        sdk_para_read(BMS_RUNING_DATA, 0, (uint8_t *)&g_bms_runing_data, sizeof(bms_runing_data_t));
        check_crc_result = (uint32_t)check_crc((uint8_t *)&g_bms_runing_data, sizeof(bms_runing_data_t) - 4);
        if (check_crc_result != g_bms_runing_data.check || g_bms_runing_data.version != g_bms_runing_init.version)
        {
            memcpy(&g_bms_runing_data, &g_bms_runing_init, sizeof(bms_runing_data_t));
            sdk_para_write(BMS_RUNING_DATA, 0, (uint8_t *)&g_bms_runing_data, sizeof(bms_runing_data_t));
            sdk_para_sync(BMS_RUNING_DATA);    
        }
        else
        {
            log_i("[store]RunDataCrcSuc\n\r");
        }

#if THIS_FILE_DEBUG
		// 打印: 掉电保存的运行数据
        log_d("read renew_cap_flag %d !! \n\r", g_bms_runing_data.renew_cap_flag);
#endif
    }
    else
    {
        data_store_fault_set(DATA_STOR_RUNNING_DATA, INVRLID);
    }
}


/**
 * @brief 日志初始化
 *
 */
static void record_data_init(void)
{
    g_data_store_flag.record_file_open = sdk_record_init(NORMAL_RECORD, sizeof(bms_record_data_t), RECORD_RUNING_DOG_DEPTH);
    if (g_data_store_flag.record_file_open != 0)
    {
        data_store_fault_set(DATA_STORE_RECORD, INVRLID);
        log_w("[store]RecordDataInitFail\n");
    }
}




/**
 * @brief
 *
 */
void data_store_init(void)
{

    sleep_lock_id = sdk_pm_get_lock_id();
    sdk_pm_lock(sleep_lock_id);

    attr_data_init();

    running_data_init();

    record_data_init();

    sdk_pm_unlock(sleep_lock_id);
}



/**
 * @brief 保存BMS属性表中某个元素
 * @param offset 偏移量
 * @param data 数据内容
 * @param len 数据长度
 * @return int32_t
 * @retval 0 成功
 * @retval -1 失败
 */
int32_t data_store_save_bms_attr(uint32_t offset, uint8_t *data, uint32_t len)
{
    if (memcmp((uint8_t *)&g_bms_attr + offset, data, len) != 0) // 如果数据相同，则不用保存
    {
        g_data_store_flag.bms_attr_save_flag = 1;
        sdk_pm_lock(sleep_lock_id);
        memcpy((uint8_t *)&g_bms_attr + offset, data, len);
    }
    return 0;
}

/**
 * @brief   保存BMS校准参数中某个元素
 * @return 无
 */
int32_t data_store_save_adjust_para(adjust_para_tab_t *adjust_para_tab)
{
    if (memcmp(&g_bms_attr.adjust, adjust_para_tab, sizeof(adjust_para_tab_t)) != 0) // 如果数据相同，则不用保存
    {
        g_data_store_flag.bms_attr_save_flag = 1;
        sdk_pm_lock(sleep_lock_id);
        memcpy(&g_bms_attr.adjust, adjust_para_tab, sizeof(adjust_para_tab_t));
    }
    return 0;
}

/**
 * @brief 保存BMSrunningdata中某个元素
 * @return int32_t
 * @retval 0 成功
 * @retval -1 失败
 */
int32_t bms_runing_data_save(bms_runing_data_t bms_runing_data)
{
    if (memcmp(&g_bms_runing_data, &bms_runing_data, sizeof(bms_runing_data_t)) != 0) // 如果数据相同，则不用保存
    {
        g_data_store_flag.bms_runing_data_save_flag = 1;
        sdk_pm_lock(sleep_lock_id);
        g_bms_runing_data = bms_runing_data;
    }

    return 0;
}

/**
 * @brief 执行保存BMSrunningdata全部数据
 * @return int32_t
 * @retval 0 成功
 * @retval -1 失败
 */
int32_t bms_runing_data_save_all(void)
{
    g_data_store_flag.bms_runing_data_save_flag = 1;
    sdk_pm_lock(sleep_lock_id);

    return 0;
}

/**
 * @brief 属性保存函数
 *
 */
static void bms_attr_data_save(void)
{
    bms_attr_t tmp_bms_attr,tmp_bms_attr2;
    
    /* --------------------------------------------------------------------------------------- */
    // 执行保存BMS属性
    /* --------------------------------------------------------------------------------------- */
    if (g_data_store_flag.bms_attr_save_flag)
    {

        if (g_data_store_flag.bms_attr_file_open == 0)
        {
            // 写入数据完整性信息
            g_bms_attr.check = (uint32_t)check_crc((uint8_t *)&g_bms_attr, sizeof(bms_attr_t) - 4);
            memcpy(&tmp_bms_attr2, &g_bms_attr, sizeof(bms_attr_t));    //防止g_bms_attr在存储过程中被篡改导致存储的数据和crc对应不上
            sdk_para_write(BMS_ATTR_TAB, 0, (uint8_t *)&tmp_bms_attr2, sizeof(bms_attr_t));
            sdk_para_sync(BMS_ATTR_TAB);
            sdk_para_read(BMS_ATTR_TAB, 0, (uint8_t *)&tmp_bms_attr, sizeof(bms_attr_t));
            if (memcmp(&tmp_bms_attr2, &tmp_bms_attr, sizeof(bms_attr_t)) == 0)
            {
                g_data_store_flag.bms_attr_save_flag = 0;
                g_data_store_flag.bms_attr_file_err_cnt = 0;
            }
            else
            {
                if (++g_data_store_flag.bms_attr_file_err_cnt >= 3) // 保存3次不成功，则报错
                {
                    g_data_store_flag.bms_attr_file_err_cnt = 3;
                    g_data_store_flag.bms_attr_save_flag = 0;
                    data_store_fault_set(DATA_STORE_BMS_ATTR, INVRLID);
                }
            }
        }
        else
        {
            g_data_store_flag.bms_attr_save_flag = 0;   //防止文件打开失败后，无法进入休眠             
        }
    }

}


/**
 * @brief 运行数据填充
 *
 */
static int8_t bms_running_data_fill(bms_runing_data_t *bms_runing_data)
{
    uint8_t pack_num = auto_addressing_pack_num_get();
    const batt_clu_sox *sox_data = NULL;
    sdk_rtc_t rtc_time = {0};

    sox_data = sox_data_get();

    if(NULL == bms_runing_data)
    {
        return -1;
    }
    if (sox_data != NULL)
    {
        bms_runing_data->soc = sox_data->batt_clu_display_soc;
        bms_runing_data->soh = sox_data->batt_clu_display_soh;
        bms_runing_data->cycle_count = sox_data->batt_clu_cycle_count;
        bms_runing_data->remain_cap = sox_data->batt_clu_remain_cap;
        bms_runing_data->real_cap = sox_data->batt_clu_real_cap;
        bms_runing_data->add_up_ah_chg = sox_data->batt_clu_ah_chg;
        bms_runing_data->add_up_ah_dsg = sox_data->batt_clu_ah_dsg;
        bms_runing_data->add_up_wh_chg = sox_data->batt_clu_wh_chg;
        bms_runing_data->add_up_wh_dsg = sox_data->batt_clu_wh_dsg;
        bms_runing_data->add_up_mas_chg = sox_data->batt_clu_mas_chg;
        bms_runing_data->add_up_mas_dsg = sox_data->batt_clu_mas_dsg;
        bms_runing_data->add_up_mws_chg = sox_data->batt_clu_mws_chg;
        bms_runing_data->add_up_mws_dsg = sox_data->batt_clu_mws_dsg;
        bms_runing_data->today_wh_chg = 0;  //待补充
        bms_runing_data->today_wh_dsg = 0;  //待补充
    }
    bms_runing_data->bat_pack_id = 0;  //待补充
    sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
    bms_runing_data->time[0] = (uint16_t)rtc_time.tm_year;
    bms_runing_data->time[1] = (uint16_t)rtc_time.tm_mon;
    bms_runing_data->time[2] = (uint16_t)rtc_time.tm_day;
    bms_runing_data->time[3] = (uint16_t)rtc_time.tm_hour;
    bms_runing_data->time[4] = (uint16_t)rtc_time.tm_min;
    bms_runing_data->time[5] = (uint16_t)rtc_time.tm_sec;
    

    //系统锁已有单独的进程进行存储
    
    return 0;
}

// 该表中故障类型的顺序需要与联合体 fault_cnt_stu_u 中 bit 位的顺序保持一致，修改时需要同步修改
// 另外该表中故障的数量不能超过 fault_cnt_stu_u 中定义的 bit 的位数，当前是32位
static fault_cnt_map_t g_fault_map[FAULT_CNT_MAX_NUMS]=
{
    {POWER_NTC_ERR_CNT,                         BOARD_POWER_TERMINAL_TEMP_SAM_FAULT     },
    {ENV_NTC_ERR_CNT,                           BOARD_ENV_TEMP_SAM_ABNORMAL_ALARM       },
    {FLASH_INVALID_CNT,                         BOARD_FLASH_INVALID_FAULT               },
    {INNER_CAN_COMM_ABNORMAL_CNT,               BOARD_INNER_CAN_COMM_FAULT              },
    {INNER_CAN_ADDR_REPEAT_FAULT_CNT,           BOARD_INNER_CAN_ADDR_REPEAT_FAULT       },
    {BCU_PCS_COMM_ABNORMAL_FAULT_CNT,           BOARD_BCU_PCS_CAN_COMM_ABNORMAL_FAULT   },
    {POWER_TERMINAL_TEMP_OVER_PROTECT_CNT,      BOARD_POWER_TERMINAL_TEMP_OVER_PROTECT  },
    {POSITIVE_RELAY_ADHESION_CNT,               BOARD_POSITIVE_RELAY_ADHESION_FAULT     },
    {NEGATIVE_RELAY_ADHESION_CNT,               BOARD_NEGATIVE_RELAY_ADHESION_FAULT     },
    {AUX_RELAY_ADHESION_CNT,                    BOARD_AUX_RELAY_ADHESION_FAULT          },
    {INS_RES_VAL_LOW_PROTECT_CNT,               BOARD_INS_RES_VAL_LOW_PROTECT           },
    {EXT_ADC_ABNORMAL_CNT,                      BOARD_EXT_ADC_FAULT                     },
    {PRE_CHARGE_FAULT_CNT,                      BOARD_PRE_CHARGE_FAULT                  },
    {ENV_TEMP_HIGH_PROTECT_CNT,                 BOARD_ENV_TEMP_HIGH_PROTECT             },
    {TRIP_FAULT_CNT,                            BOARD_TRIP_FAULT                        },
    {CAN_HALL_SENSOR_FAULT_CNT,                 BOARD_CAN_HALL_SENSOR_FAULT             },
    {CAN_HALL_SENSOR_COMM_FAULT_CNT,            BOARD_CAN_HALL_SENSOR_COMM_FAULT        },
    {POWER_OFF_FAULT_CNT,                       BOARD_POWER_OFF_FAULT                   },
    {ALL_CLUSTER_POWER_OFF_FAULT_CNT,           BOARD_ALL_CLUSTER_POWER_OFF_FAULT       },
    {CLU_TOTAL_VOLT_HIGH_PROTECT_CNT,           BAT_CLUSTER_TOTAL_VOLT_HIGH_PROTECT     },
    {CLU_TOTAL_VOLT_LOW_PROTECT_CNT,            BAT_CLUSTER_TOTAL_VOLT_LOW_PROTECT      },
    {CLU_TOTAL_VOLT_DIFF_OVER_FAULT_CNT,        BAT_CLUSTER_TOTAL_VOLT_DIFF_OVER_FAULT  },
    {INTER_CLU_VOLT_DIFF_OVER_FAULT_CNT,        BAT_INTER_CLU_VOLT_DIFF_OVER_FAULT      },
    {CHG_CURR_HIGH_PROTECT_CNT,                 BAT_CHARGE_CURR_HIGH_PROTECT            },
    {DSG_CURR_OVER_PROTECT_CNT,                 BAT_DISCHG_CURR_OVER_PROTECT            }
};

/**
 * @brief 保护越限次数保存
 *
 */
void bms_protect_cnt_save(void)
{
    static fault_cnt_stu_u last_fault_stu = {0};
    static fault_cnt_stu_u current_fault_stu = {0};
	fault_type_e temp_map;

    for(uint8_t i = FAULT_CNT_START; i < FAULT_CNT_MAX_NUMS; i++)
    {
		temp_map = g_fault_map[i].fault_cnt_map;
        if(fault_state_get(temp_map) < FAULT_STOP)
        {
            continue;
        }
        else if(fault_state_get(temp_map) == FAULT_START)
        {
			current_fault_stu.stu_val |= 1 << i;
            if((last_fault_stu.stu_val & (1 << i)) != (current_fault_stu.stu_val & (1 << i)))
            {
                g_bms_runing_data.fault_cnt[i]++;
                last_fault_stu.stu_val |= 1 << i;
            }
        }
        else
        {
			current_fault_stu.stu_val &= ~(1 << i);
            if((last_fault_stu.stu_val & (1 << i)) != (current_fault_stu.stu_val & (1 << i)))
            {
                last_fault_stu.stu_val &= ~(1 << i);
            }
        }
    }
}

/**
 * @brief 保护越限次数清除
 *
 */
void bms_protect_cnt_clear(void)
{
    for(uint8_t i = 0; i < FAULT_CNT_MAX_NUMS; i++)
    {
        g_bms_runing_data.fault_cnt[i] = 0;
    }

    return;
}

void bms_relay_cutoff_forced_save(void)
{
    if(get_load_cut_off_flag())
    {
        g_bms_runing_data.relay_cutoff_forced++;
    }

    return;
}

/**
 * @brief 运行数据保存函数
 *
 */
static void bms_running_data_save(void)
{
    bms_runing_data_t tmp_bms_runing_data,tmp_bms_runing_data2;        
    
    bms_protect_cnt_save();
    bms_relay_cutoff_forced_save();
    /* --------------------------------------------------------------------------------------- */
    // 执行保存运行数据
    /* --------------------------------------------------------------------------------------- */
    if (g_data_store_flag.bms_runing_data_save_flag)
    {
        bms_running_data_fill(&g_bms_runing_data);
        if (g_data_store_flag.runing_data_file_open == 0)
        {

            // 写入数据完整性信息
            g_bms_runing_data.check = (uint32_t)check_crc((uint8_t *)&g_bms_runing_data, sizeof(bms_runing_data_t) - 4);

    #if THIS_FILE_DEBUG
            log_d("save soc %d !! \n\r", g_bms_runing_data.soc);
    #endif

            // 保存数据到flash
            memcpy(&tmp_bms_runing_data2, &g_bms_runing_data, sizeof(bms_runing_data_t));   //防止g_bms_runing_data在存储过程中被篡改导致存储的数据和crc对应不上
            sdk_para_write(BMS_RUNING_DATA, 0, (uint8_t *)&tmp_bms_runing_data2, sizeof(bms_runing_data_t));
            sdk_para_sync(BMS_RUNING_DATA);
            sdk_para_read(BMS_RUNING_DATA, 0, (uint8_t *)&tmp_bms_runing_data, sizeof(bms_runing_data_t));
            if (memcmp(&tmp_bms_runing_data2, &tmp_bms_runing_data, sizeof(bms_runing_data_t)) == 0)
            {
                g_data_store_flag.bms_runing_data_save_flag = 0;
                g_data_store_flag.runing_data_file_err_cnt = 0;
            }
            else
            {
                if (++g_data_store_flag.runing_data_file_err_cnt >= 3) // 保存3次不成功，则报错
                {
                    g_data_store_flag.runing_data_file_err_cnt = 3;
                    g_data_store_flag.bms_runing_data_save_flag = 0;
                    data_store_fault_set(DATA_STOR_RUNNING_DATA, INVRLID);
                }
            }
        }
        else
        {
            g_data_store_flag.bms_runing_data_save_flag = 0;   //防止文件打开失败后，无法进入休眠             
        }

    }

}

//填充需要记录的数据
static bms_record_data_t record_data_fill(void)
{
    bms_record_data_t  record_data = {0};
    sample_data_t sample_data = {0}; 
    sdk_rtc_t rtc_time = {0};
    pack_info_t *bmu_data = NULL;
    uint8_t i = 0;

    const batt_clu_sox* sox_data = sox_data_get();
    const bmu_data_unify_t *p_bmu_data_unify = bmu_data_unify_get();

    if (NULL != sox_data)
    {
        record_data.soc = sox_data->batt_clu_display_soc;
        record_data.soh = sox_data->batt_clu_display_soh / 10;
        record_data.dsg_ah = sox_data->batt_clu_ah_dsg;
        record_data.chrg_ah = sox_data->batt_clu_ah_chg;
        record_data.dsg_wh = sox_data->batt_clu_wh_dsg;
        record_data.chrg_wh = sox_data->batt_clu_wh_chg;
    }
       
    sdk_rtc_get(RTC_BIN_FORMAT, &rtc_time);
    record_data.year_month = (((uint16_t)rtc_time.tm_mon)<<8)+rtc_time.tm_year;
    record_data.day_hour = (((uint16_t)rtc_time.tm_hour)<<8)+rtc_time.tm_day;     
    record_data.min_sec = (((uint16_t)rtc_time.tm_sec)<<8)+rtc_time.tm_min; 

    //电池簇充电电流上限
    record_data.chrg_cur_lim = sop_data_get()->batt_clu_limit_dsg_curr;
    //电池簇放电电流上限
    record_data.dischrg_cur_lim = sop_data_get()->batt_clu_limit_chg_curr;

    if(NULL != p_bmu_data_unify)
    {
        record_data.bat_acc_volt = p_bmu_data_unify->all_pack_acc_volt;        
    }
    //record_data->pack_no  = g_bms_attr.SET_THRE_CLU_PACK_NUM;
    sample_data = *p_sample_data_get();
    record_data.current = sample_data.sys_current/10;    //0.1a精度 
    record_data.bus_volt = sample_data.bus_volt/100;    //0.1v精度
    //record_data->fuse_volt = 0;//sample_data.fuse_bus_volt/100;    //0.1v精度
    record_data.load_volt = sample_data.load_volt/100;    //0.1v精度
    record_data.iso_impedance_value = (uint16_t)(insulation_impedance_value_get());   //单位kΩ
    record_data.supply_volt = sample_data.power_24v_volt/100;    //0.1v精度
    
    for(uint8_t i = 0; i < 4; i++)
    {
    record_data.pwr_temp[i] = (uint8_t)(sample_data.adc_sample_other_temp[LOAD_P_TEMP + i] / 10);        
    }
    record_data.env_temp = (uint8_t)(sample_data.adc_sample_other_temp[PCB_TEMP] / 10); 

    record_data.di_stus = bcu_dido_info_get()->di_state.byte;
    record_data.do_stus = bcu_dido_info_get()->do_state.byte;
    record_data.sys_stus = bms_state_get_sys_sta();
    record_data.other_status = sys_stus_get();
    
    if(!get_bcu_info()->chg_enable)
    {
        record_data.other_status |= (0x01 << data_chg_enable);
    }
    if(!get_bcu_info()->dsg_enable)
    {
        record_data.other_status |= (0x01 << data_dsg_enable);
    }
    if(get_bcu_info()->fault_state)
    {
        record_data.other_status |= (0x01 << data_fault_state);
    }
    if(get_bcu_info()->clu_mode == CLU_PARALLEL)
    {
        record_data.other_status |= (0x01 << data_CLU_PARALLEL);
    }
    else
    {
        record_data.other_status |= (0x01 << data_CLU_SINGLE);
    }
    

    const fault_stat_data_t *data_fault_data = fault_chg_dsg_level_get();
    record_data.fault_level = data_fault_data->max_charge_level + (data_fault_data->max_discharge_level << 4);
    const gold_warn_msg_t *warn_msg_reply = warn_msg_reply_get();
    record_data.fault_msg[0] = warn_msg_reply->base_warn[0].warn_byte0.byte;
    record_data.fault_msg[1] = warn_msg_reply->base_warn[0].warn_byte1.byte;
    record_data.fault_msg[2] = warn_msg_reply->base_warn[0].warn_byte2.byte;
    record_data.fault_msg[3] = warn_msg_reply->dev_warn.warn_byte0.byte;
    record_data.fault_msg[4] = warn_msg_reply->dev_warn.warn_byte1.byte;
    record_data.fault_msg[5] = warn_msg_reply->dev_warn.warn_byte2.byte;
    record_data.fault_msg[6] = warn_msg_reply->dev_warn.warn_byte3.byte;
    
    //bmu数据
    for(i = 0; i < auto_addressing_pack_num_get(); i++)
    {
        bmu_data = get_bmu_info(i);
        record_data.max_cell_volt[i] = bmu_data->yc2[YC2_UNS_MAX_CELL_VOLT];
        record_data.min_cell_volt[i] = bmu_data->yc2[YC2_UNS_MIN_CELL_VOLT];
        record_data.avg_cell_volt[i] = bmu_data->yc2[YC2_UNS_AVG_CELL_VOLT];        
        record_data.max_cell_temp[i] = (int16_t)bmu_data->yc2[YC2_SGN_MAX_CELL_TEMP]/10;
        record_data.min_cell_temp[i] = (int16_t)bmu_data->yc2[YC2_SGN_MIN_CELL_TEMP]/10;
        record_data.avg_cell_temp[i] = (int16_t)bmu_data->yc2[YC2_SGN_AVG_CELL_TEMP]/10;        
    } 
    
    record_data.max_pack_volt = bmu_data_unify_get()->packvolt_max;
    record_data.min_pack_volt = bmu_data_unify_get()->packvolt_min;
    record_data.max_pack_volt_no = (uint8_t)bmu_data_unify_get()->packvolt_max_id;
    record_data.min_pack_volt_no = (uint8_t)bmu_data_unify_get()->packvolt_min_id;
	return record_data;
}



#define RECORD_DEBUG_ENABLE     0

static void bms_record_data_save(void)
{
    bms_record_data_t  record_data = {0};
    static uint32_t data_store_tick = 0;   

    //常规5分钟保存一次数据
    if (true == sdk_is_tick_over(data_store_tick, os_tick_from_millisecond(RECORD_SAVE_PERIOD2)))
    {

        if ((0 == g_data_store_flag.record_file_open)
            && (0 == g_data_store_flag.bms_record_read_flag))
        {
            g_data_store_flag.bms_record_save_flag = 1;
            //record_data = record_data_fill();
            record_data = g_fault_record_buff_info.fault_record_buff[g_fault_record_buff_info.fault_buff_fill_cnt]; //目前故障录波和日志的存储内容一致，故这里可以不需要跑record_data_fill
            if(0 == sdk_record_write(NORMAL_RECORD, 0, (uint8_t *)&record_data, sizeof(bms_record_data_t)))
            {
                g_data_store_flag.record_file_err_cnt = 0;
                g_data_store_flag.bms_record_save_flag = 0;
            }
            else
            {
                if(++g_data_store_flag.record_file_err_cnt >= 3)
                {
                    g_data_store_flag.record_file_err_cnt = 3;
                    g_data_store_flag.bms_record_save_flag = 0;
                    data_store_fault_set(DATA_STORE_RECORD, INVRLID);
                }
            }
        }

        
        data_store_tick = sdk_tick_get();

    }    
}


int8_t attr_data_resume_default_data(void) 
{
    int8_t result = 0;

    // 恢复 safety_para_tab 数据
    result |= data_store_save_bms_attr(
        ST_VAR_POS(bms_attr_t, safety), 
        (uint8_t *)(&bms_attr_init.safety),
        ST_VAR_SIZE(bms_attr_t, safety)
    );
    // 恢复其他参数
    result |= data_store_save_bms_attr(
        ST_VAR_POS(bms_attr_t, fan_open_temp),
        (uint8_t *)(&bms_attr_init.fan_open_temp),
        ST_VAR_SIZE(bms_attr_t, fan_open_temp)
    );
    result |= data_store_save_bms_attr(
        ST_VAR_POS(bms_attr_t, fan_close_temp),
        (uint8_t *)(&bms_attr_init.fan_close_temp),
        ST_VAR_SIZE(bms_attr_t, fan_close_temp)
    );
    result |= data_store_save_bms_attr(
        ST_VAR_POS(bms_attr_t, full_chg_vol),
        (uint8_t *)(&bms_attr_init.full_chg_vol),
        ST_VAR_SIZE(bms_attr_t, full_chg_vol)
    );
    result |= data_store_save_bms_attr(
        ST_VAR_POS(bms_attr_t, pack_cell_num),
        (uint8_t *)(&bms_attr_init.pack_cell_num),
        ST_VAR_SIZE(bms_attr_t, pack_cell_num)
    );
    result |= data_store_save_bms_attr(
        ST_VAR_POS(bms_attr_t, empty_dchg_vol),
        (uint8_t *)(&bms_attr_init.empty_dchg_vol),
        ST_VAR_SIZE(bms_attr_t, empty_dchg_vol)
    );
    log_e("reDefaultData\n");
    return result;
}





int8_t bms_record_data_read(uint16_t read_num, bms_record_data_t *p_data)
{
    uint16_t record_max_num = 0;
    int8_t ret = 0; 

    record_max_num = sdk_record_get_index(NORMAL_RECORD);
    if(read_num >= record_max_num)
    {
        ret = -1;
    }
    else
    {
        ret = sdk_record_read(NORMAL_RECORD, read_num, (uint8_t *)p_data, sizeof(bms_record_data_t));
    }

    return ret;

}


//删除日志记录
static int8_t bms_record_data_delte(void)
{
    return sdk_record_delete(NORMAL_RECORD);
}



/**
 * @brief BMS数据管理线程(100ms调用一次)
 *
 */
void data_store_thread(void)
{
    //属性保存函数
    bms_attr_data_save();

    //运行数据保存函数
    bms_running_data_save();

	//日志保存
	bms_record_data_save();

    /* --------------------------------------------------------------------------------------- */
    //
    /* --------------------------------------------------------------------------------------- */
    if ((g_data_store_flag.bms_attr_save_flag == 0)           //
        && (g_data_store_flag.bms_runing_data_save_flag == 0) 
        && (g_data_store_flag.bms_record_save_flag == 0)
        )
    { // 当没有数所保存时，解除休眠锁
        sdk_pm_unlock(sleep_lock_id);
    }
}


//删除故障录波文件
int8_t bms_fault_record_file_delte(void)
{
    g_data_store_flag.fault_record_file_open = -1;  //关闭文件
    return sdk_record_delete(FAULT_DATA_RECORD);
}

 static int8_t fault_record_data_store(void)
 {
     int8_t ret = 0;

     uint16_t buf_num = 0;
     int16_t tmp_buf = 0;
  
     // 数据写入
     if(g_fault_record_buff_info.buff_full_flag)
     {
         buf_num = g_fault_record_buff_info.fault_buff_fill_cnt;
         for(uint8_t i = 0; i < WINDOW_SIZE - g_fault_record_buff_info.fault_buff_fill_cnt; i++)
         {
             tmp_buf = sdk_record_write(FAULT_DATA_RECORD, 0, (uint8_t *)&g_fault_record_buff_info.fault_record_buff[buf_num + i], sizeof(bms_record_data_t));
             if(tmp_buf != 0)
             {
                 ret = -2;
                 goto err_exit;
             }
         }
         for(uint8_t i = 0; i < g_fault_record_buff_info.fault_buff_fill_cnt; i++)
         {
             tmp_buf = sdk_record_write(FAULT_DATA_RECORD, 0, (uint8_t *)&g_fault_record_buff_info.fault_record_buff[i], sizeof(bms_record_data_t));
             if(tmp_buf != 0)
             {
                 ret = -3;
                 goto err_exit;
             } 
         }
     }
     else
     {
         for(uint8_t i = 0;i <= g_fault_record_buff_info.fault_buff_fill_cnt;i++)
         {
             tmp_buf = sdk_record_write(FAULT_DATA_RECORD, 0, (uint8_t *)&g_fault_record_buff_info.fault_record_buff[i], sizeof(bms_record_data_t));
             if(tmp_buf != 0)
             {
                 ret = -4;
                 goto err_exit;
             }
         }
     }
     log_d("[record]StoringSuccess: %d\n",sdk_record_get_index(FAULT_DATA_RECORD));
     return ret;  

 err_exit:
     log_w("[record]StoringFailed:%d\n",ret);

     return ret;
 }


/**
* @brief 故障录波线程(1000ms调用一次)
*
*/
void fault_recording_proc(void)
{
    //    uint8_t i,j;
    static uint8_t cnt = 0;
    static uint32_t temp_time = 0;
    static uint8_t first_half_record_save_flag = 1;    // 故障录波前半段5s数据保存标志
    uint8_t fault_id = 0xff;    //0xff为无效故障id
    if (true == sdk_is_tick_over(temp_time, 1000))
    {   
        temp_time = sdk_tick_get();

        if(g_fault_record_buff_info.fault_buff_fill_cnt + 1 == WINDOW_SIZE) //当前已经存满
        {
            g_fault_record_buff_info.buff_full_flag = true;
        }
        g_fault_record_buff_info.fault_record_buff[g_fault_record_buff_info.fault_buff_fill_cnt] = record_data_fill();    //TO DO

        // log_d("[fault_record]: fault_buff_fill_cnt = %d  \r \n", g_fault_record_buff_info.fault_buff_fill_cnt);

        //进入关机状态或读取过程中不保存
        // if (data_store_enable_flag == false)
        // {
        //     return;
        // }

        if(fault_state_change(&fault_id))
        {
            g_fault_record_buff_info.fault_record_buff[g_fault_record_buff_info.fault_buff_fill_cnt].fault_id = fault_id;
            if(first_half_record_save_flag)
            {
                first_half_record_save_flag = 0;
                if(0 != fault_record_data_store())
                {
                    ++cnt;
                }
                else
                {
                    cnt = 0;
                }
            }
            else
            {
                g_fault_record_buff_info.fault_record_cnt++;
                //每5条存一次
                if(0 == g_fault_record_buff_info.fault_record_cnt % WINDOW_SIZE)
                {
                    if(0 != fault_record_data_store())
                    {
                        ++cnt;
                    }
                    else
                    {
                        cnt = 0;
                    }
                }
            }
        }
        else
        {
            g_fault_record_buff_info.fault_record_cnt = 0;
            first_half_record_save_flag = 1;
        }

        g_fault_record_buff_info.fault_buff_fill_cnt = (g_fault_record_buff_info.fault_buff_fill_cnt + 1) % WINDOW_SIZE;//挪到下面主要是因为故障id需要填充  

        if(cnt >= 5)
        {
            data_store_fault_set(DATA_STORE_FAULT_RECORD, INVRLID);
        }

    }

}


void fault_recording_init(void)
{
    g_fault_record_buff_info.fault_record_cnt = 0; //

    g_data_store_flag.fault_record_file_open = sdk_record_init(FAULT_DATA_RECORD, sizeof(bms_record_data_t), FAULT_RECORD_DOG_DEPTH);
    if (g_data_store_flag.fault_record_file_open != 0)
    {
        data_store_fault_set(DATA_STORE_FAULT_RECORD, INVRLID);
        log_w("[store]FaultRecordDataInitFail\n");
    }    
 
}

void set_bms_record_read_flag(uint8_t flag)
{
    g_data_store_flag.bms_record_read_flag = flag;
}

void set_fault_record_read_flag(uint8_t flag)
{
    g_data_store_flag.fault_record_read_flag = flag;
}

/********************************************调试代码********************************************************/

void sample_print(bms_record_data_t *p_data)
{
    log_d("year_month = %#x\n",p_data->year_month);
    log_d("day_hour = %#x\n",p_data->day_hour);
    log_d("min_sec = %#x\n",p_data->min_sec);
    log_d("bat_acc_volt = %d\n",p_data->bat_acc_volt);
    log_d("soc = %d\n",p_data->soc);
    log_d("soh = %d\n",p_data->soh);
    log_d("max_pack_volt = %d\n",p_data->max_pack_volt);
    log_d("max_pack_volt_no = %d\n",p_data->max_pack_volt_no);
    log_d("bus_volt = %d\n",p_data->bus_volt);
    log_d("load_volt = %d\n",p_data->load_volt);
    log_d("supply_volt = %d\n",p_data->supply_volt);
    log_d("chrg_cur_lim = %d\n",p_data->chrg_cur_lim);
    log_d("env_temp = %d\n",p_data->env_temp);
    log_d("chrg_ah = %d\n",p_data->chrg_ah);
    log_d("dsg_ah = %d\n",p_data->dsg_ah);
    log_d("max_cell_volt = %d\n",p_data->max_cell_volt[0]);
    log_d("max_cell_temp = %d\n",p_data->max_cell_temp[0]);
}




/**
 * @brief                故障调试接口
 * @return               返回结果空
 * @warning              测试调试使用
 */
int32_t run_data(int argc, char *argv[])
{
    if (argc < 2)
    {
        log_d("runDataErr\n");
        return SF_ERR_PARA;
    }
    bms_record_data_t bms_record_data = {0};
    uint16_t operation = 0;

    log_d("%s start\n", argv[0]);		//打印命令名称


	if(!strcmp(argv[1], "write"))		//写一条日志
	{
        bms_record_data = record_data_fill();
        if(0 == sdk_record_write(NORMAL_RECORD, 0, (uint8_t *)&bms_record_data, sizeof(bms_record_data_t)))
        {
            log_d("record_test write succ\n");
        }
        else
        {
            log_d("record_test write err\n");
        }
	}
    else if(!strcmp(argv[1], "read"))	//读日志
    {
        if (argc < 3)
        {
            log_d("runDataReadErr\n");
            return SF_ERR_PARA;
        }
        operation = atoi(argv[2]);
        if(-1 == bms_record_data_read(operation, &bms_record_data))
        {
            log_d("record_test read err\n");
        }
        else
       {
            sample_print(&bms_record_data);
       }
        
    }
    else if(!strcmp(argv[1], "delete"))
    {
        if(0 == bms_record_data_delte())
        {
            log_d("record_test delete succ\n");
        }
        else
        {
            log_d("record_test delete err\n");
        }
    }
    else if(!strcmp(argv[1], "fault_set"))
    {
        data_store_fault_set(DATA_STORE_RECORD, INVRLID);
        log_d("record_test fault set succ\n\r");
    }


    return 0;
}
MSH_CMD_EXPORT(run_data, <write/read/delete/fault_set>);



#if BMS_ATTR_PRINT_FLAG
/**
 * @brief                bms_attr数据打印
 * @return               返回结果空
 * @warning              测试调试使用
 */
void bms_attr_data_debug_printf(void)
{
    const bms_attr_t *p_bms_attr = get_bms_attr();
    log_d("total_over_vol_tip               APPER=%d, CANC=%d\n", p_bms_attr->safety.total_over_vol_tip.appear_value                ,p_bms_attr->safety.total_over_vol_tip.cancel_value               );  
    log_d("total_over_vol_alarm             APPER=%d, CANC=%d\n", p_bms_attr->safety.total_over_vol_alarm.appear_value              ,p_bms_attr->safety.total_over_vol_alarm.cancel_value             );  
    log_d("total_over_vol_protect           APPER=%d, CANC=%d\n", p_bms_attr->safety.total_over_vol_protect.appear_value            ,p_bms_attr->safety.total_over_vol_protect.cancel_value           );  
    log_d("total_under_vol_tip              APPER=%d, CANC=%d\n", p_bms_attr->safety.total_under_vol_tip.appear_value               ,p_bms_attr->safety.total_under_vol_tip.cancel_value              );  
    log_d("total_under_vol_alarm            APPER=%d, CANC=%d\n", p_bms_attr->safety.total_under_vol_alarm.appear_value             ,p_bms_attr->safety.total_under_vol_alarm.cancel_value            );  
    log_d("total_under_vol_protect          APPER=%d, CANC=%d\n", p_bms_attr->safety.total_under_vol_protect.appear_value           ,p_bms_attr->safety.total_under_vol_protect.cancel_value          );  
    log_d("chg_over_cur_tip                 APPER=%d, CANC=%d\n", p_bms_attr->safety.chg_over_cur_tip.appear_value                  ,p_bms_attr->safety.chg_over_cur_tip.cancel_value                 );  
    log_d("chg_over_cur_alarm               APPER=%d, CANC=%d\n", p_bms_attr->safety.chg_over_cur_alarm.appear_value                ,p_bms_attr->safety.chg_over_cur_alarm.cancel_value               );  
    log_d("chg_over_cur_protect             APPER=%d, CANC=%d\n", p_bms_attr->safety.chg_over_cur_protect.appear_value              ,p_bms_attr->safety.chg_over_cur_protect.cancel_value             );  
    log_d("dchg_over_cur_tip                APPER=%d, CANC=%d\n", p_bms_attr->safety.dchg_over_cur_tip.appear_value                 ,p_bms_attr->safety.dchg_over_cur_tip.cancel_value                );  
    log_d("dchg_over_cur_alarm              APPER=%d, CANC=%d\n", p_bms_attr->safety.dchg_over_cur_alarm.appear_value               ,p_bms_attr->safety.dchg_over_cur_alarm.cancel_value              );  
    log_d("dchg_over_cur_protect            APPER=%d, CANC=%d\n", p_bms_attr->safety.dchg_over_cur_protect.appear_value             ,p_bms_attr->safety.dchg_over_cur_protect.cancel_value            );  
    log_d("chg_over_cell_temp_tip           APPER=%d, CANC=%d\n",(int16_t)p_bms_attr->safety.chg_over_cell_temp_tip.appear_value            ,(int16_t)p_bms_attr->safety.chg_over_cell_temp_tip.cancel_value           );  
    log_d("chg_over_cell_temp_alarm         APPER=%d, CANC=%d\n",(int16_t)p_bms_attr->safety.chg_over_cell_temp_alarm.appear_value          ,(int16_t)p_bms_attr->safety.chg_over_cell_temp_alarm.cancel_value         );  
    log_d("chg_over_cell_temp_protect       APPER=%d, CANC=%d\n",(int16_t)p_bms_attr->safety.chg_over_cell_temp_protect.appear_value        ,(int16_t)p_bms_attr->safety.chg_over_cell_temp_protect.cancel_value       );  
    log_d("chg_under_cell_temp_tip          APPER=%d, CANC=%d\n",(int16_t)p_bms_attr->safety.chg_under_cell_temp_tip.appear_value           ,(int16_t)p_bms_attr->safety.chg_under_cell_temp_tip.cancel_value          );  
    log_d("chg_under_cell_temp_alarm        APPER=%d, CANC=%d\n",(int16_t)p_bms_attr->safety.chg_under_cell_temp_alarm.appear_value         ,(int16_t)p_bms_attr->safety.chg_under_cell_temp_alarm.cancel_value        );  
    log_d("chg_under_cell_temp_protect      APPER=%d, CANC=%d\n",(int16_t)p_bms_attr->safety.chg_under_cell_temp_protect.appear_value       ,(int16_t)p_bms_attr->safety.chg_under_cell_temp_protect.cancel_value      );  
    log_d("dchg_over_cell_temp_tip          APPER=%d, CANC=%d\n",(int16_t)p_bms_attr->safety.dchg_over_cell_temp_tip.appear_value           ,(int16_t)p_bms_attr->safety.dchg_over_cell_temp_tip.cancel_value          );  
    log_d("dchg_over_cell_temp_alarm        APPER=%d, CANC=%d\n",(int16_t)p_bms_attr->safety.dchg_over_cell_temp_alarm.appear_value         ,(int16_t)p_bms_attr->safety.dchg_over_cell_temp_alarm.cancel_value        );  
    log_d("dchg_over_cell_temp_protect      APPER=%d, CANC=%d\n",(int16_t)p_bms_attr->safety.dchg_over_cell_temp_protect.appear_value       ,(int16_t)p_bms_attr->safety.dchg_over_cell_temp_protect.cancel_value      );  
    log_d("dchg_under_cell_temp_tip         APPER=%d, CANC=%d\n",(int16_t)p_bms_attr->safety.dchg_under_cell_temp_tip.appear_value          ,(int16_t)p_bms_attr->safety.dchg_under_cell_temp_tip.cancel_value         );  
    log_d("dchg_under_cell_temp_alarm       APPER=%d, CANC=%d\n",(int16_t)p_bms_attr->safety.dchg_under_cell_temp_alarm.appear_value        ,(int16_t)p_bms_attr->safety.dchg_under_cell_temp_alarm.cancel_value       );  
    log_d("dchg_under_cell_temp_protect     APPER=%d, CANC=%d\n",(int16_t)p_bms_attr->safety.dchg_under_cell_temp_protect.appear_value      ,(int16_t)p_bms_attr->safety.dchg_under_cell_temp_protect.cancel_value     );  
    log_d("cell_temp_diff_tip               APPER=%d, CANC=%d\n", p_bms_attr->safety.cell_temp_diff_tip.appear_value                ,p_bms_attr->safety.cell_temp_diff_tip.cancel_value               );  
    log_d("cell_temp_diff_alarm             APPER=%d, CANC=%d\n", p_bms_attr->safety.cell_temp_diff_alarm.appear_value              ,p_bms_attr->safety.cell_temp_diff_alarm.cancel_value             );  
    log_d("cell_temp_diff_protect           APPER=%d, CANC=%d\n", p_bms_attr->safety.cell_temp_diff_protect.appear_value            ,p_bms_attr->safety.cell_temp_diff_protect.cancel_value           );  
    log_d("bat_soc_over_tip                 APPER=%d, CANC=%d\n", p_bms_attr->safety.bat_soc_over_tip.appear_value                  ,p_bms_attr->safety.bat_soc_over_tip.cancel_value                 );  
    log_d("bat_soc_over_alarm               APPER=%d, CANC=%d\n", p_bms_attr->safety.bat_soc_over_alarm.appear_value                ,p_bms_attr->safety.bat_soc_over_alarm.cancel_value               );  
    log_d("bat_soc_over_protect             APPER=%d, CANC=%d\n", p_bms_attr->safety.bat_soc_over_protect.appear_value              ,p_bms_attr->safety.bat_soc_over_protect.cancel_value             );  
    log_d("bat_soc_under_tip                APPER=%d, CANC=%d\n", p_bms_attr->safety.bat_soc_under_tip.appear_value                 ,p_bms_attr->safety.bat_soc_under_tip.cancel_value                );  
    log_d("bat_soc_under_alarm              APPER=%d, CANC=%d\n", p_bms_attr->safety.bat_soc_under_alarm.appear_value               ,p_bms_attr->safety.bat_soc_under_alarm.cancel_value              );  
    log_d("bat_soc_under_protect            APPER=%d, CANC=%d\n", p_bms_attr->safety.bat_soc_under_protect.appear_value             ,p_bms_attr->safety.bat_soc_under_protect.cancel_value            );  
    log_d("bat_soc_diff_tip                 APPER=%d, CANC=%d\n", p_bms_attr->safety.bat_soc_diff_tip.appear_value                  ,p_bms_attr->safety.bat_soc_diff_tip.cancel_value                 );  
 
}

void bms_attr_data_debug_printf2(void)
{
    const bms_attr_t *p_bms_attr = get_bms_attr();
    log_d("bat_soc_diff_tip                 APPER=%d, CANC=%d\n", p_bms_attr->safety.bat_soc_diff_tip.appear_value                  ,p_bms_attr->safety.bat_soc_diff_tip.cancel_value                 );  
    log_d("bat_soc_diff_alarm               APPER=%d, CANC=%d\n", p_bms_attr->safety.bat_soc_diff_alarm.appear_value                ,p_bms_attr->safety.bat_soc_diff_alarm.cancel_value               );  
    log_d("bat_soc_diff_protect             APPER=%d, CANC=%d\n", p_bms_attr->safety.bat_soc_diff_protect.appear_value              ,p_bms_attr->safety.bat_soc_diff_protect.cancel_value             );  
    log_d("ins_val_under_tip                APPER=%d, CANC=%d\n", p_bms_attr->safety.ins_val_under_tip.appear_value                 ,p_bms_attr->safety.ins_val_under_tip.cancel_value                );  
    log_d("ins_val_under_alarm              APPER=%d, CANC=%d\n", p_bms_attr->safety.ins_val_under_alarm.appear_value               ,p_bms_attr->safety.ins_val_under_alarm.cancel_value              );  
    log_d("ins_val_under_protect            APPER=%d, CANC=%d\n", p_bms_attr->safety.ins_val_under_protect.appear_value             ,p_bms_attr->safety.ins_val_under_protect.cancel_value            );  
    log_d("cell_over_vol_tip                APPER=%d, CANC=%d\n", p_bms_attr->safety.cell_over_vol_tip.appear_value                 ,p_bms_attr->safety.cell_over_vol_tip.cancel_value                );  
    log_d("cell_over_vol_alarm              APPER=%d, CANC=%d\n", p_bms_attr->safety.cell_over_vol_alarm.appear_value               ,p_bms_attr->safety.cell_over_vol_alarm.cancel_value              );  
    log_d("cell_over_vol_protect            APPER=%d, CANC=%d\n", p_bms_attr->safety.cell_over_vol_protect.appear_value             ,p_bms_attr->safety.cell_over_vol_protect.cancel_value            );  
    log_d("cell_under_vol_tip               APPER=%d, CANC=%d\n", p_bms_attr->safety.cell_under_vol_tip.appear_value                ,p_bms_attr->safety.cell_under_vol_tip.cancel_value               );  
    log_d("cell_under_vol_alarm             APPER=%d, CANC=%d\n", p_bms_attr->safety.cell_under_vol_alarm.appear_value              ,p_bms_attr->safety.cell_under_vol_alarm.cancel_value             );  
    log_d("cell_under_vol_protect           APPER=%d, CANC=%d\n", p_bms_attr->safety.cell_under_vol_protect.appear_value            ,p_bms_attr->safety.cell_under_vol_protect.cancel_value           );  
    log_d("cell_vol_diff_tip                APPER=%d, CANC=%d\n", p_bms_attr->safety.cell_vol_diff_tip.appear_value                 ,p_bms_attr->safety.cell_vol_diff_tip.cancel_value                );  
    log_d("cell_vol_diff_alarm              APPER=%d, CANC=%d\n", p_bms_attr->safety.cell_vol_diff_alarm.appear_value               ,p_bms_attr->safety.cell_vol_diff_alarm.cancel_value              );  
    log_d("cell_vol_diff_protect            APPER=%d, CANC=%d\n", p_bms_attr->safety.cell_vol_diff_protect.appear_value             ,p_bms_attr->safety.cell_vol_diff_protect.cancel_value            );  
    log_d("mod_temp_over_tip                APPER=%d, CANC=%d\n", p_bms_attr->safety.mod_temp_over_tip.appear_value                 ,p_bms_attr->safety.mod_temp_over_tip.cancel_value                );  
    log_d("mod_temp_over_alarm              APPER=%d, CANC=%d\n", p_bms_attr->safety.mod_temp_over_alarm.appear_value               ,p_bms_attr->safety.mod_temp_over_alarm.cancel_value              );  
    log_d("mod_temp_over_protect            APPER=%d, CANC=%d\n", p_bms_attr->safety.mod_temp_over_protect.appear_value             ,p_bms_attr->safety.mod_temp_over_protect.cancel_value            );  
    log_d("bat_over_vol_tip                 APPER=%d, CANC=%d\n", p_bms_attr->safety.bat_over_vol_tip.appear_value                  ,p_bms_attr->safety.bat_over_vol_tip.cancel_value                 );  
    log_d("bat_over_vol_alarm               APPER=%d, CANC=%d\n", p_bms_attr->safety.bat_over_vol_alarm.appear_value                ,p_bms_attr->safety.bat_over_vol_alarm.cancel_value               );  
    log_d("bat_over_vol_protect             APPER=%d, CANC=%d\n", p_bms_attr->safety.bat_over_vol_protect.appear_value              ,p_bms_attr->safety.bat_over_vol_protect.cancel_value             );  
    log_d("bat_under_vol_tip                APPER=%d, CANC=%d\n", p_bms_attr->safety.bat_under_vol_tip.appear_value                 ,p_bms_attr->safety.bat_under_vol_tip.cancel_value                );  
    log_d("bat_under_vol_alarm              APPER=%d, CANC=%d\n", p_bms_attr->safety.bat_under_vol_alarm.appear_value               ,p_bms_attr->safety.bat_under_vol_alarm.cancel_value              );  
    log_d("bat_under_vol_protect            APPER=%d, CANC=%d\n", p_bms_attr->safety.bat_under_vol_protect.appear_value             ,p_bms_attr->safety.bat_under_vol_protect.cancel_value            );  
    log_d("power_terminal_temp_over_tip     APPER=%d, CANC=%d\n", p_bms_attr->safety.power_terminal_temp_over_tip.appear_value      ,p_bms_attr->safety.power_terminal_temp_over_tip.cancel_value     );  
    log_d("power_terminal_temp_over_alarm   APPER=%d, CANC=%d\n", p_bms_attr->safety.power_terminal_temp_over_alarm.appear_value    ,p_bms_attr->safety.power_terminal_temp_over_alarm.cancel_value   );  
    log_d("power_terminal_temp_over_protect APPER=%d, CANC=%d\n", p_bms_attr->safety.power_terminal_temp_over_protect.appear_value  ,p_bms_attr->safety.power_terminal_temp_over_protect.cancel_value );  
}

void bms_attr_data_debug_printf3(void)
{
    const bms_attr_t *p_bms_attr = get_bms_attr();
    log_d("version        =%x\n", p_bms_attr->version        );      
    log_d("hall_enable    =%x\n", p_bms_attr->hall_enable    );      
    log_d("ex_addr        =%x\n", p_bms_attr->ex_addr        );      
    log_d("clu_pack_num   =%d\n", p_bms_attr->clu_pack_num   );      
    log_d("res            =%d\n", p_bms_attr->res            );      
    log_d("hall_range     =%d %d %d\n", p_bms_attr->hall_range[0] , p_bms_attr->hall_range[1], p_bms_attr->hall_range[2]);      
    log_d("pack_cell_num  =%d\n", p_bms_attr->pack_cell_num  );      
    log_d("cell_type      =%d\n", p_bms_attr->cell_type      );      
    log_d("bat_cap        =%d\n", p_bms_attr->bat_cap        );      
    log_d("cell_model     =%d\n", p_bms_attr->cell_model     );      
    log_d("manufactor     =%d\n", p_bms_attr->manufactor     );      
    log_d("fan_open_temp  =%d\n", p_bms_attr->fan_open_temp  );      
    log_d("fan_close_temp =%d\n", p_bms_attr->fan_close_temp );      
    log_d("full_chg_vol   =%d\n", p_bms_attr->full_chg_vol   );      
    log_d("empty_dchg_vol =%d\n", p_bms_attr->empty_dchg_vol );      
}

/**
 * @brief                故障调试接口
 * @return               返回结果空
 * @warning              测试调试使用
 */
int32_t store(int argc, char *argv[])
{
    if (argc < 2)
    {
        log_d("storeErr\n");
        return SF_ERR_PARA;
    }

    if (!strcmp(argv[1], "print"))
    {
        uint32_t id = atoi(argv[2]);
        if (id == 1)
        {
            bms_attr_data_debug_printf2();
        }
        else if (id == 2)
        {
            bms_attr_data_debug_printf3();
        }
        else
        {
            bms_attr_data_debug_printf();
        }
    }
    return 0;
}

MSH_CMD_EXPORT(store, <help/print 0-2>);
#endif
