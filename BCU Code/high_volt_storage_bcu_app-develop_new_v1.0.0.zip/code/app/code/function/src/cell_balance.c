/**
 * @file     cell_balance.c
 * @brief    电池簇被动均衡处理——BCU部分
 * @company  sofarsolar
 * @author   张智超
 * @version  V1.0.0
 * @date     2024/09/18
 */
#include "cell_balance.h"
#include "auto_addressing.h"
#include "sdk.h"
#include "inner_can_data.h"
#include "bmu_data.h"

//#define CELL_BAL_DEBUG

#ifdef CELL_BAL_DEBUG
	bool g_debug_bmu_status = false;
	uint16_t g_debug_min_cell_soc = 0;
#endif

static bool g_cluster_bmu_passive_data_rdy = false; // 簇内BMU被动均衡数据是否准备好

static int16_t g_cluster_bmu_data_rdy_cnt = 0;       // 本BCU内所有BMU被动均衡数据准备好，开始计数

static int16_t g_cluster_bcu_waiting_cnt = 0;		//BCU等待BMU数据，计数器
static bool g_cluster_waiting_flag = false;			//触发BCU等待BMU数据

static uint16_t g_min_cell_soc = 0xFFFF; // 电池包最小电压
static uint16_t g_pack_soc_array[PACK_MAX_NUM] = {0xFFFF};

/****************************汇总BMU均衡状态******************************/
//广播BCU下所有BMU的均衡数据状态——本簇内发送

/**
 * @brief   获取SOC数组中的最小电芯SOC
 *
 */
static uint16_t check_min_soc(uint16_t* soc_tab,uint8_t pack_num)
{
	uint16_t min_soc = 0xFFFF;
	uint8_t i = 0;
	
	for( i = 0; i < pack_num; i++)
	{
		if(0xFFFF == soc_tab[i])
		{
			return 0xFFFF;
		}
		
		if(min_soc > soc_tab[i])
		{
			min_soc = soc_tab[i];
		}
	}
	
	return min_soc;
}

/**
 * @brief   汇总BMU被动均衡状态
 *
 */
static void cluster_bmu_passive_data_collect(void)
{
    pack_info_t* pack_info = NULL;
    static uint8_t delay_time = 0;
    uint8_t i = 0;
    uint8_t pack_num = 0;
    static uint8_t flag[PACK_MAX_NUM] = {0};

    pack_num = auto_addressing_pack_num_get();  //电池包数量获取

	#ifdef CELL_BAL_DEBUG
		if (true == g_debug_bmu_status)
		{
			bmu_passive_data_rdy_cnt++;
			min_cell_soc = g_debug_min_cell_soc;
		}

		if ((bmu_passive_data_rdy_cnt == pack_num) &&
			(false == g_cluster_bmu_passive_data_rdy))
		{
			//本簇BMU数据准备好，发送本簇BCU准备好标志
			g_min_cell_soc = min_cell_soc;
			g_cluster_bmu_passive_data_rdy = true;
			g_cluster_bmu_data_rdy_cnt = CLUSTER_DATA_RDY_SEND_TIME_BASED_10ms;
		}
	#else
		if (0 == pack_num) //没有完成自动编址或者没有连接电池包，上报无效值，并且延时1秒
		{
			delay_time = PACK_BAL_INIT_DELAY_1S_BASED_10ms;
			return;
		}

		if (delay_time > 0)
		{
			delay_time--;
			return;
		}
		
		
		//BCU接受本簇的BMU被动均衡数据，存储到全局变量中
		for (i = 0; i < pack_num; i++)
		{
			pack_info = get_bmu_info(i);
			
			if (NULL == pack_info)
			{
				continue;
			}

			// 本簇内BMU的被动均衡数据准备完成，则记录对应电池包的最低电芯SOC
			if (true == pack_info->yc2[YC2_BMU_BAL_STATE])
			{
				if ((false == g_cluster_waiting_flag)
					&& (0 == g_cluster_bcu_waiting_cnt))
				{
					g_cluster_waiting_flag = true;
					g_cluster_bcu_waiting_cnt = CLUSTER_WATING_BMU_TIME_BASED_10ms;
				}
				
				g_pack_soc_array[i] = pack_info->yc2[YC2_MIN_CELL_SOC];
                
                if(flag[i] == 0)
                {
                    flag[i] = true;
                    log_d("pack%d soc:%d\n", i+1, g_pack_soc_array[i]);
                }
				
			}
		}
		
		
		if (false == g_cluster_bmu_passive_data_rdy)
		{
			//本簇BMU数据准备好，发送本簇BCU准备好标志
			g_min_cell_soc = check_min_soc(g_pack_soc_array,pack_num);
			
			if (0xFFFF == g_min_cell_soc)
			{
				return;
			}
			memset(flag,0,sizeof(flag));
			g_cluster_bmu_passive_data_rdy = true;
			log_d("clu_bmu_data_rdy is true!\n");
			g_cluster_bmu_data_rdy_cnt = CLUSTER_DATA_RDY_SEND_TIME_BASED_10ms;
		}
	#endif
}

/**
 * @brief   刷新本簇BMU准备完成时间、本堆BCU准备完成时间
 *
 */
static void cluster_refresh(void)
{
    if (g_cluster_bmu_data_rdy_cnt > 0)
    {
        g_cluster_bmu_data_rdy_cnt--;
    }

    if (g_cluster_bmu_data_rdy_cnt == 0)
    {
        g_cluster_bmu_passive_data_rdy = false;
    }
	
	if (g_cluster_bcu_waiting_cnt > 0)
	{
		g_cluster_bcu_waiting_cnt--;
	}
	
	if (0 == g_cluster_bcu_waiting_cnt)
	{
		g_cluster_waiting_flag = false;
		memset(&g_pack_soc_array,0xFFFF,sizeof(g_pack_soc_array));
	}
}

/**
 * @brief   返回本簇BMU被动均衡数据准备状态
 *
 */
bool cluster_passive_data_status_get(void)
{
    return g_cluster_bmu_passive_data_rdy;
}

/**
 * @brief   返回本簇所有BMU的最小电芯SOC
 *
 */
uint16_t cluster_min_cell_soc_get(void)
{
    return g_min_cell_soc;
}

/**
 * @brief   刷新BCU数据准备完成时间的计数
 *
 */
void cluster_passive_proc(void)
{
    cluster_bmu_passive_data_collect();
    cluster_refresh();
}

/**
 * @brief   调试接口，用于设置BMU被动均衡数据准备状态、状态发送持续时间
 *
 */
static void passive_bal_val_set(bool bmu_rdy_status, int8_t bmu_rdy_cnt)
{
    g_cluster_bmu_passive_data_rdy = bmu_rdy_status;
    g_cluster_bmu_data_rdy_cnt = bmu_rdy_cnt;
}

/**
 * @brief   调试接口，用于打印BMU被动均衡数据准备状态、状态发送持续时间
 *
 */
static void passive_bal_printf_p(void)
{
    log_d("bmu_passive_rdy_status:%d, bmu_passive_rdy_cnt:%d", g_cluster_bmu_passive_data_rdy, g_cluster_bmu_data_rdy_cnt);
}

/**
 * @brief        被动均衡数据打印
 * @param        cmd 功能参数
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
static int passive_bal(int argc, char *argv[])
{
    if(argc < 2)
    {
        log_d("[passive_bal] para err\n");
    }
    else
    {
        if (!strcmp(argv[1], "p"))
	    {
	        passive_bal_printf_p();
	    }
        else if (!strcmp(argv[1], "val"))
        {
            bool rdy_status = atoi(argv[2]);  // 设置参数1：簇内所有BMU 被动均衡数据准备状态
            int8_t rdy_cnt = atoi(argv[3]);  // 参数2: 状态发送持续时间
            passive_bal_val_set(rdy_status, rdy_cnt);
        }
    }

    return 0;
}
MSH_CMD_EXPORT(passive_bal, <p/val>);
