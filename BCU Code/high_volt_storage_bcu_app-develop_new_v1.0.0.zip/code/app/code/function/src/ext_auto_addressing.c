/**********************************************************************************
 * 创建时间: 2022-10-13 14:41:55
 * 邮箱: yuanzhihua@sofarsolar.com
 * 版本: V1.0
 * 描述:
 * 修改:
 *
 **********************************************************************************/

#include "ext_auto_addressing.h"
#include "sdk.h"
#include "sdk_dido.h"
#include "app_config.h"
#include "app_public.h"
#include "bmu_data.h"
#include "sample.h"
#include "bms_state.h"
#include "ate.h"
#include "public_flag.h"
#include "state_machine.h"

#define EXT_ADDR_DEBUG_ENABLE 1									///< 0禁止打印信息 1使能打印信息
#define EXT_ADDR_LOGA(...) log_d(__VA_ARGS__)
#define EXT_ADDR_LOGE(...) if (EXT_ADDR_DEBUG_ENABLE) log_e(__VA_ARGS__)
#define EXT_ADDR_LOGW(...) log_d(__VA_ARGS__)
#define EXT_ADDR_LOGI(...) if (EXT_ADDR_DEBUG_ENABLE) log_d(__VA_ARGS__)
#define EXT_ADDR_LOGD(...) if (EXT_ADDR_DEBUG_ENABLE) log_d(__VA_ARGS__)

/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
//                                          变量声明
/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */

enum // 通讯命令字定义
{
    CMD_START_ADDRESSING = 1, // 开始自动编址
    CMD_SET_OUTPUT,           // 设置从机输出口电平
    CMD_SET_SLAVE_ADDR,       // 设置从机地址
    CMD_CHECK_SLAVE_ADDR,     // 验证从机地址
    CMD_REQUEST,              // 请求编址
    CMD_HEARTBEAT,            // 地址心跳包
    CMD_CONFLICT,        // 地址冲突命令
    CMD_DI_CHECK,        // 编址电平检测
    CMD_OFF,                  // 关机
};

// 通讯信息数据结构
typedef struct
{
    uint8_t dst_type;
    uint8_t dst_addr; // 目标地址
    uint8_t src_type;
    uint8_t src_addr; // 源地址
    uint16_t cmd;      // 命令
    uint16_t data;     // 数据
} msg_t;

// 等待通信回复结构
typedef struct
{
    msg_t expect_rcv_msg;    // 编址命令下发后，期待收到的回复消息
    uint8_t cmd_reply_state;      // 等待的应答状态，1：接收到、0：未接收
    uint8_t need_reply_flag;   // 需要应答标志位，1：需要，0：不需要
    uint32_t reply_over_time_cnt;   // 应答接收超时计数
} ext_reply_msg_state_t;

// 等待pin校验结构
typedef struct
{
    uint32_t check_pin_over_timer;     // pin脚检测超时计数
    uint8_t check_pin_start_flag;      // 启动pin脚校验标志状态，1：完成、0：未完成
    uint8_t check_pin_over_time_cnt;   // 应答接收超时计数
    uint8_t check_success_cnt;         // 接收ok连续次数
    uint8_t check_pin_err_cnt;         // 电平引脚异常次数
    uint8_t start_pin_err_cnt;         // 上电初始编址电平异常
} ext_check_pin_state_t;

/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
//                                          外can自动编址参数定义
/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
// 自动编址状态机相关
typedef enum{
    EVT_ADDR_STA_CPL_SUC    = 0,    //
    EVT_ADDR_CONT_START    = 1,    //
    EVT_ADDR_FAULT = 2,
    ADDR_EVT_NUM = 3
}ext_addr_fsm_event_e;

typedef enum{
    STA_ADDR_INIT = 0,          ///< 状态机初始化
    STA_ADDR_DISEN,         ///< 未使能
    STA_SET_ADDR_PIN,        ///< 主机编址1
    STA_SET_SLAVE_ADDR,        ///< 主机编址2
    STA_WAIT_SLAVE_REPLY,        ///< 主机编址3
    STA_CHECK_CTL_PIN_STA,        ///< 主机编址4
    STA_MAS_ADDR_SUC, ///< 主机编址成功
    STA_MAS_ADDR_FAIL,  ///< 主机编址失败(重新编址)
    STA_SLA_ADRR,       // 从机编址
    ADDR_STA_NUM,
}ext_addr_fsm_state_e;

typedef struct
{
    uint8_t comm_state;
    uint16_t unlink_time_cnt;
}dev_comm_status;

typedef struct
{
    uint16_t   auto_addressing_enable;    // 使能自动编址
    ext_addressing_state_e addr_state;   // 编址状态
    ext_can_mac_type_e dev_type;
    uint8_t    addr_dev_num;   // 编址完成后设备数量
    uint8_t    dev_num;       // 设备数量
    uint16_t   master_addr_failed_cnt; // 主机编址失败次数
    uint16_t   addr_abnormal_cnt; // 主机编址异常连续统计次数
    uint8_t    have_dev_on_addressing; // 存在未编址设备
    uint8_t    address_conflict_flag;
    uint8_t    fault_id_conflict;    // 编址ID冲突
    uint8_t    fault_dev_unlink;    // 设备失联
    uint8_t    fault_dev_on_addressing; // 设备未被编址
    uint8_t    fault_dev_num_less; // 编址后设备数量减少异常
    uint32_t   fault_time_stamp;  // 编址异常判断时间戳
    uint8_t    mac_addr;         // 物理地址
}ext_master_addr_para; /* 动作action表描述 */

/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
//                                          函数声明
/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
static void report_di_status_deal(void);
static int32_t ext_master_send_addr_msg(msg_t *msg);                           //
static int32_t ext_slave_send_addr_msg(msg_t *msg);
static int32_t ext_addr_cmd_reply_check(uint32_t over_time); //
static void ext_send_heartbeat(void);
static void check_dev_comm_status(void);
static void ext_can_convert_to_addr_msg(uint32_t can_id, uint8_t *p_data , msg_t* addr_msg, uint8_t len);
static void ext_addr_rcv_msg(msg_t *p_rcv_msg);
static uint8_t sta_addr_init_run(void);
static uint8_t sta_addr_disen_entry(void);
static uint8_t sta_addr_disen_run(void);
static uint8_t sta_set_addr_pin_entry(void);
static uint8_t sta_set_addr_pin_run(void);
static uint8_t sta_set_slave_addr_run(void);
static uint8_t sta_wait_slave_reply_run(void);
static uint8_t sta_check_addr_pin_entry(void);
static uint8_t sta_check_addr_pin_run(void);
static uint8_t sta_master_addr_suc_entry(void);
static uint8_t sta_master_addr_suc_run(void);
static uint8_t sta_master_addr_failed_run(void);
static uint8_t sta_slave_addr_suc_entry(void);
static uint8_t sta_slave_addr_suc_run(void);

// 从机函数
static void ext_slave_send_cmd_request_addressing(void);

/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
//                                          变量定义
/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
static fsm_action_map_t g_ext_addr_act_map[ADDR_STA_NUM] = 
{
    [STA_ADDR_INIT]           = {NULL, sta_addr_init_run},
    [STA_ADDR_DISEN]          = {sta_addr_disen_entry, sta_addr_disen_run},
    [STA_SET_ADDR_PIN]        = {sta_set_addr_pin_entry, sta_set_addr_pin_run},
    [STA_SET_SLAVE_ADDR]      = {NULL, sta_set_slave_addr_run},
    [STA_WAIT_SLAVE_REPLY]    = {NULL, sta_wait_slave_reply_run},
    [STA_CHECK_CTL_PIN_STA]   = {sta_check_addr_pin_entry , sta_check_addr_pin_run},
    [STA_MAS_ADDR_SUC]        = {sta_master_addr_suc_entry, sta_master_addr_suc_run},
    [STA_MAS_ADDR_FAIL]       = {NULL, sta_master_addr_failed_run},
    [STA_SLA_ADRR]            = {sta_slave_addr_suc_entry, sta_slave_addr_suc_run},
};

static uint8_t g_ext_addr_evt_sta_map[ADDR_STA_NUM][ADDR_EVT_NUM] = 
{                          // EVT_ADDR_STA_CPL_SUC     EVT_ADDR_CONT_START  EVT_ADDR_FAULT
    [STA_ADDR_INIT]         = {STA_ADDR_DISEN,          STA_NULL,             STA_NULL},
    [STA_ADDR_DISEN]        = {STA_SET_ADDR_PIN,        STA_SLA_ADRR,         STA_NULL},
    [STA_SET_ADDR_PIN]      = {STA_SET_SLAVE_ADDR,      STA_NULL,             STA_NULL},
    [STA_SET_SLAVE_ADDR]    = {STA_WAIT_SLAVE_REPLY,    STA_NULL,             STA_NULL},
    [STA_WAIT_SLAVE_REPLY]  = {STA_CHECK_CTL_PIN_STA,   STA_SET_ADDR_PIN,     STA_NULL},
    [STA_CHECK_CTL_PIN_STA] = {STA_MAS_ADDR_SUC,        STA_SET_ADDR_PIN,     STA_NULL},
    [STA_MAS_ADDR_SUC]      = {STA_NULL,                STA_SLA_ADRR,         STA_MAS_ADDR_FAIL},
    [STA_MAS_ADDR_FAIL]     = {STA_ADDR_DISEN,          STA_NULL,             STA_NULL},
    [STA_SLA_ADRR]          = {STA_ADDR_DISEN,          STA_NULL,             STA_NULL},    
};

static uint8_t g_master_pin_cnt = 0;  // 主机引脚滤波计数
static uint8_t g_slave_pin_cnt = 0;   // 从机引脚滤波计数
static state_machine_t g_auto_addr_fsm = {0};
static const char* g_auto_addr_fsm_name = "exAddr";
static uint16_t g_fsm_time_cnt = 0; // 状态机，状态时间计数
static uint16_t g_master_addressing_step; // 主机编址步骤(0x01~0xA),最多10台BMU设备
static ext_reply_msg_state_t g_reply_msg_state = {0};  // 应答接收状态
static ext_check_pin_state_t g_check_pin_state = {0};  // 应答接收状态
static ext_master_addr_para g_ext_addr_para =
{
    .auto_addressing_enable = false,    // 使能自动编址
    .addr_state = EXT_ADDRESSING_DISENABLE,   // 编址状态
    .dev_type = EXT_CAN_MAC_NON,                      // 默认设备类型
    .addr_dev_num = 0,   // 编址完成后设备数量
    .dev_num = 0,        // 设备数量
    .master_addr_failed_cnt = 0, // 主机编址失败次数
    .addr_abnormal_cnt = 0,
    .have_dev_on_addressing = 0, // 存在未编址电池包
    .address_conflict_flag = 0,
    .fault_id_conflict = 0,    // 编址ID冲突
    .fault_dev_unlink = 0,    // 电池包失联
    .fault_dev_on_addressing = 0, // 电池包未被编址
    .fault_dev_num_less = 0, // 编址后电池包数量减少异常
    .fault_time_stamp = 0,  // 编址异常判断时间戳
    .mac_addr = BCU_EXT_SLV_ADDR_DFT,  // 默认地址
};
static dev_comm_status g_dev_comm_status[MAX_3PH_DEV_NUM] = {0};
static uint8_t g_dev_addr_pin_state_flag = false;     // 检测到dev有处于编址电平标志,
static uint8_t g_dev_addr_default_pin_timer_cnt = 0;  // 检测所有dev为默认电平周期
/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
//                                         硬件接口适配
/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */

// 编址电平配置，0:低电平，1:高电平
#define ADDRESSING_PIN_STATUS    (1)
// 读取输入PIN脚
#define INPUT_PIN_READ() 		(di_state_get(DI_2_CLUSTER_ADDR))//sdk_dido_read(DI_13_CLUSTER_IN)
// 设置输出PIN脚为高
#define OUTPUT_PIN_SET_HIGH() 	sdk_dido_write(DO_3_CLUSTER_ADDR, 1)
// 设置输出PIN脚为低
#define OUTPUT_PIN_SET_LOW() 	sdk_dido_write(DO_3_CLUSTER_ADDR, 0)
// 设置地址电平控制
#define OUTPUT_PIN_SET_ADDRESSING() (sdk_dido_write(DO_3_CLUSTER_ADDR, ADDRESSING_PIN_STATUS))
// 默认电平控制
#define OUTPUT_PIN_SET_DEFAULT()   (sdk_dido_write(DO_3_CLUSTER_ADDR, !ADDRESSING_PIN_STATUS))

#define ADDR_PIN_CHECK_ERR_TIME  (5)
/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
//                                        函数实现
/* --------------------------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------------------------- */
/**
 * @brief   检测所有设备编址电平为默认电平
 * @param   无
 * @return  无
 * @warning	 10ms任务
 */
static void dev_addr_di_default_pin_check(void)
{
    if (++g_dev_addr_default_pin_timer_cnt >= EXT_AUTO_ADDR_200MS_BASE_CNT)
    {
//        if (g_dev_addr_pin_state_flag != false)
//        {
//            EXT_ADDR_LOGE("[EADD]clean\n");
//        }
        g_dev_addr_pin_state_flag = false;
        g_dev_addr_default_pin_timer_cnt = 0;
    }
}

/**
 * @brief   外CAN(bcu)，自动编址初始化状态进入处理
 * @param   无
 * @return  返回执行结果 0Xff,无事件
 * @warning	无
 */
static uint8_t sta_addr_init_run(void)
{
    g_ext_addr_para.addr_state = EXT_ADDRESSING_DISENABLE; // 未使能自动编址
    return EVT_ADDR_STA_CPL_SUC;
}

/**
 * @brief   外CAN(bcu)，判断从机判断逻辑
 * @param   无
 * @return  返回执行结果 EVT_NULL,无事件
 * @warning	 0 == INPUT_PIN_READ() 情况下判断
 */
static uint8_t ext_addr_slave_dev_judge(void)
{
    uint8_t event = EVT_NULL;
    if (g_slave_pin_cnt >= EXT_AUTO_ADDR_200MS_BASE_CNT)
    {
        g_slave_pin_cnt = 0;
        event = EVT_ADDR_CONT_START;
    }
    return event;
}

/**
 * @brief   外CAN(bcu)，判断主机判断逻辑
 * @param   无
 * @return  返回执行结果 EVT_NULL,无事件
 * @warning	 1 == INPUT_PIN_READ() 情况下判断
 */
static uint8_t ext_addr_master_dev_judge(void)
{
    uint8_t event = EVT_NULL;
    // 主机判断逻辑
    if (g_master_pin_cnt >= EXT_AUTO_ADDR_1S_TIMER)
    {
        g_fsm_time_cnt++;
        g_master_pin_cnt = EXT_AUTO_ADDR_1S_TIMER;
        if ((g_fsm_time_cnt % EXT_AUTO_ADDR_100MS_BASE_CNT)== 0)  // 每100ms发送一次启动设备编址
        {
            // 主机发送启动编址
            msg_t send_msg;
            send_msg.src_addr = BCU_EXT_MASTER_CAN_ADDR;
            send_msg.dst_addr = BROCAST_DEVICE_ADDRESS;
            send_msg.cmd = CMD_START_ADDRESSING;
            send_msg.data = 1;
            ext_master_send_addr_msg(&send_msg);
            report_di_status_deal();
        }
        if ((g_fsm_time_cnt % EXT_AUTO_ADDR_100MS_BASE_CNT) == 0) // 每100ms确定电平状态
        {
            if (g_dev_addr_pin_state_flag != 0)
            {
                g_fsm_time_cnt = 0;
                if (g_check_pin_state.start_pin_err_cnt < ADDR_PIN_CHECK_ERR_TIME)
                {
                    g_check_pin_state.start_pin_err_cnt++;
                }
                // log_e("err++\n");
            }
            else
            {
                g_check_pin_state.start_pin_err_cnt = 0;
            }
        }
        // 持续1s后，认为此设备为主机
        if (g_fsm_time_cnt > EXT_AUTO_ADDR_1S_TIMER)
        {
            event = EVT_ADDR_STA_CPL_SUC;
            g_ext_addr_para.mac_addr = 1;
            g_master_pin_cnt = 0;
            g_master_addressing_step = 1;
            EXT_ADDR_LOGE("[EADD]dev,addr\n");
            g_ext_addr_para.master_addr_failed_cnt = 0;
            g_ext_addr_para.dev_type = EXT_CAN_MAC_MASTER;
            ext_can_set_filter(g_ext_addr_para.mac_addr);
        }
    }
    else
    {
        g_fsm_time_cnt = 0;
    }
    return event;
}

/**
 * @brief   外CAN(bcu)，未使能自动编状态进入处理
 * @param   无
 * @return  返回执行结果 0Xff,无事件
 * @warning	无
 */
static uint8_t sta_addr_disen_entry(void)
{
    g_fsm_time_cnt = 0;
    // 相关参数初始化
    g_ext_addr_para.addr_dev_num = 0;   // 编址完成后设备数量
    g_ext_addr_para.master_addr_failed_cnt = 0; // 主机编址失败次数
    g_ext_addr_para.have_dev_on_addressing = 0; // 存在未编址设备
    g_ext_addr_para.address_conflict_flag = 0;
    g_ext_addr_para.fault_id_conflict = 0;    // 编址ID冲突
    g_ext_addr_para.fault_dev_unlink = 0;    // 设备失联
    g_ext_addr_para.fault_dev_on_addressing = 0; // 设备未被编址
    g_ext_addr_para.fault_dev_num_less = 0; // 编址后设备数量减少异常	
    g_ext_addr_para.fault_time_stamp = 0;  // 编址异常判断时间戳
    g_ext_addr_para.mac_addr = BCU_EXT_SLV_ADDR_DFT;  // 默认地址
    g_ext_addr_para.dev_type = EXT_CAN_MAC_NON;
    g_master_pin_cnt = 0;
    g_slave_pin_cnt = 0;
    return EVT_NULL;
}

/**
 * @brief   外CAN(bcu)，未使能自动编状态运行处理
 * @param   无
 * @return  返回执行结果 0:初始化完成事件
 * @warning	无
 */
static uint8_t sta_addr_disen_run(void)
{
    uint8_t event = EVT_NULL;
    if (!g_ext_addr_para.auto_addressing_enable)
    {
        OUTPUT_PIN_SET_HIGH();  // 默认电平
        return event;
    }
    // 可能导致电池包激活，外can自动编址功能不使能，不设置电平
    OUTPUT_PIN_SET_LOW();  // 设置编址电平，所有从机组件编址IN检测都为设置电平，主机为默认电平
    // 从机判断逻辑
    if (0 == INPUT_PIN_READ()) // 考虑是否通过组内编址IN下降沿激活判断 TODO
    {
        g_master_pin_cnt = 0;
        g_slave_pin_cnt++;
        event = ext_addr_slave_dev_judge();
    }
    else
    {
        // 主机判断逻辑
        g_master_pin_cnt++;
        g_slave_pin_cnt = 0;
        event = ext_addr_master_dev_judge();
    }
    return event;
}

/**
 * @brief   外CAN(bcu)，未使能自动编状态进入处理
 * @param   无
 * @return  返回执行结果 0Xff,无事件
 * @warning	无
 */
static uint8_t sta_set_addr_pin_entry(void)
{
    g_fsm_time_cnt = 0;
    if (g_master_addressing_step == 1)
    {
        OUTPUT_PIN_SET_ADDRESSING();
    }
    else    // 发送编址输出引脚，输出设置命令
    {
        msg_t send_msg;
        send_msg.src_addr = BCU_EXT_MASTER_CAN_ADDR;
        send_msg.dst_addr = g_master_addressing_step;
        send_msg.cmd = CMD_SET_OUTPUT;
        send_msg.data = ADDRESSING_PIN_STATUS;
        ext_master_send_addr_msg(&send_msg);
    }
    report_di_status_deal();
    return EVT_NULL;
}

/**
 * @brief   外CAN(bcu)，未使能自动编状态运行处理
 * @param   无
 * @return  返回执行结果 0:初始化完成事件
 * @warning	无
 */
static uint8_t sta_set_addr_pin_run(void)
{
    uint8_t event = EVT_NULL;
    g_ext_addr_para.addr_state = EXT_ADDRESSING_ING;  // 正在编址
    if (++g_fsm_time_cnt > 15)                    // 延时150ms
    {
        EXT_ADDR_LOGE("[EADD]set dev%d out_pi_%d ...\n", g_master_addressing_step, ADDRESSING_PIN_STATUS);
        event = EVT_ADDR_STA_CPL_SUC;
    }
    return event;
}
/**
 * @brief   外CAN(bcu)，未使能自动编状态进入处理
 * @param   无
 * @return  返回执行结果 0:正常；<0:异常
 * @warning	无
 */
static uint8_t sta_set_slave_addr_run(void)
{
    msg_t send_msg;
    send_msg.cmd = CMD_SET_SLAVE_ADDR;
    send_msg.src_addr = BCU_EXT_MASTER_CAN_ADDR;
    send_msg.dst_addr = BROCAST_DEVICE_ADDRESS;
    send_msg.data = g_master_addressing_step + 1;
    ext_master_send_addr_msg(&send_msg);
    EXT_ADDR_LOGE("[EADD]set dev%d addr..\n", g_master_addressing_step + 1);
//    int16_t di_status = 0;
//    for (uint8_t dev_id = 1; dev_id < g_master_addressing_step; dev_id++)
//    {
//        di_status = bmu_di_status_get(dev_id, BMS_DI_DI_INPUT_TYPE);
//        if ((ADDRESSING_PIN_STATUS) == di_status)
//        {
//            EXT_ADDR_LOGE("[EADD]oth dev%d di_pi_%d\n", dev_id + 1, ADDRESSING_PIN_STATUS);
//        }
//    }
    g_reply_msg_state.reply_over_time_cnt = 0;    // 发送完地址设置消息后，立即给预期接收消息赋值
    g_reply_msg_state.cmd_reply_state = 0;
    g_reply_msg_state.need_reply_flag = 1;
    g_reply_msg_state.expect_rcv_msg.src_addr = g_master_addressing_step + 1;
    g_reply_msg_state.expect_rcv_msg.dst_addr = BCU_EXT_MASTER_CAN_ADDR;
    g_reply_msg_state.expect_rcv_msg.cmd = CMD_SET_SLAVE_ADDR;
    g_reply_msg_state.expect_rcv_msg.data = 1;
    g_check_pin_state.check_pin_over_timer = 0;
    g_check_pin_state.check_pin_over_time_cnt = 0;
    g_check_pin_state.check_pin_start_flag = 0;
    return EVT_ADDR_STA_CPL_SUC;
}

/**
 * @brief   外CAN(bcu)，未使能自动编址状态运行处理
 * @param   无
 * @return  返回执行结果 0:初始化完成事件
 * @warning	无
 */
static uint8_t sta_wait_slave_reply_run(void)
{
    uint8_t event = EVT_NULL;
    int32_t res = ext_addr_cmd_reply_check(50); // 500ms超时
    if (res == 1)
    {
        g_check_pin_state.check_pin_start_flag = true;
        EXT_ADDR_LOGE("[EADD]dev%d reply ok\n", g_master_addressing_step + 1);
        event = EVT_ADDR_STA_CPL_SUC; // 应答结束

    }
    else if (res == -1)
    {
        if (++g_ext_addr_para.master_addr_failed_cnt >= 3)
        { // 编址从机3次没有回复视为编址完成。
            g_check_pin_state.check_pin_start_flag = false; // 最后一个电池包无需校验pin
            event = EVT_ADDR_STA_CPL_SUC; // 应答结束
        }
        else
        {
            event = EVT_ADDR_CONT_START; // 给从机重发编址
        }
        EXT_ADDR_LOGE("[EADD]dev%d reply cnt = %d\n", g_master_addressing_step + 1, g_ext_addr_para.master_addr_failed_cnt);
    }
    return event;
}

/**
 * @brief   外CAN(bcu)，设置上一个pack默认电平
 * @param   无
 * @return  无返回执行结果
 * @warning	无
 */
static void last_pack_do_pin_default_set(void)
{
    msg_t send_msg;
    send_msg.src_addr = BCU_EXT_MASTER_CAN_ADDR;
    send_msg.cmd = CMD_SET_OUTPUT;
    send_msg.dst_addr = 0;
    send_msg.data = !ADDRESSING_PIN_STATUS;
//    if (send_msg.dst_addr == 1)    // BCU主机控制BMU从机编址输入电平拉低
//    {
//        OUTPUT_PIN_SET_DEFAULT();
//    }
//    else
//    {
//        ext_master_send_addr_msg(&send_msg);
//    }
    OUTPUT_PIN_SET_DEFAULT();
    ext_master_send_addr_msg(&send_msg);
    report_di_status_deal();
}

/**
 * @brief   内网CAN(bmu/bcu)，检测电池包pin脚控制状态进入任务
 * @param   无
 * @return  返回执行结果 0:正常；<0:异常
 * @warning	无 g_check_pin_state
 */
static uint8_t sta_check_addr_pin_entry(void)
{
    uint8_t event = EVT_NULL;
    g_check_pin_state.check_pin_over_timer = 0;
    g_check_pin_state.check_pin_over_time_cnt = 0;
    g_check_pin_state.check_success_cnt = 0;
    // 进入检测函数，先调用io控制
    last_pack_do_pin_default_set();
    return event;
}

/**
 * @brief   外网CAN(bcu)，检测电池包pin脚控制状态处理任务
 * @param   无
 * @return  返回执行结果 0:正常；<0:异常
 * @warning	无
 */
static uint8_t sta_check_addr_pin_run(void)
{
    uint8_t event = EVT_NULL;
    // 无需检测
    if ((!g_check_pin_state.check_pin_start_flag))
    {
        event = EVT_ADDR_STA_CPL_SUC;
        return event;
    }
    uint8_t default_level_flag = false;
//    for (uint8_t i = 1; i <= g_master_addressing_step; i++)
//    {
//        if ((ADDRESSING_PIN_STATUS) == bmu_di_status_get(i, BMS_DI_DI_INPUT_TYPE))
//        {
//            default_level_flag = true;
//        }
//    }
    if (false == g_dev_addr_pin_state_flag && false == default_level_flag)
    {
        g_check_pin_state.check_success_cnt++;
    }
    else
    {
        g_check_pin_state.check_success_cnt = 0;
    }
    
    g_check_pin_state.check_pin_over_timer++;
    if (g_check_pin_state.check_pin_over_timer >= EXT_AUTO_ADDR_1S_TIMER)
    {
        last_pack_do_pin_default_set();
        g_check_pin_state.check_pin_over_time_cnt++;
        g_check_pin_state.check_pin_over_timer = 0;
        if (g_check_pin_state.check_pin_over_time_cnt >= 3)
        {
            g_check_pin_state.check_pin_err_cnt++;
            event = EVT_ADDR_STA_CPL_SUC;
        }
        EXT_ADDR_LOGE("[EADD]check_o_tim%d\n", g_check_pin_state.check_pin_over_time_cnt);
        EXT_ADDR_LOGE("[EADD]lv = %d,pin_sta= %d\n", default_level_flag, g_dev_addr_pin_state_flag);
    }
    
    if (g_check_pin_state.check_success_cnt > 3) // 连续校验3次
    {
        EXT_ADDR_LOGE("[EADD]dev%d di_sta%d\n", g_master_addressing_step + 1, !ADDRESSING_PIN_STATUS);
        g_master_addressing_step++;
        g_check_pin_state.check_pin_err_cnt = 0;
        if (g_master_addressing_step < MAX_3PH_DEV_NUM)
        {
            event = EVT_ADDR_CONT_START; // 给下一个从机编址
            g_ext_addr_para.master_addr_failed_cnt = 0;
            g_check_pin_state.check_pin_over_time_cnt = 0;
        }
        else
        {
            event = EVT_ADDR_STA_CPL_SUC; // 编址结束
        }
    }
    return event;
}

/**
 * @brief   内网CAN(bmu/bcu)，自动编址完成状态进入处理
 * @param   无
 * @return  返回执行结果 0:正常；<0:异常
 * @warning	无
 */
static uint8_t sta_master_addr_suc_entry(void)
{
    g_ext_addr_para.addr_dev_num = g_master_addressing_step;
    EXT_ADDR_LOGE("[EADD]succee.devnum %d!\n", g_ext_addr_para.addr_dev_num);
    memset(g_dev_comm_status, 0, sizeof(g_dev_comm_status));
    g_ext_addr_para.have_dev_on_addressing = 0;
    g_ext_addr_para.address_conflict_flag = 0;
    g_ext_addr_para.fault_time_stamp = sdk_tick_get();
    g_slave_pin_cnt = 0;
    return EVT_NULL;
}

/**
 * @brief   内网CAN(bmu/bcu)，，自动编址完成状态运行处理
 * @param   无
 * @return  返回执行结果 0:初始化完成事件
 * @warning	无
 */
static uint8_t sta_master_addr_suc_run(void)
{
    uint8_t event = EVT_NULL;
    ext_send_heartbeat();   // 定时发送心跳
    check_dev_comm_status(); // 检测从机通信状态
    // 重新编址后PACK变少了
    if (g_ext_addr_para.dev_num <= g_ext_addr_para.addr_dev_num)
    {
        g_ext_addr_para.dev_num = g_ext_addr_para.addr_dev_num;
        g_ext_addr_para.fault_dev_num_less = false;
        
    }
    else
    {
        g_ext_addr_para.fault_dev_num_less = true;
        EXT_ADDR_LOGE("[EADD]pack %d less %d\n",g_ext_addr_para.addr_dev_num, g_ext_addr_para.dev_num);
        event = EVT_ADDR_FAULT;
    }

    // 重新编址后，1秒没有地址冲突、未被编址的电池包
    if (sdk_is_tick_over(g_ext_addr_para.fault_time_stamp, os_tick_from_millisecond(1000)))
    {
        g_ext_addr_para.fault_time_stamp = sdk_tick_get();
        g_ext_addr_para.fault_id_conflict = 0;
        g_ext_addr_para.fault_dev_on_addressing = 0;
        g_ext_addr_para.addr_state = EXT_ADDRESSING_FINISH; // 编址完成
        g_ext_addr_para.addr_abnormal_cnt = 0;
        g_check_pin_state.check_pin_err_cnt = 0;
        g_check_pin_state.start_pin_err_cnt = 0;
    }

    // 电池包地址冲突
    if (g_ext_addr_para.address_conflict_flag)
    {
        EXT_ADDR_LOGE("[EADD]id cft\n");
        g_ext_addr_para.fault_id_conflict = 1;
        event = EVT_ADDR_FAULT;
    }

    // 存在未被编址的电池包
    if (g_ext_addr_para.have_dev_on_addressing)
    {
        EXT_ADDR_LOGE("[EADD]dev on add\n");
        g_ext_addr_para.fault_dev_on_addressing = 1;
        event = EVT_ADDR_FAULT;
    }

    if (g_check_pin_state.check_pin_err_cnt != 0 ||
        g_check_pin_state.start_pin_err_cnt != 0)
    {
        event = EVT_ADDR_FAULT;
        EXT_ADDR_LOGE("[EADD]low lv err\n");
    }
    // 检测电平被拉低，表示新主机出现
    if (0 == INPUT_PIN_READ())
    {
        g_slave_pin_cnt++;
        if (g_slave_pin_cnt > EXT_AUTO_ADDR_1S_TIMER)
        {
            g_slave_pin_cnt =0;
            event = EVT_ADDR_CONT_START;
        }
    }
    else
    {
        g_slave_pin_cnt = 0;
    }
    return event;
}

/**
 * @brief   内网CAN(bmu/bcu)，自动编址完成状态进入处理
 * @param   无
 * @return  返回执行结果 0:正常；<0:异常
 * @warning	无
 */
static uint8_t sta_master_addr_failed_run(void)
{
    g_ext_addr_para.addr_dev_num = 0;
    g_ext_addr_para.dev_num = 0; // 屏蔽电池包个数减少反复编址异常
    g_ext_addr_para.addr_abnormal_cnt++;
    g_ext_addr_para.addr_state = EXT_ADDRESSING_ING; // 编址中 
    return EVT_ADDR_STA_CPL_SUC;
}

/**
 * @brief   外网CAN(bcu)，从机状态进入
 * @param   无
 * @return  返回执行结果 0:正常；<0:异常
 * @warning	无
 */
static uint8_t sta_slave_addr_suc_entry(void)
{
    OUTPUT_PIN_SET_DEFAULT();
    g_ext_addr_para.mac_addr = BCU_EXT_SLV_ADDR_DFT;
    g_ext_addr_para.dev_type = EXT_CAN_MAC_SLAVER;
    g_ext_addr_para.addr_abnormal_cnt = 0;
    g_check_pin_state.check_pin_err_cnt = 0;
    g_check_pin_state.start_pin_err_cnt = 0;
    EXT_ADDR_LOGE("[EADD]sla\n");
    return EVT_NULL;
}

/**
 * @brief   外网CAN(bcu)，从机状态处理
 * @param   无
 * @return  返回执行结果 0:正常；<0:异常
 * @warning	无
 */
static uint8_t sta_slave_addr_suc_run(void)
{
    uint8_t event = EVT_NULL;
    
    if (BCU_EXT_SLV_ADDR_DFT == g_ext_addr_para.mac_addr)
    {
        // 发送请求编址命令
        ext_slave_send_cmd_request_addressing();
        g_ext_addr_para.addr_state = EXT_ADDRESSING_ING;
        return event;
    }

    ext_send_heartbeat();   // 定时发送心跳
    check_dev_comm_status(); // 检测从机通信状态
    // 若出现主机下电，后接入新设备后，重新启动编址
    if (g_ext_addr_para.fault_dev_unlink)
    {
        if ((g_ext_addr_para.address_conflict_flag || g_ext_addr_para.have_dev_on_addressing))
        {
            // log_e("address_conflict_flag =%d, have_dev_on_addressing = %d\n", g_ext_addr_para.address_conflict_flag ,g_ext_addr_para.have_dev_on_addressing);
            if (1 == INPUT_PIN_READ()) // 切换成为主机
            {
                event = EVT_ADDR_STA_CPL_SUC;
            }
            g_ext_addr_para.addr_state = EXT_ADDRESSING_DISENABLE;
        }
    }
    else
    {
        g_ext_addr_para.addr_state = EXT_ADDRESSING_FINISH;
    }
    return event;
}

static void ext_auto_addr_fsm_init(void)
{
    state_machine_init(&g_auto_addr_fsm, g_auto_addr_fsm_name, g_ext_addr_act_map, (uint8_t *)g_ext_addr_evt_sta_map,
        ADDR_EVT_NUM, ADDR_STA_NUM, STA_ADDR_INIT);
}

// 心跳帧是否需要滤波是否屏蔽， 由于此逻辑dcdc编址有一样的逻辑 TODO
// 超级注意：如果canid高16bit需要更新check_ext_pack_address()
static void ext_auto_addr_can_register(void)
{
//    uint16_t rec_msg_amount = 0;
//    can_frame_id_u frame_id[] = 
//    {
//        // res     prio(优先级)      type(帧类型)  flag（1:连续，0:非）, fun_code,    dst_type dst_addr, src_type, src_addr
////        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_HEAT, .bit.type= SOFAR_CAN_DATA,   .bit.flag= 0, .bit.fun_code= FUN_HEAT_BEAT,
////         .bit.dst_type= DEV_BCU, .bit.dst_addr= 0, .bit.src_type= DEV_BCU, .bit.src_addr =0}, // 0x197f00a0
//        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_DATA, .bit.type= SOFAR_CAN_DATA,   .bit.flag= 0, .bit.fun_code= FUN_DATA_YX,
//         .bit.dst_type= DEV_BCU, .bit.dst_addr= 0, .bit.src_type= DEV_BCU, .bit.src_addr =0}, // 0x19818080
//        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_WR_PARA, .bit.type= SOFAR_CAN_DATA,   .bit.flag= 0, .bit.fun_code= FUN_PARA_SET,
//         .bit.dst_type= DEV_BCU, .bit.dst_addr= 0, .bit.src_type= DEV_BCU, .bit.src_addr =0}, // 0xd148080
//        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_REPLAY, .bit.type= SOFAR_CAN_REPLAY,   .bit.flag= 0, .bit.fun_code= FUN_PARA_SET,
//         .bit.dst_type= DEV_BCU, .bit.dst_addr= 0, .bit.src_type= DEV_BCU, .bit.src_addr =0}, // 0x1b1480a0
//    };
//    can_sofar_rcv_reg_t can_rxmsg_tab[] = // 接收上位机或BCU的数据
//    {
//        // {frame_id[0].id_val, 0x0000FFFF, ext_can_mac_addr_rcv_callback},  // 0x197f00a0 BMU上送心跳数据处理,广播所有设备，A0：源设备类型，设备地址1~10
//        {frame_id[0].id_val, 0x00001F1F, ext_can_mac_addr_rcv_callback,},  // 0x19818080 遥测数据
//        {frame_id[1].id_val, 0x00001F1F, ext_can_mac_addr_rcv_callback,},  // 0x19148080 参数设置 20功能码
//        {frame_id[2].id_val, 0x00001F1F, ext_can_mac_addr_rcv_callback,},  // 0x1b1480a0 参数设置回复 20功能码
//    };
//    // 注册接收的数据
//    rec_msg_amount = sizeof(can_rxmsg_tab)/sizeof(can_sofar_rcv_reg_t);
//    int32_t ret = can_sofar_register_receive_frame(SDK_EXTERNAL_CAN_PORT, can_rxmsg_tab, rec_msg_amount);
//    if (ret < 0)
//    {
//        EXT_ADDR_LOGE("[EADD]reg err%d\n", ret);
//    }
}


/******************************************外can物理编址，主从机发送函数-start*******************************/
/**
 * @brief   外网CAN(bcu)，主机发送自动编址控制指令
 * @param   无
 * @return  0:发送成功，-1：发送失败
 * @warning	无
 */
static int32_t ext_master_send_addr_msg(msg_t *msg)
{
    uint8_t data[8] = {0};
    can_frame_id_u tx_frame_id = {0};
    ext_can_mas_addr_set_cmd_u master_state = EXT_NON_MAS_CAN_ADDR_SET_CMD;
    uint8_t set_addr = BROCAST_DEVICE_ADDRESS;
    // THIS_LOGD("send addr msg cmd=%d, src=%d, dst=%d, data=%d\n", msg->cmd, msg->src_addr, msg->dst_addr, msg->data);
    switch (msg->cmd)
    {
        case CMD_START_ADDRESSING:
            master_state = EXT_CAN_MAS_SET_START_ADDR_CMD;
            break;
        case CMD_SET_OUTPUT:
            if (msg->data == 1)
            {
                master_state = EXT_CAN_MAS_ADDR_SET_IO_HIGH_CMD;
            }
            else if (msg->data == 0)
            {
                master_state = EXT_CAN_MAS_ADDR_SET_IO_LOW_CMD;
            }
            break;
        case CMD_SET_SLAVE_ADDR:
            master_state  = EXT_CAN_MAS_SET_ADDR_CMD;
            set_addr = msg->data;
            break;
        default:
            return -1;
    }
    tx_frame_id.bit.src_addr = msg->src_addr;
    tx_frame_id.bit.src_type = DEV_BCU;
    tx_frame_id.bit.dst_addr = msg->dst_addr;
    tx_frame_id.bit.dst_type = DEV_BCU;
    tx_frame_id.bit.fun_code = FUNC_BCU_SELF_CTL;
    tx_frame_id.bit.prio = SOFAR_CAN_PRI_LOW_H;

    data[0] = (uint8_t)(set_addr); // 设置参数数据
    data[1] = (uint8_t)(master_state); // 设置参数数据
    data[2] = 0;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_frame_id.id_val, data, 3);
    return 0;
}

/**
 * @brief   外网CAN(bcu)，从机发送自动编址状态
 * @param   无
 * @return  0:发送成功，-1：发送失败
 * @warning	无
 */
static int32_t ext_slave_send_addr_msg(msg_t *msg)
{
    uint8_t data[8] = {0};
    can_frame_id_u tx_frame_id = {0};
    ext_can_recv_sla_addr_cmd_u sla_state = EXT_NON_CAN_RX_SLA_ADDR_SET_CMD;
    // EXT_ADDR_LOGE("send addr msg cmd=%d, src=%d, dst=%d, data=%d\n", msg->cmd, msg->src_addr, msg->dst_addr, msg->data);
    switch (msg->cmd)
    {
        case CMD_REQUEST:
            sla_state = EXT_CAN_RX_SLA_SET_START_ADDR_CMD;
            break;
        case CMD_CONFLICT:
            sla_state = EXT_CAN_RX_SLA_ADDR_CONFLICT_CMD;
            break;
        case CMD_SET_SLAVE_ADDR:
            sla_state  = EXT_CAN_RX_SLA_SET_ADDR_CMD;
            break;
        default:
            return -1;
    }
    tx_frame_id.bit.src_addr = msg->src_addr;
    tx_frame_id.bit.src_type = DEV_BCU;
    tx_frame_id.bit.dst_addr = msg->dst_addr;
    tx_frame_id.bit.dst_type = DEV_BCU;
    tx_frame_id.bit.fun_code = FUNC_BCU_SELF_REPLAY;
    tx_frame_id.bit.prio = SOFAR_CAN_PRI_LOW_H;
    
    data[0] = g_ext_addr_para.mac_addr;
    data[1] = sla_state;
    data[2] = 0;
    can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_frame_id.id_val, data, 3); 
    return 0;
}

/**
 * @brief   外网CAN(bcu)，主从定时广播心跳包，用于检测地址冲突与从机失联
 * @param   无
 * @return  无
 * @warning	无
 */
static void ext_send_heartbeat(void)
{
    uint8_t data[8] = {0};
    can_frame_id_u tx_frame_id = {0};
    static uint32_t timestamp = 0;
    if (sdk_is_tick_over(timestamp, os_tick_from_millisecond(1000)))
    { // 广播心跳包
        timestamp = sdk_tick_get();
        tx_frame_id.bit.src_addr = g_ext_addr_para.mac_addr;
        tx_frame_id.bit.src_type = DEV_BCU;
        tx_frame_id.bit.dst_addr = BROCAST_DEVICE_ADDRESS;
        tx_frame_id.bit.dst_type = 0;
        tx_frame_id.bit.fun_code = FUNC_INV_HEART_BEAT;
        tx_frame_id.bit.prio = SOFAR_CAN_PRI_LOW_H;
        // 心跳内容
//        data[0] = PRODUCT_BAT_BIG_TYPE;
//        data[1] = LOW_BYTE(BAT_PRODUCT_CBS5K_BCU);
//        data[2] = HIGH_BYTE(BAT_PRODUCT_CBS5K_BCU);
//        data[3] = EXT_SOFAR_HIGH_VOLT_PROTOCOL;
        //THIS_LOGD("send heartbeat\n");
        can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, tx_frame_id.id_val, data, 4);
    }
}

/**
 * @brief   外网CAN(bcu)，主从机编址输入电平变化上报状态
 * @param   无
 * @return  无
 * @warning	无
 */
static void ext_send_dev_di_status(void)
{
    // TODO 这里需要完善外can协议才可以实现
//    msg_t send_msg;
//    send_msg.cmd = CMD_DI_CHECK;
//    send_msg.src_addr = g_ext_addr_para.mac_addr;
//    if (EXT_CAN_MAC_SLAVER == g_ext_addr_para.dev_type)
//    {
//        send_msg.dst_addr = BCU_EXT_MASTER_CAN_ADDR;
//    }
//    else
//    {
//        send_msg.dst_addr = BROCAST_DEVICE_ADDRESS;
//    }
//    
//    send_msg.data = dev_di_state_get();
//    ext_slave_send_addr_msg(&send_msg);
}

/**
 * @brief 从机定时请求重新编址
 * @param 无
 * @param 无
 * @return 无
 */
static void ext_slave_send_cmd_request_addressing(void)
{
    static uint32_t timestamp = 0;
    if (sdk_is_tick_over(timestamp, os_tick_from_millisecond(1000 * 3))) // 每3秒请求一次编址
    {
        timestamp = sdk_tick_get();
        msg_t send_msg;
        send_msg.cmd = CMD_REQUEST;
        send_msg.src_addr = g_ext_addr_para.mac_addr;
        send_msg.dst_addr = BROCAST_DEVICE_ADDRESS; // 保证其他设备都能收到，广播地址
        send_msg.data = 1;
        ext_slave_send_addr_msg(&send_msg);
        //EXT_ADDR_LOGE("[EADD]sla req addr\n"); // 打印信息：从机请求编址
    }
}

/**
 * 从机定时定时广播地址冲突
 */
static void slave_send_address_conflict(void)
{
    if (EXT_CAN_MAC_SLAVER != g_ext_addr_para.dev_type)
    {
        return;
    }
    static uint32_t timestamp = 0;
    if (g_ext_addr_para.address_conflict_flag)
    {
        if (sdk_is_tick_over(timestamp, os_tick_from_millisecond(1000)))
        { // 广播心跳包
            timestamp = sdk_tick_get();
            msg_t send_msg;
            send_msg.src_addr = g_ext_addr_para.mac_addr;
            send_msg.dst_addr = BROCAST_DEVICE_ADDRESS;
            send_msg.cmd = CMD_CONFLICT;
            send_msg.data = 1;
            ext_slave_send_addr_msg(&send_msg);
        }
    }
    else
    {
        timestamp = 0;
    }
}

/******************************************外can物理编址，主从机发送函数-end*******************************/

/******************************************外can物理编址，主从机接收函数-start*******************************/
/**
 * @brief 主机判断接收到应答消息
 * @param recv_msg 期望接收到的信息
 * @param over_time 超时时间
 * @return -1超时、0未接收到消息、1接收到正确消息
 */
static int32_t ext_addr_cmd_reply_check(uint32_t over_time)
{
    if (g_reply_msg_state.cmd_reply_state)
    {
        memset(&g_reply_msg_state, 0, sizeof(ext_reply_msg_state_t)); // 判断完成后，清空接收判断变量
        return 1;
    }
    else
    {
        g_reply_msg_state.reply_over_time_cnt++;
        if (g_reply_msg_state.reply_over_time_cnt >= over_time)
        {
            memset(&g_reply_msg_state, 0, sizeof(ext_reply_msg_state_t));
            return -1;
        }
    }
    return 0;
}

static void if_master_rcv_addr_cmd_reply(msg_t *p_rcv_msg)
{
    if (EXT_CAN_MAC_MASTER != g_ext_addr_para.dev_type)
    {
        return;
    }
    if(g_reply_msg_state.need_reply_flag == 1)
    {
        if ((g_reply_msg_state.expect_rcv_msg.src_addr == p_rcv_msg->src_addr) &&
            (g_reply_msg_state.expect_rcv_msg.dst_addr == p_rcv_msg->dst_addr) &&
            (g_reply_msg_state.expect_rcv_msg.cmd == p_rcv_msg->cmd) &&
            (g_reply_msg_state.expect_rcv_msg.data == p_rcv_msg->data))    // 回复data为结果描述符，1表示正常
        {
            g_reply_msg_state.cmd_reply_state = 1;
        }
    }
}

/**
 * @brief 主机判断接收到应答消息
 * @param [in]can_msg 接收can帧
 * @param [in]数据buff
 * @param [out]转换对应命令和数据
 * @return 无
 */
static void ext_can_convert_to_addr_msg(uint32_t can_id, uint8_t *p_data, msg_t* addr_msg, uint8_t len)
{
    if ((addr_msg == NULL) && (p_data == NULL))
    {
        return;
    }
    can_frame_id_u can_frame_id = {can_id};
    addr_msg->src_addr = can_frame_id.bit.src_addr;
    addr_msg->dst_addr = can_frame_id.bit.dst_addr;
    addr_msg->src_type = can_frame_id.bit.src_type;
    addr_msg->dst_type = can_frame_id.bit.dst_type;

    if (can_frame_id.bit.fun_code == FUNC_BCU_SELF_CTL)
    {
        switch (p_data[1])
        {
            case EXT_CAN_MAS_ADDR_SET_IO_HIGH_CMD:
                addr_msg->cmd = CMD_SET_OUTPUT;
                addr_msg->data = 1;
                break;
            case EXT_CAN_MAS_ADDR_SET_IO_LOW_CMD:
                addr_msg->cmd = CMD_SET_OUTPUT;
                addr_msg->data = 0;
                break;
            case EXT_CAN_MAS_SET_ADDR_CMD:
                addr_msg->cmd = CMD_SET_SLAVE_ADDR;
                addr_msg->data = p_data[0];
                break;
            case EXT_CAN_MAS_SET_START_ADDR_CMD:
                addr_msg->cmd = CMD_START_ADDRESSING;
                break;
            default:
                break;
        }
    }
    else if (can_frame_id.bit.fun_code == FUNC_INV_HEART_BEAT)
    {
        addr_msg->cmd = CMD_HEARTBEAT;
    }
    else if (can_frame_id.bit.fun_code == FUNC_BCU_SELF_REPLAY)
    {
        switch (p_data[1])
        {
            case EXT_CAN_RX_SLA_SET_START_ADDR_CMD:
                addr_msg->cmd = CMD_REQUEST;
                break;
            case EXT_CAN_RX_SLA_ADDR_CONFLICT_CMD:
                addr_msg->cmd = CMD_CONFLICT;
                break;
            case EXT_CAN_RX_SLA_SET_ADDR_CMD:
                addr_msg->cmd = CMD_CHECK_SLAVE_ADDR;
                addr_msg->data = p_data[0];
                break;
            default:
                break;
        }
    }
    else if (can_frame_id.bit.fun_code == FUNC_BCU_SELF_STATE)
    {
        addr_msg->cmd = CMD_DI_CHECK;
        addr_msg->data = p_data[0];
    }
}

/**
 * @brief 主从机心跳帧接收处理
 * @param [in]p_rcv_msg 解析后的数据
 * @return 无
 */
static void ext_can_recv_heartbeat_proc(msg_t *p_rcv_msg)
{
    if (p_rcv_msg->src_type != DEV_BCU)
    {
        return;
    }
    if (p_rcv_msg->src_addr > g_ext_addr_para.dev_num && 
        EXT_ADDRESSING_FINISH == ext_can_mac_auto_addressing_get_state() &&
        EXT_CAN_MAC_SLAVER != g_ext_addr_para.dev_type)
    {
        g_ext_addr_para.have_dev_on_addressing = 1;
    }
    if (p_rcv_msg->src_addr == g_ext_addr_para.mac_addr)
    {
        g_ext_addr_para.address_conflict_flag = 1;
        EXT_ADDR_LOGE("[EADD]bcu addr cft\n");
    }
    if (BCU_EXT_MASTER_CAN_ADDR == g_ext_addr_para.mac_addr)
    {
        // 主机有接到从机的心跳
        if ((2 <= p_rcv_msg->src_addr) && (p_rcv_msg->src_addr <= g_ext_addr_para.dev_num))
        {
            g_dev_comm_status[p_rcv_msg->src_addr - 1].unlink_time_cnt = 0;
        }
    }
    else if (1 == p_rcv_msg->src_addr)
    {
        g_dev_comm_status[0].unlink_time_cnt = 0;
    }
}

/**
 * @brief 主机冲突帧接收处理
 * @param [in]p_rcv_msg 解析后的数据
 * @return 无
 */
static void ext_can_master_recv_conflict_proc(msg_t *p_rcv_msg)
{
//    if (BCU_EXT_MASTER_CAN_ADDR != g_ext_addr_para.mac_addr)
//    {
//        return;
//    }
    if ((g_ext_addr_para.mac_addr == BCU_EXT_MASTER_CAN_ADDR || BROCAST_DEVICE_ADDRESS == p_rcv_msg->dst_addr) && (p_rcv_msg->dst_type == DEV_BCU)) // 从机报告地址冲突
    {
        if (p_rcv_msg->data == 1)
        {
             g_ext_addr_para.address_conflict_flag = 1;
             EXT_ADDR_LOGE("[EADD]BCU addr cft\n");
        }
    }
}

/**
 * @brief 主机检测编址io电平
 * @param [in]p_rcv_msg 解析后的数据
 * @return 无
 * @warnning 
 */
static void ext_can_master_recv_addr_pin_check_proc(msg_t *p_rcv_msg)
{
    if (EXT_CAN_MAC_SLAVER == g_ext_addr_para.dev_type)
    {
        return;
    }
    if ((BCU_EXT_MASTER_CAN_ADDR == g_ext_addr_para.mac_addr || BROCAST_DEVICE_ADDRESS == p_rcv_msg->dst_addr) && (p_rcv_msg->dst_type == DEV_BCU))
    {
        uint16_t pin_status = (p_rcv_msg->data) & (0x0001);
        uint16_t valid_flag = (p_rcv_msg->data) & (0x8000);
        if ((valid_flag) && ((ADDRESSING_PIN_STATUS) == pin_status))
        {
            g_dev_addr_pin_state_flag |= 1;
            g_dev_addr_default_pin_timer_cnt = 0;
        }
        g_dev_addr_pin_state_flag = g_dev_addr_pin_state_flag << 1;
        //EXT_ADDR_LOGE("srd_d=%d, dst_d=%d,mac=%d,#%x\n", p_rcv_msg->src_addr, p_rcv_msg->dst_addr, g_ext_addr_para.mac_addr, g_dev_addr_pin_state_flag);
    }
}

/**
 * @brief 主机接收编址请求
 * @param [in]p_rcv_msg 解析后的数据
 * @return 无
 * @warnning 
 */
static void master_recv_addr_request_proc(msg_t *p_rcv_msg)
{
//    if (EXT_CAN_MAC_MASTER != g_ext_addr_para.dev_type)
//    {
//        return;
//    }
    if ((BCU_EXT_MASTER_CAN_ADDR == g_ext_addr_para.mac_addr || BROCAST_DEVICE_ADDRESS == p_rcv_msg->dst_addr) && (p_rcv_msg->dst_type == DEV_BCU))
    {
        if ((g_ext_addr_para.addr_state == EXT_ADDRESSING_FINISH) && (p_rcv_msg->data == 1))
        {
            g_ext_addr_para.have_dev_on_addressing = 1;
            EXT_ADDR_LOGE("[EADD]dev_on_addr set\n");
        }
    }
}

/**
 * @brief 从机接收编址启动
 * @param [in]p_rcv_msg 解析后的数据
 * @return 无
 * @warnning 
 */
static void slave_recv_addr_start_proc(msg_t *p_rcv_msg)
{
    report_di_status_deal();
    if (EXT_CAN_MAC_SLAVER != g_ext_addr_para.dev_type)
    {
        return;
    }
    if (p_rcv_msg->data == 1)
    {
        OUTPUT_PIN_SET_DEFAULT();
        g_ext_addr_para.address_conflict_flag = 0;
        g_ext_addr_para.mac_addr = BCU_EXT_SLV_ADDR_DFT;
        g_ext_addr_para.addr_state = EXT_ADDRESSING_ING;
    }
}

/**
 * @brief 从机接收设置IO命令
 * @param [in]p_rcv_msg 解析后的数据
 * @return 无
 * @warnning 
 */
static void slave_recv_output_set_proc(msg_t *p_rcv_msg)
{
    report_di_status_deal();
    if (EXT_CAN_MAC_SLAVER != g_ext_addr_para.dev_type)
    {
        return;
    }
    if ((p_rcv_msg->dst_addr == g_ext_addr_para.mac_addr || BROCAST_DEVICE_ADDRESS == p_rcv_msg->dst_addr) && (p_rcv_msg->dst_type == DEV_BCU))// 判断是否为本机地址
    {
        //EXT_ADDR_LOGE("[EADD]auto_addr:SET_PIN %d\n",p_rcv_msg->data);
        if (1 == p_rcv_msg->data)
        {
            OUTPUT_PIN_SET_HIGH();
        }
        else if (0 == p_rcv_msg->data)
        {
            OUTPUT_PIN_SET_LOW();
        }
    }
}

/**
 * @brief 从机接收设置地址
 * @param [in]p_rcv_msg 解析后的数据
 * @return 无
 * @warnning 
 */
static void slave_recv_addr_set_proc(msg_t *p_rcv_msg)
{
    if (EXT_CAN_MAC_SLAVER != g_ext_addr_para.dev_type)
    {
        return;
    }
    if ((p_rcv_msg->src_addr == BCU_EXT_MASTER_CAN_ADDR) && (p_rcv_msg->src_type == DEV_BCU))// 判断是否为主机地址
    {
        if (ADDRESSING_PIN_STATUS == INPUT_PIN_READ()) // 接收pin是否做滤波
        {
            g_ext_addr_para.mac_addr = p_rcv_msg->data;
            g_ext_addr_para.address_conflict_flag = 0;
            msg_t send_msg;
            send_msg.src_addr = g_ext_addr_para.mac_addr;
            send_msg.dst_addr = BCU_EXT_MASTER_CAN_ADDR;
            send_msg.cmd = CMD_SET_SLAVE_ADDR;
            send_msg.data = 1; //设置成功
            ext_slave_send_addr_msg(&send_msg);
			ext_can_set_filter(g_ext_addr_para.mac_addr);
            EXT_ADDR_LOGE("[EADD]SET ADDR %d,rece%d\n", g_ext_addr_para.mac_addr,  p_rcv_msg->data);
        }
    }
}

/**
 * @brief   外网CAN(bcu)，主从机自动编址回复消息处理函数
 * @param   无
 * @return  无
 * @warning	无
 */
static void ext_addr_rcv_msg(msg_t *p_rcv_msg)
{
    if (p_rcv_msg == NULL)
    {
        return;
    }

    switch (p_rcv_msg->cmd)
    {
        case CMD_REQUEST:
            master_recv_addr_request_proc(p_rcv_msg);
            break;
        case CMD_HEARTBEAT:
            ext_can_recv_heartbeat_proc(p_rcv_msg);
            break;
        case CMD_CONFLICT:
            ext_can_master_recv_conflict_proc(p_rcv_msg);
            break;
        case CMD_DI_CHECK:
            ext_can_master_recv_addr_pin_check_proc(p_rcv_msg);
            break;
        case CMD_START_ADDRESSING:
            slave_recv_addr_start_proc(p_rcv_msg);
            break;
        case CMD_SET_OUTPUT:
            slave_recv_output_set_proc(p_rcv_msg);
            break;
        case CMD_SET_SLAVE_ADDR:
            slave_recv_addr_set_proc(p_rcv_msg);
            break;
        case CMD_CHECK_SLAVE_ADDR:
            if_master_rcv_addr_cmd_reply(p_rcv_msg);
            break;
        default:
            break;
    }
}
/******************************************外can物理编址，主从机接收函数-end*******************************/
#define PCS_3PH_COM_ERR_CNT_B10MS (1000) // 10s 由于切换一种协议需要10s
static uint8_t g_report_di_stu_time = 0;
static uint16_t g_pcs_unlink_time_cnt = 0;
// 使能发送编址输入引脚数据
static void report_di_status_deal(void)
{
#define  MAX_REPORT_DI_STU_TIME 10
    g_report_di_stu_time++;
    if (g_report_di_stu_time > MAX_REPORT_DI_STU_TIME)
    {
        g_report_di_stu_time = MAX_REPORT_DI_STU_TIME;
    }
}

/**
 * IDM编址输入电平变化上报状态
 */
static void idm_input_cycle_send(void)
{
    static uint8_t last_di = 0xFF;
    uint8_t di = INPUT_PIN_READ();
    if (last_di != di)
    {
        EXT_ADDR_LOGE("[EADD]lastPin%d,curPin%d\n", last_di, di);
        last_di = di;
        g_report_di_stu_time += 3; // 状态变化发送3次
    }
    if (BCU_STATE_UPGRADE == bms_state_get_sys_sta())
    {
        g_report_di_stu_time = 0;
        return;
    }
    if (g_report_di_stu_time > 0)
    {
        g_report_di_stu_time--;
        ext_send_dev_di_status();
    }
}

/**
 * @brief   检测pcs_3ph通讯失败
 * @param   无
 * @return  无
 * @warning	无
 */
static void check_pcs_3ph_comm_status(void)
{
    // 由于3ph升级过程不会下发心跳导致bcu误触发pcs通讯失败，升级过程不判断逆变器通讯失败(125kw即使升级过程也会一直发心跳，不会出现次情况)
    if (BCU_STATE_UPGRADE == bms_state_get_sys_sta())
    {
        g_pcs_unlink_time_cnt = 0;
        return;
    }
    if(++g_pcs_unlink_time_cnt >= PCS_3PH_COM_ERR_CNT_B10MS)
    {
        g_pcs_unlink_time_cnt = PCS_3PH_COM_ERR_CNT_B10MS;
    }
}
/**
 * @brief   外网CAN(bcu)，定时广播心跳包，用于检测从机通信超时
 * @param   无
 * @return  无
 * @warning	无
 */
static void check_dev_comm_status(void)
{
    if (g_ext_addr_para.addr_state != EXT_ADDRESSING_FINISH)
    {
        return;
    }
    if (BCU_EXT_MASTER_CAN_ADDR == g_ext_addr_para.mac_addr)
    {
         for (int i = 1; i < g_ext_addr_para.dev_num; i++)
         {
             if (++g_dev_comm_status[i].unlink_time_cnt >= EXT_ADDR_DEV_UNLINK_TIME_OUT)
             {
                 g_ext_addr_para.fault_dev_unlink = 1;
                return;
             }
         }
    }
    else
    {
        if (++g_dev_comm_status[0].unlink_time_cnt >= EXT_ADDR_DEV_UNLINK_TIME_OUT)
        {
            g_ext_addr_para.fault_dev_unlink = 1;
           return;
        }
    
    }
    g_ext_addr_para.fault_dev_unlink = 0;
}

/**
 * @brief  获取自动编址状态
 * @return 自动编址状态
 */
ext_addressing_state_e ext_can_mac_auto_addressing_get_state(void)
{
    return g_ext_addr_para.addr_state;
}

/**
 * @brief  获取自动编址故障
 * @return AUTO_ADDRESSING_NO_FAULT     没故障
 * @return AUTO_ADDRESSING_ID_CONFLICT  通讯ID冲突
 * @return AUTO_ADDRESSING_COMM_FAIL    通讯故障
 */
uint8_t ext_can_mac_auto_addressing_fault_get(void)
{
    uint8_t error = AUTO_EXT_ADDRESSING_NO_FAULT;
    static uint8_t last_err_flag = AUTO_EXT_ADDRESSING_NO_FAULT;
    // 通讯故障
    if (g_ext_addr_para.fault_dev_num_less        // 电池包重新编址数量变少了
        || g_ext_addr_para.fault_dev_unlink         // 有电池包失联
        || g_ext_addr_para.fault_dev_on_addressing) // 有电池包没有被编址
    {
        error |= AUTO_EXT_ADDRESSING_COMM_FAIL;
    }
    // 地址冲突
    if (g_ext_addr_para.fault_id_conflict)
    {
        error |= AUTO_EXT_ADDRESSING_ID_CONFLICT;
    }
    // 外can编址异常
    if (g_ext_addr_para.addr_abnormal_cnt > EXT_AUTO_ADDR_ABNORMAL_MAX_NUM)
    {
        g_ext_addr_para.addr_abnormal_cnt = EXT_AUTO_ADDR_ABNORMAL_MAX_NUM + 1;  // 防止越界
        error |= AUTO_EXT_ADDRESSING_ABNORMAL_FAIL;
    }
    // 电平控制异常
    if (g_check_pin_state.start_pin_err_cnt >= ADDR_PIN_CHECK_ERR_TIME)
    {
        g_check_pin_state.start_pin_err_cnt = ADDR_PIN_CHECK_ERR_TIME + 1;  // 防止越界
        error |= AUTO_EXT_ADDRESSING_PIN_FAIL;
    }
    if (g_pcs_unlink_time_cnt >= PCS_3PH_COM_ERR_CNT_B10MS)
    {
        error |= AUTO_EXT_PCS_COM_FAIL;
    }
    if (last_err_flag != error)
    {
        EXT_ADDR_LOGE("[EADD]errTy=%d\n", error);
    }
    last_err_flag = error;
    return error;
}

/**
 * @brief  获取编址地址
 * @retval =0     未完成编址
 * @retval 1~0x0F 有效地址
 */
uint8_t ext_can_mac_auto_addressing_get_address(void)
{
    return g_ext_addr_para.mac_addr;
}

/**
 * @brief  获取设备数量
 * @retval 1~N 有效的设备数量
 * @retval 0 获取失败
 * @pre    只有编址完成后，才能正确获取设备数量
 */
uint8_t ext_can_mac_auto_addressing_dev_num_get(void)
{
    if (g_ext_addr_para.addr_state == EXT_ADDRESSING_FINISH)
    {
        if (BCU_EXT_MASTER_CAN_ADDR == g_ext_addr_para.mac_addr)
        {
             return g_ext_addr_para.dev_num;
        }
        else
        {
            return 1;
        }
    }
    else
    {
        return 0;
    }    
}

/**
 * @brief  设备目异常标志
 * @retval true 数量异常
 * @retval false 无异常
 * @pre    只有编址完成后，才能判断设备数量
 */
uint32_t ext_can_mac_addressing_dev_num_abnormal_get(void)
{
    if (g_ext_addr_para.addr_state != EXT_ADDRESSING_FINISH)
    {
        return false;
    }
    if (g_ext_addr_para.dev_num > MAX_3PH_DEV_NUM)
    {
        return true;
    }
    return false; 
}

/**
 * @brief  使能自动编址
 * @;param [in] 使能外can自动编址开关，1：使能，0:关闭
 * @return 无
 */
void ext_can_mac_auto_addressing_set(uint32_t enable)
{
    g_ext_addr_para.auto_addressing_enable = enable;
}

/**
 * @brief  获取外can自动编址使能标志
 * @return 无
 */
uint32_t ext_can_mac_auto_addressing_get(void)
{
    return g_ext_addr_para.auto_addressing_enable;
}

/**
 * @brief  获取主从机状态
 * @param [in] 使能外can自动编址开关，1：使能，0:关闭
 * @return 无
 */
ext_can_mac_type_e ext_can_mac_type_get(void)
{
    return g_ext_addr_para.dev_type;
}

/**
 * @brief  清除pcs 3ph失联时间
 * @param  
 * @return 无
 */
void clear_pcs_3ph_comm_unlink_time(void)
{
    g_pcs_unlink_time_cnt = 0;
}

/**
 * @brief   外网CAN(bcu)，自动编址初始化
 * @param   无
 * @return  返回执行结果 0:正常；<0:异常
 * @warning	无
 */
void ext_can_mac_auto_addr_init(void)
{
    ext_can_mac_auto_addressing_set(false);
    g_ext_addr_para.addr_state = EXT_ADDRESSING_DISENABLE; // 未使能自动编址
    ext_auto_addr_fsm_init();
    ext_auto_addr_can_register();
    g_check_pin_state.check_pin_err_cnt = 0;
    g_check_pin_state.start_pin_err_cnt = 0;
}

/**
 * @brief   外网CAN(bcu)，自动编址处理函数 10ms调用一次
 * @param   无
 * @return  无
 * @warning	无
 */
void ext_can_mac_auto_addressing_proc(void)
{
    if (special_mode_get(ATUO_TEST))
    {
        return;
    }
    check_pcs_3ph_comm_status();
    idm_input_cycle_send();
    slave_send_address_conflict();
    uint8_t event = state_machine_proc(&g_auto_addr_fsm);
    fsm_state_trans(&g_auto_addr_fsm, event);
    dev_addr_di_default_pin_check();
}

/**
 * @brief   外网CAN(bcu)，从机自动编址回复CAN消息处理回调函数
 * @param   无
 * @return  无
 * @warning	无
 */
int32_t ext_can_mac_addr_rcv_callback(can_frame_data_t *frame_data)
{
    msg_t addr_msg;
    ext_can_convert_to_addr_msg(frame_data->id, frame_data->data, &addr_msg, frame_data->data_len);
    // EXT_ADDR_LOGD("rcv addr msg cmd=%d, data=%x, addr = %d,p0=%d,p1=%d, p2=%d,p3=%d\n", addr_msg.cmd, addr_msg.data, can_msg->addr, p_data[0], p_data[1], p_data[2], p_data[3]);
    ext_addr_rcv_msg(&addr_msg);
    return 0;
}
