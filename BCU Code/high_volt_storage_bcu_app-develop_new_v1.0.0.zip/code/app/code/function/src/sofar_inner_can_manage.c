#include "sofar_can_manage_public.h"
#include "sofar_inner_can_manage.h"
#include "file_read.h"
#include "addressing_common.h"
#include <stdio.h>
#include <string.h>
#include "sdk.h"

//sdk接口函数的can端口号
static int32_t inner_can_sofar_prase_short_frame(can_frame_data_t  *p_can_frame );
static int32_t inner_can_sofar_register_passthrough_frame(can_sofar_pass_reg_t * p_can_rec_reg, uint16_t reg_cnt);


static rcv_register_info_t g_inner_rcv_reg_info = {0};
static pass_register_info_t g_inner_pass_reg_info = {0};

static int32_t can_inner_file_read_reply_passthrough_proc(sdk_can_frame_t *txframe)
{
    can_frame_id_u fram_id_t = {0};
    sdk_can_frame_t txframe_t = {0};
    if (txframe == NULL)
    {
        return -1;
    }
    memcpy(&txframe_t,txframe,sizeof(sdk_can_frame_t));
    txframe_t.data[1] = (uint8_t)fram_id_t.id_val; //赋上源地址在data[1]用作子设备地址
    fram_id_t.id_val = txframe_t.id;    //将当前id改一下
    fram_id_t.bit.dst_type = get_bmu_file_read_src()->type;
    fram_id_t.bit.dst_addr = get_bmu_file_read_src()->addr;
    fram_id_t.bit.src_type = DEV_EXT_BCU;
    fram_id_t.bit.src_addr = ext_addressing_manage_addr_get();

    txframe_t.id = fram_id_t.id_val;
    // log_d("in pass msg id=%x\n", txframe_t.id);
    sdk_can_write(SDK_EXTERNAL_CAN_PORT , &txframe_t, 1);
    return 0;
}

static int32_t can_inner_file_read_data_passthrough_proc(sdk_can_frame_t *txframe)
{
    can_frame_id_u fram_id_t = {0};
    sdk_can_frame_t txframe_t = {0};
    if (txframe == NULL)
    {
        return -1;
    }
    memcpy(&txframe_t,txframe,sizeof(sdk_can_frame_t));
    fram_id_t.id_val = txframe_t.id;    //将当前id改一下
    fram_id_t.bit.dst_type = get_bmu_file_read_src()->type;
    fram_id_t.bit.dst_addr = get_bmu_file_read_src()->addr;
    fram_id_t.bit.src_type = DEV_EXT_BCU;
    fram_id_t.bit.src_addr = ext_addressing_manage_addr_get();

    txframe_t.id = fram_id_t.id_val;
    // log_d("in pass msg id=%x\n", txframe_t.id);
    sdk_can_write(SDK_EXTERNAL_CAN_PORT , &txframe_t, 1);
    return 0;
}

static void can_inner_passthrough_id_register(void)
{
    uint16_t rcv_msg_amount = 0;
    can_frame_id_u frame_id[] =
        {
            // res     prio(优先级)    , fun_code,    dst_type dst_addr, src_type, src_addr
            {.bit.res = 0, .bit.prio = SOFAR_CAN_PRI_HIGH_H, .bit.fun_code = FUNC_UP_FILE_START, .bit.dst_type = 0, .bit.dst_addr = 0, .bit.src_type = DEV_BMU, .bit.src_addr = 0}, // 0x07F00000
            {.bit.res = 0, .bit.prio = SOFAR_CAN_PRI_HIGH_H, .bit.fun_code = FUNC_UP_FILE_DATA_TRAN, .bit.dst_type = 0, .bit.dst_addr = 0, .bit.src_type = DEV_BMU, .bit.src_addr = 0}, // 0x07F20000
            {.bit.res = 0, .bit.prio = SOFAR_CAN_PRI_HIGH_H, .bit.fun_code = FUNC_UP_FILE_DATA_BLOCK_CRC, .bit.dst_type = 0, .bit.dst_addr = 0, .bit.src_type = DEV_BMU, .bit.src_addr = 0}, // 0x07F30000
            {.bit.res = 0, .bit.prio = SOFAR_CAN_PRI_HIGH_H, .bit.fun_code = FUNC_UP_FILE_FINISH_QUERY, .bit.dst_type = 0, .bit.dst_addr = 0, .bit.src_type = DEV_BMU, .bit.src_addr = 0}, // 0x07F40000

        };
    can_sofar_pass_reg_t can_rxmsg_tab[] = // BCU接收上位机或PCS的数据
        {
            {.id = frame_id[0].id_val, .id_mask = 0x0000FF1F, .p_can_cb = can_inner_file_read_reply_passthrough_proc},  // 0x07F00000
            {.id = frame_id[1].id_val, .id_mask = 0x0000FF1F, .p_can_cb = can_inner_file_read_data_passthrough_proc},  // 0x07F20000
            {.id = frame_id[2].id_val, .id_mask = 0x0000FF1F, .p_can_cb = can_inner_file_read_reply_passthrough_proc},  // 0x07F30000
            {.id = frame_id[3].id_val, .id_mask = 0x0000FF1F, .p_can_cb = can_inner_file_read_reply_passthrough_proc},  // 0x07F40000
        };

    // 注册接收的数据
    rcv_msg_amount = sizeof(can_rxmsg_tab) / sizeof(can_sofar_pass_reg_t);
    inner_can_sofar_register_passthrough_frame(can_rxmsg_tab, rcv_msg_amount);
}
/**
* @brief		初始化透传
* @param		无
* @return		无
* @warning		无
*/
static void can_sofar_passthrough_init(void)
{
    can_inner_passthrough_id_register();
    // can_ext_passthrough_id_register();
}

// 透传帧处理
static int32_t inner_can_sofar_passthrough_frame_proc(sdk_can_frame_t *can_msg_data)
{
    int32_t ret;
    uint8_t i;
    if (NULL == can_msg_data)
    {
        return -1;
    }
    for (i = 0; i < g_inner_pass_reg_info.reg_cnt && i < PASS_THROUGH_MAX_NUM; i++)
    {
        if (0 == can_compare_id(can_msg_data->id, g_inner_pass_reg_info.reg_buff[i].id, g_inner_pass_reg_info.reg_buff[i].id_mask)) // 判断是已注册的id
        {
            if (NULL != g_inner_pass_reg_info.reg_buff[i].p_can_cb)
            {
                g_inner_pass_reg_info.reg_buff[i].p_can_cb(can_msg_data);
                ret = 0;
                break;
            }
        }
        else
        {
            continue;
        }
    }
    if (i >= g_inner_pass_reg_info.reg_cnt)
    {
        ret = -1;
    }
    return ret;
}
/**
* @brief		初始化can管理
* @param		无
* @return		返回结果
* @retval		0：成功    < 0: 失败
* @warning		无
*/
int32_t inner_can_sofar_manage_init(void)
{
    //初始化CAN
    sdk_can_cfg_t can_cfg =
    {
        .baud = SDK_CAN_BAUD_250K,
        .mode = SDK_CAN_MODE_NORMAL,
    };

    sdk_can_init();
    sdk_can_open(SDK_INTERNAL_CAN_PORT);
    sdk_can_setup(SDK_INTERNAL_CAN_PORT, &can_cfg);
    can_sofar_passthrough_init();
    return 0;
}

/**
* @brief		读取内can硬件缓冲区数据，1ms周期轮询
* @param		无
* @return		返回结果
* @retval		0：添加成功    < 0: 添加失败
* @warning		无
*/
int32_t inner_can_sofar_rcv_frame_proc(void)
{
    sdk_can_frame_t can_msg_data = {0};
    can_frame_data_t can_short = {0};
    int32_t ret = 0;
    int32_t len = 0;

    /************************************内CAN*************************************************/
    // hdr 值为 - 1，表示直接从 uselist 链表读取数据

    for(uint8_t i = 0; i < CAN_SOFAR_RCV_DATA_MAX_NUM_ONE_TIME; i++)
    {
        can_msg_data.hdr = -1;  // hdr 值为 - 1，表示直接从 uselist 链表读取数据
        len = sdk_can_read(SDK_INTERNAL_CAN_PORT,  &can_msg_data, 1, 0 );
        if(len > 0)
        {
            can_short.id = can_msg_data.id;
            can_short.ide = can_msg_data.ide;

            ret = inner_can_sofar_passthrough_frame_proc(&can_msg_data);
            if (ret == 0) // 透传帧
            {
                continue;
            }
            can_short.data_len = can_msg_data.len;
            memcpy(can_short.data, &(can_msg_data.data[0]), 8);
            inner_can_sofar_prase_short_frame(&can_short);
        }
        else
        {
            break;
        }

    }
    return 0;
}
/**
* @brief		判断接收的ID的目标地址是否为电池,源地址是否为指定设备
* @param		[in]接收到的ID
* @param		[in]注册ID的掩码
* @return		返回结果
* @retval		0：成功    < 0: 失败
* @warning		无
*/

#define NO_FLITER_MASK      0xFF //掩码为0xFF，即收到id的目标地址与预设id的目标地址不一致
#define NO_ADDR_MASK        0x1F //掩码为0x1F，即收到id的目标地址与预设id的目标地址不一致,设备类型一致
#define FLITER_MASK         0x00 //掩码为0x00，即收到id的目标地址必须与预设的id目标地址完全一致
static int32_t check_inn_pack_address(uint32_t target_id, uint32_t mask_id)
{
    int32_t res = 0;
    uint8_t id_tag = 0;
    uint8_t id_dev_type = 0;
    uint8_t id_dev_addr = 0;
    uint8_t mask_id_tag = 0;
    uint8_t pack_addr = BCU_INNER_CAN_ADDR; //对内保持地址为1

    id_tag = (uint8_t)(target_id >> 8);
    id_dev_type = (uint8_t)((id_tag >> 5) & 0x7);
    id_dev_addr = (uint8_t)(id_tag & 0x1F);
    mask_id_tag = (uint8_t)(mask_id >> 8);

    //如果id的目标地址掩码为0xFF,则默认只允许 0x00，0x80等广播类型和本机pack的id:81
    //如果id的目标地址掩码为0x1F,则默认只允许 0x80广播类型和本机pack的id:81
    if (((NO_FLITER_MASK == mask_id_tag) && (BROADCAST_DEVICE_TYPE_ADDRESS == id_tag || (DEV_BCU == id_dev_type && ((pack_addr == id_dev_addr) || (BROCAST_DEVICE_ADDRESS == id_dev_addr)))))
        || ((NO_ADDR_MASK == mask_id_tag) && ((pack_addr == id_dev_addr) || (BROCAST_DEVICE_ADDRESS == id_dev_addr)))
        || (FLITER_MASK == mask_id_tag))
    {
        res = 0;
    }
    else
    {
        res = -1;
    }

    return res;
}

/**
* @brief		处理已注册进来的CAN帧，跳转到各自注册的回调函数中
* @param		[in] CAN端口	外部CAN：EXTERNAL_CAN  /  内部CAN：INTERNAL_CAN
* @param		[in] 数据帧内容
* @return		返回结果
* @retval		0：成功    < 0: 失败
* @warning		无
*/
static int32_t inner_can_sofar_prase_short_frame(can_frame_data_t  *p_can_frame )
{
    int32_t ret = 0;
    uint16_t i = 0;

    if(NULL == p_can_frame)
    {
        return -1;
    }

     for(i = 0; i < g_inner_rcv_reg_info.reg_cnt && i < MAX_GENERAL_REC_NUM; i++)
     {
         //1、判断是已注册的id
         //2、判断接收的id是否为广播地址或本机pack地址
         if( (0 == can_compare_id(p_can_frame->id , g_inner_rcv_reg_info.reg_buff[i].id, g_inner_rcv_reg_info.reg_buff[i].id_mask)) &&
             ((0 == check_inn_pack_address(p_can_frame->id, g_inner_rcv_reg_info.reg_buff[i].id_mask)) || (SDK_CAN_STDID == p_can_frame->ide)))
         {
             if(NULL != g_inner_rcv_reg_info.reg_buff[i].p_can_cb)
             {
                 g_inner_rcv_reg_info.reg_buff[i].p_can_cb(p_can_frame);
                 break;
             }

         }
     }
    return ret;
}



/**
* @brief		注册can接收回调函数
* @param		[in] port：	外部CAN：EXTERNAL_CAN  /  内部CAN：INTERNAL_CAN
* @param		[in] urgent_flag:紧急处理标志  GENERAL_FRAME:接收到数据正常响应速度10ms ，URGENT_FRAME:接收数据快速响应1ms
* @param		[in] p_can_rec_reg ：
* @param		[in] id：can帧id
* @param		[in] id：id_mask：过滤不需要接收的位(标准帧的掩码mask固定为0x00000000,拓展帧的掩码mask目标地址设置为FF代表能接收0xFF,0x1F,pack_addr三种类型地址)
* @param		[in] id：can_cb：回调解析函数
* @param		[in] reg_cnt：注册的数量
* @return		返回结果
* @retval		0：注册成功    < 0: 注册失败
* @warning		禁止重复注册同一个ID
* @warning		标准帧注册掩码必须为0x00000000
* @warning		掩码不可为0xFFFFFFFF
*/
int32_t inner_can_sofar_register_receive_frame(can_sofar_rcv_reg_t *p_can_rec_reg, uint16_t reg_cnt)
{
    int32_t ret = 0;
    uint16_t i = 0;

    if ((NULL == p_can_rec_reg) ||
        (0 == p_can_rec_reg->id) ||
        (0xFFFFFFFF == p_can_rec_reg->id_mask) ||
        (NULL == p_can_rec_reg->p_can_cb))
    {
        return -1; // 输入参数有误，返回失败
    }
    for (i = 0; i < reg_cnt; i++)
    {
        if (g_inner_rcv_reg_info.reg_cnt < MAX_GENERAL_REC_NUM) // 判断已经注册数量是否大于最大允许注册的数量
        {
            memcpy(g_inner_rcv_reg_info.reg_buff + g_inner_rcv_reg_info.reg_cnt, p_can_rec_reg + i, sizeof(can_sofar_rcv_reg_t));
        }
        else
        {
            ret = -2;
            break; // 注册数量大于总数，则返回失败
        }

        g_inner_rcv_reg_info.reg_cnt++; // 已经注册的数量计数
    }
    return ret;
}

/**
* @brief		注册透传的数据帧，接收内网数据后透传到外网，或接收外网数据后透传到内网
* @param		[in] 外部CAN透传至内CAN：EXTERNAL_CAN  /  内部CAN透传至外CAN：INTERNAL_CAN
* @param		[in] p_can_rec_reg ： id：can帧id  / id_mask：过滤不需要接收的位 / can_cb：回调解析函数
* @return		返回结果
* @retval		0：注册成功    < 0: 注册失败
* @warning		无
*/
static int32_t inner_can_sofar_register_passthrough_frame(can_sofar_pass_reg_t * p_can_rec_reg, uint16_t reg_cnt)
{
    int32_t ret = 0;
    uint16_t i = 0;

    if ((NULL == p_can_rec_reg) ||
        (0 == p_can_rec_reg->id) ||
        (0xFFFFFFFF == p_can_rec_reg->id_mask) ||
        (NULL == p_can_rec_reg->p_can_cb))
    {
        return -1; // 输入参数有误，返回失败
    }
    for (i = 0; i < reg_cnt; i++)
    {
        if (g_inner_pass_reg_info.reg_cnt < PASS_THROUGH_MAX_NUM) // 判断已经注册数量是否大于最大允许注册的数量
        {
            memcpy(g_inner_pass_reg_info.reg_buff + g_inner_pass_reg_info.reg_cnt, p_can_rec_reg + i, sizeof(can_sofar_pass_reg_t));
        }
        else
        {
            ret = -2;
            log_d("inner can pass id register num over\n");
            break; // 注册数量大于总数，则返回失败
        }

        g_inner_pass_reg_info.reg_cnt++; // 已经注册的数量计数
    }
    return ret;
}
