#include "file_read.h"
#include <string.h>
#include "sofar_can_manage.h"
#include "auto_addressing.h"
#include "data_store.h"
#include "sdk.h"
#include "app_public.h"
#include "app_config.h"
#include "addressing_common.h"
#include "bms_state.h"
#include "state_machine.h"
#include "upgrade.h"

#define FILE_RD_DEBUG_ENABLE 1									///< 0禁止打印信息 1使能打印信息
#define FILE_SZIE_RD_MAX_NUM 5                                  ///< 文件大小最多读取次数


/*******************************文件上送状态机相关***********************************/
typedef enum
{
    EVT_FILE_RD_STA_CPL_SUS = 0,   // 状态正常执行完成
    EVT_FILE_RD_FILE_INFO,     // 读文件信息
	EVT_FILE_RD_PART,          // 读部分文件
    EVT_FILE_RD_ERR_OR_TIMEOUT,  // 异常或超时
    FILE_RD_EVT_NUM = 4,
}file_rd_fsm_event_e;
typedef enum
{
    FILE_RD_IDEL = 0,       // 步骤0：等待文件传输中
    FILE_RD_FILE_INFO,            // 步骤1：进入读文件状态，回复文件信息
    FILE_RD_WAIT_CONT_RD_CMD,            // 步骤2：进入读文件状态，等待读文件内容指令
    FILE_RD_SEND_DATA,           // 步骤3：发送文件内容
    FILE_RD_STA_NUM = 4
}file_rd_fsm_state_e;

typedef struct
{
    uint32_t stat_cnt_time;  // 状态计时
    uint8_t stat_delay_cnt; // 升级状态等待计数
}file_rd_fsm_para_t; /* 升级状态机控制结构 */

/********************************升级状态机处理函数声明****************************************/
static uint8_t sta_file_rd_idle_entry(void);
static uint8_t sta_file_rd_file_info_entry(void);
static uint8_t sta_file_rd_file_info_run(void);
static uint8_t sta_file_rd_wait_cont_rd_entry(void);
static uint8_t sta_file_rd_wait_cont_rd_run(void);
static uint8_t sta_file_rd_send_data_entry(void);
static uint8_t sta_file_rd_send_data_run(void);

/********************************升级状态机使用变量定义****************************************/
static fsm_action_map_t g_file_rd_act_map[FILE_RD_STA_NUM] = 
{
    [FILE_RD_IDEL]                = {sta_file_rd_idle_entry, NULL},
    [FILE_RD_FILE_INFO]           = {sta_file_rd_file_info_entry, sta_file_rd_file_info_run},
    [FILE_RD_WAIT_CONT_RD_CMD]    = {sta_file_rd_wait_cont_rd_entry, sta_file_rd_wait_cont_rd_run},
    [FILE_RD_SEND_DATA]           = {sta_file_rd_send_data_entry, sta_file_rd_send_data_run},                                                                                                                                                                                                                                            
};

static uint8_t g_file_rd_evt_sta_map[FILE_RD_STA_NUM][FILE_RD_EVT_NUM] = 
{                    // EVT_FILE_RD_STA_CPL_SUS   			EVT_FILE_RD_FILE_INFO         EVT_FILE_RD_PART          EVT_FILE_RD_ERR_OR_TIMEOUT
    [FILE_RD_IDEL]                = {STA_NULL,           		FILE_RD_FILE_INFO,           STA_NULL,           STA_NULL},
    [FILE_RD_FILE_INFO]           = {FILE_RD_WAIT_CONT_RD_CMD,  		STA_NULL,           FILE_RD_WAIT_CONT_RD_CMD,    FILE_RD_IDEL},
    [FILE_RD_WAIT_CONT_RD_CMD]    = {FILE_RD_SEND_DATA,  		FILE_RD_FILE_INFO,           STA_NULL,           FILE_RD_IDEL},
    [FILE_RD_SEND_DATA]           = {FILE_RD_WAIT_CONT_RD_CMD,	FILE_RD_FILE_INFO,           STA_NULL,           FILE_RD_IDEL},
};

/* 接收PCS或上位机升级报文相关处理函数 */
static int32_t file_read_file_info(can_frame_data_t *frame_data);
static int32_t file_read_block_data(can_frame_data_t *frame_data);
static int32_t file_read_finish(can_frame_data_t *frame_data);

// 回复帧
static int32_t reply_file_read_finish(void);
static int32_t reply_file_info(void);

/*******************全局变量初始化**********************/
static file_rd_proc_para_t g_file_rd_proc_para = {0};
static state_machine_t g_file_rd_fsm = {0};
static const char* g_file_rd_fsm_name = "fileRd";
static file_send_data_info_t g_file_send_info = {0};
//static uint8_t g_log_print_level;
static uint8_t g_log_storage_level;
static uint8_t g_bcu_file_read_stus = FILE_READ_WAIT;
static uint8_t g_bmu_file_read_stus = FILE_READ_WAIT;

static uint8_t g_bmu_file_read_cnt = 0;

static bmu_file_read_src_info_t g_bmu_file_read_src = {0};

static fs_t* gp_fs = NULL;
/********************************************文件读取模块内函数实现******************************************************/
//获取读取BMU的源设备
const bmu_file_read_src_info_t *get_bmu_file_read_src(void)
{
	return &g_bmu_file_read_src;
}

//获取文件读取空闲状态
uint8_t get_file_read_wait_stus(void)
{
	if((FILE_READ_WAIT == g_bcu_file_read_stus)
		&& (FILE_READ_WAIT == g_bmu_file_read_stus))
	{
		return true;
	}
	else
	{
		return false;
	}
}

/**
* @brief		bmu文件读取标志清除
* @param		无
* @return		无
* @retval		无
* @pre			无
*/
#define FILE_READ_STUS_CLEAN_CNT	15
static void bmu_file_read_stus_clean(void)
{
	static uint32_t timestamp = 0;

	if (true == sdk_is_tick_over(timestamp, os_tick_from_millisecond(1000)))
	{
		timestamp = sdk_tick_get();
		if(++g_bmu_file_read_cnt >= FILE_READ_STUS_CLEAN_CNT)
		{
			g_bmu_file_read_cnt = FILE_READ_STUS_CLEAN_CNT;
			if(g_bmu_file_read_stus != FILE_READ_WAIT)
			{
				g_bmu_file_read_stus = FILE_READ_WAIT;
				log_d("[file_re] clean bmu file rd stus\n");
			}

		}
	}

}

const file_rd_proc_para_t *get_file_rd_proc_info(void)
{
    return &g_file_rd_proc_para;
}

// 发起方下发读文件指令（请求帧）：
static int32_t file_read_file_info(can_frame_data_t *frame_data)
{
    if (frame_data == NULL)
    {
        return -1;
    }

    if (BCU_STATE_SHUT_DOWN == bms_state_get_sys_sta())
	{
		log_w("[file_rd] stus shunt down\n");
		return -4;
	}

    if (frame_data->data_len < 4)
    {
        return -2;
    }
    if (frame_data->data[0] != 0) // 不等于请求帧 异常
    {
        return -3;
    }
    can_frame_id_u frame_rx_id = {.id_val = frame_data->id};
    log_d("[FRd]startmsg src=%d,type=%d,file=%d,mode=%d\n", frame_rx_id.bit.src_addr, frame_rx_id.bit.src_type, frame_data->data[2], frame_data->data[3]);

    //子设备指向BMU且目标地址不为0的则进行透传,即
    if((DEV_BMU == (frame_data->data[1] >> 5))
        && (0 != (frame_data->data[1] & 0x1F))
        && (BROCAST_DEVICE_ADDRESS != (frame_data->data[1] & 0x1F)))
    {
        can_frame_id_u frame_tx_id = frame_rx_id;
        uint8_t data[4] = {0};
        memcpy(data,frame_data->data,4);
        frame_tx_id.bit.src_type = DEV_BCU;
        frame_tx_id.bit.src_addr = BCU_INNER_CAN_ADDR;
        frame_tx_id.bit.dst_type = frame_data->data[1] >> 5;
        frame_tx_id.bit.dst_addr = (frame_data->data[1]&0x1F);
        data[1] = (frame_rx_id.bit.src_type << 5) | frame_rx_id.bit.src_addr;    // 赋值最初的源地址
        g_bmu_file_read_stus = FILE_READ_ING;    
        g_bmu_file_read_cnt = 0;    
        log_d("[file_rd] file_read to bmu : %d \r\n", frame_tx_id.bit.dst_addr);
        g_bmu_file_read_src.type = frame_rx_id.bit.src_type;
        g_bmu_file_read_src.addr = frame_rx_id.bit.src_addr;
        can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_tx_id.id_val, data, 4);
    }
    else
    {
        memset(&g_file_rd_proc_para, 0, sizeof(file_rd_proc_para_t));
        g_file_rd_proc_para.src_addr = frame_rx_id.bit.src_addr;
        g_file_rd_proc_para.src_dev_type = frame_rx_id.bit.src_type;
        g_file_rd_proc_para.dst_addr = frame_rx_id.bit.dst_addr;
        g_file_rd_proc_para.dst_dev_type = frame_rx_id.bit.dst_type;
        g_file_rd_proc_para.slave_dev = frame_data->data[1];
        g_file_rd_proc_para.start_flag = true;
        g_file_rd_proc_para.file_rd_mode = frame_data->data[3];
        g_file_rd_proc_para.file_type = frame_data->data[2];
    }

    return 0;
}

// 发起方下发读文件数据内容（请求帧）：
static int32_t file_read_block_data(can_frame_data_t *frame_data)
{
    if (frame_data == NULL)
    {
        return -1;
    }
    if (frame_data->data_len < 8)
    {
        return -2;
    }
    if (frame_data->data[0] != 0) // 不等于请求帧 异常
    {
        return -3;
    }
    can_frame_id_u frame_rx_id = {.id_val = frame_data->id};
    //子设备指向BMU且目标地址不为0的则进行透传,即A0
    if((DEV_BMU == (frame_data->data[1] >> 5))
        && (0 != (frame_data->data[1] & 0x1F))
        && (BROCAST_DEVICE_ADDRESS != (frame_data->data[1] & 0x1F)))
    {
        can_frame_id_u frame_tx_id = frame_rx_id;
        uint8_t data[8] = {0};
        memcpy(data,frame_data->data,8);
        frame_tx_id.bit.src_type = DEV_BCU;
        frame_tx_id.bit.src_addr = BCU_INNER_CAN_ADDR;
        frame_tx_id.bit.dst_type = frame_data->data[1] >> 5;
        frame_tx_id.bit.dst_addr = (frame_data->data[1]&0x1F);
        data[1] = (frame_rx_id.bit.src_type << 5) | frame_rx_id.bit.src_addr;    //赋值最初的源地址    
        g_bmu_file_read_cnt = 0;    
        // log_d("SerinNet : read_block to bmu : %d \r\n", can_msg_send.dst_addr);    
        can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_tx_id.id_val, data, 8);        
    }
    else
    {
        // log_d("[file_rd] block rd msg \n", can_msg->src_addr, can_msg->src_type);
        if ((g_file_rd_proc_para.src_addr != frame_rx_id.bit.src_addr) || (g_file_rd_proc_para.src_dev_type != frame_rx_id.bit.src_type)
            || (g_file_rd_proc_para.dst_addr != frame_rx_id.bit.dst_addr) || (g_file_rd_proc_para.dst_dev_type != frame_rx_id.bit.dst_type))
        {
            return -1;
        }
        if (g_file_rd_proc_para.file_type != frame_data->data[2])
        {
            return -2;
        }
        g_file_rd_proc_para.block_data_flag = true;
        g_file_send_info.file_rd_len = ((uint16_t)frame_data->data[6] | (uint16_t)frame_data->data[7] << 8);
        g_file_send_info.file_offset_pos = ((uint32_t)frame_data->data[3] | (uint32_t)frame_data->data[4] << 8 | (uint32_t)frame_data->data[5] << 16);
    //log_d("[FRd] block rd len=%d, offset=%d \n", g_file_send_info.file_rd_len, g_file_send_info.file_offset_pos);
    }

    return 0;
}

static int32_t file_read_finish(can_frame_data_t *frame_data)
{
    if (frame_data == NULL)
    {
        return -1;
    }
    if (frame_data->data_len < 4)
    {
        return -2;
    }
    if (frame_data->data[0] != 0) // 不等于请求帧 异常
    {
        return -3;
    }

    can_frame_id_u frame_rx_id = {.id_val = frame_data->id};

    //子设备指向BMU且目标地址不为0的则进行透传,即A0
    if((DEV_BMU == (frame_data->data[1] >> 5))
        && (0 != (frame_data->data[1] & 0x1F))
        && (BROCAST_DEVICE_ADDRESS != (frame_data->data[1] & 0x1F)))
    {
        can_frame_id_u frame_tx_id = frame_rx_id;
        uint8_t data[4] = {0};
        memcpy(data,frame_data->data,4);
        frame_tx_id.bit.src_type = DEV_BCU;
        frame_tx_id.bit.src_addr = BCU_INNER_CAN_ADDR;
        frame_tx_id.bit.dst_type = frame_data->data[1] >> 5;
        frame_tx_id.bit.dst_addr = (frame_data->data[1]&0x1F);
        data[1] = (frame_rx_id.bit.src_type << 5) | frame_rx_id.bit.src_addr;    //赋值最初的源地址    
        g_bmu_file_read_cnt = 0;    
        // log_d("SerinNet : read_block to bmu : %d \r\n", can_msg_send.dst_addr);    
        can_sofar_send_frame(SDK_INTERNAL_CAN_PORT, frame_tx_id.id_val, data, 4);        
    }
    else
    {
        // log_d("[file_rd] block rd msg \n", can_msg->src_addr, can_msg->src_type);
        if ((g_file_rd_proc_para.src_addr != frame_rx_id.bit.src_addr) || (g_file_rd_proc_para.src_dev_type != frame_rx_id.bit.src_type)
            || (g_file_rd_proc_para.dst_addr != frame_rx_id.bit.dst_addr) || (g_file_rd_proc_para.dst_dev_type != frame_rx_id.bit.dst_type))
        {
            return -1;
        }
        if (g_file_rd_proc_para.file_type != frame_data->data[2])
        {
            return -2;
        }
        g_file_rd_proc_para.finish_flag = frame_data->data[3];
        reply_file_read_finish();
    }
    return 0;
}
/**
* @brief		外can文件读取相关函数注册
* @param		无
* @return		执行结果
* @retval		0： 注册成功
* @retval		-1：注册失败
* @pre			无
*/
static int32_t file_read_can_register(void)
{
    int32_t ret = 0;
    uint16_t rcv_msg_amount = 0;
    can_frame_id_u frame_id[] = 
    {
        // res     prio(优先级), fun_code,    dst_type dst_addr, src_type, src_addr
        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_HIGH_H, .bit.fun_code= FUNC_UP_FILE_START,
         .bit.dst_type= DEV_EXT_BCU, .bit.dst_addr= 0, .bit.src_type= 0, .bit.src_addr =0}, // 0x7F00000
        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_HIGH_H, .bit.fun_code= FUNC_UP_FILE_DATA_BLOCK_START,
         .bit.dst_type= DEV_EXT_BCU, .bit.dst_addr= 0, .bit.src_type= 0, .bit.src_addr =0}, // 0x7F10000
        {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_HIGH_H, .bit.fun_code= FUNC_UP_FILE_FINISH_QUERY,
         .bit.dst_type= DEV_EXT_BCU, .bit.dst_addr= 0, .bit.src_type= 0, .bit.src_addr =0}, // 0x7F40000
    };
    can_sofar_rcv_reg_t can_rxmsg_tab[] = // BMU接收上位机或PCS的数据
    {
        {.id = frame_id[0].id_val, .id_mask = 0x0000FFFF, .p_can_cb = file_read_file_info},   // 0x7F00000
        {.id = frame_id[1].id_val, .id_mask = 0x0000FFFF, .p_can_cb = file_read_block_data}, // 0x7F10000
        {.id = frame_id[2].id_val, .id_mask = 0x0000FFFF, .p_can_cb = file_read_finish},  // 0x7F40000
    };
    // 注册接收的数据
    rcv_msg_amount = sizeof(can_rxmsg_tab)/sizeof(can_sofar_rcv_reg_t);
    ret = ext_can_sofar_register_receive_frame(can_rxmsg_tab, rcv_msg_amount);

    return ret;
}

/**
* @brief		回复读取文件信息报文
* @param		无
* @return		执行结果
* @retval		无
* @pre			无
*/
static int32_t reply_file_info(void)
{
    int32_t ret = 0;
    can_frame_id_u fram_id = {0};
    uint8_t data[8] = {0};

    fram_id.bit.src_addr = g_file_rd_proc_para.dst_addr; // TODO
    fram_id.bit.src_type = g_file_rd_proc_para.dst_dev_type;
    fram_id.bit.dst_addr = g_file_rd_proc_para.src_addr;
    fram_id.bit.dst_type = g_file_rd_proc_para.src_dev_type;
    fram_id.bit.fun_code = FUNC_UP_FILE_START;
    fram_id.bit.prio = SOFAR_CAN_PRI_HIGH_H;

    data[0] = 1;   // 应答帧
    data[1] = 0; // 子设备地址（无）
    data[2] = g_file_rd_proc_para.file_type; // 文件编号
	if (true == g_file_rd_proc_para.file_size_get_flag)
	{
		data[3] = 0; // 结果描述符
	}
	else
	{
		data[3] = 0xff; // 结果描述符
	}  
	data[4] = (uint8_t)(g_file_send_info.file_size & 0x000000ff); // 文件大小
    data[5] = (uint8_t)((g_file_send_info.file_size >> 8) & 0x000000ff); // 文件大小
	data[6] = (uint8_t)((g_file_send_info.file_size >> 16) & 0x000000ff); // 文件大小
    ret = can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, fram_id.id_val, data, 8);
	log_d("[FRd]fileSize:%d\n", g_file_send_info.file_size);
	return ret;
}

/**
* @brief		回复完成文件读取帧
* @param		无
* @return		执行结果
* @retval		无
* @pre			无
*/
static int32_t reply_file_read_finish(void)
{
    int32_t ret = 0;
    can_frame_id_u fram_id = {0};
    uint8_t data[8] = {0};

    fram_id.bit.src_addr = g_file_rd_proc_para.dst_addr; // TODO
    fram_id.bit.src_type = g_file_rd_proc_para.dst_dev_type;
    fram_id.bit.dst_addr = g_file_rd_proc_para.src_addr;
    fram_id.bit.dst_type = g_file_rd_proc_para.src_dev_type;
    fram_id.bit.fun_code = FUNC_UP_FILE_FINISH_QUERY;
    fram_id.bit.prio = SOFAR_CAN_PRI_HIGH_H;

    data[0] = 1; // 应答帧
    data[1] = 0; // 子设备地址（无）
    data[2] = g_file_rd_proc_para.file_type; // 文件编号
    data[3] = (g_file_rd_proc_para.finish_flag == 1) ? 0 : 1;

    ret = can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, fram_id.id_val, data, 8);
    return ret;
}

/**
* @brief		回复完成文件读取帧
* @param		无
* @return		执行结果
* @retval		无
* @pre			无
*/
static int32_t reply_data_block_crc(uint16_t crc_val)
{
    int32_t ret = 0;
    can_frame_id_u fram_id = {0};
    uint8_t data[8] = {0};

    fram_id.bit.src_addr = g_file_rd_proc_para.dst_addr; // TODO
    fram_id.bit.src_type = g_file_rd_proc_para.dst_dev_type;
    fram_id.bit.dst_addr = g_file_rd_proc_para.src_addr;
    fram_id.bit.dst_type = g_file_rd_proc_para.src_dev_type;
    fram_id.bit.fun_code = FUNC_UP_FILE_DATA_BLOCK_CRC;
    fram_id.bit.prio = SOFAR_CAN_PRI_HIGH_H;

    data[0] = 1; // 应答帧
    data[1] = 0; // 子设备地址（无）
    data[2] = g_file_rd_proc_para.file_type; // 文件编号
    data[3] = LOW_BYTE(crc_val);
    data[4] = HIGH_BYTE(crc_val);
    ret = can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, fram_id.id_val, data, 8);
    return ret;
}

/*********************************************文件上传状态机相关*********************************************************************/
/**
* @brief		5分钟日志读取
* @param		[in] file_rd_len 读取五分钟日志的字节数
* @param		[in] file_offset_pos 读取五分钟日志的偏移地址
* @param		[in] p_data 读取五分钟日志的接收缓冲区的大小
* @return       <= 0 读取失败
* @return       >0 此次读取日志字节的长度
* @pre			
*/
static int32_t bms_record_file_info_get(uint32_t file_offset_pos, uint16_t file_rd_len, uint8_t *p_data)
{
    int32_t ret = 0; 

    if((0 != (file_offset_pos % FIVE_MINS_RECORD_MSG_SIZE))
        || (0 != (file_rd_len % FIVE_MINS_RECORD_MSG_SIZE))
        || (0 == file_rd_len)
        )
    {
        ret = -1;
    }
    else
    {
        uint16_t record_max_num = 0;
        record_max_num = sdk_record_get_index(NORMAL_RECORD);
        file_offset_pos = file_offset_pos / FIVE_MINS_RECORD_MSG_SIZE;  //决定读第几条数据
        if(file_offset_pos >= record_max_num)
        {
            ret = -2;
        }
        else
        {        
            ret = sdk_record_read(NORMAL_RECORD, file_offset_pos, p_data, sizeof(bms_record_data_t));
        }
    }

    if(ret >= 0)
    {
        ret = sizeof(bms_record_data_t);
    }
    else
    {
        log_d("bmsRecordFileInfoRead,ret=%d!!\n",ret);
    }


    return ret;

}


/**
* @brief		故障录波文件读取
* @param		[in] file_rd_len 读取故障录波的字节数
* @param		[in] file_offset_pos 读取故障录波的偏移地址
* @param		[in] type 文件类型
* @param		[in] p_data 读取故障录波的接收缓冲区的大小
* @return       <= 0 读取失败
* @return       >0 此次故障录波的长度
* @pre			
*/
static int32_t fault_record_file_info_get(uint32_t file_offset_pos, uint16_t file_rd_len, uint8_t type, uint8_t *p_data)
{
    int32_t ret = 0; 

    if((0 != (file_offset_pos % FIVE_MINS_RECORD_MSG_SIZE))
        || (0 != (file_rd_len % FIVE_MINS_RECORD_MSG_SIZE))
        || (0 == file_rd_len)
        )
    {
        ret = -1;
		goto err_exit;
    }
    else
    {
		;
    }

    return ret;

err_exit:
	log_d("faultRecordFileInfoReadFail,ret=%d!!\r\n",ret);
	return ret;
}

static int32_t running_log_file_info_read(void)
{
    // 关打印以及存储
    // g_log_print_level = sdk_log_level_get(0);
    g_log_storage_level = sdk_log_level_get(1);
    // sdk_log_level_set(0, SDK_LOG_LVL_DISABLE);
    sdk_log_level_set(1, SDK_LOG_LVL_DISABLE);
    if (sdk_log_start() < 0)  // 抢占log资源
	{
		log_d("[FRd]LogOccupy!\n");
		// sdk_log_level_set(0, g_log_print_level); // 恢复打印等级
		sdk_log_level_set(1, g_log_storage_level); // 恢复存储等级
		sdk_log_end(); // 释放log资源
		
		return -1;
	}
	// 获取log大小并限制读取大小
	int32_t sum_size;
    sdk_log_size_t log_size;
	sum_size = sdk_log_size_get(&log_size);
	if (sum_size < 0)
	{
		log_d("GetLogSizeFail!\n");
		// sdk_log_level_set(0, g_log_print_level); // 恢复打印等级
		sdk_log_level_set(1, g_log_storage_level); // 恢复存储等级
		sdk_log_end(); // 释放log资源
		return -1;
	}
	g_file_send_info.file_size = sum_size;
	return 0;
}






static int32_t bms_record_file_info_read(void)
{
    uint16_t record_max_num = 0;

    record_max_num = sdk_record_get_index(NORMAL_RECORD);
	if(record_max_num > 0)
	{
		g_file_send_info.file_size = record_max_num * sizeof(bms_record_data_t);
		set_bms_record_read_flag(true);
	}
	else
	{
		return -1;
	}

	return 0;
}

static int32_t fault_record_file_info_read(void)
{
	int16_t record_max_num = 0;

	record_max_num = sdk_fs_get_size(gp_fs);
	if(record_max_num < 0)
	{
		return -1;
	}
	else
	{
		g_file_send_info.file_size = record_max_num;
		set_fault_record_read_flag(true);
	}	

	return 0;
}



static int32_t read_sending_file_info(uint8_t type)
{
	int32_t ret = 0;
	if (type >= FILE_RD_TYPE_MAX_NUM)
	{
		log_d("[FRd]Type=%d,UnsupportSubmission\n", g_file_rd_proc_para.file_type);
		return -1;
	}
	switch (type)
	{
        case FILE_RD_FAULT_RCD:
		{
			ret = fault_record_file_info_read();
			break;
		}
		case FILE_RD_NORMAL_RCD:
		{
			ret = bms_record_file_info_read();
			break;
		}
		case FILE_RD_RUNNING_LOG:
		{					
			ret = running_log_file_info_read();
			break;
		}
		default:
			break;
	}
	return ret;
}
static int32_t runnig_log_file_send(void)
{
	int32_t ret;

	if (g_file_send_info.block_send_cnt < g_file_send_info.block_total_num)
	{
		int32_t len;
		int32_t offset = g_file_send_info.file_size - g_file_send_info.file_offset_pos;
		if ((g_file_send_info.block_send_cnt + 1) == g_file_send_info.block_total_num)
		{
			len = g_file_send_info.file_rd_len;
		}
		else
		{
			len = FILE_SEND_MAX_DATA_SIZE;
		}
		if (offset < 0)
		{
			return -1;
		}
		ret = sdk_log_read(offset, g_file_send_info.block_data, len);
	}
	else
	{
		return -1;
	}
	if(ret < 0){	
		log_d("[FRd]logReadErrRet=%d\n",ret);
		// sdk_log_level_set(0, g_log_print_level); // 恢复打印等级
		sdk_log_level_set(1, g_log_storage_level); // 恢复存储等级
		sdk_log_end(); // 释放log资源
		return -1;
	}
	g_file_send_info.file_rd_len -= ret;
	g_file_send_info.block_data_len = ret;
	g_file_send_info.block_send_cnt++;
	// log_d("[FRd] log send block %d!\n", g_file_send_info.block_send_cnt);
	if (0 == g_file_send_info.file_rd_len) // 发送完成
	{
		// log_d("[FRd] log send complete!\n");
		g_file_send_info.send_complete_flag = true;
		// sdk_log_level_set(0, g_log_print_level); // 恢复打印等级
		sdk_log_level_set(1, g_log_storage_level); // 恢复存储等级
		// sdk_log_end(); // 释放log资源
	}
	return 0;
}

static int32_t bms_record_file_send(void)
{
	int32_t ret;

	ret = bms_record_file_info_get(g_file_send_info.file_offset_pos,g_file_send_info.file_rd_len,g_file_send_info.block_data);

	if(ret > 0)
	{
		if(g_file_send_info.file_rd_len >= ret)
		{
			g_file_send_info.file_rd_len -= ret;
		}
		g_file_send_info.block_data_len = ret;
		g_file_send_info.block_send_cnt++;
		//log_d("[FRd] bms_record_file send blokc %d \r\n", g_file_send_info.block_send_cnt);

		if(0 == g_file_send_info.file_rd_len)
		{
			g_file_send_info.send_complete_flag = true;
			//log_d("[FRd] bms_record_file send complete!\n");
		}

		return 0;
	}
	else
	{
		log_d("[FRd]bmsRecordFileSendErrRet=%d\n", ret);

		return -1;
	}

}


static int32_t fault_record_file_send(void)
{
	int32_t ret;

	ret = fault_record_file_info_get(g_file_send_info.file_offset_pos,g_file_send_info.file_rd_len,g_file_rd_proc_para.file_type,g_file_send_info.block_data);

	if(ret > 0)
	{
		if(g_file_send_info.file_rd_len >= ret)
		{
			g_file_send_info.file_rd_len -= ret;
		}
		g_file_send_info.block_data_len = ret;
		g_file_send_info.block_send_cnt++;
		//log_d("[FRd] fault_record_file send block %d \r\n", g_file_send_info.block_send_cnt);

		if(0 == g_file_send_info.file_rd_len)
		{
			g_file_send_info.send_complete_flag = true;
			//log_d("[FRd] fault_record_file send complete!\n");
		}

		return 0;
	}
	else
	{
		log_d("[FRd]faultRecordFileSendErrRet=%d!!\n", ret);

		return -1;
	}

}




static int32_t close_send_file(uint8_t type)
{
	if (type >= FILE_RD_TYPE_MAX_NUM)
	{
		log_d("[FRd]type=%d,unsupportClose\n", g_file_rd_proc_para.file_type);
		return -1;
	}
	switch (type)
	{
		case FILE_RD_FAULT_RCD:
		{
			set_fault_record_read_flag(false);
			break;
		}
		case FILE_RD_NORMAL_RCD:
		{
			set_bms_record_read_flag(false);
			break;
		}
		case FILE_RD_RUNNING_LOG:
		{					
			sdk_log_level_set(1, g_log_storage_level); // 恢复存储等级
			sdk_log_end(); // 释放log资源
			break;
		}
		default:
			break;
	}
	return 0;
}
static int32_t send_file_data(uint8_t type)
{
	int32_t ret = 0;
	if (type >= FILE_RD_TYPE_MAX_NUM)
	{
		log_d("[FRd]type=%d,contentUnsupportSubmission\n", g_file_rd_proc_para.file_type);
		return -1;
	}
	switch (type)
	{
		case FILE_RD_FAULT_RCD:
		{
			ret = fault_record_file_send();
			break;
		}
		case FILE_RD_NORMAL_RCD:
		{
			ret = bms_record_file_send();
			break;
		}
		case FILE_RD_RUNNING_LOG:
		{					
			ret = runnig_log_file_send();
			break;
		}

		default:
			break;
	}
	if (!ret) // 读取文件正常
	{
        can_frame_id_u fram_id = {.id_val = 0};
		fram_id.bit.src_addr = g_file_rd_proc_para.dst_addr; // TODO
		fram_id.bit.src_type = g_file_rd_proc_para.dst_dev_type;
		fram_id.bit.dst_addr = g_file_rd_proc_para.src_addr;
		fram_id.bit.dst_type = g_file_rd_proc_para.src_dev_type;
		fram_id.bit.fun_code = FUNC_UP_FILE_DATA_TRAN;
		fram_id.bit.prio = SOFAR_CAN_PRI_HIGH_H;
		can_sofar_send_frame(SDK_EXTERNAL_CAN_PORT, fram_id.id_val, g_file_send_info.block_data, g_file_send_info.block_data_len);
		g_file_send_info.file_offset_pos += g_file_send_info.block_data_len;                          // 读取文件偏移位置更新
        uint16_t crc = crc16_ccitt(g_file_send_info.block_data, g_file_send_info.block_data_len);
        reply_data_block_crc(crc);
		// for(uint16_t i = 0; i <g_file_send_info.block_data_len; i++)
		// {
		// 	log_d("%c", g_file_send_info.block_data[i]);
		// }
	}

	return ret;	
}

static uint8_t sta_file_rd_idle_entry(void)
{
	close_send_file(g_file_rd_proc_para.file_type);
	memset(&g_file_rd_proc_para, 0, sizeof(file_rd_proc_para_t));
	memset(&g_file_send_info, 0, sizeof(file_send_data_info_t));
	memset(&g_bmu_file_read_src, 0, sizeof(bmu_file_read_src_info_t));
	g_bcu_file_read_stus = FILE_READ_WAIT;
	if(NULL != gp_fs)	// 先关闭文件
	{
		sdk_fs_close(gp_fs);
		gp_fs = NULL;
	}	

	log_d("[FRd]Init\n");

	return EVT_NULL;
}

static uint8_t sta_file_rd_file_info_entry(void)
{
	int8_t ret = 0;

    log_d("[FRd]Type=%d,Starting\n", g_file_rd_proc_para.file_type);
	g_file_rd_proc_para.file_size_get_failed_cnt = 0;
	g_file_rd_proc_para.file_size_get_flag = false;
//	g_file_read_stus = FILE_READ_ING;
//	if(g_file_rd_proc_para.file_type < FILE_RD_FAULT_NUM)
//	{
//		if(NULL != gp_fs)	// 先关闭文件
//        {
//            if(0 != sdk_fs_close(gp_fs))
//            {
//                ret = -1;
//                goto err_exit;
//            }
//			else
//			{
//				gp_fs = NULL;
//			}
//        }
//		
//		fault_record_file_t file = fault_record_file_get(g_file_rd_proc_para.file_type);
//		gp_fs = sdk_fs_open(file.file_name, FS_OPEN_ALWAYS | FS_WRITE | FS_READ);
//		if(NULL == gp_fs)
//		{
//			ret = -2;
//			goto err_exit;
//		}
//	}
	return EVT_NULL;
err_exit:
	log_d("[FRd]FileReadFail:%d",ret);
	sdk_fs_close(gp_fs);
	gp_fs = NULL;
	return EVT_NULL;
}
static uint8_t sta_file_rd_file_info_run(void)
{
	uint8_t event = EVT_NULL;
	int32_t ret = 0;
	// 读取需要上传的文件信息
	if (false == g_file_rd_proc_para.file_size_get_flag) // 文件大小未读取成功，需要先读取文件大小
	{
		ret = read_sending_file_info(g_file_rd_proc_para.file_type);
		if (0 != ret)
		{
			g_file_rd_proc_para.file_size_get_failed_cnt++;
			if (g_file_rd_proc_para.file_size_get_failed_cnt > FILE_SZIE_RD_MAX_NUM)
			{
				reply_file_info();
				g_file_rd_proc_para.start_flag = false;
				event = EVT_FILE_RD_ERR_OR_TIMEOUT;
			}
		}
		else
		{
			g_file_rd_proc_para.file_size_get_flag = true;
		}
	}
	else
	{
        reply_file_info();
		g_file_rd_proc_para.start_flag = false;
		g_file_send_info.file_rd_len = g_file_send_info.file_size;
		g_file_send_info.file_offset_pos = 0;
		if (FILE_RD_ALL == g_file_rd_proc_para.file_rd_mode)
		{
			event = EVT_FILE_RD_STA_CPL_SUS;
		}
		else
		{
			event = EVT_FILE_RD_PART;
		}


	}
	return event;
}
static uint8_t sta_file_rd_wait_cont_rd_entry(void)
{
    //log_d("[FRd]  type=%d wait content read\n", g_file_rd_proc_para.file_type);
    g_file_rd_proc_para.stat_cnt_time = sdk_tick_get();
    return EVT_NULL;
}
static uint8_t sta_file_rd_wait_cont_rd_run(void)
{
    uint8_t event = EVT_NULL;
    if (true == sdk_is_tick_over(g_file_rd_proc_para.stat_cnt_time, os_tick_from_millisecond(15000)))
    {
        log_e("[FRd]type=%d waitContentReadTimeOut\n", g_file_rd_proc_para.file_type);
        close_send_file(g_file_rd_proc_para.file_type);
        event = EVT_FILE_RD_ERR_OR_TIMEOUT;
    }
    if (g_file_rd_proc_para.block_data_flag == true)
    {
		g_file_rd_proc_para.block_data_flag = false;
		event = EVT_FILE_RD_STA_CPL_SUS;
	}
    if (g_file_rd_proc_para.finish_flag == true)
    {
        log_e("[FRd]type=%d finish\n", g_file_rd_proc_para.file_type);
        g_file_rd_proc_para.finish_flag = false;
        close_send_file(g_file_rd_proc_para.file_type);
        event = EVT_FILE_RD_ERR_OR_TIMEOUT;
    }
	return event;
}
static uint8_t sta_file_rd_send_data_entry(void)
{
    //log_d("[FRd]  type=%d file send start\n", g_file_rd_proc_para.file_type);
	g_file_send_info.block_total_num = (g_file_send_info.file_rd_len + FILE_SEND_MAX_DATA_SIZE) / FILE_SEND_MAX_DATA_SIZE;
	g_file_send_info.block_send_cnt = 0;
    g_file_rd_proc_para.stat_cnt_time = sdk_tick_get();
    return EVT_NULL;
}
static uint8_t sta_file_rd_send_data_run(void)
{
    uint8_t event = EVT_NULL;
	int32_t ret = 0;
    if (true == sdk_is_tick_over(g_file_rd_proc_para.stat_cnt_time, os_tick_from_millisecond(150)) || (0 == g_file_send_info.block_send_cnt))
	{
		ret = send_file_data(g_file_rd_proc_para.file_type);
		if (ret != 0)
		{
			event = EVT_FILE_RD_ERR_OR_TIMEOUT;
		}
		else
		{
			if (true == g_file_send_info.send_complete_flag)
			{
				event = EVT_FILE_RD_STA_CPL_SUS;
			}
		}
	}
	return event;
}


/**
 * @brief   状态机切换条件判断
 * @param   无
 * @return  返回执行结果 0:正常；<0:异常
 * @warning	无
 */
static uint8_t file_rd_state_chg_condition_check(void)
{
    uint8_t event = EVT_NULL;
    if (g_file_rd_proc_para.start_flag == true)
    {
        g_file_rd_proc_para.start_flag = false;
        event = EVT_FILE_RD_FILE_INFO;
    }
    return event;   
}

/***************************************************************对外接口**************************************************************/

/**
* @brief		文件读取模块初始化
* @param		无
* @return		无
* @retval		无
* @pre			无
*/
void file_read_init(void)
{
    state_machine_init(&g_file_rd_fsm, g_file_rd_fsm_name, g_file_rd_act_map, (uint8_t *)g_file_rd_evt_sta_map,
        FILE_RD_EVT_NUM, FILE_RD_STA_NUM, FILE_RD_IDEL);

	file_read_can_register();
}

/**
* @brief		文件读取任务
* @param		无
* @return		无
* @retval		无
* @pre			无
*/
void file_read_proc(void)
{
    uint8_t event;
    event = file_rd_state_chg_condition_check();
    fsm_state_trans(&g_file_rd_fsm, event);
    event = state_machine_proc(&g_file_rd_fsm);
    fsm_state_trans(&g_file_rd_fsm, event);
    bmu_file_read_stus_clean();
}
