/**********************************************************************************
 * 创建时间: 2023-11-21 13:52:55
 * 邮箱: liulvcong@sofarsolar.com
 * 版本: V1.0
 * 描述:
 * 修改:
 *
 **********************************************************************************/
#include <string.h>
#include "sdk.h"
#include "addressing_common.h"
#include "ext_auto_addressing.h"
#include "auto_addressing.h"
#include "data_store.h"

#define EX_ADDR_MANGE_DEBUG_ENABLE 1    ///< 0禁止打印信息 1使能打印信息
#define EX_ADDR_MANAGE_LOGE(...) if (EX_ADDR_MANGE_DEBUG_ENABLE) log_e(__VA_ARGS__)
#define EX_PROTOCOL_IDENTIFY_OVER_TIME_B10MS  (6000)  // 3次*2种协议*每种协议10s识别时间=1min

/**
 * @brief 外can自动编址类型枚举
 */
typedef enum
{
    EX_PC_ADDRESSING_TYPE = 0,      // 默认PC编址
    EX_MAC_ADDRESSING_TYPE,         ///< gpio编址
    EX_CAN_ADDRESSING_TYPE,         ///< 单纯用can编址
    EX_ADDRESSING_TYPE_NUM,         ///< 外网编址类型个数
} ex_addressing_type_e;


static ex_addressing_type_e g_ex_addressing_type = EX_PC_ADDRESSING_TYPE;
static uint8_t g_ex_addressing_enable_flag = false;
static uint8_t g_ex_can_addr = 0xFF;

/**
 * @brief   设置外can编址功能
 * @param   [in]enable 1:使能， 0:禁能 
 * @warning 
 */
void ex_can_addressing_func_enable(bool enable)
{
    g_ex_addressing_enable_flag = enable;
}

/**
 * @brief   编址方式判断
 * @param   无
 * @warning 后续需要添加识别3ph协议的判断逻辑
 */
static ex_addressing_type_e ex_addressing_type_judge(void)
{
    ex_addressing_type_e type = EX_PC_ADDRESSING_TYPE;
    
    if (0)  // TODO：后续方案确定之后确认 
    {
        ext_can_mac_auto_addressing_set(true);
        type = EX_MAC_ADDRESSING_TYPE;
    }
    return type;
}

/**
 * @brief   外网CAN(bcu)，从机自动编址回复CAN消息处理回调函数
 * @param   无
 * @return  无
 * @warning	无
 */
int32_t ext_addr_common_rcv_callback(can_frame_data_t *frame_data)
{
    if (NULL == frame_data)
    {
        return 0;
    }

    if (g_ex_addressing_type == EX_MAC_ADDRESSING_TYPE)
    {
        return ext_can_mac_addr_rcv_callback(frame_data);
    }
    return 0;
}

static void ex_auto_addr_can_common_register(void)
{
//   uint16_t rec_msg_amount = 0;
//   can_frame_id_u frame_id[] = 
//   {
//       // res     prio(优先级)      type(帧类型)  flag（1:连续，0:非）, fun_code,    dst_type dst_addr, src_type, src_addr
//       // 如果心跳帧优先级修改需要更新check_ext_pack_address()
//       {.bit.res = 0,.bit.prio= SOFAR_CAN_PRI_HEAT, .bit.type= SOFAR_CAN_DATA,   .bit.flag= 0, .bit.fun_code= FUN_HEAT_BEAT,
//        .bit.dst_type= DEV_BCU, .bit.dst_addr= 0, .bit.src_type= DEV_PCS, .bit.src_addr =1}, // 0x197f8021 PCS
//   };
//   can_sofar_rcv_reg_t can_rxmsg_tab[] = // 接收上位机或BCU的数据
//   {
//       {frame_id[0].id_val, 0x0000FFFF, ext_addr_common_rcv_callback},  // 0x197F8021
//   };
//   // 注册接收的数据
//   rec_msg_amount = sizeof(can_rxmsg_tab)/sizeof(can_sofar_rcv_reg_t);
//   can_sofar_register_receive_frame(SDK_EXTERNAL_CAN_PORT, can_rxmsg_tab, rec_msg_amount);
}

/**
 * @brief   自动编址管理初始化
 * @param   无
 * @return  返回执行结果 0:正常；<0:异常
 * @warning	无
 */
void ex_addressing_manage_init(void)
{
    g_ex_addressing_type = EX_PC_ADDRESSING_TYPE;
    ex_auto_addr_can_common_register();
    ext_can_mac_auto_addr_init();
    g_ex_addressing_enable_flag = false;
    
    const bms_attr_t *bms_attr = get_bms_attr();
    if (bms_attr != NULL)
    {
        g_ex_can_addr = (bms_attr->ex_addr) & 0x1F;
        ext_can_set_filter(bms_attr->ex_addr);
    }
}

/**
 * 自动别编址状态机，10ms调用一次
 */
void ex_addressing_manage_proc(void)
{
    if (!g_ex_addressing_enable_flag)
    {
        return;
    }

    g_ex_addressing_type = ex_addressing_type_judge();
    // 自动编址(10ms)
    if (EX_MAC_ADDRESSING_TYPE == g_ex_addressing_type)
    {
        ext_can_mac_auto_addressing_proc();
    }
}

/**
 * @brief  获取外网自动编址状态
 * @return 自动编址状态
 * @warning 其他接口返回值类型需要保持一致
 */
ext_addressing_state_e ext_addressing_manage_state_get(void)
{
    if (EX_PC_ADDRESSING_TYPE == g_ex_addressing_type)
    {
        return (g_ex_can_addr != 0xFF) ? EXT_ADDRESSING_FINISH : EXT_ADDRESSING_ING;
    }
    else if (EX_MAC_ADDRESSING_TYPE == g_ex_addressing_type)
    {
        return ext_can_mac_auto_addressing_get_state();
    }
    else
    {
        return EXT_ADDRESSING_DISENABLE;
    }
}

/**
 * @brief  获取自动编址故障
 * @return 参考ext_addressing_fault_type_e
 */
uint8_t ext_addressing_manage_fault_get(void)
{
    uint8_t ret = AUTO_EXT_ADDRESSING_NO_FAULT;

    if (EX_PC_ADDRESSING_TYPE == g_ex_addressing_type)
    {
        ret |= 0;
    }
    else if (EX_MAC_ADDRESSING_TYPE == g_ex_addressing_type)
    {
        ret |= ext_can_mac_auto_addressing_fault_get();
    }
    return ret;
}

/**
 * @brief  获取编址地址
 * @retval =0     未完成编址
 * @retval 1~0x0F 有效地址
 */
uint8_t ext_addressing_manage_addr_get(void)
{
//    if (EX_PC_ADDRESSING_TYPE == g_ex_addressing_type)
//    {
//        return g_ex_can_addr;
//    }
//    else if (EX_MAC_ADDRESSING_TYPE == g_ex_addressing_type)
//    {
//        return ext_can_mac_auto_addressing_get_address();
//    }
//    else
//    {
//        return BCU_EXT_SLV_ADDR_DFT;
//    }
    
    return g_ex_can_addr;   //地址是写死的，故直接返回这个值就好
}

/**
 * @brief  设置编址地址
 * @retval =0     未完成编址
 * @retval 0xE8-0xF1有效地址
 */
void ext_addressing_manage_addr_set(uint8_t addr)
{
    if (EX_PC_ADDRESSING_TYPE == g_ex_addressing_type)
    {
        g_ex_can_addr = addr & 0x1F;
        data_store_save_bms_attr_thre_val(SET_THRE_EX_CAN_ADDR, (uint16_t)(addr));
        ext_can_set_filter(addr);
    }
}

/**
 * @brief  获取设备数量
 * @retval 1~N 有效的设备数量
 * @retval 0 获取失败
 * @pre    只有编址完成后，才能正确获取PACK数量
 */
uint8_t ext_addressing_dev_num_get(void)
{
    if (EX_PC_ADDRESSING_TYPE == g_ex_addressing_type)
    {
        return 0;//ext_addressing_cluster_num_get();
    }
    else if (EX_MAC_ADDRESSING_TYPE == g_ex_addressing_type)
    {
        return ext_can_mac_auto_addressing_dev_num_get();
    }
    else
    {
        return 1;
    }
}

/*******************************ex_addresing_debug********************************************/
#if EX_ADDR_DEBUG

#endif

#if EX_ADDR_DEBUG
/**
 * @brief                外网编址调试接口
 * @return               返回结果空
 * @warning              测试调试使用
 */
int32_t ex_addr(int argc, char *argv[])
{
    if (argc < 2)
    {
        log_d("exAddrErr\n");
        return SF_ERR_PARA;
    }
    if (!strcmp(argv[1], "print"))
    {
        log_d("addrType=%d\n", g_ex_addressing_type);
        log_d("exAddr=%x\n", g_ex_can_addr | 0xE0);
//        log_d("clusterNum=%d,devNum=%d,%d\n", ext_addressing_cluster_num_get(), ext_can_mac_auto_addressing_dev_num_get(), ext_addressing_dev_num_get());
//        log_d("addr=%d,mac=%d,%d\n", ext_addressing_get_address(), ext_can_mac_auto_addressing_get_address(), ext_addressing_manage_addr_get());
//        log_d("fault=%d,macFault=%d,%d\n", ext_addressing_fault_get(), ext_can_mac_auto_addressing_fault_get(), ext_addressing_manage_fault_get());
    }
    else if (!strcmp(argv[1], "set"))
    {
        if (argc < 3)
        {
            log_d("exAddrSetErr\n");
            return SF_ERR_PARA;
        }
        uint8_t operation = strtol(argv[2], NULL,16); 
        ext_addressing_manage_addr_set(operation);
    }
    else
    {
        return -1;
    }
    return 0;
}

MSH_CMD_EXPORT(ex_addr, <print/set addr(1-4)>);
#endif

