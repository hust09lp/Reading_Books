#ifndef __INNER_CAN_DATA_H__
#define __INNER_CAN_DATA_H__

#include <stdint.h>
#include <stddef.h>
#include "sofar_can_data.h"

//这里按最大空间预留资源
#define PACK_POWER_TERMINAL_TEMP_NUM  2
#define PACK_PASS_BAL_NUM          ((PACK_CELL_NUM_64 + 7) / 8)
#define CLUSTER_MAX_CELL_NUM      (PACK_MAX_NUM * PACK_CELL_NUM_64)
#define CLUSTER_MAX_CELL_VOLT_NUM  (CLUSTER_MAX_CELL_NUM + ((3 - (CLUSTER_MAX_CELL_NUM % 3)) % 3))        // 需要满足3的倍数
#define CLUSTER_MAX_CELL_SOX_NUM   (CLUSTER_MAX_CELL_NUM + ((6 - (CLUSTER_MAX_CELL_NUM % 6)) % 6))         // 需要满足6的倍数
#define CLUSTER_MAX_TEMP_NUM        (PACK_MAX_NUM * PACK_CELL_TEMP_NUM_36)
#define CLUSTER_MAX_CELL_TEMP_NUM  (CLUSTER_MAX_TEMP_NUM + ((6 - (CLUSTER_MAX_TEMP_NUM % 6)) % 6))   // 需要满足6的倍数
#define CLUSTER_MAX_PASS_BAL_NUM   (PACK_PASS_BAL_NUM * PACK_MAX_NUM)  // 使用u8存储，每bit表示一个bit0-7:celln-cell(n+7)
#define CLUSTER_MAX_POWER_TERMINAL_TEMP_NUM  (PACK_POWER_TERMINAL_TEMP_NUM * PACK_MAX_NUM)
#define PACK_CELL_GROUP_NUM       ((PACK_CELL_NUM_64 + SOX_INFO_ONE_GROUP_NUM - 1) / SOX_INFO_ONE_GROUP_NUM - 1)
#define SEND_TIME2 20

/***********  设置参数点表  ***********/
// 主动发送数据类型
typedef enum{
    INN_AUTO_SEND_FORBID_TYPE = 0,
    INN_AUTO_SEND_SLOW_TYPE,
    INN_AUTO_SEND_NORMAL_TYPE,
    INN_AUTO_SEND_DATA_TYPE_NUM,
} inner_auto_send_data_type;

// 触发式发送BMU枚举
typedef enum
{
    INNER_BCU_SET_TIME_MSG = 0,
    INNER_BCU_SET_PARA_MSG,
    INNER_BCU_SEND_DATA_TYPE,
    INNER_BCU_SET_PASS_BAL_STATE_MSG,
} send_inner_can_event_type;

typedef enum
{
    FUNC_INNER_CAN_ONLY_RX_ID = 0,
    // 回复主机
    RX_INNER_SLAVER_CTL_REPLY             = FUNC_INNER_CAN_ONLY_RX_ID,  // BMS回复信息2
    RX_INNER_HEART_BEAT                   ,  // 心跳帧
    RX_INNER_BMU_TIME                     ,  // bmu时间
    // bmu数据上报
    CELL_VOLT_OVERFLOW                    ,  // 电芯电压
    CELL_TEMP_OVERFLOW                    ,  // 电芯温度
    CELL_PASS_BAL_STATE_OVERFLOW          ,  // 电芯被动均衡状态
    RX_INNER_BMS_INTER_INFO2              ,  // BMS发送电池信息2
    RX_INNER_BMS_INTER_INFO3              ,  // BMS发送电池信息3
    RX_INNER_BMS_INTER_INFO4              ,  // BMS发送电池信息4
    RX_INNER_BMS_INTER_INFO5              ,  // BMS发送电池信息5
    RX_INNER_BMS_FAULT_INFO1              ,  // BMS发送内部电池故障信息1
    RX_INNER_BMS_CELL_OTHER_INFO1         ,  // 其他信息
    RX_INNER_BMS_INTER_INFO6              ,  // BMS发送电池信息6
    RX_INNER_BMS_INTER_INFO7              ,  // BMS发送电池信息7
    RX_INNER_BAL_TEMP_INFO1               ,  // BMS均衡温度1-2
    RX_INNER_POWER_MOS_TEMP_INFO          ,  // BMS功率端子温度
    RX_INNER_BMS_FAULT_INFO2              ,  // BMS发送内部电池故障信息2
    RX_INNER_BMS_FAULT_INFO3              ,  // BMS发送内部电池故障信息3
    RX_INNER_BMS_DSG_CALI_INFO            ,  // BMS发送放电末端校准信息
    RX_INNER_BMS_REMOTE_SIGNAL_INFO1      ,  // 遥信数据上报1
    RX_INNER_BMS_REMOTE_SIGNAL_INFO2      ,  // 遥信数据上报2
    RX_INNER_ACT_BAL_INFO1                ,  // 主动均衡数据上报1
    RX_INNER_ACT_BAL_INFO2                ,  // 主动均衡数据上报2
    RX_INNER_SOFT_VER_INFO1               ,  // 设备软件版信息1
    RX_INNER_SOFT_VER_INFO2               ,  // 设备软件版信息2
    RX_INNER_SOFT_VER_INFO3               ,  // 设备软件版信息3
    RX_INNER_BMS_REMOTE_SIGNAL_INFO3      ,  // 其他数据上报
    RX_INNER_CELL_SOC_INFO                ,  // 单电芯SOC
    RX_INNER_CELL_SOH_INFO                ,  // 单电芯SOH
    RX_INNER_BMU_PACK_SN                  ,  // 标目 pack sn
    RX_INNER_BMU_BOARD_SN                 ,  // 标目 board sn
    INNER_RX_MSG_CNT,
} inner_rx_frame_data_id_e;

// can接收bmu设备枚举
typedef enum
{
    // 0x06A：设备软件版信息1
    BMU_DEV_SW_VT_VER = 0,
    BMU_DEV_SW_BIG_VER,
    BMU_DEV_SW_MIDDLE_VER,
    BMU_DEV_SW_SAMLL_VER,
    BMU_DEV_HW_VER,
    BMU_DEV_CAN_VER_L,
    BMU_DEV_CAN_VER_H,
    // 0x06B：设备软件版信息3
    BMU_DEV_SYS_CAP_L,
    BMU_DEV_SYS_CAP_H,
    BMU_DEV_MANU_REG_ID_L,
    BMU_DEV_MANU_REG_ID_H,
    BMU_DEV_BAT_TYPE_L,
    BMU_DEV_BAT_TYPE_H,
    // 0x06C：设备软件版信息4
    BMU_DEV_MANU_NAME1_L,
    BMU_DEV_MANU_NAME1_H,
    BMU_DEV_MANU_NAME2_L,
    BMU_DEV_MANU_NAME2_H,
    BMU_DEV_MANU_NAME3_L,
    BMU_DEV_MANU_NAME3_H,
    BMU_DEV_MANU_NAME4_L,
    BMU_DEV_MANU_NAME4_H,
    // pack sn start
    BMU_DEV_PACK_SN_START,
    BMU_DEV_PACK_SN1 = BMU_DEV_PACK_SN_START,
    BMU_DEV_PACK_SN2,
    BMU_DEV_PACK_SN3,
    BMU_DEV_PACK_SN4,
    BMU_DEV_PACK_SN5,
    BMU_DEV_PACK_SN6,
    BMU_DEV_PACK_SN7,
    BMU_DEV_PACK_SN8,
    BMU_DEV_PACK_SN9,
    BMU_DEV_PACK_SN10,
    BMU_DEV_PACK_SN11,
    BMU_DEV_PACK_SN12,
    BMU_DEV_PACK_SN13,
    BMU_DEV_PACK_SN14,
    BMU_DEV_PACK_SN15,
    BMU_DEV_PACK_SN16,
    BMU_DEV_PACK_SN17,
    BMU_DEV_PACK_SN18,
    BMU_DEV_PACK_SN19,
    BMU_DEV_PACK_SN20,
    BMU_DEV_PACK_SN21,
    BMU_DEV_PACK_SN_END,
    // board sn start
    BMU_DEV_BOARD_SN_START = BMU_DEV_PACK_SN_END,
    BMU_DEV_BOARD_SN1 = BMU_DEV_BOARD_SN_START,
    BMU_DEV_BOARD_SN2,
    BMU_DEV_BOARD_SN3,
    BMU_DEV_BOARD_SN4,
    BMU_DEV_BOARD_SN5,
    BMU_DEV_BOARD_SN6,
    BMU_DEV_BOARD_SN7,
    BMU_DEV_BOARD_SN8,
    BMU_DEV_BOARD_SN9,
    BMU_DEV_BOARD_SN10,
    BMU_DEV_BOARD_SN11,
    BMU_DEV_BOARD_SN12,
    BMU_DEV_BOARD_SN13,
    BMU_DEV_BOARD_SN14,
    BMU_DEV_BOARD_SN15,
    BMU_DEV_BOARD_SN16,
    BMU_DEV_BOARD_SN17,
    BMU_DEV_BOARD_SN18,
    BMU_DEV_BOARD_SN19,
    BMU_DEV_BOARD_SN20,
    BMU_DEV_BOARD_SN21,
    BMU_DEV_BOARD_SN_END,
    BMU_DEV_NUM = BMU_DEV_BOARD_SN_END,
} bmu_dev_list_e;

// 遥测一个字节数据
typedef enum
{
    YC1_UNS_MAX_CELL_V_ID = 0,
    YC1_UNS_MIN_CELL_V_ID,
    YC1_UNS_MAX_CELL_T_ID,
    YC1_UNS_MIN_CELL_T_ID,
    YC1_UNS_BMU_RESET_TYPE,
    // cell soc start
//    YC1_UNS_CELL_SOC_START,
//    YC1_UNS_CELL_SOC1 = YC1_UNS_CELL_SOC_START,
//    YC1_UNS_CELL_SOC2,
//    YC1_UNS_CELL_SOC3,
//    YC1_UNS_CELL_SOC4,
//    YC1_UNS_CELL_SOC5,
//    YC1_UNS_CELL_SOC6,
//    YC1_UNS_CELL_SOC7,
//    YC1_UNS_CELL_SOC8,
//    YC1_UNS_CELL_SOC9,
//    YC1_UNS_CELL_SOC10,
//    YC1_UNS_CELL_SOC11,
//    YC1_UNS_CELL_SOC12,
//    YC1_UNS_CELL_SOC13,
//    YC1_UNS_CELL_SOC14,
//    YC1_UNS_CELL_SOC15,
//    YC1_UNS_CELL_SOC16,
//    YC1_UNS_CELL_SOC_END,
    // cell soh start
//    YC1_UNS_CELL_SOH_START = YC1_UNS_CELL_SOC_END,
//    YC1_UNS_CELL_SOH1 = YC1_UNS_CELL_SOH_START,
//    YC1_UNS_CELL_SOH2,
//    YC1_UNS_CELL_SOH3,
//    YC1_UNS_CELL_SOH4,
//    YC1_UNS_CELL_SOH5,
//    YC1_UNS_CELL_SOH6,
//    YC1_UNS_CELL_SOH7,
//    YC1_UNS_CELL_SOH8,
//    YC1_UNS_CELL_SOH9,
//    YC1_UNS_CELL_SOH10,
//    YC1_UNS_CELL_SOH11,
//    YC1_UNS_CELL_SOH12,
//    YC1_UNS_CELL_SOH13,
//    YC1_UNS_CELL_SOH14,
//    YC1_UNS_CELL_SOH15,
//    YC1_UNS_CELL_SOH16,
//    YC1_UNS_CELL_SOH_END,
    // bmu_time start
    YC1_UNS_TIME_START, //= YC1_UNS_CELL_SOH_END,
    YC1_UNS_TIME_YEAR = YC1_UNS_TIME_START,
    YC1_UNS_TIME_MON,
    YC1_UNS_TIME_DAY,
    YC1_UNS_TIME_HOUR,
    YC1_UNS_TIME_MIN,
    YC1_UNS_TIME_SEC,
    YC1_UNS_TIME_END,
    YC1_BYTE_NUM = YC1_UNS_TIME_END,
} yc1_data_e;

// 遥测两个字节数据
typedef enum
{
    // 0x004:BMS发送电池信息2
    YC2_UNS_PACK_VOLT = 0,      //电池电压  0.1V
    YC2_UNS_LOAD_VOLT,          //负载电压  0.1V
    YC2_SGN_PACK_CURR,
    YC2_UNS_PACK_SOC,
    // 0x005:BMS发送电池信息3
    YC2_UNS_MAX_CELL_VOLT,      //pack最高单体电压 1mv
    YC2_UNS_MIN_CELL_VOLT,      //pack最低单体电压 1mv
    YC2_UNS_AVG_CELL_VOLT,      //pack平均单体电压 1mv
    // 0x006:BMS发送电池信息4
    YC2_SGN_MAX_CELL_TEMP,
    YC2_SGN_MIN_CELL_TEMP,
    YC2_SGN_AVG_CELL_TEMP,
    // 0x00E：其他信息
    YC2_SGN_MOS_TEMP,
    YC2_SGN_ENV_TEMP,
    YC2_UNS_PACK_SOH,
    YC2_UNS_PASS_BAL_STATE,
    // 0x00F：BMS发送电池信息6
    YC2_UNS_REMAIN_CAP_AH,
    YC2_UNS_FULL_CAP_AH,
    YC2_UNS_CYCLE_TIME,
    // 0x041：BMS均衡温度1-2
    YC2_SGN_PASS_BAL_TEMP1,
    YC2_SGN_PASS_BAL_TEMP2,
    YC2_SGN_DCDC_TEMP1,
    YC2_SGN_DCDC_TEMP2,
    // 0x04A：BMS功率端子温度
    YC2_SGN_POWER_TEMP1,
    YC2_SGN_POWER_TEMP2,
    // 0x048：主动均衡数据上报1
    YC2_UNS_ACT_BAL_PRI_VOLT,
    YC2_SGN_ACT_BAL_PRI_CURR,
    YC2_UNS_ACT_BAL_MAX_CELL_VOLT,

    // 0x049：主动均衡数据上报2
    YC2_UNS_ACT_BAL_CELL_SOC,
    YC2_UNS_ACT_BAL_ACC_CAP,
    YC2_UNS_ACT_BAL_REMAIN_CAP,
    // 0x04C：BMS发送被动均衡控制和电解液漏液传感器漏液浓度
	YC2_BMU_BAL_STATE,
	YC2_MIN_CELL_SOC,    
	YC2_ELECTROLYTE_STREN,        
    // 0x06D：其他数据上报
    YC2_UNS_AUX_VOLT,
    YC2_UNS_CHG_CURR_ZERO_VOLT,
    YC2_UNS_DSG_CURR_ZERO_VOLT,
    // cell volt start 不能修改中间参数
//    YC2_UNS_CELL_VOLT_START,
//    YC2_UNS_CELL_VOLT1 = YC2_UNS_CELL_VOLT_START,
//    YC2_UNS_CELL_VOLT2,
//    YC2_UNS_CELL_VOLT3,
//    YC2_UNS_CELL_VOLT4,
//    YC2_UNS_CELL_VOLT5,
//    YC2_UNS_CELL_VOLT6,
//    YC2_UNS_CELL_VOLT7,
//    YC2_UNS_CELL_VOLT8,
//    YC2_UNS_CELL_VOLT9,
//    YC2_UNS_CELL_VOLT10,
//    YC2_UNS_CELL_VOLT11,
//    YC2_UNS_CELL_VOLT12,
//    YC2_UNS_CELL_VOLT13,
//    YC2_UNS_CELL_VOLT14,
//    YC2_UNS_CELL_VOLT15,
//    YC2_UNS_CELL_VOLT16,
//    YC2_UNS_CELL_VOLT_END,
    // cell temp start 不能修改中间参数
//    YC2_UNS_CELL_TEMP_START = YC2_UNS_CELL_VOLT_END,
//    YC2_UNS_CELL_TEMP1 = YC2_UNS_CELL_TEMP_START,
//    YC2_UNS_CELL_TEMP2,
//    YC2_UNS_CELL_TEMP3,
//    YC2_UNS_CELL_TEMP4,
//    YC2_UNS_CELL_TEMP5,
//    YC2_UNS_CELL_TEMP6,
//    YC2_UNS_CELL_TEMP7,
//    YC2_UNS_CELL_TEMP8,
//    YC2_UNS_CELL_TEMP_END,
    YC2_WORD_NUM ,//= YC2_UNS_CELL_TEMP_END,
} yc2_data_e;

// 遥测4个字节数据
typedef enum
{
    YC3_UNS_TOTAL_CHG_CAP_AH = 0,
    YC3_UNS_TOTAL_DSG_CAP_AH,
    YC3_UNS_TOTAL_CHG_CAP_WH,
    YC3_UNS_TOTAL_DSG_CAP_WH,
    YC3_DWORD_NUM,
} yc3_data_e;

// 遥信数据
//
typedef enum
{
    // 0x008 故障信息
    YX_BMU_PACK_CELL_VOLT_FAULT = 0,
    YX_BMU_CELL_TEMP_FAULT,
    YX_BMU_CURR_TEMP_FAULT,
    YX_BMU_SOC_SAM_FAULT,
    YX_BMU_MOS_FAULT,
    YX_BMU_CAN_FAULT,
    YX_BMU_CHG_CURR_ZERO_VOLT_FAULT,
    YX_BMU_DSG_CURR_ZERO_VOLT_FAULT,
    // 0x045:BMS发送内部电池故障信息2
    YX_BMU_ACT_BAL_FAULT1,
    YX_BMU_ACT_BAL_FAULT2,
    YX_BMU_CELL_VOLT_LOCK_FAULT,
    YX_BMU_CELL_TEMP_LOCK_FAULT,
    YX_BMU_SAM_LINE_FAULT,
    YX_BMU_HEAT_ALARM,
    YX_BMU_OTHER_FAULT,
    YX_BMU_RES3_FAULT,
    // 0x04B:BMS发送内部电池故障信息3
    YX_BMU_CELL_TIP1,
    YX_BMU_CELL_TIP2,
    YX_BMU_CELL_ALARM,
    YX_BMU_CELL_FAULT,
    YX_BMU_FAULT_LEVEL,    
    // 0x04C:BMS发送放电末端校准信息
    YX_BMU_DSG_CALI_UTABLE_1,
    YX_BMU_DSG_CALI_UTABLE_2,
    YX_BMU_DSG_CALI_SOC_1,
    YX_BMU_DSG_CALI_SOC_2,
	YX_BMU_DSG_CALI_MIN_CELL_VOL_1,
    YX_BMU_DSG_CALI_MIN_CELL_VOL_2,
    // 0x046：遥信数据上报1
    YX_BMU_REQ_ENABLE_1,
    YX_BMU_REQ_ENABLE_2,
    YX_BMU_CHG_DSG_STATE,
    YX_BMU_DI_STATE,
    // 0x047：遥信数据上报2
    YX_BMU_SYNC_FALL_SOC,
    YX_BMU_SYS_STATE,
    YX_BMU_ACT_BAL_STATE,
    YX_BMU_CHG_CURR_LIMIT_L,
    YX_BMU_CHG_CURR_LIMIT_H,
    YX_BMU_DSG_CURR_LIMIT_L,
    YX_BMU_DSG_CURR_LIMIT_H,
    YX_BMU_BYTE_NUM,
} yx_bmu_data_e;

typedef enum
{
    PACK_INFO_DEV_TYPE = 0,
    PACK_INFO_YX_TYPE,
    PACK_INFO_YC1_TYPE,
    PACK_INFO_YC2_TYPE,
    PACK_INFO_YC3_TYPE,
    PACK_INFO_TYPE_NUM,
} pack_info_type_e;

typedef struct
{
    uint8_t dev[BMU_DEV_NUM];
    uint8_t yx[YX_BMU_BYTE_NUM];
    uint8_t yc1[YC1_BYTE_NUM];
    uint16_t yc2[YC2_WORD_NUM];
    uint32_t yc3[YC3_DWORD_NUM];
}pack_info_t;

// 从pack_info_t里面拆分出来，主要为了数据上传方便
typedef struct
{
    uint16_t cell_volt[CLUSTER_MAX_CELL_VOLT_NUM];
    int8_t cell_temp[CLUSTER_MAX_CELL_TEMP_NUM];
    uint8_t cell_soc[CLUSTER_MAX_CELL_SOX_NUM];
    uint8_t cell_soh[CLUSTER_MAX_CELL_SOX_NUM];
    uint8_t pass_bal_state[PACK_MAX_NUM][PACK_CELL_NUM_64 / 8];  //
}pack_cell_info_t;

typedef struct
{
    uint8_t called;             // 0：无can霍尔  1：有can霍尔
    uint8_t error_information;  // 0:正常 1:故障
    uint8_t rx_quality;         // 接受质量信息：0~100
    uint8_t hall_data[8];
    int32_t hall_data_deal;     //处理后的霍尔数据
}pack_other_device_info_t;

// 发送bmu遥信数据请求数据
typedef struct
{
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t chg_enale : 1;
            uint8_t dsg_enale : 1;
            uint8_t bmu_cut_off_req : 1;
            uint8_t bmu_pow_off_req : 1;
            uint8_t force_chg_req : 1;
            uint8_t bmu_sync_thre_val_req : 1;
            uint8_t res1 : 2;
        } bits;
    } req;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t heat_req : 2;
            uint8_t res1 : 6;
        } bits;
    } req2;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t full_chg : 1;
            uint8_t empty_dsg : 1;
            uint8_t res1 : 6;
        } bits;
    } state;
} bmu_yx_req_data;

typedef enum
{
    SYNC_THRE_VAL_INIT = 0,
    SYNC_THRE_VAL_CHECK,
    SYNC_THRE_VAL_SUCC,
    SYNC_THRE_VAL_ERR,
    SYNC_THRE_VAL_NUM,
} bmu_alm_thre_val_sync_e;

/**
* @brief		内网初始化
* @param		无
* @return		无
* @retval		无
* @warning		无
*/
void can_inner_data_init(void);

/**
* @brief		自动发送内网数据
* @param		[in]base_time 任务周期时间 ms
* @return		返回结果
* @retval		无
* @warning		无
*/
void can_inner_data_send_proc(void);

/**
* @brief		请求bmu数据处理函数
* @return		返回结果
* @retval		无
* @warning		无
*/
void can_inner_req_data_proc(void);

/**
* @brief		自动发送内网数据功能设置接口
* @param		[in]inner_auto_send_data_type
* @return		返回结果
* @retval		0：操作成功    < 0: 操作失败
* @warning		无
*/
int32_t auto_send_can_inner_func_set(uint8_t type);

/**
* @brief		校准发送内使能接口
* @param
* @return		返回结果
* @retval
* @warning		无
*/
void event_send_adjust_time(void);

/**
* @brief		内can产生数据事件
* @param		[in]type 参考send_inner_can_event_type
* @return		返回结果
* @retval		无
* @warning		无
*/
void event_send_inner_data(send_inner_can_event_type type);

// index 范围 0~PACK_MAX_NUM-1
pack_info_t* get_bmu_info(uint8_t index);
const pack_cell_info_t* get_bmu_cell_info(void);
const pack_other_device_info_t* get_other_device_info(void);
// 设置被动均衡状态0x101EFFE0
bool inner_can_tx_pass_bal_set(can_frame_data_t *can_data, uint16_t func_code);
void send_bmu_act_bal_ctrl(void);

void send_bmu_dsg_cali_ctrl(void);

// 获取每个电池包的通讯失败标志，0:失败 1:成功
uint16_t singal_bmu_bcu_com_fault_flag_get(void);

/**
* @brief		内网数据初始化
* @param		无
* @return		无
* @retval		无
* @warning		无
*/
void pack_data_init(void);
/**
* @brief        启动bmu阈值检测
* @warning      无
*/
void bmu_alarm_thre_val_check_start(void);

/**
* @brief        清除bmu阈值异常错误
* @warning      无
*/
void bmu_alarm_thre_val_check_err_clear(void);

/**
* @brief        获取bmu阈值检测状态
* @return       1： err  0：normal
*/
uint8_t bmu_alarm_thre_val_check_state_get(void);

#endif
