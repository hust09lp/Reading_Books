#ifndef __ADDRESSING_COMMON_H__
#define __ADDRESSING_COMMON_H__

#include <stdint.h>
#include <stddef.h>
#include "sofar_can_manage.h"

#define EX_ADDR_DEBUG 1
/**
 * @brief 协议类型
 */
typedef enum
{
    EXT_CAN_DEF = 0,  // 默认协议
    EXT_CAN__3PH,     ///< 3ph
} ext_can_agreement_type_e;

/**
 * @brief 编址状态
 */
typedef enum
{
    EXT_ADDRESSING_DISENABLE = 0, ///< 未使能自动编址
    EXT_ADDRESSING_ING,           ///< 编址中
    EXT_ADDRESSING_FINISH,        ///< 编址完成
} ext_addressing_state_e;

/**
 * @brief 主从机标志
 */
typedef enum
{
    EXT_CAN_MAC_NON = 0,      ///< 默认类型
    EXT_CAN_MAC_SLAVER,       ///< 从机类型
    EXT_CAN_MAC_MASTER,       ///< 主机类型
} ext_can_mac_type_e;

/**
 * @brief 编址故障
 */
typedef enum
{
    AUTO_EXT_ADDRESSING_NO_FAULT = 0,      ///< 没故障
    AUTO_EXT_ADDRESSING_ID_CONFLICT = 1,       ///< 通讯ID冲突
    AUTO_EXT_ADDRESSING_COMM_FAIL = 2,         ///< 通讯故障
    AUTO_EXT_PCS_COM_FAIL = 4,                 ///< PCS通讯故障
    AUTO_EXT_ADDRESSING_ABNORMAL_FAIL = 0x8,     ///< 编址异常
    AUTO_EXT_ADDRESSING_PIN_FAIL = 0x10,          ///< 编址电平异常
} ext_addressing_fault_type_e;

typedef enum
{
    EXT_NON_MAS_CAN_ADDR_SET_CMD = 0,        // 0x00:无操作
    EXT_CAN_MAS_ADDR_SET_IO_HIGH_CMD = 0x01, // 0x01:拉高ID_OUT
    EXT_CAN_MAS_ADDR_SET_IO_LOW_CMD = 0x02,  // 0x02:下拉ID_OUT
    EXT_CAN_MAS_SET_ADDR_CMD  = 0x03,        // 0x03:主机设置地址
    EXT_CAN_MAS_SET_START_ADDR_CMD = 0x7E,   // 0x7E： 主机设置重新编址
} ext_can_mas_addr_set_cmd_u;

typedef enum
{
    EXT_NON_CAN_RX_SLA_ADDR_SET_CMD = 0,        // 0x00:无操作
    EXT_CAN_RX_SLA_ADDR_SET_IO_HIGH_CMD = 0x01, // 0x01:拉高ID_OUT
    EXT_CAN_RX_SLA_ADDR_SET_IO_LOW_CMD = 0x02,  // 0x02:下拉ID_OUT
    EXT_CAN_RX_SLA_SET_ADDR_CMD  = 0x03,        // 0x03: 从机编址完成
    EXT_CAN_RX_SLA_ADDR_CONFLICT_CMD = 0x7C,    // 从机地址冲突
    EXT_CAN_RX_SLA_SET_START_ADDR_CMD = 0x7E,   // 0x7E：从机请求编址
} ext_can_recv_sla_addr_cmd_u;

#define BCU_EXT_MASTER_CAN_ADDR         0x01   // bcu主机CAN地址
#define BCU_EXT_SLV_ADDR_DFT            0x1F  // 未编址前的默认地址
#define MAX_3PH_DEV_NUM 4               // 3ph电池簇数据最大值修改
#define CLUSTER_MAX_NUM 4               // 最多4簇电池并机
#define EXT_AUTO_ADDR_ABNORMAL_MAX_NUM  5 // 连续编址失败最大次数

#define EXT_AUTO_ADDR_TIME_B10MS         (10)    // 10ms任务
#define EXT_AUTO_ADDR_ONE_SEC_TIME_CNT  (1000 / EXT_AUTO_ADDR_TIME_B10MS) // 1s的运行次数
#define EXT_AUTO_ADDR_1S_TIMER          (1 * EXT_AUTO_ADDR_ONE_SEC_TIME_CNT)
#define EXT_AUTO_ADDR_2S_TIMER          (1 * EXT_AUTO_ADDR_ONE_SEC_TIME_CNT)
#define EXT_AUTO_ADDR_200MS_BASE_CNT    (200 / EXT_AUTO_ADDR_TIME_B10MS)  // 200ms对应的运行次数
#define EXT_AUTO_ADDR_100MS_BASE_CNT    (100 / EXT_AUTO_ADDR_TIME_B10MS)  // 100ms对应的运行次数
#define EXT_AUTO_ADDR_50MS_BASE_CNT     (50 / EXT_AUTO_ADDR_TIME_B10MS)  // 100ms对应的运行次数
#define EXT_ADDR_WAIT_BMU_START_TIME     EXT_AUTO_ADDR_1S_TIMER    // 10MS任务中运行，延时1000ms
#define EXT_ADDR_START_DELAY_TIME       (50 / EXT_AUTO_ADDR_TIME_B10MS)   // 10MS任务中运行，延时50ms
#define EXT_ADDR_DEV_UNLINK_TIME_OUT    (3 * EXT_AUTO_ADDR_1S_TIMER)

/**
 * @brief  获取设备数量
 * @retval 1~N 有效的设备数量
 * @retval 0 获取失败
 * @pre    只有编址完成后，才能正确获取PACK数量
 */
uint8_t ext_addressing_dev_num_get(void);

/**
 * @brief  获取编址地址
 * @retval =0     未完成编址
 * @retval 1~0x0F 有效地址
 */
uint8_t ext_addressing_manage_addr_get(void);

/**
 * @brief  获取自动编址故障
 * @return 参考ext_addressing_fault_type_e
 */
uint8_t ext_addressing_manage_fault_get(void);

/**
 * @brief  获取外网自动编址状态
 * @return 自动编址状态
 * @warning 其他接口返回值类型需要保持一致
 */
ext_addressing_state_e ext_addressing_manage_state_get(void);

/**
 * 自动别编址状态机，10ms调用一次
 */
void ex_addressing_manage_proc(void);

/**
 * @brief   自动编址管理初始化
 * @param   无
 * @return  返回执行结果 0:正常；<0:异常
 * @warning	无
 */
void ex_addressing_manage_init(void);

/**
 * @brief   判断是否为3ph协议
 * @param   无
 * @warning 后续判断函数由3ph协议文件判断 TODO
 */
uint8_t ex_can_agreement_type_get(void);

/**
 * @brief   设置外can编址功能
 * @param   [in]enable 1:使能， 0:禁能 
 * @warning 
 */
void ex_can_addressing_func_enable(bool enable);

/**
 * @brief  设置编址地址
 * @retval =0     未完成编址
 * @retval 8~17 有效地址
 */
void ext_addressing_manage_addr_set(uint8_t addr);
#endif
