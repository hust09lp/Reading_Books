/**
    * @file     bcu_data.h
    * @brief    Bcu簇间信息
    * @company  sofarsolar
    * @author   
    * @note
    * @version
    * @date     2023/4/24
*/

#ifndef __BCU_DATA_H__
#define __BCU_DATA_H__

#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include "sofar_can_manage.h"



#define MAX_CLU_NUM  10
#define GOLD_ALM_TYPE          0
#define GOLD_SERIOUS_ALM_TYPE  1
#define GOLD_GENERAL_ALM_TYPE  2
#define GOLD_MINOR_ALM_TYPE    3
#define GOLD_DEV_HARD_ALM_TYPE 4

typedef enum
{
    CLU_POWER_INIT_STATE = 0,
    CLU_POWER_ON_SIGNAL,
    CLU_POWER_OFF_SIGNAL,
    CLU_POWER_FAULT_OFF_SIGNAL,
    CLU_POWER_ON_ALL,
    CLU_POWER_OFF_ALL,
    CLU_POWER_FAULT_OFF_ALL,
} power_state_e;

// 簇间接收到的数据(每簇单独的)
typedef struct
{
    // 0x1890FF00
    uint16_t clu_volt; // 分辨率0.1V
    int16_t  clu_curr; // 0.1A
    uint8_t clu_soc;   // 1%
    uint8_t clu_soh;   // 1%
    uint8_t clu_di_stus;   // 1:表示有效，0：表示无效； Bit0~Bit4:DI1、DI3、DI5、DI7、DI8状态， Bit5~6：预留 Bit7：绝缘采集状态 
    uint8_t clu_do_stus;   // 1:表示有效，0：表示无效； Bit0~7:DO1-8状态
    // 0x1891FF00
    uint16_t clu_max_cell_volt;  // 1mV
    int8_t clu_max_cell_temp;    // 1℃
    uint8_t clu_max_cell_soc;    // 1%
    uint16_t clu_min_cell_volt;  // 1mV
    int8_t clu_min_cell_temp;    // 1℃
    uint8_t clu_min_cell_soc;    // 1%
    // 0x1892FF00
    uint8_t tip_warn[3];     // bit  0：无报警；1：报警
    uint8_t alm_warn[3];
    uint8_t pro_warn[3];
    uint8_t dev_fault[3];    // bit  0：无报警；1：报警
    uint16_t pro_fault_deal;
    uint16_t pro_fault_num;
    uint16_t dev_fault_deal;
    uint16_t dev_fault_num;
    // 0x1895FF00
    uint8_t clu_maintenance_stus;     // 簇维护状态 （ 0 ：不维护   1 ：正在维护    2：维护结束）
    uint8_t clu_out_stus;             // 退簇状态（0：正常 1：退簇完成）
    // 
    uint8_t exist; // 0:不存在
}other_clu_data;

typedef enum
{
    CLU_SINGLE = 0,
    CLU_PARALLEL,
} clu_mode_e;


typedef struct
{
    uint8_t chg_enable;
    uint8_t dsg_enable;
    uint8_t fault_state;                // 故障状态
    uint8_t clu_mode;                   // 簇模式
    uint8_t clu_bcu_maintenance_state; // 簇维护状态（ 0 ：不维护  1 ：正在维护  2：维护结束）
    uint8_t out_clu_state;             // 退簇状态（0：正常 1：退簇完成）
    uint8_t out_clu_process;           // 0:无操作  1:允许退簇  2:禁止退簇  3:允许并簇  4:禁止并簇  5:故障下电
    uint8_t confilct_id_flag;          // 地址冲突标志
} bcu_data_unify_t;

// 高特霍尔使能标志
typedef union{
    uint8_t curr_sensor_type;
    struct{
        uint8_t hall1_enble:   1;    // 霍尔1使能标志
        uint8_t hall2_enble:   1;    // 霍尔2使能标志
        uint8_t hall3_enble:   1;    // 霍尔3使能标志
        uint8_t res:           4;     // 保留
        uint8_t double_hall:   1;    // 双霍尔标志
    }bit;
} hall_type_enable_flag;

// 簇间综合数据（对簇数据做一个处理）
typedef struct
{
    int16_t heap_curr;  // 0.1A
    uint16_t parallel_clu_volt; // 0.1V
    uint16_t max_clu_volt_diff; // 0.1V
    uint16_t max_clu_volt;      // 0.1V
    uint16_t min_clu_volt;      // 0.1V
    uint16_t max_clu_curr;      // 0.1A, 偏差-1600A
    uint16_t min_clu_curr;      // 0.1A, 偏差-1600A
    int16_t max_clu_curr_diff; // 0.1A
    uint16_t parallel_state;    // bit0~bit9:表示并入情况， 1并入，0断开
    uint8_t clu_bcu_num;        // bcu的个数
    power_state_e set_power_state; // cmu设置上下电状态 
    uint8_t set_fault_recover_flag; // 0x55 表示故障复归有效（在主控正常下电成功/正常下电失败/故障下电后，可通过此指令进行尝试重新上高压）
    uint8_t set_clu_volt_diff_state; // 0：默认状态 1：10V 以下  2：10V~20V  3：20V 以上  4：上电完成（所有簇主控上传上电完成后为 4）故障复归时清除
    // Bit7：复归指令0：默认状态1：复归准备指令（持续发送 5 秒或者接收到所有簇主控上传 1后，复归指令发送 0），主控接收到 1->0 变化时进行复归处理
    // Bit6：跳机指令0：默认状态1：跳机（主控延迟 5秒切断接触器）故障复归时清除
    // Bit5:显控故障0：默认状态1：故障状态
    // Bit4~1：预留
    // Bit0：故障状态
    uint8_t set_clu_state;
    uint8_t set_maintenance_state[2];
    uint8_t set_ins_state[2];
    uint8_t set_out_clu_state;       // 0:无操作  1:允许退簇  2:禁止退簇 3:允许并簇  4:禁止并簇  5:故障下电
    uint8_t set_out_clu[3];          // [0]Bit0~7：BCM#1~#8  [1]Bit0~7：BCM#9~#16  （1：退簇 0：不操作）
    uint8_t set_run_clu[3];          // [0]Bit0~7：BCM#1~#8  [1]Bit0~7：BCM#9~#16  （1：使能 0：不使能）
    uint8_t set_clu_sw   ;
    uint8_t set_clu_do   ;//0：关闭 1：闭合
    //BIT7 预留
    //BIT6 预留
    //BIT5 指示灯-红
    //BIT4 指示灯-绿
    //BIT3 紧急停机信号
    //BIT2 主负继电器
    //BIT1 环流继电器
    //BIT0 主正继电器
    uint8_t set_clu_clock;
}gold_bcu_integration_data;

typedef enum
{
    DO1,    //主正继电器
    DO2,    //环流继电器
    DO3,    //主负继电器
    DO4,    //预留
    DO5,    //指示灯-绿
    DO6,    //指示灯-红
    DO7,    //辅助接触器
    DO8,    //预留
} clu_do_state_e;



/**
 * @brief                bcu簇间数据设置
 * @param                [in]can_frame_data_t *
 * @return               返回结果空
 */
void cluster_bcu_data_set(can_frame_data_t *can_data);

/**
 * @brief                本bcu数据 
 * @return               返回结果空
 * @retval               [out]const bcu_data_unify_t*
 */
const bcu_data_unify_t* get_bcu_info(void);

/**
 * @brief                簇间汇总数据 
 * @return               返回结果空
 * @retval               [out]const bcu_data_unify_t*
 */
const gold_bcu_integration_data* get_gobal_bcu_info(void);

/**
 * @brief                bcu簇间数据获取
 * @param                [in]bcu_num 0~9
 * @return               返回结果空
 * @retval               [out]const other_clu_data*
 */
const other_clu_data* get_cluster_bcu_data(uint8_t bcu_num);

/**
 * @brief                bcu 主控设置参数
 * @param                [in]can_frame_data_t *
 * @return               返回结果空
 */
void master_ctl_bcu_data_set(can_frame_data_t *can_data);

/**
 * @brief                设置上下电状态
 * @param                [in]power_state_u 
 * @retval               [out]无
 */
void cluster_bcu_power_state_set(power_state_e state);

/**
 * @brief                 设置故障复归标志
* @param                  [in]flag 1 有效， 0：无效
 * @retval                [out]无
 */
void cluster_bcu_fault_recover_set(bool flag);

/**
 * @brief                本bcu簇综合数据
 * @return               返回结果空
 * @retval               [out]无
 * @warning              放在100ms任务，
 */
void bcu_data_info_proc(void);

/**
 * @brief                bcu簇间综合数据初始化
 * @return               返回结果空
 * @retval               [out]无
 * @warning              放在100ms任务，
 */
void cluster_bcu_data_init(void);

/**
 * @brief                bcu数据更新
 * @return               返回结果空
 * @retval               [out]无
 * @warning              放在100ms任务，
 */
void bcu_data_proc(void);
#endif

