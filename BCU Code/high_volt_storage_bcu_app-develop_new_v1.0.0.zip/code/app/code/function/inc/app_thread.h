#include <stdint.h>

/**
* @brief        app线程创建
* @param        void
* @return       执行结果
*/
int32_t app_thread_creat(void);

/**
* @brief        app的main函数，这里只有是在app和core合并的时候才需要调用该函数
* @param        void
* @return       执行结果
*/
int32_t app_main(void);









