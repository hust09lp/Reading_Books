/**
 * @file     sample.h
 * @brief    电池数据采样文件
 * @company  sofarsolar
 * @author   刘吕从
 * @note
 * @version
 * @date     2023/4/27 初稿
 */

#ifndef __SAMPLE_H__
#define __SAMPLE_H__

#include <stdint.h>
#include <string.h>
#include <stdbool.h>

#define APP_BCU_SAMPLE_TEST  // shell debug

#define TEMP_TABLE_SIZE        (sizeof(ntc_res_table)/sizeof(ntc_res_table[0])) ///< NTC电阻表格
#define REF_VOLT                3000        ///< 参考电压 单位1mV
#define SAMP_VOLT               3000        ///< 采集电压 单位1mV
#define EXT_ADS_REF_VOLT        6144        ///< 参考电压 单位1mV, 根据ads1115寄存器配置,需要同步
#define BAT_TEMP_OFFSET         400         ///< 温度偏移量 单位0.1℃
#define BAT_CURR_OFFSET         300000      ///< 电流偏移量30000 单位1mA
#define ADC_FILTER_NUM          12          ///< ADC滤波数量
#define INNER_ADC_RESOLUTION    (4096)      ///< 片内adc的分辨率
#define EXT_ADC_RESOLUTION      (32768)     ///< 片外adc的分辨率
#define REF_VOLT_5V_UP_LIMIT    (5250)      ///< 霍尔器件5V基准电压上限 单位1mV
#define REF_VOLT_5V_DOWN_LIMIT  (4750)      ///< 霍尔器件5V基准电压下限 单位1mV
#define HALL_CAHNNEL1_SEN       (570)   ///< 霍尔器件1的灵敏度
#define HALL_CAHNNEL2_SEN       (6670)  ///< 霍尔器件1的灵敏度
#define HALL_REF_VOLT           (5000)      ///< 霍尔基准电压5V

/*当前霍尔采用kx+b这种线性公式去确定电流，不需要再关注霍尔里面具体的灵敏度，只需要对其校准*/
#define SAMPLE_CURR_LARGE_GAIN      256410                      ///< 霍尔大量程通道增益默认值
#define SAMPLE_CURR_SMALL_GAIN      22123                       ///< 霍尔小量程通道增益默认值
#define SAMPLE_CURR_MAGNIFICATION   1000                        ///< 霍尔电流计算增大倍数（用于提高校准精度）

// 电压倍率
// 片内adc采样参数


// 片外ads芯片电路电压采样
#define SAMPLE_VOLT_SOFEWARE_GAIN  (4500)                                  // 电压软件放大倍数：4294967296(2的32次方)/EXT_ADS_REF_VOLT(参考电压6144mV)/SAMPLE_VOLT_HARDWARE_GAIN/1.2 ≈4500(仅在计算电压使用，校准不使用)
#define SAMPLE_VOLT_HARDWARE_GAIN  (51500) / (169)                           // (5000/40.2 硬件电路放大倍数), 只能乘，不能加括号
#define SAMPLE_VOLT_GAIN    (EXT_ADS_REF_VOLT * SAMPLE_VOLT_HARDWARE_GAIN)  // 理论值5000/40.2*6144 ，6144(参考电压单位mV)，乘数不能超过2^32
#define BUS_VOLT_GAIN_L      (SAMPLE_VOLT_GAIN * 8 / 10)       ///< 母线总压增益SAMPLE_VOLT_GAIN*80%
#define BUS_VOLT_GAIN_H      (SAMPLE_VOLT_GAIN * 12 / 10)      ///< 母线总压增益SAMPLE_VOLT_GAIN*120%
#define LOAD_VOLT_GAIN_L     (SAMPLE_VOLT_GAIN * 8 / 10)       ///< 负载总压增益SAMPLE_VOLT_GAIN*80%
#define LOAD_VOLT_GAIN_H     (SAMPLE_VOLT_GAIN * 12 / 10)      ///< 负载总压增益SAMPLE_VOLT_GAIN*120%



#define SAMPLE_STATE_OK         0 ///< 采集状态获取成功
#define SAMPLE_STATE_EOI        1      ///< 采集状态获取失败
#define NTC_SHORT_CIRCUIT_ERR   (-1)    ///< NTC短路
#define NTC_OPEN_CIRCUIT_ERR    (-2)    ///< NTC开路
#define AFE_ERR                 (-3)    ///< AFE异常
#define COPPER_RES              50      ///< 微欧

/**
 * @enum   ntc_res_type_e
 * @brief  NTC电阻类型
 */
typedef enum
{
    LOAD_P_TEMP = 0, // P+温度
    LOAD_N_TEMP,     // P-温度
    BAT_P_TEMP,      // B+温度
    BAT_N_TEMP,      // B-温度
    TEMP_RSV_1,      // 温度预留1
    TEMP_RSV_2,      // 温度预留2
    PCB_TEMP,        // PCB温度
    OTHER_NTC_NUM,
} ntc_type_e;

/**
 * @enum   abnormal_type_e
 * @brief  采样状态异常类型
 * @warning ntc_res_type_e 必须要与 abnormal_type_e 排序一致否则采样异常, 新增或者改变需要在后面添加，如AFE_COMM_ERR
 */
typedef enum
{
    LOAD_P_NTC_ERR = 0, // P+温度
    LOAD_N_NTC_ERR,     // P-温度
    BAT_P_NTC_ERR,      // B+温度
    BAT_N_NTC_ERR,      // B-温度
    TEMP_RSV_NTC_ERR_1, // 温度预留1
    TEMP_RSV_NTC_ERR_2, // 温度预留2
    PCB_NTC_ERR,        // PCB温度
    OTHER_NTC_ERR_NUM,
} abnormal_type_e;

/**
 * @enum adjust_para_tab_e
 * @brief 校准参数表
 */
typedef enum
{
    CURR_LARGE_GAIN = 0,              ///< 大电流增益
    CURR_SMALL_GAIN,                  ///< 小电流增益
    ADJUST_CURR_GAIN_NUM,                 ///< 电流增益个数
    BUS_VOLT_GAIN = ADJUST_CURR_GAIN_NUM, ///< 母线总压增益
    LOAD_VOLT_GAIN,                       ///< 负载总压增益
    ADJUST_VOLT_GAIN_NUM,                 ///< 电压增益个数
    ADJUST_PARA_NUM = ADJUST_VOLT_GAIN_NUM,
    ADJUST_PARA_ACT_NUM = 16, ///< 预留参数表到16，防止后续增加该参数表导致，原有参数表数据清空
} adjust_para_tab_e;

/**
 * @struct adjust_para_tab_t
 * @brief 校准参数表
 */
typedef struct
{
    uint32_t adjust_para_gain[ADJUST_PARA_ACT_NUM];
} adjust_para_tab_t;

/**
 * @struct	bat_sample_data_t
 * @brief  电池采样数据管理
 */
//#pragma pack(1)
typedef struct
{
    int32_t sys_current;                          ///< 系统电流       1mA
    int16_t adc_sample_other_temp[OTHER_NTC_NUM]; ///< 除电芯温度的其他温度,单位0.1℃
    uint32_t hardware_version_volt;               ///< 硬件版本号识别  单位1mV
    uint32_t bus_volt;                            ///< 母线总压  单位1mV
    uint32_t load_volt;                           ///< 负载  单位1mV
    uint32_t insulation_res_volt;                 ///< 绝缘电阻电压  单位1mV
    uint32_t power_24v_volt;
    uint32_t power_12v_volt;
    int32_t hall_5v_volt;
    int32_t hall_large_volt;                 ///< 霍尔大电流通道电压    1mV
    int32_t hall_small_volt;                 ///< 霍尔小电流通道电压    1mV
    int32_t out3_volt;                      ///< 输出通道3电压    1mV
    int32_t hall_cur;                       ///< 霍尔电流  1mA
    int32_t hall_large_cur;                 ///< 霍尔大电流  1mA
    int32_t hall_small_cur;                 ///< 霍尔小电流  1mA
    int32_t hall_large_offset;              ///< 霍尔大电流零飘
    int32_t hall_small_offset;              ///< 霍尔小电流零飘    
    int32_t hall_5v_volt_avg;               ///< 霍尔5V平均值
    
} sample_data_t;
//#pragma pack()

/**
 * @brief                采样初始化
 * @param                [in]无
 * @return               返回结果
 * @warning              无
 */
void sample_init(void);

/**
 * @brief    校准参数计算
 * @param    [in] adjust_para_tab_e adjust_para_type 校准参数类型
 * @param        [in]uint32_t cali_value 校准值
 * -# 电流值      单位0.01A
 * -# 电压值      单位0.1V
 * @param        [in]adjust_para_tab_t *adjust_para_tab 校准结果值为校准参数结构体中的一个成员变量
 * @return    返回结果
 * @retval      [out] ret(0)  校准计算成功
 * @retval      [out] ret(-1) 空指针校准计算失败
 * @retval      [out] ret(-2)  校准增益超出范围或校准类型无效计算失败
 * @retval      [out] ret(-3)  adc采样无效计算失败
 * @retval      [out] ret(-4)  没有进入标定模式
 * @warning
 */
int32_t sample_adjust_cali_deal(adjust_para_tab_e adjust_para_type, uint32_t cali_value, adjust_para_tab_t *p_adjust_para_tab);

/**
 * @brief                采样校准参数设置
 * @param                [in]adjust_para_tab_t *adjust_para_tab 校准参数表结构体
 * @return               返回结果
 * @retval               [out]ret(0)  设置成功
 * @retval               [out]ret(-1) 设置失败
 * @warning              无
 */
int32_t sample_adjust_set(adjust_para_tab_t *adjust_para_tab);

/**
 * @brief                采样异常状态获取
 * @param                [in]abnormal_type_e
 * @return               返回结果
 * @retval               [out]ret(SAMPLE_STATE_OK)  获取采集状态成功
 * @retval               [out]ret(SAMPLE_STATE_EOI) 获取采集状态失败
 * @retval               [out]ret(NTC_SHORT_CIRCUIT) NTC短路
 * @retval               [out]ret(NTC_OPEN_CIRCUIT)  NTC开路
 * @retval               [out]ret(AFE_ERR)           AFE异常
 */
int32_t sample_abnormal_get(abnormal_type_e type);

/**
 * @brief                获取电池采样信息指针
 * @param                [in]bat_sample_data_t *p_data 电池采样数据结构体指针
 * @return               返回结果
 * @retval               ret(-1)获取失败
 * @retval               ret(0)获取成功
 * @warning              无
 */
const sample_data_t *p_sample_data_get(void);

/**
 * @brief                电池采样任务
 * @param                [in]void
 * @return               返回结果空
 * @retval               [out]无
 * @warning              放在10ms任务，必须要调用sample_data_init()后使用
 */
void sample_proc(void);

/**
 * @brief                获取硬件版本号
 * @param                [in]无
 * @return               [out] void
 * @warning              必须确保片内adc已经完成采样
 */
int16_t hardware_ver_get(void);
#endif


