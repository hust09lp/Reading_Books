#ifndef __PUBLIC_FLAG_H__
#define __PUBLIC_FLAG_H__

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

// bcu DO、DI状态
typedef struct
{
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t di1             :1;
            uint8_t di2             :1;
            uint8_t di3             :1;
            uint8_t di4             :1;
            uint8_t di5             :1;    // 
            uint8_t di6             :1;
            uint8_t di7             :1;
            uint8_t di8             :1;
        }bit;
    }di_state;
    
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t do1             :1;
            uint8_t do2             :1;
            uint8_t do3             :1;
            uint8_t do4             :1;
            uint8_t do5             :1;    // 
            uint8_t do6             :1;
            uint8_t do7             :1;
            uint8_t do8             :1;
        }bit;
    }do_state;
}di_do_info_t;
/**
* @brief        di相关标志状态获取
* @param        [in] flag_type 故障类型
* @retval        true  置位
* @retval        false 未置位
* @retval        -1 查询失败
*/
bool di_state_get(uint8_t flag_type);

/**
 * @brief                bcu di do反馈
 * @return               返回结构体
 * @warning              
 */
const di_do_info_t *bcu_dido_info_get(void);
    
// 公用标志管理任务10ms
void public_flag_task(void);



#endif
