/**
 * @file     sofar_cluster_can_manage.h
 * @brief    公司自定义CAN协议拓展帧SDK接口
 * @author   liulvcong
 * @note     无
 * @version  V1.0
 * @date     2023/2/3
 */
#ifndef __SOFAR_CLUSTER_CAN_MANAGE_H__
#define __SOFAR_CLUSTER_CAN_MANAGE_H__

#include "sofar_can_manage_public.h"

/**
* @brief		初始化簇间can管理
* @param		无
* @return		返回结果
* @retval		0：成功    < 0: 失败
* @warning		无 
*/
int32_t cluster_can_sofar_manage_init(void);

/**
* @brief		读取簇间can硬件缓冲区数据，1ms周期轮询
* @param		无
* @return		返回结果
* @retval		0：添加成功    < 0: 添加失败
* @warning		无 
*/
int32_t cluster_can_sofar_rcv_frame_proc(void);

/**
* @brief		注册簇间can接收回调函数
* @param		[in] urgent_flag:紧急处理标志  GENERAL_FRAME:接收到数据正常响应速度10ms ，URGENT_FRAME:接收数据快速响应1ms
* @param		[in] p_can_rec_reg ：
* @param		[in] id：can帧id 
* @param		[in] id：id_mask：过滤不需要接收的位(标准帧的掩码mask固定为0x00000000,拓展帧的掩码mask目标地址设置为FF代表能接收0xFF,0x1F,pack_addr三种类型地址)
* @param		[in] id：can_cb：回调解析函数 
* @param		[in] reg_cnt：注册的数量 
* @return		返回结果
* @retval		0：注册成功    < 0: 注册失败
* @warning		禁止重复注册同一个ID
* @warning		标准帧注册掩码必须为0x00000000
* @warning		掩码不可为0xFFFFFFFF
*/
int32_t cluster_can_sofar_register_receive_frame(can_sofar_rcv_reg_t *p_can_rec_reg, uint16_t reg_cnt);

#endif
