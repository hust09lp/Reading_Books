#ifndef __EXTERNAL_CAN_DATA_H__
#define __EXTERNAL_CAN_DATA_H__

#include <stdint.h>
#include <stddef.h>
#include "sofar_can_data.h"

#define CAN_VERSION		10001 	//和点表保持一致

#define BCU_EXT_CAN_MASTER_ADDR      0x01
#define PCS_CAN_ADDR   0x01
#define DCDC_CAN_ADDR   0x01
#define CLUSTER_MAX_NUM   4    // 最多4簇电池

#define SEND_TIME1 100

#define SHIFT_RIGHT(A)			(A>>8)

#define AsciiToInt	0x30

typedef struct 
{
	uint8_t flag;		// 更新标志
	uint16_t value;
}set_data_t;

typedef struct 
{
	uint8_t No;		// 点表位置
	int8_t (*setfun)(uint8_t No, uint16_t value);
	uint16_t (*getfun)(uint8_t No);

}para_or_threhold_func_t;


typedef struct 
{
	uint16_t No;		// 点表位置
	uint16_t (*getfun)(uint16_t No, uint8_t bmuid);

}yc_func_t;

// 0x30F: BMS上发的系统强制充电、停机的控制帧
typedef struct 
{
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t chg_forbid       : 1;		// 1: 禁止充电，0: 允许充电
            uint8_t dsg_forbid       : 1;		// 1: 禁止放电，0: 允许放电
            uint8_t fault            : 1;		// 1: 触发，0: 解除
            uint8_t parallel_mode    : 1;		// 1: 并簇模式
            uint8_t single_mode      : 1;		// 1: 单簇模式            
            uint8_t rsv              : 3;
        } bit;
    } sys_stus;
    
} bcu_req_ctl_state_t;


// 0x507 逆变器设置结构体
typedef struct
{
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t heat_type : 2;  // 0.:关闭电池加热 1:启动电池恒压加热 2:启动电池恒流加热
            uint8_t res    : 6;
        } bit;
    } heat_en;
} pcs_set_ctl_state_t;

typedef enum
{
    ATE_CALI_NON = 0,
    ATE_CALI_READ_OK_RLT = 0x01,     // 0x01:读取成功
    ATE_CALI_READ_ERR_RLT = 0x02,    // 0x02:读取失败
    ATE_CALI_RECOVER_OK_RLT = 0xAA,  // 0xAA:恢复成功
    ATE_CALI_RECOVER_ERR_RLT = 0x55, // 0x55:恢复异常
} cali_para_query_e;

typedef enum{
	NORMAL				=	0,
	OPEN				=	1,
	CLOSE				=	2,
	RELEASE_MODE		=	0X55,	
	OPEN_MODE			=	0XAA
}mode_e;

// 主动发送数据类型
typedef enum{
    EXT_AUTO_SEND_FORBID_TYPE = 0,
    EXT_AUTO_SEND_SLOW_TYPE,
    EXT_AUTO_SEND_NORMAL_TYPE,
    EXT_AUTO_SEND_DATA_TYPE_NUM,
} ext_auto_send_data_type;

// 外can接收帧id
// ext_rx_frame_data_id_e与g_ext_rx_can_msg_list，必须顺序和个数保持一致
typedef enum
{
    // 优先级为0x3
    // 配置表类 
    EX_RX_GOLD_SENSOR_DATA_REQ             = 0,  // 传感器报文
    EX_RX_GOLD_CLU_VOLT_OVER_ALM           ,  // 组端总电压上限报警值
    EX_RX_GOLD_CLU_VOLT_DOWN_ALM           ,  // 组端总电压下限报警值
    EX_RX_GOLD_CHG_CURR_ALM                ,  // 充电电流报警值
    EX_RX_GOLD_DSG_CURR_ALM                ,  // 放电电流报警值
    EX_RX_GOLD_CHG_CELL_TEMP_ALM           ,  // 充电单体电池温度报警值
    EX_RX_GOLD_CELL_TEMP_DIS_ALM           ,  // 单体电池温差报警值
    EX_RX_GOLD_SOC_ALM                     ,  //  SOC 报警值
    EX_RX_GOLD_INV_ALM                     ,  // 绝缘电阻报警值
    EX_RX_GOLD_CELL_VOLT_OVER_ALM          ,  // 电池单体电压上限报警值
    EX_RX_GOLD_CELL_VOLT_DOWN_ALM          ,  // 电池单体电压下限报警值
    EX_RX_GOLD_CELL_VOLT_DIS_ALM           ,  // 电池单体电压压差报警值
    EX_RX_GOLD_MODE_TEMP_OVER_ALM          ,  // 模块温度上限报警值
    EX_RX_GOLD_SYS_RTC_DATA                ,  // RTC 数据
    EX_RX_GOLD_CELL_MAIN_PARA              ,  // 电池主参数
    EX_RX_GOLD_SET_SOX_PARA                ,  // 设置 SOC 参数
    EX_RX_GOLD_DSG_CELL_TEMP_ALM               ,  // 放电单体电池温度报警值
    EX_RX_GOLD_CFG_TABLE_REQ               ,  // 后台软件下发查询配置表消息 命令码 0x02，BYTE2 为模块地址命令码, 0x06 BYTE2 充电类型命令码, 0x1B BYTE2 充放电标志
    EX_RX_GOLD_CMU_SET_ADDR                ,  // 主控地址设置命令码
    EX_RX_GOLD_PACK_VOLT_OVER_ALM          ,  // 电池模组电压上限报警值
    EX_RX_GOLD_PACK_VOLT_DOWN_ALM          ,  // 电池模组电压下限报警值
    // 电池信息数据类
    EX_RX_GOLD_CELL_DATA_REQ               ,  // 请求电池采集消息
    // 版本控制类
    EX_RX_GOLD_VER_DATA_REQ                ,  // PC 请求查询版本号消息
    // 测试类
    EX_RX_GOLD_TEST_FORCE_BAL              ,  //  发送强制均衡命令-主动均衡
    EX_RX_GOLD_TEST_FORCE_DO               ,  // PC 发送设置 EVBCM 模块 DO 输出命令
    // 簇间通讯功能码
    EX_RX_GOLD_CLU_SUMMARY                 ,  // 组端概要信息
    EX_RX_GOLD_CLU_CELL_SUMMARY            ,  // 单体概要信息
    EX_RX_GOLD_CLU_ALM_SUMMARY             ,  // 告警信息
    EX_RX_GOLD_MAINTENANCE                 ,  //  8133维护信息
    
    // 优先级为0x01
    EX_RX_GOLD_PRIO_01,
    // 主控控制类
    EX_RX_GOLD_CMU_POWER_CTL = EX_RX_GOLD_PRIO_01,  // 控制主控上下电指令
    EX_RX_GOLD_CMU_INS_CTL                       ,  // 控制主控绝缘检测功能指令
    // 簇间通讯功能码
    EX_RX_GOLD_MAS_CLU_CTL                 ,  // 主 8133 控制命令
    EX_RX_GOLD_OUT_CLU_CTL                 ,  // 退簇信息
    EX_RX_GOLD_PC_CTL_CLU                  ,  // 显控控制指令
    EXT_CAN_RX_FRAME_NUM,
} ext_rx_frame_data_id_e;


// 外can接收帧id
// 功能码0x1E 回应后台软件设置配置表消息--比较特殊独立出来
typedef enum
{
    EX_TX_GOLD_ALARM_DATA_ACK   = 0,  // EVBCM 应答 PC 请求报警信息应答消息
    EX_TX_GOLD_DIDO_DATA_ACK       ,  // EVBCM 应答 PC 请求 DI/DO 信息应答消息
    EX_TX_GOLD_FAULT_DATA_ACK      ,  // EVBCM 应答 PC 请求报警信息应答消息(新增告警信息)
    // 主控控制类
    EX_TX_GOLD_CMU_INS_CTL         ,  // 控制主控绝缘检测功能指令
    // 簇间通讯功能码
    EX_TX_GOLD_CLU_SUMMARY         ,  // 组端概要信息
    EX_TX_GOLD_CLU_CELL_SUMMARY    ,  // 单体概要信息
    EX_TX_GOLD_CLU_ALM_SUMMARY     ,  // 告警信息
    EX_TX_GOLD_MAS_CLU_CTL         ,  // 主 8133 控制命令
    EX_TX_GOLD_ALM_REASON          ,  // 禁充禁放告警原因信息
    EX_TX_GOLD_MAINTENANCE         ,  //  8133维护信息
    EX_CAN_TX_FRAME_NUM,
} ext_tx_frame_data_id_e;

typedef enum
{
    BCU_THRE_DWORD_START = 0, 
    BCU_THRE_TOTAL_OVER_VOLT_PROT        = BCU_THRE_DWORD_START, // 总体过充保护阈值
    BCU_THRE_TOTAL_OVER_VOLT_PROT_DIS    = 1, // 总体过充解除阈值    
    BCU_THRE_TOTAL_OVER_VOLT_ALRM        = 2, // 总体过充告警阈值    
    BCU_THRE_TOTAL_OVER_VOLT_ALRM_DIS    = 3, // 总体过充解除阈值    
    BCU_THRE_TOTAL_UNDER_VOLT_PROT       = 4, // 总体过放保护阈值    
    BCU_THRE_TOTAL_UNDER_VOLT_PROT_DIS   = 5, // 总体过放解除阈值    
    BCU_THRE_TOTAL_UNDER_VOLT_ALRM       = 6, // 总体过放告警阈值    
    BCU_THRE_TOTAL_UNDER_VOLT_ALRM_DIS   = 7, // 总体过放解除阈值    
    BCU_THRE_CHG_OVER_CUR_PROT1          = 8, // 充电过流1保护阈值    
    BCU_THRE_CHG_OVER_CUR_PROT1_DIS      = 9, // 充电过流1保护消失阈值    
    BCU_THRE_CHG_OVER_CUR_ALRM           = 10, // 充电过流告警阈值    
    BCU_THRE_CHG_OVER_CUR_ALRM_DIS       = 11, // 充电过流告警消失阈值    
    BCU_THRE_DCHG_OVER_CUR_PROT2         = 12, // 放电过流2保护阈值    
    BCU_THRE_DCHG_OVER_CUR_PROT2_DIS     = 13, // 放电过流2保护消失阈值    
    BCU_THRE_DCHG_OVER_CUR_PROT          = 14, // 放电过流保护1阈值    
    BCU_THRE_DCHG_OVER_CUR_PROT_DIS      = 15, // 放电过流保护1消失阈值    
    BCU_THRE_DCHG_OVER_CUR_ALRM          = 16, // 放电过流告警阈值    
    BCU_THRE_DCHG_OVER_CUR_ALRM_DIS      = 17, // 放电过流告警消失阈值    
    BCU_THRE_SOC_UNDER_ALRM              = 18, // 低SOC告警    
    BCU_THRE_SOC_UNDER_ALRM_DIS          = 19, // 低SOC告警消失阈值
    BCU_THRE_DWORD_END,                        // 最大值为40(20对)
    BCU_THRE_WORD_START = BCU_THRE_DWORD_END,
    BCU_THRE_FAN_OPEN_TEMP = BCU_THRE_WORD_START,  // 风扇开启温度
    BCU_THRE_FAN_CLOSE_TEMP              ,     // 风扇关闭温度    
    BCU_THRE_FULL_CHG_VOL                ,     // 满充电压    
    BCU_THRE_CLUSTER_PACK_NUM            ,     // 单簇PACK个数
    BCU_THRE_EMPTY_DSG_VOL               ,     // 放亏电压
    BCU_THRE_WORD_END,
} bcu_thre_id_e;

typedef enum
{
    CYCLE_MSG_CLU_DATA1_ID = 0,
    CYCLE_MSG_CLU_DATA2_ID,
    CYCLE_MSG_INS_DATA_ID,
    CYCLE_MSG_YX_DATA_ID,   //给CMU发送充放电允许状态特殊处理，主动发送
    CYCLE_MSG_CNT,
} frame_cycle_id_e;

typedef enum
{
    NO_MODULE_SEND_REQ = 0,
    CLU_INFO_DATA_SEND_REQ,
    CLU_INFO_DATA2_SEND_REQ,
    INS_ENBAL_DATA_SEND_REQ,
    CLU_YX_DATA_SEND_REQ,
    EX_REQ_SEND_REQ_NUM,
} ex_request_send_group_e;




/**
* @brief		内网初始化
* @param		无
* @return		无
* @retval		无
* @warning		无 
*/
void can_ext_data_init(void);

// /**
// * @brief		自动发送内网数据
// * @param		[in]base_time 任务周期时间 ms 
// * @return		返回结果
// * @retval		无
// * @warning		无 
// */
void can_ext_data_send_proc(void);

/**
* @brief		请求发送can数据帧
* @param		无
* @return		返回结果
* @retval		无
* @warning		无 
*/
void ext_can_send_msg_ready(ext_tx_frame_data_id_e send_id);

// /**
// * @brief		自动发送内网数据功能设置接口
// * @param		[in]ext_auto_send_data_type
// * @return		返回结果
// * @retval		0：操作成功    < 0: 操作失败
// * @warning		无 
// */
int32_t auto_send_can_ext_func_set(uint8_t type);

uint8_t cmu_power_ctrl_type_get(void);

uint8_t sys_stus_get(void);

#endif
