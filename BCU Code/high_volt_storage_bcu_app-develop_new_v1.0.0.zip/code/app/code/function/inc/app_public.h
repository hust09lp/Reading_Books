#ifndef __APP_PUBLIC_H__
#define __APP_PUBLIC_H__
#include <stdint.h>
#include <stddef.h>
#include "sdk_dido.h"
#include "msh.h"
/**
* 软件版本号
*/
#define SOFTWARE_VERSION		"T010003"
#define HARDWARE_VERSION		"V000001"

/*测试标志*/
#define SIMULATION_FAULT_TEST				//故障模拟测试标志 正式代码发布时，要屏蔽此测试标志

/*加热控制*/
#define HEATING_CONTROL

/*3ph升级使能标志*/
#define UPD_3PH_FLAG				//3PH升级使能标志





/*电池包数据*/
#define PACK_MIN_NUM 4        // 一簇最少接4个PACK
#define PACK_MAX_NUM 8        // 一簇最多接8个PACK

//2.0项目的类型，默认2.0项目
#define PROJECT_VER_2_0_H '2'       ///< 项目号 2.0
#define PROJECT_VER_2_0_L '0'       ///< 项目号 2.0
#define PACK_CELL_TEMP_NUM_36 36 // 32个电芯温度+4个铜排温度
#define PACK_CELL_NUM_64 64      // 一个电池包内1电芯个数
#define PACK_POWER_CAP_120 120    // Ah/bit
#define PROJECT_VER_2_1_H '2'       ///< 项目号 2.1
#define PROJECT_VER_2_1_L '1'       ///< 项目号 2.1


//1.0项目的类型
#define PROJECT_VER_1_0_H '1'       ///< 项目号 1.0
#define PROJECT_VER_1_0_L '0'       ///< 项目号 1.0
#define PACK_CELL_TEMP_NUM_28 28 // 24个电芯温度+4个铜排温度
#define PACK_CELL_NUM_48 48      // 一个电池包内1电芯个数
#define PACK_POWER_CAP_280 280    // Ah/bit

/*电芯数据*/
#define PACK_CELL_TYPE   1    // 电池类型 1 表示 L--磷酸铁锂电池,2 表示 N—钛酸锂电池,3 表示 T—锰酸锂电池,4 表示 S--三元锂电池,
#define PACK_CELL_MODEL   1    // TODO
#define PACK_CELL_MANUFACTOR   1  // TODO

// can过滤宏定义
#define CAN_FILTER_ITEM_INIT(id,ide,rtr,mode,mask) \
     {(id), (ide), (rtr), (mode), (mask), -1, }	///< 不指定过滤号的硬件过滤表

// 字节偏移宏
#define WORD_SIZE              (2)
#define DWORD_SIZE             (4)
#define LOW_BYTE(word) ((uint8_t)((uint16_t)(word) & 0xFF))
#define HIGH_BYTE(word) ((uint8_t)(((uint16_t)(word) >> 8) & 0xFF))
#define MAKE_WORD(low, high) ((uint16_t)((uint16_t)(low) | (uint16_t)((high) << 8)))
#define MAKE_DWORD(low, high) ((uint32_t)((uint32_t)(low) | (uint32_t)((high) << 16)))
#define BYTE_MAKE_DWORD(lowest, low, high, highest)  ((uint32_t)((uint32_t)(low) | (uint32_t)((lowest) << 8) | (uint32_t)((high) << 16) | (uint32_t)((highest) << 24)))
     
// crc校验
#define MASTER_CTL_SET_CRC8_MASK    0x00    // 主机/上位机控制CRC
#define ATE_CONTROL_CRC8_MASK       0x00    // ATE控制CRC
#define PCS_CONTROL_CRC8_MASK       0x00

#ifndef TICK_1MS
#define TICK_1MS	os_tick_from_millisecond(1)
#endif

#ifndef TICK_5MS
#define TICK_5MS	os_tick_from_millisecond(5)
#endif

#ifndef TICK_10MS
#define TICK_10MS	os_tick_from_millisecond(10)
#endif

#ifndef TICK_100MS
#define TICK_100MS	os_tick_from_millisecond(100)
#endif

#ifndef TICK_300MS
#define TICK_300MS	os_tick_from_millisecond(300)
#endif

#ifndef TICK_500MS
#define TICK_500MS	os_tick_from_millisecond(500)
#endif

#ifndef TICK_1S
#define TICK_1S		os_tick_from_millisecond(1000)
#endif

#ifndef TICK_2S
#define TICK_2S		os_tick_from_millisecond(2000)
#endif

#ifndef TICK_10S
#define TICK_10S	os_tick_from_millisecond(10000)
#endif

// 无效值定义
#define U32_INVALID_VALUE    (0xFFFFFFFF)
#define I32_INVALID_VALUE    (0x80000000)
#define U16_INVALID_VALUE    (0xFFFF)
#define I16_INVALID_VALUE    (0x8000)
#define U8_INVALID_VALUE     (0xFF)
#define I8_INVALID_VALUE     (0x80)

#define EVT_NULL              0xFF
#define STA_NULL              0xFF

typedef enum {
    WAKEUP_SOURCE_KEY1   = 1, ///< 开机
    WAKEUP_SOURCE_CHARGE = 2, ///< 充电
    WAKEUP_SOURCE_PCS    = 3, ///< PCS通讯(外CAN)
    WAKEUP_SOURCE_ID_IN  = 4, ///< 拼机
    WAKEUP_SOURCE_DRY    = 5  ///< 干接点
}wakeup_source_e;


typedef enum
{
    FUNC_INIT = 0,
    FUNC_ENABLE,
    FUNC_DISABLE,
} func_enable_state_e;

uint8_t app_run_success_flag_get(void);

#endif

