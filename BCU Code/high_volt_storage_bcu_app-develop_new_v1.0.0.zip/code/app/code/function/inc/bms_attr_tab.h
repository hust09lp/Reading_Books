#ifndef __BMS_ATTR_TAB_H__
#define __BMS_ATTR_TAB_H__

#include <stdint.h>
#include <stddef.h>
#include "sample.h"

/**
 * @brief 校准参数表
 */
//typedef struct
//{
//    uint16_t total_vol;     ///< 总电压
//    uint16_t load_vol;      ///< 负载电压
//    uint16_t chg_high_cur;  ///< 充电电流
//    uint16_t chg_low_cur;   ///< 充电低电流
//    uint16_t dchg_high_cur; ///< 放电电流
//    uint16_t dchg_low_cur;  ///< 放电低电流
//} adjust_para_tab_t;

// /**
//  * @brief 安全参数类型
//  */
// typedef struct
// {
//     int32_t appear_value;        	///< 产生阈值
//     int32_t cancel_value; 			///< 取消阈值
// } safety_param_t;

// /**
//  * @brief 安全参数表
//  */
// typedef struct
// {
//     safety_param_t cell_over_vol_alarm;   	///< 单体过压告警
//     safety_param_t cell_over_vol_protect;   ///< 单体过压保护
// 	safety_param_t cell_over_vol_seriou;
//     safety_param_t cell_under_vol_alarm;  	///< 单体欠压告警
//     safety_param_t cell_under_vol_protect;  ///< 单体欠压保护
// 	safety_param_t cell_under_vol_seriou;
//     safety_param_t system_over_vol_alarm;  	///< 总压过压告警
//     safety_param_t system_over_vol_protect;  ///< 总压过压保护
//     safety_param_t system_under_vol_alarm; 	///< 总压欠压告警
//     safety_param_t system_under_vol_protect; ///< 总压欠压保护
//     safety_param_t chg_over_temp_alarm;   	///< 充电温度过高告警
// 	safety_param_t chg_over_temp_protect;	///< 充电温度过高保护
//     safety_param_t chg_under_temp_alarm;  	///< 充电温度过低告警
//     safety_param_t chg_under_temp_protect;  ///< 充电温度过低保护
//     safety_param_t dchg_over_temp_alarm;  	///< 放电温度过高告警
//     safety_param_t dchg_over_temp_protect;  ///< 放电温度过高保护
//     safety_param_t dchg_under_temp_alarm; 	///< 放电温度过低告警
//     safety_param_t dchg_under_temp_protect; ///< 放电温度过低保护
//     safety_param_t chg_over_cur_alarm;    	///< 充电过流告警 单位：0.01A 无偏移量
//     safety_param_t chg_over_cur_protect;    ///< 充电过流保护 单位：0.01A 无偏移量
//     safety_param_t dchg_over_cur_alarm;   	///< 放电过流告警 单位：0.01A 无偏移量
//     safety_param_t dchg_over_cur_protect1;  ///< 放电过流保护1 单位：0.01A 无偏移量
//     safety_param_t dchg_over_cur_protect2;  ///< 放电过流保护2 单位：0.01A 无偏移量
//     safety_param_t ent_over_temp_alarm;   	///< 环境温度过高告警
//     safety_param_t ent_over_temp_protect;   ///< 环境温度过高保护
//     safety_param_t ent_under_temp_alarm;  	///< 环境温度过低告警
//     safety_param_t ent_under_temp_protect;  ///< 环境温度过低保护
//     safety_param_t mos_over_temp_alarm;   	///< mos温度过高告警
//     safety_param_t mos_over_temp_protect;   ///< mos温度过高保护
//     safety_param_t soc_under_alarm;  		///< soc过低告警
//     safety_param_t soc_under_protect;  		///< soc过低保护
//     safety_param_t bat_full_volt;  			///< 满充电压
//     safety_param_t bat_empty_volt;  		///< 放空电压
// } safety_para_tab_t;

// /**
//  * @brief BMS属性数据表
//  */
// typedef struct
// {
//     uint32_t version;         ///< bms属性数据表版本
//     //adjust_para_tab_t adjust; ///< 校准参数表
//     safety_para_tab_t safety; ///< 安全参数表
//     uint16_t rate_cap;        ///< 额定容量
//     uint16_t cell_num;        ///< 电芯数量
//     uint16_t cycle_count;     ///< 循环次数
//     uint16_t bal_vol;         ///< 均衡开启电压
//     uint16_t bal_vol_diff;    ///< 均衡开启压差
//     uint16_t full_chg_vol;    ///< 满充电压
//     int32_t heap_open_temp;  ///< 加热膜开启温度
//     int32_t heap_close_temp; ///< 加热膜关闭温度
//     uint16_t chg_stop_vol;    ///< 充电截止电压
//     uint16_t chg_stop_cur;    ///< 充电截止电流
// 	uint16_t mono_vol_num;        ///< 单体电压个数
// 	uint16_t mono_tem_num;        ///< 单体温度个数
// 	uint8_t pack_sn[21];     	  ///< Pack SN：条形码
// 	uint8_t board_sn[21];        ///< Board SN：单板条形码
// 	uint8_t hardware[3];		  ///< 硬件版本号
// } bms_attr_t;
// #if 1 //Mtest
// const bms_attr_t bms_attr_init = {
//     .version = 0xA0000023,

// //    .adjust = {
// //        .bat_total_volt_gain = 63000, ///< 电池总电压增益
// //        .load_volt_gain = 63000,      ///< (P+)负载电压增益
// //        .max_chg_curr_gain = 750,     ///< 大环充电电流增益
// //        .max_dsg_curr_gain = 900,     ///< 大环放电电流增益
// //        .min_dsg_curr_gain = 147,     ///< 小环放电电流增益
// //        .min_chg_curr_gain = 147,     ///< 小环充电电流增益
// //    },
	
//     .safety = {  // 保护产生阈值 保护解除阈值 告警产生阈值 告警解除阈值
//         .cell_over_vol_alarm   	= { 3600, 3450, }, // 单体过压报警 单位0.001V
//         .cell_over_vol_protect  = { 3800, 3450, }, // 单体过压保护 单位0.001V
// 		.cell_over_vol_seriou  	= { 4000, 0, }, // 单体过压保护 单位0.001V
//         .cell_under_vol_alarm  	= { 2700, 2800, }, // 单体欠压报警 单位0.001V
//         .cell_under_vol_protect = { 2500, 2800, }, // 单体欠压保护 单位0.001V
// 		.cell_under_vol_seriou 	= { 2500, 2800, }, // 单体欠压保护 单位0.001V
//         .system_over_vol_alarm  	= { 55300, 54080,}, // 总压过压报警 单位0.001V
//         .system_over_vol_protect = { 56000, 54080,}, // 总压过压保护 单位0.001V
//         .system_under_vol_alarm 	= { 47200, 48000,}, // 总压欠压报警 单位0.001V
//         .system_under_vol_protect= { 45600, 48000, }, // 总压欠压保护 单位0.001V
//         .chg_over_temp_alarm   	= { 500 , 500 , }, // 充电温度过高报警 单位0.1℃
//         .chg_over_temp_protect  = { 560 , 500 , }, // 充电温度过高保护 单位0.1℃
//         .chg_under_temp_alarm  	= { 50 , 50 , }, // 充电温度过低报警 单位0.1℃
//         .chg_under_temp_protect = { 20 , 50 , }, // 充电温度过低保护 单位0.1℃
//         .dchg_over_temp_alarm  	= { 550 , 550 , }, // 放电温度过高报警 单位0.1℃
//         .dchg_over_temp_protect = { 600, 550 , }, // 放电温度过高保护 单位0.1℃
//         .dchg_under_temp_alarm 	= { -150 , -130, }, // 放电温度过低报警 单位0.1℃
//         .dchg_under_temp_protect= { -200 , -180 , }, // 放电温度过低保护 单位0.1℃
//         .chg_over_cur_alarm    	= { 105000, 10000 , }, // 充电过流 单位：0.001A	无偏移量报警
//         .chg_over_cur_protect   = { 110000, 10000 , }, // 充电过流 单位：0.001A	无偏移量
//         .dchg_over_cur_alarm   	= { 105000, 10000 , }, // 放电过流 单位：0.001A 无偏移量报警
//         .dchg_over_cur_protect1 = { 110000, 10000 , }, // 放电过流 单位：0.001A 无偏移量
//         .dchg_over_cur_protect2 = { 150000, 10000 , }, // 放电过流 单位：0.001A 无偏移量
//         .ent_over_temp_alarm   	= { 650, 650, }, // 环境温度过高报警 单位0.1℃
//         .ent_over_temp_protect 	= { 700, 650, }, // 环境温度过高保护 单位0.1℃
//         .ent_under_temp_alarm  	= { -200 , -200 , }, // 环境温度过低报警 单位0.1℃
//         .ent_under_temp_protect = { -250 , -200 , }, // 环境温度过低保护 单位0.1℃
//         .mos_over_temp_alarm   	= { 900, 850, }, // Mos温度过高报警  单位0.1℃
//         .mos_over_temp_protect  = { 1150, 850, }, // Mos温度过高保护  单位0.1℃
//         .soc_under_alarm  		= { 120 , 140 , }, // SOC过低报警  分辨率0.1%
//         .soc_under_protect 		= { 50  , 100 , }, // SOC过低保护  分辨率0.1%
//         .bat_full_volt  		= { 3600 , 3450 , }, // 电池满充 单位0.001V
//         .bat_empty_volt 		= { 2800 , 2900 , }, // 电池放空 单位0.001V
//     },

//     .rate_cap = 1000,      // 额定容量 单位0.1Ah
//     .cell_num = 16,        // 电芯数量
//     .cycle_count = 0,      // 循环次数
//     .bal_vol = 3400,       // 均衡电压	1mV
//     .bal_vol_diff = 30,    // 压差		1mV
//     .full_chg_vol = 3600,  // 满充电压	1mV
//     .heap_open_temp = -20, // 加热开启温度	℃
//     .heap_close_temp = 0,  // 加热关闭温度	℃
//     .chg_stop_vol = 577,   // 充电停止电压	0.1V
//     .chg_stop_cur = 500,   // 充电截止电流	单位10mA
//     .mono_vol_num = 16,    //< 单体电压个数
//     .mono_tem_num = 5,     //< 单体温度个数

//     .pack_sn = {                                   // PACK条形码
//                 '0', '1', '2', '3', '4', '5', '6', //
//                 '0', '1', '2', '3', '4', '5', '6', //
//                 '0', '1', '2', '3', '4', '5', '6'},

//     .board_sn = {                                   // BOARD条形码
//                  '0', '1', '2', '3', '4', '5', '6', //
//                  '0', '1', '2', '3', '4', '5', '6', //
//                  '0', '1', '2', '3', '4', '5', '6'},

//     .hardware = {1, 2, 3}, // 硬件版本号
// };
// const bms_attr_t *get_bms_attr(void);
// const bms_attr_t *get_bms_attr(void)
// {
//     return &bms_attr_init;
// }

#endif
#endif
