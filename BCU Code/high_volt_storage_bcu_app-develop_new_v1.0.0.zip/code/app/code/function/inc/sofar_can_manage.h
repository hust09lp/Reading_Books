/**
 * @file     sofar_can_manage.h
 * @brief    公司自定义CAN协议拓展帧SDK接口
 * @author   liulvcong
 * @note     无
 * @version  V1.0
 * @date     2023/2/3
 */
#ifndef __SOFAR_CAN_MANAGE_H__
#define __SOFAR_CAN_MANAGE_H__

#include "sofar_can_manage_public.h"

#ifdef SDK_EXTERNAL_CAN_PORT
#include "sofar_ext_can_manage.h"
#endif
#ifdef SDK_INTERNAL_CAN_PORT
#include "sofar_inner_can_manage.h"
#endif
#ifdef SDK_CLUSTER_CAN_PORT
#include "sofar_cluster_can_manage.h"
#endif

#endif
