#ifndef __RELAY_MANAGE_H__
#define __RELAY_MANAGE_H__
#include <stdint.h>
#include <stddef.h>

#define RELAY_MANAGE_DEBUG_SHELL_FLAG  1

#define REQ_POS_RELAY_ON()			(g_relay_ctrl_cmd.bit_t.pos_relay = 1)
#define REQ_POS_RELAY_OFF()			(g_relay_ctrl_cmd.bit_t.pos_relay = 0)

#define REQ_NEG_RELAY_ON()			(g_relay_ctrl_cmd.bit_t.neg_relay = 1)
#define REQ_NEG_RELAY_OFF()			(g_relay_ctrl_cmd.bit_t.neg_relay = 0)

#define REQ_PRE_RELAY_ON()			(g_relay_ctrl_cmd.bit_t.pre_relay = 1)
#define REQ_PRE_RELAY_OFF()			(g_relay_ctrl_cmd.bit_t.pre_relay = 0)

// 正继电器有+/-两路输出控制IO，继电器闭合：先+IO后-IO，断开：直接-IO和+IO----当前实际需要控一个脚就好，为了保持架构不变，所以代码不删除
#define POS_RELAY_NEG_ON() 	//sdk_dido_write(DO_7_POS_RELAY_NEG_TML, 1)
#define POS_RELAY_NEG_OFF() //sdk_dido_write(DO_7_POS_RELAY_NEG_TML, 0)
#define POS_RELAY_POS_ON() 	sdk_dido_write(DO_6_POS_RELAY, 1)
#define POS_RELAY_POS_OFF() sdk_dido_write(DO_6_POS_RELAY, 0)
// 负继电器有+/-两路输出控制IO，继电器闭合：先+IO后-IO，断开：直接-IO和+IO----当前实际需要控一个脚就好，为了保持架构不变，所以代码不删除
#define NEG_RELAY_NEG_ON() 	//sdk_dido_write(DO_5_NEG_RELAY_NEG_TML, 1)
#define NEG_RELAY_NEG_OFF() //sdk_dido_write(DO_5_NEG_RELAY_NEG_TML, 0)
#define NEG_RELAY_POS_ON() 	sdk_dido_write(DO_8_NEG_RELAY, 1)
#define NEG_RELAY_POS_OFF() sdk_dido_write(DO_8_NEG_RELAY, 0)
// 预充继电器只有一路输出IO控制
#define PRE_CHG_RELAY_ON() 	 sdk_dido_write(DO_7_PRE_RELAY, 1)
#define PRE_CHG_RELAY_OFF()  sdk_dido_write(DO_7_PRE_RELAY, 0)
// 正负继电器状态反馈信号读取，预充继电器无反馈信号
#define POS_RELAY_STATUS_READ() sdk_dido_read(DI_4_POS_RELAY)
#define NEG_RELAY_STATUS_READ() sdk_dido_read(DI_6_NEG_RELAY)

#define PRE_VOLT_DIFF_THRESHOLD	5000  // 单电池包预充阈值电压5V
#define PRE_PACK_VOLT_THRESHOLD 40000 // 单电池包放电最小电压40V
#define PRE_CHG_MAX_NUM 3 // 最多连续预充3次
#define RELAY_OPERATE_ERR_MAX_CONT_NUM 3 // 继电器最多连续操作失败3次
#define POS_RELAY_OPEN_MAX_CUR 10000 // 正继电器断开最大电流10A
#define NEG_RELAY_OPEN_MAX_CUR 10000 // 负继电器断开最大电流10A
#define PRE_RELAY_OPEN_MAX_CUR 10000 // 预充继电器断开最大电流10A
#define RELAY_WAIT_CUR_TICK_500MS  500  // 继电器小电流等待持续时间
#define RELAY_CLOSE_MAX_TICK_30MS  30  // 继电器闭合最长时间30ms
#define RELAY_OPEN_MAX_TICK_30MS  30  // 继电器打开最长时间30ms
#define RELAY_CLOSE_LOW_POWER_MAX_TICK_60S  60000  // 继电器闭合后多长时间进入低功耗模式
#define RELAY_OPEN_LOAD_MAX_TICK_6000MS  6000  // 继电器带载切断最大等待时间6S
#define RELAY_OPEN_LOAD_MAX_TICK_15000MS  15000  // 继电器带载切断最大等待时间15S
#define RELAY_OPEN_LOAD_MAX_TICK_0MS  0  // 继电器带载切断最大等待时间0S

typedef union
{
    uint8_t val;
     struct {
        uint8_t pos_relay:1;  // 1:闭合，0：断开
        uint8_t neg_relay:1;
        uint8_t pre_relay:1;
        uint8_t res:5;
    } bit_t;
}relay_ctrl_cmd_u;

typedef enum
{
    RELAY_OPEN = 0,
    RELAY_CLOSE = 1,
    RELAY_DOING = 2,
}relay_state_e;

typedef enum
{
	PRE_INIT	= 0,	///< 预充初始化
	PRE_ONGOING,		///< 预充进行中
	PRE_SUCCESS,		///< 预充成功
	PRE_FAIL,			///< 预充失败
}pre_charge_state_e;

typedef enum
{
    POS_RELAY = 0,        ///< 正继电器
    NEG_RELAY = 1,		///< 负继电器
    PRE_RELAY = 2,		///< 预充继电器
    POWER_RELAY_NUM = 3				
}relay_type_e;

/*******************************预充状态机相关***********************************/
typedef enum
{
    EVT_PRE_CUT_OFF    = 0,
    EVT_PRE_STAT_CPL_SUC    = 1,
    EVT_PRE_AGAIN   = 2,
    EVT_PRE_START_ERR = 3,
    PRE_CHG_EVT_NUM = 4,
}pre_chg_fsm_event_e;

typedef enum
{
    PRE_CHG_INIT = 0,		// 预充初始化
    PRE_CHG_START = 1,	    // 预充开始，闭合预充继电器
    PRE_CHG_STAGE1 = 2,		// 预充进行阶段1，闭合正继电器
    PRE_CHG_STAGE2 =3,		// 预充进行阶段2，断开预充继电器
    PRE_CHG_AGAIN = 4,		// 预充重新进行，连续进行3次则预充失败
    PRE_CHG_FINISH = 5,		// 预充完成
    PRE_CHG_ERROR = 6,		// 预充失败
    PRE_CHG_STA_NUM = 7
}pre_chg_fsm_state_e;

/*******************************其他不需要预充状态机相关***********************************/
typedef enum
{
    EVT_CHG_CUT_OFF    = 0,
    EVT_CHG_STAT_CPL_SUC    = 1,
    EVT_CHG_START_ERR = 2,
    CHG_EVT_NUM = 3,
}chg_fsm_event_e;

typedef enum
{
    CHG_INIT = 0,		// 非预充初始化
    CHG_START = 1,	    // 非预充开始，闭合主负
    CHG_FINISH = 2,		// 非预充完成
    CHG_ERROR = 3,		// 非预充失败
    CHG_STA_NUM = 4
}chg_fsm_state_e;

/*******************************继电器操作态机相关***********************************/
typedef enum{
    EVT_RELAY_CLOSE    = 0,
    EVT_RELAY_OPEN    = 1,
    EVT_RELAY_CPL_SUC    = 2,
    EVT_RELAY_REOPERATE = 3,
    EVT_RELAY_ERR = 4,
    RELAY_CTRL_EVT_NUM = 5,
}relay_ctrl_fsm_event_e;

typedef enum{
    RELAY_IDLE = 0,		// 继电器等待操作
    RELAY_WAIT_OPEN = 1,		// 等待断开继电器
    RELAY_START_OPEN = 2,		// 启动断开继电器
    RELAY_OPEN_RES =3,		// 继电器断开结果判断
    RELAY_START_CLOSE = 4,			// 继电器启动闭合
    RELAY_CLOSE_RES = 5,			// 闭合结果判断
    RELAY_CLOSE_LOW_POW = 6,        // 闭合后延时进入低功耗
    RELAY_ERROR = 7,			// 继电器异常
    RELAY_CTRL_STA_NUM = 8
}relay_ctrl_fsm_state_e;

typedef struct 
{
    uint16_t open_max_cur;
    uint16_t open_max_time;
    uint16_t close_max_time;
    uint16_t low_pow_max_time; 
    uint16_t open_low_current_continuous_time;
    uint16_t open_load_max_time;   
}relay_para_t;

/**
* @brief		获取预充状态
* @param		无
* @return		执行结果
* @retval		预充初始化	PRE_INIT
* @retval		预充进行中	PRE_ONGOING
* @retval		预充成功		PRE_SUCCESS
* @retval		预充失败 	PRE_FAIL
* @warning		无 
*/
pre_charge_state_e get_pre_charge_state(void);

/**
* @brief		获取预充失败标志
* @param		无
* @return		执行结果
* @retval		预充正常   	= 0
* @retval		预充失败	< 0
* @warning		无 
*/
int32_t get_pre_charge_fail_flag(void);

/**
* @brief		获取继电器控制状态
* @param		[in] relay_type 充电mos，放电mos，预充mos状态
* @return		执行结果
* @retval		0：断开， 1: 闭合
* @warning		无
*/
int32_t get_relay_contrl_state(uint8_t relay_type);

/**
* @brief		获取继电器实际状态
* @param		[in] relay_type 充电mos，放电mos，预充mos状态
* @return		执行结果
* @retval		0：断开， 1: 闭合， 2:操作中
* @warning		无 
*/
int32_t get_relay_real_state(uint8_t relay_type);

/**
* @brief		获取继电器上次控制状态（这里和实际di状态置位在同一个地方，时序比较合适加该函数给继电器粘连判断使用）
* @param		[in] relay_type 充电mos，放电mos，预充mos状态
* @return		执行结果
* @retval		0：断开， 1: 闭合
* @warning		无
*/
int32_t get_relay_contrl_last_state(uint8_t relay_type);

/**
* @brief		获取继电器异常标志
* @param		[in] relay_type 充电mos，放电mos，预充mos状态
* @return		执行结果
* @retval		0：断开， 1: 闭合， 2:操作中
* @warning		无 
*/
int32_t get_relay_abnormal_flag(uint8_t relay_type);

/**
* @brief		获取继电器强切标志
* @param		无
* @return		执行结果
* @retval		0：未强切， 1: 强切
* @warning		无 
*/
uint8_t get_load_cut_off_flag(void);

/**
* @brief		继电器切断指令
* @param		[in] cmd  0：允许闭合mos， 1： 切断mos 
* @return		无
* @retval		无
* @warning		无 
*/
int32_t relay_cutoff_cmd(uint8_t cmd);

/**
* @brief		强充继电器控制指令
* @param		[in] cmd  0：允许闭合mos， 1： 切断mos 
* @return		无
* @retval		无
* @warning		无 
*/
int32_t force_chrg_relay_ctrl_cmd(uint8_t cmd);

/**
* @brief		mos管理初始化
* @param		无  
* @return		无
* @retval		无
* @warning		无 
*/
void relay_manage_init(void);

/**
* @brief		系统继电器管理流程
* @param		无
* @return		无
* @retval		无
* @warning		无
*/
void relay_manage_proc(void);

/**
* @brief		系统继电器管理使能接口
* @param		[in]使能标志： 0：不使能    1：使能  
* @return		返回结果
* @retval		0：操作成功    < 0: 操作失败
* @warning		无 
*/
int32_t relay_manage_enable_set(uint8_t enable);

/**
* @brief		设置继电器控制状态
* @param		[in] relay_type 充电mos，放电mos，预充mos状态
* @param		[in] set_flag     true：闭合  false: 断开
* @warning		ate模式调用
*/
void relay_contrl_state_set(uint8_t relay_type, uint32_t set_flag);

/**
* @brief		切断充放电继电器条件
* @param		无
* @return		无
* @retval		true:满足切断条件    false:不满足
* @warning		无
*/
uint8_t relay_cutoff_condition(void);

/**
* @brief		辅电继电器设置
* @param		uint8_t ctrl     0：断开；1：吸合  
* @return		无
* @retval		无
* @warning		无 
*/
void aux_relay_set(uint8_t ctrl);

#endif

