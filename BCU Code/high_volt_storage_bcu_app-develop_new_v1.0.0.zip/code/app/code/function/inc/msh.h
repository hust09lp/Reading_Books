#ifndef __MSH_H
#define __MSH_H

#if 1
#include <rtthread.h>
#else
#define FINSH_USING_DESCRIPTION
#define FINSH_USING_SYMTAB
typedef long (*syscall_func)(void);
typedef int (*cmd_function_t)(int argc, signed char *argv[]);

extern void finsh_system_init(void);

/* system call table */
 struct finsh_syscall
 {
 	const char	   *name;		/* the name of system call */
 #if defined(FINSH_USING_DESCRIPTION) && defined(FINSH_USING_SYMTAB)
 	const char	   *desc;		/* description of system call */
 #endif
 	syscall_func func;		/* the function address of system call */
 };
				/* Compiler Related Definitions */
#if defined(__ARMCC_VERSION)           /* ARM Compiler */
#define RT_SECTION(x)               __attribute__((section(x)))
#define RT_USED                     __attribute__((used))
#elif defined (__IAR_SYSTEMS_ICC__)     /* for IAR Compiler */
#define RT_SECTION(x)               @ x
#define RT_USED                     __root
#endif
#if defined(_MSC_VER) || (defined(__GNUC__) && defined(__x86_64__))
	struct finsh_syscall *finsh_syscall_next(struct finsh_syscall *call);
    #define FINSH_NEXT_SYSCALL(index)  index=finsh_syscall_next(index)
#else
    #define FINSH_NEXT_SYSCALL(index)  index++
#endif



#ifdef FINSH_USING_DESCRIPTION
#define MSH_FUNCTION_EXPORT_CMD(name, cmd, desc)                      \
                const char __fsym_##cmd##_name[] RT_SECTION(".rodata.name") = #cmd;    \
                const char __fsym_##cmd##_desc[] RT_SECTION(".rodata.name") = #desc;   \
                RT_USED const struct finsh_syscall __fsym_##cmd RT_SECTION("FSymTab")= \
                {                           \
                    __fsym_##cmd##_name,    \
                    __fsym_##cmd##_desc,    \
                    (syscall_func)&name     \
                };
#else
#define MSH_FUNCTION_EXPORT_CMD(name, cmd, desc)                      \
                const char __fsym_##cmd##_name[] = #cmd;                            \
                RT_USED const struct finsh_syscall __fsym_##cmd RT_SECTION("FSymTab")= \
                {                                                                   \
                    __fsym_##cmd##_name,                                            \
                    (syscall_func)&name                                             \
                };
#endif
/**
 * @ingroup msh
 *
 * This macro exports a command to module shell.
 *
 * @param command is the name of the command.
 * @param desc is the description of the command, which will show in help list.
 */
 #define MSH_CMD_EXPORT(command, desc)   \
     MSH_FUNCTION_EXPORT_CMD(command, command, desc)

#endif
#endif

