/**
 * @file     sofar_ext_can_manage.h
 * @brief    公司自定义CAN协议拓展帧SDK接口
 * @author   liulvcong
 * @note     无
 * @version  V1.0
 * @date     2023/2/3
 */
#ifndef __SOFAR_EXT_CAN_MANAGE_H__
#define __SOFAR_EXT_CAN_MANAGE_H__

#include "sofar_can_manage_public.h"

// 高特功能码
typedef enum
{
    // 电池信息数据类
    GOLD_FUNC_CELL_DATA_REQ_CMD           = 0x30,  // 请求电池采集消息
    GOLD_FUNC_CELL_VOLT_ACK_CMD           = 0x31,  // EVBCM 应答 PC 请求电池单体电压消息
    GOLD_FUNC_CELL_TEMP_ACK_CMD           = 0x32,  // EVBCM 应答 PC 请求电池单体温度消息
    GOLD_FUNC_OTHER_TMEP_ACK_CMD          = 0xB2,  // EVBCM 应答 PC 请求极柱温度消息
    GOLD_FUNC_CELL_SOC_ACK_CMD            = 0x33,  // EVBCM 应答 PC 请求电池单体 SOC 消息
    GOLD_FUNC_CELL_SOH_ACK_CMD            = 0x34,  // EVBCM 应答 PC 请求电池单体 SOH 消息
    GOLD_FUNC_SAMPLE_ACK_CMD              = 0x35,  // EVBCM 应答 PC 请求主控采集信息消息
    GOLD_FUNC_SYS_SUMMARY_ACK_CMD         = 0x36,  // EVBCM 应答 PC 请求系统概要信息消息
    GOLD_FUNC_PACK_NUM_DATA_ACK_CMD       = 0x37,  // EVBCM 应答 PC 请求模块电池节数信息消息
    GOLD_FUNC_ALARM_DATA_ACK_CMD          = 0x38,  // EVBCM 应答 PC 请求报警信息应答消息
    GOLD_FUNC_DIDO_DATA_ACK_CMD           = 0x39,  // EVBCM 应答 PC 请求 DI/DO 信息应答消息
    GOLD_FUNC_TEMP_NUM_DATA_ACK_CMD       = 0x3A,  // EVBCM 应答 PC 请求模块温度个数信息消息
    GOLD_FUNC_PACK_BAL_DATA_ACK_CMD       = 0x3B,  // EVBCM 应答 PC 请求模块均衡状态信息消息
    GOLD_FUNC_SLA_UNLINK_ACK_CMD          = 0x3C,  // EVBCM 应答 PC 请求从控模块失联状态信息消息
    GOLD_FUNC_WIRE_OPEN_ACK_CMD           = 0x3D,  // EVBCM 应答 PC 请求掉线状态信息消息
    // 版本控制类
    GOLD_FUNC_VER_DATA_REQ_CMD            = 0x40,  // PC 请求查询版本号消息
    GOLD_FUNC_VER_DATA_ACK_CMD            = 0x41,  // 返回版本号消息
    // 设置信息
    GOLD_FUNC_SET_PASS_BAL_STATE_CMD      = 0x42,  // 上位机设置被动均衡
    // 配置表类
    GOLD_FUNC_PROJECT_INFO_REQ_CMD        = 0x00,  // 项目（硬件）信息报文
    GOLD_FUNC_SENSOR_DATA_REQ_CMD         = 0x03,  // 传感器报文
    GOLD_FUNC_CLU_VOLT_OVER_ALM_CMD       = 0x04,  // 组端总电压上限报警值
    GOLD_FUNC_CLU_VOLT_DOWN_ALM_CMD       = 0x05,  // 组端总电压下限报警值
    GOLD_FUNC_CHG_CURR_ALM_CMD            = 0x06,  // 充电电流报警值
    GOLD_FUNC_DSG_CURR_ALM_CMD            = 0x07,  // 放电电流报警值
    GOLD_FUNC_CHG_CELL_TEMP_ALM_CMD       = 0x08,  // 充电单体电池温度报警值
    GOLD_FUNC_CELL_TEMP_DIS_ALM_CMD       = 0x09,  // 单体电池温差报警值
    GOLD_FUNC_SOC_ALM_CMD                 = 0x0A,  //  SOC 报警值
    GOLD_FUNC_INV_ALM_CMD                 = 0x0B,  // 绝缘电阻报警值
    GOLD_FUNC_CELL_VOLT_OVER_ALM_CMD      = 0x0C,  // 电池单体电压上限报警值
    GOLD_FUNC_CELL_VOLT_DOWN_ALM_CMD      = 0x0D,  // 电池单体电压下限报警值
    GOLD_FUNC_CELL_VOLT_DIS_ALM_CMD       = 0x0E,  // 电池单体电压压差报警值
    GOLD_FUNC_MODE_TEMP_OVER_ALM_CMD      = 0x0F,  // 模块温度上限报警值
    GOLD_FUNC_SYS_RTC_DATA_CMD            = 0x12,  // RTC 数据
    GOLD_FUNC_SYS_ARCH_CMD                = 0x14,  // 从控模块基本参数
    GOLD_FUNC_CELL_MAIN_PARA_CMD          = 0x16,  // 电池主参数
    GOLD_FUNC_SET_SOX_PARA_CMD            = 0x1A,  // 设置 SOC 参数
    GOLD_FUNC_DSG_CELL_TEMP_ALM_CMD       = 0x1C,  // 放电单体电池温度报警值
    GOLD_FUNC_CFG_TABLE_ACK_CMD           = 0x1E,  // 回应后台软件设置配置表消息
    GOLD_FUNC_CFG_TABLE_REQ_CMD           = 0x1F,  // 后台软件下发查询配置表消息
    GOLD_FUNC_PACK_VOLT_OVER_ALM_CMD      = 0x2B,  // 电池模组电压上限报警值
    GOLD_FUNC_PACK_VOLT_DOWN_ALM_CMD      = 0x2C,  // 电池模组电压下限报警值
    // 地址配置类
    GOLD_FUNC_CMU_SET_ADDR_CMD            = 0x2A,  // 主控地址设置命令码
    // 测试类
    GOLD_FUNC_TEST_FORCE_BAL_CMD          = 0x52,  //  发送强制均衡命令-主动均衡
    GOLD_FUNC_TEST_FORCE_DO_CMD           = 0x57,  // PC 发送设置 EVBCM 模块 DO 输出命令
    //编址类
    GOLD_FUNC_INNER_ADDRESS_CMD           = 0x67,  // PC 发送设置 EVBCM 内部编址命令
    // 主控控制类
    GOLD_FUNC_CMU_POWER_CTL_CMD           = 0x80,  // 控制主控上下电指令
    GOLD_FUNC_CMU_INS_CTL_CMD             = 0x81,  // 控制主控绝缘检测功能指令
    
    // 簇间通讯功能码
    GOLD_FUNC_CLU_SUMMARY_CMD             = 0x90,  // 组端概要信息
    GOLD_FUNC_CLU_CELL_SUMMARY_CMD        = 0x91,  // 单体概要信息
    GOLD_FUNC_CLU_ALM_SUMMARY_CMD         = 0x92,  // 告警信息
    GOLD_FUNC_MAINTENANCE_CMD             = 0x95, //  维护信息
    GOLD_FUNC_MAS_CLU_CTL_CMD             = 0x493, // 主 8133 控制命令
    GOLD_FUNC_ALM_REASON_CMD              = 0x494, // 禁充禁放告警原因信息
    GOLD_FUNC_OUT_CLU_CTL_CMD             = 0x495, // 退簇信息
    GOLD_FUNC_PC_CTL_CLU_CMD              = 0x496, // 显控控制指令
    
    // 仿照高特协议新增的功能码
    GOLD_FUNC_FAULT_DATA_ACK_CMD          = 0x3E,  // 新增告警上报(替代了高特协议里充电桩信息)
    
}frame_gold_fun_e;

/**
* @brief		初始化外can管理
* @param		无
* @return		返回结果
* @retval		0：成功    < 0: 失败
* @warning		无 
*/
int32_t ext_can_sofar_manage_init(void);

/**
* @brief		外can过滤器设置
* @param		无  
* @return		无
* @retval		无
* @warning		无
*/
void ext_can_set_filter(uint8_t addr);

/**
* @brief		读取外can硬件缓冲区数据，1ms周期轮询
* @param		无
* @return		返回结果
* @retval		0：添加成功    < 0: 添加失败
* @warning		无 
*/
int32_t ext_can_sofar_rcv_frame_proc(void);

/**
* @brief		注册can接收回调函数
* @param		[in] urgent_flag:紧急处理标志  GENERAL_FRAME:接收到数据正常响应速度10ms ，URGENT_FRAME:接收数据快速响应1ms
* @param		[in] p_can_rec_reg ：
* @param		[in] id：can帧id 
* @param		[in] id：id_mask：过滤不需要接收的位(标准帧的掩码mask固定为0x00000000,拓展帧的掩码mask目标地址设置为FF代表能接收0xFF,0x1F,pack_addr三种类型地址)
* @param		[in] id：can_cb：回调解析函数 
* @param		[in] reg_cnt：注册的数量 
* @return		返回结果
* @retval		0：注册成功    < 0: 注册失败
* @warning		禁止重复注册同一个ID
* @warning		标准帧注册掩码必须为0x00000000
* @warning		掩码不可为0xFFFFFFFF
*/
int32_t ext_can_sofar_register_receive_frame(can_sofar_rcv_reg_t *p_can_rec_reg, uint16_t reg_cnt);

#endif
