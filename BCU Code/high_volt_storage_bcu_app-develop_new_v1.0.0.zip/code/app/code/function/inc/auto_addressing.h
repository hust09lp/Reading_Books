#ifndef __AUTO_ADDRESSING_H__
#define __AUTO_ADDRESSING_H__

#include <stdint.h>
#include <stddef.h>
#include "inner_can_data.h"
#include "sofar_can_manage.h"
/**
 * @brief 自动编址状态
 */
typedef enum
{
    ADDRESSING_DISENABLE = 0, ///< 未使能自动编址
    ADDRESSING_ING,           ///< 编址中
    ADDRESSING_FINISH,        ///< 编址完成
} auto_addressing_state_e;

#define AUTO_ADDRESSING_NO_FAULT 0    // 没故障
#define AUTO_ADDRESSING_ID_CONFLICT 1 // 通讯ID冲突
#define AUTO_ADDRESSING_COMM_FAIL   2 // 通讯故障
#define AUTO_ADDRESSING_ABNORMAL_FAIL   3 // 编址异常
#define AUTO_ADDRESSING_PIN_FAIL   4 // 编址电平异常
#define AUTO_ADDR_ABNORMAL_MAX_NUM  5 // 连续编址失败最大次数
// 自动编址状态机相关
typedef enum{
    EVT_ADDR_STA_CPL_SUC    = 0,    //
    EVT_ADDR_CONT_START    = 1,    //
    EVT_ADDR_FAULT = 2,
    ADDR_EVT_NUM = 3
}addr_fsm_event_e;
typedef enum{
    STA_ADDR_INIT = 0,       ///< 状态机初始化
    STA_ADDR_DISEN = 1,         ///< 未使能
    STA_SET_ADDR_PIN = 2,        ///< 主机编址1
    STA_SET_SLAVE_ADDR = 3,        ///< 主机编址2
    STA_WAIT_SLAVE_REPLY = 4,        ///< 主机编址3
    STA_CHECK_CTL_PIN_STA = 5,        ///< 主机编址4
    STA_MAS_ADDR_SUC = 6, ///< 主机编址成功
    STA_MAS_ADDR_STORE = 7, ///< 主机下发地址存储
    STA_MAS_ADDR_FAIL = 8,  ///< 主机编址失败(重新编址)
    ADDR_STA_NUM = 9,
}addr_fsm_state_e;
typedef uint8_t (*addr_state_action)(void);

typedef struct
{
    addr_state_action    enter_act;	
    addr_state_action    running_act;	
    addr_state_action    exit_act;
}addr_action_map_t; /* 动作action表描述 */

typedef struct
{
	uint8_t flag; 			/* 状态切换标志位,1表示要进行状态切换 */
	uint8_t cur_state;
	uint8_t next_state;
	addr_action_map_t *p_action_map;
	uint8_t (*p_event_map)[ADDR_EVT_NUM];
}addr_fsm_t; /* 状态机控制结构 */

typedef struct
{
    uint8_t comm_state;
    uint16_t unlink_time_cnt;
}pack_comm_status;

typedef struct
{
    uint16_t   auto_addressing_enable;    // 使能自动编址
    auto_addressing_state_e addr_state;   // 编址状态
    uint8_t    pack_num;       // 电池包数量
    uint16_t   master_addr_failed_cnt; // 主机编址失败次数
    uint16_t   addr_abnormal_cnt; // 主机编址异常连续统计次数
    uint8_t    have_pack_on_addressing; // 存在未编址电池包
    uint8_t    address_conflict_flag;
    uint8_t    fault_id_conflict;    // 编址ID冲突
    uint8_t    fault_pack_unlink;    // 电池包失联
    uint8_t    fault_pack_on_addressing; // 电池包未被编址
    uint8_t    fault_pack_num_mismatch; // 编址后电池包数量与预设电池包个数不匹配	
    uint32_t   fault_time_stamp;  // 编址异常判断时间戳
    uint8_t    addr_store_send_cnt; // 地址存储命令发送次数

}master_addr_para; /* 动作action表描述 */

/**
 * @brief  获取自动编址状态
 * @return 自动编址状态
 */
auto_addressing_state_e auto_addressing_get_state(void);

/**
 * @brief  软件版本号一致性获取
 * @return 0 PACK间的软件版本号一致
 * @return !=0 PACK间的软件版本号不一致
 */
uint8_t auto_addressing_soft_version_different_get(void);

/**
 * @brief  获取自动编址故障
 * @return AUTO_ADDRESSING_NO_FAULT     没故障
 * @return AUTO_ADDRESSING_ID_CONFLICT  通讯ID冲突
 * @return AUTO_ADDRESSING_COMM_FAIL    通讯故障
 */
uint8_t auto_addressing_fault_get(void);

/**
 * @brief  获取编址地址
 * @retval =0     未完成编址
 * @retval 1~0x0F 有效地址
 */
uint8_t auto_addressing_get_address(void);

/**
 * @brief  获取PACK数量
 * @retval 1~N 有效的PACK数量
 * @retval 0 获取失败
 * @pre    只有编址完成后，才能正确获取PACK数量
 */
uint8_t auto_addressing_pack_num_get(void);

/**
 * @brief  电池包数目异常标志
 * @retval true 数量异常
 * @retval false 无异常
 * @pre    只有编址完成后，才能判断电池包数量
 */
uint32_t addressing_pack_num_abnormal_get(void);

/**
 * @brief  使能自动编址，自动编址完成后再使能，会重新自动编址
 * @return 无
 */
void auto_addressing_enable(void);

/**
 * @brief   内网CAN(bmu/bcu)，自动编址初始化
 * @param   无
 * @return  返回执行结果 0:正常；<0:异常
 * @warning	无
 */
void inner_auto_addr_init(void);

/**
 * 自动别编址状态机，10ms调用一次
 */
void inner_auto_addressing_proc(void);

/**
 * @brief  失能自动编址
 * @return 无
 */
void auto_addressing_disable(void);

/**
 * @brief  自动编址can报文接收回调函数
 */
bool inner_addr_rcv_callback(can_frame_data_t *can_data, uint16_t func_code);
#endif
