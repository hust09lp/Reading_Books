#ifndef __UPG_MASTER_H__
#define __UPG_MASTER_H__
#include <stdint.h>
#include <stddef.h>
#include "sdk_public.h"


/* 升级BMU流程中使用的相关宏 */
#define BLOCK_SEND_DATA_SIZE 512                                                   ///< 每次发送的有效数据大小为256



#define UPD_MASTER_BMU_CHIP_ROLE   0x2D


/*******************************升级bmu状态机相关***********************************/

typedef enum
{
    UPG_MASTER_IDLE = 0x00,    ///< 升级状态:未升级
    UPG_MASTER_ING	 = 0x01,    ///< 升级状态:升级中
    UPG_MASTER_ALL_FINISH = 0x02,    ///< 升级状态:全部升级成功
    UPG_MASTER_PART_FINISH = 0x03,    ///< 升级状态:部分升级成功
    UPG_MASTER_ERR	 = 0x04,    ///< 升级状态:升级错误
    UPG_MASTER_WAIT_RESPOND	 = 0x05,    ///< 升级状态:等待BMU回应升级结果，加这个状态是为了让BMU能够编址  
}upgrade_master_status_e;

typedef enum
{
    EVT_UPG_MASTER_STA_CPL_SUS,
    EVT_UPG_MASTER_OPERATE_FAIL,
    EVT_UPG_MASTER_TIMEOUT_OR_ERR,
    EVT_UPG_MASTER_START,        // 升级开始
    EVT_UPG_MASTER_BLOCK,        // 升级块数据
    EVT_UPG_MASTER_CHECK,        // 升级结果校验
    UPG_MASTER_EVT_NUM = 6,
}upgrade_master_fsm_event_e;

typedef enum
{
    UPG_MASTER_WAIT_START = 0,       // 步骤0：未进行升级,等待升级中
    UPG_MASTER_FILE_INFO,            // 步骤1：进入升级状态，关闭CAN发送，回复升级准备就绪指令
    UPG_MASTER_BLOCK_INFO,           // 步骤2：发送当前数据块的信息(CRC)，以及bmu的回复
    UPG_MASTER_BLOCK_DATA,           // 步骤3：发送当前数据块数据报文
    UPG_MASTER_FILE_CHECK,           // 步骤4：回复接收成功与失败
    UPG_MASTER_UPDATE_FINISH,        // 步骤5：升级结束
    UPG_MASTER_UPDATE_ERROR,         // 步骤6：升级异常

    UPG_MASTER_STA_NUM
}upgrade_master_fsm_state_e;

typedef struct
{
    uint16_t first_reply_start_flag;            // 首次回复升级开始传输帧标志，每个bit代表一个bmu
    uint16_t block_reply_start_flag;            // 块数据开始始传输帧标志，每个bit代表一个bmu
    uint8_t send_block_data_flag;               // 可以发送数据块
    uint8_t file_check_fail_flag;                // 有丢包标志
    uint16_t file_integrity_flag;                // 回复文件完整标志，每个bit代表一个bmu
    uint8_t transmit_block_num;                 //补包序号
    uint8_t transmit_index;                     //补包索引值（将掩码转换成具体哪个包）
    uint16_t upgrade_finish_flag;               //升级完成标志，每个bit代表一个bmu
    uint16_t rcv_block_size;                   // bmu返回的数据块大小 
    uint32_t transmit_bit_mask;                // 补包掩码 
    uint32_t file_check_over_time_cnt;         // 文件检查超时时间，一直补包不成功则认为升级失败退出升级
    uint8_t file_check_over_time_get_flag;     // 文件检查超时时间获取标志，每次升级的时候置位一次 
    uint32_t default_addr_upd_time_cnt;          // 针对bmu有未编址升级，对时间有要求的工况
    uint8_t default_addr_reply_flag;            // 针对存在有BMU未编址情况，默认地址为0x1f
}upgrade_master_proc_para_t; /*升级过程接收到的CAN消息*/

typedef struct
{
    uint32_t stat_cnt_time;  // 状态计时
    uint8_t stat_delay_cnt; // 升级状态等待计数
}upgrade_master_fsm_para_t; /* 升级状态机控制结构 */


uint8_t upgrade_master_state_get(void);

void upgrade_master_task_proc(void);

void upgrade_master_init(void);

uint32_t upgrade_master_progress_get(void);

uint16_t upgrade_master_bmu_stus_get(void);

// uint8_t upgrade_master_reply_get(void);
/**
* @brief        清除主从升级bmu的尝试再升级标志
* @param        无
* @return        执行结果
* @pre            无
*/
void bmu_upgrade_try_restart_flag_clr(void);
#endif

