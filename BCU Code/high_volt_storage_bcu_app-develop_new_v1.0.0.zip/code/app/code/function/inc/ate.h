/**
 * @file     ate.h
 * @brief    生产装备ate测试流程文件头
 * @company  sofarsolar
 * @author   刘吕从
 * @note     
 * @version
 * @date     2023/7/18 初稿
 */
#ifndef _ATE_H_
#define _ATE_H_

#include <stdint.h>
#include <stddef.h>

#define ATE_SHELL_DEBUG_FALG 1

#define ATE_SET 1
#define ATE_CLR 0
#define ATE_ERR (-1)
#define ATE_OK (0)

/**
 * @brief        特殊模式枚举
 */
typedef enum
{
    AGING_MODE = 0,     // 老化模式
    CALI_PARM,          // 参数设置模式
    ATUO_TEST,          // ATE测试
    FORCE_CTL_MODE,     // 强制控制模式
    SPECIAL_MODE_NUM,   // 特殊模式个数
} special_mode_list_e;

/**
 * @brief        ATE控制状态枚举
 */
typedef enum
{
    ATE_CHECK_STATE = 0,   // 查询控制状态
    ATE_DEFAULT_CLOSE_STATE = 1, // 默认不启动状态
    ATE_CTL_START_STATE = 2,     // 控制启动状态
    ATE_NO_CTL_STATE = 3,        // 不控制
    ATE_OPEN_CTL_STATE = 0xAA,     // 控制启动
    ATE_CLOSE_CTL_STATE = 0x55,    // 控制关闭
    ATE_CTL_STATE_NUM,      // ate控制状态个数
} ate_ctl_state_e;

/**
 * @brief        ATE控制类型枚举
 * @warnning     
 */
typedef enum
{
    ATE_FUNC_SW_CTL_1 = 0,
    ATE_FUNC_SW_CTL_2,
    ATE_FUNC_SW_CTL_3,
    ATE_CTL_ITEM_1,
    ATE_CTL_ITEM_2,
    ATE_CTL_ITEM_3,

    ATE_CTL_TYPE_NUM,
} ate_ctl_type_e;

/**
 * @brief        ATE控制类型枚举
 * @warnning     注意：单个信号与多个设置区分开来
 * @warnning     ate_ctl_deal_proc()的ctl_deal[]数组必须按照顺序此枚举的顺序处理函数
 */
typedef enum
{
    ATE_CAN0_TEST_RESULT = 0,
    ATE_CAN1_TEST_RESULT,
    ATE_485_TEST_RESULT,
    ATE_INNER_ADDR_IO_TEST_RESULT,    
    ATE_EXT_WDT_TEST_RESULT,
    ATE_FLASH_FORMAT_TEST_RESULT,
    ATE_CAN2_TEST_RESULT,
    ATE_DO1_TEST_RESULT,
    ATE_DO2_TEST_RESULT,
    ATE_DO3_TEST_RESULT,
    ATE_CLU_ADDR_IO_TEST_RESULT,
    ATE_DO4_TEST_RESULT,
    ATE_DO5_TEST_RESULT,
    ATE_DO6_TEST_RESULT,
    ATE_DO7_TEST_RESULT,
    ATE_DO8_TEST_RESULT,    
    ATE_TEST_RESULT_NUM,
} ate_test_result_type_e;

/**
* @brief        ATE模式设置
* @param        [in] special_mode     special_mode_list_e枚举
* @param        [in] set_flag         ATE_SET(置位)/ATE_CLR(清除)
* @return       执行结果
* @retval       -1：设置失败
* @retval       0： 设置成功
* @warning      无
*/
int32_t special_mode_set(special_mode_list_e special_mode, uint8_t set_flag);

/**
* @brief        ATE模式获取
* @param        [in] special_mode     special_mode_list_e枚举
* @return       执行结果
* @retval       ATE_ERR：获取失败
* @retval       ATE_SET： 状态置位
* @retval       ATE_CLR： 状态退出
* @warning      无
*/
int32_t special_mode_get(special_mode_list_e special_mode);


/**
* @brief        ate 设置(can命令设置)
* @param        [in]ate_ctl_type_e
* @param        [in]ate_ctl_state_e
* @warning      无
*/
void ate_ctl_can_set(ate_ctl_type_e type, uint8_t ctl_val);

/**
* @brief        ate 获取DO设置(can命令设置)
* @param        [in]ate_ctl_type_e
* @param        [in]ate_ctl_state_e
* @warning      无
*/
uint8_t ate_ctl_can_get(ate_ctl_type_e type);

/**
* @brief        ATE 状态获取
* @param        [in]  ate_state_type_e
* @return       返回 0：无效 ，1: 有效  -1：输入参数异常
* @warning      由于当前ate功能没与业务解耦，不用表驱动方式来写，使用swtich
*/
// int32_t ate_state_get(ate_state_type_e type);

/**
* @brief        ate 其他状态信息(主要是部分测试项，自动测试后结果)
* @param        [in]ate_state_type_e
* @warning      无
*/
uint8_t get_ate_test_func_result(uint8_t func_id);
/**
* @brief        产测完成标志获取
* @param        [in] 无
* @return       执行结果，返回g_product_finish_flag.set_byte
* @warning      无
*/
int32_t product_finish_flag_get(void);

/**
* @brief        产测完成标志设置
* @param        [in] set_flag         参考production_step_flag_u
* @return       执行结果
* @warning      无
*/
int32_t product_finish_flag_set(uint8_t set_flag);
/**
* @brief        ATE模式init
* @param        无   
* @return       无
* @retval       无
* @warning      无
*/
void ate_mode_init(void);

/**
* @brief        ATE管理（100ms任务）
* @param        无   
* @return       无
* @retval       无
* @warning      无
*/
void ate_mode_proc(void);

#endif

