#ifndef __PARALLEL_MANAGE_H__
#define __APP_CONFIG_H__

/* ------------------------------------------------------------------------- */
// 并机相关参数配置
/* ------------------------------------------------------------------------- */



// 并机电压
#define PARALLEL_VOLT   100

// 并机堆电流
#define PARALLEL_HEAP_CUR   100

typedef enum
{
    PARALLEL_FIRST_MACH = 0,    //第一台并机标志
    PARALLEL_LAST_MACH = 1,     //最后一台并机标志
    PARALLEL_CON = 2,            //并机命令标志
    PARALLEL_ERR = 3,           //并机失败
} parallel_data_e;

typedef enum
{
    NO_ERR = 0,    //没有异常
    CMU_NOR_CUT_OFF = 1,     //CMU正常下电
    BAT_ERR = 2,            //簇严重故障
    CMU_ERR_CUT_OFF = 3,    //CMU故障下电
    BAT_VOLT_DIFF_ERR = 4,  //堆电流大于10A且V本簇与V并入压差大于10V
} parallel_err_reason_e;

typedef struct
{
    uint8_t first_manchine;
    uint8_t last_manchine;
    uint8_t con_manchine;
    uint8_t con_err;
}parallel_flag_t;

/**
 * @brief  Get the parallel stus object 返回并机状态
 * @param  i: 
 * @return uint8_t: 
 */
uint8_t get_parallel_state(parallel_data_e i);

/**
* @brief  parallel_init 并机状态初始化
 * @param  
 * @return  
 */
void parallel_init(void);


/**
* @brief  parallel_manage_proc 并机管理
 * @param  
 * @return 
 */
void parallel_manage_proc(void);

#endif
