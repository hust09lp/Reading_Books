/**
 * @file     data_store.h
 * @brief    数据存储
 * @company  sofarsolar
 * @author   刘炜全
 * @note
 * @version
 * @date     2023/5/31
 */

#ifndef __DATA_STORE_H__
#define __DATA_STORE_H__

#define BMS_ATTR_PRINT_FLAG 0

#include <stdint.h>
#include <stddef.h>
#include "sample.h"
#include "sdk_public.h"
#include "inner_can_data.h"
#include "fault_manage.h"

#define FAULT_MSG_TAB 16
#define INNER_CAN_FAULT_MSG_NUM  14

#define RECORD_RUNING_DOG_DEPTH 8000 // 记录存储条数

//故障录波缓存
#define WINDOW_SIZE 5   //缓存条数
#define FAULT_RECORD_DOG_DEPTH 60 // 故障录波记录存储条数

#define RECORD_SAVE_PERIOD1 (1000 * 60 * 1) ///< 有故障时1分钟保存一次记录
#define RECORD_SAVE_PERIOD2 (1000 * 60 * 5) // 正常5分钟一条
#define FAULT_DATA_RECORD_TIME 1000
#define SAVE_TIME1  30
#define SAVE_TIME2  50  



// warn 顺序必须与bms_attr_t的一一对应
typedef enum
{
    // 告警阈值设置
    SET_THRE_CLU_OVER_VOLT_TIP             = 0,  // 簇压过压提示阈值
    SET_THRE_CLU_OVER_VOLT_TIP_DIS            ,  // 簇压过压提示消失阈值
    SET_THRE_CLU_OVER_VOLT_ALM                ,  // 簇压过压告警阈值
    SET_THRE_CLU_OVER_VOLT_ALM_DIS            ,  // 簇压过压告警消失阈值
    SET_THRE_CLU_OVER_VOLT_PRO                ,  // 簇压过压保护阈值
    SET_THRE_CLU_OVER_VOLT_PRO_DIS            ,  // 簇压过压保护消失阈值
    SET_THRE_CLU_UNDER_VOLT_TIP               ,  // 簇压低压提示阈值
    SET_THRE_CLU_UNDER_VOLT_TIP_DIS           ,  // 簇压低压提示消失阈值
    SET_THRE_CLU_UNDER_VOLT_ALM               ,  // 簇压低压告警阈值
    SET_THRE_CLU_UNDER_VOLT_ALM_DIS           ,  // 簇压低压告警消失阈值
    SET_THRE_CLU_UNDER_VOLT_PRO               ,  // 簇压低压保护阈值
    SET_THRE_CLU_UNDER_VOLT_PRO_DIS           ,  // 簇压低压保护消失阈值
    SET_THRE_CHG_OVER_CURR_TIP                ,  // 充电过流提示阈值
    SET_THRE_CHG_OVER_CURR_TIP_DIS            ,  // 充电过流提示消失阈值
    SET_THRE_CHG_OVER_CURR_ALM                ,  // 充电过流告警阈值
    SET_THRE_CHG_OVER_CURR_ALM_DIS            ,  // 充电过流告警消失阈值
    SET_THRE_CHG_OVER_CURR_PRO                ,  // 充电过流保护阈值
    SET_THRE_CHG_OVER_CURR_PRO_DIS            ,  // 充电过流保护消失阈值
    SET_THRE_DSG_OVER_CURR_TIP                ,  // 放电过流提示阈值
    SET_THRE_DSG_OVER_CURR_TIP_DIS            ,  // 放电过流提示消失阈值
    SET_THRE_DSG_OVER_CURR_ALM                ,  // 放电过流告警阈值
    SET_THRE_DSG_OVER_CURR_ALM_DIS            ,  // 放电过流告警消失阈值
    SET_THRE_DSG_OVER_CURR_PRO                ,  // 放电过流保护阈值
    SET_THRE_DSG_OVER_CURR_PRO_DIS            ,  // 放电过流保护消失阈值
    SET_THRE_CELL_CHG_HIGH_TEMP_TIP           ,  // 电芯充电高温提示阈值
    SET_THRE_CELL_CHG_HIGH_TEMP_TIP_DIS       ,  // 电芯充电高温告警消失阈值
    SET_THRE_CELL_CHG_HIGH_TEMP_ALRM          ,  // 电芯充电高温告警阈值
    SET_THRE_CELL_CHG_HIGH_TEMP_ALRM_DIS      ,  // 电芯充电高温告警消失阈值
    SET_THRE_CELL_CHG_HIGH_TEMP_PROT          ,  // 电芯充电高温保护阈值
    SET_THRE_CELL_CHG_HIGH_TEMP_PROT_DIS      ,  // 电芯充电高温保护消失阈值
    SET_THRE_CELL_CHG_LOW_TEMP_TIP            ,  // 电芯充电低温提示阈值
    SET_THRE_CELL_CHG_LOW_TEMP_TIP_DIS        ,  // 电芯充电低温告警消失阈值
    SET_THRE_CELL_CHG_LOW_TEMP_ALRM           ,  // 电芯充电低温告警阈值
    SET_THRE_CELL_CHG_LOW_TEMP_ALRM_DIS       ,  // 电芯充电低温告警消失阈值
    SET_THRE_CELL_CHG_LOW_TEMP_PROT           ,  // 电芯充电低温保护阈值
    SET_THRE_CELL_CHG_LOW_TEMP_PROT_DIS       ,  // 电芯充电低温保护消失阈值
    SET_THRE_CELL_DSG_HIGH_TEMP_TIP           ,  // 电芯放电高温提示阈值
    SET_THRE_CELL_DSG_HIGH_TEMP_TIP_DIS       ,  // 电芯放电高温告警消失阈值
    SET_THRE_CELL_DSG_HIGH_TEMP_ALRM          ,  // 电芯放电高温告警阈值
    SET_THRE_CELL_DSG_HIGH_TEMP_ALRM_DIS      ,  // 电芯放电高温告警消失阈值
    SET_THRE_CELL_DSG_HIGH_TEMP_PROT          ,  // 电芯放电高温保护阈值
    SET_THRE_CELL_DSG_HIGH_TEMP_PROT_DIS      ,  // 电芯放电高温保护消失阈值
    SET_THRE_CELL_DSG_LOW_TEMP_TIP            ,  // 电芯放电低温提示阈值
    SET_THRE_CELL_DSG_LOW_TEMP_TIP_DIS        ,  // 电芯放电低温告警消失阈值
    SET_THRE_CELL_DSG_LOW_TEMP_ALRM           ,  // 电芯放电低温告警阈值
    SET_THRE_CELL_DSG_LOW_TEMP_ALRM_DIS       ,  // 电芯放电低温告警消失阈值
    SET_THRE_CELL_DSG_LOW_TEMP_PROT           ,  // 电芯放电低温保护阈值
    SET_THRE_CELL_DSG_LOW_TEMP_PROT_DIS       ,  // 电芯放电低温保护消失阈值
    SET_THRE_CELL_TEMP_DIFF_TIP               ,  // 电芯温度差异大提示阈值
    SET_THRE_CELL_TEMP_DIFF_TIP_DIS           ,  // 电芯温度差异大告警消失阈值
    SET_THRE_CELL_TEMP_DIFF_ALRM              ,  // 电芯温度差异大告警阈值
    SET_THRE_CELL_TEMP_DIFF_ALRM_DIS          ,  // 电芯温度差异大告警消失阈值
    SET_THRE_CELL_TEMP_DIFF_PROT              ,  // 电芯温度差异大保护阈值
    SET_THRE_CELL_TEMP_DIFF_PROT_DIS          ,  // 电芯温度差异大保护消失阈值
    SET_THRE_SOC_HIGH_TIP                    ,   // SOC过高提示
    SET_THRE_SOC_HIGH_TIP_DIS                ,   // SOC过高提示消失阈值
    SET_THRE_SOC_HIGH_ALRM                   ,   // SOC过高告警
    SET_THRE_SOC_HIGH_ALRM_DIS               ,   // SOC过高告警消失阈值
    SET_THRE_SOC_HIGH_PRO                    ,   // SOC过高保护
    SET_THRE_SOC_HIGH_PRO_DIS                ,   // SOC过高保护消失阈值
    SET_THRE_SOC_LOW_TIP                     ,   // SOC过低提示
    SET_THRE_SOC_LOW_TIP_DIS                 ,   // SOC过低提示消失阈值
    SET_THRE_SOC_LOW_ALRM                    ,   // SOC过低告警
    SET_THRE_SOC_LOW_ALRM_DIS                ,   // SOC过低告警消失阈值
    SET_THRE_SOC_LOW_PRO                     ,   // SOC过低保护
    SET_THRE_SOC_LOW_PRO_DIS                 ,   // SOC过低保护消失阈值
    SET_THRE_SOC_DIFF_TIP                    ,   // SOC差异过大提示
    SET_THRE_SOC_DIFF_TIP_DIS                ,   // SOC差异过大提示消失阈值
    SET_THRE_SOC_DIFF_ALRM                   ,   // SOC差异过大告警
    SET_THRE_SOC_DIFF_ALRM_DIS               ,   // SOC差异过大告警消失阈值
    SET_THRE_SOC_DIFF_PRO                    ,   // SOC差异过大保护
    SET_THRE_SOC_DIFF_PRO_DIS                ,   // SOC差异过大保护消失阈值
    SET_THRE_INS_VAL_TIP                     ,   // 绝缘阻抗异常提示
    SET_THRE_INS_VAL_TIP_DIS                 ,   // 绝缘阻抗异常提示消失阈值
    SET_THRE_INS_VAL_ALRM                    ,   // 绝缘阻抗异常告警
    SET_THRE_INS_VAL_ALRM_DIS                ,   // 绝缘阻抗异常告警消失阈值
    SET_THRE_INS_VAL_PRO                     ,   // 绝缘阻抗异常保护
    SET_THRE_INS_VAL_PRO_DIS                 ,   // 绝缘阻抗异常保护消失阈值
    SET_THRE_CELL_OVER_VOLT_TIP              ,   // 单体电压过充提示阈值
    SET_THRE_CELL_OVER_VOLT_TIP_DIS          ,   // 单体电压过充提示消失阈值
    SET_THRE_CELL_OVER_VOLT_ALM              ,   // 单体电压过充告警阈值
    SET_THRE_CELL_OVER_VOLT_ALM_DIS          ,   // 单体电压过充告警消失阈值
    SET_THRE_CELL_OVER_VOLT_PROT             ,   // 单体电压过充保护阈值
    SET_THRE_CELL_OVER_VOLT_PROT_DIS         ,   // 单体电压过充保护消失阈值
    SET_THRE_CELL_UNDER_VOLT_TIP             ,   // 单体电压过放提示阈值
    SET_THRE_CELL_UNDER_VOLT_TIP_DIS         ,   // 单体电压过放提示消失阈值
    SET_THRE_CELL_UNDER_VOLT_ALM             ,   // 单体电压过放告警阈值
    SET_THRE_CELL_UNDER_VOLT_ALM_DIS         ,   // 单体电压过放告警消失阈值
    SET_THRE_CELL_UNDER_VOLT_PROT            ,   // 单体电压过放保护阈值
    SET_THRE_CELL_UNDER_VOLT_PROT_DIS        ,   // 单体电压过放保护消失阈值
    SET_THRE_CELL_VOLT_DIFF_TIP              ,   // 单体电压差异大提示阈值
    SET_THRE_CELL_VOLT_DIFF_TIP_DIS          ,   // 单体电压差异大提示消失阈值
    SET_THRE_CELL_VOLT_DIFF_ALM              ,   // 单体电压差异大告警阈值
    SET_THRE_CELL_VOLT_DIFF_ALM_DIS          ,   // 单体电压差异大告警消失阈值
    SET_THRE_CELL_VOLT_DIFF_PROT             ,   // 单体电压差异大保护阈值
    SET_THRE_CELL_VOLT_DIFF_PROT_DIS         ,   // 单体电压差异大保护消失阈值
    SET_THRE_MOD_TEMP_HIGH_TIP              ,   // 单板温度过高提示阈值
    SET_THRE_MOD_TEMP_HIGH_TIP_DIS          ,   // 单板温度过高提示消失阈值
    SET_THRE_MOD_TEMP_HIGH_ALM              ,   // 单板温度过高告警阈值
    SET_THRE_MOD_TEMP_HIGH_ALM_DIS          ,   // 单板温度过高告警消失阈值
    SET_THRE_MOD_TEMP_HIGH_PROT             ,   // 单板温度过高保护阈值
    SET_THRE_MOD_TEMP_HIGH_PROT_DIS         ,   // 单板温度过高保护消失阈值
    SET_THRE_BAT_OVER_VOLT_TIP              ,   // 电池包过压提示阈值
    SET_THRE_BAT_OVER_VOLT_TIP_DIS          ,   // 电池包过压提示消失阈值
    SET_THRE_BAT_OVER_VOLT_ALM              ,   // 电池包过压告警阈值
    SET_THRE_BAT_OVER_VOLT_ALM_DIS          ,   // 电池包过压告警消失阈值
    SET_THRE_BAT_OVER_VOLT_PROT             ,   // 电池包过压保护阈值
    SET_THRE_BAT_OVER_VOLT_PROT_DIS         ,   // 电池包过压保护消失阈值
    SET_THRE_BAT_UNDER_VOLT_TIP              ,  // 电池包欠压提示阈值
    SET_THRE_BAT_UNDER_VOLT_TIP_DIS          ,  // 电池包欠压提示消失阈值
    SET_THRE_BAT_UNDER_VOLT_ALM              ,  // 电池包欠压告警阈值
    SET_THRE_BAT_UNDER_VOLT_ALM_DIS          ,  // 电池包欠压告警消失阈值
    SET_THRE_BAT_UNDER_VOLT_PROT             ,  // 电池包欠压保护阈值
    SET_THRE_BAT_UNDER_VOLT_PROT_DIS         ,  // 电池包欠压保护消失阈值
    SET_THRE_CLU_CURR_OVER_DIFF_TIP              ,   // 簇电流差异大提示阈值
    SET_THRE_CLU_CURR_OVER_DIFF_TIP_DIS          ,   // 簇电流差异大提示消失阈值
    SET_THRE_CLU_CURR_OVER_DIFF_ALM              ,   // 簇电流差异大告警阈值
    SET_THRE_CLU_CURR_OVER_DIFF_ALM_DIS          ,   // 簇电流差异大告警消失阈值
    SET_THRE_CLU_CURR_OVER_DIFF_PROT             ,   // 簇电流差异大保护阈值
    SET_THRE_CLU_CURR_OVER_DIFF_PROT_DIS         ,   // 簇电流差异大保护消失阈值
    SET_THRE_POWER_TERMINAL_TEMP_HIGH_TIP       ,   // 极柱温度过高提示阈值
    SET_THRE_POWER_TERMINAL_TEMP_HIGH_TIP_DIS   ,   // 极柱温度过高提示消失阈值
    SET_THRE_POWER_TERMINAL_TEMP_HIGH_ALM       ,   // 极柱温度过高告警阈值
    SET_THRE_POWER_TERMINAL_TEMP_HIGH_ALM_DIS   ,   // 极柱温度过高告警消失阈值
    SET_THRE_POWER_TERMINAL_TEMP_HIGH_PROT      ,   // 极柱温度过高保护阈值
    SET_THRE_POWER_TERMINAL_TEMP_HIGH_PROT_DIS  ,   // 极柱温度过高保护消失阈值
    SET_THRE_POWER_OVER_VOLT_ALM       ,           // 供电过压告警阈值
    SET_THRE_POWER_OVER_VOLT_ALM_DIS   ,           // 供电过压告警消失阈值
    SET_THRE_POWER_UNDER_VOLT_ALM       ,          // 供电欠压告警阈值
    SET_THRE_POWER_UNDER_VOLT_ALM_DIS   ,          // 供电欠压告警消失阈值
    SET_THRE_ALM_END,
    // 单个字节设置
    SET_THRE_HALL_ENABLE = SET_THRE_ALM_END,    // 霍尔使能标志 
    SET_THRE_EX_CAN_ADDR,                       // 外can地址
    SET_THRE_CLU_PACK_NUM,                      // 本簇电池包个数
    SET_THRE_CELL_TYPE,                         // 电池类型 1 表示 L--磷酸铁锂电池,2 表示 N—钛酸锂电池,3 表示 T—锰酸锂电池,4 表示 S--三元锂电池,
    SET_THRE_CELL_MODEL,                        // 电芯型号
    SET_THRE_PACK_CELL_NUM  ,                   ///< 单PACK单体个数  
    SET_THRE_PACK_TEMP_NUM  ,                   ///< 单PACK温度个数 
    SET_THRE_RES,                               // 保留
    SET_THRE_HALL_RANGE_1,                      // 霍尔电流传感器1量程
    SET_THRE_HALL_RANGE_2,                      // 霍尔电流传感器1量程
    SET_THRE_HALL_RANGE_3,                      // 霍尔电流传感器1量程
    SET_THRE_BATT_CAP,                          // 电池包容量 1Ah/bit
    SET_THRE_MANUFACTOR,                        // 厂家
    SET_THRE_FAN_OPEN_TEMP  ,                   ///< 风扇开启温度
    SET_THRE_FAN_CLOSE_TEMP ,                   ///< 风扇关闭温度 
    SET_THRE_FULL_CHG_VOL   ,                   ///< 满充电压 
    SET_THRE_EMPTY_DCHG_VOL ,                   ///< 截至电压
    SET_THRE_SOC                             ,  // SOC
    SET_THRE_SOH                             ,  // SOH
    SET_THRE_CNT,
} set_thre_id_e;


/**
 * @brief 安全参数类型
 */
typedef struct
{
    int16_t appear_value;            ///< 产生阈值
    int16_t cancel_value;             ///< 取消阈值
} safety_param_t;



/**
 * @brief 安全参数表
 */
typedef struct
{
    safety_param_t total_over_vol_tip;             ///< 总压过压提示 分辨率为0.1V/bit，偏移量为0
    safety_param_t total_over_vol_alarm;           ///< 总压过压告警 分辨率为0.1V/bit，偏移量为0  
    safety_param_t total_over_vol_protect;         ///< 总压过压保护 分辨率为0.1V/bit，偏移量为0
    safety_param_t total_under_vol_tip;            ///<总压欠压提示  分辨率为0.1V/bit，偏移量为0
    safety_param_t total_under_vol_alarm;          ///<总压欠压告警  分辨率为0.1V/bit，偏移量为0
    safety_param_t total_under_vol_protect;        ///< 总压欠压保护 分辨率为0.1V/bit，偏移量为0

    safety_param_t chg_over_cur_tip;               ///< 充电过流提示 分辨率：0.1A 无偏移量
    safety_param_t chg_over_cur_alarm;             ///< 充电过流告警 分辨率：0.1A 无偏移量
    safety_param_t chg_over_cur_protect;           ///< 充电过流保护 分辨率：0.1A 无偏移量
    
    safety_param_t dchg_over_cur_tip;             ///< 放电过流提示 分辨率：0.1A 无偏移量
    safety_param_t dchg_over_cur_alarm;           ///< 放电过流告警 分辨率：0.1A 无偏移量
    safety_param_t dchg_over_cur_protect;         ///< 放电过流保护 分辨率：0.1A 无偏移量

    safety_param_t chg_over_cell_temp_tip;        ///< 充电温度过高提示, 分辨率：0.1℃/bit 偏移量 -40.0℃
    safety_param_t chg_over_cell_temp_alarm;      ///< 充电温度过高告警, 分辨率：0.1℃/bit 偏移量 -40.0℃
    safety_param_t chg_over_cell_temp_protect;    ///< 充电温度过高保护, 分辨率：0.1℃/bit 偏移量 -40.0℃
    
    safety_param_t chg_under_cell_temp_tip;        ///< 充电温度过低提示, 分辨率：0.1℃/bit 偏移量 -40.0℃
    safety_param_t chg_under_cell_temp_alarm;      ///< 充电温度过低告警, 分辨率：0.1℃/bit 偏移量 -40.0℃
    safety_param_t chg_under_cell_temp_protect;    ///< 充电温度过低保护, 分辨率：0.1℃/bit 偏移量 -40.0℃

    safety_param_t dchg_over_cell_temp_tip;        ///< 放电温度过高提示, 分辨率：0.1℃/bit 偏移量 -40.0℃
    safety_param_t dchg_over_cell_temp_alarm;      ///< 放电温度过高告警, 分辨率：0.1℃/bit 偏移量 -40.0℃
    safety_param_t dchg_over_cell_temp_protect;    ///< 放电温度过高保护, 分辨率：0.1℃/bit 偏移量 -40.0℃
    
    safety_param_t dchg_under_cell_temp_tip;        ///< 放电温度过低提示, 分辨率：0.1℃/bit 偏移量 -40.0℃
    safety_param_t dchg_under_cell_temp_alarm;      ///< 放电温度过低告警, 分辨率：0.1℃/bit 偏移量 -40.0℃
    safety_param_t dchg_under_cell_temp_protect;    ///< 放电温度过低保护, 分辨率：0.1℃/bit 偏移量 -40.0℃
    safety_param_t cell_temp_diff_tip;              ///< 单体温度差值过大提示, 分辨率：0.1℃/bit 偏移量 -40.0℃
    safety_param_t cell_temp_diff_alarm;            ///< 单体温度差值过大告警, 分辨率：0.1℃/bit 偏移量 -40.0℃
    safety_param_t cell_temp_diff_protect;          ///< 单体温度差值过大保护, 分辨率：0.1℃/bit 偏移量 -40.0℃
    safety_param_t bat_soc_over_tip;              ///< SOC过大提示, 分辨率：0.1%/bit 偏移量 0
    safety_param_t bat_soc_over_alarm;            ///< SOC过大告警, 分辨率：0.1%/bit 偏移量 0
    safety_param_t bat_soc_over_protect;          ///< SOC过大保护, 分辨率：0.1%/bit 偏移量 0
    safety_param_t bat_soc_under_tip;              ///< SOC过低提示, 分辨率：0.1%/bit 偏移量 0
    safety_param_t bat_soc_under_alarm;            ///< SOC过低告警, 分辨率：0.1%/bit 偏移量 0
    safety_param_t bat_soc_under_protect;          ///< SOC过低保护, 分辨率：0.1%/bit 偏移量 0
    safety_param_t bat_soc_diff_tip;              ///< SOC差值过大提示, 分辨率：0.1%/bit 偏移量 0
    safety_param_t bat_soc_diff_alarm;            ///< SOC差值过大告警, 分辨率：0.1%/bit 偏移量 0
    safety_param_t bat_soc_diff_protect;          ///< SOC差值过大保护, 分辨率：0.1%/bit 偏移量 0
    safety_param_t ins_val_under_tip;              ///< 绝缘阻抗过低提示, 分辨率：1KΩ/bit  偏移量 0
    safety_param_t ins_val_under_alarm;            ///< 绝缘阻抗过低告警, 分辨率：1KΩ/bit  偏移量 0
    safety_param_t ins_val_under_protect;          ///< 绝缘阻抗过低保护, 分辨率：1KΩ/bit  偏移量 0
    safety_param_t cell_over_vol_tip;              ///< 单体过压提示, 分辨率：0.001V/bit  偏移量 0
    safety_param_t cell_over_vol_alarm;            ///< 单体过压告警, 分辨率：0.001V/bit  偏移量 0
    safety_param_t cell_over_vol_protect;          ///< 单体过压保护, 分辨率：0.001V/bit 偏移量 0
    safety_param_t cell_under_vol_tip;              ///< 单体过低提示, 分辨率：0.001V/bit  偏移量 0
    safety_param_t cell_under_vol_alarm;            ///< 单体过低告警, 分辨率：0.001V/bit  偏移量 0
    safety_param_t cell_under_vol_protect;          ///< 单体过低保护, 分辨率：0.001V/bit 偏移量 0
    safety_param_t cell_vol_diff_tip;              ///< 单体过低提示, 分辨率：0.001V/bit  偏移量 0
    safety_param_t cell_vol_diff_alarm;            ///< 单体过低告警, 分辨率：0.001V/bit  偏移量 0
    safety_param_t cell_vol_diff_protect;          ///< 单体过低保护, 分辨率：0.001V/bit 偏移量 0
    safety_param_t mod_temp_over_tip;              ///< 模块温度过高提示, 分辨率：0.1℃/bit 
    safety_param_t mod_temp_over_alarm;            ///< 模块温度过高告警, 分辨率：0.1℃/bit 
    safety_param_t mod_temp_over_protect;          ///< 模块温度过高保护, 分辨率：0.1℃/bit 
    safety_param_t bat_over_vol_tip;              ///< 电池模组过压提示, 分辨率：0.1V/bit  偏移量 0
    safety_param_t bat_over_vol_alarm;            ///< 电池模组过压告警, 分辨率：0.1V/bit  偏移量 0
    safety_param_t bat_over_vol_protect;          ///< 电池模组过压保护, 分辨率：0.1V/bit 偏移量 0
    safety_param_t bat_under_vol_tip;              ///< 电池模组过低提示, 分辨率：0.1V/bit  偏移量 0
    safety_param_t bat_under_vol_alarm;            ///< 电池模组过低告警, 分辨率：0.1V/bit  偏移量 0
    safety_param_t bat_under_vol_protect;          ///< 电池模组过低保护, 分辨率：0.1V/bit 偏移量 0
    safety_param_t power_terminal_temp_over_tip;        ///< 功率端子温度过高提示, 分辨率：0.1℃/bit 
    safety_param_t power_terminal_temp_over_alarm;      ///< 功率端子温度过高告警, 分辨率：0.1℃/bit 
    safety_param_t power_terminal_temp_over_protect;    ///< 功率端子温度过高保护, 分辨率：0.1℃/bit 
    safety_param_t power_volt_over_alarm;      ///< 供电电压过高告警, 分辨率：0.1V/bit 
    safety_param_t power_volt_under_alarm;     ///< 供电电压过低, 分辨率：0.1V/bit 
    safety_param_t rsv[13];
} safety_para_tab_t;



/**
 * @brief 故障录波记录数据
 */
typedef struct
{
    // uint16_t year_month;
    // uint16_t day_hour;
    // uint16_t min_sec;        
    // uint16_t fault_id;
    int16_t  current;   
    uint16_t maxvolt;
    uint16_t minvolt;
    int8_t maxtemp;
    int8_t mintemp;    

}fault_record_data_t;



typedef struct
{
    uint8_t file_no;
    char file_name[15];
}fault_record_file_t;

/**
 * @brief BMS属性数据表
 */
typedef struct
{
    uint16_t version;         // bms属性数据表版本
    safety_para_tab_t safety; // 安全参数表
    uint8_t hall_enable;
    uint8_t ex_addr;          // 外can地址
    uint8_t clu_pack_num;     // 本簇电池包个数
    uint8_t cell_type;        // 电池类型 1 表示 L--磷酸铁锂电池,2 表示 N—钛酸锂电池,3 表示 T—锰酸锂电池,4 表示 S--三元锂电池,
    uint8_t cell_model;       // 电芯型号
    uint8_t pack_cell_num;    // 单PACK单体个数
    uint8_t pack_temp_num;    // 单PACK电芯温度个数
    uint8_t res;              // 保留
    uint16_t hall_range[3];   // 3个霍尔电流传感器量程
    uint16_t bat_cap;         // 电池包容量，1Ah/bit 偏移量：0
    uint16_t manufactor;      // 厂家
    int16_t fan_open_temp;    // 风扇开启温度
    int16_t fan_close_temp;   // 风扇关闭温度
    uint16_t full_chg_vol;    // 满充电压
    uint16_t empty_dchg_vol;  // 截至电压
    adjust_para_tab_t adjust; // 校准参数表
    uint8_t pack_sn[21];      // Pack SN：条形码
    uint8_t board_sn[21];     // Board SN：单板条形码
    uint8_t app_ver[8];       // APP版本号
    uint8_t project_ver[2];       // 项目版本（1.0项目、2.0项目或者其他），默认2.0项目
    uint32_t u32reserve[10];  // 预留
    uint32_t check;           // crc
} bms_attr_t;                 // 数据往下增加，不能中间插入

typedef enum{
    FAULT_CNT_START = 0,
    POWER_NTC_ERR_CNT = FAULT_CNT_START,
    ENV_NTC_ERR_CNT,
    FLASH_INVALID_CNT,
    INNER_CAN_COMM_ABNORMAL_CNT,
    INNER_CAN_ADDR_REPEAT_FAULT_CNT,
    BCU_PCS_COMM_ABNORMAL_FAULT_CNT,
    POWER_TERMINAL_TEMP_OVER_PROTECT_CNT,
    POSITIVE_RELAY_ADHESION_CNT,
    NEGATIVE_RELAY_ADHESION_CNT,
    AUX_RELAY_ADHESION_CNT,
    INS_RES_VAL_LOW_PROTECT_CNT,
    EXT_ADC_ABNORMAL_CNT,
    PRE_CHARGE_FAULT_CNT,
    ENV_TEMP_HIGH_PROTECT_CNT,
    TRIP_FAULT_CNT,
    CAN_HALL_SENSOR_FAULT_CNT,
    CAN_HALL_SENSOR_COMM_FAULT_CNT,
    POWER_OFF_FAULT_CNT,
    ALL_CLUSTER_POWER_OFF_FAULT_CNT,
    CLU_TOTAL_VOLT_HIGH_PROTECT_CNT,
    CLU_TOTAL_VOLT_LOW_PROTECT_CNT,
    CLU_TOTAL_VOLT_DIFF_OVER_FAULT_CNT,
    INTER_CLU_VOLT_DIFF_OVER_FAULT_CNT,
    CHG_CURR_HIGH_PROTECT_CNT,
    DSG_CURR_OVER_PROTECT_CNT,
    FAULT_CNT_MAX_NUMS,
}fault_cnt_num_e;
typedef union
{
	uint32_t stu_val;
	struct
	{
		uint8_t 	pwr_ntc_err_stu :1;			            ///< 功率端子温度采样异常次数
		uint8_t 	env_ntc_err_stu :1;	                    ///< 环境温度采样异常次数
		uint8_t 	flash_ivalid_stu :1;	                ///< FLASH失效次数
		uint8_t 	inner_can_comm_abnormal_stu :1;	        ///< 内CAN通信异常次数
        uint8_t 	inner_can_addr_repeat_fault_stu :1;	    ///< 内can反复编址故障次数
		uint8_t 	power_terminal_temp_over_pro_stu :1;	///< 功率端子过温保护次数
		uint8_t 	pos_rly_adhesion_stu :1;	            ///< 正继电器粘连次数
		uint8_t 	neg_rly_adhesion_stu :1;	            ///< 负继电器粘连次数
        uint8_t 	aux_rly_adhesion_stu :1;	            ///< 辅源继电器粘连次数
        uint8_t 	ins_res_val_low_pro_stu :1;	            ///< 绝缘阻抗过低保护次数
        uint8_t 	ext_adc_abnormal_stu :1;	            ///< 片外ADC异常次数
        uint8_t 	pre_chg_fault_stu :1;	                ///< 预充故障次数
        uint8_t 	env_temp_high_pro_stu :1;	            ///< 环境温度过高保护次数
        uint8_t 	trip_fault_stu :1;	                    ///< 跳机故障次数
        uint8_t 	call_hall_sensor_fault_stu :1;	        ///< CAN霍尔传感器故障次数
        uint8_t 	can_hall_sensor_comm_fault_stu :1;	    ///< CAN霍尔传感器通讯异常次数
        uint8_t     power_off_fault_stu :1;                 ///< 正常下电失败次数
        uint8_t     all_clu_power_off_fault_stu :1;         ///< 接收到所有簇下电失败次数
        uint8_t     clu_total_volt_high_pro_stu :1;         ///< 簇总压过高保护次数
        uint8_t     clu_total_volt_low_pro_stu :1;          ///< 簇总压过低保护次数
        uint8_t     clu_total_volt_diff_over_fault_stu :1;  ///< 簇总压差过大故障次数
        uint8_t     inter_clu_volt_diff_over_fault_stu :1;  ///< 簇间压差过大故障次数
        uint8_t     chg_cur_high_pro_stu :1;                ///< 充电电流过大保护次数
        uint8_t     dsg_cur_over_pro_stu :1;                ///< 放电电流过大保护次数
	}bits;
} fault_cnt_stu_u;

typedef struct
{
    uint16_t fault_cnt_num;
    fault_type_e fault_cnt_map;
}fault_cnt_map_t;

/**
 * @brief BMS运行实时数据，需要掉电保存
 */
#pragma pack(4)
typedef struct
{
    uint16_t soc;            ///< SOC
    uint16_t soh;            ///< SOH
    uint16_t cycle_count;    ///< 循环次数
    uint16_t remain_cap;     ///< 剩余容量 0.1AH
    uint16_t real_cap;       ///< 实际容量 0.1AH - 满充容量
    uint16_t bat_pack_id;    ///< 电池编码
    uint32_t add_up_ah_chg; ///< 累计充电容量 AH
    uint32_t add_up_ah_dsg; ///< 累计放电容量 AH
	uint32_t add_up_wh_chg;  ///< 累计充电量   WH
    uint32_t add_up_wh_dsg;  ///< 累计放电量   WH
    uint64_t add_up_mas_chg; ///< 累计充电容量 mas
    uint64_t add_up_mas_dsg; ///< 累计放电容量 mas
	uint64_t add_up_mws_chg;  ///< 累计充电量   mws
    uint64_t add_up_mws_dsg;  ///< 累计放电量   mws    
    uint16_t time[6];        ///< 时间
	uint8_t	 today_wh_chg;   ///< 今日充电电量; 
    uint8_t	 today_wh_dsg;   ///< 今日放电电量;
    uint8_t  product_finish_flag;    ///< 生产完成标志
    uint16_t fault_cnt[FAULT_CNT_MAX_NUMS]; //保护越限次数统计
    uint32_t relay_cutoff_forced; // 继电器强切次数
    uint8_t  u8reserve1[6];  ///< 预留
    uint8_t  u8reserve2[3];   ///< 预留
    uint8_t  flash_data[8];   ///< flash test
    uint32_t u32reserve[27];  ///< 预留
    uint32_t version;         ///< 预留
    uint32_t check;           ///< 预留
} bms_runing_data_t;
#pragma pack()

#pragma pack(1)
/**
 * @brief BMS记录数据
 */
typedef struct
{
    uint8_t fault_id;               //0xff为无效id，主要是故障录波的存储会用到这个
    uint16_t year_month;
    uint16_t day_hour;
    uint16_t min_sec;
    uint16_t bat_acc_volt;          //电池簇累加电压 0.1V
    uint8_t soc;                    //电池簇SOC 1%
    uint8_t soh;                    //电池簇SOH 1%
    int16_t current;               //电池簇电流 0.01A
    uint8_t di_stus;            //DI状态
    uint8_t do_stus;            //DO状态
    uint8_t sys_stus;           //系统状态
    uint8_t other_status;       //其他状态
    uint8_t fault_level;       //告警等级 
    uint8_t fault_msg[FAULT_MSG_TAB]; //告警信息 
    uint16_t max_pack_volt;         //最高pack电压 0.1V
    uint16_t min_pack_volt;         //最低pack电压 0.1V
    uint8_t max_pack_volt_no;       //最高pack电压包序号
    uint8_t min_pack_volt_no;       //最低pack电压包序号
    int16_t clu_current2;           //高压箱里如果接两个霍尔， 这是给另一个霍尔使用
    uint16_t iso_impedance_value;   //高压绝缘阻抗  1kΩ          
    uint16_t bus_volt;              //母线侧电压    0.1V
    uint16_t load_volt;             //负载端电压    0.1V
    uint16_t supply_volt;           //辅助电源电压  0.1v
    uint16_t chrg_cur_lim;          //电池簇充电电流上限    0.1A
    uint16_t dischrg_cur_lim;       //电池簇放电电流上限    0.1A
    int8_t  pwr_temp[4];            //功率端子温度      1℃
    int8_t  env_temp;              //环境温度      1℃
    uint32_t chrg_ah;                //累计充电安时  1AH
    uint32_t dsg_ah;               //累计放电安时  1AH
    uint32_t chrg_wh;                //累计充电瓦时  1Wh
    uint32_t dsg_wh;               //累计放电瓦时  1Wh
    uint16_t max_cell_volt[PACK_MAX_NUM]; //最大单体电压    1mV
    uint16_t min_cell_volt[PACK_MAX_NUM]; //最小单体电压    1mv  
    uint16_t avg_cell_volt[PACK_MAX_NUM]; //平均单体电压    1mv      
    int8_t max_cell_temp[PACK_MAX_NUM];   //最大单体温度    1°C  
    int8_t min_cell_temp[PACK_MAX_NUM];   //最小单体温度    1°C
    int8_t avg_cell_temp[PACK_MAX_NUM];   //最小单体温度    1°C    
    uint32_t u32rsv[13];      
    uint8_t u8rsv;   
    
} bms_record_data_t;	//200个字节
#pragma pack()

typedef enum
{
    data_chg_enable  = 0,        ///< 充电使能
    data_dsg_enable  = 1,        ///< 放电使能
    data_fault_state = 2,        ///< 严重故障
    data_CLU_PARALLEL= 3,        ///< 并簇模式
	data_CLU_SINGLE  = 4,		///< 单簇模式
} other_status;

typedef struct
{
    bms_record_data_t fault_record_buff[WINDOW_SIZE]; //扫窗存储BUFF
    uint16_t fault_buff_fill_cnt;   //buff计数
    uint8_t buff_full_flag;
    uint16_t fault_record_cnt;  //剩余存储数

}fault_record_buff_info_t;

/**
 * @brief 数据保存相关标志
 */
typedef struct
{
    uint8_t bms_record_save_flag;      //运行日志记录标志
    uint8_t bms_runing_data_save_flag; //运行数据保存标志
    uint8_t bms_attr_save_flag;        //属性数据保存标志

    int8_t runing_data_file_open;      //以上四种数据文件打开标志
    int8_t bms_attr_file_open;
    int8_t record_file_open;
    int8_t fault_record_file_open;

    uint8_t para_err;
    uint8_t runing_data_err;
    uint8_t record_err;    
    uint8_t fault_record_err; 

    uint8_t bms_record_read_flag;
    uint8_t fault_record_read_flag;
    uint8_t his_event_read_flag;

    uint8_t runing_data_file_err_cnt;      //失败计数
    uint8_t bms_attr_file_err_cnt;
    uint8_t record_file_err_cnt;
    uint8_t his_event_file_err_cnt;    
}data_store_flag_t;


/**
 * @enum   data_store_fault_e
 * @brief  故障类型
 */
typedef enum
{
    DATA_STORE_BMS_ATTR     = 0,        ///< 保存数据故障 - 参数区
    DATA_STOR_RUNNING_DATA  = 1,         ///< 保存数据故障 - 运行数据
    DATA_STORE_RECORD       = 2,              ///< 保存数据故障 - 5分钟日志数据
    DATA_STORE_FAULT_RECORD = 3,        ///< 保存数据故障 - 故障录波数据
	DATA_STORE_FAULT_NUM	= 4,		//数据保存总数
} data_store_fault_e;


/**
 * @brief 5分钟特性数据存储判断
 */
typedef struct
{
    uint8_t  bmu_fault[PACK_MAX_NUM][INNER_CAN_FAULT_MSG_NUM];       //10个包，每个包14*1个字节异常
    uint8_t   bcu_fault_num;

}sum_fault_data_t;

/**
 * @enum   his_event_e
 * @brief  故障类型
 */
typedef enum
{
    HIS_FAULT_RSV =         60,                     // 故障产生和消失分别按60预留
	HIS_EVENT_INDEX         = 120,							///< 前120个已经给到了故障产生和消失，所以这一部分需要从120开始	
    RESET_SOURCE_INDEX = HIS_EVENT_INDEX,            ///< 当前复位方式只有5个，然后预留5个位置
                                                    // * -# LP reset    0   // low power复位            120
                                                    // * -# BOR reset   1   // 电压低于保护阈值复位      121     
                                                    // * -# SW reset    2   // 软件复位                 122
                                                    // * -# IWDG reset  3   // IWDG复位                 123
                                                    // * -# WWDG reset  4   // WWDG复位                 124
                                                    // * -# Pin reset   5   // Pin 引脚复位              125

    SHUNT_DOWN_SOURCE_INDEX = 130,                  ///< 当前休眠原因，
    NON_SHUNT_DOWN          = SHUNT_DOWN_SOURCE_INDEX,  ///< 默认主动故障关机
    KEY_PRESS_SHUT_DOWN     = 131,                      ///< 按键关机
    BMU_REQUEST_SHUT_DOWN   = 132,                      ///< BMU请求    
    EXT_CAN_COMM_ERR_SHUT_DOWN = 133,                   ///< 外can通讯失败24h关机
    INN_CAN_COMM_ERR_SHUT_DOWN = 134,                   ///< 内can通讯失败30min关机
    BOOT_UPGRADE_SHUT_DOWN  = 135,                      ///< boot升级启动复位关机
    UPGRADE_RESET_SHUT_DOWN = 136,                      ///< bcu升级完成复位关机
    BMU_FAULT_SHUT_DOWN     = 137,                      ///< bmu故障关机
    BCU_FAULT_SHUT_DOWN     = 138,                      ///< bcu故障关机

    UPG_EVENT_INDEX         = 140,
    UPG_ING_EVENT           = UPG_EVENT_INDEX,            ///< 升级中事件
    UPG_SUC_EVENT           = 141,                          ///< 升级成功事件
    UPG_FAIL_EVENT          = 142,                          ///< 升级失败事件 
    BMU_UPG_ING_EVENT       = 143,                          ///< BMU升级中事件    
    BMU_UPG_SUC_EVENT       = 144,                          ///< BMU升级成功事件 
    BMU_UPG_FAIL_EVENT      = 145,                          ///< BMU升级失败事件 

    OTH_EVE_HAPPEN_INDEX    = 150,                  ///< 其他事件产生
    FULL_CHRG_EVENT_EN      = OTH_EVE_HAPPEN_INDEX,  ///< 满充
    EMPT_DISC_EVENT_EN      = 151,                    ///< 放空
    OTH_EVE_CANCEL_INDEX    = 160,                  ///< 其他事件消失（暂时考虑不记录）
    FULL_CHRG_EVENT_DIS     = OTH_EVE_CANCEL_INDEX,  ///< 满充
    EMPT_DISC_EVENT_DIS     = 161,                    ///< 放空

    WAKE_SOURCE_INDEX       = 170,                      //0x0000UL    ///< 无唤醒源
                                                        //0x0001UL    ///< 按键唤醒
                                                        //0x0002UL    ///< 充电唤醒
                                                        //0x0003UL    ///< CAN唤醒 PCS通讯(外CAN)
                                                        //0x0004UL    ///< 电池包IN唤醒 并机
                                                        //0x0005UL    ///< 充电激活唤醒
    BMU_FAULT_INDEX         = 180,                      //用于记录是哪个BMU触发，0x0000UL    ///< bmu1
                                                        //0x0001UL    ///< bmu2
                                                        //0x0002UL    ///< bmu3以此类推
    

    
                                                
} his_event_e;

/**
 * @brief 保存BMS属性表中某个元素
 * @param offset 偏移量
 * @param data 数据内容
 * @param len 数据长度
 * @return int32_t
 * @retval 0 成功
 * @retval -1 失败
 */
int32_t data_store_save_bms_attr(uint32_t offset, uint8_t *data, uint32_t len);

/**
 * @brief   保存BMS校准参数中某个元素
 * @return 无
 */
int32_t data_store_save_adjust_para(adjust_para_tab_t *adjust_para_tab);

/**
 * @brief 保存BMSrunningdata中某个元素
 * @return int32_t
 * @retval 0 成功
 * @retval -1 失败
 */
int32_t bms_runing_data_save(bms_runing_data_t bms_runing_data);

/**
 * @brief 执行保存BMSrunningdata全部数据
 * @return int32_t
 * @retval 0 成功
 * @retval -1 失败
 */
int32_t bms_runing_data_save_all(void);

/**
 * @brief 保护越限次数清除
 *
 */
void bms_protect_cnt_clear(void);

/**
* @brief        获取故障存储标志数据
* @param        [out]bms_attr_t*
* @param        void
*/
const fault_record_buff_info_t *get_fault_record_buff(void);
/**
* @brief        获取bms存储数据
* @param        [out]bms_attr_t*
* @param        void
*/
const bms_attr_t *get_bms_attr(void);

//返回attr初始参数
const bms_attr_t *get_bms_attr_init(void);
    
/**
* @brief        获取bms运行数据
* @param        [out]get_bms_runing_data*
* @param        void
*/
const bms_runing_data_t *get_bms_runing_data(void);


/**
 * @brief 存储故障标志获取
 *
 */
int32_t data_store_fault_get(data_store_fault_e fault_type);

/**
 * @brief 存储故障总标志获取
 *
 */
int32_t data_store_toatal_fault_get(void);

/**
 * @brief   初始化数据存储模块
 * @param   none
 * @param   void
 */
void data_store_init(void);

/**
 * @brief 保存数据线程，100ms调用一次
 * @return 无
 */
void data_store_thread(void);

void fault_recording_init(void);

/**
 * @brief 故障录波线程(1000ms调用一次)
 *
 */
void fault_recording_proc(void);




/**
 * @brief 五分钟日志读标志
 * @return 无
 */
void set_bms_record_read_flag(uint8_t flag);

/**
 * @brief 故障录波读标志
 * @return 无
 */
void set_fault_record_read_flag(uint8_t flag);


/**
 * @brief 阈值参数恢复默认
 * @return 无
 */
int8_t attr_data_resume_default_data(void);


/**
 * @brief 5分钟特性数据获取
 * @return 无
 */
int8_t bms_record_data_read(uint16_t read_num, bms_record_data_t *p_data);

//删除故障录波文件
int8_t bms_fault_record_file_delete(uint8_t file_no);

// 设置存储数据
int8_t data_store_save_bms_attr_thre_val(set_thre_id_e thre_id, uint16_t set_value);

// 读取存储数据
int8_t data_store_bms_attr_thre_val_get(set_thre_id_e thre_id, uint16_t *get_value);
#endif

