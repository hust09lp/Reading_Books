#ifndef CELL_BALANCE_H
#define CELL_BALANCE_H

#include <stdbool.h>
#include "sdk.h"

// 延迟综合主动均衡数据，当前1s
#define PACK_BAL_INIT_DELAY_1S_BASED_10ms (100u)

//持续上报的本簇BCU被动均衡数据发送时间 5s
#define CLUSTER_DATA_RDY_SEND_TIME_BASED_10ms (500u)

//BCU等待BMU发送数据的时间
#define CLUSTER_WATING_BMU_TIME_BASED_10ms (1000u)

/**
 * @brief   返回本簇BMU被动均衡数据准备状态
 *
 */
bool cluster_passive_data_status_get(void);

/**
 * @brief   返回本簇所有BMU的最小电芯SOC
 *
 */
uint16_t cluster_min_cell_soc_get(void);

/**
 * @brief   刷新BCU数据准备完成时间的计数
 *
 */
void cluster_passive_proc(void);

#endif // CELL_BALANCE_H

