/**
 * @file     sofar_inner_can_manage.h
 * @brief    公司自定义CAN协议拓展帧SDK接口
 * @author   liulvcong
 * @note     无
 * @version  V1.0
 * @date     2023/2/3
 */
#ifndef __SOFAR_INNER_CAN_MANAGE_H__
#define __SOFAR_INNER_CAN_MANAGE_H__

#include "sofar_can_manage_public.h"

#define BCU_INNER_CAN_ADDR      0x01

/***********  需要应用按实际情况修改的内容 start  ***********/
// can功能吗
typedef enum{
    // 主动上报给逆变器（外can）
    FUNC_BRO_BCU_REQ_CTL_STATE        = 0x30F,  // BMS上发的系统强制充电、停机的控制帧
    FUNC_BRO_BCU_CHG_DSG_LIMIT        = 0x351,  // BMS上发充放电管理帧
    FUNC_BRO_BCU_HEAT_PARA            = 0x352,  // BMS上发控制状态（加热膜）
    FUNC_BRO_BCU_SOX_CAP              = 0x355,  // BMS上发系统容量相关信息帧
    FUNC_BRO_BCU_INFO1                = 0x357,  // 电池簇上报电压、电流、温度等信息,与二层的0x1356对应
    FUNC_BRO_BCU_INFO2                = 0x358,  // 电池簇功率、母线电压(直采)，电芯平均温度
    FUNC_BRO_BCU_VER_INFO             = 0x359,  // BMS上电池组基本信息帧
    FUNC_BRO_BCU_FAULT_INFO1          = 0x35A,  // BMS上发的系统Protect帧
    FUNC_BRO_BCU_FAULT_INFO2          = 0x35C,  // 新增告警
    FUNC_BRO_BCU_FAULT_INFO3          = 0x35D,  // 预留告警
    FUNC_BRO_BCU_MANU_NAME            = 0x35E,  // BMS上发PACK厂家信息帧
    FUNC_BRO_BCU_BAT_TYPE             = 0x35F,  // BMS上发电池类型、软件版本、设计容量、厂商ID信息帧
    // 逆变器控制信息（外can）
    FUNC_INV_CTL_INFO1                = 0x506,  // 逆变器控制充放电
    FUNC_INV_CTL_INFO2                = 0x507,  // 逆变器允许加热膜启动标志
    // 逆变器与BCU（外can）
    FUNC_INV_HEART_BEAT               = 0x305,  // 逆变器与BMS心跳
    FUNC_INV_QUERY_BMU_REAL_DATA      = 0x605,  // EMS查询查询PACK实时信息
    FUNC_INV_QUERY_BMU_DEV_DATA       = 0x606,  // 逆变器查询储能系统配置信息
    FUNC_INV_QUERY_BCU_REAL_DATA      = 0x607,  // EMS查询查询BCU实时信息
    FUNC_INV_QUERY_BMU_HIST_DATA      = 0x705,  // EMS查询查询BMU历史信息
    FUNC_INV_QUERY_BCU_HIST_DATA      = 0x706,  // EMS查询查询BCU历史信息
    // bcu设置以及bmu回复（内can）
    FUNC_MASTER_CTL_CMD               = 0x001,  // BMS控制信息1-编址
    FUNC_ATE_PASS_BAL_CMD             = 0x01E,  // 设置均衡状态
    FUNC_MASTER_CURR_SET_CMD          = 0x060,  // BMS控制信息3-设置状态参数/电流
    FUNC_MASTER_BAL_SET_CMD           = 0x061,  // BMS控制信息4-均衡设置
    FUNC_HEART_BEAT_CMD               = 0x062,  // 心跳帧
    FUNC_MASTER_DSG_CALI_SET_CMD      = 0x064,  // BMS控制信息6-放电末端校准/被动均衡
    FUNC_ATE_SOX_SET                  = 0x025,  // SOX参数标定
    FUNC_ATE_SYS_TIME_SET             = 0x026,  // 时间标定  
    FUNC_ATE_MONITOR_DATA_READ        = 0x02C,  // 上位机监控读取
    FUNC_ATE_PACK_SN_SET              = 0x027,  // PACK_SN标定
    FUNC_ATE_BOARD_SN_SET             = 0x028,  // BOARD_SN标定
    // ate设置告警（内can）
    FUNC_GET_BMU_THRE_ALARM_VAL       = 0x02E,  // 读取bmu告警阈值
    FUNC_CELL_VOLT_OVER_ALM_SET       = 0x010,  // 单体过充故障参数设置
    FUNC_BAT_VOLT_OVER_ALM_SET        = 0x011,  // 总体过充故障参数设置
    FUNC_CELL_VOLT_UNDER_ALM_SET      = 0x012,  // 单体过放故障参数设置
    FUNC_BAT_VOLT_UNDER_ALM_SET       = 0x013,  // 总体过放故障参数设置
    FUNC_CELL_TEMP_OVER_ALM_SET       = 0x016,  // 电芯高温故障参数设置
    FUNC_CELL_TEMP_UNDER_ALM_SET      = 0x017,  // 电芯低温故障参数设置
    FUNC_CELL_VOLT_TIP_SET            = 0x080,  // 单体电压过充、过放提示标定
    FUNC_CELL_VOLT_DIFF_1_SET         = 0x081,  // 单体电压压差过大提示、告警标定
    FUNC_CELL_VOLT_DIFF_2_SET         = 0x082,  // 单体电压压差过大故障标定
    FUNC_CELL_TEMP_TIP_SET            = 0x083,  // 电芯温度充放电高低温提示标定
    FUNC_CELL_TEMP_DIFF_SET           = 0x084,  // 电芯温差过大提示，告警、保护标定
    FUNC_BATT_VOLT_TIP_SET            = 0x085,  // 总压过压欠压提示标定
    // BMU数据回复帧（内can）
    FUNC_SLAVER_CTL_REPLY             = 0x002,  // BMS回复信息2 
    FUNC_BMS_INTER_INFO2              = 0x004,  // BMS发送电池信息2
    FUNC_BMS_INTER_INFO3              = 0x005,  // BMS发送电池信息3
    FUNC_BMS_INTER_INFO4              = 0x006,  // BMS发送电池信息4
    FUNC_BMS_INTER_INFO5              = 0x007,  // BMS发送电池信息5
    FUNC_BMS_FAULT_INFO1              = 0x008,  // BMS发送内部电池故障信息1
    FUNC_BMS_CELL_OTHER_INFO1         = 0x00E,  // 其他信息
    FUNC_BMS_INTER_INFO6              = 0x00F,  // BMS发送电池信息6
    FUNC_BMS_INTER_INFO7              = 0x040,  // BMS发送电池信息7
    FUNC_BAL_TEMP_INFO1               = 0x041,  // BMS均衡温度1-2
    FUNC_POWER_MOS_TEMP_INFO          = 0x04A,  // BMS功率端子温度
    FUNC_BMS_FAULT_INFO2              = 0x045,  // BMS发送内部电池故障信息2
    FUNC_BMS_FAULT_INFO3              = 0x04B,  // BMS发送内部电池故障信息3
    FUNC_BMS_DSG_CALI_INFO            = 0x04C,  // BMS发送放电末端校准信息
    FUNC_BMS_REMOTE_SIGNAL_INFO1      = 0x046,  // 遥信数据上报1
    FUNC_BMS_REMOTE_SIGNAL_INFO2      = 0x047,  // 遥信数据上报2
    FUNC_ACT_BAL_INFO1                = 0x048,  // 主动均衡数据上报1
    FUNC_ACT_BAL_INFO2                = 0x049,  // 主动均衡数据上报2
    FUNC_SOFT_VER_INFO1               = 0x06A,  // 设备软件版信息1
    FUNC_SOFT_VER_INFO2               = 0x06B,  // 设备软件版信息2
    FUNC_SOFT_VER_INFO3               = 0x06C,  // 设备软件版信息3
    FUNC_BMS_REMOTE_SIGNAL_INFO3      = 0x06D,  // 其他数据上报
    FUNC_CELL_VOLT_OVERFLOW           = 0x070,  // 电芯电压
    FUNC_CELL_TEMP_OVERFLOW           = 0x071,  // 电芯温度
    FUNC_CELL_PASS_BAL_STATE_OVERFLOW = 0x072,  // 电芯被动均衡状态
    FUNC_CELL_SOC_INFO                = 0x0A0,  // 单电芯SOC
    FUNC_CELL_SOH_INFO                = 0x0A1,  // 单电芯SOH
    // bmu数据上报 (为了兼容0x670-0x674是发的BCU的数据---外can)
    FUNC_RD_BMU_SOC1_7                = 0x22B, // BMS回复的单个PACK时实信息帧——单电芯SOC1-7
    FUNC_RD_BMU_SOC8_14               = 0x22C, // BMS回复的单个PACK时实信息帧——单电芯SOC8-14
    FUNC_RD_BMU_SOC15_21              = 0x22D, // BMS回复的单个PACK时实信息帧——单电芯SOC15-21
    FUNC_RD_BMU_SOH1_7                = 0x237, // BMS回复的单个PACK时实信息帧——单电芯SOH 1-7
    FUNC_RD_BMU_SOH8_14               = 0x238, // BMS回复的单个PACK时实信息帧——单电芯SOH 8-14
    FUNC_RD_BMU_SOH15_21              = 0x239, // BMS回复的单个PACK时实信息帧——单电芯SOH 15-21
    FUNC_RD_SYS_TIME                  = 0x670, // BMS回复的单个PACK(两层)/单电池包簇(三层)时实信息帧——时间戳和电流值
    FUNC_RD_SYS_SN_INFO1              = 0x671, // BMS回复的单个PACK(两层)/单电池包簇(三层)时实信息帧——20位成品序列号
    FUNC_RD_SYS_SN_INFO2              = 0x672, // BMS回复的单个PACK(两层)/单电池包簇(三层)时实信息帧——20位成品序列号
    FUNC_RD_SYS_SN_INFO3              = 0x673, // BMS回复的单个PACK(两层)/单电池包簇(三层)时实信息帧——20位成品序列号
    FUNC_RD_BMU_CELL_V1_3             = 0x680, // BMS回复的单个PACK时实信息帧——电池单体电压1-3
    FUNC_RD_BMU_CELL_V4_6             = 0x681, // BMS回复的单个PACK时实信息帧——电池单体电压4-6
    FUNC_RD_BMU_CELL_V7_9             = 0x682, // BMS回复的单个PACK时实信息帧——电池单体电压7-9
    FUNC_RD_BMU_CELL_V10_12           = 0x683, // BMS回复的单个PACK时实信息帧——电池单体电压10-12
    FUNC_RD_BMU_CELL_V13_15           = 0x684, // BMS回复的单个PACK时实信息帧——电池单体电压13-15
    FUNC_RD_BMU_CELL_V16              = 0x685, // BMS回复的单个PACK时实信息帧——电池单体电压16/最高 / 最低单体电压
    FUNC_RD_BMU_CELL_V_MAX_MIN_ID     = 0x686,     // BMS回复的单个PACK时实信息帧——最高 / 最低单体电压编号
    FUNC_RD_BMU_CELL_TEMP1_2          = 0x690, // BMS回复的单个PACK时实信息帧——电池温度1-2
    FUNC_RD_BMU_CELL_TEMP3_4          = 0x691, // BMS回复的单个PACK时实信息帧——电池温度3-4
    FUNC_RD_BMU_CELL_TEMP5_6          = 0x692, // BMS回复的单个PACK时实信息帧——电池温度5-6
    FUNC_RD_BMU_CELL_TEMP7_8          = 0x693, // BMS回复的单个PACK时实信息帧——电池温度7-8
    FUNC_RD_BMU_CELL_TEMP_MAX_MIN     = 0x694,     // BMS回复的单个PACK时实信息帧——最高 / 最低单体温度和编号
    FUNC_RD_SYS_MOS_TEMP              = 0x6A0, // BMS回复的单个PACK时实信息帧——MOS管温度和PACK内部环境温度/ BCU回复实时信息帧-电池簇的相关温度
    FUNC_RD_BMU_POWER_TEMP            = 0x6A1, // BMS回复的单个PACK时实信息帧-功率端子温度和保留位
    FUNC_RD_SYS_INFO1                 = 0x6B0, // BMS回复的单个PACK时实信息帧——PACK实时容量与循环次数 / BCU回复实时信息帧- 绝缘阻抗阻值+主动均衡状态
    FUNC_RD_SYS_INFO2                 = 0x6B1, // BMS回复的单个PACK时实信息帧-设备软件版信息2 锂电类型等 / BCU回复实时信息帧——簇最高最低单体电压和packId
    FUNC_RD_SYS_INFO3                 = 0x6B2, // BMS回复的单个PACK时实信息帧-设备软件版信息3 厂家信息   / BCU回复实时信息帧——簇最高最低单体温度和packId
    FUNC_RD_SYS_INFO4                 = 0x6B3, // BMS回复的单个PACK时实信息帧-设备软件版信息4 厂家信息   / BCU回复实时信息帧-BCU其他状态
    FUNC_RD_BMU_CHG_DSG_STATE         = 0x6B4, // BMS回复的单个PACK时实信息帧-电芯数据1 充放电使能，状态，充放电限流值
    FUNC_RD_BMU_BAL_DATA              = 0x6B5, // BMS回复的单个PACK时实信息帧-均衡数据3 均衡电流、电压等
    FUNC_RD_BMU_FAULT_INFO1           = 0x6C0, // BMS回复的单个PACK时实信息帧——PACK实时状态信息
    FUNC_RD_BMU_FAULT_INFO2           = 0x6C1, // BMS回复的单个MODULE时实WARNS帧
    FUNC_RD_BMU_DSG_CAP_WH            = 0x6D0, // BMS回复的单个PACK时实信息帧——PACK累积放电量Wh
    FUNC_RD_BMU_APP_VER               = 0x6D1, // BMS回复的单个PACK时实信息帧——PACK软件版本号
    FUNC_RD_BMU_VOLT_SOX              = 0x6D2, // BMS回复的单个PACK时实信息帧——PACK总压、SOC、SOH
    FUNC_RD_BMU_CHG_CAP_AH            = 0x6D4, // BMS回复的单个PACK时实信息帧——PACK累积充电量AH
    FUNC_RD_BMU_DSG_CAP_AH            = 0x6D5, // BMS回复的单个PACK时实信息帧——PACK累积放电容量AH
    FUNC_RD_BMU_CHG_CAP_WH            = 0x6D6, // BMS回复的单个PACK时实信息帧——PACK累积充电量WH
    // ate设置告警（外can）
    FUNC_ATE_CALI_CLU_OVER_H          = 0x0E0,  // 单簇过压故障参数标定    
    FUNC_ATE_CALI_CLU_OVER_L          = 0x0E1,  // 单簇过放故障参数标定    
    FUNC_ATE_CALI_CLU_CHG_CURR_H      = 0x0E2,  // 单簇充电过流故障参数标定    
    FUNC_ATE_CALI_CLU_DSG_CURR_H      = 0x0E3,  // 单簇放电过流故障参数标定    
    FUNC_ATE_CALI_CLU_CHG_DSG_CURR_H2 = 0x0E4,  // 单簇充放电2级故障参数标定    
    FUNC_ATE_CALI_CLU_SOC_L           = 0x0E5,  // 低电量故障参数标定      
    // ate设置其他控制和标定（外can）
    FUNC_ATE_FLASH_TEST               = 0x0EF,  // ATE_FLASH测试           
    FUNC_ATE_MODE_CTL                 = 0x0F0,  // 上位机控制老化状态
    FUNC_ATE_CALI_CHG_VOLT_PACK_NUM   = 0x0F1,  // 风扇启动，满充电压，pack个数参数标定      
    FUNC_ATE_CALI_TIME                = 0x0F2,  // 时间标定                
    FUNC_ATE_SET_PACK_SN              = 0x0F3,  // PACK_SN标定             
    FUNC_ATE_SET_BOARD_SN             = 0x0F4,  // BOARD_SN标定            
    FUNC_ATE_CALI_PARA                = 0x0F5,  // 校准系数标定            
    FUNC_ATE_BCU_FUNC_SW_CTL          = 0x0F6,  // BCU功能开关             
    FUNC_ATE_MONITOR_RD               = 0x0F7,  // 上位机监控读取          
    FUNC_ATE_CLEAR_HISTORY_DATA       = 0x0F8,  // 一键读取历史故障        
    FUNC_ATE_CALI_PARA_CTL            = 0x0F9,  // 一键操作标定参数        
    FUNC_ATE_FORCE_CTL                = 0x0FA,  // ATE强制控制指令     
    // BCU 内网控制功能码（外can）
    FUNC_BCU_SELF_CTL                 = 0x0B0, // BCU控制信息1 
    FUNC_BCU_SELF_REPLAY              = 0x0B1, // BCU回复信息2
    // BCU 内网数据查询（外can）
    FUNC_BCU_SELF_STATE               = 0x0B6, // BCU遥信数据上报1--输入电平、均衡状态、继电器状态、其他状态
    FUNC_BCU_SELF_TEMP                = 0x0B7, // BCU遥信数据上报2--温度
    FUNC_BCU_SELF_VOLT1               = 0x0B8, // BCU遥信数据上报3--相关电压
    FUNC_BCU_SELF_CURR                = 0x0B9, // BCU遥信数据上报4--相关电流
    FUNC_BCU_SELF_CLU_MIN_MAX_VOLT    = 0x0BA, // BCU遥信数据上报5--单簇最高电芯电压，最低电芯电压
    FUNC_BCU_SELF_CLU_MIN_MAX_TEMP    = 0x0BB, // BCU遥信数据上报6--单簇最高最低温度
    FUNC_BCU_SELF_CHG_DSG_LIMIT       = 0x0BC, // BCU遥信数据--簇充放电限流限压值
    FUNC_BCU_SELF_VER                 = 0x0BD, // BCU版本号信息
    FUNC_BCU_SELF_CAP                 = 0x0BE, // BCU遥信数据--簇容量信息
    FUNC_BCU_SELF_STATE_SOX           = 0x0BF, // BCU遥信数据--簇基本信息
    FUNC_BCU_SELF_TIME                = 0x0C0, // BCU系统时间
    FUNC_BCU_SELF_OTHER_DATA          = 0x0C1, // 0x0C1:BCU遥测数据上报3---其他遥测信息
    FUNC_BCU_SELF_VAL_RESULT          = 0x0C2, // 0x0C2:测试结果/其他参数(一般用于ate测试)
    FUNC_BCU_SELF_FAULT_INFO1         = 0x0C3, // bcu内网故障1
    FUNC_BCU_SELF_FAULT_INFO2         = 0x0C4, // bcu内网故障2--预留
    FUNC_BMU_SELF_FAULT_INFO1         = 0x0C5, // 故障上报--参考0x008
    FUNC_BMU_SELF_FAULT_INFO2         = 0x0C6, // 故障上报--参考0x045
    // 历史数据上报 外can (BCU/BMU共用)
    FUNC_RD_HIST_SYS_TIME             = 0x770,  // BMU/BCU回复的历史故障数据帧——发生故障时的时间戳和电流值+系统装填
    FUNC_RD_HIST_SYS_SN_INFO1         = 0x771,  // BMU/BCU回复的历史故障数据帧——20位成品序列号
    FUNC_RD_HIST_SYS_SN_INFO2         = 0x772,  // BMU/BCU回复的历史故障数据帧——20位成品序列号
    FUNC_RD_HIST_SYS_SN_INFO3         = 0x773,  // BMU/BCU回复的历史故障数据帧——20位成品序列号
    FUNC_RD_HIST_SYS_VOLT_INFO1       = 0x780,  // BMU回复的历史故障数据帧——发生故障时的电池单体电压 / BCU回复的历史故障数据帧——最大最小电芯电压和对应PACKID
    FUNC_RD_HIST_SYS_VOLT_INFO2       = 0x781,  // BMU回复的历史故障数据帧——发生故障时的电池单体电压 / BCU回复的历史故障数据帧——簇电压
    FUNC_RD_HIST_SYS_VOLT_INFO3       = 0x782,  // BMU回复的历史故障数据帧——发生故障时的电池单体电压 / BCU回复的历史故障数据帧——充放电电压上下限
    FUNC_RD_HIST_SYS_VOLT_INFO4       = 0x783,  // BMU回复的历史故障数据帧——发生故障时的电池单体电压 / BCU回复的历史故障数据帧——放电电流上下限
    FUNC_RD_HIST_SYS_VOLT_INFO5       = 0x784,  // BMU回复的历史故障数据帧——发生故障时的电池单体电压 / BCU回复的历史故障数据帧——系统状态
    FUNC_RD_HIST_SYS_VOLT_INFO6       = 0x785,  // BMU回复的历史故障数据帧——发生故障时的电池单体电压 / BCU回复的历史故障数据帧——绝缘阻抗和主动均衡状态
    FUNC_RD_HIST_SYS_TEMP_INFO1       = 0x790,  // BMU回复的历史故障数据帧——发生故障时的电池温度+最大电芯温度 / BCU回复的历史故障数据帧——最高最低电芯温度和对应ID
    FUNC_RD_HIST_SYS_ENV_TEMP         = 0x7A0,  // BMU回复的历史故障数据帧——发生故障时的MOS管温度和PACK内部环境温度 / BCU回复的历史故障数据帧——发生故障时的MOS管温度和BCU内部环境温度
    FUNC_RD_HIST_SYS_CAP_INFO1        = 0x7B0,  // BMU回复的历史故障数据帧——发生故障时剩余容量，满充容量，总电压 / BCU回复的历史故障数据帧——发生故障时剩余容量，满充容量，sox
    FUNC_RD_HIST_SYS_FAULT_INFO1      = 0x7C0,  // BMU回复的历史故障数据帧——发生故障时的PACK发生故障时的状态信息 / BCU回复的历史故障数据帧——发生故障时的系统发生故障时的状态信息
    FUNC_RD_HIST_SYS_FAULT_INFO2      = 0x7C1,  // BMU回复的历史故障数据帧2——发生故障时的PACK发生故障时的状态信息 / BCU回复的历史故障数据帧2——发生故障时的系统发生故障时的状态信息
    // 文件读取（内/外can）
    FUNC_UP_FILE_START                = 0x7F0, // 读取文件传输开始帧
    FUNC_UP_FILE_DATA_BLOCK_START     = 0x7F1, // 读取数据块开始帧
    FUNC_UP_FILE_DATA_TRAN            = 0x7F2, // 读取数据块数据帧
    FUNC_UP_FILE_DATA_BLOCK_CRC       = 0x7F3, // 读取文件接收结果查询帧
    FUNC_UP_FILE_FINISH_QUERY         = 0x7F4,  //读取文件完成状态查询帧
    // 升级信息（内/外can）
    FUNC_DOWN_FILE_TIME               = 0x7FA, // 升级文件定时升级
    FUNC_DOWN_FILE_START              = 0x7FB, // 升级文件传输开始帧
    FUNC_DOWN_FILE_DATA_BLOCK_START   = 0x7FC, // 升级数据块开始帧
    FUNC_DOWN_FILE_DATA_TRAN          = 0x7FD, // 升级数据块数据帧
    FUNC_DOWN_FILE_RESULT_CHECK       = 0x7FE, // 升级文件接收结果查询帧
    FUNC_DOWN_FILE_FINISH_QUERY       = 0x7FF, // 升级完成状态查询帧
}frame_fun_e;

//  ate接收帧id
typedef enum
{    
    // ate设置其他控制和标定（外can）
    EXT_CAN_TX_ATE_FLASH_TEST               ,  // 0x0EF：ATE_FLASH测试
    EXT_CAN_TX_ATE_MODE_CTL                 ,  // 0x0F0：上位机控制老化状态
    EXT_CAN_TX_ATE_CALI_TIME                ,  // 0x0F2：时间标定
    EXT_CAN_TX_ATE_SET_PACK_SN              ,  // 0x0F3：PACK_SN标定
    EXT_CAN_TX_ATE_SET_BOARD_SN             ,  // 0x0F4：BOARD_SN标定
    EXT_CAN_TX_ATE_BCU_FUNC_SW_CTL          ,  // 0x0F6：BCU功能开关
    EXT_CAN_TX_ATE_CALI_PARA_CTL            ,  // 0x0F9：一键操作标定参数
    EXT_CAN_TX_ATE_FORCE_CTL                ,  // 0x0FA：ATE强制控制指令
    // BCU 内网数据查询（外can）
    EXT_CAN_TX_BCU_SELF_STATE               , // 0x0B6: BCU遥信数据上报1--状态信息
    EXT_CAN_TX_BCU_SELF_TEMP                , // 0x0B7: BCU遥信数据上报2--BCU温度信息
    EXT_CAN_TX_BCU_SELF_VOLT1               , // 0x0B8: BCU遥信数据上报3--相关电压
    EXT_CAN_TX_BCU_SELF_CURR                , // 0x0B9: BCU遥信数据上报4--相关电流采样
    EXT_CAN_TX_BCU_SELF_VER                 , // 0x0BD: BCU版本号信息
    EXT_CAN_TX_BCU_SELF_TIME                , // 0x0C0: BCU系统时间
    EXT_CAN_TX_BCU_SELF_OTHER_DATA          , // 0x0C1: BCU其他数据-绝缘阻抗值
    EXT_CAN_TX_BCU_SELF_VAL_RESULT          , // 0x0C2: 模拟量与测试结果2(一般用于ate测试)
    EXT_CAN_TX_FRAME_NUM,
} eate_group_e;

/***********  需要应用按实际情况修改的内容  end  ***********/

/**
* @brief		初始化内can管理
* @param		无
* @return		返回结果
* @retval		0：成功    < 0: 失败
* @warning		无 
*/
int32_t inner_can_sofar_manage_init(void);

/**
* @brief		读取内can硬件缓冲区数据，1ms周期轮询
* @param		无
* @return		返回结果
* @retval		0：添加成功    < 0: 添加失败
* @warning		无 
*/
int32_t inner_can_sofar_rcv_frame_proc(void);

/**
* @brief		注册can接收回调函数
* @param		[in] urgent_flag:紧急处理标志  GENERAL_FRAME:接收到数据正常响应速度10ms ，URGENT_FRAME:接收数据快速响应1ms
* @param		[in] p_can_rec_reg ：
* @param		[in] id：can帧id 
* @param		[in] id：id_mask：过滤不需要接收的位(标准帧的掩码mask固定为0x00000000,拓展帧的掩码mask目标地址设置为FF代表能接收0xFF,0x1F,pack_addr三种类型地址)
* @param		[in] id：can_cb：回调解析函数 
* @param		[in] reg_cnt：注册的数量 
* @return		返回结果
* @retval		0：注册成功    < 0: 注册失败
* @warning		禁止重复注册同一个ID
* @warning		标准帧注册掩码必须为0x00000000
* @warning		掩码不可为0xFFFFFFFF
*/
int32_t inner_can_sofar_register_receive_frame(can_sofar_rcv_reg_t *p_can_rec_reg, uint16_t reg_cnt);
#endif
