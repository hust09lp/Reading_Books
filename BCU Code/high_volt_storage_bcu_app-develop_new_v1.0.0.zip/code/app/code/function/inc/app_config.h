#ifndef __APP_CONFIG_H__
#define __APP_CONFIG_H__

/* ------------------------------------------------------------------------- */

/* ------------------------------------------------------------------------- */

#define DEBUG_COMMUT_WITH_PCS 0



// 从机接收主机控制命令超时阀值
#define PARALLEL_CRTL_CMD_OVER_TIME 2000 // ms

#endif
