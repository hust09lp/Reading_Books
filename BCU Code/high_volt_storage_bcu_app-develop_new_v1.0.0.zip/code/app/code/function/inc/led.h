#ifndef __LED_MANAGE_H__
#define __LED_MANAGE_H__

#include "sdk.h"
#include "sdk_led.h"

#define LED_CTL_SHELL_DEBUG_FALG 1

typedef enum
{
    POWER_ON_LED = 0,
    USER_NOR_LED,
    USER_ERR_LED,
    LED_NUM,
} led_type_e;

typedef enum
{
    LED_INIT_STATE = 0,
    LED_STATE_FAULT,         ///< 故障状态
    LED_STATE_DI_1,          ///< BMS 系统有电，主接触器未闭合
    LED_STATE_DI_2,          ///< BMS系统有电，主接触器闭合，手动开关 SF1(原QB2)闭合，提示可关手动开关SF1(原QB2)
    LED_STATE_DI_3,          ///< 主接触器闭合，手动开关 SF1(原QB2)断开
    LED_STATE_STATE_TYPE_NUM,
} led_display_state_e;

typedef enum
{
    LED_DISPLAY_MODE_1 = 0,              ///< 闪1模式:亮0.25s,灭3.75s
    LED_DISPLAY_MODE_2,                  ///< 闪2模式:亮0.5s,灭0.5s
    LED_DISPLAY_MODE_3,                  ///< 闪3模式:亮1s,灭1s
    LED_DISPLAY_MODE_4,                  ///< 闪4模式:亮0.2s,灭0.2s
    LED_DISPLAY_MODE_ALWAYS_ON,          ///< 常亮模式
    LED_DISPLAY_MODE_ALWAYS_CLOSE,       ///< 常灭模式
    LED_DISPLAY_MODE_WATER_FALL,         ///< 流水灯模式
    LED_DISPLAY_MODE_REVERSE_WATER_FALL, ///< 反方向流水灯模式
    LED_DISPLAY_MODE_TYPE,
} led_display_mode_e;

/**
 * @brief        ate LED逻辑禁止/使能控制
 * @param        [in] disable_flag     true:屏蔽LED逻辑/false:LED逻辑正常
 * @warning       一般只有ate测试才会调用，其他模块慎用
 */
void led_display_func_disable(bool disable_flag);

/**
 * @brief        LED逻辑屏蔽标志获取
 * @param        void
 * @return        执行结果
 * @retval        true: 屏蔽led逻辑，false:正常使用led逻辑
 */
bool led_display_func_disable_flag_get(void);

/**
 * @brief        开机时LED的闪烁设置， RUN亮，ALM灭，SOC流水灯闪烁
 * @return       执行结果
 * @retval       无返回值
 * @pre          无前置条件
 * @warning      无警告
 */
void led_display_mode(uint8_t led_type, uint8_t display_mode_type);

uint8_t get_led_display_mode(void);

// led灯初始化函数
void led_init(void);

// led灯管理函数
void led_manage(void);

#endif
