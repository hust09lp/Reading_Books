/**
 * @file     insulation_impedance_calc.h
 * @brief    绝缘阻抗检测接口
 * @author   liulvcong
 * @note     无
 * @version  V1.0
 * @date     2023/5/4
 */
#ifndef __INSULATION_IMPEDANCE_CALC_H__
#define __INSULATION_IMPEDANCE_CALC_H__

#include <stdint.h>

#define APP_BCU_SIP_TEST   // test

#define SIR_OK        (0)
#define SIR_INVALID (0xFFFFFFFF)

typedef enum
{
    INSULATION_IMPEDANCE_IDLE = 0,
    INSULATION_IMPEDANCE_CHECKING,        // 绝缘阻抗检测中
    INSULATION_IMPEDANCE_ABNORMAL,        // 绝缘阻抗检测异常
    INSULATION_IMPEDANCE_NORMAL,          // 绝缘阻抗检测正常
    INSULATION_IMPEDANCE_NORMAL_OVERTIME, // 绝缘阻抗检测正常超时标志
    INSULATION_IMPEDANCE_OVERTIME,        // 绝缘阻抗检测超时
    INSULATION_IMPEDANCE_DISABLE,         // 绝缘阻抗异常屏蔽
} insulation_impedance_check_result_e;


/**
 * @brief       绝缘阻抗检测初始化
 * @param       无
 * @return      返回结果
 * @warning     无 
 */
void insulation_impedance_calc_init(void);

/**
 * @brief   启动绝缘阻抗检测
 * @param   [in] void
 * @note    调用此函数之前需要已经完成初始化
 * @return  返回执行结果 0:正常；<0:异常
 * @warning 单次测试，结果可通过insulation_impedance_check_result_get()获取
 */
int32_t insulation_impedance_calc_start(void);

/**
 * @brief   获取绝缘阻抗检测状态
 * @param   [in] void
 * @param   [out] void
 * @return  返回执行结果 参考insulation_impedance_check_result_e
 */
int32_t insulation_impedance_check_result_get(void);

/** 
 * @brief        获取绝缘阻抗阻值(单位kΩ)
 * @param        [out] void
 * @return       [uint32_t] 执行结果
 * @retval       0xFFFFFFFF 无效值
 */
uint32_t insulation_impedance_value_get(void);

/** 
 * @brief        绝缘阻抗检测管理
 * @param        [int] void
 * @return       [out] void
 * @retval       周期100ms任务
 */
void insulation_impedance_calc_proc(void);

/** 
 * @brief        设置绝缘阻抗检测功能
 * @param        [in]insulation_func_enable_state_e  1：启动，2：关闭
 * @return       [int32_t] 执行结果
 * @retval       =0  设置成功 
 * @retval       < 0 失败原因
 */
int32_t insulation_impedance_func_enable_set(uint8_t flag);

/** 
 * @brief        获取绝缘阻抗检测功能标志
 * @return       [uint8_t] 执行结果
 */
uint8_t insulation_impedance_func_enable_get(void);

#endif
