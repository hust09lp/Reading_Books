/*!*************************************************************
* @file			state_machine.h
* @brief		fsm状态机模块头文件
* @details 		该文件包含数据类型定义、fsm状态机中用到的结构定义和接口函数
* @attention 	请慎重修改本文件中的内容！
* @date 		2024-05-10
* @copyright	刘遥
***************************************************************/
#ifndef STATE_MACHINE_H
#define STATE_MACHINE_H

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdint.h>
//---------------------------------------------------------------------------
// Define Description
//---------------------------------------------------------------------------
#define EVT_NULL              0xFF
#define STA_NULL              0xFF

//---------------------------------------------------------------------------
// Structure Definition
//---------------------------------------------------------------------------
typedef uint8_t (*fsm_state_action)(void);

typedef struct
{
    fsm_state_action    enter_act;	
    fsm_state_action    running_act;	
}fsm_action_map_t; /* 动作action表描述 */

typedef struct
{
    const char* name;
    uint8_t flag;  /* 状态切换标志位,1表示要进行状态切换 */
    uint8_t cur_state;
    uint8_t next_state;
    uint8_t state_num;
    uint8_t event_num;
    fsm_action_map_t *p_action_map;
    uint8_t *p_event_map;
}state_machine_t; /* 状态机控制结构 */

//---------------------------------------------------------------------------
// Function Declarations
//---------------------------------------------------------------------------
void state_machine_init(state_machine_t* p_fsm, const char* name, fsm_action_map_t* p_action_map, uint8_t* p_event_map,
    uint8_t event_num, uint8_t state_num, uint8_t cur_state);
void fsm_state_trans(state_machine_t* p_fsm, uint8_t event);
uint8_t state_machine_proc(state_machine_t* p_fsm);
		
#ifdef __cplusplus
}
#endif	

#endif /* PI_I_CTRL_F_H_ */
