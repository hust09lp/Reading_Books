#ifndef __FAN_CTRL_H__
#define __FAN_CTRL_H__
#include <stdint.h>
#include <stddef.h>
#include "sdk_dido.h"

#define FAN_CTRL_TIME_5S    500

#define FAN_ON()      sdk_dido_write(DO_11_FAN_CTRL,1)
#define FAN_OFF()     sdk_dido_write(DO_11_FAN_CTRL,0)
/**
* @brief		风扇控制初始化函数
* @param		无  
* @return		返回结果
* @retval		0：正常  <0:异常
* @warning		无
*/
int32_t fan_ctrl_init(void);

/**
* @brief		风扇控制函数处理
* @param		无  
* @return		无
* @warning		无
*/
void fan_ctrl_proc(void);


uint8_t get_fan_flag(void);
///**
// * @brief        风扇调试接口
// * @param        [in] cmd
// * @param        [in] len
// * @return       返回结果
// * @retval    SF_OK(0) 成功
// * @retval    HAL_EIO(<0) 失败
// */
//int32_t shell_fan_test_proc(char *cmd, uint8_t len);
#endif
