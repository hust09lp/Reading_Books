#ifndef __SOFAR_CAN_DATA_H__
#define __SOFAR_CAN_DATA_H__

#include <stdint.h>
#include <stddef.h>
#include "sofar_can_manage.h"

typedef struct 
{
	uint8_t  				msg_type;   	/*CAN_MSG_EVENT_TYPE / CAN_MSG_CYCLE_TYPE */
	uint16_t    			send_period; 	/*发送周期，只有在CYCLE_TYPE才有效 */
    uint16_t                period_cnt;     // 周期计数，只有在CYCLE_TYPE才有效
    uint8_t                 event;          // event=1有事件发送，只有在CAN_MSG_EVENT_TYPE才有效
    uint8_t                 first_flag;
    uint16_t                data_len;       // 
	int32_t       			(*canmsg_routine)(uint8_t *p_data, uint8_t len, uint16_t start_addr);
    uint8_t                 event_type;           // 用于是被触发式的标识 内can参考send_inner_can_event_type，外can参考：send_ext_can_event_type
}send_msg_info_t;

#define	CAN_MSG_EVENT_TYPE  	((uint8_t)0x01)
#define	CAN_MSG_CYCLE_TYPE  	((uint8_t)0x02)
#define CYCLE_BASE_TIME_MS      10
#define	CYCLE_SEND_500MS		(500 / CYCLE_BASE_TIME_MS)
#define	CYCLE_SEND_10MS		    (10 / CYCLE_BASE_TIME_MS)
#define	CYCLE_SEND_1000MS		(1000 / CYCLE_BASE_TIME_MS)
#define	CYCLE_SEND_1200MS		(1200 / CYCLE_BASE_TIME_MS)
#define	CYCLE_SEND_2000MS		(2000 / CYCLE_BASE_TIME_MS)
#define	CYCLE_SEND_5000MS		(5000 / CYCLE_BASE_TIME_MS)
#define	CYCLE_SEND_5MIN		    (300 * 1000 / CYCLE_BASE_TIME_MS)
#define	CYCLE_SEND_10MIN		(600 * 1000 / CYCLE_BASE_TIME_MS)

#endif
