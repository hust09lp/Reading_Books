#ifndef __EXT_AUTO_ADDRESSING_H__
#define __EXT_AUTO_ADDRESSING_H__

#include <stdint.h>
#include <stddef.h>
#include "external_can_data.h"
#include "sofar_can_manage.h"
#include "addressing_common.h"

/**
 * @brief  获取自动编址状态
 * @return 自动编址状态
 */
ext_addressing_state_e ext_can_mac_auto_addressing_get_state(void);

/**
 * @brief  获取自动编址故障
 * @return AUTO_ADDRESSING_NO_FAULT     没故障
 * @return AUTO_ADDRESSING_ID_CONFLICT  通讯ID冲突
 * @return AUTO_ADDRESSING_COMM_FAIL    通讯故障
 */
uint8_t ext_can_mac_auto_addressing_fault_get(void);

/**
 * @brief  获取编址地址
 * @retval =0     未完成编址
 * @retval 1~0x0F 有效地址
 */
uint8_t ext_can_mac_auto_addressing_get_address(void);

/**
 * @brief  获取PACK数量
 * @retval 1~N 有效的PACK数量
 * @retval 0 获取失败
 * @pre    只有编址完成后，才能正确获取PACK数量
 */
uint8_t ext_can_mac_auto_addressing_dev_num_get(void);

/**
 * @brief  电池包数目异常标志
 * @retval true 数量异常
 * @retval false 无异常
 * @pre    只有编址完成后，才能判断电池包数量
 */
uint32_t ext_can_mac_addressing_dev_num_abnormal_get(void);

/**
 * @brief   外网CAN(bcu)，自动编址初始化
 * @param   无
 * @return  返回执行结果 0:正常；<0:异常
 * @warning	无
 */
void ext_can_mac_auto_addr_init(void);

/**
 * 自动别编址状态机，10ms调用一次
 */
void ext_can_mac_auto_addressing_proc(void);

/**
 * @brief  使能自动编址
 * @;param [in] 使能外can自动编址开关，1：使能，0:关闭
 * @return 无
 */
void ext_can_mac_auto_addressing_set(uint32_t enable);

/**
 * @brief  获取外can自动编址使能标志
 * @return 无
 */
uint32_t ext_can_mac_auto_addressing_get(void);

/**
 * @brief  获取主从机状态
 * @;param [in] 使能外can自动编址开关，1：使能，0:关闭
 * @return 无
 */
ext_can_mac_type_e ext_can_mac_type_get(void);

/**
 * @brief  清除pcs 3ph失联时间
 * @param  
 * @return 无
 */
void clear_pcs_3ph_comm_unlink_time(void);

/**
 * @brief   外网CAN(bcu)，从机自动编址回复CAN消息处理回调函数
 * @param   无
 * @return  无
 * @warning	无
 */
int32_t ext_can_mac_addr_rcv_callback(can_frame_data_t *frame_data);

/**
 * @brief   外网CAN(bcu)，从机自动编址回复CAN消息处理回调函数
 * @param   无
 * @return  无
 * @warning	无
 */
int32_t ext_addr_common_rcv_callback(can_frame_data_t *frame_data);
#endif
