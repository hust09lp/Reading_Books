#ifndef __FAULT_MANAGE_H__
#define __FAULT_MANAGE_H__

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>


#ifndef SET_BIT
#define SET_BIT(a,b)	((a) |= (b)) 		
#endif

#ifndef CLR_BIT
#define CLR_BIT(a,b)	((a) &= ~(b)) 
#endif

#ifndef GET_BIT
#define GET_BIT(a,b)	((a) & (b))
#endif

#ifndef ITEM_NUM
#define ITEM_NUM(items) sizeof(items) / sizeof(items[0])
#endif


#define FAULT_START				(0x01)		///< 故障启动
#define	FAULT_STOP				(0x00)		///< 故障停止

#define ENABLE					(0x01)		///< 故障使能
#define	DISABLE					(0x00)		///< 故障禁止

#define LEVEL0					(0x00)		///< 充放电等级零 故障：限流，关断MOS，无法恢复
#define LEVEL1					(0x01)		///< 充放电等级一 保护：限流，关断MOS，可恢复
#define	LEVEL2					(0x02)		///< 充放电等级二 告警：限流，不关断MOS，可恢复
#define	LEVEL3					(0x03)		///< 充放电等级三 提示

#define AUTO_CLR				(0x00)  	///< 自动清除
#define	MANUAL_CLR				(0x01)  	///< 手动清除
#define	POFF_CLR				(0x02)  	///< 下电清除

#define FAULT_LED_OFF			(0x00)		///< 故障灯灭
#define	FAULT_LED_ON			(0x01)		///< 故障灯亮
#define FAULT_LED_FLASH_MODE1	(0x02)		///< 故障灯闪烁模式1
#define FAULT_LED_FLASH_MODE2	(0x03)		///< 故障灯闪烁模式2
#define FAULT_LED_FLASH_MODE3	(0x04)		///< 故障灯闪烁模式3

#define VRLID					(0x00)  	///< 有效
#define INVRLID					(0x01)  	///< 失效

#define DEV_NUM                 (8 + 1)     ///< 与设备总数保持一致 PACK_MAX_NUM+1



/**
  * @enum   fault_diag_step_e
  * @brief  诊断流程
  */
typedef enum
{
	DIAG_NONE = 0,							///< 空闲
	POWER_ON_SELF_TEST,					    ///< 开机自检
	DIAG_ON_RUNNING,						///< 运行中诊断
}fault_diag_step_e;

/**
 * @enum   hard_self_det_abn_e
 */
typedef enum
{
    POWER_24V_ABN = 1,                      ///< 24V供电异常
    HALL_5V_ABN = 2,                            ///<  5V供电异常
    RELAY_ABN = 4,                              ///< 继电器异常
} hard_self_det_abn_e;

/**
  * @enum   fault_diag_step_e
  * @brief  诊断流程
  */
typedef enum
{
	DEVICE_ERR_LEVEL   = 0x01,
    PROTECT_LEVEL      = 0x02,
    ALARM_LEVEL        = 0x04,
    TIP_LEVEL          = 0x08,    
}fault_level_e; //主要是给外can发送使用，用于移位

/**
  * @enum   fault_type_e
  * @brief  故障类型
  */
typedef enum
{
	// 单板故障
	BOARD_FAULT_INDEX = 0,									///< 单板故障类索引	                   Hex
	BOARD_POWER_TERMINAL_TEMP_SAM_FAULT = BOARD_FAULT_INDEX,///< 单板：功率端子温度采样异常        00
	BOARD_ENV_TEMP_SAM_ABNORMAL_ALARM,						///< 单板：环境温度采样异常            01
	BOARD_FLASH_INVALID_FAULT,								///< 单板：flash失效故障               02
	BOARD_INNER_CAN_COMM_FAULT,							    ///< 单板：BCU与BMU间CAN通讯故障       03
    BOARD_INNER_CAN_ADDR_REPEAT_FAULT,                      ///< 单板：内can反复编址故障            04
	BOARD_BCU_PCS_CAN_COMM_ABNORMAL_FAULT,					///< 单板：BCU与PCS间CAN通讯异常告警    05
	BOARD_BCU_BCU_CANID_CONFLICT_ALARM,						///< 单板：BCU与BCU间CAN地址冲突告警    06
    BOARD_POWER_TERMINAL_TEMP_OVER_TIPS,					///< 单板：功率端子过温提示             07
    BOARD_POWER_TERMINAL_TEMP_OVER_ALARM,					///< 单板：功率端子过温告警             08
	BOARD_POWER_TERMINAL_TEMP_OVER_PROTECT,					///< 单板：功率端子过温保护             09
	BOARD_POSITIVE_RELAY_ADHESION_FAULT,					///< 单板：正继电器粘连故障             0A
	BOARD_NEGATIVE_RELAY_ADHESION_FAULT,					///< 单板：负继电器粘连故障             0B
    BOARD_AUX_RELAY_ADHESION_FAULT,                         ///< 单板：辅电继电器粘连故障           0C  // 当前没有，后续可替换成别的
    BOARD_INS_RES_VAL_LOW_TIPS,                             ///< 单板：绝缘阻抗过低提示             0D
    BOARD_INS_RES_VAL_LOW_ALARM,                            ///< 单板：绝缘阻抗过低告警             0E
    BOARD_INS_RES_VAL_LOW_PROTECT,                          ///< 单板：绝缘阻抗过低保护             0F
	BOARD_EXT_ADC_FAULT,								    ///< 单板：片外adc采样故障              10
    BOARD_PRE_CHARGE_FAULT,                                 ///< 单板：预充故障                    11
    BOARD_ENV_TEMP_HIGH_TIPS,						        ///< 单板：环境温度过高提示             12
    BOARD_ENV_TEMP_HIGH_ALARM,						        ///< 单板：环境温度过高告警             13
    BOARD_ENV_TEMP_HIGH_PROTECT,						    ///< 单板：环境温度过高保护             14
    BOARD_POWER_VOLT_OVER_TIPS,                             ///< 单板：供电电压过压提示             15
    BOARD_POWER_VOLT_UNDER_TIPS,                            ///< 单板：供电电压欠压提示             16
    BOARD_TRIP_FAULT,                                       ///< 单板：跳机故障                    17
    BOARD_CAN_HALL_SENSOR_FAULT,                            ///< 单板：CAN霍尔传感器故障            18
    BOARD_CAN_HALL_SENSOR_COMM_FAULT,                       ///< 单板：CAN霍尔传感器通讯故障        19
    BOARD_HARD_SELF_DET_FAULT,                              ///< 单板：硬件自检故障                 1A
    BOARD_POWER_OFF_FAULT,                                  ///< 单板：正常下电失败故障             1B
    BOARD_ALL_CLUSTER_POWER_OFF_FAULT,                      ///< 单板：接收到所有簇故障下电          1C
    BOARD_INTER_CLU_CUR_DIFF_OVER_ALARM,                    ///< 单板：簇间电流差异大告警           1D
	BOARD_HALL_CURR_DIFF_OVER_ALARM,                        ///< 单板：霍尔电流差异过大				1E
	
	// 电池故障                                                                                    
	BAT_FAULT_INDEX,										///< 电池故障类索引          
	BAT_CLUSTER_TOTAL_VOLT_HIGH_TIPS = BAT_FAULT_INDEX,	    ///< 电池：电池簇总压过压提示            1F
    BAT_CLUSTER_TOTAL_VOLT_HIGH_ALARM,					    ///< 电池：电池簇总压过高告警            20
	BAT_CLUSTER_TOTAL_VOLT_HIGH_PROTECT,					///< 电池：电池簇总压过高保护            21
    BAT_CLUSTER_TOTAL_VOLT_LOW_TIPS,						///< 电池：电池簇总压过低提示            22
	BAT_CLUSTER_TOTAL_VOLT_LOW_ALARM,						///< 电池：电池簇总压过低告警            23
	BAT_CLUSTER_TOTAL_VOLT_LOW_PROTECT,						///< 电池：电池簇总压过低保护            24
    BAT_CLUSTER_TOTAL_VOLT_DIFF_OVER_FAULT,                 ///< 电池：电池簇总压压差过大故障        25
    BAT_INTER_CLU_VOLT_DIFF_OVER_FAULT,                     ///< 电池：簇间压差过大故障              26
    BAT_CHARGE_CURR_OVER_LIMIT_ALARM,                       ///< 电池：充电电流超限告警              27
    BAT_CHARGE_CURR_OVER_LIMIT_PROTECT,                     ///< 电池：充电电流超限保护              28
    BAT_DISCHG_CURR_OVER_LIMIT_ALARM,                       ///< 电池：放电电流超限告警              29
    BAT_DISCHG_CURR_OVER_LIMIT_PROTECT,                     ///< 电池：放电电流超限保护              2A    
    BAT_CHARGE_CURR_HIGH_TIPS,								///< 电池：充电电流过高提示              2B
	BAT_CHARGE_CURR_HIGH_ALARM,								///< 电池：充电电流过高告警              2C
	BAT_CHARGE_CURR_HIGH_PROTECT,							///< 电池：充电电流过高保护              2D
    BAT_DISCHG_CURR_OVER_TIPS,								///< 电池：放电电流过高提示              2E
	BAT_DISCHG_CURR_OVER_ALARM,								///< 电池：放电电流过高告警              2F
	BAT_DISCHG_CURR_OVER_PROTECT,							///< 电池：放电电流过高保护              30
	BAT_CURR_OVER_PROTECT_DISABLE,							///< 电池：过流保护失能                  31    
	BAT_CURR_OVER_SERIOUS_LOCK,							    ///< 电池：严重过流锁死                  32        
    BAT_SOC_LOW_TIPS,										///< 电池：SOC过低提示                   33
	BAT_SOC_LOW_ALARM,										///< 电池：SOC过低告警                   34
    BAT_SOC_LOW_PROTECT,									///< 电池：SOC过低保护                   35
	// 故障总数
	FAULT_MAX,
}fault_type_e;




// BMU内can的故障信息1
typedef struct
{
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t cell_v_h_pro : 1;
            uint8_t cell_v_h_alm : 1;
            uint8_t cell_v_l_pro : 1;
            uint8_t cell_v_l_alm : 1;
            uint8_t total_v_h_pro : 1;
            uint8_t total_v_h_alm : 1;
            uint8_t total_v_l_pro : 1;
            uint8_t total_v_l_alm : 1;
        } bits;
    } byte0;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t chg_temp_h_pro : 1;
            uint8_t chg_temp_h_alm : 1;
            uint8_t chg_temp_l_pro : 1;
            uint8_t chg_temp_l_alm : 1;
            uint8_t dis_temp_h_pro : 1;
            uint8_t dis_temp_h_alm : 1;
            uint8_t dis_temp_l_pro : 1;
            uint8_t dis_temp_l_alm : 1;
        } bits;
    } byte1;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t chg_curr_h_pro : 1;
            uint8_t chg_curr_h_alm : 1;  // CBS5000无次告警，不使用
            uint8_t dsg_curr_h_pro : 1; 
            uint8_t dsg_curr_h_alm : 1;  // CBS5000无次告警，不使用
            uint8_t en_temp_h_pro : 1;  // CBS5000无次告警，不使用
            uint8_t en_temp_h_alm : 1;
            uint8_t en_temp_l_pro : 1;  // CBS5000无次告警，不使用
            uint8_t en_temp_l_alm : 1;
        } bits;
    } byte2;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t mos_temp_h_pro : 1;   // CBS5000无次告警，不使用
            uint8_t mos_temp_h_alm : 1;   // llc
            uint8_t soc_l_pro : 1;    // CBS5000无次告警，不使用
            uint8_t soc_l_alm : 1;
            uint8_t total_v_err : 1;
            uint8_t total_v_h0 : 1;    // 总压过大硬件保护(BTS-5K专用)   // CBS5000无此告警，不使用
            uint8_t chg_curr_h0 : 1;   // 充电过流硬件保护(BTS-5K专用)   // CBS5000无此告警，不使用
            uint8_t dsg_curr_h0 : 1;   // 防电过流硬件保护(BTS-5K专用)   // CBS5000无此告警，不使用
        } bits;
    } byte3;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t chg_full : 1;          // CBS5000无此告警，不使用
            uint8_t short_circuit : 1;     // CBS5000无此告警，不使用
            uint8_t eerom_error : 1;       // CBS5000无此告警，不使用
            uint8_t cell_volt_fault : 1;   // CBS5000无此告警，不使用
            uint8_t ntc_invalid : 1;
            uint8_t chg_mos_invalid : 1;   // CBS5000无此告警，不使用
            uint8_t dsg_mos_invalid : 1;   // CBS5000无此告警，不使用
            uint8_t samp_invalid : 1;
        } bits;
    } byte4;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t limit_invalid : 1;   // CBS5000无此告警，不使用
            uint8_t chg_reversed : 1;    // CBS5000无此告警，不使用
            uint8_t can_com_fail : 1;
            uint8_t canid_conflict : 1;
            uint8_t dischg_empty : 1;  // CBS5000无此告警，不使用
            uint8_t pcu_invalid : 1;   // CBS5000无此告警，不使用
            uint8_t rechg_err : 1;     // CBS5000无此告警，不使用
            uint8_t soft_error : 1;    // CBS5000无此告警，不使用
        } bits;
    } byte5;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t chg_big_curr_zero_err: 1;     // CBS5000无此告警，不使用
            uint8_t chg_samll_curr_zero_err : 1;  // CBS5000无此告警，不使用
            uint8_t curr_offset_err : 1;          // CBS5000无此告警，不使用
            uint8_t master_fuse_err : 1;          // CBS5000无此告警，不使用
            uint8_t latch_err : 1;                // CBS5000无此告警，不使用
            uint8_t aux_power_err : 1;
            uint8_t serious_cell_v_h : 1;
            uint8_t serious_cell_v_l : 1;
        } bits;
    } byte6;
	
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t dsg_big_curr_zero_err : 1;    // CBS5000无此告警，不使用
            uint8_t dsg_samll_curr_zero_err: 1;   // CBS5000无此告警，不使用
            uint8_t cell_temp_diff_err : 1;       // CBS5000无此告警，不使用
            uint8_t insulation_ab : 1;            // CBS5000无此告警，不使用
            uint8_t res1 : 1;
            uint8_t res2 : 1;
            uint8_t res3 : 1;
            uint8_t res4 : 1;
        } bits;
    } byte7;
} inner_can_fault_info1_t;

// 内can故障信息2
typedef struct
{
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t act_bal_invalid : 1;
            uint8_t act_bal_cur_diff : 1;
            uint8_t act_bal_pri_dsg_curr_slow_h : 1;
            uint8_t act_bal_pri_chg_curr_slow_h : 1;
            uint8_t act_bal_hard_curr_h : 1;
            uint8_t act_bal_curr_lock : 1;
            uint8_t act_bal_pri_volt_slow_h : 1;
            uint8_t act_bal_sec_volt_slow_h : 1;
        } bits;
    } byte0;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t act_bal_sec_volt_slow_l : 1;
            uint8_t act_bal_pri_volt_fast_h : 1;
            uint8_t act_bal_sec_volt_fast_h : 1;
            uint8_t act_bal_pri_dsg_curr_fast_h : 1;
            uint8_t act_bal_pri_chg_curr_fast_h : 1;
            uint8_t act_bal_hard_volt_h : 1;
            uint8_t act_bal_power_h : 1;
            uint8_t act_curr_ring_badness_err : 1;
        } bits;
    } byte1;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t res1 : 1;
            uint8_t res2 : 1;
            uint8_t pass_bal_temp_h : 1;
            uint8_t cell_v_serious_diff_err : 1;
            uint8_t cell_temp_h_err : 1;
            uint8_t curr_lock_h : 1;
            uint8_t cell_v_lock_h : 1;
            uint8_t cell_v_lock_l : 1;
        } bits;
    } byte2;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t cell_temp_lock_hl : 1;
            uint8_t cell_temp_rise_err : 1;
            uint8_t res1 : 1;
            uint8_t dsg_curr_h_pro2 : 1;
            uint8_t chg_temp_tip_h : 1;
            uint8_t chg_temp_tip_l : 1;   
            uint8_t dsg_temp_tip_h : 1;  
            uint8_t dsg_temp_tip_l : 1; 
        } bits;
    } byte3;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t flash_err : 1;
            uint8_t power_temp_lock_h : 1;
            uint8_t mos_temp_lock_h : 1;    // llc
            uint8_t cell_v_lock_h_err2 : 1;
            uint8_t cell_v_line_err : 1;
            uint8_t cell_temp_line_err : 1;
            uint8_t pass_bal_temp_line_err : 1;
            uint8_t power_temp_line_err : 1;
        } bits;
    } byte4;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t power_temp_pro_h : 1;
            uint8_t heat_err : 1;               // CBS5000无此告警，不使用
            uint8_t heat_relay_short_err : 1;   // CBS5000无此告警，不使用
            uint8_t heat_relay_open_err : 1;    // CBS5000无此告警，不使用
            uint8_t res5 : 1;
            uint8_t res6 : 1;
            uint8_t res7 : 1;
            uint8_t res8 : 1;
        } bits;
    } byte5;
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t chg_oc_lock_h_err2 : 1;    // CBS5000无此告警，不使用
            uint8_t dchg_oc_lock_h_err2 : 1;   // CBS5000无此告警，不使用
            uint8_t heat_loop_ctl_err : 1;     // CBS5000无此告警，不使用
            uint8_t res4 : 1;
            uint8_t res5 : 1;
            uint8_t res6 : 1;
            uint8_t res7 : 1;
            uint8_t res8 : 1;
        } bits;
    } byte6;
    
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t res1 : 1;
            uint8_t res2 : 1;
            uint8_t res3 : 1;
            uint8_t res4 : 1;
            uint8_t res5 : 1;
            uint8_t res6 : 1;
            uint8_t res7 : 1;
            uint8_t res8 : 1;
        } bits;
    } byte7;
} inner_can_fault_info2_t;

// 内can故障信息3
typedef struct
{
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t board_temp_tip : 1;
            uint8_t cell_over_volt_tip : 1;
            uint8_t cell_under_volt_tip : 1;
            uint8_t cell_volt_diff_over_tip : 1;
            uint8_t cell_temp_diff_over_tip : 1;
            uint8_t bat_over_volt_tip : 1;
            uint8_t bat_under_volt_tip : 1;
            uint8_t soc_l_tip : 1;
        } bits;
    } byte0;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t dsg_cur_over_tip : 1;
            uint8_t chg_cur_over_tip : 1;
            uint8_t afe_chain_break_tip : 1;            
            uint8_t electrolyte_sen_tip : 1;
            uint8_t cell_temp_line_tip  : 1;
            uint8_t res6 : 1;
            uint8_t res7 : 1;
            uint8_t res8 : 1;
        } bits;
    } byte1;
    
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t cell_volt_diff_over_alm : 1;
            uint8_t cell_temp_diff_over_alm : 1;
            uint8_t env_ntc_abnormal_alm : 1;
            uint8_t res4 : 1;
            uint8_t res5 : 1;
            uint8_t res6 : 1;
            uint8_t res7 : 1;
            uint8_t res8 : 1;
        } bits;
    } byte2;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t cell_limit_err : 1;
            uint8_t res2 : 1;
            uint8_t res3 : 1;
            uint8_t res4 : 1;
            uint8_t res5 : 1;
            uint8_t res6 : 1;
            uint8_t res7 : 1;
            uint8_t res8 : 1;
        } bits;
    } byte4;
} inner_can_fault_info3_t;

typedef struct
{
    inner_can_fault_info1_t fault_info1;
    inner_can_fault_info2_t fault_info2;
    inner_can_fault_info3_t fault_info3;
} inner_fault_info_t;

// 簇故障bit
typedef struct
{
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t power_volt_under          :1;  // 供电电压欠压报警
            uint8_t power_volt_over           :1;  // 供电电压过压报警
            uint8_t mod_temp_over             :1;  // 模块温度过温报警
            uint8_t clu_volt_under            :1;  // 组端电压欠压报警
            uint8_t clu_volt_over             :1;  // 组端电压过压报警
            uint8_t fast_chg_curr_over        :1;  // 快充电流过流报警
            uint8_t power_terminal_temp_over  :1;  // 动力插件过温报警
            uint8_t feed_curr_over            :1;  // 馈电电流过流报警
        }bits;
    }warn_byte0;
    
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t dsg_curr_over             :1;  // 放电电流过流报警
            uint8_t ins_val_low               :1;  // 绝缘电阻过低报警
            uint8_t soc_low                   :1;  // SOC 过低报警
            uint8_t soc_high                  :1;  // SOC 过高报警
            uint8_t cell_volt_over            :1;  // 单体电压过压报警
            uint8_t cell_volt_under           :1;  // 单体电压欠压报警
            uint8_t cell_volt_diff            :1;  // 单体压差报警
            uint8_t chg_cell_temp_high        :1;  // 充电单体过温报警
        }bits;
    }warn_byte1;
    
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t chg_cell_temp_low             :1;  // 充电单体欠温报警
            uint8_t dsg_cell_temp_over            :1;  // 放电单体过温报警
            uint8_t dsg_cell_temp_low             :1;  // 放电单体欠温报警
            uint8_t cell_temp_diff_over           :1;  // 单体温差报警
            uint8_t soc_diff_over                 :1;  // SOC 差异过大报警
            uint8_t cell_temp_rise_fast           :1;  // 温升快报警
            uint8_t bat_volt_over                 :1;  // 电池模组过压
            uint8_t bat_volt_under                :1;  // 电池模组欠压
        }bits;
    }warn_byte2;
} gold_base_warn_t;

typedef struct
{
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t di1_err             :1;  // DI1 主正接触器故障
            uint8_t di2_err             :1;  // DI2 辅电继电器故障
            uint8_t di3_err             :1;  // DI3 主负继电器故障
            uint8_t di4_err             :1;  // DI4 紧急停机
            uint8_t di5_err             :1;  // DI5 上层监控故障信号
            uint8_t di6_err             :1;  // DI6 高压箱内隔离开关断开
            uint8_t di7_err             :1;  // DI7 检测故障（预留）
            uint8_t di8_err             :1;  // DI8 检测故障（预留）
        }bits;
    }warn_byte0;
    
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t inner_comm_err              :1;  // 内网通讯故障
            uint8_t cell_volt_sample_err        :1;  // 电芯电压采集故障
            uint8_t cell_temp_sample_err        :1;  // 电芯温度采集故障
            uint8_t pc_err                      :1;  // 显控下发故障
            uint8_t inter_clu_volt_diff_over    :1;  // 簇间压差故障
            uint8_t trip_err                    :1;  // 跳机故障
            uint8_t dodi_err                    :1;  // 从控 DO/DI 检测故障
            uint8_t cell_limit_err              :1;  // 电池极限故障
        }bits;
    }warn_byte1;
    
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t code_param_err         :1;  // 程序和参数不一致故障
            uint8_t pcs_comm_err           :1;  // PCS 通讯故障
            uint8_t pc_ctl_mode            :1;  // PC 强制控制模式
            uint8_t hall_dev_err           :1;  // CAN 霍尔传感器故障
            uint8_t hall_comm_err          :1;  // CAN 霍尔传感器通讯故障
            uint8_t hard_self_err          :1;  // 硬件自检故障
            uint8_t pole_temp_sam_err      :1;  // 极柱温度采集故障
            uint8_t bal_err                :1;  // 均衡故障
        }bits;
    }warn_byte2;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t res0                   :1;
            uint8_t cur_diff_h_alm         :1;  // 电流差异大告警
            uint8_t res2                   :1;
            uint8_t pre_chg_overtime       :1;  // 预充超时
            uint8_t fan_closed_before_trip :1;  // 脱扣前关闭风扇
            uint8_t dbc_en_opened          :1;  // DBC使能已开启
            uint8_t power_off_err          :1;  // 正常下电失败
            uint8_t all_clu_err_power_off  :1;  // 接收到所有簇故障下电
        }bits;
    }warn_byte3;
} gold_dev_warn_t;


// 簇新增故障bit
typedef struct
{
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t hv_sam_err                :1; // 高压采集异常
            uint8_t inner_addr_err            :1; // 编址异常
            uint8_t afe_err                   :1; // afe异常
            uint8_t flash_err                 :1; // flash异常
            uint8_t serious_ov_curr_lock      :1; // 严重过流锁死故障
            uint8_t serious_h_volt_lock       :1; // 严重过压锁死故障
            uint8_t rsv                       :2; // 
        }bits;
    }dev_byte0;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t clu_volt_diff             :1;  // 电池簇内总压压差过大保护
            uint8_t bat_curr_protect_disable  :1;  // 电池过流保护失能
            uint8_t bat_volt_high_protect_disable :1;  // 电池过压保护失能            
            uint8_t bat_volt_low_protect_disable  :1;  // 电池欠压保护失能            
            uint8_t bat_cell_temp_high_or_low_protect_disable  :1;  // 电池高低温保护失能        
            uint8_t bat_dischg_curr_over_limit_protect  :1;  // 放电电流超限保护         
            uint8_t bat_charge_curr_over_limit_protect  :1;  // 充电电流超限保护
            uint8_t rsv                       :1;  // 
        }bits;
    }protect_byte0;
    
    union
    {
        uint8_t byte;
        struct
        {
            uint8_t addr_conflict             :1;  // 地址冲突
            uint8_t bat_dischg_curr_over_limit_alarm             :1;  // 放电电流超限告警
            uint8_t bat_charge_curr_over_limit_alarm             :1;   // 充电电流超限告警
            uint8_t rsv                       :5;  // 
        }bits;
    }alarm_byte0;

    union
    {
        uint8_t byte;
        struct
        {
            uint8_t afe_chain_break           :1;  // afe断链
            uint8_t hall_curr_diff            :1;  // 霍尔电流差异过大提示
            uint8_t env_temp_sam          :1;  // 环境温度采集失效提示    
            uint8_t electrolyte_sen       :1;  // 电解液漏液检测传感器异常提示                
            uint8_t cell_temp_sam      :1;  // 单体温度采集异常提示                        
            uint8_t rsv                       :3;  // 
        }bits;
    }tip_byte0;
    
} gold_add_warn_t;  //在高特协议外新增的


typedef struct
{
    gold_base_warn_t base_warn[3];
    gold_dev_warn_t dev_warn;
    gold_add_warn_t add_warn;   // 新增告警定义
    uint8_t alarm_no[DEV_NUM];   //触发告警所在的板号，最大8个pack，加上BCU，一共9个设备    故障等级(bit0：硬件故障;bit1：严重告警;bit2：一般告警;bit3:提示告警)
} gold_warn_msg_t;

/* can回调函数定义 */
typedef void(*fault_check_f)(void);


/**
  * @struct   fault_data_t
  * @brief  单个故障数据结构
  */
typedef struct
{
	fault_type_e 	fault_type;  			///< 故障类型
	uint16_t 		fault_code;				///< 故障编码
	uint16_t		fault_status;			///< 故障状态
	uint8_t		    charge_level;			///< 充电等级
	uint8_t		    discharge_level;		///< 放电等级
} fault_data_t;


/**
  * @struct   fault_stat_data_t
  * @brief  故障统计数据结构
  */
typedef struct
{
	uint16_t    	fault_num;  			///< 故障数量
	uint8_t 		max_charge_level;		///< 最高充电等级
	uint8_t 		max_discharge_level;	///< 最高放电等级
    uint8_t         fault_level;            ///< 按bit来代表是否触发某个等级，主要是给外can发送使用
} fault_stat_data_t;


/**
  * @struct   fault_lock_data_t
  * @brief	故障锁死数据
  */
typedef struct
{
	uint8_t 	chg_curr_protect_times;				///< 充电过流保护次数
	uint8_t 	dsg_curr_protect_times;				///< 放电过流保护次数
	uint8_t		power_terminal_protect_times;	///< 功率端子过温次数
	uint8_t 	cell_volt_over_protect_times;	///< 单体过压保护次数
	uint8_t 	total_volt_over_protect_times;	///< 总体过压保护次数
	uint8_t 	cell_volt_low_protect_times;	///< 单体欠压保护次数
	uint8_t 	total_volt_low_protect_times;	///< 总体欠压保护次数
	uint8_t 	chg_temp_over_protect_times;	///< 充电温度过高保护次数
	uint8_t 	chg_temp_low_protect_times;		///< 充电温度过低保护次数
	uint8_t 	dsg_temp_over_protect_times;	///< 放电温度过高保护次数
	uint8_t 	dsg_temp_low_protect_times;		///< 放电温度过低保护次数
    uint8_t     inner_can_addr_fault_times;     ///< 反复循环编址异常次数
} fault_lock_data_t;


/**
  * @struct   fault_record_data_t
  * @brief	故障录波数据
  */
typedef struct
{
	uint16_t fault_id[FAULT_MAX];
	uint8_t fault_record_flag[FAULT_MAX];	//故障是否已经开始写入标志
	uint8_t fault_cnt;
} fault_id_t;



typedef void (*fault_check_opt_f)(void);



/**
* @brief		故障管理初始化
* @param		void
* @param		void
* @pre			系统启动时执行一次。
*/
void fault_manage_init(void);

/**
* @brief		系统锁初始化
* @param		void
* @param		void
* @pre			系统启动时执行一次。
*/
void sys_lock_init(void);

/**
* @brief		故障诊断功能使能
* @param		void
* @param		void
* @pre			系统启动时执行一次。
*/
void fault_diag_enable(void);


/**
* @brief		故障运行步骤获取
*/
fault_diag_step_e fault_diag_step_get(void);


/**
* @brief		故障状态
* @param		[in] fault_type 故障类型
* @retval		1 有故障
* @retval		0 无故障
* @retval		-1 查询失败
*/
int32_t fault_state_get(fault_type_e fault_type);


/**
* @brief		获单个故障信息
* @param		[in] fault_type 需要查询的故障类型
* @param		[out] *p_dout 存放获取的故障数据指针,为空无法获取数据
* @return		执行结果
* @retval		0  获取成功F
* @retval		-1 获取失败
*/
int32_t fault_data_get(fault_type_e fault_type, fault_data_t* p_dout);


/**
* @brief		获取故障统计数据
* @param		[out] *p_dout 存放获取的故障统计数据指针，为空无法获取数据
* @return		执行结果
* @retval		>0 故障数量
* @retval		0  无故障
*/
int32_t fault_stat_data_get(fault_stat_data_t* p_dout);

/**
 * @brief		获取充放电故障等级
 * @return		执行结果
 * @retval		>=0 故障数量
 * @retval		-1  获取失败
 */
const fault_stat_data_t* fault_chg_dsg_level_get(void);

/**
* @brief		故障诊断 执行周期100ms 应用调用
* @param		void
* @param		void
* @return		void
*/
int32_t fault_manage_task(void);

/**
 * @brief                需要录波故障ID读取
 * @return               返回结构体
 * @warning              
 */
const fault_id_t *get_fault_id(void);



/**
 * @brief                故障开始记录后需要清除标志，防止重复记录
 * @return               返回结构体
 * @warning              
 */
void clean_fault_record_flag(uint8_t num);

/**
 * @brief		通信计数清空
 * @param		void
 * @param		void
 * @return		void
 */
void fault_bcu_inter_com_count_clear(void);

/**
* @brief		故障总状态信息，位操作， bit=0(无故障) bit=1(有故障)
* @param		[in] void
* @retval		1 有故障
* @retval		0 无故障
* @pre			
*/
const uint32_t *fault_total_state_get(void);



/**
 * @brief   获取应答回复的报警信息
 */
const gold_warn_msg_t *warn_msg_reply_get(void);

/**
 * @brief 清除CAN霍尔传感器通讯故障计数值
 */
void can_hall_sensor_comm_err_cnt_clr(void);

/**
 * @brief 清除BCU-PCS通讯故障计数值
 */
void bcu_pcs_comm_err_cnt_clr(void);

/**
* @brief        故障变化标志
* @param        [in] uint8_t *fault_id
* @return        [out]bool  0:无需存储；1：需要存储
* @retval         无
*/
bool fault_state_change(uint8_t *fault_id);

#endif


