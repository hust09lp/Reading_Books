#ifndef __BMS_STATE_MANAGE_H__
#define __BMS_STATE_MANAGE_H__

#include <stdint.h>
#include <stddef.h>

#define BMS_STATE_SHELL_DEBUG_TEST
/*进入或退出充放电模式的电流，需根据实际项目待机功耗电流调整*/
#define  ENTER_CHARGE_CURR                500              //进入充电模式电流500mA		
#define  EXIT_CHARGE_CURR                 100              //退出充电模式电流100mA

#define  ENTER_DISCHARGE_CURR             -500              //进入放电模式电流-500mA		
#define  EXIT_DISCHARGE_CURR              -100              //退出放电模式电流-100mA	

#define  ENTER_FORCECHARGE_CURR           5000              //进入充电模式电流5A	

#define  control_bmu_shut_down_flag_get() 0

/**
 * @enum battery_state_e
 * @brief 电池充放电状态
 */
typedef enum
{
	BMS_STANDY_MODE = 0, ///< 待机
	BMS_CHARGE_MODE,	 ///< 充电
	BMS_DISCHARGE_MODE,	 ///< 放电

} battery_state_e;

/**
 * @brief		电池充放电状态下的显示灯
 * @param		无
 * @return		无
 * @warning		无
 */
typedef enum
{
	INIT_STATE = 0,
	NORMAL_STANDBY,
	NORMAL_CHARGE,
	NORMAL_DISCHARGE,
	ERROR_STANDBY,
	ERROR_CHARGE,
	ERROR_DISCHARGE,
	OVER_CHARGE,
	OVER_DISCHARGE,
} bat_state_led_display_t;

/**
 * @enum bms_system_step_e
 * @brief 电池管理系统状态
 */
typedef enum
{
	EVT_BMS_START_UP, ///< 开机
	EVT_BMS_NORMAL,	  ///< 正常运行
	EVT_BMS_PF_ERROR, ///< 永久性故障
	EVT_BMS_UPGRADE,  ///< 升级
	EVT_BMS_SHUT_DOWN,///< 关机（当前是做在板子准备复位时，在状态机不体现）      
	EVT_BMS_STA_NUM,  ///< 事件综合个数
} evt_bms_system_step_e;
/**
 * @enum bms_system_step_e
 * @brief 电池管理系统状态
 */
typedef enum
{
	BMS_WAKE_CHECK = 0, ///< 唤醒检测
	BMS_START_UP,		///< 开机
	BMS_SELF_CHECK,		///< 开机自检
	BMS_NORMAL,			///< 正常运行
	BMS_PF_ERROR,		///< 永久性故障
	BMS_UPGRADE,		///< 升级过程
    BMS_SHUT_DOWN,      ///< 关机（当前是做在板子准备复位时，在状态机不体现）      
	BMS_STA_NUM,		///< 状态个数
} bms_system_step_e;

/**
 * @enum bms_system_step_e
 * @brief 电池管理系统状态
 */
typedef enum
{
	BCU_STATE_SELF_CHECK = 0, ///< 开机自检
	BCU_STATE_RUN,			  ///< 运行
	BCU_STATE_PF_ERROR,		  ///< 故障
	BCU_STATE_UPGRADE,		  ///< 升级过程
	BCU_STATE_SHUT_DOWN,	  ///< 关机
	BCU_STATE_INIT = 0xFF,	  //< 无效值
} bms_system_state_e;

typedef enum
{
	BMU_STATE_SELF_CHECK = 0, ///< 开机自检
	BMU_STATE_RUN,			  ///< 运行
	BMU_STATE_PF_ERROR,		  ///< 永久性故障
	BMU_STATE_UPGRADE,		  ///< 升级过程
	BMU_STATE_SHUT_DOWN,	  ///< 关机

} bmu_system_state_e;

/**
 * @brief		获取电池状态
 * @param		无
 * @return		电池充放电状态
 * @retval		待机:BMS_STANDY_MODE
 * @retval		充电:BMS_CHARGE_MODE
 * @retval		放电:BMS_DISCHARGE_MODE
 * @warning		无
 */
battery_state_e bms_state_get_bat_sta(void);

/**
 * @brief		获取系统状态
 * @param		无
 * @return		系统状态
 * @retval		开机		:BCU_STATE_SELF_CHECK
 * @retval		正常运行		:BCU_STATE_RUN
 * @retval		永久性故障	:BCU_STATE_PF_ERROR
 * @retval		升级		:BCU_STATE_UPGRADE
 * @retval		关机		:BCU_STATE_SHUT_DOWN
 * @warning		无
 */
bms_system_state_e bms_state_get_sys_sta(void);

/**
 * @brief    获取系统步骤状态
 * @param    无
 * @return   系统步骤状态
 * @retval   唤醒检测       BMS_WAKE_CHECK = 0,
 * @retval   开机           BMS_START_UP,
 * @retval   开机自检       BMS_SELF_CHECK,
 * @retval   正常运行       BMS_NORMAL,
 * @retval   永久性故障     BMS_PF_ERROR,
 * @retval   升级准备阶段   BMS_UPGRADE_PREPARE,
 * @retval   升级过程       BMS_UPGRADE,
 * @retval   关机准备       BMS_SHUT_DOWN_PREPARE
 * @retval   关机           BMS_SHUT_DOWN
 * @warning  无
 */
bms_system_step_e bms_state_get_sys_step(void);

/**
 * @brief		初始化
 * @param		无
 * @return		无
 * @retval		无
 * @warning		无
 */
void bms_state_init(void);

/**
 * @brief		BMS状态流程
 * @param		无
 * @return		无
 * @retval		无
 * @warning		无
 */
void bms_state_proc(void);

#endif
