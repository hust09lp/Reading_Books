/**
    * @file     sample.h
    * @brief    BMS信息数据文件
    * @company  sofarsolar
    * @author   
    * @note
    * @version
    * @date     2023/4/24
*/

#ifndef __BMU_DATA_H__
#define __BMU_DATA_H__

#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include "inner_can_data.h"
#include "fault_manage.h"

#define RECV_BMU_CAN_DATA    0
#define SIMULATION_DATA_TEST 

#define BMS_TYPE_DATA_JUDGE_OK 1

// 定义的数据枚举
typedef enum
{
    BMS_DI_DI_INPUT_TYPE  = 0,
    BMS_DI_TYPE_NUM,
} bmu_di_data_type;

typedef struct
{
    uint16_t max_cell_volt[3]; // 单位1mV ,0:最高，1：第二高，2：第三高
    uint16_t min_cell_volt[3]; // 单位1mV ,0:最低，1：第二低，2：第三低
    uint16_t avg_cell_volt;
    uint16_t max_cell_volt_diff;
    int8_t  max_cell_temp[3];   // 温度：1℃/bit 偏移量：-40℃
    int8_t  min_cell_temp[3];   // 温度：1℃/bit 偏移量：-40℃
    int8_t avg_cell_temp;       // 温度：1℃/bit 偏移量：-40℃
    uint8_t max_cell_temp_diff;  // 温度：1℃/bit 偏移量：0
    uint8_t  max_cell_soc[3];   // SOC：1%/bit 偏移量：0
    uint8_t  min_cell_soc[3];   // SOC：1%/bit 偏移量：0
    uint8_t avg_cell_soc;       // SOC：1%/bit 偏移量：0
    uint8_t max_cell_soc_diff;  // SOC：1%/bit 偏移量：0
    uint8_t  max_cell_soh[3];   // SOH：1%/bit 偏移量：0
    uint8_t  min_cell_soh[3];   // SOH：1%/bit 偏移量：0
    uint8_t avg_cell_soh;       // SOH：1%/bit 偏移量：0
    uint8_t max_cell_soh_diff;  // SOH：1%/bit 偏移量：0
    uint16_t max_cell_volt_id; // 1-N
    uint16_t min_cell_volt_id; // 1-N
    uint16_t max_cell_temp_id; // 1-N
    uint16_t min_cell_temp_id; // 1-N
    uint16_t max_cell_soc_id; // 1-N
    uint16_t min_cell_soc_id; // 1-N
    uint16_t max_cell_soh_id; // 1-N
    uint16_t min_cell_soh_id; // 1-N
} bmu_cell_info_arrange_t;

/**
  * @struct    bmu_data_unify_t
  * @brief  电池采样数据管理
  */
//#pragma pack(1)
typedef struct
{
    // bmu数据采集整合
    uint32_t all_pack_acc_volt;        // 所有pack的累加电压 精度：0.1     单位：V
    uint16_t max_cycle_time;           // 电池包最大循环次数
    uint16_t chg_disg_enable;          // 充放电使能
    uint16_t chg_en_flag;              // 充电使能标志，记录电池包编号
    uint16_t empty_full_flag;          // 充满放空标志
    int16_t  bat_ave_temp;             // 电芯平均温度
    uint16_t bal_status;               // 电池包均衡状态
    uint16_t remain_cap;               // 实时剩余总容量  精度：0.1     单位：AH
	uint16_t batmaxcellvolt;		   // 簇最高单体电压
	uint16_t batmaxcellvoltpack;	   // 簇最高单体电压所在pack
	uint16_t batmaxcellvoltnum;		   // 簇最高单体电压所在pack的第几个位置
	uint16_t batmincellvolt;		   // 簇最低单体电压
	uint16_t batmincellvoltpack;	   // 簇最低单体电压所在pack
	uint16_t batmincellvoltnum;		   // 簇最低单体电压所在pack的第几个位置
	int16_t  batmaxcelltemp;		   // 簇最高单体温度
	uint16_t batmaxcelltemppack;	   // 簇最高单体温度所在pack
	uint16_t batmaxcelltempnum;		   // 簇最高单体温度所在pack的第几个位置
	int16_t  batmincelltemp;		   // 簇最低单体温度
	uint16_t batmincelltemppack;	   // 簇最低单体温度所在pack
	uint16_t batmincelltempnum;		   // 簇最低单体温度所在pack的第几个位置
    uint32_t packvolt_max;             // 包最高电压  精度：0.1     单位：V
    uint16_t packvolt_max_id;          // 最高电压包包号
    uint32_t packvolt_min;             // 包最低电压  精度：0.1     单位：V
    uint16_t packvolt_min_id;          // 最低电压包包号
    uint16_t packvolt_diff_max;        //最大包间压差
    uint16_t pack_cellvolt_diff_max;       // 最大包内压差
    uint16_t pack_cellvolt_diff_max_id;   // 最大包内压差id
    uint16_t pack_cellvolt_diff_min;       // 最小包内压差id
    uint16_t pack_cellvolt_diff_min_id;   // 最小包内压差id 
    uint16_t pack_celltemp_diff_max;       // 最大包内温差
    uint16_t pack_celltemp_diff_max_id;   // 最大包内温差id
    uint16_t pack_celltemp_diff_min;       // 最小包内温差
    uint16_t pack_celltemp_diff_min_id;   // 最小包内温差id    	
    uint16_t req_cutoff_flag;          // 请求断开继电器标志，记录电池包编号
    uint16_t req_powoff_flag;          // 请求关机标志，记录电池包编号
    uint16_t bmu_err_sta;              // bmu 故障状态，记录电池包编号
    uint16_t bmu_upg_sta;              // bmu 升级状态，记录电池包编号
    uint16_t bmu_shut_sta;             // bmu 关机状态，记录电池包编号
    uint16_t max_sync_fall_soc;        // 最大同步下降SOC
    uint8_t  force_chg_flag;           // 强充标志
    inner_fault_info_t all_pack_inner_fault;  // 综合所有电池包的故障
    bmu_cell_info_arrange_t  bmu_cell_info;
    uint8_t fault_level[PACK_MAX_NUM];
}bmu_data_unify_t;
//#pragma pack()

/**
* @brief                BMS信息数据初始化
* @param                [in]无
* @return               无返回结果
* @warning              无
*/
void bmu_data_init(void);

/**
* @brief                获取BMS数据信息
* @param                [in]bmu_data_t *p_data 电池采样数据结构体指针
* @return               返回bmu_data_t *p_data 电池采样数据结构体指针
* @retval               NULL 获取失败
* @retval               非NULL获取成功
* @warning              必须不为NULL，才可以使用
*/
const bmu_data_unify_t* bmu_data_unify_get(void);


/**
 * @brief                BMS信息数据任务
 * @param                [in]void
 * @return               返回结果空
 * @retval               [out]无
 * @warning              放在10ms任务，必须要调用bms_data_init()后使用
 */
void bmu_data_proc(void);

/**
 * @brief                获取bmu pin脚信息
 * @param                [in]pack num (1-PACK_MAX_NUM)
 * @param                [in]io id  bmu_di_data_type
 * @return               返回结果空
 * @retval               [out]-1:输入参数异常， -2：数据没有获取, 0:低电平， 1:高电平
 * @warning              放在10ms任务，必须要调用bms_data_init()后使用
 */
int8_t bmu_di_status_get(uint8_t pack_num, bmu_di_data_type di_type);


#endif

