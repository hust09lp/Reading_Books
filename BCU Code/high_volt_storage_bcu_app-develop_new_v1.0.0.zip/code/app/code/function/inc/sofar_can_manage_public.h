/**
 * @file     cup_sofar_can.h
 * @brief    公司自定义CAN协议拓展帧SDK接口
 * @author   duyumeng
 * @note     无
 * @version  V1.0
 * @date     2023/2/3
 */
#ifndef __SOFAR_CAN_MANAGE_PUBLIC_H__
#define __SOFAR_CAN_MANAGE_PUBLIC_H__

#include <stdint.h>
#include "sdk_can.h"
#include "app_public.h"

#define SDK_INTERNAL_CAN_PORT	0
#define SDK_EXTERNAL_CAN_PORT	2
#define SDK_CLUSTER_CAN_PORT	1

#define EXT_CAN_BCU_DEFAULT_PACK_ID 0    
#define CAN_SIGNAL_FRA_MAX_NUMS   8     // can一帧最大数据长度
#define SOFAR_CAN_TRS_BUF_NUMS	  10		// 接收缓冲区个数
#define SOFAR_CAN_FILE_BUF_NUMS	  2		// 文件接收缓冲区个数
#define BROCAST_DEVICE_ADDRESS	 0x1F	//广播所有设备地址
#define BROADCAST_DEVICE_TYPE_ADDRESS    0xFF  //广播所有设备地址

#define GOLD_MIN_EX_CAN_ADDR   0xE8
#define GOLD_MAX_EX_CAN_ADDR   0xF1
#define GOLD_MIN_EX_CAN_NO_TYPE_ADDR   0x8
#define GOLD_MAX_EX_CAN_NO_TYPE_ADDR   0x11
#define GOLD_PC_EX_CAN_NO_TYPE_ADDR   0x14
#define GOLD_PC_EX_CAN_ADDR    0xF4
#define addr_convert	0	//用于将我们自身地址，转换成逆变器要求的地址(3PH)
//canbus通讯结果
#define SOFAR_CAN_RET_EMPTY       0       // 无发送数据
#define SOFAR_CAN_RET_WAIT        1       // 等待发送,任务调用发送时填入
#define SOFAR_CAN_RET_COMPILE	  2
/***********  需要应用按实际情况修改的内容 start  ***********/
// 历史数据上传的功能码范围
#define FUNC_HIST_DATA_START  (FUNC_RD_HIST_SYS_TIME)
#define FUNC_HIST_DATA_END     (0x7CF)

// frame type
typedef enum{
    SOFAR_CAN_REQUEST   = 0,	// 请求帧
    SOFAR_CAN_REPLAY    = 1,    // 应答帧
}frame_type_e;

// frame priority
typedef enum {
    SOFAR_CAN_PRI_HIGH_H = 0,   // 最高优先级
    SOFAR_CAN_PRI_HIGH_L,       // 次高优先级
    SOFAR_CAN_PRI_LOW_H,        // 次低优先级
    SOFAR_CAN_PRI_LOW_L,        // 最低优先级
} frame_pri_e;

// device type  example
typedef enum {
    DEV_BMU  = 0,       // BMU类型
    DEV_DCDC = 1,       // PCU/DCDC类型
    DEV_PCS  = 2,       // PCS类型
    DEV_BCU  = 4,       // BCU类型
    DEV_BDU  = 5,       // BDU类型
    DEV_BROADCAST = 7,  // 上位机/广播类型
    DEV_EXT_BCU = 7,
} device_type_e;
/***********  需要应用按实际情况修改的内容  end  ***********/

//函数运行结果
#define CAN_RET_TURE				 1      //函数正确执行无错误，但数据没有接受完毕
#define CAN_DATA_COMPILE			 0		//函数正确执行完,数据接受完毕
#define CAN_RET_NUMERR				-1		//发送数据长度越限
#define CAN_RET_TRSERR				-2		//发送出错
#define CAN_RET_RECERR				-3		//接收出错
#define CAN_RET_TIMEOUT				-4		//超时未收到数据
#define CAN_RET_CRC_ERR				-5		//CRC校验错误
#define CAN_RET_PARA_ERR			-10		//入参异常
	
#define CAN_SOFAR_DATA_MAXNUMS		(1024)	//CAN数据最大长度,发送长度不能超过此数，升级文件小于1K
#define CAN_SOFAR_SEND_MAXNUMS		(100)		//CAN最长发送长度，不考虑升级，最多一次发送50个数据
#define CAN_SOFAR_FILE_DATA_MAXNUMS		(1024+8)		//CAN文件要考虑数据最大为1024，还需要带crc
#define CAN_SOFAR_LONG_POINT_DATA_RCV_MAX_TIME    (10)    // 10MS定时任务中运行，100ms超时
#define CAN_SOFAR_LONG_FILE_DATA_RCV_MAX_TIME    (100)    // 10MS定时任务中运行，1000ms超时
#define CAN_SOFAR_RCV_DATA_MAX_NUM_ONE_TIME       (20)   // 一次接收处理最多20帧报文

//CAN id msg
typedef union{
	uint32_t id_val;
	struct{
		uint32_t src_addr:	5;	// source address
		uint32_t src_type:	3;	// source device type
		uint32_t dst_addr:	5;	// destination address
		uint32_t dst_type:	3;	// destination device type
		uint32_t fun_code:	11;	// < CAN Frame function code
		uint32_t prio:		2;	// < CAN Frame fun_code priority
		uint32_t res: 		3;	// < Reserved. 
	}bit;
}can_frame_id_u;

typedef struct
{
	uint32_t 			id;             ///< id
    uint8_t             ide;            ///< 扩展帧标识位 标准帧or扩展帧
	uint8_t 			data_len;		///< 数据长度
    uint8_t 			data[8];		///< 数据						
}can_frame_data_t;

typedef int32_t(*can_sofar_parse_callback)(can_frame_data_t *frame_data);

/**
  * @struct can_rec_reg_t
  * @brief can接收注册
  */
typedef struct
{
    uint32_t 			id;             ///< id
    uint32_t 			id_mask;		///< id掩码						
	can_sofar_parse_callback  p_can_cb;		///< 注册的回调函数
}can_sofar_rcv_reg_t;

typedef int32_t(*can_sofar_passthrough_cb)(sdk_can_frame_t *can_frame);

/**
  * @struct can_rec_reg_t
  * @brief can接收注册
  */
typedef struct
{
    uint32_t 			id;             ///< id
    uint32_t 			id_mask;		///< id掩码						
	can_sofar_passthrough_cb  p_can_cb;		///< 注册的回调函数
}can_sofar_pass_reg_t;

// 接收处理任务数组定义
typedef struct 
{
    uint16_t id;         // 此id用于快速定位数组
    uint16_t func_code;
    bool (*p_func_recv_deal_cb)(can_frame_data_t *can_data, uint16_t func_code);
} can_msg_tcb_t;

typedef struct 
{
    uint8_t cycle_send_data_id;
    uint8_t module_group_id;  // 参考 module_request_send_group_e
    uint16_t first_delay;
    uint16_t send_period;
    int16_t send_cnt;        // 发送次数，小于0:一直发送
} can_cycle_send_tcb_t;

//sdk接口函数的can端口号
#define MAX_GENERAL_REC_NUM		64		//普通处理的CANID缓冲区大小
#define PASS_THROUGH_MAX_NUM    8		//普通处理的CANID缓冲区大小
#define PASS_THROUGH_MAX_PAIR_NUM    3   // 透传功能范围的数目
typedef struct
{
    can_sofar_rcv_reg_t reg_buff[MAX_GENERAL_REC_NUM]; // 普通处理的CANID
    uint16_t reg_cnt;                                  // 记录当前注册的普通处理can数据
} rcv_register_info_t;                                 // 注册接收函数
typedef struct
{
    can_sofar_pass_reg_t reg_buff[PASS_THROUGH_MAX_NUM]; // 普通处理的CANID
    uint16_t reg_cnt;                                  // 记录当前注册的普通处理can数据
} pass_register_info_t;                                 // 注册接收函数

/**
 * @brief   发送CAN数据打包发送
 * @param   [in] index  CAN 口编号
 * @param   [in] can_msg  CAN ID信息
 * @param   [in] p_data  需要发送的数据
 * @param   [in] len  需要发送的数据长度
 * @note    调用此函数之前需要APP层自己调用打开CAN的SDK接口
 * @return  返回执行结果 0:正常；<0:异常
 */
int32_t can_sofar_send_frame(uint32_t index, uint32_t can_id, uint8_t *p_data, int32_t len);


// 计算canId以及data0-6的数据crc8
uint8_t can_single_frame_crc8_calc(can_frame_data_t *can_data, uint8_t crs_mask);


/**
* @brief		对比接收的ID是否和注册的ID一致
* @param		[in]接收到的ID
* @param		[in]注册的ID
* @param		[in]注册ID的掩码
* @return		返回结果
* @retval		0：成功    < 0: 失败
* @warning		无
*/
int32_t can_compare_id(uint32_t target_id, uint32_t reg_id, uint32_t id_mask);

#endif
