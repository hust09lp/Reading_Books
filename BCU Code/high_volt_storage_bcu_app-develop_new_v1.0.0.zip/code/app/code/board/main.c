#include "sdk.h"
#include "app_thread.h"
#include "app_public.h"
#include "app_config.h"
#include "data_store.h"

typedef struct
{
    int8_t major_version;      	   
    int8_t minor_version;			
    int8_t stage_version;		 
}version_t;

static uint8_t app_success_flag = 0;

int core_app_api_init(void);
typedef int (*core_app_start)(void);

/**
* @brief        APP运行成功标志设置
* @param        flag 成功标志
* @return       void
*/
void app_run_success_flag_set(uint8_t flag)
{
	app_success_flag = flag;
}

/**
* @brief        APP运行成功标志获取，判断是否升级成功
* @param        void
* @return       flag 成功标志
*/
uint8_t app_run_success_flag_get(void)
{
	return app_success_flag;
}

/**
* @brief        boot版本检查
* @param        void
* @return       只打印，返回成功
*/
bool boot_version_check(void)
{
    char  sdk_version_buff[16];


    memset(sdk_version_buff, 0x00, sizeof(sdk_version_buff));
    sdk_version_get(BOOT_VERSION_TYPE, (int8_t *)sdk_version_buff, sizeof(sdk_version_buff));
    log_i("boot version: %s\r\n", sdk_version_buff);
    
    return true;
}


/**
* @brief        SDK版本检查 不一致需报警
* @param        void
* @return       版本检查结果 true一致 false不一致
*/
bool sdk_version_check(void)
{
    #define   VERSION_LEN_MAX     11
    #define   VERSION_LEN_MIN     6
    char      version_buff[16];
    char      temp_buff[4];
    uint8_t   len, offset;
	version_t sdk_version;
    char      *p1 = NULL;
    char      *p2 = NULL;

    memset(version_buff, 0x00, sizeof(version_buff));
    memset(temp_buff   , 0x00, sizeof(temp_buff));
	len = sdk_version_get(SDK_VERSION_TYPE, (int8_t *)version_buff, sizeof(version_buff));
    log_i("core sdk version of string: %s\r\n", version_buff);
    
    if ((len <= VERSION_LEN_MAX) && (len >= VERSION_LEN_MIN))
    {
        // 解析大版本号
        p1 = version_buff;
        p2 = strchr(version_buff, '.');
        offset = (p2 - ++p1);
        if ((p2) && (offset <= sizeof(temp_buff)))
        {
            memcpy(temp_buff, p1, offset);
            sdk_version.major_version = atoi(temp_buff);
        }
        else
        {
            return false;
        }
        
        // 解析中版本号
        p1 = strchr(&version_buff[offset+2], '.');
        offset = (p1 - ++p2);
        if ((p2) && (offset <= sizeof(temp_buff)))
        {
            memcpy(temp_buff, p2, offset);
            sdk_version.minor_version = atoi(temp_buff);
        }
        else
        {
            return false;
        }
        
        // 解析小版本号
        offset = (len - (++p1 - &version_buff[0]));
        if (offset <= sizeof(temp_buff))
        {
            memcpy(temp_buff, p1, offset);
            sdk_version.stage_version = atoi(temp_buff);
        }
        else
        {
            return false;
        }
    }
    else
    {
        return false;
    }

	log_i("sdk version: V%d.%d.%d(core) V%d.%d.%d(app)\r\n",
           sdk_version.major_version, sdk_version.minor_version, sdk_version.stage_version,
           SDK_B_VERSION, SDK_M_VERSION, SDK_S_VERSION);

    // SDK大版本号不一致或core层中版本号小于app层中版本号，检测失败
	if ((sdk_version.major_version != SDK_B_VERSION) 
        || (sdk_version.minor_version < SDK_M_VERSION))
	{
		return false;
	}
	else
	{
		return true;
	}
}


extern int Region$$Table$$Base;
/**
* @brief        app全局变量初始化
* @param        void
* @return       void
*/
void app_global_load(void)
{
    int global_buf[8];

    memcpy(global_buf, (void *)&Region$$Table$$Base, sizeof(global_buf));
    memcpy((void *)global_buf[1], (void *)global_buf[0], global_buf[2]);
	memset((void *)global_buf[5], 0, global_buf[6]);
}


/**
* @brief        App主函数入口, 本身属于core层创建的一个供app独立使用的线程
* @param        void
* @return       执行结果
*/
int main(void)
{
	// 加载全局变量
	app_global_load();

	// core层api接口映射初始化
    core_app_api_init();

    //注册app命令
	finsh_system_init();
    // boot版本检测，只打印
    boot_version_check();
	// core sdk版本检测，sdk与app版本接口不一致，停止运行app应用程序
	if (true == sdk_version_check())
	{
		log_i("SdkVerRight,AppVer:%s RunSuc\n", SOFTWARE_VERSION);
		log_i("cpuResetFlag: %d\n", sdk_cpu_reset_flag_get());
		app_run_success_flag_set(1);
        os_delay(TICK_300MS);
        data_store_init();
		app_thread_creat();
		
		return true;    // 初始化成功后，退出释放线程
	}
    else
    {
        log_i("check sdk version err, app ver: %s can't run!!!\n", SOFTWARE_VERSION);
        app_run_success_flag_set(0);    
        os_delay(TICK_500MS);   //做一个短延时，用于让其可以走到空闲函数，打印版本不匹配log
        // 升级时，版本号不一致，系统复位，boot走备份
        // 下载时，系统会反复复位，需烧录正确的版本
        sdk_system_reset();    
    }

	// return false;
}



const core_app_start appcore __attribute__((at(APP_START_ADDR))) = {main};







