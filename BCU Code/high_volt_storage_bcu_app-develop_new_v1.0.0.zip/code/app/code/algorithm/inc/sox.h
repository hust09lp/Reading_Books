/**
 * @file     sox.h
 * @brief    电池簇的SOC，SOH计算的头文件
 * @company  sofarsolar
 * @author   刘吕从
 * @note
 * @version   
 * @date     2023/5/17
 */

#ifndef __SOX_H__
#define __SOX_H__

#include <stdint.h>
#include <string.h>

#define SOX_DEBUG_TEST  // shell debug

#define SOX_INVALID_VAL (0xFFFF)

typedef struct 
{
    uint16_t batt_clu_display_soc;  // 综合显示Soc，单位1%, 无效值位0xFFFF
    uint16_t batt_clu_display_soh;  // 综合显示Soh，单位0.1%, 无效值位0xFFFF
    uint16_t batt_clu_calc_soc;     // 综合计算Soc，单位0.1%, 无效值位0xFFFF
    uint16_t batt_clu_calc_soh;     // 综合计算Soh，单位0.1%, 无效值位0xFFFF
    uint16_t batt_clu_cycle_count;  // 电池循环次数
    uint16_t batt_clu_remain_cap;   // 剩余容量 0.1AH
    uint16_t batt_clu_real_cap;     // 实际容量 0.1AH - 满充容量
    uint32_t batt_clu_ah_chg;      // 累计充电容量 AH
    uint32_t batt_clu_ah_dsg;      // 累计放电容量 AH
	uint32_t batt_clu_wh_chg;       // 累计充电量   WH
    uint32_t batt_clu_wh_dsg;       // 累计放电量   WH
    uint64_t batt_clu_mas_chg;      // 累计充电容量 mas
    uint64_t batt_clu_mas_dsg;      // 累计放电容量 mas
	uint64_t batt_clu_mws_chg;       // 累计充电量   mws
    uint64_t batt_clu_mws_dsg;       // 累计放电量   mws
} batt_clu_sox;

/**
 * @brief                电池簇SOX数据初始化
 * @param                [in]void
 * @warning              用于初始化SOX模块
 */
void sox_init(void);

/**
 * @brief                电池簇SOX计算处理函数
 * @param                [in]void
 * @warning              100ms任务内运行，
 * @warning              自动编址完成等待1s时间，1s后续可调整；主要是保证所有电池包都正常上报SOX数据
 */
void sox_proc_deal(void);

/**
 * @brief    获取SOX的数据
 * @param    [in]void
 * @param    [out]sox_data_t*
 */
const batt_clu_sox* sox_data_get(void);

#endif

