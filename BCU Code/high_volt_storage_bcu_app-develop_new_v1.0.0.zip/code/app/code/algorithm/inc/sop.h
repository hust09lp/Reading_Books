/**
 * @file     sop.h
 * @brief    电池簇的SOP计算的头文件
 * @company  sofarsolar
 * @author   刘吕从
 * @note
 * @version   
 * @date     2023/5/17
 */

#ifndef __SOP_H__
#define __SOP_H__

#include <stdint.h>
#include <string.h>
#include <stdbool.h>

#define SOP_SHELL_DEBUG_TEST  // shell debug

#define SOP_INVALID_VAL (0xFFFF)

typedef struct
{
    uint16_t batt_clu_limit_dsg_curr;  // 综合放电上限，单位0.1A, 无效值位0xFFFF
    uint16_t batt_clu_limit_chg_curr;  // 综合充电上限，单位0.1A, 无效值位0xFFFF
    uint32_t batt_clu_limit_dsg_power; // 综合放电上限，单位0.1w, 无效值位0xFFFF
    uint32_t batt_clu_limit_chg_power; // 综合充电上限，单位0.1w, 无效值位0xFFFF
} batt_clu_sop;

/**
 * @brief                电池簇SOP数据初始化
 * @param                [in]void
 * @warning              用于初始化SOX模块
 */
void sop_init(void);

/**
 * @brief                电池簇SOP计算处理函数
 * @param                [in]void
 * @warning              100ms任务内运行，
 * @warning              自动编址完成等待1s时间，1s后续可调整；主要是保证所有电池包都正常上报SOX数据
 */
void sop_proc_deal(void);

/**
 * @brief    获取SOP的数据
 * @param    [in]void
 * @param    [out]sop_data_t*
 */
const batt_clu_sop* sop_data_get(void);

/**
 * @brief   充放电限流为0，开关
 * @param   [in]bool set_zero ，
 */
void sop_limit_curr_zero_set(uint8_t direction, bool set_zero_flag);

/**
 * @brief                判断sop变成0后，事件触发外can发送yc数据
 * @param                [in]void
 * @warning              10ms任务，需要较快响应
 */
void sop_zero_event_send_deal(void);

#endif

