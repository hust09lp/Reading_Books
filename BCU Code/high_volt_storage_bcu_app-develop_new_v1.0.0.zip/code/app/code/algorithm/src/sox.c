/**
 * @file     sox.c
 * @brief    综合电池簇的SOC，SOH
 * @company  sofarsolar
 * @author   刘吕从
 * @note     Battery cluster
 * @version
 * @date     2023/5/30 初稿
 */

#include <string.h>
#include <stdlib.h>
#include "sdk.h"
#include "sox.h"
#include "auto_addressing.h"
#include "inner_can_data.h"
#include "sox_stats.h"
#include "data_store.h"

#define MAX_DISPLAY_SOC_VAL (100)
#define MAX_CALC_SOC_VAL (1000)
#define SOX_INIT_DELAY_B100MS (10)    // 延迟综合SOX数据，当前1s
#define RATED_CAPACITY_OF_BATT (280)  // 电池额定容量

#define SOX_TIME_BASE    (100)                      // 一个周期为100ms
#define SOX_ONE_SEC_BASE  (60 * 1000 / SOX_TIME_BASE)    // 一秒周期时间的次数
#define SOX_RUN_SAVE_TIMER (30 * SOX_ONE_SEC_BASE)   // 半个小时检测是否要存储，

typedef struct 
{
    uint16_t min_batt_clu_display_soc;  // 综合显示Soc，单位1%
    uint16_t max_batt_clu_display_soc;  // 综合显示Soc，单位1%
    uint16_t min_batt_clu_display_soh;  // 综合显示Soh，单位1%
    uint16_t min_batt_clu_calc_soc;  // 综合计算Soc，单位0.1%
    uint16_t max_batt_clu_calc_soc;  // 综合计算Soc，单位0.1%
    uint16_t min_batt_clu_calc_soh;  // 综合计算Soh，单位0.1%
    uint16_t min_batt_clu_cycle_count;  // 电池簇循环次数
    uint32_t get_batt_clu_cap_chg;      // 累计充电容量 AH
    uint32_t get_batt_clu_cap_dsg;      // 累计放电容量 AH
	uint32_t get_batt_clu_wh_chg;       // 累计充电量   WH
    uint32_t get_batt_clu_wh_dsg;       // 累计放电量   WH
} batt_clu_sox_data;

static batt_clu_sox g_batt_cluster_sox = {0};
static uint32_t g_sox_run_timer_b100ms = SOX_RUN_SAVE_TIMER / 2;  // 第一次提前15min
#ifdef SOX_DEBUG_TEST
static bool g_sox_debug_flag = false;
#endif

/**
 * @brief                存储SOX的运行数据
 * @param                void
 * @return               无
* @note               100ms任务
 */
static void sox_running_data_cycle_save_deal(void)
{

    uint8_t save_data_flag = 0;
    uint8_t temp = 0;

    if (g_sox_run_timer_b100ms > 0)
    {
        g_sox_run_timer_b100ms--;
        return;
    }

    g_sox_run_timer_b100ms = SOX_RUN_SAVE_TIMER;
    temp = sox_stats_save_flag_get();
    if (true == temp)
    {
        save_data_flag = true;
        sox_stats_save_flag_reset();
    }
    else
    {
        return;
    }
    if (save_data_flag)
    {
        bms_runing_data_save_all();
    }
}

/**
 * @brief                计算电池簇SOX
 * @param                [in]void
 * @warning              用于初始化SOX模块
 */
void sox_calc(batt_clu_sox_data sox_data)
{
    uint8_t pack_num = auto_addressing_pack_num_get();
    sox_stats_t sox_stats = {0};
    sox_stats_get(&sox_stats);
    if (sox_data.max_batt_clu_calc_soc == SOX_INVALID_VAL || sox_data.min_batt_clu_display_soh == SOX_INVALID_VAL ||
        sox_data.max_batt_clu_display_soc == SOX_INVALID_VAL)
    {
        return;
    }
    if ((sox_data.min_batt_clu_display_soc + MAX_DISPLAY_SOC_VAL) <= sox_data.max_batt_clu_display_soc)
    {
        g_batt_cluster_sox.batt_clu_display_soc = 0;
    }
    else
    {
        g_batt_cluster_sox.batt_clu_display_soc = 
            sox_data.min_batt_clu_display_soc * 100 / (sox_data.min_batt_clu_display_soc + MAX_DISPLAY_SOC_VAL - sox_data.max_batt_clu_display_soc); // 单位1%
    }

    g_batt_cluster_sox.batt_clu_display_soh = sox_data.min_batt_clu_display_soh;

    if ((sox_data.min_batt_clu_calc_soc + MAX_CALC_SOC_VAL) <= sox_data.max_batt_clu_calc_soc)
    {
        g_batt_cluster_sox.batt_clu_calc_soc = 0;
    }
    else
    {
        g_batt_cluster_sox.batt_clu_calc_soc = 
            sox_data.min_batt_clu_calc_soc * 1000 / (sox_data.min_batt_clu_calc_soc + MAX_CALC_SOC_VAL - sox_data.max_batt_clu_calc_soc); // 单位0.1%
    }
    g_batt_cluster_sox.batt_clu_calc_soh = sox_data.min_batt_clu_calc_soh;
    g_batt_cluster_sox.batt_clu_remain_cap = g_batt_cluster_sox.batt_clu_display_soc * g_batt_cluster_sox.batt_clu_display_soh * RATED_CAPACITY_OF_BATT / 10000;
    g_batt_cluster_sox.batt_clu_real_cap = g_batt_cluster_sox.batt_clu_display_soh * RATED_CAPACITY_OF_BATT / 10000;
    g_batt_cluster_sox.batt_clu_ah_chg = sox_stats.sumed_chg_ah;
    g_batt_cluster_sox.batt_clu_mas_chg = sox_stats.sumed_chg_mA_s;
    g_batt_cluster_sox.batt_clu_ah_dsg = sox_stats.sumed_dsg_ah;
    g_batt_cluster_sox.batt_clu_mas_dsg = sox_stats.sumed_dsg_mA_s;
    g_batt_cluster_sox.batt_clu_wh_chg = sox_stats.sumed_chg_wh;
    g_batt_cluster_sox.batt_clu_mws_chg = sox_stats.sumed_chg_mW_s;
    g_batt_cluster_sox.batt_clu_wh_dsg = sox_stats.sumed_dsg_wh;
    g_batt_cluster_sox.batt_clu_mws_dsg = sox_stats.sumed_dsg_mW_s;
    g_batt_cluster_sox.batt_clu_cycle_count = sox_stats.sumed_display_cycle;
}

/**
 * @brief                电池簇SOX数据初始化
 * @param                [in]void
 * @warning              用于初始化SOX模块
 */
void sox_init(void)
{
    g_batt_cluster_sox.batt_clu_display_soc = SOX_INVALID_VAL;
    g_batt_cluster_sox.batt_clu_display_soh = SOX_INVALID_VAL;
    g_batt_cluster_sox.batt_clu_calc_soc = SOX_INVALID_VAL;
    g_batt_cluster_sox.batt_clu_calc_soh = SOX_INVALID_VAL;

    g_sox_run_timer_b100ms = SOX_RUN_SAVE_TIMER / 2;        // 第一次提前15min
    
    sox_stats_data_init();
}

/**
 * @brief                电池簇SOX计算处理函数
 * @param                [in]void
 * @warning              100ms任务内运行，
 * @warning              自动编址完成等待1s时间，1s后续可调整；主要是保证所有电池包都正常上报SOX数据
 */
void sox_proc_deal(void)
{
#ifdef SOX_DEBUG_TEST
    if (g_sox_debug_flag)
    {
        return;
    }
#endif
    uint8_t pack_num = auto_addressing_pack_num_get();
    static uint8_t delay_time = SOX_INIT_DELAY_B100MS;
    if (0 == pack_num)  // 没有完成自动编址或者没有连接电池包，上报无效值
    {
        sox_init();
        delay_time = SOX_INIT_DELAY_B100MS;
        return;
    }
    if (delay_time > 0)
    {
        delay_time--;
        return;
    }
    static int32_t counter_sox_stats = 0;
    pack_info_t* pack_info = NULL;
    uint16_t display_soc = SOX_INVALID_VAL;
    uint16_t display_soh = SOX_INVALID_VAL;
    uint16_t calc_soc = SOX_INVALID_VAL;
    uint16_t calc_soh = SOX_INVALID_VAL;
    uint16_t cycle_count = SOX_INVALID_VAL;
    uint32_t cap_chg = SOX_INVALID_VAL;
    uint32_t cap_dsg = SOX_INVALID_VAL;
    uint32_t wh_chg = SOX_INVALID_VAL;
    uint32_t wh_dsg = SOX_INVALID_VAL;
    batt_clu_sox_data batt_cluster_sox_data = {SOX_INVALID_VAL};
    bool get_first_flag = false;
    for (uint8_t i = 0; i < pack_num; i++)
    {
        pack_info = get_bmu_info(i);
        if (NULL == pack_info)
        {
            continue;
        }
        if (SOX_INVALID_VAL == pack_info->yc2[YC2_UNS_PACK_SOC] || 
            SOX_INVALID_VAL == pack_info->yc2[YC2_UNS_PACK_SOH])
        {
            continue;
        }
        display_soc = pack_info->yc2[YC2_UNS_PACK_SOC] / 10;
        display_soh = pack_info->yc2[YC2_UNS_PACK_SOH] / 10;   //当前电池包SOH按0.1%发送过来
        calc_soc = pack_info->yc2[YC2_UNS_PACK_SOC];  // 当前没有计算值SOC值接口，后面需要补充
        calc_soh = pack_info->yc2[YC2_UNS_PACK_SOH];  // 当前没有计算值SOh值接口，后面需要补充
        cycle_count = pack_info->yc2[YC2_UNS_CYCLE_TIME];
        cap_chg = pack_info->yc3[YC3_UNS_TOTAL_CHG_CAP_AH];
        cap_dsg = pack_info->yc2[YC3_UNS_TOTAL_DSG_CAP_AH];
        wh_chg = pack_info->yc3[YC3_UNS_TOTAL_CHG_CAP_WH];
        wh_dsg = pack_info->yc2[YC3_UNS_TOTAL_DSG_CAP_WH];
        
        batt_cluster_sox_data.get_batt_clu_cap_chg += cap_chg;
        batt_cluster_sox_data.get_batt_clu_cap_dsg += cap_dsg;
        batt_cluster_sox_data.get_batt_clu_wh_chg  += wh_chg;
        batt_cluster_sox_data.get_batt_clu_wh_chg  += wh_dsg;

        if (!get_first_flag)
        {
            get_first_flag = true;
            batt_cluster_sox_data.min_batt_clu_display_soc = display_soc; 
            batt_cluster_sox_data.max_batt_clu_display_soc = display_soc; 
            batt_cluster_sox_data.min_batt_clu_display_soh = display_soh; 
            batt_cluster_sox_data.min_batt_clu_calc_soc = calc_soc;
            batt_cluster_sox_data.max_batt_clu_calc_soc = calc_soc;
            batt_cluster_sox_data.min_batt_clu_calc_soh = calc_soh;
            batt_cluster_sox_data.min_batt_clu_cycle_count = cycle_count;
            continue;
        }
        if (batt_cluster_sox_data.min_batt_clu_display_soc > display_soc)
        {
            batt_cluster_sox_data.min_batt_clu_display_soc = display_soc;
        }
        if (batt_cluster_sox_data.max_batt_clu_display_soc < display_soc)
        {
            batt_cluster_sox_data.max_batt_clu_display_soc = display_soc;
        }
        if (batt_cluster_sox_data.min_batt_clu_display_soh > display_soh)
        {
            batt_cluster_sox_data.min_batt_clu_display_soh = display_soh;
        }
        if (batt_cluster_sox_data.min_batt_clu_calc_soc > calc_soc)
        {
            batt_cluster_sox_data.min_batt_clu_calc_soc = calc_soc;
        }
        if (batt_cluster_sox_data.max_batt_clu_calc_soc < calc_soc)
        {
            batt_cluster_sox_data.max_batt_clu_calc_soc = calc_soc;
        }
        if (batt_cluster_sox_data.min_batt_clu_calc_soh > calc_soh)
        {
            batt_cluster_sox_data.min_batt_clu_calc_soh = calc_soh;
        }
        if (batt_cluster_sox_data.min_batt_clu_cycle_count > cycle_count)
        {
            batt_cluster_sox_data.min_batt_clu_cycle_count = cycle_count;
        }
    }
    if (get_first_flag)
    {
        sox_calc(batt_cluster_sox_data);
        if (counter_sox_stats++ >= 9)
        {
            sox_stats_proc();
            counter_sox_stats = 0;
        }
        sox_running_data_cycle_save_deal();
    }
}

/**
 * @brief    获取SOP数据
 * @param    [in]void
 * @param    [out]batt_clu_sox*
 */
const batt_clu_sox* sox_data_get(void)
{
    return (const batt_clu_sox*)(&g_batt_cluster_sox);
}


#ifdef SOX_DEBUG_TEST

typedef enum
{
    DEBUG_VAL_DISPLAY_SOC = 0,                // 综合显示Soc，单位1%, 无效值位0xFFFF
    DEBUG_VAL_DISPLAY_SOH,                    // 综合显示Soh，单位1%, 无效值位0xFFFF
    DEBUG_VAL_CALC_SOC,                       // 综合计算Soc，单位0.1%, 无效值位0xFFFF
    DEBUG_VAL_CALC_SOH,                       // 综合计算Soh，单位0.1%, 无效值位0xFFFF
    DEBUG_VAL_NUM,
} sox_debug_e;

/**
 * @brief                电池簇SOX结果打印
 * @param                [in]void
 */
void sox_printf(void)
{
    log_e("soxDebug=%ld\n", g_sox_debug_flag);
    log_e("displaySoc=%d\n", g_batt_cluster_sox.batt_clu_display_soc);
    log_e("displaySoh=%d\n", g_batt_cluster_sox.batt_clu_display_soh);
    log_e("calcSoc=%d\n", g_batt_cluster_sox.batt_clu_calc_soc);
    log_e("calcSoh=%d\n", g_batt_cluster_sox.batt_clu_calc_soh);
    uint8_t pack_num = auto_addressing_pack_num_get();
    log_e("packNum=%d\n", pack_num);
    pack_info_t* pack_info = NULL;
    for (uint8_t i = 0; i < pack_num; i++)
    {
        pack_info = get_bmu_info(i);
        if (NULL == pack_info)
        {
            continue;
        }
        log_e("pack[%d]:", i);
        log_e("dSoc=%d,dSoh=%d\n", pack_info->yc2[YC2_UNS_PACK_SOC], pack_info->yc2[YC2_UNS_PACK_SOH]);
    }
}

/**
 * @brief                电池簇SOX错误打印
 * @param                [in]void
 */
void sox_debug_err_printf(void)
{
//    log_d(" sox_t param err\r\n");
//    log_d(" sox_t print : printf data\r\n");
//    log_d(" sox_t help : printf hlep data\r\n");
//    log_d(" sox_t val debug(0/1) val_id(0~%d) val: set analog data\r\n", DEBUG_VAL_NUM - 1);
}

/**
 * @brief                电池簇SOX打印提示
 * @param                [in]void
 */
void sox_debug_help_printf(void)
{
//    log_d("val_id:\n");
//    log_d("DEBUG_VAL_DISPLAY_SOC = %d\n", DEBUG_VAL_DISPLAY_SOC);
//    log_d("DEBUG_VAL_DISPLAY_SOH = %d\n", DEBUG_VAL_DISPLAY_SOH);
//    log_d("DEBUG_VAL_CALC_SOC    = %d\n", DEBUG_VAL_CALC_SOC);
//    log_d("DEBUG_VAL_CALC_SOH    = %d\n", DEBUG_VAL_CALC_SOH);
}

/**
 * @brief                电池簇SOX结果打印
 * @param                [in]debug_flag   设置参数标志0：不调，1：调试
 * @param                [in]type_id      参考sox_debug_e
 * @param                [in]set_data     设置SOX值
 */
void sox_debug_set(bool debug_flag, uint8_t type_id, uint16_t set_data)
{
    g_sox_debug_flag = debug_flag;
    if (!g_sox_debug_flag)
    {
        return;
    }
    switch (type_id)
    {
        case DEBUG_VAL_DISPLAY_SOC:
            g_batt_cluster_sox.batt_clu_display_soc = set_data;
            break;
        case DEBUG_VAL_DISPLAY_SOH:
            g_batt_cluster_sox.batt_clu_display_soh = set_data;
            break;
        case DEBUG_VAL_CALC_SOC:
            g_batt_cluster_sox.batt_clu_calc_soc = set_data;
            break;
        case DEBUG_VAL_CALC_SOH:
            g_batt_cluster_sox.batt_clu_calc_soh = set_data;
            break;
        default:
            break;
    }
}

/**
 * @brief        sox功能样例
 * @param        cmd 功能参数
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
static int sox(int argc, char *argv[])
{
    if (argc < 2)
    {
        log_d("soxParaErr\n");
        return SF_ERR_PARA;
    }
    if (!strcmp(argv[1], "print"))
    {
        sox_printf();
    }
    else if (!strcmp(argv[1], "val"))
    {
        if (argc < 5)
        {
            log_d("soxValErr\n");
            return SF_ERR_PARA;
        }
        uint32_t debug_flag = atoi(argv[2]);  // 设置参数1：debug标志（1使能，0取消）
        uint32_t val_id = atoi(argv[3]);      // 参数2: 模拟量sox_debug_e
        uint16_t value = atoi(argv[4]);        // 参数3：value值
        sox_debug_set(debug_flag, val_id, value);
    }
    else if (!strcmp(argv[1], "help"))
    {
        sox_debug_help_printf();
    }
    return 0; 
}
MSH_CMD_EXPORT(sox, <print/val debug(0-1) valId value>);
#endif

