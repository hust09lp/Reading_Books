/**
 * @file     sop.c
 * @brief    综合电池簇的SOP
 * @company  sofarsolar
 * @author   刘吕从
 * @note     Battery cluster
 * @version
 * @date     2023/5/30 初稿
 */
#include "sdk.h"
#include "sop.h"
#include "auto_addressing.h"
#include "inner_can_data.h"
#include "external_can_data.h"
#include "app_public.h"
#include "bms_state.h"
#include "relay_manage.h"
#include "external_can_data.h"
#include "bmu_data.h"
#include "data_store.h"

#define SOP_INIT_DELAY_B100MS (10)    // 延迟综合SOX数据，当前1s
#define RATED_CELL_VOLT (3200)
typedef struct 
{
    uint16_t min_batt_clu_limit_dsg_curr;  // 最小放电电流，单位0.1A，无效值0xFFFF
    uint16_t max_batt_clu_limit_dsg_curr;  // 最大放电电流，单位0.1A，无效值0xFFFF
    uint16_t min_batt_clu_limit_chg_curr;  // 最小充电电流，单位0.1A，无效值0xFFFF
    uint16_t max_batt_clu_limit_chg_curr;  // 最大充电电流，单位0.1A，无效值0xFFFF
} batt_clu_sop_data;

/**
 * @enum curr_direction_e
 * @brief 电流方向
 */
typedef enum
{
    CURR_DIR_CHARGE = 1,		///< 充电方向
    CURR_DIR_DISCHARGE,			///< 放电方向
}curr_direction_e;

static batt_clu_sop g_batt_cluster_sop = {0};  //当前时刻电池簇综合SOP
static bool g_limit_zero_chg_flag = false;
static bool g_limit_zero_dischg_flag = false;
static batt_clu_sop g_last_batt_clu_sop = {0}; //上一时刻电池簇综合SOP
#ifdef SOP_SHELL_DEBUG_TEST
static bool g_sop_shell_debug_flag = false;
#endif

/**
 * @brief                计算电池簇SOp
 * @param                [in]void
 * @warning              用于刷新电池簇SOP发生变化
 */
void sop_calc(batt_clu_sop_data sop_data)
{
    const bms_attr_t *bms_attr = get_bms_attr();

    g_batt_cluster_sop.batt_clu_limit_dsg_curr = sop_data.min_batt_clu_limit_dsg_curr;
    g_batt_cluster_sop.batt_clu_limit_chg_curr = sop_data.min_batt_clu_limit_chg_curr;
    g_batt_cluster_sop.batt_clu_limit_dsg_power = g_batt_cluster_sop.batt_clu_limit_dsg_curr * RATED_CELL_VOLT / 1000 * bms_attr->pack_cell_num * bms_attr->clu_pack_num;
    g_batt_cluster_sop.batt_clu_limit_chg_power = g_batt_cluster_sop.batt_clu_limit_chg_curr * RATED_CELL_VOLT / 1000 * bms_attr->pack_cell_num * bms_attr->clu_pack_num;
    //const bmu_data_unify_t *p_bmu_data_unify = bmu_data_unify_get();
   
    if ((g_batt_cluster_sop.batt_clu_limit_chg_curr != g_last_batt_clu_sop.batt_clu_limit_chg_curr)  ||
        (g_batt_cluster_sop.batt_clu_limit_dsg_curr != g_last_batt_clu_sop.batt_clu_limit_dsg_curr))
    {
    //    log_d("bat_clu_sop_is_changed!\n");
    //    log_d("bat_clu_last_chg_curr:%d,bat_clu_last_dsg_curr:%d,bat_clu_now_chg_curr:%d,bat_clu_now_dsg_curr:%d\n",
    //           g_last_batt_clu_sop.batt_clu_limit_chg_curr,g_last_batt_clu_sop.batt_clu_limit_dsg_curr,
    //           g_batt_cluster_sop.batt_clu_limit_chg_curr,g_batt_cluster_sop.batt_clu_limit_dsg_curr);
    //    log_d("CluMaxV:%d,CluMaxVPack:%d,CluMaxVNum:%d,CluMinV:%d,CluMinVPack:%d,CluMinVNum:%d\n",
    //           p_bmu_data_unify->batmaxcellvolt,p_bmu_data_unify->batmaxcellvoltpack,p_bmu_data_unify->batmaxcellvoltnum,
    //           p_bmu_data_unify->batmincellvolt,p_bmu_data_unify->batmincellvoltpack,p_bmu_data_unify->batmincellvoltnum);
    //    log_d("CluMaxT:%d, CluMaxTPack:%d,CluMaxTNum:%d,CluMinT:%d,CluMinTPack:%d, CluMinTNum:%d\n",
    //           p_bmu_data_unify->batmaxcelltemp,p_bmu_data_unify->batmaxcelltemppack,p_bmu_data_unify->batmaxcelltempnum,
    //           p_bmu_data_unify->batmincelltemp,p_bmu_data_unify->batmincelltemppack,p_bmu_data_unify->batmincelltempnum);
    }
    g_last_batt_clu_sop.batt_clu_limit_chg_curr = g_batt_cluster_sop.batt_clu_limit_chg_curr; //刷新上一时刻值
    g_last_batt_clu_sop.batt_clu_limit_dsg_curr = g_batt_cluster_sop.batt_clu_limit_dsg_curr; //刷新上一时刻值
}

/**
 * @brief                电池簇SOp数据初始化
 * @param                [in]void
 * @warning              用于初始化SOP模块
 */
void sop_init(void)
{
    g_batt_cluster_sop.batt_clu_limit_dsg_curr = 0;
    g_batt_cluster_sop.batt_clu_limit_chg_curr = 0;
    g_last_batt_clu_sop.batt_clu_limit_chg_curr = 0;
    g_last_batt_clu_sop.batt_clu_limit_dsg_curr = 0;
}

/**
 * @brief                判断sop变成0后，事件触发外can发送yc数据
 * @param                [in]void
 * @warning              10ms任务，需要较快响应
 */
void sop_zero_event_send_deal(void)
{
    const fault_stat_data_t *p_fault_data = fault_chg_dsg_level_get();
    if(PRE_SUCCESS != get_pre_charge_state() || BCU_STATE_RUN != bms_state_get_sys_sta())
    {
        sop_limit_curr_zero_set(CURR_DIR_CHARGE, true);     // 屏蔽充电电流
        sop_limit_curr_zero_set(CURR_DIR_DISCHARGE, true);  // 屏蔽放电电流
    }
    else
    {
        if(p_fault_data->max_charge_level <= LEVEL2)
        {
            sop_limit_curr_zero_set(CURR_DIR_CHARGE, true);     // 屏蔽充电电流
        }
        else
        {
            sop_limit_curr_zero_set(CURR_DIR_CHARGE, false);    // 恢复充电电流
        }
        if(p_fault_data->max_discharge_level <= LEVEL2)
        {
            sop_limit_curr_zero_set(CURR_DIR_DISCHARGE, true);  // 屏蔽放电电流
        }
        else
        {
            sop_limit_curr_zero_set(CURR_DIR_DISCHARGE, false);  // 恢复放电电流
        }
    }
    static batt_clu_sop last_sop = {SOP_INVALID_VAL};
    if ((0 != last_sop.batt_clu_limit_chg_curr && 0 == g_batt_cluster_sop.batt_clu_limit_chg_curr) ||
        (0 != last_sop.batt_clu_limit_dsg_curr && 0 == g_batt_cluster_sop.batt_clu_limit_dsg_curr))
    {
        log_e("[SOP]chg%d,dsg%d\n", g_batt_cluster_sop.batt_clu_limit_chg_curr, g_batt_cluster_sop.batt_clu_limit_dsg_curr);
        // event_send_ext_data(EXT_BCU_YC1_MSG);
        // event_send_ext_data(EXT_BCU_YC2_MSG);
        // TODO 后续补充 充放电限流值变化
        //ext_can_send_msg_ready(EXT_CAN_TX_BRO_BCU_REQ_CTL_STATE);
        //ext_can_send_msg_ready(EXT_CAN_TX_BRO_BCU_CHG_DSG_LIMIT);
    }
    last_sop = g_batt_cluster_sop;
}

/**
 * @brief                电池簇SOP计算处理函数
 * @param                [in]void
 * @warning              100ms任务内运行，
 * @warning              自动编址完成等待1s时间，1s后续可调整；主要是保证所有电池包都正常上报SOX数据
 */
void sop_calc_proc_deal(void)
{
#ifdef SOP_SHELL_DEBUG_TEST
    if (g_sop_shell_debug_flag)
    {
        return;
    }
#endif
    if (g_limit_zero_chg_flag && g_limit_zero_dischg_flag)
    {
        g_batt_cluster_sop.batt_clu_limit_dsg_curr = 0;
		g_batt_cluster_sop.batt_clu_limit_dsg_power = 0;
        g_batt_cluster_sop.batt_clu_limit_chg_curr = 0;
		g_batt_cluster_sop.batt_clu_limit_chg_power = 0;
        return;
    }
    uint8_t pack_num = auto_addressing_pack_num_get();
    static uint8_t delay_time = SOP_INIT_DELAY_B100MS;
    if (0 == pack_num)  // 没有完成自动编址或者没有连接电池包，上报无效值
    {
        sop_init();
        delay_time = SOP_INIT_DELAY_B100MS;
        return;
    }
    if (delay_time > 0)
    {
        delay_time--;
        return;
    }
    pack_info_t* pack_info = NULL;
    uint16_t dsg_curr_limit = SOP_INVALID_VAL;
    uint16_t chg_curr_limit = SOP_INVALID_VAL;
    batt_clu_sop_data batt_cluster_sop_data = {0};
    bool get_first_flag = false;
    for (uint8_t i = 0; i < pack_num; i++)
    {
        pack_info = get_bmu_info(i);
        if (NULL == pack_info)
        {
            continue;
        }

        dsg_curr_limit = MAKE_WORD(pack_info->yx[YX_BMU_DSG_CURR_LIMIT_L], pack_info->yx[YX_BMU_DSG_CURR_LIMIT_H]) / 10;  // 单位10mA转换为100mA
        chg_curr_limit = MAKE_WORD(pack_info->yx[YX_BMU_CHG_CURR_LIMIT_L], pack_info->yx[YX_BMU_CHG_CURR_LIMIT_H]) / 10;  // 单位10mA转换为100mA
        if (!get_first_flag)
        {
            get_first_flag = true;
            batt_cluster_sop_data.min_batt_clu_limit_dsg_curr = dsg_curr_limit; 
            batt_cluster_sop_data.max_batt_clu_limit_dsg_curr = dsg_curr_limit; 
            batt_cluster_sop_data.min_batt_clu_limit_chg_curr = chg_curr_limit; 
            batt_cluster_sop_data.max_batt_clu_limit_chg_curr = chg_curr_limit;
            continue;
        }
        if(!g_limit_zero_chg_flag)
        {
            if (batt_cluster_sop_data.min_batt_clu_limit_chg_curr > chg_curr_limit)
            {
                batt_cluster_sop_data.min_batt_clu_limit_chg_curr = chg_curr_limit;
            }
            if (batt_cluster_sop_data.max_batt_clu_limit_chg_curr < chg_curr_limit)
            {
                batt_cluster_sop_data.max_batt_clu_limit_chg_curr = chg_curr_limit;
            }
        }
        else
        {
            batt_cluster_sop_data.min_batt_clu_limit_chg_curr = 0;
            batt_cluster_sop_data.max_batt_clu_limit_chg_curr = 0;
        }
        if(!g_limit_zero_dischg_flag)
        {
            if (batt_cluster_sop_data.min_batt_clu_limit_dsg_curr > dsg_curr_limit)
            {
                batt_cluster_sop_data.min_batt_clu_limit_dsg_curr = dsg_curr_limit;
            }
            if (batt_cluster_sop_data.max_batt_clu_limit_dsg_curr < dsg_curr_limit)
            {
                batt_cluster_sop_data.max_batt_clu_limit_dsg_curr = dsg_curr_limit;
            }
        }
        else
        {
            batt_cluster_sop_data.min_batt_clu_limit_dsg_curr = 0;
            batt_cluster_sop_data.max_batt_clu_limit_dsg_curr = 0;
        }
    }
    if (get_first_flag)
    {
        sop_calc(batt_cluster_sop_data);
    }
}

/**
 * @brief                sop任务
 * @param                [in]void
 * @warning              100ms任务内运行，
 */
void sop_proc_deal(void)
{
    sop_calc_proc_deal();
}

/**
 * @brief   充放电限流为0，开关
 * @param   [in] uint8_t direction : CURR_DIR_CHARGE:充电方向  CURR_DIR_DISCHARGE:放电方向
 * @param   [in] bool set_zero_flag: true: 限流为0； false: 限流不为0
 */
void sop_limit_curr_zero_set(uint8_t direction, bool set_zero_flag)
{
#ifdef SOP_SHELL_DEBUG_TEST
    if (g_sop_shell_debug_flag)
    {
        return;
    }
#endif
    if (!set_zero_flag)
    {
        if (CURR_DIR_CHARGE == direction)
        {
            g_limit_zero_chg_flag = false;
        }
        else if (CURR_DIR_DISCHARGE == direction)
        {
            g_limit_zero_dischg_flag = false;
        }
    }
    else
    {
        if (CURR_DIR_CHARGE == direction)
        {
            g_limit_zero_chg_flag = true;
        }
        else if (CURR_DIR_DISCHARGE == direction)
        {
            g_limit_zero_dischg_flag = true;
        }
    }

}


/**
 * @brief    获取SOP数据
 * @param    [in]void
 * @param    [out]batt_clu_sop*
 */
const batt_clu_sop* sop_data_get(void)
{
    return (const batt_clu_sop*)(&g_batt_cluster_sop);
}

#ifdef SOP_SHELL_DEBUG_TEST

typedef enum
{
    DEBUG_VAL_LIMIT_DSG_CURR = 0,                // 综合放电上限，单位0.1A, 无效值位0xFFFF
    DEBUG_VAL_LIMIT_CHG_CURR,                    // 综合充电上限，单位0.1A, 无效值位0xFFFF
    DEBUG_VAL_LIMIT_ZERO_FLAG,                   // 设置电流为0的开关， true：启动充放电限流为0； false: 关闭充放电限流为0
    DEBUG_VAL_NUM,
} sop_debug_e;

/**
 * @brief                电池簇SOP结果打印
 * @param                [in]void
 */
void sop_printf(void)
{
    log_e("sopDebug=%ld\n", g_sop_shell_debug_flag);
    log_e("chgZ%d,dsgZ%d\n", g_limit_zero_chg_flag, g_limit_zero_dischg_flag);
    log_e("limDsgCur=%d\n", g_batt_cluster_sop.batt_clu_limit_dsg_curr);
    log_e("limChgCur=%d\n", g_batt_cluster_sop.batt_clu_limit_chg_curr);
    log_e("limDsgPower=%d\n", g_batt_cluster_sop.batt_clu_limit_dsg_power);
    log_e("limChgPower=%d\n", g_batt_cluster_sop.batt_clu_limit_chg_power);   
    uint8_t pack_num = auto_addressing_pack_num_get();
    log_e("packNum=%d\n", pack_num);
    pack_info_t* pack_info = NULL;
    uint16_t dsg_curr_limit = 0;
    uint16_t chg_curr_limit = 0;
    for (uint8_t i = 0; i < pack_num; i++)
    {
        pack_info = get_bmu_info(i);
        if (NULL == pack_info)
        {
            continue;
        }
        log_e("pack[%d]:", i);
        
        dsg_curr_limit = MAKE_WORD(pack_info->yx[YX_BMU_DSG_CURR_LIMIT_L], pack_info->yx[YX_BMU_DSG_CURR_LIMIT_H]); 
        chg_curr_limit = MAKE_WORD(pack_info->yx[YX_BMU_CHG_CURR_LIMIT_L], pack_info->yx[YX_BMU_CHG_CURR_LIMIT_H]); 
        log_e("limitDsgCur=%d(0.1A),limitChgCur=%d(0.1A)\n", dsg_curr_limit, chg_curr_limit);
    }
}

/**
 * @brief                电池簇SOX错误打印
 * @param                [in]void
 */
void sop_debug_err_printf(void)
{
//    log_d(" sop_t param err\r\n");
//    log_d(" sop_t print : printf data\r\n");
//    log_d(" sop_t help : printf hlep data\r\n");
//    log_d(" sop_t val debug(0/1) val_id(0~%d) val: set analog data\r\n", DEBUG_VAL_NUM - 1);
}

/**
 * @brief                电池簇SOP打印提示
 * @param                [in]void
 */
void sop_debug_help_printf(void)
{
//    log_d("val_id:\n");
//    log_d("DEBUG_VAL_LIMIT_DSG_CURR  = %d\n", DEBUG_VAL_LIMIT_DSG_CURR);
//    log_d("DEBUG_VAL_LIMIT_CHG_CURR  = %d\n", DEBUG_VAL_LIMIT_CHG_CURR);
//    log_d("DEBUG_VAL_LIMIT_ZERO_FLAG = %d\n", DEBUG_VAL_LIMIT_ZERO_FLAG);
}

/**
 * @brief                电池簇SOP结果打印
 * @param                [in]debug_flag   设置参数标志0：不调，1：调试
 * @param                [in]type_id      参考sop_debug_e
 * @param                [in]set_data     设置SOP值
 */
void sop_debug_set(bool debug_flag, uint8_t type_id, uint16_t set_data)
{
    g_sop_shell_debug_flag = debug_flag;
    if (!g_sop_shell_debug_flag)
    {
        return;
    }
    const bms_attr_t *bms_attr = get_bms_attr();
    switch (type_id)
    {
        case DEBUG_VAL_LIMIT_DSG_CURR:
            g_batt_cluster_sop.batt_clu_limit_dsg_curr = set_data;
            g_batt_cluster_sop.batt_clu_limit_dsg_power = g_batt_cluster_sop.batt_clu_limit_dsg_curr * RATED_CELL_VOLT / 1000 * bms_attr->pack_cell_num * bms_attr->clu_pack_num;
            break;
        case DEBUG_VAL_LIMIT_CHG_CURR:
            g_batt_cluster_sop.batt_clu_limit_chg_curr = set_data;
            g_batt_cluster_sop.batt_clu_limit_chg_power = g_batt_cluster_sop.batt_clu_limit_chg_curr * RATED_CELL_VOLT / 1000 * bms_attr->pack_cell_num * bms_attr->clu_pack_num;
            break;
        case DEBUG_VAL_LIMIT_ZERO_FLAG:
            g_limit_zero_dischg_flag = set_data;
            g_limit_zero_chg_flag = set_data;
            break;
        default:
            break;
    }
}

/**
 * @brief        sop功能样例
 * @param        cmd 功能参数
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
static int sop(int argc, char *argv[])
{
    if (argc < 2)
    {
        log_d("sopParaErr\n");
        return SF_ERR_PARA;
    }
    if (!strcmp(argv[1], "print"))
    {
        sop_printf();
    }
    else if (!strcmp(argv[1], "val"))
    {
        if (argc < 5)
        {
            log_d("sopParaErr\n");
            return SF_ERR_PARA;
        }
        uint32_t debug_flag = atoi(argv[2]);  // 设置参数1：debug标志（1使能，0取消）
        uint32_t val_id = atoi(argv[3]);      // 参数2: 模拟量sop_debug_e
        uint16_t value = atoi(argv[4]);        // 参数3：value值
        sop_debug_set(debug_flag, val_id, value);
    }
    else if (!strcmp(argv[1], "help"))
    {
        sop_debug_help_printf();
    }
    return 0; 
}
MSH_CMD_EXPORT(sop, <print/val debug(0-1) valId value>);
#endif
