/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-07-06     thread-liu   first version
 */

#include "board.h"
#include "drv_fdcan.h"

#ifdef RT_USING_CAN

//#define DRV_DEBUG
#define LOG_TAG             "drv.fdcan"
#include <drv_log.h>

#if !defined(BSP_USING_FDCAN1) && !defined(BSP_USING_FDCAN2) && !defined(BSP_USING_FDCAN3)
#error "Please define at least one BSP_USING_UARTx"
/* this driver can be disabled at menuconfig -> RT-Thread Components -> Device Drivers */
#endif


struct stm32_fd_baud_rate_tab
{
	uint32_t baud_rate;

	uint8_t B_SJW;
	uint8_t B_SEG1;
	uint8_t B_SEG2;
	uint8_t B_PRSCAL;
	
};

struct stm32_lite_fdcan
{
    struct rt_can_device device;
    FDCAN_HandleTypeDef CanHandle;
	char *name;
    FDCAN_FilterTypeDef FilterConfig;
};

/* PeriphClkInitStruct.FdcanClockSelection = RCC_FDCANCLKSOURCE_PLL1Q;=160MHz*/
static const struct stm32_fd_baud_rate_tab can_baud_rate_tab[] =
{
    {CAN500kBaud,   16,  31, 8, 2},
    {CAN250kBaud,   16,  31, 8, 4}, 
    {CAN125kBaud,   16,  31, 8, 8},
	{CAN1MBaud,     16,  31, 8, 1}
};

#define BAUD_DATA(TYPE,NO)       ((can_baud_rate_tab[NO].B_##TYPE))

#ifdef BSP_USING_FDCAN1
static struct stm32_lite_fdcan drv_can1 =
{
    .name = "can1",
    .CanHandle.Instance = FDCAN1,
    .CanHandle.Init = {0},
};
#endif

#ifdef BSP_USING_FDCAN2
static struct stm32_lite_fdcan drv_can2 =
{
    .name = "can2",
    .CanHandle.Instance = FDCAN2,
    .CanHandle.Init = {0},
};
#endif

#ifdef BSP_USING_FDCAN3
static struct stm32_lite_fdcan drv_can3 =
{
    .name = "can3",
    .CanHandle.Instance = FDCAN3,
    .CanHandle.Init = {0},
};
#endif

static rt_uint32_t get_can_baud_index(rt_uint32_t baud)
{
    rt_uint32_t len, index;

    len = sizeof(can_baud_rate_tab) / sizeof(can_baud_rate_tab[0]);
    for (index = 0; index < len; index++)
    {
        if (can_baud_rate_tab[index].baud_rate == baud)
            return index;
    }

    return 0; /* default baud is CAN500KBaud */
}

static uint32_t get_can_send_dlc(uint8_t send_len)
{
    uint32_t send_dlc;
    
    switch(send_len)
    {
        case 0:
            send_dlc = FDCAN_DLC_BYTES_0;
            break;  
        case 1:
            send_dlc = FDCAN_DLC_BYTES_1;
            break;
        case 2:
            send_dlc = FDCAN_DLC_BYTES_2;
            break;
        case 3:
            send_dlc = FDCAN_DLC_BYTES_3;
            break;
        case 4:
            send_dlc = FDCAN_DLC_BYTES_4;
            break;
        case 5:
            send_dlc = FDCAN_DLC_BYTES_5;
            break;
        case 6:
            send_dlc = FDCAN_DLC_BYTES_6;
            break;
        case 7:
            send_dlc = FDCAN_DLC_BYTES_7;
            break;
        case 8:
            send_dlc = FDCAN_DLC_BYTES_8;
            break;
        case 12:
            send_dlc = FDCAN_DLC_BYTES_12;
            break;
        case 16:
            send_dlc = FDCAN_DLC_BYTES_16;
            break;
        case 20:
            send_dlc = FDCAN_DLC_BYTES_20;
            break;
        case 24:
            send_dlc = FDCAN_DLC_BYTES_24;
            break;
        case 32:
            send_dlc = FDCAN_DLC_BYTES_32;
            break;
        case 48:
            send_dlc = FDCAN_DLC_BYTES_48;
            break;
        case 64:
            send_dlc = FDCAN_DLC_BYTES_64;
            break;
        default:
            send_dlc = FDCAN_DLC_BYTES_8;
            break;
    }
    return send_dlc;
}

static uint8_t get_can_rcv_len(uint32_t rcv_dlc)
{
    uint8_t rcv_len;
    
    switch(rcv_dlc)
    {
        case FDCAN_DLC_BYTES_0:
            rcv_len     = 0;
            break;  
        case FDCAN_DLC_BYTES_1:
            rcv_len     = 1;
            break;
        case FDCAN_DLC_BYTES_2:
            rcv_len     = 2;
            break;
        case FDCAN_DLC_BYTES_3:
            rcv_len     = 3;
            break;
        case FDCAN_DLC_BYTES_4:
            rcv_len     = 4;
            break;
        case FDCAN_DLC_BYTES_5:
            rcv_len     = 5;
            break;
        case FDCAN_DLC_BYTES_6:
            rcv_len     = 6;
            break;
        case FDCAN_DLC_BYTES_7:
            rcv_len     = 7;
            break;
        case FDCAN_DLC_BYTES_8:
            rcv_len     = 8;
            break;
        case FDCAN_DLC_BYTES_12:
            rcv_len     = 12;
            break;
        case FDCAN_DLC_BYTES_16:
            rcv_len     = 16;
            break;
        case FDCAN_DLC_BYTES_20:
            rcv_len     = 20;
            break;
        case FDCAN_DLC_BYTES_24:
            rcv_len     = 24;
            break;
        case FDCAN_DLC_BYTES_32:
            rcv_len     = 32;
            break;
        case FDCAN_DLC_BYTES_48:
            rcv_len     = 48;
            break;
        case FDCAN_DLC_BYTES_64:
            rcv_len     = 64;
            break;
        default:
            rcv_len     = 8;
            break;
    }
    return rcv_len;
}


static rt_err_t stm32_lite_can_config(struct rt_can_device *can, struct can_configure *cfg)
{
    rt_uint32_t baud_index;

    FDCAN_HandleTypeDef *phcan;
    FDCAN_FilterTypeDef *phcan_filter;    
    struct stm32_lite_fdcan *drv_can;
	
	RT_ASSERT(can != NULL);
	RT_ASSERT(cfg != NULL);
	drv_can = (struct stm32_lite_fdcan *)can;
    RT_ASSERT(drv_can != NULL);

	phcan = (FDCAN_HandleTypeDef *)&drv_can->CanHandle;

//	phcan->Instance					= phcan->Instance;
	phcan->Init.ClockDivider 		= FDCAN_CLOCK_DIV1;
	phcan->Init.FrameFormat			= FDCAN_FRAME_CLASSIC;	// FDCAN_FRAME_FD_BRS
	phcan->Init.AutoRetransmission	= ENABLE;
	phcan->Init.TransmitPause		= ENABLE;
	phcan->Init.ProtocolException	= DISABLE;			// DISABLE
	phcan->Init.NominalSyncJumpWidth = 16;

	
    baud_index = get_can_baud_index(cfg->baud_rate);
    phcan->Init.NominalSyncJumpWidth = BAUD_DATA(SJW, baud_index);
    phcan->Init.NominalTimeSeg1      = BAUD_DATA(SEG1, baud_index);
    phcan->Init.NominalTimeSeg2      = BAUD_DATA(SEG2, baud_index);
    phcan->Init.NominalPrescaler     = BAUD_DATA(PRSCAL, baud_index);
	phcan->Init.DataPrescaler		= 6;
	phcan->Init.DataSyncJumpWidth	= 16;
	phcan->Init.DataTimeSeg1 		= 63; /* DataTimeSeg1 = Propagation_segment + Phase_segment_1 */
	phcan->Init.DataTimeSeg2 		= 16;
	
	
	phcan->Init.StdFiltersNbr		= 28;
	phcan->Init.ExtFiltersNbr		= 8;
	phcan->Init.TxFifoQueueMode		= FDCAN_TX_FIFO_OPERATION;

    switch (cfg->mode)
    {
    case RT_CAN_MODE_NORMAL:
        phcan->Init.Mode = FDCAN_MODE_NORMAL;
        break;
    case RT_CAN_MODE_LISTEN:
        phcan->Init.Mode = FDCAN_MODE_BUS_MONITORING;
        break;
    case RT_CAN_MODE_LOOPBACK:
        phcan->Init.Mode = FDCAN_MODE_INTERNAL_LOOPBACK;
        break;
    case RT_CAN_MODE_LOOPBACKANLISTEN:
        phcan->Init.Mode = FDCAN_MODE_EXTERNAL_LOOPBACK;
        break;
    }
	/*backup the user cfg,for busoff can reinit*/ 
	can->config.baud_rate = cfg->baud_rate;
    can->config.mode = cfg->mode;

    /* init can */
    if (HAL_FDCAN_Init(phcan) != HAL_OK)
    {
        return -RT_ERROR;
    }

    /* default filter config */
    phcan_filter = (FDCAN_FilterTypeDef *)&drv_can->FilterConfig;
    
    phcan_filter->IdType = FDCAN_STANDARD_ID;
    HAL_FDCAN_ConfigFilter(phcan, phcan_filter); 
    
    phcan_filter->IdType = FDCAN_EXTENDED_ID;
    HAL_FDCAN_ConfigFilter(phcan, phcan_filter); 

	if (HAL_FDCAN_ConfigGlobalFilter(phcan, FDCAN_REJECT, FDCAN_REJECT, FDCAN_FILTER_REMOTE, FDCAN_FILTER_REMOTE) != HAL_OK)
	{
		return -RT_ERROR;
	}
	if (HAL_FDCAN_ActivateNotification(phcan, FDCAN_IT_RX_FIFO0_NEW_MESSAGE,0) != HAL_OK)
    {
		return -RT_ERROR;
	}
	if (HAL_FDCAN_ActivateNotification(phcan, FDCAN_IT_RX_FIFO1_NEW_MESSAGE,0) != HAL_OK)
    {
		return -RT_ERROR;
	}    
    if (HAL_FDCAN_ConfigTxDelayCompensation(phcan, 5, 0) != HAL_OK)
	{
		return -RT_ERROR;
	}
	if (HAL_FDCAN_EnableTxDelayCompensation(phcan) != HAL_OK)
	{
		return -RT_ERROR;
	}
    
    /* can start */
    HAL_FDCAN_Start(phcan);
	
    return RT_EOK;
}

static rt_err_t stm32_lite_can_control(struct rt_can_device *can, int cmd, void *arg)
{
    rt_uint32_t argval;
    //struct rt_can_filter_config filter_cfg={0};
	FDCAN_HandleTypeDef *phcan;
    struct stm32_lite_fdcan *drv_can;
	
	RT_ASSERT(can != NULL);
	drv_can = (struct stm32_lite_fdcan *)can;
    RT_ASSERT(drv_can != NULL);

	phcan = &drv_can->CanHandle;


    switch (cmd)
    {
    case RT_DEVICE_CTRL_CLR_INT:
        argval = (rt_uint32_t) arg;
        if (argval == RT_DEVICE_FLAG_INT_RX)
        {
		#ifdef BSP_USING_FDCAN1
            if (FDCAN1 == phcan->Instance)
            {
                HAL_NVIC_DisableIRQ(FDCAN1_IT0_IRQn);
                HAL_NVIC_DisableIRQ(FDCAN1_IT1_IRQn);			
            }
		#endif
		#ifdef BSP_USING_FDCAN2
            if (FDCAN2 == phcan->Instance)
            {
                HAL_NVIC_DisableIRQ(FDCAN2_IT0_IRQn);
                HAL_NVIC_DisableIRQ(FDCAN2_IT1_IRQn);
            }
		#endif
		#ifdef BSP_USING_FDCAN3
            if (FDCAN3 == phcan->Instance)
            {
                HAL_NVIC_DisableIRQ(FDCAN3_IT0_IRQn);
                HAL_NVIC_DisableIRQ(FDCAN3_IT1_IRQn);
            }
		#endif
            __HAL_FDCAN_DISABLE_IT(phcan, FDCAN_IT_RX_FIFO0_NEW_MESSAGE);
        	__HAL_FDCAN_DISABLE_IT(phcan, FDCAN_IT_RX_FIFO0_FULL);
			__HAL_FDCAN_DISABLE_IT(phcan, FDCAN_IT_RX_FIFO1_NEW_MESSAGE);
            __HAL_FDCAN_DISABLE_IT(phcan, FDCAN_IT_RX_FIFO1_FULL);
        }
        else if (argval == RT_DEVICE_FLAG_INT_TX)
        {

        }
        else if (argval == RT_DEVICE_CAN_INT_ERR)
        {

        }
        break;
    case RT_DEVICE_CTRL_SET_INT:
        argval = (rt_uint32_t) arg;
        if (argval == RT_DEVICE_FLAG_INT_RX)
        {
		#ifdef BSP_USING_FDCAN1
            if (FDCAN1 == phcan->Instance)
            {
                //HAL_NVIC_SetPriority(FDCAN1_IT0_IRQn, 1, 0);
                HAL_NVIC_EnableIRQ(FDCAN1_IT0_IRQn);
                //HAL_NVIC_SetPriority(FDCAN1_IT1_IRQn, 1, 0);
//                HAL_NVIC_EnableIRQ(FDCAN1_IT1_IRQn);
            }
		#endif
		#ifdef BSP_USING_FDCAN2
            if (FDCAN2 == phcan->Instance)
            {
                //HAL_NVIC_SetPriority(FDCAN2_IT0_IRQn, 1, 0);
                HAL_NVIC_EnableIRQ(FDCAN2_IT0_IRQn);
                //HAL_NVIC_SetPriority(FDCAN2_IT0_IRQn, 1, 0);
//                HAL_NVIC_EnableIRQ(FDCAN2_IT1_IRQn);
            }
		#endif
		#ifdef BSP_USING_FDCAN3
            if (FDCAN3 == phcan->Instance)
            {
                //HAL_NVIC_SetPriority(FDCAN2_IT0_IRQn, 1, 0);
                HAL_NVIC_EnableIRQ(FDCAN3_IT0_IRQn);
                //HAL_NVIC_SetPriority(FDCAN2_IT0_IRQn, 1, 0);
//                HAL_NVIC_EnableIRQ(FDCAN3_IT1_IRQn);
            }
		#endif
			__HAL_FDCAN_ENABLE_IT(phcan, FDCAN_IT_RX_FIFO0_NEW_MESSAGE);
			__HAL_FDCAN_ENABLE_IT(phcan, FDCAN_IT_RX_FIFO0_FULL);
			__HAL_FDCAN_ENABLE_IT(phcan, FDCAN_IT_RX_FIFO1_NEW_MESSAGE);
			__HAL_FDCAN_ENABLE_IT(phcan, FDCAN_IT_RX_FIFO1_FULL);
        }
        else if (argval == RT_DEVICE_FLAG_INT_TX)
        {

        }
        else if (argval == RT_DEVICE_CAN_INT_ERR)
        {

        }
        break;
    case RT_CAN_CMD_SET_FILTER:
    {
		FDCAN_FilterTypeDef FilterConfig = {0};
        uint8_t StdFilterIndex = 0,ExtFilterIndex = 0;
        struct rt_can_filter_config * filter_cfg;
        if (NULL == arg)
        {
			return RT_EINVAL;
        }
        else
        {
            filter_cfg = (struct rt_can_filter_config *)arg;
            /* get default filter */
            for (int i = 0; i < filter_cfg->count; i++)
            {
                if (filter_cfg->items[i].hdr == -1)
                {
                    if (filter_cfg->items[i].ide == RT_CAN_STDID)
                    {
                        FilterConfig.FilterIndex = StdFilterIndex++;    
                    }
                    else
                    {
                        FilterConfig.FilterIndex = ExtFilterIndex++;   
                    }
                }
                else
                {
                    /* use user-defined filter bank settings */
                    FilterConfig.FilterIndex = filter_cfg->items[i].hdr;
                }
				
				if (filter_cfg->items[i].mode == 0x00)
                {
                    FilterConfig.FilterType = FDCAN_FILTER_DUAL;
                }
				else if (filter_cfg->items[i].mode == 0x01)
                {
                    FilterConfig.FilterType = FDCAN_FILTER_MASK;
                }
				else
				{
                    FilterConfig.FilterType = FDCAN_FILTER_MASK;
                }	
				
                if (filter_cfg->items[i].ide == RT_CAN_STDID)
                {
                    FilterConfig.FilterID1 = filter_cfg->items[i].id & 0x7FF;
                    FilterConfig.FilterID2 = filter_cfg->items[i].mask & 0x7FF;

					FilterConfig.IdType    = FDCAN_STANDARD_ID;

                }
                else if (filter_cfg->items[i].ide == RT_CAN_EXTID)
                {
                    FilterConfig.FilterID1 = filter_cfg->items[i].id & 0x1FFFFFF; 
                    FilterConfig.FilterID2 = filter_cfg->items[i].mask & 0x1FFFFFF;
                    
					FilterConfig.IdType    = FDCAN_EXTENDED_ID;
                }
                
                if(i%2 == 0)
                {
					FilterConfig.FilterConfig = FDCAN_FILTER_TO_RXFIFO0;                    
                }
                else
                {
					FilterConfig.FilterConfig = FDCAN_FILTER_TO_RXFIFO1;                       
                }
                
                HAL_FDCAN_ConfigFilter(phcan, &FilterConfig);
            }
        }
        break;
    }
    case RT_CAN_CMD_SET_MODE:
		argval = (rt_uint32_t) arg;
        if (argval != RT_CAN_MODE_NORMAL &&
                argval != RT_CAN_MODE_LISTEN &&
                argval != RT_CAN_MODE_LOOPBACK &&
                argval != RT_CAN_MODE_LOOPBACKANLISTEN)
        {
            return -RT_ERROR;
        }
        if (argval != drv_can->device.config.mode)
        {
            drv_can->device.config.mode = argval;
            return stm32_lite_can_config(&drv_can->device, &drv_can->device.config);
        }
        break;
    case RT_CAN_CMD_SET_BAUD:
        argval = (rt_uint32_t) arg;
        if (argval != CAN1MBaud &&
                argval != CAN500kBaud &&
                argval != CAN250kBaud &&
                argval != CAN125kBaud 
                )
        {
            return -RT_ERROR;
        }
        if (argval != drv_can->device.config.baud_rate)
        {
            drv_can->device.config.baud_rate = argval;
            return stm32_lite_can_config(&drv_can->device, &drv_can->device.config);
        }
        break;

    case RT_CAN_CMD_GET_STATUS:
    {
        rt_uint32_t errtype;
        errtype = phcan->Instance->ECR;
        drv_can->device.status.rcverrcnt = ((errtype >> 8) & 0x7F);
        drv_can->device.status.snderrcnt = (errtype  & 0xFF);

		errtype = phcan->Instance->PSR;
        drv_can->device.status.errcode = ((errtype >> 7) & 0x01) << 3;//BUS OFF

        rt_memcpy(arg, &drv_can->device.status, sizeof(drv_can->device.status));
    }
    break;
    }

    return RT_EOK;
}

static int stm32_lite_can_recvmsg(struct rt_can_device *can, void *buffer, uint32_t fifo)
{
	FDCAN_RxHeaderTypeDef rxheader = {0};
	struct rt_can_msg *pmsg;
	FDCAN_HandleTypeDef *phcan;
    struct stm32_lite_fdcan *drv_can;
	
	RT_ASSERT(can != NULL);
	drv_can = (struct stm32_lite_fdcan *)can;
    RT_ASSERT(drv_can != NULL);

	phcan = &drv_can->CanHandle;

	pmsg = (struct rt_can_msg *) buffer;
	
    if (HAL_FDCAN_GetRxMessage(phcan, fifo, &rxheader, (uint8_t *)pmsg->data) != HAL_OK)
    {
        LOG_E("get msg error from fdcan fifo0!");
        return RT_ERROR;
    }
    	
	pmsg->id = rxheader.Identifier;
	pmsg->len = get_can_rcv_len(rxheader.DataLength);
	if(rxheader.IdType == FDCAN_EXTENDED_ID)
		pmsg->ide = RT_CAN_EXTID;
	else
		pmsg->ide = RT_CAN_STDID;
    return RT_EOK;
}

uint32_t g_can_new_msg_cnt[3] = {0};
uint32_t g_can_full_cnt[3] = {0};
uint32_t g_can_msg_lost_cnt[3] = {0};

static void stm32_lite_can_rx_isr(struct rt_can_device *can, rt_uint32_t fifo)
{
    FDCAN_HandleTypeDef *phcan;
    struct stm32_lite_fdcan *drv_can;
    RT_ASSERT(can);
    drv_can = (struct stm32_lite_fdcan *)can;
    uint32_t msg_count;
    RT_ASSERT(drv_can != NULL);

    phcan = &drv_can->CanHandle;

    switch (fifo)
    {
    case FDCAN_RX_FIFO0:
        /* save to user list */
        if (HAL_FDCAN_GetRxFifoFillLevel(phcan, FDCAN_RX_FIFO0) && __HAL_FDCAN_GET_IT_SOURCE(phcan, FDCAN_IT_RX_FIFO0_NEW_MESSAGE))
        {
            if(phcan->Instance == FDCAN1)
            {
                g_can_new_msg_cnt[0]++;
            }
            else if(phcan->Instance == FDCAN2)
            {
                g_can_new_msg_cnt[1]++;                
            }
            else
            {
                g_can_new_msg_cnt[2]++;                    
            }

            msg_count = HAL_FDCAN_GetRxFifoFillLevel(phcan,FDCAN_RX_FIFO0);
            for(uint32_t i = 0; i < msg_count; i++)
            {
                rt_hw_can_isr(can, RT_CAN_EVENT_RX_IND | fifo << 8);          
            }
                        /* Clear FIFO0 new msg Flag */
            __HAL_FDCAN_CLEAR_FLAG(phcan,FDCAN_FLAG_RX_FIFO0_NEW_MESSAGE); 
        }
        /* Check FULL flag for FIFO0 */
        if (__HAL_FDCAN_GET_FLAG(phcan, FDCAN_FLAG_RX_FIFO0_FULL) && __HAL_FDCAN_GET_IT_SOURCE(phcan, FDCAN_IT_RX_FIFO0_FULL))
        {
            if(phcan->Instance == FDCAN1)
            {
                g_can_full_cnt[0]++;
            }
            else if(phcan->Instance == FDCAN2)
            {
                g_can_full_cnt[1]++;                
            }
            else
            {
                g_can_full_cnt[2]++;                    
            }
            msg_count = HAL_FDCAN_GetRxFifoFillLevel(phcan,FDCAN_RX_FIFO0);
            for(uint32_t i = 0; i < msg_count; i++)
            {
                rt_hw_can_isr(can, RT_CAN_EVENT_RXOF_IND | fifo << 8);               
            }
                        /* Clear FIFO0 full Flag */
            __HAL_FDCAN_CLEAR_FLAG(phcan, FDCAN_FLAG_RX_FIFO0_FULL);
        }
        /* Check Overrun flag for FIFO0 */
        if (__HAL_FDCAN_GET_FLAG(phcan, FDCAN_FLAG_RX_FIFO0_MESSAGE_LOST) && __HAL_FDCAN_GET_IT_SOURCE(phcan, FDCAN_IT_RX_FIFO0_MESSAGE_LOST))
        {
            if(phcan->Instance == FDCAN1)
            {
                g_can_msg_lost_cnt[0]++;
            }
            else if(phcan->Instance == FDCAN2)
            {
                g_can_msg_lost_cnt[1]++;                
            }
            else
            {
                g_can_msg_lost_cnt[2]++;                    
            }
            msg_count = HAL_FDCAN_GetRxFifoFillLevel(phcan,FDCAN_RX_FIFO0);
            for(uint32_t i = 0; i < msg_count; i++)
            {
                rt_hw_can_isr(can, RT_CAN_EVENT_RXOF_IND | fifo << 8);          
            }
            /* Clear FIFO0 Overrun Flag */
            __HAL_FDCAN_CLEAR_FLAG(phcan, FDCAN_FLAG_RX_FIFO0_MESSAGE_LOST);
        }
        break;
    case FDCAN_RX_FIFO1:
        /* save to user list */
        if (HAL_FDCAN_GetRxFifoFillLevel(phcan, FDCAN_RX_FIFO1) && __HAL_FDCAN_GET_IT_SOURCE(phcan, FDCAN_IT_RX_FIFO1_NEW_MESSAGE))
        {
            if(phcan->Instance == FDCAN1)
            {
                g_can_new_msg_cnt[0]++;
            }
            else if(phcan->Instance == FDCAN2)
            {
                g_can_new_msg_cnt[1]++;                
            }
            else
            {
                g_can_new_msg_cnt[2]++;                    
            }
            msg_count = HAL_FDCAN_GetRxFifoFillLevel(phcan,FDCAN_RX_FIFO1);
            for(uint32_t i = 0; i < msg_count; i++)
            {
                rt_hw_can_isr(can, RT_CAN_EVENT_RX_IND | fifo << 8);              
            }
            __HAL_FDCAN_CLEAR_FLAG(phcan,FDCAN_FLAG_RX_FIFO1_NEW_MESSAGE);
        }
        /* Check FULL flag for FIFO1 */
        if (__HAL_FDCAN_GET_FLAG(phcan, FDCAN_FLAG_RX_FIFO1_FULL) && __HAL_FDCAN_GET_IT_SOURCE(phcan, FDCAN_IT_RX_FIFO1_FULL))
        {
            if(phcan->Instance == FDCAN1)
            {
                g_can_full_cnt[0]++;
            }
            else if(phcan->Instance == FDCAN2)
            {
                g_can_full_cnt[1]++;                
            }
            else
            {
                g_can_full_cnt[2]++;                    
            }
            msg_count = HAL_FDCAN_GetRxFifoFillLevel(phcan,FDCAN_RX_FIFO1);
            for(uint32_t i = 0; i < msg_count; i++)
            {
                rt_hw_can_isr(can, RT_CAN_EVENT_RXOF_IND | fifo << 8);             
            }
            /* Clear FIFO1 FULL Flag */
            __HAL_FDCAN_CLEAR_FLAG(phcan, FDCAN_FLAG_RX_FIFO1_FULL);
        }
        /* Check Overrun flag for FIFO1 */
        if (__HAL_FDCAN_GET_FLAG(phcan, FDCAN_FLAG_RX_FIFO1_MESSAGE_LOST) && __HAL_FDCAN_GET_IT_SOURCE(phcan, FDCAN_IT_RX_FIFO1_MESSAGE_LOST))
        {
            if(phcan->Instance == FDCAN1)
            {
                g_can_msg_lost_cnt[0]++;
            }
            else if(phcan->Instance == FDCAN2)
            {
                g_can_msg_lost_cnt[1]++;                
            }
            else
            {
                g_can_msg_lost_cnt[2]++;                    
            }
            msg_count = HAL_FDCAN_GetRxFifoFillLevel(phcan,FDCAN_RX_FIFO1);
            for(uint32_t i = 0; i < msg_count; i++)
            {
                rt_hw_can_isr(can, RT_CAN_EVENT_RXOF_IND | fifo << 8);            
            }
            /* Clear FIFO1 Overrun Flag */
            __HAL_FDCAN_CLEAR_FLAG(phcan, FDCAN_FLAG_RX_FIFO1_MESSAGE_LOST);
        }
        break;
    }
}


static void stm32_lite_can_tx_isr(struct rt_can_device *can)
{
    FDCAN_HandleTypeDef *phcan;
    struct stm32_lite_fdcan *drv_can;
	uint32_t tx_index;
    RT_ASSERT(can);
    drv_can = (struct stm32_lite_fdcan *)can;
    RT_ASSERT(drv_can != NULL);

    phcan = &drv_can->CanHandle;
	if (__HAL_FDCAN_GET_FLAG(phcan, FDCAN_FLAG_TX_COMPLETE) && __HAL_FDCAN_GET_IT_SOURCE(phcan, FDCAN_IT_TX_COMPLETE))
	{
      /* Clear the Transmission Complete flag */
      __HAL_FDCAN_CLEAR_FLAG(phcan, FDCAN_FLAG_TX_COMPLETE);
	   /* List of transmitted monitored buffers */
      tx_index = phcan->Instance->TXBTO;
      tx_index &= phcan->Instance->TXBTIE;
	  rt_hw_can_isr(can, RT_CAN_EVENT_TX_DONE | (tx_index << 8));
	}
}
static int stm32_lite_can_sendmsg(struct rt_can_device *can, const void *buffer,  rt_uint32_t box_num)
{
	FDCAN_TxHeaderTypeDef txheader;
	struct rt_can_msg *pmsg;
	FDCAN_HandleTypeDef *phcan;
    struct stm32_lite_fdcan *drv_can;
	
	RT_ASSERT(can != NULL);
	drv_can = (struct stm32_lite_fdcan *)can;
    RT_ASSERT(drv_can != NULL);

	phcan = &drv_can->CanHandle;

    if (__HAL_FDCAN_GET_FLAG(phcan, FDCAN_FLAG_BUS_OFF) != RESET)
  	{
        __HAL_FDCAN_CLEAR_FLAG(phcan, FDCAN_FLAG_BUS_OFF);
		stm32_lite_can_config(can,&can->config);
	}
	pmsg = (struct rt_can_msg *) buffer;

    txheader.Identifier          = pmsg->id;
	if (RT_CAN_STDID == pmsg->ide)
    {
        txheader.IdType = FDCAN_STANDARD_ID;
    }
    else
    {
        txheader.IdType = FDCAN_EXTENDED_ID;
    }

    txheader.TxFrameType         = FDCAN_DATA_FRAME;
    txheader.DataLength          = get_can_send_dlc(pmsg->len);
    txheader.ErrorStateIndicator = FDCAN_ESI_ACTIVE;
    txheader.BitRateSwitch       = FDCAN_BRS_OFF;
    txheader.FDFormat            = FDCAN_CLASSIC_CAN;
    txheader.TxEventFifoControl  = FDCAN_NO_TX_EVENTS;
    txheader.MessageMarker       = 0xCC;
    
    if (HAL_FDCAN_AddMessageToTxFifoQ(phcan, &txheader, (uint8_t *)pmsg->data) != HAL_OK)
    {
		rt_hw_can_isr(can, RT_CAN_EVENT_TX_FAIL | (box_num << 8));
        return RT_ERROR;
    }
	
	//rt_hw_can_isr(can, RT_CAN_EVENT_TX_DONE | (phcan->LatestTxFifoQRequest << 8));
	rt_hw_can_isr(can, RT_CAN_EVENT_TX_DONE | (box_num << 8));
    return RT_EOK;
}
static const struct rt_can_ops stm32_lite_can_ops =
{
    .configure  = stm32_lite_can_config,
    .control    = stm32_lite_can_control,
    .sendmsg    = stm32_lite_can_sendmsg,
    .recvmsg    = stm32_lite_can_recvmsg,
};

#ifdef BSP_USING_FDCAN1
void FDCAN1_IT0_IRQHandler(void)
{
    uint32_t RxFifo0ITs;
    uint32_t RxFifo1ITs;
    
    /* enter interrupt */
    rt_interrupt_enter();
    
    RxFifo0ITs = drv_can1.CanHandle.Instance->IR & 0x07; //0x07= FDCAN_RX_FIFO0_MASK
    RxFifo0ITs &= drv_can1.CanHandle.Instance->IE;
    RxFifo1ITs = drv_can1.CanHandle.Instance->IR & 0x38; //0x38= FDCAN_RX_FIFO1_MASK
    RxFifo1ITs &= drv_can1.CanHandle.Instance->IE;
    //HAL_FDCAN_IRQHandler(&rt_fdcan.fdcan);
    if(RxFifo0ITs != 0)
        stm32_lite_can_rx_isr(&drv_can1.device, FDCAN_RX_FIFO0);
    else if(RxFifo1ITs != 0)
        stm32_lite_can_rx_isr(&drv_can1.device, FDCAN_RX_FIFO1);
    /* leave interrupt */
    rt_interrupt_leave();
}

void FDCAN1_IT1_IRQHandler(void)
{
   /* enter interrupt */
   rt_interrupt_enter();

   //HAL_FDCAN_IRQHandler(&rt_fdcan.fdcan);
   stm32_lite_can_tx_isr(&drv_can1.device);

   /* leave interrupt */
   rt_interrupt_leave();
}
#endif

#ifdef BSP_USING_FDCAN2
void FDCAN2_IT0_IRQHandler(void)
{
    uint32_t RxFifo0ITs;
    uint32_t RxFifo1ITs;
    
    /* enter interrupt */
    rt_interrupt_enter();
    
    RxFifo0ITs = drv_can2.CanHandle.Instance->IR & 0x07; //0x07= FDCAN_RX_FIFO0_MASK
    RxFifo0ITs &= drv_can2.CanHandle.Instance->IE;
    RxFifo1ITs = drv_can2.CanHandle.Instance->IR & 0x38; //0x38= FDCAN_RX_FIFO1_MASK
    RxFifo1ITs &= drv_can2.CanHandle.Instance->IE;
    //HAL_FDCAN_IRQHandler(&rt_fdcan.fdcan);
    if(RxFifo0ITs != 0)
        stm32_lite_can_rx_isr(&drv_can2.device, FDCAN_RX_FIFO0);
    else if(RxFifo1ITs != 0)
        stm32_lite_can_rx_isr(&drv_can2.device, FDCAN_RX_FIFO1);
    
    /* leave interrupt */
    rt_interrupt_leave();
}

void FDCAN2_IT1_IRQHandler(void)
{
   /* enter interrupt */
   rt_interrupt_enter();

   //HAL_FDCAN_IRQHandler(&rt_fdcan.fdcan);
   stm32_lite_can_tx_isr(&drv_can2.device);

   /* leave interrupt */
   rt_interrupt_leave();
}
#endif

#ifdef BSP_USING_FDCAN3
void FDCAN3_IT0_IRQHandler(void)
{
    uint32_t RxFifo0ITs;
    uint32_t RxFifo1ITs;
    
    /* enter interrupt */
    rt_interrupt_enter();
    RxFifo0ITs = drv_can3.CanHandle.Instance->IR & 0x07; //0x07= FDCAN_RX_FIFO0_MASK
    RxFifo0ITs &= drv_can3.CanHandle.Instance->IE;
    RxFifo1ITs = drv_can3.CanHandle.Instance->IR & 0x38; //0x38= FDCAN_RX_FIFO1_MASK
    RxFifo1ITs &= drv_can3.CanHandle.Instance->IE;
    //HAL_FDCAN_IRQHandler(&rt_fdcan.fdcan);
    if(RxFifo0ITs != 0)
        stm32_lite_can_rx_isr(&drv_can3.device, FDCAN_RX_FIFO0);
    else if(RxFifo1ITs != 0)
        stm32_lite_can_rx_isr(&drv_can3.device, FDCAN_RX_FIFO1);

    /* leave interrupt */
    rt_interrupt_leave();
}

void FDCAN3_IT1_IRQHandler(void)
{
   /* enter interrupt */
   rt_interrupt_enter();

   //HAL_FDCAN_IRQHandler(&rt_fdcan.fdcan);
   stm32_lite_can_tx_isr(&drv_can3.device);

   /* leave interrupt */
   rt_interrupt_leave();
}
#endif

//void HAL_FDCAN_ErrorStatusCallback(FDCAN_HandleTypeDef *hfdcan, uint32_t ErrorStatusITs)
//{
//    __HAL_FDCAN_CLEAR_FLAG(hfdcan, FDCAN_FLAG_BUS_OFF);
//    if(hfdcan->Instance == FDCAN1) 
//    {
//        MX_FDCAN1_Init();
//        fdcan1_config();
//    } 
//    else if(hfdcan->Instance == FDCAN2) 
//    {
//        MX_FDCAN2_Init();
//        fdcan2_config();
//    } 
//    else if(hfdcan->Instance == FDCAN3) 
//    {
//        MX_FDCAN3_Init();
//        fdcan3_config();
//    } 
//    else 
//    {
//        ;
//    }
//}


int rt_hw_fdcan_init(void)
{
    struct can_configure config = CANDEFAULTCONFIG;
    config.privmode = RT_CAN_MODE_NOPRIV;
    config.ticks = 50;

#ifdef RT_CAN_USING_HDR
    config.maxhdr = 14;
#ifdef CAN2
    config.maxhdr = 28;
#endif
#endif
    /* config default filter 
 	
 */
    FDCAN_FilterTypeDef filter_cfg = {0};
	//filter_cfg.IdType			  = FDCAN_STANDARD_ID | FDCAN_EXTENDED_ID;
	filter_cfg.FilterIndex		  = 0;
	/*IdType=FDCAN_EXTENDED_ID,Classic filter: EF1ID = filter, EF2ID = mask*/
	filter_cfg.FilterType		  = FDCAN_FILTER_MASK; 
	/*Store in Rx FIFO 0 if filter matches*/
	filter_cfg.FilterConfig 	  = FDCAN_FILTER_TO_RXFIFO0;
	filter_cfg.FilterID1		  = 0x000;
	filter_cfg.FilterID2		  = 0x000;

#ifdef BSP_USING_FDCAN1

    drv_can1.FilterConfig = filter_cfg;
    drv_can1.device.config = config;
    /* register CAN1 device */
    rt_hw_can_register(&drv_can1.device,
                       drv_can1.name,
                       &stm32_lite_can_ops,
                       &drv_can1);
#endif /* BSP_USING_FDCAN1 */

#ifdef BSP_USING_FDCAN2
    drv_can2.FilterConfig = filter_cfg;
    drv_can2.device.config = config;
    /* register CAN2 device */
    rt_hw_can_register(&drv_can2.device,
                       drv_can2.name,
                       &stm32_lite_can_ops,
                       &drv_can2);
#endif /* BSP_USING_FDCAN2 */

#ifdef BSP_USING_FDCAN3
    drv_can3.FilterConfig = filter_cfg;
    drv_can3.device.config = config;
    /* register CAN2 device */
    rt_hw_can_register(&drv_can3.device,
                       drv_can3.name,
                       &stm32_lite_can_ops,
                       &drv_can3);
#endif /* BSP_USING_FDCAN3 */

    return 0;
}

INIT_BOARD_EXPORT(rt_hw_fdcan_init);

#if 0 // FINSH_USING_MSH
#include <finsh.h>
static uint32_t open_flag = 0;

int fdcantest(int argc, char **argv)
{
    rt_err_t result = RT_EOK;
    rt_uint8_t i; 
	struct rt_can_msg txmsg={0}, rxmsg={0};
	
    struct rt_device *dev = NULL;

    if (argc != 9)
    {
        rt_kprintf("Usage:\n");
        rt_kprintf("fdcanlpbk 1 2 3 4 5 6 7 8\n");
        return -1;
    }

    for (i = 0; i < 8; i++)
    {
        txmsg.data[i] = atoi(argv[i+1]);
    }
	txmsg.id = 0xc12345;
	txmsg.ide = 1;
	txmsg.len = 8;
	txmsg.priv = 0;
	txmsg.hdr = -1;
	
    dev = rt_device_find("can1");
    if (dev == NULL)
    {
        rt_kprintf("can't find fdcan1 device!\n");
        return RT_ERROR;
    }

	if(open_flag ==0)
    {
		rt_device_open(dev, RT_DEVICE_FLAG_INT_TX|RT_DEVICE_FLAG_INT_RX|RT_DEVICE_OFLAG_RDWR);
		open_flag = 1;
		//rt_device_control(dev,RT_CAN_CMD_SET_MODE,(void*)RT_CAN_MODE_LOOPBACK);// test
	}

    rt_device_write(dev, 0, &txmsg, sizeof(txmsg));
    rt_thread_delay(10);
	rxmsg.hdr = -1;
    rt_device_read(dev, 0, &rxmsg, sizeof(rxmsg));

    rt_kprintf("fdcan1 over, canid=0x%x,data: ",rxmsg.id);
    for (i = 0; i < 8; i++)
    {
        rt_kprintf(" %x ", rxmsg.data[i]);
    }
    rt_kprintf("\n");

    return result;
}

MSH_CMD_EXPORT(fdcantest, fdcan      test);

#endif

#endif
