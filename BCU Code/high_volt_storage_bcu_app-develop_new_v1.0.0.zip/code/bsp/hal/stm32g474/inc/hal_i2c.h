#ifndef __HAL_I2C_H__
#define __HAL_I2C_H__

#include "data_types.h"


/* I2C open flags */
#define HAL_I2C_MASTER  0x00            ///< i2c master mode
#define HAL_I2C_SLAVE   0x01            ///< i2c slave mode

// 对应g_soft_i2c_bus[]数组的下标
typedef enum
{
    //HAL_I2C_ID_NO_1 = 0,
    HAL_I2C_ID_NO_2 = 0,
    HAL_I2C_NUM,
} hal_i2c_id_num;

/**
  * @enum hal_i2c_config_t
  * @brief I2C配置属性
  */
typedef struct {	
	uint32_t speed; 					///< I2C 速度
	uint16_t dev_addr;					///< I2C 目标地址
	uint8_t work_mode;					///< I2C 主从模式
} hal_i2c_config_t;


int32_t hal_i2c_open(uint32_t i2c_no);
int32_t hal_i2c_close(uint32_t i2c_no);
int32_t hal_i2c_resume(uint32_t i2c_no);
int32_t hal_i2c_suspend(uint32_t i2c_no);
int32_t hal_i2c_setup(uint32_t i2c_no, hal_i2c_config_t *config);
int32_t hal_i2c_write(uint32_t i2c_no, uint16_t dev_addr, uint8_t *buf, uint32_t len);
int32_t hal_i2c_read(uint32_t i2c_no, uint16_t dev_addr, uint8_t *buf, uint32_t len);
int32_t hal_i2c_flush(uint32_t i2c_no);
int32_t hal_i2c_query(uint32_t i2c_no);
int32_t hal_i2c_ioctl(int32_t dev_no, uint8_t cmd, void* arg);


#endif
