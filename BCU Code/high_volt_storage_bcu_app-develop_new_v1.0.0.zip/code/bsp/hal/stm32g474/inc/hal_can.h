#ifndef __HAL_CAN_H__
#define __HAL_CAN_H__

#include "data_types.h"


#define CAN_TX_RING_BUFF_SZ 	80  // 发送缓冲区大小

/**
* @brief CAN 波特率
*/
#define HAL_CAN_BAUD_1M   				1000UL * 1000	///< 1 MBit/sec
#define HAL_CAN_BAUD_800K 				1000UL * 800	///< 800 kBit/sec
#define HAL_CAN_BAUD_500K 				1000UL * 500 	///< 500 kBit/sec
#define HAL_CAN_BAUD_250K 				1000UL * 250	///< 250 kBit/sec
#define HAL_CAN_BAUD_125K 				1000UL * 125	///< 125 kBit/sec
#define HAL_CAN_BAUD_100K 				1000UL * 100	///< 100 kBit/sec
#define HAL_CAN_BAUD_50K  				1000UL * 50		///< 50 kBit/sec
#define HAL_CAN_BAUD_20K  				1000UL * 20 	///< 20 kBit/sec
#define HAL_CAN_BAUD_10K  				1000UL * 10   	///< 10 kBit/sec

#define HAL_IS_CAN_BAUD(BAUD)      	   	(((BAUD) == HAL_CAN_BAUD_1M)  	\
								  	 || ((BAUD) == HAL_CAN_BAUD_800K) 	\
								  	 || ((BAUD) == HAL_CAN_BAUD_500K)  	\
     							  	 || ((BAUD) == HAL_CAN_BAUD_250K)  	\
     							  	 || ((BAUD) == HAL_CAN_BAUD_125K)  	\
     							  	 || ((BAUD) == HAL_CAN_BAUD_100K)  	\
     							  	 || ((BAUD) == HAL_CAN_BAUD_50K)   	\
     							  	 || ((BAUD) == HAL_CAN_BAUD_20K) 	\
     							  	 || ((BAUD) == HAL_CAN_BAUD_10K))

#define HAL_CAN_MODE_NORMAL             0				///< CAN 普通模式
#define HAL_CAN_MODE_LISEN              1				///< CAN 监听模式
#define HAL_CAN_MODE_LOOPBACK           2				///< CAN LOOP BACK模式
#define HAL_CAN_MODE_LOOPBACKANLISEN    3				///< CAN LOOP BACK 监听模式
#define HAL_IS_CAN_MODE(MODE)      	   	(((MODE) == HAL_CAN_MODE_NORMAL)  	\
								   	 || ((MODE) == HAL_CAN_MODE_LISEN) 		\
								  	 || ((MODE) == HAL_CAN_MODE_LOOPBACK)  	\
     							  	 || ((MODE) == HAL_CAN_MODE_LOOPBACKANLISEN))



#define HAL_CAN_CMD_SET_PRIV             0x10    ///< 设置发送优先级
#define HAL_CAN_CMD_GET_STATUS           0x11    ///< 获取 CAN 设备状态
#define HAL_CAN_CMD_SET_STATUS_IND       0x12    ///< 设置状态回调函数

#define HAL_CAN_STDID 0					///< CAN消息，IDE标识，标准帧
#define HAL_CAN_EXTID 1 				///< CAN消息，IDE标识，扩展帧

#define HAL_CAN_DTR   0 				///< CAN消息，RTR标识，数据帧
#define HAL_CAN_RTR   1 				///< CAN消息，RTR标识，遥控帧

/**
* @struct hal_can_conf_t
* @brief 配置CAN各种属性
*/
typedef struct
{
    uint32_t baud;      ///< 波特率    
	uint32_t mode;		///< 模式
	
}hal_can_conf_t;

/**
* @struct can_filter_item_t
* @brief CAN硬件过滤表属性
*/
typedef struct
{
    uint32_t id  : 29; 			///< CAN ID, 标志格式 11 位，扩展格式 29 位
    uint32_t ide : 1;			///< 扩展帧标识位 
    uint32_t rtr : 1;			///< 远程帧标识位 
    uint32_t mode : 1;			///< 过滤表模式 
    uint32_t mask;				///< ID 掩码，0 表示对应的位不关心，1 表示对应的位必须匹配 
    int32_t hdr;		    	///< -1 表示不指定过滤表号，对应的过滤表控制块也不会被初始化，正数为过滤表号，对应的过滤表控制块会被初始化 
	#ifdef RT_CAN_USING_HDR
    int32_t (*ind)(int32_t port, void *args , int32_t hdr, int32_t size);	 ///< 过滤表回调函数 
    void *args;					///< 回调函数参数
	#endif
}can_filter_item_t;


/**
* @struct hal_can_filter_t
* @brief 配置CAN硬件过滤表
*/
typedef struct
{
    uint32_t count;
    uint32_t actived;
    can_filter_item_t *items;         
}hal_can_filter_t;


#ifdef RT_CAN_USING_HDR
#define HAL_CAN_FILTER_ITEM_INIT(id,ide,rtr,mode,mask,ind,args) \
     {(id), (ide), (rtr), (mode), (mask), -1, (ind), (args)}	///< 不指定过滤号的硬件过滤表
	 
#define HAL_CAN_FILTER_STD_INIT(id,mask,ind,args) \
     HAL_CAN_FILTER_ITEM_INIT(id,0,0,0,mask,ind,args)			///< 标准帧硬件LIST过滤表
#define HAL_CAN_FILTER_EXT_INIT(id,ind,mask,args) \
     HAL_CAN_FILTER_ITEM_INIT(id,1,0,0,mask,ind,args)			///< 扩展帧硬件LIST过滤表
#define HAL_CAN_STD_RMT_FILTER_INIT(id,mask,ind,args) \
     HAL_CAN_FILTER_ITEM_INIT(id,0,1,0,mask,ind,args)			///< 标准远程帧硬件LIST过滤表
#define HAL_CAN_EXT_RMT_FILTER_INIT(id,mask,ind,args) \
     HAL_CAN_FILTER_ITEM_INIT(id,1,1,0,mask,ind,args)			///< 扩展远程帧硬件LIST过滤表
	 
#define HAL_CAN_STD_MASK_FILTER_INIT(id,ind,mask,args) \
     HAL_CAN_FILTER_ITEM_INIT(id,0,0,1,mask,ind,args)			///< 标准远程帧硬件MASK过滤表
#define HAL_CAN_EXT_MASK_FILTER_INIT(id,ind,mask,args) \
     HAL_CAN_FILTER_ITEM_INIT(id,1,0,1,mask,ind,args)           ///< 扩展远程帧硬件MASK过滤表
#else

#define HAL_CAN_FILTER_ITEM_INIT(id,ide,rtr,mode,mask) \
     {(id), (ide), (rtr), (mode), (mask), -1, }
#define HAL_CAN_FILTER_STD_INIT(id) \
     HAL_CAN_FILTER_ITEM_INIT(id,0,0,0,0xFFFFFFFF)
#define HAL_CAN_FILTER_EXT_INIT(id) \
     HAL_CAN_FILTER_ITEM_INIT(id,1,0,0,0xFFFFFFFF)
#define HAL_CAN_STD_RMT_FILTER_INIT(id) \
     HAL_CAN_FILTER_ITEM_INIT(id,0,1,0,0xFFFFFFFF)
#define HAL_CAN_EXT_RMT_FILTER_INIT(id) \
     HAL_CAN_FILTER_ITEM_INIT(id,1,1,0,0xFFFFFFFF)
#define HAL_CAN_STD_RMT_DATA_FILTER_INIT(id) \
     HAL_CAN_FILTER_ITEM_INIT(id,0,0,1,0xFFFFFFFF)
#define HAL_CAN_EXT_RMT_DATA_FILTER_INIT(id) \
     HAL_CAN_FILTER_ITEM_INIT(id,1,0,1,0xFFFFFFFF)
	 
#endif

/**
* @struct hal_can_msg_t
* @brief CAN消息
*/
typedef struct
{
    uint32_t id  : 29;					///< CAN ID, 标志格式 11 位，扩展格式 29 位
    uint32_t ide : 1;					///< 扩展帧标识位 标准帧or扩展帧
    uint32_t rtr : 1;					///< 远程帧标识位 数据帧or遥控帧
    uint32_t rsv : 1;					///< 保留位
    uint32_t len : 8;					///< 消息长度
    uint32_t priv : 8;					///< 报文发送优先级
    int32_t hdr : 8;					///< 硬件过滤表号
    uint32_t reserved : 8;				///< 保留
    uint8_t data[8];       				///< 数据段
}hal_can_msg_t;



/* can回调函数定义 */
typedef void(*irq_can_callback)(uint32_t dev_no, uint32_t size);


/**
* @brief		CAN加载驱动
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @warning 		开机只运行一次
*/
int32_t hal_can_init(void);


/**
* @brief		CAN删除驱动(预留)
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败
*/
int32_t hal_can_deinit(void);


/**
* @brief		打开CAN功能 
* @param		[in] port 虚拟CAN端口号  
* -# HAL_CAN1 - 0x00	
* -# HAL_CAN2 - 0x01
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @pre			执行hal_can_init后执行才有效。
*/
int32_t hal_can_open(uint32_t port);


/**
* @brief		关闭CAN功能 
* @param		[in] port 虚拟CAN端口号
* -# HAL_CAN1 - 0x00	
* -# HAL_CAN2 - 0x01
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			执行hal_can_init后执行才有效。
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_can_close(uint32_t port);


/**
* @brief		CAN功能从休眠中唤醒，恢复状态
* @param		[in] port 虚拟CAN端口号
* -# HAL_CAN1 - 0x00	
* -# HAL_CAN2 - 0x01
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
*/
int32_t hal_can_resume(uint32_t port);

 
/**
* @brief		CAN功能进入休眠模式
* @param		[in] port 虚拟CAN端口号
* -# HAL_CAN1 - 0x00	
* -# HAL_CAN2 - 0x01
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式，功能不影响
*/
int32_t hal_can_suspend(uint32_t port);


/**
* @brief		设置CAN属性 
* @param		[in] port 虚拟CAN端口号
* -# HAL_CAN1 - 0x00	
* -# HAL_CAN2 - 0x01
* @param		[in] p_conf 串口参数指针 
* -# p_conf->baud - 波特率	
* -# p_conf->mode - 模式
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			执行hal_can_open后执行才有效。
*/
int32_t hal_can_setup(uint32_t port, hal_can_conf_t *p_conf);


/**
* @brief		设置CAN硬件过滤表
* @param		[in] port 虚拟CAN端口号
* -# HAL_CAN1 - 0x00	
* -# HAL_CAN2 - 0x01
* @param		[in] p_filter 硬件过滤表  
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			执行hal_can_open后执行才有效。
*/
int32_t hal_can_set_filter(uint32_t port, hal_can_filter_t *p_filter);


/**
* @brief		配置CAN中断函数  
* @param		[in] port 虚拟CAN端口号
* -# HAL_CAN1 - 0x00	
* -# HAL_CAN2 - 0x01
* @param		[in] p_tx_fcallback 发送中断回调函数  
* @param		[in] p_rx_fcallback 接收中断回调函数     
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @pre			执行hal_can_open后执行才有效。
* @warning 		发送和接收中断回调至少填写一个，不设置可填写NULL
*/
int32_t hal_can_set_irq(uint32_t port, irq_can_callback p_tx_fcallback, irq_can_callback p_rx_fcallback);


/**
* @brief		关闭CAN中断
* @param		[in] port 虚拟CAN端口号
* -# HAL_CAN1 - 0x00	
* -# HAL_CAN2 - 0x01
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			执行hal_can_open后执行才有效。
*/
int32_t hal_can_free_irq(uint32_t port);


/**
* @brief		CAN收数据 
* @param		[in] port 虚拟CAN端口号
* -# HAL_CAN1 - 0x00	
* -# HAL_CAN2 - 0x01
* @param		[in] p_buf 缓冲区指针  
* @param		[in] len 缓冲区长度   
* @return		执行结果
* @retval		>=0 接收数据长度
* @retval		<0 失败原因 
* @pre			执行hal_can_open后执行才有效。
*/
int32_t hal_can_read(uint32_t port, hal_can_msg_t *p_buf, int32_t len, uint32_t timeout_ms);


/**
* @brief		CAN发数据 
* @param		[in] port 虚拟CAN端口号
* -# HAL_CAN1 - 0x00	
* -# HAL_CAN2 - 0x01
* @param		[in] p_buf 缓冲区指针  
* @param		[in] len 缓冲区长度   
* @return		执行结果
* @retval		>=0 发送数据长度
* @retval		<0 失败原因  
* @pre			执行hal_can_open后执行才有效。
*/
int32_t hal_can_write(uint32_t port,hal_can_msg_t *p_buf, int32_t len);


/**
* @brief		扩展功能(预留)
* @param		[in] port 虚拟CAN端口号
* -# HAL_CAN1 - 0x00	
* -# HAL_CAN2 - 0x01
* @param		[in] cmd 控制命令  
* @param		[in] p_arg 控制参数   
* @return		执行结果
* @retval		SF_OK 成功    
* @retval		<0 失败原因  
*/
int32_t hal_can_ioctl(uint32_t port, uint8_t cmd, void* p_arg);



#endif
