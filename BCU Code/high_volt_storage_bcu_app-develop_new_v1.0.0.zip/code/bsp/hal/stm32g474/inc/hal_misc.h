#ifndef __HAL_MISC_H__
#define __HAL_MISC_H__

#include "data_types.h"

void cpu_usage_get(uint8_t *major, uint8_t *minor);
void cpu_reset_flag_set(void);
int32_t cpu_reset_flag_get(void);

#endif
