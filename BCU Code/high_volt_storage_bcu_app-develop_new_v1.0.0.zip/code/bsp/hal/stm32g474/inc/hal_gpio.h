#ifndef __HAL_GPIO_H__
#define __HAL_GPIO_H__
#include "data_types.h"
#include "stm32g4xx.h"



/**
  * @enum hal_gpio_direction_t
  * @brief GPIO方向
  */
typedef enum
{
    HAL_GPIO_INPUT  = 0U,   	///< 输入
    HAL_GPIO_OUTPUT = 1U,    	///< 输出  
    HAL_GPIO_OUTPUT_OD = 2U,	///< 输出OD门
} hal_gpio_direction_e;

/**
  * @enum hal_gpio_pull_t
  * @brief GPIO上下拉
  */
typedef enum
{
    HAL_GPIO_PULLUP   = 0U,    	///< 上拉电阻
    HAL_GPIO_PULLDOWN = 1U,    	///< 下拉电阻
    HAL_GPIO_NOPULL   = 2U,    	///< 无上下拉
} hal_gpio_pull_e;

/**
  * @enum hal_gpio_speed_t
* @brief GPIO翻转速度配置
  */
typedef enum
{
    HAL_GPIO_SPEED_LOW          = 0U,
    HAL_GPIO_SPEED_MEDIUM       = 1U,
    HAL_GPIO_SPEED_HIGH         = 2U,
    HAL_GPIO_SPEED_FASE         = 3U,
}hal_gpio_speed_e;

/**
  * @enum hal_gpio_config_t
  * @brief GPIO配置属性
  */
typedef struct
{
    hal_gpio_direction_e  direction;   	///< GPIO方向
    hal_gpio_pull_e       pull;        	///< GPIO电阻方式
    hal_gpio_speed_e      speed;       ///< GPIO翻转速度    
} hal_gpio_config_t;

/**
  * @enum hal_gpio_irq_t
  * @brief GPIO中断方式
  */
typedef enum
{
    HAL_GPIO_IRQ_LOW     = 0U,     		///< 低电平中断
    HAL_GPIO_IRQ_HIGH    = 1U,     		///< 高电平中断
    HAL_GPIO_IRQ_FALLING = 2U,     		///< 下降沿中断
    HAL_GPIO_IRQ_RISING  = 3U,     		///< 上升沿中断
    HAL_GPIO_IRQ_RISING_FALLING  = 4U,  ///< 上升沿和下降沿中断
}hal_gpio_irq_e;

/**
  * @enum 
  * @brief GPIO状态
  */
enum{
	HAL_GPIO_LOW = 0U,
	HAL_GPIO_HIGH = 1U,	
};


typedef void(*irq_callback)(void *args);


/* GPIO回调函数定义 */
typedef void(*gpio_irq_callback)(void *args);


	
/**
* @brief         GPIO加载驱动(预留)
* @return        执行结果
* @retval          SF_OK 成功
* @retval          HAL_EIO 失败
*/
int32_t hal_gpio_init(void);


/**
* @brief         GPIO删除驱动(预留)
* @return        执行结果
* @retval          SF_OK 成功
* @retval          HAL_EIO 失败
*/
int32_t hal_gpio_deinit(void);


/**
* @brief        打开管脚功能(预留)
* @param        [in] pin pin虚拟编号
* @return       执行结果
* @retval         SF_OK 成功
* @retval         HAL_EIO 失败
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_open(int32_t pin);


/**
* @brief        关闭管脚功能(预留)
* @param        [in] pin pin虚拟编号
* @return       执行结果
* @retval         SF_OK 成功
* @retval         HAL_EIO 失败
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_close(int32_t pin);


/**
* @brief        GPIO功能从休眠中唤醒，恢复状态
* @param        [in] pin pin虚拟编号
* @return       执行结果
* @retval         SF_OK 成功
* @retval         HAL_EIO 失败
* @warning      本接口调用后，需要把单板对应管脚设置为低功耗模式
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_resume(int32_t pin);


/**
* @brief        GPIO功能进入休眠模式
* @param        [in] pin pin虚拟编号
* @return       执行结果
* @retval         SF_OK 成功
* @retval         HAL_EIO 失败
* @warning      本接口调用后，需要把对应管脚也设置为低功耗模式
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息*/
int32_t hal_gpio_suspend(int32_t pin);


/**
* @brief        配置管脚属性
* @param        [in] pin_id pin虚拟编号
* @param        [in] p_conf GPIO属性
* @return       执行结果
* @retval         SF_OK 成功
* @retval         HAL_EIO 失败
* @pre          执行hal_gpio_open后执行才有效。
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_config(int32_t pin, hal_gpio_config_t *p_conf);


/**
* @brief        控制管脚输出值
* @param        [in] pin pin虚拟编号
* @param        [in] value
                   0 = 低电平
                   1 = 高电平
* @return       执行结果
* @retval         SF_OK 成功
* @retval         HAL_EIO 失败
* @pre          执行hal_gpio_open后执行才有效
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_write(int32_t pin, int32_t value);


/**
* @brief        读取管脚输入值
* @param        [in] pin pin虚拟编号
* @return       管脚状态
* @retval         0 = 输入低
* @retval         1 = 输入高
* @retval         HAL_EIO 失败，GPIO可能未打开
* @pre          执行hal_gpio_open后执行才有效
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_read(int32_t pin);


/**
* @brief        控制管脚特殊属性的函数(预留)
* @param        [in] pin pin虚拟编号
* @param        [in] cmd 命令
* @param        [in] param 参数
* @return       返回结果，根据实际命令调整
* @retval         0 = 输入低
* @retval         1 = 输入高
* @retval         HAL_EIO 失败，GPIO可能未打开
* @pre          执行hal_gpio_open后执行才有效。
* @remarks      用于未来控制使用
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_ioctl(int32_t pin, int32_t cmd, int32_t param);


/**
* @brief        配置管脚为外部中断功能和设置相关属性
* @param        [in] pin pin虚拟编号
* @param        [in] mode 属性
* @param        [in] p_fcallback 外部中断回调函数
* @param        [in] p_args 中断参数，无传入NULL
* @return       返回结果
* @retval         SF_OK 成功
* @retval         HAL_EIO 失败
* @pre          执行hal_gpio_open后执行才有效。
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_set_irq(int32_t pin, hal_gpio_irq_e mode, gpio_irq_callback p_fcallback, void *p_args);


/**
* @brief        释放GPIO外部中断
* @param        [in] pin pin虚拟编号
* @return       返回结果
* @retval         SF_OK 成功
* @retval         HAL_EIO 失败
* @pre          执行hal_gpio_open后执行才有效。
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_free_irq(int32_t pin);





#endif
