#ifndef __BQ79616_COMMUNICATION_H__
#define __BQ79616_COMMUNICATION_H__

#include <stdint.h>

#define FRMWRT_SGL_R	        0x00    //single device READ
#define FRMWRT_SGL_W	        0x10    //single device WRITE
#define FRMWRT_STK_R	        0x20    //stack READ
#define FRMWRT_STK_W	        0x30    //stack WRITE
#define FRMWRT_ALL_R	        0x40    //broadcast READ
#define FRMWRT_ALL_W	        0x50    //broadcast WRITE
#define FRMWRT_REV_ALL_W        0x60    //broadcast WRITE reverse direction

#define NOT_NEED_CHECK          0xFFFFFFFFFFFFFFFF

#define READ_DATA_INDEX         4
#define TOTALBOARDS             1

#define AFE_DEBUG_ENABLE        1

#ifdef __cplusplus
extern "C" {
#endif

void bq79616_wakeup(void);
int32_t bq79616_communication_init(void);
int32_t write_reg(uint8_t dev_id, uint16_t addr, uint64_t val, uint64_t target_val, uint8_t write_len, 
                       uint8_t operate_type);
int32_t read_reg(uint8_t dev_id, uint16_t addr, uint8_t *buf, uint8_t read_len, uint8_t operate_type, 
                     uint32_t delay_ms);

#ifdef __cplusplus
}
#endif

#endif


