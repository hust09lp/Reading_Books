#ifndef __HAL_EXT_ADC_ADS1115_COMM_H__
#define __HAL_EXT_ADC_ADS1115_COMM_H__

#include <rtconfig.h>
#include "data_types.h"

// addr在硬件上不同接法不一样，从机设备地址不一样；当前一共有四种
#define ADS1115_DEV_ADDR_GND  (0x90)
#define ADS1115_DEV_ADDR_VDD  (0x92)
#define ADS1115_DEV_ADDR_SDA  (0x94)
#define ADS1115_DEV_ADDR_SCL  (0x96)

// 根据实际电路增加或减少
enum {
    EXT_ADS_DEV_1 = 0,
    EXT_ADS_DEV_NUM,
};

// ads1115只有4个寄存器
enum {
    ADS_CONVERSION_REG_ADDRESS = 0,
    ADS_CONFIG_REG_ADDRESS,
    ADS_LO_THRESH_REG_ADDRESS,
    ADS_HI_THRESH_REG_ADDRESS,
    NUM_ADS_REGISTERS,
};

extern int32_t hal_ext_ads1115_init(void);
extern int32_t hal_ext_ads1115_deinit(void);
extern int32_t hal_ext_ads1115_open(uint32_t ext_ads1115_no);
extern int32_t hal_ext_ads1115_close(uint32_t ext_ads1115_no);
extern int32_t hal_single_register_read(uint32_t ext_ads1115_no, uint8_t reg_address, uint16_t *reg_value);
extern int32_t hal_ads_single_register_write(uint32_t ext_ads1115_no, uint8_t reg_address, uint16_t reg_value);
extern int32_t hal_ext_ads1115_alert_read(uint32_t ext_ads1115_no);

#endif
