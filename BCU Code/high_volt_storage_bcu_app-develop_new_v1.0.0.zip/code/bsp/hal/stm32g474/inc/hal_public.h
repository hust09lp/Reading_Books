#ifndef __HAL_PUBLIC_H__
#define __HAL_PUBLIC_H__

#include "data_types.h"
#include "rtdef.h"
//#define RT_USING_FINSH_DEBUG

#ifndef TICK_1MS
#define TICK_1MS 		                os_tick_from_millisecond(1)
#endif

#ifndef TICK_10MS
#define TICK_10MS 		                os_tick_from_millisecond(10)
#endif

#ifndef TICK_100MS
#define TICK_100MS 		                os_tick_from_millisecond(100)
#endif

#ifndef TICK_1S
#define TICK_1S 		                os_tick_from_millisecond(1000)
#endif


/**
 * @brief		延时us
 * @param		[in] 需要延时的us数, <1000us
 */
void hal_delay_us(uint32_t us);
    
/**
* @brief		使能总中断
* @param		[in] level 关闭中断前的状态,参数保留未使用
* @return		无 
*/
inline void hal_enable_interrupt(int32_t level);
	
/**
* @brief		关闭总中断
* @return		中断状态
*/
inline int32_t hal_disable_interrupt(void);

/**
* @brief		获取当前tick
* @return		当前tick值
*/
uint32_t hal_tick_get(void);

/**
* @brief		判断是否时间tick超时
* @param		[in] start_tick 启动计时的tick  
* @param		[in] interval 中间间隔
* @return		是否超时 
* @retval		true 已超时
* @retval		false 未超时
*/
bool hal_is_tick_over(uint32_t start_tick, uint32_t interval);

/**
* @brief		系统复位
* @return		void
*/
void hal_system_reset(void);

rt_mutex_t hal_dfs_lock_handel_get(void);
#endif
