#ifndef __HAL_PWM_H__
#define __HAL_PWM_H__

#include "data_types.h"


/**
  * @enum  hal_pwm_tim_index_t
  * @brief PWM定时器索引编号
  */
typedef enum
{
    HAL_PWM_TIM2    = 0,   
	HAL_PWM_TIM_MAX,
}hal_pwm_tim_index_e;

/**
  * @enum  hal_pwm_ch_index_t
  * @brief PWM定时器通道
  */
typedef enum
{
    HAL_PWM_CH1    = 1,  
    HAL_PWM_CH2,
    HAL_PWM_CH3,  
    HAL_PWM_CH4,  
	HAL_PWM_CH_MAX,
}hal_pwm_ch_e;


/**
  * @struct hal_pwm_config_t
  * @brief PWM属性配置。
  */
typedef struct {
    uint32_t duty_percent;    ///< PWM占空比 1-100对应1%-100%
    uint32_t freq_hz;    	  ///< PWM输出频率,单位 HZ
    uint32_t polarity;        ///< 空闲时的极性
}hal_pwm_config_t;


/**
* @brief		PWM加载驱动
* @return		执行结果
* @retval		SF_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_pwm_init(void);


/**
* @brief		PWM删除驱动(预留)
* @return		执行结果
* @retval		SF_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_pwm_deinit(void);


/**
* @brief		启动PWM通道  
* @param		[in] pwm_tim_no pwm定时器id
* @param		[in] chan pwm通道编号
* @return		执行结果
* @retval		SF_OK（0） 成功  
* @retval		HAL_EIO（<0） 失败   
*/
int32_t hal_pwm_start(uint32_t pwm_tim_no, uint32_t chan);


/**
* @brief		停止PWM通道 
* @param		[in] pwm_tim_no pwm定时器id
* @param		[in] chan pwm通道编号
* @return		执行结果
* @retval		SF_OK（0） 成功  
* @retval		HAL_EIO（<0） 失败   
*/
int32_t hal_pwm_stop(uint32_t pwm_tim_no, uint32_t chan);


/**
* @brief		设置PWM参数   
* @param		[in] pwm_tim_no pwm定时器id
* @param		[in] chan pwm通道编号
* @param		[in] p_cfg pwm配置结构体
* -# p_cfg->duty_percent - PWM占空比 1-100对应1%-100%  
* -# p_cfg->period_ticks - PWM周期 ns
* -# p_cfg->polarity - 空闲时的引脚状态
* @return		执行结果
* @retval		SF_OK（0） 成功  
* @retval		HAL_EIO（<0） 失败   
*/
int32_t hal_pwm_config(uint32_t pwm_tim_no, uint32_t chan,hal_pwm_config_t *p_cfg);


/**
* @brief		PWM功能从休眠中唤醒，恢复状态
* @param		[in] pwm_tim_no pwm定时器id
* @param		[in] chan pwm通道编号
* @return		执行结果
* @retval		SF_OK（0） 成功  
* @retval		HAL_EIO（<0） 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_pwm_resume(uint32_t pwm_tim_no, uint32_t chan);

 
/**
* @brief		PWM功能进入休眠模式
* @param		[in] pwm_tim_no pwm定时器id
* @param		[in] chan pwm通道编号
* @return		执行结果
* @retval		SF_OK（0） 成功  
* @retval		HAL_EIO（<0） 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式，功能不影响
*/
int32_t hal_pwm_suspend(uint32_t pwm_tim_no, uint32_t chan);


/**
* @brief		扩展功能(预留)
* @param		[in] pwm_tim_no pwm定时器id
* @param		[in] chan pwm通道编号
* @param		[in] cmd 控制命令  
* @param		[in] arg 控制参数   
* @return		执行结果
* @retval		SF_OK 成功    
* @retval		<0 失败原因  
*/
int32_t hal_pwm_ioctl(uint32_t pwm_tim_no, uint32_t chan, uint8_t cmd, void* p_arg);



#endif
