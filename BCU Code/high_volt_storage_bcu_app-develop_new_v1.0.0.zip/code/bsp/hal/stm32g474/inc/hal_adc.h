#ifndef __HAL_ADC_H__
#define __HAL_ADC_H__

#include <rtconfig.h>
#include "data_types.h"

#ifdef BSP_USING_ADC1
typedef enum
{
    HALL_VOLT2 = 0, //电流霍尔采样输入2
    HALL_VOLT3 = 1, //电流霍尔采样输入3  
    MCU_TEMP_4 = 2, //第4路温度采样输入
    MCU_TEMP_5 = 3, //第5路温度采样输入    
    MCU_TEMP_2 = 4, //第2路温度采样输入    
    MCU_12V_SAM = 5, //12V采样输入    
    ADC1_CHNNEL_CNT,
    
}ADC1_SAMPLE_RESULT_E;  //adc1的采集定义顺序
#endif

#ifdef BSP_USING_ADC2
typedef enum
{
    HALL_VOLT1 = 0,//电流霍尔采样输入1
    MCU_TEMP_1 = 1, //第1路温度采样输入      
    MCU_TEMP_6 = 2, //第6路温度采样输入   
    MCU_IDC_VER = 3,  //硬件版本识别    
    MCU_PCB_TEMP = 4, //PCB温度采集
    MCU_24V_SAM= 5, //供电电源24V采集    
    MCU_TEMP_3 = 6, //第3路温度采样输入    
    MCU_5V_SAM = 7, //系统5V电源采集(霍尔)    
    ADC2_CHNNEL_CNT ,
}ADC2_SAMPLE_RESULT_E;  //adc2的采集定义顺序
#endif

#ifdef BSP_USING_ADC3
typedef enum
{
    MCU_POS_RLY_SAM = 0, //DO1输出状态采集(主正继电器采集)
    MCU_NEG_RLY_SAM = 1, //DO3输出状态采集(主负继电器采集)
    MCU_12VOUT_SAM  = 2, //12V电源输出采集    
    ADC3_CHNNEL_CNT = 3,
}ADC3_SAMPLE_RESULT_E;  //adc1的采集定义顺序
#endif

#ifdef BSP_USING_ADC1
#ifndef ADC1_CONFIG
#define ADC1_CONFIG                                         \
    {                                                       \
        .adc_handle.Instance     = ADC1,                    \
        .adc_irqn                = ADC1_2_IRQn,             \
        .name                    = "adc1",                  \
    }
#endif /* ADC1 */
#endif /* BSP_USING_ADC1 */

#ifdef BSP_USING_ADC2
#ifndef ADC2_CONFIG
#define ADC2_CONFIG                                         \
    {                                                       \
        .adc_handle.Instance     = ADC2,                    \
        .adc_irqn                = ADC1_2_IRQn,             \
        .name                    = "adc2",                  \
    }
#endif /* ADC2 */
#endif /* BSP_USING_ADC2 */

#ifdef BSP_USING_ADC3
#ifndef ADC3_CONFIG
#define ADC3_CONFIG                                         \
    {                                                       \
        .adc_handle.Instance     = ADC3,                    \
        .adc_irqn                = ADC3_IRQn,               \
        .name                    = "adc3",                  \
    }
#endif /* ADC3 */
#endif /* BSP_USING_ADC3 */

#ifdef BSP_USING_ADC4
#ifndef ADC4_CONFIG
#define ADC4_CONFIG                                         \
    {                                                       \
        .adc_handle.Instance     = ADC4,                    \
        .adc_irqn                = ADC4_IRQn,               \
        .name                    = "adc4",                  \
    }
#endif /* ADC4 */
#endif /* BSP_USING_ADC4 */
    
#ifdef BSP_USING_ADC5
#ifndef ADC5_CONFIG
#define ADC5_CONFIG                                         \
    {                                                       \
        .adc_handle.Instance     = ADC5,                    \
        .adc_irqn                = ADC5_IRQn,               \
        .name                    = "adc5",                  \
    }
#endif /* ADC5 */
#endif /* BSP_USING_ADC5 */


/**
  * @enum	hal_adc_sample_cycles_t
  * @brief  ADC采样周期
  */
typedef enum
{
	HAL_ADC_SAMP_TIME_1CYCLES5   	= 0x00,	///< 1.5周期
	HAL_ADC_SAMP_TIME_7CYCLES5,				///< 7.5周期
	HAL_ADC_SAMP_TIME_13CYCLES5,			///< 13.5周期
	HAL_ADC_SAMP_TIME_28CYCLES5,			///< 28.5周期
	HAL_ADC_SAMP_TIME_41CYCLES5,			///< 41.5周期
	HAL_ADC_SAMP_TIME_55CYCLES5,			///< 55.5周期
	HAL_ADC_SAMP_TIME_71CYCLES5,			///< 71.5周期
	HAL_ADC_SAMP_TIME_239CYCLES5,			///< 239.5周期	
}hal_adc_sample_cycles_e;


/**
  * @enum   hal_adc_sample_time_t
  * @brief  ADC转换模式
  */
typedef enum
{
	HAL_ADC_CONV_ONE_TIME_MODE   	= 0x00, ///< 单次采样
	HAL_ADC_CONV_CONTINUOUS_MODE,			///< 连续采样
}hal_adc_convert_mode_e;


/**
  * @enum   hal_adc_config_t
  * @brief  ADC配置属性
  */
typedef struct 
{
	uint32_t sampling_cycle;  				///< 采样频率
	uint32_t convert_mode;					///< 转换模式
} hal_adc_config_t;

/**
  * @enum  hal_adc_dma_map_index_t
  * @brief ADC DMA数据表索引定义
  */
typedef enum
{
    HAL_ADC_CHAN_ID0 = 0,               // 电流霍尔采样输入1
    HAL_ADC_CHAN_ID1,                   // 电流霍尔采样输入2
	HAL_ADC_CHAN_ID2,                   // 电流霍尔采样输入3
	HAL_ADC_CHAN_ID3,                   // 第1路温度采样输入
	HAL_ADC_CHAN_ID4,                   // 第2路温度采样输入
	HAL_ADC_CHAN_ID5,                   // 第3路温度采样输入
	HAL_ADC_CHAN_ID6,                   // 第4路温度采样输入
	HAL_ADC_CHAN_ID7,                   // 第5路温度采样输入
    HAL_ADC_CHAN_ID8,                   // 第6路温度采样输入    
	HAL_ADC_CHAN_ID9,                   // 硬件版本识别    
    HAL_ADC_CHAN_ID10,                  // PCB温度采集
	HAL_ADC_CHAN_ID11,                  // 供电电源24V采集    
    HAL_ADC_CHAN_ID12,                  // 5V电源输出采集(霍尔供电)
	HAL_ADC_CHAN_ID13,                  // 
    HAL_ADC_CHAN_ID14,                  // 
    HAL_ADC_CHAN_ID15,                  // //    
    HAL_ADC_CHAN_ID16,                  	//   
    HAL_ADC_CHAN_ID17,                  //     
    HAL_ADC_CHAN_ID18,
	HAL_ADC_CHAN_MAX,
}hal_adc_result_e;


/**
  * @enum  irq_adc_callback
  * @brief ADC中断回调函数定义
  */
typedef void(*irq_adc_callback)(uint32_t adc_no, uint32_t channel, uint32_t adc);


/**
* @brief		ADC加载驱动,根据配置加载对应的ADC驱动
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @warning		上电或系统初始化时调用一次
*/
int32_t hal_adc_init(void);

/**
* @brief		ADC删除驱动(跟据配置删除对应的驱动)
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
*/
int32_t hal_adc_deinit(void);


/**
* @brief		ADC功能从休眠中唤醒，恢复状态
* @param		[in] adc_no ADC虚拟编号
* -# HAL_ADC1 - 0x00
* -# HAL_ADC2 - 0x01
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @warning		本接口调用后，需要把对应管脚恢复到正常状态 
*/
int32_t hal_adc_resume(uint32_t adc_no);
 
/**
* @brief		ADC功能进入休眠模式
* @param		[in] adc_no ADC虚拟编号
* -# HAL_ADC1 - 0x00
* -# HAL_ADC2 - 0x01
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式，功能不影响
*/
int32_t hal_adc_suspend(uint32_t adc_no);


/**
* @brief		启动ADC(预留)
* @param		[in] adc_no ADC虚拟编号
* -# HAL_ADC1 - 0x00
* -# HAL_ADC2 - 0x01
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @pre			执行hal_adc_enable后执行才有效。
*/
int32_t hal_adc_start(uint32_t adc_no);


/**
* @brief		停止ADC(预留)
* @param		[in] adc_no ADC虚拟编号
* -# HAL_ADC1 - 0x00
* -# HAL_ADC2 - 0x01
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			接口未使用，默认返回SF_OK
*/
int32_t hal_adc_stop(uint32_t adc_no);
 

/**
* @brief		设置ADC属性(预留)
* @param		[in] adc_no ADC虚拟编号
* -# HAL_ADC1 - 0x00
* -# HAL_ADC2 - 0x01
* @param		[in] p_cfg 配置属性指针
* -# p_cfg->sampling_cycle 采样频率	
* -# p_cfg->convert_mode 转换模式
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			接口未使用，默认返回SF_OK
*/
int32_t hal_adc_setup(uint32_t adc_no, hal_adc_config_t *p_cfg);


/**
* @brief		读取ADC通道数据
* @param		[in] channel
* @param		[out] *p_value 读取的adc数据 
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败
* @pre			执行hal_adc_start后执行才有效。
*/
int32_t hal_adc_read(uint32_t channel, uint16_t *p_value);

/**
* @brief		ADC中断回调函数    
* @param		[in] adc_no ADC虚拟编号
* -# HAL_ADC1 - 0x00
* -# HAL_ADC2 - 0x01
* @param		[in] p_callback 回调函数  
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			接口未使用，默认返回SF_OK
*/
int32_t hal_adc_set_irq(uint32_t adc_no, irq_adc_callback p_fcallback);

/**
* @brief		扩展功能(预留)
* @param		[in] adc_no ADC虚拟编号
* -# HAL_ADC1 - 0x00
* -# HAL_ADC2 - 0x01
* @param		[in] cmd 控制命令  
* @param		[in] arg 控制参数   
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @pre			接口未使用，默认返回SF_OK
*/
int32_t hal_adc_ioctl(uint32_t adc_no, uint8_t cmd, void* p_arg);

/**
* @brief		adc滤波
* @return		void
*/
//void hal_adc_filter_task(void);
void hal_adc_filter_task(void* argument);

#endif
