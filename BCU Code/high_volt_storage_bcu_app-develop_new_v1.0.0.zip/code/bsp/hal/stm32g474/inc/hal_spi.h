#ifndef __HAL_SPI_H__
#define __HAL_SPI_H__

#include "data_types.h"


/** SPI mode flags */
#define HAL_SPI_CPHA    0x01            //!< clock phase 
#define HAL_SPI_CPOL    0x02            //!< clock polarity 


#define HAL_SPI_MODE_0  (0|0)           	///< (original MicroWire) 
#define HAL_SPI_MODE_1  (0|HAL_SPI_CPHA)
#define HAL_SPI_MODE_2  (HAL_SPI_CPOL|0)
#define HAL_SPI_MODE_3  (HAL_SPI_CPOL|HAL_SPI_CPHA)


#define HAL_SPI_8BIT    8



/** SPI transfer flags */
#define HAL_SPI_XFER_BEGIN  0x01        ///< Assert CS before transfer 
#define HAL_SPI_XFER_END    0x02        ///< Deassert CS after transfer 


/** SPI transfer flags */
#define HAL_SPI_MASTER  0x00            ///< spi master mode 
#define HAL_SPI_SLAVE   0x01            ///< spi slave mode 

/** SPI transfer flags */
#define HAL_SPI_FIRSTBIT_MSB   0x00      ///< spi first bit MSB 
#define HAL_SPI_FIRSTBIT_LSB   0x01     ///< spi first bit LSB


typedef enum
{
    SPI1_INDEX = 0,
    SPI2_INDEX,
    SPI3_INDEX,
	SPI_INDEX_MAX,
}hal_spi_index_e;



/**
  * @enum hal_spi_config_t
  * @brief SPI配置属性
  */
typedef struct {	
	uint8_t work_mode;					///< SPI 主从模式
    uint8_t trans_mode;  				///< 传输模式
    uint8_t data_width;  				///< SPI通信长度
    uint8_t first_bit;					///< MSB or LSB
    uint32_t max_hz;  					///< SPI频率
} hal_spi_config_t;



typedef void(*irq_spi_callback)(uint32_t dev_no, uint32_t size);


/**
* @brief		SPI加载驱动
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
*/
int32_t hal_spi_init(void);


/**
* @brief		SPI删除驱动
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
*/
int32_t hal_spi_deinit(void);


/**
* @brief		打开SPI功能 
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @warning 		本接口只初始化SPI总线接口 
*/
int32_t hal_spi_open(uint32_t dev_no);


/**
* @brief		关闭SPI功能 
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_spi_close(uint32_t dev_no);


/**
* @brief		SPI功能从休眠中唤醒，恢复状态
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_spi_resume(uint32_t dev_no);

 
/**
* @brief		SPI功能进入休眠模式
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式，功能不影响
*/
int32_t hal_spi_suspend(uint32_t dev_no);



/**
* @brief		设置SPI属性  
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @param		[in] p_config SPI配置参数  
* - config->work_mode 使用模式
* -# HAL_SPI_MASTER = 主模式
* -# HAL_SPI_SLAVE = 从模式
* - config->trans_mode 使用模式
* -# HAL_SPI_MODE_0 = CPOL:0|CPHA:0
* -# HAL_SPI_MODE_1 = CPOL:0|CPHA:1
* -# HAL_SPI_MODE_2 = CPOL:1|CPHA:0
* -# HAL_SPI_MODE_3 = CPOL:1|CPHA:1 
* - config->data_width SPI发送数据位
* - config->first_bit SPI通信长度
* -# HAL_SPI_FIRSTBIT_MSB 
* -# HAL_SPI_FIRSTBIT_LSB
* - config->max_hz SPI频率
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @pre 			执行hal_spi_open后执行才有效。 
@code 
		CPOL 	CPHA
MODE0 	0 		0
MODE1 	0 		1
MODE2 	1 		0
MODE3 	1 		1
CPOL: SPI空闲时的时钟信号电平(1:高电平, 0:低电平)
CPHA: SPI在时钟第几个边沿采样(1:第二个边沿开始, 0:第一个边沿开始)
@endcode
*/
int32_t hal_spi_setup(uint32_t dev_no, hal_spi_config_t *p_config);



/**
* @brief		全双工收发数据   
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @param		[in] p_dout 发送缓冲区指针   
* @param		[out] p_din 接收缓冲区指针 
* @param		[in] len 发送和接收缓冲区长度  
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		<0 失败原因   
* @pre 			执行hal_spi_open后执行才有效。
* @warning		发送接收缓冲区必须一样大小，否则可能出现程序崩溃等异常 
*/
int32_t hal_spi_xfer(uint32_t dev_no, void *p_dout, void *p_din, uint32_t len);


/**
* @brief		SPI发数据 
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @param		[in] p_buf 缓冲区指针    
* @param		[in] len 缓冲区长度    
* @return		执行结果
* @retval		>0 发送数据长度(阻塞式)  
* @retval		=0 数据待发送(非阻塞式)，使用hal_spi_query查询发送完成情况  
* @retval		<0 失败原因   
* @pre 			执行hal_spi_open后执行才有效。 
*/
int32_t hal_spi_write(uint32_t dev_no, void *p_buf, uint32_t len);


/**
* @brief		SPI发数据 
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @param		[in] p_buf 缓冲区指针    
* @param		[in] len 缓冲区长度    
* @return		执行结果
* @retval		>0 接收数据长度
* @retval		=0 数据待接收(非阻塞式)，使用hal_spi_query查询接收完成情况 
* @retval		<0 失败原因 
* @pre 			执行hal_spi_open后执行才有效。 
*/
int32_t hal_spi_read(uint32_t dev_no, void *p_buf, uint32_t len);


/**
* @brief		清空收缓冲区数据（预留）
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		<0 失败原因 
* @pre 			执行hal_spi_open后执行才有效。 
*/
int32_t hal_spi_flush(uint32_t dev_no);


/**
* @brief		查询是否发送完毕 
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @return		执行结果
* @retval		SF_OK 成功 
* @retval		=0 发送完毕
* @retval		<0 失败原因 
* @pre 			执行hal_spi_open后执行才有效。 
*/
int32_t hal_spi_query(uint32_t dev_no);


/**
* @brief		配置SPI中断函数（预留）
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @param		[in] p_tx_fcallback 发送中断回调函数 
* @param		[in] p_rx_fcallback 接收中断回调函数  
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		<0 失败原因   
* @pre 			执行hal_spi_open后执行才有效。 
*/
int32_t hal_spi_set_irq(uint32_t dev_no, irq_spi_callback p_tx_fcallback, irq_spi_callback p_rx_fcallback);



/**
* @brief		关闭SPI中断（预留）
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		<0 失败原因   
* @pre 			执行hal_spi_open后执行才有效。 
*/
int32_t hal_spi_free_irq(uint32_t dev_no);


/**
* @brief		扩展功能（预留）
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @param		[in] cmd 控制命令  
* @param		[in] p_arg 控制参数   
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		<0 失败原因  
*/
int32_t hal_spi_ioctl(uint32_t dev_no, uint32_t cmd, void* p_argv);



#endif
