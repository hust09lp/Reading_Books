#ifndef __HAL_EEPROM_H__
#define __HAL_EEPROM_H__

#include "data_types.h"




#endif
