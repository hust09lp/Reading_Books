#ifndef __HAL_CRYPTO_H__
#define __HAL_CRYPTO_H__

#include "hal_types.h"
#include "hal_errors.h"


typedef enum
{
    CRYPTO_CRC_CUSTOM,        /**< Custom CRC mode */
    CRYPTO_CRC_CRC8,          /**< poly : 0x07 */
    CRYPTO_CRC_CRC16,         /**< poly : 0x8005 */
    CRYPTO_CRC_CRC32,         /**< poly : 0x04C11DB7 */
    CRYPTO_CRC_CCITT,         /**< poly : 0x1021 */
    CRYPTO_CRC_DNP,           /**< poly : 0x3D65 */
}crypto_crc_mode_e;


#define CRC_FLAG_REFIN    (0x1 << 0)
#define CRC_FLAG_REFOUT   (0x1 << 1)

#define CRYPTO_CRC8_CFG         \
{                               \
    .last_val = 0x00,           \
    .poly = 0x07,               \
    .width = 8,                 \
    .xorout = 0x00,             \
    .flags = 0,                 \
}

#define CRYPTO_CRC16_CFG        \
{                               \
    .last_val = 0x0000,         \
    .poly = 0x8005,             \
    .width = 16,                \
    .xorout = 0x0000,           \
    .flags = 0,                 \
}

#define CRYPTO_CRC32_CFG      \
{                               \
    .last_val = 0x00000000,     \
    .poly = 0x04C11DB7,         \
    .width = 32,                \
    .xorout = 0x00000000,       \
    .flags = 0,                 \
}

#define CRYPTO_CRC_CCITT_CFG   \
{                                \
    .last_val = 0x0000,          \
    .poly = 0x1021,              \
    .width = 16,                 \
    .xorout = 0x0000,            \
    .flags = CRC_FLAG_REFIN | CRC_FLAG_REFOUT, \
}

#define CRYPTO_CRC_DNP_CFG     \
{                                \
    .last_val = 0x0000,          \
    .poly = 0x3D65,              \
    .width = 16,                 \
    .xorout = 0xffff,            \
    .flags = CRC_FLAG_REFIN | CRC_FLAG_REFOUT, \
}

#define CRYPTO_CRC32_TABLE_CFG  \
{                               \
    .last_val = 0xFFFFFFFF,     \
    .poly = 0x04C11DB7,         \
    .width = 32,                \
    .xorout = 0x00000000,       \
    .flags = 0,                 \
}



typedef struct 
{
    uint32_t last_val;   		/**< Last CRC value cache */
    uint32_t poly;       		/**< CRC polynomial */
    uint32_t width;      		/**< CRC value width */
    uint32_t xorout;    		/**< Result XOR Value */
    uint32_t flags;      		/**< Input or output data reverse. CRC_FLAG_REFIN or CRC_FLAG_REFOUT */
}crypto_crc_cfg_t;


typedef struct 
{
	void *crc_table;
    crypto_crc_mode_e mode;
    crypto_crc_cfg_t cfg;
}crypto_ctx_t;


#endif
