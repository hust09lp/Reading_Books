/**
 * @file         sdk_capture.h
 * @brief        捕获功能定义 (建议频率在1000hz以下，以免影响系统效率)
 * @details      主要包含了关于capture使用的功能相关函数
 * @author       SOFAR
 * @date         2023/04/14
 * @version      V0.0.1
 * @copyright    Copyright(c) 2023 by SofarSolar, All Rights Reserved.
 **********************************************************************************
 * @par 修改日志:
 * <table>
 * <tr><th>Date        <th>Version  <th>Author    <th>Description
 * <tr><td>2023/08/22  <td>0.0.1    <td>rwj       <td>创建初始版本 
 *
 * </table>
 *
 **********************************************************************************
 * @par 示例:
 * @code
 * 暂无
 * @endcode
 */

#ifndef __HAL_CAPTURE_H__
#define __HAL_CAPTURE_H__

#include "data_types.h"

#define CAPTURE_CHAN_MAX		1
/**
 * @enum    capture_polarity_e
 * @brief   捕获极性枚举值
 */
typedef enum
{
    HAL_CAPTURE_FALLING = 0,              ///< 下降沿捕获
    HAL_CAPTURE_RISING,                   ///< 上升沿捕获
    HAL_CAPTURE_RISING_FALLING,           ///< 上升沿下降沿捕获
} hal_capture_polarity_e;

/**
 * @enum    capture_type_e
 * @brief   捕获极性枚举值
 */
typedef enum
{
    HAL_CAPTURE_FREQ = 0,                 ///< 捕获FREQ(建议频率在1000hz以下，以免影响系统效率)
    HAL_CAPTURE_COUNT,                    ///< 捕获脉冲次数
} hal_capture_type_e;

/**
  * @struct capture_config_t
  * @brief capture属性配置。
  */
typedef struct {
    uint32_t type;                    ///< 捕获类型
    uint32_t polarity;                ///< 捕获极性，详见capture_polarity_e
} hal_capture_config_t;

/**
 * @struct  capture_data_t
 * @brief   捕获pwm结构体
 */
typedef struct
{
    uint32_t duty_percent;            ///< PWM占空比 0-100对应0%-100%
    uint32_t freq_hz;                 ///< PWM输出频率,单位 1HZ
} hal_capture_data_t;

/**
 * @brief       capture 初始化
 * @return      执行结果
 * @retval 0    执行成功
 * @retval < 0  执行失败
 */
int32_t hal_capture_init(void);

/**
 * @brief           capture配置
 * @param channel   [in] capture 通道
 * @param channel   [in] p_config capture配置结构体
 * @return          执行结果
 * @retval 0        执行成功
 * @retval < 0      执行失败
 * @note            if(p_config->type == CAPTURE_FREQ)，polarity只支持CAPTURE_RISING和CAPTURE_FALLING，否则返回失败（不支持）
 */
int32_t hal_capture_config(uint32_t channel, hal_capture_config_t *p_config);

/**
 * @brief           启动 capture
 * @param channel   [in] capture 通道
 * @return          执行结果
 * @retval 0        执行成功
 * @retval < 0      执行失败
 */
int32_t hal_capture_start(uint32_t channel);

/**
 * @brief           capture 停止
 * @param channel   [in] capture 通道
 * @return          执行结果
 * @retval 0        执行成功
 * @retval < 0      执行失败
 */
int32_t hal_capture_stop(uint32_t channel);

/**
 * @brief capture数据读取
 * @param channel   [in] capture 通道
 * @param channel   [out] p_capture 读取的capture结构体
 * -# 0x00 - 不清除
 * -# 0x01 - 清除
 * @return          执行结果
 * @retval 0        执行成功
 * @retval < 0      执行失败
 */
int32_t hal_capture_freq_read(uint32_t channel, hal_capture_data_t *p_capture);

/**
 * @brief capture脉冲计数读取
 * @param channel   [in] capture 通道
 * @param p_capture [in] clear_flag 读完是否清除数据
 * -# 0x00 - 不清除
 * -# 0x01 - 清除
 * @return          执行结果
 * @retval >= 0     读取的脉冲次数计数值
 * @retval < 0      执行失败
 */
int32_t hal_capture_counter_read(uint32_t channel, uint8_t clear_flag);

/**
 * @brief           capture 命令控制
 * @param channel   [in] capture 通道
 * @param cmd       [in] 功能码
 * @param args      [in] 参数
 * @return          执行结果
 * @retval 0        执行成功
 * @retval < 0      执行失败
 */
int32_t hal_capture_ioctl(uint32_t channel, uint32_t cmd, void *args);


#endif /* #define __SDK_CAPTURE_H__  */
