#ifndef __HAL_LCD_H__
#define __HAL_LCD_H__


#include "hal_types.h"
#include "hal_errors.h"

#define HAL_LCD_ALIGN_LEFT			///< 左对齐
#define HAL_LCD_ALIGN_CENTER		///< 居中对齐
#define HAL_LCD_ALIGN_RIGHT			///< 右对齐



#define HAL_LCD_CTRL_BACKLIGHT		0x10	///< 控制背光灯
#define HAL_LCD_GET_ATTR			0x11	///< 获取屏幕属性


#define LCD_CMD_BL_ON				1		///< 控制背光灯亮
#define LCD_CMD_BL_OFF				0		///< 控制背光灯灭


/**
* @struct hal_lcd_attr_t
* @brief LCD属性
*/
typedef struct
{
    uint32_t width;		///< 屏幕宽度
    uint32_t high;		///< 屏幕高度
}hal_lcd_attr_t;









#endif
