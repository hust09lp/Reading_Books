#ifndef __HAL_COMP_H__
#define __HAL_COMP_H__

#include "data_types.h"
#include <rtconfig.h>
#include "stm32g4xx.h"

#ifdef BSP_USING_COMP1                                       
#ifndef COMP1_CONFIG
#define COMP1_CONFIG                                         \
    {                                                       \
        .comp_handle.Instance     = COMP1,                    \
        .comp_irqn                = COMP1_2_3_IRQn,             \
        .name                    = "comp1",                  \
    }
#endif /* COMP1 */    
#endif /* BSP_USING_COMP1 */

#ifdef BSP_USING_COMP2                                     
#ifndef COMP2_CONFIG
#define COMP2_CONFIG                                         \
    {                                                       \
        .comp_handle.Instance     = COMP2,                    \
        .comp_irqn                = COMP1_2_3_IRQn,             \
        .name                    = "comp2",                  \
    }
#endif /* COMP2 */     
#endif /* BSP_USING_COMP2 */

#ifdef BSP_USING_COMP3                                     
#ifndef COMP3_CONFIG
#define COMP3_CONFIG                                         \
    {                                                       \
        .comp_handle.Instance     = COMP3,                    \
        .comp_irqn                = COMP1_2_3_IRQn,               \
        .name                    = "comp3",                  \
    }
#endif /* COMP3 */       
#endif /* BSP_USING_COMP3 */

#ifdef BSP_USING_COMP4                                     
#ifndef COMP4_CONFIG
#define COMP4_CONFIG                                         \
    {                                                       \
        .comp_handle.Instance     = COMP4,                    \
        .comp_irqn                = COMP4_5_6_IRQn,               \
        .name                    = "comp4",                  \
    }
#endif /* COMP4 */      
#endif /* BSP_USING_COMP4 */
    
#ifdef BSP_USING_COMP5                                     
#ifndef COMP5_CONFIG
#define COMP5_CONFIG                                         \
    {                                                       \
        .comp_handle.Instance     = COMP5,                    \
        .comp_irqn                = COMP4_5_6_IRQn,               \
        .name                    = "comp5",                  \
    }
#endif /* COMP5 */      
#endif /* BSP_USING_COMP5 */

#ifdef BSP_USING_COMP6                                    
#ifndef COMP6_CONFIG
#define COMP6_CONFIG                                         \
    {                                                       \
        .comp_handle.Instance     = COMP6,                    \
        .comp_irqn                = COMP4_5_6_IRQn,               \
        .name                    = "comp6",                  \
    }
#endif /* COMP6 */       
#endif /* BSP_USING_COMP6 */

#ifdef BSP_USING_COMP7                                    
#ifndef COMP7_CONFIG
#define COMP7_CONFIG                                         \
    {                                                       \
        .comp_handle.Instance     = COMP5,                    \
        .comp_irqn                = COMP7_IRQn,               \
        .name                    = "comp7",                  \
    }
#endif /* BSP_USING_COMP7 */
#endif

typedef enum
{
    AUX_RLY_PWR_STUS = 0,   /*根据实际比较器通道顺序*/
    NEG_RLY_PWR_STUS,    
    POS_RLY_PWR_STUS,
    PWR_5V_STUS,    
    PWR_12V_STUS,
    COMP_SINGAL_MAX
    
}hal_comp_singal_t;
    
/**
 * @brief  返回比较异常状态
 * @return uint8_t*: 
 * AUX_RLY_PWR_STUS = 0,
    NEG_RLY_PWR_STUS,
    POS_RLY_PWR_STUS,
    PWR_5V_STUS,
    PWR_12V_STUS,
 */
uint8_t *hal_comp_err_stus_get(void);

/**
 * @brief  清除比较异常标志
 * @param  chan:     
 * AUX_RLY_PWR_STUS = 0,
    NEG_RLY_PWR_STUS,
    POS_RLY_PWR_STUS,
    PWR_5V_STUS,
    PWR_12V_STUS,
 * @return int32_t: 
 */
int32_t hal_comp_err_stus_clr(uint8_t chan);

/**
* @brief		比较器打开
 * @param  comp_id:     开启哪个比较器
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @warning		IO动作的时候操作
*/
int hal_comp_open(uint8_t comp_id);

/**
* @brief		比较器关闭
 * @param  comp_id:     关闭哪个比较器
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @warning		IO动作的时候操作
*/
int hal_comp_close(uint8_t comp_id);

/**
* @brief		比较器电平状态
 * @param  comp_id:     
* @return		电平状态
* @retval		COMP_OUTPUT_LEVEL_LOW(0) 低电平
* @retval		COMP_OUTPUT_LEVEL_HIGH(1) 高电平
* @retval	    (-1) 无效
* @warning		IO动作的时候操作
*/
int32_t hal_comp_state(uint8_t comp_id);

#endif
    
