#include <board.h>
#include <stdlib.h>
#include <rtthread.h>
#include <rtdevice.h>
#include "hal_gpio.h"
#include "string.h"
#include "log.h"
#include "pin_config.h"
#include "sofar_errors.h"
#include "data_types.h"

// 外部中断使用,仅有16个外部中断通道

struct pin_irq_t
{
	IRQn_Type irqno;
	irq_callback cb;
};

static  struct pin_irq_t pin_irq_map[] =
{
    {EXTI0_IRQn,SF_NULL},//0
    {EXTI1_IRQn,SF_NULL},
    {EXTI2_IRQn,SF_NULL},
    {EXTI3_IRQn,SF_NULL},
    {EXTI4_IRQn,SF_NULL},
    {EXTI9_5_IRQn,SF_NULL},
    {EXTI9_5_IRQn,SF_NULL},
    {EXTI9_5_IRQn,SF_NULL},
    {EXTI9_5_IRQn,SF_NULL},
    {EXTI9_5_IRQn,SF_NULL},
    {EXTI15_10_IRQn,SF_NULL},
    {EXTI15_10_IRQn,SF_NULL},
    {EXTI15_10_IRQn,SF_NULL},
    {EXTI15_10_IRQn,SF_NULL},
    {EXTI15_10_IRQn,SF_NULL},
    {EXTI15_10_IRQn,SF_NULL},

};

static uint32_t g_gpio_status;  // GPIO状态，使用bit来定义
	
/**
* @brief         GPIO加载驱动
* @return        执行结果
* @retval          SF_OK 成功
* @retval          HAL_EIO 失败
*/
int32_t hal_gpio_init(void)
{
    g_gpio_status = 0;
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOD_CLK_ENABLE();
	__HAL_RCC_GPIOE_CLK_ENABLE();
	__HAL_RCC_GPIOF_CLK_ENABLE();
	__HAL_RCC_GPIOG_CLK_ENABLE(); 
    return SF_OK;
}
INIT_BOARD_EXPORT(hal_gpio_init);


/**
* @brief         GPIO删除驱动(预留)
* @return        执行结果
* @retval          SF_OK 成功
* @retval          HAL_EIO 失败
*/
int32_t hal_gpio_deinit(void)
{
    __HAL_RCC_GPIOA_CLK_DISABLE();
    __HAL_RCC_GPIOB_CLK_DISABLE();
	__HAL_RCC_GPIOC_CLK_DISABLE();
	__HAL_RCC_GPIOD_CLK_DISABLE();
	__HAL_RCC_GPIOE_CLK_DISABLE();
	__HAL_RCC_GPIOF_CLK_DISABLE();
	__HAL_RCC_GPIOG_CLK_DISABLE();
    
    return SF_OK;
}


/**
* @brief        打开管脚功能(预留)
* @param        [in] pin_id pin虚拟编号
* @return       执行结果
* @retval         SF_OK 成功
* @retval         HAL_EIO 失败
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_open(int32_t pin)
{
//    if (PIN_PORT(pin) >= PIN_STPORT_MAX)
//    {
//        return HAL_ENODEV;
//    }
//    
//    
//    if ((g_gpio_status[PIN_PORT(pin)] & PIN_STPIN(pin)) == 0)
//    {
//        g_gpio_status[PIN_PORT(pin)] |= PIN_STPIN(pin);
//    }

	
	return SF_OK;
}


/**
* @brief        关闭管脚功能(预留)
* @param        [in] pin_id pin虚拟编号
* @return       执行结果
* @retval         SF_OK 成功
* @retval         HAL_EIO 失败
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_close(int32_t pin)
{
//	if (PIN_PORT(pin) >= PIN_STPORT_MAX)
//    {
//        return HAL_ENODEV;
//    }
    
//    if (g_gpio_status[PIN_PORT(pin)] & PIN_STPIN(pin))
//    {
//        g_gpio_status[PIN_PORT(pin)] &= ~PIN_STPIN(pin);
//    }
    
	
	return SF_OK;
}


/**
* @brief        GPIO功能从休眠中唤醒，恢复状态
* @param        [in] pin_id pin虚拟编号
* @return       执行结果
* @retval         SF_OK 成功
* @retval         HAL_EIO 失败
* @warning      本接口调用后，需要把单板对应管脚设置为低功耗模式
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_resume(int32_t pin)
{
	log_d("not support!");
	
	return SF_ERR_FNOSUPP;
}


/**
* @brief        GPIO功能进入休眠模式
* @param        [in] pin_id pin虚拟编号
* @return       执行结果
* @retval         SF_OK 成功
* @retval         HAL_EIO 失败
* @warning      本接口调用后，需要把对应管脚也设置为低功耗模式
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息*/
int32_t hal_gpio_suspend(int32_t pin)
{
    log_d("not support!");
	
	return SF_ERR_FNOSUPP;
}




/**
* @brief        配置管脚属性
* @param        [in] pin_id pin虚拟编号
* @param        [in] p_conf GPIO属性
* @return       执行结果
* @retval         SF_OK 成功
* @retval         HAL_EIO 失败
* @pre          执行hal_gpio_open后执行才有效。
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_config(int32_t pin, hal_gpio_config_t *conf)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    if(pin >= MAX_PIN)
    {
        return SF_ERR_PARA;
    }

    if(conf == SF_NULL)
    {
        return SF_ERR_PARA;
    }

    if(conf->pull == HAL_GPIO_PULLUP)
    {
        GPIO_InitStruct.Pull = GPIO_PULLUP;
    }
    else if(conf->pull == HAL_GPIO_PULLDOWN)
    {
        GPIO_InitStruct.Pull = GPIO_PULLDOWN;
    }
    else //if(conf->pull == HAL_GPIO_NOPULL)
    {
        GPIO_InitStruct.Pull = GPIO_NOPULL;
    }

    if(conf->direction == HAL_GPIO_INPUT)
    {
        GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    }
    else if(conf->direction == HAL_GPIO_OUTPUT_OD)
    {
        GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
    }
    else //if(conf->direction == HAL_GPIO_OUTPUT)
    {
        GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    }
    
    if(conf->speed == HAL_GPIO_SPEED_HIGH)
    {
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    }
    else if(conf->speed == HAL_GPIO_SPEED_MEDIUM)
    {
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
    }
	else //if(conf->speed == HAL_GPIO_SPEED_LOW)
    {
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    }

    GPIO_InitStruct.Pin = PIN_STPIN(pin);
	
    HAL_GPIO_Init(PIN_STPORT(pin), &GPIO_InitStruct);
    return SF_OK;
}


/**
* @brief        控制管脚输出值
* @param        [in] pin_id pin虚拟编号
* @param        [in] value
                   0 = 低电平
                   1 = 高电平
* @return       执行结果
* @retval         SF_OK 成功
* @retval         HAL_EIO 失败
* @pre          执行hal_gpio_open后执行才有效
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_write(int32_t pin, int32_t value)
{
	GPIO_TypeDef *gpio_port;
    uint16_t gpio_pin;

	if (pin >= MAX_PIN)
    {
        return SF_ERR_PARA;
    }

    gpio_port = PIN_STPORT(pin);
    gpio_pin = PIN_STPIN(pin);

    HAL_GPIO_WritePin(gpio_port, gpio_pin, (GPIO_PinState)value);
    
    
    return SF_OK;
}


/**
* @brief        读取管脚输入值
* @param        [in] pin_id pin虚拟编号
* @return       管脚状态
* @retval         0 = 输入低
* @retval         1 = 输入高
* @retval         HAL_EIO 失败，GPIO可能未打开
* @pre          执行hal_gpio_open后执行才有效
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_read(int32_t pin)
{
    GPIO_TypeDef *gpio_port;
    uint16_t gpio_pin;
    GPIO_PinState state;

	if (pin >= MAX_PIN)
    {
        return SF_ERR_PARA;
    }

    gpio_port = PIN_STPORT(pin);
    gpio_pin = PIN_STPIN(pin);
    state = HAL_GPIO_ReadPin(gpio_port, gpio_pin);
   

    return (state == GPIO_PIN_RESET) ? 0 : 1;
}


int32_t hal_gpio_toggle(uint32_t pin)
{
    GPIO_TypeDef *gpio_port;
    uint16_t       gpio_pin;

    if (pin >= MAX_PIN)
    {
        return SF_ERR_PARA;
    }
    
    gpio_port = PIN_STPORT(pin);
    gpio_pin = PIN_STPIN(pin);

    HAL_GPIO_TogglePin(gpio_port, gpio_pin);

    return SF_OK;
}

/**
* @brief        控制管脚特殊属性的函数(预留)
* @param        [in] pin_id pin虚拟编号
* @param        [in] cmd 命令
* @param        [in] param 参数
* @return       返回结果，根据实际命令调整
* @retval         0 = 输入低
* @retval         1 = 输入高
* @retval         HAL_EIO 失败，GPIO可能未打开
* @pre          执行hal_gpio_open后执行才有效。
* @remarks      用于未来控制使用
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_ioctl(int32_t pin, int32_t cmd, int32_t param)
{
    log_d("not support!");
    return SF_ERR_FNOSUPP;
}


/**
* @brief        配置管脚为外部中断功能和设置相关属性
* @param        [in] pin_id pin虚拟编号
* @param        [in] mode 属性
* @param        [in] p_fcallback 外部中断回调函数
* @param        [in] p_args 中断参数，无传入NULL
* @return       返回结果
* @retval         SF_OK 成功
* @retval         HAL_EIO 失败
* @pre          执行hal_gpio_open后执行才有效。
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_set_irq(int32_t pin, hal_gpio_irq_e mode, gpio_irq_callback p_fcallback, void *p_args)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    struct pin_irq_t *irqmap;
	
	/* Configure GPIO_InitStructure */
    GPIO_InitStruct.Pin = PIN_STPIN(pin);
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    switch (mode)
    {
	    case HAL_GPIO_IRQ_RISING:
	        GPIO_InitStruct.Pull = GPIO_PULLDOWN;
	        GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
	        break;
	    case HAL_GPIO_IRQ_FALLING:
	        GPIO_InitStruct.Pull = GPIO_PULLUP;
	        GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
	        break;
	    case HAL_GPIO_IRQ_RISING_FALLING:
	        GPIO_InitStruct.Pull = GPIO_NOPULL;
	        GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
	        break;
        default:
            GPIO_InitStruct.Pull = GPIO_PULLDOWN;
	        GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
	        break;
    }
    HAL_GPIO_Init(PIN_STPORT(pin), &GPIO_InitStruct);

	irqmap = &pin_irq_map[PIN_NO(pin)];
	irqmap->cb = p_fcallback;
    HAL_NVIC_SetPriority(irqmap->irqno, 5, 0);
    HAL_NVIC_EnableIRQ(irqmap->irqno);

    return SF_OK;

}

/**
* @brief        释放GPIO外部中断
* @param        [in] pin_id pin虚拟编号
* @return       返回结果
* @retval         SF_OK 成功
* @retval         HAL_EIO 失败
* @pre          执行hal_gpio_open后执行才有效。
* @warning      输入参数必须pin必须为hal_pin_get获取的pin脚信息
*/
int32_t hal_gpio_free_irq(int32_t pin)
{
    struct pin_irq_t *irqmap;

    irqmap = &pin_irq_map[PIN_NO(pin)];
    HAL_NVIC_DisableIRQ(irqmap->irqno);
    
    return SF_OK;
}

void EXTI0_IRQHandler(void)
{
    rt_interrupt_enter();
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_0);
    rt_interrupt_leave();
}

void EXTI1_IRQHandler(void)
{
    rt_interrupt_enter();
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_1);
    rt_interrupt_leave();
}

void EXTI2_IRQHandler(void)
{
    rt_interrupt_enter();
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_2);
    rt_interrupt_leave();
}

void EXTI3_IRQHandler(void)
{
    rt_interrupt_enter();
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_3);
    rt_interrupt_leave();
}

void EXTI4_IRQHandler(void)
{
    rt_interrupt_enter();
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_4);
    rt_interrupt_leave();
}

void EXTI9_5_IRQHandler(void)
{
    rt_interrupt_enter();
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_5);
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_6);
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_7);
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_8);
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_9);
    rt_interrupt_leave();
}

void EXTI15_10_IRQHandler(void)
{
    rt_interrupt_enter();
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_10);
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_11);
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_12);
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_13);
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_14);
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_15);
    rt_interrupt_leave();
}

/**
* @brief        GPIO_HAL功能样例
* @param        argv 功能参数
* @return       返回结果
* @retval         SF_OK 成功
* @retval         HAL_EIO 失败
*/
#ifdef RT_USING_FINSH
#ifdef RT_USING_FINSH_DEBUG
#if defined(BSP_USING_GPIO)

/* gpio 测试样例 中断回调函数 */
static void gpio_callback_test(void *p_args)
{
    rt_kprintf("gpio irq\n");
}


/* gpio 测试样例 */
static int hal_gpio_sample(int argc, char *p_argv[])
{
	hal_gpio_config_t gpio_config;
	int32_t  pin_value;
	uint32_t pin_num = 0;

	char 	*pin_opt  = p_argv[1];
	char 	*pin	  = p_argv[2];
	char 	*pin_args = p_argv[3];

	pin_num = strtol(pin, &pin,16);
	/* gpio写操作 */
	if (!rt_strcmp(pin_opt, "write"))
	{
		/* set pin mode to output */
		gpio_config.direction = HAL_GPIO_OUTPUT;
    	hal_gpio_config(pin_num, &gpio_config);
		hal_gpio_write(pin_num, ((*pin_args == '1')? 1 : 0));
		pin_value = hal_gpio_read(pin_num);
		rt_kprintf("%x value is: %d\n", pin_num, pin_value);
	}
	/* gpio读操作 */
	else if(!rt_strcmp(pin_opt, "read"))
	{
		/* set pin mode to input */
		gpio_config.direction = HAL_GPIO_INPUT;
		gpio_config.pull	  = HAL_GPIO_NOPULL;
		pin_value = hal_gpio_read(pin_num);
		rt_kprintf("%x value is: %d\n", pin_num, pin_value);
	}
	/* gpio中断配置 */
	else if(!rt_strcmp(pin_opt, "irq"))
	{
		/* 按键引脚为输入模式 */
	    gpio_config.direction = HAL_GPIO_INPUT;
		gpio_config.pull	  = HAL_GPIO_PULLUP;
		hal_gpio_config(pin_num, &gpio_config);
	    /* 绑定中断，下降沿模式 */
		hal_gpio_set_irq(pin_num, HAL_GPIO_IRQ_FALLING, gpio_callback_test, RT_NULL);
	}
	/* 其他不支持 */
	else
	{
		rt_kprintf("input '%s' is not support\n",pin_opt);
		return SF_ERR_FNOSUPP;
	}
	
	return SF_OK;
}


MSH_CMD_EXPORT(hal_gpio_sample, hal_gpio_sample <write/read 1 1>);
#endif
#endif 
#endif 


