#include <rtthread.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <board.h>
#include "sfud.h"
#include "log.h"
#include "hal_flash.h"
#include "sofar_errors.h"
#include "spi_flash_sfud.h"

static const sfud_flash *gp_flash = NULL;

/**
  * @brief  Gets the page of a given address
  * @param  Addr: Address of the FLASH Memory
  * @retval The page of a given address
  */
static uint32_t GetPage(uint32_t addr)
{
    uint32_t page = 0;
    page = RT_ALIGN_DOWN(addr-STM32_FLASH_START_ADRESS, FLASH_PAGE_SIZE)/FLASH_PAGE_SIZE;
    return page;
}

/**
 * Write data to flash.
 * @note This operation's units is word.
 * @note This operation must after erase. @see flash_erase.
 *
 * @param addr flash address
 * @param buf the write data buffer
 * @param size write bytes size
 *
 * @return result
 */
int stm32_flash_write(rt_uint32_t addr, const uint8_t *buf, size_t size)
{
    size_t i, j;
    rt_err_t result = 0;
    rt_uint64_t write_data = 0, temp_data = 0;
    
    if ((addr + size) > STM32_FLASH_END_ADDRESS)
    {
        log_e("ERROR: write outrange flash size! addr is (0x%p)\n", (void*)(addr + size));
        return -RT_EINVAL;
    }

    if(addr % 8 != 0)
    {
        log_e("write addr must be 8-byte alignment");
        return -RT_EINVAL;
    }

    HAL_FLASH_Unlock();

    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP | FLASH_FLAG_OPERR | FLASH_FLAG_WRPERR | FLASH_FLAG_PGAERR | FLASH_FLAG_PGSERR);

    if (size < 1)
    {
        return -RT_ERROR;
    }

    for (i = 0; i < size;)
    {
        if ((size - i) < 8)
        {
            for (j = 0; (size - i) > 0; i++, j++)
            {
                temp_data = *buf;
                write_data = (write_data) | (temp_data << 8 * j);
                buf ++;
            }
        }
        else
        {
            for (j = 0; j < 8; j++, i++)
            {
                temp_data = *buf;
                write_data = (write_data) | (temp_data << 8 * j);
                buf ++;
            }
        }

        /* write data */
        if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_DOUBLEWORD, addr, write_data) == HAL_OK)
        {
            /* Check the written value */
            if (*(uint64_t*)addr != write_data)
            {
                log_e("ERROR: write data != read data\n");
                result = -RT_ERROR;
                goto __exit;
            }
        }
        else
        {
            result = -RT_ERROR;
            goto __exit;
        }

        temp_data = 0;
        write_data = 0;

        addr += 8;
    }

__exit:
    HAL_FLASH_Lock();
    if (result != 0)
    {
        return result;
    }

    return size;
}

/**
 * Erase data on flash.
 * @note This operation is irreversible.
 * @note This operation's units is different which on many chips.
 *
 * @param addr flash address
 * @param size erase bytes size
 *
 * @return result
 */
int stm32_flash_erase(rt_uint32_t addr, size_t size)
{
    rt_err_t result = RT_EOK;
    uint32_t PAGEError = 0;

    /*Variable used for Erase procedure*/
    FLASH_EraseInitTypeDef EraseInitStruct;

    if ((addr + size) > STM32_FLASH_END_ADDRESS)
    {
        log_e("ERROR: erase outrange flash size! addr is (0x%p)\n", (void *)(addr + size));
        return -RT_EINVAL;
    }

    HAL_FLASH_Unlock();

    /* Fill EraseInit structure*/
    EraseInitStruct.TypeErase   = FLASH_TYPEERASE_PAGES;
    EraseInitStruct.Page        = GetPage(addr);
    EraseInitStruct.NbPages     = (size + FLASH_PAGE_SIZE - 1) / FLASH_PAGE_SIZE;
    EraseInitStruct.Banks       = (addr-0x08000000)/(256*1024) + 1;

    if (HAL_FLASHEx_Erase(&EraseInitStruct, &PAGEError) != HAL_OK)
    {
        result = -RT_ERROR;
        goto __exit;
    }

__exit:
    HAL_FLASH_Lock();

    if (result != RT_EOK)
    {
        return result;
    }

    log_d("erase done: addr (0x%p), size %d", (void *)addr, size);
    return size;
}

/**
* @brief		FLASH加载驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_flash_init(void)
{

    if (sfud_init() != SFUD_SUCCESS) 
    {
        return SF_ERR_NO_OBJECT;
    }
    
    gp_flash = sfud_get_device_table();
	__HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_SR_ERRORS);
    
	return SF_OK;
    
}
//INIT_DEVICE_EXPORT(hal_flash_init);


/**
* @brief		FLASH删除驱动
* @return		执行结果
* @retval		SF_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_flash_deinit(void)
{
	return SF_OK;
}


/**
* @brief		获取flash信息 
* @param		[in] dev_no 设备端口号 
-# HAL_FLASH_ID_INT = 内部Flash 
-# HAL_FLASH_ID_EXT = 外部Flash  
* @param		[in] info flash信息结构体  
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		HAL_EIO 失败   
*/
int32_t hal_flash_get_info(uint32_t dev_no, hal_flash_info_t *info) 
{
    if ((gp_flash == NULL) || (!info))
    {
        return SF_ERR_NO_OBJECT;     
    }
    
    if (dev_no == HAL_FLASH_ID_INT)
    {
        info->total_size = 1024 * 8;
        info->sector_size = 1024 * 2;
        return HAL_OK;
    }

    if (dev_no == HAL_FLASH_ID_EXT)
    {
        info->total_size = gp_flash->chip.capacity;
        info->sector_size = gp_flash->chip.erase_gran;
        return SF_OK;
    }

    return SF_ERR_PARA;
}

/**
* @brief		获取flash唯一ID  
* @param		[in] dev_no 设备端口号  
-# HAL_FLASH_ID_INT = 内部Flash 
-# HAL_FLASH_ID_EXT = 外部Flash  
* @param		[in] id 存储buffer   
* @param		[in] len buffer深度   
* @return		执行结果
* @retval		>=0 读取id长度  
* @retval		<0 失败原因  
*/
int32_t hal_flash_get_sn(uint32_t dev_no, uint8_t *id, uint32_t len)
{
    if ((dev_no != HAL_FLASH_ID_EXT) || (gp_flash == NULL) || (!id))
	{
        return SF_ERR_PARA;	
	}
    
    memset(id, 0 ,len);
    
    if (len == 1)
    {
        id[0] = gp_flash->chip.capacity_id;
    }
    
    else if (len == 2)
    {
		id[0] = gp_flash->chip.capacity_id;
        id[1] = gp_flash->chip.mf_id;
    }
    
    else if (len == 3)
    {
		id[0] = gp_flash->chip.capacity_id;
        id[1] = gp_flash->chip.mf_id;
        id[2] = gp_flash->chip.type_id;
    }
	else
	{
		return SF_ERR_PARA;	
	}
    
    return SF_OK;
}

/**
* @brief		写数据
* @param		[in] dev_no 设备端口号  
-# HAL_FLASH_ID_INT = 内部Flash 
-# HAL_FLASH_ID_EXT = 外部Flash  
* @param		[in] offset flash地址偏移   
* @param		[in] len buffer深度   
* @param		[in] buf 写入数据缓冲区  
* @return		执行结果
* @retval		>=0 读取id长度  
* @retval		<0 失败原因  
*/
int32_t hal_flash_write(uint32_t dev_no, uint32_t offset, uint32_t len, uint8_t *buf) 
{
    if ((len == 0) || (!buf))
	{
        return SF_ERR_PARA;		
	}

    if (dev_no == HAL_FLASH_ID_INT) // 写内部flash数据
	{ 
        if ((offset < 0x800A000) || (0x8010000 <= offset)) // 超出范围
        { 
            return SF_ERR_PARA;
        }
		
		stm32_flash_write(offset, buf, len);
        return len;
    }

    if (dev_no == HAL_FLASH_ID_EXT)
    {
        sfud_err result;

        if (gp_flash == NULL)
            return SF_ERR_NO_OBJECT;

        result = sfud_write(gp_flash, offset, len, buf);

        if (result == SFUD_SUCCESS)
        {
            return len;
        }
    }

    if (dev_no == HAL_FLASH_ID_EXT2)
    {
        sfud_err result;

        if (gp_flash == NULL)
            return SF_ERR_NO_OBJECT;

        result = sfud_erase_write(gp_flash, offset, len, buf);

        if (result == SFUD_SUCCESS)
        {
            return len;
        }
    }

    return SF_ERR_WR;
}

/**
* @brief		读数据
* @param		[in] dev_no 设备端口号 
-# HAL_FLASH_ID_INT = 内部Flash 
-# HAL_FLASH_ID_EXT = 外部Flash  
* @param		[in] offset flash地址偏移   
* @param		[in] len buffer深度   
* @param		[in] buf 写入数据缓冲区  
* @return		执行结果
* @retval		>=0 读取长度  
* @retval		<0 失败原因  
*/
int32_t hal_flash_read(uint32_t dev_no, uint32_t offset, uint32_t len, uint8_t *buf) 
{
	if ((len == 0) || (!buf))
	{
        return SF_ERR_PARA;		
	}
	
    if (dev_no == HAL_FLASH_ID_INT) { // 读内部flash数据
        if ((offset < 0x800A000) || (0x8010000 <= offset))
        { // 超出范围
            return SF_ERR_PARA;
        }
        uint8_t *data = (uint8_t *) offset;
        uint32_t i;
        for (i = 0; i < len; i++) {
            *buf = *data;
            buf++;
            data++;
        }
        return len;
    }

    if (dev_no == HAL_FLASH_ID_EXT) {
        sfud_err result;

        if (gp_flash == NULL)
            return SF_ERR_NO_OBJECT;

        result = sfud_read(gp_flash, offset, len, buf);

        if (result == SFUD_SUCCESS) {
            return len;
        }
    }
    return SF_ERR_RD;
}

/**
* @brief		擦除 
* @param		[in] dev_no 设备端口号  
-# HAL_FLASH_ID_INT = 内部Flash 
-# HAL_FLASH_ID_EXT = 外部Flash  
* @param		[in] offset flash地址偏移    
* @param		[in] len buffer深度   
* @return		执行结果
* @retval		>=0 读取id长度  
* @retval		<0 失败原因  
*/
int32_t hal_flash_erase(uint32_t dev_no, uint32_t offset, uint32_t len) {

    if (dev_no == HAL_FLASH_ID_INT)
    {
        if ((offset < 0x800A000) || (0x8010000 <= offset))
        { // 超出范围
            return SF_ERR_PARA;
        }
		stm32_flash_erase(offset,FLASH_PAGE_SIZE);
        return SF_OK;
    }

    if (dev_no == HAL_FLASH_ID_EXT) {
        sfud_err result;

        if (gp_flash == NULL)
            return SF_ERR_NO_OBJECT;

        result = sfud_erase(gp_flash, offset, len);

        if (result == SFUD_SUCCESS) {
            return len;
        }
    }
    return SF_ERR_NDEF;
}

/**
* @brief     整块芯片擦除 
* @param     [in] dev_no 设备端口号  
-# HAL_FLASH_ID_INT = 内部Flash 
-# HAL_FLASH_ID_EXT = 外部Flash   
* @return    执行结果
* @retval 0  成功 
* @retval <0 失败原因  
*/
int32_t hal_flash_chip_erase(uint32_t dev_no) {

	return SF_ERR_FNOSUPP; //不支持该接口
	
//    if (dev_no == HAL_FLASH_ID_INT) {
//        return HAL_OK;
//    }

//    if (dev_no == HAL_FLASH_ID_EXT) {
//        sfud_err result;

//        if (gp_flash == NULL)
//            return HAL_EIO;

//        result = sfud_chip_erase(gp_flash);

//        if (result == HAL_OK) {
//            return HAL_OK;
//        }
//    }

//    return HAL_ERR;
}

/**
* @brief		扩展功能 
* @param		[in] dev_no 设备端口号  
* @param		[in] cmd 控制命令  
* @param		[in] arg 控制参数   
* @return		执行结果
* @retval		SF_OK 成功    
* @retval		<0 失败原因  
*/
int32_t hal_flash_ioctl(int32_t dev_no, uint8_t cmd, void* arg)
{
    
    return SF_ERR_FNOSUPP;
}



#ifdef RT_USING_FINSH
#ifdef RT_USING_FINSH_DEBUG
#if 0
static void sfud_demo(uint32_t addr, size_t size, uint8_t *data, uint8_t only_read) {
    sfud_err result = SFUD_SUCCESS;
    const sfud_flash *flash = rt_sfud_flash_find_by_dev_name(FAL_USING_NOR_FLASH_DEV_NAME);
    size_t i;
    /* prepare write data */
    for (i = 0; i < size; i++) {
        data[i] = i;
    }
    if (only_read)
    {
        /* erase test */
        result = sfud_erase(flash, addr, size);
        if (result == SFUD_SUCCESS) {
            rt_kprintf("Erase the %s flash data finish. Start from 0x%08X, size is %ld.\r\n", flash->name, addr,
                    size);
        } else {
            rt_kprintf("Erase the %s flash data failed.\r\n", flash->name);
            return;
        }
        /* write test */
        result = sfud_write(flash, addr, size, data);
        if (result == SFUD_SUCCESS) {
            rt_kprintf("Write the %s flash data finish. Start from 0x%08X, size is %ld.\r\n", flash->name, addr,
                    size);
        } else {
            rt_kprintf("Write the %s flash data failed.\r\n", flash->name);
            return;
        }
    }
    /* read test */
    result = sfud_read(flash, addr, size, data);
    if (result == SFUD_SUCCESS) {
        rt_kprintf("Read the %s flash data success. Start from 0x%08X, size is %ld. The data is:\r\n", flash->name, addr,
                size);
        rt_kprintf("Offset (h)\t00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F");
        for (i = 0; i < size; i++) {
            if (i % 16 == 0) {
                rt_kprintf("\r\n[%08X]\t", addr + i);
            }
            rt_kprintf("%02X ", data[i]);
//            if (((i + 1) % 16 == 0) || i == size - 1) {
//                rt_kprintf("\r\n");
//            }
        }
        rt_kprintf("\r\n");
    } else {
        rt_kprintf("Read the %s flash data failed.\r\n", flash->name);
    }
    /* data check */
    for (i = 0; i < size; i++) {
        if (data[i] != i % 256) {
            rt_kprintf("Read and check write data has an error. Write the %s flash data failed.\r\n", flash->name);
			break;
        }
    }
    if (i == size) {
        rt_kprintf("The %s flash test is success.\r\n", flash->name);
    }
}



#define SFUD_DEMO_TEST_BUFFER_SIZE                     1024

static uint8_t sfud_demo_test_buf[SFUD_DEMO_TEST_BUFFER_SIZE];


void test_flash(int argc, char *argv[])
{
    switch (argv[1][0]) 
    {
        case '0': 
            if (sfud_init() == SFUD_SUCCESS) {
                sfud_demo(0, sizeof(sfud_demo_test_buf), sfud_demo_test_buf, 0);
            }
            break;
        case '1': 
            if (sfud_init() == SFUD_SUCCESS) {
                sfud_demo(0, sizeof(sfud_demo_test_buf), sfud_demo_test_buf, 1);
            }
            break;
    }
}

MSH_CMD_EXPORT(test_flash, test spi flash);
#endif

#if 0 // 测试内部flash的读写
#include "log.h"
void mcu_flash_test(int argc, char *argv[]) {
    log_d("sdk_iap_set_flag_test\r\n");
    switch (argv[1][0]) {
    case '0': { 
        hal_flash_init();
        log_d("初始化flash\r\n");
        break;
    }
    case '1': {
        int len = hal_flash_erase(HAL_FLASH_ID_INT, 0x0800E000, 8);
        log_d("mcu flash 1erase%d\r\n", len);
        break;
    }
    case '2': {
        int len = hal_flash_erase(HAL_FLASH_ID_INT, 0x0800E800, 8);
        log_d("mcu flash 2erase%d\r\n", len);
        break;
    }
    case '3': {
        int len = hal_flash_write(HAL_FLASH_ID_INT, 0x0800E000, 8, (uint8_t *) "app app ");
        log_d("mcu flash write1 len %d\r\n", len);
        break;
    }
    case '4': {
        int len = hal_flash_write(HAL_FLASH_ID_INT, 0x0800E800, 8, (uint8_t *) "corecore");
        log_d("mcu flash write2 len %d\r\n", len);
        break;
    }
    case '5': {
        char buf[9]={0};
        int len = hal_flash_read(HAL_FLASH_ID_INT, 0x0800E000, 8, (uint8_t *) buf);
        log_d(buf);
        break;
    }
    case '6': {
        char buf[9]={0};
        int len = hal_flash_read(HAL_FLASH_ID_INT, 0x0800E800, 8, (uint8_t *) buf);
        log_d(buf);
        break;
    }
    default:
        break;
    }
}

MSH_CMD_EXPORT(mcu_flash_test, test);

#endif

#if 1 // 测试外部flash的读写
#include <rtthread.h>
#include "log.h"
void mcu_flash_test(int argc, char *argv[]) {
    switch (argv[1][0]) {
    case '0': { 
        hal_flash_init();
        log_d("hal_flash_init\r\n");
        break;
    }
    case '1': {
        int len = hal_flash_erase(HAL_FLASH_ID_EXT, 0, 8);
        log_d("mcu flash erase1\r\n");
        break;
    }
    case '2': {
        char buf[9]={0};
        int len = hal_flash_read(HAL_FLASH_ID_EXT, 0, 8, (uint8_t *) buf);
        log_d(buf);
        break;
    }
    case '3': {
        const char *str="appappyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy";
        int len = hal_flash_write(HAL_FLASH_ID_EXT, 0, sizeof("appappyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy"), (uint8_t *) str);
        log_d("mcu flash write1 len %d\r\n", len);
        break;
    }
    case '4': {
        hal_flash_chip_erase(HAL_FLASH_ID_EXT);
        log_d("hal_flash_chip_erase \r\n");
        break;
    }
    default:
        break;
    }
}

MSH_CMD_EXPORT(mcu_flash_test, test);

#endif
#endif
#endif



