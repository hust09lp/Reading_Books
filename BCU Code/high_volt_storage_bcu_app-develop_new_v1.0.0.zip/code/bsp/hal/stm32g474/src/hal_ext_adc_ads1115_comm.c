#include <rtthread.h>
#include <stdlib.h>
#include <string.h>
#include "hal_ext_adc_ads1115_comm.h"
#include "hal_gpio.h"
#include "hal_hw_i2c.h"
#include "osif.h"
#include "log.h"
#include "pin_config.h"
#include "sofar_errors.h"

#define ADS1115_I2C_BUS_NO            (HAL_HW_I2C3)
#define ADS1115_ALERT1_PIN            (DI_1_PIN)    // TODO:后续根据原理确定哪个pin脚
#define ADS1115_ALERT2_PIN            (DI_NULL)    // TODO:后续根据原理确定哪个pin脚
#define ADS1115_ALERT3_PIN            (DI_NULL)    // TODO:后续根据原理确定哪个pin脚
#define ADS1115_ALERT_READ(pin)       (hal_gpio_read((pin)))    

#define ADS_WRITE_DATA(i2c_no, addr, buf, len)    hal_hw_i2c_write((i2c_no), (addr) , (buf), (len))
#define ADS_READ_DATA(i2c_no, addr, buf, len)     hal_hw_i2c_read((i2c_no), (addr), (buf), (len))
#define HAL_ADS_I2C_OPEN(i2c_id)                  hal_hw_i2c_open((i2c_id))
#define HAL_ADS_I2C_CLOSE(i2c_id)                 hal_hw_i2c_close((i2c_id))
#define MAKEWORD(high, low)                       ((uint16_t)((uint16_t)((high) << 8) | (low)))
#define HIBYPTE(word)                             ((uint8_t)((word & 0xFF00) >> 8))
#define LOBYPTE(word)                             ((uint8_t)(word & 0x00FF))

typedef struct {
    const int32_t alert_gpio_index;
    const uint32_t i2c_no;
    const os_mutex_attr_t ads_mutex_attr;
    os_mutex_id_t mutex_id;
    uint8_t dev_addr;
}soft_ads_dev_t;

static soft_ads_dev_t g_soft_ads_dev[] = {
    // ads1115设备1,设备地址需要根据实际电路来配置
    {ADS1115_ALERT1_PIN, ADS1115_I2C_BUS_NO, {"ads1_mtx", 0 ,0 ,0}, NULL, ADS1115_DEV_ADDR_GND},

};

static uint8_t g_ext_ads1115_status = {0};


/**
* @brief    ads读寄存器
* @param    [in] ext_ads1115_no 虚拟片外ads端口号    
* @param    [in] reg_addr 寄存器地址 (0-3) 
* @param    [in] *reg_value 获取寄存器的指针 
* @return    执行结果
* @retval    < 0 读失败
* @retval    SF_ERR_PARA 寄存器地址失败
* @retval    HAL_ENXIO  设备地址错误
* @retval    SF_ERR_OPEN 设备没有打开
* @retval    > 0 寄存器的值
* @pre      执行ext_ads1115_open后执行才有效 
*/
int32_t hal_single_register_read(uint32_t ext_ads1115_no, uint8_t reg_address, uint16_t *reg_value)
{
    if (reg_address >= NUM_ADS_REGISTERS || reg_value == NULL)
    {
        return SF_ERR_PARA;
    }
    if (!SF_GET_BIT(g_ext_ads1115_status, (1u << ext_ads1115_no)))
    {
        return SF_ERR_OPEN;
    }

    soft_ads_dev_t *ads_dev = &g_soft_ads_dev[ext_ads1115_no];
    os_mutex_acquire(ads_dev->mutex_id, OS_WAIT_FOREVER);
    int32_t ret = ADS_WRITE_DATA(ads_dev->i2c_no, ads_dev->dev_addr, &reg_address, sizeof(reg_address));
    if (ret <= 0)
    {
        // log_e("ads r reg w err%d\n", ret);
        os_mutex_release(ads_dev->mutex_id);
        return SF_ERR_NDEF;
    }
    uint8_t rx_data[2] = {0}; // ads寄存器都为uint16（2个字节)
    ret = ADS_READ_DATA(ads_dev->i2c_no, ads_dev->dev_addr, rx_data, sizeof(rx_data));
    if (ret <= 0)
    {
        // log_e("ads r reg r err%d\n", ret);
        os_mutex_release(ads_dev->mutex_id);
        return SF_ERR_NDEF;
    }
    *reg_value = MAKEWORD(rx_data[0], rx_data[1]);
    os_mutex_release(ads_dev->mutex_id);
    return (int32_t)SF_OK;
}

/**
* @brief    ads写寄存器(回读)
* @param    [in] ext_ads1115_no 虚拟片外ads端口号    
* @param    [in] reg_addr 寄存器地址 (0-3) 
* @param    [in] len 缓冲区长度  
* @return    执行结果
* @retval    = 0 发送成功 
* @retval    < 0 发送失败   
* @pre      执行ext_ads1115_open后执行才有效 
*/
int32_t hal_ads_single_register_write(uint32_t ext_ads1115_no, uint8_t reg_address, uint16_t reg_value)
{
    if (reg_address >= NUM_ADS_REGISTERS)
    {
        return SF_ERR_PARA;
    }
    if (!SF_GET_BIT(g_ext_ads1115_status, (1u << ext_ads1115_no)))
    {
        return SF_ERR_OPEN;
    }
    soft_ads_dev_t *ads_dev = &g_soft_ads_dev[ext_ads1115_no];
    os_mutex_acquire(ads_dev->mutex_id, OS_WAIT_FOREVER);
    // 定义3个字节长度的数组
    // 根据数据手册填充发送数据，send_buf0为寄存器地址，send_buf1，send_buf2为寄存器内容
    uint8_t send_buf[3] = {0};
    send_buf[0] = reg_address;
    send_buf[1] = HIBYPTE(reg_value);
    send_buf[2] = LOBYPTE(reg_value);
    int32_t ret = ADS_WRITE_DATA(ads_dev->i2c_no, ads_dev->dev_addr, send_buf, sizeof(send_buf));
    if (ret <= 0)
    {
        // log_e("ads w reg w err%d\n", ret);
        os_mutex_release(ads_dev->mutex_id);
        return SF_ERR_NDEF;
    }
    
    uint16_t read_reg_value = 0;
    ret = hal_single_register_read(ext_ads1115_no, reg_address, &read_reg_value);
    if (ret < 0)
    {
        // log_e("ads w reg r err%d\n", ret);
        os_mutex_release(ads_dev->mutex_id);
        return SF_ERR_NDEF;
    }
    if (reg_address != ADS_CONVERSION_REG_ADDRESS)
    {
        // CONFIG_REG 最高位读写意义不一样，过滤
        uint16_t write_value = (reg_address == ADS_CONFIG_REG_ADDRESS) ? reg_value & 0x7FFF : reg_value;
        uint16_t read_value = (reg_address == ADS_CONFIG_REG_ADDRESS) ? read_reg_value & 0x7FFF : read_reg_value;
        if (write_value != read_value)
        {
            // log_e("ads r 0x%x!= w 0x%x\n", read_value, write_value);
            os_mutex_release(ads_dev->mutex_id);
            return SF_ERR_NDEF;
        }
    }
    os_mutex_release(ads_dev->mutex_id);
    return SF_OK;
}

/**
* @brief    关闭公用i2c总线判断  
* @param    [in] ext_ads1115_no 虚拟片外ads端口号 
* @return    执行结果
* @retval    RT_FALSE 不关闭  
* @retval    RT_TRUE 关闭   
* @warning   
*/
rt_bool_t close_common_bus_judge(uint32_t ext_ads1115_no)
{
    uint32_t ext_ads1115_i2c_bus_no = g_soft_ads_dev[ext_ads1115_no].i2c_no;

    for (uint8_t i = 0; i < ITEM_NUM(g_soft_ads_dev); i++)
    {
        // 找出其他公用i2c bus的外设ads
        if ((i != ext_ads1115_no) && 
            (ext_ads1115_i2c_bus_no == g_soft_ads_dev[i].i2c_no))
        {
            // 其他外设ads正在启动i2c
            if (SF_GET_BIT(g_ext_ads1115_status, (1U << i)))
            {
                 return RT_FALSE;
            }
        }
    }
    return RT_TRUE;
}

/**
 * This function initializes the ads pin.
 *
 * @param Stm32 ads1115 dirver class.
 */
static void soft_ext_ads1115_gpio_init(soft_ads_dev_t *ext_ads)
{
    if (ext_ads == RT_NULL)
    {
        return;    
    }
    const hal_gpio_config_t gpio_config = {HAL_GPIO_INPUT, HAL_GPIO_PULLUP};
    int32_t ret = hal_gpio_config(ext_ads->alert_gpio_index, (hal_gpio_config_t *)&gpio_config);
    if (SF_OK != ret)
    {
        rt_kprintf("ads init gpio err = %ld\r\n", ret);
    }
}

/**
* @brief    ads1115加载驱动
* @return    执行结果
* @retval    SF_OK 成功
* @retval    SF_ERR_PARA 失败 
*/
int32_t hal_ext_ads1115_init(void)
{
    g_ext_ads1115_status = 0;
    // 需要确保IIC已经初始化完成
    for (uint8_t i = 0; i < ITEM_NUM(g_soft_ads_dev); i++)
    {
        // gpio init
        soft_ext_ads1115_gpio_init(g_soft_ads_dev);
        // mutex init
        g_soft_ads_dev[i].mutex_id = os_mutex_new(&(g_soft_ads_dev[i].ads_mutex_attr));
        if (g_soft_ads_dev[i].mutex_id == NULL)
        {
            log_e("ads%d mutex create fail\n",i);
        }
    }
    return SF_OK;
}

/**
* @brief    ads删除驱动(跟据配置删除对应的驱动)
* @return    执行结果
* @retval    SF_OK(0) 成功
* @retval    SF_ERR_PARA(<0) 失败 
*/
int32_t hal_ext_ads1115_deinit(void)
{
    uint8_t i;

    for (i = 0; i < ITEM_NUM(g_soft_ads_dev); i++)
    {
        if (g_soft_ads_dev[i].mutex_id)
        {
            os_mutex_delete(g_soft_ads_dev[i].mutex_id);
            g_soft_ads_dev[i].mutex_id = NULL;
        }
    } 
    return SF_OK;
}

/**
* @brief    打开ext_ads1115功能  
* @param    [in] ext_ads1115_no 虚拟ads端口号 
* @return    执行结果
* @retval    SF_OK 成功  
* @retval    SF_ERR_PARA 失败   
* @warning   
*/
int32_t hal_ext_ads1115_open(uint32_t ext_ads1115_no)
{
    if (ext_ads1115_no >= ITEM_NUM(g_soft_ads_dev)) 
    {
        return SF_ERR_PARA;
    }
    int32_t ret = HAL_ADS_I2C_OPEN(g_soft_ads_dev[ext_ads1115_no].i2c_no);
    if (ret != SF_OK)
    {
        return SF_ERR_PARA;
    }
    if (!SF_GET_BIT(g_ext_ads1115_status, (1U << ext_ads1115_no)))
    {
        SF_SET_BIT(g_ext_ads1115_status, (1U << ext_ads1115_no));
    }
    return SF_OK;
}

/**
* @brief    关闭片外ext_ads功能  
* @param    [in] i2c_no 虚拟I2C端口号 
* @return    执行结果
* @retval    SF_OK 成功  
* @retval    SF_ERR_PARA 失败   
* @warning     本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_ext_ads1115_close(uint32_t ext_ads1115_no)
{
    if (ext_ads1115_no >= ITEM_NUM(g_soft_ads_dev)) 
    {
        return SF_ERR_PARA;
    }
    
    if (SF_GET_BIT(g_ext_ads1115_status, (1u << ext_ads1115_no)))
    {
        SF_CLR_BIT(g_ext_ads1115_status, (1u << ext_ads1115_no));
    }
    if (close_common_bus_judge(ext_ads1115_no))
    {
        HAL_ADS_I2C_CLOSE(g_soft_ads_dev[ext_ads1115_no].i2c_no);
    }
    return SF_OK;
}

/**
* @brief    ads功能从休眠中唤醒，恢复状态
* @param    [in] ext_ads1115_no 虚拟ads端口号   
* @return    执行结果
* @retval    SF_OK 成功  
* @retval    SF_ERR_PARA 失败   
*/
int32_t hal_ext_ads1115_resume(uint32_t ext_ads1115_no)
{
    log_d("not support!");
    return SF_ERR_PARA;
}

/**
* @brief    ads功能进入休眠模式
* @param    [in] ext_ads1115_no 虚拟ads端口号   
* @return    执行结果
* @retval    SF_OK 成功  
* @retval    SF_ERR_PARA 失败   
* @warning    本接口调用后，需要把对应管脚也设置为低功耗模式，功能不影响
*/
int32_t hal_ext_ads1115_suspend(uint32_t ext_ads1115_no)
{
    log_d("not support!");
    return SF_ERR_PARA;
}

/**
* @brief    ads1115获取比较器结果
* @param    [in] ext_ads1115_no 虚拟ads端口号     
* @return    执行结果
* @retval    0 低电平
* @retval    1 高电平  
* @retval    < 0 失败原因    
* @pre      执行hal_ext_ads1115_open后执行才有效, 
*/
int32_t hal_ext_ads1115_alert_read(uint32_t ext_ads1115_no)
{
    if (!SF_GET_BIT(g_ext_ads1115_status, (1u << ext_ads1115_no)))
    {
        return SF_ERR_OPEN;
    }
    soft_ads_dev_t *ads_dev = &g_soft_ads_dev[ext_ads1115_no];
    return ADS1115_ALERT_READ(ads_dev->alert_gpio_index);
}


/**
 * @brief        ads1115_hal功能样例
 * @param        argv 功能参数
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
#ifdef RT_USING_FINSH
#ifdef RT_USING_FINSH_DEBUG

#define HAL_ADS_CONFIG_6P144V_AIN0_250SPS_CONT (0xC0A3)
static int test_ext_ads1115_sample(int argc, char *p_argv[])
{
    if (argc > 1)
    {
        if (0 == strcmp(p_argv[1], "init"))
        {
            hal_ext_ads1115_init();
        }
        else if (0 == strcmp(p_argv[1], "open"))
        {
            uint32_t ads_no = atoi(p_argv[2]);
            int32_t ret = hal_ext_ads1115_open(ads_no);
            if (ret < 0)
            {
                rt_kprintf("test ext_ads open %d, err%d\r\n", ads_no, ret);
            }
        }
        else if (strcmp(p_argv[1], "read") == 0)
        {
            uint32_t ads_no = atoi(p_argv[2]);
            uint8_t reg_addr = atoi(p_argv[3]);
            uint16_t reg_value = 0;
            int32_t ret = hal_single_register_read(ads_no, reg_addr, &reg_value);
            if (ret < 0)
            {
                rt_kprintf("test ext_ads read %d, err%d\r\n", ads_no, ret);
            }
            else 
            {
                rt_kprintf("test ext_ads_no%d, read data 0x%x(%ld)\r\n", ads_no, ret, ret);
            }
        }
        else if (strcmp(p_argv[1], "write") == 0)
        {
            uint32_t ads_no = atoi(p_argv[2]);
            uint8_t reg_addr = atoi(p_argv[3]);
            uint16_t wrtie_data = atoi(p_argv[4]);

            int32_t ret = hal_ads_single_register_write(ads_no, reg_addr, wrtie_data);
            if (ret < 0)
            {
                rt_kprintf("test ext_ads write %d, err%d\r\n", ads_no, ret);
            }
        }
        else if (strcmp(p_argv[1], "close") == 0)
        {
            uint32_t ads_no = atoi(p_argv[2]);
            int32_t ret = hal_ext_ads1115_close(ads_no);
            if (ret < 0)
            {
                rt_kprintf("test ext_ads close %d, err%d\r\n", ads_no, ret);
            }
        }
        else if (strcmp(p_argv[1], "pin") == 0)
        {
            uint32_t ads_no = atoi(p_argv[2]);
            int32_t ret = hal_ext_ads1115_alert_read(ads_no);
            if (ret < 0)
            {
                rt_kprintf("test ext_ads pin %d, err%d\r\n", ads_no, ret);
            }
            else
            {
                rt_kprintf("test ext_ads_no%d, pin:%d\r\n", ads_no, ret);
            }
        }
    } 
    return SF_OK;    
}
MSH_CMD_EXPORT(test_ext_ads1115_sample, test_ext_ads1115_sample <write/read xxx(0-3)>);
#endif
#endif
