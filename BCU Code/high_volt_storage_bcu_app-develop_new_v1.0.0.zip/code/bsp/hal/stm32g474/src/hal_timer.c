#include <board.h>
#include <string.h>
#include <rtthread.h>
#include <rtdevice.h>
#include "hal_timer.h"
#include "osif.h"
#include "log.h"
#include "sofar_errors.h"

#define IS_TIMER_TYPE(TYPE)   (((TYPE) == HAL_TIMER_PERIODIC) || ((TYPE) == HAL_TIMER_ONSHOT))

TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;
TIM_HandleTypeDef htim5;

// timer回调函数
static timer_callback g_timer_cb[HAL_HW_TIMER_MAX];

// 标识timer状态
static uint8_t g_timer_status;

static hal_hwtimer_t g_hal_timer[HAL_HW_TIMER_MAX] = {
    { 
       .tim_no        = 0,          
       .tim_handle    = &htim3,         
       .tim_irqn     = TIM3_IRQn,  
       .tim_instance = TIM3,
    },
    
    { 
       .tim_no        = 0,          
       .tim_handle    = &htim4,         
       .tim_irqn     = TIM4_IRQn,    
       .tim_instance = TIM4,        
    },   

    { 
       .tim_no        = 0,          
       .tim_handle    = &htim5,          
       .tim_irqn     = TIM5_IRQn,     
       .tim_instance = TIM5,        
    }, 
};

/**
* @brief		定时器加载驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_timer_init(void)
{
	memset((void *)g_timer_cb, 0, sizeof(timer_callback)*HAL_HW_TIMER_MAX);
	g_timer_status = 0;
	return SF_OK;
}
INIT_BOARD_EXPORT(hal_timer_init);


/**
* @brief		定时器删除驱动
* @return		执行结果
* @retval		SF_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_timer_deinit(void)
{
	return SF_OK;
}


/**
* @brief		打开定时器  
* @param		[in] tim_no 虚拟timer编号  
* @param		[in] mode 使用模式 暂未使用
* -# HAL_TIMER_MODE_TIMER = 定时器模式
* -# HAL_TIMER_MODE_COUNTER = 计数器模式 
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		HAL_EIO 失败   
* @pre			执行hal_timer_init后执行才有效。
*/
int32_t hal_timer_open(uint32_t tim_no, uint32_t mode)
{
	/* 虚拟设备号范围检查 */
	if (tim_no >= HAL_HW_TIMER_MAX) 
	{
		return SF_ERR_PARA;
	}
	/* 设备已打开，直接返回ok,避免重复打开 */
	if (SF_GET_BIT(g_timer_status, (1U << tim_no)) != 0)
    {
        return SF_OK;
    }
        
	SET_BIT(g_timer_status, (1U << tim_no));	
    
	return SF_OK;
}


/**
* @brief		关闭定时器  
* @param		[in] tim_no 虚拟timer编号
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		HAL_EIO 失败   
* @pre			执行hal_timer_init后执行才有效。
*/
int32_t hal_timer_close(uint32_t tim_no)
{
	/* 虚拟设备号范围检查 */
	if (tim_no >= HAL_HW_TIMER_MAX) 
	{
		return SF_ERR_PARA;
	}
	/* 设备已关闭，直接返回ok,避免重复关闭 */
	if (SF_GET_BIT(g_timer_status, (1U << tim_no)) == 0)
    {
        return SF_OK;
    }

	SF_CLR_BIT(g_timer_status, (1U << tim_no));

    /* enable the TIMx global Interrupt */
    HAL_NVIC_DisableIRQ(g_hal_timer[tim_no].tim_irqn);

    /* enable update request source */
    __HAL_TIM_URS_DISABLE(g_hal_timer[tim_no].tim_handle);
	
	return SF_OK;
}


/**
* @brief		定时器中断回调  
* @param		[in] dev 定时器设备句柄   
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		HAL_EIO 失败   
* @pre			内部函数。
*/
//static rt_err_t timer_irq_cb(rt_device_t dev, rt_size_t size)
//{
//int i;
//for (i = 0; i < HAL_HW_TIMER_MAX; i++)
//{
//    if (g_timer[i] == dev)
//    {
//        if (g_timer_cb[i])
//            g_timer_cb[i](i, size);
//    }
//}

//return RT_EOK;
//}

/**
* @brief		设置定时器并启动
* @param		[in] tim_no 虚拟timer编号  
* @param		[in] type 定时类型  
* -# HAL_TIMER_ONSHOT = 1   只产生一次中断
* -# HAL_TIMER_PERIODIC = 2 重复产生周期性中断
* @param		[in] p_timeout 定时器周期 
* @param		[in] cb 定时器中断回掉函数  
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		HAL_EIO 失败   
* @pre			执行hal_timer_init后执行才有效。
*/
int32_t hal_timer_setup(uint32_t tim_no, uint32_t type, hal_timerval_t *p_timeout, timer_callback p_fcallback)
{
//    uint16_t val = 0;
	uint32_t freq = 0;
    uint32_t tim_cnt = 0;

	/* 参数合法性检查 */
	if ((tim_no >= HAL_HW_TIMER_MAX) 
		|| (!IS_TIMER_TYPE(type)) 
		|| (!p_timeout) 
		|| (!p_fcallback))
	{
		return SF_ERR_PARA;
	}
	/* 设备未打开，返回err */
	if (SF_GET_BIT(g_timer_status, (1U << tim_no)) == 0)
    {
        return SF_ERR_PARA;
    }
    

	/* 设置超时回调函数 */		
	if(p_fcallback)
	{
		g_timer_cb[tim_no] = p_fcallback;
	}	
    
    if(p_timeout->sec > 0)
    {
        freq = 4000;    //4khz
        tim_cnt = p_timeout->sec * 4000 + p_timeout->usec / 4000;  
    }
    else
    {
        freq = 1000000; //1Mhz
        tim_cnt = p_timeout->usec;
    }
    
    freq = (uint32_t)HAL_RCC_GetPCLK1Freq() / freq - 1; 
    
    g_hal_timer[tim_no].tim_handle->Instance = g_hal_timer[tim_no].tim_instance;
    g_hal_timer[tim_no].tim_handle->Init.Period = tim_cnt;
    g_hal_timer[tim_no].tim_handle->Init.Prescaler = freq;
    g_hal_timer[tim_no].tim_handle->Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    g_hal_timer[tim_no].tim_handle->Init.CounterMode = TIM_COUNTERMODE_UP;
    g_hal_timer[tim_no].tim_handle->Init.RepetitionCounter = 0;
//    g_hal_timer[tim_no].tim_handle->Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
    
    if (HAL_TIM_Base_Init(g_hal_timer[tim_no].tim_handle) != HAL_OK)
    {
        log_e("%s init failed", tim_no);
        return -1;
    }
    else
    {
        __HAL_TIM_SET_PRESCALER(g_hal_timer[tim_no].tim_handle, freq);
        
        g_hal_timer[tim_no].tim_handle->Instance->EGR = TIM_EVENTSOURCE_UPDATE;
        
        /* set the TIMx priority */
        HAL_NVIC_SetPriority(g_hal_timer[tim_no].tim_irqn, 3, 0);

        /* enable the TIMx global Interrupt */
        HAL_NVIC_EnableIRQ(g_hal_timer[tim_no].tim_irqn);

        /* clear update flag */
        __HAL_TIM_CLEAR_FLAG(g_hal_timer[tim_no].tim_handle, TIM_FLAG_UPDATE);
        /* enable update request source */
        __HAL_TIM_URS_ENABLE(g_hal_timer[tim_no].tim_handle);

        log_d("%d init success\n", tim_no);        
    }
    
//    /* set tim cnt */
//    __HAL_TIM_SET_COUNTER(g_hal_timer[tim_no].tim_handle, 0);
//    /* set tim arr */
//    __HAL_TIM_SET_AUTORELOAD(g_hal_timer[tim_no].tim_handle, 10000);
    
    /* Selects the TIMx's One Pulse Mode */
    if(type == HAL_TIMER_ONSHOT)
    {
        /* set timer to single mode */
        g_hal_timer[tim_no].tim_handle->Instance->CR1 |= TIM_OPMODE_SINGLE;    
    }
    else
    {
        g_hal_timer[tim_no].tim_handle->Instance->CR1 &= (~TIM_OPMODE_SINGLE);
    }    
  
    /* start timer */
    if (HAL_TIM_Base_Start_IT(g_hal_timer[tim_no].tim_handle) != HAL_OK)
    {
        log_e("TIM start failed");
        return -RT_ERROR;
    }
    
	return SF_OK;
}

/**
* @brief		设置下次中断时间(不用每次调用setup去设置一串寄存器)
* @param		[in] tim_no 虚拟timer编号
* -# timer1 - 0x00  
* -# timer2 - 0x01
* -# timer3 - 0x02  
* -# timer4 - 0x03  
* -# timer5 - 0x04    
* -# timer6 - 0x05
* -# timer7 - 0x06  
* -# timer8 - 0x07    
* @param		[in] interval 设置下次中断时间间隔 (单位us)  
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		HAL_EIO 失败   
* @pre			需先执行hal_timer_open和hal_timer_setup后执行才有效 
*/
int32_t hal_timer_interval(uint32_t tim_no, uint32_t interval)
{
	return SF_OK;
}

/**
* @brief		启动定时计数器 
* @param		[in] tim_no 虚拟timer编号
* -# timer1 - 0x00  
* -# timer2 - 0x01
* -# timer3 - 0x02  
* -# timer4 - 0x03  
* -# timer5 - 0x04    
* -# timer6 - 0x05
* -# timer7 - 0x06  
* -# timer8 - 0x07    
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		HAL_EIO 失败   
* @pre			需先执行hal_timer_open后执行才有效 
*/
int32_t hal_timer_start(uint32_t tim_no)
{
	return SF_OK;
}

/**
* @brief		停止定时计数器 
* @param		[in] tim_no 虚拟timer编号
* -# timer1 - 0x00  
* -# timer2 - 0x01
* -# timer3 - 0x02  
* -# timer4 - 0x03  
* -# timer5 - 0x04    
* -# timer6 - 0x05
* -# timer7 - 0x06  
* -# timer8 - 0x07    
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		HAL_EIO 失败   
*/
int32_t hal_timer_stop(uint32_t tim_no)
{
	return SF_OK;
}

/**
* @brief		读取定时器COUNTER值(磁头驱动会用到) 
* @param		[in] tim_no 虚拟timer编号
* -# timer1 - 0x00  
* -# timer2 - 0x01
* -# timer3 - 0x02  
* -# timer4 - 0x03  
* -# timer5 - 0x04    
* -# timer6 - 0x05
* -# timer7 - 0x06  
* -# timer8 - 0x07    
* @return		返回COUNTER计数值 
* @pre			需先执行hal_timer_open并且mode设置为HAL_TIMER_MODE_COUNTER 
*/
uint32_t hal_timer_read(uint32_t tim_no)
{
	return SF_OK;
}

/**
* @brief		TIMER特殊命令 
* @param		[in] tim_no 虚拟timer编号
* -# timer1 - 0x00  
* -# timer2 - 0x01
* -# timer3 - 0x02  
* -# timer4 - 0x03  
* -# timer5 - 0x04    
* -# timer6 - 0x05
* -# timer7 - 0x06  
* -# timer8 - 0x07    
* @param		[in] cmd 命令字
* -# HAL_TIMER_CMD_CLK_DIV = 设置TIMER分频 
* @param		[in] param 对应cmd的参数，没有参数则为NULL
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		<0 失败原因     
* @pre			执行hal_timer_open后执行才有效 
*/
int32_t hal_timer_ioctl(uint32_t tim_no, int32_t cmd, int32_t param)
{
	return SF_OK;
}

void TIM3_IRQHandler(void)
{
    /* enter interrupt */
    rt_interrupt_enter();
    if (__HAL_TIM_GET_IT_SOURCE(g_hal_timer[HAL_HW_TIMER3].tim_handle, TIM_IT_UPDATE) != RESET)
    {
      __HAL_TIM_CLEAR_IT(g_hal_timer[HAL_HW_TIMER3].tim_handle, TIM_IT_UPDATE);
      g_timer_cb[HAL_HW_TIMER3](HAL_HW_TIMER3, 0);
    }
    /* leave interrupt */
    rt_interrupt_leave();
}

void TIM4_IRQHandler(void)
{
    /* enter interrupt */
    rt_interrupt_enter();
    if (__HAL_TIM_GET_IT_SOURCE(g_hal_timer[HAL_HW_TIMER4].tim_handle, TIM_IT_UPDATE) != RESET)
    {
      __HAL_TIM_CLEAR_IT(g_hal_timer[HAL_HW_TIMER4].tim_handle, TIM_IT_UPDATE);
      g_timer_cb[HAL_HW_TIMER4](HAL_HW_TIMER4, 0);
    }
    /* leave interrupt */
    rt_interrupt_leave();
}

void TIM5_IRQHandler(void)
{
    /* enter interrupt */
    rt_interrupt_enter();
    if (__HAL_TIM_GET_IT_SOURCE(g_hal_timer[HAL_HW_TIMER5].tim_handle, TIM_IT_UPDATE) != RESET)
    {
      __HAL_TIM_CLEAR_IT(g_hal_timer[HAL_HW_TIMER5].tim_handle, TIM_IT_UPDATE);
      g_timer_cb[HAL_HW_TIMER5](HAL_HW_TIMER5, 0);
    }
    /* leave interrupt */
    rt_interrupt_leave();
}

/**
* @brief        PWM_HAL功能样例
* @param        argv 功能参数
* @return       返回结果
* @retval         SF_OK 成功
* @retval         HAL_EIO 失败
*/
#ifdef RT_USING_FINSH
//#ifdef RT_USING_FINSH_DEBUG
//#if defined(BSP_USING_PWM)

static int32_t time3_cb(uint32_t tim_no, uint32_t size)
{
    rt_kprintf("tim3: %d\n", os_kernel_get_tick_count());
    return 0;
}
static int32_t time4_cb(uint32_t tim_no, uint32_t size)
{
    rt_kprintf("tim4: %d\n", os_kernel_get_tick_count());
    return 0;
}
static int32_t time5_cb(uint32_t tim_no, uint32_t size)
{
    rt_kprintf("tim5: %d\n", os_kernel_get_tick_count());
    return 0;
}

static int hal_timer_sample(int argc, char *argv[])
{
	char 	*pwm_opt  = argv[1];
	hal_timerval_t hwtimerval = {10, 0};
	
	if (!rt_strcmp(pwm_opt, "start"))
	{
		hal_timer_open(HAL_HW_TIMER3, HAL_TIMER_MODE_TIMER);
		hal_timer_setup(HAL_HW_TIMER3, HAL_TIMER_PERIODIC, &hwtimerval, time3_cb);
		hal_timer_open(HAL_HW_TIMER4, HAL_TIMER_MODE_TIMER);
		hal_timer_setup(HAL_HW_TIMER4, HAL_TIMER_PERIODIC, &hwtimerval, time4_cb);
		hal_timer_open(HAL_HW_TIMER5, HAL_TIMER_MODE_TIMER);
		hal_timer_setup(HAL_HW_TIMER5, HAL_TIMER_PERIODIC, &hwtimerval, time5_cb);
	}
	if (!rt_strcmp(pwm_opt, "stop"))
	{
		hal_timer_close(HAL_HW_TIMER3);
		hal_timer_close(HAL_HW_TIMER4);
		hal_timer_close(HAL_HW_TIMER5);
	}
	
	return SF_OK;
}
//#endif
MSH_CMD_EXPORT(hal_timer_sample, hal_timer_sample <start/stop>);
//#endif
#endif






