#include <board.h>
#include <string.h>
#include <rtthread.h>
#include <rtdevice.h>
#include "hal_gpio.h"
#include "hal_capture.h"
#include "pin_config.h"
#include "log.h"
#include "sofar_errors.h"

enum
{
    CAPTURE1_INDEX,
};

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef g_htim15;

/* Captured Value */
__IO uint32_t            g_capture_value[CAPTURE_CHAN_MAX] = {0};
/* Duty Cycle Value */
__IO uint32_t            g_capture_duty[CAPTURE_CHAN_MAX]  = {0};
/* Frequency Value */
__IO uint32_t            g_capture_freq[CAPTURE_CHAN_MAX]  = {0};
/* capture flag */
__IO uint32_t 			 g_capture_flag  = 0;
/* capture cnt */
__IO uint32_t 			 g_capture_counter[CAPTURE_CHAN_MAX]  = {0};

typedef struct{
	uint32_t is_init;	
	uint32_t is_start;	
	uint32_t is_suspend;
}capture_status_t;

static capture_status_t g_capture_status = {0};


/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static HAL_StatusTypeDef MX_TIM15_Init(void)
{
    TIM_SlaveConfigTypeDef sSlaveConfig = {0};
    TIM_MasterConfigTypeDef sMasterConfig = {0};
    TIM_IC_InitTypeDef sConfigIC = {0};
    HAL_StatusTypeDef ret = HAL_OK;

    g_htim15.Instance = TIM15;
    g_htim15.Init.Prescaler = 100-1;
    g_htim15.Init.CounterMode = TIM_COUNTERMODE_UP;
    g_htim15.Init.Period = 60000;
    g_htim15.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    g_htim15.Init.RepetitionCounter = 0;
    g_htim15.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
    ret = HAL_TIM_Base_Init(&g_htim15);
    if (ret != HAL_OK)
    {
        log_e("TimBaseInitErr%d\n", ret);
        return ret;
    }
    
    ret = HAL_TIM_IC_Init(&g_htim15);
    if (ret != HAL_OK)
    {
        log_e("TimIcInitErr%d\n", ret);
        return ret;
    }

    sSlaveConfig.SlaveMode = TIM_SLAVEMODE_RESET;
    sSlaveConfig.InputTrigger = TIM_TS_TI2FP2;
    sSlaveConfig.TriggerPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
    sSlaveConfig.TriggerFilter = 0;
    ret = HAL_TIM_SlaveConfigSynchro(&g_htim15, &sSlaveConfig);
    if (ret != HAL_OK)
    {
        log_e("TimSlaErr%d\n", ret);
        return ret;
    }
    
    sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
    sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
    sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
    ret = HAL_TIMEx_MasterConfigSynchronization(&g_htim15, &sMasterConfig);
    if (ret != HAL_OK)
    {
        log_e("TimMstErr%d\n", ret);
        return ret;
    }
    sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_FALLING;
    sConfigIC.ICSelection = TIM_ICSELECTION_INDIRECTTI;
    sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
    sConfigIC.ICFilter = 0;
    ret = HAL_TIM_IC_ConfigChannel(&g_htim15, &sConfigIC, TIM_CHANNEL_1);
    if (ret != HAL_OK)
    {
        log_e("TimChl1Err%d\n", ret);
        return ret;
    }
    
    sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
    sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
	sConfigIC.ICFilter = 1;
    ret = HAL_TIM_IC_ConfigChannel(&g_htim15, &sConfigIC, TIM_CHANNEL_2);
    if (ret != HAL_OK)
    {
        log_e("TimChl2Err%d\n", ret);
        return ret;
    }
    return ret;
}


/**
  * @brief  Input Capture callback in non blocking mode 
  * @param  htim : TIM IC handle
  * @retval None
  */
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
  static uint32_t duty[CAPTURE_CHAN_MAX] = {0};
  static uint32_t freq[CAPTURE_CHAN_MAX] = {0};
  static uint32_t last_duty[CAPTURE_CHAN_MAX] = {0};
  static uint32_t last_freq[CAPTURE_CHAN_MAX] = {0};
  static uint32_t cap_diff_cnt = 0;
  
  if ((htim->Instance == TIM15) && (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_2))
  {
	  SF_SET_BIT(g_capture_flag, (1U << CAPTURE1_INDEX));
	  
	  /* Get the Input Capture value */
	  g_capture_value[CAPTURE1_INDEX] = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_2);
	  if (g_capture_value[CAPTURE1_INDEX] != 0)
	  {
		  /* Duty cycle computation */
		  duty[CAPTURE1_INDEX] = ((((HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1))) * 100) + \
								 (g_capture_value[CAPTURE1_INDEX]/2)) / g_capture_value[CAPTURE1_INDEX];
		  
		  /* g_capture_freq computation TIM1 counter clock = (System Clock) */
		  freq[CAPTURE1_INDEX] = ((HAL_RCC_GetSysClockFreq()) / g_capture_value[CAPTURE1_INDEX]  + 50) / 100;
	  }
	  else
	  {
		  duty[CAPTURE1_INDEX] = 0;
		  freq[CAPTURE1_INDEX] = 0;
	  }
	  
	  if ((duty[CAPTURE1_INDEX] != last_duty[CAPTURE1_INDEX]) || 
		  (freq[CAPTURE1_INDEX] != last_freq[CAPTURE1_INDEX]))
	  {
		  last_duty[CAPTURE1_INDEX] = duty[CAPTURE1_INDEX];
		  last_freq[CAPTURE1_INDEX] = freq[CAPTURE1_INDEX];
		  if (cap_diff_cnt++ < 3)
		  {
//			  log_d("lost: [%d %d]\n",freq[CAPTURE1_INDEX], duty[CAPTURE1_INDEX]);
			  return;
		  }
	  }
	  cap_diff_cnt = 0;
	  g_capture_duty[CAPTURE1_INDEX] = duty[CAPTURE1_INDEX];
      g_capture_freq[CAPTURE1_INDEX] = freq[CAPTURE1_INDEX];
	  //log_d("cap: [%d %d]\n",g_capture_freq[CAPTURE1_INDEX], g_capture_duty[CAPTURE1_INDEX]);
  }
}

void HAL_TIM_UPDATE_Callback(TIM_HandleTypeDef *htim)
{
	if (htim->Instance == TIM15)
	{
		if (SF_GET_BIT(g_capture_flag, (1U << CAPTURE1_INDEX)) == 0)
		{
			// 连续5次溢出中断，都没有捕获中断，读取电平状态来判断占空比
			if (g_capture_counter[CAPTURE1_INDEX]++ > 5)
			{
				if (hal_gpio_read(DI_14_PIN) == 1)
				{
					g_capture_duty[CAPTURE1_INDEX] = 100;
				}
				else
				{
					g_capture_duty[CAPTURE1_INDEX] = 0;
				}
				g_capture_counter[CAPTURE1_INDEX] = 0;		
			}
		}
		else
		{
			g_capture_counter[CAPTURE1_INDEX] = 0;
		}
		SF_CLR_BIT(g_capture_flag, (1U << CAPTURE1_INDEX));
	}
}

void TIM1_BRK_TIM15_IRQHandler(void)
{
	HAL_TIM_IRQHandler(&g_htim15);
}
/**
 * @brief       capture 加载驱动
 * @return      执行结果
 * @retval 0    执行成功
 * @retval < 0  执行失败
 */
int32_t hal_capture_init(void)
{
    HAL_StatusTypeDef ret = HAL_OK;
    if (!g_capture_status.is_init)
    {
        ret = MX_TIM15_Init();
        if (ret != HAL_OK)
        {
            log_e("CaptureinitErr%d,retry\n", ret);
            ret = MX_TIM15_Init();
            if (ret != HAL_OK)
            {
                log_e("CaptureInitErr%d\n", ret);
                return ret;
            }
        }
        g_capture_status.is_init = 1;
    }
    return HAL_OK;
}

/**
* @brief		capture删除驱动
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
*/
int32_t hal_capture_deinit(void)
{
	if (g_capture_status.is_init)
	{
		memset((void *)&g_capture_status, 0, sizeof(capture_status_t));
	}
	
	return SF_OK;
}

/**
 * @brief           capture配置
 * @param channel   [in] capture 通道
 * @param channel   [in] p_config capture配置结构体
 * @return          执行结果
 * @retval 0        执行成功
 * @retval < 0      执行失败
 * @note            if(p_config->type == CAPTURE_FREQ)，polarity只支持CAPTURE_RISING和CAPTURE_FALLING，否则返回失败（不支持）
 */
int32_t hal_capture_config(uint32_t channel, hal_capture_config_t *p_config)
{
	return SF_ERR_FNOSUPP;
}

/**
 * @brief           启动 capture
 * @param channel   [in] capture 通道
 * @return          执行结果
 * @retval 0        执行成功
 * @retval < 0      执行失败
 */
int32_t hal_capture_start(uint32_t channel)
{
	int32_t ret;
	
	if ((channel > CAPTURE_CHAN_MAX))
	{
		ret =  SF_ERR_PARA;
		goto failed;
	}
	
	// if adc is not init, return failed 
	if (!g_capture_status.is_init)
	{
		ret = SF_ERR_PARA;
		goto failed;
	} 
	// if capture is started, return ok
	if (SF_GET_BIT(g_capture_status.is_start, (1U << channel)))
    {
        return SF_OK;
    } 
	/* start timer */
    if (HAL_TIM_Base_Start_IT(&g_htim15) != HAL_OK)
    {
        ret = SF_ERR_NDEF;
		goto failed;
    }
	// Start the Input Capture in interrupt mode
	if (HAL_TIM_IC_Start_IT(&g_htim15, TIM_CHANNEL_1) != HAL_OK)
	{
		ret = SF_ERR_NDEF;
		goto failed;
	}
	// Start the Input Capture in interrupt mode
	if(HAL_TIM_IC_Start_IT(&g_htim15, TIM_CHANNEL_2) != HAL_OK)
    {
		ret = SF_ERR_NDEF;
		goto failed;
    }
	SET_BIT(g_capture_status.is_start, (1U << channel));	
	return SF_OK;
	
failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;
}

/**
 * @brief           capture 停止
 * @param channel   [in] capture 通道
 * @return          执行结果
 * @retval 0        执行成功
 * @retval < 0      执行失败
 */
int32_t hal_capture_stop(uint32_t channel)
{
	int32_t ret;
	
	/* check para */
	if ((channel > CAPTURE_CHAN_MAX))
	{
		ret =  SF_ERR_PARA;
		goto failed;
	}
	// if capture is not started, return ok
	if (SF_GET_BIT(g_capture_status.is_start, (1U << channel)) == 0)
    {
        ret =  SF_ERR_PARA;
		goto failed;
    }
    // Stop the Input Capture in interrupt mode
	if(HAL_TIM_IC_Stop_IT(&g_htim15, TIM_CHANNEL_1) != HAL_OK)
    {
		ret = SF_ERR_NDEF;
		goto failed;
    }
	// Stop the Input Capture in interrupt mode
	if(HAL_TIM_IC_Stop_IT(&g_htim15, TIM_CHANNEL_2) != HAL_OK)
    {
		ret = SF_ERR_NDEF;
		goto failed;
    }
	/* stop timer */
    if (HAL_TIM_Base_Stop_IT(&g_htim15) != HAL_OK)
    {
        ret = SF_ERR_NDEF;
		goto failed;
    }
	SF_CLR_BIT(g_capture_status.is_start, (1U << channel));	
	return SF_OK;
	
failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;
}


/**
* @brief		PWM功能从休眠中唤醒，恢复状态
* @param		[in] pwm_tim_no pwm定时器id
* @param		[in] chan pwm通道编号
* @return		执行结果
* @retval		HAL_OK（0） 成功  
* @retval		HAL_EIO（<0） 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_capture_resume(uint32_t channel)
{
	/* check para */
	if ((channel > CAPTURE_CHAN_MAX))
	{
		return SF_ERR_PARA;
	}
	switch(channel)
	{
		case 0:
			//n32_msp_tim_init(TIM2);
			break;
		default:
			break;	
	}
	
	return hal_capture_start(channel);
}
 
/**
* @brief		PWM功能进入休眠模式
* @param		[in] pwm_tim_no pwm定时器id
* @param		[in] chan pwm通道编号
* @return		执行结果
* @retval		HAL_OK（0） 成功  
* @retval		HAL_EIO（<0） 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式，功能不影响
*/
int32_t hal_capture_suspend(uint32_t channel)
{
	/* check para */
	if ((channel > CAPTURE_CHAN_MAX))
	{
		return SF_ERR_PARA;
	}

	hal_capture_stop(channel);
	switch(channel)
	{
		case 0:
			//RCC_EnableAPB1PeriphClk(RCC_APB1_PERIPH_TIM2, DISABLE);
			break;
		default:
			break;	
	}
	
	return SF_OK;
}

/**
 * @brief capture数据读取
 * @param channel   [in] capture 通道
 * @param channel   [out] p_capture 读取的capture结构体
 * -# 0x00 - 不清除
 * -# 0x01 - 清除
 * @return          执行结果
 * @retval 0        执行成功
 * @retval < 0      执行失败
 */
int32_t hal_capture_freq_read(uint32_t channel, hal_capture_data_t *p_capture)
{
	/* check para */
	if ((channel > CAPTURE_CHAN_MAX))
	{
		return SF_ERR_PARA;
	}
	
	p_capture->freq_hz = g_capture_freq[channel];
	p_capture->duty_percent = g_capture_duty[channel];
	
	return SF_OK;
}

/**
 * @brief capture脉冲计数读取
 * @param channel   [in] capture 通道
 * @param p_capture [in] clear_flag 读完是否清除数据
 * -# 0x00 - 不清除
 * -# 0x01 - 清除
 * @return          执行结果
 * @retval >= 0     读取的脉冲次数计数值
 * @retval < 0      执行失败
 */
int32_t hal_capture_counter_read(uint32_t channel, uint8_t clear_flag)
{
	return SF_ERR_FNOSUPP;
}

/**
 * @brief           capture 命令控制
 * @param channel   [in] capture 通道
 * @param cmd       [in] 功能码
 * @param args      [in] 参数
 * @return          执行结果
 * @retval 0        执行成功
 * @retval < 0      执行失败
 */
int32_t hal_capture_ioctl(uint32_t channel, uint32_t cmd, void *args)
{
	return SF_ERR_FNOSUPP;
}



/**
* @brief        PWM_HAL功能样例
* @param        argv 功能参数
* @return       返回结果
* @retval         HAL_OK 成功
* @retval         HAL_EIO 失败
*/
#ifdef RT_USING_FINSH

static int hal_capture_test(int argc, char *argv[])
{
	char 	*pwm_opt  = argv[1];
	hal_capture_data_t capture_data;
	//hal_capture_data_t last_capture_data;

	if (!rt_strcmp(pwm_opt, "start"))
	{
		hal_capture_start(0);
	}
	if (!rt_strcmp(pwm_opt, "stop"))
	{
		hal_capture_stop(0);
	}
	if (!rt_strcmp(pwm_opt, "get"))
	{
		hal_capture_freq_read(0, &capture_data);
		log_d("[capture] pwm: %dhz %d(%) \n", capture_data.freq_hz, capture_data.duty_percent);
	}
	
	return SF_OK;
}

MSH_CMD_EXPORT(hal_capture_test, hal_capture_test <start/stop>);

#endif





