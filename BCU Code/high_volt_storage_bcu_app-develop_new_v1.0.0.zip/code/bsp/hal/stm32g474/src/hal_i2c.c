#include <board.h>
#include <rtthread.h>
#include <rtdevice.h>
#include "hal_i2c.h"
#include "hal_gpio.h"
#include "string.h"
#include "osif.h"
#include "log.h"
#include "sofar_errors.h"

#define RT_USING_I2C
//#define BSP_USING_I2C3
#define BSP_USING_I2C4

#define HAL_I2C_WRITE_FLAG          0x00
#define HAL_I2C_READ_FLAG           0x01

#ifdef RT_USING_I2C
typedef struct
{
    const GPIO_TypeDef* scl_gpio_port;
    const uint16_t scl_gpio_pin;
    const GPIO_TypeDef* sda_gpio_port;
    const uint16_t sda_gpio_pin;
    const os_mutex_attr_t i2c_mutex_attr;
    os_mutex_id_t mutex_id;
    uint32_t delay_us;  /* scl and sda line delay */
    uint32_t timeout;   /* in tick */
    uint8_t dev_addr;
}soft_i2c_bus_t;



static soft_i2c_bus_t g_soft_i2c_bus[] = {
#ifdef BSP_USING_I2C1
	{GPIOA, GPIO_PIN_8, GPIOC, GPIO_PIN_9, {"i2c1_mtx",0,0,0}, NULL, 1, 100, 0x00},
#endif
#ifdef BSP_USING_I2C2
	{GPIOH, GPIO_PIN_10, GPIOA, GPIO_PIN_10, {"i2c2_mtx",0,0,0}, NULL, 1, 100, 0x00},
#endif
#ifdef BSP_USING_I2C3
	{GPIOC, GPIO_PIN_6, GPIOC, GPIO_PIN_7, {"i2c3_mtx",0,0,0}, NULL, 1, 100, 0x00},
#endif
#ifdef BSP_USING_I2C4
	{GPIOC, GPIO_PIN_8, GPIOC, GPIO_PIN_9, {"i2c4_mtx",0,0,0}, NULL, 1, 100, 0x00},
#endif
};


static uint8_t g_i2c_status;

/**
 * This function initializes the i2c pin.
 *
 * @param Stm32 i2c dirver class.
 */
static void soft_i2c_gpio_init(soft_i2c_bus_t *i2c_bus)
{
	GPIO_InitTypeDef GPIO_InitStruct;

    /* Configure GPIO_InitStructure */
    GPIO_InitStruct.Pin = i2c_bus->scl_gpio_pin;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
	//GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	
	HAL_GPIO_Init((GPIO_TypeDef*)i2c_bus->scl_gpio_port, &GPIO_InitStruct);

    
    GPIO_InitStruct.Pin = i2c_bus->sda_gpio_pin;
	HAL_GPIO_Init((GPIO_TypeDef*)i2c_bus->sda_gpio_port, &GPIO_InitStruct);
    
	HAL_GPIO_WritePin((GPIO_TypeDef*)i2c_bus->scl_gpio_port, i2c_bus->scl_gpio_pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin((GPIO_TypeDef*)i2c_bus->scl_gpio_port, i2c_bus->sda_gpio_pin, GPIO_PIN_SET);
}

/**
 * This function sets the sda pin.
 *
 * @param Stm32 config class.
 * @param The sda pin state.
 */
static void soft_set_sda(soft_i2c_bus_t *i2c_bus, rt_int32_t state)
{
    if (state)
    {
		HAL_GPIO_WritePin((GPIO_TypeDef*)i2c_bus->scl_gpio_port, i2c_bus->sda_gpio_pin, GPIO_PIN_SET);
    }
    else
    {
		HAL_GPIO_WritePin((GPIO_TypeDef*)i2c_bus->scl_gpio_port, i2c_bus->sda_gpio_pin, GPIO_PIN_RESET);
    }
}

/**
 * This function sets the scl pin.
 *
 * @param Stm32 config class.
 * @param The scl pin state.
 */
static void soft_set_scl(soft_i2c_bus_t *i2c_bus, rt_int32_t state)
{
    if (state)
    {
		HAL_GPIO_WritePin((GPIO_TypeDef*)i2c_bus->scl_gpio_port, i2c_bus->scl_gpio_pin, GPIO_PIN_SET);
    }
    else
    {
		HAL_GPIO_WritePin((GPIO_TypeDef*)i2c_bus->scl_gpio_port, i2c_bus->scl_gpio_pin, GPIO_PIN_RESET);
    }
}

/**
 * This function gets the sda pin state.
 *
 * @param The sda pin state.
 */
static rt_int32_t soft_get_sda(soft_i2c_bus_t *i2c_bus)
{
	return HAL_GPIO_ReadPin((GPIO_TypeDef*)i2c_bus->scl_gpio_port,i2c_bus->sda_gpio_pin);
}


/**
 * This function gets the scl pin state.
 *
 * @param The scl pin state.
 */
static rt_int32_t soft_get_scl(soft_i2c_bus_t *i2c_bus)
{
	return HAL_GPIO_ReadPin((GPIO_TypeDef*)i2c_bus->scl_gpio_port,i2c_bus->scl_gpio_pin);
}

/**
 * The time delay function.
 *
 * @param microseconds.
 */
static void i2c_us_delay(rt_uint32_t us)
{
    rt_uint32_t ticks;
    rt_uint32_t told, tnow, tcnt = 0;
    rt_uint32_t reload = SysTick->LOAD;

    ticks = us * reload / (1000000 / 750);
    told = SysTick->VAL;
    while (1)
    {
        tnow = SysTick->VAL;
        if (tnow != told)
        {
            if (tnow < told)
            {
                tcnt += told - tnow;
            }
            else
            {
                tcnt += reload - tnow + told;
            }
            told = tnow;
            if (tcnt >= ticks)
            {
                break;
            }
        }
    }
}

/*
 *@brief i2c Start
 */
static void i2c_start(soft_i2c_bus_t *i2c_bus)
{
	soft_set_sda(i2c_bus, HAL_GPIO_HIGH);
    i2c_us_delay(i2c_bus->delay_us);
    soft_set_scl(i2c_bus, HAL_GPIO_HIGH);
    i2c_us_delay(i2c_bus->delay_us);
    soft_set_sda(i2c_bus, HAL_GPIO_LOW);
    i2c_us_delay(i2c_bus->delay_us);
    soft_set_scl(i2c_bus, HAL_GPIO_LOW);
    i2c_us_delay(i2c_bus->delay_us);
}

/*
 *@brief i2c bus unlock
 */
static int32_t i2c_bus_unlock(soft_i2c_bus_t *i2c_bus)
{
    int32_t i = 0;

    if (HAL_GPIO_LOW == soft_get_sda(i2c_bus))
    {
        while (i++ < 9)
        {
            soft_set_scl(i2c_bus, HAL_GPIO_HIGH);
            i2c_us_delay(100);
            soft_set_scl(i2c_bus, HAL_GPIO_LOW);
            i2c_us_delay(100);
        }
    }
    
    if (HAL_GPIO_LOW == soft_get_sda(i2c_bus))
    {
        return -1;
    }

    return 0;
}

/*
 *@brief i2c Stop
 */
static void i2c_stop(soft_i2c_bus_t *i2c_bus)
{
    soft_set_scl(i2c_bus, HAL_GPIO_LOW);
    i2c_us_delay(i2c_bus->delay_us);
    soft_set_sda(i2c_bus, HAL_GPIO_LOW);
    i2c_us_delay(i2c_bus->delay_us);
    soft_set_scl(i2c_bus, HAL_GPIO_HIGH);
    i2c_us_delay(i2c_bus->delay_us);
    soft_set_sda(i2c_bus, HAL_GPIO_HIGH);
    i2c_us_delay(i2c_bus->delay_us);
}

/*
 *@brief i2c Wait Acknowledge
 */
static uint8_t i2c_wait_ack(soft_i2c_bus_t *i2c_bus)
{
    soft_set_sda(i2c_bus, HAL_GPIO_HIGH);
    i2c_us_delay(i2c_bus->delay_us);
    soft_set_scl(i2c_bus, HAL_GPIO_HIGH);
    i2c_us_delay(i2c_bus->delay_us);
    if(soft_get_sda(i2c_bus))
    {
        i2c_stop(i2c_bus);
        return 0;
    }
    soft_set_scl(i2c_bus, HAL_GPIO_LOW);
    return 1; 
}


/*
 *@brief i2c Send Acknowledge
 */
static void i2c_send_ack(soft_i2c_bus_t *i2c_bus)
{
    soft_set_sda(i2c_bus, HAL_GPIO_LOW);
    i2c_us_delay(i2c_bus->delay_us);
    soft_set_scl(i2c_bus, HAL_GPIO_HIGH);
    i2c_us_delay(i2c_bus->delay_us);
    soft_set_scl(i2c_bus, HAL_GPIO_LOW);    
}



/*
 *@brief i2c Send No Acknowledge
 */
static void i2c_send_noack(soft_i2c_bus_t *i2c_bus)
{
    soft_set_sda(i2c_bus, HAL_GPIO_HIGH);
    i2c_us_delay(i2c_bus->delay_us);
    soft_set_scl(i2c_bus, HAL_GPIO_HIGH);
    i2c_us_delay(i2c_bus->delay_us);
    soft_set_scl(i2c_bus, HAL_GPIO_LOW);    
}


/*
 *@brief i2c Send Data
 */
static void i2c_send_data(soft_i2c_bus_t *i2c_bus, uint8_t data)
{
    uint8_t i = 8;
    
    while(i--)
    {
        soft_set_scl(i2c_bus, HAL_GPIO_LOW);
        i2c_us_delay(i2c_bus->delay_us);
        if(data & 0x80)
        {
            soft_set_sda(i2c_bus, HAL_GPIO_HIGH);
        }         
        else
        {
            soft_set_sda(i2c_bus, HAL_GPIO_LOW);
        }
        
        i2c_us_delay(i2c_bus->delay_us);
        data <<= 1;
        soft_set_scl(i2c_bus, HAL_GPIO_HIGH);
        i2c_us_delay(i2c_bus->delay_us);
        soft_set_scl(i2c_bus, HAL_GPIO_LOW);
        // i2c_us_delay(i2c_bus->delay_us);
    }    
}

/*
 *@brief i2c Receive Data
 *@author Mr.W
 *@date 2020-8-3
 */
static uint8_t i2c_receive_data(soft_i2c_bus_t *i2c_bus)
{
    uint8_t i = 8;
    uint8_t data = 0;
    
    soft_set_sda(i2c_bus, HAL_GPIO_HIGH);
    while(i--)
    {
        data <<= 1;
        soft_set_scl(i2c_bus, HAL_GPIO_LOW);
        i2c_us_delay(i2c_bus->delay_us);
        soft_set_scl(i2c_bus, HAL_GPIO_HIGH);
        i2c_us_delay(i2c_bus->delay_us);
        if(soft_get_sda(i2c_bus)) 
            data |= 0x01;
    }
    soft_set_scl(i2c_bus, HAL_GPIO_LOW);
    
    return(data);    
}

/*
 *@brief i2c Init
 */
static void i2c_init(soft_i2c_bus_t *i2c_bus)
{
	i2c_bus_unlock(i2c_bus);
    i2c_stop(i2c_bus);
}





/**
* @brief		I2C加载驱动
* @return		执行结果
* @retval		SF_OK 成功
* @retval		SF_ERR_NO_OBJECT 失败 
*/
int32_t hal_i2c_init(void)
{
	uint8_t i;
	
    g_i2c_status = 0;
	for (i = 0; i < ITEM_NUM(g_soft_i2c_bus); i++)
	{
		// gpio init
		soft_i2c_gpio_init(&g_soft_i2c_bus[i]);
		// mutex init
		g_soft_i2c_bus[i].mutex_id = os_mutex_new(&(g_soft_i2c_bus[i].i2c_mutex_attr));
		if (g_soft_i2c_bus[i].mutex_id == NULL)
		{
			rt_kprintf("i2c%d mutex create fail\n",i);
		}
		i2c_init(&g_soft_i2c_bus[i]);
	}

	return SF_OK;
}

INIT_BOARD_EXPORT(hal_i2c_init);

/**
* @brief		I2C删除驱动
* @return		执行结果
* @retval		SF_OK 成功
* @retval		SF_ERR_NO_OBJECT 失败 
*/
int32_t hal_i2c_deinit(void)
{
    uint8_t i;
	
	for (i = 0; i < ITEM_NUM(g_soft_i2c_bus); i++)
	{
		if (g_soft_i2c_bus[i].mutex_id)
		{
            os_mutex_delete(g_soft_i2c_bus[i].mutex_id);
            g_soft_i2c_bus[i].mutex_id = NULL;
		}
	}
    
	return SF_OK;
}

/**
* @brief		打开I2C功能  
* @param		[in] i2c_no 虚拟I2C端口号 
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		SF_ERR_NO_OBJECT 失败   
* @warning 		本接口只初始化I2C总线接口 
*/
int32_t hal_i2c_open(uint32_t i2c_no)
{
    if (i2c_no >= ITEM_NUM(g_soft_i2c_bus)) 
	{
		return SF_ERR_NO_OBJECT;
	}
    
	if (SF_GET_BIT(g_i2c_status, (1U << i2c_no)) == 0)
    {
        SET_BIT(g_i2c_status, (1U << i2c_no));
    }
    
   	return SF_OK;
}

/**
* @brief		关闭I2C功能  
* @param		[in] i2c_no 虚拟I2C端口号 
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		SF_ERR_NO_OBJECT 失败   
* @warning 		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_i2c_close(uint32_t i2c_no)
{
    
	if (i2c_no >= ITEM_NUM(g_soft_i2c_bus)) 
	{
		return SF_ERR_NO_OBJECT;
	}
	
	if (SF_GET_BIT(g_i2c_status, (1u << i2c_no)) != 0)
    {
        SF_CLR_BIT(g_i2c_status, (1u << i2c_no));
    }
    
	return SF_OK;
}


/**
* @brief		I2C功能从休眠中唤醒，恢复状态
* @param		[in] i2c_no 虚拟I2C端口号   
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		SF_ERR_NO_OBJECT 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_i2c_resume(uint32_t i2c_no)
{
    log_d("not support!");
	return SF_ERR_OPEN;
}
 
/**
* @brief		I2C功能进入休眠模式
* @param		[in] i2c_no 虚拟I2C端口号   
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		SF_ERR_NO_OBJECT 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式，功能不影响
*/
int32_t hal_i2c_suspend(uint32_t i2c_no)
{
    log_d("not support!");
	return SF_ERR_OPEN;
}


/**
* @brief		I2C功能进入休眠模式
* @param		[in] i2c_no 虚拟I2C端口号    
* @param		[in] config I2C配置参数  
* - config->work_mode I2C 主从模式
* -# HAL_I2C_MASTER = 主模式
* -# HAL_i2c_SLAVE = 从模式
* - config->speed i2c熟读
* - config->dev_addr I2C目标地址
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		<0 失败原因    
* @pre			执行hal_i2c_open后执行才有效 
*/
int32_t hal_i2c_setup(uint32_t i2c_no, hal_i2c_config_t *config)
{
    if (i2c_no >= ITEM_NUM(g_soft_i2c_bus)) 
	{
		return SF_ERR_NO_OBJECT;
	}
	
	if (SF_GET_BIT(g_i2c_status, (1u << i2c_no)) == 0)
    {
        return SF_ERR_OPEN;
    }
    
    log_d("not support!");
	return SF_ERR_OPEN;
}


/**
* @brief		I2C发数据 
* @param		[in] i2c_no 虚拟I2C端口号   
* @param		[in] dev_addr 设备地址  
* @param		[in] buf 缓冲区指针  
* @param		[in] len 缓冲区长度  
* @return		执行结果
* @retval		>0 发送数据长度(阻塞式)  
* @retval		=0 数据待发送(非阻塞式)，使用hal_i2c_query查询发送完成情况     
* @retval		<0 失败原因   
* @pre			执行hal_i2c_open后执行才有效 
*/
int32_t hal_i2c_write(uint32_t i2c_no, uint16_t dev_addr, uint8_t *buf, uint32_t len)
{
	uint8_t i;
	int32_t send_Len;
    rt_base_t level;
	soft_i2c_bus_t *i2c_bus;
	
	if (i2c_no >= ITEM_NUM(g_soft_i2c_bus)) 
	{
		return SF_ERR_NO_OBJECT;
	}
	
	if (SF_GET_BIT(g_i2c_status, (1u << i2c_no)) == 0)
    {
        return SF_ERR_OPEN;
    }
    i2c_bus = &g_soft_i2c_bus[i2c_no];
    
    send_Len = 0;
    os_mutex_acquire(i2c_bus->mutex_id, OS_WAIT_FOREVER);
    level = rt_hw_interrupt_disable();
    i2c_start(i2c_bus);
    i2c_send_data(i2c_bus, dev_addr|HAL_I2C_WRITE_FLAG);
    if(i2c_wait_ack(i2c_bus) == 0)
    {
        i2c_stop(i2c_bus);
        goto __exit;
    }
    
    for (i = 0; i < len; i++, send_Len++)
   	{
   		i2c_send_data(i2c_bus, buf[i]);
	    if(i2c_wait_ack(i2c_bus) == 0)
	    {
	        i2c_stop(i2c_bus);
	        break;
	    }
   	}
   	
   	i2c_stop(i2c_bus);
    rt_hw_interrupt_enable(level);
   	os_mutex_release(i2c_bus->mutex_id);
   	
__exit:
    rt_hw_interrupt_enable(level);
	os_mutex_release(i2c_bus->mutex_id);	
	return send_Len;
}

/**
* @brief		I2C读数据 
* @param		[in] i2c_no 虚拟I2C端口号   
* @param		[in] dev_addr 设备地址  
* @param		[in] buf 缓冲区指针  
* @param		[in] len 缓冲区长度  
* @return		执行结果
* @retval		>0 接收数据长度  
* @retval		=0 数据待接收(非阻塞式)，使用hal_i2c_query查询接收完成情况      
* @retval		<0 失败原因   
* @pre			执行hal_i2c_open后执行才有效 
*/
int32_t hal_i2c_read(uint32_t i2c_no, uint16_t dev_addr, uint8_t *buf, uint32_t len)
{
	uint8_t i;
	int32_t read_Len;
	soft_i2c_bus_t *i2c_bus;
    rt_base_t level;
	
	if (i2c_no >= ITEM_NUM(g_soft_i2c_bus)) 
	{
		return SF_ERR_NO_OBJECT;
	}
	
	if (SF_GET_BIT(g_i2c_status, (1u << i2c_no)) == 0)
    {
        return SF_ERR_OPEN;
    }
    i2c_bus = &g_soft_i2c_bus[i2c_no];
    read_Len = 0;
    os_mutex_acquire(i2c_bus->mutex_id, OS_WAIT_FOREVER);
    level = rt_hw_interrupt_disable();
    i2c_start(i2c_bus);
    i2c_send_data(i2c_bus, dev_addr|HAL_I2C_READ_FLAG);
    if(i2c_wait_ack(i2c_bus) == 0)
    {
        i2c_stop(i2c_bus);
        goto __exit;
    }
    
    for(i = 0; i < len; i++, read_Len++)
    {
        *buf++ = i2c_receive_data(i2c_bus);
        if(i < (len - 1))
            i2c_send_ack(i2c_bus);
    }
    i2c_send_noack(i2c_bus);
    i2c_stop(i2c_bus);
    rt_hw_interrupt_enable(level);
   	os_mutex_release(i2c_bus->mutex_id);
   	
__exit:
    rt_hw_interrupt_enable(level);
   	os_mutex_release(i2c_bus->mutex_id);
	return read_Len;
}

/**
* @brief		清空I2C传输缓冲区  
* @param		[in] i2c_no 虚拟I2C端口号   
* @return		执行结果
* @retval		SF_OK 成功       
* @retval		<0 失败原因   
* @pre			执行hal_i2c_open后执行才有效 
*/
int32_t hal_i2c_flush(uint32_t i2c_no)
{
	log_d("not support!");
	return SF_ERR_FNOSUPP;
}

/**
* @brief		查询I2C传输是否完成   
* @param		[in] i2c_no 虚拟I2C端口号   
* @return		执行结果
* @retval		SF_OK 传输完毕
* @retval		>0 剩余未传输完毕的数据长度         
* @retval		<0 失败原因   
* @pre			执行hal_i2c_open后执行才有效 
*/
int32_t hal_i2c_query(uint32_t i2c_no)
{
	log_d("not support!");
	return SF_ERR_FNOSUPP;
}


/**
* @brief		扩展功能 
* @param		[in] dev_no 设备端口号  
* @param		[in] cmd 控制命令  
* @param		[in] arg 控制参数   
* @return		执行结果
* @retval		SF_OK 成功    
* @retval		<0 失败原因  
*/
int32_t hal_i2c_ioctl(int32_t dev_no, uint8_t cmd, void* arg)
{
	log_d("not support!");
	return SF_ERR_FNOSUPP;
}


#if 0	// EERPOM I2C的测试代码
int eeprom_read_byte(uint16_t addr, uint8_t *pdata, uint16_t size)
{
    uint8_t ret = 0;
    uint32_t i2c_no = 0;
    uint16_t dev_addr = 0xA0;
    uint8_t buf[2];
    
    hal_i2c_open(i2c_no);
    buf[0] = (uint8_t)(addr>>8);	
    buf[1] = (uint8_t)addr;
    hal_i2c_write(i2c_no, dev_addr, buf, 2);
    memset(pdata, 0 , size);
    hal_i2c_read(i2c_no, dev_addr, pdata, size);
    
    return ret;
}


int eeprom_write_one_byte(uint16_t addr, uint8_t data)
{
    int ret = 0;
    uint32_t i2c_no = 0;
    uint16_t dev_addr = 0xA0;
    uint8_t buf[3];
    
    hal_i2c_open(i2c_no);
    buf[0] = (uint8_t)(addr>>8);	
    buf[1] = (uint8_t)addr;
    buf[2] = data;
    hal_i2c_write(i2c_no, dev_addr, buf, 3);
    
    
    return ret;
}


int eeprom_write_n_byte(uint16_t addr, uint8_t *pdata, uint16_t size)
{
    uint8_t ret = 0;
    uint16_t dev_addr = 0xA0;
    uint16_t i;

    for(i = 0; i < size; i++)
    {
        ret = eeprom_write_one_byte(addr++, *pdata++);
        if(ret < 0)
        {
            return -1;
        }
        /* 此处延时应大于4ms，等待芯片内部写完成 */
        os_delay(4);
    }
    return 0;
}



void test_i2c_eeprom(int argc, char *argv[])
{
    int addr = 0;
    uint8_t buff[16];
    
//    GPIO_InitTypeDef GPIO_InitStruct;
//	GPIO_InitStruct.Pin = GPIO_PIN_7;
//    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
//    GPIO_InitStruct.Pull = GPIO_NOPULL;
//    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
//    HAL_GPIO_Init((GPIO_TypeDef*)GPIOD, &GPIO_InitStruct);
//    HAL_GPIO_WritePin((GPIO_TypeDef*)GPIOD, GPIO_PIN_7, GPIO_PIN_RESET);
    
    if (argc > 1)
    {
		if (strcmp(argv[1], "set") == 0)
        {
            addr = atol(argv[2]);
            buff[0] = atol(argv[3]);
            for (int i = 1; i < sizeof(buff); i++)
            {
            	buff[i] = buff[0] + i;
            }
            eeprom_write_n_byte(addr, buff, sizeof(buff));
        }
        else if (strcmp(argv[1], "get") == 0)
        {
            addr = atol(argv[2]);

            eeprom_read_byte(addr, buff , sizeof(buff));
            log_hexdump("eeprom data", 16, buff, sizeof(buff));
        }
    } 
}

MSH_CMD_EXPORT(test_i2c_eeprom, test i2c eeprom);

#endif




#endif



