#include <board.h>
#include <string.h>
#include <rthw.h>
#include <rtthread.h>
#include <rtdevice.h>
#include <ipc/ringbuffer.h>
#include <osif.h>
#include "hal_can.h"
#include "hal_public.h"
#include "hal_gpio.h"
#include "pin_config.h"
#include "log.h"
#include "sofar_errors.h"
#include "rtconfig.h"

#define CAN_TX_RING_BUFF_LEN 	(sizeof(hal_can_msg_t) * CAN_TX_RING_BUFF_SZ)


/**
* @struct can_status_t
* @brief  can状态
*/
typedef struct{
	uint32_t is_init;	// 0-未初始化 1-已初始化
	uint32_t is_open;	// 0-未打开 1-已打开
	uint32_t is_suspend;// 0-未挂起 1-已挂起
}can_status_t;

/**
* @struct can_int_cb_t
* @brief  can中断回调
*/
typedef struct{
	irq_can_callback tx_cb;
	irq_can_callback rx_cb;
}can_int_cb_t;

enum
{
#if defined(BSP_USING_FDCAN1)
    HAL_CAN1 = 0, 
#endif
#if defined(BSP_USING_FDCAN2)	
    HAL_CAN2,     
#endif
#if defined(BSP_USING_FDCAN3)
	HAL_CAN3,     
#endif
	HAL_CAN_MAX,
};

// CAN索引号对应的设备名称
static const char  *gp_can_dev[HAL_CAN_MAX] =
{
#if defined(BSP_USING_FDCAN1)
	"can1", 
#endif
#if defined(BSP_USING_FDCAN2)
	"can2",
#endif
#if defined(BSP_USING_FDCAN3)
	"can3",
#endif
};

static can_status_t g_can_status = {0};		   		// 标识CAN状态
static rt_device_t  g_can[HAL_CAN_MAX];	   			// 从RTOS打开的设备类句柄
static can_int_cb_t g_can_cb[HAL_CAN_MAX]; 			// 收发回调函数，0=TX, 1=RX
static uint8_t 		g_tx_ringbuff[HAL_CAN_MAX][CAN_TX_RING_BUFF_LEN];

static struct       rt_ringbuffer g_tx_rb[HAL_CAN_MAX];  // tx ringbuf结构指针
static struct       rt_semaphore  g_tx_sem[HAL_CAN_MAX]; // tx 信号量
static os_mutex_id_t g_can_mutex_id[HAL_CAN_MAX];

#if defined(BSP_USING_FDCAN1)
  uint32_t 		   thread_can1_stack[512/4];		// can1发送任务堆栈512byte
  os_thread_id_t   can1_thread_id;					// can1任务

  os_thread_attr_t can1_thread_attr = 
  {
  	"can1",
  	0,
  	NULL,
  	0,
  	20,
  	(void *)thread_can1_stack,
  	sizeof(thread_can1_stack),
  	OS_PRIORITY_HIGH_5,
  	0,
  };
  const os_mutex_attr_t can1_mutex_attr = 
  {
    "can1_mutex", 
    0, 
    0, 
    0
  };
#endif

#if defined(BSP_USING_FDCAN2)
  uint32_t 		   thread_can2_stack[512/4];		// can2发送任务堆栈512byte
  os_thread_id_t   can2_thread_id;					// can2任务
  
  os_thread_attr_t can2_thread_attr = 
  {
  	"can2",
  	0,
  	NULL,
  	0,
  	20,
  	(void *)thread_can2_stack,
  	sizeof(thread_can2_stack),
  	OS_PRIORITY_HIGH_4,
  	0,
  };
  const os_mutex_attr_t can2_mutex_attr = 
  {
    "can2_mutex", 
    0, 
    0, 
    0
  };
#endif
  
#if defined(BSP_USING_FDCAN3)
  uint32_t 		   thread_can3_stack[512/4];		// can2发送任务堆栈512byte
  os_thread_id_t   can3_thread_id;					// can2任务
  
  os_thread_attr_t can3_thread_attr = {
	"can3",
	0,
	NULL,
	0,
	20,
	(void *)thread_can3_stack,
	sizeof(thread_can3_stack),
	OS_PRIORITY_HIGH_3,
	0,
  };
  const os_mutex_attr_t can3_mutex_attr = 
  {
    "can3_mutex", 
    0, 
    0, 
    0
  };
#endif


static void thread_can1_tx(void* argv);
static void thread_can2_tx(void* argv);
static void thread_can3_tx(void* argv);
/**
* @brief		CAN加载驱动
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @warning 		开机只运行一次
*/
int32_t hal_can_init(void)
{
	if (!g_can_status.is_init)
    {
		memset(g_can,		  0, sizeof(rt_device_t)*HAL_CAN_MAX);
		memset(g_can_cb,	  0, sizeof(can_int_cb_t)*HAL_CAN_MAX);
		memset(g_tx_rb, 	  0, sizeof(struct rt_ringbuffer)*HAL_CAN_MAX);
		memset(g_tx_ringbuff, 0, CAN_TX_RING_BUFF_LEN * HAL_CAN_MAX);
	
	#if defined(BSP_USING_FDCAN1)
		// init can1 tx semaphore
		rt_sem_init(&g_tx_sem[HAL_CAN1], "can1_tx_sem", 0, RT_IPC_FLAG_FIFO);
		// init can1 ringbuffer
		rt_ringbuffer_init(&g_tx_rb[HAL_CAN1], g_tx_ringbuff[HAL_CAN1], CAN_TX_RING_BUFF_LEN);
		g_can_mutex_id[HAL_CAN1] = os_mutex_new(&can1_mutex_attr);
		// creat can1 tx thread
		can1_thread_id = os_thread_new(thread_can1_tx, NULL, &can1_thread_attr);
	#endif
	
	#if defined(BSP_USING_FDCAN2)
		// init can2 tx semaphore
		rt_sem_init(&g_tx_sem[HAL_CAN2], "can2_tx_sem", 0, RT_IPC_FLAG_FIFO);
		// init can2 ringbuffer
		rt_ringbuffer_init(&g_tx_rb[HAL_CAN2], g_tx_ringbuff[HAL_CAN2], CAN_TX_RING_BUFF_LEN);
		g_can_mutex_id[HAL_CAN2] = os_mutex_new(&can2_mutex_attr);
		// creat can2 tx thread
		can2_thread_id = os_thread_new(thread_can2_tx, NULL, &can2_thread_attr);
	#endif
	
	#if defined(BSP_USING_FDCAN3)
		// init can3 tx semaphore
		rt_sem_init(&g_tx_sem[HAL_CAN3], "can3_tx_sem", 0, RT_IPC_FLAG_FIFO);
		// init can3 ringbuffer
		rt_ringbuffer_init(&g_tx_rb[HAL_CAN3], g_tx_ringbuff[HAL_CAN3], CAN_TX_RING_BUFF_LEN);
		g_can_mutex_id[HAL_CAN3] = os_mutex_new(&can3_mutex_attr);
		// creat can3 tx thread
		can3_thread_id = os_thread_new(thread_can3_tx, NULL, &can3_thread_attr);
	#endif
	
		g_can_status.is_init = 1;
    }   
	
	return SF_OK;
}
INIT_DEVICE_EXPORT(hal_can_init);


/**
* @brief		CAN删除驱动(预留)
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败
*/
int32_t hal_can_deinit(void)
{
	return SF_OK;
}


/**
* @brief		打开CAN功能 
* @param		[in] port 虚拟CAN端口号
* -# HAL_CAN1 - 0x00	
* -# HAL_CAN2 - 0x01
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @pre			执行hal_can_init后执行才有效。
*/
int32_t hal_can_open(uint32_t port)
{
	int32_t ret;

    // param check
	if (port >= HAL_CAN_MAX)
	{
		ret = SF_ERR_PARA;
		goto failed;
	}  	
    // if adc is opened, return ok
    if (SF_GET_BIT(g_can_status.is_open, (1U << port)))
    {
        return SF_OK;
    }    	
	// if adc is not init, return failed 
	if (!g_can_status.is_init)
	{
		ret = SF_ERR_NO_READY;
		goto failed;
	} 
	
	g_can[port] = rt_device_find(gp_can_dev[port]);
    if (!g_can[port])
    {
        ret = SF_ERR_OPEN;
		goto failed;
    }

	ret = rt_device_open(g_can[port], RT_DEVICE_FLAG_INT_TX | RT_DEVICE_FLAG_INT_RX);
	if (SF_OK != ret)
	{
		goto failed;	
	}	
	
	SF_SET_BIT(g_can_status.is_open, (1U << port));
	return ret;

failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;
}

/**
* @brief		关闭CAN功能 
* @param		[in] port 虚拟CAN端口号
* -# HAL_CAN1 - 0x00	
* -# HAL_CAN2 - 0x01
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			执行hal_can_init后执行才有效。
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_can_close(uint32_t port)
{	
	int32_t ret;

    // param check
	if (!SF_GET_BIT(g_can_status.is_open, (1U << port)))
    {
        return SF_OK;
    }    	
	// if adc is closed, return ok
	if (!g_can_status.is_init)
	{
		ret = SF_ERR_NO_READY;
		goto failed;
	} 
    // if adc is not init, return failed
	if (port >= HAL_CAN_MAX)
	{
		ret = SF_ERR_PARA;
		goto failed;
	} 

    g_can[port] = rt_device_find(gp_can_dev[port]);
    if (!g_can[port])
    {
        ret = SF_ERR_OPEN;
		goto failed;
    }
    
    ret = rt_device_close(g_can[port]);
	if (SF_OK != ret)
	{
		goto failed;	
	}	
	
	g_can[port] = 0;	
	SF_CLR_BIT(g_can_status.is_open, (1U << port));
	return ret;
	
failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;

}


/**
* @brief		CAN功能从休眠中唤醒，恢复状态
* @param		[in] port 虚拟CAN端口号
* -# HAL_CAN1 - 0x00	
* -# HAL_CAN2 - 0x01
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
*/
int32_t hal_can_resume(uint32_t port)
{
	int32_t ret;

    // param check
	if (port >= HAL_CAN_MAX)
	{
		ret = SF_ERR_PARA;
		goto failed;
	} 
    // if the device is not supended, return ok
	if (!SF_GET_BIT(g_can_status.is_suspend, (1U << port)))
    {
        return SF_OK;
    }    	
	// if the device is not init, return failed
	if (!g_can_status.is_init)
	{
		ret = SF_ERR_NO_READY;
		goto failed;
	} 

    g_can[port] = rt_device_find(gp_can_dev[port]);
    if (!g_can[port])
    {
        ret = SF_ERR_OPEN;
		goto failed;
    } 
#if defined(BSP_USING_FDCAN1)
	if(port == HAL_CAN1)
	{
		;
	}
#endif
#if defined(BSP_USING_FDCAN2)
	if(port == HAL_CAN2)
	{
		;
	}
#endif
#if defined(BSP_USING_FDCAN3)
	if(port == HAL_CAN3)
	{
		;
	}
#endif

	
	ret  = SF_OK;
	SF_CLR_BIT(g_can_status.is_suspend, (1U << port));
	return ret;
	
failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;

}
 
/**
* @brief		CAN功能进入休眠模式
* @param		[in] port 虚拟CAN端口号
* -# HAL_CAN1 - 0x00	
* -# HAL_CAN2 - 0x01
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式，功能不影响
*/
int32_t hal_can_suspend(uint32_t port)
{
	int32_t ret;
    FDCAN_HandleTypeDef fdcan = {0};
    hal_gpio_config_t gpio_config = {.direction = HAL_GPIO_OUTPUT, .pull = HAL_GPIO_NOPULL};
    
    // param check
	if (port >= HAL_CAN_MAX)
	{
		ret = SF_ERR_PARA;
		goto failed;
	} 
    // if the device is supended, return ok
	if (SF_GET_BIT(g_can_status.is_suspend, (1U << port)))
    {
        return SF_OK;
    }    	
	// if the device is not init, return failed
	if (!g_can_status.is_init)
	{
		ret = SF_ERR_NO_READY;
		goto failed;
	} 

    g_can[port] = rt_device_find(gp_can_dev[port]);
    if (!g_can[port])
    {
        ret = SF_ERR_OPEN;
		goto failed;
    } 

	/* 将对应的can通道时钟、IO口时钟关闭并恢复初始状态 */
#if defined(BSP_USING_FDCAN1)
	if(port == HAL_CAN1)
	{
		fdcan.Instance	= FDCAN1;
		hal_can_close(port);
        HAL_FDCAN_MspDeInit(&fdcan);
        hal_gpio_config(FDCAN1_TX_PIN, &gpio_config);  
        hal_gpio_config(FDCAN1_RX_PIN, &gpio_config);  
        hal_gpio_write(FDCAN1_TX_PIN, 0); 
        hal_gpio_write(FDCAN1_RX_PIN, 0); 
	}
#endif
#if defined(BSP_USING_FDCAN2)
	if(port == HAL_CAN2)
	{
		fdcan.Instance	= FDCAN2;
		hal_can_close(port);
        HAL_FDCAN_MspDeInit(&fdcan);
        hal_gpio_config(FDCAN2_TX_PIN, &gpio_config);  
        hal_gpio_config(FDCAN2_RX_PIN, &gpio_config);  
        hal_gpio_write(FDCAN2_TX_PIN, 0); 
        hal_gpio_write(FDCAN2_RX_PIN, 0); 
	}
#endif	
#if defined(BSP_USING_FDCAN3)
	if(port == HAL_CAN3)
	{
		fdcan.Instance	= FDCAN3;
		hal_can_close(port);
        HAL_FDCAN_MspDeInit(&fdcan);
        hal_gpio_config(FDCAN3_TX_PIN, &gpio_config);
        hal_gpio_config(FDCAN3_RX_PIN, &gpio_config);
        hal_gpio_write(FDCAN3_TX_PIN, 0);   
        hal_gpio_write(FDCAN3_RX_PIN, 0);
	}
#endif
	
	ret  = SF_OK;
	SF_SET_BIT(g_can_status.is_suspend, (1U << port));
	return ret;
	
failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;

}


/**
* @brief		设置CAN属性 
* @param		[in] port 虚拟CAN端口号
* -# HAL_CAN1 - 0x00	
* -# HAL_CAN2 - 0x01
* @param		[in] conf 串口参数指针  
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			执行hal_can_open后执行才有效。
*/
int32_t hal_can_setup(uint32_t port, hal_can_conf_t *p_conf)
{
	int32_t ret; 	

	// check process status
	if ((!g_can_status.is_init) || (!SF_GET_BIT(g_can_status.is_open, (1U << port))))
	{
		ret = SF_ERR_NO_READY;
		goto failed;
	} 

	// check in param
	if (((port >= HAL_CAN_MAX)  || (!p_conf))
		||((!HAL_IS_CAN_BAUD(p_conf->baud)) || (!HAL_IS_CAN_MODE(p_conf->mode))))
	{
		ret = SF_ERR_PARA;
		goto failed;
	}
		
    g_can[port] = rt_device_find(gp_can_dev[port]);
    if (!g_can[port])
    {
        ret = SF_ERR_OPEN;
		goto failed;
    } 

	ret = rt_device_control(g_can[port], RT_CAN_CMD_SET_BAUD, (void *)p_conf->baud);
	if (SF_OK != ret)
	{
		goto failed;	
	}

	ret = rt_device_control(g_can[port], RT_CAN_CMD_SET_MODE, (void *)p_conf->mode);
	if (SF_OK != ret)
	{
		goto failed;	
	}

	return ret;	
	
failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;

}


/**
* @brief		设置CAN硬件过滤表
* @param		[in] port 虚拟CAN端口号
* -# HAL_CAN1 - 0x00	
* -# HAL_CAN2 - 0x01
* @param		[in] p_conf 串口参数指针 
* -# p_conf->baud - 波特率	
* -# p_conf->mode - 模式
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			执行hal_can_open后执行才有效。
*/
int32_t hal_can_set_filter(uint32_t port, hal_can_filter_t *p_filter)
{
	int32_t ret; 	
	
	if ((!g_can_status.is_init) || (!SF_GET_BIT(g_can_status.is_open, (1U << port))))
	{
		ret = SF_ERR_NO_READY;
		goto failed;
	} 
	
	if ((port >= HAL_CAN_MAX)  || (!p_filter))
	{
		ret = SF_ERR_PARA;
		goto failed;
	}

	g_can[port] = rt_device_find(gp_can_dev[port]);
    if (!g_can[port])
    {
        ret = SF_ERR_OPEN;
		goto failed;
    } 
	
	/* set filter */
	ret = rt_device_control(g_can[port], RT_CAN_CMD_SET_FILTER, p_filter);
	if (SF_OK != ret)
	{
		goto failed;	
	}
	return ret;	
	
failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;
}


static rt_err_t can_rx(rt_device_t dev, rt_size_t size)
{
	int i;
	for (i = 0; i < HAL_CAN_MAX; i++)
	{
		if (g_can[i] == dev)
		{
			if (g_can_cb[i].rx_cb)
				g_can_cb[i].rx_cb(i, size);
		}
	}
	
    return RT_EOK;
}

static rt_err_t can_tx(rt_device_t dev, void *buffer)
{
	int i;
	for (i = 0; i < HAL_CAN_MAX; i++)
	{
		if (g_can[i] == dev)
		{
			if (g_can_cb[i].tx_cb)
				g_can_cb[i].tx_cb(i, 0);
		}
	}
	
    return RT_EOK;
}

/**
* @brief		配置CAN中断函数  
* @param		[in] port 虚拟CAN端口号
* -# HAL_CAN1 - 0x00	
* -# HAL_CAN2 - 0x01
* @param		[in] p_tx_fcallback 发送中断回调函数  
* @param		[in] p_rx_fcallback 接收中断回调函数     
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @pre			执行hal_can_open后执行才有效。
* @warning 		发送和接收中断回调至少填写一个，不设置可填写NULL
*/
int32_t hal_can_set_irq(uint32_t port, irq_can_callback p_tx_fcallback, irq_can_callback p_rx_fcallback)
{
	int32_t ret; 	
	
	if ((!g_can_status.is_init) || (!SF_GET_BIT(g_can_status.is_open, (1U << port))))
	{
		ret = SF_ERR_NO_READY;
		goto failed;
	} 
	
	if ((port >= HAL_CAN_MAX)  || ((!p_tx_fcallback) && (!p_rx_fcallback)))
	{
		ret = SF_ERR_PARA;
		goto failed;
	}

	g_can[port] = rt_device_find(gp_can_dev[port]);
    if (!g_can[port])
    {
        ret = SF_ERR_OPEN;
		goto failed;
    } 
	
	/* set irq callback */
	if (p_rx_fcallback)
	{
		g_can_cb[port].rx_cb = p_rx_fcallback;
		rt_device_set_rx_indicate(g_can[port], can_rx);
	}
    
	if (p_tx_fcallback)
	{
		g_can_cb[port].tx_cb = p_tx_fcallback;
		rt_device_set_tx_complete(g_can[port], can_tx);
	}
	
	return SF_OK;

failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;

}


/**
* @brief		关闭CAN中断
* @param		[in] port 虚拟CAN端口号
* -# HAL_CAN1 - 0x00	
* -# HAL_CAN2 - 0x01
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			执行hal_can_open后执行才有效。
*/
int32_t hal_can_free_irq(uint32_t port)
{
	int32_t ret; 	
	
	if ((!g_can_status.is_init) || (!SF_GET_BIT(g_can_status.is_open, (1U << port))))
	{
		ret = SF_ERR_NO_READY;
		goto failed;
	} 
	
	if (port >= HAL_CAN_MAX)
	{
		ret = SF_ERR_PARA;
		goto failed;
	}

	g_can[port] = rt_device_find(gp_can_dev[port]);
    if (!g_can[port])
    {
        ret = SF_ERR_OPEN;
		goto failed;
	}
	
	rt_device_set_rx_indicate(g_can[port], NULL);
	rt_device_set_tx_complete(g_can[port], NULL);
	
	return SF_OK;

failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;

}


/**
* @brief		CAN收数据 
* @param		[in] port 虚拟CAN端口号
* -# HAL_CAN1 - 0x00	
* -# HAL_CAN2 - 0x01
* @param		[in] p_buf 缓冲区指针  
* @param		[in] len 缓冲区长度   
* @return		执行结果
* @retval		>=0 接收数据长度
* @retval		<0 失败原因 
* @pre			执行hal_can_open后执行才有效。
*/
int32_t hal_can_read(uint32_t port, hal_can_msg_t *p_buf, int32_t len, uint32_t timeout_ms)
{
	int32_t ret; 	
	int32_t rcv_len;

	if ((!g_can_status.is_init) || (!SF_GET_BIT(g_can_status.is_open, (1U << port))))
	{
		ret = SF_ERR_NO_READY;
		goto failed;
	} 
	
	if ((port >= HAL_CAN_MAX) || (len <= 0) || (!p_buf))
	{
		ret = SF_ERR_PARA;
		goto failed;
	}

	do
	{
		rcv_len = rt_device_read(g_can[port], 0, (void *)p_buf, len);
		if((0 < rcv_len) || (0 == timeout_ms))
		{
			break;
		}
		else
		{
			//log_e("read failed: %d\n", timeout_ms);
			os_delay(os_tick_from_millisecond(1));
		}
	}while (timeout_ms-- > 1);
		
	return rcv_len;

failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;

}

/**
* @brief		CAN发数据 
* @param		[in] port 虚拟CAN端口号
* -# HAL_CAN1 - 0x00	
* -# HAL_CAN2 - 0x01
* @param		[in] p_buf 缓冲区指针  
* @param		[in] len 缓冲区长度   
* @return		执行结果
* @retval		>=0 发送数据长度
* @retval		<0 失败原因    
* @pre			执行hal_can_open后执行才有效。
*/
int32_t hal_can_write(uint32_t port, hal_can_msg_t *p_buf, int32_t len)
{
	int32_t   ret; 
	int32_t   write_len;

	if ((!g_can_status.is_init) || (!SF_GET_BIT(g_can_status.is_open, (1U << port))))
	{
		ret = SF_ERR_NO_READY;
		goto failed;
	} 
	if ((port >= HAL_CAN_MAX) || (!p_buf) || (len <= 0) || (len != sizeof(hal_can_msg_t)))
	{
		ret = SF_ERR_PARA;
		goto failed;
	}
	os_mutex_acquire(g_can_mutex_id[port], OS_WAIT_FOREVER);
	write_len = rt_ringbuffer_put(&g_tx_rb[port], (uint8_t *)p_buf, len);
	os_mutex_release(g_can_mutex_id[port]);
    
	if (len == write_len)
	{
		os_sem_release(&g_tx_sem[port]);
	}

	return write_len;

failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;

}


/**
* @brief		扩展功能(预留)
* @param		[in] port 虚拟CAN端口号
* -# HAL_CAN1 - 0x00	
* -# HAL_CAN2 - 0x01
* @param		[in] cmd 控制命令  
* @param		[in] p_arg 控制参数   
* @return		执行结果
* @retval		SF_OK 成功    
* @retval		<0 失败原因  
*/
int32_t hal_can_ioctl(uint32_t port, uint8_t cmd, void* p_arg)
{
	return SF_OK;
}

#if defined(BSP_USING_FDCAN1)
static void thread_can1_tx(void* argv)
{
	hal_can_msg_t data;
	rt_size_t len;
    int16_t  send_len = 0;
    
	while(1)
	{
	    rt_sem_take(&g_tx_sem[HAL_CAN1], RT_WAITING_FOREVER);
		len = rt_ringbuffer_get(&g_tx_rb[HAL_CAN1], (rt_uint8_t *)&data, sizeof(hal_can_msg_t));
		if(len == sizeof(hal_can_msg_t))
		{
            do
            {
                send_len = rt_device_write(g_can[HAL_CAN1], 0, (rt_uint8_t *)&data, len);
                if(0 < send_len)
                {
                    break;
                }
                else
                {
                    os_delay(TICK_1MS);
                }
            }while(1);
		}
		os_delay(TICK_1MS);
	}	
}
#endif

#if defined(BSP_USING_FDCAN2)
static void thread_can2_tx(void* argv)
{
	hal_can_msg_t data;
	rt_size_t len;
    int16_t  send_len = 0;
    
	while(1)
	{
	    rt_sem_take(&g_tx_sem[HAL_CAN2], RT_WAITING_FOREVER);
		len = rt_ringbuffer_get(&g_tx_rb[HAL_CAN2], (rt_uint8_t *)&data, sizeof(hal_can_msg_t));
		if(len == sizeof(hal_can_msg_t))
		{
            do
            {
                send_len = rt_device_write(g_can[HAL_CAN2], 0, (rt_uint8_t *)&data, len);
                if(0 < send_len)
                {
                    break;
                }
                else
                {
                    os_delay(TICK_1MS);
                    
                }
            }while(1);
		}
		os_delay(TICK_1MS);
	}	
}
#endif

#if defined(BSP_USING_FDCAN3)
static void thread_can3_tx(void* argv)
{
	hal_can_msg_t data;
	rt_size_t len;
    int16_t  send_len = 0;
    
	while(1)
	{
	    rt_sem_take(&g_tx_sem[HAL_CAN3], RT_WAITING_FOREVER);
		len = rt_ringbuffer_get(&g_tx_rb[HAL_CAN3], (rt_uint8_t *)&data, sizeof(hal_can_msg_t));
		if(len == sizeof(hal_can_msg_t))
		{
            do
            {
                send_len = rt_device_write(g_can[HAL_CAN3], 0, (rt_uint8_t *)&data, len);
                if(0 < send_len)
                {
                    break;
                }
                else
                {
                    os_delay(TICK_1MS);
                    
                }
            }while(1);
		}
		os_delay(TICK_1MS);
	}	
}
#endif


#ifdef RT_USING_FINSH
#if defined(BSP_USING_FDCAN1) || defined(BSP_USING_FDCAN2)

#include "string.h"
#include <stdlib.h>

static void         can_test_thread(void* argv);

uint32_t 		    can_test_stack[512/4];		// 
os_thread_id_t 		can_test_id;				// 


os_thread_attr_t can_test_attr = {
	"can_test",
	0,
	NULL,
	0,
	20,
	(void *)can_test_stack,
	sizeof(can_test_stack),
	OS_PRIORITY_BELOW_NORMAL,//OS_PRIORITY_HIGH_7,
	0,
};
struct  rt_semaphore  rx_sem; 
uint32_t g_read_cnt = 0;
uint32_t g_read_err_cnt = 0;
uint32_t g_can_irq_rcv_cnt = 0;
uint32_t g_send_cnt[3] = {0};

static void can_rx_irq_call(uint32_t dev_no, uint32_t size)
{
    g_can_irq_rcv_cnt++;
	//os_sem_release(&rx_sem);
}
#include "sdk_can.h"
static void can_test_thread(void* argv)
{
	#define SEND_FRAME_SIZE  1
    sdk_can_frame_t  txmsg = {0};
    sdk_can_frame_t  rxmsg = {0};
    uint32_t quit_cnt = 0;
    txmsg.hdr = -1;
    txmsg.id  = 0x78;             // ID 为 0x78 
    txmsg.ide = HAL_CAN_EXTID;    // 标准格式 
    txmsg.rtr = HAL_CAN_DTR;      // 数据帧 
    txmsg.len = 8;                // 数据长度为 8 
    txmsg.data[0] = 0x00;
    txmsg.data[1] = 0x11;
    txmsg.data[2] = 0x22;
    txmsg.data[3] = 0x33;
    txmsg.data[4] = 0x44;
    txmsg.data[5] = 0x55;
    txmsg.data[6] = 0x66;
    txmsg.data[7] = 0x77;
    
    while(1)
    {
        for(uint32_t i = 0; i < 20; i++)
        {
            rxmsg.hdr = -1;
		#if defined(BSP_USING_FDCAN1)
			if (0 < sdk_can_read(HAL_CAN1, &rxmsg, SEND_FRAME_SIZE, 0))
			{
                uint32_t read_id = rxmsg.id;
                if (g_read_cnt != read_id)
                {
                    g_read_err_cnt++;
                }
                g_read_cnt++;
			}
            if (g_send_cnt[HAL_CAN1] > 0)
            {
                txmsg.data[4] = (g_send_cnt[HAL_CAN1] >> 24) & 0xFF;
                txmsg.data[5] = (g_send_cnt[HAL_CAN1] >> 16) & 0xFF;
                txmsg.data[6] = (g_send_cnt[HAL_CAN1] >> 8) & 0xFF;
                txmsg.data[7] = (g_send_cnt[HAL_CAN1]) & 0xFF;
                g_send_cnt[HAL_CAN1]--;
                quit_cnt++;
                sdk_can_write(HAL_CAN1, &txmsg, SEND_FRAME_SIZE);
                if (quit_cnt >= 10)
                {
                    quit_cnt = 0;
                    break;
                }
            }
		#endif
			
		#if defined(BSP_USING_FDCAN2)
			if (0 < sdk_can_read(HAL_CAN2, &rxmsg, SEND_FRAME_SIZE, 0))
			{
                uint32_t read_id = rxmsg.id;
                if (g_read_cnt != read_id)
                {
                    g_read_err_cnt++;
                }
				g_read_cnt++;
			}
            if (g_send_cnt[HAL_CAN2] > 0)
            {
                txmsg.data[4] = (g_send_cnt[HAL_CAN2] >> 24) & 0xFF;
                txmsg.data[5] = (g_send_cnt[HAL_CAN2] >> 16) & 0xFF;
                txmsg.data[6] = (g_send_cnt[HAL_CAN2] >> 8) & 0xFF;
                txmsg.data[7] = (g_send_cnt[HAL_CAN2]) & 0xFF;
                g_send_cnt[HAL_CAN2]--;
                quit_cnt++;
                sdk_can_write(HAL_CAN2, &txmsg, SEND_FRAME_SIZE);
                if (quit_cnt >= 10)
                {
                    quit_cnt = 0;
                    break;
                }
            }
		#endif
		
		#if defined(BSP_USING_FDCAN3)
			if (0 < sdk_can_read(HAL_CAN3, &rxmsg, SEND_FRAME_SIZE, 0))
			{
                uint32_t read_id = rxmsg.id;
                if (g_read_cnt != read_id)
                {
                    g_read_err_cnt++;
                }
				g_read_cnt++;  
			}
            if (g_send_cnt[HAL_CAN3] > 0)
            {
                txmsg.data[4] = (g_send_cnt[HAL_CAN3] >> 24) & 0xFF;
                txmsg.data[5] = (g_send_cnt[HAL_CAN3] >> 16) & 0xFF;
                txmsg.data[6] = (g_send_cnt[HAL_CAN3] >> 8) & 0xFF;
                txmsg.data[7] = (g_send_cnt[HAL_CAN3]) & 0xFF;
                g_send_cnt[HAL_CAN3]--;
                quit_cnt++;
                sdk_can_write(HAL_CAN3, &txmsg, SEND_FRAME_SIZE);
                if (quit_cnt >= 10)
                {
                    quit_cnt = 0;
                    break;
                }
            }
		#endif
        }
        os_delay(TICK_10MS);
    }
}


extern uint32_t g_can_new_msg_cnt[3];
extern uint32_t g_can_full_cnt[3];
extern uint32_t g_can_msg_lost_cnt[3];

static int hal_can_sample(int argc, char *p_argv[])
{
    sdk_can_cfg_t can_cfg = {HAL_CAN_BAUD_250K, HAL_CAN_MODE_NORMAL};
	char     *opt  = p_argv[1];
	uint32_t port  = atoi(p_argv[2]);
	uint32_t opt_cnt = atoi(p_argv[3]);
    static bool is_init = false;
	
    if (false == is_init)
    {
        sdk_can_init();
	#if defined(BSP_USING_FDCAN1)
        sdk_can_open(HAL_CAN1);
        sdk_can_setup(HAL_CAN1, &can_cfg);
	#endif
		
	#if defined(BSP_USING_FDCAN2)
        sdk_can_open(HAL_CAN2);
        sdk_can_setup(HAL_CAN2, &can_cfg);
    #endif 
		
	#if defined(BSP_USING_FDCAN3)
		sdk_can_open(HAL_CAN3);
		sdk_can_setup(HAL_CAN3, &can_cfg);
	#endif 
        
        is_init = true;
    }

    if (!rt_strcmp(opt, "wr"))
	{
        can_test_id = os_thread_new(can_test_thread, NULL, &can_test_attr);         
	}
    else if (!rt_strcmp(opt, "tx"))
    {
        g_send_cnt[port] = opt_cnt;
    }
    else if (!rt_strcmp(opt, "get"))
	{
        
        log_d("g_irq_rcv_cnt: %d\n", g_can_irq_rcv_cnt);
        log_d("g_read_cnt: %d\n", g_read_cnt);
        log_d("g_send_cnt: [%ld][%ld][%ld]\n", g_send_cnt[0], g_send_cnt[1], g_send_cnt[2]);
        log_d("g_read_err_cnt: %ld\n", g_read_err_cnt);
        
        log_d("CAN0:new_msg_cnt:%d, full_cnt:%d, msg_lost_cnt:%d\n",g_can_new_msg_cnt[0],g_can_full_cnt[0],g_can_msg_lost_cnt[0]);
        log_d("CAN1:new_msg_cnt:%d, full_cnt:%d, msg_lost_cnt:%d\n",g_can_new_msg_cnt[1],g_can_full_cnt[1],g_can_msg_lost_cnt[1]);       
        log_d("CAN2:new_msg_cnt:%d, full_cnt:%d, msg_lost_cnt:%d\n",g_can_new_msg_cnt[2],g_can_full_cnt[2],g_can_msg_lost_cnt[2]);        
    }
    else if (!rt_strcmp(opt, "clr"))
	{
        g_read_cnt = 0;
        g_can_irq_rcv_cnt = 0;
        g_send_cnt[0] = 0;
        g_send_cnt[1] = 0;
        g_send_cnt[2] = 0;
        memset(g_can_new_msg_cnt, 0, sizeof(g_can_new_msg_cnt));
        memset(g_can_full_cnt, 0, sizeof(g_can_full_cnt));
        memset(g_can_msg_lost_cnt, 0, sizeof(g_can_msg_lost_cnt));
    }
	else if (!rt_strcmp(opt, "filter"))
	{
		can_filter_item_t items[8] =
		{
			HAL_CAN_FILTER_ITEM_INIT(0x100, 0, 0, 0, 0x105), // std_msg、data_msg、list_method
			HAL_CAN_FILTER_ITEM_INIT(0x300, 0, 0, 1, 0x700), // std_msg、data_msg、mask_method
			HAL_CAN_FILTER_ITEM_INIT(0x211, 0, 1, 0, 0x7ff), // std_msg、remote_msg、list_method
			HAL_CAN_FILTER_ITEM_INIT(0x211, 0, 1, 1, 0x7ff), // std_msg、remote_msg、mask_method
			
			HAL_CAN_FILTER_ITEM_INIT(0x1000000, 1, 0, 0, 0x1050000), // ext_msg、data_msg、list_method
			HAL_CAN_FILTER_ITEM_INIT(0x1100000, 1, 0, 1, 0x1100000), // ext_msg、data_msg、mask_method
			HAL_CAN_FILTER_ITEM_INIT(0x1100000, 1, 1, 0, 0x1ff0000), // ext_msg、remote_msg、list_method
			HAL_CAN_FILTER_ITEM_INIT(0x1100000, 1, 1, 1, 0x1ff0000), // ext_msg、remote_msg、mask_method
		};
		hal_can_filter_t cfg = {8, 1, items}; // 一共有 8 个过滤表 
		
	#if defined(BSP_USING_FDCAN1)
		if (hal_can_set_filter(HAL_CAN1, &cfg) != HAL_OK)
		{
			log_d("can set_filter failed!\n");
		}
	#endif
	#if defined(BSP_USING_FDCAN2)
		if (hal_can_set_filter(HAL_CAN2, &cfg) != HAL_OK)
		{
			log_d("can set_filter failed!\n");
		}
	#endif
	#if defined(BSP_USING_FDCAN3)
		if (hal_can_set_filter(HAL_CAN3, &cfg) != HAL_OK)
		{
			log_d("can set_filter failed!\n");
		}
	#endif
	}
	return 0;
}
#endif
MSH_CMD_EXPORT(hal_can_sample, hal_can_sample <wirte/read 1/2 0...>);
#endif

