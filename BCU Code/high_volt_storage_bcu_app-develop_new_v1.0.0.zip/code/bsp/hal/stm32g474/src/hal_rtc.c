#include <board.h>
#include <stdlib.h>
#include <string.h>
#include <rtthread.h>
#include <rtdevice.h>
#include <time.h>
#include "hal_rtc.h"
#include "hal_public.h"
#include "log.h"
#include "stm32g4xx_hal_pwr.h"
#include "sofar_errors.h"
#include "data_types.h"

#define RTC_BKP_DATA 	0xA5A5
RTC_HandleTypeDef g_hrtc = {0};
static RTC_AlarmTypeDef Alarm_InitStruct = { 0 };
hal_alarm_callback_t rtc_alarmcb = NULL;
static uint8_t g_rtc_state = 0;



/* RTC Wakeup Interrupt Generation: 
   the wake-up counter is set to its maximum value to yield the longuest
   stop time to let the current reach its lowest operating point.
   The maximum value is 0xFFFF, corresponding to about 33 sec. when 
   RTC_WAKEUPCLOCK_RTCCLK_DIV = RTCCLK_Div16 = 16
   
   Wakeup Time Base = (RTC_WAKEUPCLOCK_RTCCLK_DIV /(LSI))
   Wakeup Time = Wakeup Time Base * WakeUpCounter 
     = (RTC_WAKEUPCLOCK_RTCCLK_DIV /(LSI)) * WakeUpCounter
     ==> WakeUpCounter = Wakeup Time / Wakeup Time Base
   
   To configure the wake up timer to 60s the WakeUpCounter is set to 0xFFFF:
   Wakeup Time Base = 16 /(~32.000KHz) = ~0.5 ms
   Wakeup Time = 0.5 ms  * WakeUpCounter
   Therefore, with wake-up counter =  0xFFFF  = 65,535 
   Wakeup Time =  0,5 ms *  65,535 = 32,7675 s ~ 33 sec. 
**/

/**
* @brief		BCD码转byte
* @param		[in] bcd  
* @return		返回转码值 
* @retval		hex值
*/
 uint8_t hal_bcd2hex(uint8_t bcd)
{
    uint8_t tmp = 0;
    tmp = ((uint8_t)(bcd & (uint8_t)0xF0) >> (uint8_t)0x4) * 10;
    return (tmp + (bcd & (uint8_t)0x0F));
}


/**
* @brief		检查时间数据是否合法
* @return		执行结果
* @retval		SF_OK 成功
* @retval		HAL_EIO 失败 
*/
static int32_t hal_is_time_ok(uint32_t rtc_format, hal_rtc_t *p_time)
{
	if (HAL_RTC_FORMAT_BIN == rtc_format)
	{
		if ((!IS_RTC_YEAR(p_time->tm_year))
	  	  ||(!IS_RTC_MONTH(p_time->tm_mon))   
	  	  ||(!IS_RTC_DATE(p_time->tm_day))    
          //||(!IS_RTC_WEEKDAY(p_time->tm_min))
	  	  ||(!IS_RTC_HOUR24(p_time->tm_hour))
	  	  ||(!IS_RTC_MINUTES(p_time->tm_min))
	  	  ||(!IS_RTC_SECONDS(p_time->tm_sec)))
	    {
			return SF_ERR_PARA;
		}	
	}
	else if(HAL_RTC_FORMAT_BCD == rtc_format)
	{
		if ((!IS_RTC_YEAR(hal_bcd2hex(p_time->tm_year)))
	  	  ||(!IS_RTC_MONTH(hal_bcd2hex(p_time->tm_mon)))   
	  	  ||(!IS_RTC_DATE(hal_bcd2hex(p_time->tm_day)))
          //||(!IS_RTC_WEEKDAY(hal_bcd2hex(p_time->tm_min)))
	  	  ||(!IS_RTC_HOUR24(hal_bcd2hex(p_time->tm_hour)))
	  	  ||(!IS_RTC_MINUTES(hal_bcd2hex(p_time->tm_min)))
	  	  ||(!IS_RTC_SECONDS(hal_bcd2hex(p_time->tm_sec))))
	    {
			return SF_ERR_PARA;
		}
	}
	else
	{
		return SF_ERR_NDEF;
	}
	return SF_OK;
}


/**
* @brief		RTC加载驱动
* @return		执行结果
* @retval		HAL_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_rtc_init(void)
{
    RTC_TimeTypeDef sTime = {0};
    RTC_DateTypeDef sDate = {0};
	 
    HAL_PWR_EnableBkUpAccess();
    __HAL_RCC_LSE_CONFIG(RCC_LSE_ON);
    if (1 != g_rtc_state)
    {
        if (HAL_RTCEx_BKUPRead(&g_hrtc, RTC_BKP_DR0) != RTC_BKP_DATA)
        {
            /* Init RTC */
            g_hrtc.Instance = RTC;
            g_hrtc.Init.HourFormat = RTC_HOURFORMAT_24;
            g_hrtc.Init.AsynchPrediv = 127;
            g_hrtc.Init.SynchPrediv = 255;
            g_hrtc.Init.OutPut = RTC_OUTPUT_DISABLE;
            g_hrtc.Init.OutPutRemap = RTC_OUTPUT_REMAP_NONE;
            g_hrtc.Init.OutPutPolarity = RTC_OUTPUT_POLARITY_HIGH;
            g_hrtc.Init.OutPutType = RTC_OUTPUT_TYPE_OPENDRAIN;
            g_hrtc.Init.OutPutPullUp = RTC_OUTPUT_PULLUP_NONE;
            
            if (HAL_RTC_Init(&g_hrtc) != HAL_OK)
            {
                Error_Handler();
            }
            sTime.Hours = 0x08;
            sTime.Minutes = 0x00;
            sTime.Seconds = 0x00;
            sTime.SubSeconds = 0x00;
            sTime.DayLightSaving = RTC_DAYLIGHTSAVING_NONE;
            sTime.StoreOperation = RTC_STOREOPERATION_RESET;
            if (HAL_RTC_SetTime(&g_hrtc, &sTime, RTC_FORMAT_BCD) != HAL_OK)
            {
                Error_Handler();
            }
            sDate.WeekDay = RTC_WEEKDAY_FRIDAY;
            sDate.Month = RTC_MONTH_JULY;
            sDate.Date = 0x07;
            sDate.Year = 0x23;

            if (HAL_RTC_SetDate(&g_hrtc, &sDate, RTC_FORMAT_BCD) != HAL_OK)
            {
                Error_Handler();
            }
            /* USER CODE BEGIN RTC_Init 2 */

            /* Writes a data in a RTC Backup data Register0 */
            HAL_RTCEx_BKUPWrite(&g_hrtc, RTC_BKP_DR0, RTC_BKP_DATA);
            
            rt_kprintf("RTC bak init\r\n");
        }
        
        /*##-3- Configure the NVIC for RTC Alarm ###################################*/
        HAL_NVIC_SetPriority(RTC_WKUP_IRQn, 0x0, 0);
        HAL_NVIC_EnableIRQ(RTC_WKUP_IRQn);
        g_rtc_state = 1;  // RTC打开        
    }
    rt_kprintf("RTC init ok\r\n");
	return SF_OK;
}
INIT_DEVICE_EXPORT(hal_rtc_init);

/**
* @brief		RTC删除驱动(预留)
* @return		执行结果
* @retval		SF_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_rtc_deinit(void)
{
	return SF_ERR_FNOSUPP;
}


/**
* @brief		设置RTC时间 
* @param		[in] rtc_format 时间格式:BCD/HEX
				[in] p_time rtc时间结构体,详见hal_rtc_t定义   
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		HAL_EIO 失败   
* @pre			执行hal_rtc_init后执行才有效。
*/
int32_t hal_rtc_set(uint32_t rtc_format, hal_rtc_t *p_time)
{
    RTC_DateTypeDef rtc_date_structure = {0};
	RTC_TimeTypeDef rtc_time_structure = {0};
	
    if(0 == g_rtc_state)
    {
        return SF_ERR_OPEN;
    }
	/* 参数检查 */
	if ((!HAL_IS_RTC_FORMAT(rtc_format)) || (!p_time))
	{
		return SF_ERR_PARA;	
	}
	/* 时间数据检查 */
	if(SF_OK != hal_is_time_ok(rtc_format, p_time))
	{
		return SF_ERR_PARA;	
	}
	
	/* 检查星期数据是否合法 */
	if(!IS_RTC_WEEKDAY(p_time->tm_weekday))
	{
		p_time->tm_weekday = RTC_WEEKDAY_MONDAY;	
	}
	
	rtc_date_structure.Year	   = p_time->tm_year;
	rtc_date_structure.Month   = p_time->tm_mon;
	rtc_date_structure.Date	   = p_time->tm_day;
	rtc_date_structure.WeekDay = p_time->tm_weekday;
    
	rtc_time_structure.Hours   = p_time->tm_hour;
	rtc_time_structure.Minutes = p_time->tm_min;
	rtc_time_structure.Seconds = p_time->tm_sec;

    
	HAL_RTC_SetTime(&g_hrtc, &rtc_time_structure,rtc_format);
    HAL_RTC_SetDate(&g_hrtc, &rtc_date_structure,rtc_format);
	return SF_OK;
}

/**
* @brief		读取RTC时间 
* @param		[in] rtc_format 时间格式:BCD/HEX
				[out] p_time rtc时间结构体,详见hal_rtc_t定义
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		HAL_EIO 失败   
* @pre			执行hal_rtc_init后执行才有效。
*/
int32_t hal_rtc_get(uint32_t rtc_format, hal_rtc_t *p_time)
{
	RTC_DateTypeDef rtc_date_structure;
	RTC_TimeTypeDef rtc_time_structure;
   
    if(0 == g_rtc_state)
    {
        return SF_ERR_OPEN;
    }
	/* rtc时间格式检查 */
	if ((!HAL_IS_RTC_FORMAT(rtc_format)) || (!p_time))
	{
		return SF_ERR_PARA;	
	}
	/* 获取RTC时间,must read time first!!! */
    HAL_RTC_GetTime(&g_hrtc, &rtc_time_structure,rtc_format);
	HAL_RTC_GetDate(&g_hrtc, &rtc_date_structure,rtc_format);
	

	p_time->tm_year 	= rtc_date_structure.Year;
	p_time->tm_mon		= rtc_date_structure.Month;
	p_time->tm_day		= rtc_date_structure.Date;
	p_time->tm_weekday	= rtc_date_structure.WeekDay;
	p_time->tm_hour 	= rtc_time_structure.Hours;
	p_time->tm_min		= rtc_time_structure.Minutes;
	p_time->tm_sec		= rtc_time_structure.Seconds;

	/* 检查时间数据是否合法 */
	return hal_is_time_ok(rtc_format, p_time);
}


/**
* @brief		读取RTC时间戳
* @param		[in] void
* @return		执行结果
* @retval		>=0 自1970年的秒数 
* @retval		-1 失败   
* @pre			执行hal_rtc_init后执行才有效。
*/
uint32_t hal_rtc_timestamp_get(void)
{
	struct tm time;
	RTC_DateTypeDef rtc_date_structure;
	RTC_TimeTypeDef rtc_time_structure;
	
	/* 获取RTC时间 */
    HAL_RTC_GetTime(&g_hrtc, &rtc_time_structure,RTC_FORMAT_BIN);
	HAL_RTC_GetDate(&g_hrtc, &rtc_date_structure,RTC_FORMAT_BIN);

	time.tm_year 	= (rtc_date_structure.Year + 2000) - 1900;
	time.tm_mon		= rtc_date_structure.Month - 1;
	time.tm_mday	= rtc_date_structure.Date;
	time.tm_hour 	= rtc_time_structure.Hours;
	time.tm_min		= rtc_time_structure.Minutes;
	time.tm_sec		= rtc_time_structure.Seconds;

	return mktime(&time);
}

void hal_rtc_alarm_enable(void)
{
    HAL_RTC_SetAlarm_IT(&g_hrtc,&Alarm_InitStruct,RTC_FORMAT_BIN);
    HAL_RTC_GetAlarm(&g_hrtc,&Alarm_InitStruct,RTC_ALARM_A,RTC_FORMAT_BIN);
    log_d("alarm read:%d:%d:%d", Alarm_InitStruct.AlarmTime.Hours,
        Alarm_InitStruct.AlarmTime.Minutes,
        Alarm_InitStruct.AlarmTime.Seconds);
    HAL_NVIC_SetPriority(RTC_Alarm_IRQn, 0x02, 0);
    HAL_NVIC_EnableIRQ(RTC_Alarm_IRQn);
}

void hal_rtc_alarm_disable(void)
{
    HAL_RTC_DeactivateAlarm(&g_hrtc, RTC_ALARM_A);
    HAL_NVIC_DisableIRQ(RTC_Alarm_IRQn);
    rtc_alarmcb = NULL;
}

static int32_t hal_alarm_time_set(hal_alarm_setup_t *val)
{

        Alarm_InitStruct.Alarm = RTC_ALARM_A;
        Alarm_InitStruct.AlarmTime.Hours = val->wktime.tm_hour;
        Alarm_InitStruct.AlarmTime.Minutes = val->wktime.tm_min;
        Alarm_InitStruct.AlarmTime.Seconds = val->wktime.tm_sec;
#ifndef SOC_SERIES_STM32F1
        Alarm_InitStruct.AlarmDateWeekDay = RTC_WEEKDAY_MONDAY;
        Alarm_InitStruct.AlarmDateWeekDaySel = RTC_ALARMDATEWEEKDAYSEL_WEEKDAY;
        Alarm_InitStruct.AlarmMask = RTC_ALARMMASK_DATEWEEKDAY;
        Alarm_InitStruct.AlarmSubSecondMask = RTC_ALARMSUBSECONDMASK_NONE;
        Alarm_InitStruct.AlarmTime.TimeFormat = RTC_HOURFORMAT12_AM;
#endif  /* SOC_SERIES_STM32F1 */
        log_d("alarm set:%d:%d:%d", Alarm_InitStruct.AlarmTime.Hours,
        Alarm_InitStruct.AlarmTime.Minutes,
        Alarm_InitStruct.AlarmTime.Seconds);
        hal_rtc_alarm_enable();
    

    return RT_EOK;
}

/**
* @brief		创建闹钟
* @param		[in] val rtc闹钟时间  
* @param		[in] cb 闹钟回调函数  
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		HAL_EIO 失败   
*/
int32_t hal_rtc_creat_alarm(hal_alarm_setup_t *val, hal_alarm_callback_t cb)
{
//	struct rt_alarm_setup alarm_setup;
//    struct rt_alarm * alarm = RT_NULL;
//	
//	alarm_setup.flag = val->flag;
//	alarm_setup.wktime.tm_sec = val->wktime.tm_sec;
//	alarm_setup.wktime.tm_min = val->wktime.tm_min;
//	alarm_setup.wktime.tm_hour = val->wktime.tm_hour;
//	alarm_setup.wktime.tm_wday = val->wktime.tm_day;
//	alarm_setup.wktime.tm_mon = val->wktime.tm_mon;
//	alarm_setup.wktime.tm_year = val->wktime.tm_year;

//	alarm = rt_alarm_create(cb, &alarm_setup);

//	if(RT_NULL != alarm)
//    {
//        rt_alarm_start(alarm);
//		return SF_OK;
//    }
//	return SF_ERR_PARA;
    
    hal_alarm_time_set(val);
    rtc_alarmcb = cb;
    return SF_OK;
}

/**
* @brief		启动闹钟   
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		HAL_EIO 失败   
*/
int32_t hal_rtc_start_alarm(hal_alarm_t alarm)
{
//	rt_err_t alarm_err;

//	alarm_err = rt_alarm_start(alarm);

//	if(alarm_err != RT_NULL)
//	{
//		 return SF_ERR_PARA;
//	}
    
    hal_rtc_alarm_enable();
	return SF_OK;
}

/**
* @brief		停止闹钟   
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		HAL_EIO 失败   
*/
int32_t hal_rtc_stop_alarm(hal_alarm_t alarm)
{
//	rt_err_t alarm_err;

//	alarm_err = rt_alarm_stop(alarm);

//	if(alarm_err != RT_NULL)
//	{
//		 return SF_ERR_PARA;
//	}
//    HAL_RTC_DeactivateAlarm(&g_hrtc, RTC_ALARM_A);
//    HAL_NVIC_DisableIRQ(RTC_Alarm_IRQn);
    
   hal_rtc_alarm_disable(); 
	return SF_OK;
}

/**
* @brief		取消闹钟   
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		HAL_EIO 失败   
*/
int32_t hal_rtc_clear_alarm(hal_alarm_t alarm)
{
//	uint8_t status = 0;

//	status = rt_alarm_delete(alarm);

//	if(status != 0)
//	{
//		 return SF_ERR_PARA;
//	}
    hal_rtc_alarm_disable(); 
	return SF_ERR_PARA;
}

void RTC_Alarm_IRQHandler(void)
{
   // rt_interrupt_enter();
    HAL_RTC_AlarmIRQHandler(&g_hrtc);
    if(rtc_alarmcb != NULL)
        rtc_alarmcb(NULL,NULL);
    
    //rt_interrupt_leave();
}

void RTC_WKUP_IRQHandler(void)
{
    HAL_RTCEx_WakeUpTimerIRQHandler(&g_hrtc);
}


int32_t hal_rtc_wakeup_time_set(uint32_t time_ms)
{
    #define MAX_WKUP_IT_TIME    30000 // 30s
    uint32_t wakeup_counter;
    
    if(time_ms < MAX_WKUP_IT_TIME)
    {
        wakeup_counter = ((time_ms * 2) < 0xFFFF) ? (time_ms * 2) : 0xFFFF; 
        HAL_RTCEx_SetWakeUpTimer_IT(&g_hrtc, wakeup_counter, RTC_WAKEUPCLOCK_RTCCLK_DIV16);
        return SF_OK;
    }
    return SF_ERR_PARA;
}

/**
* @brief		扩展功能 
* @param		[in] dev_no 设备端口号  
* @param		[in] cmd 控制命令  
* @param		[in] arg 控制参数   
* @return		执行结果
* @retval		SF_OK 成功    
* @retval		<0 失败原因  
*/
int32_t hal_rtc_ioctl(int32_t dev_no, uint8_t cmd, void* p_arg)
{
	return SF_ERR_FNOSUPP;
}



#if 1
#include <stdlib.h>
#include "rtthread.h"
void gettime(int argc,void**argv)
{
	hal_rtc_t tm;
	hal_rtc_get(RTC_FORMAT_BIN,&tm);
	rt_kprintf("rtc time:%u-%u-%u %u:%u:%u\n",tm.tm_year,tm.tm_mon,tm.tm_day,
		tm.tm_hour,tm.tm_min,tm.tm_sec);
}
void settime(int argc,void**argv)
{
	hal_rtc_t tm;
	if(argc < 7) 
	{
		rt_kprintf("rtc time:para number must=7\n");
        return;
	}
	tm.tm_year = atoi(argv[1]);
	tm.tm_mon = atoi(argv[2]);
	tm.tm_day = atoi(argv[3]);

	tm.tm_hour = atoi(argv[4]);
	tm.tm_min = atoi(argv[5]);
	tm.tm_sec = atoi(argv[6]);
	
	hal_rtc_set(RTC_FORMAT_BIN,&tm);
	rt_kprintf("set time:%u-%u-%u %u:%u:%u\n",tm.tm_year,tm.tm_mon,tm.tm_day,
		tm.tm_hour,tm.tm_min,tm.tm_sec);
}
MSH_CMD_EXPORT(gettime,read rtctime);
MSH_CMD_EXPORT(settime,set YMDHMS);
#endif



#ifdef RT_USING_FINSH

/**
* @brief        GPIO_HAL功能样例
* @param        argv 功能参数
* @return       返回结果
* @retval         SF_OK 成功
* @retval         HAL_EIO 失败
*/
static int hal_rtc_sample(int argc, char *argv[])
{
	char 	 *opt  	 = argv[1];
	char 	 *format = argv[2];
	hal_rtc_t time;
	int32_t   ret;

	if (!rt_strcmp(opt, "set"))
	{
		if (!rt_strcmp(format, "bin"))
		{
			time.tm_year = atoi(argv[3]);
			time.tm_mon  = atoi(argv[4]);
			time.tm_day  = atoi(argv[5]);
			time.tm_hour = atoi(argv[6]);
			time.tm_min  = atoi(argv[7]);
			time.tm_sec  = atoi(argv[8]);	
			ret = hal_rtc_set(HAL_RTC_FORMAT_BIN, &time);
		}
		else if(!rt_strcmp(format, "bcd"))
		{
			time.tm_year = hal_bcd2hex(atoi(argv[3]));
			time.tm_mon  = hal_bcd2hex(atoi(argv[4]));
			time.tm_day  = hal_bcd2hex(atoi(argv[5]));
			time.tm_hour = hal_bcd2hex(atoi(argv[6]));
			time.tm_min  = hal_bcd2hex(atoi(argv[7]));
			time.tm_sec  = hal_bcd2hex(atoi(argv[8]));
			ret = hal_rtc_set(HAL_RTC_FORMAT_BCD, &time);
		}
		if(SF_OK != ret)
		{
			rt_kprintf("set RTC time failed\n");
		}
	}
	else if(!rt_strcmp(opt, "read"))
	{
		if (!rt_strcmp(format, "bin"))
		{
			ret = hal_rtc_get(HAL_RTC_FORMAT_BIN, &time);
			if(SF_OK != ret)
			{
				rt_kprintf("get RTC time failed\n");
			}
			else
			{
				rt_kprintf("get RTC time: 20%02d-%02d-%02d %02d:%02d:%02d\n", 
							time.tm_year, time.tm_mon, time.tm_day, 
							time.tm_hour, time.tm_min, time.tm_sec);
			}
		}
		else if(!rt_strcmp(format, "bcd"))
		{
			ret = hal_rtc_get(HAL_RTC_FORMAT_BCD, &time);
			if(SF_OK != ret)
			{
				rt_kprintf("get RTC time failed\n");
			}
			else
			{
				rt_kprintf("get RTC time: 20%02d-%02d-%02d %02d:%02d:%02d\n", 
							hal_bcd2hex(time.tm_year), hal_bcd2hex(time.tm_mon), hal_bcd2hex(time.tm_day), 
							hal_bcd2hex(time.tm_hour), hal_bcd2hex(time.tm_min), hal_bcd2hex(time.tm_sec));
			}
		}
	}
	else if(!rt_strcmp(opt, "time_stamp"))
	{
		uint32_t time_stamp;
		time_stamp = hal_rtc_timestamp_get();
		rt_kprintf("get_time_stamp:%d\n", time_stamp);
	}
	else
	{
		rt_kprintf("you input '%s' is not support\n",opt);
	}
	
	return 1;
}

MSH_CMD_EXPORT(hal_rtc_sample, hal_rtc_sample <set/read bin 22 08 29 09 00 01>);
#endif 






