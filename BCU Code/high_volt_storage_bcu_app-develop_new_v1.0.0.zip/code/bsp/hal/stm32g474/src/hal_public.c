#include <rtthread.h>
#include "osif.h"
#include "hal_public.h"
#include <board.h>
#include "drv_common.h"
#include "sofar_errors.h"
#include "msh.h"

rt_mutex_t g_dfs_Mutex = NULL; 
/**
 * @brief		延时us
 * @param		[in] 需要延时的us数, <1000us
 */
void hal_delay_us(uint32_t us)
{
    rt_hw_us_delay(us);
}

/**
* @brief		使能总中断
* @param		[in] level 关闭中断前的状态,参数保留未使用
* @return		无 
*/
void hal_enable_interrupt(int32_t level)
{
    rt_interrupt_leave();
}


/**
* @brief		关闭总中断
* @return		中断状态
*/
int32_t hal_disable_interrupt(void)
{
    rt_interrupt_enter();
    
	return 0;
}


/**
* @brief		获取当前tick
* @return		当前tick值
*/
uint32_t hal_tick_get(void)
{
    return os_kernel_get_tick_count();
}



/**
* @brief		判断是否时间tick超时
* @param		[in] start_tick 启动计时的tick  
* @param		[in] interval 中间间隔
* @return		是否超时 
* @retval		true 已超时
* @retval		false 未超时
*/
bool hal_is_tick_over(uint32_t start_tick, uint32_t interval)
{
    uint32_t cur_tcik = os_kernel_get_tick_count();
    uint32_t need_interval;
    
	if (cur_tcik >= start_tick)
	{
		need_interval = (cur_tcik - start_tick);
	}
	else
	{
		need_interval = (0xffffffff - start_tick + cur_tcik);
	}
    if (need_interval >= interval)
	{
        return true;
	}
    else
	{
        return false;		
	}
}


/**
* @brief		系统复位
* @return		void
*/
void hal_system_reset(void)
{
	__set_FAULTMASK(1); 
	__NVIC_SystemReset();
}

rt_mutex_t hal_dfs_lock_handel_get(void)
{
   if (g_dfs_Mutex == NULL)
   {
       g_dfs_Mutex = rt_mutex_create("dfslock", RT_IPC_FLAG_PRIO);
   }
   return g_dfs_Mutex;   
}

#ifdef RT_USING_FINSH
#ifdef RT_USING_FINSH_DEBUG
static int hal_tick_sample(int argc, char *argv[])
{
	static uint32_t start_tick = 0;
	static uint32_t timeout_cnt = 0;

	while(1)
	{
		if(0 == start_tick)
		{
			start_tick = hal_tick_get();
		}
		if( true == hal_is_tick_over(start_tick, os_tick_from_millisecond(1000)))
		{
			start_tick = 0;
			rt_kprintf("time is out, tick: %d\r\n", hal_tick_get());
			if(++timeout_cnt > 10)
			{
				return 0;	
			}
		}	
		//os_delay(os_tick_from_millisecond(100));
	}
	
	
	//return HAL_OK;
}
MSH_CMD_EXPORT(hal_tick_sample, hal_tick_sample);
#endif
#endif


