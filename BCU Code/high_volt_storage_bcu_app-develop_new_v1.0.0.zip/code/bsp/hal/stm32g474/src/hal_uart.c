#include <board.h>
#include <string.h>
#include <rtthread.h>
#include <rtdevice.h>
#include "hal_uart.h"
#include "hal_gpio.h"
#include "pin_config.h"
#include "log.h"
#include "sofar_errors.h"

// 串口回调函数
typedef struct{
	irq_uart_callback tx_cb;
	irq_uart_callback rx_cb;
}uart_int_cb_t;

typedef struct{
	uint32_t is_init;								// 0-未初始化 1-已初始化
	uint32_t is_open;								// 0-未打开 1-已打开
	uint32_t is_suspend;							// 0-未挂起 1-已挂起
}uart_status_t;

// 串口索引号对应的设备名称
static const char *gp_uart_dev[UART_MAX_NUM] =
{
#ifdef BSP_USING_UART1	
	"uart1",
#endif
#ifdef BSP_USING_UART2	
	"uart2",
#endif
#ifdef BSP_USING_UART3	
	"uart3",
#endif
#ifdef BSP_USING_UART4	
	"uart4",
#endif
};

// 标识UART状态
static uart_status_t	g_uart_status = {0};

// 从RTOS打开的设备类句柄
static rt_device_t g_serial[UART_MAX_NUM];

// 收发回调函数，0=TX, 1=RX 
static uart_int_cb_t g_uart_cb[UART_MAX_NUM];



/**
* @brief		串口加载驱动
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
*/
int32_t hal_uart_init(void)
{
	if (!g_uart_status.is_init)
	{
		memset((void *)g_serial, 0, sizeof(rt_device_t)*UART_MAX_NUM);
		memset((void *)g_uart_cb, 0, sizeof(uart_int_cb_t)*UART_MAX_NUM);
		g_uart_status.is_init = 1;
	}

	return SF_OK;
}
INIT_BOARD_EXPORT(hal_uart_init);


/**
* @brief		串口删除驱动（预留）
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
*/
int32_t hal_uart_deinit(void)
{
	if (g_uart_status.is_init)
	{
		memset((void *)&g_uart_status, 0, sizeof(uart_status_t));
	}
	
	return SF_OK;
}


/**
* @brief		打开串口功能 
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @默认参数
* - p_conf->baud	波特率（默认115200）
* - p_conf->size	数据位（默认8）
* - p_conf->stop	停止位（默认1）
* - p_conf->par;   	校验位（默认0）   
* - p_conf->flow;  	硬件流控（默认0）
* - p_conf->buffsize;	缓冲区/字节（默认128K）
* @return		执行结果
* @retval		SF_OK 成功
* @retval		<0 失败原因  
* @pre			执行hal_uart_init后执行才有效。
* @warning		按照默认115200参数进行配置

*/
int32_t hal_uart_open(uint32_t port)
{	
	int32_t ret;
	
	// param check
	if (port >= UART_MAX_NUM) 
	{
		ret = SF_ERR_PARA;
		goto failed;
	}
	// if adc is opened, return ok
	if (SF_GET_BIT(g_uart_status.is_open, (1U << port)))
    {
        return SF_OK;
    } 
	// if adc is not init, return failed 
	if (!g_uart_status.is_init)
	{
		ret = SF_ERR_PARA;
		goto failed;
	} 	

	g_serial[port] = rt_device_find(gp_uart_dev[port]);
    if (!g_serial[port])
    {
        ret =  SF_ERR_NO_OBJECT;
		goto failed;
    }
	 	    
	// 以中断接收及轮询发送模式打开串口设备
    if(SF_OK != rt_device_open(g_serial[port], RT_DEVICE_FLAG_INT_RX))
	{
		ret =  SF_ERR_OPEN;
		goto failed;
	}
	/* 设置串口设备状态 */
	SF_SET_BIT(g_uart_status.is_open, (1U << port));
	return SF_OK;

failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;	
}

/**
* @brief		关闭串口功能 
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @pre			执行hal_uart_init后执行才有效。
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_uart_close(uint32_t port)
{
	int32_t ret;
	
	// param check
	if (port >= UART_MAX_NUM) 
	{
		ret = SF_ERR_PARA;
		goto failed;
	}
	// if adc is opened, return ok
	if (!SF_GET_BIT(g_uart_status.is_open, (1U << port)))
    {
        return SF_OK;
    } 
	
	g_serial[port] = rt_device_find(gp_uart_dev[port]);
    if (!g_serial[port])
    {
        ret =  SF_ERR_NO_OBJECT;
		goto failed;
    }
  
	if(SF_OK != rt_device_close(g_serial[port]))
	{
		return SF_ERR_PARA;
	}
	
	/* 清除串口设备状态 */
	SF_CLR_BIT(g_uart_status.is_open, (1u << port));
	return SF_OK;

failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;	
}


/**
* @brief		串口功能从休眠中唤醒，恢复状态
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_uart_resume(uint32_t port)
{
	// param check
	if (port >= UART_MAX_NUM) 
	{
		return SF_ERR_PARA;
	}
	// if the device is not supended, return ok
	if (!SF_GET_BIT(g_uart_status.is_suspend, (1U << port)))
    {
        return SF_OK;
    } 	

#ifdef BSP_USING_UART1	
	if (UART1_ID == port)
	{
		;	
	}
#endif
#ifdef BSP_USING_UART2	
	if (UART2_ID == port)
	{
		;	
	}
#endif
#ifdef BSP_USING_UART3	
	if (UART3_ID == port)
	{
		;
	}
#endif
#ifdef BSP_USING_UART4	
	if (UART4_ID == port)
	{
		;	
	}
#endif
#ifdef BSP_USING_UART5	
	if (UART5_ID == port)
	{
		;	
	}
#endif
#ifdef BSP_USING_UART6	
	if (UART6_ID == port)
	{
		;	
	}
#endif
#ifdef BSP_USING_UART7	
	if (UART7_ID == port)
	{
		;	
	}
#endif

	return SF_OK;
}
 
/**
* @brief		串口功能进入休眠模式
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败    
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式，功能不影响
*/
int32_t hal_uart_suspend(uint32_t port)
{	
    hal_gpio_config_t gpio_config = {.direction = HAL_GPIO_OUTPUT, .pull = HAL_GPIO_NOPULL};
    
	// param check
	if (port >= UART_MAX_NUM) 
	{
		return SF_ERR_PARA;
	}
	// if the device is not supended, return ok
	if (SF_GET_BIT(g_uart_status.is_suspend, (1U << port)))
    {
        return SF_OK;
    } 	

	if(SF_OK != hal_uart_close(port))
	{
		return SF_ERR_PARA;
	}
	
#ifdef BSP_USING_UART1	 
	if (UART1_ID == port)
	{
		hal_uart_close(UART1_ID);
        hal_gpio_config(UART1_TX_PIN, &gpio_config);  
        hal_gpio_config(UART1_RX_PIN, &gpio_config);  
        hal_gpio_write(UART1_TX_PIN, 0); 
        hal_gpio_write(UART1_RX_PIN, 0); 
	}
#endif
#ifdef BSP_USING_UART2	
	if (UART2_ID == port)
	{
		hal_uart_close(UART2_ID);
        hal_gpio_config(UART2_TX_PIN, &gpio_config);  
        hal_gpio_config(UART2_RX_PIN, &gpio_config);  
        hal_gpio_write(UART2_TX_PIN, 0); 
        hal_gpio_write(UART2_RX_PIN, 0); 
	}
#endif
#ifdef BSP_USING_UART3	
	if (UART3_ID == port)
	{
		hal_uart_close(UART3_ID);
        hal_gpio_config(UART3_TX_PIN, &gpio_config);  
        hal_gpio_config(UART3_RX_PIN, &gpio_config);  
        hal_gpio_write(UART3_TX_PIN, 0); 
        hal_gpio_write(UART3_RX_PIN, 0); 
	}
#endif
#ifdef BSP_USING_UART4	 
	if (UART4_ID == port)
	{
		hal_uart_close(UART4_ID);
        hal_gpio_config(UART4_TX_PIN, &gpio_config);  
        hal_gpio_config(UART4_RX_PIN, &gpio_config);  
        hal_gpio_write(UART4_TX_PIN, 1); 
        hal_gpio_write(UART4_RX_PIN, 1); 
	}
#endif
#ifdef BSP_USING_UART5	 
	if (UART5_ID == port)
	{
		;
	}
#endif
#ifdef BSP_USING_UART6	
	if (UART6_ID == port)
	{
		;
	}
#endif
#ifdef BSP_USING_UART7	
	if (UART7_ID == port)
	{
		;
	}
#endif

	return SF_OK;
}

/**
* @brief		设置串口属性 
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @param		[out] p_conf 参数配置指针
* - p_conf->baud	波特率（默认115200）
* - p_conf->size	数据位（默认8）
* - p_conf->stop	停止位（默认1）
* - p_conf->par;   	校验位（默认0）    
* - p_conf->flow;  	硬件流控（默认0）
* - p_conf->buffsize;	缓冲区/字节（默认128K）
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			执行hal_uart_open后执行才有效。
* @warning		配置参数非法时，按照默认参数进行配置
*/
int32_t hal_uart_setup(uint32_t port, hal_uart_conf_t *p_conf)
{
	int32_t ret;
	struct serial_configure config = RT_SERIAL_CONFIG_DEFAULT; 

	// param check
	if ((port >= UART_MAX_NUM) || (!p_conf))
	{
		ret = SF_ERR_PARA;
		goto failed;
	}
	// if uart is opened, return ok
	if (!SF_GET_BIT(g_uart_status.is_open, (1U << port)))
    {
        ret =  SF_ERR_OPEN;
		goto failed;
	}

    /* 波特率 */
    if ((p_conf->baud != 0) && (p_conf->baud <= HAL_B1152000))
    {
    	config.baud_rate = p_conf->baud;
    }
    /* 数据位 */
    switch (p_conf->size)
   	{
   		case HAL_UART_8B:
   			config.data_bits = DATA_BITS_8;
   			break;
   		case HAL_UART_9B:
   			config.data_bits = DATA_BITS_9;
   			break;
   	}
   	/* 停止位 */
   	switch (p_conf->stop)
   	{
   		case HAL_UART_STOP1B:
   			config.stop_bits = STOP_BITS_1;
   			break;
   		case HAL_UART_STOP2B:
   			config.stop_bits = STOP_BITS_2;
   			break;
   	}
   	/* 校验位 */
   	switch (p_conf->par)
   	{
   		case HAL_UART_PARNON:
   			config.parity = PARITY_NONE;
   			break;
   		case HAL_UART_PARODD:
   			config.parity = PARITY_ODD;
   			break;
   		case HAL_UART_PAREVEN:
   			config.parity = PARITY_EVEN;
   			break;
   	}
	/* 缓冲区大小 */
	config.bufsz = p_conf->buffsize;           
	/* 控制串口设备。通过控制接口传入命令控制字，与控制参数 */
	return rt_device_control(g_serial[port], RT_DEVICE_CTRL_CONFIG, &config);

failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;
}

/**
* @brief		清空收缓冲区数据（预留）
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @pre			执行hal_uart_open后执行才有效。
*/
int32_t hal_uart_flush(uint32_t port)
{
	return SF_OK;
}

/**
* @brief		串口收数据 
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @param		[in] p_buf 缓冲区指针  
* @param		[in] len 缓冲区长度   
* @return		执行结果
* @retval		>=0 接收数据长度  
* @retval		<0 失败原因  
* @pre			执行hal_uart_open后执行才有效。
*/
int32_t hal_uart_read(uint32_t port, uint8_t *p_buf, int32_t len)
{
	int32_t ret;
	int32_t read_len;
	
	// param check
	if ((port >= UART_MAX_NUM) || (NULL == p_buf)|| (len <= 0)) 
	{
		ret = SF_ERR_PARA;
		goto failed;
	}
	// if uart is closed, return failed
	if (!SF_GET_BIT(g_uart_status.is_open, (1U << port)))
    {
        ret = SF_ERR_OPEN;
		goto failed;
    }
    
	read_len = rt_device_read(g_serial[port], -1, p_buf, len);
	return read_len;

failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;		
}

/**
* @brief		串口发数据 
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @param		[in] buf 缓冲区指针  
* @param		[in] len 缓冲区长度   
* @return		执行结果
* @retval		>=0 发送数据长度   
* @retval		<0 失败原因  
* @pre			执行hal_uart_open后执行才有效。
*/
int32_t hal_uart_write(uint32_t port, uint8_t *p_buf, int32_t len)
{
	int32_t ret;
	int32_t send_len;
	
	// param check
	if ((port >= UART_MAX_NUM) || (NULL == p_buf)|| (len <= 0)) 
	{
		ret = SF_ERR_PARA;
		goto failed;
	}
	// if uart is closed, return failed
	if (!SF_GET_BIT(g_uart_status.is_open, (1U << port)))
    {
        ret = SF_ERR_OPEN;
		goto failed;
    }
    	
    if (!g_serial[port])
    {
    	log_e("%s is null!\n", gp_uart_dev[port]);
    	return SF_ERR_PARA;
    }
    
	send_len = rt_device_write(g_serial[port], 0, p_buf, len);
	return send_len;

failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;	
}


/**
* @brief		串口接收 内部函数 供中断使用 
* @param		[in] dev 串口操作句柄  
* @param		[in] size 接收数据大小     
* @return		执行结果
* @retval		RT_EOK 成功     
* @retval		RT_EIO 失败   
* @pre			执行hal_uart_open后执行才有效。
*/
static rt_err_t uart_rx(rt_device_t dev, rt_size_t size)
{
	int i;
	for (i = 0; i < UART_MAX_NUM; i++)
	{
		if (g_serial[i] == dev)
		{
			if (g_uart_cb[i].rx_cb)
				g_uart_cb[i].rx_cb(i, size);
		}
	}
	
    return RT_EOK;
}


/**
* @brief		串口发送 内部函数 供中断使用 
* @param		[in] dev 串口操作句柄  
* @param		[in] size 接收数据大小     
* @return		执行结果
* @retval		RT_EOK 成功     
* @retval		RT_EIO 失败   
* @pre			执行hal_uart_open后执行才有效。
*/
static rt_err_t uart_tx(rt_device_t dev, void *p_buf)
{
	int i;
	for (i = 0; i < UART_MAX_NUM; i++)
	{
		if (g_serial[i] == dev)
		{
			if (g_uart_cb[i].tx_cb)
				g_uart_cb[i].tx_cb(i, 0);
		}
	}
	
    return RT_EOK;
}



/**
* @brief		配置串口中断函数  
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @param		[in] p_tx_fcallback 发送中断回调(预留,暂不支持)
* @param		[in] p_rx_fcallback 接收中断回调    
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @pre			执行hal_uart_open后执行才有效。
* @warning 		rx_cb tx_cb至少有一个为非空 
*/
int32_t hal_uart_set_irq(uint32_t port, irq_uart_callback p_tx_fcallback, irq_uart_callback p_rx_fcallback)
{
	int32_t ret;
	
	// param check
	if ((port >= UART_MAX_NUM) || ((NULL == p_tx_fcallback) && (NULL == p_rx_fcallback))) 
	{
		ret = SF_ERR_PARA;
		goto failed;
	}
	// if uart is closed, return failed
	if (!SF_GET_BIT(g_uart_status.is_open, (1U << port)))
    {
        ret = SF_ERR_OPEN;
		goto failed;
    }
	
	if (p_rx_fcallback)
	{
		g_uart_cb[port].rx_cb = p_rx_fcallback;
		rt_device_set_rx_indicate(g_serial[port], uart_rx);
	}
    
	if (p_tx_fcallback)
	{
		g_uart_cb[port].tx_cb = p_tx_fcallback;
		rt_device_set_tx_complete(g_serial[port], uart_tx);
	}
	return SF_OK;

failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;	
}

/**
* @brief		释放串口中断
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			执行hal_uart_open后执行才有效。
*/
int32_t hal_uart_free_irq(uint32_t port)
{	
	int32_t ret;

	// param check
	if (port >= UART_MAX_NUM)
	{
		ret = SF_ERR_PARA;
		goto failed;
	}
	// if uart is closed, return failed
	if (!SF_GET_BIT(g_uart_status.is_open, (1U << port)))
    {
        ret = SF_ERR_OPEN;
		goto failed;
    }
	
    if (!g_serial[port])
    {
    	log_e("%s is null!\n", gp_uart_dev[port]);
    	return SF_ERR_NO_OBJECT;
    }
	
	rt_device_set_rx_indicate(g_serial[port], NULL);
	rt_device_set_tx_complete(g_serial[port], NULL);
	return SF_OK;
failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;	
}


/**
* @brief		扩展功能 
* @param		[in] port 虚拟串口端口号
* -# HAL_UART1 - 0x00  
* -# HAL_UART2 - 0x01
* -# HAL_UART3 - 0x02  
* -# HAL_UART4 - 0x03  
* -# HAL_UART5 - 0x04    
* -# HAL_UART6 - 0x05
* -# HAL_UART7 - 0x06
* @param		[in] cmd 控制命令  
* @param		[in] p_arg 控制参数   
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
*/
int32_t hal_uart_ioctl(uint32_t port, uint8_t cmd, void* p_arg)
{
	
	return SF_OK;
}

/**
* @brief        UART_HAL功能样例
* @param        argv 功能参数
* @return       返回结果
* @retval         SF_OK 成功
* @retval         HAL_EIO 失败
*/
#ifdef RT_USING_FINSH
#ifdef RT_USING_FINSH_DEBUG
#ifdef BSP_USING_UART 

uint32_t g_tx_flag, g_rx_flag = false;
static void uart_rx_callback(uint32_t tim_no, uint32_t size)
{
	g_rx_flag = true;
}


#include "osif.h"
uint32_t rcv_total = 0;
static int hal_uart_sample(int argc, char *argv[])
{
	#define  UART_BUFF_SIZE	  256
	uint8_t  uart_send_buf[] = {"0123456789\r\n"};
	uint8_t  uart_rcv_buf[256]  = {0};
	char 	*uart_id = argv[1];
	int32_t  port, rcv_len;
	hal_uart_conf_t uart_config = 
	{
		.baud = 1000000,  				           
		.size = HAL_UART_8B,   	 		         
		.stop = HAL_UART_STOP1B,
		.par  = HAL_UART_PARNON,
		.flow = HAL_UART_HWFLOW_OFF,
		.buffsize = UART_BUFF_SIZE,
	};

	port = atoi(uart_id);
	hal_uart_init();

	if(SF_OK != hal_uart_open(port))
	{
        return -1;
	}
	if(SF_OK != hal_uart_setup(port, &uart_config))
	{
        return -1;
	}
	
	hal_uart_set_irq(port, NULL, uart_rx_callback);
	
	while(1)
	{
		/* 向串口写入一段固定的测试数据 */
		if(true == g_rx_flag)
		{
			g_rx_flag = false;
			memset(uart_rcv_buf, 0x00, sizeof(uart_rcv_buf));
			rcv_len = hal_uart_read(port, uart_rcv_buf, UART_BUFF_SIZE);
			if(0 < rcv_len)
			{
                rcv_total += rcv_len;
				//rt_kprintf("%s", uart_rcv_buf);	
                hal_uart_write(port, uart_send_buf, sizeof(uart_send_buf));	
			}
			//os_delay(os_tick_from_millisecond(1));	
		}
	}
}

#endif
MSH_CMD_EXPORT(hal_uart_sample, hal_gpio_sample <1>);
#endif
#endif









