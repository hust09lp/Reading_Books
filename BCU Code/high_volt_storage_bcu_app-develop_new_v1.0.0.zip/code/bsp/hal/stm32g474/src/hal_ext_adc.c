#include <rtthread.h>
#include <stdlib.h>
#include <string.h>
#include "hal_ext_adc.h"
#include "hal_ext_adc_ads1115_comm.h"
#include "osif.h"
#include "log.h"
#include "sofar_errors.h"

// 采样通道
typedef enum
{
    ADS_VOLT_CHANNEL_1 = 0,     //B端电压
    ADS_VOLT_CHANNEL_2,         //P端电压
    ADS_VOLT_CHANNEL_3,         //绝缘阻抗值
    ADS_RSV,                    //预留（故实际不去采）
    ADS_CHANNEL_NUM = ADS_RSV,
} ads_collect_channel_list_e;

// 采样类型枚举
typedef enum
{
    ADS_VOLT_TYPE = 0,
    ADS_CURR_TYPE,
    ADS_COLLECT_DATA_TYPE_NUM,
} ads_collect_type_list_e;

// 片外ads采样步骤枚举
typedef enum
{
    EXT_ADS_SAMPLE_START = 0,
    EXT_ADS_SAMPLE_COLLECT_DATA,
    EXT_ADS_SAMPLE_SWITCH_CHANNEL,
    EXT_ADS_SAMPLE_DELAY,
    EXT_ADS_SAMPLE_ERR,
    EXT_ADS_SAMPLE_END,
    EXT_ADS_SAMPLE_STATE_NUM,
} hal_ext_ads_collect_stage_e;

// 配置寄存器设置
#define ADS1115_CONFIG_REG(mux, pga, mode, dr) (ADS_CONFIG_OS_CONV_START | (mux) | (pga) | (mode) | (dr) | ADS_CONFIG_COMP_QUE_DISABLE)
#define ADS1115_CONFIG_REG_CHANNEL_OFFSET(channel) ((uint16_t)(channel) << 12)
#define ADS1115_SAMPLE_TIMES                   (1)  // 采样次数
#define NO_NEED_CHANGE_CHANNEL                 (-1) // 无需切换通道
#define EXT_ADS_ABNORMAL_TIMES                 (10) // ADS芯片异常
// 全局变量
static uint16_t g_config_reg_comm = {ADS_CONFIG_REG_DEFAULT};  // 配置寄存器数据
static int16_t g_ads_collect_data[HAL_EXT_ADS_LIST_NUM] = {0};     // 码值获取
static rt_bool_t g_ext_ads_start = RT_FALSE;
static rt_bool_t g_ext_adc_stop_ctrl = RT_FALSE;       // 控制停止片外adc采样
static ads_collect_channel_list_e g_ext_ads_channel_now = ADS_CHANNEL_NUM; // 初始值,表示通道未初始化
static uint32_t g_ads_sample_err_cnt = 0;
static hal_ext_ads_collect_stage_e g_ext_ads_sample_state = EXT_ADS_SAMPLE_START; // 片外采样状态

// debug
#ifdef HAL_EXT_ADS_DEBUG
static uint32_t g_debug_sample_time = ADS1115_SAMPLE_TIMES;
#endif

/**
 * @brief    设置片外ads采样状态
 * @param    [in] state 设置状态，参数参考hal_ext_ads_collect_stage_e
 * @return   执行结果(void)
 * @pre      不可重入函数
 */
void hal_ext_ads_sample_state_set(hal_ext_ads_collect_stage_e state)
{
    if (state >= EXT_ADS_SAMPLE_STATE_NUM || state == g_ext_ads_sample_state)
    {
        return;
    }
    g_ext_ads_sample_state = state;
}

/**
 * @brief    片外ads转换前延迟
 * @param    [in] ext_ads_no 虚拟片外ads端口号    
 * @return   执行结果(void)
 * @pre      执行hal_ext_ads_config后执行才有效，默认加1ms保证单次转换时激活预留多的时间
 */
void hal_ext_ads_before_conversion_read_comm_delay(void)
{
    uint16_t config_dr = g_config_reg_comm & ADS_CONFIG_REG_DR_MASK;
    switch (config_dr)
    {
         case ADS_CONFIG_DR_8SPS:
             rt_thread_mdelay(125 + 1);   // 延迟时间 1000/x SPS (ms), 例子：1000/8=125ms
             break;
         case ADS_CONFIG_DR_16SPS:
             rt_thread_mdelay(62 + 1);
             break;
         case ADS_CONFIG_DR_32SPS:
             rt_thread_mdelay(31 + 1);
             break;
         case ADS_CONFIG_DR_64SPS:
             rt_thread_mdelay(15 + 1);
             break;
         case ADS_CONFIG_DR_128SPS:
             rt_thread_mdelay(7 + 1);
             break;
         case ADS_CONFIG_DR_250SPS:
             rt_thread_mdelay(4 + 1);
             break;
         case ADS_CONFIG_DR_475SPS:
             rt_thread_mdelay(2 + 1);
             break;
         case ADS_CONFIG_DR_860SPS:
             rt_thread_mdelay(1 + 1);
             break;
         default:
             break;
    }
}

/**
* @brief    ads参考量程获取
* @param    [in] void
* @return    返回一个码值对应电压值，单位mV
* @return    <= 0, 错误码
* @pre      执行hal_ext_ads_config后执行才有效 
*/
uint32_t hal_ext_ads_ref_volt_range_get(void)
{
    uint16_t config_pga = g_config_reg_comm & ADS_CONFIG_REG_PGA_MASK;
    int32_t volt_value;
    switch (config_pga)
    {
        case ADS_CONFIG_PGA_6P144V:
            volt_value = 6144;
            break;
        case ADS_CONFIG_PGA_4P096V:
            volt_value = 4096;
            break;
        case ADS_CONFIG_PGA_2P048V:
            volt_value = 2048;
            break;
        case ADS_CONFIG_PGA_1P024V:
            volt_value = 1024;
            break;
        case ADS_CONFIG_PGA_0P512V:
            volt_value = 512;
            break;
        case ADS_CONFIG_PGA_0P256V:
            volt_value = 256;
            break;
        default:
            volt_value = 0;
            break;
    }
    return volt_value;
}

/**
* @brief    ads转换码值单位
* @param    [in] ads码值
* @return    返回一个码值对应电压值，单位±0.1mV
* @return    <= 0, 错误码
* @pre      执行hal_ext_ads_config后执行才有效 
*/
int32_t hal_ext_ads1115_conversion_volt(int16_t ads_code)
{
    int32_t volt = hal_ext_ads_ref_volt_range_get() * ads_code * 10 / 32768;
    return volt;
}

/**
* @brief    ads1115切换输入通道
* @param    [in] ext_ads_no 虚拟ads端口号
* @param    [in] channel (范围0-3) 意义参考
* @return    执行结果
* @retval    = 0 设置成功
* @retval    < 0 失败原因
* @pre      执行hal_ext_ads1115_open后执行才有效 
*/
int32_t hal_ext_ads_input_channel_comm_set(ads_collect_channel_list_e channel)
{
    if (channel >= ADS_CHANNEL_NUM)
    {
        log_e("ads channel err\n");
        return SF_ERR_PARA;
    }
    uint16_t config = g_config_reg_comm;
    config &= ~(ADS_CONFIG_REG_MUX_MASK);
    config |= ADS1115_CONFIG_REG_CHANNEL_OFFSET((channel + 4));  // 当前采样通道AIN0_GND, AIN1_GND, AIN2_GND,AIN3_GND,所以要偏移4
    int32_t ret = SF_OK;
    for (int32_t ads_no = EXT_ADS_DEV_1; ads_no < EXT_ADS_DEV_NUM; ads_no++)
    {
         ret = hal_ads_single_register_write(ads_no, ADS_CONFIG_REG_ADDRESS, config);
         if (SF_OK != ret)
         {
            //  rt_kprintf("ads_config%d fail%d\n", ads_no, ret);
             return ret;
         }
    }
    g_config_reg_comm = config;
    g_ext_ads_channel_now = channel;
    return SF_OK;
}

/**
 * @brief    读取码值
 * @param    [in] channel (0~3)
 * @return    void
 * @pre      执行hal_ext_ads_config后执行才有效 
 */
void hal_ext_ads_read_code(uint16_t channel)
{
    if (channel >= ADS_CHANNEL_NUM)
    {
        return;
    }
    int32_t ads_code_sum;
    int32_t ads_read_time;
    int32_t min_code_ads;
    int32_t max_code_ads;
    int16_t reg_value;
    int ret;
    for (uint8_t ads_no = EXT_ADS_DEV_1; ads_no < EXT_ADS_DEV_NUM; ads_no++)
    {
         ads_code_sum = 0;
         ads_read_time = 0;
         min_code_ads = 0x7FFF;
         max_code_ads = 0;
         reg_value = 0;
         for (uint8_t sample_times = 0; sample_times < g_debug_sample_time; sample_times++)
         {
             ret = hal_single_register_read(ads_no, ADS_CONVERSION_REG_ADDRESS, (uint16_t*)&reg_value);
             if (SF_OK != ret)
             {
                 // rt_kprintf("ads_read_code%d fail%d\n", ads_no, ret);
             }
             else
             {
                 if (reg_value > max_code_ads)
                 {
                     max_code_ads = (int32_t)reg_value;
                 }
                 if (reg_value < min_code_ads)
                 {
                     min_code_ads = (int32_t)reg_value;
                 }
                 ads_code_sum += (int32_t)reg_value;
                 ads_read_time++;
//                 if (ads_code_sum < 0)
//                 {
//                     ads_code_sum = 0;  // adc1115会采样到<0(65535)，当前我们只用到0-0x7FFF
//                 }
             }
         }
         if (2 < ads_read_time) // 需要成功获取大于两次
         {
             g_ads_collect_data[channel + ads_no * ADS_CHANNEL_NUM] = 
                 (int16_t)((ads_code_sum - max_code_ads - min_code_ads + (ads_read_time - 2) / 2) / (ads_read_time - 2)); // 四舍五入
         }
         else
         {
             g_ads_collect_data[channel + ads_no * ADS_CHANNEL_NUM] = (int16_t)reg_value;
         }
    }
}

/**
 * @brief     片外ads采样所有通道
 * @param     [in] 采样数据类型 (参考ads_collect_type_list_e)
 * @return    [out] void
 * @pre       执行hal_ext_ads_init后执行才有效 
 */
void hal_ext_ads_collect_code(void)
{
    int32_t ret;
    
    for (uint16_t channel_num = ADS_VOLT_CHANNEL_1; channel_num < ADS_CHANNEL_NUM; channel_num++)
    {
        ret = hal_ext_ads_input_channel_comm_set((ads_collect_channel_list_e)channel_num);
        if (SF_OK != ret)
        {
            rt_kprintf("ads_channel fail%d\n", ret);
            continue;
        }
        hal_ext_ads_before_conversion_read_comm_delay();
        rt_thread_mdelay(2);
        hal_ext_ads_read_code(channel_num);
    }
}

/**
 * @brief     片外adc初始化
 * @return    SF_OK 初始化成功
 * @retval    其他返回值 初始化失败; 不要反复初始化
 */
int32_t hal_ext_ads_init(void)
{
    int32_t ret = hal_ext_ads1115_init();
    if (SF_OK != ret)
    {
        rt_kprintf("hal_ads_inite fail%d\n",ret);
        return ret;
    }
    for (int32_t ads_no = EXT_ADS_DEV_1; ads_no < EXT_ADS_DEV_NUM; ads_no++)
    {
         ret = hal_ext_ads1115_open(ads_no);
         if (SF_OK != ret)
         {
             rt_kprintf("ads_open%d fail%d\n", ads_no, ret);
             return ret;
         }
    }

    (void)memset((void *)&g_ads_collect_data, 0xFF, sizeof(g_ads_collect_data));
    g_ext_ads_start = RT_FALSE;
    g_config_reg_comm = ADS_CONFIG_REG_DEFAULT;
    g_ads_sample_err_cnt = 0;
    g_ext_adc_stop_ctrl = RT_FALSE;
    return SF_OK;
}

/**
 * @brief     片外adc采样功能配置操作处理
 * @param     [in] void
 * @return    执行结果
 * @retval    SF_OK 设置成功  
 * @retval    < 0 失败原因    
 * @pre       执行hal_ext_ads_init后执行才有效 
 */
int32_t hal_ext_ads_config_deal(void)
{
    // 搜集数据前，必须先设置配置寄存器，默认设置AIN0_GND采样通道，量程6.144V，连续采样，采样频率250SPS
    uint16_t ads1115_config_reg = ADS1115_CONFIG_REG(ADS_CONFIG_MUX_AIN0_GND, ADS_CONFIG_PGA_6P144V, ADS_CONFIG_MODE_SS, ADS_CONFIG_DR_250SPS);
    int32_t ret;
    for (int32_t ads_no = EXT_ADS_DEV_1; ads_no < EXT_ADS_DEV_NUM; ads_no++)
    {
         ret = hal_ads_single_register_write(ads_no, ADS_CONFIG_REG_ADDRESS, ads1115_config_reg);
         if (SF_OK != ret)
         {
             // rt_kprintf("ads_config%d fail%d\n", ads_no, ret);
             return ret;
         }
    }
    g_config_reg_comm = ads1115_config_reg;
    g_ext_ads_start = RT_TRUE;
    g_ext_ads_channel_now = ADS_VOLT_CHANNEL_1; // 由于设置ADS_CONFIG_MUX_AIN0_GND，对应通道电压1
    // 初始化，采样三次过滤数据
    hal_ext_ads_collect_code();
    hal_ext_ads_collect_code();
    hal_ext_ads_collect_code();
    rt_kprintf("ext adc_config ok\n");
    return SF_OK;
}

/**
 * @brief     片外adc采样功能配置
 * @param     [in] void
 * @return    执行结果
 * @retval    SF_OK 设置成功  
 * @retval    < 0 失败原因    
 * @pre       执行hal_ext_ads_init后执行才有效 
 */
int32_t hal_ext_ads_config(void)
{
    if (RT_TRUE == g_ext_ads_start)
    {
        return SF_OK;
    }
    int32_t ret = hal_ext_ads_config_deal();
    return ret;
}

/**
 * @brief     片外adc 启动单词采样
 * @param     [in] void
 * @return    执行结果
 * @retval    SF_OK 设置成功  
 * @retval    < 0 失败原因    
 * @pre       执行hal_ext_ads_init后执行才有效 
 */
int32_t hal_ext_ads_single_sample_restart(void)
{
    uint16_t config = g_config_reg_comm;
    config |= ADS_CONFIG_OS_CONV_START;
    int32_t ret = SF_OK;
    for (int32_t ads_no = EXT_ADS_DEV_1; ads_no < EXT_ADS_DEV_NUM; ads_no++)
    {
         ret = hal_ads_single_register_write(ads_no, ADS_CONFIG_REG_ADDRESS, config);
         if (SF_OK != ret)
         {
             return ret;
         }
    }
    g_config_reg_comm = config;
    return SF_OK;
}

/**
 * @brief     片外adc采样失败处理
 * @param     [in] void
 * @return    [out] void
 * @pre       采样芯片异常
 */
void hal_ext_adcc_err_deal(void)
{
    // 数据初始化
    (void)memset((void *)&g_ads_collect_data, 0xFF, sizeof(g_ads_collect_data)); // 默认全0xff
    g_config_reg_comm = ADS_CONFIG_REG_DEFAULT;
    int32_t ret = hal_ext_ads_config_deal();   // 配置ads寄存器
    if (SF_OK == ret)
    {
        hal_ext_ads_sample_state_set(EXT_ADS_SAMPLE_START);
    }
    rt_thread_mdelay(200);
}

/**
 * @brief     片外ads采样
 * @param     [in] void
 * @return    [out] void
 * @pre       执行hal_ext_ads_config后执行才有效，不可重入函数
 * @pre       整个采样的步骤，所有通道
 */
void hal_ext_ads_collect(void)
{
    if (RT_TRUE != g_ext_ads_start)
    {
        g_ads_sample_err_cnt = 0;
        hal_ext_ads_sample_state_set(EXT_ADS_SAMPLE_START);
       (void)memset((void *)&g_ads_collect_data, 0xFF, sizeof(g_ads_collect_data));
        if (RT_TRUE != g_ext_adc_stop_ctrl)
        {
            (void)hal_ext_ads_config_deal();   // 配置ads寄存器
        }
        rt_thread_mdelay(200);
        return;
    }
    int32_t ret;
    static ads_collect_channel_list_e target_channel = ADS_CHANNEL_NUM;
    switch ((uint16_t)g_ext_ads_sample_state)
    {
         case EXT_ADS_SAMPLE_START:
             target_channel = ADS_VOLT_CHANNEL_2;   //初始化的时候已经是设置默认读通道1，所以这里从通道2开始
             hal_ext_ads_sample_state_set(EXT_ADS_SAMPLE_COLLECT_DATA);
             break;
         case EXT_ADS_SAMPLE_COLLECT_DATA:
             hal_ext_ads_read_code(g_ext_ads_channel_now);
             hal_ext_ads_sample_state_set(EXT_ADS_SAMPLE_SWITCH_CHANNEL);
             break;
         case EXT_ADS_SAMPLE_SWITCH_CHANNEL:
             ret = hal_ext_ads_input_channel_comm_set(target_channel);
             if (SF_OK == ret)
             {
                 hal_ext_ads_sample_state_set(EXT_ADS_SAMPLE_DELAY);
                 if(++target_channel >= ADS_CHANNEL_NUM)
                 {
                     target_channel = ADS_VOLT_CHANNEL_1;
                 }
             }
             else
             {
                 if (g_ads_sample_err_cnt++ > EXT_ADS_ABNORMAL_TIMES)
                 {
                     hal_ext_ads_sample_state_set(EXT_ADS_SAMPLE_ERR);
                     rt_kprintf("ext_adc_sample err\r\n");
                 }
             }
             break;
         case EXT_ADS_SAMPLE_DELAY:
             g_ads_sample_err_cnt = 0;
             hal_ext_ads_before_conversion_read_comm_delay();
             hal_ext_ads_sample_state_set(EXT_ADS_SAMPLE_COLLECT_DATA);
             break;
         case EXT_ADS_SAMPLE_ERR:
             hal_ext_adcc_err_deal();
             break;
         default:
             hal_ext_ads_sample_state_set(EXT_ADS_SAMPLE_START);
             break;
    }
}

/**
 * @brief    启动ads1115采样启动
 * @param    [in] void 
 * @return    执行结果
 * @retval    SF_OK(0) 成功
 * @retval    SF_ERR_PARA(<0) 失败   
 * @pre      执行hal_ext_ads1115_start后执行才有效，连续采样不用调用；单次采样需要每次都要调用此函数。
 */
int32_t hal_ext_ads_start(void)
{
    if (RT_TRUE == g_ext_ads_start)
    {
        rt_kprintf("g_ext_ads_start already\r\n");
        return SF_OK;
    }
    int32_t ret = hal_ext_ads_init();
    if (SF_OK != ret)
    {
        rt_kprintf("hal_ext_ads_init err%d\r\n", ret);
        return ret;
    }
    ret = hal_ext_ads_config();
    if (SF_OK != ret)
    {
        rt_kprintf("hal_ext_ads_config err%d\r\n", ret);
        return ret;
    }
    g_ext_adc_stop_ctrl = RT_FALSE;
    return SF_OK;
}


/**
 * @brief    停止ads1115(设置单词采样)
 * @param    [in] void
 * @return    执行结果
 * @retval    SF_OK(0) 成功
 * @retval    SF_ERR_PARA(<0) 失败  
 * @pre      接口未使用，默认返回SF_OK
 */
int32_t hal_ext_ads_stop(void)
{
    g_ext_ads_start = RT_FALSE;
    g_ext_adc_stop_ctrl = RT_TRUE;
    return SF_OK;
}

/**
 * @brief     获取ads片外芯片异常标志
 * @param     [in] void 
 * @return    执行结果
 * @retval    RT_TRUE(1)    异常
 * @retval    RT_FALSE(0)   正常
 * @pre       执行hal_ext_ads1115_start后执行才有效，连续采样不用调用；单次采样需要每次都要调用此函数。
 */
int32_t hal_ext_ads_err_state_get(void)
{
    if (g_ext_ads_start == RT_FALSE)
    {
        return SF_ERR_OPEN;
    }
    else if (g_ext_ads_sample_state == EXT_ADS_SAMPLE_ERR)
    {
        return SF_ERR_WR;
    }
    else
    {
        return SF_OK;
    }
}

/**
 * @brief    ads1115获取采样码值
 * @param    [in] channel  输入hal_ext_ads_code_list_e枚举
 * @param    [in] p_value  获取数据指针
 * @return    执行结果
 * @retval    ==0 读取成功
 * @retval    < 0 失败原因
 * @pre      执行hal_ext_ads1115_open后执行才有效, 
 * @pre      此函数包括使能单次采样，hal_ext_ads_collect_data();
 */
int32_t hal_ext_ads_data_read(uint32_t channel, int16_t *p_value)
{
    if (RT_FALSE == g_ext_ads_start)
    {
        return SF_ERR_OPEN;
    }
    if (NULL == p_value || channel >= HAL_EXT_ADS_LIST_NUM)
    {
        return SF_ERR_NO_OBJECT;
    }
    // 当处于采样异常时，无法获取采样码值（片外码值默认写0xFFFF），APP层sample.c默认0xFFFF为无效值
    // 当前通过此函数判断片外adc时否正常
    if (g_ext_ads_sample_state == EXT_ADS_SAMPLE_ERR)
    {
        return SF_ERR_RD;
    }
    *p_value = g_ads_collect_data[channel];
    return SF_OK;
}

/**
 * @brief                片外ads采样任务
 * @param                [in]void *argument
 * @return               返回结果空
 * @retval               [out]无
 * @warning              无
 */
void ext_ads_sample_thread(void* argument)
{   
    hal_ext_ads_init();     // 初始化片外ads
    hal_ext_ads_config();   // 配置ads寄存器

    while (1)
    {
        hal_ext_ads_collect(); // 片外ads数据获取，内部有delay语句
    }
}

/**
 * @brief        ads1115_hal功能样例
 * @param        argv 功能参数
 * @return       返回结果
 * @retval    SF_OK(0) 成功
 * @retval    HAL_EIO(<0) 失败
 */
#ifdef RT_USING_FINSH
//#ifdef RT_USING_FINSH_DEBUG

static int test_ext_ads_sample(int argc, char *p_argv[])
{
    if (argc > 1)
    {
        if (0 == strcmp(p_argv[1], "init"))
        {
            hal_ext_ads_init();
            hal_ext_ads_config();
        }
        else if (0 == strcmp(p_argv[1], "start"))
        {
            hal_ext_ads_start();
        }
        else if (0 == strcmp(p_argv[1], "stop"))
        {
            hal_ext_ads_stop();
        }
        else if (0 == strcmp(p_argv[1], "collect"))
        {
            while(g_ext_ads_sample_state != EXT_ADS_SAMPLE_END)
            {
                hal_ext_ads_collect();
            }
            int32_t volt = 0;
            for (uint8_t ads_num = 0; ads_num < HAL_EXT_ADS_LIST_NUM; ads_num++)
            {
                volt = hal_ext_ads1115_conversion_volt(g_ads_collect_data[ads_num]);
                rt_kprintf("volt[%d] = %ld\r\n", ads_num, volt);
            }
        }
        else if (0 == strcmp(p_argv[1], "volt"))
        {
            int32_t volt = 0;
            for (uint8_t ads_num = 0; ads_num < HAL_EXT_ADS_LIST_NUM; ads_num++)
            {
                volt = hal_ext_ads1115_conversion_volt(g_ads_collect_data[ads_num]);
                rt_kprintf("volt[%d] = %ld  ad = %d\r\n", ads_num, volt, g_ads_collect_data[ads_num]);
            }
        }
        else if (strcmp(p_argv[1], "read") == 0)
        {
            uint32_t ads_no = atoi(p_argv[2]);
            uint8_t reg_addr = atoi(p_argv[3]);
            uint16_t reg_value = 0;
            int32_t ret = hal_single_register_read(ads_no, reg_addr, &reg_value);
            if (ret < 0)
            {
                rt_kprintf("test ext_ads read %d, err%d\r\n", ads_no, ret);
            }
            else 
            {
                rt_kprintf("test ext_adsNO_%d, data0x%x(%d), reg:0x%x(%d)\r\n", ads_no, reg_value, reg_value, g_config_reg_comm, g_config_reg_comm);
            }
        }
        else if (strcmp(p_argv[1], "config") == 0)
        {
            uint32_t ads_no = atoi(p_argv[2]);
            uint16_t pga = atoi(p_argv[3]) << 9;    // pga偏移9位
            uint16_t mode = atoi(p_argv[4]) << 8;   // mode偏移8位
            uint16_t dr = atoi(p_argv[5]) << 5;     // dr偏移5位
            uint16_t mux = atoi(p_argv[6]) << 12;   // mux偏移12位
            uint16_t config = ADS1115_CONFIG_REG(mux, pga, mode, dr);
            int32_t ret = hal_ads_single_register_write(ads_no, ADS_CONFIG_REG_ADDRESS, config);
            if (ret < 0)
            {
                rt_kprintf("test ext_ads config %d, err%d\r\n", ads_no, ret);
            }
        }
        else if (strcmp(p_argv[1], "delay") == 0)
        {
            g_debug_sample_time  = atoi(p_argv[3]);
        }
    } 
    return SF_OK;    
}
MSH_CMD_EXPORT(test_ext_ads_sample, test_ext_ads_sample <write/read xxx(0-3)>);
//#endif
#endif
