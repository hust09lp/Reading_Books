
#include <string.h>
#include <rtthread.h>
#include "osif.h"
#include "hal_public.h"
#include "afe_bq79616_comm.h"
#include "afe_bq79616.h"
#include "hal_afe.h"

#define BQ79616_ADDR                    1

#define RETRY_NUM                       5

#define BQ79616_SAMP_VOLT		        5000
#define BQ79616_REF_VOLT		        5000
#define BQ79616_TEMP_SAMPLE_RES         10

#define CONFIG_TAB_LEN                  (sizeof(g_config_buf) / sizeof(bq79616_config_reg_t))
#define TEMP_TABLE_SIZE                 (sizeof(ntc_res_tab) / sizeof(uint16_t))
	
#define BQ79616_READ_MS					1 // ms

#define BQ79616_READ_MAX_DAT_LEN		(16 * 2 + 6) // 16节电芯数据 * 占2个字节 + 6字节帧数据
#define BQ79616_READ_BUF_LEN			(BQ79616_READ_MAX_DAT_LEN * TOTALBOARDS)				

#define BQ79616_REG_CONFIG(addr, val, target_val, len)        {                                    \
                                                                   (val),                          \
                                                                   (target_val),                   \
                                                                   (addr),                         \
                                                                   BQ79616_ADDR,                   \
                                                                   (len),                          \
                                                                   FRMWRT_SGL_W,                   \
                                                              }
#ifdef __cplusplus
extern "C" {
#endif

typedef struct
{
    uint64_t val;           // 寄存器写入值
    uint64_t target_val;    // 写入后目标值，用于反读判断写入成功与否
    uint16_t addr;          // 寄存器地址
    uint8_t dev_id;         // 设备ID
    uint8_t write_len;      // 写入长度
    uint8_t operate_type;   // 操作类型
}bq79616_config_reg_t;

static bq79616_config_reg_t g_config_buf[] = 
{
    BQ79616_REG_CONFIG(FAULT_MSK2,     0x40,    0x40,    1), // MASK CUST_CRC SO CONFIG CHANGES DON'T FLAG A FAULT
    BQ79616_REG_CONFIG(FAULT_RST1,     0xFFFF,  0x0000,  2), // CLEAR ALL FAULTS
    BQ79616_REG_CONFIG(CONTROL2,       0x01,    0x01,    1), // 设置温度采集用参考电压TSREF
    BQ79616_REG_CONFIG(GPIO_CONF1,     0x12,    0x12,    1), // 设置GPIO1 为 ADC only input
    BQ79616_REG_CONFIG(GPIO_CONF2,     0x12,    0x12,    1), // 设置GPIO2 为 ADC only input
    BQ79616_REG_CONFIG(GPIO_CONF3,     0x12,    0x12,    1), // 设置GPIO3 为 ADC only input
	BQ79616_REG_CONFIG(GPIO_CONF4,     0x12,    0x12,    1), // 设置GPIO4 为 ADC only input		//diff_modify
    BQ79616_REG_CONFIG(ACTIVE_CELL,    0x0A,    0x0A,    1), // 有效电芯设置成16串
    BQ79616_REG_CONFIG(ADC_CONF1,      0x04,    0x04,    1), // 111Hz LPF_Vcell (9ms average)
    BQ79616_REG_CONFIG(ADC_CTRL1,      0x0E,    0x0A,    1), // continuous run, LPF enabled and MAIN_GO
    BQ79616_REG_CONFIG(ADC_CTRL3,      0x06,    0x02,    1), // continuous run, AUX_GO
    BQ79616_REG_CONFIG(CB_CELL16_CTRL, 0x00,    0x00,    8), // 9-16节电芯停止均衡
    BQ79616_REG_CONFIG(CB_CELL8_CTRL,  0x00,    0x00,    8), // 1-8节电芯停止均衡
	BQ79616_REG_CONFIG(BAL_CTRL1,      0x00,    0x00,    1), // 奇偶转换时间 10s
    BQ79616_REG_CONFIG(BAL_CTRL2,      0x43,    0x41,    1), // 设置自动均衡且暂停均衡
};

const uint16_t ntc_res_tab[] =
{
    23315, 23314, 21904, 20590, 19365, 18223, 17156, 16160, 15229, 14359, 13546, //-40 ~ -30
    12784, 12071, 11403, 10777, 10190, 9640,  9123,  8637,  8181,  7753,         //-29 ~ -20
    7350,  6971,  6614,  6278,  5961,  5663,  5382,  5116,  4866,  4630,         //-19 ~ -10
    4406,  4195,  3996,  3808,  3629,  3461,  3301,  3150,  3007,  2871,         //- 9 ~   0
    2742,  2620,  2504,  2394,  2290,  2191,  2097,  2007,  1922,  1842,         //  1 ~ 10
    1765,  1691,  1622,  1555,  1492,  1432,  1374,  1320,  1267,  1218,         // 11 ~ 20
    1170,  1125,  1081,  1040,  1000,  963,   927,   892,   859,   827,          // 21 ~ 30
    797,   768,   741,   714,   689,   664,   641,   618,   597,   576,          // 31 ~ 40
    557,   538,   519,   502,   485,   469,   454,   439,   424,   411,          // 41 ~ 50
    397,   385,   372,   361,   349,   338,   328,   318,   308,   299,          // 51 ~ 60
    290,   281,   272,   264,   256,   249,   242,   235,   228,   221,          // 61 ~ 70
    215,   209,   203,   197,   192,   186,   181,   176,   171,   167,          // 71 ~ 80
    162,   158,   154,   150,   146,   142,   138,   135,   131,   128,          // 81 ~ 90
    124,   121,   118,   115,   112,   110,   107,   104,   102,   99,           // 91 ~ 100
    97,    94,    92,    90,    88,    86,    84,    82,    80,    78,           //101 ~ 110
    76,    75,    73,    71,    70,    68,    67,    65,    64,    62,           //111 ~ 120
};

#if AFE_DEBUG_ENABLE
afe_collect_t g_afe_data = {0};
uint32_t g_balance_state = 0;
uint32_t g_balance_ctrl_flag = 0;
uint32_t g_write_counter = 0;
uint32_t g_write_fail_counter = 0;
uint32_t g_read_counter = 0;
uint32_t g_read_fail_counter = 0;
uint16_t g_cell_temp_res_buf[BMS_CELL_TEMP_NUM] = {0};
#else
static afe_collect_t g_afe_data = {0};
static uint32_t g_balance_state = 0;
static uint32_t g_balance_ctrl_flag = 0;
static uint16_t g_cell_temp_res_buf[BMS_CELL_TEMP_NUM] = {0};
#endif

static int32_t bq79616_write_single(bq79616_config_reg_t *val);
static int32_t bq79616_read_single( uint16_t addr, uint8_t *buf, uint8_t read_len, uint32_t delay_ms);

/****************************SDK********************************/
void hal_afe_collect_data_get(afe_collect_t *data)
{
	if (data == NULL)
	{
		return;
	}
    memcpy(data, &g_afe_data, sizeof(afe_collect_t));
}

void hal_afe_balance_state_get(uint32_t *state)
{
	if (state == NULL)
	{
		return;
	}
    *state = g_balance_state;
}

void hal_afe_balance_set(uint32_t enable_flag)
{
    g_balance_ctrl_flag = (enable_flag & 0x0000FFFF); // bq79616只支持16节电芯，多出电芯节数去除不做处理
}
/**************************************************************/

void bq79616_init(void)
{
    memset(&g_afe_data, 0, sizeof(afe_collect_t));
    g_balance_state = 0;
    g_balance_ctrl_flag = 0;
#if AFE_DEBUG_ENABLE
    g_write_counter = 0;
    g_write_fail_counter = 0;
    g_read_counter = 0;
    g_read_fail_counter = 0;
#endif
}

int32_t bq79616_config_init(void)
{
    uint8_t i; 
   
    for (i = 0; i < CONFIG_TAB_LEN; i++)
    {
        if (0 > bq79616_write_single(&g_config_buf[i]))
        {
            return -1;
        }
    }
    return 0;
}

static int32_t collect_cell_vol(void)
{
    uint8_t i;
    uint8_t response_frame[BQ79616_READ_BUF_LEN] = {0};
    uint8_t cell_cnt = 0;
    uint16_t temp_data;
    if(0 == bq79616_read_single(VCELL16_HI, response_frame, 16*2, BQ79616_READ_MS))
    {
    	for(i = 0; i < 32; i+=2)
    	{
    	    temp_data = (response_frame[i + READ_DATA_INDEX] << 8) | response_frame[i + READ_DATA_INDEX + 1];
    		cell_cnt = i/2;
    		if(cell_cnt < BMS_CELL_VOLT_NUM)
    		{
    			g_afe_data.cell_volt[BMS_CELL_VOLT_NUM - cell_cnt - 1] = temp_data * 19073 / 100000; // mV
    		}
    	}
        return 0;
    }
    return -1;
}

// 读取AD值，计算得到温度 unit: 0.1℃ 
static uint16_t res_transformar_tmp(uint16_t tmp)
{
	int16_t left  = 0;
	int16_t mid = 0;
	int16_t temp_data = 0;
	int16_t right = (TEMP_TABLE_SIZE - 1);

	while(left <= right)
	{ 
        mid = (left + right) / 2; 
        if(mid < 0)
        {
        	return 0;
        }
        if(ntc_res_tab[mid] == tmp)
        {
            mid *= 10;	//0.1摄氏度
            return (uint16_t)mid;
        } 
        else if(ntc_res_tab[mid] > tmp)//如果中间值偏大，将初端右移
        {
            left = mid + 1; 
        } 
        else //中间值偏小则终端左移
        {
            right = mid -1;
        }
	}
	
	if( (tmp >= ntc_res_tab[left]) && (left >= 1))
	{
		temp_data = (int16_t)(tmp - ntc_res_tab[left]) *10 / (ntc_res_tab[left-1] - ntc_res_tab[left]);
		(temp_data < 10)?(left =  10 * left - temp_data):(left *= 10);
	}
	else
	{
		left *= 10;	//0.1摄氏度
	}	
	
	return (uint16_t)left;
}

static int32_t collect_temp(void)
{
	uint8_t i;
    uint8_t response_frame[BQ79616_READ_BUF_LEN] = {0};
    uint8_t temp_cnt;
    uint16_t temp_data_16, res_val, temperature;
    uint32_t temp_data_32[2];
    if(0 == bq79616_read_single(GPIO1_HI, response_frame, 8*2, BQ79616_READ_MS))		//diff_modify	
    {
    	for(i = 0; i < 16; i+=2)	//diff_modify
    	{
    	    temp_data_16 = (response_frame[i + READ_DATA_INDEX] << 8) | response_frame[i + READ_DATA_INDEX + 1];
    		temp_cnt = i/2;
    		
    		temp_data_32[0] = (uint32_t)32768 * BQ79616_SAMP_VOLT/100 - (uint32_t)temp_data_16 * BQ79616_REF_VOLT/100;
    		temp_data_32[1] = (uint32_t)temp_data_16 * BQ79616_REF_VOLT/100 * BQ79616_TEMP_SAMPLE_RES;
    		if(0 != temp_data_32[0] )
    		{
    			res_val = (uint16_t)(temp_data_32[1] * 100 / temp_data_32[0]);
    		}
    		else
    		{
    			res_val = 0xFFFF;
    		}
    		temperature = res_transformar_tmp(res_val);
    		
    		if(temp_cnt < BMS_CELL_TEMP_NUM)
    		{
    			g_afe_data.cell_temp[temp_cnt] = temperature;
				g_cell_temp_res_buf[temp_cnt] = res_val;
    		}
//    		else if(temp_cnt < BMS_CELL_TEMP_NUM + BMS_BALANCE_TEMP_NUM)	//diff_modify
//    		{
//    			g_afe_data.balance_temp[temp_cnt - BMS_CELL_TEMP_NUM] = temperature;
//    		}
    	}
        return 0;
    }
    return -1;
}

uint16_t *get_cell_temp_res_val(void)
{
	return g_cell_temp_res_buf;
}

static int32_t collect_bat_vol(void)
{
    uint16_t temp_data;
    uint8_t response_frame[BQ79616_READ_BUF_LEN] = {0};
    if(0 == bq79616_read_single(AUX_BAT_HI, response_frame, 2, BQ79616_READ_MS))
    {
        temp_data = (response_frame[READ_DATA_INDEX] << 8) | response_frame[READ_DATA_INDEX + 1];
        //总压采集端口有二极管分压，其导通压降测量出来是0.3V
    	g_afe_data.batttery_volt = temp_data * 305 / 100 + 300; // 0.001V  
    	return 0;
    }
    return -1;
}

// val: 0->暂停全通道均衡， 1->解除暂停全通道均衡， 2->解除暂停全通道均衡且更新均衡计时
static int32_t start_stop_balance(uint8_t val)
{
    uint8_t response_frame[BQ79616_READ_BUF_LEN] = {0};
    
    bq79616_config_reg_t temp = BQ79616_REG_CONFIG(BAL_CTRL2, 0x41, 0x41, 1);

    if (0 == val) // 需要进行暂停均衡操作时，先读取状态
    {
        if (0 == bq79616_read_single(BAL_CTRL2, response_frame, 1, BQ79616_READ_MS))
        {
            if (response_frame[READ_DATA_INDEX] & 0x40)
            {
                return 0; //已暂停均衡，不做处理
            }
        }
    }
    if (0 != val) 
    {
        temp.val = 0x01;
        temp.target_val = 0x01;
        if (0 == g_balance_ctrl_flag) // 不需要进行均衡时，就不解除暂停均衡
        {
            return 0;
        }
        if(2 == val)
        {
            temp.val = 0x03;
        }
    }
    if (0 > bq79616_write_single(&temp))
	{
		return -1;
	}
    return 0;
}

int32_t bq79616_collect(void)
{
    int ret = 0;
    
    if (0 > start_stop_balance(0)) // 暂停全通道均衡
    {
        return -4;
    }
    
    if (0 > collect_temp())
    {
        ret = -2;
    }

    os_delay(os_tick_from_millisecond(8)); // 关闭均衡后延时一段时间待电压稳定再读取

    if (0 > collect_cell_vol())
    {
        ret = -1;
    }
   
    if (0 > collect_bat_vol())
    {
        ret = -3;
    }
	
	if (0 > start_stop_balance(1)) // 解除暂停全通道均衡
    {
        return -5;
    }
    
    return ret;
}

#define BALANCE_OVER_TIME	0x05ull // 硬件均衡时间： 10min
static void set_balance_bit(uint64_t *val_high, uint64_t *val_low)
{
    uint8_t i;
    for(i = 0; i < BMS_CELL_VOLT_NUM; i++)
	{
		if(g_balance_ctrl_flag & (1UL << i))
		{
			if(i < 8)
			{
			    *val_low |= (BALANCE_OVER_TIME << ((7 - i) * 8)); // 1 - 8节电芯均衡
			}
			else if(i < BMS_CELL_VOLT_NUM)
			{	
				*val_high |= (BALANCE_OVER_TIME << ((15 - i) * 8)); // 9 - 16节电芯均衡
			}
		}
	}
}

#define UPDATA_BALANCE_MS	 (10 * 60 * 1000)
// ctrl:  0->禁用均衡，1->启动均衡
int32_t bq79616_balance_ctrl(uint8_t ctrl)
{
	static uint32_t updata_balance_tick = 0;
    uint8_t i;
    bq79616_config_reg_t temp_buff[] = 
    {
		BQ79616_REG_CONFIG(CB_CELL16_CTRL, 0x00, 0x00, 8),
        BQ79616_REG_CONFIG(CB_CELL8_CTRL, 0x00, 0x00, 8),
    };

    if ((0 == ctrl) || (0 == g_balance_ctrl_flag))
    {
        if (0 > start_stop_balance(0)) // 关闭均衡
        {
            return -1;
        }
		g_balance_state = 0;
        return 0;
    }
    set_balance_bit( &temp_buff[0].val,  &temp_buff[1].val); // 更新寄存器值
	
	// 周期10min更新配置均衡相关的寄存器
	if (false == hal_is_tick_over(updata_balance_tick, os_tick_from_millisecond(UPDATA_BALANCE_MS)))
	{
		if (g_balance_state == g_balance_ctrl_flag) 
		{
			return 0; // 均衡状态没变化时，不进行配置
		}
	}
	updata_balance_tick = hal_tick_get();

    for (i = 0; i < (sizeof(temp_buff) / sizeof(bq79616_config_reg_t)); i++)
    {
        temp_buff[i].target_val = temp_buff[i].val;
        if (0 > bq79616_write_single(&temp_buff[i]))
    	{
    		return -1;
    	}
    }
    g_balance_state = g_balance_ctrl_flag;
    // 均衡结束时间后重置均衡计数并触发均衡
    if (0 > start_stop_balance(2)) // 开启均衡
    {
        return -1;
    }
    return 0;
}

int32_t bq79616_shutdown(void)
{
    bq79616_config_reg_t temp = BQ79616_REG_CONFIG(CONTROL1, 0x08, 0x08, 1);
    if (0 == bq79616_write_single(&temp))
    {
        return 0;
    }
    return -1;
}

static int32_t bq79616_write_single(bq79616_config_reg_t *val)
{
	uint8_t i;
    for (i = 0; i < RETRY_NUM; i++)
    {
#if AFE_DEBUG_ENABLE
        g_write_counter++;
#endif
        if (0 == write_reg(val->dev_id, val->addr, val->val, val->target_val, val->write_len, val->operate_type))
        {
            return 0;
        }
        os_delay(os_tick_from_millisecond(1));
#if AFE_DEBUG_ENABLE
        g_write_fail_counter++;
#endif

    }
    return -1;
}

static int32_t bq79616_read_single( uint16_t addr, uint8_t *buf, uint8_t read_len, uint32_t delay_ms)
{
	uint8_t i;
    for (i = 0; i < RETRY_NUM; i++)
    {
#if AFE_DEBUG_ENABLE
        g_read_counter++;
#endif
        if (0 == read_reg(BQ79616_ADDR, (addr), (buf), (read_len), FRMWRT_SGL_R, (delay_ms)))
        {
             return 0;
        }
        os_delay(os_tick_from_millisecond(1));
#if AFE_DEBUG_ENABLE
        g_read_fail_counter++;
#endif

    }
    return -1;
}

#ifdef RT_USING_FINSH
#if AFE_DEBUG_ENABLE

// 增加透传读AFE调试接口
const uint32_t  hex_buf[] = {0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9, 0xa, 0xb, 0xc, 0xd, 0xe, 0xf};
static int32_t str_to_u32(char *str, uint32_t *val)
{
    uint8_t temp, len;
    uint8_t i = 0;

	len = rt_strlen(str);
    *val = 0;
    while(str[i] != '\0')
    {
       if (((str[i] >= '0') && (str[i] <= '9')) || ((str[i] >= 'a') && (str[i] <= 'f')))
       {
           if (str[i] > '9')
           {
                temp = str[i] - 0x57;
                *val |= (hex_buf[temp] << ((len - i - 1) * 4));
           }
           else
           {
                temp = str[i] - 0x30;
                *val |= (hex_buf[temp] << ((len - i - 1) * 4));
           }
		   i++;
       }
       else
       {
            return -1;
       }
    }
    return 0;
}

static void afe_read_reg(int argc, char**argv)
{
    uint8_t len, i;
    uint8_t buf[128] = {0};
    uint16_t addr;
    uint32_t temp;

    if (argc != 3)
    {
        rt_kprintf("Please input'afe_read_reg <addr, len>'\n");
        return;
    }
    if (0 > str_to_u32(argv[1], &temp))
    {
        rt_kprintf("ilegal_1\n");
        return;
    }
    addr = (uint16_t)temp;
    if (0 > str_to_u32(argv[2], &temp))
    {
        rt_kprintf("ilegal_2\n");
        return;
    }
    len = (uint8_t)temp;
    if (0 > bq79616_read_single(addr, buf, len, 1))
    {
        rt_kprintf("ilegal_read\n");
        return;
    }
    for (i = 0; i < len; i++)
    {
        rt_kprintf("%x  ", buf[i + 4]);  
    }
    rt_kprintf("\n");    
}
MSH_CMD_EXPORT(afe_read_reg, afe_read_reg <addr len>);

static void afe_set_balance(int argc, char**argv)
{
    uint32_t temp_bit;
	if (argc != 2)
    {
        rt_kprintf("Please input'afe_set_balance <u32_balance_bit>'\n");
        return;
    }

    if (0 > str_to_u32(argv[1], &temp_bit))
    {
        rt_kprintf("ilegal\n");
        return;
    }
    rt_kprintf("u32_balance_bit: %x'\n", temp_bit);
	hal_afe_balance_set(temp_bit);
    rt_kprintf("set balance succeed!\n");
}
MSH_CMD_EXPORT(afe_set_balance, afe_set_balance <u32_balance_bit>);   

static void afe_communication_check(int argc, char**argv)
{
    if (argc != 2)
    {
        rt_kprintf("Please input'afe_communication_check <read|reset>'\n");
        return;
    }

    if (!rt_strcmp(argv[1], "read"))
    {
        rt_kprintf("write counter: %d\n", g_write_counter);
        rt_kprintf("write fail counter: %d\n", g_write_fail_counter);
        rt_kprintf("read counter: %d\n", g_read_counter);
        rt_kprintf("read fail counter: %d\n", g_read_fail_counter);
    }
    else if (!rt_strcmp(argv[1], "reset"))
    {
        g_write_counter = 0;
        g_write_fail_counter = 0;
        g_read_counter = 0;
        g_read_fail_counter = 0;
        rt_kprintf("reset afe communication counter!\n");
    }
}
MSH_CMD_EXPORT(afe_communication_check, afe_communication_check <read|reset>); 

#endif 
#endif

#ifdef __cplusplus
}
#endif

