#include <board.h>
#include <string.h>
#include <rtthread.h>
#include <rtdevice.h>
#include "hal_wdt.h"
#include "hal_gpio.h"
#include "pin_config.h"
#include "log.h"
#include "sofar_errors.h"


#define WDT_DEVICE_NAME    				  "wdt" /* 看门狗设备名称 */

#define RT_DEVICE_CTRL_WDT_GET_TIMEOUT    (1) 	/* 获取溢出时间 */
#define RT_DEVICE_CTRL_WDT_SET_TIMEOUT    (2) 	/* 设置溢出时间 */
#define RT_DEVICE_CTRL_WDT_GET_TIMELEFT   (3) 	/* 获取剩余时间 */
#define RT_DEVICE_CTRL_WDT_KEEPALIVE      (4) 	/* 喂狗 */
#define RT_DEVICE_CTRL_WDT_START          (5) 	/* 启动看门狗 */
#define RT_DEVICE_CTRL_WDT_STOP           (6) 	/* 停止看门狗 */

static uint32_t    g_wdg_init = 0;     		/* 看门狗打开状态 */
static uint32_t    g_wdg_status = 0;     		/* 看门狗打开状态 */
static uint8_t     g_ext_wdg_feed_enbale = false;     // 外部看门狗喂狗使能
static uint8_t     g_wdt_time_s  = 12;       //看门狗超时时间
IWDG_HandleTypeDef hiwdg;

#ifdef BSP_USING_EXWDT
/**
* @brief		看门狗加载驱动
* @return		执行结果
* @retval		SF_OK 成功
* @retval		<0 失败 
*/
int32_t hal_ext_wdt_init(void)
{
	hal_gpio_config_t gpio_config = {HAL_GPIO_OUTPUT, HAL_GPIO_NOPULL};
   
    // 初始化外部看门狗
    if(hal_gpio_config(EXT_WDI_1_PIN, &gpio_config) != SF_OK)
	{
		return SF_ERR_NO_OBJECT;
	}
	g_ext_wdg_feed_enbale = true;
	return SF_OK;
}
INIT_DEVICE_EXPORT(hal_ext_wdt_init);

// 外部看门狗喂狗
static void hal_ext_wdt_feed(void)
{
    if (!g_ext_wdg_feed_enbale)
    {
        return;
    }
    HAL_GPIO_TogglePin(PIN_STPORT(EXT_WDI_1_PIN), PIN_STPIN(EXT_WDI_1_PIN)); // EXT_WDT_1_PIN
}

#endif

/**
* @brief		看门狗加载驱动
* @return		执行结果
* @retval		SF_OK 成功
* @retval		<0 失败 
*/
int32_t hal_wdt_init(void)
{
	if(!g_wdg_init)
	{

		g_wdg_status = 0;
		g_wdg_init = 1;
	}

	return SF_OK;
}
INIT_DEVICE_EXPORT(hal_wdt_init);

/**
* @brief		看门狗删除驱动(预留)
* @return		执行结果
* @retval		SF_OK 成功
* @retval		<0 失败 
*/
int32_t hal_wdt_deinit(void)
{

	return SF_OK;
}

/**
* @brief		打开看门狗
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		<0 失败   
* @pre			执行hal_wdt_init后执行才有效。默认5s
*/
static void hal_wdg_idle_hook(void);
static int32_t hal_wdt_control(void)
{
	uint32_t timeout_s = 0;
	if(!g_wdg_init)
	{
		return SF_ERR_NO_READY;
	}

	if(g_wdg_status)
	{
		return SF_OK;
	}
	
    hiwdg.Instance = IWDG;
    hiwdg.Init.Prescaler = IWDG_PRESCALER_128;
    hiwdg.Init.Window = 0x00000FFF;
    timeout_s = g_wdt_time_s * LSI_VALUE / 128 ;
    if(timeout_s > 0x00000FFF)
    {
        hiwdg.Init.Reload = 0x00000FFF;       
    }
    else
    {
        hiwdg.Init.Reload = timeout_s;  
    }


    if (HAL_IWDG_Init(&hiwdg) != HAL_OK)
    {
        return SF_ERR_PARA;
    }
  
    rt_thread_idle_sethook(hal_wdg_idle_hook);
	g_wdg_status = 1;
	
	return SF_OK;
}

int32_t hal_wdt_open(void)
{
    int32_t ret = hal_wdt_control();
    if (ret != SF_OK)
    {
        log_e("[init]wdgErr%d,Retry\n", ret);
        ret = hal_wdt_control();
        if (ret != SF_OK)
        {
            log_e("[init]wdgErr%d\n", ret);
        }
    }
    return ret;
}


/**
* @brief		关闭看门狗  （只能关闭硬件看门狗）
* @return		执行结果
* @retval		0 成功  
* @retval		<0 失败   
* @pre			看门狗打开后就关闭不了，需等到复位。
*/
int32_t hal_wdt_close(void)
{
	g_ext_wdg_feed_enbale = false;
	return SF_ERR_PARA;
}
 

/**
* @brief		设置超时时间
* @param		[in] timeout_s 超时时间，秒为单位 不超过26
* @return		执行结果
* @retval		0 成功  
* @retval		<0 失败   
* @pre			init、open成功后执行才有效
*/
int32_t hal_wdt_set(uint32_t timeout_s)
{
	/* 看门狗未启动或看门狗设备句柄未初始化，直接返回 */
	if ((!g_wdg_init) || (!g_wdg_status)  || (timeout_s > 26))
	{
		return SF_ERR_PARA;	
    }
    
    g_wdt_time_s = timeout_s;
    timeout_s = g_wdt_time_s * LSI_VALUE / 128 ;
    if(timeout_s > 0x00000FFF)
    {
        hiwdg.Init.Reload = 0x00000FFF;       
    }
    else
    {
        hiwdg.Init.Reload = timeout_s;  
    }


    if (HAL_IWDG_Init(&hiwdg) != HAL_OK)
    {
        return SF_ERR_PARA;
    }    
    
	return SF_OK;	
}


/**
* @brief		获取超时时间
* @param		[out] timeout_s 超时时间，秒为单位,
* @return		执行结果
* @retval		0 成功  
* @retval		<0 失败   
* @pre			init、open成功后执行才有效
*/
int32_t hal_wdt_get_timeout(uint32_t *p_timeout)
{	
	if ((!g_wdg_init) || (!g_wdg_status) )
	{
		return SF_ERR_PARA;	
    }
	
	return g_wdt_time_s;
}


/**
* @brief		喂狗  
* @return		执行结果
* @retval		0 成功  
* @retval		<0 失败 
* @pre			init、open成功后执行才有效
*/
int32_t hal_wdt_feed(void)
{
	if ((!g_wdg_init) || (!g_wdg_status) )
	{
		return SF_ERR_PARA;
    }
#ifdef RT_USING_WDT
#ifdef BSP_USING_EXWDT
	hal_ext_wdt_feed();
#endif
#endif
	return HAL_IWDG_Refresh(&hiwdg);
}


/**
* @brief		看门狗超时中断回调函数(预留) 
* @param		[in] cb 回调函数  
* @return		执行结果
* @retval		0 成功  
* @retval		<0 失败   
* @pre			执行hal_wdt_open后执行才有效。
* @warning  	函数使用需要在hal_wdt_start之前调用
*/
int32_t hal_wdt_set_irq(irq_wdt_callback cb)
{
	return SF_OK;
}


static void hal_wdg_idle_hook(void)
{
    hal_wdt_feed();
}


#ifdef RT_USING_FINSH

#include <stdlib.h>
static int hal_wdt_sample(int argc, char *p_argv[])
{
	uint32_t timeout;
	char 	*pin_opt  = p_argv[1];
	char 	*time	  = p_argv[2];

	if (!rt_strcmp(pin_opt, "init"))
	{
		if(SF_OK != hal_wdt_init())
		{
			log_e("hal_wdt_init err!\n");
		}
	}
	else if (!rt_strcmp(pin_opt, "deinit"))
	{
		if(SF_OK != hal_wdt_deinit())
		{
			log_e("hal_wdt_deinit err!\n");
		}
	}
	else if (!rt_strcmp(pin_opt, "open"))
	{
		if(SF_OK != hal_wdt_open())
		{
			log_e("hal_wdt_open err!\n");
		}
	}
	else if (!rt_strcmp(pin_opt, "close"))
	{
		if(SF_OK != hal_wdt_close())
		{
			log_e("hal_wdt_close err!\n");
		}
	}
	else if (!rt_strcmp(pin_opt, "set"))
	{
		uint32_t timeout_s = 0;
		
		timeout = atoi(time);
		if(SF_OK != hal_wdt_set(timeout))
		{
			log_e("hal_wdt_set err!\n");
		}
		if(SF_OK == hal_wdt_get_timeout(&timeout_s))
		{
			rt_kprintf("get timeout: %d\n", timeout_s);
		}
	}
	else if(!rt_strcmp(pin_opt, "feed"))
	{
		if(SF_OK != hal_wdt_feed())
		{
			log_e("hal_wdt_feed err!\n");
		}
	}
    else if (!rt_strcmp(pin_opt, "dise")) // 屏蔽外部看门狗
    {
		g_ext_wdg_feed_enbale = false;
    }
    else if (!rt_strcmp(pin_opt, "disi"))
    {
        g_wdg_status = 0;
        g_wdg_init = 0;
    }
	else
	{
		log_e("input '%s' is not support\n",pin_opt);
		return SF_ERR_PARA;
	}
	
	return SF_OK;
}

MSH_CMD_EXPORT(hal_wdt_sample, hal_wdt_sample <start/stop>);
#endif

