#include <board.h>
#include <rtthread.h>
#include <rtdevice.h>
#include "hal_spi.h"
#include "hal_gpio.h"
#include "pin_config.h"
#include "string.h"
#include "log.h"
#include "sofar_errors.h"

/**
* @struct gpio管脚定义
* @brief  定义gpio对应的module和pin
*/
typedef struct 
{
    GPIO_TypeDef* GPIOx;
    uint16_t GPIO_Pin;
}gpio_pin_t;


// 标识SPI状态
static uint8_t g_spi_status;



#include <rtthread.h>
#include <rtdevice.h>
#include "board.h"
#include "drv_config.h"
#include <string.h>



typedef struct{
    SPI_TypeDef *Instance;
    rt_uint8_t spi_dma_flag;
}spi_ctrl_t;


static SPI_HandleTypeDef g_spi_handle[SPI_MAX] = {0};

static const spi_ctrl_t g_spi_config[SPI_MAX] =
{
    {SPI2, 0},
    {SPI3, 0},
    {SPI4, 0},
};




static rt_err_t stm32_spi_cfg(SPI_HandleTypeDef *spi_handle, const spi_ctrl_t *spi_ctrl, hal_spi_config_t *p_cfg)
{
    RT_ASSERT(spi_ctrl != RT_NULL);
    RT_ASSERT(p_cfg != RT_NULL);
    
    if (p_cfg->work_mode & HAL_SPI_SLAVE)
    {
        spi_handle->Init.Mode = SPI_MODE_SLAVE;
    }
    else
    {
        spi_handle->Init.Mode = SPI_MODE_MASTER;
    }


    spi_handle->Init.Direction = SPI_DIRECTION_2LINES;

    if (p_cfg->data_width == 8)
    {
        spi_handle->Init.DataSize = SPI_DATASIZE_8BIT;
        spi_handle->TxXferSize = 8;
        spi_handle->RxXferSize = 8;
    }
    else if (p_cfg->data_width == 16)
    {
        spi_handle->Init.DataSize = SPI_DATASIZE_16BIT;
    }
    else
    {
        return SF_ERR_PARA;
    }

    if (p_cfg->trans_mode & HAL_SPI_CPHA)
    {
        spi_handle->Init.CLKPhase = SPI_PHASE_2EDGE;
    }
    else
    {
        spi_handle->Init.CLKPhase = SPI_PHASE_1EDGE;
    }

    if (p_cfg->trans_mode & HAL_SPI_CPOL)
    {
        spi_handle->Init.CLKPolarity = SPI_POLARITY_HIGH;
    }
    else
    {
        spi_handle->Init.CLKPolarity = SPI_POLARITY_LOW;
    }

    spi_handle->Init.NSS = SPI_NSS_SOFT;

    uint32_t SPI_APB_CLOCK;


    /* SPI1, SPI4 and SPI5 on APB2 */
    if(spi_ctrl->Instance == SPI1
        || spi_ctrl->Instance == SPI4)
    {
        SPI_APB_CLOCK = HAL_RCC_GetPCLK2Freq();
    }
    else if(spi_ctrl->Instance == SPI2
        || spi_ctrl->Instance == SPI3)
    {
        SPI_APB_CLOCK = HAL_RCC_GetPCLK1Freq();
    }

    /* SPI6 get the input clk from APB4(such as on STM32H7). However, there is no HAL_RCC_GetPCLK4Freq api provided.
    APB4 has same prescale factor as APB1 from HPRE Clock by default in CubeMx, so we assign APB1 to it.
    if you change the default prescale factor of APB4, please modify SPI_APB_CLOCK accordingly.
    */
    else
    {
        SPI_APB_CLOCK = HAL_RCC_GetPCLK1Freq();
    }

    if (p_cfg->max_hz >= SPI_APB_CLOCK / 2)
    {
        spi_handle->Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
    }
    else if (p_cfg->max_hz >= SPI_APB_CLOCK / 4)
    {
        spi_handle->Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_4;
    }
    else if (p_cfg->max_hz >= SPI_APB_CLOCK / 8)
    {
        spi_handle->Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8;
    }
    else if (p_cfg->max_hz >= SPI_APB_CLOCK / 16)
    {
        spi_handle->Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
    }
    else if (p_cfg->max_hz >= SPI_APB_CLOCK / 32)
    {
        spi_handle->Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_32;
    }
    else if (p_cfg->max_hz >= SPI_APB_CLOCK / 64)
    {
        spi_handle->Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_64;
    }
    else if (p_cfg->max_hz >= SPI_APB_CLOCK / 128)
    {
        spi_handle->Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_128;
    }
    else
    {
        /*  min prescaler 256 */
        spi_handle->Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_256;
    }

    log_i("sys freq: %d, pclk2 freq: %d, SPI limiting freq: %d, BaudRatePrescaler: %d\r\n",
          HAL_RCC_GetSysClockFreq(),
          SPI_APB_CLOCK,
          p_cfg->max_hz,
          spi_handle->Init.BaudRatePrescaler);

    if (p_cfg->first_bit == HAL_SPI_FIRSTBIT_MSB)
    {
        spi_handle->Init.FirstBit = SPI_FIRSTBIT_MSB;
    }
    else
    {
        spi_handle->Init.FirstBit = SPI_FIRSTBIT_LSB;
    }

    spi_handle->Init.TIMode = SPI_TIMODE_DISABLE;
    spi_handle->Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
    spi_handle->State = HAL_SPI_STATE_RESET;
    spi_handle->Init.NSSPMode          = SPI_NSS_PULSE_DISABLE;

    if (HAL_SPI_Init(spi_handle) != HAL_OK)
    {
        return RT_EIO;
    }

    SET_BIT(spi_handle->Instance->CR2, SPI_RXFIFO_THRESHOLD_HF);

//    /* DMA configuration */
//    if (spi_ctrl->spi_dma_flag & SPI_USING_RX_DMA_FLAG)
//    {
//        HAL_DMA_Init(&spi_drv->dma.handle_rx);

//        __HAL_LINKDMA(&spi_drv->handle, hdmarx, spi_drv->dma.handle_rx);

//        /* NVIC configuration for DMA transfer complete interrupt */
//        HAL_NVIC_SetPriority(spi_drv->config->dma_rx->dma_irq, 0, 0);
//        HAL_NVIC_EnableIRQ(spi_drv->config->dma_rx->dma_irq);
//    }

//    if (spi_ctrl->spi_dma_flag & SPI_USING_TX_DMA_FLAG)
//    {
//        HAL_DMA_Init(&spi_drv->dma.handle_tx);

//        __HAL_LINKDMA(&spi_drv->handle, hdmatx, spi_drv->dma.handle_tx);

//        /* NVIC configuration for DMA transfer complete interrupt */
//        HAL_NVIC_SetPriority(spi_drv->config->dma_tx->dma_irq, 0, 1);
//        HAL_NVIC_EnableIRQ(spi_drv->config->dma_tx->dma_irq);
//    }

//    if(spi_ctrl->spi_dma_flag & SPI_USING_TX_DMA_FLAG || spi_ctrl->spi_dma_flag & SPI_USING_RX_DMA_FLAG)
//    {
//        HAL_NVIC_SetPriority(spi_drv->config->irq_type, 2, 0);
//        HAL_NVIC_EnableIRQ(spi_drv->config->irq_type);
//    }

    return RT_EOK;
}

static rt_uint32_t stm32_spi_xfer(SPI_HandleTypeDef *spi_handle, const spi_ctrl_t *spi_ctrl, void *p_dout, void *p_din, uint32_t len)
{
    HAL_StatusTypeDef state;
    rt_size_t message_length, already_send_length;
    rt_uint16_t send_length;
    rt_uint8_t *recv_buf;
    const rt_uint8_t *send_buf;


    //HAL_GPIO_WritePin(spi_ctrl->spi_cs_GPIOx, spi_ctrl->spi_cs_GPIO_Pin, GPIO_PIN_RESET);


    message_length = len;
    recv_buf = (rt_uint8_t *)p_din;
    send_buf = (rt_uint8_t *)p_dout;
    while (message_length)
    {
        /* the HAL library use uint16 to save the data length */
        if (message_length > 65535)
        {
            send_length = 65535;
            message_length = message_length - 65535;
        }
        else
        {
            send_length = message_length;
            message_length = 0;
        }

        /* calculate the start address */
        already_send_length = len - send_length - message_length;
        send_buf = (rt_uint8_t *)p_dout + already_send_length;
        recv_buf = (rt_uint8_t *)p_din + already_send_length;

        /* start once data exchange in DMA mode */
        if (p_dout && p_din)
        {
//            if ((spi_drv->spi_dma_flag & SPI_USING_TX_DMA_FLAG) && (spi_drv->spi_dma_flag & SPI_USING_RX_DMA_FLAG))
//            {
//                state = HAL_SPI_TransmitReceive_DMA(spi_handle, (uint8_t *)send_buf, (uint8_t *)recv_buf, send_length);
//            }
//            else
            {
                state = HAL_SPI_TransmitReceive(spi_handle, (uint8_t *)send_buf, (uint8_t *)recv_buf, send_length, 1000);
            }
        }
        else if (p_dout)
        {
//            if (spi_drv->spi_dma_flag & SPI_USING_TX_DMA_FLAG)
//            {
//                state = HAL_SPI_Transmit_DMA(spi_handle, (uint8_t *)send_buf, send_length);
//            }
//            else
            {
                state = HAL_SPI_Transmit(spi_handle, (uint8_t *)send_buf, send_length, 1000);
            }

//            if (message->cs_release && (device->config.mode & RT_SPI_3WIRE))
//            {
//                /* release the CS by disable SPI when using 3 wires SPI */
//                __HAL_SPI_DISABLE(spi_handle);
//            }
        }
        else
        {
            memset((uint8_t *)recv_buf, 0xff, send_length);
//            if (spi_drv->spi_dma_flag & SPI_USING_RX_DMA_FLAG)
//            {
//                state = HAL_SPI_Receive_DMA(spi_handle, (uint8_t *)recv_buf, send_length);
//            }
//            else
            {
                /* clear the old error flag */
                __HAL_SPI_CLEAR_OVRFLAG(spi_handle);
                state = HAL_SPI_Receive(spi_handle, (uint8_t *)recv_buf, send_length, 1000);
            }
        }

        if (state != HAL_OK)
        {
            log_i("spi transfer error : %d\r\n", state);
            len = 0;
            spi_handle->State = HAL_SPI_STATE_READY;
        }
//        else
//        {
//            LOG_D("%s transfer done", spi_drv->config->bus_name);
//        }

        /* For simplicity reasons, this example is just waiting till the end of the
           transfer, but application may perform other tasks while transfer operation
           is ongoing. */
        while (HAL_SPI_GetState(spi_handle) != HAL_SPI_STATE_READY);
    }


    //HAL_GPIO_WritePin(spi_ctrl->spi_cs_GPIOx, spi_ctrl->spi_cs_GPIO_Pin, GPIO_PIN_SET);


    return len;
}


/**
* @brief		SPI加载驱动
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
*/
int32_t hal_spi_init(void)
{
    uint8_t i;
    
	g_spi_status = 0;
    for (i = 0;i < SPI_MAX; i++)
    {
        
        g_spi_handle[i].Instance = g_spi_config[i].Instance;
        g_spi_handle[i].Init.Mode = SPI_MODE_MASTER;
        g_spi_handle[i].Init.Direction = SPI_DIRECTION_2LINES;
        g_spi_handle[i].Init.DataSize = SPI_DATASIZE_8BIT;
        g_spi_handle[i].TxXferSize = 8;
        g_spi_handle[i].RxXferSize = 8;
        g_spi_handle[i].Init.CLKPhase = SPI_PHASE_2EDGE;
        g_spi_handle[i].Init.CLKPolarity = SPI_POLARITY_HIGH;
        g_spi_handle[i].Init.NSS = SPI_NSS_SOFT;
        g_spi_handle[i].Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8;
        g_spi_handle[i].Init.FirstBit = SPI_FIRSTBIT_MSB;
        g_spi_handle[i].Init.TIMode = SPI_TIMODE_DISABLE;
        g_spi_handle[i].Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
        g_spi_handle[i].State = HAL_SPI_STATE_RESET;
        g_spi_handle[i].Init.NSSPMode          = SPI_NSS_PULSE_DISABLE;
    }
    
	
	return SF_OK;
}

INIT_BOARD_EXPORT(hal_spi_init);

/**
* @brief		SPI删除驱动
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
*/
int32_t hal_spi_deinit(void)
{
	return SF_OK;
}

/**
* @brief		打开SPI功能 
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @warning 		本接口只初始化SPI总线接口 
*/
int32_t hal_spi_open(uint32_t dev_no)
{
	/* 虚拟设备端口号合法检查 */
	if (dev_no >= SPI_MAX) 
	{
		return SF_ERR_PARA;
	}
	/* 设备已打开，直接返回ok,避免重复打开 */
	if (SF_GET_BIT(g_spi_status, (1U << dev_no)) != 0)
    {
        return SF_OK;
    }
	
    if (HAL_SPI_Init(&g_spi_handle[dev_no]) == SF_OK)
    {
        SF_SET_BIT(g_spi_status, (1U << dev_no));
        return HAL_OK;
    }
    else
    {
        return SF_ERR_PARA;
    }
}

/**
* @brief		关闭SPI功能 
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_spi_close(uint32_t dev_no)
{
	/* 虚拟设备端口号合法检查 */
	if (dev_no >= SPI_MAX) 
	{
		return SF_ERR_PARA;
	}
	/* 设备已关闭，直接返回ok,避免重复关闭 */
	if (SF_GET_BIT(g_spi_status, (1u << dev_no)) == 0)
    {
        return SF_OK;
    }

	
    if (HAL_SPI_DeInit(&g_spi_handle[dev_no]) == HAL_OK)
    {
        SF_CLR_BIT(g_spi_status, (1U << dev_no));
        return SF_OK;
    }
    else
    {
        return SF_ERR_PARA;
    }
}

/**
* @brief		SPI功能从休眠中唤醒，恢复状态
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_spi_resume(uint32_t dev_no)
{ 
	/* 虚拟设备端口号合法检查 */
	if (dev_no >= SPI_MAX) 
	{
		return SF_ERR_PARA;
	}
	/* 设备未打开，返回失败 */
	if (SF_GET_BIT(g_spi_status, (1u << dev_no)) == 0)
    {
        return SF_ERR_OPEN;
    }
    
    if (HAL_SPI_Init(&g_spi_handle[dev_no]) == HAL_OK)
    {
        SF_CLR_BIT(g_spi_status, (1U << dev_no));
        return SF_OK;
    }
    else
    {
        return SF_ERR_PARA;
    }
}
 
/**
* @brief		SPI功能进入休眠模式
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式，功能不影响
*/
int32_t hal_spi_suspend(uint32_t dev_no)
{
    int32_t ret = SF_ERR_PARA;
    hal_gpio_config_t gpio_config = 
	{
		.direction = HAL_GPIO_OUTPUT, 
		.pull = HAL_GPIO_NOPULL
	};
    
    /* 虚拟设备端口号合法检查 */
	if (dev_no >= SPI_MAX) 
	{
		return SF_ERR_PARA;
	}
	/* 设备未打开，返回失败 */
	if (SF_GET_BIT(g_spi_status, (1u << dev_no)) == 0)
    {
        return SF_ERR_OPEN;
    }

	if (g_spi_handle[dev_no].Instance == SPI2)
	{
		HAL_SPI_DeInit(&g_spi_handle[dev_no]);
		// 对应SPI管脚配置为IO口，电平拉低
		hal_gpio_config(SPI2_CLK_PIN  , &gpio_config);  
		hal_gpio_config(SPI2_MISO_PIN , &gpio_config);  
		hal_gpio_config(SPI2_MOSI_PIN , &gpio_config);
		hal_gpio_config(FLASH_HOLD_PIN, &gpio_config);
		hal_gpio_write(FLASH_CS_PIN  , 0); 
		hal_gpio_write(FLASH_WP_PIN  , 0); 
		hal_gpio_write(SPI2_CLK_PIN  , 0);   
		hal_gpio_write(SPI2_MISO_PIN , 0);   
		hal_gpio_write(SPI2_MOSI_PIN , 0);    
		hal_gpio_write(FLASH_HOLD_PIN, 0);   
		ret = SF_OK;	
	}
	else if (g_spi_handle[dev_no].Instance == SPI3)
	{
		HAL_SPI_DeInit(&g_spi_handle[dev_no]);
		// 对应SPI管脚配置为IO口，电平拉低
		hal_gpio_config(SPI3_CLK_PIN  , &gpio_config);  
		hal_gpio_config(SPI3_MISO_PIN , &gpio_config);  
		hal_gpio_config(SPI3_MOSI_PIN , &gpio_config);

		hal_gpio_write(SPI3_CS_PIN  , 0); 
		hal_gpio_write(SPI3_CLK_PIN  , 0);   
		hal_gpio_write(SPI3_MISO_PIN , 0);   
		hal_gpio_write(SPI3_MOSI_PIN , 0);      
		ret = SF_OK;	
	} 
	else if (g_spi_handle[dev_no].Instance == SPI4)
	{
		HAL_SPI_DeInit(&g_spi_handle[dev_no]);
		// 对应SPI管脚配置为IO口，电平拉低
		hal_gpio_config(SPI4_CLK_PIN  , &gpio_config);  
		hal_gpio_config(SPI4_MISO_PIN , &gpio_config);  
		hal_gpio_config(SPI4_MOSI_PIN , &gpio_config);

		hal_gpio_write(SPI4_CS_PIN  , 0); 
		hal_gpio_write(SPI4_CLK_PIN  , 0);   
		hal_gpio_write(SPI4_MISO_PIN , 0);   
		hal_gpio_write(SPI4_MOSI_PIN , 0);      
		ret = SF_OK;	
	}     
	else
	{
		ret = SF_ERR_PARA;
	}

    return ret;
}


/**
* @brief		设置SPI属性  
* @param		[in] dev_no 设备端口号
* @param		[in] p_config SPI配置参数  
* - config->work_mode 使用模式
* -# HAL_SPI_MASTER = 主模式
* -# HAL_SPI_SLAVE = 从模式
* - config->trans_mode 使用模式
* -# HAL_SPI_MODE_0 = CPOL:0|CPHA:0
* -# HAL_SPI_MODE_1 = CPOL:0|CPHA:1
* -# HAL_SPI_MODE_2 = CPOL:1|CPHA:0
* -# HAL_SPI_MODE_3 = CPOL:1|CPHA:1 
* - config->data_width SPI发送数据位
* - config->first_bit SPI通信长度
* -# HAL_SPI_FIRSTBIT_MSB 
* -# HAL_SPI_FIRSTBIT_LSB
* - config->max_hz SPI频率
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @pre 			执行hal_spi_open后执行才有效。 
@code 
		CPOL 	CPHA
MODE0 	0 		0
MODE1 	0 		1
MODE2 	1 		0
MODE3 	1 		1
CPOL: SPI空闲时的时钟信号电平(1:高电平, 0:低电平)
CPHA: SPI在时钟第几个边沿采样(1:第二个边沿开始, 0:第一个边沿开始)
@endcode
*/
int32_t hal_spi_setup(uint32_t dev_no, hal_spi_config_t *p_config)
{
	if ((dev_no >= SPI_MAX) || (!p_config))
	{
		return SF_ERR_PARA;
	}
	if (SF_GET_BIT(g_spi_status, (1u << dev_no)) == 0)
    {
        return SF_ERR_NO_OBJECT;
    }
    
	return stm32_spi_cfg(&g_spi_handle[dev_no], &g_spi_config[dev_no], p_config);
}



/**
* @brief		SPI发数据 
* @param		[in] dev_no 设备端口号
* @param		[in] p_buf 缓冲区指针    
* @param		[in] len 缓冲区长度    
* @return		执行结果
* @retval		>0 发送数据长度(阻塞式)  
* @retval		=0 数据待发送(非阻塞式)，使用hal_spi_query查询发送完成情况  
* @retval		<0 失败原因   
* @pre 			执行hal_spi_open后执行才有效。 
*/
int32_t hal_spi_write(uint32_t dev_no, void *p_buf, uint32_t len)
{
    
	/* 虚拟设备端口号合法检查 */
	if (dev_no >= SPI_MAX) 
	{
		return SF_ERR_PARA;
	}
	/* 设备未打开，返回失败 */
	if (SF_GET_BIT(g_spi_status, (1u << dev_no)) == 0)
    {
        return SF_ERR_NO_OBJECT;
    }
    
    
    return stm32_spi_xfer(&g_spi_handle[dev_no], &g_spi_config[dev_no], p_buf, NULL, len);
}

/**
* @brief		SPI发数据 
* @param		[in] dev_no 设备端口号
* @param		[in] p_buf 缓冲区指针    
* @param		[in] len 缓冲区长度    
* @return		执行结果
* @retval		>0 接收数据长度
* @retval		=0 数据待接收(非阻塞式)，使用hal_spi_query查询接收完成情况 
* @retval		<0 失败原因 
* @pre 			执行hal_spi_open后执行才有效。 
*/
int32_t hal_spi_read(uint32_t dev_no, void *p_buf, uint32_t len)
{
	/* 设备未打开，返回失败 */
	if (SF_GET_BIT(g_spi_status, (1u << dev_no)) == 0)
    {
        return SF_ERR_NO_READY;
    }
    
    return stm32_spi_xfer(&g_spi_handle[dev_no], &g_spi_config[dev_no], NULL, p_buf,  len);
}

/**
* @brief		清空收缓冲区数据（预留）
* @param		[in] dev_no 设备端口号    
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		<0 失败原因 
* @pre 			执行hal_spi_open后执行才有效。 
*/
int32_t hal_spi_flush(uint32_t dev_no)
{
	return SF_ERR_FNOSUPP;
}

/**
* @brief		查询是否发送完毕 
* @param		[in] dev_no 设备端口号
* -# SPI1 - 0x00  
* -# SPI2 - 0x01
* -# SPI3 - 0x02
* @return		执行结果
* @retval		HAL_OK 成功 
* @retval		=0 发送完毕
* @retval		<0 失败原因 
* @pre 			执行hal_spi_open后执行才有效。 
*/
int32_t hal_spi_query(uint32_t dev_no)
{
    int32_t state;
    
	/* 虚拟设备端口号合法检查 */
	if (dev_no >= SPI_INDEX_MAX) 
	{
		return SF_ERR_PARA;
	}
    
    state = HAL_SPI_GetState(&g_spi_handle[dev_no]);
    
    if (state== HAL_SPI_STATE_READY || state == HAL_SPI_STATE_RESET)
    {
        return HAL_OK; 
    }
		
	return SF_ERR_PARA;
}



int32_t hal_spi_xfer(uint32_t dev_no, void *p_dout, void *p_din, uint32_t len)
{
	/* 设备未打开，返回失败 */
	if (SF_GET_BIT(g_spi_status, (1u << dev_no)) == 0)
    {
        return SF_ERR_OPEN;
    }
    
    return stm32_spi_xfer(&g_spi_handle[dev_no], &g_spi_config[dev_no], p_dout, p_din,  len);
}

/**
* @brief		配置SPI中断函数（预留）
* @param		[in] dev_no 设备端口号 
* @param		[in] p_tx_fcallback 发送中断回调函数 
* @param		[in] p_rx_fcallback 接收中断回调函数  
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		<0 失败原因   
* @pre 			执行hal_spi_open后执行才有效。 
*/
int32_t hal_spi_set_irq(uint32_t dev_no, irq_spi_callback p_tx_fcallback, irq_spi_callback p_rx_fcallback)
{
	return SF_ERR_FNOSUPP;
}


/**
* @brief		关闭SPI中断（预留）
* @param		[in] dev_no 设备端口号    
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		<0 失败原因   
* @pre 			执行hal_spi_open后执行才有效。 
*/
int32_t hal_spi_free_irq(uint32_t dev_no)
{
	return SF_ERR_FNOSUPP;
}

/**
 * @brief		扩展功能（预留）
 * @param		[in] dev_no 设备端口号
 * @param		[in] cmd 控制命令
 * @param		[in] p_arg 控制参数
 * @return		执行结果
 * @retval		SF_OK(0) 成功
 * @retval		<0 失败原因
 */
int32_t hal_spi_ioctl(uint32_t dev_no, uint32_t cmd, void* p_argv) 
{
    return SF_ERR_FNOSUPP;
}

#ifdef RT_USING_FINSH
#ifdef RT_USING_FINSH_DEBUG
#if 0
#include "hal.h"

// spi flash写数据使能
static void spi_flash_write_data_enable(void) {
   uint8_t send_data = 0x06;
    hal_gpio_write(HAL_PIN_SPI_CS, 0);
    hal_spi_write(SPI3_INDEX, &send_data, 1);
    hal_gpio_write(HAL_PIN_SPI_CS, 1);
}

// spi flash写数据
static void spi_flash_write(uint8_t *pBuffer, uint32_t WriteAddr, uint16_t NumByteToWrite) {
   uint8_t send_data = 0x06;

    spi_flash_write_data_enable();

    hal_gpio_write(HAL_PIN_SPI_CS, 0);

    send_data = 0x02;
    hal_spi_write(SPI3_INDEX, &send_data, 1);

    send_data = (WriteAddr & 0xFF0000) >> 16;
    hal_spi_write(SPI3_INDEX, &send_data, 1);
    send_data = (WriteAddr & 0xFF00) >> 8;
    hal_spi_write(SPI3_INDEX, &send_data, 1);
    send_data = WriteAddr & 0xFF;
    hal_spi_write(SPI3_INDEX, &send_data, 1);

    hal_spi_write(SPI3_INDEX, &pBuffer, NumByteToWrite);

    hal_gpio_write(HAL_PIN_SPI_CS, 0);

    /*!< Wait the end of Flash writing 
    sFLASH_WaitForWriteEnd();*/
}

static void spi_example(int argc, char *argv[]) {
    switch (argv[1][0]) {
    case '0': { // 初始化 spi3
        hal_spi_config_t        conf_spi;
        const hal_gpio_config_t gpio_config = {HAL_GPIO_OUTPUT, HAL_GPIO_PULLUP};

        hal_gpio_config(HAL_PIN_SPI_CS, (hal_gpio_config_t *) &gpio_config);
		hal_gpio_write(HAL_PIN_SPI_CS, 1);
        hal_spi_open(SPI3_INDEX);

        /* spi congig param*/
        conf_spi.work_mode  = HAL_SPI_MASTER;
        conf_spi.data_width = HAL_SPI_8BIT;
        conf_spi.first_bit  = HAL_SPI_FIRSTBIT_MSB;
        conf_spi.max_hz     = 40 * 1000 * 1000;
        conf_spi.trans_mode = HAL_SPI_MODE_0;
        hal_spi_setup(SPI3_INDEX, &conf_spi);
        break;
    }
    case '1': { // 读flash id
        uint8_t  buff[32] = {0};
        uint32_t flash_id = 0;
        
        hal_gpio_write(HAL_PIN_SPI_CS, 0);/* spi_cs拉低 */

        uint8_t send_data = 0x9F;
        hal_spi_write(SPI3_INDEX, &send_data, 1);
        hal_spi_read(SPI3_INDEX, &buff[0], 1);

        send_data = 0xA5;
        hal_spi_write(SPI3_INDEX, &send_data, 1);
        hal_spi_read(SPI3_INDEX, &buff[1], 1);

        hal_spi_write(SPI3_INDEX, &send_data, 1);
        hal_spi_read(SPI3_INDEX, &buff[2], 1);

        hal_spi_write(SPI3_INDEX, &send_data, 1);
        hal_spi_read(SPI3_INDEX, &buff[3], 1);
        
        hal_gpio_write(HAL_PIN_SPI_CS, 1);/* 读完 spi_cs拉高 */

        flash_id = (buff[1] << 16) | (buff[2] << 8) | (buff[3]);
        rt_kprintf("flash_id=%06x\r\n", flash_id);
        break;
    }
    case '2': { // 读flash id
        uint8_t  buff[32] = {0};
        uint32_t flash_id = 0;
        
        hal_gpio_write(HAL_PIN_SPI_CS, 0);/* spi_cs拉低 */

        uint8_t send_data = 0x9F;
        hal_spi_write(SPI3_INDEX, &send_data, 1);
        hal_spi_read(SPI3_INDEX, &buff[0], 1);

        send_data = 0xA5;
        hal_spi_write(SPI3_INDEX, &send_data, 1);
        hal_spi_read(SPI3_INDEX, &buff[1], 1);

        hal_spi_write(SPI3_INDEX, &send_data, 1);
        hal_spi_read(SPI3_INDEX, &buff[2], 1);

        hal_spi_write(SPI3_INDEX, &send_data, 1);
        hal_spi_read(SPI3_INDEX, &buff[3], 1);
        
        hal_gpio_write(HAL_PIN_SPI_CS, 1);/* 读完 spi_cs拉高 */

        flash_id = (buff[1] << 16) | (buff[2] << 8) | (buff[3]);
        rt_kprintf("flash_id=%06x\r\n", flash_id);
        break;
    }
    case 'c': { // 读flash id
        hal_spi_close(SPI3_INDEX);
        break;
    }
    default:
        break;
    }
}
MSH_CMD_EXPORT(spi_example, test spi);
#endif
#endif
#endif
