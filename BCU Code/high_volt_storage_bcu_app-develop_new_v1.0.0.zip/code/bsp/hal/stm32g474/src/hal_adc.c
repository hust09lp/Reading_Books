#include <board.h>
#include <string.h>
#include <rtthread.h>
#include <rtdevice.h>
#include "hal_adc.h"
#include "log.h"
#include "stm32g4xx_hal.h"
#include "sofar_errors.h"

#define ADC_SAMPLE_TIMES    (2)	/* ADC采样次数 */



#ifdef BSP_USING_ADC1
#define ADC1_DMA_BUF_SIZE	(ADC1_CHNNEL_CNT*ADC_SAMPLE_TIMES)			/* ADC1 DMA缓冲区大小 */
static uint16_t    g_adc1_dma_buf[ADC_SAMPLE_TIMES][ADC1_CHNNEL_CNT];	/* ADC1对应DMA缓冲区 */
static uint16_t    g_adc1_result[ADC1_CHNNEL_CNT];	    				/* ADC1滤波计算后结果 */
#endif

#ifdef BSP_USING_ADC2
#define ADC2_DMA_BUF_SIZE	(ADC2_CHNNEL_CNT*ADC_SAMPLE_TIMES)			/* ADC2 DMA缓冲区大小 */
static uint16_t    g_adc2_result[ADC2_CHNNEL_CNT];	    				/* ADC2滤波计算后结果 */
static uint16_t    g_adc2_dma_buf[ADC_SAMPLE_TIMES][ADC2_CHNNEL_CNT];	/* ADC2对应DMA缓冲区 */
#endif

#ifdef BSP_USING_ADC3
#define ADC3_DMA_BUF_SIZE	(ADC3_CHNNEL_CNT*ADC_SAMPLE_TIMES)			/* ADC2 DMA缓冲区大小 */
static uint16_t    g_adc3_dma_buf[ADC_SAMPLE_TIMES][ADC3_CHNNEL_CNT];	/* ADC3对应DMA缓冲区 */
static uint16_t    g_adc3_result[ADC3_CHNNEL_CNT];	    				/* ADC3滤波计算后结果 */
#endif



#ifdef BSP_USING_ADC
enum
{
#ifdef BSP_USING_ADC1
    ADC1_INDEX,
#endif
#ifdef BSP_USING_ADC2
    ADC2_INDEX,
#endif
#ifdef BSP_USING_ADC3
    ADC3_INDEX,
#endif
#ifdef BSP_USING_ADC4
    ADC4_INDEX,
#endif
#ifdef BSP_USING_ADC5
    ADC5_INDEX,
#endif
};
#endif

struct stm32_adc
{
    ADC_HandleTypeDef    adc_handle;
    IRQn_Type adc_irqn;
    char *name;
};

static struct stm32_adc stm32_adc_obj[] = 
{
#ifdef BSP_USING_ADC1
    ADC1_CONFIG,
#endif
#ifdef BSP_USING_ADC2
    ADC2_CONFIG,
#endif
#ifdef BSP_USING_ADC3
    ADC3_CONFIG,
#endif
#ifdef BSP_USING_ADC4
    ADC4_CONFIG,
#endif
#ifdef BSP_USING_ADC5
    ADC5_CONFIG,
#endif
};

#define HAL_ADC_ID_MAX      sizeof(stm32_adc_obj) / sizeof(stm32_adc_obj[0])

typedef struct{
	uint32_t is_init;								    // 0-未初始化 1-已初始化
	uint32_t is_start;								    // 0-未打开 1-已打开
	uint32_t is_suspend;							    // 0-未挂起 1-已挂起
}adc_status_t;
static adc_status_t	g_adc_status = {0};				    /* adc状态 */

typedef struct
{
	uint8_t 	index;
	uint16_t   *result;					
}hal_adc_map_t;



/* ADC数字量和HAL层的数据映射关系 */
const static hal_adc_map_t g_adc_dma_map[] =
{
	{HAL_ADC_CHAN_ID0,          (uint16_t*)&g_adc2_result[HALL_VOLT1]},	        // // 电流霍尔采样输入1
	{HAL_ADC_CHAN_ID1,          (uint16_t*)&g_adc1_result[HALL_VOLT2]},         // // 电流霍尔采样输入2
	{HAL_ADC_CHAN_ID2, 			(uint16_t*)&g_adc1_result[HALL_VOLT3]},	        // // 电流霍尔采样输入3
	{HAL_ADC_CHAN_ID3, 		    (uint16_t*)&g_adc2_result[MCU_TEMP_1]},	        // // 第1路温度采样输入
	{HAL_ADC_CHAN_ID4, 		    (uint16_t*)&g_adc1_result[MCU_TEMP_2]},	        // // 第2路温度采样输入
	{HAL_ADC_CHAN_ID5, 			(uint16_t*)&g_adc2_result[MCU_TEMP_3]},	        // // 第3路温度采样输入
	{HAL_ADC_CHAN_ID6, 			(uint16_t*)&g_adc1_result[MCU_TEMP_4]},	        // // 第4路温度采样输入
	{HAL_ADC_CHAN_ID7, 			(uint16_t*)&g_adc1_result[MCU_TEMP_5]},	        // // 第5路温度采样输入
	{HAL_ADC_CHAN_ID8, 			(uint16_t*)&g_adc2_result[MCU_TEMP_6]},	        // // 第6路温度采样输入    
	{HAL_ADC_CHAN_ID9, 			(uint16_t*)&g_adc2_result[MCU_IDC_VER]},	    // // 硬件版本识别    
	{HAL_ADC_CHAN_ID10, 		(uint16_t*)&g_adc2_result[MCU_PCB_TEMP]},	    // // PCB温度采集
	{HAL_ADC_CHAN_ID11, 		(uint16_t*)&g_adc2_result[MCU_24V_SAM]},	    // // 供电电源24V采集    
	{HAL_ADC_CHAN_ID12, 		(uint16_t*)&g_adc2_result[MCU_5V_SAM]},	        // // 系统5V电源采集(霍尔)  
    {HAL_ADC_CHAN_ID13, 		(uint16_t*)&g_adc1_result[MCU_12V_SAM]},	    // // 系统12V采集  
};

#define ADC_SAMPLE_CHANNEL_MAX      sizeof(g_adc_dma_map)/sizeof(g_adc_dma_map[0])

#ifdef BSP_USING_ADC1
/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static HAL_StatusTypeDef MX_ADC1_Init(ADC_HandleTypeDef* hadc)
{
    ADC_MultiModeTypeDef multimode = {0};
    ADC_ChannelConfTypeDef sConfig = {0};
//    ADC_AnalogWDGConfTypeDef AnalogWDGConfig = {0};
    HAL_StatusTypeDef ret = HAL_OK;
    /* Common config */
    hadc->Instance = ADC1;
    hadc->Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV16;
    hadc->Init.Resolution = ADC_RESOLUTION_12B;
    hadc->Init.DataAlign = ADC_DATAALIGN_RIGHT;
    hadc->Init.GainCompensation = 0;
    hadc->Init.ScanConvMode = ADC_SCAN_ENABLE;
    hadc->Init.EOCSelection = ADC_EOC_SEQ_CONV;
    hadc->Init.LowPowerAutoWait = DISABLE;
    hadc->Init.ContinuousConvMode = ENABLE;
    hadc->Init.NbrOfConversion = ADC1_CHNNEL_CNT;
    hadc->Init.DiscontinuousConvMode = DISABLE;
    hadc->Init.ExternalTrigConv = ADC_SOFTWARE_START;
    hadc->Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
    hadc->Init.DMAContinuousRequests = ENABLE;
    hadc->Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;
    hadc->Init.OversamplingMode = DISABLE;
    ret = HAL_ADC_Init(hadc);
    if (ret != HAL_OK)
    {
        log_e("Adc1Err%d\n", ret);
        return ret;
    }
    /* Configure the ADC multi-mode */
    multimode.Mode = ADC_MODE_INDEPENDENT;
    ret = HAL_ADCEx_MultiModeConfigChannel(hadc, &multimode);
    if (ret != HAL_OK)
    {
        log_e("Adc1EErr%d\n", ret);
        return ret;
    }
    
    /* Configure Regular Channel */
    sConfig.Channel = ADC_CHANNEL_7;
    sConfig.Rank = ADC_REGULAR_RANK_1;
    sConfig.SamplingTime = ADC_SAMPLETIME_247CYCLES_5;
    sConfig.SingleDiff = ADC_SINGLE_ENDED;
    sConfig.OffsetNumber = ADC_OFFSET_NONE;
    sConfig.Offset = 0;
    ret = HAL_ADC_ConfigChannel(hadc, &sConfig);
    if (ret != HAL_OK)
    {
        return ret;
    }
    
    /* Configure Regular Channel */
    sConfig.Channel = ADC_CHANNEL_8;
    sConfig.Rank = ADC_REGULAR_RANK_2;
    ret = HAL_ADC_ConfigChannel(hadc, &sConfig);
    if (ret != HAL_OK)
    {
        return ret;
    }
    
    /* Configure Regular Channel */
    sConfig.Channel = ADC_CHANNEL_3;
    sConfig.Rank = ADC_REGULAR_RANK_3;
    ret = HAL_ADC_ConfigChannel(hadc, &sConfig);
    if (ret != HAL_OK)
    {
        return ret;
    }
    
    /* Configure Regular Channel */
    sConfig.Channel = ADC_CHANNEL_4;
    sConfig.Rank = ADC_REGULAR_RANK_4;
    ret = HAL_ADC_ConfigChannel(hadc, &sConfig);
    if (ret != HAL_OK)
    {
        return ret;
    }
    
    sConfig.Channel = ADC_CHANNEL_12;
    sConfig.Rank = ADC_REGULAR_RANK_5;
    ret = HAL_ADC_ConfigChannel(hadc, &sConfig);
    if (ret != HAL_OK)
    {
        return ret;
    }    

    sConfig.Channel = ADC_CHANNEL_14;
    sConfig.Rank = ADC_REGULAR_RANK_6;
    ret = HAL_ADC_ConfigChannel(hadc, &sConfig);
    if (ret != HAL_OK)
    {
        return ret;
    }
//    AnalogWDGConfig.WatchdogNumber = ADC_ANALOGWATCHDOG_1;
//    AnalogWDGConfig.WatchdogMode = ADC_ANALOGWATCHDOG_ALL_REG;
//    AnalogWDGConfig.Channel = ADCx_CHANNELa;
//    AnalogWDGConfig.ITMode = ENABLE;
//    AnalogWDGConfig.HighThreshold = (4095 * 5/8);
//    AnalogWDGConfig.LowThreshold = (4095 * 1/8);
//    if (HAL_ADC_AnalogWDGConfig(hadc, &AnalogWDGConfig) != HAL_OK)
//    {
//        Error_Handler();
//    }
    return ret;
}
#endif

#ifdef BSP_USING_ADC2
/**
  * @brief ADC2 Initialization Function
  * @param None
  * @retval None
  */
static HAL_StatusTypeDef MX_ADC2_Init(ADC_HandleTypeDef* hadc)
{
    ADC_MultiModeTypeDef multimode = {0};    
    ADC_ChannelConfTypeDef sConfig = {0};
    HAL_StatusTypeDef ret = HAL_OK;
    /** Common config */
    hadc->Instance = ADC2;
    hadc->Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV16;
    hadc->Init.Resolution = ADC_RESOLUTION_12B;
    hadc->Init.DataAlign = ADC_DATAALIGN_RIGHT;
    hadc->Init.GainCompensation = 0;
    hadc->Init.ScanConvMode = ADC_SCAN_ENABLE;
    hadc->Init.EOCSelection = ADC_EOC_SEQ_CONV;
    hadc->Init.LowPowerAutoWait = DISABLE;
    hadc->Init.ContinuousConvMode = ENABLE;
    hadc->Init.NbrOfConversion = ADC2_CHNNEL_CNT;
    hadc->Init.DiscontinuousConvMode = DISABLE;
    hadc->Init.ExternalTrigConv = ADC_SOFTWARE_START;
    hadc->Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
    hadc->Init.DMAContinuousRequests = ENABLE;
    hadc->Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;
    hadc->Init.OversamplingMode = DISABLE;
    ret = HAL_ADC_Init(hadc);
    if (ret != HAL_OK)
    {
        log_e("Adc2Err%d\n", ret);
        return ret;
    }

    /* Configure the ADC multi-mode */
//    multimode.Mode = ADC_MODE_INDEPENDENT;
//    ret = HAL_ADCEx_MultiModeConfigChannel(hadc, &multimode);
//    if (ret != HAL_OK)
//    {
//        log_e("Adc2EErr%d\n", ret);
//        return ret;
//    }
    
    /* Configure Regular Channel */
    sConfig.Channel = ADC_CHANNEL_6;
    sConfig.Rank = ADC_REGULAR_RANK_1;
    sConfig.SamplingTime = ADC_SAMPLETIME_247CYCLES_5;
    sConfig.SingleDiff = ADC_SINGLE_ENDED;
    sConfig.OffsetNumber = ADC_OFFSET_NONE;
    sConfig.Offset = 0;
    ret = HAL_ADC_ConfigChannel(hadc, &sConfig);
    if (ret != HAL_OK)
    {
        return ret;
    }

    /** Configure Regular Channel */
    sConfig.Channel = ADC_CHANNEL_9;
    sConfig.Rank = ADC_REGULAR_RANK_2;
    ret = HAL_ADC_ConfigChannel(hadc, &sConfig);
    if (ret != HAL_OK)
    {
        return ret;
    }
    
    /** Configure Regular Channel */
    sConfig.Channel = ADC_CHANNEL_17;
    sConfig.Rank = ADC_REGULAR_RANK_3;
    ret = HAL_ADC_ConfigChannel(hadc, &sConfig);
    if (ret != HAL_OK)
    {
        return ret;
    }
    
    /** Configure Regular Channel */
    sConfig.Channel = ADC_CHANNEL_13;
    sConfig.Rank = ADC_REGULAR_RANK_4;
    ret = HAL_ADC_ConfigChannel(hadc, &sConfig);
    if (ret != HAL_OK)
    {
        return ret;
    }
    
    /* Configure Regular Channel */
    sConfig.Channel = ADC_CHANNEL_3;
    sConfig.Rank = ADC_REGULAR_RANK_5;
    ret = HAL_ADC_ConfigChannel(hadc, &sConfig);
    if (ret != HAL_OK)
    {
        return ret;
    }
    
    /* Configure Regular Channel */
    sConfig.Channel = ADC_CHANNEL_5;
    sConfig.Rank = ADC_REGULAR_RANK_6;
    ret = HAL_ADC_ConfigChannel(hadc, &sConfig);
    if (ret != HAL_OK)
    {
        return ret;
    }

        /* Configure Regular Channel */
    sConfig.Channel = ADC_CHANNEL_12;
    sConfig.Rank = ADC_REGULAR_RANK_7;
    ret = HAL_ADC_ConfigChannel(hadc, &sConfig);
    if (ret != HAL_OK)
    {
        return ret;
    }  

        /* Configure Regular Channel */
    sConfig.Channel = ADC_CHANNEL_11;
    sConfig.Rank = ADC_REGULAR_RANK_8;
    ret = HAL_ADC_ConfigChannel(hadc, &sConfig);
    if (ret != HAL_OK)
    {
        return ret;
    } 
    
    return ret;
}
#endif

#ifdef BSP_USING_ADC3
/**
 * @brief ADC3 Initialization Function
 * @param None
 * @retval None
 */
static HAL_StatusTypeDef MX_ADC3_Init(ADC_HandleTypeDef* hadc)
{
    ADC_MultiModeTypeDef multimode = {0};
    ADC_ChannelConfTypeDef sConfig = {0};
    HAL_StatusTypeDef ret = HAL_OK;
    /** Common config */
    hadc->Instance = ADC3;
    hadc->Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV32;
    hadc->Init.Resolution = ADC_RESOLUTION_12B;
    hadc->Init.DataAlign = ADC_DATAALIGN_RIGHT;
    hadc->Init.GainCompensation = 0;
    hadc->Init.ScanConvMode = ADC_SCAN_ENABLE;
    hadc->Init.EOCSelection = ADC_EOC_SEQ_CONV;
    hadc->Init.LowPowerAutoWait = DISABLE;
    hadc->Init.ContinuousConvMode = ENABLE;
    hadc->Init.NbrOfConversion = ADC3_CHNNEL_CNT;
    hadc->Init.DiscontinuousConvMode = DISABLE;
    hadc->Init.ExternalTrigConv = ADC_SOFTWARE_START;
    hadc->Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
    hadc->Init.DMAContinuousRequests = ENABLE;
    hadc->Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;
    hadc->Init.OversamplingMode = DISABLE;
    ret = HAL_ADC_Init(hadc);
    if (ret != HAL_OK)
    {
        log_e("Adc3Err%d\n", ret);
        return ret;
    }
    /* Configure the ADC multi-mode */
    multimode.Mode = ADC_MODE_INDEPENDENT;
    ret = HAL_ADCEx_MultiModeConfigChannel(hadc, &multimode);
    if (ret != HAL_OK)
    {
        log_e("Adc3EErr%d\n", ret);
        return ret;
    }
    
    /* Configure Regular Channel */
    sConfig.Channel = ADC_CHANNEL_1;
    sConfig.Rank = ADC_REGULAR_RANK_1;
    sConfig.SamplingTime = ADC_SAMPLETIME_247CYCLES_5;
    sConfig.SingleDiff = ADC_SINGLE_ENDED;
    sConfig.OffsetNumber = ADC_OFFSET_NONE;
    sConfig.Offset = 0;
    ret = HAL_ADC_ConfigChannel(hadc, &sConfig);
    if (ret != HAL_OK)
    {
        return ret;
    }

    /* Configure Regular Channel */
    sConfig.Channel = ADC_CHANNEL_4;
    sConfig.Rank = ADC_REGULAR_RANK_2;
    sConfig.SamplingTime = ADC_SAMPLETIME_247CYCLES_5;
    sConfig.SingleDiff = ADC_SINGLE_ENDED;
    sConfig.OffsetNumber = ADC_OFFSET_NONE;
    sConfig.Offset = 0;
    ret = HAL_ADC_ConfigChannel(hadc, &sConfig);
    if (ret != HAL_OK)
    {
        return ret;
    }

    /* Configure Regular Channel */
    sConfig.Channel = ADC_CHANNEL_12;
    sConfig.Rank = ADC_REGULAR_RANK_3;
    sConfig.SamplingTime = ADC_SAMPLETIME_247CYCLES_5;
    sConfig.SingleDiff = ADC_SINGLE_ENDED;
    sConfig.OffsetNumber = ADC_OFFSET_NONE;
    sConfig.Offset = 0;
    ret = HAL_ADC_ConfigChannel(hadc, &sConfig);
    if (ret != HAL_OK)
    {
        return ret;
    }    
    return ret;
}
#endif
/**
 * @brief stm32 adc Initialization Function
 * @param None
 * @retval None
 */
static HAL_StatusTypeDef stm32_adc_init(void)
{
    HAL_StatusTypeDef ret = HAL_OK;
    for (uint8_t i = 0; i < sizeof(stm32_adc_obj) / sizeof(stm32_adc_obj[0]); i++)
    {
        // init adc gpio and clock
        ret = HAL_ADC_MspInit(&stm32_adc_obj[i].adc_handle);
        if (ret != HAL_OK)
        {
            return ret;
        }
	#ifdef BSP_USING_ADC1
        // adc config
        if (ADC1 == stm32_adc_obj[i].adc_handle.Instance)
        {
            ret = MX_ADC1_Init(&stm32_adc_obj[i].adc_handle);
            if (ret != HAL_OK)
            {
                log_e("MxAdc1Err%d\n", ret);
                return ret;
            }
        }
	#endif

	#ifdef BSP_USING_ADC2
        if (ADC2 == stm32_adc_obj[i].adc_handle.Instance)
        {
            ret = MX_ADC2_Init(&stm32_adc_obj[i].adc_handle);
            if (ret != HAL_OK)
            {
                log_e("MxAdc2Err%d\n", ret);
                return ret;
            }
        }
	#endif

	#ifdef BSP_USING_ADC3
        if (ADC3 == stm32_adc_obj[i].adc_handle.Instance)
        {
            MX_ADC3_Init(&stm32_adc_obj[i].adc_handle);
            if (ret != HAL_OK)
            {
                log_e("MxAdc3Err%d\n", ret);
                return ret;
            }
        }
	#endif
    }
    return ret;
}

/**
  * Enable DMA controller clock
  */
static void stm32_adc_dma_Init(void)
{

    /* DMA controller clock enable */
    __HAL_RCC_DMAMUX1_CLK_ENABLE();
    __HAL_RCC_DMA1_CLK_ENABLE();

    /* DMA interrupt init */
#ifdef BSP_USING_ADC1
    HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
    // HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);
#endif
	
#ifdef BSP_USING_ADC2
    HAL_NVIC_SetPriority(DMA1_Channel2_IRQn, 0, 0);
    // HAL_NVIC_EnableIRQ(DMA1_Channel2_IRQn);
#endif
	
#ifdef BSP_USING_ADC3	
    HAL_NVIC_SetPriority(DMA1_Channel3_IRQn, 0, 0);
    // HAL_NVIC_EnableIRQ(DMA1_Channel3_IRQn);
#endif
}

/**
* @brief		ADC加载驱动,根据配置加载对应的ADC驱动
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @warning		系统启动时默认启动
*/
int32_t hal_adc_init(void)
{    
	if (!g_adc_status.is_init)
	{	
	#ifdef BSP_USING_ADC1
        memset((void *)g_adc1_result, 0, sizeof(uint16_t) * ADC1_CHNNEL_CNT);
		memset((void *)g_adc1_dma_buf, 0, sizeof(uint16_t) * ADC1_CHNNEL_CNT*ADC_SAMPLE_TIMES);
	#endif
		
	#ifdef BSP_USING_ADC2
        memset((void *)g_adc2_result, 0, sizeof(uint16_t) * ADC2_CHNNEL_CNT);
		memset((void *)g_adc2_dma_buf, 0, sizeof(uint16_t) * ADC2_CHNNEL_CNT*ADC_SAMPLE_TIMES);
	#endif
		
	#ifdef BSP_USING_ADC3
        memset((void *)g_adc3_result, 0, sizeof(uint16_t) * ADC3_CHNNEL_CNT);
        memset((void *)g_adc3_dma_buf, 0, sizeof(uint16_t) * ADC3_CHNNEL_CNT*ADC_SAMPLE_TIMES);
	#endif
		
		memset((void *)&g_adc_status, 0, sizeof(adc_status_t));
        stm32_adc_dma_Init();
        
        HAL_StatusTypeDef ret = HAL_OK;
        ret = stm32_adc_init();
        if (ret != HAL_OK)
        {
            log_e("StmAdcInitErr%d,retry\n", ret);
            ret = stm32_adc_init();
            if (ret != HAL_OK)
            {
                log_e("StmAdcInitErr%d\n", ret);
                return ret;
            }
        }
		g_adc_status.is_init = 1;
	}
	
	return SF_OK;
}

/**
* @brief		ADC删除驱动(跟据配置删除对应的驱动)
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
*/
int32_t hal_adc_deinit(void)
{
	if (g_adc_status.is_init)
	{
        for (uint8_t i = 0; i < sizeof(stm32_adc_obj) / sizeof(stm32_adc_obj[0]); i++)
        {
            HAL_ADC_MspDeInit(&stm32_adc_obj[i].adc_handle);
        }
		memset((void *)&g_adc_status, 0, sizeof(adc_status_t));
	}
	return SF_OK;
}

/**
* @brief		ADC功能从休眠中唤醒，恢复状态
* @param		[in] adc_no ADC虚拟编号 
* -# 0x00 - HAL_ADC1	
* -# 0x01 - HAL_ADC2		
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @warning		本接口调用后，需要把对应管脚恢复到正常状态 
*/
int32_t hal_adc_resume(uint32_t adc_no)
{
	int32_t ret;

    // if the device is not supended, return ok
	if (!SF_GET_BIT(g_adc_status.is_suspend, (1U << adc_no)))
    {
        return SF_OK;
    } 	
	// param check
	if (adc_no >= HAL_ADC_ID_MAX)
	{
		ret = SF_ERR_PARA;
		goto failed;
	} 

    SF_CLR_BIT(g_adc_status.is_suspend, (1U << adc_no));
	return SF_OK;

failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;
}
 
/**
* @brief		ADC功能进入休眠模式
* @param		[in] adc_no ADC虚拟编号 
* -# 0x00 - HAL_ADC1	
* -# 0x01 - HAL_ADC2		
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @warning		本接口调用后，需要把对应管脚也设置为低功耗模式
*/
int32_t hal_adc_suspend(uint32_t adc_no)
{
	int32_t ret;

	// param check
	if (adc_no >= HAL_ADC_ID_MAX)
	{
		ret = SF_ERR_PARA;
		goto failed;
	} 
    // if the device is supended, return ok
	if (SF_GET_BIT(g_adc_status.is_suspend, (1U << adc_no)))
    {
        return SF_OK;
    }    	

    HAL_ADC_MspDeInit(&stm32_adc_obj[adc_no].adc_handle);
    
    SF_SET_BIT(g_adc_status.is_suspend, (1U << adc_no));
	return SF_OK;

failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;
}

/**
* @brief		启动ADC配置
* @param		[in] adc_no ADC虚拟编号 
* -# 0x00 - HAL_ADC1	
* -# 0x01 - HAL_ADC2		
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @pre			执行hal_adc_enable后执行才有效。
*/
int32_t hal_adc_start_config(uint32_t adc_no)
{
    int32_t ret;
    
    // param check
	if (adc_no >= HAL_ADC_ID_MAX)
	{
		ret = SF_ERR_PARA;
		goto failed;
	} 
    
    // if the device is started, return ok
    if (SF_GET_BIT(g_adc_status.is_start, (1U << adc_no)))
    {
        return SF_OK;
    }   
    
    // Start adc calibration
    ret = HAL_ADCEx_Calibration_Start(&stm32_adc_obj[adc_no].adc_handle, ADC_SINGLE_ENDED);
    if (ret != HAL_OK)
    {
        log_e("[init]Adc%dCaliErr%d\n", adc_no, ret);
    }
    
#ifdef BSP_USING_ADC1
    // Start adc1 DMA
    if (ADC1 == stm32_adc_obj[adc_no].adc_handle.Instance)
    {
        ret = HAL_ADC_Start_DMA(&stm32_adc_obj[adc_no].adc_handle, 
                              (uint32_t*)&g_adc1_dma_buf[0]    , 
                              ADC1_DMA_BUF_SIZE);
        if (ret != HAL_OK)
        {
            goto failed;
        }
    }
#endif
	
#ifdef BSP_USING_ADC2
    // Start adc2 DMA
    if (ADC2 == stm32_adc_obj[adc_no].adc_handle.Instance)
    {
        HAL_ADC_Start_DMA(&stm32_adc_obj[adc_no].adc_handle, 
                              (uint32_t*)&g_adc2_dma_buf[0]    , 
                              ADC2_DMA_BUF_SIZE);
        if (ret != HAL_OK)
        {
            goto failed;
        }
    }
#endif
	
#ifdef BSP_USING_ADC3
    // Start adc3 DMA
    if (ADC3 == stm32_adc_obj[adc_no].adc_handle.Instance)
    {
        HAL_ADC_Start_DMA(&stm32_adc_obj[adc_no].adc_handle, 
                              (uint32_t*)&g_adc3_dma_buf[0]    , 
                              ADC3_DMA_BUF_SIZE);
        if (ret != HAL_OK)
        {
            goto failed;
        }
    }
#endif
	
    SF_SET_BIT(g_adc_status.is_start, (1U << adc_no));
    return SF_OK;
    
failed:
	log_e("Function[%s] Operation failed, adc%d ret = %d!\r\n", __FUNCTION__, adc_no, ret);
	return ret;
}

/**
* @brief		启动ADC(预留)
* @param		[in] adc_no ADC虚拟编号 
* -# 0x00 - HAL_ADC1	
* -# 0x01 - HAL_ADC2		
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败   
* @pre			执行hal_adc_enable后执行才有效。
*/
int32_t hal_adc_start(uint32_t adc_no)
{
    int32_t ret = hal_adc_start_config(adc_no);
    if (ret != 0)
    {
        log_e("[init]adc%dStaErr%d,Retry\n", adc_no, ret);
        ret = hal_adc_start_config(adc_no);
        if (ret != 0)
        {
            log_e("[init]adc%dStaErr%d\n", adc_no, ret);
        }
    }
    return ret;
}


/**
* @brief		停止ADC(预留)
* @param		[in] adc_no ADC虚拟编号 
* -# 0x00 - HAL_ADC1	
* -# 0x01 - HAL_ADC2		
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			接口未使用，默认返回HAL_OK
*/
int32_t hal_adc_stop(uint32_t adc_no)
{
	int32_t ret;
    
    // param check
	if ((adc_no >= HAL_ADC_ID_MAX))
	{
		ret = SF_ERR_PARA;
		goto failed;
	} 
    
    // if the device is started, return ok
    if (!SF_GET_BIT(g_adc_status.is_start, (1U << adc_no)))
    {
        return SF_OK;
    }   
    
    // Stop adc calibration
    //HAL_ADCEx_Calibration_Start(&g_hadc1, ADC_SINGLE_ENDED);
   
#ifdef BSP_USING_ADC1
    // Stop adc1 DMA
    if (ADC1 == stm32_adc_obj[adc_no].adc_handle.Instance)
    {
        ;
    }
#endif
	
#ifdef BSP_USING_ADC2
    // Stop adc2 DMA
    if (ADC2 == stm32_adc_obj[adc_no].adc_handle.Instance)
    {
        ;
    }
#endif
	
#ifdef BSP_USING_ADC3
    // Stop adc3 DMA
    if (ADC3 == stm32_adc_obj[adc_no].adc_handle.Instance)
    {
        ;
    }
#endif
	
    SF_CLR_BIT(g_adc_status.is_start, (1U << adc_no));
    return SF_OK;
    
failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;
}
 

/**
* @brief		设置ADC属性(预留)
* @param		[in] adc_no ADC虚拟编号 
* -# 0x00 - HAL_ADC1	
* -# 0x01 - HAL_ADC2		
* @param		[in] p_cfg 配置属性指针
* -# p_cfg->sampling_cycle 采样频率	
* -# p_cfg->convert_mode 转换模式		
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			接口未使用，默认返回SF_OK
*/
int32_t hal_adc_setup(uint32_t adc_no, hal_adc_config_t *p_cfg)
{
	return SF_OK;
}


/**
* @brief		读取ADC DMA对应数据表索引通道数据
* @param		[in] channel通道
* @param		[out] *p_value 读取的adc数据 
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败
* @pre			执行hal_adc_start后执行才有效。
*/
int32_t hal_adc_read(uint32_t channel, uint16_t *p_value)
{
	int32_t ret; 

	// param check
	if ((channel >= ADC_SAMPLE_CHANNEL_MAX) || (!p_value))
	{
		ret = SF_ERR_PARA;
		goto failed;
	} 	
	// if adc is not opened, return failed
//	if (!GET_BIT(g_adc_status.is_start, (1U << HAL_ADC1))
//		||!GET_BIT(g_adc_status.is_start, (1U << HAL_ADC2)))
//	{
//		ret = HAL_EPERM;
//		goto failed;
//	} 

	// 根据配置表格，完成数据映射...
	*p_value = *g_adc_dma_map[channel].result;
	return SF_OK;

failed:
	log_e("Function[%s] Operation failed, ret = %d!\r\n", __FUNCTION__, ret);
	return ret;
}


/**
* @brief		ADC中断回调函数（预留）  
* @param		[in] adc_no ADC虚拟编号 
* -# 0x00 - HAL_ADC1	
* -# 0x01 - HAL_ADC2		
* @param		[in] p_fcallback 回调函数  
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败  
* @pre			接口未使用，默认返回SF_OK
*/
int32_t hal_adc_set_irq(uint32_t adc_no, irq_adc_callback p_fcallback)
{
	return SF_OK;
}


/**
* @brief		扩展功能（预留） 
* @param		[in] adc_no ADC虚拟编号 
* -# 0x00 - HAL_ADC1	
* -# 0x01 - HAL_ADC2		
* @param		[in] cmd 控制命令  
* @param		[in] p_arg 控制参数   
* @return		执行结果
* @retval		SF_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @pre			接口未使用，默认返回SF_OK
*/
int32_t hal_adc_ioctl(uint32_t adc_no, uint8_t cmd, void* p_arg)
{
	return SF_OK;
}


// 函数：计算平均滤波后的值
static int32_t average_filter(int32_t data[], int32_t size) {
    int32_t sum = 0;
    for (int32_t i = 0; i < size; i++) {
        sum += data[i];
    }
    return (int32_t)sum / size;
}

#define FIRST_FILTER_K_B10 (1)  // 采样一阶滤波系数
#define FIRST_FILTER_MAX_K (10) // 采样一阶滤波分母

#define AVE_CNT (10) // 采样一阶滤波分母
/**
* @brief		adc滤波任务
* @return		void
*/
//void hal_adc_filter_task(void)
void hal_adc_filter_task(void* argument)
{
    uint8_t  i, j;
    static uint8_t first_flag = true; // 默认置位    
#ifdef BSP_USING_ADC1
    uint16_t adc1_value_sum[ADC1_CHNNEL_CNT] = {0};
    uint16_t adc1_dma_avg_result[ADC1_CHNNEL_CNT] = {0};              /* dma的平均化结果*/
    
    static int32_t out1_buf[AVE_CNT] = {0};
    static int32_t out2_buf[AVE_CNT] = {0};
    static uint16_t ring_buf_cnt = 0;    
    for (i = 0; i < ADC1_CHNNEL_CNT; i++)
    {
        for (j = 0; j < ADC_SAMPLE_TIMES; j++)
        {
            adc1_value_sum[i] += g_adc1_dma_buf[j][i];            
        }
        adc1_dma_avg_result[i] = (adc1_value_sum[i] + ADC_SAMPLE_TIMES/2) / ADC_SAMPLE_TIMES;
    }
#endif
	
#ifdef BSP_USING_ADC2
    uint16_t adc2_value_sum[ADC2_CHNNEL_CNT] = {0};
    uint16_t adc2_dma_avg_result[ADC2_CHNNEL_CNT] = {0};              /* dma的平均化结果*/
    
    for (i = 0; i < ADC2_CHNNEL_CNT; i++)
    {
        for (j = 0; j < ADC_SAMPLE_TIMES; j++)
        {
            adc2_value_sum[i] += g_adc2_dma_buf[j][i]; 
        }
        adc2_dma_avg_result[i] = (adc2_value_sum[i] + ADC_SAMPLE_TIMES/2) /ADC_SAMPLE_TIMES;
    }
#endif
	
#ifdef BSP_USING_ADC3
    uint16_t adc3_value_sum[ADC3_CHNNEL_CNT] = {0};
    uint16_t adc3_dma_avg_result[ADC3_CHNNEL_CNT] = {0};              /* dma的平均化结果*/    
    for (i = 0; i < ADC3_CHNNEL_CNT; i++)
    {
        for (j = 0; j < ADC_SAMPLE_TIMES; j++)
        {
            adc3_value_sum[i] += g_adc3_dma_buf[j][i]; 
        }
        adc3_dma_avg_result[i] = (adc3_value_sum[i] + ADC_SAMPLE_TIMES/2) /ADC_SAMPLE_TIMES;
    }
#endif 

    // 一阶滤波处理
    if (first_flag)
    {
        first_flag = false;               // 清除标志
        
#ifdef BSP_USING_ADC1        
        for (i = 0; i < ADC1_CHNNEL_CNT; i++)
        {
            g_adc1_result[i] = adc1_dma_avg_result[i];
        }
#endif
        
#ifdef BSP_USING_ADC2        
        for (i = 0; i < ADC2_CHNNEL_CNT; i++)
        {
            g_adc2_result[i] = adc2_dma_avg_result[i];
        }
#endif
        
#ifdef BSP_USING_ADC3        
        for (i = 0; i < ADC3_CHNNEL_CNT; i++)
        {
            g_adc3_result[i] = adc3_dma_avg_result[i];
        }
#endif
        
        memset(out1_buf, g_adc2_result[HALL_VOLT1], sizeof(out1_buf));
        memset(out2_buf, g_adc1_result[HALL_VOLT2], sizeof(out2_buf));           
        
    }
    else
    {
//        // 一阶滤波
//        g_adc1_result[HALL_VOLT2] = ((FIRST_FILTER_MAX_K - FIRST_FILTER_K_B10) * g_adc1_result[HALL_VOLT2] +
//                                     FIRST_FILTER_K_B10 * (adc1_dma_avg_result[HALL_VOLT2])/* + 5*/) / FIRST_FILTER_MAX_K /*+ FIRST_FILTER_K_B10*/;

//        g_adc2_result[HALL_VOLT1] = ((FIRST_FILTER_MAX_K - FIRST_FILTER_K_B10) * g_adc2_result[HALL_VOLT1] +
//                             FIRST_FILTER_K_B10 * (adc2_dma_avg_result[HALL_VOLT1]) /* + 5*/) / FIRST_FILTER_MAX_K /*+ FIRST_FILTER_K_B10*/;
        
        out1_buf[ring_buf_cnt] = adc2_dma_avg_result[HALL_VOLT1];
        out2_buf[ring_buf_cnt] = adc1_dma_avg_result[HALL_VOLT2];
        if(++ring_buf_cnt >= AVE_CNT)
        {
            ring_buf_cnt = 0;
        }

        g_adc1_result[HALL_VOLT2] = average_filter(out2_buf,AVE_CNT);
        g_adc2_result[HALL_VOLT1] = average_filter(out1_buf,AVE_CNT);
        
#ifdef BSP_USING_ADC1        
        for (i = HALL_VOLT3; i < ADC1_CHNNEL_CNT; i++)  //其余目前不做一阶滤波
        {
            g_adc1_result[i] = adc1_dma_avg_result[i];
        }
#endif
        
#ifdef BSP_USING_ADC2        
        for (i = MCU_TEMP_1; i < ADC2_CHNNEL_CNT; i++)
        {
            g_adc2_result[i] = adc2_dma_avg_result[i];
        }
#endif
        
#ifdef BSP_USING_ADC3        
        for (i = 0; i < ADC3_CHNNEL_CNT; i++)
        {
            g_adc3_result[i] = adc3_dma_avg_result[i];
        }
#endif
        
    }    
    
//    rt_kprintf("tim3: %d\n", hal_tick_get());
}

#ifdef BSP_USING_ADC1
void DMA1_Channel1_IRQHandler(void)
{
    HAL_DMA_IRQHandler(stm32_adc_obj[ADC1_INDEX].adc_handle.DMA_Handle);
}
#endif

#ifdef BSP_USING_ADC2
void DMA1_Channel2_IRQHandler(void)
{
    HAL_DMA_IRQHandler(stm32_adc_obj[ADC2_INDEX].adc_handle.DMA_Handle);
}
#endif

#ifdef BSP_USING_ADC3
void DMA1_Channel3_IRQHandler(void)
{
    HAL_DMA_IRQHandler(stm32_adc_obj[ADC3_INDEX].adc_handle.DMA_Handle);
}
#endif

#ifdef BSP_USING_ADC4
void DMA2_Channel3_IRQHandler(void)
{
    HAL_DMA_IRQHandler(stm32_adc_obj[ADC4_INDEX].adc_handle.DMA_Handle);
}
#endif

#ifdef BSP_USING_ADC5
void DMA3_Channel4_IRQHandler(void)
{
    HAL_DMA_IRQHandler(stm32_adc_obj[ADC5_INDEX].adc_handle.DMA_Handle);
}
#endif



/**
* @brief        adc_hal功能样例
* @param        argv 功能参数
* @return       返回结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败
*/
#ifdef RT_USING_FINSH
//#ifdef RT_USING_FINSH_DEBUG

static int hal_adc_sample(int argc, char *p_argv[])
{
	uint16_t adc_value;
    uint8_t  i, j;

    //MX_DMA_Init();
	hal_adc_init();
    

	for (i = 0; i < HAL_ADC_ID_MAX; i++)
	{	
		if(SF_OK != hal_adc_start(i))
		{
			return SF_ERR_NDEF;
		}
	}
    //while(1)
    {
	#ifdef BSP_USING_ADC1
        for (i = 0; i < ADC1_CHNNEL_CNT; i++)
        {
            rt_kprintf("dma1_buf[%d]:",i);	
            for (j = 0; j < ADC_SAMPLE_TIMES; j++)
            {
                rt_kprintf("%d ",g_adc1_dma_buf[j][i]);	
            }
            rt_kprintf("rslt:%d\r\n",g_adc1_result[i]);
        }
    #endif
		
	#ifdef BSP_USING_ADC2
        for (i = 0; i < ADC2_CHNNEL_CNT; i++)
        {
            rt_kprintf("dma2_buf[%d]:",i);
            for (j = 0; j < ADC_SAMPLE_TIMES; j++)
            {
                rt_kprintf("%d ",g_adc2_dma_buf[j][i]);            
            }
            rt_kprintf("rslt:%d\r\n",g_adc2_result[i]);
        }
	#endif
		
    #ifdef BSP_USING_ADC3
        for (i = 0; i < ADC3_CHNNEL_CNT; i++)
        {
            rt_kprintf("dma3_buf[%d]:",i);
            for (j = 0; j < ADC_SAMPLE_TIMES; j++)
            {
                rt_kprintf("%d ",g_adc3_dma_buf[j][i]);            
            }
            rt_kprintf("rslt:%d\r\n",g_adc3_result[i]);
        }
	#endif
        rt_kprintf("\r\n");
        
        for (uint8_t index = 0; index < ADC_SAMPLE_CHANNEL_MAX; index++)
        {
            if(SF_OK == hal_adc_read(index, &adc_value))
            {
                rt_kprintf("adc_index(%d): digital=%d, volt=%d.%03dv\r\n", index, adc_value, 
                            3000*adc_value/4095/1000, 3000*adc_value/4095%1000);				
            }
        }       
        rt_kprintf("\r\n");
    }
    return SF_OK;    
}
MSH_CMD_EXPORT(hal_adc_sample, hal_adc_sample <>);
//#endif
#endif


