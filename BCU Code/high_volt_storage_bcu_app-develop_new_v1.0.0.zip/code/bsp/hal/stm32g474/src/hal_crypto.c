#include <rtthread.h>
#include "hal_crypto.h"
#include "stdio.h"
#include "string.h"
#include "log.h"

/**@file  hal_crypto.c
* @brief       举例说明使用方法
* @author      chenenzhi 
* @date        2021/6/29 	
* @details  DEMO程序
* @code
int main(void)
{
    uint8_t temp[] = {0,1,2,3,4,5,6,7};
    crypto_ctx_t *ctx;
    uint32_t result = 0;
    crypto_crc_cfg_t cfg =
    {
        .last_val = 0xFFFFFFFF,
        .poly = 0x04C11DB7,
        .width = 32,
        .xorout = 0x00000000,
        .flags = 0,
    };

    ctx = crypto_crc_create(HWCRYPTO_CRC_CRC32, &cfg); 
    rt_crypto_crc_set_value(ctx, cfg.last_val);

    result = crypto_crc_update(ctx, temp, sizeof(temp));

    printf("result: %x \n", result);                

    crypto_crc_destroy(ctx);
}
* @endcode  
*/

/*
CRC算法名称	CRC-16/MODBUS
多项式公式				= x16 + x15 + x2 + 1
宽度width				= 16
多项式poly				= 0x8005
初始值init				= 0xFFFF
输入反转refin			= true
输出反转refout			= true
输出结果异或值xorout	= 0x0000
check					= 0x4B37
residue					= 0x0000
*/
const unsigned int crc16_table[256] = {
    0x0000, 0xc0c1, 0xc181, 0x0140, 0xc301, 0x03c0, 0x0280, 0xc241,
    0xc601, 0x06c0, 0x0780, 0xc741, 0x0500, 0xc5c1, 0xc481, 0x0440,
    0xcc01, 0x0cc0, 0x0d80, 0xcd41, 0x0f00, 0xcfc1, 0xce81, 0x0e40,
    0x0a00, 0xcac1, 0xcb81, 0x0b40, 0xc901, 0x09c0, 0x0880, 0xc841,
    0xd801, 0x18c0, 0x1980, 0xd941, 0x1b00, 0xdbc1, 0xda81, 0x1a40,
    0x1e00, 0xdec1, 0xdf81, 0x1f40, 0xdd01, 0x1dc0, 0x1c80, 0xdc41,
    0x1400, 0xd4c1, 0xd581, 0x1540, 0xd701, 0x17c0, 0x1680, 0xd641,
    0xd201, 0x12c0, 0x1380, 0xd341, 0x1100, 0xd1c1, 0xd081, 0x1040,
    0xf001, 0x30c0, 0x3180, 0xf141, 0x3300, 0xf3c1, 0xf281, 0x3240,
    0x3600, 0xf6c1, 0xf781, 0x3740, 0xf501, 0x35c0, 0x3480, 0xf441,
    0x3c00, 0xfcc1, 0xfd81, 0x3d40, 0xff01, 0x3fc0, 0x3e80, 0xfe41,
    0xfa01, 0x3ac0, 0x3b80, 0xfb41, 0x3900, 0xf9c1, 0xf881, 0x3840,
    0x2800, 0xe8c1, 0xe981, 0x2940, 0xeb01, 0x2bc0, 0x2a80, 0xea41,
    0xee01, 0x2ec0, 0x2f80, 0xef41, 0x2d00, 0xedc1, 0xec81, 0x2c40,
    0xe401, 0x24c0, 0x2580, 0xe541, 0x2700, 0xe7c1, 0xe681, 0x2640,
    0x2200, 0xe2c1, 0xe381, 0x2340, 0xe101, 0x21c0, 0x2080, 0xe041,
    0xa001, 0x60c0, 0x6180, 0xa141, 0x6300, 0xa3c1, 0xa281, 0x6240,
    0x6600, 0xa6c1, 0xa781, 0x6740, 0xa501, 0x65c0, 0x6480, 0xa441,
    0x6c00, 0xacc1, 0xad81, 0x6d40, 0xaf01, 0x6fc0, 0x6e80, 0xae41,
    0xaa01, 0x6ac0, 0x6b80, 0xab41, 0x6900, 0xa9c1, 0xa881, 0x6840,
    0x7800, 0xb8c1, 0xb981, 0x7940, 0xbb01, 0x7bc0, 0x7a80, 0xba41,
    0xbe01, 0x7ec0, 0x7f80, 0xbf41, 0x7d00, 0xbdc1, 0xbc81, 0x7c40,
    0xb401, 0x74c0, 0x7580, 0xb541, 0x7700, 0xb7c1, 0xb681, 0x7640,
    0x7200, 0xb2c1, 0xb381, 0x7340, 0xb101, 0x71c0, 0x7080, 0xb041,
    0x5000, 0x90c1, 0x9181, 0x5140, 0x9301, 0x53c0, 0x5280, 0x9241,
    0x9601, 0x56c0, 0x5780, 0x9741, 0x5500, 0x95c1, 0x9481, 0x5440,
    0x9c01, 0x5cc0, 0x5d80, 0x9d41, 0x5f00, 0x9fc1, 0x9e81, 0x5e40,
    0x5a00, 0x9ac1, 0x9b81, 0x5b40, 0x9901, 0x59c0, 0x5880, 0x9841,
    0x8801, 0x48c0, 0x4980, 0x8941, 0x4b00, 0x8bc1, 0x8a81, 0x4a40,
    0x4e00, 0x8ec1, 0x8f81, 0x4f40, 0x8d01, 0x4dc0, 0x4c80, 0x8c41,
    0x4400, 0x84c1, 0x8581, 0x4540, 0x8701, 0x47c0, 0x4680, 0x8641,
    0x8201, 0x42c0, 0x4380, 0x8341, 0x4100, 0x81c1, 0x8081, 0x4040,
};







//位逆转
static uint32_t bitrev(uint32_t input, int32_t bw)
{
	int32_t i;
	uint32_t var;
	var = 0;
	
    for ( i = 0; i < bw; i++)
    {
        if(input & 0x01)
        {
            var |= (1 << (bw - 1 - i));
        }
        input >>= 1;
    }
    return var;
}

//码表生成
static void crc32_init(uint32_t *p_table, uint32_t poly)
{
    int32_t i;
    int32_t j;
    uint32_t c;
 
    poly = bitrev(poly, 32);
    for (i = 0; i < 256; i++)
    {
        c = i;
        for (j = 0; j < 8; j++)
        {
            c = (c & 1) ? (poly ^ (c >> 1)) : (c >> 1);
        }
        p_table[i] = c;
    }
}
 


/**
* @brief		创建 CRC 上下文
* @param		[in] mode CRC模式
* -# CRYPTO_CRC_CUSTOM
* -# CRYPTO_CRC_CRC8
* -# CRYPTO_CRC_CRC16
* -# CRYPTO_CRC_CRC32
* -# CRYPTO_CRC_CCITT
* -# CRYPTO_CRC_DNP
* @param		[in] cfg CRC配置
* @return		返回crypto_ctx_t结构体
* @retval		NULL 执行失败
* @retval		非空 执行成功 
*/
crypto_ctx_t *crypto_crc_create(crypto_crc_mode_e mode, crypto_crc_cfg_t *cfg)
{
	crypto_ctx_t *ctx;
	
	if (mode == CRYPTO_CRC_CRC32 || mode == CRYPTO_CRC_CRC16)
	{
		;
	}
	else
	{
		return NULL;
	}
	
	ctx = (crypto_ctx_t *)rt_malloc(sizeof(crypto_ctx_t));
	if (ctx == NULL)
		return NULL;
	else
		memset(ctx, 0, sizeof(crypto_ctx_t));
		
	ctx->cfg = *cfg;
	
	if (mode == CRYPTO_CRC_CRC32)
	{// 动态生成表格
		ctx->crc_table = rt_malloc(256*sizeof(uint32_t));
		if (ctx->crc_table == NULL)
		{
			rt_free(ctx);
			log_e("crc32 rt_malloc fail\n");
			return NULL;
		}
		crc32_init(ctx->crc_table, ctx->cfg.poly);
	}
	else if (mode == CRYPTO_CRC_CRC16)
	{
		if (ctx->cfg.poly == 0x8005)	
			ctx->crc_table = (void *)crc16_table;
		else
		{
//			ctx->crc_table = (void *)rt_malloc(256*sizeof(uint16_t));
//			if (ctx->crc_table == NULL)
//			{
//				rt_free(ctx);
//				return NULL;
//			}
			log_e("crc16 cfg unsupport!\n");
			rt_free(ctx);
			return NULL;
		}
	}
	
	ctx->mode = mode;

	return ctx;
}


/**
* @brief		释放上下文
* @param		[in] ctx 创建的crypto_ctx_t结构体 
* @return		无
*/
void crypto_crc_destroy(crypto_ctx_t *ctx)
{
	if (ctx)
	{
		rt_free(ctx->crc_table);
		rt_free(ctx);
	}
	
	return;
}



/**
* @brief		计算一包数据
* @param		[in] ctx CRC上下文 
* @param		[in] input 缓冲区
* @param		[in] len 缓冲区长度 
* @return		执行结果
* @retval		0 执行失败
* @retval		非0 执行成功   
*/
int32_t crypto_crc_update(crypto_ctx_t *ctx, const uint8_t *input, uint32_t len)
{
	uint32_t i;
    uint8_t index;
    uint8_t *p;
    uint32_t *p_crc_table = (uint32_t *)(ctx->crc_table);
    
    if (ctx == NULL)
    	return -1;
    
    p = (uint8_t*)input;
    for (i = 0; i < len; i++)
    {
        index = (*p ^ ctx->cfg.last_val);
        ctx->cfg.last_val = (ctx->cfg.last_val >> 8) ^ p_crc_table[index];
        p++;
    }
    
    return 0;
}


/**
* @brief		设置上下文计算数据
* @param		[in] ctx CRC上下文 
* @param		[in] crc_value CRC计算值
* @return		执行结果
* @retval		HAL_OK 成功  
* @retval		HAL_EIO 失败 
*/
void rt_crypto_crc_set_value(crypto_ctx_t *ctx, uint32_t crc_value)
{
    if (ctx)
    {
    	ctx->cfg.last_val = crc_value;
    }
}





