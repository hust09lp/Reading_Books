#include <board.h>
#include <string.h>
#include <rtthread.h>
#include <rtdevice.h>
#include "hal_pm.h"
#include "pin_config.h"
#include "board.h"
#include "log.h"
#include "stm32g4xx_hal_rtc.h"
#include "sofar_errors.h"
#include "data_types.h"
/**
  * @brief  Configures system clock after wake-up from stop: enable HSE, PLL
  *         and select PLL as system clock source.
  * @param  None
  * @retval None
  */
static void SYSCLKConfig_STOP(void)
{
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    uint32_t pFLatency = 0;

    /* Enable Power Control clock */
    __HAL_RCC_PWR_CLK_ENABLE();

    /* Get the Oscillators configuration according to the internal RCC registers */
    HAL_RCC_GetOscConfig(&RCC_OscInitStruct);

    /* After wake-up from stop reconfigure the system clock: Enable HSE and PLL */
    RCC_OscInitStruct.OscillatorType  = RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState        = RCC_HSE_ON;
    RCC_OscInitStruct.PLL.PLLState    = RCC_PLL_ON;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    {
        Error_Handler();
    }

    /* Get the Clocks configuration according to the internal RCC registers */
    HAL_RCC_GetClockConfig(&RCC_ClkInitStruct, &pFLatency);

    /* Select PLL as system clock source and keep HCLK, PCLK1 and PCLK2 clocks dividers as before */
    RCC_ClkInitStruct.ClockType     = RCC_CLOCKTYPE_SYSCLK;
    RCC_ClkInitStruct.SYSCLKSource  = RCC_SYSCLKSOURCE_PLLCLK;
    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, pFLatency) != HAL_OK)
    {
        Error_Handler();
    }
}




/**
* @brief		电源管理模块加载驱动
* @return		执行结果
* @retval		SF_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_pm_init(void)
{
    // Enable Power Clock
    __HAL_RCC_PWR_CLK_ENABLE();
    // 关闭调试模式下不进人stop模式,防止keil调试时进不了低功耗模式
    HAL_DBGMCU_DisableDBGStopMode();
	
	return SF_OK;
}
INIT_DEVICE_EXPORT(hal_pm_init);


/**
* @brief		电源管理模块删除驱动
* @return		执行结果
* @retval		SF_OK 成功
* @retval		HAL_EIO 失败 
*/
int32_t hal_pm_deinit(void)
{

	return SF_OK;
}


/**
* @brief		请求不进入休眠的锁    
* @warning  	
* -# hal_pm_request_lock和rt_pm_release_lock需要成对出现
* -# hal_pm_request_lock多次调用会累加，导致系统无法进入休眠模式
*/
void hal_pm_request_lock(void)
{
	return;
}



/**
* @brief		释放休眠模式    
* @warning
* -# hal_pm_request_lock和hal_pm_release_lock需要成对出现
* -# hal_pm_request_lock多次调用会累加，导致系统无法进入休眠模式
*/
void hal_pm_release_lock(void)
{
	return;
}


/**
* @brief		设置进入/退出休眠模式的回调通知
* @param		[in] notify 应用的回调函数
* @param		[in] data 私有数据 
* @pre			执行hal_pm_init后执行才有效。
*/
void hal_pm_notify_set(void (*notify)(uint8_t event, uint8_t mode, void *data), void *data)
{
	return;
}



/**
* @brief		设置运行模式
* @param		[in] run_mode 运行模式
* -# HAL_PM_ENTER_SLEEP = 进入休眠模式
* -# HAL_PM_EXIT_SLEEP = 退出休眠模式
* @pre			执行hal_pm_init后执行才有效。
*/
int32_t hal_pm_run_enter(uint8_t run_mode)
{
    if (run_mode == HAL_PM_ENTER_SLEEP)
    {
        /* Enter stop 1 mode */
        HAL_PWREx_EnterSTOP1Mode(PWR_STOPENTRY_WFI);
    }
    else if (run_mode == HAL_PM_EXIT_SLEEP)
    {
        /* Configure system clock after wake-up from stop: enable HSE, PLL and select
        PLL as system clock source (HSE and PLL are disabled in stop mode) */
        for (uint32_t i = 0; i < 100; i++)
        {
            __NOP();
        }
        SYSCLKConfig_STOP();
    }
    else
    {
        return SF_ERR_PARA;
    }

	return SF_OK;
}


/**
* @brief		扩展功能 
* @param		[in] dev_no 设备端口号  
* @param		[in] cmd 控制命令  
* @param		[in] arg 控制参数   
* @return		执行结果
* @retval		SF_OK 成功    
* @retval		<0 失败原因  
*/
int32_t hal_pm_ioctl(int32_t dev_no, uint8_t cmd, void* arg)
{
	return SF_OK;
}





