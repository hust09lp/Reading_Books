#include <board.h>
#include <rtthread.h>
#include <rtdevice.h>
#include "hal_gpio.h"
#include "hal_hw_i2c.h"
#include "string.h"
#include "osif.h"
#include "log.h"
#include "sofar_errors.h"
#include "hal_public.h"

#ifdef BSP_USING_HW_I2C

#ifdef BSP_USING_HW_I2C3
static void MX_I2C3_Init(void);
#endif
#ifdef BSP_USING_HW_I2C4
static void MX_I2C4_Init(void);
#endif
#define I2C_TIMEOUT_WR_RD   300
typedef struct
{
	I2C_HandleTypeDef  i2c_handle;
    uint32_t baud_rate;
	const GPIO_TypeDef* scl_gpio_port;
    const uint16_t scl_gpio_pin;
    const GPIO_TypeDef* sda_gpio_port;
    const uint16_t sda_gpio_pin;
	os_mutex_id_t mutex_id;
	const os_mutex_attr_t i2c_mutex_attr;
	void (*p_init)(void);
}hw_i2c_bus_t;

typedef struct{
	uint8_t is_init;	
	uint8_t is_open;	
}hw_i2c_status_t;

static hw_i2c_status_t g_hw_i2c_status = {0};

static hw_i2c_bus_t g_hw_i2c_bus[] =
{
#ifdef BSP_USING_HW_I2C3

	{
		.baud_rate = I2C_400K_BAUD,
		.scl_gpio_port = GPIOC,
		.scl_gpio_pin = GPIO_PIN_8,
		.sda_gpio_port = GPIOC,
		.sda_gpio_pin = GPIO_PIN_9,
		.i2c_mutex_attr = {"hw_i2c3_mtx",0,0,0},
		.p_init = MX_I2C3_Init,
	},
#endif

#ifdef BSP_USING_HW_I2C4

	{
		.baud_rate = I2C_400K_BAUD,
		.scl_gpio_port = GPIOC,
		.scl_gpio_pin = GPIO_PIN_6,
		.sda_gpio_port = GPIOC,
		.sda_gpio_pin = GPIO_PIN_7,
		.i2c_mutex_attr = {"hw_i2c4_mtx",0,0,0},
		.p_init = MX_I2C4_Init,
	},
#endif	
};

static uint32_t g_i2c_err_cnt = 0;
/**
 * This function initializes the i2c pin.
 *
 * @param Stm32 i2c dirver class.
 */
static void hw_i2c_gpio_init(hw_i2c_bus_t *i2c_bus)
{
	GPIO_InitTypeDef GPIO_InitStruct;

    /* Configure GPIO_InitStructure */
    GPIO_InitStruct.Pin = i2c_bus->scl_gpio_pin;
    //GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	
	HAL_GPIO_Init((GPIO_TypeDef*)i2c_bus->scl_gpio_port, &GPIO_InitStruct);

    
    GPIO_InitStruct.Pin = i2c_bus->sda_gpio_pin;
	HAL_GPIO_Init((GPIO_TypeDef*)i2c_bus->sda_gpio_port, &GPIO_InitStruct);
    
	HAL_GPIO_WritePin((GPIO_TypeDef*)i2c_bus->scl_gpio_port, i2c_bus->scl_gpio_pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin((GPIO_TypeDef*)i2c_bus->scl_gpio_port, i2c_bus->sda_gpio_pin, GPIO_PIN_SET);
}
/**
 * This function sets the sda pin.
 *
 * @param Stm32 config class.
 * @param The sda pin state.
 */
static void hw_set_sda(hw_i2c_bus_t *i2c_bus, rt_int32_t state)
{
    if (state)
    {
		HAL_GPIO_WritePin((GPIO_TypeDef*)i2c_bus->scl_gpio_port, i2c_bus->sda_gpio_pin, GPIO_PIN_SET);
    }
    else
    {
		HAL_GPIO_WritePin((GPIO_TypeDef*)i2c_bus->scl_gpio_port, i2c_bus->sda_gpio_pin, GPIO_PIN_RESET);
    }
}

/**
 * This function sets the scl pin.
 *
 * @param Stm32 config class.
 * @param The scl pin state.
 */
static void hw_set_scl(hw_i2c_bus_t *i2c_bus, rt_int32_t state)
{
    if (state)
    {
		HAL_GPIO_WritePin((GPIO_TypeDef*)i2c_bus->scl_gpio_port, i2c_bus->scl_gpio_pin, GPIO_PIN_SET);
    }
    else
    {
		HAL_GPIO_WritePin((GPIO_TypeDef*)i2c_bus->scl_gpio_port, i2c_bus->scl_gpio_pin, GPIO_PIN_RESET);
    }
}
/**
 * This function gets the sda pin state.
 *
 * @param The sda pin state.
 */
static rt_int32_t hw_get_sda(hw_i2c_bus_t *i2c_bus)
{
	return HAL_GPIO_ReadPin((GPIO_TypeDef*)i2c_bus->scl_gpio_port,i2c_bus->sda_gpio_pin);
}
/**
 * The time delay function.
 *
 * @param microseconds.
 */
static void hw_i2c_us_delay(rt_uint32_t us)
{
    rt_uint32_t ticks;
    rt_uint32_t told, tnow, tcnt = 0;
    rt_uint32_t reload = SysTick->LOAD;

    ticks = us * reload / (1000000 / RT_TICK_PER_SECOND);
    told = SysTick->VAL;
    while (1)
    {
        tnow = SysTick->VAL;
        if (tnow != told)
        {
            if (tnow < told)
            {
                tcnt += told - tnow;
            }
            else
            {
                tcnt += reload - tnow + told;
            }
            told = tnow;
            if (tcnt >= ticks)
            {
                break;
            }
        }
    }
}
/*
 *@brief i2c bus unlock
 */
static int32_t hw_i2c_bus_unlock(hw_i2c_bus_t *i2c_bus)
{
    int32_t i = 0;

    //if (HAL_GPIO_LOW == hw_get_sda(i2c_bus))
    {
		hw_set_sda(i2c_bus, HAL_GPIO_HIGH);
        while (i++ < 9)
        {
            hw_set_scl(i2c_bus, HAL_GPIO_HIGH);
            hw_i2c_us_delay(1);
            hw_set_scl(i2c_bus, HAL_GPIO_LOW);
            hw_i2c_us_delay(1);
        }
    }
    
    if (HAL_GPIO_LOW == hw_get_sda(i2c_bus))
    {
        return -1;
    }

    return SF_OK;
}

/*
 *@brief i2c Stop
 */
static void hw_i2c_stop(hw_i2c_bus_t *i2c_bus)
{
    hw_set_scl(i2c_bus, HAL_GPIO_LOW);
    hw_set_sda(i2c_bus, HAL_GPIO_LOW);
    hw_i2c_us_delay(1);
    hw_set_scl(i2c_bus, HAL_GPIO_HIGH);
    hw_i2c_us_delay(1);
    hw_set_sda(i2c_bus, HAL_GPIO_HIGH);
    hw_i2c_us_delay(1);
}

#ifdef BSP_USING_HW_I2C3
/**
  * @brief I2C3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C3_Init(void)
{

  /* USER CODE BEGIN I2C3_Init 0 */

  /* USER CODE END I2C3_Init 0 */

  /* USER CODE BEGIN I2C3_Init 1 */

  /* USER CODE END I2C3_Init 1 */
  g_hw_i2c_bus[HAL_HW_I2C3].i2c_handle.Instance = I2C3;
  g_hw_i2c_bus[HAL_HW_I2C3].i2c_handle.Init.Timing = g_hw_i2c_bus[HAL_HW_I2C3].baud_rate;
  g_hw_i2c_bus[HAL_HW_I2C3].i2c_handle.Init.OwnAddress1 = 0;
  g_hw_i2c_bus[HAL_HW_I2C3].i2c_handle.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  g_hw_i2c_bus[HAL_HW_I2C3].i2c_handle.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  g_hw_i2c_bus[HAL_HW_I2C3].i2c_handle.Init.OwnAddress2 = 0;
  g_hw_i2c_bus[HAL_HW_I2C3].i2c_handle.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  g_hw_i2c_bus[HAL_HW_I2C3].i2c_handle.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  g_hw_i2c_bus[HAL_HW_I2C3].i2c_handle.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&g_hw_i2c_bus[HAL_HW_I2C3].i2c_handle) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&g_hw_i2c_bus[HAL_HW_I2C3].i2c_handle, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&g_hw_i2c_bus[HAL_HW_I2C3].i2c_handle, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C3_Init 2 */

  /* USER CODE END I2C3_Init 2 */

}
#endif

#ifdef BSP_USING_HW_I2C4
/**
  * @brief I2C4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C4_Init(void)
{

  /* USER CODE BEGIN I2C4_Init 0 */

  /* USER CODE END I2C4_Init 0 */

  /* USER CODE BEGIN I2C4_Init 1 */

  /* USER CODE END I2C4_Init 1 */
  g_hw_i2c_bus[HAL_HW_I2C4].i2c_handle.Instance = I2C4;
  g_hw_i2c_bus[HAL_HW_I2C4].i2c_handle.Init.Timing = g_hw_i2c_bus[HAL_HW_I2C4].baud_rate;
  g_hw_i2c_bus[HAL_HW_I2C4].i2c_handle.Init.OwnAddress1 = 0;
  g_hw_i2c_bus[HAL_HW_I2C4].i2c_handle.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  g_hw_i2c_bus[HAL_HW_I2C4].i2c_handle.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  g_hw_i2c_bus[HAL_HW_I2C4].i2c_handle.Init.OwnAddress2 = 0;
  g_hw_i2c_bus[HAL_HW_I2C4].i2c_handle.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  g_hw_i2c_bus[HAL_HW_I2C4].i2c_handle.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  g_hw_i2c_bus[HAL_HW_I2C4].i2c_handle.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&g_hw_i2c_bus[HAL_HW_I2C4].i2c_handle) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&g_hw_i2c_bus[HAL_HW_I2C4].i2c_handle, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&g_hw_i2c_bus[HAL_HW_I2C4].i2c_handle, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C4_Init 2 */

  /* USER CODE END I2C4_Init 2 */

}
#endif

static int32_t hal_hw_i2c_single_init(uint8_t i2c_no)
{
	int32_t ret = SF_OK;
	if (i2c_no >= HAL_HW_I2C_MAX) 
	{
		return SF_ERR_NO_OBJECT;
	}
	if (SF_GET_BIT(g_hw_i2c_status.is_init, (1u << i2c_no)) == 1)
    {
        return SF_OK;
    }   
	// 为防止硬件IIC锁死，先初始化成GPIO，解锁
	hw_i2c_gpio_init(&g_hw_i2c_bus[i2c_no]);
	for (uint8_t i = 0; i < 3; i++)
	{
		ret = hw_i2c_bus_unlock(&g_hw_i2c_bus[i2c_no]);
		if (SF_OK == ret)
		{
			break;
		}
	}
	if (ret != SF_OK)
	{
		return SF_ERR_BUSY;
	}
	hw_i2c_stop(&g_hw_i2c_bus[i2c_no]);
	// i2c init
	g_hw_i2c_bus[i2c_no].p_init();
	// mutex init
	g_hw_i2c_bus[i2c_no].mutex_id = os_mutex_new(&(g_hw_i2c_bus[i2c_no].i2c_mutex_attr));
	if (g_hw_i2c_bus[i2c_no].mutex_id == NULL)
	{
		rt_kprintf("i2c%d mutex create fail\n",i2c_no);
		return SF_ERR_NDEF;
	}
	
    SF_SET_BIT(g_hw_i2c_status.is_init, (1u << i2c_no));    
	return SF_OK;
}

/**
* @brief		I2C加载驱动
* @return		执行结果
* @retval		SF_OK 成功
* @retval		SF_ERR_NO_OBJECT 失败 
*/
int32_t hal_hw_i2c_init(void)
{
	uint8_t i;
	int32_t ret = SF_OK;
	for (i = 0; i < ITEM_NUM(g_hw_i2c_bus); i++)
	{
		ret |= hal_hw_i2c_single_init(i);
	}
	return ret;
}

INIT_BOARD_EXPORT(hal_hw_i2c_init);

static int32_t hal_hw_i2c_single_deinit(uint8_t i2c_no)
{
	if (i2c_no >= HAL_HW_I2C_MAX) 
	{
		return SF_ERR_NO_OBJECT;
	}
	if (SF_GET_BIT(g_hw_i2c_status.is_init, (1u << i2c_no)) == 0)
    {
        return SF_OK;
    }  
	if (g_hw_i2c_bus[i2c_no].mutex_id)
	{
		os_mutex_delete(g_hw_i2c_bus[i2c_no].mutex_id);
		g_hw_i2c_bus[i2c_no].mutex_id = NULL;
	}
	HAL_I2C_DeInit(&g_hw_i2c_bus[i2c_no].i2c_handle);
	
	SF_CLR_BIT(g_hw_i2c_status.is_init, (1u << i2c_no));
	return SF_OK;
}
/**
* @brief		I2C删除驱动
* @return		执行结果
* @retval		SF_OK 成功
* @retval		SF_ERR_NO_OBJECT 失败 
*/
int32_t hal_hw_i2c_deinit(void)
{
    uint8_t i;
	int32_t ret = SF_OK;	
	for (i = 0; i < ITEM_NUM(g_hw_i2c_bus); i++)
	{
		ret |= hal_hw_i2c_single_deinit(i);
	}
	return ret;
}

/**
* @brief		I2C发数据 
* @param		[in] i2c_no 虚拟I2C端口号   
* @param		[in] dev_addr 设备地址  
* @param		[in] buf 缓冲区指针  
* @param		[in] len 缓冲区长度  
* @return		执行结果
* @retval		>0 发送数据长度(阻塞式)  
* @retval		=0 数据待发送(非阻塞式)，使用hal_i2c_query查询发送完成情况     
* @retval		<0 失败原因   
* @pre			执行hal_i2c_open后执行才有效 
*/
int32_t hal_hw_i2c_write(uint32_t i2c_no, uint16_t dev_addr, uint8_t *buf, uint32_t len)
{
	uint32_t ret = HAL_OK;
	hw_i2c_bus_t *i2c_bus;
	
	if (i2c_no >= HAL_HW_I2C_MAX) 
	{
		return SF_ERR_NO_OBJECT;
	}
	
	if (SF_GET_BIT(g_hw_i2c_status.is_open, (1u << i2c_no)) == 0)
    {
        return SF_ERR_OPEN;
    }
    i2c_bus = &g_hw_i2c_bus[i2c_no];
    
    os_mutex_acquire(i2c_bus->mutex_id, OS_WAIT_FOREVER);
    ret = HAL_I2C_Master_Transmit(&i2c_bus->i2c_handle, dev_addr, buf, len, I2C_TIMEOUT_WR_RD);
	os_mutex_release(i2c_bus->mutex_id);	
	if (HAL_OK == ret)
	{
        g_i2c_err_cnt = 0;
		return len;
	}
	else
	{
		if (HAL_BUSY == ret)
		{
			hal_hw_i2c_single_deinit(i2c_no);			
			hal_hw_i2c_single_init(i2c_no);
            if (0 == (g_i2c_err_cnt % 100))
            {
                log_e("i2cWrReset%ld\n", g_i2c_err_cnt);
            }
            g_i2c_err_cnt++;
		}
		return SF_ERR_WR;
	}
}

/**
* @brief		I2C读数据 
* @param		[in] i2c_no 虚拟I2C端口号   
* @param		[in] dev_addr 设备地址  
* @param		[in] buf 缓冲区指针  
* @param		[in] len 缓冲区长度  
* @return		执行结果
* @retval		>0 接收数据长度  
* @retval		=0 数据待接收(非阻塞式)，使用hal_i2c_query查询接收完成情况      
* @retval		<0 失败原因   
* @pre			执行hal_i2c_open后执行才有效 
*/
int32_t hal_hw_i2c_read(uint32_t i2c_no, uint16_t dev_addr, uint8_t *buf, uint32_t len)
{
	uint32_t ret = HAL_OK;
	hw_i2c_bus_t *i2c_bus;
	
	if (i2c_no >= HAL_HW_I2C_MAX) 
	{
		return SF_ERR_NO_OBJECT;
	}
	
	if (SF_GET_BIT(g_hw_i2c_status.is_open, (1u << i2c_no)) == 0)
    {
        return SF_ERR_OPEN;
    }
    i2c_bus = &g_hw_i2c_bus[i2c_no];

    os_mutex_acquire(i2c_bus->mutex_id, OS_WAIT_FOREVER);
    ret = HAL_I2C_Master_Receive(&i2c_bus->i2c_handle, dev_addr, buf, len, I2C_TIMEOUT_WR_RD);
   	os_mutex_release(i2c_bus->mutex_id);
	if (HAL_OK == ret)
	{
		return len;
	}
	else
	{
		if (HAL_BUSY == ret)
		{
			hal_hw_i2c_single_deinit(i2c_no);			
			hal_hw_i2c_single_init(i2c_no);
			log_e("i2c rd reset\n");
		}
		return SF_ERR_RD;
	}
}

/**
* @brief		打开I2C功能  
* @param		[in] i2c_no 虚拟I2C端口号 
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		SF_ERR_NO_OBJECT 失败   
* @warning 		本接口只初始化I2C总线接口 
*/
int32_t hal_hw_i2c_open(uint32_t i2c_no)
{

     if (i2c_no >= HAL_HW_I2C_MAX) 
	{
		return SF_ERR_NO_OBJECT;
	}
	if (SF_GET_BIT(g_hw_i2c_status.is_init, (1U << i2c_no)) == 0)
    {
        return SF_ERR_NO_READY; // 未初始化，返回失败
    }    
	if (SF_GET_BIT(g_hw_i2c_status.is_open, (1U << i2c_no)) == 0)
    {
        SET_BIT(g_hw_i2c_status.is_open, (1U << i2c_no));
    }
     
   	return SF_OK;
}

/**
* @brief		关闭I2C功能  
* @param		[in] i2c_no 虚拟I2C端口号 
* @return		执行结果
* @retval		SF_OK 成功  
* @retval		SF_ERR_NO_OBJECT 失败   
* @warning 		本接口调用后，需要把对应管脚也设置为低功耗模式 
*/
int32_t hal_hw_i2c_close(uint32_t i2c_no)
{
	
	if (i2c_no >= HAL_HW_I2C_MAX) 
	{
		return SF_ERR_NO_OBJECT;
	}
	if (SF_GET_BIT(g_hw_i2c_status.is_init, (1U << i2c_no)) == 0)
    {
        return SF_ERR_NO_READY; // 未初始化，返回失败
    }   	
	if (SF_GET_BIT(g_hw_i2c_status.is_open, (1u << i2c_no)) != 0)
    {
        SF_CLR_BIT(g_hw_i2c_status.is_open, (1u << i2c_no));
    }    

	return SF_OK;
}



#if 1	// EERPOM I2C的测试代码

#define EEPROM_ADDR 0xa0
#define EEPROM_I2C_NO HAL_HW_I2C4
/**
 * @brief		AT24C02任意地址读一个字节数据
 * @param		addr —— 读数据的地址（0-255）
 * @param		read_buf —— 存放读取数据的地址
 * @retval		成功 —— HAL_OK
*/
uint8_t At24c02_Read_Byte(uint16_t addr, uint8_t* read_buf)
{
	return HAL_I2C_Mem_Read(&g_hw_i2c_bus[EEPROM_I2C_NO].i2c_handle, EEPROM_ADDR, addr, I2C_MEMADD_SIZE_16BIT, read_buf, 1, I2C_TIMEOUT_WR_RD);
}

/**
 * @brief		AT24C02任意地址写一个字节数据
 * @param		addr —— 写数据的地址（0-255）
 * @param		dat  —— 存放写入数据的地址
 * @retval		成功 —— HAL_OK
*/
uint8_t At24c02_Write_Byte(uint16_t addr, uint8_t* dat)
{
	HAL_I2C_Mem_Write(&g_hw_i2c_bus[EEPROM_I2C_NO].i2c_handle, EEPROM_ADDR, addr, I2C_MEMADD_SIZE_16BIT, dat, 1, I2C_TIMEOUT_WR_RD);
	/* 此处延时应大于4ms，等待芯片内部写完成 */
	os_delay(5);
	return true;
}

/**
 * @brief		AT24C02任意地址连续写多个字节数据
 * @param		addr —— 写数据的地址（0-255）
 * @param		dat  —— 存放写入数据的地址
 * @retval		成功 —— HAL_OK
*/
uint8_t At24c02_Write_Amount_Byte(uint16_t addr, uint8_t* dat, uint16_t size)
{
    uint8_t i = 0;
    uint16_t cnt = 0;		//写入字节计数
    
    /* 对于起始地址，有两种情况，分别判断 */
    if(0 == addr % 8 )
    {
        /* 起始地址刚好是页开始地址 */
        
        /* 对于写入的字节数，有两种情况，分别判断 */
        if(size <= 8)
        {
            //写入的字节数不大于一页，直接写入
            return HAL_I2C_Mem_Write(&g_hw_i2c_bus[EEPROM_I2C_NO].i2c_handle, EEPROM_ADDR, addr, I2C_MEMADD_SIZE_16BIT, dat, size, 0xFFFF);
        }
        else
        {
            //写入的字节数大于一页，先将整页循环写入
            for(i = 0;i < size/8; i++)
            {
                HAL_I2C_Mem_Write(&g_hw_i2c_bus[EEPROM_I2C_NO].i2c_handle, EEPROM_ADDR, addr, I2C_MEMADD_SIZE_16BIT, &dat[cnt], 8, 0xFFFF);
                addr += 8;
                cnt += 8;
            }
            //将剩余的字节写入
            return HAL_I2C_Mem_Write(&g_hw_i2c_bus[EEPROM_I2C_NO].i2c_handle, EEPROM_ADDR, addr, I2C_MEMADD_SIZE_16BIT, &dat[cnt], size - cnt, 0xFFFF);
        }
    }
    else
    {
        /* 起始地址偏离页开始地址 */
        /* 对于写入的字节数，有两种情况，分别判断 */
        if(size <= (8 - addr%8))
        {
            /* 在该页可以写完 */
            return HAL_I2C_Mem_Write(&g_hw_i2c_bus[EEPROM_I2C_NO].i2c_handle, EEPROM_ADDR, addr, I2C_MEMADD_SIZE_16BIT, dat, size, 0xFFFF);
        }
        else
        {
            /* 该页写不完 */
            //先将该页写完
            cnt += 8 - addr%8;
            HAL_I2C_Mem_Write(&g_hw_i2c_bus[EEPROM_I2C_NO].i2c_handle, EEPROM_ADDR, addr, I2C_MEMADD_SIZE_16BIT, dat, cnt, 0xFFFF);
            addr += cnt;
            
            //循环写整页数据
            for(i = 0;i < (size - cnt)/8; i++)
            {
                HAL_I2C_Mem_Write(&g_hw_i2c_bus[EEPROM_I2C_NO].i2c_handle, EEPROM_ADDR, addr, I2C_MEMADD_SIZE_16BIT, &dat[cnt], 8, 0xFFFF);
                addr += 8;
                cnt += 8;
            }
            
            //将剩下的字节写入
            return HAL_I2C_Mem_Write(&g_hw_i2c_bus[EEPROM_I2C_NO].i2c_handle, EEPROM_ADDR, addr, I2C_MEMADD_SIZE_16BIT, &dat[cnt], size - cnt, 0xFFFF);
        }			
    }
}

/**
 * @brief		AT24C02任意地址连续读多个字节数据
 * @param		addr —— 读数据的地址（0-255）
 * @param		dat  —— 存放读出数据的地址
 * @retval		成功 —— HAL_OK
*/
uint8_t At24c02_Read_Amount_Byte(uint16_t addr, uint8_t* recv_buf, uint16_t size)
{
	return HAL_I2C_Mem_Read(&g_hw_i2c_bus[EEPROM_I2C_NO].i2c_handle, EEPROM_ADDR, addr, I2C_MEMADD_SIZE_16BIT, recv_buf, size, 0xFFFF);
}


int eeprom_read_byte(uint16_t addr, uint8_t *pdata, uint16_t size)
{
    uint8_t ret = 0;
    uint8_t buf[2];
    
    hal_hw_i2c_open(EEPROM_I2C_NO);
    buf[0] = (uint8_t)(addr>>8);	
    buf[1] = (uint8_t)addr;
    hal_hw_i2c_write(EEPROM_I2C_NO, EEPROM_ADDR, buf, 2);
	//ret = HAL_I2C_Master_Transmit(&g_hw_i2c_bus[EEPROM_I2C_NO].i2c_handle, EEPROM_ADDR, buf, 2, I2C_TIMEOUT_WR_RD);
    memset(pdata, 0 , size);
    hal_hw_i2c_read(EEPROM_I2C_NO, EEPROM_ADDR, pdata, size);
    //ret |= HAL_I2C_Master_Receive(&g_hw_i2c_bus[EEPROM_I2C_NO].i2c_handle, EEPROM_ADDR, pdata, size, I2C_TIMEOUT_WR_RD);
    return ret;
}


int eeprom_write_one_byte(uint16_t addr, uint8_t data)
{
    int ret = 0;
    uint8_t buf[3];
    
    hal_hw_i2c_open(EEPROM_I2C_NO);
    buf[0] = (uint8_t)(addr>>8);	
    buf[1] = (uint8_t)addr;
    buf[2] = data;
    hal_hw_i2c_write(EEPROM_I2C_NO, EEPROM_ADDR, buf, 3);
  //  ret = HAL_I2C_Master_Transmit(&g_hw_i2c_bus[EEPROM_I2C_NO].i2c_handle, EEPROM_ADDR, buf, 3, I2C_TIMEOUT_WR_RD);
    
    return ret;
}


int eeprom_write_n_byte(uint16_t addr, uint8_t *pdata, uint16_t size)
{
    int32_t ret = 0;
    uint16_t i;

    for(i = 0; i < size; i++)
    {
        ret = eeprom_write_one_byte(addr++, *pdata++);
        if(ret < 0)
        {
            return -1;
        }
        /* 此处延时应大于4ms，等待芯片内部写完成 */
        os_delay(5);
    }
    return 0;
}



void test_i2c_eeprom(int argc, char *argv[])
{
    int addr = 0;
    uint8_t buff[16];
 
    if (argc > 1)
    {
		if (strcmp(argv[1], "set") == 0)
        {
            addr = atol(argv[2]);
            buff[0] = atol(argv[3]);
            for (int i = 1; i < sizeof(buff); i++)
            {
            	buff[i] = buff[0] + i;
            }
            eeprom_write_n_byte(addr, buff, sizeof(buff));
			//At24c02_Write_Amount_Byte(addr, buff , sizeof(buff));
        }
        else if (strcmp(argv[1], "get") == 0)
        {
            addr = atol(argv[2]);
			memset(buff, 0, sizeof(buff));
			eeprom_read_byte(addr, buff , sizeof(buff));
			//At24c02_Read_Amount_Byte(addr, buff , sizeof(buff));
            log_hexdump("eeprom data", 16, buff, sizeof(buff));
        }
	}
}

MSH_CMD_EXPORT(test_i2c_eeprom, test i2c eeprom);

#endif

#endif


