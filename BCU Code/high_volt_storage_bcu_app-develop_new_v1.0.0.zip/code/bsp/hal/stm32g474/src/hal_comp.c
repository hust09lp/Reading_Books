#include <rtthread.h>
#include <rtdevice.h>
#include "hal_comp.h"
#include "hal_gpio.h"
#include "pin_config.h"
#include "log.h"


#ifdef BSP_USING_COMP
enum
{
#ifdef BSP_USING_COMP1
    COMP1_INDEX,
#endif
#ifdef BSP_USING_COMP2
    COMP2_INDEX,
#endif
#ifdef BSP_USING_COMP3
    COMP3_INDEX,
#endif
#ifdef BSP_USING_COMP4
    COMP4_INDEX,
#endif
#ifdef BSP_USING_COMP5
    COMP5_INDEX,
#endif
#ifdef BSP_USING_COMP6
    COMP6_INDEX,
#endif
#ifdef BSP_USING_COMP7
    COMP7_INDEX,
#endif
};
#endif

struct stm32_comp
{
    COMP_HandleTypeDef    comp_handle;
    IRQn_Type comp_irqn;
    char *name;
};

static struct stm32_comp stm32_comp_obj[] = 
{
#ifdef BSP_USING_COMP1
    COMP1_CONFIG,
#endif
#ifdef BSP_USING_COMP2
    COMP2_CONFIG,
#endif
#ifdef BSP_USING_COMP3
    COMP3_CONFIG,
#endif
#ifdef BSP_USING_COMP4
    COMP4_CONFIG,
#endif
#ifdef BSP_USING_COMP5
    COMP5_CONFIG,
#endif
#ifdef BSP_USING_COMP6
    COMP6_CONFIG,
#endif
#ifdef BSP_USING_COMP7
    COMP7_CONFIG,
#endif
};

static uint8_t g_comp_err_flag[COMP_SINGAL_MAX] = {0};
    
typedef struct{
	uint32_t is_init;								    // 0-未初始化 1-已初始化
	uint32_t is_start;								    // 0-未打开 1-已打开
	uint32_t is_suspend;							    // 0-未挂起 1-已挂起
}comp_status_t;
static comp_status_t	g_comp_status = {0};				    /* 比较器状态 */

#ifdef BSP_USING_COMP1
/**
  * @brief COMP1 Initialization Function
  * @param None
  * @retval None
  */
static HAL_StatusTypeDef MX_COMP1_Init(COMP_HandleTypeDef* hcomp)
{
    HAL_StatusTypeDef ret = HAL_OK;
    /* USER CODE BEGIN COMP1_Init 0 */

    /* USER CODE END COMP1_Init 0 */

    /* USER CODE BEGIN COMP1_Init 1 */

    /* USER CODE END COMP1_Init 1 */
    hcomp->Instance = COMP1;
    hcomp->Init.InputPlus = COMP_INPUT_PLUS_IO1;
    hcomp->Init.InputMinus = COMP_INPUT_MINUS_VREFINT;
    hcomp->Init.OutputPol = COMP_OUTPUTPOL_NONINVERTED;
    hcomp->Init.Hysteresis = COMP_HYSTERESIS_NONE;
    hcomp->Init.BlankingSrce = COMP_BLANKINGSRC_NONE;
    hcomp->Init.TriggerMode = COMP_TRIGGERMODE_IT_FALLING;
    ret = HAL_COMP_Init(hcomp);
    if (ret != HAL_OK)
    {
        log_e("Comp1Err%d\n", ret);
        return ret;
    }
    /* USER CODE BEGIN COMP1_Init 2 */
    HAL_COMP_Start(hcomp);
    /* USER CODE END COMP1_Init 2 */
    return HAL_OK;
}
#endif

#ifdef BSP_USING_COMP2
/**
  * @brief COMP2 Initialization Function
  * @param None
  * @retval None
  */
static HAL_StatusTypeDef MX_COMP2_Init(COMP_HandleTypeDef* hcomp)
{

    HAL_StatusTypeDef ret = HAL_OK;
    /* USER CODE BEGIN COMP2_Init 0 */

    /* USER CODE END COMP2_Init 0 */

    /* USER CODE BEGIN COMP2_Init 1 */

    /* USER CODE END COMP2_Init 1 */
    hcomp->Instance = COMP2;
    hcomp->Init.InputPlus = COMP_INPUT_PLUS_IO1;
    hcomp->Init.InputMinus = COMP_INPUT_MINUS_VREFINT;
    hcomp->Init.OutputPol = COMP_OUTPUTPOL_NONINVERTED;
    hcomp->Init.Hysteresis = COMP_HYSTERESIS_NONE;
    hcomp->Init.BlankingSrce = COMP_BLANKINGSRC_NONE;
    hcomp->Init.TriggerMode = COMP_TRIGGERMODE_IT_FALLING;
    ret = HAL_COMP_Init(hcomp);
    if (ret != HAL_OK)
    {
        log_e("Comp1Err%d\n", ret);
        return ret;
    }
    /* USER CODE BEGIN COMP2_Init 2 */
    HAL_COMP_Start(hcomp);
    /* USER CODE END COMP2_Init 2 */
    return HAL_OK;
}
#endif

#ifdef BSP_USING_COMP3
/**
  * @brief COMP3 Initialization Function
  * @param None
  * @retval None
  */
static HAL_StatusTypeDef MX_COMP3_Init(COMP_HandleTypeDef* hcomp)
{
    HAL_StatusTypeDef ret = HAL_OK;
    /* USER CODE BEGIN COMP3_Init 0 */

    /* USER CODE END COMP3_Init 0 */

    /* USER CODE BEGIN COMP3_Init 1 */

    /* USER CODE END COMP3_Init 1 */
    hcomp->Instance = COMP3;
    hcomp->Init.InputPlus = COMP_INPUT_PLUS_IO1;
    hcomp->Init.InputMinus = COMP_INPUT_MINUS_VREFINT;
    hcomp->Init.OutputPol = COMP_OUTPUTPOL_NONINVERTED;
    hcomp->Init.Hysteresis = COMP_HYSTERESIS_NONE;
    hcomp->Init.BlankingSrce = COMP_BLANKINGSRC_NONE;
    hcomp->Init.TriggerMode = COMP_TRIGGERMODE_IT_FALLING;
    ret = HAL_COMP_Init(hcomp);
    if (ret != HAL_OK)
    {
        log_e("Comp3Err%d\n", ret);
        return ret;
    }
    /* USER CODE BEGIN COMP3_Init 2 */
    HAL_COMP_Start(hcomp);
    /* USER CODE END COMP3_Init 2 */
    return HAL_OK;
}
#endif

#ifdef BSP_USING_COMP4
/**
  * @brief COMP4 Initialization Function
  * @param None
  * @retval None
  */
static HAL_StatusTypeDef MX_COMP4_Init(COMP_HandleTypeDef* hcomp)
{
    HAL_StatusTypeDef ret = HAL_OK;
    /* USER CODE BEGIN COMP4_Init 0 */

    /* USER CODE END COMP4_Init 0 */

    /* USER CODE BEGIN COMP4_Init 1 */

    /* USER CODE END COMP4_Init 1 */
    hcomp->Instance = COMP4;
    hcomp->Init.InputPlus = COMP_INPUT_PLUS_IO1;
    hcomp->Init.InputMinus = COMP_INPUT_MINUS_VREFINT;
    hcomp->Init.OutputPol = COMP_OUTPUTPOL_NONINVERTED;
    hcomp->Init.Hysteresis = COMP_HYSTERESIS_NONE;
    hcomp->Init.BlankingSrce = COMP_BLANKINGSRC_NONE;
    hcomp->Init.TriggerMode = COMP_TRIGGERMODE_IT_FALLING;
    ret = HAL_COMP_Init(hcomp);
    if (ret != HAL_OK)
    {
        log_e("Comp4Err%d\n", ret);
        return ret;
    }
    /* USER CODE BEGIN COMP4_Init 2 */
    HAL_COMP_Start(hcomp);
    /* USER CODE END COMP4_Init 2 */
    return HAL_OK;
}
#endif

#ifdef BSP_USING_COMP5
/**
  * @brief COMP5 Initialization Function
  * @param None
  * @retval None
  */
static HAL_StatusTypeDef MX_COMP5_Init(COMP_HandleTypeDef* hcomp)
{
    HAL_StatusTypeDef ret = HAL_OK;
    /* USER CODE BEGIN COMP5_Init 0 */

    /* USER CODE END COMP5_Init 0 */

    /* USER CODE BEGIN COMP5_Init 1 */

    /* USER CODE END COMP5_Init 1 */
    hcomp->Instance = COMP5;
    hcomp->Init.InputPlus = COMP_INPUT_PLUS_IO1;
    hcomp->Init.InputMinus = COMP_INPUT_MINUS_VREFINT;
    hcomp->Init.OutputPol = COMP_OUTPUTPOL_NONINVERTED;
    hcomp->Init.Hysteresis = COMP_HYSTERESIS_NONE;
    hcomp->Init.BlankingSrce = COMP_BLANKINGSRC_NONE;
    hcomp->Init.TriggerMode = COMP_TRIGGERMODE_IT_FALLING;
    ret = HAL_COMP_Init(hcomp);
    if (ret != HAL_OK)
    {
        log_e("Comp5Err%d\n", ret);
        return ret;
    }
    /* USER CODE BEGIN COMP5_Init 2 */
    HAL_COMP_Start(hcomp);
    /* USER CODE END COMP5_Init 2 */
    return HAL_OK;
}
#endif

#ifdef BSP_USING_COMP6
/**
  * @brief COMP6 Initialization Function
  * @param None
  * @retval None
  */
static HAL_StatusTypeDef MX_COMP6_Init(COMP_HandleTypeDef* hcomp)
{
    HAL_StatusTypeDef ret = HAL_OK;
    /* USER CODE BEGIN COMP6_Init 0 */

    /* USER CODE END COMP6_Init 0 */

    /* USER CODE BEGIN COMP6_Init 1 */

    /* USER CODE END COMP6_Init 1 */
    hcomp->Instance = COMP6;
    hcomp->Init.InputPlus = COMP_INPUT_PLUS_IO1;
    hcomp->Init.InputMinus = COMP_INPUT_MINUS_VREFINT;
    hcomp->Init.OutputPol = COMP_OUTPUTPOL_NONINVERTED;
    hcomp->Init.Hysteresis = COMP_HYSTERESIS_NONE;
    hcomp->Init.BlankingSrce = COMP_BLANKINGSRC_NONE;
    hcomp->Init.TriggerMode = COMP_TRIGGERMODE_IT_FALLING;
    ret = HAL_COMP_Init(hcomp);
    if (ret != HAL_OK)
    {
        log_e("Comp6Err%d\n", ret);
        return ret;
    }
    /* USER CODE BEGIN COMP6_Init 2 */
    HAL_COMP_Start(hcomp);
    /* USER CODE END COMP6_Init 2 */
    return HAL_OK;
}
#endif

#ifdef BSP_USING_COMP7  
/**
  * @brief COMP7 Initialization Function
  * @param None
  * @retval None
  */
static HAL_StatusTypeDef MX_COMP7_Init(COMP_HandleTypeDef* hcomp)
{
    HAL_StatusTypeDef ret = HAL_OK;
    /* USER CODE BEGIN COMP7_Init 0 */

    /* USER CODE END COMP7_Init 0 */

    /* USER CODE BEGIN COMP7_Init 1 */

    /* USER CODE END COMP7_Init 1 */
    hcomp->Instance = COMP7;
    hcomp->Init.InputPlus = COMP_INPUT_PLUS_IO1;
    hcomp->Init.InputMinus = COMP_INPUT_MINUS_VREFINT;
    hcomp->Init.OutputPol = COMP_OUTPUTPOL_NONINVERTED;
    hcomp->Init.Hysteresis = COMP_HYSTERESIS_NONE;
    hcomp->Init.BlankingSrce = COMP_BLANKINGSRC_NONE;
    hcomp->Init.TriggerMode = COMP_TRIGGERMODE_IT_FALLING;
    ret = HAL_COMP_Init(hcomp);
    if (ret != HAL_OK)
    {
        log_e("Comp7Err%d\n", ret);
        return ret;
    }
    /* USER CODE BEGIN COMP7_Init 2 */
    HAL_COMP_Start(hcomp);
    /* USER CODE END COMP7_Init 2 */
    return HAL_OK;
}
#endif

/**
 * @brief stm32 comp Initialization Function
 * @param None
 * @retval None
 */
static int32_t stm32_comp_init(void)
{
    int32_t ret = HAL_OK;
    for (uint8_t i = 0; i < sizeof(stm32_comp_obj) / sizeof(stm32_comp_obj[0]); i++)
    {
	#ifdef BSP_USING_COMP1
        // comp config
        if (COMP1 == stm32_comp_obj[i].comp_handle.Instance)
        {
            ret = MX_COMP1_Init(&stm32_comp_obj[i].comp_handle);
            if (ret != HAL_OK)
            {
                log_e("MxComp1Err%d\n", ret);
                return ret;
            }
        }
	#endif

	#ifdef BSP_USING_COMP2
        if (COMP2 == stm32_comp_obj[i].comp_handle.Instance)
        {
            ret = MX_COMP2_Init(&stm32_comp_obj[i].comp_handle);
            if (ret != HAL_OK)
            {
                log_e("MxComp2Err%d\n", ret);
                return ret;
            }
        }
	#endif

	#ifdef BSP_USING_COMP3
        if (COMP3 == stm32_comp_obj[i].comp_handle.Instance)
        {
            MX_COMP3_Init(&stm32_comp_obj[i].comp_handle);
            if (ret != HAL_OK)
            {
                log_e("MxComp3Err%d\n", ret);
                return ret;
            }
        }
	#endif

	#ifdef BSP_USING_COMP4
        if (COMP4 == stm32_comp_obj[i].comp_handle.Instance)
        {
            ret = MX_COMP4_Init(&stm32_comp_obj[i].comp_handle);
            if (ret != HAL_OK)
            {
                log_e("MxComp4Err%d\n", ret);
                return ret;
            }
        }
	#endif

	#ifdef BSP_USING_COMP5
        if (COMP5 == stm32_comp_obj[i].comp_handle.Instance)
        {
            ret = MX_COMP5_Init(&stm32_comp_obj[i].comp_handle);
            if (ret != HAL_OK)
            {
                log_e("MxComp5Err%d\n", ret);
                return ret;
            }
        }
	#endif

	#ifdef BSP_USING_COMP6
        if (COMP6 == stm32_comp_obj[i].comp_handle.Instance)
        {
            MX_COMP6_Init(&stm32_comp_obj[i].comp_handle);
            if (ret != HAL_OK)
            {
                log_e("MxComp6Err%d\n", ret);
                return ret;
            }
        }
	#endif    

	#ifdef BSP_USING_COMP7
        if (COMP7 == stm32_comp_obj[i].comp_handle.Instance)
        {
            MX_COMP7_Init(&stm32_comp_obj[i].comp_handle);
            if (ret != HAL_OK)
            {
                log_e("MxComp7Err%d\n", ret);
                return ret;
            }
        }
	#endif     
    }
    return ret;
}

/**
 * @brief  返回比较异常状态
 * @return uint8_t*: 
 * AUX_RLY_PWR_STUS = 0,
    NEG_RLY_PWR_STUS,
    POS_RLY_PWR_STUS,
    PWR_5V_STUS,
    PWR_12V_STUS,
 */
uint8_t *hal_comp_err_stus_get(void)
{
    return g_comp_err_flag;
}

/**
 * @brief  清除比较异常标志
 * @param  chan:     
 * AUX_RLY_PWR_STUS = 0,
    NEG_RLY_PWR_STUS,
    POS_RLY_PWR_STUS,
    PWR_5V_STUS,
    PWR_12V_STUS,
 * @return int32_t: 
 */
int32_t hal_comp_err_stus_clr(uint8_t chan)
{
    if (chan >= COMP_SINGAL_MAX)
    {
        return HAL_ERROR;
    }
    
    g_comp_err_flag[chan] = false;
    
    return HAL_OK;
}

/**
* @brief		COMP加载驱动,根据配置加载对应的COMP驱动
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @warning		系统启动时默认启动
*/
int hal_comp_init(void)
{    

    int32_t ret = stm32_comp_init();
    if (ret != HAL_OK)
    {
        log_e("StmCompInitErr%d\n", ret);
        return ret;
    }

    g_comp_status.is_init = 1;
	
	return HAL_OK;
}
INIT_BOARD_EXPORT(hal_comp_init);

/**
* @brief		比较器打开
 * @param  comp_id:     开启哪个比较器
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @warning		IO动作的时候操作
*/
int hal_comp_open(uint8_t comp_id)
{    
    int32_t ret = HAL_ERROR;
    
    if (g_comp_status.is_init)
    {
        if(comp_id < sizeof(stm32_comp_obj) / sizeof(stm32_comp_obj[0]))
        {
            ret = HAL_COMP_Start(&stm32_comp_obj[comp_id].comp_handle);
        }            
    }
    
    if(HAL_OK != ret)
    {
        log_e("[comp%d start err\n]",comp_id);
    }
    
}

/**
* @brief		比较器关闭
 * @param  comp_id:     关闭哪个比较器
* @return		执行结果
* @retval		HAL_OK(0) 成功
* @retval		HAL_EIO(<0) 失败 
* @warning		IO动作的时候操作
*/
int hal_comp_close(uint8_t comp_id)
{    
    int32_t ret = HAL_ERROR;
    
    if (g_comp_status.is_init)
    {
        if(comp_id < sizeof(stm32_comp_obj) / sizeof(stm32_comp_obj[0]))
        {
            ret = HAL_COMP_Stop(&stm32_comp_obj[comp_id].comp_handle);
        }            
    }
    
    if(HAL_OK != ret)
    {
        log_e("[comp%d stop err\n]",comp_id);
    }
    
}

/**
* @brief		比较器电平状态
 * @param  comp_id:     
* @return		电平状态
* @retval		COMP_OUTPUT_LEVEL_LOW(0) 低电平
* @retval		COMP_OUTPUT_LEVEL_HIGH(1) 高电平
* @retval	    (-1) 无效
* @warning		IO动作的时候操作
*/
int32_t hal_comp_state(uint8_t comp_id)
{    
    int32_t ret = HAL_ERROR;
    
    if (g_comp_status.is_init)
    {
        if(comp_id < sizeof(stm32_comp_obj) / sizeof(stm32_comp_obj[0]))
        {
            ret = HAL_COMP_GetOutputLevel(&stm32_comp_obj[comp_id].comp_handle);
        }            
    }

    return ret;
    
}


void COMP1_2_3_IRQHandler(void) 
{
    rt_interrupt_enter();  
    /* EXTI line interrupt detected */
#ifdef BSP_USING_COMP1    
    if (__HAL_COMP_COMP1_EXTI_GET_FLAG())
    {
        if(COMP_OUTPUT_LEVEL_LOW == hal_comp_state(AUX_RLY_PWR_STUS))
        {
            g_comp_err_flag[AUX_RLY_PWR_STUS] = true;
//            hal_gpio_write(DO_7_PIN,0);        
        }
        HAL_COMP_IRQHandler(&stm32_comp_obj[COMP1_INDEX].comp_handle);
        __HAL_COMP_COMP1_EXTI_CLEAR_FLAG();
    } 
#endif 
#ifdef BSP_USING_COMP2      
    if (__HAL_COMP_COMP2_EXTI_GET_FLAG())
    {
        if(COMP_OUTPUT_LEVEL_LOW == hal_comp_state(NEG_RLY_PWR_STUS))
        {        
            g_comp_err_flag[NEG_RLY_PWR_STUS] = true;
//            hal_gpio_write(DO_8_PIN,0);
        }
        HAL_COMP_IRQHandler(&stm32_comp_obj[COMP2_INDEX].comp_handle);     
        __HAL_COMP_COMP2_EXTI_CLEAR_FLAG();
    }
#endif   
#ifdef BSP_USING_COMP3     
    if (__HAL_COMP_COMP3_EXTI_GET_FLAG())
    {
        if(COMP_OUTPUT_LEVEL_LOW == hal_comp_state(POS_RLY_PWR_STUS))
        {           
            g_comp_err_flag[POS_RLY_PWR_STUS] = true;
//            hal_gpio_write(DO_6_PIN,0);
        }
        HAL_COMP_IRQHandler(&stm32_comp_obj[COMP3_INDEX].comp_handle);   
        __HAL_COMP_COMP3_EXTI_CLEAR_FLAG();        
    }
#endif
    rt_interrupt_leave();

}


void COMP4_5_6_IRQHandler(void) 
{
    rt_interrupt_enter();  
    /* EXTI line interrupt detected */
#ifdef BSP_USING_COMP4     
    if (__HAL_COMP_COMP4_EXTI_GET_FLAG())
    {
        if(COMP_OUTPUT_LEVEL_LOW == hal_comp_state(PWR_5V_STUS))
        {          
            g_comp_err_flag[PWR_5V_STUS] = true;
//            hal_gpio_write(DO_16_PIN,0);
        }
        HAL_COMP_IRQHandler(&stm32_comp_obj[COMP4_INDEX].comp_handle);
        __HAL_COMP_COMP4_EXTI_CLEAR_FLAG();
    }
#endif
#ifdef BSP_USING_COMP5      
    if (__HAL_COMP_COMP5_EXTI_GET_FLAG())
    {
        HAL_COMP_IRQHandler(&stm32_comp_obj[COMP5_INDEX].comp_handle);   
        __HAL_COMP_COMP5_EXTI_CLEAR_FLAG();    
    }
#endif
#ifdef BSP_USING_COMP6       
    if (__HAL_COMP_COMP6_EXTI_GET_FLAG())
    {
        if(COMP_OUTPUT_LEVEL_LOW == hal_comp_state(PWR_12V_STUS))   
        {            
            g_comp_err_flag[PWR_12V_STUS] = true;
//            hal_gpio_write(DO_13_PIN,0);
        }
        HAL_COMP_IRQHandler(&stm32_comp_obj[COMP6_INDEX].comp_handle);      
        __HAL_COMP_COMP6_EXTI_CLEAR_FLAG();        
    }
#endif
    rt_interrupt_leave();

}

void COMP_7_IRQHandler(void) 
{
    rt_interrupt_enter();      
#ifdef BSP_USING_COMP7     
    if (__HAL_COMP_COMP7_EXTI_GET_FLAG())
    {
        HAL_COMP_IRQHandler(&stm32_comp_obj[COMP7_INDEX].comp_handle);
    }
#endif    
    rt_interrupt_leave();
    
}    



#ifdef RT_USING_FINSH

#include <stdlib.h>
static int hal_comp_sample(int argc, char *p_argv[])
{
	uint32_t timeout;
	char 	*opt  = p_argv[1];
	char 	*time	  = p_argv[2];


    if (!rt_strcmp(opt, "get"))
	{
        log_d("comp err: %d, %d, %d, %d, %d\n",g_comp_err_flag[POS_RLY_PWR_STUS],g_comp_err_flag[AUX_RLY_PWR_STUS],g_comp_err_flag[NEG_RLY_PWR_STUS],g_comp_err_flag[PWR_12V_STUS],g_comp_err_flag[PWR_5V_STUS]);
	}
    else if (!rt_strcmp(opt, "clr"))
    {
        memset(g_comp_err_flag,0x00,sizeof(g_comp_err_flag));
    }
    else
    {
        log_d("input err\n");
    }

	
	return HAL_OK;
}

MSH_CMD_EXPORT(hal_comp_sample, hal_comp_sample <get/clr>);
#endif
