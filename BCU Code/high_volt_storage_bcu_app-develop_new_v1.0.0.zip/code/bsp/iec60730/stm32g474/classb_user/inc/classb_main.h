/**
  ******************************************************************************
  * @file    classb_main.h
  * @author  MCD Application Team
  * @version V2.3.0
  * @date    28-Jun-2019
  * @brief   Header for main.c module
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT(c) 2019 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __CLASSB_MAIN_H
#define __CLASSB_MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include <stdio.h>
//#include "stm32g4xx_nucleo.h"
#include "stm32g4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
//#include "stm32g4xx_nucleo.h"

/* Exported types ------------------------------------------------------------*/
  
/* Exported constants --------------------------------------------------------*/
/* Maximum Flash latency at given voltage range */
#define MAX_FLASH_LATENCY FLASH_LATENCY_4
/* HAL legacy */
#define __HAL_RCC_CLEAR_FLAG    __HAL_RCC_CLEAR_RESET_FLAGS
#define RCC_FLAG_PORRST         RCC_FLAG_BORRST

/* verbose USART */
USART_TypeDef* get_mcu_check_uart(void);

/* user gpio auxiliary pins to measure STL intervals */  
#define AUX_GPIO_PORT   GPIOA
#define AUX_VLM     GPIO_PIN_5
#define AUX_NVM     GPIO_PIN_6
  
#define User_AUX_On(msk)     { HAL_GPIO_WritePin(AUX_GPIO_PORT, msk, GPIO_PIN_SET); }
#define User_AUX_Off(msk)    { HAL_GPIO_WritePin(AUX_GPIO_PORT, msk, GPIO_PIN_RESET); }
#define User_AUX_Toggle(msk) { HAL_GPIO_TogglePin(AUX_GPIO_PORT, msk); }


#define __DBGMCU_FREEZE_IWDG  __HAL_DBGMCU_FREEZE_IWDG
#define __DBGMCU_FREEZE_WWDG  __HAL_DBGMCU_FREEZE_WWDG


/* Exported macro ------------------------------------------------------------*/

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

void STL_StartUp(void);
void SystemInit (void);
void classb_init(void);
void classb_check_runtime(void);
void StartUpClock_Config(void);
void PLLClock_Stop(void);
void TIM5_IRQHandler(void);
void User_AUX_Init(uint32_t msk);

#ifdef __IAR_SYSTEMS_ICC__  /* IAR Compiler */
  void __iar_data_init3(void);
#endif /* __IAR_SYSTEMS_ICC__ */
#ifdef __CC_ARM             /* KEIL Compiler */
extern void $Super$$main(void);  
#endif /* __CC_ARM */
#ifdef __GNUC__
int16_t __io_putchar(int16_t ch);
#endif /* __GNUC__ */

/* Private defines -----------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
