/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    RCC/RCC_ClockConfig/Src/stm32g4xx_it.c
  * @author  MCD Application Team
  * @version V2.3.0
  * @date    28-June-2019
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and
  *          peripherals interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT(c) 2019 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "classb_main.h"
#include "stm32xx_STLparam.h"
#include "stm32xx_STLlib.h"
//#include "stm32g4xx_it.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
   volatile static uint16_t tmpCC1_last;	/* keep last TIM16/Chn1 captured value */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/

/* USER CODE BEGIN EV */

/* USER CODE END EV */

/******************************************************************************/
/*           Cortex-M4 Processor Interruption and Exception Handlers          */ 
/******************************************************************************/
/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVCall_IRQn 0 */

  /* USER CODE END SVCall_IRQn 0 */
  /* USER CODE BEGIN SVCall_IRQn 1 */

  /* USER CODE END SVCall_IRQn 1 */
}


/**
  * @brief This function handles System tick timer.
  */
void stl_runtime_intick(void)
{
   /* Verify TickCounter integrity */
  if ((TickCounter ^ TickCounterInv) == 0xFFFFFFFFuL)
  {
    TickCounter++;
    TickCounterInv = ~TickCounter;

    if (TickCounter >= SYSTICK_10ms_TB)
    {
      uint32_t RamTestResult;
   
      #if defined STL_EVAL_MODE
        /* Toggle LED_VLM for debug purposes */
        BSP_LED_Toggle(LED_VLM);
      #endif  /* STL_EVAL_MODE */
      #if defined STL_USER_AUX_MODE
        User_AUX_Toggle(AUX_VLM);
      #endif /* STL_USER_AUX_MODE */

      /* Reset timebase counter */
      TickCounter = 0u;
      TickCounterInv = 0xFFFFFFFFuL;

      /* Set Flag read in main loop */
      TimeBaseFlag = 0xAAAAAAAAuL;
      TimeBaseFlagInv = 0x55555555uL;

      ISRCtrlFlowCnt += RAM_MARCHC_ISR_CALLER;
			  __disable_irq();
      RamTestResult = STL_TranspMarch();
			  __enable_irq();
      ISRCtrlFlowCntInv -= RAM_MARCHC_ISR_CALLER;

      switch ( RamTestResult )
      {
        case TEST_RUNNING:
          break;
        case TEST_OK:
          #ifdef STL_VERBOSE
          /* avoid any long string output here in the interrupt, '#' marks ram test completed ok */
            #ifndef __GNUC__
              //putchar((int16_t)'#');
            #else
              __io_putchar((int16_t)'#');
            #endif /* __GNUC__ */
          #endif  /* STL_VERBOSE */
          #ifdef STL_EVAL_MODE
            /* Toggle LED_VLM for debug purposes */
            BSP_LED_Toggle(LED_VLM);
          #endif /* STL_EVAL_MODE */
          #if defined STL_USER_AUX_MODE
            User_AUX_Toggle(AUX_VLM);
          #endif /* STL_USER_AUX_MODE */
          #if defined(STL_EVAL_LCD)
            ++MyRAMCounter;
          #endif /* STL_EVAL_LCD */
          break;
        case TEST_FAILURE:
        case CLASS_B_DATA_FAIL:
        default:
          #ifdef STL_VERBOSE
            printf("\n\r >>>>>>>>>>>>>>>>>>>  RAM Error (March C- Run-time check) %lx \n\r", RamTestResult);
          #endif  /* STL_VERBOSE */
          FailSafePOR();
          break;
      } /* End of the switch */

      /* Do we reached the end of RAM test? */
      /* Verify 1st ISRCtrlFlowCnt integrity */
      if ((ISRCtrlFlowCnt ^ ISRCtrlFlowCntInv) == 0xFFFFFFFFuL)
      {
        if (RamTestResult == TEST_OK)
        {
  /* ==============================================================================*/
  /* MISRA violation of rule 17.4 - pointer arithmetic is used to check RAM test control flow */
	#ifdef __IAR_SYSTEMS_ICC__  /* IAR Compiler */
		#pragma diag_suppress=Pm088
	#endif /* __IAR_SYSTEMS_ICC__ */
          if (ISRCtrlFlowCnt != RAM_TEST_COMPLETED)
	#ifdef __IAR_SYSTEMS_ICC__  /* IAR Compiler */
		#pragma diag_default=Pm088
	#endif /* __IAR_SYSTEMS_ICC__ */
  /* ==============================================================================*/
          {
          #ifdef STL_VERBOSE
            printf("\n\r Control Flow error (RAM test) \n\r");
          #endif  /* STL_VERBOSE */
          FailSafePOR();
          }
          else  /* Full RAM was scanned */
          {
            ISRCtrlFlowCnt = 0u;
            ISRCtrlFlowCntInv = 0xFFFFFFFFuL;
          }
        } /* End of RAM completed if*/
      } /* End of control flow monitoring */
      else
      {
      #ifdef STL_VERBOSE
        printf("\n\r Control Flow error in ISR \n\r");
      #endif  /* STL_VERBOSE */
      FailSafePOR();
      }
      #if defined STL_EVAL_MODE
        /* Toggle LED_VLM for debug purposes */
        BSP_LED_Toggle(LED_VLM);
      #endif  /* STL_EVAL_MODE */
      #if defined STL_USER_AUX_MODE
        User_AUX_Toggle(AUX_VLM);
      #endif /* STL_USER_AUX_MODE */
    } /* End of the 10 ms timebase interrupt */
  } 
  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32G4xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32g4xx.s).                    */
/******************************************************************************/

/* USER CODE BEGIN 1 */
/**
  * @brief  This function handles external lines 10 to 15 interrupt request.
  * @param  None
  * @retval None
  */
//void EXTI15_10_IRQHandler(void)
//{
//  HAL_GPIO_EXTI_IRQHandler(USER_BUTTON_PIN);
//}


/******************************************************************************/
/**
  * @brief Configure TIM16 to measure LSI period
  * @param  : None
  * @retval : ErrorStatus = (ERROR, SUCCESS)
  */
ErrorStatus STL_InitClock_Xcross_Measurement(void)
{
  ErrorStatus result = SUCCESS;
  TIM_HandleTypeDef  tim_capture_handle;
  TIM_IC_InitTypeDef tim_input_config;
  RCC_OscInitTypeDef        RCC_OscInitStruct;
  RCC_PeriphCLKInitTypeDef  PeriphClkInitStruct;
  
  //HAL_PWR_EnableBkUpAccess();

  /* Configue LSI as RTC clock soucre */
  RCC_OscInitStruct.OscillatorType =  RCC_OSCILLATORTYPE_LSI ;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  if(HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  { 
    result = ERROR;
  }

#if 0
  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_RTC;
  PeriphClkInitStruct.RTCClockSelection = RCC_RTCCLKSOURCE_LSI;
  if(HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
  {
    result = ERROR;
  }
  /* Enable RTC Clock */
  __HAL_RCC_RTC_ENABLE();
#endif
  
  /* TIM16 Peripheral clock enable */
   __TIM16_CLK_ENABLE();
  
  /* Configure the NVIC for TIM16 */
  HAL_NVIC_SetPriority(TIM1_UP_TIM16_IRQn, 3u, 0u);
  
  /* Enable the TIM16 global Interrupt */
  HAL_NVIC_EnableIRQ(TIM1_UP_TIM16_IRQn);
  
  /* TIM16 configuration: Input Capture mode ---------------------
  The Rising edge is used as active edge, ICC input divided by 8
  The TIM16 CCR1 is used to compute the frequency value. 
  ------------------------------------------------------------ */
  tim_capture_handle.Instance = TIM16;
  tim_capture_handle.Init.Prescaler         = 0u; 
  tim_capture_handle.Init.CounterMode       = TIM_COUNTERMODE_UP;  
  tim_capture_handle.Init.Period            = 0xFFFFFFFFul; 
  tim_capture_handle.Init.ClockDivision     = 0u;     
  tim_capture_handle.Init.RepetitionCounter = 0u; 
  tim_capture_handle.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE; 
  
  
  /* define internal HAL driver status here as handle structure is defined locally */
  __HAL_RESET_HANDLE_STATE(&tim_capture_handle);
  if(HAL_TIM_IC_Init(&tim_capture_handle) != HAL_OK)
  {
    /* Initialization Error */
    result = ERROR;
  }

  /* Connect internally the TIM16_CH1 Input Capture to the LSI clock output */
  HAL_TIMEx_TISelection(&tim_capture_handle, TIM_TIM16_TI1_LSI, TIM_CHANNEL_1);	
	
  /* Configure the TIM16 Input Capture of channel 1 */
  tim_input_config.ICPolarity  = TIM_ICPOLARITY_RISING;
  tim_input_config.ICSelection = TIM_ICSELECTION_DIRECTTI;
  tim_input_config.ICPrescaler = TIM_ICPSC_DIV8;
  tim_input_config.ICFilter    = 0u;
  if(HAL_TIM_IC_ConfigChannel(&tim_capture_handle, &tim_input_config, TIM_CHANNEL_1) != HAL_OK)
  {
    /* Initialization Error */
    result = ERROR;
  }
  
  /* Reset the flags */
  tim_capture_handle.Instance->SR = 0u;
  LSIPeriodFlag = 0u;
  
  /* Start the TIM Input Capture measurement in interrupt mode */
  if(HAL_TIM_IC_Start_IT(&tim_capture_handle, TIM_CHANNEL_1) != HAL_OK)
  {
    /* Initialization Error */
    result = ERROR;
  }
  return(result);
}

/******************************************************************************/
/**
  * @brief  This function handles TIM16 global interrupt request.
  * @param  : None
  * @retval : None
  */
void TIM1_UP_TIM16_IRQHandler(void)
{
  uint16_t tmpCC1_last_cpy;
   
  if ((TIM16->SR & TIM_SR_CC1IF) != 0u )
  {
    /* store previous captured value */
    tmpCC1_last_cpy = tmpCC1_last; 
    /* get currently captured value */
    tmpCC1_last = (uint16_t)TIM16->CCR1;
    /* The CC1IF flag is already cleared here be reading CCR1 register */

    /* overight results only in case the data is required */
    if (LSIPeriodFlag == 0u)
    {
      /* take correct measurement only */
     if ((TIM16->SR & TIM_SR_CC1OF) == 0u)
      {
        /* Compute period length */
        PeriodValue = ((uint32_t)(tmpCC1_last) - (uint32_t)(tmpCC1_last_cpy)) & 0xFFFFuL;
        PeriodValueInv = ~PeriodValue;
      
        /* Set Flag tested at main loop */
        LSIPeriodFlag = 0xAAAAAAAAuL;
        LSIPeriodFlagInv = 0x55555555uL;
      }
      else
      {
        /* ignore computation in case of IC overflow */
        TIM16->SR &= (uint16_t)(~TIM_SR_CC1OF);
      }
    }
  /* ignore computation in case data is not required */
  }
}

/* USER CODE END 1 */
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
