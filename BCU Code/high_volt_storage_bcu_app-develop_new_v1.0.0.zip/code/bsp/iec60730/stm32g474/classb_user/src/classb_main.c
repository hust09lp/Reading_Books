/**
  ******************************************************************************
  * @file    main.c 
  * @author  MCD Application Team
  * @version V2.3.0
  * @date    28-June-2019
  * @brief   classb_main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT(c) 2019 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "classb_main.h"
#include "stm32xx_STLparam.h"
#include "stm32xx_STLlib.h"
#include "rtconfig.h"
#include "string.h"
/** @addtogroup STM32G4xx_IEC60335_Example
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#if defined (STL_EVAL_MODE) || defined(STL_VERBOSE)
#define MESSAGE1   " STM32G4xx Cortex-M4 "
#ifdef __IAR_SYSTEMS_ICC__  /* IAR Compiler */
#define MESSAGE2   " IEC60335 test @IARc "
#endif /* __IAR_SYSTEMS_ICC__ */
#ifdef __CC_ARM             /* KEIL Compiler */
#define MESSAGE2   " IEC60335 test @ARMc "
#endif /* __CC_ARM */
#ifdef __GNUC__             /* GCC Compiler */
#define MESSAGE2   " IEC60335 test @GCCc "
#endif /* __GNUC__ */
#endif /* STL_EVAL_MODE */
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
#if defined(STL_EVAL_MODE) || defined(STL_VERBOSE)
UART_HandleTypeDef UartHandle;
#endif /* STL_EVAL_MODE */

#if defined(STL_EVAL_LCD)
char amy_string[6];
uint32_t MyRAMCounter;
uint32_t MyFLASHCounter;
uint32_t Is_LCD_Initialized = 0;
#endif /* STL_EVAL_LCD */

/* Private function prototypes -----------------------------------------------*/
//static void My_SystemClock_Config(void);
static void MPU_Config(void);
static void CPU_CACHE_Enable(void);

#ifdef __GNUC__
/* With GCC/RAISONANCE, small printf (option LD Linker->Libraries->Small printf
 set to 'Yes') calls __io_putchar() */
#define PUTCHAR_PROTOTYPE int16_t __io_putchar(int16_t ch)
#endif /* __GNUC__ */
#ifdef __IAR_SYSTEMS_ICC__  /* IAR Compiler */
#define PUTCHAR_PROTOTYPE int putchar(int ch)
#endif /* __IAR_SYSTEMS_ICC__ */
#ifdef __CC_ARM             /* KEIL Compiler */
struct __FILE { int handle; };
//FILE __stdout;
#define PUTCHAR_PROTOTYPE __weak int fputc(int ch, FILE *f)
#endif /* __CC_ARM */
  PUTCHAR_PROTOTYPE;


/* Private functions ---------------------------------------------------------*/

void classb_pre_init(void)
{
    /* Configure the MPU attributes as Write Through for SDRAM */
    MPU_Config();

    /* Enable the CPU Cache */
    CPU_CACHE_Enable();
}

/**
  * @brief  Main program
  * @param  None
  * @retval None
  */
void classb_init(void)
{
  #if defined (STL_EVAL_MODE)
    /* Evaluation board control ----------------------------------------------*/
    Eval_Board_HW_Init();

    #if defined(STL_EVAL_LCD)
      /* Display message on STM32F4XX-EVAL LCD */
      BSP_LCD_Clear(LCD_COLOR_WHITE);
      BSP_LCD_SetFont(&LCD_DEFAULT_FONT);
      BSP_LCD_SetBackColor(LCD_COLOR_BLUE);
      BSP_LCD_SetTextColor(LCD_COLOR_WHITE); 
      BSP_LCD_ClearStringLine(0);
      BSP_LCD_ClearStringLine(1);
      BSP_LCD_DisplayStringAt(0, LINE(0), (uint8_t *)MESSAGE1, CENTER_MODE);
      BSP_LCD_DisplayStringAt(0, LINE(1), (uint8_t *)MESSAGE2, CENTER_MODE);
      BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
      BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
      BSP_LCD_DisplayStringAtLine(2, (uint8_t *)("StartUp test OK     "));
      BSP_LCD_DisplayStringAtLine(3, (uint8_t *)("Main entry...       "));
      BSP_LCD_DisplayStringAtLine(4, (uint8_t *)("Class B RAM checks:     "));
      BSP_LCD_DisplayStringAtLine(5, (uint8_t *)("Code Flash checks:      "));
    #endif /* STL_EVAL_LCD */
      
  #endif /* STL_EVAL_MODE */


  /* Self test routines initialization ---------------------------------------*/
  #if defined(STL_EVAL_MODE) || defined(STL_USER_AUX_MODE)
    /* if you debug TIM16 it is helpful to uncomment next lines */

    __DBGMCU_CLK_ENABLE();
    __HAL_FREEZE_TIM16_DBGMCU();
    __DBGMCU_FREEZE_IWDG();
    __DBGMCU_FREEZE_WWDG();
  #endif  /* STL_EVAL_MODE || STL_USER_AUX_MODE */
  
  #if defined(STL_EVAL_MODE)
    BSP_LED_On(LED3);
  #endif  /* STL_EVAL_MODE */
    

  /* -------------------------------------------------------------------------*/
  /* This is where the main self-test routines are initialized */
  STL_InitRunTimeChecks();
  
  /* -------------------------------------------------------------------------*/
#if defined STL_EVAL_MODE
  BSP_LED_Off(LED3);
#endif  /* STL_EVAL_MODE */
}

void classb_check_runtime(void)
{
    /* This is where the main self-test routines are executed */
    STL_DoRunTimeChecks();
    /* -----------------------------------------------------------------------*/

#if defined(STL_EVAL_LCD)
    sprintf(amy_string, "%5lu", MyRAMCounter);
    BSP_LCD_DisplayStringAt(338, LINE(4), (uint8_t *)amy_string, LEFT_MODE);
    sprintf(amy_string, "%5lu", MyFLASHCounter);
    BSP_LCD_DisplayStringAt(338, LINE(5), (uint8_t *)amy_string, LEFT_MODE);
#endif /* STL_EVAL_LCD */
}

/* ---------------------------------------------------------------------------*/
/**
  * @brief  System Clock Configuration
  *         The system Clock is configured as follow : 
  *            System Clock source            = PLL (source HSI - 16MHz)
  *            SYSCLK(MHz)                    = 170 MHz (CPU Clock)
  *            HCLK(MHz)                      = 170 MHz (AHBs Clock)
  *            AHB Prescaler                  = 1
  *            D1 APB1 Prescaler              = 2 (APB1 Clock  170MHz)
  *            D2 APB2 Prescaler              = 2 (APB2 Clock  170MHz)
  *            PLL Input Frequency(MHz)       = 16 MHz
  *            PLL_M                          = 4
  *            PLL_N                          = 85
  *            PLL_P                          = 2
  *            PLL_Q                          = 2
  *            PLL_R                          = 2
  *            VDD(V)                         = 3.3
  *            Flash Latency(WS)              = 8
  * @param  None
  * @retval None
  */
void StartUpClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage 
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT; //64;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV4;
  RCC_OscInitStruct.PLL.PLLN = 80;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV8;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
#ifdef STL_VERBOSE_POR
    printf("PLL Osc config failure\n\r");
#endif  /* STL_VERBOSE_POR */
    FailSafePOR();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
#ifdef STL_VERBOSE_POR
    printf("PLL Osc config failure\n\r");
#endif  /* STL_VERBOSE_POR */
    FailSafePOR();
  }
}

void PLLClock_Stop(void)
{
	RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

	/** Initializes the CPU, AHB and APB buses clocks
     */
    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSE;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
    {
		FailSafePOR();
    }

    /** Configure the main internal regulator output voltage
     */
    HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);

    /** Initializes the RCC Oscillators according to the specified parameters
     * in the RCC_OscInitTypeDef structure.
     */
    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI | RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState = RCC_HSE_ON;
    RCC_OscInitStruct.LSIState = RCC_LSI_ON;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_OFF;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV3;
    RCC_OscInitStruct.PLL.PLLN = 80;
    RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
    RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV8;
    RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    {
		FailSafePOR();
    }
}

#if defined STL_EVAL_MODE
/* -------------------------------------------------------------------------*/
/**
 * @brief  Initialization of evaluation board HW
 * @param :  None
 * @retval : None
 */
void Eval_Board_HW_Init(void) 
{
 /* init LEDs on evaluation board -----------------------------------------*/
  BSP_LED_Init(LED_GREEN);
  BSP_LED_Init(LED_RED);

  #if defined (STL_EVAL_LCD)
    /* Display message on STM32F4XX-EVAL LCD */
    /* Initialize the LCD */
    BSP_LCD_Init();
    BSP_LCD_LayerDefaultInit(1, LCD_FB_START_ADDRESS);
    BSP_LCD_SelectLayer(1);
    BSP_LCD_DisplayOn();
  #endif /* STL_EVAL_LCD  */
}
#endif /* STL_EVAL_MODE */


#ifdef STL_VERBOSE
/* ---------------------------------------------------------------------------*/
/**
 * @brief  Configure the UART peripheral
 * @param  None
 * @retval None
 */
void USART_Configuration(void) {
  UartHandle.Instance = get_mcu_check_uart();
  UartHandle.Init.BaudRate = 115200;
  UartHandle.Init.WordLength = UART_WORDLENGTH_8B;
  UartHandle.Init.StopBits = UART_STOPBITS_1;
  UartHandle.Init.Parity = UART_PARITY_NONE;
  UartHandle.Init.Mode = UART_MODE_TX_RX;
  UartHandle.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  UartHandle.Init.OverSampling = UART_OVERSAMPLING_16;
  UartHandle.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  UartHandle.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  UartHandle.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  __HAL_UART_RESET_HANDLE_STATE(&UartHandle);
  if (HAL_UART_Init(&UartHandle) != HAL_OK)
  {
    FailSafePOR();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&UartHandle, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    FailSafePOR();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&UartHandle, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    FailSafePOR();
  }
  if (HAL_UARTEx_DisableFifoMode(&UartHandle) != HAL_OK)
  {
    FailSafePOR();
  }	
}
USART_TypeDef* get_mcu_check_uart(void)
{
	USART_TypeDef* uart = USART1;
	if(strcmp(RT_CONSOLE_DEVICE_NAME, "uart1") == 0)
	{
		uart = USART1;
	}
	else if(strcmp(RT_CONSOLE_DEVICE_NAME, "uart2") == 0)
	{
		uart = USART2;
	}
	else if(strcmp(RT_CONSOLE_DEVICE_NAME, "uart3") == 0)
	{
		uart = USART3;
	}
    else if(strcmp(RT_CONSOLE_DEVICE_NAME, "uart4") == 0)
	{
		uart = UART4;
	}
    else if(strcmp(RT_CONSOLE_DEVICE_NAME, "uart5") == 0)
	{
		uart = UART5;
	}
	return uart;
}
/* ---------------------------------------------------------------------------*/
/**
 * @brief  Reconfigure the UART peripheral
 * @param  None
 * @retval None
 */
void USART_Reconfiguration(void) {
  UartHandle.Instance        = get_mcu_check_uart();
  UartHandle.Init.BaudRate = 115200;
  UartHandle.Init.WordLength = UART_WORDLENGTH_8B;
  UartHandle.Init.StopBits   = UART_STOPBITS_1;
  UartHandle.Init.Parity = UART_PARITY_NONE;
  UartHandle.Init.Mode       = UART_MODE_TX;
  UartHandle.Init.HwFlowCtl  = UART_HWCONTROL_NONE;
  UartHandle.Init.OverSampling = UART_OVERSAMPLING_16;
  UartHandle.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  UartHandle.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  UartHandle.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  UartHandle.FifoMode = UART_FIFOMODE_DISABLE;
  UartHandle.NbRxDataToProcess = UART_RXFIFO_THRESHOLD_1_8;
  UartHandle.NbTxDataToProcess = UART_TXFIFO_THRESHOLD_1_8;
  __HAL_UART_RESET_HANDLE_STATE(&UartHandle);
  HAL_UART_Init(&UartHandle);
}
/* -------------------------------------------------------------------------*/
/**
 * @brief  Retargets the C library printf function to the USART.
 * @param  None
 * @retval None
 */
PUTCHAR_PROTOTYPE {
	/* Place your implementation of fputc here */
	/* e.g. write a character to the EVAL_COM1 and Loop until the end of transmission */
	HAL_UART_Transmit(&UartHandle, (uint8_t *) &ch, 1, 0xFFFF);

	return ch;
}
#ifdef __GNUC__
/* -------------------------------------------------------------------------*/
/**
 * @brief  Retargets the C library printf function to the USART.
 * @param  None
 * @retval None
 */
int16_t _write(int16_t file, int8_t *ptr, int16_t len) {
	int16_t DataIdx;

	for (DataIdx = 0; DataIdx < len; DataIdx++) {
		__io_putchar(*ptr++);
	}
	return len;
}
#endif /* __GNUC__ */
#ifdef __CC_ARM
/* -------------------------------------------------------------------------*/
/**
 * @brief  Retargets the C library printf function to the USART.
 * @param  None
 * @retval None
 */
int16_t __write(int16_t file, int8_t *ptr, int16_t len) {
  int16_t DataIdx;

  for (DataIdx = 0; DataIdx < len; DataIdx++) {
    putchar(*ptr++);
  }
  return len;
}
#endif /* __CC_ARM */
#endif /* STL_VERBOSE */

/**
  * @brief  Configure the MPU attributes as Write Through for External SDRAM.
  * @note   The Base Address is SDRAM_DEVICE_ADDR
  *         The Configured Region Size is 32MB because same as SDRAM size.
  * @param  None
  * @retval None
  */
static void MPU_Config(void)
{
  MPU_Region_InitTypeDef MPU_InitStruct;
  
  /* Disable the MPU */
  HAL_MPU_Disable();

  /* Configure the MPU attributes as WT for SDRAM */
  MPU_InitStruct.Enable = MPU_REGION_ENABLE;
  MPU_InitStruct.BaseAddress = SRAM1_BASE; /* TODO (mle) which SRAM to use */
  MPU_InitStruct.Size = MPU_REGION_SIZE_32MB;
  MPU_InitStruct.AccessPermission = MPU_REGION_FULL_ACCESS;
  MPU_InitStruct.IsBufferable = MPU_ACCESS_NOT_BUFFERABLE;
  MPU_InitStruct.IsCacheable = MPU_ACCESS_CACHEABLE;
  MPU_InitStruct.IsShareable = MPU_ACCESS_NOT_SHAREABLE;
  MPU_InitStruct.Number = MPU_REGION_NUMBER0;
  MPU_InitStruct.TypeExtField = MPU_TEX_LEVEL0;
  MPU_InitStruct.SubRegionDisable = 0x00;
  MPU_InitStruct.DisableExec = MPU_INSTRUCTION_ACCESS_ENABLE;

  HAL_MPU_ConfigRegion(&MPU_InitStruct);

  /* Enable the MPU */
  HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);
}

/**
  * @brief  CPU L1-Cache enable.
  * @param  None
  * @retval None
  */
static void CPU_CACHE_Enable(void)
{
	/* Enable prefetch */
	__HAL_FLASH_PREFETCH_BUFFER_ENABLE();
	
  /* Enable I-Cache */
  __HAL_FLASH_INSTRUCTION_CACHE_ENABLE();

  /* Enable D-Cache */
  __HAL_FLASH_DATA_CACHE_ENABLE();
}

/**
  * @brief  Configures user AUX GPIO.
  * @param  gpio pin of the AUX_GPIO_PORT
  * @retval none
  */
void User_AUX_Init(uint32_t msk)
{
  GPIO_InitTypeDef  aux_init_structure;

  /* Enable the AUX GPIO port Clock */
  __HAL_RCC_GPIOA_CLK_ENABLE();
   
  /* Configure the AUX GPIO pin */
  aux_init_structure.Pin   = msk;
  aux_init_structure.Mode  = GPIO_MODE_OUTPUT_PP;
  aux_init_structure.Pull  = GPIO_NOPULL;
  aux_init_structure.Speed = GPIO_SPEED_FREQ_VERY_HIGH;

  HAL_GPIO_Init(AUX_GPIO_PORT, &aux_init_structure);
  HAL_GPIO_WritePin(AUX_GPIO_PORT, msk, GPIO_PIN_RESET);
}


#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

	printf(">>>Assert failed<<< Wrong parameters value: file %s on line %d\r\n", file, line);

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
